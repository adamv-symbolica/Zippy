#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1,0,0,0,1,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_24 = Space::new();
  let mut v0_24_write = v0_24.write_zipper();
  let mut v0_24_cursor = descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0));
  let v0_24_origin = v0_24_cursor.path().len();
  for v0_24_byte in v0_24_cursor.child_mask().iter() {
    v0_24_cursor.descend_to_existing_byte(v0_24_byte);
    {
    let v1_2: Space = singleton(&v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_24_cursor.child_mask().iter() {
        v0_24_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 1)..(v0_24_origin + 2)]);
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let mut v4_7 = Space::new();
          let mut v4_7_write = v4_7.write_zipper();
          for v4_7_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v4_7_byte);
            {
            let v5_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v5_3: Space = intersect(&(*CONSTANT_2),&(v5_2));
            let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
            drop(v5_3);
            let v5_5: Space = subtract(&(*CONSTANT_1),&(v5_4));
            drop(v5_4);
            let v5_8: Space = if (&(v5_5)).is_empty() { Space::new() } else {
              let v6_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v5_5),&(v6_7))
            };
            drop(v5_5);
            let v5_9: Space = intersect(&(*CONSTANT_2),&(v5_2));
            drop(v5_2);
            let v5_10: Space = if has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
            drop(v5_9);
            let v5_12: Space = if (&(v5_10)).is_empty() { Space::new() } else {
              let v7_11: Space = routine_2(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v5_10),&(v7_11))
            };
            drop(v5_10);
            let v5_13: Space = unite(&(v5_8),&(v5_12));
            join_wrapped_into(&mut v4_7_write,&((v5_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v4_7_write);
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let mut v8_11 = Space::new();
          let mut v8_11_write = v8_11.write_zipper();
          for v8_11_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v8_11_byte);
            {
            let v9_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v9_3: Space = intersect(&(*CONSTANT_2),&(v9_2));
            let v9_4: Space = if has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
            drop(v9_3);
            let v9_5: Space = subtract(&(*CONSTANT_1),&(v9_4));
            drop(v9_4);
            let v9_8: Space = if (&(v9_5)).is_empty() { Space::new() } else {
              let v10_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v9_5),&(v10_7))
            };
            drop(v9_5);
            let v9_9: Space = intersect(&(*CONSTANT_2),&(v9_2));
            drop(v9_2);
            let v9_10: Space = if has_head(&(v9_9)) { singleton(&[]) } else { Space::new() };
            drop(v9_9);
            let v9_12: Space = if (&(v9_10)).is_empty() { Space::new() } else {
              let v11_11: Space = routine_3(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v9_10),&(v11_11))
            };
            drop(v9_10);
            let v9_13: Space = unite(&(v9_8),&(v9_12));
            join_wrapped_into(&mut v8_11_write,&((v9_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v8_11_write);
          compose(&(v3_10),&(v8_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_24_cursor.ascend(1);
      }
      drop(v2_6_write);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v12_10 = Space::new();
      let mut v12_10_write = v12_10.write_zipper();
      for v12_10_byte in v0_24_cursor.child_mask().iter() {
        v0_24_cursor.descend_to_existing_byte(v12_10_byte);
        {
        let v13_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 1)..(v0_24_origin + 2)]);
        let v13_3: Space = intersect(&(*CONSTANT_2),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_1),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v15_3: Space = intersect(&(*CONSTANT_2),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_1),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_2),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_11: Space = routine_2(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v14_7_write);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_2),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v19_3: Space = intersect(&(*CONSTANT_2),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_1),&(v19_4));
            drop(v19_4);
            let v19_7: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Space = routine_4(c, &v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)], &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 2)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v19_5),&(v20_6))
            };
            drop(v19_5);
            let v19_8: Space = intersect(&(*CONSTANT_2),&(v19_2));
            drop(v19_2);
            let v19_9: Space = if has_head(&(v19_8)) { singleton(&[]) } else { Space::new() };
            drop(v19_8);
            let v19_11: Space = if (&(v19_9)).is_empty() { Space::new() } else {
              let v21_10: Space = routine_5(c, &v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)], &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 2)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v19_9),&(v21_10))
            };
            drop(v19_9);
            let v19_12: Space = unite(&(v19_7),&(v19_11));
            join_wrapped_into(&mut v18_11_write,&((v19_12).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v18_11_write);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_10_write,&((v13_13).read_zipper()),&[]);
        }
        v0_24_cursor.ascend(1);
      }
      drop(v12_10_write);
      compose(&(v1_9),&(v12_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_24_write,&((v1_12).read_zipper()),&[]);
    }
    v0_24_cursor.ascend(1);
  }
  drop(v0_24_cursor);
  drop(v0_24_write);
  let v0_26: Space = wrap(&(v0_24),&(*CONSTANT_3));
  (v0_26).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v22_24 = Space::new();
  let mut v22_24_write = v22_24.write_zipper();
  let mut v22_24_cursor = (*s0).read_zipper();
  let v22_24_origin = v22_24_cursor.path().len();
  for v22_24_byte in v22_24_cursor.child_mask().iter() {
    v22_24_cursor.descend_to_existing_byte(v22_24_byte);
    {
    let v23_2: Space = singleton(&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
    let v23_3: Space = intersect(&(*CONSTANT_2),&(v23_2));
    let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
    drop(v23_3);
    let v23_5: Space = subtract(&(*CONSTANT_1),&(v23_4));
    drop(v23_4);
    let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
      let v24_6: Path = concat_path(&(*p0),&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
      let mut v24_7 = Space::new();
      let mut v24_7_write = v24_7.write_zipper();
      for v24_7_byte in v22_24_cursor.child_mask().iter() {
        v22_24_cursor.descend_to_existing_byte(v24_7_byte);
        {
        let v25_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
        let v25_3: Space = intersect(&(*CONSTANT_2),&(v25_2));
        let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
        drop(v25_3);
        let v25_5: Space = subtract(&(*CONSTANT_1),&(v25_4));
        drop(v25_4);
        let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
          let v26_6: Path = concat_path(&(v24_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v26_7 = Space::new();
          let mut v26_7_write = v26_7.write_zipper();
          for v26_7_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v26_7_byte);
            {
            let v27_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v27_3: Space = intersect(&(*CONSTANT_2),&(v27_2));
            let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
            drop(v27_3);
            let v27_5: Space = subtract(&(*CONSTANT_1),&(v27_4));
            drop(v27_4);
            let v27_8: Space = if (&(v27_5)).is_empty() { Space::new() } else {
              let v28_6: Path = concat_path(&(v26_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v28_7: Space = routine_6(c, &(v28_6), &v22_24_cursor, &(*s1));
              compose(&(v27_5),&(v28_7))
            };
            drop(v27_5);
            let v27_9: Space = intersect(&(*CONSTANT_2),&(v27_2));
            drop(v27_2);
            let v27_10: Space = if has_head(&(v27_9)) { singleton(&[]) } else { Space::new() };
            drop(v27_9);
            let v27_12: Space = if (&(v27_10)).is_empty() { Space::new() } else {
              let v29_6: Path = concat_path(&(v26_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v29_11: Space = routine_7(c, &(v29_6), &v22_24_cursor, &(*s1));
              drop(v29_6);
              compose(&(v27_10),&(v29_11))
            };
            drop(v27_10);
            let v27_13: Space = unite(&(v27_8),&(v27_12));
            join_wrapped_into(&mut v26_7_write,&((v27_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v26_7_write);
          compose(&(v25_5),&(v26_7))
        };
        drop(v25_5);
        let v25_9: Space = intersect(&(*CONSTANT_2),&(v25_2));
        drop(v25_2);
        let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
        drop(v25_9);
        let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
          let v30_6: Path = concat_path(&(v24_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v30_11 = Space::new();
          let mut v30_11_write = v30_11.write_zipper();
          for v30_11_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v30_11_byte);
            {
            let v31_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v31_3: Space = intersect(&(*CONSTANT_2),&(v31_2));
            let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
            drop(v31_3);
            let v31_5: Space = subtract(&(*CONSTANT_1),&(v31_4));
            drop(v31_4);
            let v31_8: Space = if (&(v31_5)).is_empty() { Space::new() } else {
              let v32_6: Path = concat_path(&(v30_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v32_7: Space = routine_6(c, &(v32_6), &v22_24_cursor, &(*s1));
              compose(&(v31_5),&(v32_7))
            };
            drop(v31_5);
            let v31_9: Space = intersect(&(*CONSTANT_2),&(v31_2));
            drop(v31_2);
            let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
            drop(v31_9);
            let v31_12: Space = if (&(v31_10)).is_empty() { Space::new() } else {
              let v33_6: Path = concat_path(&(v30_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v33_11: Space = routine_3(c, &(v33_6), &v22_24_cursor, &(*s1));
              drop(v33_6);
              compose(&(v31_10),&(v33_11))
            };
            drop(v31_10);
            let v31_13: Space = unite(&(v31_8),&(v31_12));
            join_wrapped_into(&mut v30_11_write,&((v31_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v30_11_write);
          drop(v30_6);
          compose(&(v25_10),&(v30_11))
        };
        drop(v25_10);
        let v25_13: Space = unite(&(v25_8),&(v25_12));
        join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
        }
        v22_24_cursor.ascend(1);
      }
      drop(v24_7_write);
      compose(&(v23_5),&(v24_7))
    };
    drop(v23_5);
    let v23_9: Space = intersect(&(*CONSTANT_2),&(v23_2));
    drop(v23_2);
    let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
    drop(v23_9);
    let v23_12: Space = if (&(v23_10)).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
      let mut v34_11 = Space::new();
      let mut v34_11_write = v34_11.write_zipper();
      for v34_11_byte in v22_24_cursor.child_mask().iter() {
        v22_24_cursor.descend_to_existing_byte(v34_11_byte);
        {
        let v35_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
        let v35_3: Space = intersect(&(*CONSTANT_2),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_1),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (&(v35_5)).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v36_7 = Space::new();
          let mut v36_7_write = v36_7.write_zipper();
          for v36_7_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v36_7_byte);
            {
            let v37_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v37_3: Space = intersect(&(*CONSTANT_2),&(v37_2));
            let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
            drop(v37_3);
            let v37_5: Space = subtract(&(*CONSTANT_1),&(v37_4));
            drop(v37_4);
            let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
              let v38_6: Path = concat_path(&(v36_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v38_7: Space = routine_6(c, &(v38_6), &v22_24_cursor, &(*s1));
              compose(&(v37_5),&(v38_7))
            };
            drop(v37_5);
            let v37_9: Space = intersect(&(*CONSTANT_2),&(v37_2));
            drop(v37_2);
            let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
            drop(v37_9);
            let v37_12: Space = if (&(v37_10)).is_empty() { Space::new() } else {
              let v39_6: Path = concat_path(&(v36_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v39_11: Space = routine_7(c, &(v39_6), &v22_24_cursor, &(*s1));
              drop(v39_6);
              compose(&(v37_10),&(v39_11))
            };
            drop(v37_10);
            let v37_13: Space = unite(&(v37_8),&(v37_12));
            join_wrapped_into(&mut v36_7_write,&((v37_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v36_7_write);
          compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = intersect(&(*CONSTANT_2),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (&(v35_10)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v34_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v40_11 = Space::new();
          let mut v40_11_write = v40_11.write_zipper();
          for v40_11_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v40_11_byte);
            {
            let v41_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v41_3: Space = intersect(&(*CONSTANT_2),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_1),&(v41_4));
            drop(v41_4);
            let v41_7: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Space = routine_4(c, &v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)], &(v40_6), &v22_24_cursor, &(*s1));
              compose(&(v41_5),&(v42_6))
            };
            drop(v41_5);
            let v41_8: Space = intersect(&(*CONSTANT_2),&(v41_2));
            drop(v41_2);
            let v41_9: Space = if has_head(&(v41_8)) { singleton(&[]) } else { Space::new() };
            drop(v41_8);
            let v41_11: Space = if (&(v41_9)).is_empty() { Space::new() } else {
              let v43_10: Space = routine_5(c, &v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)], &(v40_6), &v22_24_cursor, &(*s1));
              compose(&(v41_9),&(v43_10))
            };
            drop(v41_9);
            let v41_12: Space = unite(&(v41_7),&(v41_11));
            join_wrapped_into(&mut v40_11_write,&((v41_12).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v40_11_write);
          drop(v40_6);
          compose(&(v35_10),&(v40_11))
        };
        drop(v35_10);
        let v35_13: Space = unite(&(v35_8),&(v35_12));
        join_wrapped_into(&mut v34_11_write,&((v35_13).read_zipper()),&[]);
        }
        v22_24_cursor.ascend(1);
      }
      drop(v34_11_write);
      drop(v34_6);
      compose(&(v23_10),&(v34_11))
    };
    drop(v23_10);
    let v23_13: Space = unite(&(v23_8),&(v23_12));
    join_wrapped_into(&mut v22_24_write,&((v23_13).read_zipper()),&[]);
    }
    v22_24_cursor.ascend(1);
  }
  drop(v22_24_cursor);
  drop(v22_24_write);
  (v22_24).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v44_24 = Space::new();
  let mut v44_24_write = v44_24.write_zipper();
  let mut v44_24_cursor = (*s0).read_zipper();
  let v44_24_origin = v44_24_cursor.path().len();
  for v44_24_byte in v44_24_cursor.child_mask().iter() {
    v44_24_cursor.descend_to_existing_byte(v44_24_byte);
    {
    let v45_2: Space = singleton(&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
    let v45_3: Space = intersect(&(*CONSTANT_2),&(v45_2));
    let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
    drop(v45_3);
    let v45_5: Space = subtract(&(*CONSTANT_1),&(v45_4));
    drop(v45_4);
    let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
      let mut v46_7 = Space::new();
      let mut v46_7_write = v46_7.write_zipper();
      for v46_7_byte in v44_24_cursor.child_mask().iter() {
        v44_24_cursor.descend_to_existing_byte(v46_7_byte);
        {
        let v47_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
        let v47_3: Space = intersect(&(*CONSTANT_2),&(v47_2));
        let v47_4: Space = if has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = subtract(&(*CONSTANT_1),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (&(v47_5)).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
          let mut v48_7 = Space::new();
          let mut v48_7_write = v48_7.write_zipper();
          for v48_7_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v48_7_byte);
            {
            let v49_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v49_3: Space = intersect(&(*CONSTANT_2),&(v49_2));
            let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
            drop(v49_3);
            let v49_5: Space = subtract(&(*CONSTANT_1),&(v49_4));
            drop(v49_4);
            let v49_8: Space = if (&(v49_5)).is_empty() { Space::new() } else {
              let v50_6: Path = concat_path(&(v48_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v50_7: Space = routine_6(c, &(v50_6), &v44_24_cursor, &(*s1));
              compose(&(v49_5),&(v50_7))
            };
            drop(v49_5);
            let v49_9: Space = intersect(&(*CONSTANT_2),&(v49_2));
            drop(v49_2);
            let v49_10: Space = if has_head(&(v49_9)) { singleton(&[]) } else { Space::new() };
            drop(v49_9);
            let v49_12: Space = if (&(v49_10)).is_empty() { Space::new() } else {
              let v51_6: Path = concat_path(&(v48_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v51_11: Space = routine_7(c, &(v51_6), &v44_24_cursor, &(*s1));
              drop(v51_6);
              compose(&(v49_10),&(v51_11))
            };
            drop(v49_10);
            let v49_13: Space = unite(&(v49_8),&(v49_12));
            join_wrapped_into(&mut v48_7_write,&((v49_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v48_7_write);
          compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = intersect(&(*CONSTANT_2),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (&(v47_10)).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v46_6),&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
          let mut v52_11 = Space::new();
          let mut v52_11_write = v52_11.write_zipper();
          for v52_11_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v52_11_byte);
            {
            let v53_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v53_3: Space = intersect(&(*CONSTANT_2),&(v53_2));
            let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
            drop(v53_3);
            let v53_5: Space = subtract(&(*CONSTANT_1),&(v53_4));
            drop(v53_4);
            let v53_8: Space = if (&(v53_5)).is_empty() { Space::new() } else {
              let v54_6: Path = concat_path(&(v52_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v54_7: Space = routine_6(c, &(v54_6), &v44_24_cursor, &(*s1));
              compose(&(v53_5),&(v54_7))
            };
            drop(v53_5);
            let v53_9: Space = intersect(&(*CONSTANT_2),&(v53_2));
            drop(v53_2);
            let v53_10: Space = if has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
            drop(v53_9);
            let v53_12: Space = if (&(v53_10)).is_empty() { Space::new() } else {
              let v55_6: Path = concat_path(&(v52_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v55_11: Space = routine_3(c, &(v55_6), &v44_24_cursor, &(*s1));
              drop(v55_6);
              compose(&(v53_10),&(v55_11))
            };
            drop(v53_10);
            let v53_13: Space = unite(&(v53_8),&(v53_12));
            join_wrapped_into(&mut v52_11_write,&((v53_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v52_11_write);
          drop(v52_6);
          compose(&(v47_10),&(v52_11))
        };
        drop(v47_10);
        let v47_13: Space = unite(&(v47_8),&(v47_12));
        join_wrapped_into(&mut v46_7_write,&((v47_13).read_zipper()),&[]);
        }
        v44_24_cursor.ascend(1);
      }
      drop(v46_7_write);
      compose(&(v45_5),&(v46_7))
    };
    drop(v45_5);
    let v45_9: Space = intersect(&(*CONSTANT_2),&(v45_2));
    drop(v45_2);
    let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
    drop(v45_9);
    let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
      let mut v56_11 = Space::new();
      let mut v56_11_write = v56_11.write_zipper();
      for v56_11_byte in v44_24_cursor.child_mask().iter() {
        v44_24_cursor.descend_to_existing_byte(v56_11_byte);
        {
        let v57_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
        let v57_3: Space = intersect(&(*CONSTANT_2),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_1),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (&(v57_5)).is_empty() { Space::new() } else {
          let mut v58_6 = Space::new();
          let mut v58_6_write = v58_6.write_zipper();
          for v58_6_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v58_6_byte);
            {
            let v59_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v59_3: Space = intersect(&(*CONSTANT_2),&(v59_2));
            let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
            drop(v59_3);
            let v59_5: Space = subtract(&(*CONSTANT_1),&(v59_4));
            drop(v59_4);
            let v59_8: Space = if (&(v59_5)).is_empty() { Space::new() } else {
              let v60_7: Space = routine_8(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v59_5),&(v60_7))
            };
            drop(v59_5);
            let v59_9: Space = intersect(&(*CONSTANT_2),&(v59_2));
            drop(v59_2);
            let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
            drop(v59_9);
            let v59_12: Space = if (&(v59_10)).is_empty() { Space::new() } else {
              let v61_11: Space = routine_9(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v59_10),&(v61_11))
            };
            drop(v59_10);
            let v59_13: Space = unite(&(v59_8),&(v59_12));
            join_wrapped_into(&mut v58_6_write,&((v59_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v58_6_write);
          compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = intersect(&(*CONSTANT_2),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (&(v57_9)).is_empty() { Space::new() } else {
          let mut v62_10 = Space::new();
          let mut v62_10_write = v62_10.write_zipper();
          for v62_10_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v62_10_byte);
            {
            let v63_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v63_3: Space = intersect(&(*CONSTANT_2),&(v63_2));
            let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
            drop(v63_3);
            let v63_5: Space = subtract(&(*CONSTANT_1),&(v63_4));
            drop(v63_4);
            let v63_8: Space = if (&(v63_5)).is_empty() { Space::new() } else {
              let v64_7: Space = routine_8(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v63_5),&(v64_7))
            };
            drop(v63_5);
            let v63_9: Space = intersect(&(*CONSTANT_2),&(v63_2));
            drop(v63_2);
            let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
            drop(v63_9);
            let v63_12: Space = if (&(v63_10)).is_empty() { Space::new() } else {
              let v65_11: Space = routine_10(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v63_10),&(v65_11))
            };
            drop(v63_10);
            let v63_13: Space = unite(&(v63_8),&(v63_12));
            join_wrapped_into(&mut v62_10_write,&((v63_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v62_10_write);
          compose(&(v57_9),&(v62_10))
        };
        drop(v57_9);
        let v57_12: Space = unite(&(v57_7),&(v57_11));
        join_wrapped_into(&mut v56_11_write,&((v57_12).read_zipper()),&[]);
        }
        v44_24_cursor.ascend(1);
      }
      drop(v56_11_write);
      drop(v56_6);
      compose(&(v45_10),&(v56_11))
    };
    drop(v45_10);
    let v45_13: Space = unite(&(v45_8),&(v45_12));
    join_wrapped_into(&mut v44_24_write,&((v45_13).read_zipper()),&[]);
    }
    v44_24_cursor.ascend(1);
  }
  drop(v44_24_cursor);
  drop(v44_24_write);
  (v44_24).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v66_26 = Space::new();
  let mut v66_26_write = v66_26.write_zipper();
  let mut v66_26_cursor = (*s0).read_zipper();
  let v66_26_origin = v66_26_cursor.path().len();
  for v66_26_byte in v66_26_cursor.child_mask().iter() {
    v66_26_cursor.descend_to_existing_byte(v66_26_byte);
    {
    let v67_2: Space = singleton(&v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 1)]);
    let v67_3: Space = intersect(&(*CONSTANT_2),&(v67_2));
    let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
    drop(v67_3);
    let v67_5: Space = subtract(&(*CONSTANT_1),&(v67_4));
    drop(v67_4);
    let v67_7: Space = if (&(v67_5)).is_empty() { Space::new() } else {
      let mut v68_6 = Space::new();
      let mut v68_6_write = v68_6.write_zipper();
      for v68_6_byte in v66_26_cursor.child_mask().iter() {
        v66_26_cursor.descend_to_existing_byte(v68_6_byte);
        {
        let v69_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
        let v69_3: Space = intersect(&(*CONSTANT_2),&(v69_2));
        let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
        drop(v69_3);
        let v69_5: Space = subtract(&(*CONSTANT_1),&(v69_4));
        drop(v69_4);
        let v69_8: Space = if (&(v69_5)).is_empty() { Space::new() } else {
          let mut v70_7 = Space::new();
          let mut v70_7_write = v70_7.write_zipper();
          for v70_7_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v70_7_byte);
            {
            let v71_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v71_3: Space = intersect(&(*CONSTANT_2),&(v71_2));
            let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
            drop(v71_3);
            let v71_5: Space = subtract(&(*CONSTANT_1),&(v71_4));
            drop(v71_4);
            let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
              let v72_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v71_5),&(v72_7))
            };
            drop(v71_5);
            let v71_9: Space = intersect(&(*CONSTANT_2),&(v71_2));
            drop(v71_2);
            let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
            drop(v71_9);
            let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
              let v73_11: Space = routine_12(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v71_10),&(v73_11))
            };
            drop(v71_10);
            let v71_13: Space = unite(&(v71_8),&(v71_12));
            join_wrapped_into(&mut v70_7_write,&((v71_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v70_7_write);
          compose(&(v69_5),&(v70_7))
        };
        drop(v69_5);
        let v69_9: Space = intersect(&(*CONSTANT_2),&(v69_2));
        drop(v69_2);
        let v69_10: Space = if has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
        drop(v69_9);
        let v69_12: Space = if (&(v69_10)).is_empty() { Space::new() } else {
          let mut v74_11 = Space::new();
          let mut v74_11_write = v74_11.write_zipper();
          for v74_11_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v74_11_byte);
            {
            let v75_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v75_3: Space = intersect(&(*CONSTANT_2),&(v75_2));
            let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
            drop(v75_3);
            let v75_5: Space = subtract(&(*CONSTANT_1),&(v75_4));
            drop(v75_4);
            let v75_8: Space = if (&(v75_5)).is_empty() { Space::new() } else {
              let v76_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v75_5),&(v76_7))
            };
            drop(v75_5);
            let v75_9: Space = intersect(&(*CONSTANT_2),&(v75_2));
            drop(v75_2);
            let v75_10: Space = if has_head(&(v75_9)) { singleton(&[]) } else { Space::new() };
            drop(v75_9);
            let v75_12: Space = if (&(v75_10)).is_empty() { Space::new() } else {
              let v77_11: Space = routine_10(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v75_10),&(v77_11))
            };
            drop(v75_10);
            let v75_13: Space = unite(&(v75_8),&(v75_12));
            join_wrapped_into(&mut v74_11_write,&((v75_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v74_11_write);
          compose(&(v69_10),&(v74_11))
        };
        drop(v69_10);
        let v69_13: Space = unite(&(v69_8),&(v69_12));
        join_wrapped_into(&mut v68_6_write,&((v69_13).read_zipper()),&[]);
        }
        v66_26_cursor.ascend(1);
      }
      drop(v68_6_write);
      compose(&(v67_5),&(v68_6))
    };
    drop(v67_5);
    let v67_8: Space = intersect(&(*CONSTANT_2),&(v67_2));
    drop(v67_2);
    let v67_9: Space = if has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
    drop(v67_8);
    let v67_12: Space = if (&(v67_9)).is_empty() { Space::new() } else {
      let mut v78_11 = Space::new();
      let mut v78_11_write = v78_11.write_zipper();
      for v78_11_byte in v66_26_cursor.child_mask().iter() {
        v66_26_cursor.descend_to_existing_byte(v78_11_byte);
        {
        let v79_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
        let v79_3: Space = intersect(&(*CONSTANT_2),&(v79_2));
        let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
        drop(v79_3);
        let v79_5: Space = subtract(&(*CONSTANT_1),&(v79_4));
        drop(v79_4);
        let v79_8: Space = if (&(v79_5)).is_empty() { Space::new() } else {
          let mut v80_7 = Space::new();
          let mut v80_7_write = v80_7.write_zipper();
          for v80_7_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v80_7_byte);
            {
            let v81_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v81_3: Space = intersect(&(*CONSTANT_2),&(v81_2));
            let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
            drop(v81_3);
            let v81_5: Space = subtract(&(*CONSTANT_1),&(v81_4));
            drop(v81_4);
            let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
              let v82_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v81_5),&(v82_7))
            };
            drop(v81_5);
            let v81_9: Space = intersect(&(*CONSTANT_2),&(v81_2));
            drop(v81_2);
            let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
            drop(v81_9);
            let v81_12: Space = if (&(v81_10)).is_empty() { Space::new() } else {
              let v83_11: Space = routine_12(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v81_10),&(v83_11))
            };
            drop(v81_10);
            let v81_13: Space = unite(&(v81_8),&(v81_12));
            join_wrapped_into(&mut v80_7_write,&((v81_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v80_7_write);
          compose(&(v79_5),&(v80_7))
        };
        drop(v79_5);
        let v79_9: Space = intersect(&(*CONSTANT_2),&(v79_2));
        drop(v79_2);
        let v79_10: Space = if has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
        drop(v79_9);
        let v79_13: Space = if (&(v79_10)).is_empty() { Space::new() } else {
          let mut v84_12 = Space::new();
          let mut v84_12_write = v84_12.write_zipper();
          let mut v84_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 1)]),&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
          let v84_12_origin = v84_12_cursor.path().len();
          for v84_12_byte in v84_12_cursor.child_mask().iter() {
            v84_12_cursor.descend_to_existing_byte(v84_12_byte);
            {
            let v85_2: Space = singleton(&v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)]);
            let v85_3: Space = intersect(&(*CONSTANT_2),&(v85_2));
            let v85_4: Space = if has_head(&(v85_3)) { singleton(&[]) } else { Space::new() };
            drop(v85_3);
            let v85_5: Space = subtract(&(*CONSTANT_1),&(v85_4));
            drop(v85_4);
            let v85_7: Space = if (&(v85_5)).is_empty() { Space::new() } else {
              let v86_6: Space = routine_13(c, &v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)], &(*p0), &v84_12_cursor);
              compose(&(v85_5),&(v86_6))
            };
            drop(v85_5);
            let v85_8: Space = intersect(&(*CONSTANT_2),&(v85_2));
            drop(v85_2);
            let v85_9: Space = if has_head(&(v85_8)) { singleton(&[]) } else { Space::new() };
            drop(v85_8);
            let v85_11: Space = if (&(v85_9)).is_empty() { Space::new() } else {
              let v87_10: Space = routine_14(c, &v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)], &(*p0), &v84_12_cursor);
              compose(&(v85_9),&(v87_10))
            };
            drop(v85_9);
            let v85_12: Space = unite(&(v85_7),&(v85_11));
            join_wrapped_into(&mut v84_12_write,&((v85_12).read_zipper()),&[]);
            }
            v84_12_cursor.ascend(1);
          }
          drop(v84_12_cursor);
          drop(v84_12_write);
          compose(&(v79_10),&(v84_12))
        };
        drop(v79_10);
        let v79_14: Space = unite(&(v79_8),&(v79_13));
        join_wrapped_into(&mut v78_11_write,&((v79_14).read_zipper()),&[]);
        }
        v66_26_cursor.ascend(1);
      }
      drop(v78_11_write);
      compose(&(v67_9),&(v78_11))
    };
    drop(v67_9);
    let v67_13: Space = unite(&(v67_7),&(v67_12));
    join_wrapped_into(&mut v66_26_write,&((v67_13).read_zipper()),&[]);
    }
    v66_26_cursor.ascend(1);
  }
  drop(v66_26_cursor);
  drop(v66_26_write);
  (v66_26).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v88_28 = Space::new();
  let mut v88_28_write = v88_28.write_zipper();
  let mut v88_28_cursor = (*s0).read_zipper();
  let v88_28_origin = v88_28_cursor.path().len();
  for v88_28_byte in v88_28_cursor.child_mask().iter() {
    v88_28_cursor.descend_to_existing_byte(v88_28_byte);
    {
    let v89_2: Space = singleton(&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
    let v89_3: Space = intersect(&(*CONSTANT_2),&(v89_2));
    let v89_4: Space = if has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
    drop(v89_3);
    let v89_5: Space = subtract(&(*CONSTANT_1),&(v89_4));
    drop(v89_4);
    let v89_8: Space = if (&(v89_5)).is_empty() { Space::new() } else {
      let v90_6: Path = concat_path(&(*p0),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
      let mut v90_7 = Space::new();
      let mut v90_7_write = v90_7.write_zipper();
      for v90_7_byte in v88_28_cursor.child_mask().iter() {
        v88_28_cursor.descend_to_existing_byte(v90_7_byte);
        {
        let v91_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
        let v91_3: Space = intersect(&(*CONSTANT_2),&(v91_2));
        let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
        drop(v91_3);
        let v91_5: Space = subtract(&(*CONSTANT_1),&(v91_4));
        drop(v91_4);
        let v91_8: Space = if (&(v91_5)).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v90_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v92_7 = Space::new();
          let mut v92_7_write = v92_7.write_zipper();
          for v92_7_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v92_7_byte);
            {
            let v93_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v93_3: Space = intersect(&(*CONSTANT_2),&(v93_2));
            let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
            drop(v93_3);
            let v93_5: Space = subtract(&(*CONSTANT_1),&(v93_4));
            drop(v93_4);
            let v93_8: Space = if (&(v93_5)).is_empty() { Space::new() } else {
              let v94_6: Path = concat_path(&(v92_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v94_7: Space = routine_15(c, &(v94_6), &(*p1), &v88_28_cursor, &(*s1));
              compose(&(v93_5),&(v94_7))
            };
            drop(v93_5);
            let v93_9: Space = intersect(&(*CONSTANT_2),&(v93_2));
            drop(v93_2);
            let v93_10: Space = if has_head(&(v93_9)) { singleton(&[]) } else { Space::new() };
            drop(v93_9);
            let v93_12: Space = if (&(v93_10)).is_empty() { Space::new() } else {
              let v95_6: Path = concat_path(&(v92_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v95_11: Space = routine_16(c, &(v95_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v95_6);
              compose(&(v93_10),&(v95_11))
            };
            drop(v93_10);
            let v93_13: Space = unite(&(v93_8),&(v93_12));
            join_wrapped_into(&mut v92_7_write,&((v93_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v92_7_write);
          compose(&(v91_5),&(v92_7))
        };
        drop(v91_5);
        let v91_9: Space = intersect(&(*CONSTANT_2),&(v91_2));
        drop(v91_2);
        let v91_10: Space = if has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
        drop(v91_9);
        let v91_12: Space = if (&(v91_10)).is_empty() { Space::new() } else {
          let v96_6: Path = concat_path(&(v90_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v96_11 = Space::new();
          let mut v96_11_write = v96_11.write_zipper();
          for v96_11_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v96_11_byte);
            {
            let v97_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v97_3: Space = intersect(&(*CONSTANT_2),&(v97_2));
            let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
            drop(v97_3);
            let v97_5: Space = subtract(&(*CONSTANT_1),&(v97_4));
            drop(v97_4);
            let v97_8: Space = if (&(v97_5)).is_empty() { Space::new() } else {
              let v98_6: Path = concat_path(&(v96_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v98_7: Space = routine_15(c, &(v98_6), &(*p1), &v88_28_cursor, &(*s1));
              compose(&(v97_5),&(v98_7))
            };
            drop(v97_5);
            let v97_9: Space = intersect(&(*CONSTANT_2),&(v97_2));
            drop(v97_2);
            let v97_10: Space = if has_head(&(v97_9)) { singleton(&[]) } else { Space::new() };
            drop(v97_9);
            let v97_12: Space = if (&(v97_10)).is_empty() { Space::new() } else {
              let v99_6: Path = concat_path(&(v96_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v99_11: Space = routine_10(c, &(v99_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v99_6);
              compose(&(v97_10),&(v99_11))
            };
            drop(v97_10);
            let v97_13: Space = unite(&(v97_8),&(v97_12));
            join_wrapped_into(&mut v96_11_write,&((v97_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v96_11_write);
          drop(v96_6);
          compose(&(v91_10),&(v96_11))
        };
        drop(v91_10);
        let v91_13: Space = unite(&(v91_8),&(v91_12));
        join_wrapped_into(&mut v90_7_write,&((v91_13).read_zipper()),&[]);
        }
        v88_28_cursor.ascend(1);
      }
      drop(v90_7_write);
      compose(&(v89_5),&(v90_7))
    };
    drop(v89_5);
    let v89_9: Space = intersect(&(*CONSTANT_2),&(v89_2));
    drop(v89_2);
    let v89_10: Space = if has_head(&(v89_9)) { singleton(&[]) } else { Space::new() };
    drop(v89_9);
    let v89_13: Space = if (&(v89_10)).is_empty() { Space::new() } else {
      let v100_6: Path = concat_path(&(*p0),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
      let mut v100_12 = Space::new();
      let mut v100_12_write = v100_12.write_zipper();
      for v100_12_byte in v88_28_cursor.child_mask().iter() {
        v88_28_cursor.descend_to_existing_byte(v100_12_byte);
        {
        let v101_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
        let v101_3: Space = intersect(&(*CONSTANT_2),&(v101_2));
        let v101_4: Space = if has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
        drop(v101_3);
        let v101_5: Space = subtract(&(*CONSTANT_1),&(v101_4));
        drop(v101_4);
        let v101_8: Space = if (&(v101_5)).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v100_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v102_7 = Space::new();
          let mut v102_7_write = v102_7.write_zipper();
          for v102_7_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v102_7_byte);
            {
            let v103_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v103_3: Space = intersect(&(*CONSTANT_2),&(v103_2));
            let v103_4: Space = if has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
            drop(v103_3);
            let v103_5: Space = subtract(&(*CONSTANT_1),&(v103_4));
            drop(v103_4);
            let v103_8: Space = if (&(v103_5)).is_empty() { Space::new() } else {
              let v104_6: Path = concat_path(&(v102_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v104_7: Space = routine_15(c, &(v104_6), &(*p1), &v88_28_cursor, &(*s1));
              compose(&(v103_5),&(v104_7))
            };
            drop(v103_5);
            let v103_9: Space = intersect(&(*CONSTANT_2),&(v103_2));
            drop(v103_2);
            let v103_10: Space = if has_head(&(v103_9)) { singleton(&[]) } else { Space::new() };
            drop(v103_9);
            let v103_12: Space = if (&(v103_10)).is_empty() { Space::new() } else {
              let v105_6: Path = concat_path(&(v102_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v105_11: Space = routine_16(c, &(v105_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v105_6);
              compose(&(v103_10),&(v105_11))
            };
            drop(v103_10);
            let v103_13: Space = unite(&(v103_8),&(v103_12));
            join_wrapped_into(&mut v102_7_write,&((v103_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v102_7_write);
          drop(v102_6);
          compose(&(v101_5),&(v102_7))
        };
        drop(v101_5);
        let v101_9: Space = intersect(&(*CONSTANT_2),&(v101_2));
        drop(v101_2);
        let v101_10: Space = if has_head(&(v101_9)) { singleton(&[]) } else { Space::new() };
        drop(v101_9);
        let v101_13: Space = if (&(v101_10)).is_empty() { Space::new() } else {
          let mut v106_12 = Space::new();
          let mut v106_12_write = v106_12.write_zipper();
          let mut v106_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let v106_12_origin = v106_12_cursor.path().len();
          for v106_12_byte in v106_12_cursor.child_mask().iter() {
            v106_12_cursor.descend_to_existing_byte(v106_12_byte);
            {
            let v107_2: Space = singleton(&v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)]);
            let v107_3: Space = intersect(&(*CONSTANT_2),&(v107_2));
            let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
            drop(v107_3);
            let v107_5: Space = subtract(&(*CONSTANT_1),&(v107_4));
            drop(v107_4);
            let v107_7: Space = if (&(v107_5)).is_empty() { Space::new() } else {
              let v108_6: Space = routine_13(c, &v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)], &(*p1), &v106_12_cursor);
              compose(&(v107_5),&(v108_6))
            };
            drop(v107_5);
            let v107_8: Space = intersect(&(*CONSTANT_2),&(v107_2));
            drop(v107_2);
            let v107_9: Space = if has_head(&(v107_8)) { singleton(&[]) } else { Space::new() };
            drop(v107_8);
            let v107_11: Space = if (&(v107_9)).is_empty() { Space::new() } else {
              let v109_10: Space = routine_14(c, &v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)], &(*p1), &v106_12_cursor);
              compose(&(v107_9),&(v109_10))
            };
            drop(v107_9);
            let v107_12: Space = unite(&(v107_7),&(v107_11));
            join_wrapped_into(&mut v106_12_write,&((v107_12).read_zipper()),&[]);
            }
            v106_12_cursor.ascend(1);
          }
          drop(v106_12_cursor);
          drop(v106_12_write);
          compose(&(v101_10),&(v106_12))
        };
        drop(v101_10);
        let v101_14: Space = unite(&(v101_8),&(v101_13));
        join_wrapped_into(&mut v100_12_write,&((v101_14).read_zipper()),&[]);
        }
        v88_28_cursor.ascend(1);
      }
      drop(v100_12_write);
      drop(v100_6);
      compose(&(v89_10),&(v100_12))
    };
    drop(v89_10);
    let v89_14: Space = unite(&(v89_8),&(v89_13));
    join_wrapped_into(&mut v88_28_write,&((v89_14).read_zipper()),&[]);
    }
    v88_28_cursor.ascend(1);
  }
  drop(v88_28_cursor);
  drop(v88_28_write);
  (v88_28).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v110_28 = Space::new();
  let mut v110_28_write = v110_28.write_zipper();
  let mut v110_28_cursor = (*s0).read_zipper();
  let v110_28_origin = v110_28_cursor.path().len();
  for v110_28_byte in v110_28_cursor.child_mask().iter() {
    v110_28_cursor.descend_to_existing_byte(v110_28_byte);
    {
    let v111_2: Space = singleton(&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
    let v111_3: Space = intersect(&(*CONSTANT_2),&(v111_2));
    let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = subtract(&(*CONSTANT_1),&(v111_4));
    drop(v111_4);
    let v111_8: Space = if (&(v111_5)).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
      let mut v112_7 = Space::new();
      let mut v112_7_write = v112_7.write_zipper();
      for v112_7_byte in v110_28_cursor.child_mask().iter() {
        v110_28_cursor.descend_to_existing_byte(v112_7_byte);
        {
        let v113_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
        let v113_3: Space = intersect(&(*CONSTANT_2),&(v113_2));
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = subtract(&(*CONSTANT_1),&(v113_4));
        drop(v113_4);
        let v113_8: Space = if (&(v113_5)).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v112_6),&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
          let mut v114_7 = Space::new();
          let mut v114_7_write = v114_7.write_zipper();
          for v114_7_byte in v110_28_cursor.child_mask().iter() {
            v110_28_cursor.descend_to_existing_byte(v114_7_byte);
            {
            let v115_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
            let v115_3: Space = intersect(&(*CONSTANT_2),&(v115_2));
            let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
            drop(v115_3);
            let v115_5: Space = subtract(&(*CONSTANT_1),&(v115_4));
            drop(v115_4);
            let v115_8: Space = if (&(v115_5)).is_empty() { Space::new() } else {
              let v116_6: Path = concat_path(&(v114_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v116_7: Space = routine_15(c, &(v116_6), &(*p1), &v110_28_cursor, &(*s1));
              compose(&(v115_5),&(v116_7))
            };
            drop(v115_5);
            let v115_9: Space = intersect(&(*CONSTANT_2),&(v115_2));
            drop(v115_2);
            let v115_10: Space = if has_head(&(v115_9)) { singleton(&[]) } else { Space::new() };
            drop(v115_9);
            let v115_12: Space = if (&(v115_10)).is_empty() { Space::new() } else {
              let v117_6: Path = concat_path(&(v114_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v117_11: Space = routine_16(c, &(v117_6), &(*p1), &v110_28_cursor, &(*s1));
              drop(v117_6);
              compose(&(v115_10),&(v117_11))
            };
            drop(v115_10);
            let v115_13: Space = unite(&(v115_8),&(v115_12));
            join_wrapped_into(&mut v114_7_write,&((v115_13).read_zipper()),&[]);
            }
            v110_28_cursor.ascend(1);
          }
          drop(v114_7_write);
          compose(&(v113_5),&(v114_7))
        };
        drop(v113_5);
        let v113_9: Space = intersect(&(*CONSTANT_2),&(v113_2));
        drop(v113_2);
        let v113_10: Space = if has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
        drop(v113_9);
        let v113_12: Space = if (&(v113_10)).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v112_6),&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
          let mut v118_11 = Space::new();
          let mut v118_11_write = v118_11.write_zipper();
          for v118_11_byte in v110_28_cursor.child_mask().iter() {
            v110_28_cursor.descend_to_existing_byte(v118_11_byte);
            {
            let v119_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
            let v119_3: Space = intersect(&(*CONSTANT_2),&(v119_2));
            let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
            drop(v119_3);
            let v119_5: Space = subtract(&(*CONSTANT_1),&(v119_4));
            drop(v119_4);
            let v119_8: Space = if (&(v119_5)).is_empty() { Space::new() } else {
              let v120_6: Path = concat_path(&(v118_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v120_7: Space = routine_15(c, &(v120_6), &(*p1), &v110_28_cursor, &(*s1));
              compose(&(v119_5),&(v120_7))
            };
            drop(v119_5);
            let v119_9: Space = intersect(&(*CONSTANT_2),&(v119_2));
            drop(v119_2);
            let v119_10: Space = if has_head(&(v119_9)) { singleton(&[]) } else { Space::new() };
            drop(v119_9);
            let v119_12: Space = if (&(v119_10)).is_empty() { Space::new() } else {
              let v121_6: Path = concat_path(&(v118_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v121_11: Space = routine_10(c, &(v121_6), &(*p1), &v110_28_cursor, &(*s1));
              drop(v121_6);
              compose(&(v119_10),&(v121_11))
            };
            drop(v119_10);
            let v119_13: Space = unite(&(v119_8),&(v119_12));
            join_wrapped_into(&mut v118_11_write,&((v119_13).read_zipper()),&[]);
            }
            v110_28_cursor.ascend(1);
          }
          drop(v118_11_write);
          drop(v118_6);
          compose(&(v113_10),&(v118_11))
        };
        drop(v113_10);
        let v113_13: Space = unite(&(v113_8),&(v113_12));
        join_wrapped_into(&mut v112_7_write,&((v113_13).read_zipper()),&[]);
        }
        v110_28_cursor.ascend(1);
      }
      drop(v112_7_write);
      drop(v112_6);
      compose(&(v111_5),&(v112_7))
    };
    drop(v111_5);
    let v111_9: Space = intersect(&(*CONSTANT_2),&(v111_2));
    drop(v111_2);
    let v111_10: Space = if has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
    drop(v111_9);
    let v111_13: Space = if (&(v111_10)).is_empty() { Space::new() } else {
      let mut v122_12 = Space::new();
      let mut v122_12_write = v122_12.write_zipper();
      let mut v122_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
      let v122_12_origin = v122_12_cursor.path().len();
      for v122_12_byte in v122_12_cursor.child_mask().iter() {
        v122_12_cursor.descend_to_existing_byte(v122_12_byte);
        {
        let v123_2: Space = singleton(&v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 1)]);
        let v123_3: Space = intersect(&(*CONSTANT_2),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_1),&(v123_4));
        drop(v123_4);
        let v123_7: Space = if (&(v123_5)).is_empty() { Space::new() } else {
          let mut v124_6 = Space::new();
          let mut v124_6_write = v124_6.write_zipper();
          for v124_6_byte in v122_12_cursor.child_mask().iter() {
            v122_12_cursor.descend_to_existing_byte(v124_6_byte);
            {
            let v125_2: Space = singleton(&v122_12_cursor.path()[(v122_12_origin + 1)..(v122_12_origin + 2)]);
            let v125_3: Space = intersect(&(*CONSTANT_2),&(v125_2));
            let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = subtract(&(*CONSTANT_1),&(v125_4));
            drop(v125_4);
            let v125_8: Space = if (&(v125_5)).is_empty() { Space::new() } else {
              let v126_7: Space = routine_17(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              compose(&(v125_5),&(v126_7))
            };
            drop(v125_5);
            let v125_9: Space = intersect(&(*CONSTANT_2),&(v125_2));
            drop(v125_2);
            let v125_10: Space = if has_head(&(v125_9)) { singleton(&[]) } else { Space::new() };
            drop(v125_9);
            let v125_12: Space = if (&(v125_10)).is_empty() { Space::new() } else {
              let v127_11: Space = routine_18(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              compose(&(v125_10),&(v127_11))
            };
            drop(v125_10);
            let v125_13: Space = unite(&(v125_8),&(v125_12));
            join_wrapped_into(&mut v124_6_write,&((v125_13).read_zipper()),&[]);
            }
            v122_12_cursor.ascend(1);
          }
          drop(v124_6_write);
          compose(&(v123_5),&(v124_6))
        };
        drop(v123_5);
        let v123_8: Space = intersect(&(*CONSTANT_2),&(v123_2));
        drop(v123_2);
        let v123_9: Space = if has_head(&(v123_8)) { singleton(&[]) } else { Space::new() };
        drop(v123_8);
        let v123_11: Space = if (&(v123_9)).is_empty() { Space::new() } else {
          let mut v128_10 = Space::new();
          let mut v128_10_write = v128_10.write_zipper();
          for v128_10_byte in v122_12_cursor.child_mask().iter() {
            v122_12_cursor.descend_to_existing_byte(v128_10_byte);
            {
            let v129_2: Space = singleton(&v122_12_cursor.path()[(v122_12_origin + 1)..(v122_12_origin + 2)]);
            let v129_3: Space = intersect(&(*CONSTANT_2),&(v129_2));
            let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
            drop(v129_3);
            let v129_5: Space = subtract(&(*CONSTANT_1),&(v129_4));
            drop(v129_4);
            let v129_8: Space = if (&(v129_5)).is_empty() { Space::new() } else {
              let v130_7: Space = routine_17(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              compose(&(v129_5),&(v130_7))
            };
            drop(v129_5);
            let v129_9: Space = intersect(&(*CONSTANT_2),&(v129_2));
            drop(v129_2);
            let v129_10: Space = if has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
            drop(v129_9);
            let v129_12: Space = if (&(v129_10)).is_empty() { Space::new() } else {
              let v131_11: Space = routine_19(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              compose(&(v129_10),&(v131_11))
            };
            drop(v129_10);
            let v129_13: Space = unite(&(v129_8),&(v129_12));
            join_wrapped_into(&mut v128_10_write,&((v129_13).read_zipper()),&[]);
            }
            v122_12_cursor.ascend(1);
          }
          drop(v128_10_write);
          compose(&(v123_9),&(v128_10))
        };
        drop(v123_9);
        let v123_12: Space = unite(&(v123_7),&(v123_11));
        join_wrapped_into(&mut v122_12_write,&((v123_12).read_zipper()),&[]);
        }
        v122_12_cursor.ascend(1);
      }
      drop(v122_12_cursor);
      drop(v122_12_write);
      compose(&(v111_10),&(v122_12))
    };
    drop(v111_10);
    let v111_14: Space = unite(&(v111_8),&(v111_13));
    join_wrapped_into(&mut v110_28_write,&((v111_14).read_zipper()),&[]);
    }
    v110_28_cursor.ascend(1);
  }
  drop(v110_28_cursor);
  drop(v110_28_write);
  (v110_28).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v132_24 = Space::new();
  let mut v132_24_write = v132_24.write_zipper();
  let mut v132_24_cursor = (*s0).read_zipper();
  let v132_24_origin = v132_24_cursor.path().len();
  for v132_24_byte in v132_24_cursor.child_mask().iter() {
    v132_24_cursor.descend_to_existing_byte(v132_24_byte);
    {
    let v133_2: Space = singleton(&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
    let v133_3: Space = intersect(&(*CONSTANT_2),&(v133_2));
    let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
    drop(v133_3);
    let v133_5: Space = subtract(&(*CONSTANT_1),&(v133_4));
    drop(v133_4);
    let v133_8: Space = if (&(v133_5)).is_empty() { Space::new() } else {
      let v134_6: Path = concat_path(&(*p0),&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
      let mut v134_7 = Space::new();
      let mut v134_7_write = v134_7.write_zipper();
      for v134_7_byte in v132_24_cursor.child_mask().iter() {
        v132_24_cursor.descend_to_existing_byte(v134_7_byte);
        {
        let v135_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
        let v135_3: Space = intersect(&(*CONSTANT_2),&(v135_2));
        let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
        drop(v135_3);
        let v135_5: Space = subtract(&(*CONSTANT_1),&(v135_4));
        drop(v135_4);
        let v135_8: Space = if (&(v135_5)).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v134_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v136_7 = Space::new();
          let mut v136_7_write = v136_7.write_zipper();
          for v136_7_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v136_7_byte);
            {
            let v137_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v137_3: Space = intersect(&(*CONSTANT_2),&(v137_2));
            let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
            drop(v137_3);
            let v137_5: Space = subtract(&(*CONSTANT_1),&(v137_4));
            drop(v137_4);
            let v137_8: Space = if (&(v137_5)).is_empty() { Space::new() } else {
              let v138_6: Path = concat_path(&(v136_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v138_7: Space = routine_20(c, &(v138_6), &v132_24_cursor, &(*s1));
              compose(&(v137_5),&(v138_7))
            };
            drop(v137_5);
            let v137_9: Space = intersect(&(*CONSTANT_2),&(v137_2));
            drop(v137_2);
            let v137_10: Space = if has_head(&(v137_9)) { singleton(&[]) } else { Space::new() };
            drop(v137_9);
            let v137_12: Space = if (&(v137_10)).is_empty() { Space::new() } else {
              let v139_6: Path = concat_path(&(v136_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v139_11: Space = routine_21(c, &(v139_6), &v132_24_cursor, &(*s1));
              drop(v139_6);
              compose(&(v137_10),&(v139_11))
            };
            drop(v137_10);
            let v137_13: Space = unite(&(v137_8),&(v137_12));
            join_wrapped_into(&mut v136_7_write,&((v137_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v136_7_write);
          compose(&(v135_5),&(v136_7))
        };
        drop(v135_5);
        let v135_9: Space = intersect(&(*CONSTANT_2),&(v135_2));
        drop(v135_2);
        let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
        drop(v135_9);
        let v135_12: Space = if (&(v135_10)).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v134_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v140_11 = Space::new();
          let mut v140_11_write = v140_11.write_zipper();
          for v140_11_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v140_11_byte);
            {
            let v141_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v141_3: Space = intersect(&(*CONSTANT_2),&(v141_2));
            let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
            drop(v141_3);
            let v141_5: Space = subtract(&(*CONSTANT_1),&(v141_4));
            drop(v141_4);
            let v141_8: Space = if (&(v141_5)).is_empty() { Space::new() } else {
              let v142_6: Path = concat_path(&(v140_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v142_7: Space = routine_20(c, &(v142_6), &v132_24_cursor, &(*s1));
              compose(&(v141_5),&(v142_7))
            };
            drop(v141_5);
            let v141_9: Space = intersect(&(*CONSTANT_2),&(v141_2));
            drop(v141_2);
            let v141_10: Space = if has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
            drop(v141_9);
            let v141_12: Space = if (&(v141_10)).is_empty() { Space::new() } else {
              let v143_6: Path = concat_path(&(v140_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v143_11: Space = routine_3(c, &(v143_6), &v132_24_cursor, &(*s1));
              drop(v143_6);
              compose(&(v141_10),&(v143_11))
            };
            drop(v141_10);
            let v141_13: Space = unite(&(v141_8),&(v141_12));
            join_wrapped_into(&mut v140_11_write,&((v141_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v140_11_write);
          drop(v140_6);
          compose(&(v135_10),&(v140_11))
        };
        drop(v135_10);
        let v135_13: Space = unite(&(v135_8),&(v135_12));
        join_wrapped_into(&mut v134_7_write,&((v135_13).read_zipper()),&[]);
        }
        v132_24_cursor.ascend(1);
      }
      drop(v134_7_write);
      compose(&(v133_5),&(v134_7))
    };
    drop(v133_5);
    let v133_9: Space = intersect(&(*CONSTANT_2),&(v133_2));
    drop(v133_2);
    let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
    drop(v133_9);
    let v133_12: Space = if (&(v133_10)).is_empty() { Space::new() } else {
      let v144_6: Path = concat_path(&(*p0),&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
      let mut v144_11 = Space::new();
      let mut v144_11_write = v144_11.write_zipper();
      for v144_11_byte in v132_24_cursor.child_mask().iter() {
        v132_24_cursor.descend_to_existing_byte(v144_11_byte);
        {
        let v145_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
        let v145_3: Space = intersect(&(*CONSTANT_2),&(v145_2));
        let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
        drop(v145_3);
        let v145_5: Space = subtract(&(*CONSTANT_1),&(v145_4));
        drop(v145_4);
        let v145_8: Space = if (&(v145_5)).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v144_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v146_7 = Space::new();
          let mut v146_7_write = v146_7.write_zipper();
          for v146_7_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v146_7_byte);
            {
            let v147_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v147_3: Space = intersect(&(*CONSTANT_2),&(v147_2));
            let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
            drop(v147_3);
            let v147_5: Space = subtract(&(*CONSTANT_1),&(v147_4));
            drop(v147_4);
            let v147_8: Space = if (&(v147_5)).is_empty() { Space::new() } else {
              let v148_6: Path = concat_path(&(v146_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v148_7: Space = routine_20(c, &(v148_6), &v132_24_cursor, &(*s1));
              compose(&(v147_5),&(v148_7))
            };
            drop(v147_5);
            let v147_9: Space = intersect(&(*CONSTANT_2),&(v147_2));
            drop(v147_2);
            let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
            drop(v147_9);
            let v147_12: Space = if (&(v147_10)).is_empty() { Space::new() } else {
              let v149_6: Path = concat_path(&(v146_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v149_11: Space = routine_21(c, &(v149_6), &v132_24_cursor, &(*s1));
              drop(v149_6);
              compose(&(v147_10),&(v149_11))
            };
            drop(v147_10);
            let v147_13: Space = unite(&(v147_8),&(v147_12));
            join_wrapped_into(&mut v146_7_write,&((v147_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v146_7_write);
          compose(&(v145_5),&(v146_7))
        };
        drop(v145_5);
        let v145_9: Space = intersect(&(*CONSTANT_2),&(v145_2));
        drop(v145_2);
        let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
        drop(v145_9);
        let v145_12: Space = if (&(v145_10)).is_empty() { Space::new() } else {
          let v150_6: Path = concat_path(&(v144_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v150_11 = Space::new();
          let mut v150_11_write = v150_11.write_zipper();
          for v150_11_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v150_11_byte);
            {
            let v151_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v151_3: Space = intersect(&(*CONSTANT_2),&(v151_2));
            let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
            drop(v151_3);
            let v151_5: Space = subtract(&(*CONSTANT_1),&(v151_4));
            drop(v151_4);
            let v151_7: Space = if (&(v151_5)).is_empty() { Space::new() } else {
              let v152_6: Space = routine_4(c, &v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)], &(v150_6), &v132_24_cursor, &(*s1));
              compose(&(v151_5),&(v152_6))
            };
            drop(v151_5);
            let v151_8: Space = intersect(&(*CONSTANT_2),&(v151_2));
            drop(v151_2);
            let v151_9: Space = if has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
            drop(v151_8);
            let v151_11: Space = if (&(v151_9)).is_empty() { Space::new() } else {
              let v153_10: Space = routine_5(c, &v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)], &(v150_6), &v132_24_cursor, &(*s1));
              compose(&(v151_9),&(v153_10))
            };
            drop(v151_9);
            let v151_12: Space = unite(&(v151_7),&(v151_11));
            join_wrapped_into(&mut v150_11_write,&((v151_12).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v150_11_write);
          drop(v150_6);
          compose(&(v145_10),&(v150_11))
        };
        drop(v145_10);
        let v145_13: Space = unite(&(v145_8),&(v145_12));
        join_wrapped_into(&mut v144_11_write,&((v145_13).read_zipper()),&[]);
        }
        v132_24_cursor.ascend(1);
      }
      drop(v144_11_write);
      drop(v144_6);
      compose(&(v133_10),&(v144_11))
    };
    drop(v133_10);
    let v133_13: Space = unite(&(v133_8),&(v133_12));
    join_wrapped_into(&mut v132_24_write,&((v133_13).read_zipper()),&[]);
    }
    v132_24_cursor.ascend(1);
  }
  drop(v132_24_cursor);
  drop(v132_24_write);
  (v132_24).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v154_24 = Space::new();
  let mut v154_24_write = v154_24.write_zipper();
  let mut v154_24_cursor = (*s0).read_zipper();
  let v154_24_origin = v154_24_cursor.path().len();
  for v154_24_byte in v154_24_cursor.child_mask().iter() {
    v154_24_cursor.descend_to_existing_byte(v154_24_byte);
    {
    let v155_2: Space = singleton(&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
    let v155_3: Space = intersect(&(*CONSTANT_2),&(v155_2));
    let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
    drop(v155_3);
    let v155_5: Space = subtract(&(*CONSTANT_1),&(v155_4));
    drop(v155_4);
    let v155_8: Space = if (&(v155_5)).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
      let mut v156_7 = Space::new();
      let mut v156_7_write = v156_7.write_zipper();
      for v156_7_byte in v154_24_cursor.child_mask().iter() {
        v154_24_cursor.descend_to_existing_byte(v156_7_byte);
        {
        let v157_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
        let v157_3: Space = intersect(&(*CONSTANT_2),&(v157_2));
        let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = subtract(&(*CONSTANT_1),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (&(v157_5)).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
          let mut v158_7 = Space::new();
          let mut v158_7_write = v158_7.write_zipper();
          for v158_7_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v158_7_byte);
            {
            let v159_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v159_3: Space = intersect(&(*CONSTANT_2),&(v159_2));
            let v159_4: Space = if has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
            drop(v159_3);
            let v159_5: Space = subtract(&(*CONSTANT_1),&(v159_4));
            drop(v159_4);
            let v159_8: Space = if (&(v159_5)).is_empty() { Space::new() } else {
              let v160_6: Path = concat_path(&(v158_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v160_7: Space = routine_20(c, &(v160_6), &v154_24_cursor, &(*s1));
              compose(&(v159_5),&(v160_7))
            };
            drop(v159_5);
            let v159_9: Space = intersect(&(*CONSTANT_2),&(v159_2));
            drop(v159_2);
            let v159_10: Space = if has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
            drop(v159_9);
            let v159_12: Space = if (&(v159_10)).is_empty() { Space::new() } else {
              let v161_6: Path = concat_path(&(v158_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v161_11: Space = routine_21(c, &(v161_6), &v154_24_cursor, &(*s1));
              drop(v161_6);
              compose(&(v159_10),&(v161_11))
            };
            drop(v159_10);
            let v159_13: Space = unite(&(v159_8),&(v159_12));
            join_wrapped_into(&mut v158_7_write,&((v159_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v158_7_write);
          compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = intersect(&(*CONSTANT_2),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (&(v157_10)).is_empty() { Space::new() } else {
          let v162_6: Path = concat_path(&(v156_6),&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
          let mut v162_11 = Space::new();
          let mut v162_11_write = v162_11.write_zipper();
          for v162_11_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v162_11_byte);
            {
            let v163_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v163_3: Space = intersect(&(*CONSTANT_2),&(v163_2));
            let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
            drop(v163_3);
            let v163_5: Space = subtract(&(*CONSTANT_1),&(v163_4));
            drop(v163_4);
            let v163_8: Space = if (&(v163_5)).is_empty() { Space::new() } else {
              let v164_6: Path = concat_path(&(v162_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v164_7: Space = routine_20(c, &(v164_6), &v154_24_cursor, &(*s1));
              compose(&(v163_5),&(v164_7))
            };
            drop(v163_5);
            let v163_9: Space = intersect(&(*CONSTANT_2),&(v163_2));
            drop(v163_2);
            let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
            drop(v163_9);
            let v163_12: Space = if (&(v163_10)).is_empty() { Space::new() } else {
              let v165_6: Path = concat_path(&(v162_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v165_11: Space = routine_3(c, &(v165_6), &v154_24_cursor, &(*s1));
              drop(v165_6);
              compose(&(v163_10),&(v165_11))
            };
            drop(v163_10);
            let v163_13: Space = unite(&(v163_8),&(v163_12));
            join_wrapped_into(&mut v162_11_write,&((v163_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v162_11_write);
          drop(v162_6);
          compose(&(v157_10),&(v162_11))
        };
        drop(v157_10);
        let v157_13: Space = unite(&(v157_8),&(v157_12));
        join_wrapped_into(&mut v156_7_write,&((v157_13).read_zipper()),&[]);
        }
        v154_24_cursor.ascend(1);
      }
      drop(v156_7_write);
      compose(&(v155_5),&(v156_7))
    };
    drop(v155_5);
    let v155_9: Space = intersect(&(*CONSTANT_2),&(v155_2));
    drop(v155_2);
    let v155_10: Space = if has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
    drop(v155_9);
    let v155_12: Space = if (&(v155_10)).is_empty() { Space::new() } else {
      let v166_6: Path = concat_path(&(*p0),&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
      let mut v166_11 = Space::new();
      let mut v166_11_write = v166_11.write_zipper();
      for v166_11_byte in v154_24_cursor.child_mask().iter() {
        v154_24_cursor.descend_to_existing_byte(v166_11_byte);
        {
        let v167_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
        let v167_3: Space = intersect(&(*CONSTANT_2),&(v167_2));
        let v167_4: Space = if has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
        drop(v167_3);
        let v167_5: Space = subtract(&(*CONSTANT_1),&(v167_4));
        drop(v167_4);
        let v167_7: Space = if (&(v167_5)).is_empty() { Space::new() } else {
          let mut v168_6 = Space::new();
          let mut v168_6_write = v168_6.write_zipper();
          for v168_6_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v168_6_byte);
            {
            let v169_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v169_3: Space = intersect(&(*CONSTANT_2),&(v169_2));
            let v169_4: Space = if has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
            drop(v169_3);
            let v169_5: Space = subtract(&(*CONSTANT_1),&(v169_4));
            drop(v169_4);
            let v169_8: Space = if (&(v169_5)).is_empty() { Space::new() } else {
              let v170_7: Space = routine_8(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              compose(&(v169_5),&(v170_7))
            };
            drop(v169_5);
            let v169_9: Space = intersect(&(*CONSTANT_2),&(v169_2));
            drop(v169_2);
            let v169_10: Space = if has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
            drop(v169_9);
            let v169_12: Space = if (&(v169_10)).is_empty() { Space::new() } else {
              let v171_11: Space = routine_9(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              compose(&(v169_10),&(v171_11))
            };
            drop(v169_10);
            let v169_13: Space = unite(&(v169_8),&(v169_12));
            join_wrapped_into(&mut v168_6_write,&((v169_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v168_6_write);
          compose(&(v167_5),&(v168_6))
        };
        drop(v167_5);
        let v167_8: Space = intersect(&(*CONSTANT_2),&(v167_2));
        drop(v167_2);
        let v167_9: Space = if has_head(&(v167_8)) { singleton(&[]) } else { Space::new() };
        drop(v167_8);
        let v167_11: Space = if (&(v167_9)).is_empty() { Space::new() } else {
          let mut v172_10 = Space::new();
          let mut v172_10_write = v172_10.write_zipper();
          for v172_10_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v172_10_byte);
            {
            let v173_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v173_3: Space = intersect(&(*CONSTANT_2),&(v173_2));
            let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
            drop(v173_3);
            let v173_5: Space = subtract(&(*CONSTANT_1),&(v173_4));
            drop(v173_4);
            let v173_8: Space = if (&(v173_5)).is_empty() { Space::new() } else {
              let v174_7: Space = routine_8(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              compose(&(v173_5),&(v174_7))
            };
            drop(v173_5);
            let v173_9: Space = intersect(&(*CONSTANT_2),&(v173_2));
            drop(v173_2);
            let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
            drop(v173_9);
            let v173_12: Space = if (&(v173_10)).is_empty() { Space::new() } else {
              let v175_11: Space = routine_10(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              compose(&(v173_10),&(v175_11))
            };
            drop(v173_10);
            let v173_13: Space = unite(&(v173_8),&(v173_12));
            join_wrapped_into(&mut v172_10_write,&((v173_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v172_10_write);
          compose(&(v167_9),&(v172_10))
        };
        drop(v167_9);
        let v167_12: Space = unite(&(v167_7),&(v167_11));
        join_wrapped_into(&mut v166_11_write,&((v167_12).read_zipper()),&[]);
        }
        v154_24_cursor.ascend(1);
      }
      drop(v166_11_write);
      drop(v166_6);
      compose(&(v155_10),&(v166_11))
    };
    drop(v155_10);
    let v155_13: Space = unite(&(v155_8),&(v155_12));
    join_wrapped_into(&mut v154_24_write,&((v155_13).read_zipper()),&[]);
    }
    v154_24_cursor.ascend(1);
  }
  drop(v154_24_cursor);
  drop(v154_24_write);
  (v154_24).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v176_28 = Space::new();
  let mut v176_28_write = v176_28.write_zipper();
  let mut v176_28_cursor = (*s0).read_zipper();
  let v176_28_origin = v176_28_cursor.path().len();
  for v176_28_byte in v176_28_cursor.child_mask().iter() {
    v176_28_cursor.descend_to_existing_byte(v176_28_byte);
    {
    let v177_2: Space = singleton(&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
    let v177_3: Space = intersect(&(*CONSTANT_2),&(v177_2));
    let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
    drop(v177_3);
    let v177_5: Space = subtract(&(*CONSTANT_1),&(v177_4));
    drop(v177_4);
    let v177_8: Space = if (&(v177_5)).is_empty() { Space::new() } else {
      let v178_6: Path = concat_path(&(*p0),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
      let mut v178_7 = Space::new();
      let mut v178_7_write = v178_7.write_zipper();
      for v178_7_byte in v176_28_cursor.child_mask().iter() {
        v176_28_cursor.descend_to_existing_byte(v178_7_byte);
        {
        let v179_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
        let v179_3: Space = intersect(&(*CONSTANT_2),&(v179_2));
        let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
        drop(v179_3);
        let v179_5: Space = subtract(&(*CONSTANT_1),&(v179_4));
        drop(v179_4);
        let v179_8: Space = if (&(v179_5)).is_empty() { Space::new() } else {
          let v180_6: Path = concat_path(&(v178_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v180_7 = Space::new();
          let mut v180_7_write = v180_7.write_zipper();
          for v180_7_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v180_7_byte);
            {
            let v181_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v181_3: Space = intersect(&(*CONSTANT_2),&(v181_2));
            let v181_4: Space = if has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
            drop(v181_3);
            let v181_5: Space = subtract(&(*CONSTANT_1),&(v181_4));
            drop(v181_4);
            let v181_8: Space = if (&(v181_5)).is_empty() { Space::new() } else {
              let v182_6: Path = concat_path(&(v180_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v182_7: Space = routine_22(c, &(v182_6), &(*p1), &v176_28_cursor, &(*s1));
              compose(&(v181_5),&(v182_7))
            };
            drop(v181_5);
            let v181_9: Space = intersect(&(*CONSTANT_2),&(v181_2));
            drop(v181_2);
            let v181_10: Space = if has_head(&(v181_9)) { singleton(&[]) } else { Space::new() };
            drop(v181_9);
            let v181_12: Space = if (&(v181_10)).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v180_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v183_11: Space = routine_23(c, &(v183_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v183_6);
              compose(&(v181_10),&(v183_11))
            };
            drop(v181_10);
            let v181_13: Space = unite(&(v181_8),&(v181_12));
            join_wrapped_into(&mut v180_7_write,&((v181_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v180_7_write);
          compose(&(v179_5),&(v180_7))
        };
        drop(v179_5);
        let v179_9: Space = intersect(&(*CONSTANT_2),&(v179_2));
        drop(v179_2);
        let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
        drop(v179_9);
        let v179_12: Space = if (&(v179_10)).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v178_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v184_11 = Space::new();
          let mut v184_11_write = v184_11.write_zipper();
          for v184_11_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v184_11_byte);
            {
            let v185_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v185_3: Space = intersect(&(*CONSTANT_2),&(v185_2));
            let v185_4: Space = if has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
            drop(v185_3);
            let v185_5: Space = subtract(&(*CONSTANT_1),&(v185_4));
            drop(v185_4);
            let v185_8: Space = if (&(v185_5)).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v184_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v186_7: Space = routine_22(c, &(v186_6), &(*p1), &v176_28_cursor, &(*s1));
              compose(&(v185_5),&(v186_7))
            };
            drop(v185_5);
            let v185_9: Space = intersect(&(*CONSTANT_2),&(v185_2));
            drop(v185_2);
            let v185_10: Space = if has_head(&(v185_9)) { singleton(&[]) } else { Space::new() };
            drop(v185_9);
            let v185_12: Space = if (&(v185_10)).is_empty() { Space::new() } else {
              let v187_6: Path = concat_path(&(v184_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v187_11: Space = routine_10(c, &(v187_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v187_6);
              compose(&(v185_10),&(v187_11))
            };
            drop(v185_10);
            let v185_13: Space = unite(&(v185_8),&(v185_12));
            join_wrapped_into(&mut v184_11_write,&((v185_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v184_11_write);
          drop(v184_6);
          compose(&(v179_10),&(v184_11))
        };
        drop(v179_10);
        let v179_13: Space = unite(&(v179_8),&(v179_12));
        join_wrapped_into(&mut v178_7_write,&((v179_13).read_zipper()),&[]);
        }
        v176_28_cursor.ascend(1);
      }
      drop(v178_7_write);
      compose(&(v177_5),&(v178_7))
    };
    drop(v177_5);
    let v177_9: Space = intersect(&(*CONSTANT_2),&(v177_2));
    drop(v177_2);
    let v177_10: Space = if has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
    drop(v177_9);
    let v177_13: Space = if (&(v177_10)).is_empty() { Space::new() } else {
      let v188_6: Path = concat_path(&(*p0),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
      let mut v188_12 = Space::new();
      let mut v188_12_write = v188_12.write_zipper();
      for v188_12_byte in v176_28_cursor.child_mask().iter() {
        v176_28_cursor.descend_to_existing_byte(v188_12_byte);
        {
        let v189_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
        let v189_3: Space = intersect(&(*CONSTANT_2),&(v189_2));
        let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
        drop(v189_3);
        let v189_5: Space = subtract(&(*CONSTANT_1),&(v189_4));
        drop(v189_4);
        let v189_8: Space = if (&(v189_5)).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v188_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v190_7 = Space::new();
          let mut v190_7_write = v190_7.write_zipper();
          for v190_7_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v190_7_byte);
            {
            let v191_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v191_3: Space = intersect(&(*CONSTANT_2),&(v191_2));
            let v191_4: Space = if has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
            drop(v191_3);
            let v191_5: Space = subtract(&(*CONSTANT_1),&(v191_4));
            drop(v191_4);
            let v191_8: Space = if (&(v191_5)).is_empty() { Space::new() } else {
              let v192_6: Path = concat_path(&(v190_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v192_7: Space = routine_22(c, &(v192_6), &(*p1), &v176_28_cursor, &(*s1));
              compose(&(v191_5),&(v192_7))
            };
            drop(v191_5);
            let v191_9: Space = intersect(&(*CONSTANT_2),&(v191_2));
            drop(v191_2);
            let v191_10: Space = if has_head(&(v191_9)) { singleton(&[]) } else { Space::new() };
            drop(v191_9);
            let v191_12: Space = if (&(v191_10)).is_empty() { Space::new() } else {
              let v193_6: Path = concat_path(&(v190_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v193_11: Space = routine_23(c, &(v193_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v193_6);
              compose(&(v191_10),&(v193_11))
            };
            drop(v191_10);
            let v191_13: Space = unite(&(v191_8),&(v191_12));
            join_wrapped_into(&mut v190_7_write,&((v191_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v190_7_write);
          drop(v190_6);
          compose(&(v189_5),&(v190_7))
        };
        drop(v189_5);
        let v189_9: Space = intersect(&(*CONSTANT_2),&(v189_2));
        drop(v189_2);
        let v189_10: Space = if has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
        drop(v189_9);
        let v189_13: Space = if (&(v189_10)).is_empty() { Space::new() } else {
          let mut v194_12 = Space::new();
          let mut v194_12_write = v194_12.write_zipper();
          let mut v194_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let v194_12_origin = v194_12_cursor.path().len();
          for v194_12_byte in v194_12_cursor.child_mask().iter() {
            v194_12_cursor.descend_to_existing_byte(v194_12_byte);
            {
            let v195_2: Space = singleton(&v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)]);
            let v195_3: Space = intersect(&(*CONSTANT_2),&(v195_2));
            let v195_4: Space = if has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
            drop(v195_3);
            let v195_5: Space = subtract(&(*CONSTANT_1),&(v195_4));
            drop(v195_4);
            let v195_7: Space = if (&(v195_5)).is_empty() { Space::new() } else {
              let v196_6: Space = routine_13(c, &v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)], &(*p1), &v194_12_cursor);
              compose(&(v195_5),&(v196_6))
            };
            drop(v195_5);
            let v195_8: Space = intersect(&(*CONSTANT_2),&(v195_2));
            drop(v195_2);
            let v195_9: Space = if has_head(&(v195_8)) { singleton(&[]) } else { Space::new() };
            drop(v195_8);
            let v195_11: Space = if (&(v195_9)).is_empty() { Space::new() } else {
              let v197_10: Space = routine_14(c, &v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)], &(*p1), &v194_12_cursor);
              compose(&(v195_9),&(v197_10))
            };
            drop(v195_9);
            let v195_12: Space = unite(&(v195_7),&(v195_11));
            join_wrapped_into(&mut v194_12_write,&((v195_12).read_zipper()),&[]);
            }
            v194_12_cursor.ascend(1);
          }
          drop(v194_12_cursor);
          drop(v194_12_write);
          compose(&(v189_10),&(v194_12))
        };
        drop(v189_10);
        let v189_14: Space = unite(&(v189_8),&(v189_13));
        join_wrapped_into(&mut v188_12_write,&((v189_14).read_zipper()),&[]);
        }
        v176_28_cursor.ascend(1);
      }
      drop(v188_12_write);
      drop(v188_6);
      compose(&(v177_10),&(v188_12))
    };
    drop(v177_10);
    let v177_14: Space = unite(&(v177_8),&(v177_13));
    join_wrapped_into(&mut v176_28_write,&((v177_14).read_zipper()),&[]);
    }
    v176_28_cursor.ascend(1);
  }
  drop(v176_28_cursor);
  drop(v176_28_write);
  (v176_28).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v198_28 = Space::new();
  let mut v198_28_write = v198_28.write_zipper();
  let mut v198_28_cursor = (*s0).read_zipper();
  let v198_28_origin = v198_28_cursor.path().len();
  for v198_28_byte in v198_28_cursor.child_mask().iter() {
    v198_28_cursor.descend_to_existing_byte(v198_28_byte);
    {
    let v199_2: Space = singleton(&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
    let v199_3: Space = intersect(&(*CONSTANT_2),&(v199_2));
    let v199_4: Space = if has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
    drop(v199_3);
    let v199_5: Space = subtract(&(*CONSTANT_1),&(v199_4));
    drop(v199_4);
    let v199_8: Space = if (&(v199_5)).is_empty() { Space::new() } else {
      let v200_6: Path = concat_path(&(*p0),&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
      let mut v200_7 = Space::new();
      let mut v200_7_write = v200_7.write_zipper();
      for v200_7_byte in v198_28_cursor.child_mask().iter() {
        v198_28_cursor.descend_to_existing_byte(v200_7_byte);
        {
        let v201_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
        let v201_3: Space = intersect(&(*CONSTANT_2),&(v201_2));
        let v201_4: Space = if has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
        drop(v201_3);
        let v201_5: Space = subtract(&(*CONSTANT_1),&(v201_4));
        drop(v201_4);
        let v201_8: Space = if (&(v201_5)).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v200_6),&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
          let mut v202_7 = Space::new();
          let mut v202_7_write = v202_7.write_zipper();
          for v202_7_byte in v198_28_cursor.child_mask().iter() {
            v198_28_cursor.descend_to_existing_byte(v202_7_byte);
            {
            let v203_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
            let v203_3: Space = intersect(&(*CONSTANT_2),&(v203_2));
            let v203_4: Space = if has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
            drop(v203_3);
            let v203_5: Space = subtract(&(*CONSTANT_1),&(v203_4));
            drop(v203_4);
            let v203_8: Space = if (&(v203_5)).is_empty() { Space::new() } else {
              let v204_6: Path = concat_path(&(v202_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v204_7: Space = routine_22(c, &(v204_6), &(*p1), &v198_28_cursor, &(*s1));
              compose(&(v203_5),&(v204_7))
            };
            drop(v203_5);
            let v203_9: Space = intersect(&(*CONSTANT_2),&(v203_2));
            drop(v203_2);
            let v203_10: Space = if has_head(&(v203_9)) { singleton(&[]) } else { Space::new() };
            drop(v203_9);
            let v203_12: Space = if (&(v203_10)).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v202_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v205_11: Space = routine_23(c, &(v205_6), &(*p1), &v198_28_cursor, &(*s1));
              drop(v205_6);
              compose(&(v203_10),&(v205_11))
            };
            drop(v203_10);
            let v203_13: Space = unite(&(v203_8),&(v203_12));
            join_wrapped_into(&mut v202_7_write,&((v203_13).read_zipper()),&[]);
            }
            v198_28_cursor.ascend(1);
          }
          drop(v202_7_write);
          compose(&(v201_5),&(v202_7))
        };
        drop(v201_5);
        let v201_9: Space = intersect(&(*CONSTANT_2),&(v201_2));
        drop(v201_2);
        let v201_10: Space = if has_head(&(v201_9)) { singleton(&[]) } else { Space::new() };
        drop(v201_9);
        let v201_12: Space = if (&(v201_10)).is_empty() { Space::new() } else {
          let v206_6: Path = concat_path(&(v200_6),&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
          let mut v206_11 = Space::new();
          let mut v206_11_write = v206_11.write_zipper();
          for v206_11_byte in v198_28_cursor.child_mask().iter() {
            v198_28_cursor.descend_to_existing_byte(v206_11_byte);
            {
            let v207_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
            let v207_3: Space = intersect(&(*CONSTANT_2),&(v207_2));
            let v207_4: Space = if has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
            drop(v207_3);
            let v207_5: Space = subtract(&(*CONSTANT_1),&(v207_4));
            drop(v207_4);
            let v207_8: Space = if (&(v207_5)).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v206_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v208_7: Space = routine_22(c, &(v208_6), &(*p1), &v198_28_cursor, &(*s1));
              compose(&(v207_5),&(v208_7))
            };
            drop(v207_5);
            let v207_9: Space = intersect(&(*CONSTANT_2),&(v207_2));
            drop(v207_2);
            let v207_10: Space = if has_head(&(v207_9)) { singleton(&[]) } else { Space::new() };
            drop(v207_9);
            let v207_12: Space = if (&(v207_10)).is_empty() { Space::new() } else {
              let v209_6: Path = concat_path(&(v206_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v209_11: Space = routine_10(c, &(v209_6), &(*p1), &v198_28_cursor, &(*s1));
              drop(v209_6);
              compose(&(v207_10),&(v209_11))
            };
            drop(v207_10);
            let v207_13: Space = unite(&(v207_8),&(v207_12));
            join_wrapped_into(&mut v206_11_write,&((v207_13).read_zipper()),&[]);
            }
            v198_28_cursor.ascend(1);
          }
          drop(v206_11_write);
          drop(v206_6);
          compose(&(v201_10),&(v206_11))
        };
        drop(v201_10);
        let v201_13: Space = unite(&(v201_8),&(v201_12));
        join_wrapped_into(&mut v200_7_write,&((v201_13).read_zipper()),&[]);
        }
        v198_28_cursor.ascend(1);
      }
      drop(v200_7_write);
      drop(v200_6);
      compose(&(v199_5),&(v200_7))
    };
    drop(v199_5);
    let v199_9: Space = intersect(&(*CONSTANT_2),&(v199_2));
    drop(v199_2);
    let v199_10: Space = if has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
    drop(v199_9);
    let v199_13: Space = if (&(v199_10)).is_empty() { Space::new() } else {
      let mut v210_12 = Space::new();
      let mut v210_12_write = v210_12.write_zipper();
      let mut v210_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
      let v210_12_origin = v210_12_cursor.path().len();
      for v210_12_byte in v210_12_cursor.child_mask().iter() {
        v210_12_cursor.descend_to_existing_byte(v210_12_byte);
        {
        let v211_2: Space = singleton(&v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 1)]);
        let v211_3: Space = intersect(&(*CONSTANT_2),&(v211_2));
        let v211_4: Space = if has_head(&(v211_3)) { singleton(&[]) } else { Space::new() };
        drop(v211_3);
        let v211_5: Space = subtract(&(*CONSTANT_1),&(v211_4));
        drop(v211_4);
        let v211_7: Space = if (&(v211_5)).is_empty() { Space::new() } else {
          let mut v212_6 = Space::new();
          let mut v212_6_write = v212_6.write_zipper();
          for v212_6_byte in v210_12_cursor.child_mask().iter() {
            v210_12_cursor.descend_to_existing_byte(v212_6_byte);
            {
            let v213_2: Space = singleton(&v210_12_cursor.path()[(v210_12_origin + 1)..(v210_12_origin + 2)]);
            let v213_3: Space = intersect(&(*CONSTANT_2),&(v213_2));
            let v213_4: Space = if has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
            drop(v213_3);
            let v213_5: Space = subtract(&(*CONSTANT_1),&(v213_4));
            drop(v213_4);
            let v213_8: Space = if (&(v213_5)).is_empty() { Space::new() } else {
              let v214_7: Space = routine_17(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              compose(&(v213_5),&(v214_7))
            };
            drop(v213_5);
            let v213_9: Space = intersect(&(*CONSTANT_2),&(v213_2));
            drop(v213_2);
            let v213_10: Space = if has_head(&(v213_9)) { singleton(&[]) } else { Space::new() };
            drop(v213_9);
            let v213_12: Space = if (&(v213_10)).is_empty() { Space::new() } else {
              let v215_11: Space = routine_18(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              compose(&(v213_10),&(v215_11))
            };
            drop(v213_10);
            let v213_13: Space = unite(&(v213_8),&(v213_12));
            join_wrapped_into(&mut v212_6_write,&((v213_13).read_zipper()),&[]);
            }
            v210_12_cursor.ascend(1);
          }
          drop(v212_6_write);
          compose(&(v211_5),&(v212_6))
        };
        drop(v211_5);
        let v211_8: Space = intersect(&(*CONSTANT_2),&(v211_2));
        drop(v211_2);
        let v211_9: Space = if has_head(&(v211_8)) { singleton(&[]) } else { Space::new() };
        drop(v211_8);
        let v211_11: Space = if (&(v211_9)).is_empty() { Space::new() } else {
          let mut v216_10 = Space::new();
          let mut v216_10_write = v216_10.write_zipper();
          for v216_10_byte in v210_12_cursor.child_mask().iter() {
            v210_12_cursor.descend_to_existing_byte(v216_10_byte);
            {
            let v217_2: Space = singleton(&v210_12_cursor.path()[(v210_12_origin + 1)..(v210_12_origin + 2)]);
            let v217_3: Space = intersect(&(*CONSTANT_2),&(v217_2));
            let v217_4: Space = if has_head(&(v217_3)) { singleton(&[]) } else { Space::new() };
            drop(v217_3);
            let v217_5: Space = subtract(&(*CONSTANT_1),&(v217_4));
            drop(v217_4);
            let v217_8: Space = if (&(v217_5)).is_empty() { Space::new() } else {
              let v218_7: Space = routine_17(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              compose(&(v217_5),&(v218_7))
            };
            drop(v217_5);
            let v217_9: Space = intersect(&(*CONSTANT_2),&(v217_2));
            drop(v217_2);
            let v217_10: Space = if has_head(&(v217_9)) { singleton(&[]) } else { Space::new() };
            drop(v217_9);
            let v217_12: Space = if (&(v217_10)).is_empty() { Space::new() } else {
              let v219_11: Space = routine_19(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              compose(&(v217_10),&(v219_11))
            };
            drop(v217_10);
            let v217_13: Space = unite(&(v217_8),&(v217_12));
            join_wrapped_into(&mut v216_10_write,&((v217_13).read_zipper()),&[]);
            }
            v210_12_cursor.ascend(1);
          }
          drop(v216_10_write);
          compose(&(v211_9),&(v216_10))
        };
        drop(v211_9);
        let v211_12: Space = unite(&(v211_7),&(v211_11));
        join_wrapped_into(&mut v210_12_write,&((v211_12).read_zipper()),&[]);
        }
        v210_12_cursor.ascend(1);
      }
      drop(v210_12_cursor);
      drop(v210_12_write);
      compose(&(v199_10),&(v210_12))
    };
    drop(v199_10);
    let v199_14: Space = unite(&(v199_8),&(v199_13));
    join_wrapped_into(&mut v198_28_write,&((v199_14).read_zipper()),&[]);
    }
    v198_28_cursor.ascend(1);
  }
  drop(v198_28_cursor);
  drop(v198_28_write);
  (v198_28).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v220_25 = Space::new();
  let mut v220_25_write = v220_25.write_zipper();
  let mut v220_25_cursor = descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0));
  let v220_25_origin = v220_25_cursor.path().len();
  for v220_25_byte in v220_25_cursor.child_mask().iter() {
    v220_25_cursor.descend_to_existing_byte(v220_25_byte);
    {
    let v221_2: Space = singleton(&v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 1)]);
    let v221_3: Space = intersect(&(*CONSTANT_2),&(v221_2));
    let v221_4: Space = if has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
    drop(v221_3);
    let v221_5: Space = subtract(&(*CONSTANT_1),&(v221_4));
    drop(v221_4);
    let v221_7: Space = if (&(v221_5)).is_empty() { Space::new() } else {
      let mut v222_6 = Space::new();
      let mut v222_6_write = v222_6.write_zipper();
      for v222_6_byte in v220_25_cursor.child_mask().iter() {
        v220_25_cursor.descend_to_existing_byte(v222_6_byte);
        {
        let v223_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 1)..(v220_25_origin + 2)]);
        let v223_3: Space = intersect(&(*CONSTANT_2),&(v223_2));
        let v223_4: Space = if has_head(&(v223_3)) { singleton(&[]) } else { Space::new() };
        drop(v223_3);
        let v223_5: Space = subtract(&(*CONSTANT_1),&(v223_4));
        drop(v223_4);
        let v223_8: Space = if (&(v223_5)).is_empty() { Space::new() } else {
          let mut v224_7 = Space::new();
          let mut v224_7_write = v224_7.write_zipper();
          for v224_7_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v224_7_byte);
            {
            let v225_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v225_3: Space = intersect(&(*CONSTANT_2),&(v225_2));
            let v225_4: Space = if has_head(&(v225_3)) { singleton(&[]) } else { Space::new() };
            drop(v225_3);
            let v225_5: Space = subtract(&(*CONSTANT_1),&(v225_4));
            drop(v225_4);
            let v225_8: Space = if (&(v225_5)).is_empty() { Space::new() } else {
              let v226_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v225_5),&(v226_7))
            };
            drop(v225_5);
            let v225_9: Space = intersect(&(*CONSTANT_2),&(v225_2));
            drop(v225_2);
            let v225_10: Space = if has_head(&(v225_9)) { singleton(&[]) } else { Space::new() };
            drop(v225_9);
            let v225_12: Space = if (&(v225_10)).is_empty() { Space::new() } else {
              let v227_11: Space = routine_25(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v225_10),&(v227_11))
            };
            drop(v225_10);
            let v225_13: Space = unite(&(v225_8),&(v225_12));
            join_wrapped_into(&mut v224_7_write,&((v225_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v224_7_write);
          compose(&(v223_5),&(v224_7))
        };
        drop(v223_5);
        let v223_9: Space = intersect(&(*CONSTANT_2),&(v223_2));
        drop(v223_2);
        let v223_10: Space = if has_head(&(v223_9)) { singleton(&[]) } else { Space::new() };
        drop(v223_9);
        let v223_12: Space = if (&(v223_10)).is_empty() { Space::new() } else {
          let mut v228_11 = Space::new();
          let mut v228_11_write = v228_11.write_zipper();
          for v228_11_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v228_11_byte);
            {
            let v229_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v229_3: Space = intersect(&(*CONSTANT_2),&(v229_2));
            let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
            drop(v229_3);
            let v229_5: Space = subtract(&(*CONSTANT_1),&(v229_4));
            drop(v229_4);
            let v229_8: Space = if (&(v229_5)).is_empty() { Space::new() } else {
              let v230_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v229_5),&(v230_7))
            };
            drop(v229_5);
            let v229_9: Space = intersect(&(*CONSTANT_2),&(v229_2));
            drop(v229_2);
            let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
            drop(v229_9);
            let v229_12: Space = if (&(v229_10)).is_empty() { Space::new() } else {
              let v231_11: Space = routine_19(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v229_10),&(v231_11))
            };
            drop(v229_10);
            let v229_13: Space = unite(&(v229_8),&(v229_12));
            join_wrapped_into(&mut v228_11_write,&((v229_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v228_11_write);
          compose(&(v223_10),&(v228_11))
        };
        drop(v223_10);
        let v223_13: Space = unite(&(v223_8),&(v223_12));
        join_wrapped_into(&mut v222_6_write,&((v223_13).read_zipper()),&[]);
        }
        v220_25_cursor.ascend(1);
      }
      drop(v222_6_write);
      compose(&(v221_5),&(v222_6))
    };
    drop(v221_5);
    let v221_8: Space = intersect(&(*CONSTANT_2),&(v221_2));
    drop(v221_2);
    let v221_9: Space = if has_head(&(v221_8)) { singleton(&[]) } else { Space::new() };
    drop(v221_8);
    let v221_11: Space = if (&(v221_9)).is_empty() { Space::new() } else {
      let mut v232_10 = Space::new();
      let mut v232_10_write = v232_10.write_zipper();
      for v232_10_byte in v220_25_cursor.child_mask().iter() {
        v220_25_cursor.descend_to_existing_byte(v232_10_byte);
        {
        let v233_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 1)..(v220_25_origin + 2)]);
        let v233_3: Space = intersect(&(*CONSTANT_2),&(v233_2));
        let v233_4: Space = if has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
        drop(v233_3);
        let v233_5: Space = subtract(&(*CONSTANT_1),&(v233_4));
        drop(v233_4);
        let v233_8: Space = if (&(v233_5)).is_empty() { Space::new() } else {
          let mut v234_7 = Space::new();
          let mut v234_7_write = v234_7.write_zipper();
          for v234_7_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v234_7_byte);
            {
            let v235_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v235_3: Space = intersect(&(*CONSTANT_2),&(v235_2));
            let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
            drop(v235_3);
            let v235_5: Space = subtract(&(*CONSTANT_1),&(v235_4));
            drop(v235_4);
            let v235_8: Space = if (&(v235_5)).is_empty() { Space::new() } else {
              let v236_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v235_5),&(v236_7))
            };
            drop(v235_5);
            let v235_9: Space = intersect(&(*CONSTANT_2),&(v235_2));
            drop(v235_2);
            let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
            drop(v235_9);
            let v235_12: Space = if (&(v235_10)).is_empty() { Space::new() } else {
              let v237_11: Space = routine_25(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v235_10),&(v237_11))
            };
            drop(v235_10);
            let v235_13: Space = unite(&(v235_8),&(v235_12));
            join_wrapped_into(&mut v234_7_write,&((v235_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v234_7_write);
          compose(&(v233_5),&(v234_7))
        };
        drop(v233_5);
        let v233_9: Space = intersect(&(*CONSTANT_2),&(v233_2));
        drop(v233_2);
        let v233_10: Space = if has_head(&(v233_9)) { singleton(&[]) } else { Space::new() };
        drop(v233_9);
        let v233_11: Space = compose(&(v233_10),&v220_25_cursor);
        drop(v233_10);
        let v233_12: Space = wrap(&(v233_11),&v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 2)]);
        drop(v233_11);
        let v233_13: Space = wrap(&(v233_12),&(*p1));
        drop(v233_12);
        let v233_14: Space = unite(&(v233_8),&(v233_13));
        drop(v233_13);
        join_wrapped_into(&mut v232_10_write,&((v233_14).read_zipper()),&[]);
        }
        v220_25_cursor.ascend(1);
      }
      drop(v232_10_write);
      compose(&(v221_9),&(v232_10))
    };
    drop(v221_9);
    let v221_12: Space = unite(&(v221_7),&(v221_11));
    join_wrapped_into(&mut v220_25_write,&((v221_12).read_zipper()),&[]);
    }
    v220_25_cursor.ascend(1);
  }
  drop(v220_25_cursor);
  drop(v220_25_write);
  (v220_25).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v239_28 = Space::new();
  let mut v239_28_write = v239_28.write_zipper();
  let mut v239_28_cursor = (*s0).read_zipper();
  let v239_28_origin = v239_28_cursor.path().len();
  for v239_28_byte in v239_28_cursor.child_mask().iter() {
    v239_28_cursor.descend_to_existing_byte(v239_28_byte);
    {
    let v240_2: Space = singleton(&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
    let v240_3: Space = intersect(&(*CONSTANT_2),&(v240_2));
    let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
    drop(v240_3);
    let v240_5: Space = subtract(&(*CONSTANT_1),&(v240_4));
    drop(v240_4);
    let v240_8: Space = if (&(v240_5)).is_empty() { Space::new() } else {
      let v241_6: Path = concat_path(&(*p0),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
      let mut v241_7 = Space::new();
      let mut v241_7_write = v241_7.write_zipper();
      for v241_7_byte in v239_28_cursor.child_mask().iter() {
        v239_28_cursor.descend_to_existing_byte(v241_7_byte);
        {
        let v242_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
        let v242_3: Space = intersect(&(*CONSTANT_2),&(v242_2));
        let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = subtract(&(*CONSTANT_1),&(v242_4));
        drop(v242_4);
        let v242_8: Space = if (&(v242_5)).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v241_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v243_7 = Space::new();
          let mut v243_7_write = v243_7.write_zipper();
          for v243_7_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v243_7_byte);
            {
            let v244_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v244_3: Space = intersect(&(*CONSTANT_2),&(v244_2));
            let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = subtract(&(*CONSTANT_1),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (&(v244_5)).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v245_7: Space = routine_26(c, &(v245_6), &(*p1), &v239_28_cursor, &(*s1));
              compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = intersect(&(*CONSTANT_2),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (&(v244_10)).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v246_11: Space = routine_27(c, &(v246_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v246_6);
              compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = unite(&(v244_8),&(v244_12));
            join_wrapped_into(&mut v243_7_write,&((v244_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v243_7_write);
          compose(&(v242_5),&(v243_7))
        };
        drop(v242_5);
        let v242_9: Space = intersect(&(*CONSTANT_2),&(v242_2));
        drop(v242_2);
        let v242_10: Space = if has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
        drop(v242_9);
        let v242_12: Space = if (&(v242_10)).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v241_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v247_11 = Space::new();
          let mut v247_11_write = v247_11.write_zipper();
          for v247_11_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v247_11_byte);
            {
            let v248_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v248_3: Space = intersect(&(*CONSTANT_2),&(v248_2));
            let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = subtract(&(*CONSTANT_1),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (&(v248_5)).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v249_7: Space = routine_26(c, &(v249_6), &(*p1), &v239_28_cursor, &(*s1));
              compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = intersect(&(*CONSTANT_2),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (&(v248_10)).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v250_11: Space = routine_10(c, &(v250_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v250_6);
              compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = unite(&(v248_8),&(v248_12));
            join_wrapped_into(&mut v247_11_write,&((v248_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v247_11_write);
          drop(v247_6);
          compose(&(v242_10),&(v247_11))
        };
        drop(v242_10);
        let v242_13: Space = unite(&(v242_8),&(v242_12));
        join_wrapped_into(&mut v241_7_write,&((v242_13).read_zipper()),&[]);
        }
        v239_28_cursor.ascend(1);
      }
      drop(v241_7_write);
      compose(&(v240_5),&(v241_7))
    };
    drop(v240_5);
    let v240_9: Space = intersect(&(*CONSTANT_2),&(v240_2));
    drop(v240_2);
    let v240_10: Space = if has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
    drop(v240_9);
    let v240_13: Space = if (&(v240_10)).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
      let mut v251_12 = Space::new();
      let mut v251_12_write = v251_12.write_zipper();
      for v251_12_byte in v239_28_cursor.child_mask().iter() {
        v239_28_cursor.descend_to_existing_byte(v251_12_byte);
        {
        let v252_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
        let v252_3: Space = intersect(&(*CONSTANT_2),&(v252_2));
        let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = subtract(&(*CONSTANT_1),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (&(v252_5)).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v253_7 = Space::new();
          let mut v253_7_write = v253_7.write_zipper();
          for v253_7_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v253_7_byte);
            {
            let v254_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v254_3: Space = intersect(&(*CONSTANT_2),&(v254_2));
            let v254_4: Space = if has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
            drop(v254_3);
            let v254_5: Space = subtract(&(*CONSTANT_1),&(v254_4));
            drop(v254_4);
            let v254_8: Space = if (&(v254_5)).is_empty() { Space::new() } else {
              let v255_6: Path = concat_path(&(v253_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v255_7: Space = routine_26(c, &(v255_6), &(*p1), &v239_28_cursor, &(*s1));
              compose(&(v254_5),&(v255_7))
            };
            drop(v254_5);
            let v254_9: Space = intersect(&(*CONSTANT_2),&(v254_2));
            drop(v254_2);
            let v254_10: Space = if has_head(&(v254_9)) { singleton(&[]) } else { Space::new() };
            drop(v254_9);
            let v254_12: Space = if (&(v254_10)).is_empty() { Space::new() } else {
              let v256_6: Path = concat_path(&(v253_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v256_11: Space = routine_27(c, &(v256_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v256_6);
              compose(&(v254_10),&(v256_11))
            };
            drop(v254_10);
            let v254_13: Space = unite(&(v254_8),&(v254_12));
            join_wrapped_into(&mut v253_7_write,&((v254_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v253_7_write);
          drop(v253_6);
          compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = intersect(&(*CONSTANT_2),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_13: Space = if (&(v252_10)).is_empty() { Space::new() } else {
          let mut v257_12 = Space::new();
          let mut v257_12_write = v257_12.write_zipper();
          let mut v257_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let v257_12_origin = v257_12_cursor.path().len();
          for v257_12_byte in v257_12_cursor.child_mask().iter() {
            v257_12_cursor.descend_to_existing_byte(v257_12_byte);
            {
            let v258_2: Space = singleton(&v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)]);
            let v258_3: Space = intersect(&(*CONSTANT_2),&(v258_2));
            let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
            drop(v258_3);
            let v258_5: Space = subtract(&(*CONSTANT_1),&(v258_4));
            drop(v258_4);
            let v258_7: Space = if (&(v258_5)).is_empty() { Space::new() } else {
              let v259_6: Space = routine_13(c, &v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)], &(*p1), &v257_12_cursor);
              compose(&(v258_5),&(v259_6))
            };
            drop(v258_5);
            let v258_8: Space = intersect(&(*CONSTANT_2),&(v258_2));
            drop(v258_2);
            let v258_9: Space = if has_head(&(v258_8)) { singleton(&[]) } else { Space::new() };
            drop(v258_8);
            let v258_11: Space = if (&(v258_9)).is_empty() { Space::new() } else {
              let v260_10: Space = routine_14(c, &v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)], &(*p1), &v257_12_cursor);
              compose(&(v258_9),&(v260_10))
            };
            drop(v258_9);
            let v258_12: Space = unite(&(v258_7),&(v258_11));
            join_wrapped_into(&mut v257_12_write,&((v258_12).read_zipper()),&[]);
            }
            v257_12_cursor.ascend(1);
          }
          drop(v257_12_cursor);
          drop(v257_12_write);
          compose(&(v252_10),&(v257_12))
        };
        drop(v252_10);
        let v252_14: Space = unite(&(v252_8),&(v252_13));
        join_wrapped_into(&mut v251_12_write,&((v252_14).read_zipper()),&[]);
        }
        v239_28_cursor.ascend(1);
      }
      drop(v251_12_write);
      drop(v251_6);
      compose(&(v240_10),&(v251_12))
    };
    drop(v240_10);
    let v240_14: Space = unite(&(v240_8),&(v240_13));
    join_wrapped_into(&mut v239_28_write,&((v240_14).read_zipper()),&[]);
    }
    v239_28_cursor.ascend(1);
  }
  drop(v239_28_cursor);
  drop(v239_28_write);
  (v239_28).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v261_28 = Space::new();
  let mut v261_28_write = v261_28.write_zipper();
  let mut v261_28_cursor = (*s0).read_zipper();
  let v261_28_origin = v261_28_cursor.path().len();
  for v261_28_byte in v261_28_cursor.child_mask().iter() {
    v261_28_cursor.descend_to_existing_byte(v261_28_byte);
    {
    let v262_2: Space = singleton(&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
    let v262_3: Space = intersect(&(*CONSTANT_2),&(v262_2));
    let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
    drop(v262_3);
    let v262_5: Space = subtract(&(*CONSTANT_1),&(v262_4));
    drop(v262_4);
    let v262_8: Space = if (&(v262_5)).is_empty() { Space::new() } else {
      let v263_6: Path = concat_path(&(*p0),&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
      let mut v263_7 = Space::new();
      let mut v263_7_write = v263_7.write_zipper();
      for v263_7_byte in v261_28_cursor.child_mask().iter() {
        v261_28_cursor.descend_to_existing_byte(v263_7_byte);
        {
        let v264_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
        let v264_3: Space = intersect(&(*CONSTANT_2),&(v264_2));
        let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
        drop(v264_3);
        let v264_5: Space = subtract(&(*CONSTANT_1),&(v264_4));
        drop(v264_4);
        let v264_8: Space = if (&(v264_5)).is_empty() { Space::new() } else {
          let v265_6: Path = concat_path(&(v263_6),&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
          let mut v265_7 = Space::new();
          let mut v265_7_write = v265_7.write_zipper();
          for v265_7_byte in v261_28_cursor.child_mask().iter() {
            v261_28_cursor.descend_to_existing_byte(v265_7_byte);
            {
            let v266_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
            let v266_3: Space = intersect(&(*CONSTANT_2),&(v266_2));
            let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
            drop(v266_3);
            let v266_5: Space = subtract(&(*CONSTANT_1),&(v266_4));
            drop(v266_4);
            let v266_8: Space = if (&(v266_5)).is_empty() { Space::new() } else {
              let v267_6: Path = concat_path(&(v265_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v267_7: Space = routine_26(c, &(v267_6), &(*p1), &v261_28_cursor, &(*s1));
              compose(&(v266_5),&(v267_7))
            };
            drop(v266_5);
            let v266_9: Space = intersect(&(*CONSTANT_2),&(v266_2));
            drop(v266_2);
            let v266_10: Space = if has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
            drop(v266_9);
            let v266_12: Space = if (&(v266_10)).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v265_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v268_11: Space = routine_27(c, &(v268_6), &(*p1), &v261_28_cursor, &(*s1));
              drop(v268_6);
              compose(&(v266_10),&(v268_11))
            };
            drop(v266_10);
            let v266_13: Space = unite(&(v266_8),&(v266_12));
            join_wrapped_into(&mut v265_7_write,&((v266_13).read_zipper()),&[]);
            }
            v261_28_cursor.ascend(1);
          }
          drop(v265_7_write);
          compose(&(v264_5),&(v265_7))
        };
        drop(v264_5);
        let v264_9: Space = intersect(&(*CONSTANT_2),&(v264_2));
        drop(v264_2);
        let v264_10: Space = if has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
        drop(v264_9);
        let v264_12: Space = if (&(v264_10)).is_empty() { Space::new() } else {
          let v269_6: Path = concat_path(&(v263_6),&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
          let mut v269_11 = Space::new();
          let mut v269_11_write = v269_11.write_zipper();
          for v269_11_byte in v261_28_cursor.child_mask().iter() {
            v261_28_cursor.descend_to_existing_byte(v269_11_byte);
            {
            let v270_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
            let v270_3: Space = intersect(&(*CONSTANT_2),&(v270_2));
            let v270_4: Space = if has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
            drop(v270_3);
            let v270_5: Space = subtract(&(*CONSTANT_1),&(v270_4));
            drop(v270_4);
            let v270_8: Space = if (&(v270_5)).is_empty() { Space::new() } else {
              let v271_6: Path = concat_path(&(v269_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v271_7: Space = routine_26(c, &(v271_6), &(*p1), &v261_28_cursor, &(*s1));
              compose(&(v270_5),&(v271_7))
            };
            drop(v270_5);
            let v270_9: Space = intersect(&(*CONSTANT_2),&(v270_2));
            drop(v270_2);
            let v270_10: Space = if has_head(&(v270_9)) { singleton(&[]) } else { Space::new() };
            drop(v270_9);
            let v270_12: Space = if (&(v270_10)).is_empty() { Space::new() } else {
              let v272_6: Path = concat_path(&(v269_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v272_11: Space = routine_10(c, &(v272_6), &(*p1), &v261_28_cursor, &(*s1));
              drop(v272_6);
              compose(&(v270_10),&(v272_11))
            };
            drop(v270_10);
            let v270_13: Space = unite(&(v270_8),&(v270_12));
            join_wrapped_into(&mut v269_11_write,&((v270_13).read_zipper()),&[]);
            }
            v261_28_cursor.ascend(1);
          }
          drop(v269_11_write);
          drop(v269_6);
          compose(&(v264_10),&(v269_11))
        };
        drop(v264_10);
        let v264_13: Space = unite(&(v264_8),&(v264_12));
        join_wrapped_into(&mut v263_7_write,&((v264_13).read_zipper()),&[]);
        }
        v261_28_cursor.ascend(1);
      }
      drop(v263_7_write);
      drop(v263_6);
      compose(&(v262_5),&(v263_7))
    };
    drop(v262_5);
    let v262_9: Space = intersect(&(*CONSTANT_2),&(v262_2));
    drop(v262_2);
    let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
    drop(v262_9);
    let v262_13: Space = if (&(v262_10)).is_empty() { Space::new() } else {
      let mut v273_12 = Space::new();
      let mut v273_12_write = v273_12.write_zipper();
      let mut v273_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
      let v273_12_origin = v273_12_cursor.path().len();
      for v273_12_byte in v273_12_cursor.child_mask().iter() {
        v273_12_cursor.descend_to_existing_byte(v273_12_byte);
        {
        let v274_2: Space = singleton(&v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 1)]);
        let v274_3: Space = intersect(&(*CONSTANT_2),&(v274_2));
        let v274_4: Space = if has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
        drop(v274_3);
        let v274_5: Space = subtract(&(*CONSTANT_1),&(v274_4));
        drop(v274_4);
        let v274_7: Space = if (&(v274_5)).is_empty() { Space::new() } else {
          let mut v275_6 = Space::new();
          let mut v275_6_write = v275_6.write_zipper();
          for v275_6_byte in v273_12_cursor.child_mask().iter() {
            v273_12_cursor.descend_to_existing_byte(v275_6_byte);
            {
            let v276_2: Space = singleton(&v273_12_cursor.path()[(v273_12_origin + 1)..(v273_12_origin + 2)]);
            let v276_3: Space = intersect(&(*CONSTANT_2),&(v276_2));
            let v276_4: Space = if has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
            drop(v276_3);
            let v276_5: Space = subtract(&(*CONSTANT_1),&(v276_4));
            drop(v276_4);
            let v276_8: Space = if (&(v276_5)).is_empty() { Space::new() } else {
              let v277_7: Space = routine_17(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              compose(&(v276_5),&(v277_7))
            };
            drop(v276_5);
            let v276_9: Space = intersect(&(*CONSTANT_2),&(v276_2));
            drop(v276_2);
            let v276_10: Space = if has_head(&(v276_9)) { singleton(&[]) } else { Space::new() };
            drop(v276_9);
            let v276_12: Space = if (&(v276_10)).is_empty() { Space::new() } else {
              let v278_11: Space = routine_18(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              compose(&(v276_10),&(v278_11))
            };
            drop(v276_10);
            let v276_13: Space = unite(&(v276_8),&(v276_12));
            join_wrapped_into(&mut v275_6_write,&((v276_13).read_zipper()),&[]);
            }
            v273_12_cursor.ascend(1);
          }
          drop(v275_6_write);
          compose(&(v274_5),&(v275_6))
        };
        drop(v274_5);
        let v274_8: Space = intersect(&(*CONSTANT_2),&(v274_2));
        drop(v274_2);
        let v274_9: Space = if has_head(&(v274_8)) { singleton(&[]) } else { Space::new() };
        drop(v274_8);
        let v274_11: Space = if (&(v274_9)).is_empty() { Space::new() } else {
          let mut v279_10 = Space::new();
          let mut v279_10_write = v279_10.write_zipper();
          for v279_10_byte in v273_12_cursor.child_mask().iter() {
            v273_12_cursor.descend_to_existing_byte(v279_10_byte);
            {
            let v280_2: Space = singleton(&v273_12_cursor.path()[(v273_12_origin + 1)..(v273_12_origin + 2)]);
            let v280_3: Space = intersect(&(*CONSTANT_2),&(v280_2));
            let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
            drop(v280_3);
            let v280_5: Space = subtract(&(*CONSTANT_1),&(v280_4));
            drop(v280_4);
            let v280_8: Space = if (&(v280_5)).is_empty() { Space::new() } else {
              let v281_7: Space = routine_17(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              compose(&(v280_5),&(v281_7))
            };
            drop(v280_5);
            let v280_9: Space = intersect(&(*CONSTANT_2),&(v280_2));
            drop(v280_2);
            let v280_10: Space = if has_head(&(v280_9)) { singleton(&[]) } else { Space::new() };
            drop(v280_9);
            let v280_12: Space = if (&(v280_10)).is_empty() { Space::new() } else {
              let v282_11: Space = routine_19(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              compose(&(v280_10),&(v282_11))
            };
            drop(v280_10);
            let v280_13: Space = unite(&(v280_8),&(v280_12));
            join_wrapped_into(&mut v279_10_write,&((v280_13).read_zipper()),&[]);
            }
            v273_12_cursor.ascend(1);
          }
          drop(v279_10_write);
          compose(&(v274_9),&(v279_10))
        };
        drop(v274_9);
        let v274_12: Space = unite(&(v274_7),&(v274_11));
        join_wrapped_into(&mut v273_12_write,&((v274_12).read_zipper()),&[]);
        }
        v273_12_cursor.ascend(1);
      }
      drop(v273_12_cursor);
      drop(v273_12_write);
      compose(&(v262_10),&(v273_12))
    };
    drop(v262_10);
    let v262_14: Space = unite(&(v262_8),&(v262_13));
    join_wrapped_into(&mut v261_28_write,&((v262_14).read_zipper()),&[]);
    }
    v261_28_cursor.ascend(1);
  }
  drop(v261_28_cursor);
  drop(v261_28_write);
  (v261_28).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v283_21 = Space::new();
  let mut v283_21_write = v283_21.write_zipper();
  let mut v283_21_cursor = (*s0).read_zipper();
  let v283_21_origin = v283_21_cursor.path().len();
  for v283_21_byte in v283_21_cursor.child_mask().iter() {
    v283_21_cursor.descend_to_existing_byte(v283_21_byte);
    {
    let v284_2: Space = singleton(&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
    let v284_3: Space = intersect(&(*CONSTANT_2),&(v284_2));
    let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = subtract(&(*CONSTANT_1),&(v284_4));
    drop(v284_4);
    let v284_8: Space = if (&(v284_5)).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
      let mut v285_7 = Space::new();
      let mut v285_7_write = v285_7.write_zipper();
      for v285_7_byte in v283_21_cursor.child_mask().iter() {
        v283_21_cursor.descend_to_existing_byte(v285_7_byte);
        {
        let v286_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v286_3: Space = intersect(&(*CONSTANT_2),&(v286_2));
        let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = subtract(&(*CONSTANT_1),&(v286_4));
        drop(v286_4);
        let v286_8: Space = if (&(v286_5)).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v285_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v287_7 = Space::new();
          let mut v287_7_write = v287_7.write_zipper();
          for v287_7_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v287_7_byte);
            {
            let v288_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v288_3: Space = intersect(&(*CONSTANT_2),&(v288_2));
            let v288_4: Space = if has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = subtract(&(*CONSTANT_1),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (&(v288_5)).is_empty() { Space::new() } else {
              let v289_6: Path = concat_path(&(v287_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v289_7: Space = routine_28(c, &(v289_6), &(*p1), &v283_21_cursor);
              compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = intersect(&(*CONSTANT_2),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (&(v288_10)).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v287_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v290_11: Space = routine_29(c, &(v290_6), &(*p1), &v283_21_cursor);
              drop(v290_6);
              compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = unite(&(v288_8),&(v288_12));
            join_wrapped_into(&mut v287_7_write,&((v288_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v287_7_write);
          compose(&(v286_5),&(v287_7))
        };
        drop(v286_5);
        let v286_9: Space = intersect(&(*CONSTANT_2),&(v286_2));
        drop(v286_2);
        let v286_10: Space = if has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
        drop(v286_9);
        let v286_12: Space = if (&(v286_10)).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v285_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v291_11 = Space::new();
          let mut v291_11_write = v291_11.write_zipper();
          for v291_11_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v291_11_byte);
            {
            let v292_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v292_3: Space = intersect(&(*CONSTANT_2),&(v292_2));
            let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
            drop(v292_3);
            let v292_5: Space = subtract(&(*CONSTANT_1),&(v292_4));
            drop(v292_4);
            let v292_8: Space = if (&(v292_5)).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v291_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v293_7: Space = routine_28(c, &(v293_6), &(*p1), &v283_21_cursor);
              compose(&(v292_5),&(v293_7))
            };
            drop(v292_5);
            let v292_9: Space = intersect(&(*CONSTANT_2),&(v292_2));
            drop(v292_2);
            let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
            drop(v292_9);
            let v292_12: Space = if (&(v292_10)).is_empty() { Space::new() } else {
              let v294_6: Path = concat_path(&(v291_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v294_11: Space = routine_19(c, &(v294_6), &(*p1), &v283_21_cursor);
              drop(v294_6);
              compose(&(v292_10),&(v294_11))
            };
            drop(v292_10);
            let v292_13: Space = unite(&(v292_8),&(v292_12));
            join_wrapped_into(&mut v291_11_write,&((v292_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v291_11_write);
          drop(v291_6);
          compose(&(v286_10),&(v291_11))
        };
        drop(v286_10);
        let v286_13: Space = unite(&(v286_8),&(v286_12));
        join_wrapped_into(&mut v285_7_write,&((v286_13).read_zipper()),&[]);
        }
        v283_21_cursor.ascend(1);
      }
      drop(v285_7_write);
      compose(&(v284_5),&(v285_7))
    };
    drop(v284_5);
    let v284_9: Space = intersect(&(*CONSTANT_2),&(v284_2));
    drop(v284_2);
    let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
    drop(v284_9);
    let v284_12: Space = if (&(v284_10)).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
      let mut v295_11 = Space::new();
      let mut v295_11_write = v295_11.write_zipper();
      for v295_11_byte in v283_21_cursor.child_mask().iter() {
        v283_21_cursor.descend_to_existing_byte(v295_11_byte);
        {
        let v296_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v296_3: Space = intersect(&(*CONSTANT_2),&(v296_2));
        let v296_4: Space = if has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = subtract(&(*CONSTANT_1),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (&(v296_5)).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v297_7 = Space::new();
          let mut v297_7_write = v297_7.write_zipper();
          for v297_7_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v297_7_byte);
            {
            let v298_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v298_3: Space = intersect(&(*CONSTANT_2),&(v298_2));
            let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = subtract(&(*CONSTANT_1),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (&(v298_5)).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v299_7: Space = routine_28(c, &(v299_6), &(*p1), &v283_21_cursor);
              compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = intersect(&(*CONSTANT_2),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (&(v298_10)).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v300_11: Space = routine_29(c, &(v300_6), &(*p1), &v283_21_cursor);
              drop(v300_6);
              compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = unite(&(v298_8),&(v298_12));
            join_wrapped_into(&mut v297_7_write,&((v298_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v297_7_write);
          compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = intersect(&(*CONSTANT_2),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_11: Space = compose(&(v296_10),&v283_21_cursor);
        drop(v296_10);
        let v301_6: Path = concat_path(&(v295_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v296_12: Space = wrap(&(v296_11),&(v301_6));
        drop(v296_11);
        let v296_13: Space = wrap(&(v296_12),&(*p1));
        drop(v296_12);
        let v296_14: Space = unite(&(v296_8),&(v296_13));
        drop(v296_13);
        join_wrapped_into(&mut v295_11_write,&((v296_14).read_zipper()),&[]);
        }
        v283_21_cursor.ascend(1);
      }
      drop(v295_11_write);
      drop(v295_6);
      compose(&(v284_10),&(v295_11))
    };
    drop(v284_10);
    let v284_13: Space = unite(&(v284_8),&(v284_12));
    join_wrapped_into(&mut v283_21_write,&((v284_13).read_zipper()),&[]);
    }
    v283_21_cursor.ascend(1);
  }
  drop(v283_21_cursor);
  drop(v283_21_write);
  (v283_21).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v302_15 = Space::new();
  let mut v302_15_write = v302_15.write_zipper();
  let mut v302_15_cursor = (*s0).read_zipper();
  let v302_15_origin = v302_15_cursor.path().len();
  for v302_15_byte in v302_15_cursor.child_mask().iter() {
    v302_15_cursor.descend_to_existing_byte(v302_15_byte);
    {
    let v303_2: Space = singleton(&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
    let v303_3: Space = intersect(&(*CONSTANT_2),&(v303_2));
    let v303_4: Space = if has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
    drop(v303_3);
    let v303_5: Space = subtract(&(*CONSTANT_1),&(v303_4));
    drop(v303_4);
    let v303_8: Space = if (&(v303_5)).is_empty() { Space::new() } else {
      let v304_6: Path = concat_path(&(*p0),&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
      let mut v304_7 = Space::new();
      let mut v304_7_write = v304_7.write_zipper();
      for v304_7_byte in v302_15_cursor.child_mask().iter() {
        v302_15_cursor.descend_to_existing_byte(v304_7_byte);
        {
        let v305_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
        let v305_3: Space = intersect(&(*CONSTANT_2),&(v305_2));
        let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
        drop(v305_3);
        let v305_5: Space = subtract(&(*CONSTANT_1),&(v305_4));
        drop(v305_4);
        let v305_8: Space = if (&(v305_5)).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v304_6),&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
          let mut v306_7 = Space::new();
          let mut v306_7_write = v306_7.write_zipper();
          for v306_7_byte in v302_15_cursor.child_mask().iter() {
            v302_15_cursor.descend_to_existing_byte(v306_7_byte);
            {
            let v307_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
            let v307_3: Space = intersect(&(*CONSTANT_2),&(v307_2));
            let v307_4: Space = if has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
            drop(v307_3);
            let v307_5: Space = subtract(&(*CONSTANT_1),&(v307_4));
            drop(v307_4);
            let v307_8: Space = if (&(v307_5)).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v306_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v308_7: Space = routine_28(c, &(v308_6), &(*p1), &v302_15_cursor);
              compose(&(v307_5),&(v308_7))
            };
            drop(v307_5);
            let v307_9: Space = intersect(&(*CONSTANT_2),&(v307_2));
            drop(v307_2);
            let v307_10: Space = if has_head(&(v307_9)) { singleton(&[]) } else { Space::new() };
            drop(v307_9);
            let v307_12: Space = if (&(v307_10)).is_empty() { Space::new() } else {
              let v309_6: Path = concat_path(&(v306_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v309_11: Space = routine_29(c, &(v309_6), &(*p1), &v302_15_cursor);
              drop(v309_6);
              compose(&(v307_10),&(v309_11))
            };
            drop(v307_10);
            let v307_13: Space = unite(&(v307_8),&(v307_12));
            join_wrapped_into(&mut v306_7_write,&((v307_13).read_zipper()),&[]);
            }
            v302_15_cursor.ascend(1);
          }
          drop(v306_7_write);
          compose(&(v305_5),&(v306_7))
        };
        drop(v305_5);
        let v305_9: Space = intersect(&(*CONSTANT_2),&(v305_2));
        drop(v305_2);
        let v305_10: Space = if has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
        drop(v305_9);
        let v305_12: Space = if (&(v305_10)).is_empty() { Space::new() } else {
          let v310_6: Path = concat_path(&(v304_6),&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
          let mut v310_11 = Space::new();
          let mut v310_11_write = v310_11.write_zipper();
          for v310_11_byte in v302_15_cursor.child_mask().iter() {
            v302_15_cursor.descend_to_existing_byte(v310_11_byte);
            {
            let v311_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
            let v311_3: Space = intersect(&(*CONSTANT_2),&(v311_2));
            let v311_4: Space = if has_head(&(v311_3)) { singleton(&[]) } else { Space::new() };
            drop(v311_3);
            let v311_5: Space = subtract(&(*CONSTANT_1),&(v311_4));
            drop(v311_4);
            let v311_8: Space = if (&(v311_5)).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v310_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v312_7: Space = routine_28(c, &(v312_6), &(*p1), &v302_15_cursor);
              compose(&(v311_5),&(v312_7))
            };
            drop(v311_5);
            let v311_9: Space = intersect(&(*CONSTANT_2),&(v311_2));
            drop(v311_2);
            let v311_10: Space = if has_head(&(v311_9)) { singleton(&[]) } else { Space::new() };
            drop(v311_9);
            let v311_12: Space = if (&(v311_10)).is_empty() { Space::new() } else {
              let v313_6: Path = concat_path(&(v310_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v313_11: Space = routine_19(c, &(v313_6), &(*p1), &v302_15_cursor);
              drop(v313_6);
              compose(&(v311_10),&(v313_11))
            };
            drop(v311_10);
            let v311_13: Space = unite(&(v311_8),&(v311_12));
            join_wrapped_into(&mut v310_11_write,&((v311_13).read_zipper()),&[]);
            }
            v302_15_cursor.ascend(1);
          }
          drop(v310_11_write);
          drop(v310_6);
          compose(&(v305_10),&(v310_11))
        };
        drop(v305_10);
        let v305_13: Space = unite(&(v305_8),&(v305_12));
        join_wrapped_into(&mut v304_7_write,&((v305_13).read_zipper()),&[]);
        }
        v302_15_cursor.ascend(1);
      }
      drop(v304_7_write);
      compose(&(v303_5),&(v304_7))
    };
    drop(v303_5);
    let v303_9: Space = intersect(&(*CONSTANT_2),&(v303_2));
    drop(v303_2);
    let v303_10: Space = if has_head(&(v303_9)) { singleton(&[]) } else { Space::new() };
    drop(v303_9);
    let v303_11: Space = compose(&(v303_10),&v302_15_cursor);
    drop(v303_10);
    let v314_6: Path = concat_path(&(*p0),&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
    let v303_12: Space = wrap(&(v303_11),&(v314_6));
    drop(v303_11);
    let v303_13: Space = wrap(&(v303_12),&(*p1));
    drop(v303_12);
    let v303_14: Space = unite(&(v303_8),&(v303_13));
    drop(v303_13);
    join_wrapped_into(&mut v302_15_write,&((v303_14).read_zipper()),&[]);
    }
    v302_15_cursor.ascend(1);
  }
  drop(v302_15_cursor);
  drop(v302_15_write);
  (v302_15).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v315_28 = Space::new();
  let mut v315_28_write = v315_28.write_zipper();
  let mut v315_28_cursor = (*s0).read_zipper();
  let v315_28_origin = v315_28_cursor.path().len();
  for v315_28_byte in v315_28_cursor.child_mask().iter() {
    v315_28_cursor.descend_to_existing_byte(v315_28_byte);
    {
    let v316_2: Space = singleton(&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
    let v316_3: Space = intersect(&(*CONSTANT_2),&(v316_2));
    let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
    drop(v316_3);
    let v316_5: Space = subtract(&(*CONSTANT_1),&(v316_4));
    drop(v316_4);
    let v316_8: Space = if (&(v316_5)).is_empty() { Space::new() } else {
      let v317_6: Path = concat_path(&(*p0),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
      let mut v317_7 = Space::new();
      let mut v317_7_write = v317_7.write_zipper();
      for v317_7_byte in v315_28_cursor.child_mask().iter() {
        v315_28_cursor.descend_to_existing_byte(v317_7_byte);
        {
        let v318_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
        let v318_3: Space = intersect(&(*CONSTANT_2),&(v318_2));
        let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
        drop(v318_3);
        let v318_5: Space = subtract(&(*CONSTANT_1),&(v318_4));
        drop(v318_4);
        let v318_8: Space = if (&(v318_5)).is_empty() { Space::new() } else {
          let v319_6: Path = concat_path(&(v317_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v319_7 = Space::new();
          let mut v319_7_write = v319_7.write_zipper();
          for v319_7_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v319_7_byte);
            {
            let v320_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v320_3: Space = intersect(&(*CONSTANT_2),&(v320_2));
            let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
            drop(v320_3);
            let v320_5: Space = subtract(&(*CONSTANT_1),&(v320_4));
            drop(v320_4);
            let v320_8: Space = if (&(v320_5)).is_empty() { Space::new() } else {
              let v321_6: Path = concat_path(&(v319_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v321_7: Space = routine_30(c, &(v321_6), &(*p1), &v315_28_cursor, &(*s1));
              compose(&(v320_5),&(v321_7))
            };
            drop(v320_5);
            let v320_9: Space = intersect(&(*CONSTANT_2),&(v320_2));
            drop(v320_2);
            let v320_10: Space = if has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
            drop(v320_9);
            let v320_12: Space = if (&(v320_10)).is_empty() { Space::new() } else {
              let v322_6: Path = concat_path(&(v319_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v322_11: Space = routine_31(c, &(v322_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v322_6);
              compose(&(v320_10),&(v322_11))
            };
            drop(v320_10);
            let v320_13: Space = unite(&(v320_8),&(v320_12));
            join_wrapped_into(&mut v319_7_write,&((v320_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v319_7_write);
          compose(&(v318_5),&(v319_7))
        };
        drop(v318_5);
        let v318_9: Space = intersect(&(*CONSTANT_2),&(v318_2));
        drop(v318_2);
        let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
        drop(v318_9);
        let v318_12: Space = if (&(v318_10)).is_empty() { Space::new() } else {
          let v323_6: Path = concat_path(&(v317_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v323_11 = Space::new();
          let mut v323_11_write = v323_11.write_zipper();
          for v323_11_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v323_11_byte);
            {
            let v324_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v324_3: Space = intersect(&(*CONSTANT_2),&(v324_2));
            let v324_4: Space = if has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
            drop(v324_3);
            let v324_5: Space = subtract(&(*CONSTANT_1),&(v324_4));
            drop(v324_4);
            let v324_8: Space = if (&(v324_5)).is_empty() { Space::new() } else {
              let v325_6: Path = concat_path(&(v323_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v325_7: Space = routine_30(c, &(v325_6), &(*p1), &v315_28_cursor, &(*s1));
              compose(&(v324_5),&(v325_7))
            };
            drop(v324_5);
            let v324_9: Space = intersect(&(*CONSTANT_2),&(v324_2));
            drop(v324_2);
            let v324_10: Space = if has_head(&(v324_9)) { singleton(&[]) } else { Space::new() };
            drop(v324_9);
            let v324_12: Space = if (&(v324_10)).is_empty() { Space::new() } else {
              let v326_6: Path = concat_path(&(v323_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v326_11: Space = routine_10(c, &(v326_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v326_6);
              compose(&(v324_10),&(v326_11))
            };
            drop(v324_10);
            let v324_13: Space = unite(&(v324_8),&(v324_12));
            join_wrapped_into(&mut v323_11_write,&((v324_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v323_11_write);
          drop(v323_6);
          compose(&(v318_10),&(v323_11))
        };
        drop(v318_10);
        let v318_13: Space = unite(&(v318_8),&(v318_12));
        join_wrapped_into(&mut v317_7_write,&((v318_13).read_zipper()),&[]);
        }
        v315_28_cursor.ascend(1);
      }
      drop(v317_7_write);
      compose(&(v316_5),&(v317_7))
    };
    drop(v316_5);
    let v316_9: Space = intersect(&(*CONSTANT_2),&(v316_2));
    drop(v316_2);
    let v316_10: Space = if has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
    drop(v316_9);
    let v316_13: Space = if (&(v316_10)).is_empty() { Space::new() } else {
      let v327_6: Path = concat_path(&(*p0),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
      let mut v327_12 = Space::new();
      let mut v327_12_write = v327_12.write_zipper();
      for v327_12_byte in v315_28_cursor.child_mask().iter() {
        v315_28_cursor.descend_to_existing_byte(v327_12_byte);
        {
        let v328_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
        let v328_3: Space = intersect(&(*CONSTANT_2),&(v328_2));
        let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
        drop(v328_3);
        let v328_5: Space = subtract(&(*CONSTANT_1),&(v328_4));
        drop(v328_4);
        let v328_8: Space = if (&(v328_5)).is_empty() { Space::new() } else {
          let v329_6: Path = concat_path(&(v327_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v329_7 = Space::new();
          let mut v329_7_write = v329_7.write_zipper();
          for v329_7_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v329_7_byte);
            {
            let v330_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v330_3: Space = intersect(&(*CONSTANT_2),&(v330_2));
            let v330_4: Space = if has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
            drop(v330_3);
            let v330_5: Space = subtract(&(*CONSTANT_1),&(v330_4));
            drop(v330_4);
            let v330_8: Space = if (&(v330_5)).is_empty() { Space::new() } else {
              let v331_6: Path = concat_path(&(v329_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v331_7: Space = routine_30(c, &(v331_6), &(*p1), &v315_28_cursor, &(*s1));
              compose(&(v330_5),&(v331_7))
            };
            drop(v330_5);
            let v330_9: Space = intersect(&(*CONSTANT_2),&(v330_2));
            drop(v330_2);
            let v330_10: Space = if has_head(&(v330_9)) { singleton(&[]) } else { Space::new() };
            drop(v330_9);
            let v330_12: Space = if (&(v330_10)).is_empty() { Space::new() } else {
              let v332_6: Path = concat_path(&(v329_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v332_11: Space = routine_31(c, &(v332_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v332_6);
              compose(&(v330_10),&(v332_11))
            };
            drop(v330_10);
            let v330_13: Space = unite(&(v330_8),&(v330_12));
            join_wrapped_into(&mut v329_7_write,&((v330_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v329_7_write);
          drop(v329_6);
          compose(&(v328_5),&(v329_7))
        };
        drop(v328_5);
        let v328_9: Space = intersect(&(*CONSTANT_2),&(v328_2));
        drop(v328_2);
        let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
        drop(v328_9);
        let v328_13: Space = if (&(v328_10)).is_empty() { Space::new() } else {
          let mut v333_12 = Space::new();
          let mut v333_12_write = v333_12.write_zipper();
          let mut v333_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let v333_12_origin = v333_12_cursor.path().len();
          for v333_12_byte in v333_12_cursor.child_mask().iter() {
            v333_12_cursor.descend_to_existing_byte(v333_12_byte);
            {
            let v334_2: Space = singleton(&v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)]);
            let v334_3: Space = intersect(&(*CONSTANT_2),&(v334_2));
            let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
            drop(v334_3);
            let v334_5: Space = subtract(&(*CONSTANT_1),&(v334_4));
            drop(v334_4);
            let v334_7: Space = if (&(v334_5)).is_empty() { Space::new() } else {
              let v335_6: Space = routine_13(c, &v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)], &(*p1), &v333_12_cursor);
              compose(&(v334_5),&(v335_6))
            };
            drop(v334_5);
            let v334_8: Space = intersect(&(*CONSTANT_2),&(v334_2));
            drop(v334_2);
            let v334_9: Space = if has_head(&(v334_8)) { singleton(&[]) } else { Space::new() };
            drop(v334_8);
            let v334_11: Space = if (&(v334_9)).is_empty() { Space::new() } else {
              let v336_10: Space = routine_14(c, &v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)], &(*p1), &v333_12_cursor);
              compose(&(v334_9),&(v336_10))
            };
            drop(v334_9);
            let v334_12: Space = unite(&(v334_7),&(v334_11));
            join_wrapped_into(&mut v333_12_write,&((v334_12).read_zipper()),&[]);
            }
            v333_12_cursor.ascend(1);
          }
          drop(v333_12_cursor);
          drop(v333_12_write);
          compose(&(v328_10),&(v333_12))
        };
        drop(v328_10);
        let v328_14: Space = unite(&(v328_8),&(v328_13));
        join_wrapped_into(&mut v327_12_write,&((v328_14).read_zipper()),&[]);
        }
        v315_28_cursor.ascend(1);
      }
      drop(v327_12_write);
      drop(v327_6);
      compose(&(v316_10),&(v327_12))
    };
    drop(v316_10);
    let v316_14: Space = unite(&(v316_8),&(v316_13));
    join_wrapped_into(&mut v315_28_write,&((v316_14).read_zipper()),&[]);
    }
    v315_28_cursor.ascend(1);
  }
  drop(v315_28_cursor);
  drop(v315_28_write);
  (v315_28).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v337_28 = Space::new();
  let mut v337_28_write = v337_28.write_zipper();
  let mut v337_28_cursor = (*s0).read_zipper();
  let v337_28_origin = v337_28_cursor.path().len();
  for v337_28_byte in v337_28_cursor.child_mask().iter() {
    v337_28_cursor.descend_to_existing_byte(v337_28_byte);
    {
    let v338_2: Space = singleton(&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
    let v338_3: Space = intersect(&(*CONSTANT_2),&(v338_2));
    let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
    drop(v338_3);
    let v338_5: Space = subtract(&(*CONSTANT_1),&(v338_4));
    drop(v338_4);
    let v338_8: Space = if (&(v338_5)).is_empty() { Space::new() } else {
      let v339_6: Path = concat_path(&(*p0),&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
      let mut v339_7 = Space::new();
      let mut v339_7_write = v339_7.write_zipper();
      for v339_7_byte in v337_28_cursor.child_mask().iter() {
        v337_28_cursor.descend_to_existing_byte(v339_7_byte);
        {
        let v340_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
        let v340_3: Space = intersect(&(*CONSTANT_2),&(v340_2));
        let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
        drop(v340_3);
        let v340_5: Space = subtract(&(*CONSTANT_1),&(v340_4));
        drop(v340_4);
        let v340_8: Space = if (&(v340_5)).is_empty() { Space::new() } else {
          let v341_6: Path = concat_path(&(v339_6),&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
          let mut v341_7 = Space::new();
          let mut v341_7_write = v341_7.write_zipper();
          for v341_7_byte in v337_28_cursor.child_mask().iter() {
            v337_28_cursor.descend_to_existing_byte(v341_7_byte);
            {
            let v342_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
            let v342_3: Space = intersect(&(*CONSTANT_2),&(v342_2));
            let v342_4: Space = if has_head(&(v342_3)) { singleton(&[]) } else { Space::new() };
            drop(v342_3);
            let v342_5: Space = subtract(&(*CONSTANT_1),&(v342_4));
            drop(v342_4);
            let v342_8: Space = if (&(v342_5)).is_empty() { Space::new() } else {
              let v343_6: Path = concat_path(&(v341_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v343_7: Space = routine_30(c, &(v343_6), &(*p1), &v337_28_cursor, &(*s1));
              compose(&(v342_5),&(v343_7))
            };
            drop(v342_5);
            let v342_9: Space = intersect(&(*CONSTANT_2),&(v342_2));
            drop(v342_2);
            let v342_10: Space = if has_head(&(v342_9)) { singleton(&[]) } else { Space::new() };
            drop(v342_9);
            let v342_12: Space = if (&(v342_10)).is_empty() { Space::new() } else {
              let v344_6: Path = concat_path(&(v341_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v344_11: Space = routine_31(c, &(v344_6), &(*p1), &v337_28_cursor, &(*s1));
              drop(v344_6);
              compose(&(v342_10),&(v344_11))
            };
            drop(v342_10);
            let v342_13: Space = unite(&(v342_8),&(v342_12));
            join_wrapped_into(&mut v341_7_write,&((v342_13).read_zipper()),&[]);
            }
            v337_28_cursor.ascend(1);
          }
          drop(v341_7_write);
          compose(&(v340_5),&(v341_7))
        };
        drop(v340_5);
        let v340_9: Space = intersect(&(*CONSTANT_2),&(v340_2));
        drop(v340_2);
        let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
        drop(v340_9);
        let v340_12: Space = if (&(v340_10)).is_empty() { Space::new() } else {
          let v345_6: Path = concat_path(&(v339_6),&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
          let mut v345_11 = Space::new();
          let mut v345_11_write = v345_11.write_zipper();
          for v345_11_byte in v337_28_cursor.child_mask().iter() {
            v337_28_cursor.descend_to_existing_byte(v345_11_byte);
            {
            let v346_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
            let v346_3: Space = intersect(&(*CONSTANT_2),&(v346_2));
            let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
            drop(v346_3);
            let v346_5: Space = subtract(&(*CONSTANT_1),&(v346_4));
            drop(v346_4);
            let v346_8: Space = if (&(v346_5)).is_empty() { Space::new() } else {
              let v347_6: Path = concat_path(&(v345_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v347_7: Space = routine_30(c, &(v347_6), &(*p1), &v337_28_cursor, &(*s1));
              compose(&(v346_5),&(v347_7))
            };
            drop(v346_5);
            let v346_9: Space = intersect(&(*CONSTANT_2),&(v346_2));
            drop(v346_2);
            let v346_10: Space = if has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
            drop(v346_9);
            let v346_12: Space = if (&(v346_10)).is_empty() { Space::new() } else {
              let v348_6: Path = concat_path(&(v345_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v348_11: Space = routine_10(c, &(v348_6), &(*p1), &v337_28_cursor, &(*s1));
              drop(v348_6);
              compose(&(v346_10),&(v348_11))
            };
            drop(v346_10);
            let v346_13: Space = unite(&(v346_8),&(v346_12));
            join_wrapped_into(&mut v345_11_write,&((v346_13).read_zipper()),&[]);
            }
            v337_28_cursor.ascend(1);
          }
          drop(v345_11_write);
          drop(v345_6);
          compose(&(v340_10),&(v345_11))
        };
        drop(v340_10);
        let v340_13: Space = unite(&(v340_8),&(v340_12));
        join_wrapped_into(&mut v339_7_write,&((v340_13).read_zipper()),&[]);
        }
        v337_28_cursor.ascend(1);
      }
      drop(v339_7_write);
      drop(v339_6);
      compose(&(v338_5),&(v339_7))
    };
    drop(v338_5);
    let v338_9: Space = intersect(&(*CONSTANT_2),&(v338_2));
    drop(v338_2);
    let v338_10: Space = if has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
    drop(v338_9);
    let v338_13: Space = if (&(v338_10)).is_empty() { Space::new() } else {
      let mut v349_12 = Space::new();
      let mut v349_12_write = v349_12.write_zipper();
      let mut v349_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
      let v349_12_origin = v349_12_cursor.path().len();
      for v349_12_byte in v349_12_cursor.child_mask().iter() {
        v349_12_cursor.descend_to_existing_byte(v349_12_byte);
        {
        let v350_2: Space = singleton(&v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 1)]);
        let v350_3: Space = intersect(&(*CONSTANT_2),&(v350_2));
        let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
        drop(v350_3);
        let v350_5: Space = subtract(&(*CONSTANT_1),&(v350_4));
        drop(v350_4);
        let v350_7: Space = if (&(v350_5)).is_empty() { Space::new() } else {
          let mut v351_6 = Space::new();
          let mut v351_6_write = v351_6.write_zipper();
          for v351_6_byte in v349_12_cursor.child_mask().iter() {
            v349_12_cursor.descend_to_existing_byte(v351_6_byte);
            {
            let v352_2: Space = singleton(&v349_12_cursor.path()[(v349_12_origin + 1)..(v349_12_origin + 2)]);
            let v352_3: Space = intersect(&(*CONSTANT_2),&(v352_2));
            let v352_4: Space = if has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
            drop(v352_3);
            let v352_5: Space = subtract(&(*CONSTANT_1),&(v352_4));
            drop(v352_4);
            let v352_8: Space = if (&(v352_5)).is_empty() { Space::new() } else {
              let v353_7: Space = routine_17(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              compose(&(v352_5),&(v353_7))
            };
            drop(v352_5);
            let v352_9: Space = intersect(&(*CONSTANT_2),&(v352_2));
            drop(v352_2);
            let v352_10: Space = if has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
            drop(v352_9);
            let v352_12: Space = if (&(v352_10)).is_empty() { Space::new() } else {
              let v354_11: Space = routine_18(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              compose(&(v352_10),&(v354_11))
            };
            drop(v352_10);
            let v352_13: Space = unite(&(v352_8),&(v352_12));
            join_wrapped_into(&mut v351_6_write,&((v352_13).read_zipper()),&[]);
            }
            v349_12_cursor.ascend(1);
          }
          drop(v351_6_write);
          compose(&(v350_5),&(v351_6))
        };
        drop(v350_5);
        let v350_8: Space = intersect(&(*CONSTANT_2),&(v350_2));
        drop(v350_2);
        let v350_9: Space = if has_head(&(v350_8)) { singleton(&[]) } else { Space::new() };
        drop(v350_8);
        let v350_11: Space = if (&(v350_9)).is_empty() { Space::new() } else {
          let mut v355_10 = Space::new();
          let mut v355_10_write = v355_10.write_zipper();
          for v355_10_byte in v349_12_cursor.child_mask().iter() {
            v349_12_cursor.descend_to_existing_byte(v355_10_byte);
            {
            let v356_2: Space = singleton(&v349_12_cursor.path()[(v349_12_origin + 1)..(v349_12_origin + 2)]);
            let v356_3: Space = intersect(&(*CONSTANT_2),&(v356_2));
            let v356_4: Space = if has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
            drop(v356_3);
            let v356_5: Space = subtract(&(*CONSTANT_1),&(v356_4));
            drop(v356_4);
            let v356_8: Space = if (&(v356_5)).is_empty() { Space::new() } else {
              let v357_7: Space = routine_17(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              compose(&(v356_5),&(v357_7))
            };
            drop(v356_5);
            let v356_9: Space = intersect(&(*CONSTANT_2),&(v356_2));
            drop(v356_2);
            let v356_10: Space = if has_head(&(v356_9)) { singleton(&[]) } else { Space::new() };
            drop(v356_9);
            let v356_12: Space = if (&(v356_10)).is_empty() { Space::new() } else {
              let v358_11: Space = routine_19(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              compose(&(v356_10),&(v358_11))
            };
            drop(v356_10);
            let v356_13: Space = unite(&(v356_8),&(v356_12));
            join_wrapped_into(&mut v355_10_write,&((v356_13).read_zipper()),&[]);
            }
            v349_12_cursor.ascend(1);
          }
          drop(v355_10_write);
          compose(&(v350_9),&(v355_10))
        };
        drop(v350_9);
        let v350_12: Space = unite(&(v350_7),&(v350_11));
        join_wrapped_into(&mut v349_12_write,&((v350_12).read_zipper()),&[]);
        }
        v349_12_cursor.ascend(1);
      }
      drop(v349_12_cursor);
      drop(v349_12_write);
      compose(&(v338_10),&(v349_12))
    };
    drop(v338_10);
    let v338_14: Space = unite(&(v338_8),&(v338_13));
    join_wrapped_into(&mut v337_28_write,&((v338_14).read_zipper()),&[]);
    }
    v337_28_cursor.ascend(1);
  }
  drop(v337_28_cursor);
  drop(v337_28_write);
  (v337_28).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v359_21 = Space::new();
  let mut v359_21_write = v359_21.write_zipper();
  let mut v359_21_cursor = (*s0).read_zipper();
  let v359_21_origin = v359_21_cursor.path().len();
  for v359_21_byte in v359_21_cursor.child_mask().iter() {
    v359_21_cursor.descend_to_existing_byte(v359_21_byte);
    {
    let v360_2: Space = singleton(&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
    let v360_3: Space = intersect(&(*CONSTANT_2),&(v360_2));
    let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
    drop(v360_3);
    let v360_5: Space = subtract(&(*CONSTANT_1),&(v360_4));
    drop(v360_4);
    let v360_8: Space = if (&(v360_5)).is_empty() { Space::new() } else {
      let v361_6: Path = concat_path(&(*p0),&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
      let mut v361_7 = Space::new();
      let mut v361_7_write = v361_7.write_zipper();
      for v361_7_byte in v359_21_cursor.child_mask().iter() {
        v359_21_cursor.descend_to_existing_byte(v361_7_byte);
        {
        let v362_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v362_3: Space = intersect(&(*CONSTANT_2),&(v362_2));
        let v362_4: Space = if has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
        drop(v362_3);
        let v362_5: Space = subtract(&(*CONSTANT_1),&(v362_4));
        drop(v362_4);
        let v362_8: Space = if (&(v362_5)).is_empty() { Space::new() } else {
          let v363_6: Path = concat_path(&(v361_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v363_7 = Space::new();
          let mut v363_7_write = v363_7.write_zipper();
          for v363_7_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v363_7_byte);
            {
            let v364_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v364_3: Space = intersect(&(*CONSTANT_2),&(v364_2));
            let v364_4: Space = if has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
            drop(v364_3);
            let v364_5: Space = subtract(&(*CONSTANT_1),&(v364_4));
            drop(v364_4);
            let v364_8: Space = if (&(v364_5)).is_empty() { Space::new() } else {
              let v365_6: Path = concat_path(&(v363_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v365_7: Space = routine_32(c, &(v365_6), &(*p1), &v359_21_cursor);
              compose(&(v364_5),&(v365_7))
            };
            drop(v364_5);
            let v364_9: Space = intersect(&(*CONSTANT_2),&(v364_2));
            drop(v364_2);
            let v364_10: Space = if has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
            drop(v364_9);
            let v364_12: Space = if (&(v364_10)).is_empty() { Space::new() } else {
              let v366_6: Path = concat_path(&(v363_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v366_11: Space = routine_33(c, &(v366_6), &(*p1), &v359_21_cursor);
              drop(v366_6);
              compose(&(v364_10),&(v366_11))
            };
            drop(v364_10);
            let v364_13: Space = unite(&(v364_8),&(v364_12));
            join_wrapped_into(&mut v363_7_write,&((v364_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v363_7_write);
          compose(&(v362_5),&(v363_7))
        };
        drop(v362_5);
        let v362_9: Space = intersect(&(*CONSTANT_2),&(v362_2));
        drop(v362_2);
        let v362_10: Space = if has_head(&(v362_9)) { singleton(&[]) } else { Space::new() };
        drop(v362_9);
        let v362_12: Space = if (&(v362_10)).is_empty() { Space::new() } else {
          let v367_6: Path = concat_path(&(v361_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v367_11 = Space::new();
          let mut v367_11_write = v367_11.write_zipper();
          for v367_11_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v367_11_byte);
            {
            let v368_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v368_3: Space = intersect(&(*CONSTANT_2),&(v368_2));
            let v368_4: Space = if has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
            drop(v368_3);
            let v368_5: Space = subtract(&(*CONSTANT_1),&(v368_4));
            drop(v368_4);
            let v368_8: Space = if (&(v368_5)).is_empty() { Space::new() } else {
              let v369_6: Path = concat_path(&(v367_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v369_7: Space = routine_32(c, &(v369_6), &(*p1), &v359_21_cursor);
              compose(&(v368_5),&(v369_7))
            };
            drop(v368_5);
            let v368_9: Space = intersect(&(*CONSTANT_2),&(v368_2));
            drop(v368_2);
            let v368_10: Space = if has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
            drop(v368_9);
            let v368_12: Space = if (&(v368_10)).is_empty() { Space::new() } else {
              let v370_6: Path = concat_path(&(v367_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v370_11: Space = routine_19(c, &(v370_6), &(*p1), &v359_21_cursor);
              drop(v370_6);
              compose(&(v368_10),&(v370_11))
            };
            drop(v368_10);
            let v368_13: Space = unite(&(v368_8),&(v368_12));
            join_wrapped_into(&mut v367_11_write,&((v368_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v367_11_write);
          drop(v367_6);
          compose(&(v362_10),&(v367_11))
        };
        drop(v362_10);
        let v362_13: Space = unite(&(v362_8),&(v362_12));
        join_wrapped_into(&mut v361_7_write,&((v362_13).read_zipper()),&[]);
        }
        v359_21_cursor.ascend(1);
      }
      drop(v361_7_write);
      compose(&(v360_5),&(v361_7))
    };
    drop(v360_5);
    let v360_9: Space = intersect(&(*CONSTANT_2),&(v360_2));
    drop(v360_2);
    let v360_10: Space = if has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
    drop(v360_9);
    let v360_12: Space = if (&(v360_10)).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
      let mut v371_11 = Space::new();
      let mut v371_11_write = v371_11.write_zipper();
      for v371_11_byte in v359_21_cursor.child_mask().iter() {
        v359_21_cursor.descend_to_existing_byte(v371_11_byte);
        {
        let v372_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v372_3: Space = intersect(&(*CONSTANT_2),&(v372_2));
        let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
        drop(v372_3);
        let v372_5: Space = subtract(&(*CONSTANT_1),&(v372_4));
        drop(v372_4);
        let v372_8: Space = if (&(v372_5)).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v371_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v373_7 = Space::new();
          let mut v373_7_write = v373_7.write_zipper();
          for v373_7_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v373_7_byte);
            {
            let v374_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v374_3: Space = intersect(&(*CONSTANT_2),&(v374_2));
            let v374_4: Space = if has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
            drop(v374_3);
            let v374_5: Space = subtract(&(*CONSTANT_1),&(v374_4));
            drop(v374_4);
            let v374_8: Space = if (&(v374_5)).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v373_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v375_7: Space = routine_32(c, &(v375_6), &(*p1), &v359_21_cursor);
              compose(&(v374_5),&(v375_7))
            };
            drop(v374_5);
            let v374_9: Space = intersect(&(*CONSTANT_2),&(v374_2));
            drop(v374_2);
            let v374_10: Space = if has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
            drop(v374_9);
            let v374_12: Space = if (&(v374_10)).is_empty() { Space::new() } else {
              let v376_6: Path = concat_path(&(v373_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v376_11: Space = routine_33(c, &(v376_6), &(*p1), &v359_21_cursor);
              drop(v376_6);
              compose(&(v374_10),&(v376_11))
            };
            drop(v374_10);
            let v374_13: Space = unite(&(v374_8),&(v374_12));
            join_wrapped_into(&mut v373_7_write,&((v374_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v373_7_write);
          compose(&(v372_5),&(v373_7))
        };
        drop(v372_5);
        let v372_9: Space = intersect(&(*CONSTANT_2),&(v372_2));
        drop(v372_2);
        let v372_10: Space = if has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
        drop(v372_9);
        let v372_11: Space = compose(&(v372_10),&v359_21_cursor);
        drop(v372_10);
        let v377_6: Path = concat_path(&(v371_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v372_12: Space = wrap(&(v372_11),&(v377_6));
        drop(v372_11);
        let v372_13: Space = wrap(&(v372_12),&(*p1));
        drop(v372_12);
        let v372_14: Space = unite(&(v372_8),&(v372_13));
        drop(v372_13);
        join_wrapped_into(&mut v371_11_write,&((v372_14).read_zipper()),&[]);
        }
        v359_21_cursor.ascend(1);
      }
      drop(v371_11_write);
      drop(v371_6);
      compose(&(v360_10),&(v371_11))
    };
    drop(v360_10);
    let v360_13: Space = unite(&(v360_8),&(v360_12));
    join_wrapped_into(&mut v359_21_write,&((v360_13).read_zipper()),&[]);
    }
    v359_21_cursor.ascend(1);
  }
  drop(v359_21_cursor);
  drop(v359_21_write);
  (v359_21).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v378_15 = Space::new();
  let mut v378_15_write = v378_15.write_zipper();
  let mut v378_15_cursor = (*s0).read_zipper();
  let v378_15_origin = v378_15_cursor.path().len();
  for v378_15_byte in v378_15_cursor.child_mask().iter() {
    v378_15_cursor.descend_to_existing_byte(v378_15_byte);
    {
    let v379_2: Space = singleton(&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
    let v379_3: Space = intersect(&(*CONSTANT_2),&(v379_2));
    let v379_4: Space = if has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
    drop(v379_3);
    let v379_5: Space = subtract(&(*CONSTANT_1),&(v379_4));
    drop(v379_4);
    let v379_8: Space = if (&(v379_5)).is_empty() { Space::new() } else {
      let v380_6: Path = concat_path(&(*p0),&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
      let mut v380_7 = Space::new();
      let mut v380_7_write = v380_7.write_zipper();
      for v380_7_byte in v378_15_cursor.child_mask().iter() {
        v378_15_cursor.descend_to_existing_byte(v380_7_byte);
        {
        let v381_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
        let v381_3: Space = intersect(&(*CONSTANT_2),&(v381_2));
        let v381_4: Space = if has_head(&(v381_3)) { singleton(&[]) } else { Space::new() };
        drop(v381_3);
        let v381_5: Space = subtract(&(*CONSTANT_1),&(v381_4));
        drop(v381_4);
        let v381_8: Space = if (&(v381_5)).is_empty() { Space::new() } else {
          let v382_6: Path = concat_path(&(v380_6),&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
          let mut v382_7 = Space::new();
          let mut v382_7_write = v382_7.write_zipper();
          for v382_7_byte in v378_15_cursor.child_mask().iter() {
            v378_15_cursor.descend_to_existing_byte(v382_7_byte);
            {
            let v383_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
            let v383_3: Space = intersect(&(*CONSTANT_2),&(v383_2));
            let v383_4: Space = if has_head(&(v383_3)) { singleton(&[]) } else { Space::new() };
            drop(v383_3);
            let v383_5: Space = subtract(&(*CONSTANT_1),&(v383_4));
            drop(v383_4);
            let v383_8: Space = if (&(v383_5)).is_empty() { Space::new() } else {
              let v384_6: Path = concat_path(&(v382_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v384_7: Space = routine_32(c, &(v384_6), &(*p1), &v378_15_cursor);
              compose(&(v383_5),&(v384_7))
            };
            drop(v383_5);
            let v383_9: Space = intersect(&(*CONSTANT_2),&(v383_2));
            drop(v383_2);
            let v383_10: Space = if has_head(&(v383_9)) { singleton(&[]) } else { Space::new() };
            drop(v383_9);
            let v383_12: Space = if (&(v383_10)).is_empty() { Space::new() } else {
              let v385_6: Path = concat_path(&(v382_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v385_11: Space = routine_33(c, &(v385_6), &(*p1), &v378_15_cursor);
              drop(v385_6);
              compose(&(v383_10),&(v385_11))
            };
            drop(v383_10);
            let v383_13: Space = unite(&(v383_8),&(v383_12));
            join_wrapped_into(&mut v382_7_write,&((v383_13).read_zipper()),&[]);
            }
            v378_15_cursor.ascend(1);
          }
          drop(v382_7_write);
          compose(&(v381_5),&(v382_7))
        };
        drop(v381_5);
        let v381_9: Space = intersect(&(*CONSTANT_2),&(v381_2));
        drop(v381_2);
        let v381_10: Space = if has_head(&(v381_9)) { singleton(&[]) } else { Space::new() };
        drop(v381_9);
        let v381_12: Space = if (&(v381_10)).is_empty() { Space::new() } else {
          let v386_6: Path = concat_path(&(v380_6),&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
          let mut v386_11 = Space::new();
          let mut v386_11_write = v386_11.write_zipper();
          for v386_11_byte in v378_15_cursor.child_mask().iter() {
            v378_15_cursor.descend_to_existing_byte(v386_11_byte);
            {
            let v387_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
            let v387_3: Space = intersect(&(*CONSTANT_2),&(v387_2));
            let v387_4: Space = if has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
            drop(v387_3);
            let v387_5: Space = subtract(&(*CONSTANT_1),&(v387_4));
            drop(v387_4);
            let v387_8: Space = if (&(v387_5)).is_empty() { Space::new() } else {
              let v388_6: Path = concat_path(&(v386_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v388_7: Space = routine_32(c, &(v388_6), &(*p1), &v378_15_cursor);
              compose(&(v387_5),&(v388_7))
            };
            drop(v387_5);
            let v387_9: Space = intersect(&(*CONSTANT_2),&(v387_2));
            drop(v387_2);
            let v387_10: Space = if has_head(&(v387_9)) { singleton(&[]) } else { Space::new() };
            drop(v387_9);
            let v387_12: Space = if (&(v387_10)).is_empty() { Space::new() } else {
              let v389_6: Path = concat_path(&(v386_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v389_11: Space = routine_19(c, &(v389_6), &(*p1), &v378_15_cursor);
              drop(v389_6);
              compose(&(v387_10),&(v389_11))
            };
            drop(v387_10);
            let v387_13: Space = unite(&(v387_8),&(v387_12));
            join_wrapped_into(&mut v386_11_write,&((v387_13).read_zipper()),&[]);
            }
            v378_15_cursor.ascend(1);
          }
          drop(v386_11_write);
          drop(v386_6);
          compose(&(v381_10),&(v386_11))
        };
        drop(v381_10);
        let v381_13: Space = unite(&(v381_8),&(v381_12));
        join_wrapped_into(&mut v380_7_write,&((v381_13).read_zipper()),&[]);
        }
        v378_15_cursor.ascend(1);
      }
      drop(v380_7_write);
      compose(&(v379_5),&(v380_7))
    };
    drop(v379_5);
    let v379_9: Space = intersect(&(*CONSTANT_2),&(v379_2));
    drop(v379_2);
    let v379_10: Space = if has_head(&(v379_9)) { singleton(&[]) } else { Space::new() };
    drop(v379_9);
    let v379_11: Space = compose(&(v379_10),&v378_15_cursor);
    drop(v379_10);
    let v390_6: Path = concat_path(&(*p0),&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
    let v379_12: Space = wrap(&(v379_11),&(v390_6));
    drop(v379_11);
    let v379_13: Space = wrap(&(v379_12),&(*p1));
    drop(v379_12);
    let v379_14: Space = unite(&(v379_8),&(v379_13));
    drop(v379_13);
    join_wrapped_into(&mut v378_15_write,&((v379_14).read_zipper()),&[]);
    }
    v378_15_cursor.ascend(1);
  }
  drop(v378_15_cursor);
  drop(v378_15_write);
  (v378_15).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v391_3: Space = wrap(&(*s0),&(*p0));
  let v391_4: Space = wrap(&(v391_3),&(*p1));
  drop(v391_3);
  (v391_4).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v392_12 = Space::new();
  let mut v392_12_write = v392_12.write_zipper();
  let mut v392_12_cursor = (*s0).read_zipper();
  let v392_12_origin = v392_12_cursor.path().len();
  for v392_12_byte in v392_12_cursor.child_mask().iter() {
    v392_12_cursor.descend_to_existing_byte(v392_12_byte);
    {
    let v393_2: Space = singleton(&v392_12_cursor.path()[v392_12_origin..(v392_12_origin + 1)]);
    let v393_3: Space = intersect(&(*CONSTANT_2),&(v393_2));
    let v393_4: Space = if has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
    drop(v393_3);
    let v393_5: Space = subtract(&(*CONSTANT_1),&(v393_4));
    drop(v393_4);
    let v393_8: Space = if (&(v393_5)).is_empty() { Space::new() } else {
      let v394_6: Path = concat_path(&(*p0),&v392_12_cursor.path()[v392_12_origin..(v392_12_origin + 1)]);
      let mut v394_7 = Space::new();
      let mut v394_7_write = v394_7.write_zipper();
      for v394_7_byte in v392_12_cursor.child_mask().iter() {
        v392_12_cursor.descend_to_existing_byte(v394_7_byte);
        {
        let v395_2: Space = singleton(&v392_12_cursor.path()[(v392_12_origin + 1)..(v392_12_origin + 2)]);
        let v395_3: Space = intersect(&(*CONSTANT_2),&(v395_2));
        drop(v395_2);
        let v395_4: Space = if has_head(&(v395_3)) { singleton(&[]) } else { Space::new() };
        drop(v395_3);
        let v395_7: Space = if (&(v395_4)).is_empty() { Space::new() } else {
          let v396_5: Path = concat_path(&(v394_6),&v392_12_cursor.path()[(v392_12_origin + 1)..(v392_12_origin + 2)]);
          let mut v396_6 = Space::new();
          let mut v396_6_write = v396_6.write_zipper();
          for v396_6_byte in v392_12_cursor.child_mask().iter() {
            v392_12_cursor.descend_to_existing_byte(v396_6_byte);
            {
            let v397_2: Space = singleton(&v392_12_cursor.path()[(v392_12_origin + 2)..(v392_12_origin + 3)]);
            let v397_3: Space = intersect(&(*CONSTANT_2),&(v397_2));
            drop(v397_2);
            let v397_4: Space = if has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
            drop(v397_3);
            let v397_7: Space = if (&(v397_4)).is_empty() { Space::new() } else {
              let v398_5: Path = concat_path(&(v396_5),&v392_12_cursor.path()[(v392_12_origin + 2)..(v392_12_origin + 3)]);
              let v398_6: Space = routine_3(c, &(v398_5), &v392_12_cursor, &(*s1));
              drop(v398_5);
              compose(&(v397_4),&(v398_6))
            };
            drop(v397_4);
            join_wrapped_into(&mut v396_6_write,&((v397_7).read_zipper()),&[]);
            }
            v392_12_cursor.ascend(1);
          }
          drop(v396_6_write);
          drop(v396_5);
          compose(&(v395_4),&(v396_6))
        };
        drop(v395_4);
        join_wrapped_into(&mut v394_7_write,&((v395_7).read_zipper()),&[]);
        }
        v392_12_cursor.ascend(1);
      }
      drop(v394_7_write);
      compose(&(v393_5),&(v394_7))
    };
    drop(v393_5);
    let v393_9: Space = intersect(&(*CONSTANT_2),&(v393_2));
    drop(v393_2);
    let v393_10: Space = if has_head(&(v393_9)) { singleton(&[]) } else { Space::new() };
    drop(v393_9);
    let v393_12: Space = if (&(v393_10)).is_empty() { Space::new() } else {
      let v399_6: Path = concat_path(&(*p0),&v392_12_cursor.path()[v392_12_origin..(v392_12_origin + 1)]);
      let mut v399_11 = Space::new();
      let mut v399_11_write = v399_11.write_zipper();
      for v399_11_byte in v392_12_cursor.child_mask().iter() {
        v392_12_cursor.descend_to_existing_byte(v399_11_byte);
        {
        let v400_2: Space = singleton(&v392_12_cursor.path()[(v392_12_origin + 1)..(v392_12_origin + 2)]);
        let v400_3: Space = intersect(&(*CONSTANT_2),&(v400_2));
        drop(v400_2);
        let v400_4: Space = if has_head(&(v400_3)) { singleton(&[]) } else { Space::new() };
        drop(v400_3);
        let v400_7: Space = if (&(v400_4)).is_empty() { Space::new() } else {
          let v401_5: Path = concat_path(&(v399_6),&v392_12_cursor.path()[(v392_12_origin + 1)..(v392_12_origin + 2)]);
          let mut v401_6 = Space::new();
          let mut v401_6_write = v401_6.write_zipper();
          for v401_6_byte in v392_12_cursor.child_mask().iter() {
            v392_12_cursor.descend_to_existing_byte(v401_6_byte);
            {
            let v402_2: Space = singleton(&v392_12_cursor.path()[(v392_12_origin + 2)..(v392_12_origin + 3)]);
            let v402_3: Space = intersect(&(*CONSTANT_2),&(v402_2));
            let v402_4: Space = if has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
            drop(v402_3);
            let v402_5: Space = subtract(&(*CONSTANT_1),&(v402_4));
            drop(v402_4);
            let v402_7: Space = if (&(v402_5)).is_empty() { Space::new() } else {
              let v403_6: Space = routine_4(c, &v392_12_cursor.path()[(v392_12_origin + 2)..(v392_12_origin + 3)], &(v401_5), &v392_12_cursor, &(*s1));
              compose(&(v402_5),&(v403_6))
            };
            drop(v402_5);
            let v402_8: Space = intersect(&(*CONSTANT_2),&(v402_2));
            drop(v402_2);
            let v402_9: Space = if has_head(&(v402_8)) { singleton(&[]) } else { Space::new() };
            drop(v402_8);
            let v402_11: Space = if (&(v402_9)).is_empty() { Space::new() } else {
              let v404_10: Space = routine_5(c, &v392_12_cursor.path()[(v392_12_origin + 2)..(v392_12_origin + 3)], &(v401_5), &v392_12_cursor, &(*s1));
              compose(&(v402_9),&(v404_10))
            };
            drop(v402_9);
            let v402_12: Space = unite(&(v402_7),&(v402_11));
            join_wrapped_into(&mut v401_6_write,&((v402_12).read_zipper()),&[]);
            }
            v392_12_cursor.ascend(1);
          }
          drop(v401_6_write);
          drop(v401_5);
          compose(&(v400_4),&(v401_6))
        };
        drop(v400_4);
        join_wrapped_into(&mut v399_11_write,&((v400_7).read_zipper()),&[]);
        }
        v392_12_cursor.ascend(1);
      }
      drop(v399_11_write);
      drop(v399_6);
      compose(&(v393_10),&(v399_11))
    };
    drop(v393_10);
    let v393_13: Space = unite(&(v393_8),&(v393_12));
    join_wrapped_into(&mut v392_12_write,&((v393_13).read_zipper()),&[]);
    }
    v392_12_cursor.ascend(1);
  }
  drop(v392_12_cursor);
  drop(v392_12_write);
  (v392_12).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v405_17 = Space::new();
  let mut v405_17_write = v405_17.write_zipper();
  let mut v405_17_cursor = (*s0).read_zipper();
  let v405_17_origin = v405_17_cursor.path().len();
  for v405_17_byte in v405_17_cursor.child_mask().iter() {
    v405_17_cursor.descend_to_existing_byte(v405_17_byte);
    {
    let v406_2: Space = singleton(&v405_17_cursor.path()[v405_17_origin..(v405_17_origin + 1)]);
    let v406_3: Space = intersect(&(*CONSTANT_2),&(v406_2));
    let v406_4: Space = if has_head(&(v406_3)) { singleton(&[]) } else { Space::new() };
    drop(v406_3);
    let v406_5: Space = subtract(&(*CONSTANT_1),&(v406_4));
    drop(v406_4);
    let v406_8: Space = if (&(v406_5)).is_empty() { Space::new() } else {
      let v407_6: Path = concat_path(&(*p0),&v405_17_cursor.path()[v405_17_origin..(v405_17_origin + 1)]);
      let mut v407_7 = Space::new();
      let mut v407_7_write = v407_7.write_zipper();
      for v407_7_byte in v405_17_cursor.child_mask().iter() {
        v405_17_cursor.descend_to_existing_byte(v407_7_byte);
        {
        let v408_2: Space = singleton(&v405_17_cursor.path()[(v405_17_origin + 1)..(v405_17_origin + 2)]);
        let v408_3: Space = intersect(&(*CONSTANT_2),&(v408_2));
        drop(v408_2);
        let v408_4: Space = if has_head(&(v408_3)) { singleton(&[]) } else { Space::new() };
        drop(v408_3);
        let v408_7: Space = if (&(v408_4)).is_empty() { Space::new() } else {
          let v409_5: Path = concat_path(&(v407_6),&v405_17_cursor.path()[(v405_17_origin + 1)..(v405_17_origin + 2)]);
          let mut v409_6 = Space::new();
          let mut v409_6_write = v409_6.write_zipper();
          for v409_6_byte in v405_17_cursor.child_mask().iter() {
            v405_17_cursor.descend_to_existing_byte(v409_6_byte);
            {
            let v410_2: Space = singleton(&v405_17_cursor.path()[(v405_17_origin + 2)..(v405_17_origin + 3)]);
            let v410_3: Space = intersect(&(*CONSTANT_2),&(v410_2));
            drop(v410_2);
            let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
            drop(v410_3);
            let v410_7: Space = if (&(v410_4)).is_empty() { Space::new() } else {
              let v411_5: Path = concat_path(&(v409_5),&v405_17_cursor.path()[(v405_17_origin + 2)..(v405_17_origin + 3)]);
              let v411_6: Space = routine_3(c, &(v411_5), &v405_17_cursor, &(*s1));
              drop(v411_5);
              compose(&(v410_4),&(v411_6))
            };
            drop(v410_4);
            join_wrapped_into(&mut v409_6_write,&((v410_7).read_zipper()),&[]);
            }
            v405_17_cursor.ascend(1);
          }
          drop(v409_6_write);
          drop(v409_5);
          compose(&(v408_4),&(v409_6))
        };
        drop(v408_4);
        join_wrapped_into(&mut v407_7_write,&((v408_7).read_zipper()),&[]);
        }
        v405_17_cursor.ascend(1);
      }
      drop(v407_7_write);
      compose(&(v406_5),&(v407_7))
    };
    drop(v406_5);
    let v406_9: Space = intersect(&(*CONSTANT_2),&(v406_2));
    drop(v406_2);
    let v406_10: Space = if has_head(&(v406_9)) { singleton(&[]) } else { Space::new() };
    drop(v406_9);
    let v406_12: Space = if (&(v406_10)).is_empty() { Space::new() } else {
      let v412_6: Path = concat_path(&(*p0),&v405_17_cursor.path()[v405_17_origin..(v405_17_origin + 1)]);
      let mut v412_11 = Space::new();
      let mut v412_11_write = v412_11.write_zipper();
      for v412_11_byte in v405_17_cursor.child_mask().iter() {
        v405_17_cursor.descend_to_existing_byte(v412_11_byte);
        {
        let v413_2: Space = singleton(&v405_17_cursor.path()[(v405_17_origin + 1)..(v405_17_origin + 2)]);
        let v413_3: Space = intersect(&(*CONSTANT_2),&(v413_2));
        let v413_4: Space = if has_head(&(v413_3)) { singleton(&[]) } else { Space::new() };
        drop(v413_3);
        let v413_5: Space = subtract(&(*CONSTANT_1),&(v413_4));
        drop(v413_4);
        let v413_7: Space = if (&(v413_5)).is_empty() { Space::new() } else {
          let mut v414_6 = Space::new();
          let mut v414_6_write = v414_6.write_zipper();
          for v414_6_byte in v405_17_cursor.child_mask().iter() {
            v405_17_cursor.descend_to_existing_byte(v414_6_byte);
            {
            let v415_2: Space = singleton(&v405_17_cursor.path()[(v405_17_origin + 2)..(v405_17_origin + 3)]);
            let v415_3: Space = intersect(&(*CONSTANT_2),&(v415_2));
            let v415_4: Space = if has_head(&(v415_3)) { singleton(&[]) } else { Space::new() };
            drop(v415_3);
            let v415_5: Space = subtract(&(*CONSTANT_1),&(v415_4));
            drop(v415_4);
            let v415_8: Space = if (&(v415_5)).is_empty() { Space::new() } else {
              let v416_7: Space = routine_8(c, &v405_17_cursor.path()[(v405_17_origin + 1)..(v405_17_origin + 3)], &(v412_6), &v405_17_cursor, &(*s1));
              compose(&(v415_5),&(v416_7))
            };
            drop(v415_5);
            let v415_9: Space = intersect(&(*CONSTANT_2),&(v415_2));
            drop(v415_2);
            let v415_10: Space = if has_head(&(v415_9)) { singleton(&[]) } else { Space::new() };
            drop(v415_9);
            let v415_12: Space = if (&(v415_10)).is_empty() { Space::new() } else {
              let v417_11: Space = routine_9(c, &v405_17_cursor.path()[(v405_17_origin + 1)..(v405_17_origin + 3)], &(v412_6), &v405_17_cursor, &(*s1));
              compose(&(v415_10),&(v417_11))
            };
            drop(v415_10);
            let v415_13: Space = unite(&(v415_8),&(v415_12));
            join_wrapped_into(&mut v414_6_write,&((v415_13).read_zipper()),&[]);
            }
            v405_17_cursor.ascend(1);
          }
          drop(v414_6_write);
          compose(&(v413_5),&(v414_6))
        };
        drop(v413_5);
        let v413_8: Space = intersect(&(*CONSTANT_2),&(v413_2));
        drop(v413_2);
        let v413_9: Space = if has_head(&(v413_8)) { singleton(&[]) } else { Space::new() };
        drop(v413_8);
        let v413_11: Space = if (&(v413_9)).is_empty() { Space::new() } else {
          let mut v418_10 = Space::new();
          let mut v418_10_write = v418_10.write_zipper();
          for v418_10_byte in v405_17_cursor.child_mask().iter() {
            v405_17_cursor.descend_to_existing_byte(v418_10_byte);
            {
            let v419_2: Space = singleton(&v405_17_cursor.path()[(v405_17_origin + 2)..(v405_17_origin + 3)]);
            let v419_3: Space = intersect(&(*CONSTANT_2),&(v419_2));
            let v419_4: Space = if has_head(&(v419_3)) { singleton(&[]) } else { Space::new() };
            drop(v419_3);
            let v419_5: Space = subtract(&(*CONSTANT_1),&(v419_4));
            drop(v419_4);
            let v419_8: Space = if (&(v419_5)).is_empty() { Space::new() } else {
              let v420_7: Space = routine_8(c, &v405_17_cursor.path()[(v405_17_origin + 1)..(v405_17_origin + 3)], &(v412_6), &v405_17_cursor, &(*s1));
              compose(&(v419_5),&(v420_7))
            };
            drop(v419_5);
            let v419_9: Space = intersect(&(*CONSTANT_2),&(v419_2));
            drop(v419_2);
            let v419_10: Space = if has_head(&(v419_9)) { singleton(&[]) } else { Space::new() };
            drop(v419_9);
            let v419_12: Space = if (&(v419_10)).is_empty() { Space::new() } else {
              let v421_11: Space = routine_10(c, &v405_17_cursor.path()[(v405_17_origin + 1)..(v405_17_origin + 3)], &(v412_6), &v405_17_cursor, &(*s1));
              compose(&(v419_10),&(v421_11))
            };
            drop(v419_10);
            let v419_13: Space = unite(&(v419_8),&(v419_12));
            join_wrapped_into(&mut v418_10_write,&((v419_13).read_zipper()),&[]);
            }
            v405_17_cursor.ascend(1);
          }
          drop(v418_10_write);
          compose(&(v413_9),&(v418_10))
        };
        drop(v413_9);
        let v413_12: Space = unite(&(v413_7),&(v413_11));
        join_wrapped_into(&mut v412_11_write,&((v413_12).read_zipper()),&[]);
        }
        v405_17_cursor.ascend(1);
      }
      drop(v412_11_write);
      drop(v412_6);
      compose(&(v406_10),&(v412_11))
    };
    drop(v406_10);
    let v406_13: Space = unite(&(v406_8),&(v406_12));
    join_wrapped_into(&mut v405_17_write,&((v406_13).read_zipper()),&[]);
    }
    v405_17_cursor.ascend(1);
  }
  drop(v405_17_cursor);
  drop(v405_17_write);
  (v405_17).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v422_28 = Space::new();
  let mut v422_28_write = v422_28.write_zipper();
  let mut v422_28_cursor = (*s0).read_zipper();
  let v422_28_origin = v422_28_cursor.path().len();
  for v422_28_byte in v422_28_cursor.child_mask().iter() {
    v422_28_cursor.descend_to_existing_byte(v422_28_byte);
    {
    let v423_2: Space = singleton(&v422_28_cursor.path()[v422_28_origin..(v422_28_origin + 1)]);
    let v423_3: Space = intersect(&(*CONSTANT_2),&(v423_2));
    let v423_4: Space = if has_head(&(v423_3)) { singleton(&[]) } else { Space::new() };
    drop(v423_3);
    let v423_5: Space = subtract(&(*CONSTANT_1),&(v423_4));
    drop(v423_4);
    let v423_8: Space = if (&(v423_5)).is_empty() { Space::new() } else {
      let v424_6: Path = concat_path(&(*p0),&v422_28_cursor.path()[v422_28_origin..(v422_28_origin + 1)]);
      let mut v424_7 = Space::new();
      let mut v424_7_write = v424_7.write_zipper();
      for v424_7_byte in v422_28_cursor.child_mask().iter() {
        v422_28_cursor.descend_to_existing_byte(v424_7_byte);
        {
        let v425_2: Space = singleton(&v422_28_cursor.path()[(v422_28_origin + 1)..(v422_28_origin + 2)]);
        let v425_3: Space = intersect(&(*CONSTANT_2),&(v425_2));
        let v425_4: Space = if has_head(&(v425_3)) { singleton(&[]) } else { Space::new() };
        drop(v425_3);
        let v425_5: Space = subtract(&(*CONSTANT_1),&(v425_4));
        drop(v425_4);
        let v425_8: Space = if (&(v425_5)).is_empty() { Space::new() } else {
          let v426_6: Path = concat_path(&(v424_6),&v422_28_cursor.path()[(v422_28_origin + 1)..(v422_28_origin + 2)]);
          let mut v426_7 = Space::new();
          let mut v426_7_write = v426_7.write_zipper();
          for v426_7_byte in v422_28_cursor.child_mask().iter() {
            v422_28_cursor.descend_to_existing_byte(v426_7_byte);
            {
            let v427_2: Space = singleton(&v422_28_cursor.path()[(v422_28_origin + 2)..(v422_28_origin + 3)]);
            let v427_3: Space = intersect(&(*CONSTANT_2),&(v427_2));
            let v427_4: Space = if has_head(&(v427_3)) { singleton(&[]) } else { Space::new() };
            drop(v427_3);
            let v427_5: Space = subtract(&(*CONSTANT_1),&(v427_4));
            drop(v427_4);
            let v427_8: Space = if (&(v427_5)).is_empty() { Space::new() } else {
              let v428_6: Path = concat_path(&(v426_6),&v422_28_cursor.path()[(v422_28_origin + 2)..(v422_28_origin + 3)]);
              let v428_7: Space = routine_34(c, &(v428_6), &(*p1), &v422_28_cursor, &(*s1));
              compose(&(v427_5),&(v428_7))
            };
            drop(v427_5);
            let v427_9: Space = intersect(&(*CONSTANT_2),&(v427_2));
            drop(v427_2);
            let v427_10: Space = if has_head(&(v427_9)) { singleton(&[]) } else { Space::new() };
            drop(v427_9);
            let v427_12: Space = if (&(v427_10)).is_empty() { Space::new() } else {
              let v429_6: Path = concat_path(&(v426_6),&v422_28_cursor.path()[(v422_28_origin + 2)..(v422_28_origin + 3)]);
              let v429_11: Space = routine_35(c, &(v429_6), &(*p1), &v422_28_cursor, &(*s1));
              drop(v429_6);
              compose(&(v427_10),&(v429_11))
            };
            drop(v427_10);
            let v427_13: Space = unite(&(v427_8),&(v427_12));
            join_wrapped_into(&mut v426_7_write,&((v427_13).read_zipper()),&[]);
            }
            v422_28_cursor.ascend(1);
          }
          drop(v426_7_write);
          compose(&(v425_5),&(v426_7))
        };
        drop(v425_5);
        let v425_9: Space = intersect(&(*CONSTANT_2),&(v425_2));
        drop(v425_2);
        let v425_10: Space = if has_head(&(v425_9)) { singleton(&[]) } else { Space::new() };
        drop(v425_9);
        let v425_12: Space = if (&(v425_10)).is_empty() { Space::new() } else {
          let v430_6: Path = concat_path(&(v424_6),&v422_28_cursor.path()[(v422_28_origin + 1)..(v422_28_origin + 2)]);
          let mut v430_11 = Space::new();
          let mut v430_11_write = v430_11.write_zipper();
          for v430_11_byte in v422_28_cursor.child_mask().iter() {
            v422_28_cursor.descend_to_existing_byte(v430_11_byte);
            {
            let v431_2: Space = singleton(&v422_28_cursor.path()[(v422_28_origin + 2)..(v422_28_origin + 3)]);
            let v431_3: Space = intersect(&(*CONSTANT_2),&(v431_2));
            let v431_4: Space = if has_head(&(v431_3)) { singleton(&[]) } else { Space::new() };
            drop(v431_3);
            let v431_5: Space = subtract(&(*CONSTANT_1),&(v431_4));
            drop(v431_4);
            let v431_8: Space = if (&(v431_5)).is_empty() { Space::new() } else {
              let v432_6: Path = concat_path(&(v430_6),&v422_28_cursor.path()[(v422_28_origin + 2)..(v422_28_origin + 3)]);
              let v432_7: Space = routine_34(c, &(v432_6), &(*p1), &v422_28_cursor, &(*s1));
              compose(&(v431_5),&(v432_7))
            };
            drop(v431_5);
            let v431_9: Space = intersect(&(*CONSTANT_2),&(v431_2));
            drop(v431_2);
            let v431_10: Space = if has_head(&(v431_9)) { singleton(&[]) } else { Space::new() };
            drop(v431_9);
            let v431_12: Space = if (&(v431_10)).is_empty() { Space::new() } else {
              let v433_6: Path = concat_path(&(v430_6),&v422_28_cursor.path()[(v422_28_origin + 2)..(v422_28_origin + 3)]);
              let v433_11: Space = routine_10(c, &(v433_6), &(*p1), &v422_28_cursor, &(*s1));
              drop(v433_6);
              compose(&(v431_10),&(v433_11))
            };
            drop(v431_10);
            let v431_13: Space = unite(&(v431_8),&(v431_12));
            join_wrapped_into(&mut v430_11_write,&((v431_13).read_zipper()),&[]);
            }
            v422_28_cursor.ascend(1);
          }
          drop(v430_11_write);
          drop(v430_6);
          compose(&(v425_10),&(v430_11))
        };
        drop(v425_10);
        let v425_13: Space = unite(&(v425_8),&(v425_12));
        join_wrapped_into(&mut v424_7_write,&((v425_13).read_zipper()),&[]);
        }
        v422_28_cursor.ascend(1);
      }
      drop(v424_7_write);
      compose(&(v423_5),&(v424_7))
    };
    drop(v423_5);
    let v423_9: Space = intersect(&(*CONSTANT_2),&(v423_2));
    drop(v423_2);
    let v423_10: Space = if has_head(&(v423_9)) { singleton(&[]) } else { Space::new() };
    drop(v423_9);
    let v423_13: Space = if (&(v423_10)).is_empty() { Space::new() } else {
      let v434_6: Path = concat_path(&(*p0),&v422_28_cursor.path()[v422_28_origin..(v422_28_origin + 1)]);
      let mut v434_12 = Space::new();
      let mut v434_12_write = v434_12.write_zipper();
      for v434_12_byte in v422_28_cursor.child_mask().iter() {
        v422_28_cursor.descend_to_existing_byte(v434_12_byte);
        {
        let v435_2: Space = singleton(&v422_28_cursor.path()[(v422_28_origin + 1)..(v422_28_origin + 2)]);
        let v435_3: Space = intersect(&(*CONSTANT_2),&(v435_2));
        let v435_4: Space = if has_head(&(v435_3)) { singleton(&[]) } else { Space::new() };
        drop(v435_3);
        let v435_5: Space = subtract(&(*CONSTANT_1),&(v435_4));
        drop(v435_4);
        let v435_8: Space = if (&(v435_5)).is_empty() { Space::new() } else {
          let v436_6: Path = concat_path(&(v434_6),&v422_28_cursor.path()[(v422_28_origin + 1)..(v422_28_origin + 2)]);
          let mut v436_7 = Space::new();
          let mut v436_7_write = v436_7.write_zipper();
          for v436_7_byte in v422_28_cursor.child_mask().iter() {
            v422_28_cursor.descend_to_existing_byte(v436_7_byte);
            {
            let v437_2: Space = singleton(&v422_28_cursor.path()[(v422_28_origin + 2)..(v422_28_origin + 3)]);
            let v437_3: Space = intersect(&(*CONSTANT_2),&(v437_2));
            let v437_4: Space = if has_head(&(v437_3)) { singleton(&[]) } else { Space::new() };
            drop(v437_3);
            let v437_5: Space = subtract(&(*CONSTANT_1),&(v437_4));
            drop(v437_4);
            let v437_8: Space = if (&(v437_5)).is_empty() { Space::new() } else {
              let v438_6: Path = concat_path(&(v436_6),&v422_28_cursor.path()[(v422_28_origin + 2)..(v422_28_origin + 3)]);
              let v438_7: Space = routine_34(c, &(v438_6), &(*p1), &v422_28_cursor, &(*s1));
              compose(&(v437_5),&(v438_7))
            };
            drop(v437_5);
            let v437_9: Space = intersect(&(*CONSTANT_2),&(v437_2));
            drop(v437_2);
            let v437_10: Space = if has_head(&(v437_9)) { singleton(&[]) } else { Space::new() };
            drop(v437_9);
            let v437_12: Space = if (&(v437_10)).is_empty() { Space::new() } else {
              let v439_6: Path = concat_path(&(v436_6),&v422_28_cursor.path()[(v422_28_origin + 2)..(v422_28_origin + 3)]);
              let v439_11: Space = routine_35(c, &(v439_6), &(*p1), &v422_28_cursor, &(*s1));
              drop(v439_6);
              compose(&(v437_10),&(v439_11))
            };
            drop(v437_10);
            let v437_13: Space = unite(&(v437_8),&(v437_12));
            join_wrapped_into(&mut v436_7_write,&((v437_13).read_zipper()),&[]);
            }
            v422_28_cursor.ascend(1);
          }
          drop(v436_7_write);
          drop(v436_6);
          compose(&(v435_5),&(v436_7))
        };
        drop(v435_5);
        let v435_9: Space = intersect(&(*CONSTANT_2),&(v435_2));
        drop(v435_2);
        let v435_10: Space = if has_head(&(v435_9)) { singleton(&[]) } else { Space::new() };
        drop(v435_9);
        let v435_13: Space = if (&(v435_10)).is_empty() { Space::new() } else {
          let mut v440_12 = Space::new();
          let mut v440_12_write = v440_12.write_zipper();
          let mut v440_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v422_28_cursor.path()[v422_28_origin..(v422_28_origin + 1)]),&v422_28_cursor.path()[(v422_28_origin + 1)..(v422_28_origin + 2)]);
          let v440_12_origin = v440_12_cursor.path().len();
          for v440_12_byte in v440_12_cursor.child_mask().iter() {
            v440_12_cursor.descend_to_existing_byte(v440_12_byte);
            {
            let v441_2: Space = singleton(&v440_12_cursor.path()[v440_12_origin..(v440_12_origin + 1)]);
            let v441_3: Space = intersect(&(*CONSTANT_2),&(v441_2));
            let v441_4: Space = if has_head(&(v441_3)) { singleton(&[]) } else { Space::new() };
            drop(v441_3);
            let v441_5: Space = subtract(&(*CONSTANT_1),&(v441_4));
            drop(v441_4);
            let v441_7: Space = if (&(v441_5)).is_empty() { Space::new() } else {
              let v442_6: Space = routine_13(c, &v440_12_cursor.path()[v440_12_origin..(v440_12_origin + 1)], &(*p1), &v440_12_cursor);
              compose(&(v441_5),&(v442_6))
            };
            drop(v441_5);
            let v441_8: Space = intersect(&(*CONSTANT_2),&(v441_2));
            drop(v441_2);
            let v441_9: Space = if has_head(&(v441_8)) { singleton(&[]) } else { Space::new() };
            drop(v441_8);
            let v441_11: Space = if (&(v441_9)).is_empty() { Space::new() } else {
              let v443_10: Space = routine_14(c, &v440_12_cursor.path()[v440_12_origin..(v440_12_origin + 1)], &(*p1), &v440_12_cursor);
              compose(&(v441_9),&(v443_10))
            };
            drop(v441_9);
            let v441_12: Space = unite(&(v441_7),&(v441_11));
            join_wrapped_into(&mut v440_12_write,&((v441_12).read_zipper()),&[]);
            }
            v440_12_cursor.ascend(1);
          }
          drop(v440_12_cursor);
          drop(v440_12_write);
          compose(&(v435_10),&(v440_12))
        };
        drop(v435_10);
        let v435_14: Space = unite(&(v435_8),&(v435_13));
        join_wrapped_into(&mut v434_12_write,&((v435_14).read_zipper()),&[]);
        }
        v422_28_cursor.ascend(1);
      }
      drop(v434_12_write);
      drop(v434_6);
      compose(&(v423_10),&(v434_12))
    };
    drop(v423_10);
    let v423_14: Space = unite(&(v423_8),&(v423_13));
    join_wrapped_into(&mut v422_28_write,&((v423_14).read_zipper()),&[]);
    }
    v422_28_cursor.ascend(1);
  }
  drop(v422_28_cursor);
  drop(v422_28_write);
  (v422_28).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v444_28 = Space::new();
  let mut v444_28_write = v444_28.write_zipper();
  let mut v444_28_cursor = (*s0).read_zipper();
  let v444_28_origin = v444_28_cursor.path().len();
  for v444_28_byte in v444_28_cursor.child_mask().iter() {
    v444_28_cursor.descend_to_existing_byte(v444_28_byte);
    {
    let v445_2: Space = singleton(&v444_28_cursor.path()[v444_28_origin..(v444_28_origin + 1)]);
    let v445_3: Space = intersect(&(*CONSTANT_2),&(v445_2));
    let v445_4: Space = if has_head(&(v445_3)) { singleton(&[]) } else { Space::new() };
    drop(v445_3);
    let v445_5: Space = subtract(&(*CONSTANT_1),&(v445_4));
    drop(v445_4);
    let v445_8: Space = if (&(v445_5)).is_empty() { Space::new() } else {
      let v446_6: Path = concat_path(&(*p0),&v444_28_cursor.path()[v444_28_origin..(v444_28_origin + 1)]);
      let mut v446_7 = Space::new();
      let mut v446_7_write = v446_7.write_zipper();
      for v446_7_byte in v444_28_cursor.child_mask().iter() {
        v444_28_cursor.descend_to_existing_byte(v446_7_byte);
        {
        let v447_2: Space = singleton(&v444_28_cursor.path()[(v444_28_origin + 1)..(v444_28_origin + 2)]);
        let v447_3: Space = intersect(&(*CONSTANT_2),&(v447_2));
        let v447_4: Space = if has_head(&(v447_3)) { singleton(&[]) } else { Space::new() };
        drop(v447_3);
        let v447_5: Space = subtract(&(*CONSTANT_1),&(v447_4));
        drop(v447_4);
        let v447_8: Space = if (&(v447_5)).is_empty() { Space::new() } else {
          let v448_6: Path = concat_path(&(v446_6),&v444_28_cursor.path()[(v444_28_origin + 1)..(v444_28_origin + 2)]);
          let mut v448_7 = Space::new();
          let mut v448_7_write = v448_7.write_zipper();
          for v448_7_byte in v444_28_cursor.child_mask().iter() {
            v444_28_cursor.descend_to_existing_byte(v448_7_byte);
            {
            let v449_2: Space = singleton(&v444_28_cursor.path()[(v444_28_origin + 2)..(v444_28_origin + 3)]);
            let v449_3: Space = intersect(&(*CONSTANT_2),&(v449_2));
            let v449_4: Space = if has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
            drop(v449_3);
            let v449_5: Space = subtract(&(*CONSTANT_1),&(v449_4));
            drop(v449_4);
            let v449_8: Space = if (&(v449_5)).is_empty() { Space::new() } else {
              let v450_6: Path = concat_path(&(v448_6),&v444_28_cursor.path()[(v444_28_origin + 2)..(v444_28_origin + 3)]);
              let v450_7: Space = routine_34(c, &(v450_6), &(*p1), &v444_28_cursor, &(*s1));
              compose(&(v449_5),&(v450_7))
            };
            drop(v449_5);
            let v449_9: Space = intersect(&(*CONSTANT_2),&(v449_2));
            drop(v449_2);
            let v449_10: Space = if has_head(&(v449_9)) { singleton(&[]) } else { Space::new() };
            drop(v449_9);
            let v449_12: Space = if (&(v449_10)).is_empty() { Space::new() } else {
              let v451_6: Path = concat_path(&(v448_6),&v444_28_cursor.path()[(v444_28_origin + 2)..(v444_28_origin + 3)]);
              let v451_11: Space = routine_35(c, &(v451_6), &(*p1), &v444_28_cursor, &(*s1));
              drop(v451_6);
              compose(&(v449_10),&(v451_11))
            };
            drop(v449_10);
            let v449_13: Space = unite(&(v449_8),&(v449_12));
            join_wrapped_into(&mut v448_7_write,&((v449_13).read_zipper()),&[]);
            }
            v444_28_cursor.ascend(1);
          }
          drop(v448_7_write);
          compose(&(v447_5),&(v448_7))
        };
        drop(v447_5);
        let v447_9: Space = intersect(&(*CONSTANT_2),&(v447_2));
        drop(v447_2);
        let v447_10: Space = if has_head(&(v447_9)) { singleton(&[]) } else { Space::new() };
        drop(v447_9);
        let v447_12: Space = if (&(v447_10)).is_empty() { Space::new() } else {
          let v452_6: Path = concat_path(&(v446_6),&v444_28_cursor.path()[(v444_28_origin + 1)..(v444_28_origin + 2)]);
          let mut v452_11 = Space::new();
          let mut v452_11_write = v452_11.write_zipper();
          for v452_11_byte in v444_28_cursor.child_mask().iter() {
            v444_28_cursor.descend_to_existing_byte(v452_11_byte);
            {
            let v453_2: Space = singleton(&v444_28_cursor.path()[(v444_28_origin + 2)..(v444_28_origin + 3)]);
            let v453_3: Space = intersect(&(*CONSTANT_2),&(v453_2));
            let v453_4: Space = if has_head(&(v453_3)) { singleton(&[]) } else { Space::new() };
            drop(v453_3);
            let v453_5: Space = subtract(&(*CONSTANT_1),&(v453_4));
            drop(v453_4);
            let v453_8: Space = if (&(v453_5)).is_empty() { Space::new() } else {
              let v454_6: Path = concat_path(&(v452_6),&v444_28_cursor.path()[(v444_28_origin + 2)..(v444_28_origin + 3)]);
              let v454_7: Space = routine_34(c, &(v454_6), &(*p1), &v444_28_cursor, &(*s1));
              compose(&(v453_5),&(v454_7))
            };
            drop(v453_5);
            let v453_9: Space = intersect(&(*CONSTANT_2),&(v453_2));
            drop(v453_2);
            let v453_10: Space = if has_head(&(v453_9)) { singleton(&[]) } else { Space::new() };
            drop(v453_9);
            let v453_12: Space = if (&(v453_10)).is_empty() { Space::new() } else {
              let v455_6: Path = concat_path(&(v452_6),&v444_28_cursor.path()[(v444_28_origin + 2)..(v444_28_origin + 3)]);
              let v455_11: Space = routine_10(c, &(v455_6), &(*p1), &v444_28_cursor, &(*s1));
              drop(v455_6);
              compose(&(v453_10),&(v455_11))
            };
            drop(v453_10);
            let v453_13: Space = unite(&(v453_8),&(v453_12));
            join_wrapped_into(&mut v452_11_write,&((v453_13).read_zipper()),&[]);
            }
            v444_28_cursor.ascend(1);
          }
          drop(v452_11_write);
          drop(v452_6);
          compose(&(v447_10),&(v452_11))
        };
        drop(v447_10);
        let v447_13: Space = unite(&(v447_8),&(v447_12));
        join_wrapped_into(&mut v446_7_write,&((v447_13).read_zipper()),&[]);
        }
        v444_28_cursor.ascend(1);
      }
      drop(v446_7_write);
      drop(v446_6);
      compose(&(v445_5),&(v446_7))
    };
    drop(v445_5);
    let v445_9: Space = intersect(&(*CONSTANT_2),&(v445_2));
    drop(v445_2);
    let v445_10: Space = if has_head(&(v445_9)) { singleton(&[]) } else { Space::new() };
    drop(v445_9);
    let v445_13: Space = if (&(v445_10)).is_empty() { Space::new() } else {
      let mut v456_12 = Space::new();
      let mut v456_12_write = v456_12.write_zipper();
      let mut v456_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v444_28_cursor.path()[v444_28_origin..(v444_28_origin + 1)]);
      let v456_12_origin = v456_12_cursor.path().len();
      for v456_12_byte in v456_12_cursor.child_mask().iter() {
        v456_12_cursor.descend_to_existing_byte(v456_12_byte);
        {
        let v457_2: Space = singleton(&v456_12_cursor.path()[v456_12_origin..(v456_12_origin + 1)]);
        let v457_3: Space = intersect(&(*CONSTANT_2),&(v457_2));
        let v457_4: Space = if has_head(&(v457_3)) { singleton(&[]) } else { Space::new() };
        drop(v457_3);
        let v457_5: Space = subtract(&(*CONSTANT_1),&(v457_4));
        drop(v457_4);
        let v457_7: Space = if (&(v457_5)).is_empty() { Space::new() } else {
          let mut v458_6 = Space::new();
          let mut v458_6_write = v458_6.write_zipper();
          for v458_6_byte in v456_12_cursor.child_mask().iter() {
            v456_12_cursor.descend_to_existing_byte(v458_6_byte);
            {
            let v459_2: Space = singleton(&v456_12_cursor.path()[(v456_12_origin + 1)..(v456_12_origin + 2)]);
            let v459_3: Space = intersect(&(*CONSTANT_2),&(v459_2));
            let v459_4: Space = if has_head(&(v459_3)) { singleton(&[]) } else { Space::new() };
            drop(v459_3);
            let v459_5: Space = subtract(&(*CONSTANT_1),&(v459_4));
            drop(v459_4);
            let v459_8: Space = if (&(v459_5)).is_empty() { Space::new() } else {
              let v460_7: Space = routine_17(c, &v456_12_cursor.path()[v456_12_origin..(v456_12_origin + 2)], &(*p1), &v456_12_cursor);
              compose(&(v459_5),&(v460_7))
            };
            drop(v459_5);
            let v459_9: Space = intersect(&(*CONSTANT_2),&(v459_2));
            drop(v459_2);
            let v459_10: Space = if has_head(&(v459_9)) { singleton(&[]) } else { Space::new() };
            drop(v459_9);
            let v459_12: Space = if (&(v459_10)).is_empty() { Space::new() } else {
              let v461_11: Space = routine_18(c, &v456_12_cursor.path()[v456_12_origin..(v456_12_origin + 2)], &(*p1), &v456_12_cursor);
              compose(&(v459_10),&(v461_11))
            };
            drop(v459_10);
            let v459_13: Space = unite(&(v459_8),&(v459_12));
            join_wrapped_into(&mut v458_6_write,&((v459_13).read_zipper()),&[]);
            }
            v456_12_cursor.ascend(1);
          }
          drop(v458_6_write);
          compose(&(v457_5),&(v458_6))
        };
        drop(v457_5);
        let v457_8: Space = intersect(&(*CONSTANT_2),&(v457_2));
        drop(v457_2);
        let v457_9: Space = if has_head(&(v457_8)) { singleton(&[]) } else { Space::new() };
        drop(v457_8);
        let v457_11: Space = if (&(v457_9)).is_empty() { Space::new() } else {
          let mut v462_10 = Space::new();
          let mut v462_10_write = v462_10.write_zipper();
          for v462_10_byte in v456_12_cursor.child_mask().iter() {
            v456_12_cursor.descend_to_existing_byte(v462_10_byte);
            {
            let v463_2: Space = singleton(&v456_12_cursor.path()[(v456_12_origin + 1)..(v456_12_origin + 2)]);
            let v463_3: Space = intersect(&(*CONSTANT_2),&(v463_2));
            let v463_4: Space = if has_head(&(v463_3)) { singleton(&[]) } else { Space::new() };
            drop(v463_3);
            let v463_5: Space = subtract(&(*CONSTANT_1),&(v463_4));
            drop(v463_4);
            let v463_8: Space = if (&(v463_5)).is_empty() { Space::new() } else {
              let v464_7: Space = routine_17(c, &v456_12_cursor.path()[v456_12_origin..(v456_12_origin + 2)], &(*p1), &v456_12_cursor);
              compose(&(v463_5),&(v464_7))
            };
            drop(v463_5);
            let v463_9: Space = intersect(&(*CONSTANT_2),&(v463_2));
            drop(v463_2);
            let v463_10: Space = if has_head(&(v463_9)) { singleton(&[]) } else { Space::new() };
            drop(v463_9);
            let v463_12: Space = if (&(v463_10)).is_empty() { Space::new() } else {
              let v465_11: Space = routine_19(c, &v456_12_cursor.path()[v456_12_origin..(v456_12_origin + 2)], &(*p1), &v456_12_cursor);
              compose(&(v463_10),&(v465_11))
            };
            drop(v463_10);
            let v463_13: Space = unite(&(v463_8),&(v463_12));
            join_wrapped_into(&mut v462_10_write,&((v463_13).read_zipper()),&[]);
            }
            v456_12_cursor.ascend(1);
          }
          drop(v462_10_write);
          compose(&(v457_9),&(v462_10))
        };
        drop(v457_9);
        let v457_12: Space = unite(&(v457_7),&(v457_11));
        join_wrapped_into(&mut v456_12_write,&((v457_12).read_zipper()),&[]);
        }
        v456_12_cursor.ascend(1);
      }
      drop(v456_12_cursor);
      drop(v456_12_write);
      compose(&(v445_10),&(v456_12))
    };
    drop(v445_10);
    let v445_14: Space = unite(&(v445_8),&(v445_13));
    join_wrapped_into(&mut v444_28_write,&((v445_14).read_zipper()),&[]);
    }
    v444_28_cursor.ascend(1);
  }
  drop(v444_28_cursor);
  drop(v444_28_write);
  (v444_28).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v466_21 = Space::new();
  let mut v466_21_write = v466_21.write_zipper();
  let mut v466_21_cursor = (*s0).read_zipper();
  let v466_21_origin = v466_21_cursor.path().len();
  for v466_21_byte in v466_21_cursor.child_mask().iter() {
    v466_21_cursor.descend_to_existing_byte(v466_21_byte);
    {
    let v467_2: Space = singleton(&v466_21_cursor.path()[v466_21_origin..(v466_21_origin + 1)]);
    let v467_3: Space = intersect(&(*CONSTANT_2),&(v467_2));
    let v467_4: Space = if has_head(&(v467_3)) { singleton(&[]) } else { Space::new() };
    drop(v467_3);
    let v467_5: Space = subtract(&(*CONSTANT_1),&(v467_4));
    drop(v467_4);
    let v467_8: Space = if (&(v467_5)).is_empty() { Space::new() } else {
      let v468_6: Path = concat_path(&(*p0),&v466_21_cursor.path()[v466_21_origin..(v466_21_origin + 1)]);
      let mut v468_7 = Space::new();
      let mut v468_7_write = v468_7.write_zipper();
      for v468_7_byte in v466_21_cursor.child_mask().iter() {
        v466_21_cursor.descend_to_existing_byte(v468_7_byte);
        {
        let v469_2: Space = singleton(&v466_21_cursor.path()[(v466_21_origin + 1)..(v466_21_origin + 2)]);
        let v469_3: Space = intersect(&(*CONSTANT_2),&(v469_2));
        let v469_4: Space = if has_head(&(v469_3)) { singleton(&[]) } else { Space::new() };
        drop(v469_3);
        let v469_5: Space = subtract(&(*CONSTANT_1),&(v469_4));
        drop(v469_4);
        let v469_8: Space = if (&(v469_5)).is_empty() { Space::new() } else {
          let v470_6: Path = concat_path(&(v468_6),&v466_21_cursor.path()[(v466_21_origin + 1)..(v466_21_origin + 2)]);
          let mut v470_7 = Space::new();
          let mut v470_7_write = v470_7.write_zipper();
          for v470_7_byte in v466_21_cursor.child_mask().iter() {
            v466_21_cursor.descend_to_existing_byte(v470_7_byte);
            {
            let v471_2: Space = singleton(&v466_21_cursor.path()[(v466_21_origin + 2)..(v466_21_origin + 3)]);
            let v471_3: Space = intersect(&(*CONSTANT_2),&(v471_2));
            let v471_4: Space = if has_head(&(v471_3)) { singleton(&[]) } else { Space::new() };
            drop(v471_3);
            let v471_5: Space = subtract(&(*CONSTANT_1),&(v471_4));
            drop(v471_4);
            let v471_8: Space = if (&(v471_5)).is_empty() { Space::new() } else {
              let v472_6: Path = concat_path(&(v470_6),&v466_21_cursor.path()[(v466_21_origin + 2)..(v466_21_origin + 3)]);
              let v472_7: Space = routine_36(c, &(v472_6), &(*p1), &v466_21_cursor);
              compose(&(v471_5),&(v472_7))
            };
            drop(v471_5);
            let v471_9: Space = intersect(&(*CONSTANT_2),&(v471_2));
            drop(v471_2);
            let v471_10: Space = if has_head(&(v471_9)) { singleton(&[]) } else { Space::new() };
            drop(v471_9);
            let v471_12: Space = if (&(v471_10)).is_empty() { Space::new() } else {
              let v473_6: Path = concat_path(&(v470_6),&v466_21_cursor.path()[(v466_21_origin + 2)..(v466_21_origin + 3)]);
              let v473_11: Space = routine_37(c, &(v473_6), &(*p1), &v466_21_cursor);
              drop(v473_6);
              compose(&(v471_10),&(v473_11))
            };
            drop(v471_10);
            let v471_13: Space = unite(&(v471_8),&(v471_12));
            join_wrapped_into(&mut v470_7_write,&((v471_13).read_zipper()),&[]);
            }
            v466_21_cursor.ascend(1);
          }
          drop(v470_7_write);
          compose(&(v469_5),&(v470_7))
        };
        drop(v469_5);
        let v469_9: Space = intersect(&(*CONSTANT_2),&(v469_2));
        drop(v469_2);
        let v469_10: Space = if has_head(&(v469_9)) { singleton(&[]) } else { Space::new() };
        drop(v469_9);
        let v469_12: Space = if (&(v469_10)).is_empty() { Space::new() } else {
          let v474_6: Path = concat_path(&(v468_6),&v466_21_cursor.path()[(v466_21_origin + 1)..(v466_21_origin + 2)]);
          let mut v474_11 = Space::new();
          let mut v474_11_write = v474_11.write_zipper();
          for v474_11_byte in v466_21_cursor.child_mask().iter() {
            v466_21_cursor.descend_to_existing_byte(v474_11_byte);
            {
            let v475_2: Space = singleton(&v466_21_cursor.path()[(v466_21_origin + 2)..(v466_21_origin + 3)]);
            let v475_3: Space = intersect(&(*CONSTANT_2),&(v475_2));
            let v475_4: Space = if has_head(&(v475_3)) { singleton(&[]) } else { Space::new() };
            drop(v475_3);
            let v475_5: Space = subtract(&(*CONSTANT_1),&(v475_4));
            drop(v475_4);
            let v475_8: Space = if (&(v475_5)).is_empty() { Space::new() } else {
              let v476_6: Path = concat_path(&(v474_6),&v466_21_cursor.path()[(v466_21_origin + 2)..(v466_21_origin + 3)]);
              let v476_7: Space = routine_36(c, &(v476_6), &(*p1), &v466_21_cursor);
              compose(&(v475_5),&(v476_7))
            };
            drop(v475_5);
            let v475_9: Space = intersect(&(*CONSTANT_2),&(v475_2));
            drop(v475_2);
            let v475_10: Space = if has_head(&(v475_9)) { singleton(&[]) } else { Space::new() };
            drop(v475_9);
            let v475_12: Space = if (&(v475_10)).is_empty() { Space::new() } else {
              let v477_6: Path = concat_path(&(v474_6),&v466_21_cursor.path()[(v466_21_origin + 2)..(v466_21_origin + 3)]);
              let v477_11: Space = routine_19(c, &(v477_6), &(*p1), &v466_21_cursor);
              drop(v477_6);
              compose(&(v475_10),&(v477_11))
            };
            drop(v475_10);
            let v475_13: Space = unite(&(v475_8),&(v475_12));
            join_wrapped_into(&mut v474_11_write,&((v475_13).read_zipper()),&[]);
            }
            v466_21_cursor.ascend(1);
          }
          drop(v474_11_write);
          drop(v474_6);
          compose(&(v469_10),&(v474_11))
        };
        drop(v469_10);
        let v469_13: Space = unite(&(v469_8),&(v469_12));
        join_wrapped_into(&mut v468_7_write,&((v469_13).read_zipper()),&[]);
        }
        v466_21_cursor.ascend(1);
      }
      drop(v468_7_write);
      compose(&(v467_5),&(v468_7))
    };
    drop(v467_5);
    let v467_9: Space = intersect(&(*CONSTANT_2),&(v467_2));
    drop(v467_2);
    let v467_10: Space = if has_head(&(v467_9)) { singleton(&[]) } else { Space::new() };
    drop(v467_9);
    let v467_12: Space = if (&(v467_10)).is_empty() { Space::new() } else {
      let v478_6: Path = concat_path(&(*p0),&v466_21_cursor.path()[v466_21_origin..(v466_21_origin + 1)]);
      let mut v478_11 = Space::new();
      let mut v478_11_write = v478_11.write_zipper();
      for v478_11_byte in v466_21_cursor.child_mask().iter() {
        v466_21_cursor.descend_to_existing_byte(v478_11_byte);
        {
        let v479_2: Space = singleton(&v466_21_cursor.path()[(v466_21_origin + 1)..(v466_21_origin + 2)]);
        let v479_3: Space = intersect(&(*CONSTANT_2),&(v479_2));
        let v479_4: Space = if has_head(&(v479_3)) { singleton(&[]) } else { Space::new() };
        drop(v479_3);
        let v479_5: Space = subtract(&(*CONSTANT_1),&(v479_4));
        drop(v479_4);
        let v479_8: Space = if (&(v479_5)).is_empty() { Space::new() } else {
          let v480_6: Path = concat_path(&(v478_6),&v466_21_cursor.path()[(v466_21_origin + 1)..(v466_21_origin + 2)]);
          let mut v480_7 = Space::new();
          let mut v480_7_write = v480_7.write_zipper();
          for v480_7_byte in v466_21_cursor.child_mask().iter() {
            v466_21_cursor.descend_to_existing_byte(v480_7_byte);
            {
            let v481_2: Space = singleton(&v466_21_cursor.path()[(v466_21_origin + 2)..(v466_21_origin + 3)]);
            let v481_3: Space = intersect(&(*CONSTANT_2),&(v481_2));
            let v481_4: Space = if has_head(&(v481_3)) { singleton(&[]) } else { Space::new() };
            drop(v481_3);
            let v481_5: Space = subtract(&(*CONSTANT_1),&(v481_4));
            drop(v481_4);
            let v481_8: Space = if (&(v481_5)).is_empty() { Space::new() } else {
              let v482_6: Path = concat_path(&(v480_6),&v466_21_cursor.path()[(v466_21_origin + 2)..(v466_21_origin + 3)]);
              let v482_7: Space = routine_36(c, &(v482_6), &(*p1), &v466_21_cursor);
              compose(&(v481_5),&(v482_7))
            };
            drop(v481_5);
            let v481_9: Space = intersect(&(*CONSTANT_2),&(v481_2));
            drop(v481_2);
            let v481_10: Space = if has_head(&(v481_9)) { singleton(&[]) } else { Space::new() };
            drop(v481_9);
            let v481_12: Space = if (&(v481_10)).is_empty() { Space::new() } else {
              let v483_6: Path = concat_path(&(v480_6),&v466_21_cursor.path()[(v466_21_origin + 2)..(v466_21_origin + 3)]);
              let v483_11: Space = routine_37(c, &(v483_6), &(*p1), &v466_21_cursor);
              drop(v483_6);
              compose(&(v481_10),&(v483_11))
            };
            drop(v481_10);
            let v481_13: Space = unite(&(v481_8),&(v481_12));
            join_wrapped_into(&mut v480_7_write,&((v481_13).read_zipper()),&[]);
            }
            v466_21_cursor.ascend(1);
          }
          drop(v480_7_write);
          compose(&(v479_5),&(v480_7))
        };
        drop(v479_5);
        let v479_9: Space = intersect(&(*CONSTANT_2),&(v479_2));
        drop(v479_2);
        let v479_10: Space = if has_head(&(v479_9)) { singleton(&[]) } else { Space::new() };
        drop(v479_9);
        let v479_11: Space = compose(&(v479_10),&v466_21_cursor);
        drop(v479_10);
        let v484_6: Path = concat_path(&(v478_6),&v466_21_cursor.path()[(v466_21_origin + 1)..(v466_21_origin + 2)]);
        let v479_12: Space = wrap(&(v479_11),&(v484_6));
        drop(v479_11);
        let v479_13: Space = wrap(&(v479_12),&(*p1));
        drop(v479_12);
        let v479_14: Space = unite(&(v479_8),&(v479_13));
        drop(v479_13);
        join_wrapped_into(&mut v478_11_write,&((v479_14).read_zipper()),&[]);
        }
        v466_21_cursor.ascend(1);
      }
      drop(v478_11_write);
      drop(v478_6);
      compose(&(v467_10),&(v478_11))
    };
    drop(v467_10);
    let v467_13: Space = unite(&(v467_8),&(v467_12));
    join_wrapped_into(&mut v466_21_write,&((v467_13).read_zipper()),&[]);
    }
    v466_21_cursor.ascend(1);
  }
  drop(v466_21_cursor);
  drop(v466_21_write);
  (v466_21).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v485_15 = Space::new();
  let mut v485_15_write = v485_15.write_zipper();
  let mut v485_15_cursor = (*s0).read_zipper();
  let v485_15_origin = v485_15_cursor.path().len();
  for v485_15_byte in v485_15_cursor.child_mask().iter() {
    v485_15_cursor.descend_to_existing_byte(v485_15_byte);
    {
    let v486_2: Space = singleton(&v485_15_cursor.path()[v485_15_origin..(v485_15_origin + 1)]);
    let v486_3: Space = intersect(&(*CONSTANT_2),&(v486_2));
    let v486_4: Space = if has_head(&(v486_3)) { singleton(&[]) } else { Space::new() };
    drop(v486_3);
    let v486_5: Space = subtract(&(*CONSTANT_1),&(v486_4));
    drop(v486_4);
    let v486_8: Space = if (&(v486_5)).is_empty() { Space::new() } else {
      let v487_6: Path = concat_path(&(*p0),&v485_15_cursor.path()[v485_15_origin..(v485_15_origin + 1)]);
      let mut v487_7 = Space::new();
      let mut v487_7_write = v487_7.write_zipper();
      for v487_7_byte in v485_15_cursor.child_mask().iter() {
        v485_15_cursor.descend_to_existing_byte(v487_7_byte);
        {
        let v488_2: Space = singleton(&v485_15_cursor.path()[(v485_15_origin + 1)..(v485_15_origin + 2)]);
        let v488_3: Space = intersect(&(*CONSTANT_2),&(v488_2));
        let v488_4: Space = if has_head(&(v488_3)) { singleton(&[]) } else { Space::new() };
        drop(v488_3);
        let v488_5: Space = subtract(&(*CONSTANT_1),&(v488_4));
        drop(v488_4);
        let v488_8: Space = if (&(v488_5)).is_empty() { Space::new() } else {
          let v489_6: Path = concat_path(&(v487_6),&v485_15_cursor.path()[(v485_15_origin + 1)..(v485_15_origin + 2)]);
          let mut v489_7 = Space::new();
          let mut v489_7_write = v489_7.write_zipper();
          for v489_7_byte in v485_15_cursor.child_mask().iter() {
            v485_15_cursor.descend_to_existing_byte(v489_7_byte);
            {
            let v490_2: Space = singleton(&v485_15_cursor.path()[(v485_15_origin + 2)..(v485_15_origin + 3)]);
            let v490_3: Space = intersect(&(*CONSTANT_2),&(v490_2));
            let v490_4: Space = if has_head(&(v490_3)) { singleton(&[]) } else { Space::new() };
            drop(v490_3);
            let v490_5: Space = subtract(&(*CONSTANT_1),&(v490_4));
            drop(v490_4);
            let v490_8: Space = if (&(v490_5)).is_empty() { Space::new() } else {
              let v491_6: Path = concat_path(&(v489_6),&v485_15_cursor.path()[(v485_15_origin + 2)..(v485_15_origin + 3)]);
              let v491_7: Space = routine_36(c, &(v491_6), &(*p1), &v485_15_cursor);
              compose(&(v490_5),&(v491_7))
            };
            drop(v490_5);
            let v490_9: Space = intersect(&(*CONSTANT_2),&(v490_2));
            drop(v490_2);
            let v490_10: Space = if has_head(&(v490_9)) { singleton(&[]) } else { Space::new() };
            drop(v490_9);
            let v490_12: Space = if (&(v490_10)).is_empty() { Space::new() } else {
              let v492_6: Path = concat_path(&(v489_6),&v485_15_cursor.path()[(v485_15_origin + 2)..(v485_15_origin + 3)]);
              let v492_11: Space = routine_37(c, &(v492_6), &(*p1), &v485_15_cursor);
              drop(v492_6);
              compose(&(v490_10),&(v492_11))
            };
            drop(v490_10);
            let v490_13: Space = unite(&(v490_8),&(v490_12));
            join_wrapped_into(&mut v489_7_write,&((v490_13).read_zipper()),&[]);
            }
            v485_15_cursor.ascend(1);
          }
          drop(v489_7_write);
          compose(&(v488_5),&(v489_7))
        };
        drop(v488_5);
        let v488_9: Space = intersect(&(*CONSTANT_2),&(v488_2));
        drop(v488_2);
        let v488_10: Space = if has_head(&(v488_9)) { singleton(&[]) } else { Space::new() };
        drop(v488_9);
        let v488_12: Space = if (&(v488_10)).is_empty() { Space::new() } else {
          let v493_6: Path = concat_path(&(v487_6),&v485_15_cursor.path()[(v485_15_origin + 1)..(v485_15_origin + 2)]);
          let mut v493_11 = Space::new();
          let mut v493_11_write = v493_11.write_zipper();
          for v493_11_byte in v485_15_cursor.child_mask().iter() {
            v485_15_cursor.descend_to_existing_byte(v493_11_byte);
            {
            let v494_2: Space = singleton(&v485_15_cursor.path()[(v485_15_origin + 2)..(v485_15_origin + 3)]);
            let v494_3: Space = intersect(&(*CONSTANT_2),&(v494_2));
            let v494_4: Space = if has_head(&(v494_3)) { singleton(&[]) } else { Space::new() };
            drop(v494_3);
            let v494_5: Space = subtract(&(*CONSTANT_1),&(v494_4));
            drop(v494_4);
            let v494_8: Space = if (&(v494_5)).is_empty() { Space::new() } else {
              let v495_6: Path = concat_path(&(v493_6),&v485_15_cursor.path()[(v485_15_origin + 2)..(v485_15_origin + 3)]);
              let v495_7: Space = routine_36(c, &(v495_6), &(*p1), &v485_15_cursor);
              compose(&(v494_5),&(v495_7))
            };
            drop(v494_5);
            let v494_9: Space = intersect(&(*CONSTANT_2),&(v494_2));
            drop(v494_2);
            let v494_10: Space = if has_head(&(v494_9)) { singleton(&[]) } else { Space::new() };
            drop(v494_9);
            let v494_12: Space = if (&(v494_10)).is_empty() { Space::new() } else {
              let v496_6: Path = concat_path(&(v493_6),&v485_15_cursor.path()[(v485_15_origin + 2)..(v485_15_origin + 3)]);
              let v496_11: Space = routine_19(c, &(v496_6), &(*p1), &v485_15_cursor);
              drop(v496_6);
              compose(&(v494_10),&(v496_11))
            };
            drop(v494_10);
            let v494_13: Space = unite(&(v494_8),&(v494_12));
            join_wrapped_into(&mut v493_11_write,&((v494_13).read_zipper()),&[]);
            }
            v485_15_cursor.ascend(1);
          }
          drop(v493_11_write);
          drop(v493_6);
          compose(&(v488_10),&(v493_11))
        };
        drop(v488_10);
        let v488_13: Space = unite(&(v488_8),&(v488_12));
        join_wrapped_into(&mut v487_7_write,&((v488_13).read_zipper()),&[]);
        }
        v485_15_cursor.ascend(1);
      }
      drop(v487_7_write);
      compose(&(v486_5),&(v487_7))
    };
    drop(v486_5);
    let v486_9: Space = intersect(&(*CONSTANT_2),&(v486_2));
    drop(v486_2);
    let v486_10: Space = if has_head(&(v486_9)) { singleton(&[]) } else { Space::new() };
    drop(v486_9);
    let v486_11: Space = compose(&(v486_10),&v485_15_cursor);
    drop(v486_10);
    let v497_6: Path = concat_path(&(*p0),&v485_15_cursor.path()[v485_15_origin..(v485_15_origin + 1)]);
    let v486_12: Space = wrap(&(v486_11),&(v497_6));
    drop(v486_11);
    let v486_13: Space = wrap(&(v486_12),&(*p1));
    drop(v486_12);
    let v486_14: Space = unite(&(v486_8),&(v486_13));
    drop(v486_13);
    join_wrapped_into(&mut v485_15_write,&((v486_14).read_zipper()),&[]);
    }
    v485_15_cursor.ascend(1);
  }
  drop(v485_15_cursor);
  drop(v485_15_write);
  (v485_15).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v498_28 = Space::new();
  let mut v498_28_write = v498_28.write_zipper();
  let mut v498_28_cursor = (*s0).read_zipper();
  let v498_28_origin = v498_28_cursor.path().len();
  for v498_28_byte in v498_28_cursor.child_mask().iter() {
    v498_28_cursor.descend_to_existing_byte(v498_28_byte);
    {
    let v499_2: Space = singleton(&v498_28_cursor.path()[v498_28_origin..(v498_28_origin + 1)]);
    let v499_3: Space = intersect(&(*CONSTANT_2),&(v499_2));
    let v499_4: Space = if has_head(&(v499_3)) { singleton(&[]) } else { Space::new() };
    drop(v499_3);
    let v499_5: Space = subtract(&(*CONSTANT_1),&(v499_4));
    drop(v499_4);
    let v499_8: Space = if (&(v499_5)).is_empty() { Space::new() } else {
      let v500_6: Path = concat_path(&(*p0),&v498_28_cursor.path()[v498_28_origin..(v498_28_origin + 1)]);
      let mut v500_7 = Space::new();
      let mut v500_7_write = v500_7.write_zipper();
      for v500_7_byte in v498_28_cursor.child_mask().iter() {
        v498_28_cursor.descend_to_existing_byte(v500_7_byte);
        {
        let v501_2: Space = singleton(&v498_28_cursor.path()[(v498_28_origin + 1)..(v498_28_origin + 2)]);
        let v501_3: Space = intersect(&(*CONSTANT_2),&(v501_2));
        let v501_4: Space = if has_head(&(v501_3)) { singleton(&[]) } else { Space::new() };
        drop(v501_3);
        let v501_5: Space = subtract(&(*CONSTANT_1),&(v501_4));
        drop(v501_4);
        let v501_8: Space = if (&(v501_5)).is_empty() { Space::new() } else {
          let v502_6: Path = concat_path(&(v500_6),&v498_28_cursor.path()[(v498_28_origin + 1)..(v498_28_origin + 2)]);
          let mut v502_7 = Space::new();
          let mut v502_7_write = v502_7.write_zipper();
          for v502_7_byte in v498_28_cursor.child_mask().iter() {
            v498_28_cursor.descend_to_existing_byte(v502_7_byte);
            {
            let v503_2: Space = singleton(&v498_28_cursor.path()[(v498_28_origin + 2)..(v498_28_origin + 3)]);
            let v503_3: Space = intersect(&(*CONSTANT_2),&(v503_2));
            let v503_4: Space = if has_head(&(v503_3)) { singleton(&[]) } else { Space::new() };
            drop(v503_3);
            let v503_5: Space = subtract(&(*CONSTANT_1),&(v503_4));
            drop(v503_4);
            let v503_8: Space = if (&(v503_5)).is_empty() { Space::new() } else {
              let v504_6: Path = concat_path(&(v502_6),&v498_28_cursor.path()[(v498_28_origin + 2)..(v498_28_origin + 3)]);
              let v504_7: Space = routine_38(c, &(v504_6), &(*p1), &v498_28_cursor, &(*s1));
              compose(&(v503_5),&(v504_7))
            };
            drop(v503_5);
            let v503_9: Space = intersect(&(*CONSTANT_2),&(v503_2));
            drop(v503_2);
            let v503_10: Space = if has_head(&(v503_9)) { singleton(&[]) } else { Space::new() };
            drop(v503_9);
            let v503_12: Space = if (&(v503_10)).is_empty() { Space::new() } else {
              let v505_6: Path = concat_path(&(v502_6),&v498_28_cursor.path()[(v498_28_origin + 2)..(v498_28_origin + 3)]);
              let v505_11: Space = routine_39(c, &(v505_6), &(*p1), &v498_28_cursor, &(*s1));
              drop(v505_6);
              compose(&(v503_10),&(v505_11))
            };
            drop(v503_10);
            let v503_13: Space = unite(&(v503_8),&(v503_12));
            join_wrapped_into(&mut v502_7_write,&((v503_13).read_zipper()),&[]);
            }
            v498_28_cursor.ascend(1);
          }
          drop(v502_7_write);
          compose(&(v501_5),&(v502_7))
        };
        drop(v501_5);
        let v501_9: Space = intersect(&(*CONSTANT_2),&(v501_2));
        drop(v501_2);
        let v501_10: Space = if has_head(&(v501_9)) { singleton(&[]) } else { Space::new() };
        drop(v501_9);
        let v501_12: Space = if (&(v501_10)).is_empty() { Space::new() } else {
          let v506_6: Path = concat_path(&(v500_6),&v498_28_cursor.path()[(v498_28_origin + 1)..(v498_28_origin + 2)]);
          let mut v506_11 = Space::new();
          let mut v506_11_write = v506_11.write_zipper();
          for v506_11_byte in v498_28_cursor.child_mask().iter() {
            v498_28_cursor.descend_to_existing_byte(v506_11_byte);
            {
            let v507_2: Space = singleton(&v498_28_cursor.path()[(v498_28_origin + 2)..(v498_28_origin + 3)]);
            let v507_3: Space = intersect(&(*CONSTANT_2),&(v507_2));
            let v507_4: Space = if has_head(&(v507_3)) { singleton(&[]) } else { Space::new() };
            drop(v507_3);
            let v507_5: Space = subtract(&(*CONSTANT_1),&(v507_4));
            drop(v507_4);
            let v507_8: Space = if (&(v507_5)).is_empty() { Space::new() } else {
              let v508_6: Path = concat_path(&(v506_6),&v498_28_cursor.path()[(v498_28_origin + 2)..(v498_28_origin + 3)]);
              let v508_7: Space = routine_38(c, &(v508_6), &(*p1), &v498_28_cursor, &(*s1));
              compose(&(v507_5),&(v508_7))
            };
            drop(v507_5);
            let v507_9: Space = intersect(&(*CONSTANT_2),&(v507_2));
            drop(v507_2);
            let v507_10: Space = if has_head(&(v507_9)) { singleton(&[]) } else { Space::new() };
            drop(v507_9);
            let v507_12: Space = if (&(v507_10)).is_empty() { Space::new() } else {
              let v509_6: Path = concat_path(&(v506_6),&v498_28_cursor.path()[(v498_28_origin + 2)..(v498_28_origin + 3)]);
              let v509_11: Space = routine_10(c, &(v509_6), &(*p1), &v498_28_cursor, &(*s1));
              drop(v509_6);
              compose(&(v507_10),&(v509_11))
            };
            drop(v507_10);
            let v507_13: Space = unite(&(v507_8),&(v507_12));
            join_wrapped_into(&mut v506_11_write,&((v507_13).read_zipper()),&[]);
            }
            v498_28_cursor.ascend(1);
          }
          drop(v506_11_write);
          drop(v506_6);
          compose(&(v501_10),&(v506_11))
        };
        drop(v501_10);
        let v501_13: Space = unite(&(v501_8),&(v501_12));
        join_wrapped_into(&mut v500_7_write,&((v501_13).read_zipper()),&[]);
        }
        v498_28_cursor.ascend(1);
      }
      drop(v500_7_write);
      compose(&(v499_5),&(v500_7))
    };
    drop(v499_5);
    let v499_9: Space = intersect(&(*CONSTANT_2),&(v499_2));
    drop(v499_2);
    let v499_10: Space = if has_head(&(v499_9)) { singleton(&[]) } else { Space::new() };
    drop(v499_9);
    let v499_13: Space = if (&(v499_10)).is_empty() { Space::new() } else {
      let v510_6: Path = concat_path(&(*p0),&v498_28_cursor.path()[v498_28_origin..(v498_28_origin + 1)]);
      let mut v510_12 = Space::new();
      let mut v510_12_write = v510_12.write_zipper();
      for v510_12_byte in v498_28_cursor.child_mask().iter() {
        v498_28_cursor.descend_to_existing_byte(v510_12_byte);
        {
        let v511_2: Space = singleton(&v498_28_cursor.path()[(v498_28_origin + 1)..(v498_28_origin + 2)]);
        let v511_3: Space = intersect(&(*CONSTANT_2),&(v511_2));
        let v511_4: Space = if has_head(&(v511_3)) { singleton(&[]) } else { Space::new() };
        drop(v511_3);
        let v511_5: Space = subtract(&(*CONSTANT_1),&(v511_4));
        drop(v511_4);
        let v511_8: Space = if (&(v511_5)).is_empty() { Space::new() } else {
          let v512_6: Path = concat_path(&(v510_6),&v498_28_cursor.path()[(v498_28_origin + 1)..(v498_28_origin + 2)]);
          let mut v512_7 = Space::new();
          let mut v512_7_write = v512_7.write_zipper();
          for v512_7_byte in v498_28_cursor.child_mask().iter() {
            v498_28_cursor.descend_to_existing_byte(v512_7_byte);
            {
            let v513_2: Space = singleton(&v498_28_cursor.path()[(v498_28_origin + 2)..(v498_28_origin + 3)]);
            let v513_3: Space = intersect(&(*CONSTANT_2),&(v513_2));
            let v513_4: Space = if has_head(&(v513_3)) { singleton(&[]) } else { Space::new() };
            drop(v513_3);
            let v513_5: Space = subtract(&(*CONSTANT_1),&(v513_4));
            drop(v513_4);
            let v513_8: Space = if (&(v513_5)).is_empty() { Space::new() } else {
              let v514_6: Path = concat_path(&(v512_6),&v498_28_cursor.path()[(v498_28_origin + 2)..(v498_28_origin + 3)]);
              let v514_7: Space = routine_38(c, &(v514_6), &(*p1), &v498_28_cursor, &(*s1));
              compose(&(v513_5),&(v514_7))
            };
            drop(v513_5);
            let v513_9: Space = intersect(&(*CONSTANT_2),&(v513_2));
            drop(v513_2);
            let v513_10: Space = if has_head(&(v513_9)) { singleton(&[]) } else { Space::new() };
            drop(v513_9);
            let v513_12: Space = if (&(v513_10)).is_empty() { Space::new() } else {
              let v515_6: Path = concat_path(&(v512_6),&v498_28_cursor.path()[(v498_28_origin + 2)..(v498_28_origin + 3)]);
              let v515_11: Space = routine_39(c, &(v515_6), &(*p1), &v498_28_cursor, &(*s1));
              drop(v515_6);
              compose(&(v513_10),&(v515_11))
            };
            drop(v513_10);
            let v513_13: Space = unite(&(v513_8),&(v513_12));
            join_wrapped_into(&mut v512_7_write,&((v513_13).read_zipper()),&[]);
            }
            v498_28_cursor.ascend(1);
          }
          drop(v512_7_write);
          drop(v512_6);
          compose(&(v511_5),&(v512_7))
        };
        drop(v511_5);
        let v511_9: Space = intersect(&(*CONSTANT_2),&(v511_2));
        drop(v511_2);
        let v511_10: Space = if has_head(&(v511_9)) { singleton(&[]) } else { Space::new() };
        drop(v511_9);
        let v511_13: Space = if (&(v511_10)).is_empty() { Space::new() } else {
          let mut v516_12 = Space::new();
          let mut v516_12_write = v516_12.write_zipper();
          let mut v516_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v498_28_cursor.path()[v498_28_origin..(v498_28_origin + 1)]),&v498_28_cursor.path()[(v498_28_origin + 1)..(v498_28_origin + 2)]);
          let v516_12_origin = v516_12_cursor.path().len();
          for v516_12_byte in v516_12_cursor.child_mask().iter() {
            v516_12_cursor.descend_to_existing_byte(v516_12_byte);
            {
            let v517_2: Space = singleton(&v516_12_cursor.path()[v516_12_origin..(v516_12_origin + 1)]);
            let v517_3: Space = intersect(&(*CONSTANT_2),&(v517_2));
            let v517_4: Space = if has_head(&(v517_3)) { singleton(&[]) } else { Space::new() };
            drop(v517_3);
            let v517_5: Space = subtract(&(*CONSTANT_1),&(v517_4));
            drop(v517_4);
            let v517_7: Space = if (&(v517_5)).is_empty() { Space::new() } else {
              let v518_6: Space = routine_13(c, &v516_12_cursor.path()[v516_12_origin..(v516_12_origin + 1)], &(*p1), &v516_12_cursor);
              compose(&(v517_5),&(v518_6))
            };
            drop(v517_5);
            let v517_8: Space = intersect(&(*CONSTANT_2),&(v517_2));
            drop(v517_2);
            let v517_9: Space = if has_head(&(v517_8)) { singleton(&[]) } else { Space::new() };
            drop(v517_8);
            let v517_11: Space = if (&(v517_9)).is_empty() { Space::new() } else {
              let v519_10: Space = routine_14(c, &v516_12_cursor.path()[v516_12_origin..(v516_12_origin + 1)], &(*p1), &v516_12_cursor);
              compose(&(v517_9),&(v519_10))
            };
            drop(v517_9);
            let v517_12: Space = unite(&(v517_7),&(v517_11));
            join_wrapped_into(&mut v516_12_write,&((v517_12).read_zipper()),&[]);
            }
            v516_12_cursor.ascend(1);
          }
          drop(v516_12_cursor);
          drop(v516_12_write);
          compose(&(v511_10),&(v516_12))
        };
        drop(v511_10);
        let v511_14: Space = unite(&(v511_8),&(v511_13));
        join_wrapped_into(&mut v510_12_write,&((v511_14).read_zipper()),&[]);
        }
        v498_28_cursor.ascend(1);
      }
      drop(v510_12_write);
      drop(v510_6);
      compose(&(v499_10),&(v510_12))
    };
    drop(v499_10);
    let v499_14: Space = unite(&(v499_8),&(v499_13));
    join_wrapped_into(&mut v498_28_write,&((v499_14).read_zipper()),&[]);
    }
    v498_28_cursor.ascend(1);
  }
  drop(v498_28_cursor);
  drop(v498_28_write);
  (v498_28).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v520_28 = Space::new();
  let mut v520_28_write = v520_28.write_zipper();
  let mut v520_28_cursor = (*s0).read_zipper();
  let v520_28_origin = v520_28_cursor.path().len();
  for v520_28_byte in v520_28_cursor.child_mask().iter() {
    v520_28_cursor.descend_to_existing_byte(v520_28_byte);
    {
    let v521_2: Space = singleton(&v520_28_cursor.path()[v520_28_origin..(v520_28_origin + 1)]);
    let v521_3: Space = intersect(&(*CONSTANT_2),&(v521_2));
    let v521_4: Space = if has_head(&(v521_3)) { singleton(&[]) } else { Space::new() };
    drop(v521_3);
    let v521_5: Space = subtract(&(*CONSTANT_1),&(v521_4));
    drop(v521_4);
    let v521_8: Space = if (&(v521_5)).is_empty() { Space::new() } else {
      let v522_6: Path = concat_path(&(*p0),&v520_28_cursor.path()[v520_28_origin..(v520_28_origin + 1)]);
      let mut v522_7 = Space::new();
      let mut v522_7_write = v522_7.write_zipper();
      for v522_7_byte in v520_28_cursor.child_mask().iter() {
        v520_28_cursor.descend_to_existing_byte(v522_7_byte);
        {
        let v523_2: Space = singleton(&v520_28_cursor.path()[(v520_28_origin + 1)..(v520_28_origin + 2)]);
        let v523_3: Space = intersect(&(*CONSTANT_2),&(v523_2));
        let v523_4: Space = if has_head(&(v523_3)) { singleton(&[]) } else { Space::new() };
        drop(v523_3);
        let v523_5: Space = subtract(&(*CONSTANT_1),&(v523_4));
        drop(v523_4);
        let v523_8: Space = if (&(v523_5)).is_empty() { Space::new() } else {
          let v524_6: Path = concat_path(&(v522_6),&v520_28_cursor.path()[(v520_28_origin + 1)..(v520_28_origin + 2)]);
          let mut v524_7 = Space::new();
          let mut v524_7_write = v524_7.write_zipper();
          for v524_7_byte in v520_28_cursor.child_mask().iter() {
            v520_28_cursor.descend_to_existing_byte(v524_7_byte);
            {
            let v525_2: Space = singleton(&v520_28_cursor.path()[(v520_28_origin + 2)..(v520_28_origin + 3)]);
            let v525_3: Space = intersect(&(*CONSTANT_2),&(v525_2));
            let v525_4: Space = if has_head(&(v525_3)) { singleton(&[]) } else { Space::new() };
            drop(v525_3);
            let v525_5: Space = subtract(&(*CONSTANT_1),&(v525_4));
            drop(v525_4);
            let v525_8: Space = if (&(v525_5)).is_empty() { Space::new() } else {
              let v526_6: Path = concat_path(&(v524_6),&v520_28_cursor.path()[(v520_28_origin + 2)..(v520_28_origin + 3)]);
              let v526_7: Space = routine_38(c, &(v526_6), &(*p1), &v520_28_cursor, &(*s1));
              compose(&(v525_5),&(v526_7))
            };
            drop(v525_5);
            let v525_9: Space = intersect(&(*CONSTANT_2),&(v525_2));
            drop(v525_2);
            let v525_10: Space = if has_head(&(v525_9)) { singleton(&[]) } else { Space::new() };
            drop(v525_9);
            let v525_12: Space = if (&(v525_10)).is_empty() { Space::new() } else {
              let v527_6: Path = concat_path(&(v524_6),&v520_28_cursor.path()[(v520_28_origin + 2)..(v520_28_origin + 3)]);
              let v527_11: Space = routine_39(c, &(v527_6), &(*p1), &v520_28_cursor, &(*s1));
              drop(v527_6);
              compose(&(v525_10),&(v527_11))
            };
            drop(v525_10);
            let v525_13: Space = unite(&(v525_8),&(v525_12));
            join_wrapped_into(&mut v524_7_write,&((v525_13).read_zipper()),&[]);
            }
            v520_28_cursor.ascend(1);
          }
          drop(v524_7_write);
          compose(&(v523_5),&(v524_7))
        };
        drop(v523_5);
        let v523_9: Space = intersect(&(*CONSTANT_2),&(v523_2));
        drop(v523_2);
        let v523_10: Space = if has_head(&(v523_9)) { singleton(&[]) } else { Space::new() };
        drop(v523_9);
        let v523_12: Space = if (&(v523_10)).is_empty() { Space::new() } else {
          let v528_6: Path = concat_path(&(v522_6),&v520_28_cursor.path()[(v520_28_origin + 1)..(v520_28_origin + 2)]);
          let mut v528_11 = Space::new();
          let mut v528_11_write = v528_11.write_zipper();
          for v528_11_byte in v520_28_cursor.child_mask().iter() {
            v520_28_cursor.descend_to_existing_byte(v528_11_byte);
            {
            let v529_2: Space = singleton(&v520_28_cursor.path()[(v520_28_origin + 2)..(v520_28_origin + 3)]);
            let v529_3: Space = intersect(&(*CONSTANT_2),&(v529_2));
            let v529_4: Space = if has_head(&(v529_3)) { singleton(&[]) } else { Space::new() };
            drop(v529_3);
            let v529_5: Space = subtract(&(*CONSTANT_1),&(v529_4));
            drop(v529_4);
            let v529_8: Space = if (&(v529_5)).is_empty() { Space::new() } else {
              let v530_6: Path = concat_path(&(v528_6),&v520_28_cursor.path()[(v520_28_origin + 2)..(v520_28_origin + 3)]);
              let v530_7: Space = routine_38(c, &(v530_6), &(*p1), &v520_28_cursor, &(*s1));
              compose(&(v529_5),&(v530_7))
            };
            drop(v529_5);
            let v529_9: Space = intersect(&(*CONSTANT_2),&(v529_2));
            drop(v529_2);
            let v529_10: Space = if has_head(&(v529_9)) { singleton(&[]) } else { Space::new() };
            drop(v529_9);
            let v529_12: Space = if (&(v529_10)).is_empty() { Space::new() } else {
              let v531_6: Path = concat_path(&(v528_6),&v520_28_cursor.path()[(v520_28_origin + 2)..(v520_28_origin + 3)]);
              let v531_11: Space = routine_10(c, &(v531_6), &(*p1), &v520_28_cursor, &(*s1));
              drop(v531_6);
              compose(&(v529_10),&(v531_11))
            };
            drop(v529_10);
            let v529_13: Space = unite(&(v529_8),&(v529_12));
            join_wrapped_into(&mut v528_11_write,&((v529_13).read_zipper()),&[]);
            }
            v520_28_cursor.ascend(1);
          }
          drop(v528_11_write);
          drop(v528_6);
          compose(&(v523_10),&(v528_11))
        };
        drop(v523_10);
        let v523_13: Space = unite(&(v523_8),&(v523_12));
        join_wrapped_into(&mut v522_7_write,&((v523_13).read_zipper()),&[]);
        }
        v520_28_cursor.ascend(1);
      }
      drop(v522_7_write);
      drop(v522_6);
      compose(&(v521_5),&(v522_7))
    };
    drop(v521_5);
    let v521_9: Space = intersect(&(*CONSTANT_2),&(v521_2));
    drop(v521_2);
    let v521_10: Space = if has_head(&(v521_9)) { singleton(&[]) } else { Space::new() };
    drop(v521_9);
    let v521_13: Space = if (&(v521_10)).is_empty() { Space::new() } else {
      let mut v532_12 = Space::new();
      let mut v532_12_write = v532_12.write_zipper();
      let mut v532_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v520_28_cursor.path()[v520_28_origin..(v520_28_origin + 1)]);
      let v532_12_origin = v532_12_cursor.path().len();
      for v532_12_byte in v532_12_cursor.child_mask().iter() {
        v532_12_cursor.descend_to_existing_byte(v532_12_byte);
        {
        let v533_2: Space = singleton(&v532_12_cursor.path()[v532_12_origin..(v532_12_origin + 1)]);
        let v533_3: Space = intersect(&(*CONSTANT_2),&(v533_2));
        let v533_4: Space = if has_head(&(v533_3)) { singleton(&[]) } else { Space::new() };
        drop(v533_3);
        let v533_5: Space = subtract(&(*CONSTANT_1),&(v533_4));
        drop(v533_4);
        let v533_7: Space = if (&(v533_5)).is_empty() { Space::new() } else {
          let mut v534_6 = Space::new();
          let mut v534_6_write = v534_6.write_zipper();
          for v534_6_byte in v532_12_cursor.child_mask().iter() {
            v532_12_cursor.descend_to_existing_byte(v534_6_byte);
            {
            let v535_2: Space = singleton(&v532_12_cursor.path()[(v532_12_origin + 1)..(v532_12_origin + 2)]);
            let v535_3: Space = intersect(&(*CONSTANT_2),&(v535_2));
            let v535_4: Space = if has_head(&(v535_3)) { singleton(&[]) } else { Space::new() };
            drop(v535_3);
            let v535_5: Space = subtract(&(*CONSTANT_1),&(v535_4));
            drop(v535_4);
            let v535_8: Space = if (&(v535_5)).is_empty() { Space::new() } else {
              let v536_7: Space = routine_17(c, &v532_12_cursor.path()[v532_12_origin..(v532_12_origin + 2)], &(*p1), &v532_12_cursor);
              compose(&(v535_5),&(v536_7))
            };
            drop(v535_5);
            let v535_9: Space = intersect(&(*CONSTANT_2),&(v535_2));
            drop(v535_2);
            let v535_10: Space = if has_head(&(v535_9)) { singleton(&[]) } else { Space::new() };
            drop(v535_9);
            let v535_12: Space = if (&(v535_10)).is_empty() { Space::new() } else {
              let v537_11: Space = routine_18(c, &v532_12_cursor.path()[v532_12_origin..(v532_12_origin + 2)], &(*p1), &v532_12_cursor);
              compose(&(v535_10),&(v537_11))
            };
            drop(v535_10);
            let v535_13: Space = unite(&(v535_8),&(v535_12));
            join_wrapped_into(&mut v534_6_write,&((v535_13).read_zipper()),&[]);
            }
            v532_12_cursor.ascend(1);
          }
          drop(v534_6_write);
          compose(&(v533_5),&(v534_6))
        };
        drop(v533_5);
        let v533_8: Space = intersect(&(*CONSTANT_2),&(v533_2));
        drop(v533_2);
        let v533_9: Space = if has_head(&(v533_8)) { singleton(&[]) } else { Space::new() };
        drop(v533_8);
        let v533_11: Space = if (&(v533_9)).is_empty() { Space::new() } else {
          let mut v538_10 = Space::new();
          let mut v538_10_write = v538_10.write_zipper();
          for v538_10_byte in v532_12_cursor.child_mask().iter() {
            v532_12_cursor.descend_to_existing_byte(v538_10_byte);
            {
            let v539_2: Space = singleton(&v532_12_cursor.path()[(v532_12_origin + 1)..(v532_12_origin + 2)]);
            let v539_3: Space = intersect(&(*CONSTANT_2),&(v539_2));
            let v539_4: Space = if has_head(&(v539_3)) { singleton(&[]) } else { Space::new() };
            drop(v539_3);
            let v539_5: Space = subtract(&(*CONSTANT_1),&(v539_4));
            drop(v539_4);
            let v539_8: Space = if (&(v539_5)).is_empty() { Space::new() } else {
              let v540_7: Space = routine_17(c, &v532_12_cursor.path()[v532_12_origin..(v532_12_origin + 2)], &(*p1), &v532_12_cursor);
              compose(&(v539_5),&(v540_7))
            };
            drop(v539_5);
            let v539_9: Space = intersect(&(*CONSTANT_2),&(v539_2));
            drop(v539_2);
            let v539_10: Space = if has_head(&(v539_9)) { singleton(&[]) } else { Space::new() };
            drop(v539_9);
            let v539_12: Space = if (&(v539_10)).is_empty() { Space::new() } else {
              let v541_11: Space = routine_19(c, &v532_12_cursor.path()[v532_12_origin..(v532_12_origin + 2)], &(*p1), &v532_12_cursor);
              compose(&(v539_10),&(v541_11))
            };
            drop(v539_10);
            let v539_13: Space = unite(&(v539_8),&(v539_12));
            join_wrapped_into(&mut v538_10_write,&((v539_13).read_zipper()),&[]);
            }
            v532_12_cursor.ascend(1);
          }
          drop(v538_10_write);
          compose(&(v533_9),&(v538_10))
        };
        drop(v533_9);
        let v533_12: Space = unite(&(v533_7),&(v533_11));
        join_wrapped_into(&mut v532_12_write,&((v533_12).read_zipper()),&[]);
        }
        v532_12_cursor.ascend(1);
      }
      drop(v532_12_cursor);
      drop(v532_12_write);
      compose(&(v521_10),&(v532_12))
    };
    drop(v521_10);
    let v521_14: Space = unite(&(v521_8),&(v521_13));
    join_wrapped_into(&mut v520_28_write,&((v521_14).read_zipper()),&[]);
    }
    v520_28_cursor.ascend(1);
  }
  drop(v520_28_cursor);
  drop(v520_28_write);
  (v520_28).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v542_21 = Space::new();
  let mut v542_21_write = v542_21.write_zipper();
  let mut v542_21_cursor = (*s0).read_zipper();
  let v542_21_origin = v542_21_cursor.path().len();
  for v542_21_byte in v542_21_cursor.child_mask().iter() {
    v542_21_cursor.descend_to_existing_byte(v542_21_byte);
    {
    let v543_2: Space = singleton(&v542_21_cursor.path()[v542_21_origin..(v542_21_origin + 1)]);
    let v543_3: Space = intersect(&(*CONSTANT_2),&(v543_2));
    let v543_4: Space = if has_head(&(v543_3)) { singleton(&[]) } else { Space::new() };
    drop(v543_3);
    let v543_5: Space = subtract(&(*CONSTANT_1),&(v543_4));
    drop(v543_4);
    let v543_8: Space = if (&(v543_5)).is_empty() { Space::new() } else {
      let v544_6: Path = concat_path(&(*p0),&v542_21_cursor.path()[v542_21_origin..(v542_21_origin + 1)]);
      let mut v544_7 = Space::new();
      let mut v544_7_write = v544_7.write_zipper();
      for v544_7_byte in v542_21_cursor.child_mask().iter() {
        v542_21_cursor.descend_to_existing_byte(v544_7_byte);
        {
        let v545_2: Space = singleton(&v542_21_cursor.path()[(v542_21_origin + 1)..(v542_21_origin + 2)]);
        let v545_3: Space = intersect(&(*CONSTANT_2),&(v545_2));
        let v545_4: Space = if has_head(&(v545_3)) { singleton(&[]) } else { Space::new() };
        drop(v545_3);
        let v545_5: Space = subtract(&(*CONSTANT_1),&(v545_4));
        drop(v545_4);
        let v545_8: Space = if (&(v545_5)).is_empty() { Space::new() } else {
          let v546_6: Path = concat_path(&(v544_6),&v542_21_cursor.path()[(v542_21_origin + 1)..(v542_21_origin + 2)]);
          let mut v546_7 = Space::new();
          let mut v546_7_write = v546_7.write_zipper();
          for v546_7_byte in v542_21_cursor.child_mask().iter() {
            v542_21_cursor.descend_to_existing_byte(v546_7_byte);
            {
            let v547_2: Space = singleton(&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
            let v547_3: Space = intersect(&(*CONSTANT_2),&(v547_2));
            let v547_4: Space = if has_head(&(v547_3)) { singleton(&[]) } else { Space::new() };
            drop(v547_3);
            let v547_5: Space = subtract(&(*CONSTANT_1),&(v547_4));
            drop(v547_4);
            let v547_8: Space = if (&(v547_5)).is_empty() { Space::new() } else {
              let v548_6: Path = concat_path(&(v546_6),&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
              let v548_7: Space = routine_40(c, &(v548_6), &(*p1), &v542_21_cursor);
              compose(&(v547_5),&(v548_7))
            };
            drop(v547_5);
            let v547_9: Space = intersect(&(*CONSTANT_2),&(v547_2));
            drop(v547_2);
            let v547_10: Space = if has_head(&(v547_9)) { singleton(&[]) } else { Space::new() };
            drop(v547_9);
            let v547_12: Space = if (&(v547_10)).is_empty() { Space::new() } else {
              let v549_6: Path = concat_path(&(v546_6),&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
              let v549_11: Space = routine_41(c, &(v549_6), &(*p1), &v542_21_cursor);
              drop(v549_6);
              compose(&(v547_10),&(v549_11))
            };
            drop(v547_10);
            let v547_13: Space = unite(&(v547_8),&(v547_12));
            join_wrapped_into(&mut v546_7_write,&((v547_13).read_zipper()),&[]);
            }
            v542_21_cursor.ascend(1);
          }
          drop(v546_7_write);
          compose(&(v545_5),&(v546_7))
        };
        drop(v545_5);
        let v545_9: Space = intersect(&(*CONSTANT_2),&(v545_2));
        drop(v545_2);
        let v545_10: Space = if has_head(&(v545_9)) { singleton(&[]) } else { Space::new() };
        drop(v545_9);
        let v545_12: Space = if (&(v545_10)).is_empty() { Space::new() } else {
          let v550_6: Path = concat_path(&(v544_6),&v542_21_cursor.path()[(v542_21_origin + 1)..(v542_21_origin + 2)]);
          let mut v550_11 = Space::new();
          let mut v550_11_write = v550_11.write_zipper();
          for v550_11_byte in v542_21_cursor.child_mask().iter() {
            v542_21_cursor.descend_to_existing_byte(v550_11_byte);
            {
            let v551_2: Space = singleton(&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
            let v551_3: Space = intersect(&(*CONSTANT_2),&(v551_2));
            let v551_4: Space = if has_head(&(v551_3)) { singleton(&[]) } else { Space::new() };
            drop(v551_3);
            let v551_5: Space = subtract(&(*CONSTANT_1),&(v551_4));
            drop(v551_4);
            let v551_8: Space = if (&(v551_5)).is_empty() { Space::new() } else {
              let v552_6: Path = concat_path(&(v550_6),&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
              let v552_7: Space = routine_40(c, &(v552_6), &(*p1), &v542_21_cursor);
              compose(&(v551_5),&(v552_7))
            };
            drop(v551_5);
            let v551_9: Space = intersect(&(*CONSTANT_2),&(v551_2));
            drop(v551_2);
            let v551_10: Space = if has_head(&(v551_9)) { singleton(&[]) } else { Space::new() };
            drop(v551_9);
            let v551_12: Space = if (&(v551_10)).is_empty() { Space::new() } else {
              let v553_6: Path = concat_path(&(v550_6),&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
              let v553_11: Space = routine_19(c, &(v553_6), &(*p1), &v542_21_cursor);
              drop(v553_6);
              compose(&(v551_10),&(v553_11))
            };
            drop(v551_10);
            let v551_13: Space = unite(&(v551_8),&(v551_12));
            join_wrapped_into(&mut v550_11_write,&((v551_13).read_zipper()),&[]);
            }
            v542_21_cursor.ascend(1);
          }
          drop(v550_11_write);
          drop(v550_6);
          compose(&(v545_10),&(v550_11))
        };
        drop(v545_10);
        let v545_13: Space = unite(&(v545_8),&(v545_12));
        join_wrapped_into(&mut v544_7_write,&((v545_13).read_zipper()),&[]);
        }
        v542_21_cursor.ascend(1);
      }
      drop(v544_7_write);
      compose(&(v543_5),&(v544_7))
    };
    drop(v543_5);
    let v543_9: Space = intersect(&(*CONSTANT_2),&(v543_2));
    drop(v543_2);
    let v543_10: Space = if has_head(&(v543_9)) { singleton(&[]) } else { Space::new() };
    drop(v543_9);
    let v543_12: Space = if (&(v543_10)).is_empty() { Space::new() } else {
      let v554_6: Path = concat_path(&(*p0),&v542_21_cursor.path()[v542_21_origin..(v542_21_origin + 1)]);
      let mut v554_11 = Space::new();
      let mut v554_11_write = v554_11.write_zipper();
      for v554_11_byte in v542_21_cursor.child_mask().iter() {
        v542_21_cursor.descend_to_existing_byte(v554_11_byte);
        {
        let v555_2: Space = singleton(&v542_21_cursor.path()[(v542_21_origin + 1)..(v542_21_origin + 2)]);
        let v555_3: Space = intersect(&(*CONSTANT_2),&(v555_2));
        let v555_4: Space = if has_head(&(v555_3)) { singleton(&[]) } else { Space::new() };
        drop(v555_3);
        let v555_5: Space = subtract(&(*CONSTANT_1),&(v555_4));
        drop(v555_4);
        let v555_8: Space = if (&(v555_5)).is_empty() { Space::new() } else {
          let v556_6: Path = concat_path(&(v554_6),&v542_21_cursor.path()[(v542_21_origin + 1)..(v542_21_origin + 2)]);
          let mut v556_7 = Space::new();
          let mut v556_7_write = v556_7.write_zipper();
          for v556_7_byte in v542_21_cursor.child_mask().iter() {
            v542_21_cursor.descend_to_existing_byte(v556_7_byte);
            {
            let v557_2: Space = singleton(&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
            let v557_3: Space = intersect(&(*CONSTANT_2),&(v557_2));
            let v557_4: Space = if has_head(&(v557_3)) { singleton(&[]) } else { Space::new() };
            drop(v557_3);
            let v557_5: Space = subtract(&(*CONSTANT_1),&(v557_4));
            drop(v557_4);
            let v557_8: Space = if (&(v557_5)).is_empty() { Space::new() } else {
              let v558_6: Path = concat_path(&(v556_6),&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
              let v558_7: Space = routine_40(c, &(v558_6), &(*p1), &v542_21_cursor);
              compose(&(v557_5),&(v558_7))
            };
            drop(v557_5);
            let v557_9: Space = intersect(&(*CONSTANT_2),&(v557_2));
            drop(v557_2);
            let v557_10: Space = if has_head(&(v557_9)) { singleton(&[]) } else { Space::new() };
            drop(v557_9);
            let v557_12: Space = if (&(v557_10)).is_empty() { Space::new() } else {
              let v559_6: Path = concat_path(&(v556_6),&v542_21_cursor.path()[(v542_21_origin + 2)..(v542_21_origin + 3)]);
              let v559_11: Space = routine_41(c, &(v559_6), &(*p1), &v542_21_cursor);
              drop(v559_6);
              compose(&(v557_10),&(v559_11))
            };
            drop(v557_10);
            let v557_13: Space = unite(&(v557_8),&(v557_12));
            join_wrapped_into(&mut v556_7_write,&((v557_13).read_zipper()),&[]);
            }
            v542_21_cursor.ascend(1);
          }
          drop(v556_7_write);
          compose(&(v555_5),&(v556_7))
        };
        drop(v555_5);
        let v555_9: Space = intersect(&(*CONSTANT_2),&(v555_2));
        drop(v555_2);
        let v555_10: Space = if has_head(&(v555_9)) { singleton(&[]) } else { Space::new() };
        drop(v555_9);
        let v555_11: Space = compose(&(v555_10),&v542_21_cursor);
        drop(v555_10);
        let v560_6: Path = concat_path(&(v554_6),&v542_21_cursor.path()[(v542_21_origin + 1)..(v542_21_origin + 2)]);
        let v555_12: Space = wrap(&(v555_11),&(v560_6));
        drop(v555_11);
        let v555_13: Space = wrap(&(v555_12),&(*p1));
        drop(v555_12);
        let v555_14: Space = unite(&(v555_8),&(v555_13));
        drop(v555_13);
        join_wrapped_into(&mut v554_11_write,&((v555_14).read_zipper()),&[]);
        }
        v542_21_cursor.ascend(1);
      }
      drop(v554_11_write);
      drop(v554_6);
      compose(&(v543_10),&(v554_11))
    };
    drop(v543_10);
    let v543_13: Space = unite(&(v543_8),&(v543_12));
    join_wrapped_into(&mut v542_21_write,&((v543_13).read_zipper()),&[]);
    }
    v542_21_cursor.ascend(1);
  }
  drop(v542_21_cursor);
  drop(v542_21_write);
  (v542_21).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v561_15 = Space::new();
  let mut v561_15_write = v561_15.write_zipper();
  let mut v561_15_cursor = (*s0).read_zipper();
  let v561_15_origin = v561_15_cursor.path().len();
  for v561_15_byte in v561_15_cursor.child_mask().iter() {
    v561_15_cursor.descend_to_existing_byte(v561_15_byte);
    {
    let v562_2: Space = singleton(&v561_15_cursor.path()[v561_15_origin..(v561_15_origin + 1)]);
    let v562_3: Space = intersect(&(*CONSTANT_2),&(v562_2));
    let v562_4: Space = if has_head(&(v562_3)) { singleton(&[]) } else { Space::new() };
    drop(v562_3);
    let v562_5: Space = subtract(&(*CONSTANT_1),&(v562_4));
    drop(v562_4);
    let v562_8: Space = if (&(v562_5)).is_empty() { Space::new() } else {
      let v563_6: Path = concat_path(&(*p0),&v561_15_cursor.path()[v561_15_origin..(v561_15_origin + 1)]);
      let mut v563_7 = Space::new();
      let mut v563_7_write = v563_7.write_zipper();
      for v563_7_byte in v561_15_cursor.child_mask().iter() {
        v561_15_cursor.descend_to_existing_byte(v563_7_byte);
        {
        let v564_2: Space = singleton(&v561_15_cursor.path()[(v561_15_origin + 1)..(v561_15_origin + 2)]);
        let v564_3: Space = intersect(&(*CONSTANT_2),&(v564_2));
        let v564_4: Space = if has_head(&(v564_3)) { singleton(&[]) } else { Space::new() };
        drop(v564_3);
        let v564_5: Space = subtract(&(*CONSTANT_1),&(v564_4));
        drop(v564_4);
        let v564_8: Space = if (&(v564_5)).is_empty() { Space::new() } else {
          let v565_6: Path = concat_path(&(v563_6),&v561_15_cursor.path()[(v561_15_origin + 1)..(v561_15_origin + 2)]);
          let mut v565_7 = Space::new();
          let mut v565_7_write = v565_7.write_zipper();
          for v565_7_byte in v561_15_cursor.child_mask().iter() {
            v561_15_cursor.descend_to_existing_byte(v565_7_byte);
            {
            let v566_2: Space = singleton(&v561_15_cursor.path()[(v561_15_origin + 2)..(v561_15_origin + 3)]);
            let v566_3: Space = intersect(&(*CONSTANT_2),&(v566_2));
            let v566_4: Space = if has_head(&(v566_3)) { singleton(&[]) } else { Space::new() };
            drop(v566_3);
            let v566_5: Space = subtract(&(*CONSTANT_1),&(v566_4));
            drop(v566_4);
            let v566_8: Space = if (&(v566_5)).is_empty() { Space::new() } else {
              let v567_6: Path = concat_path(&(v565_6),&v561_15_cursor.path()[(v561_15_origin + 2)..(v561_15_origin + 3)]);
              let v567_7: Space = routine_40(c, &(v567_6), &(*p1), &v561_15_cursor);
              compose(&(v566_5),&(v567_7))
            };
            drop(v566_5);
            let v566_9: Space = intersect(&(*CONSTANT_2),&(v566_2));
            drop(v566_2);
            let v566_10: Space = if has_head(&(v566_9)) { singleton(&[]) } else { Space::new() };
            drop(v566_9);
            let v566_12: Space = if (&(v566_10)).is_empty() { Space::new() } else {
              let v568_6: Path = concat_path(&(v565_6),&v561_15_cursor.path()[(v561_15_origin + 2)..(v561_15_origin + 3)]);
              let v568_11: Space = routine_41(c, &(v568_6), &(*p1), &v561_15_cursor);
              drop(v568_6);
              compose(&(v566_10),&(v568_11))
            };
            drop(v566_10);
            let v566_13: Space = unite(&(v566_8),&(v566_12));
            join_wrapped_into(&mut v565_7_write,&((v566_13).read_zipper()),&[]);
            }
            v561_15_cursor.ascend(1);
          }
          drop(v565_7_write);
          compose(&(v564_5),&(v565_7))
        };
        drop(v564_5);
        let v564_9: Space = intersect(&(*CONSTANT_2),&(v564_2));
        drop(v564_2);
        let v564_10: Space = if has_head(&(v564_9)) { singleton(&[]) } else { Space::new() };
        drop(v564_9);
        let v564_12: Space = if (&(v564_10)).is_empty() { Space::new() } else {
          let v569_6: Path = concat_path(&(v563_6),&v561_15_cursor.path()[(v561_15_origin + 1)..(v561_15_origin + 2)]);
          let mut v569_11 = Space::new();
          let mut v569_11_write = v569_11.write_zipper();
          for v569_11_byte in v561_15_cursor.child_mask().iter() {
            v561_15_cursor.descend_to_existing_byte(v569_11_byte);
            {
            let v570_2: Space = singleton(&v561_15_cursor.path()[(v561_15_origin + 2)..(v561_15_origin + 3)]);
            let v570_3: Space = intersect(&(*CONSTANT_2),&(v570_2));
            let v570_4: Space = if has_head(&(v570_3)) { singleton(&[]) } else { Space::new() };
            drop(v570_3);
            let v570_5: Space = subtract(&(*CONSTANT_1),&(v570_4));
            drop(v570_4);
            let v570_8: Space = if (&(v570_5)).is_empty() { Space::new() } else {
              let v571_6: Path = concat_path(&(v569_6),&v561_15_cursor.path()[(v561_15_origin + 2)..(v561_15_origin + 3)]);
              let v571_7: Space = routine_40(c, &(v571_6), &(*p1), &v561_15_cursor);
              compose(&(v570_5),&(v571_7))
            };
            drop(v570_5);
            let v570_9: Space = intersect(&(*CONSTANT_2),&(v570_2));
            drop(v570_2);
            let v570_10: Space = if has_head(&(v570_9)) { singleton(&[]) } else { Space::new() };
            drop(v570_9);
            let v570_12: Space = if (&(v570_10)).is_empty() { Space::new() } else {
              let v572_6: Path = concat_path(&(v569_6),&v561_15_cursor.path()[(v561_15_origin + 2)..(v561_15_origin + 3)]);
              let v572_11: Space = routine_19(c, &(v572_6), &(*p1), &v561_15_cursor);
              drop(v572_6);
              compose(&(v570_10),&(v572_11))
            };
            drop(v570_10);
            let v570_13: Space = unite(&(v570_8),&(v570_12));
            join_wrapped_into(&mut v569_11_write,&((v570_13).read_zipper()),&[]);
            }
            v561_15_cursor.ascend(1);
          }
          drop(v569_11_write);
          drop(v569_6);
          compose(&(v564_10),&(v569_11))
        };
        drop(v564_10);
        let v564_13: Space = unite(&(v564_8),&(v564_12));
        join_wrapped_into(&mut v563_7_write,&((v564_13).read_zipper()),&[]);
        }
        v561_15_cursor.ascend(1);
      }
      drop(v563_7_write);
      compose(&(v562_5),&(v563_7))
    };
    drop(v562_5);
    let v562_9: Space = intersect(&(*CONSTANT_2),&(v562_2));
    drop(v562_2);
    let v562_10: Space = if has_head(&(v562_9)) { singleton(&[]) } else { Space::new() };
    drop(v562_9);
    let v562_11: Space = compose(&(v562_10),&v561_15_cursor);
    drop(v562_10);
    let v573_6: Path = concat_path(&(*p0),&v561_15_cursor.path()[v561_15_origin..(v561_15_origin + 1)]);
    let v562_12: Space = wrap(&(v562_11),&(v573_6));
    drop(v562_11);
    let v562_13: Space = wrap(&(v562_12),&(*p1));
    drop(v562_12);
    let v562_14: Space = unite(&(v562_8),&(v562_13));
    drop(v562_13);
    join_wrapped_into(&mut v561_15_write,&((v562_14).read_zipper()),&[]);
    }
    v561_15_cursor.ascend(1);
  }
  drop(v561_15_cursor);
  drop(v561_15_write);
  (v561_15).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v574_28 = Space::new();
  let mut v574_28_write = v574_28.write_zipper();
  let mut v574_28_cursor = (*s0).read_zipper();
  let v574_28_origin = v574_28_cursor.path().len();
  for v574_28_byte in v574_28_cursor.child_mask().iter() {
    v574_28_cursor.descend_to_existing_byte(v574_28_byte);
    {
    let v575_2: Space = singleton(&v574_28_cursor.path()[v574_28_origin..(v574_28_origin + 1)]);
    let v575_3: Space = intersect(&(*CONSTANT_2),&(v575_2));
    let v575_4: Space = if has_head(&(v575_3)) { singleton(&[]) } else { Space::new() };
    drop(v575_3);
    let v575_5: Space = subtract(&(*CONSTANT_1),&(v575_4));
    drop(v575_4);
    let v575_8: Space = if (&(v575_5)).is_empty() { Space::new() } else {
      let v576_6: Path = concat_path(&(*p0),&v574_28_cursor.path()[v574_28_origin..(v574_28_origin + 1)]);
      let mut v576_7 = Space::new();
      let mut v576_7_write = v576_7.write_zipper();
      for v576_7_byte in v574_28_cursor.child_mask().iter() {
        v574_28_cursor.descend_to_existing_byte(v576_7_byte);
        {
        let v577_2: Space = singleton(&v574_28_cursor.path()[(v574_28_origin + 1)..(v574_28_origin + 2)]);
        let v577_3: Space = intersect(&(*CONSTANT_2),&(v577_2));
        let v577_4: Space = if has_head(&(v577_3)) { singleton(&[]) } else { Space::new() };
        drop(v577_3);
        let v577_5: Space = subtract(&(*CONSTANT_1),&(v577_4));
        drop(v577_4);
        let v577_8: Space = if (&(v577_5)).is_empty() { Space::new() } else {
          let v578_6: Path = concat_path(&(v576_6),&v574_28_cursor.path()[(v574_28_origin + 1)..(v574_28_origin + 2)]);
          let mut v578_7 = Space::new();
          let mut v578_7_write = v578_7.write_zipper();
          for v578_7_byte in v574_28_cursor.child_mask().iter() {
            v574_28_cursor.descend_to_existing_byte(v578_7_byte);
            {
            let v579_2: Space = singleton(&v574_28_cursor.path()[(v574_28_origin + 2)..(v574_28_origin + 3)]);
            let v579_3: Space = intersect(&(*CONSTANT_2),&(v579_2));
            let v579_4: Space = if has_head(&(v579_3)) { singleton(&[]) } else { Space::new() };
            drop(v579_3);
            let v579_5: Space = subtract(&(*CONSTANT_1),&(v579_4));
            drop(v579_4);
            let v579_8: Space = if (&(v579_5)).is_empty() { Space::new() } else {
              let v580_6: Path = concat_path(&(v578_6),&v574_28_cursor.path()[(v574_28_origin + 2)..(v574_28_origin + 3)]);
              let v580_7: Space = routine_42(c, &(v580_6), &(*p1), &v574_28_cursor, &(*s1));
              compose(&(v579_5),&(v580_7))
            };
            drop(v579_5);
            let v579_9: Space = intersect(&(*CONSTANT_2),&(v579_2));
            drop(v579_2);
            let v579_10: Space = if has_head(&(v579_9)) { singleton(&[]) } else { Space::new() };
            drop(v579_9);
            let v579_12: Space = if (&(v579_10)).is_empty() { Space::new() } else {
              let v581_6: Path = concat_path(&(v578_6),&v574_28_cursor.path()[(v574_28_origin + 2)..(v574_28_origin + 3)]);
              let v581_11: Space = routine_43(c, &(v581_6), &(*p1), &v574_28_cursor, &(*s1));
              drop(v581_6);
              compose(&(v579_10),&(v581_11))
            };
            drop(v579_10);
            let v579_13: Space = unite(&(v579_8),&(v579_12));
            join_wrapped_into(&mut v578_7_write,&((v579_13).read_zipper()),&[]);
            }
            v574_28_cursor.ascend(1);
          }
          drop(v578_7_write);
          compose(&(v577_5),&(v578_7))
        };
        drop(v577_5);
        let v577_9: Space = intersect(&(*CONSTANT_2),&(v577_2));
        drop(v577_2);
        let v577_10: Space = if has_head(&(v577_9)) { singleton(&[]) } else { Space::new() };
        drop(v577_9);
        let v577_12: Space = if (&(v577_10)).is_empty() { Space::new() } else {
          let v582_6: Path = concat_path(&(v576_6),&v574_28_cursor.path()[(v574_28_origin + 1)..(v574_28_origin + 2)]);
          let mut v582_11 = Space::new();
          let mut v582_11_write = v582_11.write_zipper();
          for v582_11_byte in v574_28_cursor.child_mask().iter() {
            v574_28_cursor.descend_to_existing_byte(v582_11_byte);
            {
            let v583_2: Space = singleton(&v574_28_cursor.path()[(v574_28_origin + 2)..(v574_28_origin + 3)]);
            let v583_3: Space = intersect(&(*CONSTANT_2),&(v583_2));
            let v583_4: Space = if has_head(&(v583_3)) { singleton(&[]) } else { Space::new() };
            drop(v583_3);
            let v583_5: Space = subtract(&(*CONSTANT_1),&(v583_4));
            drop(v583_4);
            let v583_8: Space = if (&(v583_5)).is_empty() { Space::new() } else {
              let v584_6: Path = concat_path(&(v582_6),&v574_28_cursor.path()[(v574_28_origin + 2)..(v574_28_origin + 3)]);
              let v584_7: Space = routine_42(c, &(v584_6), &(*p1), &v574_28_cursor, &(*s1));
              compose(&(v583_5),&(v584_7))
            };
            drop(v583_5);
            let v583_9: Space = intersect(&(*CONSTANT_2),&(v583_2));
            drop(v583_2);
            let v583_10: Space = if has_head(&(v583_9)) { singleton(&[]) } else { Space::new() };
            drop(v583_9);
            let v583_12: Space = if (&(v583_10)).is_empty() { Space::new() } else {
              let v585_6: Path = concat_path(&(v582_6),&v574_28_cursor.path()[(v574_28_origin + 2)..(v574_28_origin + 3)]);
              let v585_11: Space = routine_10(c, &(v585_6), &(*p1), &v574_28_cursor, &(*s1));
              drop(v585_6);
              compose(&(v583_10),&(v585_11))
            };
            drop(v583_10);
            let v583_13: Space = unite(&(v583_8),&(v583_12));
            join_wrapped_into(&mut v582_11_write,&((v583_13).read_zipper()),&[]);
            }
            v574_28_cursor.ascend(1);
          }
          drop(v582_11_write);
          drop(v582_6);
          compose(&(v577_10),&(v582_11))
        };
        drop(v577_10);
        let v577_13: Space = unite(&(v577_8),&(v577_12));
        join_wrapped_into(&mut v576_7_write,&((v577_13).read_zipper()),&[]);
        }
        v574_28_cursor.ascend(1);
      }
      drop(v576_7_write);
      compose(&(v575_5),&(v576_7))
    };
    drop(v575_5);
    let v575_9: Space = intersect(&(*CONSTANT_2),&(v575_2));
    drop(v575_2);
    let v575_10: Space = if has_head(&(v575_9)) { singleton(&[]) } else { Space::new() };
    drop(v575_9);
    let v575_13: Space = if (&(v575_10)).is_empty() { Space::new() } else {
      let v586_6: Path = concat_path(&(*p0),&v574_28_cursor.path()[v574_28_origin..(v574_28_origin + 1)]);
      let mut v586_12 = Space::new();
      let mut v586_12_write = v586_12.write_zipper();
      for v586_12_byte in v574_28_cursor.child_mask().iter() {
        v574_28_cursor.descend_to_existing_byte(v586_12_byte);
        {
        let v587_2: Space = singleton(&v574_28_cursor.path()[(v574_28_origin + 1)..(v574_28_origin + 2)]);
        let v587_3: Space = intersect(&(*CONSTANT_2),&(v587_2));
        let v587_4: Space = if has_head(&(v587_3)) { singleton(&[]) } else { Space::new() };
        drop(v587_3);
        let v587_5: Space = subtract(&(*CONSTANT_1),&(v587_4));
        drop(v587_4);
        let v587_8: Space = if (&(v587_5)).is_empty() { Space::new() } else {
          let v588_6: Path = concat_path(&(v586_6),&v574_28_cursor.path()[(v574_28_origin + 1)..(v574_28_origin + 2)]);
          let mut v588_7 = Space::new();
          let mut v588_7_write = v588_7.write_zipper();
          for v588_7_byte in v574_28_cursor.child_mask().iter() {
            v574_28_cursor.descend_to_existing_byte(v588_7_byte);
            {
            let v589_2: Space = singleton(&v574_28_cursor.path()[(v574_28_origin + 2)..(v574_28_origin + 3)]);
            let v589_3: Space = intersect(&(*CONSTANT_2),&(v589_2));
            let v589_4: Space = if has_head(&(v589_3)) { singleton(&[]) } else { Space::new() };
            drop(v589_3);
            let v589_5: Space = subtract(&(*CONSTANT_1),&(v589_4));
            drop(v589_4);
            let v589_8: Space = if (&(v589_5)).is_empty() { Space::new() } else {
              let v590_6: Path = concat_path(&(v588_6),&v574_28_cursor.path()[(v574_28_origin + 2)..(v574_28_origin + 3)]);
              let v590_7: Space = routine_42(c, &(v590_6), &(*p1), &v574_28_cursor, &(*s1));
              compose(&(v589_5),&(v590_7))
            };
            drop(v589_5);
            let v589_9: Space = intersect(&(*CONSTANT_2),&(v589_2));
            drop(v589_2);
            let v589_10: Space = if has_head(&(v589_9)) { singleton(&[]) } else { Space::new() };
            drop(v589_9);
            let v589_12: Space = if (&(v589_10)).is_empty() { Space::new() } else {
              let v591_6: Path = concat_path(&(v588_6),&v574_28_cursor.path()[(v574_28_origin + 2)..(v574_28_origin + 3)]);
              let v591_11: Space = routine_43(c, &(v591_6), &(*p1), &v574_28_cursor, &(*s1));
              drop(v591_6);
              compose(&(v589_10),&(v591_11))
            };
            drop(v589_10);
            let v589_13: Space = unite(&(v589_8),&(v589_12));
            join_wrapped_into(&mut v588_7_write,&((v589_13).read_zipper()),&[]);
            }
            v574_28_cursor.ascend(1);
          }
          drop(v588_7_write);
          drop(v588_6);
          compose(&(v587_5),&(v588_7))
        };
        drop(v587_5);
        let v587_9: Space = intersect(&(*CONSTANT_2),&(v587_2));
        drop(v587_2);
        let v587_10: Space = if has_head(&(v587_9)) { singleton(&[]) } else { Space::new() };
        drop(v587_9);
        let v587_13: Space = if (&(v587_10)).is_empty() { Space::new() } else {
          let mut v592_12 = Space::new();
          let mut v592_12_write = v592_12.write_zipper();
          let mut v592_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v574_28_cursor.path()[v574_28_origin..(v574_28_origin + 1)]),&v574_28_cursor.path()[(v574_28_origin + 1)..(v574_28_origin + 2)]);
          let v592_12_origin = v592_12_cursor.path().len();
          for v592_12_byte in v592_12_cursor.child_mask().iter() {
            v592_12_cursor.descend_to_existing_byte(v592_12_byte);
            {
            let v593_2: Space = singleton(&v592_12_cursor.path()[v592_12_origin..(v592_12_origin + 1)]);
            let v593_3: Space = intersect(&(*CONSTANT_2),&(v593_2));
            let v593_4: Space = if has_head(&(v593_3)) { singleton(&[]) } else { Space::new() };
            drop(v593_3);
            let v593_5: Space = subtract(&(*CONSTANT_1),&(v593_4));
            drop(v593_4);
            let v593_7: Space = if (&(v593_5)).is_empty() { Space::new() } else {
              let v594_6: Space = routine_13(c, &v592_12_cursor.path()[v592_12_origin..(v592_12_origin + 1)], &(*p1), &v592_12_cursor);
              compose(&(v593_5),&(v594_6))
            };
            drop(v593_5);
            let v593_8: Space = intersect(&(*CONSTANT_2),&(v593_2));
            drop(v593_2);
            let v593_9: Space = if has_head(&(v593_8)) { singleton(&[]) } else { Space::new() };
            drop(v593_8);
            let v593_11: Space = if (&(v593_9)).is_empty() { Space::new() } else {
              let v595_10: Space = routine_14(c, &v592_12_cursor.path()[v592_12_origin..(v592_12_origin + 1)], &(*p1), &v592_12_cursor);
              compose(&(v593_9),&(v595_10))
            };
            drop(v593_9);
            let v593_12: Space = unite(&(v593_7),&(v593_11));
            join_wrapped_into(&mut v592_12_write,&((v593_12).read_zipper()),&[]);
            }
            v592_12_cursor.ascend(1);
          }
          drop(v592_12_cursor);
          drop(v592_12_write);
          compose(&(v587_10),&(v592_12))
        };
        drop(v587_10);
        let v587_14: Space = unite(&(v587_8),&(v587_13));
        join_wrapped_into(&mut v586_12_write,&((v587_14).read_zipper()),&[]);
        }
        v574_28_cursor.ascend(1);
      }
      drop(v586_12_write);
      drop(v586_6);
      compose(&(v575_10),&(v586_12))
    };
    drop(v575_10);
    let v575_14: Space = unite(&(v575_8),&(v575_13));
    join_wrapped_into(&mut v574_28_write,&((v575_14).read_zipper()),&[]);
    }
    v574_28_cursor.ascend(1);
  }
  drop(v574_28_cursor);
  drop(v574_28_write);
  (v574_28).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v596_28 = Space::new();
  let mut v596_28_write = v596_28.write_zipper();
  let mut v596_28_cursor = (*s0).read_zipper();
  let v596_28_origin = v596_28_cursor.path().len();
  for v596_28_byte in v596_28_cursor.child_mask().iter() {
    v596_28_cursor.descend_to_existing_byte(v596_28_byte);
    {
    let v597_2: Space = singleton(&v596_28_cursor.path()[v596_28_origin..(v596_28_origin + 1)]);
    let v597_3: Space = intersect(&(*CONSTANT_2),&(v597_2));
    let v597_4: Space = if has_head(&(v597_3)) { singleton(&[]) } else { Space::new() };
    drop(v597_3);
    let v597_5: Space = subtract(&(*CONSTANT_1),&(v597_4));
    drop(v597_4);
    let v597_8: Space = if (&(v597_5)).is_empty() { Space::new() } else {
      let v598_6: Path = concat_path(&(*p0),&v596_28_cursor.path()[v596_28_origin..(v596_28_origin + 1)]);
      let mut v598_7 = Space::new();
      let mut v598_7_write = v598_7.write_zipper();
      for v598_7_byte in v596_28_cursor.child_mask().iter() {
        v596_28_cursor.descend_to_existing_byte(v598_7_byte);
        {
        let v599_2: Space = singleton(&v596_28_cursor.path()[(v596_28_origin + 1)..(v596_28_origin + 2)]);
        let v599_3: Space = intersect(&(*CONSTANT_2),&(v599_2));
        let v599_4: Space = if has_head(&(v599_3)) { singleton(&[]) } else { Space::new() };
        drop(v599_3);
        let v599_5: Space = subtract(&(*CONSTANT_1),&(v599_4));
        drop(v599_4);
        let v599_8: Space = if (&(v599_5)).is_empty() { Space::new() } else {
          let v600_6: Path = concat_path(&(v598_6),&v596_28_cursor.path()[(v596_28_origin + 1)..(v596_28_origin + 2)]);
          let mut v600_7 = Space::new();
          let mut v600_7_write = v600_7.write_zipper();
          for v600_7_byte in v596_28_cursor.child_mask().iter() {
            v596_28_cursor.descend_to_existing_byte(v600_7_byte);
            {
            let v601_2: Space = singleton(&v596_28_cursor.path()[(v596_28_origin + 2)..(v596_28_origin + 3)]);
            let v601_3: Space = intersect(&(*CONSTANT_2),&(v601_2));
            let v601_4: Space = if has_head(&(v601_3)) { singleton(&[]) } else { Space::new() };
            drop(v601_3);
            let v601_5: Space = subtract(&(*CONSTANT_1),&(v601_4));
            drop(v601_4);
            let v601_8: Space = if (&(v601_5)).is_empty() { Space::new() } else {
              let v602_6: Path = concat_path(&(v600_6),&v596_28_cursor.path()[(v596_28_origin + 2)..(v596_28_origin + 3)]);
              let v602_7: Space = routine_42(c, &(v602_6), &(*p1), &v596_28_cursor, &(*s1));
              compose(&(v601_5),&(v602_7))
            };
            drop(v601_5);
            let v601_9: Space = intersect(&(*CONSTANT_2),&(v601_2));
            drop(v601_2);
            let v601_10: Space = if has_head(&(v601_9)) { singleton(&[]) } else { Space::new() };
            drop(v601_9);
            let v601_12: Space = if (&(v601_10)).is_empty() { Space::new() } else {
              let v603_6: Path = concat_path(&(v600_6),&v596_28_cursor.path()[(v596_28_origin + 2)..(v596_28_origin + 3)]);
              let v603_11: Space = routine_43(c, &(v603_6), &(*p1), &v596_28_cursor, &(*s1));
              drop(v603_6);
              compose(&(v601_10),&(v603_11))
            };
            drop(v601_10);
            let v601_13: Space = unite(&(v601_8),&(v601_12));
            join_wrapped_into(&mut v600_7_write,&((v601_13).read_zipper()),&[]);
            }
            v596_28_cursor.ascend(1);
          }
          drop(v600_7_write);
          compose(&(v599_5),&(v600_7))
        };
        drop(v599_5);
        let v599_9: Space = intersect(&(*CONSTANT_2),&(v599_2));
        drop(v599_2);
        let v599_10: Space = if has_head(&(v599_9)) { singleton(&[]) } else { Space::new() };
        drop(v599_9);
        let v599_12: Space = if (&(v599_10)).is_empty() { Space::new() } else {
          let v604_6: Path = concat_path(&(v598_6),&v596_28_cursor.path()[(v596_28_origin + 1)..(v596_28_origin + 2)]);
          let mut v604_11 = Space::new();
          let mut v604_11_write = v604_11.write_zipper();
          for v604_11_byte in v596_28_cursor.child_mask().iter() {
            v596_28_cursor.descend_to_existing_byte(v604_11_byte);
            {
            let v605_2: Space = singleton(&v596_28_cursor.path()[(v596_28_origin + 2)..(v596_28_origin + 3)]);
            let v605_3: Space = intersect(&(*CONSTANT_2),&(v605_2));
            let v605_4: Space = if has_head(&(v605_3)) { singleton(&[]) } else { Space::new() };
            drop(v605_3);
            let v605_5: Space = subtract(&(*CONSTANT_1),&(v605_4));
            drop(v605_4);
            let v605_8: Space = if (&(v605_5)).is_empty() { Space::new() } else {
              let v606_6: Path = concat_path(&(v604_6),&v596_28_cursor.path()[(v596_28_origin + 2)..(v596_28_origin + 3)]);
              let v606_7: Space = routine_42(c, &(v606_6), &(*p1), &v596_28_cursor, &(*s1));
              compose(&(v605_5),&(v606_7))
            };
            drop(v605_5);
            let v605_9: Space = intersect(&(*CONSTANT_2),&(v605_2));
            drop(v605_2);
            let v605_10: Space = if has_head(&(v605_9)) { singleton(&[]) } else { Space::new() };
            drop(v605_9);
            let v605_12: Space = if (&(v605_10)).is_empty() { Space::new() } else {
              let v607_6: Path = concat_path(&(v604_6),&v596_28_cursor.path()[(v596_28_origin + 2)..(v596_28_origin + 3)]);
              let v607_11: Space = routine_10(c, &(v607_6), &(*p1), &v596_28_cursor, &(*s1));
              drop(v607_6);
              compose(&(v605_10),&(v607_11))
            };
            drop(v605_10);
            let v605_13: Space = unite(&(v605_8),&(v605_12));
            join_wrapped_into(&mut v604_11_write,&((v605_13).read_zipper()),&[]);
            }
            v596_28_cursor.ascend(1);
          }
          drop(v604_11_write);
          drop(v604_6);
          compose(&(v599_10),&(v604_11))
        };
        drop(v599_10);
        let v599_13: Space = unite(&(v599_8),&(v599_12));
        join_wrapped_into(&mut v598_7_write,&((v599_13).read_zipper()),&[]);
        }
        v596_28_cursor.ascend(1);
      }
      drop(v598_7_write);
      drop(v598_6);
      compose(&(v597_5),&(v598_7))
    };
    drop(v597_5);
    let v597_9: Space = intersect(&(*CONSTANT_2),&(v597_2));
    drop(v597_2);
    let v597_10: Space = if has_head(&(v597_9)) { singleton(&[]) } else { Space::new() };
    drop(v597_9);
    let v597_13: Space = if (&(v597_10)).is_empty() { Space::new() } else {
      let mut v608_12 = Space::new();
      let mut v608_12_write = v608_12.write_zipper();
      let mut v608_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v596_28_cursor.path()[v596_28_origin..(v596_28_origin + 1)]);
      let v608_12_origin = v608_12_cursor.path().len();
      for v608_12_byte in v608_12_cursor.child_mask().iter() {
        v608_12_cursor.descend_to_existing_byte(v608_12_byte);
        {
        let v609_2: Space = singleton(&v608_12_cursor.path()[v608_12_origin..(v608_12_origin + 1)]);
        let v609_3: Space = intersect(&(*CONSTANT_2),&(v609_2));
        let v609_4: Space = if has_head(&(v609_3)) { singleton(&[]) } else { Space::new() };
        drop(v609_3);
        let v609_5: Space = subtract(&(*CONSTANT_1),&(v609_4));
        drop(v609_4);
        let v609_7: Space = if (&(v609_5)).is_empty() { Space::new() } else {
          let mut v610_6 = Space::new();
          let mut v610_6_write = v610_6.write_zipper();
          for v610_6_byte in v608_12_cursor.child_mask().iter() {
            v608_12_cursor.descend_to_existing_byte(v610_6_byte);
            {
            let v611_2: Space = singleton(&v608_12_cursor.path()[(v608_12_origin + 1)..(v608_12_origin + 2)]);
            let v611_3: Space = intersect(&(*CONSTANT_2),&(v611_2));
            let v611_4: Space = if has_head(&(v611_3)) { singleton(&[]) } else { Space::new() };
            drop(v611_3);
            let v611_5: Space = subtract(&(*CONSTANT_1),&(v611_4));
            drop(v611_4);
            let v611_8: Space = if (&(v611_5)).is_empty() { Space::new() } else {
              let v612_7: Space = routine_17(c, &v608_12_cursor.path()[v608_12_origin..(v608_12_origin + 2)], &(*p1), &v608_12_cursor);
              compose(&(v611_5),&(v612_7))
            };
            drop(v611_5);
            let v611_9: Space = intersect(&(*CONSTANT_2),&(v611_2));
            drop(v611_2);
            let v611_10: Space = if has_head(&(v611_9)) { singleton(&[]) } else { Space::new() };
            drop(v611_9);
            let v611_12: Space = if (&(v611_10)).is_empty() { Space::new() } else {
              let v613_11: Space = routine_18(c, &v608_12_cursor.path()[v608_12_origin..(v608_12_origin + 2)], &(*p1), &v608_12_cursor);
              compose(&(v611_10),&(v613_11))
            };
            drop(v611_10);
            let v611_13: Space = unite(&(v611_8),&(v611_12));
            join_wrapped_into(&mut v610_6_write,&((v611_13).read_zipper()),&[]);
            }
            v608_12_cursor.ascend(1);
          }
          drop(v610_6_write);
          compose(&(v609_5),&(v610_6))
        };
        drop(v609_5);
        let v609_8: Space = intersect(&(*CONSTANT_2),&(v609_2));
        drop(v609_2);
        let v609_9: Space = if has_head(&(v609_8)) { singleton(&[]) } else { Space::new() };
        drop(v609_8);
        let v609_11: Space = if (&(v609_9)).is_empty() { Space::new() } else {
          let mut v614_10 = Space::new();
          let mut v614_10_write = v614_10.write_zipper();
          for v614_10_byte in v608_12_cursor.child_mask().iter() {
            v608_12_cursor.descend_to_existing_byte(v614_10_byte);
            {
            let v615_2: Space = singleton(&v608_12_cursor.path()[(v608_12_origin + 1)..(v608_12_origin + 2)]);
            let v615_3: Space = intersect(&(*CONSTANT_2),&(v615_2));
            let v615_4: Space = if has_head(&(v615_3)) { singleton(&[]) } else { Space::new() };
            drop(v615_3);
            let v615_5: Space = subtract(&(*CONSTANT_1),&(v615_4));
            drop(v615_4);
            let v615_8: Space = if (&(v615_5)).is_empty() { Space::new() } else {
              let v616_7: Space = routine_17(c, &v608_12_cursor.path()[v608_12_origin..(v608_12_origin + 2)], &(*p1), &v608_12_cursor);
              compose(&(v615_5),&(v616_7))
            };
            drop(v615_5);
            let v615_9: Space = intersect(&(*CONSTANT_2),&(v615_2));
            drop(v615_2);
            let v615_10: Space = if has_head(&(v615_9)) { singleton(&[]) } else { Space::new() };
            drop(v615_9);
            let v615_12: Space = if (&(v615_10)).is_empty() { Space::new() } else {
              let v617_11: Space = routine_19(c, &v608_12_cursor.path()[v608_12_origin..(v608_12_origin + 2)], &(*p1), &v608_12_cursor);
              compose(&(v615_10),&(v617_11))
            };
            drop(v615_10);
            let v615_13: Space = unite(&(v615_8),&(v615_12));
            join_wrapped_into(&mut v614_10_write,&((v615_13).read_zipper()),&[]);
            }
            v608_12_cursor.ascend(1);
          }
          drop(v614_10_write);
          compose(&(v609_9),&(v614_10))
        };
        drop(v609_9);
        let v609_12: Space = unite(&(v609_7),&(v609_11));
        join_wrapped_into(&mut v608_12_write,&((v609_12).read_zipper()),&[]);
        }
        v608_12_cursor.ascend(1);
      }
      drop(v608_12_cursor);
      drop(v608_12_write);
      compose(&(v597_10),&(v608_12))
    };
    drop(v597_10);
    let v597_14: Space = unite(&(v597_8),&(v597_13));
    join_wrapped_into(&mut v596_28_write,&((v597_14).read_zipper()),&[]);
    }
    v596_28_cursor.ascend(1);
  }
  drop(v596_28_cursor);
  drop(v596_28_write);
  (v596_28).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v618_21 = Space::new();
  let mut v618_21_write = v618_21.write_zipper();
  let mut v618_21_cursor = (*s0).read_zipper();
  let v618_21_origin = v618_21_cursor.path().len();
  for v618_21_byte in v618_21_cursor.child_mask().iter() {
    v618_21_cursor.descend_to_existing_byte(v618_21_byte);
    {
    let v619_2: Space = singleton(&v618_21_cursor.path()[v618_21_origin..(v618_21_origin + 1)]);
    let v619_3: Space = intersect(&(*CONSTANT_2),&(v619_2));
    let v619_4: Space = if has_head(&(v619_3)) { singleton(&[]) } else { Space::new() };
    drop(v619_3);
    let v619_5: Space = subtract(&(*CONSTANT_1),&(v619_4));
    drop(v619_4);
    let v619_8: Space = if (&(v619_5)).is_empty() { Space::new() } else {
      let v620_6: Path = concat_path(&(*p0),&v618_21_cursor.path()[v618_21_origin..(v618_21_origin + 1)]);
      let mut v620_7 = Space::new();
      let mut v620_7_write = v620_7.write_zipper();
      for v620_7_byte in v618_21_cursor.child_mask().iter() {
        v618_21_cursor.descend_to_existing_byte(v620_7_byte);
        {
        let v621_2: Space = singleton(&v618_21_cursor.path()[(v618_21_origin + 1)..(v618_21_origin + 2)]);
        let v621_3: Space = intersect(&(*CONSTANT_2),&(v621_2));
        let v621_4: Space = if has_head(&(v621_3)) { singleton(&[]) } else { Space::new() };
        drop(v621_3);
        let v621_5: Space = subtract(&(*CONSTANT_1),&(v621_4));
        drop(v621_4);
        let v621_8: Space = if (&(v621_5)).is_empty() { Space::new() } else {
          let v622_6: Path = concat_path(&(v620_6),&v618_21_cursor.path()[(v618_21_origin + 1)..(v618_21_origin + 2)]);
          let mut v622_7 = Space::new();
          let mut v622_7_write = v622_7.write_zipper();
          for v622_7_byte in v618_21_cursor.child_mask().iter() {
            v618_21_cursor.descend_to_existing_byte(v622_7_byte);
            {
            let v623_2: Space = singleton(&v618_21_cursor.path()[(v618_21_origin + 2)..(v618_21_origin + 3)]);
            let v623_3: Space = intersect(&(*CONSTANT_2),&(v623_2));
            let v623_4: Space = if has_head(&(v623_3)) { singleton(&[]) } else { Space::new() };
            drop(v623_3);
            let v623_5: Space = subtract(&(*CONSTANT_1),&(v623_4));
            drop(v623_4);
            let v623_8: Space = if (&(v623_5)).is_empty() { Space::new() } else {
              let v624_6: Path = concat_path(&(v622_6),&v618_21_cursor.path()[(v618_21_origin + 2)..(v618_21_origin + 3)]);
              let v624_7: Space = routine_44(c, &(v624_6), &(*p1), &v618_21_cursor);
              compose(&(v623_5),&(v624_7))
            };
            drop(v623_5);
            let v623_9: Space = intersect(&(*CONSTANT_2),&(v623_2));
            drop(v623_2);
            let v623_10: Space = if has_head(&(v623_9)) { singleton(&[]) } else { Space::new() };
            drop(v623_9);
            let v623_12: Space = if (&(v623_10)).is_empty() { Space::new() } else {
              let v625_6: Path = concat_path(&(v622_6),&v618_21_cursor.path()[(v618_21_origin + 2)..(v618_21_origin + 3)]);
              let v625_11: Space = routine_45(c, &(v625_6), &(*p1), &v618_21_cursor);
              drop(v625_6);
              compose(&(v623_10),&(v625_11))
            };
            drop(v623_10);
            let v623_13: Space = unite(&(v623_8),&(v623_12));
            join_wrapped_into(&mut v622_7_write,&((v623_13).read_zipper()),&[]);
            }
            v618_21_cursor.ascend(1);
          }
          drop(v622_7_write);
          compose(&(v621_5),&(v622_7))
        };
        drop(v621_5);
        let v621_9: Space = intersect(&(*CONSTANT_2),&(v621_2));
        drop(v621_2);
        let v621_10: Space = if has_head(&(v621_9)) { singleton(&[]) } else { Space::new() };
        drop(v621_9);
        let v621_12: Space = if (&(v621_10)).is_empty() { Space::new() } else {
          let v626_6: Path = concat_path(&(v620_6),&v618_21_cursor.path()[(v618_21_origin + 1)..(v618_21_origin + 2)]);
          let mut v626_11 = Space::new();
          let mut v626_11_write = v626_11.write_zipper();
          for v626_11_byte in v618_21_cursor.child_mask().iter() {
            v618_21_cursor.descend_to_existing_byte(v626_11_byte);
            {
            let v627_2: Space = singleton(&v618_21_cursor.path()[(v618_21_origin + 2)..(v618_21_origin + 3)]);
            let v627_3: Space = intersect(&(*CONSTANT_2),&(v627_2));
            let v627_4: Space = if has_head(&(v627_3)) { singleton(&[]) } else { Space::new() };
            drop(v627_3);
            let v627_5: Space = subtract(&(*CONSTANT_1),&(v627_4));
            drop(v627_4);
            let v627_8: Space = if (&(v627_5)).is_empty() { Space::new() } else {
              let v628_6: Path = concat_path(&(v626_6),&v618_21_cursor.path()[(v618_21_origin + 2)..(v618_21_origin + 3)]);
              let v628_7: Space = routine_44(c, &(v628_6), &(*p1), &v618_21_cursor);
              compose(&(v627_5),&(v628_7))
            };
            drop(v627_5);
            let v627_9: Space = intersect(&(*CONSTANT_2),&(v627_2));
            drop(v627_2);
            let v627_10: Space = if has_head(&(v627_9)) { singleton(&[]) } else { Space::new() };
            drop(v627_9);
            let v627_12: Space = if (&(v627_10)).is_empty() { Space::new() } else {
              let v629_6: Path = concat_path(&(v626_6),&v618_21_cursor.path()[(v618_21_origin + 2)..(v618_21_origin + 3)]);
              let v629_11: Space = routine_19(c, &(v629_6), &(*p1), &v618_21_cursor);
              drop(v629_6);
              compose(&(v627_10),&(v629_11))
            };
            drop(v627_10);
            let v627_13: Space = unite(&(v627_8),&(v627_12));
            join_wrapped_into(&mut v626_11_write,&((v627_13).read_zipper()),&[]);
            }
            v618_21_cursor.ascend(1);
          }
          drop(v626_11_write);
          drop(v626_6);
          compose(&(v621_10),&(v626_11))
        };
        drop(v621_10);
        let v621_13: Space = unite(&(v621_8),&(v621_12));
        join_wrapped_into(&mut v620_7_write,&((v621_13).read_zipper()),&[]);
        }
        v618_21_cursor.ascend(1);
      }
      drop(v620_7_write);
      compose(&(v619_5),&(v620_7))
    };
    drop(v619_5);
    let v619_9: Space = intersect(&(*CONSTANT_2),&(v619_2));
    drop(v619_2);
    let v619_10: Space = if has_head(&(v619_9)) { singleton(&[]) } else { Space::new() };
    drop(v619_9);
    let v619_12: Space = if (&(v619_10)).is_empty() { Space::new() } else {
      let v630_6: Path = concat_path(&(*p0),&v618_21_cursor.path()[v618_21_origin..(v618_21_origin + 1)]);
      let mut v630_11 = Space::new();
      let mut v630_11_write = v630_11.write_zipper();
      for v630_11_byte in v618_21_cursor.child_mask().iter() {
        v618_21_cursor.descend_to_existing_byte(v630_11_byte);
        {
        let v631_2: Space = singleton(&v618_21_cursor.path()[(v618_21_origin + 1)..(v618_21_origin + 2)]);
        let v631_3: Space = intersect(&(*CONSTANT_2),&(v631_2));
        let v631_4: Space = if has_head(&(v631_3)) { singleton(&[]) } else { Space::new() };
        drop(v631_3);
        let v631_5: Space = subtract(&(*CONSTANT_1),&(v631_4));
        drop(v631_4);
        let v631_8: Space = if (&(v631_5)).is_empty() { Space::new() } else {
          let v632_6: Path = concat_path(&(v630_6),&v618_21_cursor.path()[(v618_21_origin + 1)..(v618_21_origin + 2)]);
          let mut v632_7 = Space::new();
          let mut v632_7_write = v632_7.write_zipper();
          for v632_7_byte in v618_21_cursor.child_mask().iter() {
            v618_21_cursor.descend_to_existing_byte(v632_7_byte);
            {
            let v633_2: Space = singleton(&v618_21_cursor.path()[(v618_21_origin + 2)..(v618_21_origin + 3)]);
            let v633_3: Space = intersect(&(*CONSTANT_2),&(v633_2));
            let v633_4: Space = if has_head(&(v633_3)) { singleton(&[]) } else { Space::new() };
            drop(v633_3);
            let v633_5: Space = subtract(&(*CONSTANT_1),&(v633_4));
            drop(v633_4);
            let v633_8: Space = if (&(v633_5)).is_empty() { Space::new() } else {
              let v634_6: Path = concat_path(&(v632_6),&v618_21_cursor.path()[(v618_21_origin + 2)..(v618_21_origin + 3)]);
              let v634_7: Space = routine_44(c, &(v634_6), &(*p1), &v618_21_cursor);
              compose(&(v633_5),&(v634_7))
            };
            drop(v633_5);
            let v633_9: Space = intersect(&(*CONSTANT_2),&(v633_2));
            drop(v633_2);
            let v633_10: Space = if has_head(&(v633_9)) { singleton(&[]) } else { Space::new() };
            drop(v633_9);
            let v633_12: Space = if (&(v633_10)).is_empty() { Space::new() } else {
              let v635_6: Path = concat_path(&(v632_6),&v618_21_cursor.path()[(v618_21_origin + 2)..(v618_21_origin + 3)]);
              let v635_11: Space = routine_45(c, &(v635_6), &(*p1), &v618_21_cursor);
              drop(v635_6);
              compose(&(v633_10),&(v635_11))
            };
            drop(v633_10);
            let v633_13: Space = unite(&(v633_8),&(v633_12));
            join_wrapped_into(&mut v632_7_write,&((v633_13).read_zipper()),&[]);
            }
            v618_21_cursor.ascend(1);
          }
          drop(v632_7_write);
          compose(&(v631_5),&(v632_7))
        };
        drop(v631_5);
        let v631_9: Space = intersect(&(*CONSTANT_2),&(v631_2));
        drop(v631_2);
        let v631_10: Space = if has_head(&(v631_9)) { singleton(&[]) } else { Space::new() };
        drop(v631_9);
        let v631_11: Space = compose(&(v631_10),&v618_21_cursor);
        drop(v631_10);
        let v636_6: Path = concat_path(&(v630_6),&v618_21_cursor.path()[(v618_21_origin + 1)..(v618_21_origin + 2)]);
        let v631_12: Space = wrap(&(v631_11),&(v636_6));
        drop(v631_11);
        let v631_13: Space = wrap(&(v631_12),&(*p1));
        drop(v631_12);
        let v631_14: Space = unite(&(v631_8),&(v631_13));
        drop(v631_13);
        join_wrapped_into(&mut v630_11_write,&((v631_14).read_zipper()),&[]);
        }
        v618_21_cursor.ascend(1);
      }
      drop(v630_11_write);
      drop(v630_6);
      compose(&(v619_10),&(v630_11))
    };
    drop(v619_10);
    let v619_13: Space = unite(&(v619_8),&(v619_12));
    join_wrapped_into(&mut v618_21_write,&((v619_13).read_zipper()),&[]);
    }
    v618_21_cursor.ascend(1);
  }
  drop(v618_21_cursor);
  drop(v618_21_write);
  (v618_21).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v637_15 = Space::new();
  let mut v637_15_write = v637_15.write_zipper();
  let mut v637_15_cursor = (*s0).read_zipper();
  let v637_15_origin = v637_15_cursor.path().len();
  for v637_15_byte in v637_15_cursor.child_mask().iter() {
    v637_15_cursor.descend_to_existing_byte(v637_15_byte);
    {
    let v638_2: Space = singleton(&v637_15_cursor.path()[v637_15_origin..(v637_15_origin + 1)]);
    let v638_3: Space = intersect(&(*CONSTANT_2),&(v638_2));
    let v638_4: Space = if has_head(&(v638_3)) { singleton(&[]) } else { Space::new() };
    drop(v638_3);
    let v638_5: Space = subtract(&(*CONSTANT_1),&(v638_4));
    drop(v638_4);
    let v638_8: Space = if (&(v638_5)).is_empty() { Space::new() } else {
      let v639_6: Path = concat_path(&(*p0),&v637_15_cursor.path()[v637_15_origin..(v637_15_origin + 1)]);
      let mut v639_7 = Space::new();
      let mut v639_7_write = v639_7.write_zipper();
      for v639_7_byte in v637_15_cursor.child_mask().iter() {
        v637_15_cursor.descend_to_existing_byte(v639_7_byte);
        {
        let v640_2: Space = singleton(&v637_15_cursor.path()[(v637_15_origin + 1)..(v637_15_origin + 2)]);
        let v640_3: Space = intersect(&(*CONSTANT_2),&(v640_2));
        let v640_4: Space = if has_head(&(v640_3)) { singleton(&[]) } else { Space::new() };
        drop(v640_3);
        let v640_5: Space = subtract(&(*CONSTANT_1),&(v640_4));
        drop(v640_4);
        let v640_8: Space = if (&(v640_5)).is_empty() { Space::new() } else {
          let v641_6: Path = concat_path(&(v639_6),&v637_15_cursor.path()[(v637_15_origin + 1)..(v637_15_origin + 2)]);
          let mut v641_7 = Space::new();
          let mut v641_7_write = v641_7.write_zipper();
          for v641_7_byte in v637_15_cursor.child_mask().iter() {
            v637_15_cursor.descend_to_existing_byte(v641_7_byte);
            {
            let v642_2: Space = singleton(&v637_15_cursor.path()[(v637_15_origin + 2)..(v637_15_origin + 3)]);
            let v642_3: Space = intersect(&(*CONSTANT_2),&(v642_2));
            let v642_4: Space = if has_head(&(v642_3)) { singleton(&[]) } else { Space::new() };
            drop(v642_3);
            let v642_5: Space = subtract(&(*CONSTANT_1),&(v642_4));
            drop(v642_4);
            let v642_8: Space = if (&(v642_5)).is_empty() { Space::new() } else {
              let v643_6: Path = concat_path(&(v641_6),&v637_15_cursor.path()[(v637_15_origin + 2)..(v637_15_origin + 3)]);
              let v643_7: Space = routine_44(c, &(v643_6), &(*p1), &v637_15_cursor);
              compose(&(v642_5),&(v643_7))
            };
            drop(v642_5);
            let v642_9: Space = intersect(&(*CONSTANT_2),&(v642_2));
            drop(v642_2);
            let v642_10: Space = if has_head(&(v642_9)) { singleton(&[]) } else { Space::new() };
            drop(v642_9);
            let v642_12: Space = if (&(v642_10)).is_empty() { Space::new() } else {
              let v644_6: Path = concat_path(&(v641_6),&v637_15_cursor.path()[(v637_15_origin + 2)..(v637_15_origin + 3)]);
              let v644_11: Space = routine_45(c, &(v644_6), &(*p1), &v637_15_cursor);
              drop(v644_6);
              compose(&(v642_10),&(v644_11))
            };
            drop(v642_10);
            let v642_13: Space = unite(&(v642_8),&(v642_12));
            join_wrapped_into(&mut v641_7_write,&((v642_13).read_zipper()),&[]);
            }
            v637_15_cursor.ascend(1);
          }
          drop(v641_7_write);
          compose(&(v640_5),&(v641_7))
        };
        drop(v640_5);
        let v640_9: Space = intersect(&(*CONSTANT_2),&(v640_2));
        drop(v640_2);
        let v640_10: Space = if has_head(&(v640_9)) { singleton(&[]) } else { Space::new() };
        drop(v640_9);
        let v640_12: Space = if (&(v640_10)).is_empty() { Space::new() } else {
          let v645_6: Path = concat_path(&(v639_6),&v637_15_cursor.path()[(v637_15_origin + 1)..(v637_15_origin + 2)]);
          let mut v645_11 = Space::new();
          let mut v645_11_write = v645_11.write_zipper();
          for v645_11_byte in v637_15_cursor.child_mask().iter() {
            v637_15_cursor.descend_to_existing_byte(v645_11_byte);
            {
            let v646_2: Space = singleton(&v637_15_cursor.path()[(v637_15_origin + 2)..(v637_15_origin + 3)]);
            let v646_3: Space = intersect(&(*CONSTANT_2),&(v646_2));
            let v646_4: Space = if has_head(&(v646_3)) { singleton(&[]) } else { Space::new() };
            drop(v646_3);
            let v646_5: Space = subtract(&(*CONSTANT_1),&(v646_4));
            drop(v646_4);
            let v646_8: Space = if (&(v646_5)).is_empty() { Space::new() } else {
              let v647_6: Path = concat_path(&(v645_6),&v637_15_cursor.path()[(v637_15_origin + 2)..(v637_15_origin + 3)]);
              let v647_7: Space = routine_44(c, &(v647_6), &(*p1), &v637_15_cursor);
              compose(&(v646_5),&(v647_7))
            };
            drop(v646_5);
            let v646_9: Space = intersect(&(*CONSTANT_2),&(v646_2));
            drop(v646_2);
            let v646_10: Space = if has_head(&(v646_9)) { singleton(&[]) } else { Space::new() };
            drop(v646_9);
            let v646_12: Space = if (&(v646_10)).is_empty() { Space::new() } else {
              let v648_6: Path = concat_path(&(v645_6),&v637_15_cursor.path()[(v637_15_origin + 2)..(v637_15_origin + 3)]);
              let v648_11: Space = routine_19(c, &(v648_6), &(*p1), &v637_15_cursor);
              drop(v648_6);
              compose(&(v646_10),&(v648_11))
            };
            drop(v646_10);
            let v646_13: Space = unite(&(v646_8),&(v646_12));
            join_wrapped_into(&mut v645_11_write,&((v646_13).read_zipper()),&[]);
            }
            v637_15_cursor.ascend(1);
          }
          drop(v645_11_write);
          drop(v645_6);
          compose(&(v640_10),&(v645_11))
        };
        drop(v640_10);
        let v640_13: Space = unite(&(v640_8),&(v640_12));
        join_wrapped_into(&mut v639_7_write,&((v640_13).read_zipper()),&[]);
        }
        v637_15_cursor.ascend(1);
      }
      drop(v639_7_write);
      compose(&(v638_5),&(v639_7))
    };
    drop(v638_5);
    let v638_9: Space = intersect(&(*CONSTANT_2),&(v638_2));
    drop(v638_2);
    let v638_10: Space = if has_head(&(v638_9)) { singleton(&[]) } else { Space::new() };
    drop(v638_9);
    let v638_11: Space = compose(&(v638_10),&v637_15_cursor);
    drop(v638_10);
    let v649_6: Path = concat_path(&(*p0),&v637_15_cursor.path()[v637_15_origin..(v637_15_origin + 1)]);
    let v638_12: Space = wrap(&(v638_11),&(v649_6));
    drop(v638_11);
    let v638_13: Space = wrap(&(v638_12),&(*p1));
    drop(v638_12);
    let v638_14: Space = unite(&(v638_8),&(v638_13));
    drop(v638_13);
    join_wrapped_into(&mut v637_15_write,&((v638_14).read_zipper()),&[]);
    }
    v637_15_cursor.ascend(1);
  }
  drop(v637_15_cursor);
  drop(v637_15_write);
  (v637_15).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v650_28 = Space::new();
  let mut v650_28_write = v650_28.write_zipper();
  let mut v650_28_cursor = (*s0).read_zipper();
  let v650_28_origin = v650_28_cursor.path().len();
  for v650_28_byte in v650_28_cursor.child_mask().iter() {
    v650_28_cursor.descend_to_existing_byte(v650_28_byte);
    {
    let v651_2: Space = singleton(&v650_28_cursor.path()[v650_28_origin..(v650_28_origin + 1)]);
    let v651_3: Space = intersect(&(*CONSTANT_2),&(v651_2));
    let v651_4: Space = if has_head(&(v651_3)) { singleton(&[]) } else { Space::new() };
    drop(v651_3);
    let v651_5: Space = subtract(&(*CONSTANT_1),&(v651_4));
    drop(v651_4);
    let v651_8: Space = if (&(v651_5)).is_empty() { Space::new() } else {
      let v652_6: Path = concat_path(&(*p0),&v650_28_cursor.path()[v650_28_origin..(v650_28_origin + 1)]);
      let mut v652_7 = Space::new();
      let mut v652_7_write = v652_7.write_zipper();
      for v652_7_byte in v650_28_cursor.child_mask().iter() {
        v650_28_cursor.descend_to_existing_byte(v652_7_byte);
        {
        let v653_2: Space = singleton(&v650_28_cursor.path()[(v650_28_origin + 1)..(v650_28_origin + 2)]);
        let v653_3: Space = intersect(&(*CONSTANT_2),&(v653_2));
        let v653_4: Space = if has_head(&(v653_3)) { singleton(&[]) } else { Space::new() };
        drop(v653_3);
        let v653_5: Space = subtract(&(*CONSTANT_1),&(v653_4));
        drop(v653_4);
        let v653_8: Space = if (&(v653_5)).is_empty() { Space::new() } else {
          let v654_6: Path = concat_path(&(v652_6),&v650_28_cursor.path()[(v650_28_origin + 1)..(v650_28_origin + 2)]);
          let mut v654_7 = Space::new();
          let mut v654_7_write = v654_7.write_zipper();
          for v654_7_byte in v650_28_cursor.child_mask().iter() {
            v650_28_cursor.descend_to_existing_byte(v654_7_byte);
            {
            let v655_2: Space = singleton(&v650_28_cursor.path()[(v650_28_origin + 2)..(v650_28_origin + 3)]);
            let v655_3: Space = intersect(&(*CONSTANT_2),&(v655_2));
            let v655_4: Space = if has_head(&(v655_3)) { singleton(&[]) } else { Space::new() };
            drop(v655_3);
            let v655_5: Space = subtract(&(*CONSTANT_1),&(v655_4));
            drop(v655_4);
            let v655_8: Space = if (&(v655_5)).is_empty() { Space::new() } else {
              let v656_6: Path = concat_path(&(v654_6),&v650_28_cursor.path()[(v650_28_origin + 2)..(v650_28_origin + 3)]);
              let v656_7: Space = routine_46(c, &(v656_6), &(*p1), &v650_28_cursor, &(*s1));
              compose(&(v655_5),&(v656_7))
            };
            drop(v655_5);
            let v655_9: Space = intersect(&(*CONSTANT_2),&(v655_2));
            drop(v655_2);
            let v655_10: Space = if has_head(&(v655_9)) { singleton(&[]) } else { Space::new() };
            drop(v655_9);
            let v655_12: Space = if (&(v655_10)).is_empty() { Space::new() } else {
              let v657_6: Path = concat_path(&(v654_6),&v650_28_cursor.path()[(v650_28_origin + 2)..(v650_28_origin + 3)]);
              let v657_11: Space = routine_47(c, &(v657_6), &(*p1), &v650_28_cursor, &(*s1));
              drop(v657_6);
              compose(&(v655_10),&(v657_11))
            };
            drop(v655_10);
            let v655_13: Space = unite(&(v655_8),&(v655_12));
            join_wrapped_into(&mut v654_7_write,&((v655_13).read_zipper()),&[]);
            }
            v650_28_cursor.ascend(1);
          }
          drop(v654_7_write);
          compose(&(v653_5),&(v654_7))
        };
        drop(v653_5);
        let v653_9: Space = intersect(&(*CONSTANT_2),&(v653_2));
        drop(v653_2);
        let v653_10: Space = if has_head(&(v653_9)) { singleton(&[]) } else { Space::new() };
        drop(v653_9);
        let v653_12: Space = if (&(v653_10)).is_empty() { Space::new() } else {
          let v658_6: Path = concat_path(&(v652_6),&v650_28_cursor.path()[(v650_28_origin + 1)..(v650_28_origin + 2)]);
          let mut v658_11 = Space::new();
          let mut v658_11_write = v658_11.write_zipper();
          for v658_11_byte in v650_28_cursor.child_mask().iter() {
            v650_28_cursor.descend_to_existing_byte(v658_11_byte);
            {
            let v659_2: Space = singleton(&v650_28_cursor.path()[(v650_28_origin + 2)..(v650_28_origin + 3)]);
            let v659_3: Space = intersect(&(*CONSTANT_2),&(v659_2));
            let v659_4: Space = if has_head(&(v659_3)) { singleton(&[]) } else { Space::new() };
            drop(v659_3);
            let v659_5: Space = subtract(&(*CONSTANT_1),&(v659_4));
            drop(v659_4);
            let v659_8: Space = if (&(v659_5)).is_empty() { Space::new() } else {
              let v660_6: Path = concat_path(&(v658_6),&v650_28_cursor.path()[(v650_28_origin + 2)..(v650_28_origin + 3)]);
              let v660_7: Space = routine_46(c, &(v660_6), &(*p1), &v650_28_cursor, &(*s1));
              compose(&(v659_5),&(v660_7))
            };
            drop(v659_5);
            let v659_9: Space = intersect(&(*CONSTANT_2),&(v659_2));
            drop(v659_2);
            let v659_10: Space = if has_head(&(v659_9)) { singleton(&[]) } else { Space::new() };
            drop(v659_9);
            let v659_12: Space = if (&(v659_10)).is_empty() { Space::new() } else {
              let v661_6: Path = concat_path(&(v658_6),&v650_28_cursor.path()[(v650_28_origin + 2)..(v650_28_origin + 3)]);
              let v661_11: Space = routine_10(c, &(v661_6), &(*p1), &v650_28_cursor, &(*s1));
              drop(v661_6);
              compose(&(v659_10),&(v661_11))
            };
            drop(v659_10);
            let v659_13: Space = unite(&(v659_8),&(v659_12));
            join_wrapped_into(&mut v658_11_write,&((v659_13).read_zipper()),&[]);
            }
            v650_28_cursor.ascend(1);
          }
          drop(v658_11_write);
          drop(v658_6);
          compose(&(v653_10),&(v658_11))
        };
        drop(v653_10);
        let v653_13: Space = unite(&(v653_8),&(v653_12));
        join_wrapped_into(&mut v652_7_write,&((v653_13).read_zipper()),&[]);
        }
        v650_28_cursor.ascend(1);
      }
      drop(v652_7_write);
      compose(&(v651_5),&(v652_7))
    };
    drop(v651_5);
    let v651_9: Space = intersect(&(*CONSTANT_2),&(v651_2));
    drop(v651_2);
    let v651_10: Space = if has_head(&(v651_9)) { singleton(&[]) } else { Space::new() };
    drop(v651_9);
    let v651_13: Space = if (&(v651_10)).is_empty() { Space::new() } else {
      let v662_6: Path = concat_path(&(*p0),&v650_28_cursor.path()[v650_28_origin..(v650_28_origin + 1)]);
      let mut v662_12 = Space::new();
      let mut v662_12_write = v662_12.write_zipper();
      for v662_12_byte in v650_28_cursor.child_mask().iter() {
        v650_28_cursor.descend_to_existing_byte(v662_12_byte);
        {
        let v663_2: Space = singleton(&v650_28_cursor.path()[(v650_28_origin + 1)..(v650_28_origin + 2)]);
        let v663_3: Space = intersect(&(*CONSTANT_2),&(v663_2));
        let v663_4: Space = if has_head(&(v663_3)) { singleton(&[]) } else { Space::new() };
        drop(v663_3);
        let v663_5: Space = subtract(&(*CONSTANT_1),&(v663_4));
        drop(v663_4);
        let v663_8: Space = if (&(v663_5)).is_empty() { Space::new() } else {
          let v664_6: Path = concat_path(&(v662_6),&v650_28_cursor.path()[(v650_28_origin + 1)..(v650_28_origin + 2)]);
          let mut v664_7 = Space::new();
          let mut v664_7_write = v664_7.write_zipper();
          for v664_7_byte in v650_28_cursor.child_mask().iter() {
            v650_28_cursor.descend_to_existing_byte(v664_7_byte);
            {
            let v665_2: Space = singleton(&v650_28_cursor.path()[(v650_28_origin + 2)..(v650_28_origin + 3)]);
            let v665_3: Space = intersect(&(*CONSTANT_2),&(v665_2));
            let v665_4: Space = if has_head(&(v665_3)) { singleton(&[]) } else { Space::new() };
            drop(v665_3);
            let v665_5: Space = subtract(&(*CONSTANT_1),&(v665_4));
            drop(v665_4);
            let v665_8: Space = if (&(v665_5)).is_empty() { Space::new() } else {
              let v666_6: Path = concat_path(&(v664_6),&v650_28_cursor.path()[(v650_28_origin + 2)..(v650_28_origin + 3)]);
              let v666_7: Space = routine_46(c, &(v666_6), &(*p1), &v650_28_cursor, &(*s1));
              compose(&(v665_5),&(v666_7))
            };
            drop(v665_5);
            let v665_9: Space = intersect(&(*CONSTANT_2),&(v665_2));
            drop(v665_2);
            let v665_10: Space = if has_head(&(v665_9)) { singleton(&[]) } else { Space::new() };
            drop(v665_9);
            let v665_12: Space = if (&(v665_10)).is_empty() { Space::new() } else {
              let v667_6: Path = concat_path(&(v664_6),&v650_28_cursor.path()[(v650_28_origin + 2)..(v650_28_origin + 3)]);
              let v667_11: Space = routine_47(c, &(v667_6), &(*p1), &v650_28_cursor, &(*s1));
              drop(v667_6);
              compose(&(v665_10),&(v667_11))
            };
            drop(v665_10);
            let v665_13: Space = unite(&(v665_8),&(v665_12));
            join_wrapped_into(&mut v664_7_write,&((v665_13).read_zipper()),&[]);
            }
            v650_28_cursor.ascend(1);
          }
          drop(v664_7_write);
          drop(v664_6);
          compose(&(v663_5),&(v664_7))
        };
        drop(v663_5);
        let v663_9: Space = intersect(&(*CONSTANT_2),&(v663_2));
        drop(v663_2);
        let v663_10: Space = if has_head(&(v663_9)) { singleton(&[]) } else { Space::new() };
        drop(v663_9);
        let v663_13: Space = if (&(v663_10)).is_empty() { Space::new() } else {
          let mut v668_12 = Space::new();
          let mut v668_12_write = v668_12.write_zipper();
          let mut v668_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v650_28_cursor.path()[v650_28_origin..(v650_28_origin + 1)]),&v650_28_cursor.path()[(v650_28_origin + 1)..(v650_28_origin + 2)]);
          let v668_12_origin = v668_12_cursor.path().len();
          for v668_12_byte in v668_12_cursor.child_mask().iter() {
            v668_12_cursor.descend_to_existing_byte(v668_12_byte);
            {
            let v669_2: Space = singleton(&v668_12_cursor.path()[v668_12_origin..(v668_12_origin + 1)]);
            let v669_3: Space = intersect(&(*CONSTANT_2),&(v669_2));
            let v669_4: Space = if has_head(&(v669_3)) { singleton(&[]) } else { Space::new() };
            drop(v669_3);
            let v669_5: Space = subtract(&(*CONSTANT_1),&(v669_4));
            drop(v669_4);
            let v669_7: Space = if (&(v669_5)).is_empty() { Space::new() } else {
              let v670_6: Space = routine_13(c, &v668_12_cursor.path()[v668_12_origin..(v668_12_origin + 1)], &(*p1), &v668_12_cursor);
              compose(&(v669_5),&(v670_6))
            };
            drop(v669_5);
            let v669_8: Space = intersect(&(*CONSTANT_2),&(v669_2));
            drop(v669_2);
            let v669_9: Space = if has_head(&(v669_8)) { singleton(&[]) } else { Space::new() };
            drop(v669_8);
            let v669_11: Space = if (&(v669_9)).is_empty() { Space::new() } else {
              let v671_10: Space = routine_14(c, &v668_12_cursor.path()[v668_12_origin..(v668_12_origin + 1)], &(*p1), &v668_12_cursor);
              compose(&(v669_9),&(v671_10))
            };
            drop(v669_9);
            let v669_12: Space = unite(&(v669_7),&(v669_11));
            join_wrapped_into(&mut v668_12_write,&((v669_12).read_zipper()),&[]);
            }
            v668_12_cursor.ascend(1);
          }
          drop(v668_12_cursor);
          drop(v668_12_write);
          compose(&(v663_10),&(v668_12))
        };
        drop(v663_10);
        let v663_14: Space = unite(&(v663_8),&(v663_13));
        join_wrapped_into(&mut v662_12_write,&((v663_14).read_zipper()),&[]);
        }
        v650_28_cursor.ascend(1);
      }
      drop(v662_12_write);
      drop(v662_6);
      compose(&(v651_10),&(v662_12))
    };
    drop(v651_10);
    let v651_14: Space = unite(&(v651_8),&(v651_13));
    join_wrapped_into(&mut v650_28_write,&((v651_14).read_zipper()),&[]);
    }
    v650_28_cursor.ascend(1);
  }
  drop(v650_28_cursor);
  drop(v650_28_write);
  (v650_28).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v672_28 = Space::new();
  let mut v672_28_write = v672_28.write_zipper();
  let mut v672_28_cursor = (*s0).read_zipper();
  let v672_28_origin = v672_28_cursor.path().len();
  for v672_28_byte in v672_28_cursor.child_mask().iter() {
    v672_28_cursor.descend_to_existing_byte(v672_28_byte);
    {
    let v673_2: Space = singleton(&v672_28_cursor.path()[v672_28_origin..(v672_28_origin + 1)]);
    let v673_3: Space = intersect(&(*CONSTANT_2),&(v673_2));
    let v673_4: Space = if has_head(&(v673_3)) { singleton(&[]) } else { Space::new() };
    drop(v673_3);
    let v673_5: Space = subtract(&(*CONSTANT_1),&(v673_4));
    drop(v673_4);
    let v673_8: Space = if (&(v673_5)).is_empty() { Space::new() } else {
      let v674_6: Path = concat_path(&(*p0),&v672_28_cursor.path()[v672_28_origin..(v672_28_origin + 1)]);
      let mut v674_7 = Space::new();
      let mut v674_7_write = v674_7.write_zipper();
      for v674_7_byte in v672_28_cursor.child_mask().iter() {
        v672_28_cursor.descend_to_existing_byte(v674_7_byte);
        {
        let v675_2: Space = singleton(&v672_28_cursor.path()[(v672_28_origin + 1)..(v672_28_origin + 2)]);
        let v675_3: Space = intersect(&(*CONSTANT_2),&(v675_2));
        let v675_4: Space = if has_head(&(v675_3)) { singleton(&[]) } else { Space::new() };
        drop(v675_3);
        let v675_5: Space = subtract(&(*CONSTANT_1),&(v675_4));
        drop(v675_4);
        let v675_8: Space = if (&(v675_5)).is_empty() { Space::new() } else {
          let v676_6: Path = concat_path(&(v674_6),&v672_28_cursor.path()[(v672_28_origin + 1)..(v672_28_origin + 2)]);
          let mut v676_7 = Space::new();
          let mut v676_7_write = v676_7.write_zipper();
          for v676_7_byte in v672_28_cursor.child_mask().iter() {
            v672_28_cursor.descend_to_existing_byte(v676_7_byte);
            {
            let v677_2: Space = singleton(&v672_28_cursor.path()[(v672_28_origin + 2)..(v672_28_origin + 3)]);
            let v677_3: Space = intersect(&(*CONSTANT_2),&(v677_2));
            let v677_4: Space = if has_head(&(v677_3)) { singleton(&[]) } else { Space::new() };
            drop(v677_3);
            let v677_5: Space = subtract(&(*CONSTANT_1),&(v677_4));
            drop(v677_4);
            let v677_8: Space = if (&(v677_5)).is_empty() { Space::new() } else {
              let v678_6: Path = concat_path(&(v676_6),&v672_28_cursor.path()[(v672_28_origin + 2)..(v672_28_origin + 3)]);
              let v678_7: Space = routine_46(c, &(v678_6), &(*p1), &v672_28_cursor, &(*s1));
              compose(&(v677_5),&(v678_7))
            };
            drop(v677_5);
            let v677_9: Space = intersect(&(*CONSTANT_2),&(v677_2));
            drop(v677_2);
            let v677_10: Space = if has_head(&(v677_9)) { singleton(&[]) } else { Space::new() };
            drop(v677_9);
            let v677_12: Space = if (&(v677_10)).is_empty() { Space::new() } else {
              let v679_6: Path = concat_path(&(v676_6),&v672_28_cursor.path()[(v672_28_origin + 2)..(v672_28_origin + 3)]);
              let v679_11: Space = routine_47(c, &(v679_6), &(*p1), &v672_28_cursor, &(*s1));
              drop(v679_6);
              compose(&(v677_10),&(v679_11))
            };
            drop(v677_10);
            let v677_13: Space = unite(&(v677_8),&(v677_12));
            join_wrapped_into(&mut v676_7_write,&((v677_13).read_zipper()),&[]);
            }
            v672_28_cursor.ascend(1);
          }
          drop(v676_7_write);
          compose(&(v675_5),&(v676_7))
        };
        drop(v675_5);
        let v675_9: Space = intersect(&(*CONSTANT_2),&(v675_2));
        drop(v675_2);
        let v675_10: Space = if has_head(&(v675_9)) { singleton(&[]) } else { Space::new() };
        drop(v675_9);
        let v675_12: Space = if (&(v675_10)).is_empty() { Space::new() } else {
          let v680_6: Path = concat_path(&(v674_6),&v672_28_cursor.path()[(v672_28_origin + 1)..(v672_28_origin + 2)]);
          let mut v680_11 = Space::new();
          let mut v680_11_write = v680_11.write_zipper();
          for v680_11_byte in v672_28_cursor.child_mask().iter() {
            v672_28_cursor.descend_to_existing_byte(v680_11_byte);
            {
            let v681_2: Space = singleton(&v672_28_cursor.path()[(v672_28_origin + 2)..(v672_28_origin + 3)]);
            let v681_3: Space = intersect(&(*CONSTANT_2),&(v681_2));
            let v681_4: Space = if has_head(&(v681_3)) { singleton(&[]) } else { Space::new() };
            drop(v681_3);
            let v681_5: Space = subtract(&(*CONSTANT_1),&(v681_4));
            drop(v681_4);
            let v681_8: Space = if (&(v681_5)).is_empty() { Space::new() } else {
              let v682_6: Path = concat_path(&(v680_6),&v672_28_cursor.path()[(v672_28_origin + 2)..(v672_28_origin + 3)]);
              let v682_7: Space = routine_46(c, &(v682_6), &(*p1), &v672_28_cursor, &(*s1));
              compose(&(v681_5),&(v682_7))
            };
            drop(v681_5);
            let v681_9: Space = intersect(&(*CONSTANT_2),&(v681_2));
            drop(v681_2);
            let v681_10: Space = if has_head(&(v681_9)) { singleton(&[]) } else { Space::new() };
            drop(v681_9);
            let v681_12: Space = if (&(v681_10)).is_empty() { Space::new() } else {
              let v683_6: Path = concat_path(&(v680_6),&v672_28_cursor.path()[(v672_28_origin + 2)..(v672_28_origin + 3)]);
              let v683_11: Space = routine_10(c, &(v683_6), &(*p1), &v672_28_cursor, &(*s1));
              drop(v683_6);
              compose(&(v681_10),&(v683_11))
            };
            drop(v681_10);
            let v681_13: Space = unite(&(v681_8),&(v681_12));
            join_wrapped_into(&mut v680_11_write,&((v681_13).read_zipper()),&[]);
            }
            v672_28_cursor.ascend(1);
          }
          drop(v680_11_write);
          drop(v680_6);
          compose(&(v675_10),&(v680_11))
        };
        drop(v675_10);
        let v675_13: Space = unite(&(v675_8),&(v675_12));
        join_wrapped_into(&mut v674_7_write,&((v675_13).read_zipper()),&[]);
        }
        v672_28_cursor.ascend(1);
      }
      drop(v674_7_write);
      drop(v674_6);
      compose(&(v673_5),&(v674_7))
    };
    drop(v673_5);
    let v673_9: Space = intersect(&(*CONSTANT_2),&(v673_2));
    drop(v673_2);
    let v673_10: Space = if has_head(&(v673_9)) { singleton(&[]) } else { Space::new() };
    drop(v673_9);
    let v673_13: Space = if (&(v673_10)).is_empty() { Space::new() } else {
      let mut v684_12 = Space::new();
      let mut v684_12_write = v684_12.write_zipper();
      let mut v684_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v672_28_cursor.path()[v672_28_origin..(v672_28_origin + 1)]);
      let v684_12_origin = v684_12_cursor.path().len();
      for v684_12_byte in v684_12_cursor.child_mask().iter() {
        v684_12_cursor.descend_to_existing_byte(v684_12_byte);
        {
        let v685_2: Space = singleton(&v684_12_cursor.path()[v684_12_origin..(v684_12_origin + 1)]);
        let v685_3: Space = intersect(&(*CONSTANT_2),&(v685_2));
        let v685_4: Space = if has_head(&(v685_3)) { singleton(&[]) } else { Space::new() };
        drop(v685_3);
        let v685_5: Space = subtract(&(*CONSTANT_1),&(v685_4));
        drop(v685_4);
        let v685_7: Space = if (&(v685_5)).is_empty() { Space::new() } else {
          let mut v686_6 = Space::new();
          let mut v686_6_write = v686_6.write_zipper();
          for v686_6_byte in v684_12_cursor.child_mask().iter() {
            v684_12_cursor.descend_to_existing_byte(v686_6_byte);
            {
            let v687_2: Space = singleton(&v684_12_cursor.path()[(v684_12_origin + 1)..(v684_12_origin + 2)]);
            let v687_3: Space = intersect(&(*CONSTANT_2),&(v687_2));
            let v687_4: Space = if has_head(&(v687_3)) { singleton(&[]) } else { Space::new() };
            drop(v687_3);
            let v687_5: Space = subtract(&(*CONSTANT_1),&(v687_4));
            drop(v687_4);
            let v687_8: Space = if (&(v687_5)).is_empty() { Space::new() } else {
              let v688_7: Space = routine_17(c, &v684_12_cursor.path()[v684_12_origin..(v684_12_origin + 2)], &(*p1), &v684_12_cursor);
              compose(&(v687_5),&(v688_7))
            };
            drop(v687_5);
            let v687_9: Space = intersect(&(*CONSTANT_2),&(v687_2));
            drop(v687_2);
            let v687_10: Space = if has_head(&(v687_9)) { singleton(&[]) } else { Space::new() };
            drop(v687_9);
            let v687_12: Space = if (&(v687_10)).is_empty() { Space::new() } else {
              let v689_11: Space = routine_18(c, &v684_12_cursor.path()[v684_12_origin..(v684_12_origin + 2)], &(*p1), &v684_12_cursor);
              compose(&(v687_10),&(v689_11))
            };
            drop(v687_10);
            let v687_13: Space = unite(&(v687_8),&(v687_12));
            join_wrapped_into(&mut v686_6_write,&((v687_13).read_zipper()),&[]);
            }
            v684_12_cursor.ascend(1);
          }
          drop(v686_6_write);
          compose(&(v685_5),&(v686_6))
        };
        drop(v685_5);
        let v685_8: Space = intersect(&(*CONSTANT_2),&(v685_2));
        drop(v685_2);
        let v685_9: Space = if has_head(&(v685_8)) { singleton(&[]) } else { Space::new() };
        drop(v685_8);
        let v685_11: Space = if (&(v685_9)).is_empty() { Space::new() } else {
          let mut v690_10 = Space::new();
          let mut v690_10_write = v690_10.write_zipper();
          for v690_10_byte in v684_12_cursor.child_mask().iter() {
            v684_12_cursor.descend_to_existing_byte(v690_10_byte);
            {
            let v691_2: Space = singleton(&v684_12_cursor.path()[(v684_12_origin + 1)..(v684_12_origin + 2)]);
            let v691_3: Space = intersect(&(*CONSTANT_2),&(v691_2));
            let v691_4: Space = if has_head(&(v691_3)) { singleton(&[]) } else { Space::new() };
            drop(v691_3);
            let v691_5: Space = subtract(&(*CONSTANT_1),&(v691_4));
            drop(v691_4);
            let v691_8: Space = if (&(v691_5)).is_empty() { Space::new() } else {
              let v692_7: Space = routine_17(c, &v684_12_cursor.path()[v684_12_origin..(v684_12_origin + 2)], &(*p1), &v684_12_cursor);
              compose(&(v691_5),&(v692_7))
            };
            drop(v691_5);
            let v691_9: Space = intersect(&(*CONSTANT_2),&(v691_2));
            drop(v691_2);
            let v691_10: Space = if has_head(&(v691_9)) { singleton(&[]) } else { Space::new() };
            drop(v691_9);
            let v691_12: Space = if (&(v691_10)).is_empty() { Space::new() } else {
              let v693_11: Space = routine_19(c, &v684_12_cursor.path()[v684_12_origin..(v684_12_origin + 2)], &(*p1), &v684_12_cursor);
              compose(&(v691_10),&(v693_11))
            };
            drop(v691_10);
            let v691_13: Space = unite(&(v691_8),&(v691_12));
            join_wrapped_into(&mut v690_10_write,&((v691_13).read_zipper()),&[]);
            }
            v684_12_cursor.ascend(1);
          }
          drop(v690_10_write);
          compose(&(v685_9),&(v690_10))
        };
        drop(v685_9);
        let v685_12: Space = unite(&(v685_7),&(v685_11));
        join_wrapped_into(&mut v684_12_write,&((v685_12).read_zipper()),&[]);
        }
        v684_12_cursor.ascend(1);
      }
      drop(v684_12_cursor);
      drop(v684_12_write);
      compose(&(v673_10),&(v684_12))
    };
    drop(v673_10);
    let v673_14: Space = unite(&(v673_8),&(v673_13));
    join_wrapped_into(&mut v672_28_write,&((v673_14).read_zipper()),&[]);
    }
    v672_28_cursor.ascend(1);
  }
  drop(v672_28_cursor);
  drop(v672_28_write);
  (v672_28).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v694_21 = Space::new();
  let mut v694_21_write = v694_21.write_zipper();
  let mut v694_21_cursor = (*s0).read_zipper();
  let v694_21_origin = v694_21_cursor.path().len();
  for v694_21_byte in v694_21_cursor.child_mask().iter() {
    v694_21_cursor.descend_to_existing_byte(v694_21_byte);
    {
    let v695_2: Space = singleton(&v694_21_cursor.path()[v694_21_origin..(v694_21_origin + 1)]);
    let v695_3: Space = intersect(&(*CONSTANT_2),&(v695_2));
    let v695_4: Space = if has_head(&(v695_3)) { singleton(&[]) } else { Space::new() };
    drop(v695_3);
    let v695_5: Space = subtract(&(*CONSTANT_1),&(v695_4));
    drop(v695_4);
    let v695_8: Space = if (&(v695_5)).is_empty() { Space::new() } else {
      let v696_6: Path = concat_path(&(*p0),&v694_21_cursor.path()[v694_21_origin..(v694_21_origin + 1)]);
      let mut v696_7 = Space::new();
      let mut v696_7_write = v696_7.write_zipper();
      for v696_7_byte in v694_21_cursor.child_mask().iter() {
        v694_21_cursor.descend_to_existing_byte(v696_7_byte);
        {
        let v697_2: Space = singleton(&v694_21_cursor.path()[(v694_21_origin + 1)..(v694_21_origin + 2)]);
        let v697_3: Space = intersect(&(*CONSTANT_2),&(v697_2));
        let v697_4: Space = if has_head(&(v697_3)) { singleton(&[]) } else { Space::new() };
        drop(v697_3);
        let v697_5: Space = subtract(&(*CONSTANT_1),&(v697_4));
        drop(v697_4);
        let v697_8: Space = if (&(v697_5)).is_empty() { Space::new() } else {
          let v698_6: Path = concat_path(&(v696_6),&v694_21_cursor.path()[(v694_21_origin + 1)..(v694_21_origin + 2)]);
          let mut v698_7 = Space::new();
          let mut v698_7_write = v698_7.write_zipper();
          for v698_7_byte in v694_21_cursor.child_mask().iter() {
            v694_21_cursor.descend_to_existing_byte(v698_7_byte);
            {
            let v699_2: Space = singleton(&v694_21_cursor.path()[(v694_21_origin + 2)..(v694_21_origin + 3)]);
            let v699_3: Space = intersect(&(*CONSTANT_2),&(v699_2));
            let v699_4: Space = if has_head(&(v699_3)) { singleton(&[]) } else { Space::new() };
            drop(v699_3);
            let v699_5: Space = subtract(&(*CONSTANT_1),&(v699_4));
            drop(v699_4);
            let v699_8: Space = if (&(v699_5)).is_empty() { Space::new() } else {
              let v700_6: Path = concat_path(&(v698_6),&v694_21_cursor.path()[(v694_21_origin + 2)..(v694_21_origin + 3)]);
              let v700_7: Space = routine_48(c, &(v700_6), &(*p1), &v694_21_cursor);
              compose(&(v699_5),&(v700_7))
            };
            drop(v699_5);
            let v699_9: Space = intersect(&(*CONSTANT_2),&(v699_2));
            drop(v699_2);
            let v699_10: Space = if has_head(&(v699_9)) { singleton(&[]) } else { Space::new() };
            drop(v699_9);
            let v699_12: Space = if (&(v699_10)).is_empty() { Space::new() } else {
              let v701_6: Path = concat_path(&(v698_6),&v694_21_cursor.path()[(v694_21_origin + 2)..(v694_21_origin + 3)]);
              let v701_11: Space = routine_49(c, &(v701_6), &(*p1), &v694_21_cursor);
              drop(v701_6);
              compose(&(v699_10),&(v701_11))
            };
            drop(v699_10);
            let v699_13: Space = unite(&(v699_8),&(v699_12));
            join_wrapped_into(&mut v698_7_write,&((v699_13).read_zipper()),&[]);
            }
            v694_21_cursor.ascend(1);
          }
          drop(v698_7_write);
          compose(&(v697_5),&(v698_7))
        };
        drop(v697_5);
        let v697_9: Space = intersect(&(*CONSTANT_2),&(v697_2));
        drop(v697_2);
        let v697_10: Space = if has_head(&(v697_9)) { singleton(&[]) } else { Space::new() };
        drop(v697_9);
        let v697_12: Space = if (&(v697_10)).is_empty() { Space::new() } else {
          let v702_6: Path = concat_path(&(v696_6),&v694_21_cursor.path()[(v694_21_origin + 1)..(v694_21_origin + 2)]);
          let mut v702_11 = Space::new();
          let mut v702_11_write = v702_11.write_zipper();
          for v702_11_byte in v694_21_cursor.child_mask().iter() {
            v694_21_cursor.descend_to_existing_byte(v702_11_byte);
            {
            let v703_2: Space = singleton(&v694_21_cursor.path()[(v694_21_origin + 2)..(v694_21_origin + 3)]);
            let v703_3: Space = intersect(&(*CONSTANT_2),&(v703_2));
            let v703_4: Space = if has_head(&(v703_3)) { singleton(&[]) } else { Space::new() };
            drop(v703_3);
            let v703_5: Space = subtract(&(*CONSTANT_1),&(v703_4));
            drop(v703_4);
            let v703_8: Space = if (&(v703_5)).is_empty() { Space::new() } else {
              let v704_6: Path = concat_path(&(v702_6),&v694_21_cursor.path()[(v694_21_origin + 2)..(v694_21_origin + 3)]);
              let v704_7: Space = routine_48(c, &(v704_6), &(*p1), &v694_21_cursor);
              compose(&(v703_5),&(v704_7))
            };
            drop(v703_5);
            let v703_9: Space = intersect(&(*CONSTANT_2),&(v703_2));
            drop(v703_2);
            let v703_10: Space = if has_head(&(v703_9)) { singleton(&[]) } else { Space::new() };
            drop(v703_9);
            let v703_12: Space = if (&(v703_10)).is_empty() { Space::new() } else {
              let v705_6: Path = concat_path(&(v702_6),&v694_21_cursor.path()[(v694_21_origin + 2)..(v694_21_origin + 3)]);
              let v705_11: Space = routine_19(c, &(v705_6), &(*p1), &v694_21_cursor);
              drop(v705_6);
              compose(&(v703_10),&(v705_11))
            };
            drop(v703_10);
            let v703_13: Space = unite(&(v703_8),&(v703_12));
            join_wrapped_into(&mut v702_11_write,&((v703_13).read_zipper()),&[]);
            }
            v694_21_cursor.ascend(1);
          }
          drop(v702_11_write);
          drop(v702_6);
          compose(&(v697_10),&(v702_11))
        };
        drop(v697_10);
        let v697_13: Space = unite(&(v697_8),&(v697_12));
        join_wrapped_into(&mut v696_7_write,&((v697_13).read_zipper()),&[]);
        }
        v694_21_cursor.ascend(1);
      }
      drop(v696_7_write);
      compose(&(v695_5),&(v696_7))
    };
    drop(v695_5);
    let v695_9: Space = intersect(&(*CONSTANT_2),&(v695_2));
    drop(v695_2);
    let v695_10: Space = if has_head(&(v695_9)) { singleton(&[]) } else { Space::new() };
    drop(v695_9);
    let v695_12: Space = if (&(v695_10)).is_empty() { Space::new() } else {
      let v706_6: Path = concat_path(&(*p0),&v694_21_cursor.path()[v694_21_origin..(v694_21_origin + 1)]);
      let mut v706_11 = Space::new();
      let mut v706_11_write = v706_11.write_zipper();
      for v706_11_byte in v694_21_cursor.child_mask().iter() {
        v694_21_cursor.descend_to_existing_byte(v706_11_byte);
        {
        let v707_2: Space = singleton(&v694_21_cursor.path()[(v694_21_origin + 1)..(v694_21_origin + 2)]);
        let v707_3: Space = intersect(&(*CONSTANT_2),&(v707_2));
        let v707_4: Space = if has_head(&(v707_3)) { singleton(&[]) } else { Space::new() };
        drop(v707_3);
        let v707_5: Space = subtract(&(*CONSTANT_1),&(v707_4));
        drop(v707_4);
        let v707_8: Space = if (&(v707_5)).is_empty() { Space::new() } else {
          let v708_6: Path = concat_path(&(v706_6),&v694_21_cursor.path()[(v694_21_origin + 1)..(v694_21_origin + 2)]);
          let mut v708_7 = Space::new();
          let mut v708_7_write = v708_7.write_zipper();
          for v708_7_byte in v694_21_cursor.child_mask().iter() {
            v694_21_cursor.descend_to_existing_byte(v708_7_byte);
            {
            let v709_2: Space = singleton(&v694_21_cursor.path()[(v694_21_origin + 2)..(v694_21_origin + 3)]);
            let v709_3: Space = intersect(&(*CONSTANT_2),&(v709_2));
            let v709_4: Space = if has_head(&(v709_3)) { singleton(&[]) } else { Space::new() };
            drop(v709_3);
            let v709_5: Space = subtract(&(*CONSTANT_1),&(v709_4));
            drop(v709_4);
            let v709_8: Space = if (&(v709_5)).is_empty() { Space::new() } else {
              let v710_6: Path = concat_path(&(v708_6),&v694_21_cursor.path()[(v694_21_origin + 2)..(v694_21_origin + 3)]);
              let v710_7: Space = routine_48(c, &(v710_6), &(*p1), &v694_21_cursor);
              compose(&(v709_5),&(v710_7))
            };
            drop(v709_5);
            let v709_9: Space = intersect(&(*CONSTANT_2),&(v709_2));
            drop(v709_2);
            let v709_10: Space = if has_head(&(v709_9)) { singleton(&[]) } else { Space::new() };
            drop(v709_9);
            let v709_12: Space = if (&(v709_10)).is_empty() { Space::new() } else {
              let v711_6: Path = concat_path(&(v708_6),&v694_21_cursor.path()[(v694_21_origin + 2)..(v694_21_origin + 3)]);
              let v711_11: Space = routine_49(c, &(v711_6), &(*p1), &v694_21_cursor);
              drop(v711_6);
              compose(&(v709_10),&(v711_11))
            };
            drop(v709_10);
            let v709_13: Space = unite(&(v709_8),&(v709_12));
            join_wrapped_into(&mut v708_7_write,&((v709_13).read_zipper()),&[]);
            }
            v694_21_cursor.ascend(1);
          }
          drop(v708_7_write);
          compose(&(v707_5),&(v708_7))
        };
        drop(v707_5);
        let v707_9: Space = intersect(&(*CONSTANT_2),&(v707_2));
        drop(v707_2);
        let v707_10: Space = if has_head(&(v707_9)) { singleton(&[]) } else { Space::new() };
        drop(v707_9);
        let v707_11: Space = compose(&(v707_10),&v694_21_cursor);
        drop(v707_10);
        let v712_6: Path = concat_path(&(v706_6),&v694_21_cursor.path()[(v694_21_origin + 1)..(v694_21_origin + 2)]);
        let v707_12: Space = wrap(&(v707_11),&(v712_6));
        drop(v707_11);
        let v707_13: Space = wrap(&(v707_12),&(*p1));
        drop(v707_12);
        let v707_14: Space = unite(&(v707_8),&(v707_13));
        drop(v707_13);
        join_wrapped_into(&mut v706_11_write,&((v707_14).read_zipper()),&[]);
        }
        v694_21_cursor.ascend(1);
      }
      drop(v706_11_write);
      drop(v706_6);
      compose(&(v695_10),&(v706_11))
    };
    drop(v695_10);
    let v695_13: Space = unite(&(v695_8),&(v695_12));
    join_wrapped_into(&mut v694_21_write,&((v695_13).read_zipper()),&[]);
    }
    v694_21_cursor.ascend(1);
  }
  drop(v694_21_cursor);
  drop(v694_21_write);
  (v694_21).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v713_15 = Space::new();
  let mut v713_15_write = v713_15.write_zipper();
  let mut v713_15_cursor = (*s0).read_zipper();
  let v713_15_origin = v713_15_cursor.path().len();
  for v713_15_byte in v713_15_cursor.child_mask().iter() {
    v713_15_cursor.descend_to_existing_byte(v713_15_byte);
    {
    let v714_2: Space = singleton(&v713_15_cursor.path()[v713_15_origin..(v713_15_origin + 1)]);
    let v714_3: Space = intersect(&(*CONSTANT_2),&(v714_2));
    let v714_4: Space = if has_head(&(v714_3)) { singleton(&[]) } else { Space::new() };
    drop(v714_3);
    let v714_5: Space = subtract(&(*CONSTANT_1),&(v714_4));
    drop(v714_4);
    let v714_8: Space = if (&(v714_5)).is_empty() { Space::new() } else {
      let v715_6: Path = concat_path(&(*p0),&v713_15_cursor.path()[v713_15_origin..(v713_15_origin + 1)]);
      let mut v715_7 = Space::new();
      let mut v715_7_write = v715_7.write_zipper();
      for v715_7_byte in v713_15_cursor.child_mask().iter() {
        v713_15_cursor.descend_to_existing_byte(v715_7_byte);
        {
        let v716_2: Space = singleton(&v713_15_cursor.path()[(v713_15_origin + 1)..(v713_15_origin + 2)]);
        let v716_3: Space = intersect(&(*CONSTANT_2),&(v716_2));
        let v716_4: Space = if has_head(&(v716_3)) { singleton(&[]) } else { Space::new() };
        drop(v716_3);
        let v716_5: Space = subtract(&(*CONSTANT_1),&(v716_4));
        drop(v716_4);
        let v716_8: Space = if (&(v716_5)).is_empty() { Space::new() } else {
          let v717_6: Path = concat_path(&(v715_6),&v713_15_cursor.path()[(v713_15_origin + 1)..(v713_15_origin + 2)]);
          let mut v717_7 = Space::new();
          let mut v717_7_write = v717_7.write_zipper();
          for v717_7_byte in v713_15_cursor.child_mask().iter() {
            v713_15_cursor.descend_to_existing_byte(v717_7_byte);
            {
            let v718_2: Space = singleton(&v713_15_cursor.path()[(v713_15_origin + 2)..(v713_15_origin + 3)]);
            let v718_3: Space = intersect(&(*CONSTANT_2),&(v718_2));
            let v718_4: Space = if has_head(&(v718_3)) { singleton(&[]) } else { Space::new() };
            drop(v718_3);
            let v718_5: Space = subtract(&(*CONSTANT_1),&(v718_4));
            drop(v718_4);
            let v718_8: Space = if (&(v718_5)).is_empty() { Space::new() } else {
              let v719_6: Path = concat_path(&(v717_6),&v713_15_cursor.path()[(v713_15_origin + 2)..(v713_15_origin + 3)]);
              let v719_7: Space = routine_48(c, &(v719_6), &(*p1), &v713_15_cursor);
              compose(&(v718_5),&(v719_7))
            };
            drop(v718_5);
            let v718_9: Space = intersect(&(*CONSTANT_2),&(v718_2));
            drop(v718_2);
            let v718_10: Space = if has_head(&(v718_9)) { singleton(&[]) } else { Space::new() };
            drop(v718_9);
            let v718_12: Space = if (&(v718_10)).is_empty() { Space::new() } else {
              let v720_6: Path = concat_path(&(v717_6),&v713_15_cursor.path()[(v713_15_origin + 2)..(v713_15_origin + 3)]);
              let v720_11: Space = routine_49(c, &(v720_6), &(*p1), &v713_15_cursor);
              drop(v720_6);
              compose(&(v718_10),&(v720_11))
            };
            drop(v718_10);
            let v718_13: Space = unite(&(v718_8),&(v718_12));
            join_wrapped_into(&mut v717_7_write,&((v718_13).read_zipper()),&[]);
            }
            v713_15_cursor.ascend(1);
          }
          drop(v717_7_write);
          compose(&(v716_5),&(v717_7))
        };
        drop(v716_5);
        let v716_9: Space = intersect(&(*CONSTANT_2),&(v716_2));
        drop(v716_2);
        let v716_10: Space = if has_head(&(v716_9)) { singleton(&[]) } else { Space::new() };
        drop(v716_9);
        let v716_12: Space = if (&(v716_10)).is_empty() { Space::new() } else {
          let v721_6: Path = concat_path(&(v715_6),&v713_15_cursor.path()[(v713_15_origin + 1)..(v713_15_origin + 2)]);
          let mut v721_11 = Space::new();
          let mut v721_11_write = v721_11.write_zipper();
          for v721_11_byte in v713_15_cursor.child_mask().iter() {
            v713_15_cursor.descend_to_existing_byte(v721_11_byte);
            {
            let v722_2: Space = singleton(&v713_15_cursor.path()[(v713_15_origin + 2)..(v713_15_origin + 3)]);
            let v722_3: Space = intersect(&(*CONSTANT_2),&(v722_2));
            let v722_4: Space = if has_head(&(v722_3)) { singleton(&[]) } else { Space::new() };
            drop(v722_3);
            let v722_5: Space = subtract(&(*CONSTANT_1),&(v722_4));
            drop(v722_4);
            let v722_8: Space = if (&(v722_5)).is_empty() { Space::new() } else {
              let v723_6: Path = concat_path(&(v721_6),&v713_15_cursor.path()[(v713_15_origin + 2)..(v713_15_origin + 3)]);
              let v723_7: Space = routine_48(c, &(v723_6), &(*p1), &v713_15_cursor);
              compose(&(v722_5),&(v723_7))
            };
            drop(v722_5);
            let v722_9: Space = intersect(&(*CONSTANT_2),&(v722_2));
            drop(v722_2);
            let v722_10: Space = if has_head(&(v722_9)) { singleton(&[]) } else { Space::new() };
            drop(v722_9);
            let v722_12: Space = if (&(v722_10)).is_empty() { Space::new() } else {
              let v724_6: Path = concat_path(&(v721_6),&v713_15_cursor.path()[(v713_15_origin + 2)..(v713_15_origin + 3)]);
              let v724_11: Space = routine_19(c, &(v724_6), &(*p1), &v713_15_cursor);
              drop(v724_6);
              compose(&(v722_10),&(v724_11))
            };
            drop(v722_10);
            let v722_13: Space = unite(&(v722_8),&(v722_12));
            join_wrapped_into(&mut v721_11_write,&((v722_13).read_zipper()),&[]);
            }
            v713_15_cursor.ascend(1);
          }
          drop(v721_11_write);
          drop(v721_6);
          compose(&(v716_10),&(v721_11))
        };
        drop(v716_10);
        let v716_13: Space = unite(&(v716_8),&(v716_12));
        join_wrapped_into(&mut v715_7_write,&((v716_13).read_zipper()),&[]);
        }
        v713_15_cursor.ascend(1);
      }
      drop(v715_7_write);
      compose(&(v714_5),&(v715_7))
    };
    drop(v714_5);
    let v714_9: Space = intersect(&(*CONSTANT_2),&(v714_2));
    drop(v714_2);
    let v714_10: Space = if has_head(&(v714_9)) { singleton(&[]) } else { Space::new() };
    drop(v714_9);
    let v714_11: Space = compose(&(v714_10),&v713_15_cursor);
    drop(v714_10);
    let v725_6: Path = concat_path(&(*p0),&v713_15_cursor.path()[v713_15_origin..(v713_15_origin + 1)]);
    let v714_12: Space = wrap(&(v714_11),&(v725_6));
    drop(v714_11);
    let v714_13: Space = wrap(&(v714_12),&(*p1));
    drop(v714_12);
    let v714_14: Space = unite(&(v714_8),&(v714_13));
    drop(v714_13);
    join_wrapped_into(&mut v713_15_write,&((v714_14).read_zipper()),&[]);
    }
    v713_15_cursor.ascend(1);
  }
  drop(v713_15_cursor);
  drop(v713_15_write);
  (v713_15).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v726_16 = Space::new();
  let mut v726_16_write = v726_16.write_zipper();
  let mut v726_16_cursor = (*s0).read_zipper();
  let v726_16_origin = v726_16_cursor.path().len();
  for v726_16_byte in v726_16_cursor.child_mask().iter() {
    v726_16_cursor.descend_to_existing_byte(v726_16_byte);
    {
    let v727_2: Space = singleton(&v726_16_cursor.path()[v726_16_origin..(v726_16_origin + 1)]);
    let v727_3: Space = intersect(&(*CONSTANT_2),&(v727_2));
    let v727_4: Space = if has_head(&(v727_3)) { singleton(&[]) } else { Space::new() };
    drop(v727_3);
    let v727_5: Space = subtract(&(*CONSTANT_1),&(v727_4));
    drop(v727_4);
    let v727_8: Space = if (&(v727_5)).is_empty() { Space::new() } else {
      let v728_6: Path = concat_path(&(*p0),&v726_16_cursor.path()[v726_16_origin..(v726_16_origin + 1)]);
      let mut v728_7 = Space::new();
      let mut v728_7_write = v728_7.write_zipper();
      for v728_7_byte in v726_16_cursor.child_mask().iter() {
        v726_16_cursor.descend_to_existing_byte(v728_7_byte);
        {
        let v729_2: Space = singleton(&v726_16_cursor.path()[(v726_16_origin + 1)..(v726_16_origin + 2)]);
        let v729_3: Space = intersect(&(*CONSTANT_2),&(v729_2));
        drop(v729_2);
        let v729_4: Space = if has_head(&(v729_3)) { singleton(&[]) } else { Space::new() };
        drop(v729_3);
        let v729_7: Space = if (&(v729_4)).is_empty() { Space::new() } else {
          let v730_5: Path = concat_path(&(v728_6),&v726_16_cursor.path()[(v726_16_origin + 1)..(v726_16_origin + 2)]);
          let mut v730_6 = Space::new();
          let mut v730_6_write = v730_6.write_zipper();
          for v730_6_byte in v726_16_cursor.child_mask().iter() {
            v726_16_cursor.descend_to_existing_byte(v730_6_byte);
            {
            let v731_2: Space = singleton(&v726_16_cursor.path()[(v726_16_origin + 2)..(v726_16_origin + 3)]);
            let v731_3: Space = intersect(&(*CONSTANT_2),&(v731_2));
            drop(v731_2);
            let v731_4: Space = if has_head(&(v731_3)) { singleton(&[]) } else { Space::new() };
            drop(v731_3);
            let v731_7: Space = if (&(v731_4)).is_empty() { Space::new() } else {
              let v732_5: Path = concat_path(&(v730_5),&v726_16_cursor.path()[(v726_16_origin + 2)..(v726_16_origin + 3)]);
              let v732_6: Space = routine_10(c, &(v732_5), &(*p1), &v726_16_cursor, &(*s1));
              drop(v732_5);
              compose(&(v731_4),&(v732_6))
            };
            drop(v731_4);
            join_wrapped_into(&mut v730_6_write,&((v731_7).read_zipper()),&[]);
            }
            v726_16_cursor.ascend(1);
          }
          drop(v730_6_write);
          drop(v730_5);
          compose(&(v729_4),&(v730_6))
        };
        drop(v729_4);
        join_wrapped_into(&mut v728_7_write,&((v729_7).read_zipper()),&[]);
        }
        v726_16_cursor.ascend(1);
      }
      drop(v728_7_write);
      drop(v728_6);
      compose(&(v727_5),&(v728_7))
    };
    drop(v727_5);
    let v727_9: Space = intersect(&(*CONSTANT_2),&(v727_2));
    drop(v727_2);
    let v727_10: Space = if has_head(&(v727_9)) { singleton(&[]) } else { Space::new() };
    drop(v727_9);
    let v727_13: Space = if (&(v727_10)).is_empty() { Space::new() } else {
      let mut v733_12 = Space::new();
      let mut v733_12_write = v733_12.write_zipper();
      for v733_12_byte in v726_16_cursor.child_mask().iter() {
        v726_16_cursor.descend_to_existing_byte(v733_12_byte);
        {
        let v734_2: Space = singleton(&v726_16_cursor.path()[(v726_16_origin + 1)..(v726_16_origin + 2)]);
        let v734_3: Space = intersect(&(*CONSTANT_2),&(v734_2));
        drop(v734_2);
        let v734_4: Space = if has_head(&(v734_3)) { singleton(&[]) } else { Space::new() };
        drop(v734_3);
        let v734_7: Space = if (&(v734_4)).is_empty() { Space::new() } else {
          let mut v735_6 = Space::new();
          let mut v735_6_write = v735_6.write_zipper();
          let mut v735_6_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v726_16_cursor.path()[v726_16_origin..(v726_16_origin + 1)]),&v726_16_cursor.path()[(v726_16_origin + 1)..(v726_16_origin + 2)]);
          let v735_6_origin = v735_6_cursor.path().len();
          for v735_6_byte in v735_6_cursor.child_mask().iter() {
            v735_6_cursor.descend_to_existing_byte(v735_6_byte);
            {
            let v736_2: Space = singleton(&v735_6_cursor.path()[v735_6_origin..(v735_6_origin + 1)]);
            let v736_3: Space = intersect(&(*CONSTANT_2),&(v736_2));
            let v736_4: Space = if has_head(&(v736_3)) { singleton(&[]) } else { Space::new() };
            drop(v736_3);
            let v736_5: Space = subtract(&(*CONSTANT_1),&(v736_4));
            drop(v736_4);
            let v736_7: Space = if (&(v736_5)).is_empty() { Space::new() } else {
              let v737_6: Space = routine_13(c, &v735_6_cursor.path()[v735_6_origin..(v735_6_origin + 1)], &(*p1), &v735_6_cursor);
              compose(&(v736_5),&(v737_6))
            };
            drop(v736_5);
            let v736_8: Space = intersect(&(*CONSTANT_2),&(v736_2));
            drop(v736_2);
            let v736_9: Space = if has_head(&(v736_8)) { singleton(&[]) } else { Space::new() };
            drop(v736_8);
            let v736_11: Space = if (&(v736_9)).is_empty() { Space::new() } else {
              let v738_10: Space = routine_14(c, &v735_6_cursor.path()[v735_6_origin..(v735_6_origin + 1)], &(*p1), &v735_6_cursor);
              compose(&(v736_9),&(v738_10))
            };
            drop(v736_9);
            let v736_12: Space = unite(&(v736_7),&(v736_11));
            join_wrapped_into(&mut v735_6_write,&((v736_12).read_zipper()),&[]);
            }
            v735_6_cursor.ascend(1);
          }
          drop(v735_6_cursor);
          drop(v735_6_write);
          compose(&(v734_4),&(v735_6))
        };
        drop(v734_4);
        join_wrapped_into(&mut v733_12_write,&((v734_7).read_zipper()),&[]);
        }
        v726_16_cursor.ascend(1);
      }
      drop(v733_12_write);
      compose(&(v727_10),&(v733_12))
    };
    drop(v727_10);
    let v727_14: Space = unite(&(v727_8),&(v727_13));
    join_wrapped_into(&mut v726_16_write,&((v727_14).read_zipper()),&[]);
    }
    v726_16_cursor.ascend(1);
  }
  drop(v726_16_cursor);
  drop(v726_16_write);
  (v726_16).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v739_21 = Space::new();
  let mut v739_21_write = v739_21.write_zipper();
  let mut v739_21_cursor = (*s0).read_zipper();
  let v739_21_origin = v739_21_cursor.path().len();
  for v739_21_byte in v739_21_cursor.child_mask().iter() {
    v739_21_cursor.descend_to_existing_byte(v739_21_byte);
    {
    let v740_2: Space = singleton(&v739_21_cursor.path()[v739_21_origin..(v739_21_origin + 1)]);
    let v740_3: Space = intersect(&(*CONSTANT_2),&(v740_2));
    let v740_4: Space = if has_head(&(v740_3)) { singleton(&[]) } else { Space::new() };
    drop(v740_3);
    let v740_5: Space = subtract(&(*CONSTANT_1),&(v740_4));
    drop(v740_4);
    let v740_8: Space = if (&(v740_5)).is_empty() { Space::new() } else {
      let v741_6: Path = concat_path(&(*p0),&v739_21_cursor.path()[v739_21_origin..(v739_21_origin + 1)]);
      let mut v741_7 = Space::new();
      let mut v741_7_write = v741_7.write_zipper();
      for v741_7_byte in v739_21_cursor.child_mask().iter() {
        v739_21_cursor.descend_to_existing_byte(v741_7_byte);
        {
        let v742_2: Space = singleton(&v739_21_cursor.path()[(v739_21_origin + 1)..(v739_21_origin + 2)]);
        let v742_3: Space = intersect(&(*CONSTANT_2),&(v742_2));
        drop(v742_2);
        let v742_4: Space = if has_head(&(v742_3)) { singleton(&[]) } else { Space::new() };
        drop(v742_3);
        let v742_7: Space = if (&(v742_4)).is_empty() { Space::new() } else {
          let v743_5: Path = concat_path(&(v741_6),&v739_21_cursor.path()[(v739_21_origin + 1)..(v739_21_origin + 2)]);
          let mut v743_6 = Space::new();
          let mut v743_6_write = v743_6.write_zipper();
          for v743_6_byte in v739_21_cursor.child_mask().iter() {
            v739_21_cursor.descend_to_existing_byte(v743_6_byte);
            {
            let v744_2: Space = singleton(&v739_21_cursor.path()[(v739_21_origin + 2)..(v739_21_origin + 3)]);
            let v744_3: Space = intersect(&(*CONSTANT_2),&(v744_2));
            drop(v744_2);
            let v744_4: Space = if has_head(&(v744_3)) { singleton(&[]) } else { Space::new() };
            drop(v744_3);
            let v744_7: Space = if (&(v744_4)).is_empty() { Space::new() } else {
              let v745_5: Path = concat_path(&(v743_5),&v739_21_cursor.path()[(v739_21_origin + 2)..(v739_21_origin + 3)]);
              let v745_6: Space = routine_10(c, &(v745_5), &(*p1), &v739_21_cursor, &(*s1));
              drop(v745_5);
              compose(&(v744_4),&(v745_6))
            };
            drop(v744_4);
            join_wrapped_into(&mut v743_6_write,&((v744_7).read_zipper()),&[]);
            }
            v739_21_cursor.ascend(1);
          }
          drop(v743_6_write);
          drop(v743_5);
          compose(&(v742_4),&(v743_6))
        };
        drop(v742_4);
        join_wrapped_into(&mut v741_7_write,&((v742_7).read_zipper()),&[]);
        }
        v739_21_cursor.ascend(1);
      }
      drop(v741_7_write);
      drop(v741_6);
      compose(&(v740_5),&(v741_7))
    };
    drop(v740_5);
    let v740_9: Space = intersect(&(*CONSTANT_2),&(v740_2));
    drop(v740_2);
    let v740_10: Space = if has_head(&(v740_9)) { singleton(&[]) } else { Space::new() };
    drop(v740_9);
    let v740_13: Space = if (&(v740_10)).is_empty() { Space::new() } else {
      let mut v746_12 = Space::new();
      let mut v746_12_write = v746_12.write_zipper();
      let mut v746_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v739_21_cursor.path()[v739_21_origin..(v739_21_origin + 1)]);
      let v746_12_origin = v746_12_cursor.path().len();
      for v746_12_byte in v746_12_cursor.child_mask().iter() {
        v746_12_cursor.descend_to_existing_byte(v746_12_byte);
        {
        let v747_2: Space = singleton(&v746_12_cursor.path()[v746_12_origin..(v746_12_origin + 1)]);
        let v747_3: Space = intersect(&(*CONSTANT_2),&(v747_2));
        let v747_4: Space = if has_head(&(v747_3)) { singleton(&[]) } else { Space::new() };
        drop(v747_3);
        let v747_5: Space = subtract(&(*CONSTANT_1),&(v747_4));
        drop(v747_4);
        let v747_7: Space = if (&(v747_5)).is_empty() { Space::new() } else {
          let mut v748_6 = Space::new();
          let mut v748_6_write = v748_6.write_zipper();
          for v748_6_byte in v746_12_cursor.child_mask().iter() {
            v746_12_cursor.descend_to_existing_byte(v748_6_byte);
            {
            let v749_2: Space = singleton(&v746_12_cursor.path()[(v746_12_origin + 1)..(v746_12_origin + 2)]);
            let v749_3: Space = intersect(&(*CONSTANT_2),&(v749_2));
            let v749_4: Space = if has_head(&(v749_3)) { singleton(&[]) } else { Space::new() };
            drop(v749_3);
            let v749_5: Space = subtract(&(*CONSTANT_1),&(v749_4));
            drop(v749_4);
            let v749_8: Space = if (&(v749_5)).is_empty() { Space::new() } else {
              let v750_7: Space = routine_17(c, &v746_12_cursor.path()[v746_12_origin..(v746_12_origin + 2)], &(*p1), &v746_12_cursor);
              compose(&(v749_5),&(v750_7))
            };
            drop(v749_5);
            let v749_9: Space = intersect(&(*CONSTANT_2),&(v749_2));
            drop(v749_2);
            let v749_10: Space = if has_head(&(v749_9)) { singleton(&[]) } else { Space::new() };
            drop(v749_9);
            let v749_12: Space = if (&(v749_10)).is_empty() { Space::new() } else {
              let v751_11: Space = routine_18(c, &v746_12_cursor.path()[v746_12_origin..(v746_12_origin + 2)], &(*p1), &v746_12_cursor);
              compose(&(v749_10),&(v751_11))
            };
            drop(v749_10);
            let v749_13: Space = unite(&(v749_8),&(v749_12));
            join_wrapped_into(&mut v748_6_write,&((v749_13).read_zipper()),&[]);
            }
            v746_12_cursor.ascend(1);
          }
          drop(v748_6_write);
          compose(&(v747_5),&(v748_6))
        };
        drop(v747_5);
        let v747_8: Space = intersect(&(*CONSTANT_2),&(v747_2));
        drop(v747_2);
        let v747_9: Space = if has_head(&(v747_8)) { singleton(&[]) } else { Space::new() };
        drop(v747_8);
        let v747_11: Space = if (&(v747_9)).is_empty() { Space::new() } else {
          let mut v752_10 = Space::new();
          let mut v752_10_write = v752_10.write_zipper();
          for v752_10_byte in v746_12_cursor.child_mask().iter() {
            v746_12_cursor.descend_to_existing_byte(v752_10_byte);
            {
            let v753_2: Space = singleton(&v746_12_cursor.path()[(v746_12_origin + 1)..(v746_12_origin + 2)]);
            let v753_3: Space = intersect(&(*CONSTANT_2),&(v753_2));
            let v753_4: Space = if has_head(&(v753_3)) { singleton(&[]) } else { Space::new() };
            drop(v753_3);
            let v753_5: Space = subtract(&(*CONSTANT_1),&(v753_4));
            drop(v753_4);
            let v753_8: Space = if (&(v753_5)).is_empty() { Space::new() } else {
              let v754_7: Space = routine_17(c, &v746_12_cursor.path()[v746_12_origin..(v746_12_origin + 2)], &(*p1), &v746_12_cursor);
              compose(&(v753_5),&(v754_7))
            };
            drop(v753_5);
            let v753_9: Space = intersect(&(*CONSTANT_2),&(v753_2));
            drop(v753_2);
            let v753_10: Space = if has_head(&(v753_9)) { singleton(&[]) } else { Space::new() };
            drop(v753_9);
            let v753_12: Space = if (&(v753_10)).is_empty() { Space::new() } else {
              let v755_11: Space = routine_19(c, &v746_12_cursor.path()[v746_12_origin..(v746_12_origin + 2)], &(*p1), &v746_12_cursor);
              compose(&(v753_10),&(v755_11))
            };
            drop(v753_10);
            let v753_13: Space = unite(&(v753_8),&(v753_12));
            join_wrapped_into(&mut v752_10_write,&((v753_13).read_zipper()),&[]);
            }
            v746_12_cursor.ascend(1);
          }
          drop(v752_10_write);
          compose(&(v747_9),&(v752_10))
        };
        drop(v747_9);
        let v747_12: Space = unite(&(v747_7),&(v747_11));
        join_wrapped_into(&mut v746_12_write,&((v747_12).read_zipper()),&[]);
        }
        v746_12_cursor.ascend(1);
      }
      drop(v746_12_cursor);
      drop(v746_12_write);
      compose(&(v740_10),&(v746_12))
    };
    drop(v740_10);
    let v740_14: Space = unite(&(v740_8),&(v740_13));
    join_wrapped_into(&mut v739_21_write,&((v740_14).read_zipper()),&[]);
    }
    v739_21_cursor.ascend(1);
  }
  drop(v739_21_cursor);
  drop(v739_21_write);
  (v739_21).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v756_21 = Space::new();
  let mut v756_21_write = v756_21.write_zipper();
  let mut v756_21_cursor = (*s0).read_zipper();
  let v756_21_origin = v756_21_cursor.path().len();
  for v756_21_byte in v756_21_cursor.child_mask().iter() {
    v756_21_cursor.descend_to_existing_byte(v756_21_byte);
    {
    let v757_2: Space = singleton(&v756_21_cursor.path()[v756_21_origin..(v756_21_origin + 1)]);
    let v757_3: Space = intersect(&(*CONSTANT_2),&(v757_2));
    let v757_4: Space = if has_head(&(v757_3)) { singleton(&[]) } else { Space::new() };
    drop(v757_3);
    let v757_5: Space = subtract(&(*CONSTANT_1),&(v757_4));
    drop(v757_4);
    let v757_8: Space = if (&(v757_5)).is_empty() { Space::new() } else {
      let v758_6: Path = concat_path(&(*p0),&v756_21_cursor.path()[v756_21_origin..(v756_21_origin + 1)]);
      let mut v758_7 = Space::new();
      let mut v758_7_write = v758_7.write_zipper();
      for v758_7_byte in v756_21_cursor.child_mask().iter() {
        v756_21_cursor.descend_to_existing_byte(v758_7_byte);
        {
        let v759_2: Space = singleton(&v756_21_cursor.path()[(v756_21_origin + 1)..(v756_21_origin + 2)]);
        let v759_3: Space = intersect(&(*CONSTANT_2),&(v759_2));
        let v759_4: Space = if has_head(&(v759_3)) { singleton(&[]) } else { Space::new() };
        drop(v759_3);
        let v759_5: Space = subtract(&(*CONSTANT_1),&(v759_4));
        drop(v759_4);
        let v759_8: Space = if (&(v759_5)).is_empty() { Space::new() } else {
          let v760_6: Path = concat_path(&(v758_6),&v756_21_cursor.path()[(v756_21_origin + 1)..(v756_21_origin + 2)]);
          let mut v760_7 = Space::new();
          let mut v760_7_write = v760_7.write_zipper();
          for v760_7_byte in v756_21_cursor.child_mask().iter() {
            v756_21_cursor.descend_to_existing_byte(v760_7_byte);
            {
            let v761_2: Space = singleton(&v756_21_cursor.path()[(v756_21_origin + 2)..(v756_21_origin + 3)]);
            let v761_3: Space = intersect(&(*CONSTANT_2),&(v761_2));
            let v761_4: Space = if has_head(&(v761_3)) { singleton(&[]) } else { Space::new() };
            drop(v761_3);
            let v761_5: Space = subtract(&(*CONSTANT_1),&(v761_4));
            drop(v761_4);
            let v761_8: Space = if (&(v761_5)).is_empty() { Space::new() } else {
              let v762_6: Path = concat_path(&(v760_6),&v756_21_cursor.path()[(v756_21_origin + 2)..(v756_21_origin + 3)]);
              let v762_7: Space = routine_50(c, &(v762_6), &(*p1), &v756_21_cursor);
              compose(&(v761_5),&(v762_7))
            };
            drop(v761_5);
            let v761_9: Space = intersect(&(*CONSTANT_2),&(v761_2));
            drop(v761_2);
            let v761_10: Space = if has_head(&(v761_9)) { singleton(&[]) } else { Space::new() };
            drop(v761_9);
            let v761_12: Space = if (&(v761_10)).is_empty() { Space::new() } else {
              let v763_6: Path = concat_path(&(v760_6),&v756_21_cursor.path()[(v756_21_origin + 2)..(v756_21_origin + 3)]);
              let v763_11: Space = routine_51(c, &(v763_6), &(*p1), &v756_21_cursor);
              drop(v763_6);
              compose(&(v761_10),&(v763_11))
            };
            drop(v761_10);
            let v761_13: Space = unite(&(v761_8),&(v761_12));
            join_wrapped_into(&mut v760_7_write,&((v761_13).read_zipper()),&[]);
            }
            v756_21_cursor.ascend(1);
          }
          drop(v760_7_write);
          compose(&(v759_5),&(v760_7))
        };
        drop(v759_5);
        let v759_9: Space = intersect(&(*CONSTANT_2),&(v759_2));
        drop(v759_2);
        let v759_10: Space = if has_head(&(v759_9)) { singleton(&[]) } else { Space::new() };
        drop(v759_9);
        let v759_12: Space = if (&(v759_10)).is_empty() { Space::new() } else {
          let v764_6: Path = concat_path(&(v758_6),&v756_21_cursor.path()[(v756_21_origin + 1)..(v756_21_origin + 2)]);
          let mut v764_11 = Space::new();
          let mut v764_11_write = v764_11.write_zipper();
          for v764_11_byte in v756_21_cursor.child_mask().iter() {
            v756_21_cursor.descend_to_existing_byte(v764_11_byte);
            {
            let v765_2: Space = singleton(&v756_21_cursor.path()[(v756_21_origin + 2)..(v756_21_origin + 3)]);
            let v765_3: Space = intersect(&(*CONSTANT_2),&(v765_2));
            let v765_4: Space = if has_head(&(v765_3)) { singleton(&[]) } else { Space::new() };
            drop(v765_3);
            let v765_5: Space = subtract(&(*CONSTANT_1),&(v765_4));
            drop(v765_4);
            let v765_8: Space = if (&(v765_5)).is_empty() { Space::new() } else {
              let v766_6: Path = concat_path(&(v764_6),&v756_21_cursor.path()[(v756_21_origin + 2)..(v756_21_origin + 3)]);
              let v766_7: Space = routine_50(c, &(v766_6), &(*p1), &v756_21_cursor);
              compose(&(v765_5),&(v766_7))
            };
            drop(v765_5);
            let v765_9: Space = intersect(&(*CONSTANT_2),&(v765_2));
            drop(v765_2);
            let v765_10: Space = if has_head(&(v765_9)) { singleton(&[]) } else { Space::new() };
            drop(v765_9);
            let v765_12: Space = if (&(v765_10)).is_empty() { Space::new() } else {
              let v767_6: Path = concat_path(&(v764_6),&v756_21_cursor.path()[(v756_21_origin + 2)..(v756_21_origin + 3)]);
              let v767_11: Space = routine_19(c, &(v767_6), &(*p1), &v756_21_cursor);
              drop(v767_6);
              compose(&(v765_10),&(v767_11))
            };
            drop(v765_10);
            let v765_13: Space = unite(&(v765_8),&(v765_12));
            join_wrapped_into(&mut v764_11_write,&((v765_13).read_zipper()),&[]);
            }
            v756_21_cursor.ascend(1);
          }
          drop(v764_11_write);
          drop(v764_6);
          compose(&(v759_10),&(v764_11))
        };
        drop(v759_10);
        let v759_13: Space = unite(&(v759_8),&(v759_12));
        join_wrapped_into(&mut v758_7_write,&((v759_13).read_zipper()),&[]);
        }
        v756_21_cursor.ascend(1);
      }
      drop(v758_7_write);
      compose(&(v757_5),&(v758_7))
    };
    drop(v757_5);
    let v757_9: Space = intersect(&(*CONSTANT_2),&(v757_2));
    drop(v757_2);
    let v757_10: Space = if has_head(&(v757_9)) { singleton(&[]) } else { Space::new() };
    drop(v757_9);
    let v757_12: Space = if (&(v757_10)).is_empty() { Space::new() } else {
      let v768_6: Path = concat_path(&(*p0),&v756_21_cursor.path()[v756_21_origin..(v756_21_origin + 1)]);
      let mut v768_11 = Space::new();
      let mut v768_11_write = v768_11.write_zipper();
      for v768_11_byte in v756_21_cursor.child_mask().iter() {
        v756_21_cursor.descend_to_existing_byte(v768_11_byte);
        {
        let v769_2: Space = singleton(&v756_21_cursor.path()[(v756_21_origin + 1)..(v756_21_origin + 2)]);
        let v769_3: Space = intersect(&(*CONSTANT_2),&(v769_2));
        let v769_4: Space = if has_head(&(v769_3)) { singleton(&[]) } else { Space::new() };
        drop(v769_3);
        let v769_5: Space = subtract(&(*CONSTANT_1),&(v769_4));
        drop(v769_4);
        let v769_8: Space = if (&(v769_5)).is_empty() { Space::new() } else {
          let v770_6: Path = concat_path(&(v768_6),&v756_21_cursor.path()[(v756_21_origin + 1)..(v756_21_origin + 2)]);
          let mut v770_7 = Space::new();
          let mut v770_7_write = v770_7.write_zipper();
          for v770_7_byte in v756_21_cursor.child_mask().iter() {
            v756_21_cursor.descend_to_existing_byte(v770_7_byte);
            {
            let v771_2: Space = singleton(&v756_21_cursor.path()[(v756_21_origin + 2)..(v756_21_origin + 3)]);
            let v771_3: Space = intersect(&(*CONSTANT_2),&(v771_2));
            let v771_4: Space = if has_head(&(v771_3)) { singleton(&[]) } else { Space::new() };
            drop(v771_3);
            let v771_5: Space = subtract(&(*CONSTANT_1),&(v771_4));
            drop(v771_4);
            let v771_8: Space = if (&(v771_5)).is_empty() { Space::new() } else {
              let v772_6: Path = concat_path(&(v770_6),&v756_21_cursor.path()[(v756_21_origin + 2)..(v756_21_origin + 3)]);
              let v772_7: Space = routine_50(c, &(v772_6), &(*p1), &v756_21_cursor);
              compose(&(v771_5),&(v772_7))
            };
            drop(v771_5);
            let v771_9: Space = intersect(&(*CONSTANT_2),&(v771_2));
            drop(v771_2);
            let v771_10: Space = if has_head(&(v771_9)) { singleton(&[]) } else { Space::new() };
            drop(v771_9);
            let v771_12: Space = if (&(v771_10)).is_empty() { Space::new() } else {
              let v773_6: Path = concat_path(&(v770_6),&v756_21_cursor.path()[(v756_21_origin + 2)..(v756_21_origin + 3)]);
              let v773_11: Space = routine_51(c, &(v773_6), &(*p1), &v756_21_cursor);
              drop(v773_6);
              compose(&(v771_10),&(v773_11))
            };
            drop(v771_10);
            let v771_13: Space = unite(&(v771_8),&(v771_12));
            join_wrapped_into(&mut v770_7_write,&((v771_13).read_zipper()),&[]);
            }
            v756_21_cursor.ascend(1);
          }
          drop(v770_7_write);
          compose(&(v769_5),&(v770_7))
        };
        drop(v769_5);
        let v769_9: Space = intersect(&(*CONSTANT_2),&(v769_2));
        drop(v769_2);
        let v769_10: Space = if has_head(&(v769_9)) { singleton(&[]) } else { Space::new() };
        drop(v769_9);
        let v769_11: Space = compose(&(v769_10),&v756_21_cursor);
        drop(v769_10);
        let v774_6: Path = concat_path(&(v768_6),&v756_21_cursor.path()[(v756_21_origin + 1)..(v756_21_origin + 2)]);
        let v769_12: Space = wrap(&(v769_11),&(v774_6));
        drop(v769_11);
        let v769_13: Space = wrap(&(v769_12),&(*p1));
        drop(v769_12);
        let v769_14: Space = unite(&(v769_8),&(v769_13));
        drop(v769_13);
        join_wrapped_into(&mut v768_11_write,&((v769_14).read_zipper()),&[]);
        }
        v756_21_cursor.ascend(1);
      }
      drop(v768_11_write);
      drop(v768_6);
      compose(&(v757_10),&(v768_11))
    };
    drop(v757_10);
    let v757_13: Space = unite(&(v757_8),&(v757_12));
    join_wrapped_into(&mut v756_21_write,&((v757_13).read_zipper()),&[]);
    }
    v756_21_cursor.ascend(1);
  }
  drop(v756_21_cursor);
  drop(v756_21_write);
  (v756_21).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v775_15 = Space::new();
  let mut v775_15_write = v775_15.write_zipper();
  let mut v775_15_cursor = (*s0).read_zipper();
  let v775_15_origin = v775_15_cursor.path().len();
  for v775_15_byte in v775_15_cursor.child_mask().iter() {
    v775_15_cursor.descend_to_existing_byte(v775_15_byte);
    {
    let v776_2: Space = singleton(&v775_15_cursor.path()[v775_15_origin..(v775_15_origin + 1)]);
    let v776_3: Space = intersect(&(*CONSTANT_2),&(v776_2));
    let v776_4: Space = if has_head(&(v776_3)) { singleton(&[]) } else { Space::new() };
    drop(v776_3);
    let v776_5: Space = subtract(&(*CONSTANT_1),&(v776_4));
    drop(v776_4);
    let v776_8: Space = if (&(v776_5)).is_empty() { Space::new() } else {
      let v777_6: Path = concat_path(&(*p0),&v775_15_cursor.path()[v775_15_origin..(v775_15_origin + 1)]);
      let mut v777_7 = Space::new();
      let mut v777_7_write = v777_7.write_zipper();
      for v777_7_byte in v775_15_cursor.child_mask().iter() {
        v775_15_cursor.descend_to_existing_byte(v777_7_byte);
        {
        let v778_2: Space = singleton(&v775_15_cursor.path()[(v775_15_origin + 1)..(v775_15_origin + 2)]);
        let v778_3: Space = intersect(&(*CONSTANT_2),&(v778_2));
        let v778_4: Space = if has_head(&(v778_3)) { singleton(&[]) } else { Space::new() };
        drop(v778_3);
        let v778_5: Space = subtract(&(*CONSTANT_1),&(v778_4));
        drop(v778_4);
        let v778_8: Space = if (&(v778_5)).is_empty() { Space::new() } else {
          let v779_6: Path = concat_path(&(v777_6),&v775_15_cursor.path()[(v775_15_origin + 1)..(v775_15_origin + 2)]);
          let mut v779_7 = Space::new();
          let mut v779_7_write = v779_7.write_zipper();
          for v779_7_byte in v775_15_cursor.child_mask().iter() {
            v775_15_cursor.descend_to_existing_byte(v779_7_byte);
            {
            let v780_2: Space = singleton(&v775_15_cursor.path()[(v775_15_origin + 2)..(v775_15_origin + 3)]);
            let v780_3: Space = intersect(&(*CONSTANT_2),&(v780_2));
            let v780_4: Space = if has_head(&(v780_3)) { singleton(&[]) } else { Space::new() };
            drop(v780_3);
            let v780_5: Space = subtract(&(*CONSTANT_1),&(v780_4));
            drop(v780_4);
            let v780_8: Space = if (&(v780_5)).is_empty() { Space::new() } else {
              let v781_6: Path = concat_path(&(v779_6),&v775_15_cursor.path()[(v775_15_origin + 2)..(v775_15_origin + 3)]);
              let v781_7: Space = routine_50(c, &(v781_6), &(*p1), &v775_15_cursor);
              compose(&(v780_5),&(v781_7))
            };
            drop(v780_5);
            let v780_9: Space = intersect(&(*CONSTANT_2),&(v780_2));
            drop(v780_2);
            let v780_10: Space = if has_head(&(v780_9)) { singleton(&[]) } else { Space::new() };
            drop(v780_9);
            let v780_12: Space = if (&(v780_10)).is_empty() { Space::new() } else {
              let v782_6: Path = concat_path(&(v779_6),&v775_15_cursor.path()[(v775_15_origin + 2)..(v775_15_origin + 3)]);
              let v782_11: Space = routine_51(c, &(v782_6), &(*p1), &v775_15_cursor);
              drop(v782_6);
              compose(&(v780_10),&(v782_11))
            };
            drop(v780_10);
            let v780_13: Space = unite(&(v780_8),&(v780_12));
            join_wrapped_into(&mut v779_7_write,&((v780_13).read_zipper()),&[]);
            }
            v775_15_cursor.ascend(1);
          }
          drop(v779_7_write);
          compose(&(v778_5),&(v779_7))
        };
        drop(v778_5);
        let v778_9: Space = intersect(&(*CONSTANT_2),&(v778_2));
        drop(v778_2);
        let v778_10: Space = if has_head(&(v778_9)) { singleton(&[]) } else { Space::new() };
        drop(v778_9);
        let v778_12: Space = if (&(v778_10)).is_empty() { Space::new() } else {
          let v783_6: Path = concat_path(&(v777_6),&v775_15_cursor.path()[(v775_15_origin + 1)..(v775_15_origin + 2)]);
          let mut v783_11 = Space::new();
          let mut v783_11_write = v783_11.write_zipper();
          for v783_11_byte in v775_15_cursor.child_mask().iter() {
            v775_15_cursor.descend_to_existing_byte(v783_11_byte);
            {
            let v784_2: Space = singleton(&v775_15_cursor.path()[(v775_15_origin + 2)..(v775_15_origin + 3)]);
            let v784_3: Space = intersect(&(*CONSTANT_2),&(v784_2));
            let v784_4: Space = if has_head(&(v784_3)) { singleton(&[]) } else { Space::new() };
            drop(v784_3);
            let v784_5: Space = subtract(&(*CONSTANT_1),&(v784_4));
            drop(v784_4);
            let v784_8: Space = if (&(v784_5)).is_empty() { Space::new() } else {
              let v785_6: Path = concat_path(&(v783_6),&v775_15_cursor.path()[(v775_15_origin + 2)..(v775_15_origin + 3)]);
              let v785_7: Space = routine_50(c, &(v785_6), &(*p1), &v775_15_cursor);
              compose(&(v784_5),&(v785_7))
            };
            drop(v784_5);
            let v784_9: Space = intersect(&(*CONSTANT_2),&(v784_2));
            drop(v784_2);
            let v784_10: Space = if has_head(&(v784_9)) { singleton(&[]) } else { Space::new() };
            drop(v784_9);
            let v784_12: Space = if (&(v784_10)).is_empty() { Space::new() } else {
              let v786_6: Path = concat_path(&(v783_6),&v775_15_cursor.path()[(v775_15_origin + 2)..(v775_15_origin + 3)]);
              let v786_11: Space = routine_19(c, &(v786_6), &(*p1), &v775_15_cursor);
              drop(v786_6);
              compose(&(v784_10),&(v786_11))
            };
            drop(v784_10);
            let v784_13: Space = unite(&(v784_8),&(v784_12));
            join_wrapped_into(&mut v783_11_write,&((v784_13).read_zipper()),&[]);
            }
            v775_15_cursor.ascend(1);
          }
          drop(v783_11_write);
          drop(v783_6);
          compose(&(v778_10),&(v783_11))
        };
        drop(v778_10);
        let v778_13: Space = unite(&(v778_8),&(v778_12));
        join_wrapped_into(&mut v777_7_write,&((v778_13).read_zipper()),&[]);
        }
        v775_15_cursor.ascend(1);
      }
      drop(v777_7_write);
      compose(&(v776_5),&(v777_7))
    };
    drop(v776_5);
    let v776_9: Space = intersect(&(*CONSTANT_2),&(v776_2));
    drop(v776_2);
    let v776_10: Space = if has_head(&(v776_9)) { singleton(&[]) } else { Space::new() };
    drop(v776_9);
    let v776_11: Space = compose(&(v776_10),&v775_15_cursor);
    drop(v776_10);
    let v787_6: Path = concat_path(&(*p0),&v775_15_cursor.path()[v775_15_origin..(v775_15_origin + 1)]);
    let v776_12: Space = wrap(&(v776_11),&(v787_6));
    drop(v776_11);
    let v776_13: Space = wrap(&(v776_12),&(*p1));
    drop(v776_12);
    let v776_14: Space = unite(&(v776_8),&(v776_13));
    drop(v776_13);
    join_wrapped_into(&mut v775_15_write,&((v776_14).read_zipper()),&[]);
    }
    v775_15_cursor.ascend(1);
  }
  drop(v775_15_cursor);
  drop(v775_15_write);
  (v775_15).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v788_12 = Space::new();
  let mut v788_12_write = v788_12.write_zipper();
  let mut v788_12_cursor = (*s0).read_zipper();
  let v788_12_origin = v788_12_cursor.path().len();
  for v788_12_byte in v788_12_cursor.child_mask().iter() {
    v788_12_cursor.descend_to_existing_byte(v788_12_byte);
    {
    let v789_2: Space = singleton(&v788_12_cursor.path()[v788_12_origin..(v788_12_origin + 1)]);
    let v789_3: Space = intersect(&(*CONSTANT_2),&(v789_2));
    drop(v789_2);
    let v789_4: Space = if has_head(&(v789_3)) { singleton(&[]) } else { Space::new() };
    drop(v789_3);
    let v789_7: Space = if (&(v789_4)).is_empty() { Space::new() } else {
      let mut v790_6 = Space::new();
      let mut v790_6_write = v790_6.write_zipper();
      for v790_6_byte in v788_12_cursor.child_mask().iter() {
        v788_12_cursor.descend_to_existing_byte(v790_6_byte);
        {
        let v791_2: Space = singleton(&v788_12_cursor.path()[(v788_12_origin + 1)..(v788_12_origin + 2)]);
        let v791_3: Space = intersect(&(*CONSTANT_2),&(v791_2));
        drop(v791_2);
        let v791_4: Space = if has_head(&(v791_3)) { singleton(&[]) } else { Space::new() };
        drop(v791_3);
        let v791_7: Space = if (&(v791_4)).is_empty() { Space::new() } else {
          let mut v792_6 = Space::new();
          let mut v792_6_write = v792_6.write_zipper();
          let mut v792_6_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v788_12_cursor.path()[v788_12_origin..(v788_12_origin + 1)]),&v788_12_cursor.path()[(v788_12_origin + 1)..(v788_12_origin + 2)]);
          let v792_6_origin = v792_6_cursor.path().len();
          for v792_6_byte in v792_6_cursor.child_mask().iter() {
            v792_6_cursor.descend_to_existing_byte(v792_6_byte);
            {
            let v793_2: Space = singleton(&v792_6_cursor.path()[v792_6_origin..(v792_6_origin + 1)]);
            let v793_3: Space = intersect(&(*CONSTANT_2),&(v793_2));
            let v793_4: Space = if has_head(&(v793_3)) { singleton(&[]) } else { Space::new() };
            drop(v793_3);
            let v793_5: Space = subtract(&(*CONSTANT_1),&(v793_4));
            drop(v793_4);
            let v793_7: Space = if (&(v793_5)).is_empty() { Space::new() } else {
              let v794_6: Space = routine_13(c, &v792_6_cursor.path()[v792_6_origin..(v792_6_origin + 1)], &(*p1), &v792_6_cursor);
              compose(&(v793_5),&(v794_6))
            };
            drop(v793_5);
            let v793_8: Space = intersect(&(*CONSTANT_2),&(v793_2));
            drop(v793_2);
            let v793_9: Space = if has_head(&(v793_8)) { singleton(&[]) } else { Space::new() };
            drop(v793_8);
            let v793_11: Space = if (&(v793_9)).is_empty() { Space::new() } else {
              let v795_10: Space = routine_14(c, &v792_6_cursor.path()[v792_6_origin..(v792_6_origin + 1)], &(*p1), &v792_6_cursor);
              compose(&(v793_9),&(v795_10))
            };
            drop(v793_9);
            let v793_12: Space = unite(&(v793_7),&(v793_11));
            join_wrapped_into(&mut v792_6_write,&((v793_12).read_zipper()),&[]);
            }
            v792_6_cursor.ascend(1);
          }
          drop(v792_6_cursor);
          drop(v792_6_write);
          compose(&(v791_4),&(v792_6))
        };
        drop(v791_4);
        join_wrapped_into(&mut v790_6_write,&((v791_7).read_zipper()),&[]);
        }
        v788_12_cursor.ascend(1);
      }
      drop(v790_6_write);
      compose(&(v789_4),&(v790_6))
    };
    drop(v789_4);
    join_wrapped_into(&mut v788_12_write,&((v789_7).read_zipper()),&[]);
    }
    v788_12_cursor.ascend(1);
  }
  drop(v788_12_cursor);
  drop(v788_12_write);
  (v788_12).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v796_17 = Space::new();
  let mut v796_17_write = v796_17.write_zipper();
  let mut v796_17_cursor = (*s0).read_zipper();
  let v796_17_origin = v796_17_cursor.path().len();
  for v796_17_byte in v796_17_cursor.child_mask().iter() {
    v796_17_cursor.descend_to_existing_byte(v796_17_byte);
    {
    let v797_2: Space = singleton(&v796_17_cursor.path()[v796_17_origin..(v796_17_origin + 1)]);
    let v797_3: Space = intersect(&(*CONSTANT_2),&(v797_2));
    drop(v797_2);
    let v797_4: Space = if has_head(&(v797_3)) { singleton(&[]) } else { Space::new() };
    drop(v797_3);
    let v797_7: Space = if (&(v797_4)).is_empty() { Space::new() } else {
      let mut v798_6 = Space::new();
      let mut v798_6_write = v798_6.write_zipper();
      let mut v798_6_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v796_17_cursor.path()[v796_17_origin..(v796_17_origin + 1)]);
      let v798_6_origin = v798_6_cursor.path().len();
      for v798_6_byte in v798_6_cursor.child_mask().iter() {
        v798_6_cursor.descend_to_existing_byte(v798_6_byte);
        {
        let v799_2: Space = singleton(&v798_6_cursor.path()[v798_6_origin..(v798_6_origin + 1)]);
        let v799_3: Space = intersect(&(*CONSTANT_2),&(v799_2));
        let v799_4: Space = if has_head(&(v799_3)) { singleton(&[]) } else { Space::new() };
        drop(v799_3);
        let v799_5: Space = subtract(&(*CONSTANT_1),&(v799_4));
        drop(v799_4);
        let v799_7: Space = if (&(v799_5)).is_empty() { Space::new() } else {
          let mut v800_6 = Space::new();
          let mut v800_6_write = v800_6.write_zipper();
          for v800_6_byte in v798_6_cursor.child_mask().iter() {
            v798_6_cursor.descend_to_existing_byte(v800_6_byte);
            {
            let v801_2: Space = singleton(&v798_6_cursor.path()[(v798_6_origin + 1)..(v798_6_origin + 2)]);
            let v801_3: Space = intersect(&(*CONSTANT_2),&(v801_2));
            let v801_4: Space = if has_head(&(v801_3)) { singleton(&[]) } else { Space::new() };
            drop(v801_3);
            let v801_5: Space = subtract(&(*CONSTANT_1),&(v801_4));
            drop(v801_4);
            let v801_8: Space = if (&(v801_5)).is_empty() { Space::new() } else {
              let v802_7: Space = routine_17(c, &v798_6_cursor.path()[v798_6_origin..(v798_6_origin + 2)], &(*p1), &v798_6_cursor);
              compose(&(v801_5),&(v802_7))
            };
            drop(v801_5);
            let v801_9: Space = intersect(&(*CONSTANT_2),&(v801_2));
            drop(v801_2);
            let v801_10: Space = if has_head(&(v801_9)) { singleton(&[]) } else { Space::new() };
            drop(v801_9);
            let v801_12: Space = if (&(v801_10)).is_empty() { Space::new() } else {
              let v803_11: Space = routine_18(c, &v798_6_cursor.path()[v798_6_origin..(v798_6_origin + 2)], &(*p1), &v798_6_cursor);
              compose(&(v801_10),&(v803_11))
            };
            drop(v801_10);
            let v801_13: Space = unite(&(v801_8),&(v801_12));
            join_wrapped_into(&mut v800_6_write,&((v801_13).read_zipper()),&[]);
            }
            v798_6_cursor.ascend(1);
          }
          drop(v800_6_write);
          compose(&(v799_5),&(v800_6))
        };
        drop(v799_5);
        let v799_8: Space = intersect(&(*CONSTANT_2),&(v799_2));
        drop(v799_2);
        let v799_9: Space = if has_head(&(v799_8)) { singleton(&[]) } else { Space::new() };
        drop(v799_8);
        let v799_11: Space = if (&(v799_9)).is_empty() { Space::new() } else {
          let mut v804_10 = Space::new();
          let mut v804_10_write = v804_10.write_zipper();
          for v804_10_byte in v798_6_cursor.child_mask().iter() {
            v798_6_cursor.descend_to_existing_byte(v804_10_byte);
            {
            let v805_2: Space = singleton(&v798_6_cursor.path()[(v798_6_origin + 1)..(v798_6_origin + 2)]);
            let v805_3: Space = intersect(&(*CONSTANT_2),&(v805_2));
            let v805_4: Space = if has_head(&(v805_3)) { singleton(&[]) } else { Space::new() };
            drop(v805_3);
            let v805_5: Space = subtract(&(*CONSTANT_1),&(v805_4));
            drop(v805_4);
            let v805_8: Space = if (&(v805_5)).is_empty() { Space::new() } else {
              let v806_7: Space = routine_17(c, &v798_6_cursor.path()[v798_6_origin..(v798_6_origin + 2)], &(*p1), &v798_6_cursor);
              compose(&(v805_5),&(v806_7))
            };
            drop(v805_5);
            let v805_9: Space = intersect(&(*CONSTANT_2),&(v805_2));
            drop(v805_2);
            let v805_10: Space = if has_head(&(v805_9)) { singleton(&[]) } else { Space::new() };
            drop(v805_9);
            let v805_12: Space = if (&(v805_10)).is_empty() { Space::new() } else {
              let v807_11: Space = routine_19(c, &v798_6_cursor.path()[v798_6_origin..(v798_6_origin + 2)], &(*p1), &v798_6_cursor);
              compose(&(v805_10),&(v807_11))
            };
            drop(v805_10);
            let v805_13: Space = unite(&(v805_8),&(v805_12));
            join_wrapped_into(&mut v804_10_write,&((v805_13).read_zipper()),&[]);
            }
            v798_6_cursor.ascend(1);
          }
          drop(v804_10_write);
          compose(&(v799_9),&(v804_10))
        };
        drop(v799_9);
        let v799_12: Space = unite(&(v799_7),&(v799_11));
        join_wrapped_into(&mut v798_6_write,&((v799_12).read_zipper()),&[]);
        }
        v798_6_cursor.ascend(1);
      }
      drop(v798_6_cursor);
      drop(v798_6_write);
      compose(&(v797_4),&(v798_6))
    };
    drop(v797_4);
    join_wrapped_into(&mut v796_17_write,&((v797_7).read_zipper()),&[]);
    }
    v796_17_cursor.ascend(1);
  }
  drop(v796_17_cursor);
  drop(v796_17_write);
  (v796_17).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v808_21 = Space::new();
  let mut v808_21_write = v808_21.write_zipper();
  let mut v808_21_cursor = (*s0).read_zipper();
  let v808_21_origin = v808_21_cursor.path().len();
  for v808_21_byte in v808_21_cursor.child_mask().iter() {
    v808_21_cursor.descend_to_existing_byte(v808_21_byte);
    {
    let v809_2: Space = singleton(&v808_21_cursor.path()[v808_21_origin..(v808_21_origin + 1)]);
    let v809_3: Space = intersect(&(*CONSTANT_2),&(v809_2));
    let v809_4: Space = if has_head(&(v809_3)) { singleton(&[]) } else { Space::new() };
    drop(v809_3);
    let v809_5: Space = subtract(&(*CONSTANT_1),&(v809_4));
    drop(v809_4);
    let v809_8: Space = if (&(v809_5)).is_empty() { Space::new() } else {
      let v810_6: Path = concat_path(&(*p0),&v808_21_cursor.path()[v808_21_origin..(v808_21_origin + 1)]);
      let mut v810_7 = Space::new();
      let mut v810_7_write = v810_7.write_zipper();
      for v810_7_byte in v808_21_cursor.child_mask().iter() {
        v808_21_cursor.descend_to_existing_byte(v810_7_byte);
        {
        let v811_2: Space = singleton(&v808_21_cursor.path()[(v808_21_origin + 1)..(v808_21_origin + 2)]);
        let v811_3: Space = intersect(&(*CONSTANT_2),&(v811_2));
        let v811_4: Space = if has_head(&(v811_3)) { singleton(&[]) } else { Space::new() };
        drop(v811_3);
        let v811_5: Space = subtract(&(*CONSTANT_1),&(v811_4));
        drop(v811_4);
        let v811_8: Space = if (&(v811_5)).is_empty() { Space::new() } else {
          let v812_6: Path = concat_path(&(v810_6),&v808_21_cursor.path()[(v808_21_origin + 1)..(v808_21_origin + 2)]);
          let mut v812_7 = Space::new();
          let mut v812_7_write = v812_7.write_zipper();
          for v812_7_byte in v808_21_cursor.child_mask().iter() {
            v808_21_cursor.descend_to_existing_byte(v812_7_byte);
            {
            let v813_2: Space = singleton(&v808_21_cursor.path()[(v808_21_origin + 2)..(v808_21_origin + 3)]);
            let v813_3: Space = intersect(&(*CONSTANT_2),&(v813_2));
            let v813_4: Space = if has_head(&(v813_3)) { singleton(&[]) } else { Space::new() };
            drop(v813_3);
            let v813_5: Space = subtract(&(*CONSTANT_1),&(v813_4));
            drop(v813_4);
            let v813_8: Space = if (&(v813_5)).is_empty() { Space::new() } else {
              let v814_6: Path = concat_path(&(v812_6),&v808_21_cursor.path()[(v808_21_origin + 2)..(v808_21_origin + 3)]);
              let v814_7: Space = routine_52(c, &(v814_6), &(*p1), &v808_21_cursor);
              compose(&(v813_5),&(v814_7))
            };
            drop(v813_5);
            let v813_9: Space = intersect(&(*CONSTANT_2),&(v813_2));
            drop(v813_2);
            let v813_10: Space = if has_head(&(v813_9)) { singleton(&[]) } else { Space::new() };
            drop(v813_9);
            let v813_12: Space = if (&(v813_10)).is_empty() { Space::new() } else {
              let v815_6: Path = concat_path(&(v812_6),&v808_21_cursor.path()[(v808_21_origin + 2)..(v808_21_origin + 3)]);
              let v815_11: Space = routine_53(c, &(v815_6), &(*p1), &v808_21_cursor);
              drop(v815_6);
              compose(&(v813_10),&(v815_11))
            };
            drop(v813_10);
            let v813_13: Space = unite(&(v813_8),&(v813_12));
            join_wrapped_into(&mut v812_7_write,&((v813_13).read_zipper()),&[]);
            }
            v808_21_cursor.ascend(1);
          }
          drop(v812_7_write);
          compose(&(v811_5),&(v812_7))
        };
        drop(v811_5);
        let v811_9: Space = intersect(&(*CONSTANT_2),&(v811_2));
        drop(v811_2);
        let v811_10: Space = if has_head(&(v811_9)) { singleton(&[]) } else { Space::new() };
        drop(v811_9);
        let v811_12: Space = if (&(v811_10)).is_empty() { Space::new() } else {
          let v816_6: Path = concat_path(&(v810_6),&v808_21_cursor.path()[(v808_21_origin + 1)..(v808_21_origin + 2)]);
          let mut v816_11 = Space::new();
          let mut v816_11_write = v816_11.write_zipper();
          for v816_11_byte in v808_21_cursor.child_mask().iter() {
            v808_21_cursor.descend_to_existing_byte(v816_11_byte);
            {
            let v817_2: Space = singleton(&v808_21_cursor.path()[(v808_21_origin + 2)..(v808_21_origin + 3)]);
            let v817_3: Space = intersect(&(*CONSTANT_2),&(v817_2));
            let v817_4: Space = if has_head(&(v817_3)) { singleton(&[]) } else { Space::new() };
            drop(v817_3);
            let v817_5: Space = subtract(&(*CONSTANT_1),&(v817_4));
            drop(v817_4);
            let v817_8: Space = if (&(v817_5)).is_empty() { Space::new() } else {
              let v818_6: Path = concat_path(&(v816_6),&v808_21_cursor.path()[(v808_21_origin + 2)..(v808_21_origin + 3)]);
              let v818_7: Space = routine_52(c, &(v818_6), &(*p1), &v808_21_cursor);
              compose(&(v817_5),&(v818_7))
            };
            drop(v817_5);
            let v817_9: Space = intersect(&(*CONSTANT_2),&(v817_2));
            drop(v817_2);
            let v817_10: Space = if has_head(&(v817_9)) { singleton(&[]) } else { Space::new() };
            drop(v817_9);
            let v817_12: Space = if (&(v817_10)).is_empty() { Space::new() } else {
              let v819_6: Path = concat_path(&(v816_6),&v808_21_cursor.path()[(v808_21_origin + 2)..(v808_21_origin + 3)]);
              let v819_11: Space = routine_19(c, &(v819_6), &(*p1), &v808_21_cursor);
              drop(v819_6);
              compose(&(v817_10),&(v819_11))
            };
            drop(v817_10);
            let v817_13: Space = unite(&(v817_8),&(v817_12));
            join_wrapped_into(&mut v816_11_write,&((v817_13).read_zipper()),&[]);
            }
            v808_21_cursor.ascend(1);
          }
          drop(v816_11_write);
          drop(v816_6);
          compose(&(v811_10),&(v816_11))
        };
        drop(v811_10);
        let v811_13: Space = unite(&(v811_8),&(v811_12));
        join_wrapped_into(&mut v810_7_write,&((v811_13).read_zipper()),&[]);
        }
        v808_21_cursor.ascend(1);
      }
      drop(v810_7_write);
      compose(&(v809_5),&(v810_7))
    };
    drop(v809_5);
    let v809_9: Space = intersect(&(*CONSTANT_2),&(v809_2));
    drop(v809_2);
    let v809_10: Space = if has_head(&(v809_9)) { singleton(&[]) } else { Space::new() };
    drop(v809_9);
    let v809_12: Space = if (&(v809_10)).is_empty() { Space::new() } else {
      let v820_6: Path = concat_path(&(*p0),&v808_21_cursor.path()[v808_21_origin..(v808_21_origin + 1)]);
      let mut v820_11 = Space::new();
      let mut v820_11_write = v820_11.write_zipper();
      for v820_11_byte in v808_21_cursor.child_mask().iter() {
        v808_21_cursor.descend_to_existing_byte(v820_11_byte);
        {
        let v821_2: Space = singleton(&v808_21_cursor.path()[(v808_21_origin + 1)..(v808_21_origin + 2)]);
        let v821_3: Space = intersect(&(*CONSTANT_2),&(v821_2));
        let v821_4: Space = if has_head(&(v821_3)) { singleton(&[]) } else { Space::new() };
        drop(v821_3);
        let v821_5: Space = subtract(&(*CONSTANT_1),&(v821_4));
        drop(v821_4);
        let v821_8: Space = if (&(v821_5)).is_empty() { Space::new() } else {
          let v822_6: Path = concat_path(&(v820_6),&v808_21_cursor.path()[(v808_21_origin + 1)..(v808_21_origin + 2)]);
          let mut v822_7 = Space::new();
          let mut v822_7_write = v822_7.write_zipper();
          for v822_7_byte in v808_21_cursor.child_mask().iter() {
            v808_21_cursor.descend_to_existing_byte(v822_7_byte);
            {
            let v823_2: Space = singleton(&v808_21_cursor.path()[(v808_21_origin + 2)..(v808_21_origin + 3)]);
            let v823_3: Space = intersect(&(*CONSTANT_2),&(v823_2));
            let v823_4: Space = if has_head(&(v823_3)) { singleton(&[]) } else { Space::new() };
            drop(v823_3);
            let v823_5: Space = subtract(&(*CONSTANT_1),&(v823_4));
            drop(v823_4);
            let v823_8: Space = if (&(v823_5)).is_empty() { Space::new() } else {
              let v824_6: Path = concat_path(&(v822_6),&v808_21_cursor.path()[(v808_21_origin + 2)..(v808_21_origin + 3)]);
              let v824_7: Space = routine_52(c, &(v824_6), &(*p1), &v808_21_cursor);
              compose(&(v823_5),&(v824_7))
            };
            drop(v823_5);
            let v823_9: Space = intersect(&(*CONSTANT_2),&(v823_2));
            drop(v823_2);
            let v823_10: Space = if has_head(&(v823_9)) { singleton(&[]) } else { Space::new() };
            drop(v823_9);
            let v823_12: Space = if (&(v823_10)).is_empty() { Space::new() } else {
              let v825_6: Path = concat_path(&(v822_6),&v808_21_cursor.path()[(v808_21_origin + 2)..(v808_21_origin + 3)]);
              let v825_11: Space = routine_53(c, &(v825_6), &(*p1), &v808_21_cursor);
              drop(v825_6);
              compose(&(v823_10),&(v825_11))
            };
            drop(v823_10);
            let v823_13: Space = unite(&(v823_8),&(v823_12));
            join_wrapped_into(&mut v822_7_write,&((v823_13).read_zipper()),&[]);
            }
            v808_21_cursor.ascend(1);
          }
          drop(v822_7_write);
          compose(&(v821_5),&(v822_7))
        };
        drop(v821_5);
        let v821_9: Space = intersect(&(*CONSTANT_2),&(v821_2));
        drop(v821_2);
        let v821_10: Space = if has_head(&(v821_9)) { singleton(&[]) } else { Space::new() };
        drop(v821_9);
        let v821_11: Space = compose(&(v821_10),&v808_21_cursor);
        drop(v821_10);
        let v826_6: Path = concat_path(&(v820_6),&v808_21_cursor.path()[(v808_21_origin + 1)..(v808_21_origin + 2)]);
        let v821_12: Space = wrap(&(v821_11),&(v826_6));
        drop(v821_11);
        let v821_13: Space = wrap(&(v821_12),&(*p1));
        drop(v821_12);
        let v821_14: Space = unite(&(v821_8),&(v821_13));
        drop(v821_13);
        join_wrapped_into(&mut v820_11_write,&((v821_14).read_zipper()),&[]);
        }
        v808_21_cursor.ascend(1);
      }
      drop(v820_11_write);
      drop(v820_6);
      compose(&(v809_10),&(v820_11))
    };
    drop(v809_10);
    let v809_13: Space = unite(&(v809_8),&(v809_12));
    join_wrapped_into(&mut v808_21_write,&((v809_13).read_zipper()),&[]);
    }
    v808_21_cursor.ascend(1);
  }
  drop(v808_21_cursor);
  drop(v808_21_write);
  (v808_21).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v827_15 = Space::new();
  let mut v827_15_write = v827_15.write_zipper();
  let mut v827_15_cursor = (*s0).read_zipper();
  let v827_15_origin = v827_15_cursor.path().len();
  for v827_15_byte in v827_15_cursor.child_mask().iter() {
    v827_15_cursor.descend_to_existing_byte(v827_15_byte);
    {
    let v828_2: Space = singleton(&v827_15_cursor.path()[v827_15_origin..(v827_15_origin + 1)]);
    let v828_3: Space = intersect(&(*CONSTANT_2),&(v828_2));
    let v828_4: Space = if has_head(&(v828_3)) { singleton(&[]) } else { Space::new() };
    drop(v828_3);
    let v828_5: Space = subtract(&(*CONSTANT_1),&(v828_4));
    drop(v828_4);
    let v828_8: Space = if (&(v828_5)).is_empty() { Space::new() } else {
      let v829_6: Path = concat_path(&(*p0),&v827_15_cursor.path()[v827_15_origin..(v827_15_origin + 1)]);
      let mut v829_7 = Space::new();
      let mut v829_7_write = v829_7.write_zipper();
      for v829_7_byte in v827_15_cursor.child_mask().iter() {
        v827_15_cursor.descend_to_existing_byte(v829_7_byte);
        {
        let v830_2: Space = singleton(&v827_15_cursor.path()[(v827_15_origin + 1)..(v827_15_origin + 2)]);
        let v830_3: Space = intersect(&(*CONSTANT_2),&(v830_2));
        let v830_4: Space = if has_head(&(v830_3)) { singleton(&[]) } else { Space::new() };
        drop(v830_3);
        let v830_5: Space = subtract(&(*CONSTANT_1),&(v830_4));
        drop(v830_4);
        let v830_8: Space = if (&(v830_5)).is_empty() { Space::new() } else {
          let v831_6: Path = concat_path(&(v829_6),&v827_15_cursor.path()[(v827_15_origin + 1)..(v827_15_origin + 2)]);
          let mut v831_7 = Space::new();
          let mut v831_7_write = v831_7.write_zipper();
          for v831_7_byte in v827_15_cursor.child_mask().iter() {
            v827_15_cursor.descend_to_existing_byte(v831_7_byte);
            {
            let v832_2: Space = singleton(&v827_15_cursor.path()[(v827_15_origin + 2)..(v827_15_origin + 3)]);
            let v832_3: Space = intersect(&(*CONSTANT_2),&(v832_2));
            let v832_4: Space = if has_head(&(v832_3)) { singleton(&[]) } else { Space::new() };
            drop(v832_3);
            let v832_5: Space = subtract(&(*CONSTANT_1),&(v832_4));
            drop(v832_4);
            let v832_8: Space = if (&(v832_5)).is_empty() { Space::new() } else {
              let v833_6: Path = concat_path(&(v831_6),&v827_15_cursor.path()[(v827_15_origin + 2)..(v827_15_origin + 3)]);
              let v833_7: Space = routine_52(c, &(v833_6), &(*p1), &v827_15_cursor);
              compose(&(v832_5),&(v833_7))
            };
            drop(v832_5);
            let v832_9: Space = intersect(&(*CONSTANT_2),&(v832_2));
            drop(v832_2);
            let v832_10: Space = if has_head(&(v832_9)) { singleton(&[]) } else { Space::new() };
            drop(v832_9);
            let v832_12: Space = if (&(v832_10)).is_empty() { Space::new() } else {
              let v834_6: Path = concat_path(&(v831_6),&v827_15_cursor.path()[(v827_15_origin + 2)..(v827_15_origin + 3)]);
              let v834_11: Space = routine_53(c, &(v834_6), &(*p1), &v827_15_cursor);
              drop(v834_6);
              compose(&(v832_10),&(v834_11))
            };
            drop(v832_10);
            let v832_13: Space = unite(&(v832_8),&(v832_12));
            join_wrapped_into(&mut v831_7_write,&((v832_13).read_zipper()),&[]);
            }
            v827_15_cursor.ascend(1);
          }
          drop(v831_7_write);
          compose(&(v830_5),&(v831_7))
        };
        drop(v830_5);
        let v830_9: Space = intersect(&(*CONSTANT_2),&(v830_2));
        drop(v830_2);
        let v830_10: Space = if has_head(&(v830_9)) { singleton(&[]) } else { Space::new() };
        drop(v830_9);
        let v830_12: Space = if (&(v830_10)).is_empty() { Space::new() } else {
          let v835_6: Path = concat_path(&(v829_6),&v827_15_cursor.path()[(v827_15_origin + 1)..(v827_15_origin + 2)]);
          let mut v835_11 = Space::new();
          let mut v835_11_write = v835_11.write_zipper();
          for v835_11_byte in v827_15_cursor.child_mask().iter() {
            v827_15_cursor.descend_to_existing_byte(v835_11_byte);
            {
            let v836_2: Space = singleton(&v827_15_cursor.path()[(v827_15_origin + 2)..(v827_15_origin + 3)]);
            let v836_3: Space = intersect(&(*CONSTANT_2),&(v836_2));
            let v836_4: Space = if has_head(&(v836_3)) { singleton(&[]) } else { Space::new() };
            drop(v836_3);
            let v836_5: Space = subtract(&(*CONSTANT_1),&(v836_4));
            drop(v836_4);
            let v836_8: Space = if (&(v836_5)).is_empty() { Space::new() } else {
              let v837_6: Path = concat_path(&(v835_6),&v827_15_cursor.path()[(v827_15_origin + 2)..(v827_15_origin + 3)]);
              let v837_7: Space = routine_52(c, &(v837_6), &(*p1), &v827_15_cursor);
              compose(&(v836_5),&(v837_7))
            };
            drop(v836_5);
            let v836_9: Space = intersect(&(*CONSTANT_2),&(v836_2));
            drop(v836_2);
            let v836_10: Space = if has_head(&(v836_9)) { singleton(&[]) } else { Space::new() };
            drop(v836_9);
            let v836_12: Space = if (&(v836_10)).is_empty() { Space::new() } else {
              let v838_6: Path = concat_path(&(v835_6),&v827_15_cursor.path()[(v827_15_origin + 2)..(v827_15_origin + 3)]);
              let v838_11: Space = routine_19(c, &(v838_6), &(*p1), &v827_15_cursor);
              drop(v838_6);
              compose(&(v836_10),&(v838_11))
            };
            drop(v836_10);
            let v836_13: Space = unite(&(v836_8),&(v836_12));
            join_wrapped_into(&mut v835_11_write,&((v836_13).read_zipper()),&[]);
            }
            v827_15_cursor.ascend(1);
          }
          drop(v835_11_write);
          drop(v835_6);
          compose(&(v830_10),&(v835_11))
        };
        drop(v830_10);
        let v830_13: Space = unite(&(v830_8),&(v830_12));
        join_wrapped_into(&mut v829_7_write,&((v830_13).read_zipper()),&[]);
        }
        v827_15_cursor.ascend(1);
      }
      drop(v829_7_write);
      compose(&(v828_5),&(v829_7))
    };
    drop(v828_5);
    let v828_9: Space = intersect(&(*CONSTANT_2),&(v828_2));
    drop(v828_2);
    let v828_10: Space = if has_head(&(v828_9)) { singleton(&[]) } else { Space::new() };
    drop(v828_9);
    let v828_11: Space = compose(&(v828_10),&v827_15_cursor);
    drop(v828_10);
    let v839_6: Path = concat_path(&(*p0),&v827_15_cursor.path()[v827_15_origin..(v827_15_origin + 1)]);
    let v828_12: Space = wrap(&(v828_11),&(v839_6));
    drop(v828_11);
    let v828_13: Space = wrap(&(v828_12),&(*p1));
    drop(v828_12);
    let v828_14: Space = unite(&(v828_8),&(v828_13));
    drop(v828_13);
    join_wrapped_into(&mut v827_15_write,&((v828_14).read_zipper()),&[]);
    }
    v827_15_cursor.ascend(1);
  }
  drop(v827_15_cursor);
  drop(v827_15_write);
  (v827_15).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v840_4: Space = Space::new();
  (v840_4).clone()
}

fn routine_47(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v841_17 = Space::new();
  let mut v841_17_write = v841_17.write_zipper();
  let mut v841_17_cursor = (*s0).read_zipper();
  let v841_17_origin = v841_17_cursor.path().len();
  for v841_17_byte in v841_17_cursor.child_mask().iter() {
    v841_17_cursor.descend_to_existing_byte(v841_17_byte);
    {
    let v842_2: Space = singleton(&v841_17_cursor.path()[v841_17_origin..(v841_17_origin + 1)]);
    let v842_3: Space = intersect(&(*CONSTANT_2),&(v842_2));
    drop(v842_2);
    let v842_4: Space = if has_head(&(v842_3)) { singleton(&[]) } else { Space::new() };
    drop(v842_3);
    let v842_7: Space = if (&(v842_4)).is_empty() { Space::new() } else {
      let mut v843_6 = Space::new();
      let mut v843_6_write = v843_6.write_zipper();
      let mut v843_6_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v841_17_cursor.path()[v841_17_origin..(v841_17_origin + 1)]);
      let v843_6_origin = v843_6_cursor.path().len();
      for v843_6_byte in v843_6_cursor.child_mask().iter() {
        v843_6_cursor.descend_to_existing_byte(v843_6_byte);
        {
        let v844_2: Space = singleton(&v843_6_cursor.path()[v843_6_origin..(v843_6_origin + 1)]);
        let v844_3: Space = intersect(&(*CONSTANT_2),&(v844_2));
        let v844_4: Space = if has_head(&(v844_3)) { singleton(&[]) } else { Space::new() };
        drop(v844_3);
        let v844_5: Space = subtract(&(*CONSTANT_1),&(v844_4));
        drop(v844_4);
        let v844_7: Space = if (&(v844_5)).is_empty() { Space::new() } else {
          let mut v845_6 = Space::new();
          let mut v845_6_write = v845_6.write_zipper();
          for v845_6_byte in v843_6_cursor.child_mask().iter() {
            v843_6_cursor.descend_to_existing_byte(v845_6_byte);
            {
            let v846_2: Space = singleton(&v843_6_cursor.path()[(v843_6_origin + 1)..(v843_6_origin + 2)]);
            let v846_3: Space = intersect(&(*CONSTANT_2),&(v846_2));
            let v846_4: Space = if has_head(&(v846_3)) { singleton(&[]) } else { Space::new() };
            drop(v846_3);
            let v846_5: Space = subtract(&(*CONSTANT_1),&(v846_4));
            drop(v846_4);
            let v846_8: Space = if (&(v846_5)).is_empty() { Space::new() } else {
              let v847_7: Space = routine_17(c, &v843_6_cursor.path()[v843_6_origin..(v843_6_origin + 2)], &(*p1), &v843_6_cursor);
              compose(&(v846_5),&(v847_7))
            };
            drop(v846_5);
            let v846_9: Space = intersect(&(*CONSTANT_2),&(v846_2));
            drop(v846_2);
            let v846_10: Space = if has_head(&(v846_9)) { singleton(&[]) } else { Space::new() };
            drop(v846_9);
            let v846_12: Space = if (&(v846_10)).is_empty() { Space::new() } else {
              let v848_11: Space = routine_18(c, &v843_6_cursor.path()[v843_6_origin..(v843_6_origin + 2)], &(*p1), &v843_6_cursor);
              compose(&(v846_10),&(v848_11))
            };
            drop(v846_10);
            let v846_13: Space = unite(&(v846_8),&(v846_12));
            join_wrapped_into(&mut v845_6_write,&((v846_13).read_zipper()),&[]);
            }
            v843_6_cursor.ascend(1);
          }
          drop(v845_6_write);
          compose(&(v844_5),&(v845_6))
        };
        drop(v844_5);
        let v844_8: Space = intersect(&(*CONSTANT_2),&(v844_2));
        drop(v844_2);
        let v844_9: Space = if has_head(&(v844_8)) { singleton(&[]) } else { Space::new() };
        drop(v844_8);
        let v844_11: Space = if (&(v844_9)).is_empty() { Space::new() } else {
          let mut v849_10 = Space::new();
          let mut v849_10_write = v849_10.write_zipper();
          for v849_10_byte in v843_6_cursor.child_mask().iter() {
            v843_6_cursor.descend_to_existing_byte(v849_10_byte);
            {
            let v850_2: Space = singleton(&v843_6_cursor.path()[(v843_6_origin + 1)..(v843_6_origin + 2)]);
            let v850_3: Space = intersect(&(*CONSTANT_2),&(v850_2));
            let v850_4: Space = if has_head(&(v850_3)) { singleton(&[]) } else { Space::new() };
            drop(v850_3);
            let v850_5: Space = subtract(&(*CONSTANT_1),&(v850_4));
            drop(v850_4);
            let v850_8: Space = if (&(v850_5)).is_empty() { Space::new() } else {
              let v851_7: Space = routine_17(c, &v843_6_cursor.path()[v843_6_origin..(v843_6_origin + 2)], &(*p1), &v843_6_cursor);
              compose(&(v850_5),&(v851_7))
            };
            drop(v850_5);
            let v850_9: Space = intersect(&(*CONSTANT_2),&(v850_2));
            drop(v850_2);
            let v850_10: Space = if has_head(&(v850_9)) { singleton(&[]) } else { Space::new() };
            drop(v850_9);
            let v850_12: Space = if (&(v850_10)).is_empty() { Space::new() } else {
              let v852_11: Space = routine_19(c, &v843_6_cursor.path()[v843_6_origin..(v843_6_origin + 2)], &(*p1), &v843_6_cursor);
              compose(&(v850_10),&(v852_11))
            };
            drop(v850_10);
            let v850_13: Space = unite(&(v850_8),&(v850_12));
            join_wrapped_into(&mut v849_10_write,&((v850_13).read_zipper()),&[]);
            }
            v843_6_cursor.ascend(1);
          }
          drop(v849_10_write);
          compose(&(v844_9),&(v849_10))
        };
        drop(v844_9);
        let v844_12: Space = unite(&(v844_7),&(v844_11));
        join_wrapped_into(&mut v843_6_write,&((v844_12).read_zipper()),&[]);
        }
        v843_6_cursor.ascend(1);
      }
      drop(v843_6_cursor);
      drop(v843_6_write);
      compose(&(v842_4),&(v843_6))
    };
    drop(v842_4);
    join_wrapped_into(&mut v841_17_write,&((v842_7).read_zipper()),&[]);
    }
    v841_17_cursor.ascend(1);
  }
  drop(v841_17_cursor);
  drop(v841_17_write);
  (v841_17).clone()
}

fn routine_48(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v853_9 = Space::new();
  let mut v853_9_write = v853_9.write_zipper();
  let mut v853_9_cursor = (*s0).read_zipper();
  let v853_9_origin = v853_9_cursor.path().len();
  for v853_9_byte in v853_9_cursor.child_mask().iter() {
    v853_9_cursor.descend_to_existing_byte(v853_9_byte);
    {
    let v854_2: Space = singleton(&v853_9_cursor.path()[v853_9_origin..(v853_9_origin + 1)]);
    let v854_3: Space = intersect(&(*CONSTANT_2),&(v854_2));
    let v854_4: Space = if has_head(&(v854_3)) { singleton(&[]) } else { Space::new() };
    drop(v854_3);
    let v854_5: Space = subtract(&(*CONSTANT_1),&(v854_4));
    drop(v854_4);
    let v854_8: Space = if (&(v854_5)).is_empty() { Space::new() } else {
      let v855_6: Path = concat_path(&(*p0),&v853_9_cursor.path()[v853_9_origin..(v853_9_origin + 1)]);
      let mut v855_7 = Space::new();
      let mut v855_7_write = v855_7.write_zipper();
      for v855_7_byte in v853_9_cursor.child_mask().iter() {
        v853_9_cursor.descend_to_existing_byte(v855_7_byte);
        {
        let v856_2: Space = singleton(&v853_9_cursor.path()[(v853_9_origin + 1)..(v853_9_origin + 2)]);
        let v856_3: Space = intersect(&(*CONSTANT_2),&(v856_2));
        drop(v856_2);
        let v856_4: Space = if has_head(&(v856_3)) { singleton(&[]) } else { Space::new() };
        drop(v856_3);
        let v856_7: Space = if (&(v856_4)).is_empty() { Space::new() } else {
          let v857_5: Path = concat_path(&(v855_6),&v853_9_cursor.path()[(v853_9_origin + 1)..(v853_9_origin + 2)]);
          let mut v857_6 = Space::new();
          let mut v857_6_write = v857_6.write_zipper();
          for v857_6_byte in v853_9_cursor.child_mask().iter() {
            v853_9_cursor.descend_to_existing_byte(v857_6_byte);
            {
            let v858_2: Space = singleton(&v853_9_cursor.path()[(v853_9_origin + 2)..(v853_9_origin + 3)]);
            let v858_3: Space = intersect(&(*CONSTANT_2),&(v858_2));
            drop(v858_2);
            let v858_4: Space = if has_head(&(v858_3)) { singleton(&[]) } else { Space::new() };
            drop(v858_3);
            let v858_7: Space = if (&(v858_4)).is_empty() { Space::new() } else {
              let v859_5: Path = concat_path(&(v857_5),&v853_9_cursor.path()[(v853_9_origin + 2)..(v853_9_origin + 3)]);
              let v859_6: Space = routine_19(c, &(v859_5), &(*p1), &v853_9_cursor);
              drop(v859_5);
              compose(&(v858_4),&(v859_6))
            };
            drop(v858_4);
            join_wrapped_into(&mut v857_6_write,&((v858_7).read_zipper()),&[]);
            }
            v853_9_cursor.ascend(1);
          }
          drop(v857_6_write);
          drop(v857_5);
          compose(&(v856_4),&(v857_6))
        };
        drop(v856_4);
        join_wrapped_into(&mut v855_7_write,&((v856_7).read_zipper()),&[]);
        }
        v853_9_cursor.ascend(1);
      }
      drop(v855_7_write);
      compose(&(v854_5),&(v855_7))
    };
    drop(v854_5);
    let v854_9: Space = intersect(&(*CONSTANT_2),&(v854_2));
    drop(v854_2);
    let v854_10: Space = if has_head(&(v854_9)) { singleton(&[]) } else { Space::new() };
    drop(v854_9);
    let v854_12: Space = if (&(v854_10)).is_empty() { Space::new() } else {
      let v860_6: Path = concat_path(&(*p0),&v853_9_cursor.path()[v853_9_origin..(v853_9_origin + 1)]);
      let mut v860_11 = Space::new();
      let mut v860_11_write = v860_11.write_zipper();
      for v860_11_byte in v853_9_cursor.child_mask().iter() {
        v853_9_cursor.descend_to_existing_byte(v860_11_byte);
        {
        let v861_2: Space = singleton(&v853_9_cursor.path()[(v853_9_origin + 1)..(v853_9_origin + 2)]);
        let v861_3: Space = intersect(&(*CONSTANT_2),&(v861_2));
        drop(v861_2);
        let v861_4: Space = if has_head(&(v861_3)) { singleton(&[]) } else { Space::new() };
        drop(v861_3);
        let v861_5: Space = compose(&(v861_4),&v853_9_cursor);
        drop(v861_4);
        let v861_6: Path = concat_path(&(v860_6),&v853_9_cursor.path()[(v853_9_origin + 1)..(v853_9_origin + 2)]);
        join_wrapped_into(&mut v860_11_write,&((v861_5).read_zipper()),&(v861_6));
        drop(v861_5);
        drop(v861_6);
        }
        v853_9_cursor.ascend(1);
      }
      drop(v860_11_write);
      drop(v860_6);
      compose(&(v854_10),&(v860_11))
    };
    drop(v854_10);
    let v854_13: Space = wrap(&(v854_12),&(*p1));
    drop(v854_12);
    let v854_14: Space = unite(&(v854_8),&(v854_13));
    drop(v854_13);
    join_wrapped_into(&mut v853_9_write,&((v854_14).read_zipper()),&[]);
    }
    v853_9_cursor.ascend(1);
  }
  drop(v853_9_cursor);
  drop(v853_9_write);
  (v853_9).clone()
}

fn routine_49(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v862_8 = Space::new();
  let mut v862_8_write = v862_8.write_zipper();
  let mut v862_8_cursor = (*s0).read_zipper();
  let v862_8_origin = v862_8_cursor.path().len();
  for v862_8_byte in v862_8_cursor.child_mask().iter() {
    v862_8_cursor.descend_to_existing_byte(v862_8_byte);
    {
    let v863_2: Space = singleton(&v862_8_cursor.path()[v862_8_origin..(v862_8_origin + 1)]);
    let v863_3: Space = intersect(&(*CONSTANT_2),&(v863_2));
    let v863_4: Space = if has_head(&(v863_3)) { singleton(&[]) } else { Space::new() };
    drop(v863_3);
    let v863_5: Space = subtract(&(*CONSTANT_1),&(v863_4));
    drop(v863_4);
    let v863_8: Space = if (&(v863_5)).is_empty() { Space::new() } else {
      let v864_6: Path = concat_path(&(*p0),&v862_8_cursor.path()[v862_8_origin..(v862_8_origin + 1)]);
      let mut v864_7 = Space::new();
      let mut v864_7_write = v864_7.write_zipper();
      for v864_7_byte in v862_8_cursor.child_mask().iter() {
        v862_8_cursor.descend_to_existing_byte(v864_7_byte);
        {
        let v865_2: Space = singleton(&v862_8_cursor.path()[(v862_8_origin + 1)..(v862_8_origin + 2)]);
        let v865_3: Space = intersect(&(*CONSTANT_2),&(v865_2));
        drop(v865_2);
        let v865_4: Space = if has_head(&(v865_3)) { singleton(&[]) } else { Space::new() };
        drop(v865_3);
        let v865_7: Space = if (&(v865_4)).is_empty() { Space::new() } else {
          let v866_5: Path = concat_path(&(v864_6),&v862_8_cursor.path()[(v862_8_origin + 1)..(v862_8_origin + 2)]);
          let mut v866_6 = Space::new();
          let mut v866_6_write = v866_6.write_zipper();
          for v866_6_byte in v862_8_cursor.child_mask().iter() {
            v862_8_cursor.descend_to_existing_byte(v866_6_byte);
            {
            let v867_2: Space = singleton(&v862_8_cursor.path()[(v862_8_origin + 2)..(v862_8_origin + 3)]);
            let v867_3: Space = intersect(&(*CONSTANT_2),&(v867_2));
            drop(v867_2);
            let v867_4: Space = if has_head(&(v867_3)) { singleton(&[]) } else { Space::new() };
            drop(v867_3);
            let v867_7: Space = if (&(v867_4)).is_empty() { Space::new() } else {
              let v868_5: Path = concat_path(&(v866_5),&v862_8_cursor.path()[(v862_8_origin + 2)..(v862_8_origin + 3)]);
              let v868_6: Space = routine_19(c, &(v868_5), &(*p1), &v862_8_cursor);
              drop(v868_5);
              compose(&(v867_4),&(v868_6))
            };
            drop(v867_4);
            join_wrapped_into(&mut v866_6_write,&((v867_7).read_zipper()),&[]);
            }
            v862_8_cursor.ascend(1);
          }
          drop(v866_6_write);
          drop(v866_5);
          compose(&(v865_4),&(v866_6))
        };
        drop(v865_4);
        join_wrapped_into(&mut v864_7_write,&((v865_7).read_zipper()),&[]);
        }
        v862_8_cursor.ascend(1);
      }
      drop(v864_7_write);
      compose(&(v863_5),&(v864_7))
    };
    drop(v863_5);
    let v863_9: Space = intersect(&(*CONSTANT_2),&(v863_2));
    drop(v863_2);
    let v863_10: Space = if has_head(&(v863_9)) { singleton(&[]) } else { Space::new() };
    drop(v863_9);
    let v863_11: Space = compose(&(v863_10),&v862_8_cursor);
    drop(v863_10);
    let v869_6: Path = concat_path(&(*p0),&v862_8_cursor.path()[v862_8_origin..(v862_8_origin + 1)]);
    let v863_12: Space = wrap(&(v863_11),&(v869_6));
    drop(v863_11);
    let v863_13: Space = wrap(&(v863_12),&(*p1));
    drop(v863_12);
    let v863_14: Space = unite(&(v863_8),&(v863_13));
    drop(v863_13);
    join_wrapped_into(&mut v862_8_write,&((v863_14).read_zipper()),&[]);
    }
    v862_8_cursor.ascend(1);
  }
  drop(v862_8_cursor);
  drop(v862_8_write);
  (v862_8).clone()
}

fn routine_50(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v870_5 = Space::new();
  let mut v870_5_write = v870_5.write_zipper();
  let mut v870_5_cursor = (*s0).read_zipper();
  let v870_5_origin = v870_5_cursor.path().len();
  for v870_5_byte in v870_5_cursor.child_mask().iter() {
    v870_5_cursor.descend_to_existing_byte(v870_5_byte);
    {
    let v871_2: Space = singleton(&v870_5_cursor.path()[v870_5_origin..(v870_5_origin + 1)]);
    let v871_3: Space = intersect(&(*CONSTANT_2),&(v871_2));
    drop(v871_2);
    let v871_4: Space = if has_head(&(v871_3)) { singleton(&[]) } else { Space::new() };
    drop(v871_3);
    let v871_7: Space = if (&(v871_4)).is_empty() { Space::new() } else {
      let v872_5: Path = concat_path(&(*p0),&v870_5_cursor.path()[v870_5_origin..(v870_5_origin + 1)]);
      let mut v872_6 = Space::new();
      let mut v872_6_write = v872_6.write_zipper();
      for v872_6_byte in v870_5_cursor.child_mask().iter() {
        v870_5_cursor.descend_to_existing_byte(v872_6_byte);
        {
        let v873_2: Space = singleton(&v870_5_cursor.path()[(v870_5_origin + 1)..(v870_5_origin + 2)]);
        let v873_3: Space = intersect(&(*CONSTANT_2),&(v873_2));
        drop(v873_2);
        let v873_4: Space = if has_head(&(v873_3)) { singleton(&[]) } else { Space::new() };
        drop(v873_3);
        let v873_5: Space = compose(&(v873_4),&v870_5_cursor);
        drop(v873_4);
        let v873_6: Path = concat_path(&(v872_5),&v870_5_cursor.path()[(v870_5_origin + 1)..(v870_5_origin + 2)]);
        join_wrapped_into(&mut v872_6_write,&((v873_5).read_zipper()),&(v873_6));
        drop(v873_5);
        drop(v873_6);
        }
        v870_5_cursor.ascend(1);
      }
      drop(v872_6_write);
      drop(v872_5);
      compose(&(v871_4),&(v872_6))
    };
    drop(v871_4);
    join_wrapped_into(&mut v870_5_write,&((v871_7).read_zipper()),&[]);
    }
    v870_5_cursor.ascend(1);
  }
  drop(v870_5_cursor);
  drop(v870_5_write);
  let v870_6: Space = wrap(&(v870_5),&(*p1));
  drop(v870_5);
  (v870_6).clone()
}

fn routine_51(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v874_4 = Space::new();
  let mut v874_4_write = v874_4.write_zipper();
  let mut v874_4_cursor = (*s0).read_zipper();
  let v874_4_origin = v874_4_cursor.path().len();
  for v874_4_byte in v874_4_cursor.child_mask().iter() {
    v874_4_cursor.descend_to_existing_byte(v874_4_byte);
    {
    let v875_2: Space = singleton(&v874_4_cursor.path()[v874_4_origin..(v874_4_origin + 1)]);
    let v875_3: Space = intersect(&(*CONSTANT_2),&(v875_2));
    drop(v875_2);
    let v875_4: Space = if has_head(&(v875_3)) { singleton(&[]) } else { Space::new() };
    drop(v875_3);
    let v875_5: Space = compose(&(v875_4),&v874_4_cursor);
    drop(v875_4);
    let v875_6: Path = concat_path(&(*p0),&v874_4_cursor.path()[v874_4_origin..(v874_4_origin + 1)]);
    join_wrapped_into(&mut v874_4_write,&((v875_5).read_zipper()),&(v875_6));
    drop(v875_5);
    drop(v875_6);
    }
    v874_4_cursor.ascend(1);
  }
  drop(v874_4_cursor);
  drop(v874_4_write);
  let v874_5: Space = wrap(&(v874_4),&(*p1));
  drop(v874_4);
  (v874_5).clone()
}

fn routine_52(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v876_3: Space = Space::new();
  (v876_3).clone()
}

fn routine_53(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v877_4 = Space::new();
  let mut v877_4_write = v877_4.write_zipper();
  let mut v877_4_cursor = (*s0).read_zipper();
  let v877_4_origin = v877_4_cursor.path().len();
  for v877_4_byte in v877_4_cursor.child_mask().iter() {
    v877_4_cursor.descend_to_existing_byte(v877_4_byte);
    {
    let v878_2: Space = singleton(&v877_4_cursor.path()[v877_4_origin..(v877_4_origin + 1)]);
    let v878_3: Space = intersect(&(*CONSTANT_2),&(v878_2));
    drop(v878_2);
    let v878_4: Space = if has_head(&(v878_3)) { singleton(&[]) } else { Space::new() };
    drop(v878_3);
    let v878_5: Space = compose(&(v878_4),&v877_4_cursor);
    drop(v878_4);
    let v878_6: Path = concat_path(&(*p0),&v877_4_cursor.path()[v877_4_origin..(v877_4_origin + 1)]);
    join_wrapped_into(&mut v877_4_write,&((v878_5).read_zipper()),&(v878_6));
    drop(v878_5);
    drop(v878_6);
    }
    v877_4_cursor.ascend(1);
  }
  drop(v877_4_cursor);
  drop(v877_4_write);
  let v877_5: Space = wrap(&(v877_4),&(*p1));
  drop(v877_4);
  (v877_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
