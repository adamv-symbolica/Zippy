#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1,0,0,0,1,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_24 = Space::new();
  let mut v0_24_write = v0_24.write_zipper();
  let mut v0_24_cursor = descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0));
  let v0_24_origin = v0_24_cursor.path().len();
  for v0_24_byte in v0_24_cursor.child_mask().iter() {
    v0_24_cursor.descend_to_existing_byte(v0_24_byte);
    {
    let v1_2: Space = singleton(&v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_24_cursor.child_mask().iter() {
        v0_24_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 1)..(v0_24_origin + 2)]);
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let mut v4_7 = Space::new();
          let mut v4_7_write = v4_7.write_zipper();
          for v4_7_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v4_7_byte);
            {
            let v5_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v5_3: Space = intersect(&(*CONSTANT_2),&(v5_2));
            let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
            drop(v5_3);
            let v5_5: Space = subtract(&(*CONSTANT_1),&(v5_4));
            drop(v5_4);
            let v5_8: Space = if (&(v5_5)).is_empty() { Space::new() } else {
              let v6_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v5_5),&(v6_7))
            };
            drop(v5_5);
            let v5_9: Space = intersect(&(*CONSTANT_2),&(v5_2));
            drop(v5_2);
            let v5_10: Space = if has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
            drop(v5_9);
            let v5_12: Space = if (&(v5_10)).is_empty() { Space::new() } else {
              let v7_11: Space = routine_2(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v5_10),&(v7_11))
            };
            drop(v5_10);
            let v5_13: Space = unite(&(v5_8),&(v5_12));
            join_wrapped_into(&mut v4_7_write,&((v5_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v4_7_write);
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let mut v8_11 = Space::new();
          let mut v8_11_write = v8_11.write_zipper();
          for v8_11_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v8_11_byte);
            {
            let v9_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v9_3: Space = intersect(&(*CONSTANT_2),&(v9_2));
            let v9_4: Space = if has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
            drop(v9_3);
            let v9_5: Space = subtract(&(*CONSTANT_1),&(v9_4));
            drop(v9_4);
            let v9_8: Space = if (&(v9_5)).is_empty() { Space::new() } else {
              let v10_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v9_5),&(v10_7))
            };
            drop(v9_5);
            let v9_9: Space = intersect(&(*CONSTANT_2),&(v9_2));
            drop(v9_2);
            let v9_10: Space = if has_head(&(v9_9)) { singleton(&[]) } else { Space::new() };
            drop(v9_9);
            let v9_12: Space = if (&(v9_10)).is_empty() { Space::new() } else {
              let v11_11: Space = routine_3(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v9_10),&(v11_11))
            };
            drop(v9_10);
            let v9_13: Space = unite(&(v9_8),&(v9_12));
            join_wrapped_into(&mut v8_11_write,&((v9_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v8_11_write);
          compose(&(v3_10),&(v8_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_24_cursor.ascend(1);
      }
      drop(v2_6_write);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v12_10 = Space::new();
      let mut v12_10_write = v12_10.write_zipper();
      for v12_10_byte in v0_24_cursor.child_mask().iter() {
        v0_24_cursor.descend_to_existing_byte(v12_10_byte);
        {
        let v13_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 1)..(v0_24_origin + 2)]);
        let v13_3: Space = intersect(&(*CONSTANT_2),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_1),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v15_3: Space = intersect(&(*CONSTANT_2),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_1),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_7: Space = routine_1(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_2),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_11: Space = routine_2(c, &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 3)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v14_7_write);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_2),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v0_24_cursor.child_mask().iter() {
            v0_24_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)]);
            let v19_3: Space = intersect(&(*CONSTANT_2),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_1),&(v19_4));
            drop(v19_4);
            let v19_7: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Space = routine_4(c, &v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)], &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 2)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v19_5),&(v20_6))
            };
            drop(v19_5);
            let v19_8: Space = intersect(&(*CONSTANT_2),&(v19_2));
            drop(v19_2);
            let v19_9: Space = if has_head(&(v19_8)) { singleton(&[]) } else { Space::new() };
            drop(v19_8);
            let v19_11: Space = if (&(v19_9)).is_empty() { Space::new() } else {
              let v21_10: Space = routine_5(c, &v0_24_cursor.path()[(v0_24_origin + 2)..(v0_24_origin + 3)], &v0_24_cursor.path()[v0_24_origin..(v0_24_origin + 2)], &v0_24_cursor, &((*s0.expect("unbound native input")).read_zipper()));
              compose(&(v19_9),&(v21_10))
            };
            drop(v19_9);
            let v19_12: Space = unite(&(v19_7),&(v19_11));
            join_wrapped_into(&mut v18_11_write,&((v19_12).read_zipper()),&[]);
            }
            v0_24_cursor.ascend(1);
          }
          drop(v18_11_write);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_10_write,&((v13_13).read_zipper()),&[]);
        }
        v0_24_cursor.ascend(1);
      }
      drop(v12_10_write);
      compose(&(v1_9),&(v12_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_24_write,&((v1_12).read_zipper()),&[]);
    }
    v0_24_cursor.ascend(1);
  }
  drop(v0_24_cursor);
  drop(v0_24_write);
  let v0_26: Space = wrap(&(v0_24),&(*CONSTANT_3));
  (v0_26).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v22_24 = Space::new();
  let mut v22_24_write = v22_24.write_zipper();
  let mut v22_24_cursor = (*s0).read_zipper();
  let v22_24_origin = v22_24_cursor.path().len();
  for v22_24_byte in v22_24_cursor.child_mask().iter() {
    v22_24_cursor.descend_to_existing_byte(v22_24_byte);
    {
    let v23_2: Space = singleton(&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
    let v23_3: Space = intersect(&(*CONSTANT_2),&(v23_2));
    let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
    drop(v23_3);
    let v23_5: Space = subtract(&(*CONSTANT_1),&(v23_4));
    drop(v23_4);
    let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
      let v24_6: Path = concat_path(&(*p0),&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
      let mut v24_7 = Space::new();
      let mut v24_7_write = v24_7.write_zipper();
      for v24_7_byte in v22_24_cursor.child_mask().iter() {
        v22_24_cursor.descend_to_existing_byte(v24_7_byte);
        {
        let v25_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
        let v25_3: Space = intersect(&(*CONSTANT_2),&(v25_2));
        let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
        drop(v25_3);
        let v25_5: Space = subtract(&(*CONSTANT_1),&(v25_4));
        drop(v25_4);
        let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
          let v26_6: Path = concat_path(&(v24_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v26_7 = Space::new();
          let mut v26_7_write = v26_7.write_zipper();
          for v26_7_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v26_7_byte);
            {
            let v27_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v27_3: Space = intersect(&(*CONSTANT_2),&(v27_2));
            let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
            drop(v27_3);
            let v27_5: Space = subtract(&(*CONSTANT_1),&(v27_4));
            drop(v27_4);
            let v27_8: Space = if (&(v27_5)).is_empty() { Space::new() } else {
              let v28_6: Path = concat_path(&(v26_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v28_7: Space = routine_6(c, &(v28_6), &v22_24_cursor, &(*s1));
              compose(&(v27_5),&(v28_7))
            };
            drop(v27_5);
            let v27_9: Space = intersect(&(*CONSTANT_2),&(v27_2));
            drop(v27_2);
            let v27_10: Space = if has_head(&(v27_9)) { singleton(&[]) } else { Space::new() };
            drop(v27_9);
            let v27_12: Space = if (&(v27_10)).is_empty() { Space::new() } else {
              let v29_6: Path = concat_path(&(v26_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v29_11: Space = routine_7(c, &(v29_6), &v22_24_cursor, &(*s1));
              drop(v29_6);
              compose(&(v27_10),&(v29_11))
            };
            drop(v27_10);
            let v27_13: Space = unite(&(v27_8),&(v27_12));
            join_wrapped_into(&mut v26_7_write,&((v27_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v26_7_write);
          compose(&(v25_5),&(v26_7))
        };
        drop(v25_5);
        let v25_9: Space = intersect(&(*CONSTANT_2),&(v25_2));
        drop(v25_2);
        let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
        drop(v25_9);
        let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
          let v30_6: Path = concat_path(&(v24_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v30_11 = Space::new();
          let mut v30_11_write = v30_11.write_zipper();
          for v30_11_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v30_11_byte);
            {
            let v31_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v31_3: Space = intersect(&(*CONSTANT_2),&(v31_2));
            let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
            drop(v31_3);
            let v31_5: Space = subtract(&(*CONSTANT_1),&(v31_4));
            drop(v31_4);
            let v31_8: Space = if (&(v31_5)).is_empty() { Space::new() } else {
              let v32_6: Path = concat_path(&(v30_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v32_7: Space = routine_6(c, &(v32_6), &v22_24_cursor, &(*s1));
              compose(&(v31_5),&(v32_7))
            };
            drop(v31_5);
            let v31_9: Space = intersect(&(*CONSTANT_2),&(v31_2));
            drop(v31_2);
            let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
            drop(v31_9);
            let v31_12: Space = if (&(v31_10)).is_empty() { Space::new() } else {
              let v33_6: Path = concat_path(&(v30_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v33_11: Space = routine_3(c, &(v33_6), &v22_24_cursor, &(*s1));
              drop(v33_6);
              compose(&(v31_10),&(v33_11))
            };
            drop(v31_10);
            let v31_13: Space = unite(&(v31_8),&(v31_12));
            join_wrapped_into(&mut v30_11_write,&((v31_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v30_11_write);
          drop(v30_6);
          compose(&(v25_10),&(v30_11))
        };
        drop(v25_10);
        let v25_13: Space = unite(&(v25_8),&(v25_12));
        join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
        }
        v22_24_cursor.ascend(1);
      }
      drop(v24_7_write);
      compose(&(v23_5),&(v24_7))
    };
    drop(v23_5);
    let v23_9: Space = intersect(&(*CONSTANT_2),&(v23_2));
    drop(v23_2);
    let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
    drop(v23_9);
    let v23_12: Space = if (&(v23_10)).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&v22_24_cursor.path()[v22_24_origin..(v22_24_origin + 1)]);
      let mut v34_11 = Space::new();
      let mut v34_11_write = v34_11.write_zipper();
      for v34_11_byte in v22_24_cursor.child_mask().iter() {
        v22_24_cursor.descend_to_existing_byte(v34_11_byte);
        {
        let v35_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
        let v35_3: Space = intersect(&(*CONSTANT_2),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_1),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (&(v35_5)).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v36_7 = Space::new();
          let mut v36_7_write = v36_7.write_zipper();
          for v36_7_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v36_7_byte);
            {
            let v37_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v37_3: Space = intersect(&(*CONSTANT_2),&(v37_2));
            let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
            drop(v37_3);
            let v37_5: Space = subtract(&(*CONSTANT_1),&(v37_4));
            drop(v37_4);
            let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
              let v38_6: Path = concat_path(&(v36_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v38_7: Space = routine_6(c, &(v38_6), &v22_24_cursor, &(*s1));
              compose(&(v37_5),&(v38_7))
            };
            drop(v37_5);
            let v37_9: Space = intersect(&(*CONSTANT_2),&(v37_2));
            drop(v37_2);
            let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
            drop(v37_9);
            let v37_12: Space = if (&(v37_10)).is_empty() { Space::new() } else {
              let v39_6: Path = concat_path(&(v36_6),&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
              let v39_11: Space = routine_7(c, &(v39_6), &v22_24_cursor, &(*s1));
              drop(v39_6);
              compose(&(v37_10),&(v39_11))
            };
            drop(v37_10);
            let v37_13: Space = unite(&(v37_8),&(v37_12));
            join_wrapped_into(&mut v36_7_write,&((v37_13).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v36_7_write);
          compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = intersect(&(*CONSTANT_2),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (&(v35_10)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v34_6),&v22_24_cursor.path()[(v22_24_origin + 1)..(v22_24_origin + 2)]);
          let mut v40_11 = Space::new();
          let mut v40_11_write = v40_11.write_zipper();
          for v40_11_byte in v22_24_cursor.child_mask().iter() {
            v22_24_cursor.descend_to_existing_byte(v40_11_byte);
            {
            let v41_2: Space = singleton(&v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)]);
            let v41_3: Space = intersect(&(*CONSTANT_2),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_1),&(v41_4));
            drop(v41_4);
            let v41_7: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Space = routine_4(c, &v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)], &(v40_6), &v22_24_cursor, &(*s1));
              compose(&(v41_5),&(v42_6))
            };
            drop(v41_5);
            let v41_8: Space = intersect(&(*CONSTANT_2),&(v41_2));
            drop(v41_2);
            let v41_9: Space = if has_head(&(v41_8)) { singleton(&[]) } else { Space::new() };
            drop(v41_8);
            let v41_11: Space = if (&(v41_9)).is_empty() { Space::new() } else {
              let v43_10: Space = routine_5(c, &v22_24_cursor.path()[(v22_24_origin + 2)..(v22_24_origin + 3)], &(v40_6), &v22_24_cursor, &(*s1));
              compose(&(v41_9),&(v43_10))
            };
            drop(v41_9);
            let v41_12: Space = unite(&(v41_7),&(v41_11));
            join_wrapped_into(&mut v40_11_write,&((v41_12).read_zipper()),&[]);
            }
            v22_24_cursor.ascend(1);
          }
          drop(v40_11_write);
          drop(v40_6);
          compose(&(v35_10),&(v40_11))
        };
        drop(v35_10);
        let v35_13: Space = unite(&(v35_8),&(v35_12));
        join_wrapped_into(&mut v34_11_write,&((v35_13).read_zipper()),&[]);
        }
        v22_24_cursor.ascend(1);
      }
      drop(v34_11_write);
      drop(v34_6);
      compose(&(v23_10),&(v34_11))
    };
    drop(v23_10);
    let v23_13: Space = unite(&(v23_8),&(v23_12));
    join_wrapped_into(&mut v22_24_write,&((v23_13).read_zipper()),&[]);
    }
    v22_24_cursor.ascend(1);
  }
  drop(v22_24_cursor);
  drop(v22_24_write);
  (v22_24).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v44_24 = Space::new();
  let mut v44_24_write = v44_24.write_zipper();
  let mut v44_24_cursor = (*s0).read_zipper();
  let v44_24_origin = v44_24_cursor.path().len();
  for v44_24_byte in v44_24_cursor.child_mask().iter() {
    v44_24_cursor.descend_to_existing_byte(v44_24_byte);
    {
    let v45_2: Space = singleton(&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
    let v45_3: Space = intersect(&(*CONSTANT_2),&(v45_2));
    let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
    drop(v45_3);
    let v45_5: Space = subtract(&(*CONSTANT_1),&(v45_4));
    drop(v45_4);
    let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
      let mut v46_7 = Space::new();
      let mut v46_7_write = v46_7.write_zipper();
      for v46_7_byte in v44_24_cursor.child_mask().iter() {
        v44_24_cursor.descend_to_existing_byte(v46_7_byte);
        {
        let v47_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
        let v47_3: Space = intersect(&(*CONSTANT_2),&(v47_2));
        let v47_4: Space = if has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = subtract(&(*CONSTANT_1),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (&(v47_5)).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
          let mut v48_7 = Space::new();
          let mut v48_7_write = v48_7.write_zipper();
          for v48_7_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v48_7_byte);
            {
            let v49_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v49_3: Space = intersect(&(*CONSTANT_2),&(v49_2));
            let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
            drop(v49_3);
            let v49_5: Space = subtract(&(*CONSTANT_1),&(v49_4));
            drop(v49_4);
            let v49_8: Space = if (&(v49_5)).is_empty() { Space::new() } else {
              let v50_6: Path = concat_path(&(v48_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v50_7: Space = routine_6(c, &(v50_6), &v44_24_cursor, &(*s1));
              compose(&(v49_5),&(v50_7))
            };
            drop(v49_5);
            let v49_9: Space = intersect(&(*CONSTANT_2),&(v49_2));
            drop(v49_2);
            let v49_10: Space = if has_head(&(v49_9)) { singleton(&[]) } else { Space::new() };
            drop(v49_9);
            let v49_12: Space = if (&(v49_10)).is_empty() { Space::new() } else {
              let v51_6: Path = concat_path(&(v48_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v51_11: Space = routine_7(c, &(v51_6), &v44_24_cursor, &(*s1));
              drop(v51_6);
              compose(&(v49_10),&(v51_11))
            };
            drop(v49_10);
            let v49_13: Space = unite(&(v49_8),&(v49_12));
            join_wrapped_into(&mut v48_7_write,&((v49_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v48_7_write);
          compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = intersect(&(*CONSTANT_2),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (&(v47_10)).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v46_6),&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
          let mut v52_11 = Space::new();
          let mut v52_11_write = v52_11.write_zipper();
          for v52_11_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v52_11_byte);
            {
            let v53_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v53_3: Space = intersect(&(*CONSTANT_2),&(v53_2));
            let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
            drop(v53_3);
            let v53_5: Space = subtract(&(*CONSTANT_1),&(v53_4));
            drop(v53_4);
            let v53_8: Space = if (&(v53_5)).is_empty() { Space::new() } else {
              let v54_6: Path = concat_path(&(v52_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v54_7: Space = routine_6(c, &(v54_6), &v44_24_cursor, &(*s1));
              compose(&(v53_5),&(v54_7))
            };
            drop(v53_5);
            let v53_9: Space = intersect(&(*CONSTANT_2),&(v53_2));
            drop(v53_2);
            let v53_10: Space = if has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
            drop(v53_9);
            let v53_12: Space = if (&(v53_10)).is_empty() { Space::new() } else {
              let v55_6: Path = concat_path(&(v52_6),&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
              let v55_11: Space = routine_3(c, &(v55_6), &v44_24_cursor, &(*s1));
              drop(v55_6);
              compose(&(v53_10),&(v55_11))
            };
            drop(v53_10);
            let v53_13: Space = unite(&(v53_8),&(v53_12));
            join_wrapped_into(&mut v52_11_write,&((v53_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v52_11_write);
          drop(v52_6);
          compose(&(v47_10),&(v52_11))
        };
        drop(v47_10);
        let v47_13: Space = unite(&(v47_8),&(v47_12));
        join_wrapped_into(&mut v46_7_write,&((v47_13).read_zipper()),&[]);
        }
        v44_24_cursor.ascend(1);
      }
      drop(v46_7_write);
      compose(&(v45_5),&(v46_7))
    };
    drop(v45_5);
    let v45_9: Space = intersect(&(*CONSTANT_2),&(v45_2));
    drop(v45_2);
    let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
    drop(v45_9);
    let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&v44_24_cursor.path()[v44_24_origin..(v44_24_origin + 1)]);
      let mut v56_11 = Space::new();
      let mut v56_11_write = v56_11.write_zipper();
      for v56_11_byte in v44_24_cursor.child_mask().iter() {
        v44_24_cursor.descend_to_existing_byte(v56_11_byte);
        {
        let v57_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 2)]);
        let v57_3: Space = intersect(&(*CONSTANT_2),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_1),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (&(v57_5)).is_empty() { Space::new() } else {
          let mut v58_6 = Space::new();
          let mut v58_6_write = v58_6.write_zipper();
          for v58_6_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v58_6_byte);
            {
            let v59_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v59_3: Space = intersect(&(*CONSTANT_2),&(v59_2));
            let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
            drop(v59_3);
            let v59_5: Space = subtract(&(*CONSTANT_1),&(v59_4));
            drop(v59_4);
            let v59_8: Space = if (&(v59_5)).is_empty() { Space::new() } else {
              let v60_7: Space = routine_8(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v59_5),&(v60_7))
            };
            drop(v59_5);
            let v59_9: Space = intersect(&(*CONSTANT_2),&(v59_2));
            drop(v59_2);
            let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
            drop(v59_9);
            let v59_12: Space = if (&(v59_10)).is_empty() { Space::new() } else {
              let v61_11: Space = routine_9(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v59_10),&(v61_11))
            };
            drop(v59_10);
            let v59_13: Space = unite(&(v59_8),&(v59_12));
            join_wrapped_into(&mut v58_6_write,&((v59_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v58_6_write);
          compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = intersect(&(*CONSTANT_2),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (&(v57_9)).is_empty() { Space::new() } else {
          let mut v62_10 = Space::new();
          let mut v62_10_write = v62_10.write_zipper();
          for v62_10_byte in v44_24_cursor.child_mask().iter() {
            v44_24_cursor.descend_to_existing_byte(v62_10_byte);
            {
            let v63_2: Space = singleton(&v44_24_cursor.path()[(v44_24_origin + 2)..(v44_24_origin + 3)]);
            let v63_3: Space = intersect(&(*CONSTANT_2),&(v63_2));
            let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
            drop(v63_3);
            let v63_5: Space = subtract(&(*CONSTANT_1),&(v63_4));
            drop(v63_4);
            let v63_8: Space = if (&(v63_5)).is_empty() { Space::new() } else {
              let v64_7: Space = routine_8(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v63_5),&(v64_7))
            };
            drop(v63_5);
            let v63_9: Space = intersect(&(*CONSTANT_2),&(v63_2));
            drop(v63_2);
            let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
            drop(v63_9);
            let v63_12: Space = if (&(v63_10)).is_empty() { Space::new() } else {
              let v65_11: Space = routine_10(c, &v44_24_cursor.path()[(v44_24_origin + 1)..(v44_24_origin + 3)], &(v56_6), &v44_24_cursor, &(*s1));
              compose(&(v63_10),&(v65_11))
            };
            drop(v63_10);
            let v63_13: Space = unite(&(v63_8),&(v63_12));
            join_wrapped_into(&mut v62_10_write,&((v63_13).read_zipper()),&[]);
            }
            v44_24_cursor.ascend(1);
          }
          drop(v62_10_write);
          compose(&(v57_9),&(v62_10))
        };
        drop(v57_9);
        let v57_12: Space = unite(&(v57_7),&(v57_11));
        join_wrapped_into(&mut v56_11_write,&((v57_12).read_zipper()),&[]);
        }
        v44_24_cursor.ascend(1);
      }
      drop(v56_11_write);
      drop(v56_6);
      compose(&(v45_10),&(v56_11))
    };
    drop(v45_10);
    let v45_13: Space = unite(&(v45_8),&(v45_12));
    join_wrapped_into(&mut v44_24_write,&((v45_13).read_zipper()),&[]);
    }
    v44_24_cursor.ascend(1);
  }
  drop(v44_24_cursor);
  drop(v44_24_write);
  (v44_24).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v66_26 = Space::new();
  let mut v66_26_write = v66_26.write_zipper();
  let mut v66_26_cursor = (*s0).read_zipper();
  let v66_26_origin = v66_26_cursor.path().len();
  for v66_26_byte in v66_26_cursor.child_mask().iter() {
    v66_26_cursor.descend_to_existing_byte(v66_26_byte);
    {
    let v67_2: Space = singleton(&v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 1)]);
    let v67_3: Space = intersect(&(*CONSTANT_2),&(v67_2));
    let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
    drop(v67_3);
    let v67_5: Space = subtract(&(*CONSTANT_1),&(v67_4));
    drop(v67_4);
    let v67_7: Space = if (&(v67_5)).is_empty() { Space::new() } else {
      let mut v68_6 = Space::new();
      let mut v68_6_write = v68_6.write_zipper();
      for v68_6_byte in v66_26_cursor.child_mask().iter() {
        v66_26_cursor.descend_to_existing_byte(v68_6_byte);
        {
        let v69_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
        let v69_3: Space = intersect(&(*CONSTANT_2),&(v69_2));
        let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
        drop(v69_3);
        let v69_5: Space = subtract(&(*CONSTANT_1),&(v69_4));
        drop(v69_4);
        let v69_8: Space = if (&(v69_5)).is_empty() { Space::new() } else {
          let mut v70_7 = Space::new();
          let mut v70_7_write = v70_7.write_zipper();
          for v70_7_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v70_7_byte);
            {
            let v71_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v71_3: Space = intersect(&(*CONSTANT_2),&(v71_2));
            let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
            drop(v71_3);
            let v71_5: Space = subtract(&(*CONSTANT_1),&(v71_4));
            drop(v71_4);
            let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
              let v72_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v71_5),&(v72_7))
            };
            drop(v71_5);
            let v71_9: Space = intersect(&(*CONSTANT_2),&(v71_2));
            drop(v71_2);
            let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
            drop(v71_9);
            let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
              let v73_11: Space = routine_12(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v71_10),&(v73_11))
            };
            drop(v71_10);
            let v71_13: Space = unite(&(v71_8),&(v71_12));
            join_wrapped_into(&mut v70_7_write,&((v71_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v70_7_write);
          compose(&(v69_5),&(v70_7))
        };
        drop(v69_5);
        let v69_9: Space = intersect(&(*CONSTANT_2),&(v69_2));
        drop(v69_2);
        let v69_10: Space = if has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
        drop(v69_9);
        let v69_12: Space = if (&(v69_10)).is_empty() { Space::new() } else {
          let mut v74_11 = Space::new();
          let mut v74_11_write = v74_11.write_zipper();
          for v74_11_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v74_11_byte);
            {
            let v75_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v75_3: Space = intersect(&(*CONSTANT_2),&(v75_2));
            let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
            drop(v75_3);
            let v75_5: Space = subtract(&(*CONSTANT_1),&(v75_4));
            drop(v75_4);
            let v75_8: Space = if (&(v75_5)).is_empty() { Space::new() } else {
              let v76_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v75_5),&(v76_7))
            };
            drop(v75_5);
            let v75_9: Space = intersect(&(*CONSTANT_2),&(v75_2));
            drop(v75_2);
            let v75_10: Space = if has_head(&(v75_9)) { singleton(&[]) } else { Space::new() };
            drop(v75_9);
            let v75_12: Space = if (&(v75_10)).is_empty() { Space::new() } else {
              let v77_11: Space = routine_10(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v75_10),&(v77_11))
            };
            drop(v75_10);
            let v75_13: Space = unite(&(v75_8),&(v75_12));
            join_wrapped_into(&mut v74_11_write,&((v75_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v74_11_write);
          compose(&(v69_10),&(v74_11))
        };
        drop(v69_10);
        let v69_13: Space = unite(&(v69_8),&(v69_12));
        join_wrapped_into(&mut v68_6_write,&((v69_13).read_zipper()),&[]);
        }
        v66_26_cursor.ascend(1);
      }
      drop(v68_6_write);
      compose(&(v67_5),&(v68_6))
    };
    drop(v67_5);
    let v67_8: Space = intersect(&(*CONSTANT_2),&(v67_2));
    drop(v67_2);
    let v67_9: Space = if has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
    drop(v67_8);
    let v67_12: Space = if (&(v67_9)).is_empty() { Space::new() } else {
      let mut v78_11 = Space::new();
      let mut v78_11_write = v78_11.write_zipper();
      for v78_11_byte in v66_26_cursor.child_mask().iter() {
        v66_26_cursor.descend_to_existing_byte(v78_11_byte);
        {
        let v79_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
        let v79_3: Space = intersect(&(*CONSTANT_2),&(v79_2));
        let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
        drop(v79_3);
        let v79_5: Space = subtract(&(*CONSTANT_1),&(v79_4));
        drop(v79_4);
        let v79_8: Space = if (&(v79_5)).is_empty() { Space::new() } else {
          let mut v80_7 = Space::new();
          let mut v80_7_write = v80_7.write_zipper();
          for v80_7_byte in v66_26_cursor.child_mask().iter() {
            v66_26_cursor.descend_to_existing_byte(v80_7_byte);
            {
            let v81_2: Space = singleton(&v66_26_cursor.path()[(v66_26_origin + 2)..(v66_26_origin + 3)]);
            let v81_3: Space = intersect(&(*CONSTANT_2),&(v81_2));
            let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
            drop(v81_3);
            let v81_5: Space = subtract(&(*CONSTANT_1),&(v81_4));
            drop(v81_4);
            let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
              let v82_7: Space = routine_11(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v81_5),&(v82_7))
            };
            drop(v81_5);
            let v81_9: Space = intersect(&(*CONSTANT_2),&(v81_2));
            drop(v81_2);
            let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
            drop(v81_9);
            let v81_12: Space = if (&(v81_10)).is_empty() { Space::new() } else {
              let v83_11: Space = routine_12(c, &v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 3)], &(*p0), &v66_26_cursor, &(*s1));
              compose(&(v81_10),&(v83_11))
            };
            drop(v81_10);
            let v81_13: Space = unite(&(v81_8),&(v81_12));
            join_wrapped_into(&mut v80_7_write,&((v81_13).read_zipper()),&[]);
            }
            v66_26_cursor.ascend(1);
          }
          drop(v80_7_write);
          compose(&(v79_5),&(v80_7))
        };
        drop(v79_5);
        let v79_9: Space = intersect(&(*CONSTANT_2),&(v79_2));
        drop(v79_2);
        let v79_10: Space = if has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
        drop(v79_9);
        let v79_13: Space = if (&(v79_10)).is_empty() { Space::new() } else {
          let mut v84_12 = Space::new();
          let mut v84_12_write = v84_12.write_zipper();
          let mut v84_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&v66_26_cursor.path()[v66_26_origin..(v66_26_origin + 1)]),&v66_26_cursor.path()[(v66_26_origin + 1)..(v66_26_origin + 2)]);
          let v84_12_origin = v84_12_cursor.path().len();
          for v84_12_byte in v84_12_cursor.child_mask().iter() {
            v84_12_cursor.descend_to_existing_byte(v84_12_byte);
            {
            let v85_2: Space = singleton(&v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)]);
            let v85_3: Space = intersect(&(*CONSTANT_2),&(v85_2));
            let v85_4: Space = if has_head(&(v85_3)) { singleton(&[]) } else { Space::new() };
            drop(v85_3);
            let v85_5: Space = subtract(&(*CONSTANT_1),&(v85_4));
            drop(v85_4);
            let v85_7: Space = if (&(v85_5)).is_empty() { Space::new() } else {
              let v86_6: Space = routine_13(c, &v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)], &(*p0), &v84_12_cursor);
              compose(&(v85_5),&(v86_6))
            };
            drop(v85_5);
            let v85_8: Space = intersect(&(*CONSTANT_2),&(v85_2));
            drop(v85_2);
            let v85_9: Space = if has_head(&(v85_8)) { singleton(&[]) } else { Space::new() };
            drop(v85_8);
            let v85_11: Space = if (&(v85_9)).is_empty() { Space::new() } else {
              let v87_10: Space = routine_14(c, &v84_12_cursor.path()[v84_12_origin..(v84_12_origin + 1)], &(*p0), &v84_12_cursor);
              compose(&(v85_9),&(v87_10))
            };
            drop(v85_9);
            let v85_12: Space = unite(&(v85_7),&(v85_11));
            join_wrapped_into(&mut v84_12_write,&((v85_12).read_zipper()),&[]);
            }
            v84_12_cursor.ascend(1);
          }
          drop(v84_12_cursor);
          drop(v84_12_write);
          compose(&(v79_10),&(v84_12))
        };
        drop(v79_10);
        let v79_14: Space = unite(&(v79_8),&(v79_13));
        join_wrapped_into(&mut v78_11_write,&((v79_14).read_zipper()),&[]);
        }
        v66_26_cursor.ascend(1);
      }
      drop(v78_11_write);
      compose(&(v67_9),&(v78_11))
    };
    drop(v67_9);
    let v67_13: Space = unite(&(v67_7),&(v67_12));
    join_wrapped_into(&mut v66_26_write,&((v67_13).read_zipper()),&[]);
    }
    v66_26_cursor.ascend(1);
  }
  drop(v66_26_cursor);
  drop(v66_26_write);
  (v66_26).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v88_28 = Space::new();
  let mut v88_28_write = v88_28.write_zipper();
  let mut v88_28_cursor = (*s0).read_zipper();
  let v88_28_origin = v88_28_cursor.path().len();
  for v88_28_byte in v88_28_cursor.child_mask().iter() {
    v88_28_cursor.descend_to_existing_byte(v88_28_byte);
    {
    let v89_2: Space = singleton(&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
    let v89_3: Space = intersect(&(*CONSTANT_2),&(v89_2));
    let v89_4: Space = if has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
    drop(v89_3);
    let v89_5: Space = subtract(&(*CONSTANT_1),&(v89_4));
    drop(v89_4);
    let v89_8: Space = if (&(v89_5)).is_empty() { Space::new() } else {
      let v90_6: Path = concat_path(&(*p0),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
      let mut v90_7 = Space::new();
      let mut v90_7_write = v90_7.write_zipper();
      for v90_7_byte in v88_28_cursor.child_mask().iter() {
        v88_28_cursor.descend_to_existing_byte(v90_7_byte);
        {
        let v91_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
        let v91_3: Space = intersect(&(*CONSTANT_2),&(v91_2));
        let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
        drop(v91_3);
        let v91_5: Space = subtract(&(*CONSTANT_1),&(v91_4));
        drop(v91_4);
        let v91_8: Space = if (&(v91_5)).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v90_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v92_7 = Space::new();
          let mut v92_7_write = v92_7.write_zipper();
          for v92_7_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v92_7_byte);
            {
            let v93_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v93_3: Space = intersect(&(*CONSTANT_2),&(v93_2));
            let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
            drop(v93_3);
            let v93_5: Space = subtract(&(*CONSTANT_1),&(v93_4));
            drop(v93_4);
            let v93_8: Space = if (&(v93_5)).is_empty() { Space::new() } else {
              let v94_6: Path = concat_path(&(v92_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v94_7: Space = routine_15(c, &(v94_6), &(*p1), &v88_28_cursor, &(*s1));
              compose(&(v93_5),&(v94_7))
            };
            drop(v93_5);
            let v93_9: Space = intersect(&(*CONSTANT_2),&(v93_2));
            drop(v93_2);
            let v93_10: Space = if has_head(&(v93_9)) { singleton(&[]) } else { Space::new() };
            drop(v93_9);
            let v93_12: Space = if (&(v93_10)).is_empty() { Space::new() } else {
              let v95_6: Path = concat_path(&(v92_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v95_11: Space = routine_16(c, &(v95_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v95_6);
              compose(&(v93_10),&(v95_11))
            };
            drop(v93_10);
            let v93_13: Space = unite(&(v93_8),&(v93_12));
            join_wrapped_into(&mut v92_7_write,&((v93_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v92_7_write);
          compose(&(v91_5),&(v92_7))
        };
        drop(v91_5);
        let v91_9: Space = intersect(&(*CONSTANT_2),&(v91_2));
        drop(v91_2);
        let v91_10: Space = if has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
        drop(v91_9);
        let v91_12: Space = if (&(v91_10)).is_empty() { Space::new() } else {
          let v96_6: Path = concat_path(&(v90_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v96_11 = Space::new();
          let mut v96_11_write = v96_11.write_zipper();
          for v96_11_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v96_11_byte);
            {
            let v97_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v97_3: Space = intersect(&(*CONSTANT_2),&(v97_2));
            let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
            drop(v97_3);
            let v97_5: Space = subtract(&(*CONSTANT_1),&(v97_4));
            drop(v97_4);
            let v97_8: Space = if (&(v97_5)).is_empty() { Space::new() } else {
              let v98_6: Path = concat_path(&(v96_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v98_7: Space = routine_15(c, &(v98_6), &(*p1), &v88_28_cursor, &(*s1));
              compose(&(v97_5),&(v98_7))
            };
            drop(v97_5);
            let v97_9: Space = intersect(&(*CONSTANT_2),&(v97_2));
            drop(v97_2);
            let v97_10: Space = if has_head(&(v97_9)) { singleton(&[]) } else { Space::new() };
            drop(v97_9);
            let v97_12: Space = if (&(v97_10)).is_empty() { Space::new() } else {
              let v99_6: Path = concat_path(&(v96_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v99_11: Space = routine_10(c, &(v99_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v99_6);
              compose(&(v97_10),&(v99_11))
            };
            drop(v97_10);
            let v97_13: Space = unite(&(v97_8),&(v97_12));
            join_wrapped_into(&mut v96_11_write,&((v97_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v96_11_write);
          drop(v96_6);
          compose(&(v91_10),&(v96_11))
        };
        drop(v91_10);
        let v91_13: Space = unite(&(v91_8),&(v91_12));
        join_wrapped_into(&mut v90_7_write,&((v91_13).read_zipper()),&[]);
        }
        v88_28_cursor.ascend(1);
      }
      drop(v90_7_write);
      compose(&(v89_5),&(v90_7))
    };
    drop(v89_5);
    let v89_9: Space = intersect(&(*CONSTANT_2),&(v89_2));
    drop(v89_2);
    let v89_10: Space = if has_head(&(v89_9)) { singleton(&[]) } else { Space::new() };
    drop(v89_9);
    let v89_13: Space = if (&(v89_10)).is_empty() { Space::new() } else {
      let v100_6: Path = concat_path(&(*p0),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]);
      let mut v100_12 = Space::new();
      let mut v100_12_write = v100_12.write_zipper();
      for v100_12_byte in v88_28_cursor.child_mask().iter() {
        v88_28_cursor.descend_to_existing_byte(v100_12_byte);
        {
        let v101_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
        let v101_3: Space = intersect(&(*CONSTANT_2),&(v101_2));
        let v101_4: Space = if has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
        drop(v101_3);
        let v101_5: Space = subtract(&(*CONSTANT_1),&(v101_4));
        drop(v101_4);
        let v101_8: Space = if (&(v101_5)).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v100_6),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let mut v102_7 = Space::new();
          let mut v102_7_write = v102_7.write_zipper();
          for v102_7_byte in v88_28_cursor.child_mask().iter() {
            v88_28_cursor.descend_to_existing_byte(v102_7_byte);
            {
            let v103_2: Space = singleton(&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
            let v103_3: Space = intersect(&(*CONSTANT_2),&(v103_2));
            let v103_4: Space = if has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
            drop(v103_3);
            let v103_5: Space = subtract(&(*CONSTANT_1),&(v103_4));
            drop(v103_4);
            let v103_8: Space = if (&(v103_5)).is_empty() { Space::new() } else {
              let v104_6: Path = concat_path(&(v102_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v104_7: Space = routine_15(c, &(v104_6), &(*p1), &v88_28_cursor, &(*s1));
              compose(&(v103_5),&(v104_7))
            };
            drop(v103_5);
            let v103_9: Space = intersect(&(*CONSTANT_2),&(v103_2));
            drop(v103_2);
            let v103_10: Space = if has_head(&(v103_9)) { singleton(&[]) } else { Space::new() };
            drop(v103_9);
            let v103_12: Space = if (&(v103_10)).is_empty() { Space::new() } else {
              let v105_6: Path = concat_path(&(v102_6),&v88_28_cursor.path()[(v88_28_origin + 2)..(v88_28_origin + 3)]);
              let v105_11: Space = routine_16(c, &(v105_6), &(*p1), &v88_28_cursor, &(*s1));
              drop(v105_6);
              compose(&(v103_10),&(v105_11))
            };
            drop(v103_10);
            let v103_13: Space = unite(&(v103_8),&(v103_12));
            join_wrapped_into(&mut v102_7_write,&((v103_13).read_zipper()),&[]);
            }
            v88_28_cursor.ascend(1);
          }
          drop(v102_7_write);
          drop(v102_6);
          compose(&(v101_5),&(v102_7))
        };
        drop(v101_5);
        let v101_9: Space = intersect(&(*CONSTANT_2),&(v101_2));
        drop(v101_2);
        let v101_10: Space = if has_head(&(v101_9)) { singleton(&[]) } else { Space::new() };
        drop(v101_9);
        let v101_13: Space = if (&(v101_10)).is_empty() { Space::new() } else {
          let mut v106_12 = Space::new();
          let mut v106_12_write = v106_12.write_zipper();
          let mut v106_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v88_28_cursor.path()[v88_28_origin..(v88_28_origin + 1)]),&v88_28_cursor.path()[(v88_28_origin + 1)..(v88_28_origin + 2)]);
          let v106_12_origin = v106_12_cursor.path().len();
          for v106_12_byte in v106_12_cursor.child_mask().iter() {
            v106_12_cursor.descend_to_existing_byte(v106_12_byte);
            {
            let v107_2: Space = singleton(&v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)]);
            let v107_3: Space = intersect(&(*CONSTANT_2),&(v107_2));
            let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
            drop(v107_3);
            let v107_5: Space = subtract(&(*CONSTANT_1),&(v107_4));
            drop(v107_4);
            let v107_7: Space = if (&(v107_5)).is_empty() { Space::new() } else {
              let v108_6: Space = routine_13(c, &v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)], &(*p1), &v106_12_cursor);
              compose(&(v107_5),&(v108_6))
            };
            drop(v107_5);
            let v107_8: Space = intersect(&(*CONSTANT_2),&(v107_2));
            drop(v107_2);
            let v107_9: Space = if has_head(&(v107_8)) { singleton(&[]) } else { Space::new() };
            drop(v107_8);
            let v107_11: Space = if (&(v107_9)).is_empty() { Space::new() } else {
              let v109_10: Space = routine_14(c, &v106_12_cursor.path()[v106_12_origin..(v106_12_origin + 1)], &(*p1), &v106_12_cursor);
              compose(&(v107_9),&(v109_10))
            };
            drop(v107_9);
            let v107_12: Space = unite(&(v107_7),&(v107_11));
            join_wrapped_into(&mut v106_12_write,&((v107_12).read_zipper()),&[]);
            }
            v106_12_cursor.ascend(1);
          }
          drop(v106_12_cursor);
          drop(v106_12_write);
          compose(&(v101_10),&(v106_12))
        };
        drop(v101_10);
        let v101_14: Space = unite(&(v101_8),&(v101_13));
        join_wrapped_into(&mut v100_12_write,&((v101_14).read_zipper()),&[]);
        }
        v88_28_cursor.ascend(1);
      }
      drop(v100_12_write);
      drop(v100_6);
      compose(&(v89_10),&(v100_12))
    };
    drop(v89_10);
    let v89_14: Space = unite(&(v89_8),&(v89_13));
    join_wrapped_into(&mut v88_28_write,&((v89_14).read_zipper()),&[]);
    }
    v88_28_cursor.ascend(1);
  }
  drop(v88_28_cursor);
  drop(v88_28_write);
  (v88_28).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v110_28 = Space::new();
  let mut v110_28_write = v110_28.write_zipper();
  let mut v110_28_cursor = (*s0).read_zipper();
  let v110_28_origin = v110_28_cursor.path().len();
  for v110_28_byte in v110_28_cursor.child_mask().iter() {
    v110_28_cursor.descend_to_existing_byte(v110_28_byte);
    {
    let v111_2: Space = singleton(&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
    let v111_3: Space = intersect(&(*CONSTANT_2),&(v111_2));
    let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = subtract(&(*CONSTANT_1),&(v111_4));
    drop(v111_4);
    let v111_8: Space = if (&(v111_5)).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
      let mut v112_7 = Space::new();
      let mut v112_7_write = v112_7.write_zipper();
      for v112_7_byte in v110_28_cursor.child_mask().iter() {
        v110_28_cursor.descend_to_existing_byte(v112_7_byte);
        {
        let v113_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
        let v113_3: Space = intersect(&(*CONSTANT_2),&(v113_2));
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = subtract(&(*CONSTANT_1),&(v113_4));
        drop(v113_4);
        let v113_8: Space = if (&(v113_5)).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v112_6),&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
          let mut v114_7 = Space::new();
          let mut v114_7_write = v114_7.write_zipper();
          for v114_7_byte in v110_28_cursor.child_mask().iter() {
            v110_28_cursor.descend_to_existing_byte(v114_7_byte);
            {
            let v115_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
            let v115_3: Space = intersect(&(*CONSTANT_2),&(v115_2));
            let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
            drop(v115_3);
            let v115_5: Space = subtract(&(*CONSTANT_1),&(v115_4));
            drop(v115_4);
            let v115_8: Space = if (&(v115_5)).is_empty() { Space::new() } else {
              let v116_6: Path = concat_path(&(v114_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v116_7: Space = routine_15(c, &(v116_6), &(*p1), &v110_28_cursor, &(*s1));
              compose(&(v115_5),&(v116_7))
            };
            drop(v115_5);
            let v115_9: Space = intersect(&(*CONSTANT_2),&(v115_2));
            drop(v115_2);
            let v115_10: Space = if has_head(&(v115_9)) { singleton(&[]) } else { Space::new() };
            drop(v115_9);
            let v115_12: Space = if (&(v115_10)).is_empty() { Space::new() } else {
              let v117_6: Path = concat_path(&(v114_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v117_11: Space = routine_16(c, &(v117_6), &(*p1), &v110_28_cursor, &(*s1));
              drop(v117_6);
              compose(&(v115_10),&(v117_11))
            };
            drop(v115_10);
            let v115_13: Space = unite(&(v115_8),&(v115_12));
            join_wrapped_into(&mut v114_7_write,&((v115_13).read_zipper()),&[]);
            }
            v110_28_cursor.ascend(1);
          }
          drop(v114_7_write);
          compose(&(v113_5),&(v114_7))
        };
        drop(v113_5);
        let v113_9: Space = intersect(&(*CONSTANT_2),&(v113_2));
        drop(v113_2);
        let v113_10: Space = if has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
        drop(v113_9);
        let v113_12: Space = if (&(v113_10)).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v112_6),&v110_28_cursor.path()[(v110_28_origin + 1)..(v110_28_origin + 2)]);
          let mut v118_11 = Space::new();
          let mut v118_11_write = v118_11.write_zipper();
          for v118_11_byte in v110_28_cursor.child_mask().iter() {
            v110_28_cursor.descend_to_existing_byte(v118_11_byte);
            {
            let v119_2: Space = singleton(&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
            let v119_3: Space = intersect(&(*CONSTANT_2),&(v119_2));
            let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
            drop(v119_3);
            let v119_5: Space = subtract(&(*CONSTANT_1),&(v119_4));
            drop(v119_4);
            let v119_8: Space = if (&(v119_5)).is_empty() { Space::new() } else {
              let v120_6: Path = concat_path(&(v118_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v120_7: Space = routine_15(c, &(v120_6), &(*p1), &v110_28_cursor, &(*s1));
              compose(&(v119_5),&(v120_7))
            };
            drop(v119_5);
            let v119_9: Space = intersect(&(*CONSTANT_2),&(v119_2));
            drop(v119_2);
            let v119_10: Space = if has_head(&(v119_9)) { singleton(&[]) } else { Space::new() };
            drop(v119_9);
            let v119_12: Space = if (&(v119_10)).is_empty() { Space::new() } else {
              let v121_6: Path = concat_path(&(v118_6),&v110_28_cursor.path()[(v110_28_origin + 2)..(v110_28_origin + 3)]);
              let v121_11: Space = routine_10(c, &(v121_6), &(*p1), &v110_28_cursor, &(*s1));
              drop(v121_6);
              compose(&(v119_10),&(v121_11))
            };
            drop(v119_10);
            let v119_13: Space = unite(&(v119_8),&(v119_12));
            join_wrapped_into(&mut v118_11_write,&((v119_13).read_zipper()),&[]);
            }
            v110_28_cursor.ascend(1);
          }
          drop(v118_11_write);
          drop(v118_6);
          compose(&(v113_10),&(v118_11))
        };
        drop(v113_10);
        let v113_13: Space = unite(&(v113_8),&(v113_12));
        join_wrapped_into(&mut v112_7_write,&((v113_13).read_zipper()),&[]);
        }
        v110_28_cursor.ascend(1);
      }
      drop(v112_7_write);
      drop(v112_6);
      compose(&(v111_5),&(v112_7))
    };
    drop(v111_5);
    let v111_9: Space = intersect(&(*CONSTANT_2),&(v111_2));
    drop(v111_2);
    let v111_10: Space = if has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
    drop(v111_9);
    let v111_13: Space = if (&(v111_10)).is_empty() { Space::new() } else {
      let mut v122_12 = Space::new();
      let mut v122_12_write = v122_12.write_zipper();
      let mut v122_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v110_28_cursor.path()[v110_28_origin..(v110_28_origin + 1)]);
      let v122_12_origin = v122_12_cursor.path().len();
      for v122_12_byte in v122_12_cursor.child_mask().iter() {
        v122_12_cursor.descend_to_existing_byte(v122_12_byte);
        {
        let v123_2: Space = singleton(&v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 1)]);
        let v123_3: Space = intersect(&(*CONSTANT_2),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_1),&(v123_4));
        drop(v123_4);
        let v123_7: Space = if (&(v123_5)).is_empty() { Space::new() } else {
          let mut v124_6 = Space::new();
          let mut v124_6_write = v124_6.write_zipper();
          for v124_6_byte in v122_12_cursor.child_mask().iter() {
            v122_12_cursor.descend_to_existing_byte(v124_6_byte);
            {
            let v125_2: Space = singleton(&v122_12_cursor.path()[(v122_12_origin + 1)..(v122_12_origin + 2)]);
            let v125_3: Space = intersect(&(*CONSTANT_2),&(v125_2));
            let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = subtract(&(*CONSTANT_1),&(v125_4));
            drop(v125_4);
            let v125_8: Space = if (&(v125_5)).is_empty() { Space::new() } else {
              let v126_7: Space = routine_17(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              compose(&(v125_5),&(v126_7))
            };
            drop(v125_5);
            let v125_9: Space = intersect(&(*CONSTANT_2),&(v125_2));
            drop(v125_2);
            let v125_10: Space = if has_head(&(v125_9)) { singleton(&[]) } else { Space::new() };
            drop(v125_9);
            let v125_12: Space = if (&(v125_10)).is_empty() { Space::new() } else {
              let v127_11: Space = routine_18(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              compose(&(v125_10),&(v127_11))
            };
            drop(v125_10);
            let v125_13: Space = unite(&(v125_8),&(v125_12));
            join_wrapped_into(&mut v124_6_write,&((v125_13).read_zipper()),&[]);
            }
            v122_12_cursor.ascend(1);
          }
          drop(v124_6_write);
          compose(&(v123_5),&(v124_6))
        };
        drop(v123_5);
        let v123_8: Space = intersect(&(*CONSTANT_2),&(v123_2));
        drop(v123_2);
        let v123_9: Space = if has_head(&(v123_8)) { singleton(&[]) } else { Space::new() };
        drop(v123_8);
        let v123_11: Space = if (&(v123_9)).is_empty() { Space::new() } else {
          let mut v128_10 = Space::new();
          let mut v128_10_write = v128_10.write_zipper();
          for v128_10_byte in v122_12_cursor.child_mask().iter() {
            v122_12_cursor.descend_to_existing_byte(v128_10_byte);
            {
            let v129_2: Space = singleton(&v122_12_cursor.path()[(v122_12_origin + 1)..(v122_12_origin + 2)]);
            let v129_3: Space = intersect(&(*CONSTANT_2),&(v129_2));
            let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
            drop(v129_3);
            let v129_5: Space = subtract(&(*CONSTANT_1),&(v129_4));
            drop(v129_4);
            let v129_8: Space = if (&(v129_5)).is_empty() { Space::new() } else {
              let v130_7: Space = routine_17(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              compose(&(v129_5),&(v130_7))
            };
            drop(v129_5);
            let v129_9: Space = intersect(&(*CONSTANT_2),&(v129_2));
            drop(v129_2);
            let v129_10: Space = if has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
            drop(v129_9);
            let v129_12: Space = if (&(v129_10)).is_empty() { Space::new() } else {
              let v131_11: Space = routine_19(c, &v122_12_cursor.path()[v122_12_origin..(v122_12_origin + 2)], &(*p1), &v122_12_cursor);
              compose(&(v129_10),&(v131_11))
            };
            drop(v129_10);
            let v129_13: Space = unite(&(v129_8),&(v129_12));
            join_wrapped_into(&mut v128_10_write,&((v129_13).read_zipper()),&[]);
            }
            v122_12_cursor.ascend(1);
          }
          drop(v128_10_write);
          compose(&(v123_9),&(v128_10))
        };
        drop(v123_9);
        let v123_12: Space = unite(&(v123_7),&(v123_11));
        join_wrapped_into(&mut v122_12_write,&((v123_12).read_zipper()),&[]);
        }
        v122_12_cursor.ascend(1);
      }
      drop(v122_12_cursor);
      drop(v122_12_write);
      compose(&(v111_10),&(v122_12))
    };
    drop(v111_10);
    let v111_14: Space = unite(&(v111_8),&(v111_13));
    join_wrapped_into(&mut v110_28_write,&((v111_14).read_zipper()),&[]);
    }
    v110_28_cursor.ascend(1);
  }
  drop(v110_28_cursor);
  drop(v110_28_write);
  (v110_28).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v132_24 = Space::new();
  let mut v132_24_write = v132_24.write_zipper();
  let mut v132_24_cursor = (*s0).read_zipper();
  let v132_24_origin = v132_24_cursor.path().len();
  for v132_24_byte in v132_24_cursor.child_mask().iter() {
    v132_24_cursor.descend_to_existing_byte(v132_24_byte);
    {
    let v133_2: Space = singleton(&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
    let v133_3: Space = intersect(&(*CONSTANT_2),&(v133_2));
    let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
    drop(v133_3);
    let v133_5: Space = subtract(&(*CONSTANT_1),&(v133_4));
    drop(v133_4);
    let v133_8: Space = if (&(v133_5)).is_empty() { Space::new() } else {
      let v134_6: Path = concat_path(&(*p0),&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
      let mut v134_7 = Space::new();
      let mut v134_7_write = v134_7.write_zipper();
      for v134_7_byte in v132_24_cursor.child_mask().iter() {
        v132_24_cursor.descend_to_existing_byte(v134_7_byte);
        {
        let v135_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
        let v135_3: Space = intersect(&(*CONSTANT_2),&(v135_2));
        let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
        drop(v135_3);
        let v135_5: Space = subtract(&(*CONSTANT_1),&(v135_4));
        drop(v135_4);
        let v135_8: Space = if (&(v135_5)).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v134_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v136_7 = Space::new();
          let mut v136_7_write = v136_7.write_zipper();
          for v136_7_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v136_7_byte);
            {
            let v137_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v137_3: Space = intersect(&(*CONSTANT_2),&(v137_2));
            let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
            drop(v137_3);
            let v137_5: Space = subtract(&(*CONSTANT_1),&(v137_4));
            drop(v137_4);
            let v137_8: Space = if (&(v137_5)).is_empty() { Space::new() } else {
              let v138_6: Path = concat_path(&(v136_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v138_7: Space = routine_20(c, &(v138_6), &v132_24_cursor, &(*s1));
              compose(&(v137_5),&(v138_7))
            };
            drop(v137_5);
            let v137_9: Space = intersect(&(*CONSTANT_2),&(v137_2));
            drop(v137_2);
            let v137_10: Space = if has_head(&(v137_9)) { singleton(&[]) } else { Space::new() };
            drop(v137_9);
            let v137_12: Space = if (&(v137_10)).is_empty() { Space::new() } else {
              let v139_6: Path = concat_path(&(v136_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v139_11: Space = routine_21(c, &(v139_6), &v132_24_cursor, &(*s1));
              drop(v139_6);
              compose(&(v137_10),&(v139_11))
            };
            drop(v137_10);
            let v137_13: Space = unite(&(v137_8),&(v137_12));
            join_wrapped_into(&mut v136_7_write,&((v137_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v136_7_write);
          compose(&(v135_5),&(v136_7))
        };
        drop(v135_5);
        let v135_9: Space = intersect(&(*CONSTANT_2),&(v135_2));
        drop(v135_2);
        let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
        drop(v135_9);
        let v135_12: Space = if (&(v135_10)).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v134_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v140_11 = Space::new();
          let mut v140_11_write = v140_11.write_zipper();
          for v140_11_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v140_11_byte);
            {
            let v141_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v141_3: Space = intersect(&(*CONSTANT_2),&(v141_2));
            let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
            drop(v141_3);
            let v141_5: Space = subtract(&(*CONSTANT_1),&(v141_4));
            drop(v141_4);
            let v141_8: Space = if (&(v141_5)).is_empty() { Space::new() } else {
              let v142_6: Path = concat_path(&(v140_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v142_7: Space = routine_20(c, &(v142_6), &v132_24_cursor, &(*s1));
              compose(&(v141_5),&(v142_7))
            };
            drop(v141_5);
            let v141_9: Space = intersect(&(*CONSTANT_2),&(v141_2));
            drop(v141_2);
            let v141_10: Space = if has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
            drop(v141_9);
            let v141_12: Space = if (&(v141_10)).is_empty() { Space::new() } else {
              let v143_6: Path = concat_path(&(v140_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v143_11: Space = routine_3(c, &(v143_6), &v132_24_cursor, &(*s1));
              drop(v143_6);
              compose(&(v141_10),&(v143_11))
            };
            drop(v141_10);
            let v141_13: Space = unite(&(v141_8),&(v141_12));
            join_wrapped_into(&mut v140_11_write,&((v141_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v140_11_write);
          drop(v140_6);
          compose(&(v135_10),&(v140_11))
        };
        drop(v135_10);
        let v135_13: Space = unite(&(v135_8),&(v135_12));
        join_wrapped_into(&mut v134_7_write,&((v135_13).read_zipper()),&[]);
        }
        v132_24_cursor.ascend(1);
      }
      drop(v134_7_write);
      compose(&(v133_5),&(v134_7))
    };
    drop(v133_5);
    let v133_9: Space = intersect(&(*CONSTANT_2),&(v133_2));
    drop(v133_2);
    let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
    drop(v133_9);
    let v133_12: Space = if (&(v133_10)).is_empty() { Space::new() } else {
      let v144_6: Path = concat_path(&(*p0),&v132_24_cursor.path()[v132_24_origin..(v132_24_origin + 1)]);
      let mut v144_11 = Space::new();
      let mut v144_11_write = v144_11.write_zipper();
      for v144_11_byte in v132_24_cursor.child_mask().iter() {
        v132_24_cursor.descend_to_existing_byte(v144_11_byte);
        {
        let v145_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
        let v145_3: Space = intersect(&(*CONSTANT_2),&(v145_2));
        let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
        drop(v145_3);
        let v145_5: Space = subtract(&(*CONSTANT_1),&(v145_4));
        drop(v145_4);
        let v145_8: Space = if (&(v145_5)).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v144_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v146_7 = Space::new();
          let mut v146_7_write = v146_7.write_zipper();
          for v146_7_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v146_7_byte);
            {
            let v147_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v147_3: Space = intersect(&(*CONSTANT_2),&(v147_2));
            let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
            drop(v147_3);
            let v147_5: Space = subtract(&(*CONSTANT_1),&(v147_4));
            drop(v147_4);
            let v147_8: Space = if (&(v147_5)).is_empty() { Space::new() } else {
              let v148_6: Path = concat_path(&(v146_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v148_7: Space = routine_20(c, &(v148_6), &v132_24_cursor, &(*s1));
              compose(&(v147_5),&(v148_7))
            };
            drop(v147_5);
            let v147_9: Space = intersect(&(*CONSTANT_2),&(v147_2));
            drop(v147_2);
            let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
            drop(v147_9);
            let v147_12: Space = if (&(v147_10)).is_empty() { Space::new() } else {
              let v149_6: Path = concat_path(&(v146_6),&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
              let v149_11: Space = routine_21(c, &(v149_6), &v132_24_cursor, &(*s1));
              drop(v149_6);
              compose(&(v147_10),&(v149_11))
            };
            drop(v147_10);
            let v147_13: Space = unite(&(v147_8),&(v147_12));
            join_wrapped_into(&mut v146_7_write,&((v147_13).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v146_7_write);
          compose(&(v145_5),&(v146_7))
        };
        drop(v145_5);
        let v145_9: Space = intersect(&(*CONSTANT_2),&(v145_2));
        drop(v145_2);
        let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
        drop(v145_9);
        let v145_12: Space = if (&(v145_10)).is_empty() { Space::new() } else {
          let v150_6: Path = concat_path(&(v144_6),&v132_24_cursor.path()[(v132_24_origin + 1)..(v132_24_origin + 2)]);
          let mut v150_11 = Space::new();
          let mut v150_11_write = v150_11.write_zipper();
          for v150_11_byte in v132_24_cursor.child_mask().iter() {
            v132_24_cursor.descend_to_existing_byte(v150_11_byte);
            {
            let v151_2: Space = singleton(&v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)]);
            let v151_3: Space = intersect(&(*CONSTANT_2),&(v151_2));
            let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
            drop(v151_3);
            let v151_5: Space = subtract(&(*CONSTANT_1),&(v151_4));
            drop(v151_4);
            let v151_7: Space = if (&(v151_5)).is_empty() { Space::new() } else {
              let v152_6: Space = routine_4(c, &v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)], &(v150_6), &v132_24_cursor, &(*s1));
              compose(&(v151_5),&(v152_6))
            };
            drop(v151_5);
            let v151_8: Space = intersect(&(*CONSTANT_2),&(v151_2));
            drop(v151_2);
            let v151_9: Space = if has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
            drop(v151_8);
            let v151_11: Space = if (&(v151_9)).is_empty() { Space::new() } else {
              let v153_10: Space = routine_5(c, &v132_24_cursor.path()[(v132_24_origin + 2)..(v132_24_origin + 3)], &(v150_6), &v132_24_cursor, &(*s1));
              compose(&(v151_9),&(v153_10))
            };
            drop(v151_9);
            let v151_12: Space = unite(&(v151_7),&(v151_11));
            join_wrapped_into(&mut v150_11_write,&((v151_12).read_zipper()),&[]);
            }
            v132_24_cursor.ascend(1);
          }
          drop(v150_11_write);
          drop(v150_6);
          compose(&(v145_10),&(v150_11))
        };
        drop(v145_10);
        let v145_13: Space = unite(&(v145_8),&(v145_12));
        join_wrapped_into(&mut v144_11_write,&((v145_13).read_zipper()),&[]);
        }
        v132_24_cursor.ascend(1);
      }
      drop(v144_11_write);
      drop(v144_6);
      compose(&(v133_10),&(v144_11))
    };
    drop(v133_10);
    let v133_13: Space = unite(&(v133_8),&(v133_12));
    join_wrapped_into(&mut v132_24_write,&((v133_13).read_zipper()),&[]);
    }
    v132_24_cursor.ascend(1);
  }
  drop(v132_24_cursor);
  drop(v132_24_write);
  (v132_24).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v154_24 = Space::new();
  let mut v154_24_write = v154_24.write_zipper();
  let mut v154_24_cursor = (*s0).read_zipper();
  let v154_24_origin = v154_24_cursor.path().len();
  for v154_24_byte in v154_24_cursor.child_mask().iter() {
    v154_24_cursor.descend_to_existing_byte(v154_24_byte);
    {
    let v155_2: Space = singleton(&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
    let v155_3: Space = intersect(&(*CONSTANT_2),&(v155_2));
    let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
    drop(v155_3);
    let v155_5: Space = subtract(&(*CONSTANT_1),&(v155_4));
    drop(v155_4);
    let v155_8: Space = if (&(v155_5)).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
      let mut v156_7 = Space::new();
      let mut v156_7_write = v156_7.write_zipper();
      for v156_7_byte in v154_24_cursor.child_mask().iter() {
        v154_24_cursor.descend_to_existing_byte(v156_7_byte);
        {
        let v157_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
        let v157_3: Space = intersect(&(*CONSTANT_2),&(v157_2));
        let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = subtract(&(*CONSTANT_1),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (&(v157_5)).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
          let mut v158_7 = Space::new();
          let mut v158_7_write = v158_7.write_zipper();
          for v158_7_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v158_7_byte);
            {
            let v159_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v159_3: Space = intersect(&(*CONSTANT_2),&(v159_2));
            let v159_4: Space = if has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
            drop(v159_3);
            let v159_5: Space = subtract(&(*CONSTANT_1),&(v159_4));
            drop(v159_4);
            let v159_8: Space = if (&(v159_5)).is_empty() { Space::new() } else {
              let v160_6: Path = concat_path(&(v158_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v160_7: Space = routine_20(c, &(v160_6), &v154_24_cursor, &(*s1));
              compose(&(v159_5),&(v160_7))
            };
            drop(v159_5);
            let v159_9: Space = intersect(&(*CONSTANT_2),&(v159_2));
            drop(v159_2);
            let v159_10: Space = if has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
            drop(v159_9);
            let v159_12: Space = if (&(v159_10)).is_empty() { Space::new() } else {
              let v161_6: Path = concat_path(&(v158_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v161_11: Space = routine_21(c, &(v161_6), &v154_24_cursor, &(*s1));
              drop(v161_6);
              compose(&(v159_10),&(v161_11))
            };
            drop(v159_10);
            let v159_13: Space = unite(&(v159_8),&(v159_12));
            join_wrapped_into(&mut v158_7_write,&((v159_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v158_7_write);
          compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = intersect(&(*CONSTANT_2),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (&(v157_10)).is_empty() { Space::new() } else {
          let v162_6: Path = concat_path(&(v156_6),&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
          let mut v162_11 = Space::new();
          let mut v162_11_write = v162_11.write_zipper();
          for v162_11_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v162_11_byte);
            {
            let v163_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v163_3: Space = intersect(&(*CONSTANT_2),&(v163_2));
            let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
            drop(v163_3);
            let v163_5: Space = subtract(&(*CONSTANT_1),&(v163_4));
            drop(v163_4);
            let v163_8: Space = if (&(v163_5)).is_empty() { Space::new() } else {
              let v164_6: Path = concat_path(&(v162_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v164_7: Space = routine_20(c, &(v164_6), &v154_24_cursor, &(*s1));
              compose(&(v163_5),&(v164_7))
            };
            drop(v163_5);
            let v163_9: Space = intersect(&(*CONSTANT_2),&(v163_2));
            drop(v163_2);
            let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
            drop(v163_9);
            let v163_12: Space = if (&(v163_10)).is_empty() { Space::new() } else {
              let v165_6: Path = concat_path(&(v162_6),&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
              let v165_11: Space = routine_3(c, &(v165_6), &v154_24_cursor, &(*s1));
              drop(v165_6);
              compose(&(v163_10),&(v165_11))
            };
            drop(v163_10);
            let v163_13: Space = unite(&(v163_8),&(v163_12));
            join_wrapped_into(&mut v162_11_write,&((v163_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v162_11_write);
          drop(v162_6);
          compose(&(v157_10),&(v162_11))
        };
        drop(v157_10);
        let v157_13: Space = unite(&(v157_8),&(v157_12));
        join_wrapped_into(&mut v156_7_write,&((v157_13).read_zipper()),&[]);
        }
        v154_24_cursor.ascend(1);
      }
      drop(v156_7_write);
      compose(&(v155_5),&(v156_7))
    };
    drop(v155_5);
    let v155_9: Space = intersect(&(*CONSTANT_2),&(v155_2));
    drop(v155_2);
    let v155_10: Space = if has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
    drop(v155_9);
    let v155_12: Space = if (&(v155_10)).is_empty() { Space::new() } else {
      let v166_6: Path = concat_path(&(*p0),&v154_24_cursor.path()[v154_24_origin..(v154_24_origin + 1)]);
      let mut v166_11 = Space::new();
      let mut v166_11_write = v166_11.write_zipper();
      for v166_11_byte in v154_24_cursor.child_mask().iter() {
        v154_24_cursor.descend_to_existing_byte(v166_11_byte);
        {
        let v167_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 2)]);
        let v167_3: Space = intersect(&(*CONSTANT_2),&(v167_2));
        let v167_4: Space = if has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
        drop(v167_3);
        let v167_5: Space = subtract(&(*CONSTANT_1),&(v167_4));
        drop(v167_4);
        let v167_7: Space = if (&(v167_5)).is_empty() { Space::new() } else {
          let mut v168_6 = Space::new();
          let mut v168_6_write = v168_6.write_zipper();
          for v168_6_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v168_6_byte);
            {
            let v169_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v169_3: Space = intersect(&(*CONSTANT_2),&(v169_2));
            let v169_4: Space = if has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
            drop(v169_3);
            let v169_5: Space = subtract(&(*CONSTANT_1),&(v169_4));
            drop(v169_4);
            let v169_8: Space = if (&(v169_5)).is_empty() { Space::new() } else {
              let v170_7: Space = routine_8(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              compose(&(v169_5),&(v170_7))
            };
            drop(v169_5);
            let v169_9: Space = intersect(&(*CONSTANT_2),&(v169_2));
            drop(v169_2);
            let v169_10: Space = if has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
            drop(v169_9);
            let v169_12: Space = if (&(v169_10)).is_empty() { Space::new() } else {
              let v171_11: Space = routine_9(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              compose(&(v169_10),&(v171_11))
            };
            drop(v169_10);
            let v169_13: Space = unite(&(v169_8),&(v169_12));
            join_wrapped_into(&mut v168_6_write,&((v169_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v168_6_write);
          compose(&(v167_5),&(v168_6))
        };
        drop(v167_5);
        let v167_8: Space = intersect(&(*CONSTANT_2),&(v167_2));
        drop(v167_2);
        let v167_9: Space = if has_head(&(v167_8)) { singleton(&[]) } else { Space::new() };
        drop(v167_8);
        let v167_11: Space = if (&(v167_9)).is_empty() { Space::new() } else {
          let mut v172_10 = Space::new();
          let mut v172_10_write = v172_10.write_zipper();
          for v172_10_byte in v154_24_cursor.child_mask().iter() {
            v154_24_cursor.descend_to_existing_byte(v172_10_byte);
            {
            let v173_2: Space = singleton(&v154_24_cursor.path()[(v154_24_origin + 2)..(v154_24_origin + 3)]);
            let v173_3: Space = intersect(&(*CONSTANT_2),&(v173_2));
            let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
            drop(v173_3);
            let v173_5: Space = subtract(&(*CONSTANT_1),&(v173_4));
            drop(v173_4);
            let v173_8: Space = if (&(v173_5)).is_empty() { Space::new() } else {
              let v174_7: Space = routine_8(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              compose(&(v173_5),&(v174_7))
            };
            drop(v173_5);
            let v173_9: Space = intersect(&(*CONSTANT_2),&(v173_2));
            drop(v173_2);
            let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
            drop(v173_9);
            let v173_12: Space = if (&(v173_10)).is_empty() { Space::new() } else {
              let v175_11: Space = routine_10(c, &v154_24_cursor.path()[(v154_24_origin + 1)..(v154_24_origin + 3)], &(v166_6), &v154_24_cursor, &(*s1));
              compose(&(v173_10),&(v175_11))
            };
            drop(v173_10);
            let v173_13: Space = unite(&(v173_8),&(v173_12));
            join_wrapped_into(&mut v172_10_write,&((v173_13).read_zipper()),&[]);
            }
            v154_24_cursor.ascend(1);
          }
          drop(v172_10_write);
          compose(&(v167_9),&(v172_10))
        };
        drop(v167_9);
        let v167_12: Space = unite(&(v167_7),&(v167_11));
        join_wrapped_into(&mut v166_11_write,&((v167_12).read_zipper()),&[]);
        }
        v154_24_cursor.ascend(1);
      }
      drop(v166_11_write);
      drop(v166_6);
      compose(&(v155_10),&(v166_11))
    };
    drop(v155_10);
    let v155_13: Space = unite(&(v155_8),&(v155_12));
    join_wrapped_into(&mut v154_24_write,&((v155_13).read_zipper()),&[]);
    }
    v154_24_cursor.ascend(1);
  }
  drop(v154_24_cursor);
  drop(v154_24_write);
  (v154_24).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v176_28 = Space::new();
  let mut v176_28_write = v176_28.write_zipper();
  let mut v176_28_cursor = (*s0).read_zipper();
  let v176_28_origin = v176_28_cursor.path().len();
  for v176_28_byte in v176_28_cursor.child_mask().iter() {
    v176_28_cursor.descend_to_existing_byte(v176_28_byte);
    {
    let v177_2: Space = singleton(&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
    let v177_3: Space = intersect(&(*CONSTANT_2),&(v177_2));
    let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
    drop(v177_3);
    let v177_5: Space = subtract(&(*CONSTANT_1),&(v177_4));
    drop(v177_4);
    let v177_8: Space = if (&(v177_5)).is_empty() { Space::new() } else {
      let v178_6: Path = concat_path(&(*p0),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
      let mut v178_7 = Space::new();
      let mut v178_7_write = v178_7.write_zipper();
      for v178_7_byte in v176_28_cursor.child_mask().iter() {
        v176_28_cursor.descend_to_existing_byte(v178_7_byte);
        {
        let v179_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
        let v179_3: Space = intersect(&(*CONSTANT_2),&(v179_2));
        let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
        drop(v179_3);
        let v179_5: Space = subtract(&(*CONSTANT_1),&(v179_4));
        drop(v179_4);
        let v179_8: Space = if (&(v179_5)).is_empty() { Space::new() } else {
          let v180_6: Path = concat_path(&(v178_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v180_7 = Space::new();
          let mut v180_7_write = v180_7.write_zipper();
          for v180_7_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v180_7_byte);
            {
            let v181_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v181_3: Space = intersect(&(*CONSTANT_2),&(v181_2));
            let v181_4: Space = if has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
            drop(v181_3);
            let v181_5: Space = subtract(&(*CONSTANT_1),&(v181_4));
            drop(v181_4);
            let v181_8: Space = if (&(v181_5)).is_empty() { Space::new() } else {
              let v182_6: Path = concat_path(&(v180_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v182_7: Space = routine_22(c, &(v182_6), &(*p1), &v176_28_cursor, &(*s1));
              compose(&(v181_5),&(v182_7))
            };
            drop(v181_5);
            let v181_9: Space = intersect(&(*CONSTANT_2),&(v181_2));
            drop(v181_2);
            let v181_10: Space = if has_head(&(v181_9)) { singleton(&[]) } else { Space::new() };
            drop(v181_9);
            let v181_12: Space = if (&(v181_10)).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v180_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v183_11: Space = routine_23(c, &(v183_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v183_6);
              compose(&(v181_10),&(v183_11))
            };
            drop(v181_10);
            let v181_13: Space = unite(&(v181_8),&(v181_12));
            join_wrapped_into(&mut v180_7_write,&((v181_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v180_7_write);
          compose(&(v179_5),&(v180_7))
        };
        drop(v179_5);
        let v179_9: Space = intersect(&(*CONSTANT_2),&(v179_2));
        drop(v179_2);
        let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
        drop(v179_9);
        let v179_12: Space = if (&(v179_10)).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v178_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v184_11 = Space::new();
          let mut v184_11_write = v184_11.write_zipper();
          for v184_11_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v184_11_byte);
            {
            let v185_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v185_3: Space = intersect(&(*CONSTANT_2),&(v185_2));
            let v185_4: Space = if has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
            drop(v185_3);
            let v185_5: Space = subtract(&(*CONSTANT_1),&(v185_4));
            drop(v185_4);
            let v185_8: Space = if (&(v185_5)).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v184_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v186_7: Space = routine_22(c, &(v186_6), &(*p1), &v176_28_cursor, &(*s1));
              compose(&(v185_5),&(v186_7))
            };
            drop(v185_5);
            let v185_9: Space = intersect(&(*CONSTANT_2),&(v185_2));
            drop(v185_2);
            let v185_10: Space = if has_head(&(v185_9)) { singleton(&[]) } else { Space::new() };
            drop(v185_9);
            let v185_12: Space = if (&(v185_10)).is_empty() { Space::new() } else {
              let v187_6: Path = concat_path(&(v184_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v187_11: Space = routine_10(c, &(v187_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v187_6);
              compose(&(v185_10),&(v187_11))
            };
            drop(v185_10);
            let v185_13: Space = unite(&(v185_8),&(v185_12));
            join_wrapped_into(&mut v184_11_write,&((v185_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v184_11_write);
          drop(v184_6);
          compose(&(v179_10),&(v184_11))
        };
        drop(v179_10);
        let v179_13: Space = unite(&(v179_8),&(v179_12));
        join_wrapped_into(&mut v178_7_write,&((v179_13).read_zipper()),&[]);
        }
        v176_28_cursor.ascend(1);
      }
      drop(v178_7_write);
      compose(&(v177_5),&(v178_7))
    };
    drop(v177_5);
    let v177_9: Space = intersect(&(*CONSTANT_2),&(v177_2));
    drop(v177_2);
    let v177_10: Space = if has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
    drop(v177_9);
    let v177_13: Space = if (&(v177_10)).is_empty() { Space::new() } else {
      let v188_6: Path = concat_path(&(*p0),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]);
      let mut v188_12 = Space::new();
      let mut v188_12_write = v188_12.write_zipper();
      for v188_12_byte in v176_28_cursor.child_mask().iter() {
        v176_28_cursor.descend_to_existing_byte(v188_12_byte);
        {
        let v189_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
        let v189_3: Space = intersect(&(*CONSTANT_2),&(v189_2));
        let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
        drop(v189_3);
        let v189_5: Space = subtract(&(*CONSTANT_1),&(v189_4));
        drop(v189_4);
        let v189_8: Space = if (&(v189_5)).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v188_6),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let mut v190_7 = Space::new();
          let mut v190_7_write = v190_7.write_zipper();
          for v190_7_byte in v176_28_cursor.child_mask().iter() {
            v176_28_cursor.descend_to_existing_byte(v190_7_byte);
            {
            let v191_2: Space = singleton(&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
            let v191_3: Space = intersect(&(*CONSTANT_2),&(v191_2));
            let v191_4: Space = if has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
            drop(v191_3);
            let v191_5: Space = subtract(&(*CONSTANT_1),&(v191_4));
            drop(v191_4);
            let v191_8: Space = if (&(v191_5)).is_empty() { Space::new() } else {
              let v192_6: Path = concat_path(&(v190_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v192_7: Space = routine_22(c, &(v192_6), &(*p1), &v176_28_cursor, &(*s1));
              compose(&(v191_5),&(v192_7))
            };
            drop(v191_5);
            let v191_9: Space = intersect(&(*CONSTANT_2),&(v191_2));
            drop(v191_2);
            let v191_10: Space = if has_head(&(v191_9)) { singleton(&[]) } else { Space::new() };
            drop(v191_9);
            let v191_12: Space = if (&(v191_10)).is_empty() { Space::new() } else {
              let v193_6: Path = concat_path(&(v190_6),&v176_28_cursor.path()[(v176_28_origin + 2)..(v176_28_origin + 3)]);
              let v193_11: Space = routine_23(c, &(v193_6), &(*p1), &v176_28_cursor, &(*s1));
              drop(v193_6);
              compose(&(v191_10),&(v193_11))
            };
            drop(v191_10);
            let v191_13: Space = unite(&(v191_8),&(v191_12));
            join_wrapped_into(&mut v190_7_write,&((v191_13).read_zipper()),&[]);
            }
            v176_28_cursor.ascend(1);
          }
          drop(v190_7_write);
          drop(v190_6);
          compose(&(v189_5),&(v190_7))
        };
        drop(v189_5);
        let v189_9: Space = intersect(&(*CONSTANT_2),&(v189_2));
        drop(v189_2);
        let v189_10: Space = if has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
        drop(v189_9);
        let v189_13: Space = if (&(v189_10)).is_empty() { Space::new() } else {
          let mut v194_12 = Space::new();
          let mut v194_12_write = v194_12.write_zipper();
          let mut v194_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v176_28_cursor.path()[v176_28_origin..(v176_28_origin + 1)]),&v176_28_cursor.path()[(v176_28_origin + 1)..(v176_28_origin + 2)]);
          let v194_12_origin = v194_12_cursor.path().len();
          for v194_12_byte in v194_12_cursor.child_mask().iter() {
            v194_12_cursor.descend_to_existing_byte(v194_12_byte);
            {
            let v195_2: Space = singleton(&v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)]);
            let v195_3: Space = intersect(&(*CONSTANT_2),&(v195_2));
            let v195_4: Space = if has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
            drop(v195_3);
            let v195_5: Space = subtract(&(*CONSTANT_1),&(v195_4));
            drop(v195_4);
            let v195_7: Space = if (&(v195_5)).is_empty() { Space::new() } else {
              let v196_6: Space = routine_13(c, &v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)], &(*p1), &v194_12_cursor);
              compose(&(v195_5),&(v196_6))
            };
            drop(v195_5);
            let v195_8: Space = intersect(&(*CONSTANT_2),&(v195_2));
            drop(v195_2);
            let v195_9: Space = if has_head(&(v195_8)) { singleton(&[]) } else { Space::new() };
            drop(v195_8);
            let v195_11: Space = if (&(v195_9)).is_empty() { Space::new() } else {
              let v197_10: Space = routine_14(c, &v194_12_cursor.path()[v194_12_origin..(v194_12_origin + 1)], &(*p1), &v194_12_cursor);
              compose(&(v195_9),&(v197_10))
            };
            drop(v195_9);
            let v195_12: Space = unite(&(v195_7),&(v195_11));
            join_wrapped_into(&mut v194_12_write,&((v195_12).read_zipper()),&[]);
            }
            v194_12_cursor.ascend(1);
          }
          drop(v194_12_cursor);
          drop(v194_12_write);
          compose(&(v189_10),&(v194_12))
        };
        drop(v189_10);
        let v189_14: Space = unite(&(v189_8),&(v189_13));
        join_wrapped_into(&mut v188_12_write,&((v189_14).read_zipper()),&[]);
        }
        v176_28_cursor.ascend(1);
      }
      drop(v188_12_write);
      drop(v188_6);
      compose(&(v177_10),&(v188_12))
    };
    drop(v177_10);
    let v177_14: Space = unite(&(v177_8),&(v177_13));
    join_wrapped_into(&mut v176_28_write,&((v177_14).read_zipper()),&[]);
    }
    v176_28_cursor.ascend(1);
  }
  drop(v176_28_cursor);
  drop(v176_28_write);
  (v176_28).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v198_28 = Space::new();
  let mut v198_28_write = v198_28.write_zipper();
  let mut v198_28_cursor = (*s0).read_zipper();
  let v198_28_origin = v198_28_cursor.path().len();
  for v198_28_byte in v198_28_cursor.child_mask().iter() {
    v198_28_cursor.descend_to_existing_byte(v198_28_byte);
    {
    let v199_2: Space = singleton(&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
    let v199_3: Space = intersect(&(*CONSTANT_2),&(v199_2));
    let v199_4: Space = if has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
    drop(v199_3);
    let v199_5: Space = subtract(&(*CONSTANT_1),&(v199_4));
    drop(v199_4);
    let v199_8: Space = if (&(v199_5)).is_empty() { Space::new() } else {
      let v200_6: Path = concat_path(&(*p0),&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
      let mut v200_7 = Space::new();
      let mut v200_7_write = v200_7.write_zipper();
      for v200_7_byte in v198_28_cursor.child_mask().iter() {
        v198_28_cursor.descend_to_existing_byte(v200_7_byte);
        {
        let v201_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
        let v201_3: Space = intersect(&(*CONSTANT_2),&(v201_2));
        let v201_4: Space = if has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
        drop(v201_3);
        let v201_5: Space = subtract(&(*CONSTANT_1),&(v201_4));
        drop(v201_4);
        let v201_8: Space = if (&(v201_5)).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v200_6),&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
          let mut v202_7 = Space::new();
          let mut v202_7_write = v202_7.write_zipper();
          for v202_7_byte in v198_28_cursor.child_mask().iter() {
            v198_28_cursor.descend_to_existing_byte(v202_7_byte);
            {
            let v203_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
            let v203_3: Space = intersect(&(*CONSTANT_2),&(v203_2));
            let v203_4: Space = if has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
            drop(v203_3);
            let v203_5: Space = subtract(&(*CONSTANT_1),&(v203_4));
            drop(v203_4);
            let v203_8: Space = if (&(v203_5)).is_empty() { Space::new() } else {
              let v204_6: Path = concat_path(&(v202_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v204_7: Space = routine_22(c, &(v204_6), &(*p1), &v198_28_cursor, &(*s1));
              compose(&(v203_5),&(v204_7))
            };
            drop(v203_5);
            let v203_9: Space = intersect(&(*CONSTANT_2),&(v203_2));
            drop(v203_2);
            let v203_10: Space = if has_head(&(v203_9)) { singleton(&[]) } else { Space::new() };
            drop(v203_9);
            let v203_12: Space = if (&(v203_10)).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v202_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v205_11: Space = routine_23(c, &(v205_6), &(*p1), &v198_28_cursor, &(*s1));
              drop(v205_6);
              compose(&(v203_10),&(v205_11))
            };
            drop(v203_10);
            let v203_13: Space = unite(&(v203_8),&(v203_12));
            join_wrapped_into(&mut v202_7_write,&((v203_13).read_zipper()),&[]);
            }
            v198_28_cursor.ascend(1);
          }
          drop(v202_7_write);
          compose(&(v201_5),&(v202_7))
        };
        drop(v201_5);
        let v201_9: Space = intersect(&(*CONSTANT_2),&(v201_2));
        drop(v201_2);
        let v201_10: Space = if has_head(&(v201_9)) { singleton(&[]) } else { Space::new() };
        drop(v201_9);
        let v201_12: Space = if (&(v201_10)).is_empty() { Space::new() } else {
          let v206_6: Path = concat_path(&(v200_6),&v198_28_cursor.path()[(v198_28_origin + 1)..(v198_28_origin + 2)]);
          let mut v206_11 = Space::new();
          let mut v206_11_write = v206_11.write_zipper();
          for v206_11_byte in v198_28_cursor.child_mask().iter() {
            v198_28_cursor.descend_to_existing_byte(v206_11_byte);
            {
            let v207_2: Space = singleton(&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
            let v207_3: Space = intersect(&(*CONSTANT_2),&(v207_2));
            let v207_4: Space = if has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
            drop(v207_3);
            let v207_5: Space = subtract(&(*CONSTANT_1),&(v207_4));
            drop(v207_4);
            let v207_8: Space = if (&(v207_5)).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v206_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v208_7: Space = routine_22(c, &(v208_6), &(*p1), &v198_28_cursor, &(*s1));
              compose(&(v207_5),&(v208_7))
            };
            drop(v207_5);
            let v207_9: Space = intersect(&(*CONSTANT_2),&(v207_2));
            drop(v207_2);
            let v207_10: Space = if has_head(&(v207_9)) { singleton(&[]) } else { Space::new() };
            drop(v207_9);
            let v207_12: Space = if (&(v207_10)).is_empty() { Space::new() } else {
              let v209_6: Path = concat_path(&(v206_6),&v198_28_cursor.path()[(v198_28_origin + 2)..(v198_28_origin + 3)]);
              let v209_11: Space = routine_10(c, &(v209_6), &(*p1), &v198_28_cursor, &(*s1));
              drop(v209_6);
              compose(&(v207_10),&(v209_11))
            };
            drop(v207_10);
            let v207_13: Space = unite(&(v207_8),&(v207_12));
            join_wrapped_into(&mut v206_11_write,&((v207_13).read_zipper()),&[]);
            }
            v198_28_cursor.ascend(1);
          }
          drop(v206_11_write);
          drop(v206_6);
          compose(&(v201_10),&(v206_11))
        };
        drop(v201_10);
        let v201_13: Space = unite(&(v201_8),&(v201_12));
        join_wrapped_into(&mut v200_7_write,&((v201_13).read_zipper()),&[]);
        }
        v198_28_cursor.ascend(1);
      }
      drop(v200_7_write);
      drop(v200_6);
      compose(&(v199_5),&(v200_7))
    };
    drop(v199_5);
    let v199_9: Space = intersect(&(*CONSTANT_2),&(v199_2));
    drop(v199_2);
    let v199_10: Space = if has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
    drop(v199_9);
    let v199_13: Space = if (&(v199_10)).is_empty() { Space::new() } else {
      let mut v210_12 = Space::new();
      let mut v210_12_write = v210_12.write_zipper();
      let mut v210_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v198_28_cursor.path()[v198_28_origin..(v198_28_origin + 1)]);
      let v210_12_origin = v210_12_cursor.path().len();
      for v210_12_byte in v210_12_cursor.child_mask().iter() {
        v210_12_cursor.descend_to_existing_byte(v210_12_byte);
        {
        let v211_2: Space = singleton(&v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 1)]);
        let v211_3: Space = intersect(&(*CONSTANT_2),&(v211_2));
        let v211_4: Space = if has_head(&(v211_3)) { singleton(&[]) } else { Space::new() };
        drop(v211_3);
        let v211_5: Space = subtract(&(*CONSTANT_1),&(v211_4));
        drop(v211_4);
        let v211_7: Space = if (&(v211_5)).is_empty() { Space::new() } else {
          let mut v212_6 = Space::new();
          let mut v212_6_write = v212_6.write_zipper();
          for v212_6_byte in v210_12_cursor.child_mask().iter() {
            v210_12_cursor.descend_to_existing_byte(v212_6_byte);
            {
            let v213_2: Space = singleton(&v210_12_cursor.path()[(v210_12_origin + 1)..(v210_12_origin + 2)]);
            let v213_3: Space = intersect(&(*CONSTANT_2),&(v213_2));
            let v213_4: Space = if has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
            drop(v213_3);
            let v213_5: Space = subtract(&(*CONSTANT_1),&(v213_4));
            drop(v213_4);
            let v213_8: Space = if (&(v213_5)).is_empty() { Space::new() } else {
              let v214_7: Space = routine_17(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              compose(&(v213_5),&(v214_7))
            };
            drop(v213_5);
            let v213_9: Space = intersect(&(*CONSTANT_2),&(v213_2));
            drop(v213_2);
            let v213_10: Space = if has_head(&(v213_9)) { singleton(&[]) } else { Space::new() };
            drop(v213_9);
            let v213_12: Space = if (&(v213_10)).is_empty() { Space::new() } else {
              let v215_11: Space = routine_18(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              compose(&(v213_10),&(v215_11))
            };
            drop(v213_10);
            let v213_13: Space = unite(&(v213_8),&(v213_12));
            join_wrapped_into(&mut v212_6_write,&((v213_13).read_zipper()),&[]);
            }
            v210_12_cursor.ascend(1);
          }
          drop(v212_6_write);
          compose(&(v211_5),&(v212_6))
        };
        drop(v211_5);
        let v211_8: Space = intersect(&(*CONSTANT_2),&(v211_2));
        drop(v211_2);
        let v211_9: Space = if has_head(&(v211_8)) { singleton(&[]) } else { Space::new() };
        drop(v211_8);
        let v211_11: Space = if (&(v211_9)).is_empty() { Space::new() } else {
          let mut v216_10 = Space::new();
          let mut v216_10_write = v216_10.write_zipper();
          for v216_10_byte in v210_12_cursor.child_mask().iter() {
            v210_12_cursor.descend_to_existing_byte(v216_10_byte);
            {
            let v217_2: Space = singleton(&v210_12_cursor.path()[(v210_12_origin + 1)..(v210_12_origin + 2)]);
            let v217_3: Space = intersect(&(*CONSTANT_2),&(v217_2));
            let v217_4: Space = if has_head(&(v217_3)) { singleton(&[]) } else { Space::new() };
            drop(v217_3);
            let v217_5: Space = subtract(&(*CONSTANT_1),&(v217_4));
            drop(v217_4);
            let v217_8: Space = if (&(v217_5)).is_empty() { Space::new() } else {
              let v218_7: Space = routine_17(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              compose(&(v217_5),&(v218_7))
            };
            drop(v217_5);
            let v217_9: Space = intersect(&(*CONSTANT_2),&(v217_2));
            drop(v217_2);
            let v217_10: Space = if has_head(&(v217_9)) { singleton(&[]) } else { Space::new() };
            drop(v217_9);
            let v217_12: Space = if (&(v217_10)).is_empty() { Space::new() } else {
              let v219_11: Space = routine_19(c, &v210_12_cursor.path()[v210_12_origin..(v210_12_origin + 2)], &(*p1), &v210_12_cursor);
              compose(&(v217_10),&(v219_11))
            };
            drop(v217_10);
            let v217_13: Space = unite(&(v217_8),&(v217_12));
            join_wrapped_into(&mut v216_10_write,&((v217_13).read_zipper()),&[]);
            }
            v210_12_cursor.ascend(1);
          }
          drop(v216_10_write);
          compose(&(v211_9),&(v216_10))
        };
        drop(v211_9);
        let v211_12: Space = unite(&(v211_7),&(v211_11));
        join_wrapped_into(&mut v210_12_write,&((v211_12).read_zipper()),&[]);
        }
        v210_12_cursor.ascend(1);
      }
      drop(v210_12_cursor);
      drop(v210_12_write);
      compose(&(v199_10),&(v210_12))
    };
    drop(v199_10);
    let v199_14: Space = unite(&(v199_8),&(v199_13));
    join_wrapped_into(&mut v198_28_write,&((v199_14).read_zipper()),&[]);
    }
    v198_28_cursor.ascend(1);
  }
  drop(v198_28_cursor);
  drop(v198_28_write);
  (v198_28).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v220_25 = Space::new();
  let mut v220_25_write = v220_25.write_zipper();
  let mut v220_25_cursor = descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0));
  let v220_25_origin = v220_25_cursor.path().len();
  for v220_25_byte in v220_25_cursor.child_mask().iter() {
    v220_25_cursor.descend_to_existing_byte(v220_25_byte);
    {
    let v221_2: Space = singleton(&v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 1)]);
    let v221_3: Space = intersect(&(*CONSTANT_2),&(v221_2));
    let v221_4: Space = if has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
    drop(v221_3);
    let v221_5: Space = subtract(&(*CONSTANT_1),&(v221_4));
    drop(v221_4);
    let v221_7: Space = if (&(v221_5)).is_empty() { Space::new() } else {
      let mut v222_6 = Space::new();
      let mut v222_6_write = v222_6.write_zipper();
      for v222_6_byte in v220_25_cursor.child_mask().iter() {
        v220_25_cursor.descend_to_existing_byte(v222_6_byte);
        {
        let v223_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 1)..(v220_25_origin + 2)]);
        let v223_3: Space = intersect(&(*CONSTANT_2),&(v223_2));
        let v223_4: Space = if has_head(&(v223_3)) { singleton(&[]) } else { Space::new() };
        drop(v223_3);
        let v223_5: Space = subtract(&(*CONSTANT_1),&(v223_4));
        drop(v223_4);
        let v223_8: Space = if (&(v223_5)).is_empty() { Space::new() } else {
          let mut v224_7 = Space::new();
          let mut v224_7_write = v224_7.write_zipper();
          for v224_7_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v224_7_byte);
            {
            let v225_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v225_3: Space = intersect(&(*CONSTANT_2),&(v225_2));
            let v225_4: Space = if has_head(&(v225_3)) { singleton(&[]) } else { Space::new() };
            drop(v225_3);
            let v225_5: Space = subtract(&(*CONSTANT_1),&(v225_4));
            drop(v225_4);
            let v225_8: Space = if (&(v225_5)).is_empty() { Space::new() } else {
              let v226_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v225_5),&(v226_7))
            };
            drop(v225_5);
            let v225_9: Space = intersect(&(*CONSTANT_2),&(v225_2));
            drop(v225_2);
            let v225_10: Space = if has_head(&(v225_9)) { singleton(&[]) } else { Space::new() };
            drop(v225_9);
            let v225_12: Space = if (&(v225_10)).is_empty() { Space::new() } else {
              let v227_11: Space = routine_25(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v225_10),&(v227_11))
            };
            drop(v225_10);
            let v225_13: Space = unite(&(v225_8),&(v225_12));
            join_wrapped_into(&mut v224_7_write,&((v225_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v224_7_write);
          compose(&(v223_5),&(v224_7))
        };
        drop(v223_5);
        let v223_9: Space = intersect(&(*CONSTANT_2),&(v223_2));
        drop(v223_2);
        let v223_10: Space = if has_head(&(v223_9)) { singleton(&[]) } else { Space::new() };
        drop(v223_9);
        let v223_12: Space = if (&(v223_10)).is_empty() { Space::new() } else {
          let mut v228_11 = Space::new();
          let mut v228_11_write = v228_11.write_zipper();
          for v228_11_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v228_11_byte);
            {
            let v229_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v229_3: Space = intersect(&(*CONSTANT_2),&(v229_2));
            let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
            drop(v229_3);
            let v229_5: Space = subtract(&(*CONSTANT_1),&(v229_4));
            drop(v229_4);
            let v229_8: Space = if (&(v229_5)).is_empty() { Space::new() } else {
              let v230_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v229_5),&(v230_7))
            };
            drop(v229_5);
            let v229_9: Space = intersect(&(*CONSTANT_2),&(v229_2));
            drop(v229_2);
            let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
            drop(v229_9);
            let v229_12: Space = if (&(v229_10)).is_empty() { Space::new() } else {
              let v231_11: Space = routine_19(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v229_10),&(v231_11))
            };
            drop(v229_10);
            let v229_13: Space = unite(&(v229_8),&(v229_12));
            join_wrapped_into(&mut v228_11_write,&((v229_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v228_11_write);
          compose(&(v223_10),&(v228_11))
        };
        drop(v223_10);
        let v223_13: Space = unite(&(v223_8),&(v223_12));
        join_wrapped_into(&mut v222_6_write,&((v223_13).read_zipper()),&[]);
        }
        v220_25_cursor.ascend(1);
      }
      drop(v222_6_write);
      compose(&(v221_5),&(v222_6))
    };
    drop(v221_5);
    let v221_8: Space = intersect(&(*CONSTANT_2),&(v221_2));
    drop(v221_2);
    let v221_9: Space = if has_head(&(v221_8)) { singleton(&[]) } else { Space::new() };
    drop(v221_8);
    let v221_11: Space = if (&(v221_9)).is_empty() { Space::new() } else {
      let mut v232_10 = Space::new();
      let mut v232_10_write = v232_10.write_zipper();
      for v232_10_byte in v220_25_cursor.child_mask().iter() {
        v220_25_cursor.descend_to_existing_byte(v232_10_byte);
        {
        let v233_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 1)..(v220_25_origin + 2)]);
        let v233_3: Space = intersect(&(*CONSTANT_2),&(v233_2));
        let v233_4: Space = if has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
        drop(v233_3);
        let v233_5: Space = subtract(&(*CONSTANT_1),&(v233_4));
        drop(v233_4);
        let v233_8: Space = if (&(v233_5)).is_empty() { Space::new() } else {
          let mut v234_7 = Space::new();
          let mut v234_7_write = v234_7.write_zipper();
          for v234_7_byte in v220_25_cursor.child_mask().iter() {
            v220_25_cursor.descend_to_existing_byte(v234_7_byte);
            {
            let v235_2: Space = singleton(&v220_25_cursor.path()[(v220_25_origin + 2)..(v220_25_origin + 3)]);
            let v235_3: Space = intersect(&(*CONSTANT_2),&(v235_2));
            let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
            drop(v235_3);
            let v235_5: Space = subtract(&(*CONSTANT_1),&(v235_4));
            drop(v235_4);
            let v235_8: Space = if (&(v235_5)).is_empty() { Space::new() } else {
              let v236_7: Space = routine_24(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v235_5),&(v236_7))
            };
            drop(v235_5);
            let v235_9: Space = intersect(&(*CONSTANT_2),&(v235_2));
            drop(v235_2);
            let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
            drop(v235_9);
            let v235_12: Space = if (&(v235_10)).is_empty() { Space::new() } else {
              let v237_11: Space = routine_25(c, &v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 3)], &(*p1), &v220_25_cursor);
              compose(&(v235_10),&(v237_11))
            };
            drop(v235_10);
            let v235_13: Space = unite(&(v235_8),&(v235_12));
            join_wrapped_into(&mut v234_7_write,&((v235_13).read_zipper()),&[]);
            }
            v220_25_cursor.ascend(1);
          }
          drop(v234_7_write);
          compose(&(v233_5),&(v234_7))
        };
        drop(v233_5);
        let v233_9: Space = intersect(&(*CONSTANT_2),&(v233_2));
        drop(v233_2);
        let v233_10: Space = if has_head(&(v233_9)) { singleton(&[]) } else { Space::new() };
        drop(v233_9);
        let v233_11: Space = compose(&(v233_10),&v220_25_cursor);
        drop(v233_10);
        let v233_12: Space = wrap(&(v233_11),&v220_25_cursor.path()[v220_25_origin..(v220_25_origin + 2)]);
        drop(v233_11);
        let v233_13: Space = wrap(&(v233_12),&(*p1));
        drop(v233_12);
        let v233_14: Space = unite(&(v233_8),&(v233_13));
        drop(v233_13);
        join_wrapped_into(&mut v232_10_write,&((v233_14).read_zipper()),&[]);
        }
        v220_25_cursor.ascend(1);
      }
      drop(v232_10_write);
      compose(&(v221_9),&(v232_10))
    };
    drop(v221_9);
    let v221_12: Space = unite(&(v221_7),&(v221_11));
    join_wrapped_into(&mut v220_25_write,&((v221_12).read_zipper()),&[]);
    }
    v220_25_cursor.ascend(1);
  }
  drop(v220_25_cursor);
  drop(v220_25_write);
  (v220_25).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v239_28 = Space::new();
  let mut v239_28_write = v239_28.write_zipper();
  let mut v239_28_cursor = (*s0).read_zipper();
  let v239_28_origin = v239_28_cursor.path().len();
  for v239_28_byte in v239_28_cursor.child_mask().iter() {
    v239_28_cursor.descend_to_existing_byte(v239_28_byte);
    {
    let v240_2: Space = singleton(&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
    let v240_3: Space = intersect(&(*CONSTANT_2),&(v240_2));
    let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
    drop(v240_3);
    let v240_5: Space = subtract(&(*CONSTANT_1),&(v240_4));
    drop(v240_4);
    let v240_8: Space = if (&(v240_5)).is_empty() { Space::new() } else {
      let v241_6: Path = concat_path(&(*p0),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
      let mut v241_7 = Space::new();
      let mut v241_7_write = v241_7.write_zipper();
      for v241_7_byte in v239_28_cursor.child_mask().iter() {
        v239_28_cursor.descend_to_existing_byte(v241_7_byte);
        {
        let v242_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
        let v242_3: Space = intersect(&(*CONSTANT_2),&(v242_2));
        let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = subtract(&(*CONSTANT_1),&(v242_4));
        drop(v242_4);
        let v242_8: Space = if (&(v242_5)).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v241_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v243_7 = Space::new();
          let mut v243_7_write = v243_7.write_zipper();
          for v243_7_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v243_7_byte);
            {
            let v244_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v244_3: Space = intersect(&(*CONSTANT_2),&(v244_2));
            let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = subtract(&(*CONSTANT_1),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (&(v244_5)).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v245_7: Space = routine_26(c, &(v245_6), &(*p1), &v239_28_cursor, &(*s1));
              compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = intersect(&(*CONSTANT_2),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (&(v244_10)).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v246_11: Space = routine_27(c, &(v246_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v246_6);
              compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = unite(&(v244_8),&(v244_12));
            join_wrapped_into(&mut v243_7_write,&((v244_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v243_7_write);
          compose(&(v242_5),&(v243_7))
        };
        drop(v242_5);
        let v242_9: Space = intersect(&(*CONSTANT_2),&(v242_2));
        drop(v242_2);
        let v242_10: Space = if has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
        drop(v242_9);
        let v242_12: Space = if (&(v242_10)).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v241_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v247_11 = Space::new();
          let mut v247_11_write = v247_11.write_zipper();
          for v247_11_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v247_11_byte);
            {
            let v248_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v248_3: Space = intersect(&(*CONSTANT_2),&(v248_2));
            let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = subtract(&(*CONSTANT_1),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (&(v248_5)).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v249_7: Space = routine_26(c, &(v249_6), &(*p1), &v239_28_cursor, &(*s1));
              compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = intersect(&(*CONSTANT_2),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (&(v248_10)).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v250_11: Space = routine_10(c, &(v250_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v250_6);
              compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = unite(&(v248_8),&(v248_12));
            join_wrapped_into(&mut v247_11_write,&((v248_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v247_11_write);
          drop(v247_6);
          compose(&(v242_10),&(v247_11))
        };
        drop(v242_10);
        let v242_13: Space = unite(&(v242_8),&(v242_12));
        join_wrapped_into(&mut v241_7_write,&((v242_13).read_zipper()),&[]);
        }
        v239_28_cursor.ascend(1);
      }
      drop(v241_7_write);
      compose(&(v240_5),&(v241_7))
    };
    drop(v240_5);
    let v240_9: Space = intersect(&(*CONSTANT_2),&(v240_2));
    drop(v240_2);
    let v240_10: Space = if has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
    drop(v240_9);
    let v240_13: Space = if (&(v240_10)).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]);
      let mut v251_12 = Space::new();
      let mut v251_12_write = v251_12.write_zipper();
      for v251_12_byte in v239_28_cursor.child_mask().iter() {
        v239_28_cursor.descend_to_existing_byte(v251_12_byte);
        {
        let v252_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
        let v252_3: Space = intersect(&(*CONSTANT_2),&(v252_2));
        let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = subtract(&(*CONSTANT_1),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (&(v252_5)).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let mut v253_7 = Space::new();
          let mut v253_7_write = v253_7.write_zipper();
          for v253_7_byte in v239_28_cursor.child_mask().iter() {
            v239_28_cursor.descend_to_existing_byte(v253_7_byte);
            {
            let v254_2: Space = singleton(&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
            let v254_3: Space = intersect(&(*CONSTANT_2),&(v254_2));
            let v254_4: Space = if has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
            drop(v254_3);
            let v254_5: Space = subtract(&(*CONSTANT_1),&(v254_4));
            drop(v254_4);
            let v254_8: Space = if (&(v254_5)).is_empty() { Space::new() } else {
              let v255_6: Path = concat_path(&(v253_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v255_7: Space = routine_26(c, &(v255_6), &(*p1), &v239_28_cursor, &(*s1));
              compose(&(v254_5),&(v255_7))
            };
            drop(v254_5);
            let v254_9: Space = intersect(&(*CONSTANT_2),&(v254_2));
            drop(v254_2);
            let v254_10: Space = if has_head(&(v254_9)) { singleton(&[]) } else { Space::new() };
            drop(v254_9);
            let v254_12: Space = if (&(v254_10)).is_empty() { Space::new() } else {
              let v256_6: Path = concat_path(&(v253_6),&v239_28_cursor.path()[(v239_28_origin + 2)..(v239_28_origin + 3)]);
              let v256_11: Space = routine_27(c, &(v256_6), &(*p1), &v239_28_cursor, &(*s1));
              drop(v256_6);
              compose(&(v254_10),&(v256_11))
            };
            drop(v254_10);
            let v254_13: Space = unite(&(v254_8),&(v254_12));
            join_wrapped_into(&mut v253_7_write,&((v254_13).read_zipper()),&[]);
            }
            v239_28_cursor.ascend(1);
          }
          drop(v253_7_write);
          drop(v253_6);
          compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = intersect(&(*CONSTANT_2),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_13: Space = if (&(v252_10)).is_empty() { Space::new() } else {
          let mut v257_12 = Space::new();
          let mut v257_12_write = v257_12.write_zipper();
          let mut v257_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v239_28_cursor.path()[v239_28_origin..(v239_28_origin + 1)]),&v239_28_cursor.path()[(v239_28_origin + 1)..(v239_28_origin + 2)]);
          let v257_12_origin = v257_12_cursor.path().len();
          for v257_12_byte in v257_12_cursor.child_mask().iter() {
            v257_12_cursor.descend_to_existing_byte(v257_12_byte);
            {
            let v258_2: Space = singleton(&v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)]);
            let v258_3: Space = intersect(&(*CONSTANT_2),&(v258_2));
            let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
            drop(v258_3);
            let v258_5: Space = subtract(&(*CONSTANT_1),&(v258_4));
            drop(v258_4);
            let v258_7: Space = if (&(v258_5)).is_empty() { Space::new() } else {
              let v259_6: Space = routine_13(c, &v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)], &(*p1), &v257_12_cursor);
              compose(&(v258_5),&(v259_6))
            };
            drop(v258_5);
            let v258_8: Space = intersect(&(*CONSTANT_2),&(v258_2));
            drop(v258_2);
            let v258_9: Space = if has_head(&(v258_8)) { singleton(&[]) } else { Space::new() };
            drop(v258_8);
            let v258_11: Space = if (&(v258_9)).is_empty() { Space::new() } else {
              let v260_10: Space = routine_14(c, &v257_12_cursor.path()[v257_12_origin..(v257_12_origin + 1)], &(*p1), &v257_12_cursor);
              compose(&(v258_9),&(v260_10))
            };
            drop(v258_9);
            let v258_12: Space = unite(&(v258_7),&(v258_11));
            join_wrapped_into(&mut v257_12_write,&((v258_12).read_zipper()),&[]);
            }
            v257_12_cursor.ascend(1);
          }
          drop(v257_12_cursor);
          drop(v257_12_write);
          compose(&(v252_10),&(v257_12))
        };
        drop(v252_10);
        let v252_14: Space = unite(&(v252_8),&(v252_13));
        join_wrapped_into(&mut v251_12_write,&((v252_14).read_zipper()),&[]);
        }
        v239_28_cursor.ascend(1);
      }
      drop(v251_12_write);
      drop(v251_6);
      compose(&(v240_10),&(v251_12))
    };
    drop(v240_10);
    let v240_14: Space = unite(&(v240_8),&(v240_13));
    join_wrapped_into(&mut v239_28_write,&((v240_14).read_zipper()),&[]);
    }
    v239_28_cursor.ascend(1);
  }
  drop(v239_28_cursor);
  drop(v239_28_write);
  (v239_28).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v261_28 = Space::new();
  let mut v261_28_write = v261_28.write_zipper();
  let mut v261_28_cursor = (*s0).read_zipper();
  let v261_28_origin = v261_28_cursor.path().len();
  for v261_28_byte in v261_28_cursor.child_mask().iter() {
    v261_28_cursor.descend_to_existing_byte(v261_28_byte);
    {
    let v262_2: Space = singleton(&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
    let v262_3: Space = intersect(&(*CONSTANT_2),&(v262_2));
    let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
    drop(v262_3);
    let v262_5: Space = subtract(&(*CONSTANT_1),&(v262_4));
    drop(v262_4);
    let v262_8: Space = if (&(v262_5)).is_empty() { Space::new() } else {
      let v263_6: Path = concat_path(&(*p0),&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
      let mut v263_7 = Space::new();
      let mut v263_7_write = v263_7.write_zipper();
      for v263_7_byte in v261_28_cursor.child_mask().iter() {
        v261_28_cursor.descend_to_existing_byte(v263_7_byte);
        {
        let v264_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
        let v264_3: Space = intersect(&(*CONSTANT_2),&(v264_2));
        let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
        drop(v264_3);
        let v264_5: Space = subtract(&(*CONSTANT_1),&(v264_4));
        drop(v264_4);
        let v264_8: Space = if (&(v264_5)).is_empty() { Space::new() } else {
          let v265_6: Path = concat_path(&(v263_6),&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
          let mut v265_7 = Space::new();
          let mut v265_7_write = v265_7.write_zipper();
          for v265_7_byte in v261_28_cursor.child_mask().iter() {
            v261_28_cursor.descend_to_existing_byte(v265_7_byte);
            {
            let v266_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
            let v266_3: Space = intersect(&(*CONSTANT_2),&(v266_2));
            let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
            drop(v266_3);
            let v266_5: Space = subtract(&(*CONSTANT_1),&(v266_4));
            drop(v266_4);
            let v266_8: Space = if (&(v266_5)).is_empty() { Space::new() } else {
              let v267_6: Path = concat_path(&(v265_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v267_7: Space = routine_26(c, &(v267_6), &(*p1), &v261_28_cursor, &(*s1));
              compose(&(v266_5),&(v267_7))
            };
            drop(v266_5);
            let v266_9: Space = intersect(&(*CONSTANT_2),&(v266_2));
            drop(v266_2);
            let v266_10: Space = if has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
            drop(v266_9);
            let v266_12: Space = if (&(v266_10)).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v265_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v268_11: Space = routine_27(c, &(v268_6), &(*p1), &v261_28_cursor, &(*s1));
              drop(v268_6);
              compose(&(v266_10),&(v268_11))
            };
            drop(v266_10);
            let v266_13: Space = unite(&(v266_8),&(v266_12));
            join_wrapped_into(&mut v265_7_write,&((v266_13).read_zipper()),&[]);
            }
            v261_28_cursor.ascend(1);
          }
          drop(v265_7_write);
          compose(&(v264_5),&(v265_7))
        };
        drop(v264_5);
        let v264_9: Space = intersect(&(*CONSTANT_2),&(v264_2));
        drop(v264_2);
        let v264_10: Space = if has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
        drop(v264_9);
        let v264_12: Space = if (&(v264_10)).is_empty() { Space::new() } else {
          let v269_6: Path = concat_path(&(v263_6),&v261_28_cursor.path()[(v261_28_origin + 1)..(v261_28_origin + 2)]);
          let mut v269_11 = Space::new();
          let mut v269_11_write = v269_11.write_zipper();
          for v269_11_byte in v261_28_cursor.child_mask().iter() {
            v261_28_cursor.descend_to_existing_byte(v269_11_byte);
            {
            let v270_2: Space = singleton(&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
            let v270_3: Space = intersect(&(*CONSTANT_2),&(v270_2));
            let v270_4: Space = if has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
            drop(v270_3);
            let v270_5: Space = subtract(&(*CONSTANT_1),&(v270_4));
            drop(v270_4);
            let v270_8: Space = if (&(v270_5)).is_empty() { Space::new() } else {
              let v271_6: Path = concat_path(&(v269_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v271_7: Space = routine_26(c, &(v271_6), &(*p1), &v261_28_cursor, &(*s1));
              compose(&(v270_5),&(v271_7))
            };
            drop(v270_5);
            let v270_9: Space = intersect(&(*CONSTANT_2),&(v270_2));
            drop(v270_2);
            let v270_10: Space = if has_head(&(v270_9)) { singleton(&[]) } else { Space::new() };
            drop(v270_9);
            let v270_12: Space = if (&(v270_10)).is_empty() { Space::new() } else {
              let v272_6: Path = concat_path(&(v269_6),&v261_28_cursor.path()[(v261_28_origin + 2)..(v261_28_origin + 3)]);
              let v272_11: Space = routine_10(c, &(v272_6), &(*p1), &v261_28_cursor, &(*s1));
              drop(v272_6);
              compose(&(v270_10),&(v272_11))
            };
            drop(v270_10);
            let v270_13: Space = unite(&(v270_8),&(v270_12));
            join_wrapped_into(&mut v269_11_write,&((v270_13).read_zipper()),&[]);
            }
            v261_28_cursor.ascend(1);
          }
          drop(v269_11_write);
          drop(v269_6);
          compose(&(v264_10),&(v269_11))
        };
        drop(v264_10);
        let v264_13: Space = unite(&(v264_8),&(v264_12));
        join_wrapped_into(&mut v263_7_write,&((v264_13).read_zipper()),&[]);
        }
        v261_28_cursor.ascend(1);
      }
      drop(v263_7_write);
      drop(v263_6);
      compose(&(v262_5),&(v263_7))
    };
    drop(v262_5);
    let v262_9: Space = intersect(&(*CONSTANT_2),&(v262_2));
    drop(v262_2);
    let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
    drop(v262_9);
    let v262_13: Space = if (&(v262_10)).is_empty() { Space::new() } else {
      let mut v273_12 = Space::new();
      let mut v273_12_write = v273_12.write_zipper();
      let mut v273_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v261_28_cursor.path()[v261_28_origin..(v261_28_origin + 1)]);
      let v273_12_origin = v273_12_cursor.path().len();
      for v273_12_byte in v273_12_cursor.child_mask().iter() {
        v273_12_cursor.descend_to_existing_byte(v273_12_byte);
        {
        let v274_2: Space = singleton(&v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 1)]);
        let v274_3: Space = intersect(&(*CONSTANT_2),&(v274_2));
        let v274_4: Space = if has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
        drop(v274_3);
        let v274_5: Space = subtract(&(*CONSTANT_1),&(v274_4));
        drop(v274_4);
        let v274_7: Space = if (&(v274_5)).is_empty() { Space::new() } else {
          let mut v275_6 = Space::new();
          let mut v275_6_write = v275_6.write_zipper();
          for v275_6_byte in v273_12_cursor.child_mask().iter() {
            v273_12_cursor.descend_to_existing_byte(v275_6_byte);
            {
            let v276_2: Space = singleton(&v273_12_cursor.path()[(v273_12_origin + 1)..(v273_12_origin + 2)]);
            let v276_3: Space = intersect(&(*CONSTANT_2),&(v276_2));
            let v276_4: Space = if has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
            drop(v276_3);
            let v276_5: Space = subtract(&(*CONSTANT_1),&(v276_4));
            drop(v276_4);
            let v276_8: Space = if (&(v276_5)).is_empty() { Space::new() } else {
              let v277_7: Space = routine_17(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              compose(&(v276_5),&(v277_7))
            };
            drop(v276_5);
            let v276_9: Space = intersect(&(*CONSTANT_2),&(v276_2));
            drop(v276_2);
            let v276_10: Space = if has_head(&(v276_9)) { singleton(&[]) } else { Space::new() };
            drop(v276_9);
            let v276_12: Space = if (&(v276_10)).is_empty() { Space::new() } else {
              let v278_11: Space = routine_18(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              compose(&(v276_10),&(v278_11))
            };
            drop(v276_10);
            let v276_13: Space = unite(&(v276_8),&(v276_12));
            join_wrapped_into(&mut v275_6_write,&((v276_13).read_zipper()),&[]);
            }
            v273_12_cursor.ascend(1);
          }
          drop(v275_6_write);
          compose(&(v274_5),&(v275_6))
        };
        drop(v274_5);
        let v274_8: Space = intersect(&(*CONSTANT_2),&(v274_2));
        drop(v274_2);
        let v274_9: Space = if has_head(&(v274_8)) { singleton(&[]) } else { Space::new() };
        drop(v274_8);
        let v274_11: Space = if (&(v274_9)).is_empty() { Space::new() } else {
          let mut v279_10 = Space::new();
          let mut v279_10_write = v279_10.write_zipper();
          for v279_10_byte in v273_12_cursor.child_mask().iter() {
            v273_12_cursor.descend_to_existing_byte(v279_10_byte);
            {
            let v280_2: Space = singleton(&v273_12_cursor.path()[(v273_12_origin + 1)..(v273_12_origin + 2)]);
            let v280_3: Space = intersect(&(*CONSTANT_2),&(v280_2));
            let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
            drop(v280_3);
            let v280_5: Space = subtract(&(*CONSTANT_1),&(v280_4));
            drop(v280_4);
            let v280_8: Space = if (&(v280_5)).is_empty() { Space::new() } else {
              let v281_7: Space = routine_17(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              compose(&(v280_5),&(v281_7))
            };
            drop(v280_5);
            let v280_9: Space = intersect(&(*CONSTANT_2),&(v280_2));
            drop(v280_2);
            let v280_10: Space = if has_head(&(v280_9)) { singleton(&[]) } else { Space::new() };
            drop(v280_9);
            let v280_12: Space = if (&(v280_10)).is_empty() { Space::new() } else {
              let v282_11: Space = routine_19(c, &v273_12_cursor.path()[v273_12_origin..(v273_12_origin + 2)], &(*p1), &v273_12_cursor);
              compose(&(v280_10),&(v282_11))
            };
            drop(v280_10);
            let v280_13: Space = unite(&(v280_8),&(v280_12));
            join_wrapped_into(&mut v279_10_write,&((v280_13).read_zipper()),&[]);
            }
            v273_12_cursor.ascend(1);
          }
          drop(v279_10_write);
          compose(&(v274_9),&(v279_10))
        };
        drop(v274_9);
        let v274_12: Space = unite(&(v274_7),&(v274_11));
        join_wrapped_into(&mut v273_12_write,&((v274_12).read_zipper()),&[]);
        }
        v273_12_cursor.ascend(1);
      }
      drop(v273_12_cursor);
      drop(v273_12_write);
      compose(&(v262_10),&(v273_12))
    };
    drop(v262_10);
    let v262_14: Space = unite(&(v262_8),&(v262_13));
    join_wrapped_into(&mut v261_28_write,&((v262_14).read_zipper()),&[]);
    }
    v261_28_cursor.ascend(1);
  }
  drop(v261_28_cursor);
  drop(v261_28_write);
  (v261_28).clone()
}

fn routine_13(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v283_21 = Space::new();
  let mut v283_21_write = v283_21.write_zipper();
  let mut v283_21_cursor = (*s0).read_zipper();
  let v283_21_origin = v283_21_cursor.path().len();
  for v283_21_byte in v283_21_cursor.child_mask().iter() {
    v283_21_cursor.descend_to_existing_byte(v283_21_byte);
    {
    let v284_2: Space = singleton(&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
    let v284_3: Space = intersect(&(*CONSTANT_2),&(v284_2));
    let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = subtract(&(*CONSTANT_1),&(v284_4));
    drop(v284_4);
    let v284_8: Space = if (&(v284_5)).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
      let mut v285_7 = Space::new();
      let mut v285_7_write = v285_7.write_zipper();
      for v285_7_byte in v283_21_cursor.child_mask().iter() {
        v283_21_cursor.descend_to_existing_byte(v285_7_byte);
        {
        let v286_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v286_3: Space = intersect(&(*CONSTANT_2),&(v286_2));
        let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = subtract(&(*CONSTANT_1),&(v286_4));
        drop(v286_4);
        let v286_8: Space = if (&(v286_5)).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v285_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v287_7 = Space::new();
          let mut v287_7_write = v287_7.write_zipper();
          for v287_7_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v287_7_byte);
            {
            let v288_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v288_3: Space = intersect(&(*CONSTANT_2),&(v288_2));
            let v288_4: Space = if has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = subtract(&(*CONSTANT_1),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (&(v288_5)).is_empty() { Space::new() } else {
              let v289_6: Path = concat_path(&(v287_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v289_7: Space = routine_28(c, &(v289_6), &(*p1), &v283_21_cursor);
              compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = intersect(&(*CONSTANT_2),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (&(v288_10)).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v287_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v290_11: Space = routine_29(c, &(v290_6), &(*p1), &v283_21_cursor);
              drop(v290_6);
              compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = unite(&(v288_8),&(v288_12));
            join_wrapped_into(&mut v287_7_write,&((v288_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v287_7_write);
          compose(&(v286_5),&(v287_7))
        };
        drop(v286_5);
        let v286_9: Space = intersect(&(*CONSTANT_2),&(v286_2));
        drop(v286_2);
        let v286_10: Space = if has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
        drop(v286_9);
        let v286_12: Space = if (&(v286_10)).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v285_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v291_11 = Space::new();
          let mut v291_11_write = v291_11.write_zipper();
          for v291_11_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v291_11_byte);
            {
            let v292_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v292_3: Space = intersect(&(*CONSTANT_2),&(v292_2));
            let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
            drop(v292_3);
            let v292_5: Space = subtract(&(*CONSTANT_1),&(v292_4));
            drop(v292_4);
            let v292_8: Space = if (&(v292_5)).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v291_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v293_7: Space = routine_28(c, &(v293_6), &(*p1), &v283_21_cursor);
              compose(&(v292_5),&(v293_7))
            };
            drop(v292_5);
            let v292_9: Space = intersect(&(*CONSTANT_2),&(v292_2));
            drop(v292_2);
            let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
            drop(v292_9);
            let v292_12: Space = if (&(v292_10)).is_empty() { Space::new() } else {
              let v294_6: Path = concat_path(&(v291_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v294_11: Space = routine_19(c, &(v294_6), &(*p1), &v283_21_cursor);
              drop(v294_6);
              compose(&(v292_10),&(v294_11))
            };
            drop(v292_10);
            let v292_13: Space = unite(&(v292_8),&(v292_12));
            join_wrapped_into(&mut v291_11_write,&((v292_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v291_11_write);
          drop(v291_6);
          compose(&(v286_10),&(v291_11))
        };
        drop(v286_10);
        let v286_13: Space = unite(&(v286_8),&(v286_12));
        join_wrapped_into(&mut v285_7_write,&((v286_13).read_zipper()),&[]);
        }
        v283_21_cursor.ascend(1);
      }
      drop(v285_7_write);
      compose(&(v284_5),&(v285_7))
    };
    drop(v284_5);
    let v284_9: Space = intersect(&(*CONSTANT_2),&(v284_2));
    drop(v284_2);
    let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
    drop(v284_9);
    let v284_12: Space = if (&(v284_10)).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&v283_21_cursor.path()[v283_21_origin..(v283_21_origin + 1)]);
      let mut v295_11 = Space::new();
      let mut v295_11_write = v295_11.write_zipper();
      for v295_11_byte in v283_21_cursor.child_mask().iter() {
        v283_21_cursor.descend_to_existing_byte(v295_11_byte);
        {
        let v296_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v296_3: Space = intersect(&(*CONSTANT_2),&(v296_2));
        let v296_4: Space = if has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = subtract(&(*CONSTANT_1),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (&(v296_5)).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
          let mut v297_7 = Space::new();
          let mut v297_7_write = v297_7.write_zipper();
          for v297_7_byte in v283_21_cursor.child_mask().iter() {
            v283_21_cursor.descend_to_existing_byte(v297_7_byte);
            {
            let v298_2: Space = singleton(&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
            let v298_3: Space = intersect(&(*CONSTANT_2),&(v298_2));
            let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = subtract(&(*CONSTANT_1),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (&(v298_5)).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v299_7: Space = routine_28(c, &(v299_6), &(*p1), &v283_21_cursor);
              compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = intersect(&(*CONSTANT_2),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (&(v298_10)).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&v283_21_cursor.path()[(v283_21_origin + 2)..(v283_21_origin + 3)]);
              let v300_11: Space = routine_29(c, &(v300_6), &(*p1), &v283_21_cursor);
              drop(v300_6);
              compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = unite(&(v298_8),&(v298_12));
            join_wrapped_into(&mut v297_7_write,&((v298_13).read_zipper()),&[]);
            }
            v283_21_cursor.ascend(1);
          }
          drop(v297_7_write);
          compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = intersect(&(*CONSTANT_2),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_11: Space = compose(&(v296_10),&v283_21_cursor);
        drop(v296_10);
        let v301_6: Path = concat_path(&(v295_6),&v283_21_cursor.path()[(v283_21_origin + 1)..(v283_21_origin + 2)]);
        let v296_12: Space = wrap(&(v296_11),&(v301_6));
        drop(v296_11);
        let v296_13: Space = wrap(&(v296_12),&(*p1));
        drop(v296_12);
        let v296_14: Space = unite(&(v296_8),&(v296_13));
        drop(v296_13);
        join_wrapped_into(&mut v295_11_write,&((v296_14).read_zipper()),&[]);
        }
        v283_21_cursor.ascend(1);
      }
      drop(v295_11_write);
      drop(v295_6);
      compose(&(v284_10),&(v295_11))
    };
    drop(v284_10);
    let v284_13: Space = unite(&(v284_8),&(v284_12));
    join_wrapped_into(&mut v283_21_write,&((v284_13).read_zipper()),&[]);
    }
    v283_21_cursor.ascend(1);
  }
  drop(v283_21_cursor);
  drop(v283_21_write);
  (v283_21).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v302_15 = Space::new();
  let mut v302_15_write = v302_15.write_zipper();
  let mut v302_15_cursor = (*s0).read_zipper();
  let v302_15_origin = v302_15_cursor.path().len();
  for v302_15_byte in v302_15_cursor.child_mask().iter() {
    v302_15_cursor.descend_to_existing_byte(v302_15_byte);
    {
    let v303_2: Space = singleton(&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
    let v303_3: Space = intersect(&(*CONSTANT_2),&(v303_2));
    let v303_4: Space = if has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
    drop(v303_3);
    let v303_5: Space = subtract(&(*CONSTANT_1),&(v303_4));
    drop(v303_4);
    let v303_8: Space = if (&(v303_5)).is_empty() { Space::new() } else {
      let v304_6: Path = concat_path(&(*p0),&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
      let mut v304_7 = Space::new();
      let mut v304_7_write = v304_7.write_zipper();
      for v304_7_byte in v302_15_cursor.child_mask().iter() {
        v302_15_cursor.descend_to_existing_byte(v304_7_byte);
        {
        let v305_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
        let v305_3: Space = intersect(&(*CONSTANT_2),&(v305_2));
        let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
        drop(v305_3);
        let v305_5: Space = subtract(&(*CONSTANT_1),&(v305_4));
        drop(v305_4);
        let v305_8: Space = if (&(v305_5)).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v304_6),&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
          let mut v306_7 = Space::new();
          let mut v306_7_write = v306_7.write_zipper();
          for v306_7_byte in v302_15_cursor.child_mask().iter() {
            v302_15_cursor.descend_to_existing_byte(v306_7_byte);
            {
            let v307_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
            let v307_3: Space = intersect(&(*CONSTANT_2),&(v307_2));
            let v307_4: Space = if has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
            drop(v307_3);
            let v307_5: Space = subtract(&(*CONSTANT_1),&(v307_4));
            drop(v307_4);
            let v307_8: Space = if (&(v307_5)).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v306_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v308_7: Space = routine_28(c, &(v308_6), &(*p1), &v302_15_cursor);
              compose(&(v307_5),&(v308_7))
            };
            drop(v307_5);
            let v307_9: Space = intersect(&(*CONSTANT_2),&(v307_2));
            drop(v307_2);
            let v307_10: Space = if has_head(&(v307_9)) { singleton(&[]) } else { Space::new() };
            drop(v307_9);
            let v307_12: Space = if (&(v307_10)).is_empty() { Space::new() } else {
              let v309_6: Path = concat_path(&(v306_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v309_11: Space = routine_29(c, &(v309_6), &(*p1), &v302_15_cursor);
              drop(v309_6);
              compose(&(v307_10),&(v309_11))
            };
            drop(v307_10);
            let v307_13: Space = unite(&(v307_8),&(v307_12));
            join_wrapped_into(&mut v306_7_write,&((v307_13).read_zipper()),&[]);
            }
            v302_15_cursor.ascend(1);
          }
          drop(v306_7_write);
          compose(&(v305_5),&(v306_7))
        };
        drop(v305_5);
        let v305_9: Space = intersect(&(*CONSTANT_2),&(v305_2));
        drop(v305_2);
        let v305_10: Space = if has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
        drop(v305_9);
        let v305_12: Space = if (&(v305_10)).is_empty() { Space::new() } else {
          let v310_6: Path = concat_path(&(v304_6),&v302_15_cursor.path()[(v302_15_origin + 1)..(v302_15_origin + 2)]);
          let mut v310_11 = Space::new();
          let mut v310_11_write = v310_11.write_zipper();
          for v310_11_byte in v302_15_cursor.child_mask().iter() {
            v302_15_cursor.descend_to_existing_byte(v310_11_byte);
            {
            let v311_2: Space = singleton(&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
            let v311_3: Space = intersect(&(*CONSTANT_2),&(v311_2));
            let v311_4: Space = if has_head(&(v311_3)) { singleton(&[]) } else { Space::new() };
            drop(v311_3);
            let v311_5: Space = subtract(&(*CONSTANT_1),&(v311_4));
            drop(v311_4);
            let v311_8: Space = if (&(v311_5)).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v310_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v312_7: Space = routine_28(c, &(v312_6), &(*p1), &v302_15_cursor);
              compose(&(v311_5),&(v312_7))
            };
            drop(v311_5);
            let v311_9: Space = intersect(&(*CONSTANT_2),&(v311_2));
            drop(v311_2);
            let v311_10: Space = if has_head(&(v311_9)) { singleton(&[]) } else { Space::new() };
            drop(v311_9);
            let v311_12: Space = if (&(v311_10)).is_empty() { Space::new() } else {
              let v313_6: Path = concat_path(&(v310_6),&v302_15_cursor.path()[(v302_15_origin + 2)..(v302_15_origin + 3)]);
              let v313_11: Space = routine_19(c, &(v313_6), &(*p1), &v302_15_cursor);
              drop(v313_6);
              compose(&(v311_10),&(v313_11))
            };
            drop(v311_10);
            let v311_13: Space = unite(&(v311_8),&(v311_12));
            join_wrapped_into(&mut v310_11_write,&((v311_13).read_zipper()),&[]);
            }
            v302_15_cursor.ascend(1);
          }
          drop(v310_11_write);
          drop(v310_6);
          compose(&(v305_10),&(v310_11))
        };
        drop(v305_10);
        let v305_13: Space = unite(&(v305_8),&(v305_12));
        join_wrapped_into(&mut v304_7_write,&((v305_13).read_zipper()),&[]);
        }
        v302_15_cursor.ascend(1);
      }
      drop(v304_7_write);
      compose(&(v303_5),&(v304_7))
    };
    drop(v303_5);
    let v303_9: Space = intersect(&(*CONSTANT_2),&(v303_2));
    drop(v303_2);
    let v303_10: Space = if has_head(&(v303_9)) { singleton(&[]) } else { Space::new() };
    drop(v303_9);
    let v303_11: Space = compose(&(v303_10),&v302_15_cursor);
    drop(v303_10);
    let v314_6: Path = concat_path(&(*p0),&v302_15_cursor.path()[v302_15_origin..(v302_15_origin + 1)]);
    let v303_12: Space = wrap(&(v303_11),&(v314_6));
    drop(v303_11);
    let v303_13: Space = wrap(&(v303_12),&(*p1));
    drop(v303_12);
    let v303_14: Space = unite(&(v303_8),&(v303_13));
    drop(v303_13);
    join_wrapped_into(&mut v302_15_write,&((v303_14).read_zipper()),&[]);
    }
    v302_15_cursor.ascend(1);
  }
  drop(v302_15_cursor);
  drop(v302_15_write);
  (v302_15).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v315_28 = Space::new();
  let mut v315_28_write = v315_28.write_zipper();
  let mut v315_28_cursor = (*s0).read_zipper();
  let v315_28_origin = v315_28_cursor.path().len();
  for v315_28_byte in v315_28_cursor.child_mask().iter() {
    v315_28_cursor.descend_to_existing_byte(v315_28_byte);
    {
    let v316_2: Space = singleton(&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
    let v316_3: Space = intersect(&(*CONSTANT_2),&(v316_2));
    let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
    drop(v316_3);
    let v316_5: Space = subtract(&(*CONSTANT_1),&(v316_4));
    drop(v316_4);
    let v316_8: Space = if (&(v316_5)).is_empty() { Space::new() } else {
      let v317_6: Path = concat_path(&(*p0),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
      let mut v317_7 = Space::new();
      let mut v317_7_write = v317_7.write_zipper();
      for v317_7_byte in v315_28_cursor.child_mask().iter() {
        v315_28_cursor.descend_to_existing_byte(v317_7_byte);
        {
        let v318_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
        let v318_3: Space = intersect(&(*CONSTANT_2),&(v318_2));
        let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
        drop(v318_3);
        let v318_5: Space = subtract(&(*CONSTANT_1),&(v318_4));
        drop(v318_4);
        let v318_8: Space = if (&(v318_5)).is_empty() { Space::new() } else {
          let v319_6: Path = concat_path(&(v317_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v319_7 = Space::new();
          let mut v319_7_write = v319_7.write_zipper();
          for v319_7_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v319_7_byte);
            {
            let v320_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v320_3: Space = intersect(&(*CONSTANT_2),&(v320_2));
            let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
            drop(v320_3);
            let v320_5: Space = subtract(&(*CONSTANT_1),&(v320_4));
            drop(v320_4);
            let v320_8: Space = if (&(v320_5)).is_empty() { Space::new() } else {
              let v321_6: Path = concat_path(&(v319_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v321_7: Space = routine_30(c, &(v321_6), &(*p1), &v315_28_cursor, &(*s1));
              compose(&(v320_5),&(v321_7))
            };
            drop(v320_5);
            let v320_9: Space = intersect(&(*CONSTANT_2),&(v320_2));
            drop(v320_2);
            let v320_10: Space = if has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
            drop(v320_9);
            let v320_12: Space = if (&(v320_10)).is_empty() { Space::new() } else {
              let v322_6: Path = concat_path(&(v319_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v322_11: Space = routine_31(c, &(v322_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v322_6);
              compose(&(v320_10),&(v322_11))
            };
            drop(v320_10);
            let v320_13: Space = unite(&(v320_8),&(v320_12));
            join_wrapped_into(&mut v319_7_write,&((v320_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v319_7_write);
          compose(&(v318_5),&(v319_7))
        };
        drop(v318_5);
        let v318_9: Space = intersect(&(*CONSTANT_2),&(v318_2));
        drop(v318_2);
        let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
        drop(v318_9);
        let v318_12: Space = if (&(v318_10)).is_empty() { Space::new() } else {
          let v323_6: Path = concat_path(&(v317_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v323_11 = Space::new();
          let mut v323_11_write = v323_11.write_zipper();
          for v323_11_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v323_11_byte);
            {
            let v324_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v324_3: Space = intersect(&(*CONSTANT_2),&(v324_2));
            let v324_4: Space = if has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
            drop(v324_3);
            let v324_5: Space = subtract(&(*CONSTANT_1),&(v324_4));
            drop(v324_4);
            let v324_8: Space = if (&(v324_5)).is_empty() { Space::new() } else {
              let v325_6: Path = concat_path(&(v323_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v325_7: Space = routine_30(c, &(v325_6), &(*p1), &v315_28_cursor, &(*s1));
              compose(&(v324_5),&(v325_7))
            };
            drop(v324_5);
            let v324_9: Space = intersect(&(*CONSTANT_2),&(v324_2));
            drop(v324_2);
            let v324_10: Space = if has_head(&(v324_9)) { singleton(&[]) } else { Space::new() };
            drop(v324_9);
            let v324_12: Space = if (&(v324_10)).is_empty() { Space::new() } else {
              let v326_6: Path = concat_path(&(v323_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v326_11: Space = routine_10(c, &(v326_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v326_6);
              compose(&(v324_10),&(v326_11))
            };
            drop(v324_10);
            let v324_13: Space = unite(&(v324_8),&(v324_12));
            join_wrapped_into(&mut v323_11_write,&((v324_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v323_11_write);
          drop(v323_6);
          compose(&(v318_10),&(v323_11))
        };
        drop(v318_10);
        let v318_13: Space = unite(&(v318_8),&(v318_12));
        join_wrapped_into(&mut v317_7_write,&((v318_13).read_zipper()),&[]);
        }
        v315_28_cursor.ascend(1);
      }
      drop(v317_7_write);
      compose(&(v316_5),&(v317_7))
    };
    drop(v316_5);
    let v316_9: Space = intersect(&(*CONSTANT_2),&(v316_2));
    drop(v316_2);
    let v316_10: Space = if has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
    drop(v316_9);
    let v316_13: Space = if (&(v316_10)).is_empty() { Space::new() } else {
      let v327_6: Path = concat_path(&(*p0),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]);
      let mut v327_12 = Space::new();
      let mut v327_12_write = v327_12.write_zipper();
      for v327_12_byte in v315_28_cursor.child_mask().iter() {
        v315_28_cursor.descend_to_existing_byte(v327_12_byte);
        {
        let v328_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
        let v328_3: Space = intersect(&(*CONSTANT_2),&(v328_2));
        let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
        drop(v328_3);
        let v328_5: Space = subtract(&(*CONSTANT_1),&(v328_4));
        drop(v328_4);
        let v328_8: Space = if (&(v328_5)).is_empty() { Space::new() } else {
          let v329_6: Path = concat_path(&(v327_6),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let mut v329_7 = Space::new();
          let mut v329_7_write = v329_7.write_zipper();
          for v329_7_byte in v315_28_cursor.child_mask().iter() {
            v315_28_cursor.descend_to_existing_byte(v329_7_byte);
            {
            let v330_2: Space = singleton(&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
            let v330_3: Space = intersect(&(*CONSTANT_2),&(v330_2));
            let v330_4: Space = if has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
            drop(v330_3);
            let v330_5: Space = subtract(&(*CONSTANT_1),&(v330_4));
            drop(v330_4);
            let v330_8: Space = if (&(v330_5)).is_empty() { Space::new() } else {
              let v331_6: Path = concat_path(&(v329_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v331_7: Space = routine_30(c, &(v331_6), &(*p1), &v315_28_cursor, &(*s1));
              compose(&(v330_5),&(v331_7))
            };
            drop(v330_5);
            let v330_9: Space = intersect(&(*CONSTANT_2),&(v330_2));
            drop(v330_2);
            let v330_10: Space = if has_head(&(v330_9)) { singleton(&[]) } else { Space::new() };
            drop(v330_9);
            let v330_12: Space = if (&(v330_10)).is_empty() { Space::new() } else {
              let v332_6: Path = concat_path(&(v329_6),&v315_28_cursor.path()[(v315_28_origin + 2)..(v315_28_origin + 3)]);
              let v332_11: Space = routine_31(c, &(v332_6), &(*p1), &v315_28_cursor, &(*s1));
              drop(v332_6);
              compose(&(v330_10),&(v332_11))
            };
            drop(v330_10);
            let v330_13: Space = unite(&(v330_8),&(v330_12));
            join_wrapped_into(&mut v329_7_write,&((v330_13).read_zipper()),&[]);
            }
            v315_28_cursor.ascend(1);
          }
          drop(v329_7_write);
          drop(v329_6);
          compose(&(v328_5),&(v329_7))
        };
        drop(v328_5);
        let v328_9: Space = intersect(&(*CONSTANT_2),&(v328_2));
        drop(v328_2);
        let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
        drop(v328_9);
        let v328_13: Space = if (&(v328_10)).is_empty() { Space::new() } else {
          let mut v333_12 = Space::new();
          let mut v333_12_write = v333_12.write_zipper();
          let mut v333_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v315_28_cursor.path()[v315_28_origin..(v315_28_origin + 1)]),&v315_28_cursor.path()[(v315_28_origin + 1)..(v315_28_origin + 2)]);
          let v333_12_origin = v333_12_cursor.path().len();
          for v333_12_byte in v333_12_cursor.child_mask().iter() {
            v333_12_cursor.descend_to_existing_byte(v333_12_byte);
            {
            let v334_2: Space = singleton(&v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)]);
            let v334_3: Space = intersect(&(*CONSTANT_2),&(v334_2));
            let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
            drop(v334_3);
            let v334_5: Space = subtract(&(*CONSTANT_1),&(v334_4));
            drop(v334_4);
            let v334_7: Space = if (&(v334_5)).is_empty() { Space::new() } else {
              let v335_6: Space = routine_13(c, &v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)], &(*p1), &v333_12_cursor);
              compose(&(v334_5),&(v335_6))
            };
            drop(v334_5);
            let v334_8: Space = intersect(&(*CONSTANT_2),&(v334_2));
            drop(v334_2);
            let v334_9: Space = if has_head(&(v334_8)) { singleton(&[]) } else { Space::new() };
            drop(v334_8);
            let v334_11: Space = if (&(v334_9)).is_empty() { Space::new() } else {
              let v336_10: Space = routine_14(c, &v333_12_cursor.path()[v333_12_origin..(v333_12_origin + 1)], &(*p1), &v333_12_cursor);
              compose(&(v334_9),&(v336_10))
            };
            drop(v334_9);
            let v334_12: Space = unite(&(v334_7),&(v334_11));
            join_wrapped_into(&mut v333_12_write,&((v334_12).read_zipper()),&[]);
            }
            v333_12_cursor.ascend(1);
          }
          drop(v333_12_cursor);
          drop(v333_12_write);
          compose(&(v328_10),&(v333_12))
        };
        drop(v328_10);
        let v328_14: Space = unite(&(v328_8),&(v328_13));
        join_wrapped_into(&mut v327_12_write,&((v328_14).read_zipper()),&[]);
        }
        v315_28_cursor.ascend(1);
      }
      drop(v327_12_write);
      drop(v327_6);
      compose(&(v316_10),&(v327_12))
    };
    drop(v316_10);
    let v316_14: Space = unite(&(v316_8),&(v316_13));
    join_wrapped_into(&mut v315_28_write,&((v316_14).read_zipper()),&[]);
    }
    v315_28_cursor.ascend(1);
  }
  drop(v315_28_cursor);
  drop(v315_28_write);
  (v315_28).clone()
}

fn routine_16(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v337_28 = Space::new();
  let mut v337_28_write = v337_28.write_zipper();
  let mut v337_28_cursor = (*s0).read_zipper();
  let v337_28_origin = v337_28_cursor.path().len();
  for v337_28_byte in v337_28_cursor.child_mask().iter() {
    v337_28_cursor.descend_to_existing_byte(v337_28_byte);
    {
    let v338_2: Space = singleton(&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
    let v338_3: Space = intersect(&(*CONSTANT_2),&(v338_2));
    let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
    drop(v338_3);
    let v338_5: Space = subtract(&(*CONSTANT_1),&(v338_4));
    drop(v338_4);
    let v338_8: Space = if (&(v338_5)).is_empty() { Space::new() } else {
      let v339_6: Path = concat_path(&(*p0),&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
      let mut v339_7 = Space::new();
      let mut v339_7_write = v339_7.write_zipper();
      for v339_7_byte in v337_28_cursor.child_mask().iter() {
        v337_28_cursor.descend_to_existing_byte(v339_7_byte);
        {
        let v340_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
        let v340_3: Space = intersect(&(*CONSTANT_2),&(v340_2));
        let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
        drop(v340_3);
        let v340_5: Space = subtract(&(*CONSTANT_1),&(v340_4));
        drop(v340_4);
        let v340_8: Space = if (&(v340_5)).is_empty() { Space::new() } else {
          let v341_6: Path = concat_path(&(v339_6),&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
          let mut v341_7 = Space::new();
          let mut v341_7_write = v341_7.write_zipper();
          for v341_7_byte in v337_28_cursor.child_mask().iter() {
            v337_28_cursor.descend_to_existing_byte(v341_7_byte);
            {
            let v342_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
            let v342_3: Space = intersect(&(*CONSTANT_2),&(v342_2));
            let v342_4: Space = if has_head(&(v342_3)) { singleton(&[]) } else { Space::new() };
            drop(v342_3);
            let v342_5: Space = subtract(&(*CONSTANT_1),&(v342_4));
            drop(v342_4);
            let v342_8: Space = if (&(v342_5)).is_empty() { Space::new() } else {
              let v343_6: Path = concat_path(&(v341_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v343_7: Space = routine_30(c, &(v343_6), &(*p1), &v337_28_cursor, &(*s1));
              compose(&(v342_5),&(v343_7))
            };
            drop(v342_5);
            let v342_9: Space = intersect(&(*CONSTANT_2),&(v342_2));
            drop(v342_2);
            let v342_10: Space = if has_head(&(v342_9)) { singleton(&[]) } else { Space::new() };
            drop(v342_9);
            let v342_12: Space = if (&(v342_10)).is_empty() { Space::new() } else {
              let v344_6: Path = concat_path(&(v341_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v344_11: Space = routine_31(c, &(v344_6), &(*p1), &v337_28_cursor, &(*s1));
              drop(v344_6);
              compose(&(v342_10),&(v344_11))
            };
            drop(v342_10);
            let v342_13: Space = unite(&(v342_8),&(v342_12));
            join_wrapped_into(&mut v341_7_write,&((v342_13).read_zipper()),&[]);
            }
            v337_28_cursor.ascend(1);
          }
          drop(v341_7_write);
          compose(&(v340_5),&(v341_7))
        };
        drop(v340_5);
        let v340_9: Space = intersect(&(*CONSTANT_2),&(v340_2));
        drop(v340_2);
        let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
        drop(v340_9);
        let v340_12: Space = if (&(v340_10)).is_empty() { Space::new() } else {
          let v345_6: Path = concat_path(&(v339_6),&v337_28_cursor.path()[(v337_28_origin + 1)..(v337_28_origin + 2)]);
          let mut v345_11 = Space::new();
          let mut v345_11_write = v345_11.write_zipper();
          for v345_11_byte in v337_28_cursor.child_mask().iter() {
            v337_28_cursor.descend_to_existing_byte(v345_11_byte);
            {
            let v346_2: Space = singleton(&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
            let v346_3: Space = intersect(&(*CONSTANT_2),&(v346_2));
            let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
            drop(v346_3);
            let v346_5: Space = subtract(&(*CONSTANT_1),&(v346_4));
            drop(v346_4);
            let v346_8: Space = if (&(v346_5)).is_empty() { Space::new() } else {
              let v347_6: Path = concat_path(&(v345_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v347_7: Space = routine_30(c, &(v347_6), &(*p1), &v337_28_cursor, &(*s1));
              compose(&(v346_5),&(v347_7))
            };
            drop(v346_5);
            let v346_9: Space = intersect(&(*CONSTANT_2),&(v346_2));
            drop(v346_2);
            let v346_10: Space = if has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
            drop(v346_9);
            let v346_12: Space = if (&(v346_10)).is_empty() { Space::new() } else {
              let v348_6: Path = concat_path(&(v345_6),&v337_28_cursor.path()[(v337_28_origin + 2)..(v337_28_origin + 3)]);
              let v348_11: Space = routine_10(c, &(v348_6), &(*p1), &v337_28_cursor, &(*s1));
              drop(v348_6);
              compose(&(v346_10),&(v348_11))
            };
            drop(v346_10);
            let v346_13: Space = unite(&(v346_8),&(v346_12));
            join_wrapped_into(&mut v345_11_write,&((v346_13).read_zipper()),&[]);
            }
            v337_28_cursor.ascend(1);
          }
          drop(v345_11_write);
          drop(v345_6);
          compose(&(v340_10),&(v345_11))
        };
        drop(v340_10);
        let v340_13: Space = unite(&(v340_8),&(v340_12));
        join_wrapped_into(&mut v339_7_write,&((v340_13).read_zipper()),&[]);
        }
        v337_28_cursor.ascend(1);
      }
      drop(v339_7_write);
      drop(v339_6);
      compose(&(v338_5),&(v339_7))
    };
    drop(v338_5);
    let v338_9: Space = intersect(&(*CONSTANT_2),&(v338_2));
    drop(v338_2);
    let v338_10: Space = if has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
    drop(v338_9);
    let v338_13: Space = if (&(v338_10)).is_empty() { Space::new() } else {
      let mut v349_12 = Space::new();
      let mut v349_12_write = v349_12.write_zipper();
      let mut v349_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v337_28_cursor.path()[v337_28_origin..(v337_28_origin + 1)]);
      let v349_12_origin = v349_12_cursor.path().len();
      for v349_12_byte in v349_12_cursor.child_mask().iter() {
        v349_12_cursor.descend_to_existing_byte(v349_12_byte);
        {
        let v350_2: Space = singleton(&v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 1)]);
        let v350_3: Space = intersect(&(*CONSTANT_2),&(v350_2));
        let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
        drop(v350_3);
        let v350_5: Space = subtract(&(*CONSTANT_1),&(v350_4));
        drop(v350_4);
        let v350_7: Space = if (&(v350_5)).is_empty() { Space::new() } else {
          let mut v351_6 = Space::new();
          let mut v351_6_write = v351_6.write_zipper();
          for v351_6_byte in v349_12_cursor.child_mask().iter() {
            v349_12_cursor.descend_to_existing_byte(v351_6_byte);
            {
            let v352_2: Space = singleton(&v349_12_cursor.path()[(v349_12_origin + 1)..(v349_12_origin + 2)]);
            let v352_3: Space = intersect(&(*CONSTANT_2),&(v352_2));
            let v352_4: Space = if has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
            drop(v352_3);
            let v352_5: Space = subtract(&(*CONSTANT_1),&(v352_4));
            drop(v352_4);
            let v352_8: Space = if (&(v352_5)).is_empty() { Space::new() } else {
              let v353_7: Space = routine_17(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              compose(&(v352_5),&(v353_7))
            };
            drop(v352_5);
            let v352_9: Space = intersect(&(*CONSTANT_2),&(v352_2));
            drop(v352_2);
            let v352_10: Space = if has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
            drop(v352_9);
            let v352_12: Space = if (&(v352_10)).is_empty() { Space::new() } else {
              let v354_11: Space = routine_18(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              compose(&(v352_10),&(v354_11))
            };
            drop(v352_10);
            let v352_13: Space = unite(&(v352_8),&(v352_12));
            join_wrapped_into(&mut v351_6_write,&((v352_13).read_zipper()),&[]);
            }
            v349_12_cursor.ascend(1);
          }
          drop(v351_6_write);
          compose(&(v350_5),&(v351_6))
        };
        drop(v350_5);
        let v350_8: Space = intersect(&(*CONSTANT_2),&(v350_2));
        drop(v350_2);
        let v350_9: Space = if has_head(&(v350_8)) { singleton(&[]) } else { Space::new() };
        drop(v350_8);
        let v350_11: Space = if (&(v350_9)).is_empty() { Space::new() } else {
          let mut v355_10 = Space::new();
          let mut v355_10_write = v355_10.write_zipper();
          for v355_10_byte in v349_12_cursor.child_mask().iter() {
            v349_12_cursor.descend_to_existing_byte(v355_10_byte);
            {
            let v356_2: Space = singleton(&v349_12_cursor.path()[(v349_12_origin + 1)..(v349_12_origin + 2)]);
            let v356_3: Space = intersect(&(*CONSTANT_2),&(v356_2));
            let v356_4: Space = if has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
            drop(v356_3);
            let v356_5: Space = subtract(&(*CONSTANT_1),&(v356_4));
            drop(v356_4);
            let v356_8: Space = if (&(v356_5)).is_empty() { Space::new() } else {
              let v357_7: Space = routine_17(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              compose(&(v356_5),&(v357_7))
            };
            drop(v356_5);
            let v356_9: Space = intersect(&(*CONSTANT_2),&(v356_2));
            drop(v356_2);
            let v356_10: Space = if has_head(&(v356_9)) { singleton(&[]) } else { Space::new() };
            drop(v356_9);
            let v356_12: Space = if (&(v356_10)).is_empty() { Space::new() } else {
              let v358_11: Space = routine_19(c, &v349_12_cursor.path()[v349_12_origin..(v349_12_origin + 2)], &(*p1), &v349_12_cursor);
              compose(&(v356_10),&(v358_11))
            };
            drop(v356_10);
            let v356_13: Space = unite(&(v356_8),&(v356_12));
            join_wrapped_into(&mut v355_10_write,&((v356_13).read_zipper()),&[]);
            }
            v349_12_cursor.ascend(1);
          }
          drop(v355_10_write);
          compose(&(v350_9),&(v355_10))
        };
        drop(v350_9);
        let v350_12: Space = unite(&(v350_7),&(v350_11));
        join_wrapped_into(&mut v349_12_write,&((v350_12).read_zipper()),&[]);
        }
        v349_12_cursor.ascend(1);
      }
      drop(v349_12_cursor);
      drop(v349_12_write);
      compose(&(v338_10),&(v349_12))
    };
    drop(v338_10);
    let v338_14: Space = unite(&(v338_8),&(v338_13));
    join_wrapped_into(&mut v337_28_write,&((v338_14).read_zipper()),&[]);
    }
    v337_28_cursor.ascend(1);
  }
  drop(v337_28_cursor);
  drop(v337_28_write);
  (v337_28).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v359_21 = Space::new();
  let mut v359_21_write = v359_21.write_zipper();
  let mut v359_21_cursor = (*s0).read_zipper();
  let v359_21_origin = v359_21_cursor.path().len();
  for v359_21_byte in v359_21_cursor.child_mask().iter() {
    v359_21_cursor.descend_to_existing_byte(v359_21_byte);
    {
    let v360_2: Space = singleton(&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
    let v360_3: Space = intersect(&(*CONSTANT_2),&(v360_2));
    let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
    drop(v360_3);
    let v360_5: Space = subtract(&(*CONSTANT_1),&(v360_4));
    drop(v360_4);
    let v360_8: Space = if (&(v360_5)).is_empty() { Space::new() } else {
      let v361_6: Path = concat_path(&(*p0),&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
      let mut v361_7 = Space::new();
      let mut v361_7_write = v361_7.write_zipper();
      for v361_7_byte in v359_21_cursor.child_mask().iter() {
        v359_21_cursor.descend_to_existing_byte(v361_7_byte);
        {
        let v362_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v362_3: Space = intersect(&(*CONSTANT_2),&(v362_2));
        let v362_4: Space = if has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
        drop(v362_3);
        let v362_5: Space = subtract(&(*CONSTANT_1),&(v362_4));
        drop(v362_4);
        let v362_8: Space = if (&(v362_5)).is_empty() { Space::new() } else {
          let v363_6: Path = concat_path(&(v361_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v363_7 = Space::new();
          let mut v363_7_write = v363_7.write_zipper();
          for v363_7_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v363_7_byte);
            {
            let v364_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v364_3: Space = intersect(&(*CONSTANT_2),&(v364_2));
            let v364_4: Space = if has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
            drop(v364_3);
            let v364_5: Space = subtract(&(*CONSTANT_1),&(v364_4));
            drop(v364_4);
            let v364_8: Space = if (&(v364_5)).is_empty() { Space::new() } else {
              let v365_6: Path = concat_path(&(v363_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v365_7: Space = routine_32(c, &(v365_6), &(*p1), &v359_21_cursor);
              compose(&(v364_5),&(v365_7))
            };
            drop(v364_5);
            let v364_9: Space = intersect(&(*CONSTANT_2),&(v364_2));
            drop(v364_2);
            let v364_10: Space = if has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
            drop(v364_9);
            let v364_12: Space = if (&(v364_10)).is_empty() { Space::new() } else {
              let v366_6: Path = concat_path(&(v363_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v366_11: Space = routine_33(c, &(v366_6), &(*p1), &v359_21_cursor);
              drop(v366_6);
              compose(&(v364_10),&(v366_11))
            };
            drop(v364_10);
            let v364_13: Space = unite(&(v364_8),&(v364_12));
            join_wrapped_into(&mut v363_7_write,&((v364_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v363_7_write);
          compose(&(v362_5),&(v363_7))
        };
        drop(v362_5);
        let v362_9: Space = intersect(&(*CONSTANT_2),&(v362_2));
        drop(v362_2);
        let v362_10: Space = if has_head(&(v362_9)) { singleton(&[]) } else { Space::new() };
        drop(v362_9);
        let v362_12: Space = if (&(v362_10)).is_empty() { Space::new() } else {
          let v367_6: Path = concat_path(&(v361_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v367_11 = Space::new();
          let mut v367_11_write = v367_11.write_zipper();
          for v367_11_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v367_11_byte);
            {
            let v368_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v368_3: Space = intersect(&(*CONSTANT_2),&(v368_2));
            let v368_4: Space = if has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
            drop(v368_3);
            let v368_5: Space = subtract(&(*CONSTANT_1),&(v368_4));
            drop(v368_4);
            let v368_8: Space = if (&(v368_5)).is_empty() { Space::new() } else {
              let v369_6: Path = concat_path(&(v367_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v369_7: Space = routine_32(c, &(v369_6), &(*p1), &v359_21_cursor);
              compose(&(v368_5),&(v369_7))
            };
            drop(v368_5);
            let v368_9: Space = intersect(&(*CONSTANT_2),&(v368_2));
            drop(v368_2);
            let v368_10: Space = if has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
            drop(v368_9);
            let v368_12: Space = if (&(v368_10)).is_empty() { Space::new() } else {
              let v370_6: Path = concat_path(&(v367_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v370_11: Space = routine_19(c, &(v370_6), &(*p1), &v359_21_cursor);
              drop(v370_6);
              compose(&(v368_10),&(v370_11))
            };
            drop(v368_10);
            let v368_13: Space = unite(&(v368_8),&(v368_12));
            join_wrapped_into(&mut v367_11_write,&((v368_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v367_11_write);
          drop(v367_6);
          compose(&(v362_10),&(v367_11))
        };
        drop(v362_10);
        let v362_13: Space = unite(&(v362_8),&(v362_12));
        join_wrapped_into(&mut v361_7_write,&((v362_13).read_zipper()),&[]);
        }
        v359_21_cursor.ascend(1);
      }
      drop(v361_7_write);
      compose(&(v360_5),&(v361_7))
    };
    drop(v360_5);
    let v360_9: Space = intersect(&(*CONSTANT_2),&(v360_2));
    drop(v360_2);
    let v360_10: Space = if has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
    drop(v360_9);
    let v360_12: Space = if (&(v360_10)).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&v359_21_cursor.path()[v359_21_origin..(v359_21_origin + 1)]);
      let mut v371_11 = Space::new();
      let mut v371_11_write = v371_11.write_zipper();
      for v371_11_byte in v359_21_cursor.child_mask().iter() {
        v359_21_cursor.descend_to_existing_byte(v371_11_byte);
        {
        let v372_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v372_3: Space = intersect(&(*CONSTANT_2),&(v372_2));
        let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
        drop(v372_3);
        let v372_5: Space = subtract(&(*CONSTANT_1),&(v372_4));
        drop(v372_4);
        let v372_8: Space = if (&(v372_5)).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v371_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
          let mut v373_7 = Space::new();
          let mut v373_7_write = v373_7.write_zipper();
          for v373_7_byte in v359_21_cursor.child_mask().iter() {
            v359_21_cursor.descend_to_existing_byte(v373_7_byte);
            {
            let v374_2: Space = singleton(&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
            let v374_3: Space = intersect(&(*CONSTANT_2),&(v374_2));
            let v374_4: Space = if has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
            drop(v374_3);
            let v374_5: Space = subtract(&(*CONSTANT_1),&(v374_4));
            drop(v374_4);
            let v374_8: Space = if (&(v374_5)).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v373_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v375_7: Space = routine_32(c, &(v375_6), &(*p1), &v359_21_cursor);
              compose(&(v374_5),&(v375_7))
            };
            drop(v374_5);
            let v374_9: Space = intersect(&(*CONSTANT_2),&(v374_2));
            drop(v374_2);
            let v374_10: Space = if has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
            drop(v374_9);
            let v374_12: Space = if (&(v374_10)).is_empty() { Space::new() } else {
              let v376_6: Path = concat_path(&(v373_6),&v359_21_cursor.path()[(v359_21_origin + 2)..(v359_21_origin + 3)]);
              let v376_11: Space = routine_33(c, &(v376_6), &(*p1), &v359_21_cursor);
              drop(v376_6);
              compose(&(v374_10),&(v376_11))
            };
            drop(v374_10);
            let v374_13: Space = unite(&(v374_8),&(v374_12));
            join_wrapped_into(&mut v373_7_write,&((v374_13).read_zipper()),&[]);
            }
            v359_21_cursor.ascend(1);
          }
          drop(v373_7_write);
          compose(&(v372_5),&(v373_7))
        };
        drop(v372_5);
        let v372_9: Space = intersect(&(*CONSTANT_2),&(v372_2));
        drop(v372_2);
        let v372_10: Space = if has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
        drop(v372_9);
        let v372_11: Space = compose(&(v372_10),&v359_21_cursor);
        drop(v372_10);
        let v377_6: Path = concat_path(&(v371_6),&v359_21_cursor.path()[(v359_21_origin + 1)..(v359_21_origin + 2)]);
        let v372_12: Space = wrap(&(v372_11),&(v377_6));
        drop(v372_11);
        let v372_13: Space = wrap(&(v372_12),&(*p1));
        drop(v372_12);
        let v372_14: Space = unite(&(v372_8),&(v372_13));
        drop(v372_13);
        join_wrapped_into(&mut v371_11_write,&((v372_14).read_zipper()),&[]);
        }
        v359_21_cursor.ascend(1);
      }
      drop(v371_11_write);
      drop(v371_6);
      compose(&(v360_10),&(v371_11))
    };
    drop(v360_10);
    let v360_13: Space = unite(&(v360_8),&(v360_12));
    join_wrapped_into(&mut v359_21_write,&((v360_13).read_zipper()),&[]);
    }
    v359_21_cursor.ascend(1);
  }
  drop(v359_21_cursor);
  drop(v359_21_write);
  (v359_21).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v378_15 = Space::new();
  let mut v378_15_write = v378_15.write_zipper();
  let mut v378_15_cursor = (*s0).read_zipper();
  let v378_15_origin = v378_15_cursor.path().len();
  for v378_15_byte in v378_15_cursor.child_mask().iter() {
    v378_15_cursor.descend_to_existing_byte(v378_15_byte);
    {
    let v379_2: Space = singleton(&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
    let v379_3: Space = intersect(&(*CONSTANT_2),&(v379_2));
    let v379_4: Space = if has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
    drop(v379_3);
    let v379_5: Space = subtract(&(*CONSTANT_1),&(v379_4));
    drop(v379_4);
    let v379_8: Space = if (&(v379_5)).is_empty() { Space::new() } else {
      let v380_6: Path = concat_path(&(*p0),&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
      let mut v380_7 = Space::new();
      let mut v380_7_write = v380_7.write_zipper();
      for v380_7_byte in v378_15_cursor.child_mask().iter() {
        v378_15_cursor.descend_to_existing_byte(v380_7_byte);
        {
        let v381_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
        let v381_3: Space = intersect(&(*CONSTANT_2),&(v381_2));
        let v381_4: Space = if has_head(&(v381_3)) { singleton(&[]) } else { Space::new() };
        drop(v381_3);
        let v381_5: Space = subtract(&(*CONSTANT_1),&(v381_4));
        drop(v381_4);
        let v381_8: Space = if (&(v381_5)).is_empty() { Space::new() } else {
          let v382_6: Path = concat_path(&(v380_6),&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
          let mut v382_7 = Space::new();
          let mut v382_7_write = v382_7.write_zipper();
          for v382_7_byte in v378_15_cursor.child_mask().iter() {
            v378_15_cursor.descend_to_existing_byte(v382_7_byte);
            {
            let v383_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
            let v383_3: Space = intersect(&(*CONSTANT_2),&(v383_2));
            let v383_4: Space = if has_head(&(v383_3)) { singleton(&[]) } else { Space::new() };
            drop(v383_3);
            let v383_5: Space = subtract(&(*CONSTANT_1),&(v383_4));
            drop(v383_4);
            let v383_8: Space = if (&(v383_5)).is_empty() { Space::new() } else {
              let v384_6: Path = concat_path(&(v382_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v384_7: Space = routine_32(c, &(v384_6), &(*p1), &v378_15_cursor);
              compose(&(v383_5),&(v384_7))
            };
            drop(v383_5);
            let v383_9: Space = intersect(&(*CONSTANT_2),&(v383_2));
            drop(v383_2);
            let v383_10: Space = if has_head(&(v383_9)) { singleton(&[]) } else { Space::new() };
            drop(v383_9);
            let v383_12: Space = if (&(v383_10)).is_empty() { Space::new() } else {
              let v385_6: Path = concat_path(&(v382_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v385_11: Space = routine_33(c, &(v385_6), &(*p1), &v378_15_cursor);
              drop(v385_6);
              compose(&(v383_10),&(v385_11))
            };
            drop(v383_10);
            let v383_13: Space = unite(&(v383_8),&(v383_12));
            join_wrapped_into(&mut v382_7_write,&((v383_13).read_zipper()),&[]);
            }
            v378_15_cursor.ascend(1);
          }
          drop(v382_7_write);
          compose(&(v381_5),&(v382_7))
        };
        drop(v381_5);
        let v381_9: Space = intersect(&(*CONSTANT_2),&(v381_2));
        drop(v381_2);
        let v381_10: Space = if has_head(&(v381_9)) { singleton(&[]) } else { Space::new() };
        drop(v381_9);
        let v381_12: Space = if (&(v381_10)).is_empty() { Space::new() } else {
          let v386_6: Path = concat_path(&(v380_6),&v378_15_cursor.path()[(v378_15_origin + 1)..(v378_15_origin + 2)]);
          let mut v386_11 = Space::new();
          let mut v386_11_write = v386_11.write_zipper();
          for v386_11_byte in v378_15_cursor.child_mask().iter() {
            v378_15_cursor.descend_to_existing_byte(v386_11_byte);
            {
            let v387_2: Space = singleton(&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
            let v387_3: Space = intersect(&(*CONSTANT_2),&(v387_2));
            let v387_4: Space = if has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
            drop(v387_3);
            let v387_5: Space = subtract(&(*CONSTANT_1),&(v387_4));
            drop(v387_4);
            let v387_8: Space = if (&(v387_5)).is_empty() { Space::new() } else {
              let v388_6: Path = concat_path(&(v386_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v388_7: Space = routine_32(c, &(v388_6), &(*p1), &v378_15_cursor);
              compose(&(v387_5),&(v388_7))
            };
            drop(v387_5);
            let v387_9: Space = intersect(&(*CONSTANT_2),&(v387_2));
            drop(v387_2);
            let v387_10: Space = if has_head(&(v387_9)) { singleton(&[]) } else { Space::new() };
            drop(v387_9);
            let v387_12: Space = if (&(v387_10)).is_empty() { Space::new() } else {
              let v389_6: Path = concat_path(&(v386_6),&v378_15_cursor.path()[(v378_15_origin + 2)..(v378_15_origin + 3)]);
              let v389_11: Space = routine_19(c, &(v389_6), &(*p1), &v378_15_cursor);
              drop(v389_6);
              compose(&(v387_10),&(v389_11))
            };
            drop(v387_10);
            let v387_13: Space = unite(&(v387_8),&(v387_12));
            join_wrapped_into(&mut v386_11_write,&((v387_13).read_zipper()),&[]);
            }
            v378_15_cursor.ascend(1);
          }
          drop(v386_11_write);
          drop(v386_6);
          compose(&(v381_10),&(v386_11))
        };
        drop(v381_10);
        let v381_13: Space = unite(&(v381_8),&(v381_12));
        join_wrapped_into(&mut v380_7_write,&((v381_13).read_zipper()),&[]);
        }
        v378_15_cursor.ascend(1);
      }
      drop(v380_7_write);
      compose(&(v379_5),&(v380_7))
    };
    drop(v379_5);
    let v379_9: Space = intersect(&(*CONSTANT_2),&(v379_2));
    drop(v379_2);
    let v379_10: Space = if has_head(&(v379_9)) { singleton(&[]) } else { Space::new() };
    drop(v379_9);
    let v379_11: Space = compose(&(v379_10),&v378_15_cursor);
    drop(v379_10);
    let v390_6: Path = concat_path(&(*p0),&v378_15_cursor.path()[v378_15_origin..(v378_15_origin + 1)]);
    let v379_12: Space = wrap(&(v379_11),&(v390_6));
    drop(v379_11);
    let v379_13: Space = wrap(&(v379_12),&(*p1));
    drop(v379_12);
    let v379_14: Space = unite(&(v379_8),&(v379_13));
    drop(v379_13);
    join_wrapped_into(&mut v378_15_write,&((v379_14).read_zipper()),&[]);
    }
    v378_15_cursor.ascend(1);
  }
  drop(v378_15_cursor);
  drop(v378_15_write);
  (v378_15).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let v391_3: Space = wrap(&(*s0),&(*p0));
  let v391_4: Space = wrap(&(v391_3),&(*p1));
  drop(v391_3);
  (v391_4).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v392_16 = Space::new();
  let mut v392_16_write = v392_16.write_zipper();
  let mut v392_16_cursor = (*s0).read_zipper();
  let v392_16_origin = v392_16_cursor.path().len();
  for v392_16_byte in v392_16_cursor.child_mask().iter() {
    v392_16_cursor.descend_to_existing_byte(v392_16_byte);
    {
    let v393_2: Space = singleton(&v392_16_cursor.path()[v392_16_origin..(v392_16_origin + 1)]);
    let v393_3: Space = intersect(&(*CONSTANT_2),&(v393_2));
    let v393_4: Space = if has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
    drop(v393_3);
    let v393_5: Space = subtract(&(*CONSTANT_1),&(v393_4));
    drop(v393_4);
    let v393_8: Space = if (&(v393_5)).is_empty() { Space::new() } else {
      let v394_6: Path = concat_path(&(*p0),&v392_16_cursor.path()[v392_16_origin..(v392_16_origin + 1)]);
      let mut v394_7 = Space::new();
      let mut v394_7_write = v394_7.write_zipper();
      for v394_7_byte in v392_16_cursor.child_mask().iter() {
        v392_16_cursor.descend_to_existing_byte(v394_7_byte);
        {
        let v395_2: Space = singleton(&v392_16_cursor.path()[(v392_16_origin + 1)..(v392_16_origin + 2)]);
        let v395_3: Space = intersect(&(*CONSTANT_2),&(v395_2));
        let v395_4: Space = if has_head(&(v395_3)) { singleton(&[]) } else { Space::new() };
        drop(v395_3);
        let v395_5: Space = subtract(&(*CONSTANT_1),&(v395_4));
        drop(v395_4);
        let v395_7: Space = if (&(v395_5)).is_empty() { Space::new() } else {
          let mut v396_6 = Space::new();
          let mut v396_6_write = v396_6.write_zipper();
          for v396_6_byte in v392_16_cursor.child_mask().iter() {
            v392_16_cursor.descend_to_existing_byte(v396_6_byte);
            {
            let v397_2: Space = Space::new();
            join_wrapped_into(&mut v396_6_write,&((v397_2).read_zipper()),&[]);
            }
            v392_16_cursor.ascend(1);
          }
          drop(v396_6_write);
          compose(&(v395_5),&(v396_6))
        };
        drop(v395_5);
        let v395_8: Space = intersect(&(*CONSTANT_2),&(v395_2));
        drop(v395_2);
        let v395_9: Space = if has_head(&(v395_8)) { singleton(&[]) } else { Space::new() };
        drop(v395_8);
        let v395_12: Space = if (&(v395_9)).is_empty() { Space::new() } else {
          let v398_10: Path = concat_path(&(v394_6),&v392_16_cursor.path()[(v392_16_origin + 1)..(v392_16_origin + 2)]);
          let mut v398_11 = Space::new();
          let mut v398_11_write = v398_11.write_zipper();
          for v398_11_byte in v392_16_cursor.child_mask().iter() {
            v392_16_cursor.descend_to_existing_byte(v398_11_byte);
            {
            let v399_2: Space = singleton(&v392_16_cursor.path()[(v392_16_origin + 2)..(v392_16_origin + 3)]);
            let v399_3: Space = intersect(&(*CONSTANT_2),&(v399_2));
            drop(v399_2);
            let v399_4: Space = if has_head(&(v399_3)) { singleton(&[]) } else { Space::new() };
            drop(v399_3);
            let v399_7: Space = if (&(v399_4)).is_empty() { Space::new() } else {
              let v400_5: Path = concat_path(&(v398_10),&v392_16_cursor.path()[(v392_16_origin + 2)..(v392_16_origin + 3)]);
              let v400_6: Space = routine_3(c, &(v400_5), &v392_16_cursor, &(*s1));
              drop(v400_5);
              compose(&(v399_4),&(v400_6))
            };
            drop(v399_4);
            join_wrapped_into(&mut v398_11_write,&((v399_7).read_zipper()),&[]);
            }
            v392_16_cursor.ascend(1);
          }
          drop(v398_11_write);
          drop(v398_10);
          compose(&(v395_9),&(v398_11))
        };
        drop(v395_9);
        let v395_13: Space = unite(&(v395_7),&(v395_12));
        drop(v395_7);
        join_wrapped_into(&mut v394_7_write,&((v395_13).read_zipper()),&[]);
        }
        v392_16_cursor.ascend(1);
      }
      drop(v394_7_write);
      compose(&(v393_5),&(v394_7))
    };
    drop(v393_5);
    let v393_9: Space = intersect(&(*CONSTANT_2),&(v393_2));
    drop(v393_2);
    let v393_10: Space = if has_head(&(v393_9)) { singleton(&[]) } else { Space::new() };
    drop(v393_9);
    let v393_12: Space = if (&(v393_10)).is_empty() { Space::new() } else {
      let v401_6: Path = concat_path(&(*p0),&v392_16_cursor.path()[v392_16_origin..(v392_16_origin + 1)]);
      let mut v401_11 = Space::new();
      let mut v401_11_write = v401_11.write_zipper();
      for v401_11_byte in v392_16_cursor.child_mask().iter() {
        v392_16_cursor.descend_to_existing_byte(v401_11_byte);
        {
        let v402_2: Space = singleton(&v392_16_cursor.path()[(v392_16_origin + 1)..(v392_16_origin + 2)]);
        let v402_3: Space = intersect(&(*CONSTANT_2),&(v402_2));
        let v402_4: Space = if has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
        drop(v402_3);
        let v402_5: Space = subtract(&(*CONSTANT_1),&(v402_4));
        drop(v402_4);
        let v402_7: Space = if (&(v402_5)).is_empty() { Space::new() } else {
          let mut v403_6 = Space::new();
          let mut v403_6_write = v403_6.write_zipper();
          for v403_6_byte in v392_16_cursor.child_mask().iter() {
            v392_16_cursor.descend_to_existing_byte(v403_6_byte);
            {
            let v404_2: Space = Space::new();
            join_wrapped_into(&mut v403_6_write,&((v404_2).read_zipper()),&[]);
            }
            v392_16_cursor.ascend(1);
          }
          drop(v403_6_write);
          compose(&(v402_5),&(v403_6))
        };
        drop(v402_5);
        let v402_8: Space = intersect(&(*CONSTANT_2),&(v402_2));
        drop(v402_2);
        let v402_9: Space = if has_head(&(v402_8)) { singleton(&[]) } else { Space::new() };
        drop(v402_8);
        let v402_12: Space = if (&(v402_9)).is_empty() { Space::new() } else {
          let v405_10: Path = concat_path(&(v401_6),&v392_16_cursor.path()[(v392_16_origin + 1)..(v392_16_origin + 2)]);
          let mut v405_11 = Space::new();
          let mut v405_11_write = v405_11.write_zipper();
          for v405_11_byte in v392_16_cursor.child_mask().iter() {
            v392_16_cursor.descend_to_existing_byte(v405_11_byte);
            {
            let v406_2: Space = singleton(&v392_16_cursor.path()[(v392_16_origin + 2)..(v392_16_origin + 3)]);
            let v406_3: Space = intersect(&(*CONSTANT_2),&(v406_2));
            let v406_4: Space = if has_head(&(v406_3)) { singleton(&[]) } else { Space::new() };
            drop(v406_3);
            let v406_5: Space = subtract(&(*CONSTANT_1),&(v406_4));
            drop(v406_4);
            let v406_7: Space = if (&(v406_5)).is_empty() { Space::new() } else {
              let v407_6: Space = routine_4(c, &v392_16_cursor.path()[(v392_16_origin + 2)..(v392_16_origin + 3)], &(v405_10), &v392_16_cursor, &(*s1));
              compose(&(v406_5),&(v407_6))
            };
            drop(v406_5);
            let v406_8: Space = intersect(&(*CONSTANT_2),&(v406_2));
            drop(v406_2);
            let v406_9: Space = if has_head(&(v406_8)) { singleton(&[]) } else { Space::new() };
            drop(v406_8);
            let v406_11: Space = if (&(v406_9)).is_empty() { Space::new() } else {
              let v408_10: Space = routine_5(c, &v392_16_cursor.path()[(v392_16_origin + 2)..(v392_16_origin + 3)], &(v405_10), &v392_16_cursor, &(*s1));
              compose(&(v406_9),&(v408_10))
            };
            drop(v406_9);
            let v406_12: Space = unite(&(v406_7),&(v406_11));
            join_wrapped_into(&mut v405_11_write,&((v406_12).read_zipper()),&[]);
            }
            v392_16_cursor.ascend(1);
          }
          drop(v405_11_write);
          drop(v405_10);
          compose(&(v402_9),&(v405_11))
        };
        drop(v402_9);
        let v402_13: Space = unite(&(v402_7),&(v402_12));
        drop(v402_7);
        join_wrapped_into(&mut v401_11_write,&((v402_13).read_zipper()),&[]);
        }
        v392_16_cursor.ascend(1);
      }
      drop(v401_11_write);
      drop(v401_6);
      compose(&(v393_10),&(v401_11))
    };
    drop(v393_10);
    let v393_13: Space = unite(&(v393_8),&(v393_12));
    join_wrapped_into(&mut v392_16_write,&((v393_13).read_zipper()),&[]);
    }
    v392_16_cursor.ascend(1);
  }
  drop(v392_16_cursor);
  drop(v392_16_write);
  (v392_16).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v409_19 = Space::new();
  let mut v409_19_write = v409_19.write_zipper();
  let mut v409_19_cursor = (*s0).read_zipper();
  let v409_19_origin = v409_19_cursor.path().len();
  for v409_19_byte in v409_19_cursor.child_mask().iter() {
    v409_19_cursor.descend_to_existing_byte(v409_19_byte);
    {
    let v410_2: Space = singleton(&v409_19_cursor.path()[v409_19_origin..(v409_19_origin + 1)]);
    let v410_3: Space = intersect(&(*CONSTANT_2),&(v410_2));
    let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
    drop(v410_3);
    let v410_5: Space = subtract(&(*CONSTANT_1),&(v410_4));
    drop(v410_4);
    let v410_8: Space = if (&(v410_5)).is_empty() { Space::new() } else {
      let v411_6: Path = concat_path(&(*p0),&v409_19_cursor.path()[v409_19_origin..(v409_19_origin + 1)]);
      let mut v411_7 = Space::new();
      let mut v411_7_write = v411_7.write_zipper();
      for v411_7_byte in v409_19_cursor.child_mask().iter() {
        v409_19_cursor.descend_to_existing_byte(v411_7_byte);
        {
        let v412_2: Space = singleton(&v409_19_cursor.path()[(v409_19_origin + 1)..(v409_19_origin + 2)]);
        let v412_3: Space = intersect(&(*CONSTANT_2),&(v412_2));
        let v412_4: Space = if has_head(&(v412_3)) { singleton(&[]) } else { Space::new() };
        drop(v412_3);
        let v412_5: Space = subtract(&(*CONSTANT_1),&(v412_4));
        drop(v412_4);
        let v412_7: Space = if (&(v412_5)).is_empty() { Space::new() } else {
          let mut v413_6 = Space::new();
          let mut v413_6_write = v413_6.write_zipper();
          for v413_6_byte in v409_19_cursor.child_mask().iter() {
            v409_19_cursor.descend_to_existing_byte(v413_6_byte);
            {
            let v414_2: Space = Space::new();
            join_wrapped_into(&mut v413_6_write,&((v414_2).read_zipper()),&[]);
            }
            v409_19_cursor.ascend(1);
          }
          drop(v413_6_write);
          compose(&(v412_5),&(v413_6))
        };
        drop(v412_5);
        let v412_8: Space = intersect(&(*CONSTANT_2),&(v412_2));
        drop(v412_2);
        let v412_9: Space = if has_head(&(v412_8)) { singleton(&[]) } else { Space::new() };
        drop(v412_8);
        let v412_12: Space = if (&(v412_9)).is_empty() { Space::new() } else {
          let v415_10: Path = concat_path(&(v411_6),&v409_19_cursor.path()[(v409_19_origin + 1)..(v409_19_origin + 2)]);
          let mut v415_11 = Space::new();
          let mut v415_11_write = v415_11.write_zipper();
          for v415_11_byte in v409_19_cursor.child_mask().iter() {
            v409_19_cursor.descend_to_existing_byte(v415_11_byte);
            {
            let v416_2: Space = singleton(&v409_19_cursor.path()[(v409_19_origin + 2)..(v409_19_origin + 3)]);
            let v416_3: Space = intersect(&(*CONSTANT_2),&(v416_2));
            drop(v416_2);
            let v416_4: Space = if has_head(&(v416_3)) { singleton(&[]) } else { Space::new() };
            drop(v416_3);
            let v416_7: Space = if (&(v416_4)).is_empty() { Space::new() } else {
              let v417_5: Path = concat_path(&(v415_10),&v409_19_cursor.path()[(v409_19_origin + 2)..(v409_19_origin + 3)]);
              let v417_6: Space = routine_3(c, &(v417_5), &v409_19_cursor, &(*s1));
              drop(v417_5);
              compose(&(v416_4),&(v417_6))
            };
            drop(v416_4);
            join_wrapped_into(&mut v415_11_write,&((v416_7).read_zipper()),&[]);
            }
            v409_19_cursor.ascend(1);
          }
          drop(v415_11_write);
          drop(v415_10);
          compose(&(v412_9),&(v415_11))
        };
        drop(v412_9);
        let v412_13: Space = unite(&(v412_7),&(v412_12));
        drop(v412_7);
        join_wrapped_into(&mut v411_7_write,&((v412_13).read_zipper()),&[]);
        }
        v409_19_cursor.ascend(1);
      }
      drop(v411_7_write);
      compose(&(v410_5),&(v411_7))
    };
    drop(v410_5);
    let v410_9: Space = intersect(&(*CONSTANT_2),&(v410_2));
    drop(v410_2);
    let v410_10: Space = if has_head(&(v410_9)) { singleton(&[]) } else { Space::new() };
    drop(v410_9);
    let v410_12: Space = if (&(v410_10)).is_empty() { Space::new() } else {
      let v418_6: Path = concat_path(&(*p0),&v409_19_cursor.path()[v409_19_origin..(v409_19_origin + 1)]);
      let mut v418_11 = Space::new();
      let mut v418_11_write = v418_11.write_zipper();
      for v418_11_byte in v409_19_cursor.child_mask().iter() {
        v409_19_cursor.descend_to_existing_byte(v418_11_byte);
        {
        let v419_2: Space = singleton(&v409_19_cursor.path()[(v409_19_origin + 1)..(v409_19_origin + 2)]);
        let v419_3: Space = intersect(&(*CONSTANT_2),&(v419_2));
        let v419_4: Space = if has_head(&(v419_3)) { singleton(&[]) } else { Space::new() };
        drop(v419_3);
        let v419_5: Space = subtract(&(*CONSTANT_1),&(v419_4));
        drop(v419_4);
        let v419_7: Space = if (&(v419_5)).is_empty() { Space::new() } else {
          let mut v420_6 = Space::new();
          let mut v420_6_write = v420_6.write_zipper();
          for v420_6_byte in v409_19_cursor.child_mask().iter() {
            v409_19_cursor.descend_to_existing_byte(v420_6_byte);
            {
            let v421_2: Space = singleton(&v409_19_cursor.path()[(v409_19_origin + 2)..(v409_19_origin + 3)]);
            let v421_3: Space = intersect(&(*CONSTANT_2),&(v421_2));
            let v421_4: Space = if has_head(&(v421_3)) { singleton(&[]) } else { Space::new() };
            drop(v421_3);
            let v421_5: Space = subtract(&(*CONSTANT_1),&(v421_4));
            drop(v421_4);
            let v421_8: Space = if (&(v421_5)).is_empty() { Space::new() } else {
              let v422_7: Space = routine_8(c, &v409_19_cursor.path()[(v409_19_origin + 1)..(v409_19_origin + 3)], &(v418_6), &v409_19_cursor, &(*s1));
              compose(&(v421_5),&(v422_7))
            };
            drop(v421_5);
            let v421_9: Space = intersect(&(*CONSTANT_2),&(v421_2));
            drop(v421_2);
            let v421_10: Space = if has_head(&(v421_9)) { singleton(&[]) } else { Space::new() };
            drop(v421_9);
            let v421_12: Space = if (&(v421_10)).is_empty() { Space::new() } else {
              let v423_11: Space = routine_9(c, &v409_19_cursor.path()[(v409_19_origin + 1)..(v409_19_origin + 3)], &(v418_6), &v409_19_cursor, &(*s1));
              compose(&(v421_10),&(v423_11))
            };
            drop(v421_10);
            let v421_13: Space = unite(&(v421_8),&(v421_12));
            join_wrapped_into(&mut v420_6_write,&((v421_13).read_zipper()),&[]);
            }
            v409_19_cursor.ascend(1);
          }
          drop(v420_6_write);
          compose(&(v419_5),&(v420_6))
        };
        drop(v419_5);
        let v419_8: Space = intersect(&(*CONSTANT_2),&(v419_2));
        drop(v419_2);
        let v419_9: Space = if has_head(&(v419_8)) { singleton(&[]) } else { Space::new() };
        drop(v419_8);
        let v419_11: Space = if (&(v419_9)).is_empty() { Space::new() } else {
          let mut v424_10 = Space::new();
          let mut v424_10_write = v424_10.write_zipper();
          for v424_10_byte in v409_19_cursor.child_mask().iter() {
            v409_19_cursor.descend_to_existing_byte(v424_10_byte);
            {
            let v425_2: Space = singleton(&v409_19_cursor.path()[(v409_19_origin + 2)..(v409_19_origin + 3)]);
            let v425_3: Space = intersect(&(*CONSTANT_2),&(v425_2));
            let v425_4: Space = if has_head(&(v425_3)) { singleton(&[]) } else { Space::new() };
            drop(v425_3);
            let v425_5: Space = subtract(&(*CONSTANT_1),&(v425_4));
            drop(v425_4);
            let v425_8: Space = if (&(v425_5)).is_empty() { Space::new() } else {
              let v426_7: Space = routine_8(c, &v409_19_cursor.path()[(v409_19_origin + 1)..(v409_19_origin + 3)], &(v418_6), &v409_19_cursor, &(*s1));
              compose(&(v425_5),&(v426_7))
            };
            drop(v425_5);
            let v425_9: Space = intersect(&(*CONSTANT_2),&(v425_2));
            drop(v425_2);
            let v425_10: Space = if has_head(&(v425_9)) { singleton(&[]) } else { Space::new() };
            drop(v425_9);
            let v425_12: Space = if (&(v425_10)).is_empty() { Space::new() } else {
              let v427_11: Space = routine_10(c, &v409_19_cursor.path()[(v409_19_origin + 1)..(v409_19_origin + 3)], &(v418_6), &v409_19_cursor, &(*s1));
              compose(&(v425_10),&(v427_11))
            };
            drop(v425_10);
            let v425_13: Space = unite(&(v425_8),&(v425_12));
            join_wrapped_into(&mut v424_10_write,&((v425_13).read_zipper()),&[]);
            }
            v409_19_cursor.ascend(1);
          }
          drop(v424_10_write);
          compose(&(v419_9),&(v424_10))
        };
        drop(v419_9);
        let v419_12: Space = unite(&(v419_7),&(v419_11));
        join_wrapped_into(&mut v418_11_write,&((v419_12).read_zipper()),&[]);
        }
        v409_19_cursor.ascend(1);
      }
      drop(v418_11_write);
      drop(v418_6);
      compose(&(v410_10),&(v418_11))
    };
    drop(v410_10);
    let v410_13: Space = unite(&(v410_8),&(v410_12));
    join_wrapped_into(&mut v409_19_write,&((v410_13).read_zipper()),&[]);
    }
    v409_19_cursor.ascend(1);
  }
  drop(v409_19_cursor);
  drop(v409_19_write);
  (v409_19).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v428_28 = Space::new();
  let mut v428_28_write = v428_28.write_zipper();
  let mut v428_28_cursor = (*s0).read_zipper();
  let v428_28_origin = v428_28_cursor.path().len();
  for v428_28_byte in v428_28_cursor.child_mask().iter() {
    v428_28_cursor.descend_to_existing_byte(v428_28_byte);
    {
    let v429_2: Space = singleton(&v428_28_cursor.path()[v428_28_origin..(v428_28_origin + 1)]);
    let v429_3: Space = intersect(&(*CONSTANT_2),&(v429_2));
    let v429_4: Space = if has_head(&(v429_3)) { singleton(&[]) } else { Space::new() };
    drop(v429_3);
    let v429_5: Space = subtract(&(*CONSTANT_1),&(v429_4));
    drop(v429_4);
    let v429_8: Space = if (&(v429_5)).is_empty() { Space::new() } else {
      let v430_6: Path = concat_path(&(*p0),&v428_28_cursor.path()[v428_28_origin..(v428_28_origin + 1)]);
      let mut v430_7 = Space::new();
      let mut v430_7_write = v430_7.write_zipper();
      for v430_7_byte in v428_28_cursor.child_mask().iter() {
        v428_28_cursor.descend_to_existing_byte(v430_7_byte);
        {
        let v431_2: Space = singleton(&v428_28_cursor.path()[(v428_28_origin + 1)..(v428_28_origin + 2)]);
        let v431_3: Space = intersect(&(*CONSTANT_2),&(v431_2));
        let v431_4: Space = if has_head(&(v431_3)) { singleton(&[]) } else { Space::new() };
        drop(v431_3);
        let v431_5: Space = subtract(&(*CONSTANT_1),&(v431_4));
        drop(v431_4);
        let v431_8: Space = if (&(v431_5)).is_empty() { Space::new() } else {
          let v432_6: Path = concat_path(&(v430_6),&v428_28_cursor.path()[(v428_28_origin + 1)..(v428_28_origin + 2)]);
          let mut v432_7 = Space::new();
          let mut v432_7_write = v432_7.write_zipper();
          for v432_7_byte in v428_28_cursor.child_mask().iter() {
            v428_28_cursor.descend_to_existing_byte(v432_7_byte);
            {
            let v433_2: Space = singleton(&v428_28_cursor.path()[(v428_28_origin + 2)..(v428_28_origin + 3)]);
            let v433_3: Space = intersect(&(*CONSTANT_2),&(v433_2));
            let v433_4: Space = if has_head(&(v433_3)) { singleton(&[]) } else { Space::new() };
            drop(v433_3);
            let v433_5: Space = subtract(&(*CONSTANT_1),&(v433_4));
            drop(v433_4);
            let v433_8: Space = if (&(v433_5)).is_empty() { Space::new() } else {
              let v434_6: Path = concat_path(&(v432_6),&v428_28_cursor.path()[(v428_28_origin + 2)..(v428_28_origin + 3)]);
              let v434_7: Space = routine_34(c, &(v434_6), &(*p1), &v428_28_cursor, &(*s1));
              compose(&(v433_5),&(v434_7))
            };
            drop(v433_5);
            let v433_9: Space = intersect(&(*CONSTANT_2),&(v433_2));
            drop(v433_2);
            let v433_10: Space = if has_head(&(v433_9)) { singleton(&[]) } else { Space::new() };
            drop(v433_9);
            let v433_12: Space = if (&(v433_10)).is_empty() { Space::new() } else {
              let v435_6: Path = concat_path(&(v432_6),&v428_28_cursor.path()[(v428_28_origin + 2)..(v428_28_origin + 3)]);
              let v435_11: Space = routine_35(c, &(v435_6), &(*p1), &v428_28_cursor, &(*s1));
              drop(v435_6);
              compose(&(v433_10),&(v435_11))
            };
            drop(v433_10);
            let v433_13: Space = unite(&(v433_8),&(v433_12));
            join_wrapped_into(&mut v432_7_write,&((v433_13).read_zipper()),&[]);
            }
            v428_28_cursor.ascend(1);
          }
          drop(v432_7_write);
          compose(&(v431_5),&(v432_7))
        };
        drop(v431_5);
        let v431_9: Space = intersect(&(*CONSTANT_2),&(v431_2));
        drop(v431_2);
        let v431_10: Space = if has_head(&(v431_9)) { singleton(&[]) } else { Space::new() };
        drop(v431_9);
        let v431_12: Space = if (&(v431_10)).is_empty() { Space::new() } else {
          let v436_6: Path = concat_path(&(v430_6),&v428_28_cursor.path()[(v428_28_origin + 1)..(v428_28_origin + 2)]);
          let mut v436_11 = Space::new();
          let mut v436_11_write = v436_11.write_zipper();
          for v436_11_byte in v428_28_cursor.child_mask().iter() {
            v428_28_cursor.descend_to_existing_byte(v436_11_byte);
            {
            let v437_2: Space = singleton(&v428_28_cursor.path()[(v428_28_origin + 2)..(v428_28_origin + 3)]);
            let v437_3: Space = intersect(&(*CONSTANT_2),&(v437_2));
            let v437_4: Space = if has_head(&(v437_3)) { singleton(&[]) } else { Space::new() };
            drop(v437_3);
            let v437_5: Space = subtract(&(*CONSTANT_1),&(v437_4));
            drop(v437_4);
            let v437_8: Space = if (&(v437_5)).is_empty() { Space::new() } else {
              let v438_6: Path = concat_path(&(v436_6),&v428_28_cursor.path()[(v428_28_origin + 2)..(v428_28_origin + 3)]);
              let v438_7: Space = routine_34(c, &(v438_6), &(*p1), &v428_28_cursor, &(*s1));
              compose(&(v437_5),&(v438_7))
            };
            drop(v437_5);
            let v437_9: Space = intersect(&(*CONSTANT_2),&(v437_2));
            drop(v437_2);
            let v437_10: Space = if has_head(&(v437_9)) { singleton(&[]) } else { Space::new() };
            drop(v437_9);
            let v437_12: Space = if (&(v437_10)).is_empty() { Space::new() } else {
              let v439_6: Path = concat_path(&(v436_6),&v428_28_cursor.path()[(v428_28_origin + 2)..(v428_28_origin + 3)]);
              let v439_11: Space = routine_10(c, &(v439_6), &(*p1), &v428_28_cursor, &(*s1));
              drop(v439_6);
              compose(&(v437_10),&(v439_11))
            };
            drop(v437_10);
            let v437_13: Space = unite(&(v437_8),&(v437_12));
            join_wrapped_into(&mut v436_11_write,&((v437_13).read_zipper()),&[]);
            }
            v428_28_cursor.ascend(1);
          }
          drop(v436_11_write);
          drop(v436_6);
          compose(&(v431_10),&(v436_11))
        };
        drop(v431_10);
        let v431_13: Space = unite(&(v431_8),&(v431_12));
        join_wrapped_into(&mut v430_7_write,&((v431_13).read_zipper()),&[]);
        }
        v428_28_cursor.ascend(1);
      }
      drop(v430_7_write);
      compose(&(v429_5),&(v430_7))
    };
    drop(v429_5);
    let v429_9: Space = intersect(&(*CONSTANT_2),&(v429_2));
    drop(v429_2);
    let v429_10: Space = if has_head(&(v429_9)) { singleton(&[]) } else { Space::new() };
    drop(v429_9);
    let v429_13: Space = if (&(v429_10)).is_empty() { Space::new() } else {
      let v440_6: Path = concat_path(&(*p0),&v428_28_cursor.path()[v428_28_origin..(v428_28_origin + 1)]);
      let mut v440_12 = Space::new();
      let mut v440_12_write = v440_12.write_zipper();
      for v440_12_byte in v428_28_cursor.child_mask().iter() {
        v428_28_cursor.descend_to_existing_byte(v440_12_byte);
        {
        let v441_2: Space = singleton(&v428_28_cursor.path()[(v428_28_origin + 1)..(v428_28_origin + 2)]);
        let v441_3: Space = intersect(&(*CONSTANT_2),&(v441_2));
        let v441_4: Space = if has_head(&(v441_3)) { singleton(&[]) } else { Space::new() };
        drop(v441_3);
        let v441_5: Space = subtract(&(*CONSTANT_1),&(v441_4));
        drop(v441_4);
        let v441_8: Space = if (&(v441_5)).is_empty() { Space::new() } else {
          let v442_6: Path = concat_path(&(v440_6),&v428_28_cursor.path()[(v428_28_origin + 1)..(v428_28_origin + 2)]);
          let mut v442_7 = Space::new();
          let mut v442_7_write = v442_7.write_zipper();
          for v442_7_byte in v428_28_cursor.child_mask().iter() {
            v428_28_cursor.descend_to_existing_byte(v442_7_byte);
            {
            let v443_2: Space = singleton(&v428_28_cursor.path()[(v428_28_origin + 2)..(v428_28_origin + 3)]);
            let v443_3: Space = intersect(&(*CONSTANT_2),&(v443_2));
            let v443_4: Space = if has_head(&(v443_3)) { singleton(&[]) } else { Space::new() };
            drop(v443_3);
            let v443_5: Space = subtract(&(*CONSTANT_1),&(v443_4));
            drop(v443_4);
            let v443_8: Space = if (&(v443_5)).is_empty() { Space::new() } else {
              let v444_6: Path = concat_path(&(v442_6),&v428_28_cursor.path()[(v428_28_origin + 2)..(v428_28_origin + 3)]);
              let v444_7: Space = routine_34(c, &(v444_6), &(*p1), &v428_28_cursor, &(*s1));
              compose(&(v443_5),&(v444_7))
            };
            drop(v443_5);
            let v443_9: Space = intersect(&(*CONSTANT_2),&(v443_2));
            drop(v443_2);
            let v443_10: Space = if has_head(&(v443_9)) { singleton(&[]) } else { Space::new() };
            drop(v443_9);
            let v443_12: Space = if (&(v443_10)).is_empty() { Space::new() } else {
              let v445_6: Path = concat_path(&(v442_6),&v428_28_cursor.path()[(v428_28_origin + 2)..(v428_28_origin + 3)]);
              let v445_11: Space = routine_35(c, &(v445_6), &(*p1), &v428_28_cursor, &(*s1));
              drop(v445_6);
              compose(&(v443_10),&(v445_11))
            };
            drop(v443_10);
            let v443_13: Space = unite(&(v443_8),&(v443_12));
            join_wrapped_into(&mut v442_7_write,&((v443_13).read_zipper()),&[]);
            }
            v428_28_cursor.ascend(1);
          }
          drop(v442_7_write);
          drop(v442_6);
          compose(&(v441_5),&(v442_7))
        };
        drop(v441_5);
        let v441_9: Space = intersect(&(*CONSTANT_2),&(v441_2));
        drop(v441_2);
        let v441_10: Space = if has_head(&(v441_9)) { singleton(&[]) } else { Space::new() };
        drop(v441_9);
        let v441_13: Space = if (&(v441_10)).is_empty() { Space::new() } else {
          let mut v446_12 = Space::new();
          let mut v446_12_write = v446_12.write_zipper();
          let mut v446_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v428_28_cursor.path()[v428_28_origin..(v428_28_origin + 1)]),&v428_28_cursor.path()[(v428_28_origin + 1)..(v428_28_origin + 2)]);
          let v446_12_origin = v446_12_cursor.path().len();
          for v446_12_byte in v446_12_cursor.child_mask().iter() {
            v446_12_cursor.descend_to_existing_byte(v446_12_byte);
            {
            let v447_2: Space = singleton(&v446_12_cursor.path()[v446_12_origin..(v446_12_origin + 1)]);
            let v447_3: Space = intersect(&(*CONSTANT_2),&(v447_2));
            let v447_4: Space = if has_head(&(v447_3)) { singleton(&[]) } else { Space::new() };
            drop(v447_3);
            let v447_5: Space = subtract(&(*CONSTANT_1),&(v447_4));
            drop(v447_4);
            let v447_7: Space = if (&(v447_5)).is_empty() { Space::new() } else {
              let v448_6: Space = routine_13(c, &v446_12_cursor.path()[v446_12_origin..(v446_12_origin + 1)], &(*p1), &v446_12_cursor);
              compose(&(v447_5),&(v448_6))
            };
            drop(v447_5);
            let v447_8: Space = intersect(&(*CONSTANT_2),&(v447_2));
            drop(v447_2);
            let v447_9: Space = if has_head(&(v447_8)) { singleton(&[]) } else { Space::new() };
            drop(v447_8);
            let v447_11: Space = if (&(v447_9)).is_empty() { Space::new() } else {
              let v449_10: Space = routine_14(c, &v446_12_cursor.path()[v446_12_origin..(v446_12_origin + 1)], &(*p1), &v446_12_cursor);
              compose(&(v447_9),&(v449_10))
            };
            drop(v447_9);
            let v447_12: Space = unite(&(v447_7),&(v447_11));
            join_wrapped_into(&mut v446_12_write,&((v447_12).read_zipper()),&[]);
            }
            v446_12_cursor.ascend(1);
          }
          drop(v446_12_cursor);
          drop(v446_12_write);
          compose(&(v441_10),&(v446_12))
        };
        drop(v441_10);
        let v441_14: Space = unite(&(v441_8),&(v441_13));
        join_wrapped_into(&mut v440_12_write,&((v441_14).read_zipper()),&[]);
        }
        v428_28_cursor.ascend(1);
      }
      drop(v440_12_write);
      drop(v440_6);
      compose(&(v429_10),&(v440_12))
    };
    drop(v429_10);
    let v429_14: Space = unite(&(v429_8),&(v429_13));
    join_wrapped_into(&mut v428_28_write,&((v429_14).read_zipper()),&[]);
    }
    v428_28_cursor.ascend(1);
  }
  drop(v428_28_cursor);
  drop(v428_28_write);
  (v428_28).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v450_28 = Space::new();
  let mut v450_28_write = v450_28.write_zipper();
  let mut v450_28_cursor = (*s0).read_zipper();
  let v450_28_origin = v450_28_cursor.path().len();
  for v450_28_byte in v450_28_cursor.child_mask().iter() {
    v450_28_cursor.descend_to_existing_byte(v450_28_byte);
    {
    let v451_2: Space = singleton(&v450_28_cursor.path()[v450_28_origin..(v450_28_origin + 1)]);
    let v451_3: Space = intersect(&(*CONSTANT_2),&(v451_2));
    let v451_4: Space = if has_head(&(v451_3)) { singleton(&[]) } else { Space::new() };
    drop(v451_3);
    let v451_5: Space = subtract(&(*CONSTANT_1),&(v451_4));
    drop(v451_4);
    let v451_8: Space = if (&(v451_5)).is_empty() { Space::new() } else {
      let v452_6: Path = concat_path(&(*p0),&v450_28_cursor.path()[v450_28_origin..(v450_28_origin + 1)]);
      let mut v452_7 = Space::new();
      let mut v452_7_write = v452_7.write_zipper();
      for v452_7_byte in v450_28_cursor.child_mask().iter() {
        v450_28_cursor.descend_to_existing_byte(v452_7_byte);
        {
        let v453_2: Space = singleton(&v450_28_cursor.path()[(v450_28_origin + 1)..(v450_28_origin + 2)]);
        let v453_3: Space = intersect(&(*CONSTANT_2),&(v453_2));
        let v453_4: Space = if has_head(&(v453_3)) { singleton(&[]) } else { Space::new() };
        drop(v453_3);
        let v453_5: Space = subtract(&(*CONSTANT_1),&(v453_4));
        drop(v453_4);
        let v453_8: Space = if (&(v453_5)).is_empty() { Space::new() } else {
          let v454_6: Path = concat_path(&(v452_6),&v450_28_cursor.path()[(v450_28_origin + 1)..(v450_28_origin + 2)]);
          let mut v454_7 = Space::new();
          let mut v454_7_write = v454_7.write_zipper();
          for v454_7_byte in v450_28_cursor.child_mask().iter() {
            v450_28_cursor.descend_to_existing_byte(v454_7_byte);
            {
            let v455_2: Space = singleton(&v450_28_cursor.path()[(v450_28_origin + 2)..(v450_28_origin + 3)]);
            let v455_3: Space = intersect(&(*CONSTANT_2),&(v455_2));
            let v455_4: Space = if has_head(&(v455_3)) { singleton(&[]) } else { Space::new() };
            drop(v455_3);
            let v455_5: Space = subtract(&(*CONSTANT_1),&(v455_4));
            drop(v455_4);
            let v455_8: Space = if (&(v455_5)).is_empty() { Space::new() } else {
              let v456_6: Path = concat_path(&(v454_6),&v450_28_cursor.path()[(v450_28_origin + 2)..(v450_28_origin + 3)]);
              let v456_7: Space = routine_34(c, &(v456_6), &(*p1), &v450_28_cursor, &(*s1));
              compose(&(v455_5),&(v456_7))
            };
            drop(v455_5);
            let v455_9: Space = intersect(&(*CONSTANT_2),&(v455_2));
            drop(v455_2);
            let v455_10: Space = if has_head(&(v455_9)) { singleton(&[]) } else { Space::new() };
            drop(v455_9);
            let v455_12: Space = if (&(v455_10)).is_empty() { Space::new() } else {
              let v457_6: Path = concat_path(&(v454_6),&v450_28_cursor.path()[(v450_28_origin + 2)..(v450_28_origin + 3)]);
              let v457_11: Space = routine_35(c, &(v457_6), &(*p1), &v450_28_cursor, &(*s1));
              drop(v457_6);
              compose(&(v455_10),&(v457_11))
            };
            drop(v455_10);
            let v455_13: Space = unite(&(v455_8),&(v455_12));
            join_wrapped_into(&mut v454_7_write,&((v455_13).read_zipper()),&[]);
            }
            v450_28_cursor.ascend(1);
          }
          drop(v454_7_write);
          compose(&(v453_5),&(v454_7))
        };
        drop(v453_5);
        let v453_9: Space = intersect(&(*CONSTANT_2),&(v453_2));
        drop(v453_2);
        let v453_10: Space = if has_head(&(v453_9)) { singleton(&[]) } else { Space::new() };
        drop(v453_9);
        let v453_12: Space = if (&(v453_10)).is_empty() { Space::new() } else {
          let v458_6: Path = concat_path(&(v452_6),&v450_28_cursor.path()[(v450_28_origin + 1)..(v450_28_origin + 2)]);
          let mut v458_11 = Space::new();
          let mut v458_11_write = v458_11.write_zipper();
          for v458_11_byte in v450_28_cursor.child_mask().iter() {
            v450_28_cursor.descend_to_existing_byte(v458_11_byte);
            {
            let v459_2: Space = singleton(&v450_28_cursor.path()[(v450_28_origin + 2)..(v450_28_origin + 3)]);
            let v459_3: Space = intersect(&(*CONSTANT_2),&(v459_2));
            let v459_4: Space = if has_head(&(v459_3)) { singleton(&[]) } else { Space::new() };
            drop(v459_3);
            let v459_5: Space = subtract(&(*CONSTANT_1),&(v459_4));
            drop(v459_4);
            let v459_8: Space = if (&(v459_5)).is_empty() { Space::new() } else {
              let v460_6: Path = concat_path(&(v458_6),&v450_28_cursor.path()[(v450_28_origin + 2)..(v450_28_origin + 3)]);
              let v460_7: Space = routine_34(c, &(v460_6), &(*p1), &v450_28_cursor, &(*s1));
              compose(&(v459_5),&(v460_7))
            };
            drop(v459_5);
            let v459_9: Space = intersect(&(*CONSTANT_2),&(v459_2));
            drop(v459_2);
            let v459_10: Space = if has_head(&(v459_9)) { singleton(&[]) } else { Space::new() };
            drop(v459_9);
            let v459_12: Space = if (&(v459_10)).is_empty() { Space::new() } else {
              let v461_6: Path = concat_path(&(v458_6),&v450_28_cursor.path()[(v450_28_origin + 2)..(v450_28_origin + 3)]);
              let v461_11: Space = routine_10(c, &(v461_6), &(*p1), &v450_28_cursor, &(*s1));
              drop(v461_6);
              compose(&(v459_10),&(v461_11))
            };
            drop(v459_10);
            let v459_13: Space = unite(&(v459_8),&(v459_12));
            join_wrapped_into(&mut v458_11_write,&((v459_13).read_zipper()),&[]);
            }
            v450_28_cursor.ascend(1);
          }
          drop(v458_11_write);
          drop(v458_6);
          compose(&(v453_10),&(v458_11))
        };
        drop(v453_10);
        let v453_13: Space = unite(&(v453_8),&(v453_12));
        join_wrapped_into(&mut v452_7_write,&((v453_13).read_zipper()),&[]);
        }
        v450_28_cursor.ascend(1);
      }
      drop(v452_7_write);
      drop(v452_6);
      compose(&(v451_5),&(v452_7))
    };
    drop(v451_5);
    let v451_9: Space = intersect(&(*CONSTANT_2),&(v451_2));
    drop(v451_2);
    let v451_10: Space = if has_head(&(v451_9)) { singleton(&[]) } else { Space::new() };
    drop(v451_9);
    let v451_13: Space = if (&(v451_10)).is_empty() { Space::new() } else {
      let mut v462_12 = Space::new();
      let mut v462_12_write = v462_12.write_zipper();
      let mut v462_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v450_28_cursor.path()[v450_28_origin..(v450_28_origin + 1)]);
      let v462_12_origin = v462_12_cursor.path().len();
      for v462_12_byte in v462_12_cursor.child_mask().iter() {
        v462_12_cursor.descend_to_existing_byte(v462_12_byte);
        {
        let v463_2: Space = singleton(&v462_12_cursor.path()[v462_12_origin..(v462_12_origin + 1)]);
        let v463_3: Space = intersect(&(*CONSTANT_2),&(v463_2));
        let v463_4: Space = if has_head(&(v463_3)) { singleton(&[]) } else { Space::new() };
        drop(v463_3);
        let v463_5: Space = subtract(&(*CONSTANT_1),&(v463_4));
        drop(v463_4);
        let v463_7: Space = if (&(v463_5)).is_empty() { Space::new() } else {
          let mut v464_6 = Space::new();
          let mut v464_6_write = v464_6.write_zipper();
          for v464_6_byte in v462_12_cursor.child_mask().iter() {
            v462_12_cursor.descend_to_existing_byte(v464_6_byte);
            {
            let v465_2: Space = singleton(&v462_12_cursor.path()[(v462_12_origin + 1)..(v462_12_origin + 2)]);
            let v465_3: Space = intersect(&(*CONSTANT_2),&(v465_2));
            let v465_4: Space = if has_head(&(v465_3)) { singleton(&[]) } else { Space::new() };
            drop(v465_3);
            let v465_5: Space = subtract(&(*CONSTANT_1),&(v465_4));
            drop(v465_4);
            let v465_8: Space = if (&(v465_5)).is_empty() { Space::new() } else {
              let v466_7: Space = routine_17(c, &v462_12_cursor.path()[v462_12_origin..(v462_12_origin + 2)], &(*p1), &v462_12_cursor);
              compose(&(v465_5),&(v466_7))
            };
            drop(v465_5);
            let v465_9: Space = intersect(&(*CONSTANT_2),&(v465_2));
            drop(v465_2);
            let v465_10: Space = if has_head(&(v465_9)) { singleton(&[]) } else { Space::new() };
            drop(v465_9);
            let v465_12: Space = if (&(v465_10)).is_empty() { Space::new() } else {
              let v467_11: Space = routine_18(c, &v462_12_cursor.path()[v462_12_origin..(v462_12_origin + 2)], &(*p1), &v462_12_cursor);
              compose(&(v465_10),&(v467_11))
            };
            drop(v465_10);
            let v465_13: Space = unite(&(v465_8),&(v465_12));
            join_wrapped_into(&mut v464_6_write,&((v465_13).read_zipper()),&[]);
            }
            v462_12_cursor.ascend(1);
          }
          drop(v464_6_write);
          compose(&(v463_5),&(v464_6))
        };
        drop(v463_5);
        let v463_8: Space = intersect(&(*CONSTANT_2),&(v463_2));
        drop(v463_2);
        let v463_9: Space = if has_head(&(v463_8)) { singleton(&[]) } else { Space::new() };
        drop(v463_8);
        let v463_11: Space = if (&(v463_9)).is_empty() { Space::new() } else {
          let mut v468_10 = Space::new();
          let mut v468_10_write = v468_10.write_zipper();
          for v468_10_byte in v462_12_cursor.child_mask().iter() {
            v462_12_cursor.descend_to_existing_byte(v468_10_byte);
            {
            let v469_2: Space = singleton(&v462_12_cursor.path()[(v462_12_origin + 1)..(v462_12_origin + 2)]);
            let v469_3: Space = intersect(&(*CONSTANT_2),&(v469_2));
            let v469_4: Space = if has_head(&(v469_3)) { singleton(&[]) } else { Space::new() };
            drop(v469_3);
            let v469_5: Space = subtract(&(*CONSTANT_1),&(v469_4));
            drop(v469_4);
            let v469_8: Space = if (&(v469_5)).is_empty() { Space::new() } else {
              let v470_7: Space = routine_17(c, &v462_12_cursor.path()[v462_12_origin..(v462_12_origin + 2)], &(*p1), &v462_12_cursor);
              compose(&(v469_5),&(v470_7))
            };
            drop(v469_5);
            let v469_9: Space = intersect(&(*CONSTANT_2),&(v469_2));
            drop(v469_2);
            let v469_10: Space = if has_head(&(v469_9)) { singleton(&[]) } else { Space::new() };
            drop(v469_9);
            let v469_12: Space = if (&(v469_10)).is_empty() { Space::new() } else {
              let v471_11: Space = routine_19(c, &v462_12_cursor.path()[v462_12_origin..(v462_12_origin + 2)], &(*p1), &v462_12_cursor);
              compose(&(v469_10),&(v471_11))
            };
            drop(v469_10);
            let v469_13: Space = unite(&(v469_8),&(v469_12));
            join_wrapped_into(&mut v468_10_write,&((v469_13).read_zipper()),&[]);
            }
            v462_12_cursor.ascend(1);
          }
          drop(v468_10_write);
          compose(&(v463_9),&(v468_10))
        };
        drop(v463_9);
        let v463_12: Space = unite(&(v463_7),&(v463_11));
        join_wrapped_into(&mut v462_12_write,&((v463_12).read_zipper()),&[]);
        }
        v462_12_cursor.ascend(1);
      }
      drop(v462_12_cursor);
      drop(v462_12_write);
      compose(&(v451_10),&(v462_12))
    };
    drop(v451_10);
    let v451_14: Space = unite(&(v451_8),&(v451_13));
    join_wrapped_into(&mut v450_28_write,&((v451_14).read_zipper()),&[]);
    }
    v450_28_cursor.ascend(1);
  }
  drop(v450_28_cursor);
  drop(v450_28_write);
  (v450_28).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v472_21 = Space::new();
  let mut v472_21_write = v472_21.write_zipper();
  let mut v472_21_cursor = (*s0).read_zipper();
  let v472_21_origin = v472_21_cursor.path().len();
  for v472_21_byte in v472_21_cursor.child_mask().iter() {
    v472_21_cursor.descend_to_existing_byte(v472_21_byte);
    {
    let v473_2: Space = singleton(&v472_21_cursor.path()[v472_21_origin..(v472_21_origin + 1)]);
    let v473_3: Space = intersect(&(*CONSTANT_2),&(v473_2));
    let v473_4: Space = if has_head(&(v473_3)) { singleton(&[]) } else { Space::new() };
    drop(v473_3);
    let v473_5: Space = subtract(&(*CONSTANT_1),&(v473_4));
    drop(v473_4);
    let v473_8: Space = if (&(v473_5)).is_empty() { Space::new() } else {
      let v474_6: Path = concat_path(&(*p0),&v472_21_cursor.path()[v472_21_origin..(v472_21_origin + 1)]);
      let mut v474_7 = Space::new();
      let mut v474_7_write = v474_7.write_zipper();
      for v474_7_byte in v472_21_cursor.child_mask().iter() {
        v472_21_cursor.descend_to_existing_byte(v474_7_byte);
        {
        let v475_2: Space = singleton(&v472_21_cursor.path()[(v472_21_origin + 1)..(v472_21_origin + 2)]);
        let v475_3: Space = intersect(&(*CONSTANT_2),&(v475_2));
        let v475_4: Space = if has_head(&(v475_3)) { singleton(&[]) } else { Space::new() };
        drop(v475_3);
        let v475_5: Space = subtract(&(*CONSTANT_1),&(v475_4));
        drop(v475_4);
        let v475_8: Space = if (&(v475_5)).is_empty() { Space::new() } else {
          let v476_6: Path = concat_path(&(v474_6),&v472_21_cursor.path()[(v472_21_origin + 1)..(v472_21_origin + 2)]);
          let mut v476_7 = Space::new();
          let mut v476_7_write = v476_7.write_zipper();
          for v476_7_byte in v472_21_cursor.child_mask().iter() {
            v472_21_cursor.descend_to_existing_byte(v476_7_byte);
            {
            let v477_2: Space = singleton(&v472_21_cursor.path()[(v472_21_origin + 2)..(v472_21_origin + 3)]);
            let v477_3: Space = intersect(&(*CONSTANT_2),&(v477_2));
            let v477_4: Space = if has_head(&(v477_3)) { singleton(&[]) } else { Space::new() };
            drop(v477_3);
            let v477_5: Space = subtract(&(*CONSTANT_1),&(v477_4));
            drop(v477_4);
            let v477_8: Space = if (&(v477_5)).is_empty() { Space::new() } else {
              let v478_6: Path = concat_path(&(v476_6),&v472_21_cursor.path()[(v472_21_origin + 2)..(v472_21_origin + 3)]);
              let v478_7: Space = routine_36(c, &(v478_6), &(*p1), &v472_21_cursor);
              compose(&(v477_5),&(v478_7))
            };
            drop(v477_5);
            let v477_9: Space = intersect(&(*CONSTANT_2),&(v477_2));
            drop(v477_2);
            let v477_10: Space = if has_head(&(v477_9)) { singleton(&[]) } else { Space::new() };
            drop(v477_9);
            let v477_12: Space = if (&(v477_10)).is_empty() { Space::new() } else {
              let v479_6: Path = concat_path(&(v476_6),&v472_21_cursor.path()[(v472_21_origin + 2)..(v472_21_origin + 3)]);
              let v479_11: Space = routine_37(c, &(v479_6), &(*p1), &v472_21_cursor);
              drop(v479_6);
              compose(&(v477_10),&(v479_11))
            };
            drop(v477_10);
            let v477_13: Space = unite(&(v477_8),&(v477_12));
            join_wrapped_into(&mut v476_7_write,&((v477_13).read_zipper()),&[]);
            }
            v472_21_cursor.ascend(1);
          }
          drop(v476_7_write);
          compose(&(v475_5),&(v476_7))
        };
        drop(v475_5);
        let v475_9: Space = intersect(&(*CONSTANT_2),&(v475_2));
        drop(v475_2);
        let v475_10: Space = if has_head(&(v475_9)) { singleton(&[]) } else { Space::new() };
        drop(v475_9);
        let v475_12: Space = if (&(v475_10)).is_empty() { Space::new() } else {
          let v480_6: Path = concat_path(&(v474_6),&v472_21_cursor.path()[(v472_21_origin + 1)..(v472_21_origin + 2)]);
          let mut v480_11 = Space::new();
          let mut v480_11_write = v480_11.write_zipper();
          for v480_11_byte in v472_21_cursor.child_mask().iter() {
            v472_21_cursor.descend_to_existing_byte(v480_11_byte);
            {
            let v481_2: Space = singleton(&v472_21_cursor.path()[(v472_21_origin + 2)..(v472_21_origin + 3)]);
            let v481_3: Space = intersect(&(*CONSTANT_2),&(v481_2));
            let v481_4: Space = if has_head(&(v481_3)) { singleton(&[]) } else { Space::new() };
            drop(v481_3);
            let v481_5: Space = subtract(&(*CONSTANT_1),&(v481_4));
            drop(v481_4);
            let v481_8: Space = if (&(v481_5)).is_empty() { Space::new() } else {
              let v482_6: Path = concat_path(&(v480_6),&v472_21_cursor.path()[(v472_21_origin + 2)..(v472_21_origin + 3)]);
              let v482_7: Space = routine_36(c, &(v482_6), &(*p1), &v472_21_cursor);
              compose(&(v481_5),&(v482_7))
            };
            drop(v481_5);
            let v481_9: Space = intersect(&(*CONSTANT_2),&(v481_2));
            drop(v481_2);
            let v481_10: Space = if has_head(&(v481_9)) { singleton(&[]) } else { Space::new() };
            drop(v481_9);
            let v481_12: Space = if (&(v481_10)).is_empty() { Space::new() } else {
              let v483_6: Path = concat_path(&(v480_6),&v472_21_cursor.path()[(v472_21_origin + 2)..(v472_21_origin + 3)]);
              let v483_11: Space = routine_19(c, &(v483_6), &(*p1), &v472_21_cursor);
              drop(v483_6);
              compose(&(v481_10),&(v483_11))
            };
            drop(v481_10);
            let v481_13: Space = unite(&(v481_8),&(v481_12));
            join_wrapped_into(&mut v480_11_write,&((v481_13).read_zipper()),&[]);
            }
            v472_21_cursor.ascend(1);
          }
          drop(v480_11_write);
          drop(v480_6);
          compose(&(v475_10),&(v480_11))
        };
        drop(v475_10);
        let v475_13: Space = unite(&(v475_8),&(v475_12));
        join_wrapped_into(&mut v474_7_write,&((v475_13).read_zipper()),&[]);
        }
        v472_21_cursor.ascend(1);
      }
      drop(v474_7_write);
      compose(&(v473_5),&(v474_7))
    };
    drop(v473_5);
    let v473_9: Space = intersect(&(*CONSTANT_2),&(v473_2));
    drop(v473_2);
    let v473_10: Space = if has_head(&(v473_9)) { singleton(&[]) } else { Space::new() };
    drop(v473_9);
    let v473_12: Space = if (&(v473_10)).is_empty() { Space::new() } else {
      let v484_6: Path = concat_path(&(*p0),&v472_21_cursor.path()[v472_21_origin..(v472_21_origin + 1)]);
      let mut v484_11 = Space::new();
      let mut v484_11_write = v484_11.write_zipper();
      for v484_11_byte in v472_21_cursor.child_mask().iter() {
        v472_21_cursor.descend_to_existing_byte(v484_11_byte);
        {
        let v485_2: Space = singleton(&v472_21_cursor.path()[(v472_21_origin + 1)..(v472_21_origin + 2)]);
        let v485_3: Space = intersect(&(*CONSTANT_2),&(v485_2));
        let v485_4: Space = if has_head(&(v485_3)) { singleton(&[]) } else { Space::new() };
        drop(v485_3);
        let v485_5: Space = subtract(&(*CONSTANT_1),&(v485_4));
        drop(v485_4);
        let v485_8: Space = if (&(v485_5)).is_empty() { Space::new() } else {
          let v486_6: Path = concat_path(&(v484_6),&v472_21_cursor.path()[(v472_21_origin + 1)..(v472_21_origin + 2)]);
          let mut v486_7 = Space::new();
          let mut v486_7_write = v486_7.write_zipper();
          for v486_7_byte in v472_21_cursor.child_mask().iter() {
            v472_21_cursor.descend_to_existing_byte(v486_7_byte);
            {
            let v487_2: Space = singleton(&v472_21_cursor.path()[(v472_21_origin + 2)..(v472_21_origin + 3)]);
            let v487_3: Space = intersect(&(*CONSTANT_2),&(v487_2));
            let v487_4: Space = if has_head(&(v487_3)) { singleton(&[]) } else { Space::new() };
            drop(v487_3);
            let v487_5: Space = subtract(&(*CONSTANT_1),&(v487_4));
            drop(v487_4);
            let v487_8: Space = if (&(v487_5)).is_empty() { Space::new() } else {
              let v488_6: Path = concat_path(&(v486_6),&v472_21_cursor.path()[(v472_21_origin + 2)..(v472_21_origin + 3)]);
              let v488_7: Space = routine_36(c, &(v488_6), &(*p1), &v472_21_cursor);
              compose(&(v487_5),&(v488_7))
            };
            drop(v487_5);
            let v487_9: Space = intersect(&(*CONSTANT_2),&(v487_2));
            drop(v487_2);
            let v487_10: Space = if has_head(&(v487_9)) { singleton(&[]) } else { Space::new() };
            drop(v487_9);
            let v487_12: Space = if (&(v487_10)).is_empty() { Space::new() } else {
              let v489_6: Path = concat_path(&(v486_6),&v472_21_cursor.path()[(v472_21_origin + 2)..(v472_21_origin + 3)]);
              let v489_11: Space = routine_37(c, &(v489_6), &(*p1), &v472_21_cursor);
              drop(v489_6);
              compose(&(v487_10),&(v489_11))
            };
            drop(v487_10);
            let v487_13: Space = unite(&(v487_8),&(v487_12));
            join_wrapped_into(&mut v486_7_write,&((v487_13).read_zipper()),&[]);
            }
            v472_21_cursor.ascend(1);
          }
          drop(v486_7_write);
          compose(&(v485_5),&(v486_7))
        };
        drop(v485_5);
        let v485_9: Space = intersect(&(*CONSTANT_2),&(v485_2));
        drop(v485_2);
        let v485_10: Space = if has_head(&(v485_9)) { singleton(&[]) } else { Space::new() };
        drop(v485_9);
        let v485_11: Space = compose(&(v485_10),&v472_21_cursor);
        drop(v485_10);
        let v490_6: Path = concat_path(&(v484_6),&v472_21_cursor.path()[(v472_21_origin + 1)..(v472_21_origin + 2)]);
        let v485_12: Space = wrap(&(v485_11),&(v490_6));
        drop(v485_11);
        let v485_13: Space = wrap(&(v485_12),&(*p1));
        drop(v485_12);
        let v485_14: Space = unite(&(v485_8),&(v485_13));
        drop(v485_13);
        join_wrapped_into(&mut v484_11_write,&((v485_14).read_zipper()),&[]);
        }
        v472_21_cursor.ascend(1);
      }
      drop(v484_11_write);
      drop(v484_6);
      compose(&(v473_10),&(v484_11))
    };
    drop(v473_10);
    let v473_13: Space = unite(&(v473_8),&(v473_12));
    join_wrapped_into(&mut v472_21_write,&((v473_13).read_zipper()),&[]);
    }
    v472_21_cursor.ascend(1);
  }
  drop(v472_21_cursor);
  drop(v472_21_write);
  (v472_21).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v491_15 = Space::new();
  let mut v491_15_write = v491_15.write_zipper();
  let mut v491_15_cursor = (*s0).read_zipper();
  let v491_15_origin = v491_15_cursor.path().len();
  for v491_15_byte in v491_15_cursor.child_mask().iter() {
    v491_15_cursor.descend_to_existing_byte(v491_15_byte);
    {
    let v492_2: Space = singleton(&v491_15_cursor.path()[v491_15_origin..(v491_15_origin + 1)]);
    let v492_3: Space = intersect(&(*CONSTANT_2),&(v492_2));
    let v492_4: Space = if has_head(&(v492_3)) { singleton(&[]) } else { Space::new() };
    drop(v492_3);
    let v492_5: Space = subtract(&(*CONSTANT_1),&(v492_4));
    drop(v492_4);
    let v492_8: Space = if (&(v492_5)).is_empty() { Space::new() } else {
      let v493_6: Path = concat_path(&(*p0),&v491_15_cursor.path()[v491_15_origin..(v491_15_origin + 1)]);
      let mut v493_7 = Space::new();
      let mut v493_7_write = v493_7.write_zipper();
      for v493_7_byte in v491_15_cursor.child_mask().iter() {
        v491_15_cursor.descend_to_existing_byte(v493_7_byte);
        {
        let v494_2: Space = singleton(&v491_15_cursor.path()[(v491_15_origin + 1)..(v491_15_origin + 2)]);
        let v494_3: Space = intersect(&(*CONSTANT_2),&(v494_2));
        let v494_4: Space = if has_head(&(v494_3)) { singleton(&[]) } else { Space::new() };
        drop(v494_3);
        let v494_5: Space = subtract(&(*CONSTANT_1),&(v494_4));
        drop(v494_4);
        let v494_8: Space = if (&(v494_5)).is_empty() { Space::new() } else {
          let v495_6: Path = concat_path(&(v493_6),&v491_15_cursor.path()[(v491_15_origin + 1)..(v491_15_origin + 2)]);
          let mut v495_7 = Space::new();
          let mut v495_7_write = v495_7.write_zipper();
          for v495_7_byte in v491_15_cursor.child_mask().iter() {
            v491_15_cursor.descend_to_existing_byte(v495_7_byte);
            {
            let v496_2: Space = singleton(&v491_15_cursor.path()[(v491_15_origin + 2)..(v491_15_origin + 3)]);
            let v496_3: Space = intersect(&(*CONSTANT_2),&(v496_2));
            let v496_4: Space = if has_head(&(v496_3)) { singleton(&[]) } else { Space::new() };
            drop(v496_3);
            let v496_5: Space = subtract(&(*CONSTANT_1),&(v496_4));
            drop(v496_4);
            let v496_8: Space = if (&(v496_5)).is_empty() { Space::new() } else {
              let v497_6: Path = concat_path(&(v495_6),&v491_15_cursor.path()[(v491_15_origin + 2)..(v491_15_origin + 3)]);
              let v497_7: Space = routine_36(c, &(v497_6), &(*p1), &v491_15_cursor);
              compose(&(v496_5),&(v497_7))
            };
            drop(v496_5);
            let v496_9: Space = intersect(&(*CONSTANT_2),&(v496_2));
            drop(v496_2);
            let v496_10: Space = if has_head(&(v496_9)) { singleton(&[]) } else { Space::new() };
            drop(v496_9);
            let v496_12: Space = if (&(v496_10)).is_empty() { Space::new() } else {
              let v498_6: Path = concat_path(&(v495_6),&v491_15_cursor.path()[(v491_15_origin + 2)..(v491_15_origin + 3)]);
              let v498_11: Space = routine_37(c, &(v498_6), &(*p1), &v491_15_cursor);
              drop(v498_6);
              compose(&(v496_10),&(v498_11))
            };
            drop(v496_10);
            let v496_13: Space = unite(&(v496_8),&(v496_12));
            join_wrapped_into(&mut v495_7_write,&((v496_13).read_zipper()),&[]);
            }
            v491_15_cursor.ascend(1);
          }
          drop(v495_7_write);
          compose(&(v494_5),&(v495_7))
        };
        drop(v494_5);
        let v494_9: Space = intersect(&(*CONSTANT_2),&(v494_2));
        drop(v494_2);
        let v494_10: Space = if has_head(&(v494_9)) { singleton(&[]) } else { Space::new() };
        drop(v494_9);
        let v494_12: Space = if (&(v494_10)).is_empty() { Space::new() } else {
          let v499_6: Path = concat_path(&(v493_6),&v491_15_cursor.path()[(v491_15_origin + 1)..(v491_15_origin + 2)]);
          let mut v499_11 = Space::new();
          let mut v499_11_write = v499_11.write_zipper();
          for v499_11_byte in v491_15_cursor.child_mask().iter() {
            v491_15_cursor.descend_to_existing_byte(v499_11_byte);
            {
            let v500_2: Space = singleton(&v491_15_cursor.path()[(v491_15_origin + 2)..(v491_15_origin + 3)]);
            let v500_3: Space = intersect(&(*CONSTANT_2),&(v500_2));
            let v500_4: Space = if has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
            drop(v500_3);
            let v500_5: Space = subtract(&(*CONSTANT_1),&(v500_4));
            drop(v500_4);
            let v500_8: Space = if (&(v500_5)).is_empty() { Space::new() } else {
              let v501_6: Path = concat_path(&(v499_6),&v491_15_cursor.path()[(v491_15_origin + 2)..(v491_15_origin + 3)]);
              let v501_7: Space = routine_36(c, &(v501_6), &(*p1), &v491_15_cursor);
              compose(&(v500_5),&(v501_7))
            };
            drop(v500_5);
            let v500_9: Space = intersect(&(*CONSTANT_2),&(v500_2));
            drop(v500_2);
            let v500_10: Space = if has_head(&(v500_9)) { singleton(&[]) } else { Space::new() };
            drop(v500_9);
            let v500_12: Space = if (&(v500_10)).is_empty() { Space::new() } else {
              let v502_6: Path = concat_path(&(v499_6),&v491_15_cursor.path()[(v491_15_origin + 2)..(v491_15_origin + 3)]);
              let v502_11: Space = routine_19(c, &(v502_6), &(*p1), &v491_15_cursor);
              drop(v502_6);
              compose(&(v500_10),&(v502_11))
            };
            drop(v500_10);
            let v500_13: Space = unite(&(v500_8),&(v500_12));
            join_wrapped_into(&mut v499_11_write,&((v500_13).read_zipper()),&[]);
            }
            v491_15_cursor.ascend(1);
          }
          drop(v499_11_write);
          drop(v499_6);
          compose(&(v494_10),&(v499_11))
        };
        drop(v494_10);
        let v494_13: Space = unite(&(v494_8),&(v494_12));
        join_wrapped_into(&mut v493_7_write,&((v494_13).read_zipper()),&[]);
        }
        v491_15_cursor.ascend(1);
      }
      drop(v493_7_write);
      compose(&(v492_5),&(v493_7))
    };
    drop(v492_5);
    let v492_9: Space = intersect(&(*CONSTANT_2),&(v492_2));
    drop(v492_2);
    let v492_10: Space = if has_head(&(v492_9)) { singleton(&[]) } else { Space::new() };
    drop(v492_9);
    let v492_11: Space = compose(&(v492_10),&v491_15_cursor);
    drop(v492_10);
    let v503_6: Path = concat_path(&(*p0),&v491_15_cursor.path()[v491_15_origin..(v491_15_origin + 1)]);
    let v492_12: Space = wrap(&(v492_11),&(v503_6));
    drop(v492_11);
    let v492_13: Space = wrap(&(v492_12),&(*p1));
    drop(v492_12);
    let v492_14: Space = unite(&(v492_8),&(v492_13));
    drop(v492_13);
    join_wrapped_into(&mut v491_15_write,&((v492_14).read_zipper()),&[]);
    }
    v491_15_cursor.ascend(1);
  }
  drop(v491_15_cursor);
  drop(v491_15_write);
  (v491_15).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v504_28 = Space::new();
  let mut v504_28_write = v504_28.write_zipper();
  let mut v504_28_cursor = (*s0).read_zipper();
  let v504_28_origin = v504_28_cursor.path().len();
  for v504_28_byte in v504_28_cursor.child_mask().iter() {
    v504_28_cursor.descend_to_existing_byte(v504_28_byte);
    {
    let v505_2: Space = singleton(&v504_28_cursor.path()[v504_28_origin..(v504_28_origin + 1)]);
    let v505_3: Space = intersect(&(*CONSTANT_2),&(v505_2));
    let v505_4: Space = if has_head(&(v505_3)) { singleton(&[]) } else { Space::new() };
    drop(v505_3);
    let v505_5: Space = subtract(&(*CONSTANT_1),&(v505_4));
    drop(v505_4);
    let v505_8: Space = if (&(v505_5)).is_empty() { Space::new() } else {
      let v506_6: Path = concat_path(&(*p0),&v504_28_cursor.path()[v504_28_origin..(v504_28_origin + 1)]);
      let mut v506_7 = Space::new();
      let mut v506_7_write = v506_7.write_zipper();
      for v506_7_byte in v504_28_cursor.child_mask().iter() {
        v504_28_cursor.descend_to_existing_byte(v506_7_byte);
        {
        let v507_2: Space = singleton(&v504_28_cursor.path()[(v504_28_origin + 1)..(v504_28_origin + 2)]);
        let v507_3: Space = intersect(&(*CONSTANT_2),&(v507_2));
        let v507_4: Space = if has_head(&(v507_3)) { singleton(&[]) } else { Space::new() };
        drop(v507_3);
        let v507_5: Space = subtract(&(*CONSTANT_1),&(v507_4));
        drop(v507_4);
        let v507_8: Space = if (&(v507_5)).is_empty() { Space::new() } else {
          let v508_6: Path = concat_path(&(v506_6),&v504_28_cursor.path()[(v504_28_origin + 1)..(v504_28_origin + 2)]);
          let mut v508_7 = Space::new();
          let mut v508_7_write = v508_7.write_zipper();
          for v508_7_byte in v504_28_cursor.child_mask().iter() {
            v504_28_cursor.descend_to_existing_byte(v508_7_byte);
            {
            let v509_2: Space = singleton(&v504_28_cursor.path()[(v504_28_origin + 2)..(v504_28_origin + 3)]);
            let v509_3: Space = intersect(&(*CONSTANT_2),&(v509_2));
            let v509_4: Space = if has_head(&(v509_3)) { singleton(&[]) } else { Space::new() };
            drop(v509_3);
            let v509_5: Space = subtract(&(*CONSTANT_1),&(v509_4));
            drop(v509_4);
            let v509_8: Space = if (&(v509_5)).is_empty() { Space::new() } else {
              let v510_6: Path = concat_path(&(v508_6),&v504_28_cursor.path()[(v504_28_origin + 2)..(v504_28_origin + 3)]);
              let v510_7: Space = routine_38(c, &(v510_6), &(*p1), &v504_28_cursor, &(*s1));
              compose(&(v509_5),&(v510_7))
            };
            drop(v509_5);
            let v509_9: Space = intersect(&(*CONSTANT_2),&(v509_2));
            drop(v509_2);
            let v509_10: Space = if has_head(&(v509_9)) { singleton(&[]) } else { Space::new() };
            drop(v509_9);
            let v509_12: Space = if (&(v509_10)).is_empty() { Space::new() } else {
              let v511_6: Path = concat_path(&(v508_6),&v504_28_cursor.path()[(v504_28_origin + 2)..(v504_28_origin + 3)]);
              let v511_11: Space = routine_39(c, &(v511_6), &(*p1), &v504_28_cursor, &(*s1));
              drop(v511_6);
              compose(&(v509_10),&(v511_11))
            };
            drop(v509_10);
            let v509_13: Space = unite(&(v509_8),&(v509_12));
            join_wrapped_into(&mut v508_7_write,&((v509_13).read_zipper()),&[]);
            }
            v504_28_cursor.ascend(1);
          }
          drop(v508_7_write);
          compose(&(v507_5),&(v508_7))
        };
        drop(v507_5);
        let v507_9: Space = intersect(&(*CONSTANT_2),&(v507_2));
        drop(v507_2);
        let v507_10: Space = if has_head(&(v507_9)) { singleton(&[]) } else { Space::new() };
        drop(v507_9);
        let v507_12: Space = if (&(v507_10)).is_empty() { Space::new() } else {
          let v512_6: Path = concat_path(&(v506_6),&v504_28_cursor.path()[(v504_28_origin + 1)..(v504_28_origin + 2)]);
          let mut v512_11 = Space::new();
          let mut v512_11_write = v512_11.write_zipper();
          for v512_11_byte in v504_28_cursor.child_mask().iter() {
            v504_28_cursor.descend_to_existing_byte(v512_11_byte);
            {
            let v513_2: Space = singleton(&v504_28_cursor.path()[(v504_28_origin + 2)..(v504_28_origin + 3)]);
            let v513_3: Space = intersect(&(*CONSTANT_2),&(v513_2));
            let v513_4: Space = if has_head(&(v513_3)) { singleton(&[]) } else { Space::new() };
            drop(v513_3);
            let v513_5: Space = subtract(&(*CONSTANT_1),&(v513_4));
            drop(v513_4);
            let v513_8: Space = if (&(v513_5)).is_empty() { Space::new() } else {
              let v514_6: Path = concat_path(&(v512_6),&v504_28_cursor.path()[(v504_28_origin + 2)..(v504_28_origin + 3)]);
              let v514_7: Space = routine_38(c, &(v514_6), &(*p1), &v504_28_cursor, &(*s1));
              compose(&(v513_5),&(v514_7))
            };
            drop(v513_5);
            let v513_9: Space = intersect(&(*CONSTANT_2),&(v513_2));
            drop(v513_2);
            let v513_10: Space = if has_head(&(v513_9)) { singleton(&[]) } else { Space::new() };
            drop(v513_9);
            let v513_12: Space = if (&(v513_10)).is_empty() { Space::new() } else {
              let v515_6: Path = concat_path(&(v512_6),&v504_28_cursor.path()[(v504_28_origin + 2)..(v504_28_origin + 3)]);
              let v515_11: Space = routine_10(c, &(v515_6), &(*p1), &v504_28_cursor, &(*s1));
              drop(v515_6);
              compose(&(v513_10),&(v515_11))
            };
            drop(v513_10);
            let v513_13: Space = unite(&(v513_8),&(v513_12));
            join_wrapped_into(&mut v512_11_write,&((v513_13).read_zipper()),&[]);
            }
            v504_28_cursor.ascend(1);
          }
          drop(v512_11_write);
          drop(v512_6);
          compose(&(v507_10),&(v512_11))
        };
        drop(v507_10);
        let v507_13: Space = unite(&(v507_8),&(v507_12));
        join_wrapped_into(&mut v506_7_write,&((v507_13).read_zipper()),&[]);
        }
        v504_28_cursor.ascend(1);
      }
      drop(v506_7_write);
      compose(&(v505_5),&(v506_7))
    };
    drop(v505_5);
    let v505_9: Space = intersect(&(*CONSTANT_2),&(v505_2));
    drop(v505_2);
    let v505_10: Space = if has_head(&(v505_9)) { singleton(&[]) } else { Space::new() };
    drop(v505_9);
    let v505_13: Space = if (&(v505_10)).is_empty() { Space::new() } else {
      let v516_6: Path = concat_path(&(*p0),&v504_28_cursor.path()[v504_28_origin..(v504_28_origin + 1)]);
      let mut v516_12 = Space::new();
      let mut v516_12_write = v516_12.write_zipper();
      for v516_12_byte in v504_28_cursor.child_mask().iter() {
        v504_28_cursor.descend_to_existing_byte(v516_12_byte);
        {
        let v517_2: Space = singleton(&v504_28_cursor.path()[(v504_28_origin + 1)..(v504_28_origin + 2)]);
        let v517_3: Space = intersect(&(*CONSTANT_2),&(v517_2));
        let v517_4: Space = if has_head(&(v517_3)) { singleton(&[]) } else { Space::new() };
        drop(v517_3);
        let v517_5: Space = subtract(&(*CONSTANT_1),&(v517_4));
        drop(v517_4);
        let v517_8: Space = if (&(v517_5)).is_empty() { Space::new() } else {
          let v518_6: Path = concat_path(&(v516_6),&v504_28_cursor.path()[(v504_28_origin + 1)..(v504_28_origin + 2)]);
          let mut v518_7 = Space::new();
          let mut v518_7_write = v518_7.write_zipper();
          for v518_7_byte in v504_28_cursor.child_mask().iter() {
            v504_28_cursor.descend_to_existing_byte(v518_7_byte);
            {
            let v519_2: Space = singleton(&v504_28_cursor.path()[(v504_28_origin + 2)..(v504_28_origin + 3)]);
            let v519_3: Space = intersect(&(*CONSTANT_2),&(v519_2));
            let v519_4: Space = if has_head(&(v519_3)) { singleton(&[]) } else { Space::new() };
            drop(v519_3);
            let v519_5: Space = subtract(&(*CONSTANT_1),&(v519_4));
            drop(v519_4);
            let v519_8: Space = if (&(v519_5)).is_empty() { Space::new() } else {
              let v520_6: Path = concat_path(&(v518_6),&v504_28_cursor.path()[(v504_28_origin + 2)..(v504_28_origin + 3)]);
              let v520_7: Space = routine_38(c, &(v520_6), &(*p1), &v504_28_cursor, &(*s1));
              compose(&(v519_5),&(v520_7))
            };
            drop(v519_5);
            let v519_9: Space = intersect(&(*CONSTANT_2),&(v519_2));
            drop(v519_2);
            let v519_10: Space = if has_head(&(v519_9)) { singleton(&[]) } else { Space::new() };
            drop(v519_9);
            let v519_12: Space = if (&(v519_10)).is_empty() { Space::new() } else {
              let v521_6: Path = concat_path(&(v518_6),&v504_28_cursor.path()[(v504_28_origin + 2)..(v504_28_origin + 3)]);
              let v521_11: Space = routine_39(c, &(v521_6), &(*p1), &v504_28_cursor, &(*s1));
              drop(v521_6);
              compose(&(v519_10),&(v521_11))
            };
            drop(v519_10);
            let v519_13: Space = unite(&(v519_8),&(v519_12));
            join_wrapped_into(&mut v518_7_write,&((v519_13).read_zipper()),&[]);
            }
            v504_28_cursor.ascend(1);
          }
          drop(v518_7_write);
          drop(v518_6);
          compose(&(v517_5),&(v518_7))
        };
        drop(v517_5);
        let v517_9: Space = intersect(&(*CONSTANT_2),&(v517_2));
        drop(v517_2);
        let v517_10: Space = if has_head(&(v517_9)) { singleton(&[]) } else { Space::new() };
        drop(v517_9);
        let v517_13: Space = if (&(v517_10)).is_empty() { Space::new() } else {
          let mut v522_12 = Space::new();
          let mut v522_12_write = v522_12.write_zipper();
          let mut v522_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v504_28_cursor.path()[v504_28_origin..(v504_28_origin + 1)]),&v504_28_cursor.path()[(v504_28_origin + 1)..(v504_28_origin + 2)]);
          let v522_12_origin = v522_12_cursor.path().len();
          for v522_12_byte in v522_12_cursor.child_mask().iter() {
            v522_12_cursor.descend_to_existing_byte(v522_12_byte);
            {
            let v523_2: Space = singleton(&v522_12_cursor.path()[v522_12_origin..(v522_12_origin + 1)]);
            let v523_3: Space = intersect(&(*CONSTANT_2),&(v523_2));
            let v523_4: Space = if has_head(&(v523_3)) { singleton(&[]) } else { Space::new() };
            drop(v523_3);
            let v523_5: Space = subtract(&(*CONSTANT_1),&(v523_4));
            drop(v523_4);
            let v523_7: Space = if (&(v523_5)).is_empty() { Space::new() } else {
              let v524_6: Space = routine_13(c, &v522_12_cursor.path()[v522_12_origin..(v522_12_origin + 1)], &(*p1), &v522_12_cursor);
              compose(&(v523_5),&(v524_6))
            };
            drop(v523_5);
            let v523_8: Space = intersect(&(*CONSTANT_2),&(v523_2));
            drop(v523_2);
            let v523_9: Space = if has_head(&(v523_8)) { singleton(&[]) } else { Space::new() };
            drop(v523_8);
            let v523_11: Space = if (&(v523_9)).is_empty() { Space::new() } else {
              let v525_10: Space = routine_14(c, &v522_12_cursor.path()[v522_12_origin..(v522_12_origin + 1)], &(*p1), &v522_12_cursor);
              compose(&(v523_9),&(v525_10))
            };
            drop(v523_9);
            let v523_12: Space = unite(&(v523_7),&(v523_11));
            join_wrapped_into(&mut v522_12_write,&((v523_12).read_zipper()),&[]);
            }
            v522_12_cursor.ascend(1);
          }
          drop(v522_12_cursor);
          drop(v522_12_write);
          compose(&(v517_10),&(v522_12))
        };
        drop(v517_10);
        let v517_14: Space = unite(&(v517_8),&(v517_13));
        join_wrapped_into(&mut v516_12_write,&((v517_14).read_zipper()),&[]);
        }
        v504_28_cursor.ascend(1);
      }
      drop(v516_12_write);
      drop(v516_6);
      compose(&(v505_10),&(v516_12))
    };
    drop(v505_10);
    let v505_14: Space = unite(&(v505_8),&(v505_13));
    join_wrapped_into(&mut v504_28_write,&((v505_14).read_zipper()),&[]);
    }
    v504_28_cursor.ascend(1);
  }
  drop(v504_28_cursor);
  drop(v504_28_write);
  (v504_28).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v526_28 = Space::new();
  let mut v526_28_write = v526_28.write_zipper();
  let mut v526_28_cursor = (*s0).read_zipper();
  let v526_28_origin = v526_28_cursor.path().len();
  for v526_28_byte in v526_28_cursor.child_mask().iter() {
    v526_28_cursor.descend_to_existing_byte(v526_28_byte);
    {
    let v527_2: Space = singleton(&v526_28_cursor.path()[v526_28_origin..(v526_28_origin + 1)]);
    let v527_3: Space = intersect(&(*CONSTANT_2),&(v527_2));
    let v527_4: Space = if has_head(&(v527_3)) { singleton(&[]) } else { Space::new() };
    drop(v527_3);
    let v527_5: Space = subtract(&(*CONSTANT_1),&(v527_4));
    drop(v527_4);
    let v527_8: Space = if (&(v527_5)).is_empty() { Space::new() } else {
      let v528_6: Path = concat_path(&(*p0),&v526_28_cursor.path()[v526_28_origin..(v526_28_origin + 1)]);
      let mut v528_7 = Space::new();
      let mut v528_7_write = v528_7.write_zipper();
      for v528_7_byte in v526_28_cursor.child_mask().iter() {
        v526_28_cursor.descend_to_existing_byte(v528_7_byte);
        {
        let v529_2: Space = singleton(&v526_28_cursor.path()[(v526_28_origin + 1)..(v526_28_origin + 2)]);
        let v529_3: Space = intersect(&(*CONSTANT_2),&(v529_2));
        let v529_4: Space = if has_head(&(v529_3)) { singleton(&[]) } else { Space::new() };
        drop(v529_3);
        let v529_5: Space = subtract(&(*CONSTANT_1),&(v529_4));
        drop(v529_4);
        let v529_8: Space = if (&(v529_5)).is_empty() { Space::new() } else {
          let v530_6: Path = concat_path(&(v528_6),&v526_28_cursor.path()[(v526_28_origin + 1)..(v526_28_origin + 2)]);
          let mut v530_7 = Space::new();
          let mut v530_7_write = v530_7.write_zipper();
          for v530_7_byte in v526_28_cursor.child_mask().iter() {
            v526_28_cursor.descend_to_existing_byte(v530_7_byte);
            {
            let v531_2: Space = singleton(&v526_28_cursor.path()[(v526_28_origin + 2)..(v526_28_origin + 3)]);
            let v531_3: Space = intersect(&(*CONSTANT_2),&(v531_2));
            let v531_4: Space = if has_head(&(v531_3)) { singleton(&[]) } else { Space::new() };
            drop(v531_3);
            let v531_5: Space = subtract(&(*CONSTANT_1),&(v531_4));
            drop(v531_4);
            let v531_8: Space = if (&(v531_5)).is_empty() { Space::new() } else {
              let v532_6: Path = concat_path(&(v530_6),&v526_28_cursor.path()[(v526_28_origin + 2)..(v526_28_origin + 3)]);
              let v532_7: Space = routine_38(c, &(v532_6), &(*p1), &v526_28_cursor, &(*s1));
              compose(&(v531_5),&(v532_7))
            };
            drop(v531_5);
            let v531_9: Space = intersect(&(*CONSTANT_2),&(v531_2));
            drop(v531_2);
            let v531_10: Space = if has_head(&(v531_9)) { singleton(&[]) } else { Space::new() };
            drop(v531_9);
            let v531_12: Space = if (&(v531_10)).is_empty() { Space::new() } else {
              let v533_6: Path = concat_path(&(v530_6),&v526_28_cursor.path()[(v526_28_origin + 2)..(v526_28_origin + 3)]);
              let v533_11: Space = routine_39(c, &(v533_6), &(*p1), &v526_28_cursor, &(*s1));
              drop(v533_6);
              compose(&(v531_10),&(v533_11))
            };
            drop(v531_10);
            let v531_13: Space = unite(&(v531_8),&(v531_12));
            join_wrapped_into(&mut v530_7_write,&((v531_13).read_zipper()),&[]);
            }
            v526_28_cursor.ascend(1);
          }
          drop(v530_7_write);
          compose(&(v529_5),&(v530_7))
        };
        drop(v529_5);
        let v529_9: Space = intersect(&(*CONSTANT_2),&(v529_2));
        drop(v529_2);
        let v529_10: Space = if has_head(&(v529_9)) { singleton(&[]) } else { Space::new() };
        drop(v529_9);
        let v529_12: Space = if (&(v529_10)).is_empty() { Space::new() } else {
          let v534_6: Path = concat_path(&(v528_6),&v526_28_cursor.path()[(v526_28_origin + 1)..(v526_28_origin + 2)]);
          let mut v534_11 = Space::new();
          let mut v534_11_write = v534_11.write_zipper();
          for v534_11_byte in v526_28_cursor.child_mask().iter() {
            v526_28_cursor.descend_to_existing_byte(v534_11_byte);
            {
            let v535_2: Space = singleton(&v526_28_cursor.path()[(v526_28_origin + 2)..(v526_28_origin + 3)]);
            let v535_3: Space = intersect(&(*CONSTANT_2),&(v535_2));
            let v535_4: Space = if has_head(&(v535_3)) { singleton(&[]) } else { Space::new() };
            drop(v535_3);
            let v535_5: Space = subtract(&(*CONSTANT_1),&(v535_4));
            drop(v535_4);
            let v535_8: Space = if (&(v535_5)).is_empty() { Space::new() } else {
              let v536_6: Path = concat_path(&(v534_6),&v526_28_cursor.path()[(v526_28_origin + 2)..(v526_28_origin + 3)]);
              let v536_7: Space = routine_38(c, &(v536_6), &(*p1), &v526_28_cursor, &(*s1));
              compose(&(v535_5),&(v536_7))
            };
            drop(v535_5);
            let v535_9: Space = intersect(&(*CONSTANT_2),&(v535_2));
            drop(v535_2);
            let v535_10: Space = if has_head(&(v535_9)) { singleton(&[]) } else { Space::new() };
            drop(v535_9);
            let v535_12: Space = if (&(v535_10)).is_empty() { Space::new() } else {
              let v537_6: Path = concat_path(&(v534_6),&v526_28_cursor.path()[(v526_28_origin + 2)..(v526_28_origin + 3)]);
              let v537_11: Space = routine_10(c, &(v537_6), &(*p1), &v526_28_cursor, &(*s1));
              drop(v537_6);
              compose(&(v535_10),&(v537_11))
            };
            drop(v535_10);
            let v535_13: Space = unite(&(v535_8),&(v535_12));
            join_wrapped_into(&mut v534_11_write,&((v535_13).read_zipper()),&[]);
            }
            v526_28_cursor.ascend(1);
          }
          drop(v534_11_write);
          drop(v534_6);
          compose(&(v529_10),&(v534_11))
        };
        drop(v529_10);
        let v529_13: Space = unite(&(v529_8),&(v529_12));
        join_wrapped_into(&mut v528_7_write,&((v529_13).read_zipper()),&[]);
        }
        v526_28_cursor.ascend(1);
      }
      drop(v528_7_write);
      drop(v528_6);
      compose(&(v527_5),&(v528_7))
    };
    drop(v527_5);
    let v527_9: Space = intersect(&(*CONSTANT_2),&(v527_2));
    drop(v527_2);
    let v527_10: Space = if has_head(&(v527_9)) { singleton(&[]) } else { Space::new() };
    drop(v527_9);
    let v527_13: Space = if (&(v527_10)).is_empty() { Space::new() } else {
      let mut v538_12 = Space::new();
      let mut v538_12_write = v538_12.write_zipper();
      let mut v538_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v526_28_cursor.path()[v526_28_origin..(v526_28_origin + 1)]);
      let v538_12_origin = v538_12_cursor.path().len();
      for v538_12_byte in v538_12_cursor.child_mask().iter() {
        v538_12_cursor.descend_to_existing_byte(v538_12_byte);
        {
        let v539_2: Space = singleton(&v538_12_cursor.path()[v538_12_origin..(v538_12_origin + 1)]);
        let v539_3: Space = intersect(&(*CONSTANT_2),&(v539_2));
        let v539_4: Space = if has_head(&(v539_3)) { singleton(&[]) } else { Space::new() };
        drop(v539_3);
        let v539_5: Space = subtract(&(*CONSTANT_1),&(v539_4));
        drop(v539_4);
        let v539_7: Space = if (&(v539_5)).is_empty() { Space::new() } else {
          let mut v540_6 = Space::new();
          let mut v540_6_write = v540_6.write_zipper();
          for v540_6_byte in v538_12_cursor.child_mask().iter() {
            v538_12_cursor.descend_to_existing_byte(v540_6_byte);
            {
            let v541_2: Space = singleton(&v538_12_cursor.path()[(v538_12_origin + 1)..(v538_12_origin + 2)]);
            let v541_3: Space = intersect(&(*CONSTANT_2),&(v541_2));
            let v541_4: Space = if has_head(&(v541_3)) { singleton(&[]) } else { Space::new() };
            drop(v541_3);
            let v541_5: Space = subtract(&(*CONSTANT_1),&(v541_4));
            drop(v541_4);
            let v541_8: Space = if (&(v541_5)).is_empty() { Space::new() } else {
              let v542_7: Space = routine_17(c, &v538_12_cursor.path()[v538_12_origin..(v538_12_origin + 2)], &(*p1), &v538_12_cursor);
              compose(&(v541_5),&(v542_7))
            };
            drop(v541_5);
            let v541_9: Space = intersect(&(*CONSTANT_2),&(v541_2));
            drop(v541_2);
            let v541_10: Space = if has_head(&(v541_9)) { singleton(&[]) } else { Space::new() };
            drop(v541_9);
            let v541_12: Space = if (&(v541_10)).is_empty() { Space::new() } else {
              let v543_11: Space = routine_18(c, &v538_12_cursor.path()[v538_12_origin..(v538_12_origin + 2)], &(*p1), &v538_12_cursor);
              compose(&(v541_10),&(v543_11))
            };
            drop(v541_10);
            let v541_13: Space = unite(&(v541_8),&(v541_12));
            join_wrapped_into(&mut v540_6_write,&((v541_13).read_zipper()),&[]);
            }
            v538_12_cursor.ascend(1);
          }
          drop(v540_6_write);
          compose(&(v539_5),&(v540_6))
        };
        drop(v539_5);
        let v539_8: Space = intersect(&(*CONSTANT_2),&(v539_2));
        drop(v539_2);
        let v539_9: Space = if has_head(&(v539_8)) { singleton(&[]) } else { Space::new() };
        drop(v539_8);
        let v539_11: Space = if (&(v539_9)).is_empty() { Space::new() } else {
          let mut v544_10 = Space::new();
          let mut v544_10_write = v544_10.write_zipper();
          for v544_10_byte in v538_12_cursor.child_mask().iter() {
            v538_12_cursor.descend_to_existing_byte(v544_10_byte);
            {
            let v545_2: Space = singleton(&v538_12_cursor.path()[(v538_12_origin + 1)..(v538_12_origin + 2)]);
            let v545_3: Space = intersect(&(*CONSTANT_2),&(v545_2));
            let v545_4: Space = if has_head(&(v545_3)) { singleton(&[]) } else { Space::new() };
            drop(v545_3);
            let v545_5: Space = subtract(&(*CONSTANT_1),&(v545_4));
            drop(v545_4);
            let v545_8: Space = if (&(v545_5)).is_empty() { Space::new() } else {
              let v546_7: Space = routine_17(c, &v538_12_cursor.path()[v538_12_origin..(v538_12_origin + 2)], &(*p1), &v538_12_cursor);
              compose(&(v545_5),&(v546_7))
            };
            drop(v545_5);
            let v545_9: Space = intersect(&(*CONSTANT_2),&(v545_2));
            drop(v545_2);
            let v545_10: Space = if has_head(&(v545_9)) { singleton(&[]) } else { Space::new() };
            drop(v545_9);
            let v545_12: Space = if (&(v545_10)).is_empty() { Space::new() } else {
              let v547_11: Space = routine_19(c, &v538_12_cursor.path()[v538_12_origin..(v538_12_origin + 2)], &(*p1), &v538_12_cursor);
              compose(&(v545_10),&(v547_11))
            };
            drop(v545_10);
            let v545_13: Space = unite(&(v545_8),&(v545_12));
            join_wrapped_into(&mut v544_10_write,&((v545_13).read_zipper()),&[]);
            }
            v538_12_cursor.ascend(1);
          }
          drop(v544_10_write);
          compose(&(v539_9),&(v544_10))
        };
        drop(v539_9);
        let v539_12: Space = unite(&(v539_7),&(v539_11));
        join_wrapped_into(&mut v538_12_write,&((v539_12).read_zipper()),&[]);
        }
        v538_12_cursor.ascend(1);
      }
      drop(v538_12_cursor);
      drop(v538_12_write);
      compose(&(v527_10),&(v538_12))
    };
    drop(v527_10);
    let v527_14: Space = unite(&(v527_8),&(v527_13));
    join_wrapped_into(&mut v526_28_write,&((v527_14).read_zipper()),&[]);
    }
    v526_28_cursor.ascend(1);
  }
  drop(v526_28_cursor);
  drop(v526_28_write);
  (v526_28).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v548_21 = Space::new();
  let mut v548_21_write = v548_21.write_zipper();
  let mut v548_21_cursor = (*s0).read_zipper();
  let v548_21_origin = v548_21_cursor.path().len();
  for v548_21_byte in v548_21_cursor.child_mask().iter() {
    v548_21_cursor.descend_to_existing_byte(v548_21_byte);
    {
    let v549_2: Space = singleton(&v548_21_cursor.path()[v548_21_origin..(v548_21_origin + 1)]);
    let v549_3: Space = intersect(&(*CONSTANT_2),&(v549_2));
    let v549_4: Space = if has_head(&(v549_3)) { singleton(&[]) } else { Space::new() };
    drop(v549_3);
    let v549_5: Space = subtract(&(*CONSTANT_1),&(v549_4));
    drop(v549_4);
    let v549_8: Space = if (&(v549_5)).is_empty() { Space::new() } else {
      let v550_6: Path = concat_path(&(*p0),&v548_21_cursor.path()[v548_21_origin..(v548_21_origin + 1)]);
      let mut v550_7 = Space::new();
      let mut v550_7_write = v550_7.write_zipper();
      for v550_7_byte in v548_21_cursor.child_mask().iter() {
        v548_21_cursor.descend_to_existing_byte(v550_7_byte);
        {
        let v551_2: Space = singleton(&v548_21_cursor.path()[(v548_21_origin + 1)..(v548_21_origin + 2)]);
        let v551_3: Space = intersect(&(*CONSTANT_2),&(v551_2));
        let v551_4: Space = if has_head(&(v551_3)) { singleton(&[]) } else { Space::new() };
        drop(v551_3);
        let v551_5: Space = subtract(&(*CONSTANT_1),&(v551_4));
        drop(v551_4);
        let v551_8: Space = if (&(v551_5)).is_empty() { Space::new() } else {
          let v552_6: Path = concat_path(&(v550_6),&v548_21_cursor.path()[(v548_21_origin + 1)..(v548_21_origin + 2)]);
          let mut v552_7 = Space::new();
          let mut v552_7_write = v552_7.write_zipper();
          for v552_7_byte in v548_21_cursor.child_mask().iter() {
            v548_21_cursor.descend_to_existing_byte(v552_7_byte);
            {
            let v553_2: Space = singleton(&v548_21_cursor.path()[(v548_21_origin + 2)..(v548_21_origin + 3)]);
            let v553_3: Space = intersect(&(*CONSTANT_2),&(v553_2));
            let v553_4: Space = if has_head(&(v553_3)) { singleton(&[]) } else { Space::new() };
            drop(v553_3);
            let v553_5: Space = subtract(&(*CONSTANT_1),&(v553_4));
            drop(v553_4);
            let v553_8: Space = if (&(v553_5)).is_empty() { Space::new() } else {
              let v554_6: Path = concat_path(&(v552_6),&v548_21_cursor.path()[(v548_21_origin + 2)..(v548_21_origin + 3)]);
              let v554_7: Space = routine_40(c, &(v554_6), &(*p1), &v548_21_cursor);
              compose(&(v553_5),&(v554_7))
            };
            drop(v553_5);
            let v553_9: Space = intersect(&(*CONSTANT_2),&(v553_2));
            drop(v553_2);
            let v553_10: Space = if has_head(&(v553_9)) { singleton(&[]) } else { Space::new() };
            drop(v553_9);
            let v553_12: Space = if (&(v553_10)).is_empty() { Space::new() } else {
              let v555_6: Path = concat_path(&(v552_6),&v548_21_cursor.path()[(v548_21_origin + 2)..(v548_21_origin + 3)]);
              let v555_11: Space = routine_41(c, &(v555_6), &(*p1), &v548_21_cursor);
              drop(v555_6);
              compose(&(v553_10),&(v555_11))
            };
            drop(v553_10);
            let v553_13: Space = unite(&(v553_8),&(v553_12));
            join_wrapped_into(&mut v552_7_write,&((v553_13).read_zipper()),&[]);
            }
            v548_21_cursor.ascend(1);
          }
          drop(v552_7_write);
          compose(&(v551_5),&(v552_7))
        };
        drop(v551_5);
        let v551_9: Space = intersect(&(*CONSTANT_2),&(v551_2));
        drop(v551_2);
        let v551_10: Space = if has_head(&(v551_9)) { singleton(&[]) } else { Space::new() };
        drop(v551_9);
        let v551_12: Space = if (&(v551_10)).is_empty() { Space::new() } else {
          let v556_6: Path = concat_path(&(v550_6),&v548_21_cursor.path()[(v548_21_origin + 1)..(v548_21_origin + 2)]);
          let mut v556_11 = Space::new();
          let mut v556_11_write = v556_11.write_zipper();
          for v556_11_byte in v548_21_cursor.child_mask().iter() {
            v548_21_cursor.descend_to_existing_byte(v556_11_byte);
            {
            let v557_2: Space = singleton(&v548_21_cursor.path()[(v548_21_origin + 2)..(v548_21_origin + 3)]);
            let v557_3: Space = intersect(&(*CONSTANT_2),&(v557_2));
            let v557_4: Space = if has_head(&(v557_3)) { singleton(&[]) } else { Space::new() };
            drop(v557_3);
            let v557_5: Space = subtract(&(*CONSTANT_1),&(v557_4));
            drop(v557_4);
            let v557_8: Space = if (&(v557_5)).is_empty() { Space::new() } else {
              let v558_6: Path = concat_path(&(v556_6),&v548_21_cursor.path()[(v548_21_origin + 2)..(v548_21_origin + 3)]);
              let v558_7: Space = routine_40(c, &(v558_6), &(*p1), &v548_21_cursor);
              compose(&(v557_5),&(v558_7))
            };
            drop(v557_5);
            let v557_9: Space = intersect(&(*CONSTANT_2),&(v557_2));
            drop(v557_2);
            let v557_10: Space = if has_head(&(v557_9)) { singleton(&[]) } else { Space::new() };
            drop(v557_9);
            let v557_12: Space = if (&(v557_10)).is_empty() { Space::new() } else {
              let v559_6: Path = concat_path(&(v556_6),&v548_21_cursor.path()[(v548_21_origin + 2)..(v548_21_origin + 3)]);
              let v559_11: Space = routine_19(c, &(v559_6), &(*p1), &v548_21_cursor);
              drop(v559_6);
              compose(&(v557_10),&(v559_11))
            };
            drop(v557_10);
            let v557_13: Space = unite(&(v557_8),&(v557_12));
            join_wrapped_into(&mut v556_11_write,&((v557_13).read_zipper()),&[]);
            }
            v548_21_cursor.ascend(1);
          }
          drop(v556_11_write);
          drop(v556_6);
          compose(&(v551_10),&(v556_11))
        };
        drop(v551_10);
        let v551_13: Space = unite(&(v551_8),&(v551_12));
        join_wrapped_into(&mut v550_7_write,&((v551_13).read_zipper()),&[]);
        }
        v548_21_cursor.ascend(1);
      }
      drop(v550_7_write);
      compose(&(v549_5),&(v550_7))
    };
    drop(v549_5);
    let v549_9: Space = intersect(&(*CONSTANT_2),&(v549_2));
    drop(v549_2);
    let v549_10: Space = if has_head(&(v549_9)) { singleton(&[]) } else { Space::new() };
    drop(v549_9);
    let v549_12: Space = if (&(v549_10)).is_empty() { Space::new() } else {
      let v560_6: Path = concat_path(&(*p0),&v548_21_cursor.path()[v548_21_origin..(v548_21_origin + 1)]);
      let mut v560_11 = Space::new();
      let mut v560_11_write = v560_11.write_zipper();
      for v560_11_byte in v548_21_cursor.child_mask().iter() {
        v548_21_cursor.descend_to_existing_byte(v560_11_byte);
        {
        let v561_2: Space = singleton(&v548_21_cursor.path()[(v548_21_origin + 1)..(v548_21_origin + 2)]);
        let v561_3: Space = intersect(&(*CONSTANT_2),&(v561_2));
        let v561_4: Space = if has_head(&(v561_3)) { singleton(&[]) } else { Space::new() };
        drop(v561_3);
        let v561_5: Space = subtract(&(*CONSTANT_1),&(v561_4));
        drop(v561_4);
        let v561_8: Space = if (&(v561_5)).is_empty() { Space::new() } else {
          let v562_6: Path = concat_path(&(v560_6),&v548_21_cursor.path()[(v548_21_origin + 1)..(v548_21_origin + 2)]);
          let mut v562_7 = Space::new();
          let mut v562_7_write = v562_7.write_zipper();
          for v562_7_byte in v548_21_cursor.child_mask().iter() {
            v548_21_cursor.descend_to_existing_byte(v562_7_byte);
            {
            let v563_2: Space = singleton(&v548_21_cursor.path()[(v548_21_origin + 2)..(v548_21_origin + 3)]);
            let v563_3: Space = intersect(&(*CONSTANT_2),&(v563_2));
            let v563_4: Space = if has_head(&(v563_3)) { singleton(&[]) } else { Space::new() };
            drop(v563_3);
            let v563_5: Space = subtract(&(*CONSTANT_1),&(v563_4));
            drop(v563_4);
            let v563_8: Space = if (&(v563_5)).is_empty() { Space::new() } else {
              let v564_6: Path = concat_path(&(v562_6),&v548_21_cursor.path()[(v548_21_origin + 2)..(v548_21_origin + 3)]);
              let v564_7: Space = routine_40(c, &(v564_6), &(*p1), &v548_21_cursor);
              compose(&(v563_5),&(v564_7))
            };
            drop(v563_5);
            let v563_9: Space = intersect(&(*CONSTANT_2),&(v563_2));
            drop(v563_2);
            let v563_10: Space = if has_head(&(v563_9)) { singleton(&[]) } else { Space::new() };
            drop(v563_9);
            let v563_12: Space = if (&(v563_10)).is_empty() { Space::new() } else {
              let v565_6: Path = concat_path(&(v562_6),&v548_21_cursor.path()[(v548_21_origin + 2)..(v548_21_origin + 3)]);
              let v565_11: Space = routine_41(c, &(v565_6), &(*p1), &v548_21_cursor);
              drop(v565_6);
              compose(&(v563_10),&(v565_11))
            };
            drop(v563_10);
            let v563_13: Space = unite(&(v563_8),&(v563_12));
            join_wrapped_into(&mut v562_7_write,&((v563_13).read_zipper()),&[]);
            }
            v548_21_cursor.ascend(1);
          }
          drop(v562_7_write);
          compose(&(v561_5),&(v562_7))
        };
        drop(v561_5);
        let v561_9: Space = intersect(&(*CONSTANT_2),&(v561_2));
        drop(v561_2);
        let v561_10: Space = if has_head(&(v561_9)) { singleton(&[]) } else { Space::new() };
        drop(v561_9);
        let v561_11: Space = compose(&(v561_10),&v548_21_cursor);
        drop(v561_10);
        let v566_6: Path = concat_path(&(v560_6),&v548_21_cursor.path()[(v548_21_origin + 1)..(v548_21_origin + 2)]);
        let v561_12: Space = wrap(&(v561_11),&(v566_6));
        drop(v561_11);
        let v561_13: Space = wrap(&(v561_12),&(*p1));
        drop(v561_12);
        let v561_14: Space = unite(&(v561_8),&(v561_13));
        drop(v561_13);
        join_wrapped_into(&mut v560_11_write,&((v561_14).read_zipper()),&[]);
        }
        v548_21_cursor.ascend(1);
      }
      drop(v560_11_write);
      drop(v560_6);
      compose(&(v549_10),&(v560_11))
    };
    drop(v549_10);
    let v549_13: Space = unite(&(v549_8),&(v549_12));
    join_wrapped_into(&mut v548_21_write,&((v549_13).read_zipper()),&[]);
    }
    v548_21_cursor.ascend(1);
  }
  drop(v548_21_cursor);
  drop(v548_21_write);
  (v548_21).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v567_15 = Space::new();
  let mut v567_15_write = v567_15.write_zipper();
  let mut v567_15_cursor = (*s0).read_zipper();
  let v567_15_origin = v567_15_cursor.path().len();
  for v567_15_byte in v567_15_cursor.child_mask().iter() {
    v567_15_cursor.descend_to_existing_byte(v567_15_byte);
    {
    let v568_2: Space = singleton(&v567_15_cursor.path()[v567_15_origin..(v567_15_origin + 1)]);
    let v568_3: Space = intersect(&(*CONSTANT_2),&(v568_2));
    let v568_4: Space = if has_head(&(v568_3)) { singleton(&[]) } else { Space::new() };
    drop(v568_3);
    let v568_5: Space = subtract(&(*CONSTANT_1),&(v568_4));
    drop(v568_4);
    let v568_8: Space = if (&(v568_5)).is_empty() { Space::new() } else {
      let v569_6: Path = concat_path(&(*p0),&v567_15_cursor.path()[v567_15_origin..(v567_15_origin + 1)]);
      let mut v569_7 = Space::new();
      let mut v569_7_write = v569_7.write_zipper();
      for v569_7_byte in v567_15_cursor.child_mask().iter() {
        v567_15_cursor.descend_to_existing_byte(v569_7_byte);
        {
        let v570_2: Space = singleton(&v567_15_cursor.path()[(v567_15_origin + 1)..(v567_15_origin + 2)]);
        let v570_3: Space = intersect(&(*CONSTANT_2),&(v570_2));
        let v570_4: Space = if has_head(&(v570_3)) { singleton(&[]) } else { Space::new() };
        drop(v570_3);
        let v570_5: Space = subtract(&(*CONSTANT_1),&(v570_4));
        drop(v570_4);
        let v570_8: Space = if (&(v570_5)).is_empty() { Space::new() } else {
          let v571_6: Path = concat_path(&(v569_6),&v567_15_cursor.path()[(v567_15_origin + 1)..(v567_15_origin + 2)]);
          let mut v571_7 = Space::new();
          let mut v571_7_write = v571_7.write_zipper();
          for v571_7_byte in v567_15_cursor.child_mask().iter() {
            v567_15_cursor.descend_to_existing_byte(v571_7_byte);
            {
            let v572_2: Space = singleton(&v567_15_cursor.path()[(v567_15_origin + 2)..(v567_15_origin + 3)]);
            let v572_3: Space = intersect(&(*CONSTANT_2),&(v572_2));
            let v572_4: Space = if has_head(&(v572_3)) { singleton(&[]) } else { Space::new() };
            drop(v572_3);
            let v572_5: Space = subtract(&(*CONSTANT_1),&(v572_4));
            drop(v572_4);
            let v572_8: Space = if (&(v572_5)).is_empty() { Space::new() } else {
              let v573_6: Path = concat_path(&(v571_6),&v567_15_cursor.path()[(v567_15_origin + 2)..(v567_15_origin + 3)]);
              let v573_7: Space = routine_40(c, &(v573_6), &(*p1), &v567_15_cursor);
              compose(&(v572_5),&(v573_7))
            };
            drop(v572_5);
            let v572_9: Space = intersect(&(*CONSTANT_2),&(v572_2));
            drop(v572_2);
            let v572_10: Space = if has_head(&(v572_9)) { singleton(&[]) } else { Space::new() };
            drop(v572_9);
            let v572_12: Space = if (&(v572_10)).is_empty() { Space::new() } else {
              let v574_6: Path = concat_path(&(v571_6),&v567_15_cursor.path()[(v567_15_origin + 2)..(v567_15_origin + 3)]);
              let v574_11: Space = routine_41(c, &(v574_6), &(*p1), &v567_15_cursor);
              drop(v574_6);
              compose(&(v572_10),&(v574_11))
            };
            drop(v572_10);
            let v572_13: Space = unite(&(v572_8),&(v572_12));
            join_wrapped_into(&mut v571_7_write,&((v572_13).read_zipper()),&[]);
            }
            v567_15_cursor.ascend(1);
          }
          drop(v571_7_write);
          compose(&(v570_5),&(v571_7))
        };
        drop(v570_5);
        let v570_9: Space = intersect(&(*CONSTANT_2),&(v570_2));
        drop(v570_2);
        let v570_10: Space = if has_head(&(v570_9)) { singleton(&[]) } else { Space::new() };
        drop(v570_9);
        let v570_12: Space = if (&(v570_10)).is_empty() { Space::new() } else {
          let v575_6: Path = concat_path(&(v569_6),&v567_15_cursor.path()[(v567_15_origin + 1)..(v567_15_origin + 2)]);
          let mut v575_11 = Space::new();
          let mut v575_11_write = v575_11.write_zipper();
          for v575_11_byte in v567_15_cursor.child_mask().iter() {
            v567_15_cursor.descend_to_existing_byte(v575_11_byte);
            {
            let v576_2: Space = singleton(&v567_15_cursor.path()[(v567_15_origin + 2)..(v567_15_origin + 3)]);
            let v576_3: Space = intersect(&(*CONSTANT_2),&(v576_2));
            let v576_4: Space = if has_head(&(v576_3)) { singleton(&[]) } else { Space::new() };
            drop(v576_3);
            let v576_5: Space = subtract(&(*CONSTANT_1),&(v576_4));
            drop(v576_4);
            let v576_8: Space = if (&(v576_5)).is_empty() { Space::new() } else {
              let v577_6: Path = concat_path(&(v575_6),&v567_15_cursor.path()[(v567_15_origin + 2)..(v567_15_origin + 3)]);
              let v577_7: Space = routine_40(c, &(v577_6), &(*p1), &v567_15_cursor);
              compose(&(v576_5),&(v577_7))
            };
            drop(v576_5);
            let v576_9: Space = intersect(&(*CONSTANT_2),&(v576_2));
            drop(v576_2);
            let v576_10: Space = if has_head(&(v576_9)) { singleton(&[]) } else { Space::new() };
            drop(v576_9);
            let v576_12: Space = if (&(v576_10)).is_empty() { Space::new() } else {
              let v578_6: Path = concat_path(&(v575_6),&v567_15_cursor.path()[(v567_15_origin + 2)..(v567_15_origin + 3)]);
              let v578_11: Space = routine_19(c, &(v578_6), &(*p1), &v567_15_cursor);
              drop(v578_6);
              compose(&(v576_10),&(v578_11))
            };
            drop(v576_10);
            let v576_13: Space = unite(&(v576_8),&(v576_12));
            join_wrapped_into(&mut v575_11_write,&((v576_13).read_zipper()),&[]);
            }
            v567_15_cursor.ascend(1);
          }
          drop(v575_11_write);
          drop(v575_6);
          compose(&(v570_10),&(v575_11))
        };
        drop(v570_10);
        let v570_13: Space = unite(&(v570_8),&(v570_12));
        join_wrapped_into(&mut v569_7_write,&((v570_13).read_zipper()),&[]);
        }
        v567_15_cursor.ascend(1);
      }
      drop(v569_7_write);
      compose(&(v568_5),&(v569_7))
    };
    drop(v568_5);
    let v568_9: Space = intersect(&(*CONSTANT_2),&(v568_2));
    drop(v568_2);
    let v568_10: Space = if has_head(&(v568_9)) { singleton(&[]) } else { Space::new() };
    drop(v568_9);
    let v568_11: Space = compose(&(v568_10),&v567_15_cursor);
    drop(v568_10);
    let v579_6: Path = concat_path(&(*p0),&v567_15_cursor.path()[v567_15_origin..(v567_15_origin + 1)]);
    let v568_12: Space = wrap(&(v568_11),&(v579_6));
    drop(v568_11);
    let v568_13: Space = wrap(&(v568_12),&(*p1));
    drop(v568_12);
    let v568_14: Space = unite(&(v568_8),&(v568_13));
    drop(v568_13);
    join_wrapped_into(&mut v567_15_write,&((v568_14).read_zipper()),&[]);
    }
    v567_15_cursor.ascend(1);
  }
  drop(v567_15_cursor);
  drop(v567_15_write);
  (v567_15).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v580_28 = Space::new();
  let mut v580_28_write = v580_28.write_zipper();
  let mut v580_28_cursor = (*s0).read_zipper();
  let v580_28_origin = v580_28_cursor.path().len();
  for v580_28_byte in v580_28_cursor.child_mask().iter() {
    v580_28_cursor.descend_to_existing_byte(v580_28_byte);
    {
    let v581_2: Space = singleton(&v580_28_cursor.path()[v580_28_origin..(v580_28_origin + 1)]);
    let v581_3: Space = intersect(&(*CONSTANT_2),&(v581_2));
    let v581_4: Space = if has_head(&(v581_3)) { singleton(&[]) } else { Space::new() };
    drop(v581_3);
    let v581_5: Space = subtract(&(*CONSTANT_1),&(v581_4));
    drop(v581_4);
    let v581_8: Space = if (&(v581_5)).is_empty() { Space::new() } else {
      let v582_6: Path = concat_path(&(*p0),&v580_28_cursor.path()[v580_28_origin..(v580_28_origin + 1)]);
      let mut v582_7 = Space::new();
      let mut v582_7_write = v582_7.write_zipper();
      for v582_7_byte in v580_28_cursor.child_mask().iter() {
        v580_28_cursor.descend_to_existing_byte(v582_7_byte);
        {
        let v583_2: Space = singleton(&v580_28_cursor.path()[(v580_28_origin + 1)..(v580_28_origin + 2)]);
        let v583_3: Space = intersect(&(*CONSTANT_2),&(v583_2));
        let v583_4: Space = if has_head(&(v583_3)) { singleton(&[]) } else { Space::new() };
        drop(v583_3);
        let v583_5: Space = subtract(&(*CONSTANT_1),&(v583_4));
        drop(v583_4);
        let v583_8: Space = if (&(v583_5)).is_empty() { Space::new() } else {
          let v584_6: Path = concat_path(&(v582_6),&v580_28_cursor.path()[(v580_28_origin + 1)..(v580_28_origin + 2)]);
          let mut v584_7 = Space::new();
          let mut v584_7_write = v584_7.write_zipper();
          for v584_7_byte in v580_28_cursor.child_mask().iter() {
            v580_28_cursor.descend_to_existing_byte(v584_7_byte);
            {
            let v585_2: Space = singleton(&v580_28_cursor.path()[(v580_28_origin + 2)..(v580_28_origin + 3)]);
            let v585_3: Space = intersect(&(*CONSTANT_2),&(v585_2));
            let v585_4: Space = if has_head(&(v585_3)) { singleton(&[]) } else { Space::new() };
            drop(v585_3);
            let v585_5: Space = subtract(&(*CONSTANT_1),&(v585_4));
            drop(v585_4);
            let v585_8: Space = if (&(v585_5)).is_empty() { Space::new() } else {
              let v586_6: Path = concat_path(&(v584_6),&v580_28_cursor.path()[(v580_28_origin + 2)..(v580_28_origin + 3)]);
              let v586_7: Space = routine_42(c, &(v586_6), &(*p1), &v580_28_cursor, &(*s1));
              compose(&(v585_5),&(v586_7))
            };
            drop(v585_5);
            let v585_9: Space = intersect(&(*CONSTANT_2),&(v585_2));
            drop(v585_2);
            let v585_10: Space = if has_head(&(v585_9)) { singleton(&[]) } else { Space::new() };
            drop(v585_9);
            let v585_12: Space = if (&(v585_10)).is_empty() { Space::new() } else {
              let v587_6: Path = concat_path(&(v584_6),&v580_28_cursor.path()[(v580_28_origin + 2)..(v580_28_origin + 3)]);
              let v587_11: Space = routine_43(c, &(v587_6), &(*p1), &v580_28_cursor, &(*s1));
              drop(v587_6);
              compose(&(v585_10),&(v587_11))
            };
            drop(v585_10);
            let v585_13: Space = unite(&(v585_8),&(v585_12));
            join_wrapped_into(&mut v584_7_write,&((v585_13).read_zipper()),&[]);
            }
            v580_28_cursor.ascend(1);
          }
          drop(v584_7_write);
          compose(&(v583_5),&(v584_7))
        };
        drop(v583_5);
        let v583_9: Space = intersect(&(*CONSTANT_2),&(v583_2));
        drop(v583_2);
        let v583_10: Space = if has_head(&(v583_9)) { singleton(&[]) } else { Space::new() };
        drop(v583_9);
        let v583_12: Space = if (&(v583_10)).is_empty() { Space::new() } else {
          let v588_6: Path = concat_path(&(v582_6),&v580_28_cursor.path()[(v580_28_origin + 1)..(v580_28_origin + 2)]);
          let mut v588_11 = Space::new();
          let mut v588_11_write = v588_11.write_zipper();
          for v588_11_byte in v580_28_cursor.child_mask().iter() {
            v580_28_cursor.descend_to_existing_byte(v588_11_byte);
            {
            let v589_2: Space = singleton(&v580_28_cursor.path()[(v580_28_origin + 2)..(v580_28_origin + 3)]);
            let v589_3: Space = intersect(&(*CONSTANT_2),&(v589_2));
            let v589_4: Space = if has_head(&(v589_3)) { singleton(&[]) } else { Space::new() };
            drop(v589_3);
            let v589_5: Space = subtract(&(*CONSTANT_1),&(v589_4));
            drop(v589_4);
            let v589_8: Space = if (&(v589_5)).is_empty() { Space::new() } else {
              let v590_6: Path = concat_path(&(v588_6),&v580_28_cursor.path()[(v580_28_origin + 2)..(v580_28_origin + 3)]);
              let v590_7: Space = routine_42(c, &(v590_6), &(*p1), &v580_28_cursor, &(*s1));
              compose(&(v589_5),&(v590_7))
            };
            drop(v589_5);
            let v589_9: Space = intersect(&(*CONSTANT_2),&(v589_2));
            drop(v589_2);
            let v589_10: Space = if has_head(&(v589_9)) { singleton(&[]) } else { Space::new() };
            drop(v589_9);
            let v589_12: Space = if (&(v589_10)).is_empty() { Space::new() } else {
              let v591_6: Path = concat_path(&(v588_6),&v580_28_cursor.path()[(v580_28_origin + 2)..(v580_28_origin + 3)]);
              let v591_11: Space = routine_10(c, &(v591_6), &(*p1), &v580_28_cursor, &(*s1));
              drop(v591_6);
              compose(&(v589_10),&(v591_11))
            };
            drop(v589_10);
            let v589_13: Space = unite(&(v589_8),&(v589_12));
            join_wrapped_into(&mut v588_11_write,&((v589_13).read_zipper()),&[]);
            }
            v580_28_cursor.ascend(1);
          }
          drop(v588_11_write);
          drop(v588_6);
          compose(&(v583_10),&(v588_11))
        };
        drop(v583_10);
        let v583_13: Space = unite(&(v583_8),&(v583_12));
        join_wrapped_into(&mut v582_7_write,&((v583_13).read_zipper()),&[]);
        }
        v580_28_cursor.ascend(1);
      }
      drop(v582_7_write);
      compose(&(v581_5),&(v582_7))
    };
    drop(v581_5);
    let v581_9: Space = intersect(&(*CONSTANT_2),&(v581_2));
    drop(v581_2);
    let v581_10: Space = if has_head(&(v581_9)) { singleton(&[]) } else { Space::new() };
    drop(v581_9);
    let v581_13: Space = if (&(v581_10)).is_empty() { Space::new() } else {
      let v592_6: Path = concat_path(&(*p0),&v580_28_cursor.path()[v580_28_origin..(v580_28_origin + 1)]);
      let mut v592_12 = Space::new();
      let mut v592_12_write = v592_12.write_zipper();
      for v592_12_byte in v580_28_cursor.child_mask().iter() {
        v580_28_cursor.descend_to_existing_byte(v592_12_byte);
        {
        let v593_2: Space = singleton(&v580_28_cursor.path()[(v580_28_origin + 1)..(v580_28_origin + 2)]);
        let v593_3: Space = intersect(&(*CONSTANT_2),&(v593_2));
        let v593_4: Space = if has_head(&(v593_3)) { singleton(&[]) } else { Space::new() };
        drop(v593_3);
        let v593_5: Space = subtract(&(*CONSTANT_1),&(v593_4));
        drop(v593_4);
        let v593_8: Space = if (&(v593_5)).is_empty() { Space::new() } else {
          let v594_6: Path = concat_path(&(v592_6),&v580_28_cursor.path()[(v580_28_origin + 1)..(v580_28_origin + 2)]);
          let mut v594_7 = Space::new();
          let mut v594_7_write = v594_7.write_zipper();
          for v594_7_byte in v580_28_cursor.child_mask().iter() {
            v580_28_cursor.descend_to_existing_byte(v594_7_byte);
            {
            let v595_2: Space = singleton(&v580_28_cursor.path()[(v580_28_origin + 2)..(v580_28_origin + 3)]);
            let v595_3: Space = intersect(&(*CONSTANT_2),&(v595_2));
            let v595_4: Space = if has_head(&(v595_3)) { singleton(&[]) } else { Space::new() };
            drop(v595_3);
            let v595_5: Space = subtract(&(*CONSTANT_1),&(v595_4));
            drop(v595_4);
            let v595_8: Space = if (&(v595_5)).is_empty() { Space::new() } else {
              let v596_6: Path = concat_path(&(v594_6),&v580_28_cursor.path()[(v580_28_origin + 2)..(v580_28_origin + 3)]);
              let v596_7: Space = routine_42(c, &(v596_6), &(*p1), &v580_28_cursor, &(*s1));
              compose(&(v595_5),&(v596_7))
            };
            drop(v595_5);
            let v595_9: Space = intersect(&(*CONSTANT_2),&(v595_2));
            drop(v595_2);
            let v595_10: Space = if has_head(&(v595_9)) { singleton(&[]) } else { Space::new() };
            drop(v595_9);
            let v595_12: Space = if (&(v595_10)).is_empty() { Space::new() } else {
              let v597_6: Path = concat_path(&(v594_6),&v580_28_cursor.path()[(v580_28_origin + 2)..(v580_28_origin + 3)]);
              let v597_11: Space = routine_43(c, &(v597_6), &(*p1), &v580_28_cursor, &(*s1));
              drop(v597_6);
              compose(&(v595_10),&(v597_11))
            };
            drop(v595_10);
            let v595_13: Space = unite(&(v595_8),&(v595_12));
            join_wrapped_into(&mut v594_7_write,&((v595_13).read_zipper()),&[]);
            }
            v580_28_cursor.ascend(1);
          }
          drop(v594_7_write);
          drop(v594_6);
          compose(&(v593_5),&(v594_7))
        };
        drop(v593_5);
        let v593_9: Space = intersect(&(*CONSTANT_2),&(v593_2));
        drop(v593_2);
        let v593_10: Space = if has_head(&(v593_9)) { singleton(&[]) } else { Space::new() };
        drop(v593_9);
        let v593_13: Space = if (&(v593_10)).is_empty() { Space::new() } else {
          let mut v598_12 = Space::new();
          let mut v598_12_write = v598_12.write_zipper();
          let mut v598_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v580_28_cursor.path()[v580_28_origin..(v580_28_origin + 1)]),&v580_28_cursor.path()[(v580_28_origin + 1)..(v580_28_origin + 2)]);
          let v598_12_origin = v598_12_cursor.path().len();
          for v598_12_byte in v598_12_cursor.child_mask().iter() {
            v598_12_cursor.descend_to_existing_byte(v598_12_byte);
            {
            let v599_2: Space = singleton(&v598_12_cursor.path()[v598_12_origin..(v598_12_origin + 1)]);
            let v599_3: Space = intersect(&(*CONSTANT_2),&(v599_2));
            let v599_4: Space = if has_head(&(v599_3)) { singleton(&[]) } else { Space::new() };
            drop(v599_3);
            let v599_5: Space = subtract(&(*CONSTANT_1),&(v599_4));
            drop(v599_4);
            let v599_7: Space = if (&(v599_5)).is_empty() { Space::new() } else {
              let v600_6: Space = routine_13(c, &v598_12_cursor.path()[v598_12_origin..(v598_12_origin + 1)], &(*p1), &v598_12_cursor);
              compose(&(v599_5),&(v600_6))
            };
            drop(v599_5);
            let v599_8: Space = intersect(&(*CONSTANT_2),&(v599_2));
            drop(v599_2);
            let v599_9: Space = if has_head(&(v599_8)) { singleton(&[]) } else { Space::new() };
            drop(v599_8);
            let v599_11: Space = if (&(v599_9)).is_empty() { Space::new() } else {
              let v601_10: Space = routine_14(c, &v598_12_cursor.path()[v598_12_origin..(v598_12_origin + 1)], &(*p1), &v598_12_cursor);
              compose(&(v599_9),&(v601_10))
            };
            drop(v599_9);
            let v599_12: Space = unite(&(v599_7),&(v599_11));
            join_wrapped_into(&mut v598_12_write,&((v599_12).read_zipper()),&[]);
            }
            v598_12_cursor.ascend(1);
          }
          drop(v598_12_cursor);
          drop(v598_12_write);
          compose(&(v593_10),&(v598_12))
        };
        drop(v593_10);
        let v593_14: Space = unite(&(v593_8),&(v593_13));
        join_wrapped_into(&mut v592_12_write,&((v593_14).read_zipper()),&[]);
        }
        v580_28_cursor.ascend(1);
      }
      drop(v592_12_write);
      drop(v592_6);
      compose(&(v581_10),&(v592_12))
    };
    drop(v581_10);
    let v581_14: Space = unite(&(v581_8),&(v581_13));
    join_wrapped_into(&mut v580_28_write,&((v581_14).read_zipper()),&[]);
    }
    v580_28_cursor.ascend(1);
  }
  drop(v580_28_cursor);
  drop(v580_28_write);
  (v580_28).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v602_28 = Space::new();
  let mut v602_28_write = v602_28.write_zipper();
  let mut v602_28_cursor = (*s0).read_zipper();
  let v602_28_origin = v602_28_cursor.path().len();
  for v602_28_byte in v602_28_cursor.child_mask().iter() {
    v602_28_cursor.descend_to_existing_byte(v602_28_byte);
    {
    let v603_2: Space = singleton(&v602_28_cursor.path()[v602_28_origin..(v602_28_origin + 1)]);
    let v603_3: Space = intersect(&(*CONSTANT_2),&(v603_2));
    let v603_4: Space = if has_head(&(v603_3)) { singleton(&[]) } else { Space::new() };
    drop(v603_3);
    let v603_5: Space = subtract(&(*CONSTANT_1),&(v603_4));
    drop(v603_4);
    let v603_8: Space = if (&(v603_5)).is_empty() { Space::new() } else {
      let v604_6: Path = concat_path(&(*p0),&v602_28_cursor.path()[v602_28_origin..(v602_28_origin + 1)]);
      let mut v604_7 = Space::new();
      let mut v604_7_write = v604_7.write_zipper();
      for v604_7_byte in v602_28_cursor.child_mask().iter() {
        v602_28_cursor.descend_to_existing_byte(v604_7_byte);
        {
        let v605_2: Space = singleton(&v602_28_cursor.path()[(v602_28_origin + 1)..(v602_28_origin + 2)]);
        let v605_3: Space = intersect(&(*CONSTANT_2),&(v605_2));
        let v605_4: Space = if has_head(&(v605_3)) { singleton(&[]) } else { Space::new() };
        drop(v605_3);
        let v605_5: Space = subtract(&(*CONSTANT_1),&(v605_4));
        drop(v605_4);
        let v605_8: Space = if (&(v605_5)).is_empty() { Space::new() } else {
          let v606_6: Path = concat_path(&(v604_6),&v602_28_cursor.path()[(v602_28_origin + 1)..(v602_28_origin + 2)]);
          let mut v606_7 = Space::new();
          let mut v606_7_write = v606_7.write_zipper();
          for v606_7_byte in v602_28_cursor.child_mask().iter() {
            v602_28_cursor.descend_to_existing_byte(v606_7_byte);
            {
            let v607_2: Space = singleton(&v602_28_cursor.path()[(v602_28_origin + 2)..(v602_28_origin + 3)]);
            let v607_3: Space = intersect(&(*CONSTANT_2),&(v607_2));
            let v607_4: Space = if has_head(&(v607_3)) { singleton(&[]) } else { Space::new() };
            drop(v607_3);
            let v607_5: Space = subtract(&(*CONSTANT_1),&(v607_4));
            drop(v607_4);
            let v607_8: Space = if (&(v607_5)).is_empty() { Space::new() } else {
              let v608_6: Path = concat_path(&(v606_6),&v602_28_cursor.path()[(v602_28_origin + 2)..(v602_28_origin + 3)]);
              let v608_7: Space = routine_42(c, &(v608_6), &(*p1), &v602_28_cursor, &(*s1));
              compose(&(v607_5),&(v608_7))
            };
            drop(v607_5);
            let v607_9: Space = intersect(&(*CONSTANT_2),&(v607_2));
            drop(v607_2);
            let v607_10: Space = if has_head(&(v607_9)) { singleton(&[]) } else { Space::new() };
            drop(v607_9);
            let v607_12: Space = if (&(v607_10)).is_empty() { Space::new() } else {
              let v609_6: Path = concat_path(&(v606_6),&v602_28_cursor.path()[(v602_28_origin + 2)..(v602_28_origin + 3)]);
              let v609_11: Space = routine_43(c, &(v609_6), &(*p1), &v602_28_cursor, &(*s1));
              drop(v609_6);
              compose(&(v607_10),&(v609_11))
            };
            drop(v607_10);
            let v607_13: Space = unite(&(v607_8),&(v607_12));
            join_wrapped_into(&mut v606_7_write,&((v607_13).read_zipper()),&[]);
            }
            v602_28_cursor.ascend(1);
          }
          drop(v606_7_write);
          compose(&(v605_5),&(v606_7))
        };
        drop(v605_5);
        let v605_9: Space = intersect(&(*CONSTANT_2),&(v605_2));
        drop(v605_2);
        let v605_10: Space = if has_head(&(v605_9)) { singleton(&[]) } else { Space::new() };
        drop(v605_9);
        let v605_12: Space = if (&(v605_10)).is_empty() { Space::new() } else {
          let v610_6: Path = concat_path(&(v604_6),&v602_28_cursor.path()[(v602_28_origin + 1)..(v602_28_origin + 2)]);
          let mut v610_11 = Space::new();
          let mut v610_11_write = v610_11.write_zipper();
          for v610_11_byte in v602_28_cursor.child_mask().iter() {
            v602_28_cursor.descend_to_existing_byte(v610_11_byte);
            {
            let v611_2: Space = singleton(&v602_28_cursor.path()[(v602_28_origin + 2)..(v602_28_origin + 3)]);
            let v611_3: Space = intersect(&(*CONSTANT_2),&(v611_2));
            let v611_4: Space = if has_head(&(v611_3)) { singleton(&[]) } else { Space::new() };
            drop(v611_3);
            let v611_5: Space = subtract(&(*CONSTANT_1),&(v611_4));
            drop(v611_4);
            let v611_8: Space = if (&(v611_5)).is_empty() { Space::new() } else {
              let v612_6: Path = concat_path(&(v610_6),&v602_28_cursor.path()[(v602_28_origin + 2)..(v602_28_origin + 3)]);
              let v612_7: Space = routine_42(c, &(v612_6), &(*p1), &v602_28_cursor, &(*s1));
              compose(&(v611_5),&(v612_7))
            };
            drop(v611_5);
            let v611_9: Space = intersect(&(*CONSTANT_2),&(v611_2));
            drop(v611_2);
            let v611_10: Space = if has_head(&(v611_9)) { singleton(&[]) } else { Space::new() };
            drop(v611_9);
            let v611_12: Space = if (&(v611_10)).is_empty() { Space::new() } else {
              let v613_6: Path = concat_path(&(v610_6),&v602_28_cursor.path()[(v602_28_origin + 2)..(v602_28_origin + 3)]);
              let v613_11: Space = routine_10(c, &(v613_6), &(*p1), &v602_28_cursor, &(*s1));
              drop(v613_6);
              compose(&(v611_10),&(v613_11))
            };
            drop(v611_10);
            let v611_13: Space = unite(&(v611_8),&(v611_12));
            join_wrapped_into(&mut v610_11_write,&((v611_13).read_zipper()),&[]);
            }
            v602_28_cursor.ascend(1);
          }
          drop(v610_11_write);
          drop(v610_6);
          compose(&(v605_10),&(v610_11))
        };
        drop(v605_10);
        let v605_13: Space = unite(&(v605_8),&(v605_12));
        join_wrapped_into(&mut v604_7_write,&((v605_13).read_zipper()),&[]);
        }
        v602_28_cursor.ascend(1);
      }
      drop(v604_7_write);
      drop(v604_6);
      compose(&(v603_5),&(v604_7))
    };
    drop(v603_5);
    let v603_9: Space = intersect(&(*CONSTANT_2),&(v603_2));
    drop(v603_2);
    let v603_10: Space = if has_head(&(v603_9)) { singleton(&[]) } else { Space::new() };
    drop(v603_9);
    let v603_13: Space = if (&(v603_10)).is_empty() { Space::new() } else {
      let mut v614_12 = Space::new();
      let mut v614_12_write = v614_12.write_zipper();
      let mut v614_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v602_28_cursor.path()[v602_28_origin..(v602_28_origin + 1)]);
      let v614_12_origin = v614_12_cursor.path().len();
      for v614_12_byte in v614_12_cursor.child_mask().iter() {
        v614_12_cursor.descend_to_existing_byte(v614_12_byte);
        {
        let v615_2: Space = singleton(&v614_12_cursor.path()[v614_12_origin..(v614_12_origin + 1)]);
        let v615_3: Space = intersect(&(*CONSTANT_2),&(v615_2));
        let v615_4: Space = if has_head(&(v615_3)) { singleton(&[]) } else { Space::new() };
        drop(v615_3);
        let v615_5: Space = subtract(&(*CONSTANT_1),&(v615_4));
        drop(v615_4);
        let v615_7: Space = if (&(v615_5)).is_empty() { Space::new() } else {
          let mut v616_6 = Space::new();
          let mut v616_6_write = v616_6.write_zipper();
          for v616_6_byte in v614_12_cursor.child_mask().iter() {
            v614_12_cursor.descend_to_existing_byte(v616_6_byte);
            {
            let v617_2: Space = singleton(&v614_12_cursor.path()[(v614_12_origin + 1)..(v614_12_origin + 2)]);
            let v617_3: Space = intersect(&(*CONSTANT_2),&(v617_2));
            let v617_4: Space = if has_head(&(v617_3)) { singleton(&[]) } else { Space::new() };
            drop(v617_3);
            let v617_5: Space = subtract(&(*CONSTANT_1),&(v617_4));
            drop(v617_4);
            let v617_8: Space = if (&(v617_5)).is_empty() { Space::new() } else {
              let v618_7: Space = routine_17(c, &v614_12_cursor.path()[v614_12_origin..(v614_12_origin + 2)], &(*p1), &v614_12_cursor);
              compose(&(v617_5),&(v618_7))
            };
            drop(v617_5);
            let v617_9: Space = intersect(&(*CONSTANT_2),&(v617_2));
            drop(v617_2);
            let v617_10: Space = if has_head(&(v617_9)) { singleton(&[]) } else { Space::new() };
            drop(v617_9);
            let v617_12: Space = if (&(v617_10)).is_empty() { Space::new() } else {
              let v619_11: Space = routine_18(c, &v614_12_cursor.path()[v614_12_origin..(v614_12_origin + 2)], &(*p1), &v614_12_cursor);
              compose(&(v617_10),&(v619_11))
            };
            drop(v617_10);
            let v617_13: Space = unite(&(v617_8),&(v617_12));
            join_wrapped_into(&mut v616_6_write,&((v617_13).read_zipper()),&[]);
            }
            v614_12_cursor.ascend(1);
          }
          drop(v616_6_write);
          compose(&(v615_5),&(v616_6))
        };
        drop(v615_5);
        let v615_8: Space = intersect(&(*CONSTANT_2),&(v615_2));
        drop(v615_2);
        let v615_9: Space = if has_head(&(v615_8)) { singleton(&[]) } else { Space::new() };
        drop(v615_8);
        let v615_11: Space = if (&(v615_9)).is_empty() { Space::new() } else {
          let mut v620_10 = Space::new();
          let mut v620_10_write = v620_10.write_zipper();
          for v620_10_byte in v614_12_cursor.child_mask().iter() {
            v614_12_cursor.descend_to_existing_byte(v620_10_byte);
            {
            let v621_2: Space = singleton(&v614_12_cursor.path()[(v614_12_origin + 1)..(v614_12_origin + 2)]);
            let v621_3: Space = intersect(&(*CONSTANT_2),&(v621_2));
            let v621_4: Space = if has_head(&(v621_3)) { singleton(&[]) } else { Space::new() };
            drop(v621_3);
            let v621_5: Space = subtract(&(*CONSTANT_1),&(v621_4));
            drop(v621_4);
            let v621_8: Space = if (&(v621_5)).is_empty() { Space::new() } else {
              let v622_7: Space = routine_17(c, &v614_12_cursor.path()[v614_12_origin..(v614_12_origin + 2)], &(*p1), &v614_12_cursor);
              compose(&(v621_5),&(v622_7))
            };
            drop(v621_5);
            let v621_9: Space = intersect(&(*CONSTANT_2),&(v621_2));
            drop(v621_2);
            let v621_10: Space = if has_head(&(v621_9)) { singleton(&[]) } else { Space::new() };
            drop(v621_9);
            let v621_12: Space = if (&(v621_10)).is_empty() { Space::new() } else {
              let v623_11: Space = routine_19(c, &v614_12_cursor.path()[v614_12_origin..(v614_12_origin + 2)], &(*p1), &v614_12_cursor);
              compose(&(v621_10),&(v623_11))
            };
            drop(v621_10);
            let v621_13: Space = unite(&(v621_8),&(v621_12));
            join_wrapped_into(&mut v620_10_write,&((v621_13).read_zipper()),&[]);
            }
            v614_12_cursor.ascend(1);
          }
          drop(v620_10_write);
          compose(&(v615_9),&(v620_10))
        };
        drop(v615_9);
        let v615_12: Space = unite(&(v615_7),&(v615_11));
        join_wrapped_into(&mut v614_12_write,&((v615_12).read_zipper()),&[]);
        }
        v614_12_cursor.ascend(1);
      }
      drop(v614_12_cursor);
      drop(v614_12_write);
      compose(&(v603_10),&(v614_12))
    };
    drop(v603_10);
    let v603_14: Space = unite(&(v603_8),&(v603_13));
    join_wrapped_into(&mut v602_28_write,&((v603_14).read_zipper()),&[]);
    }
    v602_28_cursor.ascend(1);
  }
  drop(v602_28_cursor);
  drop(v602_28_write);
  (v602_28).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v624_21 = Space::new();
  let mut v624_21_write = v624_21.write_zipper();
  let mut v624_21_cursor = (*s0).read_zipper();
  let v624_21_origin = v624_21_cursor.path().len();
  for v624_21_byte in v624_21_cursor.child_mask().iter() {
    v624_21_cursor.descend_to_existing_byte(v624_21_byte);
    {
    let v625_2: Space = singleton(&v624_21_cursor.path()[v624_21_origin..(v624_21_origin + 1)]);
    let v625_3: Space = intersect(&(*CONSTANT_2),&(v625_2));
    let v625_4: Space = if has_head(&(v625_3)) { singleton(&[]) } else { Space::new() };
    drop(v625_3);
    let v625_5: Space = subtract(&(*CONSTANT_1),&(v625_4));
    drop(v625_4);
    let v625_8: Space = if (&(v625_5)).is_empty() { Space::new() } else {
      let v626_6: Path = concat_path(&(*p0),&v624_21_cursor.path()[v624_21_origin..(v624_21_origin + 1)]);
      let mut v626_7 = Space::new();
      let mut v626_7_write = v626_7.write_zipper();
      for v626_7_byte in v624_21_cursor.child_mask().iter() {
        v624_21_cursor.descend_to_existing_byte(v626_7_byte);
        {
        let v627_2: Space = singleton(&v624_21_cursor.path()[(v624_21_origin + 1)..(v624_21_origin + 2)]);
        let v627_3: Space = intersect(&(*CONSTANT_2),&(v627_2));
        let v627_4: Space = if has_head(&(v627_3)) { singleton(&[]) } else { Space::new() };
        drop(v627_3);
        let v627_5: Space = subtract(&(*CONSTANT_1),&(v627_4));
        drop(v627_4);
        let v627_8: Space = if (&(v627_5)).is_empty() { Space::new() } else {
          let v628_6: Path = concat_path(&(v626_6),&v624_21_cursor.path()[(v624_21_origin + 1)..(v624_21_origin + 2)]);
          let mut v628_7 = Space::new();
          let mut v628_7_write = v628_7.write_zipper();
          for v628_7_byte in v624_21_cursor.child_mask().iter() {
            v624_21_cursor.descend_to_existing_byte(v628_7_byte);
            {
            let v629_2: Space = singleton(&v624_21_cursor.path()[(v624_21_origin + 2)..(v624_21_origin + 3)]);
            let v629_3: Space = intersect(&(*CONSTANT_2),&(v629_2));
            let v629_4: Space = if has_head(&(v629_3)) { singleton(&[]) } else { Space::new() };
            drop(v629_3);
            let v629_5: Space = subtract(&(*CONSTANT_1),&(v629_4));
            drop(v629_4);
            let v629_8: Space = if (&(v629_5)).is_empty() { Space::new() } else {
              let v630_6: Path = concat_path(&(v628_6),&v624_21_cursor.path()[(v624_21_origin + 2)..(v624_21_origin + 3)]);
              let v630_7: Space = routine_44(c, &(v630_6), &(*p1), &v624_21_cursor);
              compose(&(v629_5),&(v630_7))
            };
            drop(v629_5);
            let v629_9: Space = intersect(&(*CONSTANT_2),&(v629_2));
            drop(v629_2);
            let v629_10: Space = if has_head(&(v629_9)) { singleton(&[]) } else { Space::new() };
            drop(v629_9);
            let v629_12: Space = if (&(v629_10)).is_empty() { Space::new() } else {
              let v631_6: Path = concat_path(&(v628_6),&v624_21_cursor.path()[(v624_21_origin + 2)..(v624_21_origin + 3)]);
              let v631_11: Space = routine_45(c, &(v631_6), &(*p1), &v624_21_cursor);
              drop(v631_6);
              compose(&(v629_10),&(v631_11))
            };
            drop(v629_10);
            let v629_13: Space = unite(&(v629_8),&(v629_12));
            join_wrapped_into(&mut v628_7_write,&((v629_13).read_zipper()),&[]);
            }
            v624_21_cursor.ascend(1);
          }
          drop(v628_7_write);
          compose(&(v627_5),&(v628_7))
        };
        drop(v627_5);
        let v627_9: Space = intersect(&(*CONSTANT_2),&(v627_2));
        drop(v627_2);
        let v627_10: Space = if has_head(&(v627_9)) { singleton(&[]) } else { Space::new() };
        drop(v627_9);
        let v627_12: Space = if (&(v627_10)).is_empty() { Space::new() } else {
          let v632_6: Path = concat_path(&(v626_6),&v624_21_cursor.path()[(v624_21_origin + 1)..(v624_21_origin + 2)]);
          let mut v632_11 = Space::new();
          let mut v632_11_write = v632_11.write_zipper();
          for v632_11_byte in v624_21_cursor.child_mask().iter() {
            v624_21_cursor.descend_to_existing_byte(v632_11_byte);
            {
            let v633_2: Space = singleton(&v624_21_cursor.path()[(v624_21_origin + 2)..(v624_21_origin + 3)]);
            let v633_3: Space = intersect(&(*CONSTANT_2),&(v633_2));
            let v633_4: Space = if has_head(&(v633_3)) { singleton(&[]) } else { Space::new() };
            drop(v633_3);
            let v633_5: Space = subtract(&(*CONSTANT_1),&(v633_4));
            drop(v633_4);
            let v633_8: Space = if (&(v633_5)).is_empty() { Space::new() } else {
              let v634_6: Path = concat_path(&(v632_6),&v624_21_cursor.path()[(v624_21_origin + 2)..(v624_21_origin + 3)]);
              let v634_7: Space = routine_44(c, &(v634_6), &(*p1), &v624_21_cursor);
              compose(&(v633_5),&(v634_7))
            };
            drop(v633_5);
            let v633_9: Space = intersect(&(*CONSTANT_2),&(v633_2));
            drop(v633_2);
            let v633_10: Space = if has_head(&(v633_9)) { singleton(&[]) } else { Space::new() };
            drop(v633_9);
            let v633_12: Space = if (&(v633_10)).is_empty() { Space::new() } else {
              let v635_6: Path = concat_path(&(v632_6),&v624_21_cursor.path()[(v624_21_origin + 2)..(v624_21_origin + 3)]);
              let v635_11: Space = routine_19(c, &(v635_6), &(*p1), &v624_21_cursor);
              drop(v635_6);
              compose(&(v633_10),&(v635_11))
            };
            drop(v633_10);
            let v633_13: Space = unite(&(v633_8),&(v633_12));
            join_wrapped_into(&mut v632_11_write,&((v633_13).read_zipper()),&[]);
            }
            v624_21_cursor.ascend(1);
          }
          drop(v632_11_write);
          drop(v632_6);
          compose(&(v627_10),&(v632_11))
        };
        drop(v627_10);
        let v627_13: Space = unite(&(v627_8),&(v627_12));
        join_wrapped_into(&mut v626_7_write,&((v627_13).read_zipper()),&[]);
        }
        v624_21_cursor.ascend(1);
      }
      drop(v626_7_write);
      compose(&(v625_5),&(v626_7))
    };
    drop(v625_5);
    let v625_9: Space = intersect(&(*CONSTANT_2),&(v625_2));
    drop(v625_2);
    let v625_10: Space = if has_head(&(v625_9)) { singleton(&[]) } else { Space::new() };
    drop(v625_9);
    let v625_12: Space = if (&(v625_10)).is_empty() { Space::new() } else {
      let v636_6: Path = concat_path(&(*p0),&v624_21_cursor.path()[v624_21_origin..(v624_21_origin + 1)]);
      let mut v636_11 = Space::new();
      let mut v636_11_write = v636_11.write_zipper();
      for v636_11_byte in v624_21_cursor.child_mask().iter() {
        v624_21_cursor.descend_to_existing_byte(v636_11_byte);
        {
        let v637_2: Space = singleton(&v624_21_cursor.path()[(v624_21_origin + 1)..(v624_21_origin + 2)]);
        let v637_3: Space = intersect(&(*CONSTANT_2),&(v637_2));
        let v637_4: Space = if has_head(&(v637_3)) { singleton(&[]) } else { Space::new() };
        drop(v637_3);
        let v637_5: Space = subtract(&(*CONSTANT_1),&(v637_4));
        drop(v637_4);
        let v637_8: Space = if (&(v637_5)).is_empty() { Space::new() } else {
          let v638_6: Path = concat_path(&(v636_6),&v624_21_cursor.path()[(v624_21_origin + 1)..(v624_21_origin + 2)]);
          let mut v638_7 = Space::new();
          let mut v638_7_write = v638_7.write_zipper();
          for v638_7_byte in v624_21_cursor.child_mask().iter() {
            v624_21_cursor.descend_to_existing_byte(v638_7_byte);
            {
            let v639_2: Space = singleton(&v624_21_cursor.path()[(v624_21_origin + 2)..(v624_21_origin + 3)]);
            let v639_3: Space = intersect(&(*CONSTANT_2),&(v639_2));
            let v639_4: Space = if has_head(&(v639_3)) { singleton(&[]) } else { Space::new() };
            drop(v639_3);
            let v639_5: Space = subtract(&(*CONSTANT_1),&(v639_4));
            drop(v639_4);
            let v639_8: Space = if (&(v639_5)).is_empty() { Space::new() } else {
              let v640_6: Path = concat_path(&(v638_6),&v624_21_cursor.path()[(v624_21_origin + 2)..(v624_21_origin + 3)]);
              let v640_7: Space = routine_44(c, &(v640_6), &(*p1), &v624_21_cursor);
              compose(&(v639_5),&(v640_7))
            };
            drop(v639_5);
            let v639_9: Space = intersect(&(*CONSTANT_2),&(v639_2));
            drop(v639_2);
            let v639_10: Space = if has_head(&(v639_9)) { singleton(&[]) } else { Space::new() };
            drop(v639_9);
            let v639_12: Space = if (&(v639_10)).is_empty() { Space::new() } else {
              let v641_6: Path = concat_path(&(v638_6),&v624_21_cursor.path()[(v624_21_origin + 2)..(v624_21_origin + 3)]);
              let v641_11: Space = routine_45(c, &(v641_6), &(*p1), &v624_21_cursor);
              drop(v641_6);
              compose(&(v639_10),&(v641_11))
            };
            drop(v639_10);
            let v639_13: Space = unite(&(v639_8),&(v639_12));
            join_wrapped_into(&mut v638_7_write,&((v639_13).read_zipper()),&[]);
            }
            v624_21_cursor.ascend(1);
          }
          drop(v638_7_write);
          compose(&(v637_5),&(v638_7))
        };
        drop(v637_5);
        let v637_9: Space = intersect(&(*CONSTANT_2),&(v637_2));
        drop(v637_2);
        let v637_10: Space = if has_head(&(v637_9)) { singleton(&[]) } else { Space::new() };
        drop(v637_9);
        let v637_11: Space = compose(&(v637_10),&v624_21_cursor);
        drop(v637_10);
        let v642_6: Path = concat_path(&(v636_6),&v624_21_cursor.path()[(v624_21_origin + 1)..(v624_21_origin + 2)]);
        let v637_12: Space = wrap(&(v637_11),&(v642_6));
        drop(v637_11);
        let v637_13: Space = wrap(&(v637_12),&(*p1));
        drop(v637_12);
        let v637_14: Space = unite(&(v637_8),&(v637_13));
        drop(v637_13);
        join_wrapped_into(&mut v636_11_write,&((v637_14).read_zipper()),&[]);
        }
        v624_21_cursor.ascend(1);
      }
      drop(v636_11_write);
      drop(v636_6);
      compose(&(v625_10),&(v636_11))
    };
    drop(v625_10);
    let v625_13: Space = unite(&(v625_8),&(v625_12));
    join_wrapped_into(&mut v624_21_write,&((v625_13).read_zipper()),&[]);
    }
    v624_21_cursor.ascend(1);
  }
  drop(v624_21_cursor);
  drop(v624_21_write);
  (v624_21).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v643_15 = Space::new();
  let mut v643_15_write = v643_15.write_zipper();
  let mut v643_15_cursor = (*s0).read_zipper();
  let v643_15_origin = v643_15_cursor.path().len();
  for v643_15_byte in v643_15_cursor.child_mask().iter() {
    v643_15_cursor.descend_to_existing_byte(v643_15_byte);
    {
    let v644_2: Space = singleton(&v643_15_cursor.path()[v643_15_origin..(v643_15_origin + 1)]);
    let v644_3: Space = intersect(&(*CONSTANT_2),&(v644_2));
    let v644_4: Space = if has_head(&(v644_3)) { singleton(&[]) } else { Space::new() };
    drop(v644_3);
    let v644_5: Space = subtract(&(*CONSTANT_1),&(v644_4));
    drop(v644_4);
    let v644_8: Space = if (&(v644_5)).is_empty() { Space::new() } else {
      let v645_6: Path = concat_path(&(*p0),&v643_15_cursor.path()[v643_15_origin..(v643_15_origin + 1)]);
      let mut v645_7 = Space::new();
      let mut v645_7_write = v645_7.write_zipper();
      for v645_7_byte in v643_15_cursor.child_mask().iter() {
        v643_15_cursor.descend_to_existing_byte(v645_7_byte);
        {
        let v646_2: Space = singleton(&v643_15_cursor.path()[(v643_15_origin + 1)..(v643_15_origin + 2)]);
        let v646_3: Space = intersect(&(*CONSTANT_2),&(v646_2));
        let v646_4: Space = if has_head(&(v646_3)) { singleton(&[]) } else { Space::new() };
        drop(v646_3);
        let v646_5: Space = subtract(&(*CONSTANT_1),&(v646_4));
        drop(v646_4);
        let v646_8: Space = if (&(v646_5)).is_empty() { Space::new() } else {
          let v647_6: Path = concat_path(&(v645_6),&v643_15_cursor.path()[(v643_15_origin + 1)..(v643_15_origin + 2)]);
          let mut v647_7 = Space::new();
          let mut v647_7_write = v647_7.write_zipper();
          for v647_7_byte in v643_15_cursor.child_mask().iter() {
            v643_15_cursor.descend_to_existing_byte(v647_7_byte);
            {
            let v648_2: Space = singleton(&v643_15_cursor.path()[(v643_15_origin + 2)..(v643_15_origin + 3)]);
            let v648_3: Space = intersect(&(*CONSTANT_2),&(v648_2));
            let v648_4: Space = if has_head(&(v648_3)) { singleton(&[]) } else { Space::new() };
            drop(v648_3);
            let v648_5: Space = subtract(&(*CONSTANT_1),&(v648_4));
            drop(v648_4);
            let v648_8: Space = if (&(v648_5)).is_empty() { Space::new() } else {
              let v649_6: Path = concat_path(&(v647_6),&v643_15_cursor.path()[(v643_15_origin + 2)..(v643_15_origin + 3)]);
              let v649_7: Space = routine_44(c, &(v649_6), &(*p1), &v643_15_cursor);
              compose(&(v648_5),&(v649_7))
            };
            drop(v648_5);
            let v648_9: Space = intersect(&(*CONSTANT_2),&(v648_2));
            drop(v648_2);
            let v648_10: Space = if has_head(&(v648_9)) { singleton(&[]) } else { Space::new() };
            drop(v648_9);
            let v648_12: Space = if (&(v648_10)).is_empty() { Space::new() } else {
              let v650_6: Path = concat_path(&(v647_6),&v643_15_cursor.path()[(v643_15_origin + 2)..(v643_15_origin + 3)]);
              let v650_11: Space = routine_45(c, &(v650_6), &(*p1), &v643_15_cursor);
              drop(v650_6);
              compose(&(v648_10),&(v650_11))
            };
            drop(v648_10);
            let v648_13: Space = unite(&(v648_8),&(v648_12));
            join_wrapped_into(&mut v647_7_write,&((v648_13).read_zipper()),&[]);
            }
            v643_15_cursor.ascend(1);
          }
          drop(v647_7_write);
          compose(&(v646_5),&(v647_7))
        };
        drop(v646_5);
        let v646_9: Space = intersect(&(*CONSTANT_2),&(v646_2));
        drop(v646_2);
        let v646_10: Space = if has_head(&(v646_9)) { singleton(&[]) } else { Space::new() };
        drop(v646_9);
        let v646_12: Space = if (&(v646_10)).is_empty() { Space::new() } else {
          let v651_6: Path = concat_path(&(v645_6),&v643_15_cursor.path()[(v643_15_origin + 1)..(v643_15_origin + 2)]);
          let mut v651_11 = Space::new();
          let mut v651_11_write = v651_11.write_zipper();
          for v651_11_byte in v643_15_cursor.child_mask().iter() {
            v643_15_cursor.descend_to_existing_byte(v651_11_byte);
            {
            let v652_2: Space = singleton(&v643_15_cursor.path()[(v643_15_origin + 2)..(v643_15_origin + 3)]);
            let v652_3: Space = intersect(&(*CONSTANT_2),&(v652_2));
            let v652_4: Space = if has_head(&(v652_3)) { singleton(&[]) } else { Space::new() };
            drop(v652_3);
            let v652_5: Space = subtract(&(*CONSTANT_1),&(v652_4));
            drop(v652_4);
            let v652_8: Space = if (&(v652_5)).is_empty() { Space::new() } else {
              let v653_6: Path = concat_path(&(v651_6),&v643_15_cursor.path()[(v643_15_origin + 2)..(v643_15_origin + 3)]);
              let v653_7: Space = routine_44(c, &(v653_6), &(*p1), &v643_15_cursor);
              compose(&(v652_5),&(v653_7))
            };
            drop(v652_5);
            let v652_9: Space = intersect(&(*CONSTANT_2),&(v652_2));
            drop(v652_2);
            let v652_10: Space = if has_head(&(v652_9)) { singleton(&[]) } else { Space::new() };
            drop(v652_9);
            let v652_12: Space = if (&(v652_10)).is_empty() { Space::new() } else {
              let v654_6: Path = concat_path(&(v651_6),&v643_15_cursor.path()[(v643_15_origin + 2)..(v643_15_origin + 3)]);
              let v654_11: Space = routine_19(c, &(v654_6), &(*p1), &v643_15_cursor);
              drop(v654_6);
              compose(&(v652_10),&(v654_11))
            };
            drop(v652_10);
            let v652_13: Space = unite(&(v652_8),&(v652_12));
            join_wrapped_into(&mut v651_11_write,&((v652_13).read_zipper()),&[]);
            }
            v643_15_cursor.ascend(1);
          }
          drop(v651_11_write);
          drop(v651_6);
          compose(&(v646_10),&(v651_11))
        };
        drop(v646_10);
        let v646_13: Space = unite(&(v646_8),&(v646_12));
        join_wrapped_into(&mut v645_7_write,&((v646_13).read_zipper()),&[]);
        }
        v643_15_cursor.ascend(1);
      }
      drop(v645_7_write);
      compose(&(v644_5),&(v645_7))
    };
    drop(v644_5);
    let v644_9: Space = intersect(&(*CONSTANT_2),&(v644_2));
    drop(v644_2);
    let v644_10: Space = if has_head(&(v644_9)) { singleton(&[]) } else { Space::new() };
    drop(v644_9);
    let v644_11: Space = compose(&(v644_10),&v643_15_cursor);
    drop(v644_10);
    let v655_6: Path = concat_path(&(*p0),&v643_15_cursor.path()[v643_15_origin..(v643_15_origin + 1)]);
    let v644_12: Space = wrap(&(v644_11),&(v655_6));
    drop(v644_11);
    let v644_13: Space = wrap(&(v644_12),&(*p1));
    drop(v644_12);
    let v644_14: Space = unite(&(v644_8),&(v644_13));
    drop(v644_13);
    join_wrapped_into(&mut v643_15_write,&((v644_14).read_zipper()),&[]);
    }
    v643_15_cursor.ascend(1);
  }
  drop(v643_15_cursor);
  drop(v643_15_write);
  (v643_15).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v656_28 = Space::new();
  let mut v656_28_write = v656_28.write_zipper();
  let mut v656_28_cursor = (*s0).read_zipper();
  let v656_28_origin = v656_28_cursor.path().len();
  for v656_28_byte in v656_28_cursor.child_mask().iter() {
    v656_28_cursor.descend_to_existing_byte(v656_28_byte);
    {
    let v657_2: Space = singleton(&v656_28_cursor.path()[v656_28_origin..(v656_28_origin + 1)]);
    let v657_3: Space = intersect(&(*CONSTANT_2),&(v657_2));
    let v657_4: Space = if has_head(&(v657_3)) { singleton(&[]) } else { Space::new() };
    drop(v657_3);
    let v657_5: Space = subtract(&(*CONSTANT_1),&(v657_4));
    drop(v657_4);
    let v657_8: Space = if (&(v657_5)).is_empty() { Space::new() } else {
      let v658_6: Path = concat_path(&(*p0),&v656_28_cursor.path()[v656_28_origin..(v656_28_origin + 1)]);
      let mut v658_7 = Space::new();
      let mut v658_7_write = v658_7.write_zipper();
      for v658_7_byte in v656_28_cursor.child_mask().iter() {
        v656_28_cursor.descend_to_existing_byte(v658_7_byte);
        {
        let v659_2: Space = singleton(&v656_28_cursor.path()[(v656_28_origin + 1)..(v656_28_origin + 2)]);
        let v659_3: Space = intersect(&(*CONSTANT_2),&(v659_2));
        let v659_4: Space = if has_head(&(v659_3)) { singleton(&[]) } else { Space::new() };
        drop(v659_3);
        let v659_5: Space = subtract(&(*CONSTANT_1),&(v659_4));
        drop(v659_4);
        let v659_8: Space = if (&(v659_5)).is_empty() { Space::new() } else {
          let v660_6: Path = concat_path(&(v658_6),&v656_28_cursor.path()[(v656_28_origin + 1)..(v656_28_origin + 2)]);
          let mut v660_7 = Space::new();
          let mut v660_7_write = v660_7.write_zipper();
          for v660_7_byte in v656_28_cursor.child_mask().iter() {
            v656_28_cursor.descend_to_existing_byte(v660_7_byte);
            {
            let v661_2: Space = singleton(&v656_28_cursor.path()[(v656_28_origin + 2)..(v656_28_origin + 3)]);
            let v661_3: Space = intersect(&(*CONSTANT_2),&(v661_2));
            let v661_4: Space = if has_head(&(v661_3)) { singleton(&[]) } else { Space::new() };
            drop(v661_3);
            let v661_5: Space = subtract(&(*CONSTANT_1),&(v661_4));
            drop(v661_4);
            let v661_8: Space = if (&(v661_5)).is_empty() { Space::new() } else {
              let v662_6: Path = concat_path(&(v660_6),&v656_28_cursor.path()[(v656_28_origin + 2)..(v656_28_origin + 3)]);
              let v662_7: Space = routine_46(c, &(v662_6), &(*p1), &v656_28_cursor, &(*s1));
              compose(&(v661_5),&(v662_7))
            };
            drop(v661_5);
            let v661_9: Space = intersect(&(*CONSTANT_2),&(v661_2));
            drop(v661_2);
            let v661_10: Space = if has_head(&(v661_9)) { singleton(&[]) } else { Space::new() };
            drop(v661_9);
            let v661_12: Space = if (&(v661_10)).is_empty() { Space::new() } else {
              let v663_6: Path = concat_path(&(v660_6),&v656_28_cursor.path()[(v656_28_origin + 2)..(v656_28_origin + 3)]);
              let v663_11: Space = routine_47(c, &(v663_6), &(*p1), &v656_28_cursor, &(*s1));
              drop(v663_6);
              compose(&(v661_10),&(v663_11))
            };
            drop(v661_10);
            let v661_13: Space = unite(&(v661_8),&(v661_12));
            join_wrapped_into(&mut v660_7_write,&((v661_13).read_zipper()),&[]);
            }
            v656_28_cursor.ascend(1);
          }
          drop(v660_7_write);
          compose(&(v659_5),&(v660_7))
        };
        drop(v659_5);
        let v659_9: Space = intersect(&(*CONSTANT_2),&(v659_2));
        drop(v659_2);
        let v659_10: Space = if has_head(&(v659_9)) { singleton(&[]) } else { Space::new() };
        drop(v659_9);
        let v659_12: Space = if (&(v659_10)).is_empty() { Space::new() } else {
          let v664_6: Path = concat_path(&(v658_6),&v656_28_cursor.path()[(v656_28_origin + 1)..(v656_28_origin + 2)]);
          let mut v664_11 = Space::new();
          let mut v664_11_write = v664_11.write_zipper();
          for v664_11_byte in v656_28_cursor.child_mask().iter() {
            v656_28_cursor.descend_to_existing_byte(v664_11_byte);
            {
            let v665_2: Space = singleton(&v656_28_cursor.path()[(v656_28_origin + 2)..(v656_28_origin + 3)]);
            let v665_3: Space = intersect(&(*CONSTANT_2),&(v665_2));
            let v665_4: Space = if has_head(&(v665_3)) { singleton(&[]) } else { Space::new() };
            drop(v665_3);
            let v665_5: Space = subtract(&(*CONSTANT_1),&(v665_4));
            drop(v665_4);
            let v665_8: Space = if (&(v665_5)).is_empty() { Space::new() } else {
              let v666_6: Path = concat_path(&(v664_6),&v656_28_cursor.path()[(v656_28_origin + 2)..(v656_28_origin + 3)]);
              let v666_7: Space = routine_46(c, &(v666_6), &(*p1), &v656_28_cursor, &(*s1));
              compose(&(v665_5),&(v666_7))
            };
            drop(v665_5);
            let v665_9: Space = intersect(&(*CONSTANT_2),&(v665_2));
            drop(v665_2);
            let v665_10: Space = if has_head(&(v665_9)) { singleton(&[]) } else { Space::new() };
            drop(v665_9);
            let v665_12: Space = if (&(v665_10)).is_empty() { Space::new() } else {
              let v667_6: Path = concat_path(&(v664_6),&v656_28_cursor.path()[(v656_28_origin + 2)..(v656_28_origin + 3)]);
              let v667_11: Space = routine_10(c, &(v667_6), &(*p1), &v656_28_cursor, &(*s1));
              drop(v667_6);
              compose(&(v665_10),&(v667_11))
            };
            drop(v665_10);
            let v665_13: Space = unite(&(v665_8),&(v665_12));
            join_wrapped_into(&mut v664_11_write,&((v665_13).read_zipper()),&[]);
            }
            v656_28_cursor.ascend(1);
          }
          drop(v664_11_write);
          drop(v664_6);
          compose(&(v659_10),&(v664_11))
        };
        drop(v659_10);
        let v659_13: Space = unite(&(v659_8),&(v659_12));
        join_wrapped_into(&mut v658_7_write,&((v659_13).read_zipper()),&[]);
        }
        v656_28_cursor.ascend(1);
      }
      drop(v658_7_write);
      compose(&(v657_5),&(v658_7))
    };
    drop(v657_5);
    let v657_9: Space = intersect(&(*CONSTANT_2),&(v657_2));
    drop(v657_2);
    let v657_10: Space = if has_head(&(v657_9)) { singleton(&[]) } else { Space::new() };
    drop(v657_9);
    let v657_13: Space = if (&(v657_10)).is_empty() { Space::new() } else {
      let v668_6: Path = concat_path(&(*p0),&v656_28_cursor.path()[v656_28_origin..(v656_28_origin + 1)]);
      let mut v668_12 = Space::new();
      let mut v668_12_write = v668_12.write_zipper();
      for v668_12_byte in v656_28_cursor.child_mask().iter() {
        v656_28_cursor.descend_to_existing_byte(v668_12_byte);
        {
        let v669_2: Space = singleton(&v656_28_cursor.path()[(v656_28_origin + 1)..(v656_28_origin + 2)]);
        let v669_3: Space = intersect(&(*CONSTANT_2),&(v669_2));
        let v669_4: Space = if has_head(&(v669_3)) { singleton(&[]) } else { Space::new() };
        drop(v669_3);
        let v669_5: Space = subtract(&(*CONSTANT_1),&(v669_4));
        drop(v669_4);
        let v669_8: Space = if (&(v669_5)).is_empty() { Space::new() } else {
          let v670_6: Path = concat_path(&(v668_6),&v656_28_cursor.path()[(v656_28_origin + 1)..(v656_28_origin + 2)]);
          let mut v670_7 = Space::new();
          let mut v670_7_write = v670_7.write_zipper();
          for v670_7_byte in v656_28_cursor.child_mask().iter() {
            v656_28_cursor.descend_to_existing_byte(v670_7_byte);
            {
            let v671_2: Space = singleton(&v656_28_cursor.path()[(v656_28_origin + 2)..(v656_28_origin + 3)]);
            let v671_3: Space = intersect(&(*CONSTANT_2),&(v671_2));
            let v671_4: Space = if has_head(&(v671_3)) { singleton(&[]) } else { Space::new() };
            drop(v671_3);
            let v671_5: Space = subtract(&(*CONSTANT_1),&(v671_4));
            drop(v671_4);
            let v671_8: Space = if (&(v671_5)).is_empty() { Space::new() } else {
              let v672_6: Path = concat_path(&(v670_6),&v656_28_cursor.path()[(v656_28_origin + 2)..(v656_28_origin + 3)]);
              let v672_7: Space = routine_46(c, &(v672_6), &(*p1), &v656_28_cursor, &(*s1));
              compose(&(v671_5),&(v672_7))
            };
            drop(v671_5);
            let v671_9: Space = intersect(&(*CONSTANT_2),&(v671_2));
            drop(v671_2);
            let v671_10: Space = if has_head(&(v671_9)) { singleton(&[]) } else { Space::new() };
            drop(v671_9);
            let v671_12: Space = if (&(v671_10)).is_empty() { Space::new() } else {
              let v673_6: Path = concat_path(&(v670_6),&v656_28_cursor.path()[(v656_28_origin + 2)..(v656_28_origin + 3)]);
              let v673_11: Space = routine_47(c, &(v673_6), &(*p1), &v656_28_cursor, &(*s1));
              drop(v673_6);
              compose(&(v671_10),&(v673_11))
            };
            drop(v671_10);
            let v671_13: Space = unite(&(v671_8),&(v671_12));
            join_wrapped_into(&mut v670_7_write,&((v671_13).read_zipper()),&[]);
            }
            v656_28_cursor.ascend(1);
          }
          drop(v670_7_write);
          drop(v670_6);
          compose(&(v669_5),&(v670_7))
        };
        drop(v669_5);
        let v669_9: Space = intersect(&(*CONSTANT_2),&(v669_2));
        drop(v669_2);
        let v669_10: Space = if has_head(&(v669_9)) { singleton(&[]) } else { Space::new() };
        drop(v669_9);
        let v669_13: Space = if (&(v669_10)).is_empty() { Space::new() } else {
          let mut v674_12 = Space::new();
          let mut v674_12_write = v674_12.write_zipper();
          let mut v674_12_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v656_28_cursor.path()[v656_28_origin..(v656_28_origin + 1)]),&v656_28_cursor.path()[(v656_28_origin + 1)..(v656_28_origin + 2)]);
          let v674_12_origin = v674_12_cursor.path().len();
          for v674_12_byte in v674_12_cursor.child_mask().iter() {
            v674_12_cursor.descend_to_existing_byte(v674_12_byte);
            {
            let v675_2: Space = singleton(&v674_12_cursor.path()[v674_12_origin..(v674_12_origin + 1)]);
            let v675_3: Space = intersect(&(*CONSTANT_2),&(v675_2));
            let v675_4: Space = if has_head(&(v675_3)) { singleton(&[]) } else { Space::new() };
            drop(v675_3);
            let v675_5: Space = subtract(&(*CONSTANT_1),&(v675_4));
            drop(v675_4);
            let v675_7: Space = if (&(v675_5)).is_empty() { Space::new() } else {
              let v676_6: Space = routine_13(c, &v674_12_cursor.path()[v674_12_origin..(v674_12_origin + 1)], &(*p1), &v674_12_cursor);
              compose(&(v675_5),&(v676_6))
            };
            drop(v675_5);
            let v675_8: Space = intersect(&(*CONSTANT_2),&(v675_2));
            drop(v675_2);
            let v675_9: Space = if has_head(&(v675_8)) { singleton(&[]) } else { Space::new() };
            drop(v675_8);
            let v675_11: Space = if (&(v675_9)).is_empty() { Space::new() } else {
              let v677_10: Space = routine_14(c, &v674_12_cursor.path()[v674_12_origin..(v674_12_origin + 1)], &(*p1), &v674_12_cursor);
              compose(&(v675_9),&(v677_10))
            };
            drop(v675_9);
            let v675_12: Space = unite(&(v675_7),&(v675_11));
            join_wrapped_into(&mut v674_12_write,&((v675_12).read_zipper()),&[]);
            }
            v674_12_cursor.ascend(1);
          }
          drop(v674_12_cursor);
          drop(v674_12_write);
          compose(&(v669_10),&(v674_12))
        };
        drop(v669_10);
        let v669_14: Space = unite(&(v669_8),&(v669_13));
        join_wrapped_into(&mut v668_12_write,&((v669_14).read_zipper()),&[]);
        }
        v656_28_cursor.ascend(1);
      }
      drop(v668_12_write);
      drop(v668_6);
      compose(&(v657_10),&(v668_12))
    };
    drop(v657_10);
    let v657_14: Space = unite(&(v657_8),&(v657_13));
    join_wrapped_into(&mut v656_28_write,&((v657_14).read_zipper()),&[]);
    }
    v656_28_cursor.ascend(1);
  }
  drop(v656_28_cursor);
  drop(v656_28_write);
  (v656_28).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v678_28 = Space::new();
  let mut v678_28_write = v678_28.write_zipper();
  let mut v678_28_cursor = (*s0).read_zipper();
  let v678_28_origin = v678_28_cursor.path().len();
  for v678_28_byte in v678_28_cursor.child_mask().iter() {
    v678_28_cursor.descend_to_existing_byte(v678_28_byte);
    {
    let v679_2: Space = singleton(&v678_28_cursor.path()[v678_28_origin..(v678_28_origin + 1)]);
    let v679_3: Space = intersect(&(*CONSTANT_2),&(v679_2));
    let v679_4: Space = if has_head(&(v679_3)) { singleton(&[]) } else { Space::new() };
    drop(v679_3);
    let v679_5: Space = subtract(&(*CONSTANT_1),&(v679_4));
    drop(v679_4);
    let v679_8: Space = if (&(v679_5)).is_empty() { Space::new() } else {
      let v680_6: Path = concat_path(&(*p0),&v678_28_cursor.path()[v678_28_origin..(v678_28_origin + 1)]);
      let mut v680_7 = Space::new();
      let mut v680_7_write = v680_7.write_zipper();
      for v680_7_byte in v678_28_cursor.child_mask().iter() {
        v678_28_cursor.descend_to_existing_byte(v680_7_byte);
        {
        let v681_2: Space = singleton(&v678_28_cursor.path()[(v678_28_origin + 1)..(v678_28_origin + 2)]);
        let v681_3: Space = intersect(&(*CONSTANT_2),&(v681_2));
        let v681_4: Space = if has_head(&(v681_3)) { singleton(&[]) } else { Space::new() };
        drop(v681_3);
        let v681_5: Space = subtract(&(*CONSTANT_1),&(v681_4));
        drop(v681_4);
        let v681_8: Space = if (&(v681_5)).is_empty() { Space::new() } else {
          let v682_6: Path = concat_path(&(v680_6),&v678_28_cursor.path()[(v678_28_origin + 1)..(v678_28_origin + 2)]);
          let mut v682_7 = Space::new();
          let mut v682_7_write = v682_7.write_zipper();
          for v682_7_byte in v678_28_cursor.child_mask().iter() {
            v678_28_cursor.descend_to_existing_byte(v682_7_byte);
            {
            let v683_2: Space = singleton(&v678_28_cursor.path()[(v678_28_origin + 2)..(v678_28_origin + 3)]);
            let v683_3: Space = intersect(&(*CONSTANT_2),&(v683_2));
            let v683_4: Space = if has_head(&(v683_3)) { singleton(&[]) } else { Space::new() };
            drop(v683_3);
            let v683_5: Space = subtract(&(*CONSTANT_1),&(v683_4));
            drop(v683_4);
            let v683_8: Space = if (&(v683_5)).is_empty() { Space::new() } else {
              let v684_6: Path = concat_path(&(v682_6),&v678_28_cursor.path()[(v678_28_origin + 2)..(v678_28_origin + 3)]);
              let v684_7: Space = routine_46(c, &(v684_6), &(*p1), &v678_28_cursor, &(*s1));
              compose(&(v683_5),&(v684_7))
            };
            drop(v683_5);
            let v683_9: Space = intersect(&(*CONSTANT_2),&(v683_2));
            drop(v683_2);
            let v683_10: Space = if has_head(&(v683_9)) { singleton(&[]) } else { Space::new() };
            drop(v683_9);
            let v683_12: Space = if (&(v683_10)).is_empty() { Space::new() } else {
              let v685_6: Path = concat_path(&(v682_6),&v678_28_cursor.path()[(v678_28_origin + 2)..(v678_28_origin + 3)]);
              let v685_11: Space = routine_47(c, &(v685_6), &(*p1), &v678_28_cursor, &(*s1));
              drop(v685_6);
              compose(&(v683_10),&(v685_11))
            };
            drop(v683_10);
            let v683_13: Space = unite(&(v683_8),&(v683_12));
            join_wrapped_into(&mut v682_7_write,&((v683_13).read_zipper()),&[]);
            }
            v678_28_cursor.ascend(1);
          }
          drop(v682_7_write);
          compose(&(v681_5),&(v682_7))
        };
        drop(v681_5);
        let v681_9: Space = intersect(&(*CONSTANT_2),&(v681_2));
        drop(v681_2);
        let v681_10: Space = if has_head(&(v681_9)) { singleton(&[]) } else { Space::new() };
        drop(v681_9);
        let v681_12: Space = if (&(v681_10)).is_empty() { Space::new() } else {
          let v686_6: Path = concat_path(&(v680_6),&v678_28_cursor.path()[(v678_28_origin + 1)..(v678_28_origin + 2)]);
          let mut v686_11 = Space::new();
          let mut v686_11_write = v686_11.write_zipper();
          for v686_11_byte in v678_28_cursor.child_mask().iter() {
            v678_28_cursor.descend_to_existing_byte(v686_11_byte);
            {
            let v687_2: Space = singleton(&v678_28_cursor.path()[(v678_28_origin + 2)..(v678_28_origin + 3)]);
            let v687_3: Space = intersect(&(*CONSTANT_2),&(v687_2));
            let v687_4: Space = if has_head(&(v687_3)) { singleton(&[]) } else { Space::new() };
            drop(v687_3);
            let v687_5: Space = subtract(&(*CONSTANT_1),&(v687_4));
            drop(v687_4);
            let v687_8: Space = if (&(v687_5)).is_empty() { Space::new() } else {
              let v688_6: Path = concat_path(&(v686_6),&v678_28_cursor.path()[(v678_28_origin + 2)..(v678_28_origin + 3)]);
              let v688_7: Space = routine_46(c, &(v688_6), &(*p1), &v678_28_cursor, &(*s1));
              compose(&(v687_5),&(v688_7))
            };
            drop(v687_5);
            let v687_9: Space = intersect(&(*CONSTANT_2),&(v687_2));
            drop(v687_2);
            let v687_10: Space = if has_head(&(v687_9)) { singleton(&[]) } else { Space::new() };
            drop(v687_9);
            let v687_12: Space = if (&(v687_10)).is_empty() { Space::new() } else {
              let v689_6: Path = concat_path(&(v686_6),&v678_28_cursor.path()[(v678_28_origin + 2)..(v678_28_origin + 3)]);
              let v689_11: Space = routine_10(c, &(v689_6), &(*p1), &v678_28_cursor, &(*s1));
              drop(v689_6);
              compose(&(v687_10),&(v689_11))
            };
            drop(v687_10);
            let v687_13: Space = unite(&(v687_8),&(v687_12));
            join_wrapped_into(&mut v686_11_write,&((v687_13).read_zipper()),&[]);
            }
            v678_28_cursor.ascend(1);
          }
          drop(v686_11_write);
          drop(v686_6);
          compose(&(v681_10),&(v686_11))
        };
        drop(v681_10);
        let v681_13: Space = unite(&(v681_8),&(v681_12));
        join_wrapped_into(&mut v680_7_write,&((v681_13).read_zipper()),&[]);
        }
        v678_28_cursor.ascend(1);
      }
      drop(v680_7_write);
      drop(v680_6);
      compose(&(v679_5),&(v680_7))
    };
    drop(v679_5);
    let v679_9: Space = intersect(&(*CONSTANT_2),&(v679_2));
    drop(v679_2);
    let v679_10: Space = if has_head(&(v679_9)) { singleton(&[]) } else { Space::new() };
    drop(v679_9);
    let v679_13: Space = if (&(v679_10)).is_empty() { Space::new() } else {
      let mut v690_12 = Space::new();
      let mut v690_12_write = v690_12.write_zipper();
      let mut v690_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v678_28_cursor.path()[v678_28_origin..(v678_28_origin + 1)]);
      let v690_12_origin = v690_12_cursor.path().len();
      for v690_12_byte in v690_12_cursor.child_mask().iter() {
        v690_12_cursor.descend_to_existing_byte(v690_12_byte);
        {
        let v691_2: Space = singleton(&v690_12_cursor.path()[v690_12_origin..(v690_12_origin + 1)]);
        let v691_3: Space = intersect(&(*CONSTANT_2),&(v691_2));
        let v691_4: Space = if has_head(&(v691_3)) { singleton(&[]) } else { Space::new() };
        drop(v691_3);
        let v691_5: Space = subtract(&(*CONSTANT_1),&(v691_4));
        drop(v691_4);
        let v691_7: Space = if (&(v691_5)).is_empty() { Space::new() } else {
          let mut v692_6 = Space::new();
          let mut v692_6_write = v692_6.write_zipper();
          for v692_6_byte in v690_12_cursor.child_mask().iter() {
            v690_12_cursor.descend_to_existing_byte(v692_6_byte);
            {
            let v693_2: Space = singleton(&v690_12_cursor.path()[(v690_12_origin + 1)..(v690_12_origin + 2)]);
            let v693_3: Space = intersect(&(*CONSTANT_2),&(v693_2));
            let v693_4: Space = if has_head(&(v693_3)) { singleton(&[]) } else { Space::new() };
            drop(v693_3);
            let v693_5: Space = subtract(&(*CONSTANT_1),&(v693_4));
            drop(v693_4);
            let v693_8: Space = if (&(v693_5)).is_empty() { Space::new() } else {
              let v694_7: Space = routine_17(c, &v690_12_cursor.path()[v690_12_origin..(v690_12_origin + 2)], &(*p1), &v690_12_cursor);
              compose(&(v693_5),&(v694_7))
            };
            drop(v693_5);
            let v693_9: Space = intersect(&(*CONSTANT_2),&(v693_2));
            drop(v693_2);
            let v693_10: Space = if has_head(&(v693_9)) { singleton(&[]) } else { Space::new() };
            drop(v693_9);
            let v693_12: Space = if (&(v693_10)).is_empty() { Space::new() } else {
              let v695_11: Space = routine_18(c, &v690_12_cursor.path()[v690_12_origin..(v690_12_origin + 2)], &(*p1), &v690_12_cursor);
              compose(&(v693_10),&(v695_11))
            };
            drop(v693_10);
            let v693_13: Space = unite(&(v693_8),&(v693_12));
            join_wrapped_into(&mut v692_6_write,&((v693_13).read_zipper()),&[]);
            }
            v690_12_cursor.ascend(1);
          }
          drop(v692_6_write);
          compose(&(v691_5),&(v692_6))
        };
        drop(v691_5);
        let v691_8: Space = intersect(&(*CONSTANT_2),&(v691_2));
        drop(v691_2);
        let v691_9: Space = if has_head(&(v691_8)) { singleton(&[]) } else { Space::new() };
        drop(v691_8);
        let v691_11: Space = if (&(v691_9)).is_empty() { Space::new() } else {
          let mut v696_10 = Space::new();
          let mut v696_10_write = v696_10.write_zipper();
          for v696_10_byte in v690_12_cursor.child_mask().iter() {
            v690_12_cursor.descend_to_existing_byte(v696_10_byte);
            {
            let v697_2: Space = singleton(&v690_12_cursor.path()[(v690_12_origin + 1)..(v690_12_origin + 2)]);
            let v697_3: Space = intersect(&(*CONSTANT_2),&(v697_2));
            let v697_4: Space = if has_head(&(v697_3)) { singleton(&[]) } else { Space::new() };
            drop(v697_3);
            let v697_5: Space = subtract(&(*CONSTANT_1),&(v697_4));
            drop(v697_4);
            let v697_8: Space = if (&(v697_5)).is_empty() { Space::new() } else {
              let v698_7: Space = routine_17(c, &v690_12_cursor.path()[v690_12_origin..(v690_12_origin + 2)], &(*p1), &v690_12_cursor);
              compose(&(v697_5),&(v698_7))
            };
            drop(v697_5);
            let v697_9: Space = intersect(&(*CONSTANT_2),&(v697_2));
            drop(v697_2);
            let v697_10: Space = if has_head(&(v697_9)) { singleton(&[]) } else { Space::new() };
            drop(v697_9);
            let v697_12: Space = if (&(v697_10)).is_empty() { Space::new() } else {
              let v699_11: Space = routine_19(c, &v690_12_cursor.path()[v690_12_origin..(v690_12_origin + 2)], &(*p1), &v690_12_cursor);
              compose(&(v697_10),&(v699_11))
            };
            drop(v697_10);
            let v697_13: Space = unite(&(v697_8),&(v697_12));
            join_wrapped_into(&mut v696_10_write,&((v697_13).read_zipper()),&[]);
            }
            v690_12_cursor.ascend(1);
          }
          drop(v696_10_write);
          compose(&(v691_9),&(v696_10))
        };
        drop(v691_9);
        let v691_12: Space = unite(&(v691_7),&(v691_11));
        join_wrapped_into(&mut v690_12_write,&((v691_12).read_zipper()),&[]);
        }
        v690_12_cursor.ascend(1);
      }
      drop(v690_12_cursor);
      drop(v690_12_write);
      compose(&(v679_10),&(v690_12))
    };
    drop(v679_10);
    let v679_14: Space = unite(&(v679_8),&(v679_13));
    join_wrapped_into(&mut v678_28_write,&((v679_14).read_zipper()),&[]);
    }
    v678_28_cursor.ascend(1);
  }
  drop(v678_28_cursor);
  drop(v678_28_write);
  (v678_28).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v700_21 = Space::new();
  let mut v700_21_write = v700_21.write_zipper();
  let mut v700_21_cursor = (*s0).read_zipper();
  let v700_21_origin = v700_21_cursor.path().len();
  for v700_21_byte in v700_21_cursor.child_mask().iter() {
    v700_21_cursor.descend_to_existing_byte(v700_21_byte);
    {
    let v701_2: Space = singleton(&v700_21_cursor.path()[v700_21_origin..(v700_21_origin + 1)]);
    let v701_3: Space = intersect(&(*CONSTANT_2),&(v701_2));
    let v701_4: Space = if has_head(&(v701_3)) { singleton(&[]) } else { Space::new() };
    drop(v701_3);
    let v701_5: Space = subtract(&(*CONSTANT_1),&(v701_4));
    drop(v701_4);
    let v701_8: Space = if (&(v701_5)).is_empty() { Space::new() } else {
      let v702_6: Path = concat_path(&(*p0),&v700_21_cursor.path()[v700_21_origin..(v700_21_origin + 1)]);
      let mut v702_7 = Space::new();
      let mut v702_7_write = v702_7.write_zipper();
      for v702_7_byte in v700_21_cursor.child_mask().iter() {
        v700_21_cursor.descend_to_existing_byte(v702_7_byte);
        {
        let v703_2: Space = singleton(&v700_21_cursor.path()[(v700_21_origin + 1)..(v700_21_origin + 2)]);
        let v703_3: Space = intersect(&(*CONSTANT_2),&(v703_2));
        let v703_4: Space = if has_head(&(v703_3)) { singleton(&[]) } else { Space::new() };
        drop(v703_3);
        let v703_5: Space = subtract(&(*CONSTANT_1),&(v703_4));
        drop(v703_4);
        let v703_8: Space = if (&(v703_5)).is_empty() { Space::new() } else {
          let v704_6: Path = concat_path(&(v702_6),&v700_21_cursor.path()[(v700_21_origin + 1)..(v700_21_origin + 2)]);
          let mut v704_7 = Space::new();
          let mut v704_7_write = v704_7.write_zipper();
          for v704_7_byte in v700_21_cursor.child_mask().iter() {
            v700_21_cursor.descend_to_existing_byte(v704_7_byte);
            {
            let v705_2: Space = singleton(&v700_21_cursor.path()[(v700_21_origin + 2)..(v700_21_origin + 3)]);
            let v705_3: Space = intersect(&(*CONSTANT_2),&(v705_2));
            let v705_4: Space = if has_head(&(v705_3)) { singleton(&[]) } else { Space::new() };
            drop(v705_3);
            let v705_5: Space = subtract(&(*CONSTANT_1),&(v705_4));
            drop(v705_4);
            let v705_8: Space = if (&(v705_5)).is_empty() { Space::new() } else {
              let v706_6: Path = concat_path(&(v704_6),&v700_21_cursor.path()[(v700_21_origin + 2)..(v700_21_origin + 3)]);
              let v706_7: Space = routine_48(c, &(v706_6), &(*p1), &v700_21_cursor);
              compose(&(v705_5),&(v706_7))
            };
            drop(v705_5);
            let v705_9: Space = intersect(&(*CONSTANT_2),&(v705_2));
            drop(v705_2);
            let v705_10: Space = if has_head(&(v705_9)) { singleton(&[]) } else { Space::new() };
            drop(v705_9);
            let v705_12: Space = if (&(v705_10)).is_empty() { Space::new() } else {
              let v707_6: Path = concat_path(&(v704_6),&v700_21_cursor.path()[(v700_21_origin + 2)..(v700_21_origin + 3)]);
              let v707_11: Space = routine_49(c, &(v707_6), &(*p1), &v700_21_cursor);
              drop(v707_6);
              compose(&(v705_10),&(v707_11))
            };
            drop(v705_10);
            let v705_13: Space = unite(&(v705_8),&(v705_12));
            join_wrapped_into(&mut v704_7_write,&((v705_13).read_zipper()),&[]);
            }
            v700_21_cursor.ascend(1);
          }
          drop(v704_7_write);
          compose(&(v703_5),&(v704_7))
        };
        drop(v703_5);
        let v703_9: Space = intersect(&(*CONSTANT_2),&(v703_2));
        drop(v703_2);
        let v703_10: Space = if has_head(&(v703_9)) { singleton(&[]) } else { Space::new() };
        drop(v703_9);
        let v703_12: Space = if (&(v703_10)).is_empty() { Space::new() } else {
          let v708_6: Path = concat_path(&(v702_6),&v700_21_cursor.path()[(v700_21_origin + 1)..(v700_21_origin + 2)]);
          let mut v708_11 = Space::new();
          let mut v708_11_write = v708_11.write_zipper();
          for v708_11_byte in v700_21_cursor.child_mask().iter() {
            v700_21_cursor.descend_to_existing_byte(v708_11_byte);
            {
            let v709_2: Space = singleton(&v700_21_cursor.path()[(v700_21_origin + 2)..(v700_21_origin + 3)]);
            let v709_3: Space = intersect(&(*CONSTANT_2),&(v709_2));
            let v709_4: Space = if has_head(&(v709_3)) { singleton(&[]) } else { Space::new() };
            drop(v709_3);
            let v709_5: Space = subtract(&(*CONSTANT_1),&(v709_4));
            drop(v709_4);
            let v709_8: Space = if (&(v709_5)).is_empty() { Space::new() } else {
              let v710_6: Path = concat_path(&(v708_6),&v700_21_cursor.path()[(v700_21_origin + 2)..(v700_21_origin + 3)]);
              let v710_7: Space = routine_48(c, &(v710_6), &(*p1), &v700_21_cursor);
              compose(&(v709_5),&(v710_7))
            };
            drop(v709_5);
            let v709_9: Space = intersect(&(*CONSTANT_2),&(v709_2));
            drop(v709_2);
            let v709_10: Space = if has_head(&(v709_9)) { singleton(&[]) } else { Space::new() };
            drop(v709_9);
            let v709_12: Space = if (&(v709_10)).is_empty() { Space::new() } else {
              let v711_6: Path = concat_path(&(v708_6),&v700_21_cursor.path()[(v700_21_origin + 2)..(v700_21_origin + 3)]);
              let v711_11: Space = routine_19(c, &(v711_6), &(*p1), &v700_21_cursor);
              drop(v711_6);
              compose(&(v709_10),&(v711_11))
            };
            drop(v709_10);
            let v709_13: Space = unite(&(v709_8),&(v709_12));
            join_wrapped_into(&mut v708_11_write,&((v709_13).read_zipper()),&[]);
            }
            v700_21_cursor.ascend(1);
          }
          drop(v708_11_write);
          drop(v708_6);
          compose(&(v703_10),&(v708_11))
        };
        drop(v703_10);
        let v703_13: Space = unite(&(v703_8),&(v703_12));
        join_wrapped_into(&mut v702_7_write,&((v703_13).read_zipper()),&[]);
        }
        v700_21_cursor.ascend(1);
      }
      drop(v702_7_write);
      compose(&(v701_5),&(v702_7))
    };
    drop(v701_5);
    let v701_9: Space = intersect(&(*CONSTANT_2),&(v701_2));
    drop(v701_2);
    let v701_10: Space = if has_head(&(v701_9)) { singleton(&[]) } else { Space::new() };
    drop(v701_9);
    let v701_12: Space = if (&(v701_10)).is_empty() { Space::new() } else {
      let v712_6: Path = concat_path(&(*p0),&v700_21_cursor.path()[v700_21_origin..(v700_21_origin + 1)]);
      let mut v712_11 = Space::new();
      let mut v712_11_write = v712_11.write_zipper();
      for v712_11_byte in v700_21_cursor.child_mask().iter() {
        v700_21_cursor.descend_to_existing_byte(v712_11_byte);
        {
        let v713_2: Space = singleton(&v700_21_cursor.path()[(v700_21_origin + 1)..(v700_21_origin + 2)]);
        let v713_3: Space = intersect(&(*CONSTANT_2),&(v713_2));
        let v713_4: Space = if has_head(&(v713_3)) { singleton(&[]) } else { Space::new() };
        drop(v713_3);
        let v713_5: Space = subtract(&(*CONSTANT_1),&(v713_4));
        drop(v713_4);
        let v713_8: Space = if (&(v713_5)).is_empty() { Space::new() } else {
          let v714_6: Path = concat_path(&(v712_6),&v700_21_cursor.path()[(v700_21_origin + 1)..(v700_21_origin + 2)]);
          let mut v714_7 = Space::new();
          let mut v714_7_write = v714_7.write_zipper();
          for v714_7_byte in v700_21_cursor.child_mask().iter() {
            v700_21_cursor.descend_to_existing_byte(v714_7_byte);
            {
            let v715_2: Space = singleton(&v700_21_cursor.path()[(v700_21_origin + 2)..(v700_21_origin + 3)]);
            let v715_3: Space = intersect(&(*CONSTANT_2),&(v715_2));
            let v715_4: Space = if has_head(&(v715_3)) { singleton(&[]) } else { Space::new() };
            drop(v715_3);
            let v715_5: Space = subtract(&(*CONSTANT_1),&(v715_4));
            drop(v715_4);
            let v715_8: Space = if (&(v715_5)).is_empty() { Space::new() } else {
              let v716_6: Path = concat_path(&(v714_6),&v700_21_cursor.path()[(v700_21_origin + 2)..(v700_21_origin + 3)]);
              let v716_7: Space = routine_48(c, &(v716_6), &(*p1), &v700_21_cursor);
              compose(&(v715_5),&(v716_7))
            };
            drop(v715_5);
            let v715_9: Space = intersect(&(*CONSTANT_2),&(v715_2));
            drop(v715_2);
            let v715_10: Space = if has_head(&(v715_9)) { singleton(&[]) } else { Space::new() };
            drop(v715_9);
            let v715_12: Space = if (&(v715_10)).is_empty() { Space::new() } else {
              let v717_6: Path = concat_path(&(v714_6),&v700_21_cursor.path()[(v700_21_origin + 2)..(v700_21_origin + 3)]);
              let v717_11: Space = routine_49(c, &(v717_6), &(*p1), &v700_21_cursor);
              drop(v717_6);
              compose(&(v715_10),&(v717_11))
            };
            drop(v715_10);
            let v715_13: Space = unite(&(v715_8),&(v715_12));
            join_wrapped_into(&mut v714_7_write,&((v715_13).read_zipper()),&[]);
            }
            v700_21_cursor.ascend(1);
          }
          drop(v714_7_write);
          compose(&(v713_5),&(v714_7))
        };
        drop(v713_5);
        let v713_9: Space = intersect(&(*CONSTANT_2),&(v713_2));
        drop(v713_2);
        let v713_10: Space = if has_head(&(v713_9)) { singleton(&[]) } else { Space::new() };
        drop(v713_9);
        let v713_11: Space = compose(&(v713_10),&v700_21_cursor);
        drop(v713_10);
        let v718_6: Path = concat_path(&(v712_6),&v700_21_cursor.path()[(v700_21_origin + 1)..(v700_21_origin + 2)]);
        let v713_12: Space = wrap(&(v713_11),&(v718_6));
        drop(v713_11);
        let v713_13: Space = wrap(&(v713_12),&(*p1));
        drop(v713_12);
        let v713_14: Space = unite(&(v713_8),&(v713_13));
        drop(v713_13);
        join_wrapped_into(&mut v712_11_write,&((v713_14).read_zipper()),&[]);
        }
        v700_21_cursor.ascend(1);
      }
      drop(v712_11_write);
      drop(v712_6);
      compose(&(v701_10),&(v712_11))
    };
    drop(v701_10);
    let v701_13: Space = unite(&(v701_8),&(v701_12));
    join_wrapped_into(&mut v700_21_write,&((v701_13).read_zipper()),&[]);
    }
    v700_21_cursor.ascend(1);
  }
  drop(v700_21_cursor);
  drop(v700_21_write);
  (v700_21).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v719_15 = Space::new();
  let mut v719_15_write = v719_15.write_zipper();
  let mut v719_15_cursor = (*s0).read_zipper();
  let v719_15_origin = v719_15_cursor.path().len();
  for v719_15_byte in v719_15_cursor.child_mask().iter() {
    v719_15_cursor.descend_to_existing_byte(v719_15_byte);
    {
    let v720_2: Space = singleton(&v719_15_cursor.path()[v719_15_origin..(v719_15_origin + 1)]);
    let v720_3: Space = intersect(&(*CONSTANT_2),&(v720_2));
    let v720_4: Space = if has_head(&(v720_3)) { singleton(&[]) } else { Space::new() };
    drop(v720_3);
    let v720_5: Space = subtract(&(*CONSTANT_1),&(v720_4));
    drop(v720_4);
    let v720_8: Space = if (&(v720_5)).is_empty() { Space::new() } else {
      let v721_6: Path = concat_path(&(*p0),&v719_15_cursor.path()[v719_15_origin..(v719_15_origin + 1)]);
      let mut v721_7 = Space::new();
      let mut v721_7_write = v721_7.write_zipper();
      for v721_7_byte in v719_15_cursor.child_mask().iter() {
        v719_15_cursor.descend_to_existing_byte(v721_7_byte);
        {
        let v722_2: Space = singleton(&v719_15_cursor.path()[(v719_15_origin + 1)..(v719_15_origin + 2)]);
        let v722_3: Space = intersect(&(*CONSTANT_2),&(v722_2));
        let v722_4: Space = if has_head(&(v722_3)) { singleton(&[]) } else { Space::new() };
        drop(v722_3);
        let v722_5: Space = subtract(&(*CONSTANT_1),&(v722_4));
        drop(v722_4);
        let v722_8: Space = if (&(v722_5)).is_empty() { Space::new() } else {
          let v723_6: Path = concat_path(&(v721_6),&v719_15_cursor.path()[(v719_15_origin + 1)..(v719_15_origin + 2)]);
          let mut v723_7 = Space::new();
          let mut v723_7_write = v723_7.write_zipper();
          for v723_7_byte in v719_15_cursor.child_mask().iter() {
            v719_15_cursor.descend_to_existing_byte(v723_7_byte);
            {
            let v724_2: Space = singleton(&v719_15_cursor.path()[(v719_15_origin + 2)..(v719_15_origin + 3)]);
            let v724_3: Space = intersect(&(*CONSTANT_2),&(v724_2));
            let v724_4: Space = if has_head(&(v724_3)) { singleton(&[]) } else { Space::new() };
            drop(v724_3);
            let v724_5: Space = subtract(&(*CONSTANT_1),&(v724_4));
            drop(v724_4);
            let v724_8: Space = if (&(v724_5)).is_empty() { Space::new() } else {
              let v725_6: Path = concat_path(&(v723_6),&v719_15_cursor.path()[(v719_15_origin + 2)..(v719_15_origin + 3)]);
              let v725_7: Space = routine_48(c, &(v725_6), &(*p1), &v719_15_cursor);
              compose(&(v724_5),&(v725_7))
            };
            drop(v724_5);
            let v724_9: Space = intersect(&(*CONSTANT_2),&(v724_2));
            drop(v724_2);
            let v724_10: Space = if has_head(&(v724_9)) { singleton(&[]) } else { Space::new() };
            drop(v724_9);
            let v724_12: Space = if (&(v724_10)).is_empty() { Space::new() } else {
              let v726_6: Path = concat_path(&(v723_6),&v719_15_cursor.path()[(v719_15_origin + 2)..(v719_15_origin + 3)]);
              let v726_11: Space = routine_49(c, &(v726_6), &(*p1), &v719_15_cursor);
              drop(v726_6);
              compose(&(v724_10),&(v726_11))
            };
            drop(v724_10);
            let v724_13: Space = unite(&(v724_8),&(v724_12));
            join_wrapped_into(&mut v723_7_write,&((v724_13).read_zipper()),&[]);
            }
            v719_15_cursor.ascend(1);
          }
          drop(v723_7_write);
          compose(&(v722_5),&(v723_7))
        };
        drop(v722_5);
        let v722_9: Space = intersect(&(*CONSTANT_2),&(v722_2));
        drop(v722_2);
        let v722_10: Space = if has_head(&(v722_9)) { singleton(&[]) } else { Space::new() };
        drop(v722_9);
        let v722_12: Space = if (&(v722_10)).is_empty() { Space::new() } else {
          let v727_6: Path = concat_path(&(v721_6),&v719_15_cursor.path()[(v719_15_origin + 1)..(v719_15_origin + 2)]);
          let mut v727_11 = Space::new();
          let mut v727_11_write = v727_11.write_zipper();
          for v727_11_byte in v719_15_cursor.child_mask().iter() {
            v719_15_cursor.descend_to_existing_byte(v727_11_byte);
            {
            let v728_2: Space = singleton(&v719_15_cursor.path()[(v719_15_origin + 2)..(v719_15_origin + 3)]);
            let v728_3: Space = intersect(&(*CONSTANT_2),&(v728_2));
            let v728_4: Space = if has_head(&(v728_3)) { singleton(&[]) } else { Space::new() };
            drop(v728_3);
            let v728_5: Space = subtract(&(*CONSTANT_1),&(v728_4));
            drop(v728_4);
            let v728_8: Space = if (&(v728_5)).is_empty() { Space::new() } else {
              let v729_6: Path = concat_path(&(v727_6),&v719_15_cursor.path()[(v719_15_origin + 2)..(v719_15_origin + 3)]);
              let v729_7: Space = routine_48(c, &(v729_6), &(*p1), &v719_15_cursor);
              compose(&(v728_5),&(v729_7))
            };
            drop(v728_5);
            let v728_9: Space = intersect(&(*CONSTANT_2),&(v728_2));
            drop(v728_2);
            let v728_10: Space = if has_head(&(v728_9)) { singleton(&[]) } else { Space::new() };
            drop(v728_9);
            let v728_12: Space = if (&(v728_10)).is_empty() { Space::new() } else {
              let v730_6: Path = concat_path(&(v727_6),&v719_15_cursor.path()[(v719_15_origin + 2)..(v719_15_origin + 3)]);
              let v730_11: Space = routine_19(c, &(v730_6), &(*p1), &v719_15_cursor);
              drop(v730_6);
              compose(&(v728_10),&(v730_11))
            };
            drop(v728_10);
            let v728_13: Space = unite(&(v728_8),&(v728_12));
            join_wrapped_into(&mut v727_11_write,&((v728_13).read_zipper()),&[]);
            }
            v719_15_cursor.ascend(1);
          }
          drop(v727_11_write);
          drop(v727_6);
          compose(&(v722_10),&(v727_11))
        };
        drop(v722_10);
        let v722_13: Space = unite(&(v722_8),&(v722_12));
        join_wrapped_into(&mut v721_7_write,&((v722_13).read_zipper()),&[]);
        }
        v719_15_cursor.ascend(1);
      }
      drop(v721_7_write);
      compose(&(v720_5),&(v721_7))
    };
    drop(v720_5);
    let v720_9: Space = intersect(&(*CONSTANT_2),&(v720_2));
    drop(v720_2);
    let v720_10: Space = if has_head(&(v720_9)) { singleton(&[]) } else { Space::new() };
    drop(v720_9);
    let v720_11: Space = compose(&(v720_10),&v719_15_cursor);
    drop(v720_10);
    let v731_6: Path = concat_path(&(*p0),&v719_15_cursor.path()[v719_15_origin..(v719_15_origin + 1)]);
    let v720_12: Space = wrap(&(v720_11),&(v731_6));
    drop(v720_11);
    let v720_13: Space = wrap(&(v720_12),&(*p1));
    drop(v720_12);
    let v720_14: Space = unite(&(v720_8),&(v720_13));
    drop(v720_13);
    join_wrapped_into(&mut v719_15_write,&((v720_14).read_zipper()),&[]);
    }
    v719_15_cursor.ascend(1);
  }
  drop(v719_15_cursor);
  drop(v719_15_write);
  (v719_15).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v732_20 = Space::new();
  let mut v732_20_write = v732_20.write_zipper();
  let mut v732_20_cursor = (*s0).read_zipper();
  let v732_20_origin = v732_20_cursor.path().len();
  for v732_20_byte in v732_20_cursor.child_mask().iter() {
    v732_20_cursor.descend_to_existing_byte(v732_20_byte);
    {
    let v733_2: Space = singleton(&v732_20_cursor.path()[v732_20_origin..(v732_20_origin + 1)]);
    let v733_3: Space = intersect(&(*CONSTANT_2),&(v733_2));
    let v733_4: Space = if has_head(&(v733_3)) { singleton(&[]) } else { Space::new() };
    drop(v733_3);
    let v733_5: Space = subtract(&(*CONSTANT_1),&(v733_4));
    drop(v733_4);
    let v733_8: Space = if (&(v733_5)).is_empty() { Space::new() } else {
      let v734_6: Path = concat_path(&(*p0),&v732_20_cursor.path()[v732_20_origin..(v732_20_origin + 1)]);
      let mut v734_7 = Space::new();
      let mut v734_7_write = v734_7.write_zipper();
      for v734_7_byte in v732_20_cursor.child_mask().iter() {
        v732_20_cursor.descend_to_existing_byte(v734_7_byte);
        {
        let v735_2: Space = singleton(&v732_20_cursor.path()[(v732_20_origin + 1)..(v732_20_origin + 2)]);
        let v735_3: Space = intersect(&(*CONSTANT_2),&(v735_2));
        let v735_4: Space = if has_head(&(v735_3)) { singleton(&[]) } else { Space::new() };
        drop(v735_3);
        let v735_5: Space = subtract(&(*CONSTANT_1),&(v735_4));
        drop(v735_4);
        let v735_7: Space = if (&(v735_5)).is_empty() { Space::new() } else {
          let mut v736_6 = Space::new();
          let mut v736_6_write = v736_6.write_zipper();
          for v736_6_byte in v732_20_cursor.child_mask().iter() {
            v732_20_cursor.descend_to_existing_byte(v736_6_byte);
            {
            let v737_2: Space = Space::new();
            join_wrapped_into(&mut v736_6_write,&((v737_2).read_zipper()),&[]);
            }
            v732_20_cursor.ascend(1);
          }
          drop(v736_6_write);
          compose(&(v735_5),&(v736_6))
        };
        drop(v735_5);
        let v735_8: Space = intersect(&(*CONSTANT_2),&(v735_2));
        drop(v735_2);
        let v735_9: Space = if has_head(&(v735_8)) { singleton(&[]) } else { Space::new() };
        drop(v735_8);
        let v735_12: Space = if (&(v735_9)).is_empty() { Space::new() } else {
          let v738_10: Path = concat_path(&(v734_6),&v732_20_cursor.path()[(v732_20_origin + 1)..(v732_20_origin + 2)]);
          let mut v738_11 = Space::new();
          let mut v738_11_write = v738_11.write_zipper();
          for v738_11_byte in v732_20_cursor.child_mask().iter() {
            v732_20_cursor.descend_to_existing_byte(v738_11_byte);
            {
            let v739_2: Space = singleton(&v732_20_cursor.path()[(v732_20_origin + 2)..(v732_20_origin + 3)]);
            let v739_3: Space = intersect(&(*CONSTANT_2),&(v739_2));
            drop(v739_2);
            let v739_4: Space = if has_head(&(v739_3)) { singleton(&[]) } else { Space::new() };
            drop(v739_3);
            let v739_7: Space = if (&(v739_4)).is_empty() { Space::new() } else {
              let v740_5: Path = concat_path(&(v738_10),&v732_20_cursor.path()[(v732_20_origin + 2)..(v732_20_origin + 3)]);
              let v740_6: Space = routine_10(c, &(v740_5), &(*p1), &v732_20_cursor, &(*s1));
              drop(v740_5);
              compose(&(v739_4),&(v740_6))
            };
            drop(v739_4);
            join_wrapped_into(&mut v738_11_write,&((v739_7).read_zipper()),&[]);
            }
            v732_20_cursor.ascend(1);
          }
          drop(v738_11_write);
          drop(v738_10);
          compose(&(v735_9),&(v738_11))
        };
        drop(v735_9);
        let v735_13: Space = unite(&(v735_7),&(v735_12));
        drop(v735_7);
        join_wrapped_into(&mut v734_7_write,&((v735_13).read_zipper()),&[]);
        }
        v732_20_cursor.ascend(1);
      }
      drop(v734_7_write);
      drop(v734_6);
      compose(&(v733_5),&(v734_7))
    };
    drop(v733_5);
    let v733_9: Space = intersect(&(*CONSTANT_2),&(v733_2));
    drop(v733_2);
    let v733_10: Space = if has_head(&(v733_9)) { singleton(&[]) } else { Space::new() };
    drop(v733_9);
    let v733_13: Space = if (&(v733_10)).is_empty() { Space::new() } else {
      let mut v741_12 = Space::new();
      let mut v741_12_write = v741_12.write_zipper();
      for v741_12_byte in v732_20_cursor.child_mask().iter() {
        v732_20_cursor.descend_to_existing_byte(v741_12_byte);
        {
        let v742_2: Space = singleton(&v732_20_cursor.path()[(v732_20_origin + 1)..(v732_20_origin + 2)]);
        let v742_3: Space = intersect(&(*CONSTANT_2),&(v742_2));
        let v742_4: Space = if has_head(&(v742_3)) { singleton(&[]) } else { Space::new() };
        drop(v742_3);
        let v742_5: Space = subtract(&(*CONSTANT_1),&(v742_4));
        drop(v742_4);
        let v742_7: Space = if (&(v742_5)).is_empty() { Space::new() } else {
          let mut v743_6 = Space::new();
          let mut v743_6_write = v743_6.write_zipper();
          for v743_6_byte in v732_20_cursor.child_mask().iter() {
            v732_20_cursor.descend_to_existing_byte(v743_6_byte);
            {
            let v744_2: Space = Space::new();
            join_wrapped_into(&mut v743_6_write,&((v744_2).read_zipper()),&[]);
            }
            v732_20_cursor.ascend(1);
          }
          drop(v743_6_write);
          compose(&(v742_5),&(v743_6))
        };
        drop(v742_5);
        let v742_8: Space = intersect(&(*CONSTANT_2),&(v742_2));
        drop(v742_2);
        let v742_9: Space = if has_head(&(v742_8)) { singleton(&[]) } else { Space::new() };
        drop(v742_8);
        let v742_12: Space = if (&(v742_9)).is_empty() { Space::new() } else {
          let mut v745_11 = Space::new();
          let mut v745_11_write = v745_11.write_zipper();
          let mut v745_11_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v732_20_cursor.path()[v732_20_origin..(v732_20_origin + 1)]),&v732_20_cursor.path()[(v732_20_origin + 1)..(v732_20_origin + 2)]);
          let v745_11_origin = v745_11_cursor.path().len();
          for v745_11_byte in v745_11_cursor.child_mask().iter() {
            v745_11_cursor.descend_to_existing_byte(v745_11_byte);
            {
            let v746_2: Space = singleton(&v745_11_cursor.path()[v745_11_origin..(v745_11_origin + 1)]);
            let v746_3: Space = intersect(&(*CONSTANT_2),&(v746_2));
            let v746_4: Space = if has_head(&(v746_3)) { singleton(&[]) } else { Space::new() };
            drop(v746_3);
            let v746_5: Space = subtract(&(*CONSTANT_1),&(v746_4));
            drop(v746_4);
            let v746_7: Space = if (&(v746_5)).is_empty() { Space::new() } else {
              let v747_6: Space = routine_13(c, &v745_11_cursor.path()[v745_11_origin..(v745_11_origin + 1)], &(*p1), &v745_11_cursor);
              compose(&(v746_5),&(v747_6))
            };
            drop(v746_5);
            let v746_8: Space = intersect(&(*CONSTANT_2),&(v746_2));
            drop(v746_2);
            let v746_9: Space = if has_head(&(v746_8)) { singleton(&[]) } else { Space::new() };
            drop(v746_8);
            let v746_11: Space = if (&(v746_9)).is_empty() { Space::new() } else {
              let v748_10: Space = routine_14(c, &v745_11_cursor.path()[v745_11_origin..(v745_11_origin + 1)], &(*p1), &v745_11_cursor);
              compose(&(v746_9),&(v748_10))
            };
            drop(v746_9);
            let v746_12: Space = unite(&(v746_7),&(v746_11));
            join_wrapped_into(&mut v745_11_write,&((v746_12).read_zipper()),&[]);
            }
            v745_11_cursor.ascend(1);
          }
          drop(v745_11_cursor);
          drop(v745_11_write);
          compose(&(v742_9),&(v745_11))
        };
        drop(v742_9);
        let v742_13: Space = unite(&(v742_7),&(v742_12));
        drop(v742_7);
        join_wrapped_into(&mut v741_12_write,&((v742_13).read_zipper()),&[]);
        }
        v732_20_cursor.ascend(1);
      }
      drop(v741_12_write);
      compose(&(v733_10),&(v741_12))
    };
    drop(v733_10);
    let v733_14: Space = unite(&(v733_8),&(v733_13));
    join_wrapped_into(&mut v732_20_write,&((v733_14).read_zipper()),&[]);
    }
    v732_20_cursor.ascend(1);
  }
  drop(v732_20_cursor);
  drop(v732_20_write);
  (v732_20).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v749_23 = Space::new();
  let mut v749_23_write = v749_23.write_zipper();
  let mut v749_23_cursor = (*s0).read_zipper();
  let v749_23_origin = v749_23_cursor.path().len();
  for v749_23_byte in v749_23_cursor.child_mask().iter() {
    v749_23_cursor.descend_to_existing_byte(v749_23_byte);
    {
    let v750_2: Space = singleton(&v749_23_cursor.path()[v749_23_origin..(v749_23_origin + 1)]);
    let v750_3: Space = intersect(&(*CONSTANT_2),&(v750_2));
    let v750_4: Space = if has_head(&(v750_3)) { singleton(&[]) } else { Space::new() };
    drop(v750_3);
    let v750_5: Space = subtract(&(*CONSTANT_1),&(v750_4));
    drop(v750_4);
    let v750_8: Space = if (&(v750_5)).is_empty() { Space::new() } else {
      let v751_6: Path = concat_path(&(*p0),&v749_23_cursor.path()[v749_23_origin..(v749_23_origin + 1)]);
      let mut v751_7 = Space::new();
      let mut v751_7_write = v751_7.write_zipper();
      for v751_7_byte in v749_23_cursor.child_mask().iter() {
        v749_23_cursor.descend_to_existing_byte(v751_7_byte);
        {
        let v752_2: Space = singleton(&v749_23_cursor.path()[(v749_23_origin + 1)..(v749_23_origin + 2)]);
        let v752_3: Space = intersect(&(*CONSTANT_2),&(v752_2));
        let v752_4: Space = if has_head(&(v752_3)) { singleton(&[]) } else { Space::new() };
        drop(v752_3);
        let v752_5: Space = subtract(&(*CONSTANT_1),&(v752_4));
        drop(v752_4);
        let v752_7: Space = if (&(v752_5)).is_empty() { Space::new() } else {
          let mut v753_6 = Space::new();
          let mut v753_6_write = v753_6.write_zipper();
          for v753_6_byte in v749_23_cursor.child_mask().iter() {
            v749_23_cursor.descend_to_existing_byte(v753_6_byte);
            {
            let v754_2: Space = Space::new();
            join_wrapped_into(&mut v753_6_write,&((v754_2).read_zipper()),&[]);
            }
            v749_23_cursor.ascend(1);
          }
          drop(v753_6_write);
          compose(&(v752_5),&(v753_6))
        };
        drop(v752_5);
        let v752_8: Space = intersect(&(*CONSTANT_2),&(v752_2));
        drop(v752_2);
        let v752_9: Space = if has_head(&(v752_8)) { singleton(&[]) } else { Space::new() };
        drop(v752_8);
        let v752_12: Space = if (&(v752_9)).is_empty() { Space::new() } else {
          let v755_10: Path = concat_path(&(v751_6),&v749_23_cursor.path()[(v749_23_origin + 1)..(v749_23_origin + 2)]);
          let mut v755_11 = Space::new();
          let mut v755_11_write = v755_11.write_zipper();
          for v755_11_byte in v749_23_cursor.child_mask().iter() {
            v749_23_cursor.descend_to_existing_byte(v755_11_byte);
            {
            let v756_2: Space = singleton(&v749_23_cursor.path()[(v749_23_origin + 2)..(v749_23_origin + 3)]);
            let v756_3: Space = intersect(&(*CONSTANT_2),&(v756_2));
            drop(v756_2);
            let v756_4: Space = if has_head(&(v756_3)) { singleton(&[]) } else { Space::new() };
            drop(v756_3);
            let v756_7: Space = if (&(v756_4)).is_empty() { Space::new() } else {
              let v757_5: Path = concat_path(&(v755_10),&v749_23_cursor.path()[(v749_23_origin + 2)..(v749_23_origin + 3)]);
              let v757_6: Space = routine_10(c, &(v757_5), &(*p1), &v749_23_cursor, &(*s1));
              drop(v757_5);
              compose(&(v756_4),&(v757_6))
            };
            drop(v756_4);
            join_wrapped_into(&mut v755_11_write,&((v756_7).read_zipper()),&[]);
            }
            v749_23_cursor.ascend(1);
          }
          drop(v755_11_write);
          drop(v755_10);
          compose(&(v752_9),&(v755_11))
        };
        drop(v752_9);
        let v752_13: Space = unite(&(v752_7),&(v752_12));
        drop(v752_7);
        join_wrapped_into(&mut v751_7_write,&((v752_13).read_zipper()),&[]);
        }
        v749_23_cursor.ascend(1);
      }
      drop(v751_7_write);
      drop(v751_6);
      compose(&(v750_5),&(v751_7))
    };
    drop(v750_5);
    let v750_9: Space = intersect(&(*CONSTANT_2),&(v750_2));
    drop(v750_2);
    let v750_10: Space = if has_head(&(v750_9)) { singleton(&[]) } else { Space::new() };
    drop(v750_9);
    let v750_13: Space = if (&(v750_10)).is_empty() { Space::new() } else {
      let mut v758_12 = Space::new();
      let mut v758_12_write = v758_12.write_zipper();
      let mut v758_12_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v749_23_cursor.path()[v749_23_origin..(v749_23_origin + 1)]);
      let v758_12_origin = v758_12_cursor.path().len();
      for v758_12_byte in v758_12_cursor.child_mask().iter() {
        v758_12_cursor.descend_to_existing_byte(v758_12_byte);
        {
        let v759_2: Space = singleton(&v758_12_cursor.path()[v758_12_origin..(v758_12_origin + 1)]);
        let v759_3: Space = intersect(&(*CONSTANT_2),&(v759_2));
        let v759_4: Space = if has_head(&(v759_3)) { singleton(&[]) } else { Space::new() };
        drop(v759_3);
        let v759_5: Space = subtract(&(*CONSTANT_1),&(v759_4));
        drop(v759_4);
        let v759_7: Space = if (&(v759_5)).is_empty() { Space::new() } else {
          let mut v760_6 = Space::new();
          let mut v760_6_write = v760_6.write_zipper();
          for v760_6_byte in v758_12_cursor.child_mask().iter() {
            v758_12_cursor.descend_to_existing_byte(v760_6_byte);
            {
            let v761_2: Space = singleton(&v758_12_cursor.path()[(v758_12_origin + 1)..(v758_12_origin + 2)]);
            let v761_3: Space = intersect(&(*CONSTANT_2),&(v761_2));
            let v761_4: Space = if has_head(&(v761_3)) { singleton(&[]) } else { Space::new() };
            drop(v761_3);
            let v761_5: Space = subtract(&(*CONSTANT_1),&(v761_4));
            drop(v761_4);
            let v761_8: Space = if (&(v761_5)).is_empty() { Space::new() } else {
              let v762_7: Space = routine_17(c, &v758_12_cursor.path()[v758_12_origin..(v758_12_origin + 2)], &(*p1), &v758_12_cursor);
              compose(&(v761_5),&(v762_7))
            };
            drop(v761_5);
            let v761_9: Space = intersect(&(*CONSTANT_2),&(v761_2));
            drop(v761_2);
            let v761_10: Space = if has_head(&(v761_9)) { singleton(&[]) } else { Space::new() };
            drop(v761_9);
            let v761_12: Space = if (&(v761_10)).is_empty() { Space::new() } else {
              let v763_11: Space = routine_18(c, &v758_12_cursor.path()[v758_12_origin..(v758_12_origin + 2)], &(*p1), &v758_12_cursor);
              compose(&(v761_10),&(v763_11))
            };
            drop(v761_10);
            let v761_13: Space = unite(&(v761_8),&(v761_12));
            join_wrapped_into(&mut v760_6_write,&((v761_13).read_zipper()),&[]);
            }
            v758_12_cursor.ascend(1);
          }
          drop(v760_6_write);
          compose(&(v759_5),&(v760_6))
        };
        drop(v759_5);
        let v759_8: Space = intersect(&(*CONSTANT_2),&(v759_2));
        drop(v759_2);
        let v759_9: Space = if has_head(&(v759_8)) { singleton(&[]) } else { Space::new() };
        drop(v759_8);
        let v759_11: Space = if (&(v759_9)).is_empty() { Space::new() } else {
          let mut v764_10 = Space::new();
          let mut v764_10_write = v764_10.write_zipper();
          for v764_10_byte in v758_12_cursor.child_mask().iter() {
            v758_12_cursor.descend_to_existing_byte(v764_10_byte);
            {
            let v765_2: Space = singleton(&v758_12_cursor.path()[(v758_12_origin + 1)..(v758_12_origin + 2)]);
            let v765_3: Space = intersect(&(*CONSTANT_2),&(v765_2));
            let v765_4: Space = if has_head(&(v765_3)) { singleton(&[]) } else { Space::new() };
            drop(v765_3);
            let v765_5: Space = subtract(&(*CONSTANT_1),&(v765_4));
            drop(v765_4);
            let v765_8: Space = if (&(v765_5)).is_empty() { Space::new() } else {
              let v766_7: Space = routine_17(c, &v758_12_cursor.path()[v758_12_origin..(v758_12_origin + 2)], &(*p1), &v758_12_cursor);
              compose(&(v765_5),&(v766_7))
            };
            drop(v765_5);
            let v765_9: Space = intersect(&(*CONSTANT_2),&(v765_2));
            drop(v765_2);
            let v765_10: Space = if has_head(&(v765_9)) { singleton(&[]) } else { Space::new() };
            drop(v765_9);
            let v765_12: Space = if (&(v765_10)).is_empty() { Space::new() } else {
              let v767_11: Space = routine_19(c, &v758_12_cursor.path()[v758_12_origin..(v758_12_origin + 2)], &(*p1), &v758_12_cursor);
              compose(&(v765_10),&(v767_11))
            };
            drop(v765_10);
            let v765_13: Space = unite(&(v765_8),&(v765_12));
            join_wrapped_into(&mut v764_10_write,&((v765_13).read_zipper()),&[]);
            }
            v758_12_cursor.ascend(1);
          }
          drop(v764_10_write);
          compose(&(v759_9),&(v764_10))
        };
        drop(v759_9);
        let v759_12: Space = unite(&(v759_7),&(v759_11));
        join_wrapped_into(&mut v758_12_write,&((v759_12).read_zipper()),&[]);
        }
        v758_12_cursor.ascend(1);
      }
      drop(v758_12_cursor);
      drop(v758_12_write);
      compose(&(v750_10),&(v758_12))
    };
    drop(v750_10);
    let v750_14: Space = unite(&(v750_8),&(v750_13));
    join_wrapped_into(&mut v749_23_write,&((v750_14).read_zipper()),&[]);
    }
    v749_23_cursor.ascend(1);
  }
  drop(v749_23_cursor);
  drop(v749_23_write);
  (v749_23).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v768_21 = Space::new();
  let mut v768_21_write = v768_21.write_zipper();
  let mut v768_21_cursor = (*s0).read_zipper();
  let v768_21_origin = v768_21_cursor.path().len();
  for v768_21_byte in v768_21_cursor.child_mask().iter() {
    v768_21_cursor.descend_to_existing_byte(v768_21_byte);
    {
    let v769_2: Space = singleton(&v768_21_cursor.path()[v768_21_origin..(v768_21_origin + 1)]);
    let v769_3: Space = intersect(&(*CONSTANT_2),&(v769_2));
    let v769_4: Space = if has_head(&(v769_3)) { singleton(&[]) } else { Space::new() };
    drop(v769_3);
    let v769_5: Space = subtract(&(*CONSTANT_1),&(v769_4));
    drop(v769_4);
    let v769_8: Space = if (&(v769_5)).is_empty() { Space::new() } else {
      let v770_6: Path = concat_path(&(*p0),&v768_21_cursor.path()[v768_21_origin..(v768_21_origin + 1)]);
      let mut v770_7 = Space::new();
      let mut v770_7_write = v770_7.write_zipper();
      for v770_7_byte in v768_21_cursor.child_mask().iter() {
        v768_21_cursor.descend_to_existing_byte(v770_7_byte);
        {
        let v771_2: Space = singleton(&v768_21_cursor.path()[(v768_21_origin + 1)..(v768_21_origin + 2)]);
        let v771_3: Space = intersect(&(*CONSTANT_2),&(v771_2));
        let v771_4: Space = if has_head(&(v771_3)) { singleton(&[]) } else { Space::new() };
        drop(v771_3);
        let v771_5: Space = subtract(&(*CONSTANT_1),&(v771_4));
        drop(v771_4);
        let v771_8: Space = if (&(v771_5)).is_empty() { Space::new() } else {
          let v772_6: Path = concat_path(&(v770_6),&v768_21_cursor.path()[(v768_21_origin + 1)..(v768_21_origin + 2)]);
          let mut v772_7 = Space::new();
          let mut v772_7_write = v772_7.write_zipper();
          for v772_7_byte in v768_21_cursor.child_mask().iter() {
            v768_21_cursor.descend_to_existing_byte(v772_7_byte);
            {
            let v773_2: Space = singleton(&v768_21_cursor.path()[(v768_21_origin + 2)..(v768_21_origin + 3)]);
            let v773_3: Space = intersect(&(*CONSTANT_2),&(v773_2));
            let v773_4: Space = if has_head(&(v773_3)) { singleton(&[]) } else { Space::new() };
            drop(v773_3);
            let v773_5: Space = subtract(&(*CONSTANT_1),&(v773_4));
            drop(v773_4);
            let v773_8: Space = if (&(v773_5)).is_empty() { Space::new() } else {
              let v774_6: Path = concat_path(&(v772_6),&v768_21_cursor.path()[(v768_21_origin + 2)..(v768_21_origin + 3)]);
              let v774_7: Space = routine_50(c, &(v774_6), &(*p1), &v768_21_cursor);
              compose(&(v773_5),&(v774_7))
            };
            drop(v773_5);
            let v773_9: Space = intersect(&(*CONSTANT_2),&(v773_2));
            drop(v773_2);
            let v773_10: Space = if has_head(&(v773_9)) { singleton(&[]) } else { Space::new() };
            drop(v773_9);
            let v773_12: Space = if (&(v773_10)).is_empty() { Space::new() } else {
              let v775_6: Path = concat_path(&(v772_6),&v768_21_cursor.path()[(v768_21_origin + 2)..(v768_21_origin + 3)]);
              let v775_11: Space = routine_51(c, &(v775_6), &(*p1), &v768_21_cursor);
              drop(v775_6);
              compose(&(v773_10),&(v775_11))
            };
            drop(v773_10);
            let v773_13: Space = unite(&(v773_8),&(v773_12));
            join_wrapped_into(&mut v772_7_write,&((v773_13).read_zipper()),&[]);
            }
            v768_21_cursor.ascend(1);
          }
          drop(v772_7_write);
          compose(&(v771_5),&(v772_7))
        };
        drop(v771_5);
        let v771_9: Space = intersect(&(*CONSTANT_2),&(v771_2));
        drop(v771_2);
        let v771_10: Space = if has_head(&(v771_9)) { singleton(&[]) } else { Space::new() };
        drop(v771_9);
        let v771_12: Space = if (&(v771_10)).is_empty() { Space::new() } else {
          let v776_6: Path = concat_path(&(v770_6),&v768_21_cursor.path()[(v768_21_origin + 1)..(v768_21_origin + 2)]);
          let mut v776_11 = Space::new();
          let mut v776_11_write = v776_11.write_zipper();
          for v776_11_byte in v768_21_cursor.child_mask().iter() {
            v768_21_cursor.descend_to_existing_byte(v776_11_byte);
            {
            let v777_2: Space = singleton(&v768_21_cursor.path()[(v768_21_origin + 2)..(v768_21_origin + 3)]);
            let v777_3: Space = intersect(&(*CONSTANT_2),&(v777_2));
            let v777_4: Space = if has_head(&(v777_3)) { singleton(&[]) } else { Space::new() };
            drop(v777_3);
            let v777_5: Space = subtract(&(*CONSTANT_1),&(v777_4));
            drop(v777_4);
            let v777_8: Space = if (&(v777_5)).is_empty() { Space::new() } else {
              let v778_6: Path = concat_path(&(v776_6),&v768_21_cursor.path()[(v768_21_origin + 2)..(v768_21_origin + 3)]);
              let v778_7: Space = routine_50(c, &(v778_6), &(*p1), &v768_21_cursor);
              compose(&(v777_5),&(v778_7))
            };
            drop(v777_5);
            let v777_9: Space = intersect(&(*CONSTANT_2),&(v777_2));
            drop(v777_2);
            let v777_10: Space = if has_head(&(v777_9)) { singleton(&[]) } else { Space::new() };
            drop(v777_9);
            let v777_12: Space = if (&(v777_10)).is_empty() { Space::new() } else {
              let v779_6: Path = concat_path(&(v776_6),&v768_21_cursor.path()[(v768_21_origin + 2)..(v768_21_origin + 3)]);
              let v779_11: Space = routine_19(c, &(v779_6), &(*p1), &v768_21_cursor);
              drop(v779_6);
              compose(&(v777_10),&(v779_11))
            };
            drop(v777_10);
            let v777_13: Space = unite(&(v777_8),&(v777_12));
            join_wrapped_into(&mut v776_11_write,&((v777_13).read_zipper()),&[]);
            }
            v768_21_cursor.ascend(1);
          }
          drop(v776_11_write);
          drop(v776_6);
          compose(&(v771_10),&(v776_11))
        };
        drop(v771_10);
        let v771_13: Space = unite(&(v771_8),&(v771_12));
        join_wrapped_into(&mut v770_7_write,&((v771_13).read_zipper()),&[]);
        }
        v768_21_cursor.ascend(1);
      }
      drop(v770_7_write);
      compose(&(v769_5),&(v770_7))
    };
    drop(v769_5);
    let v769_9: Space = intersect(&(*CONSTANT_2),&(v769_2));
    drop(v769_2);
    let v769_10: Space = if has_head(&(v769_9)) { singleton(&[]) } else { Space::new() };
    drop(v769_9);
    let v769_12: Space = if (&(v769_10)).is_empty() { Space::new() } else {
      let v780_6: Path = concat_path(&(*p0),&v768_21_cursor.path()[v768_21_origin..(v768_21_origin + 1)]);
      let mut v780_11 = Space::new();
      let mut v780_11_write = v780_11.write_zipper();
      for v780_11_byte in v768_21_cursor.child_mask().iter() {
        v768_21_cursor.descend_to_existing_byte(v780_11_byte);
        {
        let v781_2: Space = singleton(&v768_21_cursor.path()[(v768_21_origin + 1)..(v768_21_origin + 2)]);
        let v781_3: Space = intersect(&(*CONSTANT_2),&(v781_2));
        let v781_4: Space = if has_head(&(v781_3)) { singleton(&[]) } else { Space::new() };
        drop(v781_3);
        let v781_5: Space = subtract(&(*CONSTANT_1),&(v781_4));
        drop(v781_4);
        let v781_8: Space = if (&(v781_5)).is_empty() { Space::new() } else {
          let v782_6: Path = concat_path(&(v780_6),&v768_21_cursor.path()[(v768_21_origin + 1)..(v768_21_origin + 2)]);
          let mut v782_7 = Space::new();
          let mut v782_7_write = v782_7.write_zipper();
          for v782_7_byte in v768_21_cursor.child_mask().iter() {
            v768_21_cursor.descend_to_existing_byte(v782_7_byte);
            {
            let v783_2: Space = singleton(&v768_21_cursor.path()[(v768_21_origin + 2)..(v768_21_origin + 3)]);
            let v783_3: Space = intersect(&(*CONSTANT_2),&(v783_2));
            let v783_4: Space = if has_head(&(v783_3)) { singleton(&[]) } else { Space::new() };
            drop(v783_3);
            let v783_5: Space = subtract(&(*CONSTANT_1),&(v783_4));
            drop(v783_4);
            let v783_8: Space = if (&(v783_5)).is_empty() { Space::new() } else {
              let v784_6: Path = concat_path(&(v782_6),&v768_21_cursor.path()[(v768_21_origin + 2)..(v768_21_origin + 3)]);
              let v784_7: Space = routine_50(c, &(v784_6), &(*p1), &v768_21_cursor);
              compose(&(v783_5),&(v784_7))
            };
            drop(v783_5);
            let v783_9: Space = intersect(&(*CONSTANT_2),&(v783_2));
            drop(v783_2);
            let v783_10: Space = if has_head(&(v783_9)) { singleton(&[]) } else { Space::new() };
            drop(v783_9);
            let v783_12: Space = if (&(v783_10)).is_empty() { Space::new() } else {
              let v785_6: Path = concat_path(&(v782_6),&v768_21_cursor.path()[(v768_21_origin + 2)..(v768_21_origin + 3)]);
              let v785_11: Space = routine_51(c, &(v785_6), &(*p1), &v768_21_cursor);
              drop(v785_6);
              compose(&(v783_10),&(v785_11))
            };
            drop(v783_10);
            let v783_13: Space = unite(&(v783_8),&(v783_12));
            join_wrapped_into(&mut v782_7_write,&((v783_13).read_zipper()),&[]);
            }
            v768_21_cursor.ascend(1);
          }
          drop(v782_7_write);
          compose(&(v781_5),&(v782_7))
        };
        drop(v781_5);
        let v781_9: Space = intersect(&(*CONSTANT_2),&(v781_2));
        drop(v781_2);
        let v781_10: Space = if has_head(&(v781_9)) { singleton(&[]) } else { Space::new() };
        drop(v781_9);
        let v781_11: Space = compose(&(v781_10),&v768_21_cursor);
        drop(v781_10);
        let v786_6: Path = concat_path(&(v780_6),&v768_21_cursor.path()[(v768_21_origin + 1)..(v768_21_origin + 2)]);
        let v781_12: Space = wrap(&(v781_11),&(v786_6));
        drop(v781_11);
        let v781_13: Space = wrap(&(v781_12),&(*p1));
        drop(v781_12);
        let v781_14: Space = unite(&(v781_8),&(v781_13));
        drop(v781_13);
        join_wrapped_into(&mut v780_11_write,&((v781_14).read_zipper()),&[]);
        }
        v768_21_cursor.ascend(1);
      }
      drop(v780_11_write);
      drop(v780_6);
      compose(&(v769_10),&(v780_11))
    };
    drop(v769_10);
    let v769_13: Space = unite(&(v769_8),&(v769_12));
    join_wrapped_into(&mut v768_21_write,&((v769_13).read_zipper()),&[]);
    }
    v768_21_cursor.ascend(1);
  }
  drop(v768_21_cursor);
  drop(v768_21_write);
  (v768_21).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v787_15 = Space::new();
  let mut v787_15_write = v787_15.write_zipper();
  let mut v787_15_cursor = (*s0).read_zipper();
  let v787_15_origin = v787_15_cursor.path().len();
  for v787_15_byte in v787_15_cursor.child_mask().iter() {
    v787_15_cursor.descend_to_existing_byte(v787_15_byte);
    {
    let v788_2: Space = singleton(&v787_15_cursor.path()[v787_15_origin..(v787_15_origin + 1)]);
    let v788_3: Space = intersect(&(*CONSTANT_2),&(v788_2));
    let v788_4: Space = if has_head(&(v788_3)) { singleton(&[]) } else { Space::new() };
    drop(v788_3);
    let v788_5: Space = subtract(&(*CONSTANT_1),&(v788_4));
    drop(v788_4);
    let v788_8: Space = if (&(v788_5)).is_empty() { Space::new() } else {
      let v789_6: Path = concat_path(&(*p0),&v787_15_cursor.path()[v787_15_origin..(v787_15_origin + 1)]);
      let mut v789_7 = Space::new();
      let mut v789_7_write = v789_7.write_zipper();
      for v789_7_byte in v787_15_cursor.child_mask().iter() {
        v787_15_cursor.descend_to_existing_byte(v789_7_byte);
        {
        let v790_2: Space = singleton(&v787_15_cursor.path()[(v787_15_origin + 1)..(v787_15_origin + 2)]);
        let v790_3: Space = intersect(&(*CONSTANT_2),&(v790_2));
        let v790_4: Space = if has_head(&(v790_3)) { singleton(&[]) } else { Space::new() };
        drop(v790_3);
        let v790_5: Space = subtract(&(*CONSTANT_1),&(v790_4));
        drop(v790_4);
        let v790_8: Space = if (&(v790_5)).is_empty() { Space::new() } else {
          let v791_6: Path = concat_path(&(v789_6),&v787_15_cursor.path()[(v787_15_origin + 1)..(v787_15_origin + 2)]);
          let mut v791_7 = Space::new();
          let mut v791_7_write = v791_7.write_zipper();
          for v791_7_byte in v787_15_cursor.child_mask().iter() {
            v787_15_cursor.descend_to_existing_byte(v791_7_byte);
            {
            let v792_2: Space = singleton(&v787_15_cursor.path()[(v787_15_origin + 2)..(v787_15_origin + 3)]);
            let v792_3: Space = intersect(&(*CONSTANT_2),&(v792_2));
            let v792_4: Space = if has_head(&(v792_3)) { singleton(&[]) } else { Space::new() };
            drop(v792_3);
            let v792_5: Space = subtract(&(*CONSTANT_1),&(v792_4));
            drop(v792_4);
            let v792_8: Space = if (&(v792_5)).is_empty() { Space::new() } else {
              let v793_6: Path = concat_path(&(v791_6),&v787_15_cursor.path()[(v787_15_origin + 2)..(v787_15_origin + 3)]);
              let v793_7: Space = routine_50(c, &(v793_6), &(*p1), &v787_15_cursor);
              compose(&(v792_5),&(v793_7))
            };
            drop(v792_5);
            let v792_9: Space = intersect(&(*CONSTANT_2),&(v792_2));
            drop(v792_2);
            let v792_10: Space = if has_head(&(v792_9)) { singleton(&[]) } else { Space::new() };
            drop(v792_9);
            let v792_12: Space = if (&(v792_10)).is_empty() { Space::new() } else {
              let v794_6: Path = concat_path(&(v791_6),&v787_15_cursor.path()[(v787_15_origin + 2)..(v787_15_origin + 3)]);
              let v794_11: Space = routine_51(c, &(v794_6), &(*p1), &v787_15_cursor);
              drop(v794_6);
              compose(&(v792_10),&(v794_11))
            };
            drop(v792_10);
            let v792_13: Space = unite(&(v792_8),&(v792_12));
            join_wrapped_into(&mut v791_7_write,&((v792_13).read_zipper()),&[]);
            }
            v787_15_cursor.ascend(1);
          }
          drop(v791_7_write);
          compose(&(v790_5),&(v791_7))
        };
        drop(v790_5);
        let v790_9: Space = intersect(&(*CONSTANT_2),&(v790_2));
        drop(v790_2);
        let v790_10: Space = if has_head(&(v790_9)) { singleton(&[]) } else { Space::new() };
        drop(v790_9);
        let v790_12: Space = if (&(v790_10)).is_empty() { Space::new() } else {
          let v795_6: Path = concat_path(&(v789_6),&v787_15_cursor.path()[(v787_15_origin + 1)..(v787_15_origin + 2)]);
          let mut v795_11 = Space::new();
          let mut v795_11_write = v795_11.write_zipper();
          for v795_11_byte in v787_15_cursor.child_mask().iter() {
            v787_15_cursor.descend_to_existing_byte(v795_11_byte);
            {
            let v796_2: Space = singleton(&v787_15_cursor.path()[(v787_15_origin + 2)..(v787_15_origin + 3)]);
            let v796_3: Space = intersect(&(*CONSTANT_2),&(v796_2));
            let v796_4: Space = if has_head(&(v796_3)) { singleton(&[]) } else { Space::new() };
            drop(v796_3);
            let v796_5: Space = subtract(&(*CONSTANT_1),&(v796_4));
            drop(v796_4);
            let v796_8: Space = if (&(v796_5)).is_empty() { Space::new() } else {
              let v797_6: Path = concat_path(&(v795_6),&v787_15_cursor.path()[(v787_15_origin + 2)..(v787_15_origin + 3)]);
              let v797_7: Space = routine_50(c, &(v797_6), &(*p1), &v787_15_cursor);
              compose(&(v796_5),&(v797_7))
            };
            drop(v796_5);
            let v796_9: Space = intersect(&(*CONSTANT_2),&(v796_2));
            drop(v796_2);
            let v796_10: Space = if has_head(&(v796_9)) { singleton(&[]) } else { Space::new() };
            drop(v796_9);
            let v796_12: Space = if (&(v796_10)).is_empty() { Space::new() } else {
              let v798_6: Path = concat_path(&(v795_6),&v787_15_cursor.path()[(v787_15_origin + 2)..(v787_15_origin + 3)]);
              let v798_11: Space = routine_19(c, &(v798_6), &(*p1), &v787_15_cursor);
              drop(v798_6);
              compose(&(v796_10),&(v798_11))
            };
            drop(v796_10);
            let v796_13: Space = unite(&(v796_8),&(v796_12));
            join_wrapped_into(&mut v795_11_write,&((v796_13).read_zipper()),&[]);
            }
            v787_15_cursor.ascend(1);
          }
          drop(v795_11_write);
          drop(v795_6);
          compose(&(v790_10),&(v795_11))
        };
        drop(v790_10);
        let v790_13: Space = unite(&(v790_8),&(v790_12));
        join_wrapped_into(&mut v789_7_write,&((v790_13).read_zipper()),&[]);
        }
        v787_15_cursor.ascend(1);
      }
      drop(v789_7_write);
      compose(&(v788_5),&(v789_7))
    };
    drop(v788_5);
    let v788_9: Space = intersect(&(*CONSTANT_2),&(v788_2));
    drop(v788_2);
    let v788_10: Space = if has_head(&(v788_9)) { singleton(&[]) } else { Space::new() };
    drop(v788_9);
    let v788_11: Space = compose(&(v788_10),&v787_15_cursor);
    drop(v788_10);
    let v799_6: Path = concat_path(&(*p0),&v787_15_cursor.path()[v787_15_origin..(v787_15_origin + 1)]);
    let v788_12: Space = wrap(&(v788_11),&(v799_6));
    drop(v788_11);
    let v788_13: Space = wrap(&(v788_12),&(*p1));
    drop(v788_12);
    let v788_14: Space = unite(&(v788_8),&(v788_13));
    drop(v788_13);
    join_wrapped_into(&mut v787_15_write,&((v788_14).read_zipper()),&[]);
    }
    v787_15_cursor.ascend(1);
  }
  drop(v787_15_cursor);
  drop(v787_15_write);
  (v787_15).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v800_14 = Space::new();
  let mut v800_14_write = v800_14.write_zipper();
  let mut v800_14_cursor = (*s0).read_zipper();
  let v800_14_origin = v800_14_cursor.path().len();
  for v800_14_byte in v800_14_cursor.child_mask().iter() {
    v800_14_cursor.descend_to_existing_byte(v800_14_byte);
    {
    let v801_2: Space = singleton(&v800_14_cursor.path()[v800_14_origin..(v800_14_origin + 1)]);
    let v801_3: Space = intersect(&(*CONSTANT_2),&(v801_2));
    let v801_4: Space = if has_head(&(v801_3)) { singleton(&[]) } else { Space::new() };
    drop(v801_3);
    let v801_5: Space = subtract(&(*CONSTANT_1),&(v801_4));
    drop(v801_4);
    let v801_7: Space = if (&(v801_5)).is_empty() { Space::new() } else {
      let mut v802_6 = Space::new();
      let mut v802_6_write = v802_6.write_zipper();
      for v802_6_byte in v800_14_cursor.child_mask().iter() {
        v800_14_cursor.descend_to_existing_byte(v802_6_byte);
        {
        let v803_2: Space = Space::new();
        join_wrapped_into(&mut v802_6_write,&((v803_2).read_zipper()),&[]);
        }
        v800_14_cursor.ascend(1);
      }
      drop(v802_6_write);
      compose(&(v801_5),&(v802_6))
    };
    drop(v801_5);
    let v801_8: Space = intersect(&(*CONSTANT_2),&(v801_2));
    drop(v801_2);
    let v801_9: Space = if has_head(&(v801_8)) { singleton(&[]) } else { Space::new() };
    drop(v801_8);
    let v801_12: Space = if (&(v801_9)).is_empty() { Space::new() } else {
      let mut v804_11 = Space::new();
      let mut v804_11_write = v804_11.write_zipper();
      for v804_11_byte in v800_14_cursor.child_mask().iter() {
        v800_14_cursor.descend_to_existing_byte(v804_11_byte);
        {
        let v805_2: Space = singleton(&v800_14_cursor.path()[(v800_14_origin + 1)..(v800_14_origin + 2)]);
        let v805_3: Space = intersect(&(*CONSTANT_2),&(v805_2));
        drop(v805_2);
        let v805_4: Space = if has_head(&(v805_3)) { singleton(&[]) } else { Space::new() };
        drop(v805_3);
        let v805_7: Space = if (&(v805_4)).is_empty() { Space::new() } else {
          let mut v806_6 = Space::new();
          let mut v806_6_write = v806_6.write_zipper();
          let mut v806_6_cursor = descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v800_14_cursor.path()[v800_14_origin..(v800_14_origin + 1)]),&v800_14_cursor.path()[(v800_14_origin + 1)..(v800_14_origin + 2)]);
          let v806_6_origin = v806_6_cursor.path().len();
          for v806_6_byte in v806_6_cursor.child_mask().iter() {
            v806_6_cursor.descend_to_existing_byte(v806_6_byte);
            {
            let v807_2: Space = singleton(&v806_6_cursor.path()[v806_6_origin..(v806_6_origin + 1)]);
            let v807_3: Space = intersect(&(*CONSTANT_2),&(v807_2));
            let v807_4: Space = if has_head(&(v807_3)) { singleton(&[]) } else { Space::new() };
            drop(v807_3);
            let v807_5: Space = subtract(&(*CONSTANT_1),&(v807_4));
            drop(v807_4);
            let v807_7: Space = if (&(v807_5)).is_empty() { Space::new() } else {
              let v808_6: Space = routine_13(c, &v806_6_cursor.path()[v806_6_origin..(v806_6_origin + 1)], &(*p1), &v806_6_cursor);
              compose(&(v807_5),&(v808_6))
            };
            drop(v807_5);
            let v807_8: Space = intersect(&(*CONSTANT_2),&(v807_2));
            drop(v807_2);
            let v807_9: Space = if has_head(&(v807_8)) { singleton(&[]) } else { Space::new() };
            drop(v807_8);
            let v807_11: Space = if (&(v807_9)).is_empty() { Space::new() } else {
              let v809_10: Space = routine_14(c, &v806_6_cursor.path()[v806_6_origin..(v806_6_origin + 1)], &(*p1), &v806_6_cursor);
              compose(&(v807_9),&(v809_10))
            };
            drop(v807_9);
            let v807_12: Space = unite(&(v807_7),&(v807_11));
            join_wrapped_into(&mut v806_6_write,&((v807_12).read_zipper()),&[]);
            }
            v806_6_cursor.ascend(1);
          }
          drop(v806_6_cursor);
          drop(v806_6_write);
          compose(&(v805_4),&(v806_6))
        };
        drop(v805_4);
        join_wrapped_into(&mut v804_11_write,&((v805_7).read_zipper()),&[]);
        }
        v800_14_cursor.ascend(1);
      }
      drop(v804_11_write);
      compose(&(v801_9),&(v804_11))
    };
    drop(v801_9);
    let v801_13: Space = unite(&(v801_7),&(v801_12));
    drop(v801_7);
    join_wrapped_into(&mut v800_14_write,&((v801_13).read_zipper()),&[]);
    }
    v800_14_cursor.ascend(1);
  }
  drop(v800_14_cursor);
  drop(v800_14_write);
  (v800_14).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v810_19 = Space::new();
  let mut v810_19_write = v810_19.write_zipper();
  let mut v810_19_cursor = (*s0).read_zipper();
  let v810_19_origin = v810_19_cursor.path().len();
  for v810_19_byte in v810_19_cursor.child_mask().iter() {
    v810_19_cursor.descend_to_existing_byte(v810_19_byte);
    {
    let v811_2: Space = singleton(&v810_19_cursor.path()[v810_19_origin..(v810_19_origin + 1)]);
    let v811_3: Space = intersect(&(*CONSTANT_2),&(v811_2));
    let v811_4: Space = if has_head(&(v811_3)) { singleton(&[]) } else { Space::new() };
    drop(v811_3);
    let v811_5: Space = subtract(&(*CONSTANT_1),&(v811_4));
    drop(v811_4);
    let v811_7: Space = if (&(v811_5)).is_empty() { Space::new() } else {
      let mut v812_6 = Space::new();
      let mut v812_6_write = v812_6.write_zipper();
      for v812_6_byte in v810_19_cursor.child_mask().iter() {
        v810_19_cursor.descend_to_existing_byte(v812_6_byte);
        {
        let v813_2: Space = Space::new();
        join_wrapped_into(&mut v812_6_write,&((v813_2).read_zipper()),&[]);
        }
        v810_19_cursor.ascend(1);
      }
      drop(v812_6_write);
      compose(&(v811_5),&(v812_6))
    };
    drop(v811_5);
    let v811_8: Space = intersect(&(*CONSTANT_2),&(v811_2));
    drop(v811_2);
    let v811_9: Space = if has_head(&(v811_8)) { singleton(&[]) } else { Space::new() };
    drop(v811_8);
    let v811_12: Space = if (&(v811_9)).is_empty() { Space::new() } else {
      let mut v814_11 = Space::new();
      let mut v814_11_write = v814_11.write_zipper();
      let mut v814_11_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v810_19_cursor.path()[v810_19_origin..(v810_19_origin + 1)]);
      let v814_11_origin = v814_11_cursor.path().len();
      for v814_11_byte in v814_11_cursor.child_mask().iter() {
        v814_11_cursor.descend_to_existing_byte(v814_11_byte);
        {
        let v815_2: Space = singleton(&v814_11_cursor.path()[v814_11_origin..(v814_11_origin + 1)]);
        let v815_3: Space = intersect(&(*CONSTANT_2),&(v815_2));
        let v815_4: Space = if has_head(&(v815_3)) { singleton(&[]) } else { Space::new() };
        drop(v815_3);
        let v815_5: Space = subtract(&(*CONSTANT_1),&(v815_4));
        drop(v815_4);
        let v815_7: Space = if (&(v815_5)).is_empty() { Space::new() } else {
          let mut v816_6 = Space::new();
          let mut v816_6_write = v816_6.write_zipper();
          for v816_6_byte in v814_11_cursor.child_mask().iter() {
            v814_11_cursor.descend_to_existing_byte(v816_6_byte);
            {
            let v817_2: Space = singleton(&v814_11_cursor.path()[(v814_11_origin + 1)..(v814_11_origin + 2)]);
            let v817_3: Space = intersect(&(*CONSTANT_2),&(v817_2));
            let v817_4: Space = if has_head(&(v817_3)) { singleton(&[]) } else { Space::new() };
            drop(v817_3);
            let v817_5: Space = subtract(&(*CONSTANT_1),&(v817_4));
            drop(v817_4);
            let v817_8: Space = if (&(v817_5)).is_empty() { Space::new() } else {
              let v818_7: Space = routine_17(c, &v814_11_cursor.path()[v814_11_origin..(v814_11_origin + 2)], &(*p1), &v814_11_cursor);
              compose(&(v817_5),&(v818_7))
            };
            drop(v817_5);
            let v817_9: Space = intersect(&(*CONSTANT_2),&(v817_2));
            drop(v817_2);
            let v817_10: Space = if has_head(&(v817_9)) { singleton(&[]) } else { Space::new() };
            drop(v817_9);
            let v817_12: Space = if (&(v817_10)).is_empty() { Space::new() } else {
              let v819_11: Space = routine_18(c, &v814_11_cursor.path()[v814_11_origin..(v814_11_origin + 2)], &(*p1), &v814_11_cursor);
              compose(&(v817_10),&(v819_11))
            };
            drop(v817_10);
            let v817_13: Space = unite(&(v817_8),&(v817_12));
            join_wrapped_into(&mut v816_6_write,&((v817_13).read_zipper()),&[]);
            }
            v814_11_cursor.ascend(1);
          }
          drop(v816_6_write);
          compose(&(v815_5),&(v816_6))
        };
        drop(v815_5);
        let v815_8: Space = intersect(&(*CONSTANT_2),&(v815_2));
        drop(v815_2);
        let v815_9: Space = if has_head(&(v815_8)) { singleton(&[]) } else { Space::new() };
        drop(v815_8);
        let v815_11: Space = if (&(v815_9)).is_empty() { Space::new() } else {
          let mut v820_10 = Space::new();
          let mut v820_10_write = v820_10.write_zipper();
          for v820_10_byte in v814_11_cursor.child_mask().iter() {
            v814_11_cursor.descend_to_existing_byte(v820_10_byte);
            {
            let v821_2: Space = singleton(&v814_11_cursor.path()[(v814_11_origin + 1)..(v814_11_origin + 2)]);
            let v821_3: Space = intersect(&(*CONSTANT_2),&(v821_2));
            let v821_4: Space = if has_head(&(v821_3)) { singleton(&[]) } else { Space::new() };
            drop(v821_3);
            let v821_5: Space = subtract(&(*CONSTANT_1),&(v821_4));
            drop(v821_4);
            let v821_8: Space = if (&(v821_5)).is_empty() { Space::new() } else {
              let v822_7: Space = routine_17(c, &v814_11_cursor.path()[v814_11_origin..(v814_11_origin + 2)], &(*p1), &v814_11_cursor);
              compose(&(v821_5),&(v822_7))
            };
            drop(v821_5);
            let v821_9: Space = intersect(&(*CONSTANT_2),&(v821_2));
            drop(v821_2);
            let v821_10: Space = if has_head(&(v821_9)) { singleton(&[]) } else { Space::new() };
            drop(v821_9);
            let v821_12: Space = if (&(v821_10)).is_empty() { Space::new() } else {
              let v823_11: Space = routine_19(c, &v814_11_cursor.path()[v814_11_origin..(v814_11_origin + 2)], &(*p1), &v814_11_cursor);
              compose(&(v821_10),&(v823_11))
            };
            drop(v821_10);
            let v821_13: Space = unite(&(v821_8),&(v821_12));
            join_wrapped_into(&mut v820_10_write,&((v821_13).read_zipper()),&[]);
            }
            v814_11_cursor.ascend(1);
          }
          drop(v820_10_write);
          compose(&(v815_9),&(v820_10))
        };
        drop(v815_9);
        let v815_12: Space = unite(&(v815_7),&(v815_11));
        join_wrapped_into(&mut v814_11_write,&((v815_12).read_zipper()),&[]);
        }
        v814_11_cursor.ascend(1);
      }
      drop(v814_11_cursor);
      drop(v814_11_write);
      compose(&(v811_9),&(v814_11))
    };
    drop(v811_9);
    let v811_13: Space = unite(&(v811_7),&(v811_12));
    drop(v811_7);
    join_wrapped_into(&mut v810_19_write,&((v811_13).read_zipper()),&[]);
    }
    v810_19_cursor.ascend(1);
  }
  drop(v810_19_cursor);
  drop(v810_19_write);
  (v810_19).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v824_21 = Space::new();
  let mut v824_21_write = v824_21.write_zipper();
  let mut v824_21_cursor = (*s0).read_zipper();
  let v824_21_origin = v824_21_cursor.path().len();
  for v824_21_byte in v824_21_cursor.child_mask().iter() {
    v824_21_cursor.descend_to_existing_byte(v824_21_byte);
    {
    let v825_2: Space = singleton(&v824_21_cursor.path()[v824_21_origin..(v824_21_origin + 1)]);
    let v825_3: Space = intersect(&(*CONSTANT_2),&(v825_2));
    let v825_4: Space = if has_head(&(v825_3)) { singleton(&[]) } else { Space::new() };
    drop(v825_3);
    let v825_5: Space = subtract(&(*CONSTANT_1),&(v825_4));
    drop(v825_4);
    let v825_8: Space = if (&(v825_5)).is_empty() { Space::new() } else {
      let v826_6: Path = concat_path(&(*p0),&v824_21_cursor.path()[v824_21_origin..(v824_21_origin + 1)]);
      let mut v826_7 = Space::new();
      let mut v826_7_write = v826_7.write_zipper();
      for v826_7_byte in v824_21_cursor.child_mask().iter() {
        v824_21_cursor.descend_to_existing_byte(v826_7_byte);
        {
        let v827_2: Space = singleton(&v824_21_cursor.path()[(v824_21_origin + 1)..(v824_21_origin + 2)]);
        let v827_3: Space = intersect(&(*CONSTANT_2),&(v827_2));
        let v827_4: Space = if has_head(&(v827_3)) { singleton(&[]) } else { Space::new() };
        drop(v827_3);
        let v827_5: Space = subtract(&(*CONSTANT_1),&(v827_4));
        drop(v827_4);
        let v827_8: Space = if (&(v827_5)).is_empty() { Space::new() } else {
          let v828_6: Path = concat_path(&(v826_6),&v824_21_cursor.path()[(v824_21_origin + 1)..(v824_21_origin + 2)]);
          let mut v828_7 = Space::new();
          let mut v828_7_write = v828_7.write_zipper();
          for v828_7_byte in v824_21_cursor.child_mask().iter() {
            v824_21_cursor.descend_to_existing_byte(v828_7_byte);
            {
            let v829_2: Space = singleton(&v824_21_cursor.path()[(v824_21_origin + 2)..(v824_21_origin + 3)]);
            let v829_3: Space = intersect(&(*CONSTANT_2),&(v829_2));
            let v829_4: Space = if has_head(&(v829_3)) { singleton(&[]) } else { Space::new() };
            drop(v829_3);
            let v829_5: Space = subtract(&(*CONSTANT_1),&(v829_4));
            drop(v829_4);
            let v829_8: Space = if (&(v829_5)).is_empty() { Space::new() } else {
              let v830_6: Path = concat_path(&(v828_6),&v824_21_cursor.path()[(v824_21_origin + 2)..(v824_21_origin + 3)]);
              let v830_7: Space = routine_52(c, &(v830_6), &(*p1), &v824_21_cursor);
              compose(&(v829_5),&(v830_7))
            };
            drop(v829_5);
            let v829_9: Space = intersect(&(*CONSTANT_2),&(v829_2));
            drop(v829_2);
            let v829_10: Space = if has_head(&(v829_9)) { singleton(&[]) } else { Space::new() };
            drop(v829_9);
            let v829_12: Space = if (&(v829_10)).is_empty() { Space::new() } else {
              let v831_6: Path = concat_path(&(v828_6),&v824_21_cursor.path()[(v824_21_origin + 2)..(v824_21_origin + 3)]);
              let v831_11: Space = routine_53(c, &(v831_6), &(*p1), &v824_21_cursor);
              drop(v831_6);
              compose(&(v829_10),&(v831_11))
            };
            drop(v829_10);
            let v829_13: Space = unite(&(v829_8),&(v829_12));
            join_wrapped_into(&mut v828_7_write,&((v829_13).read_zipper()),&[]);
            }
            v824_21_cursor.ascend(1);
          }
          drop(v828_7_write);
          compose(&(v827_5),&(v828_7))
        };
        drop(v827_5);
        let v827_9: Space = intersect(&(*CONSTANT_2),&(v827_2));
        drop(v827_2);
        let v827_10: Space = if has_head(&(v827_9)) { singleton(&[]) } else { Space::new() };
        drop(v827_9);
        let v827_12: Space = if (&(v827_10)).is_empty() { Space::new() } else {
          let v832_6: Path = concat_path(&(v826_6),&v824_21_cursor.path()[(v824_21_origin + 1)..(v824_21_origin + 2)]);
          let mut v832_11 = Space::new();
          let mut v832_11_write = v832_11.write_zipper();
          for v832_11_byte in v824_21_cursor.child_mask().iter() {
            v824_21_cursor.descend_to_existing_byte(v832_11_byte);
            {
            let v833_2: Space = singleton(&v824_21_cursor.path()[(v824_21_origin + 2)..(v824_21_origin + 3)]);
            let v833_3: Space = intersect(&(*CONSTANT_2),&(v833_2));
            let v833_4: Space = if has_head(&(v833_3)) { singleton(&[]) } else { Space::new() };
            drop(v833_3);
            let v833_5: Space = subtract(&(*CONSTANT_1),&(v833_4));
            drop(v833_4);
            let v833_8: Space = if (&(v833_5)).is_empty() { Space::new() } else {
              let v834_6: Path = concat_path(&(v832_6),&v824_21_cursor.path()[(v824_21_origin + 2)..(v824_21_origin + 3)]);
              let v834_7: Space = routine_52(c, &(v834_6), &(*p1), &v824_21_cursor);
              compose(&(v833_5),&(v834_7))
            };
            drop(v833_5);
            let v833_9: Space = intersect(&(*CONSTANT_2),&(v833_2));
            drop(v833_2);
            let v833_10: Space = if has_head(&(v833_9)) { singleton(&[]) } else { Space::new() };
            drop(v833_9);
            let v833_12: Space = if (&(v833_10)).is_empty() { Space::new() } else {
              let v835_6: Path = concat_path(&(v832_6),&v824_21_cursor.path()[(v824_21_origin + 2)..(v824_21_origin + 3)]);
              let v835_11: Space = routine_19(c, &(v835_6), &(*p1), &v824_21_cursor);
              drop(v835_6);
              compose(&(v833_10),&(v835_11))
            };
            drop(v833_10);
            let v833_13: Space = unite(&(v833_8),&(v833_12));
            join_wrapped_into(&mut v832_11_write,&((v833_13).read_zipper()),&[]);
            }
            v824_21_cursor.ascend(1);
          }
          drop(v832_11_write);
          drop(v832_6);
          compose(&(v827_10),&(v832_11))
        };
        drop(v827_10);
        let v827_13: Space = unite(&(v827_8),&(v827_12));
        join_wrapped_into(&mut v826_7_write,&((v827_13).read_zipper()),&[]);
        }
        v824_21_cursor.ascend(1);
      }
      drop(v826_7_write);
      compose(&(v825_5),&(v826_7))
    };
    drop(v825_5);
    let v825_9: Space = intersect(&(*CONSTANT_2),&(v825_2));
    drop(v825_2);
    let v825_10: Space = if has_head(&(v825_9)) { singleton(&[]) } else { Space::new() };
    drop(v825_9);
    let v825_12: Space = if (&(v825_10)).is_empty() { Space::new() } else {
      let v836_6: Path = concat_path(&(*p0),&v824_21_cursor.path()[v824_21_origin..(v824_21_origin + 1)]);
      let mut v836_11 = Space::new();
      let mut v836_11_write = v836_11.write_zipper();
      for v836_11_byte in v824_21_cursor.child_mask().iter() {
        v824_21_cursor.descend_to_existing_byte(v836_11_byte);
        {
        let v837_2: Space = singleton(&v824_21_cursor.path()[(v824_21_origin + 1)..(v824_21_origin + 2)]);
        let v837_3: Space = intersect(&(*CONSTANT_2),&(v837_2));
        let v837_4: Space = if has_head(&(v837_3)) { singleton(&[]) } else { Space::new() };
        drop(v837_3);
        let v837_5: Space = subtract(&(*CONSTANT_1),&(v837_4));
        drop(v837_4);
        let v837_8: Space = if (&(v837_5)).is_empty() { Space::new() } else {
          let v838_6: Path = concat_path(&(v836_6),&v824_21_cursor.path()[(v824_21_origin + 1)..(v824_21_origin + 2)]);
          let mut v838_7 = Space::new();
          let mut v838_7_write = v838_7.write_zipper();
          for v838_7_byte in v824_21_cursor.child_mask().iter() {
            v824_21_cursor.descend_to_existing_byte(v838_7_byte);
            {
            let v839_2: Space = singleton(&v824_21_cursor.path()[(v824_21_origin + 2)..(v824_21_origin + 3)]);
            let v839_3: Space = intersect(&(*CONSTANT_2),&(v839_2));
            let v839_4: Space = if has_head(&(v839_3)) { singleton(&[]) } else { Space::new() };
            drop(v839_3);
            let v839_5: Space = subtract(&(*CONSTANT_1),&(v839_4));
            drop(v839_4);
            let v839_8: Space = if (&(v839_5)).is_empty() { Space::new() } else {
              let v840_6: Path = concat_path(&(v838_6),&v824_21_cursor.path()[(v824_21_origin + 2)..(v824_21_origin + 3)]);
              let v840_7: Space = routine_52(c, &(v840_6), &(*p1), &v824_21_cursor);
              compose(&(v839_5),&(v840_7))
            };
            drop(v839_5);
            let v839_9: Space = intersect(&(*CONSTANT_2),&(v839_2));
            drop(v839_2);
            let v839_10: Space = if has_head(&(v839_9)) { singleton(&[]) } else { Space::new() };
            drop(v839_9);
            let v839_12: Space = if (&(v839_10)).is_empty() { Space::new() } else {
              let v841_6: Path = concat_path(&(v838_6),&v824_21_cursor.path()[(v824_21_origin + 2)..(v824_21_origin + 3)]);
              let v841_11: Space = routine_53(c, &(v841_6), &(*p1), &v824_21_cursor);
              drop(v841_6);
              compose(&(v839_10),&(v841_11))
            };
            drop(v839_10);
            let v839_13: Space = unite(&(v839_8),&(v839_12));
            join_wrapped_into(&mut v838_7_write,&((v839_13).read_zipper()),&[]);
            }
            v824_21_cursor.ascend(1);
          }
          drop(v838_7_write);
          compose(&(v837_5),&(v838_7))
        };
        drop(v837_5);
        let v837_9: Space = intersect(&(*CONSTANT_2),&(v837_2));
        drop(v837_2);
        let v837_10: Space = if has_head(&(v837_9)) { singleton(&[]) } else { Space::new() };
        drop(v837_9);
        let v837_11: Space = compose(&(v837_10),&v824_21_cursor);
        drop(v837_10);
        let v842_6: Path = concat_path(&(v836_6),&v824_21_cursor.path()[(v824_21_origin + 1)..(v824_21_origin + 2)]);
        let v837_12: Space = wrap(&(v837_11),&(v842_6));
        drop(v837_11);
        let v837_13: Space = wrap(&(v837_12),&(*p1));
        drop(v837_12);
        let v837_14: Space = unite(&(v837_8),&(v837_13));
        drop(v837_13);
        join_wrapped_into(&mut v836_11_write,&((v837_14).read_zipper()),&[]);
        }
        v824_21_cursor.ascend(1);
      }
      drop(v836_11_write);
      drop(v836_6);
      compose(&(v825_10),&(v836_11))
    };
    drop(v825_10);
    let v825_13: Space = unite(&(v825_8),&(v825_12));
    join_wrapped_into(&mut v824_21_write,&((v825_13).read_zipper()),&[]);
    }
    v824_21_cursor.ascend(1);
  }
  drop(v824_21_cursor);
  drop(v824_21_write);
  (v824_21).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v843_15 = Space::new();
  let mut v843_15_write = v843_15.write_zipper();
  let mut v843_15_cursor = (*s0).read_zipper();
  let v843_15_origin = v843_15_cursor.path().len();
  for v843_15_byte in v843_15_cursor.child_mask().iter() {
    v843_15_cursor.descend_to_existing_byte(v843_15_byte);
    {
    let v844_2: Space = singleton(&v843_15_cursor.path()[v843_15_origin..(v843_15_origin + 1)]);
    let v844_3: Space = intersect(&(*CONSTANT_2),&(v844_2));
    let v844_4: Space = if has_head(&(v844_3)) { singleton(&[]) } else { Space::new() };
    drop(v844_3);
    let v844_5: Space = subtract(&(*CONSTANT_1),&(v844_4));
    drop(v844_4);
    let v844_8: Space = if (&(v844_5)).is_empty() { Space::new() } else {
      let v845_6: Path = concat_path(&(*p0),&v843_15_cursor.path()[v843_15_origin..(v843_15_origin + 1)]);
      let mut v845_7 = Space::new();
      let mut v845_7_write = v845_7.write_zipper();
      for v845_7_byte in v843_15_cursor.child_mask().iter() {
        v843_15_cursor.descend_to_existing_byte(v845_7_byte);
        {
        let v846_2: Space = singleton(&v843_15_cursor.path()[(v843_15_origin + 1)..(v843_15_origin + 2)]);
        let v846_3: Space = intersect(&(*CONSTANT_2),&(v846_2));
        let v846_4: Space = if has_head(&(v846_3)) { singleton(&[]) } else { Space::new() };
        drop(v846_3);
        let v846_5: Space = subtract(&(*CONSTANT_1),&(v846_4));
        drop(v846_4);
        let v846_8: Space = if (&(v846_5)).is_empty() { Space::new() } else {
          let v847_6: Path = concat_path(&(v845_6),&v843_15_cursor.path()[(v843_15_origin + 1)..(v843_15_origin + 2)]);
          let mut v847_7 = Space::new();
          let mut v847_7_write = v847_7.write_zipper();
          for v847_7_byte in v843_15_cursor.child_mask().iter() {
            v843_15_cursor.descend_to_existing_byte(v847_7_byte);
            {
            let v848_2: Space = singleton(&v843_15_cursor.path()[(v843_15_origin + 2)..(v843_15_origin + 3)]);
            let v848_3: Space = intersect(&(*CONSTANT_2),&(v848_2));
            let v848_4: Space = if has_head(&(v848_3)) { singleton(&[]) } else { Space::new() };
            drop(v848_3);
            let v848_5: Space = subtract(&(*CONSTANT_1),&(v848_4));
            drop(v848_4);
            let v848_8: Space = if (&(v848_5)).is_empty() { Space::new() } else {
              let v849_6: Path = concat_path(&(v847_6),&v843_15_cursor.path()[(v843_15_origin + 2)..(v843_15_origin + 3)]);
              let v849_7: Space = routine_52(c, &(v849_6), &(*p1), &v843_15_cursor);
              compose(&(v848_5),&(v849_7))
            };
            drop(v848_5);
            let v848_9: Space = intersect(&(*CONSTANT_2),&(v848_2));
            drop(v848_2);
            let v848_10: Space = if has_head(&(v848_9)) { singleton(&[]) } else { Space::new() };
            drop(v848_9);
            let v848_12: Space = if (&(v848_10)).is_empty() { Space::new() } else {
              let v850_6: Path = concat_path(&(v847_6),&v843_15_cursor.path()[(v843_15_origin + 2)..(v843_15_origin + 3)]);
              let v850_11: Space = routine_53(c, &(v850_6), &(*p1), &v843_15_cursor);
              drop(v850_6);
              compose(&(v848_10),&(v850_11))
            };
            drop(v848_10);
            let v848_13: Space = unite(&(v848_8),&(v848_12));
            join_wrapped_into(&mut v847_7_write,&((v848_13).read_zipper()),&[]);
            }
            v843_15_cursor.ascend(1);
          }
          drop(v847_7_write);
          compose(&(v846_5),&(v847_7))
        };
        drop(v846_5);
        let v846_9: Space = intersect(&(*CONSTANT_2),&(v846_2));
        drop(v846_2);
        let v846_10: Space = if has_head(&(v846_9)) { singleton(&[]) } else { Space::new() };
        drop(v846_9);
        let v846_12: Space = if (&(v846_10)).is_empty() { Space::new() } else {
          let v851_6: Path = concat_path(&(v845_6),&v843_15_cursor.path()[(v843_15_origin + 1)..(v843_15_origin + 2)]);
          let mut v851_11 = Space::new();
          let mut v851_11_write = v851_11.write_zipper();
          for v851_11_byte in v843_15_cursor.child_mask().iter() {
            v843_15_cursor.descend_to_existing_byte(v851_11_byte);
            {
            let v852_2: Space = singleton(&v843_15_cursor.path()[(v843_15_origin + 2)..(v843_15_origin + 3)]);
            let v852_3: Space = intersect(&(*CONSTANT_2),&(v852_2));
            let v852_4: Space = if has_head(&(v852_3)) { singleton(&[]) } else { Space::new() };
            drop(v852_3);
            let v852_5: Space = subtract(&(*CONSTANT_1),&(v852_4));
            drop(v852_4);
            let v852_8: Space = if (&(v852_5)).is_empty() { Space::new() } else {
              let v853_6: Path = concat_path(&(v851_6),&v843_15_cursor.path()[(v843_15_origin + 2)..(v843_15_origin + 3)]);
              let v853_7: Space = routine_52(c, &(v853_6), &(*p1), &v843_15_cursor);
              compose(&(v852_5),&(v853_7))
            };
            drop(v852_5);
            let v852_9: Space = intersect(&(*CONSTANT_2),&(v852_2));
            drop(v852_2);
            let v852_10: Space = if has_head(&(v852_9)) { singleton(&[]) } else { Space::new() };
            drop(v852_9);
            let v852_12: Space = if (&(v852_10)).is_empty() { Space::new() } else {
              let v854_6: Path = concat_path(&(v851_6),&v843_15_cursor.path()[(v843_15_origin + 2)..(v843_15_origin + 3)]);
              let v854_11: Space = routine_19(c, &(v854_6), &(*p1), &v843_15_cursor);
              drop(v854_6);
              compose(&(v852_10),&(v854_11))
            };
            drop(v852_10);
            let v852_13: Space = unite(&(v852_8),&(v852_12));
            join_wrapped_into(&mut v851_11_write,&((v852_13).read_zipper()),&[]);
            }
            v843_15_cursor.ascend(1);
          }
          drop(v851_11_write);
          drop(v851_6);
          compose(&(v846_10),&(v851_11))
        };
        drop(v846_10);
        let v846_13: Space = unite(&(v846_8),&(v846_12));
        join_wrapped_into(&mut v845_7_write,&((v846_13).read_zipper()),&[]);
        }
        v843_15_cursor.ascend(1);
      }
      drop(v845_7_write);
      compose(&(v844_5),&(v845_7))
    };
    drop(v844_5);
    let v844_9: Space = intersect(&(*CONSTANT_2),&(v844_2));
    drop(v844_2);
    let v844_10: Space = if has_head(&(v844_9)) { singleton(&[]) } else { Space::new() };
    drop(v844_9);
    let v844_11: Space = compose(&(v844_10),&v843_15_cursor);
    drop(v844_10);
    let v855_6: Path = concat_path(&(*p0),&v843_15_cursor.path()[v843_15_origin..(v843_15_origin + 1)]);
    let v844_12: Space = wrap(&(v844_11),&(v855_6));
    drop(v844_11);
    let v844_13: Space = wrap(&(v844_12),&(*p1));
    drop(v844_12);
    let v844_14: Space = unite(&(v844_8),&(v844_13));
    drop(v844_13);
    join_wrapped_into(&mut v843_15_write,&((v844_14).read_zipper()),&[]);
    }
    v843_15_cursor.ascend(1);
  }
  drop(v843_15_cursor);
  drop(v843_15_write);
  (v843_15).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v856_4 = Space::new();
  let mut v856_4_write = v856_4.write_zipper();
  let mut v856_4_cursor = (*s0).read_zipper();
  let v856_4_origin = v856_4_cursor.path().len();
  for v856_4_byte in v856_4_cursor.child_mask().iter() {
    v856_4_cursor.descend_to_existing_byte(v856_4_byte);
    {
    let v857_2: Space = Space::new();
    join_wrapped_into(&mut v856_4_write,&((v857_2).read_zipper()),&[]);
    }
    v856_4_cursor.ascend(1);
  }
  drop(v856_4_cursor);
  drop(v856_4_write);
  (v856_4).clone()
}

fn routine_47(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v858_17 = Space::new();
  let mut v858_17_write = v858_17.write_zipper();
  let mut v858_17_cursor = (*s0).read_zipper();
  let v858_17_origin = v858_17_cursor.path().len();
  for v858_17_byte in v858_17_cursor.child_mask().iter() {
    v858_17_cursor.descend_to_existing_byte(v858_17_byte);
    {
    let v859_2: Space = singleton(&v858_17_cursor.path()[v858_17_origin..(v858_17_origin + 1)]);
    let v859_3: Space = intersect(&(*CONSTANT_2),&(v859_2));
    drop(v859_2);
    let v859_4: Space = if has_head(&(v859_3)) { singleton(&[]) } else { Space::new() };
    drop(v859_3);
    let v859_7: Space = if (&(v859_4)).is_empty() { Space::new() } else {
      let mut v860_6 = Space::new();
      let mut v860_6_write = v860_6.write_zipper();
      let mut v860_6_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0)),&v858_17_cursor.path()[v858_17_origin..(v858_17_origin + 1)]);
      let v860_6_origin = v860_6_cursor.path().len();
      for v860_6_byte in v860_6_cursor.child_mask().iter() {
        v860_6_cursor.descend_to_existing_byte(v860_6_byte);
        {
        let v861_2: Space = singleton(&v860_6_cursor.path()[v860_6_origin..(v860_6_origin + 1)]);
        let v861_3: Space = intersect(&(*CONSTANT_2),&(v861_2));
        let v861_4: Space = if has_head(&(v861_3)) { singleton(&[]) } else { Space::new() };
        drop(v861_3);
        let v861_5: Space = subtract(&(*CONSTANT_1),&(v861_4));
        drop(v861_4);
        let v861_7: Space = if (&(v861_5)).is_empty() { Space::new() } else {
          let mut v862_6 = Space::new();
          let mut v862_6_write = v862_6.write_zipper();
          for v862_6_byte in v860_6_cursor.child_mask().iter() {
            v860_6_cursor.descend_to_existing_byte(v862_6_byte);
            {
            let v863_2: Space = singleton(&v860_6_cursor.path()[(v860_6_origin + 1)..(v860_6_origin + 2)]);
            let v863_3: Space = intersect(&(*CONSTANT_2),&(v863_2));
            let v863_4: Space = if has_head(&(v863_3)) { singleton(&[]) } else { Space::new() };
            drop(v863_3);
            let v863_5: Space = subtract(&(*CONSTANT_1),&(v863_4));
            drop(v863_4);
            let v863_8: Space = if (&(v863_5)).is_empty() { Space::new() } else {
              let v864_7: Space = routine_17(c, &v860_6_cursor.path()[v860_6_origin..(v860_6_origin + 2)], &(*p1), &v860_6_cursor);
              compose(&(v863_5),&(v864_7))
            };
            drop(v863_5);
            let v863_9: Space = intersect(&(*CONSTANT_2),&(v863_2));
            drop(v863_2);
            let v863_10: Space = if has_head(&(v863_9)) { singleton(&[]) } else { Space::new() };
            drop(v863_9);
            let v863_12: Space = if (&(v863_10)).is_empty() { Space::new() } else {
              let v865_11: Space = routine_18(c, &v860_6_cursor.path()[v860_6_origin..(v860_6_origin + 2)], &(*p1), &v860_6_cursor);
              compose(&(v863_10),&(v865_11))
            };
            drop(v863_10);
            let v863_13: Space = unite(&(v863_8),&(v863_12));
            join_wrapped_into(&mut v862_6_write,&((v863_13).read_zipper()),&[]);
            }
            v860_6_cursor.ascend(1);
          }
          drop(v862_6_write);
          compose(&(v861_5),&(v862_6))
        };
        drop(v861_5);
        let v861_8: Space = intersect(&(*CONSTANT_2),&(v861_2));
        drop(v861_2);
        let v861_9: Space = if has_head(&(v861_8)) { singleton(&[]) } else { Space::new() };
        drop(v861_8);
        let v861_11: Space = if (&(v861_9)).is_empty() { Space::new() } else {
          let mut v866_10 = Space::new();
          let mut v866_10_write = v866_10.write_zipper();
          for v866_10_byte in v860_6_cursor.child_mask().iter() {
            v860_6_cursor.descend_to_existing_byte(v866_10_byte);
            {
            let v867_2: Space = singleton(&v860_6_cursor.path()[(v860_6_origin + 1)..(v860_6_origin + 2)]);
            let v867_3: Space = intersect(&(*CONSTANT_2),&(v867_2));
            let v867_4: Space = if has_head(&(v867_3)) { singleton(&[]) } else { Space::new() };
            drop(v867_3);
            let v867_5: Space = subtract(&(*CONSTANT_1),&(v867_4));
            drop(v867_4);
            let v867_8: Space = if (&(v867_5)).is_empty() { Space::new() } else {
              let v868_7: Space = routine_17(c, &v860_6_cursor.path()[v860_6_origin..(v860_6_origin + 2)], &(*p1), &v860_6_cursor);
              compose(&(v867_5),&(v868_7))
            };
            drop(v867_5);
            let v867_9: Space = intersect(&(*CONSTANT_2),&(v867_2));
            drop(v867_2);
            let v867_10: Space = if has_head(&(v867_9)) { singleton(&[]) } else { Space::new() };
            drop(v867_9);
            let v867_12: Space = if (&(v867_10)).is_empty() { Space::new() } else {
              let v869_11: Space = routine_19(c, &v860_6_cursor.path()[v860_6_origin..(v860_6_origin + 2)], &(*p1), &v860_6_cursor);
              compose(&(v867_10),&(v869_11))
            };
            drop(v867_10);
            let v867_13: Space = unite(&(v867_8),&(v867_12));
            join_wrapped_into(&mut v866_10_write,&((v867_13).read_zipper()),&[]);
            }
            v860_6_cursor.ascend(1);
          }
          drop(v866_10_write);
          compose(&(v861_9),&(v866_10))
        };
        drop(v861_9);
        let v861_12: Space = unite(&(v861_7),&(v861_11));
        join_wrapped_into(&mut v860_6_write,&((v861_12).read_zipper()),&[]);
        }
        v860_6_cursor.ascend(1);
      }
      drop(v860_6_cursor);
      drop(v860_6_write);
      compose(&(v859_4),&(v860_6))
    };
    drop(v859_4);
    join_wrapped_into(&mut v858_17_write,&((v859_7).read_zipper()),&[]);
    }
    v858_17_cursor.ascend(1);
  }
  drop(v858_17_cursor);
  drop(v858_17_write);
  (v858_17).clone()
}

fn routine_48(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v870_13 = Space::new();
  let mut v870_13_write = v870_13.write_zipper();
  let mut v870_13_cursor = (*s0).read_zipper();
  let v870_13_origin = v870_13_cursor.path().len();
  for v870_13_byte in v870_13_cursor.child_mask().iter() {
    v870_13_cursor.descend_to_existing_byte(v870_13_byte);
    {
    let v871_2: Space = singleton(&v870_13_cursor.path()[v870_13_origin..(v870_13_origin + 1)]);
    let v871_3: Space = intersect(&(*CONSTANT_2),&(v871_2));
    let v871_4: Space = if has_head(&(v871_3)) { singleton(&[]) } else { Space::new() };
    drop(v871_3);
    let v871_5: Space = subtract(&(*CONSTANT_1),&(v871_4));
    drop(v871_4);
    let v871_8: Space = if (&(v871_5)).is_empty() { Space::new() } else {
      let v872_6: Path = concat_path(&(*p0),&v870_13_cursor.path()[v870_13_origin..(v870_13_origin + 1)]);
      let mut v872_7 = Space::new();
      let mut v872_7_write = v872_7.write_zipper();
      for v872_7_byte in v870_13_cursor.child_mask().iter() {
        v870_13_cursor.descend_to_existing_byte(v872_7_byte);
        {
        let v873_2: Space = singleton(&v870_13_cursor.path()[(v870_13_origin + 1)..(v870_13_origin + 2)]);
        let v873_3: Space = intersect(&(*CONSTANT_2),&(v873_2));
        let v873_4: Space = if has_head(&(v873_3)) { singleton(&[]) } else { Space::new() };
        drop(v873_3);
        let v873_5: Space = subtract(&(*CONSTANT_1),&(v873_4));
        drop(v873_4);
        let v873_7: Space = if (&(v873_5)).is_empty() { Space::new() } else {
          let mut v874_6 = Space::new();
          let mut v874_6_write = v874_6.write_zipper();
          for v874_6_byte in v870_13_cursor.child_mask().iter() {
            v870_13_cursor.descend_to_existing_byte(v874_6_byte);
            {
            let v875_2: Space = Space::new();
            join_wrapped_into(&mut v874_6_write,&((v875_2).read_zipper()),&[]);
            }
            v870_13_cursor.ascend(1);
          }
          drop(v874_6_write);
          compose(&(v873_5),&(v874_6))
        };
        drop(v873_5);
        let v873_8: Space = intersect(&(*CONSTANT_2),&(v873_2));
        drop(v873_2);
        let v873_9: Space = if has_head(&(v873_8)) { singleton(&[]) } else { Space::new() };
        drop(v873_8);
        let v873_12: Space = if (&(v873_9)).is_empty() { Space::new() } else {
          let v876_10: Path = concat_path(&(v872_6),&v870_13_cursor.path()[(v870_13_origin + 1)..(v870_13_origin + 2)]);
          let mut v876_11 = Space::new();
          let mut v876_11_write = v876_11.write_zipper();
          for v876_11_byte in v870_13_cursor.child_mask().iter() {
            v870_13_cursor.descend_to_existing_byte(v876_11_byte);
            {
            let v877_2: Space = singleton(&v870_13_cursor.path()[(v870_13_origin + 2)..(v870_13_origin + 3)]);
            let v877_3: Space = intersect(&(*CONSTANT_2),&(v877_2));
            drop(v877_2);
            let v877_4: Space = if has_head(&(v877_3)) { singleton(&[]) } else { Space::new() };
            drop(v877_3);
            let v877_7: Space = if (&(v877_4)).is_empty() { Space::new() } else {
              let v878_5: Path = concat_path(&(v876_10),&v870_13_cursor.path()[(v870_13_origin + 2)..(v870_13_origin + 3)]);
              let v878_6: Space = routine_19(c, &(v878_5), &(*p1), &v870_13_cursor);
              drop(v878_5);
              compose(&(v877_4),&(v878_6))
            };
            drop(v877_4);
            join_wrapped_into(&mut v876_11_write,&((v877_7).read_zipper()),&[]);
            }
            v870_13_cursor.ascend(1);
          }
          drop(v876_11_write);
          drop(v876_10);
          compose(&(v873_9),&(v876_11))
        };
        drop(v873_9);
        let v873_13: Space = unite(&(v873_7),&(v873_12));
        drop(v873_7);
        join_wrapped_into(&mut v872_7_write,&((v873_13).read_zipper()),&[]);
        }
        v870_13_cursor.ascend(1);
      }
      drop(v872_7_write);
      compose(&(v871_5),&(v872_7))
    };
    drop(v871_5);
    let v871_9: Space = intersect(&(*CONSTANT_2),&(v871_2));
    drop(v871_2);
    let v871_10: Space = if has_head(&(v871_9)) { singleton(&[]) } else { Space::new() };
    drop(v871_9);
    let v871_12: Space = if (&(v871_10)).is_empty() { Space::new() } else {
      let v879_6: Path = concat_path(&(*p0),&v870_13_cursor.path()[v870_13_origin..(v870_13_origin + 1)]);
      let mut v879_11 = Space::new();
      let mut v879_11_write = v879_11.write_zipper();
      for v879_11_byte in v870_13_cursor.child_mask().iter() {
        v870_13_cursor.descend_to_existing_byte(v879_11_byte);
        {
        let v880_2: Space = singleton(&v870_13_cursor.path()[(v870_13_origin + 1)..(v870_13_origin + 2)]);
        let v880_3: Space = intersect(&(*CONSTANT_2),&(v880_2));
        let v880_4: Space = if has_head(&(v880_3)) { singleton(&[]) } else { Space::new() };
        drop(v880_3);
        let v880_5: Space = subtract(&(*CONSTANT_1),&(v880_4));
        drop(v880_4);
        let v880_7: Space = if (&(v880_5)).is_empty() { Space::new() } else {
          let mut v881_6 = Space::new();
          let mut v881_6_write = v881_6.write_zipper();
          for v881_6_byte in v870_13_cursor.child_mask().iter() {
            v870_13_cursor.descend_to_existing_byte(v881_6_byte);
            {
            let v882_2: Space = Space::new();
            join_wrapped_into(&mut v881_6_write,&((v882_2).read_zipper()),&[]);
            }
            v870_13_cursor.ascend(1);
          }
          drop(v881_6_write);
          compose(&(v880_5),&(v881_6))
        };
        drop(v880_5);
        let v880_8: Space = intersect(&(*CONSTANT_2),&(v880_2));
        drop(v880_2);
        let v880_9: Space = if has_head(&(v880_8)) { singleton(&[]) } else { Space::new() };
        drop(v880_8);
        let v880_10: Space = compose(&(v880_9),&v870_13_cursor);
        drop(v880_9);
        let v880_11: Path = concat_path(&(v879_6),&v870_13_cursor.path()[(v870_13_origin + 1)..(v870_13_origin + 2)]);
        let v880_12: Space = wrap(&(v880_10),&(v880_11));
        drop(v880_10);
        drop(v880_11);
        let v880_13: Space = wrap(&(v880_12),&(*p1));
        drop(v880_12);
        let v880_14: Space = unite(&(v880_7),&(v880_13));
        drop(v880_7);
        drop(v880_13);
        join_wrapped_into(&mut v879_11_write,&((v880_14).read_zipper()),&[]);
        }
        v870_13_cursor.ascend(1);
      }
      drop(v879_11_write);
      drop(v879_6);
      compose(&(v871_10),&(v879_11))
    };
    drop(v871_10);
    let v871_13: Space = unite(&(v871_8),&(v871_12));
    drop(v871_12);
    join_wrapped_into(&mut v870_13_write,&((v871_13).read_zipper()),&[]);
    }
    v870_13_cursor.ascend(1);
  }
  drop(v870_13_cursor);
  drop(v870_13_write);
  (v870_13).clone()
}

fn routine_49(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v883_10 = Space::new();
  let mut v883_10_write = v883_10.write_zipper();
  let mut v883_10_cursor = (*s0).read_zipper();
  let v883_10_origin = v883_10_cursor.path().len();
  for v883_10_byte in v883_10_cursor.child_mask().iter() {
    v883_10_cursor.descend_to_existing_byte(v883_10_byte);
    {
    let v884_2: Space = singleton(&v883_10_cursor.path()[v883_10_origin..(v883_10_origin + 1)]);
    let v884_3: Space = intersect(&(*CONSTANT_2),&(v884_2));
    let v884_4: Space = if has_head(&(v884_3)) { singleton(&[]) } else { Space::new() };
    drop(v884_3);
    let v884_5: Space = subtract(&(*CONSTANT_1),&(v884_4));
    drop(v884_4);
    let v884_8: Space = if (&(v884_5)).is_empty() { Space::new() } else {
      let v885_6: Path = concat_path(&(*p0),&v883_10_cursor.path()[v883_10_origin..(v883_10_origin + 1)]);
      let mut v885_7 = Space::new();
      let mut v885_7_write = v885_7.write_zipper();
      for v885_7_byte in v883_10_cursor.child_mask().iter() {
        v883_10_cursor.descend_to_existing_byte(v885_7_byte);
        {
        let v886_2: Space = singleton(&v883_10_cursor.path()[(v883_10_origin + 1)..(v883_10_origin + 2)]);
        let v886_3: Space = intersect(&(*CONSTANT_2),&(v886_2));
        let v886_4: Space = if has_head(&(v886_3)) { singleton(&[]) } else { Space::new() };
        drop(v886_3);
        let v886_5: Space = subtract(&(*CONSTANT_1),&(v886_4));
        drop(v886_4);
        let v886_7: Space = if (&(v886_5)).is_empty() { Space::new() } else {
          let mut v887_6 = Space::new();
          let mut v887_6_write = v887_6.write_zipper();
          for v887_6_byte in v883_10_cursor.child_mask().iter() {
            v883_10_cursor.descend_to_existing_byte(v887_6_byte);
            {
            let v888_2: Space = Space::new();
            join_wrapped_into(&mut v887_6_write,&((v888_2).read_zipper()),&[]);
            }
            v883_10_cursor.ascend(1);
          }
          drop(v887_6_write);
          compose(&(v886_5),&(v887_6))
        };
        drop(v886_5);
        let v886_8: Space = intersect(&(*CONSTANT_2),&(v886_2));
        drop(v886_2);
        let v886_9: Space = if has_head(&(v886_8)) { singleton(&[]) } else { Space::new() };
        drop(v886_8);
        let v886_12: Space = if (&(v886_9)).is_empty() { Space::new() } else {
          let v889_10: Path = concat_path(&(v885_6),&v883_10_cursor.path()[(v883_10_origin + 1)..(v883_10_origin + 2)]);
          let mut v889_11 = Space::new();
          let mut v889_11_write = v889_11.write_zipper();
          for v889_11_byte in v883_10_cursor.child_mask().iter() {
            v883_10_cursor.descend_to_existing_byte(v889_11_byte);
            {
            let v890_2: Space = singleton(&v883_10_cursor.path()[(v883_10_origin + 2)..(v883_10_origin + 3)]);
            let v890_3: Space = intersect(&(*CONSTANT_2),&(v890_2));
            drop(v890_2);
            let v890_4: Space = if has_head(&(v890_3)) { singleton(&[]) } else { Space::new() };
            drop(v890_3);
            let v890_7: Space = if (&(v890_4)).is_empty() { Space::new() } else {
              let v891_5: Path = concat_path(&(v889_10),&v883_10_cursor.path()[(v883_10_origin + 2)..(v883_10_origin + 3)]);
              let v891_6: Space = routine_19(c, &(v891_5), &(*p1), &v883_10_cursor);
              drop(v891_5);
              compose(&(v890_4),&(v891_6))
            };
            drop(v890_4);
            join_wrapped_into(&mut v889_11_write,&((v890_7).read_zipper()),&[]);
            }
            v883_10_cursor.ascend(1);
          }
          drop(v889_11_write);
          drop(v889_10);
          compose(&(v886_9),&(v889_11))
        };
        drop(v886_9);
        let v886_13: Space = unite(&(v886_7),&(v886_12));
        drop(v886_7);
        join_wrapped_into(&mut v885_7_write,&((v886_13).read_zipper()),&[]);
        }
        v883_10_cursor.ascend(1);
      }
      drop(v885_7_write);
      compose(&(v884_5),&(v885_7))
    };
    drop(v884_5);
    let v884_9: Space = intersect(&(*CONSTANT_2),&(v884_2));
    drop(v884_2);
    let v884_10: Space = if has_head(&(v884_9)) { singleton(&[]) } else { Space::new() };
    drop(v884_9);
    let v884_11: Space = compose(&(v884_10),&v883_10_cursor);
    drop(v884_10);
    let v892_6: Path = concat_path(&(*p0),&v883_10_cursor.path()[v883_10_origin..(v883_10_origin + 1)]);
    let v884_12: Space = wrap(&(v884_11),&(v892_6));
    drop(v884_11);
    let v884_13: Space = wrap(&(v884_12),&(*p1));
    drop(v884_12);
    let v884_14: Space = unite(&(v884_8),&(v884_13));
    drop(v884_13);
    join_wrapped_into(&mut v883_10_write,&((v884_14).read_zipper()),&[]);
    }
    v883_10_cursor.ascend(1);
  }
  drop(v883_10_cursor);
  drop(v883_10_write);
  (v883_10).clone()
}

fn routine_50(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v893_7 = Space::new();
  let mut v893_7_write = v893_7.write_zipper();
  let mut v893_7_cursor = (*s0).read_zipper();
  let v893_7_origin = v893_7_cursor.path().len();
  for v893_7_byte in v893_7_cursor.child_mask().iter() {
    v893_7_cursor.descend_to_existing_byte(v893_7_byte);
    {
    let v894_2: Space = singleton(&v893_7_cursor.path()[v893_7_origin..(v893_7_origin + 1)]);
    let v894_3: Space = intersect(&(*CONSTANT_2),&(v894_2));
    let v894_4: Space = if has_head(&(v894_3)) { singleton(&[]) } else { Space::new() };
    drop(v894_3);
    let v894_5: Space = subtract(&(*CONSTANT_1),&(v894_4));
    drop(v894_4);
    let v894_7: Space = if (&(v894_5)).is_empty() { Space::new() } else {
      let mut v895_6 = Space::new();
      let mut v895_6_write = v895_6.write_zipper();
      for v895_6_byte in v893_7_cursor.child_mask().iter() {
        v893_7_cursor.descend_to_existing_byte(v895_6_byte);
        {
        let v896_2: Space = Space::new();
        join_wrapped_into(&mut v895_6_write,&((v896_2).read_zipper()),&[]);
        }
        v893_7_cursor.ascend(1);
      }
      drop(v895_6_write);
      compose(&(v894_5),&(v895_6))
    };
    drop(v894_5);
    let v894_8: Space = intersect(&(*CONSTANT_2),&(v894_2));
    drop(v894_2);
    let v894_9: Space = if has_head(&(v894_8)) { singleton(&[]) } else { Space::new() };
    drop(v894_8);
    let v894_12: Space = if (&(v894_9)).is_empty() { Space::new() } else {
      let v897_10: Path = concat_path(&(*p0),&v893_7_cursor.path()[v893_7_origin..(v893_7_origin + 1)]);
      let mut v897_11 = Space::new();
      let mut v897_11_write = v897_11.write_zipper();
      for v897_11_byte in v893_7_cursor.child_mask().iter() {
        v893_7_cursor.descend_to_existing_byte(v897_11_byte);
        {
        let v898_2: Space = singleton(&v893_7_cursor.path()[(v893_7_origin + 1)..(v893_7_origin + 2)]);
        let v898_3: Space = intersect(&(*CONSTANT_2),&(v898_2));
        drop(v898_2);
        let v898_4: Space = if has_head(&(v898_3)) { singleton(&[]) } else { Space::new() };
        drop(v898_3);
        let v898_5: Space = compose(&(v898_4),&v893_7_cursor);
        drop(v898_4);
        let v898_6: Path = concat_path(&(v897_10),&v893_7_cursor.path()[(v893_7_origin + 1)..(v893_7_origin + 2)]);
        join_wrapped_into(&mut v897_11_write,&((v898_5).read_zipper()),&(v898_6));
        drop(v898_5);
        drop(v898_6);
        }
        v893_7_cursor.ascend(1);
      }
      drop(v897_11_write);
      drop(v897_10);
      compose(&(v894_9),&(v897_11))
    };
    drop(v894_9);
    let v894_13: Space = wrap(&(v894_12),&(*p1));
    drop(v894_12);
    let v894_14: Space = unite(&(v894_7),&(v894_13));
    drop(v894_7);
    drop(v894_13);
    join_wrapped_into(&mut v893_7_write,&((v894_14).read_zipper()),&[]);
    }
    v893_7_cursor.ascend(1);
  }
  drop(v893_7_cursor);
  drop(v893_7_write);
  (v893_7).clone()
}

fn routine_51(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v899_6 = Space::new();
  let mut v899_6_write = v899_6.write_zipper();
  let mut v899_6_cursor = (*s0).read_zipper();
  let v899_6_origin = v899_6_cursor.path().len();
  for v899_6_byte in v899_6_cursor.child_mask().iter() {
    v899_6_cursor.descend_to_existing_byte(v899_6_byte);
    {
    let v900_2: Space = singleton(&v899_6_cursor.path()[v899_6_origin..(v899_6_origin + 1)]);
    let v900_3: Space = intersect(&(*CONSTANT_2),&(v900_2));
    let v900_4: Space = if has_head(&(v900_3)) { singleton(&[]) } else { Space::new() };
    drop(v900_3);
    let v900_5: Space = subtract(&(*CONSTANT_1),&(v900_4));
    drop(v900_4);
    let v900_7: Space = if (&(v900_5)).is_empty() { Space::new() } else {
      let mut v901_6 = Space::new();
      let mut v901_6_write = v901_6.write_zipper();
      for v901_6_byte in v899_6_cursor.child_mask().iter() {
        v899_6_cursor.descend_to_existing_byte(v901_6_byte);
        {
        let v902_2: Space = Space::new();
        join_wrapped_into(&mut v901_6_write,&((v902_2).read_zipper()),&[]);
        }
        v899_6_cursor.ascend(1);
      }
      drop(v901_6_write);
      compose(&(v900_5),&(v901_6))
    };
    drop(v900_5);
    let v900_8: Space = intersect(&(*CONSTANT_2),&(v900_2));
    drop(v900_2);
    let v900_9: Space = if has_head(&(v900_8)) { singleton(&[]) } else { Space::new() };
    drop(v900_8);
    let v900_10: Space = compose(&(v900_9),&v899_6_cursor);
    drop(v900_9);
    let v900_11: Path = concat_path(&(*p0),&v899_6_cursor.path()[v899_6_origin..(v899_6_origin + 1)]);
    let v900_12: Space = wrap(&(v900_10),&(v900_11));
    drop(v900_10);
    drop(v900_11);
    let v900_13: Space = wrap(&(v900_12),&(*p1));
    drop(v900_12);
    let v900_14: Space = unite(&(v900_7),&(v900_13));
    drop(v900_7);
    drop(v900_13);
    join_wrapped_into(&mut v899_6_write,&((v900_14).read_zipper()),&[]);
    }
    v899_6_cursor.ascend(1);
  }
  drop(v899_6_cursor);
  drop(v899_6_write);
  (v899_6).clone()
}

fn routine_52(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v903_3 = Space::new();
  let mut v903_3_write = v903_3.write_zipper();
  let mut v903_3_cursor = (*s0).read_zipper();
  let v903_3_origin = v903_3_cursor.path().len();
  for v903_3_byte in v903_3_cursor.child_mask().iter() {
    v903_3_cursor.descend_to_existing_byte(v903_3_byte);
    {
    let v904_2: Space = Space::new();
    join_wrapped_into(&mut v903_3_write,&((v904_2).read_zipper()),&[]);
    }
    v903_3_cursor.ascend(1);
  }
  drop(v903_3_cursor);
  drop(v903_3_write);
  (v903_3).clone()
}

fn routine_53(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v905_4 = Space::new();
  let mut v905_4_write = v905_4.write_zipper();
  let mut v905_4_cursor = (*s0).read_zipper();
  let v905_4_origin = v905_4_cursor.path().len();
  for v905_4_byte in v905_4_cursor.child_mask().iter() {
    v905_4_cursor.descend_to_existing_byte(v905_4_byte);
    {
    let v906_2: Space = singleton(&v905_4_cursor.path()[v905_4_origin..(v905_4_origin + 1)]);
    let v906_3: Space = intersect(&(*CONSTANT_2),&(v906_2));
    drop(v906_2);
    let v906_4: Space = if has_head(&(v906_3)) { singleton(&[]) } else { Space::new() };
    drop(v906_3);
    let v906_5: Space = compose(&(v906_4),&v905_4_cursor);
    drop(v906_4);
    let v906_6: Path = concat_path(&(*p0),&v905_4_cursor.path()[v905_4_origin..(v905_4_origin + 1)]);
    join_wrapped_into(&mut v905_4_write,&((v906_5).read_zipper()),&(v906_6));
    drop(v906_5);
    drop(v906_6);
    }
    v905_4_cursor.ascend(1);
  }
  drop(v905_4_cursor);
  drop(v905_4_write);
  let v905_5: Space = wrap(&(v905_4),&(*p1));
  drop(v905_4);
  (v905_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
