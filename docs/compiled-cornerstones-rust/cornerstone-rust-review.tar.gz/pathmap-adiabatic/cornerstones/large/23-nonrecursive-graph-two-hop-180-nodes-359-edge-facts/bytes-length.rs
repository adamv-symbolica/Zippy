#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,101,100,103,101]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("255 2 1 0 2 2 1 2 3 2 2 4 3 2 5 4 2 6 5 2 7 6 2 8 7 2 9 8 2 10 9 2 11 10 2 12 11 2 13 12 2 14 13 2 15 14 2 16 15 2 17 16 2 18 17 2 19 18 2 20 19 2 21 20 2 22 21 2 23 22 2 24 23 2 25 24 2 26 25 2 27 26 2 28 27 2 29 28 2 30 29 2 31 30 2 32 31 2 33 32 2 34 33 2 35 34 2 36 35 2 37 36 2 38 37 2 39 38 2 40 39 2 41 40 2 42 41 2 43 42 2 44 43 2 45 44 2 46 45 2 47 46 2 48 47 2 49 48 2 50 49 2 51 50 2 52 51 2 53 52 2 54 53 2 55 54 2 56 55 2 57 56 2 58 57 2 59 58 2 60 59 2 61 60 2 62 61 2 63 62 2 64 63 2 65 64 2 66 65 2 67 66 2 68 67 2 69 68 2 70 69 2 71 70 2 72 71 2 73 72 2 74 73 2 75 74 2 76 75 2 77 76 2 78 77 2 79 78 2 80 79 2 81 80 2 82 81 2 83 82 2 84 83 2 85 84 2 86 85 2 87 86 2 88 87 2 89 88 2 90 89 2 91 90 2 92 91 2 93 92 2 94 93 2 95 94 2 96 95 2 97 96 2 98 97 2 99 98 2 100 99 2 101 100 2 102 101 2 103 102 2 104 103 2 105 104 2 106 105 2 107 106 2 108 107 2 109 108 2 110 109 2 111 110 2 112 111 2 113 112 2 114 113 2 115 114 2 116 115 2 117 116 2 118 117 2 119 118 2 120 119 2 121 120 2 122 121 2 123 122 2 124 123 2 125 124 2 126 125 2 127 126 2 128 127 2 129 128 2 130 129 2 131 130 2 132 131 2 133 132 2 134 133 2 135 134 2 136 135 2 137 136 2 138 137 2 139 138 2 140 139 2 141 140 2 142 141 2 143 142 2 144 143 2 145 144 2 146 145 2 147 146 2 148 147 2 149 148 2 150 149 2 151 150 2 152 151 2 153 152 2 154 153 2 155 154 2 156 155 2 157 156 2 158 157 2 159 158 2 160 159 2 161 160 2 162 161 2 163 162 2 164 163 2 165 164 2 166 165 2 167 166 2 168 167 2 169 168 2 170 169 2 171 170 2 172 171 2 173 172 2 174 173 2 175 174 2 176 175 2 177 176 2 178 177 2 179 178 2 180 179 2 181 180 2 182 181 2 183 182 2 184 183 2 185 184 2 186 185 2 187 186 2 188 187 2 189 188 2 190 189 2 191 190 2 192 191 2 193 192 2 194 193 2 195 194 2 196 195 2 197 196 2 198 197 2 199 198 2 200 199 2 201 200 2 202 201 2 203 202 2 204 203 2 205 204 2 206 205 2 207 206 2 208 207 2 209 208 2 210 209 2 211 210 2 212 211 2 213 212 2 214 213 2 215 214 2 216 215 2 217 216 2 218 217 2 219 218 2 220 219 2 221 220 2 222 221 2 223 222 2 224 223 2 225 224 2 226 225 2 227 226 2 228 227 2 229 228 2 230 229 2 231 230 2 232 231 2 233 232 2 234 233 2 235 234 2 236 235 2 237 236 2 238 237 2 239 238 2 240 239 2 241 240 2 242 241 2 243 242 2 244 243 2 245 244 2 246 245 2 247 246 2 248 247 2 249 248 2 250 249 2 251 250 2 252 251 2 253 252 2 254 253 2 255 254"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[6,84,119,111,72,111,112]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_8 = Space::new();
  let mut v0_8_write = v0_8.write_zipper();
  let mut v0_8_cursor = descend_cursor((*s0.expect("unbound native input")).read_zipper(),&(*CONSTANT_0));
  let v0_8_origin = v0_8_cursor.path().len();
  for v0_8_byte in v0_8_cursor.child_mask().iter() {
    v0_8_cursor.descend_to_existing_byte(v0_8_byte);
    {
    let v1_2: Space = singleton(&v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)]);
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_8: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_7 = Space::new();
      let mut v2_7_write = v2_7.write_zipper();
      let v2_7_arg_0: &[u8] = &(*CONSTANT_3);
      let v2_7_arg_1: &[u8] = &v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)];
      let v2_7_arg_3: &Space = &(&v0_8_cursor).make_map();
      let v2_7_arg_4: &Space = &(*s0.expect("unbound native input"));
      let mut v2_7_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)]);
      let v2_7_origin = v2_7_cursor.path().len();
      let mut v2_7_more = v2_7_cursor.is_val() || next_value_within(&mut v2_7_cursor,v2_7_origin);
      while v2_7_more {
        {
        let v2_7_depth = v2_7_cursor.path().len();
        let mut v3_5_cursor = (*v2_7_arg_3).read_zipper();
        let v3_5_origin = v3_5_cursor.path().len();
        for v3_5_byte in v3_5_cursor.child_mask().iter() {
          v3_5_cursor.descend_to_existing_byte(v3_5_byte);
          {
          let v4_2: Path = concat_path(&(*v2_7_arg_1),&v3_5_cursor.path()[v3_5_origin..(v3_5_origin + 1)]);
          let v4_3: Space = routine_1(c, &(v4_2), &v2_7_cursor.path()[v2_7_origin..v2_7_depth], &v3_5_cursor, &((*v2_7_arg_4).read_zipper()));
          drop(v4_2);
          join_wrapped_into(&mut v2_7_write,&((v4_3).read_zipper()),&[]);
          }
          v3_5_cursor.ascend(1);
        }
        drop(v3_5_cursor);
        }
        v2_7_more = next_value_within(&mut v2_7_cursor,v2_7_origin);
      }
      drop(v2_7_cursor);
      drop(v2_7_write);
      compose(&(v1_5),&(v2_7))
    };
    drop(v1_5);
    let v1_9: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_10: Space = if has_head(&(v1_9)) { singleton(&[]) } else { Space::new() };
    drop(v1_9);
    let v1_12: Space = if (&(v1_10)).is_empty() { Space::new() } else {
      let mut v5_11 = Space::new();
      let mut v5_11_write = v5_11.write_zipper();
      for v5_11_byte in v0_8_cursor.child_mask().iter() {
        v0_8_cursor.descend_to_existing_byte(v5_11_byte);
        {
        let v6_2: Space = routine_2(c, &v0_8_cursor.path()[(v0_8_origin + 1)..(v0_8_origin + 2)], &v0_8_cursor.path()[(v0_8_origin + 1)..(v0_8_origin + 2)], &v0_8_cursor.path()[v0_8_origin..(v0_8_origin + 1)], &v0_8_cursor, &((*s0.expect("unbound native input")).read_zipper()));
        join_wrapped_into(&mut v5_11_write,&((v6_2).read_zipper()),&[]);
        }
        v0_8_cursor.ascend(1);
      }
      drop(v5_11_write);
      compose(&(v1_10),&(v5_11))
    };
    drop(v1_10);
    let v1_13: Space = unite(&(v1_8),&(v1_12));
    join_wrapped_into(&mut v0_8_write,&((v1_13).read_zipper()),&[]);
    }
    v0_8_cursor.ascend(1);
  }
  drop(v0_8_cursor);
  drop(v0_8_write);
  let v0_10: Space = wrap(&(v0_8),&(*CONSTANT_5));
  (v0_10).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v7_6: Space = singleton(&(*p1));
  let v7_7: Space = intersect(&(*CONSTANT_2),&(v7_6));
  let v7_8: Space = if has_head(&(v7_7)) { singleton(&[]) } else { Space::new() };
  drop(v7_7);
  let v7_9: Space = subtract(&(*CONSTANT_1),&(v7_8));
  drop(v7_8);
  let v7_20: Space = if (&(v7_9)).is_empty() { Space::new() } else {
    let v8_12: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v8_15: Space = if (&(v8_12)).is_empty() { Space::new() } else {
      let v9_14: Space = routine_3(c, &(*CONSTANT_3), &(*p0), &(*s0), &(*s1));
      compose(&(v8_12),&(v9_14))
    };
    drop(v8_12);
    let mut v8_18 = Space::new();
    let mut v8_18_write = v8_18.write_zipper();
    let mut v8_18_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v8_18_origin = v8_18_cursor.path().len();
    for v8_18_byte in v8_18_cursor.child_mask().iter() {
      v8_18_cursor.descend_to_existing_byte(v8_18_byte);
      {
      let v10_2_arg_0: &[u8] = &v8_18_cursor.path()[v8_18_origin..(v8_18_origin + 1)];
      let v10_2_arg_1: &[u8] = &(*p0);
      let v10_2_arg_3: &Space = &(&(*s0)).make_map();
      let v10_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v10_2_more = v8_18_cursor.is_val() || next_value_within(&mut v8_18_cursor,(v8_18_origin + 1));
      while v10_2_more {
        {
        let v10_2_depth = v8_18_cursor.path().len();
        let mut v11_5_cursor = (*v10_2_arg_3).read_zipper();
        let v11_5_origin = v11_5_cursor.path().len();
        for v11_5_byte in v11_5_cursor.child_mask().iter() {
          v11_5_cursor.descend_to_existing_byte(v11_5_byte);
          {
          let v12_2: Path = concat_path(&(*v10_2_arg_1),&v11_5_cursor.path()[v11_5_origin..(v11_5_origin + 1)]);
          let v12_3: Space = routine_1(c, &(v12_2), &v8_18_cursor.path()[v8_18_origin..v10_2_depth], &v11_5_cursor, &((*v10_2_arg_4).read_zipper()));
          drop(v12_2);
          join_wrapped_into(&mut v8_18_write,&((v12_3).read_zipper()),&[]);
          }
          v11_5_cursor.ascend(1);
        }
        drop(v11_5_cursor);
        }
        v10_2_more = next_value_within(&mut v8_18_cursor,(v8_18_origin + 1));
      }
      }
      v8_18_cursor.ascend(1);
    }
    drop(v8_18_cursor);
    drop(v8_18_write);
    let v8_19: Space = unite(&(v8_15),&(v8_18));
    compose(&(v7_9),&(v8_19))
  };
  drop(v7_9);
  let v7_22: Space = intersect(&(*CONSTANT_2),&(v7_6));
  drop(v7_6);
  let v7_23: Space = if has_head(&(v7_22)) { singleton(&[]) } else { Space::new() };
  drop(v7_22);
  let v7_25: Space = if (&(v7_23)).is_empty() { Space::new() } else {
    let mut v13_24 = Space::new();
    let mut v13_24_write = v13_24.write_zipper();
    let mut v13_24_cursor = (*s0).read_zipper();
    let v13_24_origin = v13_24_cursor.path().len();
    for v13_24_byte in v13_24_cursor.child_mask().iter() {
      v13_24_cursor.descend_to_existing_byte(v13_24_byte);
      {
      let v14_2: Space = routine_2(c, &v13_24_cursor.path()[v13_24_origin..(v13_24_origin + 1)], &v13_24_cursor.path()[v13_24_origin..(v13_24_origin + 1)], &(*p0), &v13_24_cursor, &(*s1));
      join_wrapped_into(&mut v13_24_write,&((v14_2).read_zipper()),&[]);
      }
      v13_24_cursor.ascend(1);
    }
    drop(v13_24_cursor);
    drop(v13_24_write);
    compose(&(v7_23),&(v13_24))
  };
  drop(v7_23);
  let v7_26: Space = unite(&(v7_20),&(v7_25));
  (v7_26).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v15_7: Space = singleton(&(*p1));
  let v15_8: Space = intersect(&(*CONSTANT_2),&(v15_7));
  let v15_9: Space = if has_head(&(v15_8)) { singleton(&[]) } else { Space::new() };
  drop(v15_8);
  let v15_10: Space = subtract(&(*CONSTANT_1),&(v15_9));
  drop(v15_9);
  let v15_21: Space = if (&(v15_10)).is_empty() { Space::new() } else {
    let v16_13: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v16_16: Space = if (&(v16_13)).is_empty() { Space::new() } else {
      let v17_15: Space = routine_4(c, &(*CONSTANT_3), &(*p0), &(*p2), &(*s0), &(*s1));
      compose(&(v16_13),&(v17_15))
    };
    drop(v16_13);
    let mut v16_19 = Space::new();
    let mut v16_19_write = v16_19.write_zipper();
    let mut v16_19_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v16_19_origin = v16_19_cursor.path().len();
    for v16_19_byte in v16_19_cursor.child_mask().iter() {
      v16_19_cursor.descend_to_existing_byte(v16_19_byte);
      {
      let v18_2_arg_0: &[u8] = &v16_19_cursor.path()[v16_19_origin..(v16_19_origin + 1)];
      let v18_2_arg_1: &[u8] = &(*p0);
      let v18_2_arg_2: &[u8] = &(*p2);
      let v18_2_arg_4: &Space = &(&(*s0)).make_map();
      let v18_2_arg_5: &Space = &(&(*s1)).make_map();
      let mut v18_2_more = v16_19_cursor.is_val() || next_value_within(&mut v16_19_cursor,(v16_19_origin + 1));
      while v18_2_more {
        {
        let v18_2_depth = v16_19_cursor.path().len();
        let mut v19_6_cursor = (*v18_2_arg_4).read_zipper();
        let v19_6_origin = v19_6_cursor.path().len();
        for v19_6_byte in v19_6_cursor.child_mask().iter() {
          v19_6_cursor.descend_to_existing_byte(v19_6_byte);
          {
          let v20_2: Path = concat_path(&(*v18_2_arg_1),&v19_6_cursor.path()[v19_6_origin..(v19_6_origin + 1)]);
          let v20_3: Space = routine_2(c, &(v20_2), &v16_19_cursor.path()[v16_19_origin..v18_2_depth], &(*v18_2_arg_2), &v19_6_cursor, &((*v18_2_arg_5).read_zipper()));
          drop(v20_2);
          join_wrapped_into(&mut v16_19_write,&((v20_3).read_zipper()),&[]);
          }
          v19_6_cursor.ascend(1);
        }
        drop(v19_6_cursor);
        }
        v18_2_more = next_value_within(&mut v16_19_cursor,(v16_19_origin + 1));
      }
      }
      v16_19_cursor.ascend(1);
    }
    drop(v16_19_cursor);
    drop(v16_19_write);
    let v16_20: Space = unite(&(v16_16),&(v16_19));
    compose(&(v15_10),&(v16_20))
  };
  drop(v15_10);
  let v15_23: Space = intersect(&(*CONSTANT_2),&(v15_7));
  drop(v15_7);
  let v15_24: Space = if has_head(&(v15_23)) { singleton(&[]) } else { Space::new() };
  drop(v15_23);
  let v15_29: Space = if (&(v15_24)).is_empty() { Space::new() } else {
    let mut v21_28 = Space::new();
    let mut v21_28_write = v21_28.write_zipper();
    let mut v21_28_cursor = descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p0));
    let v21_28_origin = v21_28_cursor.path().len();
    for v21_28_byte in v21_28_cursor.child_mask().iter() {
      v21_28_cursor.descend_to_existing_byte(v21_28_byte);
      {
      let v22_2: Space = routine_5(c, &v21_28_cursor.path()[v21_28_origin..(v21_28_origin + 1)], &v21_28_cursor.path()[v21_28_origin..(v21_28_origin + 1)], &(*p2), &v21_28_cursor);
      join_wrapped_into(&mut v21_28_write,&((v22_2).read_zipper()),&[]);
      }
      v21_28_cursor.ascend(1);
    }
    drop(v21_28_cursor);
    drop(v21_28_write);
    compose(&(v15_24),&(v21_28))
  };
  drop(v15_24);
  let v15_30: Space = unite(&(v15_21),&(v15_29));
  (v15_30).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v23_6: Space = singleton(&(*p0));
  let v23_7: Space = intersect(&(*CONSTANT_2),&(v23_6));
  let v23_8: Space = if has_head(&(v23_7)) { singleton(&[]) } else { Space::new() };
  drop(v23_7);
  let v23_9: Space = subtract(&(*CONSTANT_1),&(v23_8));
  drop(v23_8);
  let v23_14: Space = intersect(&(*CONSTANT_2),&(v23_6));
  drop(v23_6);
  let v23_15: Space = if has_head(&(v23_14)) { singleton(&[]) } else { Space::new() };
  drop(v23_14);
  let mut v23_16 = Space::new();
  let mut v23_16_write = v23_16.write_zipper();
  let mut v23_16_cursor = (*s0).read_zipper();
  let v23_16_origin = v23_16_cursor.path().len();
  for v23_16_byte in v23_16_cursor.child_mask().iter() {
    v23_16_cursor.descend_to_existing_byte(v23_16_byte);
    {
    let v24_4: Space = if (&(v23_9)).is_empty() { Space::new() } else {
      let v25_2: Path = concat_path(&(*p1),&v23_16_cursor.path()[v23_16_origin..(v23_16_origin + 1)]);
      let mut v25_3 = Space::new();
      let mut v25_3_write = v25_3.write_zipper();
      let v25_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v25_3_arg_1: &[u8] = &(v25_2);
      let v25_3_arg_3: &Space = &(&v23_16_cursor).make_map();
      let v25_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v25_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v25_3_origin = v25_3_cursor.path().len();
      let mut v25_3_more = v25_3_cursor.is_val() || next_value_within(&mut v25_3_cursor,v25_3_origin);
      while v25_3_more {
        {
        let v25_3_depth = v25_3_cursor.path().len();
        let v26_5: Space = routine_3(c, &v25_3_cursor.path()[v25_3_origin..v25_3_depth], &(*v25_3_arg_1), &((*v25_3_arg_3).read_zipper()), &((*v25_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v25_3_write,&((v26_5).read_zipper()),&[]);
        }
        v25_3_more = next_value_within(&mut v25_3_cursor,v25_3_origin);
      }
      drop(v25_3_cursor);
      drop(v25_3_write);
      compose(&(v23_9),&(v25_3))
    };
    let v24_6: Space = if (&(v23_15)).is_empty() { Space::new() } else {
      let v27_2: Path = concat_path(&(*p1),&v23_16_cursor.path()[v23_16_origin..(v23_16_origin + 1)]);
      let mut v27_5 = Space::new();
      let mut v27_5_write = v27_5.write_zipper();
      for v27_5_byte in v23_16_cursor.child_mask().iter() {
        v23_16_cursor.descend_to_existing_byte(v27_5_byte);
        {
        let v28_2: Space = routine_2(c, &v23_16_cursor.path()[(v23_16_origin + 1)..(v23_16_origin + 2)], &v23_16_cursor.path()[(v23_16_origin + 1)..(v23_16_origin + 2)], &(v27_2), &v23_16_cursor, &(*s1));
        join_wrapped_into(&mut v27_5_write,&((v28_2).read_zipper()),&[]);
        }
        v23_16_cursor.ascend(1);
      }
      drop(v27_5_write);
      drop(v27_2);
      compose(&(v23_15),&(v27_5))
    };
    let v24_7: Space = unite(&(v24_4),&(v24_6));
    join_wrapped_into(&mut v23_16_write,&((v24_7).read_zipper()),&[]);
    }
    v23_16_cursor.ascend(1);
  }
  drop(v23_16_cursor);
  drop(v23_16_write);
  drop(v23_9);
  drop(v23_15);
  (v23_16).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v29_7: Space = singleton(&(*p0));
  let v29_8: Space = intersect(&(*CONSTANT_2),&(v29_7));
  let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
  drop(v29_8);
  let v29_10: Space = subtract(&(*CONSTANT_1),&(v29_9));
  drop(v29_9);
  let v29_15: Space = intersect(&(*CONSTANT_2),&(v29_7));
  drop(v29_7);
  let v29_16: Space = if has_head(&(v29_15)) { singleton(&[]) } else { Space::new() };
  drop(v29_15);
  let mut v29_20 = Space::new();
  let mut v29_20_write = v29_20.write_zipper();
  let mut v29_20_cursor = (*s0).read_zipper();
  let v29_20_origin = v29_20_cursor.path().len();
  for v29_20_byte in v29_20_cursor.child_mask().iter() {
    v29_20_cursor.descend_to_existing_byte(v29_20_byte);
    {
    let v30_4: Space = if (&(v29_10)).is_empty() { Space::new() } else {
      let v31_2: Path = concat_path(&(*p1),&v29_20_cursor.path()[v29_20_origin..(v29_20_origin + 1)]);
      let mut v31_3 = Space::new();
      let mut v31_3_write = v31_3.write_zipper();
      let v31_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v31_3_arg_1: &[u8] = &(v31_2);
      let v31_3_arg_2: &[u8] = &(*p2);
      let v31_3_arg_4: &Space = &(&v29_20_cursor).make_map();
      let v31_3_arg_5: &Space = &(&(*s1)).make_map();
      let mut v31_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v31_3_origin = v31_3_cursor.path().len();
      let mut v31_3_more = v31_3_cursor.is_val() || next_value_within(&mut v31_3_cursor,v31_3_origin);
      while v31_3_more {
        {
        let v31_3_depth = v31_3_cursor.path().len();
        let v32_6: Space = routine_4(c, &v31_3_cursor.path()[v31_3_origin..v31_3_depth], &(*v31_3_arg_1), &(*v31_3_arg_2), &((*v31_3_arg_4).read_zipper()), &((*v31_3_arg_5).read_zipper()));
        join_wrapped_into(&mut v31_3_write,&((v32_6).read_zipper()),&[]);
        }
        v31_3_more = next_value_within(&mut v31_3_cursor,v31_3_origin);
      }
      drop(v31_3_cursor);
      drop(v31_3_write);
      drop(v31_2);
      compose(&(v29_10),&(v31_3))
    };
    let v30_7: Space = if (&(v29_16)).is_empty() { Space::new() } else {
      let mut v33_6 = Space::new();
      let mut v33_6_write = v33_6.write_zipper();
      let mut v33_6_cursor = descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_0)),&(*p1)),&v29_20_cursor.path()[v29_20_origin..(v29_20_origin + 1)]);
      let v33_6_origin = v33_6_cursor.path().len();
      for v33_6_byte in v33_6_cursor.child_mask().iter() {
        v33_6_cursor.descend_to_existing_byte(v33_6_byte);
        {
        let v34_2: Space = routine_5(c, &v33_6_cursor.path()[v33_6_origin..(v33_6_origin + 1)], &v33_6_cursor.path()[v33_6_origin..(v33_6_origin + 1)], &(*p2), &v33_6_cursor);
        join_wrapped_into(&mut v33_6_write,&((v34_2).read_zipper()),&[]);
        }
        v33_6_cursor.ascend(1);
      }
      drop(v33_6_cursor);
      drop(v33_6_write);
      compose(&(v29_16),&(v33_6))
    };
    let v30_8: Space = unite(&(v30_4),&(v30_7));
    join_wrapped_into(&mut v29_20_write,&((v30_8).read_zipper()),&[]);
    }
    v29_20_cursor.ascend(1);
  }
  drop(v29_20_cursor);
  drop(v29_20_write);
  drop(v29_10);
  drop(v29_16);
  (v29_20).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v35_6: Space = singleton(&(*p1));
  let v35_7: Space = intersect(&(*CONSTANT_2),&(v35_6));
  let v35_8: Space = if has_head(&(v35_7)) { singleton(&[]) } else { Space::new() };
  drop(v35_7);
  let v35_9: Space = subtract(&(*CONSTANT_1),&(v35_8));
  drop(v35_8);
  let v35_20: Space = if (&(v35_9)).is_empty() { Space::new() } else {
    let v36_12: Space = first_matching(&(descend_cursor((*CONSTANT_4).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v36_15: Space = if (&(v36_12)).is_empty() { Space::new() } else {
      let v37_14: Space = routine_6(c, &(*CONSTANT_3), &(*p0), &(*p2), &(*s0));
      compose(&(v36_12),&(v37_14))
    };
    drop(v36_12);
    let mut v36_18 = Space::new();
    let mut v36_18_write = v36_18.write_zipper();
    let mut v36_18_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p1));
    let v36_18_origin = v36_18_cursor.path().len();
    for v36_18_byte in v36_18_cursor.child_mask().iter() {
      v36_18_cursor.descend_to_existing_byte(v36_18_byte);
      {
      let v38_2_arg_0: &[u8] = &v36_18_cursor.path()[v36_18_origin..(v36_18_origin + 1)];
      let v38_2_arg_1: &[u8] = &(*p0);
      let v38_2_arg_2: &[u8] = &(*p2);
      let v38_2_arg_4: &Space = &(&(*s0)).make_map();
      let mut v38_2_more = v36_18_cursor.is_val() || next_value_within(&mut v36_18_cursor,(v36_18_origin + 1));
      while v38_2_more {
        {
        let v38_2_depth = v36_18_cursor.path().len();
        let mut v39_5_cursor = (*v38_2_arg_4).read_zipper();
        let v39_5_origin = v39_5_cursor.path().len();
        for v39_5_byte in v39_5_cursor.child_mask().iter() {
          v39_5_cursor.descend_to_existing_byte(v39_5_byte);
          {
          let v40_2: Path = concat_path(&(*v38_2_arg_1),&v39_5_cursor.path()[v39_5_origin..(v39_5_origin + 1)]);
          let v40_3: Space = routine_5(c, &(v40_2), &v36_18_cursor.path()[v36_18_origin..v38_2_depth], &(*v38_2_arg_2), &v39_5_cursor);
          drop(v40_2);
          join_wrapped_into(&mut v36_18_write,&((v40_3).read_zipper()),&[]);
          }
          v39_5_cursor.ascend(1);
        }
        drop(v39_5_cursor);
        }
        v38_2_more = next_value_within(&mut v36_18_cursor,(v36_18_origin + 1));
      }
      }
      v36_18_cursor.ascend(1);
    }
    drop(v36_18_cursor);
    drop(v36_18_write);
    let v36_19: Space = unite(&(v36_15),&(v36_18));
    compose(&(v35_9),&(v36_19))
  };
  drop(v35_9);
  let v35_22: Space = intersect(&(*CONSTANT_2),&(v35_6));
  drop(v35_6);
  let v35_23: Space = if has_head(&(v35_22)) { singleton(&[]) } else { Space::new() };
  drop(v35_22);
  let v35_24: Space = if (&(v35_23)).is_empty() { Space::new() } else {
    compose(&(v35_23),&(*s0))
  };
  drop(v35_23);
  let v35_25: Space = wrap(&(v35_24),&(*p0));
  drop(v35_24);
  let v35_26: Space = wrap(&(v35_25),&(*p2));
  drop(v35_25);
  let v35_27: Space = unite(&(v35_20),&(v35_26));
  drop(v35_26);
  (v35_27).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], p1: &[u8], p2: &[u8], s0: &View<'_, '_>) -> Space {
  let v42_6: Space = singleton(&(*p0));
  let v42_7: Space = intersect(&(*CONSTANT_2),&(v42_6));
  let v42_8: Space = if has_head(&(v42_7)) { singleton(&[]) } else { Space::new() };
  drop(v42_7);
  let v42_9: Space = subtract(&(*CONSTANT_1),&(v42_8));
  drop(v42_8);
  let v42_14: Space = intersect(&(*CONSTANT_2),&(v42_6));
  drop(v42_6);
  let v42_15: Space = if has_head(&(v42_14)) { singleton(&[]) } else { Space::new() };
  drop(v42_14);
  let mut v42_16 = Space::new();
  let mut v42_16_write = v42_16.write_zipper();
  let mut v42_16_cursor = (*s0).read_zipper();
  let v42_16_origin = v42_16_cursor.path().len();
  for v42_16_byte in v42_16_cursor.child_mask().iter() {
    v42_16_cursor.descend_to_existing_byte(v42_16_byte);
    {
    let v43_4: Space = if (&(v42_9)).is_empty() { Space::new() } else {
      let v44_2: Path = concat_path(&(*p1),&v42_16_cursor.path()[v42_16_origin..(v42_16_origin + 1)]);
      let mut v44_3 = Space::new();
      let mut v44_3_write = v44_3.write_zipper();
      let v44_3_arg_0: &[u8] = &(*CONSTANT_3);
      let v44_3_arg_1: &[u8] = &(v44_2);
      let v44_3_arg_2: &[u8] = &(*p2);
      let v44_3_arg_4: &Space = &(&v42_16_cursor).make_map();
      let mut v44_3_cursor = descend_cursor((*CONSTANT_4).read_zipper(),&(*p0));
      let v44_3_origin = v44_3_cursor.path().len();
      let mut v44_3_more = v44_3_cursor.is_val() || next_value_within(&mut v44_3_cursor,v44_3_origin);
      while v44_3_more {
        {
        let v44_3_depth = v44_3_cursor.path().len();
        let v45_5: Space = routine_6(c, &v44_3_cursor.path()[v44_3_origin..v44_3_depth], &(*v44_3_arg_1), &(*v44_3_arg_2), &((*v44_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v44_3_write,&((v45_5).read_zipper()),&[]);
        }
        v44_3_more = next_value_within(&mut v44_3_cursor,v44_3_origin);
      }
      drop(v44_3_cursor);
      drop(v44_3_write);
      compose(&(v42_9),&(v44_3))
    };
    let v43_5: Space = compose(&(v42_15),&v42_16_cursor);
    let v46_2: Path = concat_path(&(*p1),&v42_16_cursor.path()[v42_16_origin..(v42_16_origin + 1)]);
    let v43_6: Space = wrap(&(v43_5),&(v46_2));
    drop(v43_5);
    let v43_7: Space = wrap(&(v43_6),&(*p2));
    drop(v43_6);
    let v43_8: Space = unite(&(v43_4),&(v43_7));
    drop(v43_7);
    join_wrapped_into(&mut v42_16_write,&((v43_8).read_zipper()),&[]);
    }
    v42_16_cursor.ascend(1);
  }
  drop(v42_16_cursor);
  drop(v42_16_write);
  drop(v42_9);
  drop(v42_15);
  (v42_16).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
