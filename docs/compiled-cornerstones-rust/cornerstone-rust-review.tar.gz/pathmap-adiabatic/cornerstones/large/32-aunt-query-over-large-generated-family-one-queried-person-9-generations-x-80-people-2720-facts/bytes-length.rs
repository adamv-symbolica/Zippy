#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[4,65,117,110,116]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("255 2 1 0 2 2 1 2 3 2 2 4 3 2 5 4 2 6 5 2 7 6 2 8 7 2 9 8 2 10 9 2 11 10 2 12 11 2 13 12 2 14 13 2 15 14 2 16 15 2 17 16 2 18 17 2 19 18 2 20 19 2 21 20 2 22 21 2 23 22 2 24 23 2 25 24 2 26 25 2 27 26 2 28 27 2 29 28 2 30 29 2 31 30 2 32 31 2 33 32 2 34 33 2 35 34 2 36 35 2 37 36 2 38 37 2 39 38 2 40 39 2 41 40 2 42 41 2 43 42 2 44 43 2 45 44 2 46 45 2 47 46 2 48 47 2 49 48 2 50 49 2 51 50 2 52 51 2 53 52 2 54 53 2 55 54 2 56 55 2 57 56 2 58 57 2 59 58 2 60 59 2 61 60 2 62 61 2 63 62 2 64 63 2 65 64 2 66 65 2 67 66 2 68 67 2 69 68 2 70 69 2 71 70 2 72 71 2 73 72 2 74 73 2 75 74 2 76 75 2 77 76 2 78 77 2 79 78 2 80 79 2 81 80 2 82 81 2 83 82 2 84 83 2 85 84 2 86 85 2 87 86 2 88 87 2 89 88 2 90 89 2 91 90 2 92 91 2 93 92 2 94 93 2 95 94 2 96 95 2 97 96 2 98 97 2 99 98 2 100 99 2 101 100 2 102 101 2 103 102 2 104 103 2 105 104 2 106 105 2 107 106 2 108 107 2 109 108 2 110 109 2 111 110 2 112 111 2 113 112 2 114 113 2 115 114 2 116 115 2 117 116 2 118 117 2 119 118 2 120 119 2 121 120 2 122 121 2 123 122 2 124 123 2 125 124 2 126 125 2 127 126 2 128 127 2 129 128 2 130 129 2 131 130 2 132 131 2 133 132 2 134 133 2 135 134 2 136 135 2 137 136 2 138 137 2 139 138 2 140 139 2 141 140 2 142 141 2 143 142 2 144 143 2 145 144 2 146 145 2 147 146 2 148 147 2 149 148 2 150 149 2 151 150 2 152 151 2 153 152 2 154 153 2 155 154 2 156 155 2 157 156 2 158 157 2 159 158 2 160 159 2 161 160 2 162 161 2 163 162 2 164 163 2 165 164 2 166 165 2 167 166 2 168 167 2 169 168 2 170 169 2 171 170 2 172 171 2 173 172 2 174 173 2 175 174 2 176 175 2 177 176 2 178 177 2 179 178 2 180 179 2 181 180 2 182 181 2 183 182 2 184 183 2 185 184 2 186 185 2 187 186 2 188 187 2 189 188 2 190 189 2 191 190 2 192 191 2 193 192 2 194 193 2 195 194 2 196 195 2 197 196 2 198 197 2 199 198 2 200 199 2 201 200 2 202 201 2 203 202 2 204 203 2 205 204 2 206 205 2 207 206 2 208 207 2 209 208 2 210 209 2 211 210 2 212 211 2 213 212 2 214 213 2 215 214 2 216 215 2 217 216 2 218 217 2 219 218 2 220 219 2 221 220 2 222 221 2 223 222 2 224 223 2 225 224 2 226 225 2 227 226 2 228 227 2 229 228 2 230 229 2 231 230 2 232 231 2 233 232 2 234 233 2 235 234 2 236 235 2 237 236 2 238 237 2 239 238 2 240 239 2 241 240 2 242 241 2 243 242 2 244 243 2 245 244 2 246 245 2 247 246 2 248 247 2 249 248 2 250 249 2 251 250 2 252 251 2 253 252 2 254 253 2 255 254"));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[6,112,97,114,101,110,116]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[5,99,104,105,108,100]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[6,102,101,109,97,108,101]));
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>) -> Space {
  let mut v0_2 = Space::new();
  let mut v0_2_write = v0_2.write_zipper();
  let mut v0_2_cursor = (*s1.expect("unbound native input")).read_zipper();
  let v0_2_origin = v0_2_cursor.path().len();
  for v0_2_byte in v0_2_cursor.child_mask().iter() {
    v0_2_cursor.descend_to_existing_byte(v0_2_byte);
    {
    let v1_2: Space = routine_1(c, &v0_2_cursor.path()[v0_2_origin..(v0_2_origin + 1)], &v0_2_cursor.path()[v0_2_origin..(v0_2_origin + 1)], &v0_2_cursor, &((*s0.expect("unbound native input")).read_zipper()));
    join_wrapped_into(&mut v0_2_write,&((v1_2).read_zipper()),&[]);
    }
    v0_2_cursor.ascend(1);
  }
  drop(v0_2_cursor);
  drop(v0_2_write);
  let v0_4: Space = wrap(&(v0_2),&(*CONSTANT_0));
  (v0_4).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v2_6: Space = singleton(&(*p1));
  let v2_7: Space = intersect(&(*CONSTANT_2),&(v2_6));
  let v2_8: Space = if has_head(&(v2_7)) { singleton(&[]) } else { Space::new() };
  drop(v2_7);
  let v2_9: Space = subtract(&(*CONSTANT_1),&(v2_8));
  drop(v2_8);
  let v2_20: Space = if (&(v2_9)).is_empty() { Space::new() } else {
    let v3_12: Space = first_matching(&(descend_cursor((*CONSTANT_3).read_zipper(),&(*p1))),&(*CONSTANT_1),false);
    let v3_15: Space = if (&(v3_12)).is_empty() { Space::new() } else {
      let v4_14: Space = routine_2(c, &(*CONSTANT_4), &(*p0), &(*s0), &(*s1));
      compose(&(v3_12),&(v4_14))
    };
    drop(v3_12);
    let mut v3_18 = Space::new();
    let mut v3_18_write = v3_18.write_zipper();
    let mut v3_18_cursor = descend_cursor((*CONSTANT_3).read_zipper(),&(*p1));
    let v3_18_origin = v3_18_cursor.path().len();
    for v3_18_byte in v3_18_cursor.child_mask().iter() {
      v3_18_cursor.descend_to_existing_byte(v3_18_byte);
      {
      let v5_2_arg_0: &[u8] = &v3_18_cursor.path()[v3_18_origin..(v3_18_origin + 1)];
      let v5_2_arg_1: &[u8] = &(*p0);
      let v5_2_arg_3: &Space = &(&(*s0)).make_map();
      let v5_2_arg_4: &Space = &(&(*s1)).make_map();
      let mut v5_2_more = v3_18_cursor.is_val() || next_value_within(&mut v3_18_cursor,(v3_18_origin + 1));
      while v5_2_more {
        {
        let v5_2_depth = v3_18_cursor.path().len();
        let mut v6_5_cursor = (*v5_2_arg_3).read_zipper();
        let v6_5_origin = v6_5_cursor.path().len();
        for v6_5_byte in v6_5_cursor.child_mask().iter() {
          v6_5_cursor.descend_to_existing_byte(v6_5_byte);
          {
          let v7_2: Path = concat_path(&(*v5_2_arg_1),&v6_5_cursor.path()[v6_5_origin..(v6_5_origin + 1)]);
          let v7_3: Space = routine_1(c, &(v7_2), &v3_18_cursor.path()[v3_18_origin..v5_2_depth], &v6_5_cursor, &((*v5_2_arg_4).read_zipper()));
          drop(v7_2);
          join_wrapped_into(&mut v3_18_write,&((v7_3).read_zipper()),&[]);
          }
          v6_5_cursor.ascend(1);
        }
        drop(v6_5_cursor);
        }
        v5_2_more = next_value_within(&mut v3_18_cursor,(v3_18_origin + 1));
      }
      }
      v3_18_cursor.ascend(1);
    }
    drop(v3_18_cursor);
    drop(v3_18_write);
    let v3_19: Space = unite(&(v3_15),&(v3_18));
    compose(&(v2_9),&(v3_19))
  };
  drop(v2_9);
  let v2_22: Space = intersect(&(*CONSTANT_2),&(v2_6));
  drop(v2_6);
  let v2_23: Space = if has_head(&(v2_22)) { singleton(&[]) } else { Space::new() };
  drop(v2_22);
  let v2_1567: Space = if (&(v2_23)).is_empty() { Space::new() } else {
    let v8_29: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_6))),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_6)),&(*p0))));
    let v8_795: Space = drop_length_prefixes(&(v8_29));
    drop(v8_29);
    let v8_796: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))),&(v8_795));
    drop(v8_795);
    let v8_1562: Space = drop_length_prefixes(&(v8_796));
    drop(v8_796);
    let v8_1563: Space = subtract(&(v8_1562),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_6)),&(*p0))));
    drop(v8_1562);
    let v8_1566: Space = intersect(&(v8_1563),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7))));
    drop(v8_1563);
    compose(&(v2_23),&(v8_1566))
  };
  drop(v2_23);
  let v2_1568: Space = wrap(&(v2_1567),&(*p0));
  drop(v2_1567);
  let v2_1569: Space = unite(&(v2_20),&(v2_1568));
  drop(v2_1568);
  (v2_1569).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], p1: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v9_6: Space = singleton(&(*p0));
  let v9_7: Space = intersect(&(*CONSTANT_2),&(v9_6));
  let v9_8: Space = if has_head(&(v9_7)) { singleton(&[]) } else { Space::new() };
  drop(v9_7);
  let v9_9: Space = subtract(&(*CONSTANT_1),&(v9_8));
  drop(v9_8);
  let v9_14: Space = intersect(&(*CONSTANT_2),&(v9_6));
  drop(v9_6);
  let v9_15: Space = if has_head(&(v9_14)) { singleton(&[]) } else { Space::new() };
  drop(v9_14);
  let mut v9_16 = Space::new();
  let mut v9_16_write = v9_16.write_zipper();
  let mut v9_16_cursor = (*s0).read_zipper();
  let v9_16_origin = v9_16_cursor.path().len();
  for v9_16_byte in v9_16_cursor.child_mask().iter() {
    v9_16_cursor.descend_to_existing_byte(v9_16_byte);
    {
    let v10_4: Space = if (&(v9_9)).is_empty() { Space::new() } else {
      let v11_2: Path = concat_path(&(*p1),&v9_16_cursor.path()[v9_16_origin..(v9_16_origin + 1)]);
      let mut v11_3 = Space::new();
      let mut v11_3_write = v11_3.write_zipper();
      let v11_3_arg_0: &[u8] = &(*CONSTANT_4);
      let v11_3_arg_1: &[u8] = &(v11_2);
      let v11_3_arg_3: &Space = &(&v9_16_cursor).make_map();
      let v11_3_arg_4: &Space = &(&(*s1)).make_map();
      let mut v11_3_cursor = descend_cursor((*CONSTANT_3).read_zipper(),&(*p0));
      let v11_3_origin = v11_3_cursor.path().len();
      let mut v11_3_more = v11_3_cursor.is_val() || next_value_within(&mut v11_3_cursor,v11_3_origin);
      while v11_3_more {
        {
        let v11_3_depth = v11_3_cursor.path().len();
        let v12_5: Space = routine_2(c, &v11_3_cursor.path()[v11_3_origin..v11_3_depth], &(*v11_3_arg_1), &((*v11_3_arg_3).read_zipper()), &((*v11_3_arg_4).read_zipper()));
        join_wrapped_into(&mut v11_3_write,&((v12_5).read_zipper()),&[]);
        }
        v11_3_more = next_value_within(&mut v11_3_cursor,v11_3_origin);
      }
      drop(v11_3_cursor);
      drop(v11_3_write);
      compose(&(v9_9),&(v11_3))
    };
    let v10_6: Space = if (&(v9_15)).is_empty() { Space::new() } else {
      let v13_2: Path = concat_path(&(*p1),&v9_16_cursor.path()[v9_16_origin..(v9_16_origin + 1)]);
      let v13_5: Space = routine_3(c, &(v13_2), &v9_16_cursor, &(*s1));
      drop(v13_2);
      compose(&(v9_15),&(v13_5))
    };
    let v10_7: Space = unite(&(v10_4),&(v10_6));
    join_wrapped_into(&mut v9_16_write,&((v10_7).read_zipper()),&[]);
    }
    v9_16_cursor.ascend(1);
  }
  drop(v9_16_cursor);
  drop(v9_16_write);
  drop(v9_9);
  drop(v9_15);
  (v9_16).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v14_8: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_6))),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_6)),&(*p0))));
  let v14_774: Space = drop_length_prefixes(&(v14_8));
  drop(v14_8);
  let v14_775: Space = restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))),&(v14_774));
  drop(v14_774);
  let v14_1541: Space = drop_length_prefixes(&(v14_775));
  drop(v14_775);
  let v14_1542: Space = subtract(&(v14_1541),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_6)),&(*p0))));
  drop(v14_1541);
  let v14_1545: Space = intersect(&(v14_1542),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_7))));
  drop(v14_1542);
  let v14_1546: Space = wrap(&(v14_1545),&(*p0));
  drop(v14_1545);
  (v14_1546).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
