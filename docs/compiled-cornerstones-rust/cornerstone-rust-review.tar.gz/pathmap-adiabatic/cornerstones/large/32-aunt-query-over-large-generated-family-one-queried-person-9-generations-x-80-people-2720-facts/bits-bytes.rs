#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,1,0,0,1,0,0,1,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,0,0,0,1,0,0,1,0,0,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1,0,0,1,0,0,1,0,0,0,1,1]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>) -> Space {
  let mut v0_11 = Space::new();
  let mut v0_11_write = v0_11.write_zipper();
  let mut v0_11_cursor = (*s1.expect("unbound native input")).read_zipper();
  let v0_11_origin = v0_11_cursor.path().len();
  for v0_11_byte in v0_11_cursor.child_mask().iter() {
    v0_11_cursor.descend_to_existing_byte(v0_11_byte);
    {
    let v1_2: Space = singleton(&v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 1)]);
    let v1_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if map_kernels::has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (&(v1_5)).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_write = v2_6.write_zipper();
      for v2_6_byte in v0_11_cursor.child_mask().iter() {
        v0_11_cursor.descend_to_existing_byte(v2_6_byte);
        {
        let v3_2: Space = singleton(&v0_11_cursor.path()[(v0_11_origin + 1)..(v0_11_origin + 2)]);
        let v3_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v3_2));
        let v3_4: Space = if map_kernels::has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (&(v3_5)).is_empty() { Space::new() } else {
          let v4_7: Space = routine_1(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          map_map_kernels::compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if map_kernels::has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (&(v3_10)).is_empty() { Space::new() } else {
          let v5_11: Space = routine_2(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          map_map_kernels::compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = map_map_kernels::unite(&(v3_8),&(v3_12));
        join_wrapped_into(&mut v2_6_write,&((v3_13).read_zipper()),&[]);
        }
        v0_11_cursor.ascend(1);
      }
      drop(v2_6_write);
      map_map_kernels::compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if map_kernels::has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (&(v1_9)).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_write = v6_10.write_zipper();
      for v6_10_byte in v0_11_cursor.child_mask().iter() {
        v0_11_cursor.descend_to_existing_byte(v6_10_byte);
        {
        let v7_2: Space = singleton(&v0_11_cursor.path()[(v0_11_origin + 1)..(v0_11_origin + 2)]);
        let v7_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if map_kernels::has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (&(v7_5)).is_empty() { Space::new() } else {
          let v8_7: Space = routine_1(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          map_map_kernels::compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if map_kernels::has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (&(v7_10)).is_empty() { Space::new() } else {
          let v9_11: Space = routine_3(c, &v0_11_cursor.path()[v0_11_origin..(v0_11_origin + 2)], &v0_11_cursor, &((*s0.expect("unbound native input")).read_zipper()));
          map_map_kernels::compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = map_map_kernels::unite(&(v7_8),&(v7_12));
        join_wrapped_into(&mut v6_10_write,&((v7_13).read_zipper()),&[]);
        }
        v0_11_cursor.ascend(1);
      }
      drop(v6_10_write);
      map_map_kernels::compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = map_map_kernels::unite(&(v1_7),&(v1_11));
    join_wrapped_into(&mut v0_11_write,&((v1_12).read_zipper()),&[]);
    }
    v0_11_cursor.ascend(1);
  }
  drop(v0_11_cursor);
  drop(v0_11_write);
  let v0_13: Space = map_kernels::wrap(&(v0_11),&(*CONSTANT_2));
  (v0_13).clone()
}

fn routine_1(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v10_34 = Space::new();
  let mut v10_34_write = v10_34.write_zipper();
  let mut v10_34_cursor = (*s0).read_zipper();
  let v10_34_origin = v10_34_cursor.path().len();
  for v10_34_byte in v10_34_cursor.child_mask().iter() {
    v10_34_cursor.descend_to_existing_byte(v10_34_byte);
    {
    let v11_2: Space = singleton(&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
    let v11_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if map_kernels::has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (&(v11_5)).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
      let mut v12_7 = Space::new();
      let mut v12_7_write = v12_7.write_zipper();
      for v12_7_byte in v10_34_cursor.child_mask().iter() {
        v10_34_cursor.descend_to_existing_byte(v12_7_byte);
        {
        let v13_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v13_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v13_2));
        let v13_4: Space = if map_kernels::has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (&(v13_5)).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v14_7 = Space::new();
          let mut v14_7_write = v14_7.write_zipper();
          for v14_7_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v14_7_byte);
            {
            let v15_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v15_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v15_2));
            let v15_4: Space = if map_kernels::has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (&(v15_5)).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v16_7: Space = routine_4(c, &(v16_6), &v10_34_cursor, &(*s1));
              map_map_kernels::compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if map_kernels::has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (&(v15_10)).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v17_11: Space = routine_5(c, &(v17_6), &v10_34_cursor, &(*s1));
              drop(v17_6);
              map_map_kernels::compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = map_map_kernels::unite(&(v15_8),&(v15_12));
            join_wrapped_into(&mut v14_7_write,&((v15_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v14_7_write);
          map_map_kernels::compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if map_kernels::has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (&(v13_10)).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v12_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v18_11 = Space::new();
          let mut v18_11_write = v18_11.write_zipper();
          for v18_11_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v18_11_byte);
            {
            let v19_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v19_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v19_2));
            let v19_4: Space = if map_kernels::has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (&(v19_5)).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v18_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v20_7: Space = routine_4(c, &(v20_6), &v10_34_cursor, &(*s1));
              map_map_kernels::compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if map_kernels::has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v19_12: Space = if (&(v19_10)).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v18_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v21_11: Space = routine_3(c, &(v21_6), &v10_34_cursor, &(*s1));
              drop(v21_6);
              map_map_kernels::compose(&(v19_10),&(v21_11))
            };
            drop(v19_10);
            let v19_13: Space = map_map_kernels::unite(&(v19_8),&(v19_12));
            join_wrapped_into(&mut v18_11_write,&((v19_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v18_11_write);
          drop(v18_6);
          map_map_kernels::compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = map_map_kernels::unite(&(v13_8),&(v13_12));
        join_wrapped_into(&mut v12_7_write,&((v13_13).read_zipper()),&[]);
        }
        v10_34_cursor.ascend(1);
      }
      drop(v12_7_write);
      map_map_kernels::compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if map_kernels::has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_13: Space = if (&(v11_10)).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]);
      let mut v22_12 = Space::new();
      let mut v22_12_write = v22_12.write_zipper();
      for v22_12_byte in v10_34_cursor.child_mask().iter() {
        v10_34_cursor.descend_to_existing_byte(v22_12_byte);
        {
        let v23_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v23_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if map_kernels::has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (&(v23_5)).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
          let mut v24_7 = Space::new();
          let mut v24_7_write = v24_7.write_zipper();
          for v24_7_byte in v10_34_cursor.child_mask().iter() {
            v10_34_cursor.descend_to_existing_byte(v24_7_byte);
            {
            let v25_2: Space = singleton(&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
            let v25_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v25_2));
            let v25_4: Space = if map_kernels::has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
            drop(v25_3);
            let v25_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v25_4));
            drop(v25_4);
            let v25_8: Space = if (&(v25_5)).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v24_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v26_7: Space = routine_4(c, &(v26_6), &v10_34_cursor, &(*s1));
              map_map_kernels::compose(&(v25_5),&(v26_7))
            };
            drop(v25_5);
            let v25_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v25_2));
            drop(v25_2);
            let v25_10: Space = if map_kernels::has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
            drop(v25_9);
            let v25_12: Space = if (&(v25_10)).is_empty() { Space::new() } else {
              let v27_6: Path = concat_path(&(v24_6),&v10_34_cursor.path()[(v10_34_origin + 2)..(v10_34_origin + 3)]);
              let v27_11: Space = routine_5(c, &(v27_6), &v10_34_cursor, &(*s1));
              drop(v27_6);
              map_map_kernels::compose(&(v25_10),&(v27_11))
            };
            drop(v25_10);
            let v25_13: Space = map_map_kernels::unite(&(v25_8),&(v25_12));
            join_wrapped_into(&mut v24_7_write,&((v25_13).read_zipper()),&[]);
            }
            v10_34_cursor.ascend(1);
          }
          drop(v24_7_write);
          map_map_kernels::compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if map_kernels::has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_18: Space = if (&(v23_10)).is_empty() { Space::new() } else {
          let v28_12: Space = view_view_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)])));
          let mut v28_13 = Space::new();
          let mut v28_13_write = v28_13.write_zipper();
          let mut v28_13_cursor = (v28_12).read_zipper();
          let v28_13_origin = v28_13_cursor.path().len();
          for v28_13_byte in v28_13_cursor.child_mask().iter() {
            v28_13_cursor.descend_to_existing_byte(v28_13_byte);
            {
            let v29_2: Space = singleton(&v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)]);
            let v29_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v29_2));
            let v29_4: Space = if map_kernels::has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
            drop(v29_3);
            let v29_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v29_4));
            drop(v29_4);
            let v29_7: Space = if (&(v29_5)).is_empty() { Space::new() } else {
              let v30_6: Space = routine_6(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              map_map_kernels::compose(&(v29_5),&(v30_6))
            };
            drop(v29_5);
            let v29_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v29_2));
            drop(v29_2);
            let v29_9: Space = if map_kernels::has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
            drop(v29_8);
            let v29_11: Space = if (&(v29_9)).is_empty() { Space::new() } else {
              let v31_10: Space = routine_7(c, &v28_13_cursor.path()[v28_13_origin..(v28_13_origin + 1)], &v28_13_cursor);
              map_map_kernels::compose(&(v29_9),&(v31_10))
            };
            drop(v29_9);
            let v29_12: Space = map_map_kernels::unite(&(v29_7),&(v29_11));
            join_wrapped_into(&mut v28_13_write,&((v29_12).read_zipper()),&[]);
            }
            v28_13_cursor.ascend(1);
          }
          drop(v28_13_cursor);
          drop(v28_13_write);
          drop(v28_12);
          let v28_14: Space = view_map_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v28_13));
          let mut v28_15 = Space::new();
          let mut v28_15_write = v28_15.write_zipper();
          let mut v28_15_cursor = (v28_14).read_zipper();
          let v28_15_origin = v28_15_cursor.path().len();
          for v28_15_byte in v28_15_cursor.child_mask().iter() {
            v28_15_cursor.descend_to_existing_byte(v28_15_byte);
            {
            let v32_2: Space = singleton(&v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)]);
            let v32_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v32_2));
            let v32_4: Space = if map_kernels::has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_7: Space = if (&(v32_5)).is_empty() { Space::new() } else {
              let v33_6: Space = routine_8(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              map_map_kernels::compose(&(v32_5),&(v33_6))
            };
            drop(v32_5);
            let v32_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v32_2));
            drop(v32_2);
            let v32_9: Space = if map_kernels::has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
            drop(v32_8);
            let v32_11: Space = if (&(v32_9)).is_empty() { Space::new() } else {
              let v34_10: Space = routine_9(c, &v28_15_cursor.path()[v28_15_origin..(v28_15_origin + 1)], &v28_15_cursor);
              map_map_kernels::compose(&(v32_9),&(v34_10))
            };
            drop(v32_9);
            let v32_12: Space = map_map_kernels::unite(&(v32_7),&(v32_11));
            join_wrapped_into(&mut v28_15_write,&((v32_12).read_zipper()),&[]);
            }
            v28_15_cursor.ascend(1);
          }
          drop(v28_15_cursor);
          drop(v28_15_write);
          let v28_16: Space = map_view_kernels::subtract(&(v28_15),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v10_34_cursor.path()[v10_34_origin..(v10_34_origin + 1)]),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)])));
          let v28_17: Space = map_view_kernels::intersect(&(v28_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
          map_map_kernels::compose(&(v23_10),&(v28_17))
        };
        drop(v23_10);
        let v35_6: Path = concat_path(&(v22_6),&v10_34_cursor.path()[(v10_34_origin + 1)..(v10_34_origin + 2)]);
        let v23_19: Space = map_kernels::wrap(&(v23_18),&(v35_6));
        let v23_20: Space = map_map_kernels::unite(&(v23_8),&(v23_19));
        join_wrapped_into(&mut v22_12_write,&((v23_20).read_zipper()),&[]);
        }
        v10_34_cursor.ascend(1);
      }
      drop(v22_12_write);
      drop(v22_6);
      map_map_kernels::compose(&(v11_10),&(v22_12))
    };
    drop(v11_10);
    let v11_14: Space = map_map_kernels::unite(&(v11_8),&(v11_13));
    join_wrapped_into(&mut v10_34_write,&((v11_14).read_zipper()),&[]);
    }
    v10_34_cursor.ascend(1);
  }
  drop(v10_34_cursor);
  drop(v10_34_write);
  (v10_34).clone()
}

fn routine_2(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v36_40 = Space::new();
  let mut v36_40_write = v36_40.write_zipper();
  let mut v36_40_cursor = (*s0).read_zipper();
  let v36_40_origin = v36_40_cursor.path().len();
  for v36_40_byte in v36_40_cursor.child_mask().iter() {
    v36_40_cursor.descend_to_existing_byte(v36_40_byte);
    {
    let v37_2: Space = singleton(&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
    let v37_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v37_2));
    let v37_4: Space = if map_kernels::has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_8: Space = if (&(v37_5)).is_empty() { Space::new() } else {
      let v38_6: Path = concat_path(&(*p0),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
      let mut v38_7 = Space::new();
      let mut v38_7_write = v38_7.write_zipper();
      for v38_7_byte in v36_40_cursor.child_mask().iter() {
        v36_40_cursor.descend_to_existing_byte(v38_7_byte);
        {
        let v39_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
        let v39_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v39_2));
        let v39_4: Space = if map_kernels::has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (&(v39_5)).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v38_6),&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
          let mut v40_7 = Space::new();
          let mut v40_7_write = v40_7.write_zipper();
          for v40_7_byte in v36_40_cursor.child_mask().iter() {
            v36_40_cursor.descend_to_existing_byte(v40_7_byte);
            {
            let v41_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
            let v41_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v41_2));
            let v41_4: Space = if map_kernels::has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v41_4));
            drop(v41_4);
            let v41_8: Space = if (&(v41_5)).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v40_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v42_7: Space = routine_4(c, &(v42_6), &v36_40_cursor, &(*s1));
              map_map_kernels::compose(&(v41_5),&(v42_7))
            };
            drop(v41_5);
            let v41_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v41_2));
            drop(v41_2);
            let v41_10: Space = if map_kernels::has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
            drop(v41_9);
            let v41_12: Space = if (&(v41_10)).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v40_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v43_11: Space = routine_5(c, &(v43_6), &v36_40_cursor, &(*s1));
              drop(v43_6);
              map_map_kernels::compose(&(v41_10),&(v43_11))
            };
            drop(v41_10);
            let v41_13: Space = map_map_kernels::unite(&(v41_8),&(v41_12));
            join_wrapped_into(&mut v40_7_write,&((v41_13).read_zipper()),&[]);
            }
            v36_40_cursor.ascend(1);
          }
          drop(v40_7_write);
          map_map_kernels::compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if map_kernels::has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (&(v39_10)).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v38_6),&v36_40_cursor.path()[(v36_40_origin + 1)..(v36_40_origin + 2)]);
          let mut v44_11 = Space::new();
          let mut v44_11_write = v44_11.write_zipper();
          for v44_11_byte in v36_40_cursor.child_mask().iter() {
            v36_40_cursor.descend_to_existing_byte(v44_11_byte);
            {
            let v45_2: Space = singleton(&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
            let v45_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v45_2));
            let v45_4: Space = if map_kernels::has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_8: Space = if (&(v45_5)).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v44_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v46_7: Space = routine_4(c, &(v46_6), &v36_40_cursor, &(*s1));
              map_map_kernels::compose(&(v45_5),&(v46_7))
            };
            drop(v45_5);
            let v45_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v45_2));
            drop(v45_2);
            let v45_10: Space = if map_kernels::has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
            drop(v45_9);
            let v45_12: Space = if (&(v45_10)).is_empty() { Space::new() } else {
              let v47_6: Path = concat_path(&(v44_6),&v36_40_cursor.path()[(v36_40_origin + 2)..(v36_40_origin + 3)]);
              let v47_11: Space = routine_3(c, &(v47_6), &v36_40_cursor, &(*s1));
              drop(v47_6);
              map_map_kernels::compose(&(v45_10),&(v47_11))
            };
            drop(v45_10);
            let v45_13: Space = map_map_kernels::unite(&(v45_8),&(v45_12));
            join_wrapped_into(&mut v44_11_write,&((v45_13).read_zipper()),&[]);
            }
            v36_40_cursor.ascend(1);
          }
          drop(v44_11_write);
          drop(v44_6);
          map_map_kernels::compose(&(v39_10),&(v44_11))
        };
        drop(v39_10);
        let v39_13: Space = map_map_kernels::unite(&(v39_8),&(v39_12));
        join_wrapped_into(&mut v38_7_write,&((v39_13).read_zipper()),&[]);
        }
        v36_40_cursor.ascend(1);
      }
      drop(v38_7_write);
      map_map_kernels::compose(&(v37_5),&(v38_7))
    };
    drop(v37_5);
    let v37_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v37_2));
    drop(v37_2);
    let v37_10: Space = if map_kernels::has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
    drop(v37_9);
    let v37_18: Space = if (&(v37_10)).is_empty() { Space::new() } else {
      let v48_12: Space = view_view_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)])));
      let mut v48_13 = Space::new();
      let mut v48_13_write = v48_13.write_zipper();
      let mut v48_13_cursor = (v48_12).read_zipper();
      let v48_13_origin = v48_13_cursor.path().len();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_existing_byte(v48_13_byte);
        {
        let v49_2: Space = singleton(&v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 1)]);
        let v49_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v49_2));
        let v49_4: Space = if map_kernels::has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (&(v49_5)).is_empty() { Space::new() } else {
          let mut v50_6 = Space::new();
          let mut v50_6_write = v50_6.write_zipper();
          for v50_6_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v50_6_byte);
            {
            let v51_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v51_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v51_2));
            let v51_4: Space = if map_kernels::has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
            drop(v51_3);
            let v51_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v51_4));
            drop(v51_4);
            let v51_8: Space = if (&(v51_5)).is_empty() { Space::new() } else {
              let v52_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              map_map_kernels::compose(&(v51_5),&(v52_7))
            };
            drop(v51_5);
            let v51_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v51_2));
            drop(v51_2);
            let v51_10: Space = if map_kernels::has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
            drop(v51_9);
            let v51_12: Space = if (&(v51_10)).is_empty() { Space::new() } else {
              let v53_11: Space = routine_11(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              map_map_kernels::compose(&(v51_10),&(v53_11))
            };
            drop(v51_10);
            let v51_13: Space = map_map_kernels::unite(&(v51_8),&(v51_12));
            join_wrapped_into(&mut v50_6_write,&((v51_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v50_6_write);
          map_map_kernels::compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if map_kernels::has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (&(v49_9)).is_empty() { Space::new() } else {
          let mut v54_10 = Space::new();
          let mut v54_10_write = v54_10.write_zipper();
          for v54_10_byte in v48_13_cursor.child_mask().iter() {
            v48_13_cursor.descend_to_existing_byte(v54_10_byte);
            {
            let v55_2: Space = singleton(&v48_13_cursor.path()[(v48_13_origin + 1)..(v48_13_origin + 2)]);
            let v55_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v55_2));
            let v55_4: Space = if map_kernels::has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
            drop(v55_3);
            let v55_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v55_4));
            drop(v55_4);
            let v55_8: Space = if (&(v55_5)).is_empty() { Space::new() } else {
              let v56_7: Space = routine_10(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              map_map_kernels::compose(&(v55_5),&(v56_7))
            };
            drop(v55_5);
            let v55_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v55_2));
            drop(v55_2);
            let v55_10: Space = if map_kernels::has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
            drop(v55_9);
            let v55_12: Space = if (&(v55_10)).is_empty() { Space::new() } else {
              let v57_11: Space = routine_12(c, &v48_13_cursor.path()[v48_13_origin..(v48_13_origin + 2)], &v48_13_cursor);
              map_map_kernels::compose(&(v55_10),&(v57_11))
            };
            drop(v55_10);
            let v55_13: Space = map_map_kernels::unite(&(v55_8),&(v55_12));
            join_wrapped_into(&mut v54_10_write,&((v55_13).read_zipper()),&[]);
            }
            v48_13_cursor.ascend(1);
          }
          drop(v54_10_write);
          map_map_kernels::compose(&(v49_9),&(v54_10))
        };
        drop(v49_9);
        let v49_12: Space = map_map_kernels::unite(&(v49_7),&(v49_11));
        join_wrapped_into(&mut v48_13_write,&((v49_12).read_zipper()),&[]);
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_13_write);
      drop(v48_12);
      let v48_14: Space = view_map_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v48_13));
      let mut v48_15 = Space::new();
      let mut v48_15_write = v48_15.write_zipper();
      let mut v48_15_cursor = (v48_14).read_zipper();
      let v48_15_origin = v48_15_cursor.path().len();
      for v48_15_byte in v48_15_cursor.child_mask().iter() {
        v48_15_cursor.descend_to_existing_byte(v48_15_byte);
        {
        let v58_2: Space = singleton(&v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 1)]);
        let v58_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v58_2));
        let v58_4: Space = if map_kernels::has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (&(v58_5)).is_empty() { Space::new() } else {
          let mut v59_6 = Space::new();
          let mut v59_6_write = v59_6.write_zipper();
          for v59_6_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v59_6_byte);
            {
            let v60_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v60_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v60_2));
            let v60_4: Space = if map_kernels::has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (&(v60_5)).is_empty() { Space::new() } else {
              let v61_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              map_map_kernels::compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if map_kernels::has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (&(v60_10)).is_empty() { Space::new() } else {
              let v62_11: Space = routine_14(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              map_map_kernels::compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = map_map_kernels::unite(&(v60_8),&(v60_12));
            join_wrapped_into(&mut v59_6_write,&((v60_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v59_6_write);
          map_map_kernels::compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if map_kernels::has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (&(v58_9)).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_write = v63_10.write_zipper();
          for v63_10_byte in v48_15_cursor.child_mask().iter() {
            v48_15_cursor.descend_to_existing_byte(v63_10_byte);
            {
            let v64_2: Space = singleton(&v48_15_cursor.path()[(v48_15_origin + 1)..(v48_15_origin + 2)]);
            let v64_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v64_2));
            let v64_4: Space = if map_kernels::has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_8: Space = if (&(v64_5)).is_empty() { Space::new() } else {
              let v65_7: Space = routine_13(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              map_map_kernels::compose(&(v64_5),&(v65_7))
            };
            drop(v64_5);
            let v64_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v64_2));
            drop(v64_2);
            let v64_10: Space = if map_kernels::has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
            drop(v64_9);
            let v64_12: Space = if (&(v64_10)).is_empty() { Space::new() } else {
              let v66_11: Space = routine_15(c, &v48_15_cursor.path()[v48_15_origin..(v48_15_origin + 2)], &v48_15_cursor);
              map_map_kernels::compose(&(v64_10),&(v66_11))
            };
            drop(v64_10);
            let v64_13: Space = map_map_kernels::unite(&(v64_8),&(v64_12));
            join_wrapped_into(&mut v63_10_write,&((v64_13).read_zipper()),&[]);
            }
            v48_15_cursor.ascend(1);
          }
          drop(v63_10_write);
          map_map_kernels::compose(&(v58_9),&(v63_10))
        };
        drop(v58_9);
        let v58_12: Space = map_map_kernels::unite(&(v58_7),&(v58_11));
        join_wrapped_into(&mut v48_15_write,&((v58_12).read_zipper()),&[]);
        }
        v48_15_cursor.ascend(1);
      }
      drop(v48_15_cursor);
      drop(v48_15_write);
      let v48_16: Space = map_view_kernels::subtract(&(v48_15),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)])));
      let v48_17: Space = map_view_kernels::intersect(&(v48_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      map_map_kernels::compose(&(v37_10),&(v48_17))
    };
    drop(v37_10);
    let v67_6: Path = concat_path(&(*p0),&v36_40_cursor.path()[v36_40_origin..(v36_40_origin + 1)]);
    let v37_19: Space = map_kernels::wrap(&(v37_18),&(v67_6));
    let v37_20: Space = map_map_kernels::unite(&(v37_8),&(v37_19));
    join_wrapped_into(&mut v36_40_write,&((v37_20).read_zipper()),&[]);
    }
    v36_40_cursor.ascend(1);
  }
  drop(v36_40_cursor);
  drop(v36_40_write);
  (v36_40).clone()
}

fn routine_3(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let v68_8: Space = view_view_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0))));
  let mut v68_27 = Space::new();
  let mut v68_27_write = v68_27.write_zipper();
  let mut v68_27_cursor = (v68_8).read_zipper();
  let v68_27_origin = v68_27_cursor.path().len();
  for v68_27_byte in v68_27_cursor.child_mask().iter() {
    v68_27_cursor.descend_to_existing_byte(v68_27_byte);
    {
    let v69_2: Space = singleton(&v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 1)]);
    let v69_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v69_2));
    let v69_4: Space = if map_kernels::has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (&(v69_5)).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_write = v70_6.write_zipper();
      for v70_6_byte in v68_27_cursor.child_mask().iter() {
        v68_27_cursor.descend_to_existing_byte(v70_6_byte);
        {
        let v71_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 1)..(v68_27_origin + 2)]);
        let v71_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v71_2));
        let v71_4: Space = if map_kernels::has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (&(v71_5)).is_empty() { Space::new() } else {
          let mut v72_7 = Space::new();
          let mut v72_7_write = v72_7.write_zipper();
          for v72_7_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v72_7_byte);
            {
            let v73_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v73_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v73_2));
            let v73_4: Space = if map_kernels::has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (&(v73_5)).is_empty() { Space::new() } else {
              let v74_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              map_map_kernels::compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if map_kernels::has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (&(v73_10)).is_empty() { Space::new() } else {
              let v75_11: Space = routine_17(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              map_map_kernels::compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = map_map_kernels::unite(&(v73_8),&(v73_12));
            join_wrapped_into(&mut v72_7_write,&((v73_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v72_7_write);
          map_map_kernels::compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if map_kernels::has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (&(v71_10)).is_empty() { Space::new() } else {
          let mut v76_11 = Space::new();
          let mut v76_11_write = v76_11.write_zipper();
          for v76_11_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v76_11_byte);
            {
            let v77_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v77_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v77_2));
            let v77_4: Space = if map_kernels::has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
            drop(v77_3);
            let v77_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v77_4));
            drop(v77_4);
            let v77_8: Space = if (&(v77_5)).is_empty() { Space::new() } else {
              let v78_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              map_map_kernels::compose(&(v77_5),&(v78_7))
            };
            drop(v77_5);
            let v77_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v77_2));
            drop(v77_2);
            let v77_10: Space = if map_kernels::has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
            drop(v77_9);
            let v77_12: Space = if (&(v77_10)).is_empty() { Space::new() } else {
              let v79_11: Space = routine_12(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              map_map_kernels::compose(&(v77_10),&(v79_11))
            };
            drop(v77_10);
            let v77_13: Space = map_map_kernels::unite(&(v77_8),&(v77_12));
            join_wrapped_into(&mut v76_11_write,&((v77_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v76_11_write);
          map_map_kernels::compose(&(v71_10),&(v76_11))
        };
        drop(v71_10);
        let v71_13: Space = map_map_kernels::unite(&(v71_8),&(v71_12));
        join_wrapped_into(&mut v70_6_write,&((v71_13).read_zipper()),&[]);
        }
        v68_27_cursor.ascend(1);
      }
      drop(v70_6_write);
      map_map_kernels::compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if map_kernels::has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (&(v69_9)).is_empty() { Space::new() } else {
      let mut v80_10 = Space::new();
      let mut v80_10_write = v80_10.write_zipper();
      for v80_10_byte in v68_27_cursor.child_mask().iter() {
        v68_27_cursor.descend_to_existing_byte(v80_10_byte);
        {
        let v81_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 1)..(v68_27_origin + 2)]);
        let v81_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v81_2));
        let v81_4: Space = if map_kernels::has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (&(v81_5)).is_empty() { Space::new() } else {
          let mut v82_7 = Space::new();
          let mut v82_7_write = v82_7.write_zipper();
          for v82_7_byte in v68_27_cursor.child_mask().iter() {
            v68_27_cursor.descend_to_existing_byte(v82_7_byte);
            {
            let v83_2: Space = singleton(&v68_27_cursor.path()[(v68_27_origin + 2)..(v68_27_origin + 3)]);
            let v83_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v83_2));
            let v83_4: Space = if map_kernels::has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v83_4));
            drop(v83_4);
            let v83_8: Space = if (&(v83_5)).is_empty() { Space::new() } else {
              let v84_7: Space = routine_16(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              map_map_kernels::compose(&(v83_5),&(v84_7))
            };
            drop(v83_5);
            let v83_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v83_2));
            drop(v83_2);
            let v83_10: Space = if map_kernels::has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
            drop(v83_9);
            let v83_12: Space = if (&(v83_10)).is_empty() { Space::new() } else {
              let v85_11: Space = routine_17(c, &v68_27_cursor.path()[v68_27_origin..(v68_27_origin + 3)], &v68_27_cursor);
              map_map_kernels::compose(&(v83_10),&(v85_11))
            };
            drop(v83_10);
            let v83_13: Space = map_map_kernels::unite(&(v83_8),&(v83_12));
            join_wrapped_into(&mut v82_7_write,&((v83_13).read_zipper()),&[]);
            }
            v68_27_cursor.ascend(1);
          }
          drop(v82_7_write);
          map_map_kernels::compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if map_kernels::has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_11: Space = map_view_kernels::compose(&(v81_10),&v68_27_cursor);
        drop(v81_10);
        let v81_12: Space = map_map_kernels::unite(&(v81_8),&(v81_11));
        drop(v81_11);
        join_wrapped_into(&mut v80_10_write,&((v81_12).read_zipper()),&[]);
        }
        v68_27_cursor.ascend(1);
      }
      drop(v80_10_write);
      map_map_kernels::compose(&(v69_9),&(v80_10))
    };
    drop(v69_9);
    let v69_12: Space = map_map_kernels::unite(&(v69_7),&(v69_11));
    join_wrapped_into(&mut v68_27_write,&((v69_12).read_zipper()),&[]);
    }
    v68_27_cursor.ascend(1);
  }
  drop(v68_27_cursor);
  drop(v68_27_write);
  drop(v68_8);
  let v68_28: Space = view_map_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v68_27));
  let mut v68_47 = Space::new();
  let mut v68_47_write = v68_47.write_zipper();
  let mut v68_47_cursor = (v68_28).read_zipper();
  let v68_47_origin = v68_47_cursor.path().len();
  for v68_47_byte in v68_47_cursor.child_mask().iter() {
    v68_47_cursor.descend_to_existing_byte(v68_47_byte);
    {
    let v86_2: Space = singleton(&v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 1)]);
    let v86_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v86_2));
    let v86_4: Space = if map_kernels::has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (&(v86_5)).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_write = v87_6.write_zipper();
      for v87_6_byte in v68_47_cursor.child_mask().iter() {
        v68_47_cursor.descend_to_existing_byte(v87_6_byte);
        {
        let v88_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 1)..(v68_47_origin + 2)]);
        let v88_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v88_2));
        let v88_4: Space = if map_kernels::has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (&(v88_5)).is_empty() { Space::new() } else {
          let mut v89_7 = Space::new();
          let mut v89_7_write = v89_7.write_zipper();
          for v89_7_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v89_7_byte);
            {
            let v90_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v90_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v90_2));
            let v90_4: Space = if map_kernels::has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
            drop(v90_3);
            let v90_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v90_4));
            drop(v90_4);
            let v90_8: Space = if (&(v90_5)).is_empty() { Space::new() } else {
              let v91_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              map_map_kernels::compose(&(v90_5),&(v91_7))
            };
            drop(v90_5);
            let v90_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v90_2));
            drop(v90_2);
            let v90_10: Space = if map_kernels::has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
            drop(v90_9);
            let v90_12: Space = if (&(v90_10)).is_empty() { Space::new() } else {
              let v92_11: Space = routine_19(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              map_map_kernels::compose(&(v90_10),&(v92_11))
            };
            drop(v90_10);
            let v90_13: Space = map_map_kernels::unite(&(v90_8),&(v90_12));
            join_wrapped_into(&mut v89_7_write,&((v90_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v89_7_write);
          map_map_kernels::compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if map_kernels::has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (&(v88_10)).is_empty() { Space::new() } else {
          let mut v93_11 = Space::new();
          let mut v93_11_write = v93_11.write_zipper();
          for v93_11_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v93_11_byte);
            {
            let v94_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v94_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v94_2));
            let v94_4: Space = if map_kernels::has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_8: Space = if (&(v94_5)).is_empty() { Space::new() } else {
              let v95_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              map_map_kernels::compose(&(v94_5),&(v95_7))
            };
            drop(v94_5);
            let v94_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v94_2));
            drop(v94_2);
            let v94_10: Space = if map_kernels::has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
            drop(v94_9);
            let v94_12: Space = if (&(v94_10)).is_empty() { Space::new() } else {
              let v96_11: Space = routine_15(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              map_map_kernels::compose(&(v94_10),&(v96_11))
            };
            drop(v94_10);
            let v94_13: Space = map_map_kernels::unite(&(v94_8),&(v94_12));
            join_wrapped_into(&mut v93_11_write,&((v94_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v93_11_write);
          map_map_kernels::compose(&(v88_10),&(v93_11))
        };
        drop(v88_10);
        let v88_13: Space = map_map_kernels::unite(&(v88_8),&(v88_12));
        join_wrapped_into(&mut v87_6_write,&((v88_13).read_zipper()),&[]);
        }
        v68_47_cursor.ascend(1);
      }
      drop(v87_6_write);
      map_map_kernels::compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if map_kernels::has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (&(v86_9)).is_empty() { Space::new() } else {
      let mut v97_10 = Space::new();
      let mut v97_10_write = v97_10.write_zipper();
      for v97_10_byte in v68_47_cursor.child_mask().iter() {
        v68_47_cursor.descend_to_existing_byte(v97_10_byte);
        {
        let v98_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 1)..(v68_47_origin + 2)]);
        let v98_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v98_2));
        let v98_4: Space = if map_kernels::has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (&(v98_5)).is_empty() { Space::new() } else {
          let mut v99_7 = Space::new();
          let mut v99_7_write = v99_7.write_zipper();
          for v99_7_byte in v68_47_cursor.child_mask().iter() {
            v68_47_cursor.descend_to_existing_byte(v99_7_byte);
            {
            let v100_2: Space = singleton(&v68_47_cursor.path()[(v68_47_origin + 2)..(v68_47_origin + 3)]);
            let v100_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v100_2));
            let v100_4: Space = if map_kernels::has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (&(v100_5)).is_empty() { Space::new() } else {
              let v101_7: Space = routine_18(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              map_map_kernels::compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if map_kernels::has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (&(v100_10)).is_empty() { Space::new() } else {
              let v102_11: Space = routine_19(c, &v68_47_cursor.path()[v68_47_origin..(v68_47_origin + 3)], &v68_47_cursor);
              map_map_kernels::compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = map_map_kernels::unite(&(v100_8),&(v100_12));
            join_wrapped_into(&mut v99_7_write,&((v100_13).read_zipper()),&[]);
            }
            v68_47_cursor.ascend(1);
          }
          drop(v99_7_write);
          map_map_kernels::compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if map_kernels::has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_11: Space = map_view_kernels::compose(&(v98_10),&v68_47_cursor);
        drop(v98_10);
        let v98_12: Space = map_map_kernels::unite(&(v98_8),&(v98_11));
        drop(v98_11);
        join_wrapped_into(&mut v97_10_write,&((v98_12).read_zipper()),&[]);
        }
        v68_47_cursor.ascend(1);
      }
      drop(v97_10_write);
      map_map_kernels::compose(&(v86_9),&(v97_10))
    };
    drop(v86_9);
    let v86_12: Space = map_map_kernels::unite(&(v86_7),&(v86_11));
    join_wrapped_into(&mut v68_47_write,&((v86_12).read_zipper()),&[]);
    }
    v68_47_cursor.ascend(1);
  }
  drop(v68_47_cursor);
  drop(v68_47_write);
  let v68_48: Space = map_view_kernels::subtract(&(v68_47),&(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0))));
  let v68_51: Space = map_view_kernels::intersect(&(v68_48),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
  let v68_52: Space = map_kernels::wrap(&(v68_51),&(*p0));
  (v68_52).clone()
}

fn routine_4(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v103_34 = Space::new();
  let mut v103_34_write = v103_34.write_zipper();
  let mut v103_34_cursor = (*s0).read_zipper();
  let v103_34_origin = v103_34_cursor.path().len();
  for v103_34_byte in v103_34_cursor.child_mask().iter() {
    v103_34_cursor.descend_to_existing_byte(v103_34_byte);
    {
    let v104_2: Space = singleton(&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]);
    let v104_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v104_2));
    let v104_4: Space = if map_kernels::has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_8: Space = if (&(v104_5)).is_empty() { Space::new() } else {
      let v105_6: Path = concat_path(&(*p0),&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]);
      let mut v105_7 = Space::new();
      let mut v105_7_write = v105_7.write_zipper();
      for v105_7_byte in v103_34_cursor.child_mask().iter() {
        v103_34_cursor.descend_to_existing_byte(v105_7_byte);
        {
        let v106_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
        let v106_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v106_2));
        let v106_4: Space = if map_kernels::has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v106_4));
        drop(v106_4);
        let v106_8: Space = if (&(v106_5)).is_empty() { Space::new() } else {
          let v107_6: Path = concat_path(&(v105_6),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
          let mut v107_7 = Space::new();
          let mut v107_7_write = v107_7.write_zipper();
          for v107_7_byte in v103_34_cursor.child_mask().iter() {
            v103_34_cursor.descend_to_existing_byte(v107_7_byte);
            {
            let v108_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
            let v108_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v108_2));
            let v108_4: Space = if map_kernels::has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
            drop(v108_3);
            let v108_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v108_4));
            drop(v108_4);
            let v108_8: Space = if (&(v108_5)).is_empty() { Space::new() } else {
              let v109_6: Path = concat_path(&(v107_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v109_7: Space = routine_20(c, &(v109_6), &v103_34_cursor, &(*s1));
              map_map_kernels::compose(&(v108_5),&(v109_7))
            };
            drop(v108_5);
            let v108_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v108_2));
            drop(v108_2);
            let v108_10: Space = if map_kernels::has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
            drop(v108_9);
            let v108_12: Space = if (&(v108_10)).is_empty() { Space::new() } else {
              let v110_6: Path = concat_path(&(v107_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v110_11: Space = routine_21(c, &(v110_6), &v103_34_cursor, &(*s1));
              drop(v110_6);
              map_map_kernels::compose(&(v108_10),&(v110_11))
            };
            drop(v108_10);
            let v108_13: Space = map_map_kernels::unite(&(v108_8),&(v108_12));
            join_wrapped_into(&mut v107_7_write,&((v108_13).read_zipper()),&[]);
            }
            v103_34_cursor.ascend(1);
          }
          drop(v107_7_write);
          map_map_kernels::compose(&(v106_5),&(v107_7))
        };
        drop(v106_5);
        let v106_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v106_2));
        drop(v106_2);
        let v106_10: Space = if map_kernels::has_head(&(v106_9)) { singleton(&[]) } else { Space::new() };
        drop(v106_9);
        let v106_12: Space = if (&(v106_10)).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v105_6),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
          let mut v111_11 = Space::new();
          let mut v111_11_write = v111_11.write_zipper();
          for v111_11_byte in v103_34_cursor.child_mask().iter() {
            v103_34_cursor.descend_to_existing_byte(v111_11_byte);
            {
            let v112_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
            let v112_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v112_2));
            let v112_4: Space = if map_kernels::has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
            drop(v112_3);
            let v112_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v112_4));
            drop(v112_4);
            let v112_8: Space = if (&(v112_5)).is_empty() { Space::new() } else {
              let v113_6: Path = concat_path(&(v111_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v113_7: Space = routine_20(c, &(v113_6), &v103_34_cursor, &(*s1));
              map_map_kernels::compose(&(v112_5),&(v113_7))
            };
            drop(v112_5);
            let v112_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v112_2));
            drop(v112_2);
            let v112_10: Space = if map_kernels::has_head(&(v112_9)) { singleton(&[]) } else { Space::new() };
            drop(v112_9);
            let v112_12: Space = if (&(v112_10)).is_empty() { Space::new() } else {
              let v114_6: Path = concat_path(&(v111_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v114_11: Space = routine_3(c, &(v114_6), &v103_34_cursor, &(*s1));
              drop(v114_6);
              map_map_kernels::compose(&(v112_10),&(v114_11))
            };
            drop(v112_10);
            let v112_13: Space = map_map_kernels::unite(&(v112_8),&(v112_12));
            join_wrapped_into(&mut v111_11_write,&((v112_13).read_zipper()),&[]);
            }
            v103_34_cursor.ascend(1);
          }
          drop(v111_11_write);
          drop(v111_6);
          map_map_kernels::compose(&(v106_10),&(v111_11))
        };
        drop(v106_10);
        let v106_13: Space = map_map_kernels::unite(&(v106_8),&(v106_12));
        join_wrapped_into(&mut v105_7_write,&((v106_13).read_zipper()),&[]);
        }
        v103_34_cursor.ascend(1);
      }
      drop(v105_7_write);
      map_map_kernels::compose(&(v104_5),&(v105_7))
    };
    drop(v104_5);
    let v104_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_10: Space = if map_kernels::has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
    drop(v104_9);
    let v104_13: Space = if (&(v104_10)).is_empty() { Space::new() } else {
      let v115_6: Path = concat_path(&(*p0),&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]);
      let mut v115_12 = Space::new();
      let mut v115_12_write = v115_12.write_zipper();
      for v115_12_byte in v103_34_cursor.child_mask().iter() {
        v103_34_cursor.descend_to_existing_byte(v115_12_byte);
        {
        let v116_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
        let v116_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v116_2));
        let v116_4: Space = if map_kernels::has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
        drop(v116_3);
        let v116_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v116_4));
        drop(v116_4);
        let v116_8: Space = if (&(v116_5)).is_empty() { Space::new() } else {
          let v117_6: Path = concat_path(&(v115_6),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
          let mut v117_7 = Space::new();
          let mut v117_7_write = v117_7.write_zipper();
          for v117_7_byte in v103_34_cursor.child_mask().iter() {
            v103_34_cursor.descend_to_existing_byte(v117_7_byte);
            {
            let v118_2: Space = singleton(&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
            let v118_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v118_2));
            let v118_4: Space = if map_kernels::has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
            drop(v118_3);
            let v118_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v118_4));
            drop(v118_4);
            let v118_8: Space = if (&(v118_5)).is_empty() { Space::new() } else {
              let v119_6: Path = concat_path(&(v117_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v119_7: Space = routine_20(c, &(v119_6), &v103_34_cursor, &(*s1));
              map_map_kernels::compose(&(v118_5),&(v119_7))
            };
            drop(v118_5);
            let v118_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v118_2));
            drop(v118_2);
            let v118_10: Space = if map_kernels::has_head(&(v118_9)) { singleton(&[]) } else { Space::new() };
            drop(v118_9);
            let v118_12: Space = if (&(v118_10)).is_empty() { Space::new() } else {
              let v120_6: Path = concat_path(&(v117_6),&v103_34_cursor.path()[(v103_34_origin + 2)..(v103_34_origin + 3)]);
              let v120_11: Space = routine_21(c, &(v120_6), &v103_34_cursor, &(*s1));
              drop(v120_6);
              map_map_kernels::compose(&(v118_10),&(v120_11))
            };
            drop(v118_10);
            let v118_13: Space = map_map_kernels::unite(&(v118_8),&(v118_12));
            join_wrapped_into(&mut v117_7_write,&((v118_13).read_zipper()),&[]);
            }
            v103_34_cursor.ascend(1);
          }
          drop(v117_7_write);
          map_map_kernels::compose(&(v116_5),&(v117_7))
        };
        drop(v116_5);
        let v116_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v116_2));
        drop(v116_2);
        let v116_10: Space = if map_kernels::has_head(&(v116_9)) { singleton(&[]) } else { Space::new() };
        drop(v116_9);
        let v116_18: Space = if (&(v116_10)).is_empty() { Space::new() } else {
          let v121_12: Space = view_view_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)])));
          let mut v121_13 = Space::new();
          let mut v121_13_write = v121_13.write_zipper();
          let mut v121_13_cursor = (v121_12).read_zipper();
          let v121_13_origin = v121_13_cursor.path().len();
          for v121_13_byte in v121_13_cursor.child_mask().iter() {
            v121_13_cursor.descend_to_existing_byte(v121_13_byte);
            {
            let v122_2: Space = singleton(&v121_13_cursor.path()[v121_13_origin..(v121_13_origin + 1)]);
            let v122_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v122_2));
            let v122_4: Space = if map_kernels::has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
            drop(v122_3);
            let v122_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v122_4));
            drop(v122_4);
            let v122_7: Space = if (&(v122_5)).is_empty() { Space::new() } else {
              let v123_6: Space = routine_6(c, &v121_13_cursor.path()[v121_13_origin..(v121_13_origin + 1)], &v121_13_cursor);
              map_map_kernels::compose(&(v122_5),&(v123_6))
            };
            drop(v122_5);
            let v122_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v122_2));
            drop(v122_2);
            let v122_9: Space = if map_kernels::has_head(&(v122_8)) { singleton(&[]) } else { Space::new() };
            drop(v122_8);
            let v122_11: Space = if (&(v122_9)).is_empty() { Space::new() } else {
              let v124_10: Space = routine_7(c, &v121_13_cursor.path()[v121_13_origin..(v121_13_origin + 1)], &v121_13_cursor);
              map_map_kernels::compose(&(v122_9),&(v124_10))
            };
            drop(v122_9);
            let v122_12: Space = map_map_kernels::unite(&(v122_7),&(v122_11));
            join_wrapped_into(&mut v121_13_write,&((v122_12).read_zipper()),&[]);
            }
            v121_13_cursor.ascend(1);
          }
          drop(v121_13_cursor);
          drop(v121_13_write);
          drop(v121_12);
          let v121_14: Space = view_map_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v121_13));
          let mut v121_15 = Space::new();
          let mut v121_15_write = v121_15.write_zipper();
          let mut v121_15_cursor = (v121_14).read_zipper();
          let v121_15_origin = v121_15_cursor.path().len();
          for v121_15_byte in v121_15_cursor.child_mask().iter() {
            v121_15_cursor.descend_to_existing_byte(v121_15_byte);
            {
            let v125_2: Space = singleton(&v121_15_cursor.path()[v121_15_origin..(v121_15_origin + 1)]);
            let v125_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v125_2));
            let v125_4: Space = if map_kernels::has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v125_4));
            drop(v125_4);
            let v125_7: Space = if (&(v125_5)).is_empty() { Space::new() } else {
              let v126_6: Space = routine_8(c, &v121_15_cursor.path()[v121_15_origin..(v121_15_origin + 1)], &v121_15_cursor);
              map_map_kernels::compose(&(v125_5),&(v126_6))
            };
            drop(v125_5);
            let v125_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v125_2));
            drop(v125_2);
            let v125_9: Space = if map_kernels::has_head(&(v125_8)) { singleton(&[]) } else { Space::new() };
            drop(v125_8);
            let v125_11: Space = if (&(v125_9)).is_empty() { Space::new() } else {
              let v127_10: Space = routine_9(c, &v121_15_cursor.path()[v121_15_origin..(v121_15_origin + 1)], &v121_15_cursor);
              map_map_kernels::compose(&(v125_9),&(v127_10))
            };
            drop(v125_9);
            let v125_12: Space = map_map_kernels::unite(&(v125_7),&(v125_11));
            join_wrapped_into(&mut v121_15_write,&((v125_12).read_zipper()),&[]);
            }
            v121_15_cursor.ascend(1);
          }
          drop(v121_15_cursor);
          drop(v121_15_write);
          let v121_16: Space = map_view_kernels::subtract(&(v121_15),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v103_34_cursor.path()[v103_34_origin..(v103_34_origin + 1)]),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)])));
          let v121_17: Space = map_view_kernels::intersect(&(v121_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
          map_map_kernels::compose(&(v116_10),&(v121_17))
        };
        drop(v116_10);
        let v128_6: Path = concat_path(&(v115_6),&v103_34_cursor.path()[(v103_34_origin + 1)..(v103_34_origin + 2)]);
        let v116_19: Space = map_kernels::wrap(&(v116_18),&(v128_6));
        let v116_20: Space = map_map_kernels::unite(&(v116_8),&(v116_19));
        join_wrapped_into(&mut v115_12_write,&((v116_20).read_zipper()),&[]);
        }
        v103_34_cursor.ascend(1);
      }
      drop(v115_12_write);
      drop(v115_6);
      map_map_kernels::compose(&(v104_10),&(v115_12))
    };
    drop(v104_10);
    let v104_14: Space = map_map_kernels::unite(&(v104_8),&(v104_13));
    join_wrapped_into(&mut v103_34_write,&((v104_14).read_zipper()),&[]);
    }
    v103_34_cursor.ascend(1);
  }
  drop(v103_34_cursor);
  drop(v103_34_write);
  (v103_34).clone()
}

fn routine_5(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v129_40 = Space::new();
  let mut v129_40_write = v129_40.write_zipper();
  let mut v129_40_cursor = (*s0).read_zipper();
  let v129_40_origin = v129_40_cursor.path().len();
  for v129_40_byte in v129_40_cursor.child_mask().iter() {
    v129_40_cursor.descend_to_existing_byte(v129_40_byte);
    {
    let v130_2: Space = singleton(&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)]);
    let v130_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v130_2));
    let v130_4: Space = if map_kernels::has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
    drop(v130_3);
    let v130_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v130_4));
    drop(v130_4);
    let v130_8: Space = if (&(v130_5)).is_empty() { Space::new() } else {
      let v131_6: Path = concat_path(&(*p0),&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)]);
      let mut v131_7 = Space::new();
      let mut v131_7_write = v131_7.write_zipper();
      for v131_7_byte in v129_40_cursor.child_mask().iter() {
        v129_40_cursor.descend_to_existing_byte(v131_7_byte);
        {
        let v132_2: Space = singleton(&v129_40_cursor.path()[(v129_40_origin + 1)..(v129_40_origin + 2)]);
        let v132_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v132_2));
        let v132_4: Space = if map_kernels::has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
        drop(v132_3);
        let v132_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v132_4));
        drop(v132_4);
        let v132_8: Space = if (&(v132_5)).is_empty() { Space::new() } else {
          let v133_6: Path = concat_path(&(v131_6),&v129_40_cursor.path()[(v129_40_origin + 1)..(v129_40_origin + 2)]);
          let mut v133_7 = Space::new();
          let mut v133_7_write = v133_7.write_zipper();
          for v133_7_byte in v129_40_cursor.child_mask().iter() {
            v129_40_cursor.descend_to_existing_byte(v133_7_byte);
            {
            let v134_2: Space = singleton(&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
            let v134_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v134_2));
            let v134_4: Space = if map_kernels::has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
            drop(v134_3);
            let v134_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v134_4));
            drop(v134_4);
            let v134_8: Space = if (&(v134_5)).is_empty() { Space::new() } else {
              let v135_6: Path = concat_path(&(v133_6),&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
              let v135_7: Space = routine_20(c, &(v135_6), &v129_40_cursor, &(*s1));
              map_map_kernels::compose(&(v134_5),&(v135_7))
            };
            drop(v134_5);
            let v134_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v134_2));
            drop(v134_2);
            let v134_10: Space = if map_kernels::has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
            drop(v134_9);
            let v134_12: Space = if (&(v134_10)).is_empty() { Space::new() } else {
              let v136_6: Path = concat_path(&(v133_6),&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
              let v136_11: Space = routine_21(c, &(v136_6), &v129_40_cursor, &(*s1));
              drop(v136_6);
              map_map_kernels::compose(&(v134_10),&(v136_11))
            };
            drop(v134_10);
            let v134_13: Space = map_map_kernels::unite(&(v134_8),&(v134_12));
            join_wrapped_into(&mut v133_7_write,&((v134_13).read_zipper()),&[]);
            }
            v129_40_cursor.ascend(1);
          }
          drop(v133_7_write);
          map_map_kernels::compose(&(v132_5),&(v133_7))
        };
        drop(v132_5);
        let v132_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v132_2));
        drop(v132_2);
        let v132_10: Space = if map_kernels::has_head(&(v132_9)) { singleton(&[]) } else { Space::new() };
        drop(v132_9);
        let v132_12: Space = if (&(v132_10)).is_empty() { Space::new() } else {
          let v137_6: Path = concat_path(&(v131_6),&v129_40_cursor.path()[(v129_40_origin + 1)..(v129_40_origin + 2)]);
          let mut v137_11 = Space::new();
          let mut v137_11_write = v137_11.write_zipper();
          for v137_11_byte in v129_40_cursor.child_mask().iter() {
            v129_40_cursor.descend_to_existing_byte(v137_11_byte);
            {
            let v138_2: Space = singleton(&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
            let v138_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v138_2));
            let v138_4: Space = if map_kernels::has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
            drop(v138_3);
            let v138_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v138_4));
            drop(v138_4);
            let v138_8: Space = if (&(v138_5)).is_empty() { Space::new() } else {
              let v139_6: Path = concat_path(&(v137_6),&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
              let v139_7: Space = routine_20(c, &(v139_6), &v129_40_cursor, &(*s1));
              map_map_kernels::compose(&(v138_5),&(v139_7))
            };
            drop(v138_5);
            let v138_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v138_2));
            drop(v138_2);
            let v138_10: Space = if map_kernels::has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
            drop(v138_9);
            let v138_12: Space = if (&(v138_10)).is_empty() { Space::new() } else {
              let v140_6: Path = concat_path(&(v137_6),&v129_40_cursor.path()[(v129_40_origin + 2)..(v129_40_origin + 3)]);
              let v140_11: Space = routine_3(c, &(v140_6), &v129_40_cursor, &(*s1));
              drop(v140_6);
              map_map_kernels::compose(&(v138_10),&(v140_11))
            };
            drop(v138_10);
            let v138_13: Space = map_map_kernels::unite(&(v138_8),&(v138_12));
            join_wrapped_into(&mut v137_11_write,&((v138_13).read_zipper()),&[]);
            }
            v129_40_cursor.ascend(1);
          }
          drop(v137_11_write);
          drop(v137_6);
          map_map_kernels::compose(&(v132_10),&(v137_11))
        };
        drop(v132_10);
        let v132_13: Space = map_map_kernels::unite(&(v132_8),&(v132_12));
        join_wrapped_into(&mut v131_7_write,&((v132_13).read_zipper()),&[]);
        }
        v129_40_cursor.ascend(1);
      }
      drop(v131_7_write);
      map_map_kernels::compose(&(v130_5),&(v131_7))
    };
    drop(v130_5);
    let v130_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v130_2));
    drop(v130_2);
    let v130_10: Space = if map_kernels::has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
    drop(v130_9);
    let v130_18: Space = if (&(v130_10)).is_empty() { Space::new() } else {
      let v141_12: Space = view_view_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)])));
      let mut v141_13 = Space::new();
      let mut v141_13_write = v141_13.write_zipper();
      let mut v141_13_cursor = (v141_12).read_zipper();
      let v141_13_origin = v141_13_cursor.path().len();
      for v141_13_byte in v141_13_cursor.child_mask().iter() {
        v141_13_cursor.descend_to_existing_byte(v141_13_byte);
        {
        let v142_2: Space = singleton(&v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 1)]);
        let v142_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v142_2));
        let v142_4: Space = if map_kernels::has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
        drop(v142_3);
        let v142_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v142_4));
        drop(v142_4);
        let v142_7: Space = if (&(v142_5)).is_empty() { Space::new() } else {
          let mut v143_6 = Space::new();
          let mut v143_6_write = v143_6.write_zipper();
          for v143_6_byte in v141_13_cursor.child_mask().iter() {
            v141_13_cursor.descend_to_existing_byte(v143_6_byte);
            {
            let v144_2: Space = singleton(&v141_13_cursor.path()[(v141_13_origin + 1)..(v141_13_origin + 2)]);
            let v144_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v144_2));
            let v144_4: Space = if map_kernels::has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
            drop(v144_3);
            let v144_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v144_4));
            drop(v144_4);
            let v144_8: Space = if (&(v144_5)).is_empty() { Space::new() } else {
              let v145_7: Space = routine_10(c, &v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 2)], &v141_13_cursor);
              map_map_kernels::compose(&(v144_5),&(v145_7))
            };
            drop(v144_5);
            let v144_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v144_2));
            drop(v144_2);
            let v144_10: Space = if map_kernels::has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
            drop(v144_9);
            let v144_12: Space = if (&(v144_10)).is_empty() { Space::new() } else {
              let v146_11: Space = routine_11(c, &v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 2)], &v141_13_cursor);
              map_map_kernels::compose(&(v144_10),&(v146_11))
            };
            drop(v144_10);
            let v144_13: Space = map_map_kernels::unite(&(v144_8),&(v144_12));
            join_wrapped_into(&mut v143_6_write,&((v144_13).read_zipper()),&[]);
            }
            v141_13_cursor.ascend(1);
          }
          drop(v143_6_write);
          map_map_kernels::compose(&(v142_5),&(v143_6))
        };
        drop(v142_5);
        let v142_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v142_2));
        drop(v142_2);
        let v142_9: Space = if map_kernels::has_head(&(v142_8)) { singleton(&[]) } else { Space::new() };
        drop(v142_8);
        let v142_11: Space = if (&(v142_9)).is_empty() { Space::new() } else {
          let mut v147_10 = Space::new();
          let mut v147_10_write = v147_10.write_zipper();
          for v147_10_byte in v141_13_cursor.child_mask().iter() {
            v141_13_cursor.descend_to_existing_byte(v147_10_byte);
            {
            let v148_2: Space = singleton(&v141_13_cursor.path()[(v141_13_origin + 1)..(v141_13_origin + 2)]);
            let v148_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v148_2));
            let v148_4: Space = if map_kernels::has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
            drop(v148_3);
            let v148_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v148_4));
            drop(v148_4);
            let v148_8: Space = if (&(v148_5)).is_empty() { Space::new() } else {
              let v149_7: Space = routine_10(c, &v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 2)], &v141_13_cursor);
              map_map_kernels::compose(&(v148_5),&(v149_7))
            };
            drop(v148_5);
            let v148_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v148_2));
            drop(v148_2);
            let v148_10: Space = if map_kernels::has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
            drop(v148_9);
            let v148_12: Space = if (&(v148_10)).is_empty() { Space::new() } else {
              let v150_11: Space = routine_12(c, &v141_13_cursor.path()[v141_13_origin..(v141_13_origin + 2)], &v141_13_cursor);
              map_map_kernels::compose(&(v148_10),&(v150_11))
            };
            drop(v148_10);
            let v148_13: Space = map_map_kernels::unite(&(v148_8),&(v148_12));
            join_wrapped_into(&mut v147_10_write,&((v148_13).read_zipper()),&[]);
            }
            v141_13_cursor.ascend(1);
          }
          drop(v147_10_write);
          map_map_kernels::compose(&(v142_9),&(v147_10))
        };
        drop(v142_9);
        let v142_12: Space = map_map_kernels::unite(&(v142_7),&(v142_11));
        join_wrapped_into(&mut v141_13_write,&((v142_12).read_zipper()),&[]);
        }
        v141_13_cursor.ascend(1);
      }
      drop(v141_13_cursor);
      drop(v141_13_write);
      drop(v141_12);
      let v141_14: Space = view_map_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v141_13));
      let mut v141_15 = Space::new();
      let mut v141_15_write = v141_15.write_zipper();
      let mut v141_15_cursor = (v141_14).read_zipper();
      let v141_15_origin = v141_15_cursor.path().len();
      for v141_15_byte in v141_15_cursor.child_mask().iter() {
        v141_15_cursor.descend_to_existing_byte(v141_15_byte);
        {
        let v151_2: Space = singleton(&v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 1)]);
        let v151_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v151_2));
        let v151_4: Space = if map_kernels::has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
        drop(v151_3);
        let v151_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v151_4));
        drop(v151_4);
        let v151_7: Space = if (&(v151_5)).is_empty() { Space::new() } else {
          let mut v152_6 = Space::new();
          let mut v152_6_write = v152_6.write_zipper();
          for v152_6_byte in v141_15_cursor.child_mask().iter() {
            v141_15_cursor.descend_to_existing_byte(v152_6_byte);
            {
            let v153_2: Space = singleton(&v141_15_cursor.path()[(v141_15_origin + 1)..(v141_15_origin + 2)]);
            let v153_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v153_2));
            let v153_4: Space = if map_kernels::has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
            drop(v153_3);
            let v153_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v153_4));
            drop(v153_4);
            let v153_8: Space = if (&(v153_5)).is_empty() { Space::new() } else {
              let v154_7: Space = routine_13(c, &v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 2)], &v141_15_cursor);
              map_map_kernels::compose(&(v153_5),&(v154_7))
            };
            drop(v153_5);
            let v153_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v153_2));
            drop(v153_2);
            let v153_10: Space = if map_kernels::has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
            drop(v153_9);
            let v153_12: Space = if (&(v153_10)).is_empty() { Space::new() } else {
              let v155_11: Space = routine_14(c, &v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 2)], &v141_15_cursor);
              map_map_kernels::compose(&(v153_10),&(v155_11))
            };
            drop(v153_10);
            let v153_13: Space = map_map_kernels::unite(&(v153_8),&(v153_12));
            join_wrapped_into(&mut v152_6_write,&((v153_13).read_zipper()),&[]);
            }
            v141_15_cursor.ascend(1);
          }
          drop(v152_6_write);
          map_map_kernels::compose(&(v151_5),&(v152_6))
        };
        drop(v151_5);
        let v151_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v151_2));
        drop(v151_2);
        let v151_9: Space = if map_kernels::has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
        drop(v151_8);
        let v151_11: Space = if (&(v151_9)).is_empty() { Space::new() } else {
          let mut v156_10 = Space::new();
          let mut v156_10_write = v156_10.write_zipper();
          for v156_10_byte in v141_15_cursor.child_mask().iter() {
            v141_15_cursor.descend_to_existing_byte(v156_10_byte);
            {
            let v157_2: Space = singleton(&v141_15_cursor.path()[(v141_15_origin + 1)..(v141_15_origin + 2)]);
            let v157_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v157_2));
            let v157_4: Space = if map_kernels::has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
            drop(v157_3);
            let v157_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v157_4));
            drop(v157_4);
            let v157_8: Space = if (&(v157_5)).is_empty() { Space::new() } else {
              let v158_7: Space = routine_13(c, &v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 2)], &v141_15_cursor);
              map_map_kernels::compose(&(v157_5),&(v158_7))
            };
            drop(v157_5);
            let v157_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v157_2));
            drop(v157_2);
            let v157_10: Space = if map_kernels::has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
            drop(v157_9);
            let v157_12: Space = if (&(v157_10)).is_empty() { Space::new() } else {
              let v159_11: Space = routine_15(c, &v141_15_cursor.path()[v141_15_origin..(v141_15_origin + 2)], &v141_15_cursor);
              map_map_kernels::compose(&(v157_10),&(v159_11))
            };
            drop(v157_10);
            let v157_13: Space = map_map_kernels::unite(&(v157_8),&(v157_12));
            join_wrapped_into(&mut v156_10_write,&((v157_13).read_zipper()),&[]);
            }
            v141_15_cursor.ascend(1);
          }
          drop(v156_10_write);
          map_map_kernels::compose(&(v151_9),&(v156_10))
        };
        drop(v151_9);
        let v151_12: Space = map_map_kernels::unite(&(v151_7),&(v151_11));
        join_wrapped_into(&mut v141_15_write,&((v151_12).read_zipper()),&[]);
        }
        v141_15_cursor.ascend(1);
      }
      drop(v141_15_cursor);
      drop(v141_15_write);
      let v141_16: Space = map_view_kernels::subtract(&(v141_15),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)])));
      let v141_17: Space = map_view_kernels::intersect(&(v141_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      map_map_kernels::compose(&(v130_10),&(v141_17))
    };
    drop(v130_10);
    let v160_6: Path = concat_path(&(*p0),&v129_40_cursor.path()[v129_40_origin..(v129_40_origin + 1)]);
    let v130_19: Space = map_kernels::wrap(&(v130_18),&(v160_6));
    let v130_20: Space = map_map_kernels::unite(&(v130_8),&(v130_19));
    join_wrapped_into(&mut v129_40_write,&((v130_20).read_zipper()),&[]);
    }
    v129_40_cursor.ascend(1);
  }
  drop(v129_40_cursor);
  drop(v129_40_write);
  (v129_40).clone()
}

fn routine_6(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v161_20 = Space::new();
  let mut v161_20_write = v161_20.write_zipper();
  let mut v161_20_cursor = (*s0).read_zipper();
  let v161_20_origin = v161_20_cursor.path().len();
  for v161_20_byte in v161_20_cursor.child_mask().iter() {
    v161_20_cursor.descend_to_existing_byte(v161_20_byte);
    {
    let v162_2: Space = singleton(&v161_20_cursor.path()[v161_20_origin..(v161_20_origin + 1)]);
    let v162_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v162_2));
    let v162_4: Space = if map_kernels::has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
    drop(v162_3);
    let v162_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v162_4));
    drop(v162_4);
    let v162_8: Space = if (&(v162_5)).is_empty() { Space::new() } else {
      let v163_6: Path = concat_path(&(*p0),&v161_20_cursor.path()[v161_20_origin..(v161_20_origin + 1)]);
      let mut v163_7 = Space::new();
      let mut v163_7_write = v163_7.write_zipper();
      for v163_7_byte in v161_20_cursor.child_mask().iter() {
        v161_20_cursor.descend_to_existing_byte(v163_7_byte);
        {
        let v164_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
        let v164_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v164_2));
        let v164_4: Space = if map_kernels::has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
        drop(v164_3);
        let v164_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v164_4));
        drop(v164_4);
        let v164_8: Space = if (&(v164_5)).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v163_6),&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
          let mut v165_7 = Space::new();
          let mut v165_7_write = v165_7.write_zipper();
          for v165_7_byte in v161_20_cursor.child_mask().iter() {
            v161_20_cursor.descend_to_existing_byte(v165_7_byte);
            {
            let v166_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
            let v166_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v166_2));
            let v166_4: Space = if map_kernels::has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
            drop(v166_3);
            let v166_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v166_4));
            drop(v166_4);
            let v166_8: Space = if (&(v166_5)).is_empty() { Space::new() } else {
              let v167_6: Path = concat_path(&(v165_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v167_7: Space = routine_22(c, &(v167_6), &v161_20_cursor);
              map_map_kernels::compose(&(v166_5),&(v167_7))
            };
            drop(v166_5);
            let v166_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v166_2));
            drop(v166_2);
            let v166_10: Space = if map_kernels::has_head(&(v166_9)) { singleton(&[]) } else { Space::new() };
            drop(v166_9);
            let v166_12: Space = if (&(v166_10)).is_empty() { Space::new() } else {
              let v168_6: Path = concat_path(&(v165_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v168_11: Space = routine_23(c, &(v168_6), &v161_20_cursor);
              drop(v168_6);
              map_map_kernels::compose(&(v166_10),&(v168_11))
            };
            drop(v166_10);
            let v166_13: Space = map_map_kernels::unite(&(v166_8),&(v166_12));
            join_wrapped_into(&mut v165_7_write,&((v166_13).read_zipper()),&[]);
            }
            v161_20_cursor.ascend(1);
          }
          drop(v165_7_write);
          map_map_kernels::compose(&(v164_5),&(v165_7))
        };
        drop(v164_5);
        let v164_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v164_2));
        drop(v164_2);
        let v164_10: Space = if map_kernels::has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
        drop(v164_9);
        let v164_12: Space = if (&(v164_10)).is_empty() { Space::new() } else {
          let v169_6: Path = concat_path(&(v163_6),&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
          let mut v169_11 = Space::new();
          let mut v169_11_write = v169_11.write_zipper();
          for v169_11_byte in v161_20_cursor.child_mask().iter() {
            v161_20_cursor.descend_to_existing_byte(v169_11_byte);
            {
            let v170_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
            let v170_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v170_2));
            let v170_4: Space = if map_kernels::has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
            drop(v170_3);
            let v170_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v170_4));
            drop(v170_4);
            let v170_8: Space = if (&(v170_5)).is_empty() { Space::new() } else {
              let v171_6: Path = concat_path(&(v169_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v171_7: Space = routine_22(c, &(v171_6), &v161_20_cursor);
              map_map_kernels::compose(&(v170_5),&(v171_7))
            };
            drop(v170_5);
            let v170_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v170_2));
            drop(v170_2);
            let v170_10: Space = if map_kernels::has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
            drop(v170_9);
            let v170_12: Space = if (&(v170_10)).is_empty() { Space::new() } else {
              let v172_6: Path = concat_path(&(v169_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v172_11: Space = routine_12(c, &(v172_6), &v161_20_cursor);
              drop(v172_6);
              map_map_kernels::compose(&(v170_10),&(v172_11))
            };
            drop(v170_10);
            let v170_13: Space = map_map_kernels::unite(&(v170_8),&(v170_12));
            join_wrapped_into(&mut v169_11_write,&((v170_13).read_zipper()),&[]);
            }
            v161_20_cursor.ascend(1);
          }
          drop(v169_11_write);
          drop(v169_6);
          map_map_kernels::compose(&(v164_10),&(v169_11))
        };
        drop(v164_10);
        let v164_13: Space = map_map_kernels::unite(&(v164_8),&(v164_12));
        join_wrapped_into(&mut v163_7_write,&((v164_13).read_zipper()),&[]);
        }
        v161_20_cursor.ascend(1);
      }
      drop(v163_7_write);
      map_map_kernels::compose(&(v162_5),&(v163_7))
    };
    drop(v162_5);
    let v162_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v162_2));
    drop(v162_2);
    let v162_10: Space = if map_kernels::has_head(&(v162_9)) { singleton(&[]) } else { Space::new() };
    drop(v162_9);
    let v162_12: Space = if (&(v162_10)).is_empty() { Space::new() } else {
      let v173_6: Path = concat_path(&(*p0),&v161_20_cursor.path()[v161_20_origin..(v161_20_origin + 1)]);
      let mut v173_11 = Space::new();
      let mut v173_11_write = v173_11.write_zipper();
      for v173_11_byte in v161_20_cursor.child_mask().iter() {
        v161_20_cursor.descend_to_existing_byte(v173_11_byte);
        {
        let v174_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
        let v174_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v174_2));
        let v174_4: Space = if map_kernels::has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
        drop(v174_3);
        let v174_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v174_4));
        drop(v174_4);
        let v174_8: Space = if (&(v174_5)).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v173_6),&v161_20_cursor.path()[(v161_20_origin + 1)..(v161_20_origin + 2)]);
          let mut v175_7 = Space::new();
          let mut v175_7_write = v175_7.write_zipper();
          for v175_7_byte in v161_20_cursor.child_mask().iter() {
            v161_20_cursor.descend_to_existing_byte(v175_7_byte);
            {
            let v176_2: Space = singleton(&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
            let v176_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v176_2));
            let v176_4: Space = if map_kernels::has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
            drop(v176_3);
            let v176_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v176_4));
            drop(v176_4);
            let v176_8: Space = if (&(v176_5)).is_empty() { Space::new() } else {
              let v177_6: Path = concat_path(&(v175_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v177_7: Space = routine_22(c, &(v177_6), &v161_20_cursor);
              map_map_kernels::compose(&(v176_5),&(v177_7))
            };
            drop(v176_5);
            let v176_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v176_2));
            drop(v176_2);
            let v176_10: Space = if map_kernels::has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
            drop(v176_9);
            let v176_12: Space = if (&(v176_10)).is_empty() { Space::new() } else {
              let v178_6: Path = concat_path(&(v175_6),&v161_20_cursor.path()[(v161_20_origin + 2)..(v161_20_origin + 3)]);
              let v178_11: Space = routine_23(c, &(v178_6), &v161_20_cursor);
              drop(v178_6);
              map_map_kernels::compose(&(v176_10),&(v178_11))
            };
            drop(v176_10);
            let v176_13: Space = map_map_kernels::unite(&(v176_8),&(v176_12));
            join_wrapped_into(&mut v175_7_write,&((v176_13).read_zipper()),&[]);
            }
            v161_20_cursor.ascend(1);
          }
          drop(v175_7_write);
          drop(v175_6);
          map_map_kernels::compose(&(v174_5),&(v175_7))
        };
        drop(v174_5);
        let v174_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v174_2));
        drop(v174_2);
        let v174_10: Space = if map_kernels::has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
        drop(v174_9);
        let v174_11: Space = map_view_kernels::compose(&(v174_10),&v161_20_cursor);
        drop(v174_10);
        let v174_12: Space = map_map_kernels::unite(&(v174_8),&(v174_11));
        drop(v174_11);
        join_wrapped_into(&mut v173_11_write,&((v174_12).read_zipper()),&[]);
        }
        v161_20_cursor.ascend(1);
      }
      drop(v173_11_write);
      drop(v173_6);
      map_map_kernels::compose(&(v162_10),&(v173_11))
    };
    drop(v162_10);
    let v162_13: Space = map_map_kernels::unite(&(v162_8),&(v162_12));
    join_wrapped_into(&mut v161_20_write,&((v162_13).read_zipper()),&[]);
    }
    v161_20_cursor.ascend(1);
  }
  drop(v161_20_cursor);
  drop(v161_20_write);
  (v161_20).clone()
}

fn routine_7(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v179_14 = Space::new();
  let mut v179_14_write = v179_14.write_zipper();
  let mut v179_14_cursor = (*s0).read_zipper();
  let v179_14_origin = v179_14_cursor.path().len();
  for v179_14_byte in v179_14_cursor.child_mask().iter() {
    v179_14_cursor.descend_to_existing_byte(v179_14_byte);
    {
    let v180_2: Space = singleton(&v179_14_cursor.path()[v179_14_origin..(v179_14_origin + 1)]);
    let v180_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v180_2));
    let v180_4: Space = if map_kernels::has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
    drop(v180_3);
    let v180_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v180_4));
    drop(v180_4);
    let v180_8: Space = if (&(v180_5)).is_empty() { Space::new() } else {
      let v181_6: Path = concat_path(&(*p0),&v179_14_cursor.path()[v179_14_origin..(v179_14_origin + 1)]);
      let mut v181_7 = Space::new();
      let mut v181_7_write = v181_7.write_zipper();
      for v181_7_byte in v179_14_cursor.child_mask().iter() {
        v179_14_cursor.descend_to_existing_byte(v181_7_byte);
        {
        let v182_2: Space = singleton(&v179_14_cursor.path()[(v179_14_origin + 1)..(v179_14_origin + 2)]);
        let v182_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v182_2));
        let v182_4: Space = if map_kernels::has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
        drop(v182_3);
        let v182_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v182_4));
        drop(v182_4);
        let v182_8: Space = if (&(v182_5)).is_empty() { Space::new() } else {
          let v183_6: Path = concat_path(&(v181_6),&v179_14_cursor.path()[(v179_14_origin + 1)..(v179_14_origin + 2)]);
          let mut v183_7 = Space::new();
          let mut v183_7_write = v183_7.write_zipper();
          for v183_7_byte in v179_14_cursor.child_mask().iter() {
            v179_14_cursor.descend_to_existing_byte(v183_7_byte);
            {
            let v184_2: Space = singleton(&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
            let v184_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v184_2));
            let v184_4: Space = if map_kernels::has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
            drop(v184_3);
            let v184_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v184_4));
            drop(v184_4);
            let v184_8: Space = if (&(v184_5)).is_empty() { Space::new() } else {
              let v185_6: Path = concat_path(&(v183_6),&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
              let v185_7: Space = routine_22(c, &(v185_6), &v179_14_cursor);
              map_map_kernels::compose(&(v184_5),&(v185_7))
            };
            drop(v184_5);
            let v184_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v184_2));
            drop(v184_2);
            let v184_10: Space = if map_kernels::has_head(&(v184_9)) { singleton(&[]) } else { Space::new() };
            drop(v184_9);
            let v184_12: Space = if (&(v184_10)).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v183_6),&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
              let v186_11: Space = routine_23(c, &(v186_6), &v179_14_cursor);
              drop(v186_6);
              map_map_kernels::compose(&(v184_10),&(v186_11))
            };
            drop(v184_10);
            let v184_13: Space = map_map_kernels::unite(&(v184_8),&(v184_12));
            join_wrapped_into(&mut v183_7_write,&((v184_13).read_zipper()),&[]);
            }
            v179_14_cursor.ascend(1);
          }
          drop(v183_7_write);
          map_map_kernels::compose(&(v182_5),&(v183_7))
        };
        drop(v182_5);
        let v182_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v182_2));
        drop(v182_2);
        let v182_10: Space = if map_kernels::has_head(&(v182_9)) { singleton(&[]) } else { Space::new() };
        drop(v182_9);
        let v182_12: Space = if (&(v182_10)).is_empty() { Space::new() } else {
          let v187_6: Path = concat_path(&(v181_6),&v179_14_cursor.path()[(v179_14_origin + 1)..(v179_14_origin + 2)]);
          let mut v187_11 = Space::new();
          let mut v187_11_write = v187_11.write_zipper();
          for v187_11_byte in v179_14_cursor.child_mask().iter() {
            v179_14_cursor.descend_to_existing_byte(v187_11_byte);
            {
            let v188_2: Space = singleton(&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
            let v188_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v188_2));
            let v188_4: Space = if map_kernels::has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
            drop(v188_3);
            let v188_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v188_4));
            drop(v188_4);
            let v188_8: Space = if (&(v188_5)).is_empty() { Space::new() } else {
              let v189_6: Path = concat_path(&(v187_6),&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
              let v189_7: Space = routine_22(c, &(v189_6), &v179_14_cursor);
              map_map_kernels::compose(&(v188_5),&(v189_7))
            };
            drop(v188_5);
            let v188_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v188_2));
            drop(v188_2);
            let v188_10: Space = if map_kernels::has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
            drop(v188_9);
            let v188_12: Space = if (&(v188_10)).is_empty() { Space::new() } else {
              let v190_6: Path = concat_path(&(v187_6),&v179_14_cursor.path()[(v179_14_origin + 2)..(v179_14_origin + 3)]);
              let v190_11: Space = routine_12(c, &(v190_6), &v179_14_cursor);
              drop(v190_6);
              map_map_kernels::compose(&(v188_10),&(v190_11))
            };
            drop(v188_10);
            let v188_13: Space = map_map_kernels::unite(&(v188_8),&(v188_12));
            join_wrapped_into(&mut v187_11_write,&((v188_13).read_zipper()),&[]);
            }
            v179_14_cursor.ascend(1);
          }
          drop(v187_11_write);
          drop(v187_6);
          map_map_kernels::compose(&(v182_10),&(v187_11))
        };
        drop(v182_10);
        let v182_13: Space = map_map_kernels::unite(&(v182_8),&(v182_12));
        join_wrapped_into(&mut v181_7_write,&((v182_13).read_zipper()),&[]);
        }
        v179_14_cursor.ascend(1);
      }
      drop(v181_7_write);
      drop(v181_6);
      map_map_kernels::compose(&(v180_5),&(v181_7))
    };
    drop(v180_5);
    let v180_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v180_2));
    drop(v180_2);
    let v180_10: Space = if map_kernels::has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
    drop(v180_9);
    let v180_11: Space = map_view_kernels::compose(&(v180_10),&v179_14_cursor);
    drop(v180_10);
    let v180_12: Space = map_map_kernels::unite(&(v180_8),&(v180_11));
    drop(v180_11);
    join_wrapped_into(&mut v179_14_write,&((v180_12).read_zipper()),&[]);
    }
    v179_14_cursor.ascend(1);
  }
  drop(v179_14_cursor);
  drop(v179_14_write);
  (v179_14).clone()
}

fn routine_8(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v191_20 = Space::new();
  let mut v191_20_write = v191_20.write_zipper();
  let mut v191_20_cursor = (*s0).read_zipper();
  let v191_20_origin = v191_20_cursor.path().len();
  for v191_20_byte in v191_20_cursor.child_mask().iter() {
    v191_20_cursor.descend_to_existing_byte(v191_20_byte);
    {
    let v192_2: Space = singleton(&v191_20_cursor.path()[v191_20_origin..(v191_20_origin + 1)]);
    let v192_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v192_2));
    let v192_4: Space = if map_kernels::has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
    drop(v192_3);
    let v192_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v192_4));
    drop(v192_4);
    let v192_8: Space = if (&(v192_5)).is_empty() { Space::new() } else {
      let v193_6: Path = concat_path(&(*p0),&v191_20_cursor.path()[v191_20_origin..(v191_20_origin + 1)]);
      let mut v193_7 = Space::new();
      let mut v193_7_write = v193_7.write_zipper();
      for v193_7_byte in v191_20_cursor.child_mask().iter() {
        v191_20_cursor.descend_to_existing_byte(v193_7_byte);
        {
        let v194_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
        let v194_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v194_2));
        let v194_4: Space = if map_kernels::has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
        drop(v194_3);
        let v194_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v194_4));
        drop(v194_4);
        let v194_8: Space = if (&(v194_5)).is_empty() { Space::new() } else {
          let v195_6: Path = concat_path(&(v193_6),&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
          let mut v195_7 = Space::new();
          let mut v195_7_write = v195_7.write_zipper();
          for v195_7_byte in v191_20_cursor.child_mask().iter() {
            v191_20_cursor.descend_to_existing_byte(v195_7_byte);
            {
            let v196_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
            let v196_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v196_2));
            let v196_4: Space = if map_kernels::has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
            drop(v196_3);
            let v196_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v196_4));
            drop(v196_4);
            let v196_8: Space = if (&(v196_5)).is_empty() { Space::new() } else {
              let v197_6: Path = concat_path(&(v195_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v197_7: Space = routine_24(c, &(v197_6), &v191_20_cursor);
              map_map_kernels::compose(&(v196_5),&(v197_7))
            };
            drop(v196_5);
            let v196_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v196_2));
            drop(v196_2);
            let v196_10: Space = if map_kernels::has_head(&(v196_9)) { singleton(&[]) } else { Space::new() };
            drop(v196_9);
            let v196_12: Space = if (&(v196_10)).is_empty() { Space::new() } else {
              let v198_6: Path = concat_path(&(v195_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v198_11: Space = routine_25(c, &(v198_6), &v191_20_cursor);
              drop(v198_6);
              map_map_kernels::compose(&(v196_10),&(v198_11))
            };
            drop(v196_10);
            let v196_13: Space = map_map_kernels::unite(&(v196_8),&(v196_12));
            join_wrapped_into(&mut v195_7_write,&((v196_13).read_zipper()),&[]);
            }
            v191_20_cursor.ascend(1);
          }
          drop(v195_7_write);
          map_map_kernels::compose(&(v194_5),&(v195_7))
        };
        drop(v194_5);
        let v194_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v194_2));
        drop(v194_2);
        let v194_10: Space = if map_kernels::has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
        drop(v194_9);
        let v194_12: Space = if (&(v194_10)).is_empty() { Space::new() } else {
          let v199_6: Path = concat_path(&(v193_6),&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
          let mut v199_11 = Space::new();
          let mut v199_11_write = v199_11.write_zipper();
          for v199_11_byte in v191_20_cursor.child_mask().iter() {
            v191_20_cursor.descend_to_existing_byte(v199_11_byte);
            {
            let v200_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
            let v200_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v200_2));
            let v200_4: Space = if map_kernels::has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
            drop(v200_3);
            let v200_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v200_4));
            drop(v200_4);
            let v200_8: Space = if (&(v200_5)).is_empty() { Space::new() } else {
              let v201_6: Path = concat_path(&(v199_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v201_7: Space = routine_24(c, &(v201_6), &v191_20_cursor);
              map_map_kernels::compose(&(v200_5),&(v201_7))
            };
            drop(v200_5);
            let v200_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v200_2));
            drop(v200_2);
            let v200_10: Space = if map_kernels::has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
            drop(v200_9);
            let v200_12: Space = if (&(v200_10)).is_empty() { Space::new() } else {
              let v202_6: Path = concat_path(&(v199_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v202_11: Space = routine_15(c, &(v202_6), &v191_20_cursor);
              drop(v202_6);
              map_map_kernels::compose(&(v200_10),&(v202_11))
            };
            drop(v200_10);
            let v200_13: Space = map_map_kernels::unite(&(v200_8),&(v200_12));
            join_wrapped_into(&mut v199_11_write,&((v200_13).read_zipper()),&[]);
            }
            v191_20_cursor.ascend(1);
          }
          drop(v199_11_write);
          drop(v199_6);
          map_map_kernels::compose(&(v194_10),&(v199_11))
        };
        drop(v194_10);
        let v194_13: Space = map_map_kernels::unite(&(v194_8),&(v194_12));
        join_wrapped_into(&mut v193_7_write,&((v194_13).read_zipper()),&[]);
        }
        v191_20_cursor.ascend(1);
      }
      drop(v193_7_write);
      map_map_kernels::compose(&(v192_5),&(v193_7))
    };
    drop(v192_5);
    let v192_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v192_2));
    drop(v192_2);
    let v192_10: Space = if map_kernels::has_head(&(v192_9)) { singleton(&[]) } else { Space::new() };
    drop(v192_9);
    let v192_12: Space = if (&(v192_10)).is_empty() { Space::new() } else {
      let v203_6: Path = concat_path(&(*p0),&v191_20_cursor.path()[v191_20_origin..(v191_20_origin + 1)]);
      let mut v203_11 = Space::new();
      let mut v203_11_write = v203_11.write_zipper();
      for v203_11_byte in v191_20_cursor.child_mask().iter() {
        v191_20_cursor.descend_to_existing_byte(v203_11_byte);
        {
        let v204_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
        let v204_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v204_2));
        let v204_4: Space = if map_kernels::has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
        drop(v204_3);
        let v204_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v204_4));
        drop(v204_4);
        let v204_8: Space = if (&(v204_5)).is_empty() { Space::new() } else {
          let v205_6: Path = concat_path(&(v203_6),&v191_20_cursor.path()[(v191_20_origin + 1)..(v191_20_origin + 2)]);
          let mut v205_7 = Space::new();
          let mut v205_7_write = v205_7.write_zipper();
          for v205_7_byte in v191_20_cursor.child_mask().iter() {
            v191_20_cursor.descend_to_existing_byte(v205_7_byte);
            {
            let v206_2: Space = singleton(&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
            let v206_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v206_2));
            let v206_4: Space = if map_kernels::has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
            drop(v206_3);
            let v206_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v206_4));
            drop(v206_4);
            let v206_8: Space = if (&(v206_5)).is_empty() { Space::new() } else {
              let v207_6: Path = concat_path(&(v205_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v207_7: Space = routine_24(c, &(v207_6), &v191_20_cursor);
              map_map_kernels::compose(&(v206_5),&(v207_7))
            };
            drop(v206_5);
            let v206_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v206_2));
            drop(v206_2);
            let v206_10: Space = if map_kernels::has_head(&(v206_9)) { singleton(&[]) } else { Space::new() };
            drop(v206_9);
            let v206_12: Space = if (&(v206_10)).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v205_6),&v191_20_cursor.path()[(v191_20_origin + 2)..(v191_20_origin + 3)]);
              let v208_11: Space = routine_25(c, &(v208_6), &v191_20_cursor);
              drop(v208_6);
              map_map_kernels::compose(&(v206_10),&(v208_11))
            };
            drop(v206_10);
            let v206_13: Space = map_map_kernels::unite(&(v206_8),&(v206_12));
            join_wrapped_into(&mut v205_7_write,&((v206_13).read_zipper()),&[]);
            }
            v191_20_cursor.ascend(1);
          }
          drop(v205_7_write);
          drop(v205_6);
          map_map_kernels::compose(&(v204_5),&(v205_7))
        };
        drop(v204_5);
        let v204_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v204_2));
        drop(v204_2);
        let v204_10: Space = if map_kernels::has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
        drop(v204_9);
        let v204_11: Space = map_view_kernels::compose(&(v204_10),&v191_20_cursor);
        drop(v204_10);
        let v204_12: Space = map_map_kernels::unite(&(v204_8),&(v204_11));
        drop(v204_11);
        join_wrapped_into(&mut v203_11_write,&((v204_12).read_zipper()),&[]);
        }
        v191_20_cursor.ascend(1);
      }
      drop(v203_11_write);
      drop(v203_6);
      map_map_kernels::compose(&(v192_10),&(v203_11))
    };
    drop(v192_10);
    let v192_13: Space = map_map_kernels::unite(&(v192_8),&(v192_12));
    join_wrapped_into(&mut v191_20_write,&((v192_13).read_zipper()),&[]);
    }
    v191_20_cursor.ascend(1);
  }
  drop(v191_20_cursor);
  drop(v191_20_write);
  (v191_20).clone()
}

fn routine_9(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v209_14 = Space::new();
  let mut v209_14_write = v209_14.write_zipper();
  let mut v209_14_cursor = (*s0).read_zipper();
  let v209_14_origin = v209_14_cursor.path().len();
  for v209_14_byte in v209_14_cursor.child_mask().iter() {
    v209_14_cursor.descend_to_existing_byte(v209_14_byte);
    {
    let v210_2: Space = singleton(&v209_14_cursor.path()[v209_14_origin..(v209_14_origin + 1)]);
    let v210_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v210_2));
    let v210_4: Space = if map_kernels::has_head(&(v210_3)) { singleton(&[]) } else { Space::new() };
    drop(v210_3);
    let v210_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v210_4));
    drop(v210_4);
    let v210_8: Space = if (&(v210_5)).is_empty() { Space::new() } else {
      let v211_6: Path = concat_path(&(*p0),&v209_14_cursor.path()[v209_14_origin..(v209_14_origin + 1)]);
      let mut v211_7 = Space::new();
      let mut v211_7_write = v211_7.write_zipper();
      for v211_7_byte in v209_14_cursor.child_mask().iter() {
        v209_14_cursor.descend_to_existing_byte(v211_7_byte);
        {
        let v212_2: Space = singleton(&v209_14_cursor.path()[(v209_14_origin + 1)..(v209_14_origin + 2)]);
        let v212_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v212_2));
        let v212_4: Space = if map_kernels::has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
        drop(v212_3);
        let v212_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v212_4));
        drop(v212_4);
        let v212_8: Space = if (&(v212_5)).is_empty() { Space::new() } else {
          let v213_6: Path = concat_path(&(v211_6),&v209_14_cursor.path()[(v209_14_origin + 1)..(v209_14_origin + 2)]);
          let mut v213_7 = Space::new();
          let mut v213_7_write = v213_7.write_zipper();
          for v213_7_byte in v209_14_cursor.child_mask().iter() {
            v209_14_cursor.descend_to_existing_byte(v213_7_byte);
            {
            let v214_2: Space = singleton(&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
            let v214_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v214_2));
            let v214_4: Space = if map_kernels::has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
            drop(v214_3);
            let v214_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v214_4));
            drop(v214_4);
            let v214_8: Space = if (&(v214_5)).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v213_6),&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
              let v215_7: Space = routine_24(c, &(v215_6), &v209_14_cursor);
              map_map_kernels::compose(&(v214_5),&(v215_7))
            };
            drop(v214_5);
            let v214_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v214_2));
            drop(v214_2);
            let v214_10: Space = if map_kernels::has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
            drop(v214_9);
            let v214_12: Space = if (&(v214_10)).is_empty() { Space::new() } else {
              let v216_6: Path = concat_path(&(v213_6),&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
              let v216_11: Space = routine_25(c, &(v216_6), &v209_14_cursor);
              drop(v216_6);
              map_map_kernels::compose(&(v214_10),&(v216_11))
            };
            drop(v214_10);
            let v214_13: Space = map_map_kernels::unite(&(v214_8),&(v214_12));
            join_wrapped_into(&mut v213_7_write,&((v214_13).read_zipper()),&[]);
            }
            v209_14_cursor.ascend(1);
          }
          drop(v213_7_write);
          map_map_kernels::compose(&(v212_5),&(v213_7))
        };
        drop(v212_5);
        let v212_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v212_2));
        drop(v212_2);
        let v212_10: Space = if map_kernels::has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
        drop(v212_9);
        let v212_12: Space = if (&(v212_10)).is_empty() { Space::new() } else {
          let v217_6: Path = concat_path(&(v211_6),&v209_14_cursor.path()[(v209_14_origin + 1)..(v209_14_origin + 2)]);
          let mut v217_11 = Space::new();
          let mut v217_11_write = v217_11.write_zipper();
          for v217_11_byte in v209_14_cursor.child_mask().iter() {
            v209_14_cursor.descend_to_existing_byte(v217_11_byte);
            {
            let v218_2: Space = singleton(&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
            let v218_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v218_2));
            let v218_4: Space = if map_kernels::has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
            drop(v218_3);
            let v218_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v218_4));
            drop(v218_4);
            let v218_8: Space = if (&(v218_5)).is_empty() { Space::new() } else {
              let v219_6: Path = concat_path(&(v217_6),&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
              let v219_7: Space = routine_24(c, &(v219_6), &v209_14_cursor);
              map_map_kernels::compose(&(v218_5),&(v219_7))
            };
            drop(v218_5);
            let v218_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v218_2));
            drop(v218_2);
            let v218_10: Space = if map_kernels::has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
            drop(v218_9);
            let v218_12: Space = if (&(v218_10)).is_empty() { Space::new() } else {
              let v220_6: Path = concat_path(&(v217_6),&v209_14_cursor.path()[(v209_14_origin + 2)..(v209_14_origin + 3)]);
              let v220_11: Space = routine_15(c, &(v220_6), &v209_14_cursor);
              drop(v220_6);
              map_map_kernels::compose(&(v218_10),&(v220_11))
            };
            drop(v218_10);
            let v218_13: Space = map_map_kernels::unite(&(v218_8),&(v218_12));
            join_wrapped_into(&mut v217_11_write,&((v218_13).read_zipper()),&[]);
            }
            v209_14_cursor.ascend(1);
          }
          drop(v217_11_write);
          drop(v217_6);
          map_map_kernels::compose(&(v212_10),&(v217_11))
        };
        drop(v212_10);
        let v212_13: Space = map_map_kernels::unite(&(v212_8),&(v212_12));
        join_wrapped_into(&mut v211_7_write,&((v212_13).read_zipper()),&[]);
        }
        v209_14_cursor.ascend(1);
      }
      drop(v211_7_write);
      drop(v211_6);
      map_map_kernels::compose(&(v210_5),&(v211_7))
    };
    drop(v210_5);
    let v210_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v210_2));
    drop(v210_2);
    let v210_10: Space = if map_kernels::has_head(&(v210_9)) { singleton(&[]) } else { Space::new() };
    drop(v210_9);
    let v210_11: Space = map_view_kernels::compose(&(v210_10),&v209_14_cursor);
    drop(v210_10);
    let v210_12: Space = map_map_kernels::unite(&(v210_8),&(v210_11));
    drop(v210_11);
    join_wrapped_into(&mut v209_14_write,&((v210_12).read_zipper()),&[]);
    }
    v209_14_cursor.ascend(1);
  }
  drop(v209_14_cursor);
  drop(v209_14_write);
  (v209_14).clone()
}

fn routine_10(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v221_20 = Space::new();
  let mut v221_20_write = v221_20.write_zipper();
  let mut v221_20_cursor = (*s0).read_zipper();
  let v221_20_origin = v221_20_cursor.path().len();
  for v221_20_byte in v221_20_cursor.child_mask().iter() {
    v221_20_cursor.descend_to_existing_byte(v221_20_byte);
    {
    let v222_2: Space = singleton(&v221_20_cursor.path()[v221_20_origin..(v221_20_origin + 1)]);
    let v222_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v222_2));
    let v222_4: Space = if map_kernels::has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
    drop(v222_3);
    let v222_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v222_4));
    drop(v222_4);
    let v222_8: Space = if (&(v222_5)).is_empty() { Space::new() } else {
      let v223_6: Path = concat_path(&(*p0),&v221_20_cursor.path()[v221_20_origin..(v221_20_origin + 1)]);
      let mut v223_7 = Space::new();
      let mut v223_7_write = v223_7.write_zipper();
      for v223_7_byte in v221_20_cursor.child_mask().iter() {
        v221_20_cursor.descend_to_existing_byte(v223_7_byte);
        {
        let v224_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
        let v224_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v224_2));
        let v224_4: Space = if map_kernels::has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
        drop(v224_3);
        let v224_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v224_4));
        drop(v224_4);
        let v224_8: Space = if (&(v224_5)).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v223_6),&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
          let mut v225_7 = Space::new();
          let mut v225_7_write = v225_7.write_zipper();
          for v225_7_byte in v221_20_cursor.child_mask().iter() {
            v221_20_cursor.descend_to_existing_byte(v225_7_byte);
            {
            let v226_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
            let v226_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v226_2));
            let v226_4: Space = if map_kernels::has_head(&(v226_3)) { singleton(&[]) } else { Space::new() };
            drop(v226_3);
            let v226_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v226_4));
            drop(v226_4);
            let v226_8: Space = if (&(v226_5)).is_empty() { Space::new() } else {
              let v227_6: Path = concat_path(&(v225_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v227_7: Space = routine_26(c, &(v227_6), &v221_20_cursor);
              map_map_kernels::compose(&(v226_5),&(v227_7))
            };
            drop(v226_5);
            let v226_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v226_2));
            drop(v226_2);
            let v226_10: Space = if map_kernels::has_head(&(v226_9)) { singleton(&[]) } else { Space::new() };
            drop(v226_9);
            let v226_12: Space = if (&(v226_10)).is_empty() { Space::new() } else {
              let v228_6: Path = concat_path(&(v225_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v228_11: Space = routine_27(c, &(v228_6), &v221_20_cursor);
              drop(v228_6);
              map_map_kernels::compose(&(v226_10),&(v228_11))
            };
            drop(v226_10);
            let v226_13: Space = map_map_kernels::unite(&(v226_8),&(v226_12));
            join_wrapped_into(&mut v225_7_write,&((v226_13).read_zipper()),&[]);
            }
            v221_20_cursor.ascend(1);
          }
          drop(v225_7_write);
          map_map_kernels::compose(&(v224_5),&(v225_7))
        };
        drop(v224_5);
        let v224_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v224_2));
        drop(v224_2);
        let v224_10: Space = if map_kernels::has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
        drop(v224_9);
        let v224_12: Space = if (&(v224_10)).is_empty() { Space::new() } else {
          let v229_6: Path = concat_path(&(v223_6),&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
          let mut v229_11 = Space::new();
          let mut v229_11_write = v229_11.write_zipper();
          for v229_11_byte in v221_20_cursor.child_mask().iter() {
            v221_20_cursor.descend_to_existing_byte(v229_11_byte);
            {
            let v230_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
            let v230_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v230_2));
            let v230_4: Space = if map_kernels::has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
            drop(v230_3);
            let v230_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v230_4));
            drop(v230_4);
            let v230_8: Space = if (&(v230_5)).is_empty() { Space::new() } else {
              let v231_6: Path = concat_path(&(v229_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v231_7: Space = routine_26(c, &(v231_6), &v221_20_cursor);
              map_map_kernels::compose(&(v230_5),&(v231_7))
            };
            drop(v230_5);
            let v230_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v230_2));
            drop(v230_2);
            let v230_10: Space = if map_kernels::has_head(&(v230_9)) { singleton(&[]) } else { Space::new() };
            drop(v230_9);
            let v230_12: Space = if (&(v230_10)).is_empty() { Space::new() } else {
              let v232_6: Path = concat_path(&(v229_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v232_11: Space = routine_12(c, &(v232_6), &v221_20_cursor);
              drop(v232_6);
              map_map_kernels::compose(&(v230_10),&(v232_11))
            };
            drop(v230_10);
            let v230_13: Space = map_map_kernels::unite(&(v230_8),&(v230_12));
            join_wrapped_into(&mut v229_11_write,&((v230_13).read_zipper()),&[]);
            }
            v221_20_cursor.ascend(1);
          }
          drop(v229_11_write);
          drop(v229_6);
          map_map_kernels::compose(&(v224_10),&(v229_11))
        };
        drop(v224_10);
        let v224_13: Space = map_map_kernels::unite(&(v224_8),&(v224_12));
        join_wrapped_into(&mut v223_7_write,&((v224_13).read_zipper()),&[]);
        }
        v221_20_cursor.ascend(1);
      }
      drop(v223_7_write);
      map_map_kernels::compose(&(v222_5),&(v223_7))
    };
    drop(v222_5);
    let v222_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v222_2));
    drop(v222_2);
    let v222_10: Space = if map_kernels::has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
    drop(v222_9);
    let v222_12: Space = if (&(v222_10)).is_empty() { Space::new() } else {
      let v233_6: Path = concat_path(&(*p0),&v221_20_cursor.path()[v221_20_origin..(v221_20_origin + 1)]);
      let mut v233_11 = Space::new();
      let mut v233_11_write = v233_11.write_zipper();
      for v233_11_byte in v221_20_cursor.child_mask().iter() {
        v221_20_cursor.descend_to_existing_byte(v233_11_byte);
        {
        let v234_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
        let v234_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v234_2));
        let v234_4: Space = if map_kernels::has_head(&(v234_3)) { singleton(&[]) } else { Space::new() };
        drop(v234_3);
        let v234_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v234_4));
        drop(v234_4);
        let v234_8: Space = if (&(v234_5)).is_empty() { Space::new() } else {
          let v235_6: Path = concat_path(&(v233_6),&v221_20_cursor.path()[(v221_20_origin + 1)..(v221_20_origin + 2)]);
          let mut v235_7 = Space::new();
          let mut v235_7_write = v235_7.write_zipper();
          for v235_7_byte in v221_20_cursor.child_mask().iter() {
            v221_20_cursor.descend_to_existing_byte(v235_7_byte);
            {
            let v236_2: Space = singleton(&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
            let v236_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v236_2));
            let v236_4: Space = if map_kernels::has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
            drop(v236_3);
            let v236_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v236_4));
            drop(v236_4);
            let v236_8: Space = if (&(v236_5)).is_empty() { Space::new() } else {
              let v237_6: Path = concat_path(&(v235_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v237_7: Space = routine_26(c, &(v237_6), &v221_20_cursor);
              map_map_kernels::compose(&(v236_5),&(v237_7))
            };
            drop(v236_5);
            let v236_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v236_2));
            drop(v236_2);
            let v236_10: Space = if map_kernels::has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
            drop(v236_9);
            let v236_12: Space = if (&(v236_10)).is_empty() { Space::new() } else {
              let v238_6: Path = concat_path(&(v235_6),&v221_20_cursor.path()[(v221_20_origin + 2)..(v221_20_origin + 3)]);
              let v238_11: Space = routine_27(c, &(v238_6), &v221_20_cursor);
              drop(v238_6);
              map_map_kernels::compose(&(v236_10),&(v238_11))
            };
            drop(v236_10);
            let v236_13: Space = map_map_kernels::unite(&(v236_8),&(v236_12));
            join_wrapped_into(&mut v235_7_write,&((v236_13).read_zipper()),&[]);
            }
            v221_20_cursor.ascend(1);
          }
          drop(v235_7_write);
          drop(v235_6);
          map_map_kernels::compose(&(v234_5),&(v235_7))
        };
        drop(v234_5);
        let v234_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v234_2));
        drop(v234_2);
        let v234_10: Space = if map_kernels::has_head(&(v234_9)) { singleton(&[]) } else { Space::new() };
        drop(v234_9);
        let v234_11: Space = map_view_kernels::compose(&(v234_10),&v221_20_cursor);
        drop(v234_10);
        let v234_12: Space = map_map_kernels::unite(&(v234_8),&(v234_11));
        drop(v234_11);
        join_wrapped_into(&mut v233_11_write,&((v234_12).read_zipper()),&[]);
        }
        v221_20_cursor.ascend(1);
      }
      drop(v233_11_write);
      drop(v233_6);
      map_map_kernels::compose(&(v222_10),&(v233_11))
    };
    drop(v222_10);
    let v222_13: Space = map_map_kernels::unite(&(v222_8),&(v222_12));
    join_wrapped_into(&mut v221_20_write,&((v222_13).read_zipper()),&[]);
    }
    v221_20_cursor.ascend(1);
  }
  drop(v221_20_cursor);
  drop(v221_20_write);
  (v221_20).clone()
}

fn routine_11(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v239_14 = Space::new();
  let mut v239_14_write = v239_14.write_zipper();
  let mut v239_14_cursor = (*s0).read_zipper();
  let v239_14_origin = v239_14_cursor.path().len();
  for v239_14_byte in v239_14_cursor.child_mask().iter() {
    v239_14_cursor.descend_to_existing_byte(v239_14_byte);
    {
    let v240_2: Space = singleton(&v239_14_cursor.path()[v239_14_origin..(v239_14_origin + 1)]);
    let v240_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v240_2));
    let v240_4: Space = if map_kernels::has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
    drop(v240_3);
    let v240_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v240_4));
    drop(v240_4);
    let v240_8: Space = if (&(v240_5)).is_empty() { Space::new() } else {
      let v241_6: Path = concat_path(&(*p0),&v239_14_cursor.path()[v239_14_origin..(v239_14_origin + 1)]);
      let mut v241_7 = Space::new();
      let mut v241_7_write = v241_7.write_zipper();
      for v241_7_byte in v239_14_cursor.child_mask().iter() {
        v239_14_cursor.descend_to_existing_byte(v241_7_byte);
        {
        let v242_2: Space = singleton(&v239_14_cursor.path()[(v239_14_origin + 1)..(v239_14_origin + 2)]);
        let v242_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v242_2));
        let v242_4: Space = if map_kernels::has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v242_4));
        drop(v242_4);
        let v242_8: Space = if (&(v242_5)).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v241_6),&v239_14_cursor.path()[(v239_14_origin + 1)..(v239_14_origin + 2)]);
          let mut v243_7 = Space::new();
          let mut v243_7_write = v243_7.write_zipper();
          for v243_7_byte in v239_14_cursor.child_mask().iter() {
            v239_14_cursor.descend_to_existing_byte(v243_7_byte);
            {
            let v244_2: Space = singleton(&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
            let v244_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v244_2));
            let v244_4: Space = if map_kernels::has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (&(v244_5)).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
              let v245_7: Space = routine_26(c, &(v245_6), &v239_14_cursor);
              map_map_kernels::compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if map_kernels::has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (&(v244_10)).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
              let v246_11: Space = routine_27(c, &(v246_6), &v239_14_cursor);
              drop(v246_6);
              map_map_kernels::compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = map_map_kernels::unite(&(v244_8),&(v244_12));
            join_wrapped_into(&mut v243_7_write,&((v244_13).read_zipper()),&[]);
            }
            v239_14_cursor.ascend(1);
          }
          drop(v243_7_write);
          map_map_kernels::compose(&(v242_5),&(v243_7))
        };
        drop(v242_5);
        let v242_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v242_2));
        drop(v242_2);
        let v242_10: Space = if map_kernels::has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
        drop(v242_9);
        let v242_12: Space = if (&(v242_10)).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v241_6),&v239_14_cursor.path()[(v239_14_origin + 1)..(v239_14_origin + 2)]);
          let mut v247_11 = Space::new();
          let mut v247_11_write = v247_11.write_zipper();
          for v247_11_byte in v239_14_cursor.child_mask().iter() {
            v239_14_cursor.descend_to_existing_byte(v247_11_byte);
            {
            let v248_2: Space = singleton(&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
            let v248_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v248_2));
            let v248_4: Space = if map_kernels::has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (&(v248_5)).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
              let v249_7: Space = routine_26(c, &(v249_6), &v239_14_cursor);
              map_map_kernels::compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if map_kernels::has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (&(v248_10)).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&v239_14_cursor.path()[(v239_14_origin + 2)..(v239_14_origin + 3)]);
              let v250_11: Space = routine_12(c, &(v250_6), &v239_14_cursor);
              drop(v250_6);
              map_map_kernels::compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = map_map_kernels::unite(&(v248_8),&(v248_12));
            join_wrapped_into(&mut v247_11_write,&((v248_13).read_zipper()),&[]);
            }
            v239_14_cursor.ascend(1);
          }
          drop(v247_11_write);
          drop(v247_6);
          map_map_kernels::compose(&(v242_10),&(v247_11))
        };
        drop(v242_10);
        let v242_13: Space = map_map_kernels::unite(&(v242_8),&(v242_12));
        join_wrapped_into(&mut v241_7_write,&((v242_13).read_zipper()),&[]);
        }
        v239_14_cursor.ascend(1);
      }
      drop(v241_7_write);
      drop(v241_6);
      map_map_kernels::compose(&(v240_5),&(v241_7))
    };
    drop(v240_5);
    let v240_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v240_2));
    drop(v240_2);
    let v240_10: Space = if map_kernels::has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
    drop(v240_9);
    let v240_11: Space = map_view_kernels::compose(&(v240_10),&v239_14_cursor);
    drop(v240_10);
    let v240_12: Space = map_map_kernels::unite(&(v240_8),&(v240_11));
    drop(v240_11);
    join_wrapped_into(&mut v239_14_write,&((v240_12).read_zipper()),&[]);
    }
    v239_14_cursor.ascend(1);
  }
  drop(v239_14_cursor);
  drop(v239_14_write);
  (v239_14).clone()
}

fn routine_12(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_13(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v252_20 = Space::new();
  let mut v252_20_write = v252_20.write_zipper();
  let mut v252_20_cursor = (*s0).read_zipper();
  let v252_20_origin = v252_20_cursor.path().len();
  for v252_20_byte in v252_20_cursor.child_mask().iter() {
    v252_20_cursor.descend_to_existing_byte(v252_20_byte);
    {
    let v253_2: Space = singleton(&v252_20_cursor.path()[v252_20_origin..(v252_20_origin + 1)]);
    let v253_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v253_2));
    let v253_4: Space = if map_kernels::has_head(&(v253_3)) { singleton(&[]) } else { Space::new() };
    drop(v253_3);
    let v253_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v253_4));
    drop(v253_4);
    let v253_8: Space = if (&(v253_5)).is_empty() { Space::new() } else {
      let v254_6: Path = concat_path(&(*p0),&v252_20_cursor.path()[v252_20_origin..(v252_20_origin + 1)]);
      let mut v254_7 = Space::new();
      let mut v254_7_write = v254_7.write_zipper();
      for v254_7_byte in v252_20_cursor.child_mask().iter() {
        v252_20_cursor.descend_to_existing_byte(v254_7_byte);
        {
        let v255_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
        let v255_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v255_2));
        let v255_4: Space = if map_kernels::has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
        drop(v255_3);
        let v255_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v255_4));
        drop(v255_4);
        let v255_8: Space = if (&(v255_5)).is_empty() { Space::new() } else {
          let v256_6: Path = concat_path(&(v254_6),&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
          let mut v256_7 = Space::new();
          let mut v256_7_write = v256_7.write_zipper();
          for v256_7_byte in v252_20_cursor.child_mask().iter() {
            v252_20_cursor.descend_to_existing_byte(v256_7_byte);
            {
            let v257_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
            let v257_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v257_2));
            let v257_4: Space = if map_kernels::has_head(&(v257_3)) { singleton(&[]) } else { Space::new() };
            drop(v257_3);
            let v257_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v257_4));
            drop(v257_4);
            let v257_8: Space = if (&(v257_5)).is_empty() { Space::new() } else {
              let v258_6: Path = concat_path(&(v256_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v258_7: Space = routine_28(c, &(v258_6), &v252_20_cursor);
              map_map_kernels::compose(&(v257_5),&(v258_7))
            };
            drop(v257_5);
            let v257_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v257_2));
            drop(v257_2);
            let v257_10: Space = if map_kernels::has_head(&(v257_9)) { singleton(&[]) } else { Space::new() };
            drop(v257_9);
            let v257_12: Space = if (&(v257_10)).is_empty() { Space::new() } else {
              let v259_6: Path = concat_path(&(v256_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v259_11: Space = routine_29(c, &(v259_6), &v252_20_cursor);
              drop(v259_6);
              map_map_kernels::compose(&(v257_10),&(v259_11))
            };
            drop(v257_10);
            let v257_13: Space = map_map_kernels::unite(&(v257_8),&(v257_12));
            join_wrapped_into(&mut v256_7_write,&((v257_13).read_zipper()),&[]);
            }
            v252_20_cursor.ascend(1);
          }
          drop(v256_7_write);
          map_map_kernels::compose(&(v255_5),&(v256_7))
        };
        drop(v255_5);
        let v255_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v255_2));
        drop(v255_2);
        let v255_10: Space = if map_kernels::has_head(&(v255_9)) { singleton(&[]) } else { Space::new() };
        drop(v255_9);
        let v255_12: Space = if (&(v255_10)).is_empty() { Space::new() } else {
          let v260_6: Path = concat_path(&(v254_6),&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
          let mut v260_11 = Space::new();
          let mut v260_11_write = v260_11.write_zipper();
          for v260_11_byte in v252_20_cursor.child_mask().iter() {
            v252_20_cursor.descend_to_existing_byte(v260_11_byte);
            {
            let v261_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
            let v261_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v261_2));
            let v261_4: Space = if map_kernels::has_head(&(v261_3)) { singleton(&[]) } else { Space::new() };
            drop(v261_3);
            let v261_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v261_4));
            drop(v261_4);
            let v261_8: Space = if (&(v261_5)).is_empty() { Space::new() } else {
              let v262_6: Path = concat_path(&(v260_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v262_7: Space = routine_28(c, &(v262_6), &v252_20_cursor);
              map_map_kernels::compose(&(v261_5),&(v262_7))
            };
            drop(v261_5);
            let v261_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v261_2));
            drop(v261_2);
            let v261_10: Space = if map_kernels::has_head(&(v261_9)) { singleton(&[]) } else { Space::new() };
            drop(v261_9);
            let v261_12: Space = if (&(v261_10)).is_empty() { Space::new() } else {
              let v263_6: Path = concat_path(&(v260_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v263_11: Space = routine_15(c, &(v263_6), &v252_20_cursor);
              drop(v263_6);
              map_map_kernels::compose(&(v261_10),&(v263_11))
            };
            drop(v261_10);
            let v261_13: Space = map_map_kernels::unite(&(v261_8),&(v261_12));
            join_wrapped_into(&mut v260_11_write,&((v261_13).read_zipper()),&[]);
            }
            v252_20_cursor.ascend(1);
          }
          drop(v260_11_write);
          drop(v260_6);
          map_map_kernels::compose(&(v255_10),&(v260_11))
        };
        drop(v255_10);
        let v255_13: Space = map_map_kernels::unite(&(v255_8),&(v255_12));
        join_wrapped_into(&mut v254_7_write,&((v255_13).read_zipper()),&[]);
        }
        v252_20_cursor.ascend(1);
      }
      drop(v254_7_write);
      map_map_kernels::compose(&(v253_5),&(v254_7))
    };
    drop(v253_5);
    let v253_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v253_2));
    drop(v253_2);
    let v253_10: Space = if map_kernels::has_head(&(v253_9)) { singleton(&[]) } else { Space::new() };
    drop(v253_9);
    let v253_12: Space = if (&(v253_10)).is_empty() { Space::new() } else {
      let v264_6: Path = concat_path(&(*p0),&v252_20_cursor.path()[v252_20_origin..(v252_20_origin + 1)]);
      let mut v264_11 = Space::new();
      let mut v264_11_write = v264_11.write_zipper();
      for v264_11_byte in v252_20_cursor.child_mask().iter() {
        v252_20_cursor.descend_to_existing_byte(v264_11_byte);
        {
        let v265_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
        let v265_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v265_2));
        let v265_4: Space = if map_kernels::has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
        drop(v265_3);
        let v265_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v265_4));
        drop(v265_4);
        let v265_8: Space = if (&(v265_5)).is_empty() { Space::new() } else {
          let v266_6: Path = concat_path(&(v264_6),&v252_20_cursor.path()[(v252_20_origin + 1)..(v252_20_origin + 2)]);
          let mut v266_7 = Space::new();
          let mut v266_7_write = v266_7.write_zipper();
          for v266_7_byte in v252_20_cursor.child_mask().iter() {
            v252_20_cursor.descend_to_existing_byte(v266_7_byte);
            {
            let v267_2: Space = singleton(&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
            let v267_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v267_2));
            let v267_4: Space = if map_kernels::has_head(&(v267_3)) { singleton(&[]) } else { Space::new() };
            drop(v267_3);
            let v267_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v267_4));
            drop(v267_4);
            let v267_8: Space = if (&(v267_5)).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v266_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v268_7: Space = routine_28(c, &(v268_6), &v252_20_cursor);
              map_map_kernels::compose(&(v267_5),&(v268_7))
            };
            drop(v267_5);
            let v267_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v267_2));
            drop(v267_2);
            let v267_10: Space = if map_kernels::has_head(&(v267_9)) { singleton(&[]) } else { Space::new() };
            drop(v267_9);
            let v267_12: Space = if (&(v267_10)).is_empty() { Space::new() } else {
              let v269_6: Path = concat_path(&(v266_6),&v252_20_cursor.path()[(v252_20_origin + 2)..(v252_20_origin + 3)]);
              let v269_11: Space = routine_29(c, &(v269_6), &v252_20_cursor);
              drop(v269_6);
              map_map_kernels::compose(&(v267_10),&(v269_11))
            };
            drop(v267_10);
            let v267_13: Space = map_map_kernels::unite(&(v267_8),&(v267_12));
            join_wrapped_into(&mut v266_7_write,&((v267_13).read_zipper()),&[]);
            }
            v252_20_cursor.ascend(1);
          }
          drop(v266_7_write);
          drop(v266_6);
          map_map_kernels::compose(&(v265_5),&(v266_7))
        };
        drop(v265_5);
        let v265_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v265_2));
        drop(v265_2);
        let v265_10: Space = if map_kernels::has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
        drop(v265_9);
        let v265_11: Space = map_view_kernels::compose(&(v265_10),&v252_20_cursor);
        drop(v265_10);
        let v265_12: Space = map_map_kernels::unite(&(v265_8),&(v265_11));
        drop(v265_11);
        join_wrapped_into(&mut v264_11_write,&((v265_12).read_zipper()),&[]);
        }
        v252_20_cursor.ascend(1);
      }
      drop(v264_11_write);
      drop(v264_6);
      map_map_kernels::compose(&(v253_10),&(v264_11))
    };
    drop(v253_10);
    let v253_13: Space = map_map_kernels::unite(&(v253_8),&(v253_12));
    join_wrapped_into(&mut v252_20_write,&((v253_13).read_zipper()),&[]);
    }
    v252_20_cursor.ascend(1);
  }
  drop(v252_20_cursor);
  drop(v252_20_write);
  (v252_20).clone()
}

fn routine_14(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v270_14 = Space::new();
  let mut v270_14_write = v270_14.write_zipper();
  let mut v270_14_cursor = (*s0).read_zipper();
  let v270_14_origin = v270_14_cursor.path().len();
  for v270_14_byte in v270_14_cursor.child_mask().iter() {
    v270_14_cursor.descend_to_existing_byte(v270_14_byte);
    {
    let v271_2: Space = singleton(&v270_14_cursor.path()[v270_14_origin..(v270_14_origin + 1)]);
    let v271_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v271_2));
    let v271_4: Space = if map_kernels::has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
    drop(v271_3);
    let v271_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v271_4));
    drop(v271_4);
    let v271_8: Space = if (&(v271_5)).is_empty() { Space::new() } else {
      let v272_6: Path = concat_path(&(*p0),&v270_14_cursor.path()[v270_14_origin..(v270_14_origin + 1)]);
      let mut v272_7 = Space::new();
      let mut v272_7_write = v272_7.write_zipper();
      for v272_7_byte in v270_14_cursor.child_mask().iter() {
        v270_14_cursor.descend_to_existing_byte(v272_7_byte);
        {
        let v273_2: Space = singleton(&v270_14_cursor.path()[(v270_14_origin + 1)..(v270_14_origin + 2)]);
        let v273_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v273_2));
        let v273_4: Space = if map_kernels::has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
        drop(v273_3);
        let v273_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v273_4));
        drop(v273_4);
        let v273_8: Space = if (&(v273_5)).is_empty() { Space::new() } else {
          let v274_6: Path = concat_path(&(v272_6),&v270_14_cursor.path()[(v270_14_origin + 1)..(v270_14_origin + 2)]);
          let mut v274_7 = Space::new();
          let mut v274_7_write = v274_7.write_zipper();
          for v274_7_byte in v270_14_cursor.child_mask().iter() {
            v270_14_cursor.descend_to_existing_byte(v274_7_byte);
            {
            let v275_2: Space = singleton(&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
            let v275_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v275_2));
            let v275_4: Space = if map_kernels::has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
            drop(v275_3);
            let v275_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v275_4));
            drop(v275_4);
            let v275_8: Space = if (&(v275_5)).is_empty() { Space::new() } else {
              let v276_6: Path = concat_path(&(v274_6),&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
              let v276_7: Space = routine_28(c, &(v276_6), &v270_14_cursor);
              map_map_kernels::compose(&(v275_5),&(v276_7))
            };
            drop(v275_5);
            let v275_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v275_2));
            drop(v275_2);
            let v275_10: Space = if map_kernels::has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
            drop(v275_9);
            let v275_12: Space = if (&(v275_10)).is_empty() { Space::new() } else {
              let v277_6: Path = concat_path(&(v274_6),&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
              let v277_11: Space = routine_29(c, &(v277_6), &v270_14_cursor);
              drop(v277_6);
              map_map_kernels::compose(&(v275_10),&(v277_11))
            };
            drop(v275_10);
            let v275_13: Space = map_map_kernels::unite(&(v275_8),&(v275_12));
            join_wrapped_into(&mut v274_7_write,&((v275_13).read_zipper()),&[]);
            }
            v270_14_cursor.ascend(1);
          }
          drop(v274_7_write);
          map_map_kernels::compose(&(v273_5),&(v274_7))
        };
        drop(v273_5);
        let v273_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v273_2));
        drop(v273_2);
        let v273_10: Space = if map_kernels::has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
        drop(v273_9);
        let v273_12: Space = if (&(v273_10)).is_empty() { Space::new() } else {
          let v278_6: Path = concat_path(&(v272_6),&v270_14_cursor.path()[(v270_14_origin + 1)..(v270_14_origin + 2)]);
          let mut v278_11 = Space::new();
          let mut v278_11_write = v278_11.write_zipper();
          for v278_11_byte in v270_14_cursor.child_mask().iter() {
            v270_14_cursor.descend_to_existing_byte(v278_11_byte);
            {
            let v279_2: Space = singleton(&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
            let v279_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v279_2));
            let v279_4: Space = if map_kernels::has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
            drop(v279_3);
            let v279_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v279_4));
            drop(v279_4);
            let v279_8: Space = if (&(v279_5)).is_empty() { Space::new() } else {
              let v280_6: Path = concat_path(&(v278_6),&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
              let v280_7: Space = routine_28(c, &(v280_6), &v270_14_cursor);
              map_map_kernels::compose(&(v279_5),&(v280_7))
            };
            drop(v279_5);
            let v279_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v279_2));
            drop(v279_2);
            let v279_10: Space = if map_kernels::has_head(&(v279_9)) { singleton(&[]) } else { Space::new() };
            drop(v279_9);
            let v279_12: Space = if (&(v279_10)).is_empty() { Space::new() } else {
              let v281_6: Path = concat_path(&(v278_6),&v270_14_cursor.path()[(v270_14_origin + 2)..(v270_14_origin + 3)]);
              let v281_11: Space = routine_15(c, &(v281_6), &v270_14_cursor);
              drop(v281_6);
              map_map_kernels::compose(&(v279_10),&(v281_11))
            };
            drop(v279_10);
            let v279_13: Space = map_map_kernels::unite(&(v279_8),&(v279_12));
            join_wrapped_into(&mut v278_11_write,&((v279_13).read_zipper()),&[]);
            }
            v270_14_cursor.ascend(1);
          }
          drop(v278_11_write);
          drop(v278_6);
          map_map_kernels::compose(&(v273_10),&(v278_11))
        };
        drop(v273_10);
        let v273_13: Space = map_map_kernels::unite(&(v273_8),&(v273_12));
        join_wrapped_into(&mut v272_7_write,&((v273_13).read_zipper()),&[]);
        }
        v270_14_cursor.ascend(1);
      }
      drop(v272_7_write);
      drop(v272_6);
      map_map_kernels::compose(&(v271_5),&(v272_7))
    };
    drop(v271_5);
    let v271_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v271_2));
    drop(v271_2);
    let v271_10: Space = if map_kernels::has_head(&(v271_9)) { singleton(&[]) } else { Space::new() };
    drop(v271_9);
    let v271_11: Space = map_view_kernels::compose(&(v271_10),&v270_14_cursor);
    drop(v271_10);
    let v271_12: Space = map_map_kernels::unite(&(v271_8),&(v271_11));
    drop(v271_11);
    join_wrapped_into(&mut v270_14_write,&((v271_12).read_zipper()),&[]);
    }
    v270_14_cursor.ascend(1);
  }
  drop(v270_14_cursor);
  drop(v270_14_write);
  (v270_14).clone()
}

fn routine_15(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  (&(*s0)).make_map()
}

fn routine_16(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v283_20 = Space::new();
  let mut v283_20_write = v283_20.write_zipper();
  let mut v283_20_cursor = (*s0).read_zipper();
  let v283_20_origin = v283_20_cursor.path().len();
  for v283_20_byte in v283_20_cursor.child_mask().iter() {
    v283_20_cursor.descend_to_existing_byte(v283_20_byte);
    {
    let v284_2: Space = singleton(&v283_20_cursor.path()[v283_20_origin..(v283_20_origin + 1)]);
    let v284_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v284_2));
    let v284_4: Space = if map_kernels::has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v284_4));
    drop(v284_4);
    let v284_8: Space = if (&(v284_5)).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&v283_20_cursor.path()[v283_20_origin..(v283_20_origin + 1)]);
      let mut v285_7 = Space::new();
      let mut v285_7_write = v285_7.write_zipper();
      for v285_7_byte in v283_20_cursor.child_mask().iter() {
        v283_20_cursor.descend_to_existing_byte(v285_7_byte);
        {
        let v286_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
        let v286_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v286_2));
        let v286_4: Space = if map_kernels::has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v286_4));
        drop(v286_4);
        let v286_8: Space = if (&(v286_5)).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v285_6),&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
          let mut v287_7 = Space::new();
          let mut v287_7_write = v287_7.write_zipper();
          for v287_7_byte in v283_20_cursor.child_mask().iter() {
            v283_20_cursor.descend_to_existing_byte(v287_7_byte);
            {
            let v288_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
            let v288_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v288_2));
            let v288_4: Space = if map_kernels::has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (&(v288_5)).is_empty() { Space::new() } else {
              let v289_6: Path = concat_path(&(v287_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v289_7: Space = routine_30(c, &(v289_6), &v283_20_cursor);
              map_map_kernels::compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if map_kernels::has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (&(v288_10)).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v287_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v290_11: Space = routine_31(c, &(v290_6), &v283_20_cursor);
              drop(v290_6);
              map_map_kernels::compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = map_map_kernels::unite(&(v288_8),&(v288_12));
            join_wrapped_into(&mut v287_7_write,&((v288_13).read_zipper()),&[]);
            }
            v283_20_cursor.ascend(1);
          }
          drop(v287_7_write);
          map_map_kernels::compose(&(v286_5),&(v287_7))
        };
        drop(v286_5);
        let v286_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v286_2));
        drop(v286_2);
        let v286_10: Space = if map_kernels::has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
        drop(v286_9);
        let v286_12: Space = if (&(v286_10)).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v285_6),&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
          let mut v291_11 = Space::new();
          let mut v291_11_write = v291_11.write_zipper();
          for v291_11_byte in v283_20_cursor.child_mask().iter() {
            v283_20_cursor.descend_to_existing_byte(v291_11_byte);
            {
            let v292_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
            let v292_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v292_2));
            let v292_4: Space = if map_kernels::has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
            drop(v292_3);
            let v292_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v292_4));
            drop(v292_4);
            let v292_8: Space = if (&(v292_5)).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v291_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v293_7: Space = routine_30(c, &(v293_6), &v283_20_cursor);
              map_map_kernels::compose(&(v292_5),&(v293_7))
            };
            drop(v292_5);
            let v292_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v292_2));
            drop(v292_2);
            let v292_10: Space = if map_kernels::has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
            drop(v292_9);
            let v292_12: Space = if (&(v292_10)).is_empty() { Space::new() } else {
              let v294_6: Path = concat_path(&(v291_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v294_11: Space = routine_12(c, &(v294_6), &v283_20_cursor);
              drop(v294_6);
              map_map_kernels::compose(&(v292_10),&(v294_11))
            };
            drop(v292_10);
            let v292_13: Space = map_map_kernels::unite(&(v292_8),&(v292_12));
            join_wrapped_into(&mut v291_11_write,&((v292_13).read_zipper()),&[]);
            }
            v283_20_cursor.ascend(1);
          }
          drop(v291_11_write);
          drop(v291_6);
          map_map_kernels::compose(&(v286_10),&(v291_11))
        };
        drop(v286_10);
        let v286_13: Space = map_map_kernels::unite(&(v286_8),&(v286_12));
        join_wrapped_into(&mut v285_7_write,&((v286_13).read_zipper()),&[]);
        }
        v283_20_cursor.ascend(1);
      }
      drop(v285_7_write);
      map_map_kernels::compose(&(v284_5),&(v285_7))
    };
    drop(v284_5);
    let v284_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v284_2));
    drop(v284_2);
    let v284_10: Space = if map_kernels::has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
    drop(v284_9);
    let v284_12: Space = if (&(v284_10)).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&v283_20_cursor.path()[v283_20_origin..(v283_20_origin + 1)]);
      let mut v295_11 = Space::new();
      let mut v295_11_write = v295_11.write_zipper();
      for v295_11_byte in v283_20_cursor.child_mask().iter() {
        v283_20_cursor.descend_to_existing_byte(v295_11_byte);
        {
        let v296_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
        let v296_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v296_2));
        let v296_4: Space = if map_kernels::has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (&(v296_5)).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&v283_20_cursor.path()[(v283_20_origin + 1)..(v283_20_origin + 2)]);
          let mut v297_7 = Space::new();
          let mut v297_7_write = v297_7.write_zipper();
          for v297_7_byte in v283_20_cursor.child_mask().iter() {
            v283_20_cursor.descend_to_existing_byte(v297_7_byte);
            {
            let v298_2: Space = singleton(&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
            let v298_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v298_2));
            let v298_4: Space = if map_kernels::has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (&(v298_5)).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v299_7: Space = routine_30(c, &(v299_6), &v283_20_cursor);
              map_map_kernels::compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if map_kernels::has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (&(v298_10)).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&v283_20_cursor.path()[(v283_20_origin + 2)..(v283_20_origin + 3)]);
              let v300_11: Space = routine_31(c, &(v300_6), &v283_20_cursor);
              drop(v300_6);
              map_map_kernels::compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = map_map_kernels::unite(&(v298_8),&(v298_12));
            join_wrapped_into(&mut v297_7_write,&((v298_13).read_zipper()),&[]);
            }
            v283_20_cursor.ascend(1);
          }
          drop(v297_7_write);
          drop(v297_6);
          map_map_kernels::compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if map_kernels::has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_11: Space = map_view_kernels::compose(&(v296_10),&v283_20_cursor);
        drop(v296_10);
        let v296_12: Space = map_map_kernels::unite(&(v296_8),&(v296_11));
        drop(v296_11);
        join_wrapped_into(&mut v295_11_write,&((v296_12).read_zipper()),&[]);
        }
        v283_20_cursor.ascend(1);
      }
      drop(v295_11_write);
      drop(v295_6);
      map_map_kernels::compose(&(v284_10),&(v295_11))
    };
    drop(v284_10);
    let v284_13: Space = map_map_kernels::unite(&(v284_8),&(v284_12));
    join_wrapped_into(&mut v283_20_write,&((v284_13).read_zipper()),&[]);
    }
    v283_20_cursor.ascend(1);
  }
  drop(v283_20_cursor);
  drop(v283_20_write);
  (v283_20).clone()
}

fn routine_17(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v301_14 = Space::new();
  let mut v301_14_write = v301_14.write_zipper();
  let mut v301_14_cursor = (*s0).read_zipper();
  let v301_14_origin = v301_14_cursor.path().len();
  for v301_14_byte in v301_14_cursor.child_mask().iter() {
    v301_14_cursor.descend_to_existing_byte(v301_14_byte);
    {
    let v302_2: Space = singleton(&v301_14_cursor.path()[v301_14_origin..(v301_14_origin + 1)]);
    let v302_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v302_2));
    let v302_4: Space = if map_kernels::has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
    drop(v302_3);
    let v302_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v302_4));
    drop(v302_4);
    let v302_8: Space = if (&(v302_5)).is_empty() { Space::new() } else {
      let v303_6: Path = concat_path(&(*p0),&v301_14_cursor.path()[v301_14_origin..(v301_14_origin + 1)]);
      let mut v303_7 = Space::new();
      let mut v303_7_write = v303_7.write_zipper();
      for v303_7_byte in v301_14_cursor.child_mask().iter() {
        v301_14_cursor.descend_to_existing_byte(v303_7_byte);
        {
        let v304_2: Space = singleton(&v301_14_cursor.path()[(v301_14_origin + 1)..(v301_14_origin + 2)]);
        let v304_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v304_2));
        let v304_4: Space = if map_kernels::has_head(&(v304_3)) { singleton(&[]) } else { Space::new() };
        drop(v304_3);
        let v304_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v304_4));
        drop(v304_4);
        let v304_8: Space = if (&(v304_5)).is_empty() { Space::new() } else {
          let v305_6: Path = concat_path(&(v303_6),&v301_14_cursor.path()[(v301_14_origin + 1)..(v301_14_origin + 2)]);
          let mut v305_7 = Space::new();
          let mut v305_7_write = v305_7.write_zipper();
          for v305_7_byte in v301_14_cursor.child_mask().iter() {
            v301_14_cursor.descend_to_existing_byte(v305_7_byte);
            {
            let v306_2: Space = singleton(&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
            let v306_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v306_2));
            let v306_4: Space = if map_kernels::has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
            drop(v306_3);
            let v306_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v306_4));
            drop(v306_4);
            let v306_8: Space = if (&(v306_5)).is_empty() { Space::new() } else {
              let v307_6: Path = concat_path(&(v305_6),&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
              let v307_7: Space = routine_30(c, &(v307_6), &v301_14_cursor);
              map_map_kernels::compose(&(v306_5),&(v307_7))
            };
            drop(v306_5);
            let v306_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v306_2));
            drop(v306_2);
            let v306_10: Space = if map_kernels::has_head(&(v306_9)) { singleton(&[]) } else { Space::new() };
            drop(v306_9);
            let v306_12: Space = if (&(v306_10)).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v305_6),&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
              let v308_11: Space = routine_31(c, &(v308_6), &v301_14_cursor);
              drop(v308_6);
              map_map_kernels::compose(&(v306_10),&(v308_11))
            };
            drop(v306_10);
            let v306_13: Space = map_map_kernels::unite(&(v306_8),&(v306_12));
            join_wrapped_into(&mut v305_7_write,&((v306_13).read_zipper()),&[]);
            }
            v301_14_cursor.ascend(1);
          }
          drop(v305_7_write);
          map_map_kernels::compose(&(v304_5),&(v305_7))
        };
        drop(v304_5);
        let v304_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v304_2));
        drop(v304_2);
        let v304_10: Space = if map_kernels::has_head(&(v304_9)) { singleton(&[]) } else { Space::new() };
        drop(v304_9);
        let v304_12: Space = if (&(v304_10)).is_empty() { Space::new() } else {
          let v309_6: Path = concat_path(&(v303_6),&v301_14_cursor.path()[(v301_14_origin + 1)..(v301_14_origin + 2)]);
          let mut v309_11 = Space::new();
          let mut v309_11_write = v309_11.write_zipper();
          for v309_11_byte in v301_14_cursor.child_mask().iter() {
            v301_14_cursor.descend_to_existing_byte(v309_11_byte);
            {
            let v310_2: Space = singleton(&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
            let v310_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v310_2));
            let v310_4: Space = if map_kernels::has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
            drop(v310_3);
            let v310_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v310_4));
            drop(v310_4);
            let v310_8: Space = if (&(v310_5)).is_empty() { Space::new() } else {
              let v311_6: Path = concat_path(&(v309_6),&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
              let v311_7: Space = routine_30(c, &(v311_6), &v301_14_cursor);
              map_map_kernels::compose(&(v310_5),&(v311_7))
            };
            drop(v310_5);
            let v310_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v310_2));
            drop(v310_2);
            let v310_10: Space = if map_kernels::has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
            drop(v310_9);
            let v310_12: Space = if (&(v310_10)).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v309_6),&v301_14_cursor.path()[(v301_14_origin + 2)..(v301_14_origin + 3)]);
              let v312_11: Space = routine_12(c, &(v312_6), &v301_14_cursor);
              drop(v312_6);
              map_map_kernels::compose(&(v310_10),&(v312_11))
            };
            drop(v310_10);
            let v310_13: Space = map_map_kernels::unite(&(v310_8),&(v310_12));
            join_wrapped_into(&mut v309_11_write,&((v310_13).read_zipper()),&[]);
            }
            v301_14_cursor.ascend(1);
          }
          drop(v309_11_write);
          drop(v309_6);
          map_map_kernels::compose(&(v304_10),&(v309_11))
        };
        drop(v304_10);
        let v304_13: Space = map_map_kernels::unite(&(v304_8),&(v304_12));
        join_wrapped_into(&mut v303_7_write,&((v304_13).read_zipper()),&[]);
        }
        v301_14_cursor.ascend(1);
      }
      drop(v303_7_write);
      drop(v303_6);
      map_map_kernels::compose(&(v302_5),&(v303_7))
    };
    drop(v302_5);
    let v302_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v302_2));
    drop(v302_2);
    let v302_10: Space = if map_kernels::has_head(&(v302_9)) { singleton(&[]) } else { Space::new() };
    drop(v302_9);
    let v302_11: Space = map_view_kernels::compose(&(v302_10),&v301_14_cursor);
    drop(v302_10);
    let v302_12: Space = map_map_kernels::unite(&(v302_8),&(v302_11));
    drop(v302_11);
    join_wrapped_into(&mut v301_14_write,&((v302_12).read_zipper()),&[]);
    }
    v301_14_cursor.ascend(1);
  }
  drop(v301_14_cursor);
  drop(v301_14_write);
  (v301_14).clone()
}

fn routine_18(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v313_20 = Space::new();
  let mut v313_20_write = v313_20.write_zipper();
  let mut v313_20_cursor = (*s0).read_zipper();
  let v313_20_origin = v313_20_cursor.path().len();
  for v313_20_byte in v313_20_cursor.child_mask().iter() {
    v313_20_cursor.descend_to_existing_byte(v313_20_byte);
    {
    let v314_2: Space = singleton(&v313_20_cursor.path()[v313_20_origin..(v313_20_origin + 1)]);
    let v314_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v314_2));
    let v314_4: Space = if map_kernels::has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
    drop(v314_3);
    let v314_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v314_4));
    drop(v314_4);
    let v314_8: Space = if (&(v314_5)).is_empty() { Space::new() } else {
      let v315_6: Path = concat_path(&(*p0),&v313_20_cursor.path()[v313_20_origin..(v313_20_origin + 1)]);
      let mut v315_7 = Space::new();
      let mut v315_7_write = v315_7.write_zipper();
      for v315_7_byte in v313_20_cursor.child_mask().iter() {
        v313_20_cursor.descend_to_existing_byte(v315_7_byte);
        {
        let v316_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
        let v316_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v316_2));
        let v316_4: Space = if map_kernels::has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
        drop(v316_3);
        let v316_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v316_4));
        drop(v316_4);
        let v316_8: Space = if (&(v316_5)).is_empty() { Space::new() } else {
          let v317_6: Path = concat_path(&(v315_6),&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
          let mut v317_7 = Space::new();
          let mut v317_7_write = v317_7.write_zipper();
          for v317_7_byte in v313_20_cursor.child_mask().iter() {
            v313_20_cursor.descend_to_existing_byte(v317_7_byte);
            {
            let v318_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
            let v318_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v318_2));
            let v318_4: Space = if map_kernels::has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
            drop(v318_3);
            let v318_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v318_4));
            drop(v318_4);
            let v318_8: Space = if (&(v318_5)).is_empty() { Space::new() } else {
              let v319_6: Path = concat_path(&(v317_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v319_7: Space = routine_32(c, &(v319_6), &v313_20_cursor);
              map_map_kernels::compose(&(v318_5),&(v319_7))
            };
            drop(v318_5);
            let v318_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v318_2));
            drop(v318_2);
            let v318_10: Space = if map_kernels::has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
            drop(v318_9);
            let v318_12: Space = if (&(v318_10)).is_empty() { Space::new() } else {
              let v320_6: Path = concat_path(&(v317_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v320_11: Space = routine_33(c, &(v320_6), &v313_20_cursor);
              drop(v320_6);
              map_map_kernels::compose(&(v318_10),&(v320_11))
            };
            drop(v318_10);
            let v318_13: Space = map_map_kernels::unite(&(v318_8),&(v318_12));
            join_wrapped_into(&mut v317_7_write,&((v318_13).read_zipper()),&[]);
            }
            v313_20_cursor.ascend(1);
          }
          drop(v317_7_write);
          map_map_kernels::compose(&(v316_5),&(v317_7))
        };
        drop(v316_5);
        let v316_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v316_2));
        drop(v316_2);
        let v316_10: Space = if map_kernels::has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
        drop(v316_9);
        let v316_12: Space = if (&(v316_10)).is_empty() { Space::new() } else {
          let v321_6: Path = concat_path(&(v315_6),&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
          let mut v321_11 = Space::new();
          let mut v321_11_write = v321_11.write_zipper();
          for v321_11_byte in v313_20_cursor.child_mask().iter() {
            v313_20_cursor.descend_to_existing_byte(v321_11_byte);
            {
            let v322_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
            let v322_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v322_2));
            let v322_4: Space = if map_kernels::has_head(&(v322_3)) { singleton(&[]) } else { Space::new() };
            drop(v322_3);
            let v322_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v322_4));
            drop(v322_4);
            let v322_8: Space = if (&(v322_5)).is_empty() { Space::new() } else {
              let v323_6: Path = concat_path(&(v321_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v323_7: Space = routine_32(c, &(v323_6), &v313_20_cursor);
              map_map_kernels::compose(&(v322_5),&(v323_7))
            };
            drop(v322_5);
            let v322_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v322_2));
            drop(v322_2);
            let v322_10: Space = if map_kernels::has_head(&(v322_9)) { singleton(&[]) } else { Space::new() };
            drop(v322_9);
            let v322_12: Space = if (&(v322_10)).is_empty() { Space::new() } else {
              let v324_6: Path = concat_path(&(v321_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v324_11: Space = routine_15(c, &(v324_6), &v313_20_cursor);
              drop(v324_6);
              map_map_kernels::compose(&(v322_10),&(v324_11))
            };
            drop(v322_10);
            let v322_13: Space = map_map_kernels::unite(&(v322_8),&(v322_12));
            join_wrapped_into(&mut v321_11_write,&((v322_13).read_zipper()),&[]);
            }
            v313_20_cursor.ascend(1);
          }
          drop(v321_11_write);
          drop(v321_6);
          map_map_kernels::compose(&(v316_10),&(v321_11))
        };
        drop(v316_10);
        let v316_13: Space = map_map_kernels::unite(&(v316_8),&(v316_12));
        join_wrapped_into(&mut v315_7_write,&((v316_13).read_zipper()),&[]);
        }
        v313_20_cursor.ascend(1);
      }
      drop(v315_7_write);
      map_map_kernels::compose(&(v314_5),&(v315_7))
    };
    drop(v314_5);
    let v314_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v314_2));
    drop(v314_2);
    let v314_10: Space = if map_kernels::has_head(&(v314_9)) { singleton(&[]) } else { Space::new() };
    drop(v314_9);
    let v314_12: Space = if (&(v314_10)).is_empty() { Space::new() } else {
      let v325_6: Path = concat_path(&(*p0),&v313_20_cursor.path()[v313_20_origin..(v313_20_origin + 1)]);
      let mut v325_11 = Space::new();
      let mut v325_11_write = v325_11.write_zipper();
      for v325_11_byte in v313_20_cursor.child_mask().iter() {
        v313_20_cursor.descend_to_existing_byte(v325_11_byte);
        {
        let v326_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
        let v326_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v326_2));
        let v326_4: Space = if map_kernels::has_head(&(v326_3)) { singleton(&[]) } else { Space::new() };
        drop(v326_3);
        let v326_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v326_4));
        drop(v326_4);
        let v326_8: Space = if (&(v326_5)).is_empty() { Space::new() } else {
          let v327_6: Path = concat_path(&(v325_6),&v313_20_cursor.path()[(v313_20_origin + 1)..(v313_20_origin + 2)]);
          let mut v327_7 = Space::new();
          let mut v327_7_write = v327_7.write_zipper();
          for v327_7_byte in v313_20_cursor.child_mask().iter() {
            v313_20_cursor.descend_to_existing_byte(v327_7_byte);
            {
            let v328_2: Space = singleton(&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
            let v328_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v328_2));
            let v328_4: Space = if map_kernels::has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
            drop(v328_3);
            let v328_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v328_4));
            drop(v328_4);
            let v328_8: Space = if (&(v328_5)).is_empty() { Space::new() } else {
              let v329_6: Path = concat_path(&(v327_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v329_7: Space = routine_32(c, &(v329_6), &v313_20_cursor);
              map_map_kernels::compose(&(v328_5),&(v329_7))
            };
            drop(v328_5);
            let v328_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v328_2));
            drop(v328_2);
            let v328_10: Space = if map_kernels::has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
            drop(v328_9);
            let v328_12: Space = if (&(v328_10)).is_empty() { Space::new() } else {
              let v330_6: Path = concat_path(&(v327_6),&v313_20_cursor.path()[(v313_20_origin + 2)..(v313_20_origin + 3)]);
              let v330_11: Space = routine_33(c, &(v330_6), &v313_20_cursor);
              drop(v330_6);
              map_map_kernels::compose(&(v328_10),&(v330_11))
            };
            drop(v328_10);
            let v328_13: Space = map_map_kernels::unite(&(v328_8),&(v328_12));
            join_wrapped_into(&mut v327_7_write,&((v328_13).read_zipper()),&[]);
            }
            v313_20_cursor.ascend(1);
          }
          drop(v327_7_write);
          drop(v327_6);
          map_map_kernels::compose(&(v326_5),&(v327_7))
        };
        drop(v326_5);
        let v326_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v326_2));
        drop(v326_2);
        let v326_10: Space = if map_kernels::has_head(&(v326_9)) { singleton(&[]) } else { Space::new() };
        drop(v326_9);
        let v326_11: Space = map_view_kernels::compose(&(v326_10),&v313_20_cursor);
        drop(v326_10);
        let v326_12: Space = map_map_kernels::unite(&(v326_8),&(v326_11));
        drop(v326_11);
        join_wrapped_into(&mut v325_11_write,&((v326_12).read_zipper()),&[]);
        }
        v313_20_cursor.ascend(1);
      }
      drop(v325_11_write);
      drop(v325_6);
      map_map_kernels::compose(&(v314_10),&(v325_11))
    };
    drop(v314_10);
    let v314_13: Space = map_map_kernels::unite(&(v314_8),&(v314_12));
    join_wrapped_into(&mut v313_20_write,&((v314_13).read_zipper()),&[]);
    }
    v313_20_cursor.ascend(1);
  }
  drop(v313_20_cursor);
  drop(v313_20_write);
  (v313_20).clone()
}

fn routine_19(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v331_14 = Space::new();
  let mut v331_14_write = v331_14.write_zipper();
  let mut v331_14_cursor = (*s0).read_zipper();
  let v331_14_origin = v331_14_cursor.path().len();
  for v331_14_byte in v331_14_cursor.child_mask().iter() {
    v331_14_cursor.descend_to_existing_byte(v331_14_byte);
    {
    let v332_2: Space = singleton(&v331_14_cursor.path()[v331_14_origin..(v331_14_origin + 1)]);
    let v332_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v332_2));
    let v332_4: Space = if map_kernels::has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
    drop(v332_3);
    let v332_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v332_4));
    drop(v332_4);
    let v332_8: Space = if (&(v332_5)).is_empty() { Space::new() } else {
      let v333_6: Path = concat_path(&(*p0),&v331_14_cursor.path()[v331_14_origin..(v331_14_origin + 1)]);
      let mut v333_7 = Space::new();
      let mut v333_7_write = v333_7.write_zipper();
      for v333_7_byte in v331_14_cursor.child_mask().iter() {
        v331_14_cursor.descend_to_existing_byte(v333_7_byte);
        {
        let v334_2: Space = singleton(&v331_14_cursor.path()[(v331_14_origin + 1)..(v331_14_origin + 2)]);
        let v334_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v334_2));
        let v334_4: Space = if map_kernels::has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
        drop(v334_3);
        let v334_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v334_4));
        drop(v334_4);
        let v334_8: Space = if (&(v334_5)).is_empty() { Space::new() } else {
          let v335_6: Path = concat_path(&(v333_6),&v331_14_cursor.path()[(v331_14_origin + 1)..(v331_14_origin + 2)]);
          let mut v335_7 = Space::new();
          let mut v335_7_write = v335_7.write_zipper();
          for v335_7_byte in v331_14_cursor.child_mask().iter() {
            v331_14_cursor.descend_to_existing_byte(v335_7_byte);
            {
            let v336_2: Space = singleton(&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
            let v336_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v336_2));
            let v336_4: Space = if map_kernels::has_head(&(v336_3)) { singleton(&[]) } else { Space::new() };
            drop(v336_3);
            let v336_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v336_4));
            drop(v336_4);
            let v336_8: Space = if (&(v336_5)).is_empty() { Space::new() } else {
              let v337_6: Path = concat_path(&(v335_6),&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
              let v337_7: Space = routine_32(c, &(v337_6), &v331_14_cursor);
              map_map_kernels::compose(&(v336_5),&(v337_7))
            };
            drop(v336_5);
            let v336_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v336_2));
            drop(v336_2);
            let v336_10: Space = if map_kernels::has_head(&(v336_9)) { singleton(&[]) } else { Space::new() };
            drop(v336_9);
            let v336_12: Space = if (&(v336_10)).is_empty() { Space::new() } else {
              let v338_6: Path = concat_path(&(v335_6),&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
              let v338_11: Space = routine_33(c, &(v338_6), &v331_14_cursor);
              drop(v338_6);
              map_map_kernels::compose(&(v336_10),&(v338_11))
            };
            drop(v336_10);
            let v336_13: Space = map_map_kernels::unite(&(v336_8),&(v336_12));
            join_wrapped_into(&mut v335_7_write,&((v336_13).read_zipper()),&[]);
            }
            v331_14_cursor.ascend(1);
          }
          drop(v335_7_write);
          map_map_kernels::compose(&(v334_5),&(v335_7))
        };
        drop(v334_5);
        let v334_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v334_2));
        drop(v334_2);
        let v334_10: Space = if map_kernels::has_head(&(v334_9)) { singleton(&[]) } else { Space::new() };
        drop(v334_9);
        let v334_12: Space = if (&(v334_10)).is_empty() { Space::new() } else {
          let v339_6: Path = concat_path(&(v333_6),&v331_14_cursor.path()[(v331_14_origin + 1)..(v331_14_origin + 2)]);
          let mut v339_11 = Space::new();
          let mut v339_11_write = v339_11.write_zipper();
          for v339_11_byte in v331_14_cursor.child_mask().iter() {
            v331_14_cursor.descend_to_existing_byte(v339_11_byte);
            {
            let v340_2: Space = singleton(&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
            let v340_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v340_2));
            let v340_4: Space = if map_kernels::has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
            drop(v340_3);
            let v340_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v340_4));
            drop(v340_4);
            let v340_8: Space = if (&(v340_5)).is_empty() { Space::new() } else {
              let v341_6: Path = concat_path(&(v339_6),&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
              let v341_7: Space = routine_32(c, &(v341_6), &v331_14_cursor);
              map_map_kernels::compose(&(v340_5),&(v341_7))
            };
            drop(v340_5);
            let v340_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v340_2));
            drop(v340_2);
            let v340_10: Space = if map_kernels::has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
            drop(v340_9);
            let v340_12: Space = if (&(v340_10)).is_empty() { Space::new() } else {
              let v342_6: Path = concat_path(&(v339_6),&v331_14_cursor.path()[(v331_14_origin + 2)..(v331_14_origin + 3)]);
              let v342_11: Space = routine_15(c, &(v342_6), &v331_14_cursor);
              drop(v342_6);
              map_map_kernels::compose(&(v340_10),&(v342_11))
            };
            drop(v340_10);
            let v340_13: Space = map_map_kernels::unite(&(v340_8),&(v340_12));
            join_wrapped_into(&mut v339_11_write,&((v340_13).read_zipper()),&[]);
            }
            v331_14_cursor.ascend(1);
          }
          drop(v339_11_write);
          drop(v339_6);
          map_map_kernels::compose(&(v334_10),&(v339_11))
        };
        drop(v334_10);
        let v334_13: Space = map_map_kernels::unite(&(v334_8),&(v334_12));
        join_wrapped_into(&mut v333_7_write,&((v334_13).read_zipper()),&[]);
        }
        v331_14_cursor.ascend(1);
      }
      drop(v333_7_write);
      drop(v333_6);
      map_map_kernels::compose(&(v332_5),&(v333_7))
    };
    drop(v332_5);
    let v332_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v332_2));
    drop(v332_2);
    let v332_10: Space = if map_kernels::has_head(&(v332_9)) { singleton(&[]) } else { Space::new() };
    drop(v332_9);
    let v332_11: Space = map_view_kernels::compose(&(v332_10),&v331_14_cursor);
    drop(v332_10);
    let v332_12: Space = map_map_kernels::unite(&(v332_8),&(v332_11));
    drop(v332_11);
    join_wrapped_into(&mut v331_14_write,&((v332_12).read_zipper()),&[]);
    }
    v331_14_cursor.ascend(1);
  }
  drop(v331_14_cursor);
  drop(v331_14_write);
  (v331_14).clone()
}

fn routine_20(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v343_34 = Space::new();
  let mut v343_34_write = v343_34.write_zipper();
  let mut v343_34_cursor = (*s0).read_zipper();
  let v343_34_origin = v343_34_cursor.path().len();
  for v343_34_byte in v343_34_cursor.child_mask().iter() {
    v343_34_cursor.descend_to_existing_byte(v343_34_byte);
    {
    let v344_2: Space = singleton(&v343_34_cursor.path()[v343_34_origin..(v343_34_origin + 1)]);
    let v344_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v344_2));
    let v344_4: Space = if map_kernels::has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
    drop(v344_3);
    let v344_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v344_4));
    drop(v344_4);
    let v344_8: Space = if (&(v344_5)).is_empty() { Space::new() } else {
      let v345_6: Path = concat_path(&(*p0),&v343_34_cursor.path()[v343_34_origin..(v343_34_origin + 1)]);
      let mut v345_7 = Space::new();
      let mut v345_7_write = v345_7.write_zipper();
      for v345_7_byte in v343_34_cursor.child_mask().iter() {
        v343_34_cursor.descend_to_existing_byte(v345_7_byte);
        {
        let v346_2: Space = singleton(&v343_34_cursor.path()[(v343_34_origin + 1)..(v343_34_origin + 2)]);
        let v346_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v346_2));
        let v346_4: Space = if map_kernels::has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
        drop(v346_3);
        let v346_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v346_4));
        drop(v346_4);
        let v346_8: Space = if (&(v346_5)).is_empty() { Space::new() } else {
          let v347_6: Path = concat_path(&(v345_6),&v343_34_cursor.path()[(v343_34_origin + 1)..(v343_34_origin + 2)]);
          let mut v347_7 = Space::new();
          let mut v347_7_write = v347_7.write_zipper();
          for v347_7_byte in v343_34_cursor.child_mask().iter() {
            v343_34_cursor.descend_to_existing_byte(v347_7_byte);
            {
            let v348_2: Space = singleton(&v343_34_cursor.path()[(v343_34_origin + 2)..(v343_34_origin + 3)]);
            let v348_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v348_2));
            let v348_4: Space = if map_kernels::has_head(&(v348_3)) { singleton(&[]) } else { Space::new() };
            drop(v348_3);
            let v348_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v348_4));
            drop(v348_4);
            let v348_8: Space = if (&(v348_5)).is_empty() { Space::new() } else {
              let v349_6: Path = concat_path(&(v347_6),&v343_34_cursor.path()[(v343_34_origin + 2)..(v343_34_origin + 3)]);
              let v349_7: Space = routine_34(c, &(v349_6), &v343_34_cursor, &(*s1));
              map_map_kernels::compose(&(v348_5),&(v349_7))
            };
            drop(v348_5);
            let v348_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v348_2));
            drop(v348_2);
            let v348_10: Space = if map_kernels::has_head(&(v348_9)) { singleton(&[]) } else { Space::new() };
            drop(v348_9);
            let v348_12: Space = if (&(v348_10)).is_empty() { Space::new() } else {
              let v350_6: Path = concat_path(&(v347_6),&v343_34_cursor.path()[(v343_34_origin + 2)..(v343_34_origin + 3)]);
              let v350_11: Space = routine_35(c, &(v350_6), &v343_34_cursor, &(*s1));
              drop(v350_6);
              map_map_kernels::compose(&(v348_10),&(v350_11))
            };
            drop(v348_10);
            let v348_13: Space = map_map_kernels::unite(&(v348_8),&(v348_12));
            join_wrapped_into(&mut v347_7_write,&((v348_13).read_zipper()),&[]);
            }
            v343_34_cursor.ascend(1);
          }
          drop(v347_7_write);
          map_map_kernels::compose(&(v346_5),&(v347_7))
        };
        drop(v346_5);
        let v346_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v346_2));
        drop(v346_2);
        let v346_10: Space = if map_kernels::has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
        drop(v346_9);
        let v346_12: Space = if (&(v346_10)).is_empty() { Space::new() } else {
          let v351_6: Path = concat_path(&(v345_6),&v343_34_cursor.path()[(v343_34_origin + 1)..(v343_34_origin + 2)]);
          let mut v351_11 = Space::new();
          let mut v351_11_write = v351_11.write_zipper();
          for v351_11_byte in v343_34_cursor.child_mask().iter() {
            v343_34_cursor.descend_to_existing_byte(v351_11_byte);
            {
            let v352_2: Space = singleton(&v343_34_cursor.path()[(v343_34_origin + 2)..(v343_34_origin + 3)]);
            let v352_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v352_2));
            let v352_4: Space = if map_kernels::has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
            drop(v352_3);
            let v352_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v352_4));
            drop(v352_4);
            let v352_8: Space = if (&(v352_5)).is_empty() { Space::new() } else {
              let v353_6: Path = concat_path(&(v351_6),&v343_34_cursor.path()[(v343_34_origin + 2)..(v343_34_origin + 3)]);
              let v353_7: Space = routine_34(c, &(v353_6), &v343_34_cursor, &(*s1));
              map_map_kernels::compose(&(v352_5),&(v353_7))
            };
            drop(v352_5);
            let v352_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v352_2));
            drop(v352_2);
            let v352_10: Space = if map_kernels::has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
            drop(v352_9);
            let v352_12: Space = if (&(v352_10)).is_empty() { Space::new() } else {
              let v354_6: Path = concat_path(&(v351_6),&v343_34_cursor.path()[(v343_34_origin + 2)..(v343_34_origin + 3)]);
              let v354_11: Space = routine_3(c, &(v354_6), &v343_34_cursor, &(*s1));
              drop(v354_6);
              map_map_kernels::compose(&(v352_10),&(v354_11))
            };
            drop(v352_10);
            let v352_13: Space = map_map_kernels::unite(&(v352_8),&(v352_12));
            join_wrapped_into(&mut v351_11_write,&((v352_13).read_zipper()),&[]);
            }
            v343_34_cursor.ascend(1);
          }
          drop(v351_11_write);
          drop(v351_6);
          map_map_kernels::compose(&(v346_10),&(v351_11))
        };
        drop(v346_10);
        let v346_13: Space = map_map_kernels::unite(&(v346_8),&(v346_12));
        join_wrapped_into(&mut v345_7_write,&((v346_13).read_zipper()),&[]);
        }
        v343_34_cursor.ascend(1);
      }
      drop(v345_7_write);
      map_map_kernels::compose(&(v344_5),&(v345_7))
    };
    drop(v344_5);
    let v344_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v344_2));
    drop(v344_2);
    let v344_10: Space = if map_kernels::has_head(&(v344_9)) { singleton(&[]) } else { Space::new() };
    drop(v344_9);
    let v344_13: Space = if (&(v344_10)).is_empty() { Space::new() } else {
      let v355_6: Path = concat_path(&(*p0),&v343_34_cursor.path()[v343_34_origin..(v343_34_origin + 1)]);
      let mut v355_12 = Space::new();
      let mut v355_12_write = v355_12.write_zipper();
      for v355_12_byte in v343_34_cursor.child_mask().iter() {
        v343_34_cursor.descend_to_existing_byte(v355_12_byte);
        {
        let v356_2: Space = singleton(&v343_34_cursor.path()[(v343_34_origin + 1)..(v343_34_origin + 2)]);
        let v356_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v356_2));
        let v356_4: Space = if map_kernels::has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
        drop(v356_3);
        let v356_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v356_4));
        drop(v356_4);
        let v356_8: Space = if (&(v356_5)).is_empty() { Space::new() } else {
          let v357_6: Path = concat_path(&(v355_6),&v343_34_cursor.path()[(v343_34_origin + 1)..(v343_34_origin + 2)]);
          let mut v357_7 = Space::new();
          let mut v357_7_write = v357_7.write_zipper();
          for v357_7_byte in v343_34_cursor.child_mask().iter() {
            v343_34_cursor.descend_to_existing_byte(v357_7_byte);
            {
            let v358_2: Space = singleton(&v343_34_cursor.path()[(v343_34_origin + 2)..(v343_34_origin + 3)]);
            let v358_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v358_2));
            let v358_4: Space = if map_kernels::has_head(&(v358_3)) { singleton(&[]) } else { Space::new() };
            drop(v358_3);
            let v358_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v358_4));
            drop(v358_4);
            let v358_8: Space = if (&(v358_5)).is_empty() { Space::new() } else {
              let v359_6: Path = concat_path(&(v357_6),&v343_34_cursor.path()[(v343_34_origin + 2)..(v343_34_origin + 3)]);
              let v359_7: Space = routine_34(c, &(v359_6), &v343_34_cursor, &(*s1));
              map_map_kernels::compose(&(v358_5),&(v359_7))
            };
            drop(v358_5);
            let v358_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v358_2));
            drop(v358_2);
            let v358_10: Space = if map_kernels::has_head(&(v358_9)) { singleton(&[]) } else { Space::new() };
            drop(v358_9);
            let v358_12: Space = if (&(v358_10)).is_empty() { Space::new() } else {
              let v360_6: Path = concat_path(&(v357_6),&v343_34_cursor.path()[(v343_34_origin + 2)..(v343_34_origin + 3)]);
              let v360_11: Space = routine_35(c, &(v360_6), &v343_34_cursor, &(*s1));
              drop(v360_6);
              map_map_kernels::compose(&(v358_10),&(v360_11))
            };
            drop(v358_10);
            let v358_13: Space = map_map_kernels::unite(&(v358_8),&(v358_12));
            join_wrapped_into(&mut v357_7_write,&((v358_13).read_zipper()),&[]);
            }
            v343_34_cursor.ascend(1);
          }
          drop(v357_7_write);
          map_map_kernels::compose(&(v356_5),&(v357_7))
        };
        drop(v356_5);
        let v356_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v356_2));
        drop(v356_2);
        let v356_10: Space = if map_kernels::has_head(&(v356_9)) { singleton(&[]) } else { Space::new() };
        drop(v356_9);
        let v356_18: Space = if (&(v356_10)).is_empty() { Space::new() } else {
          let v361_12: Space = view_view_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v343_34_cursor.path()[v343_34_origin..(v343_34_origin + 1)]),&v343_34_cursor.path()[(v343_34_origin + 1)..(v343_34_origin + 2)])));
          let mut v361_13 = Space::new();
          let mut v361_13_write = v361_13.write_zipper();
          let mut v361_13_cursor = (v361_12).read_zipper();
          let v361_13_origin = v361_13_cursor.path().len();
          for v361_13_byte in v361_13_cursor.child_mask().iter() {
            v361_13_cursor.descend_to_existing_byte(v361_13_byte);
            {
            let v362_2: Space = singleton(&v361_13_cursor.path()[v361_13_origin..(v361_13_origin + 1)]);
            let v362_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v362_2));
            let v362_4: Space = if map_kernels::has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
            drop(v362_3);
            let v362_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v362_4));
            drop(v362_4);
            let v362_7: Space = if (&(v362_5)).is_empty() { Space::new() } else {
              let v363_6: Space = routine_6(c, &v361_13_cursor.path()[v361_13_origin..(v361_13_origin + 1)], &v361_13_cursor);
              map_map_kernels::compose(&(v362_5),&(v363_6))
            };
            drop(v362_5);
            let v362_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v362_2));
            drop(v362_2);
            let v362_9: Space = if map_kernels::has_head(&(v362_8)) { singleton(&[]) } else { Space::new() };
            drop(v362_8);
            let v362_11: Space = if (&(v362_9)).is_empty() { Space::new() } else {
              let v364_10: Space = routine_7(c, &v361_13_cursor.path()[v361_13_origin..(v361_13_origin + 1)], &v361_13_cursor);
              map_map_kernels::compose(&(v362_9),&(v364_10))
            };
            drop(v362_9);
            let v362_12: Space = map_map_kernels::unite(&(v362_7),&(v362_11));
            join_wrapped_into(&mut v361_13_write,&((v362_12).read_zipper()),&[]);
            }
            v361_13_cursor.ascend(1);
          }
          drop(v361_13_cursor);
          drop(v361_13_write);
          drop(v361_12);
          let v361_14: Space = view_map_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v361_13));
          let mut v361_15 = Space::new();
          let mut v361_15_write = v361_15.write_zipper();
          let mut v361_15_cursor = (v361_14).read_zipper();
          let v361_15_origin = v361_15_cursor.path().len();
          for v361_15_byte in v361_15_cursor.child_mask().iter() {
            v361_15_cursor.descend_to_existing_byte(v361_15_byte);
            {
            let v365_2: Space = singleton(&v361_15_cursor.path()[v361_15_origin..(v361_15_origin + 1)]);
            let v365_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v365_2));
            let v365_4: Space = if map_kernels::has_head(&(v365_3)) { singleton(&[]) } else { Space::new() };
            drop(v365_3);
            let v365_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v365_4));
            drop(v365_4);
            let v365_7: Space = if (&(v365_5)).is_empty() { Space::new() } else {
              let v366_6: Space = routine_8(c, &v361_15_cursor.path()[v361_15_origin..(v361_15_origin + 1)], &v361_15_cursor);
              map_map_kernels::compose(&(v365_5),&(v366_6))
            };
            drop(v365_5);
            let v365_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v365_2));
            drop(v365_2);
            let v365_9: Space = if map_kernels::has_head(&(v365_8)) { singleton(&[]) } else { Space::new() };
            drop(v365_8);
            let v365_11: Space = if (&(v365_9)).is_empty() { Space::new() } else {
              let v367_10: Space = routine_9(c, &v361_15_cursor.path()[v361_15_origin..(v361_15_origin + 1)], &v361_15_cursor);
              map_map_kernels::compose(&(v365_9),&(v367_10))
            };
            drop(v365_9);
            let v365_12: Space = map_map_kernels::unite(&(v365_7),&(v365_11));
            join_wrapped_into(&mut v361_15_write,&((v365_12).read_zipper()),&[]);
            }
            v361_15_cursor.ascend(1);
          }
          drop(v361_15_cursor);
          drop(v361_15_write);
          let v361_16: Space = map_view_kernels::subtract(&(v361_15),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v343_34_cursor.path()[v343_34_origin..(v343_34_origin + 1)]),&v343_34_cursor.path()[(v343_34_origin + 1)..(v343_34_origin + 2)])));
          let v361_17: Space = map_view_kernels::intersect(&(v361_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
          map_map_kernels::compose(&(v356_10),&(v361_17))
        };
        drop(v356_10);
        let v368_6: Path = concat_path(&(v355_6),&v343_34_cursor.path()[(v343_34_origin + 1)..(v343_34_origin + 2)]);
        let v356_19: Space = map_kernels::wrap(&(v356_18),&(v368_6));
        let v356_20: Space = map_map_kernels::unite(&(v356_8),&(v356_19));
        join_wrapped_into(&mut v355_12_write,&((v356_20).read_zipper()),&[]);
        }
        v343_34_cursor.ascend(1);
      }
      drop(v355_12_write);
      drop(v355_6);
      map_map_kernels::compose(&(v344_10),&(v355_12))
    };
    drop(v344_10);
    let v344_14: Space = map_map_kernels::unite(&(v344_8),&(v344_13));
    join_wrapped_into(&mut v343_34_write,&((v344_14).read_zipper()),&[]);
    }
    v343_34_cursor.ascend(1);
  }
  drop(v343_34_cursor);
  drop(v343_34_write);
  (v343_34).clone()
}

fn routine_21(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v369_40 = Space::new();
  let mut v369_40_write = v369_40.write_zipper();
  let mut v369_40_cursor = (*s0).read_zipper();
  let v369_40_origin = v369_40_cursor.path().len();
  for v369_40_byte in v369_40_cursor.child_mask().iter() {
    v369_40_cursor.descend_to_existing_byte(v369_40_byte);
    {
    let v370_2: Space = singleton(&v369_40_cursor.path()[v369_40_origin..(v369_40_origin + 1)]);
    let v370_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v370_2));
    let v370_4: Space = if map_kernels::has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
    drop(v370_3);
    let v370_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v370_4));
    drop(v370_4);
    let v370_8: Space = if (&(v370_5)).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&v369_40_cursor.path()[v369_40_origin..(v369_40_origin + 1)]);
      let mut v371_7 = Space::new();
      let mut v371_7_write = v371_7.write_zipper();
      for v371_7_byte in v369_40_cursor.child_mask().iter() {
        v369_40_cursor.descend_to_existing_byte(v371_7_byte);
        {
        let v372_2: Space = singleton(&v369_40_cursor.path()[(v369_40_origin + 1)..(v369_40_origin + 2)]);
        let v372_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v372_2));
        let v372_4: Space = if map_kernels::has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
        drop(v372_3);
        let v372_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v372_4));
        drop(v372_4);
        let v372_8: Space = if (&(v372_5)).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v371_6),&v369_40_cursor.path()[(v369_40_origin + 1)..(v369_40_origin + 2)]);
          let mut v373_7 = Space::new();
          let mut v373_7_write = v373_7.write_zipper();
          for v373_7_byte in v369_40_cursor.child_mask().iter() {
            v369_40_cursor.descend_to_existing_byte(v373_7_byte);
            {
            let v374_2: Space = singleton(&v369_40_cursor.path()[(v369_40_origin + 2)..(v369_40_origin + 3)]);
            let v374_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v374_2));
            let v374_4: Space = if map_kernels::has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
            drop(v374_3);
            let v374_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v374_4));
            drop(v374_4);
            let v374_8: Space = if (&(v374_5)).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v373_6),&v369_40_cursor.path()[(v369_40_origin + 2)..(v369_40_origin + 3)]);
              let v375_7: Space = routine_34(c, &(v375_6), &v369_40_cursor, &(*s1));
              map_map_kernels::compose(&(v374_5),&(v375_7))
            };
            drop(v374_5);
            let v374_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v374_2));
            drop(v374_2);
            let v374_10: Space = if map_kernels::has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
            drop(v374_9);
            let v374_12: Space = if (&(v374_10)).is_empty() { Space::new() } else {
              let v376_6: Path = concat_path(&(v373_6),&v369_40_cursor.path()[(v369_40_origin + 2)..(v369_40_origin + 3)]);
              let v376_11: Space = routine_35(c, &(v376_6), &v369_40_cursor, &(*s1));
              drop(v376_6);
              map_map_kernels::compose(&(v374_10),&(v376_11))
            };
            drop(v374_10);
            let v374_13: Space = map_map_kernels::unite(&(v374_8),&(v374_12));
            join_wrapped_into(&mut v373_7_write,&((v374_13).read_zipper()),&[]);
            }
            v369_40_cursor.ascend(1);
          }
          drop(v373_7_write);
          map_map_kernels::compose(&(v372_5),&(v373_7))
        };
        drop(v372_5);
        let v372_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v372_2));
        drop(v372_2);
        let v372_10: Space = if map_kernels::has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
        drop(v372_9);
        let v372_12: Space = if (&(v372_10)).is_empty() { Space::new() } else {
          let v377_6: Path = concat_path(&(v371_6),&v369_40_cursor.path()[(v369_40_origin + 1)..(v369_40_origin + 2)]);
          let mut v377_11 = Space::new();
          let mut v377_11_write = v377_11.write_zipper();
          for v377_11_byte in v369_40_cursor.child_mask().iter() {
            v369_40_cursor.descend_to_existing_byte(v377_11_byte);
            {
            let v378_2: Space = singleton(&v369_40_cursor.path()[(v369_40_origin + 2)..(v369_40_origin + 3)]);
            let v378_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v378_2));
            let v378_4: Space = if map_kernels::has_head(&(v378_3)) { singleton(&[]) } else { Space::new() };
            drop(v378_3);
            let v378_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v378_4));
            drop(v378_4);
            let v378_8: Space = if (&(v378_5)).is_empty() { Space::new() } else {
              let v379_6: Path = concat_path(&(v377_6),&v369_40_cursor.path()[(v369_40_origin + 2)..(v369_40_origin + 3)]);
              let v379_7: Space = routine_34(c, &(v379_6), &v369_40_cursor, &(*s1));
              map_map_kernels::compose(&(v378_5),&(v379_7))
            };
            drop(v378_5);
            let v378_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v378_2));
            drop(v378_2);
            let v378_10: Space = if map_kernels::has_head(&(v378_9)) { singleton(&[]) } else { Space::new() };
            drop(v378_9);
            let v378_12: Space = if (&(v378_10)).is_empty() { Space::new() } else {
              let v380_6: Path = concat_path(&(v377_6),&v369_40_cursor.path()[(v369_40_origin + 2)..(v369_40_origin + 3)]);
              let v380_11: Space = routine_3(c, &(v380_6), &v369_40_cursor, &(*s1));
              drop(v380_6);
              map_map_kernels::compose(&(v378_10),&(v380_11))
            };
            drop(v378_10);
            let v378_13: Space = map_map_kernels::unite(&(v378_8),&(v378_12));
            join_wrapped_into(&mut v377_11_write,&((v378_13).read_zipper()),&[]);
            }
            v369_40_cursor.ascend(1);
          }
          drop(v377_11_write);
          drop(v377_6);
          map_map_kernels::compose(&(v372_10),&(v377_11))
        };
        drop(v372_10);
        let v372_13: Space = map_map_kernels::unite(&(v372_8),&(v372_12));
        join_wrapped_into(&mut v371_7_write,&((v372_13).read_zipper()),&[]);
        }
        v369_40_cursor.ascend(1);
      }
      drop(v371_7_write);
      map_map_kernels::compose(&(v370_5),&(v371_7))
    };
    drop(v370_5);
    let v370_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v370_2));
    drop(v370_2);
    let v370_10: Space = if map_kernels::has_head(&(v370_9)) { singleton(&[]) } else { Space::new() };
    drop(v370_9);
    let v370_18: Space = if (&(v370_10)).is_empty() { Space::new() } else {
      let v381_12: Space = view_view_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v369_40_cursor.path()[v369_40_origin..(v369_40_origin + 1)])));
      let mut v381_13 = Space::new();
      let mut v381_13_write = v381_13.write_zipper();
      let mut v381_13_cursor = (v381_12).read_zipper();
      let v381_13_origin = v381_13_cursor.path().len();
      for v381_13_byte in v381_13_cursor.child_mask().iter() {
        v381_13_cursor.descend_to_existing_byte(v381_13_byte);
        {
        let v382_2: Space = singleton(&v381_13_cursor.path()[v381_13_origin..(v381_13_origin + 1)]);
        let v382_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v382_2));
        let v382_4: Space = if map_kernels::has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
        drop(v382_3);
        let v382_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v382_4));
        drop(v382_4);
        let v382_7: Space = if (&(v382_5)).is_empty() { Space::new() } else {
          let mut v383_6 = Space::new();
          let mut v383_6_write = v383_6.write_zipper();
          for v383_6_byte in v381_13_cursor.child_mask().iter() {
            v381_13_cursor.descend_to_existing_byte(v383_6_byte);
            {
            let v384_2: Space = singleton(&v381_13_cursor.path()[(v381_13_origin + 1)..(v381_13_origin + 2)]);
            let v384_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v384_2));
            let v384_4: Space = if map_kernels::has_head(&(v384_3)) { singleton(&[]) } else { Space::new() };
            drop(v384_3);
            let v384_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v384_4));
            drop(v384_4);
            let v384_8: Space = if (&(v384_5)).is_empty() { Space::new() } else {
              let v385_7: Space = routine_10(c, &v381_13_cursor.path()[v381_13_origin..(v381_13_origin + 2)], &v381_13_cursor);
              map_map_kernels::compose(&(v384_5),&(v385_7))
            };
            drop(v384_5);
            let v384_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v384_2));
            drop(v384_2);
            let v384_10: Space = if map_kernels::has_head(&(v384_9)) { singleton(&[]) } else { Space::new() };
            drop(v384_9);
            let v384_12: Space = if (&(v384_10)).is_empty() { Space::new() } else {
              let v386_11: Space = routine_11(c, &v381_13_cursor.path()[v381_13_origin..(v381_13_origin + 2)], &v381_13_cursor);
              map_map_kernels::compose(&(v384_10),&(v386_11))
            };
            drop(v384_10);
            let v384_13: Space = map_map_kernels::unite(&(v384_8),&(v384_12));
            join_wrapped_into(&mut v383_6_write,&((v384_13).read_zipper()),&[]);
            }
            v381_13_cursor.ascend(1);
          }
          drop(v383_6_write);
          map_map_kernels::compose(&(v382_5),&(v383_6))
        };
        drop(v382_5);
        let v382_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v382_2));
        drop(v382_2);
        let v382_9: Space = if map_kernels::has_head(&(v382_8)) { singleton(&[]) } else { Space::new() };
        drop(v382_8);
        let v382_11: Space = if (&(v382_9)).is_empty() { Space::new() } else {
          let mut v387_10 = Space::new();
          let mut v387_10_write = v387_10.write_zipper();
          for v387_10_byte in v381_13_cursor.child_mask().iter() {
            v381_13_cursor.descend_to_existing_byte(v387_10_byte);
            {
            let v388_2: Space = singleton(&v381_13_cursor.path()[(v381_13_origin + 1)..(v381_13_origin + 2)]);
            let v388_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v388_2));
            let v388_4: Space = if map_kernels::has_head(&(v388_3)) { singleton(&[]) } else { Space::new() };
            drop(v388_3);
            let v388_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v388_4));
            drop(v388_4);
            let v388_8: Space = if (&(v388_5)).is_empty() { Space::new() } else {
              let v389_7: Space = routine_10(c, &v381_13_cursor.path()[v381_13_origin..(v381_13_origin + 2)], &v381_13_cursor);
              map_map_kernels::compose(&(v388_5),&(v389_7))
            };
            drop(v388_5);
            let v388_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v388_2));
            drop(v388_2);
            let v388_10: Space = if map_kernels::has_head(&(v388_9)) { singleton(&[]) } else { Space::new() };
            drop(v388_9);
            let v388_12: Space = if (&(v388_10)).is_empty() { Space::new() } else {
              let v390_11: Space = routine_12(c, &v381_13_cursor.path()[v381_13_origin..(v381_13_origin + 2)], &v381_13_cursor);
              map_map_kernels::compose(&(v388_10),&(v390_11))
            };
            drop(v388_10);
            let v388_13: Space = map_map_kernels::unite(&(v388_8),&(v388_12));
            join_wrapped_into(&mut v387_10_write,&((v388_13).read_zipper()),&[]);
            }
            v381_13_cursor.ascend(1);
          }
          drop(v387_10_write);
          map_map_kernels::compose(&(v382_9),&(v387_10))
        };
        drop(v382_9);
        let v382_12: Space = map_map_kernels::unite(&(v382_7),&(v382_11));
        join_wrapped_into(&mut v381_13_write,&((v382_12).read_zipper()),&[]);
        }
        v381_13_cursor.ascend(1);
      }
      drop(v381_13_cursor);
      drop(v381_13_write);
      drop(v381_12);
      let v381_14: Space = view_map_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v381_13));
      let mut v381_15 = Space::new();
      let mut v381_15_write = v381_15.write_zipper();
      let mut v381_15_cursor = (v381_14).read_zipper();
      let v381_15_origin = v381_15_cursor.path().len();
      for v381_15_byte in v381_15_cursor.child_mask().iter() {
        v381_15_cursor.descend_to_existing_byte(v381_15_byte);
        {
        let v391_2: Space = singleton(&v381_15_cursor.path()[v381_15_origin..(v381_15_origin + 1)]);
        let v391_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v391_2));
        let v391_4: Space = if map_kernels::has_head(&(v391_3)) { singleton(&[]) } else { Space::new() };
        drop(v391_3);
        let v391_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v391_4));
        drop(v391_4);
        let v391_7: Space = if (&(v391_5)).is_empty() { Space::new() } else {
          let mut v392_6 = Space::new();
          let mut v392_6_write = v392_6.write_zipper();
          for v392_6_byte in v381_15_cursor.child_mask().iter() {
            v381_15_cursor.descend_to_existing_byte(v392_6_byte);
            {
            let v393_2: Space = singleton(&v381_15_cursor.path()[(v381_15_origin + 1)..(v381_15_origin + 2)]);
            let v393_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v393_2));
            let v393_4: Space = if map_kernels::has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
            drop(v393_3);
            let v393_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v393_4));
            drop(v393_4);
            let v393_8: Space = if (&(v393_5)).is_empty() { Space::new() } else {
              let v394_7: Space = routine_13(c, &v381_15_cursor.path()[v381_15_origin..(v381_15_origin + 2)], &v381_15_cursor);
              map_map_kernels::compose(&(v393_5),&(v394_7))
            };
            drop(v393_5);
            let v393_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v393_2));
            drop(v393_2);
            let v393_10: Space = if map_kernels::has_head(&(v393_9)) { singleton(&[]) } else { Space::new() };
            drop(v393_9);
            let v393_12: Space = if (&(v393_10)).is_empty() { Space::new() } else {
              let v395_11: Space = routine_14(c, &v381_15_cursor.path()[v381_15_origin..(v381_15_origin + 2)], &v381_15_cursor);
              map_map_kernels::compose(&(v393_10),&(v395_11))
            };
            drop(v393_10);
            let v393_13: Space = map_map_kernels::unite(&(v393_8),&(v393_12));
            join_wrapped_into(&mut v392_6_write,&((v393_13).read_zipper()),&[]);
            }
            v381_15_cursor.ascend(1);
          }
          drop(v392_6_write);
          map_map_kernels::compose(&(v391_5),&(v392_6))
        };
        drop(v391_5);
        let v391_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v391_2));
        drop(v391_2);
        let v391_9: Space = if map_kernels::has_head(&(v391_8)) { singleton(&[]) } else { Space::new() };
        drop(v391_8);
        let v391_11: Space = if (&(v391_9)).is_empty() { Space::new() } else {
          let mut v396_10 = Space::new();
          let mut v396_10_write = v396_10.write_zipper();
          for v396_10_byte in v381_15_cursor.child_mask().iter() {
            v381_15_cursor.descend_to_existing_byte(v396_10_byte);
            {
            let v397_2: Space = singleton(&v381_15_cursor.path()[(v381_15_origin + 1)..(v381_15_origin + 2)]);
            let v397_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v397_2));
            let v397_4: Space = if map_kernels::has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
            drop(v397_3);
            let v397_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v397_4));
            drop(v397_4);
            let v397_8: Space = if (&(v397_5)).is_empty() { Space::new() } else {
              let v398_7: Space = routine_13(c, &v381_15_cursor.path()[v381_15_origin..(v381_15_origin + 2)], &v381_15_cursor);
              map_map_kernels::compose(&(v397_5),&(v398_7))
            };
            drop(v397_5);
            let v397_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v397_2));
            drop(v397_2);
            let v397_10: Space = if map_kernels::has_head(&(v397_9)) { singleton(&[]) } else { Space::new() };
            drop(v397_9);
            let v397_12: Space = if (&(v397_10)).is_empty() { Space::new() } else {
              let v399_11: Space = routine_15(c, &v381_15_cursor.path()[v381_15_origin..(v381_15_origin + 2)], &v381_15_cursor);
              map_map_kernels::compose(&(v397_10),&(v399_11))
            };
            drop(v397_10);
            let v397_13: Space = map_map_kernels::unite(&(v397_8),&(v397_12));
            join_wrapped_into(&mut v396_10_write,&((v397_13).read_zipper()),&[]);
            }
            v381_15_cursor.ascend(1);
          }
          drop(v396_10_write);
          map_map_kernels::compose(&(v391_9),&(v396_10))
        };
        drop(v391_9);
        let v391_12: Space = map_map_kernels::unite(&(v391_7),&(v391_11));
        join_wrapped_into(&mut v381_15_write,&((v391_12).read_zipper()),&[]);
        }
        v381_15_cursor.ascend(1);
      }
      drop(v381_15_cursor);
      drop(v381_15_write);
      let v381_16: Space = map_view_kernels::subtract(&(v381_15),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v369_40_cursor.path()[v369_40_origin..(v369_40_origin + 1)])));
      let v381_17: Space = map_view_kernels::intersect(&(v381_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      map_map_kernels::compose(&(v370_10),&(v381_17))
    };
    drop(v370_10);
    let v400_6: Path = concat_path(&(*p0),&v369_40_cursor.path()[v369_40_origin..(v369_40_origin + 1)]);
    let v370_19: Space = map_kernels::wrap(&(v370_18),&(v400_6));
    let v370_20: Space = map_map_kernels::unite(&(v370_8),&(v370_19));
    join_wrapped_into(&mut v369_40_write,&((v370_20).read_zipper()),&[]);
    }
    v369_40_cursor.ascend(1);
  }
  drop(v369_40_cursor);
  drop(v369_40_write);
  (v369_40).clone()
}

fn routine_22(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v401_20 = Space::new();
  let mut v401_20_write = v401_20.write_zipper();
  let mut v401_20_cursor = (*s0).read_zipper();
  let v401_20_origin = v401_20_cursor.path().len();
  for v401_20_byte in v401_20_cursor.child_mask().iter() {
    v401_20_cursor.descend_to_existing_byte(v401_20_byte);
    {
    let v402_2: Space = singleton(&v401_20_cursor.path()[v401_20_origin..(v401_20_origin + 1)]);
    let v402_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v402_2));
    let v402_4: Space = if map_kernels::has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
    drop(v402_3);
    let v402_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v402_4));
    drop(v402_4);
    let v402_8: Space = if (&(v402_5)).is_empty() { Space::new() } else {
      let v403_6: Path = concat_path(&(*p0),&v401_20_cursor.path()[v401_20_origin..(v401_20_origin + 1)]);
      let mut v403_7 = Space::new();
      let mut v403_7_write = v403_7.write_zipper();
      for v403_7_byte in v401_20_cursor.child_mask().iter() {
        v401_20_cursor.descend_to_existing_byte(v403_7_byte);
        {
        let v404_2: Space = singleton(&v401_20_cursor.path()[(v401_20_origin + 1)..(v401_20_origin + 2)]);
        let v404_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v404_2));
        let v404_4: Space = if map_kernels::has_head(&(v404_3)) { singleton(&[]) } else { Space::new() };
        drop(v404_3);
        let v404_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v404_4));
        drop(v404_4);
        let v404_8: Space = if (&(v404_5)).is_empty() { Space::new() } else {
          let v405_6: Path = concat_path(&(v403_6),&v401_20_cursor.path()[(v401_20_origin + 1)..(v401_20_origin + 2)]);
          let mut v405_7 = Space::new();
          let mut v405_7_write = v405_7.write_zipper();
          for v405_7_byte in v401_20_cursor.child_mask().iter() {
            v401_20_cursor.descend_to_existing_byte(v405_7_byte);
            {
            let v406_2: Space = singleton(&v401_20_cursor.path()[(v401_20_origin + 2)..(v401_20_origin + 3)]);
            let v406_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v406_2));
            let v406_4: Space = if map_kernels::has_head(&(v406_3)) { singleton(&[]) } else { Space::new() };
            drop(v406_3);
            let v406_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v406_4));
            drop(v406_4);
            let v406_8: Space = if (&(v406_5)).is_empty() { Space::new() } else {
              let v407_6: Path = concat_path(&(v405_6),&v401_20_cursor.path()[(v401_20_origin + 2)..(v401_20_origin + 3)]);
              let v407_7: Space = routine_36(c, &(v407_6), &v401_20_cursor);
              map_map_kernels::compose(&(v406_5),&(v407_7))
            };
            drop(v406_5);
            let v406_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v406_2));
            drop(v406_2);
            let v406_10: Space = if map_kernels::has_head(&(v406_9)) { singleton(&[]) } else { Space::new() };
            drop(v406_9);
            let v406_12: Space = if (&(v406_10)).is_empty() { Space::new() } else {
              let v408_6: Path = concat_path(&(v405_6),&v401_20_cursor.path()[(v401_20_origin + 2)..(v401_20_origin + 3)]);
              let v408_11: Space = routine_37(c, &(v408_6), &v401_20_cursor);
              drop(v408_6);
              map_map_kernels::compose(&(v406_10),&(v408_11))
            };
            drop(v406_10);
            let v406_13: Space = map_map_kernels::unite(&(v406_8),&(v406_12));
            join_wrapped_into(&mut v405_7_write,&((v406_13).read_zipper()),&[]);
            }
            v401_20_cursor.ascend(1);
          }
          drop(v405_7_write);
          map_map_kernels::compose(&(v404_5),&(v405_7))
        };
        drop(v404_5);
        let v404_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v404_2));
        drop(v404_2);
        let v404_10: Space = if map_kernels::has_head(&(v404_9)) { singleton(&[]) } else { Space::new() };
        drop(v404_9);
        let v404_12: Space = if (&(v404_10)).is_empty() { Space::new() } else {
          let v409_6: Path = concat_path(&(v403_6),&v401_20_cursor.path()[(v401_20_origin + 1)..(v401_20_origin + 2)]);
          let mut v409_11 = Space::new();
          let mut v409_11_write = v409_11.write_zipper();
          for v409_11_byte in v401_20_cursor.child_mask().iter() {
            v401_20_cursor.descend_to_existing_byte(v409_11_byte);
            {
            let v410_2: Space = singleton(&v401_20_cursor.path()[(v401_20_origin + 2)..(v401_20_origin + 3)]);
            let v410_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v410_2));
            let v410_4: Space = if map_kernels::has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
            drop(v410_3);
            let v410_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v410_4));
            drop(v410_4);
            let v410_8: Space = if (&(v410_5)).is_empty() { Space::new() } else {
              let v411_6: Path = concat_path(&(v409_6),&v401_20_cursor.path()[(v401_20_origin + 2)..(v401_20_origin + 3)]);
              let v411_7: Space = routine_36(c, &(v411_6), &v401_20_cursor);
              map_map_kernels::compose(&(v410_5),&(v411_7))
            };
            drop(v410_5);
            let v410_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v410_2));
            drop(v410_2);
            let v410_10: Space = if map_kernels::has_head(&(v410_9)) { singleton(&[]) } else { Space::new() };
            drop(v410_9);
            let v410_12: Space = if (&(v410_10)).is_empty() { Space::new() } else {
              let v412_6: Path = concat_path(&(v409_6),&v401_20_cursor.path()[(v401_20_origin + 2)..(v401_20_origin + 3)]);
              let v412_11: Space = routine_12(c, &(v412_6), &v401_20_cursor);
              drop(v412_6);
              map_map_kernels::compose(&(v410_10),&(v412_11))
            };
            drop(v410_10);
            let v410_13: Space = map_map_kernels::unite(&(v410_8),&(v410_12));
            join_wrapped_into(&mut v409_11_write,&((v410_13).read_zipper()),&[]);
            }
            v401_20_cursor.ascend(1);
          }
          drop(v409_11_write);
          drop(v409_6);
          map_map_kernels::compose(&(v404_10),&(v409_11))
        };
        drop(v404_10);
        let v404_13: Space = map_map_kernels::unite(&(v404_8),&(v404_12));
        join_wrapped_into(&mut v403_7_write,&((v404_13).read_zipper()),&[]);
        }
        v401_20_cursor.ascend(1);
      }
      drop(v403_7_write);
      map_map_kernels::compose(&(v402_5),&(v403_7))
    };
    drop(v402_5);
    let v402_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v402_2));
    drop(v402_2);
    let v402_10: Space = if map_kernels::has_head(&(v402_9)) { singleton(&[]) } else { Space::new() };
    drop(v402_9);
    let v402_12: Space = if (&(v402_10)).is_empty() { Space::new() } else {
      let v413_6: Path = concat_path(&(*p0),&v401_20_cursor.path()[v401_20_origin..(v401_20_origin + 1)]);
      let mut v413_11 = Space::new();
      let mut v413_11_write = v413_11.write_zipper();
      for v413_11_byte in v401_20_cursor.child_mask().iter() {
        v401_20_cursor.descend_to_existing_byte(v413_11_byte);
        {
        let v414_2: Space = singleton(&v401_20_cursor.path()[(v401_20_origin + 1)..(v401_20_origin + 2)]);
        let v414_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v414_2));
        let v414_4: Space = if map_kernels::has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
        drop(v414_3);
        let v414_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v414_4));
        drop(v414_4);
        let v414_8: Space = if (&(v414_5)).is_empty() { Space::new() } else {
          let v415_6: Path = concat_path(&(v413_6),&v401_20_cursor.path()[(v401_20_origin + 1)..(v401_20_origin + 2)]);
          let mut v415_7 = Space::new();
          let mut v415_7_write = v415_7.write_zipper();
          for v415_7_byte in v401_20_cursor.child_mask().iter() {
            v401_20_cursor.descend_to_existing_byte(v415_7_byte);
            {
            let v416_2: Space = singleton(&v401_20_cursor.path()[(v401_20_origin + 2)..(v401_20_origin + 3)]);
            let v416_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v416_2));
            let v416_4: Space = if map_kernels::has_head(&(v416_3)) { singleton(&[]) } else { Space::new() };
            drop(v416_3);
            let v416_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v416_4));
            drop(v416_4);
            let v416_8: Space = if (&(v416_5)).is_empty() { Space::new() } else {
              let v417_6: Path = concat_path(&(v415_6),&v401_20_cursor.path()[(v401_20_origin + 2)..(v401_20_origin + 3)]);
              let v417_7: Space = routine_36(c, &(v417_6), &v401_20_cursor);
              map_map_kernels::compose(&(v416_5),&(v417_7))
            };
            drop(v416_5);
            let v416_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v416_2));
            drop(v416_2);
            let v416_10: Space = if map_kernels::has_head(&(v416_9)) { singleton(&[]) } else { Space::new() };
            drop(v416_9);
            let v416_12: Space = if (&(v416_10)).is_empty() { Space::new() } else {
              let v418_6: Path = concat_path(&(v415_6),&v401_20_cursor.path()[(v401_20_origin + 2)..(v401_20_origin + 3)]);
              let v418_11: Space = routine_37(c, &(v418_6), &v401_20_cursor);
              drop(v418_6);
              map_map_kernels::compose(&(v416_10),&(v418_11))
            };
            drop(v416_10);
            let v416_13: Space = map_map_kernels::unite(&(v416_8),&(v416_12));
            join_wrapped_into(&mut v415_7_write,&((v416_13).read_zipper()),&[]);
            }
            v401_20_cursor.ascend(1);
          }
          drop(v415_7_write);
          drop(v415_6);
          map_map_kernels::compose(&(v414_5),&(v415_7))
        };
        drop(v414_5);
        let v414_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v414_2));
        drop(v414_2);
        let v414_10: Space = if map_kernels::has_head(&(v414_9)) { singleton(&[]) } else { Space::new() };
        drop(v414_9);
        let v414_11: Space = map_view_kernels::compose(&(v414_10),&v401_20_cursor);
        drop(v414_10);
        let v414_12: Space = map_map_kernels::unite(&(v414_8),&(v414_11));
        drop(v414_11);
        join_wrapped_into(&mut v413_11_write,&((v414_12).read_zipper()),&[]);
        }
        v401_20_cursor.ascend(1);
      }
      drop(v413_11_write);
      drop(v413_6);
      map_map_kernels::compose(&(v402_10),&(v413_11))
    };
    drop(v402_10);
    let v402_13: Space = map_map_kernels::unite(&(v402_8),&(v402_12));
    join_wrapped_into(&mut v401_20_write,&((v402_13).read_zipper()),&[]);
    }
    v401_20_cursor.ascend(1);
  }
  drop(v401_20_cursor);
  drop(v401_20_write);
  (v401_20).clone()
}

fn routine_23(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v419_14 = Space::new();
  let mut v419_14_write = v419_14.write_zipper();
  let mut v419_14_cursor = (*s0).read_zipper();
  let v419_14_origin = v419_14_cursor.path().len();
  for v419_14_byte in v419_14_cursor.child_mask().iter() {
    v419_14_cursor.descend_to_existing_byte(v419_14_byte);
    {
    let v420_2: Space = singleton(&v419_14_cursor.path()[v419_14_origin..(v419_14_origin + 1)]);
    let v420_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v420_2));
    let v420_4: Space = if map_kernels::has_head(&(v420_3)) { singleton(&[]) } else { Space::new() };
    drop(v420_3);
    let v420_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v420_4));
    drop(v420_4);
    let v420_8: Space = if (&(v420_5)).is_empty() { Space::new() } else {
      let v421_6: Path = concat_path(&(*p0),&v419_14_cursor.path()[v419_14_origin..(v419_14_origin + 1)]);
      let mut v421_7 = Space::new();
      let mut v421_7_write = v421_7.write_zipper();
      for v421_7_byte in v419_14_cursor.child_mask().iter() {
        v419_14_cursor.descend_to_existing_byte(v421_7_byte);
        {
        let v422_2: Space = singleton(&v419_14_cursor.path()[(v419_14_origin + 1)..(v419_14_origin + 2)]);
        let v422_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v422_2));
        let v422_4: Space = if map_kernels::has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
        drop(v422_3);
        let v422_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v422_4));
        drop(v422_4);
        let v422_8: Space = if (&(v422_5)).is_empty() { Space::new() } else {
          let v423_6: Path = concat_path(&(v421_6),&v419_14_cursor.path()[(v419_14_origin + 1)..(v419_14_origin + 2)]);
          let mut v423_7 = Space::new();
          let mut v423_7_write = v423_7.write_zipper();
          for v423_7_byte in v419_14_cursor.child_mask().iter() {
            v419_14_cursor.descend_to_existing_byte(v423_7_byte);
            {
            let v424_2: Space = singleton(&v419_14_cursor.path()[(v419_14_origin + 2)..(v419_14_origin + 3)]);
            let v424_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v424_2));
            let v424_4: Space = if map_kernels::has_head(&(v424_3)) { singleton(&[]) } else { Space::new() };
            drop(v424_3);
            let v424_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v424_4));
            drop(v424_4);
            let v424_8: Space = if (&(v424_5)).is_empty() { Space::new() } else {
              let v425_6: Path = concat_path(&(v423_6),&v419_14_cursor.path()[(v419_14_origin + 2)..(v419_14_origin + 3)]);
              let v425_7: Space = routine_36(c, &(v425_6), &v419_14_cursor);
              map_map_kernels::compose(&(v424_5),&(v425_7))
            };
            drop(v424_5);
            let v424_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v424_2));
            drop(v424_2);
            let v424_10: Space = if map_kernels::has_head(&(v424_9)) { singleton(&[]) } else { Space::new() };
            drop(v424_9);
            let v424_12: Space = if (&(v424_10)).is_empty() { Space::new() } else {
              let v426_6: Path = concat_path(&(v423_6),&v419_14_cursor.path()[(v419_14_origin + 2)..(v419_14_origin + 3)]);
              let v426_11: Space = routine_37(c, &(v426_6), &v419_14_cursor);
              drop(v426_6);
              map_map_kernels::compose(&(v424_10),&(v426_11))
            };
            drop(v424_10);
            let v424_13: Space = map_map_kernels::unite(&(v424_8),&(v424_12));
            join_wrapped_into(&mut v423_7_write,&((v424_13).read_zipper()),&[]);
            }
            v419_14_cursor.ascend(1);
          }
          drop(v423_7_write);
          map_map_kernels::compose(&(v422_5),&(v423_7))
        };
        drop(v422_5);
        let v422_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v422_2));
        drop(v422_2);
        let v422_10: Space = if map_kernels::has_head(&(v422_9)) { singleton(&[]) } else { Space::new() };
        drop(v422_9);
        let v422_12: Space = if (&(v422_10)).is_empty() { Space::new() } else {
          let v427_6: Path = concat_path(&(v421_6),&v419_14_cursor.path()[(v419_14_origin + 1)..(v419_14_origin + 2)]);
          let mut v427_11 = Space::new();
          let mut v427_11_write = v427_11.write_zipper();
          for v427_11_byte in v419_14_cursor.child_mask().iter() {
            v419_14_cursor.descend_to_existing_byte(v427_11_byte);
            {
            let v428_2: Space = singleton(&v419_14_cursor.path()[(v419_14_origin + 2)..(v419_14_origin + 3)]);
            let v428_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v428_2));
            let v428_4: Space = if map_kernels::has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
            drop(v428_3);
            let v428_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v428_4));
            drop(v428_4);
            let v428_8: Space = if (&(v428_5)).is_empty() { Space::new() } else {
              let v429_6: Path = concat_path(&(v427_6),&v419_14_cursor.path()[(v419_14_origin + 2)..(v419_14_origin + 3)]);
              let v429_7: Space = routine_36(c, &(v429_6), &v419_14_cursor);
              map_map_kernels::compose(&(v428_5),&(v429_7))
            };
            drop(v428_5);
            let v428_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v428_2));
            drop(v428_2);
            let v428_10: Space = if map_kernels::has_head(&(v428_9)) { singleton(&[]) } else { Space::new() };
            drop(v428_9);
            let v428_12: Space = if (&(v428_10)).is_empty() { Space::new() } else {
              let v430_6: Path = concat_path(&(v427_6),&v419_14_cursor.path()[(v419_14_origin + 2)..(v419_14_origin + 3)]);
              let v430_11: Space = routine_12(c, &(v430_6), &v419_14_cursor);
              drop(v430_6);
              map_map_kernels::compose(&(v428_10),&(v430_11))
            };
            drop(v428_10);
            let v428_13: Space = map_map_kernels::unite(&(v428_8),&(v428_12));
            join_wrapped_into(&mut v427_11_write,&((v428_13).read_zipper()),&[]);
            }
            v419_14_cursor.ascend(1);
          }
          drop(v427_11_write);
          drop(v427_6);
          map_map_kernels::compose(&(v422_10),&(v427_11))
        };
        drop(v422_10);
        let v422_13: Space = map_map_kernels::unite(&(v422_8),&(v422_12));
        join_wrapped_into(&mut v421_7_write,&((v422_13).read_zipper()),&[]);
        }
        v419_14_cursor.ascend(1);
      }
      drop(v421_7_write);
      drop(v421_6);
      map_map_kernels::compose(&(v420_5),&(v421_7))
    };
    drop(v420_5);
    let v420_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v420_2));
    drop(v420_2);
    let v420_10: Space = if map_kernels::has_head(&(v420_9)) { singleton(&[]) } else { Space::new() };
    drop(v420_9);
    let v420_11: Space = map_view_kernels::compose(&(v420_10),&v419_14_cursor);
    drop(v420_10);
    let v420_12: Space = map_map_kernels::unite(&(v420_8),&(v420_11));
    drop(v420_11);
    join_wrapped_into(&mut v419_14_write,&((v420_12).read_zipper()),&[]);
    }
    v419_14_cursor.ascend(1);
  }
  drop(v419_14_cursor);
  drop(v419_14_write);
  (v419_14).clone()
}

fn routine_24(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v431_20 = Space::new();
  let mut v431_20_write = v431_20.write_zipper();
  let mut v431_20_cursor = (*s0).read_zipper();
  let v431_20_origin = v431_20_cursor.path().len();
  for v431_20_byte in v431_20_cursor.child_mask().iter() {
    v431_20_cursor.descend_to_existing_byte(v431_20_byte);
    {
    let v432_2: Space = singleton(&v431_20_cursor.path()[v431_20_origin..(v431_20_origin + 1)]);
    let v432_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v432_2));
    let v432_4: Space = if map_kernels::has_head(&(v432_3)) { singleton(&[]) } else { Space::new() };
    drop(v432_3);
    let v432_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v432_4));
    drop(v432_4);
    let v432_8: Space = if (&(v432_5)).is_empty() { Space::new() } else {
      let v433_6: Path = concat_path(&(*p0),&v431_20_cursor.path()[v431_20_origin..(v431_20_origin + 1)]);
      let mut v433_7 = Space::new();
      let mut v433_7_write = v433_7.write_zipper();
      for v433_7_byte in v431_20_cursor.child_mask().iter() {
        v431_20_cursor.descend_to_existing_byte(v433_7_byte);
        {
        let v434_2: Space = singleton(&v431_20_cursor.path()[(v431_20_origin + 1)..(v431_20_origin + 2)]);
        let v434_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v434_2));
        let v434_4: Space = if map_kernels::has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
        drop(v434_3);
        let v434_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v434_4));
        drop(v434_4);
        let v434_8: Space = if (&(v434_5)).is_empty() { Space::new() } else {
          let v435_6: Path = concat_path(&(v433_6),&v431_20_cursor.path()[(v431_20_origin + 1)..(v431_20_origin + 2)]);
          let mut v435_7 = Space::new();
          let mut v435_7_write = v435_7.write_zipper();
          for v435_7_byte in v431_20_cursor.child_mask().iter() {
            v431_20_cursor.descend_to_existing_byte(v435_7_byte);
            {
            let v436_2: Space = singleton(&v431_20_cursor.path()[(v431_20_origin + 2)..(v431_20_origin + 3)]);
            let v436_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v436_2));
            let v436_4: Space = if map_kernels::has_head(&(v436_3)) { singleton(&[]) } else { Space::new() };
            drop(v436_3);
            let v436_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v436_4));
            drop(v436_4);
            let v436_8: Space = if (&(v436_5)).is_empty() { Space::new() } else {
              let v437_6: Path = concat_path(&(v435_6),&v431_20_cursor.path()[(v431_20_origin + 2)..(v431_20_origin + 3)]);
              let v437_7: Space = routine_38(c, &(v437_6), &v431_20_cursor);
              map_map_kernels::compose(&(v436_5),&(v437_7))
            };
            drop(v436_5);
            let v436_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v436_2));
            drop(v436_2);
            let v436_10: Space = if map_kernels::has_head(&(v436_9)) { singleton(&[]) } else { Space::new() };
            drop(v436_9);
            let v436_12: Space = if (&(v436_10)).is_empty() { Space::new() } else {
              let v438_6: Path = concat_path(&(v435_6),&v431_20_cursor.path()[(v431_20_origin + 2)..(v431_20_origin + 3)]);
              let v438_11: Space = routine_39(c, &(v438_6), &v431_20_cursor);
              drop(v438_6);
              map_map_kernels::compose(&(v436_10),&(v438_11))
            };
            drop(v436_10);
            let v436_13: Space = map_map_kernels::unite(&(v436_8),&(v436_12));
            join_wrapped_into(&mut v435_7_write,&((v436_13).read_zipper()),&[]);
            }
            v431_20_cursor.ascend(1);
          }
          drop(v435_7_write);
          map_map_kernels::compose(&(v434_5),&(v435_7))
        };
        drop(v434_5);
        let v434_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v434_2));
        drop(v434_2);
        let v434_10: Space = if map_kernels::has_head(&(v434_9)) { singleton(&[]) } else { Space::new() };
        drop(v434_9);
        let v434_12: Space = if (&(v434_10)).is_empty() { Space::new() } else {
          let v439_6: Path = concat_path(&(v433_6),&v431_20_cursor.path()[(v431_20_origin + 1)..(v431_20_origin + 2)]);
          let mut v439_11 = Space::new();
          let mut v439_11_write = v439_11.write_zipper();
          for v439_11_byte in v431_20_cursor.child_mask().iter() {
            v431_20_cursor.descend_to_existing_byte(v439_11_byte);
            {
            let v440_2: Space = singleton(&v431_20_cursor.path()[(v431_20_origin + 2)..(v431_20_origin + 3)]);
            let v440_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v440_2));
            let v440_4: Space = if map_kernels::has_head(&(v440_3)) { singleton(&[]) } else { Space::new() };
            drop(v440_3);
            let v440_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v440_4));
            drop(v440_4);
            let v440_8: Space = if (&(v440_5)).is_empty() { Space::new() } else {
              let v441_6: Path = concat_path(&(v439_6),&v431_20_cursor.path()[(v431_20_origin + 2)..(v431_20_origin + 3)]);
              let v441_7: Space = routine_38(c, &(v441_6), &v431_20_cursor);
              map_map_kernels::compose(&(v440_5),&(v441_7))
            };
            drop(v440_5);
            let v440_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v440_2));
            drop(v440_2);
            let v440_10: Space = if map_kernels::has_head(&(v440_9)) { singleton(&[]) } else { Space::new() };
            drop(v440_9);
            let v440_12: Space = if (&(v440_10)).is_empty() { Space::new() } else {
              let v442_6: Path = concat_path(&(v439_6),&v431_20_cursor.path()[(v431_20_origin + 2)..(v431_20_origin + 3)]);
              let v442_11: Space = routine_15(c, &(v442_6), &v431_20_cursor);
              drop(v442_6);
              map_map_kernels::compose(&(v440_10),&(v442_11))
            };
            drop(v440_10);
            let v440_13: Space = map_map_kernels::unite(&(v440_8),&(v440_12));
            join_wrapped_into(&mut v439_11_write,&((v440_13).read_zipper()),&[]);
            }
            v431_20_cursor.ascend(1);
          }
          drop(v439_11_write);
          drop(v439_6);
          map_map_kernels::compose(&(v434_10),&(v439_11))
        };
        drop(v434_10);
        let v434_13: Space = map_map_kernels::unite(&(v434_8),&(v434_12));
        join_wrapped_into(&mut v433_7_write,&((v434_13).read_zipper()),&[]);
        }
        v431_20_cursor.ascend(1);
      }
      drop(v433_7_write);
      map_map_kernels::compose(&(v432_5),&(v433_7))
    };
    drop(v432_5);
    let v432_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v432_2));
    drop(v432_2);
    let v432_10: Space = if map_kernels::has_head(&(v432_9)) { singleton(&[]) } else { Space::new() };
    drop(v432_9);
    let v432_12: Space = if (&(v432_10)).is_empty() { Space::new() } else {
      let v443_6: Path = concat_path(&(*p0),&v431_20_cursor.path()[v431_20_origin..(v431_20_origin + 1)]);
      let mut v443_11 = Space::new();
      let mut v443_11_write = v443_11.write_zipper();
      for v443_11_byte in v431_20_cursor.child_mask().iter() {
        v431_20_cursor.descend_to_existing_byte(v443_11_byte);
        {
        let v444_2: Space = singleton(&v431_20_cursor.path()[(v431_20_origin + 1)..(v431_20_origin + 2)]);
        let v444_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v444_2));
        let v444_4: Space = if map_kernels::has_head(&(v444_3)) { singleton(&[]) } else { Space::new() };
        drop(v444_3);
        let v444_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v444_4));
        drop(v444_4);
        let v444_8: Space = if (&(v444_5)).is_empty() { Space::new() } else {
          let v445_6: Path = concat_path(&(v443_6),&v431_20_cursor.path()[(v431_20_origin + 1)..(v431_20_origin + 2)]);
          let mut v445_7 = Space::new();
          let mut v445_7_write = v445_7.write_zipper();
          for v445_7_byte in v431_20_cursor.child_mask().iter() {
            v431_20_cursor.descend_to_existing_byte(v445_7_byte);
            {
            let v446_2: Space = singleton(&v431_20_cursor.path()[(v431_20_origin + 2)..(v431_20_origin + 3)]);
            let v446_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v446_2));
            let v446_4: Space = if map_kernels::has_head(&(v446_3)) { singleton(&[]) } else { Space::new() };
            drop(v446_3);
            let v446_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v446_4));
            drop(v446_4);
            let v446_8: Space = if (&(v446_5)).is_empty() { Space::new() } else {
              let v447_6: Path = concat_path(&(v445_6),&v431_20_cursor.path()[(v431_20_origin + 2)..(v431_20_origin + 3)]);
              let v447_7: Space = routine_38(c, &(v447_6), &v431_20_cursor);
              map_map_kernels::compose(&(v446_5),&(v447_7))
            };
            drop(v446_5);
            let v446_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v446_2));
            drop(v446_2);
            let v446_10: Space = if map_kernels::has_head(&(v446_9)) { singleton(&[]) } else { Space::new() };
            drop(v446_9);
            let v446_12: Space = if (&(v446_10)).is_empty() { Space::new() } else {
              let v448_6: Path = concat_path(&(v445_6),&v431_20_cursor.path()[(v431_20_origin + 2)..(v431_20_origin + 3)]);
              let v448_11: Space = routine_39(c, &(v448_6), &v431_20_cursor);
              drop(v448_6);
              map_map_kernels::compose(&(v446_10),&(v448_11))
            };
            drop(v446_10);
            let v446_13: Space = map_map_kernels::unite(&(v446_8),&(v446_12));
            join_wrapped_into(&mut v445_7_write,&((v446_13).read_zipper()),&[]);
            }
            v431_20_cursor.ascend(1);
          }
          drop(v445_7_write);
          drop(v445_6);
          map_map_kernels::compose(&(v444_5),&(v445_7))
        };
        drop(v444_5);
        let v444_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v444_2));
        drop(v444_2);
        let v444_10: Space = if map_kernels::has_head(&(v444_9)) { singleton(&[]) } else { Space::new() };
        drop(v444_9);
        let v444_11: Space = map_view_kernels::compose(&(v444_10),&v431_20_cursor);
        drop(v444_10);
        let v444_12: Space = map_map_kernels::unite(&(v444_8),&(v444_11));
        drop(v444_11);
        join_wrapped_into(&mut v443_11_write,&((v444_12).read_zipper()),&[]);
        }
        v431_20_cursor.ascend(1);
      }
      drop(v443_11_write);
      drop(v443_6);
      map_map_kernels::compose(&(v432_10),&(v443_11))
    };
    drop(v432_10);
    let v432_13: Space = map_map_kernels::unite(&(v432_8),&(v432_12));
    join_wrapped_into(&mut v431_20_write,&((v432_13).read_zipper()),&[]);
    }
    v431_20_cursor.ascend(1);
  }
  drop(v431_20_cursor);
  drop(v431_20_write);
  (v431_20).clone()
}

fn routine_25(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v449_14 = Space::new();
  let mut v449_14_write = v449_14.write_zipper();
  let mut v449_14_cursor = (*s0).read_zipper();
  let v449_14_origin = v449_14_cursor.path().len();
  for v449_14_byte in v449_14_cursor.child_mask().iter() {
    v449_14_cursor.descend_to_existing_byte(v449_14_byte);
    {
    let v450_2: Space = singleton(&v449_14_cursor.path()[v449_14_origin..(v449_14_origin + 1)]);
    let v450_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v450_2));
    let v450_4: Space = if map_kernels::has_head(&(v450_3)) { singleton(&[]) } else { Space::new() };
    drop(v450_3);
    let v450_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v450_4));
    drop(v450_4);
    let v450_8: Space = if (&(v450_5)).is_empty() { Space::new() } else {
      let v451_6: Path = concat_path(&(*p0),&v449_14_cursor.path()[v449_14_origin..(v449_14_origin + 1)]);
      let mut v451_7 = Space::new();
      let mut v451_7_write = v451_7.write_zipper();
      for v451_7_byte in v449_14_cursor.child_mask().iter() {
        v449_14_cursor.descend_to_existing_byte(v451_7_byte);
        {
        let v452_2: Space = singleton(&v449_14_cursor.path()[(v449_14_origin + 1)..(v449_14_origin + 2)]);
        let v452_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v452_2));
        let v452_4: Space = if map_kernels::has_head(&(v452_3)) { singleton(&[]) } else { Space::new() };
        drop(v452_3);
        let v452_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v452_4));
        drop(v452_4);
        let v452_8: Space = if (&(v452_5)).is_empty() { Space::new() } else {
          let v453_6: Path = concat_path(&(v451_6),&v449_14_cursor.path()[(v449_14_origin + 1)..(v449_14_origin + 2)]);
          let mut v453_7 = Space::new();
          let mut v453_7_write = v453_7.write_zipper();
          for v453_7_byte in v449_14_cursor.child_mask().iter() {
            v449_14_cursor.descend_to_existing_byte(v453_7_byte);
            {
            let v454_2: Space = singleton(&v449_14_cursor.path()[(v449_14_origin + 2)..(v449_14_origin + 3)]);
            let v454_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v454_2));
            let v454_4: Space = if map_kernels::has_head(&(v454_3)) { singleton(&[]) } else { Space::new() };
            drop(v454_3);
            let v454_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v454_4));
            drop(v454_4);
            let v454_8: Space = if (&(v454_5)).is_empty() { Space::new() } else {
              let v455_6: Path = concat_path(&(v453_6),&v449_14_cursor.path()[(v449_14_origin + 2)..(v449_14_origin + 3)]);
              let v455_7: Space = routine_38(c, &(v455_6), &v449_14_cursor);
              map_map_kernels::compose(&(v454_5),&(v455_7))
            };
            drop(v454_5);
            let v454_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v454_2));
            drop(v454_2);
            let v454_10: Space = if map_kernels::has_head(&(v454_9)) { singleton(&[]) } else { Space::new() };
            drop(v454_9);
            let v454_12: Space = if (&(v454_10)).is_empty() { Space::new() } else {
              let v456_6: Path = concat_path(&(v453_6),&v449_14_cursor.path()[(v449_14_origin + 2)..(v449_14_origin + 3)]);
              let v456_11: Space = routine_39(c, &(v456_6), &v449_14_cursor);
              drop(v456_6);
              map_map_kernels::compose(&(v454_10),&(v456_11))
            };
            drop(v454_10);
            let v454_13: Space = map_map_kernels::unite(&(v454_8),&(v454_12));
            join_wrapped_into(&mut v453_7_write,&((v454_13).read_zipper()),&[]);
            }
            v449_14_cursor.ascend(1);
          }
          drop(v453_7_write);
          map_map_kernels::compose(&(v452_5),&(v453_7))
        };
        drop(v452_5);
        let v452_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v452_2));
        drop(v452_2);
        let v452_10: Space = if map_kernels::has_head(&(v452_9)) { singleton(&[]) } else { Space::new() };
        drop(v452_9);
        let v452_12: Space = if (&(v452_10)).is_empty() { Space::new() } else {
          let v457_6: Path = concat_path(&(v451_6),&v449_14_cursor.path()[(v449_14_origin + 1)..(v449_14_origin + 2)]);
          let mut v457_11 = Space::new();
          let mut v457_11_write = v457_11.write_zipper();
          for v457_11_byte in v449_14_cursor.child_mask().iter() {
            v449_14_cursor.descend_to_existing_byte(v457_11_byte);
            {
            let v458_2: Space = singleton(&v449_14_cursor.path()[(v449_14_origin + 2)..(v449_14_origin + 3)]);
            let v458_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v458_2));
            let v458_4: Space = if map_kernels::has_head(&(v458_3)) { singleton(&[]) } else { Space::new() };
            drop(v458_3);
            let v458_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v458_4));
            drop(v458_4);
            let v458_8: Space = if (&(v458_5)).is_empty() { Space::new() } else {
              let v459_6: Path = concat_path(&(v457_6),&v449_14_cursor.path()[(v449_14_origin + 2)..(v449_14_origin + 3)]);
              let v459_7: Space = routine_38(c, &(v459_6), &v449_14_cursor);
              map_map_kernels::compose(&(v458_5),&(v459_7))
            };
            drop(v458_5);
            let v458_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v458_2));
            drop(v458_2);
            let v458_10: Space = if map_kernels::has_head(&(v458_9)) { singleton(&[]) } else { Space::new() };
            drop(v458_9);
            let v458_12: Space = if (&(v458_10)).is_empty() { Space::new() } else {
              let v460_6: Path = concat_path(&(v457_6),&v449_14_cursor.path()[(v449_14_origin + 2)..(v449_14_origin + 3)]);
              let v460_11: Space = routine_15(c, &(v460_6), &v449_14_cursor);
              drop(v460_6);
              map_map_kernels::compose(&(v458_10),&(v460_11))
            };
            drop(v458_10);
            let v458_13: Space = map_map_kernels::unite(&(v458_8),&(v458_12));
            join_wrapped_into(&mut v457_11_write,&((v458_13).read_zipper()),&[]);
            }
            v449_14_cursor.ascend(1);
          }
          drop(v457_11_write);
          drop(v457_6);
          map_map_kernels::compose(&(v452_10),&(v457_11))
        };
        drop(v452_10);
        let v452_13: Space = map_map_kernels::unite(&(v452_8),&(v452_12));
        join_wrapped_into(&mut v451_7_write,&((v452_13).read_zipper()),&[]);
        }
        v449_14_cursor.ascend(1);
      }
      drop(v451_7_write);
      drop(v451_6);
      map_map_kernels::compose(&(v450_5),&(v451_7))
    };
    drop(v450_5);
    let v450_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v450_2));
    drop(v450_2);
    let v450_10: Space = if map_kernels::has_head(&(v450_9)) { singleton(&[]) } else { Space::new() };
    drop(v450_9);
    let v450_11: Space = map_view_kernels::compose(&(v450_10),&v449_14_cursor);
    drop(v450_10);
    let v450_12: Space = map_map_kernels::unite(&(v450_8),&(v450_11));
    drop(v450_11);
    join_wrapped_into(&mut v449_14_write,&((v450_12).read_zipper()),&[]);
    }
    v449_14_cursor.ascend(1);
  }
  drop(v449_14_cursor);
  drop(v449_14_write);
  (v449_14).clone()
}

fn routine_26(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v461_20 = Space::new();
  let mut v461_20_write = v461_20.write_zipper();
  let mut v461_20_cursor = (*s0).read_zipper();
  let v461_20_origin = v461_20_cursor.path().len();
  for v461_20_byte in v461_20_cursor.child_mask().iter() {
    v461_20_cursor.descend_to_existing_byte(v461_20_byte);
    {
    let v462_2: Space = singleton(&v461_20_cursor.path()[v461_20_origin..(v461_20_origin + 1)]);
    let v462_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v462_2));
    let v462_4: Space = if map_kernels::has_head(&(v462_3)) { singleton(&[]) } else { Space::new() };
    drop(v462_3);
    let v462_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v462_4));
    drop(v462_4);
    let v462_8: Space = if (&(v462_5)).is_empty() { Space::new() } else {
      let v463_6: Path = concat_path(&(*p0),&v461_20_cursor.path()[v461_20_origin..(v461_20_origin + 1)]);
      let mut v463_7 = Space::new();
      let mut v463_7_write = v463_7.write_zipper();
      for v463_7_byte in v461_20_cursor.child_mask().iter() {
        v461_20_cursor.descend_to_existing_byte(v463_7_byte);
        {
        let v464_2: Space = singleton(&v461_20_cursor.path()[(v461_20_origin + 1)..(v461_20_origin + 2)]);
        let v464_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v464_2));
        let v464_4: Space = if map_kernels::has_head(&(v464_3)) { singleton(&[]) } else { Space::new() };
        drop(v464_3);
        let v464_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v464_4));
        drop(v464_4);
        let v464_8: Space = if (&(v464_5)).is_empty() { Space::new() } else {
          let v465_6: Path = concat_path(&(v463_6),&v461_20_cursor.path()[(v461_20_origin + 1)..(v461_20_origin + 2)]);
          let mut v465_7 = Space::new();
          let mut v465_7_write = v465_7.write_zipper();
          for v465_7_byte in v461_20_cursor.child_mask().iter() {
            v461_20_cursor.descend_to_existing_byte(v465_7_byte);
            {
            let v466_2: Space = singleton(&v461_20_cursor.path()[(v461_20_origin + 2)..(v461_20_origin + 3)]);
            let v466_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v466_2));
            let v466_4: Space = if map_kernels::has_head(&(v466_3)) { singleton(&[]) } else { Space::new() };
            drop(v466_3);
            let v466_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v466_4));
            drop(v466_4);
            let v466_8: Space = if (&(v466_5)).is_empty() { Space::new() } else {
              let v467_6: Path = concat_path(&(v465_6),&v461_20_cursor.path()[(v461_20_origin + 2)..(v461_20_origin + 3)]);
              let v467_7: Space = routine_40(c, &(v467_6), &v461_20_cursor);
              map_map_kernels::compose(&(v466_5),&(v467_7))
            };
            drop(v466_5);
            let v466_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v466_2));
            drop(v466_2);
            let v466_10: Space = if map_kernels::has_head(&(v466_9)) { singleton(&[]) } else { Space::new() };
            drop(v466_9);
            let v466_12: Space = if (&(v466_10)).is_empty() { Space::new() } else {
              let v468_6: Path = concat_path(&(v465_6),&v461_20_cursor.path()[(v461_20_origin + 2)..(v461_20_origin + 3)]);
              let v468_11: Space = routine_41(c, &(v468_6), &v461_20_cursor);
              drop(v468_6);
              map_map_kernels::compose(&(v466_10),&(v468_11))
            };
            drop(v466_10);
            let v466_13: Space = map_map_kernels::unite(&(v466_8),&(v466_12));
            join_wrapped_into(&mut v465_7_write,&((v466_13).read_zipper()),&[]);
            }
            v461_20_cursor.ascend(1);
          }
          drop(v465_7_write);
          map_map_kernels::compose(&(v464_5),&(v465_7))
        };
        drop(v464_5);
        let v464_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v464_2));
        drop(v464_2);
        let v464_10: Space = if map_kernels::has_head(&(v464_9)) { singleton(&[]) } else { Space::new() };
        drop(v464_9);
        let v464_12: Space = if (&(v464_10)).is_empty() { Space::new() } else {
          let v469_6: Path = concat_path(&(v463_6),&v461_20_cursor.path()[(v461_20_origin + 1)..(v461_20_origin + 2)]);
          let mut v469_11 = Space::new();
          let mut v469_11_write = v469_11.write_zipper();
          for v469_11_byte in v461_20_cursor.child_mask().iter() {
            v461_20_cursor.descend_to_existing_byte(v469_11_byte);
            {
            let v470_2: Space = singleton(&v461_20_cursor.path()[(v461_20_origin + 2)..(v461_20_origin + 3)]);
            let v470_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v470_2));
            let v470_4: Space = if map_kernels::has_head(&(v470_3)) { singleton(&[]) } else { Space::new() };
            drop(v470_3);
            let v470_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v470_4));
            drop(v470_4);
            let v470_8: Space = if (&(v470_5)).is_empty() { Space::new() } else {
              let v471_6: Path = concat_path(&(v469_6),&v461_20_cursor.path()[(v461_20_origin + 2)..(v461_20_origin + 3)]);
              let v471_7: Space = routine_40(c, &(v471_6), &v461_20_cursor);
              map_map_kernels::compose(&(v470_5),&(v471_7))
            };
            drop(v470_5);
            let v470_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v470_2));
            drop(v470_2);
            let v470_10: Space = if map_kernels::has_head(&(v470_9)) { singleton(&[]) } else { Space::new() };
            drop(v470_9);
            let v470_12: Space = if (&(v470_10)).is_empty() { Space::new() } else {
              let v472_6: Path = concat_path(&(v469_6),&v461_20_cursor.path()[(v461_20_origin + 2)..(v461_20_origin + 3)]);
              let v472_11: Space = routine_12(c, &(v472_6), &v461_20_cursor);
              drop(v472_6);
              map_map_kernels::compose(&(v470_10),&(v472_11))
            };
            drop(v470_10);
            let v470_13: Space = map_map_kernels::unite(&(v470_8),&(v470_12));
            join_wrapped_into(&mut v469_11_write,&((v470_13).read_zipper()),&[]);
            }
            v461_20_cursor.ascend(1);
          }
          drop(v469_11_write);
          drop(v469_6);
          map_map_kernels::compose(&(v464_10),&(v469_11))
        };
        drop(v464_10);
        let v464_13: Space = map_map_kernels::unite(&(v464_8),&(v464_12));
        join_wrapped_into(&mut v463_7_write,&((v464_13).read_zipper()),&[]);
        }
        v461_20_cursor.ascend(1);
      }
      drop(v463_7_write);
      map_map_kernels::compose(&(v462_5),&(v463_7))
    };
    drop(v462_5);
    let v462_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v462_2));
    drop(v462_2);
    let v462_10: Space = if map_kernels::has_head(&(v462_9)) { singleton(&[]) } else { Space::new() };
    drop(v462_9);
    let v462_12: Space = if (&(v462_10)).is_empty() { Space::new() } else {
      let v473_6: Path = concat_path(&(*p0),&v461_20_cursor.path()[v461_20_origin..(v461_20_origin + 1)]);
      let mut v473_11 = Space::new();
      let mut v473_11_write = v473_11.write_zipper();
      for v473_11_byte in v461_20_cursor.child_mask().iter() {
        v461_20_cursor.descend_to_existing_byte(v473_11_byte);
        {
        let v474_2: Space = singleton(&v461_20_cursor.path()[(v461_20_origin + 1)..(v461_20_origin + 2)]);
        let v474_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v474_2));
        let v474_4: Space = if map_kernels::has_head(&(v474_3)) { singleton(&[]) } else { Space::new() };
        drop(v474_3);
        let v474_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v474_4));
        drop(v474_4);
        let v474_8: Space = if (&(v474_5)).is_empty() { Space::new() } else {
          let v475_6: Path = concat_path(&(v473_6),&v461_20_cursor.path()[(v461_20_origin + 1)..(v461_20_origin + 2)]);
          let mut v475_7 = Space::new();
          let mut v475_7_write = v475_7.write_zipper();
          for v475_7_byte in v461_20_cursor.child_mask().iter() {
            v461_20_cursor.descend_to_existing_byte(v475_7_byte);
            {
            let v476_2: Space = singleton(&v461_20_cursor.path()[(v461_20_origin + 2)..(v461_20_origin + 3)]);
            let v476_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v476_2));
            let v476_4: Space = if map_kernels::has_head(&(v476_3)) { singleton(&[]) } else { Space::new() };
            drop(v476_3);
            let v476_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v476_4));
            drop(v476_4);
            let v476_8: Space = if (&(v476_5)).is_empty() { Space::new() } else {
              let v477_6: Path = concat_path(&(v475_6),&v461_20_cursor.path()[(v461_20_origin + 2)..(v461_20_origin + 3)]);
              let v477_7: Space = routine_40(c, &(v477_6), &v461_20_cursor);
              map_map_kernels::compose(&(v476_5),&(v477_7))
            };
            drop(v476_5);
            let v476_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v476_2));
            drop(v476_2);
            let v476_10: Space = if map_kernels::has_head(&(v476_9)) { singleton(&[]) } else { Space::new() };
            drop(v476_9);
            let v476_12: Space = if (&(v476_10)).is_empty() { Space::new() } else {
              let v478_6: Path = concat_path(&(v475_6),&v461_20_cursor.path()[(v461_20_origin + 2)..(v461_20_origin + 3)]);
              let v478_11: Space = routine_41(c, &(v478_6), &v461_20_cursor);
              drop(v478_6);
              map_map_kernels::compose(&(v476_10),&(v478_11))
            };
            drop(v476_10);
            let v476_13: Space = map_map_kernels::unite(&(v476_8),&(v476_12));
            join_wrapped_into(&mut v475_7_write,&((v476_13).read_zipper()),&[]);
            }
            v461_20_cursor.ascend(1);
          }
          drop(v475_7_write);
          drop(v475_6);
          map_map_kernels::compose(&(v474_5),&(v475_7))
        };
        drop(v474_5);
        let v474_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v474_2));
        drop(v474_2);
        let v474_10: Space = if map_kernels::has_head(&(v474_9)) { singleton(&[]) } else { Space::new() };
        drop(v474_9);
        let v474_11: Space = map_view_kernels::compose(&(v474_10),&v461_20_cursor);
        drop(v474_10);
        let v474_12: Space = map_map_kernels::unite(&(v474_8),&(v474_11));
        drop(v474_11);
        join_wrapped_into(&mut v473_11_write,&((v474_12).read_zipper()),&[]);
        }
        v461_20_cursor.ascend(1);
      }
      drop(v473_11_write);
      drop(v473_6);
      map_map_kernels::compose(&(v462_10),&(v473_11))
    };
    drop(v462_10);
    let v462_13: Space = map_map_kernels::unite(&(v462_8),&(v462_12));
    join_wrapped_into(&mut v461_20_write,&((v462_13).read_zipper()),&[]);
    }
    v461_20_cursor.ascend(1);
  }
  drop(v461_20_cursor);
  drop(v461_20_write);
  (v461_20).clone()
}

fn routine_27(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v479_14 = Space::new();
  let mut v479_14_write = v479_14.write_zipper();
  let mut v479_14_cursor = (*s0).read_zipper();
  let v479_14_origin = v479_14_cursor.path().len();
  for v479_14_byte in v479_14_cursor.child_mask().iter() {
    v479_14_cursor.descend_to_existing_byte(v479_14_byte);
    {
    let v480_2: Space = singleton(&v479_14_cursor.path()[v479_14_origin..(v479_14_origin + 1)]);
    let v480_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v480_2));
    let v480_4: Space = if map_kernels::has_head(&(v480_3)) { singleton(&[]) } else { Space::new() };
    drop(v480_3);
    let v480_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v480_4));
    drop(v480_4);
    let v480_8: Space = if (&(v480_5)).is_empty() { Space::new() } else {
      let v481_6: Path = concat_path(&(*p0),&v479_14_cursor.path()[v479_14_origin..(v479_14_origin + 1)]);
      let mut v481_7 = Space::new();
      let mut v481_7_write = v481_7.write_zipper();
      for v481_7_byte in v479_14_cursor.child_mask().iter() {
        v479_14_cursor.descend_to_existing_byte(v481_7_byte);
        {
        let v482_2: Space = singleton(&v479_14_cursor.path()[(v479_14_origin + 1)..(v479_14_origin + 2)]);
        let v482_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v482_2));
        let v482_4: Space = if map_kernels::has_head(&(v482_3)) { singleton(&[]) } else { Space::new() };
        drop(v482_3);
        let v482_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v482_4));
        drop(v482_4);
        let v482_8: Space = if (&(v482_5)).is_empty() { Space::new() } else {
          let v483_6: Path = concat_path(&(v481_6),&v479_14_cursor.path()[(v479_14_origin + 1)..(v479_14_origin + 2)]);
          let mut v483_7 = Space::new();
          let mut v483_7_write = v483_7.write_zipper();
          for v483_7_byte in v479_14_cursor.child_mask().iter() {
            v479_14_cursor.descend_to_existing_byte(v483_7_byte);
            {
            let v484_2: Space = singleton(&v479_14_cursor.path()[(v479_14_origin + 2)..(v479_14_origin + 3)]);
            let v484_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v484_2));
            let v484_4: Space = if map_kernels::has_head(&(v484_3)) { singleton(&[]) } else { Space::new() };
            drop(v484_3);
            let v484_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v484_4));
            drop(v484_4);
            let v484_8: Space = if (&(v484_5)).is_empty() { Space::new() } else {
              let v485_6: Path = concat_path(&(v483_6),&v479_14_cursor.path()[(v479_14_origin + 2)..(v479_14_origin + 3)]);
              let v485_7: Space = routine_40(c, &(v485_6), &v479_14_cursor);
              map_map_kernels::compose(&(v484_5),&(v485_7))
            };
            drop(v484_5);
            let v484_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v484_2));
            drop(v484_2);
            let v484_10: Space = if map_kernels::has_head(&(v484_9)) { singleton(&[]) } else { Space::new() };
            drop(v484_9);
            let v484_12: Space = if (&(v484_10)).is_empty() { Space::new() } else {
              let v486_6: Path = concat_path(&(v483_6),&v479_14_cursor.path()[(v479_14_origin + 2)..(v479_14_origin + 3)]);
              let v486_11: Space = routine_41(c, &(v486_6), &v479_14_cursor);
              drop(v486_6);
              map_map_kernels::compose(&(v484_10),&(v486_11))
            };
            drop(v484_10);
            let v484_13: Space = map_map_kernels::unite(&(v484_8),&(v484_12));
            join_wrapped_into(&mut v483_7_write,&((v484_13).read_zipper()),&[]);
            }
            v479_14_cursor.ascend(1);
          }
          drop(v483_7_write);
          map_map_kernels::compose(&(v482_5),&(v483_7))
        };
        drop(v482_5);
        let v482_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v482_2));
        drop(v482_2);
        let v482_10: Space = if map_kernels::has_head(&(v482_9)) { singleton(&[]) } else { Space::new() };
        drop(v482_9);
        let v482_12: Space = if (&(v482_10)).is_empty() { Space::new() } else {
          let v487_6: Path = concat_path(&(v481_6),&v479_14_cursor.path()[(v479_14_origin + 1)..(v479_14_origin + 2)]);
          let mut v487_11 = Space::new();
          let mut v487_11_write = v487_11.write_zipper();
          for v487_11_byte in v479_14_cursor.child_mask().iter() {
            v479_14_cursor.descend_to_existing_byte(v487_11_byte);
            {
            let v488_2: Space = singleton(&v479_14_cursor.path()[(v479_14_origin + 2)..(v479_14_origin + 3)]);
            let v488_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v488_2));
            let v488_4: Space = if map_kernels::has_head(&(v488_3)) { singleton(&[]) } else { Space::new() };
            drop(v488_3);
            let v488_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v488_4));
            drop(v488_4);
            let v488_8: Space = if (&(v488_5)).is_empty() { Space::new() } else {
              let v489_6: Path = concat_path(&(v487_6),&v479_14_cursor.path()[(v479_14_origin + 2)..(v479_14_origin + 3)]);
              let v489_7: Space = routine_40(c, &(v489_6), &v479_14_cursor);
              map_map_kernels::compose(&(v488_5),&(v489_7))
            };
            drop(v488_5);
            let v488_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v488_2));
            drop(v488_2);
            let v488_10: Space = if map_kernels::has_head(&(v488_9)) { singleton(&[]) } else { Space::new() };
            drop(v488_9);
            let v488_12: Space = if (&(v488_10)).is_empty() { Space::new() } else {
              let v490_6: Path = concat_path(&(v487_6),&v479_14_cursor.path()[(v479_14_origin + 2)..(v479_14_origin + 3)]);
              let v490_11: Space = routine_12(c, &(v490_6), &v479_14_cursor);
              drop(v490_6);
              map_map_kernels::compose(&(v488_10),&(v490_11))
            };
            drop(v488_10);
            let v488_13: Space = map_map_kernels::unite(&(v488_8),&(v488_12));
            join_wrapped_into(&mut v487_11_write,&((v488_13).read_zipper()),&[]);
            }
            v479_14_cursor.ascend(1);
          }
          drop(v487_11_write);
          drop(v487_6);
          map_map_kernels::compose(&(v482_10),&(v487_11))
        };
        drop(v482_10);
        let v482_13: Space = map_map_kernels::unite(&(v482_8),&(v482_12));
        join_wrapped_into(&mut v481_7_write,&((v482_13).read_zipper()),&[]);
        }
        v479_14_cursor.ascend(1);
      }
      drop(v481_7_write);
      drop(v481_6);
      map_map_kernels::compose(&(v480_5),&(v481_7))
    };
    drop(v480_5);
    let v480_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v480_2));
    drop(v480_2);
    let v480_10: Space = if map_kernels::has_head(&(v480_9)) { singleton(&[]) } else { Space::new() };
    drop(v480_9);
    let v480_11: Space = map_view_kernels::compose(&(v480_10),&v479_14_cursor);
    drop(v480_10);
    let v480_12: Space = map_map_kernels::unite(&(v480_8),&(v480_11));
    drop(v480_11);
    join_wrapped_into(&mut v479_14_write,&((v480_12).read_zipper()),&[]);
    }
    v479_14_cursor.ascend(1);
  }
  drop(v479_14_cursor);
  drop(v479_14_write);
  (v479_14).clone()
}

fn routine_28(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v491_20 = Space::new();
  let mut v491_20_write = v491_20.write_zipper();
  let mut v491_20_cursor = (*s0).read_zipper();
  let v491_20_origin = v491_20_cursor.path().len();
  for v491_20_byte in v491_20_cursor.child_mask().iter() {
    v491_20_cursor.descend_to_existing_byte(v491_20_byte);
    {
    let v492_2: Space = singleton(&v491_20_cursor.path()[v491_20_origin..(v491_20_origin + 1)]);
    let v492_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v492_2));
    let v492_4: Space = if map_kernels::has_head(&(v492_3)) { singleton(&[]) } else { Space::new() };
    drop(v492_3);
    let v492_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v492_4));
    drop(v492_4);
    let v492_8: Space = if (&(v492_5)).is_empty() { Space::new() } else {
      let v493_6: Path = concat_path(&(*p0),&v491_20_cursor.path()[v491_20_origin..(v491_20_origin + 1)]);
      let mut v493_7 = Space::new();
      let mut v493_7_write = v493_7.write_zipper();
      for v493_7_byte in v491_20_cursor.child_mask().iter() {
        v491_20_cursor.descend_to_existing_byte(v493_7_byte);
        {
        let v494_2: Space = singleton(&v491_20_cursor.path()[(v491_20_origin + 1)..(v491_20_origin + 2)]);
        let v494_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v494_2));
        let v494_4: Space = if map_kernels::has_head(&(v494_3)) { singleton(&[]) } else { Space::new() };
        drop(v494_3);
        let v494_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v494_4));
        drop(v494_4);
        let v494_8: Space = if (&(v494_5)).is_empty() { Space::new() } else {
          let v495_6: Path = concat_path(&(v493_6),&v491_20_cursor.path()[(v491_20_origin + 1)..(v491_20_origin + 2)]);
          let mut v495_7 = Space::new();
          let mut v495_7_write = v495_7.write_zipper();
          for v495_7_byte in v491_20_cursor.child_mask().iter() {
            v491_20_cursor.descend_to_existing_byte(v495_7_byte);
            {
            let v496_2: Space = singleton(&v491_20_cursor.path()[(v491_20_origin + 2)..(v491_20_origin + 3)]);
            let v496_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v496_2));
            let v496_4: Space = if map_kernels::has_head(&(v496_3)) { singleton(&[]) } else { Space::new() };
            drop(v496_3);
            let v496_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v496_4));
            drop(v496_4);
            let v496_8: Space = if (&(v496_5)).is_empty() { Space::new() } else {
              let v497_6: Path = concat_path(&(v495_6),&v491_20_cursor.path()[(v491_20_origin + 2)..(v491_20_origin + 3)]);
              let v497_7: Space = routine_42(c, &(v497_6), &v491_20_cursor);
              map_map_kernels::compose(&(v496_5),&(v497_7))
            };
            drop(v496_5);
            let v496_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v496_2));
            drop(v496_2);
            let v496_10: Space = if map_kernels::has_head(&(v496_9)) { singleton(&[]) } else { Space::new() };
            drop(v496_9);
            let v496_12: Space = if (&(v496_10)).is_empty() { Space::new() } else {
              let v498_6: Path = concat_path(&(v495_6),&v491_20_cursor.path()[(v491_20_origin + 2)..(v491_20_origin + 3)]);
              let v498_11: Space = routine_43(c, &(v498_6), &v491_20_cursor);
              drop(v498_6);
              map_map_kernels::compose(&(v496_10),&(v498_11))
            };
            drop(v496_10);
            let v496_13: Space = map_map_kernels::unite(&(v496_8),&(v496_12));
            join_wrapped_into(&mut v495_7_write,&((v496_13).read_zipper()),&[]);
            }
            v491_20_cursor.ascend(1);
          }
          drop(v495_7_write);
          map_map_kernels::compose(&(v494_5),&(v495_7))
        };
        drop(v494_5);
        let v494_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v494_2));
        drop(v494_2);
        let v494_10: Space = if map_kernels::has_head(&(v494_9)) { singleton(&[]) } else { Space::new() };
        drop(v494_9);
        let v494_12: Space = if (&(v494_10)).is_empty() { Space::new() } else {
          let v499_6: Path = concat_path(&(v493_6),&v491_20_cursor.path()[(v491_20_origin + 1)..(v491_20_origin + 2)]);
          let mut v499_11 = Space::new();
          let mut v499_11_write = v499_11.write_zipper();
          for v499_11_byte in v491_20_cursor.child_mask().iter() {
            v491_20_cursor.descend_to_existing_byte(v499_11_byte);
            {
            let v500_2: Space = singleton(&v491_20_cursor.path()[(v491_20_origin + 2)..(v491_20_origin + 3)]);
            let v500_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v500_2));
            let v500_4: Space = if map_kernels::has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
            drop(v500_3);
            let v500_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v500_4));
            drop(v500_4);
            let v500_8: Space = if (&(v500_5)).is_empty() { Space::new() } else {
              let v501_6: Path = concat_path(&(v499_6),&v491_20_cursor.path()[(v491_20_origin + 2)..(v491_20_origin + 3)]);
              let v501_7: Space = routine_42(c, &(v501_6), &v491_20_cursor);
              map_map_kernels::compose(&(v500_5),&(v501_7))
            };
            drop(v500_5);
            let v500_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v500_2));
            drop(v500_2);
            let v500_10: Space = if map_kernels::has_head(&(v500_9)) { singleton(&[]) } else { Space::new() };
            drop(v500_9);
            let v500_12: Space = if (&(v500_10)).is_empty() { Space::new() } else {
              let v502_6: Path = concat_path(&(v499_6),&v491_20_cursor.path()[(v491_20_origin + 2)..(v491_20_origin + 3)]);
              let v502_11: Space = routine_15(c, &(v502_6), &v491_20_cursor);
              drop(v502_6);
              map_map_kernels::compose(&(v500_10),&(v502_11))
            };
            drop(v500_10);
            let v500_13: Space = map_map_kernels::unite(&(v500_8),&(v500_12));
            join_wrapped_into(&mut v499_11_write,&((v500_13).read_zipper()),&[]);
            }
            v491_20_cursor.ascend(1);
          }
          drop(v499_11_write);
          drop(v499_6);
          map_map_kernels::compose(&(v494_10),&(v499_11))
        };
        drop(v494_10);
        let v494_13: Space = map_map_kernels::unite(&(v494_8),&(v494_12));
        join_wrapped_into(&mut v493_7_write,&((v494_13).read_zipper()),&[]);
        }
        v491_20_cursor.ascend(1);
      }
      drop(v493_7_write);
      map_map_kernels::compose(&(v492_5),&(v493_7))
    };
    drop(v492_5);
    let v492_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v492_2));
    drop(v492_2);
    let v492_10: Space = if map_kernels::has_head(&(v492_9)) { singleton(&[]) } else { Space::new() };
    drop(v492_9);
    let v492_12: Space = if (&(v492_10)).is_empty() { Space::new() } else {
      let v503_6: Path = concat_path(&(*p0),&v491_20_cursor.path()[v491_20_origin..(v491_20_origin + 1)]);
      let mut v503_11 = Space::new();
      let mut v503_11_write = v503_11.write_zipper();
      for v503_11_byte in v491_20_cursor.child_mask().iter() {
        v491_20_cursor.descend_to_existing_byte(v503_11_byte);
        {
        let v504_2: Space = singleton(&v491_20_cursor.path()[(v491_20_origin + 1)..(v491_20_origin + 2)]);
        let v504_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v504_2));
        let v504_4: Space = if map_kernels::has_head(&(v504_3)) { singleton(&[]) } else { Space::new() };
        drop(v504_3);
        let v504_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v504_4));
        drop(v504_4);
        let v504_8: Space = if (&(v504_5)).is_empty() { Space::new() } else {
          let v505_6: Path = concat_path(&(v503_6),&v491_20_cursor.path()[(v491_20_origin + 1)..(v491_20_origin + 2)]);
          let mut v505_7 = Space::new();
          let mut v505_7_write = v505_7.write_zipper();
          for v505_7_byte in v491_20_cursor.child_mask().iter() {
            v491_20_cursor.descend_to_existing_byte(v505_7_byte);
            {
            let v506_2: Space = singleton(&v491_20_cursor.path()[(v491_20_origin + 2)..(v491_20_origin + 3)]);
            let v506_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v506_2));
            let v506_4: Space = if map_kernels::has_head(&(v506_3)) { singleton(&[]) } else { Space::new() };
            drop(v506_3);
            let v506_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v506_4));
            drop(v506_4);
            let v506_8: Space = if (&(v506_5)).is_empty() { Space::new() } else {
              let v507_6: Path = concat_path(&(v505_6),&v491_20_cursor.path()[(v491_20_origin + 2)..(v491_20_origin + 3)]);
              let v507_7: Space = routine_42(c, &(v507_6), &v491_20_cursor);
              map_map_kernels::compose(&(v506_5),&(v507_7))
            };
            drop(v506_5);
            let v506_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v506_2));
            drop(v506_2);
            let v506_10: Space = if map_kernels::has_head(&(v506_9)) { singleton(&[]) } else { Space::new() };
            drop(v506_9);
            let v506_12: Space = if (&(v506_10)).is_empty() { Space::new() } else {
              let v508_6: Path = concat_path(&(v505_6),&v491_20_cursor.path()[(v491_20_origin + 2)..(v491_20_origin + 3)]);
              let v508_11: Space = routine_43(c, &(v508_6), &v491_20_cursor);
              drop(v508_6);
              map_map_kernels::compose(&(v506_10),&(v508_11))
            };
            drop(v506_10);
            let v506_13: Space = map_map_kernels::unite(&(v506_8),&(v506_12));
            join_wrapped_into(&mut v505_7_write,&((v506_13).read_zipper()),&[]);
            }
            v491_20_cursor.ascend(1);
          }
          drop(v505_7_write);
          drop(v505_6);
          map_map_kernels::compose(&(v504_5),&(v505_7))
        };
        drop(v504_5);
        let v504_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v504_2));
        drop(v504_2);
        let v504_10: Space = if map_kernels::has_head(&(v504_9)) { singleton(&[]) } else { Space::new() };
        drop(v504_9);
        let v504_11: Space = map_view_kernels::compose(&(v504_10),&v491_20_cursor);
        drop(v504_10);
        let v504_12: Space = map_map_kernels::unite(&(v504_8),&(v504_11));
        drop(v504_11);
        join_wrapped_into(&mut v503_11_write,&((v504_12).read_zipper()),&[]);
        }
        v491_20_cursor.ascend(1);
      }
      drop(v503_11_write);
      drop(v503_6);
      map_map_kernels::compose(&(v492_10),&(v503_11))
    };
    drop(v492_10);
    let v492_13: Space = map_map_kernels::unite(&(v492_8),&(v492_12));
    join_wrapped_into(&mut v491_20_write,&((v492_13).read_zipper()),&[]);
    }
    v491_20_cursor.ascend(1);
  }
  drop(v491_20_cursor);
  drop(v491_20_write);
  (v491_20).clone()
}

fn routine_29(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v509_14 = Space::new();
  let mut v509_14_write = v509_14.write_zipper();
  let mut v509_14_cursor = (*s0).read_zipper();
  let v509_14_origin = v509_14_cursor.path().len();
  for v509_14_byte in v509_14_cursor.child_mask().iter() {
    v509_14_cursor.descend_to_existing_byte(v509_14_byte);
    {
    let v510_2: Space = singleton(&v509_14_cursor.path()[v509_14_origin..(v509_14_origin + 1)]);
    let v510_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v510_2));
    let v510_4: Space = if map_kernels::has_head(&(v510_3)) { singleton(&[]) } else { Space::new() };
    drop(v510_3);
    let v510_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v510_4));
    drop(v510_4);
    let v510_8: Space = if (&(v510_5)).is_empty() { Space::new() } else {
      let v511_6: Path = concat_path(&(*p0),&v509_14_cursor.path()[v509_14_origin..(v509_14_origin + 1)]);
      let mut v511_7 = Space::new();
      let mut v511_7_write = v511_7.write_zipper();
      for v511_7_byte in v509_14_cursor.child_mask().iter() {
        v509_14_cursor.descend_to_existing_byte(v511_7_byte);
        {
        let v512_2: Space = singleton(&v509_14_cursor.path()[(v509_14_origin + 1)..(v509_14_origin + 2)]);
        let v512_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v512_2));
        let v512_4: Space = if map_kernels::has_head(&(v512_3)) { singleton(&[]) } else { Space::new() };
        drop(v512_3);
        let v512_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v512_4));
        drop(v512_4);
        let v512_8: Space = if (&(v512_5)).is_empty() { Space::new() } else {
          let v513_6: Path = concat_path(&(v511_6),&v509_14_cursor.path()[(v509_14_origin + 1)..(v509_14_origin + 2)]);
          let mut v513_7 = Space::new();
          let mut v513_7_write = v513_7.write_zipper();
          for v513_7_byte in v509_14_cursor.child_mask().iter() {
            v509_14_cursor.descend_to_existing_byte(v513_7_byte);
            {
            let v514_2: Space = singleton(&v509_14_cursor.path()[(v509_14_origin + 2)..(v509_14_origin + 3)]);
            let v514_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v514_2));
            let v514_4: Space = if map_kernels::has_head(&(v514_3)) { singleton(&[]) } else { Space::new() };
            drop(v514_3);
            let v514_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v514_4));
            drop(v514_4);
            let v514_8: Space = if (&(v514_5)).is_empty() { Space::new() } else {
              let v515_6: Path = concat_path(&(v513_6),&v509_14_cursor.path()[(v509_14_origin + 2)..(v509_14_origin + 3)]);
              let v515_7: Space = routine_42(c, &(v515_6), &v509_14_cursor);
              map_map_kernels::compose(&(v514_5),&(v515_7))
            };
            drop(v514_5);
            let v514_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v514_2));
            drop(v514_2);
            let v514_10: Space = if map_kernels::has_head(&(v514_9)) { singleton(&[]) } else { Space::new() };
            drop(v514_9);
            let v514_12: Space = if (&(v514_10)).is_empty() { Space::new() } else {
              let v516_6: Path = concat_path(&(v513_6),&v509_14_cursor.path()[(v509_14_origin + 2)..(v509_14_origin + 3)]);
              let v516_11: Space = routine_43(c, &(v516_6), &v509_14_cursor);
              drop(v516_6);
              map_map_kernels::compose(&(v514_10),&(v516_11))
            };
            drop(v514_10);
            let v514_13: Space = map_map_kernels::unite(&(v514_8),&(v514_12));
            join_wrapped_into(&mut v513_7_write,&((v514_13).read_zipper()),&[]);
            }
            v509_14_cursor.ascend(1);
          }
          drop(v513_7_write);
          map_map_kernels::compose(&(v512_5),&(v513_7))
        };
        drop(v512_5);
        let v512_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v512_2));
        drop(v512_2);
        let v512_10: Space = if map_kernels::has_head(&(v512_9)) { singleton(&[]) } else { Space::new() };
        drop(v512_9);
        let v512_12: Space = if (&(v512_10)).is_empty() { Space::new() } else {
          let v517_6: Path = concat_path(&(v511_6),&v509_14_cursor.path()[(v509_14_origin + 1)..(v509_14_origin + 2)]);
          let mut v517_11 = Space::new();
          let mut v517_11_write = v517_11.write_zipper();
          for v517_11_byte in v509_14_cursor.child_mask().iter() {
            v509_14_cursor.descend_to_existing_byte(v517_11_byte);
            {
            let v518_2: Space = singleton(&v509_14_cursor.path()[(v509_14_origin + 2)..(v509_14_origin + 3)]);
            let v518_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v518_2));
            let v518_4: Space = if map_kernels::has_head(&(v518_3)) { singleton(&[]) } else { Space::new() };
            drop(v518_3);
            let v518_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v518_4));
            drop(v518_4);
            let v518_8: Space = if (&(v518_5)).is_empty() { Space::new() } else {
              let v519_6: Path = concat_path(&(v517_6),&v509_14_cursor.path()[(v509_14_origin + 2)..(v509_14_origin + 3)]);
              let v519_7: Space = routine_42(c, &(v519_6), &v509_14_cursor);
              map_map_kernels::compose(&(v518_5),&(v519_7))
            };
            drop(v518_5);
            let v518_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v518_2));
            drop(v518_2);
            let v518_10: Space = if map_kernels::has_head(&(v518_9)) { singleton(&[]) } else { Space::new() };
            drop(v518_9);
            let v518_12: Space = if (&(v518_10)).is_empty() { Space::new() } else {
              let v520_6: Path = concat_path(&(v517_6),&v509_14_cursor.path()[(v509_14_origin + 2)..(v509_14_origin + 3)]);
              let v520_11: Space = routine_15(c, &(v520_6), &v509_14_cursor);
              drop(v520_6);
              map_map_kernels::compose(&(v518_10),&(v520_11))
            };
            drop(v518_10);
            let v518_13: Space = map_map_kernels::unite(&(v518_8),&(v518_12));
            join_wrapped_into(&mut v517_11_write,&((v518_13).read_zipper()),&[]);
            }
            v509_14_cursor.ascend(1);
          }
          drop(v517_11_write);
          drop(v517_6);
          map_map_kernels::compose(&(v512_10),&(v517_11))
        };
        drop(v512_10);
        let v512_13: Space = map_map_kernels::unite(&(v512_8),&(v512_12));
        join_wrapped_into(&mut v511_7_write,&((v512_13).read_zipper()),&[]);
        }
        v509_14_cursor.ascend(1);
      }
      drop(v511_7_write);
      drop(v511_6);
      map_map_kernels::compose(&(v510_5),&(v511_7))
    };
    drop(v510_5);
    let v510_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v510_2));
    drop(v510_2);
    let v510_10: Space = if map_kernels::has_head(&(v510_9)) { singleton(&[]) } else { Space::new() };
    drop(v510_9);
    let v510_11: Space = map_view_kernels::compose(&(v510_10),&v509_14_cursor);
    drop(v510_10);
    let v510_12: Space = map_map_kernels::unite(&(v510_8),&(v510_11));
    drop(v510_11);
    join_wrapped_into(&mut v509_14_write,&((v510_12).read_zipper()),&[]);
    }
    v509_14_cursor.ascend(1);
  }
  drop(v509_14_cursor);
  drop(v509_14_write);
  (v509_14).clone()
}

fn routine_30(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v521_20 = Space::new();
  let mut v521_20_write = v521_20.write_zipper();
  let mut v521_20_cursor = (*s0).read_zipper();
  let v521_20_origin = v521_20_cursor.path().len();
  for v521_20_byte in v521_20_cursor.child_mask().iter() {
    v521_20_cursor.descend_to_existing_byte(v521_20_byte);
    {
    let v522_2: Space = singleton(&v521_20_cursor.path()[v521_20_origin..(v521_20_origin + 1)]);
    let v522_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v522_2));
    let v522_4: Space = if map_kernels::has_head(&(v522_3)) { singleton(&[]) } else { Space::new() };
    drop(v522_3);
    let v522_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v522_4));
    drop(v522_4);
    let v522_8: Space = if (&(v522_5)).is_empty() { Space::new() } else {
      let v523_6: Path = concat_path(&(*p0),&v521_20_cursor.path()[v521_20_origin..(v521_20_origin + 1)]);
      let mut v523_7 = Space::new();
      let mut v523_7_write = v523_7.write_zipper();
      for v523_7_byte in v521_20_cursor.child_mask().iter() {
        v521_20_cursor.descend_to_existing_byte(v523_7_byte);
        {
        let v524_2: Space = singleton(&v521_20_cursor.path()[(v521_20_origin + 1)..(v521_20_origin + 2)]);
        let v524_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v524_2));
        let v524_4: Space = if map_kernels::has_head(&(v524_3)) { singleton(&[]) } else { Space::new() };
        drop(v524_3);
        let v524_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v524_4));
        drop(v524_4);
        let v524_8: Space = if (&(v524_5)).is_empty() { Space::new() } else {
          let v525_6: Path = concat_path(&(v523_6),&v521_20_cursor.path()[(v521_20_origin + 1)..(v521_20_origin + 2)]);
          let mut v525_7 = Space::new();
          let mut v525_7_write = v525_7.write_zipper();
          for v525_7_byte in v521_20_cursor.child_mask().iter() {
            v521_20_cursor.descend_to_existing_byte(v525_7_byte);
            {
            let v526_2: Space = singleton(&v521_20_cursor.path()[(v521_20_origin + 2)..(v521_20_origin + 3)]);
            let v526_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v526_2));
            let v526_4: Space = if map_kernels::has_head(&(v526_3)) { singleton(&[]) } else { Space::new() };
            drop(v526_3);
            let v526_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v526_4));
            drop(v526_4);
            let v526_8: Space = if (&(v526_5)).is_empty() { Space::new() } else {
              let v527_6: Path = concat_path(&(v525_6),&v521_20_cursor.path()[(v521_20_origin + 2)..(v521_20_origin + 3)]);
              let v527_7: Space = routine_44(c, &(v527_6), &v521_20_cursor);
              map_map_kernels::compose(&(v526_5),&(v527_7))
            };
            drop(v526_5);
            let v526_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v526_2));
            drop(v526_2);
            let v526_10: Space = if map_kernels::has_head(&(v526_9)) { singleton(&[]) } else { Space::new() };
            drop(v526_9);
            let v526_12: Space = if (&(v526_10)).is_empty() { Space::new() } else {
              let v528_6: Path = concat_path(&(v525_6),&v521_20_cursor.path()[(v521_20_origin + 2)..(v521_20_origin + 3)]);
              let v528_11: Space = routine_45(c, &(v528_6), &v521_20_cursor);
              drop(v528_6);
              map_map_kernels::compose(&(v526_10),&(v528_11))
            };
            drop(v526_10);
            let v526_13: Space = map_map_kernels::unite(&(v526_8),&(v526_12));
            join_wrapped_into(&mut v525_7_write,&((v526_13).read_zipper()),&[]);
            }
            v521_20_cursor.ascend(1);
          }
          drop(v525_7_write);
          map_map_kernels::compose(&(v524_5),&(v525_7))
        };
        drop(v524_5);
        let v524_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v524_2));
        drop(v524_2);
        let v524_10: Space = if map_kernels::has_head(&(v524_9)) { singleton(&[]) } else { Space::new() };
        drop(v524_9);
        let v524_12: Space = if (&(v524_10)).is_empty() { Space::new() } else {
          let v529_6: Path = concat_path(&(v523_6),&v521_20_cursor.path()[(v521_20_origin + 1)..(v521_20_origin + 2)]);
          let mut v529_11 = Space::new();
          let mut v529_11_write = v529_11.write_zipper();
          for v529_11_byte in v521_20_cursor.child_mask().iter() {
            v521_20_cursor.descend_to_existing_byte(v529_11_byte);
            {
            let v530_2: Space = singleton(&v521_20_cursor.path()[(v521_20_origin + 2)..(v521_20_origin + 3)]);
            let v530_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v530_2));
            let v530_4: Space = if map_kernels::has_head(&(v530_3)) { singleton(&[]) } else { Space::new() };
            drop(v530_3);
            let v530_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v530_4));
            drop(v530_4);
            let v530_8: Space = if (&(v530_5)).is_empty() { Space::new() } else {
              let v531_6: Path = concat_path(&(v529_6),&v521_20_cursor.path()[(v521_20_origin + 2)..(v521_20_origin + 3)]);
              let v531_7: Space = routine_44(c, &(v531_6), &v521_20_cursor);
              map_map_kernels::compose(&(v530_5),&(v531_7))
            };
            drop(v530_5);
            let v530_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v530_2));
            drop(v530_2);
            let v530_10: Space = if map_kernels::has_head(&(v530_9)) { singleton(&[]) } else { Space::new() };
            drop(v530_9);
            let v530_12: Space = if (&(v530_10)).is_empty() { Space::new() } else {
              let v532_6: Path = concat_path(&(v529_6),&v521_20_cursor.path()[(v521_20_origin + 2)..(v521_20_origin + 3)]);
              let v532_11: Space = routine_12(c, &(v532_6), &v521_20_cursor);
              drop(v532_6);
              map_map_kernels::compose(&(v530_10),&(v532_11))
            };
            drop(v530_10);
            let v530_13: Space = map_map_kernels::unite(&(v530_8),&(v530_12));
            join_wrapped_into(&mut v529_11_write,&((v530_13).read_zipper()),&[]);
            }
            v521_20_cursor.ascend(1);
          }
          drop(v529_11_write);
          drop(v529_6);
          map_map_kernels::compose(&(v524_10),&(v529_11))
        };
        drop(v524_10);
        let v524_13: Space = map_map_kernels::unite(&(v524_8),&(v524_12));
        join_wrapped_into(&mut v523_7_write,&((v524_13).read_zipper()),&[]);
        }
        v521_20_cursor.ascend(1);
      }
      drop(v523_7_write);
      map_map_kernels::compose(&(v522_5),&(v523_7))
    };
    drop(v522_5);
    let v522_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v522_2));
    drop(v522_2);
    let v522_10: Space = if map_kernels::has_head(&(v522_9)) { singleton(&[]) } else { Space::new() };
    drop(v522_9);
    let v522_12: Space = if (&(v522_10)).is_empty() { Space::new() } else {
      let v533_6: Path = concat_path(&(*p0),&v521_20_cursor.path()[v521_20_origin..(v521_20_origin + 1)]);
      let mut v533_11 = Space::new();
      let mut v533_11_write = v533_11.write_zipper();
      for v533_11_byte in v521_20_cursor.child_mask().iter() {
        v521_20_cursor.descend_to_existing_byte(v533_11_byte);
        {
        let v534_2: Space = singleton(&v521_20_cursor.path()[(v521_20_origin + 1)..(v521_20_origin + 2)]);
        let v534_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v534_2));
        let v534_4: Space = if map_kernels::has_head(&(v534_3)) { singleton(&[]) } else { Space::new() };
        drop(v534_3);
        let v534_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v534_4));
        drop(v534_4);
        let v534_8: Space = if (&(v534_5)).is_empty() { Space::new() } else {
          let v535_6: Path = concat_path(&(v533_6),&v521_20_cursor.path()[(v521_20_origin + 1)..(v521_20_origin + 2)]);
          let mut v535_7 = Space::new();
          let mut v535_7_write = v535_7.write_zipper();
          for v535_7_byte in v521_20_cursor.child_mask().iter() {
            v521_20_cursor.descend_to_existing_byte(v535_7_byte);
            {
            let v536_2: Space = singleton(&v521_20_cursor.path()[(v521_20_origin + 2)..(v521_20_origin + 3)]);
            let v536_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v536_2));
            let v536_4: Space = if map_kernels::has_head(&(v536_3)) { singleton(&[]) } else { Space::new() };
            drop(v536_3);
            let v536_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v536_4));
            drop(v536_4);
            let v536_8: Space = if (&(v536_5)).is_empty() { Space::new() } else {
              let v537_6: Path = concat_path(&(v535_6),&v521_20_cursor.path()[(v521_20_origin + 2)..(v521_20_origin + 3)]);
              let v537_7: Space = routine_44(c, &(v537_6), &v521_20_cursor);
              map_map_kernels::compose(&(v536_5),&(v537_7))
            };
            drop(v536_5);
            let v536_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v536_2));
            drop(v536_2);
            let v536_10: Space = if map_kernels::has_head(&(v536_9)) { singleton(&[]) } else { Space::new() };
            drop(v536_9);
            let v536_12: Space = if (&(v536_10)).is_empty() { Space::new() } else {
              let v538_6: Path = concat_path(&(v535_6),&v521_20_cursor.path()[(v521_20_origin + 2)..(v521_20_origin + 3)]);
              let v538_11: Space = routine_45(c, &(v538_6), &v521_20_cursor);
              drop(v538_6);
              map_map_kernels::compose(&(v536_10),&(v538_11))
            };
            drop(v536_10);
            let v536_13: Space = map_map_kernels::unite(&(v536_8),&(v536_12));
            join_wrapped_into(&mut v535_7_write,&((v536_13).read_zipper()),&[]);
            }
            v521_20_cursor.ascend(1);
          }
          drop(v535_7_write);
          drop(v535_6);
          map_map_kernels::compose(&(v534_5),&(v535_7))
        };
        drop(v534_5);
        let v534_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v534_2));
        drop(v534_2);
        let v534_10: Space = if map_kernels::has_head(&(v534_9)) { singleton(&[]) } else { Space::new() };
        drop(v534_9);
        let v534_11: Space = map_view_kernels::compose(&(v534_10),&v521_20_cursor);
        drop(v534_10);
        let v534_12: Space = map_map_kernels::unite(&(v534_8),&(v534_11));
        drop(v534_11);
        join_wrapped_into(&mut v533_11_write,&((v534_12).read_zipper()),&[]);
        }
        v521_20_cursor.ascend(1);
      }
      drop(v533_11_write);
      drop(v533_6);
      map_map_kernels::compose(&(v522_10),&(v533_11))
    };
    drop(v522_10);
    let v522_13: Space = map_map_kernels::unite(&(v522_8),&(v522_12));
    join_wrapped_into(&mut v521_20_write,&((v522_13).read_zipper()),&[]);
    }
    v521_20_cursor.ascend(1);
  }
  drop(v521_20_cursor);
  drop(v521_20_write);
  (v521_20).clone()
}

fn routine_31(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v539_14 = Space::new();
  let mut v539_14_write = v539_14.write_zipper();
  let mut v539_14_cursor = (*s0).read_zipper();
  let v539_14_origin = v539_14_cursor.path().len();
  for v539_14_byte in v539_14_cursor.child_mask().iter() {
    v539_14_cursor.descend_to_existing_byte(v539_14_byte);
    {
    let v540_2: Space = singleton(&v539_14_cursor.path()[v539_14_origin..(v539_14_origin + 1)]);
    let v540_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v540_2));
    let v540_4: Space = if map_kernels::has_head(&(v540_3)) { singleton(&[]) } else { Space::new() };
    drop(v540_3);
    let v540_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v540_4));
    drop(v540_4);
    let v540_8: Space = if (&(v540_5)).is_empty() { Space::new() } else {
      let v541_6: Path = concat_path(&(*p0),&v539_14_cursor.path()[v539_14_origin..(v539_14_origin + 1)]);
      let mut v541_7 = Space::new();
      let mut v541_7_write = v541_7.write_zipper();
      for v541_7_byte in v539_14_cursor.child_mask().iter() {
        v539_14_cursor.descend_to_existing_byte(v541_7_byte);
        {
        let v542_2: Space = singleton(&v539_14_cursor.path()[(v539_14_origin + 1)..(v539_14_origin + 2)]);
        let v542_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v542_2));
        let v542_4: Space = if map_kernels::has_head(&(v542_3)) { singleton(&[]) } else { Space::new() };
        drop(v542_3);
        let v542_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v542_4));
        drop(v542_4);
        let v542_8: Space = if (&(v542_5)).is_empty() { Space::new() } else {
          let v543_6: Path = concat_path(&(v541_6),&v539_14_cursor.path()[(v539_14_origin + 1)..(v539_14_origin + 2)]);
          let mut v543_7 = Space::new();
          let mut v543_7_write = v543_7.write_zipper();
          for v543_7_byte in v539_14_cursor.child_mask().iter() {
            v539_14_cursor.descend_to_existing_byte(v543_7_byte);
            {
            let v544_2: Space = singleton(&v539_14_cursor.path()[(v539_14_origin + 2)..(v539_14_origin + 3)]);
            let v544_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v544_2));
            let v544_4: Space = if map_kernels::has_head(&(v544_3)) { singleton(&[]) } else { Space::new() };
            drop(v544_3);
            let v544_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v544_4));
            drop(v544_4);
            let v544_8: Space = if (&(v544_5)).is_empty() { Space::new() } else {
              let v545_6: Path = concat_path(&(v543_6),&v539_14_cursor.path()[(v539_14_origin + 2)..(v539_14_origin + 3)]);
              let v545_7: Space = routine_44(c, &(v545_6), &v539_14_cursor);
              map_map_kernels::compose(&(v544_5),&(v545_7))
            };
            drop(v544_5);
            let v544_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v544_2));
            drop(v544_2);
            let v544_10: Space = if map_kernels::has_head(&(v544_9)) { singleton(&[]) } else { Space::new() };
            drop(v544_9);
            let v544_12: Space = if (&(v544_10)).is_empty() { Space::new() } else {
              let v546_6: Path = concat_path(&(v543_6),&v539_14_cursor.path()[(v539_14_origin + 2)..(v539_14_origin + 3)]);
              let v546_11: Space = routine_45(c, &(v546_6), &v539_14_cursor);
              drop(v546_6);
              map_map_kernels::compose(&(v544_10),&(v546_11))
            };
            drop(v544_10);
            let v544_13: Space = map_map_kernels::unite(&(v544_8),&(v544_12));
            join_wrapped_into(&mut v543_7_write,&((v544_13).read_zipper()),&[]);
            }
            v539_14_cursor.ascend(1);
          }
          drop(v543_7_write);
          map_map_kernels::compose(&(v542_5),&(v543_7))
        };
        drop(v542_5);
        let v542_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v542_2));
        drop(v542_2);
        let v542_10: Space = if map_kernels::has_head(&(v542_9)) { singleton(&[]) } else { Space::new() };
        drop(v542_9);
        let v542_12: Space = if (&(v542_10)).is_empty() { Space::new() } else {
          let v547_6: Path = concat_path(&(v541_6),&v539_14_cursor.path()[(v539_14_origin + 1)..(v539_14_origin + 2)]);
          let mut v547_11 = Space::new();
          let mut v547_11_write = v547_11.write_zipper();
          for v547_11_byte in v539_14_cursor.child_mask().iter() {
            v539_14_cursor.descend_to_existing_byte(v547_11_byte);
            {
            let v548_2: Space = singleton(&v539_14_cursor.path()[(v539_14_origin + 2)..(v539_14_origin + 3)]);
            let v548_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v548_2));
            let v548_4: Space = if map_kernels::has_head(&(v548_3)) { singleton(&[]) } else { Space::new() };
            drop(v548_3);
            let v548_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v548_4));
            drop(v548_4);
            let v548_8: Space = if (&(v548_5)).is_empty() { Space::new() } else {
              let v549_6: Path = concat_path(&(v547_6),&v539_14_cursor.path()[(v539_14_origin + 2)..(v539_14_origin + 3)]);
              let v549_7: Space = routine_44(c, &(v549_6), &v539_14_cursor);
              map_map_kernels::compose(&(v548_5),&(v549_7))
            };
            drop(v548_5);
            let v548_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v548_2));
            drop(v548_2);
            let v548_10: Space = if map_kernels::has_head(&(v548_9)) { singleton(&[]) } else { Space::new() };
            drop(v548_9);
            let v548_12: Space = if (&(v548_10)).is_empty() { Space::new() } else {
              let v550_6: Path = concat_path(&(v547_6),&v539_14_cursor.path()[(v539_14_origin + 2)..(v539_14_origin + 3)]);
              let v550_11: Space = routine_12(c, &(v550_6), &v539_14_cursor);
              drop(v550_6);
              map_map_kernels::compose(&(v548_10),&(v550_11))
            };
            drop(v548_10);
            let v548_13: Space = map_map_kernels::unite(&(v548_8),&(v548_12));
            join_wrapped_into(&mut v547_11_write,&((v548_13).read_zipper()),&[]);
            }
            v539_14_cursor.ascend(1);
          }
          drop(v547_11_write);
          drop(v547_6);
          map_map_kernels::compose(&(v542_10),&(v547_11))
        };
        drop(v542_10);
        let v542_13: Space = map_map_kernels::unite(&(v542_8),&(v542_12));
        join_wrapped_into(&mut v541_7_write,&((v542_13).read_zipper()),&[]);
        }
        v539_14_cursor.ascend(1);
      }
      drop(v541_7_write);
      drop(v541_6);
      map_map_kernels::compose(&(v540_5),&(v541_7))
    };
    drop(v540_5);
    let v540_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v540_2));
    drop(v540_2);
    let v540_10: Space = if map_kernels::has_head(&(v540_9)) { singleton(&[]) } else { Space::new() };
    drop(v540_9);
    let v540_11: Space = map_view_kernels::compose(&(v540_10),&v539_14_cursor);
    drop(v540_10);
    let v540_12: Space = map_map_kernels::unite(&(v540_8),&(v540_11));
    drop(v540_11);
    join_wrapped_into(&mut v539_14_write,&((v540_12).read_zipper()),&[]);
    }
    v539_14_cursor.ascend(1);
  }
  drop(v539_14_cursor);
  drop(v539_14_write);
  (v539_14).clone()
}

fn routine_32(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v551_20 = Space::new();
  let mut v551_20_write = v551_20.write_zipper();
  let mut v551_20_cursor = (*s0).read_zipper();
  let v551_20_origin = v551_20_cursor.path().len();
  for v551_20_byte in v551_20_cursor.child_mask().iter() {
    v551_20_cursor.descend_to_existing_byte(v551_20_byte);
    {
    let v552_2: Space = singleton(&v551_20_cursor.path()[v551_20_origin..(v551_20_origin + 1)]);
    let v552_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v552_2));
    let v552_4: Space = if map_kernels::has_head(&(v552_3)) { singleton(&[]) } else { Space::new() };
    drop(v552_3);
    let v552_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v552_4));
    drop(v552_4);
    let v552_8: Space = if (&(v552_5)).is_empty() { Space::new() } else {
      let v553_6: Path = concat_path(&(*p0),&v551_20_cursor.path()[v551_20_origin..(v551_20_origin + 1)]);
      let mut v553_7 = Space::new();
      let mut v553_7_write = v553_7.write_zipper();
      for v553_7_byte in v551_20_cursor.child_mask().iter() {
        v551_20_cursor.descend_to_existing_byte(v553_7_byte);
        {
        let v554_2: Space = singleton(&v551_20_cursor.path()[(v551_20_origin + 1)..(v551_20_origin + 2)]);
        let v554_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v554_2));
        let v554_4: Space = if map_kernels::has_head(&(v554_3)) { singleton(&[]) } else { Space::new() };
        drop(v554_3);
        let v554_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v554_4));
        drop(v554_4);
        let v554_8: Space = if (&(v554_5)).is_empty() { Space::new() } else {
          let v555_6: Path = concat_path(&(v553_6),&v551_20_cursor.path()[(v551_20_origin + 1)..(v551_20_origin + 2)]);
          let mut v555_7 = Space::new();
          let mut v555_7_write = v555_7.write_zipper();
          for v555_7_byte in v551_20_cursor.child_mask().iter() {
            v551_20_cursor.descend_to_existing_byte(v555_7_byte);
            {
            let v556_2: Space = singleton(&v551_20_cursor.path()[(v551_20_origin + 2)..(v551_20_origin + 3)]);
            let v556_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v556_2));
            let v556_4: Space = if map_kernels::has_head(&(v556_3)) { singleton(&[]) } else { Space::new() };
            drop(v556_3);
            let v556_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v556_4));
            drop(v556_4);
            let v556_8: Space = if (&(v556_5)).is_empty() { Space::new() } else {
              let v557_6: Path = concat_path(&(v555_6),&v551_20_cursor.path()[(v551_20_origin + 2)..(v551_20_origin + 3)]);
              let v557_7: Space = routine_46(c, &(v557_6), &v551_20_cursor);
              map_map_kernels::compose(&(v556_5),&(v557_7))
            };
            drop(v556_5);
            let v556_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v556_2));
            drop(v556_2);
            let v556_10: Space = if map_kernels::has_head(&(v556_9)) { singleton(&[]) } else { Space::new() };
            drop(v556_9);
            let v556_12: Space = if (&(v556_10)).is_empty() { Space::new() } else {
              let v558_6: Path = concat_path(&(v555_6),&v551_20_cursor.path()[(v551_20_origin + 2)..(v551_20_origin + 3)]);
              let v558_11: Space = routine_47(c, &(v558_6), &v551_20_cursor);
              drop(v558_6);
              map_map_kernels::compose(&(v556_10),&(v558_11))
            };
            drop(v556_10);
            let v556_13: Space = map_map_kernels::unite(&(v556_8),&(v556_12));
            join_wrapped_into(&mut v555_7_write,&((v556_13).read_zipper()),&[]);
            }
            v551_20_cursor.ascend(1);
          }
          drop(v555_7_write);
          map_map_kernels::compose(&(v554_5),&(v555_7))
        };
        drop(v554_5);
        let v554_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v554_2));
        drop(v554_2);
        let v554_10: Space = if map_kernels::has_head(&(v554_9)) { singleton(&[]) } else { Space::new() };
        drop(v554_9);
        let v554_12: Space = if (&(v554_10)).is_empty() { Space::new() } else {
          let v559_6: Path = concat_path(&(v553_6),&v551_20_cursor.path()[(v551_20_origin + 1)..(v551_20_origin + 2)]);
          let mut v559_11 = Space::new();
          let mut v559_11_write = v559_11.write_zipper();
          for v559_11_byte in v551_20_cursor.child_mask().iter() {
            v551_20_cursor.descend_to_existing_byte(v559_11_byte);
            {
            let v560_2: Space = singleton(&v551_20_cursor.path()[(v551_20_origin + 2)..(v551_20_origin + 3)]);
            let v560_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v560_2));
            let v560_4: Space = if map_kernels::has_head(&(v560_3)) { singleton(&[]) } else { Space::new() };
            drop(v560_3);
            let v560_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v560_4));
            drop(v560_4);
            let v560_8: Space = if (&(v560_5)).is_empty() { Space::new() } else {
              let v561_6: Path = concat_path(&(v559_6),&v551_20_cursor.path()[(v551_20_origin + 2)..(v551_20_origin + 3)]);
              let v561_7: Space = routine_46(c, &(v561_6), &v551_20_cursor);
              map_map_kernels::compose(&(v560_5),&(v561_7))
            };
            drop(v560_5);
            let v560_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v560_2));
            drop(v560_2);
            let v560_10: Space = if map_kernels::has_head(&(v560_9)) { singleton(&[]) } else { Space::new() };
            drop(v560_9);
            let v560_12: Space = if (&(v560_10)).is_empty() { Space::new() } else {
              let v562_6: Path = concat_path(&(v559_6),&v551_20_cursor.path()[(v551_20_origin + 2)..(v551_20_origin + 3)]);
              let v562_11: Space = routine_15(c, &(v562_6), &v551_20_cursor);
              drop(v562_6);
              map_map_kernels::compose(&(v560_10),&(v562_11))
            };
            drop(v560_10);
            let v560_13: Space = map_map_kernels::unite(&(v560_8),&(v560_12));
            join_wrapped_into(&mut v559_11_write,&((v560_13).read_zipper()),&[]);
            }
            v551_20_cursor.ascend(1);
          }
          drop(v559_11_write);
          drop(v559_6);
          map_map_kernels::compose(&(v554_10),&(v559_11))
        };
        drop(v554_10);
        let v554_13: Space = map_map_kernels::unite(&(v554_8),&(v554_12));
        join_wrapped_into(&mut v553_7_write,&((v554_13).read_zipper()),&[]);
        }
        v551_20_cursor.ascend(1);
      }
      drop(v553_7_write);
      map_map_kernels::compose(&(v552_5),&(v553_7))
    };
    drop(v552_5);
    let v552_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v552_2));
    drop(v552_2);
    let v552_10: Space = if map_kernels::has_head(&(v552_9)) { singleton(&[]) } else { Space::new() };
    drop(v552_9);
    let v552_12: Space = if (&(v552_10)).is_empty() { Space::new() } else {
      let v563_6: Path = concat_path(&(*p0),&v551_20_cursor.path()[v551_20_origin..(v551_20_origin + 1)]);
      let mut v563_11 = Space::new();
      let mut v563_11_write = v563_11.write_zipper();
      for v563_11_byte in v551_20_cursor.child_mask().iter() {
        v551_20_cursor.descend_to_existing_byte(v563_11_byte);
        {
        let v564_2: Space = singleton(&v551_20_cursor.path()[(v551_20_origin + 1)..(v551_20_origin + 2)]);
        let v564_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v564_2));
        let v564_4: Space = if map_kernels::has_head(&(v564_3)) { singleton(&[]) } else { Space::new() };
        drop(v564_3);
        let v564_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v564_4));
        drop(v564_4);
        let v564_8: Space = if (&(v564_5)).is_empty() { Space::new() } else {
          let v565_6: Path = concat_path(&(v563_6),&v551_20_cursor.path()[(v551_20_origin + 1)..(v551_20_origin + 2)]);
          let mut v565_7 = Space::new();
          let mut v565_7_write = v565_7.write_zipper();
          for v565_7_byte in v551_20_cursor.child_mask().iter() {
            v551_20_cursor.descend_to_existing_byte(v565_7_byte);
            {
            let v566_2: Space = singleton(&v551_20_cursor.path()[(v551_20_origin + 2)..(v551_20_origin + 3)]);
            let v566_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v566_2));
            let v566_4: Space = if map_kernels::has_head(&(v566_3)) { singleton(&[]) } else { Space::new() };
            drop(v566_3);
            let v566_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v566_4));
            drop(v566_4);
            let v566_8: Space = if (&(v566_5)).is_empty() { Space::new() } else {
              let v567_6: Path = concat_path(&(v565_6),&v551_20_cursor.path()[(v551_20_origin + 2)..(v551_20_origin + 3)]);
              let v567_7: Space = routine_46(c, &(v567_6), &v551_20_cursor);
              map_map_kernels::compose(&(v566_5),&(v567_7))
            };
            drop(v566_5);
            let v566_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v566_2));
            drop(v566_2);
            let v566_10: Space = if map_kernels::has_head(&(v566_9)) { singleton(&[]) } else { Space::new() };
            drop(v566_9);
            let v566_12: Space = if (&(v566_10)).is_empty() { Space::new() } else {
              let v568_6: Path = concat_path(&(v565_6),&v551_20_cursor.path()[(v551_20_origin + 2)..(v551_20_origin + 3)]);
              let v568_11: Space = routine_47(c, &(v568_6), &v551_20_cursor);
              drop(v568_6);
              map_map_kernels::compose(&(v566_10),&(v568_11))
            };
            drop(v566_10);
            let v566_13: Space = map_map_kernels::unite(&(v566_8),&(v566_12));
            join_wrapped_into(&mut v565_7_write,&((v566_13).read_zipper()),&[]);
            }
            v551_20_cursor.ascend(1);
          }
          drop(v565_7_write);
          drop(v565_6);
          map_map_kernels::compose(&(v564_5),&(v565_7))
        };
        drop(v564_5);
        let v564_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v564_2));
        drop(v564_2);
        let v564_10: Space = if map_kernels::has_head(&(v564_9)) { singleton(&[]) } else { Space::new() };
        drop(v564_9);
        let v564_11: Space = map_view_kernels::compose(&(v564_10),&v551_20_cursor);
        drop(v564_10);
        let v564_12: Space = map_map_kernels::unite(&(v564_8),&(v564_11));
        drop(v564_11);
        join_wrapped_into(&mut v563_11_write,&((v564_12).read_zipper()),&[]);
        }
        v551_20_cursor.ascend(1);
      }
      drop(v563_11_write);
      drop(v563_6);
      map_map_kernels::compose(&(v552_10),&(v563_11))
    };
    drop(v552_10);
    let v552_13: Space = map_map_kernels::unite(&(v552_8),&(v552_12));
    join_wrapped_into(&mut v551_20_write,&((v552_13).read_zipper()),&[]);
    }
    v551_20_cursor.ascend(1);
  }
  drop(v551_20_cursor);
  drop(v551_20_write);
  (v551_20).clone()
}

fn routine_33(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v569_14 = Space::new();
  let mut v569_14_write = v569_14.write_zipper();
  let mut v569_14_cursor = (*s0).read_zipper();
  let v569_14_origin = v569_14_cursor.path().len();
  for v569_14_byte in v569_14_cursor.child_mask().iter() {
    v569_14_cursor.descend_to_existing_byte(v569_14_byte);
    {
    let v570_2: Space = singleton(&v569_14_cursor.path()[v569_14_origin..(v569_14_origin + 1)]);
    let v570_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v570_2));
    let v570_4: Space = if map_kernels::has_head(&(v570_3)) { singleton(&[]) } else { Space::new() };
    drop(v570_3);
    let v570_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v570_4));
    drop(v570_4);
    let v570_8: Space = if (&(v570_5)).is_empty() { Space::new() } else {
      let v571_6: Path = concat_path(&(*p0),&v569_14_cursor.path()[v569_14_origin..(v569_14_origin + 1)]);
      let mut v571_7 = Space::new();
      let mut v571_7_write = v571_7.write_zipper();
      for v571_7_byte in v569_14_cursor.child_mask().iter() {
        v569_14_cursor.descend_to_existing_byte(v571_7_byte);
        {
        let v572_2: Space = singleton(&v569_14_cursor.path()[(v569_14_origin + 1)..(v569_14_origin + 2)]);
        let v572_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v572_2));
        let v572_4: Space = if map_kernels::has_head(&(v572_3)) { singleton(&[]) } else { Space::new() };
        drop(v572_3);
        let v572_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v572_4));
        drop(v572_4);
        let v572_8: Space = if (&(v572_5)).is_empty() { Space::new() } else {
          let v573_6: Path = concat_path(&(v571_6),&v569_14_cursor.path()[(v569_14_origin + 1)..(v569_14_origin + 2)]);
          let mut v573_7 = Space::new();
          let mut v573_7_write = v573_7.write_zipper();
          for v573_7_byte in v569_14_cursor.child_mask().iter() {
            v569_14_cursor.descend_to_existing_byte(v573_7_byte);
            {
            let v574_2: Space = singleton(&v569_14_cursor.path()[(v569_14_origin + 2)..(v569_14_origin + 3)]);
            let v574_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v574_2));
            let v574_4: Space = if map_kernels::has_head(&(v574_3)) { singleton(&[]) } else { Space::new() };
            drop(v574_3);
            let v574_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v574_4));
            drop(v574_4);
            let v574_8: Space = if (&(v574_5)).is_empty() { Space::new() } else {
              let v575_6: Path = concat_path(&(v573_6),&v569_14_cursor.path()[(v569_14_origin + 2)..(v569_14_origin + 3)]);
              let v575_7: Space = routine_46(c, &(v575_6), &v569_14_cursor);
              map_map_kernels::compose(&(v574_5),&(v575_7))
            };
            drop(v574_5);
            let v574_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v574_2));
            drop(v574_2);
            let v574_10: Space = if map_kernels::has_head(&(v574_9)) { singleton(&[]) } else { Space::new() };
            drop(v574_9);
            let v574_12: Space = if (&(v574_10)).is_empty() { Space::new() } else {
              let v576_6: Path = concat_path(&(v573_6),&v569_14_cursor.path()[(v569_14_origin + 2)..(v569_14_origin + 3)]);
              let v576_11: Space = routine_47(c, &(v576_6), &v569_14_cursor);
              drop(v576_6);
              map_map_kernels::compose(&(v574_10),&(v576_11))
            };
            drop(v574_10);
            let v574_13: Space = map_map_kernels::unite(&(v574_8),&(v574_12));
            join_wrapped_into(&mut v573_7_write,&((v574_13).read_zipper()),&[]);
            }
            v569_14_cursor.ascend(1);
          }
          drop(v573_7_write);
          map_map_kernels::compose(&(v572_5),&(v573_7))
        };
        drop(v572_5);
        let v572_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v572_2));
        drop(v572_2);
        let v572_10: Space = if map_kernels::has_head(&(v572_9)) { singleton(&[]) } else { Space::new() };
        drop(v572_9);
        let v572_12: Space = if (&(v572_10)).is_empty() { Space::new() } else {
          let v577_6: Path = concat_path(&(v571_6),&v569_14_cursor.path()[(v569_14_origin + 1)..(v569_14_origin + 2)]);
          let mut v577_11 = Space::new();
          let mut v577_11_write = v577_11.write_zipper();
          for v577_11_byte in v569_14_cursor.child_mask().iter() {
            v569_14_cursor.descend_to_existing_byte(v577_11_byte);
            {
            let v578_2: Space = singleton(&v569_14_cursor.path()[(v569_14_origin + 2)..(v569_14_origin + 3)]);
            let v578_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v578_2));
            let v578_4: Space = if map_kernels::has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
            drop(v578_3);
            let v578_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v578_4));
            drop(v578_4);
            let v578_8: Space = if (&(v578_5)).is_empty() { Space::new() } else {
              let v579_6: Path = concat_path(&(v577_6),&v569_14_cursor.path()[(v569_14_origin + 2)..(v569_14_origin + 3)]);
              let v579_7: Space = routine_46(c, &(v579_6), &v569_14_cursor);
              map_map_kernels::compose(&(v578_5),&(v579_7))
            };
            drop(v578_5);
            let v578_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v578_2));
            drop(v578_2);
            let v578_10: Space = if map_kernels::has_head(&(v578_9)) { singleton(&[]) } else { Space::new() };
            drop(v578_9);
            let v578_12: Space = if (&(v578_10)).is_empty() { Space::new() } else {
              let v580_6: Path = concat_path(&(v577_6),&v569_14_cursor.path()[(v569_14_origin + 2)..(v569_14_origin + 3)]);
              let v580_11: Space = routine_15(c, &(v580_6), &v569_14_cursor);
              drop(v580_6);
              map_map_kernels::compose(&(v578_10),&(v580_11))
            };
            drop(v578_10);
            let v578_13: Space = map_map_kernels::unite(&(v578_8),&(v578_12));
            join_wrapped_into(&mut v577_11_write,&((v578_13).read_zipper()),&[]);
            }
            v569_14_cursor.ascend(1);
          }
          drop(v577_11_write);
          drop(v577_6);
          map_map_kernels::compose(&(v572_10),&(v577_11))
        };
        drop(v572_10);
        let v572_13: Space = map_map_kernels::unite(&(v572_8),&(v572_12));
        join_wrapped_into(&mut v571_7_write,&((v572_13).read_zipper()),&[]);
        }
        v569_14_cursor.ascend(1);
      }
      drop(v571_7_write);
      drop(v571_6);
      map_map_kernels::compose(&(v570_5),&(v571_7))
    };
    drop(v570_5);
    let v570_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v570_2));
    drop(v570_2);
    let v570_10: Space = if map_kernels::has_head(&(v570_9)) { singleton(&[]) } else { Space::new() };
    drop(v570_9);
    let v570_11: Space = map_view_kernels::compose(&(v570_10),&v569_14_cursor);
    drop(v570_10);
    let v570_12: Space = map_map_kernels::unite(&(v570_8),&(v570_11));
    drop(v570_11);
    join_wrapped_into(&mut v569_14_write,&((v570_12).read_zipper()),&[]);
    }
    v569_14_cursor.ascend(1);
  }
  drop(v569_14_cursor);
  drop(v569_14_write);
  (v569_14).clone()
}

fn routine_34(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v581_34 = Space::new();
  let mut v581_34_write = v581_34.write_zipper();
  let mut v581_34_cursor = (*s0).read_zipper();
  let v581_34_origin = v581_34_cursor.path().len();
  for v581_34_byte in v581_34_cursor.child_mask().iter() {
    v581_34_cursor.descend_to_existing_byte(v581_34_byte);
    {
    let v582_2: Space = singleton(&v581_34_cursor.path()[v581_34_origin..(v581_34_origin + 1)]);
    let v582_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v582_2));
    let v582_4: Space = if map_kernels::has_head(&(v582_3)) { singleton(&[]) } else { Space::new() };
    drop(v582_3);
    let v582_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v582_4));
    drop(v582_4);
    let v582_8: Space = if (&(v582_5)).is_empty() { Space::new() } else {
      let v583_6: Path = concat_path(&(*p0),&v581_34_cursor.path()[v581_34_origin..(v581_34_origin + 1)]);
      let mut v583_7 = Space::new();
      let mut v583_7_write = v583_7.write_zipper();
      for v583_7_byte in v581_34_cursor.child_mask().iter() {
        v581_34_cursor.descend_to_existing_byte(v583_7_byte);
        {
        let v584_2: Space = singleton(&v581_34_cursor.path()[(v581_34_origin + 1)..(v581_34_origin + 2)]);
        let v584_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v584_2));
        let v584_4: Space = if map_kernels::has_head(&(v584_3)) { singleton(&[]) } else { Space::new() };
        drop(v584_3);
        let v584_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v584_4));
        drop(v584_4);
        let v584_8: Space = if (&(v584_5)).is_empty() { Space::new() } else {
          let v585_6: Path = concat_path(&(v583_6),&v581_34_cursor.path()[(v581_34_origin + 1)..(v581_34_origin + 2)]);
          let mut v585_7 = Space::new();
          let mut v585_7_write = v585_7.write_zipper();
          for v585_7_byte in v581_34_cursor.child_mask().iter() {
            v581_34_cursor.descend_to_existing_byte(v585_7_byte);
            {
            let v586_2: Space = singleton(&v581_34_cursor.path()[(v581_34_origin + 2)..(v581_34_origin + 3)]);
            let v586_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v586_2));
            let v586_4: Space = if map_kernels::has_head(&(v586_3)) { singleton(&[]) } else { Space::new() };
            drop(v586_3);
            let v586_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v586_4));
            drop(v586_4);
            let v586_8: Space = if (&(v586_5)).is_empty() { Space::new() } else {
              let v587_6: Path = concat_path(&(v585_6),&v581_34_cursor.path()[(v581_34_origin + 2)..(v581_34_origin + 3)]);
              let v587_7: Space = routine_48(c, &(v587_6), &v581_34_cursor, &(*s1));
              map_map_kernels::compose(&(v586_5),&(v587_7))
            };
            drop(v586_5);
            let v586_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v586_2));
            drop(v586_2);
            let v586_10: Space = if map_kernels::has_head(&(v586_9)) { singleton(&[]) } else { Space::new() };
            drop(v586_9);
            let v586_12: Space = if (&(v586_10)).is_empty() { Space::new() } else {
              let v588_6: Path = concat_path(&(v585_6),&v581_34_cursor.path()[(v581_34_origin + 2)..(v581_34_origin + 3)]);
              let v588_11: Space = routine_49(c, &(v588_6), &v581_34_cursor, &(*s1));
              drop(v588_6);
              map_map_kernels::compose(&(v586_10),&(v588_11))
            };
            drop(v586_10);
            let v586_13: Space = map_map_kernels::unite(&(v586_8),&(v586_12));
            join_wrapped_into(&mut v585_7_write,&((v586_13).read_zipper()),&[]);
            }
            v581_34_cursor.ascend(1);
          }
          drop(v585_7_write);
          map_map_kernels::compose(&(v584_5),&(v585_7))
        };
        drop(v584_5);
        let v584_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v584_2));
        drop(v584_2);
        let v584_10: Space = if map_kernels::has_head(&(v584_9)) { singleton(&[]) } else { Space::new() };
        drop(v584_9);
        let v584_12: Space = if (&(v584_10)).is_empty() { Space::new() } else {
          let v589_6: Path = concat_path(&(v583_6),&v581_34_cursor.path()[(v581_34_origin + 1)..(v581_34_origin + 2)]);
          let mut v589_11 = Space::new();
          let mut v589_11_write = v589_11.write_zipper();
          for v589_11_byte in v581_34_cursor.child_mask().iter() {
            v581_34_cursor.descend_to_existing_byte(v589_11_byte);
            {
            let v590_2: Space = singleton(&v581_34_cursor.path()[(v581_34_origin + 2)..(v581_34_origin + 3)]);
            let v590_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v590_2));
            let v590_4: Space = if map_kernels::has_head(&(v590_3)) { singleton(&[]) } else { Space::new() };
            drop(v590_3);
            let v590_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v590_4));
            drop(v590_4);
            let v590_8: Space = if (&(v590_5)).is_empty() { Space::new() } else {
              let v591_6: Path = concat_path(&(v589_6),&v581_34_cursor.path()[(v581_34_origin + 2)..(v581_34_origin + 3)]);
              let v591_7: Space = routine_48(c, &(v591_6), &v581_34_cursor, &(*s1));
              map_map_kernels::compose(&(v590_5),&(v591_7))
            };
            drop(v590_5);
            let v590_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v590_2));
            drop(v590_2);
            let v590_10: Space = if map_kernels::has_head(&(v590_9)) { singleton(&[]) } else { Space::new() };
            drop(v590_9);
            let v590_12: Space = if (&(v590_10)).is_empty() { Space::new() } else {
              let v592_6: Path = concat_path(&(v589_6),&v581_34_cursor.path()[(v581_34_origin + 2)..(v581_34_origin + 3)]);
              let v592_11: Space = routine_3(c, &(v592_6), &v581_34_cursor, &(*s1));
              drop(v592_6);
              map_map_kernels::compose(&(v590_10),&(v592_11))
            };
            drop(v590_10);
            let v590_13: Space = map_map_kernels::unite(&(v590_8),&(v590_12));
            join_wrapped_into(&mut v589_11_write,&((v590_13).read_zipper()),&[]);
            }
            v581_34_cursor.ascend(1);
          }
          drop(v589_11_write);
          drop(v589_6);
          map_map_kernels::compose(&(v584_10),&(v589_11))
        };
        drop(v584_10);
        let v584_13: Space = map_map_kernels::unite(&(v584_8),&(v584_12));
        join_wrapped_into(&mut v583_7_write,&((v584_13).read_zipper()),&[]);
        }
        v581_34_cursor.ascend(1);
      }
      drop(v583_7_write);
      map_map_kernels::compose(&(v582_5),&(v583_7))
    };
    drop(v582_5);
    let v582_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v582_2));
    drop(v582_2);
    let v582_10: Space = if map_kernels::has_head(&(v582_9)) { singleton(&[]) } else { Space::new() };
    drop(v582_9);
    let v582_13: Space = if (&(v582_10)).is_empty() { Space::new() } else {
      let v593_6: Path = concat_path(&(*p0),&v581_34_cursor.path()[v581_34_origin..(v581_34_origin + 1)]);
      let mut v593_12 = Space::new();
      let mut v593_12_write = v593_12.write_zipper();
      for v593_12_byte in v581_34_cursor.child_mask().iter() {
        v581_34_cursor.descend_to_existing_byte(v593_12_byte);
        {
        let v594_2: Space = singleton(&v581_34_cursor.path()[(v581_34_origin + 1)..(v581_34_origin + 2)]);
        let v594_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v594_2));
        let v594_4: Space = if map_kernels::has_head(&(v594_3)) { singleton(&[]) } else { Space::new() };
        drop(v594_3);
        let v594_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v594_4));
        drop(v594_4);
        let v594_8: Space = if (&(v594_5)).is_empty() { Space::new() } else {
          let v595_6: Path = concat_path(&(v593_6),&v581_34_cursor.path()[(v581_34_origin + 1)..(v581_34_origin + 2)]);
          let mut v595_7 = Space::new();
          let mut v595_7_write = v595_7.write_zipper();
          for v595_7_byte in v581_34_cursor.child_mask().iter() {
            v581_34_cursor.descend_to_existing_byte(v595_7_byte);
            {
            let v596_2: Space = singleton(&v581_34_cursor.path()[(v581_34_origin + 2)..(v581_34_origin + 3)]);
            let v596_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v596_2));
            let v596_4: Space = if map_kernels::has_head(&(v596_3)) { singleton(&[]) } else { Space::new() };
            drop(v596_3);
            let v596_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v596_4));
            drop(v596_4);
            let v596_8: Space = if (&(v596_5)).is_empty() { Space::new() } else {
              let v597_6: Path = concat_path(&(v595_6),&v581_34_cursor.path()[(v581_34_origin + 2)..(v581_34_origin + 3)]);
              let v597_7: Space = routine_48(c, &(v597_6), &v581_34_cursor, &(*s1));
              map_map_kernels::compose(&(v596_5),&(v597_7))
            };
            drop(v596_5);
            let v596_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v596_2));
            drop(v596_2);
            let v596_10: Space = if map_kernels::has_head(&(v596_9)) { singleton(&[]) } else { Space::new() };
            drop(v596_9);
            let v596_12: Space = if (&(v596_10)).is_empty() { Space::new() } else {
              let v598_6: Path = concat_path(&(v595_6),&v581_34_cursor.path()[(v581_34_origin + 2)..(v581_34_origin + 3)]);
              let v598_11: Space = routine_49(c, &(v598_6), &v581_34_cursor, &(*s1));
              drop(v598_6);
              map_map_kernels::compose(&(v596_10),&(v598_11))
            };
            drop(v596_10);
            let v596_13: Space = map_map_kernels::unite(&(v596_8),&(v596_12));
            join_wrapped_into(&mut v595_7_write,&((v596_13).read_zipper()),&[]);
            }
            v581_34_cursor.ascend(1);
          }
          drop(v595_7_write);
          map_map_kernels::compose(&(v594_5),&(v595_7))
        };
        drop(v594_5);
        let v594_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v594_2));
        drop(v594_2);
        let v594_10: Space = if map_kernels::has_head(&(v594_9)) { singleton(&[]) } else { Space::new() };
        drop(v594_9);
        let v594_18: Space = if (&(v594_10)).is_empty() { Space::new() } else {
          let v599_12: Space = view_view_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v581_34_cursor.path()[v581_34_origin..(v581_34_origin + 1)]),&v581_34_cursor.path()[(v581_34_origin + 1)..(v581_34_origin + 2)])));
          let mut v599_13 = Space::new();
          let mut v599_13_write = v599_13.write_zipper();
          let mut v599_13_cursor = (v599_12).read_zipper();
          let v599_13_origin = v599_13_cursor.path().len();
          for v599_13_byte in v599_13_cursor.child_mask().iter() {
            v599_13_cursor.descend_to_existing_byte(v599_13_byte);
            {
            let v600_2: Space = singleton(&v599_13_cursor.path()[v599_13_origin..(v599_13_origin + 1)]);
            let v600_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v600_2));
            let v600_4: Space = if map_kernels::has_head(&(v600_3)) { singleton(&[]) } else { Space::new() };
            drop(v600_3);
            let v600_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v600_4));
            drop(v600_4);
            let v600_7: Space = if (&(v600_5)).is_empty() { Space::new() } else {
              let v601_6: Space = routine_6(c, &v599_13_cursor.path()[v599_13_origin..(v599_13_origin + 1)], &v599_13_cursor);
              map_map_kernels::compose(&(v600_5),&(v601_6))
            };
            drop(v600_5);
            let v600_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v600_2));
            drop(v600_2);
            let v600_9: Space = if map_kernels::has_head(&(v600_8)) { singleton(&[]) } else { Space::new() };
            drop(v600_8);
            let v600_11: Space = if (&(v600_9)).is_empty() { Space::new() } else {
              let v602_10: Space = routine_7(c, &v599_13_cursor.path()[v599_13_origin..(v599_13_origin + 1)], &v599_13_cursor);
              map_map_kernels::compose(&(v600_9),&(v602_10))
            };
            drop(v600_9);
            let v600_12: Space = map_map_kernels::unite(&(v600_7),&(v600_11));
            join_wrapped_into(&mut v599_13_write,&((v600_12).read_zipper()),&[]);
            }
            v599_13_cursor.ascend(1);
          }
          drop(v599_13_cursor);
          drop(v599_13_write);
          drop(v599_12);
          let v599_14: Space = view_map_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v599_13));
          let mut v599_15 = Space::new();
          let mut v599_15_write = v599_15.write_zipper();
          let mut v599_15_cursor = (v599_14).read_zipper();
          let v599_15_origin = v599_15_cursor.path().len();
          for v599_15_byte in v599_15_cursor.child_mask().iter() {
            v599_15_cursor.descend_to_existing_byte(v599_15_byte);
            {
            let v603_2: Space = singleton(&v599_15_cursor.path()[v599_15_origin..(v599_15_origin + 1)]);
            let v603_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v603_2));
            let v603_4: Space = if map_kernels::has_head(&(v603_3)) { singleton(&[]) } else { Space::new() };
            drop(v603_3);
            let v603_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v603_4));
            drop(v603_4);
            let v603_7: Space = if (&(v603_5)).is_empty() { Space::new() } else {
              let v604_6: Space = routine_8(c, &v599_15_cursor.path()[v599_15_origin..(v599_15_origin + 1)], &v599_15_cursor);
              map_map_kernels::compose(&(v603_5),&(v604_6))
            };
            drop(v603_5);
            let v603_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v603_2));
            drop(v603_2);
            let v603_9: Space = if map_kernels::has_head(&(v603_8)) { singleton(&[]) } else { Space::new() };
            drop(v603_8);
            let v603_11: Space = if (&(v603_9)).is_empty() { Space::new() } else {
              let v605_10: Space = routine_9(c, &v599_15_cursor.path()[v599_15_origin..(v599_15_origin + 1)], &v599_15_cursor);
              map_map_kernels::compose(&(v603_9),&(v605_10))
            };
            drop(v603_9);
            let v603_12: Space = map_map_kernels::unite(&(v603_7),&(v603_11));
            join_wrapped_into(&mut v599_15_write,&((v603_12).read_zipper()),&[]);
            }
            v599_15_cursor.ascend(1);
          }
          drop(v599_15_cursor);
          drop(v599_15_write);
          let v599_16: Space = map_view_kernels::subtract(&(v599_15),&(descend_cursor(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v581_34_cursor.path()[v581_34_origin..(v581_34_origin + 1)]),&v581_34_cursor.path()[(v581_34_origin + 1)..(v581_34_origin + 2)])));
          let v599_17: Space = map_view_kernels::intersect(&(v599_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
          map_map_kernels::compose(&(v594_10),&(v599_17))
        };
        drop(v594_10);
        let v606_6: Path = concat_path(&(v593_6),&v581_34_cursor.path()[(v581_34_origin + 1)..(v581_34_origin + 2)]);
        let v594_19: Space = map_kernels::wrap(&(v594_18),&(v606_6));
        let v594_20: Space = map_map_kernels::unite(&(v594_8),&(v594_19));
        join_wrapped_into(&mut v593_12_write,&((v594_20).read_zipper()),&[]);
        }
        v581_34_cursor.ascend(1);
      }
      drop(v593_12_write);
      drop(v593_6);
      map_map_kernels::compose(&(v582_10),&(v593_12))
    };
    drop(v582_10);
    let v582_14: Space = map_map_kernels::unite(&(v582_8),&(v582_13));
    join_wrapped_into(&mut v581_34_write,&((v582_14).read_zipper()),&[]);
    }
    v581_34_cursor.ascend(1);
  }
  drop(v581_34_cursor);
  drop(v581_34_write);
  (v581_34).clone()
}

fn routine_35(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v607_40 = Space::new();
  let mut v607_40_write = v607_40.write_zipper();
  let mut v607_40_cursor = (*s0).read_zipper();
  let v607_40_origin = v607_40_cursor.path().len();
  for v607_40_byte in v607_40_cursor.child_mask().iter() {
    v607_40_cursor.descend_to_existing_byte(v607_40_byte);
    {
    let v608_2: Space = singleton(&v607_40_cursor.path()[v607_40_origin..(v607_40_origin + 1)]);
    let v608_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v608_2));
    let v608_4: Space = if map_kernels::has_head(&(v608_3)) { singleton(&[]) } else { Space::new() };
    drop(v608_3);
    let v608_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v608_4));
    drop(v608_4);
    let v608_8: Space = if (&(v608_5)).is_empty() { Space::new() } else {
      let v609_6: Path = concat_path(&(*p0),&v607_40_cursor.path()[v607_40_origin..(v607_40_origin + 1)]);
      let mut v609_7 = Space::new();
      let mut v609_7_write = v609_7.write_zipper();
      for v609_7_byte in v607_40_cursor.child_mask().iter() {
        v607_40_cursor.descend_to_existing_byte(v609_7_byte);
        {
        let v610_2: Space = singleton(&v607_40_cursor.path()[(v607_40_origin + 1)..(v607_40_origin + 2)]);
        let v610_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v610_2));
        let v610_4: Space = if map_kernels::has_head(&(v610_3)) { singleton(&[]) } else { Space::new() };
        drop(v610_3);
        let v610_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v610_4));
        drop(v610_4);
        let v610_8: Space = if (&(v610_5)).is_empty() { Space::new() } else {
          let v611_6: Path = concat_path(&(v609_6),&v607_40_cursor.path()[(v607_40_origin + 1)..(v607_40_origin + 2)]);
          let mut v611_7 = Space::new();
          let mut v611_7_write = v611_7.write_zipper();
          for v611_7_byte in v607_40_cursor.child_mask().iter() {
            v607_40_cursor.descend_to_existing_byte(v611_7_byte);
            {
            let v612_2: Space = singleton(&v607_40_cursor.path()[(v607_40_origin + 2)..(v607_40_origin + 3)]);
            let v612_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v612_2));
            let v612_4: Space = if map_kernels::has_head(&(v612_3)) { singleton(&[]) } else { Space::new() };
            drop(v612_3);
            let v612_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v612_4));
            drop(v612_4);
            let v612_8: Space = if (&(v612_5)).is_empty() { Space::new() } else {
              let v613_6: Path = concat_path(&(v611_6),&v607_40_cursor.path()[(v607_40_origin + 2)..(v607_40_origin + 3)]);
              let v613_7: Space = routine_48(c, &(v613_6), &v607_40_cursor, &(*s1));
              map_map_kernels::compose(&(v612_5),&(v613_7))
            };
            drop(v612_5);
            let v612_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v612_2));
            drop(v612_2);
            let v612_10: Space = if map_kernels::has_head(&(v612_9)) { singleton(&[]) } else { Space::new() };
            drop(v612_9);
            let v612_12: Space = if (&(v612_10)).is_empty() { Space::new() } else {
              let v614_6: Path = concat_path(&(v611_6),&v607_40_cursor.path()[(v607_40_origin + 2)..(v607_40_origin + 3)]);
              let v614_11: Space = routine_49(c, &(v614_6), &v607_40_cursor, &(*s1));
              drop(v614_6);
              map_map_kernels::compose(&(v612_10),&(v614_11))
            };
            drop(v612_10);
            let v612_13: Space = map_map_kernels::unite(&(v612_8),&(v612_12));
            join_wrapped_into(&mut v611_7_write,&((v612_13).read_zipper()),&[]);
            }
            v607_40_cursor.ascend(1);
          }
          drop(v611_7_write);
          map_map_kernels::compose(&(v610_5),&(v611_7))
        };
        drop(v610_5);
        let v610_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v610_2));
        drop(v610_2);
        let v610_10: Space = if map_kernels::has_head(&(v610_9)) { singleton(&[]) } else { Space::new() };
        drop(v610_9);
        let v610_12: Space = if (&(v610_10)).is_empty() { Space::new() } else {
          let v615_6: Path = concat_path(&(v609_6),&v607_40_cursor.path()[(v607_40_origin + 1)..(v607_40_origin + 2)]);
          let mut v615_11 = Space::new();
          let mut v615_11_write = v615_11.write_zipper();
          for v615_11_byte in v607_40_cursor.child_mask().iter() {
            v607_40_cursor.descend_to_existing_byte(v615_11_byte);
            {
            let v616_2: Space = singleton(&v607_40_cursor.path()[(v607_40_origin + 2)..(v607_40_origin + 3)]);
            let v616_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v616_2));
            let v616_4: Space = if map_kernels::has_head(&(v616_3)) { singleton(&[]) } else { Space::new() };
            drop(v616_3);
            let v616_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v616_4));
            drop(v616_4);
            let v616_8: Space = if (&(v616_5)).is_empty() { Space::new() } else {
              let v617_6: Path = concat_path(&(v615_6),&v607_40_cursor.path()[(v607_40_origin + 2)..(v607_40_origin + 3)]);
              let v617_7: Space = routine_48(c, &(v617_6), &v607_40_cursor, &(*s1));
              map_map_kernels::compose(&(v616_5),&(v617_7))
            };
            drop(v616_5);
            let v616_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v616_2));
            drop(v616_2);
            let v616_10: Space = if map_kernels::has_head(&(v616_9)) { singleton(&[]) } else { Space::new() };
            drop(v616_9);
            let v616_12: Space = if (&(v616_10)).is_empty() { Space::new() } else {
              let v618_6: Path = concat_path(&(v615_6),&v607_40_cursor.path()[(v607_40_origin + 2)..(v607_40_origin + 3)]);
              let v618_11: Space = routine_3(c, &(v618_6), &v607_40_cursor, &(*s1));
              drop(v618_6);
              map_map_kernels::compose(&(v616_10),&(v618_11))
            };
            drop(v616_10);
            let v616_13: Space = map_map_kernels::unite(&(v616_8),&(v616_12));
            join_wrapped_into(&mut v615_11_write,&((v616_13).read_zipper()),&[]);
            }
            v607_40_cursor.ascend(1);
          }
          drop(v615_11_write);
          drop(v615_6);
          map_map_kernels::compose(&(v610_10),&(v615_11))
        };
        drop(v610_10);
        let v610_13: Space = map_map_kernels::unite(&(v610_8),&(v610_12));
        join_wrapped_into(&mut v609_7_write,&((v610_13).read_zipper()),&[]);
        }
        v607_40_cursor.ascend(1);
      }
      drop(v609_7_write);
      map_map_kernels::compose(&(v608_5),&(v609_7))
    };
    drop(v608_5);
    let v608_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v608_2));
    drop(v608_2);
    let v608_10: Space = if map_kernels::has_head(&(v608_9)) { singleton(&[]) } else { Space::new() };
    drop(v608_9);
    let v608_18: Space = if (&(v608_10)).is_empty() { Space::new() } else {
      let v619_12: Space = view_view_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v607_40_cursor.path()[v607_40_origin..(v607_40_origin + 1)])));
      let mut v619_13 = Space::new();
      let mut v619_13_write = v619_13.write_zipper();
      let mut v619_13_cursor = (v619_12).read_zipper();
      let v619_13_origin = v619_13_cursor.path().len();
      for v619_13_byte in v619_13_cursor.child_mask().iter() {
        v619_13_cursor.descend_to_existing_byte(v619_13_byte);
        {
        let v620_2: Space = singleton(&v619_13_cursor.path()[v619_13_origin..(v619_13_origin + 1)]);
        let v620_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v620_2));
        let v620_4: Space = if map_kernels::has_head(&(v620_3)) { singleton(&[]) } else { Space::new() };
        drop(v620_3);
        let v620_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v620_4));
        drop(v620_4);
        let v620_7: Space = if (&(v620_5)).is_empty() { Space::new() } else {
          let mut v621_6 = Space::new();
          let mut v621_6_write = v621_6.write_zipper();
          for v621_6_byte in v619_13_cursor.child_mask().iter() {
            v619_13_cursor.descend_to_existing_byte(v621_6_byte);
            {
            let v622_2: Space = singleton(&v619_13_cursor.path()[(v619_13_origin + 1)..(v619_13_origin + 2)]);
            let v622_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v622_2));
            let v622_4: Space = if map_kernels::has_head(&(v622_3)) { singleton(&[]) } else { Space::new() };
            drop(v622_3);
            let v622_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v622_4));
            drop(v622_4);
            let v622_8: Space = if (&(v622_5)).is_empty() { Space::new() } else {
              let v623_7: Space = routine_10(c, &v619_13_cursor.path()[v619_13_origin..(v619_13_origin + 2)], &v619_13_cursor);
              map_map_kernels::compose(&(v622_5),&(v623_7))
            };
            drop(v622_5);
            let v622_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v622_2));
            drop(v622_2);
            let v622_10: Space = if map_kernels::has_head(&(v622_9)) { singleton(&[]) } else { Space::new() };
            drop(v622_9);
            let v622_12: Space = if (&(v622_10)).is_empty() { Space::new() } else {
              let v624_11: Space = routine_11(c, &v619_13_cursor.path()[v619_13_origin..(v619_13_origin + 2)], &v619_13_cursor);
              map_map_kernels::compose(&(v622_10),&(v624_11))
            };
            drop(v622_10);
            let v622_13: Space = map_map_kernels::unite(&(v622_8),&(v622_12));
            join_wrapped_into(&mut v621_6_write,&((v622_13).read_zipper()),&[]);
            }
            v619_13_cursor.ascend(1);
          }
          drop(v621_6_write);
          map_map_kernels::compose(&(v620_5),&(v621_6))
        };
        drop(v620_5);
        let v620_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v620_2));
        drop(v620_2);
        let v620_9: Space = if map_kernels::has_head(&(v620_8)) { singleton(&[]) } else { Space::new() };
        drop(v620_8);
        let v620_11: Space = if (&(v620_9)).is_empty() { Space::new() } else {
          let mut v625_10 = Space::new();
          let mut v625_10_write = v625_10.write_zipper();
          for v625_10_byte in v619_13_cursor.child_mask().iter() {
            v619_13_cursor.descend_to_existing_byte(v625_10_byte);
            {
            let v626_2: Space = singleton(&v619_13_cursor.path()[(v619_13_origin + 1)..(v619_13_origin + 2)]);
            let v626_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v626_2));
            let v626_4: Space = if map_kernels::has_head(&(v626_3)) { singleton(&[]) } else { Space::new() };
            drop(v626_3);
            let v626_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v626_4));
            drop(v626_4);
            let v626_8: Space = if (&(v626_5)).is_empty() { Space::new() } else {
              let v627_7: Space = routine_10(c, &v619_13_cursor.path()[v619_13_origin..(v619_13_origin + 2)], &v619_13_cursor);
              map_map_kernels::compose(&(v626_5),&(v627_7))
            };
            drop(v626_5);
            let v626_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v626_2));
            drop(v626_2);
            let v626_10: Space = if map_kernels::has_head(&(v626_9)) { singleton(&[]) } else { Space::new() };
            drop(v626_9);
            let v626_12: Space = if (&(v626_10)).is_empty() { Space::new() } else {
              let v628_11: Space = routine_12(c, &v619_13_cursor.path()[v619_13_origin..(v619_13_origin + 2)], &v619_13_cursor);
              map_map_kernels::compose(&(v626_10),&(v628_11))
            };
            drop(v626_10);
            let v626_13: Space = map_map_kernels::unite(&(v626_8),&(v626_12));
            join_wrapped_into(&mut v625_10_write,&((v626_13).read_zipper()),&[]);
            }
            v619_13_cursor.ascend(1);
          }
          drop(v625_10_write);
          map_map_kernels::compose(&(v620_9),&(v625_10))
        };
        drop(v620_9);
        let v620_12: Space = map_map_kernels::unite(&(v620_7),&(v620_11));
        join_wrapped_into(&mut v619_13_write,&((v620_12).read_zipper()),&[]);
        }
        v619_13_cursor.ascend(1);
      }
      drop(v619_13_cursor);
      drop(v619_13_write);
      drop(v619_12);
      let v619_14: Space = view_map_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v619_13));
      let mut v619_15 = Space::new();
      let mut v619_15_write = v619_15.write_zipper();
      let mut v619_15_cursor = (v619_14).read_zipper();
      let v619_15_origin = v619_15_cursor.path().len();
      for v619_15_byte in v619_15_cursor.child_mask().iter() {
        v619_15_cursor.descend_to_existing_byte(v619_15_byte);
        {
        let v629_2: Space = singleton(&v619_15_cursor.path()[v619_15_origin..(v619_15_origin + 1)]);
        let v629_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v629_2));
        let v629_4: Space = if map_kernels::has_head(&(v629_3)) { singleton(&[]) } else { Space::new() };
        drop(v629_3);
        let v629_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v629_4));
        drop(v629_4);
        let v629_7: Space = if (&(v629_5)).is_empty() { Space::new() } else {
          let mut v630_6 = Space::new();
          let mut v630_6_write = v630_6.write_zipper();
          for v630_6_byte in v619_15_cursor.child_mask().iter() {
            v619_15_cursor.descend_to_existing_byte(v630_6_byte);
            {
            let v631_2: Space = singleton(&v619_15_cursor.path()[(v619_15_origin + 1)..(v619_15_origin + 2)]);
            let v631_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v631_2));
            let v631_4: Space = if map_kernels::has_head(&(v631_3)) { singleton(&[]) } else { Space::new() };
            drop(v631_3);
            let v631_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v631_4));
            drop(v631_4);
            let v631_8: Space = if (&(v631_5)).is_empty() { Space::new() } else {
              let v632_7: Space = routine_13(c, &v619_15_cursor.path()[v619_15_origin..(v619_15_origin + 2)], &v619_15_cursor);
              map_map_kernels::compose(&(v631_5),&(v632_7))
            };
            drop(v631_5);
            let v631_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v631_2));
            drop(v631_2);
            let v631_10: Space = if map_kernels::has_head(&(v631_9)) { singleton(&[]) } else { Space::new() };
            drop(v631_9);
            let v631_12: Space = if (&(v631_10)).is_empty() { Space::new() } else {
              let v633_11: Space = routine_14(c, &v619_15_cursor.path()[v619_15_origin..(v619_15_origin + 2)], &v619_15_cursor);
              map_map_kernels::compose(&(v631_10),&(v633_11))
            };
            drop(v631_10);
            let v631_13: Space = map_map_kernels::unite(&(v631_8),&(v631_12));
            join_wrapped_into(&mut v630_6_write,&((v631_13).read_zipper()),&[]);
            }
            v619_15_cursor.ascend(1);
          }
          drop(v630_6_write);
          map_map_kernels::compose(&(v629_5),&(v630_6))
        };
        drop(v629_5);
        let v629_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v629_2));
        drop(v629_2);
        let v629_9: Space = if map_kernels::has_head(&(v629_8)) { singleton(&[]) } else { Space::new() };
        drop(v629_8);
        let v629_11: Space = if (&(v629_9)).is_empty() { Space::new() } else {
          let mut v634_10 = Space::new();
          let mut v634_10_write = v634_10.write_zipper();
          for v634_10_byte in v619_15_cursor.child_mask().iter() {
            v619_15_cursor.descend_to_existing_byte(v634_10_byte);
            {
            let v635_2: Space = singleton(&v619_15_cursor.path()[(v619_15_origin + 1)..(v619_15_origin + 2)]);
            let v635_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v635_2));
            let v635_4: Space = if map_kernels::has_head(&(v635_3)) { singleton(&[]) } else { Space::new() };
            drop(v635_3);
            let v635_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v635_4));
            drop(v635_4);
            let v635_8: Space = if (&(v635_5)).is_empty() { Space::new() } else {
              let v636_7: Space = routine_13(c, &v619_15_cursor.path()[v619_15_origin..(v619_15_origin + 2)], &v619_15_cursor);
              map_map_kernels::compose(&(v635_5),&(v636_7))
            };
            drop(v635_5);
            let v635_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v635_2));
            drop(v635_2);
            let v635_10: Space = if map_kernels::has_head(&(v635_9)) { singleton(&[]) } else { Space::new() };
            drop(v635_9);
            let v635_12: Space = if (&(v635_10)).is_empty() { Space::new() } else {
              let v637_11: Space = routine_15(c, &v619_15_cursor.path()[v619_15_origin..(v619_15_origin + 2)], &v619_15_cursor);
              map_map_kernels::compose(&(v635_10),&(v637_11))
            };
            drop(v635_10);
            let v635_13: Space = map_map_kernels::unite(&(v635_8),&(v635_12));
            join_wrapped_into(&mut v634_10_write,&((v635_13).read_zipper()),&[]);
            }
            v619_15_cursor.ascend(1);
          }
          drop(v634_10_write);
          map_map_kernels::compose(&(v629_9),&(v634_10))
        };
        drop(v629_9);
        let v629_12: Space = map_map_kernels::unite(&(v629_7),&(v629_11));
        join_wrapped_into(&mut v619_15_write,&((v629_12).read_zipper()),&[]);
        }
        v619_15_cursor.ascend(1);
      }
      drop(v619_15_cursor);
      drop(v619_15_write);
      let v619_16: Space = map_view_kernels::subtract(&(v619_15),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v607_40_cursor.path()[v607_40_origin..(v607_40_origin + 1)])));
      let v619_17: Space = map_view_kernels::intersect(&(v619_16),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      map_map_kernels::compose(&(v608_10),&(v619_17))
    };
    drop(v608_10);
    let v638_6: Path = concat_path(&(*p0),&v607_40_cursor.path()[v607_40_origin..(v607_40_origin + 1)]);
    let v608_19: Space = map_kernels::wrap(&(v608_18),&(v638_6));
    let v608_20: Space = map_map_kernels::unite(&(v608_8),&(v608_19));
    join_wrapped_into(&mut v607_40_write,&((v608_20).read_zipper()),&[]);
    }
    v607_40_cursor.ascend(1);
  }
  drop(v607_40_cursor);
  drop(v607_40_write);
  (v607_40).clone()
}

fn routine_36(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v639_20 = Space::new();
  let mut v639_20_write = v639_20.write_zipper();
  let mut v639_20_cursor = (*s0).read_zipper();
  let v639_20_origin = v639_20_cursor.path().len();
  for v639_20_byte in v639_20_cursor.child_mask().iter() {
    v639_20_cursor.descend_to_existing_byte(v639_20_byte);
    {
    let v640_2: Space = singleton(&v639_20_cursor.path()[v639_20_origin..(v639_20_origin + 1)]);
    let v640_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v640_2));
    let v640_4: Space = if map_kernels::has_head(&(v640_3)) { singleton(&[]) } else { Space::new() };
    drop(v640_3);
    let v640_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v640_4));
    drop(v640_4);
    let v640_8: Space = if (&(v640_5)).is_empty() { Space::new() } else {
      let v641_6: Path = concat_path(&(*p0),&v639_20_cursor.path()[v639_20_origin..(v639_20_origin + 1)]);
      let mut v641_7 = Space::new();
      let mut v641_7_write = v641_7.write_zipper();
      for v641_7_byte in v639_20_cursor.child_mask().iter() {
        v639_20_cursor.descend_to_existing_byte(v641_7_byte);
        {
        let v642_2: Space = singleton(&v639_20_cursor.path()[(v639_20_origin + 1)..(v639_20_origin + 2)]);
        let v642_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v642_2));
        let v642_4: Space = if map_kernels::has_head(&(v642_3)) { singleton(&[]) } else { Space::new() };
        drop(v642_3);
        let v642_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v642_4));
        drop(v642_4);
        let v642_8: Space = if (&(v642_5)).is_empty() { Space::new() } else {
          let v643_6: Path = concat_path(&(v641_6),&v639_20_cursor.path()[(v639_20_origin + 1)..(v639_20_origin + 2)]);
          let mut v643_7 = Space::new();
          let mut v643_7_write = v643_7.write_zipper();
          for v643_7_byte in v639_20_cursor.child_mask().iter() {
            v639_20_cursor.descend_to_existing_byte(v643_7_byte);
            {
            let v644_2: Space = singleton(&v639_20_cursor.path()[(v639_20_origin + 2)..(v639_20_origin + 3)]);
            let v644_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v644_2));
            let v644_4: Space = if map_kernels::has_head(&(v644_3)) { singleton(&[]) } else { Space::new() };
            drop(v644_3);
            let v644_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v644_4));
            drop(v644_4);
            let v644_8: Space = if (&(v644_5)).is_empty() { Space::new() } else {
              let v645_6: Path = concat_path(&(v643_6),&v639_20_cursor.path()[(v639_20_origin + 2)..(v639_20_origin + 3)]);
              let v645_7: Space = routine_50(c, &(v645_6), &v639_20_cursor);
              map_map_kernels::compose(&(v644_5),&(v645_7))
            };
            drop(v644_5);
            let v644_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v644_2));
            drop(v644_2);
            let v644_10: Space = if map_kernels::has_head(&(v644_9)) { singleton(&[]) } else { Space::new() };
            drop(v644_9);
            let v644_12: Space = if (&(v644_10)).is_empty() { Space::new() } else {
              let v646_6: Path = concat_path(&(v643_6),&v639_20_cursor.path()[(v639_20_origin + 2)..(v639_20_origin + 3)]);
              let v646_11: Space = routine_51(c, &(v646_6), &v639_20_cursor);
              drop(v646_6);
              map_map_kernels::compose(&(v644_10),&(v646_11))
            };
            drop(v644_10);
            let v644_13: Space = map_map_kernels::unite(&(v644_8),&(v644_12));
            join_wrapped_into(&mut v643_7_write,&((v644_13).read_zipper()),&[]);
            }
            v639_20_cursor.ascend(1);
          }
          drop(v643_7_write);
          map_map_kernels::compose(&(v642_5),&(v643_7))
        };
        drop(v642_5);
        let v642_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v642_2));
        drop(v642_2);
        let v642_10: Space = if map_kernels::has_head(&(v642_9)) { singleton(&[]) } else { Space::new() };
        drop(v642_9);
        let v642_12: Space = if (&(v642_10)).is_empty() { Space::new() } else {
          let v647_6: Path = concat_path(&(v641_6),&v639_20_cursor.path()[(v639_20_origin + 1)..(v639_20_origin + 2)]);
          let mut v647_11 = Space::new();
          let mut v647_11_write = v647_11.write_zipper();
          for v647_11_byte in v639_20_cursor.child_mask().iter() {
            v639_20_cursor.descend_to_existing_byte(v647_11_byte);
            {
            let v648_2: Space = singleton(&v639_20_cursor.path()[(v639_20_origin + 2)..(v639_20_origin + 3)]);
            let v648_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v648_2));
            let v648_4: Space = if map_kernels::has_head(&(v648_3)) { singleton(&[]) } else { Space::new() };
            drop(v648_3);
            let v648_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v648_4));
            drop(v648_4);
            let v648_8: Space = if (&(v648_5)).is_empty() { Space::new() } else {
              let v649_6: Path = concat_path(&(v647_6),&v639_20_cursor.path()[(v639_20_origin + 2)..(v639_20_origin + 3)]);
              let v649_7: Space = routine_50(c, &(v649_6), &v639_20_cursor);
              map_map_kernels::compose(&(v648_5),&(v649_7))
            };
            drop(v648_5);
            let v648_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v648_2));
            drop(v648_2);
            let v648_10: Space = if map_kernels::has_head(&(v648_9)) { singleton(&[]) } else { Space::new() };
            drop(v648_9);
            let v648_12: Space = if (&(v648_10)).is_empty() { Space::new() } else {
              let v650_6: Path = concat_path(&(v647_6),&v639_20_cursor.path()[(v639_20_origin + 2)..(v639_20_origin + 3)]);
              let v650_11: Space = routine_12(c, &(v650_6), &v639_20_cursor);
              drop(v650_6);
              map_map_kernels::compose(&(v648_10),&(v650_11))
            };
            drop(v648_10);
            let v648_13: Space = map_map_kernels::unite(&(v648_8),&(v648_12));
            join_wrapped_into(&mut v647_11_write,&((v648_13).read_zipper()),&[]);
            }
            v639_20_cursor.ascend(1);
          }
          drop(v647_11_write);
          drop(v647_6);
          map_map_kernels::compose(&(v642_10),&(v647_11))
        };
        drop(v642_10);
        let v642_13: Space = map_map_kernels::unite(&(v642_8),&(v642_12));
        join_wrapped_into(&mut v641_7_write,&((v642_13).read_zipper()),&[]);
        }
        v639_20_cursor.ascend(1);
      }
      drop(v641_7_write);
      map_map_kernels::compose(&(v640_5),&(v641_7))
    };
    drop(v640_5);
    let v640_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v640_2));
    drop(v640_2);
    let v640_10: Space = if map_kernels::has_head(&(v640_9)) { singleton(&[]) } else { Space::new() };
    drop(v640_9);
    let v640_12: Space = if (&(v640_10)).is_empty() { Space::new() } else {
      let v651_6: Path = concat_path(&(*p0),&v639_20_cursor.path()[v639_20_origin..(v639_20_origin + 1)]);
      let mut v651_11 = Space::new();
      let mut v651_11_write = v651_11.write_zipper();
      for v651_11_byte in v639_20_cursor.child_mask().iter() {
        v639_20_cursor.descend_to_existing_byte(v651_11_byte);
        {
        let v652_2: Space = singleton(&v639_20_cursor.path()[(v639_20_origin + 1)..(v639_20_origin + 2)]);
        let v652_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v652_2));
        let v652_4: Space = if map_kernels::has_head(&(v652_3)) { singleton(&[]) } else { Space::new() };
        drop(v652_3);
        let v652_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v652_4));
        drop(v652_4);
        let v652_8: Space = if (&(v652_5)).is_empty() { Space::new() } else {
          let v653_6: Path = concat_path(&(v651_6),&v639_20_cursor.path()[(v639_20_origin + 1)..(v639_20_origin + 2)]);
          let mut v653_7 = Space::new();
          let mut v653_7_write = v653_7.write_zipper();
          for v653_7_byte in v639_20_cursor.child_mask().iter() {
            v639_20_cursor.descend_to_existing_byte(v653_7_byte);
            {
            let v654_2: Space = singleton(&v639_20_cursor.path()[(v639_20_origin + 2)..(v639_20_origin + 3)]);
            let v654_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v654_2));
            let v654_4: Space = if map_kernels::has_head(&(v654_3)) { singleton(&[]) } else { Space::new() };
            drop(v654_3);
            let v654_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v654_4));
            drop(v654_4);
            let v654_8: Space = if (&(v654_5)).is_empty() { Space::new() } else {
              let v655_6: Path = concat_path(&(v653_6),&v639_20_cursor.path()[(v639_20_origin + 2)..(v639_20_origin + 3)]);
              let v655_7: Space = routine_50(c, &(v655_6), &v639_20_cursor);
              map_map_kernels::compose(&(v654_5),&(v655_7))
            };
            drop(v654_5);
            let v654_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v654_2));
            drop(v654_2);
            let v654_10: Space = if map_kernels::has_head(&(v654_9)) { singleton(&[]) } else { Space::new() };
            drop(v654_9);
            let v654_12: Space = if (&(v654_10)).is_empty() { Space::new() } else {
              let v656_6: Path = concat_path(&(v653_6),&v639_20_cursor.path()[(v639_20_origin + 2)..(v639_20_origin + 3)]);
              let v656_11: Space = routine_51(c, &(v656_6), &v639_20_cursor);
              drop(v656_6);
              map_map_kernels::compose(&(v654_10),&(v656_11))
            };
            drop(v654_10);
            let v654_13: Space = map_map_kernels::unite(&(v654_8),&(v654_12));
            join_wrapped_into(&mut v653_7_write,&((v654_13).read_zipper()),&[]);
            }
            v639_20_cursor.ascend(1);
          }
          drop(v653_7_write);
          drop(v653_6);
          map_map_kernels::compose(&(v652_5),&(v653_7))
        };
        drop(v652_5);
        let v652_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v652_2));
        drop(v652_2);
        let v652_10: Space = if map_kernels::has_head(&(v652_9)) { singleton(&[]) } else { Space::new() };
        drop(v652_9);
        let v652_11: Space = map_view_kernels::compose(&(v652_10),&v639_20_cursor);
        drop(v652_10);
        let v652_12: Space = map_map_kernels::unite(&(v652_8),&(v652_11));
        drop(v652_11);
        join_wrapped_into(&mut v651_11_write,&((v652_12).read_zipper()),&[]);
        }
        v639_20_cursor.ascend(1);
      }
      drop(v651_11_write);
      drop(v651_6);
      map_map_kernels::compose(&(v640_10),&(v651_11))
    };
    drop(v640_10);
    let v640_13: Space = map_map_kernels::unite(&(v640_8),&(v640_12));
    join_wrapped_into(&mut v639_20_write,&((v640_13).read_zipper()),&[]);
    }
    v639_20_cursor.ascend(1);
  }
  drop(v639_20_cursor);
  drop(v639_20_write);
  (v639_20).clone()
}

fn routine_37(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v657_14 = Space::new();
  let mut v657_14_write = v657_14.write_zipper();
  let mut v657_14_cursor = (*s0).read_zipper();
  let v657_14_origin = v657_14_cursor.path().len();
  for v657_14_byte in v657_14_cursor.child_mask().iter() {
    v657_14_cursor.descend_to_existing_byte(v657_14_byte);
    {
    let v658_2: Space = singleton(&v657_14_cursor.path()[v657_14_origin..(v657_14_origin + 1)]);
    let v658_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v658_2));
    let v658_4: Space = if map_kernels::has_head(&(v658_3)) { singleton(&[]) } else { Space::new() };
    drop(v658_3);
    let v658_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v658_4));
    drop(v658_4);
    let v658_8: Space = if (&(v658_5)).is_empty() { Space::new() } else {
      let v659_6: Path = concat_path(&(*p0),&v657_14_cursor.path()[v657_14_origin..(v657_14_origin + 1)]);
      let mut v659_7 = Space::new();
      let mut v659_7_write = v659_7.write_zipper();
      for v659_7_byte in v657_14_cursor.child_mask().iter() {
        v657_14_cursor.descend_to_existing_byte(v659_7_byte);
        {
        let v660_2: Space = singleton(&v657_14_cursor.path()[(v657_14_origin + 1)..(v657_14_origin + 2)]);
        let v660_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v660_2));
        let v660_4: Space = if map_kernels::has_head(&(v660_3)) { singleton(&[]) } else { Space::new() };
        drop(v660_3);
        let v660_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v660_4));
        drop(v660_4);
        let v660_8: Space = if (&(v660_5)).is_empty() { Space::new() } else {
          let v661_6: Path = concat_path(&(v659_6),&v657_14_cursor.path()[(v657_14_origin + 1)..(v657_14_origin + 2)]);
          let mut v661_7 = Space::new();
          let mut v661_7_write = v661_7.write_zipper();
          for v661_7_byte in v657_14_cursor.child_mask().iter() {
            v657_14_cursor.descend_to_existing_byte(v661_7_byte);
            {
            let v662_2: Space = singleton(&v657_14_cursor.path()[(v657_14_origin + 2)..(v657_14_origin + 3)]);
            let v662_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v662_2));
            let v662_4: Space = if map_kernels::has_head(&(v662_3)) { singleton(&[]) } else { Space::new() };
            drop(v662_3);
            let v662_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v662_4));
            drop(v662_4);
            let v662_8: Space = if (&(v662_5)).is_empty() { Space::new() } else {
              let v663_6: Path = concat_path(&(v661_6),&v657_14_cursor.path()[(v657_14_origin + 2)..(v657_14_origin + 3)]);
              let v663_7: Space = routine_50(c, &(v663_6), &v657_14_cursor);
              map_map_kernels::compose(&(v662_5),&(v663_7))
            };
            drop(v662_5);
            let v662_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v662_2));
            drop(v662_2);
            let v662_10: Space = if map_kernels::has_head(&(v662_9)) { singleton(&[]) } else { Space::new() };
            drop(v662_9);
            let v662_12: Space = if (&(v662_10)).is_empty() { Space::new() } else {
              let v664_6: Path = concat_path(&(v661_6),&v657_14_cursor.path()[(v657_14_origin + 2)..(v657_14_origin + 3)]);
              let v664_11: Space = routine_51(c, &(v664_6), &v657_14_cursor);
              drop(v664_6);
              map_map_kernels::compose(&(v662_10),&(v664_11))
            };
            drop(v662_10);
            let v662_13: Space = map_map_kernels::unite(&(v662_8),&(v662_12));
            join_wrapped_into(&mut v661_7_write,&((v662_13).read_zipper()),&[]);
            }
            v657_14_cursor.ascend(1);
          }
          drop(v661_7_write);
          map_map_kernels::compose(&(v660_5),&(v661_7))
        };
        drop(v660_5);
        let v660_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v660_2));
        drop(v660_2);
        let v660_10: Space = if map_kernels::has_head(&(v660_9)) { singleton(&[]) } else { Space::new() };
        drop(v660_9);
        let v660_12: Space = if (&(v660_10)).is_empty() { Space::new() } else {
          let v665_6: Path = concat_path(&(v659_6),&v657_14_cursor.path()[(v657_14_origin + 1)..(v657_14_origin + 2)]);
          let mut v665_11 = Space::new();
          let mut v665_11_write = v665_11.write_zipper();
          for v665_11_byte in v657_14_cursor.child_mask().iter() {
            v657_14_cursor.descend_to_existing_byte(v665_11_byte);
            {
            let v666_2: Space = singleton(&v657_14_cursor.path()[(v657_14_origin + 2)..(v657_14_origin + 3)]);
            let v666_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v666_2));
            let v666_4: Space = if map_kernels::has_head(&(v666_3)) { singleton(&[]) } else { Space::new() };
            drop(v666_3);
            let v666_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v666_4));
            drop(v666_4);
            let v666_8: Space = if (&(v666_5)).is_empty() { Space::new() } else {
              let v667_6: Path = concat_path(&(v665_6),&v657_14_cursor.path()[(v657_14_origin + 2)..(v657_14_origin + 3)]);
              let v667_7: Space = routine_50(c, &(v667_6), &v657_14_cursor);
              map_map_kernels::compose(&(v666_5),&(v667_7))
            };
            drop(v666_5);
            let v666_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v666_2));
            drop(v666_2);
            let v666_10: Space = if map_kernels::has_head(&(v666_9)) { singleton(&[]) } else { Space::new() };
            drop(v666_9);
            let v666_12: Space = if (&(v666_10)).is_empty() { Space::new() } else {
              let v668_6: Path = concat_path(&(v665_6),&v657_14_cursor.path()[(v657_14_origin + 2)..(v657_14_origin + 3)]);
              let v668_11: Space = routine_12(c, &(v668_6), &v657_14_cursor);
              drop(v668_6);
              map_map_kernels::compose(&(v666_10),&(v668_11))
            };
            drop(v666_10);
            let v666_13: Space = map_map_kernels::unite(&(v666_8),&(v666_12));
            join_wrapped_into(&mut v665_11_write,&((v666_13).read_zipper()),&[]);
            }
            v657_14_cursor.ascend(1);
          }
          drop(v665_11_write);
          drop(v665_6);
          map_map_kernels::compose(&(v660_10),&(v665_11))
        };
        drop(v660_10);
        let v660_13: Space = map_map_kernels::unite(&(v660_8),&(v660_12));
        join_wrapped_into(&mut v659_7_write,&((v660_13).read_zipper()),&[]);
        }
        v657_14_cursor.ascend(1);
      }
      drop(v659_7_write);
      drop(v659_6);
      map_map_kernels::compose(&(v658_5),&(v659_7))
    };
    drop(v658_5);
    let v658_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v658_2));
    drop(v658_2);
    let v658_10: Space = if map_kernels::has_head(&(v658_9)) { singleton(&[]) } else { Space::new() };
    drop(v658_9);
    let v658_11: Space = map_view_kernels::compose(&(v658_10),&v657_14_cursor);
    drop(v658_10);
    let v658_12: Space = map_map_kernels::unite(&(v658_8),&(v658_11));
    drop(v658_11);
    join_wrapped_into(&mut v657_14_write,&((v658_12).read_zipper()),&[]);
    }
    v657_14_cursor.ascend(1);
  }
  drop(v657_14_cursor);
  drop(v657_14_write);
  (v657_14).clone()
}

fn routine_38(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v669_20 = Space::new();
  let mut v669_20_write = v669_20.write_zipper();
  let mut v669_20_cursor = (*s0).read_zipper();
  let v669_20_origin = v669_20_cursor.path().len();
  for v669_20_byte in v669_20_cursor.child_mask().iter() {
    v669_20_cursor.descend_to_existing_byte(v669_20_byte);
    {
    let v670_2: Space = singleton(&v669_20_cursor.path()[v669_20_origin..(v669_20_origin + 1)]);
    let v670_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v670_2));
    let v670_4: Space = if map_kernels::has_head(&(v670_3)) { singleton(&[]) } else { Space::new() };
    drop(v670_3);
    let v670_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v670_4));
    drop(v670_4);
    let v670_8: Space = if (&(v670_5)).is_empty() { Space::new() } else {
      let v671_6: Path = concat_path(&(*p0),&v669_20_cursor.path()[v669_20_origin..(v669_20_origin + 1)]);
      let mut v671_7 = Space::new();
      let mut v671_7_write = v671_7.write_zipper();
      for v671_7_byte in v669_20_cursor.child_mask().iter() {
        v669_20_cursor.descend_to_existing_byte(v671_7_byte);
        {
        let v672_2: Space = singleton(&v669_20_cursor.path()[(v669_20_origin + 1)..(v669_20_origin + 2)]);
        let v672_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v672_2));
        let v672_4: Space = if map_kernels::has_head(&(v672_3)) { singleton(&[]) } else { Space::new() };
        drop(v672_3);
        let v672_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v672_4));
        drop(v672_4);
        let v672_8: Space = if (&(v672_5)).is_empty() { Space::new() } else {
          let v673_6: Path = concat_path(&(v671_6),&v669_20_cursor.path()[(v669_20_origin + 1)..(v669_20_origin + 2)]);
          let mut v673_7 = Space::new();
          let mut v673_7_write = v673_7.write_zipper();
          for v673_7_byte in v669_20_cursor.child_mask().iter() {
            v669_20_cursor.descend_to_existing_byte(v673_7_byte);
            {
            let v674_2: Space = singleton(&v669_20_cursor.path()[(v669_20_origin + 2)..(v669_20_origin + 3)]);
            let v674_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v674_2));
            let v674_4: Space = if map_kernels::has_head(&(v674_3)) { singleton(&[]) } else { Space::new() };
            drop(v674_3);
            let v674_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v674_4));
            drop(v674_4);
            let v674_8: Space = if (&(v674_5)).is_empty() { Space::new() } else {
              let v675_6: Path = concat_path(&(v673_6),&v669_20_cursor.path()[(v669_20_origin + 2)..(v669_20_origin + 3)]);
              let v675_7: Space = routine_52(c, &(v675_6), &v669_20_cursor);
              map_map_kernels::compose(&(v674_5),&(v675_7))
            };
            drop(v674_5);
            let v674_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v674_2));
            drop(v674_2);
            let v674_10: Space = if map_kernels::has_head(&(v674_9)) { singleton(&[]) } else { Space::new() };
            drop(v674_9);
            let v674_12: Space = if (&(v674_10)).is_empty() { Space::new() } else {
              let v676_6: Path = concat_path(&(v673_6),&v669_20_cursor.path()[(v669_20_origin + 2)..(v669_20_origin + 3)]);
              let v676_11: Space = routine_53(c, &(v676_6), &v669_20_cursor);
              drop(v676_6);
              map_map_kernels::compose(&(v674_10),&(v676_11))
            };
            drop(v674_10);
            let v674_13: Space = map_map_kernels::unite(&(v674_8),&(v674_12));
            join_wrapped_into(&mut v673_7_write,&((v674_13).read_zipper()),&[]);
            }
            v669_20_cursor.ascend(1);
          }
          drop(v673_7_write);
          map_map_kernels::compose(&(v672_5),&(v673_7))
        };
        drop(v672_5);
        let v672_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v672_2));
        drop(v672_2);
        let v672_10: Space = if map_kernels::has_head(&(v672_9)) { singleton(&[]) } else { Space::new() };
        drop(v672_9);
        let v672_12: Space = if (&(v672_10)).is_empty() { Space::new() } else {
          let v677_6: Path = concat_path(&(v671_6),&v669_20_cursor.path()[(v669_20_origin + 1)..(v669_20_origin + 2)]);
          let mut v677_11 = Space::new();
          let mut v677_11_write = v677_11.write_zipper();
          for v677_11_byte in v669_20_cursor.child_mask().iter() {
            v669_20_cursor.descend_to_existing_byte(v677_11_byte);
            {
            let v678_2: Space = singleton(&v669_20_cursor.path()[(v669_20_origin + 2)..(v669_20_origin + 3)]);
            let v678_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v678_2));
            let v678_4: Space = if map_kernels::has_head(&(v678_3)) { singleton(&[]) } else { Space::new() };
            drop(v678_3);
            let v678_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v678_4));
            drop(v678_4);
            let v678_8: Space = if (&(v678_5)).is_empty() { Space::new() } else {
              let v679_6: Path = concat_path(&(v677_6),&v669_20_cursor.path()[(v669_20_origin + 2)..(v669_20_origin + 3)]);
              let v679_7: Space = routine_52(c, &(v679_6), &v669_20_cursor);
              map_map_kernels::compose(&(v678_5),&(v679_7))
            };
            drop(v678_5);
            let v678_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v678_2));
            drop(v678_2);
            let v678_10: Space = if map_kernels::has_head(&(v678_9)) { singleton(&[]) } else { Space::new() };
            drop(v678_9);
            let v678_12: Space = if (&(v678_10)).is_empty() { Space::new() } else {
              let v680_6: Path = concat_path(&(v677_6),&v669_20_cursor.path()[(v669_20_origin + 2)..(v669_20_origin + 3)]);
              let v680_11: Space = routine_15(c, &(v680_6), &v669_20_cursor);
              drop(v680_6);
              map_map_kernels::compose(&(v678_10),&(v680_11))
            };
            drop(v678_10);
            let v678_13: Space = map_map_kernels::unite(&(v678_8),&(v678_12));
            join_wrapped_into(&mut v677_11_write,&((v678_13).read_zipper()),&[]);
            }
            v669_20_cursor.ascend(1);
          }
          drop(v677_11_write);
          drop(v677_6);
          map_map_kernels::compose(&(v672_10),&(v677_11))
        };
        drop(v672_10);
        let v672_13: Space = map_map_kernels::unite(&(v672_8),&(v672_12));
        join_wrapped_into(&mut v671_7_write,&((v672_13).read_zipper()),&[]);
        }
        v669_20_cursor.ascend(1);
      }
      drop(v671_7_write);
      map_map_kernels::compose(&(v670_5),&(v671_7))
    };
    drop(v670_5);
    let v670_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v670_2));
    drop(v670_2);
    let v670_10: Space = if map_kernels::has_head(&(v670_9)) { singleton(&[]) } else { Space::new() };
    drop(v670_9);
    let v670_12: Space = if (&(v670_10)).is_empty() { Space::new() } else {
      let v681_6: Path = concat_path(&(*p0),&v669_20_cursor.path()[v669_20_origin..(v669_20_origin + 1)]);
      let mut v681_11 = Space::new();
      let mut v681_11_write = v681_11.write_zipper();
      for v681_11_byte in v669_20_cursor.child_mask().iter() {
        v669_20_cursor.descend_to_existing_byte(v681_11_byte);
        {
        let v682_2: Space = singleton(&v669_20_cursor.path()[(v669_20_origin + 1)..(v669_20_origin + 2)]);
        let v682_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v682_2));
        let v682_4: Space = if map_kernels::has_head(&(v682_3)) { singleton(&[]) } else { Space::new() };
        drop(v682_3);
        let v682_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v682_4));
        drop(v682_4);
        let v682_8: Space = if (&(v682_5)).is_empty() { Space::new() } else {
          let v683_6: Path = concat_path(&(v681_6),&v669_20_cursor.path()[(v669_20_origin + 1)..(v669_20_origin + 2)]);
          let mut v683_7 = Space::new();
          let mut v683_7_write = v683_7.write_zipper();
          for v683_7_byte in v669_20_cursor.child_mask().iter() {
            v669_20_cursor.descend_to_existing_byte(v683_7_byte);
            {
            let v684_2: Space = singleton(&v669_20_cursor.path()[(v669_20_origin + 2)..(v669_20_origin + 3)]);
            let v684_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v684_2));
            let v684_4: Space = if map_kernels::has_head(&(v684_3)) { singleton(&[]) } else { Space::new() };
            drop(v684_3);
            let v684_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v684_4));
            drop(v684_4);
            let v684_8: Space = if (&(v684_5)).is_empty() { Space::new() } else {
              let v685_6: Path = concat_path(&(v683_6),&v669_20_cursor.path()[(v669_20_origin + 2)..(v669_20_origin + 3)]);
              let v685_7: Space = routine_52(c, &(v685_6), &v669_20_cursor);
              map_map_kernels::compose(&(v684_5),&(v685_7))
            };
            drop(v684_5);
            let v684_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v684_2));
            drop(v684_2);
            let v684_10: Space = if map_kernels::has_head(&(v684_9)) { singleton(&[]) } else { Space::new() };
            drop(v684_9);
            let v684_12: Space = if (&(v684_10)).is_empty() { Space::new() } else {
              let v686_6: Path = concat_path(&(v683_6),&v669_20_cursor.path()[(v669_20_origin + 2)..(v669_20_origin + 3)]);
              let v686_11: Space = routine_53(c, &(v686_6), &v669_20_cursor);
              drop(v686_6);
              map_map_kernels::compose(&(v684_10),&(v686_11))
            };
            drop(v684_10);
            let v684_13: Space = map_map_kernels::unite(&(v684_8),&(v684_12));
            join_wrapped_into(&mut v683_7_write,&((v684_13).read_zipper()),&[]);
            }
            v669_20_cursor.ascend(1);
          }
          drop(v683_7_write);
          drop(v683_6);
          map_map_kernels::compose(&(v682_5),&(v683_7))
        };
        drop(v682_5);
        let v682_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v682_2));
        drop(v682_2);
        let v682_10: Space = if map_kernels::has_head(&(v682_9)) { singleton(&[]) } else { Space::new() };
        drop(v682_9);
        let v682_11: Space = map_view_kernels::compose(&(v682_10),&v669_20_cursor);
        drop(v682_10);
        let v682_12: Space = map_map_kernels::unite(&(v682_8),&(v682_11));
        drop(v682_11);
        join_wrapped_into(&mut v681_11_write,&((v682_12).read_zipper()),&[]);
        }
        v669_20_cursor.ascend(1);
      }
      drop(v681_11_write);
      drop(v681_6);
      map_map_kernels::compose(&(v670_10),&(v681_11))
    };
    drop(v670_10);
    let v670_13: Space = map_map_kernels::unite(&(v670_8),&(v670_12));
    join_wrapped_into(&mut v669_20_write,&((v670_13).read_zipper()),&[]);
    }
    v669_20_cursor.ascend(1);
  }
  drop(v669_20_cursor);
  drop(v669_20_write);
  (v669_20).clone()
}

fn routine_39(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v687_14 = Space::new();
  let mut v687_14_write = v687_14.write_zipper();
  let mut v687_14_cursor = (*s0).read_zipper();
  let v687_14_origin = v687_14_cursor.path().len();
  for v687_14_byte in v687_14_cursor.child_mask().iter() {
    v687_14_cursor.descend_to_existing_byte(v687_14_byte);
    {
    let v688_2: Space = singleton(&v687_14_cursor.path()[v687_14_origin..(v687_14_origin + 1)]);
    let v688_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v688_2));
    let v688_4: Space = if map_kernels::has_head(&(v688_3)) { singleton(&[]) } else { Space::new() };
    drop(v688_3);
    let v688_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v688_4));
    drop(v688_4);
    let v688_8: Space = if (&(v688_5)).is_empty() { Space::new() } else {
      let v689_6: Path = concat_path(&(*p0),&v687_14_cursor.path()[v687_14_origin..(v687_14_origin + 1)]);
      let mut v689_7 = Space::new();
      let mut v689_7_write = v689_7.write_zipper();
      for v689_7_byte in v687_14_cursor.child_mask().iter() {
        v687_14_cursor.descend_to_existing_byte(v689_7_byte);
        {
        let v690_2: Space = singleton(&v687_14_cursor.path()[(v687_14_origin + 1)..(v687_14_origin + 2)]);
        let v690_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v690_2));
        let v690_4: Space = if map_kernels::has_head(&(v690_3)) { singleton(&[]) } else { Space::new() };
        drop(v690_3);
        let v690_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v690_4));
        drop(v690_4);
        let v690_8: Space = if (&(v690_5)).is_empty() { Space::new() } else {
          let v691_6: Path = concat_path(&(v689_6),&v687_14_cursor.path()[(v687_14_origin + 1)..(v687_14_origin + 2)]);
          let mut v691_7 = Space::new();
          let mut v691_7_write = v691_7.write_zipper();
          for v691_7_byte in v687_14_cursor.child_mask().iter() {
            v687_14_cursor.descend_to_existing_byte(v691_7_byte);
            {
            let v692_2: Space = singleton(&v687_14_cursor.path()[(v687_14_origin + 2)..(v687_14_origin + 3)]);
            let v692_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v692_2));
            let v692_4: Space = if map_kernels::has_head(&(v692_3)) { singleton(&[]) } else { Space::new() };
            drop(v692_3);
            let v692_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v692_4));
            drop(v692_4);
            let v692_8: Space = if (&(v692_5)).is_empty() { Space::new() } else {
              let v693_6: Path = concat_path(&(v691_6),&v687_14_cursor.path()[(v687_14_origin + 2)..(v687_14_origin + 3)]);
              let v693_7: Space = routine_52(c, &(v693_6), &v687_14_cursor);
              map_map_kernels::compose(&(v692_5),&(v693_7))
            };
            drop(v692_5);
            let v692_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v692_2));
            drop(v692_2);
            let v692_10: Space = if map_kernels::has_head(&(v692_9)) { singleton(&[]) } else { Space::new() };
            drop(v692_9);
            let v692_12: Space = if (&(v692_10)).is_empty() { Space::new() } else {
              let v694_6: Path = concat_path(&(v691_6),&v687_14_cursor.path()[(v687_14_origin + 2)..(v687_14_origin + 3)]);
              let v694_11: Space = routine_53(c, &(v694_6), &v687_14_cursor);
              drop(v694_6);
              map_map_kernels::compose(&(v692_10),&(v694_11))
            };
            drop(v692_10);
            let v692_13: Space = map_map_kernels::unite(&(v692_8),&(v692_12));
            join_wrapped_into(&mut v691_7_write,&((v692_13).read_zipper()),&[]);
            }
            v687_14_cursor.ascend(1);
          }
          drop(v691_7_write);
          map_map_kernels::compose(&(v690_5),&(v691_7))
        };
        drop(v690_5);
        let v690_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v690_2));
        drop(v690_2);
        let v690_10: Space = if map_kernels::has_head(&(v690_9)) { singleton(&[]) } else { Space::new() };
        drop(v690_9);
        let v690_12: Space = if (&(v690_10)).is_empty() { Space::new() } else {
          let v695_6: Path = concat_path(&(v689_6),&v687_14_cursor.path()[(v687_14_origin + 1)..(v687_14_origin + 2)]);
          let mut v695_11 = Space::new();
          let mut v695_11_write = v695_11.write_zipper();
          for v695_11_byte in v687_14_cursor.child_mask().iter() {
            v687_14_cursor.descend_to_existing_byte(v695_11_byte);
            {
            let v696_2: Space = singleton(&v687_14_cursor.path()[(v687_14_origin + 2)..(v687_14_origin + 3)]);
            let v696_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v696_2));
            let v696_4: Space = if map_kernels::has_head(&(v696_3)) { singleton(&[]) } else { Space::new() };
            drop(v696_3);
            let v696_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v696_4));
            drop(v696_4);
            let v696_8: Space = if (&(v696_5)).is_empty() { Space::new() } else {
              let v697_6: Path = concat_path(&(v695_6),&v687_14_cursor.path()[(v687_14_origin + 2)..(v687_14_origin + 3)]);
              let v697_7: Space = routine_52(c, &(v697_6), &v687_14_cursor);
              map_map_kernels::compose(&(v696_5),&(v697_7))
            };
            drop(v696_5);
            let v696_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v696_2));
            drop(v696_2);
            let v696_10: Space = if map_kernels::has_head(&(v696_9)) { singleton(&[]) } else { Space::new() };
            drop(v696_9);
            let v696_12: Space = if (&(v696_10)).is_empty() { Space::new() } else {
              let v698_6: Path = concat_path(&(v695_6),&v687_14_cursor.path()[(v687_14_origin + 2)..(v687_14_origin + 3)]);
              let v698_11: Space = routine_15(c, &(v698_6), &v687_14_cursor);
              drop(v698_6);
              map_map_kernels::compose(&(v696_10),&(v698_11))
            };
            drop(v696_10);
            let v696_13: Space = map_map_kernels::unite(&(v696_8),&(v696_12));
            join_wrapped_into(&mut v695_11_write,&((v696_13).read_zipper()),&[]);
            }
            v687_14_cursor.ascend(1);
          }
          drop(v695_11_write);
          drop(v695_6);
          map_map_kernels::compose(&(v690_10),&(v695_11))
        };
        drop(v690_10);
        let v690_13: Space = map_map_kernels::unite(&(v690_8),&(v690_12));
        join_wrapped_into(&mut v689_7_write,&((v690_13).read_zipper()),&[]);
        }
        v687_14_cursor.ascend(1);
      }
      drop(v689_7_write);
      drop(v689_6);
      map_map_kernels::compose(&(v688_5),&(v689_7))
    };
    drop(v688_5);
    let v688_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v688_2));
    drop(v688_2);
    let v688_10: Space = if map_kernels::has_head(&(v688_9)) { singleton(&[]) } else { Space::new() };
    drop(v688_9);
    let v688_11: Space = map_view_kernels::compose(&(v688_10),&v687_14_cursor);
    drop(v688_10);
    let v688_12: Space = map_map_kernels::unite(&(v688_8),&(v688_11));
    drop(v688_11);
    join_wrapped_into(&mut v687_14_write,&((v688_12).read_zipper()),&[]);
    }
    v687_14_cursor.ascend(1);
  }
  drop(v687_14_cursor);
  drop(v687_14_write);
  (v687_14).clone()
}

fn routine_40(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v699_20 = Space::new();
  let mut v699_20_write = v699_20.write_zipper();
  let mut v699_20_cursor = (*s0).read_zipper();
  let v699_20_origin = v699_20_cursor.path().len();
  for v699_20_byte in v699_20_cursor.child_mask().iter() {
    v699_20_cursor.descend_to_existing_byte(v699_20_byte);
    {
    let v700_2: Space = singleton(&v699_20_cursor.path()[v699_20_origin..(v699_20_origin + 1)]);
    let v700_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v700_2));
    let v700_4: Space = if map_kernels::has_head(&(v700_3)) { singleton(&[]) } else { Space::new() };
    drop(v700_3);
    let v700_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v700_4));
    drop(v700_4);
    let v700_8: Space = if (&(v700_5)).is_empty() { Space::new() } else {
      let v701_6: Path = concat_path(&(*p0),&v699_20_cursor.path()[v699_20_origin..(v699_20_origin + 1)]);
      let mut v701_7 = Space::new();
      let mut v701_7_write = v701_7.write_zipper();
      for v701_7_byte in v699_20_cursor.child_mask().iter() {
        v699_20_cursor.descend_to_existing_byte(v701_7_byte);
        {
        let v702_2: Space = singleton(&v699_20_cursor.path()[(v699_20_origin + 1)..(v699_20_origin + 2)]);
        let v702_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v702_2));
        let v702_4: Space = if map_kernels::has_head(&(v702_3)) { singleton(&[]) } else { Space::new() };
        drop(v702_3);
        let v702_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v702_4));
        drop(v702_4);
        let v702_8: Space = if (&(v702_5)).is_empty() { Space::new() } else {
          let v703_6: Path = concat_path(&(v701_6),&v699_20_cursor.path()[(v699_20_origin + 1)..(v699_20_origin + 2)]);
          let mut v703_7 = Space::new();
          let mut v703_7_write = v703_7.write_zipper();
          for v703_7_byte in v699_20_cursor.child_mask().iter() {
            v699_20_cursor.descend_to_existing_byte(v703_7_byte);
            {
            let v704_2: Space = singleton(&v699_20_cursor.path()[(v699_20_origin + 2)..(v699_20_origin + 3)]);
            let v704_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v704_2));
            let v704_4: Space = if map_kernels::has_head(&(v704_3)) { singleton(&[]) } else { Space::new() };
            drop(v704_3);
            let v704_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v704_4));
            drop(v704_4);
            let v704_8: Space = if (&(v704_5)).is_empty() { Space::new() } else {
              let v705_6: Path = concat_path(&(v703_6),&v699_20_cursor.path()[(v699_20_origin + 2)..(v699_20_origin + 3)]);
              let v705_7: Space = routine_54(c, &(v705_6), &v699_20_cursor);
              map_map_kernels::compose(&(v704_5),&(v705_7))
            };
            drop(v704_5);
            let v704_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v704_2));
            drop(v704_2);
            let v704_10: Space = if map_kernels::has_head(&(v704_9)) { singleton(&[]) } else { Space::new() };
            drop(v704_9);
            let v704_12: Space = if (&(v704_10)).is_empty() { Space::new() } else {
              let v706_6: Path = concat_path(&(v703_6),&v699_20_cursor.path()[(v699_20_origin + 2)..(v699_20_origin + 3)]);
              let v706_11: Space = routine_55(c, &(v706_6), &v699_20_cursor);
              drop(v706_6);
              map_map_kernels::compose(&(v704_10),&(v706_11))
            };
            drop(v704_10);
            let v704_13: Space = map_map_kernels::unite(&(v704_8),&(v704_12));
            join_wrapped_into(&mut v703_7_write,&((v704_13).read_zipper()),&[]);
            }
            v699_20_cursor.ascend(1);
          }
          drop(v703_7_write);
          map_map_kernels::compose(&(v702_5),&(v703_7))
        };
        drop(v702_5);
        let v702_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v702_2));
        drop(v702_2);
        let v702_10: Space = if map_kernels::has_head(&(v702_9)) { singleton(&[]) } else { Space::new() };
        drop(v702_9);
        let v702_12: Space = if (&(v702_10)).is_empty() { Space::new() } else {
          let v707_6: Path = concat_path(&(v701_6),&v699_20_cursor.path()[(v699_20_origin + 1)..(v699_20_origin + 2)]);
          let mut v707_11 = Space::new();
          let mut v707_11_write = v707_11.write_zipper();
          for v707_11_byte in v699_20_cursor.child_mask().iter() {
            v699_20_cursor.descend_to_existing_byte(v707_11_byte);
            {
            let v708_2: Space = singleton(&v699_20_cursor.path()[(v699_20_origin + 2)..(v699_20_origin + 3)]);
            let v708_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v708_2));
            let v708_4: Space = if map_kernels::has_head(&(v708_3)) { singleton(&[]) } else { Space::new() };
            drop(v708_3);
            let v708_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v708_4));
            drop(v708_4);
            let v708_8: Space = if (&(v708_5)).is_empty() { Space::new() } else {
              let v709_6: Path = concat_path(&(v707_6),&v699_20_cursor.path()[(v699_20_origin + 2)..(v699_20_origin + 3)]);
              let v709_7: Space = routine_54(c, &(v709_6), &v699_20_cursor);
              map_map_kernels::compose(&(v708_5),&(v709_7))
            };
            drop(v708_5);
            let v708_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v708_2));
            drop(v708_2);
            let v708_10: Space = if map_kernels::has_head(&(v708_9)) { singleton(&[]) } else { Space::new() };
            drop(v708_9);
            let v708_12: Space = if (&(v708_10)).is_empty() { Space::new() } else {
              let v710_6: Path = concat_path(&(v707_6),&v699_20_cursor.path()[(v699_20_origin + 2)..(v699_20_origin + 3)]);
              let v710_11: Space = routine_12(c, &(v710_6), &v699_20_cursor);
              drop(v710_6);
              map_map_kernels::compose(&(v708_10),&(v710_11))
            };
            drop(v708_10);
            let v708_13: Space = map_map_kernels::unite(&(v708_8),&(v708_12));
            join_wrapped_into(&mut v707_11_write,&((v708_13).read_zipper()),&[]);
            }
            v699_20_cursor.ascend(1);
          }
          drop(v707_11_write);
          drop(v707_6);
          map_map_kernels::compose(&(v702_10),&(v707_11))
        };
        drop(v702_10);
        let v702_13: Space = map_map_kernels::unite(&(v702_8),&(v702_12));
        join_wrapped_into(&mut v701_7_write,&((v702_13).read_zipper()),&[]);
        }
        v699_20_cursor.ascend(1);
      }
      drop(v701_7_write);
      map_map_kernels::compose(&(v700_5),&(v701_7))
    };
    drop(v700_5);
    let v700_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v700_2));
    drop(v700_2);
    let v700_10: Space = if map_kernels::has_head(&(v700_9)) { singleton(&[]) } else { Space::new() };
    drop(v700_9);
    let v700_12: Space = if (&(v700_10)).is_empty() { Space::new() } else {
      let v711_6: Path = concat_path(&(*p0),&v699_20_cursor.path()[v699_20_origin..(v699_20_origin + 1)]);
      let mut v711_11 = Space::new();
      let mut v711_11_write = v711_11.write_zipper();
      for v711_11_byte in v699_20_cursor.child_mask().iter() {
        v699_20_cursor.descend_to_existing_byte(v711_11_byte);
        {
        let v712_2: Space = singleton(&v699_20_cursor.path()[(v699_20_origin + 1)..(v699_20_origin + 2)]);
        let v712_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v712_2));
        let v712_4: Space = if map_kernels::has_head(&(v712_3)) { singleton(&[]) } else { Space::new() };
        drop(v712_3);
        let v712_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v712_4));
        drop(v712_4);
        let v712_8: Space = if (&(v712_5)).is_empty() { Space::new() } else {
          let v713_6: Path = concat_path(&(v711_6),&v699_20_cursor.path()[(v699_20_origin + 1)..(v699_20_origin + 2)]);
          let mut v713_7 = Space::new();
          let mut v713_7_write = v713_7.write_zipper();
          for v713_7_byte in v699_20_cursor.child_mask().iter() {
            v699_20_cursor.descend_to_existing_byte(v713_7_byte);
            {
            let v714_2: Space = singleton(&v699_20_cursor.path()[(v699_20_origin + 2)..(v699_20_origin + 3)]);
            let v714_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v714_2));
            let v714_4: Space = if map_kernels::has_head(&(v714_3)) { singleton(&[]) } else { Space::new() };
            drop(v714_3);
            let v714_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v714_4));
            drop(v714_4);
            let v714_8: Space = if (&(v714_5)).is_empty() { Space::new() } else {
              let v715_6: Path = concat_path(&(v713_6),&v699_20_cursor.path()[(v699_20_origin + 2)..(v699_20_origin + 3)]);
              let v715_7: Space = routine_54(c, &(v715_6), &v699_20_cursor);
              map_map_kernels::compose(&(v714_5),&(v715_7))
            };
            drop(v714_5);
            let v714_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v714_2));
            drop(v714_2);
            let v714_10: Space = if map_kernels::has_head(&(v714_9)) { singleton(&[]) } else { Space::new() };
            drop(v714_9);
            let v714_12: Space = if (&(v714_10)).is_empty() { Space::new() } else {
              let v716_6: Path = concat_path(&(v713_6),&v699_20_cursor.path()[(v699_20_origin + 2)..(v699_20_origin + 3)]);
              let v716_11: Space = routine_55(c, &(v716_6), &v699_20_cursor);
              drop(v716_6);
              map_map_kernels::compose(&(v714_10),&(v716_11))
            };
            drop(v714_10);
            let v714_13: Space = map_map_kernels::unite(&(v714_8),&(v714_12));
            join_wrapped_into(&mut v713_7_write,&((v714_13).read_zipper()),&[]);
            }
            v699_20_cursor.ascend(1);
          }
          drop(v713_7_write);
          drop(v713_6);
          map_map_kernels::compose(&(v712_5),&(v713_7))
        };
        drop(v712_5);
        let v712_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v712_2));
        drop(v712_2);
        let v712_10: Space = if map_kernels::has_head(&(v712_9)) { singleton(&[]) } else { Space::new() };
        drop(v712_9);
        let v712_11: Space = map_view_kernels::compose(&(v712_10),&v699_20_cursor);
        drop(v712_10);
        let v712_12: Space = map_map_kernels::unite(&(v712_8),&(v712_11));
        drop(v712_11);
        join_wrapped_into(&mut v711_11_write,&((v712_12).read_zipper()),&[]);
        }
        v699_20_cursor.ascend(1);
      }
      drop(v711_11_write);
      drop(v711_6);
      map_map_kernels::compose(&(v700_10),&(v711_11))
    };
    drop(v700_10);
    let v700_13: Space = map_map_kernels::unite(&(v700_8),&(v700_12));
    join_wrapped_into(&mut v699_20_write,&((v700_13).read_zipper()),&[]);
    }
    v699_20_cursor.ascend(1);
  }
  drop(v699_20_cursor);
  drop(v699_20_write);
  (v699_20).clone()
}

fn routine_41(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v717_14 = Space::new();
  let mut v717_14_write = v717_14.write_zipper();
  let mut v717_14_cursor = (*s0).read_zipper();
  let v717_14_origin = v717_14_cursor.path().len();
  for v717_14_byte in v717_14_cursor.child_mask().iter() {
    v717_14_cursor.descend_to_existing_byte(v717_14_byte);
    {
    let v718_2: Space = singleton(&v717_14_cursor.path()[v717_14_origin..(v717_14_origin + 1)]);
    let v718_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v718_2));
    let v718_4: Space = if map_kernels::has_head(&(v718_3)) { singleton(&[]) } else { Space::new() };
    drop(v718_3);
    let v718_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v718_4));
    drop(v718_4);
    let v718_8: Space = if (&(v718_5)).is_empty() { Space::new() } else {
      let v719_6: Path = concat_path(&(*p0),&v717_14_cursor.path()[v717_14_origin..(v717_14_origin + 1)]);
      let mut v719_7 = Space::new();
      let mut v719_7_write = v719_7.write_zipper();
      for v719_7_byte in v717_14_cursor.child_mask().iter() {
        v717_14_cursor.descend_to_existing_byte(v719_7_byte);
        {
        let v720_2: Space = singleton(&v717_14_cursor.path()[(v717_14_origin + 1)..(v717_14_origin + 2)]);
        let v720_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v720_2));
        let v720_4: Space = if map_kernels::has_head(&(v720_3)) { singleton(&[]) } else { Space::new() };
        drop(v720_3);
        let v720_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v720_4));
        drop(v720_4);
        let v720_8: Space = if (&(v720_5)).is_empty() { Space::new() } else {
          let v721_6: Path = concat_path(&(v719_6),&v717_14_cursor.path()[(v717_14_origin + 1)..(v717_14_origin + 2)]);
          let mut v721_7 = Space::new();
          let mut v721_7_write = v721_7.write_zipper();
          for v721_7_byte in v717_14_cursor.child_mask().iter() {
            v717_14_cursor.descend_to_existing_byte(v721_7_byte);
            {
            let v722_2: Space = singleton(&v717_14_cursor.path()[(v717_14_origin + 2)..(v717_14_origin + 3)]);
            let v722_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v722_2));
            let v722_4: Space = if map_kernels::has_head(&(v722_3)) { singleton(&[]) } else { Space::new() };
            drop(v722_3);
            let v722_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v722_4));
            drop(v722_4);
            let v722_8: Space = if (&(v722_5)).is_empty() { Space::new() } else {
              let v723_6: Path = concat_path(&(v721_6),&v717_14_cursor.path()[(v717_14_origin + 2)..(v717_14_origin + 3)]);
              let v723_7: Space = routine_54(c, &(v723_6), &v717_14_cursor);
              map_map_kernels::compose(&(v722_5),&(v723_7))
            };
            drop(v722_5);
            let v722_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v722_2));
            drop(v722_2);
            let v722_10: Space = if map_kernels::has_head(&(v722_9)) { singleton(&[]) } else { Space::new() };
            drop(v722_9);
            let v722_12: Space = if (&(v722_10)).is_empty() { Space::new() } else {
              let v724_6: Path = concat_path(&(v721_6),&v717_14_cursor.path()[(v717_14_origin + 2)..(v717_14_origin + 3)]);
              let v724_11: Space = routine_55(c, &(v724_6), &v717_14_cursor);
              drop(v724_6);
              map_map_kernels::compose(&(v722_10),&(v724_11))
            };
            drop(v722_10);
            let v722_13: Space = map_map_kernels::unite(&(v722_8),&(v722_12));
            join_wrapped_into(&mut v721_7_write,&((v722_13).read_zipper()),&[]);
            }
            v717_14_cursor.ascend(1);
          }
          drop(v721_7_write);
          map_map_kernels::compose(&(v720_5),&(v721_7))
        };
        drop(v720_5);
        let v720_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v720_2));
        drop(v720_2);
        let v720_10: Space = if map_kernels::has_head(&(v720_9)) { singleton(&[]) } else { Space::new() };
        drop(v720_9);
        let v720_12: Space = if (&(v720_10)).is_empty() { Space::new() } else {
          let v725_6: Path = concat_path(&(v719_6),&v717_14_cursor.path()[(v717_14_origin + 1)..(v717_14_origin + 2)]);
          let mut v725_11 = Space::new();
          let mut v725_11_write = v725_11.write_zipper();
          for v725_11_byte in v717_14_cursor.child_mask().iter() {
            v717_14_cursor.descend_to_existing_byte(v725_11_byte);
            {
            let v726_2: Space = singleton(&v717_14_cursor.path()[(v717_14_origin + 2)..(v717_14_origin + 3)]);
            let v726_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v726_2));
            let v726_4: Space = if map_kernels::has_head(&(v726_3)) { singleton(&[]) } else { Space::new() };
            drop(v726_3);
            let v726_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v726_4));
            drop(v726_4);
            let v726_8: Space = if (&(v726_5)).is_empty() { Space::new() } else {
              let v727_6: Path = concat_path(&(v725_6),&v717_14_cursor.path()[(v717_14_origin + 2)..(v717_14_origin + 3)]);
              let v727_7: Space = routine_54(c, &(v727_6), &v717_14_cursor);
              map_map_kernels::compose(&(v726_5),&(v727_7))
            };
            drop(v726_5);
            let v726_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v726_2));
            drop(v726_2);
            let v726_10: Space = if map_kernels::has_head(&(v726_9)) { singleton(&[]) } else { Space::new() };
            drop(v726_9);
            let v726_12: Space = if (&(v726_10)).is_empty() { Space::new() } else {
              let v728_6: Path = concat_path(&(v725_6),&v717_14_cursor.path()[(v717_14_origin + 2)..(v717_14_origin + 3)]);
              let v728_11: Space = routine_12(c, &(v728_6), &v717_14_cursor);
              drop(v728_6);
              map_map_kernels::compose(&(v726_10),&(v728_11))
            };
            drop(v726_10);
            let v726_13: Space = map_map_kernels::unite(&(v726_8),&(v726_12));
            join_wrapped_into(&mut v725_11_write,&((v726_13).read_zipper()),&[]);
            }
            v717_14_cursor.ascend(1);
          }
          drop(v725_11_write);
          drop(v725_6);
          map_map_kernels::compose(&(v720_10),&(v725_11))
        };
        drop(v720_10);
        let v720_13: Space = map_map_kernels::unite(&(v720_8),&(v720_12));
        join_wrapped_into(&mut v719_7_write,&((v720_13).read_zipper()),&[]);
        }
        v717_14_cursor.ascend(1);
      }
      drop(v719_7_write);
      drop(v719_6);
      map_map_kernels::compose(&(v718_5),&(v719_7))
    };
    drop(v718_5);
    let v718_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v718_2));
    drop(v718_2);
    let v718_10: Space = if map_kernels::has_head(&(v718_9)) { singleton(&[]) } else { Space::new() };
    drop(v718_9);
    let v718_11: Space = map_view_kernels::compose(&(v718_10),&v717_14_cursor);
    drop(v718_10);
    let v718_12: Space = map_map_kernels::unite(&(v718_8),&(v718_11));
    drop(v718_11);
    join_wrapped_into(&mut v717_14_write,&((v718_12).read_zipper()),&[]);
    }
    v717_14_cursor.ascend(1);
  }
  drop(v717_14_cursor);
  drop(v717_14_write);
  (v717_14).clone()
}

fn routine_42(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v729_20 = Space::new();
  let mut v729_20_write = v729_20.write_zipper();
  let mut v729_20_cursor = (*s0).read_zipper();
  let v729_20_origin = v729_20_cursor.path().len();
  for v729_20_byte in v729_20_cursor.child_mask().iter() {
    v729_20_cursor.descend_to_existing_byte(v729_20_byte);
    {
    let v730_2: Space = singleton(&v729_20_cursor.path()[v729_20_origin..(v729_20_origin + 1)]);
    let v730_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v730_2));
    let v730_4: Space = if map_kernels::has_head(&(v730_3)) { singleton(&[]) } else { Space::new() };
    drop(v730_3);
    let v730_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v730_4));
    drop(v730_4);
    let v730_8: Space = if (&(v730_5)).is_empty() { Space::new() } else {
      let v731_6: Path = concat_path(&(*p0),&v729_20_cursor.path()[v729_20_origin..(v729_20_origin + 1)]);
      let mut v731_7 = Space::new();
      let mut v731_7_write = v731_7.write_zipper();
      for v731_7_byte in v729_20_cursor.child_mask().iter() {
        v729_20_cursor.descend_to_existing_byte(v731_7_byte);
        {
        let v732_2: Space = singleton(&v729_20_cursor.path()[(v729_20_origin + 1)..(v729_20_origin + 2)]);
        let v732_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v732_2));
        let v732_4: Space = if map_kernels::has_head(&(v732_3)) { singleton(&[]) } else { Space::new() };
        drop(v732_3);
        let v732_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v732_4));
        drop(v732_4);
        let v732_8: Space = if (&(v732_5)).is_empty() { Space::new() } else {
          let v733_6: Path = concat_path(&(v731_6),&v729_20_cursor.path()[(v729_20_origin + 1)..(v729_20_origin + 2)]);
          let mut v733_7 = Space::new();
          let mut v733_7_write = v733_7.write_zipper();
          for v733_7_byte in v729_20_cursor.child_mask().iter() {
            v729_20_cursor.descend_to_existing_byte(v733_7_byte);
            {
            let v734_2: Space = singleton(&v729_20_cursor.path()[(v729_20_origin + 2)..(v729_20_origin + 3)]);
            let v734_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v734_2));
            let v734_4: Space = if map_kernels::has_head(&(v734_3)) { singleton(&[]) } else { Space::new() };
            drop(v734_3);
            let v734_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v734_4));
            drop(v734_4);
            let v734_8: Space = if (&(v734_5)).is_empty() { Space::new() } else {
              let v735_6: Path = concat_path(&(v733_6),&v729_20_cursor.path()[(v729_20_origin + 2)..(v729_20_origin + 3)]);
              let v735_7: Space = routine_56(c, &(v735_6), &v729_20_cursor);
              map_map_kernels::compose(&(v734_5),&(v735_7))
            };
            drop(v734_5);
            let v734_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v734_2));
            drop(v734_2);
            let v734_10: Space = if map_kernels::has_head(&(v734_9)) { singleton(&[]) } else { Space::new() };
            drop(v734_9);
            let v734_12: Space = if (&(v734_10)).is_empty() { Space::new() } else {
              let v736_6: Path = concat_path(&(v733_6),&v729_20_cursor.path()[(v729_20_origin + 2)..(v729_20_origin + 3)]);
              let v736_11: Space = routine_57(c, &(v736_6), &v729_20_cursor);
              drop(v736_6);
              map_map_kernels::compose(&(v734_10),&(v736_11))
            };
            drop(v734_10);
            let v734_13: Space = map_map_kernels::unite(&(v734_8),&(v734_12));
            join_wrapped_into(&mut v733_7_write,&((v734_13).read_zipper()),&[]);
            }
            v729_20_cursor.ascend(1);
          }
          drop(v733_7_write);
          map_map_kernels::compose(&(v732_5),&(v733_7))
        };
        drop(v732_5);
        let v732_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v732_2));
        drop(v732_2);
        let v732_10: Space = if map_kernels::has_head(&(v732_9)) { singleton(&[]) } else { Space::new() };
        drop(v732_9);
        let v732_12: Space = if (&(v732_10)).is_empty() { Space::new() } else {
          let v737_6: Path = concat_path(&(v731_6),&v729_20_cursor.path()[(v729_20_origin + 1)..(v729_20_origin + 2)]);
          let mut v737_11 = Space::new();
          let mut v737_11_write = v737_11.write_zipper();
          for v737_11_byte in v729_20_cursor.child_mask().iter() {
            v729_20_cursor.descend_to_existing_byte(v737_11_byte);
            {
            let v738_2: Space = singleton(&v729_20_cursor.path()[(v729_20_origin + 2)..(v729_20_origin + 3)]);
            let v738_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v738_2));
            let v738_4: Space = if map_kernels::has_head(&(v738_3)) { singleton(&[]) } else { Space::new() };
            drop(v738_3);
            let v738_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v738_4));
            drop(v738_4);
            let v738_8: Space = if (&(v738_5)).is_empty() { Space::new() } else {
              let v739_6: Path = concat_path(&(v737_6),&v729_20_cursor.path()[(v729_20_origin + 2)..(v729_20_origin + 3)]);
              let v739_7: Space = routine_56(c, &(v739_6), &v729_20_cursor);
              map_map_kernels::compose(&(v738_5),&(v739_7))
            };
            drop(v738_5);
            let v738_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v738_2));
            drop(v738_2);
            let v738_10: Space = if map_kernels::has_head(&(v738_9)) { singleton(&[]) } else { Space::new() };
            drop(v738_9);
            let v738_12: Space = if (&(v738_10)).is_empty() { Space::new() } else {
              let v740_6: Path = concat_path(&(v737_6),&v729_20_cursor.path()[(v729_20_origin + 2)..(v729_20_origin + 3)]);
              let v740_11: Space = routine_15(c, &(v740_6), &v729_20_cursor);
              drop(v740_6);
              map_map_kernels::compose(&(v738_10),&(v740_11))
            };
            drop(v738_10);
            let v738_13: Space = map_map_kernels::unite(&(v738_8),&(v738_12));
            join_wrapped_into(&mut v737_11_write,&((v738_13).read_zipper()),&[]);
            }
            v729_20_cursor.ascend(1);
          }
          drop(v737_11_write);
          drop(v737_6);
          map_map_kernels::compose(&(v732_10),&(v737_11))
        };
        drop(v732_10);
        let v732_13: Space = map_map_kernels::unite(&(v732_8),&(v732_12));
        join_wrapped_into(&mut v731_7_write,&((v732_13).read_zipper()),&[]);
        }
        v729_20_cursor.ascend(1);
      }
      drop(v731_7_write);
      map_map_kernels::compose(&(v730_5),&(v731_7))
    };
    drop(v730_5);
    let v730_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v730_2));
    drop(v730_2);
    let v730_10: Space = if map_kernels::has_head(&(v730_9)) { singleton(&[]) } else { Space::new() };
    drop(v730_9);
    let v730_12: Space = if (&(v730_10)).is_empty() { Space::new() } else {
      let v741_6: Path = concat_path(&(*p0),&v729_20_cursor.path()[v729_20_origin..(v729_20_origin + 1)]);
      let mut v741_11 = Space::new();
      let mut v741_11_write = v741_11.write_zipper();
      for v741_11_byte in v729_20_cursor.child_mask().iter() {
        v729_20_cursor.descend_to_existing_byte(v741_11_byte);
        {
        let v742_2: Space = singleton(&v729_20_cursor.path()[(v729_20_origin + 1)..(v729_20_origin + 2)]);
        let v742_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v742_2));
        let v742_4: Space = if map_kernels::has_head(&(v742_3)) { singleton(&[]) } else { Space::new() };
        drop(v742_3);
        let v742_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v742_4));
        drop(v742_4);
        let v742_8: Space = if (&(v742_5)).is_empty() { Space::new() } else {
          let v743_6: Path = concat_path(&(v741_6),&v729_20_cursor.path()[(v729_20_origin + 1)..(v729_20_origin + 2)]);
          let mut v743_7 = Space::new();
          let mut v743_7_write = v743_7.write_zipper();
          for v743_7_byte in v729_20_cursor.child_mask().iter() {
            v729_20_cursor.descend_to_existing_byte(v743_7_byte);
            {
            let v744_2: Space = singleton(&v729_20_cursor.path()[(v729_20_origin + 2)..(v729_20_origin + 3)]);
            let v744_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v744_2));
            let v744_4: Space = if map_kernels::has_head(&(v744_3)) { singleton(&[]) } else { Space::new() };
            drop(v744_3);
            let v744_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v744_4));
            drop(v744_4);
            let v744_8: Space = if (&(v744_5)).is_empty() { Space::new() } else {
              let v745_6: Path = concat_path(&(v743_6),&v729_20_cursor.path()[(v729_20_origin + 2)..(v729_20_origin + 3)]);
              let v745_7: Space = routine_56(c, &(v745_6), &v729_20_cursor);
              map_map_kernels::compose(&(v744_5),&(v745_7))
            };
            drop(v744_5);
            let v744_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v744_2));
            drop(v744_2);
            let v744_10: Space = if map_kernels::has_head(&(v744_9)) { singleton(&[]) } else { Space::new() };
            drop(v744_9);
            let v744_12: Space = if (&(v744_10)).is_empty() { Space::new() } else {
              let v746_6: Path = concat_path(&(v743_6),&v729_20_cursor.path()[(v729_20_origin + 2)..(v729_20_origin + 3)]);
              let v746_11: Space = routine_57(c, &(v746_6), &v729_20_cursor);
              drop(v746_6);
              map_map_kernels::compose(&(v744_10),&(v746_11))
            };
            drop(v744_10);
            let v744_13: Space = map_map_kernels::unite(&(v744_8),&(v744_12));
            join_wrapped_into(&mut v743_7_write,&((v744_13).read_zipper()),&[]);
            }
            v729_20_cursor.ascend(1);
          }
          drop(v743_7_write);
          drop(v743_6);
          map_map_kernels::compose(&(v742_5),&(v743_7))
        };
        drop(v742_5);
        let v742_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v742_2));
        drop(v742_2);
        let v742_10: Space = if map_kernels::has_head(&(v742_9)) { singleton(&[]) } else { Space::new() };
        drop(v742_9);
        let v742_11: Space = map_view_kernels::compose(&(v742_10),&v729_20_cursor);
        drop(v742_10);
        let v742_12: Space = map_map_kernels::unite(&(v742_8),&(v742_11));
        drop(v742_11);
        join_wrapped_into(&mut v741_11_write,&((v742_12).read_zipper()),&[]);
        }
        v729_20_cursor.ascend(1);
      }
      drop(v741_11_write);
      drop(v741_6);
      map_map_kernels::compose(&(v730_10),&(v741_11))
    };
    drop(v730_10);
    let v730_13: Space = map_map_kernels::unite(&(v730_8),&(v730_12));
    join_wrapped_into(&mut v729_20_write,&((v730_13).read_zipper()),&[]);
    }
    v729_20_cursor.ascend(1);
  }
  drop(v729_20_cursor);
  drop(v729_20_write);
  (v729_20).clone()
}

fn routine_43(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v747_14 = Space::new();
  let mut v747_14_write = v747_14.write_zipper();
  let mut v747_14_cursor = (*s0).read_zipper();
  let v747_14_origin = v747_14_cursor.path().len();
  for v747_14_byte in v747_14_cursor.child_mask().iter() {
    v747_14_cursor.descend_to_existing_byte(v747_14_byte);
    {
    let v748_2: Space = singleton(&v747_14_cursor.path()[v747_14_origin..(v747_14_origin + 1)]);
    let v748_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v748_2));
    let v748_4: Space = if map_kernels::has_head(&(v748_3)) { singleton(&[]) } else { Space::new() };
    drop(v748_3);
    let v748_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v748_4));
    drop(v748_4);
    let v748_8: Space = if (&(v748_5)).is_empty() { Space::new() } else {
      let v749_6: Path = concat_path(&(*p0),&v747_14_cursor.path()[v747_14_origin..(v747_14_origin + 1)]);
      let mut v749_7 = Space::new();
      let mut v749_7_write = v749_7.write_zipper();
      for v749_7_byte in v747_14_cursor.child_mask().iter() {
        v747_14_cursor.descend_to_existing_byte(v749_7_byte);
        {
        let v750_2: Space = singleton(&v747_14_cursor.path()[(v747_14_origin + 1)..(v747_14_origin + 2)]);
        let v750_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v750_2));
        let v750_4: Space = if map_kernels::has_head(&(v750_3)) { singleton(&[]) } else { Space::new() };
        drop(v750_3);
        let v750_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v750_4));
        drop(v750_4);
        let v750_8: Space = if (&(v750_5)).is_empty() { Space::new() } else {
          let v751_6: Path = concat_path(&(v749_6),&v747_14_cursor.path()[(v747_14_origin + 1)..(v747_14_origin + 2)]);
          let mut v751_7 = Space::new();
          let mut v751_7_write = v751_7.write_zipper();
          for v751_7_byte in v747_14_cursor.child_mask().iter() {
            v747_14_cursor.descend_to_existing_byte(v751_7_byte);
            {
            let v752_2: Space = singleton(&v747_14_cursor.path()[(v747_14_origin + 2)..(v747_14_origin + 3)]);
            let v752_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v752_2));
            let v752_4: Space = if map_kernels::has_head(&(v752_3)) { singleton(&[]) } else { Space::new() };
            drop(v752_3);
            let v752_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v752_4));
            drop(v752_4);
            let v752_8: Space = if (&(v752_5)).is_empty() { Space::new() } else {
              let v753_6: Path = concat_path(&(v751_6),&v747_14_cursor.path()[(v747_14_origin + 2)..(v747_14_origin + 3)]);
              let v753_7: Space = routine_56(c, &(v753_6), &v747_14_cursor);
              map_map_kernels::compose(&(v752_5),&(v753_7))
            };
            drop(v752_5);
            let v752_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v752_2));
            drop(v752_2);
            let v752_10: Space = if map_kernels::has_head(&(v752_9)) { singleton(&[]) } else { Space::new() };
            drop(v752_9);
            let v752_12: Space = if (&(v752_10)).is_empty() { Space::new() } else {
              let v754_6: Path = concat_path(&(v751_6),&v747_14_cursor.path()[(v747_14_origin + 2)..(v747_14_origin + 3)]);
              let v754_11: Space = routine_57(c, &(v754_6), &v747_14_cursor);
              drop(v754_6);
              map_map_kernels::compose(&(v752_10),&(v754_11))
            };
            drop(v752_10);
            let v752_13: Space = map_map_kernels::unite(&(v752_8),&(v752_12));
            join_wrapped_into(&mut v751_7_write,&((v752_13).read_zipper()),&[]);
            }
            v747_14_cursor.ascend(1);
          }
          drop(v751_7_write);
          map_map_kernels::compose(&(v750_5),&(v751_7))
        };
        drop(v750_5);
        let v750_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v750_2));
        drop(v750_2);
        let v750_10: Space = if map_kernels::has_head(&(v750_9)) { singleton(&[]) } else { Space::new() };
        drop(v750_9);
        let v750_12: Space = if (&(v750_10)).is_empty() { Space::new() } else {
          let v755_6: Path = concat_path(&(v749_6),&v747_14_cursor.path()[(v747_14_origin + 1)..(v747_14_origin + 2)]);
          let mut v755_11 = Space::new();
          let mut v755_11_write = v755_11.write_zipper();
          for v755_11_byte in v747_14_cursor.child_mask().iter() {
            v747_14_cursor.descend_to_existing_byte(v755_11_byte);
            {
            let v756_2: Space = singleton(&v747_14_cursor.path()[(v747_14_origin + 2)..(v747_14_origin + 3)]);
            let v756_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v756_2));
            let v756_4: Space = if map_kernels::has_head(&(v756_3)) { singleton(&[]) } else { Space::new() };
            drop(v756_3);
            let v756_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v756_4));
            drop(v756_4);
            let v756_8: Space = if (&(v756_5)).is_empty() { Space::new() } else {
              let v757_6: Path = concat_path(&(v755_6),&v747_14_cursor.path()[(v747_14_origin + 2)..(v747_14_origin + 3)]);
              let v757_7: Space = routine_56(c, &(v757_6), &v747_14_cursor);
              map_map_kernels::compose(&(v756_5),&(v757_7))
            };
            drop(v756_5);
            let v756_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v756_2));
            drop(v756_2);
            let v756_10: Space = if map_kernels::has_head(&(v756_9)) { singleton(&[]) } else { Space::new() };
            drop(v756_9);
            let v756_12: Space = if (&(v756_10)).is_empty() { Space::new() } else {
              let v758_6: Path = concat_path(&(v755_6),&v747_14_cursor.path()[(v747_14_origin + 2)..(v747_14_origin + 3)]);
              let v758_11: Space = routine_15(c, &(v758_6), &v747_14_cursor);
              drop(v758_6);
              map_map_kernels::compose(&(v756_10),&(v758_11))
            };
            drop(v756_10);
            let v756_13: Space = map_map_kernels::unite(&(v756_8),&(v756_12));
            join_wrapped_into(&mut v755_11_write,&((v756_13).read_zipper()),&[]);
            }
            v747_14_cursor.ascend(1);
          }
          drop(v755_11_write);
          drop(v755_6);
          map_map_kernels::compose(&(v750_10),&(v755_11))
        };
        drop(v750_10);
        let v750_13: Space = map_map_kernels::unite(&(v750_8),&(v750_12));
        join_wrapped_into(&mut v749_7_write,&((v750_13).read_zipper()),&[]);
        }
        v747_14_cursor.ascend(1);
      }
      drop(v749_7_write);
      drop(v749_6);
      map_map_kernels::compose(&(v748_5),&(v749_7))
    };
    drop(v748_5);
    let v748_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v748_2));
    drop(v748_2);
    let v748_10: Space = if map_kernels::has_head(&(v748_9)) { singleton(&[]) } else { Space::new() };
    drop(v748_9);
    let v748_11: Space = map_view_kernels::compose(&(v748_10),&v747_14_cursor);
    drop(v748_10);
    let v748_12: Space = map_map_kernels::unite(&(v748_8),&(v748_11));
    drop(v748_11);
    join_wrapped_into(&mut v747_14_write,&((v748_12).read_zipper()),&[]);
    }
    v747_14_cursor.ascend(1);
  }
  drop(v747_14_cursor);
  drop(v747_14_write);
  (v747_14).clone()
}

fn routine_44(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v759_20 = Space::new();
  let mut v759_20_write = v759_20.write_zipper();
  let mut v759_20_cursor = (*s0).read_zipper();
  let v759_20_origin = v759_20_cursor.path().len();
  for v759_20_byte in v759_20_cursor.child_mask().iter() {
    v759_20_cursor.descend_to_existing_byte(v759_20_byte);
    {
    let v760_2: Space = singleton(&v759_20_cursor.path()[v759_20_origin..(v759_20_origin + 1)]);
    let v760_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v760_2));
    let v760_4: Space = if map_kernels::has_head(&(v760_3)) { singleton(&[]) } else { Space::new() };
    drop(v760_3);
    let v760_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v760_4));
    drop(v760_4);
    let v760_8: Space = if (&(v760_5)).is_empty() { Space::new() } else {
      let v761_6: Path = concat_path(&(*p0),&v759_20_cursor.path()[v759_20_origin..(v759_20_origin + 1)]);
      let mut v761_7 = Space::new();
      let mut v761_7_write = v761_7.write_zipper();
      for v761_7_byte in v759_20_cursor.child_mask().iter() {
        v759_20_cursor.descend_to_existing_byte(v761_7_byte);
        {
        let v762_2: Space = singleton(&v759_20_cursor.path()[(v759_20_origin + 1)..(v759_20_origin + 2)]);
        let v762_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v762_2));
        let v762_4: Space = if map_kernels::has_head(&(v762_3)) { singleton(&[]) } else { Space::new() };
        drop(v762_3);
        let v762_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v762_4));
        drop(v762_4);
        let v762_8: Space = if (&(v762_5)).is_empty() { Space::new() } else {
          let v763_6: Path = concat_path(&(v761_6),&v759_20_cursor.path()[(v759_20_origin + 1)..(v759_20_origin + 2)]);
          let mut v763_7 = Space::new();
          let mut v763_7_write = v763_7.write_zipper();
          for v763_7_byte in v759_20_cursor.child_mask().iter() {
            v759_20_cursor.descend_to_existing_byte(v763_7_byte);
            {
            let v764_2: Space = singleton(&v759_20_cursor.path()[(v759_20_origin + 2)..(v759_20_origin + 3)]);
            let v764_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v764_2));
            let v764_4: Space = if map_kernels::has_head(&(v764_3)) { singleton(&[]) } else { Space::new() };
            drop(v764_3);
            let v764_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v764_4));
            drop(v764_4);
            let v764_8: Space = if (&(v764_5)).is_empty() { Space::new() } else {
              let v765_6: Path = concat_path(&(v763_6),&v759_20_cursor.path()[(v759_20_origin + 2)..(v759_20_origin + 3)]);
              let v765_7: Space = routine_58(c, &(v765_6), &v759_20_cursor);
              map_map_kernels::compose(&(v764_5),&(v765_7))
            };
            drop(v764_5);
            let v764_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v764_2));
            drop(v764_2);
            let v764_10: Space = if map_kernels::has_head(&(v764_9)) { singleton(&[]) } else { Space::new() };
            drop(v764_9);
            let v764_12: Space = if (&(v764_10)).is_empty() { Space::new() } else {
              let v766_6: Path = concat_path(&(v763_6),&v759_20_cursor.path()[(v759_20_origin + 2)..(v759_20_origin + 3)]);
              let v766_11: Space = routine_59(c, &(v766_6), &v759_20_cursor);
              drop(v766_6);
              map_map_kernels::compose(&(v764_10),&(v766_11))
            };
            drop(v764_10);
            let v764_13: Space = map_map_kernels::unite(&(v764_8),&(v764_12));
            join_wrapped_into(&mut v763_7_write,&((v764_13).read_zipper()),&[]);
            }
            v759_20_cursor.ascend(1);
          }
          drop(v763_7_write);
          map_map_kernels::compose(&(v762_5),&(v763_7))
        };
        drop(v762_5);
        let v762_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v762_2));
        drop(v762_2);
        let v762_10: Space = if map_kernels::has_head(&(v762_9)) { singleton(&[]) } else { Space::new() };
        drop(v762_9);
        let v762_12: Space = if (&(v762_10)).is_empty() { Space::new() } else {
          let v767_6: Path = concat_path(&(v761_6),&v759_20_cursor.path()[(v759_20_origin + 1)..(v759_20_origin + 2)]);
          let mut v767_11 = Space::new();
          let mut v767_11_write = v767_11.write_zipper();
          for v767_11_byte in v759_20_cursor.child_mask().iter() {
            v759_20_cursor.descend_to_existing_byte(v767_11_byte);
            {
            let v768_2: Space = singleton(&v759_20_cursor.path()[(v759_20_origin + 2)..(v759_20_origin + 3)]);
            let v768_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v768_2));
            let v768_4: Space = if map_kernels::has_head(&(v768_3)) { singleton(&[]) } else { Space::new() };
            drop(v768_3);
            let v768_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v768_4));
            drop(v768_4);
            let v768_8: Space = if (&(v768_5)).is_empty() { Space::new() } else {
              let v769_6: Path = concat_path(&(v767_6),&v759_20_cursor.path()[(v759_20_origin + 2)..(v759_20_origin + 3)]);
              let v769_7: Space = routine_58(c, &(v769_6), &v759_20_cursor);
              map_map_kernels::compose(&(v768_5),&(v769_7))
            };
            drop(v768_5);
            let v768_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v768_2));
            drop(v768_2);
            let v768_10: Space = if map_kernels::has_head(&(v768_9)) { singleton(&[]) } else { Space::new() };
            drop(v768_9);
            let v768_12: Space = if (&(v768_10)).is_empty() { Space::new() } else {
              let v770_6: Path = concat_path(&(v767_6),&v759_20_cursor.path()[(v759_20_origin + 2)..(v759_20_origin + 3)]);
              let v770_11: Space = routine_12(c, &(v770_6), &v759_20_cursor);
              drop(v770_6);
              map_map_kernels::compose(&(v768_10),&(v770_11))
            };
            drop(v768_10);
            let v768_13: Space = map_map_kernels::unite(&(v768_8),&(v768_12));
            join_wrapped_into(&mut v767_11_write,&((v768_13).read_zipper()),&[]);
            }
            v759_20_cursor.ascend(1);
          }
          drop(v767_11_write);
          drop(v767_6);
          map_map_kernels::compose(&(v762_10),&(v767_11))
        };
        drop(v762_10);
        let v762_13: Space = map_map_kernels::unite(&(v762_8),&(v762_12));
        join_wrapped_into(&mut v761_7_write,&((v762_13).read_zipper()),&[]);
        }
        v759_20_cursor.ascend(1);
      }
      drop(v761_7_write);
      map_map_kernels::compose(&(v760_5),&(v761_7))
    };
    drop(v760_5);
    let v760_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v760_2));
    drop(v760_2);
    let v760_10: Space = if map_kernels::has_head(&(v760_9)) { singleton(&[]) } else { Space::new() };
    drop(v760_9);
    let v760_12: Space = if (&(v760_10)).is_empty() { Space::new() } else {
      let v771_6: Path = concat_path(&(*p0),&v759_20_cursor.path()[v759_20_origin..(v759_20_origin + 1)]);
      let mut v771_11 = Space::new();
      let mut v771_11_write = v771_11.write_zipper();
      for v771_11_byte in v759_20_cursor.child_mask().iter() {
        v759_20_cursor.descend_to_existing_byte(v771_11_byte);
        {
        let v772_2: Space = singleton(&v759_20_cursor.path()[(v759_20_origin + 1)..(v759_20_origin + 2)]);
        let v772_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v772_2));
        let v772_4: Space = if map_kernels::has_head(&(v772_3)) { singleton(&[]) } else { Space::new() };
        drop(v772_3);
        let v772_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v772_4));
        drop(v772_4);
        let v772_8: Space = if (&(v772_5)).is_empty() { Space::new() } else {
          let v773_6: Path = concat_path(&(v771_6),&v759_20_cursor.path()[(v759_20_origin + 1)..(v759_20_origin + 2)]);
          let mut v773_7 = Space::new();
          let mut v773_7_write = v773_7.write_zipper();
          for v773_7_byte in v759_20_cursor.child_mask().iter() {
            v759_20_cursor.descend_to_existing_byte(v773_7_byte);
            {
            let v774_2: Space = singleton(&v759_20_cursor.path()[(v759_20_origin + 2)..(v759_20_origin + 3)]);
            let v774_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v774_2));
            let v774_4: Space = if map_kernels::has_head(&(v774_3)) { singleton(&[]) } else { Space::new() };
            drop(v774_3);
            let v774_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v774_4));
            drop(v774_4);
            let v774_8: Space = if (&(v774_5)).is_empty() { Space::new() } else {
              let v775_6: Path = concat_path(&(v773_6),&v759_20_cursor.path()[(v759_20_origin + 2)..(v759_20_origin + 3)]);
              let v775_7: Space = routine_58(c, &(v775_6), &v759_20_cursor);
              map_map_kernels::compose(&(v774_5),&(v775_7))
            };
            drop(v774_5);
            let v774_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v774_2));
            drop(v774_2);
            let v774_10: Space = if map_kernels::has_head(&(v774_9)) { singleton(&[]) } else { Space::new() };
            drop(v774_9);
            let v774_12: Space = if (&(v774_10)).is_empty() { Space::new() } else {
              let v776_6: Path = concat_path(&(v773_6),&v759_20_cursor.path()[(v759_20_origin + 2)..(v759_20_origin + 3)]);
              let v776_11: Space = routine_59(c, &(v776_6), &v759_20_cursor);
              drop(v776_6);
              map_map_kernels::compose(&(v774_10),&(v776_11))
            };
            drop(v774_10);
            let v774_13: Space = map_map_kernels::unite(&(v774_8),&(v774_12));
            join_wrapped_into(&mut v773_7_write,&((v774_13).read_zipper()),&[]);
            }
            v759_20_cursor.ascend(1);
          }
          drop(v773_7_write);
          drop(v773_6);
          map_map_kernels::compose(&(v772_5),&(v773_7))
        };
        drop(v772_5);
        let v772_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v772_2));
        drop(v772_2);
        let v772_10: Space = if map_kernels::has_head(&(v772_9)) { singleton(&[]) } else { Space::new() };
        drop(v772_9);
        let v772_11: Space = map_view_kernels::compose(&(v772_10),&v759_20_cursor);
        drop(v772_10);
        let v772_12: Space = map_map_kernels::unite(&(v772_8),&(v772_11));
        drop(v772_11);
        join_wrapped_into(&mut v771_11_write,&((v772_12).read_zipper()),&[]);
        }
        v759_20_cursor.ascend(1);
      }
      drop(v771_11_write);
      drop(v771_6);
      map_map_kernels::compose(&(v760_10),&(v771_11))
    };
    drop(v760_10);
    let v760_13: Space = map_map_kernels::unite(&(v760_8),&(v760_12));
    join_wrapped_into(&mut v759_20_write,&((v760_13).read_zipper()),&[]);
    }
    v759_20_cursor.ascend(1);
  }
  drop(v759_20_cursor);
  drop(v759_20_write);
  (v759_20).clone()
}

fn routine_45(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v777_14 = Space::new();
  let mut v777_14_write = v777_14.write_zipper();
  let mut v777_14_cursor = (*s0).read_zipper();
  let v777_14_origin = v777_14_cursor.path().len();
  for v777_14_byte in v777_14_cursor.child_mask().iter() {
    v777_14_cursor.descend_to_existing_byte(v777_14_byte);
    {
    let v778_2: Space = singleton(&v777_14_cursor.path()[v777_14_origin..(v777_14_origin + 1)]);
    let v778_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v778_2));
    let v778_4: Space = if map_kernels::has_head(&(v778_3)) { singleton(&[]) } else { Space::new() };
    drop(v778_3);
    let v778_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v778_4));
    drop(v778_4);
    let v778_8: Space = if (&(v778_5)).is_empty() { Space::new() } else {
      let v779_6: Path = concat_path(&(*p0),&v777_14_cursor.path()[v777_14_origin..(v777_14_origin + 1)]);
      let mut v779_7 = Space::new();
      let mut v779_7_write = v779_7.write_zipper();
      for v779_7_byte in v777_14_cursor.child_mask().iter() {
        v777_14_cursor.descend_to_existing_byte(v779_7_byte);
        {
        let v780_2: Space = singleton(&v777_14_cursor.path()[(v777_14_origin + 1)..(v777_14_origin + 2)]);
        let v780_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v780_2));
        let v780_4: Space = if map_kernels::has_head(&(v780_3)) { singleton(&[]) } else { Space::new() };
        drop(v780_3);
        let v780_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v780_4));
        drop(v780_4);
        let v780_8: Space = if (&(v780_5)).is_empty() { Space::new() } else {
          let v781_6: Path = concat_path(&(v779_6),&v777_14_cursor.path()[(v777_14_origin + 1)..(v777_14_origin + 2)]);
          let mut v781_7 = Space::new();
          let mut v781_7_write = v781_7.write_zipper();
          for v781_7_byte in v777_14_cursor.child_mask().iter() {
            v777_14_cursor.descend_to_existing_byte(v781_7_byte);
            {
            let v782_2: Space = singleton(&v777_14_cursor.path()[(v777_14_origin + 2)..(v777_14_origin + 3)]);
            let v782_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v782_2));
            let v782_4: Space = if map_kernels::has_head(&(v782_3)) { singleton(&[]) } else { Space::new() };
            drop(v782_3);
            let v782_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v782_4));
            drop(v782_4);
            let v782_8: Space = if (&(v782_5)).is_empty() { Space::new() } else {
              let v783_6: Path = concat_path(&(v781_6),&v777_14_cursor.path()[(v777_14_origin + 2)..(v777_14_origin + 3)]);
              let v783_7: Space = routine_58(c, &(v783_6), &v777_14_cursor);
              map_map_kernels::compose(&(v782_5),&(v783_7))
            };
            drop(v782_5);
            let v782_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v782_2));
            drop(v782_2);
            let v782_10: Space = if map_kernels::has_head(&(v782_9)) { singleton(&[]) } else { Space::new() };
            drop(v782_9);
            let v782_12: Space = if (&(v782_10)).is_empty() { Space::new() } else {
              let v784_6: Path = concat_path(&(v781_6),&v777_14_cursor.path()[(v777_14_origin + 2)..(v777_14_origin + 3)]);
              let v784_11: Space = routine_59(c, &(v784_6), &v777_14_cursor);
              drop(v784_6);
              map_map_kernels::compose(&(v782_10),&(v784_11))
            };
            drop(v782_10);
            let v782_13: Space = map_map_kernels::unite(&(v782_8),&(v782_12));
            join_wrapped_into(&mut v781_7_write,&((v782_13).read_zipper()),&[]);
            }
            v777_14_cursor.ascend(1);
          }
          drop(v781_7_write);
          map_map_kernels::compose(&(v780_5),&(v781_7))
        };
        drop(v780_5);
        let v780_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v780_2));
        drop(v780_2);
        let v780_10: Space = if map_kernels::has_head(&(v780_9)) { singleton(&[]) } else { Space::new() };
        drop(v780_9);
        let v780_12: Space = if (&(v780_10)).is_empty() { Space::new() } else {
          let v785_6: Path = concat_path(&(v779_6),&v777_14_cursor.path()[(v777_14_origin + 1)..(v777_14_origin + 2)]);
          let mut v785_11 = Space::new();
          let mut v785_11_write = v785_11.write_zipper();
          for v785_11_byte in v777_14_cursor.child_mask().iter() {
            v777_14_cursor.descend_to_existing_byte(v785_11_byte);
            {
            let v786_2: Space = singleton(&v777_14_cursor.path()[(v777_14_origin + 2)..(v777_14_origin + 3)]);
            let v786_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v786_2));
            let v786_4: Space = if map_kernels::has_head(&(v786_3)) { singleton(&[]) } else { Space::new() };
            drop(v786_3);
            let v786_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v786_4));
            drop(v786_4);
            let v786_8: Space = if (&(v786_5)).is_empty() { Space::new() } else {
              let v787_6: Path = concat_path(&(v785_6),&v777_14_cursor.path()[(v777_14_origin + 2)..(v777_14_origin + 3)]);
              let v787_7: Space = routine_58(c, &(v787_6), &v777_14_cursor);
              map_map_kernels::compose(&(v786_5),&(v787_7))
            };
            drop(v786_5);
            let v786_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v786_2));
            drop(v786_2);
            let v786_10: Space = if map_kernels::has_head(&(v786_9)) { singleton(&[]) } else { Space::new() };
            drop(v786_9);
            let v786_12: Space = if (&(v786_10)).is_empty() { Space::new() } else {
              let v788_6: Path = concat_path(&(v785_6),&v777_14_cursor.path()[(v777_14_origin + 2)..(v777_14_origin + 3)]);
              let v788_11: Space = routine_12(c, &(v788_6), &v777_14_cursor);
              drop(v788_6);
              map_map_kernels::compose(&(v786_10),&(v788_11))
            };
            drop(v786_10);
            let v786_13: Space = map_map_kernels::unite(&(v786_8),&(v786_12));
            join_wrapped_into(&mut v785_11_write,&((v786_13).read_zipper()),&[]);
            }
            v777_14_cursor.ascend(1);
          }
          drop(v785_11_write);
          drop(v785_6);
          map_map_kernels::compose(&(v780_10),&(v785_11))
        };
        drop(v780_10);
        let v780_13: Space = map_map_kernels::unite(&(v780_8),&(v780_12));
        join_wrapped_into(&mut v779_7_write,&((v780_13).read_zipper()),&[]);
        }
        v777_14_cursor.ascend(1);
      }
      drop(v779_7_write);
      drop(v779_6);
      map_map_kernels::compose(&(v778_5),&(v779_7))
    };
    drop(v778_5);
    let v778_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v778_2));
    drop(v778_2);
    let v778_10: Space = if map_kernels::has_head(&(v778_9)) { singleton(&[]) } else { Space::new() };
    drop(v778_9);
    let v778_11: Space = map_view_kernels::compose(&(v778_10),&v777_14_cursor);
    drop(v778_10);
    let v778_12: Space = map_map_kernels::unite(&(v778_8),&(v778_11));
    drop(v778_11);
    join_wrapped_into(&mut v777_14_write,&((v778_12).read_zipper()),&[]);
    }
    v777_14_cursor.ascend(1);
  }
  drop(v777_14_cursor);
  drop(v777_14_write);
  (v777_14).clone()
}

fn routine_46(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v789_20 = Space::new();
  let mut v789_20_write = v789_20.write_zipper();
  let mut v789_20_cursor = (*s0).read_zipper();
  let v789_20_origin = v789_20_cursor.path().len();
  for v789_20_byte in v789_20_cursor.child_mask().iter() {
    v789_20_cursor.descend_to_existing_byte(v789_20_byte);
    {
    let v790_2: Space = singleton(&v789_20_cursor.path()[v789_20_origin..(v789_20_origin + 1)]);
    let v790_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v790_2));
    let v790_4: Space = if map_kernels::has_head(&(v790_3)) { singleton(&[]) } else { Space::new() };
    drop(v790_3);
    let v790_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v790_4));
    drop(v790_4);
    let v790_8: Space = if (&(v790_5)).is_empty() { Space::new() } else {
      let v791_6: Path = concat_path(&(*p0),&v789_20_cursor.path()[v789_20_origin..(v789_20_origin + 1)]);
      let mut v791_7 = Space::new();
      let mut v791_7_write = v791_7.write_zipper();
      for v791_7_byte in v789_20_cursor.child_mask().iter() {
        v789_20_cursor.descend_to_existing_byte(v791_7_byte);
        {
        let v792_2: Space = singleton(&v789_20_cursor.path()[(v789_20_origin + 1)..(v789_20_origin + 2)]);
        let v792_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v792_2));
        let v792_4: Space = if map_kernels::has_head(&(v792_3)) { singleton(&[]) } else { Space::new() };
        drop(v792_3);
        let v792_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v792_4));
        drop(v792_4);
        let v792_8: Space = if (&(v792_5)).is_empty() { Space::new() } else {
          let v793_6: Path = concat_path(&(v791_6),&v789_20_cursor.path()[(v789_20_origin + 1)..(v789_20_origin + 2)]);
          let mut v793_7 = Space::new();
          let mut v793_7_write = v793_7.write_zipper();
          for v793_7_byte in v789_20_cursor.child_mask().iter() {
            v789_20_cursor.descend_to_existing_byte(v793_7_byte);
            {
            let v794_2: Space = singleton(&v789_20_cursor.path()[(v789_20_origin + 2)..(v789_20_origin + 3)]);
            let v794_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v794_2));
            let v794_4: Space = if map_kernels::has_head(&(v794_3)) { singleton(&[]) } else { Space::new() };
            drop(v794_3);
            let v794_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v794_4));
            drop(v794_4);
            let v794_8: Space = if (&(v794_5)).is_empty() { Space::new() } else {
              let v795_6: Path = concat_path(&(v793_6),&v789_20_cursor.path()[(v789_20_origin + 2)..(v789_20_origin + 3)]);
              let v795_7: Space = routine_60(c, &(v795_6), &v789_20_cursor);
              map_map_kernels::compose(&(v794_5),&(v795_7))
            };
            drop(v794_5);
            let v794_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v794_2));
            drop(v794_2);
            let v794_10: Space = if map_kernels::has_head(&(v794_9)) { singleton(&[]) } else { Space::new() };
            drop(v794_9);
            let v794_12: Space = if (&(v794_10)).is_empty() { Space::new() } else {
              let v796_6: Path = concat_path(&(v793_6),&v789_20_cursor.path()[(v789_20_origin + 2)..(v789_20_origin + 3)]);
              let v796_11: Space = routine_61(c, &(v796_6), &v789_20_cursor);
              drop(v796_6);
              map_map_kernels::compose(&(v794_10),&(v796_11))
            };
            drop(v794_10);
            let v794_13: Space = map_map_kernels::unite(&(v794_8),&(v794_12));
            join_wrapped_into(&mut v793_7_write,&((v794_13).read_zipper()),&[]);
            }
            v789_20_cursor.ascend(1);
          }
          drop(v793_7_write);
          map_map_kernels::compose(&(v792_5),&(v793_7))
        };
        drop(v792_5);
        let v792_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v792_2));
        drop(v792_2);
        let v792_10: Space = if map_kernels::has_head(&(v792_9)) { singleton(&[]) } else { Space::new() };
        drop(v792_9);
        let v792_12: Space = if (&(v792_10)).is_empty() { Space::new() } else {
          let v797_6: Path = concat_path(&(v791_6),&v789_20_cursor.path()[(v789_20_origin + 1)..(v789_20_origin + 2)]);
          let mut v797_11 = Space::new();
          let mut v797_11_write = v797_11.write_zipper();
          for v797_11_byte in v789_20_cursor.child_mask().iter() {
            v789_20_cursor.descend_to_existing_byte(v797_11_byte);
            {
            let v798_2: Space = singleton(&v789_20_cursor.path()[(v789_20_origin + 2)..(v789_20_origin + 3)]);
            let v798_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v798_2));
            let v798_4: Space = if map_kernels::has_head(&(v798_3)) { singleton(&[]) } else { Space::new() };
            drop(v798_3);
            let v798_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v798_4));
            drop(v798_4);
            let v798_8: Space = if (&(v798_5)).is_empty() { Space::new() } else {
              let v799_6: Path = concat_path(&(v797_6),&v789_20_cursor.path()[(v789_20_origin + 2)..(v789_20_origin + 3)]);
              let v799_7: Space = routine_60(c, &(v799_6), &v789_20_cursor);
              map_map_kernels::compose(&(v798_5),&(v799_7))
            };
            drop(v798_5);
            let v798_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v798_2));
            drop(v798_2);
            let v798_10: Space = if map_kernels::has_head(&(v798_9)) { singleton(&[]) } else { Space::new() };
            drop(v798_9);
            let v798_12: Space = if (&(v798_10)).is_empty() { Space::new() } else {
              let v800_6: Path = concat_path(&(v797_6),&v789_20_cursor.path()[(v789_20_origin + 2)..(v789_20_origin + 3)]);
              let v800_11: Space = routine_15(c, &(v800_6), &v789_20_cursor);
              drop(v800_6);
              map_map_kernels::compose(&(v798_10),&(v800_11))
            };
            drop(v798_10);
            let v798_13: Space = map_map_kernels::unite(&(v798_8),&(v798_12));
            join_wrapped_into(&mut v797_11_write,&((v798_13).read_zipper()),&[]);
            }
            v789_20_cursor.ascend(1);
          }
          drop(v797_11_write);
          drop(v797_6);
          map_map_kernels::compose(&(v792_10),&(v797_11))
        };
        drop(v792_10);
        let v792_13: Space = map_map_kernels::unite(&(v792_8),&(v792_12));
        join_wrapped_into(&mut v791_7_write,&((v792_13).read_zipper()),&[]);
        }
        v789_20_cursor.ascend(1);
      }
      drop(v791_7_write);
      map_map_kernels::compose(&(v790_5),&(v791_7))
    };
    drop(v790_5);
    let v790_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v790_2));
    drop(v790_2);
    let v790_10: Space = if map_kernels::has_head(&(v790_9)) { singleton(&[]) } else { Space::new() };
    drop(v790_9);
    let v790_12: Space = if (&(v790_10)).is_empty() { Space::new() } else {
      let v801_6: Path = concat_path(&(*p0),&v789_20_cursor.path()[v789_20_origin..(v789_20_origin + 1)]);
      let mut v801_11 = Space::new();
      let mut v801_11_write = v801_11.write_zipper();
      for v801_11_byte in v789_20_cursor.child_mask().iter() {
        v789_20_cursor.descend_to_existing_byte(v801_11_byte);
        {
        let v802_2: Space = singleton(&v789_20_cursor.path()[(v789_20_origin + 1)..(v789_20_origin + 2)]);
        let v802_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v802_2));
        let v802_4: Space = if map_kernels::has_head(&(v802_3)) { singleton(&[]) } else { Space::new() };
        drop(v802_3);
        let v802_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v802_4));
        drop(v802_4);
        let v802_8: Space = if (&(v802_5)).is_empty() { Space::new() } else {
          let v803_6: Path = concat_path(&(v801_6),&v789_20_cursor.path()[(v789_20_origin + 1)..(v789_20_origin + 2)]);
          let mut v803_7 = Space::new();
          let mut v803_7_write = v803_7.write_zipper();
          for v803_7_byte in v789_20_cursor.child_mask().iter() {
            v789_20_cursor.descend_to_existing_byte(v803_7_byte);
            {
            let v804_2: Space = singleton(&v789_20_cursor.path()[(v789_20_origin + 2)..(v789_20_origin + 3)]);
            let v804_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v804_2));
            let v804_4: Space = if map_kernels::has_head(&(v804_3)) { singleton(&[]) } else { Space::new() };
            drop(v804_3);
            let v804_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v804_4));
            drop(v804_4);
            let v804_8: Space = if (&(v804_5)).is_empty() { Space::new() } else {
              let v805_6: Path = concat_path(&(v803_6),&v789_20_cursor.path()[(v789_20_origin + 2)..(v789_20_origin + 3)]);
              let v805_7: Space = routine_60(c, &(v805_6), &v789_20_cursor);
              map_map_kernels::compose(&(v804_5),&(v805_7))
            };
            drop(v804_5);
            let v804_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v804_2));
            drop(v804_2);
            let v804_10: Space = if map_kernels::has_head(&(v804_9)) { singleton(&[]) } else { Space::new() };
            drop(v804_9);
            let v804_12: Space = if (&(v804_10)).is_empty() { Space::new() } else {
              let v806_6: Path = concat_path(&(v803_6),&v789_20_cursor.path()[(v789_20_origin + 2)..(v789_20_origin + 3)]);
              let v806_11: Space = routine_61(c, &(v806_6), &v789_20_cursor);
              drop(v806_6);
              map_map_kernels::compose(&(v804_10),&(v806_11))
            };
            drop(v804_10);
            let v804_13: Space = map_map_kernels::unite(&(v804_8),&(v804_12));
            join_wrapped_into(&mut v803_7_write,&((v804_13).read_zipper()),&[]);
            }
            v789_20_cursor.ascend(1);
          }
          drop(v803_7_write);
          drop(v803_6);
          map_map_kernels::compose(&(v802_5),&(v803_7))
        };
        drop(v802_5);
        let v802_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v802_2));
        drop(v802_2);
        let v802_10: Space = if map_kernels::has_head(&(v802_9)) { singleton(&[]) } else { Space::new() };
        drop(v802_9);
        let v802_11: Space = map_view_kernels::compose(&(v802_10),&v789_20_cursor);
        drop(v802_10);
        let v802_12: Space = map_map_kernels::unite(&(v802_8),&(v802_11));
        drop(v802_11);
        join_wrapped_into(&mut v801_11_write,&((v802_12).read_zipper()),&[]);
        }
        v789_20_cursor.ascend(1);
      }
      drop(v801_11_write);
      drop(v801_6);
      map_map_kernels::compose(&(v790_10),&(v801_11))
    };
    drop(v790_10);
    let v790_13: Space = map_map_kernels::unite(&(v790_8),&(v790_12));
    join_wrapped_into(&mut v789_20_write,&((v790_13).read_zipper()),&[]);
    }
    v789_20_cursor.ascend(1);
  }
  drop(v789_20_cursor);
  drop(v789_20_write);
  (v789_20).clone()
}

fn routine_47(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v807_14 = Space::new();
  let mut v807_14_write = v807_14.write_zipper();
  let mut v807_14_cursor = (*s0).read_zipper();
  let v807_14_origin = v807_14_cursor.path().len();
  for v807_14_byte in v807_14_cursor.child_mask().iter() {
    v807_14_cursor.descend_to_existing_byte(v807_14_byte);
    {
    let v808_2: Space = singleton(&v807_14_cursor.path()[v807_14_origin..(v807_14_origin + 1)]);
    let v808_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v808_2));
    let v808_4: Space = if map_kernels::has_head(&(v808_3)) { singleton(&[]) } else { Space::new() };
    drop(v808_3);
    let v808_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v808_4));
    drop(v808_4);
    let v808_8: Space = if (&(v808_5)).is_empty() { Space::new() } else {
      let v809_6: Path = concat_path(&(*p0),&v807_14_cursor.path()[v807_14_origin..(v807_14_origin + 1)]);
      let mut v809_7 = Space::new();
      let mut v809_7_write = v809_7.write_zipper();
      for v809_7_byte in v807_14_cursor.child_mask().iter() {
        v807_14_cursor.descend_to_existing_byte(v809_7_byte);
        {
        let v810_2: Space = singleton(&v807_14_cursor.path()[(v807_14_origin + 1)..(v807_14_origin + 2)]);
        let v810_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v810_2));
        let v810_4: Space = if map_kernels::has_head(&(v810_3)) { singleton(&[]) } else { Space::new() };
        drop(v810_3);
        let v810_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v810_4));
        drop(v810_4);
        let v810_8: Space = if (&(v810_5)).is_empty() { Space::new() } else {
          let v811_6: Path = concat_path(&(v809_6),&v807_14_cursor.path()[(v807_14_origin + 1)..(v807_14_origin + 2)]);
          let mut v811_7 = Space::new();
          let mut v811_7_write = v811_7.write_zipper();
          for v811_7_byte in v807_14_cursor.child_mask().iter() {
            v807_14_cursor.descend_to_existing_byte(v811_7_byte);
            {
            let v812_2: Space = singleton(&v807_14_cursor.path()[(v807_14_origin + 2)..(v807_14_origin + 3)]);
            let v812_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v812_2));
            let v812_4: Space = if map_kernels::has_head(&(v812_3)) { singleton(&[]) } else { Space::new() };
            drop(v812_3);
            let v812_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v812_4));
            drop(v812_4);
            let v812_8: Space = if (&(v812_5)).is_empty() { Space::new() } else {
              let v813_6: Path = concat_path(&(v811_6),&v807_14_cursor.path()[(v807_14_origin + 2)..(v807_14_origin + 3)]);
              let v813_7: Space = routine_60(c, &(v813_6), &v807_14_cursor);
              map_map_kernels::compose(&(v812_5),&(v813_7))
            };
            drop(v812_5);
            let v812_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v812_2));
            drop(v812_2);
            let v812_10: Space = if map_kernels::has_head(&(v812_9)) { singleton(&[]) } else { Space::new() };
            drop(v812_9);
            let v812_12: Space = if (&(v812_10)).is_empty() { Space::new() } else {
              let v814_6: Path = concat_path(&(v811_6),&v807_14_cursor.path()[(v807_14_origin + 2)..(v807_14_origin + 3)]);
              let v814_11: Space = routine_61(c, &(v814_6), &v807_14_cursor);
              drop(v814_6);
              map_map_kernels::compose(&(v812_10),&(v814_11))
            };
            drop(v812_10);
            let v812_13: Space = map_map_kernels::unite(&(v812_8),&(v812_12));
            join_wrapped_into(&mut v811_7_write,&((v812_13).read_zipper()),&[]);
            }
            v807_14_cursor.ascend(1);
          }
          drop(v811_7_write);
          map_map_kernels::compose(&(v810_5),&(v811_7))
        };
        drop(v810_5);
        let v810_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v810_2));
        drop(v810_2);
        let v810_10: Space = if map_kernels::has_head(&(v810_9)) { singleton(&[]) } else { Space::new() };
        drop(v810_9);
        let v810_12: Space = if (&(v810_10)).is_empty() { Space::new() } else {
          let v815_6: Path = concat_path(&(v809_6),&v807_14_cursor.path()[(v807_14_origin + 1)..(v807_14_origin + 2)]);
          let mut v815_11 = Space::new();
          let mut v815_11_write = v815_11.write_zipper();
          for v815_11_byte in v807_14_cursor.child_mask().iter() {
            v807_14_cursor.descend_to_existing_byte(v815_11_byte);
            {
            let v816_2: Space = singleton(&v807_14_cursor.path()[(v807_14_origin + 2)..(v807_14_origin + 3)]);
            let v816_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v816_2));
            let v816_4: Space = if map_kernels::has_head(&(v816_3)) { singleton(&[]) } else { Space::new() };
            drop(v816_3);
            let v816_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v816_4));
            drop(v816_4);
            let v816_8: Space = if (&(v816_5)).is_empty() { Space::new() } else {
              let v817_6: Path = concat_path(&(v815_6),&v807_14_cursor.path()[(v807_14_origin + 2)..(v807_14_origin + 3)]);
              let v817_7: Space = routine_60(c, &(v817_6), &v807_14_cursor);
              map_map_kernels::compose(&(v816_5),&(v817_7))
            };
            drop(v816_5);
            let v816_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v816_2));
            drop(v816_2);
            let v816_10: Space = if map_kernels::has_head(&(v816_9)) { singleton(&[]) } else { Space::new() };
            drop(v816_9);
            let v816_12: Space = if (&(v816_10)).is_empty() { Space::new() } else {
              let v818_6: Path = concat_path(&(v815_6),&v807_14_cursor.path()[(v807_14_origin + 2)..(v807_14_origin + 3)]);
              let v818_11: Space = routine_15(c, &(v818_6), &v807_14_cursor);
              drop(v818_6);
              map_map_kernels::compose(&(v816_10),&(v818_11))
            };
            drop(v816_10);
            let v816_13: Space = map_map_kernels::unite(&(v816_8),&(v816_12));
            join_wrapped_into(&mut v815_11_write,&((v816_13).read_zipper()),&[]);
            }
            v807_14_cursor.ascend(1);
          }
          drop(v815_11_write);
          drop(v815_6);
          map_map_kernels::compose(&(v810_10),&(v815_11))
        };
        drop(v810_10);
        let v810_13: Space = map_map_kernels::unite(&(v810_8),&(v810_12));
        join_wrapped_into(&mut v809_7_write,&((v810_13).read_zipper()),&[]);
        }
        v807_14_cursor.ascend(1);
      }
      drop(v809_7_write);
      drop(v809_6);
      map_map_kernels::compose(&(v808_5),&(v809_7))
    };
    drop(v808_5);
    let v808_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v808_2));
    drop(v808_2);
    let v808_10: Space = if map_kernels::has_head(&(v808_9)) { singleton(&[]) } else { Space::new() };
    drop(v808_9);
    let v808_11: Space = map_view_kernels::compose(&(v808_10),&v807_14_cursor);
    drop(v808_10);
    let v808_12: Space = map_map_kernels::unite(&(v808_8),&(v808_11));
    drop(v808_11);
    join_wrapped_into(&mut v807_14_write,&((v808_12).read_zipper()),&[]);
    }
    v807_14_cursor.ascend(1);
  }
  drop(v807_14_cursor);
  drop(v807_14_write);
  (v807_14).clone()
}

fn routine_48(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v819_3 = Space::new();
  let mut v819_3_write = v819_3.write_zipper();
  let mut v819_3_cursor = (*s0).read_zipper();
  let v819_3_origin = v819_3_cursor.path().len();
  for v819_3_byte in v819_3_cursor.child_mask().iter() {
    v819_3_cursor.descend_to_existing_byte(v819_3_byte);
    {
    let v820_2: Space = Space::new();
    join_wrapped_into(&mut v819_3_write,&((v820_2).read_zipper()),&[]);
    }
    v819_3_cursor.ascend(1);
  }
  drop(v819_3_cursor);
  drop(v819_3_write);
  (v819_3).clone()
}

fn routine_49(c: &mut Context, p0: &[u8], s0: &View<'_, '_>, s1: &View<'_, '_>) -> Space {
  let mut v821_29 = Space::new();
  let mut v821_29_write = v821_29.write_zipper();
  let mut v821_29_cursor = (*s0).read_zipper();
  let v821_29_origin = v821_29_cursor.path().len();
  for v821_29_byte in v821_29_cursor.child_mask().iter() {
    v821_29_cursor.descend_to_existing_byte(v821_29_byte);
    {
    let v822_2: Space = singleton(&v821_29_cursor.path()[v821_29_origin..(v821_29_origin + 1)]);
    let v822_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v822_2));
    drop(v822_2);
    let v822_4: Space = if map_kernels::has_head(&(v822_3)) { singleton(&[]) } else { Space::new() };
    drop(v822_3);
    let v822_12: Space = if (&(v822_4)).is_empty() { Space::new() } else {
      let v823_6: Space = view_view_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4))),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v821_29_cursor.path()[v821_29_origin..(v821_29_origin + 1)])));
      let mut v823_7 = Space::new();
      let mut v823_7_write = v823_7.write_zipper();
      let mut v823_7_cursor = (v823_6).read_zipper();
      let v823_7_origin = v823_7_cursor.path().len();
      for v823_7_byte in v823_7_cursor.child_mask().iter() {
        v823_7_cursor.descend_to_existing_byte(v823_7_byte);
        {
        let v824_2: Space = singleton(&v823_7_cursor.path()[v823_7_origin..(v823_7_origin + 1)]);
        let v824_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v824_2));
        let v824_4: Space = if map_kernels::has_head(&(v824_3)) { singleton(&[]) } else { Space::new() };
        drop(v824_3);
        let v824_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v824_4));
        drop(v824_4);
        let v824_7: Space = if (&(v824_5)).is_empty() { Space::new() } else {
          let mut v825_6 = Space::new();
          let mut v825_6_write = v825_6.write_zipper();
          for v825_6_byte in v823_7_cursor.child_mask().iter() {
            v823_7_cursor.descend_to_existing_byte(v825_6_byte);
            {
            let v826_2: Space = singleton(&v823_7_cursor.path()[(v823_7_origin + 1)..(v823_7_origin + 2)]);
            let v826_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v826_2));
            let v826_4: Space = if map_kernels::has_head(&(v826_3)) { singleton(&[]) } else { Space::new() };
            drop(v826_3);
            let v826_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v826_4));
            drop(v826_4);
            let v826_8: Space = if (&(v826_5)).is_empty() { Space::new() } else {
              let v827_7: Space = routine_10(c, &v823_7_cursor.path()[v823_7_origin..(v823_7_origin + 2)], &v823_7_cursor);
              map_map_kernels::compose(&(v826_5),&(v827_7))
            };
            drop(v826_5);
            let v826_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v826_2));
            drop(v826_2);
            let v826_10: Space = if map_kernels::has_head(&(v826_9)) { singleton(&[]) } else { Space::new() };
            drop(v826_9);
            let v826_12: Space = if (&(v826_10)).is_empty() { Space::new() } else {
              let v828_11: Space = routine_11(c, &v823_7_cursor.path()[v823_7_origin..(v823_7_origin + 2)], &v823_7_cursor);
              map_map_kernels::compose(&(v826_10),&(v828_11))
            };
            drop(v826_10);
            let v826_13: Space = map_map_kernels::unite(&(v826_8),&(v826_12));
            join_wrapped_into(&mut v825_6_write,&((v826_13).read_zipper()),&[]);
            }
            v823_7_cursor.ascend(1);
          }
          drop(v825_6_write);
          map_map_kernels::compose(&(v824_5),&(v825_6))
        };
        drop(v824_5);
        let v824_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v824_2));
        drop(v824_2);
        let v824_9: Space = if map_kernels::has_head(&(v824_8)) { singleton(&[]) } else { Space::new() };
        drop(v824_8);
        let v824_11: Space = if (&(v824_9)).is_empty() { Space::new() } else {
          let mut v829_10 = Space::new();
          let mut v829_10_write = v829_10.write_zipper();
          for v829_10_byte in v823_7_cursor.child_mask().iter() {
            v823_7_cursor.descend_to_existing_byte(v829_10_byte);
            {
            let v830_2: Space = singleton(&v823_7_cursor.path()[(v823_7_origin + 1)..(v823_7_origin + 2)]);
            let v830_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v830_2));
            let v830_4: Space = if map_kernels::has_head(&(v830_3)) { singleton(&[]) } else { Space::new() };
            drop(v830_3);
            let v830_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v830_4));
            drop(v830_4);
            let v830_8: Space = if (&(v830_5)).is_empty() { Space::new() } else {
              let v831_7: Space = routine_10(c, &v823_7_cursor.path()[v823_7_origin..(v823_7_origin + 2)], &v823_7_cursor);
              map_map_kernels::compose(&(v830_5),&(v831_7))
            };
            drop(v830_5);
            let v830_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v830_2));
            drop(v830_2);
            let v830_10: Space = if map_kernels::has_head(&(v830_9)) { singleton(&[]) } else { Space::new() };
            drop(v830_9);
            let v830_12: Space = if (&(v830_10)).is_empty() { Space::new() } else {
              let v832_11: Space = routine_12(c, &v823_7_cursor.path()[v823_7_origin..(v823_7_origin + 2)], &v823_7_cursor);
              map_map_kernels::compose(&(v830_10),&(v832_11))
            };
            drop(v830_10);
            let v830_13: Space = map_map_kernels::unite(&(v830_8),&(v830_12));
            join_wrapped_into(&mut v829_10_write,&((v830_13).read_zipper()),&[]);
            }
            v823_7_cursor.ascend(1);
          }
          drop(v829_10_write);
          map_map_kernels::compose(&(v824_9),&(v829_10))
        };
        drop(v824_9);
        let v824_12: Space = map_map_kernels::unite(&(v824_7),&(v824_11));
        join_wrapped_into(&mut v823_7_write,&((v824_12).read_zipper()),&[]);
        }
        v823_7_cursor.ascend(1);
      }
      drop(v823_7_cursor);
      drop(v823_7_write);
      drop(v823_6);
      let v823_8: Space = view_map_kernels::restrict_to(&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_3))),&(v823_7));
      let mut v823_9 = Space::new();
      let mut v823_9_write = v823_9.write_zipper();
      let mut v823_9_cursor = (v823_8).read_zipper();
      let v823_9_origin = v823_9_cursor.path().len();
      for v823_9_byte in v823_9_cursor.child_mask().iter() {
        v823_9_cursor.descend_to_existing_byte(v823_9_byte);
        {
        let v833_2: Space = singleton(&v823_9_cursor.path()[v823_9_origin..(v823_9_origin + 1)]);
        let v833_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v833_2));
        let v833_4: Space = if map_kernels::has_head(&(v833_3)) { singleton(&[]) } else { Space::new() };
        drop(v833_3);
        let v833_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v833_4));
        drop(v833_4);
        let v833_7: Space = if (&(v833_5)).is_empty() { Space::new() } else {
          let mut v834_6 = Space::new();
          let mut v834_6_write = v834_6.write_zipper();
          for v834_6_byte in v823_9_cursor.child_mask().iter() {
            v823_9_cursor.descend_to_existing_byte(v834_6_byte);
            {
            let v835_2: Space = singleton(&v823_9_cursor.path()[(v823_9_origin + 1)..(v823_9_origin + 2)]);
            let v835_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v835_2));
            let v835_4: Space = if map_kernels::has_head(&(v835_3)) { singleton(&[]) } else { Space::new() };
            drop(v835_3);
            let v835_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v835_4));
            drop(v835_4);
            let v835_8: Space = if (&(v835_5)).is_empty() { Space::new() } else {
              let v836_7: Space = routine_13(c, &v823_9_cursor.path()[v823_9_origin..(v823_9_origin + 2)], &v823_9_cursor);
              map_map_kernels::compose(&(v835_5),&(v836_7))
            };
            drop(v835_5);
            let v835_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v835_2));
            drop(v835_2);
            let v835_10: Space = if map_kernels::has_head(&(v835_9)) { singleton(&[]) } else { Space::new() };
            drop(v835_9);
            let v835_12: Space = if (&(v835_10)).is_empty() { Space::new() } else {
              let v837_11: Space = routine_14(c, &v823_9_cursor.path()[v823_9_origin..(v823_9_origin + 2)], &v823_9_cursor);
              map_map_kernels::compose(&(v835_10),&(v837_11))
            };
            drop(v835_10);
            let v835_13: Space = map_map_kernels::unite(&(v835_8),&(v835_12));
            join_wrapped_into(&mut v834_6_write,&((v835_13).read_zipper()),&[]);
            }
            v823_9_cursor.ascend(1);
          }
          drop(v834_6_write);
          map_map_kernels::compose(&(v833_5),&(v834_6))
        };
        drop(v833_5);
        let v833_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v833_2));
        drop(v833_2);
        let v833_9: Space = if map_kernels::has_head(&(v833_8)) { singleton(&[]) } else { Space::new() };
        drop(v833_8);
        let v833_11: Space = if (&(v833_9)).is_empty() { Space::new() } else {
          let mut v838_10 = Space::new();
          let mut v838_10_write = v838_10.write_zipper();
          for v838_10_byte in v823_9_cursor.child_mask().iter() {
            v823_9_cursor.descend_to_existing_byte(v838_10_byte);
            {
            let v839_2: Space = singleton(&v823_9_cursor.path()[(v823_9_origin + 1)..(v823_9_origin + 2)]);
            let v839_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v839_2));
            let v839_4: Space = if map_kernels::has_head(&(v839_3)) { singleton(&[]) } else { Space::new() };
            drop(v839_3);
            let v839_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v839_4));
            drop(v839_4);
            let v839_8: Space = if (&(v839_5)).is_empty() { Space::new() } else {
              let v840_7: Space = routine_13(c, &v823_9_cursor.path()[v823_9_origin..(v823_9_origin + 2)], &v823_9_cursor);
              map_map_kernels::compose(&(v839_5),&(v840_7))
            };
            drop(v839_5);
            let v839_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v839_2));
            drop(v839_2);
            let v839_10: Space = if map_kernels::has_head(&(v839_9)) { singleton(&[]) } else { Space::new() };
            drop(v839_9);
            let v839_12: Space = if (&(v839_10)).is_empty() { Space::new() } else {
              let v841_11: Space = routine_15(c, &v823_9_cursor.path()[v823_9_origin..(v823_9_origin + 2)], &v823_9_cursor);
              map_map_kernels::compose(&(v839_10),&(v841_11))
            };
            drop(v839_10);
            let v839_13: Space = map_map_kernels::unite(&(v839_8),&(v839_12));
            join_wrapped_into(&mut v838_10_write,&((v839_13).read_zipper()),&[]);
            }
            v823_9_cursor.ascend(1);
          }
          drop(v838_10_write);
          map_map_kernels::compose(&(v833_9),&(v838_10))
        };
        drop(v833_9);
        let v833_12: Space = map_map_kernels::unite(&(v833_7),&(v833_11));
        join_wrapped_into(&mut v823_9_write,&((v833_12).read_zipper()),&[]);
        }
        v823_9_cursor.ascend(1);
      }
      drop(v823_9_cursor);
      drop(v823_9_write);
      let v823_10: Space = map_view_kernels::subtract(&(v823_9),&(descend_cursor(descend_cursor(descend_cursor((*s1).read_zipper(),&(*CONSTANT_4)),&(*p0)),&v821_29_cursor.path()[v821_29_origin..(v821_29_origin + 1)])));
      let v823_11: Space = map_view_kernels::intersect(&(v823_10),&(descend_cursor((*s1).read_zipper(),&(*CONSTANT_5))));
      map_map_kernels::compose(&(v822_4),&(v823_11))
    };
    drop(v822_4);
    let v822_13: Path = concat_path(&(*p0),&v821_29_cursor.path()[v821_29_origin..(v821_29_origin + 1)]);
    join_wrapped_into(&mut v821_29_write,&((v822_12).read_zipper()),&(v822_13));
    drop(v822_13);
    }
    v821_29_cursor.ascend(1);
  }
  drop(v821_29_cursor);
  drop(v821_29_write);
  (v821_29).clone()
}

fn routine_50(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v842_20 = Space::new();
  let mut v842_20_write = v842_20.write_zipper();
  let mut v842_20_cursor = (*s0).read_zipper();
  let v842_20_origin = v842_20_cursor.path().len();
  for v842_20_byte in v842_20_cursor.child_mask().iter() {
    v842_20_cursor.descend_to_existing_byte(v842_20_byte);
    {
    let v843_2: Space = singleton(&v842_20_cursor.path()[v842_20_origin..(v842_20_origin + 1)]);
    let v843_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v843_2));
    let v843_4: Space = if map_kernels::has_head(&(v843_3)) { singleton(&[]) } else { Space::new() };
    drop(v843_3);
    let v843_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v843_4));
    drop(v843_4);
    let v843_8: Space = if (&(v843_5)).is_empty() { Space::new() } else {
      let v844_6: Path = concat_path(&(*p0),&v842_20_cursor.path()[v842_20_origin..(v842_20_origin + 1)]);
      let mut v844_7 = Space::new();
      let mut v844_7_write = v844_7.write_zipper();
      for v844_7_byte in v842_20_cursor.child_mask().iter() {
        v842_20_cursor.descend_to_existing_byte(v844_7_byte);
        {
        let v845_2: Space = singleton(&v842_20_cursor.path()[(v842_20_origin + 1)..(v842_20_origin + 2)]);
        let v845_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v845_2));
        let v845_4: Space = if map_kernels::has_head(&(v845_3)) { singleton(&[]) } else { Space::new() };
        drop(v845_3);
        let v845_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v845_4));
        drop(v845_4);
        let v845_8: Space = if (&(v845_5)).is_empty() { Space::new() } else {
          let v846_6: Path = concat_path(&(v844_6),&v842_20_cursor.path()[(v842_20_origin + 1)..(v842_20_origin + 2)]);
          let mut v846_7 = Space::new();
          let mut v846_7_write = v846_7.write_zipper();
          for v846_7_byte in v842_20_cursor.child_mask().iter() {
            v842_20_cursor.descend_to_existing_byte(v846_7_byte);
            {
            let v847_2: Space = singleton(&v842_20_cursor.path()[(v842_20_origin + 2)..(v842_20_origin + 3)]);
            let v847_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v847_2));
            let v847_4: Space = if map_kernels::has_head(&(v847_3)) { singleton(&[]) } else { Space::new() };
            drop(v847_3);
            let v847_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v847_4));
            drop(v847_4);
            let v847_8: Space = if (&(v847_5)).is_empty() { Space::new() } else {
              let v848_6: Path = concat_path(&(v846_6),&v842_20_cursor.path()[(v842_20_origin + 2)..(v842_20_origin + 3)]);
              let v848_7: Space = routine_62(c, &(v848_6), &v842_20_cursor);
              map_map_kernels::compose(&(v847_5),&(v848_7))
            };
            drop(v847_5);
            let v847_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v847_2));
            drop(v847_2);
            let v847_10: Space = if map_kernels::has_head(&(v847_9)) { singleton(&[]) } else { Space::new() };
            drop(v847_9);
            let v847_12: Space = if (&(v847_10)).is_empty() { Space::new() } else {
              let v849_6: Path = concat_path(&(v846_6),&v842_20_cursor.path()[(v842_20_origin + 2)..(v842_20_origin + 3)]);
              let v849_11: Space = routine_63(c, &(v849_6), &v842_20_cursor);
              drop(v849_6);
              map_map_kernels::compose(&(v847_10),&(v849_11))
            };
            drop(v847_10);
            let v847_13: Space = map_map_kernels::unite(&(v847_8),&(v847_12));
            join_wrapped_into(&mut v846_7_write,&((v847_13).read_zipper()),&[]);
            }
            v842_20_cursor.ascend(1);
          }
          drop(v846_7_write);
          map_map_kernels::compose(&(v845_5),&(v846_7))
        };
        drop(v845_5);
        let v845_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v845_2));
        drop(v845_2);
        let v845_10: Space = if map_kernels::has_head(&(v845_9)) { singleton(&[]) } else { Space::new() };
        drop(v845_9);
        let v845_12: Space = if (&(v845_10)).is_empty() { Space::new() } else {
          let v850_6: Path = concat_path(&(v844_6),&v842_20_cursor.path()[(v842_20_origin + 1)..(v842_20_origin + 2)]);
          let mut v850_11 = Space::new();
          let mut v850_11_write = v850_11.write_zipper();
          for v850_11_byte in v842_20_cursor.child_mask().iter() {
            v842_20_cursor.descend_to_existing_byte(v850_11_byte);
            {
            let v851_2: Space = singleton(&v842_20_cursor.path()[(v842_20_origin + 2)..(v842_20_origin + 3)]);
            let v851_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v851_2));
            let v851_4: Space = if map_kernels::has_head(&(v851_3)) { singleton(&[]) } else { Space::new() };
            drop(v851_3);
            let v851_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v851_4));
            drop(v851_4);
            let v851_8: Space = if (&(v851_5)).is_empty() { Space::new() } else {
              let v852_6: Path = concat_path(&(v850_6),&v842_20_cursor.path()[(v842_20_origin + 2)..(v842_20_origin + 3)]);
              let v852_7: Space = routine_62(c, &(v852_6), &v842_20_cursor);
              map_map_kernels::compose(&(v851_5),&(v852_7))
            };
            drop(v851_5);
            let v851_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v851_2));
            drop(v851_2);
            let v851_10: Space = if map_kernels::has_head(&(v851_9)) { singleton(&[]) } else { Space::new() };
            drop(v851_9);
            let v851_12: Space = if (&(v851_10)).is_empty() { Space::new() } else {
              let v853_6: Path = concat_path(&(v850_6),&v842_20_cursor.path()[(v842_20_origin + 2)..(v842_20_origin + 3)]);
              let v853_11: Space = routine_12(c, &(v853_6), &v842_20_cursor);
              drop(v853_6);
              map_map_kernels::compose(&(v851_10),&(v853_11))
            };
            drop(v851_10);
            let v851_13: Space = map_map_kernels::unite(&(v851_8),&(v851_12));
            join_wrapped_into(&mut v850_11_write,&((v851_13).read_zipper()),&[]);
            }
            v842_20_cursor.ascend(1);
          }
          drop(v850_11_write);
          drop(v850_6);
          map_map_kernels::compose(&(v845_10),&(v850_11))
        };
        drop(v845_10);
        let v845_13: Space = map_map_kernels::unite(&(v845_8),&(v845_12));
        join_wrapped_into(&mut v844_7_write,&((v845_13).read_zipper()),&[]);
        }
        v842_20_cursor.ascend(1);
      }
      drop(v844_7_write);
      map_map_kernels::compose(&(v843_5),&(v844_7))
    };
    drop(v843_5);
    let v843_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v843_2));
    drop(v843_2);
    let v843_10: Space = if map_kernels::has_head(&(v843_9)) { singleton(&[]) } else { Space::new() };
    drop(v843_9);
    let v843_12: Space = if (&(v843_10)).is_empty() { Space::new() } else {
      let v854_6: Path = concat_path(&(*p0),&v842_20_cursor.path()[v842_20_origin..(v842_20_origin + 1)]);
      let mut v854_11 = Space::new();
      let mut v854_11_write = v854_11.write_zipper();
      for v854_11_byte in v842_20_cursor.child_mask().iter() {
        v842_20_cursor.descend_to_existing_byte(v854_11_byte);
        {
        let v855_2: Space = singleton(&v842_20_cursor.path()[(v842_20_origin + 1)..(v842_20_origin + 2)]);
        let v855_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v855_2));
        let v855_4: Space = if map_kernels::has_head(&(v855_3)) { singleton(&[]) } else { Space::new() };
        drop(v855_3);
        let v855_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v855_4));
        drop(v855_4);
        let v855_8: Space = if (&(v855_5)).is_empty() { Space::new() } else {
          let v856_6: Path = concat_path(&(v854_6),&v842_20_cursor.path()[(v842_20_origin + 1)..(v842_20_origin + 2)]);
          let mut v856_7 = Space::new();
          let mut v856_7_write = v856_7.write_zipper();
          for v856_7_byte in v842_20_cursor.child_mask().iter() {
            v842_20_cursor.descend_to_existing_byte(v856_7_byte);
            {
            let v857_2: Space = singleton(&v842_20_cursor.path()[(v842_20_origin + 2)..(v842_20_origin + 3)]);
            let v857_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v857_2));
            let v857_4: Space = if map_kernels::has_head(&(v857_3)) { singleton(&[]) } else { Space::new() };
            drop(v857_3);
            let v857_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v857_4));
            drop(v857_4);
            let v857_8: Space = if (&(v857_5)).is_empty() { Space::new() } else {
              let v858_6: Path = concat_path(&(v856_6),&v842_20_cursor.path()[(v842_20_origin + 2)..(v842_20_origin + 3)]);
              let v858_7: Space = routine_62(c, &(v858_6), &v842_20_cursor);
              map_map_kernels::compose(&(v857_5),&(v858_7))
            };
            drop(v857_5);
            let v857_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v857_2));
            drop(v857_2);
            let v857_10: Space = if map_kernels::has_head(&(v857_9)) { singleton(&[]) } else { Space::new() };
            drop(v857_9);
            let v857_12: Space = if (&(v857_10)).is_empty() { Space::new() } else {
              let v859_6: Path = concat_path(&(v856_6),&v842_20_cursor.path()[(v842_20_origin + 2)..(v842_20_origin + 3)]);
              let v859_11: Space = routine_63(c, &(v859_6), &v842_20_cursor);
              drop(v859_6);
              map_map_kernels::compose(&(v857_10),&(v859_11))
            };
            drop(v857_10);
            let v857_13: Space = map_map_kernels::unite(&(v857_8),&(v857_12));
            join_wrapped_into(&mut v856_7_write,&((v857_13).read_zipper()),&[]);
            }
            v842_20_cursor.ascend(1);
          }
          drop(v856_7_write);
          drop(v856_6);
          map_map_kernels::compose(&(v855_5),&(v856_7))
        };
        drop(v855_5);
        let v855_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v855_2));
        drop(v855_2);
        let v855_10: Space = if map_kernels::has_head(&(v855_9)) { singleton(&[]) } else { Space::new() };
        drop(v855_9);
        let v855_11: Space = map_view_kernels::compose(&(v855_10),&v842_20_cursor);
        drop(v855_10);
        let v855_12: Space = map_map_kernels::unite(&(v855_8),&(v855_11));
        drop(v855_11);
        join_wrapped_into(&mut v854_11_write,&((v855_12).read_zipper()),&[]);
        }
        v842_20_cursor.ascend(1);
      }
      drop(v854_11_write);
      drop(v854_6);
      map_map_kernels::compose(&(v843_10),&(v854_11))
    };
    drop(v843_10);
    let v843_13: Space = map_map_kernels::unite(&(v843_8),&(v843_12));
    join_wrapped_into(&mut v842_20_write,&((v843_13).read_zipper()),&[]);
    }
    v842_20_cursor.ascend(1);
  }
  drop(v842_20_cursor);
  drop(v842_20_write);
  (v842_20).clone()
}

fn routine_51(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v860_14 = Space::new();
  let mut v860_14_write = v860_14.write_zipper();
  let mut v860_14_cursor = (*s0).read_zipper();
  let v860_14_origin = v860_14_cursor.path().len();
  for v860_14_byte in v860_14_cursor.child_mask().iter() {
    v860_14_cursor.descend_to_existing_byte(v860_14_byte);
    {
    let v861_2: Space = singleton(&v860_14_cursor.path()[v860_14_origin..(v860_14_origin + 1)]);
    let v861_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v861_2));
    let v861_4: Space = if map_kernels::has_head(&(v861_3)) { singleton(&[]) } else { Space::new() };
    drop(v861_3);
    let v861_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v861_4));
    drop(v861_4);
    let v861_8: Space = if (&(v861_5)).is_empty() { Space::new() } else {
      let v862_6: Path = concat_path(&(*p0),&v860_14_cursor.path()[v860_14_origin..(v860_14_origin + 1)]);
      let mut v862_7 = Space::new();
      let mut v862_7_write = v862_7.write_zipper();
      for v862_7_byte in v860_14_cursor.child_mask().iter() {
        v860_14_cursor.descend_to_existing_byte(v862_7_byte);
        {
        let v863_2: Space = singleton(&v860_14_cursor.path()[(v860_14_origin + 1)..(v860_14_origin + 2)]);
        let v863_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v863_2));
        let v863_4: Space = if map_kernels::has_head(&(v863_3)) { singleton(&[]) } else { Space::new() };
        drop(v863_3);
        let v863_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v863_4));
        drop(v863_4);
        let v863_8: Space = if (&(v863_5)).is_empty() { Space::new() } else {
          let v864_6: Path = concat_path(&(v862_6),&v860_14_cursor.path()[(v860_14_origin + 1)..(v860_14_origin + 2)]);
          let mut v864_7 = Space::new();
          let mut v864_7_write = v864_7.write_zipper();
          for v864_7_byte in v860_14_cursor.child_mask().iter() {
            v860_14_cursor.descend_to_existing_byte(v864_7_byte);
            {
            let v865_2: Space = singleton(&v860_14_cursor.path()[(v860_14_origin + 2)..(v860_14_origin + 3)]);
            let v865_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v865_2));
            let v865_4: Space = if map_kernels::has_head(&(v865_3)) { singleton(&[]) } else { Space::new() };
            drop(v865_3);
            let v865_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v865_4));
            drop(v865_4);
            let v865_8: Space = if (&(v865_5)).is_empty() { Space::new() } else {
              let v866_6: Path = concat_path(&(v864_6),&v860_14_cursor.path()[(v860_14_origin + 2)..(v860_14_origin + 3)]);
              let v866_7: Space = routine_62(c, &(v866_6), &v860_14_cursor);
              map_map_kernels::compose(&(v865_5),&(v866_7))
            };
            drop(v865_5);
            let v865_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v865_2));
            drop(v865_2);
            let v865_10: Space = if map_kernels::has_head(&(v865_9)) { singleton(&[]) } else { Space::new() };
            drop(v865_9);
            let v865_12: Space = if (&(v865_10)).is_empty() { Space::new() } else {
              let v867_6: Path = concat_path(&(v864_6),&v860_14_cursor.path()[(v860_14_origin + 2)..(v860_14_origin + 3)]);
              let v867_11: Space = routine_63(c, &(v867_6), &v860_14_cursor);
              drop(v867_6);
              map_map_kernels::compose(&(v865_10),&(v867_11))
            };
            drop(v865_10);
            let v865_13: Space = map_map_kernels::unite(&(v865_8),&(v865_12));
            join_wrapped_into(&mut v864_7_write,&((v865_13).read_zipper()),&[]);
            }
            v860_14_cursor.ascend(1);
          }
          drop(v864_7_write);
          map_map_kernels::compose(&(v863_5),&(v864_7))
        };
        drop(v863_5);
        let v863_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v863_2));
        drop(v863_2);
        let v863_10: Space = if map_kernels::has_head(&(v863_9)) { singleton(&[]) } else { Space::new() };
        drop(v863_9);
        let v863_12: Space = if (&(v863_10)).is_empty() { Space::new() } else {
          let v868_6: Path = concat_path(&(v862_6),&v860_14_cursor.path()[(v860_14_origin + 1)..(v860_14_origin + 2)]);
          let mut v868_11 = Space::new();
          let mut v868_11_write = v868_11.write_zipper();
          for v868_11_byte in v860_14_cursor.child_mask().iter() {
            v860_14_cursor.descend_to_existing_byte(v868_11_byte);
            {
            let v869_2: Space = singleton(&v860_14_cursor.path()[(v860_14_origin + 2)..(v860_14_origin + 3)]);
            let v869_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v869_2));
            let v869_4: Space = if map_kernels::has_head(&(v869_3)) { singleton(&[]) } else { Space::new() };
            drop(v869_3);
            let v869_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v869_4));
            drop(v869_4);
            let v869_8: Space = if (&(v869_5)).is_empty() { Space::new() } else {
              let v870_6: Path = concat_path(&(v868_6),&v860_14_cursor.path()[(v860_14_origin + 2)..(v860_14_origin + 3)]);
              let v870_7: Space = routine_62(c, &(v870_6), &v860_14_cursor);
              map_map_kernels::compose(&(v869_5),&(v870_7))
            };
            drop(v869_5);
            let v869_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v869_2));
            drop(v869_2);
            let v869_10: Space = if map_kernels::has_head(&(v869_9)) { singleton(&[]) } else { Space::new() };
            drop(v869_9);
            let v869_12: Space = if (&(v869_10)).is_empty() { Space::new() } else {
              let v871_6: Path = concat_path(&(v868_6),&v860_14_cursor.path()[(v860_14_origin + 2)..(v860_14_origin + 3)]);
              let v871_11: Space = routine_12(c, &(v871_6), &v860_14_cursor);
              drop(v871_6);
              map_map_kernels::compose(&(v869_10),&(v871_11))
            };
            drop(v869_10);
            let v869_13: Space = map_map_kernels::unite(&(v869_8),&(v869_12));
            join_wrapped_into(&mut v868_11_write,&((v869_13).read_zipper()),&[]);
            }
            v860_14_cursor.ascend(1);
          }
          drop(v868_11_write);
          drop(v868_6);
          map_map_kernels::compose(&(v863_10),&(v868_11))
        };
        drop(v863_10);
        let v863_13: Space = map_map_kernels::unite(&(v863_8),&(v863_12));
        join_wrapped_into(&mut v862_7_write,&((v863_13).read_zipper()),&[]);
        }
        v860_14_cursor.ascend(1);
      }
      drop(v862_7_write);
      drop(v862_6);
      map_map_kernels::compose(&(v861_5),&(v862_7))
    };
    drop(v861_5);
    let v861_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v861_2));
    drop(v861_2);
    let v861_10: Space = if map_kernels::has_head(&(v861_9)) { singleton(&[]) } else { Space::new() };
    drop(v861_9);
    let v861_11: Space = map_view_kernels::compose(&(v861_10),&v860_14_cursor);
    drop(v861_10);
    let v861_12: Space = map_map_kernels::unite(&(v861_8),&(v861_11));
    drop(v861_11);
    join_wrapped_into(&mut v860_14_write,&((v861_12).read_zipper()),&[]);
    }
    v860_14_cursor.ascend(1);
  }
  drop(v860_14_cursor);
  drop(v860_14_write);
  (v860_14).clone()
}

fn routine_52(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v872_20 = Space::new();
  let mut v872_20_write = v872_20.write_zipper();
  let mut v872_20_cursor = (*s0).read_zipper();
  let v872_20_origin = v872_20_cursor.path().len();
  for v872_20_byte in v872_20_cursor.child_mask().iter() {
    v872_20_cursor.descend_to_existing_byte(v872_20_byte);
    {
    let v873_2: Space = singleton(&v872_20_cursor.path()[v872_20_origin..(v872_20_origin + 1)]);
    let v873_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v873_2));
    let v873_4: Space = if map_kernels::has_head(&(v873_3)) { singleton(&[]) } else { Space::new() };
    drop(v873_3);
    let v873_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v873_4));
    drop(v873_4);
    let v873_8: Space = if (&(v873_5)).is_empty() { Space::new() } else {
      let v874_6: Path = concat_path(&(*p0),&v872_20_cursor.path()[v872_20_origin..(v872_20_origin + 1)]);
      let mut v874_7 = Space::new();
      let mut v874_7_write = v874_7.write_zipper();
      for v874_7_byte in v872_20_cursor.child_mask().iter() {
        v872_20_cursor.descend_to_existing_byte(v874_7_byte);
        {
        let v875_2: Space = singleton(&v872_20_cursor.path()[(v872_20_origin + 1)..(v872_20_origin + 2)]);
        let v875_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v875_2));
        let v875_4: Space = if map_kernels::has_head(&(v875_3)) { singleton(&[]) } else { Space::new() };
        drop(v875_3);
        let v875_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v875_4));
        drop(v875_4);
        let v875_8: Space = if (&(v875_5)).is_empty() { Space::new() } else {
          let v876_6: Path = concat_path(&(v874_6),&v872_20_cursor.path()[(v872_20_origin + 1)..(v872_20_origin + 2)]);
          let mut v876_7 = Space::new();
          let mut v876_7_write = v876_7.write_zipper();
          for v876_7_byte in v872_20_cursor.child_mask().iter() {
            v872_20_cursor.descend_to_existing_byte(v876_7_byte);
            {
            let v877_2: Space = singleton(&v872_20_cursor.path()[(v872_20_origin + 2)..(v872_20_origin + 3)]);
            let v877_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v877_2));
            let v877_4: Space = if map_kernels::has_head(&(v877_3)) { singleton(&[]) } else { Space::new() };
            drop(v877_3);
            let v877_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v877_4));
            drop(v877_4);
            let v877_8: Space = if (&(v877_5)).is_empty() { Space::new() } else {
              let v878_6: Path = concat_path(&(v876_6),&v872_20_cursor.path()[(v872_20_origin + 2)..(v872_20_origin + 3)]);
              let v878_7: Space = routine_64(c, &(v878_6), &v872_20_cursor);
              map_map_kernels::compose(&(v877_5),&(v878_7))
            };
            drop(v877_5);
            let v877_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v877_2));
            drop(v877_2);
            let v877_10: Space = if map_kernels::has_head(&(v877_9)) { singleton(&[]) } else { Space::new() };
            drop(v877_9);
            let v877_12: Space = if (&(v877_10)).is_empty() { Space::new() } else {
              let v879_6: Path = concat_path(&(v876_6),&v872_20_cursor.path()[(v872_20_origin + 2)..(v872_20_origin + 3)]);
              let v879_11: Space = routine_65(c, &(v879_6), &v872_20_cursor);
              drop(v879_6);
              map_map_kernels::compose(&(v877_10),&(v879_11))
            };
            drop(v877_10);
            let v877_13: Space = map_map_kernels::unite(&(v877_8),&(v877_12));
            join_wrapped_into(&mut v876_7_write,&((v877_13).read_zipper()),&[]);
            }
            v872_20_cursor.ascend(1);
          }
          drop(v876_7_write);
          map_map_kernels::compose(&(v875_5),&(v876_7))
        };
        drop(v875_5);
        let v875_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v875_2));
        drop(v875_2);
        let v875_10: Space = if map_kernels::has_head(&(v875_9)) { singleton(&[]) } else { Space::new() };
        drop(v875_9);
        let v875_12: Space = if (&(v875_10)).is_empty() { Space::new() } else {
          let v880_6: Path = concat_path(&(v874_6),&v872_20_cursor.path()[(v872_20_origin + 1)..(v872_20_origin + 2)]);
          let mut v880_11 = Space::new();
          let mut v880_11_write = v880_11.write_zipper();
          for v880_11_byte in v872_20_cursor.child_mask().iter() {
            v872_20_cursor.descend_to_existing_byte(v880_11_byte);
            {
            let v881_2: Space = singleton(&v872_20_cursor.path()[(v872_20_origin + 2)..(v872_20_origin + 3)]);
            let v881_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v881_2));
            let v881_4: Space = if map_kernels::has_head(&(v881_3)) { singleton(&[]) } else { Space::new() };
            drop(v881_3);
            let v881_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v881_4));
            drop(v881_4);
            let v881_8: Space = if (&(v881_5)).is_empty() { Space::new() } else {
              let v882_6: Path = concat_path(&(v880_6),&v872_20_cursor.path()[(v872_20_origin + 2)..(v872_20_origin + 3)]);
              let v882_7: Space = routine_64(c, &(v882_6), &v872_20_cursor);
              map_map_kernels::compose(&(v881_5),&(v882_7))
            };
            drop(v881_5);
            let v881_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v881_2));
            drop(v881_2);
            let v881_10: Space = if map_kernels::has_head(&(v881_9)) { singleton(&[]) } else { Space::new() };
            drop(v881_9);
            let v881_12: Space = if (&(v881_10)).is_empty() { Space::new() } else {
              let v883_6: Path = concat_path(&(v880_6),&v872_20_cursor.path()[(v872_20_origin + 2)..(v872_20_origin + 3)]);
              let v883_11: Space = routine_15(c, &(v883_6), &v872_20_cursor);
              drop(v883_6);
              map_map_kernels::compose(&(v881_10),&(v883_11))
            };
            drop(v881_10);
            let v881_13: Space = map_map_kernels::unite(&(v881_8),&(v881_12));
            join_wrapped_into(&mut v880_11_write,&((v881_13).read_zipper()),&[]);
            }
            v872_20_cursor.ascend(1);
          }
          drop(v880_11_write);
          drop(v880_6);
          map_map_kernels::compose(&(v875_10),&(v880_11))
        };
        drop(v875_10);
        let v875_13: Space = map_map_kernels::unite(&(v875_8),&(v875_12));
        join_wrapped_into(&mut v874_7_write,&((v875_13).read_zipper()),&[]);
        }
        v872_20_cursor.ascend(1);
      }
      drop(v874_7_write);
      map_map_kernels::compose(&(v873_5),&(v874_7))
    };
    drop(v873_5);
    let v873_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v873_2));
    drop(v873_2);
    let v873_10: Space = if map_kernels::has_head(&(v873_9)) { singleton(&[]) } else { Space::new() };
    drop(v873_9);
    let v873_12: Space = if (&(v873_10)).is_empty() { Space::new() } else {
      let v884_6: Path = concat_path(&(*p0),&v872_20_cursor.path()[v872_20_origin..(v872_20_origin + 1)]);
      let mut v884_11 = Space::new();
      let mut v884_11_write = v884_11.write_zipper();
      for v884_11_byte in v872_20_cursor.child_mask().iter() {
        v872_20_cursor.descend_to_existing_byte(v884_11_byte);
        {
        let v885_2: Space = singleton(&v872_20_cursor.path()[(v872_20_origin + 1)..(v872_20_origin + 2)]);
        let v885_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v885_2));
        let v885_4: Space = if map_kernels::has_head(&(v885_3)) { singleton(&[]) } else { Space::new() };
        drop(v885_3);
        let v885_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v885_4));
        drop(v885_4);
        let v885_8: Space = if (&(v885_5)).is_empty() { Space::new() } else {
          let v886_6: Path = concat_path(&(v884_6),&v872_20_cursor.path()[(v872_20_origin + 1)..(v872_20_origin + 2)]);
          let mut v886_7 = Space::new();
          let mut v886_7_write = v886_7.write_zipper();
          for v886_7_byte in v872_20_cursor.child_mask().iter() {
            v872_20_cursor.descend_to_existing_byte(v886_7_byte);
            {
            let v887_2: Space = singleton(&v872_20_cursor.path()[(v872_20_origin + 2)..(v872_20_origin + 3)]);
            let v887_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v887_2));
            let v887_4: Space = if map_kernels::has_head(&(v887_3)) { singleton(&[]) } else { Space::new() };
            drop(v887_3);
            let v887_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v887_4));
            drop(v887_4);
            let v887_8: Space = if (&(v887_5)).is_empty() { Space::new() } else {
              let v888_6: Path = concat_path(&(v886_6),&v872_20_cursor.path()[(v872_20_origin + 2)..(v872_20_origin + 3)]);
              let v888_7: Space = routine_64(c, &(v888_6), &v872_20_cursor);
              map_map_kernels::compose(&(v887_5),&(v888_7))
            };
            drop(v887_5);
            let v887_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v887_2));
            drop(v887_2);
            let v887_10: Space = if map_kernels::has_head(&(v887_9)) { singleton(&[]) } else { Space::new() };
            drop(v887_9);
            let v887_12: Space = if (&(v887_10)).is_empty() { Space::new() } else {
              let v889_6: Path = concat_path(&(v886_6),&v872_20_cursor.path()[(v872_20_origin + 2)..(v872_20_origin + 3)]);
              let v889_11: Space = routine_65(c, &(v889_6), &v872_20_cursor);
              drop(v889_6);
              map_map_kernels::compose(&(v887_10),&(v889_11))
            };
            drop(v887_10);
            let v887_13: Space = map_map_kernels::unite(&(v887_8),&(v887_12));
            join_wrapped_into(&mut v886_7_write,&((v887_13).read_zipper()),&[]);
            }
            v872_20_cursor.ascend(1);
          }
          drop(v886_7_write);
          drop(v886_6);
          map_map_kernels::compose(&(v885_5),&(v886_7))
        };
        drop(v885_5);
        let v885_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v885_2));
        drop(v885_2);
        let v885_10: Space = if map_kernels::has_head(&(v885_9)) { singleton(&[]) } else { Space::new() };
        drop(v885_9);
        let v885_11: Space = map_view_kernels::compose(&(v885_10),&v872_20_cursor);
        drop(v885_10);
        let v885_12: Space = map_map_kernels::unite(&(v885_8),&(v885_11));
        drop(v885_11);
        join_wrapped_into(&mut v884_11_write,&((v885_12).read_zipper()),&[]);
        }
        v872_20_cursor.ascend(1);
      }
      drop(v884_11_write);
      drop(v884_6);
      map_map_kernels::compose(&(v873_10),&(v884_11))
    };
    drop(v873_10);
    let v873_13: Space = map_map_kernels::unite(&(v873_8),&(v873_12));
    join_wrapped_into(&mut v872_20_write,&((v873_13).read_zipper()),&[]);
    }
    v872_20_cursor.ascend(1);
  }
  drop(v872_20_cursor);
  drop(v872_20_write);
  (v872_20).clone()
}

fn routine_53(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v890_14 = Space::new();
  let mut v890_14_write = v890_14.write_zipper();
  let mut v890_14_cursor = (*s0).read_zipper();
  let v890_14_origin = v890_14_cursor.path().len();
  for v890_14_byte in v890_14_cursor.child_mask().iter() {
    v890_14_cursor.descend_to_existing_byte(v890_14_byte);
    {
    let v891_2: Space = singleton(&v890_14_cursor.path()[v890_14_origin..(v890_14_origin + 1)]);
    let v891_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v891_2));
    let v891_4: Space = if map_kernels::has_head(&(v891_3)) { singleton(&[]) } else { Space::new() };
    drop(v891_3);
    let v891_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v891_4));
    drop(v891_4);
    let v891_8: Space = if (&(v891_5)).is_empty() { Space::new() } else {
      let v892_6: Path = concat_path(&(*p0),&v890_14_cursor.path()[v890_14_origin..(v890_14_origin + 1)]);
      let mut v892_7 = Space::new();
      let mut v892_7_write = v892_7.write_zipper();
      for v892_7_byte in v890_14_cursor.child_mask().iter() {
        v890_14_cursor.descend_to_existing_byte(v892_7_byte);
        {
        let v893_2: Space = singleton(&v890_14_cursor.path()[(v890_14_origin + 1)..(v890_14_origin + 2)]);
        let v893_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v893_2));
        let v893_4: Space = if map_kernels::has_head(&(v893_3)) { singleton(&[]) } else { Space::new() };
        drop(v893_3);
        let v893_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v893_4));
        drop(v893_4);
        let v893_8: Space = if (&(v893_5)).is_empty() { Space::new() } else {
          let v894_6: Path = concat_path(&(v892_6),&v890_14_cursor.path()[(v890_14_origin + 1)..(v890_14_origin + 2)]);
          let mut v894_7 = Space::new();
          let mut v894_7_write = v894_7.write_zipper();
          for v894_7_byte in v890_14_cursor.child_mask().iter() {
            v890_14_cursor.descend_to_existing_byte(v894_7_byte);
            {
            let v895_2: Space = singleton(&v890_14_cursor.path()[(v890_14_origin + 2)..(v890_14_origin + 3)]);
            let v895_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v895_2));
            let v895_4: Space = if map_kernels::has_head(&(v895_3)) { singleton(&[]) } else { Space::new() };
            drop(v895_3);
            let v895_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v895_4));
            drop(v895_4);
            let v895_8: Space = if (&(v895_5)).is_empty() { Space::new() } else {
              let v896_6: Path = concat_path(&(v894_6),&v890_14_cursor.path()[(v890_14_origin + 2)..(v890_14_origin + 3)]);
              let v896_7: Space = routine_64(c, &(v896_6), &v890_14_cursor);
              map_map_kernels::compose(&(v895_5),&(v896_7))
            };
            drop(v895_5);
            let v895_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v895_2));
            drop(v895_2);
            let v895_10: Space = if map_kernels::has_head(&(v895_9)) { singleton(&[]) } else { Space::new() };
            drop(v895_9);
            let v895_12: Space = if (&(v895_10)).is_empty() { Space::new() } else {
              let v897_6: Path = concat_path(&(v894_6),&v890_14_cursor.path()[(v890_14_origin + 2)..(v890_14_origin + 3)]);
              let v897_11: Space = routine_65(c, &(v897_6), &v890_14_cursor);
              drop(v897_6);
              map_map_kernels::compose(&(v895_10),&(v897_11))
            };
            drop(v895_10);
            let v895_13: Space = map_map_kernels::unite(&(v895_8),&(v895_12));
            join_wrapped_into(&mut v894_7_write,&((v895_13).read_zipper()),&[]);
            }
            v890_14_cursor.ascend(1);
          }
          drop(v894_7_write);
          map_map_kernels::compose(&(v893_5),&(v894_7))
        };
        drop(v893_5);
        let v893_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v893_2));
        drop(v893_2);
        let v893_10: Space = if map_kernels::has_head(&(v893_9)) { singleton(&[]) } else { Space::new() };
        drop(v893_9);
        let v893_12: Space = if (&(v893_10)).is_empty() { Space::new() } else {
          let v898_6: Path = concat_path(&(v892_6),&v890_14_cursor.path()[(v890_14_origin + 1)..(v890_14_origin + 2)]);
          let mut v898_11 = Space::new();
          let mut v898_11_write = v898_11.write_zipper();
          for v898_11_byte in v890_14_cursor.child_mask().iter() {
            v890_14_cursor.descend_to_existing_byte(v898_11_byte);
            {
            let v899_2: Space = singleton(&v890_14_cursor.path()[(v890_14_origin + 2)..(v890_14_origin + 3)]);
            let v899_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v899_2));
            let v899_4: Space = if map_kernels::has_head(&(v899_3)) { singleton(&[]) } else { Space::new() };
            drop(v899_3);
            let v899_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v899_4));
            drop(v899_4);
            let v899_8: Space = if (&(v899_5)).is_empty() { Space::new() } else {
              let v900_6: Path = concat_path(&(v898_6),&v890_14_cursor.path()[(v890_14_origin + 2)..(v890_14_origin + 3)]);
              let v900_7: Space = routine_64(c, &(v900_6), &v890_14_cursor);
              map_map_kernels::compose(&(v899_5),&(v900_7))
            };
            drop(v899_5);
            let v899_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v899_2));
            drop(v899_2);
            let v899_10: Space = if map_kernels::has_head(&(v899_9)) { singleton(&[]) } else { Space::new() };
            drop(v899_9);
            let v899_12: Space = if (&(v899_10)).is_empty() { Space::new() } else {
              let v901_6: Path = concat_path(&(v898_6),&v890_14_cursor.path()[(v890_14_origin + 2)..(v890_14_origin + 3)]);
              let v901_11: Space = routine_15(c, &(v901_6), &v890_14_cursor);
              drop(v901_6);
              map_map_kernels::compose(&(v899_10),&(v901_11))
            };
            drop(v899_10);
            let v899_13: Space = map_map_kernels::unite(&(v899_8),&(v899_12));
            join_wrapped_into(&mut v898_11_write,&((v899_13).read_zipper()),&[]);
            }
            v890_14_cursor.ascend(1);
          }
          drop(v898_11_write);
          drop(v898_6);
          map_map_kernels::compose(&(v893_10),&(v898_11))
        };
        drop(v893_10);
        let v893_13: Space = map_map_kernels::unite(&(v893_8),&(v893_12));
        join_wrapped_into(&mut v892_7_write,&((v893_13).read_zipper()),&[]);
        }
        v890_14_cursor.ascend(1);
      }
      drop(v892_7_write);
      drop(v892_6);
      map_map_kernels::compose(&(v891_5),&(v892_7))
    };
    drop(v891_5);
    let v891_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v891_2));
    drop(v891_2);
    let v891_10: Space = if map_kernels::has_head(&(v891_9)) { singleton(&[]) } else { Space::new() };
    drop(v891_9);
    let v891_11: Space = map_view_kernels::compose(&(v891_10),&v890_14_cursor);
    drop(v891_10);
    let v891_12: Space = map_map_kernels::unite(&(v891_8),&(v891_11));
    drop(v891_11);
    join_wrapped_into(&mut v890_14_write,&((v891_12).read_zipper()),&[]);
    }
    v890_14_cursor.ascend(1);
  }
  drop(v890_14_cursor);
  drop(v890_14_write);
  (v890_14).clone()
}

fn routine_54(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v902_20 = Space::new();
  let mut v902_20_write = v902_20.write_zipper();
  let mut v902_20_cursor = (*s0).read_zipper();
  let v902_20_origin = v902_20_cursor.path().len();
  for v902_20_byte in v902_20_cursor.child_mask().iter() {
    v902_20_cursor.descend_to_existing_byte(v902_20_byte);
    {
    let v903_2: Space = singleton(&v902_20_cursor.path()[v902_20_origin..(v902_20_origin + 1)]);
    let v903_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v903_2));
    let v903_4: Space = if map_kernels::has_head(&(v903_3)) { singleton(&[]) } else { Space::new() };
    drop(v903_3);
    let v903_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v903_4));
    drop(v903_4);
    let v903_8: Space = if (&(v903_5)).is_empty() { Space::new() } else {
      let v904_6: Path = concat_path(&(*p0),&v902_20_cursor.path()[v902_20_origin..(v902_20_origin + 1)]);
      let mut v904_7 = Space::new();
      let mut v904_7_write = v904_7.write_zipper();
      for v904_7_byte in v902_20_cursor.child_mask().iter() {
        v902_20_cursor.descend_to_existing_byte(v904_7_byte);
        {
        let v905_2: Space = singleton(&v902_20_cursor.path()[(v902_20_origin + 1)..(v902_20_origin + 2)]);
        let v905_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v905_2));
        let v905_4: Space = if map_kernels::has_head(&(v905_3)) { singleton(&[]) } else { Space::new() };
        drop(v905_3);
        let v905_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v905_4));
        drop(v905_4);
        let v905_8: Space = if (&(v905_5)).is_empty() { Space::new() } else {
          let v906_6: Path = concat_path(&(v904_6),&v902_20_cursor.path()[(v902_20_origin + 1)..(v902_20_origin + 2)]);
          let mut v906_7 = Space::new();
          let mut v906_7_write = v906_7.write_zipper();
          for v906_7_byte in v902_20_cursor.child_mask().iter() {
            v902_20_cursor.descend_to_existing_byte(v906_7_byte);
            {
            let v907_2: Space = singleton(&v902_20_cursor.path()[(v902_20_origin + 2)..(v902_20_origin + 3)]);
            let v907_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v907_2));
            let v907_4: Space = if map_kernels::has_head(&(v907_3)) { singleton(&[]) } else { Space::new() };
            drop(v907_3);
            let v907_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v907_4));
            drop(v907_4);
            let v907_8: Space = if (&(v907_5)).is_empty() { Space::new() } else {
              let v908_6: Path = concat_path(&(v906_6),&v902_20_cursor.path()[(v902_20_origin + 2)..(v902_20_origin + 3)]);
              let v908_7: Space = routine_66(c, &(v908_6), &v902_20_cursor);
              map_map_kernels::compose(&(v907_5),&(v908_7))
            };
            drop(v907_5);
            let v907_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v907_2));
            drop(v907_2);
            let v907_10: Space = if map_kernels::has_head(&(v907_9)) { singleton(&[]) } else { Space::new() };
            drop(v907_9);
            let v907_12: Space = if (&(v907_10)).is_empty() { Space::new() } else {
              let v909_6: Path = concat_path(&(v906_6),&v902_20_cursor.path()[(v902_20_origin + 2)..(v902_20_origin + 3)]);
              let v909_11: Space = routine_67(c, &(v909_6), &v902_20_cursor);
              drop(v909_6);
              map_map_kernels::compose(&(v907_10),&(v909_11))
            };
            drop(v907_10);
            let v907_13: Space = map_map_kernels::unite(&(v907_8),&(v907_12));
            join_wrapped_into(&mut v906_7_write,&((v907_13).read_zipper()),&[]);
            }
            v902_20_cursor.ascend(1);
          }
          drop(v906_7_write);
          map_map_kernels::compose(&(v905_5),&(v906_7))
        };
        drop(v905_5);
        let v905_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v905_2));
        drop(v905_2);
        let v905_10: Space = if map_kernels::has_head(&(v905_9)) { singleton(&[]) } else { Space::new() };
        drop(v905_9);
        let v905_12: Space = if (&(v905_10)).is_empty() { Space::new() } else {
          let v910_6: Path = concat_path(&(v904_6),&v902_20_cursor.path()[(v902_20_origin + 1)..(v902_20_origin + 2)]);
          let mut v910_11 = Space::new();
          let mut v910_11_write = v910_11.write_zipper();
          for v910_11_byte in v902_20_cursor.child_mask().iter() {
            v902_20_cursor.descend_to_existing_byte(v910_11_byte);
            {
            let v911_2: Space = singleton(&v902_20_cursor.path()[(v902_20_origin + 2)..(v902_20_origin + 3)]);
            let v911_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v911_2));
            let v911_4: Space = if map_kernels::has_head(&(v911_3)) { singleton(&[]) } else { Space::new() };
            drop(v911_3);
            let v911_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v911_4));
            drop(v911_4);
            let v911_8: Space = if (&(v911_5)).is_empty() { Space::new() } else {
              let v912_6: Path = concat_path(&(v910_6),&v902_20_cursor.path()[(v902_20_origin + 2)..(v902_20_origin + 3)]);
              let v912_7: Space = routine_66(c, &(v912_6), &v902_20_cursor);
              map_map_kernels::compose(&(v911_5),&(v912_7))
            };
            drop(v911_5);
            let v911_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v911_2));
            drop(v911_2);
            let v911_10: Space = if map_kernels::has_head(&(v911_9)) { singleton(&[]) } else { Space::new() };
            drop(v911_9);
            let v911_12: Space = if (&(v911_10)).is_empty() { Space::new() } else {
              let v913_6: Path = concat_path(&(v910_6),&v902_20_cursor.path()[(v902_20_origin + 2)..(v902_20_origin + 3)]);
              let v913_11: Space = routine_12(c, &(v913_6), &v902_20_cursor);
              drop(v913_6);
              map_map_kernels::compose(&(v911_10),&(v913_11))
            };
            drop(v911_10);
            let v911_13: Space = map_map_kernels::unite(&(v911_8),&(v911_12));
            join_wrapped_into(&mut v910_11_write,&((v911_13).read_zipper()),&[]);
            }
            v902_20_cursor.ascend(1);
          }
          drop(v910_11_write);
          drop(v910_6);
          map_map_kernels::compose(&(v905_10),&(v910_11))
        };
        drop(v905_10);
        let v905_13: Space = map_map_kernels::unite(&(v905_8),&(v905_12));
        join_wrapped_into(&mut v904_7_write,&((v905_13).read_zipper()),&[]);
        }
        v902_20_cursor.ascend(1);
      }
      drop(v904_7_write);
      map_map_kernels::compose(&(v903_5),&(v904_7))
    };
    drop(v903_5);
    let v903_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v903_2));
    drop(v903_2);
    let v903_10: Space = if map_kernels::has_head(&(v903_9)) { singleton(&[]) } else { Space::new() };
    drop(v903_9);
    let v903_12: Space = if (&(v903_10)).is_empty() { Space::new() } else {
      let v914_6: Path = concat_path(&(*p0),&v902_20_cursor.path()[v902_20_origin..(v902_20_origin + 1)]);
      let mut v914_11 = Space::new();
      let mut v914_11_write = v914_11.write_zipper();
      for v914_11_byte in v902_20_cursor.child_mask().iter() {
        v902_20_cursor.descend_to_existing_byte(v914_11_byte);
        {
        let v915_2: Space = singleton(&v902_20_cursor.path()[(v902_20_origin + 1)..(v902_20_origin + 2)]);
        let v915_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v915_2));
        let v915_4: Space = if map_kernels::has_head(&(v915_3)) { singleton(&[]) } else { Space::new() };
        drop(v915_3);
        let v915_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v915_4));
        drop(v915_4);
        let v915_8: Space = if (&(v915_5)).is_empty() { Space::new() } else {
          let v916_6: Path = concat_path(&(v914_6),&v902_20_cursor.path()[(v902_20_origin + 1)..(v902_20_origin + 2)]);
          let mut v916_7 = Space::new();
          let mut v916_7_write = v916_7.write_zipper();
          for v916_7_byte in v902_20_cursor.child_mask().iter() {
            v902_20_cursor.descend_to_existing_byte(v916_7_byte);
            {
            let v917_2: Space = singleton(&v902_20_cursor.path()[(v902_20_origin + 2)..(v902_20_origin + 3)]);
            let v917_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v917_2));
            let v917_4: Space = if map_kernels::has_head(&(v917_3)) { singleton(&[]) } else { Space::new() };
            drop(v917_3);
            let v917_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v917_4));
            drop(v917_4);
            let v917_8: Space = if (&(v917_5)).is_empty() { Space::new() } else {
              let v918_6: Path = concat_path(&(v916_6),&v902_20_cursor.path()[(v902_20_origin + 2)..(v902_20_origin + 3)]);
              let v918_7: Space = routine_66(c, &(v918_6), &v902_20_cursor);
              map_map_kernels::compose(&(v917_5),&(v918_7))
            };
            drop(v917_5);
            let v917_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v917_2));
            drop(v917_2);
            let v917_10: Space = if map_kernels::has_head(&(v917_9)) { singleton(&[]) } else { Space::new() };
            drop(v917_9);
            let v917_12: Space = if (&(v917_10)).is_empty() { Space::new() } else {
              let v919_6: Path = concat_path(&(v916_6),&v902_20_cursor.path()[(v902_20_origin + 2)..(v902_20_origin + 3)]);
              let v919_11: Space = routine_67(c, &(v919_6), &v902_20_cursor);
              drop(v919_6);
              map_map_kernels::compose(&(v917_10),&(v919_11))
            };
            drop(v917_10);
            let v917_13: Space = map_map_kernels::unite(&(v917_8),&(v917_12));
            join_wrapped_into(&mut v916_7_write,&((v917_13).read_zipper()),&[]);
            }
            v902_20_cursor.ascend(1);
          }
          drop(v916_7_write);
          drop(v916_6);
          map_map_kernels::compose(&(v915_5),&(v916_7))
        };
        drop(v915_5);
        let v915_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v915_2));
        drop(v915_2);
        let v915_10: Space = if map_kernels::has_head(&(v915_9)) { singleton(&[]) } else { Space::new() };
        drop(v915_9);
        let v915_11: Space = map_view_kernels::compose(&(v915_10),&v902_20_cursor);
        drop(v915_10);
        let v915_12: Space = map_map_kernels::unite(&(v915_8),&(v915_11));
        drop(v915_11);
        join_wrapped_into(&mut v914_11_write,&((v915_12).read_zipper()),&[]);
        }
        v902_20_cursor.ascend(1);
      }
      drop(v914_11_write);
      drop(v914_6);
      map_map_kernels::compose(&(v903_10),&(v914_11))
    };
    drop(v903_10);
    let v903_13: Space = map_map_kernels::unite(&(v903_8),&(v903_12));
    join_wrapped_into(&mut v902_20_write,&((v903_13).read_zipper()),&[]);
    }
    v902_20_cursor.ascend(1);
  }
  drop(v902_20_cursor);
  drop(v902_20_write);
  (v902_20).clone()
}

fn routine_55(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v920_14 = Space::new();
  let mut v920_14_write = v920_14.write_zipper();
  let mut v920_14_cursor = (*s0).read_zipper();
  let v920_14_origin = v920_14_cursor.path().len();
  for v920_14_byte in v920_14_cursor.child_mask().iter() {
    v920_14_cursor.descend_to_existing_byte(v920_14_byte);
    {
    let v921_2: Space = singleton(&v920_14_cursor.path()[v920_14_origin..(v920_14_origin + 1)]);
    let v921_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v921_2));
    let v921_4: Space = if map_kernels::has_head(&(v921_3)) { singleton(&[]) } else { Space::new() };
    drop(v921_3);
    let v921_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v921_4));
    drop(v921_4);
    let v921_8: Space = if (&(v921_5)).is_empty() { Space::new() } else {
      let v922_6: Path = concat_path(&(*p0),&v920_14_cursor.path()[v920_14_origin..(v920_14_origin + 1)]);
      let mut v922_7 = Space::new();
      let mut v922_7_write = v922_7.write_zipper();
      for v922_7_byte in v920_14_cursor.child_mask().iter() {
        v920_14_cursor.descend_to_existing_byte(v922_7_byte);
        {
        let v923_2: Space = singleton(&v920_14_cursor.path()[(v920_14_origin + 1)..(v920_14_origin + 2)]);
        let v923_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v923_2));
        let v923_4: Space = if map_kernels::has_head(&(v923_3)) { singleton(&[]) } else { Space::new() };
        drop(v923_3);
        let v923_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v923_4));
        drop(v923_4);
        let v923_8: Space = if (&(v923_5)).is_empty() { Space::new() } else {
          let v924_6: Path = concat_path(&(v922_6),&v920_14_cursor.path()[(v920_14_origin + 1)..(v920_14_origin + 2)]);
          let mut v924_7 = Space::new();
          let mut v924_7_write = v924_7.write_zipper();
          for v924_7_byte in v920_14_cursor.child_mask().iter() {
            v920_14_cursor.descend_to_existing_byte(v924_7_byte);
            {
            let v925_2: Space = singleton(&v920_14_cursor.path()[(v920_14_origin + 2)..(v920_14_origin + 3)]);
            let v925_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v925_2));
            let v925_4: Space = if map_kernels::has_head(&(v925_3)) { singleton(&[]) } else { Space::new() };
            drop(v925_3);
            let v925_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v925_4));
            drop(v925_4);
            let v925_8: Space = if (&(v925_5)).is_empty() { Space::new() } else {
              let v926_6: Path = concat_path(&(v924_6),&v920_14_cursor.path()[(v920_14_origin + 2)..(v920_14_origin + 3)]);
              let v926_7: Space = routine_66(c, &(v926_6), &v920_14_cursor);
              map_map_kernels::compose(&(v925_5),&(v926_7))
            };
            drop(v925_5);
            let v925_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v925_2));
            drop(v925_2);
            let v925_10: Space = if map_kernels::has_head(&(v925_9)) { singleton(&[]) } else { Space::new() };
            drop(v925_9);
            let v925_12: Space = if (&(v925_10)).is_empty() { Space::new() } else {
              let v927_6: Path = concat_path(&(v924_6),&v920_14_cursor.path()[(v920_14_origin + 2)..(v920_14_origin + 3)]);
              let v927_11: Space = routine_67(c, &(v927_6), &v920_14_cursor);
              drop(v927_6);
              map_map_kernels::compose(&(v925_10),&(v927_11))
            };
            drop(v925_10);
            let v925_13: Space = map_map_kernels::unite(&(v925_8),&(v925_12));
            join_wrapped_into(&mut v924_7_write,&((v925_13).read_zipper()),&[]);
            }
            v920_14_cursor.ascend(1);
          }
          drop(v924_7_write);
          map_map_kernels::compose(&(v923_5),&(v924_7))
        };
        drop(v923_5);
        let v923_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v923_2));
        drop(v923_2);
        let v923_10: Space = if map_kernels::has_head(&(v923_9)) { singleton(&[]) } else { Space::new() };
        drop(v923_9);
        let v923_12: Space = if (&(v923_10)).is_empty() { Space::new() } else {
          let v928_6: Path = concat_path(&(v922_6),&v920_14_cursor.path()[(v920_14_origin + 1)..(v920_14_origin + 2)]);
          let mut v928_11 = Space::new();
          let mut v928_11_write = v928_11.write_zipper();
          for v928_11_byte in v920_14_cursor.child_mask().iter() {
            v920_14_cursor.descend_to_existing_byte(v928_11_byte);
            {
            let v929_2: Space = singleton(&v920_14_cursor.path()[(v920_14_origin + 2)..(v920_14_origin + 3)]);
            let v929_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v929_2));
            let v929_4: Space = if map_kernels::has_head(&(v929_3)) { singleton(&[]) } else { Space::new() };
            drop(v929_3);
            let v929_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v929_4));
            drop(v929_4);
            let v929_8: Space = if (&(v929_5)).is_empty() { Space::new() } else {
              let v930_6: Path = concat_path(&(v928_6),&v920_14_cursor.path()[(v920_14_origin + 2)..(v920_14_origin + 3)]);
              let v930_7: Space = routine_66(c, &(v930_6), &v920_14_cursor);
              map_map_kernels::compose(&(v929_5),&(v930_7))
            };
            drop(v929_5);
            let v929_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v929_2));
            drop(v929_2);
            let v929_10: Space = if map_kernels::has_head(&(v929_9)) { singleton(&[]) } else { Space::new() };
            drop(v929_9);
            let v929_12: Space = if (&(v929_10)).is_empty() { Space::new() } else {
              let v931_6: Path = concat_path(&(v928_6),&v920_14_cursor.path()[(v920_14_origin + 2)..(v920_14_origin + 3)]);
              let v931_11: Space = routine_12(c, &(v931_6), &v920_14_cursor);
              drop(v931_6);
              map_map_kernels::compose(&(v929_10),&(v931_11))
            };
            drop(v929_10);
            let v929_13: Space = map_map_kernels::unite(&(v929_8),&(v929_12));
            join_wrapped_into(&mut v928_11_write,&((v929_13).read_zipper()),&[]);
            }
            v920_14_cursor.ascend(1);
          }
          drop(v928_11_write);
          drop(v928_6);
          map_map_kernels::compose(&(v923_10),&(v928_11))
        };
        drop(v923_10);
        let v923_13: Space = map_map_kernels::unite(&(v923_8),&(v923_12));
        join_wrapped_into(&mut v922_7_write,&((v923_13).read_zipper()),&[]);
        }
        v920_14_cursor.ascend(1);
      }
      drop(v922_7_write);
      drop(v922_6);
      map_map_kernels::compose(&(v921_5),&(v922_7))
    };
    drop(v921_5);
    let v921_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v921_2));
    drop(v921_2);
    let v921_10: Space = if map_kernels::has_head(&(v921_9)) { singleton(&[]) } else { Space::new() };
    drop(v921_9);
    let v921_11: Space = map_view_kernels::compose(&(v921_10),&v920_14_cursor);
    drop(v921_10);
    let v921_12: Space = map_map_kernels::unite(&(v921_8),&(v921_11));
    drop(v921_11);
    join_wrapped_into(&mut v920_14_write,&((v921_12).read_zipper()),&[]);
    }
    v920_14_cursor.ascend(1);
  }
  drop(v920_14_cursor);
  drop(v920_14_write);
  (v920_14).clone()
}

fn routine_56(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v932_20 = Space::new();
  let mut v932_20_write = v932_20.write_zipper();
  let mut v932_20_cursor = (*s0).read_zipper();
  let v932_20_origin = v932_20_cursor.path().len();
  for v932_20_byte in v932_20_cursor.child_mask().iter() {
    v932_20_cursor.descend_to_existing_byte(v932_20_byte);
    {
    let v933_2: Space = singleton(&v932_20_cursor.path()[v932_20_origin..(v932_20_origin + 1)]);
    let v933_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v933_2));
    let v933_4: Space = if map_kernels::has_head(&(v933_3)) { singleton(&[]) } else { Space::new() };
    drop(v933_3);
    let v933_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v933_4));
    drop(v933_4);
    let v933_8: Space = if (&(v933_5)).is_empty() { Space::new() } else {
      let v934_6: Path = concat_path(&(*p0),&v932_20_cursor.path()[v932_20_origin..(v932_20_origin + 1)]);
      let mut v934_7 = Space::new();
      let mut v934_7_write = v934_7.write_zipper();
      for v934_7_byte in v932_20_cursor.child_mask().iter() {
        v932_20_cursor.descend_to_existing_byte(v934_7_byte);
        {
        let v935_2: Space = singleton(&v932_20_cursor.path()[(v932_20_origin + 1)..(v932_20_origin + 2)]);
        let v935_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v935_2));
        let v935_4: Space = if map_kernels::has_head(&(v935_3)) { singleton(&[]) } else { Space::new() };
        drop(v935_3);
        let v935_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v935_4));
        drop(v935_4);
        let v935_8: Space = if (&(v935_5)).is_empty() { Space::new() } else {
          let v936_6: Path = concat_path(&(v934_6),&v932_20_cursor.path()[(v932_20_origin + 1)..(v932_20_origin + 2)]);
          let mut v936_7 = Space::new();
          let mut v936_7_write = v936_7.write_zipper();
          for v936_7_byte in v932_20_cursor.child_mask().iter() {
            v932_20_cursor.descend_to_existing_byte(v936_7_byte);
            {
            let v937_2: Space = singleton(&v932_20_cursor.path()[(v932_20_origin + 2)..(v932_20_origin + 3)]);
            let v937_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v937_2));
            let v937_4: Space = if map_kernels::has_head(&(v937_3)) { singleton(&[]) } else { Space::new() };
            drop(v937_3);
            let v937_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v937_4));
            drop(v937_4);
            let v937_8: Space = if (&(v937_5)).is_empty() { Space::new() } else {
              let v938_6: Path = concat_path(&(v936_6),&v932_20_cursor.path()[(v932_20_origin + 2)..(v932_20_origin + 3)]);
              let v938_7: Space = routine_68(c, &(v938_6), &v932_20_cursor);
              map_map_kernels::compose(&(v937_5),&(v938_7))
            };
            drop(v937_5);
            let v937_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v937_2));
            drop(v937_2);
            let v937_10: Space = if map_kernels::has_head(&(v937_9)) { singleton(&[]) } else { Space::new() };
            drop(v937_9);
            let v937_12: Space = if (&(v937_10)).is_empty() { Space::new() } else {
              let v939_6: Path = concat_path(&(v936_6),&v932_20_cursor.path()[(v932_20_origin + 2)..(v932_20_origin + 3)]);
              let v939_11: Space = routine_69(c, &(v939_6), &v932_20_cursor);
              drop(v939_6);
              map_map_kernels::compose(&(v937_10),&(v939_11))
            };
            drop(v937_10);
            let v937_13: Space = map_map_kernels::unite(&(v937_8),&(v937_12));
            join_wrapped_into(&mut v936_7_write,&((v937_13).read_zipper()),&[]);
            }
            v932_20_cursor.ascend(1);
          }
          drop(v936_7_write);
          map_map_kernels::compose(&(v935_5),&(v936_7))
        };
        drop(v935_5);
        let v935_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v935_2));
        drop(v935_2);
        let v935_10: Space = if map_kernels::has_head(&(v935_9)) { singleton(&[]) } else { Space::new() };
        drop(v935_9);
        let v935_12: Space = if (&(v935_10)).is_empty() { Space::new() } else {
          let v940_6: Path = concat_path(&(v934_6),&v932_20_cursor.path()[(v932_20_origin + 1)..(v932_20_origin + 2)]);
          let mut v940_11 = Space::new();
          let mut v940_11_write = v940_11.write_zipper();
          for v940_11_byte in v932_20_cursor.child_mask().iter() {
            v932_20_cursor.descend_to_existing_byte(v940_11_byte);
            {
            let v941_2: Space = singleton(&v932_20_cursor.path()[(v932_20_origin + 2)..(v932_20_origin + 3)]);
            let v941_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v941_2));
            let v941_4: Space = if map_kernels::has_head(&(v941_3)) { singleton(&[]) } else { Space::new() };
            drop(v941_3);
            let v941_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v941_4));
            drop(v941_4);
            let v941_8: Space = if (&(v941_5)).is_empty() { Space::new() } else {
              let v942_6: Path = concat_path(&(v940_6),&v932_20_cursor.path()[(v932_20_origin + 2)..(v932_20_origin + 3)]);
              let v942_7: Space = routine_68(c, &(v942_6), &v932_20_cursor);
              map_map_kernels::compose(&(v941_5),&(v942_7))
            };
            drop(v941_5);
            let v941_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v941_2));
            drop(v941_2);
            let v941_10: Space = if map_kernels::has_head(&(v941_9)) { singleton(&[]) } else { Space::new() };
            drop(v941_9);
            let v941_12: Space = if (&(v941_10)).is_empty() { Space::new() } else {
              let v943_6: Path = concat_path(&(v940_6),&v932_20_cursor.path()[(v932_20_origin + 2)..(v932_20_origin + 3)]);
              let v943_11: Space = routine_15(c, &(v943_6), &v932_20_cursor);
              drop(v943_6);
              map_map_kernels::compose(&(v941_10),&(v943_11))
            };
            drop(v941_10);
            let v941_13: Space = map_map_kernels::unite(&(v941_8),&(v941_12));
            join_wrapped_into(&mut v940_11_write,&((v941_13).read_zipper()),&[]);
            }
            v932_20_cursor.ascend(1);
          }
          drop(v940_11_write);
          drop(v940_6);
          map_map_kernels::compose(&(v935_10),&(v940_11))
        };
        drop(v935_10);
        let v935_13: Space = map_map_kernels::unite(&(v935_8),&(v935_12));
        join_wrapped_into(&mut v934_7_write,&((v935_13).read_zipper()),&[]);
        }
        v932_20_cursor.ascend(1);
      }
      drop(v934_7_write);
      map_map_kernels::compose(&(v933_5),&(v934_7))
    };
    drop(v933_5);
    let v933_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v933_2));
    drop(v933_2);
    let v933_10: Space = if map_kernels::has_head(&(v933_9)) { singleton(&[]) } else { Space::new() };
    drop(v933_9);
    let v933_12: Space = if (&(v933_10)).is_empty() { Space::new() } else {
      let v944_6: Path = concat_path(&(*p0),&v932_20_cursor.path()[v932_20_origin..(v932_20_origin + 1)]);
      let mut v944_11 = Space::new();
      let mut v944_11_write = v944_11.write_zipper();
      for v944_11_byte in v932_20_cursor.child_mask().iter() {
        v932_20_cursor.descend_to_existing_byte(v944_11_byte);
        {
        let v945_2: Space = singleton(&v932_20_cursor.path()[(v932_20_origin + 1)..(v932_20_origin + 2)]);
        let v945_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v945_2));
        let v945_4: Space = if map_kernels::has_head(&(v945_3)) { singleton(&[]) } else { Space::new() };
        drop(v945_3);
        let v945_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v945_4));
        drop(v945_4);
        let v945_8: Space = if (&(v945_5)).is_empty() { Space::new() } else {
          let v946_6: Path = concat_path(&(v944_6),&v932_20_cursor.path()[(v932_20_origin + 1)..(v932_20_origin + 2)]);
          let mut v946_7 = Space::new();
          let mut v946_7_write = v946_7.write_zipper();
          for v946_7_byte in v932_20_cursor.child_mask().iter() {
            v932_20_cursor.descend_to_existing_byte(v946_7_byte);
            {
            let v947_2: Space = singleton(&v932_20_cursor.path()[(v932_20_origin + 2)..(v932_20_origin + 3)]);
            let v947_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v947_2));
            let v947_4: Space = if map_kernels::has_head(&(v947_3)) { singleton(&[]) } else { Space::new() };
            drop(v947_3);
            let v947_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v947_4));
            drop(v947_4);
            let v947_8: Space = if (&(v947_5)).is_empty() { Space::new() } else {
              let v948_6: Path = concat_path(&(v946_6),&v932_20_cursor.path()[(v932_20_origin + 2)..(v932_20_origin + 3)]);
              let v948_7: Space = routine_68(c, &(v948_6), &v932_20_cursor);
              map_map_kernels::compose(&(v947_5),&(v948_7))
            };
            drop(v947_5);
            let v947_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v947_2));
            drop(v947_2);
            let v947_10: Space = if map_kernels::has_head(&(v947_9)) { singleton(&[]) } else { Space::new() };
            drop(v947_9);
            let v947_12: Space = if (&(v947_10)).is_empty() { Space::new() } else {
              let v949_6: Path = concat_path(&(v946_6),&v932_20_cursor.path()[(v932_20_origin + 2)..(v932_20_origin + 3)]);
              let v949_11: Space = routine_69(c, &(v949_6), &v932_20_cursor);
              drop(v949_6);
              map_map_kernels::compose(&(v947_10),&(v949_11))
            };
            drop(v947_10);
            let v947_13: Space = map_map_kernels::unite(&(v947_8),&(v947_12));
            join_wrapped_into(&mut v946_7_write,&((v947_13).read_zipper()),&[]);
            }
            v932_20_cursor.ascend(1);
          }
          drop(v946_7_write);
          drop(v946_6);
          map_map_kernels::compose(&(v945_5),&(v946_7))
        };
        drop(v945_5);
        let v945_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v945_2));
        drop(v945_2);
        let v945_10: Space = if map_kernels::has_head(&(v945_9)) { singleton(&[]) } else { Space::new() };
        drop(v945_9);
        let v945_11: Space = map_view_kernels::compose(&(v945_10),&v932_20_cursor);
        drop(v945_10);
        let v945_12: Space = map_map_kernels::unite(&(v945_8),&(v945_11));
        drop(v945_11);
        join_wrapped_into(&mut v944_11_write,&((v945_12).read_zipper()),&[]);
        }
        v932_20_cursor.ascend(1);
      }
      drop(v944_11_write);
      drop(v944_6);
      map_map_kernels::compose(&(v933_10),&(v944_11))
    };
    drop(v933_10);
    let v933_13: Space = map_map_kernels::unite(&(v933_8),&(v933_12));
    join_wrapped_into(&mut v932_20_write,&((v933_13).read_zipper()),&[]);
    }
    v932_20_cursor.ascend(1);
  }
  drop(v932_20_cursor);
  drop(v932_20_write);
  (v932_20).clone()
}

fn routine_57(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v950_14 = Space::new();
  let mut v950_14_write = v950_14.write_zipper();
  let mut v950_14_cursor = (*s0).read_zipper();
  let v950_14_origin = v950_14_cursor.path().len();
  for v950_14_byte in v950_14_cursor.child_mask().iter() {
    v950_14_cursor.descend_to_existing_byte(v950_14_byte);
    {
    let v951_2: Space = singleton(&v950_14_cursor.path()[v950_14_origin..(v950_14_origin + 1)]);
    let v951_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v951_2));
    let v951_4: Space = if map_kernels::has_head(&(v951_3)) { singleton(&[]) } else { Space::new() };
    drop(v951_3);
    let v951_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v951_4));
    drop(v951_4);
    let v951_8: Space = if (&(v951_5)).is_empty() { Space::new() } else {
      let v952_6: Path = concat_path(&(*p0),&v950_14_cursor.path()[v950_14_origin..(v950_14_origin + 1)]);
      let mut v952_7 = Space::new();
      let mut v952_7_write = v952_7.write_zipper();
      for v952_7_byte in v950_14_cursor.child_mask().iter() {
        v950_14_cursor.descend_to_existing_byte(v952_7_byte);
        {
        let v953_2: Space = singleton(&v950_14_cursor.path()[(v950_14_origin + 1)..(v950_14_origin + 2)]);
        let v953_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v953_2));
        let v953_4: Space = if map_kernels::has_head(&(v953_3)) { singleton(&[]) } else { Space::new() };
        drop(v953_3);
        let v953_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v953_4));
        drop(v953_4);
        let v953_8: Space = if (&(v953_5)).is_empty() { Space::new() } else {
          let v954_6: Path = concat_path(&(v952_6),&v950_14_cursor.path()[(v950_14_origin + 1)..(v950_14_origin + 2)]);
          let mut v954_7 = Space::new();
          let mut v954_7_write = v954_7.write_zipper();
          for v954_7_byte in v950_14_cursor.child_mask().iter() {
            v950_14_cursor.descend_to_existing_byte(v954_7_byte);
            {
            let v955_2: Space = singleton(&v950_14_cursor.path()[(v950_14_origin + 2)..(v950_14_origin + 3)]);
            let v955_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v955_2));
            let v955_4: Space = if map_kernels::has_head(&(v955_3)) { singleton(&[]) } else { Space::new() };
            drop(v955_3);
            let v955_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v955_4));
            drop(v955_4);
            let v955_8: Space = if (&(v955_5)).is_empty() { Space::new() } else {
              let v956_6: Path = concat_path(&(v954_6),&v950_14_cursor.path()[(v950_14_origin + 2)..(v950_14_origin + 3)]);
              let v956_7: Space = routine_68(c, &(v956_6), &v950_14_cursor);
              map_map_kernels::compose(&(v955_5),&(v956_7))
            };
            drop(v955_5);
            let v955_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v955_2));
            drop(v955_2);
            let v955_10: Space = if map_kernels::has_head(&(v955_9)) { singleton(&[]) } else { Space::new() };
            drop(v955_9);
            let v955_12: Space = if (&(v955_10)).is_empty() { Space::new() } else {
              let v957_6: Path = concat_path(&(v954_6),&v950_14_cursor.path()[(v950_14_origin + 2)..(v950_14_origin + 3)]);
              let v957_11: Space = routine_69(c, &(v957_6), &v950_14_cursor);
              drop(v957_6);
              map_map_kernels::compose(&(v955_10),&(v957_11))
            };
            drop(v955_10);
            let v955_13: Space = map_map_kernels::unite(&(v955_8),&(v955_12));
            join_wrapped_into(&mut v954_7_write,&((v955_13).read_zipper()),&[]);
            }
            v950_14_cursor.ascend(1);
          }
          drop(v954_7_write);
          map_map_kernels::compose(&(v953_5),&(v954_7))
        };
        drop(v953_5);
        let v953_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v953_2));
        drop(v953_2);
        let v953_10: Space = if map_kernels::has_head(&(v953_9)) { singleton(&[]) } else { Space::new() };
        drop(v953_9);
        let v953_12: Space = if (&(v953_10)).is_empty() { Space::new() } else {
          let v958_6: Path = concat_path(&(v952_6),&v950_14_cursor.path()[(v950_14_origin + 1)..(v950_14_origin + 2)]);
          let mut v958_11 = Space::new();
          let mut v958_11_write = v958_11.write_zipper();
          for v958_11_byte in v950_14_cursor.child_mask().iter() {
            v950_14_cursor.descend_to_existing_byte(v958_11_byte);
            {
            let v959_2: Space = singleton(&v950_14_cursor.path()[(v950_14_origin + 2)..(v950_14_origin + 3)]);
            let v959_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v959_2));
            let v959_4: Space = if map_kernels::has_head(&(v959_3)) { singleton(&[]) } else { Space::new() };
            drop(v959_3);
            let v959_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v959_4));
            drop(v959_4);
            let v959_8: Space = if (&(v959_5)).is_empty() { Space::new() } else {
              let v960_6: Path = concat_path(&(v958_6),&v950_14_cursor.path()[(v950_14_origin + 2)..(v950_14_origin + 3)]);
              let v960_7: Space = routine_68(c, &(v960_6), &v950_14_cursor);
              map_map_kernels::compose(&(v959_5),&(v960_7))
            };
            drop(v959_5);
            let v959_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v959_2));
            drop(v959_2);
            let v959_10: Space = if map_kernels::has_head(&(v959_9)) { singleton(&[]) } else { Space::new() };
            drop(v959_9);
            let v959_12: Space = if (&(v959_10)).is_empty() { Space::new() } else {
              let v961_6: Path = concat_path(&(v958_6),&v950_14_cursor.path()[(v950_14_origin + 2)..(v950_14_origin + 3)]);
              let v961_11: Space = routine_15(c, &(v961_6), &v950_14_cursor);
              drop(v961_6);
              map_map_kernels::compose(&(v959_10),&(v961_11))
            };
            drop(v959_10);
            let v959_13: Space = map_map_kernels::unite(&(v959_8),&(v959_12));
            join_wrapped_into(&mut v958_11_write,&((v959_13).read_zipper()),&[]);
            }
            v950_14_cursor.ascend(1);
          }
          drop(v958_11_write);
          drop(v958_6);
          map_map_kernels::compose(&(v953_10),&(v958_11))
        };
        drop(v953_10);
        let v953_13: Space = map_map_kernels::unite(&(v953_8),&(v953_12));
        join_wrapped_into(&mut v952_7_write,&((v953_13).read_zipper()),&[]);
        }
        v950_14_cursor.ascend(1);
      }
      drop(v952_7_write);
      drop(v952_6);
      map_map_kernels::compose(&(v951_5),&(v952_7))
    };
    drop(v951_5);
    let v951_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v951_2));
    drop(v951_2);
    let v951_10: Space = if map_kernels::has_head(&(v951_9)) { singleton(&[]) } else { Space::new() };
    drop(v951_9);
    let v951_11: Space = map_view_kernels::compose(&(v951_10),&v950_14_cursor);
    drop(v951_10);
    let v951_12: Space = map_map_kernels::unite(&(v951_8),&(v951_11));
    drop(v951_11);
    join_wrapped_into(&mut v950_14_write,&((v951_12).read_zipper()),&[]);
    }
    v950_14_cursor.ascend(1);
  }
  drop(v950_14_cursor);
  drop(v950_14_write);
  (v950_14).clone()
}

fn routine_58(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v962_12 = Space::new();
  let mut v962_12_write = v962_12.write_zipper();
  let mut v962_12_cursor = (*s0).read_zipper();
  let v962_12_origin = v962_12_cursor.path().len();
  for v962_12_byte in v962_12_cursor.child_mask().iter() {
    v962_12_cursor.descend_to_existing_byte(v962_12_byte);
    {
    let v963_2: Space = singleton(&v962_12_cursor.path()[v962_12_origin..(v962_12_origin + 1)]);
    let v963_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v963_2));
    let v963_4: Space = if map_kernels::has_head(&(v963_3)) { singleton(&[]) } else { Space::new() };
    drop(v963_3);
    let v963_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v963_4));
    drop(v963_4);
    let v963_8: Space = if (&(v963_5)).is_empty() { Space::new() } else {
      let v964_6: Path = concat_path(&(*p0),&v962_12_cursor.path()[v962_12_origin..(v962_12_origin + 1)]);
      let mut v964_7 = Space::new();
      let mut v964_7_write = v964_7.write_zipper();
      for v964_7_byte in v962_12_cursor.child_mask().iter() {
        v962_12_cursor.descend_to_existing_byte(v964_7_byte);
        {
        let v965_2: Space = singleton(&v962_12_cursor.path()[(v962_12_origin + 1)..(v962_12_origin + 2)]);
        let v965_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v965_2));
        let v965_4: Space = if map_kernels::has_head(&(v965_3)) { singleton(&[]) } else { Space::new() };
        drop(v965_3);
        let v965_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v965_4));
        drop(v965_4);
        let v965_7: Space = if (&(v965_5)).is_empty() { Space::new() } else {
          let mut v966_6 = Space::new();
          let mut v966_6_write = v966_6.write_zipper();
          for v966_6_byte in v962_12_cursor.child_mask().iter() {
            v962_12_cursor.descend_to_existing_byte(v966_6_byte);
            {
            let v967_2: Space = Space::new();
            join_wrapped_into(&mut v966_6_write,&((v967_2).read_zipper()),&[]);
            }
            v962_12_cursor.ascend(1);
          }
          drop(v966_6_write);
          map_map_kernels::compose(&(v965_5),&(v966_6))
        };
        drop(v965_5);
        let v965_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v965_2));
        drop(v965_2);
        let v965_9: Space = if map_kernels::has_head(&(v965_8)) { singleton(&[]) } else { Space::new() };
        drop(v965_8);
        let v965_12: Space = if (&(v965_9)).is_empty() { Space::new() } else {
          let v968_10: Path = concat_path(&(v964_6),&v962_12_cursor.path()[(v962_12_origin + 1)..(v962_12_origin + 2)]);
          let mut v968_11 = Space::new();
          let mut v968_11_write = v968_11.write_zipper();
          for v968_11_byte in v962_12_cursor.child_mask().iter() {
            v962_12_cursor.descend_to_existing_byte(v968_11_byte);
            {
            let v969_2: Space = singleton(&v962_12_cursor.path()[(v962_12_origin + 2)..(v962_12_origin + 3)]);
            let v969_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v969_2));
            drop(v969_2);
            let v969_4: Space = if map_kernels::has_head(&(v969_3)) { singleton(&[]) } else { Space::new() };
            drop(v969_3);
            let v969_7: Space = if (&(v969_4)).is_empty() { Space::new() } else {
              let v970_5: Path = concat_path(&(v968_10),&v962_12_cursor.path()[(v962_12_origin + 2)..(v962_12_origin + 3)]);
              let v970_6: Space = routine_12(c, &(v970_5), &v962_12_cursor);
              drop(v970_5);
              map_map_kernels::compose(&(v969_4),&(v970_6))
            };
            drop(v969_4);
            join_wrapped_into(&mut v968_11_write,&((v969_7).read_zipper()),&[]);
            }
            v962_12_cursor.ascend(1);
          }
          drop(v968_11_write);
          drop(v968_10);
          map_map_kernels::compose(&(v965_9),&(v968_11))
        };
        drop(v965_9);
        let v965_13: Space = map_map_kernels::unite(&(v965_7),&(v965_12));
        drop(v965_7);
        join_wrapped_into(&mut v964_7_write,&((v965_13).read_zipper()),&[]);
        }
        v962_12_cursor.ascend(1);
      }
      drop(v964_7_write);
      drop(v964_6);
      map_map_kernels::compose(&(v963_5),&(v964_7))
    };
    drop(v963_5);
    let v963_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v963_2));
    drop(v963_2);
    let v963_10: Space = if map_kernels::has_head(&(v963_9)) { singleton(&[]) } else { Space::new() };
    drop(v963_9);
    let v963_12: Space = if (&(v963_10)).is_empty() { Space::new() } else {
      let mut v971_11 = Space::new();
      let mut v971_11_write = v971_11.write_zipper();
      for v971_11_byte in v962_12_cursor.child_mask().iter() {
        v962_12_cursor.descend_to_existing_byte(v971_11_byte);
        {
        let v972_2: Space = singleton(&v962_12_cursor.path()[(v962_12_origin + 1)..(v962_12_origin + 2)]);
        let v972_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v972_2));
        let v972_4: Space = if map_kernels::has_head(&(v972_3)) { singleton(&[]) } else { Space::new() };
        drop(v972_3);
        let v972_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v972_4));
        drop(v972_4);
        let v972_7: Space = if (&(v972_5)).is_empty() { Space::new() } else {
          let mut v973_6 = Space::new();
          let mut v973_6_write = v973_6.write_zipper();
          for v973_6_byte in v962_12_cursor.child_mask().iter() {
            v962_12_cursor.descend_to_existing_byte(v973_6_byte);
            {
            let v974_2: Space = Space::new();
            join_wrapped_into(&mut v973_6_write,&((v974_2).read_zipper()),&[]);
            }
            v962_12_cursor.ascend(1);
          }
          drop(v973_6_write);
          map_map_kernels::compose(&(v972_5),&(v973_6))
        };
        drop(v972_5);
        let v972_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v972_2));
        drop(v972_2);
        let v972_9: Space = if map_kernels::has_head(&(v972_8)) { singleton(&[]) } else { Space::new() };
        drop(v972_8);
        let v972_10: Space = map_view_kernels::compose(&(v972_9),&v962_12_cursor);
        drop(v972_9);
        let v972_11: Space = map_map_kernels::unite(&(v972_7),&(v972_10));
        drop(v972_7);
        drop(v972_10);
        join_wrapped_into(&mut v971_11_write,&((v972_11).read_zipper()),&[]);
        }
        v962_12_cursor.ascend(1);
      }
      drop(v971_11_write);
      map_map_kernels::compose(&(v963_10),&(v971_11))
    };
    drop(v963_10);
    let v963_13: Space = map_map_kernels::unite(&(v963_8),&(v963_12));
    drop(v963_12);
    join_wrapped_into(&mut v962_12_write,&((v963_13).read_zipper()),&[]);
    }
    v962_12_cursor.ascend(1);
  }
  drop(v962_12_cursor);
  drop(v962_12_write);
  (v962_12).clone()
}

fn routine_59(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v975_9 = Space::new();
  let mut v975_9_write = v975_9.write_zipper();
  let mut v975_9_cursor = (*s0).read_zipper();
  let v975_9_origin = v975_9_cursor.path().len();
  for v975_9_byte in v975_9_cursor.child_mask().iter() {
    v975_9_cursor.descend_to_existing_byte(v975_9_byte);
    {
    let v976_2: Space = singleton(&v975_9_cursor.path()[v975_9_origin..(v975_9_origin + 1)]);
    let v976_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v976_2));
    let v976_4: Space = if map_kernels::has_head(&(v976_3)) { singleton(&[]) } else { Space::new() };
    drop(v976_3);
    let v976_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v976_4));
    drop(v976_4);
    let v976_8: Space = if (&(v976_5)).is_empty() { Space::new() } else {
      let v977_6: Path = concat_path(&(*p0),&v975_9_cursor.path()[v975_9_origin..(v975_9_origin + 1)]);
      let mut v977_7 = Space::new();
      let mut v977_7_write = v977_7.write_zipper();
      for v977_7_byte in v975_9_cursor.child_mask().iter() {
        v975_9_cursor.descend_to_existing_byte(v977_7_byte);
        {
        let v978_2: Space = singleton(&v975_9_cursor.path()[(v975_9_origin + 1)..(v975_9_origin + 2)]);
        let v978_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v978_2));
        let v978_4: Space = if map_kernels::has_head(&(v978_3)) { singleton(&[]) } else { Space::new() };
        drop(v978_3);
        let v978_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v978_4));
        drop(v978_4);
        let v978_7: Space = if (&(v978_5)).is_empty() { Space::new() } else {
          let mut v979_6 = Space::new();
          let mut v979_6_write = v979_6.write_zipper();
          for v979_6_byte in v975_9_cursor.child_mask().iter() {
            v975_9_cursor.descend_to_existing_byte(v979_6_byte);
            {
            let v980_2: Space = Space::new();
            join_wrapped_into(&mut v979_6_write,&((v980_2).read_zipper()),&[]);
            }
            v975_9_cursor.ascend(1);
          }
          drop(v979_6_write);
          map_map_kernels::compose(&(v978_5),&(v979_6))
        };
        drop(v978_5);
        let v978_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v978_2));
        drop(v978_2);
        let v978_9: Space = if map_kernels::has_head(&(v978_8)) { singleton(&[]) } else { Space::new() };
        drop(v978_8);
        let v978_12: Space = if (&(v978_9)).is_empty() { Space::new() } else {
          let v981_10: Path = concat_path(&(v977_6),&v975_9_cursor.path()[(v975_9_origin + 1)..(v975_9_origin + 2)]);
          let mut v981_11 = Space::new();
          let mut v981_11_write = v981_11.write_zipper();
          for v981_11_byte in v975_9_cursor.child_mask().iter() {
            v975_9_cursor.descend_to_existing_byte(v981_11_byte);
            {
            let v982_2: Space = singleton(&v975_9_cursor.path()[(v975_9_origin + 2)..(v975_9_origin + 3)]);
            let v982_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v982_2));
            drop(v982_2);
            let v982_4: Space = if map_kernels::has_head(&(v982_3)) { singleton(&[]) } else { Space::new() };
            drop(v982_3);
            let v982_7: Space = if (&(v982_4)).is_empty() { Space::new() } else {
              let v983_5: Path = concat_path(&(v981_10),&v975_9_cursor.path()[(v975_9_origin + 2)..(v975_9_origin + 3)]);
              let v983_6: Space = routine_12(c, &(v983_5), &v975_9_cursor);
              drop(v983_5);
              map_map_kernels::compose(&(v982_4),&(v983_6))
            };
            drop(v982_4);
            join_wrapped_into(&mut v981_11_write,&((v982_7).read_zipper()),&[]);
            }
            v975_9_cursor.ascend(1);
          }
          drop(v981_11_write);
          drop(v981_10);
          map_map_kernels::compose(&(v978_9),&(v981_11))
        };
        drop(v978_9);
        let v978_13: Space = map_map_kernels::unite(&(v978_7),&(v978_12));
        drop(v978_7);
        join_wrapped_into(&mut v977_7_write,&((v978_13).read_zipper()),&[]);
        }
        v975_9_cursor.ascend(1);
      }
      drop(v977_7_write);
      drop(v977_6);
      map_map_kernels::compose(&(v976_5),&(v977_7))
    };
    drop(v976_5);
    let v976_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v976_2));
    drop(v976_2);
    let v976_10: Space = if map_kernels::has_head(&(v976_9)) { singleton(&[]) } else { Space::new() };
    drop(v976_9);
    let v976_11: Space = map_view_kernels::compose(&(v976_10),&v975_9_cursor);
    drop(v976_10);
    let v976_12: Space = map_map_kernels::unite(&(v976_8),&(v976_11));
    drop(v976_11);
    join_wrapped_into(&mut v975_9_write,&((v976_12).read_zipper()),&[]);
    }
    v975_9_cursor.ascend(1);
  }
  drop(v975_9_cursor);
  drop(v975_9_write);
  (v975_9).clone()
}

fn routine_60(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v984_12 = Space::new();
  let mut v984_12_write = v984_12.write_zipper();
  let mut v984_12_cursor = (*s0).read_zipper();
  let v984_12_origin = v984_12_cursor.path().len();
  for v984_12_byte in v984_12_cursor.child_mask().iter() {
    v984_12_cursor.descend_to_existing_byte(v984_12_byte);
    {
    let v985_2: Space = singleton(&v984_12_cursor.path()[v984_12_origin..(v984_12_origin + 1)]);
    let v985_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v985_2));
    let v985_4: Space = if map_kernels::has_head(&(v985_3)) { singleton(&[]) } else { Space::new() };
    drop(v985_3);
    let v985_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v985_4));
    drop(v985_4);
    let v985_8: Space = if (&(v985_5)).is_empty() { Space::new() } else {
      let v986_6: Path = concat_path(&(*p0),&v984_12_cursor.path()[v984_12_origin..(v984_12_origin + 1)]);
      let mut v986_7 = Space::new();
      let mut v986_7_write = v986_7.write_zipper();
      for v986_7_byte in v984_12_cursor.child_mask().iter() {
        v984_12_cursor.descend_to_existing_byte(v986_7_byte);
        {
        let v987_2: Space = singleton(&v984_12_cursor.path()[(v984_12_origin + 1)..(v984_12_origin + 2)]);
        let v987_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v987_2));
        let v987_4: Space = if map_kernels::has_head(&(v987_3)) { singleton(&[]) } else { Space::new() };
        drop(v987_3);
        let v987_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v987_4));
        drop(v987_4);
        let v987_7: Space = if (&(v987_5)).is_empty() { Space::new() } else {
          let mut v988_6 = Space::new();
          let mut v988_6_write = v988_6.write_zipper();
          for v988_6_byte in v984_12_cursor.child_mask().iter() {
            v984_12_cursor.descend_to_existing_byte(v988_6_byte);
            {
            let v989_2: Space = Space::new();
            join_wrapped_into(&mut v988_6_write,&((v989_2).read_zipper()),&[]);
            }
            v984_12_cursor.ascend(1);
          }
          drop(v988_6_write);
          map_map_kernels::compose(&(v987_5),&(v988_6))
        };
        drop(v987_5);
        let v987_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v987_2));
        drop(v987_2);
        let v987_9: Space = if map_kernels::has_head(&(v987_8)) { singleton(&[]) } else { Space::new() };
        drop(v987_8);
        let v987_12: Space = if (&(v987_9)).is_empty() { Space::new() } else {
          let v990_10: Path = concat_path(&(v986_6),&v984_12_cursor.path()[(v984_12_origin + 1)..(v984_12_origin + 2)]);
          let mut v990_11 = Space::new();
          let mut v990_11_write = v990_11.write_zipper();
          for v990_11_byte in v984_12_cursor.child_mask().iter() {
            v984_12_cursor.descend_to_existing_byte(v990_11_byte);
            {
            let v991_2: Space = singleton(&v984_12_cursor.path()[(v984_12_origin + 2)..(v984_12_origin + 3)]);
            let v991_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v991_2));
            drop(v991_2);
            let v991_4: Space = if map_kernels::has_head(&(v991_3)) { singleton(&[]) } else { Space::new() };
            drop(v991_3);
            let v991_7: Space = if (&(v991_4)).is_empty() { Space::new() } else {
              let v992_5: Path = concat_path(&(v990_10),&v984_12_cursor.path()[(v984_12_origin + 2)..(v984_12_origin + 3)]);
              let v992_6: Space = routine_15(c, &(v992_5), &v984_12_cursor);
              drop(v992_5);
              map_map_kernels::compose(&(v991_4),&(v992_6))
            };
            drop(v991_4);
            join_wrapped_into(&mut v990_11_write,&((v991_7).read_zipper()),&[]);
            }
            v984_12_cursor.ascend(1);
          }
          drop(v990_11_write);
          drop(v990_10);
          map_map_kernels::compose(&(v987_9),&(v990_11))
        };
        drop(v987_9);
        let v987_13: Space = map_map_kernels::unite(&(v987_7),&(v987_12));
        drop(v987_7);
        join_wrapped_into(&mut v986_7_write,&((v987_13).read_zipper()),&[]);
        }
        v984_12_cursor.ascend(1);
      }
      drop(v986_7_write);
      drop(v986_6);
      map_map_kernels::compose(&(v985_5),&(v986_7))
    };
    drop(v985_5);
    let v985_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v985_2));
    drop(v985_2);
    let v985_10: Space = if map_kernels::has_head(&(v985_9)) { singleton(&[]) } else { Space::new() };
    drop(v985_9);
    let v985_12: Space = if (&(v985_10)).is_empty() { Space::new() } else {
      let mut v993_11 = Space::new();
      let mut v993_11_write = v993_11.write_zipper();
      for v993_11_byte in v984_12_cursor.child_mask().iter() {
        v984_12_cursor.descend_to_existing_byte(v993_11_byte);
        {
        let v994_2: Space = singleton(&v984_12_cursor.path()[(v984_12_origin + 1)..(v984_12_origin + 2)]);
        let v994_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v994_2));
        let v994_4: Space = if map_kernels::has_head(&(v994_3)) { singleton(&[]) } else { Space::new() };
        drop(v994_3);
        let v994_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v994_4));
        drop(v994_4);
        let v994_7: Space = if (&(v994_5)).is_empty() { Space::new() } else {
          let mut v995_6 = Space::new();
          let mut v995_6_write = v995_6.write_zipper();
          for v995_6_byte in v984_12_cursor.child_mask().iter() {
            v984_12_cursor.descend_to_existing_byte(v995_6_byte);
            {
            let v996_2: Space = Space::new();
            join_wrapped_into(&mut v995_6_write,&((v996_2).read_zipper()),&[]);
            }
            v984_12_cursor.ascend(1);
          }
          drop(v995_6_write);
          map_map_kernels::compose(&(v994_5),&(v995_6))
        };
        drop(v994_5);
        let v994_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v994_2));
        drop(v994_2);
        let v994_9: Space = if map_kernels::has_head(&(v994_8)) { singleton(&[]) } else { Space::new() };
        drop(v994_8);
        let v994_10: Space = map_view_kernels::compose(&(v994_9),&v984_12_cursor);
        drop(v994_9);
        let v994_11: Space = map_map_kernels::unite(&(v994_7),&(v994_10));
        drop(v994_7);
        drop(v994_10);
        join_wrapped_into(&mut v993_11_write,&((v994_11).read_zipper()),&[]);
        }
        v984_12_cursor.ascend(1);
      }
      drop(v993_11_write);
      map_map_kernels::compose(&(v985_10),&(v993_11))
    };
    drop(v985_10);
    let v985_13: Space = map_map_kernels::unite(&(v985_8),&(v985_12));
    drop(v985_12);
    join_wrapped_into(&mut v984_12_write,&((v985_13).read_zipper()),&[]);
    }
    v984_12_cursor.ascend(1);
  }
  drop(v984_12_cursor);
  drop(v984_12_write);
  (v984_12).clone()
}

fn routine_61(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v997_9 = Space::new();
  let mut v997_9_write = v997_9.write_zipper();
  let mut v997_9_cursor = (*s0).read_zipper();
  let v997_9_origin = v997_9_cursor.path().len();
  for v997_9_byte in v997_9_cursor.child_mask().iter() {
    v997_9_cursor.descend_to_existing_byte(v997_9_byte);
    {
    let v998_2: Space = singleton(&v997_9_cursor.path()[v997_9_origin..(v997_9_origin + 1)]);
    let v998_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v998_2));
    let v998_4: Space = if map_kernels::has_head(&(v998_3)) { singleton(&[]) } else { Space::new() };
    drop(v998_3);
    let v998_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v998_4));
    drop(v998_4);
    let v998_8: Space = if (&(v998_5)).is_empty() { Space::new() } else {
      let v999_6: Path = concat_path(&(*p0),&v997_9_cursor.path()[v997_9_origin..(v997_9_origin + 1)]);
      let mut v999_7 = Space::new();
      let mut v999_7_write = v999_7.write_zipper();
      for v999_7_byte in v997_9_cursor.child_mask().iter() {
        v997_9_cursor.descend_to_existing_byte(v999_7_byte);
        {
        let v1000_2: Space = singleton(&v997_9_cursor.path()[(v997_9_origin + 1)..(v997_9_origin + 2)]);
        let v1000_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1000_2));
        let v1000_4: Space = if map_kernels::has_head(&(v1000_3)) { singleton(&[]) } else { Space::new() };
        drop(v1000_3);
        let v1000_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1000_4));
        drop(v1000_4);
        let v1000_7: Space = if (&(v1000_5)).is_empty() { Space::new() } else {
          let mut v1001_6 = Space::new();
          let mut v1001_6_write = v1001_6.write_zipper();
          for v1001_6_byte in v997_9_cursor.child_mask().iter() {
            v997_9_cursor.descend_to_existing_byte(v1001_6_byte);
            {
            let v1002_2: Space = Space::new();
            join_wrapped_into(&mut v1001_6_write,&((v1002_2).read_zipper()),&[]);
            }
            v997_9_cursor.ascend(1);
          }
          drop(v1001_6_write);
          map_map_kernels::compose(&(v1000_5),&(v1001_6))
        };
        drop(v1000_5);
        let v1000_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1000_2));
        drop(v1000_2);
        let v1000_9: Space = if map_kernels::has_head(&(v1000_8)) { singleton(&[]) } else { Space::new() };
        drop(v1000_8);
        let v1000_12: Space = if (&(v1000_9)).is_empty() { Space::new() } else {
          let v1003_10: Path = concat_path(&(v999_6),&v997_9_cursor.path()[(v997_9_origin + 1)..(v997_9_origin + 2)]);
          let mut v1003_11 = Space::new();
          let mut v1003_11_write = v1003_11.write_zipper();
          for v1003_11_byte in v997_9_cursor.child_mask().iter() {
            v997_9_cursor.descend_to_existing_byte(v1003_11_byte);
            {
            let v1004_2: Space = singleton(&v997_9_cursor.path()[(v997_9_origin + 2)..(v997_9_origin + 3)]);
            let v1004_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1004_2));
            drop(v1004_2);
            let v1004_4: Space = if map_kernels::has_head(&(v1004_3)) { singleton(&[]) } else { Space::new() };
            drop(v1004_3);
            let v1004_7: Space = if (&(v1004_4)).is_empty() { Space::new() } else {
              let v1005_5: Path = concat_path(&(v1003_10),&v997_9_cursor.path()[(v997_9_origin + 2)..(v997_9_origin + 3)]);
              let v1005_6: Space = routine_15(c, &(v1005_5), &v997_9_cursor);
              drop(v1005_5);
              map_map_kernels::compose(&(v1004_4),&(v1005_6))
            };
            drop(v1004_4);
            join_wrapped_into(&mut v1003_11_write,&((v1004_7).read_zipper()),&[]);
            }
            v997_9_cursor.ascend(1);
          }
          drop(v1003_11_write);
          drop(v1003_10);
          map_map_kernels::compose(&(v1000_9),&(v1003_11))
        };
        drop(v1000_9);
        let v1000_13: Space = map_map_kernels::unite(&(v1000_7),&(v1000_12));
        drop(v1000_7);
        join_wrapped_into(&mut v999_7_write,&((v1000_13).read_zipper()),&[]);
        }
        v997_9_cursor.ascend(1);
      }
      drop(v999_7_write);
      drop(v999_6);
      map_map_kernels::compose(&(v998_5),&(v999_7))
    };
    drop(v998_5);
    let v998_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v998_2));
    drop(v998_2);
    let v998_10: Space = if map_kernels::has_head(&(v998_9)) { singleton(&[]) } else { Space::new() };
    drop(v998_9);
    let v998_11: Space = map_view_kernels::compose(&(v998_10),&v997_9_cursor);
    drop(v998_10);
    let v998_12: Space = map_map_kernels::unite(&(v998_8),&(v998_11));
    drop(v998_11);
    join_wrapped_into(&mut v997_9_write,&((v998_12).read_zipper()),&[]);
    }
    v997_9_cursor.ascend(1);
  }
  drop(v997_9_cursor);
  drop(v997_9_write);
  (v997_9).clone()
}

fn routine_62(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1006_6 = Space::new();
  let mut v1006_6_write = v1006_6.write_zipper();
  let mut v1006_6_cursor = (*s0).read_zipper();
  let v1006_6_origin = v1006_6_cursor.path().len();
  for v1006_6_byte in v1006_6_cursor.child_mask().iter() {
    v1006_6_cursor.descend_to_existing_byte(v1006_6_byte);
    {
    let v1007_2: Space = singleton(&v1006_6_cursor.path()[v1006_6_origin..(v1006_6_origin + 1)]);
    let v1007_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1007_2));
    let v1007_4: Space = if map_kernels::has_head(&(v1007_3)) { singleton(&[]) } else { Space::new() };
    drop(v1007_3);
    let v1007_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1007_4));
    drop(v1007_4);
    let v1007_7: Space = if (&(v1007_5)).is_empty() { Space::new() } else {
      let mut v1008_6 = Space::new();
      let mut v1008_6_write = v1008_6.write_zipper();
      for v1008_6_byte in v1006_6_cursor.child_mask().iter() {
        v1006_6_cursor.descend_to_existing_byte(v1008_6_byte);
        {
        let v1009_2: Space = Space::new();
        join_wrapped_into(&mut v1008_6_write,&((v1009_2).read_zipper()),&[]);
        }
        v1006_6_cursor.ascend(1);
      }
      drop(v1008_6_write);
      map_map_kernels::compose(&(v1007_5),&(v1008_6))
    };
    drop(v1007_5);
    let v1007_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1007_2));
    drop(v1007_2);
    let v1007_9: Space = if map_kernels::has_head(&(v1007_8)) { singleton(&[]) } else { Space::new() };
    drop(v1007_8);
    let v1007_11: Space = if (&(v1007_9)).is_empty() { Space::new() } else {
      let mut v1010_10 = Space::new();
      let mut v1010_10_write = v1010_10.write_zipper();
      for v1010_10_byte in v1006_6_cursor.child_mask().iter() {
        v1006_6_cursor.descend_to_existing_byte(v1010_10_byte);
        {
        let v1011_2: Space = singleton(&v1006_6_cursor.path()[(v1006_6_origin + 1)..(v1006_6_origin + 2)]);
        let v1011_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1011_2));
        drop(v1011_2);
        let v1011_4: Space = if map_kernels::has_head(&(v1011_3)) { singleton(&[]) } else { Space::new() };
        drop(v1011_3);
        let v1011_5: Space = map_view_kernels::compose(&(v1011_4),&v1006_6_cursor);
        drop(v1011_4);
        join_wrapped_into(&mut v1010_10_write,&((v1011_5).read_zipper()),&[]);
        }
        v1006_6_cursor.ascend(1);
      }
      drop(v1010_10_write);
      map_map_kernels::compose(&(v1007_9),&(v1010_10))
    };
    drop(v1007_9);
    let v1007_12: Space = map_map_kernels::unite(&(v1007_7),&(v1007_11));
    drop(v1007_7);
    drop(v1007_11);
    join_wrapped_into(&mut v1006_6_write,&((v1007_12).read_zipper()),&[]);
    }
    v1006_6_cursor.ascend(1);
  }
  drop(v1006_6_cursor);
  drop(v1006_6_write);
  (v1006_6).clone()
}

fn routine_63(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1012_5 = Space::new();
  let mut v1012_5_write = v1012_5.write_zipper();
  let mut v1012_5_cursor = (*s0).read_zipper();
  let v1012_5_origin = v1012_5_cursor.path().len();
  for v1012_5_byte in v1012_5_cursor.child_mask().iter() {
    v1012_5_cursor.descend_to_existing_byte(v1012_5_byte);
    {
    let v1013_2: Space = singleton(&v1012_5_cursor.path()[v1012_5_origin..(v1012_5_origin + 1)]);
    let v1013_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1013_2));
    let v1013_4: Space = if map_kernels::has_head(&(v1013_3)) { singleton(&[]) } else { Space::new() };
    drop(v1013_3);
    let v1013_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1013_4));
    drop(v1013_4);
    let v1013_7: Space = if (&(v1013_5)).is_empty() { Space::new() } else {
      let mut v1014_6 = Space::new();
      let mut v1014_6_write = v1014_6.write_zipper();
      for v1014_6_byte in v1012_5_cursor.child_mask().iter() {
        v1012_5_cursor.descend_to_existing_byte(v1014_6_byte);
        {
        let v1015_2: Space = Space::new();
        join_wrapped_into(&mut v1014_6_write,&((v1015_2).read_zipper()),&[]);
        }
        v1012_5_cursor.ascend(1);
      }
      drop(v1014_6_write);
      map_map_kernels::compose(&(v1013_5),&(v1014_6))
    };
    drop(v1013_5);
    let v1013_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1013_2));
    drop(v1013_2);
    let v1013_9: Space = if map_kernels::has_head(&(v1013_8)) { singleton(&[]) } else { Space::new() };
    drop(v1013_8);
    let v1013_10: Space = map_view_kernels::compose(&(v1013_9),&v1012_5_cursor);
    drop(v1013_9);
    let v1013_11: Space = map_map_kernels::unite(&(v1013_7),&(v1013_10));
    drop(v1013_7);
    drop(v1013_10);
    join_wrapped_into(&mut v1012_5_write,&((v1013_11).read_zipper()),&[]);
    }
    v1012_5_cursor.ascend(1);
  }
  drop(v1012_5_cursor);
  drop(v1012_5_write);
  (v1012_5).clone()
}

fn routine_64(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1016_6 = Space::new();
  let mut v1016_6_write = v1016_6.write_zipper();
  let mut v1016_6_cursor = (*s0).read_zipper();
  let v1016_6_origin = v1016_6_cursor.path().len();
  for v1016_6_byte in v1016_6_cursor.child_mask().iter() {
    v1016_6_cursor.descend_to_existing_byte(v1016_6_byte);
    {
    let v1017_2: Space = singleton(&v1016_6_cursor.path()[v1016_6_origin..(v1016_6_origin + 1)]);
    let v1017_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1017_2));
    let v1017_4: Space = if map_kernels::has_head(&(v1017_3)) { singleton(&[]) } else { Space::new() };
    drop(v1017_3);
    let v1017_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1017_4));
    drop(v1017_4);
    let v1017_7: Space = if (&(v1017_5)).is_empty() { Space::new() } else {
      let mut v1018_6 = Space::new();
      let mut v1018_6_write = v1018_6.write_zipper();
      for v1018_6_byte in v1016_6_cursor.child_mask().iter() {
        v1016_6_cursor.descend_to_existing_byte(v1018_6_byte);
        {
        let v1019_2: Space = Space::new();
        join_wrapped_into(&mut v1018_6_write,&((v1019_2).read_zipper()),&[]);
        }
        v1016_6_cursor.ascend(1);
      }
      drop(v1018_6_write);
      map_map_kernels::compose(&(v1017_5),&(v1018_6))
    };
    drop(v1017_5);
    let v1017_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1017_2));
    drop(v1017_2);
    let v1017_9: Space = if map_kernels::has_head(&(v1017_8)) { singleton(&[]) } else { Space::new() };
    drop(v1017_8);
    let v1017_11: Space = if (&(v1017_9)).is_empty() { Space::new() } else {
      let mut v1020_10 = Space::new();
      let mut v1020_10_write = v1020_10.write_zipper();
      for v1020_10_byte in v1016_6_cursor.child_mask().iter() {
        v1016_6_cursor.descend_to_existing_byte(v1020_10_byte);
        {
        let v1021_2: Space = singleton(&v1016_6_cursor.path()[(v1016_6_origin + 1)..(v1016_6_origin + 2)]);
        let v1021_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1021_2));
        drop(v1021_2);
        let v1021_4: Space = if map_kernels::has_head(&(v1021_3)) { singleton(&[]) } else { Space::new() };
        drop(v1021_3);
        let v1021_5: Space = map_view_kernels::compose(&(v1021_4),&v1016_6_cursor);
        drop(v1021_4);
        join_wrapped_into(&mut v1020_10_write,&((v1021_5).read_zipper()),&[]);
        }
        v1016_6_cursor.ascend(1);
      }
      drop(v1020_10_write);
      map_map_kernels::compose(&(v1017_9),&(v1020_10))
    };
    drop(v1017_9);
    let v1017_12: Space = map_map_kernels::unite(&(v1017_7),&(v1017_11));
    drop(v1017_7);
    drop(v1017_11);
    join_wrapped_into(&mut v1016_6_write,&((v1017_12).read_zipper()),&[]);
    }
    v1016_6_cursor.ascend(1);
  }
  drop(v1016_6_cursor);
  drop(v1016_6_write);
  (v1016_6).clone()
}

fn routine_65(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1022_5 = Space::new();
  let mut v1022_5_write = v1022_5.write_zipper();
  let mut v1022_5_cursor = (*s0).read_zipper();
  let v1022_5_origin = v1022_5_cursor.path().len();
  for v1022_5_byte in v1022_5_cursor.child_mask().iter() {
    v1022_5_cursor.descend_to_existing_byte(v1022_5_byte);
    {
    let v1023_2: Space = singleton(&v1022_5_cursor.path()[v1022_5_origin..(v1022_5_origin + 1)]);
    let v1023_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1023_2));
    let v1023_4: Space = if map_kernels::has_head(&(v1023_3)) { singleton(&[]) } else { Space::new() };
    drop(v1023_3);
    let v1023_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1023_4));
    drop(v1023_4);
    let v1023_7: Space = if (&(v1023_5)).is_empty() { Space::new() } else {
      let mut v1024_6 = Space::new();
      let mut v1024_6_write = v1024_6.write_zipper();
      for v1024_6_byte in v1022_5_cursor.child_mask().iter() {
        v1022_5_cursor.descend_to_existing_byte(v1024_6_byte);
        {
        let v1025_2: Space = Space::new();
        join_wrapped_into(&mut v1024_6_write,&((v1025_2).read_zipper()),&[]);
        }
        v1022_5_cursor.ascend(1);
      }
      drop(v1024_6_write);
      map_map_kernels::compose(&(v1023_5),&(v1024_6))
    };
    drop(v1023_5);
    let v1023_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1023_2));
    drop(v1023_2);
    let v1023_9: Space = if map_kernels::has_head(&(v1023_8)) { singleton(&[]) } else { Space::new() };
    drop(v1023_8);
    let v1023_10: Space = map_view_kernels::compose(&(v1023_9),&v1022_5_cursor);
    drop(v1023_9);
    let v1023_11: Space = map_map_kernels::unite(&(v1023_7),&(v1023_10));
    drop(v1023_7);
    drop(v1023_10);
    join_wrapped_into(&mut v1022_5_write,&((v1023_11).read_zipper()),&[]);
    }
    v1022_5_cursor.ascend(1);
  }
  drop(v1022_5_cursor);
  drop(v1022_5_write);
  (v1022_5).clone()
}

fn routine_66(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1026_2 = Space::new();
  let mut v1026_2_write = v1026_2.write_zipper();
  let mut v1026_2_cursor = (*s0).read_zipper();
  let v1026_2_origin = v1026_2_cursor.path().len();
  for v1026_2_byte in v1026_2_cursor.child_mask().iter() {
    v1026_2_cursor.descend_to_existing_byte(v1026_2_byte);
    {
    let v1027_2: Space = Space::new();
    join_wrapped_into(&mut v1026_2_write,&((v1027_2).read_zipper()),&[]);
    }
    v1026_2_cursor.ascend(1);
  }
  drop(v1026_2_cursor);
  drop(v1026_2_write);
  (v1026_2).clone()
}

fn routine_67(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1028_3 = Space::new();
  let mut v1028_3_write = v1028_3.write_zipper();
  let mut v1028_3_cursor = (*s0).read_zipper();
  let v1028_3_origin = v1028_3_cursor.path().len();
  for v1028_3_byte in v1028_3_cursor.child_mask().iter() {
    v1028_3_cursor.descend_to_existing_byte(v1028_3_byte);
    {
    let v1029_2: Space = singleton(&v1028_3_cursor.path()[v1028_3_origin..(v1028_3_origin + 1)]);
    let v1029_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1029_2));
    drop(v1029_2);
    let v1029_4: Space = if map_kernels::has_head(&(v1029_3)) { singleton(&[]) } else { Space::new() };
    drop(v1029_3);
    let v1029_5: Space = map_view_kernels::compose(&(v1029_4),&v1028_3_cursor);
    drop(v1029_4);
    join_wrapped_into(&mut v1028_3_write,&((v1029_5).read_zipper()),&[]);
    }
    v1028_3_cursor.ascend(1);
  }
  drop(v1028_3_cursor);
  drop(v1028_3_write);
  (v1028_3).clone()
}

fn routine_68(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1030_2 = Space::new();
  let mut v1030_2_write = v1030_2.write_zipper();
  let mut v1030_2_cursor = (*s0).read_zipper();
  let v1030_2_origin = v1030_2_cursor.path().len();
  for v1030_2_byte in v1030_2_cursor.child_mask().iter() {
    v1030_2_cursor.descend_to_existing_byte(v1030_2_byte);
    {
    let v1031_2: Space = Space::new();
    join_wrapped_into(&mut v1030_2_write,&((v1031_2).read_zipper()),&[]);
    }
    v1030_2_cursor.ascend(1);
  }
  drop(v1030_2_cursor);
  drop(v1030_2_write);
  (v1030_2).clone()
}

fn routine_69(c: &mut Context, p0: &[u8], s0: &View<'_, '_>) -> Space {
  let mut v1032_3 = Space::new();
  let mut v1032_3_write = v1032_3.write_zipper();
  let mut v1032_3_cursor = (*s0).read_zipper();
  let v1032_3_origin = v1032_3_cursor.path().len();
  for v1032_3_byte in v1032_3_cursor.child_mask().iter() {
    v1032_3_cursor.descend_to_existing_byte(v1032_3_byte);
    {
    let v1033_2: Space = singleton(&v1032_3_cursor.path()[v1032_3_origin..(v1032_3_origin + 1)]);
    let v1033_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1033_2));
    drop(v1033_2);
    let v1033_4: Space = if map_kernels::has_head(&(v1033_3)) { singleton(&[]) } else { Space::new() };
    drop(v1033_3);
    let v1033_5: Space = map_view_kernels::compose(&(v1033_4),&v1032_3_cursor);
    drop(v1033_4);
    join_wrapped_into(&mut v1032_3_write,&((v1033_5).read_zipper()),&[]);
    }
    v1032_3_cursor.ascend(1);
  }
  drop(v1032_3_cursor);
  drop(v1032_3_write);
  (v1032_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
