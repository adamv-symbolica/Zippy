#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_1 = Space::new();
  let mut v0_1_cursor = (*s0.expect("unbound native input")).read_zipper();
  let v0_1_origin = v0_1_cursor.path().len();
  for v0_1_byte in v0_1_cursor.child_mask().iter() {
    v0_1_cursor.descend_to_existing_byte(v0_1_byte);
    {
    let v0_1_tail = v0_1_cursor.fork_read_zipper();
    let v0_1_head = Path::from_slice(&[v0_1_byte]);
    let mut v1_2 = Space::new();
    let mut v1_2_cursor = (v0_1_tail).read_zipper();
    let v1_2_origin = v1_2_cursor.path().len();
    for v1_2_byte in v1_2_cursor.child_mask().iter() {
      v1_2_cursor.descend_to_existing_byte(v1_2_byte);
      {
      let v1_2_tail = v1_2_cursor.fork_read_zipper();
      let v1_2_head = Path::from_slice(&[v1_2_byte]);
      let v2_2: Path = concat_path(&(v0_1_head),&(v1_2_head));
      let mut v2_3 = Space::new();
      let mut v2_3_cursor = (v1_2_tail).read_zipper();
      let v2_3_origin = v2_3_cursor.path().len();
      for v2_3_byte in v2_3_cursor.child_mask().iter() {
        v2_3_cursor.descend_to_existing_byte(v2_3_byte);
        {
        let v2_3_tail = v2_3_cursor.fork_read_zipper();
        let v2_3_head = Path::from_slice(&[v2_3_byte]);
        let v3_2: Path = concat_path(&(v2_2),&(v2_3_head));
        let mut v3_3 = Space::new();
        let mut v3_3_cursor = (v2_3_tail).read_zipper();
        let v3_3_origin = v3_3_cursor.path().len();
        for v3_3_byte in v3_3_cursor.child_mask().iter() {
          v3_3_cursor.descend_to_existing_byte(v3_3_byte);
          {
          let v3_3_tail = v3_3_cursor.fork_read_zipper();
          let v3_3_head = Path::from_slice(&[v3_3_byte]);
          let v4_2: Path = concat_path(&(v3_2),&(v3_3_head));
          let mut v4_3 = Space::new();
          let mut v4_3_cursor = (v3_3_tail).read_zipper();
          let v4_3_origin = v4_3_cursor.path().len();
          for v4_3_byte in v4_3_cursor.child_mask().iter() {
            v4_3_cursor.descend_to_existing_byte(v4_3_byte);
            {
            let v4_3_tail = v4_3_cursor.fork_read_zipper();
            let v4_3_head = Path::from_slice(&[v4_3_byte]);
            let v5_2: Path = concat_path(&(v4_2),&(v4_3_head));
            let mut v5_3 = Space::new();
            let mut v5_3_cursor = (v4_3_tail).read_zipper();
            let v5_3_origin = v5_3_cursor.path().len();
            for v5_3_byte in v5_3_cursor.child_mask().iter() {
              v5_3_cursor.descend_to_existing_byte(v5_3_byte);
              {
              let v5_3_tail = v5_3_cursor.fork_read_zipper();
              let v5_3_head = Path::from_slice(&[v5_3_byte]);
              let v6_2: Path = concat_path(&(v5_2),&(v5_3_head));
              let mut v6_3 = Space::new();
              let mut v6_3_cursor = (v5_3_tail).read_zipper();
              let v6_3_origin = v6_3_cursor.path().len();
              for v6_3_byte in v6_3_cursor.child_mask().iter() {
                v6_3_cursor.descend_to_existing_byte(v6_3_byte);
                {
                let v6_3_tail = v6_3_cursor.fork_read_zipper();
                let v6_3_head = Path::from_slice(&[v6_3_byte]);
                let v7_2: Path = concat_path(&(v6_2),&(v6_3_head));
                let mut v7_3 = Space::new();
                let mut v7_3_cursor = (v6_3_tail).read_zipper();
                let v7_3_origin = v7_3_cursor.path().len();
                for v7_3_byte in v7_3_cursor.child_mask().iter() {
                  v7_3_cursor.descend_to_existing_byte(v7_3_byte);
                  {
                  let v7_3_tail = v7_3_cursor.fork_read_zipper();
                  let v7_3_head = Path::from_slice(&[v7_3_byte]);
                  let v8_2: Path = concat_path(&(v7_2),&(v7_3_head));
                  let mut v8_3 = Space::new();
                  let mut v8_3_cursor = (v7_3_tail).read_zipper();
                  let v8_3_origin = v8_3_cursor.path().len();
                  for v8_3_byte in v8_3_cursor.child_mask().iter() {
                    v8_3_cursor.descend_to_existing_byte(v8_3_byte);
                    {
                    let v8_3_tail = v8_3_cursor.fork_read_zipper();
                    let v8_3_head = Path::from_slice(&[v8_3_byte]);
                    let v9_2: Path = concat_path(&(v8_2),&(v8_3_head));
                    let mut v9_3 = Space::new();
                    let mut v9_3_cursor = (v8_3_tail).read_zipper();
                    let v9_3_origin = v9_3_cursor.path().len();
                    for v9_3_byte in v9_3_cursor.child_mask().iter() {
                      v9_3_cursor.descend_to_existing_byte(v9_3_byte);
                      {
                      let v9_3_tail = v9_3_cursor.fork_read_zipper();
                      let v9_3_head = Path::from_slice(&[v9_3_byte]);
                      let v10_2: Path = concat_path(&(v9_2),&(v9_3_head));
                      let mut v10_3 = Space::new();
                      let mut v10_3_cursor = (v9_3_tail).read_zipper();
                      let v10_3_origin = v10_3_cursor.path().len();
                      for v10_3_byte in v10_3_cursor.child_mask().iter() {
                        v10_3_cursor.descend_to_existing_byte(v10_3_byte);
                        {
                        let v10_3_tail = v10_3_cursor.fork_read_zipper();
                        let v10_3_head = Path::from_slice(&[v10_3_byte]);
                        let v11_2: Path = concat_path(&(v10_2),&(v10_3_head));
                        let mut v11_3 = Space::new();
                        let mut v11_3_cursor = (v10_3_tail).read_zipper();
                        let v11_3_origin = v11_3_cursor.path().len();
                        for v11_3_byte in v11_3_cursor.child_mask().iter() {
                          v11_3_cursor.descend_to_existing_byte(v11_3_byte);
                          {
                          let v11_3_tail = v11_3_cursor.fork_read_zipper();
                          let v11_3_head = Path::from_slice(&[v11_3_byte]);
                          let v12_2: Path = concat_path(&(v11_2),&(v11_3_head));
                          let mut v12_3 = Space::new();
                          let mut v12_3_cursor = (v11_3_tail).read_zipper();
                          let v12_3_origin = v12_3_cursor.path().len();
                          for v12_3_byte in v12_3_cursor.child_mask().iter() {
                            v12_3_cursor.descend_to_existing_byte(v12_3_byte);
                            {
                            let v12_3_tail = v12_3_cursor.fork_read_zipper();
                            let v12_3_head = Path::from_slice(&[v12_3_byte]);
                            let v13_2: Path = concat_path(&(v12_2),&(v12_3_head));
                            let mut v13_3 = Space::new();
                            let mut v13_3_cursor = (v12_3_tail).read_zipper();
                            let v13_3_origin = v13_3_cursor.path().len();
                            for v13_3_byte in v13_3_cursor.child_mask().iter() {
                              v13_3_cursor.descend_to_existing_byte(v13_3_byte);
                              {
                              let v13_3_tail = v13_3_cursor.fork_read_zipper();
                              let v13_3_head = Path::from_slice(&[v13_3_byte]);
                              let v14_2: Path = concat_path(&(v13_2),&(v13_3_head));
                              let mut v14_3 = Space::new();
                              let mut v14_3_cursor = (v13_3_tail).read_zipper();
                              let v14_3_origin = v14_3_cursor.path().len();
                              for v14_3_byte in v14_3_cursor.child_mask().iter() {
                                v14_3_cursor.descend_to_existing_byte(v14_3_byte);
                                {
                                let v14_3_tail = v14_3_cursor.fork_read_zipper();
                                let v14_3_head = Path::from_slice(&[v14_3_byte]);
                                let v15_2: Space = head_space(&(v14_3_tail));
                                let v15_3: Path = concat_path(&(v14_2),&(v14_3_head));
                                let v15_4: Space = wrap(&(v15_2),&(v15_3));
                                drop(v15_2);
                                drop(v15_3);
                                v14_3.join_into((v15_4).clone());
                                }
                                v14_3_cursor.ascend(1);
                              }
                              drop(v14_3_cursor);
                              drop(v14_2);
                              v13_3.join_into((v14_3).clone());
                              }
                              v13_3_cursor.ascend(1);
                            }
                            drop(v13_3_cursor);
                            drop(v13_2);
                            v12_3.join_into((v13_3).clone());
                            }
                            v12_3_cursor.ascend(1);
                          }
                          drop(v12_3_cursor);
                          drop(v12_2);
                          v11_3.join_into((v12_3).clone());
                          }
                          v11_3_cursor.ascend(1);
                        }
                        drop(v11_3_cursor);
                        drop(v11_2);
                        v10_3.join_into((v11_3).clone());
                        }
                        v10_3_cursor.ascend(1);
                      }
                      drop(v10_3_cursor);
                      drop(v10_2);
                      v9_3.join_into((v10_3).clone());
                      }
                      v9_3_cursor.ascend(1);
                    }
                    drop(v9_3_cursor);
                    drop(v9_2);
                    v8_3.join_into((v9_3).clone());
                    }
                    v8_3_cursor.ascend(1);
                  }
                  drop(v8_3_cursor);
                  drop(v8_2);
                  v7_3.join_into((v8_3).clone());
                  }
                  v7_3_cursor.ascend(1);
                }
                drop(v7_3_cursor);
                drop(v7_2);
                v6_3.join_into((v7_3).clone());
                }
                v6_3_cursor.ascend(1);
              }
              drop(v6_3_cursor);
              drop(v6_2);
              v5_3.join_into((v6_3).clone());
              }
              v5_3_cursor.ascend(1);
            }
            drop(v5_3_cursor);
            drop(v5_2);
            v4_3.join_into((v5_3).clone());
            }
            v4_3_cursor.ascend(1);
          }
          drop(v4_3_cursor);
          drop(v4_2);
          v3_3.join_into((v4_3).clone());
          }
          v3_3_cursor.ascend(1);
        }
        drop(v3_3_cursor);
        drop(v3_2);
        v2_3.join_into((v3_3).clone());
        }
        v2_3_cursor.ascend(1);
      }
      drop(v2_3_cursor);
      drop(v2_2);
      v1_2.join_into((v2_3).clone());
      }
      v1_2_cursor.ascend(1);
    }
    drop(v1_2_cursor);
    v0_1.join_into((v1_2).clone());
    }
    v0_1_cursor.ascend(1);
  }
  drop(v0_1_cursor);
  (v0_1).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
