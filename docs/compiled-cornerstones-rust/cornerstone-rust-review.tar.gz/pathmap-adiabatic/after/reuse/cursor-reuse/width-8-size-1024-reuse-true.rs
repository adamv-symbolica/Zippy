#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_1 = Space::new();
  let mut v0_1_write = v0_1.write_zipper();
  let mut v0_1_cursor = (*s0.expect("unbound native input")).read_zipper();
  let v0_1_origin = v0_1_cursor.path().len();
  for v0_1_byte in v0_1_cursor.child_mask().iter() {
    v0_1_cursor.descend_to_existing_byte(v0_1_byte);
    {
    for v1_2_byte in v0_1_cursor.child_mask().iter() {
      v0_1_cursor.descend_to_existing_byte(v1_2_byte);
      {
      for v2_3_byte in v0_1_cursor.child_mask().iter() {
        v0_1_cursor.descend_to_existing_byte(v2_3_byte);
        {
        for v3_3_byte in v0_1_cursor.child_mask().iter() {
          v0_1_cursor.descend_to_existing_byte(v3_3_byte);
          {
          for v4_3_byte in v0_1_cursor.child_mask().iter() {
            v0_1_cursor.descend_to_existing_byte(v4_3_byte);
            {
            for v5_3_byte in v0_1_cursor.child_mask().iter() {
              v0_1_cursor.descend_to_existing_byte(v5_3_byte);
              {
              for v6_3_byte in v0_1_cursor.child_mask().iter() {
                v0_1_cursor.descend_to_existing_byte(v6_3_byte);
                {
                write_heads_mask(&mut v0_1_write,(&v0_1_cursor).head_mask(),&v0_1_cursor.path()[v0_1_origin..(v0_1_origin + 7)]);
                }
                v0_1_cursor.ascend(1);
              }
              }
              v0_1_cursor.ascend(1);
            }
            }
            v0_1_cursor.ascend(1);
          }
          }
          v0_1_cursor.ascend(1);
        }
        }
        v0_1_cursor.ascend(1);
      }
      }
      v0_1_cursor.ascend(1);
    }
    }
    v0_1_cursor.ascend(1);
  }
  drop(v0_1_cursor);
  drop(v0_1_write);
  (v0_1).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
