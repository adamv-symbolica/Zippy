#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_1 = Space::new();
  let mut v0_1_cursor = (*s0.expect("unbound native input")).read_zipper();
  let v0_1_origin = v0_1_cursor.path().len();
  for v0_1_byte in v0_1_cursor.child_mask().iter() {
    v0_1_cursor.descend_to_existing_byte(v0_1_byte);
    {
    let v0_1_tail = v0_1_cursor.fork_read_zipper();
    let v0_1_head = Path::from_slice(&[v0_1_byte]);
    let mut v1_2 = Space::new();
    let mut v1_2_cursor = (v0_1_tail).read_zipper();
    let v1_2_origin = v1_2_cursor.path().len();
    for v1_2_byte in v1_2_cursor.child_mask().iter() {
      v1_2_cursor.descend_to_existing_byte(v1_2_byte);
      {
      let v1_2_tail = v1_2_cursor.fork_read_zipper();
      let v1_2_head = Path::from_slice(&[v1_2_byte]);
      let v2_2: Path = concat_path(&(v0_1_head),&(v1_2_head));
      let mut v2_3 = Space::new();
      let mut v2_3_cursor = (v1_2_tail).read_zipper();
      let v2_3_origin = v2_3_cursor.path().len();
      for v2_3_byte in v2_3_cursor.child_mask().iter() {
        v2_3_cursor.descend_to_existing_byte(v2_3_byte);
        {
        let v2_3_tail = v2_3_cursor.fork_read_zipper();
        let v2_3_head = Path::from_slice(&[v2_3_byte]);
        let v3_2: Space = head_space(&(v2_3_tail));
        let v3_3: Path = concat_path(&(v2_2),&(v2_3_head));
        let v3_4: Space = wrap(&(v3_2),&(v3_3));
        drop(v3_2);
        drop(v3_3);
        v2_3.join_into((v3_4).clone());
        }
        v2_3_cursor.ascend(1);
      }
      drop(v2_3_cursor);
      drop(v2_2);
      v1_2.join_into((v2_3).clone());
      }
      v1_2_cursor.ascend(1);
    }
    drop(v1_2_cursor);
    v0_1.join_into((v1_2).clone());
    }
    v0_1_cursor.ascend(1);
  }
  drop(v0_1_cursor);
  (v0_1).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
