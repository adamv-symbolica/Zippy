#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 0 0 2 4 0 0 0 3"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 8 4 0 0 0 9 4 0 0 0 10 4 0 0 0 11 4 0 0 0 12"));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,3]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 3 4 0 0 0 8 4 0 0 0 10 4 0 0 0 13 4 0 0 0 14"));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 5 4 0 0 0 6 4 0 0 0 7"));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 4 0 0 0 6 4 0 0 0 7 4 0 0 0 12 4 0 0 0 18"));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,6]));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 1 4 0 0 0 9 4 0 0 0 11 4 0 0 0 12 4 0 0 0 19"));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,7]));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 12 4 0 0 0 14 4 0 0 0 17 4 0 0 0 20 4 0 0 0 23"));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,8]));
static CONSTANT_15: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 15 4 0 0 0 16 4 0 0 0 17"));
static CONSTANT_16: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,9]));
static CONSTANT_17: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 0 0 2 4 0 0 0 5 4 0 0 0 8 4 0 0 0 14 4 0 0 0 20 4 0 0 0 21 4 0 0 0 24"));
static CONSTANT_18: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,10]));
static CONSTANT_19: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 4 4 0 0 0 12 4 0 0 0 14 4 0 0 0 17 4 0 0 0 23"));
static CONSTANT_20: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,11]));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 0 0 0 4 4 0 0 0 6 4 0 0 0 7 4 0 0 0 11 4 0 0 0 17 4 0 0 0 22"));
static CONSTANT_22: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,12]));
static CONSTANT_23: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 4 0 0 0 8 4 0 0 0 10 4 0 0 0 13 4 0 0 0 14 4 0 0 0 16 4 0 0 0 21 4 0 0 0 22 4 0 0 0 23"));
static CONSTANT_24: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,13]));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 4 4 0 0 0 14 4 0 0 0 17 4 0 0 0 18 4 0 0 0 23"));
static CONSTANT_26: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,14]));
static CONSTANT_27: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 2 4 0 0 0 8 4 0 0 0 9 4 0 0 0 16 4 0 0 0 23"));
static CONSTANT_28: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,15]));
static CONSTANT_29: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 1"));
static CONSTANT_30: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,16]));
static CONSTANT_31: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 9 4 0 0 0 13 4 0 0 0 18"));
static CONSTANT_32: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,17]));
static CONSTANT_33: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 2 4 0 0 0 5 4 0 0 0 18"));
static CONSTANT_34: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,18]));
static CONSTANT_35: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 5 4 0 0 0 12 4 0 0 0 19 4 0 0 0 20 4 0 0 0 22"));
static CONSTANT_36: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,19]));
static CONSTANT_37: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 0 0 0 3 4 0 0 0 11 4 0 0 0 12 4 0 0 0 14 4 0 0 0 16 4 0 0 0 18"));
static CONSTANT_38: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,20]));
static CONSTANT_39: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 4 0 0 0 4 4 0 0 0 7 4 0 0 0 11 4 0 0 0 13 4 0 0 0 14 4 0 0 0 15 4 0 0 0 16 4 0 0 0 21"));
static CONSTANT_40: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,21]));
static CONSTANT_41: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("9 4 0 0 0 8 4 0 0 0 9 4 0 0 0 11 4 0 0 0 12 4 0 0 0 13 4 0 0 0 15 4 0 0 0 17 4 0 0 0 22 4 0 0 0 23"));
static CONSTANT_42: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,22]));
static CONSTANT_43: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 0 0 3 4 0 0 0 7 4 0 0 0 10 4 0 0 0 15 4 0 0 0 16 4 0 0 0 19 4 0 0 0 20"));
static CONSTANT_44: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,23]));
static CONSTANT_45: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 0 0 2 4 0 0 0 4 4 0 0 0 6 4 0 0 0 7 4 0 0 0 14 4 0 0 0 16 4 0 0 0 22"));
static CONSTANT_46: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,24]));
static CONSTANT_47: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 4 0 0 0 15 4 0 0 0 17 4 0 0 0 24"));
static CONSTANT_48: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("120 12 0 0 0 0 0 0 0 1 0 0 0 2 12 0 0 0 0 0 0 0 1 0 0 0 3 12 0 0 0 0 0 0 0 2 0 0 0 8 12 0 0 0 0 0 0 0 2 0 0 0 9 12 0 0 0 0 0 0 0 2 0 0 0 10 12 0 0 0 0 0 0 0 2 0 0 0 11 12 0 0 0 0 0 0 0 2 0 0 0 12 12 0 0 0 0 0 0 0 3 0 0 0 3 12 0 0 0 0 0 0 0 3 0 0 0 8 12 0 0 0 0 0 0 0 3 0 0 0 10 12 0 0 0 0 0 0 0 3 0 0 0 13 12 0 0 0 0 0 0 0 3 0 0 0 14 12 0 0 0 0 0 0 0 4 0 0 0 5 12 0 0 0 0 0 0 0 4 0 0 0 6 12 0 0 0 0 0 0 0 4 0 0 0 7 12 0 0 0 0 0 0 0 5 0 0 0 6 12 0 0 0 0 0 0 0 5 0 0 0 7 12 0 0 0 0 0 0 0 5 0 0 0 12 12 0 0 0 0 0 0 0 5 0 0 0 18 12 0 0 0 0 0 0 0 6 0 0 0 1 12 0 0 0 0 0 0 0 6 0 0 0 9 12 0 0 0 0 0 0 0 6 0 0 0 11 12 0 0 0 0 0 0 0 6 0 0 0 12 12 0 0 0 0 0 0 0 6 0 0 0 19 12 0 0 0 0 0 0 0 7 0 0 0 12 12 0 0 0 0 0 0 0 7 0 0 0 14 12 0 0 0 0 0 0 0 7 0 0 0 17 12 0 0 0 0 0 0 0 7 0 0 0 20 12 0 0 0 0 0 0 0 7 0 0 0 23 12 0 0 0 0 0 0 0 8 0 0 0 15 12 0 0 0 0 0 0 0 8 0 0 0 16 12 0 0 0 0 0 0 0 8 0 0 0 17 12 0 0 0 0 0 0 0 9 0 0 0 2 12 0 0 0 0 0 0 0 9 0 0 0 5 12 0 0 0 0 0 0 0 9 0 0 0 8 12 0 0 0 0 0 0 0 9 0 0 0 14 12 0 0 0 0 0 0 0 9 0 0 0 20 12 0 0 0 0 0 0 0 9 0 0 0 21 12 0 0 0 0 0 0 0 9 0 0 0 24 12 0 0 0 0 0 0 0 10 0 0 0 4 12 0 0 0 0 0 0 0 10 0 0 0 12 12 0 0 0 0 0 0 0 10 0 0 0 14 12 0 0 0 0 0 0 0 10 0 0 0 17 12 0 0 0 0 0 0 0 10 0 0 0 23 12 0 0 0 0 0 0 0 11 0 0 0 4 12 0 0 0 0 0 0 0 11 0 0 0 6 12 0 0 0 0 0 0 0 11 0 0 0 7 12 0 0 0 0 0 0 0 11 0 0 0 11 12 0 0 0 0 0 0 0 11 0 0 0 17 12 0 0 0 0 0 0 0 11 0 0 0 22 12 0 0 0 0 0 0 0 12 0 0 0 8 12 0 0 0 0 0 0 0 12 0 0 0 10 12 0 0 0 0 0 0 0 12 0 0 0 13 12 0 0 0 0 0 0 0 12 0 0 0 14 12 0 0 0 0 0 0 0 12 0 0 0 16 12 0 0 0 0 0 0 0 12 0 0 0 21 12 0 0 0 0 0 0 0 12 0 0 0 22 12 0 0 0 0 0 0 0 12 0 0 0 23 12 0 0 0 0 0 0 0 13 0 0 0 4 12 0 0 0 0 0 0 0 13 0 0 0 14 12 0 0 0 0 0 0 0 13 0 0 0 17 12 0 0 0 0 0 0 0 13 0 0 0 18 12 0 0 0 0 0 0 0 13 0 0 0 23 12 0 0 0 0 0 0 0 14 0 0 0 2 12 0 0 0 0 0 0 0 14 0 0 0 8 12 0 0 0 0 0 0 0 14 0 0 0 9 12 0 0 0 0 0 0 0 14 0 0 0 16 12 0 0 0 0 0 0 0 14 0 0 0 23 12 0 0 0 0 0 0 0 15 0 0 0 1 12 0 0 0 0 0 0 0 16 0 0 0 9 12 0 0 0 0 0 0 0 16 0 0 0 13 12 0 0 0 0 0 0 0 16 0 0 0 18 12 0 0 0 0 0 0 0 17 0 0 0 2 12 0 0 0 0 0 0 0 17 0 0 0 5 12 0 0 0 0 0 0 0 17 0 0 0 18 12 0 0 0 0 0 0 0 18 0 0 0 5 12 0 0 0 0 0 0 0 18 0 0 0 12 12 0 0 0 0 0 0 0 18 0 0 0 19 12 0 0 0 0 0 0 0 18 0 0 0 20 12 0 0 0 0 0 0 0 18 0 0 0 22 12 0 0 0 0 0 0 0 19 0 0 0 3 12 0 0 0 0 0 0 0 19 0 0 0 11 12 0 0 0 0 0 0 0 19 0 0 0 12 12 0 0 0 0 0 0 0 19 0 0 0 14 12 0 0 0 0 0 0 0 19 0 0 0 16 12 0 0 0 0 0 0 0 19 0 0 0 18 12 0 0 0 0 0 0 0 20 0 0 0 4 12 0 0 0 0 0 0 0 20 0 0 0 7 12 0 0 0 0 0 0 0 20 0 0 0 11 12 0 0 0 0 0 0 0 20 0 0 0 13 12 0 0 0 0 0 0 0 20 0 0 0 14 12 0 0 0 0 0 0 0 20 0 0 0 15 12 0 0 0 0 0 0 0 20 0 0 0 16 12 0 0 0 0 0 0 0 20 0 0 0 21 12 0 0 0 0 0 0 0 21 0 0 0 8 12 0 0 0 0 0 0 0 21 0 0 0 9 12 0 0 0 0 0 0 0 21 0 0 0 11 12 0 0 0 0 0 0 0 21 0 0 0 12 12 0 0 0 0 0 0 0 21 0 0 0 13 12 0 0 0 0 0 0 0 21 0 0 0 15 12 0 0 0 0 0 0 0 21 0 0 0 17 12 0 0 0 0 0 0 0 21 0 0 0 22 12 0 0 0 0 0 0 0 21 0 0 0 23 12 0 0 0 0 0 0 0 22 0 0 0 3 12 0 0 0 0 0 0 0 22 0 0 0 7 12 0 0 0 0 0 0 0 22 0 0 0 10 12 0 0 0 0 0 0 0 22 0 0 0 15 12 0 0 0 0 0 0 0 22 0 0 0 16 12 0 0 0 0 0 0 0 22 0 0 0 19 12 0 0 0 0 0 0 0 22 0 0 0 20 12 0 0 0 0 0 0 0 23 0 0 0 2 12 0 0 0 0 0 0 0 23 0 0 0 4 12 0 0 0 0 0 0 0 23 0 0 0 6 12 0 0 0 0 0 0 0 23 0 0 0 7 12 0 0 0 0 0 0 0 23 0 0 0 14 12 0 0 0 0 0 0 0 23 0 0 0 16 12 0 0 0 0 0 0 0 23 0 0 0 22 12 0 0 0 0 0 0 0 24 0 0 0 15 12 0 0 0 0 0 0 0 24 0 0 0 17 12 0 0 0 0 0 0 0 24 0 0 0 24"));
static CONSTANT_49: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_50: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("387 8 0 0 0 1 0 0 0 1 8 0 0 0 1 0 0 0 4 8 0 0 0 1 0 0 0 25 8 0 0 0 2 0 0 0 2 8 0 0 0 2 0 0 0 3 8 0 0 0 2 0 0 0 12 8 0 0 0 3 0 0 0 2 8 0 0 0 3 0 0 0 3 8 0 0 0 3 0 0 0 8 8 0 0 0 4 0 0 0 1 8 0 0 0 4 0 0 0 4 8 0 0 0 4 0 0 0 17 8 0 0 0 5 0 0 0 5 8 0 0 0 5 0 0 0 6 8 0 0 0 5 0 0 0 8 8 0 0 0 6 0 0 0 5 8 0 0 0 6 0 0 0 6 8 0 0 0 6 0 0 0 20 8 0 0 0 7 0 0 0 7 8 0 0 0 7 0 0 0 16 8 0 0 0 7 0 0 0 18 8 0 0 0 8 0 0 0 3 8 0 0 0 8 0 0 0 5 8 0 0 0 8 0 0 0 8 8 0 0 0 9 0 0 0 9 8 0 0 0 9 0 0 0 16 8 0 0 0 9 0 0 0 21 8 0 0 0 10 0 0 0 10 8 0 0 0 10 0 0 0 24 8 0 0 0 10 0 0 0 90 8 0 0 0 11 0 0 0 11 8 0 0 0 11 0 0 0 14 8 0 0 0 11 0 0 0 23 8 0 0 0 12 0 0 0 2 8 0 0 0 12 0 0 0 12 8 0 0 0 12 0 0 0 19 8 0 0 0 13 0 0 0 13 8 0 0 0 13 0 0 0 17 8 0 0 0 13 0 0 0 22 8 0 0 0 14 0 0 0 11 8 0 0 0 14 0 0 0 14 8 0 0 0 14 0 0 0 22 8 0 0 0 15 0 0 0 15 8 0 0 0 15 0 0 0 20 8 0 0 0 15 0 0 0 21 8 0 0 0 16 0 0 0 7 8 0 0 0 16 0 0 0 9 8 0 0 0 16 0 0 0 16 8 0 0 0 17 0 0 0 4 8 0 0 0 17 0 0 0 13 8 0 0 0 17 0 0 0 17 8 0 0 0 18 0 0 0 7 8 0 0 0 18 0 0 0 18 8 0 0 0 18 0 0 0 24 8 0 0 0 19 0 0 0 12 8 0 0 0 19 0 0 0 19 8 0 0 0 19 0 0 0 23 8 0 0 0 20 0 0 0 6 8 0 0 0 20 0 0 0 15 8 0 0 0 20 0 0 0 20 8 0 0 0 21 0 0 0 9 8 0 0 0 21 0 0 0 15 8 0 0 0 21 0 0 0 21 8 0 0 0 22 0 0 0 13 8 0 0 0 22 0 0 0 14 8 0 0 0 22 0 0 0 22 8 0 0 0 23 0 0 0 11 8 0 0 0 23 0 0 0 19 8 0 0 0 23 0 0 0 23 8 0 0 0 24 0 0 0 10 8 0 0 0 24 0 0 0 18 8 0 0 0 24 0 0 0 24 8 0 0 0 25 0 0 0 1 8 0 0 0 25 0 0 0 25 8 0 0 0 25 0 0 0 26 8 0 0 0 26 0 0 0 25 8 0 0 0 26 0 0 0 26 8 0 0 0 26 0 0 0 39 8 0 0 0 27 0 0 0 27 8 0 0 0 27 0 0 0 28 8 0 0 0 27 0 0 0 29 8 0 0 0 28 0 0 0 27 8 0 0 0 28 0 0 0 28 8 0 0 0 28 0 0 0 30 8 0 0 0 29 0 0 0 27 8 0 0 0 29 0 0 0 29 8 0 0 0 29 0 0 0 89 8 0 0 0 30 0 0 0 28 8 0 0 0 30 0 0 0 30 8 0 0 0 30 0 0 0 31 8 0 0 0 31 0 0 0 30 8 0 0 0 31 0 0 0 31 8 0 0 0 31 0 0 0 32 8 0 0 0 32 0 0 0 31 8 0 0 0 32 0 0 0 32 8 0 0 0 32 0 0 0 33 8 0 0 0 33 0 0 0 32 8 0 0 0 33 0 0 0 33 8 0 0 0 33 0 0 0 34 8 0 0 0 34 0 0 0 33 8 0 0 0 34 0 0 0 34 8 0 0 0 34 0 0 0 35 8 0 0 0 35 0 0 0 34 8 0 0 0 35 0 0 0 35 8 0 0 0 35 0 0 0 36 8 0 0 0 36 0 0 0 35 8 0 0 0 36 0 0 0 36 8 0 0 0 36 0 0 0 37 8 0 0 0 37 0 0 0 36 8 0 0 0 37 0 0 0 37 8 0 0 0 37 0 0 0 38 8 0 0 0 38 0 0 0 37 8 0 0 0 38 0 0 0 38 8 0 0 0 38 0 0 0 40 8 0 0 0 39 0 0 0 26 8 0 0 0 39 0 0 0 39 8 0 0 0 39 0 0 0 50 8 0 0 0 40 0 0 0 38 8 0 0 0 40 0 0 0 40 8 0 0 0 40 0 0 0 41 8 0 0 0 41 0 0 0 40 8 0 0 0 41 0 0 0 41 8 0 0 0 41 0 0 0 42 8 0 0 0 42 0 0 0 41 8 0 0 0 42 0 0 0 42 8 0 0 0 42 0 0 0 43 8 0 0 0 43 0 0 0 42 8 0 0 0 43 0 0 0 43 8 0 0 0 43 0 0 0 44 8 0 0 0 44 0 0 0 43 8 0 0 0 44 0 0 0 44 8 0 0 0 44 0 0 0 45 8 0 0 0 45 0 0 0 44 8 0 0 0 45 0 0 0 45 8 0 0 0 45 0 0 0 46 8 0 0 0 46 0 0 0 45 8 0 0 0 46 0 0 0 46 8 0 0 0 46 0 0 0 47 8 0 0 0 47 0 0 0 46 8 0 0 0 47 0 0 0 47 8 0 0 0 47 0 0 0 48 8 0 0 0 48 0 0 0 47 8 0 0 0 48 0 0 0 48 8 0 0 0 48 0 0 0 49 8 0 0 0 49 0 0 0 48 8 0 0 0 49 0 0 0 49 8 0 0 0 49 0 0 0 51 8 0 0 0 50 0 0 0 39 8 0 0 0 50 0 0 0 50 8 0 0 0 50 0 0 0 61 8 0 0 0 51 0 0 0 49 8 0 0 0 51 0 0 0 51 8 0 0 0 51 0 0 0 52 8 0 0 0 52 0 0 0 51 8 0 0 0 52 0 0 0 52 8 0 0 0 52 0 0 0 53 8 0 0 0 53 0 0 0 52 8 0 0 0 53 0 0 0 53 8 0 0 0 53 0 0 0 54 8 0 0 0 54 0 0 0 53 8 0 0 0 54 0 0 0 54 8 0 0 0 54 0 0 0 55 8 0 0 0 55 0 0 0 54 8 0 0 0 55 0 0 0 55 8 0 0 0 55 0 0 0 56 8 0 0 0 56 0 0 0 55 8 0 0 0 56 0 0 0 56 8 0 0 0 56 0 0 0 57 8 0 0 0 57 0 0 0 56 8 0 0 0 57 0 0 0 57 8 0 0 0 57 0 0 0 58 8 0 0 0 58 0 0 0 57 8 0 0 0 58 0 0 0 58 8 0 0 0 58 0 0 0 59 8 0 0 0 59 0 0 0 58 8 0 0 0 59 0 0 0 59 8 0 0 0 59 0 0 0 60 8 0 0 0 60 0 0 0 59 8 0 0 0 60 0 0 0 60 8 0 0 0 60 0 0 0 62 8 0 0 0 61 0 0 0 50 8 0 0 0 61 0 0 0 61 8 0 0 0 61 0 0 0 72 8 0 0 0 62 0 0 0 60 8 0 0 0 62 0 0 0 62 8 0 0 0 62 0 0 0 63 8 0 0 0 63 0 0 0 62 8 0 0 0 63 0 0 0 63 8 0 0 0 63 0 0 0 64 8 0 0 0 64 0 0 0 63 8 0 0 0 64 0 0 0 64 8 0 0 0 64 0 0 0 65 8 0 0 0 65 0 0 0 64 8 0 0 0 65 0 0 0 65 8 0 0 0 65 0 0 0 66 8 0 0 0 66 0 0 0 65 8 0 0 0 66 0 0 0 66 8 0 0 0 66 0 0 0 67 8 0 0 0 67 0 0 0 66 8 0 0 0 67 0 0 0 67 8 0 0 0 67 0 0 0 68 8 0 0 0 68 0 0 0 67 8 0 0 0 68 0 0 0 68 8 0 0 0 68 0 0 0 69 8 0 0 0 69 0 0 0 68 8 0 0 0 69 0 0 0 69 8 0 0 0 69 0 0 0 70 8 0 0 0 70 0 0 0 69 8 0 0 0 70 0 0 0 70 8 0 0 0 70 0 0 0 71 8 0 0 0 71 0 0 0 70 8 0 0 0 71 0 0 0 71 8 0 0 0 71 0 0 0 73 8 0 0 0 72 0 0 0 61 8 0 0 0 72 0 0 0 72 8 0 0 0 72 0 0 0 83 8 0 0 0 73 0 0 0 71 8 0 0 0 73 0 0 0 73 8 0 0 0 73 0 0 0 74 8 0 0 0 74 0 0 0 73 8 0 0 0 74 0 0 0 74 8 0 0 0 74 0 0 0 75 8 0 0 0 75 0 0 0 74 8 0 0 0 75 0 0 0 75 8 0 0 0 75 0 0 0 76 8 0 0 0 76 0 0 0 75 8 0 0 0 76 0 0 0 76 8 0 0 0 76 0 0 0 77 8 0 0 0 77 0 0 0 76 8 0 0 0 77 0 0 0 77 8 0 0 0 77 0 0 0 78 8 0 0 0 78 0 0 0 77 8 0 0 0 78 0 0 0 78 8 0 0 0 78 0 0 0 79 8 0 0 0 79 0 0 0 78 8 0 0 0 79 0 0 0 79 8 0 0 0 79 0 0 0 80 8 0 0 0 80 0 0 0 79 8 0 0 0 80 0 0 0 80 8 0 0 0 80 0 0 0 81 8 0 0 0 81 0 0 0 80 8 0 0 0 81 0 0 0 81 8 0 0 0 81 0 0 0 82 8 0 0 0 82 0 0 0 81 8 0 0 0 82 0 0 0 82 8 0 0 0 82 0 0 0 84 8 0 0 0 83 0 0 0 72 8 0 0 0 83 0 0 0 83 8 0 0 0 83 0 0 0 89 8 0 0 0 84 0 0 0 82 8 0 0 0 84 0 0 0 84 8 0 0 0 84 0 0 0 85 8 0 0 0 85 0 0 0 84 8 0 0 0 85 0 0 0 85 8 0 0 0 85 0 0 0 86 8 0 0 0 86 0 0 0 85 8 0 0 0 86 0 0 0 86 8 0 0 0 86 0 0 0 87 8 0 0 0 87 0 0 0 86 8 0 0 0 87 0 0 0 87 8 0 0 0 87 0 0 0 88 8 0 0 0 89 0 0 0 29 8 0 0 0 89 0 0 0 83 8 0 0 0 89 0 0 0 89 8 0 0 0 90 0 0 0 10 8 0 0 0 90 0 0 0 90 8 0 0 0 90 0 0 0 91 8 0 0 0 91 0 0 0 90 8 0 0 0 91 0 0 0 91 8 0 0 0 91 0 0 0 92 8 0 0 0 92 0 0 0 91 8 0 0 0 92 0 0 0 92 8 0 0 0 92 0 0 0 93 8 0 0 0 93 0 0 0 92 8 0 0 0 93 0 0 0 93 8 0 0 0 93 0 0 0 94 8 0 0 0 94 0 0 0 93 8 0 0 0 94 0 0 0 94 8 0 0 0 94 0 0 0 95 8 0 0 0 95 0 0 0 94 8 0 0 0 95 0 0 0 95 8 0 0 0 95 0 0 0 96 8 0 0 0 96 0 0 0 95 8 0 0 0 96 0 0 0 96 8 0 0 0 96 0 0 0 97 8 0 0 0 97 0 0 0 96 8 0 0 0 97 0 0 0 97 8 0 0 0 97 0 0 0 98 8 0 0 0 98 0 0 0 97 8 0 0 0 98 0 0 0 98 8 0 0 0 98 0 0 0 99 8 0 0 0 99 0 0 0 98 8 0 0 0 99 0 0 0 99 8 0 0 0 99 0 0 0 100 8 0 0 0 100 0 0 0 99 8 0 0 0 100 0 0 0 100 8 0 0 0 100 0 0 0 101 8 0 0 0 101 0 0 0 100 8 0 0 0 101 0 0 0 101 8 0 0 0 101 0 0 0 102 8 0 0 0 102 0 0 0 101 8 0 0 0 102 0 0 0 102 8 0 0 0 102 0 0 0 103 8 0 0 0 103 0 0 0 102 8 0 0 0 103 0 0 0 103 8 0 0 0 103 0 0 0 104 8 0 0 0 104 0 0 0 103 8 0 0 0 104 0 0 0 104 8 0 0 0 104 0 0 0 105 8 0 0 0 105 0 0 0 104 8 0 0 0 105 0 0 0 105 8 0 0 0 105 0 0 0 106 8 0 0 0 106 0 0 0 105 8 0 0 0 106 0 0 0 106 8 0 0 0 106 0 0 0 107 8 0 0 0 107 0 0 0 106 8 0 0 0 107 0 0 0 107 8 0 0 0 107 0 0 0 108 8 0 0 0 108 0 0 0 107 8 0 0 0 108 0 0 0 108 8 0 0 0 108 0 0 0 109 8 0 0 0 109 0 0 0 108 8 0 0 0 109 0 0 0 109 8 0 0 0 109 0 0 0 110 8 0 0 0 110 0 0 0 109 8 0 0 0 110 0 0 0 110 8 0 0 0 110 0 0 0 111 8 0 0 0 111 0 0 0 110 8 0 0 0 111 0 0 0 111 8 0 0 0 111 0 0 0 112 8 0 0 0 112 0 0 0 111 8 0 0 0 112 0 0 0 112 8 0 0 0 112 0 0 0 113 8 0 0 0 113 0 0 0 112 8 0 0 0 113 0 0 0 113 8 0 0 0 113 0 0 0 114 8 0 0 0 114 0 0 0 113 8 0 0 0 114 0 0 0 114 8 0 0 0 114 0 0 0 115 8 0 0 0 115 0 0 0 114 8 0 0 0 115 0 0 0 115 8 0 0 0 115 0 0 0 116 8 0 0 0 116 0 0 0 115 8 0 0 0 116 0 0 0 116 8 0 0 0 116 0 0 0 117 8 0 0 0 117 0 0 0 116 8 0 0 0 117 0 0 0 117 8 0 0 0 117 0 0 0 118 8 0 0 0 118 0 0 0 117 8 0 0 0 118 0 0 0 118 8 0 0 0 118 0 0 0 119 8 0 0 0 119 0 0 0 118 8 0 0 0 119 0 0 0 119 8 0 0 0 119 0 0 0 120 8 0 0 0 120 0 0 0 119 8 0 0 0 120 0 0 0 120 8 0 0 0 120 0 0 0 121 8 0 0 0 121 0 0 0 120 8 0 0 0 121 0 0 0 121 8 0 0 0 121 0 0 0 122 8 0 0 0 122 0 0 0 121 8 0 0 0 122 0 0 0 122 8 0 0 0 122 0 0 0 123 8 0 0 0 123 0 0 0 122 8 0 0 0 123 0 0 0 123 8 0 0 0 123 0 0 0 124 8 0 0 0 124 0 0 0 123 8 0 0 0 124 0 0 0 124 8 0 0 0 124 0 0 0 125 8 0 0 0 125 0 0 0 124 8 0 0 0 125 0 0 0 125 8 0 0 0 125 0 0 0 126 8 0 0 0 126 0 0 0 125 8 0 0 0 126 0 0 0 126 8 0 0 0 126 0 0 0 127 8 0 0 0 127 0 0 0 126 8 0 0 0 127 0 0 0 127 8 0 0 0 127 0 0 0 128 8 0 0 0 128 0 0 0 127 8 0 0 0 128 0 0 0 128 8 0 0 0 128 0 0 0 129 8 0 0 0 129 0 0 0 128 8 0 0 0 129 0 0 0 129 8 0 0 0 129 0 0 0 130 8 0 0 0 130 0 0 0 129 8 0 0 0 130 0 0 0 130 8 0 0 0 130 0 0 0 131"));
static CONSTANT_51: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_52: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 132"));
static CONSTANT_53: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_54: std::sync::LazyLock<Vec<Path>> = std::sync::LazyLock::new(|| paths_text("133 4 0 0 0 25 4 0 0 0 27 4 0 0 0 28 4 0 0 0 30 4 0 0 0 31 4 0 0 0 32 4 0 0 0 33 4 0 0 0 34 4 0 0 0 35 4 0 0 0 36 4 0 0 0 37 4 0 0 0 26 4 0 0 0 38 4 0 0 0 40 4 0 0 0 41 4 0 0 0 42 4 0 0 0 43 4 0 0 0 44 4 0 0 0 45 4 0 0 0 46 4 0 0 0 47 4 0 0 0 48 4 0 0 0 39 4 0 0 0 49 4 0 0 0 51 4 0 0 0 52 4 0 0 0 53 4 0 0 0 54 4 0 0 0 55 4 0 0 0 56 4 0 0 0 57 4 0 0 0 58 4 0 0 0 59 4 0 0 0 50 4 0 0 0 60 4 0 0 0 62 4 0 0 0 63 4 0 0 0 64 4 0 0 0 65 4 0 0 0 66 4 0 0 0 67 4 0 0 0 68 4 0 0 0 69 4 0 0 0 70 4 0 0 0 61 4 0 0 0 71 4 0 0 0 73 4 0 0 0 74 4 0 0 0 75 4 0 0 0 76 4 0 0 0 77 4 0 0 0 78 4 0 0 0 79 4 0 0 0 80 4 0 0 0 81 4 0 0 0 72 4 0 0 0 82 4 0 0 0 84 4 0 0 0 85 4 0 0 0 86 4 0 0 0 87 4 0 0 0 88 4 0 0 0 83 4 0 0 0 89 4 0 0 0 29 4 0 0 0 1 4 0 0 0 4 4 0 0 0 2 4 0 0 0 3 4 0 0 0 8 4 0 0 0 5 4 0 0 0 6 4 0 0 0 20 4 0 0 0 15 4 0 0 0 21 4 0 0 0 9 4 0 0 0 16 4 0 0 0 17 4 0 0 0 7 4 0 0 0 18 4 0 0 0 24 4 0 0 0 10 4 0 0 0 90 4 0 0 0 91 4 0 0 0 92 4 0 0 0 93 4 0 0 0 94 4 0 0 0 95 4 0 0 0 13 4 0 0 0 96 4 0 0 0 97 4 0 0 0 98 4 0 0 0 99 4 0 0 0 100 4 0 0 0 101 4 0 0 0 102 4 0 0 0 103 4 0 0 0 104 4 0 0 0 105 4 0 0 0 22 4 0 0 0 106 4 0 0 0 107 4 0 0 0 108 4 0 0 0 109 4 0 0 0 110 4 0 0 0 111 4 0 0 0 112 4 0 0 0 113 4 0 0 0 114 4 0 0 0 115 4 0 0 0 14 4 0 0 0 116 4 0 0 0 117 4 0 0 0 118 4 0 0 0 119 4 0 0 0 120 4 0 0 0 121 4 0 0 0 122 4 0 0 0 123 4 0 0 0 124 4 0 0 0 125 4 0 0 0 11 4 0 0 0 126 4 0 0 0 127 4 0 0 0 128 4 0 0 0 129 4 0 0 0 130 4 0 0 0 131 4 0 0 0 23 4 0 0 0 19 4 0 0 0 12 4 0 0 0 0 4 0 0 0 132"));
fn routine_0(c: &mut Context) -> Space {
  let v0_2: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_5: Space = routine_1(c, &(*CONSTANT_2), &(*CONSTANT_3));
  let v0_6: Space = unite(&(v0_2),&(v0_5));
  let v0_9: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_5));
  let v0_10: Space = unite(&(v0_6),&(v0_9));
  let v0_13: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_7));
  let v0_14: Space = unite(&(v0_10),&(v0_13));
  let v0_17: Space = routine_1(c, &(*CONSTANT_8), &(*CONSTANT_9));
  let v0_18: Space = unite(&(v0_14),&(v0_17));
  let v0_21: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_11));
  let v0_22: Space = unite(&(v0_18),&(v0_21));
  let v0_25: Space = routine_1(c, &(*CONSTANT_12), &(*CONSTANT_13));
  let v0_26: Space = unite(&(v0_22),&(v0_25));
  let v0_29: Space = routine_1(c, &(*CONSTANT_14), &(*CONSTANT_15));
  let v0_30: Space = unite(&(v0_26),&(v0_29));
  let v0_33: Space = routine_1(c, &(*CONSTANT_16), &(*CONSTANT_17));
  let v0_34: Space = unite(&(v0_30),&(v0_33));
  let v0_37: Space = routine_1(c, &(*CONSTANT_18), &(*CONSTANT_19));
  let v0_38: Space = unite(&(v0_34),&(v0_37));
  let v0_41: Space = routine_1(c, &(*CONSTANT_20), &(*CONSTANT_21));
  let v0_42: Space = unite(&(v0_38),&(v0_41));
  let v0_45: Space = routine_1(c, &(*CONSTANT_22), &(*CONSTANT_23));
  let v0_46: Space = unite(&(v0_42),&(v0_45));
  let v0_49: Space = routine_1(c, &(*CONSTANT_24), &(*CONSTANT_25));
  let v0_50: Space = unite(&(v0_46),&(v0_49));
  let v0_53: Space = routine_1(c, &(*CONSTANT_26), &(*CONSTANT_27));
  let v0_54: Space = unite(&(v0_50),&(v0_53));
  let v0_57: Space = routine_1(c, &(*CONSTANT_28), &(*CONSTANT_29));
  let v0_58: Space = unite(&(v0_54),&(v0_57));
  let v0_61: Space = routine_1(c, &(*CONSTANT_30), &(*CONSTANT_31));
  let v0_62: Space = unite(&(v0_58),&(v0_61));
  let v0_65: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_33));
  let v0_66: Space = unite(&(v0_62),&(v0_65));
  let v0_69: Space = routine_1(c, &(*CONSTANT_34), &(*CONSTANT_35));
  let v0_70: Space = unite(&(v0_66),&(v0_69));
  let v0_73: Space = routine_1(c, &(*CONSTANT_36), &(*CONSTANT_37));
  let v0_74: Space = unite(&(v0_70),&(v0_73));
  let v0_77: Space = routine_1(c, &(*CONSTANT_38), &(*CONSTANT_39));
  let v0_78: Space = unite(&(v0_74),&(v0_77));
  let v0_81: Space = routine_1(c, &(*CONSTANT_40), &(*CONSTANT_41));
  let v0_82: Space = unite(&(v0_78),&(v0_81));
  let v0_85: Space = routine_1(c, &(*CONSTANT_42), &(*CONSTANT_43));
  let v0_86: Space = unite(&(v0_82),&(v0_85));
  let v0_89: Space = routine_1(c, &(*CONSTANT_44), &(*CONSTANT_45));
  let v0_90: Space = unite(&(v0_86),&(v0_89));
  let v0_93: Space = routine_1(c, &(*CONSTANT_46), &(*CONSTANT_47));
  let v0_94: Space = unite(&(v0_90),&(v0_93));
  let mut v0_96 = Space::new();
  let mut v0_96_cursor = (v0_94).read_zipper();
  for v0_96_byte in v0_96_cursor.child_mask().iter() {
    v0_96_cursor.descend_to_byte(v0_96_byte);
    let v0_96_tail = v0_96_cursor.make_map();
    v0_96_cursor.ascend(1);
    let v0_96_head = Path::from_slice(&[v0_96_byte]);
    let mut v1_2 = Space::new();
    let mut v1_2_cursor = (v0_96_tail).read_zipper();
    for v1_2_byte in v1_2_cursor.child_mask().iter() {
      v1_2_cursor.descend_to_byte(v1_2_byte);
      let v1_2_tail = v1_2_cursor.make_map();
      v1_2_cursor.ascend(1);
      let v1_2_head = Path::from_slice(&[v1_2_byte]);
      let v2_2: Path = concat_path(&(v0_96_head),&(v1_2_head));
      let mut v2_3 = Space::new();
      let mut v2_3_cursor = (v1_2_tail).read_zipper();
      for v2_3_byte in v2_3_cursor.child_mask().iter() {
        v2_3_cursor.descend_to_byte(v2_3_byte);
        let v2_3_tail = v2_3_cursor.make_map();
        v2_3_cursor.ascend(1);
        let v2_3_head = Path::from_slice(&[v2_3_byte]);
        let v3_2: Path = concat_path(&(v2_2),&(v2_3_head));
        let mut v3_3 = Space::new();
        let mut v3_3_cursor = (v2_3_tail).read_zipper();
        for v3_3_byte in v3_3_cursor.child_mask().iter() {
          v3_3_cursor.descend_to_byte(v3_3_byte);
          let v3_3_tail = v3_3_cursor.make_map();
          v3_3_cursor.ascend(1);
          let v3_3_head = Path::from_slice(&[v3_3_byte]);
          let v4_2: Path = concat_path(&(v3_2),&(v3_3_head));
          let v4_3: Space = routine_2(c, &(v4_2), &(v3_3_tail), &(*CONSTANT_48));
          drop(v4_2);
          v3_3.join_into((v4_3).clone());
        }
        drop(v3_3_cursor);
        drop(v3_2);
        v2_3.join_into((v3_3).clone());
      }
      drop(v2_3_cursor);
      drop(v2_2);
      v1_2.join_into((v2_3).clone());
    }
    drop(v1_2_cursor);
    v0_96.join_into((v1_2).clone());
  }
  drop(v0_96_cursor);
  let v0_99: Space = routine_3(c, &(*CONSTANT_0), &(*CONSTANT_1), &(*CONSTANT_48));
  let v0_100: Space = unite(&(v0_96),&(v0_99));
  let v0_103: Space = routine_3(c, &(*CONSTANT_2), &(*CONSTANT_3), &(*CONSTANT_48));
  let v0_104: Space = unite(&(v0_100),&(v0_103));
  let v0_107: Space = routine_3(c, &(*CONSTANT_4), &(*CONSTANT_5), &(*CONSTANT_48));
  let v0_108: Space = unite(&(v0_104),&(v0_107));
  let v0_111: Space = routine_3(c, &(*CONSTANT_6), &(*CONSTANT_7), &(*CONSTANT_48));
  let v0_112: Space = unite(&(v0_108),&(v0_111));
  let v0_115: Space = routine_3(c, &(*CONSTANT_8), &(*CONSTANT_9), &(*CONSTANT_48));
  let v0_116: Space = unite(&(v0_112),&(v0_115));
  let v0_119: Space = routine_3(c, &(*CONSTANT_10), &(*CONSTANT_11), &(*CONSTANT_48));
  let v0_120: Space = unite(&(v0_116),&(v0_119));
  let v0_123: Space = routine_3(c, &(*CONSTANT_12), &(*CONSTANT_13), &(*CONSTANT_48));
  let v0_124: Space = unite(&(v0_120),&(v0_123));
  let v0_127: Space = routine_3(c, &(*CONSTANT_14), &(*CONSTANT_15), &(*CONSTANT_48));
  let v0_128: Space = unite(&(v0_124),&(v0_127));
  let v0_131: Space = routine_3(c, &(*CONSTANT_16), &(*CONSTANT_17), &(*CONSTANT_48));
  let v0_132: Space = unite(&(v0_128),&(v0_131));
  let v0_135: Space = routine_3(c, &(*CONSTANT_18), &(*CONSTANT_19), &(*CONSTANT_48));
  let v0_136: Space = unite(&(v0_132),&(v0_135));
  let v0_139: Space = routine_3(c, &(*CONSTANT_20), &(*CONSTANT_21), &(*CONSTANT_48));
  let v0_140: Space = unite(&(v0_136),&(v0_139));
  let v0_143: Space = routine_3(c, &(*CONSTANT_22), &(*CONSTANT_23), &(*CONSTANT_48));
  let v0_144: Space = unite(&(v0_140),&(v0_143));
  let v0_147: Space = routine_3(c, &(*CONSTANT_24), &(*CONSTANT_25), &(*CONSTANT_48));
  let v0_148: Space = unite(&(v0_144),&(v0_147));
  let v0_151: Space = routine_3(c, &(*CONSTANT_26), &(*CONSTANT_27), &(*CONSTANT_48));
  let v0_152: Space = unite(&(v0_148),&(v0_151));
  let v0_155: Space = routine_3(c, &(*CONSTANT_28), &(*CONSTANT_29), &(*CONSTANT_48));
  let v0_156: Space = unite(&(v0_152),&(v0_155));
  let v0_159: Space = routine_3(c, &(*CONSTANT_30), &(*CONSTANT_31), &(*CONSTANT_48));
  let v0_160: Space = unite(&(v0_156),&(v0_159));
  let v0_163: Space = routine_3(c, &(*CONSTANT_32), &(*CONSTANT_33), &(*CONSTANT_48));
  let v0_164: Space = unite(&(v0_160),&(v0_163));
  let v0_167: Space = routine_3(c, &(*CONSTANT_34), &(*CONSTANT_35), &(*CONSTANT_48));
  let v0_168: Space = unite(&(v0_164),&(v0_167));
  let v0_171: Space = routine_3(c, &(*CONSTANT_36), &(*CONSTANT_37), &(*CONSTANT_48));
  let v0_172: Space = unite(&(v0_168),&(v0_171));
  let v0_175: Space = routine_3(c, &(*CONSTANT_38), &(*CONSTANT_39), &(*CONSTANT_48));
  let v0_176: Space = unite(&(v0_172),&(v0_175));
  let v0_179: Space = routine_3(c, &(*CONSTANT_40), &(*CONSTANT_41), &(*CONSTANT_48));
  let v0_180: Space = unite(&(v0_176),&(v0_179));
  let v0_183: Space = routine_3(c, &(*CONSTANT_42), &(*CONSTANT_43), &(*CONSTANT_48));
  let v0_184: Space = unite(&(v0_180),&(v0_183));
  let v0_187: Space = routine_3(c, &(*CONSTANT_44), &(*CONSTANT_45), &(*CONSTANT_48));
  let v0_188: Space = unite(&(v0_184),&(v0_187));
  let v0_191: Space = routine_3(c, &(*CONSTANT_46), &(*CONSTANT_47), &(*CONSTANT_48));
  let v0_192: Space = unite(&(v0_188),&(v0_191));
  let v0_194: Space = wrap(&(v0_192),&(*CONSTANT_49));
  (v0_194).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v5_4: Space = unwrap(&(*CONSTANT_50),&(*p0));
  let mut v5_5 = Space::new();
  let mut v5_5_cursor = (*s0).read_zipper();
  for v5_5_byte in v5_5_cursor.child_mask().iter() {
    v5_5_cursor.descend_to_byte(v5_5_byte);
    let v5_5_tail = v5_5_cursor.make_map();
    v5_5_cursor.ascend(1);
    let v5_5_head = Path::from_slice(&[v5_5_byte]);
    let v6_2: Space = unwrap(&(*CONSTANT_50),&(v5_5_head));
    let mut v6_3 = Space::new();
    let mut v6_3_cursor = (v5_5_tail).read_zipper();
    for v6_3_byte in v6_3_cursor.child_mask().iter() {
      v6_3_cursor.descend_to_byte(v6_3_byte);
      let v6_3_tail = v6_3_cursor.make_map();
      v6_3_cursor.ascend(1);
      let v6_3_head = Path::from_slice(&[v6_3_byte]);
      let v7_2: Path = concat_path(&(v5_5_head),&(v6_3_head));
      let v7_3: Space = unwrap(&(v6_2),&(v6_3_head));
      let mut v7_4 = Space::new();
      let mut v7_4_cursor = (v6_3_tail).read_zipper();
      for v7_4_byte in v7_4_cursor.child_mask().iter() {
        v7_4_cursor.descend_to_byte(v7_4_byte);
        let v7_4_tail = v7_4_cursor.make_map();
        v7_4_cursor.ascend(1);
        let v7_4_head = Path::from_slice(&[v7_4_byte]);
        let v8_2: Space = unwrap(&(v7_3),&(v7_4_head));
        let v8_3: Path = concat_path(&(v7_2),&(v7_4_head));
        let mut v8_4 = Space::new();
        let mut v8_4_cursor = (v7_4_tail).read_zipper();
        for v8_4_byte in v8_4_cursor.child_mask().iter() {
          v8_4_cursor.descend_to_byte(v8_4_byte);
          let v8_4_tail = v8_4_cursor.make_map();
          v8_4_cursor.ascend(1);
          let v8_4_head = Path::from_slice(&[v8_4_byte]);
          let v9_2: Space = unwrap(&(v8_2),&(v8_4_head));
          let v9_3: Space = compose(&(v5_4),&(v9_2));
          drop(v9_2);
          let v9_4: Path = concat_path(&(v8_3),&(v8_4_head));
          let v9_5: Path = concat_path(&(*p0),&(v9_4));
          drop(v9_4);
          let v9_6: Space = singleton(&(v9_5));
          drop(v9_5);
          let v9_7: Space = subtract(&(v9_3),&(v9_6));
          drop(v9_3);
          drop(v9_6);
          v8_4.join_into((v9_7).clone());
        }
        drop(v8_4_cursor);
        drop(v8_2);
        drop(v8_3);
        v7_4.join_into((v8_4).clone());
      }
      drop(v7_4_cursor);
      drop(v7_2);
      drop(v7_3);
      v6_3.join_into((v7_4).clone());
    }
    drop(v6_3_cursor);
    drop(v6_2);
    v5_5.join_into((v6_3).clone());
  }
  drop(v5_5_cursor);
  drop(v5_4);
  (v5_5).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v10_8: Space = unwrap(&(*CONSTANT_50),&(*p0));
  let v10_9: Space = unwrap(&(*s1),&(*CONSTANT_49));
  let v10_10: Space = unwrap(&(*CONSTANT_50),&(*p0));
  let mut v10_11 = Space::new();
  let mut v10_11_cursor = (*s0).read_zipper();
  for v10_11_byte in v10_11_cursor.child_mask().iter() {
    v10_11_cursor.descend_to_byte(v10_11_byte);
    let v10_11_tail = v10_11_cursor.make_map();
    v10_11_cursor.ascend(1);
    let v10_11_head = Path::from_slice(&[v10_11_byte]);
    let v11_2: Space = unwrap(&(*CONSTANT_50),&(v10_11_head));
    let v11_3: Space = unwrap(&(*CONSTANT_50),&(v10_11_head));
    let mut v11_4 = Space::new();
    let mut v11_4_cursor = (v10_11_tail).read_zipper();
    for v11_4_byte in v11_4_cursor.child_mask().iter() {
      v11_4_cursor.descend_to_byte(v11_4_byte);
      let v11_4_tail = v11_4_cursor.make_map();
      v11_4_cursor.ascend(1);
      let v11_4_head = Path::from_slice(&[v11_4_byte]);
      let v12_2: Path = concat_path(&(v10_11_head),&(v11_4_head));
      let v12_3: Space = unwrap(&(v11_2),&(v11_4_head));
      let v12_4: Space = unwrap(&(v11_3),&(v11_4_head));
      let mut v12_5 = Space::new();
      let mut v12_5_cursor = (v11_4_tail).read_zipper();
      for v12_5_byte in v12_5_cursor.child_mask().iter() {
        v12_5_cursor.descend_to_byte(v12_5_byte);
        let v12_5_tail = v12_5_cursor.make_map();
        v12_5_cursor.ascend(1);
        let v12_5_head = Path::from_slice(&[v12_5_byte]);
        let v13_2: Space = unwrap(&(v12_3),&(v12_5_head));
        let v13_3: Path = concat_path(&(v12_2),&(v12_5_head));
        let v13_4: Space = unwrap(&(v12_4),&(v12_5_head));
        let mut v13_5 = Space::new();
        let mut v13_5_cursor = (v12_5_tail).read_zipper();
        for v13_5_byte in v13_5_cursor.child_mask().iter() {
          v13_5_cursor.descend_to_byte(v13_5_byte);
          let v13_5_tail = v13_5_cursor.make_map();
          v13_5_cursor.ascend(1);
          let v13_5_head = Path::from_slice(&[v13_5_byte]);
          let v14_2: Space = unwrap(&(v13_2),&(v13_5_head));
          let v14_3: Space = compose(&(v10_8),&(v14_2));
          drop(v14_2);
          let v14_4: Path = concat_path(&(v13_3),&(v13_5_head));
          let v14_5: Path = concat_path(&(*p0),&(v14_4));
          drop(v14_4);
          let v14_6: Space = singleton(&(v14_5));
          drop(v14_5);
          let v14_7: Space = subtract(&(v14_3),&(v14_6));
          drop(v14_3);
          let v14_8: Space = intersect(&(v14_7),&(v10_9));
          drop(v14_7);
          let v14_9: Space = routine_4(c, &(v14_8));
          drop(v14_8);
          let mut v14_10 = Space::new();
          let mut v14_10_cursor = (v14_9).read_zipper();
          for v14_10_byte in v14_10_cursor.child_mask().iter() {
            v14_10_cursor.descend_to_byte(v14_10_byte);
            let v14_10_tail = v14_10_cursor.make_map();
            v14_10_cursor.ascend(1);
            let v14_10_head = Path::from_slice(&[v14_10_byte]);
            let mut v15_2 = Space::new();
            let mut v15_2_cursor = (v14_10_tail).read_zipper();
            for v15_2_byte in v15_2_cursor.child_mask().iter() {
              v15_2_cursor.descend_to_byte(v15_2_byte);
              let v15_2_tail = v15_2_cursor.make_map();
              v15_2_cursor.ascend(1);
              let v15_2_head = Path::from_slice(&[v15_2_byte]);
              let v16_2: Path = concat_path(&(v14_10_head),&(v15_2_head));
              let mut v16_3 = Space::new();
              let mut v16_3_cursor = (v15_2_tail).read_zipper();
              for v16_3_byte in v16_3_cursor.child_mask().iter() {
                v16_3_cursor.descend_to_byte(v16_3_byte);
                let v16_3_tail = v16_3_cursor.make_map();
                v16_3_cursor.ascend(1);
                let v16_3_head = Path::from_slice(&[v16_3_byte]);
                let v17_2: Path = concat_path(&(v16_2),&(v16_3_head));
                let mut v17_3 = Space::new();
                let mut v17_3_cursor = (v16_3_tail).read_zipper();
                for v17_3_byte in v17_3_cursor.child_mask().iter() {
                  v17_3_cursor.descend_to_byte(v17_3_byte);
                  let v17_3_tail = v17_3_cursor.make_map();
                  v17_3_cursor.ascend(1);
                  let v17_3_head = Path::from_slice(&[v17_3_byte]);
                  let v18_2: Path = concat_path(&(v17_2),&(v17_3_head));
                  let v18_3: Space = routine_5(c, &(v18_2), &(v17_3_tail));
                  drop(v18_2);
                  v17_3.join_into((v18_3).clone());
                }
                drop(v17_3_cursor);
                drop(v17_2);
                v16_3.join_into((v17_3).clone());
              }
              drop(v16_3_cursor);
              drop(v16_2);
              v15_2.join_into((v16_3).clone());
            }
            drop(v15_2_cursor);
            v14_10.join_into((v15_2).clone());
          }
          drop(v14_10_cursor);
          let v14_11: Space = unwrap(&(v13_4),&(v13_5_head));
          let v14_12: Space = compose(&(v10_10),&(v14_11));
          drop(v14_11);
          let v14_13: Space = subtract(&(v14_12),&(v14_6));
          drop(v14_12);
          let v14_14: Space = intersect(&(v14_13),&(v10_9));
          drop(v14_13);
          let v14_15: Space = routine_6(c, &(v14_14));
          drop(v14_14);
          let mut v14_16 = Space::new();
          let mut v14_16_cursor = (v14_15).read_zipper();
          for v14_16_byte in v14_16_cursor.child_mask().iter() {
            v14_16_cursor.descend_to_byte(v14_16_byte);
            let v14_16_tail = v14_16_cursor.make_map();
            v14_16_cursor.ascend(1);
            let v14_16_head = Path::from_slice(&[v14_16_byte]);
            let mut v19_2 = Space::new();
            let mut v19_2_cursor = (v14_16_tail).read_zipper();
            for v19_2_byte in v19_2_cursor.child_mask().iter() {
              v19_2_cursor.descend_to_byte(v19_2_byte);
              let v19_2_tail = v19_2_cursor.make_map();
              v19_2_cursor.ascend(1);
              let v19_2_head = Path::from_slice(&[v19_2_byte]);
              let v20_2: Path = concat_path(&(v14_16_head),&(v19_2_head));
              let mut v20_3 = Space::new();
              let mut v20_3_cursor = (v19_2_tail).read_zipper();
              for v20_3_byte in v20_3_cursor.child_mask().iter() {
                v20_3_cursor.descend_to_byte(v20_3_byte);
                let v20_3_tail = v20_3_cursor.make_map();
                v20_3_cursor.ascend(1);
                let v20_3_head = Path::from_slice(&[v20_3_byte]);
                let v21_2: Path = concat_path(&(v20_2),&(v20_3_head));
                let mut v21_3 = Space::new();
                let mut v21_3_cursor = (v20_3_tail).read_zipper();
                for v21_3_byte in v21_3_cursor.child_mask().iter() {
                  v21_3_cursor.descend_to_byte(v21_3_byte);
                  let v21_3_tail = v21_3_cursor.make_map();
                  v21_3_cursor.ascend(1);
                  let v21_3_head = Path::from_slice(&[v21_3_byte]);
                  let v22_2: Path = concat_path(&(v21_2),&(v21_3_head));
                  let v22_3: Space = routine_7(c, &(v22_2), &(v21_3_tail));
                  drop(v22_2);
                  v21_3.join_into((v22_3).clone());
                }
                drop(v21_3_cursor);
                drop(v21_2);
                v20_3.join_into((v21_3).clone());
              }
              drop(v20_3_cursor);
              drop(v20_2);
              v19_2.join_into((v20_3).clone());
            }
            drop(v19_2_cursor);
            v14_16.join_into((v19_2).clone());
          }
          drop(v14_16_cursor);
          let v14_17: Space = subtract(&(v14_10),&(v14_16));
          let v14_18: Space = if (v14_17).is_empty() { Space::new() } else {
            compose(&(v14_17),&(v14_6))
          };
          drop(v14_6);
          let mut v14_19 = Space::new();
          let mut v14_19_cursor = (v14_18).read_zipper();
          for v14_19_byte in v14_19_cursor.child_mask().iter() {
            v14_19_cursor.descend_to_byte(v14_19_byte);
            let v14_19_tail = v14_19_cursor.make_map();
            v14_19_cursor.ascend(1);
            let v14_19_head = Path::from_slice(&[v14_19_byte]);
            let mut v24_2 = Space::new();
            let mut v24_2_cursor = (v14_19_tail).read_zipper();
            for v24_2_byte in v24_2_cursor.child_mask().iter() {
              v24_2_cursor.descend_to_byte(v24_2_byte);
              let v24_2_tail = v24_2_cursor.make_map();
              v24_2_cursor.ascend(1);
              let v24_2_head = Path::from_slice(&[v24_2_byte]);
              let v25_2: Path = concat_path(&(v14_19_head),&(v24_2_head));
              let mut v25_3 = Space::new();
              let mut v25_3_cursor = (v24_2_tail).read_zipper();
              for v25_3_byte in v25_3_cursor.child_mask().iter() {
                v25_3_cursor.descend_to_byte(v25_3_byte);
                let v25_3_tail = v25_3_cursor.make_map();
                v25_3_cursor.ascend(1);
                let v25_3_head = Path::from_slice(&[v25_3_byte]);
                let v26_2: Path = concat_path(&(v25_2),&(v25_3_head));
                let mut v26_3 = Space::new();
                let mut v26_3_cursor = (v25_3_tail).read_zipper();
                for v26_3_byte in v26_3_cursor.child_mask().iter() {
                  v26_3_cursor.descend_to_byte(v26_3_byte);
                  let v26_3_tail = v26_3_cursor.make_map();
                  v26_3_cursor.ascend(1);
                  let v26_3_head = Path::from_slice(&[v26_3_byte]);
                  let v27_2: Path = concat_path(&(v26_2),&(v26_3_head));
                  let v27_3: Space = routine_8(c, &(v27_2), &(v26_3_tail));
                  drop(v27_2);
                  v26_3.join_into((v27_3).clone());
                }
                drop(v26_3_cursor);
                drop(v26_2);
                v25_3.join_into((v26_3).clone());
              }
              drop(v25_3_cursor);
              drop(v25_2);
              v24_2.join_into((v25_3).clone());
            }
            drop(v24_2_cursor);
            v14_19.join_into((v24_2).clone());
          }
          drop(v14_19_cursor);
          v13_5.join_into((v14_19).clone());
        }
        drop(v13_5_cursor);
        drop(v13_2);
        drop(v13_3);
        drop(v13_4);
        v12_5.join_into((v13_5).clone());
      }
      drop(v12_5_cursor);
      drop(v12_2);
      drop(v12_3);
      drop(v12_4);
      v11_4.join_into((v12_5).clone());
    }
    drop(v11_4_cursor);
    drop(v11_2);
    drop(v11_3);
    v10_11.join_into((v11_4).clone());
  }
  drop(v10_11_cursor);
  drop(v10_8);
  drop(v10_9);
  drop(v10_10);
  (v10_11).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v28_8: Space = unwrap(&(*CONSTANT_50),&(*p0));
  let v28_9: Space = unwrap(&(*s1),&(*CONSTANT_49));
  let v28_10: Space = unwrap(&(*CONSTANT_50),&(*p0));
  let mut v28_11 = Space::new();
  let mut v28_11_cursor = (*s0).read_zipper();
  for v28_11_byte in v28_11_cursor.child_mask().iter() {
    v28_11_cursor.descend_to_byte(v28_11_byte);
    let v28_11_tail = v28_11_cursor.make_map();
    v28_11_cursor.ascend(1);
    let v28_11_head = Path::from_slice(&[v28_11_byte]);
    let v29_2: Space = unwrap(&(*CONSTANT_50),&(v28_11_head));
    let v29_3: Space = unwrap(&(*CONSTANT_50),&(v28_11_head));
    let mut v29_4 = Space::new();
    let mut v29_4_cursor = (v28_11_tail).read_zipper();
    for v29_4_byte in v29_4_cursor.child_mask().iter() {
      v29_4_cursor.descend_to_byte(v29_4_byte);
      let v29_4_tail = v29_4_cursor.make_map();
      v29_4_cursor.ascend(1);
      let v29_4_head = Path::from_slice(&[v29_4_byte]);
      let v30_2: Path = concat_path(&(v28_11_head),&(v29_4_head));
      let v30_3: Space = unwrap(&(v29_2),&(v29_4_head));
      let v30_4: Space = unwrap(&(v29_3),&(v29_4_head));
      let mut v30_5 = Space::new();
      let mut v30_5_cursor = (v29_4_tail).read_zipper();
      for v30_5_byte in v30_5_cursor.child_mask().iter() {
        v30_5_cursor.descend_to_byte(v30_5_byte);
        let v30_5_tail = v30_5_cursor.make_map();
        v30_5_cursor.ascend(1);
        let v30_5_head = Path::from_slice(&[v30_5_byte]);
        let v31_2: Space = unwrap(&(v30_3),&(v30_5_head));
        let v31_3: Path = concat_path(&(v30_2),&(v30_5_head));
        let v31_4: Space = unwrap(&(v30_4),&(v30_5_head));
        let mut v31_5 = Space::new();
        let mut v31_5_cursor = (v30_5_tail).read_zipper();
        for v31_5_byte in v31_5_cursor.child_mask().iter() {
          v31_5_cursor.descend_to_byte(v31_5_byte);
          let v31_5_tail = v31_5_cursor.make_map();
          v31_5_cursor.ascend(1);
          let v31_5_head = Path::from_slice(&[v31_5_byte]);
          let v32_2: Space = unwrap(&(v31_2),&(v31_5_head));
          let v32_3: Space = compose(&(v28_8),&(v32_2));
          drop(v32_2);
          let v32_4: Path = concat_path(&(v31_3),&(v31_5_head));
          let v32_5: Path = concat_path(&(*p0),&(v32_4));
          drop(v32_4);
          let v32_6: Space = singleton(&(v32_5));
          drop(v32_5);
          let v32_7: Space = subtract(&(v32_3),&(v32_6));
          drop(v32_3);
          let v32_8: Space = intersect(&(v32_7),&(v28_9));
          drop(v32_7);
          let v32_9: Space = routine_9(c, &(v32_8));
          drop(v32_8);
          let mut v32_10 = Space::new();
          let mut v32_10_cursor = (v32_9).read_zipper();
          for v32_10_byte in v32_10_cursor.child_mask().iter() {
            v32_10_cursor.descend_to_byte(v32_10_byte);
            let v32_10_tail = v32_10_cursor.make_map();
            v32_10_cursor.ascend(1);
            let v32_10_head = Path::from_slice(&[v32_10_byte]);
            let mut v33_2 = Space::new();
            let mut v33_2_cursor = (v32_10_tail).read_zipper();
            for v33_2_byte in v33_2_cursor.child_mask().iter() {
              v33_2_cursor.descend_to_byte(v33_2_byte);
              let v33_2_tail = v33_2_cursor.make_map();
              v33_2_cursor.ascend(1);
              let v33_2_head = Path::from_slice(&[v33_2_byte]);
              let v34_2: Path = concat_path(&(v32_10_head),&(v33_2_head));
              let mut v34_3 = Space::new();
              let mut v34_3_cursor = (v33_2_tail).read_zipper();
              for v34_3_byte in v34_3_cursor.child_mask().iter() {
                v34_3_cursor.descend_to_byte(v34_3_byte);
                let v34_3_tail = v34_3_cursor.make_map();
                v34_3_cursor.ascend(1);
                let v34_3_head = Path::from_slice(&[v34_3_byte]);
                let v35_2: Path = concat_path(&(v34_2),&(v34_3_head));
                let mut v35_3 = Space::new();
                let mut v35_3_cursor = (v34_3_tail).read_zipper();
                for v35_3_byte in v35_3_cursor.child_mask().iter() {
                  v35_3_cursor.descend_to_byte(v35_3_byte);
                  let v35_3_tail = v35_3_cursor.make_map();
                  v35_3_cursor.ascend(1);
                  let v35_3_head = Path::from_slice(&[v35_3_byte]);
                  let v36_2: Path = concat_path(&(v35_2),&(v35_3_head));
                  let v36_3: Space = routine_10(c, &(v36_2), &(v35_3_tail));
                  drop(v36_2);
                  v35_3.join_into((v36_3).clone());
                }
                drop(v35_3_cursor);
                drop(v35_2);
                v34_3.join_into((v35_3).clone());
              }
              drop(v34_3_cursor);
              drop(v34_2);
              v33_2.join_into((v34_3).clone());
            }
            drop(v33_2_cursor);
            v32_10.join_into((v33_2).clone());
          }
          drop(v32_10_cursor);
          let v32_11: Space = unwrap(&(v31_4),&(v31_5_head));
          let v32_12: Space = compose(&(v28_10),&(v32_11));
          drop(v32_11);
          let v32_13: Space = subtract(&(v32_12),&(v32_6));
          drop(v32_12);
          let v32_14: Space = intersect(&(v32_13),&(v28_9));
          drop(v32_13);
          let v32_15: Space = routine_4(c, &(v32_14));
          drop(v32_14);
          let mut v32_16 = Space::new();
          let mut v32_16_cursor = (v32_15).read_zipper();
          for v32_16_byte in v32_16_cursor.child_mask().iter() {
            v32_16_cursor.descend_to_byte(v32_16_byte);
            let v32_16_tail = v32_16_cursor.make_map();
            v32_16_cursor.ascend(1);
            let v32_16_head = Path::from_slice(&[v32_16_byte]);
            let mut v37_2 = Space::new();
            let mut v37_2_cursor = (v32_16_tail).read_zipper();
            for v37_2_byte in v37_2_cursor.child_mask().iter() {
              v37_2_cursor.descend_to_byte(v37_2_byte);
              let v37_2_tail = v37_2_cursor.make_map();
              v37_2_cursor.ascend(1);
              let v37_2_head = Path::from_slice(&[v37_2_byte]);
              let v38_2: Path = concat_path(&(v32_16_head),&(v37_2_head));
              let mut v38_3 = Space::new();
              let mut v38_3_cursor = (v37_2_tail).read_zipper();
              for v38_3_byte in v38_3_cursor.child_mask().iter() {
                v38_3_cursor.descend_to_byte(v38_3_byte);
                let v38_3_tail = v38_3_cursor.make_map();
                v38_3_cursor.ascend(1);
                let v38_3_head = Path::from_slice(&[v38_3_byte]);
                let v39_2: Path = concat_path(&(v38_2),&(v38_3_head));
                let mut v39_3 = Space::new();
                let mut v39_3_cursor = (v38_3_tail).read_zipper();
                for v39_3_byte in v39_3_cursor.child_mask().iter() {
                  v39_3_cursor.descend_to_byte(v39_3_byte);
                  let v39_3_tail = v39_3_cursor.make_map();
                  v39_3_cursor.ascend(1);
                  let v39_3_head = Path::from_slice(&[v39_3_byte]);
                  let v40_2: Path = concat_path(&(v39_2),&(v39_3_head));
                  let v40_3: Space = routine_11(c, &(v40_2), &(v39_3_tail));
                  drop(v40_2);
                  v39_3.join_into((v40_3).clone());
                }
                drop(v39_3_cursor);
                drop(v39_2);
                v38_3.join_into((v39_3).clone());
              }
              drop(v38_3_cursor);
              drop(v38_2);
              v37_2.join_into((v38_3).clone());
            }
            drop(v37_2_cursor);
            v32_16.join_into((v37_2).clone());
          }
          drop(v32_16_cursor);
          let v32_17: Space = subtract(&(v32_10),&(v32_16));
          let v32_18: Space = if (v32_17).is_empty() { Space::new() } else {
            compose(&(v32_17),&(v32_6))
          };
          drop(v32_6);
          let mut v32_19 = Space::new();
          let mut v32_19_cursor = (v32_18).read_zipper();
          for v32_19_byte in v32_19_cursor.child_mask().iter() {
            v32_19_cursor.descend_to_byte(v32_19_byte);
            let v32_19_tail = v32_19_cursor.make_map();
            v32_19_cursor.ascend(1);
            let v32_19_head = Path::from_slice(&[v32_19_byte]);
            let mut v42_2 = Space::new();
            let mut v42_2_cursor = (v32_19_tail).read_zipper();
            for v42_2_byte in v42_2_cursor.child_mask().iter() {
              v42_2_cursor.descend_to_byte(v42_2_byte);
              let v42_2_tail = v42_2_cursor.make_map();
              v42_2_cursor.ascend(1);
              let v42_2_head = Path::from_slice(&[v42_2_byte]);
              let v43_2: Path = concat_path(&(v32_19_head),&(v42_2_head));
              let mut v43_3 = Space::new();
              let mut v43_3_cursor = (v42_2_tail).read_zipper();
              for v43_3_byte in v43_3_cursor.child_mask().iter() {
                v43_3_cursor.descend_to_byte(v43_3_byte);
                let v43_3_tail = v43_3_cursor.make_map();
                v43_3_cursor.ascend(1);
                let v43_3_head = Path::from_slice(&[v43_3_byte]);
                let v44_2: Path = concat_path(&(v43_2),&(v43_3_head));
                let mut v44_3 = Space::new();
                let mut v44_3_cursor = (v43_3_tail).read_zipper();
                for v44_3_byte in v44_3_cursor.child_mask().iter() {
                  v44_3_cursor.descend_to_byte(v44_3_byte);
                  let v44_3_tail = v44_3_cursor.make_map();
                  v44_3_cursor.ascend(1);
                  let v44_3_head = Path::from_slice(&[v44_3_byte]);
                  let v45_2: Path = concat_path(&(v44_2),&(v44_3_head));
                  let v45_3: Space = routine_12(c, &(v45_2), &(v44_3_tail));
                  drop(v45_2);
                  v44_3.join_into((v45_3).clone());
                }
                drop(v44_3_cursor);
                drop(v44_2);
                v43_3.join_into((v44_3).clone());
              }
              drop(v43_3_cursor);
              drop(v43_2);
              v42_2.join_into((v43_3).clone());
            }
            drop(v42_2_cursor);
            v32_19.join_into((v42_2).clone());
          }
          drop(v32_19_cursor);
          v31_5.join_into((v32_19).clone());
        }
        drop(v31_5_cursor);
        drop(v31_2);
        drop(v31_3);
        drop(v31_4);
        v30_5.join_into((v31_5).clone());
      }
      drop(v30_5_cursor);
      drop(v30_2);
      drop(v30_3);
      drop(v30_4);
      v29_4.join_into((v30_5).clone());
    }
    drop(v29_4_cursor);
    drop(v29_2);
    drop(v29_3);
    v28_11.join_into((v29_4).clone());
  }
  drop(v28_11_cursor);
  drop(v28_8);
  drop(v28_9);
  drop(v28_10);
  (v28_11).clone()
}

fn routine_4(c: &mut Context, s0: &Space) -> Space {
  let v46_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v46_2: Space = first_matching(&(*s0),&(*CONSTANT_51),false);
  let v46_3: Space = unite(&(v46_1),&(v46_2));
  drop(v46_1);
  drop(v46_2);
  let v46_6: Space = if (v46_3).is_empty() { Space::new() } else {
    let v47_4: Space = routine_13(c, &(*s0));
    let v47_5: Space = routine_13(c, &(v47_4));
    compose(&(v46_3),&(v47_5))
  };
  let v46_9: Space = if (v46_3).is_empty() { Space::new() } else {
    let v48_7: Space = routine_14(c, &(*s0));
    let v48_8: Space = subtract(&(*s0),&(v48_7));
    compose(&(v46_3),&(v48_8))
  };
  drop(v46_3);
  let v46_10: Space = if has_head(&(v46_9)) { singleton(&[]) } else { Space::new() };
  let v46_11: Space = first_matching(&(v46_9),&(*CONSTANT_51),false);
  let v46_12: Space = unite(&(v46_10),&(v46_11));
  let v46_15: Space = if (v46_12).is_empty() { Space::new() } else {
    let v49_13: Space = routine_13(c, &(v46_9));
    let v49_14: Space = routine_13(c, &(v49_13));
    compose(&(v46_12),&(v49_14))
  };
  let v46_16: Space = subtract(&(*s0),&(v46_15));
  let v46_17: Space = intersect(&(v46_6),&(v46_16));
  (v46_17).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*CONSTANT_52).clone()
}

fn routine_6(c: &mut Context, s0: &Space) -> Space {
  let v51_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v51_2: Space = first_matching(&(*s0),&(*CONSTANT_51),false);
  let v51_3: Space = unite(&(v51_1),&(v51_2));
  drop(v51_1);
  drop(v51_2);
  let v51_6: Space = if (v51_3).is_empty() { Space::new() } else {
    let v52_4: Space = routine_14(c, &(*s0));
    let v52_5: Space = subtract(&(*s0),&(v52_4));
    compose(&(v51_3),&(v52_5))
  };
  let v51_7: Space = if has_head(&(v51_6)) { singleton(&[]) } else { Space::new() };
  let v51_8: Space = first_matching(&(v51_6),&(*CONSTANT_51),false);
  let v51_9: Space = unite(&(v51_7),&(v51_8));
  let v51_12: Space = if (v51_9).is_empty() { Space::new() } else {
    let v53_10: Space = routine_13(c, &(v51_6));
    let v53_11: Space = routine_13(c, &(v53_10));
    compose(&(v51_9),&(v53_11))
  };
  let v51_15: Space = if (v51_3).is_empty() { Space::new() } else {
    let v54_13: Space = routine_15(c, &(*s0));
    let v54_14: Space = routine_15(c, &(v54_13));
    compose(&(v51_3),&(v54_14))
  };
  drop(v51_3);
  let v51_16: Space = subtract(&(*s0),&(v51_15));
  let v51_17: Space = intersect(&(v51_12),&(v51_16));
  (v51_17).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*CONSTANT_52).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_9(c: &mut Context, s0: &Space) -> Space {
  let v57_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v57_2: Space = first_matching(&(*s0),&(*CONSTANT_51),false);
  let v57_3: Space = unite(&(v57_1),&(v57_2));
  drop(v57_1);
  drop(v57_2);
  let v57_6: Space = if (v57_3).is_empty() { Space::new() } else {
    let v58_4: Space = routine_14(c, &(*s0));
    let v58_5: Space = subtract(&(*s0),&(v58_4));
    compose(&(v57_3),&(v58_5))
  };
  let v57_9: Space = if (v57_3).is_empty() { Space::new() } else {
    let v59_7: Space = routine_13(c, &(*s0));
    let v59_8: Space = routine_13(c, &(v59_7));
    compose(&(v57_3),&(v59_8))
  };
  drop(v57_3);
  let v57_10: Space = subtract(&(*s0),&(v57_9));
  let v57_11: Space = intersect(&(v57_6),&(v57_10));
  (v57_11).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*CONSTANT_52).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*CONSTANT_52).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_13(c: &mut Context, s0: &Space) -> Space {
  let v63_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v63_2: Space = first_matching(&(*s0),&(*CONSTANT_51),false);
  let v63_3: Space = unite(&(v63_1),&(v63_2));
  drop(v63_1);
  let v63_19: Space = if (v63_3).is_empty() { Space::new() } else {
    let v64_5: Space = intersect(&(*CONSTANT_51),&(v63_2));
    let v64_6: Space = if has_head(&(v63_2)) { singleton(&[]) } else { Space::new() };
    let v64_7: Space = unite(&(v64_5),&(v64_6));
    drop(v64_5);
    let v64_9: Space = compose(&(v64_7),&(*CONSTANT_51));
    drop(v64_7);
    let v64_10: Space = subtract(&(*s0),&(v64_9));
    drop(v64_9);
    let v64_12: Space = subtract(&(*CONSTANT_51),&(v63_2));
    let v64_13: Space = subtract(&(v64_12),&(v64_6));
    drop(v64_6);
    drop(v64_12);
    let v64_17: Space = if (v64_13).is_empty() { Space::new() } else {
      let v65_15: Space = first_listed(&(*s0),&(*CONSTANT_54),true);
      let mut v65_16 = Space::new();
      let v65_16_arg_0: &Path = &(*CONSTANT_53);
      let v65_16_arg_1: &Space = &(v65_15);
      let v65_16_arg_2: &Space = &(*s0);
      let mut v65_16_cursor = v65_16_arg_1.read_zipper();
      let mut v65_16_more = v65_16_cursor.is_val() || v65_16_cursor.to_next_val();
      while v65_16_more {
        let v65_16_path = concat_path(v65_16_arg_0,v65_16_cursor.path());
        let v65_16_rest = v65_16_cursor.make_map();
        let v66_3: Space = unwrap(&(*v65_16_arg_2),&(v65_16_path));
        let v66_4: Space = routine_14(c, &(v66_3));
        drop(v66_3);
        let v66_5: Space = wrap(&(v66_4),&(v65_16_path));
        v65_16.join_into((v66_5).clone());
        v65_16_more = v65_16_cursor.to_next_val();
      }
      drop(v65_16_cursor);
      drop(v65_15);
      compose(&(v64_13),&(v65_16))
    };
    drop(v64_13);
    let v64_18: Space = subtract(&(v64_10),&(v64_17));
    drop(v64_10);
    compose(&(v63_3),&(v64_18))
  };
  drop(v63_3);
  (v63_19).clone()
}

fn routine_14(c: &mut Context, s0: &Space) -> Space {
  let v67_2: Space = first_matching(&(*s0),&(*CONSTANT_51),false);
  let v67_3: Space = intersect(&(*CONSTANT_51),&(v67_2));
  let v67_4: Space = if has_head(&(v67_2)) { singleton(&[]) } else { Space::new() };
  let v67_5: Space = unite(&(v67_3),&(v67_4));
  drop(v67_3);
  let v67_7: Space = compose(&(v67_5),&(*CONSTANT_51));
  drop(v67_5);
  let v67_9: Space = subtract(&(*CONSTANT_51),&(v67_2));
  drop(v67_2);
  let v67_10: Space = subtract(&(v67_9),&(v67_4));
  drop(v67_4);
  drop(v67_9);
  let v67_18: Space = if (v67_10).is_empty() { Space::new() } else {
    let v68_11: Space = first_listed(&(*s0),&(*CONSTANT_54),true);
    let v68_12: Space = first_matching(&(v68_11),&(*CONSTANT_51),false);
    let v68_15: Space = if (v68_12).is_empty() { Space::new() } else {
      let v69_14: Space = routine_16(c, &(*CONSTANT_53), &(*s0));
      compose(&(v68_12),&(v69_14))
    };
    drop(v68_12);
    let mut v68_16 = Space::new();
    let mut v68_16_cursor = (v68_11).read_zipper();
    for v68_16_byte in v68_16_cursor.child_mask().iter() {
      v68_16_cursor.descend_to_byte(v68_16_byte);
      let v68_16_tail = v68_16_cursor.make_map();
      v68_16_cursor.ascend(1);
      let v68_16_head = Path::from_slice(&[v68_16_byte]);
      let mut v70_2 = Space::new();
      let v70_2_arg_0: &Path = &(v68_16_head);
      let v70_2_arg_1: &Space = &(v68_16_tail);
      let v70_2_arg_2: &Space = &(*s0);
      let mut v70_2_cursor = v70_2_arg_1.read_zipper();
      let mut v70_2_more = v70_2_cursor.is_val() || v70_2_cursor.to_next_val();
      while v70_2_more {
        let v70_2_path = concat_path(v70_2_arg_0,v70_2_cursor.path());
        let v70_2_rest = v70_2_cursor.make_map();
        let v71_3: Space = unwrap(&(*v70_2_arg_2),&(v70_2_path));
        let v71_4: Space = routine_14(c, &(v71_3));
        drop(v71_3);
        let v71_5: Space = wrap(&(v71_4),&(v70_2_path));
        v70_2.join_into((v71_5).clone());
        v70_2_more = v70_2_cursor.to_next_val();
      }
      drop(v70_2_cursor);
      v68_16.join_into((v70_2).clone());
    }
    drop(v68_16_cursor);
    drop(v68_11);
    let v68_17: Space = unite(&(v68_15),&(v68_16));
    compose(&(v67_10),&(v68_17))
  };
  drop(v67_10);
  let v67_19: Space = unite(&(v67_7),&(v67_18));
  drop(v67_7);
  (v67_19).clone()
}

fn routine_15(c: &mut Context, s0: &Space) -> Space {
  let v72_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v72_2: Space = first_matching(&(*s0),&(*CONSTANT_51),false);
  let v72_3: Space = unite(&(v72_1),&(v72_2));
  drop(v72_1);
  drop(v72_2);
  let v72_13: Space = if (v72_3).is_empty() { Space::new() } else {
    let v73_6: Space = if (v72_3).is_empty() { Space::new() } else {
      let v74_4: Space = routine_14(c, &(*s0));
      let v74_5: Space = subtract(&(*s0),&(v74_4));
      compose(&(v72_3),&(v74_5))
    };
    let v73_7: Space = if has_head(&(v73_6)) { singleton(&[]) } else { Space::new() };
    let v73_8: Space = first_matching(&(v73_6),&(*CONSTANT_51),false);
    let v73_9: Space = unite(&(v73_7),&(v73_8));
    let v73_12: Space = if (v73_9).is_empty() { Space::new() } else {
      let v75_10: Space = routine_14(c, &(v73_6));
      let v75_11: Space = subtract(&(v73_6),&(v75_10));
      compose(&(v73_9),&(v75_11))
    };
    compose(&(v72_3),&(v73_12))
  };
  drop(v72_3);
  (v72_13).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v76_3: Space = unwrap(&(*s0),&(*p0));
  let v76_4: Space = first_matching(&(v76_3),&(*CONSTANT_51),false);
  let v76_5: Space = intersect(&(*CONSTANT_51),&(v76_4));
  let v76_6: Space = if has_head(&(v76_4)) { singleton(&[]) } else { Space::new() };
  let v76_7: Space = unite(&(v76_5),&(v76_6));
  drop(v76_5);
  let v76_9: Space = compose(&(v76_7),&(*CONSTANT_51));
  drop(v76_7);
  let v76_11: Space = subtract(&(*CONSTANT_51),&(v76_4));
  drop(v76_4);
  let v76_12: Space = subtract(&(v76_11),&(v76_6));
  drop(v76_6);
  drop(v76_11);
  let v76_16: Space = if (v76_12).is_empty() { Space::new() } else {
    let v77_14: Space = first_listed(&(v76_3),&(*CONSTANT_54),true);
    let mut v77_15 = Space::new();
    let v77_15_arg_0: &Path = &(*CONSTANT_53);
    let v77_15_arg_1: &Space = &(v77_14);
    let v77_15_arg_2: &Space = &(v76_3);
    let mut v77_15_cursor = v77_15_arg_1.read_zipper();
    let mut v77_15_more = v77_15_cursor.is_val() || v77_15_cursor.to_next_val();
    while v77_15_more {
      let v77_15_path = concat_path(v77_15_arg_0,v77_15_cursor.path());
      let v77_15_rest = v77_15_cursor.make_map();
      let v78_3: Space = routine_16(c, &(v77_15_path), &(*v77_15_arg_2));
      v77_15.join_into((v78_3).clone());
      v77_15_more = v77_15_cursor.to_next_val();
    }
    drop(v77_15_cursor);
    drop(v77_14);
    compose(&(v76_12),&(v77_15))
  };
  drop(v76_12);
  let v76_17: Space = unite(&(v76_9),&(v76_16));
  drop(v76_9);
  let v76_18: Space = wrap(&(v76_17),&(*p0));
  (v76_18).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
