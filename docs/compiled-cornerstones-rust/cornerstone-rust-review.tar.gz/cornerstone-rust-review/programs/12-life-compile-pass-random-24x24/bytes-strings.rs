#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[48]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 49 48 0 4 0 49 49 0"));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("120 10 67 101 108 108 0 48 0 49 48 0 10 67 101 108 108 0 48 0 49 49 0 10 67 101 108 108 0 49 0 49 51 0 10 67 101 108 108 0 49 0 49 52 0 10 67 101 108 108 0 49 0 50 48 0 11 67 101 108 108 0 49 48 0 49 50 0 11 67 101 108 108 0 49 48 0 49 56 0 11 67 101 108 108 0 49 48 0 50 51 0 10 67 101 108 108 0 49 48 0 54 0 10 67 101 108 108 0 49 48 0 57 0 11 67 101 108 108 0 49 49 0 49 49 0 11 67 101 108 108 0 49 49 0 49 50 0 11 67 101 108 108 0 49 49 0 50 51 0 10 67 101 108 108 0 49 49 0 51 0 10 67 101 108 108 0 49 49 0 53 0 11 67 101 108 108 0 49 50 0 49 54 0 11 67 101 108 108 0 49 50 0 49 57 0 10 67 101 108 108 0 49 50 0 50 0 11 67 101 108 108 0 49 51 0 49 52 0 11 67 101 108 108 0 49 51 0 50 48 0 11 67 101 108 108 0 49 51 0 50 49 0 10 67 101 108 108 0 49 51 0 57 0 10 67 101 108 108 0 49 52 0 48 0 11 67 101 108 108 0 49 52 0 49 56 0 10 67 101 108 108 0 49 52 0 54 0 10 67 101 108 108 0 49 52 0 56 0 10 67 101 108 108 0 49 52 0 57 0 10 67 101 108 108 0 49 53 0 49 0 11 67 101 108 108 0 49 53 0 49 54 0 11 67 101 108 108 0 49 53 0 49 55 0 11 67 101 108 108 0 49 53 0 49 57 0 11 67 101 108 108 0 49 53 0 50 48 0 10 67 101 108 108 0 49 53 0 51 0 10 67 101 108 108 0 49 53 0 53 0 10 67 101 108 108 0 49 53 0 54 0 10 67 101 108 108 0 49 54 0 48 0 11 67 101 108 108 0 49 55 0 49 50 0 11 67 101 108 108 0 49 55 0 49 54 0 11 67 101 108 108 0 49 55 0 49 56 0 10 67 101 108 108 0 49 55 0 50 0 10 67 101 108 108 0 49 55 0 51 0 10 67 101 108 108 0 49 55 0 52 0 10 67 101 108 108 0 49 55 0 54 0 10 67 101 108 108 0 49 55 0 55 0 10 67 101 108 108 0 49 55 0 57 0 11 67 101 108 108 0 49 56 0 49 48 0 11 67 101 108 108 0 49 56 0 49 50 0 11 67 101 108 108 0 49 56 0 49 51 0 11 67 101 108 108 0 49 56 0 49 53 0 11 67 101 108 108 0 49 56 0 49 55 0 11 67 101 108 108 0 49 56 0 50 50 0 10 67 101 108 108 0 49 56 0 53 0 11 67 101 108 108 0 49 57 0 49 56 0 11 67 101 108 108 0 49 57 0 50 49 0 10 67 101 108 108 0 49 57 0 51 0 10 67 101 108 108 0 50 0 49 48 0 10 67 101 108 108 0 50 0 49 51 0 10 67 101 108 108 0 50 0 50 49 0 11 67 101 108 108 0 50 48 0 49 53 0 10 67 101 108 108 0 50 48 0 50 0 10 67 101 108 108 0 50 48 0 53 0 10 67 101 108 108 0 50 48 0 55 0 10 67 101 108 108 0 50 48 0 57 0 11 67 101 108 108 0 50 49 0 49 51 0 11 67 101 108 108 0 50 49 0 49 53 0 10 67 101 108 108 0 50 49 0 52 0 10 67 101 108 108 0 50 49 0 56 0 10 67 101 108 108 0 50 49 0 57 0 11 67 101 108 108 0 50 50 0 49 54 0 10 67 101 108 108 0 50 50 0 50 0 11 67 101 108 108 0 50 50 0 50 50 0 10 67 101 108 108 0 50 51 0 49 0 10 67 101 108 108 0 50 51 0 50 0 10 67 101 108 108 0 50 51 0 53 0 10 67 101 108 108 0 50 51 0 55 0 10 67 101 108 108 0 50 51 0 57 0 9 67 101 108 108 0 51 0 49 0 9 67 101 108 108 0 51 0 50 0 10 67 101 108 108 0 51 0 50 49 0 9 67 101 108 108 0 51 0 53 0 9 67 101 108 108 0 51 0 55 0 10 67 101 108 108 0 52 0 49 49 0 10 67 101 108 108 0 52 0 49 53 0 10 67 101 108 108 0 52 0 49 54 0 10 67 101 108 108 0 52 0 49 57 0 10 67 101 108 108 0 52 0 50 48 0 10 67 101 108 108 0 52 0 50 51 0 9 67 101 108 108 0 52 0 56 0 10 67 101 108 108 0 53 0 49 48 0 10 67 101 108 108 0 53 0 49 50 0 10 67 101 108 108 0 53 0 49 56 0 10 67 101 108 108 0 53 0 49 57 0 9 67 101 108 108 0 53 0 55 0 9 67 101 108 108 0 54 0 49 0 10 67 101 108 108 0 54 0 49 52 0 9 67 101 108 108 0 54 0 50 0 10 67 101 108 108 0 54 0 50 48 0 9 67 101 108 108 0 54 0 52 0 9 67 101 108 108 0 54 0 54 0 9 67 101 108 108 0 55 0 49 0 10 67 101 108 108 0 55 0 49 48 0 10 67 101 108 108 0 55 0 49 52 0 10 67 101 108 108 0 55 0 49 57 0 10 67 101 108 108 0 55 0 50 48 0 9 67 101 108 108 0 55 0 52 0 9 67 101 108 108 0 55 0 53 0 10 67 101 108 108 0 56 0 49 49 0 10 67 101 108 108 0 56 0 49 57 0 10 67 101 108 108 0 56 0 50 49 0 9 67 101 108 108 0 56 0 53 0 9 67 101 108 108 0 56 0 54 0 9 67 101 108 108 0 56 0 57 0 10 67 101 108 108 0 57 0 49 50 0 10 67 101 108 108 0 57 0 49 55 0 10 67 101 108 108 0 57 0 49 57 0 10 67 101 108 108 0 57 0 50 51 0 9 67 101 108 108 0 57 0 51 0 9 67 101 108 108 0 57 0 52 0 9 67 101 108 108 0 57 0 53 0 9 67 101 108 108 0 57 0 55 0"));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[49]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("53 4 0 49 51 0 4 0 49 52 0 4 0 50 48 0 5 48 0 49 50 0 5 48 0 49 56 0 5 48 0 50 51 0 4 48 0 54 0 4 48 0 57 0 5 49 0 49 49 0 5 49 0 49 50 0 5 49 0 50 51 0 4 49 0 51 0 4 49 0 53 0 5 50 0 49 54 0 5 50 0 49 57 0 4 50 0 50 0 5 51 0 49 52 0 5 51 0 50 48 0 5 51 0 50 49 0 4 51 0 57 0 4 52 0 48 0 5 52 0 49 56 0 4 52 0 54 0 4 52 0 56 0 4 52 0 57 0 4 53 0 49 0 5 53 0 49 54 0 5 53 0 49 55 0 5 53 0 49 57 0 5 53 0 50 48 0 4 53 0 51 0 4 53 0 53 0 4 53 0 54 0 4 54 0 48 0 5 55 0 49 50 0 5 55 0 49 54 0 5 55 0 49 56 0 4 55 0 50 0 4 55 0 51 0 4 55 0 52 0 4 55 0 54 0 4 55 0 55 0 4 55 0 57 0 5 56 0 49 48 0 5 56 0 49 50 0 5 56 0 49 51 0 5 56 0 49 53 0 5 56 0 49 55 0 5 56 0 50 50 0 4 56 0 53 0 5 57 0 49 56 0 5 57 0 50 49 0 4 57 0 51 0"));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[50]));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("21 4 0 49 48 0 4 0 49 51 0 4 0 50 49 0 5 48 0 49 53 0 4 48 0 50 0 4 48 0 53 0 4 48 0 55 0 4 48 0 57 0 5 49 0 49 51 0 5 49 0 49 53 0 4 49 0 52 0 4 49 0 56 0 4 49 0 57 0 5 50 0 49 54 0 4 50 0 50 0 5 50 0 50 50 0 4 51 0 49 0 4 51 0 50 0 4 51 0 53 0 4 51 0 55 0 4 51 0 57 0"));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[51]));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 3 0 49 0 3 0 50 0 4 0 50 49 0 3 0 53 0 3 0 55 0"));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[52]));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 49 49 0 4 0 49 53 0 4 0 49 54 0 4 0 49 57 0 4 0 50 48 0 4 0 50 51 0 3 0 56 0"));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[53]));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 49 48 0 4 0 49 50 0 4 0 49 56 0 4 0 49 57 0 3 0 55 0"));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[54]));
static CONSTANT_15: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 3 0 49 0 4 0 49 52 0 3 0 50 0 4 0 50 48 0 3 0 52 0 3 0 54 0"));
static CONSTANT_16: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[55]));
static CONSTANT_17: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 3 0 49 0 4 0 49 48 0 4 0 49 52 0 4 0 49 57 0 4 0 50 48 0 3 0 52 0 3 0 53 0"));
static CONSTANT_18: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[56]));
static CONSTANT_19: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 0 49 49 0 4 0 49 57 0 4 0 50 49 0 3 0 53 0 3 0 54 0 3 0 57 0"));
static CONSTANT_20: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[57]));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 4 0 49 50 0 4 0 49 55 0 4 0 49 57 0 4 0 50 51 0 3 0 51 0 3 0 52 0 3 0 53 0 3 0 55 0"));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[67,101,108,108,0]));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("387 6 45 49 0 45 49 0 6 45 49 0 45 50 0 5 45 49 0 48 0 8 45 49 48 0 45 49 48 0 8 45 49 48 0 45 49 49 0 7 45 49 48 0 45 57 0 8 45 49 49 0 45 49 48 0 8 45 49 49 0 45 49 49 0 8 45 49 49 0 45 49 50 0 8 45 49 50 0 45 49 49 0 8 45 49 50 0 45 49 50 0 8 45 49 50 0 45 49 51 0 8 45 49 51 0 45 49 50 0 8 45 49 51 0 45 49 51 0 8 45 49 51 0 45 49 52 0 8 45 49 52 0 45 49 51 0 8 45 49 52 0 45 49 52 0 8 45 49 52 0 45 49 53 0 8 45 49 53 0 45 49 52 0 8 45 49 53 0 45 49 53 0 8 45 49 53 0 45 49 54 0 8 45 49 54 0 45 49 53 0 8 45 49 54 0 45 49 54 0 8 45 49 54 0 45 49 55 0 8 45 49 55 0 45 49 54 0 8 45 49 55 0 45 49 55 0 8 45 49 55 0 45 49 56 0 8 45 49 56 0 45 49 55 0 8 45 49 56 0 45 49 56 0 8 45 49 56 0 45 49 57 0 8 45 49 57 0 45 49 56 0 8 45 49 57 0 45 49 57 0 8 45 49 57 0 45 50 48 0 6 45 50 0 45 49 0 6 45 50 0 45 50 0 6 45 50 0 45 51 0 8 45 50 48 0 45 49 57 0 8 45 50 48 0 45 50 48 0 8 45 50 48 0 45 50 49 0 8 45 50 49 0 45 50 48 0 8 45 50 49 0 45 50 49 0 8 45 50 49 0 45 50 50 0 8 45 50 50 0 45 50 49 0 8 45 50 50 0 45 50 50 0 8 45 50 50 0 45 50 51 0 8 45 50 51 0 45 50 50 0 8 45 50 51 0 45 50 51 0 8 45 50 51 0 45 50 52 0 8 45 50 52 0 45 50 51 0 8 45 50 52 0 45 50 52 0 8 45 50 52 0 45 50 53 0 8 45 50 53 0 45 50 52 0 8 45 50 53 0 45 50 53 0 8 45 50 53 0 45 50 54 0 8 45 50 54 0 45 50 53 0 8 45 50 54 0 45 50 54 0 8 45 50 54 0 45 50 55 0 8 45 50 55 0 45 50 54 0 8 45 50 55 0 45 50 55 0 8 45 50 55 0 45 50 56 0 8 45 50 56 0 45 50 55 0 8 45 50 56 0 45 50 56 0 8 45 50 56 0 45 50 57 0 8 45 50 57 0 45 50 56 0 8 45 50 57 0 45 50 57 0 8 45 50 57 0 45 51 48 0 6 45 51 0 45 50 0 6 45 51 0 45 51 0 6 45 51 0 45 52 0 8 45 51 48 0 45 50 57 0 8 45 51 48 0 45 51 48 0 8 45 51 48 0 45 51 49 0 8 45 51 49 0 45 51 48 0 8 45 51 49 0 45 51 49 0 8 45 51 49 0 45 51 50 0 8 45 51 50 0 45 51 49 0 8 45 51 50 0 45 51 50 0 8 45 51 50 0 45 51 51 0 8 45 51 51 0 45 51 50 0 8 45 51 51 0 45 51 51 0 8 45 51 51 0 45 51 52 0 8 45 51 52 0 45 51 51 0 8 45 51 52 0 45 51 52 0 8 45 51 52 0 45 51 53 0 8 45 51 53 0 45 51 52 0 8 45 51 53 0 45 51 53 0 8 45 51 53 0 45 51 54 0 8 45 51 54 0 45 51 53 0 8 45 51 54 0 45 51 54 0 8 45 51 54 0 45 51 55 0 8 45 51 55 0 45 51 54 0 8 45 51 55 0 45 51 55 0 8 45 51 55 0 45 51 56 0 8 45 51 56 0 45 51 55 0 8 45 51 56 0 45 51 56 0 8 45 51 56 0 45 51 57 0 8 45 51 57 0 45 51 56 0 8 45 51 57 0 45 51 57 0 8 45 51 57 0 45 52 48 0 6 45 52 0 45 51 0 6 45 52 0 45 52 0 6 45 52 0 45 53 0 8 45 52 48 0 45 51 57 0 8 45 52 48 0 45 52 48 0 8 45 52 48 0 45 52 49 0 8 45 52 49 0 45 52 48 0 8 45 52 49 0 45 52 49 0 8 45 52 49 0 45 52 50 0 8 45 52 50 0 45 52 49 0 8 45 52 50 0 45 52 50 0 8 45 52 50 0 45 52 51 0 8 45 52 51 0 45 52 50 0 8 45 52 51 0 45 52 51 0 8 45 52 51 0 45 52 52 0 8 45 52 52 0 45 52 51 0 8 45 52 52 0 45 52 52 0 8 45 52 52 0 45 52 53 0 8 45 52 53 0 45 52 52 0 8 45 52 53 0 45 52 53 0 8 45 52 53 0 45 52 54 0 8 45 52 54 0 45 52 53 0 8 45 52 54 0 45 52 54 0 8 45 52 54 0 45 52 55 0 8 45 52 55 0 45 52 54 0 8 45 52 55 0 45 52 55 0 8 45 52 55 0 45 52 56 0 8 45 52 56 0 45 52 55 0 8 45 52 56 0 45 52 56 0 8 45 52 56 0 45 52 57 0 8 45 52 57 0 45 52 56 0 8 45 52 57 0 45 52 57 0 8 45 52 57 0 45 53 48 0 6 45 53 0 45 52 0 6 45 53 0 45 53 0 6 45 53 0 45 54 0 8 45 53 48 0 45 52 57 0 8 45 53 48 0 45 53 48 0 8 45 53 48 0 45 53 49 0 8 45 53 49 0 45 53 48 0 8 45 53 49 0 45 53 49 0 8 45 53 49 0 45 53 50 0 8 45 53 50 0 45 53 49 0 8 45 53 50 0 45 53 50 0 8 45 53 50 0 45 53 51 0 8 45 53 51 0 45 53 50 0 8 45 53 51 0 45 53 51 0 8 45 53 51 0 45 53 52 0 8 45 53 52 0 45 53 51 0 8 45 53 52 0 45 53 52 0 8 45 53 52 0 45 53 53 0 8 45 53 53 0 45 53 52 0 8 45 53 53 0 45 53 53 0 8 45 53 53 0 45 53 54 0 8 45 53 54 0 45 53 53 0 8 45 53 54 0 45 53 54 0 8 45 53 54 0 45 53 55 0 8 45 53 55 0 45 53 54 0 8 45 53 55 0 45 53 55 0 8 45 53 55 0 45 53 56 0 8 45 53 56 0 45 53 55 0 8 45 53 56 0 45 53 56 0 8 45 53 56 0 45 53 57 0 8 45 53 57 0 45 53 56 0 8 45 53 57 0 45 53 57 0 8 45 53 57 0 45 54 48 0 6 45 54 0 45 53 0 6 45 54 0 45 54 0 6 45 54 0 45 55 0 8 45 54 48 0 45 53 57 0 8 45 54 48 0 45 54 48 0 8 45 54 48 0 45 54 49 0 8 45 54 49 0 45 54 48 0 8 45 54 49 0 45 54 49 0 8 45 54 49 0 45 54 50 0 8 45 54 50 0 45 54 49 0 8 45 54 50 0 45 54 50 0 8 45 54 50 0 45 54 51 0 8 45 54 51 0 45 54 50 0 8 45 54 51 0 45 54 51 0 8 45 54 51 0 45 54 52 0 8 45 54 52 0 45 54 51 0 8 45 54 52 0 45 54 52 0 8 45 54 52 0 45 54 53 0 6 45 55 0 45 54 0 6 45 55 0 45 55 0 6 45 55 0 45 56 0 6 45 56 0 45 55 0 6 45 56 0 45 56 0 6 45 56 0 45 57 0 7 45 57 0 45 49 48 0 6 45 57 0 45 56 0 6 45 57 0 45 57 0 5 48 0 45 49 0 4 48 0 48 0 4 48 0 49 0 4 49 0 48 0 4 49 0 49 0 4 49 0 50 0 6 49 48 0 49 48 0 6 49 48 0 49 49 0 5 49 48 0 57 0 6 49 49 0 49 48 0 6 49 49 0 49 49 0 6 49 49 0 49 50 0 6 49 50 0 49 49 0 6 49 50 0 49 50 0 6 49 50 0 49 51 0 6 49 51 0 49 50 0 6 49 51 0 49 51 0 6 49 51 0 49 52 0 6 49 52 0 49 51 0 6 49 52 0 49 52 0 6 49 52 0 49 53 0 6 49 53 0 49 52 0 6 49 53 0 49 53 0 6 49 53 0 49 54 0 6 49 54 0 49 53 0 6 49 54 0 49 54 0 6 49 54 0 49 55 0 6 49 55 0 49 54 0 6 49 55 0 49 55 0 6 49 55 0 49 56 0 6 49 56 0 49 55 0 6 49 56 0 49 56 0 6 49 56 0 49 57 0 6 49 57 0 49 56 0 6 49 57 0 49 57 0 6 49 57 0 50 48 0 4 50 0 49 0 4 50 0 50 0 4 50 0 51 0 6 50 48 0 49 57 0 6 50 48 0 50 48 0 6 50 48 0 50 49 0 6 50 49 0 50 48 0 6 50 49 0 50 49 0 6 50 49 0 50 50 0 6 50 50 0 50 49 0 6 50 50 0 50 50 0 6 50 50 0 50 51 0 6 50 51 0 50 50 0 6 50 51 0 50 51 0 6 50 51 0 50 52 0 6 50 52 0 50 51 0 6 50 52 0 50 52 0 6 50 52 0 50 53 0 6 50 53 0 50 52 0 6 50 53 0 50 53 0 6 50 53 0 50 54 0 6 50 54 0 50 53 0 6 50 54 0 50 54 0 6 50 54 0 50 55 0 6 50 55 0 50 54 0 6 50 55 0 50 55 0 6 50 55 0 50 56 0 6 50 56 0 50 55 0 6 50 56 0 50 56 0 6 50 56 0 50 57 0 6 50 57 0 50 56 0 6 50 57 0 50 57 0 6 50 57 0 51 48 0 4 51 0 50 0 4 51 0 51 0 4 51 0 52 0 6 51 48 0 50 57 0 6 51 48 0 51 48 0 6 51 48 0 51 49 0 6 51 49 0 51 48 0 6 51 49 0 51 49 0 6 51 49 0 51 50 0 6 51 50 0 51 49 0 6 51 50 0 51 50 0 6 51 50 0 51 51 0 6 51 51 0 51 50 0 6 51 51 0 51 51 0 6 51 51 0 51 52 0 6 51 52 0 51 51 0 6 51 52 0 51 52 0 6 51 52 0 51 53 0 6 51 53 0 51 52 0 6 51 53 0 51 53 0 6 51 53 0 51 54 0 6 51 54 0 51 53 0 6 51 54 0 51 54 0 6 51 54 0 51 55 0 6 51 55 0 51 54 0 6 51 55 0 51 55 0 6 51 55 0 51 56 0 6 51 56 0 51 55 0 6 51 56 0 51 56 0 6 51 56 0 51 57 0 6 51 57 0 51 56 0 6 51 57 0 51 57 0 6 51 57 0 52 48 0 4 52 0 51 0 4 52 0 52 0 4 52 0 53 0 6 52 48 0 51 57 0 6 52 48 0 52 48 0 6 52 48 0 52 49 0 6 52 49 0 52 48 0 6 52 49 0 52 49 0 6 52 49 0 52 50 0 6 52 50 0 52 49 0 6 52 50 0 52 50 0 6 52 50 0 52 51 0 6 52 51 0 52 50 0 6 52 51 0 52 51 0 6 52 51 0 52 52 0 6 52 52 0 52 51 0 6 52 52 0 52 52 0 6 52 52 0 52 53 0 6 52 53 0 52 52 0 6 52 53 0 52 53 0 6 52 53 0 52 54 0 6 52 54 0 52 53 0 6 52 54 0 52 54 0 6 52 54 0 52 55 0 6 52 55 0 52 54 0 6 52 55 0 52 55 0 6 52 55 0 52 56 0 6 52 56 0 52 55 0 6 52 56 0 52 56 0 6 52 56 0 52 57 0 6 52 57 0 52 56 0 6 52 57 0 52 57 0 6 52 57 0 53 48 0 4 53 0 52 0 4 53 0 53 0 4 53 0 54 0 6 53 48 0 52 57 0 6 53 48 0 53 48 0 6 53 48 0 53 49 0 6 53 49 0 53 48 0 6 53 49 0 53 49 0 6 53 49 0 53 50 0 6 53 50 0 53 49 0 6 53 50 0 53 50 0 6 53 50 0 53 51 0 6 53 51 0 53 50 0 6 53 51 0 53 51 0 6 53 51 0 53 52 0 6 53 52 0 53 51 0 6 53 52 0 53 52 0 6 53 52 0 53 53 0 6 53 53 0 53 52 0 6 53 53 0 53 53 0 6 53 53 0 53 54 0 6 53 54 0 53 53 0 6 53 54 0 53 54 0 6 53 54 0 53 55 0 6 53 55 0 53 54 0 6 53 55 0 53 55 0 6 53 55 0 53 56 0 6 53 56 0 53 55 0 6 53 56 0 53 56 0 6 53 56 0 53 57 0 6 53 57 0 53 56 0 6 53 57 0 53 57 0 6 53 57 0 54 48 0 4 54 0 53 0 4 54 0 54 0 4 54 0 55 0 6 54 48 0 53 57 0 6 54 48 0 54 48 0 6 54 48 0 54 49 0 6 54 49 0 54 48 0 6 54 49 0 54 49 0 6 54 49 0 54 50 0 6 54 50 0 54 49 0 6 54 50 0 54 50 0 6 54 50 0 54 51 0 6 54 51 0 54 50 0 6 54 51 0 54 51 0 6 54 51 0 54 52 0 6 54 52 0 54 51 0 6 54 52 0 54 52 0 6 54 52 0 54 53 0 4 55 0 54 0 4 55 0 55 0 4 55 0 56 0 4 56 0 55 0 4 56 0 56 0 4 56 0 57 0 5 57 0 49 48 0 4 57 0 56 0 4 57 0 57 0"));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 104 105 116 0"));
fn routine_0(c: &mut Context) -> Space {
  let v0_50: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v1_4: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2), &(*CONSTANT_3));
    let v1_8: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_5), &(*CONSTANT_3));
    let v1_9: Space = unite(&(v1_4),&(v1_8));
    let v1_13: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_7), &(*CONSTANT_3));
    let v1_14: Space = unite(&(v1_9),&(v1_13));
    let v1_18: Space = routine_1(c, &(*CONSTANT_8), &(*CONSTANT_9), &(*CONSTANT_3));
    let v1_19: Space = unite(&(v1_14),&(v1_18));
    let v1_23: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_11), &(*CONSTANT_3));
    let v1_24: Space = unite(&(v1_19),&(v1_23));
    let v1_28: Space = routine_1(c, &(*CONSTANT_12), &(*CONSTANT_13), &(*CONSTANT_3));
    let v1_29: Space = unite(&(v1_24),&(v1_28));
    let v1_33: Space = routine_1(c, &(*CONSTANT_14), &(*CONSTANT_15), &(*CONSTANT_3));
    let v1_34: Space = unite(&(v1_29),&(v1_33));
    let v1_38: Space = routine_1(c, &(*CONSTANT_16), &(*CONSTANT_17), &(*CONSTANT_3));
    let v1_39: Space = unite(&(v1_34),&(v1_38));
    let v1_43: Space = routine_1(c, &(*CONSTANT_18), &(*CONSTANT_19), &(*CONSTANT_3));
    let v1_44: Space = unite(&(v1_39),&(v1_43));
    let v1_48: Space = routine_1(c, &(*CONSTANT_20), &(*CONSTANT_21), &(*CONSTANT_3));
    let v1_49: Space = unite(&(v1_44),&(v1_48));
    compose(&(*CONSTANT_0),&(v1_49))
  };
  let v0_81: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v2_53: Space = routine_2(c, &(*CONSTANT_1), &(*CONSTANT_2));
    let v2_55: Space = routine_2(c, &(*CONSTANT_4), &(*CONSTANT_5));
    let v2_56: Space = unite(&(v2_53),&(v2_55));
    let v2_58: Space = routine_2(c, &(*CONSTANT_6), &(*CONSTANT_7));
    let v2_59: Space = unite(&(v2_56),&(v2_58));
    let v2_61: Space = routine_2(c, &(*CONSTANT_8), &(*CONSTANT_9));
    let v2_62: Space = unite(&(v2_59),&(v2_61));
    let v2_64: Space = routine_2(c, &(*CONSTANT_10), &(*CONSTANT_11));
    let v2_65: Space = unite(&(v2_62),&(v2_64));
    let v2_67: Space = routine_2(c, &(*CONSTANT_12), &(*CONSTANT_13));
    let v2_68: Space = unite(&(v2_65),&(v2_67));
    let v2_70: Space = routine_2(c, &(*CONSTANT_14), &(*CONSTANT_15));
    let v2_71: Space = unite(&(v2_68),&(v2_70));
    let v2_73: Space = routine_2(c, &(*CONSTANT_16), &(*CONSTANT_17));
    let v2_74: Space = unite(&(v2_71),&(v2_73));
    let v2_76: Space = routine_2(c, &(*CONSTANT_18), &(*CONSTANT_19));
    let v2_77: Space = unite(&(v2_74),&(v2_76));
    let v2_79: Space = routine_2(c, &(*CONSTANT_20), &(*CONSTANT_21));
    let v2_80: Space = unite(&(v2_77),&(v2_79));
    compose(&(*CONSTANT_0),&(v2_80))
  };
  let mut v0_87 = Space::new();
  let mut v0_87_cursor = (v0_81).read_zipper();
  for v0_87_byte in v0_87_cursor.child_mask().iter() {
    v0_87_cursor.descend_to_byte(v0_87_byte);
    let v0_87_tail = v0_87_cursor.make_map();
    v0_87_cursor.ascend(1);
    let v0_87_head = Path::from_slice(&[v0_87_byte]);
    let v3_2: Space = singleton(&(v0_87_head));
    let v3_3: Space = intersect(&(*CONSTANT_22),&(v3_2));
    let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
    drop(v3_3);
    let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
    drop(v3_4);
    let v3_7: Space = if (v3_5).is_empty() { Space::new() } else {
      let v4_6: Space = routine_3(c, &(v0_87_head), &(v0_87_tail), &(*CONSTANT_3));
      compose(&(v3_5),&(v4_6))
    };
    drop(v3_5);
    let v3_8: Space = intersect(&(*CONSTANT_22),&(v3_2));
    drop(v3_2);
    let v3_9: Space = if has_head(&(v3_8)) { singleton(&[]) } else { Space::new() };
    drop(v3_8);
    let v3_11: Space = if (v3_9).is_empty() { Space::new() } else {
      let v5_10: Space = routine_4(c, &(v0_87_head), &(v0_87_tail), &(*CONSTANT_3));
      compose(&(v3_9),&(v5_10))
    };
    drop(v3_9);
    let v3_12: Space = unite(&(v3_7),&(v3_11));
    v0_87.join_into((v3_12).clone());
  }
  drop(v0_87_cursor);
  let v0_88: Space = unite(&(v0_50),&(v0_87));
  let v0_90: Space = wrap(&(v0_88),&(*CONSTANT_23));
  (v0_90).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v6_9 = Space::new();
  let mut v6_9_cursor = (*s0).read_zipper();
  for v6_9_byte in v6_9_cursor.child_mask().iter() {
    v6_9_cursor.descend_to_byte(v6_9_byte);
    let v6_9_tail = v6_9_cursor.make_map();
    v6_9_cursor.ascend(1);
    let v6_9_head = Path::from_slice(&[v6_9_byte]);
    let v7_2: Space = singleton(&(v6_9_head));
    let v7_3: Space = intersect(&(*CONSTANT_22),&(v7_2));
    let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
    drop(v7_3);
    let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
    drop(v7_4);
    let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
      let v8_6: Path = concat_path(&(*p0),&(v6_9_head));
      let v8_7: Space = routine_1(c, &(v8_6), &(v6_9_tail), &(*s1));
      compose(&(v7_5),&(v8_7))
    };
    drop(v7_5);
    let v7_9: Space = intersect(&(*CONSTANT_22),&(v7_2));
    drop(v7_2);
    let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
    drop(v7_9);
    let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
      let v9_6: Path = concat_path(&(*p0),&(v6_9_head));
      let mut v9_11 = Space::new();
      let mut v9_11_cursor = (v6_9_tail).read_zipper();
      for v9_11_byte in v9_11_cursor.child_mask().iter() {
        v9_11_cursor.descend_to_byte(v9_11_byte);
        let v9_11_tail = v9_11_cursor.make_map();
        v9_11_cursor.ascend(1);
        let v9_11_head = Path::from_slice(&[v9_11_byte]);
        let v10_2: Space = singleton(&(v9_11_head));
        let v10_3: Space = intersect(&(*CONSTANT_22),&(v10_2));
        let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
        drop(v10_3);
        let v10_5: Space = subtract(&(*CONSTANT_0),&(v10_4));
        drop(v10_4);
        let v10_7: Space = if (v10_5).is_empty() { Space::new() } else {
          let v11_6: Space = routine_5(c, &(v9_11_head), &(v9_6), &(v9_11_tail), &(*s1));
          compose(&(v10_5),&(v11_6))
        };
        drop(v10_5);
        let v10_8: Space = intersect(&(*CONSTANT_22),&(v10_2));
        drop(v10_2);
        let v10_9: Space = if has_head(&(v10_8)) { singleton(&[]) } else { Space::new() };
        drop(v10_8);
        let v10_11: Space = if (v10_9).is_empty() { Space::new() } else {
          let v12_10: Space = routine_6(c, &(v9_11_head), &(v9_6), &(v9_11_tail), &(*s1));
          compose(&(v10_9),&(v12_10))
        };
        drop(v10_9);
        let v10_12: Space = unite(&(v10_7),&(v10_11));
        v9_11.join_into((v10_12).clone());
      }
      drop(v9_11_cursor);
      drop(v9_6);
      compose(&(v7_10),&(v9_11))
    };
    drop(v7_10);
    let v7_13: Space = unite(&(v7_8),&(v7_12));
    v6_9.join_into((v7_13).clone());
  }
  drop(v6_9_cursor);
  (v6_9).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v13_8 = Space::new();
  let mut v13_8_cursor = (*s0).read_zipper();
  for v13_8_byte in v13_8_cursor.child_mask().iter() {
    v13_8_cursor.descend_to_byte(v13_8_byte);
    let v13_8_tail = v13_8_cursor.make_map();
    v13_8_cursor.ascend(1);
    let v13_8_head = Path::from_slice(&[v13_8_byte]);
    let v14_2: Space = singleton(&(v13_8_head));
    let v14_3: Space = intersect(&(*CONSTANT_22),&(v14_2));
    let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
    drop(v14_3);
    let v14_5: Space = subtract(&(*CONSTANT_0),&(v14_4));
    drop(v14_4);
    let v14_8: Space = if (v14_5).is_empty() { Space::new() } else {
      let v15_6: Path = concat_path(&(*p0),&(v13_8_head));
      let v15_7: Space = routine_2(c, &(v15_6), &(v13_8_tail));
      compose(&(v14_5),&(v15_7))
    };
    drop(v14_5);
    let v14_9: Space = intersect(&(*CONSTANT_22),&(v14_2));
    drop(v14_2);
    let v14_10: Space = if has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
    drop(v14_9);
    let v14_12: Space = if (v14_10).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v13_8_head));
      let mut v16_11 = Space::new();
      let mut v16_11_cursor = (v13_8_tail).read_zipper();
      for v16_11_byte in v16_11_cursor.child_mask().iter() {
        v16_11_cursor.descend_to_byte(v16_11_byte);
        let v16_11_tail = v16_11_cursor.make_map();
        v16_11_cursor.ascend(1);
        let v16_11_head = Path::from_slice(&[v16_11_byte]);
        let v17_2: Space = singleton(&(v16_11_head));
        let v17_3: Space = intersect(&(*CONSTANT_22),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
        drop(v17_4);
        let v17_7: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Space = routine_7(c, &(v16_11_head), &(v16_6), &(v16_11_tail));
          compose(&(v17_5),&(v18_6))
        };
        drop(v17_5);
        let v17_8: Space = intersect(&(*CONSTANT_22),&(v17_2));
        drop(v17_2);
        let v17_9: Space = if has_head(&(v17_8)) { singleton(&[]) } else { Space::new() };
        drop(v17_8);
        let v17_11: Space = if (v17_9).is_empty() { Space::new() } else {
          let v19_10: Space = routine_8(c, &(v16_11_head), &(v16_6), &(v16_11_tail));
          compose(&(v17_9),&(v19_10))
        };
        drop(v17_9);
        let v17_12: Space = unite(&(v17_7),&(v17_11));
        v16_11.join_into((v17_12).clone());
      }
      drop(v16_11_cursor);
      drop(v16_6);
      compose(&(v14_10),&(v16_11))
    };
    drop(v14_10);
    let v14_13: Space = unite(&(v14_8),&(v14_12));
    v13_8.join_into((v14_13).clone());
  }
  drop(v13_8_cursor);
  (v13_8).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v20_9 = Space::new();
  let mut v20_9_cursor = (*s0).read_zipper();
  for v20_9_byte in v20_9_cursor.child_mask().iter() {
    v20_9_cursor.descend_to_byte(v20_9_byte);
    let v20_9_tail = v20_9_cursor.make_map();
    v20_9_cursor.ascend(1);
    let v20_9_head = Path::from_slice(&[v20_9_byte]);
    let v21_2: Space = singleton(&(v20_9_head));
    let v21_3: Space = intersect(&(*CONSTANT_22),&(v21_2));
    let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
    drop(v21_3);
    let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
    drop(v21_4);
    let v21_8: Space = if (v21_5).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&(v20_9_head));
      let v22_7: Space = routine_3(c, &(v22_6), &(v20_9_tail), &(*s1));
      compose(&(v21_5),&(v22_7))
    };
    drop(v21_5);
    let v21_9: Space = intersect(&(*CONSTANT_22),&(v21_2));
    drop(v21_2);
    let v21_10: Space = if has_head(&(v21_9)) { singleton(&[]) } else { Space::new() };
    drop(v21_9);
    let v21_12: Space = if (v21_10).is_empty() { Space::new() } else {
      let v23_6: Path = concat_path(&(*p0),&(v20_9_head));
      let mut v23_11 = Space::new();
      let mut v23_11_cursor = (v20_9_tail).read_zipper();
      for v23_11_byte in v23_11_cursor.child_mask().iter() {
        v23_11_cursor.descend_to_byte(v23_11_byte);
        let v23_11_tail = v23_11_cursor.make_map();
        v23_11_cursor.ascend(1);
        let v23_11_head = Path::from_slice(&[v23_11_byte]);
        let v24_2: Space = singleton(&(v23_11_head));
        let v24_3: Space = intersect(&(*CONSTANT_22),&(v24_2));
        let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
        drop(v24_3);
        let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
        drop(v24_4);
        let v24_7: Space = if (v24_5).is_empty() { Space::new() } else {
          let v25_6: Space = routine_9(c, &(v23_11_head), &(v23_6), &(v23_11_tail), &(*s1));
          compose(&(v24_5),&(v25_6))
        };
        drop(v24_5);
        let v24_8: Space = intersect(&(*CONSTANT_22),&(v24_2));
        drop(v24_2);
        let v24_9: Space = if has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
        drop(v24_8);
        let v24_11: Space = if (v24_9).is_empty() { Space::new() } else {
          let v26_10: Space = routine_10(c, &(v23_11_head), &(v23_6), &(v23_11_tail), &(*s1));
          compose(&(v24_9),&(v26_10))
        };
        drop(v24_9);
        let v24_12: Space = unite(&(v24_7),&(v24_11));
        v23_11.join_into((v24_12).clone());
      }
      drop(v23_11_cursor);
      drop(v23_6);
      compose(&(v21_10),&(v23_11))
    };
    drop(v21_10);
    let v21_13: Space = unite(&(v21_8),&(v21_12));
    v20_9.join_into((v21_13).clone());
  }
  drop(v20_9_cursor);
  (v20_9).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v27_7: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let v27_10: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v27_12: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let mut v27_26 = Space::new();
  let mut v27_26_cursor = (*s0).read_zipper();
  for v27_26_byte in v27_26_cursor.child_mask().iter() {
    v27_26_cursor.descend_to_byte(v27_26_byte);
    let v27_26_tail = v27_26_cursor.make_map();
    v27_26_cursor.ascend(1);
    let v27_26_head = Path::from_slice(&[v27_26_byte]);
    let v28_2: Space = singleton(&(v27_26_head));
    let v28_3: Space = intersect(&(*CONSTANT_22),&(v28_2));
    let v28_4: Space = if has_head(&(v28_3)) { singleton(&[]) } else { Space::new() };
    drop(v28_3);
    let v28_5: Space = subtract(&(*CONSTANT_0),&(v28_4));
    drop(v28_4);
    let v28_7: Space = if (v28_5).is_empty() { Space::new() } else {
      let mut v29_6 = Space::new();
      let mut v29_6_cursor = (v27_26_tail).read_zipper();
      for v29_6_byte in v29_6_cursor.child_mask().iter() {
        v29_6_cursor.descend_to_byte(v29_6_byte);
        let v29_6_tail = v29_6_cursor.make_map();
        v29_6_cursor.ascend(1);
        let v29_6_head = Path::from_slice(&[v29_6_byte]);
        let v30_2: Space = singleton(&(v29_6_head));
        let v30_3: Space = intersect(&(*CONSTANT_22),&(v30_2));
        let v30_4: Space = if has_head(&(v30_3)) { singleton(&[]) } else { Space::new() };
        drop(v30_3);
        let v30_5: Space = subtract(&(*CONSTANT_0),&(v30_4));
        drop(v30_4);
        let v30_8: Space = if (v30_5).is_empty() { Space::new() } else {
          let v31_6: Path = concat_path(&(v27_26_head),&(v29_6_head));
          let v31_7: Space = routine_9(c, &(v31_6), &(*p0), &(v29_6_tail), &(*s1));
          compose(&(v30_5),&(v31_7))
        };
        drop(v30_5);
        let v30_9: Space = intersect(&(*CONSTANT_22),&(v30_2));
        drop(v30_2);
        let v30_10: Space = if has_head(&(v30_9)) { singleton(&[]) } else { Space::new() };
        drop(v30_9);
        let v30_12: Space = if (v30_10).is_empty() { Space::new() } else {
          let v32_6: Path = concat_path(&(v27_26_head),&(v29_6_head));
          let v32_11: Space = routine_10(c, &(v32_6), &(*p0), &(v29_6_tail), &(*s1));
          drop(v32_6);
          compose(&(v30_10),&(v32_11))
        };
        drop(v30_10);
        let v30_13: Space = unite(&(v30_8),&(v30_12));
        v29_6.join_into((v30_13).clone());
      }
      drop(v29_6_cursor);
      compose(&(v28_5),&(v29_6))
    };
    drop(v28_5);
    let v28_8: Space = intersect(&(*CONSTANT_22),&(v28_2));
    drop(v28_2);
    let v28_9: Space = if has_head(&(v28_8)) { singleton(&[]) } else { Space::new() };
    drop(v28_8);
    let v28_27: Space = if (v28_9).is_empty() { Space::new() } else {
      let v33_10: Space = unwrap(&(*CONSTANT_24),&(v27_26_head));
      let v33_11: Space = compose(&(v27_7),&(v33_10));
      drop(v33_10);
      let v33_12: Path = concat_path(&(*p0),&(v27_26_head));
      let v33_13: Space = singleton(&(v33_12));
      drop(v33_12);
      let v33_14: Space = subtract(&(v33_11),&(v33_13));
      drop(v33_11);
      let v33_15: Space = intersect(&(v33_14),&(v27_10));
      drop(v33_14);
      let v33_16: Space = range(&(v33_15),3,4);
      drop(v33_15);
      let mut v33_17 = Space::new();
      let mut v33_17_cursor = (v33_16).read_zipper();
      for v33_17_byte in v33_17_cursor.child_mask().iter() {
        v33_17_cursor.descend_to_byte(v33_17_byte);
        let v33_17_tail = v33_17_cursor.make_map();
        v33_17_cursor.ascend(1);
        let v33_17_head = Path::from_slice(&[v33_17_byte]);
        let v34_2: Space = singleton(&(v33_17_head));
        let v34_3: Space = intersect(&(*CONSTANT_22),&(v34_2));
        let v34_4: Space = if has_head(&(v34_3)) { singleton(&[]) } else { Space::new() };
        drop(v34_3);
        let v34_5: Space = subtract(&(*CONSTANT_0),&(v34_4));
        drop(v34_4);
        let v34_7: Space = if (v34_5).is_empty() { Space::new() } else {
          let v35_6: Space = routine_11(c, &(v33_17_head), &(v33_17_tail));
          compose(&(v34_5),&(v35_6))
        };
        drop(v34_5);
        let v34_8: Space = intersect(&(*CONSTANT_22),&(v34_2));
        drop(v34_2);
        let v34_9: Space = if has_head(&(v34_8)) { singleton(&[]) } else { Space::new() };
        drop(v34_8);
        let v34_11: Space = if (v34_9).is_empty() { Space::new() } else {
          let v36_10: Space = routine_12(c, &(v33_17_head), &(v33_17_tail));
          compose(&(v34_9),&(v36_10))
        };
        drop(v34_9);
        let v34_12: Space = unite(&(v34_7),&(v34_11));
        v33_17.join_into((v34_12).clone());
      }
      drop(v33_17_cursor);
      drop(v33_16);
      let v33_18: Space = unwrap(&(*CONSTANT_24),&(v27_26_head));
      let v33_19: Space = compose(&(v27_12),&(v33_18));
      drop(v33_18);
      let v33_20: Space = subtract(&(v33_19),&(v33_13));
      drop(v33_19);
      let v33_21: Space = intersect(&(v33_20),&(v27_10));
      drop(v33_20);
      let v33_22: Space = range(&(v33_21),4,5);
      drop(v33_21);
      let mut v33_23 = Space::new();
      let mut v33_23_cursor = (v33_22).read_zipper();
      for v33_23_byte in v33_23_cursor.child_mask().iter() {
        v33_23_cursor.descend_to_byte(v33_23_byte);
        let v33_23_tail = v33_23_cursor.make_map();
        v33_23_cursor.ascend(1);
        let v33_23_head = Path::from_slice(&[v33_23_byte]);
        let v37_2: Space = singleton(&(v33_23_head));
        let v37_3: Space = intersect(&(*CONSTANT_22),&(v37_2));
        let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
        drop(v37_3);
        let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
        drop(v37_4);
        let v37_7: Space = if (v37_5).is_empty() { Space::new() } else {
          let v38_6: Space = routine_13(c, &(v33_23_head), &(v33_23_tail));
          compose(&(v37_5),&(v38_6))
        };
        drop(v37_5);
        let v37_8: Space = intersect(&(*CONSTANT_22),&(v37_2));
        drop(v37_2);
        let v37_9: Space = if has_head(&(v37_8)) { singleton(&[]) } else { Space::new() };
        drop(v37_8);
        let v37_11: Space = if (v37_9).is_empty() { Space::new() } else {
          let v39_10: Space = routine_14(c, &(v33_23_head), &(v33_23_tail));
          compose(&(v37_9),&(v39_10))
        };
        drop(v37_9);
        let v37_12: Space = unite(&(v37_7),&(v37_11));
        v33_23.join_into((v37_12).clone());
      }
      drop(v33_23_cursor);
      drop(v33_22);
      let v33_24: Space = subtract(&(v33_17),&(v33_23));
      let v33_25: Space = if (v33_24).is_empty() { Space::new() } else {
        compose(&(v33_24),&(v33_13))
      };
      drop(v33_13);
      let mut v33_26 = Space::new();
      let mut v33_26_cursor = (v33_25).read_zipper();
      for v33_26_byte in v33_26_cursor.child_mask().iter() {
        v33_26_cursor.descend_to_byte(v33_26_byte);
        let v33_26_tail = v33_26_cursor.make_map();
        v33_26_cursor.ascend(1);
        let v33_26_head = Path::from_slice(&[v33_26_byte]);
        let v41_2: Space = singleton(&(v33_26_head));
        let v41_3: Space = intersect(&(*CONSTANT_22),&(v41_2));
        let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
        drop(v41_3);
        let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
        drop(v41_4);
        let v41_7: Space = if (v41_5).is_empty() { Space::new() } else {
          let v42_6: Space = routine_15(c, &(v33_26_head), &(v33_26_tail));
          compose(&(v41_5),&(v42_6))
        };
        drop(v41_5);
        let v41_8: Space = intersect(&(*CONSTANT_22),&(v41_2));
        drop(v41_2);
        let v41_9: Space = if has_head(&(v41_8)) { singleton(&[]) } else { Space::new() };
        drop(v41_8);
        let v41_11: Space = if (v41_9).is_empty() { Space::new() } else {
          let v43_10: Space = routine_16(c, &(v33_26_head), &(v33_26_tail));
          compose(&(v41_9),&(v43_10))
        };
        drop(v41_9);
        let v41_12: Space = unite(&(v41_7),&(v41_11));
        v33_26.join_into((v41_12).clone());
      }
      drop(v33_26_cursor);
      compose(&(v28_9),&(v33_26))
    };
    drop(v28_9);
    let v28_28: Space = unite(&(v28_7),&(v28_27));
    v27_26.join_into((v28_28).clone());
  }
  drop(v27_26_cursor);
  drop(v27_7);
  drop(v27_10);
  drop(v27_12);
  (v27_26).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v44_8: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v44_10: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let v44_12: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v44_14: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v44_16: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let mut v44_26 = Space::new();
  let mut v44_26_cursor = (*s0).read_zipper();
  for v44_26_byte in v44_26_cursor.child_mask().iter() {
    v44_26_cursor.descend_to_byte(v44_26_byte);
    let v44_26_tail = v44_26_cursor.make_map();
    v44_26_cursor.ascend(1);
    let v44_26_head = Path::from_slice(&[v44_26_byte]);
    let v45_2: Space = singleton(&(v44_26_head));
    let v45_3: Space = intersect(&(*CONSTANT_22),&(v45_2));
    let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
    drop(v45_3);
    let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
    drop(v45_4);
    let v45_8: Space = if (v45_5).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&(v44_26_head));
      let v46_7: Space = routine_5(c, &(v46_6), &(*p1), &(v44_26_tail), &(*s1));
      compose(&(v45_5),&(v46_7))
    };
    drop(v45_5);
    let v45_9: Space = intersect(&(*CONSTANT_22),&(v45_2));
    drop(v45_2);
    let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
    drop(v45_9);
    let v45_28: Space = if (v45_10).is_empty() { Space::new() } else {
      let v47_6: Path = concat_path(&(*p0),&(v44_26_head));
      let v47_12: Space = if (v44_8).is_empty() { Space::new() } else {
        let v48_11: Space = unwrap(&(v44_10),&(v44_26_head));
        compose(&(v44_8),&(v48_11))
      };
      let v47_13: Path = concat_path(&(*p1),&(v47_6));
      drop(v47_6);
      let v47_14: Space = singleton(&(v47_13));
      drop(v47_13);
      let v47_15: Space = subtract(&(v47_12),&(v47_14));
      drop(v47_12);
      let v47_16: Space = intersect(&(v47_15),&(v44_12));
      drop(v47_15);
      let v47_17: Space = range(&(v47_16),2,3);
      drop(v47_16);
      let mut v47_18 = Space::new();
      let mut v47_18_cursor = (v47_17).read_zipper();
      for v47_18_byte in v47_18_cursor.child_mask().iter() {
        v47_18_cursor.descend_to_byte(v47_18_byte);
        let v47_18_tail = v47_18_cursor.make_map();
        v47_18_cursor.ascend(1);
        let v47_18_head = Path::from_slice(&[v47_18_byte]);
        let v49_2: Space = singleton(&(v47_18_head));
        let v49_3: Space = intersect(&(*CONSTANT_22),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (v49_5).is_empty() { Space::new() } else {
          let v50_6: Space = routine_17(c, &(v47_18_head), &(v47_18_tail));
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_22),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (v49_9).is_empty() { Space::new() } else {
          let v51_10: Space = routine_18(c, &(v47_18_head), &(v47_18_tail));
          compose(&(v49_9),&(v51_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        v47_18.join_into((v49_12).clone());
      }
      drop(v47_18_cursor);
      drop(v47_17);
      let v47_20: Space = if (v44_14).is_empty() { Space::new() } else {
        let v52_19: Space = unwrap(&(v44_16),&(v44_26_head));
        compose(&(v44_14),&(v52_19))
      };
      let v47_21: Space = subtract(&(v47_20),&(v47_14));
      drop(v47_20);
      let v47_22: Space = intersect(&(v47_21),&(v44_12));
      drop(v47_21);
      let v47_23: Space = range(&(v47_22),3,4);
      drop(v47_22);
      let mut v47_24 = Space::new();
      let mut v47_24_cursor = (v47_23).read_zipper();
      for v47_24_byte in v47_24_cursor.child_mask().iter() {
        v47_24_cursor.descend_to_byte(v47_24_byte);
        let v47_24_tail = v47_24_cursor.make_map();
        v47_24_cursor.ascend(1);
        let v47_24_head = Path::from_slice(&[v47_24_byte]);
        let v53_2: Space = singleton(&(v47_24_head));
        let v53_3: Space = intersect(&(*CONSTANT_22),&(v53_2));
        let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
        drop(v53_3);
        let v53_5: Space = subtract(&(*CONSTANT_0),&(v53_4));
        drop(v53_4);
        let v53_7: Space = if (v53_5).is_empty() { Space::new() } else {
          let v54_6: Space = routine_19(c, &(v47_24_head), &(v47_24_tail));
          compose(&(v53_5),&(v54_6))
        };
        drop(v53_5);
        let v53_8: Space = intersect(&(*CONSTANT_22),&(v53_2));
        drop(v53_2);
        let v53_9: Space = if has_head(&(v53_8)) { singleton(&[]) } else { Space::new() };
        drop(v53_8);
        let v53_11: Space = if (v53_9).is_empty() { Space::new() } else {
          let v55_10: Space = routine_20(c, &(v47_24_head), &(v47_24_tail));
          compose(&(v53_9),&(v55_10))
        };
        drop(v53_9);
        let v53_12: Space = unite(&(v53_7),&(v53_11));
        v47_24.join_into((v53_12).clone());
      }
      drop(v47_24_cursor);
      drop(v47_23);
      let v47_25: Space = subtract(&(v47_18),&(v47_24));
      let v47_26: Space = if (v47_25).is_empty() { Space::new() } else {
        compose(&(v47_25),&(v47_14))
      };
      drop(v47_14);
      let mut v47_27 = Space::new();
      let mut v47_27_cursor = (v47_26).read_zipper();
      for v47_27_byte in v47_27_cursor.child_mask().iter() {
        v47_27_cursor.descend_to_byte(v47_27_byte);
        let v47_27_tail = v47_27_cursor.make_map();
        v47_27_cursor.ascend(1);
        let v47_27_head = Path::from_slice(&[v47_27_byte]);
        let v57_2: Space = singleton(&(v47_27_head));
        let v57_3: Space = intersect(&(*CONSTANT_22),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_0),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (v57_5).is_empty() { Space::new() } else {
          let v58_6: Space = routine_21(c, &(v47_27_head), &(v47_27_tail));
          compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = intersect(&(*CONSTANT_22),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (v57_9).is_empty() { Space::new() } else {
          let v59_10: Space = routine_22(c, &(v47_27_head), &(v47_27_tail));
          compose(&(v57_9),&(v59_10))
        };
        drop(v57_9);
        let v57_12: Space = unite(&(v57_7),&(v57_11));
        v47_27.join_into((v57_12).clone());
      }
      drop(v47_27_cursor);
      compose(&(v45_10),&(v47_27))
    };
    drop(v45_10);
    let v45_29: Space = unite(&(v45_8),&(v45_28));
    v44_26.join_into((v45_29).clone());
  }
  drop(v44_26_cursor);
  drop(v44_8);
  drop(v44_10);
  drop(v44_12);
  drop(v44_14);
  drop(v44_16);
  (v44_26).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v60_5: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v60_8: Space = if (v60_5).is_empty() { Space::new() } else {
    let v61_7: Space = unwrap(&(*CONSTANT_24),&(*p0));
    compose(&(v60_5),&(v61_7))
  };
  drop(v60_5);
  let v60_9: Path = concat_path(&(*p1),&(*p0));
  let v60_10: Space = singleton(&(v60_9));
  drop(v60_9);
  let v60_11: Space = subtract(&(v60_8),&(v60_10));
  drop(v60_8);
  let v60_13: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v60_14: Space = intersect(&(v60_11),&(v60_13));
  drop(v60_11);
  let v60_15: Space = range(&(v60_14),2,3);
  drop(v60_14);
  let mut v60_23 = Space::new();
  let mut v60_23_cursor = (v60_15).read_zipper();
  for v60_23_byte in v60_23_cursor.child_mask().iter() {
    v60_23_cursor.descend_to_byte(v60_23_byte);
    let v60_23_tail = v60_23_cursor.make_map();
    v60_23_cursor.ascend(1);
    let v60_23_head = Path::from_slice(&[v60_23_byte]);
    let v62_2: Space = singleton(&(v60_23_head));
    let v62_3: Space = intersect(&(*CONSTANT_22),&(v62_2));
    let v62_4: Space = if has_head(&(v62_3)) { singleton(&[]) } else { Space::new() };
    drop(v62_3);
    let v62_5: Space = subtract(&(*CONSTANT_0),&(v62_4));
    drop(v62_4);
    let v62_7: Space = if (v62_5).is_empty() { Space::new() } else {
      let mut v63_6 = Space::new();
      let mut v63_6_cursor = (v60_23_tail).read_zipper();
      for v63_6_byte in v63_6_cursor.child_mask().iter() {
        v63_6_cursor.descend_to_byte(v63_6_byte);
        let v63_6_tail = v63_6_cursor.make_map();
        v63_6_cursor.ascend(1);
        let v63_6_head = Path::from_slice(&[v63_6_byte]);
        let v64_2: Space = singleton(&(v63_6_head));
        let v64_3: Space = intersect(&(*CONSTANT_22),&(v64_2));
        let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
        drop(v64_3);
        let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
        drop(v64_4);
        let v64_8: Space = if (v64_5).is_empty() { Space::new() } else {
          let v65_6: Path = concat_path(&(v60_23_head),&(v63_6_head));
          let v65_7: Space = routine_17(c, &(v65_6), &(v63_6_tail));
          compose(&(v64_5),&(v65_7))
        };
        drop(v64_5);
        let v64_9: Space = intersect(&(*CONSTANT_22),&(v64_2));
        drop(v64_2);
        let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
        drop(v64_9);
        let v64_12: Space = if (v64_10).is_empty() { Space::new() } else {
          let v66_6: Path = concat_path(&(v60_23_head),&(v63_6_head));
          let v66_11: Space = routine_18(c, &(v66_6), &(v63_6_tail));
          drop(v66_6);
          compose(&(v64_10),&(v66_11))
        };
        drop(v64_10);
        let v64_13: Space = unite(&(v64_8),&(v64_12));
        v63_6.join_into((v64_13).clone());
      }
      drop(v63_6_cursor);
      compose(&(v62_5),&(v63_6))
    };
    drop(v62_5);
    let v62_8: Space = intersect(&(*CONSTANT_22),&(v62_2));
    drop(v62_2);
    let v62_9: Space = if has_head(&(v62_8)) { singleton(&[]) } else { Space::new() };
    drop(v62_8);
    let v62_10: Space = compose(&(v62_9),&(*CONSTANT_25));
    drop(v62_9);
    let v62_11: Space = unite(&(v62_7),&(v62_10));
    drop(v62_10);
    v60_23.join_into((v62_11).clone());
  }
  drop(v60_23_cursor);
  drop(v60_15);
  let v60_25: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v60_28: Space = if (v60_25).is_empty() { Space::new() } else {
    let v67_27: Space = unwrap(&(*CONSTANT_24),&(*p0));
    compose(&(v60_25),&(v67_27))
  };
  drop(v60_25);
  let v60_29: Space = subtract(&(v60_28),&(v60_10));
  drop(v60_28);
  let v60_30: Space = intersect(&(v60_29),&(v60_13));
  drop(v60_13);
  drop(v60_29);
  let v60_31: Space = range(&(v60_30),3,4);
  drop(v60_30);
  let mut v60_39 = Space::new();
  let mut v60_39_cursor = (v60_31).read_zipper();
  for v60_39_byte in v60_39_cursor.child_mask().iter() {
    v60_39_cursor.descend_to_byte(v60_39_byte);
    let v60_39_tail = v60_39_cursor.make_map();
    v60_39_cursor.ascend(1);
    let v60_39_head = Path::from_slice(&[v60_39_byte]);
    let v68_2: Space = singleton(&(v60_39_head));
    let v68_3: Space = intersect(&(*CONSTANT_22),&(v68_2));
    let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
    drop(v68_3);
    let v68_5: Space = subtract(&(*CONSTANT_0),&(v68_4));
    drop(v68_4);
    let v68_7: Space = if (v68_5).is_empty() { Space::new() } else {
      let mut v69_6 = Space::new();
      let mut v69_6_cursor = (v60_39_tail).read_zipper();
      for v69_6_byte in v69_6_cursor.child_mask().iter() {
        v69_6_cursor.descend_to_byte(v69_6_byte);
        let v69_6_tail = v69_6_cursor.make_map();
        v69_6_cursor.ascend(1);
        let v69_6_head = Path::from_slice(&[v69_6_byte]);
        let v70_2: Space = singleton(&(v69_6_head));
        let v70_3: Space = intersect(&(*CONSTANT_22),&(v70_2));
        let v70_4: Space = if has_head(&(v70_3)) { singleton(&[]) } else { Space::new() };
        drop(v70_3);
        let v70_5: Space = subtract(&(*CONSTANT_0),&(v70_4));
        drop(v70_4);
        let v70_8: Space = if (v70_5).is_empty() { Space::new() } else {
          let v71_6: Path = concat_path(&(v60_39_head),&(v69_6_head));
          let v71_7: Space = routine_19(c, &(v71_6), &(v69_6_tail));
          compose(&(v70_5),&(v71_7))
        };
        drop(v70_5);
        let v70_9: Space = intersect(&(*CONSTANT_22),&(v70_2));
        drop(v70_2);
        let v70_10: Space = if has_head(&(v70_9)) { singleton(&[]) } else { Space::new() };
        drop(v70_9);
        let v70_12: Space = if (v70_10).is_empty() { Space::new() } else {
          let v72_6: Path = concat_path(&(v60_39_head),&(v69_6_head));
          let v72_11: Space = routine_20(c, &(v72_6), &(v69_6_tail));
          drop(v72_6);
          compose(&(v70_10),&(v72_11))
        };
        drop(v70_10);
        let v70_13: Space = unite(&(v70_8),&(v70_12));
        v69_6.join_into((v70_13).clone());
      }
      drop(v69_6_cursor);
      compose(&(v68_5),&(v69_6))
    };
    drop(v68_5);
    let v68_8: Space = intersect(&(*CONSTANT_22),&(v68_2));
    drop(v68_2);
    let v68_9: Space = if has_head(&(v68_8)) { singleton(&[]) } else { Space::new() };
    drop(v68_8);
    let v68_10: Space = compose(&(v68_9),&(*CONSTANT_25));
    drop(v68_9);
    let v68_11: Space = unite(&(v68_7),&(v68_10));
    drop(v68_10);
    v60_39.join_into((v68_11).clone());
  }
  drop(v60_39_cursor);
  drop(v60_31);
  let v60_40: Space = subtract(&(v60_23),&(v60_39));
  let v60_41: Space = if (v60_40).is_empty() { Space::new() } else {
    compose(&(v60_40),&(v60_10))
  };
  drop(v60_10);
  let mut v60_48 = Space::new();
  let mut v60_48_cursor = (v60_41).read_zipper();
  for v60_48_byte in v60_48_cursor.child_mask().iter() {
    v60_48_cursor.descend_to_byte(v60_48_byte);
    let v60_48_tail = v60_48_cursor.make_map();
    v60_48_cursor.ascend(1);
    let v60_48_head = Path::from_slice(&[v60_48_byte]);
    let v74_2: Space = singleton(&(v60_48_head));
    let v74_3: Space = intersect(&(*CONSTANT_22),&(v74_2));
    let v74_4: Space = if has_head(&(v74_3)) { singleton(&[]) } else { Space::new() };
    drop(v74_3);
    let v74_5: Space = subtract(&(*CONSTANT_0),&(v74_4));
    drop(v74_4);
    let v74_7: Space = if (v74_5).is_empty() { Space::new() } else {
      let mut v75_6 = Space::new();
      let mut v75_6_cursor = (v60_48_tail).read_zipper();
      for v75_6_byte in v75_6_cursor.child_mask().iter() {
        v75_6_cursor.descend_to_byte(v75_6_byte);
        let v75_6_tail = v75_6_cursor.make_map();
        v75_6_cursor.ascend(1);
        let v75_6_head = Path::from_slice(&[v75_6_byte]);
        let v76_2: Space = singleton(&(v75_6_head));
        let v76_3: Space = intersect(&(*CONSTANT_22),&(v76_2));
        let v76_4: Space = if has_head(&(v76_3)) { singleton(&[]) } else { Space::new() };
        drop(v76_3);
        let v76_5: Space = subtract(&(*CONSTANT_0),&(v76_4));
        drop(v76_4);
        let v76_8: Space = if (v76_5).is_empty() { Space::new() } else {
          let v77_6: Path = concat_path(&(v60_48_head),&(v75_6_head));
          let v77_7: Space = routine_21(c, &(v77_6), &(v75_6_tail));
          compose(&(v76_5),&(v77_7))
        };
        drop(v76_5);
        let v76_9: Space = intersect(&(*CONSTANT_22),&(v76_2));
        drop(v76_2);
        let v76_10: Space = if has_head(&(v76_9)) { singleton(&[]) } else { Space::new() };
        drop(v76_9);
        let v76_12: Space = if (v76_10).is_empty() { Space::new() } else {
          let v78_6: Path = concat_path(&(v60_48_head),&(v75_6_head));
          let v78_11: Space = routine_22(c, &(v78_6), &(v75_6_tail));
          drop(v78_6);
          compose(&(v76_10),&(v78_11))
        };
        drop(v76_10);
        let v76_13: Space = unite(&(v76_8),&(v76_12));
        v75_6.join_into((v76_13).clone());
      }
      drop(v75_6_cursor);
      compose(&(v74_5),&(v75_6))
    };
    drop(v74_5);
    let v74_8: Space = intersect(&(*CONSTANT_22),&(v74_2));
    drop(v74_2);
    let v74_9: Space = if has_head(&(v74_8)) { singleton(&[]) } else { Space::new() };
    drop(v74_8);
    let v74_10: Space = compose(&(v74_9),&(v60_48_tail));
    drop(v74_9);
    let v74_11: Space = unite(&(v74_7),&(v74_10));
    drop(v74_10);
    v60_48.join_into((v74_11).clone());
  }
  drop(v60_48_cursor);
  (v60_48).clone()
}

fn routine_7(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v79_7: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v79_9: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let mut v79_10 = Space::new();
  let mut v79_10_cursor = (*s0).read_zipper();
  for v79_10_byte in v79_10_cursor.child_mask().iter() {
    v79_10_cursor.descend_to_byte(v79_10_byte);
    let v79_10_tail = v79_10_cursor.make_map();
    v79_10_cursor.ascend(1);
    let v79_10_head = Path::from_slice(&[v79_10_byte]);
    let v80_2: Space = singleton(&(v79_10_head));
    let v80_3: Space = intersect(&(*CONSTANT_22),&(v80_2));
    let v80_4: Space = if has_head(&(v80_3)) { singleton(&[]) } else { Space::new() };
    drop(v80_3);
    let v80_5: Space = subtract(&(*CONSTANT_0),&(v80_4));
    drop(v80_4);
    let v80_8: Space = if (v80_5).is_empty() { Space::new() } else {
      let v81_6: Path = concat_path(&(*p0),&(v79_10_head));
      let v81_7: Space = routine_7(c, &(v81_6), &(*p1), &(v79_10_tail));
      compose(&(v80_5),&(v81_7))
    };
    drop(v80_5);
    let v80_9: Space = intersect(&(*CONSTANT_22),&(v80_2));
    drop(v80_2);
    let v80_10: Space = if has_head(&(v80_9)) { singleton(&[]) } else { Space::new() };
    drop(v80_9);
    let v80_16: Space = if (v80_10).is_empty() { Space::new() } else {
      let v82_6: Path = concat_path(&(*p0),&(v79_10_head));
      let v82_12: Space = if (v79_7).is_empty() { Space::new() } else {
        let v83_11: Space = unwrap(&(v79_9),&(v79_10_head));
        compose(&(v79_7),&(v83_11))
      };
      let v82_13: Path = concat_path(&(*p1),&(v82_6));
      drop(v82_6);
      let v82_14: Space = singleton(&(v82_13));
      drop(v82_13);
      let v82_15: Space = subtract(&(v82_12),&(v82_14));
      drop(v82_12);
      drop(v82_14);
      compose(&(v80_10),&(v82_15))
    };
    drop(v80_10);
    let v80_17: Space = unite(&(v80_8),&(v80_16));
    drop(v80_16);
    v79_10.join_into((v80_17).clone());
  }
  drop(v79_10_cursor);
  drop(v79_7);
  drop(v79_9);
  (v79_10).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v84_4: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v84_7: Space = if (v84_4).is_empty() { Space::new() } else {
    let v85_6: Space = unwrap(&(*CONSTANT_24),&(*p0));
    compose(&(v84_4),&(v85_6))
  };
  drop(v84_4);
  let v84_8: Path = concat_path(&(*p1),&(*p0));
  let v84_9: Space = singleton(&(v84_8));
  drop(v84_8);
  let v84_10: Space = subtract(&(v84_7),&(v84_9));
  drop(v84_7);
  drop(v84_9);
  (v84_10).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v86_8: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v86_10: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let v86_12: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v86_14: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v86_16: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let mut v86_26 = Space::new();
  let mut v86_26_cursor = (*s0).read_zipper();
  for v86_26_byte in v86_26_cursor.child_mask().iter() {
    v86_26_cursor.descend_to_byte(v86_26_byte);
    let v86_26_tail = v86_26_cursor.make_map();
    v86_26_cursor.ascend(1);
    let v86_26_head = Path::from_slice(&[v86_26_byte]);
    let v87_2: Space = singleton(&(v86_26_head));
    let v87_3: Space = intersect(&(*CONSTANT_22),&(v87_2));
    let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
    drop(v87_3);
    let v87_5: Space = subtract(&(*CONSTANT_0),&(v87_4));
    drop(v87_4);
    let v87_8: Space = if (v87_5).is_empty() { Space::new() } else {
      let v88_6: Path = concat_path(&(*p0),&(v86_26_head));
      let v88_7: Space = routine_9(c, &(v88_6), &(*p1), &(v86_26_tail), &(*s1));
      compose(&(v87_5),&(v88_7))
    };
    drop(v87_5);
    let v87_9: Space = intersect(&(*CONSTANT_22),&(v87_2));
    drop(v87_2);
    let v87_10: Space = if has_head(&(v87_9)) { singleton(&[]) } else { Space::new() };
    drop(v87_9);
    let v87_28: Space = if (v87_10).is_empty() { Space::new() } else {
      let v89_6: Path = concat_path(&(*p0),&(v86_26_head));
      let v89_12: Space = if (v86_8).is_empty() { Space::new() } else {
        let v90_11: Space = unwrap(&(v86_10),&(v86_26_head));
        compose(&(v86_8),&(v90_11))
      };
      let v89_13: Path = concat_path(&(*p1),&(v89_6));
      drop(v89_6);
      let v89_14: Space = singleton(&(v89_13));
      drop(v89_13);
      let v89_15: Space = subtract(&(v89_12),&(v89_14));
      drop(v89_12);
      let v89_16: Space = intersect(&(v89_15),&(v86_12));
      drop(v89_15);
      let v89_17: Space = range(&(v89_16),3,4);
      drop(v89_16);
      let mut v89_18 = Space::new();
      let mut v89_18_cursor = (v89_17).read_zipper();
      for v89_18_byte in v89_18_cursor.child_mask().iter() {
        v89_18_cursor.descend_to_byte(v89_18_byte);
        let v89_18_tail = v89_18_cursor.make_map();
        v89_18_cursor.ascend(1);
        let v89_18_head = Path::from_slice(&[v89_18_byte]);
        let v91_2: Space = singleton(&(v89_18_head));
        let v91_3: Space = intersect(&(*CONSTANT_22),&(v91_2));
        let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
        drop(v91_3);
        let v91_5: Space = subtract(&(*CONSTANT_0),&(v91_4));
        drop(v91_4);
        let v91_7: Space = if (v91_5).is_empty() { Space::new() } else {
          let v92_6: Space = routine_11(c, &(v89_18_head), &(v89_18_tail));
          compose(&(v91_5),&(v92_6))
        };
        drop(v91_5);
        let v91_8: Space = intersect(&(*CONSTANT_22),&(v91_2));
        drop(v91_2);
        let v91_9: Space = if has_head(&(v91_8)) { singleton(&[]) } else { Space::new() };
        drop(v91_8);
        let v91_11: Space = if (v91_9).is_empty() { Space::new() } else {
          let v93_10: Space = routine_12(c, &(v89_18_head), &(v89_18_tail));
          compose(&(v91_9),&(v93_10))
        };
        drop(v91_9);
        let v91_12: Space = unite(&(v91_7),&(v91_11));
        v89_18.join_into((v91_12).clone());
      }
      drop(v89_18_cursor);
      drop(v89_17);
      let v89_20: Space = if (v86_14).is_empty() { Space::new() } else {
        let v94_19: Space = unwrap(&(v86_16),&(v86_26_head));
        compose(&(v86_14),&(v94_19))
      };
      let v89_21: Space = subtract(&(v89_20),&(v89_14));
      drop(v89_20);
      let v89_22: Space = intersect(&(v89_21),&(v86_12));
      drop(v89_21);
      let v89_23: Space = range(&(v89_22),4,5);
      drop(v89_22);
      let mut v89_24 = Space::new();
      let mut v89_24_cursor = (v89_23).read_zipper();
      for v89_24_byte in v89_24_cursor.child_mask().iter() {
        v89_24_cursor.descend_to_byte(v89_24_byte);
        let v89_24_tail = v89_24_cursor.make_map();
        v89_24_cursor.ascend(1);
        let v89_24_head = Path::from_slice(&[v89_24_byte]);
        let v95_2: Space = singleton(&(v89_24_head));
        let v95_3: Space = intersect(&(*CONSTANT_22),&(v95_2));
        let v95_4: Space = if has_head(&(v95_3)) { singleton(&[]) } else { Space::new() };
        drop(v95_3);
        let v95_5: Space = subtract(&(*CONSTANT_0),&(v95_4));
        drop(v95_4);
        let v95_7: Space = if (v95_5).is_empty() { Space::new() } else {
          let v96_6: Space = routine_13(c, &(v89_24_head), &(v89_24_tail));
          compose(&(v95_5),&(v96_6))
        };
        drop(v95_5);
        let v95_8: Space = intersect(&(*CONSTANT_22),&(v95_2));
        drop(v95_2);
        let v95_9: Space = if has_head(&(v95_8)) { singleton(&[]) } else { Space::new() };
        drop(v95_8);
        let v95_11: Space = if (v95_9).is_empty() { Space::new() } else {
          let v97_10: Space = routine_14(c, &(v89_24_head), &(v89_24_tail));
          compose(&(v95_9),&(v97_10))
        };
        drop(v95_9);
        let v95_12: Space = unite(&(v95_7),&(v95_11));
        v89_24.join_into((v95_12).clone());
      }
      drop(v89_24_cursor);
      drop(v89_23);
      let v89_25: Space = subtract(&(v89_18),&(v89_24));
      let v89_26: Space = if (v89_25).is_empty() { Space::new() } else {
        compose(&(v89_25),&(v89_14))
      };
      drop(v89_14);
      let mut v89_27 = Space::new();
      let mut v89_27_cursor = (v89_26).read_zipper();
      for v89_27_byte in v89_27_cursor.child_mask().iter() {
        v89_27_cursor.descend_to_byte(v89_27_byte);
        let v89_27_tail = v89_27_cursor.make_map();
        v89_27_cursor.ascend(1);
        let v89_27_head = Path::from_slice(&[v89_27_byte]);
        let v99_2: Space = singleton(&(v89_27_head));
        let v99_3: Space = intersect(&(*CONSTANT_22),&(v99_2));
        let v99_4: Space = if has_head(&(v99_3)) { singleton(&[]) } else { Space::new() };
        drop(v99_3);
        let v99_5: Space = subtract(&(*CONSTANT_0),&(v99_4));
        drop(v99_4);
        let v99_7: Space = if (v99_5).is_empty() { Space::new() } else {
          let v100_6: Space = routine_15(c, &(v89_27_head), &(v89_27_tail));
          compose(&(v99_5),&(v100_6))
        };
        drop(v99_5);
        let v99_8: Space = intersect(&(*CONSTANT_22),&(v99_2));
        drop(v99_2);
        let v99_9: Space = if has_head(&(v99_8)) { singleton(&[]) } else { Space::new() };
        drop(v99_8);
        let v99_11: Space = if (v99_9).is_empty() { Space::new() } else {
          let v101_10: Space = routine_16(c, &(v89_27_head), &(v89_27_tail));
          compose(&(v99_9),&(v101_10))
        };
        drop(v99_9);
        let v99_12: Space = unite(&(v99_7),&(v99_11));
        v89_27.join_into((v99_12).clone());
      }
      drop(v89_27_cursor);
      compose(&(v87_10),&(v89_27))
    };
    drop(v87_10);
    let v87_29: Space = unite(&(v87_8),&(v87_28));
    v86_26.join_into((v87_29).clone());
  }
  drop(v86_26_cursor);
  drop(v86_8);
  drop(v86_10);
  drop(v86_12);
  drop(v86_14);
  drop(v86_16);
  (v86_26).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v102_5: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v102_8: Space = if (v102_5).is_empty() { Space::new() } else {
    let v103_7: Space = unwrap(&(*CONSTANT_24),&(*p0));
    compose(&(v102_5),&(v103_7))
  };
  drop(v102_5);
  let v102_9: Path = concat_path(&(*p1),&(*p0));
  let v102_10: Space = singleton(&(v102_9));
  drop(v102_9);
  let v102_11: Space = subtract(&(v102_8),&(v102_10));
  drop(v102_8);
  let v102_13: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v102_14: Space = intersect(&(v102_11),&(v102_13));
  drop(v102_11);
  let v102_15: Space = range(&(v102_14),3,4);
  drop(v102_14);
  let mut v102_23 = Space::new();
  let mut v102_23_cursor = (v102_15).read_zipper();
  for v102_23_byte in v102_23_cursor.child_mask().iter() {
    v102_23_cursor.descend_to_byte(v102_23_byte);
    let v102_23_tail = v102_23_cursor.make_map();
    v102_23_cursor.ascend(1);
    let v102_23_head = Path::from_slice(&[v102_23_byte]);
    let v104_2: Space = singleton(&(v102_23_head));
    let v104_3: Space = intersect(&(*CONSTANT_22),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_7: Space = if (v104_5).is_empty() { Space::new() } else {
      let mut v105_6 = Space::new();
      let mut v105_6_cursor = (v102_23_tail).read_zipper();
      for v105_6_byte in v105_6_cursor.child_mask().iter() {
        v105_6_cursor.descend_to_byte(v105_6_byte);
        let v105_6_tail = v105_6_cursor.make_map();
        v105_6_cursor.ascend(1);
        let v105_6_head = Path::from_slice(&[v105_6_byte]);
        let v106_2: Space = singleton(&(v105_6_head));
        let v106_3: Space = intersect(&(*CONSTANT_22),&(v106_2));
        let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
        drop(v106_4);
        let v106_8: Space = if (v106_5).is_empty() { Space::new() } else {
          let v107_6: Path = concat_path(&(v102_23_head),&(v105_6_head));
          let v107_7: Space = routine_11(c, &(v107_6), &(v105_6_tail));
          compose(&(v106_5),&(v107_7))
        };
        drop(v106_5);
        let v106_9: Space = intersect(&(*CONSTANT_22),&(v106_2));
        drop(v106_2);
        let v106_10: Space = if has_head(&(v106_9)) { singleton(&[]) } else { Space::new() };
        drop(v106_9);
        let v106_12: Space = if (v106_10).is_empty() { Space::new() } else {
          let v108_6: Path = concat_path(&(v102_23_head),&(v105_6_head));
          let v108_11: Space = routine_12(c, &(v108_6), &(v105_6_tail));
          drop(v108_6);
          compose(&(v106_10),&(v108_11))
        };
        drop(v106_10);
        let v106_13: Space = unite(&(v106_8),&(v106_12));
        v105_6.join_into((v106_13).clone());
      }
      drop(v105_6_cursor);
      compose(&(v104_5),&(v105_6))
    };
    drop(v104_5);
    let v104_8: Space = intersect(&(*CONSTANT_22),&(v104_2));
    drop(v104_2);
    let v104_9: Space = if has_head(&(v104_8)) { singleton(&[]) } else { Space::new() };
    drop(v104_8);
    let v104_10: Space = compose(&(v104_9),&(*CONSTANT_25));
    drop(v104_9);
    let v104_11: Space = unite(&(v104_7),&(v104_10));
    drop(v104_10);
    v102_23.join_into((v104_11).clone());
  }
  drop(v102_23_cursor);
  drop(v102_15);
  let v102_25: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v102_28: Space = if (v102_25).is_empty() { Space::new() } else {
    let v109_27: Space = unwrap(&(*CONSTANT_24),&(*p0));
    compose(&(v102_25),&(v109_27))
  };
  drop(v102_25);
  let v102_29: Space = subtract(&(v102_28),&(v102_10));
  drop(v102_28);
  let v102_30: Space = intersect(&(v102_29),&(v102_13));
  drop(v102_13);
  drop(v102_29);
  let v102_31: Space = range(&(v102_30),4,5);
  drop(v102_30);
  let mut v102_39 = Space::new();
  let mut v102_39_cursor = (v102_31).read_zipper();
  for v102_39_byte in v102_39_cursor.child_mask().iter() {
    v102_39_cursor.descend_to_byte(v102_39_byte);
    let v102_39_tail = v102_39_cursor.make_map();
    v102_39_cursor.ascend(1);
    let v102_39_head = Path::from_slice(&[v102_39_byte]);
    let v110_2: Space = singleton(&(v102_39_head));
    let v110_3: Space = intersect(&(*CONSTANT_22),&(v110_2));
    let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
    drop(v110_3);
    let v110_5: Space = subtract(&(*CONSTANT_0),&(v110_4));
    drop(v110_4);
    let v110_7: Space = if (v110_5).is_empty() { Space::new() } else {
      let mut v111_6 = Space::new();
      let mut v111_6_cursor = (v102_39_tail).read_zipper();
      for v111_6_byte in v111_6_cursor.child_mask().iter() {
        v111_6_cursor.descend_to_byte(v111_6_byte);
        let v111_6_tail = v111_6_cursor.make_map();
        v111_6_cursor.ascend(1);
        let v111_6_head = Path::from_slice(&[v111_6_byte]);
        let v112_2: Space = singleton(&(v111_6_head));
        let v112_3: Space = intersect(&(*CONSTANT_22),&(v112_2));
        let v112_4: Space = if has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
        drop(v112_3);
        let v112_5: Space = subtract(&(*CONSTANT_0),&(v112_4));
        drop(v112_4);
        let v112_8: Space = if (v112_5).is_empty() { Space::new() } else {
          let v113_6: Path = concat_path(&(v102_39_head),&(v111_6_head));
          let v113_7: Space = routine_13(c, &(v113_6), &(v111_6_tail));
          compose(&(v112_5),&(v113_7))
        };
        drop(v112_5);
        let v112_9: Space = intersect(&(*CONSTANT_22),&(v112_2));
        drop(v112_2);
        let v112_10: Space = if has_head(&(v112_9)) { singleton(&[]) } else { Space::new() };
        drop(v112_9);
        let v112_12: Space = if (v112_10).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v102_39_head),&(v111_6_head));
          let v114_11: Space = routine_14(c, &(v114_6), &(v111_6_tail));
          drop(v114_6);
          compose(&(v112_10),&(v114_11))
        };
        drop(v112_10);
        let v112_13: Space = unite(&(v112_8),&(v112_12));
        v111_6.join_into((v112_13).clone());
      }
      drop(v111_6_cursor);
      compose(&(v110_5),&(v111_6))
    };
    drop(v110_5);
    let v110_8: Space = intersect(&(*CONSTANT_22),&(v110_2));
    drop(v110_2);
    let v110_9: Space = if has_head(&(v110_8)) { singleton(&[]) } else { Space::new() };
    drop(v110_8);
    let v110_10: Space = compose(&(v110_9),&(*CONSTANT_25));
    drop(v110_9);
    let v110_11: Space = unite(&(v110_7),&(v110_10));
    drop(v110_10);
    v102_39.join_into((v110_11).clone());
  }
  drop(v102_39_cursor);
  drop(v102_31);
  let v102_40: Space = subtract(&(v102_23),&(v102_39));
  let v102_41: Space = if (v102_40).is_empty() { Space::new() } else {
    compose(&(v102_40),&(v102_10))
  };
  drop(v102_10);
  let mut v102_48 = Space::new();
  let mut v102_48_cursor = (v102_41).read_zipper();
  for v102_48_byte in v102_48_cursor.child_mask().iter() {
    v102_48_cursor.descend_to_byte(v102_48_byte);
    let v102_48_tail = v102_48_cursor.make_map();
    v102_48_cursor.ascend(1);
    let v102_48_head = Path::from_slice(&[v102_48_byte]);
    let v116_2: Space = singleton(&(v102_48_head));
    let v116_3: Space = intersect(&(*CONSTANT_22),&(v116_2));
    let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
    drop(v116_3);
    let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
    drop(v116_4);
    let v116_7: Space = if (v116_5).is_empty() { Space::new() } else {
      let mut v117_6 = Space::new();
      let mut v117_6_cursor = (v102_48_tail).read_zipper();
      for v117_6_byte in v117_6_cursor.child_mask().iter() {
        v117_6_cursor.descend_to_byte(v117_6_byte);
        let v117_6_tail = v117_6_cursor.make_map();
        v117_6_cursor.ascend(1);
        let v117_6_head = Path::from_slice(&[v117_6_byte]);
        let v118_2: Space = singleton(&(v117_6_head));
        let v118_3: Space = intersect(&(*CONSTANT_22),&(v118_2));
        let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
        drop(v118_3);
        let v118_5: Space = subtract(&(*CONSTANT_0),&(v118_4));
        drop(v118_4);
        let v118_8: Space = if (v118_5).is_empty() { Space::new() } else {
          let v119_6: Path = concat_path(&(v102_48_head),&(v117_6_head));
          let v119_7: Space = routine_15(c, &(v119_6), &(v117_6_tail));
          compose(&(v118_5),&(v119_7))
        };
        drop(v118_5);
        let v118_9: Space = intersect(&(*CONSTANT_22),&(v118_2));
        drop(v118_2);
        let v118_10: Space = if has_head(&(v118_9)) { singleton(&[]) } else { Space::new() };
        drop(v118_9);
        let v118_12: Space = if (v118_10).is_empty() { Space::new() } else {
          let v120_6: Path = concat_path(&(v102_48_head),&(v117_6_head));
          let v120_11: Space = routine_16(c, &(v120_6), &(v117_6_tail));
          drop(v120_6);
          compose(&(v118_10),&(v120_11))
        };
        drop(v118_10);
        let v118_13: Space = unite(&(v118_8),&(v118_12));
        v117_6.join_into((v118_13).clone());
      }
      drop(v117_6_cursor);
      compose(&(v116_5),&(v117_6))
    };
    drop(v116_5);
    let v116_8: Space = intersect(&(*CONSTANT_22),&(v116_2));
    drop(v116_2);
    let v116_9: Space = if has_head(&(v116_8)) { singleton(&[]) } else { Space::new() };
    drop(v116_8);
    let v116_10: Space = compose(&(v116_9),&(v102_48_tail));
    drop(v116_9);
    let v116_11: Space = unite(&(v116_7),&(v116_10));
    drop(v116_10);
    v102_48.join_into((v116_11).clone());
  }
  drop(v102_48_cursor);
  (v102_48).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v121_6 = Space::new();
  let mut v121_6_cursor = (*s0).read_zipper();
  for v121_6_byte in v121_6_cursor.child_mask().iter() {
    v121_6_cursor.descend_to_byte(v121_6_byte);
    let v121_6_tail = v121_6_cursor.make_map();
    v121_6_cursor.ascend(1);
    let v121_6_head = Path::from_slice(&[v121_6_byte]);
    let v122_2: Space = singleton(&(v121_6_head));
    let v122_3: Space = intersect(&(*CONSTANT_22),&(v122_2));
    let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
    drop(v122_3);
    let v122_5: Space = subtract(&(*CONSTANT_0),&(v122_4));
    drop(v122_4);
    let v122_8: Space = if (v122_5).is_empty() { Space::new() } else {
      let v123_6: Path = concat_path(&(*p0),&(v121_6_head));
      let v123_7: Space = routine_11(c, &(v123_6), &(v121_6_tail));
      drop(v123_6);
      compose(&(v122_5),&(v123_7))
    };
    drop(v122_5);
    let v122_9: Space = intersect(&(*CONSTANT_22),&(v122_2));
    drop(v122_2);
    let v122_10: Space = if has_head(&(v122_9)) { singleton(&[]) } else { Space::new() };
    drop(v122_9);
    let v122_11: Space = compose(&(v122_10),&(*CONSTANT_25));
    drop(v122_10);
    let v122_12: Space = unite(&(v122_8),&(v122_11));
    drop(v122_11);
    v121_6.join_into((v122_12).clone());
  }
  drop(v121_6_cursor);
  (v121_6).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*CONSTANT_25).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v125_6 = Space::new();
  let mut v125_6_cursor = (*s0).read_zipper();
  for v125_6_byte in v125_6_cursor.child_mask().iter() {
    v125_6_cursor.descend_to_byte(v125_6_byte);
    let v125_6_tail = v125_6_cursor.make_map();
    v125_6_cursor.ascend(1);
    let v125_6_head = Path::from_slice(&[v125_6_byte]);
    let v126_2: Space = singleton(&(v125_6_head));
    let v126_3: Space = intersect(&(*CONSTANT_22),&(v126_2));
    let v126_4: Space = if has_head(&(v126_3)) { singleton(&[]) } else { Space::new() };
    drop(v126_3);
    let v126_5: Space = subtract(&(*CONSTANT_0),&(v126_4));
    drop(v126_4);
    let v126_8: Space = if (v126_5).is_empty() { Space::new() } else {
      let v127_6: Path = concat_path(&(*p0),&(v125_6_head));
      let v127_7: Space = routine_13(c, &(v127_6), &(v125_6_tail));
      drop(v127_6);
      compose(&(v126_5),&(v127_7))
    };
    drop(v126_5);
    let v126_9: Space = intersect(&(*CONSTANT_22),&(v126_2));
    drop(v126_2);
    let v126_10: Space = if has_head(&(v126_9)) { singleton(&[]) } else { Space::new() };
    drop(v126_9);
    let v126_11: Space = compose(&(v126_10),&(*CONSTANT_25));
    drop(v126_10);
    let v126_12: Space = unite(&(v126_8),&(v126_11));
    drop(v126_11);
    v125_6.join_into((v126_12).clone());
  }
  drop(v125_6_cursor);
  (v125_6).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*CONSTANT_25).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v129_5 = Space::new();
  let mut v129_5_cursor = (*s0).read_zipper();
  for v129_5_byte in v129_5_cursor.child_mask().iter() {
    v129_5_cursor.descend_to_byte(v129_5_byte);
    let v129_5_tail = v129_5_cursor.make_map();
    v129_5_cursor.ascend(1);
    let v129_5_head = Path::from_slice(&[v129_5_byte]);
    let v130_2: Space = singleton(&(v129_5_head));
    let v130_3: Space = intersect(&(*CONSTANT_22),&(v130_2));
    let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
    drop(v130_3);
    let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
    drop(v130_4);
    let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
      let v131_6: Path = concat_path(&(*p0),&(v129_5_head));
      let v131_7: Space = routine_15(c, &(v131_6), &(v129_5_tail));
      drop(v131_6);
      compose(&(v130_5),&(v131_7))
    };
    drop(v130_5);
    let v130_9: Space = intersect(&(*CONSTANT_22),&(v130_2));
    drop(v130_2);
    let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
    drop(v130_9);
    let v130_11: Space = compose(&(v130_10),&(v129_5_tail));
    drop(v130_10);
    let v130_12: Space = unite(&(v130_8),&(v130_11));
    drop(v130_11);
    v129_5.join_into((v130_12).clone());
  }
  drop(v129_5_cursor);
  (v129_5).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v133_6 = Space::new();
  let mut v133_6_cursor = (*s0).read_zipper();
  for v133_6_byte in v133_6_cursor.child_mask().iter() {
    v133_6_cursor.descend_to_byte(v133_6_byte);
    let v133_6_tail = v133_6_cursor.make_map();
    v133_6_cursor.ascend(1);
    let v133_6_head = Path::from_slice(&[v133_6_byte]);
    let v134_2: Space = singleton(&(v133_6_head));
    let v134_3: Space = intersect(&(*CONSTANT_22),&(v134_2));
    let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
    drop(v134_3);
    let v134_5: Space = subtract(&(*CONSTANT_0),&(v134_4));
    drop(v134_4);
    let v134_8: Space = if (v134_5).is_empty() { Space::new() } else {
      let v135_6: Path = concat_path(&(*p0),&(v133_6_head));
      let v135_7: Space = routine_17(c, &(v135_6), &(v133_6_tail));
      drop(v135_6);
      compose(&(v134_5),&(v135_7))
    };
    drop(v134_5);
    let v134_9: Space = intersect(&(*CONSTANT_22),&(v134_2));
    drop(v134_2);
    let v134_10: Space = if has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
    drop(v134_9);
    let v134_11: Space = compose(&(v134_10),&(*CONSTANT_25));
    drop(v134_10);
    let v134_12: Space = unite(&(v134_8),&(v134_11));
    drop(v134_11);
    v133_6.join_into((v134_12).clone());
  }
  drop(v133_6_cursor);
  (v133_6).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*CONSTANT_25).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v137_6 = Space::new();
  let mut v137_6_cursor = (*s0).read_zipper();
  for v137_6_byte in v137_6_cursor.child_mask().iter() {
    v137_6_cursor.descend_to_byte(v137_6_byte);
    let v137_6_tail = v137_6_cursor.make_map();
    v137_6_cursor.ascend(1);
    let v137_6_head = Path::from_slice(&[v137_6_byte]);
    let v138_2: Space = singleton(&(v137_6_head));
    let v138_3: Space = intersect(&(*CONSTANT_22),&(v138_2));
    let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
    drop(v138_3);
    let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
    drop(v138_4);
    let v138_8: Space = if (v138_5).is_empty() { Space::new() } else {
      let v139_6: Path = concat_path(&(*p0),&(v137_6_head));
      let v139_7: Space = routine_19(c, &(v139_6), &(v137_6_tail));
      drop(v139_6);
      compose(&(v138_5),&(v139_7))
    };
    drop(v138_5);
    let v138_9: Space = intersect(&(*CONSTANT_22),&(v138_2));
    drop(v138_2);
    let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
    drop(v138_9);
    let v138_11: Space = compose(&(v138_10),&(*CONSTANT_25));
    drop(v138_10);
    let v138_12: Space = unite(&(v138_8),&(v138_11));
    drop(v138_11);
    v137_6.join_into((v138_12).clone());
  }
  drop(v137_6_cursor);
  (v137_6).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*CONSTANT_25).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v141_5 = Space::new();
  let mut v141_5_cursor = (*s0).read_zipper();
  for v141_5_byte in v141_5_cursor.child_mask().iter() {
    v141_5_cursor.descend_to_byte(v141_5_byte);
    let v141_5_tail = v141_5_cursor.make_map();
    v141_5_cursor.ascend(1);
    let v141_5_head = Path::from_slice(&[v141_5_byte]);
    let v142_2: Space = singleton(&(v141_5_head));
    let v142_3: Space = intersect(&(*CONSTANT_22),&(v142_2));
    let v142_4: Space = if has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
    drop(v142_3);
    let v142_5: Space = subtract(&(*CONSTANT_0),&(v142_4));
    drop(v142_4);
    let v142_8: Space = if (v142_5).is_empty() { Space::new() } else {
      let v143_6: Path = concat_path(&(*p0),&(v141_5_head));
      let v143_7: Space = routine_21(c, &(v143_6), &(v141_5_tail));
      drop(v143_6);
      compose(&(v142_5),&(v143_7))
    };
    drop(v142_5);
    let v142_9: Space = intersect(&(*CONSTANT_22),&(v142_2));
    drop(v142_2);
    let v142_10: Space = if has_head(&(v142_9)) { singleton(&[]) } else { Space::new() };
    drop(v142_9);
    let v142_11: Space = compose(&(v142_10),&(v141_5_tail));
    drop(v142_10);
    let v142_12: Space = unite(&(v142_8),&(v142_11));
    drop(v142_11);
    v141_5.join_into((v142_12).clone());
  }
  drop(v141_5_cursor);
  (v141_5).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
