#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("94 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 0 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 21 1 1 0 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 19 1 1 0 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 19 1 1 0 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 18 1 1 0 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 22 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 16 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 1 0 0 1 1"));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("184 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 0 1 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 0 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 1 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 1 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 1 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 1 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 0 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 0 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 1 0 1 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 0 1 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 0 0 1 1 22 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 1 0 1 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 1 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 21 1 1 0 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 19 1 1 0 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 19 1 1 0 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 18 1 1 0 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 22 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 16 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 1 0 0 1 1 21 1 1 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 21 1 1 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 19 1 1 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 19 1 1 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 17 1 1 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 17 1 1 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 21 1 1 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 21 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 20 1 1 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 19 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 15 1 1 0 1 1 0 0 0 1 1 0 1 0 1 1 15 1 1 0 1 1 0 0 0 1 1 1 0 0 1 1 21 1 1 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 21 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 19 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 19 1 1 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 18 1 1 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 17 1 1 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 19 1 1 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 19 1 1 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 17 1 1 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 17 1 1 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 19 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 19 1 1 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 20 1 1 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 20 1 1 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 18 1 1 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 17 1 1 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 21 1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 19 1 1 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 19 1 1 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 17 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 17 1 1 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 19 1 1 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 21 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 20 1 1 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 20 1 1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 17 1 1 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 15 1 1 0 1 1 1 0 0 1 1 0 1 0 1 1 21 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 21 1 1 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 19 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 19 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 18 1 1 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 18 1 1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 14 1 1 0 1 1 1 0 1 1 0 0 0 1 1 14 1 1 0 1 1 1 0 1 1 1 0 0 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,1]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,1]));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,0,1,1,0,1,1]));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v1_2: Space = unwrap(&(*capture_0),&(*CONSTANT_3));
  let v1_4: Space = unwrap(&(v1_2),&(*CONSTANT_4));
  let mut v1_14 = Space::new();
  let mut v1_14_cursor = (v1_4).read_zipper();
  for v1_14_byte in v1_14_cursor.child_mask().iter() {
    v1_14_cursor.descend_to_byte(v1_14_byte);
    let v1_14_tail = v1_14_cursor.make_map();
    v1_14_cursor.ascend(1);
    let v1_14_head = Path::from_slice(&[v1_14_byte]);
    let v2_2: Space = singleton(&(v1_14_head));
    let v2_3: Space = intersect(&(*CONSTANT_6),&(v2_2));
    let v2_4: Space = if has_head(&(v2_3)) { singleton(&[]) } else { Space::new() };
    drop(v2_3);
    let v2_5: Space = subtract(&(*CONSTANT_5),&(v2_4));
    drop(v2_4);
    let v2_7: Space = if (v2_5).is_empty() { Space::new() } else {
      let mut v3_6 = Space::new();
      let mut v3_6_cursor = (v1_14_tail).read_zipper();
      for v3_6_byte in v3_6_cursor.child_mask().iter() {
        v3_6_cursor.descend_to_byte(v3_6_byte);
        let v3_6_tail = v3_6_cursor.make_map();
        v3_6_cursor.ascend(1);
        let v3_6_head = Path::from_slice(&[v3_6_byte]);
        let v4_2: Space = singleton(&(v3_6_head));
        let v4_3: Space = intersect(&(*CONSTANT_6),&(v4_2));
        let v4_4: Space = if has_head(&(v4_3)) { singleton(&[]) } else { Space::new() };
        drop(v4_3);
        let v4_5: Space = subtract(&(*CONSTANT_5),&(v4_4));
        drop(v4_4);
        let v4_8: Space = if (v4_5).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v1_14_head),&(v3_6_head));
          let v5_7: Space = routine_2(c, &(v5_6), &(v3_6_tail), &(*capture_0));
          compose(&(v4_5),&(v5_7))
        };
        drop(v4_5);
        let v4_9: Space = intersect(&(*CONSTANT_6),&(v4_2));
        drop(v4_2);
        let v4_10: Space = if has_head(&(v4_9)) { singleton(&[]) } else { Space::new() };
        drop(v4_9);
        let v4_12: Space = if (v4_10).is_empty() { Space::new() } else {
          let v6_6: Path = concat_path(&(v1_14_head),&(v3_6_head));
          let v6_11: Space = routine_3(c, &(v6_6), &(v3_6_tail), &(*capture_0));
          drop(v6_6);
          compose(&(v4_10),&(v6_11))
        };
        drop(v4_10);
        let v4_13: Space = unite(&(v4_8),&(v4_12));
        v3_6.join_into((v4_13).clone());
      }
      drop(v3_6_cursor);
      compose(&(v2_5),&(v3_6))
    };
    drop(v2_5);
    let v2_8: Space = intersect(&(*CONSTANT_6),&(v2_2));
    drop(v2_2);
    let v2_9: Space = if has_head(&(v2_8)) { singleton(&[]) } else { Space::new() };
    drop(v2_8);
    let v2_11: Space = if (v2_9).is_empty() { Space::new() } else {
      let mut v7_10 = Space::new();
      let mut v7_10_cursor = (v1_14_tail).read_zipper();
      for v7_10_byte in v7_10_cursor.child_mask().iter() {
        v7_10_cursor.descend_to_byte(v7_10_byte);
        let v7_10_tail = v7_10_cursor.make_map();
        v7_10_cursor.ascend(1);
        let v7_10_head = Path::from_slice(&[v7_10_byte]);
        let v8_2: Space = singleton(&(v7_10_head));
        let v8_3: Space = intersect(&(*CONSTANT_6),&(v8_2));
        let v8_4: Space = if has_head(&(v8_3)) { singleton(&[]) } else { Space::new() };
        drop(v8_3);
        let v8_5: Space = subtract(&(*CONSTANT_5),&(v8_4));
        drop(v8_4);
        let v8_8: Space = if (v8_5).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v1_14_head),&(v7_10_head));
          let v9_7: Space = routine_2(c, &(v9_6), &(v7_10_tail), &(*capture_0));
          compose(&(v8_5),&(v9_7))
        };
        drop(v8_5);
        let v8_9: Space = intersect(&(*CONSTANT_6),&(v8_2));
        drop(v8_2);
        let v8_10: Space = if has_head(&(v8_9)) { singleton(&[]) } else { Space::new() };
        drop(v8_9);
        let v8_12: Space = if (v8_10).is_empty() { Space::new() } else {
          let v10_6: Path = concat_path(&(v1_14_head),&(v7_10_head));
          let v10_11: Space = routine_4(c, &(v10_6), &(v7_10_tail), &(*capture_0));
          drop(v10_6);
          compose(&(v8_10),&(v10_11))
        };
        drop(v8_10);
        let v8_13: Space = unite(&(v8_8),&(v8_12));
        v7_10.join_into((v8_13).clone());
      }
      drop(v7_10_cursor);
      compose(&(v2_9),&(v7_10))
    };
    drop(v2_9);
    let v2_12: Space = unite(&(v2_7),&(v2_11));
    v1_14.join_into((v2_12).clone());
  }
  drop(v1_14_cursor);
  let mut v1_24 = Space::new();
  let mut v1_24_cursor = (v1_4).read_zipper();
  for v1_24_byte in v1_24_cursor.child_mask().iter() {
    v1_24_cursor.descend_to_byte(v1_24_byte);
    let v1_24_tail = v1_24_cursor.make_map();
    v1_24_cursor.ascend(1);
    let v1_24_head = Path::from_slice(&[v1_24_byte]);
    let v11_2: Space = singleton(&(v1_24_head));
    let v11_3: Space = intersect(&(*CONSTANT_6),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_5),&(v11_4));
    drop(v11_4);
    let v11_7: Space = if (v11_5).is_empty() { Space::new() } else {
      let mut v12_6 = Space::new();
      let mut v12_6_cursor = (v1_24_tail).read_zipper();
      for v12_6_byte in v12_6_cursor.child_mask().iter() {
        v12_6_cursor.descend_to_byte(v12_6_byte);
        let v12_6_tail = v12_6_cursor.make_map();
        v12_6_cursor.ascend(1);
        let v12_6_head = Path::from_slice(&[v12_6_byte]);
        let v13_2: Space = singleton(&(v12_6_head));
        let v13_3: Space = intersect(&(*CONSTANT_6),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_5),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v1_24_head),&(v12_6_head));
          let v14_7: Space = routine_5(c, &(v14_6), &(v12_6_tail), &(*capture_0));
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_6),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
          let v15_6: Path = concat_path(&(v1_24_head),&(v12_6_head));
          let v15_11: Space = routine_6(c, &(v15_6), &(v12_6_tail), &(*capture_0));
          drop(v15_6);
          compose(&(v13_10),&(v15_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        v12_6.join_into((v13_13).clone());
      }
      drop(v12_6_cursor);
      compose(&(v11_5),&(v12_6))
    };
    drop(v11_5);
    let v11_8: Space = intersect(&(*CONSTANT_6),&(v11_2));
    drop(v11_2);
    let v11_9: Space = if has_head(&(v11_8)) { singleton(&[]) } else { Space::new() };
    drop(v11_8);
    let v11_11: Space = if (v11_9).is_empty() { Space::new() } else {
      let mut v16_10 = Space::new();
      let mut v16_10_cursor = (v1_24_tail).read_zipper();
      for v16_10_byte in v16_10_cursor.child_mask().iter() {
        v16_10_cursor.descend_to_byte(v16_10_byte);
        let v16_10_tail = v16_10_cursor.make_map();
        v16_10_cursor.ascend(1);
        let v16_10_head = Path::from_slice(&[v16_10_byte]);
        let v17_2: Space = singleton(&(v16_10_head));
        let v17_3: Space = intersect(&(*CONSTANT_6),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_5),&(v17_4));
        drop(v17_4);
        let v17_8: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v1_24_head),&(v16_10_head));
          let v18_7: Space = routine_5(c, &(v18_6), &(v16_10_tail), &(*capture_0));
          compose(&(v17_5),&(v18_7))
        };
        drop(v17_5);
        let v17_9: Space = intersect(&(*CONSTANT_6),&(v17_2));
        drop(v17_2);
        let v17_10: Space = if has_head(&(v17_9)) { singleton(&[]) } else { Space::new() };
        drop(v17_9);
        let v17_12: Space = if (v17_10).is_empty() { Space::new() } else {
          let v19_6: Path = concat_path(&(v1_24_head),&(v16_10_head));
          let v19_11: Space = routine_7(c, &(v19_6), &(v16_10_tail), &(*capture_0));
          drop(v19_6);
          compose(&(v17_10),&(v19_11))
        };
        drop(v17_10);
        let v17_13: Space = unite(&(v17_8),&(v17_12));
        v16_10.join_into((v17_13).clone());
      }
      drop(v16_10_cursor);
      compose(&(v11_9),&(v16_10))
    };
    drop(v11_9);
    let v11_12: Space = unite(&(v11_7),&(v11_11));
    v1_24.join_into((v11_12).clone());
  }
  drop(v1_24_cursor);
  drop(v1_4);
  let v1_25: Space = unite(&(v1_14),&(v1_24));
  let v1_27: Space = unwrap(&(*capture_0),&(*CONSTANT_7));
  let v1_29: Space = unwrap(&(v1_27),&(*CONSTANT_8));
  let mut v1_39 = Space::new();
  let mut v1_39_cursor = (v1_29).read_zipper();
  for v1_39_byte in v1_39_cursor.child_mask().iter() {
    v1_39_cursor.descend_to_byte(v1_39_byte);
    let v1_39_tail = v1_39_cursor.make_map();
    v1_39_cursor.ascend(1);
    let v1_39_head = Path::from_slice(&[v1_39_byte]);
    let v20_2: Space = singleton(&(v1_39_head));
    let v20_3: Space = intersect(&(*CONSTANT_6),&(v20_2));
    let v20_4: Space = if has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
    drop(v20_3);
    let v20_5: Space = subtract(&(*CONSTANT_5),&(v20_4));
    drop(v20_4);
    let v20_7: Space = if (v20_5).is_empty() { Space::new() } else {
      let mut v21_6 = Space::new();
      let mut v21_6_cursor = (v1_39_tail).read_zipper();
      for v21_6_byte in v21_6_cursor.child_mask().iter() {
        v21_6_cursor.descend_to_byte(v21_6_byte);
        let v21_6_tail = v21_6_cursor.make_map();
        v21_6_cursor.ascend(1);
        let v21_6_head = Path::from_slice(&[v21_6_byte]);
        let v22_2: Space = singleton(&(v21_6_head));
        let v22_3: Space = intersect(&(*CONSTANT_6),&(v22_2));
        let v22_4: Space = if has_head(&(v22_3)) { singleton(&[]) } else { Space::new() };
        drop(v22_3);
        let v22_5: Space = subtract(&(*CONSTANT_5),&(v22_4));
        drop(v22_4);
        let v22_8: Space = if (v22_5).is_empty() { Space::new() } else {
          let v23_6: Path = concat_path(&(v1_39_head),&(v21_6_head));
          let v23_7: Space = routine_8(c, &(v23_6), &(v21_6_tail));
          compose(&(v22_5),&(v23_7))
        };
        drop(v22_5);
        let v22_9: Space = intersect(&(*CONSTANT_6),&(v22_2));
        drop(v22_2);
        let v22_10: Space = if has_head(&(v22_9)) { singleton(&[]) } else { Space::new() };
        drop(v22_9);
        let v22_12: Space = if (v22_10).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v1_39_head),&(v21_6_head));
          let v24_11: Space = routine_9(c, &(v24_6), &(v21_6_tail));
          drop(v24_6);
          compose(&(v22_10),&(v24_11))
        };
        drop(v22_10);
        let v22_13: Space = unite(&(v22_8),&(v22_12));
        v21_6.join_into((v22_13).clone());
      }
      drop(v21_6_cursor);
      compose(&(v20_5),&(v21_6))
    };
    drop(v20_5);
    let v20_8: Space = intersect(&(*CONSTANT_6),&(v20_2));
    drop(v20_2);
    let v20_9: Space = if has_head(&(v20_8)) { singleton(&[]) } else { Space::new() };
    drop(v20_8);
    let v20_11: Space = if (v20_9).is_empty() { Space::new() } else {
      let mut v25_10 = Space::new();
      let mut v25_10_cursor = (v1_39_tail).read_zipper();
      for v25_10_byte in v25_10_cursor.child_mask().iter() {
        v25_10_cursor.descend_to_byte(v25_10_byte);
        let v25_10_tail = v25_10_cursor.make_map();
        v25_10_cursor.ascend(1);
        let v25_10_head = Path::from_slice(&[v25_10_byte]);
        let v26_2: Space = singleton(&(v25_10_head));
        let v26_3: Space = intersect(&(*CONSTANT_6),&(v26_2));
        let v26_4: Space = if has_head(&(v26_3)) { singleton(&[]) } else { Space::new() };
        drop(v26_3);
        let v26_5: Space = subtract(&(*CONSTANT_5),&(v26_4));
        drop(v26_4);
        let v26_8: Space = if (v26_5).is_empty() { Space::new() } else {
          let v27_6: Path = concat_path(&(v1_39_head),&(v25_10_head));
          let v27_7: Space = routine_8(c, &(v27_6), &(v25_10_tail));
          compose(&(v26_5),&(v27_7))
        };
        drop(v26_5);
        let v26_9: Space = intersect(&(*CONSTANT_6),&(v26_2));
        drop(v26_2);
        let v26_10: Space = if has_head(&(v26_9)) { singleton(&[]) } else { Space::new() };
        drop(v26_9);
        let v26_12: Space = if (v26_10).is_empty() { Space::new() } else {
          let v28_6: Path = concat_path(&(v1_39_head),&(v25_10_head));
          let v28_11: Space = routine_10(c, &(v28_6), &(v25_10_tail));
          drop(v28_6);
          compose(&(v26_10),&(v28_11))
        };
        drop(v26_10);
        let v26_13: Space = unite(&(v26_8),&(v26_12));
        v25_10.join_into((v26_13).clone());
      }
      drop(v25_10_cursor);
      compose(&(v20_9),&(v25_10))
    };
    drop(v20_9);
    let v20_12: Space = unite(&(v20_7),&(v20_11));
    v1_39.join_into((v20_12).clone());
  }
  drop(v1_39_cursor);
  drop(v1_29);
  let v1_40: Space = unite(&(v1_25),&(v1_39));
  let v1_41: Space = unwrap(&(v1_27),&(*CONSTANT_4));
  let mut v1_51 = Space::new();
  let mut v1_51_cursor = (v1_41).read_zipper();
  for v1_51_byte in v1_51_cursor.child_mask().iter() {
    v1_51_cursor.descend_to_byte(v1_51_byte);
    let v1_51_tail = v1_51_cursor.make_map();
    v1_51_cursor.ascend(1);
    let v1_51_head = Path::from_slice(&[v1_51_byte]);
    let v29_2: Space = singleton(&(v1_51_head));
    let v29_3: Space = intersect(&(*CONSTANT_6),&(v29_2));
    let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
    drop(v29_3);
    let v29_5: Space = subtract(&(*CONSTANT_5),&(v29_4));
    drop(v29_4);
    let v29_7: Space = if (v29_5).is_empty() { Space::new() } else {
      let mut v30_6 = Space::new();
      let mut v30_6_cursor = (v1_51_tail).read_zipper();
      for v30_6_byte in v30_6_cursor.child_mask().iter() {
        v30_6_cursor.descend_to_byte(v30_6_byte);
        let v30_6_tail = v30_6_cursor.make_map();
        v30_6_cursor.ascend(1);
        let v30_6_head = Path::from_slice(&[v30_6_byte]);
        let v31_2: Space = singleton(&(v30_6_head));
        let v31_3: Space = intersect(&(*CONSTANT_6),&(v31_2));
        let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
        drop(v31_3);
        let v31_5: Space = subtract(&(*CONSTANT_5),&(v31_4));
        drop(v31_4);
        let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
          let v32_6: Path = concat_path(&(v1_51_head),&(v30_6_head));
          let v32_7: Space = routine_11(c, &(v32_6), &(v30_6_tail), &(*capture_0));
          compose(&(v31_5),&(v32_7))
        };
        drop(v31_5);
        let v31_9: Space = intersect(&(*CONSTANT_6),&(v31_2));
        drop(v31_2);
        let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
        drop(v31_9);
        let v31_12: Space = if (v31_10).is_empty() { Space::new() } else {
          let v33_6: Path = concat_path(&(v1_51_head),&(v30_6_head));
          let v33_11: Space = routine_12(c, &(v33_6), &(v30_6_tail), &(*capture_0));
          drop(v33_6);
          compose(&(v31_10),&(v33_11))
        };
        drop(v31_10);
        let v31_13: Space = unite(&(v31_8),&(v31_12));
        v30_6.join_into((v31_13).clone());
      }
      drop(v30_6_cursor);
      compose(&(v29_5),&(v30_6))
    };
    drop(v29_5);
    let v29_8: Space = intersect(&(*CONSTANT_6),&(v29_2));
    drop(v29_2);
    let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
    drop(v29_8);
    let v29_11: Space = if (v29_9).is_empty() { Space::new() } else {
      let mut v34_10 = Space::new();
      let mut v34_10_cursor = (v1_51_tail).read_zipper();
      for v34_10_byte in v34_10_cursor.child_mask().iter() {
        v34_10_cursor.descend_to_byte(v34_10_byte);
        let v34_10_tail = v34_10_cursor.make_map();
        v34_10_cursor.ascend(1);
        let v34_10_head = Path::from_slice(&[v34_10_byte]);
        let v35_2: Space = singleton(&(v34_10_head));
        let v35_3: Space = intersect(&(*CONSTANT_6),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_5),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (v35_5).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v1_51_head),&(v34_10_head));
          let v36_7: Space = routine_11(c, &(v36_6), &(v34_10_tail), &(*capture_0));
          compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = intersect(&(*CONSTANT_6),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (v35_10).is_empty() { Space::new() } else {
          let v37_6: Path = concat_path(&(v1_51_head),&(v34_10_head));
          let v37_11: Space = routine_13(c, &(v37_6), &(v34_10_tail), &(*capture_0));
          drop(v37_6);
          compose(&(v35_10),&(v37_11))
        };
        drop(v35_10);
        let v35_13: Space = unite(&(v35_8),&(v35_12));
        v34_10.join_into((v35_13).clone());
      }
      drop(v34_10_cursor);
      compose(&(v29_9),&(v34_10))
    };
    drop(v29_9);
    let v29_12: Space = unite(&(v29_7),&(v29_11));
    v1_51.join_into((v29_12).clone());
  }
  drop(v1_51_cursor);
  drop(v1_41);
  let v1_52: Space = unite(&(v1_40),&(v1_51));
  let v1_54: Space = unwrap(&(*capture_0),&(*CONSTANT_2));
  let v1_55: Space = subtract(&(v1_52),&(v1_54));
  drop(v1_54);
  let v1_57: Space = unwrap(&(*capture_0),&(*CONSTANT_9));
  let v1_58: Space = subtract(&(v1_55),&(v1_57));
  drop(v1_57);
  let v1_59: Space = wrap(&(v1_58),&(*CONSTANT_9));
  let v1_60: Space = unite(&(v1_2),&(v1_27));
  drop(v1_2);
  drop(v1_27);
  let v1_61: Space = wrap(&(v1_60),&(*CONSTANT_7));
  drop(v1_60);
  let v1_62: Space = unite(&(v1_59),&(v1_61));
  drop(v1_61);
  let v1_63: Space = unite(&(v1_62),&(*capture_0));
  let mut v1_100: Space = (v1_63).clone();
  loop {
    let v38_1: Space = unwrap(&(v1_100),&(*CONSTANT_3));
    let v38_2: Space = unwrap(&(v38_1),&(*CONSTANT_4));
    let mut v38_3 = Space::new();
    let mut v38_3_cursor = (v38_2).read_zipper();
    for v38_3_byte in v38_3_cursor.child_mask().iter() {
      v38_3_cursor.descend_to_byte(v38_3_byte);
      let v38_3_tail = v38_3_cursor.make_map();
      v38_3_cursor.ascend(1);
      let v38_3_head = Path::from_slice(&[v38_3_byte]);
      let v39_2: Space = singleton(&(v38_3_head));
      let v39_3: Space = intersect(&(*CONSTANT_6),&(v39_2));
      let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
      drop(v39_3);
      let v39_5: Space = subtract(&(*CONSTANT_5),&(v39_4));
      drop(v39_4);
      let v39_7: Space = if (v39_5).is_empty() { Space::new() } else {
        let mut v40_6 = Space::new();
        let mut v40_6_cursor = (v38_3_tail).read_zipper();
        for v40_6_byte in v40_6_cursor.child_mask().iter() {
          v40_6_cursor.descend_to_byte(v40_6_byte);
          let v40_6_tail = v40_6_cursor.make_map();
          v40_6_cursor.ascend(1);
          let v40_6_head = Path::from_slice(&[v40_6_byte]);
          let v41_2: Space = singleton(&(v40_6_head));
          let v41_3: Space = intersect(&(*CONSTANT_6),&(v41_2));
          let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
          drop(v41_3);
          let v41_5: Space = subtract(&(*CONSTANT_5),&(v41_4));
          drop(v41_4);
          let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
            let v42_6: Path = concat_path(&(v38_3_head),&(v40_6_head));
            let v42_7: Space = routine_2(c, &(v42_6), &(v40_6_tail), &(v1_100));
            compose(&(v41_5),&(v42_7))
          };
          drop(v41_5);
          let v41_9: Space = intersect(&(*CONSTANT_6),&(v41_2));
          drop(v41_2);
          let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
          drop(v41_9);
          let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
            let v43_6: Path = concat_path(&(v38_3_head),&(v40_6_head));
            let v43_11: Space = routine_3(c, &(v43_6), &(v40_6_tail), &(v1_100));
            drop(v43_6);
            compose(&(v41_10),&(v43_11))
          };
          drop(v41_10);
          let v41_13: Space = unite(&(v41_8),&(v41_12));
          v40_6.join_into((v41_13).clone());
        }
        drop(v40_6_cursor);
        compose(&(v39_5),&(v40_6))
      };
      drop(v39_5);
      let v39_8: Space = intersect(&(*CONSTANT_6),&(v39_2));
      drop(v39_2);
      let v39_9: Space = if has_head(&(v39_8)) { singleton(&[]) } else { Space::new() };
      drop(v39_8);
      let v39_11: Space = if (v39_9).is_empty() { Space::new() } else {
        let mut v44_10 = Space::new();
        let mut v44_10_cursor = (v38_3_tail).read_zipper();
        for v44_10_byte in v44_10_cursor.child_mask().iter() {
          v44_10_cursor.descend_to_byte(v44_10_byte);
          let v44_10_tail = v44_10_cursor.make_map();
          v44_10_cursor.ascend(1);
          let v44_10_head = Path::from_slice(&[v44_10_byte]);
          let v45_2: Space = singleton(&(v44_10_head));
          let v45_3: Space = intersect(&(*CONSTANT_6),&(v45_2));
          let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
          drop(v45_3);
          let v45_5: Space = subtract(&(*CONSTANT_5),&(v45_4));
          drop(v45_4);
          let v45_8: Space = if (v45_5).is_empty() { Space::new() } else {
            let v46_6: Path = concat_path(&(v38_3_head),&(v44_10_head));
            let v46_7: Space = routine_2(c, &(v46_6), &(v44_10_tail), &(v1_100));
            compose(&(v45_5),&(v46_7))
          };
          drop(v45_5);
          let v45_9: Space = intersect(&(*CONSTANT_6),&(v45_2));
          drop(v45_2);
          let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
          drop(v45_9);
          let v45_12: Space = if (v45_10).is_empty() { Space::new() } else {
            let v47_6: Path = concat_path(&(v38_3_head),&(v44_10_head));
            let v47_11: Space = routine_4(c, &(v47_6), &(v44_10_tail), &(v1_100));
            drop(v47_6);
            compose(&(v45_10),&(v47_11))
          };
          drop(v45_10);
          let v45_13: Space = unite(&(v45_8),&(v45_12));
          v44_10.join_into((v45_13).clone());
        }
        drop(v44_10_cursor);
        compose(&(v39_9),&(v44_10))
      };
      drop(v39_9);
      let v39_12: Space = unite(&(v39_7),&(v39_11));
      v38_3.join_into((v39_12).clone());
    }
    drop(v38_3_cursor);
    let mut v38_4 = Space::new();
    let mut v38_4_cursor = (v38_2).read_zipper();
    for v38_4_byte in v38_4_cursor.child_mask().iter() {
      v38_4_cursor.descend_to_byte(v38_4_byte);
      let v38_4_tail = v38_4_cursor.make_map();
      v38_4_cursor.ascend(1);
      let v38_4_head = Path::from_slice(&[v38_4_byte]);
      let v48_2: Space = singleton(&(v38_4_head));
      let v48_3: Space = intersect(&(*CONSTANT_6),&(v48_2));
      let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
      drop(v48_3);
      let v48_5: Space = subtract(&(*CONSTANT_5),&(v48_4));
      drop(v48_4);
      let v48_7: Space = if (v48_5).is_empty() { Space::new() } else {
        let mut v49_6 = Space::new();
        let mut v49_6_cursor = (v38_4_tail).read_zipper();
        for v49_6_byte in v49_6_cursor.child_mask().iter() {
          v49_6_cursor.descend_to_byte(v49_6_byte);
          let v49_6_tail = v49_6_cursor.make_map();
          v49_6_cursor.ascend(1);
          let v49_6_head = Path::from_slice(&[v49_6_byte]);
          let v50_2: Space = singleton(&(v49_6_head));
          let v50_3: Space = intersect(&(*CONSTANT_6),&(v50_2));
          let v50_4: Space = if has_head(&(v50_3)) { singleton(&[]) } else { Space::new() };
          drop(v50_3);
          let v50_5: Space = subtract(&(*CONSTANT_5),&(v50_4));
          drop(v50_4);
          let v50_8: Space = if (v50_5).is_empty() { Space::new() } else {
            let v51_6: Path = concat_path(&(v38_4_head),&(v49_6_head));
            let v51_7: Space = routine_5(c, &(v51_6), &(v49_6_tail), &(v1_100));
            compose(&(v50_5),&(v51_7))
          };
          drop(v50_5);
          let v50_9: Space = intersect(&(*CONSTANT_6),&(v50_2));
          drop(v50_2);
          let v50_10: Space = if has_head(&(v50_9)) { singleton(&[]) } else { Space::new() };
          drop(v50_9);
          let v50_12: Space = if (v50_10).is_empty() { Space::new() } else {
            let v52_6: Path = concat_path(&(v38_4_head),&(v49_6_head));
            let v52_11: Space = routine_6(c, &(v52_6), &(v49_6_tail), &(v1_100));
            drop(v52_6);
            compose(&(v50_10),&(v52_11))
          };
          drop(v50_10);
          let v50_13: Space = unite(&(v50_8),&(v50_12));
          v49_6.join_into((v50_13).clone());
        }
        drop(v49_6_cursor);
        compose(&(v48_5),&(v49_6))
      };
      drop(v48_5);
      let v48_8: Space = intersect(&(*CONSTANT_6),&(v48_2));
      drop(v48_2);
      let v48_9: Space = if has_head(&(v48_8)) { singleton(&[]) } else { Space::new() };
      drop(v48_8);
      let v48_11: Space = if (v48_9).is_empty() { Space::new() } else {
        let mut v53_10 = Space::new();
        let mut v53_10_cursor = (v38_4_tail).read_zipper();
        for v53_10_byte in v53_10_cursor.child_mask().iter() {
          v53_10_cursor.descend_to_byte(v53_10_byte);
          let v53_10_tail = v53_10_cursor.make_map();
          v53_10_cursor.ascend(1);
          let v53_10_head = Path::from_slice(&[v53_10_byte]);
          let v54_2: Space = singleton(&(v53_10_head));
          let v54_3: Space = intersect(&(*CONSTANT_6),&(v54_2));
          let v54_4: Space = if has_head(&(v54_3)) { singleton(&[]) } else { Space::new() };
          drop(v54_3);
          let v54_5: Space = subtract(&(*CONSTANT_5),&(v54_4));
          drop(v54_4);
          let v54_8: Space = if (v54_5).is_empty() { Space::new() } else {
            let v55_6: Path = concat_path(&(v38_4_head),&(v53_10_head));
            let v55_7: Space = routine_5(c, &(v55_6), &(v53_10_tail), &(v1_100));
            compose(&(v54_5),&(v55_7))
          };
          drop(v54_5);
          let v54_9: Space = intersect(&(*CONSTANT_6),&(v54_2));
          drop(v54_2);
          let v54_10: Space = if has_head(&(v54_9)) { singleton(&[]) } else { Space::new() };
          drop(v54_9);
          let v54_12: Space = if (v54_10).is_empty() { Space::new() } else {
            let v56_6: Path = concat_path(&(v38_4_head),&(v53_10_head));
            let v56_11: Space = routine_7(c, &(v56_6), &(v53_10_tail), &(v1_100));
            drop(v56_6);
            compose(&(v54_10),&(v56_11))
          };
          drop(v54_10);
          let v54_13: Space = unite(&(v54_8),&(v54_12));
          v53_10.join_into((v54_13).clone());
        }
        drop(v53_10_cursor);
        compose(&(v48_9),&(v53_10))
      };
      drop(v48_9);
      let v48_12: Space = unite(&(v48_7),&(v48_11));
      v38_4.join_into((v48_12).clone());
    }
    drop(v38_4_cursor);
    drop(v38_2);
    let v38_5: Space = unite(&(v38_3),&(v38_4));
    let v38_6: Space = unwrap(&(v1_100),&(*CONSTANT_7));
    let v38_7: Space = unwrap(&(v38_6),&(*CONSTANT_8));
    let mut v38_8 = Space::new();
    let mut v38_8_cursor = (v38_7).read_zipper();
    for v38_8_byte in v38_8_cursor.child_mask().iter() {
      v38_8_cursor.descend_to_byte(v38_8_byte);
      let v38_8_tail = v38_8_cursor.make_map();
      v38_8_cursor.ascend(1);
      let v38_8_head = Path::from_slice(&[v38_8_byte]);
      let v57_2: Space = singleton(&(v38_8_head));
      let v57_3: Space = intersect(&(*CONSTANT_6),&(v57_2));
      let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
      drop(v57_3);
      let v57_5: Space = subtract(&(*CONSTANT_5),&(v57_4));
      drop(v57_4);
      let v57_7: Space = if (v57_5).is_empty() { Space::new() } else {
        let mut v58_6 = Space::new();
        let mut v58_6_cursor = (v38_8_tail).read_zipper();
        for v58_6_byte in v58_6_cursor.child_mask().iter() {
          v58_6_cursor.descend_to_byte(v58_6_byte);
          let v58_6_tail = v58_6_cursor.make_map();
          v58_6_cursor.ascend(1);
          let v58_6_head = Path::from_slice(&[v58_6_byte]);
          let v59_2: Space = singleton(&(v58_6_head));
          let v59_3: Space = intersect(&(*CONSTANT_6),&(v59_2));
          let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
          drop(v59_3);
          let v59_5: Space = subtract(&(*CONSTANT_5),&(v59_4));
          drop(v59_4);
          let v59_8: Space = if (v59_5).is_empty() { Space::new() } else {
            let v60_6: Path = concat_path(&(v38_8_head),&(v58_6_head));
            let v60_7: Space = routine_8(c, &(v60_6), &(v58_6_tail));
            compose(&(v59_5),&(v60_7))
          };
          drop(v59_5);
          let v59_9: Space = intersect(&(*CONSTANT_6),&(v59_2));
          drop(v59_2);
          let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
          drop(v59_9);
          let v59_12: Space = if (v59_10).is_empty() { Space::new() } else {
            let v61_6: Path = concat_path(&(v38_8_head),&(v58_6_head));
            let v61_11: Space = routine_9(c, &(v61_6), &(v58_6_tail));
            drop(v61_6);
            compose(&(v59_10),&(v61_11))
          };
          drop(v59_10);
          let v59_13: Space = unite(&(v59_8),&(v59_12));
          v58_6.join_into((v59_13).clone());
        }
        drop(v58_6_cursor);
        compose(&(v57_5),&(v58_6))
      };
      drop(v57_5);
      let v57_8: Space = intersect(&(*CONSTANT_6),&(v57_2));
      drop(v57_2);
      let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
      drop(v57_8);
      let v57_11: Space = if (v57_9).is_empty() { Space::new() } else {
        let mut v62_10 = Space::new();
        let mut v62_10_cursor = (v38_8_tail).read_zipper();
        for v62_10_byte in v62_10_cursor.child_mask().iter() {
          v62_10_cursor.descend_to_byte(v62_10_byte);
          let v62_10_tail = v62_10_cursor.make_map();
          v62_10_cursor.ascend(1);
          let v62_10_head = Path::from_slice(&[v62_10_byte]);
          let v63_2: Space = singleton(&(v62_10_head));
          let v63_3: Space = intersect(&(*CONSTANT_6),&(v63_2));
          let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
          drop(v63_3);
          let v63_5: Space = subtract(&(*CONSTANT_5),&(v63_4));
          drop(v63_4);
          let v63_8: Space = if (v63_5).is_empty() { Space::new() } else {
            let v64_6: Path = concat_path(&(v38_8_head),&(v62_10_head));
            let v64_7: Space = routine_8(c, &(v64_6), &(v62_10_tail));
            compose(&(v63_5),&(v64_7))
          };
          drop(v63_5);
          let v63_9: Space = intersect(&(*CONSTANT_6),&(v63_2));
          drop(v63_2);
          let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
          drop(v63_9);
          let v63_12: Space = if (v63_10).is_empty() { Space::new() } else {
            let v65_6: Path = concat_path(&(v38_8_head),&(v62_10_head));
            let v65_11: Space = routine_10(c, &(v65_6), &(v62_10_tail));
            drop(v65_6);
            compose(&(v63_10),&(v65_11))
          };
          drop(v63_10);
          let v63_13: Space = unite(&(v63_8),&(v63_12));
          v62_10.join_into((v63_13).clone());
        }
        drop(v62_10_cursor);
        compose(&(v57_9),&(v62_10))
      };
      drop(v57_9);
      let v57_12: Space = unite(&(v57_7),&(v57_11));
      v38_8.join_into((v57_12).clone());
    }
    drop(v38_8_cursor);
    drop(v38_7);
    let v38_9: Space = unite(&(v38_5),&(v38_8));
    let v38_10: Space = unwrap(&(v38_6),&(*CONSTANT_4));
    let mut v38_11 = Space::new();
    let mut v38_11_cursor = (v38_10).read_zipper();
    for v38_11_byte in v38_11_cursor.child_mask().iter() {
      v38_11_cursor.descend_to_byte(v38_11_byte);
      let v38_11_tail = v38_11_cursor.make_map();
      v38_11_cursor.ascend(1);
      let v38_11_head = Path::from_slice(&[v38_11_byte]);
      let v66_2: Space = singleton(&(v38_11_head));
      let v66_3: Space = intersect(&(*CONSTANT_6),&(v66_2));
      let v66_4: Space = if has_head(&(v66_3)) { singleton(&[]) } else { Space::new() };
      drop(v66_3);
      let v66_5: Space = subtract(&(*CONSTANT_5),&(v66_4));
      drop(v66_4);
      let v66_7: Space = if (v66_5).is_empty() { Space::new() } else {
        let mut v67_6 = Space::new();
        let mut v67_6_cursor = (v38_11_tail).read_zipper();
        for v67_6_byte in v67_6_cursor.child_mask().iter() {
          v67_6_cursor.descend_to_byte(v67_6_byte);
          let v67_6_tail = v67_6_cursor.make_map();
          v67_6_cursor.ascend(1);
          let v67_6_head = Path::from_slice(&[v67_6_byte]);
          let v68_2: Space = singleton(&(v67_6_head));
          let v68_3: Space = intersect(&(*CONSTANT_6),&(v68_2));
          let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
          drop(v68_3);
          let v68_5: Space = subtract(&(*CONSTANT_5),&(v68_4));
          drop(v68_4);
          let v68_8: Space = if (v68_5).is_empty() { Space::new() } else {
            let v69_6: Path = concat_path(&(v38_11_head),&(v67_6_head));
            let v69_7: Space = routine_11(c, &(v69_6), &(v67_6_tail), &(v1_100));
            compose(&(v68_5),&(v69_7))
          };
          drop(v68_5);
          let v68_9: Space = intersect(&(*CONSTANT_6),&(v68_2));
          drop(v68_2);
          let v68_10: Space = if has_head(&(v68_9)) { singleton(&[]) } else { Space::new() };
          drop(v68_9);
          let v68_12: Space = if (v68_10).is_empty() { Space::new() } else {
            let v70_6: Path = concat_path(&(v38_11_head),&(v67_6_head));
            let v70_11: Space = routine_12(c, &(v70_6), &(v67_6_tail), &(v1_100));
            drop(v70_6);
            compose(&(v68_10),&(v70_11))
          };
          drop(v68_10);
          let v68_13: Space = unite(&(v68_8),&(v68_12));
          v67_6.join_into((v68_13).clone());
        }
        drop(v67_6_cursor);
        compose(&(v66_5),&(v67_6))
      };
      drop(v66_5);
      let v66_8: Space = intersect(&(*CONSTANT_6),&(v66_2));
      drop(v66_2);
      let v66_9: Space = if has_head(&(v66_8)) { singleton(&[]) } else { Space::new() };
      drop(v66_8);
      let v66_11: Space = if (v66_9).is_empty() { Space::new() } else {
        let mut v71_10 = Space::new();
        let mut v71_10_cursor = (v38_11_tail).read_zipper();
        for v71_10_byte in v71_10_cursor.child_mask().iter() {
          v71_10_cursor.descend_to_byte(v71_10_byte);
          let v71_10_tail = v71_10_cursor.make_map();
          v71_10_cursor.ascend(1);
          let v71_10_head = Path::from_slice(&[v71_10_byte]);
          let v72_2: Space = singleton(&(v71_10_head));
          let v72_3: Space = intersect(&(*CONSTANT_6),&(v72_2));
          let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
          drop(v72_3);
          let v72_5: Space = subtract(&(*CONSTANT_5),&(v72_4));
          drop(v72_4);
          let v72_8: Space = if (v72_5).is_empty() { Space::new() } else {
            let v73_6: Path = concat_path(&(v38_11_head),&(v71_10_head));
            let v73_7: Space = routine_11(c, &(v73_6), &(v71_10_tail), &(v1_100));
            compose(&(v72_5),&(v73_7))
          };
          drop(v72_5);
          let v72_9: Space = intersect(&(*CONSTANT_6),&(v72_2));
          drop(v72_2);
          let v72_10: Space = if has_head(&(v72_9)) { singleton(&[]) } else { Space::new() };
          drop(v72_9);
          let v72_12: Space = if (v72_10).is_empty() { Space::new() } else {
            let v74_6: Path = concat_path(&(v38_11_head),&(v71_10_head));
            let v74_11: Space = routine_13(c, &(v74_6), &(v71_10_tail), &(v1_100));
            drop(v74_6);
            compose(&(v72_10),&(v74_11))
          };
          drop(v72_10);
          let v72_13: Space = unite(&(v72_8),&(v72_12));
          v71_10.join_into((v72_13).clone());
        }
        drop(v71_10_cursor);
        compose(&(v66_9),&(v71_10))
      };
      drop(v66_9);
      let v66_12: Space = unite(&(v66_7),&(v66_11));
      v38_11.join_into((v66_12).clone());
    }
    drop(v38_11_cursor);
    drop(v38_10);
    let v38_12: Space = unite(&(v38_9),&(v38_11));
    let v38_13: Space = unwrap(&(v1_100),&(*CONSTANT_2));
    let v38_14: Space = subtract(&(v38_12),&(v38_13));
    drop(v38_13);
    let v38_15: Space = unwrap(&(v1_100),&(*CONSTANT_9));
    let v38_16: Space = subtract(&(v38_14),&(v38_15));
    drop(v38_15);
    let v38_17: Space = wrap(&(v38_16),&(*CONSTANT_9));
    let v38_18: Space = unite(&(v38_1),&(v38_6));
    drop(v38_1);
    drop(v38_6);
    let v38_19: Space = wrap(&(v38_18),&(*CONSTANT_7));
    drop(v38_18);
    let v38_20: Space = unite(&(v38_17),&(v38_19));
    drop(v38_19);
    let v38_21: Space = unite(&(v38_20),&(v1_100));
    let v1_100_next = unite(&v1_100,&(v38_21));
    if equal(&v1_100_next,&v1_100) { break; }
    v1_100 = v1_100_next;
  }

((v1_100).clone(),(v1_14).clone(),(v1_24).clone(),(v1_25).clone(),(v1_39).clone(),(v1_40).clone(),(v1_51).clone(),(v1_52).clone(),(v1_55).clone(),(v1_58).clone(),(v1_59).clone(),(v1_62).clone(),(v1_63).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_2: Space = routine_1(c, &(*CONSTANT_1));
  let v0_3: Space = unite(&(*CONSTANT_0),&(v0_2));
  let v0_5: Space = unwrap(&(v0_3),&(*CONSTANT_2));
  (v0_5).clone()
}

fn routine_1(c: &mut Context, s0: &Space) -> Space {
  let (v1_100,v1_14,v1_24,v1_25,v1_39,v1_40,v1_51,v1_52,v1_55,v1_58,v1_59,v1_62,v1_63,) = native_block_0(c, s0);
  let v1_101: Space = unite(&(*s0),&(v1_100));
  (v1_101).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v75_12 = Space::new();
  let mut v75_12_cursor = (*s0).read_zipper();
  for v75_12_byte in v75_12_cursor.child_mask().iter() {
    v75_12_cursor.descend_to_byte(v75_12_byte);
    let v75_12_tail = v75_12_cursor.make_map();
    v75_12_cursor.ascend(1);
    let v75_12_head = Path::from_slice(&[v75_12_byte]);
    let v76_2: Space = singleton(&(v75_12_head));
    let v76_3: Space = intersect(&(*CONSTANT_6),&(v76_2));
    let v76_4: Space = if has_head(&(v76_3)) { singleton(&[]) } else { Space::new() };
    drop(v76_3);
    let v76_5: Space = subtract(&(*CONSTANT_5),&(v76_4));
    drop(v76_4);
    let v76_8: Space = if (v76_5).is_empty() { Space::new() } else {
      let v77_6: Path = concat_path(&(*p0),&(v75_12_head));
      let mut v77_7 = Space::new();
      let mut v77_7_cursor = (v75_12_tail).read_zipper();
      for v77_7_byte in v77_7_cursor.child_mask().iter() {
        v77_7_cursor.descend_to_byte(v77_7_byte);
        let v77_7_tail = v77_7_cursor.make_map();
        v77_7_cursor.ascend(1);
        let v77_7_head = Path::from_slice(&[v77_7_byte]);
        let v78_2: Space = singleton(&(v77_7_head));
        let v78_3: Space = intersect(&(*CONSTANT_6),&(v78_2));
        let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
        drop(v78_3);
        let v78_5: Space = subtract(&(*CONSTANT_5),&(v78_4));
        drop(v78_4);
        let v78_8: Space = if (v78_5).is_empty() { Space::new() } else {
          let v79_6: Path = concat_path(&(v77_6),&(v77_7_head));
          let v79_7: Space = routine_14(c, &(v79_6), &(v77_7_tail), &(*s1));
          compose(&(v78_5),&(v79_7))
        };
        drop(v78_5);
        let v78_9: Space = intersect(&(*CONSTANT_6),&(v78_2));
        drop(v78_2);
        let v78_10: Space = if has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
        drop(v78_9);
        let v78_12: Space = if (v78_10).is_empty() { Space::new() } else {
          let v80_6: Path = concat_path(&(v77_6),&(v77_7_head));
          let v80_11: Space = routine_15(c, &(v80_6), &(v77_7_tail), &(*s1));
          drop(v80_6);
          compose(&(v78_10),&(v80_11))
        };
        drop(v78_10);
        let v78_13: Space = unite(&(v78_8),&(v78_12));
        v77_7.join_into((v78_13).clone());
      }
      drop(v77_7_cursor);
      compose(&(v76_5),&(v77_7))
    };
    drop(v76_5);
    let v76_9: Space = intersect(&(*CONSTANT_6),&(v76_2));
    drop(v76_2);
    let v76_10: Space = if has_head(&(v76_9)) { singleton(&[]) } else { Space::new() };
    drop(v76_9);
    let v76_12: Space = if (v76_10).is_empty() { Space::new() } else {
      let v81_6: Path = concat_path(&(*p0),&(v75_12_head));
      let mut v81_11 = Space::new();
      let mut v81_11_cursor = (v75_12_tail).read_zipper();
      for v81_11_byte in v81_11_cursor.child_mask().iter() {
        v81_11_cursor.descend_to_byte(v81_11_byte);
        let v81_11_tail = v81_11_cursor.make_map();
        v81_11_cursor.ascend(1);
        let v81_11_head = Path::from_slice(&[v81_11_byte]);
        let v82_2: Space = singleton(&(v81_11_head));
        let v82_3: Space = intersect(&(*CONSTANT_6),&(v82_2));
        let v82_4: Space = if has_head(&(v82_3)) { singleton(&[]) } else { Space::new() };
        drop(v82_3);
        let v82_5: Space = subtract(&(*CONSTANT_5),&(v82_4));
        drop(v82_4);
        let v82_8: Space = if (v82_5).is_empty() { Space::new() } else {
          let v83_6: Path = concat_path(&(v81_6),&(v81_11_head));
          let v83_7: Space = routine_14(c, &(v83_6), &(v81_11_tail), &(*s1));
          compose(&(v82_5),&(v83_7))
        };
        drop(v82_5);
        let v82_9: Space = intersect(&(*CONSTANT_6),&(v82_2));
        drop(v82_2);
        let v82_10: Space = if has_head(&(v82_9)) { singleton(&[]) } else { Space::new() };
        drop(v82_9);
        let v82_12: Space = if (v82_10).is_empty() { Space::new() } else {
          let v84_6: Path = concat_path(&(v81_6),&(v81_11_head));
          let v84_11: Space = routine_4(c, &(v84_6), &(v81_11_tail), &(*s1));
          drop(v84_6);
          compose(&(v82_10),&(v84_11))
        };
        drop(v82_10);
        let v82_13: Space = unite(&(v82_8),&(v82_12));
        v81_11.join_into((v82_13).clone());
      }
      drop(v81_11_cursor);
      drop(v81_6);
      compose(&(v76_10),&(v81_11))
    };
    drop(v76_10);
    let v76_13: Space = unite(&(v76_8),&(v76_12));
    v75_12.join_into((v76_13).clone());
  }
  drop(v75_12_cursor);
  (v75_12).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v85_12 = Space::new();
  let mut v85_12_cursor = (*s0).read_zipper();
  for v85_12_byte in v85_12_cursor.child_mask().iter() {
    v85_12_cursor.descend_to_byte(v85_12_byte);
    let v85_12_tail = v85_12_cursor.make_map();
    v85_12_cursor.ascend(1);
    let v85_12_head = Path::from_slice(&[v85_12_byte]);
    let v86_2: Space = singleton(&(v85_12_head));
    let v86_3: Space = intersect(&(*CONSTANT_6),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_5),&(v86_4));
    drop(v86_4);
    let v86_8: Space = if (v86_5).is_empty() { Space::new() } else {
      let v87_6: Path = concat_path(&(*p0),&(v85_12_head));
      let mut v87_7 = Space::new();
      let mut v87_7_cursor = (v85_12_tail).read_zipper();
      for v87_7_byte in v87_7_cursor.child_mask().iter() {
        v87_7_cursor.descend_to_byte(v87_7_byte);
        let v87_7_tail = v87_7_cursor.make_map();
        v87_7_cursor.ascend(1);
        let v87_7_head = Path::from_slice(&[v87_7_byte]);
        let v88_2: Space = singleton(&(v87_7_head));
        let v88_3: Space = intersect(&(*CONSTANT_6),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_5),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
          let v89_6: Path = concat_path(&(v87_6),&(v87_7_head));
          let v89_7: Space = routine_14(c, &(v89_6), &(v87_7_tail), &(*s1));
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_6),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
          let v90_6: Path = concat_path(&(v87_6),&(v87_7_head));
          let v90_11: Space = routine_15(c, &(v90_6), &(v87_7_tail), &(*s1));
          drop(v90_6);
          compose(&(v88_10),&(v90_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        v87_7.join_into((v88_13).clone());
      }
      drop(v87_7_cursor);
      compose(&(v86_5),&(v87_7))
    };
    drop(v86_5);
    let v86_9: Space = intersect(&(*CONSTANT_6),&(v86_2));
    drop(v86_2);
    let v86_10: Space = if has_head(&(v86_9)) { singleton(&[]) } else { Space::new() };
    drop(v86_9);
    let v86_12: Space = if (v86_10).is_empty() { Space::new() } else {
      let mut v91_11 = Space::new();
      let mut v91_11_cursor = (v85_12_tail).read_zipper();
      for v91_11_byte in v91_11_cursor.child_mask().iter() {
        v91_11_cursor.descend_to_byte(v91_11_byte);
        let v91_11_tail = v91_11_cursor.make_map();
        v91_11_cursor.ascend(1);
        let v91_11_head = Path::from_slice(&[v91_11_byte]);
        let v92_2: Space = singleton(&(v91_11_head));
        let v92_3: Space = intersect(&(*CONSTANT_6),&(v92_2));
        let v92_4: Space = if has_head(&(v92_3)) { singleton(&[]) } else { Space::new() };
        drop(v92_3);
        let v92_5: Space = subtract(&(*CONSTANT_5),&(v92_4));
        drop(v92_4);
        let v92_7: Space = if (v92_5).is_empty() { Space::new() } else {
          let v93_6: Space = routine_16(c, &(v91_11_head), &(v91_11_tail), &(*s1));
          compose(&(v92_5),&(v93_6))
        };
        drop(v92_5);
        let v92_8: Space = intersect(&(*CONSTANT_6),&(v92_2));
        drop(v92_2);
        let v92_9: Space = if has_head(&(v92_8)) { singleton(&[]) } else { Space::new() };
        drop(v92_8);
        let v92_11: Space = if (v92_9).is_empty() { Space::new() } else {
          let v94_10: Space = routine_17(c, &(v91_11_head), &(v91_11_tail), &(*s1));
          compose(&(v92_9),&(v94_10))
        };
        drop(v92_9);
        let v92_12: Space = unite(&(v92_7),&(v92_11));
        v91_11.join_into((v92_12).clone());
      }
      drop(v91_11_cursor);
      compose(&(v86_10),&(v91_11))
    };
    drop(v86_10);
    let v95_6: Path = concat_path(&(*p0),&(v85_12_head));
    let v86_13: Space = wrap(&(v86_12),&(v95_6));
    let v86_14: Space = unite(&(v86_8),&(v86_13));
    v85_12.join_into((v86_14).clone());
  }
  drop(v85_12_cursor);
  (v85_12).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v96_12 = Space::new();
  let mut v96_12_cursor = (*s0).read_zipper();
  for v96_12_byte in v96_12_cursor.child_mask().iter() {
    v96_12_cursor.descend_to_byte(v96_12_byte);
    let v96_12_tail = v96_12_cursor.make_map();
    v96_12_cursor.ascend(1);
    let v96_12_head = Path::from_slice(&[v96_12_byte]);
    let v97_2: Space = singleton(&(v96_12_head));
    let v97_3: Space = intersect(&(*CONSTANT_6),&(v97_2));
    let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
    drop(v97_3);
    let v97_5: Space = subtract(&(*CONSTANT_5),&(v97_4));
    drop(v97_4);
    let v97_7: Space = if (v97_5).is_empty() { Space::new() } else {
      let mut v98_6 = Space::new();
      let mut v98_6_cursor = (v96_12_tail).read_zipper();
      for v98_6_byte in v98_6_cursor.child_mask().iter() {
        v98_6_cursor.descend_to_byte(v98_6_byte);
        let v98_6_tail = v98_6_cursor.make_map();
        v98_6_cursor.ascend(1);
        let v98_6_head = Path::from_slice(&[v98_6_byte]);
        let v99_2: Space = singleton(&(v98_6_head));
        let v99_3: Space = intersect(&(*CONSTANT_6),&(v99_2));
        let v99_4: Space = if has_head(&(v99_3)) { singleton(&[]) } else { Space::new() };
        drop(v99_3);
        let v99_5: Space = subtract(&(*CONSTANT_5),&(v99_4));
        drop(v99_4);
        let v99_8: Space = if (v99_5).is_empty() { Space::new() } else {
          let v100_6: Path = concat_path(&(v96_12_head),&(v98_6_head));
          let v100_7: Space = routine_18(c, &(v100_6), &(v98_6_tail), &(*s1));
          compose(&(v99_5),&(v100_7))
        };
        drop(v99_5);
        let v99_9: Space = intersect(&(*CONSTANT_6),&(v99_2));
        drop(v99_2);
        let v99_10: Space = if has_head(&(v99_9)) { singleton(&[]) } else { Space::new() };
        drop(v99_9);
        let v99_12: Space = if (v99_10).is_empty() { Space::new() } else {
          let v101_6: Path = concat_path(&(v96_12_head),&(v98_6_head));
          let v101_11: Space = routine_19(c, &(v101_6), &(v98_6_tail), &(*s1));
          drop(v101_6);
          compose(&(v99_10),&(v101_11))
        };
        drop(v99_10);
        let v99_13: Space = unite(&(v99_8),&(v99_12));
        v98_6.join_into((v99_13).clone());
      }
      drop(v98_6_cursor);
      compose(&(v97_5),&(v98_6))
    };
    drop(v97_5);
    let v97_8: Space = intersect(&(*CONSTANT_6),&(v97_2));
    drop(v97_2);
    let v97_9: Space = if has_head(&(v97_8)) { singleton(&[]) } else { Space::new() };
    drop(v97_8);
    let v97_11: Space = if (v97_9).is_empty() { Space::new() } else {
      let mut v102_10 = Space::new();
      let mut v102_10_cursor = (v96_12_tail).read_zipper();
      for v102_10_byte in v102_10_cursor.child_mask().iter() {
        v102_10_cursor.descend_to_byte(v102_10_byte);
        let v102_10_tail = v102_10_cursor.make_map();
        v102_10_cursor.ascend(1);
        let v102_10_head = Path::from_slice(&[v102_10_byte]);
        let v103_2: Space = singleton(&(v102_10_head));
        let v103_3: Space = intersect(&(*CONSTANT_6),&(v103_2));
        let v103_4: Space = if has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
        drop(v103_3);
        let v103_5: Space = subtract(&(*CONSTANT_5),&(v103_4));
        drop(v103_4);
        let v103_8: Space = if (v103_5).is_empty() { Space::new() } else {
          let v104_6: Path = concat_path(&(v96_12_head),&(v102_10_head));
          let v104_7: Space = routine_18(c, &(v104_6), &(v102_10_tail), &(*s1));
          compose(&(v103_5),&(v104_7))
        };
        drop(v103_5);
        let v103_9: Space = intersect(&(*CONSTANT_6),&(v103_2));
        drop(v103_2);
        let v103_10: Space = if has_head(&(v103_9)) { singleton(&[]) } else { Space::new() };
        drop(v103_9);
        let v103_12: Space = if (v103_10).is_empty() { Space::new() } else {
          let v105_6: Path = concat_path(&(v96_12_head),&(v102_10_head));
          let v105_11: Space = routine_20(c, &(v105_6), &(v102_10_tail), &(*s1));
          drop(v105_6);
          compose(&(v103_10),&(v105_11))
        };
        drop(v103_10);
        let v103_13: Space = unite(&(v103_8),&(v103_12));
        v102_10.join_into((v103_13).clone());
      }
      drop(v102_10_cursor);
      compose(&(v97_9),&(v102_10))
    };
    drop(v97_9);
    let v97_12: Space = unite(&(v97_7),&(v97_11));
    v96_12.join_into((v97_12).clone());
  }
  drop(v96_12_cursor);
  let v96_13: Space = wrap(&(v96_12),&(*p0));
  (v96_13).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v106_12 = Space::new();
  let mut v106_12_cursor = (*s0).read_zipper();
  for v106_12_byte in v106_12_cursor.child_mask().iter() {
    v106_12_cursor.descend_to_byte(v106_12_byte);
    let v106_12_tail = v106_12_cursor.make_map();
    v106_12_cursor.ascend(1);
    let v106_12_head = Path::from_slice(&[v106_12_byte]);
    let v107_2: Space = singleton(&(v106_12_head));
    let v107_3: Space = intersect(&(*CONSTANT_6),&(v107_2));
    let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
    drop(v107_3);
    let v107_5: Space = subtract(&(*CONSTANT_5),&(v107_4));
    drop(v107_4);
    let v107_8: Space = if (v107_5).is_empty() { Space::new() } else {
      let v108_6: Path = concat_path(&(*p0),&(v106_12_head));
      let mut v108_7 = Space::new();
      let mut v108_7_cursor = (v106_12_tail).read_zipper();
      for v108_7_byte in v108_7_cursor.child_mask().iter() {
        v108_7_cursor.descend_to_byte(v108_7_byte);
        let v108_7_tail = v108_7_cursor.make_map();
        v108_7_cursor.ascend(1);
        let v108_7_head = Path::from_slice(&[v108_7_byte]);
        let v109_2: Space = singleton(&(v108_7_head));
        let v109_3: Space = intersect(&(*CONSTANT_6),&(v109_2));
        let v109_4: Space = if has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
        drop(v109_3);
        let v109_5: Space = subtract(&(*CONSTANT_5),&(v109_4));
        drop(v109_4);
        let v109_8: Space = if (v109_5).is_empty() { Space::new() } else {
          let v110_6: Path = concat_path(&(v108_6),&(v108_7_head));
          let v110_7: Space = routine_21(c, &(v110_6), &(v108_7_tail), &(*s1));
          compose(&(v109_5),&(v110_7))
        };
        drop(v109_5);
        let v109_9: Space = intersect(&(*CONSTANT_6),&(v109_2));
        drop(v109_2);
        let v109_10: Space = if has_head(&(v109_9)) { singleton(&[]) } else { Space::new() };
        drop(v109_9);
        let v109_12: Space = if (v109_10).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v108_6),&(v108_7_head));
          let v111_11: Space = routine_22(c, &(v111_6), &(v108_7_tail), &(*s1));
          drop(v111_6);
          compose(&(v109_10),&(v111_11))
        };
        drop(v109_10);
        let v109_13: Space = unite(&(v109_8),&(v109_12));
        v108_7.join_into((v109_13).clone());
      }
      drop(v108_7_cursor);
      compose(&(v107_5),&(v108_7))
    };
    drop(v107_5);
    let v107_9: Space = intersect(&(*CONSTANT_6),&(v107_2));
    drop(v107_2);
    let v107_10: Space = if has_head(&(v107_9)) { singleton(&[]) } else { Space::new() };
    drop(v107_9);
    let v107_12: Space = if (v107_10).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&(v106_12_head));
      let mut v112_11 = Space::new();
      let mut v112_11_cursor = (v106_12_tail).read_zipper();
      for v112_11_byte in v112_11_cursor.child_mask().iter() {
        v112_11_cursor.descend_to_byte(v112_11_byte);
        let v112_11_tail = v112_11_cursor.make_map();
        v112_11_cursor.ascend(1);
        let v112_11_head = Path::from_slice(&[v112_11_byte]);
        let v113_2: Space = singleton(&(v112_11_head));
        let v113_3: Space = intersect(&(*CONSTANT_6),&(v113_2));
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = subtract(&(*CONSTANT_5),&(v113_4));
        drop(v113_4);
        let v113_8: Space = if (v113_5).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v112_6),&(v112_11_head));
          let v114_7: Space = routine_21(c, &(v114_6), &(v112_11_tail), &(*s1));
          compose(&(v113_5),&(v114_7))
        };
        drop(v113_5);
        let v113_9: Space = intersect(&(*CONSTANT_6),&(v113_2));
        drop(v113_2);
        let v113_10: Space = if has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
        drop(v113_9);
        let v113_12: Space = if (v113_10).is_empty() { Space::new() } else {
          let v115_6: Path = concat_path(&(v112_6),&(v112_11_head));
          let v115_11: Space = routine_7(c, &(v115_6), &(v112_11_tail), &(*s1));
          drop(v115_6);
          compose(&(v113_10),&(v115_11))
        };
        drop(v113_10);
        let v113_13: Space = unite(&(v113_8),&(v113_12));
        v112_11.join_into((v113_13).clone());
      }
      drop(v112_11_cursor);
      drop(v112_6);
      compose(&(v107_10),&(v112_11))
    };
    drop(v107_10);
    let v107_13: Space = unite(&(v107_8),&(v107_12));
    v106_12.join_into((v107_13).clone());
  }
  drop(v106_12_cursor);
  (v106_12).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v116_12 = Space::new();
  let mut v116_12_cursor = (*s0).read_zipper();
  for v116_12_byte in v116_12_cursor.child_mask().iter() {
    v116_12_cursor.descend_to_byte(v116_12_byte);
    let v116_12_tail = v116_12_cursor.make_map();
    v116_12_cursor.ascend(1);
    let v116_12_head = Path::from_slice(&[v116_12_byte]);
    let v117_2: Space = singleton(&(v116_12_head));
    let v117_3: Space = intersect(&(*CONSTANT_6),&(v117_2));
    let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
    drop(v117_3);
    let v117_5: Space = subtract(&(*CONSTANT_5),&(v117_4));
    drop(v117_4);
    let v117_8: Space = if (v117_5).is_empty() { Space::new() } else {
      let v118_6: Path = concat_path(&(*p0),&(v116_12_head));
      let mut v118_7 = Space::new();
      let mut v118_7_cursor = (v116_12_tail).read_zipper();
      for v118_7_byte in v118_7_cursor.child_mask().iter() {
        v118_7_cursor.descend_to_byte(v118_7_byte);
        let v118_7_tail = v118_7_cursor.make_map();
        v118_7_cursor.ascend(1);
        let v118_7_head = Path::from_slice(&[v118_7_byte]);
        let v119_2: Space = singleton(&(v118_7_head));
        let v119_3: Space = intersect(&(*CONSTANT_6),&(v119_2));
        let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
        drop(v119_3);
        let v119_5: Space = subtract(&(*CONSTANT_5),&(v119_4));
        drop(v119_4);
        let v119_8: Space = if (v119_5).is_empty() { Space::new() } else {
          let v120_6: Path = concat_path(&(v118_6),&(v118_7_head));
          let v120_7: Space = routine_21(c, &(v120_6), &(v118_7_tail), &(*s1));
          compose(&(v119_5),&(v120_7))
        };
        drop(v119_5);
        let v119_9: Space = intersect(&(*CONSTANT_6),&(v119_2));
        drop(v119_2);
        let v119_10: Space = if has_head(&(v119_9)) { singleton(&[]) } else { Space::new() };
        drop(v119_9);
        let v119_12: Space = if (v119_10).is_empty() { Space::new() } else {
          let v121_6: Path = concat_path(&(v118_6),&(v118_7_head));
          let v121_11: Space = routine_22(c, &(v121_6), &(v118_7_tail), &(*s1));
          drop(v121_6);
          compose(&(v119_10),&(v121_11))
        };
        drop(v119_10);
        let v119_13: Space = unite(&(v119_8),&(v119_12));
        v118_7.join_into((v119_13).clone());
      }
      drop(v118_7_cursor);
      compose(&(v117_5),&(v118_7))
    };
    drop(v117_5);
    let v117_9: Space = intersect(&(*CONSTANT_6),&(v117_2));
    drop(v117_2);
    let v117_10: Space = if has_head(&(v117_9)) { singleton(&[]) } else { Space::new() };
    drop(v117_9);
    let v117_12: Space = if (v117_10).is_empty() { Space::new() } else {
      let mut v122_11 = Space::new();
      let mut v122_11_cursor = (v116_12_tail).read_zipper();
      for v122_11_byte in v122_11_cursor.child_mask().iter() {
        v122_11_cursor.descend_to_byte(v122_11_byte);
        let v122_11_tail = v122_11_cursor.make_map();
        v122_11_cursor.ascend(1);
        let v122_11_head = Path::from_slice(&[v122_11_byte]);
        let v123_2: Space = singleton(&(v122_11_head));
        let v123_3: Space = intersect(&(*CONSTANT_6),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_5),&(v123_4));
        drop(v123_4);
        let v123_7: Space = if (v123_5).is_empty() { Space::new() } else {
          let v124_6: Space = routine_23(c, &(v122_11_head), &(v122_11_tail), &(*s1));
          compose(&(v123_5),&(v124_6))
        };
        drop(v123_5);
        let v123_8: Space = intersect(&(*CONSTANT_6),&(v123_2));
        drop(v123_2);
        let v123_9: Space = if has_head(&(v123_8)) { singleton(&[]) } else { Space::new() };
        drop(v123_8);
        let v123_11: Space = if (v123_9).is_empty() { Space::new() } else {
          let v125_10: Space = routine_24(c, &(v122_11_head), &(v122_11_tail), &(*s1));
          compose(&(v123_9),&(v125_10))
        };
        drop(v123_9);
        let v123_12: Space = unite(&(v123_7),&(v123_11));
        v122_11.join_into((v123_12).clone());
      }
      drop(v122_11_cursor);
      compose(&(v117_10),&(v122_11))
    };
    drop(v117_10);
    let v126_6: Path = concat_path(&(*p0),&(v116_12_head));
    let v117_13: Space = wrap(&(v117_12),&(v126_6));
    let v117_14: Space = unite(&(v117_8),&(v117_13));
    v116_12.join_into((v117_14).clone());
  }
  drop(v116_12_cursor);
  (v116_12).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v127_12 = Space::new();
  let mut v127_12_cursor = (*s0).read_zipper();
  for v127_12_byte in v127_12_cursor.child_mask().iter() {
    v127_12_cursor.descend_to_byte(v127_12_byte);
    let v127_12_tail = v127_12_cursor.make_map();
    v127_12_cursor.ascend(1);
    let v127_12_head = Path::from_slice(&[v127_12_byte]);
    let v128_2: Space = singleton(&(v127_12_head));
    let v128_3: Space = intersect(&(*CONSTANT_6),&(v128_2));
    let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
    drop(v128_3);
    let v128_5: Space = subtract(&(*CONSTANT_5),&(v128_4));
    drop(v128_4);
    let v128_7: Space = if (v128_5).is_empty() { Space::new() } else {
      let mut v129_6 = Space::new();
      let mut v129_6_cursor = (v127_12_tail).read_zipper();
      for v129_6_byte in v129_6_cursor.child_mask().iter() {
        v129_6_cursor.descend_to_byte(v129_6_byte);
        let v129_6_tail = v129_6_cursor.make_map();
        v129_6_cursor.ascend(1);
        let v129_6_head = Path::from_slice(&[v129_6_byte]);
        let v130_2: Space = singleton(&(v129_6_head));
        let v130_3: Space = intersect(&(*CONSTANT_6),&(v130_2));
        let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
        drop(v130_3);
        let v130_5: Space = subtract(&(*CONSTANT_5),&(v130_4));
        drop(v130_4);
        let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
          let v131_6: Path = concat_path(&(v127_12_head),&(v129_6_head));
          let v131_7: Space = routine_25(c, &(v131_6), &(v129_6_tail), &(*s1));
          compose(&(v130_5),&(v131_7))
        };
        drop(v130_5);
        let v130_9: Space = intersect(&(*CONSTANT_6),&(v130_2));
        drop(v130_2);
        let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
        drop(v130_9);
        let v130_12: Space = if (v130_10).is_empty() { Space::new() } else {
          let v132_6: Path = concat_path(&(v127_12_head),&(v129_6_head));
          let v132_11: Space = routine_26(c, &(v132_6), &(v129_6_tail), &(*s1));
          drop(v132_6);
          compose(&(v130_10),&(v132_11))
        };
        drop(v130_10);
        let v130_13: Space = unite(&(v130_8),&(v130_12));
        v129_6.join_into((v130_13).clone());
      }
      drop(v129_6_cursor);
      compose(&(v128_5),&(v129_6))
    };
    drop(v128_5);
    let v128_8: Space = intersect(&(*CONSTANT_6),&(v128_2));
    drop(v128_2);
    let v128_9: Space = if has_head(&(v128_8)) { singleton(&[]) } else { Space::new() };
    drop(v128_8);
    let v128_11: Space = if (v128_9).is_empty() { Space::new() } else {
      let mut v133_10 = Space::new();
      let mut v133_10_cursor = (v127_12_tail).read_zipper();
      for v133_10_byte in v133_10_cursor.child_mask().iter() {
        v133_10_cursor.descend_to_byte(v133_10_byte);
        let v133_10_tail = v133_10_cursor.make_map();
        v133_10_cursor.ascend(1);
        let v133_10_head = Path::from_slice(&[v133_10_byte]);
        let v134_2: Space = singleton(&(v133_10_head));
        let v134_3: Space = intersect(&(*CONSTANT_6),&(v134_2));
        let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
        drop(v134_3);
        let v134_5: Space = subtract(&(*CONSTANT_5),&(v134_4));
        drop(v134_4);
        let v134_8: Space = if (v134_5).is_empty() { Space::new() } else {
          let v135_6: Path = concat_path(&(v127_12_head),&(v133_10_head));
          let v135_7: Space = routine_25(c, &(v135_6), &(v133_10_tail), &(*s1));
          compose(&(v134_5),&(v135_7))
        };
        drop(v134_5);
        let v134_9: Space = intersect(&(*CONSTANT_6),&(v134_2));
        drop(v134_2);
        let v134_10: Space = if has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
        drop(v134_9);
        let v134_12: Space = if (v134_10).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v127_12_head),&(v133_10_head));
          let v136_11: Space = routine_27(c, &(v136_6), &(v133_10_tail), &(*s1));
          drop(v136_6);
          compose(&(v134_10),&(v136_11))
        };
        drop(v134_10);
        let v134_13: Space = unite(&(v134_8),&(v134_12));
        v133_10.join_into((v134_13).clone());
      }
      drop(v133_10_cursor);
      compose(&(v128_9),&(v133_10))
    };
    drop(v128_9);
    let v128_12: Space = unite(&(v128_7),&(v128_11));
    v127_12.join_into((v128_12).clone());
  }
  drop(v127_12_cursor);
  let v127_13: Space = wrap(&(v127_12),&(*p0));
  (v127_13).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v137_11 = Space::new();
  let mut v137_11_cursor = (*s0).read_zipper();
  for v137_11_byte in v137_11_cursor.child_mask().iter() {
    v137_11_cursor.descend_to_byte(v137_11_byte);
    let v137_11_tail = v137_11_cursor.make_map();
    v137_11_cursor.ascend(1);
    let v137_11_head = Path::from_slice(&[v137_11_byte]);
    let v138_2: Space = singleton(&(v137_11_head));
    let v138_3: Space = intersect(&(*CONSTANT_6),&(v138_2));
    let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
    drop(v138_3);
    let v138_5: Space = subtract(&(*CONSTANT_5),&(v138_4));
    drop(v138_4);
    let v138_8: Space = if (v138_5).is_empty() { Space::new() } else {
      let v139_6: Path = concat_path(&(*p0),&(v137_11_head));
      let mut v139_7 = Space::new();
      let mut v139_7_cursor = (v137_11_tail).read_zipper();
      for v139_7_byte in v139_7_cursor.child_mask().iter() {
        v139_7_cursor.descend_to_byte(v139_7_byte);
        let v139_7_tail = v139_7_cursor.make_map();
        v139_7_cursor.ascend(1);
        let v139_7_head = Path::from_slice(&[v139_7_byte]);
        let v140_2: Space = singleton(&(v139_7_head));
        let v140_3: Space = intersect(&(*CONSTANT_6),&(v140_2));
        let v140_4: Space = if has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
        drop(v140_3);
        let v140_5: Space = subtract(&(*CONSTANT_5),&(v140_4));
        drop(v140_4);
        let v140_8: Space = if (v140_5).is_empty() { Space::new() } else {
          let v141_6: Path = concat_path(&(v139_6),&(v139_7_head));
          let v141_7: Space = routine_28(c, &(v141_6), &(v139_7_tail));
          compose(&(v140_5),&(v141_7))
        };
        drop(v140_5);
        let v140_9: Space = intersect(&(*CONSTANT_6),&(v140_2));
        drop(v140_2);
        let v140_10: Space = if has_head(&(v140_9)) { singleton(&[]) } else { Space::new() };
        drop(v140_9);
        let v140_12: Space = if (v140_10).is_empty() { Space::new() } else {
          let v142_6: Path = concat_path(&(v139_6),&(v139_7_head));
          let v142_11: Space = routine_29(c, &(v142_6), &(v139_7_tail));
          drop(v142_6);
          compose(&(v140_10),&(v142_11))
        };
        drop(v140_10);
        let v140_13: Space = unite(&(v140_8),&(v140_12));
        v139_7.join_into((v140_13).clone());
      }
      drop(v139_7_cursor);
      compose(&(v138_5),&(v139_7))
    };
    drop(v138_5);
    let v138_9: Space = intersect(&(*CONSTANT_6),&(v138_2));
    drop(v138_2);
    let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
    drop(v138_9);
    let v138_12: Space = if (v138_10).is_empty() { Space::new() } else {
      let v143_6: Path = concat_path(&(*p0),&(v137_11_head));
      let mut v143_11 = Space::new();
      let mut v143_11_cursor = (v137_11_tail).read_zipper();
      for v143_11_byte in v143_11_cursor.child_mask().iter() {
        v143_11_cursor.descend_to_byte(v143_11_byte);
        let v143_11_tail = v143_11_cursor.make_map();
        v143_11_cursor.ascend(1);
        let v143_11_head = Path::from_slice(&[v143_11_byte]);
        let v144_2: Space = singleton(&(v143_11_head));
        let v144_3: Space = intersect(&(*CONSTANT_6),&(v144_2));
        let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
        drop(v144_3);
        let v144_5: Space = subtract(&(*CONSTANT_5),&(v144_4));
        drop(v144_4);
        let v144_8: Space = if (v144_5).is_empty() { Space::new() } else {
          let v145_6: Path = concat_path(&(v143_6),&(v143_11_head));
          let v145_7: Space = routine_28(c, &(v145_6), &(v143_11_tail));
          compose(&(v144_5),&(v145_7))
        };
        drop(v144_5);
        let v144_9: Space = intersect(&(*CONSTANT_6),&(v144_2));
        drop(v144_2);
        let v144_10: Space = if has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
        drop(v144_9);
        let v144_12: Space = if (v144_10).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v143_6),&(v143_11_head));
          let v146_11: Space = routine_10(c, &(v146_6), &(v143_11_tail));
          drop(v146_6);
          compose(&(v144_10),&(v146_11))
        };
        drop(v144_10);
        let v144_13: Space = unite(&(v144_8),&(v144_12));
        v143_11.join_into((v144_13).clone());
      }
      drop(v143_11_cursor);
      drop(v143_6);
      compose(&(v138_10),&(v143_11))
    };
    drop(v138_10);
    let v138_13: Space = unite(&(v138_8),&(v138_12));
    v137_11.join_into((v138_13).clone());
  }
  drop(v137_11_cursor);
  (v137_11).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v147_9 = Space::new();
  let mut v147_9_cursor = (*s0).read_zipper();
  for v147_9_byte in v147_9_cursor.child_mask().iter() {
    v147_9_cursor.descend_to_byte(v147_9_byte);
    let v147_9_tail = v147_9_cursor.make_map();
    v147_9_cursor.ascend(1);
    let v147_9_head = Path::from_slice(&[v147_9_byte]);
    let v148_2: Space = singleton(&(v147_9_head));
    let v148_3: Space = intersect(&(*CONSTANT_6),&(v148_2));
    let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
    drop(v148_3);
    let v148_5: Space = subtract(&(*CONSTANT_5),&(v148_4));
    drop(v148_4);
    let v148_8: Space = if (v148_5).is_empty() { Space::new() } else {
      let v149_6: Path = concat_path(&(*p0),&(v147_9_head));
      let mut v149_7 = Space::new();
      let mut v149_7_cursor = (v147_9_tail).read_zipper();
      for v149_7_byte in v149_7_cursor.child_mask().iter() {
        v149_7_cursor.descend_to_byte(v149_7_byte);
        let v149_7_tail = v149_7_cursor.make_map();
        v149_7_cursor.ascend(1);
        let v149_7_head = Path::from_slice(&[v149_7_byte]);
        let v150_2: Space = singleton(&(v149_7_head));
        let v150_3: Space = intersect(&(*CONSTANT_6),&(v150_2));
        let v150_4: Space = if has_head(&(v150_3)) { singleton(&[]) } else { Space::new() };
        drop(v150_3);
        let v150_5: Space = subtract(&(*CONSTANT_5),&(v150_4));
        drop(v150_4);
        let v150_8: Space = if (v150_5).is_empty() { Space::new() } else {
          let v151_6: Path = concat_path(&(v149_6),&(v149_7_head));
          let v151_7: Space = routine_28(c, &(v151_6), &(v149_7_tail));
          compose(&(v150_5),&(v151_7))
        };
        drop(v150_5);
        let v150_9: Space = intersect(&(*CONSTANT_6),&(v150_2));
        drop(v150_2);
        let v150_10: Space = if has_head(&(v150_9)) { singleton(&[]) } else { Space::new() };
        drop(v150_9);
        let v150_12: Space = if (v150_10).is_empty() { Space::new() } else {
          let v152_6: Path = concat_path(&(v149_6),&(v149_7_head));
          let v152_11: Space = routine_29(c, &(v152_6), &(v149_7_tail));
          drop(v152_6);
          compose(&(v150_10),&(v152_11))
        };
        drop(v150_10);
        let v150_13: Space = unite(&(v150_8),&(v150_12));
        v149_7.join_into((v150_13).clone());
      }
      drop(v149_7_cursor);
      compose(&(v148_5),&(v149_7))
    };
    drop(v148_5);
    let v148_9: Space = intersect(&(*CONSTANT_6),&(v148_2));
    drop(v148_2);
    let v148_10: Space = if has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
    drop(v148_9);
    let v148_11: Space = subtract(&(v147_9_tail),&(*CONSTANT_5));
    let v148_12: Space = compose(&(v148_10),&(v148_11));
    drop(v148_10);
    drop(v148_11);
    let v153_6: Path = concat_path(&(*p0),&(v147_9_head));
    let v148_13: Space = wrap(&(v148_12),&(v153_6));
    drop(v148_12);
    let v148_14: Space = unite(&(v148_8),&(v148_13));
    drop(v148_13);
    v147_9.join_into((v148_14).clone());
  }
  drop(v147_9_cursor);
  (v147_9).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v154_3: Space = subtract(&(*s0),&(*CONSTANT_5));
  let v154_4: Space = wrap(&(v154_3),&(*p0));
  drop(v154_3);
  (v154_4).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v155_12 = Space::new();
  let mut v155_12_cursor = (*s0).read_zipper();
  for v155_12_byte in v155_12_cursor.child_mask().iter() {
    v155_12_cursor.descend_to_byte(v155_12_byte);
    let v155_12_tail = v155_12_cursor.make_map();
    v155_12_cursor.ascend(1);
    let v155_12_head = Path::from_slice(&[v155_12_byte]);
    let v156_2: Space = singleton(&(v155_12_head));
    let v156_3: Space = intersect(&(*CONSTANT_6),&(v156_2));
    let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
    drop(v156_3);
    let v156_5: Space = subtract(&(*CONSTANT_5),&(v156_4));
    drop(v156_4);
    let v156_8: Space = if (v156_5).is_empty() { Space::new() } else {
      let v157_6: Path = concat_path(&(*p0),&(v155_12_head));
      let mut v157_7 = Space::new();
      let mut v157_7_cursor = (v155_12_tail).read_zipper();
      for v157_7_byte in v157_7_cursor.child_mask().iter() {
        v157_7_cursor.descend_to_byte(v157_7_byte);
        let v157_7_tail = v157_7_cursor.make_map();
        v157_7_cursor.ascend(1);
        let v157_7_head = Path::from_slice(&[v157_7_byte]);
        let v158_2: Space = singleton(&(v157_7_head));
        let v158_3: Space = intersect(&(*CONSTANT_6),&(v158_2));
        let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
        drop(v158_3);
        let v158_5: Space = subtract(&(*CONSTANT_5),&(v158_4));
        drop(v158_4);
        let v158_8: Space = if (v158_5).is_empty() { Space::new() } else {
          let v159_6: Path = concat_path(&(v157_6),&(v157_7_head));
          let v159_7: Space = routine_30(c, &(v159_6), &(v157_7_tail), &(*s1));
          compose(&(v158_5),&(v159_7))
        };
        drop(v158_5);
        let v158_9: Space = intersect(&(*CONSTANT_6),&(v158_2));
        drop(v158_2);
        let v158_10: Space = if has_head(&(v158_9)) { singleton(&[]) } else { Space::new() };
        drop(v158_9);
        let v158_12: Space = if (v158_10).is_empty() { Space::new() } else {
          let v160_6: Path = concat_path(&(v157_6),&(v157_7_head));
          let v160_11: Space = routine_31(c, &(v160_6), &(v157_7_tail), &(*s1));
          drop(v160_6);
          compose(&(v158_10),&(v160_11))
        };
        drop(v158_10);
        let v158_13: Space = unite(&(v158_8),&(v158_12));
        v157_7.join_into((v158_13).clone());
      }
      drop(v157_7_cursor);
      compose(&(v156_5),&(v157_7))
    };
    drop(v156_5);
    let v156_9: Space = intersect(&(*CONSTANT_6),&(v156_2));
    drop(v156_2);
    let v156_10: Space = if has_head(&(v156_9)) { singleton(&[]) } else { Space::new() };
    drop(v156_9);
    let v156_12: Space = if (v156_10).is_empty() { Space::new() } else {
      let v161_6: Path = concat_path(&(*p0),&(v155_12_head));
      let mut v161_11 = Space::new();
      let mut v161_11_cursor = (v155_12_tail).read_zipper();
      for v161_11_byte in v161_11_cursor.child_mask().iter() {
        v161_11_cursor.descend_to_byte(v161_11_byte);
        let v161_11_tail = v161_11_cursor.make_map();
        v161_11_cursor.ascend(1);
        let v161_11_head = Path::from_slice(&[v161_11_byte]);
        let v162_2: Space = singleton(&(v161_11_head));
        let v162_3: Space = intersect(&(*CONSTANT_6),&(v162_2));
        let v162_4: Space = if has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
        drop(v162_3);
        let v162_5: Space = subtract(&(*CONSTANT_5),&(v162_4));
        drop(v162_4);
        let v162_8: Space = if (v162_5).is_empty() { Space::new() } else {
          let v163_6: Path = concat_path(&(v161_6),&(v161_11_head));
          let v163_7: Space = routine_30(c, &(v163_6), &(v161_11_tail), &(*s1));
          compose(&(v162_5),&(v163_7))
        };
        drop(v162_5);
        let v162_9: Space = intersect(&(*CONSTANT_6),&(v162_2));
        drop(v162_2);
        let v162_10: Space = if has_head(&(v162_9)) { singleton(&[]) } else { Space::new() };
        drop(v162_9);
        let v162_12: Space = if (v162_10).is_empty() { Space::new() } else {
          let v164_6: Path = concat_path(&(v161_6),&(v161_11_head));
          let v164_11: Space = routine_13(c, &(v164_6), &(v161_11_tail), &(*s1));
          drop(v164_6);
          compose(&(v162_10),&(v164_11))
        };
        drop(v162_10);
        let v162_13: Space = unite(&(v162_8),&(v162_12));
        v161_11.join_into((v162_13).clone());
      }
      drop(v161_11_cursor);
      drop(v161_6);
      compose(&(v156_10),&(v161_11))
    };
    drop(v156_10);
    let v156_13: Space = unite(&(v156_8),&(v156_12));
    v155_12.join_into((v156_13).clone());
  }
  drop(v155_12_cursor);
  (v155_12).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v165_12 = Space::new();
  let mut v165_12_cursor = (*s0).read_zipper();
  for v165_12_byte in v165_12_cursor.child_mask().iter() {
    v165_12_cursor.descend_to_byte(v165_12_byte);
    let v165_12_tail = v165_12_cursor.make_map();
    v165_12_cursor.ascend(1);
    let v165_12_head = Path::from_slice(&[v165_12_byte]);
    let v166_2: Space = singleton(&(v165_12_head));
    let v166_3: Space = intersect(&(*CONSTANT_6),&(v166_2));
    let v166_4: Space = if has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
    drop(v166_3);
    let v166_5: Space = subtract(&(*CONSTANT_5),&(v166_4));
    drop(v166_4);
    let v166_8: Space = if (v166_5).is_empty() { Space::new() } else {
      let v167_6: Path = concat_path(&(*p0),&(v165_12_head));
      let mut v167_7 = Space::new();
      let mut v167_7_cursor = (v165_12_tail).read_zipper();
      for v167_7_byte in v167_7_cursor.child_mask().iter() {
        v167_7_cursor.descend_to_byte(v167_7_byte);
        let v167_7_tail = v167_7_cursor.make_map();
        v167_7_cursor.ascend(1);
        let v167_7_head = Path::from_slice(&[v167_7_byte]);
        let v168_2: Space = singleton(&(v167_7_head));
        let v168_3: Space = intersect(&(*CONSTANT_6),&(v168_2));
        let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
        drop(v168_3);
        let v168_5: Space = subtract(&(*CONSTANT_5),&(v168_4));
        drop(v168_4);
        let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
          let v169_6: Path = concat_path(&(v167_6),&(v167_7_head));
          let v169_7: Space = routine_30(c, &(v169_6), &(v167_7_tail), &(*s1));
          compose(&(v168_5),&(v169_7))
        };
        drop(v168_5);
        let v168_9: Space = intersect(&(*CONSTANT_6),&(v168_2));
        drop(v168_2);
        let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
        drop(v168_9);
        let v168_12: Space = if (v168_10).is_empty() { Space::new() } else {
          let v170_6: Path = concat_path(&(v167_6),&(v167_7_head));
          let v170_11: Space = routine_31(c, &(v170_6), &(v167_7_tail), &(*s1));
          drop(v170_6);
          compose(&(v168_10),&(v170_11))
        };
        drop(v168_10);
        let v168_13: Space = unite(&(v168_8),&(v168_12));
        v167_7.join_into((v168_13).clone());
      }
      drop(v167_7_cursor);
      compose(&(v166_5),&(v167_7))
    };
    drop(v166_5);
    let v166_9: Space = intersect(&(*CONSTANT_6),&(v166_2));
    drop(v166_2);
    let v166_10: Space = if has_head(&(v166_9)) { singleton(&[]) } else { Space::new() };
    drop(v166_9);
    let v166_12: Space = if (v166_10).is_empty() { Space::new() } else {
      let mut v171_11 = Space::new();
      let mut v171_11_cursor = (v165_12_tail).read_zipper();
      for v171_11_byte in v171_11_cursor.child_mask().iter() {
        v171_11_cursor.descend_to_byte(v171_11_byte);
        let v171_11_tail = v171_11_cursor.make_map();
        v171_11_cursor.ascend(1);
        let v171_11_head = Path::from_slice(&[v171_11_byte]);
        let v172_2: Space = singleton(&(v171_11_head));
        let v172_3: Space = intersect(&(*CONSTANT_6),&(v172_2));
        let v172_4: Space = if has_head(&(v172_3)) { singleton(&[]) } else { Space::new() };
        drop(v172_3);
        let v172_5: Space = subtract(&(*CONSTANT_5),&(v172_4));
        drop(v172_4);
        let v172_7: Space = if (v172_5).is_empty() { Space::new() } else {
          let v173_6: Space = routine_32(c, &(v171_11_head), &(v171_11_tail), &(*s1));
          compose(&(v172_5),&(v173_6))
        };
        drop(v172_5);
        let v172_8: Space = intersect(&(*CONSTANT_6),&(v172_2));
        drop(v172_2);
        let v172_9: Space = if has_head(&(v172_8)) { singleton(&[]) } else { Space::new() };
        drop(v172_8);
        let v172_11: Space = if (v172_9).is_empty() { Space::new() } else {
          let v174_10: Space = routine_33(c, &(v171_11_head), &(v171_11_tail), &(*s1));
          compose(&(v172_9),&(v174_10))
        };
        drop(v172_9);
        let v172_12: Space = unite(&(v172_7),&(v172_11));
        v171_11.join_into((v172_12).clone());
      }
      drop(v171_11_cursor);
      compose(&(v166_10),&(v171_11))
    };
    drop(v166_10);
    let v175_6: Path = concat_path(&(*p0),&(v165_12_head));
    let v166_13: Space = wrap(&(v166_12),&(v175_6));
    let v166_14: Space = unite(&(v166_8),&(v166_13));
    v165_12.join_into((v166_14).clone());
  }
  drop(v165_12_cursor);
  (v165_12).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v176_12 = Space::new();
  let mut v176_12_cursor = (*s0).read_zipper();
  for v176_12_byte in v176_12_cursor.child_mask().iter() {
    v176_12_cursor.descend_to_byte(v176_12_byte);
    let v176_12_tail = v176_12_cursor.make_map();
    v176_12_cursor.ascend(1);
    let v176_12_head = Path::from_slice(&[v176_12_byte]);
    let v177_2: Space = singleton(&(v176_12_head));
    let v177_3: Space = intersect(&(*CONSTANT_6),&(v177_2));
    let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
    drop(v177_3);
    let v177_5: Space = subtract(&(*CONSTANT_5),&(v177_4));
    drop(v177_4);
    let v177_7: Space = if (v177_5).is_empty() { Space::new() } else {
      let mut v178_6 = Space::new();
      let mut v178_6_cursor = (v176_12_tail).read_zipper();
      for v178_6_byte in v178_6_cursor.child_mask().iter() {
        v178_6_cursor.descend_to_byte(v178_6_byte);
        let v178_6_tail = v178_6_cursor.make_map();
        v178_6_cursor.ascend(1);
        let v178_6_head = Path::from_slice(&[v178_6_byte]);
        let v179_2: Space = singleton(&(v178_6_head));
        let v179_3: Space = intersect(&(*CONSTANT_6),&(v179_2));
        let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
        drop(v179_3);
        let v179_5: Space = subtract(&(*CONSTANT_5),&(v179_4));
        drop(v179_4);
        let v179_8: Space = if (v179_5).is_empty() { Space::new() } else {
          let v180_6: Path = concat_path(&(v176_12_head),&(v178_6_head));
          let v180_7: Space = routine_34(c, &(v180_6), &(v178_6_tail), &(*s1));
          compose(&(v179_5),&(v180_7))
        };
        drop(v179_5);
        let v179_9: Space = intersect(&(*CONSTANT_6),&(v179_2));
        drop(v179_2);
        let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
        drop(v179_9);
        let v179_12: Space = if (v179_10).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v176_12_head),&(v178_6_head));
          let v181_11: Space = routine_35(c, &(v181_6), &(v178_6_tail), &(*s1));
          drop(v181_6);
          compose(&(v179_10),&(v181_11))
        };
        drop(v179_10);
        let v179_13: Space = unite(&(v179_8),&(v179_12));
        v178_6.join_into((v179_13).clone());
      }
      drop(v178_6_cursor);
      compose(&(v177_5),&(v178_6))
    };
    drop(v177_5);
    let v177_8: Space = intersect(&(*CONSTANT_6),&(v177_2));
    drop(v177_2);
    let v177_9: Space = if has_head(&(v177_8)) { singleton(&[]) } else { Space::new() };
    drop(v177_8);
    let v177_11: Space = if (v177_9).is_empty() { Space::new() } else {
      let mut v182_10 = Space::new();
      let mut v182_10_cursor = (v176_12_tail).read_zipper();
      for v182_10_byte in v182_10_cursor.child_mask().iter() {
        v182_10_cursor.descend_to_byte(v182_10_byte);
        let v182_10_tail = v182_10_cursor.make_map();
        v182_10_cursor.ascend(1);
        let v182_10_head = Path::from_slice(&[v182_10_byte]);
        let v183_2: Space = singleton(&(v182_10_head));
        let v183_3: Space = intersect(&(*CONSTANT_6),&(v183_2));
        let v183_4: Space = if has_head(&(v183_3)) { singleton(&[]) } else { Space::new() };
        drop(v183_3);
        let v183_5: Space = subtract(&(*CONSTANT_5),&(v183_4));
        drop(v183_4);
        let v183_8: Space = if (v183_5).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v176_12_head),&(v182_10_head));
          let v184_7: Space = routine_34(c, &(v184_6), &(v182_10_tail), &(*s1));
          compose(&(v183_5),&(v184_7))
        };
        drop(v183_5);
        let v183_9: Space = intersect(&(*CONSTANT_6),&(v183_2));
        drop(v183_2);
        let v183_10: Space = if has_head(&(v183_9)) { singleton(&[]) } else { Space::new() };
        drop(v183_9);
        let v183_12: Space = if (v183_10).is_empty() { Space::new() } else {
          let v185_6: Path = concat_path(&(v176_12_head),&(v182_10_head));
          let v185_11: Space = routine_36(c, &(v185_6), &(v182_10_tail), &(*s1));
          drop(v185_6);
          compose(&(v183_10),&(v185_11))
        };
        drop(v183_10);
        let v183_13: Space = unite(&(v183_8),&(v183_12));
        v182_10.join_into((v183_13).clone());
      }
      drop(v182_10_cursor);
      compose(&(v177_9),&(v182_10))
    };
    drop(v177_9);
    let v177_12: Space = unite(&(v177_7),&(v177_11));
    v176_12.join_into((v177_12).clone());
  }
  drop(v176_12_cursor);
  let v176_13: Space = wrap(&(v176_12),&(*p0));
  (v176_13).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v186_12 = Space::new();
  let mut v186_12_cursor = (*s0).read_zipper();
  for v186_12_byte in v186_12_cursor.child_mask().iter() {
    v186_12_cursor.descend_to_byte(v186_12_byte);
    let v186_12_tail = v186_12_cursor.make_map();
    v186_12_cursor.ascend(1);
    let v186_12_head = Path::from_slice(&[v186_12_byte]);
    let v187_2: Space = singleton(&(v186_12_head));
    let v187_3: Space = intersect(&(*CONSTANT_6),&(v187_2));
    let v187_4: Space = if has_head(&(v187_3)) { singleton(&[]) } else { Space::new() };
    drop(v187_3);
    let v187_5: Space = subtract(&(*CONSTANT_5),&(v187_4));
    drop(v187_4);
    let v187_8: Space = if (v187_5).is_empty() { Space::new() } else {
      let v188_6: Path = concat_path(&(*p0),&(v186_12_head));
      let mut v188_7 = Space::new();
      let mut v188_7_cursor = (v186_12_tail).read_zipper();
      for v188_7_byte in v188_7_cursor.child_mask().iter() {
        v188_7_cursor.descend_to_byte(v188_7_byte);
        let v188_7_tail = v188_7_cursor.make_map();
        v188_7_cursor.ascend(1);
        let v188_7_head = Path::from_slice(&[v188_7_byte]);
        let v189_2: Space = singleton(&(v188_7_head));
        let v189_3: Space = intersect(&(*CONSTANT_6),&(v189_2));
        let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
        drop(v189_3);
        let v189_5: Space = subtract(&(*CONSTANT_5),&(v189_4));
        drop(v189_4);
        let v189_8: Space = if (v189_5).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v188_6),&(v188_7_head));
          let v190_7: Space = routine_37(c, &(v190_6), &(v188_7_tail), &(*s1));
          compose(&(v189_5),&(v190_7))
        };
        drop(v189_5);
        let v189_9: Space = intersect(&(*CONSTANT_6),&(v189_2));
        drop(v189_2);
        let v189_10: Space = if has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
        drop(v189_9);
        let v189_12: Space = if (v189_10).is_empty() { Space::new() } else {
          let v191_6: Path = concat_path(&(v188_6),&(v188_7_head));
          let v191_11: Space = routine_38(c, &(v191_6), &(v188_7_tail), &(*s1));
          drop(v191_6);
          compose(&(v189_10),&(v191_11))
        };
        drop(v189_10);
        let v189_13: Space = unite(&(v189_8),&(v189_12));
        v188_7.join_into((v189_13).clone());
      }
      drop(v188_7_cursor);
      compose(&(v187_5),&(v188_7))
    };
    drop(v187_5);
    let v187_9: Space = intersect(&(*CONSTANT_6),&(v187_2));
    drop(v187_2);
    let v187_10: Space = if has_head(&(v187_9)) { singleton(&[]) } else { Space::new() };
    drop(v187_9);
    let v187_12: Space = if (v187_10).is_empty() { Space::new() } else {
      let v192_6: Path = concat_path(&(*p0),&(v186_12_head));
      let mut v192_11 = Space::new();
      let mut v192_11_cursor = (v186_12_tail).read_zipper();
      for v192_11_byte in v192_11_cursor.child_mask().iter() {
        v192_11_cursor.descend_to_byte(v192_11_byte);
        let v192_11_tail = v192_11_cursor.make_map();
        v192_11_cursor.ascend(1);
        let v192_11_head = Path::from_slice(&[v192_11_byte]);
        let v193_2: Space = singleton(&(v192_11_head));
        let v193_3: Space = intersect(&(*CONSTANT_6),&(v193_2));
        let v193_4: Space = if has_head(&(v193_3)) { singleton(&[]) } else { Space::new() };
        drop(v193_3);
        let v193_5: Space = subtract(&(*CONSTANT_5),&(v193_4));
        drop(v193_4);
        let v193_8: Space = if (v193_5).is_empty() { Space::new() } else {
          let v194_6: Path = concat_path(&(v192_6),&(v192_11_head));
          let v194_7: Space = routine_37(c, &(v194_6), &(v192_11_tail), &(*s1));
          compose(&(v193_5),&(v194_7))
        };
        drop(v193_5);
        let v193_9: Space = intersect(&(*CONSTANT_6),&(v193_2));
        drop(v193_2);
        let v193_10: Space = if has_head(&(v193_9)) { singleton(&[]) } else { Space::new() };
        drop(v193_9);
        let v193_12: Space = if (v193_10).is_empty() { Space::new() } else {
          let v195_6: Path = concat_path(&(v192_6),&(v192_11_head));
          let v195_11: Space = routine_4(c, &(v195_6), &(v192_11_tail), &(*s1));
          drop(v195_6);
          compose(&(v193_10),&(v195_11))
        };
        drop(v193_10);
        let v193_13: Space = unite(&(v193_8),&(v193_12));
        v192_11.join_into((v193_13).clone());
      }
      drop(v192_11_cursor);
      drop(v192_6);
      compose(&(v187_10),&(v192_11))
    };
    drop(v187_10);
    let v187_13: Space = unite(&(v187_8),&(v187_12));
    v186_12.join_into((v187_13).clone());
  }
  drop(v186_12_cursor);
  (v186_12).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v196_12 = Space::new();
  let mut v196_12_cursor = (*s0).read_zipper();
  for v196_12_byte in v196_12_cursor.child_mask().iter() {
    v196_12_cursor.descend_to_byte(v196_12_byte);
    let v196_12_tail = v196_12_cursor.make_map();
    v196_12_cursor.ascend(1);
    let v196_12_head = Path::from_slice(&[v196_12_byte]);
    let v197_2: Space = singleton(&(v196_12_head));
    let v197_3: Space = intersect(&(*CONSTANT_6),&(v197_2));
    let v197_4: Space = if has_head(&(v197_3)) { singleton(&[]) } else { Space::new() };
    drop(v197_3);
    let v197_5: Space = subtract(&(*CONSTANT_5),&(v197_4));
    drop(v197_4);
    let v197_8: Space = if (v197_5).is_empty() { Space::new() } else {
      let v198_6: Path = concat_path(&(*p0),&(v196_12_head));
      let mut v198_7 = Space::new();
      let mut v198_7_cursor = (v196_12_tail).read_zipper();
      for v198_7_byte in v198_7_cursor.child_mask().iter() {
        v198_7_cursor.descend_to_byte(v198_7_byte);
        let v198_7_tail = v198_7_cursor.make_map();
        v198_7_cursor.ascend(1);
        let v198_7_head = Path::from_slice(&[v198_7_byte]);
        let v199_2: Space = singleton(&(v198_7_head));
        let v199_3: Space = intersect(&(*CONSTANT_6),&(v199_2));
        let v199_4: Space = if has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
        drop(v199_3);
        let v199_5: Space = subtract(&(*CONSTANT_5),&(v199_4));
        drop(v199_4);
        let v199_8: Space = if (v199_5).is_empty() { Space::new() } else {
          let v200_6: Path = concat_path(&(v198_6),&(v198_7_head));
          let v200_7: Space = routine_37(c, &(v200_6), &(v198_7_tail), &(*s1));
          compose(&(v199_5),&(v200_7))
        };
        drop(v199_5);
        let v199_9: Space = intersect(&(*CONSTANT_6),&(v199_2));
        drop(v199_2);
        let v199_10: Space = if has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
        drop(v199_9);
        let v199_12: Space = if (v199_10).is_empty() { Space::new() } else {
          let v201_6: Path = concat_path(&(v198_6),&(v198_7_head));
          let v201_11: Space = routine_38(c, &(v201_6), &(v198_7_tail), &(*s1));
          drop(v201_6);
          compose(&(v199_10),&(v201_11))
        };
        drop(v199_10);
        let v199_13: Space = unite(&(v199_8),&(v199_12));
        v198_7.join_into((v199_13).clone());
      }
      drop(v198_7_cursor);
      compose(&(v197_5),&(v198_7))
    };
    drop(v197_5);
    let v197_9: Space = intersect(&(*CONSTANT_6),&(v197_2));
    drop(v197_2);
    let v197_10: Space = if has_head(&(v197_9)) { singleton(&[]) } else { Space::new() };
    drop(v197_9);
    let v197_12: Space = if (v197_10).is_empty() { Space::new() } else {
      let mut v202_11 = Space::new();
      let mut v202_11_cursor = (v196_12_tail).read_zipper();
      for v202_11_byte in v202_11_cursor.child_mask().iter() {
        v202_11_cursor.descend_to_byte(v202_11_byte);
        let v202_11_tail = v202_11_cursor.make_map();
        v202_11_cursor.ascend(1);
        let v202_11_head = Path::from_slice(&[v202_11_byte]);
        let v203_2: Space = singleton(&(v202_11_head));
        let v203_3: Space = intersect(&(*CONSTANT_6),&(v203_2));
        let v203_4: Space = if has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
        drop(v203_3);
        let v203_5: Space = subtract(&(*CONSTANT_5),&(v203_4));
        drop(v203_4);
        let v203_7: Space = if (v203_5).is_empty() { Space::new() } else {
          let v204_6: Space = routine_16(c, &(v202_11_head), &(v202_11_tail), &(*s1));
          compose(&(v203_5),&(v204_6))
        };
        drop(v203_5);
        let v203_8: Space = intersect(&(*CONSTANT_6),&(v203_2));
        drop(v203_2);
        let v203_9: Space = if has_head(&(v203_8)) { singleton(&[]) } else { Space::new() };
        drop(v203_8);
        let v203_11: Space = if (v203_9).is_empty() { Space::new() } else {
          let v205_10: Space = routine_17(c, &(v202_11_head), &(v202_11_tail), &(*s1));
          compose(&(v203_9),&(v205_10))
        };
        drop(v203_9);
        let v203_12: Space = unite(&(v203_7),&(v203_11));
        v202_11.join_into((v203_12).clone());
      }
      drop(v202_11_cursor);
      compose(&(v197_10),&(v202_11))
    };
    drop(v197_10);
    let v206_6: Path = concat_path(&(*p0),&(v196_12_head));
    let v197_13: Space = wrap(&(v197_12),&(v206_6));
    let v197_14: Space = unite(&(v197_8),&(v197_13));
    v196_12.join_into((v197_14).clone());
  }
  drop(v196_12_cursor);
  (v196_12).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v207_12 = Space::new();
  let mut v207_12_cursor = (*s0).read_zipper();
  for v207_12_byte in v207_12_cursor.child_mask().iter() {
    v207_12_cursor.descend_to_byte(v207_12_byte);
    let v207_12_tail = v207_12_cursor.make_map();
    v207_12_cursor.ascend(1);
    let v207_12_head = Path::from_slice(&[v207_12_byte]);
    let v208_2: Space = singleton(&(v207_12_head));
    let v208_3: Space = intersect(&(*CONSTANT_6),&(v208_2));
    let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
    drop(v208_3);
    let v208_5: Space = subtract(&(*CONSTANT_5),&(v208_4));
    drop(v208_4);
    let v208_8: Space = if (v208_5).is_empty() { Space::new() } else {
      let v209_6: Path = concat_path(&(*p0),&(v207_12_head));
      let mut v209_7 = Space::new();
      let mut v209_7_cursor = (v207_12_tail).read_zipper();
      for v209_7_byte in v209_7_cursor.child_mask().iter() {
        v209_7_cursor.descend_to_byte(v209_7_byte);
        let v209_7_tail = v209_7_cursor.make_map();
        v209_7_cursor.ascend(1);
        let v209_7_head = Path::from_slice(&[v209_7_byte]);
        let v210_2: Space = singleton(&(v209_7_head));
        let v210_3: Space = intersect(&(*CONSTANT_6),&(v210_2));
        let v210_4: Space = if has_head(&(v210_3)) { singleton(&[]) } else { Space::new() };
        drop(v210_3);
        let v210_5: Space = subtract(&(*CONSTANT_5),&(v210_4));
        drop(v210_4);
        let v210_8: Space = if (v210_5).is_empty() { Space::new() } else {
          let v211_6: Path = concat_path(&(v209_6),&(v209_7_head));
          let v211_7: Space = routine_39(c, &(v211_6), &(v209_7_tail), &(*s1));
          compose(&(v210_5),&(v211_7))
        };
        drop(v210_5);
        let v210_9: Space = intersect(&(*CONSTANT_6),&(v210_2));
        drop(v210_2);
        let v210_10: Space = if has_head(&(v210_9)) { singleton(&[]) } else { Space::new() };
        drop(v210_9);
        let v210_12: Space = if (v210_10).is_empty() { Space::new() } else {
          let v212_6: Path = concat_path(&(v209_6),&(v209_7_head));
          let v212_11: Space = routine_40(c, &(v212_6), &(v209_7_tail), &(*s1));
          drop(v212_6);
          compose(&(v210_10),&(v212_11))
        };
        drop(v210_10);
        let v210_13: Space = unite(&(v210_8),&(v210_12));
        v209_7.join_into((v210_13).clone());
      }
      drop(v209_7_cursor);
      compose(&(v208_5),&(v209_7))
    };
    drop(v208_5);
    let v208_9: Space = intersect(&(*CONSTANT_6),&(v208_2));
    drop(v208_2);
    let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
    drop(v208_9);
    let v208_12: Space = if (v208_10).is_empty() { Space::new() } else {
      let v213_6: Path = concat_path(&(*p0),&(v207_12_head));
      let mut v213_11 = Space::new();
      let mut v213_11_cursor = (v207_12_tail).read_zipper();
      for v213_11_byte in v213_11_cursor.child_mask().iter() {
        v213_11_cursor.descend_to_byte(v213_11_byte);
        let v213_11_tail = v213_11_cursor.make_map();
        v213_11_cursor.ascend(1);
        let v213_11_head = Path::from_slice(&[v213_11_byte]);
        let v214_2: Space = singleton(&(v213_11_head));
        let v214_3: Space = intersect(&(*CONSTANT_6),&(v214_2));
        let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
        drop(v214_3);
        let v214_5: Space = subtract(&(*CONSTANT_5),&(v214_4));
        drop(v214_4);
        let v214_8: Space = if (v214_5).is_empty() { Space::new() } else {
          let v215_6: Path = concat_path(&(v213_6),&(v213_11_head));
          let v215_7: Space = routine_39(c, &(v215_6), &(v213_11_tail), &(*s1));
          compose(&(v214_5),&(v215_7))
        };
        drop(v214_5);
        let v214_9: Space = intersect(&(*CONSTANT_6),&(v214_2));
        drop(v214_2);
        let v214_10: Space = if has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
        drop(v214_9);
        let v214_12: Space = if (v214_10).is_empty() { Space::new() } else {
          let v216_6: Path = concat_path(&(v213_6),&(v213_11_head));
          let v216_11: Space = routine_20(c, &(v216_6), &(v213_11_tail), &(*s1));
          drop(v216_6);
          compose(&(v214_10),&(v216_11))
        };
        drop(v214_10);
        let v214_13: Space = unite(&(v214_8),&(v214_12));
        v213_11.join_into((v214_13).clone());
      }
      drop(v213_11_cursor);
      drop(v213_6);
      compose(&(v208_10),&(v213_11))
    };
    drop(v208_10);
    let v208_13: Space = unite(&(v208_8),&(v208_12));
    v207_12.join_into((v208_13).clone());
  }
  drop(v207_12_cursor);
  (v207_12).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v217_7: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v217_9: Space = unwrap(&(v217_7),&(*CONSTANT_4));
  drop(v217_7);
  let v217_10: Space = unwrap(&(v217_9),&(*p0));
  drop(v217_9);
  let mut v217_15 = Space::new();
  let mut v217_15_cursor = (*s0).read_zipper();
  for v217_15_byte in v217_15_cursor.child_mask().iter() {
    v217_15_cursor.descend_to_byte(v217_15_byte);
    let v217_15_tail = v217_15_cursor.make_map();
    v217_15_cursor.ascend(1);
    let v217_15_head = Path::from_slice(&[v217_15_byte]);
    let v218_2: Space = singleton(&(v217_15_head));
    let v218_3: Space = intersect(&(*CONSTANT_6),&(v218_2));
    let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
    drop(v218_3);
    let v218_5: Space = subtract(&(*CONSTANT_5),&(v218_4));
    drop(v218_4);
    let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
      let v219_6: Path = concat_path(&(*p0),&(v217_15_head));
      let mut v219_7 = Space::new();
      let mut v219_7_cursor = (v217_15_tail).read_zipper();
      for v219_7_byte in v219_7_cursor.child_mask().iter() {
        v219_7_cursor.descend_to_byte(v219_7_byte);
        let v219_7_tail = v219_7_cursor.make_map();
        v219_7_cursor.ascend(1);
        let v219_7_head = Path::from_slice(&[v219_7_byte]);
        let v220_2: Space = singleton(&(v219_7_head));
        let v220_3: Space = intersect(&(*CONSTANT_6),&(v220_2));
        let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
        drop(v220_3);
        let v220_5: Space = subtract(&(*CONSTANT_5),&(v220_4));
        drop(v220_4);
        let v220_8: Space = if (v220_5).is_empty() { Space::new() } else {
          let v221_6: Path = concat_path(&(v219_6),&(v219_7_head));
          let v221_7: Space = routine_39(c, &(v221_6), &(v219_7_tail), &(*s1));
          compose(&(v220_5),&(v221_7))
        };
        drop(v220_5);
        let v220_9: Space = intersect(&(*CONSTANT_6),&(v220_2));
        drop(v220_2);
        let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
        drop(v220_9);
        let v220_12: Space = if (v220_10).is_empty() { Space::new() } else {
          let v222_6: Path = concat_path(&(v219_6),&(v219_7_head));
          let v222_11: Space = routine_40(c, &(v222_6), &(v219_7_tail), &(*s1));
          drop(v222_6);
          compose(&(v220_10),&(v222_11))
        };
        drop(v220_10);
        let v220_13: Space = unite(&(v220_8),&(v220_12));
        v219_7.join_into((v220_13).clone());
      }
      drop(v219_7_cursor);
      drop(v219_6);
      compose(&(v218_5),&(v219_7))
    };
    drop(v218_5);
    let v218_9: Space = intersect(&(*CONSTANT_6),&(v218_2));
    drop(v218_2);
    let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
    drop(v218_9);
    let v218_13: Space = if (v218_10).is_empty() { Space::new() } else {
      let v223_11: Space = unwrap(&(v217_10),&(v217_15_head));
      let v223_12: Space = subtract(&(v223_11),&(*CONSTANT_5));
      drop(v223_11);
      compose(&(v218_10),&(v223_12))
    };
    drop(v218_10);
    let v218_14: Space = unite(&(v218_8),&(v218_13));
    drop(v218_13);
    v217_15.join_into((v218_14).clone());
  }
  drop(v217_15_cursor);
  drop(v217_10);
  (v217_15).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v224_12 = Space::new();
  let mut v224_12_cursor = (*s0).read_zipper();
  for v224_12_byte in v224_12_cursor.child_mask().iter() {
    v224_12_cursor.descend_to_byte(v224_12_byte);
    let v224_12_tail = v224_12_cursor.make_map();
    v224_12_cursor.ascend(1);
    let v224_12_head = Path::from_slice(&[v224_12_byte]);
    let v225_2: Space = singleton(&(v224_12_head));
    let v225_3: Space = intersect(&(*CONSTANT_6),&(v225_2));
    let v225_4: Space = if has_head(&(v225_3)) { singleton(&[]) } else { Space::new() };
    drop(v225_3);
    let v225_5: Space = subtract(&(*CONSTANT_5),&(v225_4));
    drop(v225_4);
    let v225_8: Space = if (v225_5).is_empty() { Space::new() } else {
      let v226_6: Path = concat_path(&(*p0),&(v224_12_head));
      let mut v226_7 = Space::new();
      let mut v226_7_cursor = (v224_12_tail).read_zipper();
      for v226_7_byte in v226_7_cursor.child_mask().iter() {
        v226_7_cursor.descend_to_byte(v226_7_byte);
        let v226_7_tail = v226_7_cursor.make_map();
        v226_7_cursor.ascend(1);
        let v226_7_head = Path::from_slice(&[v226_7_byte]);
        let v227_2: Space = singleton(&(v226_7_head));
        let v227_3: Space = intersect(&(*CONSTANT_6),&(v227_2));
        let v227_4: Space = if has_head(&(v227_3)) { singleton(&[]) } else { Space::new() };
        drop(v227_3);
        let v227_5: Space = subtract(&(*CONSTANT_5),&(v227_4));
        drop(v227_4);
        let v227_8: Space = if (v227_5).is_empty() { Space::new() } else {
          let v228_6: Path = concat_path(&(v226_6),&(v226_7_head));
          let v228_7: Space = routine_41(c, &(v228_6), &(v226_7_tail), &(*s1));
          compose(&(v227_5),&(v228_7))
        };
        drop(v227_5);
        let v227_9: Space = intersect(&(*CONSTANT_6),&(v227_2));
        drop(v227_2);
        let v227_10: Space = if has_head(&(v227_9)) { singleton(&[]) } else { Space::new() };
        drop(v227_9);
        let v227_12: Space = if (v227_10).is_empty() { Space::new() } else {
          let v229_6: Path = concat_path(&(v226_6),&(v226_7_head));
          let v229_11: Space = routine_42(c, &(v229_6), &(v226_7_tail), &(*s1));
          drop(v229_6);
          compose(&(v227_10),&(v229_11))
        };
        drop(v227_10);
        let v227_13: Space = unite(&(v227_8),&(v227_12));
        v226_7.join_into((v227_13).clone());
      }
      drop(v226_7_cursor);
      compose(&(v225_5),&(v226_7))
    };
    drop(v225_5);
    let v225_9: Space = intersect(&(*CONSTANT_6),&(v225_2));
    drop(v225_2);
    let v225_10: Space = if has_head(&(v225_9)) { singleton(&[]) } else { Space::new() };
    drop(v225_9);
    let v225_12: Space = if (v225_10).is_empty() { Space::new() } else {
      let v230_6: Path = concat_path(&(*p0),&(v224_12_head));
      let mut v230_11 = Space::new();
      let mut v230_11_cursor = (v224_12_tail).read_zipper();
      for v230_11_byte in v230_11_cursor.child_mask().iter() {
        v230_11_cursor.descend_to_byte(v230_11_byte);
        let v230_11_tail = v230_11_cursor.make_map();
        v230_11_cursor.ascend(1);
        let v230_11_head = Path::from_slice(&[v230_11_byte]);
        let v231_2: Space = singleton(&(v230_11_head));
        let v231_3: Space = intersect(&(*CONSTANT_6),&(v231_2));
        let v231_4: Space = if has_head(&(v231_3)) { singleton(&[]) } else { Space::new() };
        drop(v231_3);
        let v231_5: Space = subtract(&(*CONSTANT_5),&(v231_4));
        drop(v231_4);
        let v231_8: Space = if (v231_5).is_empty() { Space::new() } else {
          let v232_6: Path = concat_path(&(v230_6),&(v230_11_head));
          let v232_7: Space = routine_41(c, &(v232_6), &(v230_11_tail), &(*s1));
          compose(&(v231_5),&(v232_7))
        };
        drop(v231_5);
        let v231_9: Space = intersect(&(*CONSTANT_6),&(v231_2));
        drop(v231_2);
        let v231_10: Space = if has_head(&(v231_9)) { singleton(&[]) } else { Space::new() };
        drop(v231_9);
        let v231_12: Space = if (v231_10).is_empty() { Space::new() } else {
          let v233_6: Path = concat_path(&(v230_6),&(v230_11_head));
          let v233_11: Space = routine_20(c, &(v233_6), &(v230_11_tail), &(*s1));
          drop(v233_6);
          compose(&(v231_10),&(v233_11))
        };
        drop(v231_10);
        let v231_13: Space = unite(&(v231_8),&(v231_12));
        v230_11.join_into((v231_13).clone());
      }
      drop(v230_11_cursor);
      drop(v230_6);
      compose(&(v225_10),&(v230_11))
    };
    drop(v225_10);
    let v225_13: Space = unite(&(v225_8),&(v225_12));
    v224_12.join_into((v225_13).clone());
  }
  drop(v224_12_cursor);
  (v224_12).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v234_7: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v234_9: Space = unwrap(&(v234_7),&(*CONSTANT_4));
  drop(v234_7);
  let v234_10: Space = unwrap(&(v234_9),&(*p0));
  drop(v234_9);
  let mut v234_15 = Space::new();
  let mut v234_15_cursor = (*s0).read_zipper();
  for v234_15_byte in v234_15_cursor.child_mask().iter() {
    v234_15_cursor.descend_to_byte(v234_15_byte);
    let v234_15_tail = v234_15_cursor.make_map();
    v234_15_cursor.ascend(1);
    let v234_15_head = Path::from_slice(&[v234_15_byte]);
    let v235_2: Space = singleton(&(v234_15_head));
    let v235_3: Space = intersect(&(*CONSTANT_6),&(v235_2));
    let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
    drop(v235_3);
    let v235_5: Space = subtract(&(*CONSTANT_5),&(v235_4));
    drop(v235_4);
    let v235_8: Space = if (v235_5).is_empty() { Space::new() } else {
      let v236_6: Path = concat_path(&(*p0),&(v234_15_head));
      let mut v236_7 = Space::new();
      let mut v236_7_cursor = (v234_15_tail).read_zipper();
      for v236_7_byte in v236_7_cursor.child_mask().iter() {
        v236_7_cursor.descend_to_byte(v236_7_byte);
        let v236_7_tail = v236_7_cursor.make_map();
        v236_7_cursor.ascend(1);
        let v236_7_head = Path::from_slice(&[v236_7_byte]);
        let v237_2: Space = singleton(&(v236_7_head));
        let v237_3: Space = intersect(&(*CONSTANT_6),&(v237_2));
        let v237_4: Space = if has_head(&(v237_3)) { singleton(&[]) } else { Space::new() };
        drop(v237_3);
        let v237_5: Space = subtract(&(*CONSTANT_5),&(v237_4));
        drop(v237_4);
        let v237_8: Space = if (v237_5).is_empty() { Space::new() } else {
          let v238_6: Path = concat_path(&(v236_6),&(v236_7_head));
          let v238_7: Space = routine_41(c, &(v238_6), &(v236_7_tail), &(*s1));
          compose(&(v237_5),&(v238_7))
        };
        drop(v237_5);
        let v237_9: Space = intersect(&(*CONSTANT_6),&(v237_2));
        drop(v237_2);
        let v237_10: Space = if has_head(&(v237_9)) { singleton(&[]) } else { Space::new() };
        drop(v237_9);
        let v237_12: Space = if (v237_10).is_empty() { Space::new() } else {
          let v239_6: Path = concat_path(&(v236_6),&(v236_7_head));
          let v239_11: Space = routine_42(c, &(v239_6), &(v236_7_tail), &(*s1));
          drop(v239_6);
          compose(&(v237_10),&(v239_11))
        };
        drop(v237_10);
        let v237_13: Space = unite(&(v237_8),&(v237_12));
        v236_7.join_into((v237_13).clone());
      }
      drop(v236_7_cursor);
      drop(v236_6);
      compose(&(v235_5),&(v236_7))
    };
    drop(v235_5);
    let v235_9: Space = intersect(&(*CONSTANT_6),&(v235_2));
    drop(v235_2);
    let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
    drop(v235_9);
    let v235_13: Space = if (v235_10).is_empty() { Space::new() } else {
      let v240_11: Space = unwrap(&(v234_10),&(v234_15_head));
      let v240_12: Space = subtract(&(v240_11),&(*CONSTANT_5));
      drop(v240_11);
      compose(&(v235_10),&(v240_12))
    };
    drop(v235_10);
    let v235_14: Space = unite(&(v235_8),&(v235_13));
    drop(v235_13);
    v234_15.join_into((v235_14).clone());
  }
  drop(v234_15_cursor);
  drop(v234_10);
  (v234_15).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v241_4: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v241_6: Space = unwrap(&(v241_4),&(*CONSTANT_4));
  drop(v241_4);
  let v241_7: Space = unwrap(&(v241_6),&(*p0));
  drop(v241_6);
  let v241_9: Space = subtract(&(v241_7),&(*CONSTANT_5));
  drop(v241_7);
  (v241_9).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v242_12 = Space::new();
  let mut v242_12_cursor = (*s0).read_zipper();
  for v242_12_byte in v242_12_cursor.child_mask().iter() {
    v242_12_cursor.descend_to_byte(v242_12_byte);
    let v242_12_tail = v242_12_cursor.make_map();
    v242_12_cursor.ascend(1);
    let v242_12_head = Path::from_slice(&[v242_12_byte]);
    let v243_2: Space = singleton(&(v242_12_head));
    let v243_3: Space = intersect(&(*CONSTANT_6),&(v243_2));
    let v243_4: Space = if has_head(&(v243_3)) { singleton(&[]) } else { Space::new() };
    drop(v243_3);
    let v243_5: Space = subtract(&(*CONSTANT_5),&(v243_4));
    drop(v243_4);
    let v243_8: Space = if (v243_5).is_empty() { Space::new() } else {
      let v244_6: Path = concat_path(&(*p0),&(v242_12_head));
      let mut v244_7 = Space::new();
      let mut v244_7_cursor = (v242_12_tail).read_zipper();
      for v244_7_byte in v244_7_cursor.child_mask().iter() {
        v244_7_cursor.descend_to_byte(v244_7_byte);
        let v244_7_tail = v244_7_cursor.make_map();
        v244_7_cursor.ascend(1);
        let v244_7_head = Path::from_slice(&[v244_7_byte]);
        let v245_2: Space = singleton(&(v244_7_head));
        let v245_3: Space = intersect(&(*CONSTANT_6),&(v245_2));
        let v245_4: Space = if has_head(&(v245_3)) { singleton(&[]) } else { Space::new() };
        drop(v245_3);
        let v245_5: Space = subtract(&(*CONSTANT_5),&(v245_4));
        drop(v245_4);
        let v245_8: Space = if (v245_5).is_empty() { Space::new() } else {
          let v246_6: Path = concat_path(&(v244_6),&(v244_7_head));
          let v246_7: Space = routine_43(c, &(v246_6), &(v244_7_tail), &(*s1));
          compose(&(v245_5),&(v246_7))
        };
        drop(v245_5);
        let v245_9: Space = intersect(&(*CONSTANT_6),&(v245_2));
        drop(v245_2);
        let v245_10: Space = if has_head(&(v245_9)) { singleton(&[]) } else { Space::new() };
        drop(v245_9);
        let v245_12: Space = if (v245_10).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v244_6),&(v244_7_head));
          let v247_11: Space = routine_44(c, &(v247_6), &(v244_7_tail), &(*s1));
          drop(v247_6);
          compose(&(v245_10),&(v247_11))
        };
        drop(v245_10);
        let v245_13: Space = unite(&(v245_8),&(v245_12));
        v244_7.join_into((v245_13).clone());
      }
      drop(v244_7_cursor);
      compose(&(v243_5),&(v244_7))
    };
    drop(v243_5);
    let v243_9: Space = intersect(&(*CONSTANT_6),&(v243_2));
    drop(v243_2);
    let v243_10: Space = if has_head(&(v243_9)) { singleton(&[]) } else { Space::new() };
    drop(v243_9);
    let v243_12: Space = if (v243_10).is_empty() { Space::new() } else {
      let v248_6: Path = concat_path(&(*p0),&(v242_12_head));
      let mut v248_11 = Space::new();
      let mut v248_11_cursor = (v242_12_tail).read_zipper();
      for v248_11_byte in v248_11_cursor.child_mask().iter() {
        v248_11_cursor.descend_to_byte(v248_11_byte);
        let v248_11_tail = v248_11_cursor.make_map();
        v248_11_cursor.ascend(1);
        let v248_11_head = Path::from_slice(&[v248_11_byte]);
        let v249_2: Space = singleton(&(v248_11_head));
        let v249_3: Space = intersect(&(*CONSTANT_6),&(v249_2));
        let v249_4: Space = if has_head(&(v249_3)) { singleton(&[]) } else { Space::new() };
        drop(v249_3);
        let v249_5: Space = subtract(&(*CONSTANT_5),&(v249_4));
        drop(v249_4);
        let v249_8: Space = if (v249_5).is_empty() { Space::new() } else {
          let v250_6: Path = concat_path(&(v248_6),&(v248_11_head));
          let v250_7: Space = routine_43(c, &(v250_6), &(v248_11_tail), &(*s1));
          compose(&(v249_5),&(v250_7))
        };
        drop(v249_5);
        let v249_9: Space = intersect(&(*CONSTANT_6),&(v249_2));
        drop(v249_2);
        let v249_10: Space = if has_head(&(v249_9)) { singleton(&[]) } else { Space::new() };
        drop(v249_9);
        let v249_12: Space = if (v249_10).is_empty() { Space::new() } else {
          let v251_6: Path = concat_path(&(v248_6),&(v248_11_head));
          let v251_11: Space = routine_7(c, &(v251_6), &(v248_11_tail), &(*s1));
          drop(v251_6);
          compose(&(v249_10),&(v251_11))
        };
        drop(v249_10);
        let v249_13: Space = unite(&(v249_8),&(v249_12));
        v248_11.join_into((v249_13).clone());
      }
      drop(v248_11_cursor);
      drop(v248_6);
      compose(&(v243_10),&(v248_11))
    };
    drop(v243_10);
    let v243_13: Space = unite(&(v243_8),&(v243_12));
    v242_12.join_into((v243_13).clone());
  }
  drop(v242_12_cursor);
  (v242_12).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v252_12 = Space::new();
  let mut v252_12_cursor = (*s0).read_zipper();
  for v252_12_byte in v252_12_cursor.child_mask().iter() {
    v252_12_cursor.descend_to_byte(v252_12_byte);
    let v252_12_tail = v252_12_cursor.make_map();
    v252_12_cursor.ascend(1);
    let v252_12_head = Path::from_slice(&[v252_12_byte]);
    let v253_2: Space = singleton(&(v252_12_head));
    let v253_3: Space = intersect(&(*CONSTANT_6),&(v253_2));
    let v253_4: Space = if has_head(&(v253_3)) { singleton(&[]) } else { Space::new() };
    drop(v253_3);
    let v253_5: Space = subtract(&(*CONSTANT_5),&(v253_4));
    drop(v253_4);
    let v253_8: Space = if (v253_5).is_empty() { Space::new() } else {
      let v254_6: Path = concat_path(&(*p0),&(v252_12_head));
      let mut v254_7 = Space::new();
      let mut v254_7_cursor = (v252_12_tail).read_zipper();
      for v254_7_byte in v254_7_cursor.child_mask().iter() {
        v254_7_cursor.descend_to_byte(v254_7_byte);
        let v254_7_tail = v254_7_cursor.make_map();
        v254_7_cursor.ascend(1);
        let v254_7_head = Path::from_slice(&[v254_7_byte]);
        let v255_2: Space = singleton(&(v254_7_head));
        let v255_3: Space = intersect(&(*CONSTANT_6),&(v255_2));
        let v255_4: Space = if has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
        drop(v255_3);
        let v255_5: Space = subtract(&(*CONSTANT_5),&(v255_4));
        drop(v255_4);
        let v255_8: Space = if (v255_5).is_empty() { Space::new() } else {
          let v256_6: Path = concat_path(&(v254_6),&(v254_7_head));
          let v256_7: Space = routine_43(c, &(v256_6), &(v254_7_tail), &(*s1));
          compose(&(v255_5),&(v256_7))
        };
        drop(v255_5);
        let v255_9: Space = intersect(&(*CONSTANT_6),&(v255_2));
        drop(v255_2);
        let v255_10: Space = if has_head(&(v255_9)) { singleton(&[]) } else { Space::new() };
        drop(v255_9);
        let v255_12: Space = if (v255_10).is_empty() { Space::new() } else {
          let v257_6: Path = concat_path(&(v254_6),&(v254_7_head));
          let v257_11: Space = routine_44(c, &(v257_6), &(v254_7_tail), &(*s1));
          drop(v257_6);
          compose(&(v255_10),&(v257_11))
        };
        drop(v255_10);
        let v255_13: Space = unite(&(v255_8),&(v255_12));
        v254_7.join_into((v255_13).clone());
      }
      drop(v254_7_cursor);
      compose(&(v253_5),&(v254_7))
    };
    drop(v253_5);
    let v253_9: Space = intersect(&(*CONSTANT_6),&(v253_2));
    drop(v253_2);
    let v253_10: Space = if has_head(&(v253_9)) { singleton(&[]) } else { Space::new() };
    drop(v253_9);
    let v253_12: Space = if (v253_10).is_empty() { Space::new() } else {
      let mut v258_11 = Space::new();
      let mut v258_11_cursor = (v252_12_tail).read_zipper();
      for v258_11_byte in v258_11_cursor.child_mask().iter() {
        v258_11_cursor.descend_to_byte(v258_11_byte);
        let v258_11_tail = v258_11_cursor.make_map();
        v258_11_cursor.ascend(1);
        let v258_11_head = Path::from_slice(&[v258_11_byte]);
        let v259_2: Space = singleton(&(v258_11_head));
        let v259_3: Space = intersect(&(*CONSTANT_6),&(v259_2));
        let v259_4: Space = if has_head(&(v259_3)) { singleton(&[]) } else { Space::new() };
        drop(v259_3);
        let v259_5: Space = subtract(&(*CONSTANT_5),&(v259_4));
        drop(v259_4);
        let v259_7: Space = if (v259_5).is_empty() { Space::new() } else {
          let v260_6: Space = routine_23(c, &(v258_11_head), &(v258_11_tail), &(*s1));
          compose(&(v259_5),&(v260_6))
        };
        drop(v259_5);
        let v259_8: Space = intersect(&(*CONSTANT_6),&(v259_2));
        drop(v259_2);
        let v259_9: Space = if has_head(&(v259_8)) { singleton(&[]) } else { Space::new() };
        drop(v259_8);
        let v259_11: Space = if (v259_9).is_empty() { Space::new() } else {
          let v261_10: Space = routine_24(c, &(v258_11_head), &(v258_11_tail), &(*s1));
          compose(&(v259_9),&(v261_10))
        };
        drop(v259_9);
        let v259_12: Space = unite(&(v259_7),&(v259_11));
        v258_11.join_into((v259_12).clone());
      }
      drop(v258_11_cursor);
      compose(&(v253_10),&(v258_11))
    };
    drop(v253_10);
    let v262_6: Path = concat_path(&(*p0),&(v252_12_head));
    let v253_13: Space = wrap(&(v253_12),&(v262_6));
    let v253_14: Space = unite(&(v253_8),&(v253_13));
    v252_12.join_into((v253_14).clone());
  }
  drop(v252_12_cursor);
  (v252_12).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v263_12 = Space::new();
  let mut v263_12_cursor = (*s0).read_zipper();
  for v263_12_byte in v263_12_cursor.child_mask().iter() {
    v263_12_cursor.descend_to_byte(v263_12_byte);
    let v263_12_tail = v263_12_cursor.make_map();
    v263_12_cursor.ascend(1);
    let v263_12_head = Path::from_slice(&[v263_12_byte]);
    let v264_2: Space = singleton(&(v263_12_head));
    let v264_3: Space = intersect(&(*CONSTANT_6),&(v264_2));
    let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
    drop(v264_3);
    let v264_5: Space = subtract(&(*CONSTANT_5),&(v264_4));
    drop(v264_4);
    let v264_8: Space = if (v264_5).is_empty() { Space::new() } else {
      let v265_6: Path = concat_path(&(*p0),&(v263_12_head));
      let mut v265_7 = Space::new();
      let mut v265_7_cursor = (v263_12_tail).read_zipper();
      for v265_7_byte in v265_7_cursor.child_mask().iter() {
        v265_7_cursor.descend_to_byte(v265_7_byte);
        let v265_7_tail = v265_7_cursor.make_map();
        v265_7_cursor.ascend(1);
        let v265_7_head = Path::from_slice(&[v265_7_byte]);
        let v266_2: Space = singleton(&(v265_7_head));
        let v266_3: Space = intersect(&(*CONSTANT_6),&(v266_2));
        let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
        drop(v266_3);
        let v266_5: Space = subtract(&(*CONSTANT_5),&(v266_4));
        drop(v266_4);
        let v266_8: Space = if (v266_5).is_empty() { Space::new() } else {
          let v267_6: Path = concat_path(&(v265_6),&(v265_7_head));
          let v267_7: Space = routine_45(c, &(v267_6), &(v265_7_tail), &(*s1));
          compose(&(v266_5),&(v267_7))
        };
        drop(v266_5);
        let v266_9: Space = intersect(&(*CONSTANT_6),&(v266_2));
        drop(v266_2);
        let v266_10: Space = if has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
        drop(v266_9);
        let v266_12: Space = if (v266_10).is_empty() { Space::new() } else {
          let v268_6: Path = concat_path(&(v265_6),&(v265_7_head));
          let v268_11: Space = routine_46(c, &(v268_6), &(v265_7_tail), &(*s1));
          drop(v268_6);
          compose(&(v266_10),&(v268_11))
        };
        drop(v266_10);
        let v266_13: Space = unite(&(v266_8),&(v266_12));
        v265_7.join_into((v266_13).clone());
      }
      drop(v265_7_cursor);
      compose(&(v264_5),&(v265_7))
    };
    drop(v264_5);
    let v264_9: Space = intersect(&(*CONSTANT_6),&(v264_2));
    drop(v264_2);
    let v264_10: Space = if has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
    drop(v264_9);
    let v264_12: Space = if (v264_10).is_empty() { Space::new() } else {
      let v269_6: Path = concat_path(&(*p0),&(v263_12_head));
      let mut v269_11 = Space::new();
      let mut v269_11_cursor = (v263_12_tail).read_zipper();
      for v269_11_byte in v269_11_cursor.child_mask().iter() {
        v269_11_cursor.descend_to_byte(v269_11_byte);
        let v269_11_tail = v269_11_cursor.make_map();
        v269_11_cursor.ascend(1);
        let v269_11_head = Path::from_slice(&[v269_11_byte]);
        let v270_2: Space = singleton(&(v269_11_head));
        let v270_3: Space = intersect(&(*CONSTANT_6),&(v270_2));
        let v270_4: Space = if has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
        drop(v270_3);
        let v270_5: Space = subtract(&(*CONSTANT_5),&(v270_4));
        drop(v270_4);
        let v270_8: Space = if (v270_5).is_empty() { Space::new() } else {
          let v271_6: Path = concat_path(&(v269_6),&(v269_11_head));
          let v271_7: Space = routine_45(c, &(v271_6), &(v269_11_tail), &(*s1));
          compose(&(v270_5),&(v271_7))
        };
        drop(v270_5);
        let v270_9: Space = intersect(&(*CONSTANT_6),&(v270_2));
        drop(v270_2);
        let v270_10: Space = if has_head(&(v270_9)) { singleton(&[]) } else { Space::new() };
        drop(v270_9);
        let v270_12: Space = if (v270_10).is_empty() { Space::new() } else {
          let v272_6: Path = concat_path(&(v269_6),&(v269_11_head));
          let v272_11: Space = routine_27(c, &(v272_6), &(v269_11_tail), &(*s1));
          drop(v272_6);
          compose(&(v270_10),&(v272_11))
        };
        drop(v270_10);
        let v270_13: Space = unite(&(v270_8),&(v270_12));
        v269_11.join_into((v270_13).clone());
      }
      drop(v269_11_cursor);
      drop(v269_6);
      compose(&(v264_10),&(v269_11))
    };
    drop(v264_10);
    let v264_13: Space = unite(&(v264_8),&(v264_12));
    v263_12.join_into((v264_13).clone());
  }
  drop(v263_12_cursor);
  (v263_12).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v273_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v273_9: Space = unwrap(&(v273_7),&(*CONSTANT_4));
  drop(v273_7);
  let v273_10: Space = unwrap(&(v273_9),&(*p0));
  drop(v273_9);
  let mut v273_15 = Space::new();
  let mut v273_15_cursor = (*s0).read_zipper();
  for v273_15_byte in v273_15_cursor.child_mask().iter() {
    v273_15_cursor.descend_to_byte(v273_15_byte);
    let v273_15_tail = v273_15_cursor.make_map();
    v273_15_cursor.ascend(1);
    let v273_15_head = Path::from_slice(&[v273_15_byte]);
    let v274_2: Space = singleton(&(v273_15_head));
    let v274_3: Space = intersect(&(*CONSTANT_6),&(v274_2));
    let v274_4: Space = if has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
    drop(v274_3);
    let v274_5: Space = subtract(&(*CONSTANT_5),&(v274_4));
    drop(v274_4);
    let v274_8: Space = if (v274_5).is_empty() { Space::new() } else {
      let v275_6: Path = concat_path(&(*p0),&(v273_15_head));
      let mut v275_7 = Space::new();
      let mut v275_7_cursor = (v273_15_tail).read_zipper();
      for v275_7_byte in v275_7_cursor.child_mask().iter() {
        v275_7_cursor.descend_to_byte(v275_7_byte);
        let v275_7_tail = v275_7_cursor.make_map();
        v275_7_cursor.ascend(1);
        let v275_7_head = Path::from_slice(&[v275_7_byte]);
        let v276_2: Space = singleton(&(v275_7_head));
        let v276_3: Space = intersect(&(*CONSTANT_6),&(v276_2));
        let v276_4: Space = if has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
        drop(v276_3);
        let v276_5: Space = subtract(&(*CONSTANT_5),&(v276_4));
        drop(v276_4);
        let v276_8: Space = if (v276_5).is_empty() { Space::new() } else {
          let v277_6: Path = concat_path(&(v275_6),&(v275_7_head));
          let v277_7: Space = routine_45(c, &(v277_6), &(v275_7_tail), &(*s1));
          compose(&(v276_5),&(v277_7))
        };
        drop(v276_5);
        let v276_9: Space = intersect(&(*CONSTANT_6),&(v276_2));
        drop(v276_2);
        let v276_10: Space = if has_head(&(v276_9)) { singleton(&[]) } else { Space::new() };
        drop(v276_9);
        let v276_12: Space = if (v276_10).is_empty() { Space::new() } else {
          let v278_6: Path = concat_path(&(v275_6),&(v275_7_head));
          let v278_11: Space = routine_46(c, &(v278_6), &(v275_7_tail), &(*s1));
          drop(v278_6);
          compose(&(v276_10),&(v278_11))
        };
        drop(v276_10);
        let v276_13: Space = unite(&(v276_8),&(v276_12));
        v275_7.join_into((v276_13).clone());
      }
      drop(v275_7_cursor);
      drop(v275_6);
      compose(&(v274_5),&(v275_7))
    };
    drop(v274_5);
    let v274_9: Space = intersect(&(*CONSTANT_6),&(v274_2));
    drop(v274_2);
    let v274_10: Space = if has_head(&(v274_9)) { singleton(&[]) } else { Space::new() };
    drop(v274_9);
    let v274_13: Space = if (v274_10).is_empty() { Space::new() } else {
      let v279_11: Space = unwrap(&(v273_10),&(v273_15_head));
      let v279_12: Space = subtract(&(v279_11),&(*CONSTANT_5));
      drop(v279_11);
      compose(&(v274_10),&(v279_12))
    };
    drop(v274_10);
    let v274_14: Space = unite(&(v274_8),&(v274_13));
    drop(v274_13);
    v273_15.join_into((v274_14).clone());
  }
  drop(v273_15_cursor);
  drop(v273_10);
  (v273_15).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v280_12 = Space::new();
  let mut v280_12_cursor = (*s0).read_zipper();
  for v280_12_byte in v280_12_cursor.child_mask().iter() {
    v280_12_cursor.descend_to_byte(v280_12_byte);
    let v280_12_tail = v280_12_cursor.make_map();
    v280_12_cursor.ascend(1);
    let v280_12_head = Path::from_slice(&[v280_12_byte]);
    let v281_2: Space = singleton(&(v280_12_head));
    let v281_3: Space = intersect(&(*CONSTANT_6),&(v281_2));
    let v281_4: Space = if has_head(&(v281_3)) { singleton(&[]) } else { Space::new() };
    drop(v281_3);
    let v281_5: Space = subtract(&(*CONSTANT_5),&(v281_4));
    drop(v281_4);
    let v281_8: Space = if (v281_5).is_empty() { Space::new() } else {
      let v282_6: Path = concat_path(&(*p0),&(v280_12_head));
      let mut v282_7 = Space::new();
      let mut v282_7_cursor = (v280_12_tail).read_zipper();
      for v282_7_byte in v282_7_cursor.child_mask().iter() {
        v282_7_cursor.descend_to_byte(v282_7_byte);
        let v282_7_tail = v282_7_cursor.make_map();
        v282_7_cursor.ascend(1);
        let v282_7_head = Path::from_slice(&[v282_7_byte]);
        let v283_2: Space = singleton(&(v282_7_head));
        let v283_3: Space = intersect(&(*CONSTANT_6),&(v283_2));
        let v283_4: Space = if has_head(&(v283_3)) { singleton(&[]) } else { Space::new() };
        drop(v283_3);
        let v283_5: Space = subtract(&(*CONSTANT_5),&(v283_4));
        drop(v283_4);
        let v283_8: Space = if (v283_5).is_empty() { Space::new() } else {
          let v284_6: Path = concat_path(&(v282_6),&(v282_7_head));
          let v284_7: Space = routine_47(c, &(v284_6), &(v282_7_tail), &(*s1));
          compose(&(v283_5),&(v284_7))
        };
        drop(v283_5);
        let v283_9: Space = intersect(&(*CONSTANT_6),&(v283_2));
        drop(v283_2);
        let v283_10: Space = if has_head(&(v283_9)) { singleton(&[]) } else { Space::new() };
        drop(v283_9);
        let v283_12: Space = if (v283_10).is_empty() { Space::new() } else {
          let v285_6: Path = concat_path(&(v282_6),&(v282_7_head));
          let v285_11: Space = routine_48(c, &(v285_6), &(v282_7_tail), &(*s1));
          drop(v285_6);
          compose(&(v283_10),&(v285_11))
        };
        drop(v283_10);
        let v283_13: Space = unite(&(v283_8),&(v283_12));
        v282_7.join_into((v283_13).clone());
      }
      drop(v282_7_cursor);
      compose(&(v281_5),&(v282_7))
    };
    drop(v281_5);
    let v281_9: Space = intersect(&(*CONSTANT_6),&(v281_2));
    drop(v281_2);
    let v281_10: Space = if has_head(&(v281_9)) { singleton(&[]) } else { Space::new() };
    drop(v281_9);
    let v281_12: Space = if (v281_10).is_empty() { Space::new() } else {
      let v286_6: Path = concat_path(&(*p0),&(v280_12_head));
      let mut v286_11 = Space::new();
      let mut v286_11_cursor = (v280_12_tail).read_zipper();
      for v286_11_byte in v286_11_cursor.child_mask().iter() {
        v286_11_cursor.descend_to_byte(v286_11_byte);
        let v286_11_tail = v286_11_cursor.make_map();
        v286_11_cursor.ascend(1);
        let v286_11_head = Path::from_slice(&[v286_11_byte]);
        let v287_2: Space = singleton(&(v286_11_head));
        let v287_3: Space = intersect(&(*CONSTANT_6),&(v287_2));
        let v287_4: Space = if has_head(&(v287_3)) { singleton(&[]) } else { Space::new() };
        drop(v287_3);
        let v287_5: Space = subtract(&(*CONSTANT_5),&(v287_4));
        drop(v287_4);
        let v287_8: Space = if (v287_5).is_empty() { Space::new() } else {
          let v288_6: Path = concat_path(&(v286_6),&(v286_11_head));
          let v288_7: Space = routine_47(c, &(v288_6), &(v286_11_tail), &(*s1));
          compose(&(v287_5),&(v288_7))
        };
        drop(v287_5);
        let v287_9: Space = intersect(&(*CONSTANT_6),&(v287_2));
        drop(v287_2);
        let v287_10: Space = if has_head(&(v287_9)) { singleton(&[]) } else { Space::new() };
        drop(v287_9);
        let v287_12: Space = if (v287_10).is_empty() { Space::new() } else {
          let v289_6: Path = concat_path(&(v286_6),&(v286_11_head));
          let v289_11: Space = routine_27(c, &(v289_6), &(v286_11_tail), &(*s1));
          drop(v289_6);
          compose(&(v287_10),&(v289_11))
        };
        drop(v287_10);
        let v287_13: Space = unite(&(v287_8),&(v287_12));
        v286_11.join_into((v287_13).clone());
      }
      drop(v286_11_cursor);
      drop(v286_6);
      compose(&(v281_10),&(v286_11))
    };
    drop(v281_10);
    let v281_13: Space = unite(&(v281_8),&(v281_12));
    v280_12.join_into((v281_13).clone());
  }
  drop(v280_12_cursor);
  (v280_12).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v290_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v290_9: Space = unwrap(&(v290_7),&(*CONSTANT_4));
  drop(v290_7);
  let v290_10: Space = unwrap(&(v290_9),&(*p0));
  drop(v290_9);
  let mut v290_15 = Space::new();
  let mut v290_15_cursor = (*s0).read_zipper();
  for v290_15_byte in v290_15_cursor.child_mask().iter() {
    v290_15_cursor.descend_to_byte(v290_15_byte);
    let v290_15_tail = v290_15_cursor.make_map();
    v290_15_cursor.ascend(1);
    let v290_15_head = Path::from_slice(&[v290_15_byte]);
    let v291_2: Space = singleton(&(v290_15_head));
    let v291_3: Space = intersect(&(*CONSTANT_6),&(v291_2));
    let v291_4: Space = if has_head(&(v291_3)) { singleton(&[]) } else { Space::new() };
    drop(v291_3);
    let v291_5: Space = subtract(&(*CONSTANT_5),&(v291_4));
    drop(v291_4);
    let v291_8: Space = if (v291_5).is_empty() { Space::new() } else {
      let v292_6: Path = concat_path(&(*p0),&(v290_15_head));
      let mut v292_7 = Space::new();
      let mut v292_7_cursor = (v290_15_tail).read_zipper();
      for v292_7_byte in v292_7_cursor.child_mask().iter() {
        v292_7_cursor.descend_to_byte(v292_7_byte);
        let v292_7_tail = v292_7_cursor.make_map();
        v292_7_cursor.ascend(1);
        let v292_7_head = Path::from_slice(&[v292_7_byte]);
        let v293_2: Space = singleton(&(v292_7_head));
        let v293_3: Space = intersect(&(*CONSTANT_6),&(v293_2));
        let v293_4: Space = if has_head(&(v293_3)) { singleton(&[]) } else { Space::new() };
        drop(v293_3);
        let v293_5: Space = subtract(&(*CONSTANT_5),&(v293_4));
        drop(v293_4);
        let v293_8: Space = if (v293_5).is_empty() { Space::new() } else {
          let v294_6: Path = concat_path(&(v292_6),&(v292_7_head));
          let v294_7: Space = routine_47(c, &(v294_6), &(v292_7_tail), &(*s1));
          compose(&(v293_5),&(v294_7))
        };
        drop(v293_5);
        let v293_9: Space = intersect(&(*CONSTANT_6),&(v293_2));
        drop(v293_2);
        let v293_10: Space = if has_head(&(v293_9)) { singleton(&[]) } else { Space::new() };
        drop(v293_9);
        let v293_12: Space = if (v293_10).is_empty() { Space::new() } else {
          let v295_6: Path = concat_path(&(v292_6),&(v292_7_head));
          let v295_11: Space = routine_48(c, &(v295_6), &(v292_7_tail), &(*s1));
          drop(v295_6);
          compose(&(v293_10),&(v295_11))
        };
        drop(v293_10);
        let v293_13: Space = unite(&(v293_8),&(v293_12));
        v292_7.join_into((v293_13).clone());
      }
      drop(v292_7_cursor);
      drop(v292_6);
      compose(&(v291_5),&(v292_7))
    };
    drop(v291_5);
    let v291_9: Space = intersect(&(*CONSTANT_6),&(v291_2));
    drop(v291_2);
    let v291_10: Space = if has_head(&(v291_9)) { singleton(&[]) } else { Space::new() };
    drop(v291_9);
    let v291_13: Space = if (v291_10).is_empty() { Space::new() } else {
      let v296_11: Space = unwrap(&(v290_10),&(v290_15_head));
      let v296_12: Space = subtract(&(v296_11),&(*CONSTANT_5));
      drop(v296_11);
      compose(&(v291_10),&(v296_12))
    };
    drop(v291_10);
    let v291_14: Space = unite(&(v291_8),&(v291_13));
    drop(v291_13);
    v290_15.join_into((v291_14).clone());
  }
  drop(v290_15_cursor);
  drop(v290_10);
  (v290_15).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v297_4: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v297_6: Space = unwrap(&(v297_4),&(*CONSTANT_4));
  drop(v297_4);
  let v297_7: Space = unwrap(&(v297_6),&(*p0));
  drop(v297_6);
  let v297_9: Space = subtract(&(v297_7),&(*CONSTANT_5));
  drop(v297_7);
  (v297_9).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v298_11 = Space::new();
  let mut v298_11_cursor = (*s0).read_zipper();
  for v298_11_byte in v298_11_cursor.child_mask().iter() {
    v298_11_cursor.descend_to_byte(v298_11_byte);
    let v298_11_tail = v298_11_cursor.make_map();
    v298_11_cursor.ascend(1);
    let v298_11_head = Path::from_slice(&[v298_11_byte]);
    let v299_2: Space = singleton(&(v298_11_head));
    let v299_3: Space = intersect(&(*CONSTANT_6),&(v299_2));
    let v299_4: Space = if has_head(&(v299_3)) { singleton(&[]) } else { Space::new() };
    drop(v299_3);
    let v299_5: Space = subtract(&(*CONSTANT_5),&(v299_4));
    drop(v299_4);
    let v299_8: Space = if (v299_5).is_empty() { Space::new() } else {
      let v300_6: Path = concat_path(&(*p0),&(v298_11_head));
      let mut v300_7 = Space::new();
      let mut v300_7_cursor = (v298_11_tail).read_zipper();
      for v300_7_byte in v300_7_cursor.child_mask().iter() {
        v300_7_cursor.descend_to_byte(v300_7_byte);
        let v300_7_tail = v300_7_cursor.make_map();
        v300_7_cursor.ascend(1);
        let v300_7_head = Path::from_slice(&[v300_7_byte]);
        let v301_2: Space = singleton(&(v300_7_head));
        let v301_3: Space = intersect(&(*CONSTANT_6),&(v301_2));
        let v301_4: Space = if has_head(&(v301_3)) { singleton(&[]) } else { Space::new() };
        drop(v301_3);
        let v301_5: Space = subtract(&(*CONSTANT_5),&(v301_4));
        drop(v301_4);
        let v301_8: Space = if (v301_5).is_empty() { Space::new() } else {
          let v302_6: Path = concat_path(&(v300_6),&(v300_7_head));
          let v302_7: Space = routine_49(c, &(v302_6), &(v300_7_tail));
          compose(&(v301_5),&(v302_7))
        };
        drop(v301_5);
        let v301_9: Space = intersect(&(*CONSTANT_6),&(v301_2));
        drop(v301_2);
        let v301_10: Space = if has_head(&(v301_9)) { singleton(&[]) } else { Space::new() };
        drop(v301_9);
        let v301_12: Space = if (v301_10).is_empty() { Space::new() } else {
          let v303_6: Path = concat_path(&(v300_6),&(v300_7_head));
          let v303_11: Space = routine_50(c, &(v303_6), &(v300_7_tail));
          drop(v303_6);
          compose(&(v301_10),&(v303_11))
        };
        drop(v301_10);
        let v301_13: Space = unite(&(v301_8),&(v301_12));
        v300_7.join_into((v301_13).clone());
      }
      drop(v300_7_cursor);
      compose(&(v299_5),&(v300_7))
    };
    drop(v299_5);
    let v299_9: Space = intersect(&(*CONSTANT_6),&(v299_2));
    drop(v299_2);
    let v299_10: Space = if has_head(&(v299_9)) { singleton(&[]) } else { Space::new() };
    drop(v299_9);
    let v299_12: Space = if (v299_10).is_empty() { Space::new() } else {
      let v304_6: Path = concat_path(&(*p0),&(v298_11_head));
      let mut v304_11 = Space::new();
      let mut v304_11_cursor = (v298_11_tail).read_zipper();
      for v304_11_byte in v304_11_cursor.child_mask().iter() {
        v304_11_cursor.descend_to_byte(v304_11_byte);
        let v304_11_tail = v304_11_cursor.make_map();
        v304_11_cursor.ascend(1);
        let v304_11_head = Path::from_slice(&[v304_11_byte]);
        let v305_2: Space = singleton(&(v304_11_head));
        let v305_3: Space = intersect(&(*CONSTANT_6),&(v305_2));
        let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
        drop(v305_3);
        let v305_5: Space = subtract(&(*CONSTANT_5),&(v305_4));
        drop(v305_4);
        let v305_8: Space = if (v305_5).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v304_6),&(v304_11_head));
          let v306_7: Space = routine_49(c, &(v306_6), &(v304_11_tail));
          compose(&(v305_5),&(v306_7))
        };
        drop(v305_5);
        let v305_9: Space = intersect(&(*CONSTANT_6),&(v305_2));
        drop(v305_2);
        let v305_10: Space = if has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
        drop(v305_9);
        let v305_12: Space = if (v305_10).is_empty() { Space::new() } else {
          let v307_6: Path = concat_path(&(v304_6),&(v304_11_head));
          let v307_11: Space = routine_10(c, &(v307_6), &(v304_11_tail));
          drop(v307_6);
          compose(&(v305_10),&(v307_11))
        };
        drop(v305_10);
        let v305_13: Space = unite(&(v305_8),&(v305_12));
        v304_11.join_into((v305_13).clone());
      }
      drop(v304_11_cursor);
      drop(v304_6);
      compose(&(v299_10),&(v304_11))
    };
    drop(v299_10);
    let v299_13: Space = unite(&(v299_8),&(v299_12));
    v298_11.join_into((v299_13).clone());
  }
  drop(v298_11_cursor);
  (v298_11).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v308_9 = Space::new();
  let mut v308_9_cursor = (*s0).read_zipper();
  for v308_9_byte in v308_9_cursor.child_mask().iter() {
    v308_9_cursor.descend_to_byte(v308_9_byte);
    let v308_9_tail = v308_9_cursor.make_map();
    v308_9_cursor.ascend(1);
    let v308_9_head = Path::from_slice(&[v308_9_byte]);
    let v309_2: Space = singleton(&(v308_9_head));
    let v309_3: Space = intersect(&(*CONSTANT_6),&(v309_2));
    let v309_4: Space = if has_head(&(v309_3)) { singleton(&[]) } else { Space::new() };
    drop(v309_3);
    let v309_5: Space = subtract(&(*CONSTANT_5),&(v309_4));
    drop(v309_4);
    let v309_8: Space = if (v309_5).is_empty() { Space::new() } else {
      let v310_6: Path = concat_path(&(*p0),&(v308_9_head));
      let mut v310_7 = Space::new();
      let mut v310_7_cursor = (v308_9_tail).read_zipper();
      for v310_7_byte in v310_7_cursor.child_mask().iter() {
        v310_7_cursor.descend_to_byte(v310_7_byte);
        let v310_7_tail = v310_7_cursor.make_map();
        v310_7_cursor.ascend(1);
        let v310_7_head = Path::from_slice(&[v310_7_byte]);
        let v311_2: Space = singleton(&(v310_7_head));
        let v311_3: Space = intersect(&(*CONSTANT_6),&(v311_2));
        let v311_4: Space = if has_head(&(v311_3)) { singleton(&[]) } else { Space::new() };
        drop(v311_3);
        let v311_5: Space = subtract(&(*CONSTANT_5),&(v311_4));
        drop(v311_4);
        let v311_8: Space = if (v311_5).is_empty() { Space::new() } else {
          let v312_6: Path = concat_path(&(v310_6),&(v310_7_head));
          let v312_7: Space = routine_49(c, &(v312_6), &(v310_7_tail));
          compose(&(v311_5),&(v312_7))
        };
        drop(v311_5);
        let v311_9: Space = intersect(&(*CONSTANT_6),&(v311_2));
        drop(v311_2);
        let v311_10: Space = if has_head(&(v311_9)) { singleton(&[]) } else { Space::new() };
        drop(v311_9);
        let v311_12: Space = if (v311_10).is_empty() { Space::new() } else {
          let v313_6: Path = concat_path(&(v310_6),&(v310_7_head));
          let v313_11: Space = routine_50(c, &(v313_6), &(v310_7_tail));
          drop(v313_6);
          compose(&(v311_10),&(v313_11))
        };
        drop(v311_10);
        let v311_13: Space = unite(&(v311_8),&(v311_12));
        v310_7.join_into((v311_13).clone());
      }
      drop(v310_7_cursor);
      compose(&(v309_5),&(v310_7))
    };
    drop(v309_5);
    let v309_9: Space = intersect(&(*CONSTANT_6),&(v309_2));
    drop(v309_2);
    let v309_10: Space = if has_head(&(v309_9)) { singleton(&[]) } else { Space::new() };
    drop(v309_9);
    let v309_11: Space = subtract(&(v308_9_tail),&(*CONSTANT_5));
    let v309_12: Space = compose(&(v309_10),&(v309_11));
    drop(v309_10);
    drop(v309_11);
    let v314_6: Path = concat_path(&(*p0),&(v308_9_head));
    let v309_13: Space = wrap(&(v309_12),&(v314_6));
    drop(v309_12);
    let v309_14: Space = unite(&(v309_8),&(v309_13));
    drop(v309_13);
    v308_9.join_into((v309_14).clone());
  }
  drop(v308_9_cursor);
  (v308_9).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v315_12 = Space::new();
  let mut v315_12_cursor = (*s0).read_zipper();
  for v315_12_byte in v315_12_cursor.child_mask().iter() {
    v315_12_cursor.descend_to_byte(v315_12_byte);
    let v315_12_tail = v315_12_cursor.make_map();
    v315_12_cursor.ascend(1);
    let v315_12_head = Path::from_slice(&[v315_12_byte]);
    let v316_2: Space = singleton(&(v315_12_head));
    let v316_3: Space = intersect(&(*CONSTANT_6),&(v316_2));
    let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
    drop(v316_3);
    let v316_5: Space = subtract(&(*CONSTANT_5),&(v316_4));
    drop(v316_4);
    let v316_8: Space = if (v316_5).is_empty() { Space::new() } else {
      let v317_6: Path = concat_path(&(*p0),&(v315_12_head));
      let mut v317_7 = Space::new();
      let mut v317_7_cursor = (v315_12_tail).read_zipper();
      for v317_7_byte in v317_7_cursor.child_mask().iter() {
        v317_7_cursor.descend_to_byte(v317_7_byte);
        let v317_7_tail = v317_7_cursor.make_map();
        v317_7_cursor.ascend(1);
        let v317_7_head = Path::from_slice(&[v317_7_byte]);
        let v318_2: Space = singleton(&(v317_7_head));
        let v318_3: Space = intersect(&(*CONSTANT_6),&(v318_2));
        let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
        drop(v318_3);
        let v318_5: Space = subtract(&(*CONSTANT_5),&(v318_4));
        drop(v318_4);
        let v318_8: Space = if (v318_5).is_empty() { Space::new() } else {
          let v319_6: Path = concat_path(&(v317_6),&(v317_7_head));
          let v319_7: Space = routine_51(c, &(v319_6), &(v317_7_tail), &(*s1));
          compose(&(v318_5),&(v319_7))
        };
        drop(v318_5);
        let v318_9: Space = intersect(&(*CONSTANT_6),&(v318_2));
        drop(v318_2);
        let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
        drop(v318_9);
        let v318_12: Space = if (v318_10).is_empty() { Space::new() } else {
          let v320_6: Path = concat_path(&(v317_6),&(v317_7_head));
          let v320_11: Space = routine_52(c, &(v320_6), &(v317_7_tail), &(*s1));
          drop(v320_6);
          compose(&(v318_10),&(v320_11))
        };
        drop(v318_10);
        let v318_13: Space = unite(&(v318_8),&(v318_12));
        v317_7.join_into((v318_13).clone());
      }
      drop(v317_7_cursor);
      compose(&(v316_5),&(v317_7))
    };
    drop(v316_5);
    let v316_9: Space = intersect(&(*CONSTANT_6),&(v316_2));
    drop(v316_2);
    let v316_10: Space = if has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
    drop(v316_9);
    let v316_12: Space = if (v316_10).is_empty() { Space::new() } else {
      let v321_6: Path = concat_path(&(*p0),&(v315_12_head));
      let mut v321_11 = Space::new();
      let mut v321_11_cursor = (v315_12_tail).read_zipper();
      for v321_11_byte in v321_11_cursor.child_mask().iter() {
        v321_11_cursor.descend_to_byte(v321_11_byte);
        let v321_11_tail = v321_11_cursor.make_map();
        v321_11_cursor.ascend(1);
        let v321_11_head = Path::from_slice(&[v321_11_byte]);
        let v322_2: Space = singleton(&(v321_11_head));
        let v322_3: Space = intersect(&(*CONSTANT_6),&(v322_2));
        let v322_4: Space = if has_head(&(v322_3)) { singleton(&[]) } else { Space::new() };
        drop(v322_3);
        let v322_5: Space = subtract(&(*CONSTANT_5),&(v322_4));
        drop(v322_4);
        let v322_8: Space = if (v322_5).is_empty() { Space::new() } else {
          let v323_6: Path = concat_path(&(v321_6),&(v321_11_head));
          let v323_7: Space = routine_51(c, &(v323_6), &(v321_11_tail), &(*s1));
          compose(&(v322_5),&(v323_7))
        };
        drop(v322_5);
        let v322_9: Space = intersect(&(*CONSTANT_6),&(v322_2));
        drop(v322_2);
        let v322_10: Space = if has_head(&(v322_9)) { singleton(&[]) } else { Space::new() };
        drop(v322_9);
        let v322_12: Space = if (v322_10).is_empty() { Space::new() } else {
          let v324_6: Path = concat_path(&(v321_6),&(v321_11_head));
          let v324_11: Space = routine_13(c, &(v324_6), &(v321_11_tail), &(*s1));
          drop(v324_6);
          compose(&(v322_10),&(v324_11))
        };
        drop(v322_10);
        let v322_13: Space = unite(&(v322_8),&(v322_12));
        v321_11.join_into((v322_13).clone());
      }
      drop(v321_11_cursor);
      drop(v321_6);
      compose(&(v316_10),&(v321_11))
    };
    drop(v316_10);
    let v316_13: Space = unite(&(v316_8),&(v316_12));
    v315_12.join_into((v316_13).clone());
  }
  drop(v315_12_cursor);
  (v315_12).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v325_12 = Space::new();
  let mut v325_12_cursor = (*s0).read_zipper();
  for v325_12_byte in v325_12_cursor.child_mask().iter() {
    v325_12_cursor.descend_to_byte(v325_12_byte);
    let v325_12_tail = v325_12_cursor.make_map();
    v325_12_cursor.ascend(1);
    let v325_12_head = Path::from_slice(&[v325_12_byte]);
    let v326_2: Space = singleton(&(v325_12_head));
    let v326_3: Space = intersect(&(*CONSTANT_6),&(v326_2));
    let v326_4: Space = if has_head(&(v326_3)) { singleton(&[]) } else { Space::new() };
    drop(v326_3);
    let v326_5: Space = subtract(&(*CONSTANT_5),&(v326_4));
    drop(v326_4);
    let v326_8: Space = if (v326_5).is_empty() { Space::new() } else {
      let v327_6: Path = concat_path(&(*p0),&(v325_12_head));
      let mut v327_7 = Space::new();
      let mut v327_7_cursor = (v325_12_tail).read_zipper();
      for v327_7_byte in v327_7_cursor.child_mask().iter() {
        v327_7_cursor.descend_to_byte(v327_7_byte);
        let v327_7_tail = v327_7_cursor.make_map();
        v327_7_cursor.ascend(1);
        let v327_7_head = Path::from_slice(&[v327_7_byte]);
        let v328_2: Space = singleton(&(v327_7_head));
        let v328_3: Space = intersect(&(*CONSTANT_6),&(v328_2));
        let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
        drop(v328_3);
        let v328_5: Space = subtract(&(*CONSTANT_5),&(v328_4));
        drop(v328_4);
        let v328_8: Space = if (v328_5).is_empty() { Space::new() } else {
          let v329_6: Path = concat_path(&(v327_6),&(v327_7_head));
          let v329_7: Space = routine_51(c, &(v329_6), &(v327_7_tail), &(*s1));
          compose(&(v328_5),&(v329_7))
        };
        drop(v328_5);
        let v328_9: Space = intersect(&(*CONSTANT_6),&(v328_2));
        drop(v328_2);
        let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
        drop(v328_9);
        let v328_12: Space = if (v328_10).is_empty() { Space::new() } else {
          let v330_6: Path = concat_path(&(v327_6),&(v327_7_head));
          let v330_11: Space = routine_52(c, &(v330_6), &(v327_7_tail), &(*s1));
          drop(v330_6);
          compose(&(v328_10),&(v330_11))
        };
        drop(v328_10);
        let v328_13: Space = unite(&(v328_8),&(v328_12));
        v327_7.join_into((v328_13).clone());
      }
      drop(v327_7_cursor);
      compose(&(v326_5),&(v327_7))
    };
    drop(v326_5);
    let v326_9: Space = intersect(&(*CONSTANT_6),&(v326_2));
    drop(v326_2);
    let v326_10: Space = if has_head(&(v326_9)) { singleton(&[]) } else { Space::new() };
    drop(v326_9);
    let v326_12: Space = if (v326_10).is_empty() { Space::new() } else {
      let mut v331_11 = Space::new();
      let mut v331_11_cursor = (v325_12_tail).read_zipper();
      for v331_11_byte in v331_11_cursor.child_mask().iter() {
        v331_11_cursor.descend_to_byte(v331_11_byte);
        let v331_11_tail = v331_11_cursor.make_map();
        v331_11_cursor.ascend(1);
        let v331_11_head = Path::from_slice(&[v331_11_byte]);
        let v332_2: Space = singleton(&(v331_11_head));
        let v332_3: Space = intersect(&(*CONSTANT_6),&(v332_2));
        let v332_4: Space = if has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
        drop(v332_3);
        let v332_5: Space = subtract(&(*CONSTANT_5),&(v332_4));
        drop(v332_4);
        let v332_7: Space = if (v332_5).is_empty() { Space::new() } else {
          let v333_6: Space = routine_32(c, &(v331_11_head), &(v331_11_tail), &(*s1));
          compose(&(v332_5),&(v333_6))
        };
        drop(v332_5);
        let v332_8: Space = intersect(&(*CONSTANT_6),&(v332_2));
        drop(v332_2);
        let v332_9: Space = if has_head(&(v332_8)) { singleton(&[]) } else { Space::new() };
        drop(v332_8);
        let v332_11: Space = if (v332_9).is_empty() { Space::new() } else {
          let v334_10: Space = routine_33(c, &(v331_11_head), &(v331_11_tail), &(*s1));
          compose(&(v332_9),&(v334_10))
        };
        drop(v332_9);
        let v332_12: Space = unite(&(v332_7),&(v332_11));
        v331_11.join_into((v332_12).clone());
      }
      drop(v331_11_cursor);
      compose(&(v326_10),&(v331_11))
    };
    drop(v326_10);
    let v335_6: Path = concat_path(&(*p0),&(v325_12_head));
    let v326_13: Space = wrap(&(v326_12),&(v335_6));
    let v326_14: Space = unite(&(v326_8),&(v326_13));
    v325_12.join_into((v326_14).clone());
  }
  drop(v325_12_cursor);
  (v325_12).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v336_12 = Space::new();
  let mut v336_12_cursor = (*s0).read_zipper();
  for v336_12_byte in v336_12_cursor.child_mask().iter() {
    v336_12_cursor.descend_to_byte(v336_12_byte);
    let v336_12_tail = v336_12_cursor.make_map();
    v336_12_cursor.ascend(1);
    let v336_12_head = Path::from_slice(&[v336_12_byte]);
    let v337_2: Space = singleton(&(v336_12_head));
    let v337_3: Space = intersect(&(*CONSTANT_6),&(v337_2));
    let v337_4: Space = if has_head(&(v337_3)) { singleton(&[]) } else { Space::new() };
    drop(v337_3);
    let v337_5: Space = subtract(&(*CONSTANT_5),&(v337_4));
    drop(v337_4);
    let v337_8: Space = if (v337_5).is_empty() { Space::new() } else {
      let v338_6: Path = concat_path(&(*p0),&(v336_12_head));
      let mut v338_7 = Space::new();
      let mut v338_7_cursor = (v336_12_tail).read_zipper();
      for v338_7_byte in v338_7_cursor.child_mask().iter() {
        v338_7_cursor.descend_to_byte(v338_7_byte);
        let v338_7_tail = v338_7_cursor.make_map();
        v338_7_cursor.ascend(1);
        let v338_7_head = Path::from_slice(&[v338_7_byte]);
        let v339_2: Space = singleton(&(v338_7_head));
        let v339_3: Space = intersect(&(*CONSTANT_6),&(v339_2));
        let v339_4: Space = if has_head(&(v339_3)) { singleton(&[]) } else { Space::new() };
        drop(v339_3);
        let v339_5: Space = subtract(&(*CONSTANT_5),&(v339_4));
        drop(v339_4);
        let v339_8: Space = if (v339_5).is_empty() { Space::new() } else {
          let v340_6: Path = concat_path(&(v338_6),&(v338_7_head));
          let v340_7: Space = routine_53(c, &(v340_6), &(v338_7_tail), &(*s1));
          compose(&(v339_5),&(v340_7))
        };
        drop(v339_5);
        let v339_9: Space = intersect(&(*CONSTANT_6),&(v339_2));
        drop(v339_2);
        let v339_10: Space = if has_head(&(v339_9)) { singleton(&[]) } else { Space::new() };
        drop(v339_9);
        let v339_12: Space = if (v339_10).is_empty() { Space::new() } else {
          let v341_6: Path = concat_path(&(v338_6),&(v338_7_head));
          let v341_11: Space = routine_54(c, &(v341_6), &(v338_7_tail), &(*s1));
          drop(v341_6);
          compose(&(v339_10),&(v341_11))
        };
        drop(v339_10);
        let v339_13: Space = unite(&(v339_8),&(v339_12));
        v338_7.join_into((v339_13).clone());
      }
      drop(v338_7_cursor);
      compose(&(v337_5),&(v338_7))
    };
    drop(v337_5);
    let v337_9: Space = intersect(&(*CONSTANT_6),&(v337_2));
    drop(v337_2);
    let v337_10: Space = if has_head(&(v337_9)) { singleton(&[]) } else { Space::new() };
    drop(v337_9);
    let v337_12: Space = if (v337_10).is_empty() { Space::new() } else {
      let v342_6: Path = concat_path(&(*p0),&(v336_12_head));
      let mut v342_11 = Space::new();
      let mut v342_11_cursor = (v336_12_tail).read_zipper();
      for v342_11_byte in v342_11_cursor.child_mask().iter() {
        v342_11_cursor.descend_to_byte(v342_11_byte);
        let v342_11_tail = v342_11_cursor.make_map();
        v342_11_cursor.ascend(1);
        let v342_11_head = Path::from_slice(&[v342_11_byte]);
        let v343_2: Space = singleton(&(v342_11_head));
        let v343_3: Space = intersect(&(*CONSTANT_6),&(v343_2));
        let v343_4: Space = if has_head(&(v343_3)) { singleton(&[]) } else { Space::new() };
        drop(v343_3);
        let v343_5: Space = subtract(&(*CONSTANT_5),&(v343_4));
        drop(v343_4);
        let v343_8: Space = if (v343_5).is_empty() { Space::new() } else {
          let v344_6: Path = concat_path(&(v342_6),&(v342_11_head));
          let v344_7: Space = routine_53(c, &(v344_6), &(v342_11_tail), &(*s1));
          compose(&(v343_5),&(v344_7))
        };
        drop(v343_5);
        let v343_9: Space = intersect(&(*CONSTANT_6),&(v343_2));
        drop(v343_2);
        let v343_10: Space = if has_head(&(v343_9)) { singleton(&[]) } else { Space::new() };
        drop(v343_9);
        let v343_12: Space = if (v343_10).is_empty() { Space::new() } else {
          let v345_6: Path = concat_path(&(v342_6),&(v342_11_head));
          let v345_11: Space = routine_36(c, &(v345_6), &(v342_11_tail), &(*s1));
          drop(v345_6);
          compose(&(v343_10),&(v345_11))
        };
        drop(v343_10);
        let v343_13: Space = unite(&(v343_8),&(v343_12));
        v342_11.join_into((v343_13).clone());
      }
      drop(v342_11_cursor);
      drop(v342_6);
      compose(&(v337_10),&(v342_11))
    };
    drop(v337_10);
    let v337_13: Space = unite(&(v337_8),&(v337_12));
    v336_12.join_into((v337_13).clone());
  }
  drop(v336_12_cursor);
  (v336_12).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v346_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v346_9: Space = unwrap(&(v346_7),&(*CONSTANT_4));
  drop(v346_7);
  let v346_10: Space = unwrap(&(v346_9),&(*p0));
  drop(v346_9);
  let mut v346_15 = Space::new();
  let mut v346_15_cursor = (*s0).read_zipper();
  for v346_15_byte in v346_15_cursor.child_mask().iter() {
    v346_15_cursor.descend_to_byte(v346_15_byte);
    let v346_15_tail = v346_15_cursor.make_map();
    v346_15_cursor.ascend(1);
    let v346_15_head = Path::from_slice(&[v346_15_byte]);
    let v347_2: Space = singleton(&(v346_15_head));
    let v347_3: Space = intersect(&(*CONSTANT_6),&(v347_2));
    let v347_4: Space = if has_head(&(v347_3)) { singleton(&[]) } else { Space::new() };
    drop(v347_3);
    let v347_5: Space = subtract(&(*CONSTANT_5),&(v347_4));
    drop(v347_4);
    let v347_8: Space = if (v347_5).is_empty() { Space::new() } else {
      let v348_6: Path = concat_path(&(*p0),&(v346_15_head));
      let mut v348_7 = Space::new();
      let mut v348_7_cursor = (v346_15_tail).read_zipper();
      for v348_7_byte in v348_7_cursor.child_mask().iter() {
        v348_7_cursor.descend_to_byte(v348_7_byte);
        let v348_7_tail = v348_7_cursor.make_map();
        v348_7_cursor.ascend(1);
        let v348_7_head = Path::from_slice(&[v348_7_byte]);
        let v349_2: Space = singleton(&(v348_7_head));
        let v349_3: Space = intersect(&(*CONSTANT_6),&(v349_2));
        let v349_4: Space = if has_head(&(v349_3)) { singleton(&[]) } else { Space::new() };
        drop(v349_3);
        let v349_5: Space = subtract(&(*CONSTANT_5),&(v349_4));
        drop(v349_4);
        let v349_8: Space = if (v349_5).is_empty() { Space::new() } else {
          let v350_6: Path = concat_path(&(v348_6),&(v348_7_head));
          let v350_7: Space = routine_53(c, &(v350_6), &(v348_7_tail), &(*s1));
          compose(&(v349_5),&(v350_7))
        };
        drop(v349_5);
        let v349_9: Space = intersect(&(*CONSTANT_6),&(v349_2));
        drop(v349_2);
        let v349_10: Space = if has_head(&(v349_9)) { singleton(&[]) } else { Space::new() };
        drop(v349_9);
        let v349_12: Space = if (v349_10).is_empty() { Space::new() } else {
          let v351_6: Path = concat_path(&(v348_6),&(v348_7_head));
          let v351_11: Space = routine_54(c, &(v351_6), &(v348_7_tail), &(*s1));
          drop(v351_6);
          compose(&(v349_10),&(v351_11))
        };
        drop(v349_10);
        let v349_13: Space = unite(&(v349_8),&(v349_12));
        v348_7.join_into((v349_13).clone());
      }
      drop(v348_7_cursor);
      drop(v348_6);
      compose(&(v347_5),&(v348_7))
    };
    drop(v347_5);
    let v347_9: Space = intersect(&(*CONSTANT_6),&(v347_2));
    drop(v347_2);
    let v347_10: Space = if has_head(&(v347_9)) { singleton(&[]) } else { Space::new() };
    drop(v347_9);
    let v347_13: Space = if (v347_10).is_empty() { Space::new() } else {
      let v352_11: Space = unwrap(&(v346_10),&(v346_15_head));
      let v352_12: Space = subtract(&(v352_11),&(*CONSTANT_5));
      drop(v352_11);
      compose(&(v347_10),&(v352_12))
    };
    drop(v347_10);
    let v347_14: Space = unite(&(v347_8),&(v347_13));
    drop(v347_13);
    v346_15.join_into((v347_14).clone());
  }
  drop(v346_15_cursor);
  drop(v346_10);
  (v346_15).clone()
}

fn routine_34(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v353_12 = Space::new();
  let mut v353_12_cursor = (*s0).read_zipper();
  for v353_12_byte in v353_12_cursor.child_mask().iter() {
    v353_12_cursor.descend_to_byte(v353_12_byte);
    let v353_12_tail = v353_12_cursor.make_map();
    v353_12_cursor.ascend(1);
    let v353_12_head = Path::from_slice(&[v353_12_byte]);
    let v354_2: Space = singleton(&(v353_12_head));
    let v354_3: Space = intersect(&(*CONSTANT_6),&(v354_2));
    let v354_4: Space = if has_head(&(v354_3)) { singleton(&[]) } else { Space::new() };
    drop(v354_3);
    let v354_5: Space = subtract(&(*CONSTANT_5),&(v354_4));
    drop(v354_4);
    let v354_8: Space = if (v354_5).is_empty() { Space::new() } else {
      let v355_6: Path = concat_path(&(*p0),&(v353_12_head));
      let mut v355_7 = Space::new();
      let mut v355_7_cursor = (v353_12_tail).read_zipper();
      for v355_7_byte in v355_7_cursor.child_mask().iter() {
        v355_7_cursor.descend_to_byte(v355_7_byte);
        let v355_7_tail = v355_7_cursor.make_map();
        v355_7_cursor.ascend(1);
        let v355_7_head = Path::from_slice(&[v355_7_byte]);
        let v356_2: Space = singleton(&(v355_7_head));
        let v356_3: Space = intersect(&(*CONSTANT_6),&(v356_2));
        let v356_4: Space = if has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
        drop(v356_3);
        let v356_5: Space = subtract(&(*CONSTANT_5),&(v356_4));
        drop(v356_4);
        let v356_8: Space = if (v356_5).is_empty() { Space::new() } else {
          let v357_6: Path = concat_path(&(v355_6),&(v355_7_head));
          let v357_7: Space = routine_55(c, &(v357_6), &(v355_7_tail), &(*s1));
          compose(&(v356_5),&(v357_7))
        };
        drop(v356_5);
        let v356_9: Space = intersect(&(*CONSTANT_6),&(v356_2));
        drop(v356_2);
        let v356_10: Space = if has_head(&(v356_9)) { singleton(&[]) } else { Space::new() };
        drop(v356_9);
        let v356_12: Space = if (v356_10).is_empty() { Space::new() } else {
          let v358_6: Path = concat_path(&(v355_6),&(v355_7_head));
          let v358_11: Space = routine_56(c, &(v358_6), &(v355_7_tail), &(*s1));
          drop(v358_6);
          compose(&(v356_10),&(v358_11))
        };
        drop(v356_10);
        let v356_13: Space = unite(&(v356_8),&(v356_12));
        v355_7.join_into((v356_13).clone());
      }
      drop(v355_7_cursor);
      compose(&(v354_5),&(v355_7))
    };
    drop(v354_5);
    let v354_9: Space = intersect(&(*CONSTANT_6),&(v354_2));
    drop(v354_2);
    let v354_10: Space = if has_head(&(v354_9)) { singleton(&[]) } else { Space::new() };
    drop(v354_9);
    let v354_12: Space = if (v354_10).is_empty() { Space::new() } else {
      let v359_6: Path = concat_path(&(*p0),&(v353_12_head));
      let mut v359_11 = Space::new();
      let mut v359_11_cursor = (v353_12_tail).read_zipper();
      for v359_11_byte in v359_11_cursor.child_mask().iter() {
        v359_11_cursor.descend_to_byte(v359_11_byte);
        let v359_11_tail = v359_11_cursor.make_map();
        v359_11_cursor.ascend(1);
        let v359_11_head = Path::from_slice(&[v359_11_byte]);
        let v360_2: Space = singleton(&(v359_11_head));
        let v360_3: Space = intersect(&(*CONSTANT_6),&(v360_2));
        let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
        drop(v360_3);
        let v360_5: Space = subtract(&(*CONSTANT_5),&(v360_4));
        drop(v360_4);
        let v360_8: Space = if (v360_5).is_empty() { Space::new() } else {
          let v361_6: Path = concat_path(&(v359_6),&(v359_11_head));
          let v361_7: Space = routine_55(c, &(v361_6), &(v359_11_tail), &(*s1));
          compose(&(v360_5),&(v361_7))
        };
        drop(v360_5);
        let v360_9: Space = intersect(&(*CONSTANT_6),&(v360_2));
        drop(v360_2);
        let v360_10: Space = if has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
        drop(v360_9);
        let v360_12: Space = if (v360_10).is_empty() { Space::new() } else {
          let v362_6: Path = concat_path(&(v359_6),&(v359_11_head));
          let v362_11: Space = routine_36(c, &(v362_6), &(v359_11_tail), &(*s1));
          drop(v362_6);
          compose(&(v360_10),&(v362_11))
        };
        drop(v360_10);
        let v360_13: Space = unite(&(v360_8),&(v360_12));
        v359_11.join_into((v360_13).clone());
      }
      drop(v359_11_cursor);
      drop(v359_6);
      compose(&(v354_10),&(v359_11))
    };
    drop(v354_10);
    let v354_13: Space = unite(&(v354_8),&(v354_12));
    v353_12.join_into((v354_13).clone());
  }
  drop(v353_12_cursor);
  (v353_12).clone()
}

fn routine_35(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v363_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v363_9: Space = unwrap(&(v363_7),&(*CONSTANT_4));
  drop(v363_7);
  let v363_10: Space = unwrap(&(v363_9),&(*p0));
  drop(v363_9);
  let mut v363_15 = Space::new();
  let mut v363_15_cursor = (*s0).read_zipper();
  for v363_15_byte in v363_15_cursor.child_mask().iter() {
    v363_15_cursor.descend_to_byte(v363_15_byte);
    let v363_15_tail = v363_15_cursor.make_map();
    v363_15_cursor.ascend(1);
    let v363_15_head = Path::from_slice(&[v363_15_byte]);
    let v364_2: Space = singleton(&(v363_15_head));
    let v364_3: Space = intersect(&(*CONSTANT_6),&(v364_2));
    let v364_4: Space = if has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
    drop(v364_3);
    let v364_5: Space = subtract(&(*CONSTANT_5),&(v364_4));
    drop(v364_4);
    let v364_8: Space = if (v364_5).is_empty() { Space::new() } else {
      let v365_6: Path = concat_path(&(*p0),&(v363_15_head));
      let mut v365_7 = Space::new();
      let mut v365_7_cursor = (v363_15_tail).read_zipper();
      for v365_7_byte in v365_7_cursor.child_mask().iter() {
        v365_7_cursor.descend_to_byte(v365_7_byte);
        let v365_7_tail = v365_7_cursor.make_map();
        v365_7_cursor.ascend(1);
        let v365_7_head = Path::from_slice(&[v365_7_byte]);
        let v366_2: Space = singleton(&(v365_7_head));
        let v366_3: Space = intersect(&(*CONSTANT_6),&(v366_2));
        let v366_4: Space = if has_head(&(v366_3)) { singleton(&[]) } else { Space::new() };
        drop(v366_3);
        let v366_5: Space = subtract(&(*CONSTANT_5),&(v366_4));
        drop(v366_4);
        let v366_8: Space = if (v366_5).is_empty() { Space::new() } else {
          let v367_6: Path = concat_path(&(v365_6),&(v365_7_head));
          let v367_7: Space = routine_55(c, &(v367_6), &(v365_7_tail), &(*s1));
          compose(&(v366_5),&(v367_7))
        };
        drop(v366_5);
        let v366_9: Space = intersect(&(*CONSTANT_6),&(v366_2));
        drop(v366_2);
        let v366_10: Space = if has_head(&(v366_9)) { singleton(&[]) } else { Space::new() };
        drop(v366_9);
        let v366_12: Space = if (v366_10).is_empty() { Space::new() } else {
          let v368_6: Path = concat_path(&(v365_6),&(v365_7_head));
          let v368_11: Space = routine_56(c, &(v368_6), &(v365_7_tail), &(*s1));
          drop(v368_6);
          compose(&(v366_10),&(v368_11))
        };
        drop(v366_10);
        let v366_13: Space = unite(&(v366_8),&(v366_12));
        v365_7.join_into((v366_13).clone());
      }
      drop(v365_7_cursor);
      drop(v365_6);
      compose(&(v364_5),&(v365_7))
    };
    drop(v364_5);
    let v364_9: Space = intersect(&(*CONSTANT_6),&(v364_2));
    drop(v364_2);
    let v364_10: Space = if has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
    drop(v364_9);
    let v364_13: Space = if (v364_10).is_empty() { Space::new() } else {
      let v369_11: Space = unwrap(&(v363_10),&(v363_15_head));
      let v369_12: Space = subtract(&(v369_11),&(*CONSTANT_5));
      drop(v369_11);
      compose(&(v364_10),&(v369_12))
    };
    drop(v364_10);
    let v364_14: Space = unite(&(v364_8),&(v364_13));
    drop(v364_13);
    v363_15.join_into((v364_14).clone());
  }
  drop(v363_15_cursor);
  drop(v363_10);
  (v363_15).clone()
}

fn routine_36(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v370_4: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v370_6: Space = unwrap(&(v370_4),&(*CONSTANT_4));
  drop(v370_4);
  let v370_7: Space = unwrap(&(v370_6),&(*p0));
  drop(v370_6);
  let v370_9: Space = subtract(&(v370_7),&(*CONSTANT_5));
  drop(v370_7);
  (v370_9).clone()
}

fn routine_37(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v371_7 = Space::new();
  let mut v371_7_cursor = (*s0).read_zipper();
  for v371_7_byte in v371_7_cursor.child_mask().iter() {
    v371_7_cursor.descend_to_byte(v371_7_byte);
    let v371_7_tail = v371_7_cursor.make_map();
    v371_7_cursor.ascend(1);
    let v371_7_head = Path::from_slice(&[v371_7_byte]);
    let v372_2: Space = singleton(&(v371_7_head));
    let v372_3: Space = intersect(&(*CONSTANT_6),&(v372_2));
    let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
    drop(v372_3);
    let v372_5: Space = subtract(&(*CONSTANT_5),&(v372_4));
    drop(v372_4);
    let mut v372_6 = Space::new();
    let mut v372_6_cursor = (v371_7_tail).read_zipper();
    for v372_6_byte in v372_6_cursor.child_mask().iter() {
      v372_6_cursor.descend_to_byte(v372_6_byte);
      let v372_6_tail = v372_6_cursor.make_map();
      v372_6_cursor.ascend(1);
      let v372_6_head = Path::from_slice(&[v372_6_byte]);
      let v373_2: Space = Space::new();
      v372_6.join_into((v373_2).clone());
    }
    drop(v372_6_cursor);
    let v372_7: Space = compose(&(v372_5),&(v372_6));
    drop(v372_5);
    drop(v372_6);
    let v372_8: Space = intersect(&(*CONSTANT_6),&(v372_2));
    drop(v372_2);
    let v372_9: Space = if has_head(&(v372_8)) { singleton(&[]) } else { Space::new() };
    drop(v372_8);
    let v372_12: Space = if (v372_9).is_empty() { Space::new() } else {
      let v374_10: Path = concat_path(&(*p0),&(v371_7_head));
      let mut v374_11 = Space::new();
      let mut v374_11_cursor = (v371_7_tail).read_zipper();
      for v374_11_byte in v374_11_cursor.child_mask().iter() {
        v374_11_cursor.descend_to_byte(v374_11_byte);
        let v374_11_tail = v374_11_cursor.make_map();
        v374_11_cursor.ascend(1);
        let v374_11_head = Path::from_slice(&[v374_11_byte]);
        let v375_2: Space = singleton(&(v374_11_head));
        let v375_3: Space = intersect(&(*CONSTANT_6),&(v375_2));
        drop(v375_2);
        let v375_4: Space = if has_head(&(v375_3)) { singleton(&[]) } else { Space::new() };
        drop(v375_3);
        let v375_7: Space = if (v375_4).is_empty() { Space::new() } else {
          let v376_5: Path = concat_path(&(v374_10),&(v374_11_head));
          let v376_6: Space = routine_4(c, &(v376_5), &(v374_11_tail), &(*s1));
          drop(v376_5);
          compose(&(v375_4),&(v376_6))
        };
        drop(v375_4);
        v374_11.join_into((v375_7).clone());
      }
      drop(v374_11_cursor);
      drop(v374_10);
      compose(&(v372_9),&(v374_11))
    };
    drop(v372_9);
    let v372_13: Space = unite(&(v372_7),&(v372_12));
    drop(v372_7);
    v371_7.join_into((v372_13).clone());
  }
  drop(v371_7_cursor);
  (v371_7).clone()
}

fn routine_38(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v377_9 = Space::new();
  let mut v377_9_cursor = (*s0).read_zipper();
  for v377_9_byte in v377_9_cursor.child_mask().iter() {
    v377_9_cursor.descend_to_byte(v377_9_byte);
    let v377_9_tail = v377_9_cursor.make_map();
    v377_9_cursor.ascend(1);
    let v377_9_head = Path::from_slice(&[v377_9_byte]);
    let v378_2: Space = singleton(&(v377_9_head));
    let v378_3: Space = intersect(&(*CONSTANT_6),&(v378_2));
    let v378_4: Space = if has_head(&(v378_3)) { singleton(&[]) } else { Space::new() };
    drop(v378_3);
    let v378_5: Space = subtract(&(*CONSTANT_5),&(v378_4));
    drop(v378_4);
    let mut v378_6 = Space::new();
    let mut v378_6_cursor = (v377_9_tail).read_zipper();
    for v378_6_byte in v378_6_cursor.child_mask().iter() {
      v378_6_cursor.descend_to_byte(v378_6_byte);
      let v378_6_tail = v378_6_cursor.make_map();
      v378_6_cursor.ascend(1);
      let v378_6_head = Path::from_slice(&[v378_6_byte]);
      let v379_2: Space = Space::new();
      v378_6.join_into((v379_2).clone());
    }
    drop(v378_6_cursor);
    let v378_7: Space = compose(&(v378_5),&(v378_6));
    drop(v378_5);
    drop(v378_6);
    let v378_8: Space = intersect(&(*CONSTANT_6),&(v378_2));
    drop(v378_2);
    let v378_9: Space = if has_head(&(v378_8)) { singleton(&[]) } else { Space::new() };
    drop(v378_8);
    let v378_11: Space = if (v378_9).is_empty() { Space::new() } else {
      let mut v380_10 = Space::new();
      let mut v380_10_cursor = (v377_9_tail).read_zipper();
      for v380_10_byte in v380_10_cursor.child_mask().iter() {
        v380_10_cursor.descend_to_byte(v380_10_byte);
        let v380_10_tail = v380_10_cursor.make_map();
        v380_10_cursor.ascend(1);
        let v380_10_head = Path::from_slice(&[v380_10_byte]);
        let v381_2: Space = singleton(&(v380_10_head));
        let v381_3: Space = intersect(&(*CONSTANT_6),&(v381_2));
        let v381_4: Space = if has_head(&(v381_3)) { singleton(&[]) } else { Space::new() };
        drop(v381_3);
        let v381_5: Space = subtract(&(*CONSTANT_5),&(v381_4));
        drop(v381_4);
        let v381_7: Space = if (v381_5).is_empty() { Space::new() } else {
          let v382_6: Space = routine_16(c, &(v380_10_head), &(v380_10_tail), &(*s1));
          compose(&(v381_5),&(v382_6))
        };
        drop(v381_5);
        let v381_8: Space = intersect(&(*CONSTANT_6),&(v381_2));
        drop(v381_2);
        let v381_9: Space = if has_head(&(v381_8)) { singleton(&[]) } else { Space::new() };
        drop(v381_8);
        let v381_11: Space = if (v381_9).is_empty() { Space::new() } else {
          let v383_10: Space = routine_17(c, &(v380_10_head), &(v380_10_tail), &(*s1));
          compose(&(v381_9),&(v383_10))
        };
        drop(v381_9);
        let v381_12: Space = unite(&(v381_7),&(v381_11));
        v380_10.join_into((v381_12).clone());
      }
      drop(v380_10_cursor);
      compose(&(v378_9),&(v380_10))
    };
    drop(v378_9);
    let v378_12: Path = concat_path(&(*p0),&(v377_9_head));
    let v378_13: Space = wrap(&(v378_11),&(v378_12));
    drop(v378_12);
    let v378_14: Space = unite(&(v378_7),&(v378_13));
    drop(v378_7);
    v377_9.join_into((v378_14).clone());
  }
  drop(v377_9_cursor);
  (v377_9).clone()
}

fn routine_39(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v384_12 = Space::new();
  let mut v384_12_cursor = (*s0).read_zipper();
  for v384_12_byte in v384_12_cursor.child_mask().iter() {
    v384_12_cursor.descend_to_byte(v384_12_byte);
    let v384_12_tail = v384_12_cursor.make_map();
    v384_12_cursor.ascend(1);
    let v384_12_head = Path::from_slice(&[v384_12_byte]);
    let v385_2: Space = singleton(&(v384_12_head));
    let v385_3: Space = intersect(&(*CONSTANT_6),&(v385_2));
    let v385_4: Space = if has_head(&(v385_3)) { singleton(&[]) } else { Space::new() };
    drop(v385_3);
    let v385_5: Space = subtract(&(*CONSTANT_5),&(v385_4));
    drop(v385_4);
    let v385_8: Space = if (v385_5).is_empty() { Space::new() } else {
      let v386_6: Path = concat_path(&(*p0),&(v384_12_head));
      let mut v386_7 = Space::new();
      let mut v386_7_cursor = (v384_12_tail).read_zipper();
      for v386_7_byte in v386_7_cursor.child_mask().iter() {
        v386_7_cursor.descend_to_byte(v386_7_byte);
        let v386_7_tail = v386_7_cursor.make_map();
        v386_7_cursor.ascend(1);
        let v386_7_head = Path::from_slice(&[v386_7_byte]);
        let v387_2: Space = singleton(&(v386_7_head));
        let v387_3: Space = intersect(&(*CONSTANT_6),&(v387_2));
        let v387_4: Space = if has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
        drop(v387_3);
        let v387_5: Space = subtract(&(*CONSTANT_5),&(v387_4));
        drop(v387_4);
        let v387_8: Space = if (v387_5).is_empty() { Space::new() } else {
          let v388_6: Path = concat_path(&(v386_6),&(v386_7_head));
          let v388_7: Space = routine_57(c, &(v388_6), &(v386_7_tail), &(*s1));
          compose(&(v387_5),&(v388_7))
        };
        drop(v387_5);
        let v387_9: Space = intersect(&(*CONSTANT_6),&(v387_2));
        drop(v387_2);
        let v387_10: Space = if has_head(&(v387_9)) { singleton(&[]) } else { Space::new() };
        drop(v387_9);
        let v387_12: Space = if (v387_10).is_empty() { Space::new() } else {
          let v389_6: Path = concat_path(&(v386_6),&(v386_7_head));
          let v389_11: Space = routine_58(c, &(v389_6), &(v386_7_tail), &(*s1));
          drop(v389_6);
          compose(&(v387_10),&(v389_11))
        };
        drop(v387_10);
        let v387_13: Space = unite(&(v387_8),&(v387_12));
        v386_7.join_into((v387_13).clone());
      }
      drop(v386_7_cursor);
      compose(&(v385_5),&(v386_7))
    };
    drop(v385_5);
    let v385_9: Space = intersect(&(*CONSTANT_6),&(v385_2));
    drop(v385_2);
    let v385_10: Space = if has_head(&(v385_9)) { singleton(&[]) } else { Space::new() };
    drop(v385_9);
    let v385_12: Space = if (v385_10).is_empty() { Space::new() } else {
      let v390_6: Path = concat_path(&(*p0),&(v384_12_head));
      let mut v390_11 = Space::new();
      let mut v390_11_cursor = (v384_12_tail).read_zipper();
      for v390_11_byte in v390_11_cursor.child_mask().iter() {
        v390_11_cursor.descend_to_byte(v390_11_byte);
        let v390_11_tail = v390_11_cursor.make_map();
        v390_11_cursor.ascend(1);
        let v390_11_head = Path::from_slice(&[v390_11_byte]);
        let v391_2: Space = singleton(&(v390_11_head));
        let v391_3: Space = intersect(&(*CONSTANT_6),&(v391_2));
        let v391_4: Space = if has_head(&(v391_3)) { singleton(&[]) } else { Space::new() };
        drop(v391_3);
        let v391_5: Space = subtract(&(*CONSTANT_5),&(v391_4));
        drop(v391_4);
        let v391_8: Space = if (v391_5).is_empty() { Space::new() } else {
          let v392_6: Path = concat_path(&(v390_6),&(v390_11_head));
          let v392_7: Space = routine_57(c, &(v392_6), &(v390_11_tail), &(*s1));
          compose(&(v391_5),&(v392_7))
        };
        drop(v391_5);
        let v391_9: Space = intersect(&(*CONSTANT_6),&(v391_2));
        drop(v391_2);
        let v391_10: Space = if has_head(&(v391_9)) { singleton(&[]) } else { Space::new() };
        drop(v391_9);
        let v391_12: Space = if (v391_10).is_empty() { Space::new() } else {
          let v393_6: Path = concat_path(&(v390_6),&(v390_11_head));
          let v393_11: Space = routine_20(c, &(v393_6), &(v390_11_tail), &(*s1));
          drop(v393_6);
          compose(&(v391_10),&(v393_11))
        };
        drop(v391_10);
        let v391_13: Space = unite(&(v391_8),&(v391_12));
        v390_11.join_into((v391_13).clone());
      }
      drop(v390_11_cursor);
      drop(v390_6);
      compose(&(v385_10),&(v390_11))
    };
    drop(v385_10);
    let v385_13: Space = unite(&(v385_8),&(v385_12));
    v384_12.join_into((v385_13).clone());
  }
  drop(v384_12_cursor);
  (v384_12).clone()
}

fn routine_40(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v394_7: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v394_9: Space = unwrap(&(v394_7),&(*CONSTANT_4));
  drop(v394_7);
  let v394_10: Space = unwrap(&(v394_9),&(*p0));
  drop(v394_9);
  let mut v394_15 = Space::new();
  let mut v394_15_cursor = (*s0).read_zipper();
  for v394_15_byte in v394_15_cursor.child_mask().iter() {
    v394_15_cursor.descend_to_byte(v394_15_byte);
    let v394_15_tail = v394_15_cursor.make_map();
    v394_15_cursor.ascend(1);
    let v394_15_head = Path::from_slice(&[v394_15_byte]);
    let v395_2: Space = singleton(&(v394_15_head));
    let v395_3: Space = intersect(&(*CONSTANT_6),&(v395_2));
    let v395_4: Space = if has_head(&(v395_3)) { singleton(&[]) } else { Space::new() };
    drop(v395_3);
    let v395_5: Space = subtract(&(*CONSTANT_5),&(v395_4));
    drop(v395_4);
    let v395_8: Space = if (v395_5).is_empty() { Space::new() } else {
      let v396_6: Path = concat_path(&(*p0),&(v394_15_head));
      let mut v396_7 = Space::new();
      let mut v396_7_cursor = (v394_15_tail).read_zipper();
      for v396_7_byte in v396_7_cursor.child_mask().iter() {
        v396_7_cursor.descend_to_byte(v396_7_byte);
        let v396_7_tail = v396_7_cursor.make_map();
        v396_7_cursor.ascend(1);
        let v396_7_head = Path::from_slice(&[v396_7_byte]);
        let v397_2: Space = singleton(&(v396_7_head));
        let v397_3: Space = intersect(&(*CONSTANT_6),&(v397_2));
        let v397_4: Space = if has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
        drop(v397_3);
        let v397_5: Space = subtract(&(*CONSTANT_5),&(v397_4));
        drop(v397_4);
        let v397_8: Space = if (v397_5).is_empty() { Space::new() } else {
          let v398_6: Path = concat_path(&(v396_6),&(v396_7_head));
          let v398_7: Space = routine_57(c, &(v398_6), &(v396_7_tail), &(*s1));
          compose(&(v397_5),&(v398_7))
        };
        drop(v397_5);
        let v397_9: Space = intersect(&(*CONSTANT_6),&(v397_2));
        drop(v397_2);
        let v397_10: Space = if has_head(&(v397_9)) { singleton(&[]) } else { Space::new() };
        drop(v397_9);
        let v397_12: Space = if (v397_10).is_empty() { Space::new() } else {
          let v399_6: Path = concat_path(&(v396_6),&(v396_7_head));
          let v399_11: Space = routine_58(c, &(v399_6), &(v396_7_tail), &(*s1));
          drop(v399_6);
          compose(&(v397_10),&(v399_11))
        };
        drop(v397_10);
        let v397_13: Space = unite(&(v397_8),&(v397_12));
        v396_7.join_into((v397_13).clone());
      }
      drop(v396_7_cursor);
      drop(v396_6);
      compose(&(v395_5),&(v396_7))
    };
    drop(v395_5);
    let v395_9: Space = intersect(&(*CONSTANT_6),&(v395_2));
    drop(v395_2);
    let v395_10: Space = if has_head(&(v395_9)) { singleton(&[]) } else { Space::new() };
    drop(v395_9);
    let v395_13: Space = if (v395_10).is_empty() { Space::new() } else {
      let v400_11: Space = unwrap(&(v394_10),&(v394_15_head));
      let v400_12: Space = subtract(&(v400_11),&(*CONSTANT_5));
      drop(v400_11);
      compose(&(v395_10),&(v400_12))
    };
    drop(v395_10);
    let v395_14: Space = unite(&(v395_8),&(v395_13));
    drop(v395_13);
    v394_15.join_into((v395_14).clone());
  }
  drop(v394_15_cursor);
  drop(v394_10);
  (v394_15).clone()
}

fn routine_41(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v401_12 = Space::new();
  let mut v401_12_cursor = (*s0).read_zipper();
  for v401_12_byte in v401_12_cursor.child_mask().iter() {
    v401_12_cursor.descend_to_byte(v401_12_byte);
    let v401_12_tail = v401_12_cursor.make_map();
    v401_12_cursor.ascend(1);
    let v401_12_head = Path::from_slice(&[v401_12_byte]);
    let v402_2: Space = singleton(&(v401_12_head));
    let v402_3: Space = intersect(&(*CONSTANT_6),&(v402_2));
    let v402_4: Space = if has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
    drop(v402_3);
    let v402_5: Space = subtract(&(*CONSTANT_5),&(v402_4));
    drop(v402_4);
    let v402_8: Space = if (v402_5).is_empty() { Space::new() } else {
      let v403_6: Path = concat_path(&(*p0),&(v401_12_head));
      let mut v403_7 = Space::new();
      let mut v403_7_cursor = (v401_12_tail).read_zipper();
      for v403_7_byte in v403_7_cursor.child_mask().iter() {
        v403_7_cursor.descend_to_byte(v403_7_byte);
        let v403_7_tail = v403_7_cursor.make_map();
        v403_7_cursor.ascend(1);
        let v403_7_head = Path::from_slice(&[v403_7_byte]);
        let v404_2: Space = singleton(&(v403_7_head));
        let v404_3: Space = intersect(&(*CONSTANT_6),&(v404_2));
        let v404_4: Space = if has_head(&(v404_3)) { singleton(&[]) } else { Space::new() };
        drop(v404_3);
        let v404_5: Space = subtract(&(*CONSTANT_5),&(v404_4));
        drop(v404_4);
        let v404_8: Space = if (v404_5).is_empty() { Space::new() } else {
          let v405_6: Path = concat_path(&(v403_6),&(v403_7_head));
          let v405_7: Space = routine_59(c, &(v405_6), &(v403_7_tail), &(*s1));
          compose(&(v404_5),&(v405_7))
        };
        drop(v404_5);
        let v404_9: Space = intersect(&(*CONSTANT_6),&(v404_2));
        drop(v404_2);
        let v404_10: Space = if has_head(&(v404_9)) { singleton(&[]) } else { Space::new() };
        drop(v404_9);
        let v404_12: Space = if (v404_10).is_empty() { Space::new() } else {
          let v406_6: Path = concat_path(&(v403_6),&(v403_7_head));
          let v406_11: Space = routine_60(c, &(v406_6), &(v403_7_tail), &(*s1));
          drop(v406_6);
          compose(&(v404_10),&(v406_11))
        };
        drop(v404_10);
        let v404_13: Space = unite(&(v404_8),&(v404_12));
        v403_7.join_into((v404_13).clone());
      }
      drop(v403_7_cursor);
      compose(&(v402_5),&(v403_7))
    };
    drop(v402_5);
    let v402_9: Space = intersect(&(*CONSTANT_6),&(v402_2));
    drop(v402_2);
    let v402_10: Space = if has_head(&(v402_9)) { singleton(&[]) } else { Space::new() };
    drop(v402_9);
    let v402_12: Space = if (v402_10).is_empty() { Space::new() } else {
      let v407_6: Path = concat_path(&(*p0),&(v401_12_head));
      let mut v407_11 = Space::new();
      let mut v407_11_cursor = (v401_12_tail).read_zipper();
      for v407_11_byte in v407_11_cursor.child_mask().iter() {
        v407_11_cursor.descend_to_byte(v407_11_byte);
        let v407_11_tail = v407_11_cursor.make_map();
        v407_11_cursor.ascend(1);
        let v407_11_head = Path::from_slice(&[v407_11_byte]);
        let v408_2: Space = singleton(&(v407_11_head));
        let v408_3: Space = intersect(&(*CONSTANT_6),&(v408_2));
        let v408_4: Space = if has_head(&(v408_3)) { singleton(&[]) } else { Space::new() };
        drop(v408_3);
        let v408_5: Space = subtract(&(*CONSTANT_5),&(v408_4));
        drop(v408_4);
        let v408_8: Space = if (v408_5).is_empty() { Space::new() } else {
          let v409_6: Path = concat_path(&(v407_6),&(v407_11_head));
          let v409_7: Space = routine_59(c, &(v409_6), &(v407_11_tail), &(*s1));
          compose(&(v408_5),&(v409_7))
        };
        drop(v408_5);
        let v408_9: Space = intersect(&(*CONSTANT_6),&(v408_2));
        drop(v408_2);
        let v408_10: Space = if has_head(&(v408_9)) { singleton(&[]) } else { Space::new() };
        drop(v408_9);
        let v408_12: Space = if (v408_10).is_empty() { Space::new() } else {
          let v410_6: Path = concat_path(&(v407_6),&(v407_11_head));
          let v410_11: Space = routine_20(c, &(v410_6), &(v407_11_tail), &(*s1));
          drop(v410_6);
          compose(&(v408_10),&(v410_11))
        };
        drop(v408_10);
        let v408_13: Space = unite(&(v408_8),&(v408_12));
        v407_11.join_into((v408_13).clone());
      }
      drop(v407_11_cursor);
      drop(v407_6);
      compose(&(v402_10),&(v407_11))
    };
    drop(v402_10);
    let v402_13: Space = unite(&(v402_8),&(v402_12));
    v401_12.join_into((v402_13).clone());
  }
  drop(v401_12_cursor);
  (v401_12).clone()
}

fn routine_42(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v411_7: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v411_9: Space = unwrap(&(v411_7),&(*CONSTANT_4));
  drop(v411_7);
  let v411_10: Space = unwrap(&(v411_9),&(*p0));
  drop(v411_9);
  let mut v411_15 = Space::new();
  let mut v411_15_cursor = (*s0).read_zipper();
  for v411_15_byte in v411_15_cursor.child_mask().iter() {
    v411_15_cursor.descend_to_byte(v411_15_byte);
    let v411_15_tail = v411_15_cursor.make_map();
    v411_15_cursor.ascend(1);
    let v411_15_head = Path::from_slice(&[v411_15_byte]);
    let v412_2: Space = singleton(&(v411_15_head));
    let v412_3: Space = intersect(&(*CONSTANT_6),&(v412_2));
    let v412_4: Space = if has_head(&(v412_3)) { singleton(&[]) } else { Space::new() };
    drop(v412_3);
    let v412_5: Space = subtract(&(*CONSTANT_5),&(v412_4));
    drop(v412_4);
    let v412_8: Space = if (v412_5).is_empty() { Space::new() } else {
      let v413_6: Path = concat_path(&(*p0),&(v411_15_head));
      let mut v413_7 = Space::new();
      let mut v413_7_cursor = (v411_15_tail).read_zipper();
      for v413_7_byte in v413_7_cursor.child_mask().iter() {
        v413_7_cursor.descend_to_byte(v413_7_byte);
        let v413_7_tail = v413_7_cursor.make_map();
        v413_7_cursor.ascend(1);
        let v413_7_head = Path::from_slice(&[v413_7_byte]);
        let v414_2: Space = singleton(&(v413_7_head));
        let v414_3: Space = intersect(&(*CONSTANT_6),&(v414_2));
        let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
        drop(v414_3);
        let v414_5: Space = subtract(&(*CONSTANT_5),&(v414_4));
        drop(v414_4);
        let v414_8: Space = if (v414_5).is_empty() { Space::new() } else {
          let v415_6: Path = concat_path(&(v413_6),&(v413_7_head));
          let v415_7: Space = routine_59(c, &(v415_6), &(v413_7_tail), &(*s1));
          compose(&(v414_5),&(v415_7))
        };
        drop(v414_5);
        let v414_9: Space = intersect(&(*CONSTANT_6),&(v414_2));
        drop(v414_2);
        let v414_10: Space = if has_head(&(v414_9)) { singleton(&[]) } else { Space::new() };
        drop(v414_9);
        let v414_12: Space = if (v414_10).is_empty() { Space::new() } else {
          let v416_6: Path = concat_path(&(v413_6),&(v413_7_head));
          let v416_11: Space = routine_60(c, &(v416_6), &(v413_7_tail), &(*s1));
          drop(v416_6);
          compose(&(v414_10),&(v416_11))
        };
        drop(v414_10);
        let v414_13: Space = unite(&(v414_8),&(v414_12));
        v413_7.join_into((v414_13).clone());
      }
      drop(v413_7_cursor);
      drop(v413_6);
      compose(&(v412_5),&(v413_7))
    };
    drop(v412_5);
    let v412_9: Space = intersect(&(*CONSTANT_6),&(v412_2));
    drop(v412_2);
    let v412_10: Space = if has_head(&(v412_9)) { singleton(&[]) } else { Space::new() };
    drop(v412_9);
    let v412_13: Space = if (v412_10).is_empty() { Space::new() } else {
      let v417_11: Space = unwrap(&(v411_10),&(v411_15_head));
      let v417_12: Space = subtract(&(v417_11),&(*CONSTANT_5));
      drop(v417_11);
      compose(&(v412_10),&(v417_12))
    };
    drop(v412_10);
    let v412_14: Space = unite(&(v412_8),&(v412_13));
    drop(v412_13);
    v411_15.join_into((v412_14).clone());
  }
  drop(v411_15_cursor);
  drop(v411_10);
  (v411_15).clone()
}

fn routine_43(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v418_7 = Space::new();
  let mut v418_7_cursor = (*s0).read_zipper();
  for v418_7_byte in v418_7_cursor.child_mask().iter() {
    v418_7_cursor.descend_to_byte(v418_7_byte);
    let v418_7_tail = v418_7_cursor.make_map();
    v418_7_cursor.ascend(1);
    let v418_7_head = Path::from_slice(&[v418_7_byte]);
    let v419_2: Space = singleton(&(v418_7_head));
    let v419_3: Space = intersect(&(*CONSTANT_6),&(v419_2));
    let v419_4: Space = if has_head(&(v419_3)) { singleton(&[]) } else { Space::new() };
    drop(v419_3);
    let v419_5: Space = subtract(&(*CONSTANT_5),&(v419_4));
    drop(v419_4);
    let mut v419_6 = Space::new();
    let mut v419_6_cursor = (v418_7_tail).read_zipper();
    for v419_6_byte in v419_6_cursor.child_mask().iter() {
      v419_6_cursor.descend_to_byte(v419_6_byte);
      let v419_6_tail = v419_6_cursor.make_map();
      v419_6_cursor.ascend(1);
      let v419_6_head = Path::from_slice(&[v419_6_byte]);
      let v420_2: Space = Space::new();
      v419_6.join_into((v420_2).clone());
    }
    drop(v419_6_cursor);
    let v419_7: Space = compose(&(v419_5),&(v419_6));
    drop(v419_5);
    drop(v419_6);
    let v419_8: Space = intersect(&(*CONSTANT_6),&(v419_2));
    drop(v419_2);
    let v419_9: Space = if has_head(&(v419_8)) { singleton(&[]) } else { Space::new() };
    drop(v419_8);
    let v419_12: Space = if (v419_9).is_empty() { Space::new() } else {
      let v421_10: Path = concat_path(&(*p0),&(v418_7_head));
      let mut v421_11 = Space::new();
      let mut v421_11_cursor = (v418_7_tail).read_zipper();
      for v421_11_byte in v421_11_cursor.child_mask().iter() {
        v421_11_cursor.descend_to_byte(v421_11_byte);
        let v421_11_tail = v421_11_cursor.make_map();
        v421_11_cursor.ascend(1);
        let v421_11_head = Path::from_slice(&[v421_11_byte]);
        let v422_2: Space = singleton(&(v421_11_head));
        let v422_3: Space = intersect(&(*CONSTANT_6),&(v422_2));
        drop(v422_2);
        let v422_4: Space = if has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
        drop(v422_3);
        let v422_7: Space = if (v422_4).is_empty() { Space::new() } else {
          let v423_5: Path = concat_path(&(v421_10),&(v421_11_head));
          let v423_6: Space = routine_7(c, &(v423_5), &(v421_11_tail), &(*s1));
          drop(v423_5);
          compose(&(v422_4),&(v423_6))
        };
        drop(v422_4);
        v421_11.join_into((v422_7).clone());
      }
      drop(v421_11_cursor);
      drop(v421_10);
      compose(&(v419_9),&(v421_11))
    };
    drop(v419_9);
    let v419_13: Space = unite(&(v419_7),&(v419_12));
    drop(v419_7);
    v418_7.join_into((v419_13).clone());
  }
  drop(v418_7_cursor);
  (v418_7).clone()
}

fn routine_44(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v424_9 = Space::new();
  let mut v424_9_cursor = (*s0).read_zipper();
  for v424_9_byte in v424_9_cursor.child_mask().iter() {
    v424_9_cursor.descend_to_byte(v424_9_byte);
    let v424_9_tail = v424_9_cursor.make_map();
    v424_9_cursor.ascend(1);
    let v424_9_head = Path::from_slice(&[v424_9_byte]);
    let v425_2: Space = singleton(&(v424_9_head));
    let v425_3: Space = intersect(&(*CONSTANT_6),&(v425_2));
    let v425_4: Space = if has_head(&(v425_3)) { singleton(&[]) } else { Space::new() };
    drop(v425_3);
    let v425_5: Space = subtract(&(*CONSTANT_5),&(v425_4));
    drop(v425_4);
    let mut v425_6 = Space::new();
    let mut v425_6_cursor = (v424_9_tail).read_zipper();
    for v425_6_byte in v425_6_cursor.child_mask().iter() {
      v425_6_cursor.descend_to_byte(v425_6_byte);
      let v425_6_tail = v425_6_cursor.make_map();
      v425_6_cursor.ascend(1);
      let v425_6_head = Path::from_slice(&[v425_6_byte]);
      let v426_2: Space = Space::new();
      v425_6.join_into((v426_2).clone());
    }
    drop(v425_6_cursor);
    let v425_7: Space = compose(&(v425_5),&(v425_6));
    drop(v425_5);
    drop(v425_6);
    let v425_8: Space = intersect(&(*CONSTANT_6),&(v425_2));
    drop(v425_2);
    let v425_9: Space = if has_head(&(v425_8)) { singleton(&[]) } else { Space::new() };
    drop(v425_8);
    let v425_11: Space = if (v425_9).is_empty() { Space::new() } else {
      let mut v427_10 = Space::new();
      let mut v427_10_cursor = (v424_9_tail).read_zipper();
      for v427_10_byte in v427_10_cursor.child_mask().iter() {
        v427_10_cursor.descend_to_byte(v427_10_byte);
        let v427_10_tail = v427_10_cursor.make_map();
        v427_10_cursor.ascend(1);
        let v427_10_head = Path::from_slice(&[v427_10_byte]);
        let v428_2: Space = singleton(&(v427_10_head));
        let v428_3: Space = intersect(&(*CONSTANT_6),&(v428_2));
        let v428_4: Space = if has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
        drop(v428_3);
        let v428_5: Space = subtract(&(*CONSTANT_5),&(v428_4));
        drop(v428_4);
        let v428_7: Space = if (v428_5).is_empty() { Space::new() } else {
          let v429_6: Space = routine_23(c, &(v427_10_head), &(v427_10_tail), &(*s1));
          compose(&(v428_5),&(v429_6))
        };
        drop(v428_5);
        let v428_8: Space = intersect(&(*CONSTANT_6),&(v428_2));
        drop(v428_2);
        let v428_9: Space = if has_head(&(v428_8)) { singleton(&[]) } else { Space::new() };
        drop(v428_8);
        let v428_11: Space = if (v428_9).is_empty() { Space::new() } else {
          let v430_10: Space = routine_24(c, &(v427_10_head), &(v427_10_tail), &(*s1));
          compose(&(v428_9),&(v430_10))
        };
        drop(v428_9);
        let v428_12: Space = unite(&(v428_7),&(v428_11));
        v427_10.join_into((v428_12).clone());
      }
      drop(v427_10_cursor);
      compose(&(v425_9),&(v427_10))
    };
    drop(v425_9);
    let v425_12: Path = concat_path(&(*p0),&(v424_9_head));
    let v425_13: Space = wrap(&(v425_11),&(v425_12));
    drop(v425_12);
    let v425_14: Space = unite(&(v425_7),&(v425_13));
    drop(v425_7);
    v424_9.join_into((v425_14).clone());
  }
  drop(v424_9_cursor);
  (v424_9).clone()
}

fn routine_45(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v431_12 = Space::new();
  let mut v431_12_cursor = (*s0).read_zipper();
  for v431_12_byte in v431_12_cursor.child_mask().iter() {
    v431_12_cursor.descend_to_byte(v431_12_byte);
    let v431_12_tail = v431_12_cursor.make_map();
    v431_12_cursor.ascend(1);
    let v431_12_head = Path::from_slice(&[v431_12_byte]);
    let v432_2: Space = singleton(&(v431_12_head));
    let v432_3: Space = intersect(&(*CONSTANT_6),&(v432_2));
    let v432_4: Space = if has_head(&(v432_3)) { singleton(&[]) } else { Space::new() };
    drop(v432_3);
    let v432_5: Space = subtract(&(*CONSTANT_5),&(v432_4));
    drop(v432_4);
    let v432_8: Space = if (v432_5).is_empty() { Space::new() } else {
      let v433_6: Path = concat_path(&(*p0),&(v431_12_head));
      let mut v433_7 = Space::new();
      let mut v433_7_cursor = (v431_12_tail).read_zipper();
      for v433_7_byte in v433_7_cursor.child_mask().iter() {
        v433_7_cursor.descend_to_byte(v433_7_byte);
        let v433_7_tail = v433_7_cursor.make_map();
        v433_7_cursor.ascend(1);
        let v433_7_head = Path::from_slice(&[v433_7_byte]);
        let v434_2: Space = singleton(&(v433_7_head));
        let v434_3: Space = intersect(&(*CONSTANT_6),&(v434_2));
        let v434_4: Space = if has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
        drop(v434_3);
        let v434_5: Space = subtract(&(*CONSTANT_5),&(v434_4));
        drop(v434_4);
        let v434_8: Space = if (v434_5).is_empty() { Space::new() } else {
          let v435_6: Path = concat_path(&(v433_6),&(v433_7_head));
          let v435_7: Space = routine_61(c, &(v435_6), &(v433_7_tail), &(*s1));
          compose(&(v434_5),&(v435_7))
        };
        drop(v434_5);
        let v434_9: Space = intersect(&(*CONSTANT_6),&(v434_2));
        drop(v434_2);
        let v434_10: Space = if has_head(&(v434_9)) { singleton(&[]) } else { Space::new() };
        drop(v434_9);
        let v434_12: Space = if (v434_10).is_empty() { Space::new() } else {
          let v436_6: Path = concat_path(&(v433_6),&(v433_7_head));
          let v436_11: Space = routine_62(c, &(v436_6), &(v433_7_tail), &(*s1));
          drop(v436_6);
          compose(&(v434_10),&(v436_11))
        };
        drop(v434_10);
        let v434_13: Space = unite(&(v434_8),&(v434_12));
        v433_7.join_into((v434_13).clone());
      }
      drop(v433_7_cursor);
      compose(&(v432_5),&(v433_7))
    };
    drop(v432_5);
    let v432_9: Space = intersect(&(*CONSTANT_6),&(v432_2));
    drop(v432_2);
    let v432_10: Space = if has_head(&(v432_9)) { singleton(&[]) } else { Space::new() };
    drop(v432_9);
    let v432_12: Space = if (v432_10).is_empty() { Space::new() } else {
      let v437_6: Path = concat_path(&(*p0),&(v431_12_head));
      let mut v437_11 = Space::new();
      let mut v437_11_cursor = (v431_12_tail).read_zipper();
      for v437_11_byte in v437_11_cursor.child_mask().iter() {
        v437_11_cursor.descend_to_byte(v437_11_byte);
        let v437_11_tail = v437_11_cursor.make_map();
        v437_11_cursor.ascend(1);
        let v437_11_head = Path::from_slice(&[v437_11_byte]);
        let v438_2: Space = singleton(&(v437_11_head));
        let v438_3: Space = intersect(&(*CONSTANT_6),&(v438_2));
        let v438_4: Space = if has_head(&(v438_3)) { singleton(&[]) } else { Space::new() };
        drop(v438_3);
        let v438_5: Space = subtract(&(*CONSTANT_5),&(v438_4));
        drop(v438_4);
        let v438_8: Space = if (v438_5).is_empty() { Space::new() } else {
          let v439_6: Path = concat_path(&(v437_6),&(v437_11_head));
          let v439_7: Space = routine_61(c, &(v439_6), &(v437_11_tail), &(*s1));
          compose(&(v438_5),&(v439_7))
        };
        drop(v438_5);
        let v438_9: Space = intersect(&(*CONSTANT_6),&(v438_2));
        drop(v438_2);
        let v438_10: Space = if has_head(&(v438_9)) { singleton(&[]) } else { Space::new() };
        drop(v438_9);
        let v438_12: Space = if (v438_10).is_empty() { Space::new() } else {
          let v440_6: Path = concat_path(&(v437_6),&(v437_11_head));
          let v440_11: Space = routine_27(c, &(v440_6), &(v437_11_tail), &(*s1));
          drop(v440_6);
          compose(&(v438_10),&(v440_11))
        };
        drop(v438_10);
        let v438_13: Space = unite(&(v438_8),&(v438_12));
        v437_11.join_into((v438_13).clone());
      }
      drop(v437_11_cursor);
      drop(v437_6);
      compose(&(v432_10),&(v437_11))
    };
    drop(v432_10);
    let v432_13: Space = unite(&(v432_8),&(v432_12));
    v431_12.join_into((v432_13).clone());
  }
  drop(v431_12_cursor);
  (v431_12).clone()
}

fn routine_46(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v441_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v441_9: Space = unwrap(&(v441_7),&(*CONSTANT_4));
  drop(v441_7);
  let v441_10: Space = unwrap(&(v441_9),&(*p0));
  drop(v441_9);
  let mut v441_15 = Space::new();
  let mut v441_15_cursor = (*s0).read_zipper();
  for v441_15_byte in v441_15_cursor.child_mask().iter() {
    v441_15_cursor.descend_to_byte(v441_15_byte);
    let v441_15_tail = v441_15_cursor.make_map();
    v441_15_cursor.ascend(1);
    let v441_15_head = Path::from_slice(&[v441_15_byte]);
    let v442_2: Space = singleton(&(v441_15_head));
    let v442_3: Space = intersect(&(*CONSTANT_6),&(v442_2));
    let v442_4: Space = if has_head(&(v442_3)) { singleton(&[]) } else { Space::new() };
    drop(v442_3);
    let v442_5: Space = subtract(&(*CONSTANT_5),&(v442_4));
    drop(v442_4);
    let v442_8: Space = if (v442_5).is_empty() { Space::new() } else {
      let v443_6: Path = concat_path(&(*p0),&(v441_15_head));
      let mut v443_7 = Space::new();
      let mut v443_7_cursor = (v441_15_tail).read_zipper();
      for v443_7_byte in v443_7_cursor.child_mask().iter() {
        v443_7_cursor.descend_to_byte(v443_7_byte);
        let v443_7_tail = v443_7_cursor.make_map();
        v443_7_cursor.ascend(1);
        let v443_7_head = Path::from_slice(&[v443_7_byte]);
        let v444_2: Space = singleton(&(v443_7_head));
        let v444_3: Space = intersect(&(*CONSTANT_6),&(v444_2));
        let v444_4: Space = if has_head(&(v444_3)) { singleton(&[]) } else { Space::new() };
        drop(v444_3);
        let v444_5: Space = subtract(&(*CONSTANT_5),&(v444_4));
        drop(v444_4);
        let v444_8: Space = if (v444_5).is_empty() { Space::new() } else {
          let v445_6: Path = concat_path(&(v443_6),&(v443_7_head));
          let v445_7: Space = routine_61(c, &(v445_6), &(v443_7_tail), &(*s1));
          compose(&(v444_5),&(v445_7))
        };
        drop(v444_5);
        let v444_9: Space = intersect(&(*CONSTANT_6),&(v444_2));
        drop(v444_2);
        let v444_10: Space = if has_head(&(v444_9)) { singleton(&[]) } else { Space::new() };
        drop(v444_9);
        let v444_12: Space = if (v444_10).is_empty() { Space::new() } else {
          let v446_6: Path = concat_path(&(v443_6),&(v443_7_head));
          let v446_11: Space = routine_62(c, &(v446_6), &(v443_7_tail), &(*s1));
          drop(v446_6);
          compose(&(v444_10),&(v446_11))
        };
        drop(v444_10);
        let v444_13: Space = unite(&(v444_8),&(v444_12));
        v443_7.join_into((v444_13).clone());
      }
      drop(v443_7_cursor);
      drop(v443_6);
      compose(&(v442_5),&(v443_7))
    };
    drop(v442_5);
    let v442_9: Space = intersect(&(*CONSTANT_6),&(v442_2));
    drop(v442_2);
    let v442_10: Space = if has_head(&(v442_9)) { singleton(&[]) } else { Space::new() };
    drop(v442_9);
    let v442_13: Space = if (v442_10).is_empty() { Space::new() } else {
      let v447_11: Space = unwrap(&(v441_10),&(v441_15_head));
      let v447_12: Space = subtract(&(v447_11),&(*CONSTANT_5));
      drop(v447_11);
      compose(&(v442_10),&(v447_12))
    };
    drop(v442_10);
    let v442_14: Space = unite(&(v442_8),&(v442_13));
    drop(v442_13);
    v441_15.join_into((v442_14).clone());
  }
  drop(v441_15_cursor);
  drop(v441_10);
  (v441_15).clone()
}

fn routine_47(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v448_12 = Space::new();
  let mut v448_12_cursor = (*s0).read_zipper();
  for v448_12_byte in v448_12_cursor.child_mask().iter() {
    v448_12_cursor.descend_to_byte(v448_12_byte);
    let v448_12_tail = v448_12_cursor.make_map();
    v448_12_cursor.ascend(1);
    let v448_12_head = Path::from_slice(&[v448_12_byte]);
    let v449_2: Space = singleton(&(v448_12_head));
    let v449_3: Space = intersect(&(*CONSTANT_6),&(v449_2));
    let v449_4: Space = if has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
    drop(v449_3);
    let v449_5: Space = subtract(&(*CONSTANT_5),&(v449_4));
    drop(v449_4);
    let v449_8: Space = if (v449_5).is_empty() { Space::new() } else {
      let v450_6: Path = concat_path(&(*p0),&(v448_12_head));
      let mut v450_7 = Space::new();
      let mut v450_7_cursor = (v448_12_tail).read_zipper();
      for v450_7_byte in v450_7_cursor.child_mask().iter() {
        v450_7_cursor.descend_to_byte(v450_7_byte);
        let v450_7_tail = v450_7_cursor.make_map();
        v450_7_cursor.ascend(1);
        let v450_7_head = Path::from_slice(&[v450_7_byte]);
        let v451_2: Space = singleton(&(v450_7_head));
        let v451_3: Space = intersect(&(*CONSTANT_6),&(v451_2));
        let v451_4: Space = if has_head(&(v451_3)) { singleton(&[]) } else { Space::new() };
        drop(v451_3);
        let v451_5: Space = subtract(&(*CONSTANT_5),&(v451_4));
        drop(v451_4);
        let v451_8: Space = if (v451_5).is_empty() { Space::new() } else {
          let v452_6: Path = concat_path(&(v450_6),&(v450_7_head));
          let v452_7: Space = routine_63(c, &(v452_6), &(v450_7_tail), &(*s1));
          compose(&(v451_5),&(v452_7))
        };
        drop(v451_5);
        let v451_9: Space = intersect(&(*CONSTANT_6),&(v451_2));
        drop(v451_2);
        let v451_10: Space = if has_head(&(v451_9)) { singleton(&[]) } else { Space::new() };
        drop(v451_9);
        let v451_12: Space = if (v451_10).is_empty() { Space::new() } else {
          let v453_6: Path = concat_path(&(v450_6),&(v450_7_head));
          let v453_11: Space = routine_64(c, &(v453_6), &(v450_7_tail), &(*s1));
          drop(v453_6);
          compose(&(v451_10),&(v453_11))
        };
        drop(v451_10);
        let v451_13: Space = unite(&(v451_8),&(v451_12));
        v450_7.join_into((v451_13).clone());
      }
      drop(v450_7_cursor);
      compose(&(v449_5),&(v450_7))
    };
    drop(v449_5);
    let v449_9: Space = intersect(&(*CONSTANT_6),&(v449_2));
    drop(v449_2);
    let v449_10: Space = if has_head(&(v449_9)) { singleton(&[]) } else { Space::new() };
    drop(v449_9);
    let v449_12: Space = if (v449_10).is_empty() { Space::new() } else {
      let v454_6: Path = concat_path(&(*p0),&(v448_12_head));
      let mut v454_11 = Space::new();
      let mut v454_11_cursor = (v448_12_tail).read_zipper();
      for v454_11_byte in v454_11_cursor.child_mask().iter() {
        v454_11_cursor.descend_to_byte(v454_11_byte);
        let v454_11_tail = v454_11_cursor.make_map();
        v454_11_cursor.ascend(1);
        let v454_11_head = Path::from_slice(&[v454_11_byte]);
        let v455_2: Space = singleton(&(v454_11_head));
        let v455_3: Space = intersect(&(*CONSTANT_6),&(v455_2));
        let v455_4: Space = if has_head(&(v455_3)) { singleton(&[]) } else { Space::new() };
        drop(v455_3);
        let v455_5: Space = subtract(&(*CONSTANT_5),&(v455_4));
        drop(v455_4);
        let v455_8: Space = if (v455_5).is_empty() { Space::new() } else {
          let v456_6: Path = concat_path(&(v454_6),&(v454_11_head));
          let v456_7: Space = routine_63(c, &(v456_6), &(v454_11_tail), &(*s1));
          compose(&(v455_5),&(v456_7))
        };
        drop(v455_5);
        let v455_9: Space = intersect(&(*CONSTANT_6),&(v455_2));
        drop(v455_2);
        let v455_10: Space = if has_head(&(v455_9)) { singleton(&[]) } else { Space::new() };
        drop(v455_9);
        let v455_12: Space = if (v455_10).is_empty() { Space::new() } else {
          let v457_6: Path = concat_path(&(v454_6),&(v454_11_head));
          let v457_11: Space = routine_27(c, &(v457_6), &(v454_11_tail), &(*s1));
          drop(v457_6);
          compose(&(v455_10),&(v457_11))
        };
        drop(v455_10);
        let v455_13: Space = unite(&(v455_8),&(v455_12));
        v454_11.join_into((v455_13).clone());
      }
      drop(v454_11_cursor);
      drop(v454_6);
      compose(&(v449_10),&(v454_11))
    };
    drop(v449_10);
    let v449_13: Space = unite(&(v449_8),&(v449_12));
    v448_12.join_into((v449_13).clone());
  }
  drop(v448_12_cursor);
  (v448_12).clone()
}

fn routine_48(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v458_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v458_9: Space = unwrap(&(v458_7),&(*CONSTANT_4));
  drop(v458_7);
  let v458_10: Space = unwrap(&(v458_9),&(*p0));
  drop(v458_9);
  let mut v458_15 = Space::new();
  let mut v458_15_cursor = (*s0).read_zipper();
  for v458_15_byte in v458_15_cursor.child_mask().iter() {
    v458_15_cursor.descend_to_byte(v458_15_byte);
    let v458_15_tail = v458_15_cursor.make_map();
    v458_15_cursor.ascend(1);
    let v458_15_head = Path::from_slice(&[v458_15_byte]);
    let v459_2: Space = singleton(&(v458_15_head));
    let v459_3: Space = intersect(&(*CONSTANT_6),&(v459_2));
    let v459_4: Space = if has_head(&(v459_3)) { singleton(&[]) } else { Space::new() };
    drop(v459_3);
    let v459_5: Space = subtract(&(*CONSTANT_5),&(v459_4));
    drop(v459_4);
    let v459_8: Space = if (v459_5).is_empty() { Space::new() } else {
      let v460_6: Path = concat_path(&(*p0),&(v458_15_head));
      let mut v460_7 = Space::new();
      let mut v460_7_cursor = (v458_15_tail).read_zipper();
      for v460_7_byte in v460_7_cursor.child_mask().iter() {
        v460_7_cursor.descend_to_byte(v460_7_byte);
        let v460_7_tail = v460_7_cursor.make_map();
        v460_7_cursor.ascend(1);
        let v460_7_head = Path::from_slice(&[v460_7_byte]);
        let v461_2: Space = singleton(&(v460_7_head));
        let v461_3: Space = intersect(&(*CONSTANT_6),&(v461_2));
        let v461_4: Space = if has_head(&(v461_3)) { singleton(&[]) } else { Space::new() };
        drop(v461_3);
        let v461_5: Space = subtract(&(*CONSTANT_5),&(v461_4));
        drop(v461_4);
        let v461_8: Space = if (v461_5).is_empty() { Space::new() } else {
          let v462_6: Path = concat_path(&(v460_6),&(v460_7_head));
          let v462_7: Space = routine_63(c, &(v462_6), &(v460_7_tail), &(*s1));
          compose(&(v461_5),&(v462_7))
        };
        drop(v461_5);
        let v461_9: Space = intersect(&(*CONSTANT_6),&(v461_2));
        drop(v461_2);
        let v461_10: Space = if has_head(&(v461_9)) { singleton(&[]) } else { Space::new() };
        drop(v461_9);
        let v461_12: Space = if (v461_10).is_empty() { Space::new() } else {
          let v463_6: Path = concat_path(&(v460_6),&(v460_7_head));
          let v463_11: Space = routine_64(c, &(v463_6), &(v460_7_tail), &(*s1));
          drop(v463_6);
          compose(&(v461_10),&(v463_11))
        };
        drop(v461_10);
        let v461_13: Space = unite(&(v461_8),&(v461_12));
        v460_7.join_into((v461_13).clone());
      }
      drop(v460_7_cursor);
      drop(v460_6);
      compose(&(v459_5),&(v460_7))
    };
    drop(v459_5);
    let v459_9: Space = intersect(&(*CONSTANT_6),&(v459_2));
    drop(v459_2);
    let v459_10: Space = if has_head(&(v459_9)) { singleton(&[]) } else { Space::new() };
    drop(v459_9);
    let v459_13: Space = if (v459_10).is_empty() { Space::new() } else {
      let v464_11: Space = unwrap(&(v458_10),&(v458_15_head));
      let v464_12: Space = subtract(&(v464_11),&(*CONSTANT_5));
      drop(v464_11);
      compose(&(v459_10),&(v464_12))
    };
    drop(v459_10);
    let v459_14: Space = unite(&(v459_8),&(v459_13));
    drop(v459_13);
    v458_15.join_into((v459_14).clone());
  }
  drop(v458_15_cursor);
  drop(v458_10);
  (v458_15).clone()
}

fn routine_49(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v465_6 = Space::new();
  let mut v465_6_cursor = (*s0).read_zipper();
  for v465_6_byte in v465_6_cursor.child_mask().iter() {
    v465_6_cursor.descend_to_byte(v465_6_byte);
    let v465_6_tail = v465_6_cursor.make_map();
    v465_6_cursor.ascend(1);
    let v465_6_head = Path::from_slice(&[v465_6_byte]);
    let v466_2: Space = singleton(&(v465_6_head));
    let v466_3: Space = intersect(&(*CONSTANT_6),&(v466_2));
    let v466_4: Space = if has_head(&(v466_3)) { singleton(&[]) } else { Space::new() };
    drop(v466_3);
    let v466_5: Space = subtract(&(*CONSTANT_5),&(v466_4));
    drop(v466_4);
    let mut v466_6 = Space::new();
    let mut v466_6_cursor = (v465_6_tail).read_zipper();
    for v466_6_byte in v466_6_cursor.child_mask().iter() {
      v466_6_cursor.descend_to_byte(v466_6_byte);
      let v466_6_tail = v466_6_cursor.make_map();
      v466_6_cursor.ascend(1);
      let v466_6_head = Path::from_slice(&[v466_6_byte]);
      let v467_2: Space = Space::new();
      v466_6.join_into((v467_2).clone());
    }
    drop(v466_6_cursor);
    let v466_7: Space = compose(&(v466_5),&(v466_6));
    drop(v466_5);
    drop(v466_6);
    let v466_8: Space = intersect(&(*CONSTANT_6),&(v466_2));
    drop(v466_2);
    let v466_9: Space = if has_head(&(v466_8)) { singleton(&[]) } else { Space::new() };
    drop(v466_8);
    let v466_12: Space = if (v466_9).is_empty() { Space::new() } else {
      let v468_10: Path = concat_path(&(*p0),&(v465_6_head));
      let mut v468_11 = Space::new();
      let mut v468_11_cursor = (v465_6_tail).read_zipper();
      for v468_11_byte in v468_11_cursor.child_mask().iter() {
        v468_11_cursor.descend_to_byte(v468_11_byte);
        let v468_11_tail = v468_11_cursor.make_map();
        v468_11_cursor.ascend(1);
        let v468_11_head = Path::from_slice(&[v468_11_byte]);
        let v469_2: Space = singleton(&(v468_11_head));
        let v469_3: Space = intersect(&(*CONSTANT_6),&(v469_2));
        drop(v469_2);
        let v469_4: Space = if has_head(&(v469_3)) { singleton(&[]) } else { Space::new() };
        drop(v469_3);
        let v469_7: Space = if (v469_4).is_empty() { Space::new() } else {
          let v470_5: Path = concat_path(&(v468_10),&(v468_11_head));
          let v470_6: Space = routine_10(c, &(v470_5), &(v468_11_tail));
          drop(v470_5);
          compose(&(v469_4),&(v470_6))
        };
        drop(v469_4);
        v468_11.join_into((v469_7).clone());
      }
      drop(v468_11_cursor);
      drop(v468_10);
      compose(&(v466_9),&(v468_11))
    };
    drop(v466_9);
    let v466_13: Space = unite(&(v466_7),&(v466_12));
    drop(v466_7);
    v465_6.join_into((v466_13).clone());
  }
  drop(v465_6_cursor);
  (v465_6).clone()
}

fn routine_50(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v471_6 = Space::new();
  let mut v471_6_cursor = (*s0).read_zipper();
  for v471_6_byte in v471_6_cursor.child_mask().iter() {
    v471_6_cursor.descend_to_byte(v471_6_byte);
    let v471_6_tail = v471_6_cursor.make_map();
    v471_6_cursor.ascend(1);
    let v471_6_head = Path::from_slice(&[v471_6_byte]);
    let v472_2: Space = singleton(&(v471_6_head));
    let v472_3: Space = intersect(&(*CONSTANT_6),&(v472_2));
    let v472_4: Space = if has_head(&(v472_3)) { singleton(&[]) } else { Space::new() };
    drop(v472_3);
    let v472_5: Space = subtract(&(*CONSTANT_5),&(v472_4));
    drop(v472_4);
    let mut v472_6 = Space::new();
    let mut v472_6_cursor = (v471_6_tail).read_zipper();
    for v472_6_byte in v472_6_cursor.child_mask().iter() {
      v472_6_cursor.descend_to_byte(v472_6_byte);
      let v472_6_tail = v472_6_cursor.make_map();
      v472_6_cursor.ascend(1);
      let v472_6_head = Path::from_slice(&[v472_6_byte]);
      let v473_2: Space = Space::new();
      v472_6.join_into((v473_2).clone());
    }
    drop(v472_6_cursor);
    let v472_7: Space = compose(&(v472_5),&(v472_6));
    drop(v472_5);
    drop(v472_6);
    let v472_8: Space = intersect(&(*CONSTANT_6),&(v472_2));
    drop(v472_2);
    let v472_9: Space = if has_head(&(v472_8)) { singleton(&[]) } else { Space::new() };
    drop(v472_8);
    let v472_10: Space = subtract(&(v471_6_tail),&(*CONSTANT_5));
    let v472_11: Space = compose(&(v472_9),&(v472_10));
    drop(v472_9);
    drop(v472_10);
    let v472_12: Path = concat_path(&(*p0),&(v471_6_head));
    let v472_13: Space = wrap(&(v472_11),&(v472_12));
    drop(v472_11);
    drop(v472_12);
    let v472_14: Space = unite(&(v472_7),&(v472_13));
    drop(v472_7);
    drop(v472_13);
    v471_6.join_into((v472_14).clone());
  }
  drop(v471_6_cursor);
  (v471_6).clone()
}

fn routine_51(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v474_7 = Space::new();
  let mut v474_7_cursor = (*s0).read_zipper();
  for v474_7_byte in v474_7_cursor.child_mask().iter() {
    v474_7_cursor.descend_to_byte(v474_7_byte);
    let v474_7_tail = v474_7_cursor.make_map();
    v474_7_cursor.ascend(1);
    let v474_7_head = Path::from_slice(&[v474_7_byte]);
    let v475_2: Space = singleton(&(v474_7_head));
    let v475_3: Space = intersect(&(*CONSTANT_6),&(v475_2));
    let v475_4: Space = if has_head(&(v475_3)) { singleton(&[]) } else { Space::new() };
    drop(v475_3);
    let v475_5: Space = subtract(&(*CONSTANT_5),&(v475_4));
    drop(v475_4);
    let mut v475_6 = Space::new();
    let mut v475_6_cursor = (v474_7_tail).read_zipper();
    for v475_6_byte in v475_6_cursor.child_mask().iter() {
      v475_6_cursor.descend_to_byte(v475_6_byte);
      let v475_6_tail = v475_6_cursor.make_map();
      v475_6_cursor.ascend(1);
      let v475_6_head = Path::from_slice(&[v475_6_byte]);
      let v476_2: Space = Space::new();
      v475_6.join_into((v476_2).clone());
    }
    drop(v475_6_cursor);
    let v475_7: Space = compose(&(v475_5),&(v475_6));
    drop(v475_5);
    drop(v475_6);
    let v475_8: Space = intersect(&(*CONSTANT_6),&(v475_2));
    drop(v475_2);
    let v475_9: Space = if has_head(&(v475_8)) { singleton(&[]) } else { Space::new() };
    drop(v475_8);
    let v475_12: Space = if (v475_9).is_empty() { Space::new() } else {
      let v477_10: Path = concat_path(&(*p0),&(v474_7_head));
      let mut v477_11 = Space::new();
      let mut v477_11_cursor = (v474_7_tail).read_zipper();
      for v477_11_byte in v477_11_cursor.child_mask().iter() {
        v477_11_cursor.descend_to_byte(v477_11_byte);
        let v477_11_tail = v477_11_cursor.make_map();
        v477_11_cursor.ascend(1);
        let v477_11_head = Path::from_slice(&[v477_11_byte]);
        let v478_2: Space = singleton(&(v477_11_head));
        let v478_3: Space = intersect(&(*CONSTANT_6),&(v478_2));
        drop(v478_2);
        let v478_4: Space = if has_head(&(v478_3)) { singleton(&[]) } else { Space::new() };
        drop(v478_3);
        let v478_7: Space = if (v478_4).is_empty() { Space::new() } else {
          let v479_5: Path = concat_path(&(v477_10),&(v477_11_head));
          let v479_6: Space = routine_13(c, &(v479_5), &(v477_11_tail), &(*s1));
          drop(v479_5);
          compose(&(v478_4),&(v479_6))
        };
        drop(v478_4);
        v477_11.join_into((v478_7).clone());
      }
      drop(v477_11_cursor);
      drop(v477_10);
      compose(&(v475_9),&(v477_11))
    };
    drop(v475_9);
    let v475_13: Space = unite(&(v475_7),&(v475_12));
    drop(v475_7);
    v474_7.join_into((v475_13).clone());
  }
  drop(v474_7_cursor);
  (v474_7).clone()
}

fn routine_52(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v480_9 = Space::new();
  let mut v480_9_cursor = (*s0).read_zipper();
  for v480_9_byte in v480_9_cursor.child_mask().iter() {
    v480_9_cursor.descend_to_byte(v480_9_byte);
    let v480_9_tail = v480_9_cursor.make_map();
    v480_9_cursor.ascend(1);
    let v480_9_head = Path::from_slice(&[v480_9_byte]);
    let v481_2: Space = singleton(&(v480_9_head));
    let v481_3: Space = intersect(&(*CONSTANT_6),&(v481_2));
    let v481_4: Space = if has_head(&(v481_3)) { singleton(&[]) } else { Space::new() };
    drop(v481_3);
    let v481_5: Space = subtract(&(*CONSTANT_5),&(v481_4));
    drop(v481_4);
    let mut v481_6 = Space::new();
    let mut v481_6_cursor = (v480_9_tail).read_zipper();
    for v481_6_byte in v481_6_cursor.child_mask().iter() {
      v481_6_cursor.descend_to_byte(v481_6_byte);
      let v481_6_tail = v481_6_cursor.make_map();
      v481_6_cursor.ascend(1);
      let v481_6_head = Path::from_slice(&[v481_6_byte]);
      let v482_2: Space = Space::new();
      v481_6.join_into((v482_2).clone());
    }
    drop(v481_6_cursor);
    let v481_7: Space = compose(&(v481_5),&(v481_6));
    drop(v481_5);
    drop(v481_6);
    let v481_8: Space = intersect(&(*CONSTANT_6),&(v481_2));
    drop(v481_2);
    let v481_9: Space = if has_head(&(v481_8)) { singleton(&[]) } else { Space::new() };
    drop(v481_8);
    let v481_11: Space = if (v481_9).is_empty() { Space::new() } else {
      let mut v483_10 = Space::new();
      let mut v483_10_cursor = (v480_9_tail).read_zipper();
      for v483_10_byte in v483_10_cursor.child_mask().iter() {
        v483_10_cursor.descend_to_byte(v483_10_byte);
        let v483_10_tail = v483_10_cursor.make_map();
        v483_10_cursor.ascend(1);
        let v483_10_head = Path::from_slice(&[v483_10_byte]);
        let v484_2: Space = singleton(&(v483_10_head));
        let v484_3: Space = intersect(&(*CONSTANT_6),&(v484_2));
        let v484_4: Space = if has_head(&(v484_3)) { singleton(&[]) } else { Space::new() };
        drop(v484_3);
        let v484_5: Space = subtract(&(*CONSTANT_5),&(v484_4));
        drop(v484_4);
        let v484_7: Space = if (v484_5).is_empty() { Space::new() } else {
          let v485_6: Space = routine_32(c, &(v483_10_head), &(v483_10_tail), &(*s1));
          compose(&(v484_5),&(v485_6))
        };
        drop(v484_5);
        let v484_8: Space = intersect(&(*CONSTANT_6),&(v484_2));
        drop(v484_2);
        let v484_9: Space = if has_head(&(v484_8)) { singleton(&[]) } else { Space::new() };
        drop(v484_8);
        let v484_11: Space = if (v484_9).is_empty() { Space::new() } else {
          let v486_10: Space = routine_33(c, &(v483_10_head), &(v483_10_tail), &(*s1));
          compose(&(v484_9),&(v486_10))
        };
        drop(v484_9);
        let v484_12: Space = unite(&(v484_7),&(v484_11));
        v483_10.join_into((v484_12).clone());
      }
      drop(v483_10_cursor);
      compose(&(v481_9),&(v483_10))
    };
    drop(v481_9);
    let v481_12: Path = concat_path(&(*p0),&(v480_9_head));
    let v481_13: Space = wrap(&(v481_11),&(v481_12));
    drop(v481_12);
    let v481_14: Space = unite(&(v481_7),&(v481_13));
    drop(v481_7);
    v480_9.join_into((v481_14).clone());
  }
  drop(v480_9_cursor);
  (v480_9).clone()
}

fn routine_53(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v487_12 = Space::new();
  let mut v487_12_cursor = (*s0).read_zipper();
  for v487_12_byte in v487_12_cursor.child_mask().iter() {
    v487_12_cursor.descend_to_byte(v487_12_byte);
    let v487_12_tail = v487_12_cursor.make_map();
    v487_12_cursor.ascend(1);
    let v487_12_head = Path::from_slice(&[v487_12_byte]);
    let v488_2: Space = singleton(&(v487_12_head));
    let v488_3: Space = intersect(&(*CONSTANT_6),&(v488_2));
    let v488_4: Space = if has_head(&(v488_3)) { singleton(&[]) } else { Space::new() };
    drop(v488_3);
    let v488_5: Space = subtract(&(*CONSTANT_5),&(v488_4));
    drop(v488_4);
    let v488_8: Space = if (v488_5).is_empty() { Space::new() } else {
      let v489_6: Path = concat_path(&(*p0),&(v487_12_head));
      let mut v489_7 = Space::new();
      let mut v489_7_cursor = (v487_12_tail).read_zipper();
      for v489_7_byte in v489_7_cursor.child_mask().iter() {
        v489_7_cursor.descend_to_byte(v489_7_byte);
        let v489_7_tail = v489_7_cursor.make_map();
        v489_7_cursor.ascend(1);
        let v489_7_head = Path::from_slice(&[v489_7_byte]);
        let v490_2: Space = singleton(&(v489_7_head));
        let v490_3: Space = intersect(&(*CONSTANT_6),&(v490_2));
        let v490_4: Space = if has_head(&(v490_3)) { singleton(&[]) } else { Space::new() };
        drop(v490_3);
        let v490_5: Space = subtract(&(*CONSTANT_5),&(v490_4));
        drop(v490_4);
        let v490_8: Space = if (v490_5).is_empty() { Space::new() } else {
          let v491_6: Path = concat_path(&(v489_6),&(v489_7_head));
          let v491_7: Space = routine_65(c, &(v491_6), &(v489_7_tail), &(*s1));
          compose(&(v490_5),&(v491_7))
        };
        drop(v490_5);
        let v490_9: Space = intersect(&(*CONSTANT_6),&(v490_2));
        drop(v490_2);
        let v490_10: Space = if has_head(&(v490_9)) { singleton(&[]) } else { Space::new() };
        drop(v490_9);
        let v490_12: Space = if (v490_10).is_empty() { Space::new() } else {
          let v492_6: Path = concat_path(&(v489_6),&(v489_7_head));
          let v492_11: Space = routine_66(c, &(v492_6), &(v489_7_tail), &(*s1));
          drop(v492_6);
          compose(&(v490_10),&(v492_11))
        };
        drop(v490_10);
        let v490_13: Space = unite(&(v490_8),&(v490_12));
        v489_7.join_into((v490_13).clone());
      }
      drop(v489_7_cursor);
      compose(&(v488_5),&(v489_7))
    };
    drop(v488_5);
    let v488_9: Space = intersect(&(*CONSTANT_6),&(v488_2));
    drop(v488_2);
    let v488_10: Space = if has_head(&(v488_9)) { singleton(&[]) } else { Space::new() };
    drop(v488_9);
    let v488_12: Space = if (v488_10).is_empty() { Space::new() } else {
      let v493_6: Path = concat_path(&(*p0),&(v487_12_head));
      let mut v493_11 = Space::new();
      let mut v493_11_cursor = (v487_12_tail).read_zipper();
      for v493_11_byte in v493_11_cursor.child_mask().iter() {
        v493_11_cursor.descend_to_byte(v493_11_byte);
        let v493_11_tail = v493_11_cursor.make_map();
        v493_11_cursor.ascend(1);
        let v493_11_head = Path::from_slice(&[v493_11_byte]);
        let v494_2: Space = singleton(&(v493_11_head));
        let v494_3: Space = intersect(&(*CONSTANT_6),&(v494_2));
        let v494_4: Space = if has_head(&(v494_3)) { singleton(&[]) } else { Space::new() };
        drop(v494_3);
        let v494_5: Space = subtract(&(*CONSTANT_5),&(v494_4));
        drop(v494_4);
        let v494_8: Space = if (v494_5).is_empty() { Space::new() } else {
          let v495_6: Path = concat_path(&(v493_6),&(v493_11_head));
          let v495_7: Space = routine_65(c, &(v495_6), &(v493_11_tail), &(*s1));
          compose(&(v494_5),&(v495_7))
        };
        drop(v494_5);
        let v494_9: Space = intersect(&(*CONSTANT_6),&(v494_2));
        drop(v494_2);
        let v494_10: Space = if has_head(&(v494_9)) { singleton(&[]) } else { Space::new() };
        drop(v494_9);
        let v494_12: Space = if (v494_10).is_empty() { Space::new() } else {
          let v496_6: Path = concat_path(&(v493_6),&(v493_11_head));
          let v496_11: Space = routine_36(c, &(v496_6), &(v493_11_tail), &(*s1));
          drop(v496_6);
          compose(&(v494_10),&(v496_11))
        };
        drop(v494_10);
        let v494_13: Space = unite(&(v494_8),&(v494_12));
        v493_11.join_into((v494_13).clone());
      }
      drop(v493_11_cursor);
      drop(v493_6);
      compose(&(v488_10),&(v493_11))
    };
    drop(v488_10);
    let v488_13: Space = unite(&(v488_8),&(v488_12));
    v487_12.join_into((v488_13).clone());
  }
  drop(v487_12_cursor);
  (v487_12).clone()
}

fn routine_54(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v497_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v497_9: Space = unwrap(&(v497_7),&(*CONSTANT_4));
  drop(v497_7);
  let v497_10: Space = unwrap(&(v497_9),&(*p0));
  drop(v497_9);
  let mut v497_15 = Space::new();
  let mut v497_15_cursor = (*s0).read_zipper();
  for v497_15_byte in v497_15_cursor.child_mask().iter() {
    v497_15_cursor.descend_to_byte(v497_15_byte);
    let v497_15_tail = v497_15_cursor.make_map();
    v497_15_cursor.ascend(1);
    let v497_15_head = Path::from_slice(&[v497_15_byte]);
    let v498_2: Space = singleton(&(v497_15_head));
    let v498_3: Space = intersect(&(*CONSTANT_6),&(v498_2));
    let v498_4: Space = if has_head(&(v498_3)) { singleton(&[]) } else { Space::new() };
    drop(v498_3);
    let v498_5: Space = subtract(&(*CONSTANT_5),&(v498_4));
    drop(v498_4);
    let v498_8: Space = if (v498_5).is_empty() { Space::new() } else {
      let v499_6: Path = concat_path(&(*p0),&(v497_15_head));
      let mut v499_7 = Space::new();
      let mut v499_7_cursor = (v497_15_tail).read_zipper();
      for v499_7_byte in v499_7_cursor.child_mask().iter() {
        v499_7_cursor.descend_to_byte(v499_7_byte);
        let v499_7_tail = v499_7_cursor.make_map();
        v499_7_cursor.ascend(1);
        let v499_7_head = Path::from_slice(&[v499_7_byte]);
        let v500_2: Space = singleton(&(v499_7_head));
        let v500_3: Space = intersect(&(*CONSTANT_6),&(v500_2));
        let v500_4: Space = if has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
        drop(v500_3);
        let v500_5: Space = subtract(&(*CONSTANT_5),&(v500_4));
        drop(v500_4);
        let v500_8: Space = if (v500_5).is_empty() { Space::new() } else {
          let v501_6: Path = concat_path(&(v499_6),&(v499_7_head));
          let v501_7: Space = routine_65(c, &(v501_6), &(v499_7_tail), &(*s1));
          compose(&(v500_5),&(v501_7))
        };
        drop(v500_5);
        let v500_9: Space = intersect(&(*CONSTANT_6),&(v500_2));
        drop(v500_2);
        let v500_10: Space = if has_head(&(v500_9)) { singleton(&[]) } else { Space::new() };
        drop(v500_9);
        let v500_12: Space = if (v500_10).is_empty() { Space::new() } else {
          let v502_6: Path = concat_path(&(v499_6),&(v499_7_head));
          let v502_11: Space = routine_66(c, &(v502_6), &(v499_7_tail), &(*s1));
          drop(v502_6);
          compose(&(v500_10),&(v502_11))
        };
        drop(v500_10);
        let v500_13: Space = unite(&(v500_8),&(v500_12));
        v499_7.join_into((v500_13).clone());
      }
      drop(v499_7_cursor);
      drop(v499_6);
      compose(&(v498_5),&(v499_7))
    };
    drop(v498_5);
    let v498_9: Space = intersect(&(*CONSTANT_6),&(v498_2));
    drop(v498_2);
    let v498_10: Space = if has_head(&(v498_9)) { singleton(&[]) } else { Space::new() };
    drop(v498_9);
    let v498_13: Space = if (v498_10).is_empty() { Space::new() } else {
      let v503_11: Space = unwrap(&(v497_10),&(v497_15_head));
      let v503_12: Space = subtract(&(v503_11),&(*CONSTANT_5));
      drop(v503_11);
      compose(&(v498_10),&(v503_12))
    };
    drop(v498_10);
    let v498_14: Space = unite(&(v498_8),&(v498_13));
    drop(v498_13);
    v497_15.join_into((v498_14).clone());
  }
  drop(v497_15_cursor);
  drop(v497_10);
  (v497_15).clone()
}

fn routine_55(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v504_12 = Space::new();
  let mut v504_12_cursor = (*s0).read_zipper();
  for v504_12_byte in v504_12_cursor.child_mask().iter() {
    v504_12_cursor.descend_to_byte(v504_12_byte);
    let v504_12_tail = v504_12_cursor.make_map();
    v504_12_cursor.ascend(1);
    let v504_12_head = Path::from_slice(&[v504_12_byte]);
    let v505_2: Space = singleton(&(v504_12_head));
    let v505_3: Space = intersect(&(*CONSTANT_6),&(v505_2));
    let v505_4: Space = if has_head(&(v505_3)) { singleton(&[]) } else { Space::new() };
    drop(v505_3);
    let v505_5: Space = subtract(&(*CONSTANT_5),&(v505_4));
    drop(v505_4);
    let v505_8: Space = if (v505_5).is_empty() { Space::new() } else {
      let v506_6: Path = concat_path(&(*p0),&(v504_12_head));
      let mut v506_7 = Space::new();
      let mut v506_7_cursor = (v504_12_tail).read_zipper();
      for v506_7_byte in v506_7_cursor.child_mask().iter() {
        v506_7_cursor.descend_to_byte(v506_7_byte);
        let v506_7_tail = v506_7_cursor.make_map();
        v506_7_cursor.ascend(1);
        let v506_7_head = Path::from_slice(&[v506_7_byte]);
        let v507_2: Space = singleton(&(v506_7_head));
        let v507_3: Space = intersect(&(*CONSTANT_6),&(v507_2));
        let v507_4: Space = if has_head(&(v507_3)) { singleton(&[]) } else { Space::new() };
        drop(v507_3);
        let v507_5: Space = subtract(&(*CONSTANT_5),&(v507_4));
        drop(v507_4);
        let v507_8: Space = if (v507_5).is_empty() { Space::new() } else {
          let v508_6: Path = concat_path(&(v506_6),&(v506_7_head));
          let v508_7: Space = routine_67(c, &(v508_6), &(v506_7_tail), &(*s1));
          compose(&(v507_5),&(v508_7))
        };
        drop(v507_5);
        let v507_9: Space = intersect(&(*CONSTANT_6),&(v507_2));
        drop(v507_2);
        let v507_10: Space = if has_head(&(v507_9)) { singleton(&[]) } else { Space::new() };
        drop(v507_9);
        let v507_12: Space = if (v507_10).is_empty() { Space::new() } else {
          let v509_6: Path = concat_path(&(v506_6),&(v506_7_head));
          let v509_11: Space = routine_68(c, &(v509_6), &(v506_7_tail), &(*s1));
          drop(v509_6);
          compose(&(v507_10),&(v509_11))
        };
        drop(v507_10);
        let v507_13: Space = unite(&(v507_8),&(v507_12));
        v506_7.join_into((v507_13).clone());
      }
      drop(v506_7_cursor);
      compose(&(v505_5),&(v506_7))
    };
    drop(v505_5);
    let v505_9: Space = intersect(&(*CONSTANT_6),&(v505_2));
    drop(v505_2);
    let v505_10: Space = if has_head(&(v505_9)) { singleton(&[]) } else { Space::new() };
    drop(v505_9);
    let v505_12: Space = if (v505_10).is_empty() { Space::new() } else {
      let v510_6: Path = concat_path(&(*p0),&(v504_12_head));
      let mut v510_11 = Space::new();
      let mut v510_11_cursor = (v504_12_tail).read_zipper();
      for v510_11_byte in v510_11_cursor.child_mask().iter() {
        v510_11_cursor.descend_to_byte(v510_11_byte);
        let v510_11_tail = v510_11_cursor.make_map();
        v510_11_cursor.ascend(1);
        let v510_11_head = Path::from_slice(&[v510_11_byte]);
        let v511_2: Space = singleton(&(v510_11_head));
        let v511_3: Space = intersect(&(*CONSTANT_6),&(v511_2));
        let v511_4: Space = if has_head(&(v511_3)) { singleton(&[]) } else { Space::new() };
        drop(v511_3);
        let v511_5: Space = subtract(&(*CONSTANT_5),&(v511_4));
        drop(v511_4);
        let v511_8: Space = if (v511_5).is_empty() { Space::new() } else {
          let v512_6: Path = concat_path(&(v510_6),&(v510_11_head));
          let v512_7: Space = routine_67(c, &(v512_6), &(v510_11_tail), &(*s1));
          compose(&(v511_5),&(v512_7))
        };
        drop(v511_5);
        let v511_9: Space = intersect(&(*CONSTANT_6),&(v511_2));
        drop(v511_2);
        let v511_10: Space = if has_head(&(v511_9)) { singleton(&[]) } else { Space::new() };
        drop(v511_9);
        let v511_12: Space = if (v511_10).is_empty() { Space::new() } else {
          let v513_6: Path = concat_path(&(v510_6),&(v510_11_head));
          let v513_11: Space = routine_36(c, &(v513_6), &(v510_11_tail), &(*s1));
          drop(v513_6);
          compose(&(v511_10),&(v513_11))
        };
        drop(v511_10);
        let v511_13: Space = unite(&(v511_8),&(v511_12));
        v510_11.join_into((v511_13).clone());
      }
      drop(v510_11_cursor);
      drop(v510_6);
      compose(&(v505_10),&(v510_11))
    };
    drop(v505_10);
    let v505_13: Space = unite(&(v505_8),&(v505_12));
    v504_12.join_into((v505_13).clone());
  }
  drop(v504_12_cursor);
  (v504_12).clone()
}

fn routine_56(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v514_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v514_9: Space = unwrap(&(v514_7),&(*CONSTANT_4));
  drop(v514_7);
  let v514_10: Space = unwrap(&(v514_9),&(*p0));
  drop(v514_9);
  let mut v514_15 = Space::new();
  let mut v514_15_cursor = (*s0).read_zipper();
  for v514_15_byte in v514_15_cursor.child_mask().iter() {
    v514_15_cursor.descend_to_byte(v514_15_byte);
    let v514_15_tail = v514_15_cursor.make_map();
    v514_15_cursor.ascend(1);
    let v514_15_head = Path::from_slice(&[v514_15_byte]);
    let v515_2: Space = singleton(&(v514_15_head));
    let v515_3: Space = intersect(&(*CONSTANT_6),&(v515_2));
    let v515_4: Space = if has_head(&(v515_3)) { singleton(&[]) } else { Space::new() };
    drop(v515_3);
    let v515_5: Space = subtract(&(*CONSTANT_5),&(v515_4));
    drop(v515_4);
    let v515_8: Space = if (v515_5).is_empty() { Space::new() } else {
      let v516_6: Path = concat_path(&(*p0),&(v514_15_head));
      let mut v516_7 = Space::new();
      let mut v516_7_cursor = (v514_15_tail).read_zipper();
      for v516_7_byte in v516_7_cursor.child_mask().iter() {
        v516_7_cursor.descend_to_byte(v516_7_byte);
        let v516_7_tail = v516_7_cursor.make_map();
        v516_7_cursor.ascend(1);
        let v516_7_head = Path::from_slice(&[v516_7_byte]);
        let v517_2: Space = singleton(&(v516_7_head));
        let v517_3: Space = intersect(&(*CONSTANT_6),&(v517_2));
        let v517_4: Space = if has_head(&(v517_3)) { singleton(&[]) } else { Space::new() };
        drop(v517_3);
        let v517_5: Space = subtract(&(*CONSTANT_5),&(v517_4));
        drop(v517_4);
        let v517_8: Space = if (v517_5).is_empty() { Space::new() } else {
          let v518_6: Path = concat_path(&(v516_6),&(v516_7_head));
          let v518_7: Space = routine_67(c, &(v518_6), &(v516_7_tail), &(*s1));
          compose(&(v517_5),&(v518_7))
        };
        drop(v517_5);
        let v517_9: Space = intersect(&(*CONSTANT_6),&(v517_2));
        drop(v517_2);
        let v517_10: Space = if has_head(&(v517_9)) { singleton(&[]) } else { Space::new() };
        drop(v517_9);
        let v517_12: Space = if (v517_10).is_empty() { Space::new() } else {
          let v519_6: Path = concat_path(&(v516_6),&(v516_7_head));
          let v519_11: Space = routine_68(c, &(v519_6), &(v516_7_tail), &(*s1));
          drop(v519_6);
          compose(&(v517_10),&(v519_11))
        };
        drop(v517_10);
        let v517_13: Space = unite(&(v517_8),&(v517_12));
        v516_7.join_into((v517_13).clone());
      }
      drop(v516_7_cursor);
      drop(v516_6);
      compose(&(v515_5),&(v516_7))
    };
    drop(v515_5);
    let v515_9: Space = intersect(&(*CONSTANT_6),&(v515_2));
    drop(v515_2);
    let v515_10: Space = if has_head(&(v515_9)) { singleton(&[]) } else { Space::new() };
    drop(v515_9);
    let v515_13: Space = if (v515_10).is_empty() { Space::new() } else {
      let v520_11: Space = unwrap(&(v514_10),&(v514_15_head));
      let v520_12: Space = subtract(&(v520_11),&(*CONSTANT_5));
      drop(v520_11);
      compose(&(v515_10),&(v520_12))
    };
    drop(v515_10);
    let v515_14: Space = unite(&(v515_8),&(v515_13));
    drop(v515_13);
    v514_15.join_into((v515_14).clone());
  }
  drop(v514_15_cursor);
  drop(v514_10);
  (v514_15).clone()
}

fn routine_57(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v521_12 = Space::new();
  let mut v521_12_cursor = (*s0).read_zipper();
  for v521_12_byte in v521_12_cursor.child_mask().iter() {
    v521_12_cursor.descend_to_byte(v521_12_byte);
    let v521_12_tail = v521_12_cursor.make_map();
    v521_12_cursor.ascend(1);
    let v521_12_head = Path::from_slice(&[v521_12_byte]);
    let v522_2: Space = singleton(&(v521_12_head));
    let v522_3: Space = intersect(&(*CONSTANT_6),&(v522_2));
    let v522_4: Space = if has_head(&(v522_3)) { singleton(&[]) } else { Space::new() };
    drop(v522_3);
    let v522_5: Space = subtract(&(*CONSTANT_5),&(v522_4));
    drop(v522_4);
    let v522_8: Space = if (v522_5).is_empty() { Space::new() } else {
      let v523_6: Path = concat_path(&(*p0),&(v521_12_head));
      let mut v523_7 = Space::new();
      let mut v523_7_cursor = (v521_12_tail).read_zipper();
      for v523_7_byte in v523_7_cursor.child_mask().iter() {
        v523_7_cursor.descend_to_byte(v523_7_byte);
        let v523_7_tail = v523_7_cursor.make_map();
        v523_7_cursor.ascend(1);
        let v523_7_head = Path::from_slice(&[v523_7_byte]);
        let v524_2: Space = singleton(&(v523_7_head));
        let v524_3: Space = intersect(&(*CONSTANT_6),&(v524_2));
        let v524_4: Space = if has_head(&(v524_3)) { singleton(&[]) } else { Space::new() };
        drop(v524_3);
        let v524_5: Space = subtract(&(*CONSTANT_5),&(v524_4));
        drop(v524_4);
        let v524_8: Space = if (v524_5).is_empty() { Space::new() } else {
          let v525_6: Path = concat_path(&(v523_6),&(v523_7_head));
          let v525_7: Space = routine_69(c, &(v525_6), &(v523_7_tail), &(*s1));
          compose(&(v524_5),&(v525_7))
        };
        drop(v524_5);
        let v524_9: Space = intersect(&(*CONSTANT_6),&(v524_2));
        drop(v524_2);
        let v524_10: Space = if has_head(&(v524_9)) { singleton(&[]) } else { Space::new() };
        drop(v524_9);
        let v524_12: Space = if (v524_10).is_empty() { Space::new() } else {
          let v526_6: Path = concat_path(&(v523_6),&(v523_7_head));
          let v526_11: Space = routine_70(c, &(v526_6), &(v523_7_tail), &(*s1));
          drop(v526_6);
          compose(&(v524_10),&(v526_11))
        };
        drop(v524_10);
        let v524_13: Space = unite(&(v524_8),&(v524_12));
        v523_7.join_into((v524_13).clone());
      }
      drop(v523_7_cursor);
      compose(&(v522_5),&(v523_7))
    };
    drop(v522_5);
    let v522_9: Space = intersect(&(*CONSTANT_6),&(v522_2));
    drop(v522_2);
    let v522_10: Space = if has_head(&(v522_9)) { singleton(&[]) } else { Space::new() };
    drop(v522_9);
    let v522_12: Space = if (v522_10).is_empty() { Space::new() } else {
      let v527_6: Path = concat_path(&(*p0),&(v521_12_head));
      let mut v527_11 = Space::new();
      let mut v527_11_cursor = (v521_12_tail).read_zipper();
      for v527_11_byte in v527_11_cursor.child_mask().iter() {
        v527_11_cursor.descend_to_byte(v527_11_byte);
        let v527_11_tail = v527_11_cursor.make_map();
        v527_11_cursor.ascend(1);
        let v527_11_head = Path::from_slice(&[v527_11_byte]);
        let v528_2: Space = singleton(&(v527_11_head));
        let v528_3: Space = intersect(&(*CONSTANT_6),&(v528_2));
        let v528_4: Space = if has_head(&(v528_3)) { singleton(&[]) } else { Space::new() };
        drop(v528_3);
        let v528_5: Space = subtract(&(*CONSTANT_5),&(v528_4));
        drop(v528_4);
        let v528_8: Space = if (v528_5).is_empty() { Space::new() } else {
          let v529_6: Path = concat_path(&(v527_6),&(v527_11_head));
          let v529_7: Space = routine_69(c, &(v529_6), &(v527_11_tail), &(*s1));
          compose(&(v528_5),&(v529_7))
        };
        drop(v528_5);
        let v528_9: Space = intersect(&(*CONSTANT_6),&(v528_2));
        drop(v528_2);
        let v528_10: Space = if has_head(&(v528_9)) { singleton(&[]) } else { Space::new() };
        drop(v528_9);
        let v528_12: Space = if (v528_10).is_empty() { Space::new() } else {
          let v530_6: Path = concat_path(&(v527_6),&(v527_11_head));
          let v530_11: Space = routine_20(c, &(v530_6), &(v527_11_tail), &(*s1));
          drop(v530_6);
          compose(&(v528_10),&(v530_11))
        };
        drop(v528_10);
        let v528_13: Space = unite(&(v528_8),&(v528_12));
        v527_11.join_into((v528_13).clone());
      }
      drop(v527_11_cursor);
      drop(v527_6);
      compose(&(v522_10),&(v527_11))
    };
    drop(v522_10);
    let v522_13: Space = unite(&(v522_8),&(v522_12));
    v521_12.join_into((v522_13).clone());
  }
  drop(v521_12_cursor);
  (v521_12).clone()
}

fn routine_58(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v531_7: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v531_9: Space = unwrap(&(v531_7),&(*CONSTANT_4));
  drop(v531_7);
  let v531_10: Space = unwrap(&(v531_9),&(*p0));
  drop(v531_9);
  let mut v531_15 = Space::new();
  let mut v531_15_cursor = (*s0).read_zipper();
  for v531_15_byte in v531_15_cursor.child_mask().iter() {
    v531_15_cursor.descend_to_byte(v531_15_byte);
    let v531_15_tail = v531_15_cursor.make_map();
    v531_15_cursor.ascend(1);
    let v531_15_head = Path::from_slice(&[v531_15_byte]);
    let v532_2: Space = singleton(&(v531_15_head));
    let v532_3: Space = intersect(&(*CONSTANT_6),&(v532_2));
    let v532_4: Space = if has_head(&(v532_3)) { singleton(&[]) } else { Space::new() };
    drop(v532_3);
    let v532_5: Space = subtract(&(*CONSTANT_5),&(v532_4));
    drop(v532_4);
    let v532_8: Space = if (v532_5).is_empty() { Space::new() } else {
      let v533_6: Path = concat_path(&(*p0),&(v531_15_head));
      let mut v533_7 = Space::new();
      let mut v533_7_cursor = (v531_15_tail).read_zipper();
      for v533_7_byte in v533_7_cursor.child_mask().iter() {
        v533_7_cursor.descend_to_byte(v533_7_byte);
        let v533_7_tail = v533_7_cursor.make_map();
        v533_7_cursor.ascend(1);
        let v533_7_head = Path::from_slice(&[v533_7_byte]);
        let v534_2: Space = singleton(&(v533_7_head));
        let v534_3: Space = intersect(&(*CONSTANT_6),&(v534_2));
        let v534_4: Space = if has_head(&(v534_3)) { singleton(&[]) } else { Space::new() };
        drop(v534_3);
        let v534_5: Space = subtract(&(*CONSTANT_5),&(v534_4));
        drop(v534_4);
        let v534_8: Space = if (v534_5).is_empty() { Space::new() } else {
          let v535_6: Path = concat_path(&(v533_6),&(v533_7_head));
          let v535_7: Space = routine_69(c, &(v535_6), &(v533_7_tail), &(*s1));
          compose(&(v534_5),&(v535_7))
        };
        drop(v534_5);
        let v534_9: Space = intersect(&(*CONSTANT_6),&(v534_2));
        drop(v534_2);
        let v534_10: Space = if has_head(&(v534_9)) { singleton(&[]) } else { Space::new() };
        drop(v534_9);
        let v534_12: Space = if (v534_10).is_empty() { Space::new() } else {
          let v536_6: Path = concat_path(&(v533_6),&(v533_7_head));
          let v536_11: Space = routine_70(c, &(v536_6), &(v533_7_tail), &(*s1));
          drop(v536_6);
          compose(&(v534_10),&(v536_11))
        };
        drop(v534_10);
        let v534_13: Space = unite(&(v534_8),&(v534_12));
        v533_7.join_into((v534_13).clone());
      }
      drop(v533_7_cursor);
      drop(v533_6);
      compose(&(v532_5),&(v533_7))
    };
    drop(v532_5);
    let v532_9: Space = intersect(&(*CONSTANT_6),&(v532_2));
    drop(v532_2);
    let v532_10: Space = if has_head(&(v532_9)) { singleton(&[]) } else { Space::new() };
    drop(v532_9);
    let v532_13: Space = if (v532_10).is_empty() { Space::new() } else {
      let v537_11: Space = unwrap(&(v531_10),&(v531_15_head));
      let v537_12: Space = subtract(&(v537_11),&(*CONSTANT_5));
      drop(v537_11);
      compose(&(v532_10),&(v537_12))
    };
    drop(v532_10);
    let v532_14: Space = unite(&(v532_8),&(v532_13));
    drop(v532_13);
    v531_15.join_into((v532_14).clone());
  }
  drop(v531_15_cursor);
  drop(v531_10);
  (v531_15).clone()
}

fn routine_59(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v538_7 = Space::new();
  let mut v538_7_cursor = (*s0).read_zipper();
  for v538_7_byte in v538_7_cursor.child_mask().iter() {
    v538_7_cursor.descend_to_byte(v538_7_byte);
    let v538_7_tail = v538_7_cursor.make_map();
    v538_7_cursor.ascend(1);
    let v538_7_head = Path::from_slice(&[v538_7_byte]);
    let v539_2: Space = singleton(&(v538_7_head));
    let v539_3: Space = intersect(&(*CONSTANT_6),&(v539_2));
    let v539_4: Space = if has_head(&(v539_3)) { singleton(&[]) } else { Space::new() };
    drop(v539_3);
    let v539_5: Space = subtract(&(*CONSTANT_5),&(v539_4));
    drop(v539_4);
    let mut v539_6 = Space::new();
    let mut v539_6_cursor = (v538_7_tail).read_zipper();
    for v539_6_byte in v539_6_cursor.child_mask().iter() {
      v539_6_cursor.descend_to_byte(v539_6_byte);
      let v539_6_tail = v539_6_cursor.make_map();
      v539_6_cursor.ascend(1);
      let v539_6_head = Path::from_slice(&[v539_6_byte]);
      let v540_2: Space = Space::new();
      v539_6.join_into((v540_2).clone());
    }
    drop(v539_6_cursor);
    let v539_7: Space = compose(&(v539_5),&(v539_6));
    drop(v539_5);
    drop(v539_6);
    let v539_8: Space = intersect(&(*CONSTANT_6),&(v539_2));
    drop(v539_2);
    let v539_9: Space = if has_head(&(v539_8)) { singleton(&[]) } else { Space::new() };
    drop(v539_8);
    let v539_12: Space = if (v539_9).is_empty() { Space::new() } else {
      let v541_10: Path = concat_path(&(*p0),&(v538_7_head));
      let mut v541_11 = Space::new();
      let mut v541_11_cursor = (v538_7_tail).read_zipper();
      for v541_11_byte in v541_11_cursor.child_mask().iter() {
        v541_11_cursor.descend_to_byte(v541_11_byte);
        let v541_11_tail = v541_11_cursor.make_map();
        v541_11_cursor.ascend(1);
        let v541_11_head = Path::from_slice(&[v541_11_byte]);
        let v542_2: Space = singleton(&(v541_11_head));
        let v542_3: Space = intersect(&(*CONSTANT_6),&(v542_2));
        drop(v542_2);
        let v542_4: Space = if has_head(&(v542_3)) { singleton(&[]) } else { Space::new() };
        drop(v542_3);
        let v542_7: Space = if (v542_4).is_empty() { Space::new() } else {
          let v543_5: Path = concat_path(&(v541_10),&(v541_11_head));
          let v543_6: Space = routine_20(c, &(v543_5), &(v541_11_tail), &(*s1));
          drop(v543_5);
          compose(&(v542_4),&(v543_6))
        };
        drop(v542_4);
        v541_11.join_into((v542_7).clone());
      }
      drop(v541_11_cursor);
      drop(v541_10);
      compose(&(v539_9),&(v541_11))
    };
    drop(v539_9);
    let v539_13: Space = unite(&(v539_7),&(v539_12));
    drop(v539_7);
    v538_7.join_into((v539_13).clone());
  }
  drop(v538_7_cursor);
  (v538_7).clone()
}

fn routine_60(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v544_7: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v544_9: Space = unwrap(&(v544_7),&(*CONSTANT_4));
  drop(v544_7);
  let v544_10: Space = unwrap(&(v544_9),&(*p0));
  drop(v544_9);
  let mut v544_12 = Space::new();
  let mut v544_12_cursor = (*s0).read_zipper();
  for v544_12_byte in v544_12_cursor.child_mask().iter() {
    v544_12_cursor.descend_to_byte(v544_12_byte);
    let v544_12_tail = v544_12_cursor.make_map();
    v544_12_cursor.ascend(1);
    let v544_12_head = Path::from_slice(&[v544_12_byte]);
    let v545_2: Space = singleton(&(v544_12_head));
    let v545_3: Space = intersect(&(*CONSTANT_6),&(v545_2));
    let v545_4: Space = if has_head(&(v545_3)) { singleton(&[]) } else { Space::new() };
    drop(v545_3);
    let v545_5: Space = subtract(&(*CONSTANT_5),&(v545_4));
    drop(v545_4);
    let mut v545_6 = Space::new();
    let mut v545_6_cursor = (v544_12_tail).read_zipper();
    for v545_6_byte in v545_6_cursor.child_mask().iter() {
      v545_6_cursor.descend_to_byte(v545_6_byte);
      let v545_6_tail = v545_6_cursor.make_map();
      v545_6_cursor.ascend(1);
      let v545_6_head = Path::from_slice(&[v545_6_byte]);
      let v546_2: Space = Space::new();
      v545_6.join_into((v546_2).clone());
    }
    drop(v545_6_cursor);
    let v545_7: Space = compose(&(v545_5),&(v545_6));
    drop(v545_5);
    drop(v545_6);
    let v545_8: Space = intersect(&(*CONSTANT_6),&(v545_2));
    drop(v545_2);
    let v545_9: Space = if has_head(&(v545_8)) { singleton(&[]) } else { Space::new() };
    drop(v545_8);
    let v545_12: Space = if (v545_9).is_empty() { Space::new() } else {
      let v547_10: Space = unwrap(&(v544_10),&(v544_12_head));
      let v547_11: Space = subtract(&(v547_10),&(*CONSTANT_5));
      drop(v547_10);
      compose(&(v545_9),&(v547_11))
    };
    drop(v545_9);
    let v545_13: Space = unite(&(v545_7),&(v545_12));
    drop(v545_7);
    drop(v545_12);
    v544_12.join_into((v545_13).clone());
  }
  drop(v544_12_cursor);
  drop(v544_10);
  (v544_12).clone()
}

fn routine_61(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v548_12 = Space::new();
  let mut v548_12_cursor = (*s0).read_zipper();
  for v548_12_byte in v548_12_cursor.child_mask().iter() {
    v548_12_cursor.descend_to_byte(v548_12_byte);
    let v548_12_tail = v548_12_cursor.make_map();
    v548_12_cursor.ascend(1);
    let v548_12_head = Path::from_slice(&[v548_12_byte]);
    let v549_2: Space = singleton(&(v548_12_head));
    let v549_3: Space = intersect(&(*CONSTANT_6),&(v549_2));
    let v549_4: Space = if has_head(&(v549_3)) { singleton(&[]) } else { Space::new() };
    drop(v549_3);
    let v549_5: Space = subtract(&(*CONSTANT_5),&(v549_4));
    drop(v549_4);
    let v549_8: Space = if (v549_5).is_empty() { Space::new() } else {
      let v550_6: Path = concat_path(&(*p0),&(v548_12_head));
      let mut v550_7 = Space::new();
      let mut v550_7_cursor = (v548_12_tail).read_zipper();
      for v550_7_byte in v550_7_cursor.child_mask().iter() {
        v550_7_cursor.descend_to_byte(v550_7_byte);
        let v550_7_tail = v550_7_cursor.make_map();
        v550_7_cursor.ascend(1);
        let v550_7_head = Path::from_slice(&[v550_7_byte]);
        let v551_2: Space = singleton(&(v550_7_head));
        let v551_3: Space = intersect(&(*CONSTANT_6),&(v551_2));
        let v551_4: Space = if has_head(&(v551_3)) { singleton(&[]) } else { Space::new() };
        drop(v551_3);
        let v551_5: Space = subtract(&(*CONSTANT_5),&(v551_4));
        drop(v551_4);
        let v551_8: Space = if (v551_5).is_empty() { Space::new() } else {
          let v552_6: Path = concat_path(&(v550_6),&(v550_7_head));
          let v552_7: Space = routine_71(c, &(v552_6), &(v550_7_tail), &(*s1));
          compose(&(v551_5),&(v552_7))
        };
        drop(v551_5);
        let v551_9: Space = intersect(&(*CONSTANT_6),&(v551_2));
        drop(v551_2);
        let v551_10: Space = if has_head(&(v551_9)) { singleton(&[]) } else { Space::new() };
        drop(v551_9);
        let v551_12: Space = if (v551_10).is_empty() { Space::new() } else {
          let v553_6: Path = concat_path(&(v550_6),&(v550_7_head));
          let v553_11: Space = routine_72(c, &(v553_6), &(v550_7_tail), &(*s1));
          drop(v553_6);
          compose(&(v551_10),&(v553_11))
        };
        drop(v551_10);
        let v551_13: Space = unite(&(v551_8),&(v551_12));
        v550_7.join_into((v551_13).clone());
      }
      drop(v550_7_cursor);
      compose(&(v549_5),&(v550_7))
    };
    drop(v549_5);
    let v549_9: Space = intersect(&(*CONSTANT_6),&(v549_2));
    drop(v549_2);
    let v549_10: Space = if has_head(&(v549_9)) { singleton(&[]) } else { Space::new() };
    drop(v549_9);
    let v549_12: Space = if (v549_10).is_empty() { Space::new() } else {
      let v554_6: Path = concat_path(&(*p0),&(v548_12_head));
      let mut v554_11 = Space::new();
      let mut v554_11_cursor = (v548_12_tail).read_zipper();
      for v554_11_byte in v554_11_cursor.child_mask().iter() {
        v554_11_cursor.descend_to_byte(v554_11_byte);
        let v554_11_tail = v554_11_cursor.make_map();
        v554_11_cursor.ascend(1);
        let v554_11_head = Path::from_slice(&[v554_11_byte]);
        let v555_2: Space = singleton(&(v554_11_head));
        let v555_3: Space = intersect(&(*CONSTANT_6),&(v555_2));
        let v555_4: Space = if has_head(&(v555_3)) { singleton(&[]) } else { Space::new() };
        drop(v555_3);
        let v555_5: Space = subtract(&(*CONSTANT_5),&(v555_4));
        drop(v555_4);
        let v555_8: Space = if (v555_5).is_empty() { Space::new() } else {
          let v556_6: Path = concat_path(&(v554_6),&(v554_11_head));
          let v556_7: Space = routine_71(c, &(v556_6), &(v554_11_tail), &(*s1));
          compose(&(v555_5),&(v556_7))
        };
        drop(v555_5);
        let v555_9: Space = intersect(&(*CONSTANT_6),&(v555_2));
        drop(v555_2);
        let v555_10: Space = if has_head(&(v555_9)) { singleton(&[]) } else { Space::new() };
        drop(v555_9);
        let v555_12: Space = if (v555_10).is_empty() { Space::new() } else {
          let v557_6: Path = concat_path(&(v554_6),&(v554_11_head));
          let v557_11: Space = routine_27(c, &(v557_6), &(v554_11_tail), &(*s1));
          drop(v557_6);
          compose(&(v555_10),&(v557_11))
        };
        drop(v555_10);
        let v555_13: Space = unite(&(v555_8),&(v555_12));
        v554_11.join_into((v555_13).clone());
      }
      drop(v554_11_cursor);
      drop(v554_6);
      compose(&(v549_10),&(v554_11))
    };
    drop(v549_10);
    let v549_13: Space = unite(&(v549_8),&(v549_12));
    v548_12.join_into((v549_13).clone());
  }
  drop(v548_12_cursor);
  (v548_12).clone()
}

fn routine_62(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v558_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v558_9: Space = unwrap(&(v558_7),&(*CONSTANT_4));
  drop(v558_7);
  let v558_10: Space = unwrap(&(v558_9),&(*p0));
  drop(v558_9);
  let mut v558_15 = Space::new();
  let mut v558_15_cursor = (*s0).read_zipper();
  for v558_15_byte in v558_15_cursor.child_mask().iter() {
    v558_15_cursor.descend_to_byte(v558_15_byte);
    let v558_15_tail = v558_15_cursor.make_map();
    v558_15_cursor.ascend(1);
    let v558_15_head = Path::from_slice(&[v558_15_byte]);
    let v559_2: Space = singleton(&(v558_15_head));
    let v559_3: Space = intersect(&(*CONSTANT_6),&(v559_2));
    let v559_4: Space = if has_head(&(v559_3)) { singleton(&[]) } else { Space::new() };
    drop(v559_3);
    let v559_5: Space = subtract(&(*CONSTANT_5),&(v559_4));
    drop(v559_4);
    let v559_8: Space = if (v559_5).is_empty() { Space::new() } else {
      let v560_6: Path = concat_path(&(*p0),&(v558_15_head));
      let mut v560_7 = Space::new();
      let mut v560_7_cursor = (v558_15_tail).read_zipper();
      for v560_7_byte in v560_7_cursor.child_mask().iter() {
        v560_7_cursor.descend_to_byte(v560_7_byte);
        let v560_7_tail = v560_7_cursor.make_map();
        v560_7_cursor.ascend(1);
        let v560_7_head = Path::from_slice(&[v560_7_byte]);
        let v561_2: Space = singleton(&(v560_7_head));
        let v561_3: Space = intersect(&(*CONSTANT_6),&(v561_2));
        let v561_4: Space = if has_head(&(v561_3)) { singleton(&[]) } else { Space::new() };
        drop(v561_3);
        let v561_5: Space = subtract(&(*CONSTANT_5),&(v561_4));
        drop(v561_4);
        let v561_8: Space = if (v561_5).is_empty() { Space::new() } else {
          let v562_6: Path = concat_path(&(v560_6),&(v560_7_head));
          let v562_7: Space = routine_71(c, &(v562_6), &(v560_7_tail), &(*s1));
          compose(&(v561_5),&(v562_7))
        };
        drop(v561_5);
        let v561_9: Space = intersect(&(*CONSTANT_6),&(v561_2));
        drop(v561_2);
        let v561_10: Space = if has_head(&(v561_9)) { singleton(&[]) } else { Space::new() };
        drop(v561_9);
        let v561_12: Space = if (v561_10).is_empty() { Space::new() } else {
          let v563_6: Path = concat_path(&(v560_6),&(v560_7_head));
          let v563_11: Space = routine_72(c, &(v563_6), &(v560_7_tail), &(*s1));
          drop(v563_6);
          compose(&(v561_10),&(v563_11))
        };
        drop(v561_10);
        let v561_13: Space = unite(&(v561_8),&(v561_12));
        v560_7.join_into((v561_13).clone());
      }
      drop(v560_7_cursor);
      drop(v560_6);
      compose(&(v559_5),&(v560_7))
    };
    drop(v559_5);
    let v559_9: Space = intersect(&(*CONSTANT_6),&(v559_2));
    drop(v559_2);
    let v559_10: Space = if has_head(&(v559_9)) { singleton(&[]) } else { Space::new() };
    drop(v559_9);
    let v559_13: Space = if (v559_10).is_empty() { Space::new() } else {
      let v564_11: Space = unwrap(&(v558_10),&(v558_15_head));
      let v564_12: Space = subtract(&(v564_11),&(*CONSTANT_5));
      drop(v564_11);
      compose(&(v559_10),&(v564_12))
    };
    drop(v559_10);
    let v559_14: Space = unite(&(v559_8),&(v559_13));
    drop(v559_13);
    v558_15.join_into((v559_14).clone());
  }
  drop(v558_15_cursor);
  drop(v558_10);
  (v558_15).clone()
}

fn routine_63(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v565_7 = Space::new();
  let mut v565_7_cursor = (*s0).read_zipper();
  for v565_7_byte in v565_7_cursor.child_mask().iter() {
    v565_7_cursor.descend_to_byte(v565_7_byte);
    let v565_7_tail = v565_7_cursor.make_map();
    v565_7_cursor.ascend(1);
    let v565_7_head = Path::from_slice(&[v565_7_byte]);
    let v566_2: Space = singleton(&(v565_7_head));
    let v566_3: Space = intersect(&(*CONSTANT_6),&(v566_2));
    let v566_4: Space = if has_head(&(v566_3)) { singleton(&[]) } else { Space::new() };
    drop(v566_3);
    let v566_5: Space = subtract(&(*CONSTANT_5),&(v566_4));
    drop(v566_4);
    let mut v566_6 = Space::new();
    let mut v566_6_cursor = (v565_7_tail).read_zipper();
    for v566_6_byte in v566_6_cursor.child_mask().iter() {
      v566_6_cursor.descend_to_byte(v566_6_byte);
      let v566_6_tail = v566_6_cursor.make_map();
      v566_6_cursor.ascend(1);
      let v566_6_head = Path::from_slice(&[v566_6_byte]);
      let v567_2: Space = Space::new();
      v566_6.join_into((v567_2).clone());
    }
    drop(v566_6_cursor);
    let v566_7: Space = compose(&(v566_5),&(v566_6));
    drop(v566_5);
    drop(v566_6);
    let v566_8: Space = intersect(&(*CONSTANT_6),&(v566_2));
    drop(v566_2);
    let v566_9: Space = if has_head(&(v566_8)) { singleton(&[]) } else { Space::new() };
    drop(v566_8);
    let v566_12: Space = if (v566_9).is_empty() { Space::new() } else {
      let v568_10: Path = concat_path(&(*p0),&(v565_7_head));
      let mut v568_11 = Space::new();
      let mut v568_11_cursor = (v565_7_tail).read_zipper();
      for v568_11_byte in v568_11_cursor.child_mask().iter() {
        v568_11_cursor.descend_to_byte(v568_11_byte);
        let v568_11_tail = v568_11_cursor.make_map();
        v568_11_cursor.ascend(1);
        let v568_11_head = Path::from_slice(&[v568_11_byte]);
        let v569_2: Space = singleton(&(v568_11_head));
        let v569_3: Space = intersect(&(*CONSTANT_6),&(v569_2));
        drop(v569_2);
        let v569_4: Space = if has_head(&(v569_3)) { singleton(&[]) } else { Space::new() };
        drop(v569_3);
        let v569_7: Space = if (v569_4).is_empty() { Space::new() } else {
          let v570_5: Path = concat_path(&(v568_10),&(v568_11_head));
          let v570_6: Space = routine_27(c, &(v570_5), &(v568_11_tail), &(*s1));
          drop(v570_5);
          compose(&(v569_4),&(v570_6))
        };
        drop(v569_4);
        v568_11.join_into((v569_7).clone());
      }
      drop(v568_11_cursor);
      drop(v568_10);
      compose(&(v566_9),&(v568_11))
    };
    drop(v566_9);
    let v566_13: Space = unite(&(v566_7),&(v566_12));
    drop(v566_7);
    v565_7.join_into((v566_13).clone());
  }
  drop(v565_7_cursor);
  (v565_7).clone()
}

fn routine_64(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v571_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v571_9: Space = unwrap(&(v571_7),&(*CONSTANT_4));
  drop(v571_7);
  let v571_10: Space = unwrap(&(v571_9),&(*p0));
  drop(v571_9);
  let mut v571_12 = Space::new();
  let mut v571_12_cursor = (*s0).read_zipper();
  for v571_12_byte in v571_12_cursor.child_mask().iter() {
    v571_12_cursor.descend_to_byte(v571_12_byte);
    let v571_12_tail = v571_12_cursor.make_map();
    v571_12_cursor.ascend(1);
    let v571_12_head = Path::from_slice(&[v571_12_byte]);
    let v572_2: Space = singleton(&(v571_12_head));
    let v572_3: Space = intersect(&(*CONSTANT_6),&(v572_2));
    let v572_4: Space = if has_head(&(v572_3)) { singleton(&[]) } else { Space::new() };
    drop(v572_3);
    let v572_5: Space = subtract(&(*CONSTANT_5),&(v572_4));
    drop(v572_4);
    let mut v572_6 = Space::new();
    let mut v572_6_cursor = (v571_12_tail).read_zipper();
    for v572_6_byte in v572_6_cursor.child_mask().iter() {
      v572_6_cursor.descend_to_byte(v572_6_byte);
      let v572_6_tail = v572_6_cursor.make_map();
      v572_6_cursor.ascend(1);
      let v572_6_head = Path::from_slice(&[v572_6_byte]);
      let v573_2: Space = Space::new();
      v572_6.join_into((v573_2).clone());
    }
    drop(v572_6_cursor);
    let v572_7: Space = compose(&(v572_5),&(v572_6));
    drop(v572_5);
    drop(v572_6);
    let v572_8: Space = intersect(&(*CONSTANT_6),&(v572_2));
    drop(v572_2);
    let v572_9: Space = if has_head(&(v572_8)) { singleton(&[]) } else { Space::new() };
    drop(v572_8);
    let v572_12: Space = if (v572_9).is_empty() { Space::new() } else {
      let v574_10: Space = unwrap(&(v571_10),&(v571_12_head));
      let v574_11: Space = subtract(&(v574_10),&(*CONSTANT_5));
      drop(v574_10);
      compose(&(v572_9),&(v574_11))
    };
    drop(v572_9);
    let v572_13: Space = unite(&(v572_7),&(v572_12));
    drop(v572_7);
    drop(v572_12);
    v571_12.join_into((v572_13).clone());
  }
  drop(v571_12_cursor);
  drop(v571_10);
  (v571_12).clone()
}

fn routine_65(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v575_12 = Space::new();
  let mut v575_12_cursor = (*s0).read_zipper();
  for v575_12_byte in v575_12_cursor.child_mask().iter() {
    v575_12_cursor.descend_to_byte(v575_12_byte);
    let v575_12_tail = v575_12_cursor.make_map();
    v575_12_cursor.ascend(1);
    let v575_12_head = Path::from_slice(&[v575_12_byte]);
    let v576_2: Space = singleton(&(v575_12_head));
    let v576_3: Space = intersect(&(*CONSTANT_6),&(v576_2));
    let v576_4: Space = if has_head(&(v576_3)) { singleton(&[]) } else { Space::new() };
    drop(v576_3);
    let v576_5: Space = subtract(&(*CONSTANT_5),&(v576_4));
    drop(v576_4);
    let v576_8: Space = if (v576_5).is_empty() { Space::new() } else {
      let v577_6: Path = concat_path(&(*p0),&(v575_12_head));
      let mut v577_7 = Space::new();
      let mut v577_7_cursor = (v575_12_tail).read_zipper();
      for v577_7_byte in v577_7_cursor.child_mask().iter() {
        v577_7_cursor.descend_to_byte(v577_7_byte);
        let v577_7_tail = v577_7_cursor.make_map();
        v577_7_cursor.ascend(1);
        let v577_7_head = Path::from_slice(&[v577_7_byte]);
        let v578_2: Space = singleton(&(v577_7_head));
        let v578_3: Space = intersect(&(*CONSTANT_6),&(v578_2));
        let v578_4: Space = if has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
        drop(v578_3);
        let v578_5: Space = subtract(&(*CONSTANT_5),&(v578_4));
        drop(v578_4);
        let v578_8: Space = if (v578_5).is_empty() { Space::new() } else {
          let v579_6: Path = concat_path(&(v577_6),&(v577_7_head));
          let v579_7: Space = routine_73(c, &(v579_6), &(v577_7_tail), &(*s1));
          compose(&(v578_5),&(v579_7))
        };
        drop(v578_5);
        let v578_9: Space = intersect(&(*CONSTANT_6),&(v578_2));
        drop(v578_2);
        let v578_10: Space = if has_head(&(v578_9)) { singleton(&[]) } else { Space::new() };
        drop(v578_9);
        let v578_12: Space = if (v578_10).is_empty() { Space::new() } else {
          let v580_6: Path = concat_path(&(v577_6),&(v577_7_head));
          let v580_11: Space = routine_74(c, &(v580_6), &(v577_7_tail), &(*s1));
          drop(v580_6);
          compose(&(v578_10),&(v580_11))
        };
        drop(v578_10);
        let v578_13: Space = unite(&(v578_8),&(v578_12));
        v577_7.join_into((v578_13).clone());
      }
      drop(v577_7_cursor);
      compose(&(v576_5),&(v577_7))
    };
    drop(v576_5);
    let v576_9: Space = intersect(&(*CONSTANT_6),&(v576_2));
    drop(v576_2);
    let v576_10: Space = if has_head(&(v576_9)) { singleton(&[]) } else { Space::new() };
    drop(v576_9);
    let v576_12: Space = if (v576_10).is_empty() { Space::new() } else {
      let v581_6: Path = concat_path(&(*p0),&(v575_12_head));
      let mut v581_11 = Space::new();
      let mut v581_11_cursor = (v575_12_tail).read_zipper();
      for v581_11_byte in v581_11_cursor.child_mask().iter() {
        v581_11_cursor.descend_to_byte(v581_11_byte);
        let v581_11_tail = v581_11_cursor.make_map();
        v581_11_cursor.ascend(1);
        let v581_11_head = Path::from_slice(&[v581_11_byte]);
        let v582_2: Space = singleton(&(v581_11_head));
        let v582_3: Space = intersect(&(*CONSTANT_6),&(v582_2));
        let v582_4: Space = if has_head(&(v582_3)) { singleton(&[]) } else { Space::new() };
        drop(v582_3);
        let v582_5: Space = subtract(&(*CONSTANT_5),&(v582_4));
        drop(v582_4);
        let v582_8: Space = if (v582_5).is_empty() { Space::new() } else {
          let v583_6: Path = concat_path(&(v581_6),&(v581_11_head));
          let v583_7: Space = routine_73(c, &(v583_6), &(v581_11_tail), &(*s1));
          compose(&(v582_5),&(v583_7))
        };
        drop(v582_5);
        let v582_9: Space = intersect(&(*CONSTANT_6),&(v582_2));
        drop(v582_2);
        let v582_10: Space = if has_head(&(v582_9)) { singleton(&[]) } else { Space::new() };
        drop(v582_9);
        let v582_12: Space = if (v582_10).is_empty() { Space::new() } else {
          let v584_6: Path = concat_path(&(v581_6),&(v581_11_head));
          let v584_11: Space = routine_36(c, &(v584_6), &(v581_11_tail), &(*s1));
          drop(v584_6);
          compose(&(v582_10),&(v584_11))
        };
        drop(v582_10);
        let v582_13: Space = unite(&(v582_8),&(v582_12));
        v581_11.join_into((v582_13).clone());
      }
      drop(v581_11_cursor);
      drop(v581_6);
      compose(&(v576_10),&(v581_11))
    };
    drop(v576_10);
    let v576_13: Space = unite(&(v576_8),&(v576_12));
    v575_12.join_into((v576_13).clone());
  }
  drop(v575_12_cursor);
  (v575_12).clone()
}

fn routine_66(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v585_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v585_9: Space = unwrap(&(v585_7),&(*CONSTANT_4));
  drop(v585_7);
  let v585_10: Space = unwrap(&(v585_9),&(*p0));
  drop(v585_9);
  let mut v585_15 = Space::new();
  let mut v585_15_cursor = (*s0).read_zipper();
  for v585_15_byte in v585_15_cursor.child_mask().iter() {
    v585_15_cursor.descend_to_byte(v585_15_byte);
    let v585_15_tail = v585_15_cursor.make_map();
    v585_15_cursor.ascend(1);
    let v585_15_head = Path::from_slice(&[v585_15_byte]);
    let v586_2: Space = singleton(&(v585_15_head));
    let v586_3: Space = intersect(&(*CONSTANT_6),&(v586_2));
    let v586_4: Space = if has_head(&(v586_3)) { singleton(&[]) } else { Space::new() };
    drop(v586_3);
    let v586_5: Space = subtract(&(*CONSTANT_5),&(v586_4));
    drop(v586_4);
    let v586_8: Space = if (v586_5).is_empty() { Space::new() } else {
      let v587_6: Path = concat_path(&(*p0),&(v585_15_head));
      let mut v587_7 = Space::new();
      let mut v587_7_cursor = (v585_15_tail).read_zipper();
      for v587_7_byte in v587_7_cursor.child_mask().iter() {
        v587_7_cursor.descend_to_byte(v587_7_byte);
        let v587_7_tail = v587_7_cursor.make_map();
        v587_7_cursor.ascend(1);
        let v587_7_head = Path::from_slice(&[v587_7_byte]);
        let v588_2: Space = singleton(&(v587_7_head));
        let v588_3: Space = intersect(&(*CONSTANT_6),&(v588_2));
        let v588_4: Space = if has_head(&(v588_3)) { singleton(&[]) } else { Space::new() };
        drop(v588_3);
        let v588_5: Space = subtract(&(*CONSTANT_5),&(v588_4));
        drop(v588_4);
        let v588_8: Space = if (v588_5).is_empty() { Space::new() } else {
          let v589_6: Path = concat_path(&(v587_6),&(v587_7_head));
          let v589_7: Space = routine_73(c, &(v589_6), &(v587_7_tail), &(*s1));
          compose(&(v588_5),&(v589_7))
        };
        drop(v588_5);
        let v588_9: Space = intersect(&(*CONSTANT_6),&(v588_2));
        drop(v588_2);
        let v588_10: Space = if has_head(&(v588_9)) { singleton(&[]) } else { Space::new() };
        drop(v588_9);
        let v588_12: Space = if (v588_10).is_empty() { Space::new() } else {
          let v590_6: Path = concat_path(&(v587_6),&(v587_7_head));
          let v590_11: Space = routine_74(c, &(v590_6), &(v587_7_tail), &(*s1));
          drop(v590_6);
          compose(&(v588_10),&(v590_11))
        };
        drop(v588_10);
        let v588_13: Space = unite(&(v588_8),&(v588_12));
        v587_7.join_into((v588_13).clone());
      }
      drop(v587_7_cursor);
      drop(v587_6);
      compose(&(v586_5),&(v587_7))
    };
    drop(v586_5);
    let v586_9: Space = intersect(&(*CONSTANT_6),&(v586_2));
    drop(v586_2);
    let v586_10: Space = if has_head(&(v586_9)) { singleton(&[]) } else { Space::new() };
    drop(v586_9);
    let v586_13: Space = if (v586_10).is_empty() { Space::new() } else {
      let v591_11: Space = unwrap(&(v585_10),&(v585_15_head));
      let v591_12: Space = subtract(&(v591_11),&(*CONSTANT_5));
      drop(v591_11);
      compose(&(v586_10),&(v591_12))
    };
    drop(v586_10);
    let v586_14: Space = unite(&(v586_8),&(v586_13));
    drop(v586_13);
    v585_15.join_into((v586_14).clone());
  }
  drop(v585_15_cursor);
  drop(v585_10);
  (v585_15).clone()
}

fn routine_67(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v592_7 = Space::new();
  let mut v592_7_cursor = (*s0).read_zipper();
  for v592_7_byte in v592_7_cursor.child_mask().iter() {
    v592_7_cursor.descend_to_byte(v592_7_byte);
    let v592_7_tail = v592_7_cursor.make_map();
    v592_7_cursor.ascend(1);
    let v592_7_head = Path::from_slice(&[v592_7_byte]);
    let v593_2: Space = singleton(&(v592_7_head));
    let v593_3: Space = intersect(&(*CONSTANT_6),&(v593_2));
    let v593_4: Space = if has_head(&(v593_3)) { singleton(&[]) } else { Space::new() };
    drop(v593_3);
    let v593_5: Space = subtract(&(*CONSTANT_5),&(v593_4));
    drop(v593_4);
    let mut v593_6 = Space::new();
    let mut v593_6_cursor = (v592_7_tail).read_zipper();
    for v593_6_byte in v593_6_cursor.child_mask().iter() {
      v593_6_cursor.descend_to_byte(v593_6_byte);
      let v593_6_tail = v593_6_cursor.make_map();
      v593_6_cursor.ascend(1);
      let v593_6_head = Path::from_slice(&[v593_6_byte]);
      let v594_2: Space = Space::new();
      v593_6.join_into((v594_2).clone());
    }
    drop(v593_6_cursor);
    let v593_7: Space = compose(&(v593_5),&(v593_6));
    drop(v593_5);
    drop(v593_6);
    let v593_8: Space = intersect(&(*CONSTANT_6),&(v593_2));
    drop(v593_2);
    let v593_9: Space = if has_head(&(v593_8)) { singleton(&[]) } else { Space::new() };
    drop(v593_8);
    let v593_12: Space = if (v593_9).is_empty() { Space::new() } else {
      let v595_10: Path = concat_path(&(*p0),&(v592_7_head));
      let mut v595_11 = Space::new();
      let mut v595_11_cursor = (v592_7_tail).read_zipper();
      for v595_11_byte in v595_11_cursor.child_mask().iter() {
        v595_11_cursor.descend_to_byte(v595_11_byte);
        let v595_11_tail = v595_11_cursor.make_map();
        v595_11_cursor.ascend(1);
        let v595_11_head = Path::from_slice(&[v595_11_byte]);
        let v596_2: Space = singleton(&(v595_11_head));
        let v596_3: Space = intersect(&(*CONSTANT_6),&(v596_2));
        drop(v596_2);
        let v596_4: Space = if has_head(&(v596_3)) { singleton(&[]) } else { Space::new() };
        drop(v596_3);
        let v596_7: Space = if (v596_4).is_empty() { Space::new() } else {
          let v597_5: Path = concat_path(&(v595_10),&(v595_11_head));
          let v597_6: Space = routine_36(c, &(v597_5), &(v595_11_tail), &(*s1));
          drop(v597_5);
          compose(&(v596_4),&(v597_6))
        };
        drop(v596_4);
        v595_11.join_into((v596_7).clone());
      }
      drop(v595_11_cursor);
      drop(v595_10);
      compose(&(v593_9),&(v595_11))
    };
    drop(v593_9);
    let v593_13: Space = unite(&(v593_7),&(v593_12));
    drop(v593_7);
    v592_7.join_into((v593_13).clone());
  }
  drop(v592_7_cursor);
  (v592_7).clone()
}

fn routine_68(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v598_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v598_9: Space = unwrap(&(v598_7),&(*CONSTANT_4));
  drop(v598_7);
  let v598_10: Space = unwrap(&(v598_9),&(*p0));
  drop(v598_9);
  let mut v598_12 = Space::new();
  let mut v598_12_cursor = (*s0).read_zipper();
  for v598_12_byte in v598_12_cursor.child_mask().iter() {
    v598_12_cursor.descend_to_byte(v598_12_byte);
    let v598_12_tail = v598_12_cursor.make_map();
    v598_12_cursor.ascend(1);
    let v598_12_head = Path::from_slice(&[v598_12_byte]);
    let v599_2: Space = singleton(&(v598_12_head));
    let v599_3: Space = intersect(&(*CONSTANT_6),&(v599_2));
    let v599_4: Space = if has_head(&(v599_3)) { singleton(&[]) } else { Space::new() };
    drop(v599_3);
    let v599_5: Space = subtract(&(*CONSTANT_5),&(v599_4));
    drop(v599_4);
    let mut v599_6 = Space::new();
    let mut v599_6_cursor = (v598_12_tail).read_zipper();
    for v599_6_byte in v599_6_cursor.child_mask().iter() {
      v599_6_cursor.descend_to_byte(v599_6_byte);
      let v599_6_tail = v599_6_cursor.make_map();
      v599_6_cursor.ascend(1);
      let v599_6_head = Path::from_slice(&[v599_6_byte]);
      let v600_2: Space = Space::new();
      v599_6.join_into((v600_2).clone());
    }
    drop(v599_6_cursor);
    let v599_7: Space = compose(&(v599_5),&(v599_6));
    drop(v599_5);
    drop(v599_6);
    let v599_8: Space = intersect(&(*CONSTANT_6),&(v599_2));
    drop(v599_2);
    let v599_9: Space = if has_head(&(v599_8)) { singleton(&[]) } else { Space::new() };
    drop(v599_8);
    let v599_12: Space = if (v599_9).is_empty() { Space::new() } else {
      let v601_10: Space = unwrap(&(v598_10),&(v598_12_head));
      let v601_11: Space = subtract(&(v601_10),&(*CONSTANT_5));
      drop(v601_10);
      compose(&(v599_9),&(v601_11))
    };
    drop(v599_9);
    let v599_13: Space = unite(&(v599_7),&(v599_12));
    drop(v599_7);
    drop(v599_12);
    v598_12.join_into((v599_13).clone());
  }
  drop(v598_12_cursor);
  drop(v598_10);
  (v598_12).clone()
}

fn routine_69(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v602_3 = Space::new();
  let mut v602_3_cursor = (*s0).read_zipper();
  for v602_3_byte in v602_3_cursor.child_mask().iter() {
    v602_3_cursor.descend_to_byte(v602_3_byte);
    let v602_3_tail = v602_3_cursor.make_map();
    v602_3_cursor.ascend(1);
    let v602_3_head = Path::from_slice(&[v602_3_byte]);
    let v603_2: Space = Space::new();
    v602_3.join_into((v603_2).clone());
  }
  drop(v602_3_cursor);
  (v602_3).clone()
}

fn routine_70(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v604_5: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v604_7: Space = unwrap(&(v604_5),&(*CONSTANT_4));
  drop(v604_5);
  let v604_8: Space = unwrap(&(v604_7),&(*p0));
  drop(v604_7);
  let mut v604_10 = Space::new();
  let mut v604_10_cursor = (*s0).read_zipper();
  for v604_10_byte in v604_10_cursor.child_mask().iter() {
    v604_10_cursor.descend_to_byte(v604_10_byte);
    let v604_10_tail = v604_10_cursor.make_map();
    v604_10_cursor.ascend(1);
    let v604_10_head = Path::from_slice(&[v604_10_byte]);
    let v605_2: Space = singleton(&(v604_10_head));
    let v605_3: Space = intersect(&(*CONSTANT_6),&(v605_2));
    drop(v605_2);
    let v605_4: Space = if has_head(&(v605_3)) { singleton(&[]) } else { Space::new() };
    drop(v605_3);
    let v605_7: Space = if (v605_4).is_empty() { Space::new() } else {
      let v606_5: Space = unwrap(&(v604_8),&(v604_10_head));
      let v606_6: Space = subtract(&(v606_5),&(*CONSTANT_5));
      drop(v606_5);
      compose(&(v605_4),&(v606_6))
    };
    drop(v605_4);
    v604_10.join_into((v605_7).clone());
  }
  drop(v604_10_cursor);
  drop(v604_8);
  (v604_10).clone()
}

fn routine_71(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v607_3 = Space::new();
  let mut v607_3_cursor = (*s0).read_zipper();
  for v607_3_byte in v607_3_cursor.child_mask().iter() {
    v607_3_cursor.descend_to_byte(v607_3_byte);
    let v607_3_tail = v607_3_cursor.make_map();
    v607_3_cursor.ascend(1);
    let v607_3_head = Path::from_slice(&[v607_3_byte]);
    let v608_2: Space = Space::new();
    v607_3.join_into((v608_2).clone());
  }
  drop(v607_3_cursor);
  (v607_3).clone()
}

fn routine_72(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v609_5: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v609_7: Space = unwrap(&(v609_5),&(*CONSTANT_4));
  drop(v609_5);
  let v609_8: Space = unwrap(&(v609_7),&(*p0));
  drop(v609_7);
  let mut v609_10 = Space::new();
  let mut v609_10_cursor = (*s0).read_zipper();
  for v609_10_byte in v609_10_cursor.child_mask().iter() {
    v609_10_cursor.descend_to_byte(v609_10_byte);
    let v609_10_tail = v609_10_cursor.make_map();
    v609_10_cursor.ascend(1);
    let v609_10_head = Path::from_slice(&[v609_10_byte]);
    let v610_2: Space = singleton(&(v609_10_head));
    let v610_3: Space = intersect(&(*CONSTANT_6),&(v610_2));
    drop(v610_2);
    let v610_4: Space = if has_head(&(v610_3)) { singleton(&[]) } else { Space::new() };
    drop(v610_3);
    let v610_7: Space = if (v610_4).is_empty() { Space::new() } else {
      let v611_5: Space = unwrap(&(v609_8),&(v609_10_head));
      let v611_6: Space = subtract(&(v611_5),&(*CONSTANT_5));
      drop(v611_5);
      compose(&(v610_4),&(v611_6))
    };
    drop(v610_4);
    v609_10.join_into((v610_7).clone());
  }
  drop(v609_10_cursor);
  drop(v609_8);
  (v609_10).clone()
}

fn routine_73(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v612_3 = Space::new();
  let mut v612_3_cursor = (*s0).read_zipper();
  for v612_3_byte in v612_3_cursor.child_mask().iter() {
    v612_3_cursor.descend_to_byte(v612_3_byte);
    let v612_3_tail = v612_3_cursor.make_map();
    v612_3_cursor.ascend(1);
    let v612_3_head = Path::from_slice(&[v612_3_byte]);
    let v613_2: Space = Space::new();
    v612_3.join_into((v613_2).clone());
  }
  drop(v612_3_cursor);
  (v612_3).clone()
}

fn routine_74(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v614_5: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v614_7: Space = unwrap(&(v614_5),&(*CONSTANT_4));
  drop(v614_5);
  let v614_8: Space = unwrap(&(v614_7),&(*p0));
  drop(v614_7);
  let mut v614_10 = Space::new();
  let mut v614_10_cursor = (*s0).read_zipper();
  for v614_10_byte in v614_10_cursor.child_mask().iter() {
    v614_10_cursor.descend_to_byte(v614_10_byte);
    let v614_10_tail = v614_10_cursor.make_map();
    v614_10_cursor.ascend(1);
    let v614_10_head = Path::from_slice(&[v614_10_byte]);
    let v615_2: Space = singleton(&(v614_10_head));
    let v615_3: Space = intersect(&(*CONSTANT_6),&(v615_2));
    drop(v615_2);
    let v615_4: Space = if has_head(&(v615_3)) { singleton(&[]) } else { Space::new() };
    drop(v615_3);
    let v615_7: Space = if (v615_4).is_empty() { Space::new() } else {
      let v616_5: Space = unwrap(&(v614_8),&(v614_10_head));
      let v616_6: Space = subtract(&(v616_5),&(*CONSTANT_5));
      drop(v616_5);
      compose(&(v615_4),&(v616_6))
    };
    drop(v615_4);
    v614_10.join_into((v615_7).clone());
  }
  drop(v614_10_cursor);
  drop(v614_8);
  (v614_10).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
