#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,48]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 110 49 0 4 0 110 50 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,49]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("22 4 0 110 50 0 4 0 110 51 0 6 48 0 110 49 49 0 6 48 0 110 49 50 0 6 49 0 110 49 50 0 6 49 0 110 49 51 0 6 50 0 110 49 51 0 6 50 0 110 49 52 0 6 51 0 110 49 52 0 6 51 0 110 49 53 0 6 52 0 110 49 53 0 6 52 0 110 49 54 0 6 53 0 110 49 54 0 6 53 0 110 49 55 0 6 54 0 110 49 55 0 6 54 0 110 49 56 0 6 55 0 110 49 56 0 6 55 0 110 49 57 0 6 56 0 110 49 57 0 6 56 0 110 50 48 0 6 57 0 110 50 48 0 6 57 0 110 50 49 0"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,50]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("9 4 0 110 51 0 4 0 110 52 0 6 48 0 110 50 49 0 6 48 0 110 50 50 0 6 49 0 110 50 50 0 6 49 0 110 50 51 0 6 50 0 110 50 51 0 6 50 0 110 50 52 0 6 51 0 110 50 52 0"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,51]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 110 52 0 4 0 110 53 0"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,52]));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 110 53 0 4 0 110 54 0"));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,53]));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 110 54 0 4 0 110 55 0"));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,54]));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 110 55 0 4 0 110 56 0"));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,55]));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 110 56 0 4 0 110 57 0"));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,56]));
static CONSTANT_18: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 5 0 110 49 48 0 4 0 110 57 0"));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[110,57]));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 5 0 110 49 48 0 5 0 110 49 49 0"));
static CONSTANT_21: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[100,101,108,116,97,0]));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("47 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 48 0 110 49 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 48 0 110 50 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 0 110 50 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 0 110 51 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 48 0 110 49 49 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 48 0 110 49 50 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 49 0 110 49 50 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 49 0 110 49 51 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 50 0 110 49 51 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 50 0 110 49 52 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 51 0 110 49 52 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 51 0 110 49 53 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 52 0 110 49 53 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 52 0 110 49 54 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 53 0 110 49 54 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 53 0 110 49 55 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 54 0 110 49 55 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 54 0 110 49 56 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 55 0 110 49 56 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 55 0 110 49 57 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 56 0 110 49 57 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 56 0 110 50 48 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 57 0 110 50 48 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 49 57 0 110 50 49 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 0 110 51 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 0 110 52 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 48 0 110 50 49 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 48 0 110 50 50 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 49 0 110 50 50 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 49 0 110 50 51 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 50 0 110 50 51 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 50 0 110 50 52 0 22 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 50 51 0 110 50 52 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 51 0 110 52 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 51 0 110 53 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 52 0 110 53 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 52 0 110 54 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 53 0 110 54 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 53 0 110 55 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 54 0 110 55 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 54 0 110 56 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 55 0 110 56 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 55 0 110 57 0 21 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 56 0 110 49 48 0 20 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 56 0 110 57 0 21 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 57 0 110 49 48 0 21 99 111 109 112 108 101 116 101 0 101 100 103 101 0 110 57 0 110 49 49 0"));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[99,111,109,112,108,101,116,101,0]));
static CONSTANT_24: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[101,100,103,101,0]));
static CONSTANT_25: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[112,97,116,104,0]));
static CONSTANT_26: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[99,111,109,112,108,101,116,101,0,112,97,116,104,0]));
static CONSTANT_27: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[100,101,108,116,97,0,112,97,116,104,0]));
static CONSTANT_28: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
fn routine_0(c: &mut Context) -> Space {
  let v0_42: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v1_41: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v2_4: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
      let v2_7: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4));
      let v2_8: Space = unite(&(v2_4),&(v2_7));
      let v2_11: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_6));
      let v2_12: Space = unite(&(v2_8),&(v2_11));
      let v2_15: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_8));
      let v2_16: Space = unite(&(v2_12),&(v2_15));
      let v2_19: Space = routine_1(c, &(*CONSTANT_9), &(*CONSTANT_10));
      let v2_20: Space = unite(&(v2_16),&(v2_19));
      let v2_23: Space = routine_1(c, &(*CONSTANT_11), &(*CONSTANT_12));
      let v2_24: Space = unite(&(v2_20),&(v2_23));
      let v2_27: Space = routine_1(c, &(*CONSTANT_13), &(*CONSTANT_14));
      let v2_28: Space = unite(&(v2_24),&(v2_27));
      let v2_31: Space = routine_1(c, &(*CONSTANT_15), &(*CONSTANT_16));
      let v2_32: Space = unite(&(v2_28),&(v2_31));
      let v2_35: Space = routine_1(c, &(*CONSTANT_17), &(*CONSTANT_18));
      let v2_36: Space = unite(&(v2_32),&(v2_35));
      let v2_39: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_20));
      let v2_40: Space = unite(&(v2_36),&(v2_39));
      compose(&(*CONSTANT_0),&(v2_40))
    };
    compose(&(*CONSTANT_0),&(v1_41))
  };
  let v0_44: Space = wrap(&(v0_42),&(*CONSTANT_21));
  let v0_46: Space = unite(&(v0_44),&(*CONSTANT_22));
  let mut v0_88: Space = (v0_46).clone();
  loop {
    let v3_1: Space = unwrap(&(v0_88),&(*CONSTANT_23));
    let v3_2: Space = unwrap(&(v0_88),&(*CONSTANT_21));
    let v3_3: Space = unite(&(v3_1),&(v3_2));
    let v3_4: Space = wrap(&(v3_3),&(*CONSTANT_23));
    drop(v3_3);
    let v3_5: Space = unwrap(&(v3_1),&(*CONSTANT_24));
    let mut v3_6 = Space::new();
    let mut v3_6_cursor = (v3_5).read_zipper();
    for v3_6_byte in v3_6_cursor.child_mask().iter() {
      v3_6_cursor.descend_to_byte(v3_6_byte);
      let v3_6_tail = v3_6_cursor.make_map();
      v3_6_cursor.ascend(1);
      let v3_6_head = Path::from_slice(&[v3_6_byte]);
      let v4_2: Space = singleton(&(v3_6_head));
      let v4_3: Space = intersect(&(*CONSTANT_28),&(v4_2));
      let v4_4: Space = if has_head(&(v4_3)) { singleton(&[]) } else { Space::new() };
      drop(v4_3);
      let v4_5: Space = subtract(&(*CONSTANT_0),&(v4_4));
      drop(v4_4);
      let v4_7: Space = if (v4_5).is_empty() { Space::new() } else {
        let mut v5_6 = Space::new();
        let mut v5_6_cursor = (v3_6_tail).read_zipper();
        for v5_6_byte in v5_6_cursor.child_mask().iter() {
          v5_6_cursor.descend_to_byte(v5_6_byte);
          let v5_6_tail = v5_6_cursor.make_map();
          v5_6_cursor.ascend(1);
          let v5_6_head = Path::from_slice(&[v5_6_byte]);
          let v6_2: Space = singleton(&(v5_6_head));
          let v6_3: Space = intersect(&(*CONSTANT_28),&(v6_2));
          let v6_4: Space = if has_head(&(v6_3)) { singleton(&[]) } else { Space::new() };
          drop(v6_3);
          let v6_5: Space = subtract(&(*CONSTANT_0),&(v6_4));
          drop(v6_4);
          let v6_8: Space = if (v6_5).is_empty() { Space::new() } else {
            let v7_6: Path = concat_path(&(v3_6_head),&(v5_6_head));
            let v7_7: Space = routine_2(c, &(v7_6), &(v5_6_tail));
            compose(&(v6_5),&(v7_7))
          };
          drop(v6_5);
          let v6_9: Space = intersect(&(*CONSTANT_28),&(v6_2));
          drop(v6_2);
          let v6_10: Space = if has_head(&(v6_9)) { singleton(&[]) } else { Space::new() };
          drop(v6_9);
          let v6_12: Space = if (v6_10).is_empty() { Space::new() } else {
            let v8_6: Path = concat_path(&(v3_6_head),&(v5_6_head));
            let v8_11: Space = routine_3(c, &(v8_6), &(v5_6_tail));
            drop(v8_6);
            compose(&(v6_10),&(v8_11))
          };
          drop(v6_10);
          let v6_13: Space = unite(&(v6_8),&(v6_12));
          v5_6.join_into((v6_13).clone());
        }
        drop(v5_6_cursor);
        compose(&(v4_5),&(v5_6))
      };
      drop(v4_5);
      let v4_8: Space = intersect(&(*CONSTANT_28),&(v4_2));
      drop(v4_2);
      let v4_9: Space = if has_head(&(v4_8)) { singleton(&[]) } else { Space::new() };
      drop(v4_8);
      let v4_11: Space = if (v4_9).is_empty() { Space::new() } else {
        let mut v9_10 = Space::new();
        let mut v9_10_cursor = (v3_6_tail).read_zipper();
        for v9_10_byte in v9_10_cursor.child_mask().iter() {
          v9_10_cursor.descend_to_byte(v9_10_byte);
          let v9_10_tail = v9_10_cursor.make_map();
          v9_10_cursor.ascend(1);
          let v9_10_head = Path::from_slice(&[v9_10_byte]);
          let v10_2: Space = singleton(&(v9_10_head));
          let v10_3: Space = intersect(&(*CONSTANT_28),&(v10_2));
          let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
          drop(v10_3);
          let v10_5: Space = subtract(&(*CONSTANT_0),&(v10_4));
          drop(v10_4);
          let v10_7: Space = if (v10_5).is_empty() { Space::new() } else {
            let v11_6: Space = routine_4(c, &(v9_10_head), &(v3_6_head), &(v9_10_tail));
            compose(&(v10_5),&(v11_6))
          };
          drop(v10_5);
          let v10_8: Space = intersect(&(*CONSTANT_28),&(v10_2));
          drop(v10_2);
          let v10_9: Space = if has_head(&(v10_8)) { singleton(&[]) } else { Space::new() };
          drop(v10_8);
          let v10_11: Space = if (v10_9).is_empty() { Space::new() } else {
            let v12_10: Space = routine_5(c, &(v9_10_head), &(v3_6_head), &(v9_10_tail));
            compose(&(v10_9),&(v12_10))
          };
          drop(v10_9);
          let v10_12: Space = unite(&(v10_7),&(v10_11));
          v9_10.join_into((v10_12).clone());
        }
        drop(v9_10_cursor);
        compose(&(v4_9),&(v9_10))
      };
      drop(v4_9);
      let v4_12: Space = unite(&(v4_7),&(v4_11));
      v3_6.join_into((v4_12).clone());
    }
    drop(v3_6_cursor);
    drop(v3_5);
    let v3_7: Space = unwrap(&(v3_1),&(*CONSTANT_25));
    drop(v3_1);
    let mut v3_8 = Space::new();
    let mut v3_8_cursor = (v3_7).read_zipper();
    for v3_8_byte in v3_8_cursor.child_mask().iter() {
      v3_8_cursor.descend_to_byte(v3_8_byte);
      let v3_8_tail = v3_8_cursor.make_map();
      v3_8_cursor.ascend(1);
      let v3_8_head = Path::from_slice(&[v3_8_byte]);
      let v13_2: Space = singleton(&(v3_8_head));
      let v13_3: Space = intersect(&(*CONSTANT_28),&(v13_2));
      let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
      drop(v13_3);
      let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
      drop(v13_4);
      let v13_7: Space = if (v13_5).is_empty() { Space::new() } else {
        let mut v14_6 = Space::new();
        let mut v14_6_cursor = (v3_8_tail).read_zipper();
        for v14_6_byte in v14_6_cursor.child_mask().iter() {
          v14_6_cursor.descend_to_byte(v14_6_byte);
          let v14_6_tail = v14_6_cursor.make_map();
          v14_6_cursor.ascend(1);
          let v14_6_head = Path::from_slice(&[v14_6_byte]);
          let v15_2: Space = singleton(&(v14_6_head));
          let v15_3: Space = intersect(&(*CONSTANT_28),&(v15_2));
          let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
          drop(v15_3);
          let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
          drop(v15_4);
          let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
            let v16_6: Path = concat_path(&(v3_8_head),&(v14_6_head));
            let v16_7: Space = routine_6(c, &(v16_6), &(v14_6_tail), &(v0_88));
            compose(&(v15_5),&(v16_7))
          };
          drop(v15_5);
          let v15_9: Space = intersect(&(*CONSTANT_28),&(v15_2));
          drop(v15_2);
          let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
          drop(v15_9);
          let v15_12: Space = if (v15_10).is_empty() { Space::new() } else {
            let v17_6: Path = concat_path(&(v3_8_head),&(v14_6_head));
            let v17_11: Space = routine_7(c, &(v17_6), &(v14_6_tail), &(v0_88));
            drop(v17_6);
            compose(&(v15_10),&(v17_11))
          };
          drop(v15_10);
          let v15_13: Space = unite(&(v15_8),&(v15_12));
          v14_6.join_into((v15_13).clone());
        }
        drop(v14_6_cursor);
        compose(&(v13_5),&(v14_6))
      };
      drop(v13_5);
      let v13_8: Space = intersect(&(*CONSTANT_28),&(v13_2));
      drop(v13_2);
      let v13_9: Space = if has_head(&(v13_8)) { singleton(&[]) } else { Space::new() };
      drop(v13_8);
      let v13_11: Space = if (v13_9).is_empty() { Space::new() } else {
        let mut v18_10 = Space::new();
        let mut v18_10_cursor = (v3_8_tail).read_zipper();
        for v18_10_byte in v18_10_cursor.child_mask().iter() {
          v18_10_cursor.descend_to_byte(v18_10_byte);
          let v18_10_tail = v18_10_cursor.make_map();
          v18_10_cursor.ascend(1);
          let v18_10_head = Path::from_slice(&[v18_10_byte]);
          let v19_2: Space = singleton(&(v18_10_head));
          let v19_3: Space = intersect(&(*CONSTANT_28),&(v19_2));
          let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
          drop(v19_3);
          let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
          drop(v19_4);
          let v19_7: Space = if (v19_5).is_empty() { Space::new() } else {
            let v20_6: Space = routine_8(c, &(v18_10_head), &(v3_8_head), &(v18_10_tail), &(v0_88));
            compose(&(v19_5),&(v20_6))
          };
          drop(v19_5);
          let v19_8: Space = intersect(&(*CONSTANT_28),&(v19_2));
          drop(v19_2);
          let v19_9: Space = if has_head(&(v19_8)) { singleton(&[]) } else { Space::new() };
          drop(v19_8);
          let v19_11: Space = if (v19_9).is_empty() { Space::new() } else {
            let v21_10: Space = routine_9(c, &(v18_10_head), &(v3_8_head), &(v18_10_tail), &(v0_88));
            compose(&(v19_9),&(v21_10))
          };
          drop(v19_9);
          let v19_12: Space = unite(&(v19_7),&(v19_11));
          v18_10.join_into((v19_12).clone());
        }
        drop(v18_10_cursor);
        compose(&(v13_9),&(v18_10))
      };
      drop(v13_9);
      let v13_12: Space = unite(&(v13_7),&(v13_11));
      v3_8.join_into((v13_12).clone());
    }
    drop(v3_8_cursor);
    drop(v3_7);
    let v3_9: Space = unite(&(v3_6),&(v3_8));
    let v3_10: Space = unwrap(&(v3_2),&(*CONSTANT_25));
    drop(v3_2);
    let mut v3_11 = Space::new();
    let mut v3_11_cursor = (v3_10).read_zipper();
    for v3_11_byte in v3_11_cursor.child_mask().iter() {
      v3_11_cursor.descend_to_byte(v3_11_byte);
      let v3_11_tail = v3_11_cursor.make_map();
      v3_11_cursor.ascend(1);
      let v3_11_head = Path::from_slice(&[v3_11_byte]);
      let v22_2: Space = singleton(&(v3_11_head));
      let v22_3: Space = intersect(&(*CONSTANT_28),&(v22_2));
      let v22_4: Space = if has_head(&(v22_3)) { singleton(&[]) } else { Space::new() };
      drop(v22_3);
      let v22_5: Space = subtract(&(*CONSTANT_0),&(v22_4));
      drop(v22_4);
      let v22_7: Space = if (v22_5).is_empty() { Space::new() } else {
        let mut v23_6 = Space::new();
        let mut v23_6_cursor = (v3_11_tail).read_zipper();
        for v23_6_byte in v23_6_cursor.child_mask().iter() {
          v23_6_cursor.descend_to_byte(v23_6_byte);
          let v23_6_tail = v23_6_cursor.make_map();
          v23_6_cursor.ascend(1);
          let v23_6_head = Path::from_slice(&[v23_6_byte]);
          let v24_2: Space = singleton(&(v23_6_head));
          let v24_3: Space = intersect(&(*CONSTANT_28),&(v24_2));
          let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
          drop(v24_3);
          let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
          drop(v24_4);
          let v24_8: Space = if (v24_5).is_empty() { Space::new() } else {
            let v25_6: Path = concat_path(&(v3_11_head),&(v23_6_head));
            let v25_7: Space = routine_10(c, &(v25_6), &(v23_6_tail), &(v0_88));
            compose(&(v24_5),&(v25_7))
          };
          drop(v24_5);
          let v24_9: Space = intersect(&(*CONSTANT_28),&(v24_2));
          drop(v24_2);
          let v24_10: Space = if has_head(&(v24_9)) { singleton(&[]) } else { Space::new() };
          drop(v24_9);
          let v24_12: Space = if (v24_10).is_empty() { Space::new() } else {
            let v26_6: Path = concat_path(&(v3_11_head),&(v23_6_head));
            let v26_11: Space = routine_11(c, &(v26_6), &(v23_6_tail), &(v0_88));
            drop(v26_6);
            compose(&(v24_10),&(v26_11))
          };
          drop(v24_10);
          let v24_13: Space = unite(&(v24_8),&(v24_12));
          v23_6.join_into((v24_13).clone());
        }
        drop(v23_6_cursor);
        compose(&(v22_5),&(v23_6))
      };
      drop(v22_5);
      let v22_8: Space = intersect(&(*CONSTANT_28),&(v22_2));
      drop(v22_2);
      let v22_9: Space = if has_head(&(v22_8)) { singleton(&[]) } else { Space::new() };
      drop(v22_8);
      let v22_11: Space = if (v22_9).is_empty() { Space::new() } else {
        let mut v27_10 = Space::new();
        let mut v27_10_cursor = (v3_11_tail).read_zipper();
        for v27_10_byte in v27_10_cursor.child_mask().iter() {
          v27_10_cursor.descend_to_byte(v27_10_byte);
          let v27_10_tail = v27_10_cursor.make_map();
          v27_10_cursor.ascend(1);
          let v27_10_head = Path::from_slice(&[v27_10_byte]);
          let v28_2: Space = singleton(&(v27_10_head));
          let v28_3: Space = intersect(&(*CONSTANT_28),&(v28_2));
          let v28_4: Space = if has_head(&(v28_3)) { singleton(&[]) } else { Space::new() };
          drop(v28_3);
          let v28_5: Space = subtract(&(*CONSTANT_0),&(v28_4));
          drop(v28_4);
          let v28_7: Space = if (v28_5).is_empty() { Space::new() } else {
            let v29_6: Space = routine_12(c, &(v27_10_head), &(v3_11_head), &(v27_10_tail), &(v0_88));
            compose(&(v28_5),&(v29_6))
          };
          drop(v28_5);
          let v28_8: Space = intersect(&(*CONSTANT_28),&(v28_2));
          drop(v28_2);
          let v28_9: Space = if has_head(&(v28_8)) { singleton(&[]) } else { Space::new() };
          drop(v28_8);
          let v28_11: Space = if (v28_9).is_empty() { Space::new() } else {
            let v30_10: Space = routine_13(c, &(v27_10_head), &(v3_11_head), &(v27_10_tail), &(v0_88));
            compose(&(v28_9),&(v30_10))
          };
          drop(v28_9);
          let v28_12: Space = unite(&(v28_7),&(v28_11));
          v27_10.join_into((v28_12).clone());
        }
        drop(v27_10_cursor);
        compose(&(v22_9),&(v27_10))
      };
      drop(v22_9);
      let v22_12: Space = unite(&(v22_7),&(v22_11));
      v3_11.join_into((v22_12).clone());
    }
    drop(v3_11_cursor);
    let v3_12: Space = unite(&(v3_9),&(v3_11));
    let mut v3_13 = Space::new();
    let mut v3_13_cursor = (v3_10).read_zipper();
    for v3_13_byte in v3_13_cursor.child_mask().iter() {
      v3_13_cursor.descend_to_byte(v3_13_byte);
      let v3_13_tail = v3_13_cursor.make_map();
      v3_13_cursor.ascend(1);
      let v3_13_head = Path::from_slice(&[v3_13_byte]);
      let v31_2: Space = singleton(&(v3_13_head));
      let v31_3: Space = intersect(&(*CONSTANT_28),&(v31_2));
      let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
      drop(v31_3);
      let v31_5: Space = subtract(&(*CONSTANT_0),&(v31_4));
      drop(v31_4);
      let v31_7: Space = if (v31_5).is_empty() { Space::new() } else {
        let mut v32_6 = Space::new();
        let mut v32_6_cursor = (v3_13_tail).read_zipper();
        for v32_6_byte in v32_6_cursor.child_mask().iter() {
          v32_6_cursor.descend_to_byte(v32_6_byte);
          let v32_6_tail = v32_6_cursor.make_map();
          v32_6_cursor.ascend(1);
          let v32_6_head = Path::from_slice(&[v32_6_byte]);
          let v33_2: Space = singleton(&(v32_6_head));
          let v33_3: Space = intersect(&(*CONSTANT_28),&(v33_2));
          let v33_4: Space = if has_head(&(v33_3)) { singleton(&[]) } else { Space::new() };
          drop(v33_3);
          let v33_5: Space = subtract(&(*CONSTANT_0),&(v33_4));
          drop(v33_4);
          let v33_8: Space = if (v33_5).is_empty() { Space::new() } else {
            let v34_6: Path = concat_path(&(v3_13_head),&(v32_6_head));
            let v34_7: Space = routine_14(c, &(v34_6), &(v32_6_tail), &(v0_88));
            compose(&(v33_5),&(v34_7))
          };
          drop(v33_5);
          let v33_9: Space = intersect(&(*CONSTANT_28),&(v33_2));
          drop(v33_2);
          let v33_10: Space = if has_head(&(v33_9)) { singleton(&[]) } else { Space::new() };
          drop(v33_9);
          let v33_12: Space = if (v33_10).is_empty() { Space::new() } else {
            let v35_6: Path = concat_path(&(v3_13_head),&(v32_6_head));
            let v35_11: Space = routine_15(c, &(v35_6), &(v32_6_tail), &(v0_88));
            drop(v35_6);
            compose(&(v33_10),&(v35_11))
          };
          drop(v33_10);
          let v33_13: Space = unite(&(v33_8),&(v33_12));
          v32_6.join_into((v33_13).clone());
        }
        drop(v32_6_cursor);
        compose(&(v31_5),&(v32_6))
      };
      drop(v31_5);
      let v31_8: Space = intersect(&(*CONSTANT_28),&(v31_2));
      drop(v31_2);
      let v31_9: Space = if has_head(&(v31_8)) { singleton(&[]) } else { Space::new() };
      drop(v31_8);
      let v31_11: Space = if (v31_9).is_empty() { Space::new() } else {
        let mut v36_10 = Space::new();
        let mut v36_10_cursor = (v3_13_tail).read_zipper();
        for v36_10_byte in v36_10_cursor.child_mask().iter() {
          v36_10_cursor.descend_to_byte(v36_10_byte);
          let v36_10_tail = v36_10_cursor.make_map();
          v36_10_cursor.ascend(1);
          let v36_10_head = Path::from_slice(&[v36_10_byte]);
          let v37_2: Space = singleton(&(v36_10_head));
          let v37_3: Space = intersect(&(*CONSTANT_28),&(v37_2));
          let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
          drop(v37_3);
          let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
          drop(v37_4);
          let v37_7: Space = if (v37_5).is_empty() { Space::new() } else {
            let v38_6: Space = routine_16(c, &(v36_10_head), &(v3_13_head), &(v36_10_tail), &(v0_88));
            compose(&(v37_5),&(v38_6))
          };
          drop(v37_5);
          let v37_8: Space = intersect(&(*CONSTANT_28),&(v37_2));
          drop(v37_2);
          let v37_9: Space = if has_head(&(v37_8)) { singleton(&[]) } else { Space::new() };
          drop(v37_8);
          let v37_11: Space = if (v37_9).is_empty() { Space::new() } else {
            let v39_10: Space = routine_17(c, &(v36_10_head), &(v3_13_head), &(v36_10_tail), &(v0_88));
            compose(&(v37_9),&(v39_10))
          };
          drop(v37_9);
          let v37_12: Space = unite(&(v37_7),&(v37_11));
          v36_10.join_into((v37_12).clone());
        }
        drop(v36_10_cursor);
        compose(&(v31_9),&(v36_10))
      };
      drop(v31_9);
      let v31_12: Space = unite(&(v31_7),&(v31_11));
      v3_13.join_into((v31_12).clone());
    }
    drop(v3_13_cursor);
    drop(v3_10);
    let v3_14: Space = unite(&(v3_12),&(v3_13));
    let v3_15: Space = unwrap(&(v0_88),&(*CONSTANT_26));
    let v3_16: Space = subtract(&(v3_14),&(v3_15));
    drop(v3_15);
    let v3_17: Space = unwrap(&(v0_88),&(*CONSTANT_27));
    let v3_18: Space = subtract(&(v3_16),&(v3_17));
    drop(v3_17);
    let v3_19: Space = wrap(&(v3_18),&(*CONSTANT_27));
    let v3_20: Space = unite(&(v3_4),&(v3_19));
    drop(v3_4);
    let v3_21: Space = unite(&(v3_20),&(v0_88));
    let v0_88_next = unite(&v0_88,&(v3_21));
    if equal(&v0_88_next,&v0_88) { break; }
    v0_88 = v0_88_next;
  }
  let v0_89: Space = unwrap(&(v0_88),&(*CONSTANT_26));
  (v0_89).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v40_8 = Space::new();
  let mut v40_8_cursor = (*s0).read_zipper();
  for v40_8_byte in v40_8_cursor.child_mask().iter() {
    v40_8_cursor.descend_to_byte(v40_8_byte);
    let v40_8_tail = v40_8_cursor.make_map();
    v40_8_cursor.ascend(1);
    let v40_8_head = Path::from_slice(&[v40_8_byte]);
    let v41_2: Space = singleton(&(v40_8_head));
    let v41_3: Space = intersect(&(*CONSTANT_28),&(v41_2));
    let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
    drop(v41_3);
    let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
    drop(v41_4);
    let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
      let v42_6: Path = concat_path(&(*p0),&(v40_8_head));
      let v42_7: Space = routine_1(c, &(v42_6), &(v40_8_tail));
      compose(&(v41_5),&(v42_7))
    };
    drop(v41_5);
    let v41_9: Space = intersect(&(*CONSTANT_28),&(v41_2));
    drop(v41_2);
    let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
    drop(v41_9);
    let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
      let v43_6: Path = concat_path(&(*p0),&(v40_8_head));
      let mut v43_11 = Space::new();
      let mut v43_11_cursor = (v40_8_tail).read_zipper();
      for v43_11_byte in v43_11_cursor.child_mask().iter() {
        v43_11_cursor.descend_to_byte(v43_11_byte);
        let v43_11_tail = v43_11_cursor.make_map();
        v43_11_cursor.ascend(1);
        let v43_11_head = Path::from_slice(&[v43_11_byte]);
        let v44_2: Space = singleton(&(v43_11_head));
        let v44_3: Space = intersect(&(*CONSTANT_28),&(v44_2));
        let v44_4: Space = if has_head(&(v44_3)) { singleton(&[]) } else { Space::new() };
        drop(v44_3);
        let v44_5: Space = subtract(&(*CONSTANT_0),&(v44_4));
        drop(v44_4);
        let v44_7: Space = if (v44_5).is_empty() { Space::new() } else {
          let v45_6: Space = routine_18(c, &(v43_11_head), &(v43_6), &(v43_11_tail));
          compose(&(v44_5),&(v45_6))
        };
        drop(v44_5);
        let v44_8: Space = intersect(&(*CONSTANT_28),&(v44_2));
        drop(v44_2);
        let v44_9: Space = if has_head(&(v44_8)) { singleton(&[]) } else { Space::new() };
        drop(v44_8);
        let v44_11: Space = if (v44_9).is_empty() { Space::new() } else {
          let v46_10: Space = routine_19(c, &(v43_11_head), &(v43_6), &(v43_11_tail));
          compose(&(v44_9),&(v46_10))
        };
        drop(v44_9);
        let v44_12: Space = unite(&(v44_7),&(v44_11));
        v43_11.join_into((v44_12).clone());
      }
      drop(v43_11_cursor);
      drop(v43_6);
      compose(&(v41_10),&(v43_11))
    };
    drop(v41_10);
    let v41_13: Space = unite(&(v41_8),&(v41_12));
    v40_8.join_into((v41_13).clone());
  }
  drop(v40_8_cursor);
  (v40_8).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v47_8 = Space::new();
  let mut v47_8_cursor = (*s0).read_zipper();
  for v47_8_byte in v47_8_cursor.child_mask().iter() {
    v47_8_cursor.descend_to_byte(v47_8_byte);
    let v47_8_tail = v47_8_cursor.make_map();
    v47_8_cursor.ascend(1);
    let v47_8_head = Path::from_slice(&[v47_8_byte]);
    let v48_2: Space = singleton(&(v47_8_head));
    let v48_3: Space = intersect(&(*CONSTANT_28),&(v48_2));
    let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
    drop(v48_3);
    let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
    drop(v48_4);
    let v48_8: Space = if (v48_5).is_empty() { Space::new() } else {
      let v49_6: Path = concat_path(&(*p0),&(v47_8_head));
      let v49_7: Space = routine_2(c, &(v49_6), &(v47_8_tail));
      compose(&(v48_5),&(v49_7))
    };
    drop(v48_5);
    let v48_9: Space = intersect(&(*CONSTANT_28),&(v48_2));
    drop(v48_2);
    let v48_10: Space = if has_head(&(v48_9)) { singleton(&[]) } else { Space::new() };
    drop(v48_9);
    let v48_12: Space = if (v48_10).is_empty() { Space::new() } else {
      let v50_6: Path = concat_path(&(*p0),&(v47_8_head));
      let mut v50_11 = Space::new();
      let mut v50_11_cursor = (v47_8_tail).read_zipper();
      for v50_11_byte in v50_11_cursor.child_mask().iter() {
        v50_11_cursor.descend_to_byte(v50_11_byte);
        let v50_11_tail = v50_11_cursor.make_map();
        v50_11_cursor.ascend(1);
        let v50_11_head = Path::from_slice(&[v50_11_byte]);
        let v51_2: Space = singleton(&(v50_11_head));
        let v51_3: Space = intersect(&(*CONSTANT_28),&(v51_2));
        let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
        drop(v51_3);
        let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
        drop(v51_4);
        let v51_7: Space = if (v51_5).is_empty() { Space::new() } else {
          let v52_6: Space = routine_4(c, &(v50_11_head), &(v50_6), &(v50_11_tail));
          compose(&(v51_5),&(v52_6))
        };
        drop(v51_5);
        let v51_8: Space = intersect(&(*CONSTANT_28),&(v51_2));
        drop(v51_2);
        let v51_9: Space = if has_head(&(v51_8)) { singleton(&[]) } else { Space::new() };
        drop(v51_8);
        let v51_11: Space = if (v51_9).is_empty() { Space::new() } else {
          let v53_10: Space = routine_5(c, &(v50_11_head), &(v50_6), &(v50_11_tail));
          compose(&(v51_9),&(v53_10))
        };
        drop(v51_9);
        let v51_12: Space = unite(&(v51_7),&(v51_11));
        v50_11.join_into((v51_12).clone());
      }
      drop(v50_11_cursor);
      drop(v50_6);
      compose(&(v48_10),&(v50_11))
    };
    drop(v48_10);
    let v48_13: Space = unite(&(v48_8),&(v48_12));
    v47_8.join_into((v48_13).clone());
  }
  drop(v47_8_cursor);
  (v47_8).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v54_8 = Space::new();
  let mut v54_8_cursor = (*s0).read_zipper();
  for v54_8_byte in v54_8_cursor.child_mask().iter() {
    v54_8_cursor.descend_to_byte(v54_8_byte);
    let v54_8_tail = v54_8_cursor.make_map();
    v54_8_cursor.ascend(1);
    let v54_8_head = Path::from_slice(&[v54_8_byte]);
    let v55_2: Space = singleton(&(v54_8_head));
    let v55_3: Space = intersect(&(*CONSTANT_28),&(v55_2));
    let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
    drop(v55_3);
    let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
    drop(v55_4);
    let v55_7: Space = if (v55_5).is_empty() { Space::new() } else {
      let mut v56_6 = Space::new();
      let mut v56_6_cursor = (v54_8_tail).read_zipper();
      for v56_6_byte in v56_6_cursor.child_mask().iter() {
        v56_6_cursor.descend_to_byte(v56_6_byte);
        let v56_6_tail = v56_6_cursor.make_map();
        v56_6_cursor.ascend(1);
        let v56_6_head = Path::from_slice(&[v56_6_byte]);
        let v57_2: Space = singleton(&(v56_6_head));
        let v57_3: Space = intersect(&(*CONSTANT_28),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_0),&(v57_4));
        drop(v57_4);
        let v57_8: Space = if (v57_5).is_empty() { Space::new() } else {
          let v58_6: Path = concat_path(&(v54_8_head),&(v56_6_head));
          let v58_7: Space = routine_4(c, &(v58_6), &(*p0), &(v56_6_tail));
          compose(&(v57_5),&(v58_7))
        };
        drop(v57_5);
        let v57_9: Space = intersect(&(*CONSTANT_28),&(v57_2));
        drop(v57_2);
        let v57_10: Space = if has_head(&(v57_9)) { singleton(&[]) } else { Space::new() };
        drop(v57_9);
        let v57_12: Space = if (v57_10).is_empty() { Space::new() } else {
          let v59_6: Path = concat_path(&(v54_8_head),&(v56_6_head));
          let v59_11: Space = routine_5(c, &(v59_6), &(*p0), &(v56_6_tail));
          drop(v59_6);
          compose(&(v57_10),&(v59_11))
        };
        drop(v57_10);
        let v57_13: Space = unite(&(v57_8),&(v57_12));
        v56_6.join_into((v57_13).clone());
      }
      drop(v56_6_cursor);
      compose(&(v55_5),&(v56_6))
    };
    drop(v55_5);
    let v55_8: Space = intersect(&(*CONSTANT_28),&(v55_2));
    drop(v55_2);
    let v55_9: Space = if has_head(&(v55_8)) { singleton(&[]) } else { Space::new() };
    drop(v55_8);
    let v55_10: Space = compose(&(v55_9),&(v54_8_tail));
    drop(v55_9);
    let v55_11: Space = wrap(&(v55_10),&(v54_8_head));
    drop(v55_10);
    let v55_12: Space = wrap(&(v55_11),&(*p0));
    drop(v55_11);
    let v55_13: Space = unite(&(v55_7),&(v55_12));
    drop(v55_12);
    v54_8.join_into((v55_13).clone());
  }
  drop(v54_8_cursor);
  (v54_8).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v60_6 = Space::new();
  let mut v60_6_cursor = (*s0).read_zipper();
  for v60_6_byte in v60_6_cursor.child_mask().iter() {
    v60_6_cursor.descend_to_byte(v60_6_byte);
    let v60_6_tail = v60_6_cursor.make_map();
    v60_6_cursor.ascend(1);
    let v60_6_head = Path::from_slice(&[v60_6_byte]);
    let v61_2: Space = singleton(&(v60_6_head));
    let v61_3: Space = intersect(&(*CONSTANT_28),&(v61_2));
    let v61_4: Space = if has_head(&(v61_3)) { singleton(&[]) } else { Space::new() };
    drop(v61_3);
    let v61_5: Space = subtract(&(*CONSTANT_0),&(v61_4));
    drop(v61_4);
    let v61_8: Space = if (v61_5).is_empty() { Space::new() } else {
      let v62_6: Path = concat_path(&(*p0),&(v60_6_head));
      let v62_7: Space = routine_4(c, &(v62_6), &(*p1), &(v60_6_tail));
      compose(&(v61_5),&(v62_7))
    };
    drop(v61_5);
    let v61_9: Space = intersect(&(*CONSTANT_28),&(v61_2));
    drop(v61_2);
    let v61_10: Space = if has_head(&(v61_9)) { singleton(&[]) } else { Space::new() };
    drop(v61_9);
    let v61_11: Space = compose(&(v61_10),&(v60_6_tail));
    drop(v61_10);
    let v63_6: Path = concat_path(&(*p0),&(v60_6_head));
    let v61_12: Space = wrap(&(v61_11),&(v63_6));
    drop(v61_11);
    let v61_13: Space = wrap(&(v61_12),&(*p1));
    drop(v61_12);
    let v61_14: Space = unite(&(v61_8),&(v61_13));
    drop(v61_13);
    v60_6.join_into((v61_14).clone());
  }
  drop(v60_6_cursor);
  (v60_6).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v64_3: Space = wrap(&(*s0),&(*p0));
  let v64_4: Space = wrap(&(v64_3),&(*p1));
  drop(v64_3);
  (v64_4).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v65_9 = Space::new();
  let mut v65_9_cursor = (*s0).read_zipper();
  for v65_9_byte in v65_9_cursor.child_mask().iter() {
    v65_9_cursor.descend_to_byte(v65_9_byte);
    let v65_9_tail = v65_9_cursor.make_map();
    v65_9_cursor.ascend(1);
    let v65_9_head = Path::from_slice(&[v65_9_byte]);
    let v66_2: Space = singleton(&(v65_9_head));
    let v66_3: Space = intersect(&(*CONSTANT_28),&(v66_2));
    let v66_4: Space = if has_head(&(v66_3)) { singleton(&[]) } else { Space::new() };
    drop(v66_3);
    let v66_5: Space = subtract(&(*CONSTANT_0),&(v66_4));
    drop(v66_4);
    let v66_8: Space = if (v66_5).is_empty() { Space::new() } else {
      let v67_6: Path = concat_path(&(*p0),&(v65_9_head));
      let v67_7: Space = routine_6(c, &(v67_6), &(v65_9_tail), &(*s1));
      compose(&(v66_5),&(v67_7))
    };
    drop(v66_5);
    let v66_9: Space = intersect(&(*CONSTANT_28),&(v66_2));
    drop(v66_2);
    let v66_10: Space = if has_head(&(v66_9)) { singleton(&[]) } else { Space::new() };
    drop(v66_9);
    let v66_12: Space = if (v66_10).is_empty() { Space::new() } else {
      let v68_6: Path = concat_path(&(*p0),&(v65_9_head));
      let mut v68_11 = Space::new();
      let mut v68_11_cursor = (v65_9_tail).read_zipper();
      for v68_11_byte in v68_11_cursor.child_mask().iter() {
        v68_11_cursor.descend_to_byte(v68_11_byte);
        let v68_11_tail = v68_11_cursor.make_map();
        v68_11_cursor.ascend(1);
        let v68_11_head = Path::from_slice(&[v68_11_byte]);
        let v69_2: Space = singleton(&(v68_11_head));
        let v69_3: Space = intersect(&(*CONSTANT_28),&(v69_2));
        let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
        drop(v69_3);
        let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
        drop(v69_4);
        let v69_7: Space = if (v69_5).is_empty() { Space::new() } else {
          let v70_6: Space = routine_8(c, &(v68_11_head), &(v68_6), &(v68_11_tail), &(*s1));
          compose(&(v69_5),&(v70_6))
        };
        drop(v69_5);
        let v69_8: Space = intersect(&(*CONSTANT_28),&(v69_2));
        drop(v69_2);
        let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
        drop(v69_8);
        let v69_11: Space = if (v69_9).is_empty() { Space::new() } else {
          let v71_10: Space = routine_9(c, &(v68_11_head), &(v68_6), &(v68_11_tail), &(*s1));
          compose(&(v69_9),&(v71_10))
        };
        drop(v69_9);
        let v69_12: Space = unite(&(v69_7),&(v69_11));
        v68_11.join_into((v69_12).clone());
      }
      drop(v68_11_cursor);
      drop(v68_6);
      compose(&(v66_10),&(v68_11))
    };
    drop(v66_10);
    let v66_13: Space = unite(&(v66_8),&(v66_12));
    v65_9.join_into((v66_13).clone());
  }
  drop(v65_9_cursor);
  (v65_9).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v72_7: Space = unwrap(&(*s1),&(*CONSTANT_21));
  let v72_9: Space = unwrap(&(v72_7),&(*CONSTANT_25));
  drop(v72_7);
  let mut v72_16 = Space::new();
  let mut v72_16_cursor = (*s0).read_zipper();
  for v72_16_byte in v72_16_cursor.child_mask().iter() {
    v72_16_cursor.descend_to_byte(v72_16_byte);
    let v72_16_tail = v72_16_cursor.make_map();
    v72_16_cursor.ascend(1);
    let v72_16_head = Path::from_slice(&[v72_16_byte]);
    let v73_2: Space = singleton(&(v72_16_head));
    let v73_3: Space = intersect(&(*CONSTANT_28),&(v73_2));
    let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
    drop(v73_3);
    let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
    drop(v73_4);
    let v73_7: Space = if (v73_5).is_empty() { Space::new() } else {
      let mut v74_6 = Space::new();
      let mut v74_6_cursor = (v72_16_tail).read_zipper();
      for v74_6_byte in v74_6_cursor.child_mask().iter() {
        v74_6_cursor.descend_to_byte(v74_6_byte);
        let v74_6_tail = v74_6_cursor.make_map();
        v74_6_cursor.ascend(1);
        let v74_6_head = Path::from_slice(&[v74_6_byte]);
        let v75_2: Space = singleton(&(v74_6_head));
        let v75_3: Space = intersect(&(*CONSTANT_28),&(v75_2));
        let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
        drop(v75_3);
        let v75_5: Space = subtract(&(*CONSTANT_0),&(v75_4));
        drop(v75_4);
        let v75_8: Space = if (v75_5).is_empty() { Space::new() } else {
          let v76_6: Path = concat_path(&(v72_16_head),&(v74_6_head));
          let v76_7: Space = routine_8(c, &(v76_6), &(*p0), &(v74_6_tail), &(*s1));
          compose(&(v75_5),&(v76_7))
        };
        drop(v75_5);
        let v75_9: Space = intersect(&(*CONSTANT_28),&(v75_2));
        drop(v75_2);
        let v75_10: Space = if has_head(&(v75_9)) { singleton(&[]) } else { Space::new() };
        drop(v75_9);
        let v75_12: Space = if (v75_10).is_empty() { Space::new() } else {
          let v77_6: Path = concat_path(&(v72_16_head),&(v74_6_head));
          let v77_11: Space = routine_9(c, &(v77_6), &(*p0), &(v74_6_tail), &(*s1));
          drop(v77_6);
          compose(&(v75_10),&(v77_11))
        };
        drop(v75_10);
        let v75_13: Space = unite(&(v75_8),&(v75_12));
        v74_6.join_into((v75_13).clone());
      }
      drop(v74_6_cursor);
      compose(&(v73_5),&(v74_6))
    };
    drop(v73_5);
    let v73_8: Space = intersect(&(*CONSTANT_28),&(v73_2));
    drop(v73_2);
    let v73_9: Space = if has_head(&(v73_8)) { singleton(&[]) } else { Space::new() };
    drop(v73_8);
    let v73_12: Space = if (v73_9).is_empty() { Space::new() } else {
      let v78_10: Space = unwrap(&(v72_9),&(v72_16_head));
      let mut v78_11 = Space::new();
      let mut v78_11_cursor = (v78_10).read_zipper();
      for v78_11_byte in v78_11_cursor.child_mask().iter() {
        v78_11_cursor.descend_to_byte(v78_11_byte);
        let v78_11_tail = v78_11_cursor.make_map();
        v78_11_cursor.ascend(1);
        let v78_11_head = Path::from_slice(&[v78_11_byte]);
        let v79_2: Space = singleton(&(v78_11_head));
        let v79_3: Space = intersect(&(*CONSTANT_28),&(v79_2));
        let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
        drop(v79_3);
        let v79_5: Space = subtract(&(*CONSTANT_0),&(v79_4));
        drop(v79_4);
        let v79_7: Space = if (v79_5).is_empty() { Space::new() } else {
          let v80_6: Space = routine_20(c, &(v78_11_head), &(*p0), &(v78_11_tail));
          compose(&(v79_5),&(v80_6))
        };
        drop(v79_5);
        let v79_8: Space = intersect(&(*CONSTANT_28),&(v79_2));
        drop(v79_2);
        let v79_9: Space = if has_head(&(v79_8)) { singleton(&[]) } else { Space::new() };
        drop(v79_8);
        let v79_11: Space = if (v79_9).is_empty() { Space::new() } else {
          let v81_10: Space = routine_21(c, &(v78_11_head), &(*p0), &(v78_11_tail));
          compose(&(v79_9),&(v81_10))
        };
        drop(v79_9);
        let v79_12: Space = unite(&(v79_7),&(v79_11));
        v78_11.join_into((v79_12).clone());
      }
      drop(v78_11_cursor);
      drop(v78_10);
      compose(&(v73_9),&(v78_11))
    };
    drop(v73_9);
    let v73_13: Space = unite(&(v73_7),&(v73_12));
    v72_16.join_into((v73_13).clone());
  }
  drop(v72_16_cursor);
  drop(v72_9);
  (v72_16).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v82_8: Space = unwrap(&(*s1),&(*CONSTANT_21));
  let v82_10: Space = unwrap(&(v82_8),&(*CONSTANT_25));
  drop(v82_8);
  let v82_11: Space = unwrap(&(v82_10),&(*p0));
  drop(v82_10);
  let mut v82_15 = Space::new();
  let mut v82_15_cursor = (*s0).read_zipper();
  for v82_15_byte in v82_15_cursor.child_mask().iter() {
    v82_15_cursor.descend_to_byte(v82_15_byte);
    let v82_15_tail = v82_15_cursor.make_map();
    v82_15_cursor.ascend(1);
    let v82_15_head = Path::from_slice(&[v82_15_byte]);
    let v83_2: Space = singleton(&(v82_15_head));
    let v83_3: Space = intersect(&(*CONSTANT_28),&(v83_2));
    let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
    drop(v83_3);
    let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
    drop(v83_4);
    let v83_8: Space = if (v83_5).is_empty() { Space::new() } else {
      let v84_6: Path = concat_path(&(*p0),&(v82_15_head));
      let v84_7: Space = routine_8(c, &(v84_6), &(*p1), &(v82_15_tail), &(*s1));
      drop(v84_6);
      compose(&(v83_5),&(v84_7))
    };
    drop(v83_5);
    let v83_9: Space = intersect(&(*CONSTANT_28),&(v83_2));
    drop(v83_2);
    let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
    drop(v83_9);
    let v83_13: Space = if (v83_10).is_empty() { Space::new() } else {
      let v85_11: Space = unwrap(&(v82_11),&(v82_15_head));
      let mut v85_12 = Space::new();
      let mut v85_12_cursor = (v85_11).read_zipper();
      for v85_12_byte in v85_12_cursor.child_mask().iter() {
        v85_12_cursor.descend_to_byte(v85_12_byte);
        let v85_12_tail = v85_12_cursor.make_map();
        v85_12_cursor.ascend(1);
        let v85_12_head = Path::from_slice(&[v85_12_byte]);
        let v86_2: Space = singleton(&(v85_12_head));
        let v86_3: Space = intersect(&(*CONSTANT_28),&(v86_2));
        let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
        drop(v86_3);
        let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
        drop(v86_4);
        let v86_7: Space = if (v86_5).is_empty() { Space::new() } else {
          let v87_6: Space = routine_20(c, &(v85_12_head), &(*p1), &(v85_12_tail));
          compose(&(v86_5),&(v87_6))
        };
        drop(v86_5);
        let v86_8: Space = intersect(&(*CONSTANT_28),&(v86_2));
        drop(v86_2);
        let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
        drop(v86_8);
        let v86_11: Space = if (v86_9).is_empty() { Space::new() } else {
          let v88_10: Space = routine_21(c, &(v85_12_head), &(*p1), &(v85_12_tail));
          compose(&(v86_9),&(v88_10))
        };
        drop(v86_9);
        let v86_12: Space = unite(&(v86_7),&(v86_11));
        v85_12.join_into((v86_12).clone());
      }
      drop(v85_12_cursor);
      drop(v85_11);
      compose(&(v83_10),&(v85_12))
    };
    drop(v83_10);
    let v83_14: Space = unite(&(v83_8),&(v83_13));
    v82_15.join_into((v83_14).clone());
  }
  drop(v82_15_cursor);
  drop(v82_11);
  (v82_15).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v89_5: Space = unwrap(&(*s1),&(*CONSTANT_21));
  let v89_7: Space = unwrap(&(v89_5),&(*CONSTANT_25));
  drop(v89_5);
  let v89_8: Space = unwrap(&(v89_7),&(*p0));
  drop(v89_7);
  let mut v89_15 = Space::new();
  let mut v89_15_cursor = (v89_8).read_zipper();
  for v89_15_byte in v89_15_cursor.child_mask().iter() {
    v89_15_cursor.descend_to_byte(v89_15_byte);
    let v89_15_tail = v89_15_cursor.make_map();
    v89_15_cursor.ascend(1);
    let v89_15_head = Path::from_slice(&[v89_15_byte]);
    let v90_2: Space = singleton(&(v89_15_head));
    let v90_3: Space = intersect(&(*CONSTANT_28),&(v90_2));
    let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
    drop(v90_3);
    let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
    drop(v90_4);
    let v90_7: Space = if (v90_5).is_empty() { Space::new() } else {
      let mut v91_6 = Space::new();
      let mut v91_6_cursor = (v89_15_tail).read_zipper();
      for v91_6_byte in v91_6_cursor.child_mask().iter() {
        v91_6_cursor.descend_to_byte(v91_6_byte);
        let v91_6_tail = v91_6_cursor.make_map();
        v91_6_cursor.ascend(1);
        let v91_6_head = Path::from_slice(&[v91_6_byte]);
        let v92_2: Space = singleton(&(v91_6_head));
        let v92_3: Space = intersect(&(*CONSTANT_28),&(v92_2));
        let v92_4: Space = if has_head(&(v92_3)) { singleton(&[]) } else { Space::new() };
        drop(v92_3);
        let v92_5: Space = subtract(&(*CONSTANT_0),&(v92_4));
        drop(v92_4);
        let v92_8: Space = if (v92_5).is_empty() { Space::new() } else {
          let v93_6: Path = concat_path(&(v89_15_head),&(v91_6_head));
          let v93_7: Space = routine_20(c, &(v93_6), &(*p1), &(v91_6_tail));
          compose(&(v92_5),&(v93_7))
        };
        drop(v92_5);
        let v92_9: Space = intersect(&(*CONSTANT_28),&(v92_2));
        drop(v92_2);
        let v92_10: Space = if has_head(&(v92_9)) { singleton(&[]) } else { Space::new() };
        drop(v92_9);
        let v92_12: Space = if (v92_10).is_empty() { Space::new() } else {
          let v94_6: Path = concat_path(&(v89_15_head),&(v91_6_head));
          let v94_11: Space = routine_21(c, &(v94_6), &(*p1), &(v91_6_tail));
          drop(v94_6);
          compose(&(v92_10),&(v94_11))
        };
        drop(v92_10);
        let v92_13: Space = unite(&(v92_8),&(v92_12));
        v91_6.join_into((v92_13).clone());
      }
      drop(v91_6_cursor);
      compose(&(v90_5),&(v91_6))
    };
    drop(v90_5);
    let v90_8: Space = intersect(&(*CONSTANT_28),&(v90_2));
    drop(v90_2);
    let v90_9: Space = if has_head(&(v90_8)) { singleton(&[]) } else { Space::new() };
    drop(v90_8);
    let v90_10: Space = compose(&(v90_9),&(v89_15_tail));
    drop(v90_9);
    let v90_11: Space = wrap(&(v90_10),&(v89_15_head));
    drop(v90_10);
    let v90_12: Space = wrap(&(v90_11),&(*p1));
    drop(v90_11);
    let v90_13: Space = unite(&(v90_7),&(v90_12));
    drop(v90_12);
    v89_15.join_into((v90_13).clone());
  }
  drop(v89_15_cursor);
  drop(v89_8);
  (v89_15).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v95_9 = Space::new();
  let mut v95_9_cursor = (*s0).read_zipper();
  for v95_9_byte in v95_9_cursor.child_mask().iter() {
    v95_9_cursor.descend_to_byte(v95_9_byte);
    let v95_9_tail = v95_9_cursor.make_map();
    v95_9_cursor.ascend(1);
    let v95_9_head = Path::from_slice(&[v95_9_byte]);
    let v96_2: Space = singleton(&(v95_9_head));
    let v96_3: Space = intersect(&(*CONSTANT_28),&(v96_2));
    let v96_4: Space = if has_head(&(v96_3)) { singleton(&[]) } else { Space::new() };
    drop(v96_3);
    let v96_5: Space = subtract(&(*CONSTANT_0),&(v96_4));
    drop(v96_4);
    let v96_8: Space = if (v96_5).is_empty() { Space::new() } else {
      let v97_6: Path = concat_path(&(*p0),&(v95_9_head));
      let v97_7: Space = routine_10(c, &(v97_6), &(v95_9_tail), &(*s1));
      compose(&(v96_5),&(v97_7))
    };
    drop(v96_5);
    let v96_9: Space = intersect(&(*CONSTANT_28),&(v96_2));
    drop(v96_2);
    let v96_10: Space = if has_head(&(v96_9)) { singleton(&[]) } else { Space::new() };
    drop(v96_9);
    let v96_12: Space = if (v96_10).is_empty() { Space::new() } else {
      let v98_6: Path = concat_path(&(*p0),&(v95_9_head));
      let mut v98_11 = Space::new();
      let mut v98_11_cursor = (v95_9_tail).read_zipper();
      for v98_11_byte in v98_11_cursor.child_mask().iter() {
        v98_11_cursor.descend_to_byte(v98_11_byte);
        let v98_11_tail = v98_11_cursor.make_map();
        v98_11_cursor.ascend(1);
        let v98_11_head = Path::from_slice(&[v98_11_byte]);
        let v99_2: Space = singleton(&(v98_11_head));
        let v99_3: Space = intersect(&(*CONSTANT_28),&(v99_2));
        let v99_4: Space = if has_head(&(v99_3)) { singleton(&[]) } else { Space::new() };
        drop(v99_3);
        let v99_5: Space = subtract(&(*CONSTANT_0),&(v99_4));
        drop(v99_4);
        let v99_7: Space = if (v99_5).is_empty() { Space::new() } else {
          let v100_6: Space = routine_12(c, &(v98_11_head), &(v98_6), &(v98_11_tail), &(*s1));
          compose(&(v99_5),&(v100_6))
        };
        drop(v99_5);
        let v99_8: Space = intersect(&(*CONSTANT_28),&(v99_2));
        drop(v99_2);
        let v99_9: Space = if has_head(&(v99_8)) { singleton(&[]) } else { Space::new() };
        drop(v99_8);
        let v99_11: Space = if (v99_9).is_empty() { Space::new() } else {
          let v101_10: Space = routine_13(c, &(v98_11_head), &(v98_6), &(v98_11_tail), &(*s1));
          compose(&(v99_9),&(v101_10))
        };
        drop(v99_9);
        let v99_12: Space = unite(&(v99_7),&(v99_11));
        v98_11.join_into((v99_12).clone());
      }
      drop(v98_11_cursor);
      drop(v98_6);
      compose(&(v96_10),&(v98_11))
    };
    drop(v96_10);
    let v96_13: Space = unite(&(v96_8),&(v96_12));
    v95_9.join_into((v96_13).clone());
  }
  drop(v95_9_cursor);
  (v95_9).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v102_7: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v102_9: Space = unwrap(&(v102_7),&(*CONSTANT_25));
  drop(v102_7);
  let mut v102_16 = Space::new();
  let mut v102_16_cursor = (*s0).read_zipper();
  for v102_16_byte in v102_16_cursor.child_mask().iter() {
    v102_16_cursor.descend_to_byte(v102_16_byte);
    let v102_16_tail = v102_16_cursor.make_map();
    v102_16_cursor.ascend(1);
    let v102_16_head = Path::from_slice(&[v102_16_byte]);
    let v103_2: Space = singleton(&(v102_16_head));
    let v103_3: Space = intersect(&(*CONSTANT_28),&(v103_2));
    let v103_4: Space = if has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
    drop(v103_3);
    let v103_5: Space = subtract(&(*CONSTANT_0),&(v103_4));
    drop(v103_4);
    let v103_7: Space = if (v103_5).is_empty() { Space::new() } else {
      let mut v104_6 = Space::new();
      let mut v104_6_cursor = (v102_16_tail).read_zipper();
      for v104_6_byte in v104_6_cursor.child_mask().iter() {
        v104_6_cursor.descend_to_byte(v104_6_byte);
        let v104_6_tail = v104_6_cursor.make_map();
        v104_6_cursor.ascend(1);
        let v104_6_head = Path::from_slice(&[v104_6_byte]);
        let v105_2: Space = singleton(&(v104_6_head));
        let v105_3: Space = intersect(&(*CONSTANT_28),&(v105_2));
        let v105_4: Space = if has_head(&(v105_3)) { singleton(&[]) } else { Space::new() };
        drop(v105_3);
        let v105_5: Space = subtract(&(*CONSTANT_0),&(v105_4));
        drop(v105_4);
        let v105_8: Space = if (v105_5).is_empty() { Space::new() } else {
          let v106_6: Path = concat_path(&(v102_16_head),&(v104_6_head));
          let v106_7: Space = routine_12(c, &(v106_6), &(*p0), &(v104_6_tail), &(*s1));
          compose(&(v105_5),&(v106_7))
        };
        drop(v105_5);
        let v105_9: Space = intersect(&(*CONSTANT_28),&(v105_2));
        drop(v105_2);
        let v105_10: Space = if has_head(&(v105_9)) { singleton(&[]) } else { Space::new() };
        drop(v105_9);
        let v105_12: Space = if (v105_10).is_empty() { Space::new() } else {
          let v107_6: Path = concat_path(&(v102_16_head),&(v104_6_head));
          let v107_11: Space = routine_13(c, &(v107_6), &(*p0), &(v104_6_tail), &(*s1));
          drop(v107_6);
          compose(&(v105_10),&(v107_11))
        };
        drop(v105_10);
        let v105_13: Space = unite(&(v105_8),&(v105_12));
        v104_6.join_into((v105_13).clone());
      }
      drop(v104_6_cursor);
      compose(&(v103_5),&(v104_6))
    };
    drop(v103_5);
    let v103_8: Space = intersect(&(*CONSTANT_28),&(v103_2));
    drop(v103_2);
    let v103_9: Space = if has_head(&(v103_8)) { singleton(&[]) } else { Space::new() };
    drop(v103_8);
    let v103_12: Space = if (v103_9).is_empty() { Space::new() } else {
      let v108_10: Space = unwrap(&(v102_9),&(v102_16_head));
      let mut v108_11 = Space::new();
      let mut v108_11_cursor = (v108_10).read_zipper();
      for v108_11_byte in v108_11_cursor.child_mask().iter() {
        v108_11_cursor.descend_to_byte(v108_11_byte);
        let v108_11_tail = v108_11_cursor.make_map();
        v108_11_cursor.ascend(1);
        let v108_11_head = Path::from_slice(&[v108_11_byte]);
        let v109_2: Space = singleton(&(v108_11_head));
        let v109_3: Space = intersect(&(*CONSTANT_28),&(v109_2));
        let v109_4: Space = if has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
        drop(v109_3);
        let v109_5: Space = subtract(&(*CONSTANT_0),&(v109_4));
        drop(v109_4);
        let v109_7: Space = if (v109_5).is_empty() { Space::new() } else {
          let v110_6: Space = routine_22(c, &(v108_11_head), &(*p0), &(v108_11_tail));
          compose(&(v109_5),&(v110_6))
        };
        drop(v109_5);
        let v109_8: Space = intersect(&(*CONSTANT_28),&(v109_2));
        drop(v109_2);
        let v109_9: Space = if has_head(&(v109_8)) { singleton(&[]) } else { Space::new() };
        drop(v109_8);
        let v109_11: Space = if (v109_9).is_empty() { Space::new() } else {
          let v111_10: Space = routine_23(c, &(v108_11_head), &(*p0), &(v108_11_tail));
          compose(&(v109_9),&(v111_10))
        };
        drop(v109_9);
        let v109_12: Space = unite(&(v109_7),&(v109_11));
        v108_11.join_into((v109_12).clone());
      }
      drop(v108_11_cursor);
      drop(v108_10);
      compose(&(v103_9),&(v108_11))
    };
    drop(v103_9);
    let v103_13: Space = unite(&(v103_7),&(v103_12));
    v102_16.join_into((v103_13).clone());
  }
  drop(v102_16_cursor);
  drop(v102_9);
  (v102_16).clone()
}

fn routine_12(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v112_8: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v112_10: Space = unwrap(&(v112_8),&(*CONSTANT_25));
  drop(v112_8);
  let v112_11: Space = unwrap(&(v112_10),&(*p0));
  drop(v112_10);
  let mut v112_15 = Space::new();
  let mut v112_15_cursor = (*s0).read_zipper();
  for v112_15_byte in v112_15_cursor.child_mask().iter() {
    v112_15_cursor.descend_to_byte(v112_15_byte);
    let v112_15_tail = v112_15_cursor.make_map();
    v112_15_cursor.ascend(1);
    let v112_15_head = Path::from_slice(&[v112_15_byte]);
    let v113_2: Space = singleton(&(v112_15_head));
    let v113_3: Space = intersect(&(*CONSTANT_28),&(v113_2));
    let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
    drop(v113_3);
    let v113_5: Space = subtract(&(*CONSTANT_0),&(v113_4));
    drop(v113_4);
    let v113_8: Space = if (v113_5).is_empty() { Space::new() } else {
      let v114_6: Path = concat_path(&(*p0),&(v112_15_head));
      let v114_7: Space = routine_12(c, &(v114_6), &(*p1), &(v112_15_tail), &(*s1));
      drop(v114_6);
      compose(&(v113_5),&(v114_7))
    };
    drop(v113_5);
    let v113_9: Space = intersect(&(*CONSTANT_28),&(v113_2));
    drop(v113_2);
    let v113_10: Space = if has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
    drop(v113_9);
    let v113_13: Space = if (v113_10).is_empty() { Space::new() } else {
      let v115_11: Space = unwrap(&(v112_11),&(v112_15_head));
      let mut v115_12 = Space::new();
      let mut v115_12_cursor = (v115_11).read_zipper();
      for v115_12_byte in v115_12_cursor.child_mask().iter() {
        v115_12_cursor.descend_to_byte(v115_12_byte);
        let v115_12_tail = v115_12_cursor.make_map();
        v115_12_cursor.ascend(1);
        let v115_12_head = Path::from_slice(&[v115_12_byte]);
        let v116_2: Space = singleton(&(v115_12_head));
        let v116_3: Space = intersect(&(*CONSTANT_28),&(v116_2));
        let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
        drop(v116_3);
        let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
        drop(v116_4);
        let v116_7: Space = if (v116_5).is_empty() { Space::new() } else {
          let v117_6: Space = routine_22(c, &(v115_12_head), &(*p1), &(v115_12_tail));
          compose(&(v116_5),&(v117_6))
        };
        drop(v116_5);
        let v116_8: Space = intersect(&(*CONSTANT_28),&(v116_2));
        drop(v116_2);
        let v116_9: Space = if has_head(&(v116_8)) { singleton(&[]) } else { Space::new() };
        drop(v116_8);
        let v116_11: Space = if (v116_9).is_empty() { Space::new() } else {
          let v118_10: Space = routine_23(c, &(v115_12_head), &(*p1), &(v115_12_tail));
          compose(&(v116_9),&(v118_10))
        };
        drop(v116_9);
        let v116_12: Space = unite(&(v116_7),&(v116_11));
        v115_12.join_into((v116_12).clone());
      }
      drop(v115_12_cursor);
      drop(v115_11);
      compose(&(v113_10),&(v115_12))
    };
    drop(v113_10);
    let v113_14: Space = unite(&(v113_8),&(v113_13));
    v112_15.join_into((v113_14).clone());
  }
  drop(v112_15_cursor);
  drop(v112_11);
  (v112_15).clone()
}

fn routine_13(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v119_5: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v119_7: Space = unwrap(&(v119_5),&(*CONSTANT_25));
  drop(v119_5);
  let v119_8: Space = unwrap(&(v119_7),&(*p0));
  drop(v119_7);
  let mut v119_15 = Space::new();
  let mut v119_15_cursor = (v119_8).read_zipper();
  for v119_15_byte in v119_15_cursor.child_mask().iter() {
    v119_15_cursor.descend_to_byte(v119_15_byte);
    let v119_15_tail = v119_15_cursor.make_map();
    v119_15_cursor.ascend(1);
    let v119_15_head = Path::from_slice(&[v119_15_byte]);
    let v120_2: Space = singleton(&(v119_15_head));
    let v120_3: Space = intersect(&(*CONSTANT_28),&(v120_2));
    let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
    drop(v120_3);
    let v120_5: Space = subtract(&(*CONSTANT_0),&(v120_4));
    drop(v120_4);
    let v120_7: Space = if (v120_5).is_empty() { Space::new() } else {
      let mut v121_6 = Space::new();
      let mut v121_6_cursor = (v119_15_tail).read_zipper();
      for v121_6_byte in v121_6_cursor.child_mask().iter() {
        v121_6_cursor.descend_to_byte(v121_6_byte);
        let v121_6_tail = v121_6_cursor.make_map();
        v121_6_cursor.ascend(1);
        let v121_6_head = Path::from_slice(&[v121_6_byte]);
        let v122_2: Space = singleton(&(v121_6_head));
        let v122_3: Space = intersect(&(*CONSTANT_28),&(v122_2));
        let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
        drop(v122_3);
        let v122_5: Space = subtract(&(*CONSTANT_0),&(v122_4));
        drop(v122_4);
        let v122_8: Space = if (v122_5).is_empty() { Space::new() } else {
          let v123_6: Path = concat_path(&(v119_15_head),&(v121_6_head));
          let v123_7: Space = routine_22(c, &(v123_6), &(*p1), &(v121_6_tail));
          compose(&(v122_5),&(v123_7))
        };
        drop(v122_5);
        let v122_9: Space = intersect(&(*CONSTANT_28),&(v122_2));
        drop(v122_2);
        let v122_10: Space = if has_head(&(v122_9)) { singleton(&[]) } else { Space::new() };
        drop(v122_9);
        let v122_12: Space = if (v122_10).is_empty() { Space::new() } else {
          let v124_6: Path = concat_path(&(v119_15_head),&(v121_6_head));
          let v124_11: Space = routine_23(c, &(v124_6), &(*p1), &(v121_6_tail));
          drop(v124_6);
          compose(&(v122_10),&(v124_11))
        };
        drop(v122_10);
        let v122_13: Space = unite(&(v122_8),&(v122_12));
        v121_6.join_into((v122_13).clone());
      }
      drop(v121_6_cursor);
      compose(&(v120_5),&(v121_6))
    };
    drop(v120_5);
    let v120_8: Space = intersect(&(*CONSTANT_28),&(v120_2));
    drop(v120_2);
    let v120_9: Space = if has_head(&(v120_8)) { singleton(&[]) } else { Space::new() };
    drop(v120_8);
    let v120_10: Space = compose(&(v120_9),&(v119_15_tail));
    drop(v120_9);
    let v120_11: Space = wrap(&(v120_10),&(v119_15_head));
    drop(v120_10);
    let v120_12: Space = wrap(&(v120_11),&(*p1));
    drop(v120_11);
    let v120_13: Space = unite(&(v120_7),&(v120_12));
    drop(v120_12);
    v119_15.join_into((v120_13).clone());
  }
  drop(v119_15_cursor);
  drop(v119_8);
  (v119_15).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v125_9 = Space::new();
  let mut v125_9_cursor = (*s0).read_zipper();
  for v125_9_byte in v125_9_cursor.child_mask().iter() {
    v125_9_cursor.descend_to_byte(v125_9_byte);
    let v125_9_tail = v125_9_cursor.make_map();
    v125_9_cursor.ascend(1);
    let v125_9_head = Path::from_slice(&[v125_9_byte]);
    let v126_2: Space = singleton(&(v125_9_head));
    let v126_3: Space = intersect(&(*CONSTANT_28),&(v126_2));
    let v126_4: Space = if has_head(&(v126_3)) { singleton(&[]) } else { Space::new() };
    drop(v126_3);
    let v126_5: Space = subtract(&(*CONSTANT_0),&(v126_4));
    drop(v126_4);
    let v126_8: Space = if (v126_5).is_empty() { Space::new() } else {
      let v127_6: Path = concat_path(&(*p0),&(v125_9_head));
      let v127_7: Space = routine_14(c, &(v127_6), &(v125_9_tail), &(*s1));
      compose(&(v126_5),&(v127_7))
    };
    drop(v126_5);
    let v126_9: Space = intersect(&(*CONSTANT_28),&(v126_2));
    drop(v126_2);
    let v126_10: Space = if has_head(&(v126_9)) { singleton(&[]) } else { Space::new() };
    drop(v126_9);
    let v126_12: Space = if (v126_10).is_empty() { Space::new() } else {
      let v128_6: Path = concat_path(&(*p0),&(v125_9_head));
      let mut v128_11 = Space::new();
      let mut v128_11_cursor = (v125_9_tail).read_zipper();
      for v128_11_byte in v128_11_cursor.child_mask().iter() {
        v128_11_cursor.descend_to_byte(v128_11_byte);
        let v128_11_tail = v128_11_cursor.make_map();
        v128_11_cursor.ascend(1);
        let v128_11_head = Path::from_slice(&[v128_11_byte]);
        let v129_2: Space = singleton(&(v128_11_head));
        let v129_3: Space = intersect(&(*CONSTANT_28),&(v129_2));
        let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
        drop(v129_3);
        let v129_5: Space = subtract(&(*CONSTANT_0),&(v129_4));
        drop(v129_4);
        let v129_7: Space = if (v129_5).is_empty() { Space::new() } else {
          let v130_6: Space = routine_16(c, &(v128_11_head), &(v128_6), &(v128_11_tail), &(*s1));
          compose(&(v129_5),&(v130_6))
        };
        drop(v129_5);
        let v129_8: Space = intersect(&(*CONSTANT_28),&(v129_2));
        drop(v129_2);
        let v129_9: Space = if has_head(&(v129_8)) { singleton(&[]) } else { Space::new() };
        drop(v129_8);
        let v129_11: Space = if (v129_9).is_empty() { Space::new() } else {
          let v131_10: Space = routine_17(c, &(v128_11_head), &(v128_6), &(v128_11_tail), &(*s1));
          compose(&(v129_9),&(v131_10))
        };
        drop(v129_9);
        let v129_12: Space = unite(&(v129_7),&(v129_11));
        v128_11.join_into((v129_12).clone());
      }
      drop(v128_11_cursor);
      drop(v128_6);
      compose(&(v126_10),&(v128_11))
    };
    drop(v126_10);
    let v126_13: Space = unite(&(v126_8),&(v126_12));
    v125_9.join_into((v126_13).clone());
  }
  drop(v125_9_cursor);
  (v125_9).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v132_7: Space = unwrap(&(*s1),&(*CONSTANT_21));
  let v132_9: Space = unwrap(&(v132_7),&(*CONSTANT_25));
  drop(v132_7);
  let mut v132_16 = Space::new();
  let mut v132_16_cursor = (*s0).read_zipper();
  for v132_16_byte in v132_16_cursor.child_mask().iter() {
    v132_16_cursor.descend_to_byte(v132_16_byte);
    let v132_16_tail = v132_16_cursor.make_map();
    v132_16_cursor.ascend(1);
    let v132_16_head = Path::from_slice(&[v132_16_byte]);
    let v133_2: Space = singleton(&(v132_16_head));
    let v133_3: Space = intersect(&(*CONSTANT_28),&(v133_2));
    let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
    drop(v133_3);
    let v133_5: Space = subtract(&(*CONSTANT_0),&(v133_4));
    drop(v133_4);
    let v133_7: Space = if (v133_5).is_empty() { Space::new() } else {
      let mut v134_6 = Space::new();
      let mut v134_6_cursor = (v132_16_tail).read_zipper();
      for v134_6_byte in v134_6_cursor.child_mask().iter() {
        v134_6_cursor.descend_to_byte(v134_6_byte);
        let v134_6_tail = v134_6_cursor.make_map();
        v134_6_cursor.ascend(1);
        let v134_6_head = Path::from_slice(&[v134_6_byte]);
        let v135_2: Space = singleton(&(v134_6_head));
        let v135_3: Space = intersect(&(*CONSTANT_28),&(v135_2));
        let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
        drop(v135_3);
        let v135_5: Space = subtract(&(*CONSTANT_0),&(v135_4));
        drop(v135_4);
        let v135_8: Space = if (v135_5).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v132_16_head),&(v134_6_head));
          let v136_7: Space = routine_16(c, &(v136_6), &(*p0), &(v134_6_tail), &(*s1));
          compose(&(v135_5),&(v136_7))
        };
        drop(v135_5);
        let v135_9: Space = intersect(&(*CONSTANT_28),&(v135_2));
        drop(v135_2);
        let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
        drop(v135_9);
        let v135_12: Space = if (v135_10).is_empty() { Space::new() } else {
          let v137_6: Path = concat_path(&(v132_16_head),&(v134_6_head));
          let v137_11: Space = routine_17(c, &(v137_6), &(*p0), &(v134_6_tail), &(*s1));
          drop(v137_6);
          compose(&(v135_10),&(v137_11))
        };
        drop(v135_10);
        let v135_13: Space = unite(&(v135_8),&(v135_12));
        v134_6.join_into((v135_13).clone());
      }
      drop(v134_6_cursor);
      compose(&(v133_5),&(v134_6))
    };
    drop(v133_5);
    let v133_8: Space = intersect(&(*CONSTANT_28),&(v133_2));
    drop(v133_2);
    let v133_9: Space = if has_head(&(v133_8)) { singleton(&[]) } else { Space::new() };
    drop(v133_8);
    let v133_12: Space = if (v133_9).is_empty() { Space::new() } else {
      let v138_10: Space = unwrap(&(v132_9),&(v132_16_head));
      let mut v138_11 = Space::new();
      let mut v138_11_cursor = (v138_10).read_zipper();
      for v138_11_byte in v138_11_cursor.child_mask().iter() {
        v138_11_cursor.descend_to_byte(v138_11_byte);
        let v138_11_tail = v138_11_cursor.make_map();
        v138_11_cursor.ascend(1);
        let v138_11_head = Path::from_slice(&[v138_11_byte]);
        let v139_2: Space = singleton(&(v138_11_head));
        let v139_3: Space = intersect(&(*CONSTANT_28),&(v139_2));
        let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
        drop(v139_3);
        let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
        drop(v139_4);
        let v139_7: Space = if (v139_5).is_empty() { Space::new() } else {
          let v140_6: Space = routine_24(c, &(v138_11_head), &(*p0), &(v138_11_tail));
          compose(&(v139_5),&(v140_6))
        };
        drop(v139_5);
        let v139_8: Space = intersect(&(*CONSTANT_28),&(v139_2));
        drop(v139_2);
        let v139_9: Space = if has_head(&(v139_8)) { singleton(&[]) } else { Space::new() };
        drop(v139_8);
        let v139_11: Space = if (v139_9).is_empty() { Space::new() } else {
          let v141_10: Space = routine_25(c, &(v138_11_head), &(*p0), &(v138_11_tail));
          compose(&(v139_9),&(v141_10))
        };
        drop(v139_9);
        let v139_12: Space = unite(&(v139_7),&(v139_11));
        v138_11.join_into((v139_12).clone());
      }
      drop(v138_11_cursor);
      drop(v138_10);
      compose(&(v133_9),&(v138_11))
    };
    drop(v133_9);
    let v133_13: Space = unite(&(v133_7),&(v133_12));
    v132_16.join_into((v133_13).clone());
  }
  drop(v132_16_cursor);
  drop(v132_9);
  (v132_16).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v142_8: Space = unwrap(&(*s1),&(*CONSTANT_21));
  let v142_10: Space = unwrap(&(v142_8),&(*CONSTANT_25));
  drop(v142_8);
  let v142_11: Space = unwrap(&(v142_10),&(*p0));
  drop(v142_10);
  let mut v142_15 = Space::new();
  let mut v142_15_cursor = (*s0).read_zipper();
  for v142_15_byte in v142_15_cursor.child_mask().iter() {
    v142_15_cursor.descend_to_byte(v142_15_byte);
    let v142_15_tail = v142_15_cursor.make_map();
    v142_15_cursor.ascend(1);
    let v142_15_head = Path::from_slice(&[v142_15_byte]);
    let v143_2: Space = singleton(&(v142_15_head));
    let v143_3: Space = intersect(&(*CONSTANT_28),&(v143_2));
    let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
    drop(v143_3);
    let v143_5: Space = subtract(&(*CONSTANT_0),&(v143_4));
    drop(v143_4);
    let v143_8: Space = if (v143_5).is_empty() { Space::new() } else {
      let v144_6: Path = concat_path(&(*p0),&(v142_15_head));
      let v144_7: Space = routine_16(c, &(v144_6), &(*p1), &(v142_15_tail), &(*s1));
      drop(v144_6);
      compose(&(v143_5),&(v144_7))
    };
    drop(v143_5);
    let v143_9: Space = intersect(&(*CONSTANT_28),&(v143_2));
    drop(v143_2);
    let v143_10: Space = if has_head(&(v143_9)) { singleton(&[]) } else { Space::new() };
    drop(v143_9);
    let v143_13: Space = if (v143_10).is_empty() { Space::new() } else {
      let v145_11: Space = unwrap(&(v142_11),&(v142_15_head));
      let mut v145_12 = Space::new();
      let mut v145_12_cursor = (v145_11).read_zipper();
      for v145_12_byte in v145_12_cursor.child_mask().iter() {
        v145_12_cursor.descend_to_byte(v145_12_byte);
        let v145_12_tail = v145_12_cursor.make_map();
        v145_12_cursor.ascend(1);
        let v145_12_head = Path::from_slice(&[v145_12_byte]);
        let v146_2: Space = singleton(&(v145_12_head));
        let v146_3: Space = intersect(&(*CONSTANT_28),&(v146_2));
        let v146_4: Space = if has_head(&(v146_3)) { singleton(&[]) } else { Space::new() };
        drop(v146_3);
        let v146_5: Space = subtract(&(*CONSTANT_0),&(v146_4));
        drop(v146_4);
        let v146_7: Space = if (v146_5).is_empty() { Space::new() } else {
          let v147_6: Space = routine_24(c, &(v145_12_head), &(*p1), &(v145_12_tail));
          compose(&(v146_5),&(v147_6))
        };
        drop(v146_5);
        let v146_8: Space = intersect(&(*CONSTANT_28),&(v146_2));
        drop(v146_2);
        let v146_9: Space = if has_head(&(v146_8)) { singleton(&[]) } else { Space::new() };
        drop(v146_8);
        let v146_11: Space = if (v146_9).is_empty() { Space::new() } else {
          let v148_10: Space = routine_25(c, &(v145_12_head), &(*p1), &(v145_12_tail));
          compose(&(v146_9),&(v148_10))
        };
        drop(v146_9);
        let v146_12: Space = unite(&(v146_7),&(v146_11));
        v145_12.join_into((v146_12).clone());
      }
      drop(v145_12_cursor);
      drop(v145_11);
      compose(&(v143_10),&(v145_12))
    };
    drop(v143_10);
    let v143_14: Space = unite(&(v143_8),&(v143_13));
    v142_15.join_into((v143_14).clone());
  }
  drop(v142_15_cursor);
  drop(v142_11);
  (v142_15).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v149_5: Space = unwrap(&(*s1),&(*CONSTANT_21));
  let v149_7: Space = unwrap(&(v149_5),&(*CONSTANT_25));
  drop(v149_5);
  let v149_8: Space = unwrap(&(v149_7),&(*p0));
  drop(v149_7);
  let mut v149_15 = Space::new();
  let mut v149_15_cursor = (v149_8).read_zipper();
  for v149_15_byte in v149_15_cursor.child_mask().iter() {
    v149_15_cursor.descend_to_byte(v149_15_byte);
    let v149_15_tail = v149_15_cursor.make_map();
    v149_15_cursor.ascend(1);
    let v149_15_head = Path::from_slice(&[v149_15_byte]);
    let v150_2: Space = singleton(&(v149_15_head));
    let v150_3: Space = intersect(&(*CONSTANT_28),&(v150_2));
    let v150_4: Space = if has_head(&(v150_3)) { singleton(&[]) } else { Space::new() };
    drop(v150_3);
    let v150_5: Space = subtract(&(*CONSTANT_0),&(v150_4));
    drop(v150_4);
    let v150_7: Space = if (v150_5).is_empty() { Space::new() } else {
      let mut v151_6 = Space::new();
      let mut v151_6_cursor = (v149_15_tail).read_zipper();
      for v151_6_byte in v151_6_cursor.child_mask().iter() {
        v151_6_cursor.descend_to_byte(v151_6_byte);
        let v151_6_tail = v151_6_cursor.make_map();
        v151_6_cursor.ascend(1);
        let v151_6_head = Path::from_slice(&[v151_6_byte]);
        let v152_2: Space = singleton(&(v151_6_head));
        let v152_3: Space = intersect(&(*CONSTANT_28),&(v152_2));
        let v152_4: Space = if has_head(&(v152_3)) { singleton(&[]) } else { Space::new() };
        drop(v152_3);
        let v152_5: Space = subtract(&(*CONSTANT_0),&(v152_4));
        drop(v152_4);
        let v152_8: Space = if (v152_5).is_empty() { Space::new() } else {
          let v153_6: Path = concat_path(&(v149_15_head),&(v151_6_head));
          let v153_7: Space = routine_24(c, &(v153_6), &(*p1), &(v151_6_tail));
          compose(&(v152_5),&(v153_7))
        };
        drop(v152_5);
        let v152_9: Space = intersect(&(*CONSTANT_28),&(v152_2));
        drop(v152_2);
        let v152_10: Space = if has_head(&(v152_9)) { singleton(&[]) } else { Space::new() };
        drop(v152_9);
        let v152_12: Space = if (v152_10).is_empty() { Space::new() } else {
          let v154_6: Path = concat_path(&(v149_15_head),&(v151_6_head));
          let v154_11: Space = routine_25(c, &(v154_6), &(*p1), &(v151_6_tail));
          drop(v154_6);
          compose(&(v152_10),&(v154_11))
        };
        drop(v152_10);
        let v152_13: Space = unite(&(v152_8),&(v152_12));
        v151_6.join_into((v152_13).clone());
      }
      drop(v151_6_cursor);
      compose(&(v150_5),&(v151_6))
    };
    drop(v150_5);
    let v150_8: Space = intersect(&(*CONSTANT_28),&(v150_2));
    drop(v150_2);
    let v150_9: Space = if has_head(&(v150_8)) { singleton(&[]) } else { Space::new() };
    drop(v150_8);
    let v150_10: Space = compose(&(v150_9),&(v149_15_tail));
    drop(v150_9);
    let v150_11: Space = wrap(&(v150_10),&(v149_15_head));
    drop(v150_10);
    let v150_12: Space = wrap(&(v150_11),&(*p1));
    drop(v150_11);
    let v150_13: Space = unite(&(v150_7),&(v150_12));
    drop(v150_12);
    v149_15.join_into((v150_13).clone());
  }
  drop(v149_15_cursor);
  drop(v149_8);
  (v149_15).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v155_7 = Space::new();
  let mut v155_7_cursor = (*s0).read_zipper();
  for v155_7_byte in v155_7_cursor.child_mask().iter() {
    v155_7_cursor.descend_to_byte(v155_7_byte);
    let v155_7_tail = v155_7_cursor.make_map();
    v155_7_cursor.ascend(1);
    let v155_7_head = Path::from_slice(&[v155_7_byte]);
    let v156_2: Space = singleton(&(v155_7_head));
    let v156_3: Space = intersect(&(*CONSTANT_28),&(v156_2));
    let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
    drop(v156_3);
    let v156_5: Space = compose(&(v156_4),&(v155_7_tail));
    drop(v156_4);
    let v157_6: Path = concat_path(&(*p0),&(v155_7_head));
    let v156_7: Space = wrap(&(v156_5),&(v157_6));
    drop(v156_5);
    let v156_8: Space = wrap(&(v156_7),&(*p1));
    drop(v156_7);
    let v156_9: Space = wrap(&(v156_8),&(*CONSTANT_25));
    drop(v156_8);
    let v156_10: Space = intersect(&(*CONSTANT_28),&(v156_2));
    drop(v156_2);
    let v156_11: Space = if has_head(&(v156_10)) { singleton(&[]) } else { Space::new() };
    drop(v156_10);
    let v156_12: Space = subtract(&(*CONSTANT_0),&(v156_11));
    drop(v156_11);
    let v156_14: Space = if (v156_12).is_empty() { Space::new() } else {
      let v158_13: Space = routine_18(c, &(v157_6), &(*p1), &(v155_7_tail));
      compose(&(v156_12),&(v158_13))
    };
    drop(v156_12);
    let v156_15: Space = unite(&(v156_9),&(v156_14));
    drop(v156_9);
    v155_7.join_into((v156_15).clone());
  }
  drop(v155_7_cursor);
  (v155_7).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v159_3: Space = wrap(&(*s0),&(*p0));
  let v159_4: Space = wrap(&(v159_3),&(*p1));
  drop(v159_3);
  let v159_6: Space = wrap(&(v159_4),&(*CONSTANT_25));
  drop(v159_4);
  (v159_6).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v160_6 = Space::new();
  let mut v160_6_cursor = (*s0).read_zipper();
  for v160_6_byte in v160_6_cursor.child_mask().iter() {
    v160_6_cursor.descend_to_byte(v160_6_byte);
    let v160_6_tail = v160_6_cursor.make_map();
    v160_6_cursor.ascend(1);
    let v160_6_head = Path::from_slice(&[v160_6_byte]);
    let v161_2: Space = singleton(&(v160_6_head));
    let v161_3: Space = intersect(&(*CONSTANT_28),&(v161_2));
    let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
    drop(v161_3);
    let v161_5: Space = subtract(&(*CONSTANT_0),&(v161_4));
    drop(v161_4);
    let v161_8: Space = if (v161_5).is_empty() { Space::new() } else {
      let v162_6: Path = concat_path(&(*p0),&(v160_6_head));
      let v162_7: Space = routine_20(c, &(v162_6), &(*p1), &(v160_6_tail));
      compose(&(v161_5),&(v162_7))
    };
    drop(v161_5);
    let v161_9: Space = intersect(&(*CONSTANT_28),&(v161_2));
    drop(v161_2);
    let v161_10: Space = if has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
    drop(v161_9);
    let v161_11: Space = compose(&(v161_10),&(v160_6_tail));
    drop(v161_10);
    let v163_6: Path = concat_path(&(*p0),&(v160_6_head));
    let v161_12: Space = wrap(&(v161_11),&(v163_6));
    drop(v161_11);
    let v161_13: Space = wrap(&(v161_12),&(*p1));
    drop(v161_12);
    let v161_14: Space = unite(&(v161_8),&(v161_13));
    drop(v161_13);
    v160_6.join_into((v161_14).clone());
  }
  drop(v160_6_cursor);
  (v160_6).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v164_3: Space = wrap(&(*s0),&(*p0));
  let v164_4: Space = wrap(&(v164_3),&(*p1));
  drop(v164_3);
  (v164_4).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v165_6 = Space::new();
  let mut v165_6_cursor = (*s0).read_zipper();
  for v165_6_byte in v165_6_cursor.child_mask().iter() {
    v165_6_cursor.descend_to_byte(v165_6_byte);
    let v165_6_tail = v165_6_cursor.make_map();
    v165_6_cursor.ascend(1);
    let v165_6_head = Path::from_slice(&[v165_6_byte]);
    let v166_2: Space = singleton(&(v165_6_head));
    let v166_3: Space = intersect(&(*CONSTANT_28),&(v166_2));
    let v166_4: Space = if has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
    drop(v166_3);
    let v166_5: Space = subtract(&(*CONSTANT_0),&(v166_4));
    drop(v166_4);
    let v166_8: Space = if (v166_5).is_empty() { Space::new() } else {
      let v167_6: Path = concat_path(&(*p0),&(v165_6_head));
      let v167_7: Space = routine_22(c, &(v167_6), &(*p1), &(v165_6_tail));
      compose(&(v166_5),&(v167_7))
    };
    drop(v166_5);
    let v166_9: Space = intersect(&(*CONSTANT_28),&(v166_2));
    drop(v166_2);
    let v166_10: Space = if has_head(&(v166_9)) { singleton(&[]) } else { Space::new() };
    drop(v166_9);
    let v166_11: Space = compose(&(v166_10),&(v165_6_tail));
    drop(v166_10);
    let v168_6: Path = concat_path(&(*p0),&(v165_6_head));
    let v166_12: Space = wrap(&(v166_11),&(v168_6));
    drop(v166_11);
    let v166_13: Space = wrap(&(v166_12),&(*p1));
    drop(v166_12);
    let v166_14: Space = unite(&(v166_8),&(v166_13));
    drop(v166_13);
    v165_6.join_into((v166_14).clone());
  }
  drop(v165_6_cursor);
  (v165_6).clone()
}

fn routine_23(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v169_3: Space = wrap(&(*s0),&(*p0));
  let v169_4: Space = wrap(&(v169_3),&(*p1));
  drop(v169_3);
  (v169_4).clone()
}

fn routine_24(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v170_6 = Space::new();
  let mut v170_6_cursor = (*s0).read_zipper();
  for v170_6_byte in v170_6_cursor.child_mask().iter() {
    v170_6_cursor.descend_to_byte(v170_6_byte);
    let v170_6_tail = v170_6_cursor.make_map();
    v170_6_cursor.ascend(1);
    let v170_6_head = Path::from_slice(&[v170_6_byte]);
    let v171_2: Space = singleton(&(v170_6_head));
    let v171_3: Space = intersect(&(*CONSTANT_28),&(v171_2));
    let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
    drop(v171_3);
    let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
    drop(v171_4);
    let v171_8: Space = if (v171_5).is_empty() { Space::new() } else {
      let v172_6: Path = concat_path(&(*p0),&(v170_6_head));
      let v172_7: Space = routine_24(c, &(v172_6), &(*p1), &(v170_6_tail));
      compose(&(v171_5),&(v172_7))
    };
    drop(v171_5);
    let v171_9: Space = intersect(&(*CONSTANT_28),&(v171_2));
    drop(v171_2);
    let v171_10: Space = if has_head(&(v171_9)) { singleton(&[]) } else { Space::new() };
    drop(v171_9);
    let v171_11: Space = compose(&(v171_10),&(v170_6_tail));
    drop(v171_10);
    let v173_6: Path = concat_path(&(*p0),&(v170_6_head));
    let v171_12: Space = wrap(&(v171_11),&(v173_6));
    drop(v171_11);
    let v171_13: Space = wrap(&(v171_12),&(*p1));
    drop(v171_12);
    let v171_14: Space = unite(&(v171_8),&(v171_13));
    drop(v171_13);
    v170_6.join_into((v171_14).clone());
  }
  drop(v170_6_cursor);
  (v170_6).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v174_3: Space = wrap(&(*s0),&(*p0));
  let v174_4: Space = wrap(&(v174_3),&(*p1));
  drop(v174_3);
  (v174_4).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
