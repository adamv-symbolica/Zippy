#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("18 12 0 0 0 1 1 0 1 0 0 0 1 1 12 0 0 0 1 1 1 0 0 0 0 1 1 10 0 0 1 1 0 1 0 0 1 1 10 0 0 1 1 1 0 0 0 1 1 11 0 1 0 0 1 1 0 1 0 1 1 11 0 1 0 0 1 1 1 0 0 1 1 13 0 1 0 1 1 0 1 0 0 0 0 1 1 13 0 1 0 1 1 1 0 0 0 0 0 1 1 10 0 1 1 0 0 0 1 0 1 1 11 0 1 1 1 0 0 0 0 0 1 1 14 1 0 0 0 1 1 0 0 0 1 0 0 1 1 14 1 0 0 0 1 1 1 0 1 0 0 0 1 1 12 1 0 0 1 1 1 0 0 1 0 1 1 12 1 0 0 1 1 1 0 1 0 0 1 1 11 1 0 1 1 0 0 0 0 0 1 1 10 1 0 1 1 1 0 1 0 1 1 7 1 1 0 0 0 1 1 6 1 1 1 0 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("18 14 0 0 0 0 1 1 0 0 1 0 0 0 1 1 14 0 0 0 0 1 1 0 1 0 0 0 0 1 1 12 0 0 0 1 1 0 0 1 0 0 1 1 12 0 0 0 1 1 0 1 0 0 0 1 1 10 0 0 1 1 0 0 1 0 1 1 10 0 0 1 1 0 1 0 0 1 1 13 0 1 0 1 1 0 0 0 0 0 0 1 1 12 0 1 0 1 1 0 1 0 1 0 1 1 9 0 1 1 0 0 0 0 1 1 8 0 1 1 0 1 0 1 1 14 1 0 0 0 1 1 0 0 0 1 0 0 1 1 11 1 0 0 0 1 1 1 0 0 1 1 12 1 0 0 1 1 0 1 0 1 0 1 1 12 1 0 0 1 1 1 0 0 1 0 1 1 11 1 0 1 1 0 0 0 0 0 1 1 11 1 0 1 1 1 0 0 0 0 1 1 9 1 1 0 0 0 1 0 1 1 7 1 1 0 0 0 1 1"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("11 14 0 0 0 0 1 1 0 0 1 0 0 0 1 1 14 0 0 0 0 1 1 1 0 1 0 0 0 1 1 12 0 0 0 1 1 0 0 1 0 0 1 1 12 0 0 0 1 1 1 0 1 0 0 1 1 10 0 0 1 1 0 0 1 0 1 1 10 0 0 1 1 1 0 1 0 1 1 13 0 1 0 1 1 0 0 0 0 0 0 1 1 9 0 1 1 0 0 0 0 1 1 9 0 1 1 1 0 0 0 1 1 5 1 0 0 1 1 5 1 1 0 1 1"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,0,1,0,0,1,1]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("47 24 0 0 0 0 1 0 1 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 22 0 0 0 0 1 0 1 1 1 1 0 0 0 0 1 1 0 1 0 0 1 1 22 0 0 0 0 1 0 1 1 1 1 0 0 0 0 1 1 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 1 1 0 0 0 1 0 0 1 1 0 1 0 1 1 23 0 0 0 0 1 0 1 1 1 1 0 0 0 1 0 0 1 1 1 0 0 1 1 25 0 0 0 0 1 0 1 1 1 1 0 0 0 1 0 1 1 0 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 1 1 0 0 0 1 0 1 1 1 0 0 0 0 0 1 1 22 0 0 0 0 1 0 1 1 1 1 0 0 0 1 1 0 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 1 1 0 0 0 1 1 1 0 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 1 1 0 0 1 0 0 1 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 22 0 0 0 0 1 0 1 1 1 1 0 0 1 0 1 1 1 0 1 0 1 1 19 0 0 0 0 1 0 1 1 1 1 0 0 1 1 0 0 0 1 1 18 0 0 0 0 1 0 1 1 1 1 0 0 1 1 1 0 1 1 26 0 0 0 0 1 0 1 1 1 1 0 1 0 0 0 0 1 1 0 0 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 1 1 0 1 0 0 0 0 1 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 22 0 0 0 0 1 0 1 1 1 1 0 1 0 0 1 1 0 0 1 0 1 1 22 0 0 0 0 1 0 1 1 1 1 0 1 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 1 1 0 1 0 1 0 1 1 0 0 0 0 0 0 1 1 21 0 0 0 0 1 0 1 1 1 1 0 1 0 1 1 0 0 0 0 1 1 21 0 0 0 0 1 0 1 1 1 1 0 1 0 1 1 1 0 0 0 1 1 17 0 0 0 0 1 0 1 1 1 1 0 1 1 0 0 1 1 17 0 0 0 0 1 0 1 1 1 1 0 1 1 1 0 1 1 26 0 0 0 0 1 0 1 1 1 1 1 0 0 0 0 0 1 1 0 0 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 22 0 0 0 0 1 0 1 1 1 1 1 0 0 0 1 1 0 0 1 0 1 1 22 0 0 0 0 1 0 1 1 1 1 1 0 0 0 1 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 1 1 1 0 0 1 0 1 1 0 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 1 1 1 0 0 1 1 0 0 0 0 1 1 20 0 0 0 0 1 0 1 1 1 1 1 0 0 1 1 0 1 0 1 1 26 0 0 0 0 1 0 1 1 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 1 1 1 0 1 0 0 0 1 1 1 0 0 1 1 24 0 0 0 0 1 0 1 1 1 1 1 0 1 0 0 1 1 0 1 0 1 0 1 1 24 0 0 0 0 1 0 1 1 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 21 0 0 0 0 1 0 1 1 1 1 1 0 1 1 0 0 0 1 0 1 1 19 0 0 0 0 1 0 1 1 1 1 1 0 1 1 0 0 0 1 1"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,0,1,1]));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,1,0,0,1,1]));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,0,1,1,1,0,0,1,0,0,1,1]));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,0,1,0,0,1,1,1,0,0,1,0,0,1,1]));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
fn routine_0(c: &mut Context) -> Space {
  let v0_14: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v1_13: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v2_4: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
      let v2_7: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4));
      let v2_8: Space = unite(&(v2_4),&(v2_7));
      let v2_11: Space = routine_2(c, &(*CONSTANT_5), &(*CONSTANT_6));
      let v2_12: Space = unite(&(v2_8),&(v2_11));
      compose(&(*CONSTANT_0),&(v2_12))
    };
    compose(&(*CONSTANT_0),&(v1_13))
  };
  let v0_16: Space = wrap(&(v0_14),&(*CONSTANT_7));
  let v0_18: Space = unite(&(v0_16),&(*CONSTANT_8));
  let mut v0_60: Space = (v0_18).clone();
  loop {
    let v3_1: Space = unwrap(&(v0_60),&(*CONSTANT_9));
    let v3_2: Space = unwrap(&(v0_60),&(*CONSTANT_7));
    let v3_3: Space = unite(&(v3_1),&(v3_2));
    let v3_4: Space = wrap(&(v3_3),&(*CONSTANT_9));
    drop(v3_3);
    let v3_5: Space = unwrap(&(v3_1),&(*CONSTANT_10));
    let mut v3_6 = Space::new();
    let mut v3_6_cursor = (v3_5).read_zipper();
    for v3_6_byte in v3_6_cursor.child_mask().iter() {
      v3_6_cursor.descend_to_byte(v3_6_byte);
      let v3_6_tail = v3_6_cursor.make_map();
      v3_6_cursor.ascend(1);
      let v3_6_head = Path::from_slice(&[v3_6_byte]);
      let v4_2: Space = singleton(&(v3_6_head));
      let v4_3: Space = intersect(&(*CONSTANT_14),&(v4_2));
      let v4_4: Space = if has_head(&(v4_3)) { singleton(&[]) } else { Space::new() };
      drop(v4_3);
      let v4_5: Space = subtract(&(*CONSTANT_0),&(v4_4));
      drop(v4_4);
      let v4_7: Space = if (v4_5).is_empty() { Space::new() } else {
        let mut v5_6 = Space::new();
        let mut v5_6_cursor = (v3_6_tail).read_zipper();
        for v5_6_byte in v5_6_cursor.child_mask().iter() {
          v5_6_cursor.descend_to_byte(v5_6_byte);
          let v5_6_tail = v5_6_cursor.make_map();
          v5_6_cursor.ascend(1);
          let v5_6_head = Path::from_slice(&[v5_6_byte]);
          let v6_2: Space = singleton(&(v5_6_head));
          let v6_3: Space = intersect(&(*CONSTANT_14),&(v6_2));
          let v6_4: Space = if has_head(&(v6_3)) { singleton(&[]) } else { Space::new() };
          drop(v6_3);
          let v6_5: Space = subtract(&(*CONSTANT_0),&(v6_4));
          drop(v6_4);
          let v6_8: Space = if (v6_5).is_empty() { Space::new() } else {
            let v7_6: Path = concat_path(&(v3_6_head),&(v5_6_head));
            let v7_7: Space = routine_3(c, &(v7_6), &(v5_6_tail), &(v0_60));
            compose(&(v6_5),&(v7_7))
          };
          drop(v6_5);
          let v6_9: Space = intersect(&(*CONSTANT_14),&(v6_2));
          drop(v6_2);
          let v6_10: Space = if has_head(&(v6_9)) { singleton(&[]) } else { Space::new() };
          drop(v6_9);
          let v6_12: Space = if (v6_10).is_empty() { Space::new() } else {
            let v8_6: Path = concat_path(&(v3_6_head),&(v5_6_head));
            let v8_11: Space = routine_4(c, &(v8_6), &(v5_6_tail), &(v0_60));
            drop(v8_6);
            compose(&(v6_10),&(v8_11))
          };
          drop(v6_10);
          let v6_13: Space = unite(&(v6_8),&(v6_12));
          v5_6.join_into((v6_13).clone());
        }
        drop(v5_6_cursor);
        compose(&(v4_5),&(v5_6))
      };
      drop(v4_5);
      let v4_8: Space = intersect(&(*CONSTANT_14),&(v4_2));
      drop(v4_2);
      let v4_9: Space = if has_head(&(v4_8)) { singleton(&[]) } else { Space::new() };
      drop(v4_8);
      let v4_11: Space = if (v4_9).is_empty() { Space::new() } else {
        let mut v9_10 = Space::new();
        let mut v9_10_cursor = (v3_6_tail).read_zipper();
        for v9_10_byte in v9_10_cursor.child_mask().iter() {
          v9_10_cursor.descend_to_byte(v9_10_byte);
          let v9_10_tail = v9_10_cursor.make_map();
          v9_10_cursor.ascend(1);
          let v9_10_head = Path::from_slice(&[v9_10_byte]);
          let v10_2: Space = singleton(&(v9_10_head));
          let v10_3: Space = intersect(&(*CONSTANT_14),&(v10_2));
          let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
          drop(v10_3);
          let v10_5: Space = subtract(&(*CONSTANT_0),&(v10_4));
          drop(v10_4);
          let v10_8: Space = if (v10_5).is_empty() { Space::new() } else {
            let v11_6: Path = concat_path(&(v3_6_head),&(v9_10_head));
            let v11_7: Space = routine_3(c, &(v11_6), &(v9_10_tail), &(v0_60));
            compose(&(v10_5),&(v11_7))
          };
          drop(v10_5);
          let v10_9: Space = intersect(&(*CONSTANT_14),&(v10_2));
          drop(v10_2);
          let v10_10: Space = if has_head(&(v10_9)) { singleton(&[]) } else { Space::new() };
          drop(v10_9);
          let v10_12: Space = if (v10_10).is_empty() { Space::new() } else {
            let v12_6: Path = concat_path(&(v3_6_head),&(v9_10_head));
            let v12_11: Space = routine_5(c, &(v12_6), &(v9_10_tail), &(v0_60));
            drop(v12_6);
            compose(&(v10_10),&(v12_11))
          };
          drop(v10_10);
          let v10_13: Space = unite(&(v10_8),&(v10_12));
          v9_10.join_into((v10_13).clone());
        }
        drop(v9_10_cursor);
        compose(&(v4_9),&(v9_10))
      };
      drop(v4_9);
      let v4_12: Space = unite(&(v4_7),&(v4_11));
      v3_6.join_into((v4_12).clone());
    }
    drop(v3_6_cursor);
    drop(v3_5);
    let v3_7: Space = unwrap(&(v3_1),&(*CONSTANT_11));
    drop(v3_1);
    let mut v3_8 = Space::new();
    let mut v3_8_cursor = (v3_7).read_zipper();
    for v3_8_byte in v3_8_cursor.child_mask().iter() {
      v3_8_cursor.descend_to_byte(v3_8_byte);
      let v3_8_tail = v3_8_cursor.make_map();
      v3_8_cursor.ascend(1);
      let v3_8_head = Path::from_slice(&[v3_8_byte]);
      let v13_2: Space = singleton(&(v3_8_head));
      let v13_3: Space = intersect(&(*CONSTANT_14),&(v13_2));
      let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
      drop(v13_3);
      let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
      drop(v13_4);
      let v13_7: Space = if (v13_5).is_empty() { Space::new() } else {
        let mut v14_6 = Space::new();
        let mut v14_6_cursor = (v3_8_tail).read_zipper();
        for v14_6_byte in v14_6_cursor.child_mask().iter() {
          v14_6_cursor.descend_to_byte(v14_6_byte);
          let v14_6_tail = v14_6_cursor.make_map();
          v14_6_cursor.ascend(1);
          let v14_6_head = Path::from_slice(&[v14_6_byte]);
          let v15_2: Space = singleton(&(v14_6_head));
          let v15_3: Space = intersect(&(*CONSTANT_14),&(v15_2));
          let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
          drop(v15_3);
          let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
          drop(v15_4);
          let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
            let v16_6: Path = concat_path(&(v3_8_head),&(v14_6_head));
            let v16_7: Space = routine_6(c, &(v16_6), &(v14_6_tail));
            compose(&(v15_5),&(v16_7))
          };
          drop(v15_5);
          let v15_9: Space = intersect(&(*CONSTANT_14),&(v15_2));
          drop(v15_2);
          let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
          drop(v15_9);
          let v15_12: Space = if (v15_10).is_empty() { Space::new() } else {
            let v17_6: Path = concat_path(&(v3_8_head),&(v14_6_head));
            let v17_11: Space = routine_7(c, &(v17_6), &(v14_6_tail));
            drop(v17_6);
            compose(&(v15_10),&(v17_11))
          };
          drop(v15_10);
          let v15_13: Space = unite(&(v15_8),&(v15_12));
          v14_6.join_into((v15_13).clone());
        }
        drop(v14_6_cursor);
        compose(&(v13_5),&(v14_6))
      };
      drop(v13_5);
      let v13_8: Space = intersect(&(*CONSTANT_14),&(v13_2));
      drop(v13_2);
      let v13_9: Space = if has_head(&(v13_8)) { singleton(&[]) } else { Space::new() };
      drop(v13_8);
      let v13_11: Space = if (v13_9).is_empty() { Space::new() } else {
        let mut v18_10 = Space::new();
        let mut v18_10_cursor = (v3_8_tail).read_zipper();
        for v18_10_byte in v18_10_cursor.child_mask().iter() {
          v18_10_cursor.descend_to_byte(v18_10_byte);
          let v18_10_tail = v18_10_cursor.make_map();
          v18_10_cursor.ascend(1);
          let v18_10_head = Path::from_slice(&[v18_10_byte]);
          let v19_2: Space = singleton(&(v18_10_head));
          let v19_3: Space = intersect(&(*CONSTANT_14),&(v19_2));
          let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
          drop(v19_3);
          let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
          drop(v19_4);
          let v19_8: Space = if (v19_5).is_empty() { Space::new() } else {
            let v20_6: Path = concat_path(&(v3_8_head),&(v18_10_head));
            let v20_7: Space = routine_6(c, &(v20_6), &(v18_10_tail));
            compose(&(v19_5),&(v20_7))
          };
          drop(v19_5);
          let v19_9: Space = intersect(&(*CONSTANT_14),&(v19_2));
          drop(v19_2);
          let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
          drop(v19_9);
          let v19_12: Space = if (v19_10).is_empty() { Space::new() } else {
            let v21_6: Path = concat_path(&(v3_8_head),&(v18_10_head));
            let v21_11: Space = routine_8(c, &(v21_6), &(v18_10_tail));
            drop(v21_6);
            compose(&(v19_10),&(v21_11))
          };
          drop(v19_10);
          let v19_13: Space = unite(&(v19_8),&(v19_12));
          v18_10.join_into((v19_13).clone());
        }
        drop(v18_10_cursor);
        compose(&(v13_9),&(v18_10))
      };
      drop(v13_9);
      let v13_12: Space = unite(&(v13_7),&(v13_11));
      v3_8.join_into((v13_12).clone());
    }
    drop(v3_8_cursor);
    drop(v3_7);
    let v3_9: Space = unite(&(v3_6),&(v3_8));
    let v3_10: Space = unwrap(&(v3_2),&(*CONSTANT_10));
    drop(v3_2);
    let mut v3_11 = Space::new();
    let mut v3_11_cursor = (v3_10).read_zipper();
    for v3_11_byte in v3_11_cursor.child_mask().iter() {
      v3_11_cursor.descend_to_byte(v3_11_byte);
      let v3_11_tail = v3_11_cursor.make_map();
      v3_11_cursor.ascend(1);
      let v3_11_head = Path::from_slice(&[v3_11_byte]);
      let v22_2: Space = singleton(&(v3_11_head));
      let v22_3: Space = intersect(&(*CONSTANT_14),&(v22_2));
      let v22_4: Space = if has_head(&(v22_3)) { singleton(&[]) } else { Space::new() };
      drop(v22_3);
      let v22_5: Space = subtract(&(*CONSTANT_0),&(v22_4));
      drop(v22_4);
      let v22_7: Space = if (v22_5).is_empty() { Space::new() } else {
        let mut v23_6 = Space::new();
        let mut v23_6_cursor = (v3_11_tail).read_zipper();
        for v23_6_byte in v23_6_cursor.child_mask().iter() {
          v23_6_cursor.descend_to_byte(v23_6_byte);
          let v23_6_tail = v23_6_cursor.make_map();
          v23_6_cursor.ascend(1);
          let v23_6_head = Path::from_slice(&[v23_6_byte]);
          let v24_2: Space = singleton(&(v23_6_head));
          let v24_3: Space = intersect(&(*CONSTANT_14),&(v24_2));
          let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
          drop(v24_3);
          let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
          drop(v24_4);
          let v24_8: Space = if (v24_5).is_empty() { Space::new() } else {
            let v25_6: Path = concat_path(&(v3_11_head),&(v23_6_head));
            let v25_7: Space = routine_9(c, &(v25_6), &(v23_6_tail), &(v0_60));
            compose(&(v24_5),&(v25_7))
          };
          drop(v24_5);
          let v24_9: Space = intersect(&(*CONSTANT_14),&(v24_2));
          drop(v24_2);
          let v24_10: Space = if has_head(&(v24_9)) { singleton(&[]) } else { Space::new() };
          drop(v24_9);
          let v24_12: Space = if (v24_10).is_empty() { Space::new() } else {
            let v26_6: Path = concat_path(&(v3_11_head),&(v23_6_head));
            let v26_11: Space = routine_10(c, &(v26_6), &(v23_6_tail), &(v0_60));
            drop(v26_6);
            compose(&(v24_10),&(v26_11))
          };
          drop(v24_10);
          let v24_13: Space = unite(&(v24_8),&(v24_12));
          v23_6.join_into((v24_13).clone());
        }
        drop(v23_6_cursor);
        compose(&(v22_5),&(v23_6))
      };
      drop(v22_5);
      let v22_8: Space = intersect(&(*CONSTANT_14),&(v22_2));
      drop(v22_2);
      let v22_9: Space = if has_head(&(v22_8)) { singleton(&[]) } else { Space::new() };
      drop(v22_8);
      let v22_11: Space = if (v22_9).is_empty() { Space::new() } else {
        let mut v27_10 = Space::new();
        let mut v27_10_cursor = (v3_11_tail).read_zipper();
        for v27_10_byte in v27_10_cursor.child_mask().iter() {
          v27_10_cursor.descend_to_byte(v27_10_byte);
          let v27_10_tail = v27_10_cursor.make_map();
          v27_10_cursor.ascend(1);
          let v27_10_head = Path::from_slice(&[v27_10_byte]);
          let v28_2: Space = singleton(&(v27_10_head));
          let v28_3: Space = intersect(&(*CONSTANT_14),&(v28_2));
          let v28_4: Space = if has_head(&(v28_3)) { singleton(&[]) } else { Space::new() };
          drop(v28_3);
          let v28_5: Space = subtract(&(*CONSTANT_0),&(v28_4));
          drop(v28_4);
          let v28_8: Space = if (v28_5).is_empty() { Space::new() } else {
            let v29_6: Path = concat_path(&(v3_11_head),&(v27_10_head));
            let v29_7: Space = routine_9(c, &(v29_6), &(v27_10_tail), &(v0_60));
            compose(&(v28_5),&(v29_7))
          };
          drop(v28_5);
          let v28_9: Space = intersect(&(*CONSTANT_14),&(v28_2));
          drop(v28_2);
          let v28_10: Space = if has_head(&(v28_9)) { singleton(&[]) } else { Space::new() };
          drop(v28_9);
          let v28_12: Space = if (v28_10).is_empty() { Space::new() } else {
            let v30_6: Path = concat_path(&(v3_11_head),&(v27_10_head));
            let v30_11: Space = routine_11(c, &(v30_6), &(v27_10_tail), &(v0_60));
            drop(v30_6);
            compose(&(v28_10),&(v30_11))
          };
          drop(v28_10);
          let v28_13: Space = unite(&(v28_8),&(v28_12));
          v27_10.join_into((v28_13).clone());
        }
        drop(v27_10_cursor);
        compose(&(v22_9),&(v27_10))
      };
      drop(v22_9);
      let v22_12: Space = unite(&(v22_7),&(v22_11));
      v3_11.join_into((v22_12).clone());
    }
    drop(v3_11_cursor);
    let v3_12: Space = unite(&(v3_9),&(v3_11));
    let mut v3_13 = Space::new();
    let mut v3_13_cursor = (v3_10).read_zipper();
    for v3_13_byte in v3_13_cursor.child_mask().iter() {
      v3_13_cursor.descend_to_byte(v3_13_byte);
      let v3_13_tail = v3_13_cursor.make_map();
      v3_13_cursor.ascend(1);
      let v3_13_head = Path::from_slice(&[v3_13_byte]);
      let v31_2: Space = singleton(&(v3_13_head));
      let v31_3: Space = intersect(&(*CONSTANT_14),&(v31_2));
      let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
      drop(v31_3);
      let v31_5: Space = subtract(&(*CONSTANT_0),&(v31_4));
      drop(v31_4);
      let v31_7: Space = if (v31_5).is_empty() { Space::new() } else {
        let mut v32_6 = Space::new();
        let mut v32_6_cursor = (v3_13_tail).read_zipper();
        for v32_6_byte in v32_6_cursor.child_mask().iter() {
          v32_6_cursor.descend_to_byte(v32_6_byte);
          let v32_6_tail = v32_6_cursor.make_map();
          v32_6_cursor.ascend(1);
          let v32_6_head = Path::from_slice(&[v32_6_byte]);
          let v33_2: Space = singleton(&(v32_6_head));
          let v33_3: Space = intersect(&(*CONSTANT_14),&(v33_2));
          let v33_4: Space = if has_head(&(v33_3)) { singleton(&[]) } else { Space::new() };
          drop(v33_3);
          let v33_5: Space = subtract(&(*CONSTANT_0),&(v33_4));
          drop(v33_4);
          let v33_8: Space = if (v33_5).is_empty() { Space::new() } else {
            let v34_6: Path = concat_path(&(v3_13_head),&(v32_6_head));
            let v34_7: Space = routine_12(c, &(v34_6), &(v32_6_tail), &(v0_60));
            compose(&(v33_5),&(v34_7))
          };
          drop(v33_5);
          let v33_9: Space = intersect(&(*CONSTANT_14),&(v33_2));
          drop(v33_2);
          let v33_10: Space = if has_head(&(v33_9)) { singleton(&[]) } else { Space::new() };
          drop(v33_9);
          let v33_12: Space = if (v33_10).is_empty() { Space::new() } else {
            let v35_6: Path = concat_path(&(v3_13_head),&(v32_6_head));
            let v35_11: Space = routine_13(c, &(v35_6), &(v32_6_tail), &(v0_60));
            drop(v35_6);
            compose(&(v33_10),&(v35_11))
          };
          drop(v33_10);
          let v33_13: Space = unite(&(v33_8),&(v33_12));
          v32_6.join_into((v33_13).clone());
        }
        drop(v32_6_cursor);
        compose(&(v31_5),&(v32_6))
      };
      drop(v31_5);
      let v31_8: Space = intersect(&(*CONSTANT_14),&(v31_2));
      drop(v31_2);
      let v31_9: Space = if has_head(&(v31_8)) { singleton(&[]) } else { Space::new() };
      drop(v31_8);
      let v31_11: Space = if (v31_9).is_empty() { Space::new() } else {
        let mut v36_10 = Space::new();
        let mut v36_10_cursor = (v3_13_tail).read_zipper();
        for v36_10_byte in v36_10_cursor.child_mask().iter() {
          v36_10_cursor.descend_to_byte(v36_10_byte);
          let v36_10_tail = v36_10_cursor.make_map();
          v36_10_cursor.ascend(1);
          let v36_10_head = Path::from_slice(&[v36_10_byte]);
          let v37_2: Space = singleton(&(v36_10_head));
          let v37_3: Space = intersect(&(*CONSTANT_14),&(v37_2));
          let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
          drop(v37_3);
          let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
          drop(v37_4);
          let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
            let v38_6: Path = concat_path(&(v3_13_head),&(v36_10_head));
            let v38_7: Space = routine_12(c, &(v38_6), &(v36_10_tail), &(v0_60));
            compose(&(v37_5),&(v38_7))
          };
          drop(v37_5);
          let v37_9: Space = intersect(&(*CONSTANT_14),&(v37_2));
          drop(v37_2);
          let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
          drop(v37_9);
          let v37_12: Space = if (v37_10).is_empty() { Space::new() } else {
            let v39_6: Path = concat_path(&(v3_13_head),&(v36_10_head));
            let v39_11: Space = routine_14(c, &(v39_6), &(v36_10_tail), &(v0_60));
            drop(v39_6);
            compose(&(v37_10),&(v39_11))
          };
          drop(v37_10);
          let v37_13: Space = unite(&(v37_8),&(v37_12));
          v36_10.join_into((v37_13).clone());
        }
        drop(v36_10_cursor);
        compose(&(v31_9),&(v36_10))
      };
      drop(v31_9);
      let v31_12: Space = unite(&(v31_7),&(v31_11));
      v3_13.join_into((v31_12).clone());
    }
    drop(v3_13_cursor);
    drop(v3_10);
    let v3_14: Space = unite(&(v3_12),&(v3_13));
    let v3_15: Space = unwrap(&(v0_60),&(*CONSTANT_12));
    let v3_16: Space = subtract(&(v3_14),&(v3_15));
    drop(v3_15);
    let v3_17: Space = unwrap(&(v0_60),&(*CONSTANT_13));
    let v3_18: Space = subtract(&(v3_16),&(v3_17));
    drop(v3_17);
    let v3_19: Space = wrap(&(v3_18),&(*CONSTANT_13));
    let v3_20: Space = unite(&(v3_4),&(v3_19));
    drop(v3_4);
    let v3_21: Space = unite(&(v3_20),&(v0_60));
    let v0_60_next = unite(&v0_60,&(v3_21));
    if equal(&v0_60_next,&v0_60) { break; }
    v0_60 = v0_60_next;
  }
  let v0_61: Space = unwrap(&(v0_60),&(*CONSTANT_12));
  (v0_61).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v40_11 = Space::new();
  let mut v40_11_cursor = (*s0).read_zipper();
  for v40_11_byte in v40_11_cursor.child_mask().iter() {
    v40_11_cursor.descend_to_byte(v40_11_byte);
    let v40_11_tail = v40_11_cursor.make_map();
    v40_11_cursor.ascend(1);
    let v40_11_head = Path::from_slice(&[v40_11_byte]);
    let v41_2: Space = singleton(&(v40_11_head));
    let v41_3: Space = intersect(&(*CONSTANT_14),&(v41_2));
    let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
    drop(v41_3);
    let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
    drop(v41_4);
    let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
      let v42_6: Path = concat_path(&(*p0),&(v40_11_head));
      let mut v42_7 = Space::new();
      let mut v42_7_cursor = (v40_11_tail).read_zipper();
      for v42_7_byte in v42_7_cursor.child_mask().iter() {
        v42_7_cursor.descend_to_byte(v42_7_byte);
        let v42_7_tail = v42_7_cursor.make_map();
        v42_7_cursor.ascend(1);
        let v42_7_head = Path::from_slice(&[v42_7_byte]);
        let v43_2: Space = singleton(&(v42_7_head));
        let v43_3: Space = intersect(&(*CONSTANT_14),&(v43_2));
        let v43_4: Space = if has_head(&(v43_3)) { singleton(&[]) } else { Space::new() };
        drop(v43_3);
        let v43_5: Space = subtract(&(*CONSTANT_0),&(v43_4));
        drop(v43_4);
        let v43_8: Space = if (v43_5).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v42_6),&(v42_7_head));
          let v44_7: Space = routine_15(c, &(v44_6), &(v42_7_tail));
          compose(&(v43_5),&(v44_7))
        };
        drop(v43_5);
        let v43_9: Space = intersect(&(*CONSTANT_14),&(v43_2));
        drop(v43_2);
        let v43_10: Space = if has_head(&(v43_9)) { singleton(&[]) } else { Space::new() };
        drop(v43_9);
        let v43_12: Space = if (v43_10).is_empty() { Space::new() } else {
          let v45_6: Path = concat_path(&(v42_6),&(v42_7_head));
          let v45_11: Space = routine_16(c, &(v45_6), &(v42_7_tail));
          drop(v45_6);
          compose(&(v43_10),&(v45_11))
        };
        drop(v43_10);
        let v43_13: Space = unite(&(v43_8),&(v43_12));
        v42_7.join_into((v43_13).clone());
      }
      drop(v42_7_cursor);
      compose(&(v41_5),&(v42_7))
    };
    drop(v41_5);
    let v41_9: Space = intersect(&(*CONSTANT_14),&(v41_2));
    drop(v41_2);
    let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
    drop(v41_9);
    let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&(v40_11_head));
      let mut v46_11 = Space::new();
      let mut v46_11_cursor = (v40_11_tail).read_zipper();
      for v46_11_byte in v46_11_cursor.child_mask().iter() {
        v46_11_cursor.descend_to_byte(v46_11_byte);
        let v46_11_tail = v46_11_cursor.make_map();
        v46_11_cursor.ascend(1);
        let v46_11_head = Path::from_slice(&[v46_11_byte]);
        let v47_2: Space = singleton(&(v46_11_head));
        let v47_3: Space = intersect(&(*CONSTANT_14),&(v47_2));
        let v47_4: Space = if has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = subtract(&(*CONSTANT_0),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (v47_5).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&(v46_11_head));
          let v48_7: Space = routine_15(c, &(v48_6), &(v46_11_tail));
          compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = intersect(&(*CONSTANT_14),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (v47_10).is_empty() { Space::new() } else {
          let v49_6: Path = concat_path(&(v46_6),&(v46_11_head));
          let v49_11: Space = routine_17(c, &(v49_6), &(v46_11_tail));
          drop(v49_6);
          compose(&(v47_10),&(v49_11))
        };
        drop(v47_10);
        let v47_13: Space = unite(&(v47_8),&(v47_12));
        v46_11.join_into((v47_13).clone());
      }
      drop(v46_11_cursor);
      drop(v46_6);
      compose(&(v41_10),&(v46_11))
    };
    drop(v41_10);
    let v41_13: Space = unite(&(v41_8),&(v41_12));
    v40_11.join_into((v41_13).clone());
  }
  drop(v40_11_cursor);
  (v40_11).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v50_11 = Space::new();
  let mut v50_11_cursor = (*s0).read_zipper();
  for v50_11_byte in v50_11_cursor.child_mask().iter() {
    v50_11_cursor.descend_to_byte(v50_11_byte);
    let v50_11_tail = v50_11_cursor.make_map();
    v50_11_cursor.ascend(1);
    let v50_11_head = Path::from_slice(&[v50_11_byte]);
    let v51_2: Space = singleton(&(v50_11_head));
    let v51_3: Space = intersect(&(*CONSTANT_14),&(v51_2));
    let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
    drop(v51_3);
    let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
    drop(v51_4);
    let v51_8: Space = if (v51_5).is_empty() { Space::new() } else {
      let v52_6: Path = concat_path(&(*p0),&(v50_11_head));
      let mut v52_7 = Space::new();
      let mut v52_7_cursor = (v50_11_tail).read_zipper();
      for v52_7_byte in v52_7_cursor.child_mask().iter() {
        v52_7_cursor.descend_to_byte(v52_7_byte);
        let v52_7_tail = v52_7_cursor.make_map();
        v52_7_cursor.ascend(1);
        let v52_7_head = Path::from_slice(&[v52_7_byte]);
        let v53_2: Space = singleton(&(v52_7_head));
        let v53_3: Space = intersect(&(*CONSTANT_14),&(v53_2));
        let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
        drop(v53_3);
        let v53_5: Space = subtract(&(*CONSTANT_0),&(v53_4));
        drop(v53_4);
        let v53_8: Space = if (v53_5).is_empty() { Space::new() } else {
          let v54_6: Path = concat_path(&(v52_6),&(v52_7_head));
          let v54_7: Space = routine_15(c, &(v54_6), &(v52_7_tail));
          compose(&(v53_5),&(v54_7))
        };
        drop(v53_5);
        let v53_9: Space = intersect(&(*CONSTANT_14),&(v53_2));
        drop(v53_2);
        let v53_10: Space = if has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
        drop(v53_9);
        let v53_12: Space = if (v53_10).is_empty() { Space::new() } else {
          let v55_6: Path = concat_path(&(v52_6),&(v52_7_head));
          let v55_11: Space = routine_16(c, &(v55_6), &(v52_7_tail));
          drop(v55_6);
          compose(&(v53_10),&(v55_11))
        };
        drop(v53_10);
        let v53_13: Space = unite(&(v53_8),&(v53_12));
        v52_7.join_into((v53_13).clone());
      }
      drop(v52_7_cursor);
      compose(&(v51_5),&(v52_7))
    };
    drop(v51_5);
    let v51_9: Space = intersect(&(*CONSTANT_14),&(v51_2));
    drop(v51_2);
    let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
    drop(v51_9);
    let v51_12: Space = if (v51_10).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&(v50_11_head));
      let mut v56_11 = Space::new();
      let mut v56_11_cursor = (v50_11_tail).read_zipper();
      for v56_11_byte in v56_11_cursor.child_mask().iter() {
        v56_11_cursor.descend_to_byte(v56_11_byte);
        let v56_11_tail = v56_11_cursor.make_map();
        v56_11_cursor.ascend(1);
        let v56_11_head = Path::from_slice(&[v56_11_byte]);
        let v57_2: Space = singleton(&(v56_11_head));
        let v57_3: Space = intersect(&(*CONSTANT_14),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_0),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (v57_5).is_empty() { Space::new() } else {
          let v58_6: Space = routine_18(c, &(v56_11_head), &(v56_6), &(v56_11_tail));
          compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = intersect(&(*CONSTANT_14),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (v57_9).is_empty() { Space::new() } else {
          let v59_10: Space = routine_19(c, &(v56_11_head), &(v56_6), &(v56_11_tail));
          compose(&(v57_9),&(v59_10))
        };
        drop(v57_9);
        let v57_12: Space = unite(&(v57_7),&(v57_11));
        v56_11.join_into((v57_12).clone());
      }
      drop(v56_11_cursor);
      drop(v56_6);
      compose(&(v51_10),&(v56_11))
    };
    drop(v51_10);
    let v51_13: Space = unite(&(v51_8),&(v51_12));
    v50_11.join_into((v51_13).clone());
  }
  drop(v50_11_cursor);
  (v50_11).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v60_12 = Space::new();
  let mut v60_12_cursor = (*s0).read_zipper();
  for v60_12_byte in v60_12_cursor.child_mask().iter() {
    v60_12_cursor.descend_to_byte(v60_12_byte);
    let v60_12_tail = v60_12_cursor.make_map();
    v60_12_cursor.ascend(1);
    let v60_12_head = Path::from_slice(&[v60_12_byte]);
    let v61_2: Space = singleton(&(v60_12_head));
    let v61_3: Space = intersect(&(*CONSTANT_14),&(v61_2));
    let v61_4: Space = if has_head(&(v61_3)) { singleton(&[]) } else { Space::new() };
    drop(v61_3);
    let v61_5: Space = subtract(&(*CONSTANT_0),&(v61_4));
    drop(v61_4);
    let v61_8: Space = if (v61_5).is_empty() { Space::new() } else {
      let v62_6: Path = concat_path(&(*p0),&(v60_12_head));
      let mut v62_7 = Space::new();
      let mut v62_7_cursor = (v60_12_tail).read_zipper();
      for v62_7_byte in v62_7_cursor.child_mask().iter() {
        v62_7_cursor.descend_to_byte(v62_7_byte);
        let v62_7_tail = v62_7_cursor.make_map();
        v62_7_cursor.ascend(1);
        let v62_7_head = Path::from_slice(&[v62_7_byte]);
        let v63_2: Space = singleton(&(v62_7_head));
        let v63_3: Space = intersect(&(*CONSTANT_14),&(v63_2));
        let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
        drop(v63_3);
        let v63_5: Space = subtract(&(*CONSTANT_0),&(v63_4));
        drop(v63_4);
        let v63_8: Space = if (v63_5).is_empty() { Space::new() } else {
          let v64_6: Path = concat_path(&(v62_6),&(v62_7_head));
          let v64_7: Space = routine_20(c, &(v64_6), &(v62_7_tail), &(*s1));
          compose(&(v63_5),&(v64_7))
        };
        drop(v63_5);
        let v63_9: Space = intersect(&(*CONSTANT_14),&(v63_2));
        drop(v63_2);
        let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
        drop(v63_9);
        let v63_12: Space = if (v63_10).is_empty() { Space::new() } else {
          let v65_6: Path = concat_path(&(v62_6),&(v62_7_head));
          let v65_11: Space = routine_21(c, &(v65_6), &(v62_7_tail), &(*s1));
          drop(v65_6);
          compose(&(v63_10),&(v65_11))
        };
        drop(v63_10);
        let v63_13: Space = unite(&(v63_8),&(v63_12));
        v62_7.join_into((v63_13).clone());
      }
      drop(v62_7_cursor);
      compose(&(v61_5),&(v62_7))
    };
    drop(v61_5);
    let v61_9: Space = intersect(&(*CONSTANT_14),&(v61_2));
    drop(v61_2);
    let v61_10: Space = if has_head(&(v61_9)) { singleton(&[]) } else { Space::new() };
    drop(v61_9);
    let v61_12: Space = if (v61_10).is_empty() { Space::new() } else {
      let v66_6: Path = concat_path(&(*p0),&(v60_12_head));
      let mut v66_11 = Space::new();
      let mut v66_11_cursor = (v60_12_tail).read_zipper();
      for v66_11_byte in v66_11_cursor.child_mask().iter() {
        v66_11_cursor.descend_to_byte(v66_11_byte);
        let v66_11_tail = v66_11_cursor.make_map();
        v66_11_cursor.ascend(1);
        let v66_11_head = Path::from_slice(&[v66_11_byte]);
        let v67_2: Space = singleton(&(v66_11_head));
        let v67_3: Space = intersect(&(*CONSTANT_14),&(v67_2));
        let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
        drop(v67_3);
        let v67_5: Space = subtract(&(*CONSTANT_0),&(v67_4));
        drop(v67_4);
        let v67_8: Space = if (v67_5).is_empty() { Space::new() } else {
          let v68_6: Path = concat_path(&(v66_6),&(v66_11_head));
          let v68_7: Space = routine_20(c, &(v68_6), &(v66_11_tail), &(*s1));
          compose(&(v67_5),&(v68_7))
        };
        drop(v67_5);
        let v67_9: Space = intersect(&(*CONSTANT_14),&(v67_2));
        drop(v67_2);
        let v67_10: Space = if has_head(&(v67_9)) { singleton(&[]) } else { Space::new() };
        drop(v67_9);
        let v67_12: Space = if (v67_10).is_empty() { Space::new() } else {
          let v69_6: Path = concat_path(&(v66_6),&(v66_11_head));
          let v69_11: Space = routine_5(c, &(v69_6), &(v66_11_tail), &(*s1));
          drop(v69_6);
          compose(&(v67_10),&(v69_11))
        };
        drop(v67_10);
        let v67_13: Space = unite(&(v67_8),&(v67_12));
        v66_11.join_into((v67_13).clone());
      }
      drop(v66_11_cursor);
      drop(v66_6);
      compose(&(v61_10),&(v66_11))
    };
    drop(v61_10);
    let v61_13: Space = unite(&(v61_8),&(v61_12));
    v60_12.join_into((v61_13).clone());
  }
  drop(v60_12_cursor);
  (v60_12).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v70_12 = Space::new();
  let mut v70_12_cursor = (*s0).read_zipper();
  for v70_12_byte in v70_12_cursor.child_mask().iter() {
    v70_12_cursor.descend_to_byte(v70_12_byte);
    let v70_12_tail = v70_12_cursor.make_map();
    v70_12_cursor.ascend(1);
    let v70_12_head = Path::from_slice(&[v70_12_byte]);
    let v71_2: Space = singleton(&(v70_12_head));
    let v71_3: Space = intersect(&(*CONSTANT_14),&(v71_2));
    let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
    drop(v71_3);
    let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
    drop(v71_4);
    let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
      let v72_6: Path = concat_path(&(*p0),&(v70_12_head));
      let mut v72_7 = Space::new();
      let mut v72_7_cursor = (v70_12_tail).read_zipper();
      for v72_7_byte in v72_7_cursor.child_mask().iter() {
        v72_7_cursor.descend_to_byte(v72_7_byte);
        let v72_7_tail = v72_7_cursor.make_map();
        v72_7_cursor.ascend(1);
        let v72_7_head = Path::from_slice(&[v72_7_byte]);
        let v73_2: Space = singleton(&(v72_7_head));
        let v73_3: Space = intersect(&(*CONSTANT_14),&(v73_2));
        let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
        drop(v73_3);
        let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
        drop(v73_4);
        let v73_8: Space = if (v73_5).is_empty() { Space::new() } else {
          let v74_6: Path = concat_path(&(v72_6),&(v72_7_head));
          let v74_7: Space = routine_20(c, &(v74_6), &(v72_7_tail), &(*s1));
          compose(&(v73_5),&(v74_7))
        };
        drop(v73_5);
        let v73_9: Space = intersect(&(*CONSTANT_14),&(v73_2));
        drop(v73_2);
        let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
        drop(v73_9);
        let v73_12: Space = if (v73_10).is_empty() { Space::new() } else {
          let v75_6: Path = concat_path(&(v72_6),&(v72_7_head));
          let v75_11: Space = routine_21(c, &(v75_6), &(v72_7_tail), &(*s1));
          drop(v75_6);
          compose(&(v73_10),&(v75_11))
        };
        drop(v73_10);
        let v73_13: Space = unite(&(v73_8),&(v73_12));
        v72_7.join_into((v73_13).clone());
      }
      drop(v72_7_cursor);
      compose(&(v71_5),&(v72_7))
    };
    drop(v71_5);
    let v71_9: Space = intersect(&(*CONSTANT_14),&(v71_2));
    drop(v71_2);
    let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
    drop(v71_9);
    let v71_12: Space = if (v71_10).is_empty() { Space::new() } else {
      let v76_6: Path = concat_path(&(*p0),&(v70_12_head));
      let mut v76_11 = Space::new();
      let mut v76_11_cursor = (v70_12_tail).read_zipper();
      for v76_11_byte in v76_11_cursor.child_mask().iter() {
        v76_11_cursor.descend_to_byte(v76_11_byte);
        let v76_11_tail = v76_11_cursor.make_map();
        v76_11_cursor.ascend(1);
        let v76_11_head = Path::from_slice(&[v76_11_byte]);
        let v77_2: Space = singleton(&(v76_11_head));
        let v77_3: Space = intersect(&(*CONSTANT_14),&(v77_2));
        let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
        drop(v77_3);
        let v77_5: Space = subtract(&(*CONSTANT_0),&(v77_4));
        drop(v77_4);
        let v77_7: Space = if (v77_5).is_empty() { Space::new() } else {
          let v78_6: Space = routine_22(c, &(v76_11_head), &(v76_6), &(v76_11_tail), &(*s1));
          compose(&(v77_5),&(v78_6))
        };
        drop(v77_5);
        let v77_8: Space = intersect(&(*CONSTANT_14),&(v77_2));
        drop(v77_2);
        let v77_9: Space = if has_head(&(v77_8)) { singleton(&[]) } else { Space::new() };
        drop(v77_8);
        let v77_11: Space = if (v77_9).is_empty() { Space::new() } else {
          let v79_10: Space = routine_23(c, &(v76_11_head), &(v76_6), &(v76_11_tail), &(*s1));
          compose(&(v77_9),&(v79_10))
        };
        drop(v77_9);
        let v77_12: Space = unite(&(v77_7),&(v77_11));
        v76_11.join_into((v77_12).clone());
      }
      drop(v76_11_cursor);
      drop(v76_6);
      compose(&(v71_10),&(v76_11))
    };
    drop(v71_10);
    let v71_13: Space = unite(&(v71_8),&(v71_12));
    v70_12.join_into((v71_13).clone());
  }
  drop(v70_12_cursor);
  (v70_12).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v80_12 = Space::new();
  let mut v80_12_cursor = (*s0).read_zipper();
  for v80_12_byte in v80_12_cursor.child_mask().iter() {
    v80_12_cursor.descend_to_byte(v80_12_byte);
    let v80_12_tail = v80_12_cursor.make_map();
    v80_12_cursor.ascend(1);
    let v80_12_head = Path::from_slice(&[v80_12_byte]);
    let v81_2: Space = singleton(&(v80_12_head));
    let v81_3: Space = intersect(&(*CONSTANT_14),&(v81_2));
    let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
    drop(v81_3);
    let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
    drop(v81_4);
    let v81_7: Space = if (v81_5).is_empty() { Space::new() } else {
      let mut v82_6 = Space::new();
      let mut v82_6_cursor = (v80_12_tail).read_zipper();
      for v82_6_byte in v82_6_cursor.child_mask().iter() {
        v82_6_cursor.descend_to_byte(v82_6_byte);
        let v82_6_tail = v82_6_cursor.make_map();
        v82_6_cursor.ascend(1);
        let v82_6_head = Path::from_slice(&[v82_6_byte]);
        let v83_2: Space = singleton(&(v82_6_head));
        let v83_3: Space = intersect(&(*CONSTANT_14),&(v83_2));
        let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
        drop(v83_3);
        let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
        drop(v83_4);
        let v83_8: Space = if (v83_5).is_empty() { Space::new() } else {
          let v84_6: Path = concat_path(&(v80_12_head),&(v82_6_head));
          let v84_7: Space = routine_24(c, &(v84_6), &(*p0), &(v82_6_tail), &(*s1));
          compose(&(v83_5),&(v84_7))
        };
        drop(v83_5);
        let v83_9: Space = intersect(&(*CONSTANT_14),&(v83_2));
        drop(v83_2);
        let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
        drop(v83_9);
        let v83_12: Space = if (v83_10).is_empty() { Space::new() } else {
          let v85_6: Path = concat_path(&(v80_12_head),&(v82_6_head));
          let v85_11: Space = routine_25(c, &(v85_6), &(*p0), &(v82_6_tail), &(*s1));
          drop(v85_6);
          compose(&(v83_10),&(v85_11))
        };
        drop(v83_10);
        let v83_13: Space = unite(&(v83_8),&(v83_12));
        v82_6.join_into((v83_13).clone());
      }
      drop(v82_6_cursor);
      compose(&(v81_5),&(v82_6))
    };
    drop(v81_5);
    let v81_8: Space = intersect(&(*CONSTANT_14),&(v81_2));
    drop(v81_2);
    let v81_9: Space = if has_head(&(v81_8)) { singleton(&[]) } else { Space::new() };
    drop(v81_8);
    let v81_11: Space = if (v81_9).is_empty() { Space::new() } else {
      let mut v86_10 = Space::new();
      let mut v86_10_cursor = (v80_12_tail).read_zipper();
      for v86_10_byte in v86_10_cursor.child_mask().iter() {
        v86_10_cursor.descend_to_byte(v86_10_byte);
        let v86_10_tail = v86_10_cursor.make_map();
        v86_10_cursor.ascend(1);
        let v86_10_head = Path::from_slice(&[v86_10_byte]);
        let v87_2: Space = singleton(&(v86_10_head));
        let v87_3: Space = intersect(&(*CONSTANT_14),&(v87_2));
        let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
        drop(v87_3);
        let v87_5: Space = subtract(&(*CONSTANT_0),&(v87_4));
        drop(v87_4);
        let v87_8: Space = if (v87_5).is_empty() { Space::new() } else {
          let v88_6: Path = concat_path(&(v80_12_head),&(v86_10_head));
          let v88_7: Space = routine_24(c, &(v88_6), &(*p0), &(v86_10_tail), &(*s1));
          compose(&(v87_5),&(v88_7))
        };
        drop(v87_5);
        let v87_9: Space = intersect(&(*CONSTANT_14),&(v87_2));
        drop(v87_2);
        let v87_10: Space = if has_head(&(v87_9)) { singleton(&[]) } else { Space::new() };
        drop(v87_9);
        let v87_12: Space = if (v87_10).is_empty() { Space::new() } else {
          let v89_6: Path = concat_path(&(v80_12_head),&(v86_10_head));
          let v89_11: Space = routine_26(c, &(v89_6), &(*p0), &(v86_10_tail), &(*s1));
          drop(v89_6);
          compose(&(v87_10),&(v89_11))
        };
        drop(v87_10);
        let v87_13: Space = unite(&(v87_8),&(v87_12));
        v86_10.join_into((v87_13).clone());
      }
      drop(v86_10_cursor);
      compose(&(v81_9),&(v86_10))
    };
    drop(v81_9);
    let v81_12: Space = unite(&(v81_7),&(v81_11));
    v80_12.join_into((v81_12).clone());
  }
  drop(v80_12_cursor);
  (v80_12).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v90_11 = Space::new();
  let mut v90_11_cursor = (*s0).read_zipper();
  for v90_11_byte in v90_11_cursor.child_mask().iter() {
    v90_11_cursor.descend_to_byte(v90_11_byte);
    let v90_11_tail = v90_11_cursor.make_map();
    v90_11_cursor.ascend(1);
    let v90_11_head = Path::from_slice(&[v90_11_byte]);
    let v91_2: Space = singleton(&(v90_11_head));
    let v91_3: Space = intersect(&(*CONSTANT_14),&(v91_2));
    let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
    drop(v91_3);
    let v91_5: Space = subtract(&(*CONSTANT_0),&(v91_4));
    drop(v91_4);
    let v91_8: Space = if (v91_5).is_empty() { Space::new() } else {
      let v92_6: Path = concat_path(&(*p0),&(v90_11_head));
      let mut v92_7 = Space::new();
      let mut v92_7_cursor = (v90_11_tail).read_zipper();
      for v92_7_byte in v92_7_cursor.child_mask().iter() {
        v92_7_cursor.descend_to_byte(v92_7_byte);
        let v92_7_tail = v92_7_cursor.make_map();
        v92_7_cursor.ascend(1);
        let v92_7_head = Path::from_slice(&[v92_7_byte]);
        let v93_2: Space = singleton(&(v92_7_head));
        let v93_3: Space = intersect(&(*CONSTANT_14),&(v93_2));
        let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
        drop(v93_3);
        let v93_5: Space = subtract(&(*CONSTANT_0),&(v93_4));
        drop(v93_4);
        let v93_8: Space = if (v93_5).is_empty() { Space::new() } else {
          let v94_6: Path = concat_path(&(v92_6),&(v92_7_head));
          let v94_7: Space = routine_27(c, &(v94_6), &(v92_7_tail));
          compose(&(v93_5),&(v94_7))
        };
        drop(v93_5);
        let v93_9: Space = intersect(&(*CONSTANT_14),&(v93_2));
        drop(v93_2);
        let v93_10: Space = if has_head(&(v93_9)) { singleton(&[]) } else { Space::new() };
        drop(v93_9);
        let v93_12: Space = if (v93_10).is_empty() { Space::new() } else {
          let v95_6: Path = concat_path(&(v92_6),&(v92_7_head));
          let v95_11: Space = routine_28(c, &(v95_6), &(v92_7_tail));
          drop(v95_6);
          compose(&(v93_10),&(v95_11))
        };
        drop(v93_10);
        let v93_13: Space = unite(&(v93_8),&(v93_12));
        v92_7.join_into((v93_13).clone());
      }
      drop(v92_7_cursor);
      compose(&(v91_5),&(v92_7))
    };
    drop(v91_5);
    let v91_9: Space = intersect(&(*CONSTANT_14),&(v91_2));
    drop(v91_2);
    let v91_10: Space = if has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
    drop(v91_9);
    let v91_12: Space = if (v91_10).is_empty() { Space::new() } else {
      let v96_6: Path = concat_path(&(*p0),&(v90_11_head));
      let mut v96_11 = Space::new();
      let mut v96_11_cursor = (v90_11_tail).read_zipper();
      for v96_11_byte in v96_11_cursor.child_mask().iter() {
        v96_11_cursor.descend_to_byte(v96_11_byte);
        let v96_11_tail = v96_11_cursor.make_map();
        v96_11_cursor.ascend(1);
        let v96_11_head = Path::from_slice(&[v96_11_byte]);
        let v97_2: Space = singleton(&(v96_11_head));
        let v97_3: Space = intersect(&(*CONSTANT_14),&(v97_2));
        let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
        drop(v97_3);
        let v97_5: Space = subtract(&(*CONSTANT_0),&(v97_4));
        drop(v97_4);
        let v97_8: Space = if (v97_5).is_empty() { Space::new() } else {
          let v98_6: Path = concat_path(&(v96_6),&(v96_11_head));
          let v98_7: Space = routine_27(c, &(v98_6), &(v96_11_tail));
          compose(&(v97_5),&(v98_7))
        };
        drop(v97_5);
        let v97_9: Space = intersect(&(*CONSTANT_14),&(v97_2));
        drop(v97_2);
        let v97_10: Space = if has_head(&(v97_9)) { singleton(&[]) } else { Space::new() };
        drop(v97_9);
        let v97_12: Space = if (v97_10).is_empty() { Space::new() } else {
          let v99_6: Path = concat_path(&(v96_6),&(v96_11_head));
          let v99_11: Space = routine_8(c, &(v99_6), &(v96_11_tail));
          drop(v99_6);
          compose(&(v97_10),&(v99_11))
        };
        drop(v97_10);
        let v97_13: Space = unite(&(v97_8),&(v97_12));
        v96_11.join_into((v97_13).clone());
      }
      drop(v96_11_cursor);
      drop(v96_6);
      compose(&(v91_10),&(v96_11))
    };
    drop(v91_10);
    let v91_13: Space = unite(&(v91_8),&(v91_12));
    v90_11.join_into((v91_13).clone());
  }
  drop(v90_11_cursor);
  (v90_11).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v100_11 = Space::new();
  let mut v100_11_cursor = (*s0).read_zipper();
  for v100_11_byte in v100_11_cursor.child_mask().iter() {
    v100_11_cursor.descend_to_byte(v100_11_byte);
    let v100_11_tail = v100_11_cursor.make_map();
    v100_11_cursor.ascend(1);
    let v100_11_head = Path::from_slice(&[v100_11_byte]);
    let v101_2: Space = singleton(&(v100_11_head));
    let v101_3: Space = intersect(&(*CONSTANT_14),&(v101_2));
    let v101_4: Space = if has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
    drop(v101_3);
    let v101_5: Space = subtract(&(*CONSTANT_0),&(v101_4));
    drop(v101_4);
    let v101_8: Space = if (v101_5).is_empty() { Space::new() } else {
      let v102_6: Path = concat_path(&(*p0),&(v100_11_head));
      let mut v102_7 = Space::new();
      let mut v102_7_cursor = (v100_11_tail).read_zipper();
      for v102_7_byte in v102_7_cursor.child_mask().iter() {
        v102_7_cursor.descend_to_byte(v102_7_byte);
        let v102_7_tail = v102_7_cursor.make_map();
        v102_7_cursor.ascend(1);
        let v102_7_head = Path::from_slice(&[v102_7_byte]);
        let v103_2: Space = singleton(&(v102_7_head));
        let v103_3: Space = intersect(&(*CONSTANT_14),&(v103_2));
        let v103_4: Space = if has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
        drop(v103_3);
        let v103_5: Space = subtract(&(*CONSTANT_0),&(v103_4));
        drop(v103_4);
        let v103_8: Space = if (v103_5).is_empty() { Space::new() } else {
          let v104_6: Path = concat_path(&(v102_6),&(v102_7_head));
          let v104_7: Space = routine_27(c, &(v104_6), &(v102_7_tail));
          compose(&(v103_5),&(v104_7))
        };
        drop(v103_5);
        let v103_9: Space = intersect(&(*CONSTANT_14),&(v103_2));
        drop(v103_2);
        let v103_10: Space = if has_head(&(v103_9)) { singleton(&[]) } else { Space::new() };
        drop(v103_9);
        let v103_12: Space = if (v103_10).is_empty() { Space::new() } else {
          let v105_6: Path = concat_path(&(v102_6),&(v102_7_head));
          let v105_11: Space = routine_28(c, &(v105_6), &(v102_7_tail));
          drop(v105_6);
          compose(&(v103_10),&(v105_11))
        };
        drop(v103_10);
        let v103_13: Space = unite(&(v103_8),&(v103_12));
        v102_7.join_into((v103_13).clone());
      }
      drop(v102_7_cursor);
      compose(&(v101_5),&(v102_7))
    };
    drop(v101_5);
    let v101_9: Space = intersect(&(*CONSTANT_14),&(v101_2));
    drop(v101_2);
    let v101_10: Space = if has_head(&(v101_9)) { singleton(&[]) } else { Space::new() };
    drop(v101_9);
    let v101_12: Space = if (v101_10).is_empty() { Space::new() } else {
      let v106_6: Path = concat_path(&(*p0),&(v100_11_head));
      let mut v106_11 = Space::new();
      let mut v106_11_cursor = (v100_11_tail).read_zipper();
      for v106_11_byte in v106_11_cursor.child_mask().iter() {
        v106_11_cursor.descend_to_byte(v106_11_byte);
        let v106_11_tail = v106_11_cursor.make_map();
        v106_11_cursor.ascend(1);
        let v106_11_head = Path::from_slice(&[v106_11_byte]);
        let v107_2: Space = singleton(&(v106_11_head));
        let v107_3: Space = intersect(&(*CONSTANT_14),&(v107_2));
        let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
        drop(v107_3);
        let v107_5: Space = subtract(&(*CONSTANT_0),&(v107_4));
        drop(v107_4);
        let v107_7: Space = if (v107_5).is_empty() { Space::new() } else {
          let v108_6: Space = routine_29(c, &(v106_11_head), &(v106_6), &(v106_11_tail));
          compose(&(v107_5),&(v108_6))
        };
        drop(v107_5);
        let v107_8: Space = intersect(&(*CONSTANT_14),&(v107_2));
        drop(v107_2);
        let v107_9: Space = if has_head(&(v107_8)) { singleton(&[]) } else { Space::new() };
        drop(v107_8);
        let v107_11: Space = if (v107_9).is_empty() { Space::new() } else {
          let v109_10: Space = routine_30(c, &(v106_11_head), &(v106_6), &(v106_11_tail));
          compose(&(v107_9),&(v109_10))
        };
        drop(v107_9);
        let v107_12: Space = unite(&(v107_7),&(v107_11));
        v106_11.join_into((v107_12).clone());
      }
      drop(v106_11_cursor);
      drop(v106_6);
      compose(&(v101_10),&(v106_11))
    };
    drop(v101_10);
    let v101_13: Space = unite(&(v101_8),&(v101_12));
    v100_11.join_into((v101_13).clone());
  }
  drop(v100_11_cursor);
  (v100_11).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v110_11 = Space::new();
  let mut v110_11_cursor = (*s0).read_zipper();
  for v110_11_byte in v110_11_cursor.child_mask().iter() {
    v110_11_cursor.descend_to_byte(v110_11_byte);
    let v110_11_tail = v110_11_cursor.make_map();
    v110_11_cursor.ascend(1);
    let v110_11_head = Path::from_slice(&[v110_11_byte]);
    let v111_2: Space = singleton(&(v110_11_head));
    let v111_3: Space = intersect(&(*CONSTANT_14),&(v111_2));
    let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = subtract(&(*CONSTANT_0),&(v111_4));
    drop(v111_4);
    let v111_7: Space = if (v111_5).is_empty() { Space::new() } else {
      let mut v112_6 = Space::new();
      let mut v112_6_cursor = (v110_11_tail).read_zipper();
      for v112_6_byte in v112_6_cursor.child_mask().iter() {
        v112_6_cursor.descend_to_byte(v112_6_byte);
        let v112_6_tail = v112_6_cursor.make_map();
        v112_6_cursor.ascend(1);
        let v112_6_head = Path::from_slice(&[v112_6_byte]);
        let v113_2: Space = singleton(&(v112_6_head));
        let v113_3: Space = intersect(&(*CONSTANT_14),&(v113_2));
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = subtract(&(*CONSTANT_0),&(v113_4));
        drop(v113_4);
        let v113_8: Space = if (v113_5).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v110_11_head),&(v112_6_head));
          let v114_7: Space = routine_31(c, &(v114_6), &(*p0), &(v112_6_tail));
          compose(&(v113_5),&(v114_7))
        };
        drop(v113_5);
        let v113_9: Space = intersect(&(*CONSTANT_14),&(v113_2));
        drop(v113_2);
        let v113_10: Space = if has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
        drop(v113_9);
        let v113_12: Space = if (v113_10).is_empty() { Space::new() } else {
          let v115_6: Path = concat_path(&(v110_11_head),&(v112_6_head));
          let v115_11: Space = routine_32(c, &(v115_6), &(*p0), &(v112_6_tail));
          drop(v115_6);
          compose(&(v113_10),&(v115_11))
        };
        drop(v113_10);
        let v113_13: Space = unite(&(v113_8),&(v113_12));
        v112_6.join_into((v113_13).clone());
      }
      drop(v112_6_cursor);
      compose(&(v111_5),&(v112_6))
    };
    drop(v111_5);
    let v111_8: Space = intersect(&(*CONSTANT_14),&(v111_2));
    drop(v111_2);
    let v111_9: Space = if has_head(&(v111_8)) { singleton(&[]) } else { Space::new() };
    drop(v111_8);
    let v111_11: Space = if (v111_9).is_empty() { Space::new() } else {
      let mut v116_10 = Space::new();
      let mut v116_10_cursor = (v110_11_tail).read_zipper();
      for v116_10_byte in v116_10_cursor.child_mask().iter() {
        v116_10_cursor.descend_to_byte(v116_10_byte);
        let v116_10_tail = v116_10_cursor.make_map();
        v116_10_cursor.ascend(1);
        let v116_10_head = Path::from_slice(&[v116_10_byte]);
        let v117_2: Space = singleton(&(v116_10_head));
        let v117_3: Space = intersect(&(*CONSTANT_14),&(v117_2));
        let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
        drop(v117_3);
        let v117_5: Space = subtract(&(*CONSTANT_0),&(v117_4));
        drop(v117_4);
        let v117_8: Space = if (v117_5).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v110_11_head),&(v116_10_head));
          let v118_7: Space = routine_31(c, &(v118_6), &(*p0), &(v116_10_tail));
          compose(&(v117_5),&(v118_7))
        };
        drop(v117_5);
        let v117_9: Space = intersect(&(*CONSTANT_14),&(v117_2));
        drop(v117_2);
        let v117_10: Space = if has_head(&(v117_9)) { singleton(&[]) } else { Space::new() };
        drop(v117_9);
        let v117_12: Space = if (v117_10).is_empty() { Space::new() } else {
          let v119_6: Path = concat_path(&(v110_11_head),&(v116_10_head));
          let v119_11: Space = routine_33(c, &(v119_6), &(*p0), &(v116_10_tail));
          drop(v119_6);
          compose(&(v117_10),&(v119_11))
        };
        drop(v117_10);
        let v117_13: Space = unite(&(v117_8),&(v117_12));
        v116_10.join_into((v117_13).clone());
      }
      drop(v116_10_cursor);
      compose(&(v111_9),&(v116_10))
    };
    drop(v111_9);
    let v111_12: Space = unite(&(v111_7),&(v111_11));
    v110_11.join_into((v111_12).clone());
  }
  drop(v110_11_cursor);
  (v110_11).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v120_12 = Space::new();
  let mut v120_12_cursor = (*s0).read_zipper();
  for v120_12_byte in v120_12_cursor.child_mask().iter() {
    v120_12_cursor.descend_to_byte(v120_12_byte);
    let v120_12_tail = v120_12_cursor.make_map();
    v120_12_cursor.ascend(1);
    let v120_12_head = Path::from_slice(&[v120_12_byte]);
    let v121_2: Space = singleton(&(v120_12_head));
    let v121_3: Space = intersect(&(*CONSTANT_14),&(v121_2));
    let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
    drop(v121_3);
    let v121_5: Space = subtract(&(*CONSTANT_0),&(v121_4));
    drop(v121_4);
    let v121_8: Space = if (v121_5).is_empty() { Space::new() } else {
      let v122_6: Path = concat_path(&(*p0),&(v120_12_head));
      let mut v122_7 = Space::new();
      let mut v122_7_cursor = (v120_12_tail).read_zipper();
      for v122_7_byte in v122_7_cursor.child_mask().iter() {
        v122_7_cursor.descend_to_byte(v122_7_byte);
        let v122_7_tail = v122_7_cursor.make_map();
        v122_7_cursor.ascend(1);
        let v122_7_head = Path::from_slice(&[v122_7_byte]);
        let v123_2: Space = singleton(&(v122_7_head));
        let v123_3: Space = intersect(&(*CONSTANT_14),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
        drop(v123_4);
        let v123_8: Space = if (v123_5).is_empty() { Space::new() } else {
          let v124_6: Path = concat_path(&(v122_6),&(v122_7_head));
          let v124_7: Space = routine_34(c, &(v124_6), &(v122_7_tail), &(*s1));
          compose(&(v123_5),&(v124_7))
        };
        drop(v123_5);
        let v123_9: Space = intersect(&(*CONSTANT_14),&(v123_2));
        drop(v123_2);
        let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
        drop(v123_9);
        let v123_12: Space = if (v123_10).is_empty() { Space::new() } else {
          let v125_6: Path = concat_path(&(v122_6),&(v122_7_head));
          let v125_11: Space = routine_35(c, &(v125_6), &(v122_7_tail), &(*s1));
          drop(v125_6);
          compose(&(v123_10),&(v125_11))
        };
        drop(v123_10);
        let v123_13: Space = unite(&(v123_8),&(v123_12));
        v122_7.join_into((v123_13).clone());
      }
      drop(v122_7_cursor);
      compose(&(v121_5),&(v122_7))
    };
    drop(v121_5);
    let v121_9: Space = intersect(&(*CONSTANT_14),&(v121_2));
    drop(v121_2);
    let v121_10: Space = if has_head(&(v121_9)) { singleton(&[]) } else { Space::new() };
    drop(v121_9);
    let v121_12: Space = if (v121_10).is_empty() { Space::new() } else {
      let v126_6: Path = concat_path(&(*p0),&(v120_12_head));
      let mut v126_11 = Space::new();
      let mut v126_11_cursor = (v120_12_tail).read_zipper();
      for v126_11_byte in v126_11_cursor.child_mask().iter() {
        v126_11_cursor.descend_to_byte(v126_11_byte);
        let v126_11_tail = v126_11_cursor.make_map();
        v126_11_cursor.ascend(1);
        let v126_11_head = Path::from_slice(&[v126_11_byte]);
        let v127_2: Space = singleton(&(v126_11_head));
        let v127_3: Space = intersect(&(*CONSTANT_14),&(v127_2));
        let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
        drop(v127_3);
        let v127_5: Space = subtract(&(*CONSTANT_0),&(v127_4));
        drop(v127_4);
        let v127_8: Space = if (v127_5).is_empty() { Space::new() } else {
          let v128_6: Path = concat_path(&(v126_6),&(v126_11_head));
          let v128_7: Space = routine_34(c, &(v128_6), &(v126_11_tail), &(*s1));
          compose(&(v127_5),&(v128_7))
        };
        drop(v127_5);
        let v127_9: Space = intersect(&(*CONSTANT_14),&(v127_2));
        drop(v127_2);
        let v127_10: Space = if has_head(&(v127_9)) { singleton(&[]) } else { Space::new() };
        drop(v127_9);
        let v127_12: Space = if (v127_10).is_empty() { Space::new() } else {
          let v129_6: Path = concat_path(&(v126_6),&(v126_11_head));
          let v129_11: Space = routine_11(c, &(v129_6), &(v126_11_tail), &(*s1));
          drop(v129_6);
          compose(&(v127_10),&(v129_11))
        };
        drop(v127_10);
        let v127_13: Space = unite(&(v127_8),&(v127_12));
        v126_11.join_into((v127_13).clone());
      }
      drop(v126_11_cursor);
      drop(v126_6);
      compose(&(v121_10),&(v126_11))
    };
    drop(v121_10);
    let v121_13: Space = unite(&(v121_8),&(v121_12));
    v120_12.join_into((v121_13).clone());
  }
  drop(v120_12_cursor);
  (v120_12).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v130_12 = Space::new();
  let mut v130_12_cursor = (*s0).read_zipper();
  for v130_12_byte in v130_12_cursor.child_mask().iter() {
    v130_12_cursor.descend_to_byte(v130_12_byte);
    let v130_12_tail = v130_12_cursor.make_map();
    v130_12_cursor.ascend(1);
    let v130_12_head = Path::from_slice(&[v130_12_byte]);
    let v131_2: Space = singleton(&(v130_12_head));
    let v131_3: Space = intersect(&(*CONSTANT_14),&(v131_2));
    let v131_4: Space = if has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
    drop(v131_3);
    let v131_5: Space = subtract(&(*CONSTANT_0),&(v131_4));
    drop(v131_4);
    let v131_8: Space = if (v131_5).is_empty() { Space::new() } else {
      let v132_6: Path = concat_path(&(*p0),&(v130_12_head));
      let mut v132_7 = Space::new();
      let mut v132_7_cursor = (v130_12_tail).read_zipper();
      for v132_7_byte in v132_7_cursor.child_mask().iter() {
        v132_7_cursor.descend_to_byte(v132_7_byte);
        let v132_7_tail = v132_7_cursor.make_map();
        v132_7_cursor.ascend(1);
        let v132_7_head = Path::from_slice(&[v132_7_byte]);
        let v133_2: Space = singleton(&(v132_7_head));
        let v133_3: Space = intersect(&(*CONSTANT_14),&(v133_2));
        let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
        drop(v133_3);
        let v133_5: Space = subtract(&(*CONSTANT_0),&(v133_4));
        drop(v133_4);
        let v133_8: Space = if (v133_5).is_empty() { Space::new() } else {
          let v134_6: Path = concat_path(&(v132_6),&(v132_7_head));
          let v134_7: Space = routine_34(c, &(v134_6), &(v132_7_tail), &(*s1));
          compose(&(v133_5),&(v134_7))
        };
        drop(v133_5);
        let v133_9: Space = intersect(&(*CONSTANT_14),&(v133_2));
        drop(v133_2);
        let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
        drop(v133_9);
        let v133_12: Space = if (v133_10).is_empty() { Space::new() } else {
          let v135_6: Path = concat_path(&(v132_6),&(v132_7_head));
          let v135_11: Space = routine_35(c, &(v135_6), &(v132_7_tail), &(*s1));
          drop(v135_6);
          compose(&(v133_10),&(v135_11))
        };
        drop(v133_10);
        let v133_13: Space = unite(&(v133_8),&(v133_12));
        v132_7.join_into((v133_13).clone());
      }
      drop(v132_7_cursor);
      compose(&(v131_5),&(v132_7))
    };
    drop(v131_5);
    let v131_9: Space = intersect(&(*CONSTANT_14),&(v131_2));
    drop(v131_2);
    let v131_10: Space = if has_head(&(v131_9)) { singleton(&[]) } else { Space::new() };
    drop(v131_9);
    let v131_12: Space = if (v131_10).is_empty() { Space::new() } else {
      let v136_6: Path = concat_path(&(*p0),&(v130_12_head));
      let mut v136_11 = Space::new();
      let mut v136_11_cursor = (v130_12_tail).read_zipper();
      for v136_11_byte in v136_11_cursor.child_mask().iter() {
        v136_11_cursor.descend_to_byte(v136_11_byte);
        let v136_11_tail = v136_11_cursor.make_map();
        v136_11_cursor.ascend(1);
        let v136_11_head = Path::from_slice(&[v136_11_byte]);
        let v137_2: Space = singleton(&(v136_11_head));
        let v137_3: Space = intersect(&(*CONSTANT_14),&(v137_2));
        let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
        drop(v137_3);
        let v137_5: Space = subtract(&(*CONSTANT_0),&(v137_4));
        drop(v137_4);
        let v137_7: Space = if (v137_5).is_empty() { Space::new() } else {
          let v138_6: Space = routine_36(c, &(v136_11_head), &(v136_6), &(v136_11_tail), &(*s1));
          compose(&(v137_5),&(v138_6))
        };
        drop(v137_5);
        let v137_8: Space = intersect(&(*CONSTANT_14),&(v137_2));
        drop(v137_2);
        let v137_9: Space = if has_head(&(v137_8)) { singleton(&[]) } else { Space::new() };
        drop(v137_8);
        let v137_11: Space = if (v137_9).is_empty() { Space::new() } else {
          let v139_10: Space = routine_37(c, &(v136_11_head), &(v136_6), &(v136_11_tail), &(*s1));
          compose(&(v137_9),&(v139_10))
        };
        drop(v137_9);
        let v137_12: Space = unite(&(v137_7),&(v137_11));
        v136_11.join_into((v137_12).clone());
      }
      drop(v136_11_cursor);
      drop(v136_6);
      compose(&(v131_10),&(v136_11))
    };
    drop(v131_10);
    let v131_13: Space = unite(&(v131_8),&(v131_12));
    v130_12.join_into((v131_13).clone());
  }
  drop(v130_12_cursor);
  (v130_12).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v140_12 = Space::new();
  let mut v140_12_cursor = (*s0).read_zipper();
  for v140_12_byte in v140_12_cursor.child_mask().iter() {
    v140_12_cursor.descend_to_byte(v140_12_byte);
    let v140_12_tail = v140_12_cursor.make_map();
    v140_12_cursor.ascend(1);
    let v140_12_head = Path::from_slice(&[v140_12_byte]);
    let v141_2: Space = singleton(&(v140_12_head));
    let v141_3: Space = intersect(&(*CONSTANT_14),&(v141_2));
    let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
    drop(v141_3);
    let v141_5: Space = subtract(&(*CONSTANT_0),&(v141_4));
    drop(v141_4);
    let v141_7: Space = if (v141_5).is_empty() { Space::new() } else {
      let mut v142_6 = Space::new();
      let mut v142_6_cursor = (v140_12_tail).read_zipper();
      for v142_6_byte in v142_6_cursor.child_mask().iter() {
        v142_6_cursor.descend_to_byte(v142_6_byte);
        let v142_6_tail = v142_6_cursor.make_map();
        v142_6_cursor.ascend(1);
        let v142_6_head = Path::from_slice(&[v142_6_byte]);
        let v143_2: Space = singleton(&(v142_6_head));
        let v143_3: Space = intersect(&(*CONSTANT_14),&(v143_2));
        let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
        drop(v143_3);
        let v143_5: Space = subtract(&(*CONSTANT_0),&(v143_4));
        drop(v143_4);
        let v143_8: Space = if (v143_5).is_empty() { Space::new() } else {
          let v144_6: Path = concat_path(&(v140_12_head),&(v142_6_head));
          let v144_7: Space = routine_38(c, &(v144_6), &(*p0), &(v142_6_tail), &(*s1));
          compose(&(v143_5),&(v144_7))
        };
        drop(v143_5);
        let v143_9: Space = intersect(&(*CONSTANT_14),&(v143_2));
        drop(v143_2);
        let v143_10: Space = if has_head(&(v143_9)) { singleton(&[]) } else { Space::new() };
        drop(v143_9);
        let v143_12: Space = if (v143_10).is_empty() { Space::new() } else {
          let v145_6: Path = concat_path(&(v140_12_head),&(v142_6_head));
          let v145_11: Space = routine_39(c, &(v145_6), &(*p0), &(v142_6_tail), &(*s1));
          drop(v145_6);
          compose(&(v143_10),&(v145_11))
        };
        drop(v143_10);
        let v143_13: Space = unite(&(v143_8),&(v143_12));
        v142_6.join_into((v143_13).clone());
      }
      drop(v142_6_cursor);
      compose(&(v141_5),&(v142_6))
    };
    drop(v141_5);
    let v141_8: Space = intersect(&(*CONSTANT_14),&(v141_2));
    drop(v141_2);
    let v141_9: Space = if has_head(&(v141_8)) { singleton(&[]) } else { Space::new() };
    drop(v141_8);
    let v141_11: Space = if (v141_9).is_empty() { Space::new() } else {
      let mut v146_10 = Space::new();
      let mut v146_10_cursor = (v140_12_tail).read_zipper();
      for v146_10_byte in v146_10_cursor.child_mask().iter() {
        v146_10_cursor.descend_to_byte(v146_10_byte);
        let v146_10_tail = v146_10_cursor.make_map();
        v146_10_cursor.ascend(1);
        let v146_10_head = Path::from_slice(&[v146_10_byte]);
        let v147_2: Space = singleton(&(v146_10_head));
        let v147_3: Space = intersect(&(*CONSTANT_14),&(v147_2));
        let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
        drop(v147_3);
        let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
        drop(v147_4);
        let v147_8: Space = if (v147_5).is_empty() { Space::new() } else {
          let v148_6: Path = concat_path(&(v140_12_head),&(v146_10_head));
          let v148_7: Space = routine_38(c, &(v148_6), &(*p0), &(v146_10_tail), &(*s1));
          compose(&(v147_5),&(v148_7))
        };
        drop(v147_5);
        let v147_9: Space = intersect(&(*CONSTANT_14),&(v147_2));
        drop(v147_2);
        let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
        drop(v147_9);
        let v147_12: Space = if (v147_10).is_empty() { Space::new() } else {
          let v149_6: Path = concat_path(&(v140_12_head),&(v146_10_head));
          let v149_11: Space = routine_40(c, &(v149_6), &(*p0), &(v146_10_tail), &(*s1));
          drop(v149_6);
          compose(&(v147_10),&(v149_11))
        };
        drop(v147_10);
        let v147_13: Space = unite(&(v147_8),&(v147_12));
        v146_10.join_into((v147_13).clone());
      }
      drop(v146_10_cursor);
      compose(&(v141_9),&(v146_10))
    };
    drop(v141_9);
    let v141_12: Space = unite(&(v141_7),&(v141_11));
    v140_12.join_into((v141_12).clone());
  }
  drop(v140_12_cursor);
  (v140_12).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v150_12 = Space::new();
  let mut v150_12_cursor = (*s0).read_zipper();
  for v150_12_byte in v150_12_cursor.child_mask().iter() {
    v150_12_cursor.descend_to_byte(v150_12_byte);
    let v150_12_tail = v150_12_cursor.make_map();
    v150_12_cursor.ascend(1);
    let v150_12_head = Path::from_slice(&[v150_12_byte]);
    let v151_2: Space = singleton(&(v150_12_head));
    let v151_3: Space = intersect(&(*CONSTANT_14),&(v151_2));
    let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
    drop(v151_3);
    let v151_5: Space = subtract(&(*CONSTANT_0),&(v151_4));
    drop(v151_4);
    let v151_8: Space = if (v151_5).is_empty() { Space::new() } else {
      let v152_6: Path = concat_path(&(*p0),&(v150_12_head));
      let mut v152_7 = Space::new();
      let mut v152_7_cursor = (v150_12_tail).read_zipper();
      for v152_7_byte in v152_7_cursor.child_mask().iter() {
        v152_7_cursor.descend_to_byte(v152_7_byte);
        let v152_7_tail = v152_7_cursor.make_map();
        v152_7_cursor.ascend(1);
        let v152_7_head = Path::from_slice(&[v152_7_byte]);
        let v153_2: Space = singleton(&(v152_7_head));
        let v153_3: Space = intersect(&(*CONSTANT_14),&(v153_2));
        let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
        drop(v153_3);
        let v153_5: Space = subtract(&(*CONSTANT_0),&(v153_4));
        drop(v153_4);
        let v153_8: Space = if (v153_5).is_empty() { Space::new() } else {
          let v154_6: Path = concat_path(&(v152_6),&(v152_7_head));
          let v154_7: Space = routine_41(c, &(v154_6), &(v152_7_tail), &(*s1));
          compose(&(v153_5),&(v154_7))
        };
        drop(v153_5);
        let v153_9: Space = intersect(&(*CONSTANT_14),&(v153_2));
        drop(v153_2);
        let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
        drop(v153_9);
        let v153_12: Space = if (v153_10).is_empty() { Space::new() } else {
          let v155_6: Path = concat_path(&(v152_6),&(v152_7_head));
          let v155_11: Space = routine_42(c, &(v155_6), &(v152_7_tail), &(*s1));
          drop(v155_6);
          compose(&(v153_10),&(v155_11))
        };
        drop(v153_10);
        let v153_13: Space = unite(&(v153_8),&(v153_12));
        v152_7.join_into((v153_13).clone());
      }
      drop(v152_7_cursor);
      compose(&(v151_5),&(v152_7))
    };
    drop(v151_5);
    let v151_9: Space = intersect(&(*CONSTANT_14),&(v151_2));
    drop(v151_2);
    let v151_10: Space = if has_head(&(v151_9)) { singleton(&[]) } else { Space::new() };
    drop(v151_9);
    let v151_12: Space = if (v151_10).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&(v150_12_head));
      let mut v156_11 = Space::new();
      let mut v156_11_cursor = (v150_12_tail).read_zipper();
      for v156_11_byte in v156_11_cursor.child_mask().iter() {
        v156_11_cursor.descend_to_byte(v156_11_byte);
        let v156_11_tail = v156_11_cursor.make_map();
        v156_11_cursor.ascend(1);
        let v156_11_head = Path::from_slice(&[v156_11_byte]);
        let v157_2: Space = singleton(&(v156_11_head));
        let v157_3: Space = intersect(&(*CONSTANT_14),&(v157_2));
        let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = subtract(&(*CONSTANT_0),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&(v156_11_head));
          let v158_7: Space = routine_41(c, &(v158_6), &(v156_11_tail), &(*s1));
          compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = intersect(&(*CONSTANT_14),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
          let v159_6: Path = concat_path(&(v156_6),&(v156_11_head));
          let v159_11: Space = routine_14(c, &(v159_6), &(v156_11_tail), &(*s1));
          drop(v159_6);
          compose(&(v157_10),&(v159_11))
        };
        drop(v157_10);
        let v157_13: Space = unite(&(v157_8),&(v157_12));
        v156_11.join_into((v157_13).clone());
      }
      drop(v156_11_cursor);
      drop(v156_6);
      compose(&(v151_10),&(v156_11))
    };
    drop(v151_10);
    let v151_13: Space = unite(&(v151_8),&(v151_12));
    v150_12.join_into((v151_13).clone());
  }
  drop(v150_12_cursor);
  (v150_12).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v160_12 = Space::new();
  let mut v160_12_cursor = (*s0).read_zipper();
  for v160_12_byte in v160_12_cursor.child_mask().iter() {
    v160_12_cursor.descend_to_byte(v160_12_byte);
    let v160_12_tail = v160_12_cursor.make_map();
    v160_12_cursor.ascend(1);
    let v160_12_head = Path::from_slice(&[v160_12_byte]);
    let v161_2: Space = singleton(&(v160_12_head));
    let v161_3: Space = intersect(&(*CONSTANT_14),&(v161_2));
    let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
    drop(v161_3);
    let v161_5: Space = subtract(&(*CONSTANT_0),&(v161_4));
    drop(v161_4);
    let v161_8: Space = if (v161_5).is_empty() { Space::new() } else {
      let v162_6: Path = concat_path(&(*p0),&(v160_12_head));
      let mut v162_7 = Space::new();
      let mut v162_7_cursor = (v160_12_tail).read_zipper();
      for v162_7_byte in v162_7_cursor.child_mask().iter() {
        v162_7_cursor.descend_to_byte(v162_7_byte);
        let v162_7_tail = v162_7_cursor.make_map();
        v162_7_cursor.ascend(1);
        let v162_7_head = Path::from_slice(&[v162_7_byte]);
        let v163_2: Space = singleton(&(v162_7_head));
        let v163_3: Space = intersect(&(*CONSTANT_14),&(v163_2));
        let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
        drop(v163_3);
        let v163_5: Space = subtract(&(*CONSTANT_0),&(v163_4));
        drop(v163_4);
        let v163_8: Space = if (v163_5).is_empty() { Space::new() } else {
          let v164_6: Path = concat_path(&(v162_6),&(v162_7_head));
          let v164_7: Space = routine_41(c, &(v164_6), &(v162_7_tail), &(*s1));
          compose(&(v163_5),&(v164_7))
        };
        drop(v163_5);
        let v163_9: Space = intersect(&(*CONSTANT_14),&(v163_2));
        drop(v163_2);
        let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
        drop(v163_9);
        let v163_12: Space = if (v163_10).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v162_6),&(v162_7_head));
          let v165_11: Space = routine_42(c, &(v165_6), &(v162_7_tail), &(*s1));
          drop(v165_6);
          compose(&(v163_10),&(v165_11))
        };
        drop(v163_10);
        let v163_13: Space = unite(&(v163_8),&(v163_12));
        v162_7.join_into((v163_13).clone());
      }
      drop(v162_7_cursor);
      compose(&(v161_5),&(v162_7))
    };
    drop(v161_5);
    let v161_9: Space = intersect(&(*CONSTANT_14),&(v161_2));
    drop(v161_2);
    let v161_10: Space = if has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
    drop(v161_9);
    let v161_12: Space = if (v161_10).is_empty() { Space::new() } else {
      let v166_6: Path = concat_path(&(*p0),&(v160_12_head));
      let mut v166_11 = Space::new();
      let mut v166_11_cursor = (v160_12_tail).read_zipper();
      for v166_11_byte in v166_11_cursor.child_mask().iter() {
        v166_11_cursor.descend_to_byte(v166_11_byte);
        let v166_11_tail = v166_11_cursor.make_map();
        v166_11_cursor.ascend(1);
        let v166_11_head = Path::from_slice(&[v166_11_byte]);
        let v167_2: Space = singleton(&(v166_11_head));
        let v167_3: Space = intersect(&(*CONSTANT_14),&(v167_2));
        let v167_4: Space = if has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
        drop(v167_3);
        let v167_5: Space = subtract(&(*CONSTANT_0),&(v167_4));
        drop(v167_4);
        let v167_7: Space = if (v167_5).is_empty() { Space::new() } else {
          let v168_6: Space = routine_43(c, &(v166_11_head), &(v166_6), &(v166_11_tail), &(*s1));
          compose(&(v167_5),&(v168_6))
        };
        drop(v167_5);
        let v167_8: Space = intersect(&(*CONSTANT_14),&(v167_2));
        drop(v167_2);
        let v167_9: Space = if has_head(&(v167_8)) { singleton(&[]) } else { Space::new() };
        drop(v167_8);
        let v167_11: Space = if (v167_9).is_empty() { Space::new() } else {
          let v169_10: Space = routine_44(c, &(v166_11_head), &(v166_6), &(v166_11_tail), &(*s1));
          compose(&(v167_9),&(v169_10))
        };
        drop(v167_9);
        let v167_12: Space = unite(&(v167_7),&(v167_11));
        v166_11.join_into((v167_12).clone());
      }
      drop(v166_11_cursor);
      drop(v166_6);
      compose(&(v161_10),&(v166_11))
    };
    drop(v161_10);
    let v161_13: Space = unite(&(v161_8),&(v161_12));
    v160_12.join_into((v161_13).clone());
  }
  drop(v160_12_cursor);
  (v160_12).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v170_12 = Space::new();
  let mut v170_12_cursor = (*s0).read_zipper();
  for v170_12_byte in v170_12_cursor.child_mask().iter() {
    v170_12_cursor.descend_to_byte(v170_12_byte);
    let v170_12_tail = v170_12_cursor.make_map();
    v170_12_cursor.ascend(1);
    let v170_12_head = Path::from_slice(&[v170_12_byte]);
    let v171_2: Space = singleton(&(v170_12_head));
    let v171_3: Space = intersect(&(*CONSTANT_14),&(v171_2));
    let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
    drop(v171_3);
    let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
    drop(v171_4);
    let v171_7: Space = if (v171_5).is_empty() { Space::new() } else {
      let mut v172_6 = Space::new();
      let mut v172_6_cursor = (v170_12_tail).read_zipper();
      for v172_6_byte in v172_6_cursor.child_mask().iter() {
        v172_6_cursor.descend_to_byte(v172_6_byte);
        let v172_6_tail = v172_6_cursor.make_map();
        v172_6_cursor.ascend(1);
        let v172_6_head = Path::from_slice(&[v172_6_byte]);
        let v173_2: Space = singleton(&(v172_6_head));
        let v173_3: Space = intersect(&(*CONSTANT_14),&(v173_2));
        let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
        drop(v173_3);
        let v173_5: Space = subtract(&(*CONSTANT_0),&(v173_4));
        drop(v173_4);
        let v173_8: Space = if (v173_5).is_empty() { Space::new() } else {
          let v174_6: Path = concat_path(&(v170_12_head),&(v172_6_head));
          let v174_7: Space = routine_45(c, &(v174_6), &(*p0), &(v172_6_tail), &(*s1));
          compose(&(v173_5),&(v174_7))
        };
        drop(v173_5);
        let v173_9: Space = intersect(&(*CONSTANT_14),&(v173_2));
        drop(v173_2);
        let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
        drop(v173_9);
        let v173_12: Space = if (v173_10).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v170_12_head),&(v172_6_head));
          let v175_11: Space = routine_46(c, &(v175_6), &(*p0), &(v172_6_tail), &(*s1));
          drop(v175_6);
          compose(&(v173_10),&(v175_11))
        };
        drop(v173_10);
        let v173_13: Space = unite(&(v173_8),&(v173_12));
        v172_6.join_into((v173_13).clone());
      }
      drop(v172_6_cursor);
      compose(&(v171_5),&(v172_6))
    };
    drop(v171_5);
    let v171_8: Space = intersect(&(*CONSTANT_14),&(v171_2));
    drop(v171_2);
    let v171_9: Space = if has_head(&(v171_8)) { singleton(&[]) } else { Space::new() };
    drop(v171_8);
    let v171_11: Space = if (v171_9).is_empty() { Space::new() } else {
      let mut v176_10 = Space::new();
      let mut v176_10_cursor = (v170_12_tail).read_zipper();
      for v176_10_byte in v176_10_cursor.child_mask().iter() {
        v176_10_cursor.descend_to_byte(v176_10_byte);
        let v176_10_tail = v176_10_cursor.make_map();
        v176_10_cursor.ascend(1);
        let v176_10_head = Path::from_slice(&[v176_10_byte]);
        let v177_2: Space = singleton(&(v176_10_head));
        let v177_3: Space = intersect(&(*CONSTANT_14),&(v177_2));
        let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
        drop(v177_3);
        let v177_5: Space = subtract(&(*CONSTANT_0),&(v177_4));
        drop(v177_4);
        let v177_8: Space = if (v177_5).is_empty() { Space::new() } else {
          let v178_6: Path = concat_path(&(v170_12_head),&(v176_10_head));
          let v178_7: Space = routine_45(c, &(v178_6), &(*p0), &(v176_10_tail), &(*s1));
          compose(&(v177_5),&(v178_7))
        };
        drop(v177_5);
        let v177_9: Space = intersect(&(*CONSTANT_14),&(v177_2));
        drop(v177_2);
        let v177_10: Space = if has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
        drop(v177_9);
        let v177_12: Space = if (v177_10).is_empty() { Space::new() } else {
          let v179_6: Path = concat_path(&(v170_12_head),&(v176_10_head));
          let v179_11: Space = routine_47(c, &(v179_6), &(*p0), &(v176_10_tail), &(*s1));
          drop(v179_6);
          compose(&(v177_10),&(v179_11))
        };
        drop(v177_10);
        let v177_13: Space = unite(&(v177_8),&(v177_12));
        v176_10.join_into((v177_13).clone());
      }
      drop(v176_10_cursor);
      compose(&(v171_9),&(v176_10))
    };
    drop(v171_9);
    let v171_12: Space = unite(&(v171_7),&(v171_11));
    v170_12.join_into((v171_12).clone());
  }
  drop(v170_12_cursor);
  (v170_12).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v180_11 = Space::new();
  let mut v180_11_cursor = (*s0).read_zipper();
  for v180_11_byte in v180_11_cursor.child_mask().iter() {
    v180_11_cursor.descend_to_byte(v180_11_byte);
    let v180_11_tail = v180_11_cursor.make_map();
    v180_11_cursor.ascend(1);
    let v180_11_head = Path::from_slice(&[v180_11_byte]);
    let v181_2: Space = singleton(&(v180_11_head));
    let v181_3: Space = intersect(&(*CONSTANT_14),&(v181_2));
    let v181_4: Space = if has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
    drop(v181_3);
    let v181_5: Space = subtract(&(*CONSTANT_0),&(v181_4));
    drop(v181_4);
    let v181_8: Space = if (v181_5).is_empty() { Space::new() } else {
      let v182_6: Path = concat_path(&(*p0),&(v180_11_head));
      let mut v182_7 = Space::new();
      let mut v182_7_cursor = (v180_11_tail).read_zipper();
      for v182_7_byte in v182_7_cursor.child_mask().iter() {
        v182_7_cursor.descend_to_byte(v182_7_byte);
        let v182_7_tail = v182_7_cursor.make_map();
        v182_7_cursor.ascend(1);
        let v182_7_head = Path::from_slice(&[v182_7_byte]);
        let v183_2: Space = singleton(&(v182_7_head));
        let v183_3: Space = intersect(&(*CONSTANT_14),&(v183_2));
        let v183_4: Space = if has_head(&(v183_3)) { singleton(&[]) } else { Space::new() };
        drop(v183_3);
        let v183_5: Space = subtract(&(*CONSTANT_0),&(v183_4));
        drop(v183_4);
        let v183_8: Space = if (v183_5).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v182_6),&(v182_7_head));
          let v184_7: Space = routine_48(c, &(v184_6), &(v182_7_tail));
          compose(&(v183_5),&(v184_7))
        };
        drop(v183_5);
        let v183_9: Space = intersect(&(*CONSTANT_14),&(v183_2));
        drop(v183_2);
        let v183_10: Space = if has_head(&(v183_9)) { singleton(&[]) } else { Space::new() };
        drop(v183_9);
        let v183_12: Space = if (v183_10).is_empty() { Space::new() } else {
          let v185_6: Path = concat_path(&(v182_6),&(v182_7_head));
          let v185_11: Space = routine_49(c, &(v185_6), &(v182_7_tail));
          drop(v185_6);
          compose(&(v183_10),&(v185_11))
        };
        drop(v183_10);
        let v183_13: Space = unite(&(v183_8),&(v183_12));
        v182_7.join_into((v183_13).clone());
      }
      drop(v182_7_cursor);
      compose(&(v181_5),&(v182_7))
    };
    drop(v181_5);
    let v181_9: Space = intersect(&(*CONSTANT_14),&(v181_2));
    drop(v181_2);
    let v181_10: Space = if has_head(&(v181_9)) { singleton(&[]) } else { Space::new() };
    drop(v181_9);
    let v181_12: Space = if (v181_10).is_empty() { Space::new() } else {
      let v186_6: Path = concat_path(&(*p0),&(v180_11_head));
      let mut v186_11 = Space::new();
      let mut v186_11_cursor = (v180_11_tail).read_zipper();
      for v186_11_byte in v186_11_cursor.child_mask().iter() {
        v186_11_cursor.descend_to_byte(v186_11_byte);
        let v186_11_tail = v186_11_cursor.make_map();
        v186_11_cursor.ascend(1);
        let v186_11_head = Path::from_slice(&[v186_11_byte]);
        let v187_2: Space = singleton(&(v186_11_head));
        let v187_3: Space = intersect(&(*CONSTANT_14),&(v187_2));
        let v187_4: Space = if has_head(&(v187_3)) { singleton(&[]) } else { Space::new() };
        drop(v187_3);
        let v187_5: Space = subtract(&(*CONSTANT_0),&(v187_4));
        drop(v187_4);
        let v187_8: Space = if (v187_5).is_empty() { Space::new() } else {
          let v188_6: Path = concat_path(&(v186_6),&(v186_11_head));
          let v188_7: Space = routine_48(c, &(v188_6), &(v186_11_tail));
          compose(&(v187_5),&(v188_7))
        };
        drop(v187_5);
        let v187_9: Space = intersect(&(*CONSTANT_14),&(v187_2));
        drop(v187_2);
        let v187_10: Space = if has_head(&(v187_9)) { singleton(&[]) } else { Space::new() };
        drop(v187_9);
        let v187_12: Space = if (v187_10).is_empty() { Space::new() } else {
          let v189_6: Path = concat_path(&(v186_6),&(v186_11_head));
          let v189_11: Space = routine_17(c, &(v189_6), &(v186_11_tail));
          drop(v189_6);
          compose(&(v187_10),&(v189_11))
        };
        drop(v187_10);
        let v187_13: Space = unite(&(v187_8),&(v187_12));
        v186_11.join_into((v187_13).clone());
      }
      drop(v186_11_cursor);
      drop(v186_6);
      compose(&(v181_10),&(v186_11))
    };
    drop(v181_10);
    let v181_13: Space = unite(&(v181_8),&(v181_12));
    v180_11.join_into((v181_13).clone());
  }
  drop(v180_11_cursor);
  (v180_11).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v190_11 = Space::new();
  let mut v190_11_cursor = (*s0).read_zipper();
  for v190_11_byte in v190_11_cursor.child_mask().iter() {
    v190_11_cursor.descend_to_byte(v190_11_byte);
    let v190_11_tail = v190_11_cursor.make_map();
    v190_11_cursor.ascend(1);
    let v190_11_head = Path::from_slice(&[v190_11_byte]);
    let v191_2: Space = singleton(&(v190_11_head));
    let v191_3: Space = intersect(&(*CONSTANT_14),&(v191_2));
    let v191_4: Space = if has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
    drop(v191_3);
    let v191_5: Space = subtract(&(*CONSTANT_0),&(v191_4));
    drop(v191_4);
    let v191_8: Space = if (v191_5).is_empty() { Space::new() } else {
      let v192_6: Path = concat_path(&(*p0),&(v190_11_head));
      let mut v192_7 = Space::new();
      let mut v192_7_cursor = (v190_11_tail).read_zipper();
      for v192_7_byte in v192_7_cursor.child_mask().iter() {
        v192_7_cursor.descend_to_byte(v192_7_byte);
        let v192_7_tail = v192_7_cursor.make_map();
        v192_7_cursor.ascend(1);
        let v192_7_head = Path::from_slice(&[v192_7_byte]);
        let v193_2: Space = singleton(&(v192_7_head));
        let v193_3: Space = intersect(&(*CONSTANT_14),&(v193_2));
        let v193_4: Space = if has_head(&(v193_3)) { singleton(&[]) } else { Space::new() };
        drop(v193_3);
        let v193_5: Space = subtract(&(*CONSTANT_0),&(v193_4));
        drop(v193_4);
        let v193_8: Space = if (v193_5).is_empty() { Space::new() } else {
          let v194_6: Path = concat_path(&(v192_6),&(v192_7_head));
          let v194_7: Space = routine_48(c, &(v194_6), &(v192_7_tail));
          compose(&(v193_5),&(v194_7))
        };
        drop(v193_5);
        let v193_9: Space = intersect(&(*CONSTANT_14),&(v193_2));
        drop(v193_2);
        let v193_10: Space = if has_head(&(v193_9)) { singleton(&[]) } else { Space::new() };
        drop(v193_9);
        let v193_12: Space = if (v193_10).is_empty() { Space::new() } else {
          let v195_6: Path = concat_path(&(v192_6),&(v192_7_head));
          let v195_11: Space = routine_49(c, &(v195_6), &(v192_7_tail));
          drop(v195_6);
          compose(&(v193_10),&(v195_11))
        };
        drop(v193_10);
        let v193_13: Space = unite(&(v193_8),&(v193_12));
        v192_7.join_into((v193_13).clone());
      }
      drop(v192_7_cursor);
      compose(&(v191_5),&(v192_7))
    };
    drop(v191_5);
    let v191_9: Space = intersect(&(*CONSTANT_14),&(v191_2));
    drop(v191_2);
    let v191_10: Space = if has_head(&(v191_9)) { singleton(&[]) } else { Space::new() };
    drop(v191_9);
    let v191_12: Space = if (v191_10).is_empty() { Space::new() } else {
      let v196_6: Path = concat_path(&(*p0),&(v190_11_head));
      let mut v196_11 = Space::new();
      let mut v196_11_cursor = (v190_11_tail).read_zipper();
      for v196_11_byte in v196_11_cursor.child_mask().iter() {
        v196_11_cursor.descend_to_byte(v196_11_byte);
        let v196_11_tail = v196_11_cursor.make_map();
        v196_11_cursor.ascend(1);
        let v196_11_head = Path::from_slice(&[v196_11_byte]);
        let v197_2: Space = singleton(&(v196_11_head));
        let v197_3: Space = intersect(&(*CONSTANT_14),&(v197_2));
        let v197_4: Space = if has_head(&(v197_3)) { singleton(&[]) } else { Space::new() };
        drop(v197_3);
        let v197_5: Space = subtract(&(*CONSTANT_0),&(v197_4));
        drop(v197_4);
        let v197_7: Space = if (v197_5).is_empty() { Space::new() } else {
          let v198_6: Space = routine_18(c, &(v196_11_head), &(v196_6), &(v196_11_tail));
          compose(&(v197_5),&(v198_6))
        };
        drop(v197_5);
        let v197_8: Space = intersect(&(*CONSTANT_14),&(v197_2));
        drop(v197_2);
        let v197_9: Space = if has_head(&(v197_8)) { singleton(&[]) } else { Space::new() };
        drop(v197_8);
        let v197_11: Space = if (v197_9).is_empty() { Space::new() } else {
          let v199_10: Space = routine_19(c, &(v196_11_head), &(v196_6), &(v196_11_tail));
          compose(&(v197_9),&(v199_10))
        };
        drop(v197_9);
        let v197_12: Space = unite(&(v197_7),&(v197_11));
        v196_11.join_into((v197_12).clone());
      }
      drop(v196_11_cursor);
      drop(v196_6);
      compose(&(v191_10),&(v196_11))
    };
    drop(v191_10);
    let v191_13: Space = unite(&(v191_8),&(v191_12));
    v190_11.join_into((v191_13).clone());
  }
  drop(v190_11_cursor);
  (v190_11).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v200_11 = Space::new();
  let mut v200_11_cursor = (*s0).read_zipper();
  for v200_11_byte in v200_11_cursor.child_mask().iter() {
    v200_11_cursor.descend_to_byte(v200_11_byte);
    let v200_11_tail = v200_11_cursor.make_map();
    v200_11_cursor.ascend(1);
    let v200_11_head = Path::from_slice(&[v200_11_byte]);
    let v201_2: Space = singleton(&(v200_11_head));
    let v201_3: Space = intersect(&(*CONSTANT_14),&(v201_2));
    let v201_4: Space = if has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
    drop(v201_3);
    let v201_5: Space = subtract(&(*CONSTANT_0),&(v201_4));
    drop(v201_4);
    let v201_7: Space = if (v201_5).is_empty() { Space::new() } else {
      let mut v202_6 = Space::new();
      let mut v202_6_cursor = (v200_11_tail).read_zipper();
      for v202_6_byte in v202_6_cursor.child_mask().iter() {
        v202_6_cursor.descend_to_byte(v202_6_byte);
        let v202_6_tail = v202_6_cursor.make_map();
        v202_6_cursor.ascend(1);
        let v202_6_head = Path::from_slice(&[v202_6_byte]);
        let v203_2: Space = singleton(&(v202_6_head));
        let v203_3: Space = intersect(&(*CONSTANT_14),&(v203_2));
        let v203_4: Space = if has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
        drop(v203_3);
        let v203_5: Space = subtract(&(*CONSTANT_0),&(v203_4));
        drop(v203_4);
        let v203_8: Space = if (v203_5).is_empty() { Space::new() } else {
          let v204_6: Path = concat_path(&(v200_11_head),&(v202_6_head));
          let v204_7: Space = routine_50(c, &(v204_6), &(*p0), &(v202_6_tail));
          compose(&(v203_5),&(v204_7))
        };
        drop(v203_5);
        let v203_9: Space = intersect(&(*CONSTANT_14),&(v203_2));
        drop(v203_2);
        let v203_10: Space = if has_head(&(v203_9)) { singleton(&[]) } else { Space::new() };
        drop(v203_9);
        let v203_12: Space = if (v203_10).is_empty() { Space::new() } else {
          let v205_6: Path = concat_path(&(v200_11_head),&(v202_6_head));
          let v205_11: Space = routine_51(c, &(v205_6), &(*p0), &(v202_6_tail));
          drop(v205_6);
          compose(&(v203_10),&(v205_11))
        };
        drop(v203_10);
        let v203_13: Space = unite(&(v203_8),&(v203_12));
        v202_6.join_into((v203_13).clone());
      }
      drop(v202_6_cursor);
      compose(&(v201_5),&(v202_6))
    };
    drop(v201_5);
    let v201_8: Space = intersect(&(*CONSTANT_14),&(v201_2));
    drop(v201_2);
    let v201_9: Space = if has_head(&(v201_8)) { singleton(&[]) } else { Space::new() };
    drop(v201_8);
    let v201_11: Space = if (v201_9).is_empty() { Space::new() } else {
      let mut v206_10 = Space::new();
      let mut v206_10_cursor = (v200_11_tail).read_zipper();
      for v206_10_byte in v206_10_cursor.child_mask().iter() {
        v206_10_cursor.descend_to_byte(v206_10_byte);
        let v206_10_tail = v206_10_cursor.make_map();
        v206_10_cursor.ascend(1);
        let v206_10_head = Path::from_slice(&[v206_10_byte]);
        let v207_2: Space = singleton(&(v206_10_head));
        let v207_3: Space = intersect(&(*CONSTANT_14),&(v207_2));
        let v207_4: Space = if has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
        drop(v207_3);
        let v207_5: Space = subtract(&(*CONSTANT_0),&(v207_4));
        drop(v207_4);
        let v207_8: Space = if (v207_5).is_empty() { Space::new() } else {
          let v208_6: Path = concat_path(&(v200_11_head),&(v206_10_head));
          let v208_7: Space = routine_50(c, &(v208_6), &(*p0), &(v206_10_tail));
          compose(&(v207_5),&(v208_7))
        };
        drop(v207_5);
        let v207_9: Space = intersect(&(*CONSTANT_14),&(v207_2));
        drop(v207_2);
        let v207_10: Space = if has_head(&(v207_9)) { singleton(&[]) } else { Space::new() };
        drop(v207_9);
        let v207_12: Space = if (v207_10).is_empty() { Space::new() } else {
          let v209_6: Path = concat_path(&(v200_11_head),&(v206_10_head));
          let v209_11: Space = routine_52(c, &(v209_6), &(*p0), &(v206_10_tail));
          drop(v209_6);
          compose(&(v207_10),&(v209_11))
        };
        drop(v207_10);
        let v207_13: Space = unite(&(v207_8),&(v207_12));
        v206_10.join_into((v207_13).clone());
      }
      drop(v206_10_cursor);
      compose(&(v201_9),&(v206_10))
    };
    drop(v201_9);
    let v201_12: Space = unite(&(v201_7),&(v201_11));
    v200_11.join_into((v201_12).clone());
  }
  drop(v200_11_cursor);
  (v200_11).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v210_12 = Space::new();
  let mut v210_12_cursor = (*s0).read_zipper();
  for v210_12_byte in v210_12_cursor.child_mask().iter() {
    v210_12_cursor.descend_to_byte(v210_12_byte);
    let v210_12_tail = v210_12_cursor.make_map();
    v210_12_cursor.ascend(1);
    let v210_12_head = Path::from_slice(&[v210_12_byte]);
    let v211_2: Space = singleton(&(v210_12_head));
    let v211_3: Space = intersect(&(*CONSTANT_14),&(v211_2));
    let v211_4: Space = if has_head(&(v211_3)) { singleton(&[]) } else { Space::new() };
    drop(v211_3);
    let v211_5: Space = subtract(&(*CONSTANT_0),&(v211_4));
    drop(v211_4);
    let v211_8: Space = if (v211_5).is_empty() { Space::new() } else {
      let v212_6: Path = concat_path(&(*p0),&(v210_12_head));
      let mut v212_7 = Space::new();
      let mut v212_7_cursor = (v210_12_tail).read_zipper();
      for v212_7_byte in v212_7_cursor.child_mask().iter() {
        v212_7_cursor.descend_to_byte(v212_7_byte);
        let v212_7_tail = v212_7_cursor.make_map();
        v212_7_cursor.ascend(1);
        let v212_7_head = Path::from_slice(&[v212_7_byte]);
        let v213_2: Space = singleton(&(v212_7_head));
        let v213_3: Space = intersect(&(*CONSTANT_14),&(v213_2));
        let v213_4: Space = if has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
        drop(v213_3);
        let v213_5: Space = subtract(&(*CONSTANT_0),&(v213_4));
        drop(v213_4);
        let v213_8: Space = if (v213_5).is_empty() { Space::new() } else {
          let v214_6: Path = concat_path(&(v212_6),&(v212_7_head));
          let v214_7: Space = routine_53(c, &(v214_6), &(*p1), &(v212_7_tail));
          compose(&(v213_5),&(v214_7))
        };
        drop(v213_5);
        let v213_9: Space = intersect(&(*CONSTANT_14),&(v213_2));
        drop(v213_2);
        let v213_10: Space = if has_head(&(v213_9)) { singleton(&[]) } else { Space::new() };
        drop(v213_9);
        let v213_12: Space = if (v213_10).is_empty() { Space::new() } else {
          let v215_6: Path = concat_path(&(v212_6),&(v212_7_head));
          let v215_11: Space = routine_54(c, &(v215_6), &(*p1), &(v212_7_tail));
          drop(v215_6);
          compose(&(v213_10),&(v215_11))
        };
        drop(v213_10);
        let v213_13: Space = unite(&(v213_8),&(v213_12));
        v212_7.join_into((v213_13).clone());
      }
      drop(v212_7_cursor);
      compose(&(v211_5),&(v212_7))
    };
    drop(v211_5);
    let v211_9: Space = intersect(&(*CONSTANT_14),&(v211_2));
    drop(v211_2);
    let v211_10: Space = if has_head(&(v211_9)) { singleton(&[]) } else { Space::new() };
    drop(v211_9);
    let v211_12: Space = if (v211_10).is_empty() { Space::new() } else {
      let v216_6: Path = concat_path(&(*p0),&(v210_12_head));
      let mut v216_11 = Space::new();
      let mut v216_11_cursor = (v210_12_tail).read_zipper();
      for v216_11_byte in v216_11_cursor.child_mask().iter() {
        v216_11_cursor.descend_to_byte(v216_11_byte);
        let v216_11_tail = v216_11_cursor.make_map();
        v216_11_cursor.ascend(1);
        let v216_11_head = Path::from_slice(&[v216_11_byte]);
        let v217_2: Space = singleton(&(v216_11_head));
        let v217_3: Space = intersect(&(*CONSTANT_14),&(v217_2));
        let v217_4: Space = if has_head(&(v217_3)) { singleton(&[]) } else { Space::new() };
        drop(v217_3);
        let v217_5: Space = subtract(&(*CONSTANT_0),&(v217_4));
        drop(v217_4);
        let v217_8: Space = if (v217_5).is_empty() { Space::new() } else {
          let v218_6: Path = concat_path(&(v216_6),&(v216_11_head));
          let v218_7: Space = routine_53(c, &(v218_6), &(*p1), &(v216_11_tail));
          compose(&(v217_5),&(v218_7))
        };
        drop(v217_5);
        let v217_9: Space = intersect(&(*CONSTANT_14),&(v217_2));
        drop(v217_2);
        let v217_10: Space = if has_head(&(v217_9)) { singleton(&[]) } else { Space::new() };
        drop(v217_9);
        let v217_12: Space = if (v217_10).is_empty() { Space::new() } else {
          let v219_6: Path = concat_path(&(v216_6),&(v216_11_head));
          let v219_11: Space = routine_52(c, &(v219_6), &(*p1), &(v216_11_tail));
          drop(v219_6);
          compose(&(v217_10),&(v219_11))
        };
        drop(v217_10);
        let v217_13: Space = unite(&(v217_8),&(v217_12));
        v216_11.join_into((v217_13).clone());
      }
      drop(v216_11_cursor);
      drop(v216_6);
      compose(&(v211_10),&(v216_11))
    };
    drop(v211_10);
    let v211_13: Space = unite(&(v211_8),&(v211_12));
    v210_12.join_into((v211_13).clone());
  }
  drop(v210_12_cursor);
  (v210_12).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v220_10 = Space::new();
  let mut v220_10_cursor = (*s0).read_zipper();
  for v220_10_byte in v220_10_cursor.child_mask().iter() {
    v220_10_cursor.descend_to_byte(v220_10_byte);
    let v220_10_tail = v220_10_cursor.make_map();
    v220_10_cursor.ascend(1);
    let v220_10_head = Path::from_slice(&[v220_10_byte]);
    let v221_2: Space = singleton(&(v220_10_head));
    let v221_3: Space = intersect(&(*CONSTANT_14),&(v221_2));
    let v221_4: Space = if has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
    drop(v221_3);
    let v221_5: Space = compose(&(v221_4),&(v220_10_tail));
    drop(v221_4);
    let v222_6: Path = concat_path(&(*p0),&(v220_10_head));
    let v221_7: Space = wrap(&(v221_5),&(v222_6));
    drop(v221_5);
    let v221_8: Space = wrap(&(v221_7),&(*p1));
    drop(v221_7);
    let v221_9: Space = wrap(&(v221_8),&(*CONSTANT_10));
    drop(v221_8);
    let v221_10: Space = intersect(&(*CONSTANT_14),&(v221_2));
    drop(v221_2);
    let v221_11: Space = if has_head(&(v221_10)) { singleton(&[]) } else { Space::new() };
    drop(v221_10);
    let v221_12: Space = subtract(&(*CONSTANT_0),&(v221_11));
    drop(v221_11);
    let v221_14: Space = if (v221_12).is_empty() { Space::new() } else {
      let mut v223_13 = Space::new();
      let mut v223_13_cursor = (v220_10_tail).read_zipper();
      for v223_13_byte in v223_13_cursor.child_mask().iter() {
        v223_13_cursor.descend_to_byte(v223_13_byte);
        let v223_13_tail = v223_13_cursor.make_map();
        v223_13_cursor.ascend(1);
        let v223_13_head = Path::from_slice(&[v223_13_byte]);
        let v224_2: Space = singleton(&(v223_13_head));
        let v224_3: Space = intersect(&(*CONSTANT_14),&(v224_2));
        let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
        drop(v224_3);
        let v224_5: Space = subtract(&(*CONSTANT_0),&(v224_4));
        drop(v224_4);
        let v224_8: Space = if (v224_5).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v222_6),&(v223_13_head));
          let v225_7: Space = routine_53(c, &(v225_6), &(*p1), &(v223_13_tail));
          compose(&(v224_5),&(v225_7))
        };
        drop(v224_5);
        let v224_9: Space = intersect(&(*CONSTANT_14),&(v224_2));
        drop(v224_2);
        let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
        drop(v224_9);
        let v224_12: Space = if (v224_10).is_empty() { Space::new() } else {
          let v226_6: Path = concat_path(&(v222_6),&(v223_13_head));
          let v226_11: Space = routine_54(c, &(v226_6), &(*p1), &(v223_13_tail));
          drop(v226_6);
          compose(&(v224_10),&(v226_11))
        };
        drop(v224_10);
        let v224_13: Space = unite(&(v224_8),&(v224_12));
        v223_13.join_into((v224_13).clone());
      }
      drop(v223_13_cursor);
      compose(&(v221_12),&(v223_13))
    };
    drop(v221_12);
    let v221_15: Space = unite(&(v221_9),&(v221_14));
    drop(v221_9);
    v220_10.join_into((v221_15).clone());
  }
  drop(v220_10_cursor);
  (v220_10).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v227_12 = Space::new();
  let mut v227_12_cursor = (*s0).read_zipper();
  for v227_12_byte in v227_12_cursor.child_mask().iter() {
    v227_12_cursor.descend_to_byte(v227_12_byte);
    let v227_12_tail = v227_12_cursor.make_map();
    v227_12_cursor.ascend(1);
    let v227_12_head = Path::from_slice(&[v227_12_byte]);
    let v228_2: Space = singleton(&(v227_12_head));
    let v228_3: Space = intersect(&(*CONSTANT_14),&(v228_2));
    let v228_4: Space = if has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
    drop(v228_3);
    let v228_5: Space = subtract(&(*CONSTANT_0),&(v228_4));
    drop(v228_4);
    let v228_8: Space = if (v228_5).is_empty() { Space::new() } else {
      let v229_6: Path = concat_path(&(*p0),&(v227_12_head));
      let mut v229_7 = Space::new();
      let mut v229_7_cursor = (v227_12_tail).read_zipper();
      for v229_7_byte in v229_7_cursor.child_mask().iter() {
        v229_7_cursor.descend_to_byte(v229_7_byte);
        let v229_7_tail = v229_7_cursor.make_map();
        v229_7_cursor.ascend(1);
        let v229_7_head = Path::from_slice(&[v229_7_byte]);
        let v230_2: Space = singleton(&(v229_7_head));
        let v230_3: Space = intersect(&(*CONSTANT_14),&(v230_2));
        let v230_4: Space = if has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
        drop(v230_3);
        let v230_5: Space = subtract(&(*CONSTANT_0),&(v230_4));
        drop(v230_4);
        let v230_8: Space = if (v230_5).is_empty() { Space::new() } else {
          let v231_6: Path = concat_path(&(v229_6),&(v229_7_head));
          let v231_7: Space = routine_55(c, &(v231_6), &(v229_7_tail), &(*s1));
          compose(&(v230_5),&(v231_7))
        };
        drop(v230_5);
        let v230_9: Space = intersect(&(*CONSTANT_14),&(v230_2));
        drop(v230_2);
        let v230_10: Space = if has_head(&(v230_9)) { singleton(&[]) } else { Space::new() };
        drop(v230_9);
        let v230_12: Space = if (v230_10).is_empty() { Space::new() } else {
          let v232_6: Path = concat_path(&(v229_6),&(v229_7_head));
          let v232_11: Space = routine_56(c, &(v232_6), &(v229_7_tail), &(*s1));
          drop(v232_6);
          compose(&(v230_10),&(v232_11))
        };
        drop(v230_10);
        let v230_13: Space = unite(&(v230_8),&(v230_12));
        v229_7.join_into((v230_13).clone());
      }
      drop(v229_7_cursor);
      compose(&(v228_5),&(v229_7))
    };
    drop(v228_5);
    let v228_9: Space = intersect(&(*CONSTANT_14),&(v228_2));
    drop(v228_2);
    let v228_10: Space = if has_head(&(v228_9)) { singleton(&[]) } else { Space::new() };
    drop(v228_9);
    let v228_12: Space = if (v228_10).is_empty() { Space::new() } else {
      let v233_6: Path = concat_path(&(*p0),&(v227_12_head));
      let mut v233_11 = Space::new();
      let mut v233_11_cursor = (v227_12_tail).read_zipper();
      for v233_11_byte in v233_11_cursor.child_mask().iter() {
        v233_11_cursor.descend_to_byte(v233_11_byte);
        let v233_11_tail = v233_11_cursor.make_map();
        v233_11_cursor.ascend(1);
        let v233_11_head = Path::from_slice(&[v233_11_byte]);
        let v234_2: Space = singleton(&(v233_11_head));
        let v234_3: Space = intersect(&(*CONSTANT_14),&(v234_2));
        let v234_4: Space = if has_head(&(v234_3)) { singleton(&[]) } else { Space::new() };
        drop(v234_3);
        let v234_5: Space = subtract(&(*CONSTANT_0),&(v234_4));
        drop(v234_4);
        let v234_8: Space = if (v234_5).is_empty() { Space::new() } else {
          let v235_6: Path = concat_path(&(v233_6),&(v233_11_head));
          let v235_7: Space = routine_55(c, &(v235_6), &(v233_11_tail), &(*s1));
          compose(&(v234_5),&(v235_7))
        };
        drop(v234_5);
        let v234_9: Space = intersect(&(*CONSTANT_14),&(v234_2));
        drop(v234_2);
        let v234_10: Space = if has_head(&(v234_9)) { singleton(&[]) } else { Space::new() };
        drop(v234_9);
        let v234_12: Space = if (v234_10).is_empty() { Space::new() } else {
          let v236_6: Path = concat_path(&(v233_6),&(v233_11_head));
          let v236_11: Space = routine_5(c, &(v236_6), &(v233_11_tail), &(*s1));
          drop(v236_6);
          compose(&(v234_10),&(v236_11))
        };
        drop(v234_10);
        let v234_13: Space = unite(&(v234_8),&(v234_12));
        v233_11.join_into((v234_13).clone());
      }
      drop(v233_11_cursor);
      drop(v233_6);
      compose(&(v228_10),&(v233_11))
    };
    drop(v228_10);
    let v228_13: Space = unite(&(v228_8),&(v228_12));
    v227_12.join_into((v228_13).clone());
  }
  drop(v227_12_cursor);
  (v227_12).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v237_12 = Space::new();
  let mut v237_12_cursor = (*s0).read_zipper();
  for v237_12_byte in v237_12_cursor.child_mask().iter() {
    v237_12_cursor.descend_to_byte(v237_12_byte);
    let v237_12_tail = v237_12_cursor.make_map();
    v237_12_cursor.ascend(1);
    let v237_12_head = Path::from_slice(&[v237_12_byte]);
    let v238_2: Space = singleton(&(v237_12_head));
    let v238_3: Space = intersect(&(*CONSTANT_14),&(v238_2));
    let v238_4: Space = if has_head(&(v238_3)) { singleton(&[]) } else { Space::new() };
    drop(v238_3);
    let v238_5: Space = subtract(&(*CONSTANT_0),&(v238_4));
    drop(v238_4);
    let v238_8: Space = if (v238_5).is_empty() { Space::new() } else {
      let v239_6: Path = concat_path(&(*p0),&(v237_12_head));
      let mut v239_7 = Space::new();
      let mut v239_7_cursor = (v237_12_tail).read_zipper();
      for v239_7_byte in v239_7_cursor.child_mask().iter() {
        v239_7_cursor.descend_to_byte(v239_7_byte);
        let v239_7_tail = v239_7_cursor.make_map();
        v239_7_cursor.ascend(1);
        let v239_7_head = Path::from_slice(&[v239_7_byte]);
        let v240_2: Space = singleton(&(v239_7_head));
        let v240_3: Space = intersect(&(*CONSTANT_14),&(v240_2));
        let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
        drop(v240_3);
        let v240_5: Space = subtract(&(*CONSTANT_0),&(v240_4));
        drop(v240_4);
        let v240_8: Space = if (v240_5).is_empty() { Space::new() } else {
          let v241_6: Path = concat_path(&(v239_6),&(v239_7_head));
          let v241_7: Space = routine_55(c, &(v241_6), &(v239_7_tail), &(*s1));
          compose(&(v240_5),&(v241_7))
        };
        drop(v240_5);
        let v240_9: Space = intersect(&(*CONSTANT_14),&(v240_2));
        drop(v240_2);
        let v240_10: Space = if has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
        drop(v240_9);
        let v240_12: Space = if (v240_10).is_empty() { Space::new() } else {
          let v242_6: Path = concat_path(&(v239_6),&(v239_7_head));
          let v242_11: Space = routine_56(c, &(v242_6), &(v239_7_tail), &(*s1));
          drop(v242_6);
          compose(&(v240_10),&(v242_11))
        };
        drop(v240_10);
        let v240_13: Space = unite(&(v240_8),&(v240_12));
        v239_7.join_into((v240_13).clone());
      }
      drop(v239_7_cursor);
      compose(&(v238_5),&(v239_7))
    };
    drop(v238_5);
    let v238_9: Space = intersect(&(*CONSTANT_14),&(v238_2));
    drop(v238_2);
    let v238_10: Space = if has_head(&(v238_9)) { singleton(&[]) } else { Space::new() };
    drop(v238_9);
    let v238_12: Space = if (v238_10).is_empty() { Space::new() } else {
      let v243_6: Path = concat_path(&(*p0),&(v237_12_head));
      let mut v243_11 = Space::new();
      let mut v243_11_cursor = (v237_12_tail).read_zipper();
      for v243_11_byte in v243_11_cursor.child_mask().iter() {
        v243_11_cursor.descend_to_byte(v243_11_byte);
        let v243_11_tail = v243_11_cursor.make_map();
        v243_11_cursor.ascend(1);
        let v243_11_head = Path::from_slice(&[v243_11_byte]);
        let v244_2: Space = singleton(&(v243_11_head));
        let v244_3: Space = intersect(&(*CONSTANT_14),&(v244_2));
        let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
        drop(v244_3);
        let v244_5: Space = subtract(&(*CONSTANT_0),&(v244_4));
        drop(v244_4);
        let v244_7: Space = if (v244_5).is_empty() { Space::new() } else {
          let v245_6: Space = routine_22(c, &(v243_11_head), &(v243_6), &(v243_11_tail), &(*s1));
          compose(&(v244_5),&(v245_6))
        };
        drop(v244_5);
        let v244_8: Space = intersect(&(*CONSTANT_14),&(v244_2));
        drop(v244_2);
        let v244_9: Space = if has_head(&(v244_8)) { singleton(&[]) } else { Space::new() };
        drop(v244_8);
        let v244_11: Space = if (v244_9).is_empty() { Space::new() } else {
          let v246_10: Space = routine_23(c, &(v243_11_head), &(v243_6), &(v243_11_tail), &(*s1));
          compose(&(v244_9),&(v246_10))
        };
        drop(v244_9);
        let v244_12: Space = unite(&(v244_7),&(v244_11));
        v243_11.join_into((v244_12).clone());
      }
      drop(v243_11_cursor);
      drop(v243_6);
      compose(&(v238_10),&(v243_11))
    };
    drop(v238_10);
    let v238_13: Space = unite(&(v238_8),&(v238_12));
    v237_12.join_into((v238_13).clone());
  }
  drop(v237_12_cursor);
  (v237_12).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v247_13 = Space::new();
  let mut v247_13_cursor = (*s0).read_zipper();
  for v247_13_byte in v247_13_cursor.child_mask().iter() {
    v247_13_cursor.descend_to_byte(v247_13_byte);
    let v247_13_tail = v247_13_cursor.make_map();
    v247_13_cursor.ascend(1);
    let v247_13_head = Path::from_slice(&[v247_13_byte]);
    let v248_2: Space = singleton(&(v247_13_head));
    let v248_3: Space = intersect(&(*CONSTANT_14),&(v248_2));
    let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
    drop(v248_3);
    let v248_5: Space = subtract(&(*CONSTANT_0),&(v248_4));
    drop(v248_4);
    let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
      let v249_6: Path = concat_path(&(*p0),&(v247_13_head));
      let mut v249_7 = Space::new();
      let mut v249_7_cursor = (v247_13_tail).read_zipper();
      for v249_7_byte in v249_7_cursor.child_mask().iter() {
        v249_7_cursor.descend_to_byte(v249_7_byte);
        let v249_7_tail = v249_7_cursor.make_map();
        v249_7_cursor.ascend(1);
        let v249_7_head = Path::from_slice(&[v249_7_byte]);
        let v250_2: Space = singleton(&(v249_7_head));
        let v250_3: Space = intersect(&(*CONSTANT_14),&(v250_2));
        let v250_4: Space = if has_head(&(v250_3)) { singleton(&[]) } else { Space::new() };
        drop(v250_3);
        let v250_5: Space = subtract(&(*CONSTANT_0),&(v250_4));
        drop(v250_4);
        let v250_8: Space = if (v250_5).is_empty() { Space::new() } else {
          let v251_6: Path = concat_path(&(v249_6),&(v249_7_head));
          let v251_7: Space = routine_57(c, &(v251_6), &(*p1), &(v249_7_tail), &(*s1));
          compose(&(v250_5),&(v251_7))
        };
        drop(v250_5);
        let v250_9: Space = intersect(&(*CONSTANT_14),&(v250_2));
        drop(v250_2);
        let v250_10: Space = if has_head(&(v250_9)) { singleton(&[]) } else { Space::new() };
        drop(v250_9);
        let v250_12: Space = if (v250_10).is_empty() { Space::new() } else {
          let v252_6: Path = concat_path(&(v249_6),&(v249_7_head));
          let v252_11: Space = routine_58(c, &(v252_6), &(*p1), &(v249_7_tail), &(*s1));
          drop(v252_6);
          compose(&(v250_10),&(v252_11))
        };
        drop(v250_10);
        let v250_13: Space = unite(&(v250_8),&(v250_12));
        v249_7.join_into((v250_13).clone());
      }
      drop(v249_7_cursor);
      compose(&(v248_5),&(v249_7))
    };
    drop(v248_5);
    let v248_9: Space = intersect(&(*CONSTANT_14),&(v248_2));
    drop(v248_2);
    let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
    drop(v248_9);
    let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
      let v253_6: Path = concat_path(&(*p0),&(v247_13_head));
      let mut v253_11 = Space::new();
      let mut v253_11_cursor = (v247_13_tail).read_zipper();
      for v253_11_byte in v253_11_cursor.child_mask().iter() {
        v253_11_cursor.descend_to_byte(v253_11_byte);
        let v253_11_tail = v253_11_cursor.make_map();
        v253_11_cursor.ascend(1);
        let v253_11_head = Path::from_slice(&[v253_11_byte]);
        let v254_2: Space = singleton(&(v253_11_head));
        let v254_3: Space = intersect(&(*CONSTANT_14),&(v254_2));
        let v254_4: Space = if has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
        drop(v254_3);
        let v254_5: Space = subtract(&(*CONSTANT_0),&(v254_4));
        drop(v254_4);
        let v254_8: Space = if (v254_5).is_empty() { Space::new() } else {
          let v255_6: Path = concat_path(&(v253_6),&(v253_11_head));
          let v255_7: Space = routine_57(c, &(v255_6), &(*p1), &(v253_11_tail), &(*s1));
          compose(&(v254_5),&(v255_7))
        };
        drop(v254_5);
        let v254_9: Space = intersect(&(*CONSTANT_14),&(v254_2));
        drop(v254_2);
        let v254_10: Space = if has_head(&(v254_9)) { singleton(&[]) } else { Space::new() };
        drop(v254_9);
        let v254_12: Space = if (v254_10).is_empty() { Space::new() } else {
          let v256_6: Path = concat_path(&(v253_6),&(v253_11_head));
          let v256_11: Space = routine_26(c, &(v256_6), &(*p1), &(v253_11_tail), &(*s1));
          drop(v256_6);
          compose(&(v254_10),&(v256_11))
        };
        drop(v254_10);
        let v254_13: Space = unite(&(v254_8),&(v254_12));
        v253_11.join_into((v254_13).clone());
      }
      drop(v253_11_cursor);
      drop(v253_6);
      compose(&(v248_10),&(v253_11))
    };
    drop(v248_10);
    let v248_13: Space = unite(&(v248_8),&(v248_12));
    v247_13.join_into((v248_13).clone());
  }
  drop(v247_13_cursor);
  (v247_13).clone()
}

fn routine_23(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v257_8: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v257_10: Space = unwrap(&(v257_8),&(*CONSTANT_10));
  drop(v257_8);
  let v257_11: Space = unwrap(&(v257_10),&(*p0));
  drop(v257_10);
  let mut v257_18 = Space::new();
  let mut v257_18_cursor = (*s0).read_zipper();
  for v257_18_byte in v257_18_cursor.child_mask().iter() {
    v257_18_cursor.descend_to_byte(v257_18_byte);
    let v257_18_tail = v257_18_cursor.make_map();
    v257_18_cursor.ascend(1);
    let v257_18_head = Path::from_slice(&[v257_18_byte]);
    let v258_2: Space = singleton(&(v257_18_head));
    let v258_3: Space = intersect(&(*CONSTANT_14),&(v258_2));
    let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
    drop(v258_3);
    let v258_5: Space = subtract(&(*CONSTANT_0),&(v258_4));
    drop(v258_4);
    let v258_8: Space = if (v258_5).is_empty() { Space::new() } else {
      let v259_6: Path = concat_path(&(*p0),&(v257_18_head));
      let mut v259_7 = Space::new();
      let mut v259_7_cursor = (v257_18_tail).read_zipper();
      for v259_7_byte in v259_7_cursor.child_mask().iter() {
        v259_7_cursor.descend_to_byte(v259_7_byte);
        let v259_7_tail = v259_7_cursor.make_map();
        v259_7_cursor.ascend(1);
        let v259_7_head = Path::from_slice(&[v259_7_byte]);
        let v260_2: Space = singleton(&(v259_7_head));
        let v260_3: Space = intersect(&(*CONSTANT_14),&(v260_2));
        let v260_4: Space = if has_head(&(v260_3)) { singleton(&[]) } else { Space::new() };
        drop(v260_3);
        let v260_5: Space = subtract(&(*CONSTANT_0),&(v260_4));
        drop(v260_4);
        let v260_8: Space = if (v260_5).is_empty() { Space::new() } else {
          let v261_6: Path = concat_path(&(v259_6),&(v259_7_head));
          let v261_7: Space = routine_57(c, &(v261_6), &(*p1), &(v259_7_tail), &(*s1));
          compose(&(v260_5),&(v261_7))
        };
        drop(v260_5);
        let v260_9: Space = intersect(&(*CONSTANT_14),&(v260_2));
        drop(v260_2);
        let v260_10: Space = if has_head(&(v260_9)) { singleton(&[]) } else { Space::new() };
        drop(v260_9);
        let v260_12: Space = if (v260_10).is_empty() { Space::new() } else {
          let v262_6: Path = concat_path(&(v259_6),&(v259_7_head));
          let v262_11: Space = routine_58(c, &(v262_6), &(*p1), &(v259_7_tail), &(*s1));
          drop(v262_6);
          compose(&(v260_10),&(v262_11))
        };
        drop(v260_10);
        let v260_13: Space = unite(&(v260_8),&(v260_12));
        v259_7.join_into((v260_13).clone());
      }
      drop(v259_7_cursor);
      drop(v259_6);
      compose(&(v258_5),&(v259_7))
    };
    drop(v258_5);
    let v258_9: Space = intersect(&(*CONSTANT_14),&(v258_2));
    drop(v258_2);
    let v258_10: Space = if has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
    drop(v258_9);
    let v258_13: Space = if (v258_10).is_empty() { Space::new() } else {
      let v263_11: Space = unwrap(&(v257_11),&(v257_18_head));
      let mut v263_12 = Space::new();
      let mut v263_12_cursor = (v263_11).read_zipper();
      for v263_12_byte in v263_12_cursor.child_mask().iter() {
        v263_12_cursor.descend_to_byte(v263_12_byte);
        let v263_12_tail = v263_12_cursor.make_map();
        v263_12_cursor.ascend(1);
        let v263_12_head = Path::from_slice(&[v263_12_byte]);
        let v264_2: Space = singleton(&(v263_12_head));
        let v264_3: Space = intersect(&(*CONSTANT_14),&(v264_2));
        let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
        drop(v264_3);
        let v264_5: Space = subtract(&(*CONSTANT_0),&(v264_4));
        drop(v264_4);
        let v264_7: Space = if (v264_5).is_empty() { Space::new() } else {
          let v265_6: Space = routine_59(c, &(v263_12_head), &(*p1), &(v263_12_tail));
          compose(&(v264_5),&(v265_6))
        };
        drop(v264_5);
        let v264_8: Space = intersect(&(*CONSTANT_14),&(v264_2));
        drop(v264_2);
        let v264_9: Space = if has_head(&(v264_8)) { singleton(&[]) } else { Space::new() };
        drop(v264_8);
        let v264_11: Space = if (v264_9).is_empty() { Space::new() } else {
          let v266_10: Space = routine_60(c, &(v263_12_head), &(*p1), &(v263_12_tail));
          compose(&(v264_9),&(v266_10))
        };
        drop(v264_9);
        let v264_12: Space = unite(&(v264_7),&(v264_11));
        v263_12.join_into((v264_12).clone());
      }
      drop(v263_12_cursor);
      drop(v263_11);
      compose(&(v258_10),&(v263_12))
    };
    drop(v258_10);
    let v258_14: Space = unite(&(v258_8),&(v258_13));
    v257_18.join_into((v258_14).clone());
  }
  drop(v257_18_cursor);
  drop(v257_11);
  (v257_18).clone()
}

fn routine_24(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v267_13 = Space::new();
  let mut v267_13_cursor = (*s0).read_zipper();
  for v267_13_byte in v267_13_cursor.child_mask().iter() {
    v267_13_cursor.descend_to_byte(v267_13_byte);
    let v267_13_tail = v267_13_cursor.make_map();
    v267_13_cursor.ascend(1);
    let v267_13_head = Path::from_slice(&[v267_13_byte]);
    let v268_2: Space = singleton(&(v267_13_head));
    let v268_3: Space = intersect(&(*CONSTANT_14),&(v268_2));
    let v268_4: Space = if has_head(&(v268_3)) { singleton(&[]) } else { Space::new() };
    drop(v268_3);
    let v268_5: Space = subtract(&(*CONSTANT_0),&(v268_4));
    drop(v268_4);
    let v268_8: Space = if (v268_5).is_empty() { Space::new() } else {
      let v269_6: Path = concat_path(&(*p0),&(v267_13_head));
      let mut v269_7 = Space::new();
      let mut v269_7_cursor = (v267_13_tail).read_zipper();
      for v269_7_byte in v269_7_cursor.child_mask().iter() {
        v269_7_cursor.descend_to_byte(v269_7_byte);
        let v269_7_tail = v269_7_cursor.make_map();
        v269_7_cursor.ascend(1);
        let v269_7_head = Path::from_slice(&[v269_7_byte]);
        let v270_2: Space = singleton(&(v269_7_head));
        let v270_3: Space = intersect(&(*CONSTANT_14),&(v270_2));
        let v270_4: Space = if has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
        drop(v270_3);
        let v270_5: Space = subtract(&(*CONSTANT_0),&(v270_4));
        drop(v270_4);
        let v270_8: Space = if (v270_5).is_empty() { Space::new() } else {
          let v271_6: Path = concat_path(&(v269_6),&(v269_7_head));
          let v271_7: Space = routine_61(c, &(v271_6), &(*p1), &(v269_7_tail), &(*s1));
          compose(&(v270_5),&(v271_7))
        };
        drop(v270_5);
        let v270_9: Space = intersect(&(*CONSTANT_14),&(v270_2));
        drop(v270_2);
        let v270_10: Space = if has_head(&(v270_9)) { singleton(&[]) } else { Space::new() };
        drop(v270_9);
        let v270_12: Space = if (v270_10).is_empty() { Space::new() } else {
          let v272_6: Path = concat_path(&(v269_6),&(v269_7_head));
          let v272_11: Space = routine_62(c, &(v272_6), &(*p1), &(v269_7_tail), &(*s1));
          drop(v272_6);
          compose(&(v270_10),&(v272_11))
        };
        drop(v270_10);
        let v270_13: Space = unite(&(v270_8),&(v270_12));
        v269_7.join_into((v270_13).clone());
      }
      drop(v269_7_cursor);
      compose(&(v268_5),&(v269_7))
    };
    drop(v268_5);
    let v268_9: Space = intersect(&(*CONSTANT_14),&(v268_2));
    drop(v268_2);
    let v268_10: Space = if has_head(&(v268_9)) { singleton(&[]) } else { Space::new() };
    drop(v268_9);
    let v268_12: Space = if (v268_10).is_empty() { Space::new() } else {
      let v273_6: Path = concat_path(&(*p0),&(v267_13_head));
      let mut v273_11 = Space::new();
      let mut v273_11_cursor = (v267_13_tail).read_zipper();
      for v273_11_byte in v273_11_cursor.child_mask().iter() {
        v273_11_cursor.descend_to_byte(v273_11_byte);
        let v273_11_tail = v273_11_cursor.make_map();
        v273_11_cursor.ascend(1);
        let v273_11_head = Path::from_slice(&[v273_11_byte]);
        let v274_2: Space = singleton(&(v273_11_head));
        let v274_3: Space = intersect(&(*CONSTANT_14),&(v274_2));
        let v274_4: Space = if has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
        drop(v274_3);
        let v274_5: Space = subtract(&(*CONSTANT_0),&(v274_4));
        drop(v274_4);
        let v274_8: Space = if (v274_5).is_empty() { Space::new() } else {
          let v275_6: Path = concat_path(&(v273_6),&(v273_11_head));
          let v275_7: Space = routine_61(c, &(v275_6), &(*p1), &(v273_11_tail), &(*s1));
          compose(&(v274_5),&(v275_7))
        };
        drop(v274_5);
        let v274_9: Space = intersect(&(*CONSTANT_14),&(v274_2));
        drop(v274_2);
        let v274_10: Space = if has_head(&(v274_9)) { singleton(&[]) } else { Space::new() };
        drop(v274_9);
        let v274_12: Space = if (v274_10).is_empty() { Space::new() } else {
          let v276_6: Path = concat_path(&(v273_6),&(v273_11_head));
          let v276_11: Space = routine_26(c, &(v276_6), &(*p1), &(v273_11_tail), &(*s1));
          drop(v276_6);
          compose(&(v274_10),&(v276_11))
        };
        drop(v274_10);
        let v274_13: Space = unite(&(v274_8),&(v274_12));
        v273_11.join_into((v274_13).clone());
      }
      drop(v273_11_cursor);
      drop(v273_6);
      compose(&(v268_10),&(v273_11))
    };
    drop(v268_10);
    let v268_13: Space = unite(&(v268_8),&(v268_12));
    v267_13.join_into((v268_13).clone());
  }
  drop(v267_13_cursor);
  (v267_13).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v277_8: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v277_10: Space = unwrap(&(v277_8),&(*CONSTANT_10));
  drop(v277_8);
  let v277_11: Space = unwrap(&(v277_10),&(*p0));
  drop(v277_10);
  let mut v277_18 = Space::new();
  let mut v277_18_cursor = (*s0).read_zipper();
  for v277_18_byte in v277_18_cursor.child_mask().iter() {
    v277_18_cursor.descend_to_byte(v277_18_byte);
    let v277_18_tail = v277_18_cursor.make_map();
    v277_18_cursor.ascend(1);
    let v277_18_head = Path::from_slice(&[v277_18_byte]);
    let v278_2: Space = singleton(&(v277_18_head));
    let v278_3: Space = intersect(&(*CONSTANT_14),&(v278_2));
    let v278_4: Space = if has_head(&(v278_3)) { singleton(&[]) } else { Space::new() };
    drop(v278_3);
    let v278_5: Space = subtract(&(*CONSTANT_0),&(v278_4));
    drop(v278_4);
    let v278_8: Space = if (v278_5).is_empty() { Space::new() } else {
      let v279_6: Path = concat_path(&(*p0),&(v277_18_head));
      let mut v279_7 = Space::new();
      let mut v279_7_cursor = (v277_18_tail).read_zipper();
      for v279_7_byte in v279_7_cursor.child_mask().iter() {
        v279_7_cursor.descend_to_byte(v279_7_byte);
        let v279_7_tail = v279_7_cursor.make_map();
        v279_7_cursor.ascend(1);
        let v279_7_head = Path::from_slice(&[v279_7_byte]);
        let v280_2: Space = singleton(&(v279_7_head));
        let v280_3: Space = intersect(&(*CONSTANT_14),&(v280_2));
        let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
        drop(v280_3);
        let v280_5: Space = subtract(&(*CONSTANT_0),&(v280_4));
        drop(v280_4);
        let v280_8: Space = if (v280_5).is_empty() { Space::new() } else {
          let v281_6: Path = concat_path(&(v279_6),&(v279_7_head));
          let v281_7: Space = routine_61(c, &(v281_6), &(*p1), &(v279_7_tail), &(*s1));
          compose(&(v280_5),&(v281_7))
        };
        drop(v280_5);
        let v280_9: Space = intersect(&(*CONSTANT_14),&(v280_2));
        drop(v280_2);
        let v280_10: Space = if has_head(&(v280_9)) { singleton(&[]) } else { Space::new() };
        drop(v280_9);
        let v280_12: Space = if (v280_10).is_empty() { Space::new() } else {
          let v282_6: Path = concat_path(&(v279_6),&(v279_7_head));
          let v282_11: Space = routine_62(c, &(v282_6), &(*p1), &(v279_7_tail), &(*s1));
          drop(v282_6);
          compose(&(v280_10),&(v282_11))
        };
        drop(v280_10);
        let v280_13: Space = unite(&(v280_8),&(v280_12));
        v279_7.join_into((v280_13).clone());
      }
      drop(v279_7_cursor);
      drop(v279_6);
      compose(&(v278_5),&(v279_7))
    };
    drop(v278_5);
    let v278_9: Space = intersect(&(*CONSTANT_14),&(v278_2));
    drop(v278_2);
    let v278_10: Space = if has_head(&(v278_9)) { singleton(&[]) } else { Space::new() };
    drop(v278_9);
    let v278_13: Space = if (v278_10).is_empty() { Space::new() } else {
      let v283_11: Space = unwrap(&(v277_11),&(v277_18_head));
      let mut v283_12 = Space::new();
      let mut v283_12_cursor = (v283_11).read_zipper();
      for v283_12_byte in v283_12_cursor.child_mask().iter() {
        v283_12_cursor.descend_to_byte(v283_12_byte);
        let v283_12_tail = v283_12_cursor.make_map();
        v283_12_cursor.ascend(1);
        let v283_12_head = Path::from_slice(&[v283_12_byte]);
        let v284_2: Space = singleton(&(v283_12_head));
        let v284_3: Space = intersect(&(*CONSTANT_14),&(v284_2));
        let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
        drop(v284_3);
        let v284_5: Space = subtract(&(*CONSTANT_0),&(v284_4));
        drop(v284_4);
        let v284_7: Space = if (v284_5).is_empty() { Space::new() } else {
          let v285_6: Space = routine_59(c, &(v283_12_head), &(*p1), &(v283_12_tail));
          compose(&(v284_5),&(v285_6))
        };
        drop(v284_5);
        let v284_8: Space = intersect(&(*CONSTANT_14),&(v284_2));
        drop(v284_2);
        let v284_9: Space = if has_head(&(v284_8)) { singleton(&[]) } else { Space::new() };
        drop(v284_8);
        let v284_11: Space = if (v284_9).is_empty() { Space::new() } else {
          let v286_10: Space = routine_60(c, &(v283_12_head), &(*p1), &(v283_12_tail));
          compose(&(v284_9),&(v286_10))
        };
        drop(v284_9);
        let v284_12: Space = unite(&(v284_7),&(v284_11));
        v283_12.join_into((v284_12).clone());
      }
      drop(v283_12_cursor);
      drop(v283_11);
      compose(&(v278_10),&(v283_12))
    };
    drop(v278_10);
    let v278_14: Space = unite(&(v278_8),&(v278_13));
    v277_18.join_into((v278_14).clone());
  }
  drop(v277_18_cursor);
  drop(v277_11);
  (v277_18).clone()
}

fn routine_26(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v287_5: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v287_7: Space = unwrap(&(v287_5),&(*CONSTANT_10));
  drop(v287_5);
  let v287_8: Space = unwrap(&(v287_7),&(*p0));
  drop(v287_7);
  let mut v287_18 = Space::new();
  let mut v287_18_cursor = (v287_8).read_zipper();
  for v287_18_byte in v287_18_cursor.child_mask().iter() {
    v287_18_cursor.descend_to_byte(v287_18_byte);
    let v287_18_tail = v287_18_cursor.make_map();
    v287_18_cursor.ascend(1);
    let v287_18_head = Path::from_slice(&[v287_18_byte]);
    let v288_2: Space = singleton(&(v287_18_head));
    let v288_3: Space = intersect(&(*CONSTANT_14),&(v288_2));
    let v288_4: Space = if has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
    drop(v288_3);
    let v288_5: Space = subtract(&(*CONSTANT_0),&(v288_4));
    drop(v288_4);
    let v288_7: Space = if (v288_5).is_empty() { Space::new() } else {
      let mut v289_6 = Space::new();
      let mut v289_6_cursor = (v287_18_tail).read_zipper();
      for v289_6_byte in v289_6_cursor.child_mask().iter() {
        v289_6_cursor.descend_to_byte(v289_6_byte);
        let v289_6_tail = v289_6_cursor.make_map();
        v289_6_cursor.ascend(1);
        let v289_6_head = Path::from_slice(&[v289_6_byte]);
        let v290_2: Space = singleton(&(v289_6_head));
        let v290_3: Space = intersect(&(*CONSTANT_14),&(v290_2));
        let v290_4: Space = if has_head(&(v290_3)) { singleton(&[]) } else { Space::new() };
        drop(v290_3);
        let v290_5: Space = subtract(&(*CONSTANT_0),&(v290_4));
        drop(v290_4);
        let v290_8: Space = if (v290_5).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v287_18_head),&(v289_6_head));
          let v291_7: Space = routine_63(c, &(v291_6), &(*p1), &(v289_6_tail));
          compose(&(v290_5),&(v291_7))
        };
        drop(v290_5);
        let v290_9: Space = intersect(&(*CONSTANT_14),&(v290_2));
        drop(v290_2);
        let v290_10: Space = if has_head(&(v290_9)) { singleton(&[]) } else { Space::new() };
        drop(v290_9);
        let v290_12: Space = if (v290_10).is_empty() { Space::new() } else {
          let v292_6: Path = concat_path(&(v287_18_head),&(v289_6_head));
          let v292_11: Space = routine_64(c, &(v292_6), &(*p1), &(v289_6_tail));
          drop(v292_6);
          compose(&(v290_10),&(v292_11))
        };
        drop(v290_10);
        let v290_13: Space = unite(&(v290_8),&(v290_12));
        v289_6.join_into((v290_13).clone());
      }
      drop(v289_6_cursor);
      compose(&(v288_5),&(v289_6))
    };
    drop(v288_5);
    let v288_8: Space = intersect(&(*CONSTANT_14),&(v288_2));
    drop(v288_2);
    let v288_9: Space = if has_head(&(v288_8)) { singleton(&[]) } else { Space::new() };
    drop(v288_8);
    let v288_11: Space = if (v288_9).is_empty() { Space::new() } else {
      let mut v293_10 = Space::new();
      let mut v293_10_cursor = (v287_18_tail).read_zipper();
      for v293_10_byte in v293_10_cursor.child_mask().iter() {
        v293_10_cursor.descend_to_byte(v293_10_byte);
        let v293_10_tail = v293_10_cursor.make_map();
        v293_10_cursor.ascend(1);
        let v293_10_head = Path::from_slice(&[v293_10_byte]);
        let v294_2: Space = singleton(&(v293_10_head));
        let v294_3: Space = intersect(&(*CONSTANT_14),&(v294_2));
        let v294_4: Space = if has_head(&(v294_3)) { singleton(&[]) } else { Space::new() };
        drop(v294_3);
        let v294_5: Space = subtract(&(*CONSTANT_0),&(v294_4));
        drop(v294_4);
        let v294_8: Space = if (v294_5).is_empty() { Space::new() } else {
          let v295_6: Path = concat_path(&(v287_18_head),&(v293_10_head));
          let v295_7: Space = routine_63(c, &(v295_6), &(*p1), &(v293_10_tail));
          compose(&(v294_5),&(v295_7))
        };
        drop(v294_5);
        let v294_9: Space = intersect(&(*CONSTANT_14),&(v294_2));
        drop(v294_2);
        let v294_10: Space = if has_head(&(v294_9)) { singleton(&[]) } else { Space::new() };
        drop(v294_9);
        let v294_12: Space = if (v294_10).is_empty() { Space::new() } else {
          let v296_6: Path = concat_path(&(v287_18_head),&(v293_10_head));
          let v296_11: Space = routine_65(c, &(v296_6), &(*p1), &(v293_10_tail));
          drop(v296_6);
          compose(&(v294_10),&(v296_11))
        };
        drop(v294_10);
        let v294_13: Space = unite(&(v294_8),&(v294_12));
        v293_10.join_into((v294_13).clone());
      }
      drop(v293_10_cursor);
      compose(&(v288_9),&(v293_10))
    };
    drop(v288_9);
    let v288_12: Space = unite(&(v288_7),&(v288_11));
    v287_18.join_into((v288_12).clone());
  }
  drop(v287_18_cursor);
  drop(v287_8);
  (v287_18).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v297_11 = Space::new();
  let mut v297_11_cursor = (*s0).read_zipper();
  for v297_11_byte in v297_11_cursor.child_mask().iter() {
    v297_11_cursor.descend_to_byte(v297_11_byte);
    let v297_11_tail = v297_11_cursor.make_map();
    v297_11_cursor.ascend(1);
    let v297_11_head = Path::from_slice(&[v297_11_byte]);
    let v298_2: Space = singleton(&(v297_11_head));
    let v298_3: Space = intersect(&(*CONSTANT_14),&(v298_2));
    let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
    drop(v298_3);
    let v298_5: Space = subtract(&(*CONSTANT_0),&(v298_4));
    drop(v298_4);
    let v298_8: Space = if (v298_5).is_empty() { Space::new() } else {
      let v299_6: Path = concat_path(&(*p0),&(v297_11_head));
      let mut v299_7 = Space::new();
      let mut v299_7_cursor = (v297_11_tail).read_zipper();
      for v299_7_byte in v299_7_cursor.child_mask().iter() {
        v299_7_cursor.descend_to_byte(v299_7_byte);
        let v299_7_tail = v299_7_cursor.make_map();
        v299_7_cursor.ascend(1);
        let v299_7_head = Path::from_slice(&[v299_7_byte]);
        let v300_2: Space = singleton(&(v299_7_head));
        let v300_3: Space = intersect(&(*CONSTANT_14),&(v300_2));
        let v300_4: Space = if has_head(&(v300_3)) { singleton(&[]) } else { Space::new() };
        drop(v300_3);
        let v300_5: Space = subtract(&(*CONSTANT_0),&(v300_4));
        drop(v300_4);
        let v300_8: Space = if (v300_5).is_empty() { Space::new() } else {
          let v301_6: Path = concat_path(&(v299_6),&(v299_7_head));
          let v301_7: Space = routine_66(c, &(v301_6), &(v299_7_tail));
          compose(&(v300_5),&(v301_7))
        };
        drop(v300_5);
        let v300_9: Space = intersect(&(*CONSTANT_14),&(v300_2));
        drop(v300_2);
        let v300_10: Space = if has_head(&(v300_9)) { singleton(&[]) } else { Space::new() };
        drop(v300_9);
        let v300_12: Space = if (v300_10).is_empty() { Space::new() } else {
          let v302_6: Path = concat_path(&(v299_6),&(v299_7_head));
          let v302_11: Space = routine_67(c, &(v302_6), &(v299_7_tail));
          drop(v302_6);
          compose(&(v300_10),&(v302_11))
        };
        drop(v300_10);
        let v300_13: Space = unite(&(v300_8),&(v300_12));
        v299_7.join_into((v300_13).clone());
      }
      drop(v299_7_cursor);
      compose(&(v298_5),&(v299_7))
    };
    drop(v298_5);
    let v298_9: Space = intersect(&(*CONSTANT_14),&(v298_2));
    drop(v298_2);
    let v298_10: Space = if has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
    drop(v298_9);
    let v298_12: Space = if (v298_10).is_empty() { Space::new() } else {
      let v303_6: Path = concat_path(&(*p0),&(v297_11_head));
      let mut v303_11 = Space::new();
      let mut v303_11_cursor = (v297_11_tail).read_zipper();
      for v303_11_byte in v303_11_cursor.child_mask().iter() {
        v303_11_cursor.descend_to_byte(v303_11_byte);
        let v303_11_tail = v303_11_cursor.make_map();
        v303_11_cursor.ascend(1);
        let v303_11_head = Path::from_slice(&[v303_11_byte]);
        let v304_2: Space = singleton(&(v303_11_head));
        let v304_3: Space = intersect(&(*CONSTANT_14),&(v304_2));
        let v304_4: Space = if has_head(&(v304_3)) { singleton(&[]) } else { Space::new() };
        drop(v304_3);
        let v304_5: Space = subtract(&(*CONSTANT_0),&(v304_4));
        drop(v304_4);
        let v304_8: Space = if (v304_5).is_empty() { Space::new() } else {
          let v305_6: Path = concat_path(&(v303_6),&(v303_11_head));
          let v305_7: Space = routine_66(c, &(v305_6), &(v303_11_tail));
          compose(&(v304_5),&(v305_7))
        };
        drop(v304_5);
        let v304_9: Space = intersect(&(*CONSTANT_14),&(v304_2));
        drop(v304_2);
        let v304_10: Space = if has_head(&(v304_9)) { singleton(&[]) } else { Space::new() };
        drop(v304_9);
        let v304_12: Space = if (v304_10).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v303_6),&(v303_11_head));
          let v306_11: Space = routine_8(c, &(v306_6), &(v303_11_tail));
          drop(v306_6);
          compose(&(v304_10),&(v306_11))
        };
        drop(v304_10);
        let v304_13: Space = unite(&(v304_8),&(v304_12));
        v303_11.join_into((v304_13).clone());
      }
      drop(v303_11_cursor);
      drop(v303_6);
      compose(&(v298_10),&(v303_11))
    };
    drop(v298_10);
    let v298_13: Space = unite(&(v298_8),&(v298_12));
    v297_11.join_into((v298_13).clone());
  }
  drop(v297_11_cursor);
  (v297_11).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v307_11 = Space::new();
  let mut v307_11_cursor = (*s0).read_zipper();
  for v307_11_byte in v307_11_cursor.child_mask().iter() {
    v307_11_cursor.descend_to_byte(v307_11_byte);
    let v307_11_tail = v307_11_cursor.make_map();
    v307_11_cursor.ascend(1);
    let v307_11_head = Path::from_slice(&[v307_11_byte]);
    let v308_2: Space = singleton(&(v307_11_head));
    let v308_3: Space = intersect(&(*CONSTANT_14),&(v308_2));
    let v308_4: Space = if has_head(&(v308_3)) { singleton(&[]) } else { Space::new() };
    drop(v308_3);
    let v308_5: Space = subtract(&(*CONSTANT_0),&(v308_4));
    drop(v308_4);
    let v308_8: Space = if (v308_5).is_empty() { Space::new() } else {
      let v309_6: Path = concat_path(&(*p0),&(v307_11_head));
      let mut v309_7 = Space::new();
      let mut v309_7_cursor = (v307_11_tail).read_zipper();
      for v309_7_byte in v309_7_cursor.child_mask().iter() {
        v309_7_cursor.descend_to_byte(v309_7_byte);
        let v309_7_tail = v309_7_cursor.make_map();
        v309_7_cursor.ascend(1);
        let v309_7_head = Path::from_slice(&[v309_7_byte]);
        let v310_2: Space = singleton(&(v309_7_head));
        let v310_3: Space = intersect(&(*CONSTANT_14),&(v310_2));
        let v310_4: Space = if has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
        drop(v310_3);
        let v310_5: Space = subtract(&(*CONSTANT_0),&(v310_4));
        drop(v310_4);
        let v310_8: Space = if (v310_5).is_empty() { Space::new() } else {
          let v311_6: Path = concat_path(&(v309_6),&(v309_7_head));
          let v311_7: Space = routine_66(c, &(v311_6), &(v309_7_tail));
          compose(&(v310_5),&(v311_7))
        };
        drop(v310_5);
        let v310_9: Space = intersect(&(*CONSTANT_14),&(v310_2));
        drop(v310_2);
        let v310_10: Space = if has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
        drop(v310_9);
        let v310_12: Space = if (v310_10).is_empty() { Space::new() } else {
          let v312_6: Path = concat_path(&(v309_6),&(v309_7_head));
          let v312_11: Space = routine_67(c, &(v312_6), &(v309_7_tail));
          drop(v312_6);
          compose(&(v310_10),&(v312_11))
        };
        drop(v310_10);
        let v310_13: Space = unite(&(v310_8),&(v310_12));
        v309_7.join_into((v310_13).clone());
      }
      drop(v309_7_cursor);
      compose(&(v308_5),&(v309_7))
    };
    drop(v308_5);
    let v308_9: Space = intersect(&(*CONSTANT_14),&(v308_2));
    drop(v308_2);
    let v308_10: Space = if has_head(&(v308_9)) { singleton(&[]) } else { Space::new() };
    drop(v308_9);
    let v308_12: Space = if (v308_10).is_empty() { Space::new() } else {
      let v313_6: Path = concat_path(&(*p0),&(v307_11_head));
      let mut v313_11 = Space::new();
      let mut v313_11_cursor = (v307_11_tail).read_zipper();
      for v313_11_byte in v313_11_cursor.child_mask().iter() {
        v313_11_cursor.descend_to_byte(v313_11_byte);
        let v313_11_tail = v313_11_cursor.make_map();
        v313_11_cursor.ascend(1);
        let v313_11_head = Path::from_slice(&[v313_11_byte]);
        let v314_2: Space = singleton(&(v313_11_head));
        let v314_3: Space = intersect(&(*CONSTANT_14),&(v314_2));
        let v314_4: Space = if has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
        drop(v314_3);
        let v314_5: Space = subtract(&(*CONSTANT_0),&(v314_4));
        drop(v314_4);
        let v314_7: Space = if (v314_5).is_empty() { Space::new() } else {
          let v315_6: Space = routine_29(c, &(v313_11_head), &(v313_6), &(v313_11_tail));
          compose(&(v314_5),&(v315_6))
        };
        drop(v314_5);
        let v314_8: Space = intersect(&(*CONSTANT_14),&(v314_2));
        drop(v314_2);
        let v314_9: Space = if has_head(&(v314_8)) { singleton(&[]) } else { Space::new() };
        drop(v314_8);
        let v314_11: Space = if (v314_9).is_empty() { Space::new() } else {
          let v316_10: Space = routine_30(c, &(v313_11_head), &(v313_6), &(v313_11_tail));
          compose(&(v314_9),&(v316_10))
        };
        drop(v314_9);
        let v314_12: Space = unite(&(v314_7),&(v314_11));
        v313_11.join_into((v314_12).clone());
      }
      drop(v313_11_cursor);
      drop(v313_6);
      compose(&(v308_10),&(v313_11))
    };
    drop(v308_10);
    let v308_13: Space = unite(&(v308_8),&(v308_12));
    v307_11.join_into((v308_13).clone());
  }
  drop(v307_11_cursor);
  (v307_11).clone()
}

fn routine_29(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v317_12 = Space::new();
  let mut v317_12_cursor = (*s0).read_zipper();
  for v317_12_byte in v317_12_cursor.child_mask().iter() {
    v317_12_cursor.descend_to_byte(v317_12_byte);
    let v317_12_tail = v317_12_cursor.make_map();
    v317_12_cursor.ascend(1);
    let v317_12_head = Path::from_slice(&[v317_12_byte]);
    let v318_2: Space = singleton(&(v317_12_head));
    let v318_3: Space = intersect(&(*CONSTANT_14),&(v318_2));
    let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
    drop(v318_3);
    let v318_5: Space = subtract(&(*CONSTANT_0),&(v318_4));
    drop(v318_4);
    let v318_8: Space = if (v318_5).is_empty() { Space::new() } else {
      let v319_6: Path = concat_path(&(*p0),&(v317_12_head));
      let mut v319_7 = Space::new();
      let mut v319_7_cursor = (v317_12_tail).read_zipper();
      for v319_7_byte in v319_7_cursor.child_mask().iter() {
        v319_7_cursor.descend_to_byte(v319_7_byte);
        let v319_7_tail = v319_7_cursor.make_map();
        v319_7_cursor.ascend(1);
        let v319_7_head = Path::from_slice(&[v319_7_byte]);
        let v320_2: Space = singleton(&(v319_7_head));
        let v320_3: Space = intersect(&(*CONSTANT_14),&(v320_2));
        let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
        drop(v320_3);
        let v320_5: Space = subtract(&(*CONSTANT_0),&(v320_4));
        drop(v320_4);
        let v320_8: Space = if (v320_5).is_empty() { Space::new() } else {
          let v321_6: Path = concat_path(&(v319_6),&(v319_7_head));
          let v321_7: Space = routine_68(c, &(v321_6), &(*p1), &(v319_7_tail));
          compose(&(v320_5),&(v321_7))
        };
        drop(v320_5);
        let v320_9: Space = intersect(&(*CONSTANT_14),&(v320_2));
        drop(v320_2);
        let v320_10: Space = if has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
        drop(v320_9);
        let v320_12: Space = if (v320_10).is_empty() { Space::new() } else {
          let v322_6: Path = concat_path(&(v319_6),&(v319_7_head));
          let v322_11: Space = routine_69(c, &(v322_6), &(*p1), &(v319_7_tail));
          drop(v322_6);
          compose(&(v320_10),&(v322_11))
        };
        drop(v320_10);
        let v320_13: Space = unite(&(v320_8),&(v320_12));
        v319_7.join_into((v320_13).clone());
      }
      drop(v319_7_cursor);
      compose(&(v318_5),&(v319_7))
    };
    drop(v318_5);
    let v318_9: Space = intersect(&(*CONSTANT_14),&(v318_2));
    drop(v318_2);
    let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
    drop(v318_9);
    let v318_12: Space = if (v318_10).is_empty() { Space::new() } else {
      let v323_6: Path = concat_path(&(*p0),&(v317_12_head));
      let mut v323_11 = Space::new();
      let mut v323_11_cursor = (v317_12_tail).read_zipper();
      for v323_11_byte in v323_11_cursor.child_mask().iter() {
        v323_11_cursor.descend_to_byte(v323_11_byte);
        let v323_11_tail = v323_11_cursor.make_map();
        v323_11_cursor.ascend(1);
        let v323_11_head = Path::from_slice(&[v323_11_byte]);
        let v324_2: Space = singleton(&(v323_11_head));
        let v324_3: Space = intersect(&(*CONSTANT_14),&(v324_2));
        let v324_4: Space = if has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
        drop(v324_3);
        let v324_5: Space = subtract(&(*CONSTANT_0),&(v324_4));
        drop(v324_4);
        let v324_8: Space = if (v324_5).is_empty() { Space::new() } else {
          let v325_6: Path = concat_path(&(v323_6),&(v323_11_head));
          let v325_7: Space = routine_68(c, &(v325_6), &(*p1), &(v323_11_tail));
          compose(&(v324_5),&(v325_7))
        };
        drop(v324_5);
        let v324_9: Space = intersect(&(*CONSTANT_14),&(v324_2));
        drop(v324_2);
        let v324_10: Space = if has_head(&(v324_9)) { singleton(&[]) } else { Space::new() };
        drop(v324_9);
        let v324_12: Space = if (v324_10).is_empty() { Space::new() } else {
          let v326_6: Path = concat_path(&(v323_6),&(v323_11_head));
          let v326_11: Space = routine_33(c, &(v326_6), &(*p1), &(v323_11_tail));
          drop(v326_6);
          compose(&(v324_10),&(v326_11))
        };
        drop(v324_10);
        let v324_13: Space = unite(&(v324_8),&(v324_12));
        v323_11.join_into((v324_13).clone());
      }
      drop(v323_11_cursor);
      drop(v323_6);
      compose(&(v318_10),&(v323_11))
    };
    drop(v318_10);
    let v318_13: Space = unite(&(v318_8),&(v318_12));
    v317_12.join_into((v318_13).clone());
  }
  drop(v317_12_cursor);
  (v317_12).clone()
}

fn routine_30(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v327_9 = Space::new();
  let mut v327_9_cursor = (*s0).read_zipper();
  for v327_9_byte in v327_9_cursor.child_mask().iter() {
    v327_9_cursor.descend_to_byte(v327_9_byte);
    let v327_9_tail = v327_9_cursor.make_map();
    v327_9_cursor.ascend(1);
    let v327_9_head = Path::from_slice(&[v327_9_byte]);
    let v328_2: Space = singleton(&(v327_9_head));
    let v328_3: Space = intersect(&(*CONSTANT_14),&(v328_2));
    let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
    drop(v328_3);
    let v328_5: Space = subtract(&(*CONSTANT_0),&(v328_4));
    drop(v328_4);
    let v328_8: Space = if (v328_5).is_empty() { Space::new() } else {
      let v329_6: Path = concat_path(&(*p0),&(v327_9_head));
      let mut v329_7 = Space::new();
      let mut v329_7_cursor = (v327_9_tail).read_zipper();
      for v329_7_byte in v329_7_cursor.child_mask().iter() {
        v329_7_cursor.descend_to_byte(v329_7_byte);
        let v329_7_tail = v329_7_cursor.make_map();
        v329_7_cursor.ascend(1);
        let v329_7_head = Path::from_slice(&[v329_7_byte]);
        let v330_2: Space = singleton(&(v329_7_head));
        let v330_3: Space = intersect(&(*CONSTANT_14),&(v330_2));
        let v330_4: Space = if has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
        drop(v330_3);
        let v330_5: Space = subtract(&(*CONSTANT_0),&(v330_4));
        drop(v330_4);
        let v330_8: Space = if (v330_5).is_empty() { Space::new() } else {
          let v331_6: Path = concat_path(&(v329_6),&(v329_7_head));
          let v331_7: Space = routine_68(c, &(v331_6), &(*p1), &(v329_7_tail));
          compose(&(v330_5),&(v331_7))
        };
        drop(v330_5);
        let v330_9: Space = intersect(&(*CONSTANT_14),&(v330_2));
        drop(v330_2);
        let v330_10: Space = if has_head(&(v330_9)) { singleton(&[]) } else { Space::new() };
        drop(v330_9);
        let v330_12: Space = if (v330_10).is_empty() { Space::new() } else {
          let v332_6: Path = concat_path(&(v329_6),&(v329_7_head));
          let v332_11: Space = routine_69(c, &(v332_6), &(*p1), &(v329_7_tail));
          drop(v332_6);
          compose(&(v330_10),&(v332_11))
        };
        drop(v330_10);
        let v330_13: Space = unite(&(v330_8),&(v330_12));
        v329_7.join_into((v330_13).clone());
      }
      drop(v329_7_cursor);
      compose(&(v328_5),&(v329_7))
    };
    drop(v328_5);
    let v328_9: Space = intersect(&(*CONSTANT_14),&(v328_2));
    drop(v328_2);
    let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
    drop(v328_9);
    let v328_11: Space = compose(&(v328_10),&(v327_9_tail));
    drop(v328_10);
    let v333_6: Path = concat_path(&(*p0),&(v327_9_head));
    let v328_12: Space = wrap(&(v328_11),&(v333_6));
    drop(v328_11);
    let v328_13: Space = wrap(&(v328_12),&(*p1));
    drop(v328_12);
    let v328_14: Space = unite(&(v328_8),&(v328_13));
    drop(v328_13);
    v327_9.join_into((v328_14).clone());
  }
  drop(v327_9_cursor);
  (v327_9).clone()
}

fn routine_31(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v334_12 = Space::new();
  let mut v334_12_cursor = (*s0).read_zipper();
  for v334_12_byte in v334_12_cursor.child_mask().iter() {
    v334_12_cursor.descend_to_byte(v334_12_byte);
    let v334_12_tail = v334_12_cursor.make_map();
    v334_12_cursor.ascend(1);
    let v334_12_head = Path::from_slice(&[v334_12_byte]);
    let v335_2: Space = singleton(&(v334_12_head));
    let v335_3: Space = intersect(&(*CONSTANT_14),&(v335_2));
    let v335_4: Space = if has_head(&(v335_3)) { singleton(&[]) } else { Space::new() };
    drop(v335_3);
    let v335_5: Space = subtract(&(*CONSTANT_0),&(v335_4));
    drop(v335_4);
    let v335_8: Space = if (v335_5).is_empty() { Space::new() } else {
      let v336_6: Path = concat_path(&(*p0),&(v334_12_head));
      let mut v336_7 = Space::new();
      let mut v336_7_cursor = (v334_12_tail).read_zipper();
      for v336_7_byte in v336_7_cursor.child_mask().iter() {
        v336_7_cursor.descend_to_byte(v336_7_byte);
        let v336_7_tail = v336_7_cursor.make_map();
        v336_7_cursor.ascend(1);
        let v336_7_head = Path::from_slice(&[v336_7_byte]);
        let v337_2: Space = singleton(&(v336_7_head));
        let v337_3: Space = intersect(&(*CONSTANT_14),&(v337_2));
        let v337_4: Space = if has_head(&(v337_3)) { singleton(&[]) } else { Space::new() };
        drop(v337_3);
        let v337_5: Space = subtract(&(*CONSTANT_0),&(v337_4));
        drop(v337_4);
        let v337_8: Space = if (v337_5).is_empty() { Space::new() } else {
          let v338_6: Path = concat_path(&(v336_6),&(v336_7_head));
          let v338_7: Space = routine_70(c, &(v338_6), &(*p1), &(v336_7_tail));
          compose(&(v337_5),&(v338_7))
        };
        drop(v337_5);
        let v337_9: Space = intersect(&(*CONSTANT_14),&(v337_2));
        drop(v337_2);
        let v337_10: Space = if has_head(&(v337_9)) { singleton(&[]) } else { Space::new() };
        drop(v337_9);
        let v337_12: Space = if (v337_10).is_empty() { Space::new() } else {
          let v339_6: Path = concat_path(&(v336_6),&(v336_7_head));
          let v339_11: Space = routine_71(c, &(v339_6), &(*p1), &(v336_7_tail));
          drop(v339_6);
          compose(&(v337_10),&(v339_11))
        };
        drop(v337_10);
        let v337_13: Space = unite(&(v337_8),&(v337_12));
        v336_7.join_into((v337_13).clone());
      }
      drop(v336_7_cursor);
      compose(&(v335_5),&(v336_7))
    };
    drop(v335_5);
    let v335_9: Space = intersect(&(*CONSTANT_14),&(v335_2));
    drop(v335_2);
    let v335_10: Space = if has_head(&(v335_9)) { singleton(&[]) } else { Space::new() };
    drop(v335_9);
    let v335_12: Space = if (v335_10).is_empty() { Space::new() } else {
      let v340_6: Path = concat_path(&(*p0),&(v334_12_head));
      let mut v340_11 = Space::new();
      let mut v340_11_cursor = (v334_12_tail).read_zipper();
      for v340_11_byte in v340_11_cursor.child_mask().iter() {
        v340_11_cursor.descend_to_byte(v340_11_byte);
        let v340_11_tail = v340_11_cursor.make_map();
        v340_11_cursor.ascend(1);
        let v340_11_head = Path::from_slice(&[v340_11_byte]);
        let v341_2: Space = singleton(&(v340_11_head));
        let v341_3: Space = intersect(&(*CONSTANT_14),&(v341_2));
        let v341_4: Space = if has_head(&(v341_3)) { singleton(&[]) } else { Space::new() };
        drop(v341_3);
        let v341_5: Space = subtract(&(*CONSTANT_0),&(v341_4));
        drop(v341_4);
        let v341_8: Space = if (v341_5).is_empty() { Space::new() } else {
          let v342_6: Path = concat_path(&(v340_6),&(v340_11_head));
          let v342_7: Space = routine_70(c, &(v342_6), &(*p1), &(v340_11_tail));
          compose(&(v341_5),&(v342_7))
        };
        drop(v341_5);
        let v341_9: Space = intersect(&(*CONSTANT_14),&(v341_2));
        drop(v341_2);
        let v341_10: Space = if has_head(&(v341_9)) { singleton(&[]) } else { Space::new() };
        drop(v341_9);
        let v341_12: Space = if (v341_10).is_empty() { Space::new() } else {
          let v343_6: Path = concat_path(&(v340_6),&(v340_11_head));
          let v343_11: Space = routine_33(c, &(v343_6), &(*p1), &(v340_11_tail));
          drop(v343_6);
          compose(&(v341_10),&(v343_11))
        };
        drop(v341_10);
        let v341_13: Space = unite(&(v341_8),&(v341_12));
        v340_11.join_into((v341_13).clone());
      }
      drop(v340_11_cursor);
      drop(v340_6);
      compose(&(v335_10),&(v340_11))
    };
    drop(v335_10);
    let v335_13: Space = unite(&(v335_8),&(v335_12));
    v334_12.join_into((v335_13).clone());
  }
  drop(v334_12_cursor);
  (v334_12).clone()
}

fn routine_32(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v344_9 = Space::new();
  let mut v344_9_cursor = (*s0).read_zipper();
  for v344_9_byte in v344_9_cursor.child_mask().iter() {
    v344_9_cursor.descend_to_byte(v344_9_byte);
    let v344_9_tail = v344_9_cursor.make_map();
    v344_9_cursor.ascend(1);
    let v344_9_head = Path::from_slice(&[v344_9_byte]);
    let v345_2: Space = singleton(&(v344_9_head));
    let v345_3: Space = intersect(&(*CONSTANT_14),&(v345_2));
    let v345_4: Space = if has_head(&(v345_3)) { singleton(&[]) } else { Space::new() };
    drop(v345_3);
    let v345_5: Space = subtract(&(*CONSTANT_0),&(v345_4));
    drop(v345_4);
    let v345_8: Space = if (v345_5).is_empty() { Space::new() } else {
      let v346_6: Path = concat_path(&(*p0),&(v344_9_head));
      let mut v346_7 = Space::new();
      let mut v346_7_cursor = (v344_9_tail).read_zipper();
      for v346_7_byte in v346_7_cursor.child_mask().iter() {
        v346_7_cursor.descend_to_byte(v346_7_byte);
        let v346_7_tail = v346_7_cursor.make_map();
        v346_7_cursor.ascend(1);
        let v346_7_head = Path::from_slice(&[v346_7_byte]);
        let v347_2: Space = singleton(&(v346_7_head));
        let v347_3: Space = intersect(&(*CONSTANT_14),&(v347_2));
        let v347_4: Space = if has_head(&(v347_3)) { singleton(&[]) } else { Space::new() };
        drop(v347_3);
        let v347_5: Space = subtract(&(*CONSTANT_0),&(v347_4));
        drop(v347_4);
        let v347_8: Space = if (v347_5).is_empty() { Space::new() } else {
          let v348_6: Path = concat_path(&(v346_6),&(v346_7_head));
          let v348_7: Space = routine_70(c, &(v348_6), &(*p1), &(v346_7_tail));
          compose(&(v347_5),&(v348_7))
        };
        drop(v347_5);
        let v347_9: Space = intersect(&(*CONSTANT_14),&(v347_2));
        drop(v347_2);
        let v347_10: Space = if has_head(&(v347_9)) { singleton(&[]) } else { Space::new() };
        drop(v347_9);
        let v347_12: Space = if (v347_10).is_empty() { Space::new() } else {
          let v349_6: Path = concat_path(&(v346_6),&(v346_7_head));
          let v349_11: Space = routine_71(c, &(v349_6), &(*p1), &(v346_7_tail));
          drop(v349_6);
          compose(&(v347_10),&(v349_11))
        };
        drop(v347_10);
        let v347_13: Space = unite(&(v347_8),&(v347_12));
        v346_7.join_into((v347_13).clone());
      }
      drop(v346_7_cursor);
      compose(&(v345_5),&(v346_7))
    };
    drop(v345_5);
    let v345_9: Space = intersect(&(*CONSTANT_14),&(v345_2));
    drop(v345_2);
    let v345_10: Space = if has_head(&(v345_9)) { singleton(&[]) } else { Space::new() };
    drop(v345_9);
    let v345_11: Space = compose(&(v345_10),&(v344_9_tail));
    drop(v345_10);
    let v350_6: Path = concat_path(&(*p0),&(v344_9_head));
    let v345_12: Space = wrap(&(v345_11),&(v350_6));
    drop(v345_11);
    let v345_13: Space = wrap(&(v345_12),&(*p1));
    drop(v345_12);
    let v345_14: Space = unite(&(v345_8),&(v345_13));
    drop(v345_13);
    v344_9.join_into((v345_14).clone());
  }
  drop(v344_9_cursor);
  (v344_9).clone()
}

fn routine_33(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v351_3: Space = wrap(&(*s0),&(*p0));
  let v351_4: Space = wrap(&(v351_3),&(*p1));
  drop(v351_3);
  (v351_4).clone()
}

fn routine_34(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v352_12 = Space::new();
  let mut v352_12_cursor = (*s0).read_zipper();
  for v352_12_byte in v352_12_cursor.child_mask().iter() {
    v352_12_cursor.descend_to_byte(v352_12_byte);
    let v352_12_tail = v352_12_cursor.make_map();
    v352_12_cursor.ascend(1);
    let v352_12_head = Path::from_slice(&[v352_12_byte]);
    let v353_2: Space = singleton(&(v352_12_head));
    let v353_3: Space = intersect(&(*CONSTANT_14),&(v353_2));
    let v353_4: Space = if has_head(&(v353_3)) { singleton(&[]) } else { Space::new() };
    drop(v353_3);
    let v353_5: Space = subtract(&(*CONSTANT_0),&(v353_4));
    drop(v353_4);
    let v353_8: Space = if (v353_5).is_empty() { Space::new() } else {
      let v354_6: Path = concat_path(&(*p0),&(v352_12_head));
      let mut v354_7 = Space::new();
      let mut v354_7_cursor = (v352_12_tail).read_zipper();
      for v354_7_byte in v354_7_cursor.child_mask().iter() {
        v354_7_cursor.descend_to_byte(v354_7_byte);
        let v354_7_tail = v354_7_cursor.make_map();
        v354_7_cursor.ascend(1);
        let v354_7_head = Path::from_slice(&[v354_7_byte]);
        let v355_2: Space = singleton(&(v354_7_head));
        let v355_3: Space = intersect(&(*CONSTANT_14),&(v355_2));
        let v355_4: Space = if has_head(&(v355_3)) { singleton(&[]) } else { Space::new() };
        drop(v355_3);
        let v355_5: Space = subtract(&(*CONSTANT_0),&(v355_4));
        drop(v355_4);
        let v355_8: Space = if (v355_5).is_empty() { Space::new() } else {
          let v356_6: Path = concat_path(&(v354_6),&(v354_7_head));
          let v356_7: Space = routine_72(c, &(v356_6), &(v354_7_tail), &(*s1));
          compose(&(v355_5),&(v356_7))
        };
        drop(v355_5);
        let v355_9: Space = intersect(&(*CONSTANT_14),&(v355_2));
        drop(v355_2);
        let v355_10: Space = if has_head(&(v355_9)) { singleton(&[]) } else { Space::new() };
        drop(v355_9);
        let v355_12: Space = if (v355_10).is_empty() { Space::new() } else {
          let v357_6: Path = concat_path(&(v354_6),&(v354_7_head));
          let v357_11: Space = routine_73(c, &(v357_6), &(v354_7_tail), &(*s1));
          drop(v357_6);
          compose(&(v355_10),&(v357_11))
        };
        drop(v355_10);
        let v355_13: Space = unite(&(v355_8),&(v355_12));
        v354_7.join_into((v355_13).clone());
      }
      drop(v354_7_cursor);
      compose(&(v353_5),&(v354_7))
    };
    drop(v353_5);
    let v353_9: Space = intersect(&(*CONSTANT_14),&(v353_2));
    drop(v353_2);
    let v353_10: Space = if has_head(&(v353_9)) { singleton(&[]) } else { Space::new() };
    drop(v353_9);
    let v353_12: Space = if (v353_10).is_empty() { Space::new() } else {
      let v358_6: Path = concat_path(&(*p0),&(v352_12_head));
      let mut v358_11 = Space::new();
      let mut v358_11_cursor = (v352_12_tail).read_zipper();
      for v358_11_byte in v358_11_cursor.child_mask().iter() {
        v358_11_cursor.descend_to_byte(v358_11_byte);
        let v358_11_tail = v358_11_cursor.make_map();
        v358_11_cursor.ascend(1);
        let v358_11_head = Path::from_slice(&[v358_11_byte]);
        let v359_2: Space = singleton(&(v358_11_head));
        let v359_3: Space = intersect(&(*CONSTANT_14),&(v359_2));
        let v359_4: Space = if has_head(&(v359_3)) { singleton(&[]) } else { Space::new() };
        drop(v359_3);
        let v359_5: Space = subtract(&(*CONSTANT_0),&(v359_4));
        drop(v359_4);
        let v359_8: Space = if (v359_5).is_empty() { Space::new() } else {
          let v360_6: Path = concat_path(&(v358_6),&(v358_11_head));
          let v360_7: Space = routine_72(c, &(v360_6), &(v358_11_tail), &(*s1));
          compose(&(v359_5),&(v360_7))
        };
        drop(v359_5);
        let v359_9: Space = intersect(&(*CONSTANT_14),&(v359_2));
        drop(v359_2);
        let v359_10: Space = if has_head(&(v359_9)) { singleton(&[]) } else { Space::new() };
        drop(v359_9);
        let v359_12: Space = if (v359_10).is_empty() { Space::new() } else {
          let v361_6: Path = concat_path(&(v358_6),&(v358_11_head));
          let v361_11: Space = routine_11(c, &(v361_6), &(v358_11_tail), &(*s1));
          drop(v361_6);
          compose(&(v359_10),&(v361_11))
        };
        drop(v359_10);
        let v359_13: Space = unite(&(v359_8),&(v359_12));
        v358_11.join_into((v359_13).clone());
      }
      drop(v358_11_cursor);
      drop(v358_6);
      compose(&(v353_10),&(v358_11))
    };
    drop(v353_10);
    let v353_13: Space = unite(&(v353_8),&(v353_12));
    v352_12.join_into((v353_13).clone());
  }
  drop(v352_12_cursor);
  (v352_12).clone()
}

fn routine_35(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v362_12 = Space::new();
  let mut v362_12_cursor = (*s0).read_zipper();
  for v362_12_byte in v362_12_cursor.child_mask().iter() {
    v362_12_cursor.descend_to_byte(v362_12_byte);
    let v362_12_tail = v362_12_cursor.make_map();
    v362_12_cursor.ascend(1);
    let v362_12_head = Path::from_slice(&[v362_12_byte]);
    let v363_2: Space = singleton(&(v362_12_head));
    let v363_3: Space = intersect(&(*CONSTANT_14),&(v363_2));
    let v363_4: Space = if has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
    drop(v363_3);
    let v363_5: Space = subtract(&(*CONSTANT_0),&(v363_4));
    drop(v363_4);
    let v363_8: Space = if (v363_5).is_empty() { Space::new() } else {
      let v364_6: Path = concat_path(&(*p0),&(v362_12_head));
      let mut v364_7 = Space::new();
      let mut v364_7_cursor = (v362_12_tail).read_zipper();
      for v364_7_byte in v364_7_cursor.child_mask().iter() {
        v364_7_cursor.descend_to_byte(v364_7_byte);
        let v364_7_tail = v364_7_cursor.make_map();
        v364_7_cursor.ascend(1);
        let v364_7_head = Path::from_slice(&[v364_7_byte]);
        let v365_2: Space = singleton(&(v364_7_head));
        let v365_3: Space = intersect(&(*CONSTANT_14),&(v365_2));
        let v365_4: Space = if has_head(&(v365_3)) { singleton(&[]) } else { Space::new() };
        drop(v365_3);
        let v365_5: Space = subtract(&(*CONSTANT_0),&(v365_4));
        drop(v365_4);
        let v365_8: Space = if (v365_5).is_empty() { Space::new() } else {
          let v366_6: Path = concat_path(&(v364_6),&(v364_7_head));
          let v366_7: Space = routine_72(c, &(v366_6), &(v364_7_tail), &(*s1));
          compose(&(v365_5),&(v366_7))
        };
        drop(v365_5);
        let v365_9: Space = intersect(&(*CONSTANT_14),&(v365_2));
        drop(v365_2);
        let v365_10: Space = if has_head(&(v365_9)) { singleton(&[]) } else { Space::new() };
        drop(v365_9);
        let v365_12: Space = if (v365_10).is_empty() { Space::new() } else {
          let v367_6: Path = concat_path(&(v364_6),&(v364_7_head));
          let v367_11: Space = routine_73(c, &(v367_6), &(v364_7_tail), &(*s1));
          drop(v367_6);
          compose(&(v365_10),&(v367_11))
        };
        drop(v365_10);
        let v365_13: Space = unite(&(v365_8),&(v365_12));
        v364_7.join_into((v365_13).clone());
      }
      drop(v364_7_cursor);
      compose(&(v363_5),&(v364_7))
    };
    drop(v363_5);
    let v363_9: Space = intersect(&(*CONSTANT_14),&(v363_2));
    drop(v363_2);
    let v363_10: Space = if has_head(&(v363_9)) { singleton(&[]) } else { Space::new() };
    drop(v363_9);
    let v363_12: Space = if (v363_10).is_empty() { Space::new() } else {
      let v368_6: Path = concat_path(&(*p0),&(v362_12_head));
      let mut v368_11 = Space::new();
      let mut v368_11_cursor = (v362_12_tail).read_zipper();
      for v368_11_byte in v368_11_cursor.child_mask().iter() {
        v368_11_cursor.descend_to_byte(v368_11_byte);
        let v368_11_tail = v368_11_cursor.make_map();
        v368_11_cursor.ascend(1);
        let v368_11_head = Path::from_slice(&[v368_11_byte]);
        let v369_2: Space = singleton(&(v368_11_head));
        let v369_3: Space = intersect(&(*CONSTANT_14),&(v369_2));
        let v369_4: Space = if has_head(&(v369_3)) { singleton(&[]) } else { Space::new() };
        drop(v369_3);
        let v369_5: Space = subtract(&(*CONSTANT_0),&(v369_4));
        drop(v369_4);
        let v369_7: Space = if (v369_5).is_empty() { Space::new() } else {
          let v370_6: Space = routine_36(c, &(v368_11_head), &(v368_6), &(v368_11_tail), &(*s1));
          compose(&(v369_5),&(v370_6))
        };
        drop(v369_5);
        let v369_8: Space = intersect(&(*CONSTANT_14),&(v369_2));
        drop(v369_2);
        let v369_9: Space = if has_head(&(v369_8)) { singleton(&[]) } else { Space::new() };
        drop(v369_8);
        let v369_11: Space = if (v369_9).is_empty() { Space::new() } else {
          let v371_10: Space = routine_37(c, &(v368_11_head), &(v368_6), &(v368_11_tail), &(*s1));
          compose(&(v369_9),&(v371_10))
        };
        drop(v369_9);
        let v369_12: Space = unite(&(v369_7),&(v369_11));
        v368_11.join_into((v369_12).clone());
      }
      drop(v368_11_cursor);
      drop(v368_6);
      compose(&(v363_10),&(v368_11))
    };
    drop(v363_10);
    let v363_13: Space = unite(&(v363_8),&(v363_12));
    v362_12.join_into((v363_13).clone());
  }
  drop(v362_12_cursor);
  (v362_12).clone()
}

fn routine_36(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v372_13 = Space::new();
  let mut v372_13_cursor = (*s0).read_zipper();
  for v372_13_byte in v372_13_cursor.child_mask().iter() {
    v372_13_cursor.descend_to_byte(v372_13_byte);
    let v372_13_tail = v372_13_cursor.make_map();
    v372_13_cursor.ascend(1);
    let v372_13_head = Path::from_slice(&[v372_13_byte]);
    let v373_2: Space = singleton(&(v372_13_head));
    let v373_3: Space = intersect(&(*CONSTANT_14),&(v373_2));
    let v373_4: Space = if has_head(&(v373_3)) { singleton(&[]) } else { Space::new() };
    drop(v373_3);
    let v373_5: Space = subtract(&(*CONSTANT_0),&(v373_4));
    drop(v373_4);
    let v373_8: Space = if (v373_5).is_empty() { Space::new() } else {
      let v374_6: Path = concat_path(&(*p0),&(v372_13_head));
      let mut v374_7 = Space::new();
      let mut v374_7_cursor = (v372_13_tail).read_zipper();
      for v374_7_byte in v374_7_cursor.child_mask().iter() {
        v374_7_cursor.descend_to_byte(v374_7_byte);
        let v374_7_tail = v374_7_cursor.make_map();
        v374_7_cursor.ascend(1);
        let v374_7_head = Path::from_slice(&[v374_7_byte]);
        let v375_2: Space = singleton(&(v374_7_head));
        let v375_3: Space = intersect(&(*CONSTANT_14),&(v375_2));
        let v375_4: Space = if has_head(&(v375_3)) { singleton(&[]) } else { Space::new() };
        drop(v375_3);
        let v375_5: Space = subtract(&(*CONSTANT_0),&(v375_4));
        drop(v375_4);
        let v375_8: Space = if (v375_5).is_empty() { Space::new() } else {
          let v376_6: Path = concat_path(&(v374_6),&(v374_7_head));
          let v376_7: Space = routine_74(c, &(v376_6), &(*p1), &(v374_7_tail), &(*s1));
          compose(&(v375_5),&(v376_7))
        };
        drop(v375_5);
        let v375_9: Space = intersect(&(*CONSTANT_14),&(v375_2));
        drop(v375_2);
        let v375_10: Space = if has_head(&(v375_9)) { singleton(&[]) } else { Space::new() };
        drop(v375_9);
        let v375_12: Space = if (v375_10).is_empty() { Space::new() } else {
          let v377_6: Path = concat_path(&(v374_6),&(v374_7_head));
          let v377_11: Space = routine_75(c, &(v377_6), &(*p1), &(v374_7_tail), &(*s1));
          drop(v377_6);
          compose(&(v375_10),&(v377_11))
        };
        drop(v375_10);
        let v375_13: Space = unite(&(v375_8),&(v375_12));
        v374_7.join_into((v375_13).clone());
      }
      drop(v374_7_cursor);
      compose(&(v373_5),&(v374_7))
    };
    drop(v373_5);
    let v373_9: Space = intersect(&(*CONSTANT_14),&(v373_2));
    drop(v373_2);
    let v373_10: Space = if has_head(&(v373_9)) { singleton(&[]) } else { Space::new() };
    drop(v373_9);
    let v373_12: Space = if (v373_10).is_empty() { Space::new() } else {
      let v378_6: Path = concat_path(&(*p0),&(v372_13_head));
      let mut v378_11 = Space::new();
      let mut v378_11_cursor = (v372_13_tail).read_zipper();
      for v378_11_byte in v378_11_cursor.child_mask().iter() {
        v378_11_cursor.descend_to_byte(v378_11_byte);
        let v378_11_tail = v378_11_cursor.make_map();
        v378_11_cursor.ascend(1);
        let v378_11_head = Path::from_slice(&[v378_11_byte]);
        let v379_2: Space = singleton(&(v378_11_head));
        let v379_3: Space = intersect(&(*CONSTANT_14),&(v379_2));
        let v379_4: Space = if has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
        drop(v379_3);
        let v379_5: Space = subtract(&(*CONSTANT_0),&(v379_4));
        drop(v379_4);
        let v379_8: Space = if (v379_5).is_empty() { Space::new() } else {
          let v380_6: Path = concat_path(&(v378_6),&(v378_11_head));
          let v380_7: Space = routine_74(c, &(v380_6), &(*p1), &(v378_11_tail), &(*s1));
          compose(&(v379_5),&(v380_7))
        };
        drop(v379_5);
        let v379_9: Space = intersect(&(*CONSTANT_14),&(v379_2));
        drop(v379_2);
        let v379_10: Space = if has_head(&(v379_9)) { singleton(&[]) } else { Space::new() };
        drop(v379_9);
        let v379_12: Space = if (v379_10).is_empty() { Space::new() } else {
          let v381_6: Path = concat_path(&(v378_6),&(v378_11_head));
          let v381_11: Space = routine_40(c, &(v381_6), &(*p1), &(v378_11_tail), &(*s1));
          drop(v381_6);
          compose(&(v379_10),&(v381_11))
        };
        drop(v379_10);
        let v379_13: Space = unite(&(v379_8),&(v379_12));
        v378_11.join_into((v379_13).clone());
      }
      drop(v378_11_cursor);
      drop(v378_6);
      compose(&(v373_10),&(v378_11))
    };
    drop(v373_10);
    let v373_13: Space = unite(&(v373_8),&(v373_12));
    v372_13.join_into((v373_13).clone());
  }
  drop(v372_13_cursor);
  (v372_13).clone()
}

fn routine_37(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v382_8: Space = unwrap(&(*s1),&(*CONSTANT_9));
  let v382_10: Space = unwrap(&(v382_8),&(*CONSTANT_10));
  drop(v382_8);
  let v382_11: Space = unwrap(&(v382_10),&(*p0));
  drop(v382_10);
  let mut v382_18 = Space::new();
  let mut v382_18_cursor = (*s0).read_zipper();
  for v382_18_byte in v382_18_cursor.child_mask().iter() {
    v382_18_cursor.descend_to_byte(v382_18_byte);
    let v382_18_tail = v382_18_cursor.make_map();
    v382_18_cursor.ascend(1);
    let v382_18_head = Path::from_slice(&[v382_18_byte]);
    let v383_2: Space = singleton(&(v382_18_head));
    let v383_3: Space = intersect(&(*CONSTANT_14),&(v383_2));
    let v383_4: Space = if has_head(&(v383_3)) { singleton(&[]) } else { Space::new() };
    drop(v383_3);
    let v383_5: Space = subtract(&(*CONSTANT_0),&(v383_4));
    drop(v383_4);
    let v383_8: Space = if (v383_5).is_empty() { Space::new() } else {
      let v384_6: Path = concat_path(&(*p0),&(v382_18_head));
      let mut v384_7 = Space::new();
      let mut v384_7_cursor = (v382_18_tail).read_zipper();
      for v384_7_byte in v384_7_cursor.child_mask().iter() {
        v384_7_cursor.descend_to_byte(v384_7_byte);
        let v384_7_tail = v384_7_cursor.make_map();
        v384_7_cursor.ascend(1);
        let v384_7_head = Path::from_slice(&[v384_7_byte]);
        let v385_2: Space = singleton(&(v384_7_head));
        let v385_3: Space = intersect(&(*CONSTANT_14),&(v385_2));
        let v385_4: Space = if has_head(&(v385_3)) { singleton(&[]) } else { Space::new() };
        drop(v385_3);
        let v385_5: Space = subtract(&(*CONSTANT_0),&(v385_4));
        drop(v385_4);
        let v385_8: Space = if (v385_5).is_empty() { Space::new() } else {
          let v386_6: Path = concat_path(&(v384_6),&(v384_7_head));
          let v386_7: Space = routine_74(c, &(v386_6), &(*p1), &(v384_7_tail), &(*s1));
          compose(&(v385_5),&(v386_7))
        };
        drop(v385_5);
        let v385_9: Space = intersect(&(*CONSTANT_14),&(v385_2));
        drop(v385_2);
        let v385_10: Space = if has_head(&(v385_9)) { singleton(&[]) } else { Space::new() };
        drop(v385_9);
        let v385_12: Space = if (v385_10).is_empty() { Space::new() } else {
          let v387_6: Path = concat_path(&(v384_6),&(v384_7_head));
          let v387_11: Space = routine_75(c, &(v387_6), &(*p1), &(v384_7_tail), &(*s1));
          drop(v387_6);
          compose(&(v385_10),&(v387_11))
        };
        drop(v385_10);
        let v385_13: Space = unite(&(v385_8),&(v385_12));
        v384_7.join_into((v385_13).clone());
      }
      drop(v384_7_cursor);
      drop(v384_6);
      compose(&(v383_5),&(v384_7))
    };
    drop(v383_5);
    let v383_9: Space = intersect(&(*CONSTANT_14),&(v383_2));
    drop(v383_2);
    let v383_10: Space = if has_head(&(v383_9)) { singleton(&[]) } else { Space::new() };
    drop(v383_9);
    let v383_13: Space = if (v383_10).is_empty() { Space::new() } else {
      let v388_11: Space = unwrap(&(v382_11),&(v382_18_head));
      let mut v388_12 = Space::new();
      let mut v388_12_cursor = (v388_11).read_zipper();
      for v388_12_byte in v388_12_cursor.child_mask().iter() {
        v388_12_cursor.descend_to_byte(v388_12_byte);
        let v388_12_tail = v388_12_cursor.make_map();
        v388_12_cursor.ascend(1);
        let v388_12_head = Path::from_slice(&[v388_12_byte]);
        let v389_2: Space = singleton(&(v388_12_head));
        let v389_3: Space = intersect(&(*CONSTANT_14),&(v389_2));
        let v389_4: Space = if has_head(&(v389_3)) { singleton(&[]) } else { Space::new() };
        drop(v389_3);
        let v389_5: Space = subtract(&(*CONSTANT_0),&(v389_4));
        drop(v389_4);
        let v389_7: Space = if (v389_5).is_empty() { Space::new() } else {
          let v390_6: Space = routine_76(c, &(v388_12_head), &(*p1), &(v388_12_tail));
          compose(&(v389_5),&(v390_6))
        };
        drop(v389_5);
        let v389_8: Space = intersect(&(*CONSTANT_14),&(v389_2));
        drop(v389_2);
        let v389_9: Space = if has_head(&(v389_8)) { singleton(&[]) } else { Space::new() };
        drop(v389_8);
        let v389_11: Space = if (v389_9).is_empty() { Space::new() } else {
          let v391_10: Space = routine_77(c, &(v388_12_head), &(*p1), &(v388_12_tail));
          compose(&(v389_9),&(v391_10))
        };
        drop(v389_9);
        let v389_12: Space = unite(&(v389_7),&(v389_11));
        v388_12.join_into((v389_12).clone());
      }
      drop(v388_12_cursor);
      drop(v388_11);
      compose(&(v383_10),&(v388_12))
    };
    drop(v383_10);
    let v383_14: Space = unite(&(v383_8),&(v383_13));
    v382_18.join_into((v383_14).clone());
  }
  drop(v382_18_cursor);
  drop(v382_11);
  (v382_18).clone()
}

fn routine_38(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v392_13 = Space::new();
  let mut v392_13_cursor = (*s0).read_zipper();
  for v392_13_byte in v392_13_cursor.child_mask().iter() {
    v392_13_cursor.descend_to_byte(v392_13_byte);
    let v392_13_tail = v392_13_cursor.make_map();
    v392_13_cursor.ascend(1);
    let v392_13_head = Path::from_slice(&[v392_13_byte]);
    let v393_2: Space = singleton(&(v392_13_head));
    let v393_3: Space = intersect(&(*CONSTANT_14),&(v393_2));
    let v393_4: Space = if has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
    drop(v393_3);
    let v393_5: Space = subtract(&(*CONSTANT_0),&(v393_4));
    drop(v393_4);
    let v393_8: Space = if (v393_5).is_empty() { Space::new() } else {
      let v394_6: Path = concat_path(&(*p0),&(v392_13_head));
      let mut v394_7 = Space::new();
      let mut v394_7_cursor = (v392_13_tail).read_zipper();
      for v394_7_byte in v394_7_cursor.child_mask().iter() {
        v394_7_cursor.descend_to_byte(v394_7_byte);
        let v394_7_tail = v394_7_cursor.make_map();
        v394_7_cursor.ascend(1);
        let v394_7_head = Path::from_slice(&[v394_7_byte]);
        let v395_2: Space = singleton(&(v394_7_head));
        let v395_3: Space = intersect(&(*CONSTANT_14),&(v395_2));
        let v395_4: Space = if has_head(&(v395_3)) { singleton(&[]) } else { Space::new() };
        drop(v395_3);
        let v395_5: Space = subtract(&(*CONSTANT_0),&(v395_4));
        drop(v395_4);
        let v395_8: Space = if (v395_5).is_empty() { Space::new() } else {
          let v396_6: Path = concat_path(&(v394_6),&(v394_7_head));
          let v396_7: Space = routine_78(c, &(v396_6), &(*p1), &(v394_7_tail), &(*s1));
          compose(&(v395_5),&(v396_7))
        };
        drop(v395_5);
        let v395_9: Space = intersect(&(*CONSTANT_14),&(v395_2));
        drop(v395_2);
        let v395_10: Space = if has_head(&(v395_9)) { singleton(&[]) } else { Space::new() };
        drop(v395_9);
        let v395_12: Space = if (v395_10).is_empty() { Space::new() } else {
          let v397_6: Path = concat_path(&(v394_6),&(v394_7_head));
          let v397_11: Space = routine_79(c, &(v397_6), &(*p1), &(v394_7_tail), &(*s1));
          drop(v397_6);
          compose(&(v395_10),&(v397_11))
        };
        drop(v395_10);
        let v395_13: Space = unite(&(v395_8),&(v395_12));
        v394_7.join_into((v395_13).clone());
      }
      drop(v394_7_cursor);
      compose(&(v393_5),&(v394_7))
    };
    drop(v393_5);
    let v393_9: Space = intersect(&(*CONSTANT_14),&(v393_2));
    drop(v393_2);
    let v393_10: Space = if has_head(&(v393_9)) { singleton(&[]) } else { Space::new() };
    drop(v393_9);
    let v393_12: Space = if (v393_10).is_empty() { Space::new() } else {
      let v398_6: Path = concat_path(&(*p0),&(v392_13_head));
      let mut v398_11 = Space::new();
      let mut v398_11_cursor = (v392_13_tail).read_zipper();
      for v398_11_byte in v398_11_cursor.child_mask().iter() {
        v398_11_cursor.descend_to_byte(v398_11_byte);
        let v398_11_tail = v398_11_cursor.make_map();
        v398_11_cursor.ascend(1);
        let v398_11_head = Path::from_slice(&[v398_11_byte]);
        let v399_2: Space = singleton(&(v398_11_head));
        let v399_3: Space = intersect(&(*CONSTANT_14),&(v399_2));
        let v399_4: Space = if has_head(&(v399_3)) { singleton(&[]) } else { Space::new() };
        drop(v399_3);
        let v399_5: Space = subtract(&(*CONSTANT_0),&(v399_4));
        drop(v399_4);
        let v399_8: Space = if (v399_5).is_empty() { Space::new() } else {
          let v400_6: Path = concat_path(&(v398_6),&(v398_11_head));
          let v400_7: Space = routine_78(c, &(v400_6), &(*p1), &(v398_11_tail), &(*s1));
          compose(&(v399_5),&(v400_7))
        };
        drop(v399_5);
        let v399_9: Space = intersect(&(*CONSTANT_14),&(v399_2));
        drop(v399_2);
        let v399_10: Space = if has_head(&(v399_9)) { singleton(&[]) } else { Space::new() };
        drop(v399_9);
        let v399_12: Space = if (v399_10).is_empty() { Space::new() } else {
          let v401_6: Path = concat_path(&(v398_6),&(v398_11_head));
          let v401_11: Space = routine_40(c, &(v401_6), &(*p1), &(v398_11_tail), &(*s1));
          drop(v401_6);
          compose(&(v399_10),&(v401_11))
        };
        drop(v399_10);
        let v399_13: Space = unite(&(v399_8),&(v399_12));
        v398_11.join_into((v399_13).clone());
      }
      drop(v398_11_cursor);
      drop(v398_6);
      compose(&(v393_10),&(v398_11))
    };
    drop(v393_10);
    let v393_13: Space = unite(&(v393_8),&(v393_12));
    v392_13.join_into((v393_13).clone());
  }
  drop(v392_13_cursor);
  (v392_13).clone()
}

fn routine_39(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v402_8: Space = unwrap(&(*s1),&(*CONSTANT_9));
  let v402_10: Space = unwrap(&(v402_8),&(*CONSTANT_10));
  drop(v402_8);
  let v402_11: Space = unwrap(&(v402_10),&(*p0));
  drop(v402_10);
  let mut v402_18 = Space::new();
  let mut v402_18_cursor = (*s0).read_zipper();
  for v402_18_byte in v402_18_cursor.child_mask().iter() {
    v402_18_cursor.descend_to_byte(v402_18_byte);
    let v402_18_tail = v402_18_cursor.make_map();
    v402_18_cursor.ascend(1);
    let v402_18_head = Path::from_slice(&[v402_18_byte]);
    let v403_2: Space = singleton(&(v402_18_head));
    let v403_3: Space = intersect(&(*CONSTANT_14),&(v403_2));
    let v403_4: Space = if has_head(&(v403_3)) { singleton(&[]) } else { Space::new() };
    drop(v403_3);
    let v403_5: Space = subtract(&(*CONSTANT_0),&(v403_4));
    drop(v403_4);
    let v403_8: Space = if (v403_5).is_empty() { Space::new() } else {
      let v404_6: Path = concat_path(&(*p0),&(v402_18_head));
      let mut v404_7 = Space::new();
      let mut v404_7_cursor = (v402_18_tail).read_zipper();
      for v404_7_byte in v404_7_cursor.child_mask().iter() {
        v404_7_cursor.descend_to_byte(v404_7_byte);
        let v404_7_tail = v404_7_cursor.make_map();
        v404_7_cursor.ascend(1);
        let v404_7_head = Path::from_slice(&[v404_7_byte]);
        let v405_2: Space = singleton(&(v404_7_head));
        let v405_3: Space = intersect(&(*CONSTANT_14),&(v405_2));
        let v405_4: Space = if has_head(&(v405_3)) { singleton(&[]) } else { Space::new() };
        drop(v405_3);
        let v405_5: Space = subtract(&(*CONSTANT_0),&(v405_4));
        drop(v405_4);
        let v405_8: Space = if (v405_5).is_empty() { Space::new() } else {
          let v406_6: Path = concat_path(&(v404_6),&(v404_7_head));
          let v406_7: Space = routine_78(c, &(v406_6), &(*p1), &(v404_7_tail), &(*s1));
          compose(&(v405_5),&(v406_7))
        };
        drop(v405_5);
        let v405_9: Space = intersect(&(*CONSTANT_14),&(v405_2));
        drop(v405_2);
        let v405_10: Space = if has_head(&(v405_9)) { singleton(&[]) } else { Space::new() };
        drop(v405_9);
        let v405_12: Space = if (v405_10).is_empty() { Space::new() } else {
          let v407_6: Path = concat_path(&(v404_6),&(v404_7_head));
          let v407_11: Space = routine_79(c, &(v407_6), &(*p1), &(v404_7_tail), &(*s1));
          drop(v407_6);
          compose(&(v405_10),&(v407_11))
        };
        drop(v405_10);
        let v405_13: Space = unite(&(v405_8),&(v405_12));
        v404_7.join_into((v405_13).clone());
      }
      drop(v404_7_cursor);
      drop(v404_6);
      compose(&(v403_5),&(v404_7))
    };
    drop(v403_5);
    let v403_9: Space = intersect(&(*CONSTANT_14),&(v403_2));
    drop(v403_2);
    let v403_10: Space = if has_head(&(v403_9)) { singleton(&[]) } else { Space::new() };
    drop(v403_9);
    let v403_13: Space = if (v403_10).is_empty() { Space::new() } else {
      let v408_11: Space = unwrap(&(v402_11),&(v402_18_head));
      let mut v408_12 = Space::new();
      let mut v408_12_cursor = (v408_11).read_zipper();
      for v408_12_byte in v408_12_cursor.child_mask().iter() {
        v408_12_cursor.descend_to_byte(v408_12_byte);
        let v408_12_tail = v408_12_cursor.make_map();
        v408_12_cursor.ascend(1);
        let v408_12_head = Path::from_slice(&[v408_12_byte]);
        let v409_2: Space = singleton(&(v408_12_head));
        let v409_3: Space = intersect(&(*CONSTANT_14),&(v409_2));
        let v409_4: Space = if has_head(&(v409_3)) { singleton(&[]) } else { Space::new() };
        drop(v409_3);
        let v409_5: Space = subtract(&(*CONSTANT_0),&(v409_4));
        drop(v409_4);
        let v409_7: Space = if (v409_5).is_empty() { Space::new() } else {
          let v410_6: Space = routine_76(c, &(v408_12_head), &(*p1), &(v408_12_tail));
          compose(&(v409_5),&(v410_6))
        };
        drop(v409_5);
        let v409_8: Space = intersect(&(*CONSTANT_14),&(v409_2));
        drop(v409_2);
        let v409_9: Space = if has_head(&(v409_8)) { singleton(&[]) } else { Space::new() };
        drop(v409_8);
        let v409_11: Space = if (v409_9).is_empty() { Space::new() } else {
          let v411_10: Space = routine_77(c, &(v408_12_head), &(*p1), &(v408_12_tail));
          compose(&(v409_9),&(v411_10))
        };
        drop(v409_9);
        let v409_12: Space = unite(&(v409_7),&(v409_11));
        v408_12.join_into((v409_12).clone());
      }
      drop(v408_12_cursor);
      drop(v408_11);
      compose(&(v403_10),&(v408_12))
    };
    drop(v403_10);
    let v403_14: Space = unite(&(v403_8),&(v403_13));
    v402_18.join_into((v403_14).clone());
  }
  drop(v402_18_cursor);
  drop(v402_11);
  (v402_18).clone()
}

fn routine_40(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v412_5: Space = unwrap(&(*s1),&(*CONSTANT_9));
  let v412_7: Space = unwrap(&(v412_5),&(*CONSTANT_10));
  drop(v412_5);
  let v412_8: Space = unwrap(&(v412_7),&(*p0));
  drop(v412_7);
  let mut v412_18 = Space::new();
  let mut v412_18_cursor = (v412_8).read_zipper();
  for v412_18_byte in v412_18_cursor.child_mask().iter() {
    v412_18_cursor.descend_to_byte(v412_18_byte);
    let v412_18_tail = v412_18_cursor.make_map();
    v412_18_cursor.ascend(1);
    let v412_18_head = Path::from_slice(&[v412_18_byte]);
    let v413_2: Space = singleton(&(v412_18_head));
    let v413_3: Space = intersect(&(*CONSTANT_14),&(v413_2));
    let v413_4: Space = if has_head(&(v413_3)) { singleton(&[]) } else { Space::new() };
    drop(v413_3);
    let v413_5: Space = subtract(&(*CONSTANT_0),&(v413_4));
    drop(v413_4);
    let v413_7: Space = if (v413_5).is_empty() { Space::new() } else {
      let mut v414_6 = Space::new();
      let mut v414_6_cursor = (v412_18_tail).read_zipper();
      for v414_6_byte in v414_6_cursor.child_mask().iter() {
        v414_6_cursor.descend_to_byte(v414_6_byte);
        let v414_6_tail = v414_6_cursor.make_map();
        v414_6_cursor.ascend(1);
        let v414_6_head = Path::from_slice(&[v414_6_byte]);
        let v415_2: Space = singleton(&(v414_6_head));
        let v415_3: Space = intersect(&(*CONSTANT_14),&(v415_2));
        let v415_4: Space = if has_head(&(v415_3)) { singleton(&[]) } else { Space::new() };
        drop(v415_3);
        let v415_5: Space = subtract(&(*CONSTANT_0),&(v415_4));
        drop(v415_4);
        let v415_8: Space = if (v415_5).is_empty() { Space::new() } else {
          let v416_6: Path = concat_path(&(v412_18_head),&(v414_6_head));
          let v416_7: Space = routine_80(c, &(v416_6), &(*p1), &(v414_6_tail));
          compose(&(v415_5),&(v416_7))
        };
        drop(v415_5);
        let v415_9: Space = intersect(&(*CONSTANT_14),&(v415_2));
        drop(v415_2);
        let v415_10: Space = if has_head(&(v415_9)) { singleton(&[]) } else { Space::new() };
        drop(v415_9);
        let v415_12: Space = if (v415_10).is_empty() { Space::new() } else {
          let v417_6: Path = concat_path(&(v412_18_head),&(v414_6_head));
          let v417_11: Space = routine_81(c, &(v417_6), &(*p1), &(v414_6_tail));
          drop(v417_6);
          compose(&(v415_10),&(v417_11))
        };
        drop(v415_10);
        let v415_13: Space = unite(&(v415_8),&(v415_12));
        v414_6.join_into((v415_13).clone());
      }
      drop(v414_6_cursor);
      compose(&(v413_5),&(v414_6))
    };
    drop(v413_5);
    let v413_8: Space = intersect(&(*CONSTANT_14),&(v413_2));
    drop(v413_2);
    let v413_9: Space = if has_head(&(v413_8)) { singleton(&[]) } else { Space::new() };
    drop(v413_8);
    let v413_11: Space = if (v413_9).is_empty() { Space::new() } else {
      let mut v418_10 = Space::new();
      let mut v418_10_cursor = (v412_18_tail).read_zipper();
      for v418_10_byte in v418_10_cursor.child_mask().iter() {
        v418_10_cursor.descend_to_byte(v418_10_byte);
        let v418_10_tail = v418_10_cursor.make_map();
        v418_10_cursor.ascend(1);
        let v418_10_head = Path::from_slice(&[v418_10_byte]);
        let v419_2: Space = singleton(&(v418_10_head));
        let v419_3: Space = intersect(&(*CONSTANT_14),&(v419_2));
        let v419_4: Space = if has_head(&(v419_3)) { singleton(&[]) } else { Space::new() };
        drop(v419_3);
        let v419_5: Space = subtract(&(*CONSTANT_0),&(v419_4));
        drop(v419_4);
        let v419_8: Space = if (v419_5).is_empty() { Space::new() } else {
          let v420_6: Path = concat_path(&(v412_18_head),&(v418_10_head));
          let v420_7: Space = routine_80(c, &(v420_6), &(*p1), &(v418_10_tail));
          compose(&(v419_5),&(v420_7))
        };
        drop(v419_5);
        let v419_9: Space = intersect(&(*CONSTANT_14),&(v419_2));
        drop(v419_2);
        let v419_10: Space = if has_head(&(v419_9)) { singleton(&[]) } else { Space::new() };
        drop(v419_9);
        let v419_12: Space = if (v419_10).is_empty() { Space::new() } else {
          let v421_6: Path = concat_path(&(v412_18_head),&(v418_10_head));
          let v421_11: Space = routine_82(c, &(v421_6), &(*p1), &(v418_10_tail));
          drop(v421_6);
          compose(&(v419_10),&(v421_11))
        };
        drop(v419_10);
        let v419_13: Space = unite(&(v419_8),&(v419_12));
        v418_10.join_into((v419_13).clone());
      }
      drop(v418_10_cursor);
      compose(&(v413_9),&(v418_10))
    };
    drop(v413_9);
    let v413_12: Space = unite(&(v413_7),&(v413_11));
    v412_18.join_into((v413_12).clone());
  }
  drop(v412_18_cursor);
  drop(v412_8);
  (v412_18).clone()
}

fn routine_41(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v422_12 = Space::new();
  let mut v422_12_cursor = (*s0).read_zipper();
  for v422_12_byte in v422_12_cursor.child_mask().iter() {
    v422_12_cursor.descend_to_byte(v422_12_byte);
    let v422_12_tail = v422_12_cursor.make_map();
    v422_12_cursor.ascend(1);
    let v422_12_head = Path::from_slice(&[v422_12_byte]);
    let v423_2: Space = singleton(&(v422_12_head));
    let v423_3: Space = intersect(&(*CONSTANT_14),&(v423_2));
    let v423_4: Space = if has_head(&(v423_3)) { singleton(&[]) } else { Space::new() };
    drop(v423_3);
    let v423_5: Space = subtract(&(*CONSTANT_0),&(v423_4));
    drop(v423_4);
    let v423_8: Space = if (v423_5).is_empty() { Space::new() } else {
      let v424_6: Path = concat_path(&(*p0),&(v422_12_head));
      let mut v424_7 = Space::new();
      let mut v424_7_cursor = (v422_12_tail).read_zipper();
      for v424_7_byte in v424_7_cursor.child_mask().iter() {
        v424_7_cursor.descend_to_byte(v424_7_byte);
        let v424_7_tail = v424_7_cursor.make_map();
        v424_7_cursor.ascend(1);
        let v424_7_head = Path::from_slice(&[v424_7_byte]);
        let v425_2: Space = singleton(&(v424_7_head));
        let v425_3: Space = intersect(&(*CONSTANT_14),&(v425_2));
        let v425_4: Space = if has_head(&(v425_3)) { singleton(&[]) } else { Space::new() };
        drop(v425_3);
        let v425_5: Space = subtract(&(*CONSTANT_0),&(v425_4));
        drop(v425_4);
        let v425_8: Space = if (v425_5).is_empty() { Space::new() } else {
          let v426_6: Path = concat_path(&(v424_6),&(v424_7_head));
          let v426_7: Space = routine_83(c, &(v426_6), &(v424_7_tail), &(*s1));
          compose(&(v425_5),&(v426_7))
        };
        drop(v425_5);
        let v425_9: Space = intersect(&(*CONSTANT_14),&(v425_2));
        drop(v425_2);
        let v425_10: Space = if has_head(&(v425_9)) { singleton(&[]) } else { Space::new() };
        drop(v425_9);
        let v425_12: Space = if (v425_10).is_empty() { Space::new() } else {
          let v427_6: Path = concat_path(&(v424_6),&(v424_7_head));
          let v427_11: Space = routine_84(c, &(v427_6), &(v424_7_tail), &(*s1));
          drop(v427_6);
          compose(&(v425_10),&(v427_11))
        };
        drop(v425_10);
        let v425_13: Space = unite(&(v425_8),&(v425_12));
        v424_7.join_into((v425_13).clone());
      }
      drop(v424_7_cursor);
      compose(&(v423_5),&(v424_7))
    };
    drop(v423_5);
    let v423_9: Space = intersect(&(*CONSTANT_14),&(v423_2));
    drop(v423_2);
    let v423_10: Space = if has_head(&(v423_9)) { singleton(&[]) } else { Space::new() };
    drop(v423_9);
    let v423_12: Space = if (v423_10).is_empty() { Space::new() } else {
      let v428_6: Path = concat_path(&(*p0),&(v422_12_head));
      let mut v428_11 = Space::new();
      let mut v428_11_cursor = (v422_12_tail).read_zipper();
      for v428_11_byte in v428_11_cursor.child_mask().iter() {
        v428_11_cursor.descend_to_byte(v428_11_byte);
        let v428_11_tail = v428_11_cursor.make_map();
        v428_11_cursor.ascend(1);
        let v428_11_head = Path::from_slice(&[v428_11_byte]);
        let v429_2: Space = singleton(&(v428_11_head));
        let v429_3: Space = intersect(&(*CONSTANT_14),&(v429_2));
        let v429_4: Space = if has_head(&(v429_3)) { singleton(&[]) } else { Space::new() };
        drop(v429_3);
        let v429_5: Space = subtract(&(*CONSTANT_0),&(v429_4));
        drop(v429_4);
        let v429_8: Space = if (v429_5).is_empty() { Space::new() } else {
          let v430_6: Path = concat_path(&(v428_6),&(v428_11_head));
          let v430_7: Space = routine_83(c, &(v430_6), &(v428_11_tail), &(*s1));
          compose(&(v429_5),&(v430_7))
        };
        drop(v429_5);
        let v429_9: Space = intersect(&(*CONSTANT_14),&(v429_2));
        drop(v429_2);
        let v429_10: Space = if has_head(&(v429_9)) { singleton(&[]) } else { Space::new() };
        drop(v429_9);
        let v429_12: Space = if (v429_10).is_empty() { Space::new() } else {
          let v431_6: Path = concat_path(&(v428_6),&(v428_11_head));
          let v431_11: Space = routine_14(c, &(v431_6), &(v428_11_tail), &(*s1));
          drop(v431_6);
          compose(&(v429_10),&(v431_11))
        };
        drop(v429_10);
        let v429_13: Space = unite(&(v429_8),&(v429_12));
        v428_11.join_into((v429_13).clone());
      }
      drop(v428_11_cursor);
      drop(v428_6);
      compose(&(v423_10),&(v428_11))
    };
    drop(v423_10);
    let v423_13: Space = unite(&(v423_8),&(v423_12));
    v422_12.join_into((v423_13).clone());
  }
  drop(v422_12_cursor);
  (v422_12).clone()
}

fn routine_42(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v432_12 = Space::new();
  let mut v432_12_cursor = (*s0).read_zipper();
  for v432_12_byte in v432_12_cursor.child_mask().iter() {
    v432_12_cursor.descend_to_byte(v432_12_byte);
    let v432_12_tail = v432_12_cursor.make_map();
    v432_12_cursor.ascend(1);
    let v432_12_head = Path::from_slice(&[v432_12_byte]);
    let v433_2: Space = singleton(&(v432_12_head));
    let v433_3: Space = intersect(&(*CONSTANT_14),&(v433_2));
    let v433_4: Space = if has_head(&(v433_3)) { singleton(&[]) } else { Space::new() };
    drop(v433_3);
    let v433_5: Space = subtract(&(*CONSTANT_0),&(v433_4));
    drop(v433_4);
    let v433_8: Space = if (v433_5).is_empty() { Space::new() } else {
      let v434_6: Path = concat_path(&(*p0),&(v432_12_head));
      let mut v434_7 = Space::new();
      let mut v434_7_cursor = (v432_12_tail).read_zipper();
      for v434_7_byte in v434_7_cursor.child_mask().iter() {
        v434_7_cursor.descend_to_byte(v434_7_byte);
        let v434_7_tail = v434_7_cursor.make_map();
        v434_7_cursor.ascend(1);
        let v434_7_head = Path::from_slice(&[v434_7_byte]);
        let v435_2: Space = singleton(&(v434_7_head));
        let v435_3: Space = intersect(&(*CONSTANT_14),&(v435_2));
        let v435_4: Space = if has_head(&(v435_3)) { singleton(&[]) } else { Space::new() };
        drop(v435_3);
        let v435_5: Space = subtract(&(*CONSTANT_0),&(v435_4));
        drop(v435_4);
        let v435_8: Space = if (v435_5).is_empty() { Space::new() } else {
          let v436_6: Path = concat_path(&(v434_6),&(v434_7_head));
          let v436_7: Space = routine_83(c, &(v436_6), &(v434_7_tail), &(*s1));
          compose(&(v435_5),&(v436_7))
        };
        drop(v435_5);
        let v435_9: Space = intersect(&(*CONSTANT_14),&(v435_2));
        drop(v435_2);
        let v435_10: Space = if has_head(&(v435_9)) { singleton(&[]) } else { Space::new() };
        drop(v435_9);
        let v435_12: Space = if (v435_10).is_empty() { Space::new() } else {
          let v437_6: Path = concat_path(&(v434_6),&(v434_7_head));
          let v437_11: Space = routine_84(c, &(v437_6), &(v434_7_tail), &(*s1));
          drop(v437_6);
          compose(&(v435_10),&(v437_11))
        };
        drop(v435_10);
        let v435_13: Space = unite(&(v435_8),&(v435_12));
        v434_7.join_into((v435_13).clone());
      }
      drop(v434_7_cursor);
      compose(&(v433_5),&(v434_7))
    };
    drop(v433_5);
    let v433_9: Space = intersect(&(*CONSTANT_14),&(v433_2));
    drop(v433_2);
    let v433_10: Space = if has_head(&(v433_9)) { singleton(&[]) } else { Space::new() };
    drop(v433_9);
    let v433_12: Space = if (v433_10).is_empty() { Space::new() } else {
      let v438_6: Path = concat_path(&(*p0),&(v432_12_head));
      let mut v438_11 = Space::new();
      let mut v438_11_cursor = (v432_12_tail).read_zipper();
      for v438_11_byte in v438_11_cursor.child_mask().iter() {
        v438_11_cursor.descend_to_byte(v438_11_byte);
        let v438_11_tail = v438_11_cursor.make_map();
        v438_11_cursor.ascend(1);
        let v438_11_head = Path::from_slice(&[v438_11_byte]);
        let v439_2: Space = singleton(&(v438_11_head));
        let v439_3: Space = intersect(&(*CONSTANT_14),&(v439_2));
        let v439_4: Space = if has_head(&(v439_3)) { singleton(&[]) } else { Space::new() };
        drop(v439_3);
        let v439_5: Space = subtract(&(*CONSTANT_0),&(v439_4));
        drop(v439_4);
        let v439_7: Space = if (v439_5).is_empty() { Space::new() } else {
          let v440_6: Space = routine_43(c, &(v438_11_head), &(v438_6), &(v438_11_tail), &(*s1));
          compose(&(v439_5),&(v440_6))
        };
        drop(v439_5);
        let v439_8: Space = intersect(&(*CONSTANT_14),&(v439_2));
        drop(v439_2);
        let v439_9: Space = if has_head(&(v439_8)) { singleton(&[]) } else { Space::new() };
        drop(v439_8);
        let v439_11: Space = if (v439_9).is_empty() { Space::new() } else {
          let v441_10: Space = routine_44(c, &(v438_11_head), &(v438_6), &(v438_11_tail), &(*s1));
          compose(&(v439_9),&(v441_10))
        };
        drop(v439_9);
        let v439_12: Space = unite(&(v439_7),&(v439_11));
        v438_11.join_into((v439_12).clone());
      }
      drop(v438_11_cursor);
      drop(v438_6);
      compose(&(v433_10),&(v438_11))
    };
    drop(v433_10);
    let v433_13: Space = unite(&(v433_8),&(v433_12));
    v432_12.join_into((v433_13).clone());
  }
  drop(v432_12_cursor);
  (v432_12).clone()
}

fn routine_43(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v442_13 = Space::new();
  let mut v442_13_cursor = (*s0).read_zipper();
  for v442_13_byte in v442_13_cursor.child_mask().iter() {
    v442_13_cursor.descend_to_byte(v442_13_byte);
    let v442_13_tail = v442_13_cursor.make_map();
    v442_13_cursor.ascend(1);
    let v442_13_head = Path::from_slice(&[v442_13_byte]);
    let v443_2: Space = singleton(&(v442_13_head));
    let v443_3: Space = intersect(&(*CONSTANT_14),&(v443_2));
    let v443_4: Space = if has_head(&(v443_3)) { singleton(&[]) } else { Space::new() };
    drop(v443_3);
    let v443_5: Space = subtract(&(*CONSTANT_0),&(v443_4));
    drop(v443_4);
    let v443_8: Space = if (v443_5).is_empty() { Space::new() } else {
      let v444_6: Path = concat_path(&(*p0),&(v442_13_head));
      let mut v444_7 = Space::new();
      let mut v444_7_cursor = (v442_13_tail).read_zipper();
      for v444_7_byte in v444_7_cursor.child_mask().iter() {
        v444_7_cursor.descend_to_byte(v444_7_byte);
        let v444_7_tail = v444_7_cursor.make_map();
        v444_7_cursor.ascend(1);
        let v444_7_head = Path::from_slice(&[v444_7_byte]);
        let v445_2: Space = singleton(&(v444_7_head));
        let v445_3: Space = intersect(&(*CONSTANT_14),&(v445_2));
        let v445_4: Space = if has_head(&(v445_3)) { singleton(&[]) } else { Space::new() };
        drop(v445_3);
        let v445_5: Space = subtract(&(*CONSTANT_0),&(v445_4));
        drop(v445_4);
        let v445_8: Space = if (v445_5).is_empty() { Space::new() } else {
          let v446_6: Path = concat_path(&(v444_6),&(v444_7_head));
          let v446_7: Space = routine_85(c, &(v446_6), &(*p1), &(v444_7_tail), &(*s1));
          compose(&(v445_5),&(v446_7))
        };
        drop(v445_5);
        let v445_9: Space = intersect(&(*CONSTANT_14),&(v445_2));
        drop(v445_2);
        let v445_10: Space = if has_head(&(v445_9)) { singleton(&[]) } else { Space::new() };
        drop(v445_9);
        let v445_12: Space = if (v445_10).is_empty() { Space::new() } else {
          let v447_6: Path = concat_path(&(v444_6),&(v444_7_head));
          let v447_11: Space = routine_86(c, &(v447_6), &(*p1), &(v444_7_tail), &(*s1));
          drop(v447_6);
          compose(&(v445_10),&(v447_11))
        };
        drop(v445_10);
        let v445_13: Space = unite(&(v445_8),&(v445_12));
        v444_7.join_into((v445_13).clone());
      }
      drop(v444_7_cursor);
      compose(&(v443_5),&(v444_7))
    };
    drop(v443_5);
    let v443_9: Space = intersect(&(*CONSTANT_14),&(v443_2));
    drop(v443_2);
    let v443_10: Space = if has_head(&(v443_9)) { singleton(&[]) } else { Space::new() };
    drop(v443_9);
    let v443_12: Space = if (v443_10).is_empty() { Space::new() } else {
      let v448_6: Path = concat_path(&(*p0),&(v442_13_head));
      let mut v448_11 = Space::new();
      let mut v448_11_cursor = (v442_13_tail).read_zipper();
      for v448_11_byte in v448_11_cursor.child_mask().iter() {
        v448_11_cursor.descend_to_byte(v448_11_byte);
        let v448_11_tail = v448_11_cursor.make_map();
        v448_11_cursor.ascend(1);
        let v448_11_head = Path::from_slice(&[v448_11_byte]);
        let v449_2: Space = singleton(&(v448_11_head));
        let v449_3: Space = intersect(&(*CONSTANT_14),&(v449_2));
        let v449_4: Space = if has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
        drop(v449_3);
        let v449_5: Space = subtract(&(*CONSTANT_0),&(v449_4));
        drop(v449_4);
        let v449_8: Space = if (v449_5).is_empty() { Space::new() } else {
          let v450_6: Path = concat_path(&(v448_6),&(v448_11_head));
          let v450_7: Space = routine_85(c, &(v450_6), &(*p1), &(v448_11_tail), &(*s1));
          compose(&(v449_5),&(v450_7))
        };
        drop(v449_5);
        let v449_9: Space = intersect(&(*CONSTANT_14),&(v449_2));
        drop(v449_2);
        let v449_10: Space = if has_head(&(v449_9)) { singleton(&[]) } else { Space::new() };
        drop(v449_9);
        let v449_12: Space = if (v449_10).is_empty() { Space::new() } else {
          let v451_6: Path = concat_path(&(v448_6),&(v448_11_head));
          let v451_11: Space = routine_47(c, &(v451_6), &(*p1), &(v448_11_tail), &(*s1));
          drop(v451_6);
          compose(&(v449_10),&(v451_11))
        };
        drop(v449_10);
        let v449_13: Space = unite(&(v449_8),&(v449_12));
        v448_11.join_into((v449_13).clone());
      }
      drop(v448_11_cursor);
      drop(v448_6);
      compose(&(v443_10),&(v448_11))
    };
    drop(v443_10);
    let v443_13: Space = unite(&(v443_8),&(v443_12));
    v442_13.join_into((v443_13).clone());
  }
  drop(v442_13_cursor);
  (v442_13).clone()
}

fn routine_44(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v452_8: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v452_10: Space = unwrap(&(v452_8),&(*CONSTANT_10));
  drop(v452_8);
  let v452_11: Space = unwrap(&(v452_10),&(*p0));
  drop(v452_10);
  let mut v452_18 = Space::new();
  let mut v452_18_cursor = (*s0).read_zipper();
  for v452_18_byte in v452_18_cursor.child_mask().iter() {
    v452_18_cursor.descend_to_byte(v452_18_byte);
    let v452_18_tail = v452_18_cursor.make_map();
    v452_18_cursor.ascend(1);
    let v452_18_head = Path::from_slice(&[v452_18_byte]);
    let v453_2: Space = singleton(&(v452_18_head));
    let v453_3: Space = intersect(&(*CONSTANT_14),&(v453_2));
    let v453_4: Space = if has_head(&(v453_3)) { singleton(&[]) } else { Space::new() };
    drop(v453_3);
    let v453_5: Space = subtract(&(*CONSTANT_0),&(v453_4));
    drop(v453_4);
    let v453_8: Space = if (v453_5).is_empty() { Space::new() } else {
      let v454_6: Path = concat_path(&(*p0),&(v452_18_head));
      let mut v454_7 = Space::new();
      let mut v454_7_cursor = (v452_18_tail).read_zipper();
      for v454_7_byte in v454_7_cursor.child_mask().iter() {
        v454_7_cursor.descend_to_byte(v454_7_byte);
        let v454_7_tail = v454_7_cursor.make_map();
        v454_7_cursor.ascend(1);
        let v454_7_head = Path::from_slice(&[v454_7_byte]);
        let v455_2: Space = singleton(&(v454_7_head));
        let v455_3: Space = intersect(&(*CONSTANT_14),&(v455_2));
        let v455_4: Space = if has_head(&(v455_3)) { singleton(&[]) } else { Space::new() };
        drop(v455_3);
        let v455_5: Space = subtract(&(*CONSTANT_0),&(v455_4));
        drop(v455_4);
        let v455_8: Space = if (v455_5).is_empty() { Space::new() } else {
          let v456_6: Path = concat_path(&(v454_6),&(v454_7_head));
          let v456_7: Space = routine_85(c, &(v456_6), &(*p1), &(v454_7_tail), &(*s1));
          compose(&(v455_5),&(v456_7))
        };
        drop(v455_5);
        let v455_9: Space = intersect(&(*CONSTANT_14),&(v455_2));
        drop(v455_2);
        let v455_10: Space = if has_head(&(v455_9)) { singleton(&[]) } else { Space::new() };
        drop(v455_9);
        let v455_12: Space = if (v455_10).is_empty() { Space::new() } else {
          let v457_6: Path = concat_path(&(v454_6),&(v454_7_head));
          let v457_11: Space = routine_86(c, &(v457_6), &(*p1), &(v454_7_tail), &(*s1));
          drop(v457_6);
          compose(&(v455_10),&(v457_11))
        };
        drop(v455_10);
        let v455_13: Space = unite(&(v455_8),&(v455_12));
        v454_7.join_into((v455_13).clone());
      }
      drop(v454_7_cursor);
      drop(v454_6);
      compose(&(v453_5),&(v454_7))
    };
    drop(v453_5);
    let v453_9: Space = intersect(&(*CONSTANT_14),&(v453_2));
    drop(v453_2);
    let v453_10: Space = if has_head(&(v453_9)) { singleton(&[]) } else { Space::new() };
    drop(v453_9);
    let v453_13: Space = if (v453_10).is_empty() { Space::new() } else {
      let v458_11: Space = unwrap(&(v452_11),&(v452_18_head));
      let mut v458_12 = Space::new();
      let mut v458_12_cursor = (v458_11).read_zipper();
      for v458_12_byte in v458_12_cursor.child_mask().iter() {
        v458_12_cursor.descend_to_byte(v458_12_byte);
        let v458_12_tail = v458_12_cursor.make_map();
        v458_12_cursor.ascend(1);
        let v458_12_head = Path::from_slice(&[v458_12_byte]);
        let v459_2: Space = singleton(&(v458_12_head));
        let v459_3: Space = intersect(&(*CONSTANT_14),&(v459_2));
        let v459_4: Space = if has_head(&(v459_3)) { singleton(&[]) } else { Space::new() };
        drop(v459_3);
        let v459_5: Space = subtract(&(*CONSTANT_0),&(v459_4));
        drop(v459_4);
        let v459_7: Space = if (v459_5).is_empty() { Space::new() } else {
          let v460_6: Space = routine_87(c, &(v458_12_head), &(*p1), &(v458_12_tail));
          compose(&(v459_5),&(v460_6))
        };
        drop(v459_5);
        let v459_8: Space = intersect(&(*CONSTANT_14),&(v459_2));
        drop(v459_2);
        let v459_9: Space = if has_head(&(v459_8)) { singleton(&[]) } else { Space::new() };
        drop(v459_8);
        let v459_11: Space = if (v459_9).is_empty() { Space::new() } else {
          let v461_10: Space = routine_88(c, &(v458_12_head), &(*p1), &(v458_12_tail));
          compose(&(v459_9),&(v461_10))
        };
        drop(v459_9);
        let v459_12: Space = unite(&(v459_7),&(v459_11));
        v458_12.join_into((v459_12).clone());
      }
      drop(v458_12_cursor);
      drop(v458_11);
      compose(&(v453_10),&(v458_12))
    };
    drop(v453_10);
    let v453_14: Space = unite(&(v453_8),&(v453_13));
    v452_18.join_into((v453_14).clone());
  }
  drop(v452_18_cursor);
  drop(v452_11);
  (v452_18).clone()
}

fn routine_45(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v462_13 = Space::new();
  let mut v462_13_cursor = (*s0).read_zipper();
  for v462_13_byte in v462_13_cursor.child_mask().iter() {
    v462_13_cursor.descend_to_byte(v462_13_byte);
    let v462_13_tail = v462_13_cursor.make_map();
    v462_13_cursor.ascend(1);
    let v462_13_head = Path::from_slice(&[v462_13_byte]);
    let v463_2: Space = singleton(&(v462_13_head));
    let v463_3: Space = intersect(&(*CONSTANT_14),&(v463_2));
    let v463_4: Space = if has_head(&(v463_3)) { singleton(&[]) } else { Space::new() };
    drop(v463_3);
    let v463_5: Space = subtract(&(*CONSTANT_0),&(v463_4));
    drop(v463_4);
    let v463_8: Space = if (v463_5).is_empty() { Space::new() } else {
      let v464_6: Path = concat_path(&(*p0),&(v462_13_head));
      let mut v464_7 = Space::new();
      let mut v464_7_cursor = (v462_13_tail).read_zipper();
      for v464_7_byte in v464_7_cursor.child_mask().iter() {
        v464_7_cursor.descend_to_byte(v464_7_byte);
        let v464_7_tail = v464_7_cursor.make_map();
        v464_7_cursor.ascend(1);
        let v464_7_head = Path::from_slice(&[v464_7_byte]);
        let v465_2: Space = singleton(&(v464_7_head));
        let v465_3: Space = intersect(&(*CONSTANT_14),&(v465_2));
        let v465_4: Space = if has_head(&(v465_3)) { singleton(&[]) } else { Space::new() };
        drop(v465_3);
        let v465_5: Space = subtract(&(*CONSTANT_0),&(v465_4));
        drop(v465_4);
        let v465_8: Space = if (v465_5).is_empty() { Space::new() } else {
          let v466_6: Path = concat_path(&(v464_6),&(v464_7_head));
          let v466_7: Space = routine_89(c, &(v466_6), &(*p1), &(v464_7_tail), &(*s1));
          compose(&(v465_5),&(v466_7))
        };
        drop(v465_5);
        let v465_9: Space = intersect(&(*CONSTANT_14),&(v465_2));
        drop(v465_2);
        let v465_10: Space = if has_head(&(v465_9)) { singleton(&[]) } else { Space::new() };
        drop(v465_9);
        let v465_12: Space = if (v465_10).is_empty() { Space::new() } else {
          let v467_6: Path = concat_path(&(v464_6),&(v464_7_head));
          let v467_11: Space = routine_90(c, &(v467_6), &(*p1), &(v464_7_tail), &(*s1));
          drop(v467_6);
          compose(&(v465_10),&(v467_11))
        };
        drop(v465_10);
        let v465_13: Space = unite(&(v465_8),&(v465_12));
        v464_7.join_into((v465_13).clone());
      }
      drop(v464_7_cursor);
      compose(&(v463_5),&(v464_7))
    };
    drop(v463_5);
    let v463_9: Space = intersect(&(*CONSTANT_14),&(v463_2));
    drop(v463_2);
    let v463_10: Space = if has_head(&(v463_9)) { singleton(&[]) } else { Space::new() };
    drop(v463_9);
    let v463_12: Space = if (v463_10).is_empty() { Space::new() } else {
      let v468_6: Path = concat_path(&(*p0),&(v462_13_head));
      let mut v468_11 = Space::new();
      let mut v468_11_cursor = (v462_13_tail).read_zipper();
      for v468_11_byte in v468_11_cursor.child_mask().iter() {
        v468_11_cursor.descend_to_byte(v468_11_byte);
        let v468_11_tail = v468_11_cursor.make_map();
        v468_11_cursor.ascend(1);
        let v468_11_head = Path::from_slice(&[v468_11_byte]);
        let v469_2: Space = singleton(&(v468_11_head));
        let v469_3: Space = intersect(&(*CONSTANT_14),&(v469_2));
        let v469_4: Space = if has_head(&(v469_3)) { singleton(&[]) } else { Space::new() };
        drop(v469_3);
        let v469_5: Space = subtract(&(*CONSTANT_0),&(v469_4));
        drop(v469_4);
        let v469_8: Space = if (v469_5).is_empty() { Space::new() } else {
          let v470_6: Path = concat_path(&(v468_6),&(v468_11_head));
          let v470_7: Space = routine_89(c, &(v470_6), &(*p1), &(v468_11_tail), &(*s1));
          compose(&(v469_5),&(v470_7))
        };
        drop(v469_5);
        let v469_9: Space = intersect(&(*CONSTANT_14),&(v469_2));
        drop(v469_2);
        let v469_10: Space = if has_head(&(v469_9)) { singleton(&[]) } else { Space::new() };
        drop(v469_9);
        let v469_12: Space = if (v469_10).is_empty() { Space::new() } else {
          let v471_6: Path = concat_path(&(v468_6),&(v468_11_head));
          let v471_11: Space = routine_47(c, &(v471_6), &(*p1), &(v468_11_tail), &(*s1));
          drop(v471_6);
          compose(&(v469_10),&(v471_11))
        };
        drop(v469_10);
        let v469_13: Space = unite(&(v469_8),&(v469_12));
        v468_11.join_into((v469_13).clone());
      }
      drop(v468_11_cursor);
      drop(v468_6);
      compose(&(v463_10),&(v468_11))
    };
    drop(v463_10);
    let v463_13: Space = unite(&(v463_8),&(v463_12));
    v462_13.join_into((v463_13).clone());
  }
  drop(v462_13_cursor);
  (v462_13).clone()
}

fn routine_46(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v472_8: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v472_10: Space = unwrap(&(v472_8),&(*CONSTANT_10));
  drop(v472_8);
  let v472_11: Space = unwrap(&(v472_10),&(*p0));
  drop(v472_10);
  let mut v472_18 = Space::new();
  let mut v472_18_cursor = (*s0).read_zipper();
  for v472_18_byte in v472_18_cursor.child_mask().iter() {
    v472_18_cursor.descend_to_byte(v472_18_byte);
    let v472_18_tail = v472_18_cursor.make_map();
    v472_18_cursor.ascend(1);
    let v472_18_head = Path::from_slice(&[v472_18_byte]);
    let v473_2: Space = singleton(&(v472_18_head));
    let v473_3: Space = intersect(&(*CONSTANT_14),&(v473_2));
    let v473_4: Space = if has_head(&(v473_3)) { singleton(&[]) } else { Space::new() };
    drop(v473_3);
    let v473_5: Space = subtract(&(*CONSTANT_0),&(v473_4));
    drop(v473_4);
    let v473_8: Space = if (v473_5).is_empty() { Space::new() } else {
      let v474_6: Path = concat_path(&(*p0),&(v472_18_head));
      let mut v474_7 = Space::new();
      let mut v474_7_cursor = (v472_18_tail).read_zipper();
      for v474_7_byte in v474_7_cursor.child_mask().iter() {
        v474_7_cursor.descend_to_byte(v474_7_byte);
        let v474_7_tail = v474_7_cursor.make_map();
        v474_7_cursor.ascend(1);
        let v474_7_head = Path::from_slice(&[v474_7_byte]);
        let v475_2: Space = singleton(&(v474_7_head));
        let v475_3: Space = intersect(&(*CONSTANT_14),&(v475_2));
        let v475_4: Space = if has_head(&(v475_3)) { singleton(&[]) } else { Space::new() };
        drop(v475_3);
        let v475_5: Space = subtract(&(*CONSTANT_0),&(v475_4));
        drop(v475_4);
        let v475_8: Space = if (v475_5).is_empty() { Space::new() } else {
          let v476_6: Path = concat_path(&(v474_6),&(v474_7_head));
          let v476_7: Space = routine_89(c, &(v476_6), &(*p1), &(v474_7_tail), &(*s1));
          compose(&(v475_5),&(v476_7))
        };
        drop(v475_5);
        let v475_9: Space = intersect(&(*CONSTANT_14),&(v475_2));
        drop(v475_2);
        let v475_10: Space = if has_head(&(v475_9)) { singleton(&[]) } else { Space::new() };
        drop(v475_9);
        let v475_12: Space = if (v475_10).is_empty() { Space::new() } else {
          let v477_6: Path = concat_path(&(v474_6),&(v474_7_head));
          let v477_11: Space = routine_90(c, &(v477_6), &(*p1), &(v474_7_tail), &(*s1));
          drop(v477_6);
          compose(&(v475_10),&(v477_11))
        };
        drop(v475_10);
        let v475_13: Space = unite(&(v475_8),&(v475_12));
        v474_7.join_into((v475_13).clone());
      }
      drop(v474_7_cursor);
      drop(v474_6);
      compose(&(v473_5),&(v474_7))
    };
    drop(v473_5);
    let v473_9: Space = intersect(&(*CONSTANT_14),&(v473_2));
    drop(v473_2);
    let v473_10: Space = if has_head(&(v473_9)) { singleton(&[]) } else { Space::new() };
    drop(v473_9);
    let v473_13: Space = if (v473_10).is_empty() { Space::new() } else {
      let v478_11: Space = unwrap(&(v472_11),&(v472_18_head));
      let mut v478_12 = Space::new();
      let mut v478_12_cursor = (v478_11).read_zipper();
      for v478_12_byte in v478_12_cursor.child_mask().iter() {
        v478_12_cursor.descend_to_byte(v478_12_byte);
        let v478_12_tail = v478_12_cursor.make_map();
        v478_12_cursor.ascend(1);
        let v478_12_head = Path::from_slice(&[v478_12_byte]);
        let v479_2: Space = singleton(&(v478_12_head));
        let v479_3: Space = intersect(&(*CONSTANT_14),&(v479_2));
        let v479_4: Space = if has_head(&(v479_3)) { singleton(&[]) } else { Space::new() };
        drop(v479_3);
        let v479_5: Space = subtract(&(*CONSTANT_0),&(v479_4));
        drop(v479_4);
        let v479_7: Space = if (v479_5).is_empty() { Space::new() } else {
          let v480_6: Space = routine_87(c, &(v478_12_head), &(*p1), &(v478_12_tail));
          compose(&(v479_5),&(v480_6))
        };
        drop(v479_5);
        let v479_8: Space = intersect(&(*CONSTANT_14),&(v479_2));
        drop(v479_2);
        let v479_9: Space = if has_head(&(v479_8)) { singleton(&[]) } else { Space::new() };
        drop(v479_8);
        let v479_11: Space = if (v479_9).is_empty() { Space::new() } else {
          let v481_10: Space = routine_88(c, &(v478_12_head), &(*p1), &(v478_12_tail));
          compose(&(v479_9),&(v481_10))
        };
        drop(v479_9);
        let v479_12: Space = unite(&(v479_7),&(v479_11));
        v478_12.join_into((v479_12).clone());
      }
      drop(v478_12_cursor);
      drop(v478_11);
      compose(&(v473_10),&(v478_12))
    };
    drop(v473_10);
    let v473_14: Space = unite(&(v473_8),&(v473_13));
    v472_18.join_into((v473_14).clone());
  }
  drop(v472_18_cursor);
  drop(v472_11);
  (v472_18).clone()
}

fn routine_47(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v482_5: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v482_7: Space = unwrap(&(v482_5),&(*CONSTANT_10));
  drop(v482_5);
  let v482_8: Space = unwrap(&(v482_7),&(*p0));
  drop(v482_7);
  let mut v482_18 = Space::new();
  let mut v482_18_cursor = (v482_8).read_zipper();
  for v482_18_byte in v482_18_cursor.child_mask().iter() {
    v482_18_cursor.descend_to_byte(v482_18_byte);
    let v482_18_tail = v482_18_cursor.make_map();
    v482_18_cursor.ascend(1);
    let v482_18_head = Path::from_slice(&[v482_18_byte]);
    let v483_2: Space = singleton(&(v482_18_head));
    let v483_3: Space = intersect(&(*CONSTANT_14),&(v483_2));
    let v483_4: Space = if has_head(&(v483_3)) { singleton(&[]) } else { Space::new() };
    drop(v483_3);
    let v483_5: Space = subtract(&(*CONSTANT_0),&(v483_4));
    drop(v483_4);
    let v483_7: Space = if (v483_5).is_empty() { Space::new() } else {
      let mut v484_6 = Space::new();
      let mut v484_6_cursor = (v482_18_tail).read_zipper();
      for v484_6_byte in v484_6_cursor.child_mask().iter() {
        v484_6_cursor.descend_to_byte(v484_6_byte);
        let v484_6_tail = v484_6_cursor.make_map();
        v484_6_cursor.ascend(1);
        let v484_6_head = Path::from_slice(&[v484_6_byte]);
        let v485_2: Space = singleton(&(v484_6_head));
        let v485_3: Space = intersect(&(*CONSTANT_14),&(v485_2));
        let v485_4: Space = if has_head(&(v485_3)) { singleton(&[]) } else { Space::new() };
        drop(v485_3);
        let v485_5: Space = subtract(&(*CONSTANT_0),&(v485_4));
        drop(v485_4);
        let v485_8: Space = if (v485_5).is_empty() { Space::new() } else {
          let v486_6: Path = concat_path(&(v482_18_head),&(v484_6_head));
          let v486_7: Space = routine_91(c, &(v486_6), &(*p1), &(v484_6_tail));
          compose(&(v485_5),&(v486_7))
        };
        drop(v485_5);
        let v485_9: Space = intersect(&(*CONSTANT_14),&(v485_2));
        drop(v485_2);
        let v485_10: Space = if has_head(&(v485_9)) { singleton(&[]) } else { Space::new() };
        drop(v485_9);
        let v485_12: Space = if (v485_10).is_empty() { Space::new() } else {
          let v487_6: Path = concat_path(&(v482_18_head),&(v484_6_head));
          let v487_11: Space = routine_92(c, &(v487_6), &(*p1), &(v484_6_tail));
          drop(v487_6);
          compose(&(v485_10),&(v487_11))
        };
        drop(v485_10);
        let v485_13: Space = unite(&(v485_8),&(v485_12));
        v484_6.join_into((v485_13).clone());
      }
      drop(v484_6_cursor);
      compose(&(v483_5),&(v484_6))
    };
    drop(v483_5);
    let v483_8: Space = intersect(&(*CONSTANT_14),&(v483_2));
    drop(v483_2);
    let v483_9: Space = if has_head(&(v483_8)) { singleton(&[]) } else { Space::new() };
    drop(v483_8);
    let v483_11: Space = if (v483_9).is_empty() { Space::new() } else {
      let mut v488_10 = Space::new();
      let mut v488_10_cursor = (v482_18_tail).read_zipper();
      for v488_10_byte in v488_10_cursor.child_mask().iter() {
        v488_10_cursor.descend_to_byte(v488_10_byte);
        let v488_10_tail = v488_10_cursor.make_map();
        v488_10_cursor.ascend(1);
        let v488_10_head = Path::from_slice(&[v488_10_byte]);
        let v489_2: Space = singleton(&(v488_10_head));
        let v489_3: Space = intersect(&(*CONSTANT_14),&(v489_2));
        let v489_4: Space = if has_head(&(v489_3)) { singleton(&[]) } else { Space::new() };
        drop(v489_3);
        let v489_5: Space = subtract(&(*CONSTANT_0),&(v489_4));
        drop(v489_4);
        let v489_8: Space = if (v489_5).is_empty() { Space::new() } else {
          let v490_6: Path = concat_path(&(v482_18_head),&(v488_10_head));
          let v490_7: Space = routine_91(c, &(v490_6), &(*p1), &(v488_10_tail));
          compose(&(v489_5),&(v490_7))
        };
        drop(v489_5);
        let v489_9: Space = intersect(&(*CONSTANT_14),&(v489_2));
        drop(v489_2);
        let v489_10: Space = if has_head(&(v489_9)) { singleton(&[]) } else { Space::new() };
        drop(v489_9);
        let v489_12: Space = if (v489_10).is_empty() { Space::new() } else {
          let v491_6: Path = concat_path(&(v482_18_head),&(v488_10_head));
          let v491_11: Space = routine_93(c, &(v491_6), &(*p1), &(v488_10_tail));
          drop(v491_6);
          compose(&(v489_10),&(v491_11))
        };
        drop(v489_10);
        let v489_13: Space = unite(&(v489_8),&(v489_12));
        v488_10.join_into((v489_13).clone());
      }
      drop(v488_10_cursor);
      compose(&(v483_9),&(v488_10))
    };
    drop(v483_9);
    let v483_12: Space = unite(&(v483_7),&(v483_11));
    v482_18.join_into((v483_12).clone());
  }
  drop(v482_18_cursor);
  drop(v482_8);
  (v482_18).clone()
}

fn routine_48(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v492_6 = Space::new();
  let mut v492_6_cursor = (*s0).read_zipper();
  for v492_6_byte in v492_6_cursor.child_mask().iter() {
    v492_6_cursor.descend_to_byte(v492_6_byte);
    let v492_6_tail = v492_6_cursor.make_map();
    v492_6_cursor.ascend(1);
    let v492_6_head = Path::from_slice(&[v492_6_byte]);
    let v493_2: Space = singleton(&(v492_6_head));
    let v493_3: Space = intersect(&(*CONSTANT_14),&(v493_2));
    let v493_4: Space = if has_head(&(v493_3)) { singleton(&[]) } else { Space::new() };
    drop(v493_3);
    let v493_5: Space = subtract(&(*CONSTANT_0),&(v493_4));
    drop(v493_4);
    let mut v493_6 = Space::new();
    let mut v493_6_cursor = (v492_6_tail).read_zipper();
    for v493_6_byte in v493_6_cursor.child_mask().iter() {
      v493_6_cursor.descend_to_byte(v493_6_byte);
      let v493_6_tail = v493_6_cursor.make_map();
      v493_6_cursor.ascend(1);
      let v493_6_head = Path::from_slice(&[v493_6_byte]);
      let v494_2: Space = Space::new();
      v493_6.join_into((v494_2).clone());
    }
    drop(v493_6_cursor);
    let v493_7: Space = compose(&(v493_5),&(v493_6));
    drop(v493_5);
    drop(v493_6);
    let v493_8: Space = intersect(&(*CONSTANT_14),&(v493_2));
    drop(v493_2);
    let v493_9: Space = if has_head(&(v493_8)) { singleton(&[]) } else { Space::new() };
    drop(v493_8);
    let v493_12: Space = if (v493_9).is_empty() { Space::new() } else {
      let v495_10: Path = concat_path(&(*p0),&(v492_6_head));
      let mut v495_11 = Space::new();
      let mut v495_11_cursor = (v492_6_tail).read_zipper();
      for v495_11_byte in v495_11_cursor.child_mask().iter() {
        v495_11_cursor.descend_to_byte(v495_11_byte);
        let v495_11_tail = v495_11_cursor.make_map();
        v495_11_cursor.ascend(1);
        let v495_11_head = Path::from_slice(&[v495_11_byte]);
        let v496_2: Space = singleton(&(v495_11_head));
        let v496_3: Space = intersect(&(*CONSTANT_14),&(v496_2));
        drop(v496_2);
        let v496_4: Space = if has_head(&(v496_3)) { singleton(&[]) } else { Space::new() };
        drop(v496_3);
        let v496_7: Space = if (v496_4).is_empty() { Space::new() } else {
          let v497_5: Path = concat_path(&(v495_10),&(v495_11_head));
          let v497_6: Space = routine_17(c, &(v497_5), &(v495_11_tail));
          drop(v497_5);
          compose(&(v496_4),&(v497_6))
        };
        drop(v496_4);
        v495_11.join_into((v496_7).clone());
      }
      drop(v495_11_cursor);
      drop(v495_10);
      compose(&(v493_9),&(v495_11))
    };
    drop(v493_9);
    let v493_13: Space = unite(&(v493_7),&(v493_12));
    drop(v493_7);
    v492_6.join_into((v493_13).clone());
  }
  drop(v492_6_cursor);
  (v492_6).clone()
}

fn routine_49(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v498_8 = Space::new();
  let mut v498_8_cursor = (*s0).read_zipper();
  for v498_8_byte in v498_8_cursor.child_mask().iter() {
    v498_8_cursor.descend_to_byte(v498_8_byte);
    let v498_8_tail = v498_8_cursor.make_map();
    v498_8_cursor.ascend(1);
    let v498_8_head = Path::from_slice(&[v498_8_byte]);
    let v499_2: Space = singleton(&(v498_8_head));
    let v499_3: Space = intersect(&(*CONSTANT_14),&(v499_2));
    let v499_4: Space = if has_head(&(v499_3)) { singleton(&[]) } else { Space::new() };
    drop(v499_3);
    let v499_5: Space = subtract(&(*CONSTANT_0),&(v499_4));
    drop(v499_4);
    let mut v499_6 = Space::new();
    let mut v499_6_cursor = (v498_8_tail).read_zipper();
    for v499_6_byte in v499_6_cursor.child_mask().iter() {
      v499_6_cursor.descend_to_byte(v499_6_byte);
      let v499_6_tail = v499_6_cursor.make_map();
      v499_6_cursor.ascend(1);
      let v499_6_head = Path::from_slice(&[v499_6_byte]);
      let v500_2: Space = Space::new();
      v499_6.join_into((v500_2).clone());
    }
    drop(v499_6_cursor);
    let v499_7: Space = compose(&(v499_5),&(v499_6));
    drop(v499_5);
    drop(v499_6);
    let v499_8: Space = intersect(&(*CONSTANT_14),&(v499_2));
    drop(v499_2);
    let v499_9: Space = if has_head(&(v499_8)) { singleton(&[]) } else { Space::new() };
    drop(v499_8);
    let v499_12: Space = if (v499_9).is_empty() { Space::new() } else {
      let v501_10: Path = concat_path(&(*p0),&(v498_8_head));
      let mut v501_11 = Space::new();
      let mut v501_11_cursor = (v498_8_tail).read_zipper();
      for v501_11_byte in v501_11_cursor.child_mask().iter() {
        v501_11_cursor.descend_to_byte(v501_11_byte);
        let v501_11_tail = v501_11_cursor.make_map();
        v501_11_cursor.ascend(1);
        let v501_11_head = Path::from_slice(&[v501_11_byte]);
        let v502_2: Space = singleton(&(v501_11_head));
        let v502_3: Space = intersect(&(*CONSTANT_14),&(v502_2));
        let v502_4: Space = if has_head(&(v502_3)) { singleton(&[]) } else { Space::new() };
        drop(v502_3);
        let v502_5: Space = subtract(&(*CONSTANT_0),&(v502_4));
        drop(v502_4);
        let v502_7: Space = if (v502_5).is_empty() { Space::new() } else {
          let v503_6: Space = routine_18(c, &(v501_11_head), &(v501_10), &(v501_11_tail));
          compose(&(v502_5),&(v503_6))
        };
        drop(v502_5);
        let v502_8: Space = intersect(&(*CONSTANT_14),&(v502_2));
        drop(v502_2);
        let v502_9: Space = if has_head(&(v502_8)) { singleton(&[]) } else { Space::new() };
        drop(v502_8);
        let v502_11: Space = if (v502_9).is_empty() { Space::new() } else {
          let v504_10: Space = routine_19(c, &(v501_11_head), &(v501_10), &(v501_11_tail));
          compose(&(v502_9),&(v504_10))
        };
        drop(v502_9);
        let v502_12: Space = unite(&(v502_7),&(v502_11));
        v501_11.join_into((v502_12).clone());
      }
      drop(v501_11_cursor);
      drop(v501_10);
      compose(&(v499_9),&(v501_11))
    };
    drop(v499_9);
    let v499_13: Space = unite(&(v499_7),&(v499_12));
    drop(v499_7);
    v498_8.join_into((v499_13).clone());
  }
  drop(v498_8_cursor);
  (v498_8).clone()
}

fn routine_50(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v505_12 = Space::new();
  let mut v505_12_cursor = (*s0).read_zipper();
  for v505_12_byte in v505_12_cursor.child_mask().iter() {
    v505_12_cursor.descend_to_byte(v505_12_byte);
    let v505_12_tail = v505_12_cursor.make_map();
    v505_12_cursor.ascend(1);
    let v505_12_head = Path::from_slice(&[v505_12_byte]);
    let v506_2: Space = singleton(&(v505_12_head));
    let v506_3: Space = intersect(&(*CONSTANT_14),&(v506_2));
    let v506_4: Space = if has_head(&(v506_3)) { singleton(&[]) } else { Space::new() };
    drop(v506_3);
    let v506_5: Space = subtract(&(*CONSTANT_0),&(v506_4));
    drop(v506_4);
    let v506_8: Space = if (v506_5).is_empty() { Space::new() } else {
      let v507_6: Path = concat_path(&(*p0),&(v505_12_head));
      let mut v507_7 = Space::new();
      let mut v507_7_cursor = (v505_12_tail).read_zipper();
      for v507_7_byte in v507_7_cursor.child_mask().iter() {
        v507_7_cursor.descend_to_byte(v507_7_byte);
        let v507_7_tail = v507_7_cursor.make_map();
        v507_7_cursor.ascend(1);
        let v507_7_head = Path::from_slice(&[v507_7_byte]);
        let v508_2: Space = singleton(&(v507_7_head));
        let v508_3: Space = intersect(&(*CONSTANT_14),&(v508_2));
        let v508_4: Space = if has_head(&(v508_3)) { singleton(&[]) } else { Space::new() };
        drop(v508_3);
        let v508_5: Space = subtract(&(*CONSTANT_0),&(v508_4));
        drop(v508_4);
        let v508_8: Space = if (v508_5).is_empty() { Space::new() } else {
          let v509_6: Path = concat_path(&(v507_6),&(v507_7_head));
          let v509_7: Space = routine_94(c, &(v509_6), &(*p1), &(v507_7_tail));
          compose(&(v508_5),&(v509_7))
        };
        drop(v508_5);
        let v508_9: Space = intersect(&(*CONSTANT_14),&(v508_2));
        drop(v508_2);
        let v508_10: Space = if has_head(&(v508_9)) { singleton(&[]) } else { Space::new() };
        drop(v508_9);
        let v508_12: Space = if (v508_10).is_empty() { Space::new() } else {
          let v510_6: Path = concat_path(&(v507_6),&(v507_7_head));
          let v510_11: Space = routine_95(c, &(v510_6), &(*p1), &(v507_7_tail));
          drop(v510_6);
          compose(&(v508_10),&(v510_11))
        };
        drop(v508_10);
        let v508_13: Space = unite(&(v508_8),&(v508_12));
        v507_7.join_into((v508_13).clone());
      }
      drop(v507_7_cursor);
      compose(&(v506_5),&(v507_7))
    };
    drop(v506_5);
    let v506_9: Space = intersect(&(*CONSTANT_14),&(v506_2));
    drop(v506_2);
    let v506_10: Space = if has_head(&(v506_9)) { singleton(&[]) } else { Space::new() };
    drop(v506_9);
    let v506_12: Space = if (v506_10).is_empty() { Space::new() } else {
      let v511_6: Path = concat_path(&(*p0),&(v505_12_head));
      let mut v511_11 = Space::new();
      let mut v511_11_cursor = (v505_12_tail).read_zipper();
      for v511_11_byte in v511_11_cursor.child_mask().iter() {
        v511_11_cursor.descend_to_byte(v511_11_byte);
        let v511_11_tail = v511_11_cursor.make_map();
        v511_11_cursor.ascend(1);
        let v511_11_head = Path::from_slice(&[v511_11_byte]);
        let v512_2: Space = singleton(&(v511_11_head));
        let v512_3: Space = intersect(&(*CONSTANT_14),&(v512_2));
        let v512_4: Space = if has_head(&(v512_3)) { singleton(&[]) } else { Space::new() };
        drop(v512_3);
        let v512_5: Space = subtract(&(*CONSTANT_0),&(v512_4));
        drop(v512_4);
        let v512_8: Space = if (v512_5).is_empty() { Space::new() } else {
          let v513_6: Path = concat_path(&(v511_6),&(v511_11_head));
          let v513_7: Space = routine_94(c, &(v513_6), &(*p1), &(v511_11_tail));
          compose(&(v512_5),&(v513_7))
        };
        drop(v512_5);
        let v512_9: Space = intersect(&(*CONSTANT_14),&(v512_2));
        drop(v512_2);
        let v512_10: Space = if has_head(&(v512_9)) { singleton(&[]) } else { Space::new() };
        drop(v512_9);
        let v512_12: Space = if (v512_10).is_empty() { Space::new() } else {
          let v514_6: Path = concat_path(&(v511_6),&(v511_11_head));
          let v514_11: Space = routine_52(c, &(v514_6), &(*p1), &(v511_11_tail));
          drop(v514_6);
          compose(&(v512_10),&(v514_11))
        };
        drop(v512_10);
        let v512_13: Space = unite(&(v512_8),&(v512_12));
        v511_11.join_into((v512_13).clone());
      }
      drop(v511_11_cursor);
      drop(v511_6);
      compose(&(v506_10),&(v511_11))
    };
    drop(v506_10);
    let v506_13: Space = unite(&(v506_8),&(v506_12));
    v505_12.join_into((v506_13).clone());
  }
  drop(v505_12_cursor);
  (v505_12).clone()
}

fn routine_51(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v515_10 = Space::new();
  let mut v515_10_cursor = (*s0).read_zipper();
  for v515_10_byte in v515_10_cursor.child_mask().iter() {
    v515_10_cursor.descend_to_byte(v515_10_byte);
    let v515_10_tail = v515_10_cursor.make_map();
    v515_10_cursor.ascend(1);
    let v515_10_head = Path::from_slice(&[v515_10_byte]);
    let v516_2: Space = singleton(&(v515_10_head));
    let v516_3: Space = intersect(&(*CONSTANT_14),&(v516_2));
    let v516_4: Space = if has_head(&(v516_3)) { singleton(&[]) } else { Space::new() };
    drop(v516_3);
    let v516_5: Space = compose(&(v516_4),&(v515_10_tail));
    drop(v516_4);
    let v517_6: Path = concat_path(&(*p0),&(v515_10_head));
    let v516_7: Space = wrap(&(v516_5),&(v517_6));
    drop(v516_5);
    let v516_8: Space = wrap(&(v516_7),&(*p1));
    drop(v516_7);
    let v516_9: Space = wrap(&(v516_8),&(*CONSTANT_10));
    drop(v516_8);
    let v516_10: Space = intersect(&(*CONSTANT_14),&(v516_2));
    drop(v516_2);
    let v516_11: Space = if has_head(&(v516_10)) { singleton(&[]) } else { Space::new() };
    drop(v516_10);
    let v516_12: Space = subtract(&(*CONSTANT_0),&(v516_11));
    drop(v516_11);
    let v516_14: Space = if (v516_12).is_empty() { Space::new() } else {
      let mut v518_13 = Space::new();
      let mut v518_13_cursor = (v515_10_tail).read_zipper();
      for v518_13_byte in v518_13_cursor.child_mask().iter() {
        v518_13_cursor.descend_to_byte(v518_13_byte);
        let v518_13_tail = v518_13_cursor.make_map();
        v518_13_cursor.ascend(1);
        let v518_13_head = Path::from_slice(&[v518_13_byte]);
        let v519_2: Space = singleton(&(v518_13_head));
        let v519_3: Space = intersect(&(*CONSTANT_14),&(v519_2));
        let v519_4: Space = if has_head(&(v519_3)) { singleton(&[]) } else { Space::new() };
        drop(v519_3);
        let v519_5: Space = subtract(&(*CONSTANT_0),&(v519_4));
        drop(v519_4);
        let v519_8: Space = if (v519_5).is_empty() { Space::new() } else {
          let v520_6: Path = concat_path(&(v517_6),&(v518_13_head));
          let v520_7: Space = routine_94(c, &(v520_6), &(*p1), &(v518_13_tail));
          compose(&(v519_5),&(v520_7))
        };
        drop(v519_5);
        let v519_9: Space = intersect(&(*CONSTANT_14),&(v519_2));
        drop(v519_2);
        let v519_10: Space = if has_head(&(v519_9)) { singleton(&[]) } else { Space::new() };
        drop(v519_9);
        let v519_12: Space = if (v519_10).is_empty() { Space::new() } else {
          let v521_6: Path = concat_path(&(v517_6),&(v518_13_head));
          let v521_11: Space = routine_95(c, &(v521_6), &(*p1), &(v518_13_tail));
          drop(v521_6);
          compose(&(v519_10),&(v521_11))
        };
        drop(v519_10);
        let v519_13: Space = unite(&(v519_8),&(v519_12));
        v518_13.join_into((v519_13).clone());
      }
      drop(v518_13_cursor);
      compose(&(v516_12),&(v518_13))
    };
    drop(v516_12);
    let v516_15: Space = unite(&(v516_9),&(v516_14));
    drop(v516_9);
    v515_10.join_into((v516_15).clone());
  }
  drop(v515_10_cursor);
  (v515_10).clone()
}

fn routine_52(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v522_3: Space = wrap(&(*s0),&(*p0));
  let v522_4: Space = wrap(&(v522_3),&(*p1));
  drop(v522_3);
  let v522_6: Space = wrap(&(v522_4),&(*CONSTANT_10));
  drop(v522_4);
  (v522_6).clone()
}

fn routine_53(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v523_12 = Space::new();
  let mut v523_12_cursor = (*s0).read_zipper();
  for v523_12_byte in v523_12_cursor.child_mask().iter() {
    v523_12_cursor.descend_to_byte(v523_12_byte);
    let v523_12_tail = v523_12_cursor.make_map();
    v523_12_cursor.ascend(1);
    let v523_12_head = Path::from_slice(&[v523_12_byte]);
    let v524_2: Space = singleton(&(v523_12_head));
    let v524_3: Space = intersect(&(*CONSTANT_14),&(v524_2));
    let v524_4: Space = if has_head(&(v524_3)) { singleton(&[]) } else { Space::new() };
    drop(v524_3);
    let v524_5: Space = subtract(&(*CONSTANT_0),&(v524_4));
    drop(v524_4);
    let v524_8: Space = if (v524_5).is_empty() { Space::new() } else {
      let v525_6: Path = concat_path(&(*p0),&(v523_12_head));
      let mut v525_7 = Space::new();
      let mut v525_7_cursor = (v523_12_tail).read_zipper();
      for v525_7_byte in v525_7_cursor.child_mask().iter() {
        v525_7_cursor.descend_to_byte(v525_7_byte);
        let v525_7_tail = v525_7_cursor.make_map();
        v525_7_cursor.ascend(1);
        let v525_7_head = Path::from_slice(&[v525_7_byte]);
        let v526_2: Space = singleton(&(v525_7_head));
        let v526_3: Space = intersect(&(*CONSTANT_14),&(v526_2));
        let v526_4: Space = if has_head(&(v526_3)) { singleton(&[]) } else { Space::new() };
        drop(v526_3);
        let v526_5: Space = subtract(&(*CONSTANT_0),&(v526_4));
        drop(v526_4);
        let v526_8: Space = if (v526_5).is_empty() { Space::new() } else {
          let v527_6: Path = concat_path(&(v525_6),&(v525_7_head));
          let v527_7: Space = routine_96(c, &(v527_6), &(*p1), &(v525_7_tail));
          compose(&(v526_5),&(v527_7))
        };
        drop(v526_5);
        let v526_9: Space = intersect(&(*CONSTANT_14),&(v526_2));
        drop(v526_2);
        let v526_10: Space = if has_head(&(v526_9)) { singleton(&[]) } else { Space::new() };
        drop(v526_9);
        let v526_12: Space = if (v526_10).is_empty() { Space::new() } else {
          let v528_6: Path = concat_path(&(v525_6),&(v525_7_head));
          let v528_11: Space = routine_97(c, &(v528_6), &(*p1), &(v525_7_tail));
          drop(v528_6);
          compose(&(v526_10),&(v528_11))
        };
        drop(v526_10);
        let v526_13: Space = unite(&(v526_8),&(v526_12));
        v525_7.join_into((v526_13).clone());
      }
      drop(v525_7_cursor);
      compose(&(v524_5),&(v525_7))
    };
    drop(v524_5);
    let v524_9: Space = intersect(&(*CONSTANT_14),&(v524_2));
    drop(v524_2);
    let v524_10: Space = if has_head(&(v524_9)) { singleton(&[]) } else { Space::new() };
    drop(v524_9);
    let v524_12: Space = if (v524_10).is_empty() { Space::new() } else {
      let v529_6: Path = concat_path(&(*p0),&(v523_12_head));
      let mut v529_11 = Space::new();
      let mut v529_11_cursor = (v523_12_tail).read_zipper();
      for v529_11_byte in v529_11_cursor.child_mask().iter() {
        v529_11_cursor.descend_to_byte(v529_11_byte);
        let v529_11_tail = v529_11_cursor.make_map();
        v529_11_cursor.ascend(1);
        let v529_11_head = Path::from_slice(&[v529_11_byte]);
        let v530_2: Space = singleton(&(v529_11_head));
        let v530_3: Space = intersect(&(*CONSTANT_14),&(v530_2));
        let v530_4: Space = if has_head(&(v530_3)) { singleton(&[]) } else { Space::new() };
        drop(v530_3);
        let v530_5: Space = subtract(&(*CONSTANT_0),&(v530_4));
        drop(v530_4);
        let v530_8: Space = if (v530_5).is_empty() { Space::new() } else {
          let v531_6: Path = concat_path(&(v529_6),&(v529_11_head));
          let v531_7: Space = routine_96(c, &(v531_6), &(*p1), &(v529_11_tail));
          compose(&(v530_5),&(v531_7))
        };
        drop(v530_5);
        let v530_9: Space = intersect(&(*CONSTANT_14),&(v530_2));
        drop(v530_2);
        let v530_10: Space = if has_head(&(v530_9)) { singleton(&[]) } else { Space::new() };
        drop(v530_9);
        let v530_12: Space = if (v530_10).is_empty() { Space::new() } else {
          let v532_6: Path = concat_path(&(v529_6),&(v529_11_head));
          let v532_11: Space = routine_52(c, &(v532_6), &(*p1), &(v529_11_tail));
          drop(v532_6);
          compose(&(v530_10),&(v532_11))
        };
        drop(v530_10);
        let v530_13: Space = unite(&(v530_8),&(v530_12));
        v529_11.join_into((v530_13).clone());
      }
      drop(v529_11_cursor);
      drop(v529_6);
      compose(&(v524_10),&(v529_11))
    };
    drop(v524_10);
    let v524_13: Space = unite(&(v524_8),&(v524_12));
    v523_12.join_into((v524_13).clone());
  }
  drop(v523_12_cursor);
  (v523_12).clone()
}

fn routine_54(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v533_10 = Space::new();
  let mut v533_10_cursor = (*s0).read_zipper();
  for v533_10_byte in v533_10_cursor.child_mask().iter() {
    v533_10_cursor.descend_to_byte(v533_10_byte);
    let v533_10_tail = v533_10_cursor.make_map();
    v533_10_cursor.ascend(1);
    let v533_10_head = Path::from_slice(&[v533_10_byte]);
    let v534_2: Space = singleton(&(v533_10_head));
    let v534_3: Space = intersect(&(*CONSTANT_14),&(v534_2));
    let v534_4: Space = if has_head(&(v534_3)) { singleton(&[]) } else { Space::new() };
    drop(v534_3);
    let v534_5: Space = compose(&(v534_4),&(v533_10_tail));
    drop(v534_4);
    let v535_6: Path = concat_path(&(*p0),&(v533_10_head));
    let v534_7: Space = wrap(&(v534_5),&(v535_6));
    drop(v534_5);
    let v534_8: Space = wrap(&(v534_7),&(*p1));
    drop(v534_7);
    let v534_9: Space = wrap(&(v534_8),&(*CONSTANT_10));
    drop(v534_8);
    let v534_10: Space = intersect(&(*CONSTANT_14),&(v534_2));
    drop(v534_2);
    let v534_11: Space = if has_head(&(v534_10)) { singleton(&[]) } else { Space::new() };
    drop(v534_10);
    let v534_12: Space = subtract(&(*CONSTANT_0),&(v534_11));
    drop(v534_11);
    let v534_14: Space = if (v534_12).is_empty() { Space::new() } else {
      let mut v536_13 = Space::new();
      let mut v536_13_cursor = (v533_10_tail).read_zipper();
      for v536_13_byte in v536_13_cursor.child_mask().iter() {
        v536_13_cursor.descend_to_byte(v536_13_byte);
        let v536_13_tail = v536_13_cursor.make_map();
        v536_13_cursor.ascend(1);
        let v536_13_head = Path::from_slice(&[v536_13_byte]);
        let v537_2: Space = singleton(&(v536_13_head));
        let v537_3: Space = intersect(&(*CONSTANT_14),&(v537_2));
        let v537_4: Space = if has_head(&(v537_3)) { singleton(&[]) } else { Space::new() };
        drop(v537_3);
        let v537_5: Space = subtract(&(*CONSTANT_0),&(v537_4));
        drop(v537_4);
        let v537_8: Space = if (v537_5).is_empty() { Space::new() } else {
          let v538_6: Path = concat_path(&(v535_6),&(v536_13_head));
          let v538_7: Space = routine_96(c, &(v538_6), &(*p1), &(v536_13_tail));
          compose(&(v537_5),&(v538_7))
        };
        drop(v537_5);
        let v537_9: Space = intersect(&(*CONSTANT_14),&(v537_2));
        drop(v537_2);
        let v537_10: Space = if has_head(&(v537_9)) { singleton(&[]) } else { Space::new() };
        drop(v537_9);
        let v537_12: Space = if (v537_10).is_empty() { Space::new() } else {
          let v539_6: Path = concat_path(&(v535_6),&(v536_13_head));
          let v539_11: Space = routine_97(c, &(v539_6), &(*p1), &(v536_13_tail));
          drop(v539_6);
          compose(&(v537_10),&(v539_11))
        };
        drop(v537_10);
        let v537_13: Space = unite(&(v537_8),&(v537_12));
        v536_13.join_into((v537_13).clone());
      }
      drop(v536_13_cursor);
      compose(&(v534_12),&(v536_13))
    };
    drop(v534_12);
    let v534_15: Space = unite(&(v534_9),&(v534_14));
    drop(v534_9);
    v533_10.join_into((v534_15).clone());
  }
  drop(v533_10_cursor);
  (v533_10).clone()
}

fn routine_55(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v540_7 = Space::new();
  let mut v540_7_cursor = (*s0).read_zipper();
  for v540_7_byte in v540_7_cursor.child_mask().iter() {
    v540_7_cursor.descend_to_byte(v540_7_byte);
    let v540_7_tail = v540_7_cursor.make_map();
    v540_7_cursor.ascend(1);
    let v540_7_head = Path::from_slice(&[v540_7_byte]);
    let v541_2: Space = singleton(&(v540_7_head));
    let v541_3: Space = intersect(&(*CONSTANT_14),&(v541_2));
    let v541_4: Space = if has_head(&(v541_3)) { singleton(&[]) } else { Space::new() };
    drop(v541_3);
    let v541_5: Space = subtract(&(*CONSTANT_0),&(v541_4));
    drop(v541_4);
    let mut v541_6 = Space::new();
    let mut v541_6_cursor = (v540_7_tail).read_zipper();
    for v541_6_byte in v541_6_cursor.child_mask().iter() {
      v541_6_cursor.descend_to_byte(v541_6_byte);
      let v541_6_tail = v541_6_cursor.make_map();
      v541_6_cursor.ascend(1);
      let v541_6_head = Path::from_slice(&[v541_6_byte]);
      let v542_2: Space = Space::new();
      v541_6.join_into((v542_2).clone());
    }
    drop(v541_6_cursor);
    let v541_7: Space = compose(&(v541_5),&(v541_6));
    drop(v541_5);
    drop(v541_6);
    let v541_8: Space = intersect(&(*CONSTANT_14),&(v541_2));
    drop(v541_2);
    let v541_9: Space = if has_head(&(v541_8)) { singleton(&[]) } else { Space::new() };
    drop(v541_8);
    let v541_12: Space = if (v541_9).is_empty() { Space::new() } else {
      let v543_10: Path = concat_path(&(*p0),&(v540_7_head));
      let mut v543_11 = Space::new();
      let mut v543_11_cursor = (v540_7_tail).read_zipper();
      for v543_11_byte in v543_11_cursor.child_mask().iter() {
        v543_11_cursor.descend_to_byte(v543_11_byte);
        let v543_11_tail = v543_11_cursor.make_map();
        v543_11_cursor.ascend(1);
        let v543_11_head = Path::from_slice(&[v543_11_byte]);
        let v544_2: Space = singleton(&(v543_11_head));
        let v544_3: Space = intersect(&(*CONSTANT_14),&(v544_2));
        drop(v544_2);
        let v544_4: Space = if has_head(&(v544_3)) { singleton(&[]) } else { Space::new() };
        drop(v544_3);
        let v544_7: Space = if (v544_4).is_empty() { Space::new() } else {
          let v545_5: Path = concat_path(&(v543_10),&(v543_11_head));
          let v545_6: Space = routine_5(c, &(v545_5), &(v543_11_tail), &(*s1));
          drop(v545_5);
          compose(&(v544_4),&(v545_6))
        };
        drop(v544_4);
        v543_11.join_into((v544_7).clone());
      }
      drop(v543_11_cursor);
      drop(v543_10);
      compose(&(v541_9),&(v543_11))
    };
    drop(v541_9);
    let v541_13: Space = unite(&(v541_7),&(v541_12));
    drop(v541_7);
    v540_7.join_into((v541_13).clone());
  }
  drop(v540_7_cursor);
  (v540_7).clone()
}

fn routine_56(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v546_9 = Space::new();
  let mut v546_9_cursor = (*s0).read_zipper();
  for v546_9_byte in v546_9_cursor.child_mask().iter() {
    v546_9_cursor.descend_to_byte(v546_9_byte);
    let v546_9_tail = v546_9_cursor.make_map();
    v546_9_cursor.ascend(1);
    let v546_9_head = Path::from_slice(&[v546_9_byte]);
    let v547_2: Space = singleton(&(v546_9_head));
    let v547_3: Space = intersect(&(*CONSTANT_14),&(v547_2));
    let v547_4: Space = if has_head(&(v547_3)) { singleton(&[]) } else { Space::new() };
    drop(v547_3);
    let v547_5: Space = subtract(&(*CONSTANT_0),&(v547_4));
    drop(v547_4);
    let mut v547_6 = Space::new();
    let mut v547_6_cursor = (v546_9_tail).read_zipper();
    for v547_6_byte in v547_6_cursor.child_mask().iter() {
      v547_6_cursor.descend_to_byte(v547_6_byte);
      let v547_6_tail = v547_6_cursor.make_map();
      v547_6_cursor.ascend(1);
      let v547_6_head = Path::from_slice(&[v547_6_byte]);
      let v548_2: Space = Space::new();
      v547_6.join_into((v548_2).clone());
    }
    drop(v547_6_cursor);
    let v547_7: Space = compose(&(v547_5),&(v547_6));
    drop(v547_5);
    drop(v547_6);
    let v547_8: Space = intersect(&(*CONSTANT_14),&(v547_2));
    drop(v547_2);
    let v547_9: Space = if has_head(&(v547_8)) { singleton(&[]) } else { Space::new() };
    drop(v547_8);
    let v547_12: Space = if (v547_9).is_empty() { Space::new() } else {
      let v549_10: Path = concat_path(&(*p0),&(v546_9_head));
      let mut v549_11 = Space::new();
      let mut v549_11_cursor = (v546_9_tail).read_zipper();
      for v549_11_byte in v549_11_cursor.child_mask().iter() {
        v549_11_cursor.descend_to_byte(v549_11_byte);
        let v549_11_tail = v549_11_cursor.make_map();
        v549_11_cursor.ascend(1);
        let v549_11_head = Path::from_slice(&[v549_11_byte]);
        let v550_2: Space = singleton(&(v549_11_head));
        let v550_3: Space = intersect(&(*CONSTANT_14),&(v550_2));
        let v550_4: Space = if has_head(&(v550_3)) { singleton(&[]) } else { Space::new() };
        drop(v550_3);
        let v550_5: Space = subtract(&(*CONSTANT_0),&(v550_4));
        drop(v550_4);
        let v550_7: Space = if (v550_5).is_empty() { Space::new() } else {
          let v551_6: Space = routine_22(c, &(v549_11_head), &(v549_10), &(v549_11_tail), &(*s1));
          compose(&(v550_5),&(v551_6))
        };
        drop(v550_5);
        let v550_8: Space = intersect(&(*CONSTANT_14),&(v550_2));
        drop(v550_2);
        let v550_9: Space = if has_head(&(v550_8)) { singleton(&[]) } else { Space::new() };
        drop(v550_8);
        let v550_11: Space = if (v550_9).is_empty() { Space::new() } else {
          let v552_10: Space = routine_23(c, &(v549_11_head), &(v549_10), &(v549_11_tail), &(*s1));
          compose(&(v550_9),&(v552_10))
        };
        drop(v550_9);
        let v550_12: Space = unite(&(v550_7),&(v550_11));
        v549_11.join_into((v550_12).clone());
      }
      drop(v549_11_cursor);
      drop(v549_10);
      compose(&(v547_9),&(v549_11))
    };
    drop(v547_9);
    let v547_13: Space = unite(&(v547_7),&(v547_12));
    drop(v547_7);
    v546_9.join_into((v547_13).clone());
  }
  drop(v546_9_cursor);
  (v546_9).clone()
}

fn routine_57(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v553_13 = Space::new();
  let mut v553_13_cursor = (*s0).read_zipper();
  for v553_13_byte in v553_13_cursor.child_mask().iter() {
    v553_13_cursor.descend_to_byte(v553_13_byte);
    let v553_13_tail = v553_13_cursor.make_map();
    v553_13_cursor.ascend(1);
    let v553_13_head = Path::from_slice(&[v553_13_byte]);
    let v554_2: Space = singleton(&(v553_13_head));
    let v554_3: Space = intersect(&(*CONSTANT_14),&(v554_2));
    let v554_4: Space = if has_head(&(v554_3)) { singleton(&[]) } else { Space::new() };
    drop(v554_3);
    let v554_5: Space = subtract(&(*CONSTANT_0),&(v554_4));
    drop(v554_4);
    let v554_8: Space = if (v554_5).is_empty() { Space::new() } else {
      let v555_6: Path = concat_path(&(*p0),&(v553_13_head));
      let mut v555_7 = Space::new();
      let mut v555_7_cursor = (v553_13_tail).read_zipper();
      for v555_7_byte in v555_7_cursor.child_mask().iter() {
        v555_7_cursor.descend_to_byte(v555_7_byte);
        let v555_7_tail = v555_7_cursor.make_map();
        v555_7_cursor.ascend(1);
        let v555_7_head = Path::from_slice(&[v555_7_byte]);
        let v556_2: Space = singleton(&(v555_7_head));
        let v556_3: Space = intersect(&(*CONSTANT_14),&(v556_2));
        let v556_4: Space = if has_head(&(v556_3)) { singleton(&[]) } else { Space::new() };
        drop(v556_3);
        let v556_5: Space = subtract(&(*CONSTANT_0),&(v556_4));
        drop(v556_4);
        let v556_8: Space = if (v556_5).is_empty() { Space::new() } else {
          let v557_6: Path = concat_path(&(v555_6),&(v555_7_head));
          let v557_7: Space = routine_98(c, &(v557_6), &(*p1), &(v555_7_tail), &(*s1));
          compose(&(v556_5),&(v557_7))
        };
        drop(v556_5);
        let v556_9: Space = intersect(&(*CONSTANT_14),&(v556_2));
        drop(v556_2);
        let v556_10: Space = if has_head(&(v556_9)) { singleton(&[]) } else { Space::new() };
        drop(v556_9);
        let v556_12: Space = if (v556_10).is_empty() { Space::new() } else {
          let v558_6: Path = concat_path(&(v555_6),&(v555_7_head));
          let v558_11: Space = routine_99(c, &(v558_6), &(*p1), &(v555_7_tail), &(*s1));
          drop(v558_6);
          compose(&(v556_10),&(v558_11))
        };
        drop(v556_10);
        let v556_13: Space = unite(&(v556_8),&(v556_12));
        v555_7.join_into((v556_13).clone());
      }
      drop(v555_7_cursor);
      compose(&(v554_5),&(v555_7))
    };
    drop(v554_5);
    let v554_9: Space = intersect(&(*CONSTANT_14),&(v554_2));
    drop(v554_2);
    let v554_10: Space = if has_head(&(v554_9)) { singleton(&[]) } else { Space::new() };
    drop(v554_9);
    let v554_12: Space = if (v554_10).is_empty() { Space::new() } else {
      let v559_6: Path = concat_path(&(*p0),&(v553_13_head));
      let mut v559_11 = Space::new();
      let mut v559_11_cursor = (v553_13_tail).read_zipper();
      for v559_11_byte in v559_11_cursor.child_mask().iter() {
        v559_11_cursor.descend_to_byte(v559_11_byte);
        let v559_11_tail = v559_11_cursor.make_map();
        v559_11_cursor.ascend(1);
        let v559_11_head = Path::from_slice(&[v559_11_byte]);
        let v560_2: Space = singleton(&(v559_11_head));
        let v560_3: Space = intersect(&(*CONSTANT_14),&(v560_2));
        let v560_4: Space = if has_head(&(v560_3)) { singleton(&[]) } else { Space::new() };
        drop(v560_3);
        let v560_5: Space = subtract(&(*CONSTANT_0),&(v560_4));
        drop(v560_4);
        let v560_8: Space = if (v560_5).is_empty() { Space::new() } else {
          let v561_6: Path = concat_path(&(v559_6),&(v559_11_head));
          let v561_7: Space = routine_98(c, &(v561_6), &(*p1), &(v559_11_tail), &(*s1));
          compose(&(v560_5),&(v561_7))
        };
        drop(v560_5);
        let v560_9: Space = intersect(&(*CONSTANT_14),&(v560_2));
        drop(v560_2);
        let v560_10: Space = if has_head(&(v560_9)) { singleton(&[]) } else { Space::new() };
        drop(v560_9);
        let v560_12: Space = if (v560_10).is_empty() { Space::new() } else {
          let v562_6: Path = concat_path(&(v559_6),&(v559_11_head));
          let v562_11: Space = routine_26(c, &(v562_6), &(*p1), &(v559_11_tail), &(*s1));
          drop(v562_6);
          compose(&(v560_10),&(v562_11))
        };
        drop(v560_10);
        let v560_13: Space = unite(&(v560_8),&(v560_12));
        v559_11.join_into((v560_13).clone());
      }
      drop(v559_11_cursor);
      drop(v559_6);
      compose(&(v554_10),&(v559_11))
    };
    drop(v554_10);
    let v554_13: Space = unite(&(v554_8),&(v554_12));
    v553_13.join_into((v554_13).clone());
  }
  drop(v553_13_cursor);
  (v553_13).clone()
}

fn routine_58(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v563_8: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v563_10: Space = unwrap(&(v563_8),&(*CONSTANT_10));
  drop(v563_8);
  let v563_11: Space = unwrap(&(v563_10),&(*p0));
  drop(v563_10);
  let mut v563_18 = Space::new();
  let mut v563_18_cursor = (*s0).read_zipper();
  for v563_18_byte in v563_18_cursor.child_mask().iter() {
    v563_18_cursor.descend_to_byte(v563_18_byte);
    let v563_18_tail = v563_18_cursor.make_map();
    v563_18_cursor.ascend(1);
    let v563_18_head = Path::from_slice(&[v563_18_byte]);
    let v564_2: Space = singleton(&(v563_18_head));
    let v564_3: Space = intersect(&(*CONSTANT_14),&(v564_2));
    let v564_4: Space = if has_head(&(v564_3)) { singleton(&[]) } else { Space::new() };
    drop(v564_3);
    let v564_5: Space = subtract(&(*CONSTANT_0),&(v564_4));
    drop(v564_4);
    let v564_8: Space = if (v564_5).is_empty() { Space::new() } else {
      let v565_6: Path = concat_path(&(*p0),&(v563_18_head));
      let mut v565_7 = Space::new();
      let mut v565_7_cursor = (v563_18_tail).read_zipper();
      for v565_7_byte in v565_7_cursor.child_mask().iter() {
        v565_7_cursor.descend_to_byte(v565_7_byte);
        let v565_7_tail = v565_7_cursor.make_map();
        v565_7_cursor.ascend(1);
        let v565_7_head = Path::from_slice(&[v565_7_byte]);
        let v566_2: Space = singleton(&(v565_7_head));
        let v566_3: Space = intersect(&(*CONSTANT_14),&(v566_2));
        let v566_4: Space = if has_head(&(v566_3)) { singleton(&[]) } else { Space::new() };
        drop(v566_3);
        let v566_5: Space = subtract(&(*CONSTANT_0),&(v566_4));
        drop(v566_4);
        let v566_8: Space = if (v566_5).is_empty() { Space::new() } else {
          let v567_6: Path = concat_path(&(v565_6),&(v565_7_head));
          let v567_7: Space = routine_98(c, &(v567_6), &(*p1), &(v565_7_tail), &(*s1));
          compose(&(v566_5),&(v567_7))
        };
        drop(v566_5);
        let v566_9: Space = intersect(&(*CONSTANT_14),&(v566_2));
        drop(v566_2);
        let v566_10: Space = if has_head(&(v566_9)) { singleton(&[]) } else { Space::new() };
        drop(v566_9);
        let v566_12: Space = if (v566_10).is_empty() { Space::new() } else {
          let v568_6: Path = concat_path(&(v565_6),&(v565_7_head));
          let v568_11: Space = routine_99(c, &(v568_6), &(*p1), &(v565_7_tail), &(*s1));
          drop(v568_6);
          compose(&(v566_10),&(v568_11))
        };
        drop(v566_10);
        let v566_13: Space = unite(&(v566_8),&(v566_12));
        v565_7.join_into((v566_13).clone());
      }
      drop(v565_7_cursor);
      drop(v565_6);
      compose(&(v564_5),&(v565_7))
    };
    drop(v564_5);
    let v564_9: Space = intersect(&(*CONSTANT_14),&(v564_2));
    drop(v564_2);
    let v564_10: Space = if has_head(&(v564_9)) { singleton(&[]) } else { Space::new() };
    drop(v564_9);
    let v564_13: Space = if (v564_10).is_empty() { Space::new() } else {
      let v569_11: Space = unwrap(&(v563_11),&(v563_18_head));
      let mut v569_12 = Space::new();
      let mut v569_12_cursor = (v569_11).read_zipper();
      for v569_12_byte in v569_12_cursor.child_mask().iter() {
        v569_12_cursor.descend_to_byte(v569_12_byte);
        let v569_12_tail = v569_12_cursor.make_map();
        v569_12_cursor.ascend(1);
        let v569_12_head = Path::from_slice(&[v569_12_byte]);
        let v570_2: Space = singleton(&(v569_12_head));
        let v570_3: Space = intersect(&(*CONSTANT_14),&(v570_2));
        let v570_4: Space = if has_head(&(v570_3)) { singleton(&[]) } else { Space::new() };
        drop(v570_3);
        let v570_5: Space = subtract(&(*CONSTANT_0),&(v570_4));
        drop(v570_4);
        let v570_7: Space = if (v570_5).is_empty() { Space::new() } else {
          let v571_6: Space = routine_59(c, &(v569_12_head), &(*p1), &(v569_12_tail));
          compose(&(v570_5),&(v571_6))
        };
        drop(v570_5);
        let v570_8: Space = intersect(&(*CONSTANT_14),&(v570_2));
        drop(v570_2);
        let v570_9: Space = if has_head(&(v570_8)) { singleton(&[]) } else { Space::new() };
        drop(v570_8);
        let v570_11: Space = if (v570_9).is_empty() { Space::new() } else {
          let v572_10: Space = routine_60(c, &(v569_12_head), &(*p1), &(v569_12_tail));
          compose(&(v570_9),&(v572_10))
        };
        drop(v570_9);
        let v570_12: Space = unite(&(v570_7),&(v570_11));
        v569_12.join_into((v570_12).clone());
      }
      drop(v569_12_cursor);
      drop(v569_11);
      compose(&(v564_10),&(v569_12))
    };
    drop(v564_10);
    let v564_14: Space = unite(&(v564_8),&(v564_13));
    v563_18.join_into((v564_14).clone());
  }
  drop(v563_18_cursor);
  drop(v563_11);
  (v563_18).clone()
}

fn routine_59(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v573_12 = Space::new();
  let mut v573_12_cursor = (*s0).read_zipper();
  for v573_12_byte in v573_12_cursor.child_mask().iter() {
    v573_12_cursor.descend_to_byte(v573_12_byte);
    let v573_12_tail = v573_12_cursor.make_map();
    v573_12_cursor.ascend(1);
    let v573_12_head = Path::from_slice(&[v573_12_byte]);
    let v574_2: Space = singleton(&(v573_12_head));
    let v574_3: Space = intersect(&(*CONSTANT_14),&(v574_2));
    let v574_4: Space = if has_head(&(v574_3)) { singleton(&[]) } else { Space::new() };
    drop(v574_3);
    let v574_5: Space = subtract(&(*CONSTANT_0),&(v574_4));
    drop(v574_4);
    let v574_8: Space = if (v574_5).is_empty() { Space::new() } else {
      let v575_6: Path = concat_path(&(*p0),&(v573_12_head));
      let mut v575_7 = Space::new();
      let mut v575_7_cursor = (v573_12_tail).read_zipper();
      for v575_7_byte in v575_7_cursor.child_mask().iter() {
        v575_7_cursor.descend_to_byte(v575_7_byte);
        let v575_7_tail = v575_7_cursor.make_map();
        v575_7_cursor.ascend(1);
        let v575_7_head = Path::from_slice(&[v575_7_byte]);
        let v576_2: Space = singleton(&(v575_7_head));
        let v576_3: Space = intersect(&(*CONSTANT_14),&(v576_2));
        let v576_4: Space = if has_head(&(v576_3)) { singleton(&[]) } else { Space::new() };
        drop(v576_3);
        let v576_5: Space = subtract(&(*CONSTANT_0),&(v576_4));
        drop(v576_4);
        let v576_8: Space = if (v576_5).is_empty() { Space::new() } else {
          let v577_6: Path = concat_path(&(v575_6),&(v575_7_head));
          let v577_7: Space = routine_100(c, &(v577_6), &(*p1), &(v575_7_tail));
          compose(&(v576_5),&(v577_7))
        };
        drop(v576_5);
        let v576_9: Space = intersect(&(*CONSTANT_14),&(v576_2));
        drop(v576_2);
        let v576_10: Space = if has_head(&(v576_9)) { singleton(&[]) } else { Space::new() };
        drop(v576_9);
        let v576_12: Space = if (v576_10).is_empty() { Space::new() } else {
          let v578_6: Path = concat_path(&(v575_6),&(v575_7_head));
          let v578_11: Space = routine_101(c, &(v578_6), &(*p1), &(v575_7_tail));
          drop(v578_6);
          compose(&(v576_10),&(v578_11))
        };
        drop(v576_10);
        let v576_13: Space = unite(&(v576_8),&(v576_12));
        v575_7.join_into((v576_13).clone());
      }
      drop(v575_7_cursor);
      compose(&(v574_5),&(v575_7))
    };
    drop(v574_5);
    let v574_9: Space = intersect(&(*CONSTANT_14),&(v574_2));
    drop(v574_2);
    let v574_10: Space = if has_head(&(v574_9)) { singleton(&[]) } else { Space::new() };
    drop(v574_9);
    let v574_12: Space = if (v574_10).is_empty() { Space::new() } else {
      let v579_6: Path = concat_path(&(*p0),&(v573_12_head));
      let mut v579_11 = Space::new();
      let mut v579_11_cursor = (v573_12_tail).read_zipper();
      for v579_11_byte in v579_11_cursor.child_mask().iter() {
        v579_11_cursor.descend_to_byte(v579_11_byte);
        let v579_11_tail = v579_11_cursor.make_map();
        v579_11_cursor.ascend(1);
        let v579_11_head = Path::from_slice(&[v579_11_byte]);
        let v580_2: Space = singleton(&(v579_11_head));
        let v580_3: Space = intersect(&(*CONSTANT_14),&(v580_2));
        let v580_4: Space = if has_head(&(v580_3)) { singleton(&[]) } else { Space::new() };
        drop(v580_3);
        let v580_5: Space = subtract(&(*CONSTANT_0),&(v580_4));
        drop(v580_4);
        let v580_8: Space = if (v580_5).is_empty() { Space::new() } else {
          let v581_6: Path = concat_path(&(v579_6),&(v579_11_head));
          let v581_7: Space = routine_100(c, &(v581_6), &(*p1), &(v579_11_tail));
          compose(&(v580_5),&(v581_7))
        };
        drop(v580_5);
        let v580_9: Space = intersect(&(*CONSTANT_14),&(v580_2));
        drop(v580_2);
        let v580_10: Space = if has_head(&(v580_9)) { singleton(&[]) } else { Space::new() };
        drop(v580_9);
        let v580_12: Space = if (v580_10).is_empty() { Space::new() } else {
          let v582_6: Path = concat_path(&(v579_6),&(v579_11_head));
          let v582_11: Space = routine_65(c, &(v582_6), &(*p1), &(v579_11_tail));
          drop(v582_6);
          compose(&(v580_10),&(v582_11))
        };
        drop(v580_10);
        let v580_13: Space = unite(&(v580_8),&(v580_12));
        v579_11.join_into((v580_13).clone());
      }
      drop(v579_11_cursor);
      drop(v579_6);
      compose(&(v574_10),&(v579_11))
    };
    drop(v574_10);
    let v574_13: Space = unite(&(v574_8),&(v574_12));
    v573_12.join_into((v574_13).clone());
  }
  drop(v573_12_cursor);
  (v573_12).clone()
}

fn routine_60(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v583_9 = Space::new();
  let mut v583_9_cursor = (*s0).read_zipper();
  for v583_9_byte in v583_9_cursor.child_mask().iter() {
    v583_9_cursor.descend_to_byte(v583_9_byte);
    let v583_9_tail = v583_9_cursor.make_map();
    v583_9_cursor.ascend(1);
    let v583_9_head = Path::from_slice(&[v583_9_byte]);
    let v584_2: Space = singleton(&(v583_9_head));
    let v584_3: Space = intersect(&(*CONSTANT_14),&(v584_2));
    let v584_4: Space = if has_head(&(v584_3)) { singleton(&[]) } else { Space::new() };
    drop(v584_3);
    let v584_5: Space = subtract(&(*CONSTANT_0),&(v584_4));
    drop(v584_4);
    let v584_8: Space = if (v584_5).is_empty() { Space::new() } else {
      let v585_6: Path = concat_path(&(*p0),&(v583_9_head));
      let mut v585_7 = Space::new();
      let mut v585_7_cursor = (v583_9_tail).read_zipper();
      for v585_7_byte in v585_7_cursor.child_mask().iter() {
        v585_7_cursor.descend_to_byte(v585_7_byte);
        let v585_7_tail = v585_7_cursor.make_map();
        v585_7_cursor.ascend(1);
        let v585_7_head = Path::from_slice(&[v585_7_byte]);
        let v586_2: Space = singleton(&(v585_7_head));
        let v586_3: Space = intersect(&(*CONSTANT_14),&(v586_2));
        let v586_4: Space = if has_head(&(v586_3)) { singleton(&[]) } else { Space::new() };
        drop(v586_3);
        let v586_5: Space = subtract(&(*CONSTANT_0),&(v586_4));
        drop(v586_4);
        let v586_8: Space = if (v586_5).is_empty() { Space::new() } else {
          let v587_6: Path = concat_path(&(v585_6),&(v585_7_head));
          let v587_7: Space = routine_100(c, &(v587_6), &(*p1), &(v585_7_tail));
          compose(&(v586_5),&(v587_7))
        };
        drop(v586_5);
        let v586_9: Space = intersect(&(*CONSTANT_14),&(v586_2));
        drop(v586_2);
        let v586_10: Space = if has_head(&(v586_9)) { singleton(&[]) } else { Space::new() };
        drop(v586_9);
        let v586_12: Space = if (v586_10).is_empty() { Space::new() } else {
          let v588_6: Path = concat_path(&(v585_6),&(v585_7_head));
          let v588_11: Space = routine_101(c, &(v588_6), &(*p1), &(v585_7_tail));
          drop(v588_6);
          compose(&(v586_10),&(v588_11))
        };
        drop(v586_10);
        let v586_13: Space = unite(&(v586_8),&(v586_12));
        v585_7.join_into((v586_13).clone());
      }
      drop(v585_7_cursor);
      compose(&(v584_5),&(v585_7))
    };
    drop(v584_5);
    let v584_9: Space = intersect(&(*CONSTANT_14),&(v584_2));
    drop(v584_2);
    let v584_10: Space = if has_head(&(v584_9)) { singleton(&[]) } else { Space::new() };
    drop(v584_9);
    let v584_11: Space = compose(&(v584_10),&(v583_9_tail));
    drop(v584_10);
    let v589_6: Path = concat_path(&(*p0),&(v583_9_head));
    let v584_12: Space = wrap(&(v584_11),&(v589_6));
    drop(v584_11);
    let v584_13: Space = wrap(&(v584_12),&(*p1));
    drop(v584_12);
    let v584_14: Space = unite(&(v584_8),&(v584_13));
    drop(v584_13);
    v583_9.join_into((v584_14).clone());
  }
  drop(v583_9_cursor);
  (v583_9).clone()
}

fn routine_61(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v590_13 = Space::new();
  let mut v590_13_cursor = (*s0).read_zipper();
  for v590_13_byte in v590_13_cursor.child_mask().iter() {
    v590_13_cursor.descend_to_byte(v590_13_byte);
    let v590_13_tail = v590_13_cursor.make_map();
    v590_13_cursor.ascend(1);
    let v590_13_head = Path::from_slice(&[v590_13_byte]);
    let v591_2: Space = singleton(&(v590_13_head));
    let v591_3: Space = intersect(&(*CONSTANT_14),&(v591_2));
    let v591_4: Space = if has_head(&(v591_3)) { singleton(&[]) } else { Space::new() };
    drop(v591_3);
    let v591_5: Space = subtract(&(*CONSTANT_0),&(v591_4));
    drop(v591_4);
    let v591_8: Space = if (v591_5).is_empty() { Space::new() } else {
      let v592_6: Path = concat_path(&(*p0),&(v590_13_head));
      let mut v592_7 = Space::new();
      let mut v592_7_cursor = (v590_13_tail).read_zipper();
      for v592_7_byte in v592_7_cursor.child_mask().iter() {
        v592_7_cursor.descend_to_byte(v592_7_byte);
        let v592_7_tail = v592_7_cursor.make_map();
        v592_7_cursor.ascend(1);
        let v592_7_head = Path::from_slice(&[v592_7_byte]);
        let v593_2: Space = singleton(&(v592_7_head));
        let v593_3: Space = intersect(&(*CONSTANT_14),&(v593_2));
        let v593_4: Space = if has_head(&(v593_3)) { singleton(&[]) } else { Space::new() };
        drop(v593_3);
        let v593_5: Space = subtract(&(*CONSTANT_0),&(v593_4));
        drop(v593_4);
        let v593_8: Space = if (v593_5).is_empty() { Space::new() } else {
          let v594_6: Path = concat_path(&(v592_6),&(v592_7_head));
          let v594_7: Space = routine_102(c, &(v594_6), &(*p1), &(v592_7_tail), &(*s1));
          compose(&(v593_5),&(v594_7))
        };
        drop(v593_5);
        let v593_9: Space = intersect(&(*CONSTANT_14),&(v593_2));
        drop(v593_2);
        let v593_10: Space = if has_head(&(v593_9)) { singleton(&[]) } else { Space::new() };
        drop(v593_9);
        let v593_12: Space = if (v593_10).is_empty() { Space::new() } else {
          let v595_6: Path = concat_path(&(v592_6),&(v592_7_head));
          let v595_11: Space = routine_103(c, &(v595_6), &(*p1), &(v592_7_tail), &(*s1));
          drop(v595_6);
          compose(&(v593_10),&(v595_11))
        };
        drop(v593_10);
        let v593_13: Space = unite(&(v593_8),&(v593_12));
        v592_7.join_into((v593_13).clone());
      }
      drop(v592_7_cursor);
      compose(&(v591_5),&(v592_7))
    };
    drop(v591_5);
    let v591_9: Space = intersect(&(*CONSTANT_14),&(v591_2));
    drop(v591_2);
    let v591_10: Space = if has_head(&(v591_9)) { singleton(&[]) } else { Space::new() };
    drop(v591_9);
    let v591_12: Space = if (v591_10).is_empty() { Space::new() } else {
      let v596_6: Path = concat_path(&(*p0),&(v590_13_head));
      let mut v596_11 = Space::new();
      let mut v596_11_cursor = (v590_13_tail).read_zipper();
      for v596_11_byte in v596_11_cursor.child_mask().iter() {
        v596_11_cursor.descend_to_byte(v596_11_byte);
        let v596_11_tail = v596_11_cursor.make_map();
        v596_11_cursor.ascend(1);
        let v596_11_head = Path::from_slice(&[v596_11_byte]);
        let v597_2: Space = singleton(&(v596_11_head));
        let v597_3: Space = intersect(&(*CONSTANT_14),&(v597_2));
        let v597_4: Space = if has_head(&(v597_3)) { singleton(&[]) } else { Space::new() };
        drop(v597_3);
        let v597_5: Space = subtract(&(*CONSTANT_0),&(v597_4));
        drop(v597_4);
        let v597_8: Space = if (v597_5).is_empty() { Space::new() } else {
          let v598_6: Path = concat_path(&(v596_6),&(v596_11_head));
          let v598_7: Space = routine_102(c, &(v598_6), &(*p1), &(v596_11_tail), &(*s1));
          compose(&(v597_5),&(v598_7))
        };
        drop(v597_5);
        let v597_9: Space = intersect(&(*CONSTANT_14),&(v597_2));
        drop(v597_2);
        let v597_10: Space = if has_head(&(v597_9)) { singleton(&[]) } else { Space::new() };
        drop(v597_9);
        let v597_12: Space = if (v597_10).is_empty() { Space::new() } else {
          let v599_6: Path = concat_path(&(v596_6),&(v596_11_head));
          let v599_11: Space = routine_26(c, &(v599_6), &(*p1), &(v596_11_tail), &(*s1));
          drop(v599_6);
          compose(&(v597_10),&(v599_11))
        };
        drop(v597_10);
        let v597_13: Space = unite(&(v597_8),&(v597_12));
        v596_11.join_into((v597_13).clone());
      }
      drop(v596_11_cursor);
      drop(v596_6);
      compose(&(v591_10),&(v596_11))
    };
    drop(v591_10);
    let v591_13: Space = unite(&(v591_8),&(v591_12));
    v590_13.join_into((v591_13).clone());
  }
  drop(v590_13_cursor);
  (v590_13).clone()
}

fn routine_62(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v600_8: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v600_10: Space = unwrap(&(v600_8),&(*CONSTANT_10));
  drop(v600_8);
  let v600_11: Space = unwrap(&(v600_10),&(*p0));
  drop(v600_10);
  let mut v600_18 = Space::new();
  let mut v600_18_cursor = (*s0).read_zipper();
  for v600_18_byte in v600_18_cursor.child_mask().iter() {
    v600_18_cursor.descend_to_byte(v600_18_byte);
    let v600_18_tail = v600_18_cursor.make_map();
    v600_18_cursor.ascend(1);
    let v600_18_head = Path::from_slice(&[v600_18_byte]);
    let v601_2: Space = singleton(&(v600_18_head));
    let v601_3: Space = intersect(&(*CONSTANT_14),&(v601_2));
    let v601_4: Space = if has_head(&(v601_3)) { singleton(&[]) } else { Space::new() };
    drop(v601_3);
    let v601_5: Space = subtract(&(*CONSTANT_0),&(v601_4));
    drop(v601_4);
    let v601_8: Space = if (v601_5).is_empty() { Space::new() } else {
      let v602_6: Path = concat_path(&(*p0),&(v600_18_head));
      let mut v602_7 = Space::new();
      let mut v602_7_cursor = (v600_18_tail).read_zipper();
      for v602_7_byte in v602_7_cursor.child_mask().iter() {
        v602_7_cursor.descend_to_byte(v602_7_byte);
        let v602_7_tail = v602_7_cursor.make_map();
        v602_7_cursor.ascend(1);
        let v602_7_head = Path::from_slice(&[v602_7_byte]);
        let v603_2: Space = singleton(&(v602_7_head));
        let v603_3: Space = intersect(&(*CONSTANT_14),&(v603_2));
        let v603_4: Space = if has_head(&(v603_3)) { singleton(&[]) } else { Space::new() };
        drop(v603_3);
        let v603_5: Space = subtract(&(*CONSTANT_0),&(v603_4));
        drop(v603_4);
        let v603_8: Space = if (v603_5).is_empty() { Space::new() } else {
          let v604_6: Path = concat_path(&(v602_6),&(v602_7_head));
          let v604_7: Space = routine_102(c, &(v604_6), &(*p1), &(v602_7_tail), &(*s1));
          compose(&(v603_5),&(v604_7))
        };
        drop(v603_5);
        let v603_9: Space = intersect(&(*CONSTANT_14),&(v603_2));
        drop(v603_2);
        let v603_10: Space = if has_head(&(v603_9)) { singleton(&[]) } else { Space::new() };
        drop(v603_9);
        let v603_12: Space = if (v603_10).is_empty() { Space::new() } else {
          let v605_6: Path = concat_path(&(v602_6),&(v602_7_head));
          let v605_11: Space = routine_103(c, &(v605_6), &(*p1), &(v602_7_tail), &(*s1));
          drop(v605_6);
          compose(&(v603_10),&(v605_11))
        };
        drop(v603_10);
        let v603_13: Space = unite(&(v603_8),&(v603_12));
        v602_7.join_into((v603_13).clone());
      }
      drop(v602_7_cursor);
      drop(v602_6);
      compose(&(v601_5),&(v602_7))
    };
    drop(v601_5);
    let v601_9: Space = intersect(&(*CONSTANT_14),&(v601_2));
    drop(v601_2);
    let v601_10: Space = if has_head(&(v601_9)) { singleton(&[]) } else { Space::new() };
    drop(v601_9);
    let v601_13: Space = if (v601_10).is_empty() { Space::new() } else {
      let v606_11: Space = unwrap(&(v600_11),&(v600_18_head));
      let mut v606_12 = Space::new();
      let mut v606_12_cursor = (v606_11).read_zipper();
      for v606_12_byte in v606_12_cursor.child_mask().iter() {
        v606_12_cursor.descend_to_byte(v606_12_byte);
        let v606_12_tail = v606_12_cursor.make_map();
        v606_12_cursor.ascend(1);
        let v606_12_head = Path::from_slice(&[v606_12_byte]);
        let v607_2: Space = singleton(&(v606_12_head));
        let v607_3: Space = intersect(&(*CONSTANT_14),&(v607_2));
        let v607_4: Space = if has_head(&(v607_3)) { singleton(&[]) } else { Space::new() };
        drop(v607_3);
        let v607_5: Space = subtract(&(*CONSTANT_0),&(v607_4));
        drop(v607_4);
        let v607_7: Space = if (v607_5).is_empty() { Space::new() } else {
          let v608_6: Space = routine_59(c, &(v606_12_head), &(*p1), &(v606_12_tail));
          compose(&(v607_5),&(v608_6))
        };
        drop(v607_5);
        let v607_8: Space = intersect(&(*CONSTANT_14),&(v607_2));
        drop(v607_2);
        let v607_9: Space = if has_head(&(v607_8)) { singleton(&[]) } else { Space::new() };
        drop(v607_8);
        let v607_11: Space = if (v607_9).is_empty() { Space::new() } else {
          let v609_10: Space = routine_60(c, &(v606_12_head), &(*p1), &(v606_12_tail));
          compose(&(v607_9),&(v609_10))
        };
        drop(v607_9);
        let v607_12: Space = unite(&(v607_7),&(v607_11));
        v606_12.join_into((v607_12).clone());
      }
      drop(v606_12_cursor);
      drop(v606_11);
      compose(&(v601_10),&(v606_12))
    };
    drop(v601_10);
    let v601_14: Space = unite(&(v601_8),&(v601_13));
    v600_18.join_into((v601_14).clone());
  }
  drop(v600_18_cursor);
  drop(v600_11);
  (v600_18).clone()
}

fn routine_63(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v610_12 = Space::new();
  let mut v610_12_cursor = (*s0).read_zipper();
  for v610_12_byte in v610_12_cursor.child_mask().iter() {
    v610_12_cursor.descend_to_byte(v610_12_byte);
    let v610_12_tail = v610_12_cursor.make_map();
    v610_12_cursor.ascend(1);
    let v610_12_head = Path::from_slice(&[v610_12_byte]);
    let v611_2: Space = singleton(&(v610_12_head));
    let v611_3: Space = intersect(&(*CONSTANT_14),&(v611_2));
    let v611_4: Space = if has_head(&(v611_3)) { singleton(&[]) } else { Space::new() };
    drop(v611_3);
    let v611_5: Space = subtract(&(*CONSTANT_0),&(v611_4));
    drop(v611_4);
    let v611_8: Space = if (v611_5).is_empty() { Space::new() } else {
      let v612_6: Path = concat_path(&(*p0),&(v610_12_head));
      let mut v612_7 = Space::new();
      let mut v612_7_cursor = (v610_12_tail).read_zipper();
      for v612_7_byte in v612_7_cursor.child_mask().iter() {
        v612_7_cursor.descend_to_byte(v612_7_byte);
        let v612_7_tail = v612_7_cursor.make_map();
        v612_7_cursor.ascend(1);
        let v612_7_head = Path::from_slice(&[v612_7_byte]);
        let v613_2: Space = singleton(&(v612_7_head));
        let v613_3: Space = intersect(&(*CONSTANT_14),&(v613_2));
        let v613_4: Space = if has_head(&(v613_3)) { singleton(&[]) } else { Space::new() };
        drop(v613_3);
        let v613_5: Space = subtract(&(*CONSTANT_0),&(v613_4));
        drop(v613_4);
        let v613_8: Space = if (v613_5).is_empty() { Space::new() } else {
          let v614_6: Path = concat_path(&(v612_6),&(v612_7_head));
          let v614_7: Space = routine_104(c, &(v614_6), &(*p1), &(v612_7_tail));
          compose(&(v613_5),&(v614_7))
        };
        drop(v613_5);
        let v613_9: Space = intersect(&(*CONSTANT_14),&(v613_2));
        drop(v613_2);
        let v613_10: Space = if has_head(&(v613_9)) { singleton(&[]) } else { Space::new() };
        drop(v613_9);
        let v613_12: Space = if (v613_10).is_empty() { Space::new() } else {
          let v615_6: Path = concat_path(&(v612_6),&(v612_7_head));
          let v615_11: Space = routine_105(c, &(v615_6), &(*p1), &(v612_7_tail));
          drop(v615_6);
          compose(&(v613_10),&(v615_11))
        };
        drop(v613_10);
        let v613_13: Space = unite(&(v613_8),&(v613_12));
        v612_7.join_into((v613_13).clone());
      }
      drop(v612_7_cursor);
      compose(&(v611_5),&(v612_7))
    };
    drop(v611_5);
    let v611_9: Space = intersect(&(*CONSTANT_14),&(v611_2));
    drop(v611_2);
    let v611_10: Space = if has_head(&(v611_9)) { singleton(&[]) } else { Space::new() };
    drop(v611_9);
    let v611_12: Space = if (v611_10).is_empty() { Space::new() } else {
      let v616_6: Path = concat_path(&(*p0),&(v610_12_head));
      let mut v616_11 = Space::new();
      let mut v616_11_cursor = (v610_12_tail).read_zipper();
      for v616_11_byte in v616_11_cursor.child_mask().iter() {
        v616_11_cursor.descend_to_byte(v616_11_byte);
        let v616_11_tail = v616_11_cursor.make_map();
        v616_11_cursor.ascend(1);
        let v616_11_head = Path::from_slice(&[v616_11_byte]);
        let v617_2: Space = singleton(&(v616_11_head));
        let v617_3: Space = intersect(&(*CONSTANT_14),&(v617_2));
        let v617_4: Space = if has_head(&(v617_3)) { singleton(&[]) } else { Space::new() };
        drop(v617_3);
        let v617_5: Space = subtract(&(*CONSTANT_0),&(v617_4));
        drop(v617_4);
        let v617_8: Space = if (v617_5).is_empty() { Space::new() } else {
          let v618_6: Path = concat_path(&(v616_6),&(v616_11_head));
          let v618_7: Space = routine_104(c, &(v618_6), &(*p1), &(v616_11_tail));
          compose(&(v617_5),&(v618_7))
        };
        drop(v617_5);
        let v617_9: Space = intersect(&(*CONSTANT_14),&(v617_2));
        drop(v617_2);
        let v617_10: Space = if has_head(&(v617_9)) { singleton(&[]) } else { Space::new() };
        drop(v617_9);
        let v617_12: Space = if (v617_10).is_empty() { Space::new() } else {
          let v619_6: Path = concat_path(&(v616_6),&(v616_11_head));
          let v619_11: Space = routine_65(c, &(v619_6), &(*p1), &(v616_11_tail));
          drop(v619_6);
          compose(&(v617_10),&(v619_11))
        };
        drop(v617_10);
        let v617_13: Space = unite(&(v617_8),&(v617_12));
        v616_11.join_into((v617_13).clone());
      }
      drop(v616_11_cursor);
      drop(v616_6);
      compose(&(v611_10),&(v616_11))
    };
    drop(v611_10);
    let v611_13: Space = unite(&(v611_8),&(v611_12));
    v610_12.join_into((v611_13).clone());
  }
  drop(v610_12_cursor);
  (v610_12).clone()
}

fn routine_64(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v620_9 = Space::new();
  let mut v620_9_cursor = (*s0).read_zipper();
  for v620_9_byte in v620_9_cursor.child_mask().iter() {
    v620_9_cursor.descend_to_byte(v620_9_byte);
    let v620_9_tail = v620_9_cursor.make_map();
    v620_9_cursor.ascend(1);
    let v620_9_head = Path::from_slice(&[v620_9_byte]);
    let v621_2: Space = singleton(&(v620_9_head));
    let v621_3: Space = intersect(&(*CONSTANT_14),&(v621_2));
    let v621_4: Space = if has_head(&(v621_3)) { singleton(&[]) } else { Space::new() };
    drop(v621_3);
    let v621_5: Space = subtract(&(*CONSTANT_0),&(v621_4));
    drop(v621_4);
    let v621_8: Space = if (v621_5).is_empty() { Space::new() } else {
      let v622_6: Path = concat_path(&(*p0),&(v620_9_head));
      let mut v622_7 = Space::new();
      let mut v622_7_cursor = (v620_9_tail).read_zipper();
      for v622_7_byte in v622_7_cursor.child_mask().iter() {
        v622_7_cursor.descend_to_byte(v622_7_byte);
        let v622_7_tail = v622_7_cursor.make_map();
        v622_7_cursor.ascend(1);
        let v622_7_head = Path::from_slice(&[v622_7_byte]);
        let v623_2: Space = singleton(&(v622_7_head));
        let v623_3: Space = intersect(&(*CONSTANT_14),&(v623_2));
        let v623_4: Space = if has_head(&(v623_3)) { singleton(&[]) } else { Space::new() };
        drop(v623_3);
        let v623_5: Space = subtract(&(*CONSTANT_0),&(v623_4));
        drop(v623_4);
        let v623_8: Space = if (v623_5).is_empty() { Space::new() } else {
          let v624_6: Path = concat_path(&(v622_6),&(v622_7_head));
          let v624_7: Space = routine_104(c, &(v624_6), &(*p1), &(v622_7_tail));
          compose(&(v623_5),&(v624_7))
        };
        drop(v623_5);
        let v623_9: Space = intersect(&(*CONSTANT_14),&(v623_2));
        drop(v623_2);
        let v623_10: Space = if has_head(&(v623_9)) { singleton(&[]) } else { Space::new() };
        drop(v623_9);
        let v623_12: Space = if (v623_10).is_empty() { Space::new() } else {
          let v625_6: Path = concat_path(&(v622_6),&(v622_7_head));
          let v625_11: Space = routine_105(c, &(v625_6), &(*p1), &(v622_7_tail));
          drop(v625_6);
          compose(&(v623_10),&(v625_11))
        };
        drop(v623_10);
        let v623_13: Space = unite(&(v623_8),&(v623_12));
        v622_7.join_into((v623_13).clone());
      }
      drop(v622_7_cursor);
      compose(&(v621_5),&(v622_7))
    };
    drop(v621_5);
    let v621_9: Space = intersect(&(*CONSTANT_14),&(v621_2));
    drop(v621_2);
    let v621_10: Space = if has_head(&(v621_9)) { singleton(&[]) } else { Space::new() };
    drop(v621_9);
    let v621_11: Space = compose(&(v621_10),&(v620_9_tail));
    drop(v621_10);
    let v626_6: Path = concat_path(&(*p0),&(v620_9_head));
    let v621_12: Space = wrap(&(v621_11),&(v626_6));
    drop(v621_11);
    let v621_13: Space = wrap(&(v621_12),&(*p1));
    drop(v621_12);
    let v621_14: Space = unite(&(v621_8),&(v621_13));
    drop(v621_13);
    v620_9.join_into((v621_14).clone());
  }
  drop(v620_9_cursor);
  (v620_9).clone()
}

fn routine_65(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v627_3: Space = wrap(&(*s0),&(*p0));
  let v627_4: Space = wrap(&(v627_3),&(*p1));
  drop(v627_3);
  (v627_4).clone()
}

fn routine_66(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v628_6 = Space::new();
  let mut v628_6_cursor = (*s0).read_zipper();
  for v628_6_byte in v628_6_cursor.child_mask().iter() {
    v628_6_cursor.descend_to_byte(v628_6_byte);
    let v628_6_tail = v628_6_cursor.make_map();
    v628_6_cursor.ascend(1);
    let v628_6_head = Path::from_slice(&[v628_6_byte]);
    let v629_2: Space = singleton(&(v628_6_head));
    let v629_3: Space = intersect(&(*CONSTANT_14),&(v629_2));
    let v629_4: Space = if has_head(&(v629_3)) { singleton(&[]) } else { Space::new() };
    drop(v629_3);
    let v629_5: Space = subtract(&(*CONSTANT_0),&(v629_4));
    drop(v629_4);
    let mut v629_6 = Space::new();
    let mut v629_6_cursor = (v628_6_tail).read_zipper();
    for v629_6_byte in v629_6_cursor.child_mask().iter() {
      v629_6_cursor.descend_to_byte(v629_6_byte);
      let v629_6_tail = v629_6_cursor.make_map();
      v629_6_cursor.ascend(1);
      let v629_6_head = Path::from_slice(&[v629_6_byte]);
      let v630_2: Space = Space::new();
      v629_6.join_into((v630_2).clone());
    }
    drop(v629_6_cursor);
    let v629_7: Space = compose(&(v629_5),&(v629_6));
    drop(v629_5);
    drop(v629_6);
    let v629_8: Space = intersect(&(*CONSTANT_14),&(v629_2));
    drop(v629_2);
    let v629_9: Space = if has_head(&(v629_8)) { singleton(&[]) } else { Space::new() };
    drop(v629_8);
    let v629_12: Space = if (v629_9).is_empty() { Space::new() } else {
      let v631_10: Path = concat_path(&(*p0),&(v628_6_head));
      let mut v631_11 = Space::new();
      let mut v631_11_cursor = (v628_6_tail).read_zipper();
      for v631_11_byte in v631_11_cursor.child_mask().iter() {
        v631_11_cursor.descend_to_byte(v631_11_byte);
        let v631_11_tail = v631_11_cursor.make_map();
        v631_11_cursor.ascend(1);
        let v631_11_head = Path::from_slice(&[v631_11_byte]);
        let v632_2: Space = singleton(&(v631_11_head));
        let v632_3: Space = intersect(&(*CONSTANT_14),&(v632_2));
        drop(v632_2);
        let v632_4: Space = if has_head(&(v632_3)) { singleton(&[]) } else { Space::new() };
        drop(v632_3);
        let v632_7: Space = if (v632_4).is_empty() { Space::new() } else {
          let v633_5: Path = concat_path(&(v631_10),&(v631_11_head));
          let v633_6: Space = routine_8(c, &(v633_5), &(v631_11_tail));
          drop(v633_5);
          compose(&(v632_4),&(v633_6))
        };
        drop(v632_4);
        v631_11.join_into((v632_7).clone());
      }
      drop(v631_11_cursor);
      drop(v631_10);
      compose(&(v629_9),&(v631_11))
    };
    drop(v629_9);
    let v629_13: Space = unite(&(v629_7),&(v629_12));
    drop(v629_7);
    v628_6.join_into((v629_13).clone());
  }
  drop(v628_6_cursor);
  (v628_6).clone()
}

fn routine_67(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v634_8 = Space::new();
  let mut v634_8_cursor = (*s0).read_zipper();
  for v634_8_byte in v634_8_cursor.child_mask().iter() {
    v634_8_cursor.descend_to_byte(v634_8_byte);
    let v634_8_tail = v634_8_cursor.make_map();
    v634_8_cursor.ascend(1);
    let v634_8_head = Path::from_slice(&[v634_8_byte]);
    let v635_2: Space = singleton(&(v634_8_head));
    let v635_3: Space = intersect(&(*CONSTANT_14),&(v635_2));
    let v635_4: Space = if has_head(&(v635_3)) { singleton(&[]) } else { Space::new() };
    drop(v635_3);
    let v635_5: Space = subtract(&(*CONSTANT_0),&(v635_4));
    drop(v635_4);
    let mut v635_6 = Space::new();
    let mut v635_6_cursor = (v634_8_tail).read_zipper();
    for v635_6_byte in v635_6_cursor.child_mask().iter() {
      v635_6_cursor.descend_to_byte(v635_6_byte);
      let v635_6_tail = v635_6_cursor.make_map();
      v635_6_cursor.ascend(1);
      let v635_6_head = Path::from_slice(&[v635_6_byte]);
      let v636_2: Space = Space::new();
      v635_6.join_into((v636_2).clone());
    }
    drop(v635_6_cursor);
    let v635_7: Space = compose(&(v635_5),&(v635_6));
    drop(v635_5);
    drop(v635_6);
    let v635_8: Space = intersect(&(*CONSTANT_14),&(v635_2));
    drop(v635_2);
    let v635_9: Space = if has_head(&(v635_8)) { singleton(&[]) } else { Space::new() };
    drop(v635_8);
    let v635_12: Space = if (v635_9).is_empty() { Space::new() } else {
      let v637_10: Path = concat_path(&(*p0),&(v634_8_head));
      let mut v637_11 = Space::new();
      let mut v637_11_cursor = (v634_8_tail).read_zipper();
      for v637_11_byte in v637_11_cursor.child_mask().iter() {
        v637_11_cursor.descend_to_byte(v637_11_byte);
        let v637_11_tail = v637_11_cursor.make_map();
        v637_11_cursor.ascend(1);
        let v637_11_head = Path::from_slice(&[v637_11_byte]);
        let v638_2: Space = singleton(&(v637_11_head));
        let v638_3: Space = intersect(&(*CONSTANT_14),&(v638_2));
        let v638_4: Space = if has_head(&(v638_3)) { singleton(&[]) } else { Space::new() };
        drop(v638_3);
        let v638_5: Space = subtract(&(*CONSTANT_0),&(v638_4));
        drop(v638_4);
        let v638_7: Space = if (v638_5).is_empty() { Space::new() } else {
          let v639_6: Space = routine_29(c, &(v637_11_head), &(v637_10), &(v637_11_tail));
          compose(&(v638_5),&(v639_6))
        };
        drop(v638_5);
        let v638_8: Space = intersect(&(*CONSTANT_14),&(v638_2));
        drop(v638_2);
        let v638_9: Space = if has_head(&(v638_8)) { singleton(&[]) } else { Space::new() };
        drop(v638_8);
        let v638_11: Space = if (v638_9).is_empty() { Space::new() } else {
          let v640_10: Space = routine_30(c, &(v637_11_head), &(v637_10), &(v637_11_tail));
          compose(&(v638_9),&(v640_10))
        };
        drop(v638_9);
        let v638_12: Space = unite(&(v638_7),&(v638_11));
        v637_11.join_into((v638_12).clone());
      }
      drop(v637_11_cursor);
      drop(v637_10);
      compose(&(v635_9),&(v637_11))
    };
    drop(v635_9);
    let v635_13: Space = unite(&(v635_7),&(v635_12));
    drop(v635_7);
    v634_8.join_into((v635_13).clone());
  }
  drop(v634_8_cursor);
  (v634_8).clone()
}

fn routine_68(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v641_12 = Space::new();
  let mut v641_12_cursor = (*s0).read_zipper();
  for v641_12_byte in v641_12_cursor.child_mask().iter() {
    v641_12_cursor.descend_to_byte(v641_12_byte);
    let v641_12_tail = v641_12_cursor.make_map();
    v641_12_cursor.ascend(1);
    let v641_12_head = Path::from_slice(&[v641_12_byte]);
    let v642_2: Space = singleton(&(v641_12_head));
    let v642_3: Space = intersect(&(*CONSTANT_14),&(v642_2));
    let v642_4: Space = if has_head(&(v642_3)) { singleton(&[]) } else { Space::new() };
    drop(v642_3);
    let v642_5: Space = subtract(&(*CONSTANT_0),&(v642_4));
    drop(v642_4);
    let v642_8: Space = if (v642_5).is_empty() { Space::new() } else {
      let v643_6: Path = concat_path(&(*p0),&(v641_12_head));
      let mut v643_7 = Space::new();
      let mut v643_7_cursor = (v641_12_tail).read_zipper();
      for v643_7_byte in v643_7_cursor.child_mask().iter() {
        v643_7_cursor.descend_to_byte(v643_7_byte);
        let v643_7_tail = v643_7_cursor.make_map();
        v643_7_cursor.ascend(1);
        let v643_7_head = Path::from_slice(&[v643_7_byte]);
        let v644_2: Space = singleton(&(v643_7_head));
        let v644_3: Space = intersect(&(*CONSTANT_14),&(v644_2));
        let v644_4: Space = if has_head(&(v644_3)) { singleton(&[]) } else { Space::new() };
        drop(v644_3);
        let v644_5: Space = subtract(&(*CONSTANT_0),&(v644_4));
        drop(v644_4);
        let v644_8: Space = if (v644_5).is_empty() { Space::new() } else {
          let v645_6: Path = concat_path(&(v643_6),&(v643_7_head));
          let v645_7: Space = routine_106(c, &(v645_6), &(*p1), &(v643_7_tail));
          compose(&(v644_5),&(v645_7))
        };
        drop(v644_5);
        let v644_9: Space = intersect(&(*CONSTANT_14),&(v644_2));
        drop(v644_2);
        let v644_10: Space = if has_head(&(v644_9)) { singleton(&[]) } else { Space::new() };
        drop(v644_9);
        let v644_12: Space = if (v644_10).is_empty() { Space::new() } else {
          let v646_6: Path = concat_path(&(v643_6),&(v643_7_head));
          let v646_11: Space = routine_107(c, &(v646_6), &(*p1), &(v643_7_tail));
          drop(v646_6);
          compose(&(v644_10),&(v646_11))
        };
        drop(v644_10);
        let v644_13: Space = unite(&(v644_8),&(v644_12));
        v643_7.join_into((v644_13).clone());
      }
      drop(v643_7_cursor);
      compose(&(v642_5),&(v643_7))
    };
    drop(v642_5);
    let v642_9: Space = intersect(&(*CONSTANT_14),&(v642_2));
    drop(v642_2);
    let v642_10: Space = if has_head(&(v642_9)) { singleton(&[]) } else { Space::new() };
    drop(v642_9);
    let v642_12: Space = if (v642_10).is_empty() { Space::new() } else {
      let v647_6: Path = concat_path(&(*p0),&(v641_12_head));
      let mut v647_11 = Space::new();
      let mut v647_11_cursor = (v641_12_tail).read_zipper();
      for v647_11_byte in v647_11_cursor.child_mask().iter() {
        v647_11_cursor.descend_to_byte(v647_11_byte);
        let v647_11_tail = v647_11_cursor.make_map();
        v647_11_cursor.ascend(1);
        let v647_11_head = Path::from_slice(&[v647_11_byte]);
        let v648_2: Space = singleton(&(v647_11_head));
        let v648_3: Space = intersect(&(*CONSTANT_14),&(v648_2));
        let v648_4: Space = if has_head(&(v648_3)) { singleton(&[]) } else { Space::new() };
        drop(v648_3);
        let v648_5: Space = subtract(&(*CONSTANT_0),&(v648_4));
        drop(v648_4);
        let v648_8: Space = if (v648_5).is_empty() { Space::new() } else {
          let v649_6: Path = concat_path(&(v647_6),&(v647_11_head));
          let v649_7: Space = routine_106(c, &(v649_6), &(*p1), &(v647_11_tail));
          compose(&(v648_5),&(v649_7))
        };
        drop(v648_5);
        let v648_9: Space = intersect(&(*CONSTANT_14),&(v648_2));
        drop(v648_2);
        let v648_10: Space = if has_head(&(v648_9)) { singleton(&[]) } else { Space::new() };
        drop(v648_9);
        let v648_12: Space = if (v648_10).is_empty() { Space::new() } else {
          let v650_6: Path = concat_path(&(v647_6),&(v647_11_head));
          let v650_11: Space = routine_33(c, &(v650_6), &(*p1), &(v647_11_tail));
          drop(v650_6);
          compose(&(v648_10),&(v650_11))
        };
        drop(v648_10);
        let v648_13: Space = unite(&(v648_8),&(v648_12));
        v647_11.join_into((v648_13).clone());
      }
      drop(v647_11_cursor);
      drop(v647_6);
      compose(&(v642_10),&(v647_11))
    };
    drop(v642_10);
    let v642_13: Space = unite(&(v642_8),&(v642_12));
    v641_12.join_into((v642_13).clone());
  }
  drop(v641_12_cursor);
  (v641_12).clone()
}

fn routine_69(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v651_9 = Space::new();
  let mut v651_9_cursor = (*s0).read_zipper();
  for v651_9_byte in v651_9_cursor.child_mask().iter() {
    v651_9_cursor.descend_to_byte(v651_9_byte);
    let v651_9_tail = v651_9_cursor.make_map();
    v651_9_cursor.ascend(1);
    let v651_9_head = Path::from_slice(&[v651_9_byte]);
    let v652_2: Space = singleton(&(v651_9_head));
    let v652_3: Space = intersect(&(*CONSTANT_14),&(v652_2));
    let v652_4: Space = if has_head(&(v652_3)) { singleton(&[]) } else { Space::new() };
    drop(v652_3);
    let v652_5: Space = subtract(&(*CONSTANT_0),&(v652_4));
    drop(v652_4);
    let v652_8: Space = if (v652_5).is_empty() { Space::new() } else {
      let v653_6: Path = concat_path(&(*p0),&(v651_9_head));
      let mut v653_7 = Space::new();
      let mut v653_7_cursor = (v651_9_tail).read_zipper();
      for v653_7_byte in v653_7_cursor.child_mask().iter() {
        v653_7_cursor.descend_to_byte(v653_7_byte);
        let v653_7_tail = v653_7_cursor.make_map();
        v653_7_cursor.ascend(1);
        let v653_7_head = Path::from_slice(&[v653_7_byte]);
        let v654_2: Space = singleton(&(v653_7_head));
        let v654_3: Space = intersect(&(*CONSTANT_14),&(v654_2));
        let v654_4: Space = if has_head(&(v654_3)) { singleton(&[]) } else { Space::new() };
        drop(v654_3);
        let v654_5: Space = subtract(&(*CONSTANT_0),&(v654_4));
        drop(v654_4);
        let v654_8: Space = if (v654_5).is_empty() { Space::new() } else {
          let v655_6: Path = concat_path(&(v653_6),&(v653_7_head));
          let v655_7: Space = routine_106(c, &(v655_6), &(*p1), &(v653_7_tail));
          compose(&(v654_5),&(v655_7))
        };
        drop(v654_5);
        let v654_9: Space = intersect(&(*CONSTANT_14),&(v654_2));
        drop(v654_2);
        let v654_10: Space = if has_head(&(v654_9)) { singleton(&[]) } else { Space::new() };
        drop(v654_9);
        let v654_12: Space = if (v654_10).is_empty() { Space::new() } else {
          let v656_6: Path = concat_path(&(v653_6),&(v653_7_head));
          let v656_11: Space = routine_107(c, &(v656_6), &(*p1), &(v653_7_tail));
          drop(v656_6);
          compose(&(v654_10),&(v656_11))
        };
        drop(v654_10);
        let v654_13: Space = unite(&(v654_8),&(v654_12));
        v653_7.join_into((v654_13).clone());
      }
      drop(v653_7_cursor);
      compose(&(v652_5),&(v653_7))
    };
    drop(v652_5);
    let v652_9: Space = intersect(&(*CONSTANT_14),&(v652_2));
    drop(v652_2);
    let v652_10: Space = if has_head(&(v652_9)) { singleton(&[]) } else { Space::new() };
    drop(v652_9);
    let v652_11: Space = compose(&(v652_10),&(v651_9_tail));
    drop(v652_10);
    let v657_6: Path = concat_path(&(*p0),&(v651_9_head));
    let v652_12: Space = wrap(&(v652_11),&(v657_6));
    drop(v652_11);
    let v652_13: Space = wrap(&(v652_12),&(*p1));
    drop(v652_12);
    let v652_14: Space = unite(&(v652_8),&(v652_13));
    drop(v652_13);
    v651_9.join_into((v652_14).clone());
  }
  drop(v651_9_cursor);
  (v651_9).clone()
}

fn routine_70(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v658_12 = Space::new();
  let mut v658_12_cursor = (*s0).read_zipper();
  for v658_12_byte in v658_12_cursor.child_mask().iter() {
    v658_12_cursor.descend_to_byte(v658_12_byte);
    let v658_12_tail = v658_12_cursor.make_map();
    v658_12_cursor.ascend(1);
    let v658_12_head = Path::from_slice(&[v658_12_byte]);
    let v659_2: Space = singleton(&(v658_12_head));
    let v659_3: Space = intersect(&(*CONSTANT_14),&(v659_2));
    let v659_4: Space = if has_head(&(v659_3)) { singleton(&[]) } else { Space::new() };
    drop(v659_3);
    let v659_5: Space = subtract(&(*CONSTANT_0),&(v659_4));
    drop(v659_4);
    let v659_8: Space = if (v659_5).is_empty() { Space::new() } else {
      let v660_6: Path = concat_path(&(*p0),&(v658_12_head));
      let mut v660_7 = Space::new();
      let mut v660_7_cursor = (v658_12_tail).read_zipper();
      for v660_7_byte in v660_7_cursor.child_mask().iter() {
        v660_7_cursor.descend_to_byte(v660_7_byte);
        let v660_7_tail = v660_7_cursor.make_map();
        v660_7_cursor.ascend(1);
        let v660_7_head = Path::from_slice(&[v660_7_byte]);
        let v661_2: Space = singleton(&(v660_7_head));
        let v661_3: Space = intersect(&(*CONSTANT_14),&(v661_2));
        let v661_4: Space = if has_head(&(v661_3)) { singleton(&[]) } else { Space::new() };
        drop(v661_3);
        let v661_5: Space = subtract(&(*CONSTANT_0),&(v661_4));
        drop(v661_4);
        let v661_8: Space = if (v661_5).is_empty() { Space::new() } else {
          let v662_6: Path = concat_path(&(v660_6),&(v660_7_head));
          let v662_7: Space = routine_108(c, &(v662_6), &(*p1), &(v660_7_tail));
          compose(&(v661_5),&(v662_7))
        };
        drop(v661_5);
        let v661_9: Space = intersect(&(*CONSTANT_14),&(v661_2));
        drop(v661_2);
        let v661_10: Space = if has_head(&(v661_9)) { singleton(&[]) } else { Space::new() };
        drop(v661_9);
        let v661_12: Space = if (v661_10).is_empty() { Space::new() } else {
          let v663_6: Path = concat_path(&(v660_6),&(v660_7_head));
          let v663_11: Space = routine_109(c, &(v663_6), &(*p1), &(v660_7_tail));
          drop(v663_6);
          compose(&(v661_10),&(v663_11))
        };
        drop(v661_10);
        let v661_13: Space = unite(&(v661_8),&(v661_12));
        v660_7.join_into((v661_13).clone());
      }
      drop(v660_7_cursor);
      compose(&(v659_5),&(v660_7))
    };
    drop(v659_5);
    let v659_9: Space = intersect(&(*CONSTANT_14),&(v659_2));
    drop(v659_2);
    let v659_10: Space = if has_head(&(v659_9)) { singleton(&[]) } else { Space::new() };
    drop(v659_9);
    let v659_12: Space = if (v659_10).is_empty() { Space::new() } else {
      let v664_6: Path = concat_path(&(*p0),&(v658_12_head));
      let mut v664_11 = Space::new();
      let mut v664_11_cursor = (v658_12_tail).read_zipper();
      for v664_11_byte in v664_11_cursor.child_mask().iter() {
        v664_11_cursor.descend_to_byte(v664_11_byte);
        let v664_11_tail = v664_11_cursor.make_map();
        v664_11_cursor.ascend(1);
        let v664_11_head = Path::from_slice(&[v664_11_byte]);
        let v665_2: Space = singleton(&(v664_11_head));
        let v665_3: Space = intersect(&(*CONSTANT_14),&(v665_2));
        let v665_4: Space = if has_head(&(v665_3)) { singleton(&[]) } else { Space::new() };
        drop(v665_3);
        let v665_5: Space = subtract(&(*CONSTANT_0),&(v665_4));
        drop(v665_4);
        let v665_8: Space = if (v665_5).is_empty() { Space::new() } else {
          let v666_6: Path = concat_path(&(v664_6),&(v664_11_head));
          let v666_7: Space = routine_108(c, &(v666_6), &(*p1), &(v664_11_tail));
          compose(&(v665_5),&(v666_7))
        };
        drop(v665_5);
        let v665_9: Space = intersect(&(*CONSTANT_14),&(v665_2));
        drop(v665_2);
        let v665_10: Space = if has_head(&(v665_9)) { singleton(&[]) } else { Space::new() };
        drop(v665_9);
        let v665_12: Space = if (v665_10).is_empty() { Space::new() } else {
          let v667_6: Path = concat_path(&(v664_6),&(v664_11_head));
          let v667_11: Space = routine_33(c, &(v667_6), &(*p1), &(v664_11_tail));
          drop(v667_6);
          compose(&(v665_10),&(v667_11))
        };
        drop(v665_10);
        let v665_13: Space = unite(&(v665_8),&(v665_12));
        v664_11.join_into((v665_13).clone());
      }
      drop(v664_11_cursor);
      drop(v664_6);
      compose(&(v659_10),&(v664_11))
    };
    drop(v659_10);
    let v659_13: Space = unite(&(v659_8),&(v659_12));
    v658_12.join_into((v659_13).clone());
  }
  drop(v658_12_cursor);
  (v658_12).clone()
}

fn routine_71(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v668_9 = Space::new();
  let mut v668_9_cursor = (*s0).read_zipper();
  for v668_9_byte in v668_9_cursor.child_mask().iter() {
    v668_9_cursor.descend_to_byte(v668_9_byte);
    let v668_9_tail = v668_9_cursor.make_map();
    v668_9_cursor.ascend(1);
    let v668_9_head = Path::from_slice(&[v668_9_byte]);
    let v669_2: Space = singleton(&(v668_9_head));
    let v669_3: Space = intersect(&(*CONSTANT_14),&(v669_2));
    let v669_4: Space = if has_head(&(v669_3)) { singleton(&[]) } else { Space::new() };
    drop(v669_3);
    let v669_5: Space = subtract(&(*CONSTANT_0),&(v669_4));
    drop(v669_4);
    let v669_8: Space = if (v669_5).is_empty() { Space::new() } else {
      let v670_6: Path = concat_path(&(*p0),&(v668_9_head));
      let mut v670_7 = Space::new();
      let mut v670_7_cursor = (v668_9_tail).read_zipper();
      for v670_7_byte in v670_7_cursor.child_mask().iter() {
        v670_7_cursor.descend_to_byte(v670_7_byte);
        let v670_7_tail = v670_7_cursor.make_map();
        v670_7_cursor.ascend(1);
        let v670_7_head = Path::from_slice(&[v670_7_byte]);
        let v671_2: Space = singleton(&(v670_7_head));
        let v671_3: Space = intersect(&(*CONSTANT_14),&(v671_2));
        let v671_4: Space = if has_head(&(v671_3)) { singleton(&[]) } else { Space::new() };
        drop(v671_3);
        let v671_5: Space = subtract(&(*CONSTANT_0),&(v671_4));
        drop(v671_4);
        let v671_8: Space = if (v671_5).is_empty() { Space::new() } else {
          let v672_6: Path = concat_path(&(v670_6),&(v670_7_head));
          let v672_7: Space = routine_108(c, &(v672_6), &(*p1), &(v670_7_tail));
          compose(&(v671_5),&(v672_7))
        };
        drop(v671_5);
        let v671_9: Space = intersect(&(*CONSTANT_14),&(v671_2));
        drop(v671_2);
        let v671_10: Space = if has_head(&(v671_9)) { singleton(&[]) } else { Space::new() };
        drop(v671_9);
        let v671_12: Space = if (v671_10).is_empty() { Space::new() } else {
          let v673_6: Path = concat_path(&(v670_6),&(v670_7_head));
          let v673_11: Space = routine_109(c, &(v673_6), &(*p1), &(v670_7_tail));
          drop(v673_6);
          compose(&(v671_10),&(v673_11))
        };
        drop(v671_10);
        let v671_13: Space = unite(&(v671_8),&(v671_12));
        v670_7.join_into((v671_13).clone());
      }
      drop(v670_7_cursor);
      compose(&(v669_5),&(v670_7))
    };
    drop(v669_5);
    let v669_9: Space = intersect(&(*CONSTANT_14),&(v669_2));
    drop(v669_2);
    let v669_10: Space = if has_head(&(v669_9)) { singleton(&[]) } else { Space::new() };
    drop(v669_9);
    let v669_11: Space = compose(&(v669_10),&(v668_9_tail));
    drop(v669_10);
    let v674_6: Path = concat_path(&(*p0),&(v668_9_head));
    let v669_12: Space = wrap(&(v669_11),&(v674_6));
    drop(v669_11);
    let v669_13: Space = wrap(&(v669_12),&(*p1));
    drop(v669_12);
    let v669_14: Space = unite(&(v669_8),&(v669_13));
    drop(v669_13);
    v668_9.join_into((v669_14).clone());
  }
  drop(v668_9_cursor);
  (v668_9).clone()
}

fn routine_72(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v675_7 = Space::new();
  let mut v675_7_cursor = (*s0).read_zipper();
  for v675_7_byte in v675_7_cursor.child_mask().iter() {
    v675_7_cursor.descend_to_byte(v675_7_byte);
    let v675_7_tail = v675_7_cursor.make_map();
    v675_7_cursor.ascend(1);
    let v675_7_head = Path::from_slice(&[v675_7_byte]);
    let v676_2: Space = singleton(&(v675_7_head));
    let v676_3: Space = intersect(&(*CONSTANT_14),&(v676_2));
    let v676_4: Space = if has_head(&(v676_3)) { singleton(&[]) } else { Space::new() };
    drop(v676_3);
    let v676_5: Space = subtract(&(*CONSTANT_0),&(v676_4));
    drop(v676_4);
    let mut v676_6 = Space::new();
    let mut v676_6_cursor = (v675_7_tail).read_zipper();
    for v676_6_byte in v676_6_cursor.child_mask().iter() {
      v676_6_cursor.descend_to_byte(v676_6_byte);
      let v676_6_tail = v676_6_cursor.make_map();
      v676_6_cursor.ascend(1);
      let v676_6_head = Path::from_slice(&[v676_6_byte]);
      let v677_2: Space = Space::new();
      v676_6.join_into((v677_2).clone());
    }
    drop(v676_6_cursor);
    let v676_7: Space = compose(&(v676_5),&(v676_6));
    drop(v676_5);
    drop(v676_6);
    let v676_8: Space = intersect(&(*CONSTANT_14),&(v676_2));
    drop(v676_2);
    let v676_9: Space = if has_head(&(v676_8)) { singleton(&[]) } else { Space::new() };
    drop(v676_8);
    let v676_12: Space = if (v676_9).is_empty() { Space::new() } else {
      let v678_10: Path = concat_path(&(*p0),&(v675_7_head));
      let mut v678_11 = Space::new();
      let mut v678_11_cursor = (v675_7_tail).read_zipper();
      for v678_11_byte in v678_11_cursor.child_mask().iter() {
        v678_11_cursor.descend_to_byte(v678_11_byte);
        let v678_11_tail = v678_11_cursor.make_map();
        v678_11_cursor.ascend(1);
        let v678_11_head = Path::from_slice(&[v678_11_byte]);
        let v679_2: Space = singleton(&(v678_11_head));
        let v679_3: Space = intersect(&(*CONSTANT_14),&(v679_2));
        drop(v679_2);
        let v679_4: Space = if has_head(&(v679_3)) { singleton(&[]) } else { Space::new() };
        drop(v679_3);
        let v679_7: Space = if (v679_4).is_empty() { Space::new() } else {
          let v680_5: Path = concat_path(&(v678_10),&(v678_11_head));
          let v680_6: Space = routine_11(c, &(v680_5), &(v678_11_tail), &(*s1));
          drop(v680_5);
          compose(&(v679_4),&(v680_6))
        };
        drop(v679_4);
        v678_11.join_into((v679_7).clone());
      }
      drop(v678_11_cursor);
      drop(v678_10);
      compose(&(v676_9),&(v678_11))
    };
    drop(v676_9);
    let v676_13: Space = unite(&(v676_7),&(v676_12));
    drop(v676_7);
    v675_7.join_into((v676_13).clone());
  }
  drop(v675_7_cursor);
  (v675_7).clone()
}

fn routine_73(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v681_9 = Space::new();
  let mut v681_9_cursor = (*s0).read_zipper();
  for v681_9_byte in v681_9_cursor.child_mask().iter() {
    v681_9_cursor.descend_to_byte(v681_9_byte);
    let v681_9_tail = v681_9_cursor.make_map();
    v681_9_cursor.ascend(1);
    let v681_9_head = Path::from_slice(&[v681_9_byte]);
    let v682_2: Space = singleton(&(v681_9_head));
    let v682_3: Space = intersect(&(*CONSTANT_14),&(v682_2));
    let v682_4: Space = if has_head(&(v682_3)) { singleton(&[]) } else { Space::new() };
    drop(v682_3);
    let v682_5: Space = subtract(&(*CONSTANT_0),&(v682_4));
    drop(v682_4);
    let mut v682_6 = Space::new();
    let mut v682_6_cursor = (v681_9_tail).read_zipper();
    for v682_6_byte in v682_6_cursor.child_mask().iter() {
      v682_6_cursor.descend_to_byte(v682_6_byte);
      let v682_6_tail = v682_6_cursor.make_map();
      v682_6_cursor.ascend(1);
      let v682_6_head = Path::from_slice(&[v682_6_byte]);
      let v683_2: Space = Space::new();
      v682_6.join_into((v683_2).clone());
    }
    drop(v682_6_cursor);
    let v682_7: Space = compose(&(v682_5),&(v682_6));
    drop(v682_5);
    drop(v682_6);
    let v682_8: Space = intersect(&(*CONSTANT_14),&(v682_2));
    drop(v682_2);
    let v682_9: Space = if has_head(&(v682_8)) { singleton(&[]) } else { Space::new() };
    drop(v682_8);
    let v682_12: Space = if (v682_9).is_empty() { Space::new() } else {
      let v684_10: Path = concat_path(&(*p0),&(v681_9_head));
      let mut v684_11 = Space::new();
      let mut v684_11_cursor = (v681_9_tail).read_zipper();
      for v684_11_byte in v684_11_cursor.child_mask().iter() {
        v684_11_cursor.descend_to_byte(v684_11_byte);
        let v684_11_tail = v684_11_cursor.make_map();
        v684_11_cursor.ascend(1);
        let v684_11_head = Path::from_slice(&[v684_11_byte]);
        let v685_2: Space = singleton(&(v684_11_head));
        let v685_3: Space = intersect(&(*CONSTANT_14),&(v685_2));
        let v685_4: Space = if has_head(&(v685_3)) { singleton(&[]) } else { Space::new() };
        drop(v685_3);
        let v685_5: Space = subtract(&(*CONSTANT_0),&(v685_4));
        drop(v685_4);
        let v685_7: Space = if (v685_5).is_empty() { Space::new() } else {
          let v686_6: Space = routine_36(c, &(v684_11_head), &(v684_10), &(v684_11_tail), &(*s1));
          compose(&(v685_5),&(v686_6))
        };
        drop(v685_5);
        let v685_8: Space = intersect(&(*CONSTANT_14),&(v685_2));
        drop(v685_2);
        let v685_9: Space = if has_head(&(v685_8)) { singleton(&[]) } else { Space::new() };
        drop(v685_8);
        let v685_11: Space = if (v685_9).is_empty() { Space::new() } else {
          let v687_10: Space = routine_37(c, &(v684_11_head), &(v684_10), &(v684_11_tail), &(*s1));
          compose(&(v685_9),&(v687_10))
        };
        drop(v685_9);
        let v685_12: Space = unite(&(v685_7),&(v685_11));
        v684_11.join_into((v685_12).clone());
      }
      drop(v684_11_cursor);
      drop(v684_10);
      compose(&(v682_9),&(v684_11))
    };
    drop(v682_9);
    let v682_13: Space = unite(&(v682_7),&(v682_12));
    drop(v682_7);
    v681_9.join_into((v682_13).clone());
  }
  drop(v681_9_cursor);
  (v681_9).clone()
}

fn routine_74(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v688_13 = Space::new();
  let mut v688_13_cursor = (*s0).read_zipper();
  for v688_13_byte in v688_13_cursor.child_mask().iter() {
    v688_13_cursor.descend_to_byte(v688_13_byte);
    let v688_13_tail = v688_13_cursor.make_map();
    v688_13_cursor.ascend(1);
    let v688_13_head = Path::from_slice(&[v688_13_byte]);
    let v689_2: Space = singleton(&(v688_13_head));
    let v689_3: Space = intersect(&(*CONSTANT_14),&(v689_2));
    let v689_4: Space = if has_head(&(v689_3)) { singleton(&[]) } else { Space::new() };
    drop(v689_3);
    let v689_5: Space = subtract(&(*CONSTANT_0),&(v689_4));
    drop(v689_4);
    let v689_8: Space = if (v689_5).is_empty() { Space::new() } else {
      let v690_6: Path = concat_path(&(*p0),&(v688_13_head));
      let mut v690_7 = Space::new();
      let mut v690_7_cursor = (v688_13_tail).read_zipper();
      for v690_7_byte in v690_7_cursor.child_mask().iter() {
        v690_7_cursor.descend_to_byte(v690_7_byte);
        let v690_7_tail = v690_7_cursor.make_map();
        v690_7_cursor.ascend(1);
        let v690_7_head = Path::from_slice(&[v690_7_byte]);
        let v691_2: Space = singleton(&(v690_7_head));
        let v691_3: Space = intersect(&(*CONSTANT_14),&(v691_2));
        let v691_4: Space = if has_head(&(v691_3)) { singleton(&[]) } else { Space::new() };
        drop(v691_3);
        let v691_5: Space = subtract(&(*CONSTANT_0),&(v691_4));
        drop(v691_4);
        let v691_8: Space = if (v691_5).is_empty() { Space::new() } else {
          let v692_6: Path = concat_path(&(v690_6),&(v690_7_head));
          let v692_7: Space = routine_110(c, &(v692_6), &(*p1), &(v690_7_tail), &(*s1));
          compose(&(v691_5),&(v692_7))
        };
        drop(v691_5);
        let v691_9: Space = intersect(&(*CONSTANT_14),&(v691_2));
        drop(v691_2);
        let v691_10: Space = if has_head(&(v691_9)) { singleton(&[]) } else { Space::new() };
        drop(v691_9);
        let v691_12: Space = if (v691_10).is_empty() { Space::new() } else {
          let v693_6: Path = concat_path(&(v690_6),&(v690_7_head));
          let v693_11: Space = routine_111(c, &(v693_6), &(*p1), &(v690_7_tail), &(*s1));
          drop(v693_6);
          compose(&(v691_10),&(v693_11))
        };
        drop(v691_10);
        let v691_13: Space = unite(&(v691_8),&(v691_12));
        v690_7.join_into((v691_13).clone());
      }
      drop(v690_7_cursor);
      compose(&(v689_5),&(v690_7))
    };
    drop(v689_5);
    let v689_9: Space = intersect(&(*CONSTANT_14),&(v689_2));
    drop(v689_2);
    let v689_10: Space = if has_head(&(v689_9)) { singleton(&[]) } else { Space::new() };
    drop(v689_9);
    let v689_12: Space = if (v689_10).is_empty() { Space::new() } else {
      let v694_6: Path = concat_path(&(*p0),&(v688_13_head));
      let mut v694_11 = Space::new();
      let mut v694_11_cursor = (v688_13_tail).read_zipper();
      for v694_11_byte in v694_11_cursor.child_mask().iter() {
        v694_11_cursor.descend_to_byte(v694_11_byte);
        let v694_11_tail = v694_11_cursor.make_map();
        v694_11_cursor.ascend(1);
        let v694_11_head = Path::from_slice(&[v694_11_byte]);
        let v695_2: Space = singleton(&(v694_11_head));
        let v695_3: Space = intersect(&(*CONSTANT_14),&(v695_2));
        let v695_4: Space = if has_head(&(v695_3)) { singleton(&[]) } else { Space::new() };
        drop(v695_3);
        let v695_5: Space = subtract(&(*CONSTANT_0),&(v695_4));
        drop(v695_4);
        let v695_8: Space = if (v695_5).is_empty() { Space::new() } else {
          let v696_6: Path = concat_path(&(v694_6),&(v694_11_head));
          let v696_7: Space = routine_110(c, &(v696_6), &(*p1), &(v694_11_tail), &(*s1));
          compose(&(v695_5),&(v696_7))
        };
        drop(v695_5);
        let v695_9: Space = intersect(&(*CONSTANT_14),&(v695_2));
        drop(v695_2);
        let v695_10: Space = if has_head(&(v695_9)) { singleton(&[]) } else { Space::new() };
        drop(v695_9);
        let v695_12: Space = if (v695_10).is_empty() { Space::new() } else {
          let v697_6: Path = concat_path(&(v694_6),&(v694_11_head));
          let v697_11: Space = routine_40(c, &(v697_6), &(*p1), &(v694_11_tail), &(*s1));
          drop(v697_6);
          compose(&(v695_10),&(v697_11))
        };
        drop(v695_10);
        let v695_13: Space = unite(&(v695_8),&(v695_12));
        v694_11.join_into((v695_13).clone());
      }
      drop(v694_11_cursor);
      drop(v694_6);
      compose(&(v689_10),&(v694_11))
    };
    drop(v689_10);
    let v689_13: Space = unite(&(v689_8),&(v689_12));
    v688_13.join_into((v689_13).clone());
  }
  drop(v688_13_cursor);
  (v688_13).clone()
}

fn routine_75(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v698_8: Space = unwrap(&(*s1),&(*CONSTANT_9));
  let v698_10: Space = unwrap(&(v698_8),&(*CONSTANT_10));
  drop(v698_8);
  let v698_11: Space = unwrap(&(v698_10),&(*p0));
  drop(v698_10);
  let mut v698_18 = Space::new();
  let mut v698_18_cursor = (*s0).read_zipper();
  for v698_18_byte in v698_18_cursor.child_mask().iter() {
    v698_18_cursor.descend_to_byte(v698_18_byte);
    let v698_18_tail = v698_18_cursor.make_map();
    v698_18_cursor.ascend(1);
    let v698_18_head = Path::from_slice(&[v698_18_byte]);
    let v699_2: Space = singleton(&(v698_18_head));
    let v699_3: Space = intersect(&(*CONSTANT_14),&(v699_2));
    let v699_4: Space = if has_head(&(v699_3)) { singleton(&[]) } else { Space::new() };
    drop(v699_3);
    let v699_5: Space = subtract(&(*CONSTANT_0),&(v699_4));
    drop(v699_4);
    let v699_8: Space = if (v699_5).is_empty() { Space::new() } else {
      let v700_6: Path = concat_path(&(*p0),&(v698_18_head));
      let mut v700_7 = Space::new();
      let mut v700_7_cursor = (v698_18_tail).read_zipper();
      for v700_7_byte in v700_7_cursor.child_mask().iter() {
        v700_7_cursor.descend_to_byte(v700_7_byte);
        let v700_7_tail = v700_7_cursor.make_map();
        v700_7_cursor.ascend(1);
        let v700_7_head = Path::from_slice(&[v700_7_byte]);
        let v701_2: Space = singleton(&(v700_7_head));
        let v701_3: Space = intersect(&(*CONSTANT_14),&(v701_2));
        let v701_4: Space = if has_head(&(v701_3)) { singleton(&[]) } else { Space::new() };
        drop(v701_3);
        let v701_5: Space = subtract(&(*CONSTANT_0),&(v701_4));
        drop(v701_4);
        let v701_8: Space = if (v701_5).is_empty() { Space::new() } else {
          let v702_6: Path = concat_path(&(v700_6),&(v700_7_head));
          let v702_7: Space = routine_110(c, &(v702_6), &(*p1), &(v700_7_tail), &(*s1));
          compose(&(v701_5),&(v702_7))
        };
        drop(v701_5);
        let v701_9: Space = intersect(&(*CONSTANT_14),&(v701_2));
        drop(v701_2);
        let v701_10: Space = if has_head(&(v701_9)) { singleton(&[]) } else { Space::new() };
        drop(v701_9);
        let v701_12: Space = if (v701_10).is_empty() { Space::new() } else {
          let v703_6: Path = concat_path(&(v700_6),&(v700_7_head));
          let v703_11: Space = routine_111(c, &(v703_6), &(*p1), &(v700_7_tail), &(*s1));
          drop(v703_6);
          compose(&(v701_10),&(v703_11))
        };
        drop(v701_10);
        let v701_13: Space = unite(&(v701_8),&(v701_12));
        v700_7.join_into((v701_13).clone());
      }
      drop(v700_7_cursor);
      drop(v700_6);
      compose(&(v699_5),&(v700_7))
    };
    drop(v699_5);
    let v699_9: Space = intersect(&(*CONSTANT_14),&(v699_2));
    drop(v699_2);
    let v699_10: Space = if has_head(&(v699_9)) { singleton(&[]) } else { Space::new() };
    drop(v699_9);
    let v699_13: Space = if (v699_10).is_empty() { Space::new() } else {
      let v704_11: Space = unwrap(&(v698_11),&(v698_18_head));
      let mut v704_12 = Space::new();
      let mut v704_12_cursor = (v704_11).read_zipper();
      for v704_12_byte in v704_12_cursor.child_mask().iter() {
        v704_12_cursor.descend_to_byte(v704_12_byte);
        let v704_12_tail = v704_12_cursor.make_map();
        v704_12_cursor.ascend(1);
        let v704_12_head = Path::from_slice(&[v704_12_byte]);
        let v705_2: Space = singleton(&(v704_12_head));
        let v705_3: Space = intersect(&(*CONSTANT_14),&(v705_2));
        let v705_4: Space = if has_head(&(v705_3)) { singleton(&[]) } else { Space::new() };
        drop(v705_3);
        let v705_5: Space = subtract(&(*CONSTANT_0),&(v705_4));
        drop(v705_4);
        let v705_7: Space = if (v705_5).is_empty() { Space::new() } else {
          let v706_6: Space = routine_76(c, &(v704_12_head), &(*p1), &(v704_12_tail));
          compose(&(v705_5),&(v706_6))
        };
        drop(v705_5);
        let v705_8: Space = intersect(&(*CONSTANT_14),&(v705_2));
        drop(v705_2);
        let v705_9: Space = if has_head(&(v705_8)) { singleton(&[]) } else { Space::new() };
        drop(v705_8);
        let v705_11: Space = if (v705_9).is_empty() { Space::new() } else {
          let v707_10: Space = routine_77(c, &(v704_12_head), &(*p1), &(v704_12_tail));
          compose(&(v705_9),&(v707_10))
        };
        drop(v705_9);
        let v705_12: Space = unite(&(v705_7),&(v705_11));
        v704_12.join_into((v705_12).clone());
      }
      drop(v704_12_cursor);
      drop(v704_11);
      compose(&(v699_10),&(v704_12))
    };
    drop(v699_10);
    let v699_14: Space = unite(&(v699_8),&(v699_13));
    v698_18.join_into((v699_14).clone());
  }
  drop(v698_18_cursor);
  drop(v698_11);
  (v698_18).clone()
}

fn routine_76(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v708_12 = Space::new();
  let mut v708_12_cursor = (*s0).read_zipper();
  for v708_12_byte in v708_12_cursor.child_mask().iter() {
    v708_12_cursor.descend_to_byte(v708_12_byte);
    let v708_12_tail = v708_12_cursor.make_map();
    v708_12_cursor.ascend(1);
    let v708_12_head = Path::from_slice(&[v708_12_byte]);
    let v709_2: Space = singleton(&(v708_12_head));
    let v709_3: Space = intersect(&(*CONSTANT_14),&(v709_2));
    let v709_4: Space = if has_head(&(v709_3)) { singleton(&[]) } else { Space::new() };
    drop(v709_3);
    let v709_5: Space = subtract(&(*CONSTANT_0),&(v709_4));
    drop(v709_4);
    let v709_8: Space = if (v709_5).is_empty() { Space::new() } else {
      let v710_6: Path = concat_path(&(*p0),&(v708_12_head));
      let mut v710_7 = Space::new();
      let mut v710_7_cursor = (v708_12_tail).read_zipper();
      for v710_7_byte in v710_7_cursor.child_mask().iter() {
        v710_7_cursor.descend_to_byte(v710_7_byte);
        let v710_7_tail = v710_7_cursor.make_map();
        v710_7_cursor.ascend(1);
        let v710_7_head = Path::from_slice(&[v710_7_byte]);
        let v711_2: Space = singleton(&(v710_7_head));
        let v711_3: Space = intersect(&(*CONSTANT_14),&(v711_2));
        let v711_4: Space = if has_head(&(v711_3)) { singleton(&[]) } else { Space::new() };
        drop(v711_3);
        let v711_5: Space = subtract(&(*CONSTANT_0),&(v711_4));
        drop(v711_4);
        let v711_8: Space = if (v711_5).is_empty() { Space::new() } else {
          let v712_6: Path = concat_path(&(v710_6),&(v710_7_head));
          let v712_7: Space = routine_112(c, &(v712_6), &(*p1), &(v710_7_tail));
          compose(&(v711_5),&(v712_7))
        };
        drop(v711_5);
        let v711_9: Space = intersect(&(*CONSTANT_14),&(v711_2));
        drop(v711_2);
        let v711_10: Space = if has_head(&(v711_9)) { singleton(&[]) } else { Space::new() };
        drop(v711_9);
        let v711_12: Space = if (v711_10).is_empty() { Space::new() } else {
          let v713_6: Path = concat_path(&(v710_6),&(v710_7_head));
          let v713_11: Space = routine_113(c, &(v713_6), &(*p1), &(v710_7_tail));
          drop(v713_6);
          compose(&(v711_10),&(v713_11))
        };
        drop(v711_10);
        let v711_13: Space = unite(&(v711_8),&(v711_12));
        v710_7.join_into((v711_13).clone());
      }
      drop(v710_7_cursor);
      compose(&(v709_5),&(v710_7))
    };
    drop(v709_5);
    let v709_9: Space = intersect(&(*CONSTANT_14),&(v709_2));
    drop(v709_2);
    let v709_10: Space = if has_head(&(v709_9)) { singleton(&[]) } else { Space::new() };
    drop(v709_9);
    let v709_12: Space = if (v709_10).is_empty() { Space::new() } else {
      let v714_6: Path = concat_path(&(*p0),&(v708_12_head));
      let mut v714_11 = Space::new();
      let mut v714_11_cursor = (v708_12_tail).read_zipper();
      for v714_11_byte in v714_11_cursor.child_mask().iter() {
        v714_11_cursor.descend_to_byte(v714_11_byte);
        let v714_11_tail = v714_11_cursor.make_map();
        v714_11_cursor.ascend(1);
        let v714_11_head = Path::from_slice(&[v714_11_byte]);
        let v715_2: Space = singleton(&(v714_11_head));
        let v715_3: Space = intersect(&(*CONSTANT_14),&(v715_2));
        let v715_4: Space = if has_head(&(v715_3)) { singleton(&[]) } else { Space::new() };
        drop(v715_3);
        let v715_5: Space = subtract(&(*CONSTANT_0),&(v715_4));
        drop(v715_4);
        let v715_8: Space = if (v715_5).is_empty() { Space::new() } else {
          let v716_6: Path = concat_path(&(v714_6),&(v714_11_head));
          let v716_7: Space = routine_112(c, &(v716_6), &(*p1), &(v714_11_tail));
          compose(&(v715_5),&(v716_7))
        };
        drop(v715_5);
        let v715_9: Space = intersect(&(*CONSTANT_14),&(v715_2));
        drop(v715_2);
        let v715_10: Space = if has_head(&(v715_9)) { singleton(&[]) } else { Space::new() };
        drop(v715_9);
        let v715_12: Space = if (v715_10).is_empty() { Space::new() } else {
          let v717_6: Path = concat_path(&(v714_6),&(v714_11_head));
          let v717_11: Space = routine_82(c, &(v717_6), &(*p1), &(v714_11_tail));
          drop(v717_6);
          compose(&(v715_10),&(v717_11))
        };
        drop(v715_10);
        let v715_13: Space = unite(&(v715_8),&(v715_12));
        v714_11.join_into((v715_13).clone());
      }
      drop(v714_11_cursor);
      drop(v714_6);
      compose(&(v709_10),&(v714_11))
    };
    drop(v709_10);
    let v709_13: Space = unite(&(v709_8),&(v709_12));
    v708_12.join_into((v709_13).clone());
  }
  drop(v708_12_cursor);
  (v708_12).clone()
}

fn routine_77(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v718_9 = Space::new();
  let mut v718_9_cursor = (*s0).read_zipper();
  for v718_9_byte in v718_9_cursor.child_mask().iter() {
    v718_9_cursor.descend_to_byte(v718_9_byte);
    let v718_9_tail = v718_9_cursor.make_map();
    v718_9_cursor.ascend(1);
    let v718_9_head = Path::from_slice(&[v718_9_byte]);
    let v719_2: Space = singleton(&(v718_9_head));
    let v719_3: Space = intersect(&(*CONSTANT_14),&(v719_2));
    let v719_4: Space = if has_head(&(v719_3)) { singleton(&[]) } else { Space::new() };
    drop(v719_3);
    let v719_5: Space = subtract(&(*CONSTANT_0),&(v719_4));
    drop(v719_4);
    let v719_8: Space = if (v719_5).is_empty() { Space::new() } else {
      let v720_6: Path = concat_path(&(*p0),&(v718_9_head));
      let mut v720_7 = Space::new();
      let mut v720_7_cursor = (v718_9_tail).read_zipper();
      for v720_7_byte in v720_7_cursor.child_mask().iter() {
        v720_7_cursor.descend_to_byte(v720_7_byte);
        let v720_7_tail = v720_7_cursor.make_map();
        v720_7_cursor.ascend(1);
        let v720_7_head = Path::from_slice(&[v720_7_byte]);
        let v721_2: Space = singleton(&(v720_7_head));
        let v721_3: Space = intersect(&(*CONSTANT_14),&(v721_2));
        let v721_4: Space = if has_head(&(v721_3)) { singleton(&[]) } else { Space::new() };
        drop(v721_3);
        let v721_5: Space = subtract(&(*CONSTANT_0),&(v721_4));
        drop(v721_4);
        let v721_8: Space = if (v721_5).is_empty() { Space::new() } else {
          let v722_6: Path = concat_path(&(v720_6),&(v720_7_head));
          let v722_7: Space = routine_112(c, &(v722_6), &(*p1), &(v720_7_tail));
          compose(&(v721_5),&(v722_7))
        };
        drop(v721_5);
        let v721_9: Space = intersect(&(*CONSTANT_14),&(v721_2));
        drop(v721_2);
        let v721_10: Space = if has_head(&(v721_9)) { singleton(&[]) } else { Space::new() };
        drop(v721_9);
        let v721_12: Space = if (v721_10).is_empty() { Space::new() } else {
          let v723_6: Path = concat_path(&(v720_6),&(v720_7_head));
          let v723_11: Space = routine_113(c, &(v723_6), &(*p1), &(v720_7_tail));
          drop(v723_6);
          compose(&(v721_10),&(v723_11))
        };
        drop(v721_10);
        let v721_13: Space = unite(&(v721_8),&(v721_12));
        v720_7.join_into((v721_13).clone());
      }
      drop(v720_7_cursor);
      compose(&(v719_5),&(v720_7))
    };
    drop(v719_5);
    let v719_9: Space = intersect(&(*CONSTANT_14),&(v719_2));
    drop(v719_2);
    let v719_10: Space = if has_head(&(v719_9)) { singleton(&[]) } else { Space::new() };
    drop(v719_9);
    let v719_11: Space = compose(&(v719_10),&(v718_9_tail));
    drop(v719_10);
    let v724_6: Path = concat_path(&(*p0),&(v718_9_head));
    let v719_12: Space = wrap(&(v719_11),&(v724_6));
    drop(v719_11);
    let v719_13: Space = wrap(&(v719_12),&(*p1));
    drop(v719_12);
    let v719_14: Space = unite(&(v719_8),&(v719_13));
    drop(v719_13);
    v718_9.join_into((v719_14).clone());
  }
  drop(v718_9_cursor);
  (v718_9).clone()
}

fn routine_78(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v725_13 = Space::new();
  let mut v725_13_cursor = (*s0).read_zipper();
  for v725_13_byte in v725_13_cursor.child_mask().iter() {
    v725_13_cursor.descend_to_byte(v725_13_byte);
    let v725_13_tail = v725_13_cursor.make_map();
    v725_13_cursor.ascend(1);
    let v725_13_head = Path::from_slice(&[v725_13_byte]);
    let v726_2: Space = singleton(&(v725_13_head));
    let v726_3: Space = intersect(&(*CONSTANT_14),&(v726_2));
    let v726_4: Space = if has_head(&(v726_3)) { singleton(&[]) } else { Space::new() };
    drop(v726_3);
    let v726_5: Space = subtract(&(*CONSTANT_0),&(v726_4));
    drop(v726_4);
    let v726_8: Space = if (v726_5).is_empty() { Space::new() } else {
      let v727_6: Path = concat_path(&(*p0),&(v725_13_head));
      let mut v727_7 = Space::new();
      let mut v727_7_cursor = (v725_13_tail).read_zipper();
      for v727_7_byte in v727_7_cursor.child_mask().iter() {
        v727_7_cursor.descend_to_byte(v727_7_byte);
        let v727_7_tail = v727_7_cursor.make_map();
        v727_7_cursor.ascend(1);
        let v727_7_head = Path::from_slice(&[v727_7_byte]);
        let v728_2: Space = singleton(&(v727_7_head));
        let v728_3: Space = intersect(&(*CONSTANT_14),&(v728_2));
        let v728_4: Space = if has_head(&(v728_3)) { singleton(&[]) } else { Space::new() };
        drop(v728_3);
        let v728_5: Space = subtract(&(*CONSTANT_0),&(v728_4));
        drop(v728_4);
        let v728_8: Space = if (v728_5).is_empty() { Space::new() } else {
          let v729_6: Path = concat_path(&(v727_6),&(v727_7_head));
          let v729_7: Space = routine_114(c, &(v729_6), &(*p1), &(v727_7_tail), &(*s1));
          compose(&(v728_5),&(v729_7))
        };
        drop(v728_5);
        let v728_9: Space = intersect(&(*CONSTANT_14),&(v728_2));
        drop(v728_2);
        let v728_10: Space = if has_head(&(v728_9)) { singleton(&[]) } else { Space::new() };
        drop(v728_9);
        let v728_12: Space = if (v728_10).is_empty() { Space::new() } else {
          let v730_6: Path = concat_path(&(v727_6),&(v727_7_head));
          let v730_11: Space = routine_115(c, &(v730_6), &(*p1), &(v727_7_tail), &(*s1));
          drop(v730_6);
          compose(&(v728_10),&(v730_11))
        };
        drop(v728_10);
        let v728_13: Space = unite(&(v728_8),&(v728_12));
        v727_7.join_into((v728_13).clone());
      }
      drop(v727_7_cursor);
      compose(&(v726_5),&(v727_7))
    };
    drop(v726_5);
    let v726_9: Space = intersect(&(*CONSTANT_14),&(v726_2));
    drop(v726_2);
    let v726_10: Space = if has_head(&(v726_9)) { singleton(&[]) } else { Space::new() };
    drop(v726_9);
    let v726_12: Space = if (v726_10).is_empty() { Space::new() } else {
      let v731_6: Path = concat_path(&(*p0),&(v725_13_head));
      let mut v731_11 = Space::new();
      let mut v731_11_cursor = (v725_13_tail).read_zipper();
      for v731_11_byte in v731_11_cursor.child_mask().iter() {
        v731_11_cursor.descend_to_byte(v731_11_byte);
        let v731_11_tail = v731_11_cursor.make_map();
        v731_11_cursor.ascend(1);
        let v731_11_head = Path::from_slice(&[v731_11_byte]);
        let v732_2: Space = singleton(&(v731_11_head));
        let v732_3: Space = intersect(&(*CONSTANT_14),&(v732_2));
        let v732_4: Space = if has_head(&(v732_3)) { singleton(&[]) } else { Space::new() };
        drop(v732_3);
        let v732_5: Space = subtract(&(*CONSTANT_0),&(v732_4));
        drop(v732_4);
        let v732_8: Space = if (v732_5).is_empty() { Space::new() } else {
          let v733_6: Path = concat_path(&(v731_6),&(v731_11_head));
          let v733_7: Space = routine_114(c, &(v733_6), &(*p1), &(v731_11_tail), &(*s1));
          compose(&(v732_5),&(v733_7))
        };
        drop(v732_5);
        let v732_9: Space = intersect(&(*CONSTANT_14),&(v732_2));
        drop(v732_2);
        let v732_10: Space = if has_head(&(v732_9)) { singleton(&[]) } else { Space::new() };
        drop(v732_9);
        let v732_12: Space = if (v732_10).is_empty() { Space::new() } else {
          let v734_6: Path = concat_path(&(v731_6),&(v731_11_head));
          let v734_11: Space = routine_40(c, &(v734_6), &(*p1), &(v731_11_tail), &(*s1));
          drop(v734_6);
          compose(&(v732_10),&(v734_11))
        };
        drop(v732_10);
        let v732_13: Space = unite(&(v732_8),&(v732_12));
        v731_11.join_into((v732_13).clone());
      }
      drop(v731_11_cursor);
      drop(v731_6);
      compose(&(v726_10),&(v731_11))
    };
    drop(v726_10);
    let v726_13: Space = unite(&(v726_8),&(v726_12));
    v725_13.join_into((v726_13).clone());
  }
  drop(v725_13_cursor);
  (v725_13).clone()
}

fn routine_79(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v735_8: Space = unwrap(&(*s1),&(*CONSTANT_9));
  let v735_10: Space = unwrap(&(v735_8),&(*CONSTANT_10));
  drop(v735_8);
  let v735_11: Space = unwrap(&(v735_10),&(*p0));
  drop(v735_10);
  let mut v735_18 = Space::new();
  let mut v735_18_cursor = (*s0).read_zipper();
  for v735_18_byte in v735_18_cursor.child_mask().iter() {
    v735_18_cursor.descend_to_byte(v735_18_byte);
    let v735_18_tail = v735_18_cursor.make_map();
    v735_18_cursor.ascend(1);
    let v735_18_head = Path::from_slice(&[v735_18_byte]);
    let v736_2: Space = singleton(&(v735_18_head));
    let v736_3: Space = intersect(&(*CONSTANT_14),&(v736_2));
    let v736_4: Space = if has_head(&(v736_3)) { singleton(&[]) } else { Space::new() };
    drop(v736_3);
    let v736_5: Space = subtract(&(*CONSTANT_0),&(v736_4));
    drop(v736_4);
    let v736_8: Space = if (v736_5).is_empty() { Space::new() } else {
      let v737_6: Path = concat_path(&(*p0),&(v735_18_head));
      let mut v737_7 = Space::new();
      let mut v737_7_cursor = (v735_18_tail).read_zipper();
      for v737_7_byte in v737_7_cursor.child_mask().iter() {
        v737_7_cursor.descend_to_byte(v737_7_byte);
        let v737_7_tail = v737_7_cursor.make_map();
        v737_7_cursor.ascend(1);
        let v737_7_head = Path::from_slice(&[v737_7_byte]);
        let v738_2: Space = singleton(&(v737_7_head));
        let v738_3: Space = intersect(&(*CONSTANT_14),&(v738_2));
        let v738_4: Space = if has_head(&(v738_3)) { singleton(&[]) } else { Space::new() };
        drop(v738_3);
        let v738_5: Space = subtract(&(*CONSTANT_0),&(v738_4));
        drop(v738_4);
        let v738_8: Space = if (v738_5).is_empty() { Space::new() } else {
          let v739_6: Path = concat_path(&(v737_6),&(v737_7_head));
          let v739_7: Space = routine_114(c, &(v739_6), &(*p1), &(v737_7_tail), &(*s1));
          compose(&(v738_5),&(v739_7))
        };
        drop(v738_5);
        let v738_9: Space = intersect(&(*CONSTANT_14),&(v738_2));
        drop(v738_2);
        let v738_10: Space = if has_head(&(v738_9)) { singleton(&[]) } else { Space::new() };
        drop(v738_9);
        let v738_12: Space = if (v738_10).is_empty() { Space::new() } else {
          let v740_6: Path = concat_path(&(v737_6),&(v737_7_head));
          let v740_11: Space = routine_115(c, &(v740_6), &(*p1), &(v737_7_tail), &(*s1));
          drop(v740_6);
          compose(&(v738_10),&(v740_11))
        };
        drop(v738_10);
        let v738_13: Space = unite(&(v738_8),&(v738_12));
        v737_7.join_into((v738_13).clone());
      }
      drop(v737_7_cursor);
      drop(v737_6);
      compose(&(v736_5),&(v737_7))
    };
    drop(v736_5);
    let v736_9: Space = intersect(&(*CONSTANT_14),&(v736_2));
    drop(v736_2);
    let v736_10: Space = if has_head(&(v736_9)) { singleton(&[]) } else { Space::new() };
    drop(v736_9);
    let v736_13: Space = if (v736_10).is_empty() { Space::new() } else {
      let v741_11: Space = unwrap(&(v735_11),&(v735_18_head));
      let mut v741_12 = Space::new();
      let mut v741_12_cursor = (v741_11).read_zipper();
      for v741_12_byte in v741_12_cursor.child_mask().iter() {
        v741_12_cursor.descend_to_byte(v741_12_byte);
        let v741_12_tail = v741_12_cursor.make_map();
        v741_12_cursor.ascend(1);
        let v741_12_head = Path::from_slice(&[v741_12_byte]);
        let v742_2: Space = singleton(&(v741_12_head));
        let v742_3: Space = intersect(&(*CONSTANT_14),&(v742_2));
        let v742_4: Space = if has_head(&(v742_3)) { singleton(&[]) } else { Space::new() };
        drop(v742_3);
        let v742_5: Space = subtract(&(*CONSTANT_0),&(v742_4));
        drop(v742_4);
        let v742_7: Space = if (v742_5).is_empty() { Space::new() } else {
          let v743_6: Space = routine_76(c, &(v741_12_head), &(*p1), &(v741_12_tail));
          compose(&(v742_5),&(v743_6))
        };
        drop(v742_5);
        let v742_8: Space = intersect(&(*CONSTANT_14),&(v742_2));
        drop(v742_2);
        let v742_9: Space = if has_head(&(v742_8)) { singleton(&[]) } else { Space::new() };
        drop(v742_8);
        let v742_11: Space = if (v742_9).is_empty() { Space::new() } else {
          let v744_10: Space = routine_77(c, &(v741_12_head), &(*p1), &(v741_12_tail));
          compose(&(v742_9),&(v744_10))
        };
        drop(v742_9);
        let v742_12: Space = unite(&(v742_7),&(v742_11));
        v741_12.join_into((v742_12).clone());
      }
      drop(v741_12_cursor);
      drop(v741_11);
      compose(&(v736_10),&(v741_12))
    };
    drop(v736_10);
    let v736_14: Space = unite(&(v736_8),&(v736_13));
    v735_18.join_into((v736_14).clone());
  }
  drop(v735_18_cursor);
  drop(v735_11);
  (v735_18).clone()
}

fn routine_80(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v745_12 = Space::new();
  let mut v745_12_cursor = (*s0).read_zipper();
  for v745_12_byte in v745_12_cursor.child_mask().iter() {
    v745_12_cursor.descend_to_byte(v745_12_byte);
    let v745_12_tail = v745_12_cursor.make_map();
    v745_12_cursor.ascend(1);
    let v745_12_head = Path::from_slice(&[v745_12_byte]);
    let v746_2: Space = singleton(&(v745_12_head));
    let v746_3: Space = intersect(&(*CONSTANT_14),&(v746_2));
    let v746_4: Space = if has_head(&(v746_3)) { singleton(&[]) } else { Space::new() };
    drop(v746_3);
    let v746_5: Space = subtract(&(*CONSTANT_0),&(v746_4));
    drop(v746_4);
    let v746_8: Space = if (v746_5).is_empty() { Space::new() } else {
      let v747_6: Path = concat_path(&(*p0),&(v745_12_head));
      let mut v747_7 = Space::new();
      let mut v747_7_cursor = (v745_12_tail).read_zipper();
      for v747_7_byte in v747_7_cursor.child_mask().iter() {
        v747_7_cursor.descend_to_byte(v747_7_byte);
        let v747_7_tail = v747_7_cursor.make_map();
        v747_7_cursor.ascend(1);
        let v747_7_head = Path::from_slice(&[v747_7_byte]);
        let v748_2: Space = singleton(&(v747_7_head));
        let v748_3: Space = intersect(&(*CONSTANT_14),&(v748_2));
        let v748_4: Space = if has_head(&(v748_3)) { singleton(&[]) } else { Space::new() };
        drop(v748_3);
        let v748_5: Space = subtract(&(*CONSTANT_0),&(v748_4));
        drop(v748_4);
        let v748_8: Space = if (v748_5).is_empty() { Space::new() } else {
          let v749_6: Path = concat_path(&(v747_6),&(v747_7_head));
          let v749_7: Space = routine_116(c, &(v749_6), &(*p1), &(v747_7_tail));
          compose(&(v748_5),&(v749_7))
        };
        drop(v748_5);
        let v748_9: Space = intersect(&(*CONSTANT_14),&(v748_2));
        drop(v748_2);
        let v748_10: Space = if has_head(&(v748_9)) { singleton(&[]) } else { Space::new() };
        drop(v748_9);
        let v748_12: Space = if (v748_10).is_empty() { Space::new() } else {
          let v750_6: Path = concat_path(&(v747_6),&(v747_7_head));
          let v750_11: Space = routine_117(c, &(v750_6), &(*p1), &(v747_7_tail));
          drop(v750_6);
          compose(&(v748_10),&(v750_11))
        };
        drop(v748_10);
        let v748_13: Space = unite(&(v748_8),&(v748_12));
        v747_7.join_into((v748_13).clone());
      }
      drop(v747_7_cursor);
      compose(&(v746_5),&(v747_7))
    };
    drop(v746_5);
    let v746_9: Space = intersect(&(*CONSTANT_14),&(v746_2));
    drop(v746_2);
    let v746_10: Space = if has_head(&(v746_9)) { singleton(&[]) } else { Space::new() };
    drop(v746_9);
    let v746_12: Space = if (v746_10).is_empty() { Space::new() } else {
      let v751_6: Path = concat_path(&(*p0),&(v745_12_head));
      let mut v751_11 = Space::new();
      let mut v751_11_cursor = (v745_12_tail).read_zipper();
      for v751_11_byte in v751_11_cursor.child_mask().iter() {
        v751_11_cursor.descend_to_byte(v751_11_byte);
        let v751_11_tail = v751_11_cursor.make_map();
        v751_11_cursor.ascend(1);
        let v751_11_head = Path::from_slice(&[v751_11_byte]);
        let v752_2: Space = singleton(&(v751_11_head));
        let v752_3: Space = intersect(&(*CONSTANT_14),&(v752_2));
        let v752_4: Space = if has_head(&(v752_3)) { singleton(&[]) } else { Space::new() };
        drop(v752_3);
        let v752_5: Space = subtract(&(*CONSTANT_0),&(v752_4));
        drop(v752_4);
        let v752_8: Space = if (v752_5).is_empty() { Space::new() } else {
          let v753_6: Path = concat_path(&(v751_6),&(v751_11_head));
          let v753_7: Space = routine_116(c, &(v753_6), &(*p1), &(v751_11_tail));
          compose(&(v752_5),&(v753_7))
        };
        drop(v752_5);
        let v752_9: Space = intersect(&(*CONSTANT_14),&(v752_2));
        drop(v752_2);
        let v752_10: Space = if has_head(&(v752_9)) { singleton(&[]) } else { Space::new() };
        drop(v752_9);
        let v752_12: Space = if (v752_10).is_empty() { Space::new() } else {
          let v754_6: Path = concat_path(&(v751_6),&(v751_11_head));
          let v754_11: Space = routine_82(c, &(v754_6), &(*p1), &(v751_11_tail));
          drop(v754_6);
          compose(&(v752_10),&(v754_11))
        };
        drop(v752_10);
        let v752_13: Space = unite(&(v752_8),&(v752_12));
        v751_11.join_into((v752_13).clone());
      }
      drop(v751_11_cursor);
      drop(v751_6);
      compose(&(v746_10),&(v751_11))
    };
    drop(v746_10);
    let v746_13: Space = unite(&(v746_8),&(v746_12));
    v745_12.join_into((v746_13).clone());
  }
  drop(v745_12_cursor);
  (v745_12).clone()
}

fn routine_81(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v755_9 = Space::new();
  let mut v755_9_cursor = (*s0).read_zipper();
  for v755_9_byte in v755_9_cursor.child_mask().iter() {
    v755_9_cursor.descend_to_byte(v755_9_byte);
    let v755_9_tail = v755_9_cursor.make_map();
    v755_9_cursor.ascend(1);
    let v755_9_head = Path::from_slice(&[v755_9_byte]);
    let v756_2: Space = singleton(&(v755_9_head));
    let v756_3: Space = intersect(&(*CONSTANT_14),&(v756_2));
    let v756_4: Space = if has_head(&(v756_3)) { singleton(&[]) } else { Space::new() };
    drop(v756_3);
    let v756_5: Space = subtract(&(*CONSTANT_0),&(v756_4));
    drop(v756_4);
    let v756_8: Space = if (v756_5).is_empty() { Space::new() } else {
      let v757_6: Path = concat_path(&(*p0),&(v755_9_head));
      let mut v757_7 = Space::new();
      let mut v757_7_cursor = (v755_9_tail).read_zipper();
      for v757_7_byte in v757_7_cursor.child_mask().iter() {
        v757_7_cursor.descend_to_byte(v757_7_byte);
        let v757_7_tail = v757_7_cursor.make_map();
        v757_7_cursor.ascend(1);
        let v757_7_head = Path::from_slice(&[v757_7_byte]);
        let v758_2: Space = singleton(&(v757_7_head));
        let v758_3: Space = intersect(&(*CONSTANT_14),&(v758_2));
        let v758_4: Space = if has_head(&(v758_3)) { singleton(&[]) } else { Space::new() };
        drop(v758_3);
        let v758_5: Space = subtract(&(*CONSTANT_0),&(v758_4));
        drop(v758_4);
        let v758_8: Space = if (v758_5).is_empty() { Space::new() } else {
          let v759_6: Path = concat_path(&(v757_6),&(v757_7_head));
          let v759_7: Space = routine_116(c, &(v759_6), &(*p1), &(v757_7_tail));
          compose(&(v758_5),&(v759_7))
        };
        drop(v758_5);
        let v758_9: Space = intersect(&(*CONSTANT_14),&(v758_2));
        drop(v758_2);
        let v758_10: Space = if has_head(&(v758_9)) { singleton(&[]) } else { Space::new() };
        drop(v758_9);
        let v758_12: Space = if (v758_10).is_empty() { Space::new() } else {
          let v760_6: Path = concat_path(&(v757_6),&(v757_7_head));
          let v760_11: Space = routine_117(c, &(v760_6), &(*p1), &(v757_7_tail));
          drop(v760_6);
          compose(&(v758_10),&(v760_11))
        };
        drop(v758_10);
        let v758_13: Space = unite(&(v758_8),&(v758_12));
        v757_7.join_into((v758_13).clone());
      }
      drop(v757_7_cursor);
      compose(&(v756_5),&(v757_7))
    };
    drop(v756_5);
    let v756_9: Space = intersect(&(*CONSTANT_14),&(v756_2));
    drop(v756_2);
    let v756_10: Space = if has_head(&(v756_9)) { singleton(&[]) } else { Space::new() };
    drop(v756_9);
    let v756_11: Space = compose(&(v756_10),&(v755_9_tail));
    drop(v756_10);
    let v761_6: Path = concat_path(&(*p0),&(v755_9_head));
    let v756_12: Space = wrap(&(v756_11),&(v761_6));
    drop(v756_11);
    let v756_13: Space = wrap(&(v756_12),&(*p1));
    drop(v756_12);
    let v756_14: Space = unite(&(v756_8),&(v756_13));
    drop(v756_13);
    v755_9.join_into((v756_14).clone());
  }
  drop(v755_9_cursor);
  (v755_9).clone()
}

fn routine_82(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v762_3: Space = wrap(&(*s0),&(*p0));
  let v762_4: Space = wrap(&(v762_3),&(*p1));
  drop(v762_3);
  (v762_4).clone()
}

fn routine_83(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v763_7 = Space::new();
  let mut v763_7_cursor = (*s0).read_zipper();
  for v763_7_byte in v763_7_cursor.child_mask().iter() {
    v763_7_cursor.descend_to_byte(v763_7_byte);
    let v763_7_tail = v763_7_cursor.make_map();
    v763_7_cursor.ascend(1);
    let v763_7_head = Path::from_slice(&[v763_7_byte]);
    let v764_2: Space = singleton(&(v763_7_head));
    let v764_3: Space = intersect(&(*CONSTANT_14),&(v764_2));
    let v764_4: Space = if has_head(&(v764_3)) { singleton(&[]) } else { Space::new() };
    drop(v764_3);
    let v764_5: Space = subtract(&(*CONSTANT_0),&(v764_4));
    drop(v764_4);
    let mut v764_6 = Space::new();
    let mut v764_6_cursor = (v763_7_tail).read_zipper();
    for v764_6_byte in v764_6_cursor.child_mask().iter() {
      v764_6_cursor.descend_to_byte(v764_6_byte);
      let v764_6_tail = v764_6_cursor.make_map();
      v764_6_cursor.ascend(1);
      let v764_6_head = Path::from_slice(&[v764_6_byte]);
      let v765_2: Space = Space::new();
      v764_6.join_into((v765_2).clone());
    }
    drop(v764_6_cursor);
    let v764_7: Space = compose(&(v764_5),&(v764_6));
    drop(v764_5);
    drop(v764_6);
    let v764_8: Space = intersect(&(*CONSTANT_14),&(v764_2));
    drop(v764_2);
    let v764_9: Space = if has_head(&(v764_8)) { singleton(&[]) } else { Space::new() };
    drop(v764_8);
    let v764_12: Space = if (v764_9).is_empty() { Space::new() } else {
      let v766_10: Path = concat_path(&(*p0),&(v763_7_head));
      let mut v766_11 = Space::new();
      let mut v766_11_cursor = (v763_7_tail).read_zipper();
      for v766_11_byte in v766_11_cursor.child_mask().iter() {
        v766_11_cursor.descend_to_byte(v766_11_byte);
        let v766_11_tail = v766_11_cursor.make_map();
        v766_11_cursor.ascend(1);
        let v766_11_head = Path::from_slice(&[v766_11_byte]);
        let v767_2: Space = singleton(&(v766_11_head));
        let v767_3: Space = intersect(&(*CONSTANT_14),&(v767_2));
        drop(v767_2);
        let v767_4: Space = if has_head(&(v767_3)) { singleton(&[]) } else { Space::new() };
        drop(v767_3);
        let v767_7: Space = if (v767_4).is_empty() { Space::new() } else {
          let v768_5: Path = concat_path(&(v766_10),&(v766_11_head));
          let v768_6: Space = routine_14(c, &(v768_5), &(v766_11_tail), &(*s1));
          drop(v768_5);
          compose(&(v767_4),&(v768_6))
        };
        drop(v767_4);
        v766_11.join_into((v767_7).clone());
      }
      drop(v766_11_cursor);
      drop(v766_10);
      compose(&(v764_9),&(v766_11))
    };
    drop(v764_9);
    let v764_13: Space = unite(&(v764_7),&(v764_12));
    drop(v764_7);
    v763_7.join_into((v764_13).clone());
  }
  drop(v763_7_cursor);
  (v763_7).clone()
}

fn routine_84(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v769_9 = Space::new();
  let mut v769_9_cursor = (*s0).read_zipper();
  for v769_9_byte in v769_9_cursor.child_mask().iter() {
    v769_9_cursor.descend_to_byte(v769_9_byte);
    let v769_9_tail = v769_9_cursor.make_map();
    v769_9_cursor.ascend(1);
    let v769_9_head = Path::from_slice(&[v769_9_byte]);
    let v770_2: Space = singleton(&(v769_9_head));
    let v770_3: Space = intersect(&(*CONSTANT_14),&(v770_2));
    let v770_4: Space = if has_head(&(v770_3)) { singleton(&[]) } else { Space::new() };
    drop(v770_3);
    let v770_5: Space = subtract(&(*CONSTANT_0),&(v770_4));
    drop(v770_4);
    let mut v770_6 = Space::new();
    let mut v770_6_cursor = (v769_9_tail).read_zipper();
    for v770_6_byte in v770_6_cursor.child_mask().iter() {
      v770_6_cursor.descend_to_byte(v770_6_byte);
      let v770_6_tail = v770_6_cursor.make_map();
      v770_6_cursor.ascend(1);
      let v770_6_head = Path::from_slice(&[v770_6_byte]);
      let v771_2: Space = Space::new();
      v770_6.join_into((v771_2).clone());
    }
    drop(v770_6_cursor);
    let v770_7: Space = compose(&(v770_5),&(v770_6));
    drop(v770_5);
    drop(v770_6);
    let v770_8: Space = intersect(&(*CONSTANT_14),&(v770_2));
    drop(v770_2);
    let v770_9: Space = if has_head(&(v770_8)) { singleton(&[]) } else { Space::new() };
    drop(v770_8);
    let v770_12: Space = if (v770_9).is_empty() { Space::new() } else {
      let v772_10: Path = concat_path(&(*p0),&(v769_9_head));
      let mut v772_11 = Space::new();
      let mut v772_11_cursor = (v769_9_tail).read_zipper();
      for v772_11_byte in v772_11_cursor.child_mask().iter() {
        v772_11_cursor.descend_to_byte(v772_11_byte);
        let v772_11_tail = v772_11_cursor.make_map();
        v772_11_cursor.ascend(1);
        let v772_11_head = Path::from_slice(&[v772_11_byte]);
        let v773_2: Space = singleton(&(v772_11_head));
        let v773_3: Space = intersect(&(*CONSTANT_14),&(v773_2));
        let v773_4: Space = if has_head(&(v773_3)) { singleton(&[]) } else { Space::new() };
        drop(v773_3);
        let v773_5: Space = subtract(&(*CONSTANT_0),&(v773_4));
        drop(v773_4);
        let v773_7: Space = if (v773_5).is_empty() { Space::new() } else {
          let v774_6: Space = routine_43(c, &(v772_11_head), &(v772_10), &(v772_11_tail), &(*s1));
          compose(&(v773_5),&(v774_6))
        };
        drop(v773_5);
        let v773_8: Space = intersect(&(*CONSTANT_14),&(v773_2));
        drop(v773_2);
        let v773_9: Space = if has_head(&(v773_8)) { singleton(&[]) } else { Space::new() };
        drop(v773_8);
        let v773_11: Space = if (v773_9).is_empty() { Space::new() } else {
          let v775_10: Space = routine_44(c, &(v772_11_head), &(v772_10), &(v772_11_tail), &(*s1));
          compose(&(v773_9),&(v775_10))
        };
        drop(v773_9);
        let v773_12: Space = unite(&(v773_7),&(v773_11));
        v772_11.join_into((v773_12).clone());
      }
      drop(v772_11_cursor);
      drop(v772_10);
      compose(&(v770_9),&(v772_11))
    };
    drop(v770_9);
    let v770_13: Space = unite(&(v770_7),&(v770_12));
    drop(v770_7);
    v769_9.join_into((v770_13).clone());
  }
  drop(v769_9_cursor);
  (v769_9).clone()
}

fn routine_85(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v776_13 = Space::new();
  let mut v776_13_cursor = (*s0).read_zipper();
  for v776_13_byte in v776_13_cursor.child_mask().iter() {
    v776_13_cursor.descend_to_byte(v776_13_byte);
    let v776_13_tail = v776_13_cursor.make_map();
    v776_13_cursor.ascend(1);
    let v776_13_head = Path::from_slice(&[v776_13_byte]);
    let v777_2: Space = singleton(&(v776_13_head));
    let v777_3: Space = intersect(&(*CONSTANT_14),&(v777_2));
    let v777_4: Space = if has_head(&(v777_3)) { singleton(&[]) } else { Space::new() };
    drop(v777_3);
    let v777_5: Space = subtract(&(*CONSTANT_0),&(v777_4));
    drop(v777_4);
    let v777_8: Space = if (v777_5).is_empty() { Space::new() } else {
      let v778_6: Path = concat_path(&(*p0),&(v776_13_head));
      let mut v778_7 = Space::new();
      let mut v778_7_cursor = (v776_13_tail).read_zipper();
      for v778_7_byte in v778_7_cursor.child_mask().iter() {
        v778_7_cursor.descend_to_byte(v778_7_byte);
        let v778_7_tail = v778_7_cursor.make_map();
        v778_7_cursor.ascend(1);
        let v778_7_head = Path::from_slice(&[v778_7_byte]);
        let v779_2: Space = singleton(&(v778_7_head));
        let v779_3: Space = intersect(&(*CONSTANT_14),&(v779_2));
        let v779_4: Space = if has_head(&(v779_3)) { singleton(&[]) } else { Space::new() };
        drop(v779_3);
        let v779_5: Space = subtract(&(*CONSTANT_0),&(v779_4));
        drop(v779_4);
        let v779_8: Space = if (v779_5).is_empty() { Space::new() } else {
          let v780_6: Path = concat_path(&(v778_6),&(v778_7_head));
          let v780_7: Space = routine_118(c, &(v780_6), &(*p1), &(v778_7_tail), &(*s1));
          compose(&(v779_5),&(v780_7))
        };
        drop(v779_5);
        let v779_9: Space = intersect(&(*CONSTANT_14),&(v779_2));
        drop(v779_2);
        let v779_10: Space = if has_head(&(v779_9)) { singleton(&[]) } else { Space::new() };
        drop(v779_9);
        let v779_12: Space = if (v779_10).is_empty() { Space::new() } else {
          let v781_6: Path = concat_path(&(v778_6),&(v778_7_head));
          let v781_11: Space = routine_119(c, &(v781_6), &(*p1), &(v778_7_tail), &(*s1));
          drop(v781_6);
          compose(&(v779_10),&(v781_11))
        };
        drop(v779_10);
        let v779_13: Space = unite(&(v779_8),&(v779_12));
        v778_7.join_into((v779_13).clone());
      }
      drop(v778_7_cursor);
      compose(&(v777_5),&(v778_7))
    };
    drop(v777_5);
    let v777_9: Space = intersect(&(*CONSTANT_14),&(v777_2));
    drop(v777_2);
    let v777_10: Space = if has_head(&(v777_9)) { singleton(&[]) } else { Space::new() };
    drop(v777_9);
    let v777_12: Space = if (v777_10).is_empty() { Space::new() } else {
      let v782_6: Path = concat_path(&(*p0),&(v776_13_head));
      let mut v782_11 = Space::new();
      let mut v782_11_cursor = (v776_13_tail).read_zipper();
      for v782_11_byte in v782_11_cursor.child_mask().iter() {
        v782_11_cursor.descend_to_byte(v782_11_byte);
        let v782_11_tail = v782_11_cursor.make_map();
        v782_11_cursor.ascend(1);
        let v782_11_head = Path::from_slice(&[v782_11_byte]);
        let v783_2: Space = singleton(&(v782_11_head));
        let v783_3: Space = intersect(&(*CONSTANT_14),&(v783_2));
        let v783_4: Space = if has_head(&(v783_3)) { singleton(&[]) } else { Space::new() };
        drop(v783_3);
        let v783_5: Space = subtract(&(*CONSTANT_0),&(v783_4));
        drop(v783_4);
        let v783_8: Space = if (v783_5).is_empty() { Space::new() } else {
          let v784_6: Path = concat_path(&(v782_6),&(v782_11_head));
          let v784_7: Space = routine_118(c, &(v784_6), &(*p1), &(v782_11_tail), &(*s1));
          compose(&(v783_5),&(v784_7))
        };
        drop(v783_5);
        let v783_9: Space = intersect(&(*CONSTANT_14),&(v783_2));
        drop(v783_2);
        let v783_10: Space = if has_head(&(v783_9)) { singleton(&[]) } else { Space::new() };
        drop(v783_9);
        let v783_12: Space = if (v783_10).is_empty() { Space::new() } else {
          let v785_6: Path = concat_path(&(v782_6),&(v782_11_head));
          let v785_11: Space = routine_47(c, &(v785_6), &(*p1), &(v782_11_tail), &(*s1));
          drop(v785_6);
          compose(&(v783_10),&(v785_11))
        };
        drop(v783_10);
        let v783_13: Space = unite(&(v783_8),&(v783_12));
        v782_11.join_into((v783_13).clone());
      }
      drop(v782_11_cursor);
      drop(v782_6);
      compose(&(v777_10),&(v782_11))
    };
    drop(v777_10);
    let v777_13: Space = unite(&(v777_8),&(v777_12));
    v776_13.join_into((v777_13).clone());
  }
  drop(v776_13_cursor);
  (v776_13).clone()
}

fn routine_86(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v786_8: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v786_10: Space = unwrap(&(v786_8),&(*CONSTANT_10));
  drop(v786_8);
  let v786_11: Space = unwrap(&(v786_10),&(*p0));
  drop(v786_10);
  let mut v786_18 = Space::new();
  let mut v786_18_cursor = (*s0).read_zipper();
  for v786_18_byte in v786_18_cursor.child_mask().iter() {
    v786_18_cursor.descend_to_byte(v786_18_byte);
    let v786_18_tail = v786_18_cursor.make_map();
    v786_18_cursor.ascend(1);
    let v786_18_head = Path::from_slice(&[v786_18_byte]);
    let v787_2: Space = singleton(&(v786_18_head));
    let v787_3: Space = intersect(&(*CONSTANT_14),&(v787_2));
    let v787_4: Space = if has_head(&(v787_3)) { singleton(&[]) } else { Space::new() };
    drop(v787_3);
    let v787_5: Space = subtract(&(*CONSTANT_0),&(v787_4));
    drop(v787_4);
    let v787_8: Space = if (v787_5).is_empty() { Space::new() } else {
      let v788_6: Path = concat_path(&(*p0),&(v786_18_head));
      let mut v788_7 = Space::new();
      let mut v788_7_cursor = (v786_18_tail).read_zipper();
      for v788_7_byte in v788_7_cursor.child_mask().iter() {
        v788_7_cursor.descend_to_byte(v788_7_byte);
        let v788_7_tail = v788_7_cursor.make_map();
        v788_7_cursor.ascend(1);
        let v788_7_head = Path::from_slice(&[v788_7_byte]);
        let v789_2: Space = singleton(&(v788_7_head));
        let v789_3: Space = intersect(&(*CONSTANT_14),&(v789_2));
        let v789_4: Space = if has_head(&(v789_3)) { singleton(&[]) } else { Space::new() };
        drop(v789_3);
        let v789_5: Space = subtract(&(*CONSTANT_0),&(v789_4));
        drop(v789_4);
        let v789_8: Space = if (v789_5).is_empty() { Space::new() } else {
          let v790_6: Path = concat_path(&(v788_6),&(v788_7_head));
          let v790_7: Space = routine_118(c, &(v790_6), &(*p1), &(v788_7_tail), &(*s1));
          compose(&(v789_5),&(v790_7))
        };
        drop(v789_5);
        let v789_9: Space = intersect(&(*CONSTANT_14),&(v789_2));
        drop(v789_2);
        let v789_10: Space = if has_head(&(v789_9)) { singleton(&[]) } else { Space::new() };
        drop(v789_9);
        let v789_12: Space = if (v789_10).is_empty() { Space::new() } else {
          let v791_6: Path = concat_path(&(v788_6),&(v788_7_head));
          let v791_11: Space = routine_119(c, &(v791_6), &(*p1), &(v788_7_tail), &(*s1));
          drop(v791_6);
          compose(&(v789_10),&(v791_11))
        };
        drop(v789_10);
        let v789_13: Space = unite(&(v789_8),&(v789_12));
        v788_7.join_into((v789_13).clone());
      }
      drop(v788_7_cursor);
      drop(v788_6);
      compose(&(v787_5),&(v788_7))
    };
    drop(v787_5);
    let v787_9: Space = intersect(&(*CONSTANT_14),&(v787_2));
    drop(v787_2);
    let v787_10: Space = if has_head(&(v787_9)) { singleton(&[]) } else { Space::new() };
    drop(v787_9);
    let v787_13: Space = if (v787_10).is_empty() { Space::new() } else {
      let v792_11: Space = unwrap(&(v786_11),&(v786_18_head));
      let mut v792_12 = Space::new();
      let mut v792_12_cursor = (v792_11).read_zipper();
      for v792_12_byte in v792_12_cursor.child_mask().iter() {
        v792_12_cursor.descend_to_byte(v792_12_byte);
        let v792_12_tail = v792_12_cursor.make_map();
        v792_12_cursor.ascend(1);
        let v792_12_head = Path::from_slice(&[v792_12_byte]);
        let v793_2: Space = singleton(&(v792_12_head));
        let v793_3: Space = intersect(&(*CONSTANT_14),&(v793_2));
        let v793_4: Space = if has_head(&(v793_3)) { singleton(&[]) } else { Space::new() };
        drop(v793_3);
        let v793_5: Space = subtract(&(*CONSTANT_0),&(v793_4));
        drop(v793_4);
        let v793_7: Space = if (v793_5).is_empty() { Space::new() } else {
          let v794_6: Space = routine_87(c, &(v792_12_head), &(*p1), &(v792_12_tail));
          compose(&(v793_5),&(v794_6))
        };
        drop(v793_5);
        let v793_8: Space = intersect(&(*CONSTANT_14),&(v793_2));
        drop(v793_2);
        let v793_9: Space = if has_head(&(v793_8)) { singleton(&[]) } else { Space::new() };
        drop(v793_8);
        let v793_11: Space = if (v793_9).is_empty() { Space::new() } else {
          let v795_10: Space = routine_88(c, &(v792_12_head), &(*p1), &(v792_12_tail));
          compose(&(v793_9),&(v795_10))
        };
        drop(v793_9);
        let v793_12: Space = unite(&(v793_7),&(v793_11));
        v792_12.join_into((v793_12).clone());
      }
      drop(v792_12_cursor);
      drop(v792_11);
      compose(&(v787_10),&(v792_12))
    };
    drop(v787_10);
    let v787_14: Space = unite(&(v787_8),&(v787_13));
    v786_18.join_into((v787_14).clone());
  }
  drop(v786_18_cursor);
  drop(v786_11);
  (v786_18).clone()
}

fn routine_87(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v796_12 = Space::new();
  let mut v796_12_cursor = (*s0).read_zipper();
  for v796_12_byte in v796_12_cursor.child_mask().iter() {
    v796_12_cursor.descend_to_byte(v796_12_byte);
    let v796_12_tail = v796_12_cursor.make_map();
    v796_12_cursor.ascend(1);
    let v796_12_head = Path::from_slice(&[v796_12_byte]);
    let v797_2: Space = singleton(&(v796_12_head));
    let v797_3: Space = intersect(&(*CONSTANT_14),&(v797_2));
    let v797_4: Space = if has_head(&(v797_3)) { singleton(&[]) } else { Space::new() };
    drop(v797_3);
    let v797_5: Space = subtract(&(*CONSTANT_0),&(v797_4));
    drop(v797_4);
    let v797_8: Space = if (v797_5).is_empty() { Space::new() } else {
      let v798_6: Path = concat_path(&(*p0),&(v796_12_head));
      let mut v798_7 = Space::new();
      let mut v798_7_cursor = (v796_12_tail).read_zipper();
      for v798_7_byte in v798_7_cursor.child_mask().iter() {
        v798_7_cursor.descend_to_byte(v798_7_byte);
        let v798_7_tail = v798_7_cursor.make_map();
        v798_7_cursor.ascend(1);
        let v798_7_head = Path::from_slice(&[v798_7_byte]);
        let v799_2: Space = singleton(&(v798_7_head));
        let v799_3: Space = intersect(&(*CONSTANT_14),&(v799_2));
        let v799_4: Space = if has_head(&(v799_3)) { singleton(&[]) } else { Space::new() };
        drop(v799_3);
        let v799_5: Space = subtract(&(*CONSTANT_0),&(v799_4));
        drop(v799_4);
        let v799_8: Space = if (v799_5).is_empty() { Space::new() } else {
          let v800_6: Path = concat_path(&(v798_6),&(v798_7_head));
          let v800_7: Space = routine_120(c, &(v800_6), &(*p1), &(v798_7_tail));
          compose(&(v799_5),&(v800_7))
        };
        drop(v799_5);
        let v799_9: Space = intersect(&(*CONSTANT_14),&(v799_2));
        drop(v799_2);
        let v799_10: Space = if has_head(&(v799_9)) { singleton(&[]) } else { Space::new() };
        drop(v799_9);
        let v799_12: Space = if (v799_10).is_empty() { Space::new() } else {
          let v801_6: Path = concat_path(&(v798_6),&(v798_7_head));
          let v801_11: Space = routine_121(c, &(v801_6), &(*p1), &(v798_7_tail));
          drop(v801_6);
          compose(&(v799_10),&(v801_11))
        };
        drop(v799_10);
        let v799_13: Space = unite(&(v799_8),&(v799_12));
        v798_7.join_into((v799_13).clone());
      }
      drop(v798_7_cursor);
      compose(&(v797_5),&(v798_7))
    };
    drop(v797_5);
    let v797_9: Space = intersect(&(*CONSTANT_14),&(v797_2));
    drop(v797_2);
    let v797_10: Space = if has_head(&(v797_9)) { singleton(&[]) } else { Space::new() };
    drop(v797_9);
    let v797_12: Space = if (v797_10).is_empty() { Space::new() } else {
      let v802_6: Path = concat_path(&(*p0),&(v796_12_head));
      let mut v802_11 = Space::new();
      let mut v802_11_cursor = (v796_12_tail).read_zipper();
      for v802_11_byte in v802_11_cursor.child_mask().iter() {
        v802_11_cursor.descend_to_byte(v802_11_byte);
        let v802_11_tail = v802_11_cursor.make_map();
        v802_11_cursor.ascend(1);
        let v802_11_head = Path::from_slice(&[v802_11_byte]);
        let v803_2: Space = singleton(&(v802_11_head));
        let v803_3: Space = intersect(&(*CONSTANT_14),&(v803_2));
        let v803_4: Space = if has_head(&(v803_3)) { singleton(&[]) } else { Space::new() };
        drop(v803_3);
        let v803_5: Space = subtract(&(*CONSTANT_0),&(v803_4));
        drop(v803_4);
        let v803_8: Space = if (v803_5).is_empty() { Space::new() } else {
          let v804_6: Path = concat_path(&(v802_6),&(v802_11_head));
          let v804_7: Space = routine_120(c, &(v804_6), &(*p1), &(v802_11_tail));
          compose(&(v803_5),&(v804_7))
        };
        drop(v803_5);
        let v803_9: Space = intersect(&(*CONSTANT_14),&(v803_2));
        drop(v803_2);
        let v803_10: Space = if has_head(&(v803_9)) { singleton(&[]) } else { Space::new() };
        drop(v803_9);
        let v803_12: Space = if (v803_10).is_empty() { Space::new() } else {
          let v805_6: Path = concat_path(&(v802_6),&(v802_11_head));
          let v805_11: Space = routine_93(c, &(v805_6), &(*p1), &(v802_11_tail));
          drop(v805_6);
          compose(&(v803_10),&(v805_11))
        };
        drop(v803_10);
        let v803_13: Space = unite(&(v803_8),&(v803_12));
        v802_11.join_into((v803_13).clone());
      }
      drop(v802_11_cursor);
      drop(v802_6);
      compose(&(v797_10),&(v802_11))
    };
    drop(v797_10);
    let v797_13: Space = unite(&(v797_8),&(v797_12));
    v796_12.join_into((v797_13).clone());
  }
  drop(v796_12_cursor);
  (v796_12).clone()
}

fn routine_88(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v806_9 = Space::new();
  let mut v806_9_cursor = (*s0).read_zipper();
  for v806_9_byte in v806_9_cursor.child_mask().iter() {
    v806_9_cursor.descend_to_byte(v806_9_byte);
    let v806_9_tail = v806_9_cursor.make_map();
    v806_9_cursor.ascend(1);
    let v806_9_head = Path::from_slice(&[v806_9_byte]);
    let v807_2: Space = singleton(&(v806_9_head));
    let v807_3: Space = intersect(&(*CONSTANT_14),&(v807_2));
    let v807_4: Space = if has_head(&(v807_3)) { singleton(&[]) } else { Space::new() };
    drop(v807_3);
    let v807_5: Space = subtract(&(*CONSTANT_0),&(v807_4));
    drop(v807_4);
    let v807_8: Space = if (v807_5).is_empty() { Space::new() } else {
      let v808_6: Path = concat_path(&(*p0),&(v806_9_head));
      let mut v808_7 = Space::new();
      let mut v808_7_cursor = (v806_9_tail).read_zipper();
      for v808_7_byte in v808_7_cursor.child_mask().iter() {
        v808_7_cursor.descend_to_byte(v808_7_byte);
        let v808_7_tail = v808_7_cursor.make_map();
        v808_7_cursor.ascend(1);
        let v808_7_head = Path::from_slice(&[v808_7_byte]);
        let v809_2: Space = singleton(&(v808_7_head));
        let v809_3: Space = intersect(&(*CONSTANT_14),&(v809_2));
        let v809_4: Space = if has_head(&(v809_3)) { singleton(&[]) } else { Space::new() };
        drop(v809_3);
        let v809_5: Space = subtract(&(*CONSTANT_0),&(v809_4));
        drop(v809_4);
        let v809_8: Space = if (v809_5).is_empty() { Space::new() } else {
          let v810_6: Path = concat_path(&(v808_6),&(v808_7_head));
          let v810_7: Space = routine_120(c, &(v810_6), &(*p1), &(v808_7_tail));
          compose(&(v809_5),&(v810_7))
        };
        drop(v809_5);
        let v809_9: Space = intersect(&(*CONSTANT_14),&(v809_2));
        drop(v809_2);
        let v809_10: Space = if has_head(&(v809_9)) { singleton(&[]) } else { Space::new() };
        drop(v809_9);
        let v809_12: Space = if (v809_10).is_empty() { Space::new() } else {
          let v811_6: Path = concat_path(&(v808_6),&(v808_7_head));
          let v811_11: Space = routine_121(c, &(v811_6), &(*p1), &(v808_7_tail));
          drop(v811_6);
          compose(&(v809_10),&(v811_11))
        };
        drop(v809_10);
        let v809_13: Space = unite(&(v809_8),&(v809_12));
        v808_7.join_into((v809_13).clone());
      }
      drop(v808_7_cursor);
      compose(&(v807_5),&(v808_7))
    };
    drop(v807_5);
    let v807_9: Space = intersect(&(*CONSTANT_14),&(v807_2));
    drop(v807_2);
    let v807_10: Space = if has_head(&(v807_9)) { singleton(&[]) } else { Space::new() };
    drop(v807_9);
    let v807_11: Space = compose(&(v807_10),&(v806_9_tail));
    drop(v807_10);
    let v812_6: Path = concat_path(&(*p0),&(v806_9_head));
    let v807_12: Space = wrap(&(v807_11),&(v812_6));
    drop(v807_11);
    let v807_13: Space = wrap(&(v807_12),&(*p1));
    drop(v807_12);
    let v807_14: Space = unite(&(v807_8),&(v807_13));
    drop(v807_13);
    v806_9.join_into((v807_14).clone());
  }
  drop(v806_9_cursor);
  (v806_9).clone()
}

fn routine_89(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v813_13 = Space::new();
  let mut v813_13_cursor = (*s0).read_zipper();
  for v813_13_byte in v813_13_cursor.child_mask().iter() {
    v813_13_cursor.descend_to_byte(v813_13_byte);
    let v813_13_tail = v813_13_cursor.make_map();
    v813_13_cursor.ascend(1);
    let v813_13_head = Path::from_slice(&[v813_13_byte]);
    let v814_2: Space = singleton(&(v813_13_head));
    let v814_3: Space = intersect(&(*CONSTANT_14),&(v814_2));
    let v814_4: Space = if has_head(&(v814_3)) { singleton(&[]) } else { Space::new() };
    drop(v814_3);
    let v814_5: Space = subtract(&(*CONSTANT_0),&(v814_4));
    drop(v814_4);
    let v814_8: Space = if (v814_5).is_empty() { Space::new() } else {
      let v815_6: Path = concat_path(&(*p0),&(v813_13_head));
      let mut v815_7 = Space::new();
      let mut v815_7_cursor = (v813_13_tail).read_zipper();
      for v815_7_byte in v815_7_cursor.child_mask().iter() {
        v815_7_cursor.descend_to_byte(v815_7_byte);
        let v815_7_tail = v815_7_cursor.make_map();
        v815_7_cursor.ascend(1);
        let v815_7_head = Path::from_slice(&[v815_7_byte]);
        let v816_2: Space = singleton(&(v815_7_head));
        let v816_3: Space = intersect(&(*CONSTANT_14),&(v816_2));
        let v816_4: Space = if has_head(&(v816_3)) { singleton(&[]) } else { Space::new() };
        drop(v816_3);
        let v816_5: Space = subtract(&(*CONSTANT_0),&(v816_4));
        drop(v816_4);
        let v816_8: Space = if (v816_5).is_empty() { Space::new() } else {
          let v817_6: Path = concat_path(&(v815_6),&(v815_7_head));
          let v817_7: Space = routine_122(c, &(v817_6), &(*p1), &(v815_7_tail), &(*s1));
          compose(&(v816_5),&(v817_7))
        };
        drop(v816_5);
        let v816_9: Space = intersect(&(*CONSTANT_14),&(v816_2));
        drop(v816_2);
        let v816_10: Space = if has_head(&(v816_9)) { singleton(&[]) } else { Space::new() };
        drop(v816_9);
        let v816_12: Space = if (v816_10).is_empty() { Space::new() } else {
          let v818_6: Path = concat_path(&(v815_6),&(v815_7_head));
          let v818_11: Space = routine_123(c, &(v818_6), &(*p1), &(v815_7_tail), &(*s1));
          drop(v818_6);
          compose(&(v816_10),&(v818_11))
        };
        drop(v816_10);
        let v816_13: Space = unite(&(v816_8),&(v816_12));
        v815_7.join_into((v816_13).clone());
      }
      drop(v815_7_cursor);
      compose(&(v814_5),&(v815_7))
    };
    drop(v814_5);
    let v814_9: Space = intersect(&(*CONSTANT_14),&(v814_2));
    drop(v814_2);
    let v814_10: Space = if has_head(&(v814_9)) { singleton(&[]) } else { Space::new() };
    drop(v814_9);
    let v814_12: Space = if (v814_10).is_empty() { Space::new() } else {
      let v819_6: Path = concat_path(&(*p0),&(v813_13_head));
      let mut v819_11 = Space::new();
      let mut v819_11_cursor = (v813_13_tail).read_zipper();
      for v819_11_byte in v819_11_cursor.child_mask().iter() {
        v819_11_cursor.descend_to_byte(v819_11_byte);
        let v819_11_tail = v819_11_cursor.make_map();
        v819_11_cursor.ascend(1);
        let v819_11_head = Path::from_slice(&[v819_11_byte]);
        let v820_2: Space = singleton(&(v819_11_head));
        let v820_3: Space = intersect(&(*CONSTANT_14),&(v820_2));
        let v820_4: Space = if has_head(&(v820_3)) { singleton(&[]) } else { Space::new() };
        drop(v820_3);
        let v820_5: Space = subtract(&(*CONSTANT_0),&(v820_4));
        drop(v820_4);
        let v820_8: Space = if (v820_5).is_empty() { Space::new() } else {
          let v821_6: Path = concat_path(&(v819_6),&(v819_11_head));
          let v821_7: Space = routine_122(c, &(v821_6), &(*p1), &(v819_11_tail), &(*s1));
          compose(&(v820_5),&(v821_7))
        };
        drop(v820_5);
        let v820_9: Space = intersect(&(*CONSTANT_14),&(v820_2));
        drop(v820_2);
        let v820_10: Space = if has_head(&(v820_9)) { singleton(&[]) } else { Space::new() };
        drop(v820_9);
        let v820_12: Space = if (v820_10).is_empty() { Space::new() } else {
          let v822_6: Path = concat_path(&(v819_6),&(v819_11_head));
          let v822_11: Space = routine_47(c, &(v822_6), &(*p1), &(v819_11_tail), &(*s1));
          drop(v822_6);
          compose(&(v820_10),&(v822_11))
        };
        drop(v820_10);
        let v820_13: Space = unite(&(v820_8),&(v820_12));
        v819_11.join_into((v820_13).clone());
      }
      drop(v819_11_cursor);
      drop(v819_6);
      compose(&(v814_10),&(v819_11))
    };
    drop(v814_10);
    let v814_13: Space = unite(&(v814_8),&(v814_12));
    v813_13.join_into((v814_13).clone());
  }
  drop(v813_13_cursor);
  (v813_13).clone()
}

fn routine_90(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v823_8: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v823_10: Space = unwrap(&(v823_8),&(*CONSTANT_10));
  drop(v823_8);
  let v823_11: Space = unwrap(&(v823_10),&(*p0));
  drop(v823_10);
  let mut v823_18 = Space::new();
  let mut v823_18_cursor = (*s0).read_zipper();
  for v823_18_byte in v823_18_cursor.child_mask().iter() {
    v823_18_cursor.descend_to_byte(v823_18_byte);
    let v823_18_tail = v823_18_cursor.make_map();
    v823_18_cursor.ascend(1);
    let v823_18_head = Path::from_slice(&[v823_18_byte]);
    let v824_2: Space = singleton(&(v823_18_head));
    let v824_3: Space = intersect(&(*CONSTANT_14),&(v824_2));
    let v824_4: Space = if has_head(&(v824_3)) { singleton(&[]) } else { Space::new() };
    drop(v824_3);
    let v824_5: Space = subtract(&(*CONSTANT_0),&(v824_4));
    drop(v824_4);
    let v824_8: Space = if (v824_5).is_empty() { Space::new() } else {
      let v825_6: Path = concat_path(&(*p0),&(v823_18_head));
      let mut v825_7 = Space::new();
      let mut v825_7_cursor = (v823_18_tail).read_zipper();
      for v825_7_byte in v825_7_cursor.child_mask().iter() {
        v825_7_cursor.descend_to_byte(v825_7_byte);
        let v825_7_tail = v825_7_cursor.make_map();
        v825_7_cursor.ascend(1);
        let v825_7_head = Path::from_slice(&[v825_7_byte]);
        let v826_2: Space = singleton(&(v825_7_head));
        let v826_3: Space = intersect(&(*CONSTANT_14),&(v826_2));
        let v826_4: Space = if has_head(&(v826_3)) { singleton(&[]) } else { Space::new() };
        drop(v826_3);
        let v826_5: Space = subtract(&(*CONSTANT_0),&(v826_4));
        drop(v826_4);
        let v826_8: Space = if (v826_5).is_empty() { Space::new() } else {
          let v827_6: Path = concat_path(&(v825_6),&(v825_7_head));
          let v827_7: Space = routine_122(c, &(v827_6), &(*p1), &(v825_7_tail), &(*s1));
          compose(&(v826_5),&(v827_7))
        };
        drop(v826_5);
        let v826_9: Space = intersect(&(*CONSTANT_14),&(v826_2));
        drop(v826_2);
        let v826_10: Space = if has_head(&(v826_9)) { singleton(&[]) } else { Space::new() };
        drop(v826_9);
        let v826_12: Space = if (v826_10).is_empty() { Space::new() } else {
          let v828_6: Path = concat_path(&(v825_6),&(v825_7_head));
          let v828_11: Space = routine_123(c, &(v828_6), &(*p1), &(v825_7_tail), &(*s1));
          drop(v828_6);
          compose(&(v826_10),&(v828_11))
        };
        drop(v826_10);
        let v826_13: Space = unite(&(v826_8),&(v826_12));
        v825_7.join_into((v826_13).clone());
      }
      drop(v825_7_cursor);
      drop(v825_6);
      compose(&(v824_5),&(v825_7))
    };
    drop(v824_5);
    let v824_9: Space = intersect(&(*CONSTANT_14),&(v824_2));
    drop(v824_2);
    let v824_10: Space = if has_head(&(v824_9)) { singleton(&[]) } else { Space::new() };
    drop(v824_9);
    let v824_13: Space = if (v824_10).is_empty() { Space::new() } else {
      let v829_11: Space = unwrap(&(v823_11),&(v823_18_head));
      let mut v829_12 = Space::new();
      let mut v829_12_cursor = (v829_11).read_zipper();
      for v829_12_byte in v829_12_cursor.child_mask().iter() {
        v829_12_cursor.descend_to_byte(v829_12_byte);
        let v829_12_tail = v829_12_cursor.make_map();
        v829_12_cursor.ascend(1);
        let v829_12_head = Path::from_slice(&[v829_12_byte]);
        let v830_2: Space = singleton(&(v829_12_head));
        let v830_3: Space = intersect(&(*CONSTANT_14),&(v830_2));
        let v830_4: Space = if has_head(&(v830_3)) { singleton(&[]) } else { Space::new() };
        drop(v830_3);
        let v830_5: Space = subtract(&(*CONSTANT_0),&(v830_4));
        drop(v830_4);
        let v830_7: Space = if (v830_5).is_empty() { Space::new() } else {
          let v831_6: Space = routine_87(c, &(v829_12_head), &(*p1), &(v829_12_tail));
          compose(&(v830_5),&(v831_6))
        };
        drop(v830_5);
        let v830_8: Space = intersect(&(*CONSTANT_14),&(v830_2));
        drop(v830_2);
        let v830_9: Space = if has_head(&(v830_8)) { singleton(&[]) } else { Space::new() };
        drop(v830_8);
        let v830_11: Space = if (v830_9).is_empty() { Space::new() } else {
          let v832_10: Space = routine_88(c, &(v829_12_head), &(*p1), &(v829_12_tail));
          compose(&(v830_9),&(v832_10))
        };
        drop(v830_9);
        let v830_12: Space = unite(&(v830_7),&(v830_11));
        v829_12.join_into((v830_12).clone());
      }
      drop(v829_12_cursor);
      drop(v829_11);
      compose(&(v824_10),&(v829_12))
    };
    drop(v824_10);
    let v824_14: Space = unite(&(v824_8),&(v824_13));
    v823_18.join_into((v824_14).clone());
  }
  drop(v823_18_cursor);
  drop(v823_11);
  (v823_18).clone()
}

fn routine_91(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v833_12 = Space::new();
  let mut v833_12_cursor = (*s0).read_zipper();
  for v833_12_byte in v833_12_cursor.child_mask().iter() {
    v833_12_cursor.descend_to_byte(v833_12_byte);
    let v833_12_tail = v833_12_cursor.make_map();
    v833_12_cursor.ascend(1);
    let v833_12_head = Path::from_slice(&[v833_12_byte]);
    let v834_2: Space = singleton(&(v833_12_head));
    let v834_3: Space = intersect(&(*CONSTANT_14),&(v834_2));
    let v834_4: Space = if has_head(&(v834_3)) { singleton(&[]) } else { Space::new() };
    drop(v834_3);
    let v834_5: Space = subtract(&(*CONSTANT_0),&(v834_4));
    drop(v834_4);
    let v834_8: Space = if (v834_5).is_empty() { Space::new() } else {
      let v835_6: Path = concat_path(&(*p0),&(v833_12_head));
      let mut v835_7 = Space::new();
      let mut v835_7_cursor = (v833_12_tail).read_zipper();
      for v835_7_byte in v835_7_cursor.child_mask().iter() {
        v835_7_cursor.descend_to_byte(v835_7_byte);
        let v835_7_tail = v835_7_cursor.make_map();
        v835_7_cursor.ascend(1);
        let v835_7_head = Path::from_slice(&[v835_7_byte]);
        let v836_2: Space = singleton(&(v835_7_head));
        let v836_3: Space = intersect(&(*CONSTANT_14),&(v836_2));
        let v836_4: Space = if has_head(&(v836_3)) { singleton(&[]) } else { Space::new() };
        drop(v836_3);
        let v836_5: Space = subtract(&(*CONSTANT_0),&(v836_4));
        drop(v836_4);
        let v836_8: Space = if (v836_5).is_empty() { Space::new() } else {
          let v837_6: Path = concat_path(&(v835_6),&(v835_7_head));
          let v837_7: Space = routine_124(c, &(v837_6), &(*p1), &(v835_7_tail));
          compose(&(v836_5),&(v837_7))
        };
        drop(v836_5);
        let v836_9: Space = intersect(&(*CONSTANT_14),&(v836_2));
        drop(v836_2);
        let v836_10: Space = if has_head(&(v836_9)) { singleton(&[]) } else { Space::new() };
        drop(v836_9);
        let v836_12: Space = if (v836_10).is_empty() { Space::new() } else {
          let v838_6: Path = concat_path(&(v835_6),&(v835_7_head));
          let v838_11: Space = routine_125(c, &(v838_6), &(*p1), &(v835_7_tail));
          drop(v838_6);
          compose(&(v836_10),&(v838_11))
        };
        drop(v836_10);
        let v836_13: Space = unite(&(v836_8),&(v836_12));
        v835_7.join_into((v836_13).clone());
      }
      drop(v835_7_cursor);
      compose(&(v834_5),&(v835_7))
    };
    drop(v834_5);
    let v834_9: Space = intersect(&(*CONSTANT_14),&(v834_2));
    drop(v834_2);
    let v834_10: Space = if has_head(&(v834_9)) { singleton(&[]) } else { Space::new() };
    drop(v834_9);
    let v834_12: Space = if (v834_10).is_empty() { Space::new() } else {
      let v839_6: Path = concat_path(&(*p0),&(v833_12_head));
      let mut v839_11 = Space::new();
      let mut v839_11_cursor = (v833_12_tail).read_zipper();
      for v839_11_byte in v839_11_cursor.child_mask().iter() {
        v839_11_cursor.descend_to_byte(v839_11_byte);
        let v839_11_tail = v839_11_cursor.make_map();
        v839_11_cursor.ascend(1);
        let v839_11_head = Path::from_slice(&[v839_11_byte]);
        let v840_2: Space = singleton(&(v839_11_head));
        let v840_3: Space = intersect(&(*CONSTANT_14),&(v840_2));
        let v840_4: Space = if has_head(&(v840_3)) { singleton(&[]) } else { Space::new() };
        drop(v840_3);
        let v840_5: Space = subtract(&(*CONSTANT_0),&(v840_4));
        drop(v840_4);
        let v840_8: Space = if (v840_5).is_empty() { Space::new() } else {
          let v841_6: Path = concat_path(&(v839_6),&(v839_11_head));
          let v841_7: Space = routine_124(c, &(v841_6), &(*p1), &(v839_11_tail));
          compose(&(v840_5),&(v841_7))
        };
        drop(v840_5);
        let v840_9: Space = intersect(&(*CONSTANT_14),&(v840_2));
        drop(v840_2);
        let v840_10: Space = if has_head(&(v840_9)) { singleton(&[]) } else { Space::new() };
        drop(v840_9);
        let v840_12: Space = if (v840_10).is_empty() { Space::new() } else {
          let v842_6: Path = concat_path(&(v839_6),&(v839_11_head));
          let v842_11: Space = routine_93(c, &(v842_6), &(*p1), &(v839_11_tail));
          drop(v842_6);
          compose(&(v840_10),&(v842_11))
        };
        drop(v840_10);
        let v840_13: Space = unite(&(v840_8),&(v840_12));
        v839_11.join_into((v840_13).clone());
      }
      drop(v839_11_cursor);
      drop(v839_6);
      compose(&(v834_10),&(v839_11))
    };
    drop(v834_10);
    let v834_13: Space = unite(&(v834_8),&(v834_12));
    v833_12.join_into((v834_13).clone());
  }
  drop(v833_12_cursor);
  (v833_12).clone()
}

fn routine_92(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v843_9 = Space::new();
  let mut v843_9_cursor = (*s0).read_zipper();
  for v843_9_byte in v843_9_cursor.child_mask().iter() {
    v843_9_cursor.descend_to_byte(v843_9_byte);
    let v843_9_tail = v843_9_cursor.make_map();
    v843_9_cursor.ascend(1);
    let v843_9_head = Path::from_slice(&[v843_9_byte]);
    let v844_2: Space = singleton(&(v843_9_head));
    let v844_3: Space = intersect(&(*CONSTANT_14),&(v844_2));
    let v844_4: Space = if has_head(&(v844_3)) { singleton(&[]) } else { Space::new() };
    drop(v844_3);
    let v844_5: Space = subtract(&(*CONSTANT_0),&(v844_4));
    drop(v844_4);
    let v844_8: Space = if (v844_5).is_empty() { Space::new() } else {
      let v845_6: Path = concat_path(&(*p0),&(v843_9_head));
      let mut v845_7 = Space::new();
      let mut v845_7_cursor = (v843_9_tail).read_zipper();
      for v845_7_byte in v845_7_cursor.child_mask().iter() {
        v845_7_cursor.descend_to_byte(v845_7_byte);
        let v845_7_tail = v845_7_cursor.make_map();
        v845_7_cursor.ascend(1);
        let v845_7_head = Path::from_slice(&[v845_7_byte]);
        let v846_2: Space = singleton(&(v845_7_head));
        let v846_3: Space = intersect(&(*CONSTANT_14),&(v846_2));
        let v846_4: Space = if has_head(&(v846_3)) { singleton(&[]) } else { Space::new() };
        drop(v846_3);
        let v846_5: Space = subtract(&(*CONSTANT_0),&(v846_4));
        drop(v846_4);
        let v846_8: Space = if (v846_5).is_empty() { Space::new() } else {
          let v847_6: Path = concat_path(&(v845_6),&(v845_7_head));
          let v847_7: Space = routine_124(c, &(v847_6), &(*p1), &(v845_7_tail));
          compose(&(v846_5),&(v847_7))
        };
        drop(v846_5);
        let v846_9: Space = intersect(&(*CONSTANT_14),&(v846_2));
        drop(v846_2);
        let v846_10: Space = if has_head(&(v846_9)) { singleton(&[]) } else { Space::new() };
        drop(v846_9);
        let v846_12: Space = if (v846_10).is_empty() { Space::new() } else {
          let v848_6: Path = concat_path(&(v845_6),&(v845_7_head));
          let v848_11: Space = routine_125(c, &(v848_6), &(*p1), &(v845_7_tail));
          drop(v848_6);
          compose(&(v846_10),&(v848_11))
        };
        drop(v846_10);
        let v846_13: Space = unite(&(v846_8),&(v846_12));
        v845_7.join_into((v846_13).clone());
      }
      drop(v845_7_cursor);
      compose(&(v844_5),&(v845_7))
    };
    drop(v844_5);
    let v844_9: Space = intersect(&(*CONSTANT_14),&(v844_2));
    drop(v844_2);
    let v844_10: Space = if has_head(&(v844_9)) { singleton(&[]) } else { Space::new() };
    drop(v844_9);
    let v844_11: Space = compose(&(v844_10),&(v843_9_tail));
    drop(v844_10);
    let v849_6: Path = concat_path(&(*p0),&(v843_9_head));
    let v844_12: Space = wrap(&(v844_11),&(v849_6));
    drop(v844_11);
    let v844_13: Space = wrap(&(v844_12),&(*p1));
    drop(v844_12);
    let v844_14: Space = unite(&(v844_8),&(v844_13));
    drop(v844_13);
    v843_9.join_into((v844_14).clone());
  }
  drop(v843_9_cursor);
  (v843_9).clone()
}

fn routine_93(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v850_3: Space = wrap(&(*s0),&(*p0));
  let v850_4: Space = wrap(&(v850_3),&(*p1));
  drop(v850_3);
  (v850_4).clone()
}

fn routine_94(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v851_12 = Space::new();
  let mut v851_12_cursor = (*s0).read_zipper();
  for v851_12_byte in v851_12_cursor.child_mask().iter() {
    v851_12_cursor.descend_to_byte(v851_12_byte);
    let v851_12_tail = v851_12_cursor.make_map();
    v851_12_cursor.ascend(1);
    let v851_12_head = Path::from_slice(&[v851_12_byte]);
    let v852_2: Space = singleton(&(v851_12_head));
    let v852_3: Space = intersect(&(*CONSTANT_14),&(v852_2));
    let v852_4: Space = if has_head(&(v852_3)) { singleton(&[]) } else { Space::new() };
    drop(v852_3);
    let v852_5: Space = subtract(&(*CONSTANT_0),&(v852_4));
    drop(v852_4);
    let v852_8: Space = if (v852_5).is_empty() { Space::new() } else {
      let v853_6: Path = concat_path(&(*p0),&(v851_12_head));
      let mut v853_7 = Space::new();
      let mut v853_7_cursor = (v851_12_tail).read_zipper();
      for v853_7_byte in v853_7_cursor.child_mask().iter() {
        v853_7_cursor.descend_to_byte(v853_7_byte);
        let v853_7_tail = v853_7_cursor.make_map();
        v853_7_cursor.ascend(1);
        let v853_7_head = Path::from_slice(&[v853_7_byte]);
        let v854_2: Space = singleton(&(v853_7_head));
        let v854_3: Space = intersect(&(*CONSTANT_14),&(v854_2));
        let v854_4: Space = if has_head(&(v854_3)) { singleton(&[]) } else { Space::new() };
        drop(v854_3);
        let v854_5: Space = subtract(&(*CONSTANT_0),&(v854_4));
        drop(v854_4);
        let v854_8: Space = if (v854_5).is_empty() { Space::new() } else {
          let v855_6: Path = concat_path(&(v853_6),&(v853_7_head));
          let v855_7: Space = routine_126(c, &(v855_6), &(*p1), &(v853_7_tail));
          compose(&(v854_5),&(v855_7))
        };
        drop(v854_5);
        let v854_9: Space = intersect(&(*CONSTANT_14),&(v854_2));
        drop(v854_2);
        let v854_10: Space = if has_head(&(v854_9)) { singleton(&[]) } else { Space::new() };
        drop(v854_9);
        let v854_12: Space = if (v854_10).is_empty() { Space::new() } else {
          let v856_6: Path = concat_path(&(v853_6),&(v853_7_head));
          let v856_11: Space = routine_127(c, &(v856_6), &(*p1), &(v853_7_tail));
          drop(v856_6);
          compose(&(v854_10),&(v856_11))
        };
        drop(v854_10);
        let v854_13: Space = unite(&(v854_8),&(v854_12));
        v853_7.join_into((v854_13).clone());
      }
      drop(v853_7_cursor);
      compose(&(v852_5),&(v853_7))
    };
    drop(v852_5);
    let v852_9: Space = intersect(&(*CONSTANT_14),&(v852_2));
    drop(v852_2);
    let v852_10: Space = if has_head(&(v852_9)) { singleton(&[]) } else { Space::new() };
    drop(v852_9);
    let v852_12: Space = if (v852_10).is_empty() { Space::new() } else {
      let v857_6: Path = concat_path(&(*p0),&(v851_12_head));
      let mut v857_11 = Space::new();
      let mut v857_11_cursor = (v851_12_tail).read_zipper();
      for v857_11_byte in v857_11_cursor.child_mask().iter() {
        v857_11_cursor.descend_to_byte(v857_11_byte);
        let v857_11_tail = v857_11_cursor.make_map();
        v857_11_cursor.ascend(1);
        let v857_11_head = Path::from_slice(&[v857_11_byte]);
        let v858_2: Space = singleton(&(v857_11_head));
        let v858_3: Space = intersect(&(*CONSTANT_14),&(v858_2));
        let v858_4: Space = if has_head(&(v858_3)) { singleton(&[]) } else { Space::new() };
        drop(v858_3);
        let v858_5: Space = subtract(&(*CONSTANT_0),&(v858_4));
        drop(v858_4);
        let v858_8: Space = if (v858_5).is_empty() { Space::new() } else {
          let v859_6: Path = concat_path(&(v857_6),&(v857_11_head));
          let v859_7: Space = routine_126(c, &(v859_6), &(*p1), &(v857_11_tail));
          compose(&(v858_5),&(v859_7))
        };
        drop(v858_5);
        let v858_9: Space = intersect(&(*CONSTANT_14),&(v858_2));
        drop(v858_2);
        let v858_10: Space = if has_head(&(v858_9)) { singleton(&[]) } else { Space::new() };
        drop(v858_9);
        let v858_12: Space = if (v858_10).is_empty() { Space::new() } else {
          let v860_6: Path = concat_path(&(v857_6),&(v857_11_head));
          let v860_11: Space = routine_52(c, &(v860_6), &(*p1), &(v857_11_tail));
          drop(v860_6);
          compose(&(v858_10),&(v860_11))
        };
        drop(v858_10);
        let v858_13: Space = unite(&(v858_8),&(v858_12));
        v857_11.join_into((v858_13).clone());
      }
      drop(v857_11_cursor);
      drop(v857_6);
      compose(&(v852_10),&(v857_11))
    };
    drop(v852_10);
    let v852_13: Space = unite(&(v852_8),&(v852_12));
    v851_12.join_into((v852_13).clone());
  }
  drop(v851_12_cursor);
  (v851_12).clone()
}

fn routine_95(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v861_10 = Space::new();
  let mut v861_10_cursor = (*s0).read_zipper();
  for v861_10_byte in v861_10_cursor.child_mask().iter() {
    v861_10_cursor.descend_to_byte(v861_10_byte);
    let v861_10_tail = v861_10_cursor.make_map();
    v861_10_cursor.ascend(1);
    let v861_10_head = Path::from_slice(&[v861_10_byte]);
    let v862_2: Space = singleton(&(v861_10_head));
    let v862_3: Space = intersect(&(*CONSTANT_14),&(v862_2));
    let v862_4: Space = if has_head(&(v862_3)) { singleton(&[]) } else { Space::new() };
    drop(v862_3);
    let v862_5: Space = compose(&(v862_4),&(v861_10_tail));
    drop(v862_4);
    let v863_6: Path = concat_path(&(*p0),&(v861_10_head));
    let v862_7: Space = wrap(&(v862_5),&(v863_6));
    drop(v862_5);
    let v862_8: Space = wrap(&(v862_7),&(*p1));
    drop(v862_7);
    let v862_9: Space = wrap(&(v862_8),&(*CONSTANT_10));
    drop(v862_8);
    let v862_10: Space = intersect(&(*CONSTANT_14),&(v862_2));
    drop(v862_2);
    let v862_11: Space = if has_head(&(v862_10)) { singleton(&[]) } else { Space::new() };
    drop(v862_10);
    let v862_12: Space = subtract(&(*CONSTANT_0),&(v862_11));
    drop(v862_11);
    let v862_14: Space = if (v862_12).is_empty() { Space::new() } else {
      let mut v864_13 = Space::new();
      let mut v864_13_cursor = (v861_10_tail).read_zipper();
      for v864_13_byte in v864_13_cursor.child_mask().iter() {
        v864_13_cursor.descend_to_byte(v864_13_byte);
        let v864_13_tail = v864_13_cursor.make_map();
        v864_13_cursor.ascend(1);
        let v864_13_head = Path::from_slice(&[v864_13_byte]);
        let v865_2: Space = singleton(&(v864_13_head));
        let v865_3: Space = intersect(&(*CONSTANT_14),&(v865_2));
        let v865_4: Space = if has_head(&(v865_3)) { singleton(&[]) } else { Space::new() };
        drop(v865_3);
        let v865_5: Space = subtract(&(*CONSTANT_0),&(v865_4));
        drop(v865_4);
        let v865_8: Space = if (v865_5).is_empty() { Space::new() } else {
          let v866_6: Path = concat_path(&(v863_6),&(v864_13_head));
          let v866_7: Space = routine_126(c, &(v866_6), &(*p1), &(v864_13_tail));
          compose(&(v865_5),&(v866_7))
        };
        drop(v865_5);
        let v865_9: Space = intersect(&(*CONSTANT_14),&(v865_2));
        drop(v865_2);
        let v865_10: Space = if has_head(&(v865_9)) { singleton(&[]) } else { Space::new() };
        drop(v865_9);
        let v865_12: Space = if (v865_10).is_empty() { Space::new() } else {
          let v867_6: Path = concat_path(&(v863_6),&(v864_13_head));
          let v867_11: Space = routine_127(c, &(v867_6), &(*p1), &(v864_13_tail));
          drop(v867_6);
          compose(&(v865_10),&(v867_11))
        };
        drop(v865_10);
        let v865_13: Space = unite(&(v865_8),&(v865_12));
        v864_13.join_into((v865_13).clone());
      }
      drop(v864_13_cursor);
      compose(&(v862_12),&(v864_13))
    };
    drop(v862_12);
    let v862_15: Space = unite(&(v862_9),&(v862_14));
    drop(v862_9);
    v861_10.join_into((v862_15).clone());
  }
  drop(v861_10_cursor);
  (v861_10).clone()
}

fn routine_96(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v868_12 = Space::new();
  let mut v868_12_cursor = (*s0).read_zipper();
  for v868_12_byte in v868_12_cursor.child_mask().iter() {
    v868_12_cursor.descend_to_byte(v868_12_byte);
    let v868_12_tail = v868_12_cursor.make_map();
    v868_12_cursor.ascend(1);
    let v868_12_head = Path::from_slice(&[v868_12_byte]);
    let v869_2: Space = singleton(&(v868_12_head));
    let v869_3: Space = intersect(&(*CONSTANT_14),&(v869_2));
    let v869_4: Space = if has_head(&(v869_3)) { singleton(&[]) } else { Space::new() };
    drop(v869_3);
    let v869_5: Space = subtract(&(*CONSTANT_0),&(v869_4));
    drop(v869_4);
    let v869_8: Space = if (v869_5).is_empty() { Space::new() } else {
      let v870_6: Path = concat_path(&(*p0),&(v868_12_head));
      let mut v870_7 = Space::new();
      let mut v870_7_cursor = (v868_12_tail).read_zipper();
      for v870_7_byte in v870_7_cursor.child_mask().iter() {
        v870_7_cursor.descend_to_byte(v870_7_byte);
        let v870_7_tail = v870_7_cursor.make_map();
        v870_7_cursor.ascend(1);
        let v870_7_head = Path::from_slice(&[v870_7_byte]);
        let v871_2: Space = singleton(&(v870_7_head));
        let v871_3: Space = intersect(&(*CONSTANT_14),&(v871_2));
        let v871_4: Space = if has_head(&(v871_3)) { singleton(&[]) } else { Space::new() };
        drop(v871_3);
        let v871_5: Space = subtract(&(*CONSTANT_0),&(v871_4));
        drop(v871_4);
        let v871_8: Space = if (v871_5).is_empty() { Space::new() } else {
          let v872_6: Path = concat_path(&(v870_6),&(v870_7_head));
          let v872_7: Space = routine_128(c, &(v872_6), &(*p1), &(v870_7_tail));
          compose(&(v871_5),&(v872_7))
        };
        drop(v871_5);
        let v871_9: Space = intersect(&(*CONSTANT_14),&(v871_2));
        drop(v871_2);
        let v871_10: Space = if has_head(&(v871_9)) { singleton(&[]) } else { Space::new() };
        drop(v871_9);
        let v871_12: Space = if (v871_10).is_empty() { Space::new() } else {
          let v873_6: Path = concat_path(&(v870_6),&(v870_7_head));
          let v873_11: Space = routine_129(c, &(v873_6), &(*p1), &(v870_7_tail));
          drop(v873_6);
          compose(&(v871_10),&(v873_11))
        };
        drop(v871_10);
        let v871_13: Space = unite(&(v871_8),&(v871_12));
        v870_7.join_into((v871_13).clone());
      }
      drop(v870_7_cursor);
      compose(&(v869_5),&(v870_7))
    };
    drop(v869_5);
    let v869_9: Space = intersect(&(*CONSTANT_14),&(v869_2));
    drop(v869_2);
    let v869_10: Space = if has_head(&(v869_9)) { singleton(&[]) } else { Space::new() };
    drop(v869_9);
    let v869_12: Space = if (v869_10).is_empty() { Space::new() } else {
      let v874_6: Path = concat_path(&(*p0),&(v868_12_head));
      let mut v874_11 = Space::new();
      let mut v874_11_cursor = (v868_12_tail).read_zipper();
      for v874_11_byte in v874_11_cursor.child_mask().iter() {
        v874_11_cursor.descend_to_byte(v874_11_byte);
        let v874_11_tail = v874_11_cursor.make_map();
        v874_11_cursor.ascend(1);
        let v874_11_head = Path::from_slice(&[v874_11_byte]);
        let v875_2: Space = singleton(&(v874_11_head));
        let v875_3: Space = intersect(&(*CONSTANT_14),&(v875_2));
        let v875_4: Space = if has_head(&(v875_3)) { singleton(&[]) } else { Space::new() };
        drop(v875_3);
        let v875_5: Space = subtract(&(*CONSTANT_0),&(v875_4));
        drop(v875_4);
        let v875_8: Space = if (v875_5).is_empty() { Space::new() } else {
          let v876_6: Path = concat_path(&(v874_6),&(v874_11_head));
          let v876_7: Space = routine_128(c, &(v876_6), &(*p1), &(v874_11_tail));
          compose(&(v875_5),&(v876_7))
        };
        drop(v875_5);
        let v875_9: Space = intersect(&(*CONSTANT_14),&(v875_2));
        drop(v875_2);
        let v875_10: Space = if has_head(&(v875_9)) { singleton(&[]) } else { Space::new() };
        drop(v875_9);
        let v875_12: Space = if (v875_10).is_empty() { Space::new() } else {
          let v877_6: Path = concat_path(&(v874_6),&(v874_11_head));
          let v877_11: Space = routine_52(c, &(v877_6), &(*p1), &(v874_11_tail));
          drop(v877_6);
          compose(&(v875_10),&(v877_11))
        };
        drop(v875_10);
        let v875_13: Space = unite(&(v875_8),&(v875_12));
        v874_11.join_into((v875_13).clone());
      }
      drop(v874_11_cursor);
      drop(v874_6);
      compose(&(v869_10),&(v874_11))
    };
    drop(v869_10);
    let v869_13: Space = unite(&(v869_8),&(v869_12));
    v868_12.join_into((v869_13).clone());
  }
  drop(v868_12_cursor);
  (v868_12).clone()
}

fn routine_97(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v878_10 = Space::new();
  let mut v878_10_cursor = (*s0).read_zipper();
  for v878_10_byte in v878_10_cursor.child_mask().iter() {
    v878_10_cursor.descend_to_byte(v878_10_byte);
    let v878_10_tail = v878_10_cursor.make_map();
    v878_10_cursor.ascend(1);
    let v878_10_head = Path::from_slice(&[v878_10_byte]);
    let v879_2: Space = singleton(&(v878_10_head));
    let v879_3: Space = intersect(&(*CONSTANT_14),&(v879_2));
    let v879_4: Space = if has_head(&(v879_3)) { singleton(&[]) } else { Space::new() };
    drop(v879_3);
    let v879_5: Space = compose(&(v879_4),&(v878_10_tail));
    drop(v879_4);
    let v880_6: Path = concat_path(&(*p0),&(v878_10_head));
    let v879_7: Space = wrap(&(v879_5),&(v880_6));
    drop(v879_5);
    let v879_8: Space = wrap(&(v879_7),&(*p1));
    drop(v879_7);
    let v879_9: Space = wrap(&(v879_8),&(*CONSTANT_10));
    drop(v879_8);
    let v879_10: Space = intersect(&(*CONSTANT_14),&(v879_2));
    drop(v879_2);
    let v879_11: Space = if has_head(&(v879_10)) { singleton(&[]) } else { Space::new() };
    drop(v879_10);
    let v879_12: Space = subtract(&(*CONSTANT_0),&(v879_11));
    drop(v879_11);
    let v879_14: Space = if (v879_12).is_empty() { Space::new() } else {
      let mut v881_13 = Space::new();
      let mut v881_13_cursor = (v878_10_tail).read_zipper();
      for v881_13_byte in v881_13_cursor.child_mask().iter() {
        v881_13_cursor.descend_to_byte(v881_13_byte);
        let v881_13_tail = v881_13_cursor.make_map();
        v881_13_cursor.ascend(1);
        let v881_13_head = Path::from_slice(&[v881_13_byte]);
        let v882_2: Space = singleton(&(v881_13_head));
        let v882_3: Space = intersect(&(*CONSTANT_14),&(v882_2));
        let v882_4: Space = if has_head(&(v882_3)) { singleton(&[]) } else { Space::new() };
        drop(v882_3);
        let v882_5: Space = subtract(&(*CONSTANT_0),&(v882_4));
        drop(v882_4);
        let v882_8: Space = if (v882_5).is_empty() { Space::new() } else {
          let v883_6: Path = concat_path(&(v880_6),&(v881_13_head));
          let v883_7: Space = routine_128(c, &(v883_6), &(*p1), &(v881_13_tail));
          compose(&(v882_5),&(v883_7))
        };
        drop(v882_5);
        let v882_9: Space = intersect(&(*CONSTANT_14),&(v882_2));
        drop(v882_2);
        let v882_10: Space = if has_head(&(v882_9)) { singleton(&[]) } else { Space::new() };
        drop(v882_9);
        let v882_12: Space = if (v882_10).is_empty() { Space::new() } else {
          let v884_6: Path = concat_path(&(v880_6),&(v881_13_head));
          let v884_11: Space = routine_129(c, &(v884_6), &(*p1), &(v881_13_tail));
          drop(v884_6);
          compose(&(v882_10),&(v884_11))
        };
        drop(v882_10);
        let v882_13: Space = unite(&(v882_8),&(v882_12));
        v881_13.join_into((v882_13).clone());
      }
      drop(v881_13_cursor);
      compose(&(v879_12),&(v881_13))
    };
    drop(v879_12);
    let v879_15: Space = unite(&(v879_9),&(v879_14));
    drop(v879_9);
    v878_10.join_into((v879_15).clone());
  }
  drop(v878_10_cursor);
  (v878_10).clone()
}

fn routine_98(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v885_13 = Space::new();
  let mut v885_13_cursor = (*s0).read_zipper();
  for v885_13_byte in v885_13_cursor.child_mask().iter() {
    v885_13_cursor.descend_to_byte(v885_13_byte);
    let v885_13_tail = v885_13_cursor.make_map();
    v885_13_cursor.ascend(1);
    let v885_13_head = Path::from_slice(&[v885_13_byte]);
    let v886_2: Space = singleton(&(v885_13_head));
    let v886_3: Space = intersect(&(*CONSTANT_14),&(v886_2));
    let v886_4: Space = if has_head(&(v886_3)) { singleton(&[]) } else { Space::new() };
    drop(v886_3);
    let v886_5: Space = subtract(&(*CONSTANT_0),&(v886_4));
    drop(v886_4);
    let v886_8: Space = if (v886_5).is_empty() { Space::new() } else {
      let v887_6: Path = concat_path(&(*p0),&(v885_13_head));
      let mut v887_7 = Space::new();
      let mut v887_7_cursor = (v885_13_tail).read_zipper();
      for v887_7_byte in v887_7_cursor.child_mask().iter() {
        v887_7_cursor.descend_to_byte(v887_7_byte);
        let v887_7_tail = v887_7_cursor.make_map();
        v887_7_cursor.ascend(1);
        let v887_7_head = Path::from_slice(&[v887_7_byte]);
        let v888_2: Space = singleton(&(v887_7_head));
        let v888_3: Space = intersect(&(*CONSTANT_14),&(v888_2));
        let v888_4: Space = if has_head(&(v888_3)) { singleton(&[]) } else { Space::new() };
        drop(v888_3);
        let v888_5: Space = subtract(&(*CONSTANT_0),&(v888_4));
        drop(v888_4);
        let v888_8: Space = if (v888_5).is_empty() { Space::new() } else {
          let v889_6: Path = concat_path(&(v887_6),&(v887_7_head));
          let v889_7: Space = routine_130(c, &(v889_6), &(*p1), &(v887_7_tail), &(*s1));
          compose(&(v888_5),&(v889_7))
        };
        drop(v888_5);
        let v888_9: Space = intersect(&(*CONSTANT_14),&(v888_2));
        drop(v888_2);
        let v888_10: Space = if has_head(&(v888_9)) { singleton(&[]) } else { Space::new() };
        drop(v888_9);
        let v888_12: Space = if (v888_10).is_empty() { Space::new() } else {
          let v890_6: Path = concat_path(&(v887_6),&(v887_7_head));
          let v890_11: Space = routine_131(c, &(v890_6), &(*p1), &(v887_7_tail), &(*s1));
          drop(v890_6);
          compose(&(v888_10),&(v890_11))
        };
        drop(v888_10);
        let v888_13: Space = unite(&(v888_8),&(v888_12));
        v887_7.join_into((v888_13).clone());
      }
      drop(v887_7_cursor);
      compose(&(v886_5),&(v887_7))
    };
    drop(v886_5);
    let v886_9: Space = intersect(&(*CONSTANT_14),&(v886_2));
    drop(v886_2);
    let v886_10: Space = if has_head(&(v886_9)) { singleton(&[]) } else { Space::new() };
    drop(v886_9);
    let v886_12: Space = if (v886_10).is_empty() { Space::new() } else {
      let v891_6: Path = concat_path(&(*p0),&(v885_13_head));
      let mut v891_11 = Space::new();
      let mut v891_11_cursor = (v885_13_tail).read_zipper();
      for v891_11_byte in v891_11_cursor.child_mask().iter() {
        v891_11_cursor.descend_to_byte(v891_11_byte);
        let v891_11_tail = v891_11_cursor.make_map();
        v891_11_cursor.ascend(1);
        let v891_11_head = Path::from_slice(&[v891_11_byte]);
        let v892_2: Space = singleton(&(v891_11_head));
        let v892_3: Space = intersect(&(*CONSTANT_14),&(v892_2));
        let v892_4: Space = if has_head(&(v892_3)) { singleton(&[]) } else { Space::new() };
        drop(v892_3);
        let v892_5: Space = subtract(&(*CONSTANT_0),&(v892_4));
        drop(v892_4);
        let v892_8: Space = if (v892_5).is_empty() { Space::new() } else {
          let v893_6: Path = concat_path(&(v891_6),&(v891_11_head));
          let v893_7: Space = routine_130(c, &(v893_6), &(*p1), &(v891_11_tail), &(*s1));
          compose(&(v892_5),&(v893_7))
        };
        drop(v892_5);
        let v892_9: Space = intersect(&(*CONSTANT_14),&(v892_2));
        drop(v892_2);
        let v892_10: Space = if has_head(&(v892_9)) { singleton(&[]) } else { Space::new() };
        drop(v892_9);
        let v892_12: Space = if (v892_10).is_empty() { Space::new() } else {
          let v894_6: Path = concat_path(&(v891_6),&(v891_11_head));
          let v894_11: Space = routine_26(c, &(v894_6), &(*p1), &(v891_11_tail), &(*s1));
          drop(v894_6);
          compose(&(v892_10),&(v894_11))
        };
        drop(v892_10);
        let v892_13: Space = unite(&(v892_8),&(v892_12));
        v891_11.join_into((v892_13).clone());
      }
      drop(v891_11_cursor);
      drop(v891_6);
      compose(&(v886_10),&(v891_11))
    };
    drop(v886_10);
    let v886_13: Space = unite(&(v886_8),&(v886_12));
    v885_13.join_into((v886_13).clone());
  }
  drop(v885_13_cursor);
  (v885_13).clone()
}

fn routine_99(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v895_8: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v895_10: Space = unwrap(&(v895_8),&(*CONSTANT_10));
  drop(v895_8);
  let v895_11: Space = unwrap(&(v895_10),&(*p0));
  drop(v895_10);
  let mut v895_18 = Space::new();
  let mut v895_18_cursor = (*s0).read_zipper();
  for v895_18_byte in v895_18_cursor.child_mask().iter() {
    v895_18_cursor.descend_to_byte(v895_18_byte);
    let v895_18_tail = v895_18_cursor.make_map();
    v895_18_cursor.ascend(1);
    let v895_18_head = Path::from_slice(&[v895_18_byte]);
    let v896_2: Space = singleton(&(v895_18_head));
    let v896_3: Space = intersect(&(*CONSTANT_14),&(v896_2));
    let v896_4: Space = if has_head(&(v896_3)) { singleton(&[]) } else { Space::new() };
    drop(v896_3);
    let v896_5: Space = subtract(&(*CONSTANT_0),&(v896_4));
    drop(v896_4);
    let v896_8: Space = if (v896_5).is_empty() { Space::new() } else {
      let v897_6: Path = concat_path(&(*p0),&(v895_18_head));
      let mut v897_7 = Space::new();
      let mut v897_7_cursor = (v895_18_tail).read_zipper();
      for v897_7_byte in v897_7_cursor.child_mask().iter() {
        v897_7_cursor.descend_to_byte(v897_7_byte);
        let v897_7_tail = v897_7_cursor.make_map();
        v897_7_cursor.ascend(1);
        let v897_7_head = Path::from_slice(&[v897_7_byte]);
        let v898_2: Space = singleton(&(v897_7_head));
        let v898_3: Space = intersect(&(*CONSTANT_14),&(v898_2));
        let v898_4: Space = if has_head(&(v898_3)) { singleton(&[]) } else { Space::new() };
        drop(v898_3);
        let v898_5: Space = subtract(&(*CONSTANT_0),&(v898_4));
        drop(v898_4);
        let v898_8: Space = if (v898_5).is_empty() { Space::new() } else {
          let v899_6: Path = concat_path(&(v897_6),&(v897_7_head));
          let v899_7: Space = routine_130(c, &(v899_6), &(*p1), &(v897_7_tail), &(*s1));
          compose(&(v898_5),&(v899_7))
        };
        drop(v898_5);
        let v898_9: Space = intersect(&(*CONSTANT_14),&(v898_2));
        drop(v898_2);
        let v898_10: Space = if has_head(&(v898_9)) { singleton(&[]) } else { Space::new() };
        drop(v898_9);
        let v898_12: Space = if (v898_10).is_empty() { Space::new() } else {
          let v900_6: Path = concat_path(&(v897_6),&(v897_7_head));
          let v900_11: Space = routine_131(c, &(v900_6), &(*p1), &(v897_7_tail), &(*s1));
          drop(v900_6);
          compose(&(v898_10),&(v900_11))
        };
        drop(v898_10);
        let v898_13: Space = unite(&(v898_8),&(v898_12));
        v897_7.join_into((v898_13).clone());
      }
      drop(v897_7_cursor);
      drop(v897_6);
      compose(&(v896_5),&(v897_7))
    };
    drop(v896_5);
    let v896_9: Space = intersect(&(*CONSTANT_14),&(v896_2));
    drop(v896_2);
    let v896_10: Space = if has_head(&(v896_9)) { singleton(&[]) } else { Space::new() };
    drop(v896_9);
    let v896_13: Space = if (v896_10).is_empty() { Space::new() } else {
      let v901_11: Space = unwrap(&(v895_11),&(v895_18_head));
      let mut v901_12 = Space::new();
      let mut v901_12_cursor = (v901_11).read_zipper();
      for v901_12_byte in v901_12_cursor.child_mask().iter() {
        v901_12_cursor.descend_to_byte(v901_12_byte);
        let v901_12_tail = v901_12_cursor.make_map();
        v901_12_cursor.ascend(1);
        let v901_12_head = Path::from_slice(&[v901_12_byte]);
        let v902_2: Space = singleton(&(v901_12_head));
        let v902_3: Space = intersect(&(*CONSTANT_14),&(v902_2));
        let v902_4: Space = if has_head(&(v902_3)) { singleton(&[]) } else { Space::new() };
        drop(v902_3);
        let v902_5: Space = subtract(&(*CONSTANT_0),&(v902_4));
        drop(v902_4);
        let v902_7: Space = if (v902_5).is_empty() { Space::new() } else {
          let v903_6: Space = routine_59(c, &(v901_12_head), &(*p1), &(v901_12_tail));
          compose(&(v902_5),&(v903_6))
        };
        drop(v902_5);
        let v902_8: Space = intersect(&(*CONSTANT_14),&(v902_2));
        drop(v902_2);
        let v902_9: Space = if has_head(&(v902_8)) { singleton(&[]) } else { Space::new() };
        drop(v902_8);
        let v902_11: Space = if (v902_9).is_empty() { Space::new() } else {
          let v904_10: Space = routine_60(c, &(v901_12_head), &(*p1), &(v901_12_tail));
          compose(&(v902_9),&(v904_10))
        };
        drop(v902_9);
        let v902_12: Space = unite(&(v902_7),&(v902_11));
        v901_12.join_into((v902_12).clone());
      }
      drop(v901_12_cursor);
      drop(v901_11);
      compose(&(v896_10),&(v901_12))
    };
    drop(v896_10);
    let v896_14: Space = unite(&(v896_8),&(v896_13));
    v895_18.join_into((v896_14).clone());
  }
  drop(v895_18_cursor);
  drop(v895_11);
  (v895_18).clone()
}

fn routine_100(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v905_12 = Space::new();
  let mut v905_12_cursor = (*s0).read_zipper();
  for v905_12_byte in v905_12_cursor.child_mask().iter() {
    v905_12_cursor.descend_to_byte(v905_12_byte);
    let v905_12_tail = v905_12_cursor.make_map();
    v905_12_cursor.ascend(1);
    let v905_12_head = Path::from_slice(&[v905_12_byte]);
    let v906_2: Space = singleton(&(v905_12_head));
    let v906_3: Space = intersect(&(*CONSTANT_14),&(v906_2));
    let v906_4: Space = if has_head(&(v906_3)) { singleton(&[]) } else { Space::new() };
    drop(v906_3);
    let v906_5: Space = subtract(&(*CONSTANT_0),&(v906_4));
    drop(v906_4);
    let v906_8: Space = if (v906_5).is_empty() { Space::new() } else {
      let v907_6: Path = concat_path(&(*p0),&(v905_12_head));
      let mut v907_7 = Space::new();
      let mut v907_7_cursor = (v905_12_tail).read_zipper();
      for v907_7_byte in v907_7_cursor.child_mask().iter() {
        v907_7_cursor.descend_to_byte(v907_7_byte);
        let v907_7_tail = v907_7_cursor.make_map();
        v907_7_cursor.ascend(1);
        let v907_7_head = Path::from_slice(&[v907_7_byte]);
        let v908_2: Space = singleton(&(v907_7_head));
        let v908_3: Space = intersect(&(*CONSTANT_14),&(v908_2));
        let v908_4: Space = if has_head(&(v908_3)) { singleton(&[]) } else { Space::new() };
        drop(v908_3);
        let v908_5: Space = subtract(&(*CONSTANT_0),&(v908_4));
        drop(v908_4);
        let v908_8: Space = if (v908_5).is_empty() { Space::new() } else {
          let v909_6: Path = concat_path(&(v907_6),&(v907_7_head));
          let v909_7: Space = routine_132(c, &(v909_6), &(*p1), &(v907_7_tail));
          compose(&(v908_5),&(v909_7))
        };
        drop(v908_5);
        let v908_9: Space = intersect(&(*CONSTANT_14),&(v908_2));
        drop(v908_2);
        let v908_10: Space = if has_head(&(v908_9)) { singleton(&[]) } else { Space::new() };
        drop(v908_9);
        let v908_12: Space = if (v908_10).is_empty() { Space::new() } else {
          let v910_6: Path = concat_path(&(v907_6),&(v907_7_head));
          let v910_11: Space = routine_133(c, &(v910_6), &(*p1), &(v907_7_tail));
          drop(v910_6);
          compose(&(v908_10),&(v910_11))
        };
        drop(v908_10);
        let v908_13: Space = unite(&(v908_8),&(v908_12));
        v907_7.join_into((v908_13).clone());
      }
      drop(v907_7_cursor);
      compose(&(v906_5),&(v907_7))
    };
    drop(v906_5);
    let v906_9: Space = intersect(&(*CONSTANT_14),&(v906_2));
    drop(v906_2);
    let v906_10: Space = if has_head(&(v906_9)) { singleton(&[]) } else { Space::new() };
    drop(v906_9);
    let v906_12: Space = if (v906_10).is_empty() { Space::new() } else {
      let v911_6: Path = concat_path(&(*p0),&(v905_12_head));
      let mut v911_11 = Space::new();
      let mut v911_11_cursor = (v905_12_tail).read_zipper();
      for v911_11_byte in v911_11_cursor.child_mask().iter() {
        v911_11_cursor.descend_to_byte(v911_11_byte);
        let v911_11_tail = v911_11_cursor.make_map();
        v911_11_cursor.ascend(1);
        let v911_11_head = Path::from_slice(&[v911_11_byte]);
        let v912_2: Space = singleton(&(v911_11_head));
        let v912_3: Space = intersect(&(*CONSTANT_14),&(v912_2));
        let v912_4: Space = if has_head(&(v912_3)) { singleton(&[]) } else { Space::new() };
        drop(v912_3);
        let v912_5: Space = subtract(&(*CONSTANT_0),&(v912_4));
        drop(v912_4);
        let v912_8: Space = if (v912_5).is_empty() { Space::new() } else {
          let v913_6: Path = concat_path(&(v911_6),&(v911_11_head));
          let v913_7: Space = routine_132(c, &(v913_6), &(*p1), &(v911_11_tail));
          compose(&(v912_5),&(v913_7))
        };
        drop(v912_5);
        let v912_9: Space = intersect(&(*CONSTANT_14),&(v912_2));
        drop(v912_2);
        let v912_10: Space = if has_head(&(v912_9)) { singleton(&[]) } else { Space::new() };
        drop(v912_9);
        let v912_12: Space = if (v912_10).is_empty() { Space::new() } else {
          let v914_6: Path = concat_path(&(v911_6),&(v911_11_head));
          let v914_11: Space = routine_65(c, &(v914_6), &(*p1), &(v911_11_tail));
          drop(v914_6);
          compose(&(v912_10),&(v914_11))
        };
        drop(v912_10);
        let v912_13: Space = unite(&(v912_8),&(v912_12));
        v911_11.join_into((v912_13).clone());
      }
      drop(v911_11_cursor);
      drop(v911_6);
      compose(&(v906_10),&(v911_11))
    };
    drop(v906_10);
    let v906_13: Space = unite(&(v906_8),&(v906_12));
    v905_12.join_into((v906_13).clone());
  }
  drop(v905_12_cursor);
  (v905_12).clone()
}

fn routine_101(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v915_9 = Space::new();
  let mut v915_9_cursor = (*s0).read_zipper();
  for v915_9_byte in v915_9_cursor.child_mask().iter() {
    v915_9_cursor.descend_to_byte(v915_9_byte);
    let v915_9_tail = v915_9_cursor.make_map();
    v915_9_cursor.ascend(1);
    let v915_9_head = Path::from_slice(&[v915_9_byte]);
    let v916_2: Space = singleton(&(v915_9_head));
    let v916_3: Space = intersect(&(*CONSTANT_14),&(v916_2));
    let v916_4: Space = if has_head(&(v916_3)) { singleton(&[]) } else { Space::new() };
    drop(v916_3);
    let v916_5: Space = subtract(&(*CONSTANT_0),&(v916_4));
    drop(v916_4);
    let v916_8: Space = if (v916_5).is_empty() { Space::new() } else {
      let v917_6: Path = concat_path(&(*p0),&(v915_9_head));
      let mut v917_7 = Space::new();
      let mut v917_7_cursor = (v915_9_tail).read_zipper();
      for v917_7_byte in v917_7_cursor.child_mask().iter() {
        v917_7_cursor.descend_to_byte(v917_7_byte);
        let v917_7_tail = v917_7_cursor.make_map();
        v917_7_cursor.ascend(1);
        let v917_7_head = Path::from_slice(&[v917_7_byte]);
        let v918_2: Space = singleton(&(v917_7_head));
        let v918_3: Space = intersect(&(*CONSTANT_14),&(v918_2));
        let v918_4: Space = if has_head(&(v918_3)) { singleton(&[]) } else { Space::new() };
        drop(v918_3);
        let v918_5: Space = subtract(&(*CONSTANT_0),&(v918_4));
        drop(v918_4);
        let v918_8: Space = if (v918_5).is_empty() { Space::new() } else {
          let v919_6: Path = concat_path(&(v917_6),&(v917_7_head));
          let v919_7: Space = routine_132(c, &(v919_6), &(*p1), &(v917_7_tail));
          compose(&(v918_5),&(v919_7))
        };
        drop(v918_5);
        let v918_9: Space = intersect(&(*CONSTANT_14),&(v918_2));
        drop(v918_2);
        let v918_10: Space = if has_head(&(v918_9)) { singleton(&[]) } else { Space::new() };
        drop(v918_9);
        let v918_12: Space = if (v918_10).is_empty() { Space::new() } else {
          let v920_6: Path = concat_path(&(v917_6),&(v917_7_head));
          let v920_11: Space = routine_133(c, &(v920_6), &(*p1), &(v917_7_tail));
          drop(v920_6);
          compose(&(v918_10),&(v920_11))
        };
        drop(v918_10);
        let v918_13: Space = unite(&(v918_8),&(v918_12));
        v917_7.join_into((v918_13).clone());
      }
      drop(v917_7_cursor);
      compose(&(v916_5),&(v917_7))
    };
    drop(v916_5);
    let v916_9: Space = intersect(&(*CONSTANT_14),&(v916_2));
    drop(v916_2);
    let v916_10: Space = if has_head(&(v916_9)) { singleton(&[]) } else { Space::new() };
    drop(v916_9);
    let v916_11: Space = compose(&(v916_10),&(v915_9_tail));
    drop(v916_10);
    let v921_6: Path = concat_path(&(*p0),&(v915_9_head));
    let v916_12: Space = wrap(&(v916_11),&(v921_6));
    drop(v916_11);
    let v916_13: Space = wrap(&(v916_12),&(*p1));
    drop(v916_12);
    let v916_14: Space = unite(&(v916_8),&(v916_13));
    drop(v916_13);
    v915_9.join_into((v916_14).clone());
  }
  drop(v915_9_cursor);
  (v915_9).clone()
}

fn routine_102(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v922_8 = Space::new();
  let mut v922_8_cursor = (*s0).read_zipper();
  for v922_8_byte in v922_8_cursor.child_mask().iter() {
    v922_8_cursor.descend_to_byte(v922_8_byte);
    let v922_8_tail = v922_8_cursor.make_map();
    v922_8_cursor.ascend(1);
    let v922_8_head = Path::from_slice(&[v922_8_byte]);
    let v923_2: Space = singleton(&(v922_8_head));
    let v923_3: Space = intersect(&(*CONSTANT_14),&(v923_2));
    let v923_4: Space = if has_head(&(v923_3)) { singleton(&[]) } else { Space::new() };
    drop(v923_3);
    let v923_5: Space = subtract(&(*CONSTANT_0),&(v923_4));
    drop(v923_4);
    let mut v923_6 = Space::new();
    let mut v923_6_cursor = (v922_8_tail).read_zipper();
    for v923_6_byte in v923_6_cursor.child_mask().iter() {
      v923_6_cursor.descend_to_byte(v923_6_byte);
      let v923_6_tail = v923_6_cursor.make_map();
      v923_6_cursor.ascend(1);
      let v923_6_head = Path::from_slice(&[v923_6_byte]);
      let v924_2: Space = Space::new();
      v923_6.join_into((v924_2).clone());
    }
    drop(v923_6_cursor);
    let v923_7: Space = compose(&(v923_5),&(v923_6));
    drop(v923_5);
    drop(v923_6);
    let v923_8: Space = intersect(&(*CONSTANT_14),&(v923_2));
    drop(v923_2);
    let v923_9: Space = if has_head(&(v923_8)) { singleton(&[]) } else { Space::new() };
    drop(v923_8);
    let v923_12: Space = if (v923_9).is_empty() { Space::new() } else {
      let v925_10: Path = concat_path(&(*p0),&(v922_8_head));
      let mut v925_11 = Space::new();
      let mut v925_11_cursor = (v922_8_tail).read_zipper();
      for v925_11_byte in v925_11_cursor.child_mask().iter() {
        v925_11_cursor.descend_to_byte(v925_11_byte);
        let v925_11_tail = v925_11_cursor.make_map();
        v925_11_cursor.ascend(1);
        let v925_11_head = Path::from_slice(&[v925_11_byte]);
        let v926_2: Space = singleton(&(v925_11_head));
        let v926_3: Space = intersect(&(*CONSTANT_14),&(v926_2));
        drop(v926_2);
        let v926_4: Space = if has_head(&(v926_3)) { singleton(&[]) } else { Space::new() };
        drop(v926_3);
        let v926_7: Space = if (v926_4).is_empty() { Space::new() } else {
          let v927_5: Path = concat_path(&(v925_10),&(v925_11_head));
          let v927_6: Space = routine_26(c, &(v927_5), &(*p1), &(v925_11_tail), &(*s1));
          drop(v927_5);
          compose(&(v926_4),&(v927_6))
        };
        drop(v926_4);
        v925_11.join_into((v926_7).clone());
      }
      drop(v925_11_cursor);
      drop(v925_10);
      compose(&(v923_9),&(v925_11))
    };
    drop(v923_9);
    let v923_13: Space = unite(&(v923_7),&(v923_12));
    drop(v923_7);
    v922_8.join_into((v923_13).clone());
  }
  drop(v922_8_cursor);
  (v922_8).clone()
}

fn routine_103(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v928_8: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v928_10: Space = unwrap(&(v928_8),&(*CONSTANT_10));
  drop(v928_8);
  let v928_11: Space = unwrap(&(v928_10),&(*p0));
  drop(v928_10);
  let mut v928_15 = Space::new();
  let mut v928_15_cursor = (*s0).read_zipper();
  for v928_15_byte in v928_15_cursor.child_mask().iter() {
    v928_15_cursor.descend_to_byte(v928_15_byte);
    let v928_15_tail = v928_15_cursor.make_map();
    v928_15_cursor.ascend(1);
    let v928_15_head = Path::from_slice(&[v928_15_byte]);
    let v929_2: Space = singleton(&(v928_15_head));
    let v929_3: Space = intersect(&(*CONSTANT_14),&(v929_2));
    let v929_4: Space = if has_head(&(v929_3)) { singleton(&[]) } else { Space::new() };
    drop(v929_3);
    let v929_5: Space = subtract(&(*CONSTANT_0),&(v929_4));
    drop(v929_4);
    let mut v929_6 = Space::new();
    let mut v929_6_cursor = (v928_15_tail).read_zipper();
    for v929_6_byte in v929_6_cursor.child_mask().iter() {
      v929_6_cursor.descend_to_byte(v929_6_byte);
      let v929_6_tail = v929_6_cursor.make_map();
      v929_6_cursor.ascend(1);
      let v929_6_head = Path::from_slice(&[v929_6_byte]);
      let v930_2: Space = Space::new();
      v929_6.join_into((v930_2).clone());
    }
    drop(v929_6_cursor);
    let v929_7: Space = compose(&(v929_5),&(v929_6));
    drop(v929_5);
    drop(v929_6);
    let v929_8: Space = intersect(&(*CONSTANT_14),&(v929_2));
    drop(v929_2);
    let v929_9: Space = if has_head(&(v929_8)) { singleton(&[]) } else { Space::new() };
    drop(v929_8);
    let v929_12: Space = if (v929_9).is_empty() { Space::new() } else {
      let v931_10: Space = unwrap(&(v928_11),&(v928_15_head));
      let mut v931_11 = Space::new();
      let mut v931_11_cursor = (v931_10).read_zipper();
      for v931_11_byte in v931_11_cursor.child_mask().iter() {
        v931_11_cursor.descend_to_byte(v931_11_byte);
        let v931_11_tail = v931_11_cursor.make_map();
        v931_11_cursor.ascend(1);
        let v931_11_head = Path::from_slice(&[v931_11_byte]);
        let v932_2: Space = singleton(&(v931_11_head));
        let v932_3: Space = intersect(&(*CONSTANT_14),&(v932_2));
        let v932_4: Space = if has_head(&(v932_3)) { singleton(&[]) } else { Space::new() };
        drop(v932_3);
        let v932_5: Space = subtract(&(*CONSTANT_0),&(v932_4));
        drop(v932_4);
        let v932_7: Space = if (v932_5).is_empty() { Space::new() } else {
          let v933_6: Space = routine_59(c, &(v931_11_head), &(*p1), &(v931_11_tail));
          compose(&(v932_5),&(v933_6))
        };
        drop(v932_5);
        let v932_8: Space = intersect(&(*CONSTANT_14),&(v932_2));
        drop(v932_2);
        let v932_9: Space = if has_head(&(v932_8)) { singleton(&[]) } else { Space::new() };
        drop(v932_8);
        let v932_11: Space = if (v932_9).is_empty() { Space::new() } else {
          let v934_10: Space = routine_60(c, &(v931_11_head), &(*p1), &(v931_11_tail));
          compose(&(v932_9),&(v934_10))
        };
        drop(v932_9);
        let v932_12: Space = unite(&(v932_7),&(v932_11));
        v931_11.join_into((v932_12).clone());
      }
      drop(v931_11_cursor);
      drop(v931_10);
      compose(&(v929_9),&(v931_11))
    };
    drop(v929_9);
    let v929_13: Space = unite(&(v929_7),&(v929_12));
    drop(v929_7);
    v928_15.join_into((v929_13).clone());
  }
  drop(v928_15_cursor);
  drop(v928_11);
  (v928_15).clone()
}

fn routine_104(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v935_12 = Space::new();
  let mut v935_12_cursor = (*s0).read_zipper();
  for v935_12_byte in v935_12_cursor.child_mask().iter() {
    v935_12_cursor.descend_to_byte(v935_12_byte);
    let v935_12_tail = v935_12_cursor.make_map();
    v935_12_cursor.ascend(1);
    let v935_12_head = Path::from_slice(&[v935_12_byte]);
    let v936_2: Space = singleton(&(v935_12_head));
    let v936_3: Space = intersect(&(*CONSTANT_14),&(v936_2));
    let v936_4: Space = if has_head(&(v936_3)) { singleton(&[]) } else { Space::new() };
    drop(v936_3);
    let v936_5: Space = subtract(&(*CONSTANT_0),&(v936_4));
    drop(v936_4);
    let v936_8: Space = if (v936_5).is_empty() { Space::new() } else {
      let v937_6: Path = concat_path(&(*p0),&(v935_12_head));
      let mut v937_7 = Space::new();
      let mut v937_7_cursor = (v935_12_tail).read_zipper();
      for v937_7_byte in v937_7_cursor.child_mask().iter() {
        v937_7_cursor.descend_to_byte(v937_7_byte);
        let v937_7_tail = v937_7_cursor.make_map();
        v937_7_cursor.ascend(1);
        let v937_7_head = Path::from_slice(&[v937_7_byte]);
        let v938_2: Space = singleton(&(v937_7_head));
        let v938_3: Space = intersect(&(*CONSTANT_14),&(v938_2));
        let v938_4: Space = if has_head(&(v938_3)) { singleton(&[]) } else { Space::new() };
        drop(v938_3);
        let v938_5: Space = subtract(&(*CONSTANT_0),&(v938_4));
        drop(v938_4);
        let v938_8: Space = if (v938_5).is_empty() { Space::new() } else {
          let v939_6: Path = concat_path(&(v937_6),&(v937_7_head));
          let v939_7: Space = routine_134(c, &(v939_6), &(*p1), &(v937_7_tail));
          compose(&(v938_5),&(v939_7))
        };
        drop(v938_5);
        let v938_9: Space = intersect(&(*CONSTANT_14),&(v938_2));
        drop(v938_2);
        let v938_10: Space = if has_head(&(v938_9)) { singleton(&[]) } else { Space::new() };
        drop(v938_9);
        let v938_12: Space = if (v938_10).is_empty() { Space::new() } else {
          let v940_6: Path = concat_path(&(v937_6),&(v937_7_head));
          let v940_11: Space = routine_135(c, &(v940_6), &(*p1), &(v937_7_tail));
          drop(v940_6);
          compose(&(v938_10),&(v940_11))
        };
        drop(v938_10);
        let v938_13: Space = unite(&(v938_8),&(v938_12));
        v937_7.join_into((v938_13).clone());
      }
      drop(v937_7_cursor);
      compose(&(v936_5),&(v937_7))
    };
    drop(v936_5);
    let v936_9: Space = intersect(&(*CONSTANT_14),&(v936_2));
    drop(v936_2);
    let v936_10: Space = if has_head(&(v936_9)) { singleton(&[]) } else { Space::new() };
    drop(v936_9);
    let v936_12: Space = if (v936_10).is_empty() { Space::new() } else {
      let v941_6: Path = concat_path(&(*p0),&(v935_12_head));
      let mut v941_11 = Space::new();
      let mut v941_11_cursor = (v935_12_tail).read_zipper();
      for v941_11_byte in v941_11_cursor.child_mask().iter() {
        v941_11_cursor.descend_to_byte(v941_11_byte);
        let v941_11_tail = v941_11_cursor.make_map();
        v941_11_cursor.ascend(1);
        let v941_11_head = Path::from_slice(&[v941_11_byte]);
        let v942_2: Space = singleton(&(v941_11_head));
        let v942_3: Space = intersect(&(*CONSTANT_14),&(v942_2));
        let v942_4: Space = if has_head(&(v942_3)) { singleton(&[]) } else { Space::new() };
        drop(v942_3);
        let v942_5: Space = subtract(&(*CONSTANT_0),&(v942_4));
        drop(v942_4);
        let v942_8: Space = if (v942_5).is_empty() { Space::new() } else {
          let v943_6: Path = concat_path(&(v941_6),&(v941_11_head));
          let v943_7: Space = routine_134(c, &(v943_6), &(*p1), &(v941_11_tail));
          compose(&(v942_5),&(v943_7))
        };
        drop(v942_5);
        let v942_9: Space = intersect(&(*CONSTANT_14),&(v942_2));
        drop(v942_2);
        let v942_10: Space = if has_head(&(v942_9)) { singleton(&[]) } else { Space::new() };
        drop(v942_9);
        let v942_12: Space = if (v942_10).is_empty() { Space::new() } else {
          let v944_6: Path = concat_path(&(v941_6),&(v941_11_head));
          let v944_11: Space = routine_65(c, &(v944_6), &(*p1), &(v941_11_tail));
          drop(v944_6);
          compose(&(v942_10),&(v944_11))
        };
        drop(v942_10);
        let v942_13: Space = unite(&(v942_8),&(v942_12));
        v941_11.join_into((v942_13).clone());
      }
      drop(v941_11_cursor);
      drop(v941_6);
      compose(&(v936_10),&(v941_11))
    };
    drop(v936_10);
    let v936_13: Space = unite(&(v936_8),&(v936_12));
    v935_12.join_into((v936_13).clone());
  }
  drop(v935_12_cursor);
  (v935_12).clone()
}

fn routine_105(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v945_9 = Space::new();
  let mut v945_9_cursor = (*s0).read_zipper();
  for v945_9_byte in v945_9_cursor.child_mask().iter() {
    v945_9_cursor.descend_to_byte(v945_9_byte);
    let v945_9_tail = v945_9_cursor.make_map();
    v945_9_cursor.ascend(1);
    let v945_9_head = Path::from_slice(&[v945_9_byte]);
    let v946_2: Space = singleton(&(v945_9_head));
    let v946_3: Space = intersect(&(*CONSTANT_14),&(v946_2));
    let v946_4: Space = if has_head(&(v946_3)) { singleton(&[]) } else { Space::new() };
    drop(v946_3);
    let v946_5: Space = subtract(&(*CONSTANT_0),&(v946_4));
    drop(v946_4);
    let v946_8: Space = if (v946_5).is_empty() { Space::new() } else {
      let v947_6: Path = concat_path(&(*p0),&(v945_9_head));
      let mut v947_7 = Space::new();
      let mut v947_7_cursor = (v945_9_tail).read_zipper();
      for v947_7_byte in v947_7_cursor.child_mask().iter() {
        v947_7_cursor.descend_to_byte(v947_7_byte);
        let v947_7_tail = v947_7_cursor.make_map();
        v947_7_cursor.ascend(1);
        let v947_7_head = Path::from_slice(&[v947_7_byte]);
        let v948_2: Space = singleton(&(v947_7_head));
        let v948_3: Space = intersect(&(*CONSTANT_14),&(v948_2));
        let v948_4: Space = if has_head(&(v948_3)) { singleton(&[]) } else { Space::new() };
        drop(v948_3);
        let v948_5: Space = subtract(&(*CONSTANT_0),&(v948_4));
        drop(v948_4);
        let v948_8: Space = if (v948_5).is_empty() { Space::new() } else {
          let v949_6: Path = concat_path(&(v947_6),&(v947_7_head));
          let v949_7: Space = routine_134(c, &(v949_6), &(*p1), &(v947_7_tail));
          compose(&(v948_5),&(v949_7))
        };
        drop(v948_5);
        let v948_9: Space = intersect(&(*CONSTANT_14),&(v948_2));
        drop(v948_2);
        let v948_10: Space = if has_head(&(v948_9)) { singleton(&[]) } else { Space::new() };
        drop(v948_9);
        let v948_12: Space = if (v948_10).is_empty() { Space::new() } else {
          let v950_6: Path = concat_path(&(v947_6),&(v947_7_head));
          let v950_11: Space = routine_135(c, &(v950_6), &(*p1), &(v947_7_tail));
          drop(v950_6);
          compose(&(v948_10),&(v950_11))
        };
        drop(v948_10);
        let v948_13: Space = unite(&(v948_8),&(v948_12));
        v947_7.join_into((v948_13).clone());
      }
      drop(v947_7_cursor);
      compose(&(v946_5),&(v947_7))
    };
    drop(v946_5);
    let v946_9: Space = intersect(&(*CONSTANT_14),&(v946_2));
    drop(v946_2);
    let v946_10: Space = if has_head(&(v946_9)) { singleton(&[]) } else { Space::new() };
    drop(v946_9);
    let v946_11: Space = compose(&(v946_10),&(v945_9_tail));
    drop(v946_10);
    let v951_6: Path = concat_path(&(*p0),&(v945_9_head));
    let v946_12: Space = wrap(&(v946_11),&(v951_6));
    drop(v946_11);
    let v946_13: Space = wrap(&(v946_12),&(*p1));
    drop(v946_12);
    let v946_14: Space = unite(&(v946_8),&(v946_13));
    drop(v946_13);
    v945_9.join_into((v946_14).clone());
  }
  drop(v945_9_cursor);
  (v945_9).clone()
}

fn routine_106(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v952_12 = Space::new();
  let mut v952_12_cursor = (*s0).read_zipper();
  for v952_12_byte in v952_12_cursor.child_mask().iter() {
    v952_12_cursor.descend_to_byte(v952_12_byte);
    let v952_12_tail = v952_12_cursor.make_map();
    v952_12_cursor.ascend(1);
    let v952_12_head = Path::from_slice(&[v952_12_byte]);
    let v953_2: Space = singleton(&(v952_12_head));
    let v953_3: Space = intersect(&(*CONSTANT_14),&(v953_2));
    let v953_4: Space = if has_head(&(v953_3)) { singleton(&[]) } else { Space::new() };
    drop(v953_3);
    let v953_5: Space = subtract(&(*CONSTANT_0),&(v953_4));
    drop(v953_4);
    let v953_8: Space = if (v953_5).is_empty() { Space::new() } else {
      let v954_6: Path = concat_path(&(*p0),&(v952_12_head));
      let mut v954_7 = Space::new();
      let mut v954_7_cursor = (v952_12_tail).read_zipper();
      for v954_7_byte in v954_7_cursor.child_mask().iter() {
        v954_7_cursor.descend_to_byte(v954_7_byte);
        let v954_7_tail = v954_7_cursor.make_map();
        v954_7_cursor.ascend(1);
        let v954_7_head = Path::from_slice(&[v954_7_byte]);
        let v955_2: Space = singleton(&(v954_7_head));
        let v955_3: Space = intersect(&(*CONSTANT_14),&(v955_2));
        let v955_4: Space = if has_head(&(v955_3)) { singleton(&[]) } else { Space::new() };
        drop(v955_3);
        let v955_5: Space = subtract(&(*CONSTANT_0),&(v955_4));
        drop(v955_4);
        let v955_8: Space = if (v955_5).is_empty() { Space::new() } else {
          let v956_6: Path = concat_path(&(v954_6),&(v954_7_head));
          let v956_7: Space = routine_136(c, &(v956_6), &(*p1), &(v954_7_tail));
          compose(&(v955_5),&(v956_7))
        };
        drop(v955_5);
        let v955_9: Space = intersect(&(*CONSTANT_14),&(v955_2));
        drop(v955_2);
        let v955_10: Space = if has_head(&(v955_9)) { singleton(&[]) } else { Space::new() };
        drop(v955_9);
        let v955_12: Space = if (v955_10).is_empty() { Space::new() } else {
          let v957_6: Path = concat_path(&(v954_6),&(v954_7_head));
          let v957_11: Space = routine_137(c, &(v957_6), &(*p1), &(v954_7_tail));
          drop(v957_6);
          compose(&(v955_10),&(v957_11))
        };
        drop(v955_10);
        let v955_13: Space = unite(&(v955_8),&(v955_12));
        v954_7.join_into((v955_13).clone());
      }
      drop(v954_7_cursor);
      compose(&(v953_5),&(v954_7))
    };
    drop(v953_5);
    let v953_9: Space = intersect(&(*CONSTANT_14),&(v953_2));
    drop(v953_2);
    let v953_10: Space = if has_head(&(v953_9)) { singleton(&[]) } else { Space::new() };
    drop(v953_9);
    let v953_12: Space = if (v953_10).is_empty() { Space::new() } else {
      let v958_6: Path = concat_path(&(*p0),&(v952_12_head));
      let mut v958_11 = Space::new();
      let mut v958_11_cursor = (v952_12_tail).read_zipper();
      for v958_11_byte in v958_11_cursor.child_mask().iter() {
        v958_11_cursor.descend_to_byte(v958_11_byte);
        let v958_11_tail = v958_11_cursor.make_map();
        v958_11_cursor.ascend(1);
        let v958_11_head = Path::from_slice(&[v958_11_byte]);
        let v959_2: Space = singleton(&(v958_11_head));
        let v959_3: Space = intersect(&(*CONSTANT_14),&(v959_2));
        let v959_4: Space = if has_head(&(v959_3)) { singleton(&[]) } else { Space::new() };
        drop(v959_3);
        let v959_5: Space = subtract(&(*CONSTANT_0),&(v959_4));
        drop(v959_4);
        let v959_8: Space = if (v959_5).is_empty() { Space::new() } else {
          let v960_6: Path = concat_path(&(v958_6),&(v958_11_head));
          let v960_7: Space = routine_136(c, &(v960_6), &(*p1), &(v958_11_tail));
          compose(&(v959_5),&(v960_7))
        };
        drop(v959_5);
        let v959_9: Space = intersect(&(*CONSTANT_14),&(v959_2));
        drop(v959_2);
        let v959_10: Space = if has_head(&(v959_9)) { singleton(&[]) } else { Space::new() };
        drop(v959_9);
        let v959_12: Space = if (v959_10).is_empty() { Space::new() } else {
          let v961_6: Path = concat_path(&(v958_6),&(v958_11_head));
          let v961_11: Space = routine_33(c, &(v961_6), &(*p1), &(v958_11_tail));
          drop(v961_6);
          compose(&(v959_10),&(v961_11))
        };
        drop(v959_10);
        let v959_13: Space = unite(&(v959_8),&(v959_12));
        v958_11.join_into((v959_13).clone());
      }
      drop(v958_11_cursor);
      drop(v958_6);
      compose(&(v953_10),&(v958_11))
    };
    drop(v953_10);
    let v953_13: Space = unite(&(v953_8),&(v953_12));
    v952_12.join_into((v953_13).clone());
  }
  drop(v952_12_cursor);
  (v952_12).clone()
}

fn routine_107(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v962_9 = Space::new();
  let mut v962_9_cursor = (*s0).read_zipper();
  for v962_9_byte in v962_9_cursor.child_mask().iter() {
    v962_9_cursor.descend_to_byte(v962_9_byte);
    let v962_9_tail = v962_9_cursor.make_map();
    v962_9_cursor.ascend(1);
    let v962_9_head = Path::from_slice(&[v962_9_byte]);
    let v963_2: Space = singleton(&(v962_9_head));
    let v963_3: Space = intersect(&(*CONSTANT_14),&(v963_2));
    let v963_4: Space = if has_head(&(v963_3)) { singleton(&[]) } else { Space::new() };
    drop(v963_3);
    let v963_5: Space = subtract(&(*CONSTANT_0),&(v963_4));
    drop(v963_4);
    let v963_8: Space = if (v963_5).is_empty() { Space::new() } else {
      let v964_6: Path = concat_path(&(*p0),&(v962_9_head));
      let mut v964_7 = Space::new();
      let mut v964_7_cursor = (v962_9_tail).read_zipper();
      for v964_7_byte in v964_7_cursor.child_mask().iter() {
        v964_7_cursor.descend_to_byte(v964_7_byte);
        let v964_7_tail = v964_7_cursor.make_map();
        v964_7_cursor.ascend(1);
        let v964_7_head = Path::from_slice(&[v964_7_byte]);
        let v965_2: Space = singleton(&(v964_7_head));
        let v965_3: Space = intersect(&(*CONSTANT_14),&(v965_2));
        let v965_4: Space = if has_head(&(v965_3)) { singleton(&[]) } else { Space::new() };
        drop(v965_3);
        let v965_5: Space = subtract(&(*CONSTANT_0),&(v965_4));
        drop(v965_4);
        let v965_8: Space = if (v965_5).is_empty() { Space::new() } else {
          let v966_6: Path = concat_path(&(v964_6),&(v964_7_head));
          let v966_7: Space = routine_136(c, &(v966_6), &(*p1), &(v964_7_tail));
          compose(&(v965_5),&(v966_7))
        };
        drop(v965_5);
        let v965_9: Space = intersect(&(*CONSTANT_14),&(v965_2));
        drop(v965_2);
        let v965_10: Space = if has_head(&(v965_9)) { singleton(&[]) } else { Space::new() };
        drop(v965_9);
        let v965_12: Space = if (v965_10).is_empty() { Space::new() } else {
          let v967_6: Path = concat_path(&(v964_6),&(v964_7_head));
          let v967_11: Space = routine_137(c, &(v967_6), &(*p1), &(v964_7_tail));
          drop(v967_6);
          compose(&(v965_10),&(v967_11))
        };
        drop(v965_10);
        let v965_13: Space = unite(&(v965_8),&(v965_12));
        v964_7.join_into((v965_13).clone());
      }
      drop(v964_7_cursor);
      compose(&(v963_5),&(v964_7))
    };
    drop(v963_5);
    let v963_9: Space = intersect(&(*CONSTANT_14),&(v963_2));
    drop(v963_2);
    let v963_10: Space = if has_head(&(v963_9)) { singleton(&[]) } else { Space::new() };
    drop(v963_9);
    let v963_11: Space = compose(&(v963_10),&(v962_9_tail));
    drop(v963_10);
    let v968_6: Path = concat_path(&(*p0),&(v962_9_head));
    let v963_12: Space = wrap(&(v963_11),&(v968_6));
    drop(v963_11);
    let v963_13: Space = wrap(&(v963_12),&(*p1));
    drop(v963_12);
    let v963_14: Space = unite(&(v963_8),&(v963_13));
    drop(v963_13);
    v962_9.join_into((v963_14).clone());
  }
  drop(v962_9_cursor);
  (v962_9).clone()
}

fn routine_108(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v969_7 = Space::new();
  let mut v969_7_cursor = (*s0).read_zipper();
  for v969_7_byte in v969_7_cursor.child_mask().iter() {
    v969_7_cursor.descend_to_byte(v969_7_byte);
    let v969_7_tail = v969_7_cursor.make_map();
    v969_7_cursor.ascend(1);
    let v969_7_head = Path::from_slice(&[v969_7_byte]);
    let v970_2: Space = singleton(&(v969_7_head));
    let v970_3: Space = intersect(&(*CONSTANT_14),&(v970_2));
    let v970_4: Space = if has_head(&(v970_3)) { singleton(&[]) } else { Space::new() };
    drop(v970_3);
    let v970_5: Space = subtract(&(*CONSTANT_0),&(v970_4));
    drop(v970_4);
    let mut v970_6 = Space::new();
    let mut v970_6_cursor = (v969_7_tail).read_zipper();
    for v970_6_byte in v970_6_cursor.child_mask().iter() {
      v970_6_cursor.descend_to_byte(v970_6_byte);
      let v970_6_tail = v970_6_cursor.make_map();
      v970_6_cursor.ascend(1);
      let v970_6_head = Path::from_slice(&[v970_6_byte]);
      let v971_2: Space = Space::new();
      v970_6.join_into((v971_2).clone());
    }
    drop(v970_6_cursor);
    let v970_7: Space = compose(&(v970_5),&(v970_6));
    drop(v970_5);
    drop(v970_6);
    let v970_8: Space = intersect(&(*CONSTANT_14),&(v970_2));
    drop(v970_2);
    let v970_9: Space = if has_head(&(v970_8)) { singleton(&[]) } else { Space::new() };
    drop(v970_8);
    let v970_12: Space = if (v970_9).is_empty() { Space::new() } else {
      let v972_10: Path = concat_path(&(*p0),&(v969_7_head));
      let mut v972_11 = Space::new();
      let mut v972_11_cursor = (v969_7_tail).read_zipper();
      for v972_11_byte in v972_11_cursor.child_mask().iter() {
        v972_11_cursor.descend_to_byte(v972_11_byte);
        let v972_11_tail = v972_11_cursor.make_map();
        v972_11_cursor.ascend(1);
        let v972_11_head = Path::from_slice(&[v972_11_byte]);
        let v973_2: Space = singleton(&(v972_11_head));
        let v973_3: Space = intersect(&(*CONSTANT_14),&(v973_2));
        drop(v973_2);
        let v973_4: Space = if has_head(&(v973_3)) { singleton(&[]) } else { Space::new() };
        drop(v973_3);
        let v973_7: Space = if (v973_4).is_empty() { Space::new() } else {
          let v974_5: Path = concat_path(&(v972_10),&(v972_11_head));
          let v974_6: Space = routine_33(c, &(v974_5), &(*p1), &(v972_11_tail));
          drop(v974_5);
          compose(&(v973_4),&(v974_6))
        };
        drop(v973_4);
        v972_11.join_into((v973_7).clone());
      }
      drop(v972_11_cursor);
      drop(v972_10);
      compose(&(v970_9),&(v972_11))
    };
    drop(v970_9);
    let v970_13: Space = unite(&(v970_7),&(v970_12));
    drop(v970_7);
    v969_7.join_into((v970_13).clone());
  }
  drop(v969_7_cursor);
  (v969_7).clone()
}

fn routine_109(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v975_6 = Space::new();
  let mut v975_6_cursor = (*s0).read_zipper();
  for v975_6_byte in v975_6_cursor.child_mask().iter() {
    v975_6_cursor.descend_to_byte(v975_6_byte);
    let v975_6_tail = v975_6_cursor.make_map();
    v975_6_cursor.ascend(1);
    let v975_6_head = Path::from_slice(&[v975_6_byte]);
    let v976_2: Space = singleton(&(v975_6_head));
    let v976_3: Space = intersect(&(*CONSTANT_14),&(v976_2));
    let v976_4: Space = if has_head(&(v976_3)) { singleton(&[]) } else { Space::new() };
    drop(v976_3);
    let v976_5: Space = subtract(&(*CONSTANT_0),&(v976_4));
    drop(v976_4);
    let mut v976_6 = Space::new();
    let mut v976_6_cursor = (v975_6_tail).read_zipper();
    for v976_6_byte in v976_6_cursor.child_mask().iter() {
      v976_6_cursor.descend_to_byte(v976_6_byte);
      let v976_6_tail = v976_6_cursor.make_map();
      v976_6_cursor.ascend(1);
      let v976_6_head = Path::from_slice(&[v976_6_byte]);
      let v977_2: Space = Space::new();
      v976_6.join_into((v977_2).clone());
    }
    drop(v976_6_cursor);
    let v976_7: Space = compose(&(v976_5),&(v976_6));
    drop(v976_5);
    drop(v976_6);
    let v976_8: Space = intersect(&(*CONSTANT_14),&(v976_2));
    drop(v976_2);
    let v976_9: Space = if has_head(&(v976_8)) { singleton(&[]) } else { Space::new() };
    drop(v976_8);
    let v976_10: Space = compose(&(v976_9),&(v975_6_tail));
    drop(v976_9);
    let v976_11: Path = concat_path(&(*p0),&(v975_6_head));
    let v976_12: Space = wrap(&(v976_10),&(v976_11));
    drop(v976_10);
    drop(v976_11);
    let v976_13: Space = wrap(&(v976_12),&(*p1));
    drop(v976_12);
    let v976_14: Space = unite(&(v976_7),&(v976_13));
    drop(v976_7);
    drop(v976_13);
    v975_6.join_into((v976_14).clone());
  }
  drop(v975_6_cursor);
  (v975_6).clone()
}

fn routine_110(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v978_13 = Space::new();
  let mut v978_13_cursor = (*s0).read_zipper();
  for v978_13_byte in v978_13_cursor.child_mask().iter() {
    v978_13_cursor.descend_to_byte(v978_13_byte);
    let v978_13_tail = v978_13_cursor.make_map();
    v978_13_cursor.ascend(1);
    let v978_13_head = Path::from_slice(&[v978_13_byte]);
    let v979_2: Space = singleton(&(v978_13_head));
    let v979_3: Space = intersect(&(*CONSTANT_14),&(v979_2));
    let v979_4: Space = if has_head(&(v979_3)) { singleton(&[]) } else { Space::new() };
    drop(v979_3);
    let v979_5: Space = subtract(&(*CONSTANT_0),&(v979_4));
    drop(v979_4);
    let v979_8: Space = if (v979_5).is_empty() { Space::new() } else {
      let v980_6: Path = concat_path(&(*p0),&(v978_13_head));
      let mut v980_7 = Space::new();
      let mut v980_7_cursor = (v978_13_tail).read_zipper();
      for v980_7_byte in v980_7_cursor.child_mask().iter() {
        v980_7_cursor.descend_to_byte(v980_7_byte);
        let v980_7_tail = v980_7_cursor.make_map();
        v980_7_cursor.ascend(1);
        let v980_7_head = Path::from_slice(&[v980_7_byte]);
        let v981_2: Space = singleton(&(v980_7_head));
        let v981_3: Space = intersect(&(*CONSTANT_14),&(v981_2));
        let v981_4: Space = if has_head(&(v981_3)) { singleton(&[]) } else { Space::new() };
        drop(v981_3);
        let v981_5: Space = subtract(&(*CONSTANT_0),&(v981_4));
        drop(v981_4);
        let v981_8: Space = if (v981_5).is_empty() { Space::new() } else {
          let v982_6: Path = concat_path(&(v980_6),&(v980_7_head));
          let v982_7: Space = routine_138(c, &(v982_6), &(*p1), &(v980_7_tail), &(*s1));
          compose(&(v981_5),&(v982_7))
        };
        drop(v981_5);
        let v981_9: Space = intersect(&(*CONSTANT_14),&(v981_2));
        drop(v981_2);
        let v981_10: Space = if has_head(&(v981_9)) { singleton(&[]) } else { Space::new() };
        drop(v981_9);
        let v981_12: Space = if (v981_10).is_empty() { Space::new() } else {
          let v983_6: Path = concat_path(&(v980_6),&(v980_7_head));
          let v983_11: Space = routine_139(c, &(v983_6), &(*p1), &(v980_7_tail), &(*s1));
          drop(v983_6);
          compose(&(v981_10),&(v983_11))
        };
        drop(v981_10);
        let v981_13: Space = unite(&(v981_8),&(v981_12));
        v980_7.join_into((v981_13).clone());
      }
      drop(v980_7_cursor);
      compose(&(v979_5),&(v980_7))
    };
    drop(v979_5);
    let v979_9: Space = intersect(&(*CONSTANT_14),&(v979_2));
    drop(v979_2);
    let v979_10: Space = if has_head(&(v979_9)) { singleton(&[]) } else { Space::new() };
    drop(v979_9);
    let v979_12: Space = if (v979_10).is_empty() { Space::new() } else {
      let v984_6: Path = concat_path(&(*p0),&(v978_13_head));
      let mut v984_11 = Space::new();
      let mut v984_11_cursor = (v978_13_tail).read_zipper();
      for v984_11_byte in v984_11_cursor.child_mask().iter() {
        v984_11_cursor.descend_to_byte(v984_11_byte);
        let v984_11_tail = v984_11_cursor.make_map();
        v984_11_cursor.ascend(1);
        let v984_11_head = Path::from_slice(&[v984_11_byte]);
        let v985_2: Space = singleton(&(v984_11_head));
        let v985_3: Space = intersect(&(*CONSTANT_14),&(v985_2));
        let v985_4: Space = if has_head(&(v985_3)) { singleton(&[]) } else { Space::new() };
        drop(v985_3);
        let v985_5: Space = subtract(&(*CONSTANT_0),&(v985_4));
        drop(v985_4);
        let v985_8: Space = if (v985_5).is_empty() { Space::new() } else {
          let v986_6: Path = concat_path(&(v984_6),&(v984_11_head));
          let v986_7: Space = routine_138(c, &(v986_6), &(*p1), &(v984_11_tail), &(*s1));
          compose(&(v985_5),&(v986_7))
        };
        drop(v985_5);
        let v985_9: Space = intersect(&(*CONSTANT_14),&(v985_2));
        drop(v985_2);
        let v985_10: Space = if has_head(&(v985_9)) { singleton(&[]) } else { Space::new() };
        drop(v985_9);
        let v985_12: Space = if (v985_10).is_empty() { Space::new() } else {
          let v987_6: Path = concat_path(&(v984_6),&(v984_11_head));
          let v987_11: Space = routine_40(c, &(v987_6), &(*p1), &(v984_11_tail), &(*s1));
          drop(v987_6);
          compose(&(v985_10),&(v987_11))
        };
        drop(v985_10);
        let v985_13: Space = unite(&(v985_8),&(v985_12));
        v984_11.join_into((v985_13).clone());
      }
      drop(v984_11_cursor);
      drop(v984_6);
      compose(&(v979_10),&(v984_11))
    };
    drop(v979_10);
    let v979_13: Space = unite(&(v979_8),&(v979_12));
    v978_13.join_into((v979_13).clone());
  }
  drop(v978_13_cursor);
  (v978_13).clone()
}

fn routine_111(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v988_8: Space = unwrap(&(*s1),&(*CONSTANT_9));
  let v988_10: Space = unwrap(&(v988_8),&(*CONSTANT_10));
  drop(v988_8);
  let v988_11: Space = unwrap(&(v988_10),&(*p0));
  drop(v988_10);
  let mut v988_18 = Space::new();
  let mut v988_18_cursor = (*s0).read_zipper();
  for v988_18_byte in v988_18_cursor.child_mask().iter() {
    v988_18_cursor.descend_to_byte(v988_18_byte);
    let v988_18_tail = v988_18_cursor.make_map();
    v988_18_cursor.ascend(1);
    let v988_18_head = Path::from_slice(&[v988_18_byte]);
    let v989_2: Space = singleton(&(v988_18_head));
    let v989_3: Space = intersect(&(*CONSTANT_14),&(v989_2));
    let v989_4: Space = if has_head(&(v989_3)) { singleton(&[]) } else { Space::new() };
    drop(v989_3);
    let v989_5: Space = subtract(&(*CONSTANT_0),&(v989_4));
    drop(v989_4);
    let v989_8: Space = if (v989_5).is_empty() { Space::new() } else {
      let v990_6: Path = concat_path(&(*p0),&(v988_18_head));
      let mut v990_7 = Space::new();
      let mut v990_7_cursor = (v988_18_tail).read_zipper();
      for v990_7_byte in v990_7_cursor.child_mask().iter() {
        v990_7_cursor.descend_to_byte(v990_7_byte);
        let v990_7_tail = v990_7_cursor.make_map();
        v990_7_cursor.ascend(1);
        let v990_7_head = Path::from_slice(&[v990_7_byte]);
        let v991_2: Space = singleton(&(v990_7_head));
        let v991_3: Space = intersect(&(*CONSTANT_14),&(v991_2));
        let v991_4: Space = if has_head(&(v991_3)) { singleton(&[]) } else { Space::new() };
        drop(v991_3);
        let v991_5: Space = subtract(&(*CONSTANT_0),&(v991_4));
        drop(v991_4);
        let v991_8: Space = if (v991_5).is_empty() { Space::new() } else {
          let v992_6: Path = concat_path(&(v990_6),&(v990_7_head));
          let v992_7: Space = routine_138(c, &(v992_6), &(*p1), &(v990_7_tail), &(*s1));
          compose(&(v991_5),&(v992_7))
        };
        drop(v991_5);
        let v991_9: Space = intersect(&(*CONSTANT_14),&(v991_2));
        drop(v991_2);
        let v991_10: Space = if has_head(&(v991_9)) { singleton(&[]) } else { Space::new() };
        drop(v991_9);
        let v991_12: Space = if (v991_10).is_empty() { Space::new() } else {
          let v993_6: Path = concat_path(&(v990_6),&(v990_7_head));
          let v993_11: Space = routine_139(c, &(v993_6), &(*p1), &(v990_7_tail), &(*s1));
          drop(v993_6);
          compose(&(v991_10),&(v993_11))
        };
        drop(v991_10);
        let v991_13: Space = unite(&(v991_8),&(v991_12));
        v990_7.join_into((v991_13).clone());
      }
      drop(v990_7_cursor);
      drop(v990_6);
      compose(&(v989_5),&(v990_7))
    };
    drop(v989_5);
    let v989_9: Space = intersect(&(*CONSTANT_14),&(v989_2));
    drop(v989_2);
    let v989_10: Space = if has_head(&(v989_9)) { singleton(&[]) } else { Space::new() };
    drop(v989_9);
    let v989_13: Space = if (v989_10).is_empty() { Space::new() } else {
      let v994_11: Space = unwrap(&(v988_11),&(v988_18_head));
      let mut v994_12 = Space::new();
      let mut v994_12_cursor = (v994_11).read_zipper();
      for v994_12_byte in v994_12_cursor.child_mask().iter() {
        v994_12_cursor.descend_to_byte(v994_12_byte);
        let v994_12_tail = v994_12_cursor.make_map();
        v994_12_cursor.ascend(1);
        let v994_12_head = Path::from_slice(&[v994_12_byte]);
        let v995_2: Space = singleton(&(v994_12_head));
        let v995_3: Space = intersect(&(*CONSTANT_14),&(v995_2));
        let v995_4: Space = if has_head(&(v995_3)) { singleton(&[]) } else { Space::new() };
        drop(v995_3);
        let v995_5: Space = subtract(&(*CONSTANT_0),&(v995_4));
        drop(v995_4);
        let v995_7: Space = if (v995_5).is_empty() { Space::new() } else {
          let v996_6: Space = routine_76(c, &(v994_12_head), &(*p1), &(v994_12_tail));
          compose(&(v995_5),&(v996_6))
        };
        drop(v995_5);
        let v995_8: Space = intersect(&(*CONSTANT_14),&(v995_2));
        drop(v995_2);
        let v995_9: Space = if has_head(&(v995_8)) { singleton(&[]) } else { Space::new() };
        drop(v995_8);
        let v995_11: Space = if (v995_9).is_empty() { Space::new() } else {
          let v997_10: Space = routine_77(c, &(v994_12_head), &(*p1), &(v994_12_tail));
          compose(&(v995_9),&(v997_10))
        };
        drop(v995_9);
        let v995_12: Space = unite(&(v995_7),&(v995_11));
        v994_12.join_into((v995_12).clone());
      }
      drop(v994_12_cursor);
      drop(v994_11);
      compose(&(v989_10),&(v994_12))
    };
    drop(v989_10);
    let v989_14: Space = unite(&(v989_8),&(v989_13));
    v988_18.join_into((v989_14).clone());
  }
  drop(v988_18_cursor);
  drop(v988_11);
  (v988_18).clone()
}

fn routine_112(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v998_12 = Space::new();
  let mut v998_12_cursor = (*s0).read_zipper();
  for v998_12_byte in v998_12_cursor.child_mask().iter() {
    v998_12_cursor.descend_to_byte(v998_12_byte);
    let v998_12_tail = v998_12_cursor.make_map();
    v998_12_cursor.ascend(1);
    let v998_12_head = Path::from_slice(&[v998_12_byte]);
    let v999_2: Space = singleton(&(v998_12_head));
    let v999_3: Space = intersect(&(*CONSTANT_14),&(v999_2));
    let v999_4: Space = if has_head(&(v999_3)) { singleton(&[]) } else { Space::new() };
    drop(v999_3);
    let v999_5: Space = subtract(&(*CONSTANT_0),&(v999_4));
    drop(v999_4);
    let v999_8: Space = if (v999_5).is_empty() { Space::new() } else {
      let v1000_6: Path = concat_path(&(*p0),&(v998_12_head));
      let mut v1000_7 = Space::new();
      let mut v1000_7_cursor = (v998_12_tail).read_zipper();
      for v1000_7_byte in v1000_7_cursor.child_mask().iter() {
        v1000_7_cursor.descend_to_byte(v1000_7_byte);
        let v1000_7_tail = v1000_7_cursor.make_map();
        v1000_7_cursor.ascend(1);
        let v1000_7_head = Path::from_slice(&[v1000_7_byte]);
        let v1001_2: Space = singleton(&(v1000_7_head));
        let v1001_3: Space = intersect(&(*CONSTANT_14),&(v1001_2));
        let v1001_4: Space = if has_head(&(v1001_3)) { singleton(&[]) } else { Space::new() };
        drop(v1001_3);
        let v1001_5: Space = subtract(&(*CONSTANT_0),&(v1001_4));
        drop(v1001_4);
        let v1001_8: Space = if (v1001_5).is_empty() { Space::new() } else {
          let v1002_6: Path = concat_path(&(v1000_6),&(v1000_7_head));
          let v1002_7: Space = routine_140(c, &(v1002_6), &(*p1), &(v1000_7_tail));
          compose(&(v1001_5),&(v1002_7))
        };
        drop(v1001_5);
        let v1001_9: Space = intersect(&(*CONSTANT_14),&(v1001_2));
        drop(v1001_2);
        let v1001_10: Space = if has_head(&(v1001_9)) { singleton(&[]) } else { Space::new() };
        drop(v1001_9);
        let v1001_12: Space = if (v1001_10).is_empty() { Space::new() } else {
          let v1003_6: Path = concat_path(&(v1000_6),&(v1000_7_head));
          let v1003_11: Space = routine_141(c, &(v1003_6), &(*p1), &(v1000_7_tail));
          drop(v1003_6);
          compose(&(v1001_10),&(v1003_11))
        };
        drop(v1001_10);
        let v1001_13: Space = unite(&(v1001_8),&(v1001_12));
        v1000_7.join_into((v1001_13).clone());
      }
      drop(v1000_7_cursor);
      compose(&(v999_5),&(v1000_7))
    };
    drop(v999_5);
    let v999_9: Space = intersect(&(*CONSTANT_14),&(v999_2));
    drop(v999_2);
    let v999_10: Space = if has_head(&(v999_9)) { singleton(&[]) } else { Space::new() };
    drop(v999_9);
    let v999_12: Space = if (v999_10).is_empty() { Space::new() } else {
      let v1004_6: Path = concat_path(&(*p0),&(v998_12_head));
      let mut v1004_11 = Space::new();
      let mut v1004_11_cursor = (v998_12_tail).read_zipper();
      for v1004_11_byte in v1004_11_cursor.child_mask().iter() {
        v1004_11_cursor.descend_to_byte(v1004_11_byte);
        let v1004_11_tail = v1004_11_cursor.make_map();
        v1004_11_cursor.ascend(1);
        let v1004_11_head = Path::from_slice(&[v1004_11_byte]);
        let v1005_2: Space = singleton(&(v1004_11_head));
        let v1005_3: Space = intersect(&(*CONSTANT_14),&(v1005_2));
        let v1005_4: Space = if has_head(&(v1005_3)) { singleton(&[]) } else { Space::new() };
        drop(v1005_3);
        let v1005_5: Space = subtract(&(*CONSTANT_0),&(v1005_4));
        drop(v1005_4);
        let v1005_8: Space = if (v1005_5).is_empty() { Space::new() } else {
          let v1006_6: Path = concat_path(&(v1004_6),&(v1004_11_head));
          let v1006_7: Space = routine_140(c, &(v1006_6), &(*p1), &(v1004_11_tail));
          compose(&(v1005_5),&(v1006_7))
        };
        drop(v1005_5);
        let v1005_9: Space = intersect(&(*CONSTANT_14),&(v1005_2));
        drop(v1005_2);
        let v1005_10: Space = if has_head(&(v1005_9)) { singleton(&[]) } else { Space::new() };
        drop(v1005_9);
        let v1005_12: Space = if (v1005_10).is_empty() { Space::new() } else {
          let v1007_6: Path = concat_path(&(v1004_6),&(v1004_11_head));
          let v1007_11: Space = routine_82(c, &(v1007_6), &(*p1), &(v1004_11_tail));
          drop(v1007_6);
          compose(&(v1005_10),&(v1007_11))
        };
        drop(v1005_10);
        let v1005_13: Space = unite(&(v1005_8),&(v1005_12));
        v1004_11.join_into((v1005_13).clone());
      }
      drop(v1004_11_cursor);
      drop(v1004_6);
      compose(&(v999_10),&(v1004_11))
    };
    drop(v999_10);
    let v999_13: Space = unite(&(v999_8),&(v999_12));
    v998_12.join_into((v999_13).clone());
  }
  drop(v998_12_cursor);
  (v998_12).clone()
}

fn routine_113(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1008_9 = Space::new();
  let mut v1008_9_cursor = (*s0).read_zipper();
  for v1008_9_byte in v1008_9_cursor.child_mask().iter() {
    v1008_9_cursor.descend_to_byte(v1008_9_byte);
    let v1008_9_tail = v1008_9_cursor.make_map();
    v1008_9_cursor.ascend(1);
    let v1008_9_head = Path::from_slice(&[v1008_9_byte]);
    let v1009_2: Space = singleton(&(v1008_9_head));
    let v1009_3: Space = intersect(&(*CONSTANT_14),&(v1009_2));
    let v1009_4: Space = if has_head(&(v1009_3)) { singleton(&[]) } else { Space::new() };
    drop(v1009_3);
    let v1009_5: Space = subtract(&(*CONSTANT_0),&(v1009_4));
    drop(v1009_4);
    let v1009_8: Space = if (v1009_5).is_empty() { Space::new() } else {
      let v1010_6: Path = concat_path(&(*p0),&(v1008_9_head));
      let mut v1010_7 = Space::new();
      let mut v1010_7_cursor = (v1008_9_tail).read_zipper();
      for v1010_7_byte in v1010_7_cursor.child_mask().iter() {
        v1010_7_cursor.descend_to_byte(v1010_7_byte);
        let v1010_7_tail = v1010_7_cursor.make_map();
        v1010_7_cursor.ascend(1);
        let v1010_7_head = Path::from_slice(&[v1010_7_byte]);
        let v1011_2: Space = singleton(&(v1010_7_head));
        let v1011_3: Space = intersect(&(*CONSTANT_14),&(v1011_2));
        let v1011_4: Space = if has_head(&(v1011_3)) { singleton(&[]) } else { Space::new() };
        drop(v1011_3);
        let v1011_5: Space = subtract(&(*CONSTANT_0),&(v1011_4));
        drop(v1011_4);
        let v1011_8: Space = if (v1011_5).is_empty() { Space::new() } else {
          let v1012_6: Path = concat_path(&(v1010_6),&(v1010_7_head));
          let v1012_7: Space = routine_140(c, &(v1012_6), &(*p1), &(v1010_7_tail));
          compose(&(v1011_5),&(v1012_7))
        };
        drop(v1011_5);
        let v1011_9: Space = intersect(&(*CONSTANT_14),&(v1011_2));
        drop(v1011_2);
        let v1011_10: Space = if has_head(&(v1011_9)) { singleton(&[]) } else { Space::new() };
        drop(v1011_9);
        let v1011_12: Space = if (v1011_10).is_empty() { Space::new() } else {
          let v1013_6: Path = concat_path(&(v1010_6),&(v1010_7_head));
          let v1013_11: Space = routine_141(c, &(v1013_6), &(*p1), &(v1010_7_tail));
          drop(v1013_6);
          compose(&(v1011_10),&(v1013_11))
        };
        drop(v1011_10);
        let v1011_13: Space = unite(&(v1011_8),&(v1011_12));
        v1010_7.join_into((v1011_13).clone());
      }
      drop(v1010_7_cursor);
      compose(&(v1009_5),&(v1010_7))
    };
    drop(v1009_5);
    let v1009_9: Space = intersect(&(*CONSTANT_14),&(v1009_2));
    drop(v1009_2);
    let v1009_10: Space = if has_head(&(v1009_9)) { singleton(&[]) } else { Space::new() };
    drop(v1009_9);
    let v1009_11: Space = compose(&(v1009_10),&(v1008_9_tail));
    drop(v1009_10);
    let v1014_6: Path = concat_path(&(*p0),&(v1008_9_head));
    let v1009_12: Space = wrap(&(v1009_11),&(v1014_6));
    drop(v1009_11);
    let v1009_13: Space = wrap(&(v1009_12),&(*p1));
    drop(v1009_12);
    let v1009_14: Space = unite(&(v1009_8),&(v1009_13));
    drop(v1009_13);
    v1008_9.join_into((v1009_14).clone());
  }
  drop(v1008_9_cursor);
  (v1008_9).clone()
}

fn routine_114(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1015_8 = Space::new();
  let mut v1015_8_cursor = (*s0).read_zipper();
  for v1015_8_byte in v1015_8_cursor.child_mask().iter() {
    v1015_8_cursor.descend_to_byte(v1015_8_byte);
    let v1015_8_tail = v1015_8_cursor.make_map();
    v1015_8_cursor.ascend(1);
    let v1015_8_head = Path::from_slice(&[v1015_8_byte]);
    let v1016_2: Space = singleton(&(v1015_8_head));
    let v1016_3: Space = intersect(&(*CONSTANT_14),&(v1016_2));
    let v1016_4: Space = if has_head(&(v1016_3)) { singleton(&[]) } else { Space::new() };
    drop(v1016_3);
    let v1016_5: Space = subtract(&(*CONSTANT_0),&(v1016_4));
    drop(v1016_4);
    let mut v1016_6 = Space::new();
    let mut v1016_6_cursor = (v1015_8_tail).read_zipper();
    for v1016_6_byte in v1016_6_cursor.child_mask().iter() {
      v1016_6_cursor.descend_to_byte(v1016_6_byte);
      let v1016_6_tail = v1016_6_cursor.make_map();
      v1016_6_cursor.ascend(1);
      let v1016_6_head = Path::from_slice(&[v1016_6_byte]);
      let v1017_2: Space = Space::new();
      v1016_6.join_into((v1017_2).clone());
    }
    drop(v1016_6_cursor);
    let v1016_7: Space = compose(&(v1016_5),&(v1016_6));
    drop(v1016_5);
    drop(v1016_6);
    let v1016_8: Space = intersect(&(*CONSTANT_14),&(v1016_2));
    drop(v1016_2);
    let v1016_9: Space = if has_head(&(v1016_8)) { singleton(&[]) } else { Space::new() };
    drop(v1016_8);
    let v1016_12: Space = if (v1016_9).is_empty() { Space::new() } else {
      let v1018_10: Path = concat_path(&(*p0),&(v1015_8_head));
      let mut v1018_11 = Space::new();
      let mut v1018_11_cursor = (v1015_8_tail).read_zipper();
      for v1018_11_byte in v1018_11_cursor.child_mask().iter() {
        v1018_11_cursor.descend_to_byte(v1018_11_byte);
        let v1018_11_tail = v1018_11_cursor.make_map();
        v1018_11_cursor.ascend(1);
        let v1018_11_head = Path::from_slice(&[v1018_11_byte]);
        let v1019_2: Space = singleton(&(v1018_11_head));
        let v1019_3: Space = intersect(&(*CONSTANT_14),&(v1019_2));
        drop(v1019_2);
        let v1019_4: Space = if has_head(&(v1019_3)) { singleton(&[]) } else { Space::new() };
        drop(v1019_3);
        let v1019_7: Space = if (v1019_4).is_empty() { Space::new() } else {
          let v1020_5: Path = concat_path(&(v1018_10),&(v1018_11_head));
          let v1020_6: Space = routine_40(c, &(v1020_5), &(*p1), &(v1018_11_tail), &(*s1));
          drop(v1020_5);
          compose(&(v1019_4),&(v1020_6))
        };
        drop(v1019_4);
        v1018_11.join_into((v1019_7).clone());
      }
      drop(v1018_11_cursor);
      drop(v1018_10);
      compose(&(v1016_9),&(v1018_11))
    };
    drop(v1016_9);
    let v1016_13: Space = unite(&(v1016_7),&(v1016_12));
    drop(v1016_7);
    v1015_8.join_into((v1016_13).clone());
  }
  drop(v1015_8_cursor);
  (v1015_8).clone()
}

fn routine_115(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1021_8: Space = unwrap(&(*s1),&(*CONSTANT_9));
  let v1021_10: Space = unwrap(&(v1021_8),&(*CONSTANT_10));
  drop(v1021_8);
  let v1021_11: Space = unwrap(&(v1021_10),&(*p0));
  drop(v1021_10);
  let mut v1021_15 = Space::new();
  let mut v1021_15_cursor = (*s0).read_zipper();
  for v1021_15_byte in v1021_15_cursor.child_mask().iter() {
    v1021_15_cursor.descend_to_byte(v1021_15_byte);
    let v1021_15_tail = v1021_15_cursor.make_map();
    v1021_15_cursor.ascend(1);
    let v1021_15_head = Path::from_slice(&[v1021_15_byte]);
    let v1022_2: Space = singleton(&(v1021_15_head));
    let v1022_3: Space = intersect(&(*CONSTANT_14),&(v1022_2));
    let v1022_4: Space = if has_head(&(v1022_3)) { singleton(&[]) } else { Space::new() };
    drop(v1022_3);
    let v1022_5: Space = subtract(&(*CONSTANT_0),&(v1022_4));
    drop(v1022_4);
    let mut v1022_6 = Space::new();
    let mut v1022_6_cursor = (v1021_15_tail).read_zipper();
    for v1022_6_byte in v1022_6_cursor.child_mask().iter() {
      v1022_6_cursor.descend_to_byte(v1022_6_byte);
      let v1022_6_tail = v1022_6_cursor.make_map();
      v1022_6_cursor.ascend(1);
      let v1022_6_head = Path::from_slice(&[v1022_6_byte]);
      let v1023_2: Space = Space::new();
      v1022_6.join_into((v1023_2).clone());
    }
    drop(v1022_6_cursor);
    let v1022_7: Space = compose(&(v1022_5),&(v1022_6));
    drop(v1022_5);
    drop(v1022_6);
    let v1022_8: Space = intersect(&(*CONSTANT_14),&(v1022_2));
    drop(v1022_2);
    let v1022_9: Space = if has_head(&(v1022_8)) { singleton(&[]) } else { Space::new() };
    drop(v1022_8);
    let v1022_12: Space = if (v1022_9).is_empty() { Space::new() } else {
      let v1024_10: Space = unwrap(&(v1021_11),&(v1021_15_head));
      let mut v1024_11 = Space::new();
      let mut v1024_11_cursor = (v1024_10).read_zipper();
      for v1024_11_byte in v1024_11_cursor.child_mask().iter() {
        v1024_11_cursor.descend_to_byte(v1024_11_byte);
        let v1024_11_tail = v1024_11_cursor.make_map();
        v1024_11_cursor.ascend(1);
        let v1024_11_head = Path::from_slice(&[v1024_11_byte]);
        let v1025_2: Space = singleton(&(v1024_11_head));
        let v1025_3: Space = intersect(&(*CONSTANT_14),&(v1025_2));
        let v1025_4: Space = if has_head(&(v1025_3)) { singleton(&[]) } else { Space::new() };
        drop(v1025_3);
        let v1025_5: Space = subtract(&(*CONSTANT_0),&(v1025_4));
        drop(v1025_4);
        let v1025_7: Space = if (v1025_5).is_empty() { Space::new() } else {
          let v1026_6: Space = routine_76(c, &(v1024_11_head), &(*p1), &(v1024_11_tail));
          compose(&(v1025_5),&(v1026_6))
        };
        drop(v1025_5);
        let v1025_8: Space = intersect(&(*CONSTANT_14),&(v1025_2));
        drop(v1025_2);
        let v1025_9: Space = if has_head(&(v1025_8)) { singleton(&[]) } else { Space::new() };
        drop(v1025_8);
        let v1025_11: Space = if (v1025_9).is_empty() { Space::new() } else {
          let v1027_10: Space = routine_77(c, &(v1024_11_head), &(*p1), &(v1024_11_tail));
          compose(&(v1025_9),&(v1027_10))
        };
        drop(v1025_9);
        let v1025_12: Space = unite(&(v1025_7),&(v1025_11));
        v1024_11.join_into((v1025_12).clone());
      }
      drop(v1024_11_cursor);
      drop(v1024_10);
      compose(&(v1022_9),&(v1024_11))
    };
    drop(v1022_9);
    let v1022_13: Space = unite(&(v1022_7),&(v1022_12));
    drop(v1022_7);
    v1021_15.join_into((v1022_13).clone());
  }
  drop(v1021_15_cursor);
  drop(v1021_11);
  (v1021_15).clone()
}

fn routine_116(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1028_12 = Space::new();
  let mut v1028_12_cursor = (*s0).read_zipper();
  for v1028_12_byte in v1028_12_cursor.child_mask().iter() {
    v1028_12_cursor.descend_to_byte(v1028_12_byte);
    let v1028_12_tail = v1028_12_cursor.make_map();
    v1028_12_cursor.ascend(1);
    let v1028_12_head = Path::from_slice(&[v1028_12_byte]);
    let v1029_2: Space = singleton(&(v1028_12_head));
    let v1029_3: Space = intersect(&(*CONSTANT_14),&(v1029_2));
    let v1029_4: Space = if has_head(&(v1029_3)) { singleton(&[]) } else { Space::new() };
    drop(v1029_3);
    let v1029_5: Space = subtract(&(*CONSTANT_0),&(v1029_4));
    drop(v1029_4);
    let v1029_8: Space = if (v1029_5).is_empty() { Space::new() } else {
      let v1030_6: Path = concat_path(&(*p0),&(v1028_12_head));
      let mut v1030_7 = Space::new();
      let mut v1030_7_cursor = (v1028_12_tail).read_zipper();
      for v1030_7_byte in v1030_7_cursor.child_mask().iter() {
        v1030_7_cursor.descend_to_byte(v1030_7_byte);
        let v1030_7_tail = v1030_7_cursor.make_map();
        v1030_7_cursor.ascend(1);
        let v1030_7_head = Path::from_slice(&[v1030_7_byte]);
        let v1031_2: Space = singleton(&(v1030_7_head));
        let v1031_3: Space = intersect(&(*CONSTANT_14),&(v1031_2));
        let v1031_4: Space = if has_head(&(v1031_3)) { singleton(&[]) } else { Space::new() };
        drop(v1031_3);
        let v1031_5: Space = subtract(&(*CONSTANT_0),&(v1031_4));
        drop(v1031_4);
        let v1031_8: Space = if (v1031_5).is_empty() { Space::new() } else {
          let v1032_6: Path = concat_path(&(v1030_6),&(v1030_7_head));
          let v1032_7: Space = routine_142(c, &(v1032_6), &(*p1), &(v1030_7_tail));
          compose(&(v1031_5),&(v1032_7))
        };
        drop(v1031_5);
        let v1031_9: Space = intersect(&(*CONSTANT_14),&(v1031_2));
        drop(v1031_2);
        let v1031_10: Space = if has_head(&(v1031_9)) { singleton(&[]) } else { Space::new() };
        drop(v1031_9);
        let v1031_12: Space = if (v1031_10).is_empty() { Space::new() } else {
          let v1033_6: Path = concat_path(&(v1030_6),&(v1030_7_head));
          let v1033_11: Space = routine_143(c, &(v1033_6), &(*p1), &(v1030_7_tail));
          drop(v1033_6);
          compose(&(v1031_10),&(v1033_11))
        };
        drop(v1031_10);
        let v1031_13: Space = unite(&(v1031_8),&(v1031_12));
        v1030_7.join_into((v1031_13).clone());
      }
      drop(v1030_7_cursor);
      compose(&(v1029_5),&(v1030_7))
    };
    drop(v1029_5);
    let v1029_9: Space = intersect(&(*CONSTANT_14),&(v1029_2));
    drop(v1029_2);
    let v1029_10: Space = if has_head(&(v1029_9)) { singleton(&[]) } else { Space::new() };
    drop(v1029_9);
    let v1029_12: Space = if (v1029_10).is_empty() { Space::new() } else {
      let v1034_6: Path = concat_path(&(*p0),&(v1028_12_head));
      let mut v1034_11 = Space::new();
      let mut v1034_11_cursor = (v1028_12_tail).read_zipper();
      for v1034_11_byte in v1034_11_cursor.child_mask().iter() {
        v1034_11_cursor.descend_to_byte(v1034_11_byte);
        let v1034_11_tail = v1034_11_cursor.make_map();
        v1034_11_cursor.ascend(1);
        let v1034_11_head = Path::from_slice(&[v1034_11_byte]);
        let v1035_2: Space = singleton(&(v1034_11_head));
        let v1035_3: Space = intersect(&(*CONSTANT_14),&(v1035_2));
        let v1035_4: Space = if has_head(&(v1035_3)) { singleton(&[]) } else { Space::new() };
        drop(v1035_3);
        let v1035_5: Space = subtract(&(*CONSTANT_0),&(v1035_4));
        drop(v1035_4);
        let v1035_8: Space = if (v1035_5).is_empty() { Space::new() } else {
          let v1036_6: Path = concat_path(&(v1034_6),&(v1034_11_head));
          let v1036_7: Space = routine_142(c, &(v1036_6), &(*p1), &(v1034_11_tail));
          compose(&(v1035_5),&(v1036_7))
        };
        drop(v1035_5);
        let v1035_9: Space = intersect(&(*CONSTANT_14),&(v1035_2));
        drop(v1035_2);
        let v1035_10: Space = if has_head(&(v1035_9)) { singleton(&[]) } else { Space::new() };
        drop(v1035_9);
        let v1035_12: Space = if (v1035_10).is_empty() { Space::new() } else {
          let v1037_6: Path = concat_path(&(v1034_6),&(v1034_11_head));
          let v1037_11: Space = routine_82(c, &(v1037_6), &(*p1), &(v1034_11_tail));
          drop(v1037_6);
          compose(&(v1035_10),&(v1037_11))
        };
        drop(v1035_10);
        let v1035_13: Space = unite(&(v1035_8),&(v1035_12));
        v1034_11.join_into((v1035_13).clone());
      }
      drop(v1034_11_cursor);
      drop(v1034_6);
      compose(&(v1029_10),&(v1034_11))
    };
    drop(v1029_10);
    let v1029_13: Space = unite(&(v1029_8),&(v1029_12));
    v1028_12.join_into((v1029_13).clone());
  }
  drop(v1028_12_cursor);
  (v1028_12).clone()
}

fn routine_117(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1038_9 = Space::new();
  let mut v1038_9_cursor = (*s0).read_zipper();
  for v1038_9_byte in v1038_9_cursor.child_mask().iter() {
    v1038_9_cursor.descend_to_byte(v1038_9_byte);
    let v1038_9_tail = v1038_9_cursor.make_map();
    v1038_9_cursor.ascend(1);
    let v1038_9_head = Path::from_slice(&[v1038_9_byte]);
    let v1039_2: Space = singleton(&(v1038_9_head));
    let v1039_3: Space = intersect(&(*CONSTANT_14),&(v1039_2));
    let v1039_4: Space = if has_head(&(v1039_3)) { singleton(&[]) } else { Space::new() };
    drop(v1039_3);
    let v1039_5: Space = subtract(&(*CONSTANT_0),&(v1039_4));
    drop(v1039_4);
    let v1039_8: Space = if (v1039_5).is_empty() { Space::new() } else {
      let v1040_6: Path = concat_path(&(*p0),&(v1038_9_head));
      let mut v1040_7 = Space::new();
      let mut v1040_7_cursor = (v1038_9_tail).read_zipper();
      for v1040_7_byte in v1040_7_cursor.child_mask().iter() {
        v1040_7_cursor.descend_to_byte(v1040_7_byte);
        let v1040_7_tail = v1040_7_cursor.make_map();
        v1040_7_cursor.ascend(1);
        let v1040_7_head = Path::from_slice(&[v1040_7_byte]);
        let v1041_2: Space = singleton(&(v1040_7_head));
        let v1041_3: Space = intersect(&(*CONSTANT_14),&(v1041_2));
        let v1041_4: Space = if has_head(&(v1041_3)) { singleton(&[]) } else { Space::new() };
        drop(v1041_3);
        let v1041_5: Space = subtract(&(*CONSTANT_0),&(v1041_4));
        drop(v1041_4);
        let v1041_8: Space = if (v1041_5).is_empty() { Space::new() } else {
          let v1042_6: Path = concat_path(&(v1040_6),&(v1040_7_head));
          let v1042_7: Space = routine_142(c, &(v1042_6), &(*p1), &(v1040_7_tail));
          compose(&(v1041_5),&(v1042_7))
        };
        drop(v1041_5);
        let v1041_9: Space = intersect(&(*CONSTANT_14),&(v1041_2));
        drop(v1041_2);
        let v1041_10: Space = if has_head(&(v1041_9)) { singleton(&[]) } else { Space::new() };
        drop(v1041_9);
        let v1041_12: Space = if (v1041_10).is_empty() { Space::new() } else {
          let v1043_6: Path = concat_path(&(v1040_6),&(v1040_7_head));
          let v1043_11: Space = routine_143(c, &(v1043_6), &(*p1), &(v1040_7_tail));
          drop(v1043_6);
          compose(&(v1041_10),&(v1043_11))
        };
        drop(v1041_10);
        let v1041_13: Space = unite(&(v1041_8),&(v1041_12));
        v1040_7.join_into((v1041_13).clone());
      }
      drop(v1040_7_cursor);
      compose(&(v1039_5),&(v1040_7))
    };
    drop(v1039_5);
    let v1039_9: Space = intersect(&(*CONSTANT_14),&(v1039_2));
    drop(v1039_2);
    let v1039_10: Space = if has_head(&(v1039_9)) { singleton(&[]) } else { Space::new() };
    drop(v1039_9);
    let v1039_11: Space = compose(&(v1039_10),&(v1038_9_tail));
    drop(v1039_10);
    let v1044_6: Path = concat_path(&(*p0),&(v1038_9_head));
    let v1039_12: Space = wrap(&(v1039_11),&(v1044_6));
    drop(v1039_11);
    let v1039_13: Space = wrap(&(v1039_12),&(*p1));
    drop(v1039_12);
    let v1039_14: Space = unite(&(v1039_8),&(v1039_13));
    drop(v1039_13);
    v1038_9.join_into((v1039_14).clone());
  }
  drop(v1038_9_cursor);
  (v1038_9).clone()
}

fn routine_118(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1045_13 = Space::new();
  let mut v1045_13_cursor = (*s0).read_zipper();
  for v1045_13_byte in v1045_13_cursor.child_mask().iter() {
    v1045_13_cursor.descend_to_byte(v1045_13_byte);
    let v1045_13_tail = v1045_13_cursor.make_map();
    v1045_13_cursor.ascend(1);
    let v1045_13_head = Path::from_slice(&[v1045_13_byte]);
    let v1046_2: Space = singleton(&(v1045_13_head));
    let v1046_3: Space = intersect(&(*CONSTANT_14),&(v1046_2));
    let v1046_4: Space = if has_head(&(v1046_3)) { singleton(&[]) } else { Space::new() };
    drop(v1046_3);
    let v1046_5: Space = subtract(&(*CONSTANT_0),&(v1046_4));
    drop(v1046_4);
    let v1046_8: Space = if (v1046_5).is_empty() { Space::new() } else {
      let v1047_6: Path = concat_path(&(*p0),&(v1045_13_head));
      let mut v1047_7 = Space::new();
      let mut v1047_7_cursor = (v1045_13_tail).read_zipper();
      for v1047_7_byte in v1047_7_cursor.child_mask().iter() {
        v1047_7_cursor.descend_to_byte(v1047_7_byte);
        let v1047_7_tail = v1047_7_cursor.make_map();
        v1047_7_cursor.ascend(1);
        let v1047_7_head = Path::from_slice(&[v1047_7_byte]);
        let v1048_2: Space = singleton(&(v1047_7_head));
        let v1048_3: Space = intersect(&(*CONSTANT_14),&(v1048_2));
        let v1048_4: Space = if has_head(&(v1048_3)) { singleton(&[]) } else { Space::new() };
        drop(v1048_3);
        let v1048_5: Space = subtract(&(*CONSTANT_0),&(v1048_4));
        drop(v1048_4);
        let v1048_8: Space = if (v1048_5).is_empty() { Space::new() } else {
          let v1049_6: Path = concat_path(&(v1047_6),&(v1047_7_head));
          let v1049_7: Space = routine_144(c, &(v1049_6), &(*p1), &(v1047_7_tail), &(*s1));
          compose(&(v1048_5),&(v1049_7))
        };
        drop(v1048_5);
        let v1048_9: Space = intersect(&(*CONSTANT_14),&(v1048_2));
        drop(v1048_2);
        let v1048_10: Space = if has_head(&(v1048_9)) { singleton(&[]) } else { Space::new() };
        drop(v1048_9);
        let v1048_12: Space = if (v1048_10).is_empty() { Space::new() } else {
          let v1050_6: Path = concat_path(&(v1047_6),&(v1047_7_head));
          let v1050_11: Space = routine_145(c, &(v1050_6), &(*p1), &(v1047_7_tail), &(*s1));
          drop(v1050_6);
          compose(&(v1048_10),&(v1050_11))
        };
        drop(v1048_10);
        let v1048_13: Space = unite(&(v1048_8),&(v1048_12));
        v1047_7.join_into((v1048_13).clone());
      }
      drop(v1047_7_cursor);
      compose(&(v1046_5),&(v1047_7))
    };
    drop(v1046_5);
    let v1046_9: Space = intersect(&(*CONSTANT_14),&(v1046_2));
    drop(v1046_2);
    let v1046_10: Space = if has_head(&(v1046_9)) { singleton(&[]) } else { Space::new() };
    drop(v1046_9);
    let v1046_12: Space = if (v1046_10).is_empty() { Space::new() } else {
      let v1051_6: Path = concat_path(&(*p0),&(v1045_13_head));
      let mut v1051_11 = Space::new();
      let mut v1051_11_cursor = (v1045_13_tail).read_zipper();
      for v1051_11_byte in v1051_11_cursor.child_mask().iter() {
        v1051_11_cursor.descend_to_byte(v1051_11_byte);
        let v1051_11_tail = v1051_11_cursor.make_map();
        v1051_11_cursor.ascend(1);
        let v1051_11_head = Path::from_slice(&[v1051_11_byte]);
        let v1052_2: Space = singleton(&(v1051_11_head));
        let v1052_3: Space = intersect(&(*CONSTANT_14),&(v1052_2));
        let v1052_4: Space = if has_head(&(v1052_3)) { singleton(&[]) } else { Space::new() };
        drop(v1052_3);
        let v1052_5: Space = subtract(&(*CONSTANT_0),&(v1052_4));
        drop(v1052_4);
        let v1052_8: Space = if (v1052_5).is_empty() { Space::new() } else {
          let v1053_6: Path = concat_path(&(v1051_6),&(v1051_11_head));
          let v1053_7: Space = routine_144(c, &(v1053_6), &(*p1), &(v1051_11_tail), &(*s1));
          compose(&(v1052_5),&(v1053_7))
        };
        drop(v1052_5);
        let v1052_9: Space = intersect(&(*CONSTANT_14),&(v1052_2));
        drop(v1052_2);
        let v1052_10: Space = if has_head(&(v1052_9)) { singleton(&[]) } else { Space::new() };
        drop(v1052_9);
        let v1052_12: Space = if (v1052_10).is_empty() { Space::new() } else {
          let v1054_6: Path = concat_path(&(v1051_6),&(v1051_11_head));
          let v1054_11: Space = routine_47(c, &(v1054_6), &(*p1), &(v1051_11_tail), &(*s1));
          drop(v1054_6);
          compose(&(v1052_10),&(v1054_11))
        };
        drop(v1052_10);
        let v1052_13: Space = unite(&(v1052_8),&(v1052_12));
        v1051_11.join_into((v1052_13).clone());
      }
      drop(v1051_11_cursor);
      drop(v1051_6);
      compose(&(v1046_10),&(v1051_11))
    };
    drop(v1046_10);
    let v1046_13: Space = unite(&(v1046_8),&(v1046_12));
    v1045_13.join_into((v1046_13).clone());
  }
  drop(v1045_13_cursor);
  (v1045_13).clone()
}

fn routine_119(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1055_8: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v1055_10: Space = unwrap(&(v1055_8),&(*CONSTANT_10));
  drop(v1055_8);
  let v1055_11: Space = unwrap(&(v1055_10),&(*p0));
  drop(v1055_10);
  let mut v1055_18 = Space::new();
  let mut v1055_18_cursor = (*s0).read_zipper();
  for v1055_18_byte in v1055_18_cursor.child_mask().iter() {
    v1055_18_cursor.descend_to_byte(v1055_18_byte);
    let v1055_18_tail = v1055_18_cursor.make_map();
    v1055_18_cursor.ascend(1);
    let v1055_18_head = Path::from_slice(&[v1055_18_byte]);
    let v1056_2: Space = singleton(&(v1055_18_head));
    let v1056_3: Space = intersect(&(*CONSTANT_14),&(v1056_2));
    let v1056_4: Space = if has_head(&(v1056_3)) { singleton(&[]) } else { Space::new() };
    drop(v1056_3);
    let v1056_5: Space = subtract(&(*CONSTANT_0),&(v1056_4));
    drop(v1056_4);
    let v1056_8: Space = if (v1056_5).is_empty() { Space::new() } else {
      let v1057_6: Path = concat_path(&(*p0),&(v1055_18_head));
      let mut v1057_7 = Space::new();
      let mut v1057_7_cursor = (v1055_18_tail).read_zipper();
      for v1057_7_byte in v1057_7_cursor.child_mask().iter() {
        v1057_7_cursor.descend_to_byte(v1057_7_byte);
        let v1057_7_tail = v1057_7_cursor.make_map();
        v1057_7_cursor.ascend(1);
        let v1057_7_head = Path::from_slice(&[v1057_7_byte]);
        let v1058_2: Space = singleton(&(v1057_7_head));
        let v1058_3: Space = intersect(&(*CONSTANT_14),&(v1058_2));
        let v1058_4: Space = if has_head(&(v1058_3)) { singleton(&[]) } else { Space::new() };
        drop(v1058_3);
        let v1058_5: Space = subtract(&(*CONSTANT_0),&(v1058_4));
        drop(v1058_4);
        let v1058_8: Space = if (v1058_5).is_empty() { Space::new() } else {
          let v1059_6: Path = concat_path(&(v1057_6),&(v1057_7_head));
          let v1059_7: Space = routine_144(c, &(v1059_6), &(*p1), &(v1057_7_tail), &(*s1));
          compose(&(v1058_5),&(v1059_7))
        };
        drop(v1058_5);
        let v1058_9: Space = intersect(&(*CONSTANT_14),&(v1058_2));
        drop(v1058_2);
        let v1058_10: Space = if has_head(&(v1058_9)) { singleton(&[]) } else { Space::new() };
        drop(v1058_9);
        let v1058_12: Space = if (v1058_10).is_empty() { Space::new() } else {
          let v1060_6: Path = concat_path(&(v1057_6),&(v1057_7_head));
          let v1060_11: Space = routine_145(c, &(v1060_6), &(*p1), &(v1057_7_tail), &(*s1));
          drop(v1060_6);
          compose(&(v1058_10),&(v1060_11))
        };
        drop(v1058_10);
        let v1058_13: Space = unite(&(v1058_8),&(v1058_12));
        v1057_7.join_into((v1058_13).clone());
      }
      drop(v1057_7_cursor);
      drop(v1057_6);
      compose(&(v1056_5),&(v1057_7))
    };
    drop(v1056_5);
    let v1056_9: Space = intersect(&(*CONSTANT_14),&(v1056_2));
    drop(v1056_2);
    let v1056_10: Space = if has_head(&(v1056_9)) { singleton(&[]) } else { Space::new() };
    drop(v1056_9);
    let v1056_13: Space = if (v1056_10).is_empty() { Space::new() } else {
      let v1061_11: Space = unwrap(&(v1055_11),&(v1055_18_head));
      let mut v1061_12 = Space::new();
      let mut v1061_12_cursor = (v1061_11).read_zipper();
      for v1061_12_byte in v1061_12_cursor.child_mask().iter() {
        v1061_12_cursor.descend_to_byte(v1061_12_byte);
        let v1061_12_tail = v1061_12_cursor.make_map();
        v1061_12_cursor.ascend(1);
        let v1061_12_head = Path::from_slice(&[v1061_12_byte]);
        let v1062_2: Space = singleton(&(v1061_12_head));
        let v1062_3: Space = intersect(&(*CONSTANT_14),&(v1062_2));
        let v1062_4: Space = if has_head(&(v1062_3)) { singleton(&[]) } else { Space::new() };
        drop(v1062_3);
        let v1062_5: Space = subtract(&(*CONSTANT_0),&(v1062_4));
        drop(v1062_4);
        let v1062_7: Space = if (v1062_5).is_empty() { Space::new() } else {
          let v1063_6: Space = routine_87(c, &(v1061_12_head), &(*p1), &(v1061_12_tail));
          compose(&(v1062_5),&(v1063_6))
        };
        drop(v1062_5);
        let v1062_8: Space = intersect(&(*CONSTANT_14),&(v1062_2));
        drop(v1062_2);
        let v1062_9: Space = if has_head(&(v1062_8)) { singleton(&[]) } else { Space::new() };
        drop(v1062_8);
        let v1062_11: Space = if (v1062_9).is_empty() { Space::new() } else {
          let v1064_10: Space = routine_88(c, &(v1061_12_head), &(*p1), &(v1061_12_tail));
          compose(&(v1062_9),&(v1064_10))
        };
        drop(v1062_9);
        let v1062_12: Space = unite(&(v1062_7),&(v1062_11));
        v1061_12.join_into((v1062_12).clone());
      }
      drop(v1061_12_cursor);
      drop(v1061_11);
      compose(&(v1056_10),&(v1061_12))
    };
    drop(v1056_10);
    let v1056_14: Space = unite(&(v1056_8),&(v1056_13));
    v1055_18.join_into((v1056_14).clone());
  }
  drop(v1055_18_cursor);
  drop(v1055_11);
  (v1055_18).clone()
}

fn routine_120(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1065_12 = Space::new();
  let mut v1065_12_cursor = (*s0).read_zipper();
  for v1065_12_byte in v1065_12_cursor.child_mask().iter() {
    v1065_12_cursor.descend_to_byte(v1065_12_byte);
    let v1065_12_tail = v1065_12_cursor.make_map();
    v1065_12_cursor.ascend(1);
    let v1065_12_head = Path::from_slice(&[v1065_12_byte]);
    let v1066_2: Space = singleton(&(v1065_12_head));
    let v1066_3: Space = intersect(&(*CONSTANT_14),&(v1066_2));
    let v1066_4: Space = if has_head(&(v1066_3)) { singleton(&[]) } else { Space::new() };
    drop(v1066_3);
    let v1066_5: Space = subtract(&(*CONSTANT_0),&(v1066_4));
    drop(v1066_4);
    let v1066_8: Space = if (v1066_5).is_empty() { Space::new() } else {
      let v1067_6: Path = concat_path(&(*p0),&(v1065_12_head));
      let mut v1067_7 = Space::new();
      let mut v1067_7_cursor = (v1065_12_tail).read_zipper();
      for v1067_7_byte in v1067_7_cursor.child_mask().iter() {
        v1067_7_cursor.descend_to_byte(v1067_7_byte);
        let v1067_7_tail = v1067_7_cursor.make_map();
        v1067_7_cursor.ascend(1);
        let v1067_7_head = Path::from_slice(&[v1067_7_byte]);
        let v1068_2: Space = singleton(&(v1067_7_head));
        let v1068_3: Space = intersect(&(*CONSTANT_14),&(v1068_2));
        let v1068_4: Space = if has_head(&(v1068_3)) { singleton(&[]) } else { Space::new() };
        drop(v1068_3);
        let v1068_5: Space = subtract(&(*CONSTANT_0),&(v1068_4));
        drop(v1068_4);
        let v1068_8: Space = if (v1068_5).is_empty() { Space::new() } else {
          let v1069_6: Path = concat_path(&(v1067_6),&(v1067_7_head));
          let v1069_7: Space = routine_146(c, &(v1069_6), &(*p1), &(v1067_7_tail));
          compose(&(v1068_5),&(v1069_7))
        };
        drop(v1068_5);
        let v1068_9: Space = intersect(&(*CONSTANT_14),&(v1068_2));
        drop(v1068_2);
        let v1068_10: Space = if has_head(&(v1068_9)) { singleton(&[]) } else { Space::new() };
        drop(v1068_9);
        let v1068_12: Space = if (v1068_10).is_empty() { Space::new() } else {
          let v1070_6: Path = concat_path(&(v1067_6),&(v1067_7_head));
          let v1070_11: Space = routine_147(c, &(v1070_6), &(*p1), &(v1067_7_tail));
          drop(v1070_6);
          compose(&(v1068_10),&(v1070_11))
        };
        drop(v1068_10);
        let v1068_13: Space = unite(&(v1068_8),&(v1068_12));
        v1067_7.join_into((v1068_13).clone());
      }
      drop(v1067_7_cursor);
      compose(&(v1066_5),&(v1067_7))
    };
    drop(v1066_5);
    let v1066_9: Space = intersect(&(*CONSTANT_14),&(v1066_2));
    drop(v1066_2);
    let v1066_10: Space = if has_head(&(v1066_9)) { singleton(&[]) } else { Space::new() };
    drop(v1066_9);
    let v1066_12: Space = if (v1066_10).is_empty() { Space::new() } else {
      let v1071_6: Path = concat_path(&(*p0),&(v1065_12_head));
      let mut v1071_11 = Space::new();
      let mut v1071_11_cursor = (v1065_12_tail).read_zipper();
      for v1071_11_byte in v1071_11_cursor.child_mask().iter() {
        v1071_11_cursor.descend_to_byte(v1071_11_byte);
        let v1071_11_tail = v1071_11_cursor.make_map();
        v1071_11_cursor.ascend(1);
        let v1071_11_head = Path::from_slice(&[v1071_11_byte]);
        let v1072_2: Space = singleton(&(v1071_11_head));
        let v1072_3: Space = intersect(&(*CONSTANT_14),&(v1072_2));
        let v1072_4: Space = if has_head(&(v1072_3)) { singleton(&[]) } else { Space::new() };
        drop(v1072_3);
        let v1072_5: Space = subtract(&(*CONSTANT_0),&(v1072_4));
        drop(v1072_4);
        let v1072_8: Space = if (v1072_5).is_empty() { Space::new() } else {
          let v1073_6: Path = concat_path(&(v1071_6),&(v1071_11_head));
          let v1073_7: Space = routine_146(c, &(v1073_6), &(*p1), &(v1071_11_tail));
          compose(&(v1072_5),&(v1073_7))
        };
        drop(v1072_5);
        let v1072_9: Space = intersect(&(*CONSTANT_14),&(v1072_2));
        drop(v1072_2);
        let v1072_10: Space = if has_head(&(v1072_9)) { singleton(&[]) } else { Space::new() };
        drop(v1072_9);
        let v1072_12: Space = if (v1072_10).is_empty() { Space::new() } else {
          let v1074_6: Path = concat_path(&(v1071_6),&(v1071_11_head));
          let v1074_11: Space = routine_93(c, &(v1074_6), &(*p1), &(v1071_11_tail));
          drop(v1074_6);
          compose(&(v1072_10),&(v1074_11))
        };
        drop(v1072_10);
        let v1072_13: Space = unite(&(v1072_8),&(v1072_12));
        v1071_11.join_into((v1072_13).clone());
      }
      drop(v1071_11_cursor);
      drop(v1071_6);
      compose(&(v1066_10),&(v1071_11))
    };
    drop(v1066_10);
    let v1066_13: Space = unite(&(v1066_8),&(v1066_12));
    v1065_12.join_into((v1066_13).clone());
  }
  drop(v1065_12_cursor);
  (v1065_12).clone()
}

fn routine_121(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1075_9 = Space::new();
  let mut v1075_9_cursor = (*s0).read_zipper();
  for v1075_9_byte in v1075_9_cursor.child_mask().iter() {
    v1075_9_cursor.descend_to_byte(v1075_9_byte);
    let v1075_9_tail = v1075_9_cursor.make_map();
    v1075_9_cursor.ascend(1);
    let v1075_9_head = Path::from_slice(&[v1075_9_byte]);
    let v1076_2: Space = singleton(&(v1075_9_head));
    let v1076_3: Space = intersect(&(*CONSTANT_14),&(v1076_2));
    let v1076_4: Space = if has_head(&(v1076_3)) { singleton(&[]) } else { Space::new() };
    drop(v1076_3);
    let v1076_5: Space = subtract(&(*CONSTANT_0),&(v1076_4));
    drop(v1076_4);
    let v1076_8: Space = if (v1076_5).is_empty() { Space::new() } else {
      let v1077_6: Path = concat_path(&(*p0),&(v1075_9_head));
      let mut v1077_7 = Space::new();
      let mut v1077_7_cursor = (v1075_9_tail).read_zipper();
      for v1077_7_byte in v1077_7_cursor.child_mask().iter() {
        v1077_7_cursor.descend_to_byte(v1077_7_byte);
        let v1077_7_tail = v1077_7_cursor.make_map();
        v1077_7_cursor.ascend(1);
        let v1077_7_head = Path::from_slice(&[v1077_7_byte]);
        let v1078_2: Space = singleton(&(v1077_7_head));
        let v1078_3: Space = intersect(&(*CONSTANT_14),&(v1078_2));
        let v1078_4: Space = if has_head(&(v1078_3)) { singleton(&[]) } else { Space::new() };
        drop(v1078_3);
        let v1078_5: Space = subtract(&(*CONSTANT_0),&(v1078_4));
        drop(v1078_4);
        let v1078_8: Space = if (v1078_5).is_empty() { Space::new() } else {
          let v1079_6: Path = concat_path(&(v1077_6),&(v1077_7_head));
          let v1079_7: Space = routine_146(c, &(v1079_6), &(*p1), &(v1077_7_tail));
          compose(&(v1078_5),&(v1079_7))
        };
        drop(v1078_5);
        let v1078_9: Space = intersect(&(*CONSTANT_14),&(v1078_2));
        drop(v1078_2);
        let v1078_10: Space = if has_head(&(v1078_9)) { singleton(&[]) } else { Space::new() };
        drop(v1078_9);
        let v1078_12: Space = if (v1078_10).is_empty() { Space::new() } else {
          let v1080_6: Path = concat_path(&(v1077_6),&(v1077_7_head));
          let v1080_11: Space = routine_147(c, &(v1080_6), &(*p1), &(v1077_7_tail));
          drop(v1080_6);
          compose(&(v1078_10),&(v1080_11))
        };
        drop(v1078_10);
        let v1078_13: Space = unite(&(v1078_8),&(v1078_12));
        v1077_7.join_into((v1078_13).clone());
      }
      drop(v1077_7_cursor);
      compose(&(v1076_5),&(v1077_7))
    };
    drop(v1076_5);
    let v1076_9: Space = intersect(&(*CONSTANT_14),&(v1076_2));
    drop(v1076_2);
    let v1076_10: Space = if has_head(&(v1076_9)) { singleton(&[]) } else { Space::new() };
    drop(v1076_9);
    let v1076_11: Space = compose(&(v1076_10),&(v1075_9_tail));
    drop(v1076_10);
    let v1081_6: Path = concat_path(&(*p0),&(v1075_9_head));
    let v1076_12: Space = wrap(&(v1076_11),&(v1081_6));
    drop(v1076_11);
    let v1076_13: Space = wrap(&(v1076_12),&(*p1));
    drop(v1076_12);
    let v1076_14: Space = unite(&(v1076_8),&(v1076_13));
    drop(v1076_13);
    v1075_9.join_into((v1076_14).clone());
  }
  drop(v1075_9_cursor);
  (v1075_9).clone()
}

fn routine_122(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1082_8 = Space::new();
  let mut v1082_8_cursor = (*s0).read_zipper();
  for v1082_8_byte in v1082_8_cursor.child_mask().iter() {
    v1082_8_cursor.descend_to_byte(v1082_8_byte);
    let v1082_8_tail = v1082_8_cursor.make_map();
    v1082_8_cursor.ascend(1);
    let v1082_8_head = Path::from_slice(&[v1082_8_byte]);
    let v1083_2: Space = singleton(&(v1082_8_head));
    let v1083_3: Space = intersect(&(*CONSTANT_14),&(v1083_2));
    let v1083_4: Space = if has_head(&(v1083_3)) { singleton(&[]) } else { Space::new() };
    drop(v1083_3);
    let v1083_5: Space = subtract(&(*CONSTANT_0),&(v1083_4));
    drop(v1083_4);
    let mut v1083_6 = Space::new();
    let mut v1083_6_cursor = (v1082_8_tail).read_zipper();
    for v1083_6_byte in v1083_6_cursor.child_mask().iter() {
      v1083_6_cursor.descend_to_byte(v1083_6_byte);
      let v1083_6_tail = v1083_6_cursor.make_map();
      v1083_6_cursor.ascend(1);
      let v1083_6_head = Path::from_slice(&[v1083_6_byte]);
      let v1084_2: Space = Space::new();
      v1083_6.join_into((v1084_2).clone());
    }
    drop(v1083_6_cursor);
    let v1083_7: Space = compose(&(v1083_5),&(v1083_6));
    drop(v1083_5);
    drop(v1083_6);
    let v1083_8: Space = intersect(&(*CONSTANT_14),&(v1083_2));
    drop(v1083_2);
    let v1083_9: Space = if has_head(&(v1083_8)) { singleton(&[]) } else { Space::new() };
    drop(v1083_8);
    let v1083_12: Space = if (v1083_9).is_empty() { Space::new() } else {
      let v1085_10: Path = concat_path(&(*p0),&(v1082_8_head));
      let mut v1085_11 = Space::new();
      let mut v1085_11_cursor = (v1082_8_tail).read_zipper();
      for v1085_11_byte in v1085_11_cursor.child_mask().iter() {
        v1085_11_cursor.descend_to_byte(v1085_11_byte);
        let v1085_11_tail = v1085_11_cursor.make_map();
        v1085_11_cursor.ascend(1);
        let v1085_11_head = Path::from_slice(&[v1085_11_byte]);
        let v1086_2: Space = singleton(&(v1085_11_head));
        let v1086_3: Space = intersect(&(*CONSTANT_14),&(v1086_2));
        drop(v1086_2);
        let v1086_4: Space = if has_head(&(v1086_3)) { singleton(&[]) } else { Space::new() };
        drop(v1086_3);
        let v1086_7: Space = if (v1086_4).is_empty() { Space::new() } else {
          let v1087_5: Path = concat_path(&(v1085_10),&(v1085_11_head));
          let v1087_6: Space = routine_47(c, &(v1087_5), &(*p1), &(v1085_11_tail), &(*s1));
          drop(v1087_5);
          compose(&(v1086_4),&(v1087_6))
        };
        drop(v1086_4);
        v1085_11.join_into((v1086_7).clone());
      }
      drop(v1085_11_cursor);
      drop(v1085_10);
      compose(&(v1083_9),&(v1085_11))
    };
    drop(v1083_9);
    let v1083_13: Space = unite(&(v1083_7),&(v1083_12));
    drop(v1083_7);
    v1082_8.join_into((v1083_13).clone());
  }
  drop(v1082_8_cursor);
  (v1082_8).clone()
}

fn routine_123(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1088_8: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v1088_10: Space = unwrap(&(v1088_8),&(*CONSTANT_10));
  drop(v1088_8);
  let v1088_11: Space = unwrap(&(v1088_10),&(*p0));
  drop(v1088_10);
  let mut v1088_15 = Space::new();
  let mut v1088_15_cursor = (*s0).read_zipper();
  for v1088_15_byte in v1088_15_cursor.child_mask().iter() {
    v1088_15_cursor.descend_to_byte(v1088_15_byte);
    let v1088_15_tail = v1088_15_cursor.make_map();
    v1088_15_cursor.ascend(1);
    let v1088_15_head = Path::from_slice(&[v1088_15_byte]);
    let v1089_2: Space = singleton(&(v1088_15_head));
    let v1089_3: Space = intersect(&(*CONSTANT_14),&(v1089_2));
    let v1089_4: Space = if has_head(&(v1089_3)) { singleton(&[]) } else { Space::new() };
    drop(v1089_3);
    let v1089_5: Space = subtract(&(*CONSTANT_0),&(v1089_4));
    drop(v1089_4);
    let mut v1089_6 = Space::new();
    let mut v1089_6_cursor = (v1088_15_tail).read_zipper();
    for v1089_6_byte in v1089_6_cursor.child_mask().iter() {
      v1089_6_cursor.descend_to_byte(v1089_6_byte);
      let v1089_6_tail = v1089_6_cursor.make_map();
      v1089_6_cursor.ascend(1);
      let v1089_6_head = Path::from_slice(&[v1089_6_byte]);
      let v1090_2: Space = Space::new();
      v1089_6.join_into((v1090_2).clone());
    }
    drop(v1089_6_cursor);
    let v1089_7: Space = compose(&(v1089_5),&(v1089_6));
    drop(v1089_5);
    drop(v1089_6);
    let v1089_8: Space = intersect(&(*CONSTANT_14),&(v1089_2));
    drop(v1089_2);
    let v1089_9: Space = if has_head(&(v1089_8)) { singleton(&[]) } else { Space::new() };
    drop(v1089_8);
    let v1089_12: Space = if (v1089_9).is_empty() { Space::new() } else {
      let v1091_10: Space = unwrap(&(v1088_11),&(v1088_15_head));
      let mut v1091_11 = Space::new();
      let mut v1091_11_cursor = (v1091_10).read_zipper();
      for v1091_11_byte in v1091_11_cursor.child_mask().iter() {
        v1091_11_cursor.descend_to_byte(v1091_11_byte);
        let v1091_11_tail = v1091_11_cursor.make_map();
        v1091_11_cursor.ascend(1);
        let v1091_11_head = Path::from_slice(&[v1091_11_byte]);
        let v1092_2: Space = singleton(&(v1091_11_head));
        let v1092_3: Space = intersect(&(*CONSTANT_14),&(v1092_2));
        let v1092_4: Space = if has_head(&(v1092_3)) { singleton(&[]) } else { Space::new() };
        drop(v1092_3);
        let v1092_5: Space = subtract(&(*CONSTANT_0),&(v1092_4));
        drop(v1092_4);
        let v1092_7: Space = if (v1092_5).is_empty() { Space::new() } else {
          let v1093_6: Space = routine_87(c, &(v1091_11_head), &(*p1), &(v1091_11_tail));
          compose(&(v1092_5),&(v1093_6))
        };
        drop(v1092_5);
        let v1092_8: Space = intersect(&(*CONSTANT_14),&(v1092_2));
        drop(v1092_2);
        let v1092_9: Space = if has_head(&(v1092_8)) { singleton(&[]) } else { Space::new() };
        drop(v1092_8);
        let v1092_11: Space = if (v1092_9).is_empty() { Space::new() } else {
          let v1094_10: Space = routine_88(c, &(v1091_11_head), &(*p1), &(v1091_11_tail));
          compose(&(v1092_9),&(v1094_10))
        };
        drop(v1092_9);
        let v1092_12: Space = unite(&(v1092_7),&(v1092_11));
        v1091_11.join_into((v1092_12).clone());
      }
      drop(v1091_11_cursor);
      drop(v1091_10);
      compose(&(v1089_9),&(v1091_11))
    };
    drop(v1089_9);
    let v1089_13: Space = unite(&(v1089_7),&(v1089_12));
    drop(v1089_7);
    v1088_15.join_into((v1089_13).clone());
  }
  drop(v1088_15_cursor);
  drop(v1088_11);
  (v1088_15).clone()
}

fn routine_124(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1095_12 = Space::new();
  let mut v1095_12_cursor = (*s0).read_zipper();
  for v1095_12_byte in v1095_12_cursor.child_mask().iter() {
    v1095_12_cursor.descend_to_byte(v1095_12_byte);
    let v1095_12_tail = v1095_12_cursor.make_map();
    v1095_12_cursor.ascend(1);
    let v1095_12_head = Path::from_slice(&[v1095_12_byte]);
    let v1096_2: Space = singleton(&(v1095_12_head));
    let v1096_3: Space = intersect(&(*CONSTANT_14),&(v1096_2));
    let v1096_4: Space = if has_head(&(v1096_3)) { singleton(&[]) } else { Space::new() };
    drop(v1096_3);
    let v1096_5: Space = subtract(&(*CONSTANT_0),&(v1096_4));
    drop(v1096_4);
    let v1096_8: Space = if (v1096_5).is_empty() { Space::new() } else {
      let v1097_6: Path = concat_path(&(*p0),&(v1095_12_head));
      let mut v1097_7 = Space::new();
      let mut v1097_7_cursor = (v1095_12_tail).read_zipper();
      for v1097_7_byte in v1097_7_cursor.child_mask().iter() {
        v1097_7_cursor.descend_to_byte(v1097_7_byte);
        let v1097_7_tail = v1097_7_cursor.make_map();
        v1097_7_cursor.ascend(1);
        let v1097_7_head = Path::from_slice(&[v1097_7_byte]);
        let v1098_2: Space = singleton(&(v1097_7_head));
        let v1098_3: Space = intersect(&(*CONSTANT_14),&(v1098_2));
        let v1098_4: Space = if has_head(&(v1098_3)) { singleton(&[]) } else { Space::new() };
        drop(v1098_3);
        let v1098_5: Space = subtract(&(*CONSTANT_0),&(v1098_4));
        drop(v1098_4);
        let v1098_8: Space = if (v1098_5).is_empty() { Space::new() } else {
          let v1099_6: Path = concat_path(&(v1097_6),&(v1097_7_head));
          let v1099_7: Space = routine_148(c, &(v1099_6), &(*p1), &(v1097_7_tail));
          compose(&(v1098_5),&(v1099_7))
        };
        drop(v1098_5);
        let v1098_9: Space = intersect(&(*CONSTANT_14),&(v1098_2));
        drop(v1098_2);
        let v1098_10: Space = if has_head(&(v1098_9)) { singleton(&[]) } else { Space::new() };
        drop(v1098_9);
        let v1098_12: Space = if (v1098_10).is_empty() { Space::new() } else {
          let v1100_6: Path = concat_path(&(v1097_6),&(v1097_7_head));
          let v1100_11: Space = routine_149(c, &(v1100_6), &(*p1), &(v1097_7_tail));
          drop(v1100_6);
          compose(&(v1098_10),&(v1100_11))
        };
        drop(v1098_10);
        let v1098_13: Space = unite(&(v1098_8),&(v1098_12));
        v1097_7.join_into((v1098_13).clone());
      }
      drop(v1097_7_cursor);
      compose(&(v1096_5),&(v1097_7))
    };
    drop(v1096_5);
    let v1096_9: Space = intersect(&(*CONSTANT_14),&(v1096_2));
    drop(v1096_2);
    let v1096_10: Space = if has_head(&(v1096_9)) { singleton(&[]) } else { Space::new() };
    drop(v1096_9);
    let v1096_12: Space = if (v1096_10).is_empty() { Space::new() } else {
      let v1101_6: Path = concat_path(&(*p0),&(v1095_12_head));
      let mut v1101_11 = Space::new();
      let mut v1101_11_cursor = (v1095_12_tail).read_zipper();
      for v1101_11_byte in v1101_11_cursor.child_mask().iter() {
        v1101_11_cursor.descend_to_byte(v1101_11_byte);
        let v1101_11_tail = v1101_11_cursor.make_map();
        v1101_11_cursor.ascend(1);
        let v1101_11_head = Path::from_slice(&[v1101_11_byte]);
        let v1102_2: Space = singleton(&(v1101_11_head));
        let v1102_3: Space = intersect(&(*CONSTANT_14),&(v1102_2));
        let v1102_4: Space = if has_head(&(v1102_3)) { singleton(&[]) } else { Space::new() };
        drop(v1102_3);
        let v1102_5: Space = subtract(&(*CONSTANT_0),&(v1102_4));
        drop(v1102_4);
        let v1102_8: Space = if (v1102_5).is_empty() { Space::new() } else {
          let v1103_6: Path = concat_path(&(v1101_6),&(v1101_11_head));
          let v1103_7: Space = routine_148(c, &(v1103_6), &(*p1), &(v1101_11_tail));
          compose(&(v1102_5),&(v1103_7))
        };
        drop(v1102_5);
        let v1102_9: Space = intersect(&(*CONSTANT_14),&(v1102_2));
        drop(v1102_2);
        let v1102_10: Space = if has_head(&(v1102_9)) { singleton(&[]) } else { Space::new() };
        drop(v1102_9);
        let v1102_12: Space = if (v1102_10).is_empty() { Space::new() } else {
          let v1104_6: Path = concat_path(&(v1101_6),&(v1101_11_head));
          let v1104_11: Space = routine_93(c, &(v1104_6), &(*p1), &(v1101_11_tail));
          drop(v1104_6);
          compose(&(v1102_10),&(v1104_11))
        };
        drop(v1102_10);
        let v1102_13: Space = unite(&(v1102_8),&(v1102_12));
        v1101_11.join_into((v1102_13).clone());
      }
      drop(v1101_11_cursor);
      drop(v1101_6);
      compose(&(v1096_10),&(v1101_11))
    };
    drop(v1096_10);
    let v1096_13: Space = unite(&(v1096_8),&(v1096_12));
    v1095_12.join_into((v1096_13).clone());
  }
  drop(v1095_12_cursor);
  (v1095_12).clone()
}

fn routine_125(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1105_9 = Space::new();
  let mut v1105_9_cursor = (*s0).read_zipper();
  for v1105_9_byte in v1105_9_cursor.child_mask().iter() {
    v1105_9_cursor.descend_to_byte(v1105_9_byte);
    let v1105_9_tail = v1105_9_cursor.make_map();
    v1105_9_cursor.ascend(1);
    let v1105_9_head = Path::from_slice(&[v1105_9_byte]);
    let v1106_2: Space = singleton(&(v1105_9_head));
    let v1106_3: Space = intersect(&(*CONSTANT_14),&(v1106_2));
    let v1106_4: Space = if has_head(&(v1106_3)) { singleton(&[]) } else { Space::new() };
    drop(v1106_3);
    let v1106_5: Space = subtract(&(*CONSTANT_0),&(v1106_4));
    drop(v1106_4);
    let v1106_8: Space = if (v1106_5).is_empty() { Space::new() } else {
      let v1107_6: Path = concat_path(&(*p0),&(v1105_9_head));
      let mut v1107_7 = Space::new();
      let mut v1107_7_cursor = (v1105_9_tail).read_zipper();
      for v1107_7_byte in v1107_7_cursor.child_mask().iter() {
        v1107_7_cursor.descend_to_byte(v1107_7_byte);
        let v1107_7_tail = v1107_7_cursor.make_map();
        v1107_7_cursor.ascend(1);
        let v1107_7_head = Path::from_slice(&[v1107_7_byte]);
        let v1108_2: Space = singleton(&(v1107_7_head));
        let v1108_3: Space = intersect(&(*CONSTANT_14),&(v1108_2));
        let v1108_4: Space = if has_head(&(v1108_3)) { singleton(&[]) } else { Space::new() };
        drop(v1108_3);
        let v1108_5: Space = subtract(&(*CONSTANT_0),&(v1108_4));
        drop(v1108_4);
        let v1108_8: Space = if (v1108_5).is_empty() { Space::new() } else {
          let v1109_6: Path = concat_path(&(v1107_6),&(v1107_7_head));
          let v1109_7: Space = routine_148(c, &(v1109_6), &(*p1), &(v1107_7_tail));
          compose(&(v1108_5),&(v1109_7))
        };
        drop(v1108_5);
        let v1108_9: Space = intersect(&(*CONSTANT_14),&(v1108_2));
        drop(v1108_2);
        let v1108_10: Space = if has_head(&(v1108_9)) { singleton(&[]) } else { Space::new() };
        drop(v1108_9);
        let v1108_12: Space = if (v1108_10).is_empty() { Space::new() } else {
          let v1110_6: Path = concat_path(&(v1107_6),&(v1107_7_head));
          let v1110_11: Space = routine_149(c, &(v1110_6), &(*p1), &(v1107_7_tail));
          drop(v1110_6);
          compose(&(v1108_10),&(v1110_11))
        };
        drop(v1108_10);
        let v1108_13: Space = unite(&(v1108_8),&(v1108_12));
        v1107_7.join_into((v1108_13).clone());
      }
      drop(v1107_7_cursor);
      compose(&(v1106_5),&(v1107_7))
    };
    drop(v1106_5);
    let v1106_9: Space = intersect(&(*CONSTANT_14),&(v1106_2));
    drop(v1106_2);
    let v1106_10: Space = if has_head(&(v1106_9)) { singleton(&[]) } else { Space::new() };
    drop(v1106_9);
    let v1106_11: Space = compose(&(v1106_10),&(v1105_9_tail));
    drop(v1106_10);
    let v1111_6: Path = concat_path(&(*p0),&(v1105_9_head));
    let v1106_12: Space = wrap(&(v1106_11),&(v1111_6));
    drop(v1106_11);
    let v1106_13: Space = wrap(&(v1106_12),&(*p1));
    drop(v1106_12);
    let v1106_14: Space = unite(&(v1106_8),&(v1106_13));
    drop(v1106_13);
    v1105_9.join_into((v1106_14).clone());
  }
  drop(v1105_9_cursor);
  (v1105_9).clone()
}

fn routine_126(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1112_7 = Space::new();
  let mut v1112_7_cursor = (*s0).read_zipper();
  for v1112_7_byte in v1112_7_cursor.child_mask().iter() {
    v1112_7_cursor.descend_to_byte(v1112_7_byte);
    let v1112_7_tail = v1112_7_cursor.make_map();
    v1112_7_cursor.ascend(1);
    let v1112_7_head = Path::from_slice(&[v1112_7_byte]);
    let v1113_2: Space = singleton(&(v1112_7_head));
    let v1113_3: Space = intersect(&(*CONSTANT_14),&(v1113_2));
    let v1113_4: Space = if has_head(&(v1113_3)) { singleton(&[]) } else { Space::new() };
    drop(v1113_3);
    let v1113_5: Space = subtract(&(*CONSTANT_0),&(v1113_4));
    drop(v1113_4);
    let mut v1113_6 = Space::new();
    let mut v1113_6_cursor = (v1112_7_tail).read_zipper();
    for v1113_6_byte in v1113_6_cursor.child_mask().iter() {
      v1113_6_cursor.descend_to_byte(v1113_6_byte);
      let v1113_6_tail = v1113_6_cursor.make_map();
      v1113_6_cursor.ascend(1);
      let v1113_6_head = Path::from_slice(&[v1113_6_byte]);
      let v1114_2: Space = Space::new();
      v1113_6.join_into((v1114_2).clone());
    }
    drop(v1113_6_cursor);
    let v1113_7: Space = compose(&(v1113_5),&(v1113_6));
    drop(v1113_5);
    drop(v1113_6);
    let v1113_8: Space = intersect(&(*CONSTANT_14),&(v1113_2));
    drop(v1113_2);
    let v1113_9: Space = if has_head(&(v1113_8)) { singleton(&[]) } else { Space::new() };
    drop(v1113_8);
    let v1113_12: Space = if (v1113_9).is_empty() { Space::new() } else {
      let v1115_10: Path = concat_path(&(*p0),&(v1112_7_head));
      let mut v1115_11 = Space::new();
      let mut v1115_11_cursor = (v1112_7_tail).read_zipper();
      for v1115_11_byte in v1115_11_cursor.child_mask().iter() {
        v1115_11_cursor.descend_to_byte(v1115_11_byte);
        let v1115_11_tail = v1115_11_cursor.make_map();
        v1115_11_cursor.ascend(1);
        let v1115_11_head = Path::from_slice(&[v1115_11_byte]);
        let v1116_2: Space = singleton(&(v1115_11_head));
        let v1116_3: Space = intersect(&(*CONSTANT_14),&(v1116_2));
        drop(v1116_2);
        let v1116_4: Space = if has_head(&(v1116_3)) { singleton(&[]) } else { Space::new() };
        drop(v1116_3);
        let v1116_7: Space = if (v1116_4).is_empty() { Space::new() } else {
          let v1117_5: Path = concat_path(&(v1115_10),&(v1115_11_head));
          let v1117_6: Space = routine_52(c, &(v1117_5), &(*p1), &(v1115_11_tail));
          drop(v1117_5);
          compose(&(v1116_4),&(v1117_6))
        };
        drop(v1116_4);
        v1115_11.join_into((v1116_7).clone());
      }
      drop(v1115_11_cursor);
      drop(v1115_10);
      compose(&(v1113_9),&(v1115_11))
    };
    drop(v1113_9);
    let v1113_13: Space = unite(&(v1113_7),&(v1113_12));
    drop(v1113_7);
    v1112_7.join_into((v1113_13).clone());
  }
  drop(v1112_7_cursor);
  (v1112_7).clone()
}

fn routine_127(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1118_7 = Space::new();
  let mut v1118_7_cursor = (*s0).read_zipper();
  for v1118_7_byte in v1118_7_cursor.child_mask().iter() {
    v1118_7_cursor.descend_to_byte(v1118_7_byte);
    let v1118_7_tail = v1118_7_cursor.make_map();
    v1118_7_cursor.ascend(1);
    let v1118_7_head = Path::from_slice(&[v1118_7_byte]);
    let v1119_2: Space = singleton(&(v1118_7_head));
    let v1119_3: Space = intersect(&(*CONSTANT_14),&(v1119_2));
    let v1119_4: Space = if has_head(&(v1119_3)) { singleton(&[]) } else { Space::new() };
    drop(v1119_3);
    let v1119_5: Space = compose(&(v1119_4),&(v1118_7_tail));
    drop(v1119_4);
    let v1119_6: Path = concat_path(&(*p0),&(v1118_7_head));
    let v1119_7: Space = wrap(&(v1119_5),&(v1119_6));
    drop(v1119_5);
    drop(v1119_6);
    let v1119_8: Space = wrap(&(v1119_7),&(*p1));
    drop(v1119_7);
    let v1119_9: Space = wrap(&(v1119_8),&(*CONSTANT_10));
    drop(v1119_8);
    let v1119_10: Space = intersect(&(*CONSTANT_14),&(v1119_2));
    drop(v1119_2);
    let v1119_11: Space = if has_head(&(v1119_10)) { singleton(&[]) } else { Space::new() };
    drop(v1119_10);
    let v1119_12: Space = subtract(&(*CONSTANT_0),&(v1119_11));
    drop(v1119_11);
    let mut v1119_13 = Space::new();
    let mut v1119_13_cursor = (v1118_7_tail).read_zipper();
    for v1119_13_byte in v1119_13_cursor.child_mask().iter() {
      v1119_13_cursor.descend_to_byte(v1119_13_byte);
      let v1119_13_tail = v1119_13_cursor.make_map();
      v1119_13_cursor.ascend(1);
      let v1119_13_head = Path::from_slice(&[v1119_13_byte]);
      let v1120_2: Space = Space::new();
      v1119_13.join_into((v1120_2).clone());
    }
    drop(v1119_13_cursor);
    let v1119_14: Space = compose(&(v1119_12),&(v1119_13));
    drop(v1119_12);
    drop(v1119_13);
    let v1119_15: Space = unite(&(v1119_9),&(v1119_14));
    drop(v1119_9);
    drop(v1119_14);
    v1118_7.join_into((v1119_15).clone());
  }
  drop(v1118_7_cursor);
  (v1118_7).clone()
}

fn routine_128(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1121_3 = Space::new();
  let mut v1121_3_cursor = (*s0).read_zipper();
  for v1121_3_byte in v1121_3_cursor.child_mask().iter() {
    v1121_3_cursor.descend_to_byte(v1121_3_byte);
    let v1121_3_tail = v1121_3_cursor.make_map();
    v1121_3_cursor.ascend(1);
    let v1121_3_head = Path::from_slice(&[v1121_3_byte]);
    let v1122_2: Space = Space::new();
    v1121_3.join_into((v1122_2).clone());
  }
  drop(v1121_3_cursor);
  (v1121_3).clone()
}

fn routine_129(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1123_4 = Space::new();
  let mut v1123_4_cursor = (*s0).read_zipper();
  for v1123_4_byte in v1123_4_cursor.child_mask().iter() {
    v1123_4_cursor.descend_to_byte(v1123_4_byte);
    let v1123_4_tail = v1123_4_cursor.make_map();
    v1123_4_cursor.ascend(1);
    let v1123_4_head = Path::from_slice(&[v1123_4_byte]);
    let v1124_2: Space = singleton(&(v1123_4_head));
    let v1124_3: Space = intersect(&(*CONSTANT_14),&(v1124_2));
    drop(v1124_2);
    let v1124_4: Space = if has_head(&(v1124_3)) { singleton(&[]) } else { Space::new() };
    drop(v1124_3);
    let v1124_5: Space = compose(&(v1124_4),&(v1123_4_tail));
    drop(v1124_4);
    let v1124_6: Path = concat_path(&(*p0),&(v1123_4_head));
    let v1124_7: Space = wrap(&(v1124_5),&(v1124_6));
    drop(v1124_5);
    drop(v1124_6);
    v1123_4.join_into((v1124_7).clone());
  }
  drop(v1123_4_cursor);
  let v1123_5: Space = wrap(&(v1123_4),&(*p1));
  drop(v1123_4);
  let v1123_7: Space = wrap(&(v1123_5),&(*CONSTANT_10));
  drop(v1123_5);
  (v1123_7).clone()
}

fn routine_130(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1125_4 = Space::new();
  let mut v1125_4_cursor = (*s0).read_zipper();
  for v1125_4_byte in v1125_4_cursor.child_mask().iter() {
    v1125_4_cursor.descend_to_byte(v1125_4_byte);
    let v1125_4_tail = v1125_4_cursor.make_map();
    v1125_4_cursor.ascend(1);
    let v1125_4_head = Path::from_slice(&[v1125_4_byte]);
    let v1126_2: Space = Space::new();
    v1125_4.join_into((v1126_2).clone());
  }
  drop(v1125_4_cursor);
  (v1125_4).clone()
}

fn routine_131(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1127_6: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v1127_8: Space = unwrap(&(v1127_6),&(*CONSTANT_10));
  drop(v1127_6);
  let v1127_9: Space = unwrap(&(v1127_8),&(*p0));
  drop(v1127_8);
  let mut v1127_13 = Space::new();
  let mut v1127_13_cursor = (*s0).read_zipper();
  for v1127_13_byte in v1127_13_cursor.child_mask().iter() {
    v1127_13_cursor.descend_to_byte(v1127_13_byte);
    let v1127_13_tail = v1127_13_cursor.make_map();
    v1127_13_cursor.ascend(1);
    let v1127_13_head = Path::from_slice(&[v1127_13_byte]);
    let v1128_2: Space = singleton(&(v1127_13_head));
    let v1128_3: Space = intersect(&(*CONSTANT_14),&(v1128_2));
    drop(v1128_2);
    let v1128_4: Space = if has_head(&(v1128_3)) { singleton(&[]) } else { Space::new() };
    drop(v1128_3);
    let v1128_7: Space = if (v1128_4).is_empty() { Space::new() } else {
      let v1129_5: Space = unwrap(&(v1127_9),&(v1127_13_head));
      let mut v1129_6 = Space::new();
      let mut v1129_6_cursor = (v1129_5).read_zipper();
      for v1129_6_byte in v1129_6_cursor.child_mask().iter() {
        v1129_6_cursor.descend_to_byte(v1129_6_byte);
        let v1129_6_tail = v1129_6_cursor.make_map();
        v1129_6_cursor.ascend(1);
        let v1129_6_head = Path::from_slice(&[v1129_6_byte]);
        let v1130_2: Space = singleton(&(v1129_6_head));
        let v1130_3: Space = intersect(&(*CONSTANT_14),&(v1130_2));
        let v1130_4: Space = if has_head(&(v1130_3)) { singleton(&[]) } else { Space::new() };
        drop(v1130_3);
        let v1130_5: Space = subtract(&(*CONSTANT_0),&(v1130_4));
        drop(v1130_4);
        let v1130_7: Space = if (v1130_5).is_empty() { Space::new() } else {
          let v1131_6: Space = routine_59(c, &(v1129_6_head), &(*p1), &(v1129_6_tail));
          compose(&(v1130_5),&(v1131_6))
        };
        drop(v1130_5);
        let v1130_8: Space = intersect(&(*CONSTANT_14),&(v1130_2));
        drop(v1130_2);
        let v1130_9: Space = if has_head(&(v1130_8)) { singleton(&[]) } else { Space::new() };
        drop(v1130_8);
        let v1130_11: Space = if (v1130_9).is_empty() { Space::new() } else {
          let v1132_10: Space = routine_60(c, &(v1129_6_head), &(*p1), &(v1129_6_tail));
          compose(&(v1130_9),&(v1132_10))
        };
        drop(v1130_9);
        let v1130_12: Space = unite(&(v1130_7),&(v1130_11));
        v1129_6.join_into((v1130_12).clone());
      }
      drop(v1129_6_cursor);
      drop(v1129_5);
      compose(&(v1128_4),&(v1129_6))
    };
    drop(v1128_4);
    v1127_13.join_into((v1128_7).clone());
  }
  drop(v1127_13_cursor);
  drop(v1127_9);
  (v1127_13).clone()
}

fn routine_132(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1133_12 = Space::new();
  let mut v1133_12_cursor = (*s0).read_zipper();
  for v1133_12_byte in v1133_12_cursor.child_mask().iter() {
    v1133_12_cursor.descend_to_byte(v1133_12_byte);
    let v1133_12_tail = v1133_12_cursor.make_map();
    v1133_12_cursor.ascend(1);
    let v1133_12_head = Path::from_slice(&[v1133_12_byte]);
    let v1134_2: Space = singleton(&(v1133_12_head));
    let v1134_3: Space = intersect(&(*CONSTANT_14),&(v1134_2));
    let v1134_4: Space = if has_head(&(v1134_3)) { singleton(&[]) } else { Space::new() };
    drop(v1134_3);
    let v1134_5: Space = subtract(&(*CONSTANT_0),&(v1134_4));
    drop(v1134_4);
    let v1134_8: Space = if (v1134_5).is_empty() { Space::new() } else {
      let v1135_6: Path = concat_path(&(*p0),&(v1133_12_head));
      let mut v1135_7 = Space::new();
      let mut v1135_7_cursor = (v1133_12_tail).read_zipper();
      for v1135_7_byte in v1135_7_cursor.child_mask().iter() {
        v1135_7_cursor.descend_to_byte(v1135_7_byte);
        let v1135_7_tail = v1135_7_cursor.make_map();
        v1135_7_cursor.ascend(1);
        let v1135_7_head = Path::from_slice(&[v1135_7_byte]);
        let v1136_2: Space = singleton(&(v1135_7_head));
        let v1136_3: Space = intersect(&(*CONSTANT_14),&(v1136_2));
        let v1136_4: Space = if has_head(&(v1136_3)) { singleton(&[]) } else { Space::new() };
        drop(v1136_3);
        let v1136_5: Space = subtract(&(*CONSTANT_0),&(v1136_4));
        drop(v1136_4);
        let v1136_8: Space = if (v1136_5).is_empty() { Space::new() } else {
          let v1137_6: Path = concat_path(&(v1135_6),&(v1135_7_head));
          let v1137_7: Space = routine_150(c, &(v1137_6), &(*p1), &(v1135_7_tail));
          compose(&(v1136_5),&(v1137_7))
        };
        drop(v1136_5);
        let v1136_9: Space = intersect(&(*CONSTANT_14),&(v1136_2));
        drop(v1136_2);
        let v1136_10: Space = if has_head(&(v1136_9)) { singleton(&[]) } else { Space::new() };
        drop(v1136_9);
        let v1136_12: Space = if (v1136_10).is_empty() { Space::new() } else {
          let v1138_6: Path = concat_path(&(v1135_6),&(v1135_7_head));
          let v1138_11: Space = routine_151(c, &(v1138_6), &(*p1), &(v1135_7_tail));
          drop(v1138_6);
          compose(&(v1136_10),&(v1138_11))
        };
        drop(v1136_10);
        let v1136_13: Space = unite(&(v1136_8),&(v1136_12));
        v1135_7.join_into((v1136_13).clone());
      }
      drop(v1135_7_cursor);
      compose(&(v1134_5),&(v1135_7))
    };
    drop(v1134_5);
    let v1134_9: Space = intersect(&(*CONSTANT_14),&(v1134_2));
    drop(v1134_2);
    let v1134_10: Space = if has_head(&(v1134_9)) { singleton(&[]) } else { Space::new() };
    drop(v1134_9);
    let v1134_12: Space = if (v1134_10).is_empty() { Space::new() } else {
      let v1139_6: Path = concat_path(&(*p0),&(v1133_12_head));
      let mut v1139_11 = Space::new();
      let mut v1139_11_cursor = (v1133_12_tail).read_zipper();
      for v1139_11_byte in v1139_11_cursor.child_mask().iter() {
        v1139_11_cursor.descend_to_byte(v1139_11_byte);
        let v1139_11_tail = v1139_11_cursor.make_map();
        v1139_11_cursor.ascend(1);
        let v1139_11_head = Path::from_slice(&[v1139_11_byte]);
        let v1140_2: Space = singleton(&(v1139_11_head));
        let v1140_3: Space = intersect(&(*CONSTANT_14),&(v1140_2));
        let v1140_4: Space = if has_head(&(v1140_3)) { singleton(&[]) } else { Space::new() };
        drop(v1140_3);
        let v1140_5: Space = subtract(&(*CONSTANT_0),&(v1140_4));
        drop(v1140_4);
        let v1140_8: Space = if (v1140_5).is_empty() { Space::new() } else {
          let v1141_6: Path = concat_path(&(v1139_6),&(v1139_11_head));
          let v1141_7: Space = routine_150(c, &(v1141_6), &(*p1), &(v1139_11_tail));
          compose(&(v1140_5),&(v1141_7))
        };
        drop(v1140_5);
        let v1140_9: Space = intersect(&(*CONSTANT_14),&(v1140_2));
        drop(v1140_2);
        let v1140_10: Space = if has_head(&(v1140_9)) { singleton(&[]) } else { Space::new() };
        drop(v1140_9);
        let v1140_12: Space = if (v1140_10).is_empty() { Space::new() } else {
          let v1142_6: Path = concat_path(&(v1139_6),&(v1139_11_head));
          let v1142_11: Space = routine_65(c, &(v1142_6), &(*p1), &(v1139_11_tail));
          drop(v1142_6);
          compose(&(v1140_10),&(v1142_11))
        };
        drop(v1140_10);
        let v1140_13: Space = unite(&(v1140_8),&(v1140_12));
        v1139_11.join_into((v1140_13).clone());
      }
      drop(v1139_11_cursor);
      drop(v1139_6);
      compose(&(v1134_10),&(v1139_11))
    };
    drop(v1134_10);
    let v1134_13: Space = unite(&(v1134_8),&(v1134_12));
    v1133_12.join_into((v1134_13).clone());
  }
  drop(v1133_12_cursor);
  (v1133_12).clone()
}

fn routine_133(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1143_9 = Space::new();
  let mut v1143_9_cursor = (*s0).read_zipper();
  for v1143_9_byte in v1143_9_cursor.child_mask().iter() {
    v1143_9_cursor.descend_to_byte(v1143_9_byte);
    let v1143_9_tail = v1143_9_cursor.make_map();
    v1143_9_cursor.ascend(1);
    let v1143_9_head = Path::from_slice(&[v1143_9_byte]);
    let v1144_2: Space = singleton(&(v1143_9_head));
    let v1144_3: Space = intersect(&(*CONSTANT_14),&(v1144_2));
    let v1144_4: Space = if has_head(&(v1144_3)) { singleton(&[]) } else { Space::new() };
    drop(v1144_3);
    let v1144_5: Space = subtract(&(*CONSTANT_0),&(v1144_4));
    drop(v1144_4);
    let v1144_8: Space = if (v1144_5).is_empty() { Space::new() } else {
      let v1145_6: Path = concat_path(&(*p0),&(v1143_9_head));
      let mut v1145_7 = Space::new();
      let mut v1145_7_cursor = (v1143_9_tail).read_zipper();
      for v1145_7_byte in v1145_7_cursor.child_mask().iter() {
        v1145_7_cursor.descend_to_byte(v1145_7_byte);
        let v1145_7_tail = v1145_7_cursor.make_map();
        v1145_7_cursor.ascend(1);
        let v1145_7_head = Path::from_slice(&[v1145_7_byte]);
        let v1146_2: Space = singleton(&(v1145_7_head));
        let v1146_3: Space = intersect(&(*CONSTANT_14),&(v1146_2));
        let v1146_4: Space = if has_head(&(v1146_3)) { singleton(&[]) } else { Space::new() };
        drop(v1146_3);
        let v1146_5: Space = subtract(&(*CONSTANT_0),&(v1146_4));
        drop(v1146_4);
        let v1146_8: Space = if (v1146_5).is_empty() { Space::new() } else {
          let v1147_6: Path = concat_path(&(v1145_6),&(v1145_7_head));
          let v1147_7: Space = routine_150(c, &(v1147_6), &(*p1), &(v1145_7_tail));
          compose(&(v1146_5),&(v1147_7))
        };
        drop(v1146_5);
        let v1146_9: Space = intersect(&(*CONSTANT_14),&(v1146_2));
        drop(v1146_2);
        let v1146_10: Space = if has_head(&(v1146_9)) { singleton(&[]) } else { Space::new() };
        drop(v1146_9);
        let v1146_12: Space = if (v1146_10).is_empty() { Space::new() } else {
          let v1148_6: Path = concat_path(&(v1145_6),&(v1145_7_head));
          let v1148_11: Space = routine_151(c, &(v1148_6), &(*p1), &(v1145_7_tail));
          drop(v1148_6);
          compose(&(v1146_10),&(v1148_11))
        };
        drop(v1146_10);
        let v1146_13: Space = unite(&(v1146_8),&(v1146_12));
        v1145_7.join_into((v1146_13).clone());
      }
      drop(v1145_7_cursor);
      compose(&(v1144_5),&(v1145_7))
    };
    drop(v1144_5);
    let v1144_9: Space = intersect(&(*CONSTANT_14),&(v1144_2));
    drop(v1144_2);
    let v1144_10: Space = if has_head(&(v1144_9)) { singleton(&[]) } else { Space::new() };
    drop(v1144_9);
    let v1144_11: Space = compose(&(v1144_10),&(v1143_9_tail));
    drop(v1144_10);
    let v1149_6: Path = concat_path(&(*p0),&(v1143_9_head));
    let v1144_12: Space = wrap(&(v1144_11),&(v1149_6));
    drop(v1144_11);
    let v1144_13: Space = wrap(&(v1144_12),&(*p1));
    drop(v1144_12);
    let v1144_14: Space = unite(&(v1144_8),&(v1144_13));
    drop(v1144_13);
    v1143_9.join_into((v1144_14).clone());
  }
  drop(v1143_9_cursor);
  (v1143_9).clone()
}

fn routine_134(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1150_7 = Space::new();
  let mut v1150_7_cursor = (*s0).read_zipper();
  for v1150_7_byte in v1150_7_cursor.child_mask().iter() {
    v1150_7_cursor.descend_to_byte(v1150_7_byte);
    let v1150_7_tail = v1150_7_cursor.make_map();
    v1150_7_cursor.ascend(1);
    let v1150_7_head = Path::from_slice(&[v1150_7_byte]);
    let v1151_2: Space = singleton(&(v1150_7_head));
    let v1151_3: Space = intersect(&(*CONSTANT_14),&(v1151_2));
    let v1151_4: Space = if has_head(&(v1151_3)) { singleton(&[]) } else { Space::new() };
    drop(v1151_3);
    let v1151_5: Space = subtract(&(*CONSTANT_0),&(v1151_4));
    drop(v1151_4);
    let mut v1151_6 = Space::new();
    let mut v1151_6_cursor = (v1150_7_tail).read_zipper();
    for v1151_6_byte in v1151_6_cursor.child_mask().iter() {
      v1151_6_cursor.descend_to_byte(v1151_6_byte);
      let v1151_6_tail = v1151_6_cursor.make_map();
      v1151_6_cursor.ascend(1);
      let v1151_6_head = Path::from_slice(&[v1151_6_byte]);
      let v1152_2: Space = Space::new();
      v1151_6.join_into((v1152_2).clone());
    }
    drop(v1151_6_cursor);
    let v1151_7: Space = compose(&(v1151_5),&(v1151_6));
    drop(v1151_5);
    drop(v1151_6);
    let v1151_8: Space = intersect(&(*CONSTANT_14),&(v1151_2));
    drop(v1151_2);
    let v1151_9: Space = if has_head(&(v1151_8)) { singleton(&[]) } else { Space::new() };
    drop(v1151_8);
    let v1151_12: Space = if (v1151_9).is_empty() { Space::new() } else {
      let v1153_10: Path = concat_path(&(*p0),&(v1150_7_head));
      let mut v1153_11 = Space::new();
      let mut v1153_11_cursor = (v1150_7_tail).read_zipper();
      for v1153_11_byte in v1153_11_cursor.child_mask().iter() {
        v1153_11_cursor.descend_to_byte(v1153_11_byte);
        let v1153_11_tail = v1153_11_cursor.make_map();
        v1153_11_cursor.ascend(1);
        let v1153_11_head = Path::from_slice(&[v1153_11_byte]);
        let v1154_2: Space = singleton(&(v1153_11_head));
        let v1154_3: Space = intersect(&(*CONSTANT_14),&(v1154_2));
        drop(v1154_2);
        let v1154_4: Space = if has_head(&(v1154_3)) { singleton(&[]) } else { Space::new() };
        drop(v1154_3);
        let v1154_7: Space = if (v1154_4).is_empty() { Space::new() } else {
          let v1155_5: Path = concat_path(&(v1153_10),&(v1153_11_head));
          let v1155_6: Space = routine_65(c, &(v1155_5), &(*p1), &(v1153_11_tail));
          drop(v1155_5);
          compose(&(v1154_4),&(v1155_6))
        };
        drop(v1154_4);
        v1153_11.join_into((v1154_7).clone());
      }
      drop(v1153_11_cursor);
      drop(v1153_10);
      compose(&(v1151_9),&(v1153_11))
    };
    drop(v1151_9);
    let v1151_13: Space = unite(&(v1151_7),&(v1151_12));
    drop(v1151_7);
    v1150_7.join_into((v1151_13).clone());
  }
  drop(v1150_7_cursor);
  (v1150_7).clone()
}

fn routine_135(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1156_6 = Space::new();
  let mut v1156_6_cursor = (*s0).read_zipper();
  for v1156_6_byte in v1156_6_cursor.child_mask().iter() {
    v1156_6_cursor.descend_to_byte(v1156_6_byte);
    let v1156_6_tail = v1156_6_cursor.make_map();
    v1156_6_cursor.ascend(1);
    let v1156_6_head = Path::from_slice(&[v1156_6_byte]);
    let v1157_2: Space = singleton(&(v1156_6_head));
    let v1157_3: Space = intersect(&(*CONSTANT_14),&(v1157_2));
    let v1157_4: Space = if has_head(&(v1157_3)) { singleton(&[]) } else { Space::new() };
    drop(v1157_3);
    let v1157_5: Space = subtract(&(*CONSTANT_0),&(v1157_4));
    drop(v1157_4);
    let mut v1157_6 = Space::new();
    let mut v1157_6_cursor = (v1156_6_tail).read_zipper();
    for v1157_6_byte in v1157_6_cursor.child_mask().iter() {
      v1157_6_cursor.descend_to_byte(v1157_6_byte);
      let v1157_6_tail = v1157_6_cursor.make_map();
      v1157_6_cursor.ascend(1);
      let v1157_6_head = Path::from_slice(&[v1157_6_byte]);
      let v1158_2: Space = Space::new();
      v1157_6.join_into((v1158_2).clone());
    }
    drop(v1157_6_cursor);
    let v1157_7: Space = compose(&(v1157_5),&(v1157_6));
    drop(v1157_5);
    drop(v1157_6);
    let v1157_8: Space = intersect(&(*CONSTANT_14),&(v1157_2));
    drop(v1157_2);
    let v1157_9: Space = if has_head(&(v1157_8)) { singleton(&[]) } else { Space::new() };
    drop(v1157_8);
    let v1157_10: Space = compose(&(v1157_9),&(v1156_6_tail));
    drop(v1157_9);
    let v1157_11: Path = concat_path(&(*p0),&(v1156_6_head));
    let v1157_12: Space = wrap(&(v1157_10),&(v1157_11));
    drop(v1157_10);
    drop(v1157_11);
    let v1157_13: Space = wrap(&(v1157_12),&(*p1));
    drop(v1157_12);
    let v1157_14: Space = unite(&(v1157_7),&(v1157_13));
    drop(v1157_7);
    drop(v1157_13);
    v1156_6.join_into((v1157_14).clone());
  }
  drop(v1156_6_cursor);
  (v1156_6).clone()
}

fn routine_136(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1159_3 = Space::new();
  let mut v1159_3_cursor = (*s0).read_zipper();
  for v1159_3_byte in v1159_3_cursor.child_mask().iter() {
    v1159_3_cursor.descend_to_byte(v1159_3_byte);
    let v1159_3_tail = v1159_3_cursor.make_map();
    v1159_3_cursor.ascend(1);
    let v1159_3_head = Path::from_slice(&[v1159_3_byte]);
    let v1160_2: Space = Space::new();
    v1159_3.join_into((v1160_2).clone());
  }
  drop(v1159_3_cursor);
  (v1159_3).clone()
}

fn routine_137(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1161_4 = Space::new();
  let mut v1161_4_cursor = (*s0).read_zipper();
  for v1161_4_byte in v1161_4_cursor.child_mask().iter() {
    v1161_4_cursor.descend_to_byte(v1161_4_byte);
    let v1161_4_tail = v1161_4_cursor.make_map();
    v1161_4_cursor.ascend(1);
    let v1161_4_head = Path::from_slice(&[v1161_4_byte]);
    let v1162_2: Space = singleton(&(v1161_4_head));
    let v1162_3: Space = intersect(&(*CONSTANT_14),&(v1162_2));
    drop(v1162_2);
    let v1162_4: Space = if has_head(&(v1162_3)) { singleton(&[]) } else { Space::new() };
    drop(v1162_3);
    let v1162_5: Space = compose(&(v1162_4),&(v1161_4_tail));
    drop(v1162_4);
    let v1162_6: Path = concat_path(&(*p0),&(v1161_4_head));
    let v1162_7: Space = wrap(&(v1162_5),&(v1162_6));
    drop(v1162_5);
    drop(v1162_6);
    v1161_4.join_into((v1162_7).clone());
  }
  drop(v1161_4_cursor);
  let v1161_5: Space = wrap(&(v1161_4),&(*p1));
  drop(v1161_4);
  (v1161_5).clone()
}

fn routine_138(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1163_4 = Space::new();
  let mut v1163_4_cursor = (*s0).read_zipper();
  for v1163_4_byte in v1163_4_cursor.child_mask().iter() {
    v1163_4_cursor.descend_to_byte(v1163_4_byte);
    let v1163_4_tail = v1163_4_cursor.make_map();
    v1163_4_cursor.ascend(1);
    let v1163_4_head = Path::from_slice(&[v1163_4_byte]);
    let v1164_2: Space = Space::new();
    v1163_4.join_into((v1164_2).clone());
  }
  drop(v1163_4_cursor);
  (v1163_4).clone()
}

fn routine_139(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1165_6: Space = unwrap(&(*s1),&(*CONSTANT_9));
  let v1165_8: Space = unwrap(&(v1165_6),&(*CONSTANT_10));
  drop(v1165_6);
  let v1165_9: Space = unwrap(&(v1165_8),&(*p0));
  drop(v1165_8);
  let mut v1165_13 = Space::new();
  let mut v1165_13_cursor = (*s0).read_zipper();
  for v1165_13_byte in v1165_13_cursor.child_mask().iter() {
    v1165_13_cursor.descend_to_byte(v1165_13_byte);
    let v1165_13_tail = v1165_13_cursor.make_map();
    v1165_13_cursor.ascend(1);
    let v1165_13_head = Path::from_slice(&[v1165_13_byte]);
    let v1166_2: Space = singleton(&(v1165_13_head));
    let v1166_3: Space = intersect(&(*CONSTANT_14),&(v1166_2));
    drop(v1166_2);
    let v1166_4: Space = if has_head(&(v1166_3)) { singleton(&[]) } else { Space::new() };
    drop(v1166_3);
    let v1166_7: Space = if (v1166_4).is_empty() { Space::new() } else {
      let v1167_5: Space = unwrap(&(v1165_9),&(v1165_13_head));
      let mut v1167_6 = Space::new();
      let mut v1167_6_cursor = (v1167_5).read_zipper();
      for v1167_6_byte in v1167_6_cursor.child_mask().iter() {
        v1167_6_cursor.descend_to_byte(v1167_6_byte);
        let v1167_6_tail = v1167_6_cursor.make_map();
        v1167_6_cursor.ascend(1);
        let v1167_6_head = Path::from_slice(&[v1167_6_byte]);
        let v1168_2: Space = singleton(&(v1167_6_head));
        let v1168_3: Space = intersect(&(*CONSTANT_14),&(v1168_2));
        let v1168_4: Space = if has_head(&(v1168_3)) { singleton(&[]) } else { Space::new() };
        drop(v1168_3);
        let v1168_5: Space = subtract(&(*CONSTANT_0),&(v1168_4));
        drop(v1168_4);
        let v1168_7: Space = if (v1168_5).is_empty() { Space::new() } else {
          let v1169_6: Space = routine_76(c, &(v1167_6_head), &(*p1), &(v1167_6_tail));
          compose(&(v1168_5),&(v1169_6))
        };
        drop(v1168_5);
        let v1168_8: Space = intersect(&(*CONSTANT_14),&(v1168_2));
        drop(v1168_2);
        let v1168_9: Space = if has_head(&(v1168_8)) { singleton(&[]) } else { Space::new() };
        drop(v1168_8);
        let v1168_11: Space = if (v1168_9).is_empty() { Space::new() } else {
          let v1170_10: Space = routine_77(c, &(v1167_6_head), &(*p1), &(v1167_6_tail));
          compose(&(v1168_9),&(v1170_10))
        };
        drop(v1168_9);
        let v1168_12: Space = unite(&(v1168_7),&(v1168_11));
        v1167_6.join_into((v1168_12).clone());
      }
      drop(v1167_6_cursor);
      drop(v1167_5);
      compose(&(v1166_4),&(v1167_6))
    };
    drop(v1166_4);
    v1165_13.join_into((v1166_7).clone());
  }
  drop(v1165_13_cursor);
  drop(v1165_9);
  (v1165_13).clone()
}

fn routine_140(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1171_12 = Space::new();
  let mut v1171_12_cursor = (*s0).read_zipper();
  for v1171_12_byte in v1171_12_cursor.child_mask().iter() {
    v1171_12_cursor.descend_to_byte(v1171_12_byte);
    let v1171_12_tail = v1171_12_cursor.make_map();
    v1171_12_cursor.ascend(1);
    let v1171_12_head = Path::from_slice(&[v1171_12_byte]);
    let v1172_2: Space = singleton(&(v1171_12_head));
    let v1172_3: Space = intersect(&(*CONSTANT_14),&(v1172_2));
    let v1172_4: Space = if has_head(&(v1172_3)) { singleton(&[]) } else { Space::new() };
    drop(v1172_3);
    let v1172_5: Space = subtract(&(*CONSTANT_0),&(v1172_4));
    drop(v1172_4);
    let v1172_8: Space = if (v1172_5).is_empty() { Space::new() } else {
      let v1173_6: Path = concat_path(&(*p0),&(v1171_12_head));
      let mut v1173_7 = Space::new();
      let mut v1173_7_cursor = (v1171_12_tail).read_zipper();
      for v1173_7_byte in v1173_7_cursor.child_mask().iter() {
        v1173_7_cursor.descend_to_byte(v1173_7_byte);
        let v1173_7_tail = v1173_7_cursor.make_map();
        v1173_7_cursor.ascend(1);
        let v1173_7_head = Path::from_slice(&[v1173_7_byte]);
        let v1174_2: Space = singleton(&(v1173_7_head));
        let v1174_3: Space = intersect(&(*CONSTANT_14),&(v1174_2));
        let v1174_4: Space = if has_head(&(v1174_3)) { singleton(&[]) } else { Space::new() };
        drop(v1174_3);
        let v1174_5: Space = subtract(&(*CONSTANT_0),&(v1174_4));
        drop(v1174_4);
        let v1174_8: Space = if (v1174_5).is_empty() { Space::new() } else {
          let v1175_6: Path = concat_path(&(v1173_6),&(v1173_7_head));
          let v1175_7: Space = routine_152(c, &(v1175_6), &(*p1), &(v1173_7_tail));
          compose(&(v1174_5),&(v1175_7))
        };
        drop(v1174_5);
        let v1174_9: Space = intersect(&(*CONSTANT_14),&(v1174_2));
        drop(v1174_2);
        let v1174_10: Space = if has_head(&(v1174_9)) { singleton(&[]) } else { Space::new() };
        drop(v1174_9);
        let v1174_12: Space = if (v1174_10).is_empty() { Space::new() } else {
          let v1176_6: Path = concat_path(&(v1173_6),&(v1173_7_head));
          let v1176_11: Space = routine_153(c, &(v1176_6), &(*p1), &(v1173_7_tail));
          drop(v1176_6);
          compose(&(v1174_10),&(v1176_11))
        };
        drop(v1174_10);
        let v1174_13: Space = unite(&(v1174_8),&(v1174_12));
        v1173_7.join_into((v1174_13).clone());
      }
      drop(v1173_7_cursor);
      compose(&(v1172_5),&(v1173_7))
    };
    drop(v1172_5);
    let v1172_9: Space = intersect(&(*CONSTANT_14),&(v1172_2));
    drop(v1172_2);
    let v1172_10: Space = if has_head(&(v1172_9)) { singleton(&[]) } else { Space::new() };
    drop(v1172_9);
    let v1172_12: Space = if (v1172_10).is_empty() { Space::new() } else {
      let v1177_6: Path = concat_path(&(*p0),&(v1171_12_head));
      let mut v1177_11 = Space::new();
      let mut v1177_11_cursor = (v1171_12_tail).read_zipper();
      for v1177_11_byte in v1177_11_cursor.child_mask().iter() {
        v1177_11_cursor.descend_to_byte(v1177_11_byte);
        let v1177_11_tail = v1177_11_cursor.make_map();
        v1177_11_cursor.ascend(1);
        let v1177_11_head = Path::from_slice(&[v1177_11_byte]);
        let v1178_2: Space = singleton(&(v1177_11_head));
        let v1178_3: Space = intersect(&(*CONSTANT_14),&(v1178_2));
        let v1178_4: Space = if has_head(&(v1178_3)) { singleton(&[]) } else { Space::new() };
        drop(v1178_3);
        let v1178_5: Space = subtract(&(*CONSTANT_0),&(v1178_4));
        drop(v1178_4);
        let v1178_8: Space = if (v1178_5).is_empty() { Space::new() } else {
          let v1179_6: Path = concat_path(&(v1177_6),&(v1177_11_head));
          let v1179_7: Space = routine_152(c, &(v1179_6), &(*p1), &(v1177_11_tail));
          compose(&(v1178_5),&(v1179_7))
        };
        drop(v1178_5);
        let v1178_9: Space = intersect(&(*CONSTANT_14),&(v1178_2));
        drop(v1178_2);
        let v1178_10: Space = if has_head(&(v1178_9)) { singleton(&[]) } else { Space::new() };
        drop(v1178_9);
        let v1178_12: Space = if (v1178_10).is_empty() { Space::new() } else {
          let v1180_6: Path = concat_path(&(v1177_6),&(v1177_11_head));
          let v1180_11: Space = routine_82(c, &(v1180_6), &(*p1), &(v1177_11_tail));
          drop(v1180_6);
          compose(&(v1178_10),&(v1180_11))
        };
        drop(v1178_10);
        let v1178_13: Space = unite(&(v1178_8),&(v1178_12));
        v1177_11.join_into((v1178_13).clone());
      }
      drop(v1177_11_cursor);
      drop(v1177_6);
      compose(&(v1172_10),&(v1177_11))
    };
    drop(v1172_10);
    let v1172_13: Space = unite(&(v1172_8),&(v1172_12));
    v1171_12.join_into((v1172_13).clone());
  }
  drop(v1171_12_cursor);
  (v1171_12).clone()
}

fn routine_141(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1181_9 = Space::new();
  let mut v1181_9_cursor = (*s0).read_zipper();
  for v1181_9_byte in v1181_9_cursor.child_mask().iter() {
    v1181_9_cursor.descend_to_byte(v1181_9_byte);
    let v1181_9_tail = v1181_9_cursor.make_map();
    v1181_9_cursor.ascend(1);
    let v1181_9_head = Path::from_slice(&[v1181_9_byte]);
    let v1182_2: Space = singleton(&(v1181_9_head));
    let v1182_3: Space = intersect(&(*CONSTANT_14),&(v1182_2));
    let v1182_4: Space = if has_head(&(v1182_3)) { singleton(&[]) } else { Space::new() };
    drop(v1182_3);
    let v1182_5: Space = subtract(&(*CONSTANT_0),&(v1182_4));
    drop(v1182_4);
    let v1182_8: Space = if (v1182_5).is_empty() { Space::new() } else {
      let v1183_6: Path = concat_path(&(*p0),&(v1181_9_head));
      let mut v1183_7 = Space::new();
      let mut v1183_7_cursor = (v1181_9_tail).read_zipper();
      for v1183_7_byte in v1183_7_cursor.child_mask().iter() {
        v1183_7_cursor.descend_to_byte(v1183_7_byte);
        let v1183_7_tail = v1183_7_cursor.make_map();
        v1183_7_cursor.ascend(1);
        let v1183_7_head = Path::from_slice(&[v1183_7_byte]);
        let v1184_2: Space = singleton(&(v1183_7_head));
        let v1184_3: Space = intersect(&(*CONSTANT_14),&(v1184_2));
        let v1184_4: Space = if has_head(&(v1184_3)) { singleton(&[]) } else { Space::new() };
        drop(v1184_3);
        let v1184_5: Space = subtract(&(*CONSTANT_0),&(v1184_4));
        drop(v1184_4);
        let v1184_8: Space = if (v1184_5).is_empty() { Space::new() } else {
          let v1185_6: Path = concat_path(&(v1183_6),&(v1183_7_head));
          let v1185_7: Space = routine_152(c, &(v1185_6), &(*p1), &(v1183_7_tail));
          compose(&(v1184_5),&(v1185_7))
        };
        drop(v1184_5);
        let v1184_9: Space = intersect(&(*CONSTANT_14),&(v1184_2));
        drop(v1184_2);
        let v1184_10: Space = if has_head(&(v1184_9)) { singleton(&[]) } else { Space::new() };
        drop(v1184_9);
        let v1184_12: Space = if (v1184_10).is_empty() { Space::new() } else {
          let v1186_6: Path = concat_path(&(v1183_6),&(v1183_7_head));
          let v1186_11: Space = routine_153(c, &(v1186_6), &(*p1), &(v1183_7_tail));
          drop(v1186_6);
          compose(&(v1184_10),&(v1186_11))
        };
        drop(v1184_10);
        let v1184_13: Space = unite(&(v1184_8),&(v1184_12));
        v1183_7.join_into((v1184_13).clone());
      }
      drop(v1183_7_cursor);
      compose(&(v1182_5),&(v1183_7))
    };
    drop(v1182_5);
    let v1182_9: Space = intersect(&(*CONSTANT_14),&(v1182_2));
    drop(v1182_2);
    let v1182_10: Space = if has_head(&(v1182_9)) { singleton(&[]) } else { Space::new() };
    drop(v1182_9);
    let v1182_11: Space = compose(&(v1182_10),&(v1181_9_tail));
    drop(v1182_10);
    let v1187_6: Path = concat_path(&(*p0),&(v1181_9_head));
    let v1182_12: Space = wrap(&(v1182_11),&(v1187_6));
    drop(v1182_11);
    let v1182_13: Space = wrap(&(v1182_12),&(*p1));
    drop(v1182_12);
    let v1182_14: Space = unite(&(v1182_8),&(v1182_13));
    drop(v1182_13);
    v1181_9.join_into((v1182_14).clone());
  }
  drop(v1181_9_cursor);
  (v1181_9).clone()
}

fn routine_142(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1188_7 = Space::new();
  let mut v1188_7_cursor = (*s0).read_zipper();
  for v1188_7_byte in v1188_7_cursor.child_mask().iter() {
    v1188_7_cursor.descend_to_byte(v1188_7_byte);
    let v1188_7_tail = v1188_7_cursor.make_map();
    v1188_7_cursor.ascend(1);
    let v1188_7_head = Path::from_slice(&[v1188_7_byte]);
    let v1189_2: Space = singleton(&(v1188_7_head));
    let v1189_3: Space = intersect(&(*CONSTANT_14),&(v1189_2));
    let v1189_4: Space = if has_head(&(v1189_3)) { singleton(&[]) } else { Space::new() };
    drop(v1189_3);
    let v1189_5: Space = subtract(&(*CONSTANT_0),&(v1189_4));
    drop(v1189_4);
    let mut v1189_6 = Space::new();
    let mut v1189_6_cursor = (v1188_7_tail).read_zipper();
    for v1189_6_byte in v1189_6_cursor.child_mask().iter() {
      v1189_6_cursor.descend_to_byte(v1189_6_byte);
      let v1189_6_tail = v1189_6_cursor.make_map();
      v1189_6_cursor.ascend(1);
      let v1189_6_head = Path::from_slice(&[v1189_6_byte]);
      let v1190_2: Space = Space::new();
      v1189_6.join_into((v1190_2).clone());
    }
    drop(v1189_6_cursor);
    let v1189_7: Space = compose(&(v1189_5),&(v1189_6));
    drop(v1189_5);
    drop(v1189_6);
    let v1189_8: Space = intersect(&(*CONSTANT_14),&(v1189_2));
    drop(v1189_2);
    let v1189_9: Space = if has_head(&(v1189_8)) { singleton(&[]) } else { Space::new() };
    drop(v1189_8);
    let v1189_12: Space = if (v1189_9).is_empty() { Space::new() } else {
      let v1191_10: Path = concat_path(&(*p0),&(v1188_7_head));
      let mut v1191_11 = Space::new();
      let mut v1191_11_cursor = (v1188_7_tail).read_zipper();
      for v1191_11_byte in v1191_11_cursor.child_mask().iter() {
        v1191_11_cursor.descend_to_byte(v1191_11_byte);
        let v1191_11_tail = v1191_11_cursor.make_map();
        v1191_11_cursor.ascend(1);
        let v1191_11_head = Path::from_slice(&[v1191_11_byte]);
        let v1192_2: Space = singleton(&(v1191_11_head));
        let v1192_3: Space = intersect(&(*CONSTANT_14),&(v1192_2));
        drop(v1192_2);
        let v1192_4: Space = if has_head(&(v1192_3)) { singleton(&[]) } else { Space::new() };
        drop(v1192_3);
        let v1192_7: Space = if (v1192_4).is_empty() { Space::new() } else {
          let v1193_5: Path = concat_path(&(v1191_10),&(v1191_11_head));
          let v1193_6: Space = routine_82(c, &(v1193_5), &(*p1), &(v1191_11_tail));
          drop(v1193_5);
          compose(&(v1192_4),&(v1193_6))
        };
        drop(v1192_4);
        v1191_11.join_into((v1192_7).clone());
      }
      drop(v1191_11_cursor);
      drop(v1191_10);
      compose(&(v1189_9),&(v1191_11))
    };
    drop(v1189_9);
    let v1189_13: Space = unite(&(v1189_7),&(v1189_12));
    drop(v1189_7);
    v1188_7.join_into((v1189_13).clone());
  }
  drop(v1188_7_cursor);
  (v1188_7).clone()
}

fn routine_143(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1194_6 = Space::new();
  let mut v1194_6_cursor = (*s0).read_zipper();
  for v1194_6_byte in v1194_6_cursor.child_mask().iter() {
    v1194_6_cursor.descend_to_byte(v1194_6_byte);
    let v1194_6_tail = v1194_6_cursor.make_map();
    v1194_6_cursor.ascend(1);
    let v1194_6_head = Path::from_slice(&[v1194_6_byte]);
    let v1195_2: Space = singleton(&(v1194_6_head));
    let v1195_3: Space = intersect(&(*CONSTANT_14),&(v1195_2));
    let v1195_4: Space = if has_head(&(v1195_3)) { singleton(&[]) } else { Space::new() };
    drop(v1195_3);
    let v1195_5: Space = subtract(&(*CONSTANT_0),&(v1195_4));
    drop(v1195_4);
    let mut v1195_6 = Space::new();
    let mut v1195_6_cursor = (v1194_6_tail).read_zipper();
    for v1195_6_byte in v1195_6_cursor.child_mask().iter() {
      v1195_6_cursor.descend_to_byte(v1195_6_byte);
      let v1195_6_tail = v1195_6_cursor.make_map();
      v1195_6_cursor.ascend(1);
      let v1195_6_head = Path::from_slice(&[v1195_6_byte]);
      let v1196_2: Space = Space::new();
      v1195_6.join_into((v1196_2).clone());
    }
    drop(v1195_6_cursor);
    let v1195_7: Space = compose(&(v1195_5),&(v1195_6));
    drop(v1195_5);
    drop(v1195_6);
    let v1195_8: Space = intersect(&(*CONSTANT_14),&(v1195_2));
    drop(v1195_2);
    let v1195_9: Space = if has_head(&(v1195_8)) { singleton(&[]) } else { Space::new() };
    drop(v1195_8);
    let v1195_10: Space = compose(&(v1195_9),&(v1194_6_tail));
    drop(v1195_9);
    let v1195_11: Path = concat_path(&(*p0),&(v1194_6_head));
    let v1195_12: Space = wrap(&(v1195_10),&(v1195_11));
    drop(v1195_10);
    drop(v1195_11);
    let v1195_13: Space = wrap(&(v1195_12),&(*p1));
    drop(v1195_12);
    let v1195_14: Space = unite(&(v1195_7),&(v1195_13));
    drop(v1195_7);
    drop(v1195_13);
    v1194_6.join_into((v1195_14).clone());
  }
  drop(v1194_6_cursor);
  (v1194_6).clone()
}

fn routine_144(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1197_4 = Space::new();
  let mut v1197_4_cursor = (*s0).read_zipper();
  for v1197_4_byte in v1197_4_cursor.child_mask().iter() {
    v1197_4_cursor.descend_to_byte(v1197_4_byte);
    let v1197_4_tail = v1197_4_cursor.make_map();
    v1197_4_cursor.ascend(1);
    let v1197_4_head = Path::from_slice(&[v1197_4_byte]);
    let v1198_2: Space = Space::new();
    v1197_4.join_into((v1198_2).clone());
  }
  drop(v1197_4_cursor);
  (v1197_4).clone()
}

fn routine_145(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1199_6: Space = unwrap(&(*s1),&(*CONSTANT_7));
  let v1199_8: Space = unwrap(&(v1199_6),&(*CONSTANT_10));
  drop(v1199_6);
  let v1199_9: Space = unwrap(&(v1199_8),&(*p0));
  drop(v1199_8);
  let mut v1199_13 = Space::new();
  let mut v1199_13_cursor = (*s0).read_zipper();
  for v1199_13_byte in v1199_13_cursor.child_mask().iter() {
    v1199_13_cursor.descend_to_byte(v1199_13_byte);
    let v1199_13_tail = v1199_13_cursor.make_map();
    v1199_13_cursor.ascend(1);
    let v1199_13_head = Path::from_slice(&[v1199_13_byte]);
    let v1200_2: Space = singleton(&(v1199_13_head));
    let v1200_3: Space = intersect(&(*CONSTANT_14),&(v1200_2));
    drop(v1200_2);
    let v1200_4: Space = if has_head(&(v1200_3)) { singleton(&[]) } else { Space::new() };
    drop(v1200_3);
    let v1200_7: Space = if (v1200_4).is_empty() { Space::new() } else {
      let v1201_5: Space = unwrap(&(v1199_9),&(v1199_13_head));
      let mut v1201_6 = Space::new();
      let mut v1201_6_cursor = (v1201_5).read_zipper();
      for v1201_6_byte in v1201_6_cursor.child_mask().iter() {
        v1201_6_cursor.descend_to_byte(v1201_6_byte);
        let v1201_6_tail = v1201_6_cursor.make_map();
        v1201_6_cursor.ascend(1);
        let v1201_6_head = Path::from_slice(&[v1201_6_byte]);
        let v1202_2: Space = singleton(&(v1201_6_head));
        let v1202_3: Space = intersect(&(*CONSTANT_14),&(v1202_2));
        let v1202_4: Space = if has_head(&(v1202_3)) { singleton(&[]) } else { Space::new() };
        drop(v1202_3);
        let v1202_5: Space = subtract(&(*CONSTANT_0),&(v1202_4));
        drop(v1202_4);
        let v1202_7: Space = if (v1202_5).is_empty() { Space::new() } else {
          let v1203_6: Space = routine_87(c, &(v1201_6_head), &(*p1), &(v1201_6_tail));
          compose(&(v1202_5),&(v1203_6))
        };
        drop(v1202_5);
        let v1202_8: Space = intersect(&(*CONSTANT_14),&(v1202_2));
        drop(v1202_2);
        let v1202_9: Space = if has_head(&(v1202_8)) { singleton(&[]) } else { Space::new() };
        drop(v1202_8);
        let v1202_11: Space = if (v1202_9).is_empty() { Space::new() } else {
          let v1204_10: Space = routine_88(c, &(v1201_6_head), &(*p1), &(v1201_6_tail));
          compose(&(v1202_9),&(v1204_10))
        };
        drop(v1202_9);
        let v1202_12: Space = unite(&(v1202_7),&(v1202_11));
        v1201_6.join_into((v1202_12).clone());
      }
      drop(v1201_6_cursor);
      drop(v1201_5);
      compose(&(v1200_4),&(v1201_6))
    };
    drop(v1200_4);
    v1199_13.join_into((v1200_7).clone());
  }
  drop(v1199_13_cursor);
  drop(v1199_9);
  (v1199_13).clone()
}

fn routine_146(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1205_12 = Space::new();
  let mut v1205_12_cursor = (*s0).read_zipper();
  for v1205_12_byte in v1205_12_cursor.child_mask().iter() {
    v1205_12_cursor.descend_to_byte(v1205_12_byte);
    let v1205_12_tail = v1205_12_cursor.make_map();
    v1205_12_cursor.ascend(1);
    let v1205_12_head = Path::from_slice(&[v1205_12_byte]);
    let v1206_2: Space = singleton(&(v1205_12_head));
    let v1206_3: Space = intersect(&(*CONSTANT_14),&(v1206_2));
    let v1206_4: Space = if has_head(&(v1206_3)) { singleton(&[]) } else { Space::new() };
    drop(v1206_3);
    let v1206_5: Space = subtract(&(*CONSTANT_0),&(v1206_4));
    drop(v1206_4);
    let v1206_8: Space = if (v1206_5).is_empty() { Space::new() } else {
      let v1207_6: Path = concat_path(&(*p0),&(v1205_12_head));
      let mut v1207_7 = Space::new();
      let mut v1207_7_cursor = (v1205_12_tail).read_zipper();
      for v1207_7_byte in v1207_7_cursor.child_mask().iter() {
        v1207_7_cursor.descend_to_byte(v1207_7_byte);
        let v1207_7_tail = v1207_7_cursor.make_map();
        v1207_7_cursor.ascend(1);
        let v1207_7_head = Path::from_slice(&[v1207_7_byte]);
        let v1208_2: Space = singleton(&(v1207_7_head));
        let v1208_3: Space = intersect(&(*CONSTANT_14),&(v1208_2));
        let v1208_4: Space = if has_head(&(v1208_3)) { singleton(&[]) } else { Space::new() };
        drop(v1208_3);
        let v1208_5: Space = subtract(&(*CONSTANT_0),&(v1208_4));
        drop(v1208_4);
        let v1208_8: Space = if (v1208_5).is_empty() { Space::new() } else {
          let v1209_6: Path = concat_path(&(v1207_6),&(v1207_7_head));
          let v1209_7: Space = routine_154(c, &(v1209_6), &(*p1), &(v1207_7_tail));
          compose(&(v1208_5),&(v1209_7))
        };
        drop(v1208_5);
        let v1208_9: Space = intersect(&(*CONSTANT_14),&(v1208_2));
        drop(v1208_2);
        let v1208_10: Space = if has_head(&(v1208_9)) { singleton(&[]) } else { Space::new() };
        drop(v1208_9);
        let v1208_12: Space = if (v1208_10).is_empty() { Space::new() } else {
          let v1210_6: Path = concat_path(&(v1207_6),&(v1207_7_head));
          let v1210_11: Space = routine_155(c, &(v1210_6), &(*p1), &(v1207_7_tail));
          drop(v1210_6);
          compose(&(v1208_10),&(v1210_11))
        };
        drop(v1208_10);
        let v1208_13: Space = unite(&(v1208_8),&(v1208_12));
        v1207_7.join_into((v1208_13).clone());
      }
      drop(v1207_7_cursor);
      compose(&(v1206_5),&(v1207_7))
    };
    drop(v1206_5);
    let v1206_9: Space = intersect(&(*CONSTANT_14),&(v1206_2));
    drop(v1206_2);
    let v1206_10: Space = if has_head(&(v1206_9)) { singleton(&[]) } else { Space::new() };
    drop(v1206_9);
    let v1206_12: Space = if (v1206_10).is_empty() { Space::new() } else {
      let v1211_6: Path = concat_path(&(*p0),&(v1205_12_head));
      let mut v1211_11 = Space::new();
      let mut v1211_11_cursor = (v1205_12_tail).read_zipper();
      for v1211_11_byte in v1211_11_cursor.child_mask().iter() {
        v1211_11_cursor.descend_to_byte(v1211_11_byte);
        let v1211_11_tail = v1211_11_cursor.make_map();
        v1211_11_cursor.ascend(1);
        let v1211_11_head = Path::from_slice(&[v1211_11_byte]);
        let v1212_2: Space = singleton(&(v1211_11_head));
        let v1212_3: Space = intersect(&(*CONSTANT_14),&(v1212_2));
        let v1212_4: Space = if has_head(&(v1212_3)) { singleton(&[]) } else { Space::new() };
        drop(v1212_3);
        let v1212_5: Space = subtract(&(*CONSTANT_0),&(v1212_4));
        drop(v1212_4);
        let v1212_8: Space = if (v1212_5).is_empty() { Space::new() } else {
          let v1213_6: Path = concat_path(&(v1211_6),&(v1211_11_head));
          let v1213_7: Space = routine_154(c, &(v1213_6), &(*p1), &(v1211_11_tail));
          compose(&(v1212_5),&(v1213_7))
        };
        drop(v1212_5);
        let v1212_9: Space = intersect(&(*CONSTANT_14),&(v1212_2));
        drop(v1212_2);
        let v1212_10: Space = if has_head(&(v1212_9)) { singleton(&[]) } else { Space::new() };
        drop(v1212_9);
        let v1212_12: Space = if (v1212_10).is_empty() { Space::new() } else {
          let v1214_6: Path = concat_path(&(v1211_6),&(v1211_11_head));
          let v1214_11: Space = routine_93(c, &(v1214_6), &(*p1), &(v1211_11_tail));
          drop(v1214_6);
          compose(&(v1212_10),&(v1214_11))
        };
        drop(v1212_10);
        let v1212_13: Space = unite(&(v1212_8),&(v1212_12));
        v1211_11.join_into((v1212_13).clone());
      }
      drop(v1211_11_cursor);
      drop(v1211_6);
      compose(&(v1206_10),&(v1211_11))
    };
    drop(v1206_10);
    let v1206_13: Space = unite(&(v1206_8),&(v1206_12));
    v1205_12.join_into((v1206_13).clone());
  }
  drop(v1205_12_cursor);
  (v1205_12).clone()
}

fn routine_147(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1215_9 = Space::new();
  let mut v1215_9_cursor = (*s0).read_zipper();
  for v1215_9_byte in v1215_9_cursor.child_mask().iter() {
    v1215_9_cursor.descend_to_byte(v1215_9_byte);
    let v1215_9_tail = v1215_9_cursor.make_map();
    v1215_9_cursor.ascend(1);
    let v1215_9_head = Path::from_slice(&[v1215_9_byte]);
    let v1216_2: Space = singleton(&(v1215_9_head));
    let v1216_3: Space = intersect(&(*CONSTANT_14),&(v1216_2));
    let v1216_4: Space = if has_head(&(v1216_3)) { singleton(&[]) } else { Space::new() };
    drop(v1216_3);
    let v1216_5: Space = subtract(&(*CONSTANT_0),&(v1216_4));
    drop(v1216_4);
    let v1216_8: Space = if (v1216_5).is_empty() { Space::new() } else {
      let v1217_6: Path = concat_path(&(*p0),&(v1215_9_head));
      let mut v1217_7 = Space::new();
      let mut v1217_7_cursor = (v1215_9_tail).read_zipper();
      for v1217_7_byte in v1217_7_cursor.child_mask().iter() {
        v1217_7_cursor.descend_to_byte(v1217_7_byte);
        let v1217_7_tail = v1217_7_cursor.make_map();
        v1217_7_cursor.ascend(1);
        let v1217_7_head = Path::from_slice(&[v1217_7_byte]);
        let v1218_2: Space = singleton(&(v1217_7_head));
        let v1218_3: Space = intersect(&(*CONSTANT_14),&(v1218_2));
        let v1218_4: Space = if has_head(&(v1218_3)) { singleton(&[]) } else { Space::new() };
        drop(v1218_3);
        let v1218_5: Space = subtract(&(*CONSTANT_0),&(v1218_4));
        drop(v1218_4);
        let v1218_8: Space = if (v1218_5).is_empty() { Space::new() } else {
          let v1219_6: Path = concat_path(&(v1217_6),&(v1217_7_head));
          let v1219_7: Space = routine_154(c, &(v1219_6), &(*p1), &(v1217_7_tail));
          compose(&(v1218_5),&(v1219_7))
        };
        drop(v1218_5);
        let v1218_9: Space = intersect(&(*CONSTANT_14),&(v1218_2));
        drop(v1218_2);
        let v1218_10: Space = if has_head(&(v1218_9)) { singleton(&[]) } else { Space::new() };
        drop(v1218_9);
        let v1218_12: Space = if (v1218_10).is_empty() { Space::new() } else {
          let v1220_6: Path = concat_path(&(v1217_6),&(v1217_7_head));
          let v1220_11: Space = routine_155(c, &(v1220_6), &(*p1), &(v1217_7_tail));
          drop(v1220_6);
          compose(&(v1218_10),&(v1220_11))
        };
        drop(v1218_10);
        let v1218_13: Space = unite(&(v1218_8),&(v1218_12));
        v1217_7.join_into((v1218_13).clone());
      }
      drop(v1217_7_cursor);
      compose(&(v1216_5),&(v1217_7))
    };
    drop(v1216_5);
    let v1216_9: Space = intersect(&(*CONSTANT_14),&(v1216_2));
    drop(v1216_2);
    let v1216_10: Space = if has_head(&(v1216_9)) { singleton(&[]) } else { Space::new() };
    drop(v1216_9);
    let v1216_11: Space = compose(&(v1216_10),&(v1215_9_tail));
    drop(v1216_10);
    let v1221_6: Path = concat_path(&(*p0),&(v1215_9_head));
    let v1216_12: Space = wrap(&(v1216_11),&(v1221_6));
    drop(v1216_11);
    let v1216_13: Space = wrap(&(v1216_12),&(*p1));
    drop(v1216_12);
    let v1216_14: Space = unite(&(v1216_8),&(v1216_13));
    drop(v1216_13);
    v1215_9.join_into((v1216_14).clone());
  }
  drop(v1215_9_cursor);
  (v1215_9).clone()
}

fn routine_148(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1222_7 = Space::new();
  let mut v1222_7_cursor = (*s0).read_zipper();
  for v1222_7_byte in v1222_7_cursor.child_mask().iter() {
    v1222_7_cursor.descend_to_byte(v1222_7_byte);
    let v1222_7_tail = v1222_7_cursor.make_map();
    v1222_7_cursor.ascend(1);
    let v1222_7_head = Path::from_slice(&[v1222_7_byte]);
    let v1223_2: Space = singleton(&(v1222_7_head));
    let v1223_3: Space = intersect(&(*CONSTANT_14),&(v1223_2));
    let v1223_4: Space = if has_head(&(v1223_3)) { singleton(&[]) } else { Space::new() };
    drop(v1223_3);
    let v1223_5: Space = subtract(&(*CONSTANT_0),&(v1223_4));
    drop(v1223_4);
    let mut v1223_6 = Space::new();
    let mut v1223_6_cursor = (v1222_7_tail).read_zipper();
    for v1223_6_byte in v1223_6_cursor.child_mask().iter() {
      v1223_6_cursor.descend_to_byte(v1223_6_byte);
      let v1223_6_tail = v1223_6_cursor.make_map();
      v1223_6_cursor.ascend(1);
      let v1223_6_head = Path::from_slice(&[v1223_6_byte]);
      let v1224_2: Space = Space::new();
      v1223_6.join_into((v1224_2).clone());
    }
    drop(v1223_6_cursor);
    let v1223_7: Space = compose(&(v1223_5),&(v1223_6));
    drop(v1223_5);
    drop(v1223_6);
    let v1223_8: Space = intersect(&(*CONSTANT_14),&(v1223_2));
    drop(v1223_2);
    let v1223_9: Space = if has_head(&(v1223_8)) { singleton(&[]) } else { Space::new() };
    drop(v1223_8);
    let v1223_12: Space = if (v1223_9).is_empty() { Space::new() } else {
      let v1225_10: Path = concat_path(&(*p0),&(v1222_7_head));
      let mut v1225_11 = Space::new();
      let mut v1225_11_cursor = (v1222_7_tail).read_zipper();
      for v1225_11_byte in v1225_11_cursor.child_mask().iter() {
        v1225_11_cursor.descend_to_byte(v1225_11_byte);
        let v1225_11_tail = v1225_11_cursor.make_map();
        v1225_11_cursor.ascend(1);
        let v1225_11_head = Path::from_slice(&[v1225_11_byte]);
        let v1226_2: Space = singleton(&(v1225_11_head));
        let v1226_3: Space = intersect(&(*CONSTANT_14),&(v1226_2));
        drop(v1226_2);
        let v1226_4: Space = if has_head(&(v1226_3)) { singleton(&[]) } else { Space::new() };
        drop(v1226_3);
        let v1226_7: Space = if (v1226_4).is_empty() { Space::new() } else {
          let v1227_5: Path = concat_path(&(v1225_10),&(v1225_11_head));
          let v1227_6: Space = routine_93(c, &(v1227_5), &(*p1), &(v1225_11_tail));
          drop(v1227_5);
          compose(&(v1226_4),&(v1227_6))
        };
        drop(v1226_4);
        v1225_11.join_into((v1226_7).clone());
      }
      drop(v1225_11_cursor);
      drop(v1225_10);
      compose(&(v1223_9),&(v1225_11))
    };
    drop(v1223_9);
    let v1223_13: Space = unite(&(v1223_7),&(v1223_12));
    drop(v1223_7);
    v1222_7.join_into((v1223_13).clone());
  }
  drop(v1222_7_cursor);
  (v1222_7).clone()
}

fn routine_149(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1228_6 = Space::new();
  let mut v1228_6_cursor = (*s0).read_zipper();
  for v1228_6_byte in v1228_6_cursor.child_mask().iter() {
    v1228_6_cursor.descend_to_byte(v1228_6_byte);
    let v1228_6_tail = v1228_6_cursor.make_map();
    v1228_6_cursor.ascend(1);
    let v1228_6_head = Path::from_slice(&[v1228_6_byte]);
    let v1229_2: Space = singleton(&(v1228_6_head));
    let v1229_3: Space = intersect(&(*CONSTANT_14),&(v1229_2));
    let v1229_4: Space = if has_head(&(v1229_3)) { singleton(&[]) } else { Space::new() };
    drop(v1229_3);
    let v1229_5: Space = subtract(&(*CONSTANT_0),&(v1229_4));
    drop(v1229_4);
    let mut v1229_6 = Space::new();
    let mut v1229_6_cursor = (v1228_6_tail).read_zipper();
    for v1229_6_byte in v1229_6_cursor.child_mask().iter() {
      v1229_6_cursor.descend_to_byte(v1229_6_byte);
      let v1229_6_tail = v1229_6_cursor.make_map();
      v1229_6_cursor.ascend(1);
      let v1229_6_head = Path::from_slice(&[v1229_6_byte]);
      let v1230_2: Space = Space::new();
      v1229_6.join_into((v1230_2).clone());
    }
    drop(v1229_6_cursor);
    let v1229_7: Space = compose(&(v1229_5),&(v1229_6));
    drop(v1229_5);
    drop(v1229_6);
    let v1229_8: Space = intersect(&(*CONSTANT_14),&(v1229_2));
    drop(v1229_2);
    let v1229_9: Space = if has_head(&(v1229_8)) { singleton(&[]) } else { Space::new() };
    drop(v1229_8);
    let v1229_10: Space = compose(&(v1229_9),&(v1228_6_tail));
    drop(v1229_9);
    let v1229_11: Path = concat_path(&(*p0),&(v1228_6_head));
    let v1229_12: Space = wrap(&(v1229_10),&(v1229_11));
    drop(v1229_10);
    drop(v1229_11);
    let v1229_13: Space = wrap(&(v1229_12),&(*p1));
    drop(v1229_12);
    let v1229_14: Space = unite(&(v1229_7),&(v1229_13));
    drop(v1229_7);
    drop(v1229_13);
    v1228_6.join_into((v1229_14).clone());
  }
  drop(v1228_6_cursor);
  (v1228_6).clone()
}

fn routine_150(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1231_3 = Space::new();
  let mut v1231_3_cursor = (*s0).read_zipper();
  for v1231_3_byte in v1231_3_cursor.child_mask().iter() {
    v1231_3_cursor.descend_to_byte(v1231_3_byte);
    let v1231_3_tail = v1231_3_cursor.make_map();
    v1231_3_cursor.ascend(1);
    let v1231_3_head = Path::from_slice(&[v1231_3_byte]);
    let v1232_2: Space = Space::new();
    v1231_3.join_into((v1232_2).clone());
  }
  drop(v1231_3_cursor);
  (v1231_3).clone()
}

fn routine_151(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1233_4 = Space::new();
  let mut v1233_4_cursor = (*s0).read_zipper();
  for v1233_4_byte in v1233_4_cursor.child_mask().iter() {
    v1233_4_cursor.descend_to_byte(v1233_4_byte);
    let v1233_4_tail = v1233_4_cursor.make_map();
    v1233_4_cursor.ascend(1);
    let v1233_4_head = Path::from_slice(&[v1233_4_byte]);
    let v1234_2: Space = singleton(&(v1233_4_head));
    let v1234_3: Space = intersect(&(*CONSTANT_14),&(v1234_2));
    drop(v1234_2);
    let v1234_4: Space = if has_head(&(v1234_3)) { singleton(&[]) } else { Space::new() };
    drop(v1234_3);
    let v1234_5: Space = compose(&(v1234_4),&(v1233_4_tail));
    drop(v1234_4);
    let v1234_6: Path = concat_path(&(*p0),&(v1233_4_head));
    let v1234_7: Space = wrap(&(v1234_5),&(v1234_6));
    drop(v1234_5);
    drop(v1234_6);
    v1233_4.join_into((v1234_7).clone());
  }
  drop(v1233_4_cursor);
  let v1233_5: Space = wrap(&(v1233_4),&(*p1));
  drop(v1233_4);
  (v1233_5).clone()
}

fn routine_152(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1235_3 = Space::new();
  let mut v1235_3_cursor = (*s0).read_zipper();
  for v1235_3_byte in v1235_3_cursor.child_mask().iter() {
    v1235_3_cursor.descend_to_byte(v1235_3_byte);
    let v1235_3_tail = v1235_3_cursor.make_map();
    v1235_3_cursor.ascend(1);
    let v1235_3_head = Path::from_slice(&[v1235_3_byte]);
    let v1236_2: Space = Space::new();
    v1235_3.join_into((v1236_2).clone());
  }
  drop(v1235_3_cursor);
  (v1235_3).clone()
}

fn routine_153(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1237_4 = Space::new();
  let mut v1237_4_cursor = (*s0).read_zipper();
  for v1237_4_byte in v1237_4_cursor.child_mask().iter() {
    v1237_4_cursor.descend_to_byte(v1237_4_byte);
    let v1237_4_tail = v1237_4_cursor.make_map();
    v1237_4_cursor.ascend(1);
    let v1237_4_head = Path::from_slice(&[v1237_4_byte]);
    let v1238_2: Space = singleton(&(v1237_4_head));
    let v1238_3: Space = intersect(&(*CONSTANT_14),&(v1238_2));
    drop(v1238_2);
    let v1238_4: Space = if has_head(&(v1238_3)) { singleton(&[]) } else { Space::new() };
    drop(v1238_3);
    let v1238_5: Space = compose(&(v1238_4),&(v1237_4_tail));
    drop(v1238_4);
    let v1238_6: Path = concat_path(&(*p0),&(v1237_4_head));
    let v1238_7: Space = wrap(&(v1238_5),&(v1238_6));
    drop(v1238_5);
    drop(v1238_6);
    v1237_4.join_into((v1238_7).clone());
  }
  drop(v1237_4_cursor);
  let v1237_5: Space = wrap(&(v1237_4),&(*p1));
  drop(v1237_4);
  (v1237_5).clone()
}

fn routine_154(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1239_3 = Space::new();
  let mut v1239_3_cursor = (*s0).read_zipper();
  for v1239_3_byte in v1239_3_cursor.child_mask().iter() {
    v1239_3_cursor.descend_to_byte(v1239_3_byte);
    let v1239_3_tail = v1239_3_cursor.make_map();
    v1239_3_cursor.ascend(1);
    let v1239_3_head = Path::from_slice(&[v1239_3_byte]);
    let v1240_2: Space = Space::new();
    v1239_3.join_into((v1240_2).clone());
  }
  drop(v1239_3_cursor);
  (v1239_3).clone()
}

fn routine_155(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1241_4 = Space::new();
  let mut v1241_4_cursor = (*s0).read_zipper();
  for v1241_4_byte in v1241_4_cursor.child_mask().iter() {
    v1241_4_cursor.descend_to_byte(v1241_4_byte);
    let v1241_4_tail = v1241_4_cursor.make_map();
    v1241_4_cursor.ascend(1);
    let v1241_4_head = Path::from_slice(&[v1241_4_byte]);
    let v1242_2: Space = singleton(&(v1241_4_head));
    let v1242_3: Space = intersect(&(*CONSTANT_14),&(v1242_2));
    drop(v1242_2);
    let v1242_4: Space = if has_head(&(v1242_3)) { singleton(&[]) } else { Space::new() };
    drop(v1242_3);
    let v1242_5: Space = compose(&(v1242_4),&(v1241_4_tail));
    drop(v1242_4);
    let v1242_6: Path = concat_path(&(*p0),&(v1241_4_head));
    let v1242_7: Space = wrap(&(v1242_5),&(v1242_6));
    drop(v1242_5);
    drop(v1242_6);
    v1241_4.join_into((v1242_7).clone());
  }
  drop(v1241_4_cursor);
  let v1241_5: Space = wrap(&(v1241_4),&(*p1));
  drop(v1241_4);
  (v1241_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
