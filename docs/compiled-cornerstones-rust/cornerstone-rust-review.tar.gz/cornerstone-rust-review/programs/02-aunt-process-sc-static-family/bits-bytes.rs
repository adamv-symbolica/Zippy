#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 8 0 0 0 1 1 0 1 1 8 0 1 0 1 1 0 1 1 9 0 1 0 1 1 1 0 1 1 8 0 1 1 1 0 0 1 1 5 0 1 1 1 1 9 1 0 0 1 1 0 0 1 1"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 9 0 0 1 1 1 0 0 1 1 8 0 1 1 0 0 0 1 1 8 0 1 1 0 1 0 1 1 8 1 0 0 1 1 0 1 1 9 1 0 1 1 0 1 0 1 1 5 1 1 0 1 1"));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 5 0 0 0 1 1 5 1 0 0 1 1 4 1 0 1 1 2 1 1"));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_4 = Space::new();
  let mut v0_4_cursor = (*s0.expect("unbound native input")).read_zipper();
  for v0_4_byte in v0_4_cursor.child_mask().iter() {
    v0_4_cursor.descend_to_byte(v0_4_byte);
    let v0_4_tail = v0_4_cursor.make_map();
    v0_4_cursor.ascend(1);
    let v0_4_head = Path::from_slice(&[v0_4_byte]);
    let v1_2: Space = singleton(&(v0_4_head));
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let v2_6: Space = routine_1(c, &(v0_4_head), &(v0_4_tail));
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let v3_10: Space = routine_2(c, &(v0_4_head), &(v0_4_tail));
      compose(&(v1_9),&(v3_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_4.join_into((v1_12).clone());
  }
  drop(v0_4_cursor);
  let v0_6: Space = wrap(&(v0_4),&(*CONSTANT_2));
  (v0_6).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v4_11 = Space::new();
  let mut v4_11_cursor = (*s0).read_zipper();
  for v4_11_byte in v4_11_cursor.child_mask().iter() {
    v4_11_cursor.descend_to_byte(v4_11_byte);
    let v4_11_tail = v4_11_cursor.make_map();
    v4_11_cursor.ascend(1);
    let v4_11_head = Path::from_slice(&[v4_11_byte]);
    let v5_2: Space = singleton(&(v4_11_head));
    let v5_3: Space = intersect(&(*CONSTANT_1),&(v5_2));
    let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
    drop(v5_3);
    let v5_5: Space = subtract(&(*CONSTANT_0),&(v5_4));
    drop(v5_4);
    let v5_8: Space = if (v5_5).is_empty() { Space::new() } else {
      let v6_6: Path = concat_path(&(*p0),&(v4_11_head));
      let mut v6_7 = Space::new();
      let mut v6_7_cursor = (v4_11_tail).read_zipper();
      for v6_7_byte in v6_7_cursor.child_mask().iter() {
        v6_7_cursor.descend_to_byte(v6_7_byte);
        let v6_7_tail = v6_7_cursor.make_map();
        v6_7_cursor.ascend(1);
        let v6_7_head = Path::from_slice(&[v6_7_byte]);
        let v7_2: Space = singleton(&(v6_7_head));
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v6_6),&(v6_7_head));
          let v8_7: Space = routine_3(c, &(v8_6), &(v6_7_tail));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v6_6),&(v6_7_head));
          let v9_11: Space = routine_4(c, &(v9_6), &(v6_7_tail));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_7.join_into((v7_13).clone());
      }
      drop(v6_7_cursor);
      compose(&(v5_5),&(v6_7))
    };
    drop(v5_5);
    let v5_9: Space = intersect(&(*CONSTANT_1),&(v5_2));
    drop(v5_2);
    let v5_10: Space = if has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
    drop(v5_9);
    let v5_12: Space = if (v5_10).is_empty() { Space::new() } else {
      let v10_6: Path = concat_path(&(*p0),&(v4_11_head));
      let mut v10_11 = Space::new();
      let mut v10_11_cursor = (v4_11_tail).read_zipper();
      for v10_11_byte in v10_11_cursor.child_mask().iter() {
        v10_11_cursor.descend_to_byte(v10_11_byte);
        let v10_11_tail = v10_11_cursor.make_map();
        v10_11_cursor.ascend(1);
        let v10_11_head = Path::from_slice(&[v10_11_byte]);
        let v11_2: Space = singleton(&(v10_11_head));
        let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
        let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
        drop(v11_3);
        let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
        drop(v11_4);
        let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
          let v12_6: Path = concat_path(&(v10_6),&(v10_11_head));
          let v12_7: Space = routine_3(c, &(v12_6), &(v10_11_tail));
          compose(&(v11_5),&(v12_7))
        };
        drop(v11_5);
        let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
        drop(v11_2);
        let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
        drop(v11_9);
        let v11_12: Space = if (v11_10).is_empty() { Space::new() } else {
          let v13_6: Path = concat_path(&(v10_6),&(v10_11_head));
          let v13_11: Space = routine_5(c, &(v13_6), &(v10_11_tail));
          drop(v13_6);
          compose(&(v11_10),&(v13_11))
        };
        drop(v11_10);
        let v11_13: Space = unite(&(v11_8),&(v11_12));
        v10_11.join_into((v11_13).clone());
      }
      drop(v10_11_cursor);
      drop(v10_6);
      compose(&(v5_10),&(v10_11))
    };
    drop(v5_10);
    let v5_13: Space = unite(&(v5_8),&(v5_12));
    v4_11.join_into((v5_13).clone());
  }
  drop(v4_11_cursor);
  (v4_11).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v14_8: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v14_10: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v14_21 = Space::new();
  let mut v14_21_cursor = (*s0).read_zipper();
  for v14_21_byte in v14_21_cursor.child_mask().iter() {
    v14_21_cursor.descend_to_byte(v14_21_byte);
    let v14_21_tail = v14_21_cursor.make_map();
    v14_21_cursor.ascend(1);
    let v14_21_head = Path::from_slice(&[v14_21_byte]);
    let v15_2: Space = singleton(&(v14_21_head));
    let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
    let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
    drop(v15_3);
    let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
    drop(v15_4);
    let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v14_21_head));
      let mut v16_7 = Space::new();
      let mut v16_7_cursor = (v14_21_tail).read_zipper();
      for v16_7_byte in v16_7_cursor.child_mask().iter() {
        v16_7_cursor.descend_to_byte(v16_7_byte);
        let v16_7_tail = v16_7_cursor.make_map();
        v16_7_cursor.ascend(1);
        let v16_7_head = Path::from_slice(&[v16_7_byte]);
        let v17_2: Space = singleton(&(v16_7_head));
        let v17_3: Space = intersect(&(*CONSTANT_1),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
        drop(v17_4);
        let v17_8: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v16_6),&(v16_7_head));
          let v18_7: Space = routine_3(c, &(v18_6), &(v16_7_tail));
          compose(&(v17_5),&(v18_7))
        };
        drop(v17_5);
        let v17_9: Space = intersect(&(*CONSTANT_1),&(v17_2));
        drop(v17_2);
        let v17_10: Space = if has_head(&(v17_9)) { singleton(&[]) } else { Space::new() };
        drop(v17_9);
        let v17_12: Space = if (v17_10).is_empty() { Space::new() } else {
          let v19_6: Path = concat_path(&(v16_6),&(v16_7_head));
          let v19_11: Space = routine_4(c, &(v19_6), &(v16_7_tail));
          drop(v19_6);
          compose(&(v17_10),&(v19_11))
        };
        drop(v17_10);
        let v17_13: Space = unite(&(v17_8),&(v17_12));
        v16_7.join_into((v17_13).clone());
      }
      drop(v16_7_cursor);
      compose(&(v15_5),&(v16_7))
    };
    drop(v15_5);
    let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
    drop(v15_2);
    let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
    drop(v15_9);
    let v15_19: Space = if (v15_10).is_empty() { Space::new() } else {
      let v20_11: Space = unwrap(&(v14_8),&(v14_21_head));
      let v20_12: Space = restrict_to(&(*CONSTANT_4),&(v20_11));
      drop(v20_11);
      let mut v20_13 = Space::new();
      let mut v20_13_cursor = (v20_12).read_zipper();
      for v20_13_byte in v20_13_cursor.child_mask().iter() {
        v20_13_cursor.descend_to_byte(v20_13_byte);
        let v20_13_tail = v20_13_cursor.make_map();
        v20_13_cursor.ascend(1);
        let v20_13_head = Path::from_slice(&[v20_13_byte]);
        let v21_2: Space = singleton(&(v20_13_head));
        let v21_3: Space = intersect(&(*CONSTANT_1),&(v21_2));
        let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
        drop(v21_3);
        let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
        drop(v21_4);
        let v21_7: Space = if (v21_5).is_empty() { Space::new() } else {
          let v22_6: Space = routine_6(c, &(v20_13_head), &(v20_13_tail));
          compose(&(v21_5),&(v22_6))
        };
        drop(v21_5);
        let v21_8: Space = intersect(&(*CONSTANT_1),&(v21_2));
        drop(v21_2);
        let v21_9: Space = if has_head(&(v21_8)) { singleton(&[]) } else { Space::new() };
        drop(v21_8);
        let v21_11: Space = if (v21_9).is_empty() { Space::new() } else {
          let v23_10: Space = routine_7(c, &(v20_13_head), &(v20_13_tail));
          compose(&(v21_9),&(v23_10))
        };
        drop(v21_9);
        let v21_12: Space = unite(&(v21_7),&(v21_11));
        v20_13.join_into((v21_12).clone());
      }
      drop(v20_13_cursor);
      drop(v20_12);
      let v20_14: Space = restrict_to(&(*CONSTANT_3),&(v20_13));
      let mut v20_15 = Space::new();
      let mut v20_15_cursor = (v20_14).read_zipper();
      for v20_15_byte in v20_15_cursor.child_mask().iter() {
        v20_15_cursor.descend_to_byte(v20_15_byte);
        let v20_15_tail = v20_15_cursor.make_map();
        v20_15_cursor.ascend(1);
        let v20_15_head = Path::from_slice(&[v20_15_byte]);
        let v24_2: Space = singleton(&(v20_15_head));
        let v24_3: Space = intersect(&(*CONSTANT_1),&(v24_2));
        let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
        drop(v24_3);
        let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
        drop(v24_4);
        let v24_7: Space = if (v24_5).is_empty() { Space::new() } else {
          let v25_6: Space = routine_8(c, &(v20_15_head), &(v20_15_tail));
          compose(&(v24_5),&(v25_6))
        };
        drop(v24_5);
        let v24_8: Space = intersect(&(*CONSTANT_1),&(v24_2));
        drop(v24_2);
        let v24_9: Space = if has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
        drop(v24_8);
        let v24_11: Space = if (v24_9).is_empty() { Space::new() } else {
          let v26_10: Space = routine_9(c, &(v20_15_head), &(v20_15_tail));
          compose(&(v24_9),&(v26_10))
        };
        drop(v24_9);
        let v24_12: Space = unite(&(v24_7),&(v24_11));
        v20_15.join_into((v24_12).clone());
      }
      drop(v20_15_cursor);
      let v20_16: Space = unwrap(&(v14_10),&(v14_21_head));
      let v20_17: Space = subtract(&(v20_15),&(v20_16));
      drop(v20_16);
      let v20_18: Space = intersect(&(v20_17),&(*CONSTANT_5));
      compose(&(v15_10),&(v20_18))
    };
    drop(v15_10);
    let v27_6: Path = concat_path(&(*p0),&(v14_21_head));
    let v15_20: Space = wrap(&(v15_19),&(v27_6));
    let v15_21: Space = unite(&(v15_8),&(v15_20));
    v14_21.join_into((v15_21).clone());
  }
  drop(v14_21_cursor);
  drop(v14_8);
  drop(v14_10);
  (v14_21).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v28_11 = Space::new();
  let mut v28_11_cursor = (*s0).read_zipper();
  for v28_11_byte in v28_11_cursor.child_mask().iter() {
    v28_11_cursor.descend_to_byte(v28_11_byte);
    let v28_11_tail = v28_11_cursor.make_map();
    v28_11_cursor.ascend(1);
    let v28_11_head = Path::from_slice(&[v28_11_byte]);
    let v29_2: Space = singleton(&(v28_11_head));
    let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
    let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
    drop(v29_3);
    let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
    drop(v29_4);
    let v29_8: Space = if (v29_5).is_empty() { Space::new() } else {
      let v30_6: Path = concat_path(&(*p0),&(v28_11_head));
      let mut v30_7 = Space::new();
      let mut v30_7_cursor = (v28_11_tail).read_zipper();
      for v30_7_byte in v30_7_cursor.child_mask().iter() {
        v30_7_cursor.descend_to_byte(v30_7_byte);
        let v30_7_tail = v30_7_cursor.make_map();
        v30_7_cursor.ascend(1);
        let v30_7_head = Path::from_slice(&[v30_7_byte]);
        let v31_2: Space = singleton(&(v30_7_head));
        let v31_3: Space = intersect(&(*CONSTANT_1),&(v31_2));
        let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
        drop(v31_3);
        let v31_5: Space = subtract(&(*CONSTANT_0),&(v31_4));
        drop(v31_4);
        let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
          let v32_6: Path = concat_path(&(v30_6),&(v30_7_head));
          let v32_7: Space = routine_10(c, &(v32_6), &(v30_7_tail));
          compose(&(v31_5),&(v32_7))
        };
        drop(v31_5);
        let v31_9: Space = intersect(&(*CONSTANT_1),&(v31_2));
        drop(v31_2);
        let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
        drop(v31_9);
        let v31_12: Space = if (v31_10).is_empty() { Space::new() } else {
          let v33_6: Path = concat_path(&(v30_6),&(v30_7_head));
          let v33_11: Space = routine_11(c, &(v33_6), &(v30_7_tail));
          drop(v33_6);
          compose(&(v31_10),&(v33_11))
        };
        drop(v31_10);
        let v31_13: Space = unite(&(v31_8),&(v31_12));
        v30_7.join_into((v31_13).clone());
      }
      drop(v30_7_cursor);
      compose(&(v29_5),&(v30_7))
    };
    drop(v29_5);
    let v29_9: Space = intersect(&(*CONSTANT_1),&(v29_2));
    drop(v29_2);
    let v29_10: Space = if has_head(&(v29_9)) { singleton(&[]) } else { Space::new() };
    drop(v29_9);
    let v29_12: Space = if (v29_10).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&(v28_11_head));
      let mut v34_11 = Space::new();
      let mut v34_11_cursor = (v28_11_tail).read_zipper();
      for v34_11_byte in v34_11_cursor.child_mask().iter() {
        v34_11_cursor.descend_to_byte(v34_11_byte);
        let v34_11_tail = v34_11_cursor.make_map();
        v34_11_cursor.ascend(1);
        let v34_11_head = Path::from_slice(&[v34_11_byte]);
        let v35_2: Space = singleton(&(v34_11_head));
        let v35_3: Space = intersect(&(*CONSTANT_1),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_0),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (v35_5).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let v36_7: Space = routine_10(c, &(v36_6), &(v34_11_tail));
          compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = intersect(&(*CONSTANT_1),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (v35_10).is_empty() { Space::new() } else {
          let v37_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let v37_11: Space = routine_5(c, &(v37_6), &(v34_11_tail));
          drop(v37_6);
          compose(&(v35_10),&(v37_11))
        };
        drop(v35_10);
        let v35_13: Space = unite(&(v35_8),&(v35_12));
        v34_11.join_into((v35_13).clone());
      }
      drop(v34_11_cursor);
      drop(v34_6);
      compose(&(v29_10),&(v34_11))
    };
    drop(v29_10);
    let v29_13: Space = unite(&(v29_8),&(v29_12));
    v28_11.join_into((v29_13).clone());
  }
  drop(v28_11_cursor);
  (v28_11).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v38_8: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v38_10: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v38_21 = Space::new();
  let mut v38_21_cursor = (*s0).read_zipper();
  for v38_21_byte in v38_21_cursor.child_mask().iter() {
    v38_21_cursor.descend_to_byte(v38_21_byte);
    let v38_21_tail = v38_21_cursor.make_map();
    v38_21_cursor.ascend(1);
    let v38_21_head = Path::from_slice(&[v38_21_byte]);
    let v39_2: Space = singleton(&(v38_21_head));
    let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
    let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
    drop(v39_3);
    let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
    drop(v39_4);
    let v39_8: Space = if (v39_5).is_empty() { Space::new() } else {
      let v40_6: Path = concat_path(&(*p0),&(v38_21_head));
      let mut v40_7 = Space::new();
      let mut v40_7_cursor = (v38_21_tail).read_zipper();
      for v40_7_byte in v40_7_cursor.child_mask().iter() {
        v40_7_cursor.descend_to_byte(v40_7_byte);
        let v40_7_tail = v40_7_cursor.make_map();
        v40_7_cursor.ascend(1);
        let v40_7_head = Path::from_slice(&[v40_7_byte]);
        let v41_2: Space = singleton(&(v40_7_head));
        let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
        let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
        drop(v41_3);
        let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
        drop(v41_4);
        let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
          let v42_6: Path = concat_path(&(v40_6),&(v40_7_head));
          let v42_7: Space = routine_10(c, &(v42_6), &(v40_7_tail));
          compose(&(v41_5),&(v42_7))
        };
        drop(v41_5);
        let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
        drop(v41_2);
        let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
        drop(v41_9);
        let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
          let v43_6: Path = concat_path(&(v40_6),&(v40_7_head));
          let v43_11: Space = routine_11(c, &(v43_6), &(v40_7_tail));
          drop(v43_6);
          compose(&(v41_10),&(v43_11))
        };
        drop(v41_10);
        let v41_13: Space = unite(&(v41_8),&(v41_12));
        v40_7.join_into((v41_13).clone());
      }
      drop(v40_7_cursor);
      compose(&(v39_5),&(v40_7))
    };
    drop(v39_5);
    let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
    drop(v39_2);
    let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
    drop(v39_9);
    let v39_19: Space = if (v39_10).is_empty() { Space::new() } else {
      let v44_11: Space = unwrap(&(v38_8),&(v38_21_head));
      let v44_12: Space = restrict_to(&(*CONSTANT_4),&(v44_11));
      drop(v44_11);
      let mut v44_13 = Space::new();
      let mut v44_13_cursor = (v44_12).read_zipper();
      for v44_13_byte in v44_13_cursor.child_mask().iter() {
        v44_13_cursor.descend_to_byte(v44_13_byte);
        let v44_13_tail = v44_13_cursor.make_map();
        v44_13_cursor.ascend(1);
        let v44_13_head = Path::from_slice(&[v44_13_byte]);
        let v45_2: Space = singleton(&(v44_13_head));
        let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
        let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
        drop(v45_3);
        let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
        drop(v45_4);
        let v45_7: Space = if (v45_5).is_empty() { Space::new() } else {
          let v46_6: Space = routine_6(c, &(v44_13_head), &(v44_13_tail));
          compose(&(v45_5),&(v46_6))
        };
        drop(v45_5);
        let v45_8: Space = intersect(&(*CONSTANT_1),&(v45_2));
        drop(v45_2);
        let v45_9: Space = if has_head(&(v45_8)) { singleton(&[]) } else { Space::new() };
        drop(v45_8);
        let v45_11: Space = if (v45_9).is_empty() { Space::new() } else {
          let v47_10: Space = routine_7(c, &(v44_13_head), &(v44_13_tail));
          compose(&(v45_9),&(v47_10))
        };
        drop(v45_9);
        let v45_12: Space = unite(&(v45_7),&(v45_11));
        v44_13.join_into((v45_12).clone());
      }
      drop(v44_13_cursor);
      drop(v44_12);
      let v44_14: Space = restrict_to(&(*CONSTANT_3),&(v44_13));
      let mut v44_15 = Space::new();
      let mut v44_15_cursor = (v44_14).read_zipper();
      for v44_15_byte in v44_15_cursor.child_mask().iter() {
        v44_15_cursor.descend_to_byte(v44_15_byte);
        let v44_15_tail = v44_15_cursor.make_map();
        v44_15_cursor.ascend(1);
        let v44_15_head = Path::from_slice(&[v44_15_byte]);
        let v48_2: Space = singleton(&(v44_15_head));
        let v48_3: Space = intersect(&(*CONSTANT_1),&(v48_2));
        let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
        drop(v48_3);
        let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
        drop(v48_4);
        let v48_7: Space = if (v48_5).is_empty() { Space::new() } else {
          let v49_6: Space = routine_8(c, &(v44_15_head), &(v44_15_tail));
          compose(&(v48_5),&(v49_6))
        };
        drop(v48_5);
        let v48_8: Space = intersect(&(*CONSTANT_1),&(v48_2));
        drop(v48_2);
        let v48_9: Space = if has_head(&(v48_8)) { singleton(&[]) } else { Space::new() };
        drop(v48_8);
        let v48_11: Space = if (v48_9).is_empty() { Space::new() } else {
          let v50_10: Space = routine_9(c, &(v44_15_head), &(v44_15_tail));
          compose(&(v48_9),&(v50_10))
        };
        drop(v48_9);
        let v48_12: Space = unite(&(v48_7),&(v48_11));
        v44_15.join_into((v48_12).clone());
      }
      drop(v44_15_cursor);
      let v44_16: Space = unwrap(&(v38_10),&(v38_21_head));
      let v44_17: Space = subtract(&(v44_15),&(v44_16));
      drop(v44_16);
      let v44_18: Space = intersect(&(v44_17),&(*CONSTANT_5));
      compose(&(v39_10),&(v44_18))
    };
    drop(v39_10);
    let v51_6: Path = concat_path(&(*p0),&(v38_21_head));
    let v39_20: Space = wrap(&(v39_19),&(v51_6));
    let v39_21: Space = unite(&(v39_8),&(v39_20));
    v38_21.join_into((v39_21).clone());
  }
  drop(v38_21_cursor);
  drop(v38_8);
  drop(v38_10);
  (v38_21).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v52_5: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v52_6: Space = restrict_to(&(*CONSTANT_4),&(v52_5));
  drop(v52_5);
  let mut v52_16 = Space::new();
  let mut v52_16_cursor = (v52_6).read_zipper();
  for v52_16_byte in v52_16_cursor.child_mask().iter() {
    v52_16_cursor.descend_to_byte(v52_16_byte);
    let v52_16_tail = v52_16_cursor.make_map();
    v52_16_cursor.ascend(1);
    let v52_16_head = Path::from_slice(&[v52_16_byte]);
    let v53_2: Space = singleton(&(v52_16_head));
    let v53_3: Space = intersect(&(*CONSTANT_1),&(v53_2));
    let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
    drop(v53_3);
    let v53_5: Space = subtract(&(*CONSTANT_0),&(v53_4));
    drop(v53_4);
    let v53_7: Space = if (v53_5).is_empty() { Space::new() } else {
      let mut v54_6 = Space::new();
      let mut v54_6_cursor = (v52_16_tail).read_zipper();
      for v54_6_byte in v54_6_cursor.child_mask().iter() {
        v54_6_cursor.descend_to_byte(v54_6_byte);
        let v54_6_tail = v54_6_cursor.make_map();
        v54_6_cursor.ascend(1);
        let v54_6_head = Path::from_slice(&[v54_6_byte]);
        let v55_2: Space = singleton(&(v54_6_head));
        let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
        let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
        drop(v55_3);
        let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
        drop(v55_4);
        let v55_8: Space = if (v55_5).is_empty() { Space::new() } else {
          let v56_6: Path = concat_path(&(v52_16_head),&(v54_6_head));
          let v56_7: Space = routine_12(c, &(v56_6), &(v54_6_tail));
          compose(&(v55_5),&(v56_7))
        };
        drop(v55_5);
        let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
        drop(v55_2);
        let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
        drop(v55_9);
        let v55_12: Space = if (v55_10).is_empty() { Space::new() } else {
          let v57_6: Path = concat_path(&(v52_16_head),&(v54_6_head));
          let v57_11: Space = routine_13(c, &(v57_6), &(v54_6_tail));
          drop(v57_6);
          compose(&(v55_10),&(v57_11))
        };
        drop(v55_10);
        let v55_13: Space = unite(&(v55_8),&(v55_12));
        v54_6.join_into((v55_13).clone());
      }
      drop(v54_6_cursor);
      compose(&(v53_5),&(v54_6))
    };
    drop(v53_5);
    let v53_8: Space = intersect(&(*CONSTANT_1),&(v53_2));
    drop(v53_2);
    let v53_9: Space = if has_head(&(v53_8)) { singleton(&[]) } else { Space::new() };
    drop(v53_8);
    let v53_11: Space = if (v53_9).is_empty() { Space::new() } else {
      let mut v58_10 = Space::new();
      let mut v58_10_cursor = (v52_16_tail).read_zipper();
      for v58_10_byte in v58_10_cursor.child_mask().iter() {
        v58_10_cursor.descend_to_byte(v58_10_byte);
        let v58_10_tail = v58_10_cursor.make_map();
        v58_10_cursor.ascend(1);
        let v58_10_head = Path::from_slice(&[v58_10_byte]);
        let v59_2: Space = singleton(&(v58_10_head));
        let v59_3: Space = intersect(&(*CONSTANT_1),&(v59_2));
        let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
        drop(v59_3);
        let v59_5: Space = subtract(&(*CONSTANT_0),&(v59_4));
        drop(v59_4);
        let v59_8: Space = if (v59_5).is_empty() { Space::new() } else {
          let v60_6: Path = concat_path(&(v52_16_head),&(v58_10_head));
          let v60_7: Space = routine_12(c, &(v60_6), &(v58_10_tail));
          compose(&(v59_5),&(v60_7))
        };
        drop(v59_5);
        let v59_9: Space = intersect(&(*CONSTANT_1),&(v59_2));
        drop(v59_2);
        let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
        drop(v59_9);
        let v59_12: Space = if (v59_10).is_empty() { Space::new() } else {
          let v61_6: Path = concat_path(&(v52_16_head),&(v58_10_head));
          let v61_11: Space = routine_14(c, &(v61_6), &(v58_10_tail));
          drop(v61_6);
          compose(&(v59_10),&(v61_11))
        };
        drop(v59_10);
        let v59_13: Space = unite(&(v59_8),&(v59_12));
        v58_10.join_into((v59_13).clone());
      }
      drop(v58_10_cursor);
      compose(&(v53_9),&(v58_10))
    };
    drop(v53_9);
    let v53_12: Space = unite(&(v53_7),&(v53_11));
    v52_16.join_into((v53_12).clone());
  }
  drop(v52_16_cursor);
  drop(v52_6);
  let v52_17: Space = restrict_to(&(*CONSTANT_3),&(v52_16));
  let mut v52_27 = Space::new();
  let mut v52_27_cursor = (v52_17).read_zipper();
  for v52_27_byte in v52_27_cursor.child_mask().iter() {
    v52_27_cursor.descend_to_byte(v52_27_byte);
    let v52_27_tail = v52_27_cursor.make_map();
    v52_27_cursor.ascend(1);
    let v52_27_head = Path::from_slice(&[v52_27_byte]);
    let v62_2: Space = singleton(&(v52_27_head));
    let v62_3: Space = intersect(&(*CONSTANT_1),&(v62_2));
    let v62_4: Space = if has_head(&(v62_3)) { singleton(&[]) } else { Space::new() };
    drop(v62_3);
    let v62_5: Space = subtract(&(*CONSTANT_0),&(v62_4));
    drop(v62_4);
    let v62_7: Space = if (v62_5).is_empty() { Space::new() } else {
      let mut v63_6 = Space::new();
      let mut v63_6_cursor = (v52_27_tail).read_zipper();
      for v63_6_byte in v63_6_cursor.child_mask().iter() {
        v63_6_cursor.descend_to_byte(v63_6_byte);
        let v63_6_tail = v63_6_cursor.make_map();
        v63_6_cursor.ascend(1);
        let v63_6_head = Path::from_slice(&[v63_6_byte]);
        let v64_2: Space = singleton(&(v63_6_head));
        let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
        let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
        drop(v64_3);
        let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
        drop(v64_4);
        let v64_8: Space = if (v64_5).is_empty() { Space::new() } else {
          let v65_6: Path = concat_path(&(v52_27_head),&(v63_6_head));
          let v65_7: Space = routine_15(c, &(v65_6), &(v63_6_tail));
          compose(&(v64_5),&(v65_7))
        };
        drop(v64_5);
        let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
        drop(v64_2);
        let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
        drop(v64_9);
        let v64_12: Space = if (v64_10).is_empty() { Space::new() } else {
          let v66_6: Path = concat_path(&(v52_27_head),&(v63_6_head));
          let v66_11: Space = routine_16(c, &(v66_6), &(v63_6_tail));
          drop(v66_6);
          compose(&(v64_10),&(v66_11))
        };
        drop(v64_10);
        let v64_13: Space = unite(&(v64_8),&(v64_12));
        v63_6.join_into((v64_13).clone());
      }
      drop(v63_6_cursor);
      compose(&(v62_5),&(v63_6))
    };
    drop(v62_5);
    let v62_8: Space = intersect(&(*CONSTANT_1),&(v62_2));
    drop(v62_2);
    let v62_9: Space = if has_head(&(v62_8)) { singleton(&[]) } else { Space::new() };
    drop(v62_8);
    let v62_11: Space = if (v62_9).is_empty() { Space::new() } else {
      let mut v67_10 = Space::new();
      let mut v67_10_cursor = (v52_27_tail).read_zipper();
      for v67_10_byte in v67_10_cursor.child_mask().iter() {
        v67_10_cursor.descend_to_byte(v67_10_byte);
        let v67_10_tail = v67_10_cursor.make_map();
        v67_10_cursor.ascend(1);
        let v67_10_head = Path::from_slice(&[v67_10_byte]);
        let v68_2: Space = singleton(&(v67_10_head));
        let v68_3: Space = intersect(&(*CONSTANT_1),&(v68_2));
        let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
        drop(v68_3);
        let v68_5: Space = subtract(&(*CONSTANT_0),&(v68_4));
        drop(v68_4);
        let v68_8: Space = if (v68_5).is_empty() { Space::new() } else {
          let v69_6: Path = concat_path(&(v52_27_head),&(v67_10_head));
          let v69_7: Space = routine_15(c, &(v69_6), &(v67_10_tail));
          compose(&(v68_5),&(v69_7))
        };
        drop(v68_5);
        let v68_9: Space = intersect(&(*CONSTANT_1),&(v68_2));
        drop(v68_2);
        let v68_10: Space = if has_head(&(v68_9)) { singleton(&[]) } else { Space::new() };
        drop(v68_9);
        let v68_12: Space = if (v68_10).is_empty() { Space::new() } else {
          let v70_6: Path = concat_path(&(v52_27_head),&(v67_10_head));
          let v70_11: Space = routine_17(c, &(v70_6), &(v67_10_tail));
          drop(v70_6);
          compose(&(v68_10),&(v70_11))
        };
        drop(v68_10);
        let v68_13: Space = unite(&(v68_8),&(v68_12));
        v67_10.join_into((v68_13).clone());
      }
      drop(v67_10_cursor);
      compose(&(v62_9),&(v67_10))
    };
    drop(v62_9);
    let v62_12: Space = unite(&(v62_7),&(v62_11));
    v52_27.join_into((v62_12).clone());
  }
  drop(v52_27_cursor);
  let v52_29: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v52_30: Space = subtract(&(v52_27),&(v52_29));
  drop(v52_29);
  let v52_32: Space = intersect(&(v52_30),&(*CONSTANT_5));
  let v52_33: Space = wrap(&(v52_32),&(*p0));
  (v52_33).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v71_11 = Space::new();
  let mut v71_11_cursor = (*s0).read_zipper();
  for v71_11_byte in v71_11_cursor.child_mask().iter() {
    v71_11_cursor.descend_to_byte(v71_11_byte);
    let v71_11_tail = v71_11_cursor.make_map();
    v71_11_cursor.ascend(1);
    let v71_11_head = Path::from_slice(&[v71_11_byte]);
    let v72_2: Space = singleton(&(v71_11_head));
    let v72_3: Space = intersect(&(*CONSTANT_1),&(v72_2));
    let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
    drop(v72_3);
    let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
    drop(v72_4);
    let v72_8: Space = if (v72_5).is_empty() { Space::new() } else {
      let v73_6: Path = concat_path(&(*p0),&(v71_11_head));
      let mut v73_7 = Space::new();
      let mut v73_7_cursor = (v71_11_tail).read_zipper();
      for v73_7_byte in v73_7_cursor.child_mask().iter() {
        v73_7_cursor.descend_to_byte(v73_7_byte);
        let v73_7_tail = v73_7_cursor.make_map();
        v73_7_cursor.ascend(1);
        let v73_7_head = Path::from_slice(&[v73_7_byte]);
        let v74_2: Space = singleton(&(v73_7_head));
        let v74_3: Space = intersect(&(*CONSTANT_1),&(v74_2));
        let v74_4: Space = if has_head(&(v74_3)) { singleton(&[]) } else { Space::new() };
        drop(v74_3);
        let v74_5: Space = subtract(&(*CONSTANT_0),&(v74_4));
        drop(v74_4);
        let v74_8: Space = if (v74_5).is_empty() { Space::new() } else {
          let v75_6: Path = concat_path(&(v73_6),&(v73_7_head));
          let v75_7: Space = routine_18(c, &(v75_6), &(v73_7_tail));
          compose(&(v74_5),&(v75_7))
        };
        drop(v74_5);
        let v74_9: Space = intersect(&(*CONSTANT_1),&(v74_2));
        drop(v74_2);
        let v74_10: Space = if has_head(&(v74_9)) { singleton(&[]) } else { Space::new() };
        drop(v74_9);
        let v74_12: Space = if (v74_10).is_empty() { Space::new() } else {
          let v76_6: Path = concat_path(&(v73_6),&(v73_7_head));
          let v76_11: Space = routine_19(c, &(v76_6), &(v73_7_tail));
          drop(v76_6);
          compose(&(v74_10),&(v76_11))
        };
        drop(v74_10);
        let v74_13: Space = unite(&(v74_8),&(v74_12));
        v73_7.join_into((v74_13).clone());
      }
      drop(v73_7_cursor);
      compose(&(v72_5),&(v73_7))
    };
    drop(v72_5);
    let v72_9: Space = intersect(&(*CONSTANT_1),&(v72_2));
    drop(v72_2);
    let v72_10: Space = if has_head(&(v72_9)) { singleton(&[]) } else { Space::new() };
    drop(v72_9);
    let v72_12: Space = if (v72_10).is_empty() { Space::new() } else {
      let v77_6: Path = concat_path(&(*p0),&(v71_11_head));
      let mut v77_11 = Space::new();
      let mut v77_11_cursor = (v71_11_tail).read_zipper();
      for v77_11_byte in v77_11_cursor.child_mask().iter() {
        v77_11_cursor.descend_to_byte(v77_11_byte);
        let v77_11_tail = v77_11_cursor.make_map();
        v77_11_cursor.ascend(1);
        let v77_11_head = Path::from_slice(&[v77_11_byte]);
        let v78_2: Space = singleton(&(v77_11_head));
        let v78_3: Space = intersect(&(*CONSTANT_1),&(v78_2));
        let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
        drop(v78_3);
        let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
        drop(v78_4);
        let v78_8: Space = if (v78_5).is_empty() { Space::new() } else {
          let v79_6: Path = concat_path(&(v77_6),&(v77_11_head));
          let v79_7: Space = routine_18(c, &(v79_6), &(v77_11_tail));
          compose(&(v78_5),&(v79_7))
        };
        drop(v78_5);
        let v78_9: Space = intersect(&(*CONSTANT_1),&(v78_2));
        drop(v78_2);
        let v78_10: Space = if has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
        drop(v78_9);
        let v78_12: Space = if (v78_10).is_empty() { Space::new() } else {
          let v80_6: Path = concat_path(&(v77_6),&(v77_11_head));
          let v80_11: Space = routine_14(c, &(v80_6), &(v77_11_tail));
          drop(v80_6);
          compose(&(v78_10),&(v80_11))
        };
        drop(v78_10);
        let v78_13: Space = unite(&(v78_8),&(v78_12));
        v77_11.join_into((v78_13).clone());
      }
      drop(v77_11_cursor);
      drop(v77_6);
      compose(&(v72_10),&(v77_11))
    };
    drop(v72_10);
    let v72_13: Space = unite(&(v72_8),&(v72_12));
    v71_11.join_into((v72_13).clone());
  }
  drop(v71_11_cursor);
  (v71_11).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v81_8 = Space::new();
  let mut v81_8_cursor = (*s0).read_zipper();
  for v81_8_byte in v81_8_cursor.child_mask().iter() {
    v81_8_cursor.descend_to_byte(v81_8_byte);
    let v81_8_tail = v81_8_cursor.make_map();
    v81_8_cursor.ascend(1);
    let v81_8_head = Path::from_slice(&[v81_8_byte]);
    let v82_2: Space = singleton(&(v81_8_head));
    let v82_3: Space = intersect(&(*CONSTANT_1),&(v82_2));
    let v82_4: Space = if has_head(&(v82_3)) { singleton(&[]) } else { Space::new() };
    drop(v82_3);
    let v82_5: Space = subtract(&(*CONSTANT_0),&(v82_4));
    drop(v82_4);
    let v82_8: Space = if (v82_5).is_empty() { Space::new() } else {
      let v83_6: Path = concat_path(&(*p0),&(v81_8_head));
      let mut v83_7 = Space::new();
      let mut v83_7_cursor = (v81_8_tail).read_zipper();
      for v83_7_byte in v83_7_cursor.child_mask().iter() {
        v83_7_cursor.descend_to_byte(v83_7_byte);
        let v83_7_tail = v83_7_cursor.make_map();
        v83_7_cursor.ascend(1);
        let v83_7_head = Path::from_slice(&[v83_7_byte]);
        let v84_2: Space = singleton(&(v83_7_head));
        let v84_3: Space = intersect(&(*CONSTANT_1),&(v84_2));
        let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
        drop(v84_3);
        let v84_5: Space = subtract(&(*CONSTANT_0),&(v84_4));
        drop(v84_4);
        let v84_8: Space = if (v84_5).is_empty() { Space::new() } else {
          let v85_6: Path = concat_path(&(v83_6),&(v83_7_head));
          let v85_7: Space = routine_18(c, &(v85_6), &(v83_7_tail));
          compose(&(v84_5),&(v85_7))
        };
        drop(v84_5);
        let v84_9: Space = intersect(&(*CONSTANT_1),&(v84_2));
        drop(v84_2);
        let v84_10: Space = if has_head(&(v84_9)) { singleton(&[]) } else { Space::new() };
        drop(v84_9);
        let v84_12: Space = if (v84_10).is_empty() { Space::new() } else {
          let v86_6: Path = concat_path(&(v83_6),&(v83_7_head));
          let v86_11: Space = routine_19(c, &(v86_6), &(v83_7_tail));
          drop(v86_6);
          compose(&(v84_10),&(v86_11))
        };
        drop(v84_10);
        let v84_13: Space = unite(&(v84_8),&(v84_12));
        v83_7.join_into((v84_13).clone());
      }
      drop(v83_7_cursor);
      drop(v83_6);
      compose(&(v82_5),&(v83_7))
    };
    drop(v82_5);
    let v82_9: Space = intersect(&(*CONSTANT_1),&(v82_2));
    drop(v82_2);
    let v82_10: Space = if has_head(&(v82_9)) { singleton(&[]) } else { Space::new() };
    drop(v82_9);
    let v82_11: Space = compose(&(v82_10),&(v81_8_tail));
    drop(v82_10);
    let v82_12: Space = unite(&(v82_8),&(v82_11));
    drop(v82_11);
    v81_8.join_into((v82_12).clone());
  }
  drop(v81_8_cursor);
  (v81_8).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v87_11 = Space::new();
  let mut v87_11_cursor = (*s0).read_zipper();
  for v87_11_byte in v87_11_cursor.child_mask().iter() {
    v87_11_cursor.descend_to_byte(v87_11_byte);
    let v87_11_tail = v87_11_cursor.make_map();
    v87_11_cursor.ascend(1);
    let v87_11_head = Path::from_slice(&[v87_11_byte]);
    let v88_2: Space = singleton(&(v87_11_head));
    let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
    let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
    drop(v88_3);
    let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
    drop(v88_4);
    let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
      let v89_6: Path = concat_path(&(*p0),&(v87_11_head));
      let mut v89_7 = Space::new();
      let mut v89_7_cursor = (v87_11_tail).read_zipper();
      for v89_7_byte in v89_7_cursor.child_mask().iter() {
        v89_7_cursor.descend_to_byte(v89_7_byte);
        let v89_7_tail = v89_7_cursor.make_map();
        v89_7_cursor.ascend(1);
        let v89_7_head = Path::from_slice(&[v89_7_byte]);
        let v90_2: Space = singleton(&(v89_7_head));
        let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
        let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
        drop(v90_3);
        let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
        drop(v90_4);
        let v90_8: Space = if (v90_5).is_empty() { Space::new() } else {
          let v91_6: Path = concat_path(&(v89_6),&(v89_7_head));
          let v91_7: Space = routine_20(c, &(v91_6), &(v89_7_tail));
          compose(&(v90_5),&(v91_7))
        };
        drop(v90_5);
        let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
        drop(v90_2);
        let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
        drop(v90_9);
        let v90_12: Space = if (v90_10).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v89_6),&(v89_7_head));
          let v92_11: Space = routine_21(c, &(v92_6), &(v89_7_tail));
          drop(v92_6);
          compose(&(v90_10),&(v92_11))
        };
        drop(v90_10);
        let v90_13: Space = unite(&(v90_8),&(v90_12));
        v89_7.join_into((v90_13).clone());
      }
      drop(v89_7_cursor);
      compose(&(v88_5),&(v89_7))
    };
    drop(v88_5);
    let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
    drop(v88_2);
    let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
    drop(v88_9);
    let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
      let v93_6: Path = concat_path(&(*p0),&(v87_11_head));
      let mut v93_11 = Space::new();
      let mut v93_11_cursor = (v87_11_tail).read_zipper();
      for v93_11_byte in v93_11_cursor.child_mask().iter() {
        v93_11_cursor.descend_to_byte(v93_11_byte);
        let v93_11_tail = v93_11_cursor.make_map();
        v93_11_cursor.ascend(1);
        let v93_11_head = Path::from_slice(&[v93_11_byte]);
        let v94_2: Space = singleton(&(v93_11_head));
        let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
        let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
        drop(v94_3);
        let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
        drop(v94_4);
        let v94_8: Space = if (v94_5).is_empty() { Space::new() } else {
          let v95_6: Path = concat_path(&(v93_6),&(v93_11_head));
          let v95_7: Space = routine_20(c, &(v95_6), &(v93_11_tail));
          compose(&(v94_5),&(v95_7))
        };
        drop(v94_5);
        let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
        drop(v94_2);
        let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
        drop(v94_9);
        let v94_12: Space = if (v94_10).is_empty() { Space::new() } else {
          let v96_6: Path = concat_path(&(v93_6),&(v93_11_head));
          let v96_11: Space = routine_17(c, &(v96_6), &(v93_11_tail));
          drop(v96_6);
          compose(&(v94_10),&(v96_11))
        };
        drop(v94_10);
        let v94_13: Space = unite(&(v94_8),&(v94_12));
        v93_11.join_into((v94_13).clone());
      }
      drop(v93_11_cursor);
      drop(v93_6);
      compose(&(v88_10),&(v93_11))
    };
    drop(v88_10);
    let v88_13: Space = unite(&(v88_8),&(v88_12));
    v87_11.join_into((v88_13).clone());
  }
  drop(v87_11_cursor);
  (v87_11).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v97_8 = Space::new();
  let mut v97_8_cursor = (*s0).read_zipper();
  for v97_8_byte in v97_8_cursor.child_mask().iter() {
    v97_8_cursor.descend_to_byte(v97_8_byte);
    let v97_8_tail = v97_8_cursor.make_map();
    v97_8_cursor.ascend(1);
    let v97_8_head = Path::from_slice(&[v97_8_byte]);
    let v98_2: Space = singleton(&(v97_8_head));
    let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
    let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
    drop(v98_3);
    let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
    drop(v98_4);
    let v98_8: Space = if (v98_5).is_empty() { Space::new() } else {
      let v99_6: Path = concat_path(&(*p0),&(v97_8_head));
      let mut v99_7 = Space::new();
      let mut v99_7_cursor = (v97_8_tail).read_zipper();
      for v99_7_byte in v99_7_cursor.child_mask().iter() {
        v99_7_cursor.descend_to_byte(v99_7_byte);
        let v99_7_tail = v99_7_cursor.make_map();
        v99_7_cursor.ascend(1);
        let v99_7_head = Path::from_slice(&[v99_7_byte]);
        let v100_2: Space = singleton(&(v99_7_head));
        let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
        let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
        drop(v100_3);
        let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
        drop(v100_4);
        let v100_8: Space = if (v100_5).is_empty() { Space::new() } else {
          let v101_6: Path = concat_path(&(v99_6),&(v99_7_head));
          let v101_7: Space = routine_20(c, &(v101_6), &(v99_7_tail));
          compose(&(v100_5),&(v101_7))
        };
        drop(v100_5);
        let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
        drop(v100_2);
        let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
        drop(v100_9);
        let v100_12: Space = if (v100_10).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v99_6),&(v99_7_head));
          let v102_11: Space = routine_21(c, &(v102_6), &(v99_7_tail));
          drop(v102_6);
          compose(&(v100_10),&(v102_11))
        };
        drop(v100_10);
        let v100_13: Space = unite(&(v100_8),&(v100_12));
        v99_7.join_into((v100_13).clone());
      }
      drop(v99_7_cursor);
      drop(v99_6);
      compose(&(v98_5),&(v99_7))
    };
    drop(v98_5);
    let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
    drop(v98_2);
    let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
    drop(v98_9);
    let v98_11: Space = compose(&(v98_10),&(v97_8_tail));
    drop(v98_10);
    let v98_12: Space = unite(&(v98_8),&(v98_11));
    drop(v98_11);
    v97_8.join_into((v98_12).clone());
  }
  drop(v97_8_cursor);
  (v97_8).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v103_2 = Space::new();
  let mut v103_2_cursor = (*s0).read_zipper();
  for v103_2_byte in v103_2_cursor.child_mask().iter() {
    v103_2_cursor.descend_to_byte(v103_2_byte);
    let v103_2_tail = v103_2_cursor.make_map();
    v103_2_cursor.ascend(1);
    let v103_2_head = Path::from_slice(&[v103_2_byte]);
    let v104_2: Space = Space::new();
    v103_2.join_into((v104_2).clone());
  }
  drop(v103_2_cursor);
  (v103_2).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v105_6: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v105_8: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v105_16 = Space::new();
  let mut v105_16_cursor = (*s0).read_zipper();
  for v105_16_byte in v105_16_cursor.child_mask().iter() {
    v105_16_cursor.descend_to_byte(v105_16_byte);
    let v105_16_tail = v105_16_cursor.make_map();
    v105_16_cursor.ascend(1);
    let v105_16_head = Path::from_slice(&[v105_16_byte]);
    let v106_2: Space = singleton(&(v105_16_head));
    let v106_3: Space = intersect(&(*CONSTANT_1),&(v106_2));
    drop(v106_2);
    let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
    drop(v106_3);
    let v106_13: Space = if (v106_4).is_empty() { Space::new() } else {
      let v107_5: Space = unwrap(&(v105_6),&(v105_16_head));
      let v107_6: Space = restrict_to(&(*CONSTANT_4),&(v107_5));
      drop(v107_5);
      let mut v107_7 = Space::new();
      let mut v107_7_cursor = (v107_6).read_zipper();
      for v107_7_byte in v107_7_cursor.child_mask().iter() {
        v107_7_cursor.descend_to_byte(v107_7_byte);
        let v107_7_tail = v107_7_cursor.make_map();
        v107_7_cursor.ascend(1);
        let v107_7_head = Path::from_slice(&[v107_7_byte]);
        let v108_2: Space = singleton(&(v107_7_head));
        let v108_3: Space = intersect(&(*CONSTANT_1),&(v108_2));
        let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
        drop(v108_3);
        let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
        drop(v108_4);
        let v108_7: Space = if (v108_5).is_empty() { Space::new() } else {
          let v109_6: Space = routine_6(c, &(v107_7_head), &(v107_7_tail));
          compose(&(v108_5),&(v109_6))
        };
        drop(v108_5);
        let v108_8: Space = intersect(&(*CONSTANT_1),&(v108_2));
        drop(v108_2);
        let v108_9: Space = if has_head(&(v108_8)) { singleton(&[]) } else { Space::new() };
        drop(v108_8);
        let v108_11: Space = if (v108_9).is_empty() { Space::new() } else {
          let v110_10: Space = routine_7(c, &(v107_7_head), &(v107_7_tail));
          compose(&(v108_9),&(v110_10))
        };
        drop(v108_9);
        let v108_12: Space = unite(&(v108_7),&(v108_11));
        v107_7.join_into((v108_12).clone());
      }
      drop(v107_7_cursor);
      drop(v107_6);
      let v107_8: Space = restrict_to(&(*CONSTANT_3),&(v107_7));
      let mut v107_9 = Space::new();
      let mut v107_9_cursor = (v107_8).read_zipper();
      for v107_9_byte in v107_9_cursor.child_mask().iter() {
        v107_9_cursor.descend_to_byte(v107_9_byte);
        let v107_9_tail = v107_9_cursor.make_map();
        v107_9_cursor.ascend(1);
        let v107_9_head = Path::from_slice(&[v107_9_byte]);
        let v111_2: Space = singleton(&(v107_9_head));
        let v111_3: Space = intersect(&(*CONSTANT_1),&(v111_2));
        let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
        drop(v111_3);
        let v111_5: Space = subtract(&(*CONSTANT_0),&(v111_4));
        drop(v111_4);
        let v111_7: Space = if (v111_5).is_empty() { Space::new() } else {
          let v112_6: Space = routine_8(c, &(v107_9_head), &(v107_9_tail));
          compose(&(v111_5),&(v112_6))
        };
        drop(v111_5);
        let v111_8: Space = intersect(&(*CONSTANT_1),&(v111_2));
        drop(v111_2);
        let v111_9: Space = if has_head(&(v111_8)) { singleton(&[]) } else { Space::new() };
        drop(v111_8);
        let v111_11: Space = if (v111_9).is_empty() { Space::new() } else {
          let v113_10: Space = routine_9(c, &(v107_9_head), &(v107_9_tail));
          compose(&(v111_9),&(v113_10))
        };
        drop(v111_9);
        let v111_12: Space = unite(&(v111_7),&(v111_11));
        v107_9.join_into((v111_12).clone());
      }
      drop(v107_9_cursor);
      let v107_10: Space = unwrap(&(v105_8),&(v105_16_head));
      let v107_11: Space = subtract(&(v107_9),&(v107_10));
      drop(v107_10);
      let v107_12: Space = intersect(&(v107_11),&(*CONSTANT_5));
      compose(&(v106_4),&(v107_12))
    };
    drop(v106_4);
    let v106_14: Path = concat_path(&(*p0),&(v105_16_head));
    let v106_15: Space = wrap(&(v106_13),&(v106_14));
    drop(v106_14);
    v105_16.join_into((v106_15).clone());
  }
  drop(v105_16_cursor);
  drop(v105_6);
  drop(v105_8);
  (v105_16).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v114_11 = Space::new();
  let mut v114_11_cursor = (*s0).read_zipper();
  for v114_11_byte in v114_11_cursor.child_mask().iter() {
    v114_11_cursor.descend_to_byte(v114_11_byte);
    let v114_11_tail = v114_11_cursor.make_map();
    v114_11_cursor.ascend(1);
    let v114_11_head = Path::from_slice(&[v114_11_byte]);
    let v115_2: Space = singleton(&(v114_11_head));
    let v115_3: Space = intersect(&(*CONSTANT_1),&(v115_2));
    let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
    drop(v115_3);
    let v115_5: Space = subtract(&(*CONSTANT_0),&(v115_4));
    drop(v115_4);
    let v115_8: Space = if (v115_5).is_empty() { Space::new() } else {
      let v116_6: Path = concat_path(&(*p0),&(v114_11_head));
      let mut v116_7 = Space::new();
      let mut v116_7_cursor = (v114_11_tail).read_zipper();
      for v116_7_byte in v116_7_cursor.child_mask().iter() {
        v116_7_cursor.descend_to_byte(v116_7_byte);
        let v116_7_tail = v116_7_cursor.make_map();
        v116_7_cursor.ascend(1);
        let v116_7_head = Path::from_slice(&[v116_7_byte]);
        let v117_2: Space = singleton(&(v116_7_head));
        let v117_3: Space = intersect(&(*CONSTANT_1),&(v117_2));
        let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
        drop(v117_3);
        let v117_5: Space = subtract(&(*CONSTANT_0),&(v117_4));
        drop(v117_4);
        let v117_8: Space = if (v117_5).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v116_6),&(v116_7_head));
          let v118_7: Space = routine_22(c, &(v118_6), &(v116_7_tail));
          compose(&(v117_5),&(v118_7))
        };
        drop(v117_5);
        let v117_9: Space = intersect(&(*CONSTANT_1),&(v117_2));
        drop(v117_2);
        let v117_10: Space = if has_head(&(v117_9)) { singleton(&[]) } else { Space::new() };
        drop(v117_9);
        let v117_12: Space = if (v117_10).is_empty() { Space::new() } else {
          let v119_6: Path = concat_path(&(v116_6),&(v116_7_head));
          let v119_11: Space = routine_23(c, &(v119_6), &(v116_7_tail));
          drop(v119_6);
          compose(&(v117_10),&(v119_11))
        };
        drop(v117_10);
        let v117_13: Space = unite(&(v117_8),&(v117_12));
        v116_7.join_into((v117_13).clone());
      }
      drop(v116_7_cursor);
      compose(&(v115_5),&(v116_7))
    };
    drop(v115_5);
    let v115_9: Space = intersect(&(*CONSTANT_1),&(v115_2));
    drop(v115_2);
    let v115_10: Space = if has_head(&(v115_9)) { singleton(&[]) } else { Space::new() };
    drop(v115_9);
    let v115_12: Space = if (v115_10).is_empty() { Space::new() } else {
      let v120_6: Path = concat_path(&(*p0),&(v114_11_head));
      let mut v120_11 = Space::new();
      let mut v120_11_cursor = (v114_11_tail).read_zipper();
      for v120_11_byte in v120_11_cursor.child_mask().iter() {
        v120_11_cursor.descend_to_byte(v120_11_byte);
        let v120_11_tail = v120_11_cursor.make_map();
        v120_11_cursor.ascend(1);
        let v120_11_head = Path::from_slice(&[v120_11_byte]);
        let v121_2: Space = singleton(&(v120_11_head));
        let v121_3: Space = intersect(&(*CONSTANT_1),&(v121_2));
        let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
        drop(v121_3);
        let v121_5: Space = subtract(&(*CONSTANT_0),&(v121_4));
        drop(v121_4);
        let v121_8: Space = if (v121_5).is_empty() { Space::new() } else {
          let v122_6: Path = concat_path(&(v120_6),&(v120_11_head));
          let v122_7: Space = routine_22(c, &(v122_6), &(v120_11_tail));
          compose(&(v121_5),&(v122_7))
        };
        drop(v121_5);
        let v121_9: Space = intersect(&(*CONSTANT_1),&(v121_2));
        drop(v121_2);
        let v121_10: Space = if has_head(&(v121_9)) { singleton(&[]) } else { Space::new() };
        drop(v121_9);
        let v121_12: Space = if (v121_10).is_empty() { Space::new() } else {
          let v123_6: Path = concat_path(&(v120_6),&(v120_11_head));
          let v123_11: Space = routine_14(c, &(v123_6), &(v120_11_tail));
          drop(v123_6);
          compose(&(v121_10),&(v123_11))
        };
        drop(v121_10);
        let v121_13: Space = unite(&(v121_8),&(v121_12));
        v120_11.join_into((v121_13).clone());
      }
      drop(v120_11_cursor);
      drop(v120_6);
      compose(&(v115_10),&(v120_11))
    };
    drop(v115_10);
    let v115_13: Space = unite(&(v115_8),&(v115_12));
    v114_11.join_into((v115_13).clone());
  }
  drop(v114_11_cursor);
  (v114_11).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v124_8 = Space::new();
  let mut v124_8_cursor = (*s0).read_zipper();
  for v124_8_byte in v124_8_cursor.child_mask().iter() {
    v124_8_cursor.descend_to_byte(v124_8_byte);
    let v124_8_tail = v124_8_cursor.make_map();
    v124_8_cursor.ascend(1);
    let v124_8_head = Path::from_slice(&[v124_8_byte]);
    let v125_2: Space = singleton(&(v124_8_head));
    let v125_3: Space = intersect(&(*CONSTANT_1),&(v125_2));
    let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
    drop(v125_3);
    let v125_5: Space = subtract(&(*CONSTANT_0),&(v125_4));
    drop(v125_4);
    let v125_8: Space = if (v125_5).is_empty() { Space::new() } else {
      let v126_6: Path = concat_path(&(*p0),&(v124_8_head));
      let mut v126_7 = Space::new();
      let mut v126_7_cursor = (v124_8_tail).read_zipper();
      for v126_7_byte in v126_7_cursor.child_mask().iter() {
        v126_7_cursor.descend_to_byte(v126_7_byte);
        let v126_7_tail = v126_7_cursor.make_map();
        v126_7_cursor.ascend(1);
        let v126_7_head = Path::from_slice(&[v126_7_byte]);
        let v127_2: Space = singleton(&(v126_7_head));
        let v127_3: Space = intersect(&(*CONSTANT_1),&(v127_2));
        let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
        drop(v127_3);
        let v127_5: Space = subtract(&(*CONSTANT_0),&(v127_4));
        drop(v127_4);
        let v127_8: Space = if (v127_5).is_empty() { Space::new() } else {
          let v128_6: Path = concat_path(&(v126_6),&(v126_7_head));
          let v128_7: Space = routine_22(c, &(v128_6), &(v126_7_tail));
          compose(&(v127_5),&(v128_7))
        };
        drop(v127_5);
        let v127_9: Space = intersect(&(*CONSTANT_1),&(v127_2));
        drop(v127_2);
        let v127_10: Space = if has_head(&(v127_9)) { singleton(&[]) } else { Space::new() };
        drop(v127_9);
        let v127_12: Space = if (v127_10).is_empty() { Space::new() } else {
          let v129_6: Path = concat_path(&(v126_6),&(v126_7_head));
          let v129_11: Space = routine_23(c, &(v129_6), &(v126_7_tail));
          drop(v129_6);
          compose(&(v127_10),&(v129_11))
        };
        drop(v127_10);
        let v127_13: Space = unite(&(v127_8),&(v127_12));
        v126_7.join_into((v127_13).clone());
      }
      drop(v126_7_cursor);
      drop(v126_6);
      compose(&(v125_5),&(v126_7))
    };
    drop(v125_5);
    let v125_9: Space = intersect(&(*CONSTANT_1),&(v125_2));
    drop(v125_2);
    let v125_10: Space = if has_head(&(v125_9)) { singleton(&[]) } else { Space::new() };
    drop(v125_9);
    let v125_11: Space = compose(&(v125_10),&(v124_8_tail));
    drop(v125_10);
    let v125_12: Space = unite(&(v125_8),&(v125_11));
    drop(v125_11);
    v124_8.join_into((v125_12).clone());
  }
  drop(v124_8_cursor);
  (v124_8).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v131_11 = Space::new();
  let mut v131_11_cursor = (*s0).read_zipper();
  for v131_11_byte in v131_11_cursor.child_mask().iter() {
    v131_11_cursor.descend_to_byte(v131_11_byte);
    let v131_11_tail = v131_11_cursor.make_map();
    v131_11_cursor.ascend(1);
    let v131_11_head = Path::from_slice(&[v131_11_byte]);
    let v132_2: Space = singleton(&(v131_11_head));
    let v132_3: Space = intersect(&(*CONSTANT_1),&(v132_2));
    let v132_4: Space = if has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
    drop(v132_3);
    let v132_5: Space = subtract(&(*CONSTANT_0),&(v132_4));
    drop(v132_4);
    let v132_8: Space = if (v132_5).is_empty() { Space::new() } else {
      let v133_6: Path = concat_path(&(*p0),&(v131_11_head));
      let mut v133_7 = Space::new();
      let mut v133_7_cursor = (v131_11_tail).read_zipper();
      for v133_7_byte in v133_7_cursor.child_mask().iter() {
        v133_7_cursor.descend_to_byte(v133_7_byte);
        let v133_7_tail = v133_7_cursor.make_map();
        v133_7_cursor.ascend(1);
        let v133_7_head = Path::from_slice(&[v133_7_byte]);
        let v134_2: Space = singleton(&(v133_7_head));
        let v134_3: Space = intersect(&(*CONSTANT_1),&(v134_2));
        let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
        drop(v134_3);
        let v134_5: Space = subtract(&(*CONSTANT_0),&(v134_4));
        drop(v134_4);
        let v134_8: Space = if (v134_5).is_empty() { Space::new() } else {
          let v135_6: Path = concat_path(&(v133_6),&(v133_7_head));
          let v135_7: Space = routine_24(c, &(v135_6), &(v133_7_tail));
          compose(&(v134_5),&(v135_7))
        };
        drop(v134_5);
        let v134_9: Space = intersect(&(*CONSTANT_1),&(v134_2));
        drop(v134_2);
        let v134_10: Space = if has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
        drop(v134_9);
        let v134_12: Space = if (v134_10).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v133_6),&(v133_7_head));
          let v136_11: Space = routine_25(c, &(v136_6), &(v133_7_tail));
          drop(v136_6);
          compose(&(v134_10),&(v136_11))
        };
        drop(v134_10);
        let v134_13: Space = unite(&(v134_8),&(v134_12));
        v133_7.join_into((v134_13).clone());
      }
      drop(v133_7_cursor);
      compose(&(v132_5),&(v133_7))
    };
    drop(v132_5);
    let v132_9: Space = intersect(&(*CONSTANT_1),&(v132_2));
    drop(v132_2);
    let v132_10: Space = if has_head(&(v132_9)) { singleton(&[]) } else { Space::new() };
    drop(v132_9);
    let v132_12: Space = if (v132_10).is_empty() { Space::new() } else {
      let v137_6: Path = concat_path(&(*p0),&(v131_11_head));
      let mut v137_11 = Space::new();
      let mut v137_11_cursor = (v131_11_tail).read_zipper();
      for v137_11_byte in v137_11_cursor.child_mask().iter() {
        v137_11_cursor.descend_to_byte(v137_11_byte);
        let v137_11_tail = v137_11_cursor.make_map();
        v137_11_cursor.ascend(1);
        let v137_11_head = Path::from_slice(&[v137_11_byte]);
        let v138_2: Space = singleton(&(v137_11_head));
        let v138_3: Space = intersect(&(*CONSTANT_1),&(v138_2));
        let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
        drop(v138_3);
        let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
        drop(v138_4);
        let v138_8: Space = if (v138_5).is_empty() { Space::new() } else {
          let v139_6: Path = concat_path(&(v137_6),&(v137_11_head));
          let v139_7: Space = routine_24(c, &(v139_6), &(v137_11_tail));
          compose(&(v138_5),&(v139_7))
        };
        drop(v138_5);
        let v138_9: Space = intersect(&(*CONSTANT_1),&(v138_2));
        drop(v138_2);
        let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
        drop(v138_9);
        let v138_12: Space = if (v138_10).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v137_6),&(v137_11_head));
          let v140_11: Space = routine_17(c, &(v140_6), &(v137_11_tail));
          drop(v140_6);
          compose(&(v138_10),&(v140_11))
        };
        drop(v138_10);
        let v138_13: Space = unite(&(v138_8),&(v138_12));
        v137_11.join_into((v138_13).clone());
      }
      drop(v137_11_cursor);
      drop(v137_6);
      compose(&(v132_10),&(v137_11))
    };
    drop(v132_10);
    let v132_13: Space = unite(&(v132_8),&(v132_12));
    v131_11.join_into((v132_13).clone());
  }
  drop(v131_11_cursor);
  (v131_11).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v141_8 = Space::new();
  let mut v141_8_cursor = (*s0).read_zipper();
  for v141_8_byte in v141_8_cursor.child_mask().iter() {
    v141_8_cursor.descend_to_byte(v141_8_byte);
    let v141_8_tail = v141_8_cursor.make_map();
    v141_8_cursor.ascend(1);
    let v141_8_head = Path::from_slice(&[v141_8_byte]);
    let v142_2: Space = singleton(&(v141_8_head));
    let v142_3: Space = intersect(&(*CONSTANT_1),&(v142_2));
    let v142_4: Space = if has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
    drop(v142_3);
    let v142_5: Space = subtract(&(*CONSTANT_0),&(v142_4));
    drop(v142_4);
    let v142_8: Space = if (v142_5).is_empty() { Space::new() } else {
      let v143_6: Path = concat_path(&(*p0),&(v141_8_head));
      let mut v143_7 = Space::new();
      let mut v143_7_cursor = (v141_8_tail).read_zipper();
      for v143_7_byte in v143_7_cursor.child_mask().iter() {
        v143_7_cursor.descend_to_byte(v143_7_byte);
        let v143_7_tail = v143_7_cursor.make_map();
        v143_7_cursor.ascend(1);
        let v143_7_head = Path::from_slice(&[v143_7_byte]);
        let v144_2: Space = singleton(&(v143_7_head));
        let v144_3: Space = intersect(&(*CONSTANT_1),&(v144_2));
        let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
        drop(v144_3);
        let v144_5: Space = subtract(&(*CONSTANT_0),&(v144_4));
        drop(v144_4);
        let v144_8: Space = if (v144_5).is_empty() { Space::new() } else {
          let v145_6: Path = concat_path(&(v143_6),&(v143_7_head));
          let v145_7: Space = routine_24(c, &(v145_6), &(v143_7_tail));
          compose(&(v144_5),&(v145_7))
        };
        drop(v144_5);
        let v144_9: Space = intersect(&(*CONSTANT_1),&(v144_2));
        drop(v144_2);
        let v144_10: Space = if has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
        drop(v144_9);
        let v144_12: Space = if (v144_10).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v143_6),&(v143_7_head));
          let v146_11: Space = routine_25(c, &(v146_6), &(v143_7_tail));
          drop(v146_6);
          compose(&(v144_10),&(v146_11))
        };
        drop(v144_10);
        let v144_13: Space = unite(&(v144_8),&(v144_12));
        v143_7.join_into((v144_13).clone());
      }
      drop(v143_7_cursor);
      drop(v143_6);
      compose(&(v142_5),&(v143_7))
    };
    drop(v142_5);
    let v142_9: Space = intersect(&(*CONSTANT_1),&(v142_2));
    drop(v142_2);
    let v142_10: Space = if has_head(&(v142_9)) { singleton(&[]) } else { Space::new() };
    drop(v142_9);
    let v142_11: Space = compose(&(v142_10),&(v141_8_tail));
    drop(v142_10);
    let v142_12: Space = unite(&(v142_8),&(v142_11));
    drop(v142_11);
    v141_8.join_into((v142_12).clone());
  }
  drop(v141_8_cursor);
  (v141_8).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v148_11 = Space::new();
  let mut v148_11_cursor = (*s0).read_zipper();
  for v148_11_byte in v148_11_cursor.child_mask().iter() {
    v148_11_cursor.descend_to_byte(v148_11_byte);
    let v148_11_tail = v148_11_cursor.make_map();
    v148_11_cursor.ascend(1);
    let v148_11_head = Path::from_slice(&[v148_11_byte]);
    let v149_2: Space = singleton(&(v148_11_head));
    let v149_3: Space = intersect(&(*CONSTANT_1),&(v149_2));
    let v149_4: Space = if has_head(&(v149_3)) { singleton(&[]) } else { Space::new() };
    drop(v149_3);
    let v149_5: Space = subtract(&(*CONSTANT_0),&(v149_4));
    drop(v149_4);
    let v149_8: Space = if (v149_5).is_empty() { Space::new() } else {
      let v150_6: Path = concat_path(&(*p0),&(v148_11_head));
      let mut v150_7 = Space::new();
      let mut v150_7_cursor = (v148_11_tail).read_zipper();
      for v150_7_byte in v150_7_cursor.child_mask().iter() {
        v150_7_cursor.descend_to_byte(v150_7_byte);
        let v150_7_tail = v150_7_cursor.make_map();
        v150_7_cursor.ascend(1);
        let v150_7_head = Path::from_slice(&[v150_7_byte]);
        let v151_2: Space = singleton(&(v150_7_head));
        let v151_3: Space = intersect(&(*CONSTANT_1),&(v151_2));
        let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
        drop(v151_3);
        let v151_5: Space = subtract(&(*CONSTANT_0),&(v151_4));
        drop(v151_4);
        let v151_8: Space = if (v151_5).is_empty() { Space::new() } else {
          let v152_6: Path = concat_path(&(v150_6),&(v150_7_head));
          let v152_7: Space = routine_26(c, &(v152_6), &(v150_7_tail));
          compose(&(v151_5),&(v152_7))
        };
        drop(v151_5);
        let v151_9: Space = intersect(&(*CONSTANT_1),&(v151_2));
        drop(v151_2);
        let v151_10: Space = if has_head(&(v151_9)) { singleton(&[]) } else { Space::new() };
        drop(v151_9);
        let v151_12: Space = if (v151_10).is_empty() { Space::new() } else {
          let v153_6: Path = concat_path(&(v150_6),&(v150_7_head));
          let v153_11: Space = routine_27(c, &(v153_6), &(v150_7_tail));
          drop(v153_6);
          compose(&(v151_10),&(v153_11))
        };
        drop(v151_10);
        let v151_13: Space = unite(&(v151_8),&(v151_12));
        v150_7.join_into((v151_13).clone());
      }
      drop(v150_7_cursor);
      compose(&(v149_5),&(v150_7))
    };
    drop(v149_5);
    let v149_9: Space = intersect(&(*CONSTANT_1),&(v149_2));
    drop(v149_2);
    let v149_10: Space = if has_head(&(v149_9)) { singleton(&[]) } else { Space::new() };
    drop(v149_9);
    let v149_12: Space = if (v149_10).is_empty() { Space::new() } else {
      let v154_6: Path = concat_path(&(*p0),&(v148_11_head));
      let mut v154_11 = Space::new();
      let mut v154_11_cursor = (v148_11_tail).read_zipper();
      for v154_11_byte in v154_11_cursor.child_mask().iter() {
        v154_11_cursor.descend_to_byte(v154_11_byte);
        let v154_11_tail = v154_11_cursor.make_map();
        v154_11_cursor.ascend(1);
        let v154_11_head = Path::from_slice(&[v154_11_byte]);
        let v155_2: Space = singleton(&(v154_11_head));
        let v155_3: Space = intersect(&(*CONSTANT_1),&(v155_2));
        let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
        drop(v155_3);
        let v155_5: Space = subtract(&(*CONSTANT_0),&(v155_4));
        drop(v155_4);
        let v155_8: Space = if (v155_5).is_empty() { Space::new() } else {
          let v156_6: Path = concat_path(&(v154_6),&(v154_11_head));
          let v156_7: Space = routine_26(c, &(v156_6), &(v154_11_tail));
          compose(&(v155_5),&(v156_7))
        };
        drop(v155_5);
        let v155_9: Space = intersect(&(*CONSTANT_1),&(v155_2));
        drop(v155_2);
        let v155_10: Space = if has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
        drop(v155_9);
        let v155_12: Space = if (v155_10).is_empty() { Space::new() } else {
          let v157_6: Path = concat_path(&(v154_6),&(v154_11_head));
          let v157_11: Space = routine_14(c, &(v157_6), &(v154_11_tail));
          drop(v157_6);
          compose(&(v155_10),&(v157_11))
        };
        drop(v155_10);
        let v155_13: Space = unite(&(v155_8),&(v155_12));
        v154_11.join_into((v155_13).clone());
      }
      drop(v154_11_cursor);
      drop(v154_6);
      compose(&(v149_10),&(v154_11))
    };
    drop(v149_10);
    let v149_13: Space = unite(&(v149_8),&(v149_12));
    v148_11.join_into((v149_13).clone());
  }
  drop(v148_11_cursor);
  (v148_11).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v158_8 = Space::new();
  let mut v158_8_cursor = (*s0).read_zipper();
  for v158_8_byte in v158_8_cursor.child_mask().iter() {
    v158_8_cursor.descend_to_byte(v158_8_byte);
    let v158_8_tail = v158_8_cursor.make_map();
    v158_8_cursor.ascend(1);
    let v158_8_head = Path::from_slice(&[v158_8_byte]);
    let v159_2: Space = singleton(&(v158_8_head));
    let v159_3: Space = intersect(&(*CONSTANT_1),&(v159_2));
    let v159_4: Space = if has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
    drop(v159_3);
    let v159_5: Space = subtract(&(*CONSTANT_0),&(v159_4));
    drop(v159_4);
    let v159_8: Space = if (v159_5).is_empty() { Space::new() } else {
      let v160_6: Path = concat_path(&(*p0),&(v158_8_head));
      let mut v160_7 = Space::new();
      let mut v160_7_cursor = (v158_8_tail).read_zipper();
      for v160_7_byte in v160_7_cursor.child_mask().iter() {
        v160_7_cursor.descend_to_byte(v160_7_byte);
        let v160_7_tail = v160_7_cursor.make_map();
        v160_7_cursor.ascend(1);
        let v160_7_head = Path::from_slice(&[v160_7_byte]);
        let v161_2: Space = singleton(&(v160_7_head));
        let v161_3: Space = intersect(&(*CONSTANT_1),&(v161_2));
        let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
        drop(v161_3);
        let v161_5: Space = subtract(&(*CONSTANT_0),&(v161_4));
        drop(v161_4);
        let v161_8: Space = if (v161_5).is_empty() { Space::new() } else {
          let v162_6: Path = concat_path(&(v160_6),&(v160_7_head));
          let v162_7: Space = routine_26(c, &(v162_6), &(v160_7_tail));
          compose(&(v161_5),&(v162_7))
        };
        drop(v161_5);
        let v161_9: Space = intersect(&(*CONSTANT_1),&(v161_2));
        drop(v161_2);
        let v161_10: Space = if has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
        drop(v161_9);
        let v161_12: Space = if (v161_10).is_empty() { Space::new() } else {
          let v163_6: Path = concat_path(&(v160_6),&(v160_7_head));
          let v163_11: Space = routine_27(c, &(v163_6), &(v160_7_tail));
          drop(v163_6);
          compose(&(v161_10),&(v163_11))
        };
        drop(v161_10);
        let v161_13: Space = unite(&(v161_8),&(v161_12));
        v160_7.join_into((v161_13).clone());
      }
      drop(v160_7_cursor);
      drop(v160_6);
      compose(&(v159_5),&(v160_7))
    };
    drop(v159_5);
    let v159_9: Space = intersect(&(*CONSTANT_1),&(v159_2));
    drop(v159_2);
    let v159_10: Space = if has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
    drop(v159_9);
    let v159_11: Space = compose(&(v159_10),&(v158_8_tail));
    drop(v159_10);
    let v159_12: Space = unite(&(v159_8),&(v159_11));
    drop(v159_11);
    v158_8.join_into((v159_12).clone());
  }
  drop(v158_8_cursor);
  (v158_8).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v164_11 = Space::new();
  let mut v164_11_cursor = (*s0).read_zipper();
  for v164_11_byte in v164_11_cursor.child_mask().iter() {
    v164_11_cursor.descend_to_byte(v164_11_byte);
    let v164_11_tail = v164_11_cursor.make_map();
    v164_11_cursor.ascend(1);
    let v164_11_head = Path::from_slice(&[v164_11_byte]);
    let v165_2: Space = singleton(&(v164_11_head));
    let v165_3: Space = intersect(&(*CONSTANT_1),&(v165_2));
    let v165_4: Space = if has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
    drop(v165_3);
    let v165_5: Space = subtract(&(*CONSTANT_0),&(v165_4));
    drop(v165_4);
    let v165_8: Space = if (v165_5).is_empty() { Space::new() } else {
      let v166_6: Path = concat_path(&(*p0),&(v164_11_head));
      let mut v166_7 = Space::new();
      let mut v166_7_cursor = (v164_11_tail).read_zipper();
      for v166_7_byte in v166_7_cursor.child_mask().iter() {
        v166_7_cursor.descend_to_byte(v166_7_byte);
        let v166_7_tail = v166_7_cursor.make_map();
        v166_7_cursor.ascend(1);
        let v166_7_head = Path::from_slice(&[v166_7_byte]);
        let v167_2: Space = singleton(&(v166_7_head));
        let v167_3: Space = intersect(&(*CONSTANT_1),&(v167_2));
        let v167_4: Space = if has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
        drop(v167_3);
        let v167_5: Space = subtract(&(*CONSTANT_0),&(v167_4));
        drop(v167_4);
        let v167_8: Space = if (v167_5).is_empty() { Space::new() } else {
          let v168_6: Path = concat_path(&(v166_6),&(v166_7_head));
          let v168_7: Space = routine_28(c, &(v168_6), &(v166_7_tail));
          compose(&(v167_5),&(v168_7))
        };
        drop(v167_5);
        let v167_9: Space = intersect(&(*CONSTANT_1),&(v167_2));
        drop(v167_2);
        let v167_10: Space = if has_head(&(v167_9)) { singleton(&[]) } else { Space::new() };
        drop(v167_9);
        let v167_12: Space = if (v167_10).is_empty() { Space::new() } else {
          let v169_6: Path = concat_path(&(v166_6),&(v166_7_head));
          let v169_11: Space = routine_29(c, &(v169_6), &(v166_7_tail));
          drop(v169_6);
          compose(&(v167_10),&(v169_11))
        };
        drop(v167_10);
        let v167_13: Space = unite(&(v167_8),&(v167_12));
        v166_7.join_into((v167_13).clone());
      }
      drop(v166_7_cursor);
      compose(&(v165_5),&(v166_7))
    };
    drop(v165_5);
    let v165_9: Space = intersect(&(*CONSTANT_1),&(v165_2));
    drop(v165_2);
    let v165_10: Space = if has_head(&(v165_9)) { singleton(&[]) } else { Space::new() };
    drop(v165_9);
    let v165_12: Space = if (v165_10).is_empty() { Space::new() } else {
      let v170_6: Path = concat_path(&(*p0),&(v164_11_head));
      let mut v170_11 = Space::new();
      let mut v170_11_cursor = (v164_11_tail).read_zipper();
      for v170_11_byte in v170_11_cursor.child_mask().iter() {
        v170_11_cursor.descend_to_byte(v170_11_byte);
        let v170_11_tail = v170_11_cursor.make_map();
        v170_11_cursor.ascend(1);
        let v170_11_head = Path::from_slice(&[v170_11_byte]);
        let v171_2: Space = singleton(&(v170_11_head));
        let v171_3: Space = intersect(&(*CONSTANT_1),&(v171_2));
        let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
        drop(v171_3);
        let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
        drop(v171_4);
        let v171_8: Space = if (v171_5).is_empty() { Space::new() } else {
          let v172_6: Path = concat_path(&(v170_6),&(v170_11_head));
          let v172_7: Space = routine_28(c, &(v172_6), &(v170_11_tail));
          compose(&(v171_5),&(v172_7))
        };
        drop(v171_5);
        let v171_9: Space = intersect(&(*CONSTANT_1),&(v171_2));
        drop(v171_2);
        let v171_10: Space = if has_head(&(v171_9)) { singleton(&[]) } else { Space::new() };
        drop(v171_9);
        let v171_12: Space = if (v171_10).is_empty() { Space::new() } else {
          let v173_6: Path = concat_path(&(v170_6),&(v170_11_head));
          let v173_11: Space = routine_17(c, &(v173_6), &(v170_11_tail));
          drop(v173_6);
          compose(&(v171_10),&(v173_11))
        };
        drop(v171_10);
        let v171_13: Space = unite(&(v171_8),&(v171_12));
        v170_11.join_into((v171_13).clone());
      }
      drop(v170_11_cursor);
      drop(v170_6);
      compose(&(v165_10),&(v170_11))
    };
    drop(v165_10);
    let v165_13: Space = unite(&(v165_8),&(v165_12));
    v164_11.join_into((v165_13).clone());
  }
  drop(v164_11_cursor);
  (v164_11).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v174_8 = Space::new();
  let mut v174_8_cursor = (*s0).read_zipper();
  for v174_8_byte in v174_8_cursor.child_mask().iter() {
    v174_8_cursor.descend_to_byte(v174_8_byte);
    let v174_8_tail = v174_8_cursor.make_map();
    v174_8_cursor.ascend(1);
    let v174_8_head = Path::from_slice(&[v174_8_byte]);
    let v175_2: Space = singleton(&(v174_8_head));
    let v175_3: Space = intersect(&(*CONSTANT_1),&(v175_2));
    let v175_4: Space = if has_head(&(v175_3)) { singleton(&[]) } else { Space::new() };
    drop(v175_3);
    let v175_5: Space = subtract(&(*CONSTANT_0),&(v175_4));
    drop(v175_4);
    let v175_8: Space = if (v175_5).is_empty() { Space::new() } else {
      let v176_6: Path = concat_path(&(*p0),&(v174_8_head));
      let mut v176_7 = Space::new();
      let mut v176_7_cursor = (v174_8_tail).read_zipper();
      for v176_7_byte in v176_7_cursor.child_mask().iter() {
        v176_7_cursor.descend_to_byte(v176_7_byte);
        let v176_7_tail = v176_7_cursor.make_map();
        v176_7_cursor.ascend(1);
        let v176_7_head = Path::from_slice(&[v176_7_byte]);
        let v177_2: Space = singleton(&(v176_7_head));
        let v177_3: Space = intersect(&(*CONSTANT_1),&(v177_2));
        let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
        drop(v177_3);
        let v177_5: Space = subtract(&(*CONSTANT_0),&(v177_4));
        drop(v177_4);
        let v177_8: Space = if (v177_5).is_empty() { Space::new() } else {
          let v178_6: Path = concat_path(&(v176_6),&(v176_7_head));
          let v178_7: Space = routine_28(c, &(v178_6), &(v176_7_tail));
          compose(&(v177_5),&(v178_7))
        };
        drop(v177_5);
        let v177_9: Space = intersect(&(*CONSTANT_1),&(v177_2));
        drop(v177_2);
        let v177_10: Space = if has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
        drop(v177_9);
        let v177_12: Space = if (v177_10).is_empty() { Space::new() } else {
          let v179_6: Path = concat_path(&(v176_6),&(v176_7_head));
          let v179_11: Space = routine_29(c, &(v179_6), &(v176_7_tail));
          drop(v179_6);
          compose(&(v177_10),&(v179_11))
        };
        drop(v177_10);
        let v177_13: Space = unite(&(v177_8),&(v177_12));
        v176_7.join_into((v177_13).clone());
      }
      drop(v176_7_cursor);
      drop(v176_6);
      compose(&(v175_5),&(v176_7))
    };
    drop(v175_5);
    let v175_9: Space = intersect(&(*CONSTANT_1),&(v175_2));
    drop(v175_2);
    let v175_10: Space = if has_head(&(v175_9)) { singleton(&[]) } else { Space::new() };
    drop(v175_9);
    let v175_11: Space = compose(&(v175_10),&(v174_8_tail));
    drop(v175_10);
    let v175_12: Space = unite(&(v175_8),&(v175_11));
    drop(v175_11);
    v174_8.join_into((v175_12).clone());
  }
  drop(v174_8_cursor);
  (v174_8).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v180_6 = Space::new();
  let mut v180_6_cursor = (*s0).read_zipper();
  for v180_6_byte in v180_6_cursor.child_mask().iter() {
    v180_6_cursor.descend_to_byte(v180_6_byte);
    let v180_6_tail = v180_6_cursor.make_map();
    v180_6_cursor.ascend(1);
    let v180_6_head = Path::from_slice(&[v180_6_byte]);
    let v181_2: Space = singleton(&(v180_6_head));
    let v181_3: Space = intersect(&(*CONSTANT_1),&(v181_2));
    let v181_4: Space = if has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
    drop(v181_3);
    let v181_5: Space = subtract(&(*CONSTANT_0),&(v181_4));
    drop(v181_4);
    let mut v181_6 = Space::new();
    let mut v181_6_cursor = (v180_6_tail).read_zipper();
    for v181_6_byte in v181_6_cursor.child_mask().iter() {
      v181_6_cursor.descend_to_byte(v181_6_byte);
      let v181_6_tail = v181_6_cursor.make_map();
      v181_6_cursor.ascend(1);
      let v181_6_head = Path::from_slice(&[v181_6_byte]);
      let v182_2: Space = Space::new();
      v181_6.join_into((v182_2).clone());
    }
    drop(v181_6_cursor);
    let v181_7: Space = compose(&(v181_5),&(v181_6));
    drop(v181_5);
    drop(v181_6);
    let v181_8: Space = intersect(&(*CONSTANT_1),&(v181_2));
    drop(v181_2);
    let v181_9: Space = if has_head(&(v181_8)) { singleton(&[]) } else { Space::new() };
    drop(v181_8);
    let v181_12: Space = if (v181_9).is_empty() { Space::new() } else {
      let v183_10: Path = concat_path(&(*p0),&(v180_6_head));
      let mut v183_11 = Space::new();
      let mut v183_11_cursor = (v180_6_tail).read_zipper();
      for v183_11_byte in v183_11_cursor.child_mask().iter() {
        v183_11_cursor.descend_to_byte(v183_11_byte);
        let v183_11_tail = v183_11_cursor.make_map();
        v183_11_cursor.ascend(1);
        let v183_11_head = Path::from_slice(&[v183_11_byte]);
        let v184_2: Space = singleton(&(v183_11_head));
        let v184_3: Space = intersect(&(*CONSTANT_1),&(v184_2));
        drop(v184_2);
        let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
        drop(v184_3);
        let v184_7: Space = if (v184_4).is_empty() { Space::new() } else {
          let v185_5: Path = concat_path(&(v183_10),&(v183_11_head));
          let v185_6: Space = routine_14(c, &(v185_5), &(v183_11_tail));
          drop(v185_5);
          compose(&(v184_4),&(v185_6))
        };
        drop(v184_4);
        v183_11.join_into((v184_7).clone());
      }
      drop(v183_11_cursor);
      drop(v183_10);
      compose(&(v181_9),&(v183_11))
    };
    drop(v181_9);
    let v181_13: Space = unite(&(v181_7),&(v181_12));
    drop(v181_7);
    v180_6.join_into((v181_13).clone());
  }
  drop(v180_6_cursor);
  (v180_6).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v186_5 = Space::new();
  let mut v186_5_cursor = (*s0).read_zipper();
  for v186_5_byte in v186_5_cursor.child_mask().iter() {
    v186_5_cursor.descend_to_byte(v186_5_byte);
    let v186_5_tail = v186_5_cursor.make_map();
    v186_5_cursor.ascend(1);
    let v186_5_head = Path::from_slice(&[v186_5_byte]);
    let v187_2: Space = singleton(&(v186_5_head));
    let v187_3: Space = intersect(&(*CONSTANT_1),&(v187_2));
    let v187_4: Space = if has_head(&(v187_3)) { singleton(&[]) } else { Space::new() };
    drop(v187_3);
    let v187_5: Space = subtract(&(*CONSTANT_0),&(v187_4));
    drop(v187_4);
    let mut v187_6 = Space::new();
    let mut v187_6_cursor = (v186_5_tail).read_zipper();
    for v187_6_byte in v187_6_cursor.child_mask().iter() {
      v187_6_cursor.descend_to_byte(v187_6_byte);
      let v187_6_tail = v187_6_cursor.make_map();
      v187_6_cursor.ascend(1);
      let v187_6_head = Path::from_slice(&[v187_6_byte]);
      let v188_2: Space = Space::new();
      v187_6.join_into((v188_2).clone());
    }
    drop(v187_6_cursor);
    let v187_7: Space = compose(&(v187_5),&(v187_6));
    drop(v187_5);
    drop(v187_6);
    let v187_8: Space = intersect(&(*CONSTANT_1),&(v187_2));
    drop(v187_2);
    let v187_9: Space = if has_head(&(v187_8)) { singleton(&[]) } else { Space::new() };
    drop(v187_8);
    let v187_10: Space = compose(&(v187_9),&(v186_5_tail));
    drop(v187_9);
    let v187_11: Space = unite(&(v187_7),&(v187_10));
    drop(v187_7);
    drop(v187_10);
    v186_5.join_into((v187_11).clone());
  }
  drop(v186_5_cursor);
  (v186_5).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v189_6 = Space::new();
  let mut v189_6_cursor = (*s0).read_zipper();
  for v189_6_byte in v189_6_cursor.child_mask().iter() {
    v189_6_cursor.descend_to_byte(v189_6_byte);
    let v189_6_tail = v189_6_cursor.make_map();
    v189_6_cursor.ascend(1);
    let v189_6_head = Path::from_slice(&[v189_6_byte]);
    let v190_2: Space = singleton(&(v189_6_head));
    let v190_3: Space = intersect(&(*CONSTANT_1),&(v190_2));
    let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
    drop(v190_3);
    let v190_5: Space = subtract(&(*CONSTANT_0),&(v190_4));
    drop(v190_4);
    let mut v190_6 = Space::new();
    let mut v190_6_cursor = (v189_6_tail).read_zipper();
    for v190_6_byte in v190_6_cursor.child_mask().iter() {
      v190_6_cursor.descend_to_byte(v190_6_byte);
      let v190_6_tail = v190_6_cursor.make_map();
      v190_6_cursor.ascend(1);
      let v190_6_head = Path::from_slice(&[v190_6_byte]);
      let v191_2: Space = Space::new();
      v190_6.join_into((v191_2).clone());
    }
    drop(v190_6_cursor);
    let v190_7: Space = compose(&(v190_5),&(v190_6));
    drop(v190_5);
    drop(v190_6);
    let v190_8: Space = intersect(&(*CONSTANT_1),&(v190_2));
    drop(v190_2);
    let v190_9: Space = if has_head(&(v190_8)) { singleton(&[]) } else { Space::new() };
    drop(v190_8);
    let v190_12: Space = if (v190_9).is_empty() { Space::new() } else {
      let v192_10: Path = concat_path(&(*p0),&(v189_6_head));
      let mut v192_11 = Space::new();
      let mut v192_11_cursor = (v189_6_tail).read_zipper();
      for v192_11_byte in v192_11_cursor.child_mask().iter() {
        v192_11_cursor.descend_to_byte(v192_11_byte);
        let v192_11_tail = v192_11_cursor.make_map();
        v192_11_cursor.ascend(1);
        let v192_11_head = Path::from_slice(&[v192_11_byte]);
        let v193_2: Space = singleton(&(v192_11_head));
        let v193_3: Space = intersect(&(*CONSTANT_1),&(v193_2));
        drop(v193_2);
        let v193_4: Space = if has_head(&(v193_3)) { singleton(&[]) } else { Space::new() };
        drop(v193_3);
        let v193_7: Space = if (v193_4).is_empty() { Space::new() } else {
          let v194_5: Path = concat_path(&(v192_10),&(v192_11_head));
          let v194_6: Space = routine_17(c, &(v194_5), &(v192_11_tail));
          drop(v194_5);
          compose(&(v193_4),&(v194_6))
        };
        drop(v193_4);
        v192_11.join_into((v193_7).clone());
      }
      drop(v192_11_cursor);
      drop(v192_10);
      compose(&(v190_9),&(v192_11))
    };
    drop(v190_9);
    let v190_13: Space = unite(&(v190_7),&(v190_12));
    drop(v190_7);
    v189_6.join_into((v190_13).clone());
  }
  drop(v189_6_cursor);
  (v189_6).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v195_5 = Space::new();
  let mut v195_5_cursor = (*s0).read_zipper();
  for v195_5_byte in v195_5_cursor.child_mask().iter() {
    v195_5_cursor.descend_to_byte(v195_5_byte);
    let v195_5_tail = v195_5_cursor.make_map();
    v195_5_cursor.ascend(1);
    let v195_5_head = Path::from_slice(&[v195_5_byte]);
    let v196_2: Space = singleton(&(v195_5_head));
    let v196_3: Space = intersect(&(*CONSTANT_1),&(v196_2));
    let v196_4: Space = if has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
    drop(v196_3);
    let v196_5: Space = subtract(&(*CONSTANT_0),&(v196_4));
    drop(v196_4);
    let mut v196_6 = Space::new();
    let mut v196_6_cursor = (v195_5_tail).read_zipper();
    for v196_6_byte in v196_6_cursor.child_mask().iter() {
      v196_6_cursor.descend_to_byte(v196_6_byte);
      let v196_6_tail = v196_6_cursor.make_map();
      v196_6_cursor.ascend(1);
      let v196_6_head = Path::from_slice(&[v196_6_byte]);
      let v197_2: Space = Space::new();
      v196_6.join_into((v197_2).clone());
    }
    drop(v196_6_cursor);
    let v196_7: Space = compose(&(v196_5),&(v196_6));
    drop(v196_5);
    drop(v196_6);
    let v196_8: Space = intersect(&(*CONSTANT_1),&(v196_2));
    drop(v196_2);
    let v196_9: Space = if has_head(&(v196_8)) { singleton(&[]) } else { Space::new() };
    drop(v196_8);
    let v196_10: Space = compose(&(v196_9),&(v195_5_tail));
    drop(v196_9);
    let v196_11: Space = unite(&(v196_7),&(v196_10));
    drop(v196_7);
    drop(v196_10);
    v195_5.join_into((v196_11).clone());
  }
  drop(v195_5_cursor);
  (v195_5).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v198_2 = Space::new();
  let mut v198_2_cursor = (*s0).read_zipper();
  for v198_2_byte in v198_2_cursor.child_mask().iter() {
    v198_2_cursor.descend_to_byte(v198_2_byte);
    let v198_2_tail = v198_2_cursor.make_map();
    v198_2_cursor.ascend(1);
    let v198_2_head = Path::from_slice(&[v198_2_byte]);
    let v199_2: Space = Space::new();
    v198_2.join_into((v199_2).clone());
  }
  drop(v198_2_cursor);
  (v198_2).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v200_3 = Space::new();
  let mut v200_3_cursor = (*s0).read_zipper();
  for v200_3_byte in v200_3_cursor.child_mask().iter() {
    v200_3_cursor.descend_to_byte(v200_3_byte);
    let v200_3_tail = v200_3_cursor.make_map();
    v200_3_cursor.ascend(1);
    let v200_3_head = Path::from_slice(&[v200_3_byte]);
    let v201_2: Space = singleton(&(v200_3_head));
    let v201_3: Space = intersect(&(*CONSTANT_1),&(v201_2));
    drop(v201_2);
    let v201_4: Space = if has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
    drop(v201_3);
    let v201_5: Space = compose(&(v201_4),&(v200_3_tail));
    drop(v201_4);
    v200_3.join_into((v201_5).clone());
  }
  drop(v200_3_cursor);
  (v200_3).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v202_2 = Space::new();
  let mut v202_2_cursor = (*s0).read_zipper();
  for v202_2_byte in v202_2_cursor.child_mask().iter() {
    v202_2_cursor.descend_to_byte(v202_2_byte);
    let v202_2_tail = v202_2_cursor.make_map();
    v202_2_cursor.ascend(1);
    let v202_2_head = Path::from_slice(&[v202_2_byte]);
    let v203_2: Space = Space::new();
    v202_2.join_into((v203_2).clone());
  }
  drop(v202_2_cursor);
  (v202_2).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v204_3 = Space::new();
  let mut v204_3_cursor = (*s0).read_zipper();
  for v204_3_byte in v204_3_cursor.child_mask().iter() {
    v204_3_cursor.descend_to_byte(v204_3_byte);
    let v204_3_tail = v204_3_cursor.make_map();
    v204_3_cursor.ascend(1);
    let v204_3_head = Path::from_slice(&[v204_3_byte]);
    let v205_2: Space = singleton(&(v204_3_head));
    let v205_3: Space = intersect(&(*CONSTANT_1),&(v205_2));
    drop(v205_2);
    let v205_4: Space = if has_head(&(v205_3)) { singleton(&[]) } else { Space::new() };
    drop(v205_3);
    let v205_5: Space = compose(&(v205_4),&(v204_3_tail));
    drop(v205_4);
    v204_3.join_into((v205_5).clone());
  }
  drop(v204_3_cursor);
  (v204_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
