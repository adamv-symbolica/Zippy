#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[65,117,110,116,0]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 8 66 111 98 0 65 110 110 0 8 66 111 98 0 80 97 116 0 8 80 97 109 0 66 111 98 0 8 80 97 116 0 74 105 109 0 8 84 111 109 0 66 111 98 0 8 84 111 109 0 76 105 122 0"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 8 65 110 110 0 66 111 98 0 8 66 111 98 0 80 97 109 0 8 66 111 98 0 84 111 109 0 8 74 105 109 0 80 97 116 0 8 76 105 122 0 84 111 109 0 8 80 97 116 0 66 111 98 0"));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 4 65 110 110 0 4 76 105 122 0 4 80 97 109 0 4 80 97 116 0"));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_4 = Space::new();
  let mut v0_4_cursor = (*s0.expect("unbound native input")).read_zipper();
  for v0_4_byte in v0_4_cursor.child_mask().iter() {
    v0_4_cursor.descend_to_byte(v0_4_byte);
    let v0_4_tail = v0_4_cursor.make_map();
    v0_4_cursor.ascend(1);
    let v0_4_head = Path::from_slice(&[v0_4_byte]);
    let v1_2: Space = singleton(&(v0_4_head));
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let v2_6: Space = routine_1(c, &(v0_4_head), &(v0_4_tail));
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let v3_10: Space = routine_2(c, &(v0_4_head), &(v0_4_tail));
      compose(&(v1_9),&(v3_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_4.join_into((v1_12).clone());
  }
  drop(v0_4_cursor);
  let v0_6: Space = wrap(&(v0_4),&(*CONSTANT_2));
  (v0_6).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v4_8: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v4_10: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v4_18 = Space::new();
  let mut v4_18_cursor = (*s0).read_zipper();
  for v4_18_byte in v4_18_cursor.child_mask().iter() {
    v4_18_cursor.descend_to_byte(v4_18_byte);
    let v4_18_tail = v4_18_cursor.make_map();
    v4_18_cursor.ascend(1);
    let v4_18_head = Path::from_slice(&[v4_18_byte]);
    let v5_2: Space = singleton(&(v4_18_head));
    let v5_3: Space = intersect(&(*CONSTANT_1),&(v5_2));
    let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
    drop(v5_3);
    let v5_5: Space = subtract(&(*CONSTANT_0),&(v5_4));
    drop(v5_4);
    let v5_8: Space = if (v5_5).is_empty() { Space::new() } else {
      let v6_6: Path = concat_path(&(*p0),&(v4_18_head));
      let v6_7: Space = routine_1(c, &(v6_6), &(v4_18_tail));
      compose(&(v5_5),&(v6_7))
    };
    drop(v5_5);
    let v5_9: Space = intersect(&(*CONSTANT_1),&(v5_2));
    drop(v5_2);
    let v5_10: Space = if has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
    drop(v5_9);
    let v5_19: Space = if (v5_10).is_empty() { Space::new() } else {
      let v7_11: Space = unwrap(&(v4_8),&(v4_18_head));
      let v7_12: Space = restrict_to(&(*CONSTANT_4),&(v7_11));
      drop(v7_11);
      let mut v7_13 = Space::new();
      let mut v7_13_cursor = (v7_12).read_zipper();
      for v7_13_byte in v7_13_cursor.child_mask().iter() {
        v7_13_cursor.descend_to_byte(v7_13_byte);
        let v7_13_tail = v7_13_cursor.make_map();
        v7_13_cursor.ascend(1);
        let v7_13_head = Path::from_slice(&[v7_13_byte]);
        let v8_2: Space = singleton(&(v7_13_head));
        let v8_3: Space = intersect(&(*CONSTANT_1),&(v8_2));
        let v8_4: Space = if has_head(&(v8_3)) { singleton(&[]) } else { Space::new() };
        drop(v8_3);
        let v8_5: Space = subtract(&(*CONSTANT_0),&(v8_4));
        drop(v8_4);
        let v8_7: Space = if (v8_5).is_empty() { Space::new() } else {
          let v9_6: Space = routine_3(c, &(v7_13_head), &(v7_13_tail));
          compose(&(v8_5),&(v9_6))
        };
        drop(v8_5);
        let v8_8: Space = intersect(&(*CONSTANT_1),&(v8_2));
        drop(v8_2);
        let v8_9: Space = if has_head(&(v8_8)) { singleton(&[]) } else { Space::new() };
        drop(v8_8);
        let v8_11: Space = if (v8_9).is_empty() { Space::new() } else {
          let v10_10: Space = routine_4(c, &(v7_13_head), &(v7_13_tail));
          compose(&(v8_9),&(v10_10))
        };
        drop(v8_9);
        let v8_12: Space = unite(&(v8_7),&(v8_11));
        v7_13.join_into((v8_12).clone());
      }
      drop(v7_13_cursor);
      drop(v7_12);
      let v7_14: Space = restrict_to(&(*CONSTANT_3),&(v7_13));
      let mut v7_15 = Space::new();
      let mut v7_15_cursor = (v7_14).read_zipper();
      for v7_15_byte in v7_15_cursor.child_mask().iter() {
        v7_15_cursor.descend_to_byte(v7_15_byte);
        let v7_15_tail = v7_15_cursor.make_map();
        v7_15_cursor.ascend(1);
        let v7_15_head = Path::from_slice(&[v7_15_byte]);
        let v11_2: Space = singleton(&(v7_15_head));
        let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
        let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
        drop(v11_3);
        let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
        drop(v11_4);
        let v11_7: Space = if (v11_5).is_empty() { Space::new() } else {
          let v12_6: Space = routine_5(c, &(v7_15_head), &(v7_15_tail));
          compose(&(v11_5),&(v12_6))
        };
        drop(v11_5);
        let v11_8: Space = intersect(&(*CONSTANT_1),&(v11_2));
        drop(v11_2);
        let v11_9: Space = if has_head(&(v11_8)) { singleton(&[]) } else { Space::new() };
        drop(v11_8);
        let v11_11: Space = if (v11_9).is_empty() { Space::new() } else {
          let v13_10: Space = routine_6(c, &(v7_15_head), &(v7_15_tail));
          compose(&(v11_9),&(v13_10))
        };
        drop(v11_9);
        let v11_12: Space = unite(&(v11_7),&(v11_11));
        v7_15.join_into((v11_12).clone());
      }
      drop(v7_15_cursor);
      let v7_16: Space = unwrap(&(v4_10),&(v4_18_head));
      let v7_17: Space = subtract(&(v7_15),&(v7_16));
      drop(v7_16);
      let v7_18: Space = intersect(&(v7_17),&(*CONSTANT_5));
      compose(&(v5_10),&(v7_18))
    };
    drop(v5_10);
    let v14_6: Path = concat_path(&(*p0),&(v4_18_head));
    let v5_20: Space = wrap(&(v5_19),&(v14_6));
    let v5_21: Space = unite(&(v5_8),&(v5_20));
    v4_18.join_into((v5_21).clone());
  }
  drop(v4_18_cursor);
  drop(v4_8);
  drop(v4_10);
  (v4_18).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v15_5: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v15_6: Space = restrict_to(&(*CONSTANT_4),&(v15_5));
  drop(v15_5);
  let mut v15_13 = Space::new();
  let mut v15_13_cursor = (v15_6).read_zipper();
  for v15_13_byte in v15_13_cursor.child_mask().iter() {
    v15_13_cursor.descend_to_byte(v15_13_byte);
    let v15_13_tail = v15_13_cursor.make_map();
    v15_13_cursor.ascend(1);
    let v15_13_head = Path::from_slice(&[v15_13_byte]);
    let v16_2: Space = singleton(&(v15_13_head));
    let v16_3: Space = intersect(&(*CONSTANT_1),&(v16_2));
    let v16_4: Space = if has_head(&(v16_3)) { singleton(&[]) } else { Space::new() };
    drop(v16_3);
    let v16_5: Space = subtract(&(*CONSTANT_0),&(v16_4));
    drop(v16_4);
    let v16_7: Space = if (v16_5).is_empty() { Space::new() } else {
      let mut v17_6 = Space::new();
      let mut v17_6_cursor = (v15_13_tail).read_zipper();
      for v17_6_byte in v17_6_cursor.child_mask().iter() {
        v17_6_cursor.descend_to_byte(v17_6_byte);
        let v17_6_tail = v17_6_cursor.make_map();
        v17_6_cursor.ascend(1);
        let v17_6_head = Path::from_slice(&[v17_6_byte]);
        let v18_2: Space = singleton(&(v17_6_head));
        let v18_3: Space = intersect(&(*CONSTANT_1),&(v18_2));
        let v18_4: Space = if has_head(&(v18_3)) { singleton(&[]) } else { Space::new() };
        drop(v18_3);
        let v18_5: Space = subtract(&(*CONSTANT_0),&(v18_4));
        drop(v18_4);
        let v18_8: Space = if (v18_5).is_empty() { Space::new() } else {
          let v19_6: Path = concat_path(&(v15_13_head),&(v17_6_head));
          let v19_7: Space = routine_3(c, &(v19_6), &(v17_6_tail));
          compose(&(v18_5),&(v19_7))
        };
        drop(v18_5);
        let v18_9: Space = intersect(&(*CONSTANT_1),&(v18_2));
        drop(v18_2);
        let v18_10: Space = if has_head(&(v18_9)) { singleton(&[]) } else { Space::new() };
        drop(v18_9);
        let v18_12: Space = if (v18_10).is_empty() { Space::new() } else {
          let v20_6: Path = concat_path(&(v15_13_head),&(v17_6_head));
          let v20_11: Space = routine_4(c, &(v20_6), &(v17_6_tail));
          drop(v20_6);
          compose(&(v18_10),&(v20_11))
        };
        drop(v18_10);
        let v18_13: Space = unite(&(v18_8),&(v18_12));
        v17_6.join_into((v18_13).clone());
      }
      drop(v17_6_cursor);
      compose(&(v16_5),&(v17_6))
    };
    drop(v16_5);
    let v16_8: Space = intersect(&(*CONSTANT_1),&(v16_2));
    drop(v16_2);
    let v16_9: Space = if has_head(&(v16_8)) { singleton(&[]) } else { Space::new() };
    drop(v16_8);
    let v16_10: Space = compose(&(v16_9),&(v15_13_tail));
    drop(v16_9);
    let v16_11: Space = unite(&(v16_7),&(v16_10));
    drop(v16_10);
    v15_13.join_into((v16_11).clone());
  }
  drop(v15_13_cursor);
  drop(v15_6);
  let v15_14: Space = restrict_to(&(*CONSTANT_3),&(v15_13));
  let mut v15_21 = Space::new();
  let mut v15_21_cursor = (v15_14).read_zipper();
  for v15_21_byte in v15_21_cursor.child_mask().iter() {
    v15_21_cursor.descend_to_byte(v15_21_byte);
    let v15_21_tail = v15_21_cursor.make_map();
    v15_21_cursor.ascend(1);
    let v15_21_head = Path::from_slice(&[v15_21_byte]);
    let v21_2: Space = singleton(&(v15_21_head));
    let v21_3: Space = intersect(&(*CONSTANT_1),&(v21_2));
    let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
    drop(v21_3);
    let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
    drop(v21_4);
    let v21_7: Space = if (v21_5).is_empty() { Space::new() } else {
      let mut v22_6 = Space::new();
      let mut v22_6_cursor = (v15_21_tail).read_zipper();
      for v22_6_byte in v22_6_cursor.child_mask().iter() {
        v22_6_cursor.descend_to_byte(v22_6_byte);
        let v22_6_tail = v22_6_cursor.make_map();
        v22_6_cursor.ascend(1);
        let v22_6_head = Path::from_slice(&[v22_6_byte]);
        let v23_2: Space = singleton(&(v22_6_head));
        let v23_3: Space = intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v15_21_head),&(v22_6_head));
          let v24_7: Space = routine_5(c, &(v24_6), &(v22_6_tail));
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_12: Space = if (v23_10).is_empty() { Space::new() } else {
          let v25_6: Path = concat_path(&(v15_21_head),&(v22_6_head));
          let v25_11: Space = routine_6(c, &(v25_6), &(v22_6_tail));
          drop(v25_6);
          compose(&(v23_10),&(v25_11))
        };
        drop(v23_10);
        let v23_13: Space = unite(&(v23_8),&(v23_12));
        v22_6.join_into((v23_13).clone());
      }
      drop(v22_6_cursor);
      compose(&(v21_5),&(v22_6))
    };
    drop(v21_5);
    let v21_8: Space = intersect(&(*CONSTANT_1),&(v21_2));
    drop(v21_2);
    let v21_9: Space = if has_head(&(v21_8)) { singleton(&[]) } else { Space::new() };
    drop(v21_8);
    let v21_10: Space = compose(&(v21_9),&(v15_21_tail));
    drop(v21_9);
    let v21_11: Space = unite(&(v21_7),&(v21_10));
    drop(v21_10);
    v15_21.join_into((v21_11).clone());
  }
  drop(v15_21_cursor);
  let v15_23: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v15_24: Space = subtract(&(v15_21),&(v15_23));
  drop(v15_23);
  let v15_26: Space = intersect(&(v15_24),&(*CONSTANT_5));
  let v15_27: Space = wrap(&(v15_26),&(*p0));
  (v15_27).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v26_5 = Space::new();
  let mut v26_5_cursor = (*s0).read_zipper();
  for v26_5_byte in v26_5_cursor.child_mask().iter() {
    v26_5_cursor.descend_to_byte(v26_5_byte);
    let v26_5_tail = v26_5_cursor.make_map();
    v26_5_cursor.ascend(1);
    let v26_5_head = Path::from_slice(&[v26_5_byte]);
    let v27_2: Space = singleton(&(v26_5_head));
    let v27_3: Space = intersect(&(*CONSTANT_1),&(v27_2));
    let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
    drop(v27_3);
    let v27_5: Space = subtract(&(*CONSTANT_0),&(v27_4));
    drop(v27_4);
    let v27_8: Space = if (v27_5).is_empty() { Space::new() } else {
      let v28_6: Path = concat_path(&(*p0),&(v26_5_head));
      let v28_7: Space = routine_3(c, &(v28_6), &(v26_5_tail));
      drop(v28_6);
      compose(&(v27_5),&(v28_7))
    };
    drop(v27_5);
    let v27_9: Space = intersect(&(*CONSTANT_1),&(v27_2));
    drop(v27_2);
    let v27_10: Space = if has_head(&(v27_9)) { singleton(&[]) } else { Space::new() };
    drop(v27_9);
    let v27_11: Space = compose(&(v27_10),&(v26_5_tail));
    drop(v27_10);
    let v27_12: Space = unite(&(v27_8),&(v27_11));
    drop(v27_11);
    v26_5.join_into((v27_12).clone());
  }
  drop(v26_5_cursor);
  (v26_5).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v30_5 = Space::new();
  let mut v30_5_cursor = (*s0).read_zipper();
  for v30_5_byte in v30_5_cursor.child_mask().iter() {
    v30_5_cursor.descend_to_byte(v30_5_byte);
    let v30_5_tail = v30_5_cursor.make_map();
    v30_5_cursor.ascend(1);
    let v30_5_head = Path::from_slice(&[v30_5_byte]);
    let v31_2: Space = singleton(&(v30_5_head));
    let v31_3: Space = intersect(&(*CONSTANT_1),&(v31_2));
    let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
    drop(v31_3);
    let v31_5: Space = subtract(&(*CONSTANT_0),&(v31_4));
    drop(v31_4);
    let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
      let v32_6: Path = concat_path(&(*p0),&(v30_5_head));
      let v32_7: Space = routine_5(c, &(v32_6), &(v30_5_tail));
      drop(v32_6);
      compose(&(v31_5),&(v32_7))
    };
    drop(v31_5);
    let v31_9: Space = intersect(&(*CONSTANT_1),&(v31_2));
    drop(v31_2);
    let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
    drop(v31_9);
    let v31_11: Space = compose(&(v31_10),&(v30_5_tail));
    drop(v31_10);
    let v31_12: Space = unite(&(v31_8),&(v31_11));
    drop(v31_11);
    v30_5.join_into((v31_12).clone());
  }
  drop(v30_5_cursor);
  (v30_5).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
