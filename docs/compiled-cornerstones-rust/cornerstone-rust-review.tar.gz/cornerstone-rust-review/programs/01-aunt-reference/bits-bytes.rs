#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,1]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>) -> Space {
  let mut v0_5 = Space::new();
  let mut v0_5_cursor = (*s1.expect("unbound native input")).read_zipper();
  for v0_5_byte in v0_5_cursor.child_mask().iter() {
    v0_5_cursor.descend_to_byte(v0_5_byte);
    let v0_5_tail = v0_5_cursor.make_map();
    v0_5_cursor.ascend(1);
    let v0_5_head = Path::from_slice(&[v0_5_byte]);
    let v1_2: Space = singleton(&(v0_5_head));
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let v2_6: Space = routine_1(c, &(v0_5_head), &(v0_5_tail), &(*s0.expect("unbound native input")));
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let v3_10: Space = routine_2(c, &(v0_5_head), &(v0_5_tail), &(*s0.expect("unbound native input")));
      compose(&(v1_9),&(v3_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_5.join_into((v1_12).clone());
  }
  drop(v0_5_cursor);
  let v0_7: Space = wrap(&(v0_5),&(*CONSTANT_2));
  (v0_7).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v4_12 = Space::new();
  let mut v4_12_cursor = (*s0).read_zipper();
  for v4_12_byte in v4_12_cursor.child_mask().iter() {
    v4_12_cursor.descend_to_byte(v4_12_byte);
    let v4_12_tail = v4_12_cursor.make_map();
    v4_12_cursor.ascend(1);
    let v4_12_head = Path::from_slice(&[v4_12_byte]);
    let v5_2: Space = singleton(&(v4_12_head));
    let v5_3: Space = intersect(&(*CONSTANT_1),&(v5_2));
    let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
    drop(v5_3);
    let v5_5: Space = subtract(&(*CONSTANT_0),&(v5_4));
    drop(v5_4);
    let v5_8: Space = if (v5_5).is_empty() { Space::new() } else {
      let v6_6: Path = concat_path(&(*p0),&(v4_12_head));
      let mut v6_7 = Space::new();
      let mut v6_7_cursor = (v4_12_tail).read_zipper();
      for v6_7_byte in v6_7_cursor.child_mask().iter() {
        v6_7_cursor.descend_to_byte(v6_7_byte);
        let v6_7_tail = v6_7_cursor.make_map();
        v6_7_cursor.ascend(1);
        let v6_7_head = Path::from_slice(&[v6_7_byte]);
        let v7_2: Space = singleton(&(v6_7_head));
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v6_6),&(v6_7_head));
          let v8_7: Space = routine_3(c, &(v8_6), &(v6_7_tail), &(*s1));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v6_6),&(v6_7_head));
          let v9_11: Space = routine_4(c, &(v9_6), &(v6_7_tail), &(*s1));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_7.join_into((v7_13).clone());
      }
      drop(v6_7_cursor);
      compose(&(v5_5),&(v6_7))
    };
    drop(v5_5);
    let v5_9: Space = intersect(&(*CONSTANT_1),&(v5_2));
    drop(v5_2);
    let v5_10: Space = if has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
    drop(v5_9);
    let v5_12: Space = if (v5_10).is_empty() { Space::new() } else {
      let v10_6: Path = concat_path(&(*p0),&(v4_12_head));
      let mut v10_11 = Space::new();
      let mut v10_11_cursor = (v4_12_tail).read_zipper();
      for v10_11_byte in v10_11_cursor.child_mask().iter() {
        v10_11_cursor.descend_to_byte(v10_11_byte);
        let v10_11_tail = v10_11_cursor.make_map();
        v10_11_cursor.ascend(1);
        let v10_11_head = Path::from_slice(&[v10_11_byte]);
        let v11_2: Space = singleton(&(v10_11_head));
        let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
        let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
        drop(v11_3);
        let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
        drop(v11_4);
        let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
          let v12_6: Path = concat_path(&(v10_6),&(v10_11_head));
          let v12_7: Space = routine_3(c, &(v12_6), &(v10_11_tail), &(*s1));
          compose(&(v11_5),&(v12_7))
        };
        drop(v11_5);
        let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
        drop(v11_2);
        let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
        drop(v11_9);
        let v11_12: Space = if (v11_10).is_empty() { Space::new() } else {
          let v13_6: Path = concat_path(&(v10_6),&(v10_11_head));
          let v13_11: Space = routine_5(c, &(v13_6), &(v10_11_tail), &(*s1));
          drop(v13_6);
          compose(&(v11_10),&(v13_11))
        };
        drop(v11_10);
        let v11_13: Space = unite(&(v11_8),&(v11_12));
        v10_11.join_into((v11_13).clone());
      }
      drop(v10_11_cursor);
      drop(v10_6);
      compose(&(v5_10),&(v10_11))
    };
    drop(v5_10);
    let v5_13: Space = unite(&(v5_8),&(v5_12));
    v4_12.join_into((v5_13).clone());
  }
  drop(v4_12_cursor);
  (v4_12).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v14_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v14_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v14_10: Space = unwrap(&(v14_9),&(*p0));
  let v14_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v14_22 = Space::new();
  let mut v14_22_cursor = (*s0).read_zipper();
  for v14_22_byte in v14_22_cursor.child_mask().iter() {
    v14_22_cursor.descend_to_byte(v14_22_byte);
    let v14_22_tail = v14_22_cursor.make_map();
    v14_22_cursor.ascend(1);
    let v14_22_head = Path::from_slice(&[v14_22_byte]);
    let v15_2: Space = singleton(&(v14_22_head));
    let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
    let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
    drop(v15_3);
    let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
    drop(v15_4);
    let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v14_22_head));
      let mut v16_7 = Space::new();
      let mut v16_7_cursor = (v14_22_tail).read_zipper();
      for v16_7_byte in v16_7_cursor.child_mask().iter() {
        v16_7_cursor.descend_to_byte(v16_7_byte);
        let v16_7_tail = v16_7_cursor.make_map();
        v16_7_cursor.ascend(1);
        let v16_7_head = Path::from_slice(&[v16_7_byte]);
        let v17_2: Space = singleton(&(v16_7_head));
        let v17_3: Space = intersect(&(*CONSTANT_1),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
        drop(v17_4);
        let v17_8: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v16_6),&(v16_7_head));
          let v18_7: Space = routine_3(c, &(v18_6), &(v16_7_tail), &(*s1));
          compose(&(v17_5),&(v18_7))
        };
        drop(v17_5);
        let v17_9: Space = intersect(&(*CONSTANT_1),&(v17_2));
        drop(v17_2);
        let v17_10: Space = if has_head(&(v17_9)) { singleton(&[]) } else { Space::new() };
        drop(v17_9);
        let v17_12: Space = if (v17_10).is_empty() { Space::new() } else {
          let v19_6: Path = concat_path(&(v16_6),&(v16_7_head));
          let v19_11: Space = routine_4(c, &(v19_6), &(v16_7_tail), &(*s1));
          drop(v19_6);
          compose(&(v17_10),&(v19_11))
        };
        drop(v17_10);
        let v17_13: Space = unite(&(v17_8),&(v17_12));
        v16_7.join_into((v17_13).clone());
      }
      drop(v16_7_cursor);
      compose(&(v15_5),&(v16_7))
    };
    drop(v15_5);
    let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
    drop(v15_2);
    let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
    drop(v15_9);
    let v15_18: Space = if (v15_10).is_empty() { Space::new() } else {
      let v20_11: Space = unwrap(&(v14_10),&(v14_22_head));
      let v20_12: Space = restrict_to(&(v14_9),&(v20_11));
      let mut v20_13 = Space::new();
      let mut v20_13_cursor = (v20_12).read_zipper();
      for v20_13_byte in v20_13_cursor.child_mask().iter() {
        v20_13_cursor.descend_to_byte(v20_13_byte);
        let v20_13_tail = v20_13_cursor.make_map();
        v20_13_cursor.ascend(1);
        let v20_13_head = Path::from_slice(&[v20_13_byte]);
        let v21_2: Space = singleton(&(v20_13_head));
        let v21_3: Space = intersect(&(*CONSTANT_1),&(v21_2));
        let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
        drop(v21_3);
        let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
        drop(v21_4);
        let v21_7: Space = if (v21_5).is_empty() { Space::new() } else {
          let v22_6: Space = routine_6(c, &(v20_13_head), &(v20_13_tail));
          compose(&(v21_5),&(v22_6))
        };
        drop(v21_5);
        let v21_8: Space = intersect(&(*CONSTANT_1),&(v21_2));
        drop(v21_2);
        let v21_9: Space = if has_head(&(v21_8)) { singleton(&[]) } else { Space::new() };
        drop(v21_8);
        let v21_11: Space = if (v21_9).is_empty() { Space::new() } else {
          let v23_10: Space = routine_7(c, &(v20_13_head), &(v20_13_tail));
          compose(&(v21_9),&(v23_10))
        };
        drop(v21_9);
        let v21_12: Space = unite(&(v21_7),&(v21_11));
        v20_13.join_into((v21_12).clone());
      }
      drop(v20_13_cursor);
      drop(v20_12);
      let v20_14: Space = restrict_to(&(v14_7),&(v20_13));
      let mut v20_15 = Space::new();
      let mut v20_15_cursor = (v20_14).read_zipper();
      for v20_15_byte in v20_15_cursor.child_mask().iter() {
        v20_15_cursor.descend_to_byte(v20_15_byte);
        let v20_15_tail = v20_15_cursor.make_map();
        v20_15_cursor.ascend(1);
        let v20_15_head = Path::from_slice(&[v20_15_byte]);
        let v24_2: Space = singleton(&(v20_15_head));
        let v24_3: Space = intersect(&(*CONSTANT_1),&(v24_2));
        let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
        drop(v24_3);
        let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
        drop(v24_4);
        let v24_7: Space = if (v24_5).is_empty() { Space::new() } else {
          let v25_6: Space = routine_8(c, &(v20_15_head), &(v20_15_tail));
          compose(&(v24_5),&(v25_6))
        };
        drop(v24_5);
        let v24_8: Space = intersect(&(*CONSTANT_1),&(v24_2));
        drop(v24_2);
        let v24_9: Space = if has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
        drop(v24_8);
        let v24_11: Space = if (v24_9).is_empty() { Space::new() } else {
          let v26_10: Space = routine_9(c, &(v20_15_head), &(v20_15_tail));
          compose(&(v24_9),&(v26_10))
        };
        drop(v24_9);
        let v24_12: Space = unite(&(v24_7),&(v24_11));
        v20_15.join_into((v24_12).clone());
      }
      drop(v20_15_cursor);
      let v20_16: Space = subtract(&(v20_15),&(v20_11));
      drop(v20_11);
      let v20_17: Space = intersect(&(v20_16),&(v14_12));
      compose(&(v15_10),&(v20_17))
    };
    drop(v15_10);
    let v27_6: Path = concat_path(&(*p0),&(v14_22_head));
    let v15_19: Space = wrap(&(v15_18),&(v27_6));
    let v15_20: Space = unite(&(v15_8),&(v15_19));
    v14_22.join_into((v15_20).clone());
  }
  drop(v14_22_cursor);
  drop(v14_7);
  drop(v14_9);
  drop(v14_10);
  drop(v14_12);
  (v14_22).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v28_12 = Space::new();
  let mut v28_12_cursor = (*s0).read_zipper();
  for v28_12_byte in v28_12_cursor.child_mask().iter() {
    v28_12_cursor.descend_to_byte(v28_12_byte);
    let v28_12_tail = v28_12_cursor.make_map();
    v28_12_cursor.ascend(1);
    let v28_12_head = Path::from_slice(&[v28_12_byte]);
    let v29_2: Space = singleton(&(v28_12_head));
    let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
    let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
    drop(v29_3);
    let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
    drop(v29_4);
    let v29_8: Space = if (v29_5).is_empty() { Space::new() } else {
      let v30_6: Path = concat_path(&(*p0),&(v28_12_head));
      let mut v30_7 = Space::new();
      let mut v30_7_cursor = (v28_12_tail).read_zipper();
      for v30_7_byte in v30_7_cursor.child_mask().iter() {
        v30_7_cursor.descend_to_byte(v30_7_byte);
        let v30_7_tail = v30_7_cursor.make_map();
        v30_7_cursor.ascend(1);
        let v30_7_head = Path::from_slice(&[v30_7_byte]);
        let v31_2: Space = singleton(&(v30_7_head));
        let v31_3: Space = intersect(&(*CONSTANT_1),&(v31_2));
        let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
        drop(v31_3);
        let v31_5: Space = subtract(&(*CONSTANT_0),&(v31_4));
        drop(v31_4);
        let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
          let v32_6: Path = concat_path(&(v30_6),&(v30_7_head));
          let v32_7: Space = routine_10(c, &(v32_6), &(v30_7_tail), &(*s1));
          compose(&(v31_5),&(v32_7))
        };
        drop(v31_5);
        let v31_9: Space = intersect(&(*CONSTANT_1),&(v31_2));
        drop(v31_2);
        let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
        drop(v31_9);
        let v31_12: Space = if (v31_10).is_empty() { Space::new() } else {
          let v33_6: Path = concat_path(&(v30_6),&(v30_7_head));
          let v33_11: Space = routine_11(c, &(v33_6), &(v30_7_tail), &(*s1));
          drop(v33_6);
          compose(&(v31_10),&(v33_11))
        };
        drop(v31_10);
        let v31_13: Space = unite(&(v31_8),&(v31_12));
        v30_7.join_into((v31_13).clone());
      }
      drop(v30_7_cursor);
      compose(&(v29_5),&(v30_7))
    };
    drop(v29_5);
    let v29_9: Space = intersect(&(*CONSTANT_1),&(v29_2));
    drop(v29_2);
    let v29_10: Space = if has_head(&(v29_9)) { singleton(&[]) } else { Space::new() };
    drop(v29_9);
    let v29_12: Space = if (v29_10).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&(v28_12_head));
      let mut v34_11 = Space::new();
      let mut v34_11_cursor = (v28_12_tail).read_zipper();
      for v34_11_byte in v34_11_cursor.child_mask().iter() {
        v34_11_cursor.descend_to_byte(v34_11_byte);
        let v34_11_tail = v34_11_cursor.make_map();
        v34_11_cursor.ascend(1);
        let v34_11_head = Path::from_slice(&[v34_11_byte]);
        let v35_2: Space = singleton(&(v34_11_head));
        let v35_3: Space = intersect(&(*CONSTANT_1),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_0),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (v35_5).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let v36_7: Space = routine_10(c, &(v36_6), &(v34_11_tail), &(*s1));
          compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = intersect(&(*CONSTANT_1),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (v35_10).is_empty() { Space::new() } else {
          let v37_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let v37_11: Space = routine_5(c, &(v37_6), &(v34_11_tail), &(*s1));
          drop(v37_6);
          compose(&(v35_10),&(v37_11))
        };
        drop(v35_10);
        let v35_13: Space = unite(&(v35_8),&(v35_12));
        v34_11.join_into((v35_13).clone());
      }
      drop(v34_11_cursor);
      drop(v34_6);
      compose(&(v29_10),&(v34_11))
    };
    drop(v29_10);
    let v29_13: Space = unite(&(v29_8),&(v29_12));
    v28_12.join_into((v29_13).clone());
  }
  drop(v28_12_cursor);
  (v28_12).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v38_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v38_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v38_10: Space = unwrap(&(v38_9),&(*p0));
  let v38_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v38_22 = Space::new();
  let mut v38_22_cursor = (*s0).read_zipper();
  for v38_22_byte in v38_22_cursor.child_mask().iter() {
    v38_22_cursor.descend_to_byte(v38_22_byte);
    let v38_22_tail = v38_22_cursor.make_map();
    v38_22_cursor.ascend(1);
    let v38_22_head = Path::from_slice(&[v38_22_byte]);
    let v39_2: Space = singleton(&(v38_22_head));
    let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
    let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
    drop(v39_3);
    let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
    drop(v39_4);
    let v39_8: Space = if (v39_5).is_empty() { Space::new() } else {
      let v40_6: Path = concat_path(&(*p0),&(v38_22_head));
      let mut v40_7 = Space::new();
      let mut v40_7_cursor = (v38_22_tail).read_zipper();
      for v40_7_byte in v40_7_cursor.child_mask().iter() {
        v40_7_cursor.descend_to_byte(v40_7_byte);
        let v40_7_tail = v40_7_cursor.make_map();
        v40_7_cursor.ascend(1);
        let v40_7_head = Path::from_slice(&[v40_7_byte]);
        let v41_2: Space = singleton(&(v40_7_head));
        let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
        let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
        drop(v41_3);
        let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
        drop(v41_4);
        let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
          let v42_6: Path = concat_path(&(v40_6),&(v40_7_head));
          let v42_7: Space = routine_10(c, &(v42_6), &(v40_7_tail), &(*s1));
          compose(&(v41_5),&(v42_7))
        };
        drop(v41_5);
        let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
        drop(v41_2);
        let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
        drop(v41_9);
        let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
          let v43_6: Path = concat_path(&(v40_6),&(v40_7_head));
          let v43_11: Space = routine_11(c, &(v43_6), &(v40_7_tail), &(*s1));
          drop(v43_6);
          compose(&(v41_10),&(v43_11))
        };
        drop(v41_10);
        let v41_13: Space = unite(&(v41_8),&(v41_12));
        v40_7.join_into((v41_13).clone());
      }
      drop(v40_7_cursor);
      compose(&(v39_5),&(v40_7))
    };
    drop(v39_5);
    let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
    drop(v39_2);
    let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
    drop(v39_9);
    let v39_18: Space = if (v39_10).is_empty() { Space::new() } else {
      let v44_11: Space = unwrap(&(v38_10),&(v38_22_head));
      let v44_12: Space = restrict_to(&(v38_9),&(v44_11));
      let mut v44_13 = Space::new();
      let mut v44_13_cursor = (v44_12).read_zipper();
      for v44_13_byte in v44_13_cursor.child_mask().iter() {
        v44_13_cursor.descend_to_byte(v44_13_byte);
        let v44_13_tail = v44_13_cursor.make_map();
        v44_13_cursor.ascend(1);
        let v44_13_head = Path::from_slice(&[v44_13_byte]);
        let v45_2: Space = singleton(&(v44_13_head));
        let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
        let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
        drop(v45_3);
        let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
        drop(v45_4);
        let v45_7: Space = if (v45_5).is_empty() { Space::new() } else {
          let v46_6: Space = routine_6(c, &(v44_13_head), &(v44_13_tail));
          compose(&(v45_5),&(v46_6))
        };
        drop(v45_5);
        let v45_8: Space = intersect(&(*CONSTANT_1),&(v45_2));
        drop(v45_2);
        let v45_9: Space = if has_head(&(v45_8)) { singleton(&[]) } else { Space::new() };
        drop(v45_8);
        let v45_11: Space = if (v45_9).is_empty() { Space::new() } else {
          let v47_10: Space = routine_7(c, &(v44_13_head), &(v44_13_tail));
          compose(&(v45_9),&(v47_10))
        };
        drop(v45_9);
        let v45_12: Space = unite(&(v45_7),&(v45_11));
        v44_13.join_into((v45_12).clone());
      }
      drop(v44_13_cursor);
      drop(v44_12);
      let v44_14: Space = restrict_to(&(v38_7),&(v44_13));
      let mut v44_15 = Space::new();
      let mut v44_15_cursor = (v44_14).read_zipper();
      for v44_15_byte in v44_15_cursor.child_mask().iter() {
        v44_15_cursor.descend_to_byte(v44_15_byte);
        let v44_15_tail = v44_15_cursor.make_map();
        v44_15_cursor.ascend(1);
        let v44_15_head = Path::from_slice(&[v44_15_byte]);
        let v48_2: Space = singleton(&(v44_15_head));
        let v48_3: Space = intersect(&(*CONSTANT_1),&(v48_2));
        let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
        drop(v48_3);
        let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
        drop(v48_4);
        let v48_7: Space = if (v48_5).is_empty() { Space::new() } else {
          let v49_6: Space = routine_8(c, &(v44_15_head), &(v44_15_tail));
          compose(&(v48_5),&(v49_6))
        };
        drop(v48_5);
        let v48_8: Space = intersect(&(*CONSTANT_1),&(v48_2));
        drop(v48_2);
        let v48_9: Space = if has_head(&(v48_8)) { singleton(&[]) } else { Space::new() };
        drop(v48_8);
        let v48_11: Space = if (v48_9).is_empty() { Space::new() } else {
          let v50_10: Space = routine_9(c, &(v44_15_head), &(v44_15_tail));
          compose(&(v48_9),&(v50_10))
        };
        drop(v48_9);
        let v48_12: Space = unite(&(v48_7),&(v48_11));
        v44_15.join_into((v48_12).clone());
      }
      drop(v44_15_cursor);
      let v44_16: Space = subtract(&(v44_15),&(v44_11));
      drop(v44_11);
      let v44_17: Space = intersect(&(v44_16),&(v38_12));
      compose(&(v39_10),&(v44_17))
    };
    drop(v39_10);
    let v51_6: Path = concat_path(&(*p0),&(v38_22_head));
    let v39_19: Space = wrap(&(v39_18),&(v51_6));
    let v39_20: Space = unite(&(v39_8),&(v39_19));
    v38_22.join_into((v39_20).clone());
  }
  drop(v38_22_cursor);
  drop(v38_7);
  drop(v38_9);
  drop(v38_10);
  drop(v38_12);
  (v38_22).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v52_4: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v52_6: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v52_7: Space = unwrap(&(v52_6),&(*p0));
  let v52_8: Space = restrict_to(&(v52_6),&(v52_7));
  drop(v52_6);
  let mut v52_18 = Space::new();
  let mut v52_18_cursor = (v52_8).read_zipper();
  for v52_18_byte in v52_18_cursor.child_mask().iter() {
    v52_18_cursor.descend_to_byte(v52_18_byte);
    let v52_18_tail = v52_18_cursor.make_map();
    v52_18_cursor.ascend(1);
    let v52_18_head = Path::from_slice(&[v52_18_byte]);
    let v53_2: Space = singleton(&(v52_18_head));
    let v53_3: Space = intersect(&(*CONSTANT_1),&(v53_2));
    let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
    drop(v53_3);
    let v53_5: Space = subtract(&(*CONSTANT_0),&(v53_4));
    drop(v53_4);
    let v53_7: Space = if (v53_5).is_empty() { Space::new() } else {
      let mut v54_6 = Space::new();
      let mut v54_6_cursor = (v52_18_tail).read_zipper();
      for v54_6_byte in v54_6_cursor.child_mask().iter() {
        v54_6_cursor.descend_to_byte(v54_6_byte);
        let v54_6_tail = v54_6_cursor.make_map();
        v54_6_cursor.ascend(1);
        let v54_6_head = Path::from_slice(&[v54_6_byte]);
        let v55_2: Space = singleton(&(v54_6_head));
        let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
        let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
        drop(v55_3);
        let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
        drop(v55_4);
        let v55_8: Space = if (v55_5).is_empty() { Space::new() } else {
          let v56_6: Path = concat_path(&(v52_18_head),&(v54_6_head));
          let v56_7: Space = routine_12(c, &(v56_6), &(v54_6_tail));
          compose(&(v55_5),&(v56_7))
        };
        drop(v55_5);
        let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
        drop(v55_2);
        let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
        drop(v55_9);
        let v55_12: Space = if (v55_10).is_empty() { Space::new() } else {
          let v57_6: Path = concat_path(&(v52_18_head),&(v54_6_head));
          let v57_11: Space = routine_13(c, &(v57_6), &(v54_6_tail));
          drop(v57_6);
          compose(&(v55_10),&(v57_11))
        };
        drop(v55_10);
        let v55_13: Space = unite(&(v55_8),&(v55_12));
        v54_6.join_into((v55_13).clone());
      }
      drop(v54_6_cursor);
      compose(&(v53_5),&(v54_6))
    };
    drop(v53_5);
    let v53_8: Space = intersect(&(*CONSTANT_1),&(v53_2));
    drop(v53_2);
    let v53_9: Space = if has_head(&(v53_8)) { singleton(&[]) } else { Space::new() };
    drop(v53_8);
    let v53_11: Space = if (v53_9).is_empty() { Space::new() } else {
      let mut v58_10 = Space::new();
      let mut v58_10_cursor = (v52_18_tail).read_zipper();
      for v58_10_byte in v58_10_cursor.child_mask().iter() {
        v58_10_cursor.descend_to_byte(v58_10_byte);
        let v58_10_tail = v58_10_cursor.make_map();
        v58_10_cursor.ascend(1);
        let v58_10_head = Path::from_slice(&[v58_10_byte]);
        let v59_2: Space = singleton(&(v58_10_head));
        let v59_3: Space = intersect(&(*CONSTANT_1),&(v59_2));
        let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
        drop(v59_3);
        let v59_5: Space = subtract(&(*CONSTANT_0),&(v59_4));
        drop(v59_4);
        let v59_8: Space = if (v59_5).is_empty() { Space::new() } else {
          let v60_6: Path = concat_path(&(v52_18_head),&(v58_10_head));
          let v60_7: Space = routine_12(c, &(v60_6), &(v58_10_tail));
          compose(&(v59_5),&(v60_7))
        };
        drop(v59_5);
        let v59_9: Space = intersect(&(*CONSTANT_1),&(v59_2));
        drop(v59_2);
        let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
        drop(v59_9);
        let v59_12: Space = if (v59_10).is_empty() { Space::new() } else {
          let v61_6: Path = concat_path(&(v52_18_head),&(v58_10_head));
          let v61_11: Space = routine_14(c, &(v61_6), &(v58_10_tail));
          drop(v61_6);
          compose(&(v59_10),&(v61_11))
        };
        drop(v59_10);
        let v59_13: Space = unite(&(v59_8),&(v59_12));
        v58_10.join_into((v59_13).clone());
      }
      drop(v58_10_cursor);
      compose(&(v53_9),&(v58_10))
    };
    drop(v53_9);
    let v53_12: Space = unite(&(v53_7),&(v53_11));
    v52_18.join_into((v53_12).clone());
  }
  drop(v52_18_cursor);
  drop(v52_8);
  let v52_19: Space = restrict_to(&(v52_4),&(v52_18));
  drop(v52_4);
  let mut v52_29 = Space::new();
  let mut v52_29_cursor = (v52_19).read_zipper();
  for v52_29_byte in v52_29_cursor.child_mask().iter() {
    v52_29_cursor.descend_to_byte(v52_29_byte);
    let v52_29_tail = v52_29_cursor.make_map();
    v52_29_cursor.ascend(1);
    let v52_29_head = Path::from_slice(&[v52_29_byte]);
    let v62_2: Space = singleton(&(v52_29_head));
    let v62_3: Space = intersect(&(*CONSTANT_1),&(v62_2));
    let v62_4: Space = if has_head(&(v62_3)) { singleton(&[]) } else { Space::new() };
    drop(v62_3);
    let v62_5: Space = subtract(&(*CONSTANT_0),&(v62_4));
    drop(v62_4);
    let v62_7: Space = if (v62_5).is_empty() { Space::new() } else {
      let mut v63_6 = Space::new();
      let mut v63_6_cursor = (v52_29_tail).read_zipper();
      for v63_6_byte in v63_6_cursor.child_mask().iter() {
        v63_6_cursor.descend_to_byte(v63_6_byte);
        let v63_6_tail = v63_6_cursor.make_map();
        v63_6_cursor.ascend(1);
        let v63_6_head = Path::from_slice(&[v63_6_byte]);
        let v64_2: Space = singleton(&(v63_6_head));
        let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
        let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
        drop(v64_3);
        let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
        drop(v64_4);
        let v64_8: Space = if (v64_5).is_empty() { Space::new() } else {
          let v65_6: Path = concat_path(&(v52_29_head),&(v63_6_head));
          let v65_7: Space = routine_15(c, &(v65_6), &(v63_6_tail));
          compose(&(v64_5),&(v65_7))
        };
        drop(v64_5);
        let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
        drop(v64_2);
        let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
        drop(v64_9);
        let v64_12: Space = if (v64_10).is_empty() { Space::new() } else {
          let v66_6: Path = concat_path(&(v52_29_head),&(v63_6_head));
          let v66_11: Space = routine_16(c, &(v66_6), &(v63_6_tail));
          drop(v66_6);
          compose(&(v64_10),&(v66_11))
        };
        drop(v64_10);
        let v64_13: Space = unite(&(v64_8),&(v64_12));
        v63_6.join_into((v64_13).clone());
      }
      drop(v63_6_cursor);
      compose(&(v62_5),&(v63_6))
    };
    drop(v62_5);
    let v62_8: Space = intersect(&(*CONSTANT_1),&(v62_2));
    drop(v62_2);
    let v62_9: Space = if has_head(&(v62_8)) { singleton(&[]) } else { Space::new() };
    drop(v62_8);
    let v62_11: Space = if (v62_9).is_empty() { Space::new() } else {
      let mut v67_10 = Space::new();
      let mut v67_10_cursor = (v52_29_tail).read_zipper();
      for v67_10_byte in v67_10_cursor.child_mask().iter() {
        v67_10_cursor.descend_to_byte(v67_10_byte);
        let v67_10_tail = v67_10_cursor.make_map();
        v67_10_cursor.ascend(1);
        let v67_10_head = Path::from_slice(&[v67_10_byte]);
        let v68_2: Space = singleton(&(v67_10_head));
        let v68_3: Space = intersect(&(*CONSTANT_1),&(v68_2));
        let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
        drop(v68_3);
        let v68_5: Space = subtract(&(*CONSTANT_0),&(v68_4));
        drop(v68_4);
        let v68_8: Space = if (v68_5).is_empty() { Space::new() } else {
          let v69_6: Path = concat_path(&(v52_29_head),&(v67_10_head));
          let v69_7: Space = routine_15(c, &(v69_6), &(v67_10_tail));
          compose(&(v68_5),&(v69_7))
        };
        drop(v68_5);
        let v68_9: Space = intersect(&(*CONSTANT_1),&(v68_2));
        drop(v68_2);
        let v68_10: Space = if has_head(&(v68_9)) { singleton(&[]) } else { Space::new() };
        drop(v68_9);
        let v68_12: Space = if (v68_10).is_empty() { Space::new() } else {
          let v70_6: Path = concat_path(&(v52_29_head),&(v67_10_head));
          let v70_11: Space = routine_17(c, &(v70_6), &(v67_10_tail));
          drop(v70_6);
          compose(&(v68_10),&(v70_11))
        };
        drop(v68_10);
        let v68_13: Space = unite(&(v68_8),&(v68_12));
        v67_10.join_into((v68_13).clone());
      }
      drop(v67_10_cursor);
      compose(&(v62_9),&(v67_10))
    };
    drop(v62_9);
    let v62_12: Space = unite(&(v62_7),&(v62_11));
    v52_29.join_into((v62_12).clone());
  }
  drop(v52_29_cursor);
  let v52_30: Space = subtract(&(v52_29),&(v52_7));
  drop(v52_7);
  let v52_32: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let v52_33: Space = intersect(&(v52_30),&(v52_32));
  drop(v52_32);
  let v52_34: Space = wrap(&(v52_33),&(*p0));
  (v52_34).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v71_11 = Space::new();
  let mut v71_11_cursor = (*s0).read_zipper();
  for v71_11_byte in v71_11_cursor.child_mask().iter() {
    v71_11_cursor.descend_to_byte(v71_11_byte);
    let v71_11_tail = v71_11_cursor.make_map();
    v71_11_cursor.ascend(1);
    let v71_11_head = Path::from_slice(&[v71_11_byte]);
    let v72_2: Space = singleton(&(v71_11_head));
    let v72_3: Space = intersect(&(*CONSTANT_1),&(v72_2));
    let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
    drop(v72_3);
    let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
    drop(v72_4);
    let v72_8: Space = if (v72_5).is_empty() { Space::new() } else {
      let v73_6: Path = concat_path(&(*p0),&(v71_11_head));
      let mut v73_7 = Space::new();
      let mut v73_7_cursor = (v71_11_tail).read_zipper();
      for v73_7_byte in v73_7_cursor.child_mask().iter() {
        v73_7_cursor.descend_to_byte(v73_7_byte);
        let v73_7_tail = v73_7_cursor.make_map();
        v73_7_cursor.ascend(1);
        let v73_7_head = Path::from_slice(&[v73_7_byte]);
        let v74_2: Space = singleton(&(v73_7_head));
        let v74_3: Space = intersect(&(*CONSTANT_1),&(v74_2));
        let v74_4: Space = if has_head(&(v74_3)) { singleton(&[]) } else { Space::new() };
        drop(v74_3);
        let v74_5: Space = subtract(&(*CONSTANT_0),&(v74_4));
        drop(v74_4);
        let v74_8: Space = if (v74_5).is_empty() { Space::new() } else {
          let v75_6: Path = concat_path(&(v73_6),&(v73_7_head));
          let v75_7: Space = routine_18(c, &(v75_6), &(v73_7_tail));
          compose(&(v74_5),&(v75_7))
        };
        drop(v74_5);
        let v74_9: Space = intersect(&(*CONSTANT_1),&(v74_2));
        drop(v74_2);
        let v74_10: Space = if has_head(&(v74_9)) { singleton(&[]) } else { Space::new() };
        drop(v74_9);
        let v74_12: Space = if (v74_10).is_empty() { Space::new() } else {
          let v76_6: Path = concat_path(&(v73_6),&(v73_7_head));
          let v76_11: Space = routine_19(c, &(v76_6), &(v73_7_tail));
          drop(v76_6);
          compose(&(v74_10),&(v76_11))
        };
        drop(v74_10);
        let v74_13: Space = unite(&(v74_8),&(v74_12));
        v73_7.join_into((v74_13).clone());
      }
      drop(v73_7_cursor);
      compose(&(v72_5),&(v73_7))
    };
    drop(v72_5);
    let v72_9: Space = intersect(&(*CONSTANT_1),&(v72_2));
    drop(v72_2);
    let v72_10: Space = if has_head(&(v72_9)) { singleton(&[]) } else { Space::new() };
    drop(v72_9);
    let v72_12: Space = if (v72_10).is_empty() { Space::new() } else {
      let v77_6: Path = concat_path(&(*p0),&(v71_11_head));
      let mut v77_11 = Space::new();
      let mut v77_11_cursor = (v71_11_tail).read_zipper();
      for v77_11_byte in v77_11_cursor.child_mask().iter() {
        v77_11_cursor.descend_to_byte(v77_11_byte);
        let v77_11_tail = v77_11_cursor.make_map();
        v77_11_cursor.ascend(1);
        let v77_11_head = Path::from_slice(&[v77_11_byte]);
        let v78_2: Space = singleton(&(v77_11_head));
        let v78_3: Space = intersect(&(*CONSTANT_1),&(v78_2));
        let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
        drop(v78_3);
        let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
        drop(v78_4);
        let v78_8: Space = if (v78_5).is_empty() { Space::new() } else {
          let v79_6: Path = concat_path(&(v77_6),&(v77_11_head));
          let v79_7: Space = routine_18(c, &(v79_6), &(v77_11_tail));
          compose(&(v78_5),&(v79_7))
        };
        drop(v78_5);
        let v78_9: Space = intersect(&(*CONSTANT_1),&(v78_2));
        drop(v78_2);
        let v78_10: Space = if has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
        drop(v78_9);
        let v78_12: Space = if (v78_10).is_empty() { Space::new() } else {
          let v80_6: Path = concat_path(&(v77_6),&(v77_11_head));
          let v80_11: Space = routine_14(c, &(v80_6), &(v77_11_tail));
          drop(v80_6);
          compose(&(v78_10),&(v80_11))
        };
        drop(v78_10);
        let v78_13: Space = unite(&(v78_8),&(v78_12));
        v77_11.join_into((v78_13).clone());
      }
      drop(v77_11_cursor);
      drop(v77_6);
      compose(&(v72_10),&(v77_11))
    };
    drop(v72_10);
    let v72_13: Space = unite(&(v72_8),&(v72_12));
    v71_11.join_into((v72_13).clone());
  }
  drop(v71_11_cursor);
  (v71_11).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v81_8 = Space::new();
  let mut v81_8_cursor = (*s0).read_zipper();
  for v81_8_byte in v81_8_cursor.child_mask().iter() {
    v81_8_cursor.descend_to_byte(v81_8_byte);
    let v81_8_tail = v81_8_cursor.make_map();
    v81_8_cursor.ascend(1);
    let v81_8_head = Path::from_slice(&[v81_8_byte]);
    let v82_2: Space = singleton(&(v81_8_head));
    let v82_3: Space = intersect(&(*CONSTANT_1),&(v82_2));
    let v82_4: Space = if has_head(&(v82_3)) { singleton(&[]) } else { Space::new() };
    drop(v82_3);
    let v82_5: Space = subtract(&(*CONSTANT_0),&(v82_4));
    drop(v82_4);
    let v82_8: Space = if (v82_5).is_empty() { Space::new() } else {
      let v83_6: Path = concat_path(&(*p0),&(v81_8_head));
      let mut v83_7 = Space::new();
      let mut v83_7_cursor = (v81_8_tail).read_zipper();
      for v83_7_byte in v83_7_cursor.child_mask().iter() {
        v83_7_cursor.descend_to_byte(v83_7_byte);
        let v83_7_tail = v83_7_cursor.make_map();
        v83_7_cursor.ascend(1);
        let v83_7_head = Path::from_slice(&[v83_7_byte]);
        let v84_2: Space = singleton(&(v83_7_head));
        let v84_3: Space = intersect(&(*CONSTANT_1),&(v84_2));
        let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
        drop(v84_3);
        let v84_5: Space = subtract(&(*CONSTANT_0),&(v84_4));
        drop(v84_4);
        let v84_8: Space = if (v84_5).is_empty() { Space::new() } else {
          let v85_6: Path = concat_path(&(v83_6),&(v83_7_head));
          let v85_7: Space = routine_18(c, &(v85_6), &(v83_7_tail));
          compose(&(v84_5),&(v85_7))
        };
        drop(v84_5);
        let v84_9: Space = intersect(&(*CONSTANT_1),&(v84_2));
        drop(v84_2);
        let v84_10: Space = if has_head(&(v84_9)) { singleton(&[]) } else { Space::new() };
        drop(v84_9);
        let v84_12: Space = if (v84_10).is_empty() { Space::new() } else {
          let v86_6: Path = concat_path(&(v83_6),&(v83_7_head));
          let v86_11: Space = routine_19(c, &(v86_6), &(v83_7_tail));
          drop(v86_6);
          compose(&(v84_10),&(v86_11))
        };
        drop(v84_10);
        let v84_13: Space = unite(&(v84_8),&(v84_12));
        v83_7.join_into((v84_13).clone());
      }
      drop(v83_7_cursor);
      drop(v83_6);
      compose(&(v82_5),&(v83_7))
    };
    drop(v82_5);
    let v82_9: Space = intersect(&(*CONSTANT_1),&(v82_2));
    drop(v82_2);
    let v82_10: Space = if has_head(&(v82_9)) { singleton(&[]) } else { Space::new() };
    drop(v82_9);
    let v82_11: Space = compose(&(v82_10),&(v81_8_tail));
    drop(v82_10);
    let v82_12: Space = unite(&(v82_8),&(v82_11));
    drop(v82_11);
    v81_8.join_into((v82_12).clone());
  }
  drop(v81_8_cursor);
  (v81_8).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v87_11 = Space::new();
  let mut v87_11_cursor = (*s0).read_zipper();
  for v87_11_byte in v87_11_cursor.child_mask().iter() {
    v87_11_cursor.descend_to_byte(v87_11_byte);
    let v87_11_tail = v87_11_cursor.make_map();
    v87_11_cursor.ascend(1);
    let v87_11_head = Path::from_slice(&[v87_11_byte]);
    let v88_2: Space = singleton(&(v87_11_head));
    let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
    let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
    drop(v88_3);
    let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
    drop(v88_4);
    let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
      let v89_6: Path = concat_path(&(*p0),&(v87_11_head));
      let mut v89_7 = Space::new();
      let mut v89_7_cursor = (v87_11_tail).read_zipper();
      for v89_7_byte in v89_7_cursor.child_mask().iter() {
        v89_7_cursor.descend_to_byte(v89_7_byte);
        let v89_7_tail = v89_7_cursor.make_map();
        v89_7_cursor.ascend(1);
        let v89_7_head = Path::from_slice(&[v89_7_byte]);
        let v90_2: Space = singleton(&(v89_7_head));
        let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
        let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
        drop(v90_3);
        let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
        drop(v90_4);
        let v90_8: Space = if (v90_5).is_empty() { Space::new() } else {
          let v91_6: Path = concat_path(&(v89_6),&(v89_7_head));
          let v91_7: Space = routine_20(c, &(v91_6), &(v89_7_tail));
          compose(&(v90_5),&(v91_7))
        };
        drop(v90_5);
        let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
        drop(v90_2);
        let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
        drop(v90_9);
        let v90_12: Space = if (v90_10).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v89_6),&(v89_7_head));
          let v92_11: Space = routine_21(c, &(v92_6), &(v89_7_tail));
          drop(v92_6);
          compose(&(v90_10),&(v92_11))
        };
        drop(v90_10);
        let v90_13: Space = unite(&(v90_8),&(v90_12));
        v89_7.join_into((v90_13).clone());
      }
      drop(v89_7_cursor);
      compose(&(v88_5),&(v89_7))
    };
    drop(v88_5);
    let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
    drop(v88_2);
    let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
    drop(v88_9);
    let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
      let v93_6: Path = concat_path(&(*p0),&(v87_11_head));
      let mut v93_11 = Space::new();
      let mut v93_11_cursor = (v87_11_tail).read_zipper();
      for v93_11_byte in v93_11_cursor.child_mask().iter() {
        v93_11_cursor.descend_to_byte(v93_11_byte);
        let v93_11_tail = v93_11_cursor.make_map();
        v93_11_cursor.ascend(1);
        let v93_11_head = Path::from_slice(&[v93_11_byte]);
        let v94_2: Space = singleton(&(v93_11_head));
        let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
        let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
        drop(v94_3);
        let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
        drop(v94_4);
        let v94_8: Space = if (v94_5).is_empty() { Space::new() } else {
          let v95_6: Path = concat_path(&(v93_6),&(v93_11_head));
          let v95_7: Space = routine_20(c, &(v95_6), &(v93_11_tail));
          compose(&(v94_5),&(v95_7))
        };
        drop(v94_5);
        let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
        drop(v94_2);
        let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
        drop(v94_9);
        let v94_12: Space = if (v94_10).is_empty() { Space::new() } else {
          let v96_6: Path = concat_path(&(v93_6),&(v93_11_head));
          let v96_11: Space = routine_17(c, &(v96_6), &(v93_11_tail));
          drop(v96_6);
          compose(&(v94_10),&(v96_11))
        };
        drop(v94_10);
        let v94_13: Space = unite(&(v94_8),&(v94_12));
        v93_11.join_into((v94_13).clone());
      }
      drop(v93_11_cursor);
      drop(v93_6);
      compose(&(v88_10),&(v93_11))
    };
    drop(v88_10);
    let v88_13: Space = unite(&(v88_8),&(v88_12));
    v87_11.join_into((v88_13).clone());
  }
  drop(v87_11_cursor);
  (v87_11).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v97_8 = Space::new();
  let mut v97_8_cursor = (*s0).read_zipper();
  for v97_8_byte in v97_8_cursor.child_mask().iter() {
    v97_8_cursor.descend_to_byte(v97_8_byte);
    let v97_8_tail = v97_8_cursor.make_map();
    v97_8_cursor.ascend(1);
    let v97_8_head = Path::from_slice(&[v97_8_byte]);
    let v98_2: Space = singleton(&(v97_8_head));
    let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
    let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
    drop(v98_3);
    let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
    drop(v98_4);
    let v98_8: Space = if (v98_5).is_empty() { Space::new() } else {
      let v99_6: Path = concat_path(&(*p0),&(v97_8_head));
      let mut v99_7 = Space::new();
      let mut v99_7_cursor = (v97_8_tail).read_zipper();
      for v99_7_byte in v99_7_cursor.child_mask().iter() {
        v99_7_cursor.descend_to_byte(v99_7_byte);
        let v99_7_tail = v99_7_cursor.make_map();
        v99_7_cursor.ascend(1);
        let v99_7_head = Path::from_slice(&[v99_7_byte]);
        let v100_2: Space = singleton(&(v99_7_head));
        let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
        let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
        drop(v100_3);
        let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
        drop(v100_4);
        let v100_8: Space = if (v100_5).is_empty() { Space::new() } else {
          let v101_6: Path = concat_path(&(v99_6),&(v99_7_head));
          let v101_7: Space = routine_20(c, &(v101_6), &(v99_7_tail));
          compose(&(v100_5),&(v101_7))
        };
        drop(v100_5);
        let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
        drop(v100_2);
        let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
        drop(v100_9);
        let v100_12: Space = if (v100_10).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v99_6),&(v99_7_head));
          let v102_11: Space = routine_21(c, &(v102_6), &(v99_7_tail));
          drop(v102_6);
          compose(&(v100_10),&(v102_11))
        };
        drop(v100_10);
        let v100_13: Space = unite(&(v100_8),&(v100_12));
        v99_7.join_into((v100_13).clone());
      }
      drop(v99_7_cursor);
      drop(v99_6);
      compose(&(v98_5),&(v99_7))
    };
    drop(v98_5);
    let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
    drop(v98_2);
    let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
    drop(v98_9);
    let v98_11: Space = compose(&(v98_10),&(v97_8_tail));
    drop(v98_10);
    let v98_12: Space = unite(&(v98_8),&(v98_11));
    drop(v98_11);
    v97_8.join_into((v98_12).clone());
  }
  drop(v97_8_cursor);
  (v97_8).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v103_7 = Space::new();
  let mut v103_7_cursor = (*s0).read_zipper();
  for v103_7_byte in v103_7_cursor.child_mask().iter() {
    v103_7_cursor.descend_to_byte(v103_7_byte);
    let v103_7_tail = v103_7_cursor.make_map();
    v103_7_cursor.ascend(1);
    let v103_7_head = Path::from_slice(&[v103_7_byte]);
    let v104_2: Space = singleton(&(v103_7_head));
    let v104_3: Space = intersect(&(*CONSTANT_1),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let mut v104_6 = Space::new();
    let mut v104_6_cursor = (v103_7_tail).read_zipper();
    for v104_6_byte in v104_6_cursor.child_mask().iter() {
      v104_6_cursor.descend_to_byte(v104_6_byte);
      let v104_6_tail = v104_6_cursor.make_map();
      v104_6_cursor.ascend(1);
      let v104_6_head = Path::from_slice(&[v104_6_byte]);
      let v105_2: Space = Space::new();
      v104_6.join_into((v105_2).clone());
    }
    drop(v104_6_cursor);
    let v104_7: Space = compose(&(v104_5),&(v104_6));
    drop(v104_5);
    drop(v104_6);
    let v104_8: Space = intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_9: Space = if has_head(&(v104_8)) { singleton(&[]) } else { Space::new() };
    drop(v104_8);
    let v104_12: Space = if (v104_9).is_empty() { Space::new() } else {
      let v106_10: Path = concat_path(&(*p0),&(v103_7_head));
      let mut v106_11 = Space::new();
      let mut v106_11_cursor = (v103_7_tail).read_zipper();
      for v106_11_byte in v106_11_cursor.child_mask().iter() {
        v106_11_cursor.descend_to_byte(v106_11_byte);
        let v106_11_tail = v106_11_cursor.make_map();
        v106_11_cursor.ascend(1);
        let v106_11_head = Path::from_slice(&[v106_11_byte]);
        let v107_2: Space = singleton(&(v106_11_head));
        let v107_3: Space = intersect(&(*CONSTANT_1),&(v107_2));
        drop(v107_2);
        let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
        drop(v107_3);
        let v107_7: Space = if (v107_4).is_empty() { Space::new() } else {
          let v108_5: Path = concat_path(&(v106_10),&(v106_11_head));
          let v108_6: Space = routine_5(c, &(v108_5), &(v106_11_tail), &(*s1));
          drop(v108_5);
          compose(&(v107_4),&(v108_6))
        };
        drop(v107_4);
        v106_11.join_into((v107_7).clone());
      }
      drop(v106_11_cursor);
      drop(v106_10);
      compose(&(v104_9),&(v106_11))
    };
    drop(v104_9);
    let v104_13: Space = unite(&(v104_7),&(v104_12));
    drop(v104_7);
    v103_7.join_into((v104_13).clone());
  }
  drop(v103_7_cursor);
  (v103_7).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v109_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v109_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v109_10: Space = unwrap(&(v109_9),&(*p0));
  let v109_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v109_19 = Space::new();
  let mut v109_19_cursor = (*s0).read_zipper();
  for v109_19_byte in v109_19_cursor.child_mask().iter() {
    v109_19_cursor.descend_to_byte(v109_19_byte);
    let v109_19_tail = v109_19_cursor.make_map();
    v109_19_cursor.ascend(1);
    let v109_19_head = Path::from_slice(&[v109_19_byte]);
    let v110_2: Space = singleton(&(v109_19_head));
    let v110_3: Space = intersect(&(*CONSTANT_1),&(v110_2));
    let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
    drop(v110_3);
    let v110_5: Space = subtract(&(*CONSTANT_0),&(v110_4));
    drop(v110_4);
    let mut v110_6 = Space::new();
    let mut v110_6_cursor = (v109_19_tail).read_zipper();
    for v110_6_byte in v110_6_cursor.child_mask().iter() {
      v110_6_cursor.descend_to_byte(v110_6_byte);
      let v110_6_tail = v110_6_cursor.make_map();
      v110_6_cursor.ascend(1);
      let v110_6_head = Path::from_slice(&[v110_6_byte]);
      let v111_2: Space = Space::new();
      v110_6.join_into((v111_2).clone());
    }
    drop(v110_6_cursor);
    let v110_7: Space = compose(&(v110_5),&(v110_6));
    drop(v110_5);
    drop(v110_6);
    let v110_8: Space = intersect(&(*CONSTANT_1),&(v110_2));
    drop(v110_2);
    let v110_9: Space = if has_head(&(v110_8)) { singleton(&[]) } else { Space::new() };
    drop(v110_8);
    let v110_17: Space = if (v110_9).is_empty() { Space::new() } else {
      let v112_10: Space = unwrap(&(v109_10),&(v109_19_head));
      let v112_11: Space = restrict_to(&(v109_9),&(v112_10));
      let mut v112_12 = Space::new();
      let mut v112_12_cursor = (v112_11).read_zipper();
      for v112_12_byte in v112_12_cursor.child_mask().iter() {
        v112_12_cursor.descend_to_byte(v112_12_byte);
        let v112_12_tail = v112_12_cursor.make_map();
        v112_12_cursor.ascend(1);
        let v112_12_head = Path::from_slice(&[v112_12_byte]);
        let v113_2: Space = singleton(&(v112_12_head));
        let v113_3: Space = intersect(&(*CONSTANT_1),&(v113_2));
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = subtract(&(*CONSTANT_0),&(v113_4));
        drop(v113_4);
        let v113_7: Space = if (v113_5).is_empty() { Space::new() } else {
          let v114_6: Space = routine_6(c, &(v112_12_head), &(v112_12_tail));
          compose(&(v113_5),&(v114_6))
        };
        drop(v113_5);
        let v113_8: Space = intersect(&(*CONSTANT_1),&(v113_2));
        drop(v113_2);
        let v113_9: Space = if has_head(&(v113_8)) { singleton(&[]) } else { Space::new() };
        drop(v113_8);
        let v113_11: Space = if (v113_9).is_empty() { Space::new() } else {
          let v115_10: Space = routine_7(c, &(v112_12_head), &(v112_12_tail));
          compose(&(v113_9),&(v115_10))
        };
        drop(v113_9);
        let v113_12: Space = unite(&(v113_7),&(v113_11));
        v112_12.join_into((v113_12).clone());
      }
      drop(v112_12_cursor);
      drop(v112_11);
      let v112_13: Space = restrict_to(&(v109_7),&(v112_12));
      let mut v112_14 = Space::new();
      let mut v112_14_cursor = (v112_13).read_zipper();
      for v112_14_byte in v112_14_cursor.child_mask().iter() {
        v112_14_cursor.descend_to_byte(v112_14_byte);
        let v112_14_tail = v112_14_cursor.make_map();
        v112_14_cursor.ascend(1);
        let v112_14_head = Path::from_slice(&[v112_14_byte]);
        let v116_2: Space = singleton(&(v112_14_head));
        let v116_3: Space = intersect(&(*CONSTANT_1),&(v116_2));
        let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
        drop(v116_3);
        let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
        drop(v116_4);
        let v116_7: Space = if (v116_5).is_empty() { Space::new() } else {
          let v117_6: Space = routine_8(c, &(v112_14_head), &(v112_14_tail));
          compose(&(v116_5),&(v117_6))
        };
        drop(v116_5);
        let v116_8: Space = intersect(&(*CONSTANT_1),&(v116_2));
        drop(v116_2);
        let v116_9: Space = if has_head(&(v116_8)) { singleton(&[]) } else { Space::new() };
        drop(v116_8);
        let v116_11: Space = if (v116_9).is_empty() { Space::new() } else {
          let v118_10: Space = routine_9(c, &(v112_14_head), &(v112_14_tail));
          compose(&(v116_9),&(v118_10))
        };
        drop(v116_9);
        let v116_12: Space = unite(&(v116_7),&(v116_11));
        v112_14.join_into((v116_12).clone());
      }
      drop(v112_14_cursor);
      let v112_15: Space = subtract(&(v112_14),&(v112_10));
      drop(v112_10);
      let v112_16: Space = intersect(&(v112_15),&(v109_12));
      compose(&(v110_9),&(v112_16))
    };
    drop(v110_9);
    let v110_18: Path = concat_path(&(*p0),&(v109_19_head));
    let v110_19: Space = wrap(&(v110_17),&(v110_18));
    drop(v110_18);
    let v110_20: Space = unite(&(v110_7),&(v110_19));
    drop(v110_7);
    v109_19.join_into((v110_20).clone());
  }
  drop(v109_19_cursor);
  drop(v109_7);
  drop(v109_9);
  drop(v109_10);
  drop(v109_12);
  (v109_19).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v119_11 = Space::new();
  let mut v119_11_cursor = (*s0).read_zipper();
  for v119_11_byte in v119_11_cursor.child_mask().iter() {
    v119_11_cursor.descend_to_byte(v119_11_byte);
    let v119_11_tail = v119_11_cursor.make_map();
    v119_11_cursor.ascend(1);
    let v119_11_head = Path::from_slice(&[v119_11_byte]);
    let v120_2: Space = singleton(&(v119_11_head));
    let v120_3: Space = intersect(&(*CONSTANT_1),&(v120_2));
    let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
    drop(v120_3);
    let v120_5: Space = subtract(&(*CONSTANT_0),&(v120_4));
    drop(v120_4);
    let v120_8: Space = if (v120_5).is_empty() { Space::new() } else {
      let v121_6: Path = concat_path(&(*p0),&(v119_11_head));
      let mut v121_7 = Space::new();
      let mut v121_7_cursor = (v119_11_tail).read_zipper();
      for v121_7_byte in v121_7_cursor.child_mask().iter() {
        v121_7_cursor.descend_to_byte(v121_7_byte);
        let v121_7_tail = v121_7_cursor.make_map();
        v121_7_cursor.ascend(1);
        let v121_7_head = Path::from_slice(&[v121_7_byte]);
        let v122_2: Space = singleton(&(v121_7_head));
        let v122_3: Space = intersect(&(*CONSTANT_1),&(v122_2));
        let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
        drop(v122_3);
        let v122_5: Space = subtract(&(*CONSTANT_0),&(v122_4));
        drop(v122_4);
        let v122_8: Space = if (v122_5).is_empty() { Space::new() } else {
          let v123_6: Path = concat_path(&(v121_6),&(v121_7_head));
          let v123_7: Space = routine_22(c, &(v123_6), &(v121_7_tail));
          compose(&(v122_5),&(v123_7))
        };
        drop(v122_5);
        let v122_9: Space = intersect(&(*CONSTANT_1),&(v122_2));
        drop(v122_2);
        let v122_10: Space = if has_head(&(v122_9)) { singleton(&[]) } else { Space::new() };
        drop(v122_9);
        let v122_12: Space = if (v122_10).is_empty() { Space::new() } else {
          let v124_6: Path = concat_path(&(v121_6),&(v121_7_head));
          let v124_11: Space = routine_23(c, &(v124_6), &(v121_7_tail));
          drop(v124_6);
          compose(&(v122_10),&(v124_11))
        };
        drop(v122_10);
        let v122_13: Space = unite(&(v122_8),&(v122_12));
        v121_7.join_into((v122_13).clone());
      }
      drop(v121_7_cursor);
      compose(&(v120_5),&(v121_7))
    };
    drop(v120_5);
    let v120_9: Space = intersect(&(*CONSTANT_1),&(v120_2));
    drop(v120_2);
    let v120_10: Space = if has_head(&(v120_9)) { singleton(&[]) } else { Space::new() };
    drop(v120_9);
    let v120_12: Space = if (v120_10).is_empty() { Space::new() } else {
      let v125_6: Path = concat_path(&(*p0),&(v119_11_head));
      let mut v125_11 = Space::new();
      let mut v125_11_cursor = (v119_11_tail).read_zipper();
      for v125_11_byte in v125_11_cursor.child_mask().iter() {
        v125_11_cursor.descend_to_byte(v125_11_byte);
        let v125_11_tail = v125_11_cursor.make_map();
        v125_11_cursor.ascend(1);
        let v125_11_head = Path::from_slice(&[v125_11_byte]);
        let v126_2: Space = singleton(&(v125_11_head));
        let v126_3: Space = intersect(&(*CONSTANT_1),&(v126_2));
        let v126_4: Space = if has_head(&(v126_3)) { singleton(&[]) } else { Space::new() };
        drop(v126_3);
        let v126_5: Space = subtract(&(*CONSTANT_0),&(v126_4));
        drop(v126_4);
        let v126_8: Space = if (v126_5).is_empty() { Space::new() } else {
          let v127_6: Path = concat_path(&(v125_6),&(v125_11_head));
          let v127_7: Space = routine_22(c, &(v127_6), &(v125_11_tail));
          compose(&(v126_5),&(v127_7))
        };
        drop(v126_5);
        let v126_9: Space = intersect(&(*CONSTANT_1),&(v126_2));
        drop(v126_2);
        let v126_10: Space = if has_head(&(v126_9)) { singleton(&[]) } else { Space::new() };
        drop(v126_9);
        let v126_12: Space = if (v126_10).is_empty() { Space::new() } else {
          let v128_6: Path = concat_path(&(v125_6),&(v125_11_head));
          let v128_11: Space = routine_14(c, &(v128_6), &(v125_11_tail));
          drop(v128_6);
          compose(&(v126_10),&(v128_11))
        };
        drop(v126_10);
        let v126_13: Space = unite(&(v126_8),&(v126_12));
        v125_11.join_into((v126_13).clone());
      }
      drop(v125_11_cursor);
      drop(v125_6);
      compose(&(v120_10),&(v125_11))
    };
    drop(v120_10);
    let v120_13: Space = unite(&(v120_8),&(v120_12));
    v119_11.join_into((v120_13).clone());
  }
  drop(v119_11_cursor);
  (v119_11).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v129_8 = Space::new();
  let mut v129_8_cursor = (*s0).read_zipper();
  for v129_8_byte in v129_8_cursor.child_mask().iter() {
    v129_8_cursor.descend_to_byte(v129_8_byte);
    let v129_8_tail = v129_8_cursor.make_map();
    v129_8_cursor.ascend(1);
    let v129_8_head = Path::from_slice(&[v129_8_byte]);
    let v130_2: Space = singleton(&(v129_8_head));
    let v130_3: Space = intersect(&(*CONSTANT_1),&(v130_2));
    let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
    drop(v130_3);
    let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
    drop(v130_4);
    let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
      let v131_6: Path = concat_path(&(*p0),&(v129_8_head));
      let mut v131_7 = Space::new();
      let mut v131_7_cursor = (v129_8_tail).read_zipper();
      for v131_7_byte in v131_7_cursor.child_mask().iter() {
        v131_7_cursor.descend_to_byte(v131_7_byte);
        let v131_7_tail = v131_7_cursor.make_map();
        v131_7_cursor.ascend(1);
        let v131_7_head = Path::from_slice(&[v131_7_byte]);
        let v132_2: Space = singleton(&(v131_7_head));
        let v132_3: Space = intersect(&(*CONSTANT_1),&(v132_2));
        let v132_4: Space = if has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
        drop(v132_3);
        let v132_5: Space = subtract(&(*CONSTANT_0),&(v132_4));
        drop(v132_4);
        let v132_8: Space = if (v132_5).is_empty() { Space::new() } else {
          let v133_6: Path = concat_path(&(v131_6),&(v131_7_head));
          let v133_7: Space = routine_22(c, &(v133_6), &(v131_7_tail));
          compose(&(v132_5),&(v133_7))
        };
        drop(v132_5);
        let v132_9: Space = intersect(&(*CONSTANT_1),&(v132_2));
        drop(v132_2);
        let v132_10: Space = if has_head(&(v132_9)) { singleton(&[]) } else { Space::new() };
        drop(v132_9);
        let v132_12: Space = if (v132_10).is_empty() { Space::new() } else {
          let v134_6: Path = concat_path(&(v131_6),&(v131_7_head));
          let v134_11: Space = routine_23(c, &(v134_6), &(v131_7_tail));
          drop(v134_6);
          compose(&(v132_10),&(v134_11))
        };
        drop(v132_10);
        let v132_13: Space = unite(&(v132_8),&(v132_12));
        v131_7.join_into((v132_13).clone());
      }
      drop(v131_7_cursor);
      drop(v131_6);
      compose(&(v130_5),&(v131_7))
    };
    drop(v130_5);
    let v130_9: Space = intersect(&(*CONSTANT_1),&(v130_2));
    drop(v130_2);
    let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
    drop(v130_9);
    let v130_11: Space = compose(&(v130_10),&(v129_8_tail));
    drop(v130_10);
    let v130_12: Space = unite(&(v130_8),&(v130_11));
    drop(v130_11);
    v129_8.join_into((v130_12).clone());
  }
  drop(v129_8_cursor);
  (v129_8).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v136_11 = Space::new();
  let mut v136_11_cursor = (*s0).read_zipper();
  for v136_11_byte in v136_11_cursor.child_mask().iter() {
    v136_11_cursor.descend_to_byte(v136_11_byte);
    let v136_11_tail = v136_11_cursor.make_map();
    v136_11_cursor.ascend(1);
    let v136_11_head = Path::from_slice(&[v136_11_byte]);
    let v137_2: Space = singleton(&(v136_11_head));
    let v137_3: Space = intersect(&(*CONSTANT_1),&(v137_2));
    let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
    drop(v137_3);
    let v137_5: Space = subtract(&(*CONSTANT_0),&(v137_4));
    drop(v137_4);
    let v137_8: Space = if (v137_5).is_empty() { Space::new() } else {
      let v138_6: Path = concat_path(&(*p0),&(v136_11_head));
      let mut v138_7 = Space::new();
      let mut v138_7_cursor = (v136_11_tail).read_zipper();
      for v138_7_byte in v138_7_cursor.child_mask().iter() {
        v138_7_cursor.descend_to_byte(v138_7_byte);
        let v138_7_tail = v138_7_cursor.make_map();
        v138_7_cursor.ascend(1);
        let v138_7_head = Path::from_slice(&[v138_7_byte]);
        let v139_2: Space = singleton(&(v138_7_head));
        let v139_3: Space = intersect(&(*CONSTANT_1),&(v139_2));
        let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
        drop(v139_3);
        let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
        drop(v139_4);
        let v139_8: Space = if (v139_5).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v138_6),&(v138_7_head));
          let v140_7: Space = routine_24(c, &(v140_6), &(v138_7_tail));
          compose(&(v139_5),&(v140_7))
        };
        drop(v139_5);
        let v139_9: Space = intersect(&(*CONSTANT_1),&(v139_2));
        drop(v139_2);
        let v139_10: Space = if has_head(&(v139_9)) { singleton(&[]) } else { Space::new() };
        drop(v139_9);
        let v139_12: Space = if (v139_10).is_empty() { Space::new() } else {
          let v141_6: Path = concat_path(&(v138_6),&(v138_7_head));
          let v141_11: Space = routine_25(c, &(v141_6), &(v138_7_tail));
          drop(v141_6);
          compose(&(v139_10),&(v141_11))
        };
        drop(v139_10);
        let v139_13: Space = unite(&(v139_8),&(v139_12));
        v138_7.join_into((v139_13).clone());
      }
      drop(v138_7_cursor);
      compose(&(v137_5),&(v138_7))
    };
    drop(v137_5);
    let v137_9: Space = intersect(&(*CONSTANT_1),&(v137_2));
    drop(v137_2);
    let v137_10: Space = if has_head(&(v137_9)) { singleton(&[]) } else { Space::new() };
    drop(v137_9);
    let v137_12: Space = if (v137_10).is_empty() { Space::new() } else {
      let v142_6: Path = concat_path(&(*p0),&(v136_11_head));
      let mut v142_11 = Space::new();
      let mut v142_11_cursor = (v136_11_tail).read_zipper();
      for v142_11_byte in v142_11_cursor.child_mask().iter() {
        v142_11_cursor.descend_to_byte(v142_11_byte);
        let v142_11_tail = v142_11_cursor.make_map();
        v142_11_cursor.ascend(1);
        let v142_11_head = Path::from_slice(&[v142_11_byte]);
        let v143_2: Space = singleton(&(v142_11_head));
        let v143_3: Space = intersect(&(*CONSTANT_1),&(v143_2));
        let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
        drop(v143_3);
        let v143_5: Space = subtract(&(*CONSTANT_0),&(v143_4));
        drop(v143_4);
        let v143_8: Space = if (v143_5).is_empty() { Space::new() } else {
          let v144_6: Path = concat_path(&(v142_6),&(v142_11_head));
          let v144_7: Space = routine_24(c, &(v144_6), &(v142_11_tail));
          compose(&(v143_5),&(v144_7))
        };
        drop(v143_5);
        let v143_9: Space = intersect(&(*CONSTANT_1),&(v143_2));
        drop(v143_2);
        let v143_10: Space = if has_head(&(v143_9)) { singleton(&[]) } else { Space::new() };
        drop(v143_9);
        let v143_12: Space = if (v143_10).is_empty() { Space::new() } else {
          let v145_6: Path = concat_path(&(v142_6),&(v142_11_head));
          let v145_11: Space = routine_17(c, &(v145_6), &(v142_11_tail));
          drop(v145_6);
          compose(&(v143_10),&(v145_11))
        };
        drop(v143_10);
        let v143_13: Space = unite(&(v143_8),&(v143_12));
        v142_11.join_into((v143_13).clone());
      }
      drop(v142_11_cursor);
      drop(v142_6);
      compose(&(v137_10),&(v142_11))
    };
    drop(v137_10);
    let v137_13: Space = unite(&(v137_8),&(v137_12));
    v136_11.join_into((v137_13).clone());
  }
  drop(v136_11_cursor);
  (v136_11).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v146_8 = Space::new();
  let mut v146_8_cursor = (*s0).read_zipper();
  for v146_8_byte in v146_8_cursor.child_mask().iter() {
    v146_8_cursor.descend_to_byte(v146_8_byte);
    let v146_8_tail = v146_8_cursor.make_map();
    v146_8_cursor.ascend(1);
    let v146_8_head = Path::from_slice(&[v146_8_byte]);
    let v147_2: Space = singleton(&(v146_8_head));
    let v147_3: Space = intersect(&(*CONSTANT_1),&(v147_2));
    let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
    drop(v147_3);
    let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
    drop(v147_4);
    let v147_8: Space = if (v147_5).is_empty() { Space::new() } else {
      let v148_6: Path = concat_path(&(*p0),&(v146_8_head));
      let mut v148_7 = Space::new();
      let mut v148_7_cursor = (v146_8_tail).read_zipper();
      for v148_7_byte in v148_7_cursor.child_mask().iter() {
        v148_7_cursor.descend_to_byte(v148_7_byte);
        let v148_7_tail = v148_7_cursor.make_map();
        v148_7_cursor.ascend(1);
        let v148_7_head = Path::from_slice(&[v148_7_byte]);
        let v149_2: Space = singleton(&(v148_7_head));
        let v149_3: Space = intersect(&(*CONSTANT_1),&(v149_2));
        let v149_4: Space = if has_head(&(v149_3)) { singleton(&[]) } else { Space::new() };
        drop(v149_3);
        let v149_5: Space = subtract(&(*CONSTANT_0),&(v149_4));
        drop(v149_4);
        let v149_8: Space = if (v149_5).is_empty() { Space::new() } else {
          let v150_6: Path = concat_path(&(v148_6),&(v148_7_head));
          let v150_7: Space = routine_24(c, &(v150_6), &(v148_7_tail));
          compose(&(v149_5),&(v150_7))
        };
        drop(v149_5);
        let v149_9: Space = intersect(&(*CONSTANT_1),&(v149_2));
        drop(v149_2);
        let v149_10: Space = if has_head(&(v149_9)) { singleton(&[]) } else { Space::new() };
        drop(v149_9);
        let v149_12: Space = if (v149_10).is_empty() { Space::new() } else {
          let v151_6: Path = concat_path(&(v148_6),&(v148_7_head));
          let v151_11: Space = routine_25(c, &(v151_6), &(v148_7_tail));
          drop(v151_6);
          compose(&(v149_10),&(v151_11))
        };
        drop(v149_10);
        let v149_13: Space = unite(&(v149_8),&(v149_12));
        v148_7.join_into((v149_13).clone());
      }
      drop(v148_7_cursor);
      drop(v148_6);
      compose(&(v147_5),&(v148_7))
    };
    drop(v147_5);
    let v147_9: Space = intersect(&(*CONSTANT_1),&(v147_2));
    drop(v147_2);
    let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
    drop(v147_9);
    let v147_11: Space = compose(&(v147_10),&(v146_8_tail));
    drop(v147_10);
    let v147_12: Space = unite(&(v147_8),&(v147_11));
    drop(v147_11);
    v146_8.join_into((v147_12).clone());
  }
  drop(v146_8_cursor);
  (v146_8).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v153_11 = Space::new();
  let mut v153_11_cursor = (*s0).read_zipper();
  for v153_11_byte in v153_11_cursor.child_mask().iter() {
    v153_11_cursor.descend_to_byte(v153_11_byte);
    let v153_11_tail = v153_11_cursor.make_map();
    v153_11_cursor.ascend(1);
    let v153_11_head = Path::from_slice(&[v153_11_byte]);
    let v154_2: Space = singleton(&(v153_11_head));
    let v154_3: Space = intersect(&(*CONSTANT_1),&(v154_2));
    let v154_4: Space = if has_head(&(v154_3)) { singleton(&[]) } else { Space::new() };
    drop(v154_3);
    let v154_5: Space = subtract(&(*CONSTANT_0),&(v154_4));
    drop(v154_4);
    let v154_8: Space = if (v154_5).is_empty() { Space::new() } else {
      let v155_6: Path = concat_path(&(*p0),&(v153_11_head));
      let mut v155_7 = Space::new();
      let mut v155_7_cursor = (v153_11_tail).read_zipper();
      for v155_7_byte in v155_7_cursor.child_mask().iter() {
        v155_7_cursor.descend_to_byte(v155_7_byte);
        let v155_7_tail = v155_7_cursor.make_map();
        v155_7_cursor.ascend(1);
        let v155_7_head = Path::from_slice(&[v155_7_byte]);
        let v156_2: Space = singleton(&(v155_7_head));
        let v156_3: Space = intersect(&(*CONSTANT_1),&(v156_2));
        let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
        drop(v156_3);
        let v156_5: Space = subtract(&(*CONSTANT_0),&(v156_4));
        drop(v156_4);
        let v156_8: Space = if (v156_5).is_empty() { Space::new() } else {
          let v157_6: Path = concat_path(&(v155_6),&(v155_7_head));
          let v157_7: Space = routine_26(c, &(v157_6), &(v155_7_tail));
          compose(&(v156_5),&(v157_7))
        };
        drop(v156_5);
        let v156_9: Space = intersect(&(*CONSTANT_1),&(v156_2));
        drop(v156_2);
        let v156_10: Space = if has_head(&(v156_9)) { singleton(&[]) } else { Space::new() };
        drop(v156_9);
        let v156_12: Space = if (v156_10).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v155_6),&(v155_7_head));
          let v158_11: Space = routine_27(c, &(v158_6), &(v155_7_tail));
          drop(v158_6);
          compose(&(v156_10),&(v158_11))
        };
        drop(v156_10);
        let v156_13: Space = unite(&(v156_8),&(v156_12));
        v155_7.join_into((v156_13).clone());
      }
      drop(v155_7_cursor);
      compose(&(v154_5),&(v155_7))
    };
    drop(v154_5);
    let v154_9: Space = intersect(&(*CONSTANT_1),&(v154_2));
    drop(v154_2);
    let v154_10: Space = if has_head(&(v154_9)) { singleton(&[]) } else { Space::new() };
    drop(v154_9);
    let v154_12: Space = if (v154_10).is_empty() { Space::new() } else {
      let v159_6: Path = concat_path(&(*p0),&(v153_11_head));
      let mut v159_11 = Space::new();
      let mut v159_11_cursor = (v153_11_tail).read_zipper();
      for v159_11_byte in v159_11_cursor.child_mask().iter() {
        v159_11_cursor.descend_to_byte(v159_11_byte);
        let v159_11_tail = v159_11_cursor.make_map();
        v159_11_cursor.ascend(1);
        let v159_11_head = Path::from_slice(&[v159_11_byte]);
        let v160_2: Space = singleton(&(v159_11_head));
        let v160_3: Space = intersect(&(*CONSTANT_1),&(v160_2));
        let v160_4: Space = if has_head(&(v160_3)) { singleton(&[]) } else { Space::new() };
        drop(v160_3);
        let v160_5: Space = subtract(&(*CONSTANT_0),&(v160_4));
        drop(v160_4);
        let v160_8: Space = if (v160_5).is_empty() { Space::new() } else {
          let v161_6: Path = concat_path(&(v159_6),&(v159_11_head));
          let v161_7: Space = routine_26(c, &(v161_6), &(v159_11_tail));
          compose(&(v160_5),&(v161_7))
        };
        drop(v160_5);
        let v160_9: Space = intersect(&(*CONSTANT_1),&(v160_2));
        drop(v160_2);
        let v160_10: Space = if has_head(&(v160_9)) { singleton(&[]) } else { Space::new() };
        drop(v160_9);
        let v160_12: Space = if (v160_10).is_empty() { Space::new() } else {
          let v162_6: Path = concat_path(&(v159_6),&(v159_11_head));
          let v162_11: Space = routine_14(c, &(v162_6), &(v159_11_tail));
          drop(v162_6);
          compose(&(v160_10),&(v162_11))
        };
        drop(v160_10);
        let v160_13: Space = unite(&(v160_8),&(v160_12));
        v159_11.join_into((v160_13).clone());
      }
      drop(v159_11_cursor);
      drop(v159_6);
      compose(&(v154_10),&(v159_11))
    };
    drop(v154_10);
    let v154_13: Space = unite(&(v154_8),&(v154_12));
    v153_11.join_into((v154_13).clone());
  }
  drop(v153_11_cursor);
  (v153_11).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v163_8 = Space::new();
  let mut v163_8_cursor = (*s0).read_zipper();
  for v163_8_byte in v163_8_cursor.child_mask().iter() {
    v163_8_cursor.descend_to_byte(v163_8_byte);
    let v163_8_tail = v163_8_cursor.make_map();
    v163_8_cursor.ascend(1);
    let v163_8_head = Path::from_slice(&[v163_8_byte]);
    let v164_2: Space = singleton(&(v163_8_head));
    let v164_3: Space = intersect(&(*CONSTANT_1),&(v164_2));
    let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
    drop(v164_3);
    let v164_5: Space = subtract(&(*CONSTANT_0),&(v164_4));
    drop(v164_4);
    let v164_8: Space = if (v164_5).is_empty() { Space::new() } else {
      let v165_6: Path = concat_path(&(*p0),&(v163_8_head));
      let mut v165_7 = Space::new();
      let mut v165_7_cursor = (v163_8_tail).read_zipper();
      for v165_7_byte in v165_7_cursor.child_mask().iter() {
        v165_7_cursor.descend_to_byte(v165_7_byte);
        let v165_7_tail = v165_7_cursor.make_map();
        v165_7_cursor.ascend(1);
        let v165_7_head = Path::from_slice(&[v165_7_byte]);
        let v166_2: Space = singleton(&(v165_7_head));
        let v166_3: Space = intersect(&(*CONSTANT_1),&(v166_2));
        let v166_4: Space = if has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
        drop(v166_3);
        let v166_5: Space = subtract(&(*CONSTANT_0),&(v166_4));
        drop(v166_4);
        let v166_8: Space = if (v166_5).is_empty() { Space::new() } else {
          let v167_6: Path = concat_path(&(v165_6),&(v165_7_head));
          let v167_7: Space = routine_26(c, &(v167_6), &(v165_7_tail));
          compose(&(v166_5),&(v167_7))
        };
        drop(v166_5);
        let v166_9: Space = intersect(&(*CONSTANT_1),&(v166_2));
        drop(v166_2);
        let v166_10: Space = if has_head(&(v166_9)) { singleton(&[]) } else { Space::new() };
        drop(v166_9);
        let v166_12: Space = if (v166_10).is_empty() { Space::new() } else {
          let v168_6: Path = concat_path(&(v165_6),&(v165_7_head));
          let v168_11: Space = routine_27(c, &(v168_6), &(v165_7_tail));
          drop(v168_6);
          compose(&(v166_10),&(v168_11))
        };
        drop(v166_10);
        let v166_13: Space = unite(&(v166_8),&(v166_12));
        v165_7.join_into((v166_13).clone());
      }
      drop(v165_7_cursor);
      drop(v165_6);
      compose(&(v164_5),&(v165_7))
    };
    drop(v164_5);
    let v164_9: Space = intersect(&(*CONSTANT_1),&(v164_2));
    drop(v164_2);
    let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
    drop(v164_9);
    let v164_11: Space = compose(&(v164_10),&(v163_8_tail));
    drop(v164_10);
    let v164_12: Space = unite(&(v164_8),&(v164_11));
    drop(v164_11);
    v163_8.join_into((v164_12).clone());
  }
  drop(v163_8_cursor);
  (v163_8).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v169_11 = Space::new();
  let mut v169_11_cursor = (*s0).read_zipper();
  for v169_11_byte in v169_11_cursor.child_mask().iter() {
    v169_11_cursor.descend_to_byte(v169_11_byte);
    let v169_11_tail = v169_11_cursor.make_map();
    v169_11_cursor.ascend(1);
    let v169_11_head = Path::from_slice(&[v169_11_byte]);
    let v170_2: Space = singleton(&(v169_11_head));
    let v170_3: Space = intersect(&(*CONSTANT_1),&(v170_2));
    let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
    drop(v170_3);
    let v170_5: Space = subtract(&(*CONSTANT_0),&(v170_4));
    drop(v170_4);
    let v170_8: Space = if (v170_5).is_empty() { Space::new() } else {
      let v171_6: Path = concat_path(&(*p0),&(v169_11_head));
      let mut v171_7 = Space::new();
      let mut v171_7_cursor = (v169_11_tail).read_zipper();
      for v171_7_byte in v171_7_cursor.child_mask().iter() {
        v171_7_cursor.descend_to_byte(v171_7_byte);
        let v171_7_tail = v171_7_cursor.make_map();
        v171_7_cursor.ascend(1);
        let v171_7_head = Path::from_slice(&[v171_7_byte]);
        let v172_2: Space = singleton(&(v171_7_head));
        let v172_3: Space = intersect(&(*CONSTANT_1),&(v172_2));
        let v172_4: Space = if has_head(&(v172_3)) { singleton(&[]) } else { Space::new() };
        drop(v172_3);
        let v172_5: Space = subtract(&(*CONSTANT_0),&(v172_4));
        drop(v172_4);
        let v172_8: Space = if (v172_5).is_empty() { Space::new() } else {
          let v173_6: Path = concat_path(&(v171_6),&(v171_7_head));
          let v173_7: Space = routine_28(c, &(v173_6), &(v171_7_tail));
          compose(&(v172_5),&(v173_7))
        };
        drop(v172_5);
        let v172_9: Space = intersect(&(*CONSTANT_1),&(v172_2));
        drop(v172_2);
        let v172_10: Space = if has_head(&(v172_9)) { singleton(&[]) } else { Space::new() };
        drop(v172_9);
        let v172_12: Space = if (v172_10).is_empty() { Space::new() } else {
          let v174_6: Path = concat_path(&(v171_6),&(v171_7_head));
          let v174_11: Space = routine_29(c, &(v174_6), &(v171_7_tail));
          drop(v174_6);
          compose(&(v172_10),&(v174_11))
        };
        drop(v172_10);
        let v172_13: Space = unite(&(v172_8),&(v172_12));
        v171_7.join_into((v172_13).clone());
      }
      drop(v171_7_cursor);
      compose(&(v170_5),&(v171_7))
    };
    drop(v170_5);
    let v170_9: Space = intersect(&(*CONSTANT_1),&(v170_2));
    drop(v170_2);
    let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
    drop(v170_9);
    let v170_12: Space = if (v170_10).is_empty() { Space::new() } else {
      let v175_6: Path = concat_path(&(*p0),&(v169_11_head));
      let mut v175_11 = Space::new();
      let mut v175_11_cursor = (v169_11_tail).read_zipper();
      for v175_11_byte in v175_11_cursor.child_mask().iter() {
        v175_11_cursor.descend_to_byte(v175_11_byte);
        let v175_11_tail = v175_11_cursor.make_map();
        v175_11_cursor.ascend(1);
        let v175_11_head = Path::from_slice(&[v175_11_byte]);
        let v176_2: Space = singleton(&(v175_11_head));
        let v176_3: Space = intersect(&(*CONSTANT_1),&(v176_2));
        let v176_4: Space = if has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
        drop(v176_3);
        let v176_5: Space = subtract(&(*CONSTANT_0),&(v176_4));
        drop(v176_4);
        let v176_8: Space = if (v176_5).is_empty() { Space::new() } else {
          let v177_6: Path = concat_path(&(v175_6),&(v175_11_head));
          let v177_7: Space = routine_28(c, &(v177_6), &(v175_11_tail));
          compose(&(v176_5),&(v177_7))
        };
        drop(v176_5);
        let v176_9: Space = intersect(&(*CONSTANT_1),&(v176_2));
        drop(v176_2);
        let v176_10: Space = if has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
        drop(v176_9);
        let v176_12: Space = if (v176_10).is_empty() { Space::new() } else {
          let v178_6: Path = concat_path(&(v175_6),&(v175_11_head));
          let v178_11: Space = routine_17(c, &(v178_6), &(v175_11_tail));
          drop(v178_6);
          compose(&(v176_10),&(v178_11))
        };
        drop(v176_10);
        let v176_13: Space = unite(&(v176_8),&(v176_12));
        v175_11.join_into((v176_13).clone());
      }
      drop(v175_11_cursor);
      drop(v175_6);
      compose(&(v170_10),&(v175_11))
    };
    drop(v170_10);
    let v170_13: Space = unite(&(v170_8),&(v170_12));
    v169_11.join_into((v170_13).clone());
  }
  drop(v169_11_cursor);
  (v169_11).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v179_8 = Space::new();
  let mut v179_8_cursor = (*s0).read_zipper();
  for v179_8_byte in v179_8_cursor.child_mask().iter() {
    v179_8_cursor.descend_to_byte(v179_8_byte);
    let v179_8_tail = v179_8_cursor.make_map();
    v179_8_cursor.ascend(1);
    let v179_8_head = Path::from_slice(&[v179_8_byte]);
    let v180_2: Space = singleton(&(v179_8_head));
    let v180_3: Space = intersect(&(*CONSTANT_1),&(v180_2));
    let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
    drop(v180_3);
    let v180_5: Space = subtract(&(*CONSTANT_0),&(v180_4));
    drop(v180_4);
    let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
      let v181_6: Path = concat_path(&(*p0),&(v179_8_head));
      let mut v181_7 = Space::new();
      let mut v181_7_cursor = (v179_8_tail).read_zipper();
      for v181_7_byte in v181_7_cursor.child_mask().iter() {
        v181_7_cursor.descend_to_byte(v181_7_byte);
        let v181_7_tail = v181_7_cursor.make_map();
        v181_7_cursor.ascend(1);
        let v181_7_head = Path::from_slice(&[v181_7_byte]);
        let v182_2: Space = singleton(&(v181_7_head));
        let v182_3: Space = intersect(&(*CONSTANT_1),&(v182_2));
        let v182_4: Space = if has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
        drop(v182_3);
        let v182_5: Space = subtract(&(*CONSTANT_0),&(v182_4));
        drop(v182_4);
        let v182_8: Space = if (v182_5).is_empty() { Space::new() } else {
          let v183_6: Path = concat_path(&(v181_6),&(v181_7_head));
          let v183_7: Space = routine_28(c, &(v183_6), &(v181_7_tail));
          compose(&(v182_5),&(v183_7))
        };
        drop(v182_5);
        let v182_9: Space = intersect(&(*CONSTANT_1),&(v182_2));
        drop(v182_2);
        let v182_10: Space = if has_head(&(v182_9)) { singleton(&[]) } else { Space::new() };
        drop(v182_9);
        let v182_12: Space = if (v182_10).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v181_6),&(v181_7_head));
          let v184_11: Space = routine_29(c, &(v184_6), &(v181_7_tail));
          drop(v184_6);
          compose(&(v182_10),&(v184_11))
        };
        drop(v182_10);
        let v182_13: Space = unite(&(v182_8),&(v182_12));
        v181_7.join_into((v182_13).clone());
      }
      drop(v181_7_cursor);
      drop(v181_6);
      compose(&(v180_5),&(v181_7))
    };
    drop(v180_5);
    let v180_9: Space = intersect(&(*CONSTANT_1),&(v180_2));
    drop(v180_2);
    let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
    drop(v180_9);
    let v180_11: Space = compose(&(v180_10),&(v179_8_tail));
    drop(v180_10);
    let v180_12: Space = unite(&(v180_8),&(v180_11));
    drop(v180_11);
    v179_8.join_into((v180_12).clone());
  }
  drop(v179_8_cursor);
  (v179_8).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v185_11 = Space::new();
  let mut v185_11_cursor = (*s0).read_zipper();
  for v185_11_byte in v185_11_cursor.child_mask().iter() {
    v185_11_cursor.descend_to_byte(v185_11_byte);
    let v185_11_tail = v185_11_cursor.make_map();
    v185_11_cursor.ascend(1);
    let v185_11_head = Path::from_slice(&[v185_11_byte]);
    let v186_2: Space = singleton(&(v185_11_head));
    let v186_3: Space = intersect(&(*CONSTANT_1),&(v186_2));
    let v186_4: Space = if has_head(&(v186_3)) { singleton(&[]) } else { Space::new() };
    drop(v186_3);
    let v186_5: Space = subtract(&(*CONSTANT_0),&(v186_4));
    drop(v186_4);
    let v186_8: Space = if (v186_5).is_empty() { Space::new() } else {
      let v187_6: Path = concat_path(&(*p0),&(v185_11_head));
      let mut v187_7 = Space::new();
      let mut v187_7_cursor = (v185_11_tail).read_zipper();
      for v187_7_byte in v187_7_cursor.child_mask().iter() {
        v187_7_cursor.descend_to_byte(v187_7_byte);
        let v187_7_tail = v187_7_cursor.make_map();
        v187_7_cursor.ascend(1);
        let v187_7_head = Path::from_slice(&[v187_7_byte]);
        let v188_2: Space = singleton(&(v187_7_head));
        let v188_3: Space = intersect(&(*CONSTANT_1),&(v188_2));
        let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
        drop(v188_3);
        let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
        drop(v188_4);
        let v188_8: Space = if (v188_5).is_empty() { Space::new() } else {
          let v189_6: Path = concat_path(&(v187_6),&(v187_7_head));
          let v189_7: Space = routine_30(c, &(v189_6), &(v187_7_tail));
          compose(&(v188_5),&(v189_7))
        };
        drop(v188_5);
        let v188_9: Space = intersect(&(*CONSTANT_1),&(v188_2));
        drop(v188_2);
        let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
        drop(v188_9);
        let v188_12: Space = if (v188_10).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v187_6),&(v187_7_head));
          let v190_11: Space = routine_31(c, &(v190_6), &(v187_7_tail));
          drop(v190_6);
          compose(&(v188_10),&(v190_11))
        };
        drop(v188_10);
        let v188_13: Space = unite(&(v188_8),&(v188_12));
        v187_7.join_into((v188_13).clone());
      }
      drop(v187_7_cursor);
      compose(&(v186_5),&(v187_7))
    };
    drop(v186_5);
    let v186_9: Space = intersect(&(*CONSTANT_1),&(v186_2));
    drop(v186_2);
    let v186_10: Space = if has_head(&(v186_9)) { singleton(&[]) } else { Space::new() };
    drop(v186_9);
    let v186_12: Space = if (v186_10).is_empty() { Space::new() } else {
      let v191_6: Path = concat_path(&(*p0),&(v185_11_head));
      let mut v191_11 = Space::new();
      let mut v191_11_cursor = (v185_11_tail).read_zipper();
      for v191_11_byte in v191_11_cursor.child_mask().iter() {
        v191_11_cursor.descend_to_byte(v191_11_byte);
        let v191_11_tail = v191_11_cursor.make_map();
        v191_11_cursor.ascend(1);
        let v191_11_head = Path::from_slice(&[v191_11_byte]);
        let v192_2: Space = singleton(&(v191_11_head));
        let v192_3: Space = intersect(&(*CONSTANT_1),&(v192_2));
        let v192_4: Space = if has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
        drop(v192_3);
        let v192_5: Space = subtract(&(*CONSTANT_0),&(v192_4));
        drop(v192_4);
        let v192_8: Space = if (v192_5).is_empty() { Space::new() } else {
          let v193_6: Path = concat_path(&(v191_6),&(v191_11_head));
          let v193_7: Space = routine_30(c, &(v193_6), &(v191_11_tail));
          compose(&(v192_5),&(v193_7))
        };
        drop(v192_5);
        let v192_9: Space = intersect(&(*CONSTANT_1),&(v192_2));
        drop(v192_2);
        let v192_10: Space = if has_head(&(v192_9)) { singleton(&[]) } else { Space::new() };
        drop(v192_9);
        let v192_12: Space = if (v192_10).is_empty() { Space::new() } else {
          let v194_6: Path = concat_path(&(v191_6),&(v191_11_head));
          let v194_11: Space = routine_14(c, &(v194_6), &(v191_11_tail));
          drop(v194_6);
          compose(&(v192_10),&(v194_11))
        };
        drop(v192_10);
        let v192_13: Space = unite(&(v192_8),&(v192_12));
        v191_11.join_into((v192_13).clone());
      }
      drop(v191_11_cursor);
      drop(v191_6);
      compose(&(v186_10),&(v191_11))
    };
    drop(v186_10);
    let v186_13: Space = unite(&(v186_8),&(v186_12));
    v185_11.join_into((v186_13).clone());
  }
  drop(v185_11_cursor);
  (v185_11).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v195_8 = Space::new();
  let mut v195_8_cursor = (*s0).read_zipper();
  for v195_8_byte in v195_8_cursor.child_mask().iter() {
    v195_8_cursor.descend_to_byte(v195_8_byte);
    let v195_8_tail = v195_8_cursor.make_map();
    v195_8_cursor.ascend(1);
    let v195_8_head = Path::from_slice(&[v195_8_byte]);
    let v196_2: Space = singleton(&(v195_8_head));
    let v196_3: Space = intersect(&(*CONSTANT_1),&(v196_2));
    let v196_4: Space = if has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
    drop(v196_3);
    let v196_5: Space = subtract(&(*CONSTANT_0),&(v196_4));
    drop(v196_4);
    let v196_8: Space = if (v196_5).is_empty() { Space::new() } else {
      let v197_6: Path = concat_path(&(*p0),&(v195_8_head));
      let mut v197_7 = Space::new();
      let mut v197_7_cursor = (v195_8_tail).read_zipper();
      for v197_7_byte in v197_7_cursor.child_mask().iter() {
        v197_7_cursor.descend_to_byte(v197_7_byte);
        let v197_7_tail = v197_7_cursor.make_map();
        v197_7_cursor.ascend(1);
        let v197_7_head = Path::from_slice(&[v197_7_byte]);
        let v198_2: Space = singleton(&(v197_7_head));
        let v198_3: Space = intersect(&(*CONSTANT_1),&(v198_2));
        let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
        drop(v198_3);
        let v198_5: Space = subtract(&(*CONSTANT_0),&(v198_4));
        drop(v198_4);
        let v198_8: Space = if (v198_5).is_empty() { Space::new() } else {
          let v199_6: Path = concat_path(&(v197_6),&(v197_7_head));
          let v199_7: Space = routine_30(c, &(v199_6), &(v197_7_tail));
          compose(&(v198_5),&(v199_7))
        };
        drop(v198_5);
        let v198_9: Space = intersect(&(*CONSTANT_1),&(v198_2));
        drop(v198_2);
        let v198_10: Space = if has_head(&(v198_9)) { singleton(&[]) } else { Space::new() };
        drop(v198_9);
        let v198_12: Space = if (v198_10).is_empty() { Space::new() } else {
          let v200_6: Path = concat_path(&(v197_6),&(v197_7_head));
          let v200_11: Space = routine_31(c, &(v200_6), &(v197_7_tail));
          drop(v200_6);
          compose(&(v198_10),&(v200_11))
        };
        drop(v198_10);
        let v198_13: Space = unite(&(v198_8),&(v198_12));
        v197_7.join_into((v198_13).clone());
      }
      drop(v197_7_cursor);
      drop(v197_6);
      compose(&(v196_5),&(v197_7))
    };
    drop(v196_5);
    let v196_9: Space = intersect(&(*CONSTANT_1),&(v196_2));
    drop(v196_2);
    let v196_10: Space = if has_head(&(v196_9)) { singleton(&[]) } else { Space::new() };
    drop(v196_9);
    let v196_11: Space = compose(&(v196_10),&(v195_8_tail));
    drop(v196_10);
    let v196_12: Space = unite(&(v196_8),&(v196_11));
    drop(v196_11);
    v195_8.join_into((v196_12).clone());
  }
  drop(v195_8_cursor);
  (v195_8).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v201_11 = Space::new();
  let mut v201_11_cursor = (*s0).read_zipper();
  for v201_11_byte in v201_11_cursor.child_mask().iter() {
    v201_11_cursor.descend_to_byte(v201_11_byte);
    let v201_11_tail = v201_11_cursor.make_map();
    v201_11_cursor.ascend(1);
    let v201_11_head = Path::from_slice(&[v201_11_byte]);
    let v202_2: Space = singleton(&(v201_11_head));
    let v202_3: Space = intersect(&(*CONSTANT_1),&(v202_2));
    let v202_4: Space = if has_head(&(v202_3)) { singleton(&[]) } else { Space::new() };
    drop(v202_3);
    let v202_5: Space = subtract(&(*CONSTANT_0),&(v202_4));
    drop(v202_4);
    let v202_8: Space = if (v202_5).is_empty() { Space::new() } else {
      let v203_6: Path = concat_path(&(*p0),&(v201_11_head));
      let mut v203_7 = Space::new();
      let mut v203_7_cursor = (v201_11_tail).read_zipper();
      for v203_7_byte in v203_7_cursor.child_mask().iter() {
        v203_7_cursor.descend_to_byte(v203_7_byte);
        let v203_7_tail = v203_7_cursor.make_map();
        v203_7_cursor.ascend(1);
        let v203_7_head = Path::from_slice(&[v203_7_byte]);
        let v204_2: Space = singleton(&(v203_7_head));
        let v204_3: Space = intersect(&(*CONSTANT_1),&(v204_2));
        let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
        drop(v204_3);
        let v204_5: Space = subtract(&(*CONSTANT_0),&(v204_4));
        drop(v204_4);
        let v204_8: Space = if (v204_5).is_empty() { Space::new() } else {
          let v205_6: Path = concat_path(&(v203_6),&(v203_7_head));
          let v205_7: Space = routine_32(c, &(v205_6), &(v203_7_tail));
          compose(&(v204_5),&(v205_7))
        };
        drop(v204_5);
        let v204_9: Space = intersect(&(*CONSTANT_1),&(v204_2));
        drop(v204_2);
        let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
        drop(v204_9);
        let v204_12: Space = if (v204_10).is_empty() { Space::new() } else {
          let v206_6: Path = concat_path(&(v203_6),&(v203_7_head));
          let v206_11: Space = routine_33(c, &(v206_6), &(v203_7_tail));
          drop(v206_6);
          compose(&(v204_10),&(v206_11))
        };
        drop(v204_10);
        let v204_13: Space = unite(&(v204_8),&(v204_12));
        v203_7.join_into((v204_13).clone());
      }
      drop(v203_7_cursor);
      compose(&(v202_5),&(v203_7))
    };
    drop(v202_5);
    let v202_9: Space = intersect(&(*CONSTANT_1),&(v202_2));
    drop(v202_2);
    let v202_10: Space = if has_head(&(v202_9)) { singleton(&[]) } else { Space::new() };
    drop(v202_9);
    let v202_12: Space = if (v202_10).is_empty() { Space::new() } else {
      let v207_6: Path = concat_path(&(*p0),&(v201_11_head));
      let mut v207_11 = Space::new();
      let mut v207_11_cursor = (v201_11_tail).read_zipper();
      for v207_11_byte in v207_11_cursor.child_mask().iter() {
        v207_11_cursor.descend_to_byte(v207_11_byte);
        let v207_11_tail = v207_11_cursor.make_map();
        v207_11_cursor.ascend(1);
        let v207_11_head = Path::from_slice(&[v207_11_byte]);
        let v208_2: Space = singleton(&(v207_11_head));
        let v208_3: Space = intersect(&(*CONSTANT_1),&(v208_2));
        let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
        drop(v208_3);
        let v208_5: Space = subtract(&(*CONSTANT_0),&(v208_4));
        drop(v208_4);
        let v208_8: Space = if (v208_5).is_empty() { Space::new() } else {
          let v209_6: Path = concat_path(&(v207_6),&(v207_11_head));
          let v209_7: Space = routine_32(c, &(v209_6), &(v207_11_tail));
          compose(&(v208_5),&(v209_7))
        };
        drop(v208_5);
        let v208_9: Space = intersect(&(*CONSTANT_1),&(v208_2));
        drop(v208_2);
        let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
        drop(v208_9);
        let v208_12: Space = if (v208_10).is_empty() { Space::new() } else {
          let v210_6: Path = concat_path(&(v207_6),&(v207_11_head));
          let v210_11: Space = routine_17(c, &(v210_6), &(v207_11_tail));
          drop(v210_6);
          compose(&(v208_10),&(v210_11))
        };
        drop(v208_10);
        let v208_13: Space = unite(&(v208_8),&(v208_12));
        v207_11.join_into((v208_13).clone());
      }
      drop(v207_11_cursor);
      drop(v207_6);
      compose(&(v202_10),&(v207_11))
    };
    drop(v202_10);
    let v202_13: Space = unite(&(v202_8),&(v202_12));
    v201_11.join_into((v202_13).clone());
  }
  drop(v201_11_cursor);
  (v201_11).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v211_8 = Space::new();
  let mut v211_8_cursor = (*s0).read_zipper();
  for v211_8_byte in v211_8_cursor.child_mask().iter() {
    v211_8_cursor.descend_to_byte(v211_8_byte);
    let v211_8_tail = v211_8_cursor.make_map();
    v211_8_cursor.ascend(1);
    let v211_8_head = Path::from_slice(&[v211_8_byte]);
    let v212_2: Space = singleton(&(v211_8_head));
    let v212_3: Space = intersect(&(*CONSTANT_1),&(v212_2));
    let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
    drop(v212_3);
    let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
    drop(v212_4);
    let v212_8: Space = if (v212_5).is_empty() { Space::new() } else {
      let v213_6: Path = concat_path(&(*p0),&(v211_8_head));
      let mut v213_7 = Space::new();
      let mut v213_7_cursor = (v211_8_tail).read_zipper();
      for v213_7_byte in v213_7_cursor.child_mask().iter() {
        v213_7_cursor.descend_to_byte(v213_7_byte);
        let v213_7_tail = v213_7_cursor.make_map();
        v213_7_cursor.ascend(1);
        let v213_7_head = Path::from_slice(&[v213_7_byte]);
        let v214_2: Space = singleton(&(v213_7_head));
        let v214_3: Space = intersect(&(*CONSTANT_1),&(v214_2));
        let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
        drop(v214_3);
        let v214_5: Space = subtract(&(*CONSTANT_0),&(v214_4));
        drop(v214_4);
        let v214_8: Space = if (v214_5).is_empty() { Space::new() } else {
          let v215_6: Path = concat_path(&(v213_6),&(v213_7_head));
          let v215_7: Space = routine_32(c, &(v215_6), &(v213_7_tail));
          compose(&(v214_5),&(v215_7))
        };
        drop(v214_5);
        let v214_9: Space = intersect(&(*CONSTANT_1),&(v214_2));
        drop(v214_2);
        let v214_10: Space = if has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
        drop(v214_9);
        let v214_12: Space = if (v214_10).is_empty() { Space::new() } else {
          let v216_6: Path = concat_path(&(v213_6),&(v213_7_head));
          let v216_11: Space = routine_33(c, &(v216_6), &(v213_7_tail));
          drop(v216_6);
          compose(&(v214_10),&(v216_11))
        };
        drop(v214_10);
        let v214_13: Space = unite(&(v214_8),&(v214_12));
        v213_7.join_into((v214_13).clone());
      }
      drop(v213_7_cursor);
      drop(v213_6);
      compose(&(v212_5),&(v213_7))
    };
    drop(v212_5);
    let v212_9: Space = intersect(&(*CONSTANT_1),&(v212_2));
    drop(v212_2);
    let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
    drop(v212_9);
    let v212_11: Space = compose(&(v212_10),&(v211_8_tail));
    drop(v212_10);
    let v212_12: Space = unite(&(v212_8),&(v212_11));
    drop(v212_11);
    v211_8.join_into((v212_12).clone());
  }
  drop(v211_8_cursor);
  (v211_8).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v217_6 = Space::new();
  let mut v217_6_cursor = (*s0).read_zipper();
  for v217_6_byte in v217_6_cursor.child_mask().iter() {
    v217_6_cursor.descend_to_byte(v217_6_byte);
    let v217_6_tail = v217_6_cursor.make_map();
    v217_6_cursor.ascend(1);
    let v217_6_head = Path::from_slice(&[v217_6_byte]);
    let v218_2: Space = singleton(&(v217_6_head));
    let v218_3: Space = intersect(&(*CONSTANT_1),&(v218_2));
    let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
    drop(v218_3);
    let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
    drop(v218_4);
    let mut v218_6 = Space::new();
    let mut v218_6_cursor = (v217_6_tail).read_zipper();
    for v218_6_byte in v218_6_cursor.child_mask().iter() {
      v218_6_cursor.descend_to_byte(v218_6_byte);
      let v218_6_tail = v218_6_cursor.make_map();
      v218_6_cursor.ascend(1);
      let v218_6_head = Path::from_slice(&[v218_6_byte]);
      let v219_2: Space = Space::new();
      v218_6.join_into((v219_2).clone());
    }
    drop(v218_6_cursor);
    let v218_7: Space = compose(&(v218_5),&(v218_6));
    drop(v218_5);
    drop(v218_6);
    let v218_8: Space = intersect(&(*CONSTANT_1),&(v218_2));
    drop(v218_2);
    let v218_9: Space = if has_head(&(v218_8)) { singleton(&[]) } else { Space::new() };
    drop(v218_8);
    let v218_12: Space = if (v218_9).is_empty() { Space::new() } else {
      let v220_10: Path = concat_path(&(*p0),&(v217_6_head));
      let mut v220_11 = Space::new();
      let mut v220_11_cursor = (v217_6_tail).read_zipper();
      for v220_11_byte in v220_11_cursor.child_mask().iter() {
        v220_11_cursor.descend_to_byte(v220_11_byte);
        let v220_11_tail = v220_11_cursor.make_map();
        v220_11_cursor.ascend(1);
        let v220_11_head = Path::from_slice(&[v220_11_byte]);
        let v221_2: Space = singleton(&(v220_11_head));
        let v221_3: Space = intersect(&(*CONSTANT_1),&(v221_2));
        drop(v221_2);
        let v221_4: Space = if has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
        drop(v221_3);
        let v221_7: Space = if (v221_4).is_empty() { Space::new() } else {
          let v222_5: Path = concat_path(&(v220_10),&(v220_11_head));
          let v222_6: Space = routine_14(c, &(v222_5), &(v220_11_tail));
          drop(v222_5);
          compose(&(v221_4),&(v222_6))
        };
        drop(v221_4);
        v220_11.join_into((v221_7).clone());
      }
      drop(v220_11_cursor);
      drop(v220_10);
      compose(&(v218_9),&(v220_11))
    };
    drop(v218_9);
    let v218_13: Space = unite(&(v218_7),&(v218_12));
    drop(v218_7);
    v217_6.join_into((v218_13).clone());
  }
  drop(v217_6_cursor);
  (v217_6).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v223_5 = Space::new();
  let mut v223_5_cursor = (*s0).read_zipper();
  for v223_5_byte in v223_5_cursor.child_mask().iter() {
    v223_5_cursor.descend_to_byte(v223_5_byte);
    let v223_5_tail = v223_5_cursor.make_map();
    v223_5_cursor.ascend(1);
    let v223_5_head = Path::from_slice(&[v223_5_byte]);
    let v224_2: Space = singleton(&(v223_5_head));
    let v224_3: Space = intersect(&(*CONSTANT_1),&(v224_2));
    let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
    drop(v224_3);
    let v224_5: Space = subtract(&(*CONSTANT_0),&(v224_4));
    drop(v224_4);
    let mut v224_6 = Space::new();
    let mut v224_6_cursor = (v223_5_tail).read_zipper();
    for v224_6_byte in v224_6_cursor.child_mask().iter() {
      v224_6_cursor.descend_to_byte(v224_6_byte);
      let v224_6_tail = v224_6_cursor.make_map();
      v224_6_cursor.ascend(1);
      let v224_6_head = Path::from_slice(&[v224_6_byte]);
      let v225_2: Space = Space::new();
      v224_6.join_into((v225_2).clone());
    }
    drop(v224_6_cursor);
    let v224_7: Space = compose(&(v224_5),&(v224_6));
    drop(v224_5);
    drop(v224_6);
    let v224_8: Space = intersect(&(*CONSTANT_1),&(v224_2));
    drop(v224_2);
    let v224_9: Space = if has_head(&(v224_8)) { singleton(&[]) } else { Space::new() };
    drop(v224_8);
    let v224_10: Space = compose(&(v224_9),&(v223_5_tail));
    drop(v224_9);
    let v224_11: Space = unite(&(v224_7),&(v224_10));
    drop(v224_7);
    drop(v224_10);
    v223_5.join_into((v224_11).clone());
  }
  drop(v223_5_cursor);
  (v223_5).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v226_6 = Space::new();
  let mut v226_6_cursor = (*s0).read_zipper();
  for v226_6_byte in v226_6_cursor.child_mask().iter() {
    v226_6_cursor.descend_to_byte(v226_6_byte);
    let v226_6_tail = v226_6_cursor.make_map();
    v226_6_cursor.ascend(1);
    let v226_6_head = Path::from_slice(&[v226_6_byte]);
    let v227_2: Space = singleton(&(v226_6_head));
    let v227_3: Space = intersect(&(*CONSTANT_1),&(v227_2));
    let v227_4: Space = if has_head(&(v227_3)) { singleton(&[]) } else { Space::new() };
    drop(v227_3);
    let v227_5: Space = subtract(&(*CONSTANT_0),&(v227_4));
    drop(v227_4);
    let mut v227_6 = Space::new();
    let mut v227_6_cursor = (v226_6_tail).read_zipper();
    for v227_6_byte in v227_6_cursor.child_mask().iter() {
      v227_6_cursor.descend_to_byte(v227_6_byte);
      let v227_6_tail = v227_6_cursor.make_map();
      v227_6_cursor.ascend(1);
      let v227_6_head = Path::from_slice(&[v227_6_byte]);
      let v228_2: Space = Space::new();
      v227_6.join_into((v228_2).clone());
    }
    drop(v227_6_cursor);
    let v227_7: Space = compose(&(v227_5),&(v227_6));
    drop(v227_5);
    drop(v227_6);
    let v227_8: Space = intersect(&(*CONSTANT_1),&(v227_2));
    drop(v227_2);
    let v227_9: Space = if has_head(&(v227_8)) { singleton(&[]) } else { Space::new() };
    drop(v227_8);
    let v227_12: Space = if (v227_9).is_empty() { Space::new() } else {
      let v229_10: Path = concat_path(&(*p0),&(v226_6_head));
      let mut v229_11 = Space::new();
      let mut v229_11_cursor = (v226_6_tail).read_zipper();
      for v229_11_byte in v229_11_cursor.child_mask().iter() {
        v229_11_cursor.descend_to_byte(v229_11_byte);
        let v229_11_tail = v229_11_cursor.make_map();
        v229_11_cursor.ascend(1);
        let v229_11_head = Path::from_slice(&[v229_11_byte]);
        let v230_2: Space = singleton(&(v229_11_head));
        let v230_3: Space = intersect(&(*CONSTANT_1),&(v230_2));
        drop(v230_2);
        let v230_4: Space = if has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
        drop(v230_3);
        let v230_7: Space = if (v230_4).is_empty() { Space::new() } else {
          let v231_5: Path = concat_path(&(v229_10),&(v229_11_head));
          let v231_6: Space = routine_17(c, &(v231_5), &(v229_11_tail));
          drop(v231_5);
          compose(&(v230_4),&(v231_6))
        };
        drop(v230_4);
        v229_11.join_into((v230_7).clone());
      }
      drop(v229_11_cursor);
      drop(v229_10);
      compose(&(v227_9),&(v229_11))
    };
    drop(v227_9);
    let v227_13: Space = unite(&(v227_7),&(v227_12));
    drop(v227_7);
    v226_6.join_into((v227_13).clone());
  }
  drop(v226_6_cursor);
  (v226_6).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v232_5 = Space::new();
  let mut v232_5_cursor = (*s0).read_zipper();
  for v232_5_byte in v232_5_cursor.child_mask().iter() {
    v232_5_cursor.descend_to_byte(v232_5_byte);
    let v232_5_tail = v232_5_cursor.make_map();
    v232_5_cursor.ascend(1);
    let v232_5_head = Path::from_slice(&[v232_5_byte]);
    let v233_2: Space = singleton(&(v232_5_head));
    let v233_3: Space = intersect(&(*CONSTANT_1),&(v233_2));
    let v233_4: Space = if has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
    drop(v233_3);
    let v233_5: Space = subtract(&(*CONSTANT_0),&(v233_4));
    drop(v233_4);
    let mut v233_6 = Space::new();
    let mut v233_6_cursor = (v232_5_tail).read_zipper();
    for v233_6_byte in v233_6_cursor.child_mask().iter() {
      v233_6_cursor.descend_to_byte(v233_6_byte);
      let v233_6_tail = v233_6_cursor.make_map();
      v233_6_cursor.ascend(1);
      let v233_6_head = Path::from_slice(&[v233_6_byte]);
      let v234_2: Space = Space::new();
      v233_6.join_into((v234_2).clone());
    }
    drop(v233_6_cursor);
    let v233_7: Space = compose(&(v233_5),&(v233_6));
    drop(v233_5);
    drop(v233_6);
    let v233_8: Space = intersect(&(*CONSTANT_1),&(v233_2));
    drop(v233_2);
    let v233_9: Space = if has_head(&(v233_8)) { singleton(&[]) } else { Space::new() };
    drop(v233_8);
    let v233_10: Space = compose(&(v233_9),&(v232_5_tail));
    drop(v233_9);
    let v233_11: Space = unite(&(v233_7),&(v233_10));
    drop(v233_7);
    drop(v233_10);
    v232_5.join_into((v233_11).clone());
  }
  drop(v232_5_cursor);
  (v232_5).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v235_2 = Space::new();
  let mut v235_2_cursor = (*s0).read_zipper();
  for v235_2_byte in v235_2_cursor.child_mask().iter() {
    v235_2_cursor.descend_to_byte(v235_2_byte);
    let v235_2_tail = v235_2_cursor.make_map();
    v235_2_cursor.ascend(1);
    let v235_2_head = Path::from_slice(&[v235_2_byte]);
    let v236_2: Space = Space::new();
    v235_2.join_into((v236_2).clone());
  }
  drop(v235_2_cursor);
  (v235_2).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v237_3 = Space::new();
  let mut v237_3_cursor = (*s0).read_zipper();
  for v237_3_byte in v237_3_cursor.child_mask().iter() {
    v237_3_cursor.descend_to_byte(v237_3_byte);
    let v237_3_tail = v237_3_cursor.make_map();
    v237_3_cursor.ascend(1);
    let v237_3_head = Path::from_slice(&[v237_3_byte]);
    let v238_2: Space = singleton(&(v237_3_head));
    let v238_3: Space = intersect(&(*CONSTANT_1),&(v238_2));
    drop(v238_2);
    let v238_4: Space = if has_head(&(v238_3)) { singleton(&[]) } else { Space::new() };
    drop(v238_3);
    let v238_5: Space = compose(&(v238_4),&(v237_3_tail));
    drop(v238_4);
    v237_3.join_into((v238_5).clone());
  }
  drop(v237_3_cursor);
  (v237_3).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v239_2 = Space::new();
  let mut v239_2_cursor = (*s0).read_zipper();
  for v239_2_byte in v239_2_cursor.child_mask().iter() {
    v239_2_cursor.descend_to_byte(v239_2_byte);
    let v239_2_tail = v239_2_cursor.make_map();
    v239_2_cursor.ascend(1);
    let v239_2_head = Path::from_slice(&[v239_2_byte]);
    let v240_2: Space = Space::new();
    v239_2.join_into((v240_2).clone());
  }
  drop(v239_2_cursor);
  (v239_2).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v241_3 = Space::new();
  let mut v241_3_cursor = (*s0).read_zipper();
  for v241_3_byte in v241_3_cursor.child_mask().iter() {
    v241_3_cursor.descend_to_byte(v241_3_byte);
    let v241_3_tail = v241_3_cursor.make_map();
    v241_3_cursor.ascend(1);
    let v241_3_head = Path::from_slice(&[v241_3_byte]);
    let v242_2: Space = singleton(&(v241_3_head));
    let v242_3: Space = intersect(&(*CONSTANT_1),&(v242_2));
    drop(v242_2);
    let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
    drop(v242_3);
    let v242_5: Space = compose(&(v242_4),&(v241_3_tail));
    drop(v242_4);
    v241_3.join_into((v242_5).clone());
  }
  drop(v241_3_cursor);
  (v241_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
