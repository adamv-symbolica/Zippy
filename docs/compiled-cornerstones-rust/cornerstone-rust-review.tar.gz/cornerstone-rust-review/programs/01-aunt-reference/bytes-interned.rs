#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,12]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,10]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,7]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,8]));
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>) -> Space {
  let mut v0_2 = Space::new();
  let mut v0_2_cursor = (*s1.expect("unbound native input")).read_zipper();
  for v0_2_byte in v0_2_cursor.child_mask().iter() {
    v0_2_cursor.descend_to_byte(v0_2_byte);
    let v0_2_tail = v0_2_cursor.make_map();
    v0_2_cursor.ascend(1);
    let v0_2_head = Path::from_slice(&[v0_2_byte]);
    let mut v1_2 = Space::new();
    let mut v1_2_cursor = (v0_2_tail).read_zipper();
    for v1_2_byte in v1_2_cursor.child_mask().iter() {
      v1_2_cursor.descend_to_byte(v1_2_byte);
      let v1_2_tail = v1_2_cursor.make_map();
      v1_2_cursor.ascend(1);
      let v1_2_head = Path::from_slice(&[v1_2_byte]);
      let v2_2: Path = concat_path(&(v0_2_head),&(v1_2_head));
      let mut v2_3 = Space::new();
      let mut v2_3_cursor = (v1_2_tail).read_zipper();
      for v2_3_byte in v2_3_cursor.child_mask().iter() {
        v2_3_cursor.descend_to_byte(v2_3_byte);
        let v2_3_tail = v2_3_cursor.make_map();
        v2_3_cursor.ascend(1);
        let v2_3_head = Path::from_slice(&[v2_3_byte]);
        let v3_2: Path = concat_path(&(v2_2),&(v2_3_head));
        let mut v3_3 = Space::new();
        let mut v3_3_cursor = (v2_3_tail).read_zipper();
        for v3_3_byte in v3_3_cursor.child_mask().iter() {
          v3_3_cursor.descend_to_byte(v3_3_byte);
          let v3_3_tail = v3_3_cursor.make_map();
          v3_3_cursor.ascend(1);
          let v3_3_head = Path::from_slice(&[v3_3_byte]);
          let v4_2: Path = concat_path(&(v3_2),&(v3_3_head));
          let v4_3: Space = routine_1(c, &(v4_2), &(v3_3_tail), &(*s0.expect("unbound native input")));
          drop(v4_2);
          v3_3.join_into((v4_3).clone());
        }
        drop(v3_3_cursor);
        drop(v3_2);
        v2_3.join_into((v3_3).clone());
      }
      drop(v2_3_cursor);
      drop(v2_2);
      v1_2.join_into((v2_3).clone());
    }
    drop(v1_2_cursor);
    v0_2.join_into((v1_2).clone());
  }
  drop(v0_2_cursor);
  let v0_4: Space = wrap(&(v0_2),&(*CONSTANT_0));
  (v0_4).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v5_4: Space = unwrap(&(*s1),&(*CONSTANT_1));
  let v5_6: Space = unwrap(&(*s1),&(*CONSTANT_2));
  let v5_7: Space = unwrap(&(v5_6),&(*p0));
  let v5_8: Space = restrict_to(&(v5_6),&(v5_7));
  drop(v5_6);
  let mut v5_9 = Space::new();
  let mut v5_9_cursor = (v5_8).read_zipper();
  for v5_9_byte in v5_9_cursor.child_mask().iter() {
    v5_9_cursor.descend_to_byte(v5_9_byte);
    let v5_9_tail = v5_9_cursor.make_map();
    v5_9_cursor.ascend(1);
    let v5_9_head = Path::from_slice(&[v5_9_byte]);
    let mut v6_2 = Space::new();
    let mut v6_2_cursor = (v5_9_tail).read_zipper();
    for v6_2_byte in v6_2_cursor.child_mask().iter() {
      v6_2_cursor.descend_to_byte(v6_2_byte);
      let v6_2_tail = v6_2_cursor.make_map();
      v6_2_cursor.ascend(1);
      let v6_2_head = Path::from_slice(&[v6_2_byte]);
      let mut v7_2 = Space::new();
      let mut v7_2_cursor = (v6_2_tail).read_zipper();
      for v7_2_byte in v7_2_cursor.child_mask().iter() {
        v7_2_cursor.descend_to_byte(v7_2_byte);
        let v7_2_tail = v7_2_cursor.make_map();
        v7_2_cursor.ascend(1);
        let v7_2_head = Path::from_slice(&[v7_2_byte]);
        let v8_2: Space = tails_union(&(v7_2_tail));
        v7_2.join_into((v8_2).clone());
      }
      drop(v7_2_cursor);
      v6_2.join_into((v7_2).clone());
    }
    drop(v6_2_cursor);
    v5_9.join_into((v6_2).clone());
  }
  drop(v5_9_cursor);
  drop(v5_8);
  let v5_10: Space = restrict_to(&(v5_4),&(v5_9));
  drop(v5_4);
  drop(v5_9);
  let mut v5_11 = Space::new();
  let mut v5_11_cursor = (v5_10).read_zipper();
  for v5_11_byte in v5_11_cursor.child_mask().iter() {
    v5_11_cursor.descend_to_byte(v5_11_byte);
    let v5_11_tail = v5_11_cursor.make_map();
    v5_11_cursor.ascend(1);
    let v5_11_head = Path::from_slice(&[v5_11_byte]);
    let mut v9_2 = Space::new();
    let mut v9_2_cursor = (v5_11_tail).read_zipper();
    for v9_2_byte in v9_2_cursor.child_mask().iter() {
      v9_2_cursor.descend_to_byte(v9_2_byte);
      let v9_2_tail = v9_2_cursor.make_map();
      v9_2_cursor.ascend(1);
      let v9_2_head = Path::from_slice(&[v9_2_byte]);
      let mut v10_2 = Space::new();
      let mut v10_2_cursor = (v9_2_tail).read_zipper();
      for v10_2_byte in v10_2_cursor.child_mask().iter() {
        v10_2_cursor.descend_to_byte(v10_2_byte);
        let v10_2_tail = v10_2_cursor.make_map();
        v10_2_cursor.ascend(1);
        let v10_2_head = Path::from_slice(&[v10_2_byte]);
        let v11_2: Space = tails_union(&(v10_2_tail));
        v10_2.join_into((v11_2).clone());
      }
      drop(v10_2_cursor);
      v9_2.join_into((v10_2).clone());
    }
    drop(v9_2_cursor);
    v5_11.join_into((v9_2).clone());
  }
  drop(v5_11_cursor);
  drop(v5_10);
  let v5_12: Space = subtract(&(v5_11),&(v5_7));
  drop(v5_7);
  drop(v5_11);
  let v5_14: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v5_15: Space = intersect(&(v5_12),&(v5_14));
  drop(v5_12);
  drop(v5_14);
  let v5_16: Space = wrap(&(v5_15),&(*p0));
  drop(v5_15);
  (v5_16).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
