#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("13 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 8 0 0 0 4 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 3 0 0 0 6 0 0 0 4 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 3 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 2 0 0 0 7 0 0 0 4 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 3 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 3 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 5 0 0 0 3 0 0 0 2 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 5 0 0 0 3 0 0 0 2 0 0 0 8 0 0 0 6 0 0 0 4 0 0 0 7"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,9]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("11 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 2 0 0 0 3 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 2 0 0 0 7 0 0 0 4 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 3 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 3 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 5 0 0 0 3 0 0 0 2 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 5 0 0 0 3 0 0 0 2 0 0 0 8 0 0 0 6 0 0 0 4 0 0 0 7"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,10]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("17 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 2 0 0 0 3 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 0 0 0 4 28 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 4 0 0 0 7 28 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 2 0 0 0 7 0 0 0 4 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 3 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 3 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 3 0 0 0 8 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 4 0 0 0 6 0 0 0 3 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 6 0 0 0 5 0 0 0 2 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 4 0 0 0 7 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 3 0 0 0 2 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 5 0 0 0 3 0 0 0 2 0 0 0 8 0 0 0 6 0 0 0 4 0 0 0 7"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,11]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("11 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 4 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 8 0 0 0 3 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 5 0 0 0 8 0 0 0 3 0 0 0 6 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,12]));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("17 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 4 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 4 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 8 0 0 0 3 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 4 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 5 0 0 0 8 0 0 0 3 0 0 0 6 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 6 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 7 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 7 0 0 0 4 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 5"));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,13]));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("10 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 4 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 4 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,14]));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("13 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 7 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 3 0 0 0 8 0 0 0 4 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 7 0 0 0 6 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 5 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 6 0 0 0 5 0 0 0 3 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 3 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 3 0 0 0 2 0 0 0 7 0 0 0 8"));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,15]));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("9 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 7 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 7 0 0 0 6 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 5 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 6 0 0 0 5 0 0 0 3 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 3 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8"));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,16]));
static CONSTANT_18: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("13 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 7 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 3 0 0 0 8 0 0 0 7 0 0 0 6 0 0 0 4 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 7 0 0 0 6 0 0 0 5 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 5 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 8 0 0 0 7 0 0 0 3 28 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 8 0 0 0 3 0 0 0 6 28 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 6 0 0 0 5 0 0 0 3 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 3 0 0 0 2 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 5 0 0 0 4 0 0 0 3 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8"));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 28 0 0 0 5 0 0 0 1 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 5 0 0 0 1 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 4 0 0 0 7 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 8 0 0 0 3 0 0 0 6 0 0 0 7 28 0 0 0 5 0 0 0 1 0 0 0 7 0 0 0 4 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 28 0 0 0 5 0 0 0 1 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 28 0 0 0 3 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,3]));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("11 28 0 0 0 1 0 0 0 4 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 4 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 6 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 6 0 0 0 5 0 0 0 2 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 4 0 0 0 1 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 4 0 0 0 1 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 4 0 0 0 1 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 2 0 0 0 6 0 0 0 1 0 0 0 4 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 6 0 0 0 1 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 7 0 0 0 1 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 2 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("13 28 0 0 0 1 0 0 0 4 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 4 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 4 0 0 0 8 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 1 0 0 0 6 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 6 0 0 0 5 0 0 0 2 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 1 0 0 0 7 0 0 0 5 0 0 0 2 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 4 0 0 0 1 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 4 0 0 0 1 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 4 0 0 0 1 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 2 0 0 0 6 0 0 0 1 0 0 0 4 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 6 0 0 0 1 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 7 0 0 0 1 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 4 0 0 0 2 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_26: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("11 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 5 0 0 0 8 0 0 0 4 0 0 0 6 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 1 0 0 0 4 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 5 0 0 0 2 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_27: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("17 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 5 0 0 0 8 0 0 0 4 0 0 0 6 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 7 0 0 0 5 0 0 0 4 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 1 0 0 0 4 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 5 0 0 0 2 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 1 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 1 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 4 0 0 0 1 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 5 0 0 0 1 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 7 0 0 0 1 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 5"));
static CONSTANT_28: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("9 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 4 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 1 0 0 0 7 0 0 0 4 0 0 0 8 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_29: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("17 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 5 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 8 0 0 0 7 0 0 0 6 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 7 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 8 0 0 0 5 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 8 0 0 0 7 0 0 0 4 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 4 0 0 0 7 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 6 0 0 0 4 0 0 0 8 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 6 0 0 0 5 0 0 0 4 0 0 0 8 28 0 0 0 1 0 0 0 4 0 0 0 6 0 0 0 5 0 0 0 2 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 5 0 0 0 6 0 0 0 2 0 0 0 4 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 1 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 7 0 0 0 1 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 4 0 0 0 1 0 0 0 7 0 0 0 8 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 1 0 0 0 6 0 0 0 4 0 0 0 2 0 0 0 7 0 0 0 8"));
static CONSTANT_30: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("10 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 5 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 8 0 0 0 7 0 0 0 6 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 8 0 0 0 7 0 0 0 4 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 4 0 0 0 7 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 6 0 0 0 5 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 1 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 7 0 0 0 1 0 0 0 6 0 0 0 8 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8"));
static CONSTANT_31: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("13 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 5 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 4 0 0 0 8 0 0 0 7 0 0 0 6 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 8 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 8 0 0 0 7 0 0 0 4 28 0 0 0 1 0 0 0 2 0 0 0 6 0 0 0 8 0 0 0 4 0 0 0 7 0 0 0 5 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 5 0 0 0 8 0 0 0 4 0 0 0 6 28 0 0 0 1 0 0 0 2 0 0 0 7 0 0 0 6 0 0 0 5 0 0 0 4 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 1 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 5 0 0 0 4 0 0 0 7 0 0 0 1 0 0 0 6 0 0 0 8 28 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 1 0 0 0 8 0 0 0 7 0 0 0 4 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 2 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 5 0 0 0 1 0 0 0 4 0 0 0 7 0 0 0 2 0 0 0 6 0 0 0 8"));
static CONSTANT_32: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_33: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 28 0 0 0 2 0 0 0 1 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 1 0 0 0 3 0 0 0 7 0 0 0 6 0 0 0 8 0 0 0 5 28 0 0 0 2 0 0 0 1 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 5 0 0 0 7 28 0 0 0 2 0 0 0 1 0 0 0 5 0 0 0 8 0 0 0 3 0 0 0 6 0 0 0 7 28 0 0 0 2 0 0 0 1 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 28 0 0 0 2 0 0 0 1 0 0 0 7 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8"));
static CONSTANT_34: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 28 0 0 0 2 0 0 0 1 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 1 0 0 0 7 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8"));
static CONSTANT_35: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 28 0 0 0 2 0 0 0 1 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 2 0 0 0 1 0 0 0 7 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8 28 0 0 0 3 0 0 0 1 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_36: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 28 0 0 0 3 0 0 0 1 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_37: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 28 0 0 0 2 0 0 0 5 0 0 0 1 0 0 0 3 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 3 0 0 0 1 0 0 0 5 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 5 0 0 0 7 0 0 0 1 0 0 0 8 28 0 0 0 7 0 0 0 2 0 0 0 1 0 0 0 5 0 0 0 3 0 0 0 6 0 0 0 8"));
static CONSTANT_38: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 28 0 0 0 2 0 0 0 5 0 0 0 1 0 0 0 3 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_39: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 28 0 0 0 3 0 0 0 1 0 0 0 6 0 0 0 5 0 0 0 2 0 0 0 7 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 1 0 0 0 5 0 0 0 7 0 0 0 8"));
static CONSTANT_40: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 1 0 0 0 5 0 0 0 7 0 0 0 8"));
static CONSTANT_41: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 28 0 0 0 2 0 0 0 5 0 0 0 1 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 5 0 0 0 8 0 0 0 6 0 0 0 7 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 7 0 0 0 5 0 0 0 6 0 0 0 8 28 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 1 0 0 0 5 0 0 0 7 0 0 0 8"));
static CONSTANT_42: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_43: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 28 0 0 0 1 0 0 0 3 0 0 0 4 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8 28 0 0 0 4 0 0 0 1 0 0 0 3 0 0 0 2 0 0 0 6 0 0 0 7 0 0 0 8"));
static CONSTANT_44: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,6]));
static CONSTANT_45: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 28 0 0 0 3 0 0 0 2 0 0 0 1 0 0 0 5 0 0 0 7 0 0 0 4 0 0 0 8"));
static CONSTANT_46: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 28 0 0 0 3 0 0 0 2 0 0 0 7 0 0 0 1 0 0 0 5 0 0 0 4 0 0 0 8"));
static CONSTANT_47: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 0"));
static CONSTANT_48: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 9"));
static CONSTANT_49: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 10"));
static CONSTANT_50: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 11"));
static CONSTANT_51: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 12"));
static CONSTANT_52: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 13"));
static CONSTANT_53: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 14"));
static CONSTANT_54: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 15"));
static CONSTANT_55: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 16"));
static CONSTANT_56: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,17]));
static CONSTANT_57: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 0 0 0 0 11 8 0 0 0 11 0 0 0 0"));
static CONSTANT_58: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 9 0 0 0 12 8 0 0 0 12 0 0 0 9"));
static CONSTANT_59: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 10 0 0 0 13 8 0 0 0 13 0 0 0 10"));
static CONSTANT_60: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 11 0 0 0 14 8 0 0 0 14 0 0 0 11"));
static CONSTANT_61: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 12 0 0 0 15 8 0 0 0 15 0 0 0 12"));
static CONSTANT_62: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 13 0 0 0 16 8 0 0 0 16 0 0 0 13"));
static CONSTANT_63: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,18]));
static CONSTANT_64: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 0 0 0 0 9 8 0 0 0 9 0 0 0 0"));
static CONSTANT_65: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 9 0 0 0 10 8 0 0 0 10 0 0 0 9"));
static CONSTANT_66: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 11 0 0 0 12 8 0 0 0 12 0 0 0 11"));
static CONSTANT_67: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 12 0 0 0 13 8 0 0 0 13 0 0 0 12"));
static CONSTANT_68: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 14 0 0 0 15 8 0 0 0 15 0 0 0 14"));
static CONSTANT_69: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 0 0 15 0 0 0 16 8 0 0 0 16 0 0 0 15"));
static CONSTANT_70: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,19]));
static CONSTANT_71: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,20]));
static CONSTANT_72: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("9 8 0 0 0 0 0 0 0 0 8 0 0 0 9 0 0 0 9 8 0 0 0 10 0 0 0 10 8 0 0 0 11 0 0 0 11 8 0 0 0 12 0 0 0 12 8 0 0 0 13 0 0 0 13 8 0 0 0 14 0 0 0 14 8 0 0 0 15 0 0 0 15 8 0 0 0 16 0 0 0 16"));
static CONSTANT_73: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 0 0 0 0 21"));
static CONSTANT_74: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 9 0 0 0 21"));
static CONSTANT_75: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 10 0 0 0 21"));
static CONSTANT_76: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 11 0 0 0 21"));
static CONSTANT_77: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 12 0 0 0 21"));
static CONSTANT_78: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 13 0 0 0 21"));
static CONSTANT_79: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 14 0 0 0 21"));
static CONSTANT_80: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 15 0 0 0 21"));
static CONSTANT_81: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 16 0 0 0 21"));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &Path,capture_1: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v41_3: Space = singleton(&(*capture_0));
  let v41_4: Space = intersect(&(*CONSTANT_47),&(v41_3));
  let mut v41_5 = Space::new();
  let mut v41_5_cursor = (v41_4).read_zipper();
  for v41_5_byte in v41_5_cursor.child_mask().iter() {
    v41_5_cursor.descend_to_byte(v41_5_byte);
    let v41_5_tail = v41_5_cursor.make_map();
    v41_5_cursor.ascend(1);
    let v41_5_head = Path::from_slice(&[v41_5_byte]);
    let mut v42_2 = Space::new();
    let mut v42_2_cursor = (v41_5_tail).read_zipper();
    for v42_2_byte in v42_2_cursor.child_mask().iter() {
      v42_2_cursor.descend_to_byte(v42_2_byte);
      let v42_2_tail = v42_2_cursor.make_map();
      v42_2_cursor.ascend(1);
      let v42_2_head = Path::from_slice(&[v42_2_byte]);
      let mut v43_2 = Space::new();
      let mut v43_2_cursor = (v42_2_tail).read_zipper();
      for v43_2_byte in v43_2_cursor.child_mask().iter() {
        v43_2_cursor.descend_to_byte(v43_2_byte);
        let v43_2_tail = v43_2_cursor.make_map();
        v43_2_cursor.ascend(1);
        let v43_2_head = Path::from_slice(&[v43_2_byte]);
        let v44_2: Space = tails_union(&(v43_2_tail));
        v43_2.join_into((v44_2).clone());
      }
      drop(v43_2_cursor);
      v42_2.join_into((v43_2).clone());
    }
    drop(v42_2_cursor);
    v41_5.join_into((v42_2).clone());
  }
  drop(v41_5_cursor);
  drop(v41_4);
  let v41_7: Space = if (v41_5).is_empty() { Space::new() } else {
    let mut v45_6 = Space::new();
    let mut v45_6_cursor = (*capture_1).read_zipper();
    for v45_6_byte in v45_6_cursor.child_mask().iter() {
      v45_6_cursor.descend_to_byte(v45_6_byte);
      let v45_6_tail = v45_6_cursor.make_map();
      v45_6_cursor.ascend(1);
      let v45_6_head = Path::from_slice(&[v45_6_byte]);
      let mut v46_2 = Space::new();
      let mut v46_2_cursor = (v45_6_tail).read_zipper();
      for v46_2_byte in v46_2_cursor.child_mask().iter() {
        v46_2_cursor.descend_to_byte(v46_2_byte);
        let v46_2_tail = v46_2_cursor.make_map();
        v46_2_cursor.ascend(1);
        let v46_2_head = Path::from_slice(&[v46_2_byte]);
        let v47_2: Path = concat_path(&(v45_6_head),&(v46_2_head));
        let mut v47_3 = Space::new();
        let mut v47_3_cursor = (v46_2_tail).read_zipper();
        for v47_3_byte in v47_3_cursor.child_mask().iter() {
          v47_3_cursor.descend_to_byte(v47_3_byte);
          let v47_3_tail = v47_3_cursor.make_map();
          v47_3_cursor.ascend(1);
          let v47_3_head = Path::from_slice(&[v47_3_byte]);
          let v48_2: Path = concat_path(&(v47_2),&(v47_3_head));
          let mut v48_3 = Space::new();
          let mut v48_3_cursor = (v47_3_tail).read_zipper();
          for v48_3_byte in v48_3_cursor.child_mask().iter() {
            v48_3_cursor.descend_to_byte(v48_3_byte);
            let v48_3_tail = v48_3_cursor.make_map();
            v48_3_cursor.ascend(1);
            let v48_3_head = Path::from_slice(&[v48_3_byte]);
            let v49_2: Path = concat_path(&(v48_2),&(v48_3_head));
            let mut v49_3 = Space::new();
            let mut v49_3_cursor = (v48_3_tail).read_zipper();
            for v49_3_byte in v49_3_cursor.child_mask().iter() {
              v49_3_cursor.descend_to_byte(v49_3_byte);
              let v49_3_tail = v49_3_cursor.make_map();
              v49_3_cursor.ascend(1);
              let v49_3_head = Path::from_slice(&[v49_3_byte]);
              let mut v50_2 = Space::new();
              let mut v50_2_cursor = (v49_3_tail).read_zipper();
              for v50_2_byte in v50_2_cursor.child_mask().iter() {
                v50_2_cursor.descend_to_byte(v50_2_byte);
                let v50_2_tail = v50_2_cursor.make_map();
                v50_2_cursor.ascend(1);
                let v50_2_head = Path::from_slice(&[v50_2_byte]);
                let v51_2: Path = concat_path(&(v49_3_head),&(v50_2_head));
                let mut v51_3 = Space::new();
                let mut v51_3_cursor = (v50_2_tail).read_zipper();
                for v51_3_byte in v51_3_cursor.child_mask().iter() {
                  v51_3_cursor.descend_to_byte(v51_3_byte);
                  let v51_3_tail = v51_3_cursor.make_map();
                  v51_3_cursor.ascend(1);
                  let v51_3_head = Path::from_slice(&[v51_3_byte]);
                  let v52_2: Path = concat_path(&(v51_2),&(v51_3_head));
                  let mut v52_3 = Space::new();
                  let mut v52_3_cursor = (v51_3_tail).read_zipper();
                  for v52_3_byte in v52_3_cursor.child_mask().iter() {
                    v52_3_cursor.descend_to_byte(v52_3_byte);
                    let v52_3_tail = v52_3_cursor.make_map();
                    v52_3_cursor.ascend(1);
                    let v52_3_head = Path::from_slice(&[v52_3_byte]);
                    let v53_2: Path = concat_path(&(v52_2),&(v52_3_head));
                    let v53_3: Space = routine_8(c, &(v53_2), &(v49_2), &(v52_3_tail));
                    drop(v53_2);
                    v52_3.join_into((v53_3).clone());
                  }
                  drop(v52_3_cursor);
                  drop(v52_2);
                  v51_3.join_into((v52_3).clone());
                }
                drop(v51_3_cursor);
                drop(v51_2);
                v50_2.join_into((v51_3).clone());
              }
              drop(v50_2_cursor);
              v49_3.join_into((v50_2).clone());
            }
            drop(v49_3_cursor);
            drop(v49_2);
            v48_3.join_into((v49_3).clone());
          }
          drop(v48_3_cursor);
          drop(v48_2);
          v47_3.join_into((v48_3).clone());
        }
        drop(v47_3_cursor);
        drop(v47_2);
        v46_2.join_into((v47_3).clone());
      }
      drop(v46_2_cursor);
      v45_6.join_into((v46_2).clone());
    }
    drop(v45_6_cursor);
    compose(&(v41_5),&(v45_6))
  };
  drop(v41_5);
  let v41_9: Space = intersect(&(*CONSTANT_48),&(v41_3));
  let mut v41_10 = Space::new();
  let mut v41_10_cursor = (v41_9).read_zipper();
  for v41_10_byte in v41_10_cursor.child_mask().iter() {
    v41_10_cursor.descend_to_byte(v41_10_byte);
    let v41_10_tail = v41_10_cursor.make_map();
    v41_10_cursor.ascend(1);
    let v41_10_head = Path::from_slice(&[v41_10_byte]);
    let mut v54_2 = Space::new();
    let mut v54_2_cursor = (v41_10_tail).read_zipper();
    for v54_2_byte in v54_2_cursor.child_mask().iter() {
      v54_2_cursor.descend_to_byte(v54_2_byte);
      let v54_2_tail = v54_2_cursor.make_map();
      v54_2_cursor.ascend(1);
      let v54_2_head = Path::from_slice(&[v54_2_byte]);
      let mut v55_2 = Space::new();
      let mut v55_2_cursor = (v54_2_tail).read_zipper();
      for v55_2_byte in v55_2_cursor.child_mask().iter() {
        v55_2_cursor.descend_to_byte(v55_2_byte);
        let v55_2_tail = v55_2_cursor.make_map();
        v55_2_cursor.ascend(1);
        let v55_2_head = Path::from_slice(&[v55_2_byte]);
        let v56_2: Space = tails_union(&(v55_2_tail));
        v55_2.join_into((v56_2).clone());
      }
      drop(v55_2_cursor);
      v54_2.join_into((v55_2).clone());
    }
    drop(v54_2_cursor);
    v41_10.join_into((v54_2).clone());
  }
  drop(v41_10_cursor);
  drop(v41_9);
  let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
    let mut v57_11 = Space::new();
    let mut v57_11_cursor = (*capture_1).read_zipper();
    for v57_11_byte in v57_11_cursor.child_mask().iter() {
      v57_11_cursor.descend_to_byte(v57_11_byte);
      let v57_11_tail = v57_11_cursor.make_map();
      v57_11_cursor.ascend(1);
      let v57_11_head = Path::from_slice(&[v57_11_byte]);
      let mut v58_2 = Space::new();
      let mut v58_2_cursor = (v57_11_tail).read_zipper();
      for v58_2_byte in v58_2_cursor.child_mask().iter() {
        v58_2_cursor.descend_to_byte(v58_2_byte);
        let v58_2_tail = v58_2_cursor.make_map();
        v58_2_cursor.ascend(1);
        let v58_2_head = Path::from_slice(&[v58_2_byte]);
        let v59_2: Path = concat_path(&(v57_11_head),&(v58_2_head));
        let mut v59_3 = Space::new();
        let mut v59_3_cursor = (v58_2_tail).read_zipper();
        for v59_3_byte in v59_3_cursor.child_mask().iter() {
          v59_3_cursor.descend_to_byte(v59_3_byte);
          let v59_3_tail = v59_3_cursor.make_map();
          v59_3_cursor.ascend(1);
          let v59_3_head = Path::from_slice(&[v59_3_byte]);
          let v60_2: Path = concat_path(&(v59_2),&(v59_3_head));
          let mut v60_3 = Space::new();
          let mut v60_3_cursor = (v59_3_tail).read_zipper();
          for v60_3_byte in v60_3_cursor.child_mask().iter() {
            v60_3_cursor.descend_to_byte(v60_3_byte);
            let v60_3_tail = v60_3_cursor.make_map();
            v60_3_cursor.ascend(1);
            let v60_3_head = Path::from_slice(&[v60_3_byte]);
            let v61_2: Path = concat_path(&(v60_2),&(v60_3_head));
            let mut v61_3 = Space::new();
            let mut v61_3_cursor = (v60_3_tail).read_zipper();
            for v61_3_byte in v61_3_cursor.child_mask().iter() {
              v61_3_cursor.descend_to_byte(v61_3_byte);
              let v61_3_tail = v61_3_cursor.make_map();
              v61_3_cursor.ascend(1);
              let v61_3_head = Path::from_slice(&[v61_3_byte]);
              let mut v62_2 = Space::new();
              let mut v62_2_cursor = (v61_3_tail).read_zipper();
              for v62_2_byte in v62_2_cursor.child_mask().iter() {
                v62_2_cursor.descend_to_byte(v62_2_byte);
                let v62_2_tail = v62_2_cursor.make_map();
                v62_2_cursor.ascend(1);
                let v62_2_head = Path::from_slice(&[v62_2_byte]);
                let v63_2: Path = concat_path(&(v61_3_head),&(v62_2_head));
                let mut v63_3 = Space::new();
                let mut v63_3_cursor = (v62_2_tail).read_zipper();
                for v63_3_byte in v63_3_cursor.child_mask().iter() {
                  v63_3_cursor.descend_to_byte(v63_3_byte);
                  let v63_3_tail = v63_3_cursor.make_map();
                  v63_3_cursor.ascend(1);
                  let v63_3_head = Path::from_slice(&[v63_3_byte]);
                  let v64_2: Path = concat_path(&(v63_2),&(v63_3_head));
                  let mut v64_3 = Space::new();
                  let mut v64_3_cursor = (v63_3_tail).read_zipper();
                  for v64_3_byte in v64_3_cursor.child_mask().iter() {
                    v64_3_cursor.descend_to_byte(v64_3_byte);
                    let v64_3_tail = v64_3_cursor.make_map();
                    v64_3_cursor.ascend(1);
                    let v64_3_head = Path::from_slice(&[v64_3_byte]);
                    let v65_2: Path = concat_path(&(v64_2),&(v64_3_head));
                    let v65_3: Space = routine_9(c, &(v65_2), &(v61_2), &(v64_3_tail));
                    drop(v65_2);
                    v64_3.join_into((v65_3).clone());
                  }
                  drop(v64_3_cursor);
                  drop(v64_2);
                  v63_3.join_into((v64_3).clone());
                }
                drop(v63_3_cursor);
                drop(v63_2);
                v62_2.join_into((v63_3).clone());
              }
              drop(v62_2_cursor);
              v61_3.join_into((v62_2).clone());
            }
            drop(v61_3_cursor);
            drop(v61_2);
            v60_3.join_into((v61_3).clone());
          }
          drop(v60_3_cursor);
          drop(v60_2);
          v59_3.join_into((v60_3).clone());
        }
        drop(v59_3_cursor);
        drop(v59_2);
        v58_2.join_into((v59_3).clone());
      }
      drop(v58_2_cursor);
      v57_11.join_into((v58_2).clone());
    }
    drop(v57_11_cursor);
    compose(&(v41_10),&(v57_11))
  };
  drop(v41_10);
  let v41_13: Space = unite(&(v41_7),&(v41_12));
  let v41_15: Space = intersect(&(*CONSTANT_49),&(v41_3));
  let mut v41_16 = Space::new();
  let mut v41_16_cursor = (v41_15).read_zipper();
  for v41_16_byte in v41_16_cursor.child_mask().iter() {
    v41_16_cursor.descend_to_byte(v41_16_byte);
    let v41_16_tail = v41_16_cursor.make_map();
    v41_16_cursor.ascend(1);
    let v41_16_head = Path::from_slice(&[v41_16_byte]);
    let mut v66_2 = Space::new();
    let mut v66_2_cursor = (v41_16_tail).read_zipper();
    for v66_2_byte in v66_2_cursor.child_mask().iter() {
      v66_2_cursor.descend_to_byte(v66_2_byte);
      let v66_2_tail = v66_2_cursor.make_map();
      v66_2_cursor.ascend(1);
      let v66_2_head = Path::from_slice(&[v66_2_byte]);
      let mut v67_2 = Space::new();
      let mut v67_2_cursor = (v66_2_tail).read_zipper();
      for v67_2_byte in v67_2_cursor.child_mask().iter() {
        v67_2_cursor.descend_to_byte(v67_2_byte);
        let v67_2_tail = v67_2_cursor.make_map();
        v67_2_cursor.ascend(1);
        let v67_2_head = Path::from_slice(&[v67_2_byte]);
        let v68_2: Space = tails_union(&(v67_2_tail));
        v67_2.join_into((v68_2).clone());
      }
      drop(v67_2_cursor);
      v66_2.join_into((v67_2).clone());
    }
    drop(v66_2_cursor);
    v41_16.join_into((v66_2).clone());
  }
  drop(v41_16_cursor);
  drop(v41_15);
  let v41_18: Space = if (v41_16).is_empty() { Space::new() } else {
    let mut v69_17 = Space::new();
    let mut v69_17_cursor = (*capture_1).read_zipper();
    for v69_17_byte in v69_17_cursor.child_mask().iter() {
      v69_17_cursor.descend_to_byte(v69_17_byte);
      let v69_17_tail = v69_17_cursor.make_map();
      v69_17_cursor.ascend(1);
      let v69_17_head = Path::from_slice(&[v69_17_byte]);
      let mut v70_2 = Space::new();
      let mut v70_2_cursor = (v69_17_tail).read_zipper();
      for v70_2_byte in v70_2_cursor.child_mask().iter() {
        v70_2_cursor.descend_to_byte(v70_2_byte);
        let v70_2_tail = v70_2_cursor.make_map();
        v70_2_cursor.ascend(1);
        let v70_2_head = Path::from_slice(&[v70_2_byte]);
        let v71_2: Path = concat_path(&(v69_17_head),&(v70_2_head));
        let mut v71_3 = Space::new();
        let mut v71_3_cursor = (v70_2_tail).read_zipper();
        for v71_3_byte in v71_3_cursor.child_mask().iter() {
          v71_3_cursor.descend_to_byte(v71_3_byte);
          let v71_3_tail = v71_3_cursor.make_map();
          v71_3_cursor.ascend(1);
          let v71_3_head = Path::from_slice(&[v71_3_byte]);
          let v72_2: Path = concat_path(&(v71_2),&(v71_3_head));
          let mut v72_3 = Space::new();
          let mut v72_3_cursor = (v71_3_tail).read_zipper();
          for v72_3_byte in v72_3_cursor.child_mask().iter() {
            v72_3_cursor.descend_to_byte(v72_3_byte);
            let v72_3_tail = v72_3_cursor.make_map();
            v72_3_cursor.ascend(1);
            let v72_3_head = Path::from_slice(&[v72_3_byte]);
            let v73_2: Path = concat_path(&(v72_2),&(v72_3_head));
            let mut v73_3 = Space::new();
            let mut v73_3_cursor = (v72_3_tail).read_zipper();
            for v73_3_byte in v73_3_cursor.child_mask().iter() {
              v73_3_cursor.descend_to_byte(v73_3_byte);
              let v73_3_tail = v73_3_cursor.make_map();
              v73_3_cursor.ascend(1);
              let v73_3_head = Path::from_slice(&[v73_3_byte]);
              let mut v74_2 = Space::new();
              let mut v74_2_cursor = (v73_3_tail).read_zipper();
              for v74_2_byte in v74_2_cursor.child_mask().iter() {
                v74_2_cursor.descend_to_byte(v74_2_byte);
                let v74_2_tail = v74_2_cursor.make_map();
                v74_2_cursor.ascend(1);
                let v74_2_head = Path::from_slice(&[v74_2_byte]);
                let v75_2: Path = concat_path(&(v73_3_head),&(v74_2_head));
                let mut v75_3 = Space::new();
                let mut v75_3_cursor = (v74_2_tail).read_zipper();
                for v75_3_byte in v75_3_cursor.child_mask().iter() {
                  v75_3_cursor.descend_to_byte(v75_3_byte);
                  let v75_3_tail = v75_3_cursor.make_map();
                  v75_3_cursor.ascend(1);
                  let v75_3_head = Path::from_slice(&[v75_3_byte]);
                  let v76_2: Path = concat_path(&(v75_2),&(v75_3_head));
                  let mut v76_3 = Space::new();
                  let mut v76_3_cursor = (v75_3_tail).read_zipper();
                  for v76_3_byte in v76_3_cursor.child_mask().iter() {
                    v76_3_cursor.descend_to_byte(v76_3_byte);
                    let v76_3_tail = v76_3_cursor.make_map();
                    v76_3_cursor.ascend(1);
                    let v76_3_head = Path::from_slice(&[v76_3_byte]);
                    let v77_2: Path = concat_path(&(v76_2),&(v76_3_head));
                    let v77_3: Space = routine_10(c, &(v77_2), &(v73_2), &(v76_3_tail));
                    drop(v77_2);
                    v76_3.join_into((v77_3).clone());
                  }
                  drop(v76_3_cursor);
                  drop(v76_2);
                  v75_3.join_into((v76_3).clone());
                }
                drop(v75_3_cursor);
                drop(v75_2);
                v74_2.join_into((v75_3).clone());
              }
              drop(v74_2_cursor);
              v73_3.join_into((v74_2).clone());
            }
            drop(v73_3_cursor);
            drop(v73_2);
            v72_3.join_into((v73_3).clone());
          }
          drop(v72_3_cursor);
          drop(v72_2);
          v71_3.join_into((v72_3).clone());
        }
        drop(v71_3_cursor);
        drop(v71_2);
        v70_2.join_into((v71_3).clone());
      }
      drop(v70_2_cursor);
      v69_17.join_into((v70_2).clone());
    }
    drop(v69_17_cursor);
    compose(&(v41_16),&(v69_17))
  };
  drop(v41_16);
  let v41_19: Space = unite(&(v41_13),&(v41_18));
  let v41_21: Space = intersect(&(*CONSTANT_50),&(v41_3));
  let mut v41_22 = Space::new();
  let mut v41_22_cursor = (v41_21).read_zipper();
  for v41_22_byte in v41_22_cursor.child_mask().iter() {
    v41_22_cursor.descend_to_byte(v41_22_byte);
    let v41_22_tail = v41_22_cursor.make_map();
    v41_22_cursor.ascend(1);
    let v41_22_head = Path::from_slice(&[v41_22_byte]);
    let mut v78_2 = Space::new();
    let mut v78_2_cursor = (v41_22_tail).read_zipper();
    for v78_2_byte in v78_2_cursor.child_mask().iter() {
      v78_2_cursor.descend_to_byte(v78_2_byte);
      let v78_2_tail = v78_2_cursor.make_map();
      v78_2_cursor.ascend(1);
      let v78_2_head = Path::from_slice(&[v78_2_byte]);
      let mut v79_2 = Space::new();
      let mut v79_2_cursor = (v78_2_tail).read_zipper();
      for v79_2_byte in v79_2_cursor.child_mask().iter() {
        v79_2_cursor.descend_to_byte(v79_2_byte);
        let v79_2_tail = v79_2_cursor.make_map();
        v79_2_cursor.ascend(1);
        let v79_2_head = Path::from_slice(&[v79_2_byte]);
        let v80_2: Space = tails_union(&(v79_2_tail));
        v79_2.join_into((v80_2).clone());
      }
      drop(v79_2_cursor);
      v78_2.join_into((v79_2).clone());
    }
    drop(v78_2_cursor);
    v41_22.join_into((v78_2).clone());
  }
  drop(v41_22_cursor);
  drop(v41_21);
  let v41_24: Space = if (v41_22).is_empty() { Space::new() } else {
    let mut v81_23 = Space::new();
    let mut v81_23_cursor = (*capture_1).read_zipper();
    for v81_23_byte in v81_23_cursor.child_mask().iter() {
      v81_23_cursor.descend_to_byte(v81_23_byte);
      let v81_23_tail = v81_23_cursor.make_map();
      v81_23_cursor.ascend(1);
      let v81_23_head = Path::from_slice(&[v81_23_byte]);
      let mut v82_2 = Space::new();
      let mut v82_2_cursor = (v81_23_tail).read_zipper();
      for v82_2_byte in v82_2_cursor.child_mask().iter() {
        v82_2_cursor.descend_to_byte(v82_2_byte);
        let v82_2_tail = v82_2_cursor.make_map();
        v82_2_cursor.ascend(1);
        let v82_2_head = Path::from_slice(&[v82_2_byte]);
        let v83_2: Path = concat_path(&(v81_23_head),&(v82_2_head));
        let mut v83_3 = Space::new();
        let mut v83_3_cursor = (v82_2_tail).read_zipper();
        for v83_3_byte in v83_3_cursor.child_mask().iter() {
          v83_3_cursor.descend_to_byte(v83_3_byte);
          let v83_3_tail = v83_3_cursor.make_map();
          v83_3_cursor.ascend(1);
          let v83_3_head = Path::from_slice(&[v83_3_byte]);
          let v84_2: Path = concat_path(&(v83_2),&(v83_3_head));
          let mut v84_3 = Space::new();
          let mut v84_3_cursor = (v83_3_tail).read_zipper();
          for v84_3_byte in v84_3_cursor.child_mask().iter() {
            v84_3_cursor.descend_to_byte(v84_3_byte);
            let v84_3_tail = v84_3_cursor.make_map();
            v84_3_cursor.ascend(1);
            let v84_3_head = Path::from_slice(&[v84_3_byte]);
            let v85_2: Path = concat_path(&(v84_2),&(v84_3_head));
            let mut v85_3 = Space::new();
            let mut v85_3_cursor = (v84_3_tail).read_zipper();
            for v85_3_byte in v85_3_cursor.child_mask().iter() {
              v85_3_cursor.descend_to_byte(v85_3_byte);
              let v85_3_tail = v85_3_cursor.make_map();
              v85_3_cursor.ascend(1);
              let v85_3_head = Path::from_slice(&[v85_3_byte]);
              let mut v86_2 = Space::new();
              let mut v86_2_cursor = (v85_3_tail).read_zipper();
              for v86_2_byte in v86_2_cursor.child_mask().iter() {
                v86_2_cursor.descend_to_byte(v86_2_byte);
                let v86_2_tail = v86_2_cursor.make_map();
                v86_2_cursor.ascend(1);
                let v86_2_head = Path::from_slice(&[v86_2_byte]);
                let v87_2: Path = concat_path(&(v85_3_head),&(v86_2_head));
                let mut v87_3 = Space::new();
                let mut v87_3_cursor = (v86_2_tail).read_zipper();
                for v87_3_byte in v87_3_cursor.child_mask().iter() {
                  v87_3_cursor.descend_to_byte(v87_3_byte);
                  let v87_3_tail = v87_3_cursor.make_map();
                  v87_3_cursor.ascend(1);
                  let v87_3_head = Path::from_slice(&[v87_3_byte]);
                  let v88_2: Path = concat_path(&(v87_2),&(v87_3_head));
                  let mut v88_3 = Space::new();
                  let mut v88_3_cursor = (v87_3_tail).read_zipper();
                  for v88_3_byte in v88_3_cursor.child_mask().iter() {
                    v88_3_cursor.descend_to_byte(v88_3_byte);
                    let v88_3_tail = v88_3_cursor.make_map();
                    v88_3_cursor.ascend(1);
                    let v88_3_head = Path::from_slice(&[v88_3_byte]);
                    let v89_2: Path = concat_path(&(v88_2),&(v88_3_head));
                    let v89_3: Space = routine_11(c, &(v89_2), &(v85_2), &(v88_3_tail));
                    drop(v89_2);
                    v88_3.join_into((v89_3).clone());
                  }
                  drop(v88_3_cursor);
                  drop(v88_2);
                  v87_3.join_into((v88_3).clone());
                }
                drop(v87_3_cursor);
                drop(v87_2);
                v86_2.join_into((v87_3).clone());
              }
              drop(v86_2_cursor);
              v85_3.join_into((v86_2).clone());
            }
            drop(v85_3_cursor);
            drop(v85_2);
            v84_3.join_into((v85_3).clone());
          }
          drop(v84_3_cursor);
          drop(v84_2);
          v83_3.join_into((v84_3).clone());
        }
        drop(v83_3_cursor);
        drop(v83_2);
        v82_2.join_into((v83_3).clone());
      }
      drop(v82_2_cursor);
      v81_23.join_into((v82_2).clone());
    }
    drop(v81_23_cursor);
    compose(&(v41_22),&(v81_23))
  };
  drop(v41_22);
  let v41_25: Space = unite(&(v41_19),&(v41_24));
  let v41_27: Space = intersect(&(*CONSTANT_51),&(v41_3));
  let mut v41_28 = Space::new();
  let mut v41_28_cursor = (v41_27).read_zipper();
  for v41_28_byte in v41_28_cursor.child_mask().iter() {
    v41_28_cursor.descend_to_byte(v41_28_byte);
    let v41_28_tail = v41_28_cursor.make_map();
    v41_28_cursor.ascend(1);
    let v41_28_head = Path::from_slice(&[v41_28_byte]);
    let mut v90_2 = Space::new();
    let mut v90_2_cursor = (v41_28_tail).read_zipper();
    for v90_2_byte in v90_2_cursor.child_mask().iter() {
      v90_2_cursor.descend_to_byte(v90_2_byte);
      let v90_2_tail = v90_2_cursor.make_map();
      v90_2_cursor.ascend(1);
      let v90_2_head = Path::from_slice(&[v90_2_byte]);
      let mut v91_2 = Space::new();
      let mut v91_2_cursor = (v90_2_tail).read_zipper();
      for v91_2_byte in v91_2_cursor.child_mask().iter() {
        v91_2_cursor.descend_to_byte(v91_2_byte);
        let v91_2_tail = v91_2_cursor.make_map();
        v91_2_cursor.ascend(1);
        let v91_2_head = Path::from_slice(&[v91_2_byte]);
        let v92_2: Space = tails_union(&(v91_2_tail));
        v91_2.join_into((v92_2).clone());
      }
      drop(v91_2_cursor);
      v90_2.join_into((v91_2).clone());
    }
    drop(v90_2_cursor);
    v41_28.join_into((v90_2).clone());
  }
  drop(v41_28_cursor);
  drop(v41_27);
  let v41_30: Space = if (v41_28).is_empty() { Space::new() } else {
    let mut v93_29 = Space::new();
    let mut v93_29_cursor = (*capture_1).read_zipper();
    for v93_29_byte in v93_29_cursor.child_mask().iter() {
      v93_29_cursor.descend_to_byte(v93_29_byte);
      let v93_29_tail = v93_29_cursor.make_map();
      v93_29_cursor.ascend(1);
      let v93_29_head = Path::from_slice(&[v93_29_byte]);
      let mut v94_2 = Space::new();
      let mut v94_2_cursor = (v93_29_tail).read_zipper();
      for v94_2_byte in v94_2_cursor.child_mask().iter() {
        v94_2_cursor.descend_to_byte(v94_2_byte);
        let v94_2_tail = v94_2_cursor.make_map();
        v94_2_cursor.ascend(1);
        let v94_2_head = Path::from_slice(&[v94_2_byte]);
        let v95_2: Path = concat_path(&(v93_29_head),&(v94_2_head));
        let mut v95_3 = Space::new();
        let mut v95_3_cursor = (v94_2_tail).read_zipper();
        for v95_3_byte in v95_3_cursor.child_mask().iter() {
          v95_3_cursor.descend_to_byte(v95_3_byte);
          let v95_3_tail = v95_3_cursor.make_map();
          v95_3_cursor.ascend(1);
          let v95_3_head = Path::from_slice(&[v95_3_byte]);
          let v96_2: Path = concat_path(&(v95_2),&(v95_3_head));
          let mut v96_3 = Space::new();
          let mut v96_3_cursor = (v95_3_tail).read_zipper();
          for v96_3_byte in v96_3_cursor.child_mask().iter() {
            v96_3_cursor.descend_to_byte(v96_3_byte);
            let v96_3_tail = v96_3_cursor.make_map();
            v96_3_cursor.ascend(1);
            let v96_3_head = Path::from_slice(&[v96_3_byte]);
            let v97_2: Path = concat_path(&(v96_2),&(v96_3_head));
            let mut v97_3 = Space::new();
            let mut v97_3_cursor = (v96_3_tail).read_zipper();
            for v97_3_byte in v97_3_cursor.child_mask().iter() {
              v97_3_cursor.descend_to_byte(v97_3_byte);
              let v97_3_tail = v97_3_cursor.make_map();
              v97_3_cursor.ascend(1);
              let v97_3_head = Path::from_slice(&[v97_3_byte]);
              let mut v98_2 = Space::new();
              let mut v98_2_cursor = (v97_3_tail).read_zipper();
              for v98_2_byte in v98_2_cursor.child_mask().iter() {
                v98_2_cursor.descend_to_byte(v98_2_byte);
                let v98_2_tail = v98_2_cursor.make_map();
                v98_2_cursor.ascend(1);
                let v98_2_head = Path::from_slice(&[v98_2_byte]);
                let v99_2: Path = concat_path(&(v97_3_head),&(v98_2_head));
                let mut v99_3 = Space::new();
                let mut v99_3_cursor = (v98_2_tail).read_zipper();
                for v99_3_byte in v99_3_cursor.child_mask().iter() {
                  v99_3_cursor.descend_to_byte(v99_3_byte);
                  let v99_3_tail = v99_3_cursor.make_map();
                  v99_3_cursor.ascend(1);
                  let v99_3_head = Path::from_slice(&[v99_3_byte]);
                  let v100_2: Path = concat_path(&(v99_2),&(v99_3_head));
                  let mut v100_3 = Space::new();
                  let mut v100_3_cursor = (v99_3_tail).read_zipper();
                  for v100_3_byte in v100_3_cursor.child_mask().iter() {
                    v100_3_cursor.descend_to_byte(v100_3_byte);
                    let v100_3_tail = v100_3_cursor.make_map();
                    v100_3_cursor.ascend(1);
                    let v100_3_head = Path::from_slice(&[v100_3_byte]);
                    let v101_2: Path = concat_path(&(v100_2),&(v100_3_head));
                    let v101_3: Space = routine_12(c, &(v101_2), &(v97_2), &(v100_3_tail));
                    drop(v101_2);
                    v100_3.join_into((v101_3).clone());
                  }
                  drop(v100_3_cursor);
                  drop(v100_2);
                  v99_3.join_into((v100_3).clone());
                }
                drop(v99_3_cursor);
                drop(v99_2);
                v98_2.join_into((v99_3).clone());
              }
              drop(v98_2_cursor);
              v97_3.join_into((v98_2).clone());
            }
            drop(v97_3_cursor);
            drop(v97_2);
            v96_3.join_into((v97_3).clone());
          }
          drop(v96_3_cursor);
          drop(v96_2);
          v95_3.join_into((v96_3).clone());
        }
        drop(v95_3_cursor);
        drop(v95_2);
        v94_2.join_into((v95_3).clone());
      }
      drop(v94_2_cursor);
      v93_29.join_into((v94_2).clone());
    }
    drop(v93_29_cursor);
    compose(&(v41_28),&(v93_29))
  };
  drop(v41_28);
  let v41_31: Space = unite(&(v41_25),&(v41_30));
  let v41_33: Space = intersect(&(*CONSTANT_52),&(v41_3));
  let mut v41_34 = Space::new();
  let mut v41_34_cursor = (v41_33).read_zipper();
  for v41_34_byte in v41_34_cursor.child_mask().iter() {
    v41_34_cursor.descend_to_byte(v41_34_byte);
    let v41_34_tail = v41_34_cursor.make_map();
    v41_34_cursor.ascend(1);
    let v41_34_head = Path::from_slice(&[v41_34_byte]);
    let mut v102_2 = Space::new();
    let mut v102_2_cursor = (v41_34_tail).read_zipper();
    for v102_2_byte in v102_2_cursor.child_mask().iter() {
      v102_2_cursor.descend_to_byte(v102_2_byte);
      let v102_2_tail = v102_2_cursor.make_map();
      v102_2_cursor.ascend(1);
      let v102_2_head = Path::from_slice(&[v102_2_byte]);
      let mut v103_2 = Space::new();
      let mut v103_2_cursor = (v102_2_tail).read_zipper();
      for v103_2_byte in v103_2_cursor.child_mask().iter() {
        v103_2_cursor.descend_to_byte(v103_2_byte);
        let v103_2_tail = v103_2_cursor.make_map();
        v103_2_cursor.ascend(1);
        let v103_2_head = Path::from_slice(&[v103_2_byte]);
        let v104_2: Space = tails_union(&(v103_2_tail));
        v103_2.join_into((v104_2).clone());
      }
      drop(v103_2_cursor);
      v102_2.join_into((v103_2).clone());
    }
    drop(v102_2_cursor);
    v41_34.join_into((v102_2).clone());
  }
  drop(v41_34_cursor);
  drop(v41_33);
  let v41_36: Space = if (v41_34).is_empty() { Space::new() } else {
    let mut v105_35 = Space::new();
    let mut v105_35_cursor = (*capture_1).read_zipper();
    for v105_35_byte in v105_35_cursor.child_mask().iter() {
      v105_35_cursor.descend_to_byte(v105_35_byte);
      let v105_35_tail = v105_35_cursor.make_map();
      v105_35_cursor.ascend(1);
      let v105_35_head = Path::from_slice(&[v105_35_byte]);
      let mut v106_2 = Space::new();
      let mut v106_2_cursor = (v105_35_tail).read_zipper();
      for v106_2_byte in v106_2_cursor.child_mask().iter() {
        v106_2_cursor.descend_to_byte(v106_2_byte);
        let v106_2_tail = v106_2_cursor.make_map();
        v106_2_cursor.ascend(1);
        let v106_2_head = Path::from_slice(&[v106_2_byte]);
        let v107_2: Path = concat_path(&(v105_35_head),&(v106_2_head));
        let mut v107_3 = Space::new();
        let mut v107_3_cursor = (v106_2_tail).read_zipper();
        for v107_3_byte in v107_3_cursor.child_mask().iter() {
          v107_3_cursor.descend_to_byte(v107_3_byte);
          let v107_3_tail = v107_3_cursor.make_map();
          v107_3_cursor.ascend(1);
          let v107_3_head = Path::from_slice(&[v107_3_byte]);
          let v108_2: Path = concat_path(&(v107_2),&(v107_3_head));
          let mut v108_3 = Space::new();
          let mut v108_3_cursor = (v107_3_tail).read_zipper();
          for v108_3_byte in v108_3_cursor.child_mask().iter() {
            v108_3_cursor.descend_to_byte(v108_3_byte);
            let v108_3_tail = v108_3_cursor.make_map();
            v108_3_cursor.ascend(1);
            let v108_3_head = Path::from_slice(&[v108_3_byte]);
            let v109_2: Path = concat_path(&(v108_2),&(v108_3_head));
            let mut v109_3 = Space::new();
            let mut v109_3_cursor = (v108_3_tail).read_zipper();
            for v109_3_byte in v109_3_cursor.child_mask().iter() {
              v109_3_cursor.descend_to_byte(v109_3_byte);
              let v109_3_tail = v109_3_cursor.make_map();
              v109_3_cursor.ascend(1);
              let v109_3_head = Path::from_slice(&[v109_3_byte]);
              let mut v110_2 = Space::new();
              let mut v110_2_cursor = (v109_3_tail).read_zipper();
              for v110_2_byte in v110_2_cursor.child_mask().iter() {
                v110_2_cursor.descend_to_byte(v110_2_byte);
                let v110_2_tail = v110_2_cursor.make_map();
                v110_2_cursor.ascend(1);
                let v110_2_head = Path::from_slice(&[v110_2_byte]);
                let v111_2: Path = concat_path(&(v109_3_head),&(v110_2_head));
                let mut v111_3 = Space::new();
                let mut v111_3_cursor = (v110_2_tail).read_zipper();
                for v111_3_byte in v111_3_cursor.child_mask().iter() {
                  v111_3_cursor.descend_to_byte(v111_3_byte);
                  let v111_3_tail = v111_3_cursor.make_map();
                  v111_3_cursor.ascend(1);
                  let v111_3_head = Path::from_slice(&[v111_3_byte]);
                  let v112_2: Path = concat_path(&(v111_2),&(v111_3_head));
                  let mut v112_3 = Space::new();
                  let mut v112_3_cursor = (v111_3_tail).read_zipper();
                  for v112_3_byte in v112_3_cursor.child_mask().iter() {
                    v112_3_cursor.descend_to_byte(v112_3_byte);
                    let v112_3_tail = v112_3_cursor.make_map();
                    v112_3_cursor.ascend(1);
                    let v112_3_head = Path::from_slice(&[v112_3_byte]);
                    let v113_2: Path = concat_path(&(v112_2),&(v112_3_head));
                    let v113_3: Space = routine_13(c, &(v113_2), &(v109_2), &(v112_3_tail));
                    drop(v113_2);
                    v112_3.join_into((v113_3).clone());
                  }
                  drop(v112_3_cursor);
                  drop(v112_2);
                  v111_3.join_into((v112_3).clone());
                }
                drop(v111_3_cursor);
                drop(v111_2);
                v110_2.join_into((v111_3).clone());
              }
              drop(v110_2_cursor);
              v109_3.join_into((v110_2).clone());
            }
            drop(v109_3_cursor);
            drop(v109_2);
            v108_3.join_into((v109_3).clone());
          }
          drop(v108_3_cursor);
          drop(v108_2);
          v107_3.join_into((v108_3).clone());
        }
        drop(v107_3_cursor);
        drop(v107_2);
        v106_2.join_into((v107_3).clone());
      }
      drop(v106_2_cursor);
      v105_35.join_into((v106_2).clone());
    }
    drop(v105_35_cursor);
    compose(&(v41_34),&(v105_35))
  };
  drop(v41_34);

((v41_12).clone(),(v41_13).clone(),(v41_18).clone(),(v41_19).clone(),(v41_24).clone(),(v41_25).clone(),(v41_3).clone(),(v41_30).clone(),(v41_31).clone(),(v41_36).clone(),(v41_7).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_3: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_1), &(*CONSTANT_2));
  let v0_6: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_3), &(*CONSTANT_4));
  let v0_7: Space = unite(&(v0_3),&(v0_6));
  let v0_10: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_5), &(*CONSTANT_6));
  let v0_11: Space = unite(&(v0_7),&(v0_10));
  let v0_14: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_7), &(*CONSTANT_8));
  let v0_15: Space = unite(&(v0_11),&(v0_14));
  let v0_18: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_9), &(*CONSTANT_10));
  let v0_19: Space = unite(&(v0_15),&(v0_18));
  let v0_22: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_11), &(*CONSTANT_12));
  let v0_23: Space = unite(&(v0_19),&(v0_22));
  let v0_26: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_13), &(*CONSTANT_14));
  let v0_27: Space = unite(&(v0_23),&(v0_26));
  let v0_30: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_15), &(*CONSTANT_16));
  let v0_31: Space = unite(&(v0_27),&(v0_30));
  let v0_34: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_17), &(*CONSTANT_18));
  let v0_35: Space = unite(&(v0_31),&(v0_34));
  let v0_38: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_1), &(*CONSTANT_20));
  let v0_39: Space = unite(&(v0_35),&(v0_38));
  let v0_41: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_3), &(*CONSTANT_21));
  let v0_42: Space = unite(&(v0_39),&(v0_41));
  let v0_44: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_5), &(*CONSTANT_21));
  let v0_45: Space = unite(&(v0_42),&(v0_44));
  let v0_47: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_9), &(*CONSTANT_22));
  let v0_48: Space = unite(&(v0_45),&(v0_47));
  let v0_51: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_1), &(*CONSTANT_24));
  let v0_52: Space = unite(&(v0_48),&(v0_51));
  let v0_54: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_3), &(*CONSTANT_24));
  let v0_55: Space = unite(&(v0_52),&(v0_54));
  let v0_57: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_5), &(*CONSTANT_25));
  let v0_58: Space = unite(&(v0_55),&(v0_57));
  let v0_60: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_7), &(*CONSTANT_26));
  let v0_61: Space = unite(&(v0_58),&(v0_60));
  let v0_63: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_9), &(*CONSTANT_27));
  let v0_64: Space = unite(&(v0_61),&(v0_63));
  let v0_66: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_11), &(*CONSTANT_28));
  let v0_67: Space = unite(&(v0_64),&(v0_66));
  let v0_69: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_13), &(*CONSTANT_29));
  let v0_70: Space = unite(&(v0_67),&(v0_69));
  let v0_72: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_15), &(*CONSTANT_30));
  let v0_73: Space = unite(&(v0_70),&(v0_72));
  let v0_75: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_17), &(*CONSTANT_31));
  let v0_76: Space = unite(&(v0_73),&(v0_75));
  let v0_79: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_1), &(*CONSTANT_33));
  let v0_80: Space = unite(&(v0_76),&(v0_79));
  let v0_82: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_3), &(*CONSTANT_34));
  let v0_83: Space = unite(&(v0_80),&(v0_82));
  let v0_85: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_5), &(*CONSTANT_35));
  let v0_86: Space = unite(&(v0_83),&(v0_85));
  let v0_88: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_7), &(*CONSTANT_36));
  let v0_89: Space = unite(&(v0_86),&(v0_88));
  let v0_91: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_9), &(*CONSTANT_37));
  let v0_92: Space = unite(&(v0_89),&(v0_91));
  let v0_94: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_11), &(*CONSTANT_38));
  let v0_95: Space = unite(&(v0_92),&(v0_94));
  let v0_97: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_13), &(*CONSTANT_39));
  let v0_98: Space = unite(&(v0_95),&(v0_97));
  let v0_100: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_15), &(*CONSTANT_40));
  let v0_101: Space = unite(&(v0_98),&(v0_100));
  let v0_103: Space = routine_1(c, &(*CONSTANT_32), &(*CONSTANT_17), &(*CONSTANT_41));
  let v0_104: Space = unite(&(v0_101),&(v0_103));
  let v0_107: Space = routine_1(c, &(*CONSTANT_42), &(*CONSTANT_1), &(*CONSTANT_43));
  let v0_108: Space = unite(&(v0_104),&(v0_107));
  let v0_111: Space = routine_1(c, &(*CONSTANT_44), &(*CONSTANT_7), &(*CONSTANT_45));
  let v0_112: Space = unite(&(v0_108),&(v0_111));
  let v0_114: Space = routine_1(c, &(*CONSTANT_44), &(*CONSTANT_9), &(*CONSTANT_45));
  let v0_115: Space = unite(&(v0_112),&(v0_114));
  let v0_117: Space = routine_1(c, &(*CONSTANT_44), &(*CONSTANT_13), &(*CONSTANT_46));
  let v0_118: Space = unite(&(v0_115),&(v0_117));
  (v0_118).clone()
}

fn routine_1(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1_3 = Space::new();
  let mut v1_3_cursor = (*s0).read_zipper();
  for v1_3_byte in v1_3_cursor.child_mask().iter() {
    v1_3_cursor.descend_to_byte(v1_3_byte);
    let v1_3_tail = v1_3_cursor.make_map();
    v1_3_cursor.ascend(1);
    let v1_3_head = Path::from_slice(&[v1_3_byte]);
    let mut v2_2 = Space::new();
    let mut v2_2_cursor = (v1_3_tail).read_zipper();
    for v2_2_byte in v2_2_cursor.child_mask().iter() {
      v2_2_cursor.descend_to_byte(v2_2_byte);
      let v2_2_tail = v2_2_cursor.make_map();
      v2_2_cursor.ascend(1);
      let v2_2_head = Path::from_slice(&[v2_2_byte]);
      let v3_2: Path = concat_path(&(v1_3_head),&(v2_2_head));
      let mut v3_3 = Space::new();
      let mut v3_3_cursor = (v2_2_tail).read_zipper();
      for v3_3_byte in v3_3_cursor.child_mask().iter() {
        v3_3_cursor.descend_to_byte(v3_3_byte);
        let v3_3_tail = v3_3_cursor.make_map();
        v3_3_cursor.ascend(1);
        let v3_3_head = Path::from_slice(&[v3_3_byte]);
        let v4_2: Path = concat_path(&(v3_2),&(v3_3_head));
        let mut v4_3 = Space::new();
        let mut v4_3_cursor = (v3_3_tail).read_zipper();
        for v4_3_byte in v4_3_cursor.child_mask().iter() {
          v4_3_cursor.descend_to_byte(v4_3_byte);
          let v4_3_tail = v4_3_cursor.make_map();
          v4_3_cursor.ascend(1);
          let v4_3_head = Path::from_slice(&[v4_3_byte]);
          let v5_2: Path = concat_path(&(v4_2),&(v4_3_head));
          let mut v5_3 = Space::new();
          let mut v5_3_cursor = (v4_3_tail).read_zipper();
          for v5_3_byte in v5_3_cursor.child_mask().iter() {
            v5_3_cursor.descend_to_byte(v5_3_byte);
            let v5_3_tail = v5_3_cursor.make_map();
            v5_3_cursor.ascend(1);
            let v5_3_head = Path::from_slice(&[v5_3_byte]);
            let mut v6_2 = Space::new();
            let mut v6_2_cursor = (v5_3_tail).read_zipper();
            for v6_2_byte in v6_2_cursor.child_mask().iter() {
              v6_2_cursor.descend_to_byte(v6_2_byte);
              let v6_2_tail = v6_2_cursor.make_map();
              v6_2_cursor.ascend(1);
              let v6_2_head = Path::from_slice(&[v6_2_byte]);
              let v7_2: Path = concat_path(&(v5_3_head),&(v6_2_head));
              let mut v7_3 = Space::new();
              let mut v7_3_cursor = (v6_2_tail).read_zipper();
              for v7_3_byte in v7_3_cursor.child_mask().iter() {
                v7_3_cursor.descend_to_byte(v7_3_byte);
                let v7_3_tail = v7_3_cursor.make_map();
                v7_3_cursor.ascend(1);
                let v7_3_head = Path::from_slice(&[v7_3_byte]);
                let v8_2: Path = concat_path(&(v7_2),&(v7_3_head));
                let mut v8_3 = Space::new();
                let mut v8_3_cursor = (v7_3_tail).read_zipper();
                for v8_3_byte in v8_3_cursor.child_mask().iter() {
                  v8_3_cursor.descend_to_byte(v8_3_byte);
                  let v8_3_tail = v8_3_cursor.make_map();
                  v8_3_cursor.ascend(1);
                  let v8_3_head = Path::from_slice(&[v8_3_byte]);
                  let v9_2: Path = concat_path(&(v8_2),&(v8_3_head));
                  let v9_3: Space = routine_2(c, &(v9_2), &(*p1), &(*p0), &(v5_2), &(v8_3_tail));
                  drop(v9_2);
                  v8_3.join_into((v9_3).clone());
                }
                drop(v8_3_cursor);
                drop(v8_2);
                v7_3.join_into((v8_3).clone());
              }
              drop(v7_3_cursor);
              drop(v7_2);
              v6_2.join_into((v7_3).clone());
            }
            drop(v6_2_cursor);
            v5_3.join_into((v6_2).clone());
          }
          drop(v5_3_cursor);
          drop(v5_2);
          v4_3.join_into((v5_3).clone());
        }
        drop(v4_3_cursor);
        drop(v4_2);
        v3_3.join_into((v4_3).clone());
      }
      drop(v3_3_cursor);
      drop(v3_2);
      v2_2.join_into((v3_3).clone());
    }
    drop(v2_2_cursor);
    v1_3.join_into((v2_2).clone());
  }
  drop(v1_3_cursor);
  (v1_3).clone()
}

fn routine_2(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v10_5 = Space::new();
  let mut v10_5_cursor = (*s0).read_zipper();
  for v10_5_byte in v10_5_cursor.child_mask().iter() {
    v10_5_cursor.descend_to_byte(v10_5_byte);
    let v10_5_tail = v10_5_cursor.make_map();
    v10_5_cursor.ascend(1);
    let v10_5_head = Path::from_slice(&[v10_5_byte]);
    let mut v11_2 = Space::new();
    let mut v11_2_cursor = (v10_5_tail).read_zipper();
    for v11_2_byte in v11_2_cursor.child_mask().iter() {
      v11_2_cursor.descend_to_byte(v11_2_byte);
      let v11_2_tail = v11_2_cursor.make_map();
      v11_2_cursor.ascend(1);
      let v11_2_head = Path::from_slice(&[v11_2_byte]);
      let v12_2: Path = concat_path(&(v10_5_head),&(v11_2_head));
      let mut v12_3 = Space::new();
      let mut v12_3_cursor = (v11_2_tail).read_zipper();
      for v12_3_byte in v12_3_cursor.child_mask().iter() {
        v12_3_cursor.descend_to_byte(v12_3_byte);
        let v12_3_tail = v12_3_cursor.make_map();
        v12_3_cursor.ascend(1);
        let v12_3_head = Path::from_slice(&[v12_3_byte]);
        let v13_2: Path = concat_path(&(v12_2),&(v12_3_head));
        let mut v13_3 = Space::new();
        let mut v13_3_cursor = (v12_3_tail).read_zipper();
        for v13_3_byte in v13_3_cursor.child_mask().iter() {
          v13_3_cursor.descend_to_byte(v13_3_byte);
          let v13_3_tail = v13_3_cursor.make_map();
          v13_3_cursor.ascend(1);
          let v13_3_head = Path::from_slice(&[v13_3_byte]);
          let v14_2: Path = concat_path(&(v13_2),&(v13_3_head));
          let mut v14_3 = Space::new();
          let mut v14_3_cursor = (v13_3_tail).read_zipper();
          for v14_3_byte in v14_3_cursor.child_mask().iter() {
            v14_3_cursor.descend_to_byte(v14_3_byte);
            let v14_3_tail = v14_3_cursor.make_map();
            v14_3_cursor.ascend(1);
            let v14_3_head = Path::from_slice(&[v14_3_byte]);
            let mut v15_2 = Space::new();
            let mut v15_2_cursor = (v14_3_tail).read_zipper();
            for v15_2_byte in v15_2_cursor.child_mask().iter() {
              v15_2_cursor.descend_to_byte(v15_2_byte);
              let v15_2_tail = v15_2_cursor.make_map();
              v15_2_cursor.ascend(1);
              let v15_2_head = Path::from_slice(&[v15_2_byte]);
              let v16_2: Path = concat_path(&(v14_3_head),&(v15_2_head));
              let mut v16_3 = Space::new();
              let mut v16_3_cursor = (v15_2_tail).read_zipper();
              for v16_3_byte in v16_3_cursor.child_mask().iter() {
                v16_3_cursor.descend_to_byte(v16_3_byte);
                let v16_3_tail = v16_3_cursor.make_map();
                v16_3_cursor.ascend(1);
                let v16_3_head = Path::from_slice(&[v16_3_byte]);
                let v17_2: Path = concat_path(&(v16_2),&(v16_3_head));
                let mut v17_3 = Space::new();
                let mut v17_3_cursor = (v16_3_tail).read_zipper();
                for v17_3_byte in v17_3_cursor.child_mask().iter() {
                  v17_3_cursor.descend_to_byte(v17_3_byte);
                  let v17_3_tail = v17_3_cursor.make_map();
                  v17_3_cursor.ascend(1);
                  let v17_3_head = Path::from_slice(&[v17_3_byte]);
                  let v18_2: Path = concat_path(&(v17_2),&(v17_3_head));
                  let v18_3: Space = routine_3(c, &(v18_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v14_2), &(v17_3_tail));
                  drop(v18_2);
                  v17_3.join_into((v18_3).clone());
                }
                drop(v17_3_cursor);
                drop(v17_2);
                v16_3.join_into((v17_3).clone());
              }
              drop(v16_3_cursor);
              drop(v16_2);
              v15_2.join_into((v16_3).clone());
            }
            drop(v15_2_cursor);
            v14_3.join_into((v15_2).clone());
          }
          drop(v14_3_cursor);
          drop(v14_2);
          v13_3.join_into((v14_3).clone());
        }
        drop(v13_3_cursor);
        drop(v13_2);
        v12_3.join_into((v13_3).clone());
      }
      drop(v12_3_cursor);
      drop(v12_2);
      v11_2.join_into((v12_3).clone());
    }
    drop(v11_2_cursor);
    v10_5.join_into((v11_2).clone());
  }
  drop(v10_5_cursor);
  (v10_5).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v19_7 = Space::new();
  let mut v19_7_cursor = (*s0).read_zipper();
  for v19_7_byte in v19_7_cursor.child_mask().iter() {
    v19_7_cursor.descend_to_byte(v19_7_byte);
    let v19_7_tail = v19_7_cursor.make_map();
    v19_7_cursor.ascend(1);
    let v19_7_head = Path::from_slice(&[v19_7_byte]);
    let mut v20_2 = Space::new();
    let mut v20_2_cursor = (v19_7_tail).read_zipper();
    for v20_2_byte in v20_2_cursor.child_mask().iter() {
      v20_2_cursor.descend_to_byte(v20_2_byte);
      let v20_2_tail = v20_2_cursor.make_map();
      v20_2_cursor.ascend(1);
      let v20_2_head = Path::from_slice(&[v20_2_byte]);
      let v21_2: Path = concat_path(&(v19_7_head),&(v20_2_head));
      let mut v21_3 = Space::new();
      let mut v21_3_cursor = (v20_2_tail).read_zipper();
      for v21_3_byte in v21_3_cursor.child_mask().iter() {
        v21_3_cursor.descend_to_byte(v21_3_byte);
        let v21_3_tail = v21_3_cursor.make_map();
        v21_3_cursor.ascend(1);
        let v21_3_head = Path::from_slice(&[v21_3_byte]);
        let v22_2: Path = concat_path(&(v21_2),&(v21_3_head));
        let mut v22_3 = Space::new();
        let mut v22_3_cursor = (v21_3_tail).read_zipper();
        for v22_3_byte in v22_3_cursor.child_mask().iter() {
          v22_3_cursor.descend_to_byte(v22_3_byte);
          let v22_3_tail = v22_3_cursor.make_map();
          v22_3_cursor.ascend(1);
          let v22_3_head = Path::from_slice(&[v22_3_byte]);
          let v23_2: Path = concat_path(&(v22_2),&(v22_3_head));
          let mut v23_3 = Space::new();
          let mut v23_3_cursor = (v22_3_tail).read_zipper();
          for v23_3_byte in v23_3_cursor.child_mask().iter() {
            v23_3_cursor.descend_to_byte(v23_3_byte);
            let v23_3_tail = v23_3_cursor.make_map();
            v23_3_cursor.ascend(1);
            let v23_3_head = Path::from_slice(&[v23_3_byte]);
            let mut v24_2 = Space::new();
            let mut v24_2_cursor = (v23_3_tail).read_zipper();
            for v24_2_byte in v24_2_cursor.child_mask().iter() {
              v24_2_cursor.descend_to_byte(v24_2_byte);
              let v24_2_tail = v24_2_cursor.make_map();
              v24_2_cursor.ascend(1);
              let v24_2_head = Path::from_slice(&[v24_2_byte]);
              let v25_2: Path = concat_path(&(v23_3_head),&(v24_2_head));
              let mut v25_3 = Space::new();
              let mut v25_3_cursor = (v24_2_tail).read_zipper();
              for v25_3_byte in v25_3_cursor.child_mask().iter() {
                v25_3_cursor.descend_to_byte(v25_3_byte);
                let v25_3_tail = v25_3_cursor.make_map();
                v25_3_cursor.ascend(1);
                let v25_3_head = Path::from_slice(&[v25_3_byte]);
                let v26_2: Path = concat_path(&(v25_2),&(v25_3_head));
                let mut v26_3 = Space::new();
                let mut v26_3_cursor = (v25_3_tail).read_zipper();
                for v26_3_byte in v26_3_cursor.child_mask().iter() {
                  v26_3_cursor.descend_to_byte(v26_3_byte);
                  let v26_3_tail = v26_3_cursor.make_map();
                  v26_3_cursor.ascend(1);
                  let v26_3_head = Path::from_slice(&[v26_3_byte]);
                  let v27_2: Path = concat_path(&(v26_2),&(v26_3_head));
                  let v27_3: Space = routine_4(c, &(v27_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v23_2), &(v26_3_tail));
                  drop(v27_2);
                  v26_3.join_into((v27_3).clone());
                }
                drop(v26_3_cursor);
                drop(v26_2);
                v25_3.join_into((v26_3).clone());
              }
              drop(v25_3_cursor);
              drop(v25_2);
              v24_2.join_into((v25_3).clone());
            }
            drop(v24_2_cursor);
            v23_3.join_into((v24_2).clone());
          }
          drop(v23_3_cursor);
          drop(v23_2);
          v22_3.join_into((v23_3).clone());
        }
        drop(v22_3_cursor);
        drop(v22_2);
        v21_3.join_into((v22_3).clone());
      }
      drop(v21_3_cursor);
      drop(v21_2);
      v20_2.join_into((v21_3).clone());
    }
    drop(v20_2_cursor);
    v19_7.join_into((v20_2).clone());
  }
  drop(v19_7_cursor);
  (v19_7).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v28_9: Path = concat_path(&(*p2),&(*p3));
  let v28_10: Path = concat_path(&(v28_9),&(*p4));
  drop(v28_9);
  let v28_11: Path = concat_path(&(v28_10),&(*p5));
  drop(v28_10);
  let v28_12: Path = concat_path(&(v28_11),&(*p6));
  drop(v28_11);
  let v28_13: Path = concat_path(&(v28_12),&(*p7));
  drop(v28_12);
  let v28_14: Path = concat_path(&(v28_13),&(*p0));
  drop(v28_13);
  let mut v28_15 = Space::new();
  let mut v28_15_cursor = (*s0).read_zipper();
  for v28_15_byte in v28_15_cursor.child_mask().iter() {
    v28_15_cursor.descend_to_byte(v28_15_byte);
    let v28_15_tail = v28_15_cursor.make_map();
    v28_15_cursor.ascend(1);
    let v28_15_head = Path::from_slice(&[v28_15_byte]);
    let mut v29_2 = Space::new();
    let mut v29_2_cursor = (v28_15_tail).read_zipper();
    for v29_2_byte in v29_2_cursor.child_mask().iter() {
      v29_2_cursor.descend_to_byte(v29_2_byte);
      let v29_2_tail = v29_2_cursor.make_map();
      v29_2_cursor.ascend(1);
      let v29_2_head = Path::from_slice(&[v29_2_byte]);
      let v30_2: Path = concat_path(&(v28_15_head),&(v29_2_head));
      let mut v30_3 = Space::new();
      let mut v30_3_cursor = (v29_2_tail).read_zipper();
      for v30_3_byte in v30_3_cursor.child_mask().iter() {
        v30_3_cursor.descend_to_byte(v30_3_byte);
        let v30_3_tail = v30_3_cursor.make_map();
        v30_3_cursor.ascend(1);
        let v30_3_head = Path::from_slice(&[v30_3_byte]);
        let v31_2: Path = concat_path(&(v30_2),&(v30_3_head));
        let mut v31_3 = Space::new();
        let mut v31_3_cursor = (v30_3_tail).read_zipper();
        for v31_3_byte in v31_3_cursor.child_mask().iter() {
          v31_3_cursor.descend_to_byte(v31_3_byte);
          let v31_3_tail = v31_3_cursor.make_map();
          v31_3_cursor.ascend(1);
          let v31_3_head = Path::from_slice(&[v31_3_byte]);
          let v32_2: Path = concat_path(&(v31_2),&(v31_3_head));
          let v32_3: Path = concat_path(&(v28_14),&(v32_2));
          drop(v32_2);
          let v32_4: Space = singleton(&(v32_3));
          drop(v32_3);
          let v32_5: Space = routine_5(c, &(*p1), &(v32_4));
          drop(v32_4);
          let mut v32_6 = Space::new();
          let mut v32_6_cursor = (v32_5).read_zipper();
          for v32_6_byte in v32_6_cursor.child_mask().iter() {
            v32_6_cursor.descend_to_byte(v32_6_byte);
            let v32_6_tail = v32_6_cursor.make_map();
            v32_6_cursor.ascend(1);
            let v32_6_head = Path::from_slice(&[v32_6_byte]);
            let mut v33_2 = Space::new();
            let mut v33_2_cursor = (v32_6_tail).read_zipper();
            for v33_2_byte in v33_2_cursor.child_mask().iter() {
              v33_2_cursor.descend_to_byte(v33_2_byte);
              let v33_2_tail = v33_2_cursor.make_map();
              v33_2_cursor.ascend(1);
              let v33_2_head = Path::from_slice(&[v33_2_byte]);
              let v34_2: Path = concat_path(&(v32_6_head),&(v33_2_head));
              let mut v34_3 = Space::new();
              let mut v34_3_cursor = (v33_2_tail).read_zipper();
              for v34_3_byte in v34_3_cursor.child_mask().iter() {
                v34_3_cursor.descend_to_byte(v34_3_byte);
                let v34_3_tail = v34_3_cursor.make_map();
                v34_3_cursor.ascend(1);
                let v34_3_head = Path::from_slice(&[v34_3_byte]);
                let v35_2: Path = concat_path(&(v34_2),&(v34_3_head));
                let mut v35_3 = Space::new();
                let mut v35_3_cursor = (v34_3_tail).read_zipper();
                for v35_3_byte in v35_3_cursor.child_mask().iter() {
                  v35_3_cursor.descend_to_byte(v35_3_byte);
                  let v35_3_tail = v35_3_cursor.make_map();
                  v35_3_cursor.ascend(1);
                  let v35_3_head = Path::from_slice(&[v35_3_byte]);
                  let v36_2: Path = concat_path(&(v35_2),&(v35_3_head));
                  let v36_3: Space = routine_6(c, &(v36_2), &(*p1), &(v35_3_tail));
                  drop(v36_2);
                  v35_3.join_into((v36_3).clone());
                }
                drop(v35_3_cursor);
                drop(v35_2);
                v34_3.join_into((v35_3).clone());
              }
              drop(v34_3_cursor);
              drop(v34_2);
              v33_2.join_into((v34_3).clone());
            }
            drop(v33_2_cursor);
            v32_6.join_into((v33_2).clone());
          }
          drop(v32_6_cursor);
          let mut v32_7 = Space::new();
          let mut v32_7_cursor = (v32_6).read_zipper();
          for v32_7_byte in v32_7_cursor.child_mask().iter() {
            v32_7_cursor.descend_to_byte(v32_7_byte);
            let v32_7_tail = v32_7_cursor.make_map();
            v32_7_cursor.ascend(1);
            let v32_7_head = Path::from_slice(&[v32_7_byte]);
            let mut v37_2 = Space::new();
            let mut v37_2_cursor = (v32_7_tail).read_zipper();
            for v37_2_byte in v37_2_cursor.child_mask().iter() {
              v37_2_cursor.descend_to_byte(v37_2_byte);
              let v37_2_tail = v37_2_cursor.make_map();
              v37_2_cursor.ascend(1);
              let v37_2_head = Path::from_slice(&[v37_2_byte]);
              let v38_2: Path = concat_path(&(v32_7_head),&(v37_2_head));
              let mut v38_3 = Space::new();
              let mut v38_3_cursor = (v37_2_tail).read_zipper();
              for v38_3_byte in v38_3_cursor.child_mask().iter() {
                v38_3_cursor.descend_to_byte(v38_3_byte);
                let v38_3_tail = v38_3_cursor.make_map();
                v38_3_cursor.ascend(1);
                let v38_3_head = Path::from_slice(&[v38_3_byte]);
                let v39_2: Path = concat_path(&(v38_2),&(v38_3_head));
                let mut v39_3 = Space::new();
                let mut v39_3_cursor = (v38_3_tail).read_zipper();
                for v39_3_byte in v39_3_cursor.child_mask().iter() {
                  v39_3_cursor.descend_to_byte(v39_3_byte);
                  let v39_3_tail = v39_3_cursor.make_map();
                  v39_3_cursor.ascend(1);
                  let v39_3_head = Path::from_slice(&[v39_3_byte]);
                  let v40_2: Path = concat_path(&(v39_2),&(v39_3_head));
                  let v40_3: Space = routine_7(c, &(v40_2), &(*p1), &(v39_3_tail));
                  drop(v40_2);
                  v39_3.join_into((v40_3).clone());
                }
                drop(v39_3_cursor);
                drop(v39_2);
                v38_3.join_into((v39_3).clone());
              }
              drop(v38_3_cursor);
              drop(v38_2);
              v37_2.join_into((v38_3).clone());
            }
            drop(v37_2_cursor);
            v32_7.join_into((v37_2).clone());
          }
          drop(v32_7_cursor);
          v31_3.join_into((v32_7).clone());
        }
        drop(v31_3_cursor);
        drop(v31_2);
        v30_3.join_into((v31_3).clone());
      }
      drop(v30_3_cursor);
      drop(v30_2);
      v29_2.join_into((v30_3).clone());
    }
    drop(v29_2_cursor);
    v28_15.join_into((v29_2).clone());
  }
  drop(v28_15_cursor);
  drop(v28_14);
  (v28_15).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let (v41_12,v41_13,v41_18,v41_19,v41_24,v41_25,v41_3,v41_30,v41_31,v41_36,v41_7,) = native_block_0(c, p0, s0);
  let v41_37: Space = unite(&(v41_31),&(v41_36));
  let v41_39: Space = intersect(&(*CONSTANT_53),&(v41_3));
  let mut v41_40 = Space::new();
  let mut v41_40_cursor = (v41_39).read_zipper();
  for v41_40_byte in v41_40_cursor.child_mask().iter() {
    v41_40_cursor.descend_to_byte(v41_40_byte);
    let v41_40_tail = v41_40_cursor.make_map();
    v41_40_cursor.ascend(1);
    let v41_40_head = Path::from_slice(&[v41_40_byte]);
    let mut v114_2 = Space::new();
    let mut v114_2_cursor = (v41_40_tail).read_zipper();
    for v114_2_byte in v114_2_cursor.child_mask().iter() {
      v114_2_cursor.descend_to_byte(v114_2_byte);
      let v114_2_tail = v114_2_cursor.make_map();
      v114_2_cursor.ascend(1);
      let v114_2_head = Path::from_slice(&[v114_2_byte]);
      let mut v115_2 = Space::new();
      let mut v115_2_cursor = (v114_2_tail).read_zipper();
      for v115_2_byte in v115_2_cursor.child_mask().iter() {
        v115_2_cursor.descend_to_byte(v115_2_byte);
        let v115_2_tail = v115_2_cursor.make_map();
        v115_2_cursor.ascend(1);
        let v115_2_head = Path::from_slice(&[v115_2_byte]);
        let v116_2: Space = tails_union(&(v115_2_tail));
        v115_2.join_into((v116_2).clone());
      }
      drop(v115_2_cursor);
      v114_2.join_into((v115_2).clone());
    }
    drop(v114_2_cursor);
    v41_40.join_into((v114_2).clone());
  }
  drop(v41_40_cursor);
  drop(v41_39);
  let v41_42: Space = if (v41_40).is_empty() { Space::new() } else {
    let mut v117_41 = Space::new();
    let mut v117_41_cursor = (*s0).read_zipper();
    for v117_41_byte in v117_41_cursor.child_mask().iter() {
      v117_41_cursor.descend_to_byte(v117_41_byte);
      let v117_41_tail = v117_41_cursor.make_map();
      v117_41_cursor.ascend(1);
      let v117_41_head = Path::from_slice(&[v117_41_byte]);
      let mut v118_2 = Space::new();
      let mut v118_2_cursor = (v117_41_tail).read_zipper();
      for v118_2_byte in v118_2_cursor.child_mask().iter() {
        v118_2_cursor.descend_to_byte(v118_2_byte);
        let v118_2_tail = v118_2_cursor.make_map();
        v118_2_cursor.ascend(1);
        let v118_2_head = Path::from_slice(&[v118_2_byte]);
        let v119_2: Path = concat_path(&(v117_41_head),&(v118_2_head));
        let mut v119_3 = Space::new();
        let mut v119_3_cursor = (v118_2_tail).read_zipper();
        for v119_3_byte in v119_3_cursor.child_mask().iter() {
          v119_3_cursor.descend_to_byte(v119_3_byte);
          let v119_3_tail = v119_3_cursor.make_map();
          v119_3_cursor.ascend(1);
          let v119_3_head = Path::from_slice(&[v119_3_byte]);
          let v120_2: Path = concat_path(&(v119_2),&(v119_3_head));
          let mut v120_3 = Space::new();
          let mut v120_3_cursor = (v119_3_tail).read_zipper();
          for v120_3_byte in v120_3_cursor.child_mask().iter() {
            v120_3_cursor.descend_to_byte(v120_3_byte);
            let v120_3_tail = v120_3_cursor.make_map();
            v120_3_cursor.ascend(1);
            let v120_3_head = Path::from_slice(&[v120_3_byte]);
            let v121_2: Path = concat_path(&(v120_2),&(v120_3_head));
            let mut v121_3 = Space::new();
            let mut v121_3_cursor = (v120_3_tail).read_zipper();
            for v121_3_byte in v121_3_cursor.child_mask().iter() {
              v121_3_cursor.descend_to_byte(v121_3_byte);
              let v121_3_tail = v121_3_cursor.make_map();
              v121_3_cursor.ascend(1);
              let v121_3_head = Path::from_slice(&[v121_3_byte]);
              let mut v122_2 = Space::new();
              let mut v122_2_cursor = (v121_3_tail).read_zipper();
              for v122_2_byte in v122_2_cursor.child_mask().iter() {
                v122_2_cursor.descend_to_byte(v122_2_byte);
                let v122_2_tail = v122_2_cursor.make_map();
                v122_2_cursor.ascend(1);
                let v122_2_head = Path::from_slice(&[v122_2_byte]);
                let v123_2: Path = concat_path(&(v121_3_head),&(v122_2_head));
                let mut v123_3 = Space::new();
                let mut v123_3_cursor = (v122_2_tail).read_zipper();
                for v123_3_byte in v123_3_cursor.child_mask().iter() {
                  v123_3_cursor.descend_to_byte(v123_3_byte);
                  let v123_3_tail = v123_3_cursor.make_map();
                  v123_3_cursor.ascend(1);
                  let v123_3_head = Path::from_slice(&[v123_3_byte]);
                  let v124_2: Path = concat_path(&(v123_2),&(v123_3_head));
                  let mut v124_3 = Space::new();
                  let mut v124_3_cursor = (v123_3_tail).read_zipper();
                  for v124_3_byte in v124_3_cursor.child_mask().iter() {
                    v124_3_cursor.descend_to_byte(v124_3_byte);
                    let v124_3_tail = v124_3_cursor.make_map();
                    v124_3_cursor.ascend(1);
                    let v124_3_head = Path::from_slice(&[v124_3_byte]);
                    let v125_2: Path = concat_path(&(v124_2),&(v124_3_head));
                    let v125_3: Space = routine_14(c, &(v125_2), &(v121_2), &(v124_3_tail));
                    drop(v125_2);
                    v124_3.join_into((v125_3).clone());
                  }
                  drop(v124_3_cursor);
                  drop(v124_2);
                  v123_3.join_into((v124_3).clone());
                }
                drop(v123_3_cursor);
                drop(v123_2);
                v122_2.join_into((v123_3).clone());
              }
              drop(v122_2_cursor);
              v121_3.join_into((v122_2).clone());
            }
            drop(v121_3_cursor);
            drop(v121_2);
            v120_3.join_into((v121_3).clone());
          }
          drop(v120_3_cursor);
          drop(v120_2);
          v119_3.join_into((v120_3).clone());
        }
        drop(v119_3_cursor);
        drop(v119_2);
        v118_2.join_into((v119_3).clone());
      }
      drop(v118_2_cursor);
      v117_41.join_into((v118_2).clone());
    }
    drop(v117_41_cursor);
    compose(&(v41_40),&(v117_41))
  };
  drop(v41_40);
  let v41_43: Space = unite(&(v41_37),&(v41_42));
  let v41_45: Space = intersect(&(*CONSTANT_54),&(v41_3));
  let mut v41_46 = Space::new();
  let mut v41_46_cursor = (v41_45).read_zipper();
  for v41_46_byte in v41_46_cursor.child_mask().iter() {
    v41_46_cursor.descend_to_byte(v41_46_byte);
    let v41_46_tail = v41_46_cursor.make_map();
    v41_46_cursor.ascend(1);
    let v41_46_head = Path::from_slice(&[v41_46_byte]);
    let mut v126_2 = Space::new();
    let mut v126_2_cursor = (v41_46_tail).read_zipper();
    for v126_2_byte in v126_2_cursor.child_mask().iter() {
      v126_2_cursor.descend_to_byte(v126_2_byte);
      let v126_2_tail = v126_2_cursor.make_map();
      v126_2_cursor.ascend(1);
      let v126_2_head = Path::from_slice(&[v126_2_byte]);
      let mut v127_2 = Space::new();
      let mut v127_2_cursor = (v126_2_tail).read_zipper();
      for v127_2_byte in v127_2_cursor.child_mask().iter() {
        v127_2_cursor.descend_to_byte(v127_2_byte);
        let v127_2_tail = v127_2_cursor.make_map();
        v127_2_cursor.ascend(1);
        let v127_2_head = Path::from_slice(&[v127_2_byte]);
        let v128_2: Space = tails_union(&(v127_2_tail));
        v127_2.join_into((v128_2).clone());
      }
      drop(v127_2_cursor);
      v126_2.join_into((v127_2).clone());
    }
    drop(v126_2_cursor);
    v41_46.join_into((v126_2).clone());
  }
  drop(v41_46_cursor);
  drop(v41_45);
  let v41_48: Space = if (v41_46).is_empty() { Space::new() } else {
    let mut v129_47 = Space::new();
    let mut v129_47_cursor = (*s0).read_zipper();
    for v129_47_byte in v129_47_cursor.child_mask().iter() {
      v129_47_cursor.descend_to_byte(v129_47_byte);
      let v129_47_tail = v129_47_cursor.make_map();
      v129_47_cursor.ascend(1);
      let v129_47_head = Path::from_slice(&[v129_47_byte]);
      let mut v130_2 = Space::new();
      let mut v130_2_cursor = (v129_47_tail).read_zipper();
      for v130_2_byte in v130_2_cursor.child_mask().iter() {
        v130_2_cursor.descend_to_byte(v130_2_byte);
        let v130_2_tail = v130_2_cursor.make_map();
        v130_2_cursor.ascend(1);
        let v130_2_head = Path::from_slice(&[v130_2_byte]);
        let v131_2: Path = concat_path(&(v129_47_head),&(v130_2_head));
        let mut v131_3 = Space::new();
        let mut v131_3_cursor = (v130_2_tail).read_zipper();
        for v131_3_byte in v131_3_cursor.child_mask().iter() {
          v131_3_cursor.descend_to_byte(v131_3_byte);
          let v131_3_tail = v131_3_cursor.make_map();
          v131_3_cursor.ascend(1);
          let v131_3_head = Path::from_slice(&[v131_3_byte]);
          let v132_2: Path = concat_path(&(v131_2),&(v131_3_head));
          let mut v132_3 = Space::new();
          let mut v132_3_cursor = (v131_3_tail).read_zipper();
          for v132_3_byte in v132_3_cursor.child_mask().iter() {
            v132_3_cursor.descend_to_byte(v132_3_byte);
            let v132_3_tail = v132_3_cursor.make_map();
            v132_3_cursor.ascend(1);
            let v132_3_head = Path::from_slice(&[v132_3_byte]);
            let v133_2: Path = concat_path(&(v132_2),&(v132_3_head));
            let mut v133_3 = Space::new();
            let mut v133_3_cursor = (v132_3_tail).read_zipper();
            for v133_3_byte in v133_3_cursor.child_mask().iter() {
              v133_3_cursor.descend_to_byte(v133_3_byte);
              let v133_3_tail = v133_3_cursor.make_map();
              v133_3_cursor.ascend(1);
              let v133_3_head = Path::from_slice(&[v133_3_byte]);
              let mut v134_2 = Space::new();
              let mut v134_2_cursor = (v133_3_tail).read_zipper();
              for v134_2_byte in v134_2_cursor.child_mask().iter() {
                v134_2_cursor.descend_to_byte(v134_2_byte);
                let v134_2_tail = v134_2_cursor.make_map();
                v134_2_cursor.ascend(1);
                let v134_2_head = Path::from_slice(&[v134_2_byte]);
                let v135_2: Path = concat_path(&(v133_3_head),&(v134_2_head));
                let mut v135_3 = Space::new();
                let mut v135_3_cursor = (v134_2_tail).read_zipper();
                for v135_3_byte in v135_3_cursor.child_mask().iter() {
                  v135_3_cursor.descend_to_byte(v135_3_byte);
                  let v135_3_tail = v135_3_cursor.make_map();
                  v135_3_cursor.ascend(1);
                  let v135_3_head = Path::from_slice(&[v135_3_byte]);
                  let v136_2: Path = concat_path(&(v135_2),&(v135_3_head));
                  let mut v136_3 = Space::new();
                  let mut v136_3_cursor = (v135_3_tail).read_zipper();
                  for v136_3_byte in v136_3_cursor.child_mask().iter() {
                    v136_3_cursor.descend_to_byte(v136_3_byte);
                    let v136_3_tail = v136_3_cursor.make_map();
                    v136_3_cursor.ascend(1);
                    let v136_3_head = Path::from_slice(&[v136_3_byte]);
                    let v137_2: Path = concat_path(&(v136_2),&(v136_3_head));
                    let v137_3: Space = routine_15(c, &(v137_2), &(v133_2), &(v136_3_tail));
                    drop(v137_2);
                    v136_3.join_into((v137_3).clone());
                  }
                  drop(v136_3_cursor);
                  drop(v136_2);
                  v135_3.join_into((v136_3).clone());
                }
                drop(v135_3_cursor);
                drop(v135_2);
                v134_2.join_into((v135_3).clone());
              }
              drop(v134_2_cursor);
              v133_3.join_into((v134_2).clone());
            }
            drop(v133_3_cursor);
            drop(v133_2);
            v132_3.join_into((v133_3).clone());
          }
          drop(v132_3_cursor);
          drop(v132_2);
          v131_3.join_into((v132_3).clone());
        }
        drop(v131_3_cursor);
        drop(v131_2);
        v130_2.join_into((v131_3).clone());
      }
      drop(v130_2_cursor);
      v129_47.join_into((v130_2).clone());
    }
    drop(v129_47_cursor);
    compose(&(v41_46),&(v129_47))
  };
  drop(v41_46);
  let v41_49: Space = unite(&(v41_43),&(v41_48));
  let v41_51: Space = intersect(&(*CONSTANT_55),&(v41_3));
  drop(v41_3);
  let mut v41_52 = Space::new();
  let mut v41_52_cursor = (v41_51).read_zipper();
  for v41_52_byte in v41_52_cursor.child_mask().iter() {
    v41_52_cursor.descend_to_byte(v41_52_byte);
    let v41_52_tail = v41_52_cursor.make_map();
    v41_52_cursor.ascend(1);
    let v41_52_head = Path::from_slice(&[v41_52_byte]);
    let mut v138_2 = Space::new();
    let mut v138_2_cursor = (v41_52_tail).read_zipper();
    for v138_2_byte in v138_2_cursor.child_mask().iter() {
      v138_2_cursor.descend_to_byte(v138_2_byte);
      let v138_2_tail = v138_2_cursor.make_map();
      v138_2_cursor.ascend(1);
      let v138_2_head = Path::from_slice(&[v138_2_byte]);
      let mut v139_2 = Space::new();
      let mut v139_2_cursor = (v138_2_tail).read_zipper();
      for v139_2_byte in v139_2_cursor.child_mask().iter() {
        v139_2_cursor.descend_to_byte(v139_2_byte);
        let v139_2_tail = v139_2_cursor.make_map();
        v139_2_cursor.ascend(1);
        let v139_2_head = Path::from_slice(&[v139_2_byte]);
        let v140_2: Space = tails_union(&(v139_2_tail));
        v139_2.join_into((v140_2).clone());
      }
      drop(v139_2_cursor);
      v138_2.join_into((v139_2).clone());
    }
    drop(v138_2_cursor);
    v41_52.join_into((v138_2).clone());
  }
  drop(v41_52_cursor);
  drop(v41_51);
  let v41_54: Space = if (v41_52).is_empty() { Space::new() } else {
    let mut v141_53 = Space::new();
    let mut v141_53_cursor = (*s0).read_zipper();
    for v141_53_byte in v141_53_cursor.child_mask().iter() {
      v141_53_cursor.descend_to_byte(v141_53_byte);
      let v141_53_tail = v141_53_cursor.make_map();
      v141_53_cursor.ascend(1);
      let v141_53_head = Path::from_slice(&[v141_53_byte]);
      let mut v142_2 = Space::new();
      let mut v142_2_cursor = (v141_53_tail).read_zipper();
      for v142_2_byte in v142_2_cursor.child_mask().iter() {
        v142_2_cursor.descend_to_byte(v142_2_byte);
        let v142_2_tail = v142_2_cursor.make_map();
        v142_2_cursor.ascend(1);
        let v142_2_head = Path::from_slice(&[v142_2_byte]);
        let v143_2: Path = concat_path(&(v141_53_head),&(v142_2_head));
        let mut v143_3 = Space::new();
        let mut v143_3_cursor = (v142_2_tail).read_zipper();
        for v143_3_byte in v143_3_cursor.child_mask().iter() {
          v143_3_cursor.descend_to_byte(v143_3_byte);
          let v143_3_tail = v143_3_cursor.make_map();
          v143_3_cursor.ascend(1);
          let v143_3_head = Path::from_slice(&[v143_3_byte]);
          let v144_2: Path = concat_path(&(v143_2),&(v143_3_head));
          let mut v144_3 = Space::new();
          let mut v144_3_cursor = (v143_3_tail).read_zipper();
          for v144_3_byte in v144_3_cursor.child_mask().iter() {
            v144_3_cursor.descend_to_byte(v144_3_byte);
            let v144_3_tail = v144_3_cursor.make_map();
            v144_3_cursor.ascend(1);
            let v144_3_head = Path::from_slice(&[v144_3_byte]);
            let v145_2: Path = concat_path(&(v144_2),&(v144_3_head));
            let mut v145_3 = Space::new();
            let mut v145_3_cursor = (v144_3_tail).read_zipper();
            for v145_3_byte in v145_3_cursor.child_mask().iter() {
              v145_3_cursor.descend_to_byte(v145_3_byte);
              let v145_3_tail = v145_3_cursor.make_map();
              v145_3_cursor.ascend(1);
              let v145_3_head = Path::from_slice(&[v145_3_byte]);
              let mut v146_2 = Space::new();
              let mut v146_2_cursor = (v145_3_tail).read_zipper();
              for v146_2_byte in v146_2_cursor.child_mask().iter() {
                v146_2_cursor.descend_to_byte(v146_2_byte);
                let v146_2_tail = v146_2_cursor.make_map();
                v146_2_cursor.ascend(1);
                let v146_2_head = Path::from_slice(&[v146_2_byte]);
                let v147_2: Path = concat_path(&(v145_3_head),&(v146_2_head));
                let mut v147_3 = Space::new();
                let mut v147_3_cursor = (v146_2_tail).read_zipper();
                for v147_3_byte in v147_3_cursor.child_mask().iter() {
                  v147_3_cursor.descend_to_byte(v147_3_byte);
                  let v147_3_tail = v147_3_cursor.make_map();
                  v147_3_cursor.ascend(1);
                  let v147_3_head = Path::from_slice(&[v147_3_byte]);
                  let v148_2: Path = concat_path(&(v147_2),&(v147_3_head));
                  let mut v148_3 = Space::new();
                  let mut v148_3_cursor = (v147_3_tail).read_zipper();
                  for v148_3_byte in v148_3_cursor.child_mask().iter() {
                    v148_3_cursor.descend_to_byte(v148_3_byte);
                    let v148_3_tail = v148_3_cursor.make_map();
                    v148_3_cursor.ascend(1);
                    let v148_3_head = Path::from_slice(&[v148_3_byte]);
                    let v149_2: Path = concat_path(&(v148_2),&(v148_3_head));
                    let v149_3: Space = routine_16(c, &(v149_2), &(v145_2), &(v148_3_tail));
                    drop(v149_2);
                    v148_3.join_into((v149_3).clone());
                  }
                  drop(v148_3_cursor);
                  drop(v148_2);
                  v147_3.join_into((v148_3).clone());
                }
                drop(v147_3_cursor);
                drop(v147_2);
                v146_2.join_into((v147_3).clone());
              }
              drop(v146_2_cursor);
              v145_3.join_into((v146_2).clone());
            }
            drop(v145_3_cursor);
            drop(v145_2);
            v144_3.join_into((v145_3).clone());
          }
          drop(v144_3_cursor);
          drop(v144_2);
          v143_3.join_into((v144_3).clone());
        }
        drop(v143_3_cursor);
        drop(v143_2);
        v142_2.join_into((v143_3).clone());
      }
      drop(v142_2_cursor);
      v141_53.join_into((v142_2).clone());
    }
    drop(v141_53_cursor);
    compose(&(v41_52),&(v141_53))
  };
  drop(v41_52);
  let v41_55: Space = unite(&(v41_49),&(v41_54));
  (v41_55).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v150_6: Space = routine_17(c, &(*CONSTANT_56), &(*CONSTANT_1), &(*CONSTANT_57));
  let v150_9: Space = routine_17(c, &(*CONSTANT_56), &(*CONSTANT_3), &(*CONSTANT_58));
  let v150_10: Space = unite(&(v150_6),&(v150_9));
  let v150_13: Space = routine_17(c, &(*CONSTANT_56), &(*CONSTANT_5), &(*CONSTANT_59));
  let v150_14: Space = unite(&(v150_10),&(v150_13));
  let v150_17: Space = routine_17(c, &(*CONSTANT_56), &(*CONSTANT_7), &(*CONSTANT_60));
  let v150_18: Space = unite(&(v150_14),&(v150_17));
  let v150_21: Space = routine_17(c, &(*CONSTANT_56), &(*CONSTANT_9), &(*CONSTANT_61));
  let v150_22: Space = unite(&(v150_18),&(v150_21));
  let v150_25: Space = routine_17(c, &(*CONSTANT_56), &(*CONSTANT_11), &(*CONSTANT_62));
  let v150_26: Space = unite(&(v150_22),&(v150_25));
  let v150_29: Space = routine_17(c, &(*CONSTANT_63), &(*CONSTANT_1), &(*CONSTANT_64));
  let v150_30: Space = unite(&(v150_26),&(v150_29));
  let v150_32: Space = routine_17(c, &(*CONSTANT_63), &(*CONSTANT_3), &(*CONSTANT_65));
  let v150_33: Space = unite(&(v150_30),&(v150_32));
  let v150_35: Space = routine_17(c, &(*CONSTANT_63), &(*CONSTANT_7), &(*CONSTANT_66));
  let v150_36: Space = unite(&(v150_33),&(v150_35));
  let v150_38: Space = routine_17(c, &(*CONSTANT_63), &(*CONSTANT_9), &(*CONSTANT_67));
  let v150_39: Space = unite(&(v150_36),&(v150_38));
  let v150_42: Space = routine_17(c, &(*CONSTANT_63), &(*CONSTANT_13), &(*CONSTANT_68));
  let v150_43: Space = unite(&(v150_39),&(v150_42));
  let v150_46: Space = routine_17(c, &(*CONSTANT_63), &(*CONSTANT_15), &(*CONSTANT_69));
  let v150_47: Space = unite(&(v150_43),&(v150_46));
  let v150_50: Space = routine_17(c, &(*CONSTANT_70), &(*CONSTANT_3), &(*CONSTANT_64));
  let v150_51: Space = unite(&(v150_47),&(v150_50));
  let v150_53: Space = routine_17(c, &(*CONSTANT_70), &(*CONSTANT_5), &(*CONSTANT_65));
  let v150_54: Space = unite(&(v150_51),&(v150_53));
  let v150_56: Space = routine_17(c, &(*CONSTANT_70), &(*CONSTANT_9), &(*CONSTANT_66));
  let v150_57: Space = unite(&(v150_54),&(v150_56));
  let v150_59: Space = routine_17(c, &(*CONSTANT_70), &(*CONSTANT_11), &(*CONSTANT_67));
  let v150_60: Space = unite(&(v150_57),&(v150_59));
  let v150_62: Space = routine_17(c, &(*CONSTANT_70), &(*CONSTANT_15), &(*CONSTANT_68));
  let v150_63: Space = unite(&(v150_60),&(v150_62));
  let v150_66: Space = routine_17(c, &(*CONSTANT_70), &(*CONSTANT_17), &(*CONSTANT_69));
  let v150_67: Space = unite(&(v150_63),&(v150_66));
  let v150_70: Space = routine_17(c, &(*CONSTANT_71), &(*CONSTANT_7), &(*CONSTANT_57));
  let v150_71: Space = unite(&(v150_67),&(v150_70));
  let v150_73: Space = routine_17(c, &(*CONSTANT_71), &(*CONSTANT_9), &(*CONSTANT_58));
  let v150_74: Space = unite(&(v150_71),&(v150_73));
  let v150_76: Space = routine_17(c, &(*CONSTANT_71), &(*CONSTANT_11), &(*CONSTANT_59));
  let v150_77: Space = unite(&(v150_74),&(v150_76));
  let v150_79: Space = routine_17(c, &(*CONSTANT_71), &(*CONSTANT_13), &(*CONSTANT_60));
  let v150_80: Space = unite(&(v150_77),&(v150_79));
  let v150_82: Space = routine_17(c, &(*CONSTANT_71), &(*CONSTANT_15), &(*CONSTANT_61));
  let v150_83: Space = unite(&(v150_80),&(v150_82));
  let v150_85: Space = routine_17(c, &(*CONSTANT_71), &(*CONSTANT_17), &(*CONSTANT_62));
  let v150_86: Space = unite(&(v150_83),&(v150_85));
  let v150_87: Space = unwrap(&(v150_86),&(*p1));
  let mut v150_88 = Space::new();
  let mut v150_88_cursor = (v150_87).read_zipper();
  for v150_88_byte in v150_88_cursor.child_mask().iter() {
    v150_88_cursor.descend_to_byte(v150_88_byte);
    let v150_88_tail = v150_88_cursor.make_map();
    v150_88_cursor.ascend(1);
    let v150_88_head = Path::from_slice(&[v150_88_byte]);
    let mut v151_2 = Space::new();
    let mut v151_2_cursor = (v150_88_tail).read_zipper();
    for v151_2_byte in v151_2_cursor.child_mask().iter() {
      v151_2_cursor.descend_to_byte(v151_2_byte);
      let v151_2_tail = v151_2_cursor.make_map();
      v151_2_cursor.ascend(1);
      let v151_2_head = Path::from_slice(&[v151_2_byte]);
      let v152_2: Path = concat_path(&(v150_88_head),&(v151_2_head));
      let mut v152_3 = Space::new();
      let mut v152_3_cursor = (v151_2_tail).read_zipper();
      for v152_3_byte in v152_3_cursor.child_mask().iter() {
        v152_3_cursor.descend_to_byte(v152_3_byte);
        let v152_3_tail = v152_3_cursor.make_map();
        v152_3_cursor.ascend(1);
        let v152_3_head = Path::from_slice(&[v152_3_byte]);
        let v153_2: Path = concat_path(&(v152_2),&(v152_3_head));
        let mut v153_3 = Space::new();
        let mut v153_3_cursor = (v152_3_tail).read_zipper();
        for v153_3_byte in v153_3_cursor.child_mask().iter() {
          v153_3_cursor.descend_to_byte(v153_3_byte);
          let v153_3_tail = v153_3_cursor.make_map();
          v153_3_cursor.ascend(1);
          let v153_3_head = Path::from_slice(&[v153_3_byte]);
          let v154_2: Space = unwrap(&(v153_3_tail),&(*p0));
          let v154_3: Path = concat_path(&(v153_2),&(v153_3_head));
          let v154_4: Space = wrap(&(v154_2),&(v154_3));
          drop(v154_2);
          drop(v154_3);
          let v154_5: Space = compose(&(v154_4),&(*s0));
          drop(v154_4);
          v153_3.join_into((v154_5).clone());
        }
        drop(v153_3_cursor);
        drop(v153_2);
        v152_3.join_into((v153_3).clone());
      }
      drop(v152_3_cursor);
      drop(v152_2);
      v151_2.join_into((v152_3).clone());
    }
    drop(v151_2_cursor);
    v150_88.join_into((v151_2).clone());
  }
  drop(v150_88_cursor);
  (v150_88).clone()
}

fn routine_7(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v155_6: Space = routine_18(c, &(*CONSTANT_56), &(*CONSTANT_1), &(*CONSTANT_57));
  let v155_9: Space = routine_18(c, &(*CONSTANT_56), &(*CONSTANT_3), &(*CONSTANT_58));
  let v155_10: Space = unite(&(v155_6),&(v155_9));
  let v155_13: Space = routine_18(c, &(*CONSTANT_56), &(*CONSTANT_5), &(*CONSTANT_59));
  let v155_14: Space = unite(&(v155_10),&(v155_13));
  let v155_17: Space = routine_18(c, &(*CONSTANT_56), &(*CONSTANT_7), &(*CONSTANT_60));
  let v155_18: Space = unite(&(v155_14),&(v155_17));
  let v155_21: Space = routine_18(c, &(*CONSTANT_56), &(*CONSTANT_9), &(*CONSTANT_61));
  let v155_22: Space = unite(&(v155_18),&(v155_21));
  let v155_25: Space = routine_18(c, &(*CONSTANT_56), &(*CONSTANT_11), &(*CONSTANT_62));
  let v155_26: Space = unite(&(v155_22),&(v155_25));
  let v155_29: Space = routine_18(c, &(*CONSTANT_63), &(*CONSTANT_1), &(*CONSTANT_64));
  let v155_30: Space = unite(&(v155_26),&(v155_29));
  let v155_32: Space = routine_18(c, &(*CONSTANT_63), &(*CONSTANT_3), &(*CONSTANT_65));
  let v155_33: Space = unite(&(v155_30),&(v155_32));
  let v155_35: Space = routine_18(c, &(*CONSTANT_63), &(*CONSTANT_7), &(*CONSTANT_66));
  let v155_36: Space = unite(&(v155_33),&(v155_35));
  let v155_38: Space = routine_18(c, &(*CONSTANT_63), &(*CONSTANT_9), &(*CONSTANT_67));
  let v155_39: Space = unite(&(v155_36),&(v155_38));
  let v155_42: Space = routine_18(c, &(*CONSTANT_63), &(*CONSTANT_13), &(*CONSTANT_68));
  let v155_43: Space = unite(&(v155_39),&(v155_42));
  let v155_46: Space = routine_18(c, &(*CONSTANT_63), &(*CONSTANT_15), &(*CONSTANT_69));
  let v155_47: Space = unite(&(v155_43),&(v155_46));
  let v155_50: Space = routine_18(c, &(*CONSTANT_70), &(*CONSTANT_3), &(*CONSTANT_64));
  let v155_51: Space = unite(&(v155_47),&(v155_50));
  let v155_53: Space = routine_18(c, &(*CONSTANT_70), &(*CONSTANT_5), &(*CONSTANT_65));
  let v155_54: Space = unite(&(v155_51),&(v155_53));
  let v155_56: Space = routine_18(c, &(*CONSTANT_70), &(*CONSTANT_9), &(*CONSTANT_66));
  let v155_57: Space = unite(&(v155_54),&(v155_56));
  let v155_59: Space = routine_18(c, &(*CONSTANT_70), &(*CONSTANT_11), &(*CONSTANT_67));
  let v155_60: Space = unite(&(v155_57),&(v155_59));
  let v155_62: Space = routine_18(c, &(*CONSTANT_70), &(*CONSTANT_15), &(*CONSTANT_68));
  let v155_63: Space = unite(&(v155_60),&(v155_62));
  let v155_66: Space = routine_18(c, &(*CONSTANT_70), &(*CONSTANT_17), &(*CONSTANT_69));
  let v155_67: Space = unite(&(v155_63),&(v155_66));
  let v155_70: Space = routine_18(c, &(*CONSTANT_71), &(*CONSTANT_7), &(*CONSTANT_57));
  let v155_71: Space = unite(&(v155_67),&(v155_70));
  let v155_73: Space = routine_18(c, &(*CONSTANT_71), &(*CONSTANT_9), &(*CONSTANT_58));
  let v155_74: Space = unite(&(v155_71),&(v155_73));
  let v155_76: Space = routine_18(c, &(*CONSTANT_71), &(*CONSTANT_11), &(*CONSTANT_59));
  let v155_77: Space = unite(&(v155_74),&(v155_76));
  let v155_79: Space = routine_18(c, &(*CONSTANT_71), &(*CONSTANT_13), &(*CONSTANT_60));
  let v155_80: Space = unite(&(v155_77),&(v155_79));
  let v155_82: Space = routine_18(c, &(*CONSTANT_71), &(*CONSTANT_15), &(*CONSTANT_61));
  let v155_83: Space = unite(&(v155_80),&(v155_82));
  let v155_85: Space = routine_18(c, &(*CONSTANT_71), &(*CONSTANT_17), &(*CONSTANT_62));
  let v155_86: Space = unite(&(v155_83),&(v155_85));
  let v155_87: Space = unwrap(&(v155_86),&(*p1));
  let v155_88: Space = unwrap(&(v155_87),&(*p0));
  let v155_89: Space = unwrap(&(v155_88),&(*p1));
  let mut v155_90 = Space::new();
  let mut v155_90_cursor = (v155_89).read_zipper();
  for v155_90_byte in v155_90_cursor.child_mask().iter() {
    v155_90_cursor.descend_to_byte(v155_90_byte);
    let v155_90_tail = v155_90_cursor.make_map();
    v155_90_cursor.ascend(1);
    let v155_90_head = Path::from_slice(&[v155_90_byte]);
    let mut v156_2 = Space::new();
    let mut v156_2_cursor = (v155_90_tail).read_zipper();
    for v156_2_byte in v156_2_cursor.child_mask().iter() {
      v156_2_cursor.descend_to_byte(v156_2_byte);
      let v156_2_tail = v156_2_cursor.make_map();
      v156_2_cursor.ascend(1);
      let v156_2_head = Path::from_slice(&[v156_2_byte]);
      let v157_2: Path = concat_path(&(v155_90_head),&(v156_2_head));
      let mut v157_3 = Space::new();
      let mut v157_3_cursor = (v156_2_tail).read_zipper();
      for v157_3_byte in v157_3_cursor.child_mask().iter() {
        v157_3_cursor.descend_to_byte(v157_3_byte);
        let v157_3_tail = v157_3_cursor.make_map();
        v157_3_cursor.ascend(1);
        let v157_3_head = Path::from_slice(&[v157_3_byte]);
        let v158_2: Path = concat_path(&(v157_2),&(v157_3_head));
        let mut v158_3 = Space::new();
        let mut v158_3_cursor = (v157_3_tail).read_zipper();
        for v158_3_byte in v158_3_cursor.child_mask().iter() {
          v158_3_cursor.descend_to_byte(v158_3_byte);
          let v158_3_tail = v158_3_cursor.make_map();
          v158_3_cursor.ascend(1);
          let v158_3_head = Path::from_slice(&[v158_3_byte]);
          let v159_2: Path = concat_path(&(v158_2),&(v158_3_head));
          let v159_3: Space = routine_19(c, &(v159_2), &(*s0));
          drop(v159_2);
          v158_3.join_into((v159_3).clone());
        }
        drop(v158_3_cursor);
        drop(v158_2);
        v157_3.join_into((v158_3).clone());
      }
      drop(v157_3_cursor);
      drop(v157_2);
      v156_2.join_into((v157_3).clone());
    }
    drop(v156_2_cursor);
    v155_90.join_into((v156_2).clone());
  }
  drop(v155_90_cursor);
  (v155_90).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v160_3 = Space::new();
  let mut v160_3_cursor = (*s0).read_zipper();
  for v160_3_byte in v160_3_cursor.child_mask().iter() {
    v160_3_cursor.descend_to_byte(v160_3_byte);
    let v160_3_tail = v160_3_cursor.make_map();
    v160_3_cursor.ascend(1);
    let v160_3_head = Path::from_slice(&[v160_3_byte]);
    let mut v161_2 = Space::new();
    let mut v161_2_cursor = (v160_3_tail).read_zipper();
    for v161_2_byte in v161_2_cursor.child_mask().iter() {
      v161_2_cursor.descend_to_byte(v161_2_byte);
      let v161_2_tail = v161_2_cursor.make_map();
      v161_2_cursor.ascend(1);
      let v161_2_head = Path::from_slice(&[v161_2_byte]);
      let v162_2: Path = concat_path(&(v160_3_head),&(v161_2_head));
      let mut v162_3 = Space::new();
      let mut v162_3_cursor = (v161_2_tail).read_zipper();
      for v162_3_byte in v162_3_cursor.child_mask().iter() {
        v162_3_cursor.descend_to_byte(v162_3_byte);
        let v162_3_tail = v162_3_cursor.make_map();
        v162_3_cursor.ascend(1);
        let v162_3_head = Path::from_slice(&[v162_3_byte]);
        let v163_2: Path = concat_path(&(v162_2),&(v162_3_head));
        let mut v163_3 = Space::new();
        let mut v163_3_cursor = (v162_3_tail).read_zipper();
        for v163_3_byte in v163_3_cursor.child_mask().iter() {
          v163_3_cursor.descend_to_byte(v163_3_byte);
          let v163_3_tail = v163_3_cursor.make_map();
          v163_3_cursor.ascend(1);
          let v163_3_head = Path::from_slice(&[v163_3_byte]);
          let v164_2: Path = concat_path(&(v163_2),&(v163_3_head));
          let mut v164_3 = Space::new();
          let mut v164_3_cursor = (v163_3_tail).read_zipper();
          for v164_3_byte in v164_3_cursor.child_mask().iter() {
            v164_3_cursor.descend_to_byte(v164_3_byte);
            let v164_3_tail = v164_3_cursor.make_map();
            v164_3_cursor.ascend(1);
            let v164_3_head = Path::from_slice(&[v164_3_byte]);
            let mut v165_2 = Space::new();
            let mut v165_2_cursor = (v164_3_tail).read_zipper();
            for v165_2_byte in v165_2_cursor.child_mask().iter() {
              v165_2_cursor.descend_to_byte(v165_2_byte);
              let v165_2_tail = v165_2_cursor.make_map();
              v165_2_cursor.ascend(1);
              let v165_2_head = Path::from_slice(&[v165_2_byte]);
              let v166_2: Path = concat_path(&(v164_3_head),&(v165_2_head));
              let mut v166_3 = Space::new();
              let mut v166_3_cursor = (v165_2_tail).read_zipper();
              for v166_3_byte in v166_3_cursor.child_mask().iter() {
                v166_3_cursor.descend_to_byte(v166_3_byte);
                let v166_3_tail = v166_3_cursor.make_map();
                v166_3_cursor.ascend(1);
                let v166_3_head = Path::from_slice(&[v166_3_byte]);
                let v167_2: Path = concat_path(&(v166_2),&(v166_3_head));
                let mut v167_3 = Space::new();
                let mut v167_3_cursor = (v166_3_tail).read_zipper();
                for v167_3_byte in v167_3_cursor.child_mask().iter() {
                  v167_3_cursor.descend_to_byte(v167_3_byte);
                  let v167_3_tail = v167_3_cursor.make_map();
                  v167_3_cursor.ascend(1);
                  let v167_3_head = Path::from_slice(&[v167_3_byte]);
                  let v168_2: Path = concat_path(&(v167_2),&(v167_3_head));
                  let v168_3: Space = routine_20(c, &(v168_2), &(*p1), &(*p0), &(v164_2), &(v167_3_tail));
                  drop(v168_2);
                  v167_3.join_into((v168_3).clone());
                }
                drop(v167_3_cursor);
                drop(v167_2);
                v166_3.join_into((v167_3).clone());
              }
              drop(v166_3_cursor);
              drop(v166_2);
              v165_2.join_into((v166_3).clone());
            }
            drop(v165_2_cursor);
            v164_3.join_into((v165_2).clone());
          }
          drop(v164_3_cursor);
          drop(v164_2);
          v163_3.join_into((v164_3).clone());
        }
        drop(v163_3_cursor);
        drop(v163_2);
        v162_3.join_into((v163_3).clone());
      }
      drop(v162_3_cursor);
      drop(v162_2);
      v161_2.join_into((v162_3).clone());
    }
    drop(v161_2_cursor);
    v160_3.join_into((v161_2).clone());
  }
  drop(v160_3_cursor);
  (v160_3).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v169_3 = Space::new();
  let mut v169_3_cursor = (*s0).read_zipper();
  for v169_3_byte in v169_3_cursor.child_mask().iter() {
    v169_3_cursor.descend_to_byte(v169_3_byte);
    let v169_3_tail = v169_3_cursor.make_map();
    v169_3_cursor.ascend(1);
    let v169_3_head = Path::from_slice(&[v169_3_byte]);
    let mut v170_2 = Space::new();
    let mut v170_2_cursor = (v169_3_tail).read_zipper();
    for v170_2_byte in v170_2_cursor.child_mask().iter() {
      v170_2_cursor.descend_to_byte(v170_2_byte);
      let v170_2_tail = v170_2_cursor.make_map();
      v170_2_cursor.ascend(1);
      let v170_2_head = Path::from_slice(&[v170_2_byte]);
      let v171_2: Path = concat_path(&(v169_3_head),&(v170_2_head));
      let mut v171_3 = Space::new();
      let mut v171_3_cursor = (v170_2_tail).read_zipper();
      for v171_3_byte in v171_3_cursor.child_mask().iter() {
        v171_3_cursor.descend_to_byte(v171_3_byte);
        let v171_3_tail = v171_3_cursor.make_map();
        v171_3_cursor.ascend(1);
        let v171_3_head = Path::from_slice(&[v171_3_byte]);
        let v172_2: Path = concat_path(&(v171_2),&(v171_3_head));
        let mut v172_3 = Space::new();
        let mut v172_3_cursor = (v171_3_tail).read_zipper();
        for v172_3_byte in v172_3_cursor.child_mask().iter() {
          v172_3_cursor.descend_to_byte(v172_3_byte);
          let v172_3_tail = v172_3_cursor.make_map();
          v172_3_cursor.ascend(1);
          let v172_3_head = Path::from_slice(&[v172_3_byte]);
          let v173_2: Path = concat_path(&(v172_2),&(v172_3_head));
          let mut v173_3 = Space::new();
          let mut v173_3_cursor = (v172_3_tail).read_zipper();
          for v173_3_byte in v173_3_cursor.child_mask().iter() {
            v173_3_cursor.descend_to_byte(v173_3_byte);
            let v173_3_tail = v173_3_cursor.make_map();
            v173_3_cursor.ascend(1);
            let v173_3_head = Path::from_slice(&[v173_3_byte]);
            let mut v174_2 = Space::new();
            let mut v174_2_cursor = (v173_3_tail).read_zipper();
            for v174_2_byte in v174_2_cursor.child_mask().iter() {
              v174_2_cursor.descend_to_byte(v174_2_byte);
              let v174_2_tail = v174_2_cursor.make_map();
              v174_2_cursor.ascend(1);
              let v174_2_head = Path::from_slice(&[v174_2_byte]);
              let v175_2: Path = concat_path(&(v173_3_head),&(v174_2_head));
              let mut v175_3 = Space::new();
              let mut v175_3_cursor = (v174_2_tail).read_zipper();
              for v175_3_byte in v175_3_cursor.child_mask().iter() {
                v175_3_cursor.descend_to_byte(v175_3_byte);
                let v175_3_tail = v175_3_cursor.make_map();
                v175_3_cursor.ascend(1);
                let v175_3_head = Path::from_slice(&[v175_3_byte]);
                let v176_2: Path = concat_path(&(v175_2),&(v175_3_head));
                let mut v176_3 = Space::new();
                let mut v176_3_cursor = (v175_3_tail).read_zipper();
                for v176_3_byte in v176_3_cursor.child_mask().iter() {
                  v176_3_cursor.descend_to_byte(v176_3_byte);
                  let v176_3_tail = v176_3_cursor.make_map();
                  v176_3_cursor.ascend(1);
                  let v176_3_head = Path::from_slice(&[v176_3_byte]);
                  let v177_2: Path = concat_path(&(v176_2),&(v176_3_head));
                  let v177_3: Space = routine_21(c, &(v177_2), &(*p1), &(*p0), &(v173_2), &(v176_3_tail));
                  drop(v177_2);
                  v176_3.join_into((v177_3).clone());
                }
                drop(v176_3_cursor);
                drop(v176_2);
                v175_3.join_into((v176_3).clone());
              }
              drop(v175_3_cursor);
              drop(v175_2);
              v174_2.join_into((v175_3).clone());
            }
            drop(v174_2_cursor);
            v173_3.join_into((v174_2).clone());
          }
          drop(v173_3_cursor);
          drop(v173_2);
          v172_3.join_into((v173_3).clone());
        }
        drop(v172_3_cursor);
        drop(v172_2);
        v171_3.join_into((v172_3).clone());
      }
      drop(v171_3_cursor);
      drop(v171_2);
      v170_2.join_into((v171_3).clone());
    }
    drop(v170_2_cursor);
    v169_3.join_into((v170_2).clone());
  }
  drop(v169_3_cursor);
  (v169_3).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v178_3 = Space::new();
  let mut v178_3_cursor = (*s0).read_zipper();
  for v178_3_byte in v178_3_cursor.child_mask().iter() {
    v178_3_cursor.descend_to_byte(v178_3_byte);
    let v178_3_tail = v178_3_cursor.make_map();
    v178_3_cursor.ascend(1);
    let v178_3_head = Path::from_slice(&[v178_3_byte]);
    let mut v179_2 = Space::new();
    let mut v179_2_cursor = (v178_3_tail).read_zipper();
    for v179_2_byte in v179_2_cursor.child_mask().iter() {
      v179_2_cursor.descend_to_byte(v179_2_byte);
      let v179_2_tail = v179_2_cursor.make_map();
      v179_2_cursor.ascend(1);
      let v179_2_head = Path::from_slice(&[v179_2_byte]);
      let v180_2: Path = concat_path(&(v178_3_head),&(v179_2_head));
      let mut v180_3 = Space::new();
      let mut v180_3_cursor = (v179_2_tail).read_zipper();
      for v180_3_byte in v180_3_cursor.child_mask().iter() {
        v180_3_cursor.descend_to_byte(v180_3_byte);
        let v180_3_tail = v180_3_cursor.make_map();
        v180_3_cursor.ascend(1);
        let v180_3_head = Path::from_slice(&[v180_3_byte]);
        let v181_2: Path = concat_path(&(v180_2),&(v180_3_head));
        let mut v181_3 = Space::new();
        let mut v181_3_cursor = (v180_3_tail).read_zipper();
        for v181_3_byte in v181_3_cursor.child_mask().iter() {
          v181_3_cursor.descend_to_byte(v181_3_byte);
          let v181_3_tail = v181_3_cursor.make_map();
          v181_3_cursor.ascend(1);
          let v181_3_head = Path::from_slice(&[v181_3_byte]);
          let v182_2: Path = concat_path(&(v181_2),&(v181_3_head));
          let mut v182_3 = Space::new();
          let mut v182_3_cursor = (v181_3_tail).read_zipper();
          for v182_3_byte in v182_3_cursor.child_mask().iter() {
            v182_3_cursor.descend_to_byte(v182_3_byte);
            let v182_3_tail = v182_3_cursor.make_map();
            v182_3_cursor.ascend(1);
            let v182_3_head = Path::from_slice(&[v182_3_byte]);
            let mut v183_2 = Space::new();
            let mut v183_2_cursor = (v182_3_tail).read_zipper();
            for v183_2_byte in v183_2_cursor.child_mask().iter() {
              v183_2_cursor.descend_to_byte(v183_2_byte);
              let v183_2_tail = v183_2_cursor.make_map();
              v183_2_cursor.ascend(1);
              let v183_2_head = Path::from_slice(&[v183_2_byte]);
              let v184_2: Path = concat_path(&(v182_3_head),&(v183_2_head));
              let mut v184_3 = Space::new();
              let mut v184_3_cursor = (v183_2_tail).read_zipper();
              for v184_3_byte in v184_3_cursor.child_mask().iter() {
                v184_3_cursor.descend_to_byte(v184_3_byte);
                let v184_3_tail = v184_3_cursor.make_map();
                v184_3_cursor.ascend(1);
                let v184_3_head = Path::from_slice(&[v184_3_byte]);
                let v185_2: Path = concat_path(&(v184_2),&(v184_3_head));
                let mut v185_3 = Space::new();
                let mut v185_3_cursor = (v184_3_tail).read_zipper();
                for v185_3_byte in v185_3_cursor.child_mask().iter() {
                  v185_3_cursor.descend_to_byte(v185_3_byte);
                  let v185_3_tail = v185_3_cursor.make_map();
                  v185_3_cursor.ascend(1);
                  let v185_3_head = Path::from_slice(&[v185_3_byte]);
                  let v186_2: Path = concat_path(&(v185_2),&(v185_3_head));
                  let v186_3: Space = routine_22(c, &(v186_2), &(*p1), &(*p0), &(v182_2), &(v185_3_tail));
                  drop(v186_2);
                  v185_3.join_into((v186_3).clone());
                }
                drop(v185_3_cursor);
                drop(v185_2);
                v184_3.join_into((v185_3).clone());
              }
              drop(v184_3_cursor);
              drop(v184_2);
              v183_2.join_into((v184_3).clone());
            }
            drop(v183_2_cursor);
            v182_3.join_into((v183_2).clone());
          }
          drop(v182_3_cursor);
          drop(v182_2);
          v181_3.join_into((v182_3).clone());
        }
        drop(v181_3_cursor);
        drop(v181_2);
        v180_3.join_into((v181_3).clone());
      }
      drop(v180_3_cursor);
      drop(v180_2);
      v179_2.join_into((v180_3).clone());
    }
    drop(v179_2_cursor);
    v178_3.join_into((v179_2).clone());
  }
  drop(v178_3_cursor);
  (v178_3).clone()
}

fn routine_11(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v187_3 = Space::new();
  let mut v187_3_cursor = (*s0).read_zipper();
  for v187_3_byte in v187_3_cursor.child_mask().iter() {
    v187_3_cursor.descend_to_byte(v187_3_byte);
    let v187_3_tail = v187_3_cursor.make_map();
    v187_3_cursor.ascend(1);
    let v187_3_head = Path::from_slice(&[v187_3_byte]);
    let mut v188_2 = Space::new();
    let mut v188_2_cursor = (v187_3_tail).read_zipper();
    for v188_2_byte in v188_2_cursor.child_mask().iter() {
      v188_2_cursor.descend_to_byte(v188_2_byte);
      let v188_2_tail = v188_2_cursor.make_map();
      v188_2_cursor.ascend(1);
      let v188_2_head = Path::from_slice(&[v188_2_byte]);
      let v189_2: Path = concat_path(&(v187_3_head),&(v188_2_head));
      let mut v189_3 = Space::new();
      let mut v189_3_cursor = (v188_2_tail).read_zipper();
      for v189_3_byte in v189_3_cursor.child_mask().iter() {
        v189_3_cursor.descend_to_byte(v189_3_byte);
        let v189_3_tail = v189_3_cursor.make_map();
        v189_3_cursor.ascend(1);
        let v189_3_head = Path::from_slice(&[v189_3_byte]);
        let v190_2: Path = concat_path(&(v189_2),&(v189_3_head));
        let mut v190_3 = Space::new();
        let mut v190_3_cursor = (v189_3_tail).read_zipper();
        for v190_3_byte in v190_3_cursor.child_mask().iter() {
          v190_3_cursor.descend_to_byte(v190_3_byte);
          let v190_3_tail = v190_3_cursor.make_map();
          v190_3_cursor.ascend(1);
          let v190_3_head = Path::from_slice(&[v190_3_byte]);
          let v191_2: Path = concat_path(&(v190_2),&(v190_3_head));
          let mut v191_3 = Space::new();
          let mut v191_3_cursor = (v190_3_tail).read_zipper();
          for v191_3_byte in v191_3_cursor.child_mask().iter() {
            v191_3_cursor.descend_to_byte(v191_3_byte);
            let v191_3_tail = v191_3_cursor.make_map();
            v191_3_cursor.ascend(1);
            let v191_3_head = Path::from_slice(&[v191_3_byte]);
            let mut v192_2 = Space::new();
            let mut v192_2_cursor = (v191_3_tail).read_zipper();
            for v192_2_byte in v192_2_cursor.child_mask().iter() {
              v192_2_cursor.descend_to_byte(v192_2_byte);
              let v192_2_tail = v192_2_cursor.make_map();
              v192_2_cursor.ascend(1);
              let v192_2_head = Path::from_slice(&[v192_2_byte]);
              let v193_2: Path = concat_path(&(v191_3_head),&(v192_2_head));
              let mut v193_3 = Space::new();
              let mut v193_3_cursor = (v192_2_tail).read_zipper();
              for v193_3_byte in v193_3_cursor.child_mask().iter() {
                v193_3_cursor.descend_to_byte(v193_3_byte);
                let v193_3_tail = v193_3_cursor.make_map();
                v193_3_cursor.ascend(1);
                let v193_3_head = Path::from_slice(&[v193_3_byte]);
                let v194_2: Path = concat_path(&(v193_2),&(v193_3_head));
                let mut v194_3 = Space::new();
                let mut v194_3_cursor = (v193_3_tail).read_zipper();
                for v194_3_byte in v194_3_cursor.child_mask().iter() {
                  v194_3_cursor.descend_to_byte(v194_3_byte);
                  let v194_3_tail = v194_3_cursor.make_map();
                  v194_3_cursor.ascend(1);
                  let v194_3_head = Path::from_slice(&[v194_3_byte]);
                  let v195_2: Path = concat_path(&(v194_2),&(v194_3_head));
                  let v195_3: Space = routine_23(c, &(v195_2), &(*p1), &(*p0), &(v191_2), &(v194_3_tail));
                  drop(v195_2);
                  v194_3.join_into((v195_3).clone());
                }
                drop(v194_3_cursor);
                drop(v194_2);
                v193_3.join_into((v194_3).clone());
              }
              drop(v193_3_cursor);
              drop(v193_2);
              v192_2.join_into((v193_3).clone());
            }
            drop(v192_2_cursor);
            v191_3.join_into((v192_2).clone());
          }
          drop(v191_3_cursor);
          drop(v191_2);
          v190_3.join_into((v191_3).clone());
        }
        drop(v190_3_cursor);
        drop(v190_2);
        v189_3.join_into((v190_3).clone());
      }
      drop(v189_3_cursor);
      drop(v189_2);
      v188_2.join_into((v189_3).clone());
    }
    drop(v188_2_cursor);
    v187_3.join_into((v188_2).clone());
  }
  drop(v187_3_cursor);
  (v187_3).clone()
}

fn routine_12(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v196_3 = Space::new();
  let mut v196_3_cursor = (*s0).read_zipper();
  for v196_3_byte in v196_3_cursor.child_mask().iter() {
    v196_3_cursor.descend_to_byte(v196_3_byte);
    let v196_3_tail = v196_3_cursor.make_map();
    v196_3_cursor.ascend(1);
    let v196_3_head = Path::from_slice(&[v196_3_byte]);
    let mut v197_2 = Space::new();
    let mut v197_2_cursor = (v196_3_tail).read_zipper();
    for v197_2_byte in v197_2_cursor.child_mask().iter() {
      v197_2_cursor.descend_to_byte(v197_2_byte);
      let v197_2_tail = v197_2_cursor.make_map();
      v197_2_cursor.ascend(1);
      let v197_2_head = Path::from_slice(&[v197_2_byte]);
      let v198_2: Path = concat_path(&(v196_3_head),&(v197_2_head));
      let mut v198_3 = Space::new();
      let mut v198_3_cursor = (v197_2_tail).read_zipper();
      for v198_3_byte in v198_3_cursor.child_mask().iter() {
        v198_3_cursor.descend_to_byte(v198_3_byte);
        let v198_3_tail = v198_3_cursor.make_map();
        v198_3_cursor.ascend(1);
        let v198_3_head = Path::from_slice(&[v198_3_byte]);
        let v199_2: Path = concat_path(&(v198_2),&(v198_3_head));
        let mut v199_3 = Space::new();
        let mut v199_3_cursor = (v198_3_tail).read_zipper();
        for v199_3_byte in v199_3_cursor.child_mask().iter() {
          v199_3_cursor.descend_to_byte(v199_3_byte);
          let v199_3_tail = v199_3_cursor.make_map();
          v199_3_cursor.ascend(1);
          let v199_3_head = Path::from_slice(&[v199_3_byte]);
          let v200_2: Path = concat_path(&(v199_2),&(v199_3_head));
          let mut v200_3 = Space::new();
          let mut v200_3_cursor = (v199_3_tail).read_zipper();
          for v200_3_byte in v200_3_cursor.child_mask().iter() {
            v200_3_cursor.descend_to_byte(v200_3_byte);
            let v200_3_tail = v200_3_cursor.make_map();
            v200_3_cursor.ascend(1);
            let v200_3_head = Path::from_slice(&[v200_3_byte]);
            let mut v201_2 = Space::new();
            let mut v201_2_cursor = (v200_3_tail).read_zipper();
            for v201_2_byte in v201_2_cursor.child_mask().iter() {
              v201_2_cursor.descend_to_byte(v201_2_byte);
              let v201_2_tail = v201_2_cursor.make_map();
              v201_2_cursor.ascend(1);
              let v201_2_head = Path::from_slice(&[v201_2_byte]);
              let v202_2: Path = concat_path(&(v200_3_head),&(v201_2_head));
              let mut v202_3 = Space::new();
              let mut v202_3_cursor = (v201_2_tail).read_zipper();
              for v202_3_byte in v202_3_cursor.child_mask().iter() {
                v202_3_cursor.descend_to_byte(v202_3_byte);
                let v202_3_tail = v202_3_cursor.make_map();
                v202_3_cursor.ascend(1);
                let v202_3_head = Path::from_slice(&[v202_3_byte]);
                let v203_2: Path = concat_path(&(v202_2),&(v202_3_head));
                let mut v203_3 = Space::new();
                let mut v203_3_cursor = (v202_3_tail).read_zipper();
                for v203_3_byte in v203_3_cursor.child_mask().iter() {
                  v203_3_cursor.descend_to_byte(v203_3_byte);
                  let v203_3_tail = v203_3_cursor.make_map();
                  v203_3_cursor.ascend(1);
                  let v203_3_head = Path::from_slice(&[v203_3_byte]);
                  let v204_2: Path = concat_path(&(v203_2),&(v203_3_head));
                  let v204_3: Space = routine_24(c, &(v204_2), &(*p1), &(*p0), &(v200_2), &(v203_3_tail));
                  drop(v204_2);
                  v203_3.join_into((v204_3).clone());
                }
                drop(v203_3_cursor);
                drop(v203_2);
                v202_3.join_into((v203_3).clone());
              }
              drop(v202_3_cursor);
              drop(v202_2);
              v201_2.join_into((v202_3).clone());
            }
            drop(v201_2_cursor);
            v200_3.join_into((v201_2).clone());
          }
          drop(v200_3_cursor);
          drop(v200_2);
          v199_3.join_into((v200_3).clone());
        }
        drop(v199_3_cursor);
        drop(v199_2);
        v198_3.join_into((v199_3).clone());
      }
      drop(v198_3_cursor);
      drop(v198_2);
      v197_2.join_into((v198_3).clone());
    }
    drop(v197_2_cursor);
    v196_3.join_into((v197_2).clone());
  }
  drop(v196_3_cursor);
  (v196_3).clone()
}

fn routine_13(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v205_3 = Space::new();
  let mut v205_3_cursor = (*s0).read_zipper();
  for v205_3_byte in v205_3_cursor.child_mask().iter() {
    v205_3_cursor.descend_to_byte(v205_3_byte);
    let v205_3_tail = v205_3_cursor.make_map();
    v205_3_cursor.ascend(1);
    let v205_3_head = Path::from_slice(&[v205_3_byte]);
    let mut v206_2 = Space::new();
    let mut v206_2_cursor = (v205_3_tail).read_zipper();
    for v206_2_byte in v206_2_cursor.child_mask().iter() {
      v206_2_cursor.descend_to_byte(v206_2_byte);
      let v206_2_tail = v206_2_cursor.make_map();
      v206_2_cursor.ascend(1);
      let v206_2_head = Path::from_slice(&[v206_2_byte]);
      let v207_2: Path = concat_path(&(v205_3_head),&(v206_2_head));
      let mut v207_3 = Space::new();
      let mut v207_3_cursor = (v206_2_tail).read_zipper();
      for v207_3_byte in v207_3_cursor.child_mask().iter() {
        v207_3_cursor.descend_to_byte(v207_3_byte);
        let v207_3_tail = v207_3_cursor.make_map();
        v207_3_cursor.ascend(1);
        let v207_3_head = Path::from_slice(&[v207_3_byte]);
        let v208_2: Path = concat_path(&(v207_2),&(v207_3_head));
        let mut v208_3 = Space::new();
        let mut v208_3_cursor = (v207_3_tail).read_zipper();
        for v208_3_byte in v208_3_cursor.child_mask().iter() {
          v208_3_cursor.descend_to_byte(v208_3_byte);
          let v208_3_tail = v208_3_cursor.make_map();
          v208_3_cursor.ascend(1);
          let v208_3_head = Path::from_slice(&[v208_3_byte]);
          let v209_2: Path = concat_path(&(v208_2),&(v208_3_head));
          let mut v209_3 = Space::new();
          let mut v209_3_cursor = (v208_3_tail).read_zipper();
          for v209_3_byte in v209_3_cursor.child_mask().iter() {
            v209_3_cursor.descend_to_byte(v209_3_byte);
            let v209_3_tail = v209_3_cursor.make_map();
            v209_3_cursor.ascend(1);
            let v209_3_head = Path::from_slice(&[v209_3_byte]);
            let mut v210_2 = Space::new();
            let mut v210_2_cursor = (v209_3_tail).read_zipper();
            for v210_2_byte in v210_2_cursor.child_mask().iter() {
              v210_2_cursor.descend_to_byte(v210_2_byte);
              let v210_2_tail = v210_2_cursor.make_map();
              v210_2_cursor.ascend(1);
              let v210_2_head = Path::from_slice(&[v210_2_byte]);
              let v211_2: Path = concat_path(&(v209_3_head),&(v210_2_head));
              let mut v211_3 = Space::new();
              let mut v211_3_cursor = (v210_2_tail).read_zipper();
              for v211_3_byte in v211_3_cursor.child_mask().iter() {
                v211_3_cursor.descend_to_byte(v211_3_byte);
                let v211_3_tail = v211_3_cursor.make_map();
                v211_3_cursor.ascend(1);
                let v211_3_head = Path::from_slice(&[v211_3_byte]);
                let v212_2: Path = concat_path(&(v211_2),&(v211_3_head));
                let mut v212_3 = Space::new();
                let mut v212_3_cursor = (v211_3_tail).read_zipper();
                for v212_3_byte in v212_3_cursor.child_mask().iter() {
                  v212_3_cursor.descend_to_byte(v212_3_byte);
                  let v212_3_tail = v212_3_cursor.make_map();
                  v212_3_cursor.ascend(1);
                  let v212_3_head = Path::from_slice(&[v212_3_byte]);
                  let v213_2: Path = concat_path(&(v212_2),&(v212_3_head));
                  let v213_3: Space = routine_25(c, &(v213_2), &(*p1), &(*p0), &(v209_2), &(v212_3_tail));
                  drop(v213_2);
                  v212_3.join_into((v213_3).clone());
                }
                drop(v212_3_cursor);
                drop(v212_2);
                v211_3.join_into((v212_3).clone());
              }
              drop(v211_3_cursor);
              drop(v211_2);
              v210_2.join_into((v211_3).clone());
            }
            drop(v210_2_cursor);
            v209_3.join_into((v210_2).clone());
          }
          drop(v209_3_cursor);
          drop(v209_2);
          v208_3.join_into((v209_3).clone());
        }
        drop(v208_3_cursor);
        drop(v208_2);
        v207_3.join_into((v208_3).clone());
      }
      drop(v207_3_cursor);
      drop(v207_2);
      v206_2.join_into((v207_3).clone());
    }
    drop(v206_2_cursor);
    v205_3.join_into((v206_2).clone());
  }
  drop(v205_3_cursor);
  (v205_3).clone()
}

fn routine_14(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v214_3 = Space::new();
  let mut v214_3_cursor = (*s0).read_zipper();
  for v214_3_byte in v214_3_cursor.child_mask().iter() {
    v214_3_cursor.descend_to_byte(v214_3_byte);
    let v214_3_tail = v214_3_cursor.make_map();
    v214_3_cursor.ascend(1);
    let v214_3_head = Path::from_slice(&[v214_3_byte]);
    let mut v215_2 = Space::new();
    let mut v215_2_cursor = (v214_3_tail).read_zipper();
    for v215_2_byte in v215_2_cursor.child_mask().iter() {
      v215_2_cursor.descend_to_byte(v215_2_byte);
      let v215_2_tail = v215_2_cursor.make_map();
      v215_2_cursor.ascend(1);
      let v215_2_head = Path::from_slice(&[v215_2_byte]);
      let v216_2: Path = concat_path(&(v214_3_head),&(v215_2_head));
      let mut v216_3 = Space::new();
      let mut v216_3_cursor = (v215_2_tail).read_zipper();
      for v216_3_byte in v216_3_cursor.child_mask().iter() {
        v216_3_cursor.descend_to_byte(v216_3_byte);
        let v216_3_tail = v216_3_cursor.make_map();
        v216_3_cursor.ascend(1);
        let v216_3_head = Path::from_slice(&[v216_3_byte]);
        let v217_2: Path = concat_path(&(v216_2),&(v216_3_head));
        let mut v217_3 = Space::new();
        let mut v217_3_cursor = (v216_3_tail).read_zipper();
        for v217_3_byte in v217_3_cursor.child_mask().iter() {
          v217_3_cursor.descend_to_byte(v217_3_byte);
          let v217_3_tail = v217_3_cursor.make_map();
          v217_3_cursor.ascend(1);
          let v217_3_head = Path::from_slice(&[v217_3_byte]);
          let v218_2: Path = concat_path(&(v217_2),&(v217_3_head));
          let mut v218_3 = Space::new();
          let mut v218_3_cursor = (v217_3_tail).read_zipper();
          for v218_3_byte in v218_3_cursor.child_mask().iter() {
            v218_3_cursor.descend_to_byte(v218_3_byte);
            let v218_3_tail = v218_3_cursor.make_map();
            v218_3_cursor.ascend(1);
            let v218_3_head = Path::from_slice(&[v218_3_byte]);
            let mut v219_2 = Space::new();
            let mut v219_2_cursor = (v218_3_tail).read_zipper();
            for v219_2_byte in v219_2_cursor.child_mask().iter() {
              v219_2_cursor.descend_to_byte(v219_2_byte);
              let v219_2_tail = v219_2_cursor.make_map();
              v219_2_cursor.ascend(1);
              let v219_2_head = Path::from_slice(&[v219_2_byte]);
              let v220_2: Path = concat_path(&(v218_3_head),&(v219_2_head));
              let mut v220_3 = Space::new();
              let mut v220_3_cursor = (v219_2_tail).read_zipper();
              for v220_3_byte in v220_3_cursor.child_mask().iter() {
                v220_3_cursor.descend_to_byte(v220_3_byte);
                let v220_3_tail = v220_3_cursor.make_map();
                v220_3_cursor.ascend(1);
                let v220_3_head = Path::from_slice(&[v220_3_byte]);
                let v221_2: Path = concat_path(&(v220_2),&(v220_3_head));
                let mut v221_3 = Space::new();
                let mut v221_3_cursor = (v220_3_tail).read_zipper();
                for v221_3_byte in v221_3_cursor.child_mask().iter() {
                  v221_3_cursor.descend_to_byte(v221_3_byte);
                  let v221_3_tail = v221_3_cursor.make_map();
                  v221_3_cursor.ascend(1);
                  let v221_3_head = Path::from_slice(&[v221_3_byte]);
                  let v222_2: Path = concat_path(&(v221_2),&(v221_3_head));
                  let v222_3: Space = routine_26(c, &(v222_2), &(*p1), &(*p0), &(v218_2), &(v221_3_tail));
                  drop(v222_2);
                  v221_3.join_into((v222_3).clone());
                }
                drop(v221_3_cursor);
                drop(v221_2);
                v220_3.join_into((v221_3).clone());
              }
              drop(v220_3_cursor);
              drop(v220_2);
              v219_2.join_into((v220_3).clone());
            }
            drop(v219_2_cursor);
            v218_3.join_into((v219_2).clone());
          }
          drop(v218_3_cursor);
          drop(v218_2);
          v217_3.join_into((v218_3).clone());
        }
        drop(v217_3_cursor);
        drop(v217_2);
        v216_3.join_into((v217_3).clone());
      }
      drop(v216_3_cursor);
      drop(v216_2);
      v215_2.join_into((v216_3).clone());
    }
    drop(v215_2_cursor);
    v214_3.join_into((v215_2).clone());
  }
  drop(v214_3_cursor);
  (v214_3).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v223_3 = Space::new();
  let mut v223_3_cursor = (*s0).read_zipper();
  for v223_3_byte in v223_3_cursor.child_mask().iter() {
    v223_3_cursor.descend_to_byte(v223_3_byte);
    let v223_3_tail = v223_3_cursor.make_map();
    v223_3_cursor.ascend(1);
    let v223_3_head = Path::from_slice(&[v223_3_byte]);
    let mut v224_2 = Space::new();
    let mut v224_2_cursor = (v223_3_tail).read_zipper();
    for v224_2_byte in v224_2_cursor.child_mask().iter() {
      v224_2_cursor.descend_to_byte(v224_2_byte);
      let v224_2_tail = v224_2_cursor.make_map();
      v224_2_cursor.ascend(1);
      let v224_2_head = Path::from_slice(&[v224_2_byte]);
      let v225_2: Path = concat_path(&(v223_3_head),&(v224_2_head));
      let mut v225_3 = Space::new();
      let mut v225_3_cursor = (v224_2_tail).read_zipper();
      for v225_3_byte in v225_3_cursor.child_mask().iter() {
        v225_3_cursor.descend_to_byte(v225_3_byte);
        let v225_3_tail = v225_3_cursor.make_map();
        v225_3_cursor.ascend(1);
        let v225_3_head = Path::from_slice(&[v225_3_byte]);
        let v226_2: Path = concat_path(&(v225_2),&(v225_3_head));
        let mut v226_3 = Space::new();
        let mut v226_3_cursor = (v225_3_tail).read_zipper();
        for v226_3_byte in v226_3_cursor.child_mask().iter() {
          v226_3_cursor.descend_to_byte(v226_3_byte);
          let v226_3_tail = v226_3_cursor.make_map();
          v226_3_cursor.ascend(1);
          let v226_3_head = Path::from_slice(&[v226_3_byte]);
          let v227_2: Path = concat_path(&(v226_2),&(v226_3_head));
          let mut v227_3 = Space::new();
          let mut v227_3_cursor = (v226_3_tail).read_zipper();
          for v227_3_byte in v227_3_cursor.child_mask().iter() {
            v227_3_cursor.descend_to_byte(v227_3_byte);
            let v227_3_tail = v227_3_cursor.make_map();
            v227_3_cursor.ascend(1);
            let v227_3_head = Path::from_slice(&[v227_3_byte]);
            let mut v228_2 = Space::new();
            let mut v228_2_cursor = (v227_3_tail).read_zipper();
            for v228_2_byte in v228_2_cursor.child_mask().iter() {
              v228_2_cursor.descend_to_byte(v228_2_byte);
              let v228_2_tail = v228_2_cursor.make_map();
              v228_2_cursor.ascend(1);
              let v228_2_head = Path::from_slice(&[v228_2_byte]);
              let v229_2: Path = concat_path(&(v227_3_head),&(v228_2_head));
              let mut v229_3 = Space::new();
              let mut v229_3_cursor = (v228_2_tail).read_zipper();
              for v229_3_byte in v229_3_cursor.child_mask().iter() {
                v229_3_cursor.descend_to_byte(v229_3_byte);
                let v229_3_tail = v229_3_cursor.make_map();
                v229_3_cursor.ascend(1);
                let v229_3_head = Path::from_slice(&[v229_3_byte]);
                let v230_2: Path = concat_path(&(v229_2),&(v229_3_head));
                let mut v230_3 = Space::new();
                let mut v230_3_cursor = (v229_3_tail).read_zipper();
                for v230_3_byte in v230_3_cursor.child_mask().iter() {
                  v230_3_cursor.descend_to_byte(v230_3_byte);
                  let v230_3_tail = v230_3_cursor.make_map();
                  v230_3_cursor.ascend(1);
                  let v230_3_head = Path::from_slice(&[v230_3_byte]);
                  let v231_2: Path = concat_path(&(v230_2),&(v230_3_head));
                  let v231_3: Space = routine_27(c, &(v231_2), &(*p1), &(*p0), &(v227_2), &(v230_3_tail));
                  drop(v231_2);
                  v230_3.join_into((v231_3).clone());
                }
                drop(v230_3_cursor);
                drop(v230_2);
                v229_3.join_into((v230_3).clone());
              }
              drop(v229_3_cursor);
              drop(v229_2);
              v228_2.join_into((v229_3).clone());
            }
            drop(v228_2_cursor);
            v227_3.join_into((v228_2).clone());
          }
          drop(v227_3_cursor);
          drop(v227_2);
          v226_3.join_into((v227_3).clone());
        }
        drop(v226_3_cursor);
        drop(v226_2);
        v225_3.join_into((v226_3).clone());
      }
      drop(v225_3_cursor);
      drop(v225_2);
      v224_2.join_into((v225_3).clone());
    }
    drop(v224_2_cursor);
    v223_3.join_into((v224_2).clone());
  }
  drop(v223_3_cursor);
  (v223_3).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v232_3 = Space::new();
  let mut v232_3_cursor = (*s0).read_zipper();
  for v232_3_byte in v232_3_cursor.child_mask().iter() {
    v232_3_cursor.descend_to_byte(v232_3_byte);
    let v232_3_tail = v232_3_cursor.make_map();
    v232_3_cursor.ascend(1);
    let v232_3_head = Path::from_slice(&[v232_3_byte]);
    let mut v233_2 = Space::new();
    let mut v233_2_cursor = (v232_3_tail).read_zipper();
    for v233_2_byte in v233_2_cursor.child_mask().iter() {
      v233_2_cursor.descend_to_byte(v233_2_byte);
      let v233_2_tail = v233_2_cursor.make_map();
      v233_2_cursor.ascend(1);
      let v233_2_head = Path::from_slice(&[v233_2_byte]);
      let v234_2: Path = concat_path(&(v232_3_head),&(v233_2_head));
      let mut v234_3 = Space::new();
      let mut v234_3_cursor = (v233_2_tail).read_zipper();
      for v234_3_byte in v234_3_cursor.child_mask().iter() {
        v234_3_cursor.descend_to_byte(v234_3_byte);
        let v234_3_tail = v234_3_cursor.make_map();
        v234_3_cursor.ascend(1);
        let v234_3_head = Path::from_slice(&[v234_3_byte]);
        let v235_2: Path = concat_path(&(v234_2),&(v234_3_head));
        let mut v235_3 = Space::new();
        let mut v235_3_cursor = (v234_3_tail).read_zipper();
        for v235_3_byte in v235_3_cursor.child_mask().iter() {
          v235_3_cursor.descend_to_byte(v235_3_byte);
          let v235_3_tail = v235_3_cursor.make_map();
          v235_3_cursor.ascend(1);
          let v235_3_head = Path::from_slice(&[v235_3_byte]);
          let v236_2: Path = concat_path(&(v235_2),&(v235_3_head));
          let mut v236_3 = Space::new();
          let mut v236_3_cursor = (v235_3_tail).read_zipper();
          for v236_3_byte in v236_3_cursor.child_mask().iter() {
            v236_3_cursor.descend_to_byte(v236_3_byte);
            let v236_3_tail = v236_3_cursor.make_map();
            v236_3_cursor.ascend(1);
            let v236_3_head = Path::from_slice(&[v236_3_byte]);
            let mut v237_2 = Space::new();
            let mut v237_2_cursor = (v236_3_tail).read_zipper();
            for v237_2_byte in v237_2_cursor.child_mask().iter() {
              v237_2_cursor.descend_to_byte(v237_2_byte);
              let v237_2_tail = v237_2_cursor.make_map();
              v237_2_cursor.ascend(1);
              let v237_2_head = Path::from_slice(&[v237_2_byte]);
              let v238_2: Path = concat_path(&(v236_3_head),&(v237_2_head));
              let mut v238_3 = Space::new();
              let mut v238_3_cursor = (v237_2_tail).read_zipper();
              for v238_3_byte in v238_3_cursor.child_mask().iter() {
                v238_3_cursor.descend_to_byte(v238_3_byte);
                let v238_3_tail = v238_3_cursor.make_map();
                v238_3_cursor.ascend(1);
                let v238_3_head = Path::from_slice(&[v238_3_byte]);
                let v239_2: Path = concat_path(&(v238_2),&(v238_3_head));
                let mut v239_3 = Space::new();
                let mut v239_3_cursor = (v238_3_tail).read_zipper();
                for v239_3_byte in v239_3_cursor.child_mask().iter() {
                  v239_3_cursor.descend_to_byte(v239_3_byte);
                  let v239_3_tail = v239_3_cursor.make_map();
                  v239_3_cursor.ascend(1);
                  let v239_3_head = Path::from_slice(&[v239_3_byte]);
                  let v240_2: Path = concat_path(&(v239_2),&(v239_3_head));
                  let v240_3: Space = routine_28(c, &(v240_2), &(*p1), &(*p0), &(v236_2), &(v239_3_tail));
                  drop(v240_2);
                  v239_3.join_into((v240_3).clone());
                }
                drop(v239_3_cursor);
                drop(v239_2);
                v238_3.join_into((v239_3).clone());
              }
              drop(v238_3_cursor);
              drop(v238_2);
              v237_2.join_into((v238_3).clone());
            }
            drop(v237_2_cursor);
            v236_3.join_into((v237_2).clone());
          }
          drop(v236_3_cursor);
          drop(v236_2);
          v235_3.join_into((v236_3).clone());
        }
        drop(v235_3_cursor);
        drop(v235_2);
        v234_3.join_into((v235_3).clone());
      }
      drop(v234_3_cursor);
      drop(v234_2);
      v233_2.join_into((v234_3).clone());
    }
    drop(v233_2_cursor);
    v232_3.join_into((v233_2).clone());
  }
  drop(v232_3_cursor);
  (v232_3).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v241_4 = Space::new();
  let mut v241_4_cursor = (*s0).read_zipper();
  for v241_4_byte in v241_4_cursor.child_mask().iter() {
    v241_4_cursor.descend_to_byte(v241_4_byte);
    let v241_4_tail = v241_4_cursor.make_map();
    v241_4_cursor.ascend(1);
    let v241_4_head = Path::from_slice(&[v241_4_byte]);
    let mut v242_2 = Space::new();
    let mut v242_2_cursor = (v241_4_tail).read_zipper();
    for v242_2_byte in v242_2_cursor.child_mask().iter() {
      v242_2_cursor.descend_to_byte(v242_2_byte);
      let v242_2_tail = v242_2_cursor.make_map();
      v242_2_cursor.ascend(1);
      let v242_2_head = Path::from_slice(&[v242_2_byte]);
      let v243_2: Path = concat_path(&(v241_4_head),&(v242_2_head));
      let mut v243_3 = Space::new();
      let mut v243_3_cursor = (v242_2_tail).read_zipper();
      for v243_3_byte in v243_3_cursor.child_mask().iter() {
        v243_3_cursor.descend_to_byte(v243_3_byte);
        let v243_3_tail = v243_3_cursor.make_map();
        v243_3_cursor.ascend(1);
        let v243_3_head = Path::from_slice(&[v243_3_byte]);
        let v244_2: Space = head_space(&(v243_3_tail));
        let v244_3: Path = concat_path(&(v243_2),&(v243_3_head));
        let v244_4: Space = wrap(&(v244_2),&(v244_3));
        drop(v244_2);
        drop(v244_3);
        v243_3.join_into((v244_4).clone());
      }
      drop(v243_3_cursor);
      drop(v243_2);
      v242_2.join_into((v243_3).clone());
    }
    drop(v242_2_cursor);
    v241_4.join_into((v242_2).clone());
  }
  drop(v241_4_cursor);
  let v241_5: Space = raffine(&(*CONSTANT_72),&(v241_4));
  drop(v241_4);
  let v241_6: Space = unite(&(v241_5),&(*s0));
  drop(v241_5);
  let v241_7: Path = concat_path(&(*p1),&(*p0));
  let v241_8: Space = wrap(&(v241_6),&(v241_7));
  drop(v241_6);
  drop(v241_7);
  (v241_8).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v245_4 = Space::new();
  let mut v245_4_cursor = (*s0).read_zipper();
  for v245_4_byte in v245_4_cursor.child_mask().iter() {
    v245_4_cursor.descend_to_byte(v245_4_byte);
    let v245_4_tail = v245_4_cursor.make_map();
    v245_4_cursor.ascend(1);
    let v245_4_head = Path::from_slice(&[v245_4_byte]);
    let mut v246_2 = Space::new();
    let mut v246_2_cursor = (v245_4_tail).read_zipper();
    for v246_2_byte in v246_2_cursor.child_mask().iter() {
      v246_2_cursor.descend_to_byte(v246_2_byte);
      let v246_2_tail = v246_2_cursor.make_map();
      v246_2_cursor.ascend(1);
      let v246_2_head = Path::from_slice(&[v246_2_byte]);
      let v247_2: Path = concat_path(&(v245_4_head),&(v246_2_head));
      let mut v247_3 = Space::new();
      let mut v247_3_cursor = (v246_2_tail).read_zipper();
      for v247_3_byte in v247_3_cursor.child_mask().iter() {
        v247_3_cursor.descend_to_byte(v247_3_byte);
        let v247_3_tail = v247_3_cursor.make_map();
        v247_3_cursor.ascend(1);
        let v247_3_head = Path::from_slice(&[v247_3_byte]);
        let v248_2: Space = head_space(&(v247_3_tail));
        let v248_3: Path = concat_path(&(v247_2),&(v247_3_head));
        let v248_4: Space = wrap(&(v248_2),&(v248_3));
        drop(v248_2);
        drop(v248_3);
        v247_3.join_into((v248_4).clone());
      }
      drop(v247_3_cursor);
      drop(v247_2);
      v246_2.join_into((v247_3).clone());
    }
    drop(v246_2_cursor);
    v245_4.join_into((v246_2).clone());
  }
  drop(v245_4_cursor);
  let v245_5: Space = raffine(&(*CONSTANT_72),&(v245_4));
  drop(v245_4);
  let v245_6: Space = unite(&(v245_5),&(*s0));
  drop(v245_5);
  let v245_7: Path = concat_path(&(*p1),&(*p0));
  let v245_8: Space = wrap(&(v245_6),&(v245_7));
  drop(v245_6);
  drop(v245_7);
  (v245_8).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v249_3: Space = singleton(&(*p0));
  let v249_4: Space = intersect(&(*CONSTANT_47),&(v249_3));
  let v249_28: Space = if (v249_4).is_empty() { Space::new() } else {
    let v250_6: Space = unwrap(&(*s0),&(*CONSTANT_3));
    let v250_9: Space = if (v250_6).is_empty() { Space::new() } else {
      let v251_8: Space = unwrap(&(*s0),&(*CONSTANT_5));
      compose(&(v250_6),&(v251_8))
    };
    let v250_12: Space = if (v250_9).is_empty() { Space::new() } else {
      let v252_11: Space = unwrap(&(*s0),&(*CONSTANT_7));
      compose(&(v250_9),&(v252_11))
    };
    drop(v250_9);
    let v250_15: Space = if (v250_12).is_empty() { Space::new() } else {
      let v253_14: Space = unwrap(&(*s0),&(*CONSTANT_9));
      compose(&(v250_12),&(v253_14))
    };
    drop(v250_12);
    let v250_18: Space = if (v250_15).is_empty() { Space::new() } else {
      let v254_17: Space = unwrap(&(*s0),&(*CONSTANT_11));
      compose(&(v250_15),&(v254_17))
    };
    drop(v250_15);
    let v250_21: Space = if (v250_18).is_empty() { Space::new() } else {
      let v255_20: Space = unwrap(&(*s0),&(*CONSTANT_13));
      compose(&(v250_18),&(v255_20))
    };
    drop(v250_18);
    let v250_24: Space = if (v250_21).is_empty() { Space::new() } else {
      let v256_23: Space = unwrap(&(*s0),&(*CONSTANT_15));
      compose(&(v250_21),&(v256_23))
    };
    drop(v250_21);
    let v250_27: Space = if (v250_24).is_empty() { Space::new() } else {
      let v257_26: Space = unwrap(&(*s0),&(*CONSTANT_17));
      compose(&(v250_24),&(v257_26))
    };
    drop(v250_24);
    compose(&(v249_4),&(v250_27))
  };
  drop(v249_4);
  let v249_30: Space = intersect(&(*CONSTANT_48),&(v249_3));
  let v249_40: Space = if (v249_30).is_empty() { Space::new() } else {
    let v258_32: Space = unwrap(&(*s0),&(*CONSTANT_1));
    let v258_33: Space = if (v258_32).is_empty() { Space::new() } else {
      let v259_8: Space = unwrap(&(*s0),&(*CONSTANT_5));
      compose(&(v258_32),&(v259_8))
    };
    let v258_34: Space = if (v258_33).is_empty() { Space::new() } else {
      let v260_11: Space = unwrap(&(*s0),&(*CONSTANT_7));
      compose(&(v258_33),&(v260_11))
    };
    drop(v258_33);
    let v258_35: Space = if (v258_34).is_empty() { Space::new() } else {
      let v261_14: Space = unwrap(&(*s0),&(*CONSTANT_9));
      compose(&(v258_34),&(v261_14))
    };
    drop(v258_34);
    let v258_36: Space = if (v258_35).is_empty() { Space::new() } else {
      let v262_17: Space = unwrap(&(*s0),&(*CONSTANT_11));
      compose(&(v258_35),&(v262_17))
    };
    drop(v258_35);
    let v258_37: Space = if (v258_36).is_empty() { Space::new() } else {
      let v263_20: Space = unwrap(&(*s0),&(*CONSTANT_13));
      compose(&(v258_36),&(v263_20))
    };
    drop(v258_36);
    let v258_38: Space = if (v258_37).is_empty() { Space::new() } else {
      let v264_23: Space = unwrap(&(*s0),&(*CONSTANT_15));
      compose(&(v258_37),&(v264_23))
    };
    drop(v258_37);
    let v258_39: Space = if (v258_38).is_empty() { Space::new() } else {
      let v265_26: Space = unwrap(&(*s0),&(*CONSTANT_17));
      compose(&(v258_38),&(v265_26))
    };
    drop(v258_38);
    compose(&(v249_30),&(v258_39))
  };
  drop(v249_30);
  let v249_41: Space = unite(&(v249_28),&(v249_40));
  drop(v249_28);
  drop(v249_40);
  let v249_43: Space = intersect(&(*CONSTANT_49),&(v249_3));
  let v249_51: Space = if (v249_43).is_empty() { Space::new() } else {
    let v266_32: Space = unwrap(&(*s0),&(*CONSTANT_1));
    let v266_44: Space = if (v266_32).is_empty() { Space::new() } else {
      let v267_6: Space = unwrap(&(*s0),&(*CONSTANT_3));
      compose(&(v266_32),&(v267_6))
    };
    drop(v266_32);
    let v266_45: Space = if (v266_44).is_empty() { Space::new() } else {
      let v268_11: Space = unwrap(&(*s0),&(*CONSTANT_7));
      compose(&(v266_44),&(v268_11))
    };
    let v266_46: Space = if (v266_45).is_empty() { Space::new() } else {
      let v269_14: Space = unwrap(&(*s0),&(*CONSTANT_9));
      compose(&(v266_45),&(v269_14))
    };
    drop(v266_45);
    let v266_47: Space = if (v266_46).is_empty() { Space::new() } else {
      let v270_17: Space = unwrap(&(*s0),&(*CONSTANT_11));
      compose(&(v266_46),&(v270_17))
    };
    drop(v266_46);
    let v266_48: Space = if (v266_47).is_empty() { Space::new() } else {
      let v271_20: Space = unwrap(&(*s0),&(*CONSTANT_13));
      compose(&(v266_47),&(v271_20))
    };
    drop(v266_47);
    let v266_49: Space = if (v266_48).is_empty() { Space::new() } else {
      let v272_23: Space = unwrap(&(*s0),&(*CONSTANT_15));
      compose(&(v266_48),&(v272_23))
    };
    drop(v266_48);
    let v266_50: Space = if (v266_49).is_empty() { Space::new() } else {
      let v273_26: Space = unwrap(&(*s0),&(*CONSTANT_17));
      compose(&(v266_49),&(v273_26))
    };
    drop(v266_49);
    compose(&(v249_43),&(v266_50))
  };
  drop(v249_43);
  let v249_52: Space = unite(&(v249_41),&(v249_51));
  drop(v249_41);
  drop(v249_51);
  let v249_54: Space = intersect(&(*CONSTANT_50),&(v249_3));
  let v249_61: Space = if (v249_54).is_empty() { Space::new() } else {
    let v274_32: Space = unwrap(&(*s0),&(*CONSTANT_1));
    let v274_44: Space = if (v274_32).is_empty() { Space::new() } else {
      let v275_6: Space = unwrap(&(*s0),&(*CONSTANT_3));
      compose(&(v274_32),&(v275_6))
    };
    drop(v274_32);
    let v274_55: Space = if (v274_44).is_empty() { Space::new() } else {
      let v276_8: Space = unwrap(&(*s0),&(*CONSTANT_5));
      compose(&(v274_44),&(v276_8))
    };
    drop(v274_44);
    let v274_56: Space = if (v274_55).is_empty() { Space::new() } else {
      let v277_14: Space = unwrap(&(*s0),&(*CONSTANT_9));
      compose(&(v274_55),&(v277_14))
    };
    let v274_57: Space = if (v274_56).is_empty() { Space::new() } else {
      let v278_17: Space = unwrap(&(*s0),&(*CONSTANT_11));
      compose(&(v274_56),&(v278_17))
    };
    drop(v274_56);
    let v274_58: Space = if (v274_57).is_empty() { Space::new() } else {
      let v279_20: Space = unwrap(&(*s0),&(*CONSTANT_13));
      compose(&(v274_57),&(v279_20))
    };
    drop(v274_57);
    let v274_59: Space = if (v274_58).is_empty() { Space::new() } else {
      let v280_23: Space = unwrap(&(*s0),&(*CONSTANT_15));
      compose(&(v274_58),&(v280_23))
    };
    drop(v274_58);
    let v274_60: Space = if (v274_59).is_empty() { Space::new() } else {
      let v281_26: Space = unwrap(&(*s0),&(*CONSTANT_17));
      compose(&(v274_59),&(v281_26))
    };
    drop(v274_59);
    compose(&(v249_54),&(v274_60))
  };
  drop(v249_54);
  let v249_62: Space = unite(&(v249_52),&(v249_61));
  drop(v249_52);
  drop(v249_61);
  let v249_64: Space = intersect(&(*CONSTANT_51),&(v249_3));
  let v249_70: Space = if (v249_64).is_empty() { Space::new() } else {
    let v282_32: Space = unwrap(&(*s0),&(*CONSTANT_1));
    let v282_44: Space = if (v282_32).is_empty() { Space::new() } else {
      let v283_6: Space = unwrap(&(*s0),&(*CONSTANT_3));
      compose(&(v282_32),&(v283_6))
    };
    drop(v282_32);
    let v282_55: Space = if (v282_44).is_empty() { Space::new() } else {
      let v284_8: Space = unwrap(&(*s0),&(*CONSTANT_5));
      compose(&(v282_44),&(v284_8))
    };
    drop(v282_44);
    let v282_65: Space = if (v282_55).is_empty() { Space::new() } else {
      let v285_11: Space = unwrap(&(*s0),&(*CONSTANT_7));
      compose(&(v282_55),&(v285_11))
    };
    drop(v282_55);
    let v282_66: Space = if (v282_65).is_empty() { Space::new() } else {
      let v286_17: Space = unwrap(&(*s0),&(*CONSTANT_11));
      compose(&(v282_65),&(v286_17))
    };
    let v282_67: Space = if (v282_66).is_empty() { Space::new() } else {
      let v287_20: Space = unwrap(&(*s0),&(*CONSTANT_13));
      compose(&(v282_66),&(v287_20))
    };
    drop(v282_66);
    let v282_68: Space = if (v282_67).is_empty() { Space::new() } else {
      let v288_23: Space = unwrap(&(*s0),&(*CONSTANT_15));
      compose(&(v282_67),&(v288_23))
    };
    drop(v282_67);
    let v282_69: Space = if (v282_68).is_empty() { Space::new() } else {
      let v289_26: Space = unwrap(&(*s0),&(*CONSTANT_17));
      compose(&(v282_68),&(v289_26))
    };
    drop(v282_68);
    compose(&(v249_64),&(v282_69))
  };
  drop(v249_64);
  let v249_71: Space = unite(&(v249_62),&(v249_70));
  drop(v249_62);
  drop(v249_70);
  let v249_73: Space = intersect(&(*CONSTANT_52),&(v249_3));
  let v249_78: Space = if (v249_73).is_empty() { Space::new() } else {
    let v290_32: Space = unwrap(&(*s0),&(*CONSTANT_1));
    let v290_44: Space = if (v290_32).is_empty() { Space::new() } else {
      let v291_6: Space = unwrap(&(*s0),&(*CONSTANT_3));
      compose(&(v290_32),&(v291_6))
    };
    drop(v290_32);
    let v290_55: Space = if (v290_44).is_empty() { Space::new() } else {
      let v292_8: Space = unwrap(&(*s0),&(*CONSTANT_5));
      compose(&(v290_44),&(v292_8))
    };
    drop(v290_44);
    let v290_65: Space = if (v290_55).is_empty() { Space::new() } else {
      let v293_11: Space = unwrap(&(*s0),&(*CONSTANT_7));
      compose(&(v290_55),&(v293_11))
    };
    drop(v290_55);
    let v290_74: Space = if (v290_65).is_empty() { Space::new() } else {
      let v294_14: Space = unwrap(&(*s0),&(*CONSTANT_9));
      compose(&(v290_65),&(v294_14))
    };
    drop(v290_65);
    let v290_75: Space = if (v290_74).is_empty() { Space::new() } else {
      let v295_20: Space = unwrap(&(*s0),&(*CONSTANT_13));
      compose(&(v290_74),&(v295_20))
    };
    let v290_76: Space = if (v290_75).is_empty() { Space::new() } else {
      let v296_23: Space = unwrap(&(*s0),&(*CONSTANT_15));
      compose(&(v290_75),&(v296_23))
    };
    drop(v290_75);
    let v290_77: Space = if (v290_76).is_empty() { Space::new() } else {
      let v297_26: Space = unwrap(&(*s0),&(*CONSTANT_17));
      compose(&(v290_76),&(v297_26))
    };
    drop(v290_76);
    compose(&(v249_73),&(v290_77))
  };
  drop(v249_73);
  let v249_79: Space = unite(&(v249_71),&(v249_78));
  drop(v249_71);
  drop(v249_78);
  let v249_81: Space = intersect(&(*CONSTANT_53),&(v249_3));
  let v249_85: Space = if (v249_81).is_empty() { Space::new() } else {
    let v298_32: Space = unwrap(&(*s0),&(*CONSTANT_1));
    let v298_44: Space = if (v298_32).is_empty() { Space::new() } else {
      let v299_6: Space = unwrap(&(*s0),&(*CONSTANT_3));
      compose(&(v298_32),&(v299_6))
    };
    drop(v298_32);
    let v298_55: Space = if (v298_44).is_empty() { Space::new() } else {
      let v300_8: Space = unwrap(&(*s0),&(*CONSTANT_5));
      compose(&(v298_44),&(v300_8))
    };
    drop(v298_44);
    let v298_65: Space = if (v298_55).is_empty() { Space::new() } else {
      let v301_11: Space = unwrap(&(*s0),&(*CONSTANT_7));
      compose(&(v298_55),&(v301_11))
    };
    drop(v298_55);
    let v298_74: Space = if (v298_65).is_empty() { Space::new() } else {
      let v302_14: Space = unwrap(&(*s0),&(*CONSTANT_9));
      compose(&(v298_65),&(v302_14))
    };
    drop(v298_65);
    let v298_82: Space = if (v298_74).is_empty() { Space::new() } else {
      let v303_17: Space = unwrap(&(*s0),&(*CONSTANT_11));
      compose(&(v298_74),&(v303_17))
    };
    drop(v298_74);
    let v298_83: Space = if (v298_82).is_empty() { Space::new() } else {
      let v304_23: Space = unwrap(&(*s0),&(*CONSTANT_15));
      compose(&(v298_82),&(v304_23))
    };
    let v298_84: Space = if (v298_83).is_empty() { Space::new() } else {
      let v305_26: Space = unwrap(&(*s0),&(*CONSTANT_17));
      compose(&(v298_83),&(v305_26))
    };
    drop(v298_83);
    compose(&(v249_81),&(v298_84))
  };
  drop(v249_81);
  let v249_86: Space = unite(&(v249_79),&(v249_85));
  drop(v249_79);
  drop(v249_85);
  let v249_88: Space = intersect(&(*CONSTANT_54),&(v249_3));
  let v249_91: Space = if (v249_88).is_empty() { Space::new() } else {
    let v306_32: Space = unwrap(&(*s0),&(*CONSTANT_1));
    let v306_44: Space = if (v306_32).is_empty() { Space::new() } else {
      let v307_6: Space = unwrap(&(*s0),&(*CONSTANT_3));
      compose(&(v306_32),&(v307_6))
    };
    drop(v306_32);
    let v306_55: Space = if (v306_44).is_empty() { Space::new() } else {
      let v308_8: Space = unwrap(&(*s0),&(*CONSTANT_5));
      compose(&(v306_44),&(v308_8))
    };
    drop(v306_44);
    let v306_65: Space = if (v306_55).is_empty() { Space::new() } else {
      let v309_11: Space = unwrap(&(*s0),&(*CONSTANT_7));
      compose(&(v306_55),&(v309_11))
    };
    drop(v306_55);
    let v306_74: Space = if (v306_65).is_empty() { Space::new() } else {
      let v310_14: Space = unwrap(&(*s0),&(*CONSTANT_9));
      compose(&(v306_65),&(v310_14))
    };
    drop(v306_65);
    let v306_82: Space = if (v306_74).is_empty() { Space::new() } else {
      let v311_17: Space = unwrap(&(*s0),&(*CONSTANT_11));
      compose(&(v306_74),&(v311_17))
    };
    drop(v306_74);
    let v306_89: Space = if (v306_82).is_empty() { Space::new() } else {
      let v312_20: Space = unwrap(&(*s0),&(*CONSTANT_13));
      compose(&(v306_82),&(v312_20))
    };
    drop(v306_82);
    let v306_90: Space = if (v306_89).is_empty() { Space::new() } else {
      let v313_26: Space = unwrap(&(*s0),&(*CONSTANT_17));
      compose(&(v306_89),&(v313_26))
    };
    compose(&(v249_88),&(v306_90))
  };
  drop(v249_88);
  let v249_92: Space = unite(&(v249_86),&(v249_91));
  drop(v249_86);
  drop(v249_91);
  let v249_94: Space = intersect(&(*CONSTANT_55),&(v249_3));
  drop(v249_3);
  let v249_96: Space = if (v249_94).is_empty() { Space::new() } else {
    let v314_32: Space = unwrap(&(*s0),&(*CONSTANT_1));
    let v314_44: Space = if (v314_32).is_empty() { Space::new() } else {
      let v315_6: Space = unwrap(&(*s0),&(*CONSTANT_3));
      compose(&(v314_32),&(v315_6))
    };
    drop(v314_32);
    let v314_55: Space = if (v314_44).is_empty() { Space::new() } else {
      let v316_8: Space = unwrap(&(*s0),&(*CONSTANT_5));
      compose(&(v314_44),&(v316_8))
    };
    drop(v314_44);
    let v314_65: Space = if (v314_55).is_empty() { Space::new() } else {
      let v317_11: Space = unwrap(&(*s0),&(*CONSTANT_7));
      compose(&(v314_55),&(v317_11))
    };
    drop(v314_55);
    let v314_74: Space = if (v314_65).is_empty() { Space::new() } else {
      let v318_14: Space = unwrap(&(*s0),&(*CONSTANT_9));
      compose(&(v314_65),&(v318_14))
    };
    drop(v314_65);
    let v314_82: Space = if (v314_74).is_empty() { Space::new() } else {
      let v319_17: Space = unwrap(&(*s0),&(*CONSTANT_11));
      compose(&(v314_74),&(v319_17))
    };
    drop(v314_74);
    let v314_89: Space = if (v314_82).is_empty() { Space::new() } else {
      let v320_20: Space = unwrap(&(*s0),&(*CONSTANT_13));
      compose(&(v314_82),&(v320_20))
    };
    drop(v314_82);
    let v314_95: Space = if (v314_89).is_empty() { Space::new() } else {
      let v321_23: Space = unwrap(&(*s0),&(*CONSTANT_15));
      compose(&(v314_89),&(v321_23))
    };
    drop(v314_89);
    compose(&(v249_94),&(v314_95))
  };
  drop(v249_94);
  let v249_97: Space = unite(&(v249_92),&(v249_96));
  drop(v249_92);
  drop(v249_96);
  (v249_97).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v322_5 = Space::new();
  let mut v322_5_cursor = (*s0).read_zipper();
  for v322_5_byte in v322_5_cursor.child_mask().iter() {
    v322_5_cursor.descend_to_byte(v322_5_byte);
    let v322_5_tail = v322_5_cursor.make_map();
    v322_5_cursor.ascend(1);
    let v322_5_head = Path::from_slice(&[v322_5_byte]);
    let mut v323_2 = Space::new();
    let mut v323_2_cursor = (v322_5_tail).read_zipper();
    for v323_2_byte in v323_2_cursor.child_mask().iter() {
      v323_2_cursor.descend_to_byte(v323_2_byte);
      let v323_2_tail = v323_2_cursor.make_map();
      v323_2_cursor.ascend(1);
      let v323_2_head = Path::from_slice(&[v323_2_byte]);
      let v324_2: Path = concat_path(&(v322_5_head),&(v323_2_head));
      let mut v324_3 = Space::new();
      let mut v324_3_cursor = (v323_2_tail).read_zipper();
      for v324_3_byte in v324_3_cursor.child_mask().iter() {
        v324_3_cursor.descend_to_byte(v324_3_byte);
        let v324_3_tail = v324_3_cursor.make_map();
        v324_3_cursor.ascend(1);
        let v324_3_head = Path::from_slice(&[v324_3_byte]);
        let v325_2: Path = concat_path(&(v324_2),&(v324_3_head));
        let mut v325_3 = Space::new();
        let mut v325_3_cursor = (v324_3_tail).read_zipper();
        for v325_3_byte in v325_3_cursor.child_mask().iter() {
          v325_3_cursor.descend_to_byte(v325_3_byte);
          let v325_3_tail = v325_3_cursor.make_map();
          v325_3_cursor.ascend(1);
          let v325_3_head = Path::from_slice(&[v325_3_byte]);
          let v326_2: Path = concat_path(&(v325_2),&(v325_3_head));
          let mut v326_3 = Space::new();
          let mut v326_3_cursor = (v325_3_tail).read_zipper();
          for v326_3_byte in v326_3_cursor.child_mask().iter() {
            v326_3_cursor.descend_to_byte(v326_3_byte);
            let v326_3_tail = v326_3_cursor.make_map();
            v326_3_cursor.ascend(1);
            let v326_3_head = Path::from_slice(&[v326_3_byte]);
            let mut v327_2 = Space::new();
            let mut v327_2_cursor = (v326_3_tail).read_zipper();
            for v327_2_byte in v327_2_cursor.child_mask().iter() {
              v327_2_cursor.descend_to_byte(v327_2_byte);
              let v327_2_tail = v327_2_cursor.make_map();
              v327_2_cursor.ascend(1);
              let v327_2_head = Path::from_slice(&[v327_2_byte]);
              let v328_2: Path = concat_path(&(v326_3_head),&(v327_2_head));
              let mut v328_3 = Space::new();
              let mut v328_3_cursor = (v327_2_tail).read_zipper();
              for v328_3_byte in v328_3_cursor.child_mask().iter() {
                v328_3_cursor.descend_to_byte(v328_3_byte);
                let v328_3_tail = v328_3_cursor.make_map();
                v328_3_cursor.ascend(1);
                let v328_3_head = Path::from_slice(&[v328_3_byte]);
                let v329_2: Path = concat_path(&(v328_2),&(v328_3_head));
                let mut v329_3 = Space::new();
                let mut v329_3_cursor = (v328_3_tail).read_zipper();
                for v329_3_byte in v329_3_cursor.child_mask().iter() {
                  v329_3_cursor.descend_to_byte(v329_3_byte);
                  let v329_3_tail = v329_3_cursor.make_map();
                  v329_3_cursor.ascend(1);
                  let v329_3_head = Path::from_slice(&[v329_3_byte]);
                  let v330_2: Path = concat_path(&(v329_2),&(v329_3_head));
                  let v330_3: Space = routine_29(c, &(v330_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v326_2), &(v329_3_tail));
                  drop(v330_2);
                  v329_3.join_into((v330_3).clone());
                }
                drop(v329_3_cursor);
                drop(v329_2);
                v328_3.join_into((v329_3).clone());
              }
              drop(v328_3_cursor);
              drop(v328_2);
              v327_2.join_into((v328_3).clone());
            }
            drop(v327_2_cursor);
            v326_3.join_into((v327_2).clone());
          }
          drop(v326_3_cursor);
          drop(v326_2);
          v325_3.join_into((v326_3).clone());
        }
        drop(v325_3_cursor);
        drop(v325_2);
        v324_3.join_into((v325_3).clone());
      }
      drop(v324_3_cursor);
      drop(v324_2);
      v323_2.join_into((v324_3).clone());
    }
    drop(v323_2_cursor);
    v322_5.join_into((v323_2).clone());
  }
  drop(v322_5_cursor);
  (v322_5).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v331_5 = Space::new();
  let mut v331_5_cursor = (*s0).read_zipper();
  for v331_5_byte in v331_5_cursor.child_mask().iter() {
    v331_5_cursor.descend_to_byte(v331_5_byte);
    let v331_5_tail = v331_5_cursor.make_map();
    v331_5_cursor.ascend(1);
    let v331_5_head = Path::from_slice(&[v331_5_byte]);
    let mut v332_2 = Space::new();
    let mut v332_2_cursor = (v331_5_tail).read_zipper();
    for v332_2_byte in v332_2_cursor.child_mask().iter() {
      v332_2_cursor.descend_to_byte(v332_2_byte);
      let v332_2_tail = v332_2_cursor.make_map();
      v332_2_cursor.ascend(1);
      let v332_2_head = Path::from_slice(&[v332_2_byte]);
      let v333_2: Path = concat_path(&(v331_5_head),&(v332_2_head));
      let mut v333_3 = Space::new();
      let mut v333_3_cursor = (v332_2_tail).read_zipper();
      for v333_3_byte in v333_3_cursor.child_mask().iter() {
        v333_3_cursor.descend_to_byte(v333_3_byte);
        let v333_3_tail = v333_3_cursor.make_map();
        v333_3_cursor.ascend(1);
        let v333_3_head = Path::from_slice(&[v333_3_byte]);
        let v334_2: Path = concat_path(&(v333_2),&(v333_3_head));
        let mut v334_3 = Space::new();
        let mut v334_3_cursor = (v333_3_tail).read_zipper();
        for v334_3_byte in v334_3_cursor.child_mask().iter() {
          v334_3_cursor.descend_to_byte(v334_3_byte);
          let v334_3_tail = v334_3_cursor.make_map();
          v334_3_cursor.ascend(1);
          let v334_3_head = Path::from_slice(&[v334_3_byte]);
          let v335_2: Path = concat_path(&(v334_2),&(v334_3_head));
          let mut v335_3 = Space::new();
          let mut v335_3_cursor = (v334_3_tail).read_zipper();
          for v335_3_byte in v335_3_cursor.child_mask().iter() {
            v335_3_cursor.descend_to_byte(v335_3_byte);
            let v335_3_tail = v335_3_cursor.make_map();
            v335_3_cursor.ascend(1);
            let v335_3_head = Path::from_slice(&[v335_3_byte]);
            let mut v336_2 = Space::new();
            let mut v336_2_cursor = (v335_3_tail).read_zipper();
            for v336_2_byte in v336_2_cursor.child_mask().iter() {
              v336_2_cursor.descend_to_byte(v336_2_byte);
              let v336_2_tail = v336_2_cursor.make_map();
              v336_2_cursor.ascend(1);
              let v336_2_head = Path::from_slice(&[v336_2_byte]);
              let v337_2: Path = concat_path(&(v335_3_head),&(v336_2_head));
              let mut v337_3 = Space::new();
              let mut v337_3_cursor = (v336_2_tail).read_zipper();
              for v337_3_byte in v337_3_cursor.child_mask().iter() {
                v337_3_cursor.descend_to_byte(v337_3_byte);
                let v337_3_tail = v337_3_cursor.make_map();
                v337_3_cursor.ascend(1);
                let v337_3_head = Path::from_slice(&[v337_3_byte]);
                let v338_2: Path = concat_path(&(v337_2),&(v337_3_head));
                let mut v338_3 = Space::new();
                let mut v338_3_cursor = (v337_3_tail).read_zipper();
                for v338_3_byte in v338_3_cursor.child_mask().iter() {
                  v338_3_cursor.descend_to_byte(v338_3_byte);
                  let v338_3_tail = v338_3_cursor.make_map();
                  v338_3_cursor.ascend(1);
                  let v338_3_head = Path::from_slice(&[v338_3_byte]);
                  let v339_2: Path = concat_path(&(v338_2),&(v338_3_head));
                  let v339_3: Space = routine_30(c, &(v339_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v335_2), &(v338_3_tail));
                  drop(v339_2);
                  v338_3.join_into((v339_3).clone());
                }
                drop(v338_3_cursor);
                drop(v338_2);
                v337_3.join_into((v338_3).clone());
              }
              drop(v337_3_cursor);
              drop(v337_2);
              v336_2.join_into((v337_3).clone());
            }
            drop(v336_2_cursor);
            v335_3.join_into((v336_2).clone());
          }
          drop(v335_3_cursor);
          drop(v335_2);
          v334_3.join_into((v335_3).clone());
        }
        drop(v334_3_cursor);
        drop(v334_2);
        v333_3.join_into((v334_3).clone());
      }
      drop(v333_3_cursor);
      drop(v333_2);
      v332_2.join_into((v333_3).clone());
    }
    drop(v332_2_cursor);
    v331_5.join_into((v332_2).clone());
  }
  drop(v331_5_cursor);
  (v331_5).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v340_5 = Space::new();
  let mut v340_5_cursor = (*s0).read_zipper();
  for v340_5_byte in v340_5_cursor.child_mask().iter() {
    v340_5_cursor.descend_to_byte(v340_5_byte);
    let v340_5_tail = v340_5_cursor.make_map();
    v340_5_cursor.ascend(1);
    let v340_5_head = Path::from_slice(&[v340_5_byte]);
    let mut v341_2 = Space::new();
    let mut v341_2_cursor = (v340_5_tail).read_zipper();
    for v341_2_byte in v341_2_cursor.child_mask().iter() {
      v341_2_cursor.descend_to_byte(v341_2_byte);
      let v341_2_tail = v341_2_cursor.make_map();
      v341_2_cursor.ascend(1);
      let v341_2_head = Path::from_slice(&[v341_2_byte]);
      let v342_2: Path = concat_path(&(v340_5_head),&(v341_2_head));
      let mut v342_3 = Space::new();
      let mut v342_3_cursor = (v341_2_tail).read_zipper();
      for v342_3_byte in v342_3_cursor.child_mask().iter() {
        v342_3_cursor.descend_to_byte(v342_3_byte);
        let v342_3_tail = v342_3_cursor.make_map();
        v342_3_cursor.ascend(1);
        let v342_3_head = Path::from_slice(&[v342_3_byte]);
        let v343_2: Path = concat_path(&(v342_2),&(v342_3_head));
        let mut v343_3 = Space::new();
        let mut v343_3_cursor = (v342_3_tail).read_zipper();
        for v343_3_byte in v343_3_cursor.child_mask().iter() {
          v343_3_cursor.descend_to_byte(v343_3_byte);
          let v343_3_tail = v343_3_cursor.make_map();
          v343_3_cursor.ascend(1);
          let v343_3_head = Path::from_slice(&[v343_3_byte]);
          let v344_2: Path = concat_path(&(v343_2),&(v343_3_head));
          let mut v344_3 = Space::new();
          let mut v344_3_cursor = (v343_3_tail).read_zipper();
          for v344_3_byte in v344_3_cursor.child_mask().iter() {
            v344_3_cursor.descend_to_byte(v344_3_byte);
            let v344_3_tail = v344_3_cursor.make_map();
            v344_3_cursor.ascend(1);
            let v344_3_head = Path::from_slice(&[v344_3_byte]);
            let mut v345_2 = Space::new();
            let mut v345_2_cursor = (v344_3_tail).read_zipper();
            for v345_2_byte in v345_2_cursor.child_mask().iter() {
              v345_2_cursor.descend_to_byte(v345_2_byte);
              let v345_2_tail = v345_2_cursor.make_map();
              v345_2_cursor.ascend(1);
              let v345_2_head = Path::from_slice(&[v345_2_byte]);
              let v346_2: Path = concat_path(&(v344_3_head),&(v345_2_head));
              let mut v346_3 = Space::new();
              let mut v346_3_cursor = (v345_2_tail).read_zipper();
              for v346_3_byte in v346_3_cursor.child_mask().iter() {
                v346_3_cursor.descend_to_byte(v346_3_byte);
                let v346_3_tail = v346_3_cursor.make_map();
                v346_3_cursor.ascend(1);
                let v346_3_head = Path::from_slice(&[v346_3_byte]);
                let v347_2: Path = concat_path(&(v346_2),&(v346_3_head));
                let mut v347_3 = Space::new();
                let mut v347_3_cursor = (v346_3_tail).read_zipper();
                for v347_3_byte in v347_3_cursor.child_mask().iter() {
                  v347_3_cursor.descend_to_byte(v347_3_byte);
                  let v347_3_tail = v347_3_cursor.make_map();
                  v347_3_cursor.ascend(1);
                  let v347_3_head = Path::from_slice(&[v347_3_byte]);
                  let v348_2: Path = concat_path(&(v347_2),&(v347_3_head));
                  let v348_3: Space = routine_31(c, &(v348_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v344_2), &(v347_3_tail));
                  drop(v348_2);
                  v347_3.join_into((v348_3).clone());
                }
                drop(v347_3_cursor);
                drop(v347_2);
                v346_3.join_into((v347_3).clone());
              }
              drop(v346_3_cursor);
              drop(v346_2);
              v345_2.join_into((v346_3).clone());
            }
            drop(v345_2_cursor);
            v344_3.join_into((v345_2).clone());
          }
          drop(v344_3_cursor);
          drop(v344_2);
          v343_3.join_into((v344_3).clone());
        }
        drop(v343_3_cursor);
        drop(v343_2);
        v342_3.join_into((v343_3).clone());
      }
      drop(v342_3_cursor);
      drop(v342_2);
      v341_2.join_into((v342_3).clone());
    }
    drop(v341_2_cursor);
    v340_5.join_into((v341_2).clone());
  }
  drop(v340_5_cursor);
  (v340_5).clone()
}

fn routine_23(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v349_5 = Space::new();
  let mut v349_5_cursor = (*s0).read_zipper();
  for v349_5_byte in v349_5_cursor.child_mask().iter() {
    v349_5_cursor.descend_to_byte(v349_5_byte);
    let v349_5_tail = v349_5_cursor.make_map();
    v349_5_cursor.ascend(1);
    let v349_5_head = Path::from_slice(&[v349_5_byte]);
    let mut v350_2 = Space::new();
    let mut v350_2_cursor = (v349_5_tail).read_zipper();
    for v350_2_byte in v350_2_cursor.child_mask().iter() {
      v350_2_cursor.descend_to_byte(v350_2_byte);
      let v350_2_tail = v350_2_cursor.make_map();
      v350_2_cursor.ascend(1);
      let v350_2_head = Path::from_slice(&[v350_2_byte]);
      let v351_2: Path = concat_path(&(v349_5_head),&(v350_2_head));
      let mut v351_3 = Space::new();
      let mut v351_3_cursor = (v350_2_tail).read_zipper();
      for v351_3_byte in v351_3_cursor.child_mask().iter() {
        v351_3_cursor.descend_to_byte(v351_3_byte);
        let v351_3_tail = v351_3_cursor.make_map();
        v351_3_cursor.ascend(1);
        let v351_3_head = Path::from_slice(&[v351_3_byte]);
        let v352_2: Path = concat_path(&(v351_2),&(v351_3_head));
        let mut v352_3 = Space::new();
        let mut v352_3_cursor = (v351_3_tail).read_zipper();
        for v352_3_byte in v352_3_cursor.child_mask().iter() {
          v352_3_cursor.descend_to_byte(v352_3_byte);
          let v352_3_tail = v352_3_cursor.make_map();
          v352_3_cursor.ascend(1);
          let v352_3_head = Path::from_slice(&[v352_3_byte]);
          let v353_2: Path = concat_path(&(v352_2),&(v352_3_head));
          let mut v353_3 = Space::new();
          let mut v353_3_cursor = (v352_3_tail).read_zipper();
          for v353_3_byte in v353_3_cursor.child_mask().iter() {
            v353_3_cursor.descend_to_byte(v353_3_byte);
            let v353_3_tail = v353_3_cursor.make_map();
            v353_3_cursor.ascend(1);
            let v353_3_head = Path::from_slice(&[v353_3_byte]);
            let mut v354_2 = Space::new();
            let mut v354_2_cursor = (v353_3_tail).read_zipper();
            for v354_2_byte in v354_2_cursor.child_mask().iter() {
              v354_2_cursor.descend_to_byte(v354_2_byte);
              let v354_2_tail = v354_2_cursor.make_map();
              v354_2_cursor.ascend(1);
              let v354_2_head = Path::from_slice(&[v354_2_byte]);
              let v355_2: Path = concat_path(&(v353_3_head),&(v354_2_head));
              let mut v355_3 = Space::new();
              let mut v355_3_cursor = (v354_2_tail).read_zipper();
              for v355_3_byte in v355_3_cursor.child_mask().iter() {
                v355_3_cursor.descend_to_byte(v355_3_byte);
                let v355_3_tail = v355_3_cursor.make_map();
                v355_3_cursor.ascend(1);
                let v355_3_head = Path::from_slice(&[v355_3_byte]);
                let v356_2: Path = concat_path(&(v355_2),&(v355_3_head));
                let mut v356_3 = Space::new();
                let mut v356_3_cursor = (v355_3_tail).read_zipper();
                for v356_3_byte in v356_3_cursor.child_mask().iter() {
                  v356_3_cursor.descend_to_byte(v356_3_byte);
                  let v356_3_tail = v356_3_cursor.make_map();
                  v356_3_cursor.ascend(1);
                  let v356_3_head = Path::from_slice(&[v356_3_byte]);
                  let v357_2: Path = concat_path(&(v356_2),&(v356_3_head));
                  let v357_3: Space = routine_32(c, &(v357_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v353_2), &(v356_3_tail));
                  drop(v357_2);
                  v356_3.join_into((v357_3).clone());
                }
                drop(v356_3_cursor);
                drop(v356_2);
                v355_3.join_into((v356_3).clone());
              }
              drop(v355_3_cursor);
              drop(v355_2);
              v354_2.join_into((v355_3).clone());
            }
            drop(v354_2_cursor);
            v353_3.join_into((v354_2).clone());
          }
          drop(v353_3_cursor);
          drop(v353_2);
          v352_3.join_into((v353_3).clone());
        }
        drop(v352_3_cursor);
        drop(v352_2);
        v351_3.join_into((v352_3).clone());
      }
      drop(v351_3_cursor);
      drop(v351_2);
      v350_2.join_into((v351_3).clone());
    }
    drop(v350_2_cursor);
    v349_5.join_into((v350_2).clone());
  }
  drop(v349_5_cursor);
  (v349_5).clone()
}

fn routine_24(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v358_5 = Space::new();
  let mut v358_5_cursor = (*s0).read_zipper();
  for v358_5_byte in v358_5_cursor.child_mask().iter() {
    v358_5_cursor.descend_to_byte(v358_5_byte);
    let v358_5_tail = v358_5_cursor.make_map();
    v358_5_cursor.ascend(1);
    let v358_5_head = Path::from_slice(&[v358_5_byte]);
    let mut v359_2 = Space::new();
    let mut v359_2_cursor = (v358_5_tail).read_zipper();
    for v359_2_byte in v359_2_cursor.child_mask().iter() {
      v359_2_cursor.descend_to_byte(v359_2_byte);
      let v359_2_tail = v359_2_cursor.make_map();
      v359_2_cursor.ascend(1);
      let v359_2_head = Path::from_slice(&[v359_2_byte]);
      let v360_2: Path = concat_path(&(v358_5_head),&(v359_2_head));
      let mut v360_3 = Space::new();
      let mut v360_3_cursor = (v359_2_tail).read_zipper();
      for v360_3_byte in v360_3_cursor.child_mask().iter() {
        v360_3_cursor.descend_to_byte(v360_3_byte);
        let v360_3_tail = v360_3_cursor.make_map();
        v360_3_cursor.ascend(1);
        let v360_3_head = Path::from_slice(&[v360_3_byte]);
        let v361_2: Path = concat_path(&(v360_2),&(v360_3_head));
        let mut v361_3 = Space::new();
        let mut v361_3_cursor = (v360_3_tail).read_zipper();
        for v361_3_byte in v361_3_cursor.child_mask().iter() {
          v361_3_cursor.descend_to_byte(v361_3_byte);
          let v361_3_tail = v361_3_cursor.make_map();
          v361_3_cursor.ascend(1);
          let v361_3_head = Path::from_slice(&[v361_3_byte]);
          let v362_2: Path = concat_path(&(v361_2),&(v361_3_head));
          let mut v362_3 = Space::new();
          let mut v362_3_cursor = (v361_3_tail).read_zipper();
          for v362_3_byte in v362_3_cursor.child_mask().iter() {
            v362_3_cursor.descend_to_byte(v362_3_byte);
            let v362_3_tail = v362_3_cursor.make_map();
            v362_3_cursor.ascend(1);
            let v362_3_head = Path::from_slice(&[v362_3_byte]);
            let mut v363_2 = Space::new();
            let mut v363_2_cursor = (v362_3_tail).read_zipper();
            for v363_2_byte in v363_2_cursor.child_mask().iter() {
              v363_2_cursor.descend_to_byte(v363_2_byte);
              let v363_2_tail = v363_2_cursor.make_map();
              v363_2_cursor.ascend(1);
              let v363_2_head = Path::from_slice(&[v363_2_byte]);
              let v364_2: Path = concat_path(&(v362_3_head),&(v363_2_head));
              let mut v364_3 = Space::new();
              let mut v364_3_cursor = (v363_2_tail).read_zipper();
              for v364_3_byte in v364_3_cursor.child_mask().iter() {
                v364_3_cursor.descend_to_byte(v364_3_byte);
                let v364_3_tail = v364_3_cursor.make_map();
                v364_3_cursor.ascend(1);
                let v364_3_head = Path::from_slice(&[v364_3_byte]);
                let v365_2: Path = concat_path(&(v364_2),&(v364_3_head));
                let mut v365_3 = Space::new();
                let mut v365_3_cursor = (v364_3_tail).read_zipper();
                for v365_3_byte in v365_3_cursor.child_mask().iter() {
                  v365_3_cursor.descend_to_byte(v365_3_byte);
                  let v365_3_tail = v365_3_cursor.make_map();
                  v365_3_cursor.ascend(1);
                  let v365_3_head = Path::from_slice(&[v365_3_byte]);
                  let v366_2: Path = concat_path(&(v365_2),&(v365_3_head));
                  let v366_3: Space = routine_33(c, &(v366_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v362_2), &(v365_3_tail));
                  drop(v366_2);
                  v365_3.join_into((v366_3).clone());
                }
                drop(v365_3_cursor);
                drop(v365_2);
                v364_3.join_into((v365_3).clone());
              }
              drop(v364_3_cursor);
              drop(v364_2);
              v363_2.join_into((v364_3).clone());
            }
            drop(v363_2_cursor);
            v362_3.join_into((v363_2).clone());
          }
          drop(v362_3_cursor);
          drop(v362_2);
          v361_3.join_into((v362_3).clone());
        }
        drop(v361_3_cursor);
        drop(v361_2);
        v360_3.join_into((v361_3).clone());
      }
      drop(v360_3_cursor);
      drop(v360_2);
      v359_2.join_into((v360_3).clone());
    }
    drop(v359_2_cursor);
    v358_5.join_into((v359_2).clone());
  }
  drop(v358_5_cursor);
  (v358_5).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v367_5 = Space::new();
  let mut v367_5_cursor = (*s0).read_zipper();
  for v367_5_byte in v367_5_cursor.child_mask().iter() {
    v367_5_cursor.descend_to_byte(v367_5_byte);
    let v367_5_tail = v367_5_cursor.make_map();
    v367_5_cursor.ascend(1);
    let v367_5_head = Path::from_slice(&[v367_5_byte]);
    let mut v368_2 = Space::new();
    let mut v368_2_cursor = (v367_5_tail).read_zipper();
    for v368_2_byte in v368_2_cursor.child_mask().iter() {
      v368_2_cursor.descend_to_byte(v368_2_byte);
      let v368_2_tail = v368_2_cursor.make_map();
      v368_2_cursor.ascend(1);
      let v368_2_head = Path::from_slice(&[v368_2_byte]);
      let v369_2: Path = concat_path(&(v367_5_head),&(v368_2_head));
      let mut v369_3 = Space::new();
      let mut v369_3_cursor = (v368_2_tail).read_zipper();
      for v369_3_byte in v369_3_cursor.child_mask().iter() {
        v369_3_cursor.descend_to_byte(v369_3_byte);
        let v369_3_tail = v369_3_cursor.make_map();
        v369_3_cursor.ascend(1);
        let v369_3_head = Path::from_slice(&[v369_3_byte]);
        let v370_2: Path = concat_path(&(v369_2),&(v369_3_head));
        let mut v370_3 = Space::new();
        let mut v370_3_cursor = (v369_3_tail).read_zipper();
        for v370_3_byte in v370_3_cursor.child_mask().iter() {
          v370_3_cursor.descend_to_byte(v370_3_byte);
          let v370_3_tail = v370_3_cursor.make_map();
          v370_3_cursor.ascend(1);
          let v370_3_head = Path::from_slice(&[v370_3_byte]);
          let v371_2: Path = concat_path(&(v370_2),&(v370_3_head));
          let mut v371_3 = Space::new();
          let mut v371_3_cursor = (v370_3_tail).read_zipper();
          for v371_3_byte in v371_3_cursor.child_mask().iter() {
            v371_3_cursor.descend_to_byte(v371_3_byte);
            let v371_3_tail = v371_3_cursor.make_map();
            v371_3_cursor.ascend(1);
            let v371_3_head = Path::from_slice(&[v371_3_byte]);
            let mut v372_2 = Space::new();
            let mut v372_2_cursor = (v371_3_tail).read_zipper();
            for v372_2_byte in v372_2_cursor.child_mask().iter() {
              v372_2_cursor.descend_to_byte(v372_2_byte);
              let v372_2_tail = v372_2_cursor.make_map();
              v372_2_cursor.ascend(1);
              let v372_2_head = Path::from_slice(&[v372_2_byte]);
              let v373_2: Path = concat_path(&(v371_3_head),&(v372_2_head));
              let mut v373_3 = Space::new();
              let mut v373_3_cursor = (v372_2_tail).read_zipper();
              for v373_3_byte in v373_3_cursor.child_mask().iter() {
                v373_3_cursor.descend_to_byte(v373_3_byte);
                let v373_3_tail = v373_3_cursor.make_map();
                v373_3_cursor.ascend(1);
                let v373_3_head = Path::from_slice(&[v373_3_byte]);
                let v374_2: Path = concat_path(&(v373_2),&(v373_3_head));
                let mut v374_3 = Space::new();
                let mut v374_3_cursor = (v373_3_tail).read_zipper();
                for v374_3_byte in v374_3_cursor.child_mask().iter() {
                  v374_3_cursor.descend_to_byte(v374_3_byte);
                  let v374_3_tail = v374_3_cursor.make_map();
                  v374_3_cursor.ascend(1);
                  let v374_3_head = Path::from_slice(&[v374_3_byte]);
                  let v375_2: Path = concat_path(&(v374_2),&(v374_3_head));
                  let v375_3: Space = routine_34(c, &(v375_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v371_2), &(v374_3_tail));
                  drop(v375_2);
                  v374_3.join_into((v375_3).clone());
                }
                drop(v374_3_cursor);
                drop(v374_2);
                v373_3.join_into((v374_3).clone());
              }
              drop(v373_3_cursor);
              drop(v373_2);
              v372_2.join_into((v373_3).clone());
            }
            drop(v372_2_cursor);
            v371_3.join_into((v372_2).clone());
          }
          drop(v371_3_cursor);
          drop(v371_2);
          v370_3.join_into((v371_3).clone());
        }
        drop(v370_3_cursor);
        drop(v370_2);
        v369_3.join_into((v370_3).clone());
      }
      drop(v369_3_cursor);
      drop(v369_2);
      v368_2.join_into((v369_3).clone());
    }
    drop(v368_2_cursor);
    v367_5.join_into((v368_2).clone());
  }
  drop(v367_5_cursor);
  (v367_5).clone()
}

fn routine_26(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v376_5 = Space::new();
  let mut v376_5_cursor = (*s0).read_zipper();
  for v376_5_byte in v376_5_cursor.child_mask().iter() {
    v376_5_cursor.descend_to_byte(v376_5_byte);
    let v376_5_tail = v376_5_cursor.make_map();
    v376_5_cursor.ascend(1);
    let v376_5_head = Path::from_slice(&[v376_5_byte]);
    let mut v377_2 = Space::new();
    let mut v377_2_cursor = (v376_5_tail).read_zipper();
    for v377_2_byte in v377_2_cursor.child_mask().iter() {
      v377_2_cursor.descend_to_byte(v377_2_byte);
      let v377_2_tail = v377_2_cursor.make_map();
      v377_2_cursor.ascend(1);
      let v377_2_head = Path::from_slice(&[v377_2_byte]);
      let v378_2: Path = concat_path(&(v376_5_head),&(v377_2_head));
      let mut v378_3 = Space::new();
      let mut v378_3_cursor = (v377_2_tail).read_zipper();
      for v378_3_byte in v378_3_cursor.child_mask().iter() {
        v378_3_cursor.descend_to_byte(v378_3_byte);
        let v378_3_tail = v378_3_cursor.make_map();
        v378_3_cursor.ascend(1);
        let v378_3_head = Path::from_slice(&[v378_3_byte]);
        let v379_2: Path = concat_path(&(v378_2),&(v378_3_head));
        let mut v379_3 = Space::new();
        let mut v379_3_cursor = (v378_3_tail).read_zipper();
        for v379_3_byte in v379_3_cursor.child_mask().iter() {
          v379_3_cursor.descend_to_byte(v379_3_byte);
          let v379_3_tail = v379_3_cursor.make_map();
          v379_3_cursor.ascend(1);
          let v379_3_head = Path::from_slice(&[v379_3_byte]);
          let v380_2: Path = concat_path(&(v379_2),&(v379_3_head));
          let mut v380_3 = Space::new();
          let mut v380_3_cursor = (v379_3_tail).read_zipper();
          for v380_3_byte in v380_3_cursor.child_mask().iter() {
            v380_3_cursor.descend_to_byte(v380_3_byte);
            let v380_3_tail = v380_3_cursor.make_map();
            v380_3_cursor.ascend(1);
            let v380_3_head = Path::from_slice(&[v380_3_byte]);
            let mut v381_2 = Space::new();
            let mut v381_2_cursor = (v380_3_tail).read_zipper();
            for v381_2_byte in v381_2_cursor.child_mask().iter() {
              v381_2_cursor.descend_to_byte(v381_2_byte);
              let v381_2_tail = v381_2_cursor.make_map();
              v381_2_cursor.ascend(1);
              let v381_2_head = Path::from_slice(&[v381_2_byte]);
              let v382_2: Path = concat_path(&(v380_3_head),&(v381_2_head));
              let mut v382_3 = Space::new();
              let mut v382_3_cursor = (v381_2_tail).read_zipper();
              for v382_3_byte in v382_3_cursor.child_mask().iter() {
                v382_3_cursor.descend_to_byte(v382_3_byte);
                let v382_3_tail = v382_3_cursor.make_map();
                v382_3_cursor.ascend(1);
                let v382_3_head = Path::from_slice(&[v382_3_byte]);
                let v383_2: Path = concat_path(&(v382_2),&(v382_3_head));
                let mut v383_3 = Space::new();
                let mut v383_3_cursor = (v382_3_tail).read_zipper();
                for v383_3_byte in v383_3_cursor.child_mask().iter() {
                  v383_3_cursor.descend_to_byte(v383_3_byte);
                  let v383_3_tail = v383_3_cursor.make_map();
                  v383_3_cursor.ascend(1);
                  let v383_3_head = Path::from_slice(&[v383_3_byte]);
                  let v384_2: Path = concat_path(&(v383_2),&(v383_3_head));
                  let v384_3: Space = routine_35(c, &(v384_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v380_2), &(v383_3_tail));
                  drop(v384_2);
                  v383_3.join_into((v384_3).clone());
                }
                drop(v383_3_cursor);
                drop(v383_2);
                v382_3.join_into((v383_3).clone());
              }
              drop(v382_3_cursor);
              drop(v382_2);
              v381_2.join_into((v382_3).clone());
            }
            drop(v381_2_cursor);
            v380_3.join_into((v381_2).clone());
          }
          drop(v380_3_cursor);
          drop(v380_2);
          v379_3.join_into((v380_3).clone());
        }
        drop(v379_3_cursor);
        drop(v379_2);
        v378_3.join_into((v379_3).clone());
      }
      drop(v378_3_cursor);
      drop(v378_2);
      v377_2.join_into((v378_3).clone());
    }
    drop(v377_2_cursor);
    v376_5.join_into((v377_2).clone());
  }
  drop(v376_5_cursor);
  (v376_5).clone()
}

fn routine_27(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v385_5 = Space::new();
  let mut v385_5_cursor = (*s0).read_zipper();
  for v385_5_byte in v385_5_cursor.child_mask().iter() {
    v385_5_cursor.descend_to_byte(v385_5_byte);
    let v385_5_tail = v385_5_cursor.make_map();
    v385_5_cursor.ascend(1);
    let v385_5_head = Path::from_slice(&[v385_5_byte]);
    let mut v386_2 = Space::new();
    let mut v386_2_cursor = (v385_5_tail).read_zipper();
    for v386_2_byte in v386_2_cursor.child_mask().iter() {
      v386_2_cursor.descend_to_byte(v386_2_byte);
      let v386_2_tail = v386_2_cursor.make_map();
      v386_2_cursor.ascend(1);
      let v386_2_head = Path::from_slice(&[v386_2_byte]);
      let v387_2: Path = concat_path(&(v385_5_head),&(v386_2_head));
      let mut v387_3 = Space::new();
      let mut v387_3_cursor = (v386_2_tail).read_zipper();
      for v387_3_byte in v387_3_cursor.child_mask().iter() {
        v387_3_cursor.descend_to_byte(v387_3_byte);
        let v387_3_tail = v387_3_cursor.make_map();
        v387_3_cursor.ascend(1);
        let v387_3_head = Path::from_slice(&[v387_3_byte]);
        let v388_2: Path = concat_path(&(v387_2),&(v387_3_head));
        let mut v388_3 = Space::new();
        let mut v388_3_cursor = (v387_3_tail).read_zipper();
        for v388_3_byte in v388_3_cursor.child_mask().iter() {
          v388_3_cursor.descend_to_byte(v388_3_byte);
          let v388_3_tail = v388_3_cursor.make_map();
          v388_3_cursor.ascend(1);
          let v388_3_head = Path::from_slice(&[v388_3_byte]);
          let v389_2: Path = concat_path(&(v388_2),&(v388_3_head));
          let mut v389_3 = Space::new();
          let mut v389_3_cursor = (v388_3_tail).read_zipper();
          for v389_3_byte in v389_3_cursor.child_mask().iter() {
            v389_3_cursor.descend_to_byte(v389_3_byte);
            let v389_3_tail = v389_3_cursor.make_map();
            v389_3_cursor.ascend(1);
            let v389_3_head = Path::from_slice(&[v389_3_byte]);
            let mut v390_2 = Space::new();
            let mut v390_2_cursor = (v389_3_tail).read_zipper();
            for v390_2_byte in v390_2_cursor.child_mask().iter() {
              v390_2_cursor.descend_to_byte(v390_2_byte);
              let v390_2_tail = v390_2_cursor.make_map();
              v390_2_cursor.ascend(1);
              let v390_2_head = Path::from_slice(&[v390_2_byte]);
              let v391_2: Path = concat_path(&(v389_3_head),&(v390_2_head));
              let mut v391_3 = Space::new();
              let mut v391_3_cursor = (v390_2_tail).read_zipper();
              for v391_3_byte in v391_3_cursor.child_mask().iter() {
                v391_3_cursor.descend_to_byte(v391_3_byte);
                let v391_3_tail = v391_3_cursor.make_map();
                v391_3_cursor.ascend(1);
                let v391_3_head = Path::from_slice(&[v391_3_byte]);
                let v392_2: Path = concat_path(&(v391_2),&(v391_3_head));
                let mut v392_3 = Space::new();
                let mut v392_3_cursor = (v391_3_tail).read_zipper();
                for v392_3_byte in v392_3_cursor.child_mask().iter() {
                  v392_3_cursor.descend_to_byte(v392_3_byte);
                  let v392_3_tail = v392_3_cursor.make_map();
                  v392_3_cursor.ascend(1);
                  let v392_3_head = Path::from_slice(&[v392_3_byte]);
                  let v393_2: Path = concat_path(&(v392_2),&(v392_3_head));
                  let v393_3: Space = routine_36(c, &(v393_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v389_2), &(v392_3_tail));
                  drop(v393_2);
                  v392_3.join_into((v393_3).clone());
                }
                drop(v392_3_cursor);
                drop(v392_2);
                v391_3.join_into((v392_3).clone());
              }
              drop(v391_3_cursor);
              drop(v391_2);
              v390_2.join_into((v391_3).clone());
            }
            drop(v390_2_cursor);
            v389_3.join_into((v390_2).clone());
          }
          drop(v389_3_cursor);
          drop(v389_2);
          v388_3.join_into((v389_3).clone());
        }
        drop(v388_3_cursor);
        drop(v388_2);
        v387_3.join_into((v388_3).clone());
      }
      drop(v387_3_cursor);
      drop(v387_2);
      v386_2.join_into((v387_3).clone());
    }
    drop(v386_2_cursor);
    v385_5.join_into((v386_2).clone());
  }
  drop(v385_5_cursor);
  (v385_5).clone()
}

fn routine_28(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v394_5 = Space::new();
  let mut v394_5_cursor = (*s0).read_zipper();
  for v394_5_byte in v394_5_cursor.child_mask().iter() {
    v394_5_cursor.descend_to_byte(v394_5_byte);
    let v394_5_tail = v394_5_cursor.make_map();
    v394_5_cursor.ascend(1);
    let v394_5_head = Path::from_slice(&[v394_5_byte]);
    let mut v395_2 = Space::new();
    let mut v395_2_cursor = (v394_5_tail).read_zipper();
    for v395_2_byte in v395_2_cursor.child_mask().iter() {
      v395_2_cursor.descend_to_byte(v395_2_byte);
      let v395_2_tail = v395_2_cursor.make_map();
      v395_2_cursor.ascend(1);
      let v395_2_head = Path::from_slice(&[v395_2_byte]);
      let v396_2: Path = concat_path(&(v394_5_head),&(v395_2_head));
      let mut v396_3 = Space::new();
      let mut v396_3_cursor = (v395_2_tail).read_zipper();
      for v396_3_byte in v396_3_cursor.child_mask().iter() {
        v396_3_cursor.descend_to_byte(v396_3_byte);
        let v396_3_tail = v396_3_cursor.make_map();
        v396_3_cursor.ascend(1);
        let v396_3_head = Path::from_slice(&[v396_3_byte]);
        let v397_2: Path = concat_path(&(v396_2),&(v396_3_head));
        let mut v397_3 = Space::new();
        let mut v397_3_cursor = (v396_3_tail).read_zipper();
        for v397_3_byte in v397_3_cursor.child_mask().iter() {
          v397_3_cursor.descend_to_byte(v397_3_byte);
          let v397_3_tail = v397_3_cursor.make_map();
          v397_3_cursor.ascend(1);
          let v397_3_head = Path::from_slice(&[v397_3_byte]);
          let v398_2: Path = concat_path(&(v397_2),&(v397_3_head));
          let mut v398_3 = Space::new();
          let mut v398_3_cursor = (v397_3_tail).read_zipper();
          for v398_3_byte in v398_3_cursor.child_mask().iter() {
            v398_3_cursor.descend_to_byte(v398_3_byte);
            let v398_3_tail = v398_3_cursor.make_map();
            v398_3_cursor.ascend(1);
            let v398_3_head = Path::from_slice(&[v398_3_byte]);
            let mut v399_2 = Space::new();
            let mut v399_2_cursor = (v398_3_tail).read_zipper();
            for v399_2_byte in v399_2_cursor.child_mask().iter() {
              v399_2_cursor.descend_to_byte(v399_2_byte);
              let v399_2_tail = v399_2_cursor.make_map();
              v399_2_cursor.ascend(1);
              let v399_2_head = Path::from_slice(&[v399_2_byte]);
              let v400_2: Path = concat_path(&(v398_3_head),&(v399_2_head));
              let mut v400_3 = Space::new();
              let mut v400_3_cursor = (v399_2_tail).read_zipper();
              for v400_3_byte in v400_3_cursor.child_mask().iter() {
                v400_3_cursor.descend_to_byte(v400_3_byte);
                let v400_3_tail = v400_3_cursor.make_map();
                v400_3_cursor.ascend(1);
                let v400_3_head = Path::from_slice(&[v400_3_byte]);
                let v401_2: Path = concat_path(&(v400_2),&(v400_3_head));
                let mut v401_3 = Space::new();
                let mut v401_3_cursor = (v400_3_tail).read_zipper();
                for v401_3_byte in v401_3_cursor.child_mask().iter() {
                  v401_3_cursor.descend_to_byte(v401_3_byte);
                  let v401_3_tail = v401_3_cursor.make_map();
                  v401_3_cursor.ascend(1);
                  let v401_3_head = Path::from_slice(&[v401_3_byte]);
                  let v402_2: Path = concat_path(&(v401_2),&(v401_3_head));
                  let v402_3: Space = routine_37(c, &(v402_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v398_2), &(v401_3_tail));
                  drop(v402_2);
                  v401_3.join_into((v402_3).clone());
                }
                drop(v401_3_cursor);
                drop(v401_2);
                v400_3.join_into((v401_3).clone());
              }
              drop(v400_3_cursor);
              drop(v400_2);
              v399_2.join_into((v400_3).clone());
            }
            drop(v399_2_cursor);
            v398_3.join_into((v399_2).clone());
          }
          drop(v398_3_cursor);
          drop(v398_2);
          v397_3.join_into((v398_3).clone());
        }
        drop(v397_3_cursor);
        drop(v397_2);
        v396_3.join_into((v397_3).clone());
      }
      drop(v396_3_cursor);
      drop(v396_2);
      v395_2.join_into((v396_3).clone());
    }
    drop(v395_2_cursor);
    v394_5.join_into((v395_2).clone());
  }
  drop(v394_5_cursor);
  (v394_5).clone()
}

fn routine_29(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v403_7 = Space::new();
  let mut v403_7_cursor = (*s0).read_zipper();
  for v403_7_byte in v403_7_cursor.child_mask().iter() {
    v403_7_cursor.descend_to_byte(v403_7_byte);
    let v403_7_tail = v403_7_cursor.make_map();
    v403_7_cursor.ascend(1);
    let v403_7_head = Path::from_slice(&[v403_7_byte]);
    let mut v404_2 = Space::new();
    let mut v404_2_cursor = (v403_7_tail).read_zipper();
    for v404_2_byte in v404_2_cursor.child_mask().iter() {
      v404_2_cursor.descend_to_byte(v404_2_byte);
      let v404_2_tail = v404_2_cursor.make_map();
      v404_2_cursor.ascend(1);
      let v404_2_head = Path::from_slice(&[v404_2_byte]);
      let v405_2: Path = concat_path(&(v403_7_head),&(v404_2_head));
      let mut v405_3 = Space::new();
      let mut v405_3_cursor = (v404_2_tail).read_zipper();
      for v405_3_byte in v405_3_cursor.child_mask().iter() {
        v405_3_cursor.descend_to_byte(v405_3_byte);
        let v405_3_tail = v405_3_cursor.make_map();
        v405_3_cursor.ascend(1);
        let v405_3_head = Path::from_slice(&[v405_3_byte]);
        let v406_2: Path = concat_path(&(v405_2),&(v405_3_head));
        let mut v406_3 = Space::new();
        let mut v406_3_cursor = (v405_3_tail).read_zipper();
        for v406_3_byte in v406_3_cursor.child_mask().iter() {
          v406_3_cursor.descend_to_byte(v406_3_byte);
          let v406_3_tail = v406_3_cursor.make_map();
          v406_3_cursor.ascend(1);
          let v406_3_head = Path::from_slice(&[v406_3_byte]);
          let v407_2: Path = concat_path(&(v406_2),&(v406_3_head));
          let mut v407_3 = Space::new();
          let mut v407_3_cursor = (v406_3_tail).read_zipper();
          for v407_3_byte in v407_3_cursor.child_mask().iter() {
            v407_3_cursor.descend_to_byte(v407_3_byte);
            let v407_3_tail = v407_3_cursor.make_map();
            v407_3_cursor.ascend(1);
            let v407_3_head = Path::from_slice(&[v407_3_byte]);
            let mut v408_2 = Space::new();
            let mut v408_2_cursor = (v407_3_tail).read_zipper();
            for v408_2_byte in v408_2_cursor.child_mask().iter() {
              v408_2_cursor.descend_to_byte(v408_2_byte);
              let v408_2_tail = v408_2_cursor.make_map();
              v408_2_cursor.ascend(1);
              let v408_2_head = Path::from_slice(&[v408_2_byte]);
              let v409_2: Path = concat_path(&(v407_3_head),&(v408_2_head));
              let mut v409_3 = Space::new();
              let mut v409_3_cursor = (v408_2_tail).read_zipper();
              for v409_3_byte in v409_3_cursor.child_mask().iter() {
                v409_3_cursor.descend_to_byte(v409_3_byte);
                let v409_3_tail = v409_3_cursor.make_map();
                v409_3_cursor.ascend(1);
                let v409_3_head = Path::from_slice(&[v409_3_byte]);
                let v410_2: Path = concat_path(&(v409_2),&(v409_3_head));
                let mut v410_3 = Space::new();
                let mut v410_3_cursor = (v409_3_tail).read_zipper();
                for v410_3_byte in v410_3_cursor.child_mask().iter() {
                  v410_3_cursor.descend_to_byte(v410_3_byte);
                  let v410_3_tail = v410_3_cursor.make_map();
                  v410_3_cursor.ascend(1);
                  let v410_3_head = Path::from_slice(&[v410_3_byte]);
                  let v411_2: Path = concat_path(&(v410_2),&(v410_3_head));
                  let v411_3: Space = routine_38(c, &(v411_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v407_2), &(v410_3_tail));
                  drop(v411_2);
                  v410_3.join_into((v411_3).clone());
                }
                drop(v410_3_cursor);
                drop(v410_2);
                v409_3.join_into((v410_3).clone());
              }
              drop(v409_3_cursor);
              drop(v409_2);
              v408_2.join_into((v409_3).clone());
            }
            drop(v408_2_cursor);
            v407_3.join_into((v408_2).clone());
          }
          drop(v407_3_cursor);
          drop(v407_2);
          v406_3.join_into((v407_3).clone());
        }
        drop(v406_3_cursor);
        drop(v406_2);
        v405_3.join_into((v406_3).clone());
      }
      drop(v405_3_cursor);
      drop(v405_2);
      v404_2.join_into((v405_3).clone());
    }
    drop(v404_2_cursor);
    v403_7.join_into((v404_2).clone());
  }
  drop(v403_7_cursor);
  (v403_7).clone()
}

fn routine_30(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v412_7 = Space::new();
  let mut v412_7_cursor = (*s0).read_zipper();
  for v412_7_byte in v412_7_cursor.child_mask().iter() {
    v412_7_cursor.descend_to_byte(v412_7_byte);
    let v412_7_tail = v412_7_cursor.make_map();
    v412_7_cursor.ascend(1);
    let v412_7_head = Path::from_slice(&[v412_7_byte]);
    let mut v413_2 = Space::new();
    let mut v413_2_cursor = (v412_7_tail).read_zipper();
    for v413_2_byte in v413_2_cursor.child_mask().iter() {
      v413_2_cursor.descend_to_byte(v413_2_byte);
      let v413_2_tail = v413_2_cursor.make_map();
      v413_2_cursor.ascend(1);
      let v413_2_head = Path::from_slice(&[v413_2_byte]);
      let v414_2: Path = concat_path(&(v412_7_head),&(v413_2_head));
      let mut v414_3 = Space::new();
      let mut v414_3_cursor = (v413_2_tail).read_zipper();
      for v414_3_byte in v414_3_cursor.child_mask().iter() {
        v414_3_cursor.descend_to_byte(v414_3_byte);
        let v414_3_tail = v414_3_cursor.make_map();
        v414_3_cursor.ascend(1);
        let v414_3_head = Path::from_slice(&[v414_3_byte]);
        let v415_2: Path = concat_path(&(v414_2),&(v414_3_head));
        let mut v415_3 = Space::new();
        let mut v415_3_cursor = (v414_3_tail).read_zipper();
        for v415_3_byte in v415_3_cursor.child_mask().iter() {
          v415_3_cursor.descend_to_byte(v415_3_byte);
          let v415_3_tail = v415_3_cursor.make_map();
          v415_3_cursor.ascend(1);
          let v415_3_head = Path::from_slice(&[v415_3_byte]);
          let v416_2: Path = concat_path(&(v415_2),&(v415_3_head));
          let mut v416_3 = Space::new();
          let mut v416_3_cursor = (v415_3_tail).read_zipper();
          for v416_3_byte in v416_3_cursor.child_mask().iter() {
            v416_3_cursor.descend_to_byte(v416_3_byte);
            let v416_3_tail = v416_3_cursor.make_map();
            v416_3_cursor.ascend(1);
            let v416_3_head = Path::from_slice(&[v416_3_byte]);
            let mut v417_2 = Space::new();
            let mut v417_2_cursor = (v416_3_tail).read_zipper();
            for v417_2_byte in v417_2_cursor.child_mask().iter() {
              v417_2_cursor.descend_to_byte(v417_2_byte);
              let v417_2_tail = v417_2_cursor.make_map();
              v417_2_cursor.ascend(1);
              let v417_2_head = Path::from_slice(&[v417_2_byte]);
              let v418_2: Path = concat_path(&(v416_3_head),&(v417_2_head));
              let mut v418_3 = Space::new();
              let mut v418_3_cursor = (v417_2_tail).read_zipper();
              for v418_3_byte in v418_3_cursor.child_mask().iter() {
                v418_3_cursor.descend_to_byte(v418_3_byte);
                let v418_3_tail = v418_3_cursor.make_map();
                v418_3_cursor.ascend(1);
                let v418_3_head = Path::from_slice(&[v418_3_byte]);
                let v419_2: Path = concat_path(&(v418_2),&(v418_3_head));
                let mut v419_3 = Space::new();
                let mut v419_3_cursor = (v418_3_tail).read_zipper();
                for v419_3_byte in v419_3_cursor.child_mask().iter() {
                  v419_3_cursor.descend_to_byte(v419_3_byte);
                  let v419_3_tail = v419_3_cursor.make_map();
                  v419_3_cursor.ascend(1);
                  let v419_3_head = Path::from_slice(&[v419_3_byte]);
                  let v420_2: Path = concat_path(&(v419_2),&(v419_3_head));
                  let v420_3: Space = routine_39(c, &(v420_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v416_2), &(v419_3_tail));
                  drop(v420_2);
                  v419_3.join_into((v420_3).clone());
                }
                drop(v419_3_cursor);
                drop(v419_2);
                v418_3.join_into((v419_3).clone());
              }
              drop(v418_3_cursor);
              drop(v418_2);
              v417_2.join_into((v418_3).clone());
            }
            drop(v417_2_cursor);
            v416_3.join_into((v417_2).clone());
          }
          drop(v416_3_cursor);
          drop(v416_2);
          v415_3.join_into((v416_3).clone());
        }
        drop(v415_3_cursor);
        drop(v415_2);
        v414_3.join_into((v415_3).clone());
      }
      drop(v414_3_cursor);
      drop(v414_2);
      v413_2.join_into((v414_3).clone());
    }
    drop(v413_2_cursor);
    v412_7.join_into((v413_2).clone());
  }
  drop(v412_7_cursor);
  (v412_7).clone()
}

fn routine_31(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v421_7 = Space::new();
  let mut v421_7_cursor = (*s0).read_zipper();
  for v421_7_byte in v421_7_cursor.child_mask().iter() {
    v421_7_cursor.descend_to_byte(v421_7_byte);
    let v421_7_tail = v421_7_cursor.make_map();
    v421_7_cursor.ascend(1);
    let v421_7_head = Path::from_slice(&[v421_7_byte]);
    let mut v422_2 = Space::new();
    let mut v422_2_cursor = (v421_7_tail).read_zipper();
    for v422_2_byte in v422_2_cursor.child_mask().iter() {
      v422_2_cursor.descend_to_byte(v422_2_byte);
      let v422_2_tail = v422_2_cursor.make_map();
      v422_2_cursor.ascend(1);
      let v422_2_head = Path::from_slice(&[v422_2_byte]);
      let v423_2: Path = concat_path(&(v421_7_head),&(v422_2_head));
      let mut v423_3 = Space::new();
      let mut v423_3_cursor = (v422_2_tail).read_zipper();
      for v423_3_byte in v423_3_cursor.child_mask().iter() {
        v423_3_cursor.descend_to_byte(v423_3_byte);
        let v423_3_tail = v423_3_cursor.make_map();
        v423_3_cursor.ascend(1);
        let v423_3_head = Path::from_slice(&[v423_3_byte]);
        let v424_2: Path = concat_path(&(v423_2),&(v423_3_head));
        let mut v424_3 = Space::new();
        let mut v424_3_cursor = (v423_3_tail).read_zipper();
        for v424_3_byte in v424_3_cursor.child_mask().iter() {
          v424_3_cursor.descend_to_byte(v424_3_byte);
          let v424_3_tail = v424_3_cursor.make_map();
          v424_3_cursor.ascend(1);
          let v424_3_head = Path::from_slice(&[v424_3_byte]);
          let v425_2: Path = concat_path(&(v424_2),&(v424_3_head));
          let mut v425_3 = Space::new();
          let mut v425_3_cursor = (v424_3_tail).read_zipper();
          for v425_3_byte in v425_3_cursor.child_mask().iter() {
            v425_3_cursor.descend_to_byte(v425_3_byte);
            let v425_3_tail = v425_3_cursor.make_map();
            v425_3_cursor.ascend(1);
            let v425_3_head = Path::from_slice(&[v425_3_byte]);
            let mut v426_2 = Space::new();
            let mut v426_2_cursor = (v425_3_tail).read_zipper();
            for v426_2_byte in v426_2_cursor.child_mask().iter() {
              v426_2_cursor.descend_to_byte(v426_2_byte);
              let v426_2_tail = v426_2_cursor.make_map();
              v426_2_cursor.ascend(1);
              let v426_2_head = Path::from_slice(&[v426_2_byte]);
              let v427_2: Path = concat_path(&(v425_3_head),&(v426_2_head));
              let mut v427_3 = Space::new();
              let mut v427_3_cursor = (v426_2_tail).read_zipper();
              for v427_3_byte in v427_3_cursor.child_mask().iter() {
                v427_3_cursor.descend_to_byte(v427_3_byte);
                let v427_3_tail = v427_3_cursor.make_map();
                v427_3_cursor.ascend(1);
                let v427_3_head = Path::from_slice(&[v427_3_byte]);
                let v428_2: Path = concat_path(&(v427_2),&(v427_3_head));
                let mut v428_3 = Space::new();
                let mut v428_3_cursor = (v427_3_tail).read_zipper();
                for v428_3_byte in v428_3_cursor.child_mask().iter() {
                  v428_3_cursor.descend_to_byte(v428_3_byte);
                  let v428_3_tail = v428_3_cursor.make_map();
                  v428_3_cursor.ascend(1);
                  let v428_3_head = Path::from_slice(&[v428_3_byte]);
                  let v429_2: Path = concat_path(&(v428_2),&(v428_3_head));
                  let v429_3: Space = routine_40(c, &(v429_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v425_2), &(v428_3_tail));
                  drop(v429_2);
                  v428_3.join_into((v429_3).clone());
                }
                drop(v428_3_cursor);
                drop(v428_2);
                v427_3.join_into((v428_3).clone());
              }
              drop(v427_3_cursor);
              drop(v427_2);
              v426_2.join_into((v427_3).clone());
            }
            drop(v426_2_cursor);
            v425_3.join_into((v426_2).clone());
          }
          drop(v425_3_cursor);
          drop(v425_2);
          v424_3.join_into((v425_3).clone());
        }
        drop(v424_3_cursor);
        drop(v424_2);
        v423_3.join_into((v424_3).clone());
      }
      drop(v423_3_cursor);
      drop(v423_2);
      v422_2.join_into((v423_3).clone());
    }
    drop(v422_2_cursor);
    v421_7.join_into((v422_2).clone());
  }
  drop(v421_7_cursor);
  (v421_7).clone()
}

fn routine_32(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v430_7 = Space::new();
  let mut v430_7_cursor = (*s0).read_zipper();
  for v430_7_byte in v430_7_cursor.child_mask().iter() {
    v430_7_cursor.descend_to_byte(v430_7_byte);
    let v430_7_tail = v430_7_cursor.make_map();
    v430_7_cursor.ascend(1);
    let v430_7_head = Path::from_slice(&[v430_7_byte]);
    let mut v431_2 = Space::new();
    let mut v431_2_cursor = (v430_7_tail).read_zipper();
    for v431_2_byte in v431_2_cursor.child_mask().iter() {
      v431_2_cursor.descend_to_byte(v431_2_byte);
      let v431_2_tail = v431_2_cursor.make_map();
      v431_2_cursor.ascend(1);
      let v431_2_head = Path::from_slice(&[v431_2_byte]);
      let v432_2: Path = concat_path(&(v430_7_head),&(v431_2_head));
      let mut v432_3 = Space::new();
      let mut v432_3_cursor = (v431_2_tail).read_zipper();
      for v432_3_byte in v432_3_cursor.child_mask().iter() {
        v432_3_cursor.descend_to_byte(v432_3_byte);
        let v432_3_tail = v432_3_cursor.make_map();
        v432_3_cursor.ascend(1);
        let v432_3_head = Path::from_slice(&[v432_3_byte]);
        let v433_2: Path = concat_path(&(v432_2),&(v432_3_head));
        let mut v433_3 = Space::new();
        let mut v433_3_cursor = (v432_3_tail).read_zipper();
        for v433_3_byte in v433_3_cursor.child_mask().iter() {
          v433_3_cursor.descend_to_byte(v433_3_byte);
          let v433_3_tail = v433_3_cursor.make_map();
          v433_3_cursor.ascend(1);
          let v433_3_head = Path::from_slice(&[v433_3_byte]);
          let v434_2: Path = concat_path(&(v433_2),&(v433_3_head));
          let mut v434_3 = Space::new();
          let mut v434_3_cursor = (v433_3_tail).read_zipper();
          for v434_3_byte in v434_3_cursor.child_mask().iter() {
            v434_3_cursor.descend_to_byte(v434_3_byte);
            let v434_3_tail = v434_3_cursor.make_map();
            v434_3_cursor.ascend(1);
            let v434_3_head = Path::from_slice(&[v434_3_byte]);
            let mut v435_2 = Space::new();
            let mut v435_2_cursor = (v434_3_tail).read_zipper();
            for v435_2_byte in v435_2_cursor.child_mask().iter() {
              v435_2_cursor.descend_to_byte(v435_2_byte);
              let v435_2_tail = v435_2_cursor.make_map();
              v435_2_cursor.ascend(1);
              let v435_2_head = Path::from_slice(&[v435_2_byte]);
              let v436_2: Path = concat_path(&(v434_3_head),&(v435_2_head));
              let mut v436_3 = Space::new();
              let mut v436_3_cursor = (v435_2_tail).read_zipper();
              for v436_3_byte in v436_3_cursor.child_mask().iter() {
                v436_3_cursor.descend_to_byte(v436_3_byte);
                let v436_3_tail = v436_3_cursor.make_map();
                v436_3_cursor.ascend(1);
                let v436_3_head = Path::from_slice(&[v436_3_byte]);
                let v437_2: Path = concat_path(&(v436_2),&(v436_3_head));
                let mut v437_3 = Space::new();
                let mut v437_3_cursor = (v436_3_tail).read_zipper();
                for v437_3_byte in v437_3_cursor.child_mask().iter() {
                  v437_3_cursor.descend_to_byte(v437_3_byte);
                  let v437_3_tail = v437_3_cursor.make_map();
                  v437_3_cursor.ascend(1);
                  let v437_3_head = Path::from_slice(&[v437_3_byte]);
                  let v438_2: Path = concat_path(&(v437_2),&(v437_3_head));
                  let v438_3: Space = routine_41(c, &(v438_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v434_2), &(v437_3_tail));
                  drop(v438_2);
                  v437_3.join_into((v438_3).clone());
                }
                drop(v437_3_cursor);
                drop(v437_2);
                v436_3.join_into((v437_3).clone());
              }
              drop(v436_3_cursor);
              drop(v436_2);
              v435_2.join_into((v436_3).clone());
            }
            drop(v435_2_cursor);
            v434_3.join_into((v435_2).clone());
          }
          drop(v434_3_cursor);
          drop(v434_2);
          v433_3.join_into((v434_3).clone());
        }
        drop(v433_3_cursor);
        drop(v433_2);
        v432_3.join_into((v433_3).clone());
      }
      drop(v432_3_cursor);
      drop(v432_2);
      v431_2.join_into((v432_3).clone());
    }
    drop(v431_2_cursor);
    v430_7.join_into((v431_2).clone());
  }
  drop(v430_7_cursor);
  (v430_7).clone()
}

fn routine_33(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v439_7 = Space::new();
  let mut v439_7_cursor = (*s0).read_zipper();
  for v439_7_byte in v439_7_cursor.child_mask().iter() {
    v439_7_cursor.descend_to_byte(v439_7_byte);
    let v439_7_tail = v439_7_cursor.make_map();
    v439_7_cursor.ascend(1);
    let v439_7_head = Path::from_slice(&[v439_7_byte]);
    let mut v440_2 = Space::new();
    let mut v440_2_cursor = (v439_7_tail).read_zipper();
    for v440_2_byte in v440_2_cursor.child_mask().iter() {
      v440_2_cursor.descend_to_byte(v440_2_byte);
      let v440_2_tail = v440_2_cursor.make_map();
      v440_2_cursor.ascend(1);
      let v440_2_head = Path::from_slice(&[v440_2_byte]);
      let v441_2: Path = concat_path(&(v439_7_head),&(v440_2_head));
      let mut v441_3 = Space::new();
      let mut v441_3_cursor = (v440_2_tail).read_zipper();
      for v441_3_byte in v441_3_cursor.child_mask().iter() {
        v441_3_cursor.descend_to_byte(v441_3_byte);
        let v441_3_tail = v441_3_cursor.make_map();
        v441_3_cursor.ascend(1);
        let v441_3_head = Path::from_slice(&[v441_3_byte]);
        let v442_2: Path = concat_path(&(v441_2),&(v441_3_head));
        let mut v442_3 = Space::new();
        let mut v442_3_cursor = (v441_3_tail).read_zipper();
        for v442_3_byte in v442_3_cursor.child_mask().iter() {
          v442_3_cursor.descend_to_byte(v442_3_byte);
          let v442_3_tail = v442_3_cursor.make_map();
          v442_3_cursor.ascend(1);
          let v442_3_head = Path::from_slice(&[v442_3_byte]);
          let v443_2: Path = concat_path(&(v442_2),&(v442_3_head));
          let mut v443_3 = Space::new();
          let mut v443_3_cursor = (v442_3_tail).read_zipper();
          for v443_3_byte in v443_3_cursor.child_mask().iter() {
            v443_3_cursor.descend_to_byte(v443_3_byte);
            let v443_3_tail = v443_3_cursor.make_map();
            v443_3_cursor.ascend(1);
            let v443_3_head = Path::from_slice(&[v443_3_byte]);
            let mut v444_2 = Space::new();
            let mut v444_2_cursor = (v443_3_tail).read_zipper();
            for v444_2_byte in v444_2_cursor.child_mask().iter() {
              v444_2_cursor.descend_to_byte(v444_2_byte);
              let v444_2_tail = v444_2_cursor.make_map();
              v444_2_cursor.ascend(1);
              let v444_2_head = Path::from_slice(&[v444_2_byte]);
              let v445_2: Path = concat_path(&(v443_3_head),&(v444_2_head));
              let mut v445_3 = Space::new();
              let mut v445_3_cursor = (v444_2_tail).read_zipper();
              for v445_3_byte in v445_3_cursor.child_mask().iter() {
                v445_3_cursor.descend_to_byte(v445_3_byte);
                let v445_3_tail = v445_3_cursor.make_map();
                v445_3_cursor.ascend(1);
                let v445_3_head = Path::from_slice(&[v445_3_byte]);
                let v446_2: Path = concat_path(&(v445_2),&(v445_3_head));
                let mut v446_3 = Space::new();
                let mut v446_3_cursor = (v445_3_tail).read_zipper();
                for v446_3_byte in v446_3_cursor.child_mask().iter() {
                  v446_3_cursor.descend_to_byte(v446_3_byte);
                  let v446_3_tail = v446_3_cursor.make_map();
                  v446_3_cursor.ascend(1);
                  let v446_3_head = Path::from_slice(&[v446_3_byte]);
                  let v447_2: Path = concat_path(&(v446_2),&(v446_3_head));
                  let v447_3: Space = routine_42(c, &(v447_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v443_2), &(v446_3_tail));
                  drop(v447_2);
                  v446_3.join_into((v447_3).clone());
                }
                drop(v446_3_cursor);
                drop(v446_2);
                v445_3.join_into((v446_3).clone());
              }
              drop(v445_3_cursor);
              drop(v445_2);
              v444_2.join_into((v445_3).clone());
            }
            drop(v444_2_cursor);
            v443_3.join_into((v444_2).clone());
          }
          drop(v443_3_cursor);
          drop(v443_2);
          v442_3.join_into((v443_3).clone());
        }
        drop(v442_3_cursor);
        drop(v442_2);
        v441_3.join_into((v442_3).clone());
      }
      drop(v441_3_cursor);
      drop(v441_2);
      v440_2.join_into((v441_3).clone());
    }
    drop(v440_2_cursor);
    v439_7.join_into((v440_2).clone());
  }
  drop(v439_7_cursor);
  (v439_7).clone()
}

fn routine_34(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v448_7 = Space::new();
  let mut v448_7_cursor = (*s0).read_zipper();
  for v448_7_byte in v448_7_cursor.child_mask().iter() {
    v448_7_cursor.descend_to_byte(v448_7_byte);
    let v448_7_tail = v448_7_cursor.make_map();
    v448_7_cursor.ascend(1);
    let v448_7_head = Path::from_slice(&[v448_7_byte]);
    let mut v449_2 = Space::new();
    let mut v449_2_cursor = (v448_7_tail).read_zipper();
    for v449_2_byte in v449_2_cursor.child_mask().iter() {
      v449_2_cursor.descend_to_byte(v449_2_byte);
      let v449_2_tail = v449_2_cursor.make_map();
      v449_2_cursor.ascend(1);
      let v449_2_head = Path::from_slice(&[v449_2_byte]);
      let v450_2: Path = concat_path(&(v448_7_head),&(v449_2_head));
      let mut v450_3 = Space::new();
      let mut v450_3_cursor = (v449_2_tail).read_zipper();
      for v450_3_byte in v450_3_cursor.child_mask().iter() {
        v450_3_cursor.descend_to_byte(v450_3_byte);
        let v450_3_tail = v450_3_cursor.make_map();
        v450_3_cursor.ascend(1);
        let v450_3_head = Path::from_slice(&[v450_3_byte]);
        let v451_2: Path = concat_path(&(v450_2),&(v450_3_head));
        let mut v451_3 = Space::new();
        let mut v451_3_cursor = (v450_3_tail).read_zipper();
        for v451_3_byte in v451_3_cursor.child_mask().iter() {
          v451_3_cursor.descend_to_byte(v451_3_byte);
          let v451_3_tail = v451_3_cursor.make_map();
          v451_3_cursor.ascend(1);
          let v451_3_head = Path::from_slice(&[v451_3_byte]);
          let v452_2: Path = concat_path(&(v451_2),&(v451_3_head));
          let mut v452_3 = Space::new();
          let mut v452_3_cursor = (v451_3_tail).read_zipper();
          for v452_3_byte in v452_3_cursor.child_mask().iter() {
            v452_3_cursor.descend_to_byte(v452_3_byte);
            let v452_3_tail = v452_3_cursor.make_map();
            v452_3_cursor.ascend(1);
            let v452_3_head = Path::from_slice(&[v452_3_byte]);
            let mut v453_2 = Space::new();
            let mut v453_2_cursor = (v452_3_tail).read_zipper();
            for v453_2_byte in v453_2_cursor.child_mask().iter() {
              v453_2_cursor.descend_to_byte(v453_2_byte);
              let v453_2_tail = v453_2_cursor.make_map();
              v453_2_cursor.ascend(1);
              let v453_2_head = Path::from_slice(&[v453_2_byte]);
              let v454_2: Path = concat_path(&(v452_3_head),&(v453_2_head));
              let mut v454_3 = Space::new();
              let mut v454_3_cursor = (v453_2_tail).read_zipper();
              for v454_3_byte in v454_3_cursor.child_mask().iter() {
                v454_3_cursor.descend_to_byte(v454_3_byte);
                let v454_3_tail = v454_3_cursor.make_map();
                v454_3_cursor.ascend(1);
                let v454_3_head = Path::from_slice(&[v454_3_byte]);
                let v455_2: Path = concat_path(&(v454_2),&(v454_3_head));
                let mut v455_3 = Space::new();
                let mut v455_3_cursor = (v454_3_tail).read_zipper();
                for v455_3_byte in v455_3_cursor.child_mask().iter() {
                  v455_3_cursor.descend_to_byte(v455_3_byte);
                  let v455_3_tail = v455_3_cursor.make_map();
                  v455_3_cursor.ascend(1);
                  let v455_3_head = Path::from_slice(&[v455_3_byte]);
                  let v456_2: Path = concat_path(&(v455_2),&(v455_3_head));
                  let v456_3: Space = routine_43(c, &(v456_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v452_2), &(v455_3_tail));
                  drop(v456_2);
                  v455_3.join_into((v456_3).clone());
                }
                drop(v455_3_cursor);
                drop(v455_2);
                v454_3.join_into((v455_3).clone());
              }
              drop(v454_3_cursor);
              drop(v454_2);
              v453_2.join_into((v454_3).clone());
            }
            drop(v453_2_cursor);
            v452_3.join_into((v453_2).clone());
          }
          drop(v452_3_cursor);
          drop(v452_2);
          v451_3.join_into((v452_3).clone());
        }
        drop(v451_3_cursor);
        drop(v451_2);
        v450_3.join_into((v451_3).clone());
      }
      drop(v450_3_cursor);
      drop(v450_2);
      v449_2.join_into((v450_3).clone());
    }
    drop(v449_2_cursor);
    v448_7.join_into((v449_2).clone());
  }
  drop(v448_7_cursor);
  (v448_7).clone()
}

fn routine_35(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v457_7 = Space::new();
  let mut v457_7_cursor = (*s0).read_zipper();
  for v457_7_byte in v457_7_cursor.child_mask().iter() {
    v457_7_cursor.descend_to_byte(v457_7_byte);
    let v457_7_tail = v457_7_cursor.make_map();
    v457_7_cursor.ascend(1);
    let v457_7_head = Path::from_slice(&[v457_7_byte]);
    let mut v458_2 = Space::new();
    let mut v458_2_cursor = (v457_7_tail).read_zipper();
    for v458_2_byte in v458_2_cursor.child_mask().iter() {
      v458_2_cursor.descend_to_byte(v458_2_byte);
      let v458_2_tail = v458_2_cursor.make_map();
      v458_2_cursor.ascend(1);
      let v458_2_head = Path::from_slice(&[v458_2_byte]);
      let v459_2: Path = concat_path(&(v457_7_head),&(v458_2_head));
      let mut v459_3 = Space::new();
      let mut v459_3_cursor = (v458_2_tail).read_zipper();
      for v459_3_byte in v459_3_cursor.child_mask().iter() {
        v459_3_cursor.descend_to_byte(v459_3_byte);
        let v459_3_tail = v459_3_cursor.make_map();
        v459_3_cursor.ascend(1);
        let v459_3_head = Path::from_slice(&[v459_3_byte]);
        let v460_2: Path = concat_path(&(v459_2),&(v459_3_head));
        let mut v460_3 = Space::new();
        let mut v460_3_cursor = (v459_3_tail).read_zipper();
        for v460_3_byte in v460_3_cursor.child_mask().iter() {
          v460_3_cursor.descend_to_byte(v460_3_byte);
          let v460_3_tail = v460_3_cursor.make_map();
          v460_3_cursor.ascend(1);
          let v460_3_head = Path::from_slice(&[v460_3_byte]);
          let v461_2: Path = concat_path(&(v460_2),&(v460_3_head));
          let mut v461_3 = Space::new();
          let mut v461_3_cursor = (v460_3_tail).read_zipper();
          for v461_3_byte in v461_3_cursor.child_mask().iter() {
            v461_3_cursor.descend_to_byte(v461_3_byte);
            let v461_3_tail = v461_3_cursor.make_map();
            v461_3_cursor.ascend(1);
            let v461_3_head = Path::from_slice(&[v461_3_byte]);
            let mut v462_2 = Space::new();
            let mut v462_2_cursor = (v461_3_tail).read_zipper();
            for v462_2_byte in v462_2_cursor.child_mask().iter() {
              v462_2_cursor.descend_to_byte(v462_2_byte);
              let v462_2_tail = v462_2_cursor.make_map();
              v462_2_cursor.ascend(1);
              let v462_2_head = Path::from_slice(&[v462_2_byte]);
              let v463_2: Path = concat_path(&(v461_3_head),&(v462_2_head));
              let mut v463_3 = Space::new();
              let mut v463_3_cursor = (v462_2_tail).read_zipper();
              for v463_3_byte in v463_3_cursor.child_mask().iter() {
                v463_3_cursor.descend_to_byte(v463_3_byte);
                let v463_3_tail = v463_3_cursor.make_map();
                v463_3_cursor.ascend(1);
                let v463_3_head = Path::from_slice(&[v463_3_byte]);
                let v464_2: Path = concat_path(&(v463_2),&(v463_3_head));
                let mut v464_3 = Space::new();
                let mut v464_3_cursor = (v463_3_tail).read_zipper();
                for v464_3_byte in v464_3_cursor.child_mask().iter() {
                  v464_3_cursor.descend_to_byte(v464_3_byte);
                  let v464_3_tail = v464_3_cursor.make_map();
                  v464_3_cursor.ascend(1);
                  let v464_3_head = Path::from_slice(&[v464_3_byte]);
                  let v465_2: Path = concat_path(&(v464_2),&(v464_3_head));
                  let v465_3: Space = routine_44(c, &(v465_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v461_2), &(v464_3_tail));
                  drop(v465_2);
                  v464_3.join_into((v465_3).clone());
                }
                drop(v464_3_cursor);
                drop(v464_2);
                v463_3.join_into((v464_3).clone());
              }
              drop(v463_3_cursor);
              drop(v463_2);
              v462_2.join_into((v463_3).clone());
            }
            drop(v462_2_cursor);
            v461_3.join_into((v462_2).clone());
          }
          drop(v461_3_cursor);
          drop(v461_2);
          v460_3.join_into((v461_3).clone());
        }
        drop(v460_3_cursor);
        drop(v460_2);
        v459_3.join_into((v460_3).clone());
      }
      drop(v459_3_cursor);
      drop(v459_2);
      v458_2.join_into((v459_3).clone());
    }
    drop(v458_2_cursor);
    v457_7.join_into((v458_2).clone());
  }
  drop(v457_7_cursor);
  (v457_7).clone()
}

fn routine_36(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v466_7 = Space::new();
  let mut v466_7_cursor = (*s0).read_zipper();
  for v466_7_byte in v466_7_cursor.child_mask().iter() {
    v466_7_cursor.descend_to_byte(v466_7_byte);
    let v466_7_tail = v466_7_cursor.make_map();
    v466_7_cursor.ascend(1);
    let v466_7_head = Path::from_slice(&[v466_7_byte]);
    let mut v467_2 = Space::new();
    let mut v467_2_cursor = (v466_7_tail).read_zipper();
    for v467_2_byte in v467_2_cursor.child_mask().iter() {
      v467_2_cursor.descend_to_byte(v467_2_byte);
      let v467_2_tail = v467_2_cursor.make_map();
      v467_2_cursor.ascend(1);
      let v467_2_head = Path::from_slice(&[v467_2_byte]);
      let v468_2: Path = concat_path(&(v466_7_head),&(v467_2_head));
      let mut v468_3 = Space::new();
      let mut v468_3_cursor = (v467_2_tail).read_zipper();
      for v468_3_byte in v468_3_cursor.child_mask().iter() {
        v468_3_cursor.descend_to_byte(v468_3_byte);
        let v468_3_tail = v468_3_cursor.make_map();
        v468_3_cursor.ascend(1);
        let v468_3_head = Path::from_slice(&[v468_3_byte]);
        let v469_2: Path = concat_path(&(v468_2),&(v468_3_head));
        let mut v469_3 = Space::new();
        let mut v469_3_cursor = (v468_3_tail).read_zipper();
        for v469_3_byte in v469_3_cursor.child_mask().iter() {
          v469_3_cursor.descend_to_byte(v469_3_byte);
          let v469_3_tail = v469_3_cursor.make_map();
          v469_3_cursor.ascend(1);
          let v469_3_head = Path::from_slice(&[v469_3_byte]);
          let v470_2: Path = concat_path(&(v469_2),&(v469_3_head));
          let mut v470_3 = Space::new();
          let mut v470_3_cursor = (v469_3_tail).read_zipper();
          for v470_3_byte in v470_3_cursor.child_mask().iter() {
            v470_3_cursor.descend_to_byte(v470_3_byte);
            let v470_3_tail = v470_3_cursor.make_map();
            v470_3_cursor.ascend(1);
            let v470_3_head = Path::from_slice(&[v470_3_byte]);
            let mut v471_2 = Space::new();
            let mut v471_2_cursor = (v470_3_tail).read_zipper();
            for v471_2_byte in v471_2_cursor.child_mask().iter() {
              v471_2_cursor.descend_to_byte(v471_2_byte);
              let v471_2_tail = v471_2_cursor.make_map();
              v471_2_cursor.ascend(1);
              let v471_2_head = Path::from_slice(&[v471_2_byte]);
              let v472_2: Path = concat_path(&(v470_3_head),&(v471_2_head));
              let mut v472_3 = Space::new();
              let mut v472_3_cursor = (v471_2_tail).read_zipper();
              for v472_3_byte in v472_3_cursor.child_mask().iter() {
                v472_3_cursor.descend_to_byte(v472_3_byte);
                let v472_3_tail = v472_3_cursor.make_map();
                v472_3_cursor.ascend(1);
                let v472_3_head = Path::from_slice(&[v472_3_byte]);
                let v473_2: Path = concat_path(&(v472_2),&(v472_3_head));
                let mut v473_3 = Space::new();
                let mut v473_3_cursor = (v472_3_tail).read_zipper();
                for v473_3_byte in v473_3_cursor.child_mask().iter() {
                  v473_3_cursor.descend_to_byte(v473_3_byte);
                  let v473_3_tail = v473_3_cursor.make_map();
                  v473_3_cursor.ascend(1);
                  let v473_3_head = Path::from_slice(&[v473_3_byte]);
                  let v474_2: Path = concat_path(&(v473_2),&(v473_3_head));
                  let v474_3: Space = routine_45(c, &(v474_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v470_2), &(v473_3_tail));
                  drop(v474_2);
                  v473_3.join_into((v474_3).clone());
                }
                drop(v473_3_cursor);
                drop(v473_2);
                v472_3.join_into((v473_3).clone());
              }
              drop(v472_3_cursor);
              drop(v472_2);
              v471_2.join_into((v472_3).clone());
            }
            drop(v471_2_cursor);
            v470_3.join_into((v471_2).clone());
          }
          drop(v470_3_cursor);
          drop(v470_2);
          v469_3.join_into((v470_3).clone());
        }
        drop(v469_3_cursor);
        drop(v469_2);
        v468_3.join_into((v469_3).clone());
      }
      drop(v468_3_cursor);
      drop(v468_2);
      v467_2.join_into((v468_3).clone());
    }
    drop(v467_2_cursor);
    v466_7.join_into((v467_2).clone());
  }
  drop(v466_7_cursor);
  (v466_7).clone()
}

fn routine_37(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v475_7 = Space::new();
  let mut v475_7_cursor = (*s0).read_zipper();
  for v475_7_byte in v475_7_cursor.child_mask().iter() {
    v475_7_cursor.descend_to_byte(v475_7_byte);
    let v475_7_tail = v475_7_cursor.make_map();
    v475_7_cursor.ascend(1);
    let v475_7_head = Path::from_slice(&[v475_7_byte]);
    let mut v476_2 = Space::new();
    let mut v476_2_cursor = (v475_7_tail).read_zipper();
    for v476_2_byte in v476_2_cursor.child_mask().iter() {
      v476_2_cursor.descend_to_byte(v476_2_byte);
      let v476_2_tail = v476_2_cursor.make_map();
      v476_2_cursor.ascend(1);
      let v476_2_head = Path::from_slice(&[v476_2_byte]);
      let v477_2: Path = concat_path(&(v475_7_head),&(v476_2_head));
      let mut v477_3 = Space::new();
      let mut v477_3_cursor = (v476_2_tail).read_zipper();
      for v477_3_byte in v477_3_cursor.child_mask().iter() {
        v477_3_cursor.descend_to_byte(v477_3_byte);
        let v477_3_tail = v477_3_cursor.make_map();
        v477_3_cursor.ascend(1);
        let v477_3_head = Path::from_slice(&[v477_3_byte]);
        let v478_2: Path = concat_path(&(v477_2),&(v477_3_head));
        let mut v478_3 = Space::new();
        let mut v478_3_cursor = (v477_3_tail).read_zipper();
        for v478_3_byte in v478_3_cursor.child_mask().iter() {
          v478_3_cursor.descend_to_byte(v478_3_byte);
          let v478_3_tail = v478_3_cursor.make_map();
          v478_3_cursor.ascend(1);
          let v478_3_head = Path::from_slice(&[v478_3_byte]);
          let v479_2: Path = concat_path(&(v478_2),&(v478_3_head));
          let mut v479_3 = Space::new();
          let mut v479_3_cursor = (v478_3_tail).read_zipper();
          for v479_3_byte in v479_3_cursor.child_mask().iter() {
            v479_3_cursor.descend_to_byte(v479_3_byte);
            let v479_3_tail = v479_3_cursor.make_map();
            v479_3_cursor.ascend(1);
            let v479_3_head = Path::from_slice(&[v479_3_byte]);
            let mut v480_2 = Space::new();
            let mut v480_2_cursor = (v479_3_tail).read_zipper();
            for v480_2_byte in v480_2_cursor.child_mask().iter() {
              v480_2_cursor.descend_to_byte(v480_2_byte);
              let v480_2_tail = v480_2_cursor.make_map();
              v480_2_cursor.ascend(1);
              let v480_2_head = Path::from_slice(&[v480_2_byte]);
              let v481_2: Path = concat_path(&(v479_3_head),&(v480_2_head));
              let mut v481_3 = Space::new();
              let mut v481_3_cursor = (v480_2_tail).read_zipper();
              for v481_3_byte in v481_3_cursor.child_mask().iter() {
                v481_3_cursor.descend_to_byte(v481_3_byte);
                let v481_3_tail = v481_3_cursor.make_map();
                v481_3_cursor.ascend(1);
                let v481_3_head = Path::from_slice(&[v481_3_byte]);
                let v482_2: Path = concat_path(&(v481_2),&(v481_3_head));
                let mut v482_3 = Space::new();
                let mut v482_3_cursor = (v481_3_tail).read_zipper();
                for v482_3_byte in v482_3_cursor.child_mask().iter() {
                  v482_3_cursor.descend_to_byte(v482_3_byte);
                  let v482_3_tail = v482_3_cursor.make_map();
                  v482_3_cursor.ascend(1);
                  let v482_3_head = Path::from_slice(&[v482_3_byte]);
                  let v483_2: Path = concat_path(&(v482_2),&(v482_3_head));
                  let v483_3: Space = routine_46(c, &(v483_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v479_2), &(v482_3_tail));
                  drop(v483_2);
                  v482_3.join_into((v483_3).clone());
                }
                drop(v482_3_cursor);
                drop(v482_2);
                v481_3.join_into((v482_3).clone());
              }
              drop(v481_3_cursor);
              drop(v481_2);
              v480_2.join_into((v481_3).clone());
            }
            drop(v480_2_cursor);
            v479_3.join_into((v480_2).clone());
          }
          drop(v479_3_cursor);
          drop(v479_2);
          v478_3.join_into((v479_3).clone());
        }
        drop(v478_3_cursor);
        drop(v478_2);
        v477_3.join_into((v478_3).clone());
      }
      drop(v477_3_cursor);
      drop(v477_2);
      v476_2.join_into((v477_3).clone());
    }
    drop(v476_2_cursor);
    v475_7.join_into((v476_2).clone());
  }
  drop(v475_7_cursor);
  (v475_7).clone()
}

fn routine_38(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v484_11: Path = concat_path(&(*CONSTANT_3),&(*p1));
  let v484_12: Space = singleton(&(v484_11));
  drop(v484_11);
  let v484_13: Space = unite(&(*CONSTANT_73),&(v484_12));
  drop(v484_12);
  let v484_15: Path = concat_path(&(*CONSTANT_5),&(*p2));
  let v484_16: Space = singleton(&(v484_15));
  drop(v484_15);
  let v484_17: Space = unite(&(v484_13),&(v484_16));
  drop(v484_13);
  drop(v484_16);
  let v484_19: Path = concat_path(&(*CONSTANT_7),&(*p3));
  let v484_20: Space = singleton(&(v484_19));
  drop(v484_19);
  let v484_21: Space = unite(&(v484_17),&(v484_20));
  drop(v484_17);
  drop(v484_20);
  let v484_23: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v484_24: Space = singleton(&(v484_23));
  drop(v484_23);
  let v484_25: Space = unite(&(v484_21),&(v484_24));
  drop(v484_21);
  drop(v484_24);
  let v484_27: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v484_28: Space = singleton(&(v484_27));
  drop(v484_27);
  let v484_29: Space = unite(&(v484_25),&(v484_28));
  drop(v484_25);
  drop(v484_28);
  let v484_31: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v484_32: Space = singleton(&(v484_31));
  drop(v484_31);
  let v484_33: Space = unite(&(v484_29),&(v484_32));
  drop(v484_29);
  drop(v484_32);
  let v484_35: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v484_36: Space = singleton(&(v484_35));
  drop(v484_35);
  let v484_37: Space = unite(&(v484_33),&(v484_36));
  drop(v484_33);
  drop(v484_36);
  let v484_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v484_40: Space = singleton(&(v484_39));
  drop(v484_39);
  let v484_41: Space = unite(&(v484_37),&(v484_40));
  drop(v484_37);
  drop(v484_40);
  (v484_41).clone()
}

fn routine_39(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v485_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v485_12: Space = singleton(&(v485_11));
  drop(v485_11);
  let v485_13: Space = unite(&(*CONSTANT_74),&(v485_12));
  drop(v485_12);
  let v485_15: Path = concat_path(&(*CONSTANT_5),&(*p2));
  let v485_16: Space = singleton(&(v485_15));
  drop(v485_15);
  let v485_17: Space = unite(&(v485_13),&(v485_16));
  drop(v485_13);
  drop(v485_16);
  let v485_19: Path = concat_path(&(*CONSTANT_7),&(*p3));
  let v485_20: Space = singleton(&(v485_19));
  drop(v485_19);
  let v485_21: Space = unite(&(v485_17),&(v485_20));
  drop(v485_17);
  drop(v485_20);
  let v485_23: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v485_24: Space = singleton(&(v485_23));
  drop(v485_23);
  let v485_25: Space = unite(&(v485_21),&(v485_24));
  drop(v485_21);
  drop(v485_24);
  let v485_27: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v485_28: Space = singleton(&(v485_27));
  drop(v485_27);
  let v485_29: Space = unite(&(v485_25),&(v485_28));
  drop(v485_25);
  drop(v485_28);
  let v485_31: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v485_32: Space = singleton(&(v485_31));
  drop(v485_31);
  let v485_33: Space = unite(&(v485_29),&(v485_32));
  drop(v485_29);
  drop(v485_32);
  let v485_35: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v485_36: Space = singleton(&(v485_35));
  drop(v485_35);
  let v485_37: Space = unite(&(v485_33),&(v485_36));
  drop(v485_33);
  drop(v485_36);
  let v485_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v485_40: Space = singleton(&(v485_39));
  drop(v485_39);
  let v485_41: Space = unite(&(v485_37),&(v485_40));
  drop(v485_37);
  drop(v485_40);
  (v485_41).clone()
}

fn routine_40(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v486_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v486_12: Space = singleton(&(v486_11));
  drop(v486_11);
  let v486_13: Space = unite(&(*CONSTANT_75),&(v486_12));
  drop(v486_12);
  let v486_15: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v486_16: Space = singleton(&(v486_15));
  drop(v486_15);
  let v486_17: Space = unite(&(v486_13),&(v486_16));
  drop(v486_13);
  drop(v486_16);
  let v486_19: Path = concat_path(&(*CONSTANT_7),&(*p3));
  let v486_20: Space = singleton(&(v486_19));
  drop(v486_19);
  let v486_21: Space = unite(&(v486_17),&(v486_20));
  drop(v486_17);
  drop(v486_20);
  let v486_23: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v486_24: Space = singleton(&(v486_23));
  drop(v486_23);
  let v486_25: Space = unite(&(v486_21),&(v486_24));
  drop(v486_21);
  drop(v486_24);
  let v486_27: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v486_28: Space = singleton(&(v486_27));
  drop(v486_27);
  let v486_29: Space = unite(&(v486_25),&(v486_28));
  drop(v486_25);
  drop(v486_28);
  let v486_31: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v486_32: Space = singleton(&(v486_31));
  drop(v486_31);
  let v486_33: Space = unite(&(v486_29),&(v486_32));
  drop(v486_29);
  drop(v486_32);
  let v486_35: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v486_36: Space = singleton(&(v486_35));
  drop(v486_35);
  let v486_37: Space = unite(&(v486_33),&(v486_36));
  drop(v486_33);
  drop(v486_36);
  let v486_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v486_40: Space = singleton(&(v486_39));
  drop(v486_39);
  let v486_41: Space = unite(&(v486_37),&(v486_40));
  drop(v486_37);
  drop(v486_40);
  (v486_41).clone()
}

fn routine_41(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v487_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v487_12: Space = singleton(&(v487_11));
  drop(v487_11);
  let v487_13: Space = unite(&(*CONSTANT_76),&(v487_12));
  drop(v487_12);
  let v487_15: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v487_16: Space = singleton(&(v487_15));
  drop(v487_15);
  let v487_17: Space = unite(&(v487_13),&(v487_16));
  drop(v487_13);
  drop(v487_16);
  let v487_19: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v487_20: Space = singleton(&(v487_19));
  drop(v487_19);
  let v487_21: Space = unite(&(v487_17),&(v487_20));
  drop(v487_17);
  drop(v487_20);
  let v487_23: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v487_24: Space = singleton(&(v487_23));
  drop(v487_23);
  let v487_25: Space = unite(&(v487_21),&(v487_24));
  drop(v487_21);
  drop(v487_24);
  let v487_27: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v487_28: Space = singleton(&(v487_27));
  drop(v487_27);
  let v487_29: Space = unite(&(v487_25),&(v487_28));
  drop(v487_25);
  drop(v487_28);
  let v487_31: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v487_32: Space = singleton(&(v487_31));
  drop(v487_31);
  let v487_33: Space = unite(&(v487_29),&(v487_32));
  drop(v487_29);
  drop(v487_32);
  let v487_35: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v487_36: Space = singleton(&(v487_35));
  drop(v487_35);
  let v487_37: Space = unite(&(v487_33),&(v487_36));
  drop(v487_33);
  drop(v487_36);
  let v487_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v487_40: Space = singleton(&(v487_39));
  drop(v487_39);
  let v487_41: Space = unite(&(v487_37),&(v487_40));
  drop(v487_37);
  drop(v487_40);
  (v487_41).clone()
}

fn routine_42(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v488_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v488_12: Space = singleton(&(v488_11));
  drop(v488_11);
  let v488_13: Space = unite(&(*CONSTANT_77),&(v488_12));
  drop(v488_12);
  let v488_15: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v488_16: Space = singleton(&(v488_15));
  drop(v488_15);
  let v488_17: Space = unite(&(v488_13),&(v488_16));
  drop(v488_13);
  drop(v488_16);
  let v488_19: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v488_20: Space = singleton(&(v488_19));
  drop(v488_19);
  let v488_21: Space = unite(&(v488_17),&(v488_20));
  drop(v488_17);
  drop(v488_20);
  let v488_23: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v488_24: Space = singleton(&(v488_23));
  drop(v488_23);
  let v488_25: Space = unite(&(v488_21),&(v488_24));
  drop(v488_21);
  drop(v488_24);
  let v488_27: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v488_28: Space = singleton(&(v488_27));
  drop(v488_27);
  let v488_29: Space = unite(&(v488_25),&(v488_28));
  drop(v488_25);
  drop(v488_28);
  let v488_31: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v488_32: Space = singleton(&(v488_31));
  drop(v488_31);
  let v488_33: Space = unite(&(v488_29),&(v488_32));
  drop(v488_29);
  drop(v488_32);
  let v488_35: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v488_36: Space = singleton(&(v488_35));
  drop(v488_35);
  let v488_37: Space = unite(&(v488_33),&(v488_36));
  drop(v488_33);
  drop(v488_36);
  let v488_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v488_40: Space = singleton(&(v488_39));
  drop(v488_39);
  let v488_41: Space = unite(&(v488_37),&(v488_40));
  drop(v488_37);
  drop(v488_40);
  (v488_41).clone()
}

fn routine_43(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v489_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v489_12: Space = singleton(&(v489_11));
  drop(v489_11);
  let v489_13: Space = unite(&(*CONSTANT_78),&(v489_12));
  drop(v489_12);
  let v489_15: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v489_16: Space = singleton(&(v489_15));
  drop(v489_15);
  let v489_17: Space = unite(&(v489_13),&(v489_16));
  drop(v489_13);
  drop(v489_16);
  let v489_19: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v489_20: Space = singleton(&(v489_19));
  drop(v489_19);
  let v489_21: Space = unite(&(v489_17),&(v489_20));
  drop(v489_17);
  drop(v489_20);
  let v489_23: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v489_24: Space = singleton(&(v489_23));
  drop(v489_23);
  let v489_25: Space = unite(&(v489_21),&(v489_24));
  drop(v489_21);
  drop(v489_24);
  let v489_27: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v489_28: Space = singleton(&(v489_27));
  drop(v489_27);
  let v489_29: Space = unite(&(v489_25),&(v489_28));
  drop(v489_25);
  drop(v489_28);
  let v489_31: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v489_32: Space = singleton(&(v489_31));
  drop(v489_31);
  let v489_33: Space = unite(&(v489_29),&(v489_32));
  drop(v489_29);
  drop(v489_32);
  let v489_35: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v489_36: Space = singleton(&(v489_35));
  drop(v489_35);
  let v489_37: Space = unite(&(v489_33),&(v489_36));
  drop(v489_33);
  drop(v489_36);
  let v489_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v489_40: Space = singleton(&(v489_39));
  drop(v489_39);
  let v489_41: Space = unite(&(v489_37),&(v489_40));
  drop(v489_37);
  drop(v489_40);
  (v489_41).clone()
}

fn routine_44(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v490_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v490_12: Space = singleton(&(v490_11));
  drop(v490_11);
  let v490_13: Space = unite(&(*CONSTANT_79),&(v490_12));
  drop(v490_12);
  let v490_15: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v490_16: Space = singleton(&(v490_15));
  drop(v490_15);
  let v490_17: Space = unite(&(v490_13),&(v490_16));
  drop(v490_13);
  drop(v490_16);
  let v490_19: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v490_20: Space = singleton(&(v490_19));
  drop(v490_19);
  let v490_21: Space = unite(&(v490_17),&(v490_20));
  drop(v490_17);
  drop(v490_20);
  let v490_23: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v490_24: Space = singleton(&(v490_23));
  drop(v490_23);
  let v490_25: Space = unite(&(v490_21),&(v490_24));
  drop(v490_21);
  drop(v490_24);
  let v490_27: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v490_28: Space = singleton(&(v490_27));
  drop(v490_27);
  let v490_29: Space = unite(&(v490_25),&(v490_28));
  drop(v490_25);
  drop(v490_28);
  let v490_31: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v490_32: Space = singleton(&(v490_31));
  drop(v490_31);
  let v490_33: Space = unite(&(v490_29),&(v490_32));
  drop(v490_29);
  drop(v490_32);
  let v490_35: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v490_36: Space = singleton(&(v490_35));
  drop(v490_35);
  let v490_37: Space = unite(&(v490_33),&(v490_36));
  drop(v490_33);
  drop(v490_36);
  let v490_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v490_40: Space = singleton(&(v490_39));
  drop(v490_39);
  let v490_41: Space = unite(&(v490_37),&(v490_40));
  drop(v490_37);
  drop(v490_40);
  (v490_41).clone()
}

fn routine_45(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v491_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v491_12: Space = singleton(&(v491_11));
  drop(v491_11);
  let v491_13: Space = unite(&(*CONSTANT_80),&(v491_12));
  drop(v491_12);
  let v491_15: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v491_16: Space = singleton(&(v491_15));
  drop(v491_15);
  let v491_17: Space = unite(&(v491_13),&(v491_16));
  drop(v491_13);
  drop(v491_16);
  let v491_19: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v491_20: Space = singleton(&(v491_19));
  drop(v491_19);
  let v491_21: Space = unite(&(v491_17),&(v491_20));
  drop(v491_17);
  drop(v491_20);
  let v491_23: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v491_24: Space = singleton(&(v491_23));
  drop(v491_23);
  let v491_25: Space = unite(&(v491_21),&(v491_24));
  drop(v491_21);
  drop(v491_24);
  let v491_27: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v491_28: Space = singleton(&(v491_27));
  drop(v491_27);
  let v491_29: Space = unite(&(v491_25),&(v491_28));
  drop(v491_25);
  drop(v491_28);
  let v491_31: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v491_32: Space = singleton(&(v491_31));
  drop(v491_31);
  let v491_33: Space = unite(&(v491_29),&(v491_32));
  drop(v491_29);
  drop(v491_32);
  let v491_35: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v491_36: Space = singleton(&(v491_35));
  drop(v491_35);
  let v491_37: Space = unite(&(v491_33),&(v491_36));
  drop(v491_33);
  drop(v491_36);
  let v491_39: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v491_40: Space = singleton(&(v491_39));
  drop(v491_39);
  let v491_41: Space = unite(&(v491_37),&(v491_40));
  drop(v491_37);
  drop(v491_40);
  (v491_41).clone()
}

fn routine_46(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v492_11: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v492_12: Space = singleton(&(v492_11));
  drop(v492_11);
  let v492_13: Space = unite(&(*CONSTANT_81),&(v492_12));
  drop(v492_12);
  let v492_15: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v492_16: Space = singleton(&(v492_15));
  drop(v492_15);
  let v492_17: Space = unite(&(v492_13),&(v492_16));
  drop(v492_13);
  drop(v492_16);
  let v492_19: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v492_20: Space = singleton(&(v492_19));
  drop(v492_19);
  let v492_21: Space = unite(&(v492_17),&(v492_20));
  drop(v492_17);
  drop(v492_20);
  let v492_23: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v492_24: Space = singleton(&(v492_23));
  drop(v492_23);
  let v492_25: Space = unite(&(v492_21),&(v492_24));
  drop(v492_21);
  drop(v492_24);
  let v492_27: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v492_28: Space = singleton(&(v492_27));
  drop(v492_27);
  let v492_29: Space = unite(&(v492_25),&(v492_28));
  drop(v492_25);
  drop(v492_28);
  let v492_31: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v492_32: Space = singleton(&(v492_31));
  drop(v492_31);
  let v492_33: Space = unite(&(v492_29),&(v492_32));
  drop(v492_29);
  drop(v492_32);
  let v492_35: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v492_36: Space = singleton(&(v492_35));
  drop(v492_35);
  let v492_37: Space = unite(&(v492_33),&(v492_36));
  drop(v492_33);
  drop(v492_36);
  let v492_39: Path = concat_path(&(*CONSTANT_15),&(*p0));
  let v492_40: Space = singleton(&(v492_39));
  drop(v492_39);
  let v492_41: Space = unite(&(v492_37),&(v492_40));
  drop(v492_37);
  drop(v492_40);
  (v492_41).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
