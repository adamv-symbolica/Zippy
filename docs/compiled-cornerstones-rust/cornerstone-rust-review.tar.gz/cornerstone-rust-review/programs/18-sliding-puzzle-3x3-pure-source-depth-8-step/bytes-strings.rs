#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[82,48]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("96 19 67 48 0 49 0 50 0 51 0 52 0 53 0 54 0 55 0 56 0 19 67 48 0 49 0 50 0 51 0 52 0 55 0 54 0 56 0 53 0 19 67 48 0 49 0 50 0 51 0 52 0 56 0 54 0 53 0 55 0 19 67 48 0 49 0 50 0 51 0 53 0 56 0 52 0 54 0 55 0 19 67 48 0 49 0 50 0 51 0 54 0 52 0 55 0 56 0 53 0 19 67 48 0 49 0 50 0 51 0 54 0 53 0 55 0 52 0 56 0 19 67 48 0 49 0 50 0 51 0 55 0 53 0 52 0 54 0 56 0 19 67 48 0 49 0 50 0 54 0 52 0 53 0 55 0 51 0 56 0 19 67 48 0 49 0 50 0 55 0 52 0 53 0 51 0 54 0 56 0 19 67 48 0 49 0 52 0 51 0 53 0 50 0 54 0 55 0 56 0 19 67 48 0 49 0 52 0 51 0 55 0 50 0 54 0 56 0 53 0 19 67 48 0 49 0 53 0 51 0 50 0 52 0 54 0 55 0 56 0 19 67 48 0 49 0 53 0 51 0 50 0 56 0 54 0 52 0 55 0 19 67 48 0 50 0 53 0 49 0 51 0 52 0 54 0 55 0 56 0 19 67 48 0 50 0 53 0 49 0 51 0 56 0 54 0 52 0 55 0 19 67 48 0 50 0 53 0 49 0 52 0 56 0 51 0 54 0 55 0 19 67 48 0 50 0 53 0 49 0 55 0 52 0 51 0 54 0 56 0 19 67 48 0 50 0 53 0 51 0 52 0 49 0 54 0 55 0 56 0 19 67 48 0 51 0 49 0 52 0 53 0 50 0 54 0 55 0 56 0 19 67 48 0 51 0 49 0 52 0 55 0 50 0 54 0 56 0 53 0 19 67 48 0 51 0 49 0 54 0 52 0 50 0 55 0 56 0 53 0 19 67 48 0 51 0 49 0 54 0 53 0 50 0 55 0 52 0 56 0 19 67 48 0 51 0 50 0 52 0 49 0 53 0 54 0 55 0 56 0 19 67 48 0 51 0 50 0 52 0 49 0 55 0 54 0 56 0 53 0 19 67 48 0 51 0 50 0 52 0 49 0 56 0 54 0 53 0 55 0 19 67 48 0 51 0 50 0 54 0 49 0 52 0 55 0 56 0 53 0 19 67 48 0 51 0 50 0 54 0 49 0 53 0 55 0 52 0 56 0 19 67 48 0 51 0 50 0 55 0 49 0 53 0 52 0 54 0 56 0 19 67 48 0 51 0 53 0 52 0 50 0 49 0 54 0 55 0 56 0 19 67 48 0 52 0 50 0 49 0 51 0 53 0 54 0 55 0 56 0 19 67 48 0 52 0 50 0 49 0 51 0 55 0 54 0 56 0 53 0 19 67 48 0 52 0 50 0 49 0 51 0 56 0 54 0 53 0 55 0 19 67 48 0 52 0 50 0 49 0 53 0 56 0 51 0 54 0 55 0 19 67 48 0 52 0 50 0 49 0 54 0 53 0 55 0 51 0 56 0 19 67 48 0 52 0 50 0 49 0 55 0 53 0 51 0 54 0 56 0 19 67 48 0 53 0 49 0 51 0 52 0 50 0 54 0 55 0 56 0 19 67 48 0 53 0 52 0 49 0 51 0 50 0 54 0 55 0 56 0 19 67 49 0 49 0 50 0 51 0 52 0 53 0 54 0 55 0 56 0 19 67 49 0 49 0 50 0 51 0 52 0 55 0 54 0 56 0 53 0 19 67 49 0 49 0 50 0 51 0 52 0 56 0 54 0 53 0 55 0 19 67 49 0 49 0 50 0 51 0 54 0 53 0 55 0 52 0 56 0 19 67 49 0 49 0 50 0 51 0 55 0 53 0 52 0 54 0 56 0 19 67 49 0 49 0 50 0 54 0 52 0 53 0 55 0 51 0 56 0 19 67 49 0 49 0 50 0 55 0 52 0 53 0 51 0 54 0 56 0 19 67 49 0 49 0 52 0 51 0 53 0 50 0 54 0 55 0 56 0 19 67 49 0 49 0 52 0 51 0 55 0 50 0 54 0 56 0 53 0 19 67 49 0 49 0 53 0 51 0 50 0 52 0 54 0 55 0 56 0 19 67 49 0 49 0 53 0 51 0 50 0 56 0 54 0 52 0 55 0 19 67 49 0 50 0 53 0 49 0 51 0 52 0 54 0 55 0 56 0 19 67 49 0 51 0 49 0 52 0 53 0 50 0 54 0 55 0 56 0 19 67 49 0 51 0 49 0 52 0 55 0 50 0 54 0 56 0 53 0 19 67 49 0 51 0 49 0 54 0 52 0 50 0 55 0 56 0 53 0 19 67 49 0 51 0 49 0 54 0 53 0 50 0 55 0 52 0 56 0 19 67 49 0 51 0 50 0 52 0 49 0 53 0 54 0 55 0 56 0 19 67 49 0 51 0 50 0 52 0 49 0 55 0 54 0 56 0 53 0 19 67 49 0 51 0 50 0 52 0 49 0 56 0 54 0 53 0 55 0 19 67 49 0 51 0 50 0 54 0 49 0 52 0 55 0 56 0 53 0 19 67 49 0 51 0 50 0 54 0 49 0 53 0 55 0 52 0 56 0 19 67 49 0 51 0 50 0 55 0 49 0 53 0 52 0 54 0 56 0 19 67 49 0 51 0 53 0 52 0 50 0 49 0 54 0 55 0 56 0 19 67 49 0 52 0 50 0 49 0 51 0 53 0 54 0 55 0 56 0 19 67 49 0 52 0 50 0 49 0 55 0 53 0 51 0 54 0 56 0 19 67 50 0 49 0 50 0 51 0 52 0 53 0 54 0 55 0 56 0 19 67 50 0 49 0 50 0 51 0 52 0 55 0 54 0 56 0 53 0 19 67 50 0 49 0 50 0 51 0 52 0 56 0 54 0 53 0 55 0 19 67 50 0 49 0 50 0 51 0 54 0 53 0 55 0 52 0 56 0 19 67 50 0 49 0 50 0 51 0 55 0 53 0 52 0 54 0 56 0 19 67 50 0 49 0 50 0 51 0 55 0 53 0 54 0 56 0 52 0 19 67 50 0 49 0 50 0 51 0 56 0 53 0 54 0 52 0 55 0 19 67 50 0 49 0 50 0 54 0 52 0 53 0 55 0 51 0 56 0 19 67 50 0 49 0 50 0 55 0 52 0 53 0 51 0 54 0 56 0 19 67 50 0 49 0 52 0 51 0 53 0 50 0 54 0 55 0 56 0 19 67 50 0 49 0 52 0 51 0 55 0 50 0 54 0 56 0 53 0 19 67 50 0 49 0 52 0 51 0 56 0 50 0 54 0 53 0 55 0 19 67 50 0 49 0 52 0 54 0 51 0 50 0 55 0 56 0 53 0 19 67 50 0 49 0 52 0 54 0 53 0 50 0 55 0 51 0 56 0 19 67 50 0 49 0 52 0 55 0 53 0 50 0 51 0 54 0 56 0 19 67 50 0 49 0 53 0 51 0 50 0 52 0 54 0 55 0 56 0 19 67 50 0 49 0 53 0 51 0 50 0 56 0 54 0 52 0 55 0 19 67 50 0 50 0 53 0 49 0 51 0 52 0 54 0 55 0 56 0 19 67 50 0 51 0 49 0 52 0 53 0 50 0 54 0 55 0 56 0 19 67 50 0 51 0 49 0 52 0 55 0 50 0 54 0 56 0 53 0 19 67 50 0 51 0 49 0 52 0 56 0 50 0 54 0 53 0 55 0 19 67 50 0 51 0 49 0 54 0 52 0 50 0 55 0 56 0 53 0 19 67 50 0 51 0 49 0 54 0 53 0 50 0 55 0 52 0 56 0 19 67 50 0 51 0 49 0 55 0 53 0 50 0 52 0 54 0 56 0 19 67 50 0 51 0 50 0 52 0 49 0 53 0 54 0 55 0 56 0 19 67 50 0 51 0 50 0 52 0 49 0 55 0 54 0 56 0 53 0 19 67 50 0 51 0 50 0 52 0 49 0 56 0 54 0 53 0 55 0 19 67 50 0 51 0 50 0 54 0 49 0 52 0 55 0 56 0 53 0 19 67 50 0 51 0 50 0 54 0 49 0 53 0 55 0 52 0 56 0 19 67 50 0 51 0 50 0 55 0 49 0 53 0 52 0 54 0 56 0 19 67 50 0 51 0 53 0 52 0 50 0 49 0 54 0 55 0 56 0 19 67 50 0 52 0 50 0 49 0 51 0 53 0 54 0 55 0 56 0 19 67 50 0 52 0 50 0 49 0 55 0 53 0 51 0 54 0 56 0 19 67 50 0 52 0 51 0 49 0 53 0 50 0 54 0 55 0 56 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[82,49]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("87 19 67 48 0 49 0 50 0 53 0 51 0 52 0 54 0 55 0 56 0 19 67 48 0 49 0 50 0 53 0 51 0 56 0 54 0 52 0 55 0 19 67 48 0 49 0 50 0 53 0 52 0 56 0 51 0 54 0 55 0 19 67 48 0 49 0 50 0 53 0 55 0 52 0 51 0 54 0 56 0 19 67 48 0 49 0 52 0 50 0 51 0 53 0 54 0 55 0 56 0 19 67 48 0 49 0 52 0 50 0 51 0 55 0 54 0 56 0 53 0 19 67 48 0 49 0 52 0 50 0 51 0 56 0 54 0 53 0 55 0 19 67 48 0 49 0 52 0 50 0 53 0 56 0 51 0 54 0 55 0 19 67 48 0 49 0 52 0 50 0 54 0 53 0 55 0 51 0 56 0 19 67 48 0 49 0 52 0 50 0 55 0 53 0 51 0 54 0 56 0 19 67 48 0 49 0 53 0 52 0 51 0 50 0 54 0 55 0 56 0 19 67 48 0 51 0 49 0 50 0 52 0 53 0 54 0 55 0 56 0 19 67 48 0 51 0 49 0 50 0 52 0 55 0 54 0 56 0 53 0 19 67 48 0 51 0 49 0 50 0 52 0 56 0 54 0 53 0 55 0 19 67 48 0 51 0 49 0 50 0 53 0 56 0 52 0 54 0 55 0 19 67 48 0 51 0 49 0 50 0 54 0 52 0 55 0 56 0 53 0 19 67 48 0 51 0 49 0 50 0 54 0 53 0 55 0 52 0 56 0 19 67 48 0 51 0 49 0 50 0 55 0 53 0 52 0 54 0 56 0 19 67 48 0 51 0 49 0 52 0 53 0 50 0 54 0 55 0 56 0 19 67 48 0 51 0 49 0 53 0 50 0 52 0 54 0 55 0 56 0 19 67 48 0 51 0 50 0 53 0 52 0 49 0 54 0 55 0 56 0 19 67 48 0 51 0 53 0 49 0 52 0 50 0 54 0 55 0 56 0 19 67 48 0 52 0 51 0 49 0 53 0 50 0 54 0 55 0 56 0 19 67 48 0 52 0 51 0 50 0 49 0 53 0 54 0 55 0 56 0 19 67 48 0 54 0 51 0 50 0 49 0 53 0 55 0 52 0 56 0 19 67 49 0 49 0 50 0 53 0 51 0 52 0 54 0 55 0 56 0 19 67 49 0 49 0 50 0 53 0 51 0 55 0 54 0 56 0 52 0 19 67 49 0 49 0 50 0 53 0 51 0 56 0 54 0 52 0 55 0 19 67 49 0 49 0 50 0 53 0 52 0 56 0 51 0 54 0 55 0 19 67 49 0 49 0 50 0 53 0 54 0 52 0 55 0 51 0 56 0 19 67 49 0 49 0 50 0 53 0 55 0 52 0 51 0 54 0 56 0 19 67 49 0 49 0 52 0 50 0 51 0 53 0 54 0 55 0 56 0 19 67 49 0 49 0 52 0 50 0 51 0 55 0 54 0 56 0 53 0 19 67 49 0 49 0 52 0 50 0 51 0 56 0 54 0 53 0 55 0 19 67 49 0 49 0 52 0 50 0 53 0 56 0 51 0 54 0 55 0 19 67 49 0 49 0 52 0 50 0 54 0 51 0 55 0 56 0 53 0 19 67 49 0 49 0 52 0 50 0 54 0 53 0 55 0 51 0 56 0 19 67 49 0 49 0 52 0 50 0 55 0 53 0 51 0 54 0 56 0 19 67 49 0 49 0 53 0 52 0 51 0 50 0 54 0 55 0 56 0 19 67 49 0 49 0 54 0 50 0 51 0 53 0 55 0 52 0 56 0 19 67 49 0 49 0 55 0 50 0 51 0 53 0 52 0 54 0 56 0 19 67 49 0 49 0 55 0 52 0 51 0 50 0 54 0 56 0 53 0 19 67 49 0 50 0 51 0 53 0 49 0 52 0 54 0 55 0 56 0 19 67 49 0 51 0 49 0 50 0 52 0 53 0 54 0 55 0 56 0 19 67 49 0 51 0 49 0 50 0 52 0 55 0 54 0 56 0 53 0 19 67 49 0 51 0 49 0 50 0 52 0 56 0 54 0 53 0 55 0 19 67 49 0 51 0 49 0 50 0 53 0 56 0 52 0 54 0 55 0 19 67 49 0 51 0 49 0 50 0 54 0 52 0 55 0 56 0 53 0 19 67 49 0 51 0 49 0 50 0 54 0 53 0 55 0 52 0 56 0 19 67 49 0 51 0 49 0 50 0 54 0 56 0 55 0 53 0 52 0 19 67 49 0 51 0 49 0 50 0 55 0 53 0 52 0 54 0 56 0 19 67 49 0 51 0 49 0 52 0 53 0 50 0 54 0 55 0 56 0 19 67 49 0 51 0 49 0 53 0 50 0 52 0 54 0 55 0 56 0 19 67 49 0 51 0 50 0 53 0 52 0 49 0 54 0 55 0 56 0 19 67 49 0 51 0 50 0 53 0 52 0 56 0 54 0 49 0 55 0 19 67 49 0 51 0 50 0 53 0 54 0 49 0 55 0 52 0 56 0 19 67 49 0 51 0 52 0 49 0 54 0 50 0 55 0 56 0 53 0 19 67 49 0 51 0 53 0 49 0 52 0 50 0 54 0 55 0 56 0 19 67 49 0 51 0 53 0 49 0 54 0 50 0 55 0 52 0 56 0 19 67 49 0 51 0 55 0 49 0 52 0 50 0 54 0 56 0 53 0 19 67 49 0 52 0 50 0 53 0 49 0 51 0 54 0 55 0 56 0 19 67 49 0 52 0 51 0 49 0 53 0 50 0 54 0 55 0 56 0 19 67 49 0 52 0 51 0 50 0 49 0 53 0 54 0 55 0 56 0 19 67 49 0 52 0 51 0 50 0 54 0 53 0 55 0 49 0 56 0 19 67 49 0 52 0 55 0 50 0 49 0 53 0 51 0 54 0 56 0 19 67 49 0 54 0 51 0 50 0 49 0 53 0 55 0 52 0 56 0 19 67 50 0 49 0 50 0 53 0 51 0 52 0 54 0 55 0 56 0 19 67 50 0 49 0 50 0 53 0 51 0 55 0 54 0 56 0 52 0 19 67 50 0 49 0 50 0 53 0 51 0 56 0 54 0 52 0 55 0 19 67 50 0 49 0 52 0 50 0 51 0 53 0 54 0 55 0 56 0 19 67 50 0 49 0 52 0 50 0 51 0 55 0 54 0 56 0 53 0 19 67 50 0 49 0 52 0 50 0 51 0 56 0 54 0 53 0 55 0 19 67 50 0 49 0 52 0 50 0 54 0 51 0 55 0 56 0 53 0 19 67 50 0 49 0 52 0 50 0 54 0 53 0 55 0 51 0 56 0 19 67 50 0 49 0 52 0 50 0 55 0 53 0 51 0 54 0 56 0 19 67 50 0 49 0 53 0 52 0 51 0 50 0 54 0 55 0 56 0 19 67 50 0 51 0 49 0 50 0 52 0 53 0 54 0 55 0 56 0 19 67 50 0 51 0 49 0 50 0 52 0 55 0 54 0 56 0 53 0 19 67 50 0 51 0 49 0 50 0 52 0 56 0 54 0 53 0 55 0 19 67 50 0 51 0 49 0 50 0 54 0 52 0 55 0 56 0 53 0 19 67 50 0 51 0 49 0 50 0 54 0 53 0 55 0 52 0 56 0 19 67 50 0 51 0 49 0 50 0 55 0 53 0 52 0 54 0 56 0 19 67 50 0 51 0 50 0 53 0 52 0 49 0 54 0 55 0 56 0 19 67 50 0 51 0 50 0 53 0 54 0 49 0 55 0 52 0 56 0 19 67 50 0 51 0 53 0 49 0 52 0 50 0 54 0 55 0 56 0 19 67 50 0 52 0 50 0 53 0 49 0 51 0 54 0 55 0 56 0 19 67 50 0 52 0 51 0 50 0 49 0 53 0 54 0 55 0 56 0"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[82,50]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("85 19 67 48 0 49 0 50 0 53 0 51 0 52 0 56 0 54 0 55 0 19 67 48 0 49 0 50 0 53 0 51 0 55 0 52 0 54 0 56 0 19 67 48 0 49 0 50 0 53 0 54 0 51 0 52 0 55 0 56 0 19 67 48 0 49 0 50 0 53 0 54 0 51 0 56 0 52 0 55 0 19 67 48 0 49 0 52 0 50 0 51 0 53 0 56 0 54 0 55 0 19 67 48 0 49 0 52 0 50 0 51 0 55 0 53 0 54 0 56 0 19 67 48 0 49 0 52 0 50 0 51 0 56 0 55 0 54 0 53 0 19 67 48 0 49 0 52 0 50 0 54 0 51 0 53 0 55 0 56 0 19 67 48 0 49 0 52 0 50 0 54 0 51 0 55 0 56 0 53 0 19 67 48 0 49 0 52 0 50 0 54 0 51 0 56 0 53 0 55 0 19 67 48 0 49 0 52 0 50 0 55 0 54 0 53 0 51 0 56 0 19 67 48 0 49 0 53 0 52 0 51 0 55 0 50 0 54 0 56 0 19 67 48 0 49 0 53 0 52 0 54 0 51 0 50 0 55 0 56 0 19 67 48 0 51 0 49 0 50 0 52 0 53 0 56 0 54 0 55 0 19 67 48 0 51 0 49 0 50 0 52 0 55 0 53 0 54 0 56 0 19 67 48 0 51 0 49 0 50 0 52 0 56 0 55 0 54 0 53 0 19 67 48 0 51 0 49 0 50 0 54 0 52 0 53 0 55 0 56 0 19 67 48 0 51 0 49 0 50 0 54 0 52 0 55 0 56 0 53 0 19 67 48 0 51 0 49 0 50 0 54 0 52 0 56 0 53 0 55 0 19 67 48 0 51 0 49 0 50 0 54 0 53 0 56 0 55 0 52 0 19 67 48 0 51 0 49 0 50 0 54 0 56 0 52 0 55 0 53 0 19 67 48 0 51 0 49 0 50 0 55 0 54 0 52 0 56 0 53 0 19 67 48 0 51 0 49 0 50 0 55 0 54 0 53 0 52 0 56 0 19 67 48 0 51 0 49 0 52 0 54 0 53 0 50 0 55 0 56 0 19 67 48 0 51 0 49 0 53 0 54 0 50 0 52 0 55 0 56 0 19 67 48 0 51 0 50 0 53 0 52 0 49 0 56 0 54 0 55 0 19 67 48 0 51 0 50 0 53 0 52 0 55 0 49 0 54 0 56 0 19 67 48 0 51 0 50 0 53 0 54 0 52 0 49 0 55 0 56 0 19 67 48 0 51 0 53 0 49 0 52 0 55 0 50 0 54 0 56 0 19 67 48 0 51 0 53 0 49 0 54 0 52 0 50 0 55 0 56 0 19 67 48 0 52 0 51 0 49 0 54 0 53 0 50 0 55 0 56 0 19 67 48 0 52 0 51 0 50 0 49 0 55 0 53 0 54 0 56 0 19 67 48 0 52 0 51 0 50 0 54 0 49 0 53 0 55 0 56 0 19 67 48 0 54 0 51 0 50 0 55 0 49 0 53 0 52 0 56 0 19 67 49 0 49 0 50 0 53 0 51 0 52 0 56 0 54 0 55 0 19 67 49 0 49 0 50 0 53 0 51 0 55 0 52 0 54 0 56 0 19 67 49 0 49 0 50 0 53 0 54 0 51 0 52 0 55 0 56 0 19 67 49 0 49 0 52 0 50 0 51 0 53 0 56 0 54 0 55 0 19 67 49 0 49 0 52 0 50 0 51 0 55 0 53 0 54 0 56 0 19 67 49 0 49 0 52 0 50 0 51 0 56 0 55 0 54 0 53 0 19 67 49 0 49 0 52 0 50 0 54 0 51 0 53 0 55 0 56 0 19 67 49 0 49 0 52 0 50 0 55 0 54 0 53 0 51 0 56 0 19 67 49 0 49 0 53 0 52 0 51 0 55 0 50 0 54 0 56 0 19 67 49 0 51 0 49 0 50 0 52 0 53 0 56 0 54 0 55 0 19 67 49 0 51 0 49 0 50 0 52 0 55 0 53 0 54 0 56 0 19 67 49 0 51 0 49 0 50 0 52 0 56 0 55 0 54 0 53 0 19 67 49 0 51 0 49 0 50 0 54 0 52 0 53 0 55 0 56 0 19 67 49 0 51 0 49 0 50 0 54 0 53 0 56 0 55 0 52 0 19 67 49 0 51 0 49 0 50 0 54 0 56 0 52 0 55 0 53 0 19 67 49 0 51 0 49 0 50 0 55 0 54 0 53 0 52 0 56 0 19 67 49 0 51 0 50 0 53 0 52 0 49 0 56 0 54 0 55 0 19 67 49 0 51 0 50 0 53 0 52 0 55 0 49 0 54 0 56 0 19 67 49 0 51 0 53 0 49 0 52 0 55 0 50 0 54 0 56 0 19 67 49 0 52 0 51 0 50 0 49 0 55 0 53 0 54 0 56 0 19 67 49 0 52 0 51 0 50 0 54 0 49 0 53 0 55 0 56 0 19 67 50 0 49 0 50 0 53 0 51 0 52 0 56 0 54 0 55 0 19 67 50 0 49 0 50 0 53 0 51 0 55 0 52 0 54 0 56 0 19 67 50 0 49 0 50 0 53 0 51 0 56 0 55 0 54 0 52 0 19 67 50 0 49 0 50 0 53 0 54 0 51 0 52 0 55 0 56 0 19 67 50 0 49 0 52 0 50 0 51 0 53 0 56 0 54 0 55 0 19 67 50 0 49 0 52 0 50 0 51 0 55 0 53 0 54 0 56 0 19 67 50 0 49 0 52 0 50 0 51 0 56 0 55 0 54 0 53 0 19 67 50 0 49 0 52 0 50 0 54 0 51 0 53 0 55 0 56 0 19 67 50 0 49 0 52 0 50 0 54 0 53 0 56 0 55 0 51 0 19 67 50 0 49 0 52 0 50 0 55 0 53 0 56 0 51 0 54 0 19 67 50 0 49 0 52 0 50 0 55 0 54 0 53 0 51 0 56 0 19 67 50 0 49 0 53 0 52 0 51 0 50 0 56 0 54 0 55 0 19 67 50 0 49 0 53 0 52 0 51 0 55 0 50 0 54 0 56 0 19 67 50 0 51 0 49 0 50 0 52 0 53 0 56 0 54 0 55 0 19 67 50 0 51 0 49 0 50 0 52 0 55 0 53 0 54 0 56 0 19 67 50 0 51 0 49 0 50 0 52 0 56 0 55 0 54 0 53 0 19 67 50 0 51 0 49 0 50 0 54 0 52 0 53 0 55 0 56 0 19 67 50 0 51 0 49 0 50 0 54 0 53 0 56 0 55 0 52 0 19 67 50 0 51 0 49 0 50 0 54 0 56 0 52 0 55 0 53 0 19 67 50 0 51 0 49 0 50 0 55 0 53 0 56 0 52 0 54 0 19 67 50 0 51 0 49 0 50 0 55 0 54 0 53 0 52 0 56 0 19 67 50 0 51 0 50 0 53 0 52 0 49 0 56 0 54 0 55 0 19 67 50 0 51 0 50 0 53 0 52 0 55 0 49 0 54 0 56 0 19 67 50 0 51 0 50 0 53 0 54 0 49 0 56 0 55 0 52 0 19 67 50 0 51 0 53 0 49 0 52 0 50 0 56 0 54 0 55 0 19 67 50 0 51 0 53 0 49 0 52 0 55 0 50 0 54 0 56 0 19 67 50 0 52 0 50 0 53 0 49 0 51 0 56 0 54 0 55 0 19 67 50 0 52 0 51 0 50 0 49 0 53 0 56 0 54 0 55 0 19 67 50 0 52 0 51 0 50 0 49 0 55 0 53 0 54 0 56 0 19 67 50 0 52 0 51 0 50 0 54 0 49 0 53 0 55 0 56 0"));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 82 48 67 48 0"));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 82 48 67 49 0"));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 82 48 67 50 0"));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 82 49 67 48 0"));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 82 49 67 49 0"));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 82 49 67 50 0"));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 82 50 67 48 0"));
static CONSTANT_15: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 82 50 67 49 0"));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 82 50 67 50 0"));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[82]));
static CONSTANT_18: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("48 16 48 67 48 0 68 0 82 48 67 48 0 82 49 67 48 0 16 48 67 48 0 68 0 82 49 67 48 0 82 48 67 48 0 16 48 67 48 0 82 0 82 48 67 48 0 82 48 67 49 0 16 48 67 48 0 82 0 82 48 67 49 0 82 48 67 48 0 16 48 67 49 0 68 0 82 48 67 49 0 82 49 67 49 0 16 48 67 49 0 68 0 82 49 67 49 0 82 48 67 49 0 16 48 67 49 0 76 0 82 48 67 48 0 82 48 67 49 0 16 48 67 49 0 76 0 82 48 67 49 0 82 48 67 48 0 16 48 67 49 0 82 0 82 48 67 49 0 82 48 67 50 0 16 48 67 49 0 82 0 82 48 67 50 0 82 48 67 49 0 16 48 67 50 0 68 0 82 48 67 50 0 82 49 67 50 0 16 48 67 50 0 68 0 82 49 67 50 0 82 48 67 50 0 16 48 67 50 0 76 0 82 48 67 49 0 82 48 67 50 0 16 48 67 50 0 76 0 82 48 67 50 0 82 48 67 49 0 16 49 67 48 0 68 0 82 49 67 48 0 82 50 67 48 0 16 49 67 48 0 68 0 82 50 67 48 0 82 49 67 48 0 16 49 67 48 0 82 0 82 49 67 48 0 82 49 67 49 0 16 49 67 48 0 82 0 82 49 67 49 0 82 49 67 48 0 16 49 67 48 0 85 0 82 48 67 48 0 82 49 67 48 0 16 49 67 48 0 85 0 82 49 67 48 0 82 48 67 48 0 16 49 67 49 0 68 0 82 49 67 49 0 82 50 67 49 0 16 49 67 49 0 68 0 82 50 67 49 0 82 49 67 49 0 16 49 67 49 0 76 0 82 49 67 48 0 82 49 67 49 0 16 49 67 49 0 76 0 82 49 67 49 0 82 49 67 48 0 16 49 67 49 0 82 0 82 49 67 49 0 82 49 67 50 0 16 49 67 49 0 82 0 82 49 67 50 0 82 49 67 49 0 16 49 67 49 0 85 0 82 48 67 49 0 82 49 67 49 0 16 49 67 49 0 85 0 82 49 67 49 0 82 48 67 49 0 16 49 67 50 0 68 0 82 49 67 50 0 82 50 67 50 0 16 49 67 50 0 68 0 82 50 67 50 0 82 49 67 50 0 16 49 67 50 0 76 0 82 49 67 49 0 82 49 67 50 0 16 49 67 50 0 76 0 82 49 67 50 0 82 49 67 49 0 16 49 67 50 0 85 0 82 48 67 50 0 82 49 67 50 0 16 49 67 50 0 85 0 82 49 67 50 0 82 48 67 50 0 16 50 67 48 0 82 0 82 50 67 48 0 82 50 67 49 0 16 50 67 48 0 82 0 82 50 67 49 0 82 50 67 48 0 16 50 67 48 0 85 0 82 49 67 48 0 82 50 67 48 0 16 50 67 48 0 85 0 82 50 67 48 0 82 49 67 48 0 16 50 67 49 0 76 0 82 50 67 48 0 82 50 67 49 0 16 50 67 49 0 76 0 82 50 67 49 0 82 50 67 48 0 16 50 67 49 0 82 0 82 50 67 49 0 82 50 67 50 0 16 50 67 49 0 82 0 82 50 67 50 0 82 50 67 49 0 16 50 67 49 0 85 0 82 49 67 49 0 82 50 67 49 0 16 50 67 49 0 85 0 82 50 67 49 0 82 49 67 49 0 16 50 67 50 0 76 0 82 50 67 49 0 82 50 67 50 0 16 50 67 50 0 76 0 82 50 67 50 0 82 50 67 49 0 16 50 67 50 0 85 0 82 49 67 50 0 82 50 67 50 0 16 50 67 50 0 85 0 82 50 67 50 0 82 49 67 50 0"));
static CONSTANT_19: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("14 15 67 48 0 68 0 82 48 67 48 0 82 49 67 48 0 15 67 48 0 68 0 82 49 67 48 0 82 48 67 48 0 15 67 48 0 82 0 82 48 67 48 0 82 48 67 49 0 15 67 48 0 82 0 82 48 67 49 0 82 48 67 48 0 15 67 49 0 68 0 82 48 67 49 0 82 49 67 49 0 15 67 49 0 68 0 82 49 67 49 0 82 48 67 49 0 15 67 49 0 76 0 82 48 67 48 0 82 48 67 49 0 15 67 49 0 76 0 82 48 67 49 0 82 48 67 48 0 15 67 49 0 82 0 82 48 67 49 0 82 48 67 50 0 15 67 49 0 82 0 82 48 67 50 0 82 48 67 49 0 15 67 50 0 68 0 82 48 67 50 0 82 49 67 50 0 15 67 50 0 68 0 82 49 67 50 0 82 48 67 50 0 15 67 50 0 76 0 82 48 67 49 0 82 48 67 50 0 15 67 50 0 76 0 82 48 67 50 0 82 48 67 49 0"));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("20 15 67 48 0 68 0 82 49 67 48 0 82 50 67 48 0 15 67 48 0 68 0 82 50 67 48 0 82 49 67 48 0 15 67 48 0 82 0 82 49 67 48 0 82 49 67 49 0 15 67 48 0 82 0 82 49 67 49 0 82 49 67 48 0 15 67 48 0 85 0 82 48 67 48 0 82 49 67 48 0 15 67 48 0 85 0 82 49 67 48 0 82 48 67 48 0 15 67 49 0 68 0 82 49 67 49 0 82 50 67 49 0 15 67 49 0 68 0 82 50 67 49 0 82 49 67 49 0 15 67 49 0 76 0 82 49 67 48 0 82 49 67 49 0 15 67 49 0 76 0 82 49 67 49 0 82 49 67 48 0 15 67 49 0 82 0 82 49 67 49 0 82 49 67 50 0 15 67 49 0 82 0 82 49 67 50 0 82 49 67 49 0 15 67 49 0 85 0 82 48 67 49 0 82 49 67 49 0 15 67 49 0 85 0 82 49 67 49 0 82 48 67 49 0 15 67 50 0 68 0 82 49 67 50 0 82 50 67 50 0 15 67 50 0 68 0 82 50 67 50 0 82 49 67 50 0 15 67 50 0 76 0 82 49 67 49 0 82 49 67 50 0 15 67 50 0 76 0 82 49 67 50 0 82 49 67 49 0 15 67 50 0 85 0 82 48 67 50 0 82 49 67 50 0 15 67 50 0 85 0 82 49 67 50 0 82 48 67 50 0"));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("14 15 67 48 0 82 0 82 50 67 48 0 82 50 67 49 0 15 67 48 0 82 0 82 50 67 49 0 82 50 67 48 0 15 67 48 0 85 0 82 49 67 48 0 82 50 67 48 0 15 67 48 0 85 0 82 50 67 48 0 82 49 67 48 0 15 67 49 0 76 0 82 50 67 48 0 82 50 67 49 0 15 67 49 0 76 0 82 50 67 49 0 82 50 67 48 0 15 67 49 0 82 0 82 50 67 49 0 82 50 67 50 0 15 67 49 0 82 0 82 50 67 50 0 82 50 67 49 0 15 67 49 0 85 0 82 49 67 49 0 82 50 67 49 0 15 67 49 0 85 0 82 50 67 49 0 82 49 67 49 0 15 67 50 0 76 0 82 50 67 49 0 82 50 67 50 0 15 67 50 0 76 0 82 50 67 50 0 82 50 67 49 0 15 67 50 0 85 0 82 49 67 50 0 82 50 67 50 0 15 67 50 0 85 0 82 50 67 50 0 82 49 67 50 0"));
static CONSTANT_22: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[82,48,67,49,0]));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[82,48,67,50,0]));
static CONSTANT_24: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[82,49,67,48,0]));
static CONSTANT_25: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[82,49,67,49,0]));
static CONSTANT_26: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[82,49,67,50,0]));
static CONSTANT_27: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[82,50,67,48,0]));
static CONSTANT_28: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[82,50,67,49,0]));
static CONSTANT_29: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[82,50,67,50,0]));
static CONSTANT_30: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[82,48,67,48,0]));
static CONSTANT_31: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("9 10 82 48 67 48 0 82 48 67 48 0 10 82 48 67 49 0 82 48 67 49 0 10 82 48 67 50 0 82 48 67 50 0 10 82 49 67 48 0 82 49 67 48 0 10 82 49 67 49 0 82 49 67 49 0 10 82 49 67 50 0 82 49 67 50 0 10 82 50 67 48 0 82 50 67 48 0 10 82 50 67 49 0 82 50 67 49 0 10 82 50 67 50 0 82 50 67 50 0"));
static CONSTANT_32: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 82 48 67 48 0 95 0"));
static CONSTANT_33: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 82 48 67 49 0 95 0"));
static CONSTANT_34: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 82 48 67 50 0 95 0"));
static CONSTANT_35: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 82 49 67 48 0 95 0"));
static CONSTANT_36: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 82 49 67 49 0 95 0"));
static CONSTANT_37: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 82 49 67 50 0 95 0"));
static CONSTANT_38: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 82 50 67 48 0 95 0"));
static CONSTANT_39: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 82 50 67 49 0 95 0"));
static CONSTANT_40: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 82 50 67 50 0 95 0"));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &Path,capture_1: &Path,capture_2: &Path,capture_3: &Path,capture_4: &Path,capture_5: &Path,capture_6: &Path,capture_7: &Path,capture_8: &Path) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v142_11: Space = singleton(&(*capture_1));
  let v142_12: Space = intersect(&(*CONSTANT_8),&(v142_11));
  let mut v142_16 = Space::new();
  let mut v142_16_cursor = (v142_12).read_zipper();
  for v142_16_byte in v142_16_cursor.child_mask().iter() {
    v142_16_cursor.descend_to_byte(v142_16_byte);
    let v142_16_tail = v142_16_cursor.make_map();
    v142_16_cursor.ascend(1);
    let v142_16_head = Path::from_slice(&[v142_16_byte]);
    let v143_2: Space = singleton(&(v142_16_head));
    let v143_3: Space = intersect(&(*CONSTANT_7),&(v143_2));
    let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
    drop(v143_3);
    let v143_5: Space = subtract(&(*CONSTANT_0),&(v143_4));
    drop(v143_4);
    let v143_7: Space = if (v143_5).is_empty() { Space::new() } else {
      let v144_6: Space = routine_23(c, &(v142_16_head), &(v142_16_tail));
      compose(&(v143_5),&(v144_6))
    };
    drop(v143_5);
    let v143_8: Space = intersect(&(*CONSTANT_7),&(v143_2));
    drop(v143_2);
    let v143_9: Space = if has_head(&(v143_8)) { singleton(&[]) } else { Space::new() };
    drop(v143_8);
    let v143_11: Space = if (v143_9).is_empty() { Space::new() } else {
      let v145_10: Space = routine_24(c, &(v142_16_head), &(v142_16_tail));
      compose(&(v143_9),&(v145_10))
    };
    drop(v143_9);
    let v143_12: Space = unite(&(v143_7),&(v143_11));
    v142_16.join_into((v143_12).clone());
  }
  drop(v142_16_cursor);
  drop(v142_12);
  let v142_29: Space = if (v142_16).is_empty() { Space::new() } else {
    let v146_17: Path = concat_path(&(*capture_2),&(*capture_3));
    let v146_18: Path = concat_path(&(v146_17),&(*capture_4));
    drop(v146_17);
    let v146_19: Path = concat_path(&(v146_18),&(*capture_5));
    drop(v146_18);
    let v146_20: Path = concat_path(&(v146_19),&(*capture_6));
    drop(v146_19);
    let v146_21: Path = concat_path(&(v146_20),&(*capture_7));
    drop(v146_20);
    let v146_22: Path = concat_path(&(v146_21),&(*capture_8));
    drop(v146_21);
    let v146_23: Path = concat_path(&(v146_22),&(*capture_0));
    drop(v146_22);
    let v146_24: Space = singleton(&(v146_23));
    drop(v146_23);
    let mut v146_28 = Space::new();
    let mut v146_28_cursor = (v146_24).read_zipper();
    for v146_28_byte in v146_28_cursor.child_mask().iter() {
      v146_28_cursor.descend_to_byte(v146_28_byte);
      let v146_28_tail = v146_28_cursor.make_map();
      v146_28_cursor.ascend(1);
      let v146_28_head = Path::from_slice(&[v146_28_byte]);
      let v147_2: Space = singleton(&(v146_28_head));
      let v147_3: Space = intersect(&(*CONSTANT_7),&(v147_2));
      let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
      drop(v147_3);
      let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
      drop(v147_4);
      let v147_7: Space = if (v147_5).is_empty() { Space::new() } else {
        let v148_6: Space = routine_25(c, &(v146_28_head), &(v146_28_tail));
        compose(&(v147_5),&(v148_6))
      };
      drop(v147_5);
      let v147_8: Space = intersect(&(*CONSTANT_7),&(v147_2));
      drop(v147_2);
      let v147_9: Space = if has_head(&(v147_8)) { singleton(&[]) } else { Space::new() };
      drop(v147_8);
      let v147_11: Space = if (v147_9).is_empty() { Space::new() } else {
        let v149_10: Space = routine_26(c, &(v146_28_head), &(v146_28_tail));
        compose(&(v147_9),&(v149_10))
      };
      drop(v147_9);
      let v147_12: Space = unite(&(v147_7),&(v147_11));
      v146_28.join_into((v147_12).clone());
    }
    drop(v146_28_cursor);
    compose(&(v142_16),&(v146_28))
  };
  let v142_31: Space = intersect(&(*CONSTANT_9),&(v142_11));
  let mut v142_35 = Space::new();
  let mut v142_35_cursor = (v142_31).read_zipper();
  for v142_35_byte in v142_35_cursor.child_mask().iter() {
    v142_35_cursor.descend_to_byte(v142_35_byte);
    let v142_35_tail = v142_35_cursor.make_map();
    v142_35_cursor.ascend(1);
    let v142_35_head = Path::from_slice(&[v142_35_byte]);
    let v150_2: Space = singleton(&(v142_35_head));
    let v150_3: Space = intersect(&(*CONSTANT_7),&(v150_2));
    let v150_4: Space = if has_head(&(v150_3)) { singleton(&[]) } else { Space::new() };
    drop(v150_3);
    let v150_5: Space = subtract(&(*CONSTANT_0),&(v150_4));
    drop(v150_4);
    let v150_7: Space = if (v150_5).is_empty() { Space::new() } else {
      let v151_6: Space = routine_27(c, &(v142_35_head), &(v142_35_tail));
      compose(&(v150_5),&(v151_6))
    };
    drop(v150_5);
    let v150_8: Space = intersect(&(*CONSTANT_7),&(v150_2));
    drop(v150_2);
    let v150_9: Space = if has_head(&(v150_8)) { singleton(&[]) } else { Space::new() };
    drop(v150_8);
    let v150_11: Space = if (v150_9).is_empty() { Space::new() } else {
      let v152_10: Space = routine_28(c, &(v142_35_head), &(v142_35_tail));
      compose(&(v150_9),&(v152_10))
    };
    drop(v150_9);
    let v150_12: Space = unite(&(v150_7),&(v150_11));
    v142_35.join_into((v150_12).clone());
  }
  drop(v142_35_cursor);
  drop(v142_31);
  let v142_40: Space = if (v142_35).is_empty() { Space::new() } else {
    let v153_17: Path = concat_path(&(*capture_2),&(*capture_3));
    let v153_18: Path = concat_path(&(v153_17),&(*capture_4));
    drop(v153_17);
    let v153_19: Path = concat_path(&(v153_18),&(*capture_5));
    drop(v153_18);
    let v153_20: Path = concat_path(&(v153_19),&(*capture_6));
    drop(v153_19);
    let v153_21: Path = concat_path(&(v153_20),&(*capture_7));
    drop(v153_20);
    let v153_22: Path = concat_path(&(v153_21),&(*capture_8));
    drop(v153_21);
    let v153_23: Path = concat_path(&(v153_22),&(*capture_0));
    drop(v153_22);
    let v153_24: Space = singleton(&(v153_23));
    drop(v153_23);
    let mut v153_39 = Space::new();
    let mut v153_39_cursor = (v153_24).read_zipper();
    for v153_39_byte in v153_39_cursor.child_mask().iter() {
      v153_39_cursor.descend_to_byte(v153_39_byte);
      let v153_39_tail = v153_39_cursor.make_map();
      v153_39_cursor.ascend(1);
      let v153_39_head = Path::from_slice(&[v153_39_byte]);
      let v154_2: Space = singleton(&(v153_39_head));
      let v154_3: Space = intersect(&(*CONSTANT_7),&(v154_2));
      let v154_4: Space = if has_head(&(v154_3)) { singleton(&[]) } else { Space::new() };
      drop(v154_3);
      let v154_5: Space = subtract(&(*CONSTANT_0),&(v154_4));
      drop(v154_4);
      let v154_7: Space = if (v154_5).is_empty() { Space::new() } else {
        let v155_6: Space = routine_29(c, &(v153_39_head), &(v153_39_tail));
        compose(&(v154_5),&(v155_6))
      };
      drop(v154_5);
      let v154_8: Space = intersect(&(*CONSTANT_7),&(v154_2));
      drop(v154_2);
      let v154_9: Space = if has_head(&(v154_8)) { singleton(&[]) } else { Space::new() };
      drop(v154_8);
      let v154_11: Space = if (v154_9).is_empty() { Space::new() } else {
        let v156_10: Space = routine_30(c, &(v153_39_head), &(v153_39_tail));
        compose(&(v154_9),&(v156_10))
      };
      drop(v154_9);
      let v154_12: Space = unite(&(v154_7),&(v154_11));
      v153_39.join_into((v154_12).clone());
    }
    drop(v153_39_cursor);
    compose(&(v142_35),&(v153_39))
  };
  let v142_41: Space = unite(&(v142_29),&(v142_40));
  let v142_43: Space = intersect(&(*CONSTANT_10),&(v142_11));
  let mut v142_47 = Space::new();
  let mut v142_47_cursor = (v142_43).read_zipper();
  for v142_47_byte in v142_47_cursor.child_mask().iter() {
    v142_47_cursor.descend_to_byte(v142_47_byte);
    let v142_47_tail = v142_47_cursor.make_map();
    v142_47_cursor.ascend(1);
    let v142_47_head = Path::from_slice(&[v142_47_byte]);
    let v157_2: Space = singleton(&(v142_47_head));
    let v157_3: Space = intersect(&(*CONSTANT_7),&(v157_2));
    let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
    drop(v157_3);
    let v157_5: Space = subtract(&(*CONSTANT_0),&(v157_4));
    drop(v157_4);
    let v157_7: Space = if (v157_5).is_empty() { Space::new() } else {
      let v158_6: Space = routine_31(c, &(v142_47_head), &(v142_47_tail));
      compose(&(v157_5),&(v158_6))
    };
    drop(v157_5);
    let v157_8: Space = intersect(&(*CONSTANT_7),&(v157_2));
    drop(v157_2);
    let v157_9: Space = if has_head(&(v157_8)) { singleton(&[]) } else { Space::new() };
    drop(v157_8);
    let v157_11: Space = if (v157_9).is_empty() { Space::new() } else {
      let v159_10: Space = routine_32(c, &(v142_47_head), &(v142_47_tail));
      compose(&(v157_9),&(v159_10))
    };
    drop(v157_9);
    let v157_12: Space = unite(&(v157_7),&(v157_11));
    v142_47.join_into((v157_12).clone());
  }
  drop(v142_47_cursor);
  drop(v142_43);
  let v142_52: Space = if (v142_47).is_empty() { Space::new() } else {
    let v160_17: Path = concat_path(&(*capture_2),&(*capture_3));
    let v160_18: Path = concat_path(&(v160_17),&(*capture_4));
    drop(v160_17);
    let v160_19: Path = concat_path(&(v160_18),&(*capture_5));
    drop(v160_18);
    let v160_20: Path = concat_path(&(v160_19),&(*capture_6));
    drop(v160_19);
    let v160_21: Path = concat_path(&(v160_20),&(*capture_7));
    drop(v160_20);
    let v160_22: Path = concat_path(&(v160_21),&(*capture_8));
    drop(v160_21);
    let v160_23: Path = concat_path(&(v160_22),&(*capture_0));
    drop(v160_22);
    let v160_24: Space = singleton(&(v160_23));
    drop(v160_23);
    let mut v160_51 = Space::new();
    let mut v160_51_cursor = (v160_24).read_zipper();
    for v160_51_byte in v160_51_cursor.child_mask().iter() {
      v160_51_cursor.descend_to_byte(v160_51_byte);
      let v160_51_tail = v160_51_cursor.make_map();
      v160_51_cursor.ascend(1);
      let v160_51_head = Path::from_slice(&[v160_51_byte]);
      let v161_2: Space = singleton(&(v160_51_head));
      let v161_3: Space = intersect(&(*CONSTANT_7),&(v161_2));
      let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
      drop(v161_3);
      let v161_5: Space = subtract(&(*CONSTANT_0),&(v161_4));
      drop(v161_4);
      let v161_7: Space = if (v161_5).is_empty() { Space::new() } else {
        let v162_6: Space = routine_33(c, &(v160_51_head), &(v160_51_tail));
        compose(&(v161_5),&(v162_6))
      };
      drop(v161_5);
      let v161_8: Space = intersect(&(*CONSTANT_7),&(v161_2));
      drop(v161_2);
      let v161_9: Space = if has_head(&(v161_8)) { singleton(&[]) } else { Space::new() };
      drop(v161_8);
      let v161_11: Space = if (v161_9).is_empty() { Space::new() } else {
        let v163_10: Space = routine_34(c, &(v160_51_head), &(v160_51_tail));
        compose(&(v161_9),&(v163_10))
      };
      drop(v161_9);
      let v161_12: Space = unite(&(v161_7),&(v161_11));
      v160_51.join_into((v161_12).clone());
    }
    drop(v160_51_cursor);
    compose(&(v142_47),&(v160_51))
  };
  let v142_53: Space = unite(&(v142_41),&(v142_52));
  let v142_55: Space = intersect(&(*CONSTANT_11),&(v142_11));
  let mut v142_59 = Space::new();
  let mut v142_59_cursor = (v142_55).read_zipper();
  for v142_59_byte in v142_59_cursor.child_mask().iter() {
    v142_59_cursor.descend_to_byte(v142_59_byte);
    let v142_59_tail = v142_59_cursor.make_map();
    v142_59_cursor.ascend(1);
    let v142_59_head = Path::from_slice(&[v142_59_byte]);
    let v164_2: Space = singleton(&(v142_59_head));
    let v164_3: Space = intersect(&(*CONSTANT_7),&(v164_2));
    let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
    drop(v164_3);
    let v164_5: Space = subtract(&(*CONSTANT_0),&(v164_4));
    drop(v164_4);
    let v164_7: Space = if (v164_5).is_empty() { Space::new() } else {
      let v165_6: Space = routine_35(c, &(v142_59_head), &(v142_59_tail));
      compose(&(v164_5),&(v165_6))
    };
    drop(v164_5);
    let v164_8: Space = intersect(&(*CONSTANT_7),&(v164_2));
    drop(v164_2);
    let v164_9: Space = if has_head(&(v164_8)) { singleton(&[]) } else { Space::new() };
    drop(v164_8);
    let v164_11: Space = if (v164_9).is_empty() { Space::new() } else {
      let v166_10: Space = routine_36(c, &(v142_59_head), &(v142_59_tail));
      compose(&(v164_9),&(v166_10))
    };
    drop(v164_9);
    let v164_12: Space = unite(&(v164_7),&(v164_11));
    v142_59.join_into((v164_12).clone());
  }
  drop(v142_59_cursor);
  drop(v142_55);
  let v142_64: Space = if (v142_59).is_empty() { Space::new() } else {
    let v167_17: Path = concat_path(&(*capture_2),&(*capture_3));
    let v167_18: Path = concat_path(&(v167_17),&(*capture_4));
    drop(v167_17);
    let v167_19: Path = concat_path(&(v167_18),&(*capture_5));
    drop(v167_18);
    let v167_20: Path = concat_path(&(v167_19),&(*capture_6));
    drop(v167_19);
    let v167_21: Path = concat_path(&(v167_20),&(*capture_7));
    drop(v167_20);
    let v167_22: Path = concat_path(&(v167_21),&(*capture_8));
    drop(v167_21);
    let v167_23: Path = concat_path(&(v167_22),&(*capture_0));
    drop(v167_22);
    let v167_24: Space = singleton(&(v167_23));
    drop(v167_23);
    let mut v167_63 = Space::new();
    let mut v167_63_cursor = (v167_24).read_zipper();
    for v167_63_byte in v167_63_cursor.child_mask().iter() {
      v167_63_cursor.descend_to_byte(v167_63_byte);
      let v167_63_tail = v167_63_cursor.make_map();
      v167_63_cursor.ascend(1);
      let v167_63_head = Path::from_slice(&[v167_63_byte]);
      let v168_2: Space = singleton(&(v167_63_head));
      let v168_3: Space = intersect(&(*CONSTANT_7),&(v168_2));
      let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
      drop(v168_3);
      let v168_5: Space = subtract(&(*CONSTANT_0),&(v168_4));
      drop(v168_4);
      let v168_7: Space = if (v168_5).is_empty() { Space::new() } else {
        let v169_6: Space = routine_37(c, &(v167_63_head), &(v167_63_tail));
        compose(&(v168_5),&(v169_6))
      };
      drop(v168_5);
      let v168_8: Space = intersect(&(*CONSTANT_7),&(v168_2));
      drop(v168_2);
      let v168_9: Space = if has_head(&(v168_8)) { singleton(&[]) } else { Space::new() };
      drop(v168_8);
      let v168_11: Space = if (v168_9).is_empty() { Space::new() } else {
        let v170_10: Space = routine_38(c, &(v167_63_head), &(v167_63_tail));
        compose(&(v168_9),&(v170_10))
      };
      drop(v168_9);
      let v168_12: Space = unite(&(v168_7),&(v168_11));
      v167_63.join_into((v168_12).clone());
    }
    drop(v167_63_cursor);
    compose(&(v142_59),&(v167_63))
  };
  let v142_65: Space = unite(&(v142_53),&(v142_64));
  let v142_67: Space = intersect(&(*CONSTANT_12),&(v142_11));
  let mut v142_71 = Space::new();
  let mut v142_71_cursor = (v142_67).read_zipper();
  for v142_71_byte in v142_71_cursor.child_mask().iter() {
    v142_71_cursor.descend_to_byte(v142_71_byte);
    let v142_71_tail = v142_71_cursor.make_map();
    v142_71_cursor.ascend(1);
    let v142_71_head = Path::from_slice(&[v142_71_byte]);
    let v171_2: Space = singleton(&(v142_71_head));
    let v171_3: Space = intersect(&(*CONSTANT_7),&(v171_2));
    let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
    drop(v171_3);
    let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
    drop(v171_4);
    let v171_7: Space = if (v171_5).is_empty() { Space::new() } else {
      let v172_6: Space = routine_39(c, &(v142_71_head), &(v142_71_tail));
      compose(&(v171_5),&(v172_6))
    };
    drop(v171_5);
    let v171_8: Space = intersect(&(*CONSTANT_7),&(v171_2));
    drop(v171_2);
    let v171_9: Space = if has_head(&(v171_8)) { singleton(&[]) } else { Space::new() };
    drop(v171_8);
    let v171_11: Space = if (v171_9).is_empty() { Space::new() } else {
      let v173_10: Space = routine_40(c, &(v142_71_head), &(v142_71_tail));
      compose(&(v171_9),&(v173_10))
    };
    drop(v171_9);
    let v171_12: Space = unite(&(v171_7),&(v171_11));
    v142_71.join_into((v171_12).clone());
  }
  drop(v142_71_cursor);
  drop(v142_67);
  let v142_76: Space = if (v142_71).is_empty() { Space::new() } else {
    let v174_17: Path = concat_path(&(*capture_2),&(*capture_3));
    let v174_18: Path = concat_path(&(v174_17),&(*capture_4));
    drop(v174_17);
    let v174_19: Path = concat_path(&(v174_18),&(*capture_5));
    drop(v174_18);
    let v174_20: Path = concat_path(&(v174_19),&(*capture_6));
    drop(v174_19);
    let v174_21: Path = concat_path(&(v174_20),&(*capture_7));
    drop(v174_20);
    let v174_22: Path = concat_path(&(v174_21),&(*capture_8));
    drop(v174_21);
    let v174_23: Path = concat_path(&(v174_22),&(*capture_0));
    drop(v174_22);
    let v174_24: Space = singleton(&(v174_23));
    drop(v174_23);
    let mut v174_75 = Space::new();
    let mut v174_75_cursor = (v174_24).read_zipper();
    for v174_75_byte in v174_75_cursor.child_mask().iter() {
      v174_75_cursor.descend_to_byte(v174_75_byte);
      let v174_75_tail = v174_75_cursor.make_map();
      v174_75_cursor.ascend(1);
      let v174_75_head = Path::from_slice(&[v174_75_byte]);
      let v175_2: Space = singleton(&(v174_75_head));
      let v175_3: Space = intersect(&(*CONSTANT_7),&(v175_2));
      let v175_4: Space = if has_head(&(v175_3)) { singleton(&[]) } else { Space::new() };
      drop(v175_3);
      let v175_5: Space = subtract(&(*CONSTANT_0),&(v175_4));
      drop(v175_4);
      let v175_7: Space = if (v175_5).is_empty() { Space::new() } else {
        let v176_6: Space = routine_41(c, &(v174_75_head), &(v174_75_tail));
        compose(&(v175_5),&(v176_6))
      };
      drop(v175_5);
      let v175_8: Space = intersect(&(*CONSTANT_7),&(v175_2));
      drop(v175_2);
      let v175_9: Space = if has_head(&(v175_8)) { singleton(&[]) } else { Space::new() };
      drop(v175_8);
      let v175_11: Space = if (v175_9).is_empty() { Space::new() } else {
        let v177_10: Space = routine_42(c, &(v174_75_head), &(v174_75_tail));
        compose(&(v175_9),&(v177_10))
      };
      drop(v175_9);
      let v175_12: Space = unite(&(v175_7),&(v175_11));
      v174_75.join_into((v175_12).clone());
    }
    drop(v174_75_cursor);
    compose(&(v142_71),&(v174_75))
  };
  let v142_77: Space = unite(&(v142_65),&(v142_76));
  let v142_79: Space = intersect(&(*CONSTANT_13),&(v142_11));
  let mut v142_83 = Space::new();
  let mut v142_83_cursor = (v142_79).read_zipper();
  for v142_83_byte in v142_83_cursor.child_mask().iter() {
    v142_83_cursor.descend_to_byte(v142_83_byte);
    let v142_83_tail = v142_83_cursor.make_map();
    v142_83_cursor.ascend(1);
    let v142_83_head = Path::from_slice(&[v142_83_byte]);
    let v178_2: Space = singleton(&(v142_83_head));
    let v178_3: Space = intersect(&(*CONSTANT_7),&(v178_2));
    let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
    drop(v178_3);
    let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
    drop(v178_4);
    let v178_7: Space = if (v178_5).is_empty() { Space::new() } else {
      let v179_6: Space = routine_43(c, &(v142_83_head), &(v142_83_tail));
      compose(&(v178_5),&(v179_6))
    };
    drop(v178_5);
    let v178_8: Space = intersect(&(*CONSTANT_7),&(v178_2));
    drop(v178_2);
    let v178_9: Space = if has_head(&(v178_8)) { singleton(&[]) } else { Space::new() };
    drop(v178_8);
    let v178_11: Space = if (v178_9).is_empty() { Space::new() } else {
      let v180_10: Space = routine_44(c, &(v142_83_head), &(v142_83_tail));
      compose(&(v178_9),&(v180_10))
    };
    drop(v178_9);
    let v178_12: Space = unite(&(v178_7),&(v178_11));
    v142_83.join_into((v178_12).clone());
  }
  drop(v142_83_cursor);
  drop(v142_79);
  let v142_88: Space = if (v142_83).is_empty() { Space::new() } else {
    let v181_17: Path = concat_path(&(*capture_2),&(*capture_3));
    let v181_18: Path = concat_path(&(v181_17),&(*capture_4));
    drop(v181_17);
    let v181_19: Path = concat_path(&(v181_18),&(*capture_5));
    drop(v181_18);
    let v181_20: Path = concat_path(&(v181_19),&(*capture_6));
    drop(v181_19);
    let v181_21: Path = concat_path(&(v181_20),&(*capture_7));
    drop(v181_20);
    let v181_22: Path = concat_path(&(v181_21),&(*capture_8));
    drop(v181_21);
    let v181_23: Path = concat_path(&(v181_22),&(*capture_0));
    drop(v181_22);
    let v181_24: Space = singleton(&(v181_23));
    drop(v181_23);
    let mut v181_87 = Space::new();
    let mut v181_87_cursor = (v181_24).read_zipper();
    for v181_87_byte in v181_87_cursor.child_mask().iter() {
      v181_87_cursor.descend_to_byte(v181_87_byte);
      let v181_87_tail = v181_87_cursor.make_map();
      v181_87_cursor.ascend(1);
      let v181_87_head = Path::from_slice(&[v181_87_byte]);
      let v182_2: Space = singleton(&(v181_87_head));
      let v182_3: Space = intersect(&(*CONSTANT_7),&(v182_2));
      let v182_4: Space = if has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
      drop(v182_3);
      let v182_5: Space = subtract(&(*CONSTANT_0),&(v182_4));
      drop(v182_4);
      let v182_7: Space = if (v182_5).is_empty() { Space::new() } else {
        let v183_6: Space = routine_45(c, &(v181_87_head), &(v181_87_tail));
        compose(&(v182_5),&(v183_6))
      };
      drop(v182_5);
      let v182_8: Space = intersect(&(*CONSTANT_7),&(v182_2));
      drop(v182_2);
      let v182_9: Space = if has_head(&(v182_8)) { singleton(&[]) } else { Space::new() };
      drop(v182_8);
      let v182_11: Space = if (v182_9).is_empty() { Space::new() } else {
        let v184_10: Space = routine_46(c, &(v181_87_head), &(v181_87_tail));
        compose(&(v182_9),&(v184_10))
      };
      drop(v182_9);
      let v182_12: Space = unite(&(v182_7),&(v182_11));
      v181_87.join_into((v182_12).clone());
    }
    drop(v181_87_cursor);
    compose(&(v142_83),&(v181_87))
  };
  let v142_89: Space = unite(&(v142_77),&(v142_88));
  let v142_91: Space = intersect(&(*CONSTANT_14),&(v142_11));
  let mut v142_95 = Space::new();
  let mut v142_95_cursor = (v142_91).read_zipper();
  for v142_95_byte in v142_95_cursor.child_mask().iter() {
    v142_95_cursor.descend_to_byte(v142_95_byte);
    let v142_95_tail = v142_95_cursor.make_map();
    v142_95_cursor.ascend(1);
    let v142_95_head = Path::from_slice(&[v142_95_byte]);
    let v185_2: Space = singleton(&(v142_95_head));
    let v185_3: Space = intersect(&(*CONSTANT_7),&(v185_2));
    let v185_4: Space = if has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
    drop(v185_3);
    let v185_5: Space = subtract(&(*CONSTANT_0),&(v185_4));
    drop(v185_4);
    let v185_7: Space = if (v185_5).is_empty() { Space::new() } else {
      let v186_6: Space = routine_47(c, &(v142_95_head), &(v142_95_tail));
      compose(&(v185_5),&(v186_6))
    };
    drop(v185_5);
    let v185_8: Space = intersect(&(*CONSTANT_7),&(v185_2));
    drop(v185_2);
    let v185_9: Space = if has_head(&(v185_8)) { singleton(&[]) } else { Space::new() };
    drop(v185_8);
    let v185_11: Space = if (v185_9).is_empty() { Space::new() } else {
      let v187_10: Space = routine_48(c, &(v142_95_head), &(v142_95_tail));
      compose(&(v185_9),&(v187_10))
    };
    drop(v185_9);
    let v185_12: Space = unite(&(v185_7),&(v185_11));
    v142_95.join_into((v185_12).clone());
  }
  drop(v142_95_cursor);
  drop(v142_91);
  let v142_100: Space = if (v142_95).is_empty() { Space::new() } else {
    let v188_17: Path = concat_path(&(*capture_2),&(*capture_3));
    let v188_18: Path = concat_path(&(v188_17),&(*capture_4));
    drop(v188_17);
    let v188_19: Path = concat_path(&(v188_18),&(*capture_5));
    drop(v188_18);
    let v188_20: Path = concat_path(&(v188_19),&(*capture_6));
    drop(v188_19);
    let v188_21: Path = concat_path(&(v188_20),&(*capture_7));
    drop(v188_20);
    let v188_22: Path = concat_path(&(v188_21),&(*capture_8));
    drop(v188_21);
    let v188_23: Path = concat_path(&(v188_22),&(*capture_0));
    drop(v188_22);
    let v188_24: Space = singleton(&(v188_23));
    drop(v188_23);
    let mut v188_99 = Space::new();
    let mut v188_99_cursor = (v188_24).read_zipper();
    for v188_99_byte in v188_99_cursor.child_mask().iter() {
      v188_99_cursor.descend_to_byte(v188_99_byte);
      let v188_99_tail = v188_99_cursor.make_map();
      v188_99_cursor.ascend(1);
      let v188_99_head = Path::from_slice(&[v188_99_byte]);
      let v189_2: Space = singleton(&(v188_99_head));
      let v189_3: Space = intersect(&(*CONSTANT_7),&(v189_2));
      let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
      drop(v189_3);
      let v189_5: Space = subtract(&(*CONSTANT_0),&(v189_4));
      drop(v189_4);
      let v189_7: Space = if (v189_5).is_empty() { Space::new() } else {
        let v190_6: Space = routine_49(c, &(v188_99_head), &(v188_99_tail));
        compose(&(v189_5),&(v190_6))
      };
      drop(v189_5);
      let v189_8: Space = intersect(&(*CONSTANT_7),&(v189_2));
      drop(v189_2);
      let v189_9: Space = if has_head(&(v189_8)) { singleton(&[]) } else { Space::new() };
      drop(v189_8);
      let v189_11: Space = if (v189_9).is_empty() { Space::new() } else {
        let v191_10: Space = routine_50(c, &(v188_99_head), &(v188_99_tail));
        compose(&(v189_9),&(v191_10))
      };
      drop(v189_9);
      let v189_12: Space = unite(&(v189_7),&(v189_11));
      v188_99.join_into((v189_12).clone());
    }
    drop(v188_99_cursor);
    compose(&(v142_95),&(v188_99))
  };
  let v142_101: Space = unite(&(v142_89),&(v142_100));
  let v142_103: Space = intersect(&(*CONSTANT_15),&(v142_11));
  let mut v142_107 = Space::new();
  let mut v142_107_cursor = (v142_103).read_zipper();
  for v142_107_byte in v142_107_cursor.child_mask().iter() {
    v142_107_cursor.descend_to_byte(v142_107_byte);
    let v142_107_tail = v142_107_cursor.make_map();
    v142_107_cursor.ascend(1);
    let v142_107_head = Path::from_slice(&[v142_107_byte]);
    let v192_2: Space = singleton(&(v142_107_head));
    let v192_3: Space = intersect(&(*CONSTANT_7),&(v192_2));
    let v192_4: Space = if has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
    drop(v192_3);
    let v192_5: Space = subtract(&(*CONSTANT_0),&(v192_4));
    drop(v192_4);
    let v192_7: Space = if (v192_5).is_empty() { Space::new() } else {
      let v193_6: Space = routine_51(c, &(v142_107_head), &(v142_107_tail));
      compose(&(v192_5),&(v193_6))
    };
    drop(v192_5);
    let v192_8: Space = intersect(&(*CONSTANT_7),&(v192_2));
    drop(v192_2);
    let v192_9: Space = if has_head(&(v192_8)) { singleton(&[]) } else { Space::new() };
    drop(v192_8);
    let v192_11: Space = if (v192_9).is_empty() { Space::new() } else {
      let v194_10: Space = routine_52(c, &(v142_107_head), &(v142_107_tail));
      compose(&(v192_9),&(v194_10))
    };
    drop(v192_9);
    let v192_12: Space = unite(&(v192_7),&(v192_11));
    v142_107.join_into((v192_12).clone());
  }
  drop(v142_107_cursor);
  drop(v142_103);
  let v142_112: Space = if (v142_107).is_empty() { Space::new() } else {
    let v195_17: Path = concat_path(&(*capture_2),&(*capture_3));
    let v195_18: Path = concat_path(&(v195_17),&(*capture_4));
    drop(v195_17);
    let v195_19: Path = concat_path(&(v195_18),&(*capture_5));
    drop(v195_18);
    let v195_20: Path = concat_path(&(v195_19),&(*capture_6));
    drop(v195_19);
    let v195_21: Path = concat_path(&(v195_20),&(*capture_7));
    drop(v195_20);
    let v195_22: Path = concat_path(&(v195_21),&(*capture_8));
    drop(v195_21);
    let v195_23: Path = concat_path(&(v195_22),&(*capture_0));
    drop(v195_22);
    let v195_24: Space = singleton(&(v195_23));
    drop(v195_23);
    let mut v195_111 = Space::new();
    let mut v195_111_cursor = (v195_24).read_zipper();
    for v195_111_byte in v195_111_cursor.child_mask().iter() {
      v195_111_cursor.descend_to_byte(v195_111_byte);
      let v195_111_tail = v195_111_cursor.make_map();
      v195_111_cursor.ascend(1);
      let v195_111_head = Path::from_slice(&[v195_111_byte]);
      let v196_2: Space = singleton(&(v195_111_head));
      let v196_3: Space = intersect(&(*CONSTANT_7),&(v196_2));
      let v196_4: Space = if has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
      drop(v196_3);
      let v196_5: Space = subtract(&(*CONSTANT_0),&(v196_4));
      drop(v196_4);
      let v196_7: Space = if (v196_5).is_empty() { Space::new() } else {
        let v197_6: Space = routine_53(c, &(v195_111_head), &(v195_111_tail));
        compose(&(v196_5),&(v197_6))
      };
      drop(v196_5);
      let v196_8: Space = intersect(&(*CONSTANT_7),&(v196_2));
      drop(v196_2);
      let v196_9: Space = if has_head(&(v196_8)) { singleton(&[]) } else { Space::new() };
      drop(v196_8);
      let v196_11: Space = if (v196_9).is_empty() { Space::new() } else {
        let v198_10: Space = routine_54(c, &(v195_111_head), &(v195_111_tail));
        compose(&(v196_9),&(v198_10))
      };
      drop(v196_9);
      let v196_12: Space = unite(&(v196_7),&(v196_11));
      v195_111.join_into((v196_12).clone());
    }
    drop(v195_111_cursor);
    compose(&(v142_107),&(v195_111))
  };
  let v142_113: Space = unite(&(v142_101),&(v142_112));
  let v142_115: Space = intersect(&(*CONSTANT_16),&(v142_11));
  drop(v142_11);
  let mut v142_119 = Space::new();
  let mut v142_119_cursor = (v142_115).read_zipper();
  for v142_119_byte in v142_119_cursor.child_mask().iter() {
    v142_119_cursor.descend_to_byte(v142_119_byte);
    let v142_119_tail = v142_119_cursor.make_map();
    v142_119_cursor.ascend(1);
    let v142_119_head = Path::from_slice(&[v142_119_byte]);
    let v199_2: Space = singleton(&(v142_119_head));
    let v199_3: Space = intersect(&(*CONSTANT_7),&(v199_2));
    let v199_4: Space = if has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
    drop(v199_3);
    let v199_5: Space = subtract(&(*CONSTANT_0),&(v199_4));
    drop(v199_4);
    let v199_7: Space = if (v199_5).is_empty() { Space::new() } else {
      let v200_6: Space = routine_55(c, &(v142_119_head), &(v142_119_tail));
      compose(&(v199_5),&(v200_6))
    };
    drop(v199_5);
    let v199_8: Space = intersect(&(*CONSTANT_7),&(v199_2));
    drop(v199_2);
    let v199_9: Space = if has_head(&(v199_8)) { singleton(&[]) } else { Space::new() };
    drop(v199_8);
    let v199_11: Space = if (v199_9).is_empty() { Space::new() } else {
      let v201_10: Space = routine_56(c, &(v142_119_head), &(v142_119_tail));
      compose(&(v199_9),&(v201_10))
    };
    drop(v199_9);
    let v199_12: Space = unite(&(v199_7),&(v199_11));
    v142_119.join_into((v199_12).clone());
  }
  drop(v142_119_cursor);
  drop(v142_115);
  let v142_124: Space = if (v142_119).is_empty() { Space::new() } else {
    let v202_17: Path = concat_path(&(*capture_2),&(*capture_3));
    let v202_18: Path = concat_path(&(v202_17),&(*capture_4));
    drop(v202_17);
    let v202_19: Path = concat_path(&(v202_18),&(*capture_5));
    drop(v202_18);
    let v202_20: Path = concat_path(&(v202_19),&(*capture_6));
    drop(v202_19);
    let v202_21: Path = concat_path(&(v202_20),&(*capture_7));
    drop(v202_20);
    let v202_22: Path = concat_path(&(v202_21),&(*capture_8));
    drop(v202_21);
    let v202_23: Path = concat_path(&(v202_22),&(*capture_0));
    drop(v202_22);
    let v202_24: Space = singleton(&(v202_23));
    drop(v202_23);
    let mut v202_123 = Space::new();
    let mut v202_123_cursor = (v202_24).read_zipper();
    for v202_123_byte in v202_123_cursor.child_mask().iter() {
      v202_123_cursor.descend_to_byte(v202_123_byte);
      let v202_123_tail = v202_123_cursor.make_map();
      v202_123_cursor.ascend(1);
      let v202_123_head = Path::from_slice(&[v202_123_byte]);
      let v203_2: Space = singleton(&(v202_123_head));
      let v203_3: Space = intersect(&(*CONSTANT_7),&(v203_2));
      let v203_4: Space = if has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
      drop(v203_3);
      let v203_5: Space = subtract(&(*CONSTANT_0),&(v203_4));
      drop(v203_4);
      let v203_7: Space = if (v203_5).is_empty() { Space::new() } else {
        let v204_6: Space = routine_57(c, &(v202_123_head), &(v202_123_tail));
        compose(&(v203_5),&(v204_6))
      };
      drop(v203_5);
      let v203_8: Space = intersect(&(*CONSTANT_7),&(v203_2));
      drop(v203_2);
      let v203_9: Space = if has_head(&(v203_8)) { singleton(&[]) } else { Space::new() };
      drop(v203_8);
      let v203_11: Space = if (v203_9).is_empty() { Space::new() } else {
        let v205_10: Space = routine_58(c, &(v202_123_head), &(v202_123_tail));
        compose(&(v203_9),&(v205_10))
      };
      drop(v203_9);
      let v203_12: Space = unite(&(v203_7),&(v203_11));
      v202_123.join_into((v203_12).clone());
    }
    drop(v202_123_cursor);
    drop(v202_24);
    compose(&(v142_119),&(v202_123))
  };

((v142_100).clone(),(v142_101).clone(),(v142_107).clone(),(v142_112).clone(),(v142_113).clone(),(v142_119).clone(),(v142_124).clone(),(v142_16).clone(),(v142_29).clone(),(v142_35).clone(),(v142_40).clone(),(v142_41).clone(),(v142_47).clone(),(v142_52).clone(),(v142_53).clone(),(v142_59).clone(),(v142_64).clone(),(v142_65).clone(),(v142_71).clone(),(v142_76).clone(),(v142_77).clone(),(v142_83).clone(),(v142_88).clone(),(v142_89).clone(),(v142_95).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &Path,capture_1: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v226_3: Space = singleton(&(*capture_0));
  let v226_4: Space = intersect(&(*CONSTANT_8),&(v226_3));
  let mut v226_11 = Space::new();
  let mut v226_11_cursor = (v226_4).read_zipper();
  for v226_11_byte in v226_11_cursor.child_mask().iter() {
    v226_11_cursor.descend_to_byte(v226_11_byte);
    let v226_11_tail = v226_11_cursor.make_map();
    v226_11_cursor.ascend(1);
    let v226_11_head = Path::from_slice(&[v226_11_byte]);
    let v227_2: Space = singleton(&(v226_11_head));
    let v227_3: Space = intersect(&(*CONSTANT_7),&(v227_2));
    let v227_4: Space = if has_head(&(v227_3)) { singleton(&[]) } else { Space::new() };
    drop(v227_3);
    let v227_5: Space = subtract(&(*CONSTANT_0),&(v227_4));
    drop(v227_4);
    let v227_7: Space = if (v227_5).is_empty() { Space::new() } else {
      let mut v228_6 = Space::new();
      let mut v228_6_cursor = (v226_11_tail).read_zipper();
      for v228_6_byte in v228_6_cursor.child_mask().iter() {
        v228_6_cursor.descend_to_byte(v228_6_byte);
        let v228_6_tail = v228_6_cursor.make_map();
        v228_6_cursor.ascend(1);
        let v228_6_head = Path::from_slice(&[v228_6_byte]);
        let v229_2: Space = singleton(&(v228_6_head));
        let v229_3: Space = intersect(&(*CONSTANT_7),&(v229_2));
        let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
        drop(v229_3);
        let v229_5: Space = subtract(&(*CONSTANT_0),&(v229_4));
        drop(v229_4);
        let v229_8: Space = if (v229_5).is_empty() { Space::new() } else {
          let v230_6: Path = concat_path(&(v226_11_head),&(v228_6_head));
          let v230_7: Space = routine_23(c, &(v230_6), &(v228_6_tail));
          compose(&(v229_5),&(v230_7))
        };
        drop(v229_5);
        let v229_9: Space = intersect(&(*CONSTANT_7),&(v229_2));
        drop(v229_2);
        let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
        drop(v229_9);
        let v229_12: Space = if (v229_10).is_empty() { Space::new() } else {
          let v231_6: Path = concat_path(&(v226_11_head),&(v228_6_head));
          let v231_11: Space = routine_24(c, &(v231_6), &(v228_6_tail));
          drop(v231_6);
          compose(&(v229_10),&(v231_11))
        };
        drop(v229_10);
        let v229_13: Space = unite(&(v229_8),&(v229_12));
        v228_6.join_into((v229_13).clone());
      }
      drop(v228_6_cursor);
      compose(&(v227_5),&(v228_6))
    };
    drop(v227_5);
    let v227_8: Space = intersect(&(*CONSTANT_7),&(v227_2));
    drop(v227_2);
    let v227_9: Space = if has_head(&(v227_8)) { singleton(&[]) } else { Space::new() };
    drop(v227_8);
    let v227_10: Space = compose(&(v227_9),&(v226_11_tail));
    drop(v227_9);
    let v227_11: Space = unite(&(v227_7),&(v227_10));
    drop(v227_10);
    v226_11.join_into((v227_11).clone());
  }
  drop(v226_11_cursor);
  drop(v226_4);
  let v226_22: Space = if (v226_11).is_empty() { Space::new() } else {
    let mut v232_21 = Space::new();
    let mut v232_21_cursor = (*capture_1).read_zipper();
    for v232_21_byte in v232_21_cursor.child_mask().iter() {
      v232_21_cursor.descend_to_byte(v232_21_byte);
      let v232_21_tail = v232_21_cursor.make_map();
      v232_21_cursor.ascend(1);
      let v232_21_head = Path::from_slice(&[v232_21_byte]);
      let v233_2: Space = singleton(&(v232_21_head));
      let v233_3: Space = intersect(&(*CONSTANT_7),&(v233_2));
      let v233_4: Space = if has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
      drop(v233_3);
      let v233_5: Space = subtract(&(*CONSTANT_0),&(v233_4));
      drop(v233_4);
      let v233_7: Space = if (v233_5).is_empty() { Space::new() } else {
        let mut v234_6 = Space::new();
        let mut v234_6_cursor = (v232_21_tail).read_zipper();
        for v234_6_byte in v234_6_cursor.child_mask().iter() {
          v234_6_cursor.descend_to_byte(v234_6_byte);
          let v234_6_tail = v234_6_cursor.make_map();
          v234_6_cursor.ascend(1);
          let v234_6_head = Path::from_slice(&[v234_6_byte]);
          let v235_2: Space = singleton(&(v234_6_head));
          let v235_3: Space = intersect(&(*CONSTANT_7),&(v235_2));
          let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
          drop(v235_3);
          let v235_5: Space = subtract(&(*CONSTANT_0),&(v235_4));
          drop(v235_4);
          let v235_8: Space = if (v235_5).is_empty() { Space::new() } else {
            let v236_6: Path = concat_path(&(v232_21_head),&(v234_6_head));
            let v236_7: Space = routine_25(c, &(v236_6), &(v234_6_tail));
            compose(&(v235_5),&(v236_7))
          };
          drop(v235_5);
          let v235_9: Space = intersect(&(*CONSTANT_7),&(v235_2));
          drop(v235_2);
          let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
          drop(v235_9);
          let v235_12: Space = if (v235_10).is_empty() { Space::new() } else {
            let v237_6: Path = concat_path(&(v232_21_head),&(v234_6_head));
            let v237_11: Space = routine_26(c, &(v237_6), &(v234_6_tail));
            drop(v237_6);
            compose(&(v235_10),&(v237_11))
          };
          drop(v235_10);
          let v235_13: Space = unite(&(v235_8),&(v235_12));
          v234_6.join_into((v235_13).clone());
        }
        drop(v234_6_cursor);
        compose(&(v233_5),&(v234_6))
      };
      drop(v233_5);
      let v233_8: Space = intersect(&(*CONSTANT_7),&(v233_2));
      drop(v233_2);
      let v233_9: Space = if has_head(&(v233_8)) { singleton(&[]) } else { Space::new() };
      drop(v233_8);
      let v233_11: Space = if (v233_9).is_empty() { Space::new() } else {
        let mut v238_10 = Space::new();
        let mut v238_10_cursor = (v232_21_tail).read_zipper();
        for v238_10_byte in v238_10_cursor.child_mask().iter() {
          v238_10_cursor.descend_to_byte(v238_10_byte);
          let v238_10_tail = v238_10_cursor.make_map();
          v238_10_cursor.ascend(1);
          let v238_10_head = Path::from_slice(&[v238_10_byte]);
          let v239_2: Space = singleton(&(v238_10_head));
          let v239_3: Space = intersect(&(*CONSTANT_7),&(v239_2));
          let v239_4: Space = if has_head(&(v239_3)) { singleton(&[]) } else { Space::new() };
          drop(v239_3);
          let v239_5: Space = subtract(&(*CONSTANT_0),&(v239_4));
          drop(v239_4);
          let v239_7: Space = if (v239_5).is_empty() { Space::new() } else {
            let v240_6: Space = routine_65(c, &(v238_10_head), &(v232_21_head), &(v238_10_tail));
            compose(&(v239_5),&(v240_6))
          };
          drop(v239_5);
          let v239_8: Space = intersect(&(*CONSTANT_7),&(v239_2));
          drop(v239_2);
          let v239_9: Space = if has_head(&(v239_8)) { singleton(&[]) } else { Space::new() };
          drop(v239_8);
          let v239_11: Space = if (v239_9).is_empty() { Space::new() } else {
            let v241_10: Space = routine_66(c, &(v238_10_head), &(v232_21_head), &(v238_10_tail));
            compose(&(v239_9),&(v241_10))
          };
          drop(v239_9);
          let v239_12: Space = unite(&(v239_7),&(v239_11));
          v238_10.join_into((v239_12).clone());
        }
        drop(v238_10_cursor);
        compose(&(v233_9),&(v238_10))
      };
      drop(v233_9);
      let v233_12: Space = unite(&(v233_7),&(v233_11));
      v232_21.join_into((v233_12).clone());
    }
    drop(v232_21_cursor);
    compose(&(v226_11),&(v232_21))
  };
  let v226_24: Space = intersect(&(*CONSTANT_9),&(v226_3));
  let mut v226_31 = Space::new();
  let mut v226_31_cursor = (v226_24).read_zipper();
  for v226_31_byte in v226_31_cursor.child_mask().iter() {
    v226_31_cursor.descend_to_byte(v226_31_byte);
    let v226_31_tail = v226_31_cursor.make_map();
    v226_31_cursor.ascend(1);
    let v226_31_head = Path::from_slice(&[v226_31_byte]);
    let v242_2: Space = singleton(&(v226_31_head));
    let v242_3: Space = intersect(&(*CONSTANT_7),&(v242_2));
    let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
    drop(v242_3);
    let v242_5: Space = subtract(&(*CONSTANT_0),&(v242_4));
    drop(v242_4);
    let v242_7: Space = if (v242_5).is_empty() { Space::new() } else {
      let mut v243_6 = Space::new();
      let mut v243_6_cursor = (v226_31_tail).read_zipper();
      for v243_6_byte in v243_6_cursor.child_mask().iter() {
        v243_6_cursor.descend_to_byte(v243_6_byte);
        let v243_6_tail = v243_6_cursor.make_map();
        v243_6_cursor.ascend(1);
        let v243_6_head = Path::from_slice(&[v243_6_byte]);
        let v244_2: Space = singleton(&(v243_6_head));
        let v244_3: Space = intersect(&(*CONSTANT_7),&(v244_2));
        let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
        drop(v244_3);
        let v244_5: Space = subtract(&(*CONSTANT_0),&(v244_4));
        drop(v244_4);
        let v244_8: Space = if (v244_5).is_empty() { Space::new() } else {
          let v245_6: Path = concat_path(&(v226_31_head),&(v243_6_head));
          let v245_7: Space = routine_27(c, &(v245_6), &(v243_6_tail));
          compose(&(v244_5),&(v245_7))
        };
        drop(v244_5);
        let v244_9: Space = intersect(&(*CONSTANT_7),&(v244_2));
        drop(v244_2);
        let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
        drop(v244_9);
        let v244_12: Space = if (v244_10).is_empty() { Space::new() } else {
          let v246_6: Path = concat_path(&(v226_31_head),&(v243_6_head));
          let v246_11: Space = routine_28(c, &(v246_6), &(v243_6_tail));
          drop(v246_6);
          compose(&(v244_10),&(v246_11))
        };
        drop(v244_10);
        let v244_13: Space = unite(&(v244_8),&(v244_12));
        v243_6.join_into((v244_13).clone());
      }
      drop(v243_6_cursor);
      compose(&(v242_5),&(v243_6))
    };
    drop(v242_5);
    let v242_8: Space = intersect(&(*CONSTANT_7),&(v242_2));
    drop(v242_2);
    let v242_9: Space = if has_head(&(v242_8)) { singleton(&[]) } else { Space::new() };
    drop(v242_8);
    let v242_10: Space = compose(&(v242_9),&(v226_31_tail));
    drop(v242_9);
    let v242_11: Space = unite(&(v242_7),&(v242_10));
    drop(v242_10);
    v226_31.join_into((v242_11).clone());
  }
  drop(v226_31_cursor);
  drop(v226_24);
  let v226_42: Space = if (v226_31).is_empty() { Space::new() } else {
    let mut v247_41 = Space::new();
    let mut v247_41_cursor = (*capture_1).read_zipper();
    for v247_41_byte in v247_41_cursor.child_mask().iter() {
      v247_41_cursor.descend_to_byte(v247_41_byte);
      let v247_41_tail = v247_41_cursor.make_map();
      v247_41_cursor.ascend(1);
      let v247_41_head = Path::from_slice(&[v247_41_byte]);
      let v248_2: Space = singleton(&(v247_41_head));
      let v248_3: Space = intersect(&(*CONSTANT_7),&(v248_2));
      let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
      drop(v248_3);
      let v248_5: Space = subtract(&(*CONSTANT_0),&(v248_4));
      drop(v248_4);
      let v248_7: Space = if (v248_5).is_empty() { Space::new() } else {
        let mut v249_6 = Space::new();
        let mut v249_6_cursor = (v247_41_tail).read_zipper();
        for v249_6_byte in v249_6_cursor.child_mask().iter() {
          v249_6_cursor.descend_to_byte(v249_6_byte);
          let v249_6_tail = v249_6_cursor.make_map();
          v249_6_cursor.ascend(1);
          let v249_6_head = Path::from_slice(&[v249_6_byte]);
          let v250_2: Space = singleton(&(v249_6_head));
          let v250_3: Space = intersect(&(*CONSTANT_7),&(v250_2));
          let v250_4: Space = if has_head(&(v250_3)) { singleton(&[]) } else { Space::new() };
          drop(v250_3);
          let v250_5: Space = subtract(&(*CONSTANT_0),&(v250_4));
          drop(v250_4);
          let v250_8: Space = if (v250_5).is_empty() { Space::new() } else {
            let v251_6: Path = concat_path(&(v247_41_head),&(v249_6_head));
            let v251_7: Space = routine_29(c, &(v251_6), &(v249_6_tail));
            compose(&(v250_5),&(v251_7))
          };
          drop(v250_5);
          let v250_9: Space = intersect(&(*CONSTANT_7),&(v250_2));
          drop(v250_2);
          let v250_10: Space = if has_head(&(v250_9)) { singleton(&[]) } else { Space::new() };
          drop(v250_9);
          let v250_12: Space = if (v250_10).is_empty() { Space::new() } else {
            let v252_6: Path = concat_path(&(v247_41_head),&(v249_6_head));
            let v252_11: Space = routine_30(c, &(v252_6), &(v249_6_tail));
            drop(v252_6);
            compose(&(v250_10),&(v252_11))
          };
          drop(v250_10);
          let v250_13: Space = unite(&(v250_8),&(v250_12));
          v249_6.join_into((v250_13).clone());
        }
        drop(v249_6_cursor);
        compose(&(v248_5),&(v249_6))
      };
      drop(v248_5);
      let v248_8: Space = intersect(&(*CONSTANT_7),&(v248_2));
      drop(v248_2);
      let v248_9: Space = if has_head(&(v248_8)) { singleton(&[]) } else { Space::new() };
      drop(v248_8);
      let v248_11: Space = if (v248_9).is_empty() { Space::new() } else {
        let mut v253_10 = Space::new();
        let mut v253_10_cursor = (v247_41_tail).read_zipper();
        for v253_10_byte in v253_10_cursor.child_mask().iter() {
          v253_10_cursor.descend_to_byte(v253_10_byte);
          let v253_10_tail = v253_10_cursor.make_map();
          v253_10_cursor.ascend(1);
          let v253_10_head = Path::from_slice(&[v253_10_byte]);
          let v254_2: Space = singleton(&(v253_10_head));
          let v254_3: Space = intersect(&(*CONSTANT_7),&(v254_2));
          let v254_4: Space = if has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
          drop(v254_3);
          let v254_5: Space = subtract(&(*CONSTANT_0),&(v254_4));
          drop(v254_4);
          let v254_7: Space = if (v254_5).is_empty() { Space::new() } else {
            let v255_6: Space = routine_67(c, &(v253_10_head), &(v247_41_head), &(v253_10_tail));
            compose(&(v254_5),&(v255_6))
          };
          drop(v254_5);
          let v254_8: Space = intersect(&(*CONSTANT_7),&(v254_2));
          drop(v254_2);
          let v254_9: Space = if has_head(&(v254_8)) { singleton(&[]) } else { Space::new() };
          drop(v254_8);
          let v254_11: Space = if (v254_9).is_empty() { Space::new() } else {
            let v256_10: Space = routine_68(c, &(v253_10_head), &(v247_41_head), &(v253_10_tail));
            compose(&(v254_9),&(v256_10))
          };
          drop(v254_9);
          let v254_12: Space = unite(&(v254_7),&(v254_11));
          v253_10.join_into((v254_12).clone());
        }
        drop(v253_10_cursor);
        compose(&(v248_9),&(v253_10))
      };
      drop(v248_9);
      let v248_12: Space = unite(&(v248_7),&(v248_11));
      v247_41.join_into((v248_12).clone());
    }
    drop(v247_41_cursor);
    compose(&(v226_31),&(v247_41))
  };
  let v226_43: Space = unite(&(v226_22),&(v226_42));
  let v226_45: Space = intersect(&(*CONSTANT_10),&(v226_3));
  let mut v226_52 = Space::new();
  let mut v226_52_cursor = (v226_45).read_zipper();
  for v226_52_byte in v226_52_cursor.child_mask().iter() {
    v226_52_cursor.descend_to_byte(v226_52_byte);
    let v226_52_tail = v226_52_cursor.make_map();
    v226_52_cursor.ascend(1);
    let v226_52_head = Path::from_slice(&[v226_52_byte]);
    let v257_2: Space = singleton(&(v226_52_head));
    let v257_3: Space = intersect(&(*CONSTANT_7),&(v257_2));
    let v257_4: Space = if has_head(&(v257_3)) { singleton(&[]) } else { Space::new() };
    drop(v257_3);
    let v257_5: Space = subtract(&(*CONSTANT_0),&(v257_4));
    drop(v257_4);
    let v257_7: Space = if (v257_5).is_empty() { Space::new() } else {
      let mut v258_6 = Space::new();
      let mut v258_6_cursor = (v226_52_tail).read_zipper();
      for v258_6_byte in v258_6_cursor.child_mask().iter() {
        v258_6_cursor.descend_to_byte(v258_6_byte);
        let v258_6_tail = v258_6_cursor.make_map();
        v258_6_cursor.ascend(1);
        let v258_6_head = Path::from_slice(&[v258_6_byte]);
        let v259_2: Space = singleton(&(v258_6_head));
        let v259_3: Space = intersect(&(*CONSTANT_7),&(v259_2));
        let v259_4: Space = if has_head(&(v259_3)) { singleton(&[]) } else { Space::new() };
        drop(v259_3);
        let v259_5: Space = subtract(&(*CONSTANT_0),&(v259_4));
        drop(v259_4);
        let v259_8: Space = if (v259_5).is_empty() { Space::new() } else {
          let v260_6: Path = concat_path(&(v226_52_head),&(v258_6_head));
          let v260_7: Space = routine_31(c, &(v260_6), &(v258_6_tail));
          compose(&(v259_5),&(v260_7))
        };
        drop(v259_5);
        let v259_9: Space = intersect(&(*CONSTANT_7),&(v259_2));
        drop(v259_2);
        let v259_10: Space = if has_head(&(v259_9)) { singleton(&[]) } else { Space::new() };
        drop(v259_9);
        let v259_12: Space = if (v259_10).is_empty() { Space::new() } else {
          let v261_6: Path = concat_path(&(v226_52_head),&(v258_6_head));
          let v261_11: Space = routine_32(c, &(v261_6), &(v258_6_tail));
          drop(v261_6);
          compose(&(v259_10),&(v261_11))
        };
        drop(v259_10);
        let v259_13: Space = unite(&(v259_8),&(v259_12));
        v258_6.join_into((v259_13).clone());
      }
      drop(v258_6_cursor);
      compose(&(v257_5),&(v258_6))
    };
    drop(v257_5);
    let v257_8: Space = intersect(&(*CONSTANT_7),&(v257_2));
    drop(v257_2);
    let v257_9: Space = if has_head(&(v257_8)) { singleton(&[]) } else { Space::new() };
    drop(v257_8);
    let v257_10: Space = compose(&(v257_9),&(v226_52_tail));
    drop(v257_9);
    let v257_11: Space = unite(&(v257_7),&(v257_10));
    drop(v257_10);
    v226_52.join_into((v257_11).clone());
  }
  drop(v226_52_cursor);
  drop(v226_45);
  let v226_63: Space = if (v226_52).is_empty() { Space::new() } else {
    let mut v262_62 = Space::new();
    let mut v262_62_cursor = (*capture_1).read_zipper();
    for v262_62_byte in v262_62_cursor.child_mask().iter() {
      v262_62_cursor.descend_to_byte(v262_62_byte);
      let v262_62_tail = v262_62_cursor.make_map();
      v262_62_cursor.ascend(1);
      let v262_62_head = Path::from_slice(&[v262_62_byte]);
      let v263_2: Space = singleton(&(v262_62_head));
      let v263_3: Space = intersect(&(*CONSTANT_7),&(v263_2));
      let v263_4: Space = if has_head(&(v263_3)) { singleton(&[]) } else { Space::new() };
      drop(v263_3);
      let v263_5: Space = subtract(&(*CONSTANT_0),&(v263_4));
      drop(v263_4);
      let v263_7: Space = if (v263_5).is_empty() { Space::new() } else {
        let mut v264_6 = Space::new();
        let mut v264_6_cursor = (v262_62_tail).read_zipper();
        for v264_6_byte in v264_6_cursor.child_mask().iter() {
          v264_6_cursor.descend_to_byte(v264_6_byte);
          let v264_6_tail = v264_6_cursor.make_map();
          v264_6_cursor.ascend(1);
          let v264_6_head = Path::from_slice(&[v264_6_byte]);
          let v265_2: Space = singleton(&(v264_6_head));
          let v265_3: Space = intersect(&(*CONSTANT_7),&(v265_2));
          let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
          drop(v265_3);
          let v265_5: Space = subtract(&(*CONSTANT_0),&(v265_4));
          drop(v265_4);
          let v265_8: Space = if (v265_5).is_empty() { Space::new() } else {
            let v266_6: Path = concat_path(&(v262_62_head),&(v264_6_head));
            let v266_7: Space = routine_33(c, &(v266_6), &(v264_6_tail));
            compose(&(v265_5),&(v266_7))
          };
          drop(v265_5);
          let v265_9: Space = intersect(&(*CONSTANT_7),&(v265_2));
          drop(v265_2);
          let v265_10: Space = if has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
          drop(v265_9);
          let v265_12: Space = if (v265_10).is_empty() { Space::new() } else {
            let v267_6: Path = concat_path(&(v262_62_head),&(v264_6_head));
            let v267_11: Space = routine_34(c, &(v267_6), &(v264_6_tail));
            drop(v267_6);
            compose(&(v265_10),&(v267_11))
          };
          drop(v265_10);
          let v265_13: Space = unite(&(v265_8),&(v265_12));
          v264_6.join_into((v265_13).clone());
        }
        drop(v264_6_cursor);
        compose(&(v263_5),&(v264_6))
      };
      drop(v263_5);
      let v263_8: Space = intersect(&(*CONSTANT_7),&(v263_2));
      drop(v263_2);
      let v263_9: Space = if has_head(&(v263_8)) { singleton(&[]) } else { Space::new() };
      drop(v263_8);
      let v263_11: Space = if (v263_9).is_empty() { Space::new() } else {
        let mut v268_10 = Space::new();
        let mut v268_10_cursor = (v262_62_tail).read_zipper();
        for v268_10_byte in v268_10_cursor.child_mask().iter() {
          v268_10_cursor.descend_to_byte(v268_10_byte);
          let v268_10_tail = v268_10_cursor.make_map();
          v268_10_cursor.ascend(1);
          let v268_10_head = Path::from_slice(&[v268_10_byte]);
          let v269_2: Space = singleton(&(v268_10_head));
          let v269_3: Space = intersect(&(*CONSTANT_7),&(v269_2));
          let v269_4: Space = if has_head(&(v269_3)) { singleton(&[]) } else { Space::new() };
          drop(v269_3);
          let v269_5: Space = subtract(&(*CONSTANT_0),&(v269_4));
          drop(v269_4);
          let v269_7: Space = if (v269_5).is_empty() { Space::new() } else {
            let v270_6: Space = routine_69(c, &(v268_10_head), &(v262_62_head), &(v268_10_tail));
            compose(&(v269_5),&(v270_6))
          };
          drop(v269_5);
          let v269_8: Space = intersect(&(*CONSTANT_7),&(v269_2));
          drop(v269_2);
          let v269_9: Space = if has_head(&(v269_8)) { singleton(&[]) } else { Space::new() };
          drop(v269_8);
          let v269_11: Space = if (v269_9).is_empty() { Space::new() } else {
            let v271_10: Space = routine_70(c, &(v268_10_head), &(v262_62_head), &(v268_10_tail));
            compose(&(v269_9),&(v271_10))
          };
          drop(v269_9);
          let v269_12: Space = unite(&(v269_7),&(v269_11));
          v268_10.join_into((v269_12).clone());
        }
        drop(v268_10_cursor);
        compose(&(v263_9),&(v268_10))
      };
      drop(v263_9);
      let v263_12: Space = unite(&(v263_7),&(v263_11));
      v262_62.join_into((v263_12).clone());
    }
    drop(v262_62_cursor);
    compose(&(v226_52),&(v262_62))
  };
  let v226_64: Space = unite(&(v226_43),&(v226_63));
  let v226_66: Space = intersect(&(*CONSTANT_11),&(v226_3));
  let mut v226_73 = Space::new();
  let mut v226_73_cursor = (v226_66).read_zipper();
  for v226_73_byte in v226_73_cursor.child_mask().iter() {
    v226_73_cursor.descend_to_byte(v226_73_byte);
    let v226_73_tail = v226_73_cursor.make_map();
    v226_73_cursor.ascend(1);
    let v226_73_head = Path::from_slice(&[v226_73_byte]);
    let v272_2: Space = singleton(&(v226_73_head));
    let v272_3: Space = intersect(&(*CONSTANT_7),&(v272_2));
    let v272_4: Space = if has_head(&(v272_3)) { singleton(&[]) } else { Space::new() };
    drop(v272_3);
    let v272_5: Space = subtract(&(*CONSTANT_0),&(v272_4));
    drop(v272_4);
    let v272_7: Space = if (v272_5).is_empty() { Space::new() } else {
      let mut v273_6 = Space::new();
      let mut v273_6_cursor = (v226_73_tail).read_zipper();
      for v273_6_byte in v273_6_cursor.child_mask().iter() {
        v273_6_cursor.descend_to_byte(v273_6_byte);
        let v273_6_tail = v273_6_cursor.make_map();
        v273_6_cursor.ascend(1);
        let v273_6_head = Path::from_slice(&[v273_6_byte]);
        let v274_2: Space = singleton(&(v273_6_head));
        let v274_3: Space = intersect(&(*CONSTANT_7),&(v274_2));
        let v274_4: Space = if has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
        drop(v274_3);
        let v274_5: Space = subtract(&(*CONSTANT_0),&(v274_4));
        drop(v274_4);
        let v274_8: Space = if (v274_5).is_empty() { Space::new() } else {
          let v275_6: Path = concat_path(&(v226_73_head),&(v273_6_head));
          let v275_7: Space = routine_35(c, &(v275_6), &(v273_6_tail));
          compose(&(v274_5),&(v275_7))
        };
        drop(v274_5);
        let v274_9: Space = intersect(&(*CONSTANT_7),&(v274_2));
        drop(v274_2);
        let v274_10: Space = if has_head(&(v274_9)) { singleton(&[]) } else { Space::new() };
        drop(v274_9);
        let v274_12: Space = if (v274_10).is_empty() { Space::new() } else {
          let v276_6: Path = concat_path(&(v226_73_head),&(v273_6_head));
          let v276_11: Space = routine_36(c, &(v276_6), &(v273_6_tail));
          drop(v276_6);
          compose(&(v274_10),&(v276_11))
        };
        drop(v274_10);
        let v274_13: Space = unite(&(v274_8),&(v274_12));
        v273_6.join_into((v274_13).clone());
      }
      drop(v273_6_cursor);
      compose(&(v272_5),&(v273_6))
    };
    drop(v272_5);
    let v272_8: Space = intersect(&(*CONSTANT_7),&(v272_2));
    drop(v272_2);
    let v272_9: Space = if has_head(&(v272_8)) { singleton(&[]) } else { Space::new() };
    drop(v272_8);
    let v272_10: Space = compose(&(v272_9),&(v226_73_tail));
    drop(v272_9);
    let v272_11: Space = unite(&(v272_7),&(v272_10));
    drop(v272_10);
    v226_73.join_into((v272_11).clone());
  }
  drop(v226_73_cursor);
  drop(v226_66);
  let v226_84: Space = if (v226_73).is_empty() { Space::new() } else {
    let mut v277_83 = Space::new();
    let mut v277_83_cursor = (*capture_1).read_zipper();
    for v277_83_byte in v277_83_cursor.child_mask().iter() {
      v277_83_cursor.descend_to_byte(v277_83_byte);
      let v277_83_tail = v277_83_cursor.make_map();
      v277_83_cursor.ascend(1);
      let v277_83_head = Path::from_slice(&[v277_83_byte]);
      let v278_2: Space = singleton(&(v277_83_head));
      let v278_3: Space = intersect(&(*CONSTANT_7),&(v278_2));
      let v278_4: Space = if has_head(&(v278_3)) { singleton(&[]) } else { Space::new() };
      drop(v278_3);
      let v278_5: Space = subtract(&(*CONSTANT_0),&(v278_4));
      drop(v278_4);
      let v278_7: Space = if (v278_5).is_empty() { Space::new() } else {
        let mut v279_6 = Space::new();
        let mut v279_6_cursor = (v277_83_tail).read_zipper();
        for v279_6_byte in v279_6_cursor.child_mask().iter() {
          v279_6_cursor.descend_to_byte(v279_6_byte);
          let v279_6_tail = v279_6_cursor.make_map();
          v279_6_cursor.ascend(1);
          let v279_6_head = Path::from_slice(&[v279_6_byte]);
          let v280_2: Space = singleton(&(v279_6_head));
          let v280_3: Space = intersect(&(*CONSTANT_7),&(v280_2));
          let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
          drop(v280_3);
          let v280_5: Space = subtract(&(*CONSTANT_0),&(v280_4));
          drop(v280_4);
          let v280_8: Space = if (v280_5).is_empty() { Space::new() } else {
            let v281_6: Path = concat_path(&(v277_83_head),&(v279_6_head));
            let v281_7: Space = routine_37(c, &(v281_6), &(v279_6_tail));
            compose(&(v280_5),&(v281_7))
          };
          drop(v280_5);
          let v280_9: Space = intersect(&(*CONSTANT_7),&(v280_2));
          drop(v280_2);
          let v280_10: Space = if has_head(&(v280_9)) { singleton(&[]) } else { Space::new() };
          drop(v280_9);
          let v280_12: Space = if (v280_10).is_empty() { Space::new() } else {
            let v282_6: Path = concat_path(&(v277_83_head),&(v279_6_head));
            let v282_11: Space = routine_38(c, &(v282_6), &(v279_6_tail));
            drop(v282_6);
            compose(&(v280_10),&(v282_11))
          };
          drop(v280_10);
          let v280_13: Space = unite(&(v280_8),&(v280_12));
          v279_6.join_into((v280_13).clone());
        }
        drop(v279_6_cursor);
        compose(&(v278_5),&(v279_6))
      };
      drop(v278_5);
      let v278_8: Space = intersect(&(*CONSTANT_7),&(v278_2));
      drop(v278_2);
      let v278_9: Space = if has_head(&(v278_8)) { singleton(&[]) } else { Space::new() };
      drop(v278_8);
      let v278_11: Space = if (v278_9).is_empty() { Space::new() } else {
        let mut v283_10 = Space::new();
        let mut v283_10_cursor = (v277_83_tail).read_zipper();
        for v283_10_byte in v283_10_cursor.child_mask().iter() {
          v283_10_cursor.descend_to_byte(v283_10_byte);
          let v283_10_tail = v283_10_cursor.make_map();
          v283_10_cursor.ascend(1);
          let v283_10_head = Path::from_slice(&[v283_10_byte]);
          let v284_2: Space = singleton(&(v283_10_head));
          let v284_3: Space = intersect(&(*CONSTANT_7),&(v284_2));
          let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
          drop(v284_3);
          let v284_5: Space = subtract(&(*CONSTANT_0),&(v284_4));
          drop(v284_4);
          let v284_7: Space = if (v284_5).is_empty() { Space::new() } else {
            let v285_6: Space = routine_71(c, &(v283_10_head), &(v277_83_head), &(v283_10_tail));
            compose(&(v284_5),&(v285_6))
          };
          drop(v284_5);
          let v284_8: Space = intersect(&(*CONSTANT_7),&(v284_2));
          drop(v284_2);
          let v284_9: Space = if has_head(&(v284_8)) { singleton(&[]) } else { Space::new() };
          drop(v284_8);
          let v284_11: Space = if (v284_9).is_empty() { Space::new() } else {
            let v286_10: Space = routine_72(c, &(v283_10_head), &(v277_83_head), &(v283_10_tail));
            compose(&(v284_9),&(v286_10))
          };
          drop(v284_9);
          let v284_12: Space = unite(&(v284_7),&(v284_11));
          v283_10.join_into((v284_12).clone());
        }
        drop(v283_10_cursor);
        compose(&(v278_9),&(v283_10))
      };
      drop(v278_9);
      let v278_12: Space = unite(&(v278_7),&(v278_11));
      v277_83.join_into((v278_12).clone());
    }
    drop(v277_83_cursor);
    compose(&(v226_73),&(v277_83))
  };
  let v226_85: Space = unite(&(v226_64),&(v226_84));
  let v226_87: Space = intersect(&(*CONSTANT_12),&(v226_3));
  let mut v226_94 = Space::new();
  let mut v226_94_cursor = (v226_87).read_zipper();
  for v226_94_byte in v226_94_cursor.child_mask().iter() {
    v226_94_cursor.descend_to_byte(v226_94_byte);
    let v226_94_tail = v226_94_cursor.make_map();
    v226_94_cursor.ascend(1);
    let v226_94_head = Path::from_slice(&[v226_94_byte]);
    let v287_2: Space = singleton(&(v226_94_head));
    let v287_3: Space = intersect(&(*CONSTANT_7),&(v287_2));
    let v287_4: Space = if has_head(&(v287_3)) { singleton(&[]) } else { Space::new() };
    drop(v287_3);
    let v287_5: Space = subtract(&(*CONSTANT_0),&(v287_4));
    drop(v287_4);
    let v287_7: Space = if (v287_5).is_empty() { Space::new() } else {
      let mut v288_6 = Space::new();
      let mut v288_6_cursor = (v226_94_tail).read_zipper();
      for v288_6_byte in v288_6_cursor.child_mask().iter() {
        v288_6_cursor.descend_to_byte(v288_6_byte);
        let v288_6_tail = v288_6_cursor.make_map();
        v288_6_cursor.ascend(1);
        let v288_6_head = Path::from_slice(&[v288_6_byte]);
        let v289_2: Space = singleton(&(v288_6_head));
        let v289_3: Space = intersect(&(*CONSTANT_7),&(v289_2));
        let v289_4: Space = if has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
        drop(v289_3);
        let v289_5: Space = subtract(&(*CONSTANT_0),&(v289_4));
        drop(v289_4);
        let v289_8: Space = if (v289_5).is_empty() { Space::new() } else {
          let v290_6: Path = concat_path(&(v226_94_head),&(v288_6_head));
          let v290_7: Space = routine_39(c, &(v290_6), &(v288_6_tail));
          compose(&(v289_5),&(v290_7))
        };
        drop(v289_5);
        let v289_9: Space = intersect(&(*CONSTANT_7),&(v289_2));
        drop(v289_2);
        let v289_10: Space = if has_head(&(v289_9)) { singleton(&[]) } else { Space::new() };
        drop(v289_9);
        let v289_12: Space = if (v289_10).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v226_94_head),&(v288_6_head));
          let v291_11: Space = routine_40(c, &(v291_6), &(v288_6_tail));
          drop(v291_6);
          compose(&(v289_10),&(v291_11))
        };
        drop(v289_10);
        let v289_13: Space = unite(&(v289_8),&(v289_12));
        v288_6.join_into((v289_13).clone());
      }
      drop(v288_6_cursor);
      compose(&(v287_5),&(v288_6))
    };
    drop(v287_5);
    let v287_8: Space = intersect(&(*CONSTANT_7),&(v287_2));
    drop(v287_2);
    let v287_9: Space = if has_head(&(v287_8)) { singleton(&[]) } else { Space::new() };
    drop(v287_8);
    let v287_10: Space = compose(&(v287_9),&(v226_94_tail));
    drop(v287_9);
    let v287_11: Space = unite(&(v287_7),&(v287_10));
    drop(v287_10);
    v226_94.join_into((v287_11).clone());
  }
  drop(v226_94_cursor);
  drop(v226_87);

((v226_11).clone(),(v226_22).clone(),(v226_3).clone(),(v226_31).clone(),(v226_42).clone(),(v226_43).clone(),(v226_52).clone(),(v226_63).clone(),(v226_64).clone(),(v226_73).clone(),(v226_84).clone(),(v226_85).clone(),(v226_94).clone(),)
}

#[inline(never)]
fn native_block_2(c: &mut Context,capture_0: &Space,capture_1: &Space,capture_2: &Space,capture_3: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v226_105: Space = if ((*capture_3)).is_empty() { Space::new() } else {
    let mut v292_104 = Space::new();
    let mut v292_104_cursor = (*capture_0).read_zipper();
    for v292_104_byte in v292_104_cursor.child_mask().iter() {
      v292_104_cursor.descend_to_byte(v292_104_byte);
      let v292_104_tail = v292_104_cursor.make_map();
      v292_104_cursor.ascend(1);
      let v292_104_head = Path::from_slice(&[v292_104_byte]);
      let v293_2: Space = singleton(&(v292_104_head));
      let v293_3: Space = intersect(&(*CONSTANT_7),&(v293_2));
      let v293_4: Space = if has_head(&(v293_3)) { singleton(&[]) } else { Space::new() };
      drop(v293_3);
      let v293_5: Space = subtract(&(*CONSTANT_0),&(v293_4));
      drop(v293_4);
      let v293_7: Space = if (v293_5).is_empty() { Space::new() } else {
        let mut v294_6 = Space::new();
        let mut v294_6_cursor = (v292_104_tail).read_zipper();
        for v294_6_byte in v294_6_cursor.child_mask().iter() {
          v294_6_cursor.descend_to_byte(v294_6_byte);
          let v294_6_tail = v294_6_cursor.make_map();
          v294_6_cursor.ascend(1);
          let v294_6_head = Path::from_slice(&[v294_6_byte]);
          let v295_2: Space = singleton(&(v294_6_head));
          let v295_3: Space = intersect(&(*CONSTANT_7),&(v295_2));
          let v295_4: Space = if has_head(&(v295_3)) { singleton(&[]) } else { Space::new() };
          drop(v295_3);
          let v295_5: Space = subtract(&(*CONSTANT_0),&(v295_4));
          drop(v295_4);
          let v295_8: Space = if (v295_5).is_empty() { Space::new() } else {
            let v296_6: Path = concat_path(&(v292_104_head),&(v294_6_head));
            let v296_7: Space = routine_41(c, &(v296_6), &(v294_6_tail));
            compose(&(v295_5),&(v296_7))
          };
          drop(v295_5);
          let v295_9: Space = intersect(&(*CONSTANT_7),&(v295_2));
          drop(v295_2);
          let v295_10: Space = if has_head(&(v295_9)) { singleton(&[]) } else { Space::new() };
          drop(v295_9);
          let v295_12: Space = if (v295_10).is_empty() { Space::new() } else {
            let v297_6: Path = concat_path(&(v292_104_head),&(v294_6_head));
            let v297_11: Space = routine_42(c, &(v297_6), &(v294_6_tail));
            drop(v297_6);
            compose(&(v295_10),&(v297_11))
          };
          drop(v295_10);
          let v295_13: Space = unite(&(v295_8),&(v295_12));
          v294_6.join_into((v295_13).clone());
        }
        drop(v294_6_cursor);
        compose(&(v293_5),&(v294_6))
      };
      drop(v293_5);
      let v293_8: Space = intersect(&(*CONSTANT_7),&(v293_2));
      drop(v293_2);
      let v293_9: Space = if has_head(&(v293_8)) { singleton(&[]) } else { Space::new() };
      drop(v293_8);
      let v293_11: Space = if (v293_9).is_empty() { Space::new() } else {
        let mut v298_10 = Space::new();
        let mut v298_10_cursor = (v292_104_tail).read_zipper();
        for v298_10_byte in v298_10_cursor.child_mask().iter() {
          v298_10_cursor.descend_to_byte(v298_10_byte);
          let v298_10_tail = v298_10_cursor.make_map();
          v298_10_cursor.ascend(1);
          let v298_10_head = Path::from_slice(&[v298_10_byte]);
          let v299_2: Space = singleton(&(v298_10_head));
          let v299_3: Space = intersect(&(*CONSTANT_7),&(v299_2));
          let v299_4: Space = if has_head(&(v299_3)) { singleton(&[]) } else { Space::new() };
          drop(v299_3);
          let v299_5: Space = subtract(&(*CONSTANT_0),&(v299_4));
          drop(v299_4);
          let v299_7: Space = if (v299_5).is_empty() { Space::new() } else {
            let v300_6: Space = routine_73(c, &(v298_10_head), &(v292_104_head), &(v298_10_tail));
            compose(&(v299_5),&(v300_6))
          };
          drop(v299_5);
          let v299_8: Space = intersect(&(*CONSTANT_7),&(v299_2));
          drop(v299_2);
          let v299_9: Space = if has_head(&(v299_8)) { singleton(&[]) } else { Space::new() };
          drop(v299_8);
          let v299_11: Space = if (v299_9).is_empty() { Space::new() } else {
            let v301_10: Space = routine_74(c, &(v298_10_head), &(v292_104_head), &(v298_10_tail));
            compose(&(v299_9),&(v301_10))
          };
          drop(v299_9);
          let v299_12: Space = unite(&(v299_7),&(v299_11));
          v298_10.join_into((v299_12).clone());
        }
        drop(v298_10_cursor);
        compose(&(v293_9),&(v298_10))
      };
      drop(v293_9);
      let v293_12: Space = unite(&(v293_7),&(v293_11));
      v292_104.join_into((v293_12).clone());
    }
    drop(v292_104_cursor);
    compose(&((*capture_3)),&(v292_104))
  };
  let v226_106: Space = unite(&((*capture_2)),&(v226_105));
  let v226_108: Space = intersect(&(*CONSTANT_13),&((*capture_1)));
  let mut v226_115 = Space::new();
  let mut v226_115_cursor = (v226_108).read_zipper();
  for v226_115_byte in v226_115_cursor.child_mask().iter() {
    v226_115_cursor.descend_to_byte(v226_115_byte);
    let v226_115_tail = v226_115_cursor.make_map();
    v226_115_cursor.ascend(1);
    let v226_115_head = Path::from_slice(&[v226_115_byte]);
    let v302_2: Space = singleton(&(v226_115_head));
    let v302_3: Space = intersect(&(*CONSTANT_7),&(v302_2));
    let v302_4: Space = if has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
    drop(v302_3);
    let v302_5: Space = subtract(&(*CONSTANT_0),&(v302_4));
    drop(v302_4);
    let v302_7: Space = if (v302_5).is_empty() { Space::new() } else {
      let mut v303_6 = Space::new();
      let mut v303_6_cursor = (v226_115_tail).read_zipper();
      for v303_6_byte in v303_6_cursor.child_mask().iter() {
        v303_6_cursor.descend_to_byte(v303_6_byte);
        let v303_6_tail = v303_6_cursor.make_map();
        v303_6_cursor.ascend(1);
        let v303_6_head = Path::from_slice(&[v303_6_byte]);
        let v304_2: Space = singleton(&(v303_6_head));
        let v304_3: Space = intersect(&(*CONSTANT_7),&(v304_2));
        let v304_4: Space = if has_head(&(v304_3)) { singleton(&[]) } else { Space::new() };
        drop(v304_3);
        let v304_5: Space = subtract(&(*CONSTANT_0),&(v304_4));
        drop(v304_4);
        let v304_8: Space = if (v304_5).is_empty() { Space::new() } else {
          let v305_6: Path = concat_path(&(v226_115_head),&(v303_6_head));
          let v305_7: Space = routine_43(c, &(v305_6), &(v303_6_tail));
          compose(&(v304_5),&(v305_7))
        };
        drop(v304_5);
        let v304_9: Space = intersect(&(*CONSTANT_7),&(v304_2));
        drop(v304_2);
        let v304_10: Space = if has_head(&(v304_9)) { singleton(&[]) } else { Space::new() };
        drop(v304_9);
        let v304_12: Space = if (v304_10).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v226_115_head),&(v303_6_head));
          let v306_11: Space = routine_44(c, &(v306_6), &(v303_6_tail));
          drop(v306_6);
          compose(&(v304_10),&(v306_11))
        };
        drop(v304_10);
        let v304_13: Space = unite(&(v304_8),&(v304_12));
        v303_6.join_into((v304_13).clone());
      }
      drop(v303_6_cursor);
      compose(&(v302_5),&(v303_6))
    };
    drop(v302_5);
    let v302_8: Space = intersect(&(*CONSTANT_7),&(v302_2));
    drop(v302_2);
    let v302_9: Space = if has_head(&(v302_8)) { singleton(&[]) } else { Space::new() };
    drop(v302_8);
    let v302_10: Space = compose(&(v302_9),&(v226_115_tail));
    drop(v302_9);
    let v302_11: Space = unite(&(v302_7),&(v302_10));
    drop(v302_10);
    v226_115.join_into((v302_11).clone());
  }
  drop(v226_115_cursor);
  drop(v226_108);
  let v226_126: Space = if (v226_115).is_empty() { Space::new() } else {
    let mut v307_125 = Space::new();
    let mut v307_125_cursor = (*capture_0).read_zipper();
    for v307_125_byte in v307_125_cursor.child_mask().iter() {
      v307_125_cursor.descend_to_byte(v307_125_byte);
      let v307_125_tail = v307_125_cursor.make_map();
      v307_125_cursor.ascend(1);
      let v307_125_head = Path::from_slice(&[v307_125_byte]);
      let v308_2: Space = singleton(&(v307_125_head));
      let v308_3: Space = intersect(&(*CONSTANT_7),&(v308_2));
      let v308_4: Space = if has_head(&(v308_3)) { singleton(&[]) } else { Space::new() };
      drop(v308_3);
      let v308_5: Space = subtract(&(*CONSTANT_0),&(v308_4));
      drop(v308_4);
      let v308_7: Space = if (v308_5).is_empty() { Space::new() } else {
        let mut v309_6 = Space::new();
        let mut v309_6_cursor = (v307_125_tail).read_zipper();
        for v309_6_byte in v309_6_cursor.child_mask().iter() {
          v309_6_cursor.descend_to_byte(v309_6_byte);
          let v309_6_tail = v309_6_cursor.make_map();
          v309_6_cursor.ascend(1);
          let v309_6_head = Path::from_slice(&[v309_6_byte]);
          let v310_2: Space = singleton(&(v309_6_head));
          let v310_3: Space = intersect(&(*CONSTANT_7),&(v310_2));
          let v310_4: Space = if has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
          drop(v310_3);
          let v310_5: Space = subtract(&(*CONSTANT_0),&(v310_4));
          drop(v310_4);
          let v310_8: Space = if (v310_5).is_empty() { Space::new() } else {
            let v311_6: Path = concat_path(&(v307_125_head),&(v309_6_head));
            let v311_7: Space = routine_45(c, &(v311_6), &(v309_6_tail));
            compose(&(v310_5),&(v311_7))
          };
          drop(v310_5);
          let v310_9: Space = intersect(&(*CONSTANT_7),&(v310_2));
          drop(v310_2);
          let v310_10: Space = if has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
          drop(v310_9);
          let v310_12: Space = if (v310_10).is_empty() { Space::new() } else {
            let v312_6: Path = concat_path(&(v307_125_head),&(v309_6_head));
            let v312_11: Space = routine_46(c, &(v312_6), &(v309_6_tail));
            drop(v312_6);
            compose(&(v310_10),&(v312_11))
          };
          drop(v310_10);
          let v310_13: Space = unite(&(v310_8),&(v310_12));
          v309_6.join_into((v310_13).clone());
        }
        drop(v309_6_cursor);
        compose(&(v308_5),&(v309_6))
      };
      drop(v308_5);
      let v308_8: Space = intersect(&(*CONSTANT_7),&(v308_2));
      drop(v308_2);
      let v308_9: Space = if has_head(&(v308_8)) { singleton(&[]) } else { Space::new() };
      drop(v308_8);
      let v308_11: Space = if (v308_9).is_empty() { Space::new() } else {
        let mut v313_10 = Space::new();
        let mut v313_10_cursor = (v307_125_tail).read_zipper();
        for v313_10_byte in v313_10_cursor.child_mask().iter() {
          v313_10_cursor.descend_to_byte(v313_10_byte);
          let v313_10_tail = v313_10_cursor.make_map();
          v313_10_cursor.ascend(1);
          let v313_10_head = Path::from_slice(&[v313_10_byte]);
          let v314_2: Space = singleton(&(v313_10_head));
          let v314_3: Space = intersect(&(*CONSTANT_7),&(v314_2));
          let v314_4: Space = if has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
          drop(v314_3);
          let v314_5: Space = subtract(&(*CONSTANT_0),&(v314_4));
          drop(v314_4);
          let v314_7: Space = if (v314_5).is_empty() { Space::new() } else {
            let v315_6: Space = routine_75(c, &(v313_10_head), &(v307_125_head), &(v313_10_tail));
            compose(&(v314_5),&(v315_6))
          };
          drop(v314_5);
          let v314_8: Space = intersect(&(*CONSTANT_7),&(v314_2));
          drop(v314_2);
          let v314_9: Space = if has_head(&(v314_8)) { singleton(&[]) } else { Space::new() };
          drop(v314_8);
          let v314_11: Space = if (v314_9).is_empty() { Space::new() } else {
            let v316_10: Space = routine_76(c, &(v313_10_head), &(v307_125_head), &(v313_10_tail));
            compose(&(v314_9),&(v316_10))
          };
          drop(v314_9);
          let v314_12: Space = unite(&(v314_7),&(v314_11));
          v313_10.join_into((v314_12).clone());
        }
        drop(v313_10_cursor);
        compose(&(v308_9),&(v313_10))
      };
      drop(v308_9);
      let v308_12: Space = unite(&(v308_7),&(v308_11));
      v307_125.join_into((v308_12).clone());
    }
    drop(v307_125_cursor);
    compose(&(v226_115),&(v307_125))
  };
  let v226_127: Space = unite(&(v226_106),&(v226_126));
  let v226_129: Space = intersect(&(*CONSTANT_14),&((*capture_1)));
  let mut v226_136 = Space::new();
  let mut v226_136_cursor = (v226_129).read_zipper();
  for v226_136_byte in v226_136_cursor.child_mask().iter() {
    v226_136_cursor.descend_to_byte(v226_136_byte);
    let v226_136_tail = v226_136_cursor.make_map();
    v226_136_cursor.ascend(1);
    let v226_136_head = Path::from_slice(&[v226_136_byte]);
    let v317_2: Space = singleton(&(v226_136_head));
    let v317_3: Space = intersect(&(*CONSTANT_7),&(v317_2));
    let v317_4: Space = if has_head(&(v317_3)) { singleton(&[]) } else { Space::new() };
    drop(v317_3);
    let v317_5: Space = subtract(&(*CONSTANT_0),&(v317_4));
    drop(v317_4);
    let v317_7: Space = if (v317_5).is_empty() { Space::new() } else {
      let mut v318_6 = Space::new();
      let mut v318_6_cursor = (v226_136_tail).read_zipper();
      for v318_6_byte in v318_6_cursor.child_mask().iter() {
        v318_6_cursor.descend_to_byte(v318_6_byte);
        let v318_6_tail = v318_6_cursor.make_map();
        v318_6_cursor.ascend(1);
        let v318_6_head = Path::from_slice(&[v318_6_byte]);
        let v319_2: Space = singleton(&(v318_6_head));
        let v319_3: Space = intersect(&(*CONSTANT_7),&(v319_2));
        let v319_4: Space = if has_head(&(v319_3)) { singleton(&[]) } else { Space::new() };
        drop(v319_3);
        let v319_5: Space = subtract(&(*CONSTANT_0),&(v319_4));
        drop(v319_4);
        let v319_8: Space = if (v319_5).is_empty() { Space::new() } else {
          let v320_6: Path = concat_path(&(v226_136_head),&(v318_6_head));
          let v320_7: Space = routine_47(c, &(v320_6), &(v318_6_tail));
          compose(&(v319_5),&(v320_7))
        };
        drop(v319_5);
        let v319_9: Space = intersect(&(*CONSTANT_7),&(v319_2));
        drop(v319_2);
        let v319_10: Space = if has_head(&(v319_9)) { singleton(&[]) } else { Space::new() };
        drop(v319_9);
        let v319_12: Space = if (v319_10).is_empty() { Space::new() } else {
          let v321_6: Path = concat_path(&(v226_136_head),&(v318_6_head));
          let v321_11: Space = routine_48(c, &(v321_6), &(v318_6_tail));
          drop(v321_6);
          compose(&(v319_10),&(v321_11))
        };
        drop(v319_10);
        let v319_13: Space = unite(&(v319_8),&(v319_12));
        v318_6.join_into((v319_13).clone());
      }
      drop(v318_6_cursor);
      compose(&(v317_5),&(v318_6))
    };
    drop(v317_5);
    let v317_8: Space = intersect(&(*CONSTANT_7),&(v317_2));
    drop(v317_2);
    let v317_9: Space = if has_head(&(v317_8)) { singleton(&[]) } else { Space::new() };
    drop(v317_8);
    let v317_10: Space = compose(&(v317_9),&(v226_136_tail));
    drop(v317_9);
    let v317_11: Space = unite(&(v317_7),&(v317_10));
    drop(v317_10);
    v226_136.join_into((v317_11).clone());
  }
  drop(v226_136_cursor);
  drop(v226_129);
  let v226_147: Space = if (v226_136).is_empty() { Space::new() } else {
    let mut v322_146 = Space::new();
    let mut v322_146_cursor = (*capture_0).read_zipper();
    for v322_146_byte in v322_146_cursor.child_mask().iter() {
      v322_146_cursor.descend_to_byte(v322_146_byte);
      let v322_146_tail = v322_146_cursor.make_map();
      v322_146_cursor.ascend(1);
      let v322_146_head = Path::from_slice(&[v322_146_byte]);
      let v323_2: Space = singleton(&(v322_146_head));
      let v323_3: Space = intersect(&(*CONSTANT_7),&(v323_2));
      let v323_4: Space = if has_head(&(v323_3)) { singleton(&[]) } else { Space::new() };
      drop(v323_3);
      let v323_5: Space = subtract(&(*CONSTANT_0),&(v323_4));
      drop(v323_4);
      let v323_7: Space = if (v323_5).is_empty() { Space::new() } else {
        let mut v324_6 = Space::new();
        let mut v324_6_cursor = (v322_146_tail).read_zipper();
        for v324_6_byte in v324_6_cursor.child_mask().iter() {
          v324_6_cursor.descend_to_byte(v324_6_byte);
          let v324_6_tail = v324_6_cursor.make_map();
          v324_6_cursor.ascend(1);
          let v324_6_head = Path::from_slice(&[v324_6_byte]);
          let v325_2: Space = singleton(&(v324_6_head));
          let v325_3: Space = intersect(&(*CONSTANT_7),&(v325_2));
          let v325_4: Space = if has_head(&(v325_3)) { singleton(&[]) } else { Space::new() };
          drop(v325_3);
          let v325_5: Space = subtract(&(*CONSTANT_0),&(v325_4));
          drop(v325_4);
          let v325_8: Space = if (v325_5).is_empty() { Space::new() } else {
            let v326_6: Path = concat_path(&(v322_146_head),&(v324_6_head));
            let v326_7: Space = routine_49(c, &(v326_6), &(v324_6_tail));
            compose(&(v325_5),&(v326_7))
          };
          drop(v325_5);
          let v325_9: Space = intersect(&(*CONSTANT_7),&(v325_2));
          drop(v325_2);
          let v325_10: Space = if has_head(&(v325_9)) { singleton(&[]) } else { Space::new() };
          drop(v325_9);
          let v325_12: Space = if (v325_10).is_empty() { Space::new() } else {
            let v327_6: Path = concat_path(&(v322_146_head),&(v324_6_head));
            let v327_11: Space = routine_50(c, &(v327_6), &(v324_6_tail));
            drop(v327_6);
            compose(&(v325_10),&(v327_11))
          };
          drop(v325_10);
          let v325_13: Space = unite(&(v325_8),&(v325_12));
          v324_6.join_into((v325_13).clone());
        }
        drop(v324_6_cursor);
        compose(&(v323_5),&(v324_6))
      };
      drop(v323_5);
      let v323_8: Space = intersect(&(*CONSTANT_7),&(v323_2));
      drop(v323_2);
      let v323_9: Space = if has_head(&(v323_8)) { singleton(&[]) } else { Space::new() };
      drop(v323_8);
      let v323_11: Space = if (v323_9).is_empty() { Space::new() } else {
        let mut v328_10 = Space::new();
        let mut v328_10_cursor = (v322_146_tail).read_zipper();
        for v328_10_byte in v328_10_cursor.child_mask().iter() {
          v328_10_cursor.descend_to_byte(v328_10_byte);
          let v328_10_tail = v328_10_cursor.make_map();
          v328_10_cursor.ascend(1);
          let v328_10_head = Path::from_slice(&[v328_10_byte]);
          let v329_2: Space = singleton(&(v328_10_head));
          let v329_3: Space = intersect(&(*CONSTANT_7),&(v329_2));
          let v329_4: Space = if has_head(&(v329_3)) { singleton(&[]) } else { Space::new() };
          drop(v329_3);
          let v329_5: Space = subtract(&(*CONSTANT_0),&(v329_4));
          drop(v329_4);
          let v329_7: Space = if (v329_5).is_empty() { Space::new() } else {
            let v330_6: Space = routine_77(c, &(v328_10_head), &(v322_146_head), &(v328_10_tail));
            compose(&(v329_5),&(v330_6))
          };
          drop(v329_5);
          let v329_8: Space = intersect(&(*CONSTANT_7),&(v329_2));
          drop(v329_2);
          let v329_9: Space = if has_head(&(v329_8)) { singleton(&[]) } else { Space::new() };
          drop(v329_8);
          let v329_11: Space = if (v329_9).is_empty() { Space::new() } else {
            let v331_10: Space = routine_78(c, &(v328_10_head), &(v322_146_head), &(v328_10_tail));
            compose(&(v329_9),&(v331_10))
          };
          drop(v329_9);
          let v329_12: Space = unite(&(v329_7),&(v329_11));
          v328_10.join_into((v329_12).clone());
        }
        drop(v328_10_cursor);
        compose(&(v323_9),&(v328_10))
      };
      drop(v323_9);
      let v323_12: Space = unite(&(v323_7),&(v323_11));
      v322_146.join_into((v323_12).clone());
    }
    drop(v322_146_cursor);
    compose(&(v226_136),&(v322_146))
  };
  let v226_148: Space = unite(&(v226_127),&(v226_147));
  let v226_150: Space = intersect(&(*CONSTANT_15),&((*capture_1)));
  let mut v226_157 = Space::new();
  let mut v226_157_cursor = (v226_150).read_zipper();
  for v226_157_byte in v226_157_cursor.child_mask().iter() {
    v226_157_cursor.descend_to_byte(v226_157_byte);
    let v226_157_tail = v226_157_cursor.make_map();
    v226_157_cursor.ascend(1);
    let v226_157_head = Path::from_slice(&[v226_157_byte]);
    let v332_2: Space = singleton(&(v226_157_head));
    let v332_3: Space = intersect(&(*CONSTANT_7),&(v332_2));
    let v332_4: Space = if has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
    drop(v332_3);
    let v332_5: Space = subtract(&(*CONSTANT_0),&(v332_4));
    drop(v332_4);
    let v332_7: Space = if (v332_5).is_empty() { Space::new() } else {
      let mut v333_6 = Space::new();
      let mut v333_6_cursor = (v226_157_tail).read_zipper();
      for v333_6_byte in v333_6_cursor.child_mask().iter() {
        v333_6_cursor.descend_to_byte(v333_6_byte);
        let v333_6_tail = v333_6_cursor.make_map();
        v333_6_cursor.ascend(1);
        let v333_6_head = Path::from_slice(&[v333_6_byte]);
        let v334_2: Space = singleton(&(v333_6_head));
        let v334_3: Space = intersect(&(*CONSTANT_7),&(v334_2));
        let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
        drop(v334_3);
        let v334_5: Space = subtract(&(*CONSTANT_0),&(v334_4));
        drop(v334_4);
        let v334_8: Space = if (v334_5).is_empty() { Space::new() } else {
          let v335_6: Path = concat_path(&(v226_157_head),&(v333_6_head));
          let v335_7: Space = routine_51(c, &(v335_6), &(v333_6_tail));
          compose(&(v334_5),&(v335_7))
        };
        drop(v334_5);
        let v334_9: Space = intersect(&(*CONSTANT_7),&(v334_2));
        drop(v334_2);
        let v334_10: Space = if has_head(&(v334_9)) { singleton(&[]) } else { Space::new() };
        drop(v334_9);
        let v334_12: Space = if (v334_10).is_empty() { Space::new() } else {
          let v336_6: Path = concat_path(&(v226_157_head),&(v333_6_head));
          let v336_11: Space = routine_52(c, &(v336_6), &(v333_6_tail));
          drop(v336_6);
          compose(&(v334_10),&(v336_11))
        };
        drop(v334_10);
        let v334_13: Space = unite(&(v334_8),&(v334_12));
        v333_6.join_into((v334_13).clone());
      }
      drop(v333_6_cursor);
      compose(&(v332_5),&(v333_6))
    };
    drop(v332_5);
    let v332_8: Space = intersect(&(*CONSTANT_7),&(v332_2));
    drop(v332_2);
    let v332_9: Space = if has_head(&(v332_8)) { singleton(&[]) } else { Space::new() };
    drop(v332_8);
    let v332_10: Space = compose(&(v332_9),&(v226_157_tail));
    drop(v332_9);
    let v332_11: Space = unite(&(v332_7),&(v332_10));
    drop(v332_10);
    v226_157.join_into((v332_11).clone());
  }
  drop(v226_157_cursor);
  drop(v226_150);
  let v226_168: Space = if (v226_157).is_empty() { Space::new() } else {
    let mut v337_167 = Space::new();
    let mut v337_167_cursor = (*capture_0).read_zipper();
    for v337_167_byte in v337_167_cursor.child_mask().iter() {
      v337_167_cursor.descend_to_byte(v337_167_byte);
      let v337_167_tail = v337_167_cursor.make_map();
      v337_167_cursor.ascend(1);
      let v337_167_head = Path::from_slice(&[v337_167_byte]);
      let v338_2: Space = singleton(&(v337_167_head));
      let v338_3: Space = intersect(&(*CONSTANT_7),&(v338_2));
      let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
      drop(v338_3);
      let v338_5: Space = subtract(&(*CONSTANT_0),&(v338_4));
      drop(v338_4);
      let v338_7: Space = if (v338_5).is_empty() { Space::new() } else {
        let mut v339_6 = Space::new();
        let mut v339_6_cursor = (v337_167_tail).read_zipper();
        for v339_6_byte in v339_6_cursor.child_mask().iter() {
          v339_6_cursor.descend_to_byte(v339_6_byte);
          let v339_6_tail = v339_6_cursor.make_map();
          v339_6_cursor.ascend(1);
          let v339_6_head = Path::from_slice(&[v339_6_byte]);
          let v340_2: Space = singleton(&(v339_6_head));
          let v340_3: Space = intersect(&(*CONSTANT_7),&(v340_2));
          let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
          drop(v340_3);
          let v340_5: Space = subtract(&(*CONSTANT_0),&(v340_4));
          drop(v340_4);
          let v340_8: Space = if (v340_5).is_empty() { Space::new() } else {
            let v341_6: Path = concat_path(&(v337_167_head),&(v339_6_head));
            let v341_7: Space = routine_53(c, &(v341_6), &(v339_6_tail));
            compose(&(v340_5),&(v341_7))
          };
          drop(v340_5);
          let v340_9: Space = intersect(&(*CONSTANT_7),&(v340_2));
          drop(v340_2);
          let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
          drop(v340_9);
          let v340_12: Space = if (v340_10).is_empty() { Space::new() } else {
            let v342_6: Path = concat_path(&(v337_167_head),&(v339_6_head));
            let v342_11: Space = routine_54(c, &(v342_6), &(v339_6_tail));
            drop(v342_6);
            compose(&(v340_10),&(v342_11))
          };
          drop(v340_10);
          let v340_13: Space = unite(&(v340_8),&(v340_12));
          v339_6.join_into((v340_13).clone());
        }
        drop(v339_6_cursor);
        compose(&(v338_5),&(v339_6))
      };
      drop(v338_5);
      let v338_8: Space = intersect(&(*CONSTANT_7),&(v338_2));
      drop(v338_2);
      let v338_9: Space = if has_head(&(v338_8)) { singleton(&[]) } else { Space::new() };
      drop(v338_8);
      let v338_11: Space = if (v338_9).is_empty() { Space::new() } else {
        let mut v343_10 = Space::new();
        let mut v343_10_cursor = (v337_167_tail).read_zipper();
        for v343_10_byte in v343_10_cursor.child_mask().iter() {
          v343_10_cursor.descend_to_byte(v343_10_byte);
          let v343_10_tail = v343_10_cursor.make_map();
          v343_10_cursor.ascend(1);
          let v343_10_head = Path::from_slice(&[v343_10_byte]);
          let v344_2: Space = singleton(&(v343_10_head));
          let v344_3: Space = intersect(&(*CONSTANT_7),&(v344_2));
          let v344_4: Space = if has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
          drop(v344_3);
          let v344_5: Space = subtract(&(*CONSTANT_0),&(v344_4));
          drop(v344_4);
          let v344_7: Space = if (v344_5).is_empty() { Space::new() } else {
            let v345_6: Space = routine_79(c, &(v343_10_head), &(v337_167_head), &(v343_10_tail));
            compose(&(v344_5),&(v345_6))
          };
          drop(v344_5);
          let v344_8: Space = intersect(&(*CONSTANT_7),&(v344_2));
          drop(v344_2);
          let v344_9: Space = if has_head(&(v344_8)) { singleton(&[]) } else { Space::new() };
          drop(v344_8);
          let v344_11: Space = if (v344_9).is_empty() { Space::new() } else {
            let v346_10: Space = routine_80(c, &(v343_10_head), &(v337_167_head), &(v343_10_tail));
            compose(&(v344_9),&(v346_10))
          };
          drop(v344_9);
          let v344_12: Space = unite(&(v344_7),&(v344_11));
          v343_10.join_into((v344_12).clone());
        }
        drop(v343_10_cursor);
        compose(&(v338_9),&(v343_10))
      };
      drop(v338_9);
      let v338_12: Space = unite(&(v338_7),&(v338_11));
      v337_167.join_into((v338_12).clone());
    }
    drop(v337_167_cursor);
    compose(&(v226_157),&(v337_167))
  };
  let v226_169: Space = unite(&(v226_148),&(v226_168));
  let v226_171: Space = intersect(&(*CONSTANT_16),&((*capture_1)));

  let mut v226_178 = Space::new();
  let mut v226_178_cursor = (v226_171).read_zipper();
  for v226_178_byte in v226_178_cursor.child_mask().iter() {
    v226_178_cursor.descend_to_byte(v226_178_byte);
    let v226_178_tail = v226_178_cursor.make_map();
    v226_178_cursor.ascend(1);
    let v226_178_head = Path::from_slice(&[v226_178_byte]);
    let v347_2: Space = singleton(&(v226_178_head));
    let v347_3: Space = intersect(&(*CONSTANT_7),&(v347_2));
    let v347_4: Space = if has_head(&(v347_3)) { singleton(&[]) } else { Space::new() };
    drop(v347_3);
    let v347_5: Space = subtract(&(*CONSTANT_0),&(v347_4));
    drop(v347_4);
    let v347_7: Space = if (v347_5).is_empty() { Space::new() } else {
      let mut v348_6 = Space::new();
      let mut v348_6_cursor = (v226_178_tail).read_zipper();
      for v348_6_byte in v348_6_cursor.child_mask().iter() {
        v348_6_cursor.descend_to_byte(v348_6_byte);
        let v348_6_tail = v348_6_cursor.make_map();
        v348_6_cursor.ascend(1);
        let v348_6_head = Path::from_slice(&[v348_6_byte]);
        let v349_2: Space = singleton(&(v348_6_head));
        let v349_3: Space = intersect(&(*CONSTANT_7),&(v349_2));
        let v349_4: Space = if has_head(&(v349_3)) { singleton(&[]) } else { Space::new() };
        drop(v349_3);
        let v349_5: Space = subtract(&(*CONSTANT_0),&(v349_4));
        drop(v349_4);
        let v349_8: Space = if (v349_5).is_empty() { Space::new() } else {
          let v350_6: Path = concat_path(&(v226_178_head),&(v348_6_head));
          let v350_7: Space = routine_55(c, &(v350_6), &(v348_6_tail));
          compose(&(v349_5),&(v350_7))
        };
        drop(v349_5);
        let v349_9: Space = intersect(&(*CONSTANT_7),&(v349_2));
        drop(v349_2);
        let v349_10: Space = if has_head(&(v349_9)) { singleton(&[]) } else { Space::new() };
        drop(v349_9);
        let v349_12: Space = if (v349_10).is_empty() { Space::new() } else {
          let v351_6: Path = concat_path(&(v226_178_head),&(v348_6_head));
          let v351_11: Space = routine_56(c, &(v351_6), &(v348_6_tail));
          drop(v351_6);
          compose(&(v349_10),&(v351_11))
        };
        drop(v349_10);
        let v349_13: Space = unite(&(v349_8),&(v349_12));
        v348_6.join_into((v349_13).clone());
      }
      drop(v348_6_cursor);
      compose(&(v347_5),&(v348_6))
    };
    drop(v347_5);
    let v347_8: Space = intersect(&(*CONSTANT_7),&(v347_2));
    drop(v347_2);
    let v347_9: Space = if has_head(&(v347_8)) { singleton(&[]) } else { Space::new() };
    drop(v347_8);
    let v347_10: Space = compose(&(v347_9),&(v226_178_tail));
    drop(v347_9);
    let v347_11: Space = unite(&(v347_7),&(v347_10));
    drop(v347_10);
    v226_178.join_into((v347_11).clone());
  }
  drop(v226_178_cursor);
  drop(v226_171);
  let v226_189: Space = if (v226_178).is_empty() { Space::new() } else {
    let mut v352_188 = Space::new();
    let mut v352_188_cursor = (*capture_0).read_zipper();
    for v352_188_byte in v352_188_cursor.child_mask().iter() {
      v352_188_cursor.descend_to_byte(v352_188_byte);
      let v352_188_tail = v352_188_cursor.make_map();
      v352_188_cursor.ascend(1);
      let v352_188_head = Path::from_slice(&[v352_188_byte]);
      let v353_2: Space = singleton(&(v352_188_head));
      let v353_3: Space = intersect(&(*CONSTANT_7),&(v353_2));
      let v353_4: Space = if has_head(&(v353_3)) { singleton(&[]) } else { Space::new() };
      drop(v353_3);
      let v353_5: Space = subtract(&(*CONSTANT_0),&(v353_4));
      drop(v353_4);
      let v353_7: Space = if (v353_5).is_empty() { Space::new() } else {
        let mut v354_6 = Space::new();
        let mut v354_6_cursor = (v352_188_tail).read_zipper();
        for v354_6_byte in v354_6_cursor.child_mask().iter() {
          v354_6_cursor.descend_to_byte(v354_6_byte);
          let v354_6_tail = v354_6_cursor.make_map();
          v354_6_cursor.ascend(1);
          let v354_6_head = Path::from_slice(&[v354_6_byte]);
          let v355_2: Space = singleton(&(v354_6_head));
          let v355_3: Space = intersect(&(*CONSTANT_7),&(v355_2));
          let v355_4: Space = if has_head(&(v355_3)) { singleton(&[]) } else { Space::new() };
          drop(v355_3);
          let v355_5: Space = subtract(&(*CONSTANT_0),&(v355_4));
          drop(v355_4);
          let v355_8: Space = if (v355_5).is_empty() { Space::new() } else {
            let v356_6: Path = concat_path(&(v352_188_head),&(v354_6_head));
            let v356_7: Space = routine_57(c, &(v356_6), &(v354_6_tail));
            compose(&(v355_5),&(v356_7))
          };
          drop(v355_5);
          let v355_9: Space = intersect(&(*CONSTANT_7),&(v355_2));
          drop(v355_2);
          let v355_10: Space = if has_head(&(v355_9)) { singleton(&[]) } else { Space::new() };
          drop(v355_9);
          let v355_12: Space = if (v355_10).is_empty() { Space::new() } else {
            let v357_6: Path = concat_path(&(v352_188_head),&(v354_6_head));
            let v357_11: Space = routine_58(c, &(v357_6), &(v354_6_tail));
            drop(v357_6);
            compose(&(v355_10),&(v357_11))
          };
          drop(v355_10);
          let v355_13: Space = unite(&(v355_8),&(v355_12));
          v354_6.join_into((v355_13).clone());
        }
        drop(v354_6_cursor);
        compose(&(v353_5),&(v354_6))
      };
      drop(v353_5);
      let v353_8: Space = intersect(&(*CONSTANT_7),&(v353_2));
      drop(v353_2);
      let v353_9: Space = if has_head(&(v353_8)) { singleton(&[]) } else { Space::new() };
      drop(v353_8);
      let v353_11: Space = if (v353_9).is_empty() { Space::new() } else {
        let mut v358_10 = Space::new();
        let mut v358_10_cursor = (v352_188_tail).read_zipper();
        for v358_10_byte in v358_10_cursor.child_mask().iter() {
          v358_10_cursor.descend_to_byte(v358_10_byte);
          let v358_10_tail = v358_10_cursor.make_map();
          v358_10_cursor.ascend(1);
          let v358_10_head = Path::from_slice(&[v358_10_byte]);
          let v359_2: Space = singleton(&(v358_10_head));
          let v359_3: Space = intersect(&(*CONSTANT_7),&(v359_2));
          let v359_4: Space = if has_head(&(v359_3)) { singleton(&[]) } else { Space::new() };
          drop(v359_3);
          let v359_5: Space = subtract(&(*CONSTANT_0),&(v359_4));
          drop(v359_4);
          let v359_7: Space = if (v359_5).is_empty() { Space::new() } else {
            let v360_6: Space = routine_81(c, &(v358_10_head), &(v352_188_head), &(v358_10_tail));
            compose(&(v359_5),&(v360_6))
          };
          drop(v359_5);
          let v359_8: Space = intersect(&(*CONSTANT_7),&(v359_2));
          drop(v359_2);
          let v359_9: Space = if has_head(&(v359_8)) { singleton(&[]) } else { Space::new() };
          drop(v359_8);
          let v359_11: Space = if (v359_9).is_empty() { Space::new() } else {
            let v361_10: Space = routine_82(c, &(v358_10_head), &(v352_188_head), &(v358_10_tail));
            compose(&(v359_9),&(v361_10))
          };
          drop(v359_9);
          let v359_12: Space = unite(&(v359_7),&(v359_11));
          v358_10.join_into((v359_12).clone());
        }
        drop(v358_10_cursor);
        compose(&(v353_9),&(v358_10))
      };
      drop(v353_9);
      let v353_12: Space = unite(&(v353_7),&(v353_11));
      v352_188.join_into((v353_12).clone());
    }
    drop(v352_188_cursor);
    compose(&(v226_178),&(v352_188))
  };

((v226_105).clone(),(v226_106).clone(),(v226_115).clone(),(v226_126).clone(),(v226_127).clone(),(v226_136).clone(),(v226_147).clone(),(v226_148).clone(),(v226_157).clone(),(v226_168).clone(),(v226_169).clone(),(v226_178).clone(),(v226_189).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_14: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v1_13: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v2_4: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
      let v2_7: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4));
      let v2_8: Space = unite(&(v2_4),&(v2_7));
      let v2_11: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_6));
      let v2_12: Space = unite(&(v2_8),&(v2_11));
      compose(&(*CONSTANT_0),&(v2_12))
    };
    compose(&(*CONSTANT_0),&(v1_13))
  };
  (v0_14).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v3_8 = Space::new();
  let mut v3_8_cursor = (*s0).read_zipper();
  for v3_8_byte in v3_8_cursor.child_mask().iter() {
    v3_8_cursor.descend_to_byte(v3_8_byte);
    let v3_8_tail = v3_8_cursor.make_map();
    v3_8_cursor.ascend(1);
    let v3_8_head = Path::from_slice(&[v3_8_byte]);
    let v4_2: Space = singleton(&(v3_8_head));
    let v4_3: Space = intersect(&(*CONSTANT_7),&(v4_2));
    let v4_4: Space = if has_head(&(v4_3)) { singleton(&[]) } else { Space::new() };
    drop(v4_3);
    let v4_5: Space = subtract(&(*CONSTANT_0),&(v4_4));
    drop(v4_4);
    let v4_8: Space = if (v4_5).is_empty() { Space::new() } else {
      let v5_6: Path = concat_path(&(*p0),&(v3_8_head));
      let v5_7: Space = routine_1(c, &(v5_6), &(v3_8_tail));
      compose(&(v4_5),&(v5_7))
    };
    drop(v4_5);
    let v4_9: Space = intersect(&(*CONSTANT_7),&(v4_2));
    drop(v4_2);
    let v4_10: Space = if has_head(&(v4_9)) { singleton(&[]) } else { Space::new() };
    drop(v4_9);
    let v4_12: Space = if (v4_10).is_empty() { Space::new() } else {
      let v6_6: Path = concat_path(&(*p0),&(v3_8_head));
      let mut v6_11 = Space::new();
      let mut v6_11_cursor = (v3_8_tail).read_zipper();
      for v6_11_byte in v6_11_cursor.child_mask().iter() {
        v6_11_cursor.descend_to_byte(v6_11_byte);
        let v6_11_tail = v6_11_cursor.make_map();
        v6_11_cursor.ascend(1);
        let v6_11_head = Path::from_slice(&[v6_11_byte]);
        let v7_2: Space = singleton(&(v6_11_head));
        let v7_3: Space = intersect(&(*CONSTANT_7),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_7: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Space = routine_2(c, &(v6_11_head), &(v6_6), &(v6_11_tail));
          compose(&(v7_5),&(v8_6))
        };
        drop(v7_5);
        let v7_8: Space = intersect(&(*CONSTANT_7),&(v7_2));
        drop(v7_2);
        let v7_9: Space = if has_head(&(v7_8)) { singleton(&[]) } else { Space::new() };
        drop(v7_8);
        let v7_11: Space = if (v7_9).is_empty() { Space::new() } else {
          let v9_10: Space = routine_3(c, &(v6_11_head), &(v6_6), &(v6_11_tail));
          compose(&(v7_9),&(v9_10))
        };
        drop(v7_9);
        let v7_12: Space = unite(&(v7_7),&(v7_11));
        v6_11.join_into((v7_12).clone());
      }
      drop(v6_11_cursor);
      drop(v6_6);
      compose(&(v4_10),&(v6_11))
    };
    drop(v4_10);
    let v4_13: Space = unite(&(v4_8),&(v4_12));
    v3_8.join_into((v4_13).clone());
  }
  drop(v3_8_cursor);
  (v3_8).clone()
}

fn routine_2(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v10_9 = Space::new();
  let mut v10_9_cursor = (*s0).read_zipper();
  for v10_9_byte in v10_9_cursor.child_mask().iter() {
    v10_9_cursor.descend_to_byte(v10_9_byte);
    let v10_9_tail = v10_9_cursor.make_map();
    v10_9_cursor.ascend(1);
    let v10_9_head = Path::from_slice(&[v10_9_byte]);
    let v11_2: Space = singleton(&(v10_9_head));
    let v11_3: Space = intersect(&(*CONSTANT_7),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&(v10_9_head));
      let v12_7: Space = routine_2(c, &(v12_6), &(*p1), &(v10_9_tail));
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_7),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_12: Space = if (v11_10).is_empty() { Space::new() } else {
      let v13_6: Path = concat_path(&(*p0),&(v10_9_head));
      let mut v13_11 = Space::new();
      let mut v13_11_cursor = (v10_9_tail).read_zipper();
      for v13_11_byte in v13_11_cursor.child_mask().iter() {
        v13_11_cursor.descend_to_byte(v13_11_byte);
        let v13_11_tail = v13_11_cursor.make_map();
        v13_11_cursor.ascend(1);
        let v13_11_head = Path::from_slice(&[v13_11_byte]);
        let v14_2: Space = singleton(&(v13_11_head));
        let v14_3: Space = intersect(&(*CONSTANT_7),&(v14_2));
        let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
        drop(v14_3);
        let v14_5: Space = subtract(&(*CONSTANT_0),&(v14_4));
        drop(v14_4);
        let v14_7: Space = if (v14_5).is_empty() { Space::new() } else {
          let v15_6: Space = routine_4(c, &(v13_11_head), &(*p1), &(v13_6), &(v13_11_tail));
          compose(&(v14_5),&(v15_6))
        };
        drop(v14_5);
        let v14_8: Space = intersect(&(*CONSTANT_7),&(v14_2));
        drop(v14_2);
        let v14_9: Space = if has_head(&(v14_8)) { singleton(&[]) } else { Space::new() };
        drop(v14_8);
        let v14_11: Space = if (v14_9).is_empty() { Space::new() } else {
          let v16_10: Space = routine_5(c, &(v13_11_head), &(*p1), &(v13_6), &(v13_11_tail));
          compose(&(v14_9),&(v16_10))
        };
        drop(v14_9);
        let v14_12: Space = unite(&(v14_7),&(v14_11));
        v13_11.join_into((v14_12).clone());
      }
      drop(v13_11_cursor);
      drop(v13_6);
      compose(&(v11_10),&(v13_11))
    };
    drop(v11_10);
    let v11_13: Space = unite(&(v11_8),&(v11_12));
    v10_9.join_into((v11_13).clone());
  }
  drop(v10_9_cursor);
  (v10_9).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v17_12 = Space::new();
  let mut v17_12_cursor = (*s0).read_zipper();
  for v17_12_byte in v17_12_cursor.child_mask().iter() {
    v17_12_cursor.descend_to_byte(v17_12_byte);
    let v17_12_tail = v17_12_cursor.make_map();
    v17_12_cursor.ascend(1);
    let v17_12_head = Path::from_slice(&[v17_12_byte]);
    let v18_2: Space = singleton(&(v17_12_head));
    let v18_3: Space = intersect(&(*CONSTANT_7),&(v18_2));
    let v18_4: Space = if has_head(&(v18_3)) { singleton(&[]) } else { Space::new() };
    drop(v18_3);
    let v18_5: Space = subtract(&(*CONSTANT_0),&(v18_4));
    drop(v18_4);
    let v18_7: Space = if (v18_5).is_empty() { Space::new() } else {
      let mut v19_6 = Space::new();
      let mut v19_6_cursor = (v17_12_tail).read_zipper();
      for v19_6_byte in v19_6_cursor.child_mask().iter() {
        v19_6_cursor.descend_to_byte(v19_6_byte);
        let v19_6_tail = v19_6_cursor.make_map();
        v19_6_cursor.ascend(1);
        let v19_6_head = Path::from_slice(&[v19_6_byte]);
        let v20_2: Space = singleton(&(v19_6_head));
        let v20_3: Space = intersect(&(*CONSTANT_7),&(v20_2));
        let v20_4: Space = if has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
        drop(v20_3);
        let v20_5: Space = subtract(&(*CONSTANT_0),&(v20_4));
        drop(v20_4);
        let v20_8: Space = if (v20_5).is_empty() { Space::new() } else {
          let v21_6: Path = concat_path(&(v17_12_head),&(v19_6_head));
          let v21_7: Space = routine_4(c, &(v21_6), &(*p1), &(*p0), &(v19_6_tail));
          compose(&(v20_5),&(v21_7))
        };
        drop(v20_5);
        let v20_9: Space = intersect(&(*CONSTANT_7),&(v20_2));
        drop(v20_2);
        let v20_10: Space = if has_head(&(v20_9)) { singleton(&[]) } else { Space::new() };
        drop(v20_9);
        let v20_12: Space = if (v20_10).is_empty() { Space::new() } else {
          let v22_6: Path = concat_path(&(v17_12_head),&(v19_6_head));
          let v22_11: Space = routine_5(c, &(v22_6), &(*p1), &(*p0), &(v19_6_tail));
          drop(v22_6);
          compose(&(v20_10),&(v22_11))
        };
        drop(v20_10);
        let v20_13: Space = unite(&(v20_8),&(v20_12));
        v19_6.join_into((v20_13).clone());
      }
      drop(v19_6_cursor);
      compose(&(v18_5),&(v19_6))
    };
    drop(v18_5);
    let v18_8: Space = intersect(&(*CONSTANT_7),&(v18_2));
    drop(v18_2);
    let v18_9: Space = if has_head(&(v18_8)) { singleton(&[]) } else { Space::new() };
    drop(v18_8);
    let v18_11: Space = if (v18_9).is_empty() { Space::new() } else {
      let mut v23_10 = Space::new();
      let mut v23_10_cursor = (v17_12_tail).read_zipper();
      for v23_10_byte in v23_10_cursor.child_mask().iter() {
        v23_10_cursor.descend_to_byte(v23_10_byte);
        let v23_10_tail = v23_10_cursor.make_map();
        v23_10_cursor.ascend(1);
        let v23_10_head = Path::from_slice(&[v23_10_byte]);
        let v24_2: Space = singleton(&(v23_10_head));
        let v24_3: Space = intersect(&(*CONSTANT_7),&(v24_2));
        let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
        drop(v24_3);
        let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
        drop(v24_4);
        let v24_7: Space = if (v24_5).is_empty() { Space::new() } else {
          let v25_6: Space = routine_6(c, &(v23_10_head), &(*p1), &(*p0), &(v17_12_head), &(v23_10_tail));
          compose(&(v24_5),&(v25_6))
        };
        drop(v24_5);
        let v24_8: Space = intersect(&(*CONSTANT_7),&(v24_2));
        drop(v24_2);
        let v24_9: Space = if has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
        drop(v24_8);
        let v24_11: Space = if (v24_9).is_empty() { Space::new() } else {
          let v26_10: Space = routine_7(c, &(v23_10_head), &(*p1), &(*p0), &(v17_12_head), &(v23_10_tail));
          compose(&(v24_9),&(v26_10))
        };
        drop(v24_9);
        let v24_12: Space = unite(&(v24_7),&(v24_11));
        v23_10.join_into((v24_12).clone());
      }
      drop(v23_10_cursor);
      compose(&(v18_9),&(v23_10))
    };
    drop(v18_9);
    let v18_12: Space = unite(&(v18_7),&(v18_11));
    v17_12.join_into((v18_12).clone());
  }
  drop(v17_12_cursor);
  (v17_12).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v27_10 = Space::new();
  let mut v27_10_cursor = (*s0).read_zipper();
  for v27_10_byte in v27_10_cursor.child_mask().iter() {
    v27_10_cursor.descend_to_byte(v27_10_byte);
    let v27_10_tail = v27_10_cursor.make_map();
    v27_10_cursor.ascend(1);
    let v27_10_head = Path::from_slice(&[v27_10_byte]);
    let v28_2: Space = singleton(&(v27_10_head));
    let v28_3: Space = intersect(&(*CONSTANT_7),&(v28_2));
    let v28_4: Space = if has_head(&(v28_3)) { singleton(&[]) } else { Space::new() };
    drop(v28_3);
    let v28_5: Space = subtract(&(*CONSTANT_0),&(v28_4));
    drop(v28_4);
    let v28_8: Space = if (v28_5).is_empty() { Space::new() } else {
      let v29_6: Path = concat_path(&(*p0),&(v27_10_head));
      let v29_7: Space = routine_4(c, &(v29_6), &(*p1), &(*p2), &(v27_10_tail));
      compose(&(v28_5),&(v29_7))
    };
    drop(v28_5);
    let v28_9: Space = intersect(&(*CONSTANT_7),&(v28_2));
    drop(v28_2);
    let v28_10: Space = if has_head(&(v28_9)) { singleton(&[]) } else { Space::new() };
    drop(v28_9);
    let v28_12: Space = if (v28_10).is_empty() { Space::new() } else {
      let v30_6: Path = concat_path(&(*p0),&(v27_10_head));
      let mut v30_11 = Space::new();
      let mut v30_11_cursor = (v27_10_tail).read_zipper();
      for v30_11_byte in v30_11_cursor.child_mask().iter() {
        v30_11_cursor.descend_to_byte(v30_11_byte);
        let v30_11_tail = v30_11_cursor.make_map();
        v30_11_cursor.ascend(1);
        let v30_11_head = Path::from_slice(&[v30_11_byte]);
        let v31_2: Space = singleton(&(v30_11_head));
        let v31_3: Space = intersect(&(*CONSTANT_7),&(v31_2));
        let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
        drop(v31_3);
        let v31_5: Space = subtract(&(*CONSTANT_0),&(v31_4));
        drop(v31_4);
        let v31_7: Space = if (v31_5).is_empty() { Space::new() } else {
          let v32_6: Space = routine_6(c, &(v30_11_head), &(*p1), &(*p2), &(v30_6), &(v30_11_tail));
          compose(&(v31_5),&(v32_6))
        };
        drop(v31_5);
        let v31_8: Space = intersect(&(*CONSTANT_7),&(v31_2));
        drop(v31_2);
        let v31_9: Space = if has_head(&(v31_8)) { singleton(&[]) } else { Space::new() };
        drop(v31_8);
        let v31_11: Space = if (v31_9).is_empty() { Space::new() } else {
          let v33_10: Space = routine_7(c, &(v30_11_head), &(*p1), &(*p2), &(v30_6), &(v30_11_tail));
          compose(&(v31_9),&(v33_10))
        };
        drop(v31_9);
        let v31_12: Space = unite(&(v31_7),&(v31_11));
        v30_11.join_into((v31_12).clone());
      }
      drop(v30_11_cursor);
      drop(v30_6);
      compose(&(v28_10),&(v30_11))
    };
    drop(v28_10);
    let v28_13: Space = unite(&(v28_8),&(v28_12));
    v27_10.join_into((v28_13).clone());
  }
  drop(v27_10_cursor);
  (v27_10).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v34_13 = Space::new();
  let mut v34_13_cursor = (*s0).read_zipper();
  for v34_13_byte in v34_13_cursor.child_mask().iter() {
    v34_13_cursor.descend_to_byte(v34_13_byte);
    let v34_13_tail = v34_13_cursor.make_map();
    v34_13_cursor.ascend(1);
    let v34_13_head = Path::from_slice(&[v34_13_byte]);
    let v35_2: Space = singleton(&(v34_13_head));
    let v35_3: Space = intersect(&(*CONSTANT_7),&(v35_2));
    let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
    drop(v35_3);
    let v35_5: Space = subtract(&(*CONSTANT_0),&(v35_4));
    drop(v35_4);
    let v35_7: Space = if (v35_5).is_empty() { Space::new() } else {
      let mut v36_6 = Space::new();
      let mut v36_6_cursor = (v34_13_tail).read_zipper();
      for v36_6_byte in v36_6_cursor.child_mask().iter() {
        v36_6_cursor.descend_to_byte(v36_6_byte);
        let v36_6_tail = v36_6_cursor.make_map();
        v36_6_cursor.ascend(1);
        let v36_6_head = Path::from_slice(&[v36_6_byte]);
        let v37_2: Space = singleton(&(v36_6_head));
        let v37_3: Space = intersect(&(*CONSTANT_7),&(v37_2));
        let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
        drop(v37_3);
        let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
        drop(v37_4);
        let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
          let v38_6: Path = concat_path(&(v34_13_head),&(v36_6_head));
          let v38_7: Space = routine_6(c, &(v38_6), &(*p1), &(*p2), &(*p0), &(v36_6_tail));
          compose(&(v37_5),&(v38_7))
        };
        drop(v37_5);
        let v37_9: Space = intersect(&(*CONSTANT_7),&(v37_2));
        drop(v37_2);
        let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
        drop(v37_9);
        let v37_12: Space = if (v37_10).is_empty() { Space::new() } else {
          let v39_6: Path = concat_path(&(v34_13_head),&(v36_6_head));
          let v39_11: Space = routine_7(c, &(v39_6), &(*p1), &(*p2), &(*p0), &(v36_6_tail));
          drop(v39_6);
          compose(&(v37_10),&(v39_11))
        };
        drop(v37_10);
        let v37_13: Space = unite(&(v37_8),&(v37_12));
        v36_6.join_into((v37_13).clone());
      }
      drop(v36_6_cursor);
      compose(&(v35_5),&(v36_6))
    };
    drop(v35_5);
    let v35_8: Space = intersect(&(*CONSTANT_7),&(v35_2));
    drop(v35_2);
    let v35_9: Space = if has_head(&(v35_8)) { singleton(&[]) } else { Space::new() };
    drop(v35_8);
    let v35_11: Space = if (v35_9).is_empty() { Space::new() } else {
      let mut v40_10 = Space::new();
      let mut v40_10_cursor = (v34_13_tail).read_zipper();
      for v40_10_byte in v40_10_cursor.child_mask().iter() {
        v40_10_cursor.descend_to_byte(v40_10_byte);
        let v40_10_tail = v40_10_cursor.make_map();
        v40_10_cursor.ascend(1);
        let v40_10_head = Path::from_slice(&[v40_10_byte]);
        let v41_2: Space = singleton(&(v40_10_head));
        let v41_3: Space = intersect(&(*CONSTANT_7),&(v41_2));
        let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
        drop(v41_3);
        let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
        drop(v41_4);
        let v41_7: Space = if (v41_5).is_empty() { Space::new() } else {
          let v42_6: Space = routine_8(c, &(v40_10_head), &(*p1), &(*p2), &(*p0), &(v34_13_head), &(v40_10_tail));
          compose(&(v41_5),&(v42_6))
        };
        drop(v41_5);
        let v41_8: Space = intersect(&(*CONSTANT_7),&(v41_2));
        drop(v41_2);
        let v41_9: Space = if has_head(&(v41_8)) { singleton(&[]) } else { Space::new() };
        drop(v41_8);
        let v41_11: Space = if (v41_9).is_empty() { Space::new() } else {
          let v43_10: Space = routine_9(c, &(v40_10_head), &(*p1), &(*p2), &(*p0), &(v34_13_head), &(v40_10_tail));
          compose(&(v41_9),&(v43_10))
        };
        drop(v41_9);
        let v41_12: Space = unite(&(v41_7),&(v41_11));
        v40_10.join_into((v41_12).clone());
      }
      drop(v40_10_cursor);
      compose(&(v35_9),&(v40_10))
    };
    drop(v35_9);
    let v35_12: Space = unite(&(v35_7),&(v35_11));
    v34_13.join_into((v35_12).clone());
  }
  drop(v34_13_cursor);
  (v34_13).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v44_11 = Space::new();
  let mut v44_11_cursor = (*s0).read_zipper();
  for v44_11_byte in v44_11_cursor.child_mask().iter() {
    v44_11_cursor.descend_to_byte(v44_11_byte);
    let v44_11_tail = v44_11_cursor.make_map();
    v44_11_cursor.ascend(1);
    let v44_11_head = Path::from_slice(&[v44_11_byte]);
    let v45_2: Space = singleton(&(v44_11_head));
    let v45_3: Space = intersect(&(*CONSTANT_7),&(v45_2));
    let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
    drop(v45_3);
    let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
    drop(v45_4);
    let v45_8: Space = if (v45_5).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&(v44_11_head));
      let v46_7: Space = routine_6(c, &(v46_6), &(*p1), &(*p2), &(*p3), &(v44_11_tail));
      compose(&(v45_5),&(v46_7))
    };
    drop(v45_5);
    let v45_9: Space = intersect(&(*CONSTANT_7),&(v45_2));
    drop(v45_2);
    let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
    drop(v45_9);
    let v45_12: Space = if (v45_10).is_empty() { Space::new() } else {
      let v47_6: Path = concat_path(&(*p0),&(v44_11_head));
      let mut v47_11 = Space::new();
      let mut v47_11_cursor = (v44_11_tail).read_zipper();
      for v47_11_byte in v47_11_cursor.child_mask().iter() {
        v47_11_cursor.descend_to_byte(v47_11_byte);
        let v47_11_tail = v47_11_cursor.make_map();
        v47_11_cursor.ascend(1);
        let v47_11_head = Path::from_slice(&[v47_11_byte]);
        let v48_2: Space = singleton(&(v47_11_head));
        let v48_3: Space = intersect(&(*CONSTANT_7),&(v48_2));
        let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
        drop(v48_3);
        let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
        drop(v48_4);
        let v48_7: Space = if (v48_5).is_empty() { Space::new() } else {
          let v49_6: Space = routine_8(c, &(v47_11_head), &(*p1), &(*p2), &(*p3), &(v47_6), &(v47_11_tail));
          compose(&(v48_5),&(v49_6))
        };
        drop(v48_5);
        let v48_8: Space = intersect(&(*CONSTANT_7),&(v48_2));
        drop(v48_2);
        let v48_9: Space = if has_head(&(v48_8)) { singleton(&[]) } else { Space::new() };
        drop(v48_8);
        let v48_11: Space = if (v48_9).is_empty() { Space::new() } else {
          let v50_10: Space = routine_9(c, &(v47_11_head), &(*p1), &(*p2), &(*p3), &(v47_6), &(v47_11_tail));
          compose(&(v48_9),&(v50_10))
        };
        drop(v48_9);
        let v48_12: Space = unite(&(v48_7),&(v48_11));
        v47_11.join_into((v48_12).clone());
      }
      drop(v47_11_cursor);
      drop(v47_6);
      compose(&(v45_10),&(v47_11))
    };
    drop(v45_10);
    let v45_13: Space = unite(&(v45_8),&(v45_12));
    v44_11.join_into((v45_13).clone());
  }
  drop(v44_11_cursor);
  (v44_11).clone()
}

fn routine_7(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v51_14 = Space::new();
  let mut v51_14_cursor = (*s0).read_zipper();
  for v51_14_byte in v51_14_cursor.child_mask().iter() {
    v51_14_cursor.descend_to_byte(v51_14_byte);
    let v51_14_tail = v51_14_cursor.make_map();
    v51_14_cursor.ascend(1);
    let v51_14_head = Path::from_slice(&[v51_14_byte]);
    let v52_2: Space = singleton(&(v51_14_head));
    let v52_3: Space = intersect(&(*CONSTANT_7),&(v52_2));
    let v52_4: Space = if has_head(&(v52_3)) { singleton(&[]) } else { Space::new() };
    drop(v52_3);
    let v52_5: Space = subtract(&(*CONSTANT_0),&(v52_4));
    drop(v52_4);
    let v52_7: Space = if (v52_5).is_empty() { Space::new() } else {
      let mut v53_6 = Space::new();
      let mut v53_6_cursor = (v51_14_tail).read_zipper();
      for v53_6_byte in v53_6_cursor.child_mask().iter() {
        v53_6_cursor.descend_to_byte(v53_6_byte);
        let v53_6_tail = v53_6_cursor.make_map();
        v53_6_cursor.ascend(1);
        let v53_6_head = Path::from_slice(&[v53_6_byte]);
        let v54_2: Space = singleton(&(v53_6_head));
        let v54_3: Space = intersect(&(*CONSTANT_7),&(v54_2));
        let v54_4: Space = if has_head(&(v54_3)) { singleton(&[]) } else { Space::new() };
        drop(v54_3);
        let v54_5: Space = subtract(&(*CONSTANT_0),&(v54_4));
        drop(v54_4);
        let v54_8: Space = if (v54_5).is_empty() { Space::new() } else {
          let v55_6: Path = concat_path(&(v51_14_head),&(v53_6_head));
          let v55_7: Space = routine_8(c, &(v55_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v53_6_tail));
          compose(&(v54_5),&(v55_7))
        };
        drop(v54_5);
        let v54_9: Space = intersect(&(*CONSTANT_7),&(v54_2));
        drop(v54_2);
        let v54_10: Space = if has_head(&(v54_9)) { singleton(&[]) } else { Space::new() };
        drop(v54_9);
        let v54_12: Space = if (v54_10).is_empty() { Space::new() } else {
          let v56_6: Path = concat_path(&(v51_14_head),&(v53_6_head));
          let v56_11: Space = routine_9(c, &(v56_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v53_6_tail));
          drop(v56_6);
          compose(&(v54_10),&(v56_11))
        };
        drop(v54_10);
        let v54_13: Space = unite(&(v54_8),&(v54_12));
        v53_6.join_into((v54_13).clone());
      }
      drop(v53_6_cursor);
      compose(&(v52_5),&(v53_6))
    };
    drop(v52_5);
    let v52_8: Space = intersect(&(*CONSTANT_7),&(v52_2));
    drop(v52_2);
    let v52_9: Space = if has_head(&(v52_8)) { singleton(&[]) } else { Space::new() };
    drop(v52_8);
    let v52_11: Space = if (v52_9).is_empty() { Space::new() } else {
      let mut v57_10 = Space::new();
      let mut v57_10_cursor = (v51_14_tail).read_zipper();
      for v57_10_byte in v57_10_cursor.child_mask().iter() {
        v57_10_cursor.descend_to_byte(v57_10_byte);
        let v57_10_tail = v57_10_cursor.make_map();
        v57_10_cursor.ascend(1);
        let v57_10_head = Path::from_slice(&[v57_10_byte]);
        let v58_2: Space = singleton(&(v57_10_head));
        let v58_3: Space = intersect(&(*CONSTANT_7),&(v58_2));
        let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (v58_5).is_empty() { Space::new() } else {
          let v59_6: Space = routine_10(c, &(v57_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v51_14_head), &(v57_10_tail));
          compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = intersect(&(*CONSTANT_7),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (v58_9).is_empty() { Space::new() } else {
          let v60_10: Space = routine_11(c, &(v57_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v51_14_head), &(v57_10_tail));
          compose(&(v58_9),&(v60_10))
        };
        drop(v58_9);
        let v58_12: Space = unite(&(v58_7),&(v58_11));
        v57_10.join_into((v58_12).clone());
      }
      drop(v57_10_cursor);
      compose(&(v52_9),&(v57_10))
    };
    drop(v52_9);
    let v52_12: Space = unite(&(v52_7),&(v52_11));
    v51_14.join_into((v52_12).clone());
  }
  drop(v51_14_cursor);
  (v51_14).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v61_12 = Space::new();
  let mut v61_12_cursor = (*s0).read_zipper();
  for v61_12_byte in v61_12_cursor.child_mask().iter() {
    v61_12_cursor.descend_to_byte(v61_12_byte);
    let v61_12_tail = v61_12_cursor.make_map();
    v61_12_cursor.ascend(1);
    let v61_12_head = Path::from_slice(&[v61_12_byte]);
    let v62_2: Space = singleton(&(v61_12_head));
    let v62_3: Space = intersect(&(*CONSTANT_7),&(v62_2));
    let v62_4: Space = if has_head(&(v62_3)) { singleton(&[]) } else { Space::new() };
    drop(v62_3);
    let v62_5: Space = subtract(&(*CONSTANT_0),&(v62_4));
    drop(v62_4);
    let v62_8: Space = if (v62_5).is_empty() { Space::new() } else {
      let v63_6: Path = concat_path(&(*p0),&(v61_12_head));
      let v63_7: Space = routine_8(c, &(v63_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v61_12_tail));
      compose(&(v62_5),&(v63_7))
    };
    drop(v62_5);
    let v62_9: Space = intersect(&(*CONSTANT_7),&(v62_2));
    drop(v62_2);
    let v62_10: Space = if has_head(&(v62_9)) { singleton(&[]) } else { Space::new() };
    drop(v62_9);
    let v62_12: Space = if (v62_10).is_empty() { Space::new() } else {
      let v64_6: Path = concat_path(&(*p0),&(v61_12_head));
      let mut v64_11 = Space::new();
      let mut v64_11_cursor = (v61_12_tail).read_zipper();
      for v64_11_byte in v64_11_cursor.child_mask().iter() {
        v64_11_cursor.descend_to_byte(v64_11_byte);
        let v64_11_tail = v64_11_cursor.make_map();
        v64_11_cursor.ascend(1);
        let v64_11_head = Path::from_slice(&[v64_11_byte]);
        let v65_2: Space = singleton(&(v64_11_head));
        let v65_3: Space = intersect(&(*CONSTANT_7),&(v65_2));
        let v65_4: Space = if has_head(&(v65_3)) { singleton(&[]) } else { Space::new() };
        drop(v65_3);
        let v65_5: Space = subtract(&(*CONSTANT_0),&(v65_4));
        drop(v65_4);
        let v65_7: Space = if (v65_5).is_empty() { Space::new() } else {
          let v66_6: Space = routine_10(c, &(v64_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v64_6), &(v64_11_tail));
          compose(&(v65_5),&(v66_6))
        };
        drop(v65_5);
        let v65_8: Space = intersect(&(*CONSTANT_7),&(v65_2));
        drop(v65_2);
        let v65_9: Space = if has_head(&(v65_8)) { singleton(&[]) } else { Space::new() };
        drop(v65_8);
        let v65_11: Space = if (v65_9).is_empty() { Space::new() } else {
          let v67_10: Space = routine_11(c, &(v64_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v64_6), &(v64_11_tail));
          compose(&(v65_9),&(v67_10))
        };
        drop(v65_9);
        let v65_12: Space = unite(&(v65_7),&(v65_11));
        v64_11.join_into((v65_12).clone());
      }
      drop(v64_11_cursor);
      drop(v64_6);
      compose(&(v62_10),&(v64_11))
    };
    drop(v62_10);
    let v62_13: Space = unite(&(v62_8),&(v62_12));
    v61_12.join_into((v62_13).clone());
  }
  drop(v61_12_cursor);
  (v61_12).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v68_15 = Space::new();
  let mut v68_15_cursor = (*s0).read_zipper();
  for v68_15_byte in v68_15_cursor.child_mask().iter() {
    v68_15_cursor.descend_to_byte(v68_15_byte);
    let v68_15_tail = v68_15_cursor.make_map();
    v68_15_cursor.ascend(1);
    let v68_15_head = Path::from_slice(&[v68_15_byte]);
    let v69_2: Space = singleton(&(v68_15_head));
    let v69_3: Space = intersect(&(*CONSTANT_7),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (v69_5).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_cursor = (v68_15_tail).read_zipper();
      for v70_6_byte in v70_6_cursor.child_mask().iter() {
        v70_6_cursor.descend_to_byte(v70_6_byte);
        let v70_6_tail = v70_6_cursor.make_map();
        v70_6_cursor.ascend(1);
        let v70_6_head = Path::from_slice(&[v70_6_byte]);
        let v71_2: Space = singleton(&(v70_6_head));
        let v71_3: Space = intersect(&(*CONSTANT_7),&(v71_2));
        let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
          let v72_6: Path = concat_path(&(v68_15_head),&(v70_6_head));
          let v72_7: Space = routine_10(c, &(v72_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v70_6_tail));
          compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = intersect(&(*CONSTANT_7),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (v71_10).is_empty() { Space::new() } else {
          let v73_6: Path = concat_path(&(v68_15_head),&(v70_6_head));
          let v73_11: Space = routine_11(c, &(v73_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v70_6_tail));
          drop(v73_6);
          compose(&(v71_10),&(v73_11))
        };
        drop(v71_10);
        let v71_13: Space = unite(&(v71_8),&(v71_12));
        v70_6.join_into((v71_13).clone());
      }
      drop(v70_6_cursor);
      compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = intersect(&(*CONSTANT_7),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (v69_9).is_empty() { Space::new() } else {
      let mut v74_10 = Space::new();
      let mut v74_10_cursor = (v68_15_tail).read_zipper();
      for v74_10_byte in v74_10_cursor.child_mask().iter() {
        v74_10_cursor.descend_to_byte(v74_10_byte);
        let v74_10_tail = v74_10_cursor.make_map();
        v74_10_cursor.ascend(1);
        let v74_10_head = Path::from_slice(&[v74_10_byte]);
        let v75_2: Space = singleton(&(v74_10_head));
        let v75_3: Space = intersect(&(*CONSTANT_7),&(v75_2));
        let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
        drop(v75_3);
        let v75_5: Space = subtract(&(*CONSTANT_0),&(v75_4));
        drop(v75_4);
        let v75_7: Space = if (v75_5).is_empty() { Space::new() } else {
          let v76_6: Space = routine_12(c, &(v74_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v68_15_head), &(v74_10_tail));
          compose(&(v75_5),&(v76_6))
        };
        drop(v75_5);
        let v75_8: Space = intersect(&(*CONSTANT_7),&(v75_2));
        drop(v75_2);
        let v75_9: Space = if has_head(&(v75_8)) { singleton(&[]) } else { Space::new() };
        drop(v75_8);
        let v75_11: Space = if (v75_9).is_empty() { Space::new() } else {
          let v77_10: Space = routine_13(c, &(v74_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v68_15_head), &(v74_10_tail));
          compose(&(v75_9),&(v77_10))
        };
        drop(v75_9);
        let v75_12: Space = unite(&(v75_7),&(v75_11));
        v74_10.join_into((v75_12).clone());
      }
      drop(v74_10_cursor);
      compose(&(v69_9),&(v74_10))
    };
    drop(v69_9);
    let v69_12: Space = unite(&(v69_7),&(v69_11));
    v68_15.join_into((v69_12).clone());
  }
  drop(v68_15_cursor);
  (v68_15).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v78_13 = Space::new();
  let mut v78_13_cursor = (*s0).read_zipper();
  for v78_13_byte in v78_13_cursor.child_mask().iter() {
    v78_13_cursor.descend_to_byte(v78_13_byte);
    let v78_13_tail = v78_13_cursor.make_map();
    v78_13_cursor.ascend(1);
    let v78_13_head = Path::from_slice(&[v78_13_byte]);
    let v79_2: Space = singleton(&(v78_13_head));
    let v79_3: Space = intersect(&(*CONSTANT_7),&(v79_2));
    let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
    drop(v79_3);
    let v79_5: Space = subtract(&(*CONSTANT_0),&(v79_4));
    drop(v79_4);
    let v79_8: Space = if (v79_5).is_empty() { Space::new() } else {
      let v80_6: Path = concat_path(&(*p0),&(v78_13_head));
      let v80_7: Space = routine_10(c, &(v80_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v78_13_tail));
      compose(&(v79_5),&(v80_7))
    };
    drop(v79_5);
    let v79_9: Space = intersect(&(*CONSTANT_7),&(v79_2));
    drop(v79_2);
    let v79_10: Space = if has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
    drop(v79_9);
    let v79_12: Space = if (v79_10).is_empty() { Space::new() } else {
      let v81_6: Path = concat_path(&(*p0),&(v78_13_head));
      let mut v81_11 = Space::new();
      let mut v81_11_cursor = (v78_13_tail).read_zipper();
      for v81_11_byte in v81_11_cursor.child_mask().iter() {
        v81_11_cursor.descend_to_byte(v81_11_byte);
        let v81_11_tail = v81_11_cursor.make_map();
        v81_11_cursor.ascend(1);
        let v81_11_head = Path::from_slice(&[v81_11_byte]);
        let v82_2: Space = singleton(&(v81_11_head));
        let v82_3: Space = intersect(&(*CONSTANT_7),&(v82_2));
        let v82_4: Space = if has_head(&(v82_3)) { singleton(&[]) } else { Space::new() };
        drop(v82_3);
        let v82_5: Space = subtract(&(*CONSTANT_0),&(v82_4));
        drop(v82_4);
        let v82_7: Space = if (v82_5).is_empty() { Space::new() } else {
          let v83_6: Space = routine_12(c, &(v81_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v81_6), &(v81_11_tail));
          compose(&(v82_5),&(v83_6))
        };
        drop(v82_5);
        let v82_8: Space = intersect(&(*CONSTANT_7),&(v82_2));
        drop(v82_2);
        let v82_9: Space = if has_head(&(v82_8)) { singleton(&[]) } else { Space::new() };
        drop(v82_8);
        let v82_11: Space = if (v82_9).is_empty() { Space::new() } else {
          let v84_10: Space = routine_13(c, &(v81_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v81_6), &(v81_11_tail));
          compose(&(v82_9),&(v84_10))
        };
        drop(v82_9);
        let v82_12: Space = unite(&(v82_7),&(v82_11));
        v81_11.join_into((v82_12).clone());
      }
      drop(v81_11_cursor);
      drop(v81_6);
      compose(&(v79_10),&(v81_11))
    };
    drop(v79_10);
    let v79_13: Space = unite(&(v79_8),&(v79_12));
    v78_13.join_into((v79_13).clone());
  }
  drop(v78_13_cursor);
  (v78_13).clone()
}

fn routine_11(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v85_16 = Space::new();
  let mut v85_16_cursor = (*s0).read_zipper();
  for v85_16_byte in v85_16_cursor.child_mask().iter() {
    v85_16_cursor.descend_to_byte(v85_16_byte);
    let v85_16_tail = v85_16_cursor.make_map();
    v85_16_cursor.ascend(1);
    let v85_16_head = Path::from_slice(&[v85_16_byte]);
    let v86_2: Space = singleton(&(v85_16_head));
    let v86_3: Space = intersect(&(*CONSTANT_7),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (v86_5).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_cursor = (v85_16_tail).read_zipper();
      for v87_6_byte in v87_6_cursor.child_mask().iter() {
        v87_6_cursor.descend_to_byte(v87_6_byte);
        let v87_6_tail = v87_6_cursor.make_map();
        v87_6_cursor.ascend(1);
        let v87_6_head = Path::from_slice(&[v87_6_byte]);
        let v88_2: Space = singleton(&(v87_6_head));
        let v88_3: Space = intersect(&(*CONSTANT_7),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
          let v89_6: Path = concat_path(&(v85_16_head),&(v87_6_head));
          let v89_7: Space = routine_12(c, &(v89_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v87_6_tail));
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_7),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
          let v90_6: Path = concat_path(&(v85_16_head),&(v87_6_head));
          let v90_11: Space = routine_13(c, &(v90_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v87_6_tail));
          drop(v90_6);
          compose(&(v88_10),&(v90_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        v87_6.join_into((v88_13).clone());
      }
      drop(v87_6_cursor);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_7),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (v86_9).is_empty() { Space::new() } else {
      let mut v91_10 = Space::new();
      let mut v91_10_cursor = (v85_16_tail).read_zipper();
      for v91_10_byte in v91_10_cursor.child_mask().iter() {
        v91_10_cursor.descend_to_byte(v91_10_byte);
        let v91_10_tail = v91_10_cursor.make_map();
        v91_10_cursor.ascend(1);
        let v91_10_head = Path::from_slice(&[v91_10_byte]);
        let v92_2: Space = singleton(&(v91_10_head));
        let v92_3: Space = intersect(&(*CONSTANT_7),&(v92_2));
        let v92_4: Space = if has_head(&(v92_3)) { singleton(&[]) } else { Space::new() };
        drop(v92_3);
        let v92_5: Space = subtract(&(*CONSTANT_0),&(v92_4));
        drop(v92_4);
        let v92_7: Space = if (v92_5).is_empty() { Space::new() } else {
          let v93_6: Space = routine_14(c, &(v91_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v85_16_head), &(v91_10_tail));
          compose(&(v92_5),&(v93_6))
        };
        drop(v92_5);
        let v92_8: Space = intersect(&(*CONSTANT_7),&(v92_2));
        drop(v92_2);
        let v92_9: Space = if has_head(&(v92_8)) { singleton(&[]) } else { Space::new() };
        drop(v92_8);
        let v92_11: Space = if (v92_9).is_empty() { Space::new() } else {
          let v94_10: Space = routine_15(c, &(v91_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v85_16_head), &(v91_10_tail));
          compose(&(v92_9),&(v94_10))
        };
        drop(v92_9);
        let v92_12: Space = unite(&(v92_7),&(v92_11));
        v91_10.join_into((v92_12).clone());
      }
      drop(v91_10_cursor);
      compose(&(v86_9),&(v91_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    v85_16.join_into((v86_12).clone());
  }
  drop(v85_16_cursor);
  (v85_16).clone()
}

fn routine_12(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v95_14 = Space::new();
  let mut v95_14_cursor = (*s0).read_zipper();
  for v95_14_byte in v95_14_cursor.child_mask().iter() {
    v95_14_cursor.descend_to_byte(v95_14_byte);
    let v95_14_tail = v95_14_cursor.make_map();
    v95_14_cursor.ascend(1);
    let v95_14_head = Path::from_slice(&[v95_14_byte]);
    let v96_2: Space = singleton(&(v95_14_head));
    let v96_3: Space = intersect(&(*CONSTANT_7),&(v96_2));
    let v96_4: Space = if has_head(&(v96_3)) { singleton(&[]) } else { Space::new() };
    drop(v96_3);
    let v96_5: Space = subtract(&(*CONSTANT_0),&(v96_4));
    drop(v96_4);
    let v96_8: Space = if (v96_5).is_empty() { Space::new() } else {
      let v97_6: Path = concat_path(&(*p0),&(v95_14_head));
      let v97_7: Space = routine_12(c, &(v97_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v95_14_tail));
      compose(&(v96_5),&(v97_7))
    };
    drop(v96_5);
    let v96_9: Space = intersect(&(*CONSTANT_7),&(v96_2));
    drop(v96_2);
    let v96_10: Space = if has_head(&(v96_9)) { singleton(&[]) } else { Space::new() };
    drop(v96_9);
    let v96_12: Space = if (v96_10).is_empty() { Space::new() } else {
      let v98_6: Path = concat_path(&(*p0),&(v95_14_head));
      let mut v98_11 = Space::new();
      let mut v98_11_cursor = (v95_14_tail).read_zipper();
      for v98_11_byte in v98_11_cursor.child_mask().iter() {
        v98_11_cursor.descend_to_byte(v98_11_byte);
        let v98_11_tail = v98_11_cursor.make_map();
        v98_11_cursor.ascend(1);
        let v98_11_head = Path::from_slice(&[v98_11_byte]);
        let v99_2: Space = singleton(&(v98_11_head));
        let v99_3: Space = intersect(&(*CONSTANT_7),&(v99_2));
        let v99_4: Space = if has_head(&(v99_3)) { singleton(&[]) } else { Space::new() };
        drop(v99_3);
        let v99_5: Space = subtract(&(*CONSTANT_0),&(v99_4));
        drop(v99_4);
        let v99_7: Space = if (v99_5).is_empty() { Space::new() } else {
          let v100_6: Space = routine_14(c, &(v98_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v98_6), &(v98_11_tail));
          compose(&(v99_5),&(v100_6))
        };
        drop(v99_5);
        let v99_8: Space = intersect(&(*CONSTANT_7),&(v99_2));
        drop(v99_2);
        let v99_9: Space = if has_head(&(v99_8)) { singleton(&[]) } else { Space::new() };
        drop(v99_8);
        let v99_11: Space = if (v99_9).is_empty() { Space::new() } else {
          let v101_10: Space = routine_15(c, &(v98_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v98_6), &(v98_11_tail));
          compose(&(v99_9),&(v101_10))
        };
        drop(v99_9);
        let v99_12: Space = unite(&(v99_7),&(v99_11));
        v98_11.join_into((v99_12).clone());
      }
      drop(v98_11_cursor);
      drop(v98_6);
      compose(&(v96_10),&(v98_11))
    };
    drop(v96_10);
    let v96_13: Space = unite(&(v96_8),&(v96_12));
    v95_14.join_into((v96_13).clone());
  }
  drop(v95_14_cursor);
  (v95_14).clone()
}

fn routine_13(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v102_17 = Space::new();
  let mut v102_17_cursor = (*s0).read_zipper();
  for v102_17_byte in v102_17_cursor.child_mask().iter() {
    v102_17_cursor.descend_to_byte(v102_17_byte);
    let v102_17_tail = v102_17_cursor.make_map();
    v102_17_cursor.ascend(1);
    let v102_17_head = Path::from_slice(&[v102_17_byte]);
    let v103_2: Space = singleton(&(v102_17_head));
    let v103_3: Space = intersect(&(*CONSTANT_7),&(v103_2));
    let v103_4: Space = if has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
    drop(v103_3);
    let v103_5: Space = subtract(&(*CONSTANT_0),&(v103_4));
    drop(v103_4);
    let v103_7: Space = if (v103_5).is_empty() { Space::new() } else {
      let mut v104_6 = Space::new();
      let mut v104_6_cursor = (v102_17_tail).read_zipper();
      for v104_6_byte in v104_6_cursor.child_mask().iter() {
        v104_6_cursor.descend_to_byte(v104_6_byte);
        let v104_6_tail = v104_6_cursor.make_map();
        v104_6_cursor.ascend(1);
        let v104_6_head = Path::from_slice(&[v104_6_byte]);
        let v105_2: Space = singleton(&(v104_6_head));
        let v105_3: Space = intersect(&(*CONSTANT_7),&(v105_2));
        let v105_4: Space = if has_head(&(v105_3)) { singleton(&[]) } else { Space::new() };
        drop(v105_3);
        let v105_5: Space = subtract(&(*CONSTANT_0),&(v105_4));
        drop(v105_4);
        let v105_8: Space = if (v105_5).is_empty() { Space::new() } else {
          let v106_6: Path = concat_path(&(v102_17_head),&(v104_6_head));
          let v106_7: Space = routine_14(c, &(v106_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v104_6_tail));
          compose(&(v105_5),&(v106_7))
        };
        drop(v105_5);
        let v105_9: Space = intersect(&(*CONSTANT_7),&(v105_2));
        drop(v105_2);
        let v105_10: Space = if has_head(&(v105_9)) { singleton(&[]) } else { Space::new() };
        drop(v105_9);
        let v105_12: Space = if (v105_10).is_empty() { Space::new() } else {
          let v107_6: Path = concat_path(&(v102_17_head),&(v104_6_head));
          let v107_11: Space = routine_15(c, &(v107_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v104_6_tail));
          drop(v107_6);
          compose(&(v105_10),&(v107_11))
        };
        drop(v105_10);
        let v105_13: Space = unite(&(v105_8),&(v105_12));
        v104_6.join_into((v105_13).clone());
      }
      drop(v104_6_cursor);
      compose(&(v103_5),&(v104_6))
    };
    drop(v103_5);
    let v103_8: Space = intersect(&(*CONSTANT_7),&(v103_2));
    drop(v103_2);
    let v103_9: Space = if has_head(&(v103_8)) { singleton(&[]) } else { Space::new() };
    drop(v103_8);
    let v103_11: Space = if (v103_9).is_empty() { Space::new() } else {
      let mut v108_10 = Space::new();
      let mut v108_10_cursor = (v102_17_tail).read_zipper();
      for v108_10_byte in v108_10_cursor.child_mask().iter() {
        v108_10_cursor.descend_to_byte(v108_10_byte);
        let v108_10_tail = v108_10_cursor.make_map();
        v108_10_cursor.ascend(1);
        let v108_10_head = Path::from_slice(&[v108_10_byte]);
        let v109_2: Space = singleton(&(v108_10_head));
        let v109_3: Space = intersect(&(*CONSTANT_7),&(v109_2));
        let v109_4: Space = if has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
        drop(v109_3);
        let v109_5: Space = subtract(&(*CONSTANT_0),&(v109_4));
        drop(v109_4);
        let v109_7: Space = if (v109_5).is_empty() { Space::new() } else {
          let v110_6: Space = routine_16(c, &(v108_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v102_17_head), &(v108_10_tail));
          compose(&(v109_5),&(v110_6))
        };
        drop(v109_5);
        let v109_8: Space = intersect(&(*CONSTANT_7),&(v109_2));
        drop(v109_2);
        let v109_9: Space = if has_head(&(v109_8)) { singleton(&[]) } else { Space::new() };
        drop(v109_8);
        let v109_11: Space = if (v109_9).is_empty() { Space::new() } else {
          let v111_10: Space = routine_17(c, &(v108_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v102_17_head), &(v108_10_tail));
          compose(&(v109_9),&(v111_10))
        };
        drop(v109_9);
        let v109_12: Space = unite(&(v109_7),&(v109_11));
        v108_10.join_into((v109_12).clone());
      }
      drop(v108_10_cursor);
      compose(&(v103_9),&(v108_10))
    };
    drop(v103_9);
    let v103_12: Space = unite(&(v103_7),&(v103_11));
    v102_17.join_into((v103_12).clone());
  }
  drop(v102_17_cursor);
  (v102_17).clone()
}

fn routine_14(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let mut v112_15 = Space::new();
  let mut v112_15_cursor = (*s0).read_zipper();
  for v112_15_byte in v112_15_cursor.child_mask().iter() {
    v112_15_cursor.descend_to_byte(v112_15_byte);
    let v112_15_tail = v112_15_cursor.make_map();
    v112_15_cursor.ascend(1);
    let v112_15_head = Path::from_slice(&[v112_15_byte]);
    let v113_2: Space = singleton(&(v112_15_head));
    let v113_3: Space = intersect(&(*CONSTANT_7),&(v113_2));
    let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
    drop(v113_3);
    let v113_5: Space = subtract(&(*CONSTANT_0),&(v113_4));
    drop(v113_4);
    let v113_8: Space = if (v113_5).is_empty() { Space::new() } else {
      let v114_6: Path = concat_path(&(*p0),&(v112_15_head));
      let v114_7: Space = routine_14(c, &(v114_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v112_15_tail));
      compose(&(v113_5),&(v114_7))
    };
    drop(v113_5);
    let v113_9: Space = intersect(&(*CONSTANT_7),&(v113_2));
    drop(v113_2);
    let v113_10: Space = if has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
    drop(v113_9);
    let v113_12: Space = if (v113_10).is_empty() { Space::new() } else {
      let v115_6: Path = concat_path(&(*p0),&(v112_15_head));
      let mut v115_11 = Space::new();
      let mut v115_11_cursor = (v112_15_tail).read_zipper();
      for v115_11_byte in v115_11_cursor.child_mask().iter() {
        v115_11_cursor.descend_to_byte(v115_11_byte);
        let v115_11_tail = v115_11_cursor.make_map();
        v115_11_cursor.ascend(1);
        let v115_11_head = Path::from_slice(&[v115_11_byte]);
        let v116_2: Space = singleton(&(v115_11_head));
        let v116_3: Space = intersect(&(*CONSTANT_7),&(v116_2));
        let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
        drop(v116_3);
        let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
        drop(v116_4);
        let v116_7: Space = if (v116_5).is_empty() { Space::new() } else {
          let v117_6: Space = routine_16(c, &(v115_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v115_6), &(v115_11_tail));
          compose(&(v116_5),&(v117_6))
        };
        drop(v116_5);
        let v116_8: Space = intersect(&(*CONSTANT_7),&(v116_2));
        drop(v116_2);
        let v116_9: Space = if has_head(&(v116_8)) { singleton(&[]) } else { Space::new() };
        drop(v116_8);
        let v116_11: Space = if (v116_9).is_empty() { Space::new() } else {
          let v118_10: Space = routine_17(c, &(v115_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v115_6), &(v115_11_tail));
          compose(&(v116_9),&(v118_10))
        };
        drop(v116_9);
        let v116_12: Space = unite(&(v116_7),&(v116_11));
        v115_11.join_into((v116_12).clone());
      }
      drop(v115_11_cursor);
      drop(v115_6);
      compose(&(v113_10),&(v115_11))
    };
    drop(v113_10);
    let v113_13: Space = unite(&(v113_8),&(v113_12));
    v112_15.join_into((v113_13).clone());
  }
  drop(v112_15_cursor);
  (v112_15).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v119_12: Path = concat_path(&(*p2),&(*p3));
  let v119_13: Path = concat_path(&(v119_12),&(*p4));
  drop(v119_12);
  let v119_14: Path = concat_path(&(v119_13),&(*p5));
  drop(v119_13);
  let v119_15: Path = concat_path(&(v119_14),&(*p6));
  drop(v119_14);
  let v119_16: Path = concat_path(&(v119_15),&(*p7));
  drop(v119_15);
  let v119_17: Path = concat_path(&(v119_16),&(*p0));
  drop(v119_16);
  let mut v119_27 = Space::new();
  let mut v119_27_cursor = (*s0).read_zipper();
  for v119_27_byte in v119_27_cursor.child_mask().iter() {
    v119_27_cursor.descend_to_byte(v119_27_byte);
    let v119_27_tail = v119_27_cursor.make_map();
    v119_27_cursor.ascend(1);
    let v119_27_head = Path::from_slice(&[v119_27_byte]);
    let v120_2: Space = singleton(&(v119_27_head));
    let v120_3: Space = intersect(&(*CONSTANT_7),&(v120_2));
    let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
    drop(v120_3);
    let v120_5: Space = subtract(&(*CONSTANT_0),&(v120_4));
    drop(v120_4);
    let v120_7: Space = if (v120_5).is_empty() { Space::new() } else {
      let mut v121_6 = Space::new();
      let mut v121_6_cursor = (v119_27_tail).read_zipper();
      for v121_6_byte in v121_6_cursor.child_mask().iter() {
        v121_6_cursor.descend_to_byte(v121_6_byte);
        let v121_6_tail = v121_6_cursor.make_map();
        v121_6_cursor.ascend(1);
        let v121_6_head = Path::from_slice(&[v121_6_byte]);
        let v122_2: Space = singleton(&(v121_6_head));
        let v122_3: Space = intersect(&(*CONSTANT_7),&(v122_2));
        let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
        drop(v122_3);
        let v122_5: Space = subtract(&(*CONSTANT_0),&(v122_4));
        drop(v122_4);
        let v122_8: Space = if (v122_5).is_empty() { Space::new() } else {
          let v123_6: Path = concat_path(&(v119_27_head),&(v121_6_head));
          let v123_7: Space = routine_16(c, &(v123_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &(v121_6_tail));
          compose(&(v122_5),&(v123_7))
        };
        drop(v122_5);
        let v122_9: Space = intersect(&(*CONSTANT_7),&(v122_2));
        drop(v122_2);
        let v122_10: Space = if has_head(&(v122_9)) { singleton(&[]) } else { Space::new() };
        drop(v122_9);
        let v122_12: Space = if (v122_10).is_empty() { Space::new() } else {
          let v124_6: Path = concat_path(&(v119_27_head),&(v121_6_head));
          let v124_11: Space = routine_17(c, &(v124_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &(v121_6_tail));
          drop(v124_6);
          compose(&(v122_10),&(v124_11))
        };
        drop(v122_10);
        let v122_13: Space = unite(&(v122_8),&(v122_12));
        v121_6.join_into((v122_13).clone());
      }
      drop(v121_6_cursor);
      compose(&(v120_5),&(v121_6))
    };
    drop(v120_5);
    let v120_8: Space = intersect(&(*CONSTANT_7),&(v120_2));
    drop(v120_2);
    let v120_9: Space = if has_head(&(v120_8)) { singleton(&[]) } else { Space::new() };
    drop(v120_8);
    let v120_15: Space = if (v120_9).is_empty() { Space::new() } else {
      let v125_10: Path = concat_path(&(v119_17),&(v119_27_head));
      let v125_11: Space = singleton(&(v125_10));
      drop(v125_10);
      let v125_12: Space = routine_18(c, &(*p1), &(v125_11));
      drop(v125_11);
      let mut v125_13 = Space::new();
      let mut v125_13_cursor = (v125_12).read_zipper();
      for v125_13_byte in v125_13_cursor.child_mask().iter() {
        v125_13_cursor.descend_to_byte(v125_13_byte);
        let v125_13_tail = v125_13_cursor.make_map();
        v125_13_cursor.ascend(1);
        let v125_13_head = Path::from_slice(&[v125_13_byte]);
        let v126_2: Space = singleton(&(v125_13_head));
        let v126_3: Space = intersect(&(*CONSTANT_7),&(v126_2));
        let v126_4: Space = if has_head(&(v126_3)) { singleton(&[]) } else { Space::new() };
        drop(v126_3);
        let v126_5: Space = subtract(&(*CONSTANT_0),&(v126_4));
        drop(v126_4);
        let v126_7: Space = if (v126_5).is_empty() { Space::new() } else {
          let v127_6: Space = routine_19(c, &(v125_13_head), &(*p1), &(v125_13_tail));
          compose(&(v126_5),&(v127_6))
        };
        drop(v126_5);
        let v126_8: Space = intersect(&(*CONSTANT_7),&(v126_2));
        drop(v126_2);
        let v126_9: Space = if has_head(&(v126_8)) { singleton(&[]) } else { Space::new() };
        drop(v126_8);
        let v126_11: Space = if (v126_9).is_empty() { Space::new() } else {
          let v128_10: Space = routine_20(c, &(v125_13_head), &(*p1), &(v125_13_tail));
          compose(&(v126_9),&(v128_10))
        };
        drop(v126_9);
        let v126_12: Space = unite(&(v126_7),&(v126_11));
        v125_13.join_into((v126_12).clone());
      }
      drop(v125_13_cursor);
      let mut v125_14 = Space::new();
      let mut v125_14_cursor = (v125_13).read_zipper();
      for v125_14_byte in v125_14_cursor.child_mask().iter() {
        v125_14_cursor.descend_to_byte(v125_14_byte);
        let v125_14_tail = v125_14_cursor.make_map();
        v125_14_cursor.ascend(1);
        let v125_14_head = Path::from_slice(&[v125_14_byte]);
        let v129_2: Space = singleton(&(v125_14_head));
        let v129_3: Space = intersect(&(*CONSTANT_7),&(v129_2));
        let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
        drop(v129_3);
        let v129_5: Space = subtract(&(*CONSTANT_0),&(v129_4));
        drop(v129_4);
        let v129_7: Space = if (v129_5).is_empty() { Space::new() } else {
          let v130_6: Space = routine_21(c, &(v125_14_head), &(*p1), &(v125_14_tail));
          compose(&(v129_5),&(v130_6))
        };
        drop(v129_5);
        let v129_8: Space = intersect(&(*CONSTANT_7),&(v129_2));
        drop(v129_2);
        let v129_9: Space = if has_head(&(v129_8)) { singleton(&[]) } else { Space::new() };
        drop(v129_8);
        let v129_11: Space = if (v129_9).is_empty() { Space::new() } else {
          let v131_10: Space = routine_22(c, &(v125_14_head), &(*p1), &(v125_14_tail));
          compose(&(v129_9),&(v131_10))
        };
        drop(v129_9);
        let v129_12: Space = unite(&(v129_7),&(v129_11));
        v125_14.join_into((v129_12).clone());
      }
      drop(v125_14_cursor);
      compose(&(v120_9),&(v125_14))
    };
    drop(v120_9);
    let v120_16: Space = unite(&(v120_7),&(v120_15));
    v119_27.join_into((v120_16).clone());
  }
  drop(v119_27_cursor);
  drop(v119_17);
  (v119_27).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let v132_13: Path = concat_path(&(*p2),&(*p3));
  let v132_14: Path = concat_path(&(v132_13),&(*p4));
  drop(v132_13);
  let v132_15: Path = concat_path(&(v132_14),&(*p5));
  drop(v132_14);
  let v132_16: Path = concat_path(&(v132_15),&(*p6));
  drop(v132_15);
  let v132_17: Path = concat_path(&(v132_16),&(*p7));
  drop(v132_16);
  let v132_18: Path = concat_path(&(v132_17),&(*p8));
  drop(v132_17);
  let mut v132_25 = Space::new();
  let mut v132_25_cursor = (*s0).read_zipper();
  for v132_25_byte in v132_25_cursor.child_mask().iter() {
    v132_25_cursor.descend_to_byte(v132_25_byte);
    let v132_25_tail = v132_25_cursor.make_map();
    v132_25_cursor.ascend(1);
    let v132_25_head = Path::from_slice(&[v132_25_byte]);
    let v133_2: Space = singleton(&(v132_25_head));
    let v133_3: Space = intersect(&(*CONSTANT_7),&(v133_2));
    let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
    drop(v133_3);
    let v133_5: Space = subtract(&(*CONSTANT_0),&(v133_4));
    drop(v133_4);
    let v133_8: Space = if (v133_5).is_empty() { Space::new() } else {
      let v134_6: Path = concat_path(&(*p0),&(v132_25_head));
      let v134_7: Space = routine_16(c, &(v134_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(v132_25_tail));
      compose(&(v133_5),&(v134_7))
    };
    drop(v133_5);
    let v133_9: Space = intersect(&(*CONSTANT_7),&(v133_2));
    drop(v133_2);
    let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
    drop(v133_9);
    let v133_16: Space = if (v133_10).is_empty() { Space::new() } else {
      let v135_6: Path = concat_path(&(*p0),&(v132_25_head));
      let v135_11: Path = concat_path(&(v132_18),&(v135_6));
      drop(v135_6);
      let v135_12: Space = singleton(&(v135_11));
      drop(v135_11);
      let v135_13: Space = routine_18(c, &(*p1), &(v135_12));
      drop(v135_12);
      let mut v135_14 = Space::new();
      let mut v135_14_cursor = (v135_13).read_zipper();
      for v135_14_byte in v135_14_cursor.child_mask().iter() {
        v135_14_cursor.descend_to_byte(v135_14_byte);
        let v135_14_tail = v135_14_cursor.make_map();
        v135_14_cursor.ascend(1);
        let v135_14_head = Path::from_slice(&[v135_14_byte]);
        let v136_2: Space = singleton(&(v135_14_head));
        let v136_3: Space = intersect(&(*CONSTANT_7),&(v136_2));
        let v136_4: Space = if has_head(&(v136_3)) { singleton(&[]) } else { Space::new() };
        drop(v136_3);
        let v136_5: Space = subtract(&(*CONSTANT_0),&(v136_4));
        drop(v136_4);
        let v136_7: Space = if (v136_5).is_empty() { Space::new() } else {
          let v137_6: Space = routine_19(c, &(v135_14_head), &(*p1), &(v135_14_tail));
          compose(&(v136_5),&(v137_6))
        };
        drop(v136_5);
        let v136_8: Space = intersect(&(*CONSTANT_7),&(v136_2));
        drop(v136_2);
        let v136_9: Space = if has_head(&(v136_8)) { singleton(&[]) } else { Space::new() };
        drop(v136_8);
        let v136_11: Space = if (v136_9).is_empty() { Space::new() } else {
          let v138_10: Space = routine_20(c, &(v135_14_head), &(*p1), &(v135_14_tail));
          compose(&(v136_9),&(v138_10))
        };
        drop(v136_9);
        let v136_12: Space = unite(&(v136_7),&(v136_11));
        v135_14.join_into((v136_12).clone());
      }
      drop(v135_14_cursor);
      let mut v135_15 = Space::new();
      let mut v135_15_cursor = (v135_14).read_zipper();
      for v135_15_byte in v135_15_cursor.child_mask().iter() {
        v135_15_cursor.descend_to_byte(v135_15_byte);
        let v135_15_tail = v135_15_cursor.make_map();
        v135_15_cursor.ascend(1);
        let v135_15_head = Path::from_slice(&[v135_15_byte]);
        let v139_2: Space = singleton(&(v135_15_head));
        let v139_3: Space = intersect(&(*CONSTANT_7),&(v139_2));
        let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
        drop(v139_3);
        let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
        drop(v139_4);
        let v139_7: Space = if (v139_5).is_empty() { Space::new() } else {
          let v140_6: Space = routine_21(c, &(v135_15_head), &(*p1), &(v135_15_tail));
          compose(&(v139_5),&(v140_6))
        };
        drop(v139_5);
        let v139_8: Space = intersect(&(*CONSTANT_7),&(v139_2));
        drop(v139_2);
        let v139_9: Space = if has_head(&(v139_8)) { singleton(&[]) } else { Space::new() };
        drop(v139_8);
        let v139_11: Space = if (v139_9).is_empty() { Space::new() } else {
          let v141_10: Space = routine_22(c, &(v135_15_head), &(*p1), &(v135_15_tail));
          compose(&(v139_9),&(v141_10))
        };
        drop(v139_9);
        let v139_12: Space = unite(&(v139_7),&(v139_11));
        v135_15.join_into((v139_12).clone());
      }
      drop(v135_15_cursor);
      compose(&(v133_10),&(v135_15))
    };
    drop(v133_10);
    let v133_17: Space = unite(&(v133_8),&(v133_16));
    v132_25.join_into((v133_17).clone());
  }
  drop(v132_25_cursor);
  drop(v132_18);
  (v132_25).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let (v142_100,v142_101,v142_107,v142_112,v142_113,v142_119,v142_124,v142_16,v142_29,v142_35,v142_40,v142_41,v142_47,v142_52,v142_53,v142_59,v142_64,v142_65,v142_71,v142_76,v142_77,v142_83,v142_88,v142_89,v142_95,) = native_block_0(c, p0, p1, p2, p3, p4, p5, p6, p7, p8);
  let v142_125: Space = unite(&(v142_113),&(v142_124));
  let mut v142_138 = Space::new();
  let mut v142_138_cursor = (v142_125).read_zipper();
  for v142_138_byte in v142_138_cursor.child_mask().iter() {
    v142_138_cursor.descend_to_byte(v142_138_byte);
    let v142_138_tail = v142_138_cursor.make_map();
    v142_138_cursor.ascend(1);
    let v142_138_head = Path::from_slice(&[v142_138_byte]);
    let v206_2: Space = singleton(&(v142_138_head));
    let v206_3: Space = intersect(&(*CONSTANT_7),&(v206_2));
    let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
    drop(v206_3);
    let v206_5: Space = subtract(&(*CONSTANT_0),&(v206_4));
    drop(v206_4);
    let v206_7: Space = if (v206_5).is_empty() { Space::new() } else {
      let mut v207_6 = Space::new();
      let mut v207_6_cursor = (v142_138_tail).read_zipper();
      for v207_6_byte in v207_6_cursor.child_mask().iter() {
        v207_6_cursor.descend_to_byte(v207_6_byte);
        let v207_6_tail = v207_6_cursor.make_map();
        v207_6_cursor.ascend(1);
        let v207_6_head = Path::from_slice(&[v207_6_byte]);
        let v208_2: Space = singleton(&(v207_6_head));
        let v208_3: Space = intersect(&(*CONSTANT_7),&(v208_2));
        let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
        drop(v208_3);
        let v208_5: Space = subtract(&(*CONSTANT_0),&(v208_4));
        drop(v208_4);
        let v208_8: Space = if (v208_5).is_empty() { Space::new() } else {
          let v209_6: Path = concat_path(&(v142_138_head),&(v207_6_head));
          let v209_7: Space = routine_19(c, &(v209_6), &(*p1), &(v207_6_tail));
          compose(&(v208_5),&(v209_7))
        };
        drop(v208_5);
        let v208_9: Space = intersect(&(*CONSTANT_7),&(v208_2));
        drop(v208_2);
        let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
        drop(v208_9);
        let v208_12: Space = if (v208_10).is_empty() { Space::new() } else {
          let v210_6: Path = concat_path(&(v142_138_head),&(v207_6_head));
          let v210_11: Space = routine_20(c, &(v210_6), &(*p1), &(v207_6_tail));
          drop(v210_6);
          compose(&(v208_10),&(v210_11))
        };
        drop(v208_10);
        let v208_13: Space = unite(&(v208_8),&(v208_12));
        v207_6.join_into((v208_13).clone());
      }
      drop(v207_6_cursor);
      compose(&(v206_5),&(v207_6))
    };
    drop(v206_5);
    let v206_8: Space = intersect(&(*CONSTANT_7),&(v206_2));
    drop(v206_2);
    let v206_9: Space = if has_head(&(v206_8)) { singleton(&[]) } else { Space::new() };
    drop(v206_8);
    let v206_14: Space = if (v206_9).is_empty() { Space::new() } else {
      let v211_11: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v212_10: Space = routine_59(c, &(*CONSTANT_17), &(*CONSTANT_18));
        compose(&(*CONSTANT_0),&(v212_10))
      };
      let v211_12: Space = unwrap(&(v211_11),&(*p1));
      let mut v211_13 = Space::new();
      let mut v211_13_cursor = (v211_12).read_zipper();
      for v211_13_byte in v211_13_cursor.child_mask().iter() {
        v211_13_cursor.descend_to_byte(v211_13_byte);
        let v211_13_tail = v211_13_cursor.make_map();
        v211_13_cursor.ascend(1);
        let v211_13_head = Path::from_slice(&[v211_13_byte]);
        let v213_2: Space = singleton(&(v211_13_head));
        let v213_3: Space = intersect(&(*CONSTANT_7),&(v213_2));
        let v213_4: Space = if has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
        drop(v213_3);
        let v213_5: Space = subtract(&(*CONSTANT_0),&(v213_4));
        drop(v213_4);
        let v213_7: Space = if (v213_5).is_empty() { Space::new() } else {
          let v214_6: Space = routine_60(c, &(v211_13_head), &(v142_138_head), &(v211_13_tail), &(v142_138_tail));
          compose(&(v213_5),&(v214_6))
        };
        drop(v213_5);
        let v213_8: Space = intersect(&(*CONSTANT_7),&(v213_2));
        drop(v213_2);
        let v213_9: Space = if has_head(&(v213_8)) { singleton(&[]) } else { Space::new() };
        drop(v213_8);
        let v213_11: Space = if (v213_9).is_empty() { Space::new() } else {
          let v215_10: Space = routine_61(c, &(v211_13_head), &(v142_138_head), &(v211_13_tail), &(v142_138_tail));
          compose(&(v213_9),&(v215_10))
        };
        drop(v213_9);
        let v213_12: Space = unite(&(v213_7),&(v213_11));
        v211_13.join_into((v213_12).clone());
      }
      drop(v211_13_cursor);
      compose(&(v206_9),&(v211_13))
    };
    drop(v206_9);
    let v206_15: Space = unite(&(v206_7),&(v206_14));
    v142_138.join_into((v206_15).clone());
  }
  drop(v142_138_cursor);
  let mut v142_150 = Space::new();
  let mut v142_150_cursor = (v142_138).read_zipper();
  for v142_150_byte in v142_150_cursor.child_mask().iter() {
    v142_150_cursor.descend_to_byte(v142_150_byte);
    let v142_150_tail = v142_150_cursor.make_map();
    v142_150_cursor.ascend(1);
    let v142_150_head = Path::from_slice(&[v142_150_byte]);
    let v216_2: Space = singleton(&(v142_150_head));
    let v216_3: Space = intersect(&(*CONSTANT_7),&(v216_2));
    let v216_4: Space = if has_head(&(v216_3)) { singleton(&[]) } else { Space::new() };
    drop(v216_3);
    let v216_5: Space = subtract(&(*CONSTANT_0),&(v216_4));
    drop(v216_4);
    let v216_7: Space = if (v216_5).is_empty() { Space::new() } else {
      let mut v217_6 = Space::new();
      let mut v217_6_cursor = (v142_150_tail).read_zipper();
      for v217_6_byte in v217_6_cursor.child_mask().iter() {
        v217_6_cursor.descend_to_byte(v217_6_byte);
        let v217_6_tail = v217_6_cursor.make_map();
        v217_6_cursor.ascend(1);
        let v217_6_head = Path::from_slice(&[v217_6_byte]);
        let v218_2: Space = singleton(&(v217_6_head));
        let v218_3: Space = intersect(&(*CONSTANT_7),&(v218_2));
        let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
        drop(v218_3);
        let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
        drop(v218_4);
        let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
          let v219_6: Path = concat_path(&(v142_150_head),&(v217_6_head));
          let v219_7: Space = routine_21(c, &(v219_6), &(*p1), &(v217_6_tail));
          compose(&(v218_5),&(v219_7))
        };
        drop(v218_5);
        let v218_9: Space = intersect(&(*CONSTANT_7),&(v218_2));
        drop(v218_2);
        let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
        drop(v218_9);
        let v218_12: Space = if (v218_10).is_empty() { Space::new() } else {
          let v220_6: Path = concat_path(&(v142_150_head),&(v217_6_head));
          let v220_11: Space = routine_22(c, &(v220_6), &(*p1), &(v217_6_tail));
          drop(v220_6);
          compose(&(v218_10),&(v220_11))
        };
        drop(v218_10);
        let v218_13: Space = unite(&(v218_8),&(v218_12));
        v217_6.join_into((v218_13).clone());
      }
      drop(v217_6_cursor);
      compose(&(v216_5),&(v217_6))
    };
    drop(v216_5);
    let v216_8: Space = intersect(&(*CONSTANT_7),&(v216_2));
    drop(v216_2);
    let v216_9: Space = if has_head(&(v216_8)) { singleton(&[]) } else { Space::new() };
    drop(v216_8);
    let v216_16: Space = if (v216_9).is_empty() { Space::new() } else {
      let v221_11: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v222_10: Space = routine_62(c, &(*CONSTANT_17), &(*CONSTANT_18));
        compose(&(*CONSTANT_0),&(v222_10))
      };
      let v221_12: Space = unwrap(&(v221_11),&(*p1));
      let v221_13: Space = unwrap(&(v221_12),&(v142_150_head));
      let v221_14: Space = unwrap(&(v221_13),&(*p1));
      let mut v221_15 = Space::new();
      let mut v221_15_cursor = (v221_14).read_zipper();
      for v221_15_byte in v221_15_cursor.child_mask().iter() {
        v221_15_cursor.descend_to_byte(v221_15_byte);
        let v221_15_tail = v221_15_cursor.make_map();
        v221_15_cursor.ascend(1);
        let v221_15_head = Path::from_slice(&[v221_15_byte]);
        let v223_2: Space = singleton(&(v221_15_head));
        let v223_3: Space = intersect(&(*CONSTANT_7),&(v223_2));
        let v223_4: Space = if has_head(&(v223_3)) { singleton(&[]) } else { Space::new() };
        drop(v223_3);
        let v223_5: Space = subtract(&(*CONSTANT_0),&(v223_4));
        drop(v223_4);
        let v223_7: Space = if (v223_5).is_empty() { Space::new() } else {
          let v224_6: Space = routine_63(c, &(v221_15_head), &(v221_15_tail), &(v142_150_tail));
          compose(&(v223_5),&(v224_6))
        };
        drop(v223_5);
        let v223_8: Space = intersect(&(*CONSTANT_7),&(v223_2));
        drop(v223_2);
        let v223_9: Space = if has_head(&(v223_8)) { singleton(&[]) } else { Space::new() };
        drop(v223_8);
        let v223_11: Space = if (v223_9).is_empty() { Space::new() } else {
          let v225_10: Space = routine_64(c, &(v221_15_head), &(v221_15_tail), &(v142_150_tail));
          compose(&(v223_9),&(v225_10))
        };
        drop(v223_9);
        let v223_12: Space = unite(&(v223_7),&(v223_11));
        v221_15.join_into((v223_12).clone());
      }
      drop(v221_15_cursor);
      compose(&(v216_9),&(v221_15))
    };
    drop(v216_9);
    let v216_17: Space = unite(&(v216_7),&(v216_16));
    v142_150.join_into((v216_17).clone());
  }
  drop(v142_150_cursor);
  (v142_150).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let (v226_11,v226_22,v226_3,v226_31,v226_42,v226_43,v226_52,v226_63,v226_64,v226_73,v226_84,v226_85,v226_94,) = native_block_1(c, p0, s0);
  let (v226_105,v226_106,v226_115,v226_126,v226_127,v226_136,v226_147,v226_148,v226_157,v226_168,v226_169,v226_178,v226_189,) = native_block_2(c, s0, &v226_3, &v226_85, &v226_94);
  drop(v226_3);
  let v226_190: Space = unite(&(v226_169),&(v226_189));
  (v226_190).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v362_12 = Space::new();
  let mut v362_12_cursor = (*s0).read_zipper();
  for v362_12_byte in v362_12_cursor.child_mask().iter() {
    v362_12_cursor.descend_to_byte(v362_12_byte);
    let v362_12_tail = v362_12_cursor.make_map();
    v362_12_cursor.ascend(1);
    let v362_12_head = Path::from_slice(&[v362_12_byte]);
    let v363_2: Space = singleton(&(v362_12_head));
    let v363_3: Space = intersect(&(*CONSTANT_7),&(v363_2));
    let v363_4: Space = if has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
    drop(v363_3);
    let v363_5: Space = subtract(&(*CONSTANT_0),&(v363_4));
    drop(v363_4);
    let v363_8: Space = if (v363_5).is_empty() { Space::new() } else {
      let v364_6: Path = concat_path(&(*p0),&(v362_12_head));
      let v364_7: Space = routine_19(c, &(v364_6), &(*p1), &(v362_12_tail));
      compose(&(v363_5),&(v364_7))
    };
    drop(v363_5);
    let v363_9: Space = intersect(&(*CONSTANT_7),&(v363_2));
    drop(v363_2);
    let v363_10: Space = if has_head(&(v363_9)) { singleton(&[]) } else { Space::new() };
    drop(v363_9);
    let v363_15: Space = if (v363_10).is_empty() { Space::new() } else {
      let v365_6: Path = concat_path(&(*p0),&(v362_12_head));
      let v365_12: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v366_11: Space = routine_59(c, &(*CONSTANT_17), &(*CONSTANT_18));
        compose(&(*CONSTANT_0),&(v366_11))
      };
      let v365_13: Space = unwrap(&(v365_12),&(*p1));
      let mut v365_14 = Space::new();
      let mut v365_14_cursor = (v365_13).read_zipper();
      for v365_14_byte in v365_14_cursor.child_mask().iter() {
        v365_14_cursor.descend_to_byte(v365_14_byte);
        let v365_14_tail = v365_14_cursor.make_map();
        v365_14_cursor.ascend(1);
        let v365_14_head = Path::from_slice(&[v365_14_byte]);
        let v367_2: Space = singleton(&(v365_14_head));
        let v367_3: Space = intersect(&(*CONSTANT_7),&(v367_2));
        let v367_4: Space = if has_head(&(v367_3)) { singleton(&[]) } else { Space::new() };
        drop(v367_3);
        let v367_5: Space = subtract(&(*CONSTANT_0),&(v367_4));
        drop(v367_4);
        let v367_7: Space = if (v367_5).is_empty() { Space::new() } else {
          let v368_6: Space = routine_60(c, &(v365_14_head), &(v365_6), &(v365_14_tail), &(v362_12_tail));
          compose(&(v367_5),&(v368_6))
        };
        drop(v367_5);
        let v367_8: Space = intersect(&(*CONSTANT_7),&(v367_2));
        drop(v367_2);
        let v367_9: Space = if has_head(&(v367_8)) { singleton(&[]) } else { Space::new() };
        drop(v367_8);
        let v367_11: Space = if (v367_9).is_empty() { Space::new() } else {
          let v369_10: Space = routine_61(c, &(v365_14_head), &(v365_6), &(v365_14_tail), &(v362_12_tail));
          compose(&(v367_9),&(v369_10))
        };
        drop(v367_9);
        let v367_12: Space = unite(&(v367_7),&(v367_11));
        v365_14.join_into((v367_12).clone());
      }
      drop(v365_14_cursor);
      drop(v365_6);
      compose(&(v363_10),&(v365_14))
    };
    drop(v363_10);
    let v363_16: Space = unite(&(v363_8),&(v363_15));
    v362_12.join_into((v363_16).clone());
  }
  drop(v362_12_cursor);
  (v362_12).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v370_17: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v371_16: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v372_7: Space = routine_59(c, &(*CONSTANT_1), &(*CONSTANT_19));
      let v372_10: Space = routine_59(c, &(*CONSTANT_3), &(*CONSTANT_20));
      let v372_11: Space = unite(&(v372_7),&(v372_10));
      let v372_14: Space = routine_59(c, &(*CONSTANT_5), &(*CONSTANT_21));
      let v372_15: Space = unite(&(v372_11),&(v372_14));
      compose(&(*CONSTANT_0),&(v372_15))
    };
    compose(&(*CONSTANT_0),&(v371_16))
  };
  let v370_18: Space = unwrap(&(v370_17),&(*p1));
  let mut v370_25 = Space::new();
  let mut v370_25_cursor = (v370_18).read_zipper();
  for v370_25_byte in v370_25_cursor.child_mask().iter() {
    v370_25_cursor.descend_to_byte(v370_25_byte);
    let v370_25_tail = v370_25_cursor.make_map();
    v370_25_cursor.ascend(1);
    let v370_25_head = Path::from_slice(&[v370_25_byte]);
    let v373_2: Space = singleton(&(v370_25_head));
    let v373_3: Space = intersect(&(*CONSTANT_7),&(v373_2));
    let v373_4: Space = if has_head(&(v373_3)) { singleton(&[]) } else { Space::new() };
    drop(v373_3);
    let v373_5: Space = subtract(&(*CONSTANT_0),&(v373_4));
    drop(v373_4);
    let v373_7: Space = if (v373_5).is_empty() { Space::new() } else {
      let mut v374_6 = Space::new();
      let mut v374_6_cursor = (v370_25_tail).read_zipper();
      for v374_6_byte in v374_6_cursor.child_mask().iter() {
        v374_6_cursor.descend_to_byte(v374_6_byte);
        let v374_6_tail = v374_6_cursor.make_map();
        v374_6_cursor.ascend(1);
        let v374_6_head = Path::from_slice(&[v374_6_byte]);
        let v375_2: Space = singleton(&(v374_6_head));
        let v375_3: Space = intersect(&(*CONSTANT_7),&(v375_2));
        let v375_4: Space = if has_head(&(v375_3)) { singleton(&[]) } else { Space::new() };
        drop(v375_3);
        let v375_5: Space = subtract(&(*CONSTANT_0),&(v375_4));
        drop(v375_4);
        let v375_8: Space = if (v375_5).is_empty() { Space::new() } else {
          let v376_6: Path = concat_path(&(v370_25_head),&(v374_6_head));
          let v376_7: Space = routine_60(c, &(v376_6), &(*p0), &(v374_6_tail), &(*s0));
          compose(&(v375_5),&(v376_7))
        };
        drop(v375_5);
        let v375_9: Space = intersect(&(*CONSTANT_7),&(v375_2));
        drop(v375_2);
        let v375_10: Space = if has_head(&(v375_9)) { singleton(&[]) } else { Space::new() };
        drop(v375_9);
        let v375_12: Space = if (v375_10).is_empty() { Space::new() } else {
          let v377_6: Path = concat_path(&(v370_25_head),&(v374_6_head));
          let v377_11: Space = routine_61(c, &(v377_6), &(*p0), &(v374_6_tail), &(*s0));
          drop(v377_6);
          compose(&(v375_10),&(v377_11))
        };
        drop(v375_10);
        let v375_13: Space = unite(&(v375_8),&(v375_12));
        v374_6.join_into((v375_13).clone());
      }
      drop(v374_6_cursor);
      compose(&(v373_5),&(v374_6))
    };
    drop(v373_5);
    let v373_8: Space = intersect(&(*CONSTANT_7),&(v373_2));
    drop(v373_2);
    let v373_9: Space = if has_head(&(v373_8)) { singleton(&[]) } else { Space::new() };
    drop(v373_8);
    let v373_13: Space = if (v373_9).is_empty() { Space::new() } else {
      let v378_10: Space = unwrap(&(v370_25_tail),&(*p0));
      let v378_11: Space = wrap(&(v378_10),&(v370_25_head));
      drop(v378_10);
      let v378_12: Space = compose(&(v378_11),&(*s0));
      drop(v378_11);
      compose(&(v373_9),&(v378_12))
    };
    drop(v373_9);
    let v373_14: Space = unite(&(v373_7),&(v373_13));
    drop(v373_13);
    v370_25.join_into((v373_14).clone());
  }
  drop(v370_25_cursor);
  (v370_25).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v379_12 = Space::new();
  let mut v379_12_cursor = (*s0).read_zipper();
  for v379_12_byte in v379_12_cursor.child_mask().iter() {
    v379_12_cursor.descend_to_byte(v379_12_byte);
    let v379_12_tail = v379_12_cursor.make_map();
    v379_12_cursor.ascend(1);
    let v379_12_head = Path::from_slice(&[v379_12_byte]);
    let v380_2: Space = singleton(&(v379_12_head));
    let v380_3: Space = intersect(&(*CONSTANT_7),&(v380_2));
    let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
    drop(v380_3);
    let v380_5: Space = subtract(&(*CONSTANT_0),&(v380_4));
    drop(v380_4);
    let v380_8: Space = if (v380_5).is_empty() { Space::new() } else {
      let v381_6: Path = concat_path(&(*p0),&(v379_12_head));
      let v381_7: Space = routine_21(c, &(v381_6), &(*p1), &(v379_12_tail));
      drop(v381_6);
      compose(&(v380_5),&(v381_7))
    };
    drop(v380_5);
    let v380_9: Space = intersect(&(*CONSTANT_7),&(v380_2));
    drop(v380_2);
    let v380_10: Space = if has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
    drop(v380_9);
    let v380_18: Space = if (v380_10).is_empty() { Space::new() } else {
      let v382_12: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v383_11: Space = routine_62(c, &(*CONSTANT_17), &(*CONSTANT_18));
        compose(&(*CONSTANT_0),&(v383_11))
      };
      let v382_13: Space = unwrap(&(v382_12),&(*p1));
      let v382_14: Space = unwrap(&(v382_13),&(*p0));
      let v382_15: Space = unwrap(&(v382_14),&(v379_12_head));
      let v382_16: Space = unwrap(&(v382_15),&(*p1));
      let mut v382_17 = Space::new();
      let mut v382_17_cursor = (v382_16).read_zipper();
      for v382_17_byte in v382_17_cursor.child_mask().iter() {
        v382_17_cursor.descend_to_byte(v382_17_byte);
        let v382_17_tail = v382_17_cursor.make_map();
        v382_17_cursor.ascend(1);
        let v382_17_head = Path::from_slice(&[v382_17_byte]);
        let v384_2: Space = singleton(&(v382_17_head));
        let v384_3: Space = intersect(&(*CONSTANT_7),&(v384_2));
        let v384_4: Space = if has_head(&(v384_3)) { singleton(&[]) } else { Space::new() };
        drop(v384_3);
        let v384_5: Space = subtract(&(*CONSTANT_0),&(v384_4));
        drop(v384_4);
        let v384_7: Space = if (v384_5).is_empty() { Space::new() } else {
          let v385_6: Space = routine_63(c, &(v382_17_head), &(v382_17_tail), &(v379_12_tail));
          compose(&(v384_5),&(v385_6))
        };
        drop(v384_5);
        let v384_8: Space = intersect(&(*CONSTANT_7),&(v384_2));
        drop(v384_2);
        let v384_9: Space = if has_head(&(v384_8)) { singleton(&[]) } else { Space::new() };
        drop(v384_8);
        let v384_11: Space = if (v384_9).is_empty() { Space::new() } else {
          let v386_10: Space = routine_64(c, &(v382_17_head), &(v382_17_tail), &(v379_12_tail));
          compose(&(v384_9),&(v386_10))
        };
        drop(v384_9);
        let v384_12: Space = unite(&(v384_7),&(v384_11));
        v382_17.join_into((v384_12).clone());
      }
      drop(v382_17_cursor);
      compose(&(v380_10),&(v382_17))
    };
    drop(v380_10);
    let v380_19: Space = unite(&(v380_8),&(v380_18));
    v379_12.join_into((v380_19).clone());
  }
  drop(v379_12_cursor);
  (v379_12).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v387_17: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v388_16: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v389_7: Space = routine_62(c, &(*CONSTANT_1), &(*CONSTANT_19));
      let v389_10: Space = routine_62(c, &(*CONSTANT_3), &(*CONSTANT_20));
      let v389_11: Space = unite(&(v389_7),&(v389_10));
      let v389_14: Space = routine_62(c, &(*CONSTANT_5), &(*CONSTANT_21));
      let v389_15: Space = unite(&(v389_11),&(v389_14));
      compose(&(*CONSTANT_0),&(v389_15))
    };
    compose(&(*CONSTANT_0),&(v388_16))
  };
  let v387_18: Space = unwrap(&(v387_17),&(*p1));
  let v387_19: Space = unwrap(&(v387_18),&(*p0));
  let v387_20: Space = unwrap(&(v387_19),&(*p1));
  let mut v387_27 = Space::new();
  let mut v387_27_cursor = (v387_20).read_zipper();
  for v387_27_byte in v387_27_cursor.child_mask().iter() {
    v387_27_cursor.descend_to_byte(v387_27_byte);
    let v387_27_tail = v387_27_cursor.make_map();
    v387_27_cursor.ascend(1);
    let v387_27_head = Path::from_slice(&[v387_27_byte]);
    let v390_2: Space = singleton(&(v387_27_head));
    let v390_3: Space = intersect(&(*CONSTANT_7),&(v390_2));
    let v390_4: Space = if has_head(&(v390_3)) { singleton(&[]) } else { Space::new() };
    drop(v390_3);
    let v390_5: Space = subtract(&(*CONSTANT_0),&(v390_4));
    drop(v390_4);
    let v390_7: Space = if (v390_5).is_empty() { Space::new() } else {
      let mut v391_6 = Space::new();
      let mut v391_6_cursor = (v387_27_tail).read_zipper();
      for v391_6_byte in v391_6_cursor.child_mask().iter() {
        v391_6_cursor.descend_to_byte(v391_6_byte);
        let v391_6_tail = v391_6_cursor.make_map();
        v391_6_cursor.ascend(1);
        let v391_6_head = Path::from_slice(&[v391_6_byte]);
        let v392_2: Space = singleton(&(v391_6_head));
        let v392_3: Space = intersect(&(*CONSTANT_7),&(v392_2));
        let v392_4: Space = if has_head(&(v392_3)) { singleton(&[]) } else { Space::new() };
        drop(v392_3);
        let v392_5: Space = subtract(&(*CONSTANT_0),&(v392_4));
        drop(v392_4);
        let v392_8: Space = if (v392_5).is_empty() { Space::new() } else {
          let v393_6: Path = concat_path(&(v387_27_head),&(v391_6_head));
          let v393_7: Space = routine_63(c, &(v393_6), &(v391_6_tail), &(*s0));
          compose(&(v392_5),&(v393_7))
        };
        drop(v392_5);
        let v392_9: Space = intersect(&(*CONSTANT_7),&(v392_2));
        drop(v392_2);
        let v392_10: Space = if has_head(&(v392_9)) { singleton(&[]) } else { Space::new() };
        drop(v392_9);
        let v392_12: Space = if (v392_10).is_empty() { Space::new() } else {
          let v394_6: Path = concat_path(&(v387_27_head),&(v391_6_head));
          let v394_11: Space = routine_64(c, &(v394_6), &(v391_6_tail), &(*s0));
          drop(v394_6);
          compose(&(v392_10),&(v394_11))
        };
        drop(v392_10);
        let v392_13: Space = unite(&(v392_8),&(v392_12));
        v391_6.join_into((v392_13).clone());
      }
      drop(v391_6_cursor);
      compose(&(v390_5),&(v391_6))
    };
    drop(v390_5);
    let v390_8: Space = intersect(&(*CONSTANT_7),&(v390_2));
    drop(v390_2);
    let v390_9: Space = if has_head(&(v390_8)) { singleton(&[]) } else { Space::new() };
    drop(v390_8);
    let v390_11: Space = if (v390_9).is_empty() { Space::new() } else {
      let v395_10: Space = routine_83(c, &(v387_27_head), &(*s0));
      compose(&(v390_9),&(v395_10))
    };
    drop(v390_9);
    let v390_12: Space = unite(&(v390_7),&(v390_11));
    v387_27.join_into((v390_12).clone());
  }
  drop(v387_27_cursor);
  (v387_27).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v396_5 = Space::new();
  let mut v396_5_cursor = (*s0).read_zipper();
  for v396_5_byte in v396_5_cursor.child_mask().iter() {
    v396_5_cursor.descend_to_byte(v396_5_byte);
    let v396_5_tail = v396_5_cursor.make_map();
    v396_5_cursor.ascend(1);
    let v396_5_head = Path::from_slice(&[v396_5_byte]);
    let v397_2: Space = singleton(&(v396_5_head));
    let v397_3: Space = intersect(&(*CONSTANT_7),&(v397_2));
    let v397_4: Space = if has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
    drop(v397_3);
    let v397_5: Space = subtract(&(*CONSTANT_0),&(v397_4));
    drop(v397_4);
    let v397_8: Space = if (v397_5).is_empty() { Space::new() } else {
      let v398_6: Path = concat_path(&(*p0),&(v396_5_head));
      let v398_7: Space = routine_23(c, &(v398_6), &(v396_5_tail));
      drop(v398_6);
      compose(&(v397_5),&(v398_7))
    };
    drop(v397_5);
    let v397_9: Space = intersect(&(*CONSTANT_7),&(v397_2));
    drop(v397_2);
    let v397_10: Space = if has_head(&(v397_9)) { singleton(&[]) } else { Space::new() };
    drop(v397_9);
    let v397_11: Space = compose(&(v397_10),&(v396_5_tail));
    drop(v397_10);
    let v397_12: Space = unite(&(v397_8),&(v397_11));
    drop(v397_11);
    v396_5.join_into((v397_12).clone());
  }
  drop(v396_5_cursor);
  (v396_5).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v400_8 = Space::new();
  let mut v400_8_cursor = (*s0).read_zipper();
  for v400_8_byte in v400_8_cursor.child_mask().iter() {
    v400_8_cursor.descend_to_byte(v400_8_byte);
    let v400_8_tail = v400_8_cursor.make_map();
    v400_8_cursor.ascend(1);
    let v400_8_head = Path::from_slice(&[v400_8_byte]);
    let v401_2: Space = singleton(&(v400_8_head));
    let v401_3: Space = intersect(&(*CONSTANT_7),&(v401_2));
    let v401_4: Space = if has_head(&(v401_3)) { singleton(&[]) } else { Space::new() };
    drop(v401_3);
    let v401_5: Space = subtract(&(*CONSTANT_0),&(v401_4));
    drop(v401_4);
    let v401_8: Space = if (v401_5).is_empty() { Space::new() } else {
      let v402_6: Path = concat_path(&(*p0),&(v400_8_head));
      let v402_7: Space = routine_25(c, &(v402_6), &(v400_8_tail));
      compose(&(v401_5),&(v402_7))
    };
    drop(v401_5);
    let v401_9: Space = intersect(&(*CONSTANT_7),&(v401_2));
    drop(v401_2);
    let v401_10: Space = if has_head(&(v401_9)) { singleton(&[]) } else { Space::new() };
    drop(v401_9);
    let v401_12: Space = if (v401_10).is_empty() { Space::new() } else {
      let v403_6: Path = concat_path(&(*p0),&(v400_8_head));
      let mut v403_11 = Space::new();
      let mut v403_11_cursor = (v400_8_tail).read_zipper();
      for v403_11_byte in v403_11_cursor.child_mask().iter() {
        v403_11_cursor.descend_to_byte(v403_11_byte);
        let v403_11_tail = v403_11_cursor.make_map();
        v403_11_cursor.ascend(1);
        let v403_11_head = Path::from_slice(&[v403_11_byte]);
        let v404_2: Space = singleton(&(v403_11_head));
        let v404_3: Space = intersect(&(*CONSTANT_7),&(v404_2));
        let v404_4: Space = if has_head(&(v404_3)) { singleton(&[]) } else { Space::new() };
        drop(v404_3);
        let v404_5: Space = subtract(&(*CONSTANT_0),&(v404_4));
        drop(v404_4);
        let v404_7: Space = if (v404_5).is_empty() { Space::new() } else {
          let v405_6: Space = routine_65(c, &(v403_11_head), &(v403_6), &(v403_11_tail));
          compose(&(v404_5),&(v405_6))
        };
        drop(v404_5);
        let v404_8: Space = intersect(&(*CONSTANT_7),&(v404_2));
        drop(v404_2);
        let v404_9: Space = if has_head(&(v404_8)) { singleton(&[]) } else { Space::new() };
        drop(v404_8);
        let v404_11: Space = if (v404_9).is_empty() { Space::new() } else {
          let v406_10: Space = routine_66(c, &(v403_11_head), &(v403_6), &(v403_11_tail));
          compose(&(v404_9),&(v406_10))
        };
        drop(v404_9);
        let v404_12: Space = unite(&(v404_7),&(v404_11));
        v403_11.join_into((v404_12).clone());
      }
      drop(v403_11_cursor);
      drop(v403_6);
      compose(&(v401_10),&(v403_11))
    };
    drop(v401_10);
    let v401_13: Space = unite(&(v401_8),&(v401_12));
    v400_8.join_into((v401_13).clone());
  }
  drop(v400_8_cursor);
  (v400_8).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v407_11 = Space::new();
  let mut v407_11_cursor = (*s0).read_zipper();
  for v407_11_byte in v407_11_cursor.child_mask().iter() {
    v407_11_cursor.descend_to_byte(v407_11_byte);
    let v407_11_tail = v407_11_cursor.make_map();
    v407_11_cursor.ascend(1);
    let v407_11_head = Path::from_slice(&[v407_11_byte]);
    let v408_2: Space = singleton(&(v407_11_head));
    let v408_3: Space = intersect(&(*CONSTANT_7),&(v408_2));
    let v408_4: Space = if has_head(&(v408_3)) { singleton(&[]) } else { Space::new() };
    drop(v408_3);
    let v408_5: Space = subtract(&(*CONSTANT_0),&(v408_4));
    drop(v408_4);
    let v408_7: Space = if (v408_5).is_empty() { Space::new() } else {
      let mut v409_6 = Space::new();
      let mut v409_6_cursor = (v407_11_tail).read_zipper();
      for v409_6_byte in v409_6_cursor.child_mask().iter() {
        v409_6_cursor.descend_to_byte(v409_6_byte);
        let v409_6_tail = v409_6_cursor.make_map();
        v409_6_cursor.ascend(1);
        let v409_6_head = Path::from_slice(&[v409_6_byte]);
        let v410_2: Space = singleton(&(v409_6_head));
        let v410_3: Space = intersect(&(*CONSTANT_7),&(v410_2));
        let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
        drop(v410_3);
        let v410_5: Space = subtract(&(*CONSTANT_0),&(v410_4));
        drop(v410_4);
        let v410_8: Space = if (v410_5).is_empty() { Space::new() } else {
          let v411_6: Path = concat_path(&(v407_11_head),&(v409_6_head));
          let v411_7: Space = routine_65(c, &(v411_6), &(*p0), &(v409_6_tail));
          compose(&(v410_5),&(v411_7))
        };
        drop(v410_5);
        let v410_9: Space = intersect(&(*CONSTANT_7),&(v410_2));
        drop(v410_2);
        let v410_10: Space = if has_head(&(v410_9)) { singleton(&[]) } else { Space::new() };
        drop(v410_9);
        let v410_12: Space = if (v410_10).is_empty() { Space::new() } else {
          let v412_6: Path = concat_path(&(v407_11_head),&(v409_6_head));
          let v412_11: Space = routine_66(c, &(v412_6), &(*p0), &(v409_6_tail));
          drop(v412_6);
          compose(&(v410_10),&(v412_11))
        };
        drop(v410_10);
        let v410_13: Space = unite(&(v410_8),&(v410_12));
        v409_6.join_into((v410_13).clone());
      }
      drop(v409_6_cursor);
      compose(&(v408_5),&(v409_6))
    };
    drop(v408_5);
    let v408_8: Space = intersect(&(*CONSTANT_7),&(v408_2));
    drop(v408_2);
    let v408_9: Space = if has_head(&(v408_8)) { singleton(&[]) } else { Space::new() };
    drop(v408_8);
    let v408_11: Space = if (v408_9).is_empty() { Space::new() } else {
      let mut v413_10 = Space::new();
      let mut v413_10_cursor = (v407_11_tail).read_zipper();
      for v413_10_byte in v413_10_cursor.child_mask().iter() {
        v413_10_cursor.descend_to_byte(v413_10_byte);
        let v413_10_tail = v413_10_cursor.make_map();
        v413_10_cursor.ascend(1);
        let v413_10_head = Path::from_slice(&[v413_10_byte]);
        let v414_2: Space = singleton(&(v413_10_head));
        let v414_3: Space = intersect(&(*CONSTANT_7),&(v414_2));
        let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
        drop(v414_3);
        let v414_5: Space = subtract(&(*CONSTANT_0),&(v414_4));
        drop(v414_4);
        let v414_7: Space = if (v414_5).is_empty() { Space::new() } else {
          let v415_6: Space = routine_84(c, &(v413_10_head), &(*p0), &(v407_11_head), &(v413_10_tail));
          compose(&(v414_5),&(v415_6))
        };
        drop(v414_5);
        let v414_8: Space = intersect(&(*CONSTANT_7),&(v414_2));
        drop(v414_2);
        let v414_9: Space = if has_head(&(v414_8)) { singleton(&[]) } else { Space::new() };
        drop(v414_8);
        let v414_11: Space = if (v414_9).is_empty() { Space::new() } else {
          let v416_10: Space = routine_85(c, &(v413_10_head), &(*p0), &(v407_11_head), &(v413_10_tail));
          compose(&(v414_9),&(v416_10))
        };
        drop(v414_9);
        let v414_12: Space = unite(&(v414_7),&(v414_11));
        v413_10.join_into((v414_12).clone());
      }
      drop(v413_10_cursor);
      compose(&(v408_9),&(v413_10))
    };
    drop(v408_9);
    let v408_12: Space = unite(&(v408_7),&(v408_11));
    v407_11.join_into((v408_12).clone());
  }
  drop(v407_11_cursor);
  (v407_11).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v417_5 = Space::new();
  let mut v417_5_cursor = (*s0).read_zipper();
  for v417_5_byte in v417_5_cursor.child_mask().iter() {
    v417_5_cursor.descend_to_byte(v417_5_byte);
    let v417_5_tail = v417_5_cursor.make_map();
    v417_5_cursor.ascend(1);
    let v417_5_head = Path::from_slice(&[v417_5_byte]);
    let v418_2: Space = singleton(&(v417_5_head));
    let v418_3: Space = intersect(&(*CONSTANT_7),&(v418_2));
    let v418_4: Space = if has_head(&(v418_3)) { singleton(&[]) } else { Space::new() };
    drop(v418_3);
    let v418_5: Space = subtract(&(*CONSTANT_0),&(v418_4));
    drop(v418_4);
    let v418_8: Space = if (v418_5).is_empty() { Space::new() } else {
      let v419_6: Path = concat_path(&(*p0),&(v417_5_head));
      let v419_7: Space = routine_27(c, &(v419_6), &(v417_5_tail));
      drop(v419_6);
      compose(&(v418_5),&(v419_7))
    };
    drop(v418_5);
    let v418_9: Space = intersect(&(*CONSTANT_7),&(v418_2));
    drop(v418_2);
    let v418_10: Space = if has_head(&(v418_9)) { singleton(&[]) } else { Space::new() };
    drop(v418_9);
    let v418_11: Space = compose(&(v418_10),&(v417_5_tail));
    drop(v418_10);
    let v418_12: Space = unite(&(v418_8),&(v418_11));
    drop(v418_11);
    v417_5.join_into((v418_12).clone());
  }
  drop(v417_5_cursor);
  (v417_5).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v421_8 = Space::new();
  let mut v421_8_cursor = (*s0).read_zipper();
  for v421_8_byte in v421_8_cursor.child_mask().iter() {
    v421_8_cursor.descend_to_byte(v421_8_byte);
    let v421_8_tail = v421_8_cursor.make_map();
    v421_8_cursor.ascend(1);
    let v421_8_head = Path::from_slice(&[v421_8_byte]);
    let v422_2: Space = singleton(&(v421_8_head));
    let v422_3: Space = intersect(&(*CONSTANT_7),&(v422_2));
    let v422_4: Space = if has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
    drop(v422_3);
    let v422_5: Space = subtract(&(*CONSTANT_0),&(v422_4));
    drop(v422_4);
    let v422_8: Space = if (v422_5).is_empty() { Space::new() } else {
      let v423_6: Path = concat_path(&(*p0),&(v421_8_head));
      let v423_7: Space = routine_29(c, &(v423_6), &(v421_8_tail));
      compose(&(v422_5),&(v423_7))
    };
    drop(v422_5);
    let v422_9: Space = intersect(&(*CONSTANT_7),&(v422_2));
    drop(v422_2);
    let v422_10: Space = if has_head(&(v422_9)) { singleton(&[]) } else { Space::new() };
    drop(v422_9);
    let v422_12: Space = if (v422_10).is_empty() { Space::new() } else {
      let v424_6: Path = concat_path(&(*p0),&(v421_8_head));
      let mut v424_11 = Space::new();
      let mut v424_11_cursor = (v421_8_tail).read_zipper();
      for v424_11_byte in v424_11_cursor.child_mask().iter() {
        v424_11_cursor.descend_to_byte(v424_11_byte);
        let v424_11_tail = v424_11_cursor.make_map();
        v424_11_cursor.ascend(1);
        let v424_11_head = Path::from_slice(&[v424_11_byte]);
        let v425_2: Space = singleton(&(v424_11_head));
        let v425_3: Space = intersect(&(*CONSTANT_7),&(v425_2));
        let v425_4: Space = if has_head(&(v425_3)) { singleton(&[]) } else { Space::new() };
        drop(v425_3);
        let v425_5: Space = subtract(&(*CONSTANT_0),&(v425_4));
        drop(v425_4);
        let v425_7: Space = if (v425_5).is_empty() { Space::new() } else {
          let v426_6: Space = routine_67(c, &(v424_11_head), &(v424_6), &(v424_11_tail));
          compose(&(v425_5),&(v426_6))
        };
        drop(v425_5);
        let v425_8: Space = intersect(&(*CONSTANT_7),&(v425_2));
        drop(v425_2);
        let v425_9: Space = if has_head(&(v425_8)) { singleton(&[]) } else { Space::new() };
        drop(v425_8);
        let v425_11: Space = if (v425_9).is_empty() { Space::new() } else {
          let v427_10: Space = routine_68(c, &(v424_11_head), &(v424_6), &(v424_11_tail));
          compose(&(v425_9),&(v427_10))
        };
        drop(v425_9);
        let v425_12: Space = unite(&(v425_7),&(v425_11));
        v424_11.join_into((v425_12).clone());
      }
      drop(v424_11_cursor);
      drop(v424_6);
      compose(&(v422_10),&(v424_11))
    };
    drop(v422_10);
    let v422_13: Space = unite(&(v422_8),&(v422_12));
    v421_8.join_into((v422_13).clone());
  }
  drop(v421_8_cursor);
  (v421_8).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v428_11 = Space::new();
  let mut v428_11_cursor = (*s0).read_zipper();
  for v428_11_byte in v428_11_cursor.child_mask().iter() {
    v428_11_cursor.descend_to_byte(v428_11_byte);
    let v428_11_tail = v428_11_cursor.make_map();
    v428_11_cursor.ascend(1);
    let v428_11_head = Path::from_slice(&[v428_11_byte]);
    let v429_2: Space = singleton(&(v428_11_head));
    let v429_3: Space = intersect(&(*CONSTANT_7),&(v429_2));
    let v429_4: Space = if has_head(&(v429_3)) { singleton(&[]) } else { Space::new() };
    drop(v429_3);
    let v429_5: Space = subtract(&(*CONSTANT_0),&(v429_4));
    drop(v429_4);
    let v429_7: Space = if (v429_5).is_empty() { Space::new() } else {
      let mut v430_6 = Space::new();
      let mut v430_6_cursor = (v428_11_tail).read_zipper();
      for v430_6_byte in v430_6_cursor.child_mask().iter() {
        v430_6_cursor.descend_to_byte(v430_6_byte);
        let v430_6_tail = v430_6_cursor.make_map();
        v430_6_cursor.ascend(1);
        let v430_6_head = Path::from_slice(&[v430_6_byte]);
        let v431_2: Space = singleton(&(v430_6_head));
        let v431_3: Space = intersect(&(*CONSTANT_7),&(v431_2));
        let v431_4: Space = if has_head(&(v431_3)) { singleton(&[]) } else { Space::new() };
        drop(v431_3);
        let v431_5: Space = subtract(&(*CONSTANT_0),&(v431_4));
        drop(v431_4);
        let v431_8: Space = if (v431_5).is_empty() { Space::new() } else {
          let v432_6: Path = concat_path(&(v428_11_head),&(v430_6_head));
          let v432_7: Space = routine_67(c, &(v432_6), &(*p0), &(v430_6_tail));
          compose(&(v431_5),&(v432_7))
        };
        drop(v431_5);
        let v431_9: Space = intersect(&(*CONSTANT_7),&(v431_2));
        drop(v431_2);
        let v431_10: Space = if has_head(&(v431_9)) { singleton(&[]) } else { Space::new() };
        drop(v431_9);
        let v431_12: Space = if (v431_10).is_empty() { Space::new() } else {
          let v433_6: Path = concat_path(&(v428_11_head),&(v430_6_head));
          let v433_11: Space = routine_68(c, &(v433_6), &(*p0), &(v430_6_tail));
          drop(v433_6);
          compose(&(v431_10),&(v433_11))
        };
        drop(v431_10);
        let v431_13: Space = unite(&(v431_8),&(v431_12));
        v430_6.join_into((v431_13).clone());
      }
      drop(v430_6_cursor);
      compose(&(v429_5),&(v430_6))
    };
    drop(v429_5);
    let v429_8: Space = intersect(&(*CONSTANT_7),&(v429_2));
    drop(v429_2);
    let v429_9: Space = if has_head(&(v429_8)) { singleton(&[]) } else { Space::new() };
    drop(v429_8);
    let v429_11: Space = if (v429_9).is_empty() { Space::new() } else {
      let mut v434_10 = Space::new();
      let mut v434_10_cursor = (v428_11_tail).read_zipper();
      for v434_10_byte in v434_10_cursor.child_mask().iter() {
        v434_10_cursor.descend_to_byte(v434_10_byte);
        let v434_10_tail = v434_10_cursor.make_map();
        v434_10_cursor.ascend(1);
        let v434_10_head = Path::from_slice(&[v434_10_byte]);
        let v435_2: Space = singleton(&(v434_10_head));
        let v435_3: Space = intersect(&(*CONSTANT_7),&(v435_2));
        let v435_4: Space = if has_head(&(v435_3)) { singleton(&[]) } else { Space::new() };
        drop(v435_3);
        let v435_5: Space = subtract(&(*CONSTANT_0),&(v435_4));
        drop(v435_4);
        let v435_7: Space = if (v435_5).is_empty() { Space::new() } else {
          let v436_6: Space = routine_86(c, &(v434_10_head), &(*p0), &(v428_11_head), &(v434_10_tail));
          compose(&(v435_5),&(v436_6))
        };
        drop(v435_5);
        let v435_8: Space = intersect(&(*CONSTANT_7),&(v435_2));
        drop(v435_2);
        let v435_9: Space = if has_head(&(v435_8)) { singleton(&[]) } else { Space::new() };
        drop(v435_8);
        let v435_11: Space = if (v435_9).is_empty() { Space::new() } else {
          let v437_10: Space = routine_87(c, &(v434_10_head), &(*p0), &(v428_11_head), &(v434_10_tail));
          compose(&(v435_9),&(v437_10))
        };
        drop(v435_9);
        let v435_12: Space = unite(&(v435_7),&(v435_11));
        v434_10.join_into((v435_12).clone());
      }
      drop(v434_10_cursor);
      compose(&(v429_9),&(v434_10))
    };
    drop(v429_9);
    let v429_12: Space = unite(&(v429_7),&(v429_11));
    v428_11.join_into((v429_12).clone());
  }
  drop(v428_11_cursor);
  (v428_11).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v438_5 = Space::new();
  let mut v438_5_cursor = (*s0).read_zipper();
  for v438_5_byte in v438_5_cursor.child_mask().iter() {
    v438_5_cursor.descend_to_byte(v438_5_byte);
    let v438_5_tail = v438_5_cursor.make_map();
    v438_5_cursor.ascend(1);
    let v438_5_head = Path::from_slice(&[v438_5_byte]);
    let v439_2: Space = singleton(&(v438_5_head));
    let v439_3: Space = intersect(&(*CONSTANT_7),&(v439_2));
    let v439_4: Space = if has_head(&(v439_3)) { singleton(&[]) } else { Space::new() };
    drop(v439_3);
    let v439_5: Space = subtract(&(*CONSTANT_0),&(v439_4));
    drop(v439_4);
    let v439_8: Space = if (v439_5).is_empty() { Space::new() } else {
      let v440_6: Path = concat_path(&(*p0),&(v438_5_head));
      let v440_7: Space = routine_31(c, &(v440_6), &(v438_5_tail));
      drop(v440_6);
      compose(&(v439_5),&(v440_7))
    };
    drop(v439_5);
    let v439_9: Space = intersect(&(*CONSTANT_7),&(v439_2));
    drop(v439_2);
    let v439_10: Space = if has_head(&(v439_9)) { singleton(&[]) } else { Space::new() };
    drop(v439_9);
    let v439_11: Space = compose(&(v439_10),&(v438_5_tail));
    drop(v439_10);
    let v439_12: Space = unite(&(v439_8),&(v439_11));
    drop(v439_11);
    v438_5.join_into((v439_12).clone());
  }
  drop(v438_5_cursor);
  (v438_5).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v442_8 = Space::new();
  let mut v442_8_cursor = (*s0).read_zipper();
  for v442_8_byte in v442_8_cursor.child_mask().iter() {
    v442_8_cursor.descend_to_byte(v442_8_byte);
    let v442_8_tail = v442_8_cursor.make_map();
    v442_8_cursor.ascend(1);
    let v442_8_head = Path::from_slice(&[v442_8_byte]);
    let v443_2: Space = singleton(&(v442_8_head));
    let v443_3: Space = intersect(&(*CONSTANT_7),&(v443_2));
    let v443_4: Space = if has_head(&(v443_3)) { singleton(&[]) } else { Space::new() };
    drop(v443_3);
    let v443_5: Space = subtract(&(*CONSTANT_0),&(v443_4));
    drop(v443_4);
    let v443_8: Space = if (v443_5).is_empty() { Space::new() } else {
      let v444_6: Path = concat_path(&(*p0),&(v442_8_head));
      let v444_7: Space = routine_33(c, &(v444_6), &(v442_8_tail));
      compose(&(v443_5),&(v444_7))
    };
    drop(v443_5);
    let v443_9: Space = intersect(&(*CONSTANT_7),&(v443_2));
    drop(v443_2);
    let v443_10: Space = if has_head(&(v443_9)) { singleton(&[]) } else { Space::new() };
    drop(v443_9);
    let v443_12: Space = if (v443_10).is_empty() { Space::new() } else {
      let v445_6: Path = concat_path(&(*p0),&(v442_8_head));
      let mut v445_11 = Space::new();
      let mut v445_11_cursor = (v442_8_tail).read_zipper();
      for v445_11_byte in v445_11_cursor.child_mask().iter() {
        v445_11_cursor.descend_to_byte(v445_11_byte);
        let v445_11_tail = v445_11_cursor.make_map();
        v445_11_cursor.ascend(1);
        let v445_11_head = Path::from_slice(&[v445_11_byte]);
        let v446_2: Space = singleton(&(v445_11_head));
        let v446_3: Space = intersect(&(*CONSTANT_7),&(v446_2));
        let v446_4: Space = if has_head(&(v446_3)) { singleton(&[]) } else { Space::new() };
        drop(v446_3);
        let v446_5: Space = subtract(&(*CONSTANT_0),&(v446_4));
        drop(v446_4);
        let v446_7: Space = if (v446_5).is_empty() { Space::new() } else {
          let v447_6: Space = routine_69(c, &(v445_11_head), &(v445_6), &(v445_11_tail));
          compose(&(v446_5),&(v447_6))
        };
        drop(v446_5);
        let v446_8: Space = intersect(&(*CONSTANT_7),&(v446_2));
        drop(v446_2);
        let v446_9: Space = if has_head(&(v446_8)) { singleton(&[]) } else { Space::new() };
        drop(v446_8);
        let v446_11: Space = if (v446_9).is_empty() { Space::new() } else {
          let v448_10: Space = routine_70(c, &(v445_11_head), &(v445_6), &(v445_11_tail));
          compose(&(v446_9),&(v448_10))
        };
        drop(v446_9);
        let v446_12: Space = unite(&(v446_7),&(v446_11));
        v445_11.join_into((v446_12).clone());
      }
      drop(v445_11_cursor);
      drop(v445_6);
      compose(&(v443_10),&(v445_11))
    };
    drop(v443_10);
    let v443_13: Space = unite(&(v443_8),&(v443_12));
    v442_8.join_into((v443_13).clone());
  }
  drop(v442_8_cursor);
  (v442_8).clone()
}

fn routine_34(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v449_11 = Space::new();
  let mut v449_11_cursor = (*s0).read_zipper();
  for v449_11_byte in v449_11_cursor.child_mask().iter() {
    v449_11_cursor.descend_to_byte(v449_11_byte);
    let v449_11_tail = v449_11_cursor.make_map();
    v449_11_cursor.ascend(1);
    let v449_11_head = Path::from_slice(&[v449_11_byte]);
    let v450_2: Space = singleton(&(v449_11_head));
    let v450_3: Space = intersect(&(*CONSTANT_7),&(v450_2));
    let v450_4: Space = if has_head(&(v450_3)) { singleton(&[]) } else { Space::new() };
    drop(v450_3);
    let v450_5: Space = subtract(&(*CONSTANT_0),&(v450_4));
    drop(v450_4);
    let v450_7: Space = if (v450_5).is_empty() { Space::new() } else {
      let mut v451_6 = Space::new();
      let mut v451_6_cursor = (v449_11_tail).read_zipper();
      for v451_6_byte in v451_6_cursor.child_mask().iter() {
        v451_6_cursor.descend_to_byte(v451_6_byte);
        let v451_6_tail = v451_6_cursor.make_map();
        v451_6_cursor.ascend(1);
        let v451_6_head = Path::from_slice(&[v451_6_byte]);
        let v452_2: Space = singleton(&(v451_6_head));
        let v452_3: Space = intersect(&(*CONSTANT_7),&(v452_2));
        let v452_4: Space = if has_head(&(v452_3)) { singleton(&[]) } else { Space::new() };
        drop(v452_3);
        let v452_5: Space = subtract(&(*CONSTANT_0),&(v452_4));
        drop(v452_4);
        let v452_8: Space = if (v452_5).is_empty() { Space::new() } else {
          let v453_6: Path = concat_path(&(v449_11_head),&(v451_6_head));
          let v453_7: Space = routine_69(c, &(v453_6), &(*p0), &(v451_6_tail));
          compose(&(v452_5),&(v453_7))
        };
        drop(v452_5);
        let v452_9: Space = intersect(&(*CONSTANT_7),&(v452_2));
        drop(v452_2);
        let v452_10: Space = if has_head(&(v452_9)) { singleton(&[]) } else { Space::new() };
        drop(v452_9);
        let v452_12: Space = if (v452_10).is_empty() { Space::new() } else {
          let v454_6: Path = concat_path(&(v449_11_head),&(v451_6_head));
          let v454_11: Space = routine_70(c, &(v454_6), &(*p0), &(v451_6_tail));
          drop(v454_6);
          compose(&(v452_10),&(v454_11))
        };
        drop(v452_10);
        let v452_13: Space = unite(&(v452_8),&(v452_12));
        v451_6.join_into((v452_13).clone());
      }
      drop(v451_6_cursor);
      compose(&(v450_5),&(v451_6))
    };
    drop(v450_5);
    let v450_8: Space = intersect(&(*CONSTANT_7),&(v450_2));
    drop(v450_2);
    let v450_9: Space = if has_head(&(v450_8)) { singleton(&[]) } else { Space::new() };
    drop(v450_8);
    let v450_11: Space = if (v450_9).is_empty() { Space::new() } else {
      let mut v455_10 = Space::new();
      let mut v455_10_cursor = (v449_11_tail).read_zipper();
      for v455_10_byte in v455_10_cursor.child_mask().iter() {
        v455_10_cursor.descend_to_byte(v455_10_byte);
        let v455_10_tail = v455_10_cursor.make_map();
        v455_10_cursor.ascend(1);
        let v455_10_head = Path::from_slice(&[v455_10_byte]);
        let v456_2: Space = singleton(&(v455_10_head));
        let v456_3: Space = intersect(&(*CONSTANT_7),&(v456_2));
        let v456_4: Space = if has_head(&(v456_3)) { singleton(&[]) } else { Space::new() };
        drop(v456_3);
        let v456_5: Space = subtract(&(*CONSTANT_0),&(v456_4));
        drop(v456_4);
        let v456_7: Space = if (v456_5).is_empty() { Space::new() } else {
          let v457_6: Space = routine_88(c, &(v455_10_head), &(*p0), &(v449_11_head), &(v455_10_tail));
          compose(&(v456_5),&(v457_6))
        };
        drop(v456_5);
        let v456_8: Space = intersect(&(*CONSTANT_7),&(v456_2));
        drop(v456_2);
        let v456_9: Space = if has_head(&(v456_8)) { singleton(&[]) } else { Space::new() };
        drop(v456_8);
        let v456_11: Space = if (v456_9).is_empty() { Space::new() } else {
          let v458_10: Space = routine_89(c, &(v455_10_head), &(*p0), &(v449_11_head), &(v455_10_tail));
          compose(&(v456_9),&(v458_10))
        };
        drop(v456_9);
        let v456_12: Space = unite(&(v456_7),&(v456_11));
        v455_10.join_into((v456_12).clone());
      }
      drop(v455_10_cursor);
      compose(&(v450_9),&(v455_10))
    };
    drop(v450_9);
    let v450_12: Space = unite(&(v450_7),&(v450_11));
    v449_11.join_into((v450_12).clone());
  }
  drop(v449_11_cursor);
  (v449_11).clone()
}

fn routine_35(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v459_5 = Space::new();
  let mut v459_5_cursor = (*s0).read_zipper();
  for v459_5_byte in v459_5_cursor.child_mask().iter() {
    v459_5_cursor.descend_to_byte(v459_5_byte);
    let v459_5_tail = v459_5_cursor.make_map();
    v459_5_cursor.ascend(1);
    let v459_5_head = Path::from_slice(&[v459_5_byte]);
    let v460_2: Space = singleton(&(v459_5_head));
    let v460_3: Space = intersect(&(*CONSTANT_7),&(v460_2));
    let v460_4: Space = if has_head(&(v460_3)) { singleton(&[]) } else { Space::new() };
    drop(v460_3);
    let v460_5: Space = subtract(&(*CONSTANT_0),&(v460_4));
    drop(v460_4);
    let v460_8: Space = if (v460_5).is_empty() { Space::new() } else {
      let v461_6: Path = concat_path(&(*p0),&(v459_5_head));
      let v461_7: Space = routine_35(c, &(v461_6), &(v459_5_tail));
      drop(v461_6);
      compose(&(v460_5),&(v461_7))
    };
    drop(v460_5);
    let v460_9: Space = intersect(&(*CONSTANT_7),&(v460_2));
    drop(v460_2);
    let v460_10: Space = if has_head(&(v460_9)) { singleton(&[]) } else { Space::new() };
    drop(v460_9);
    let v460_11: Space = compose(&(v460_10),&(v459_5_tail));
    drop(v460_10);
    let v460_12: Space = unite(&(v460_8),&(v460_11));
    drop(v460_11);
    v459_5.join_into((v460_12).clone());
  }
  drop(v459_5_cursor);
  (v459_5).clone()
}

fn routine_36(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_37(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v463_8 = Space::new();
  let mut v463_8_cursor = (*s0).read_zipper();
  for v463_8_byte in v463_8_cursor.child_mask().iter() {
    v463_8_cursor.descend_to_byte(v463_8_byte);
    let v463_8_tail = v463_8_cursor.make_map();
    v463_8_cursor.ascend(1);
    let v463_8_head = Path::from_slice(&[v463_8_byte]);
    let v464_2: Space = singleton(&(v463_8_head));
    let v464_3: Space = intersect(&(*CONSTANT_7),&(v464_2));
    let v464_4: Space = if has_head(&(v464_3)) { singleton(&[]) } else { Space::new() };
    drop(v464_3);
    let v464_5: Space = subtract(&(*CONSTANT_0),&(v464_4));
    drop(v464_4);
    let v464_8: Space = if (v464_5).is_empty() { Space::new() } else {
      let v465_6: Path = concat_path(&(*p0),&(v463_8_head));
      let v465_7: Space = routine_37(c, &(v465_6), &(v463_8_tail));
      compose(&(v464_5),&(v465_7))
    };
    drop(v464_5);
    let v464_9: Space = intersect(&(*CONSTANT_7),&(v464_2));
    drop(v464_2);
    let v464_10: Space = if has_head(&(v464_9)) { singleton(&[]) } else { Space::new() };
    drop(v464_9);
    let v464_12: Space = if (v464_10).is_empty() { Space::new() } else {
      let v466_6: Path = concat_path(&(*p0),&(v463_8_head));
      let mut v466_11 = Space::new();
      let mut v466_11_cursor = (v463_8_tail).read_zipper();
      for v466_11_byte in v466_11_cursor.child_mask().iter() {
        v466_11_cursor.descend_to_byte(v466_11_byte);
        let v466_11_tail = v466_11_cursor.make_map();
        v466_11_cursor.ascend(1);
        let v466_11_head = Path::from_slice(&[v466_11_byte]);
        let v467_2: Space = singleton(&(v466_11_head));
        let v467_3: Space = intersect(&(*CONSTANT_7),&(v467_2));
        let v467_4: Space = if has_head(&(v467_3)) { singleton(&[]) } else { Space::new() };
        drop(v467_3);
        let v467_5: Space = subtract(&(*CONSTANT_0),&(v467_4));
        drop(v467_4);
        let v467_7: Space = if (v467_5).is_empty() { Space::new() } else {
          let v468_6: Space = routine_71(c, &(v466_11_head), &(v466_6), &(v466_11_tail));
          compose(&(v467_5),&(v468_6))
        };
        drop(v467_5);
        let v467_8: Space = intersect(&(*CONSTANT_7),&(v467_2));
        drop(v467_2);
        let v467_9: Space = if has_head(&(v467_8)) { singleton(&[]) } else { Space::new() };
        drop(v467_8);
        let v467_11: Space = if (v467_9).is_empty() { Space::new() } else {
          let v469_10: Space = routine_72(c, &(v466_11_head), &(v466_6), &(v466_11_tail));
          compose(&(v467_9),&(v469_10))
        };
        drop(v467_9);
        let v467_12: Space = unite(&(v467_7),&(v467_11));
        v466_11.join_into((v467_12).clone());
      }
      drop(v466_11_cursor);
      drop(v466_6);
      compose(&(v464_10),&(v466_11))
    };
    drop(v464_10);
    let v464_13: Space = unite(&(v464_8),&(v464_12));
    v463_8.join_into((v464_13).clone());
  }
  drop(v463_8_cursor);
  (v463_8).clone()
}

fn routine_38(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v470_11 = Space::new();
  let mut v470_11_cursor = (*s0).read_zipper();
  for v470_11_byte in v470_11_cursor.child_mask().iter() {
    v470_11_cursor.descend_to_byte(v470_11_byte);
    let v470_11_tail = v470_11_cursor.make_map();
    v470_11_cursor.ascend(1);
    let v470_11_head = Path::from_slice(&[v470_11_byte]);
    let v471_2: Space = singleton(&(v470_11_head));
    let v471_3: Space = intersect(&(*CONSTANT_7),&(v471_2));
    let v471_4: Space = if has_head(&(v471_3)) { singleton(&[]) } else { Space::new() };
    drop(v471_3);
    let v471_5: Space = subtract(&(*CONSTANT_0),&(v471_4));
    drop(v471_4);
    let v471_7: Space = if (v471_5).is_empty() { Space::new() } else {
      let mut v472_6 = Space::new();
      let mut v472_6_cursor = (v470_11_tail).read_zipper();
      for v472_6_byte in v472_6_cursor.child_mask().iter() {
        v472_6_cursor.descend_to_byte(v472_6_byte);
        let v472_6_tail = v472_6_cursor.make_map();
        v472_6_cursor.ascend(1);
        let v472_6_head = Path::from_slice(&[v472_6_byte]);
        let v473_2: Space = singleton(&(v472_6_head));
        let v473_3: Space = intersect(&(*CONSTANT_7),&(v473_2));
        let v473_4: Space = if has_head(&(v473_3)) { singleton(&[]) } else { Space::new() };
        drop(v473_3);
        let v473_5: Space = subtract(&(*CONSTANT_0),&(v473_4));
        drop(v473_4);
        let v473_8: Space = if (v473_5).is_empty() { Space::new() } else {
          let v474_6: Path = concat_path(&(v470_11_head),&(v472_6_head));
          let v474_7: Space = routine_71(c, &(v474_6), &(*p0), &(v472_6_tail));
          compose(&(v473_5),&(v474_7))
        };
        drop(v473_5);
        let v473_9: Space = intersect(&(*CONSTANT_7),&(v473_2));
        drop(v473_2);
        let v473_10: Space = if has_head(&(v473_9)) { singleton(&[]) } else { Space::new() };
        drop(v473_9);
        let v473_12: Space = if (v473_10).is_empty() { Space::new() } else {
          let v475_6: Path = concat_path(&(v470_11_head),&(v472_6_head));
          let v475_11: Space = routine_72(c, &(v475_6), &(*p0), &(v472_6_tail));
          drop(v475_6);
          compose(&(v473_10),&(v475_11))
        };
        drop(v473_10);
        let v473_13: Space = unite(&(v473_8),&(v473_12));
        v472_6.join_into((v473_13).clone());
      }
      drop(v472_6_cursor);
      compose(&(v471_5),&(v472_6))
    };
    drop(v471_5);
    let v471_8: Space = intersect(&(*CONSTANT_7),&(v471_2));
    drop(v471_2);
    let v471_9: Space = if has_head(&(v471_8)) { singleton(&[]) } else { Space::new() };
    drop(v471_8);
    let v471_11: Space = if (v471_9).is_empty() { Space::new() } else {
      let mut v476_10 = Space::new();
      let mut v476_10_cursor = (v470_11_tail).read_zipper();
      for v476_10_byte in v476_10_cursor.child_mask().iter() {
        v476_10_cursor.descend_to_byte(v476_10_byte);
        let v476_10_tail = v476_10_cursor.make_map();
        v476_10_cursor.ascend(1);
        let v476_10_head = Path::from_slice(&[v476_10_byte]);
        let v477_2: Space = singleton(&(v476_10_head));
        let v477_3: Space = intersect(&(*CONSTANT_7),&(v477_2));
        let v477_4: Space = if has_head(&(v477_3)) { singleton(&[]) } else { Space::new() };
        drop(v477_3);
        let v477_5: Space = subtract(&(*CONSTANT_0),&(v477_4));
        drop(v477_4);
        let v477_7: Space = if (v477_5).is_empty() { Space::new() } else {
          let v478_6: Space = routine_90(c, &(v476_10_head), &(*p0), &(v470_11_head), &(v476_10_tail));
          compose(&(v477_5),&(v478_6))
        };
        drop(v477_5);
        let v477_8: Space = intersect(&(*CONSTANT_7),&(v477_2));
        drop(v477_2);
        let v477_9: Space = if has_head(&(v477_8)) { singleton(&[]) } else { Space::new() };
        drop(v477_8);
        let v477_11: Space = if (v477_9).is_empty() { Space::new() } else {
          let v479_10: Space = routine_91(c, &(v476_10_head), &(*p0), &(v470_11_head), &(v476_10_tail));
          compose(&(v477_9),&(v479_10))
        };
        drop(v477_9);
        let v477_12: Space = unite(&(v477_7),&(v477_11));
        v476_10.join_into((v477_12).clone());
      }
      drop(v476_10_cursor);
      compose(&(v471_9),&(v476_10))
    };
    drop(v471_9);
    let v471_12: Space = unite(&(v471_7),&(v471_11));
    v470_11.join_into((v471_12).clone());
  }
  drop(v470_11_cursor);
  (v470_11).clone()
}

fn routine_39(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v480_5 = Space::new();
  let mut v480_5_cursor = (*s0).read_zipper();
  for v480_5_byte in v480_5_cursor.child_mask().iter() {
    v480_5_cursor.descend_to_byte(v480_5_byte);
    let v480_5_tail = v480_5_cursor.make_map();
    v480_5_cursor.ascend(1);
    let v480_5_head = Path::from_slice(&[v480_5_byte]);
    let v481_2: Space = singleton(&(v480_5_head));
    let v481_3: Space = intersect(&(*CONSTANT_7),&(v481_2));
    let v481_4: Space = if has_head(&(v481_3)) { singleton(&[]) } else { Space::new() };
    drop(v481_3);
    let v481_5: Space = subtract(&(*CONSTANT_0),&(v481_4));
    drop(v481_4);
    let v481_8: Space = if (v481_5).is_empty() { Space::new() } else {
      let v482_6: Path = concat_path(&(*p0),&(v480_5_head));
      let v482_7: Space = routine_39(c, &(v482_6), &(v480_5_tail));
      drop(v482_6);
      compose(&(v481_5),&(v482_7))
    };
    drop(v481_5);
    let v481_9: Space = intersect(&(*CONSTANT_7),&(v481_2));
    drop(v481_2);
    let v481_10: Space = if has_head(&(v481_9)) { singleton(&[]) } else { Space::new() };
    drop(v481_9);
    let v481_11: Space = compose(&(v481_10),&(v480_5_tail));
    drop(v481_10);
    let v481_12: Space = unite(&(v481_8),&(v481_11));
    drop(v481_11);
    v480_5.join_into((v481_12).clone());
  }
  drop(v480_5_cursor);
  (v480_5).clone()
}

fn routine_40(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_41(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v484_8 = Space::new();
  let mut v484_8_cursor = (*s0).read_zipper();
  for v484_8_byte in v484_8_cursor.child_mask().iter() {
    v484_8_cursor.descend_to_byte(v484_8_byte);
    let v484_8_tail = v484_8_cursor.make_map();
    v484_8_cursor.ascend(1);
    let v484_8_head = Path::from_slice(&[v484_8_byte]);
    let v485_2: Space = singleton(&(v484_8_head));
    let v485_3: Space = intersect(&(*CONSTANT_7),&(v485_2));
    let v485_4: Space = if has_head(&(v485_3)) { singleton(&[]) } else { Space::new() };
    drop(v485_3);
    let v485_5: Space = subtract(&(*CONSTANT_0),&(v485_4));
    drop(v485_4);
    let v485_8: Space = if (v485_5).is_empty() { Space::new() } else {
      let v486_6: Path = concat_path(&(*p0),&(v484_8_head));
      let v486_7: Space = routine_41(c, &(v486_6), &(v484_8_tail));
      compose(&(v485_5),&(v486_7))
    };
    drop(v485_5);
    let v485_9: Space = intersect(&(*CONSTANT_7),&(v485_2));
    drop(v485_2);
    let v485_10: Space = if has_head(&(v485_9)) { singleton(&[]) } else { Space::new() };
    drop(v485_9);
    let v485_12: Space = if (v485_10).is_empty() { Space::new() } else {
      let v487_6: Path = concat_path(&(*p0),&(v484_8_head));
      let mut v487_11 = Space::new();
      let mut v487_11_cursor = (v484_8_tail).read_zipper();
      for v487_11_byte in v487_11_cursor.child_mask().iter() {
        v487_11_cursor.descend_to_byte(v487_11_byte);
        let v487_11_tail = v487_11_cursor.make_map();
        v487_11_cursor.ascend(1);
        let v487_11_head = Path::from_slice(&[v487_11_byte]);
        let v488_2: Space = singleton(&(v487_11_head));
        let v488_3: Space = intersect(&(*CONSTANT_7),&(v488_2));
        let v488_4: Space = if has_head(&(v488_3)) { singleton(&[]) } else { Space::new() };
        drop(v488_3);
        let v488_5: Space = subtract(&(*CONSTANT_0),&(v488_4));
        drop(v488_4);
        let v488_7: Space = if (v488_5).is_empty() { Space::new() } else {
          let v489_6: Space = routine_73(c, &(v487_11_head), &(v487_6), &(v487_11_tail));
          compose(&(v488_5),&(v489_6))
        };
        drop(v488_5);
        let v488_8: Space = intersect(&(*CONSTANT_7),&(v488_2));
        drop(v488_2);
        let v488_9: Space = if has_head(&(v488_8)) { singleton(&[]) } else { Space::new() };
        drop(v488_8);
        let v488_11: Space = if (v488_9).is_empty() { Space::new() } else {
          let v490_10: Space = routine_74(c, &(v487_11_head), &(v487_6), &(v487_11_tail));
          compose(&(v488_9),&(v490_10))
        };
        drop(v488_9);
        let v488_12: Space = unite(&(v488_7),&(v488_11));
        v487_11.join_into((v488_12).clone());
      }
      drop(v487_11_cursor);
      drop(v487_6);
      compose(&(v485_10),&(v487_11))
    };
    drop(v485_10);
    let v485_13: Space = unite(&(v485_8),&(v485_12));
    v484_8.join_into((v485_13).clone());
  }
  drop(v484_8_cursor);
  (v484_8).clone()
}

fn routine_42(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v491_11 = Space::new();
  let mut v491_11_cursor = (*s0).read_zipper();
  for v491_11_byte in v491_11_cursor.child_mask().iter() {
    v491_11_cursor.descend_to_byte(v491_11_byte);
    let v491_11_tail = v491_11_cursor.make_map();
    v491_11_cursor.ascend(1);
    let v491_11_head = Path::from_slice(&[v491_11_byte]);
    let v492_2: Space = singleton(&(v491_11_head));
    let v492_3: Space = intersect(&(*CONSTANT_7),&(v492_2));
    let v492_4: Space = if has_head(&(v492_3)) { singleton(&[]) } else { Space::new() };
    drop(v492_3);
    let v492_5: Space = subtract(&(*CONSTANT_0),&(v492_4));
    drop(v492_4);
    let v492_7: Space = if (v492_5).is_empty() { Space::new() } else {
      let mut v493_6 = Space::new();
      let mut v493_6_cursor = (v491_11_tail).read_zipper();
      for v493_6_byte in v493_6_cursor.child_mask().iter() {
        v493_6_cursor.descend_to_byte(v493_6_byte);
        let v493_6_tail = v493_6_cursor.make_map();
        v493_6_cursor.ascend(1);
        let v493_6_head = Path::from_slice(&[v493_6_byte]);
        let v494_2: Space = singleton(&(v493_6_head));
        let v494_3: Space = intersect(&(*CONSTANT_7),&(v494_2));
        let v494_4: Space = if has_head(&(v494_3)) { singleton(&[]) } else { Space::new() };
        drop(v494_3);
        let v494_5: Space = subtract(&(*CONSTANT_0),&(v494_4));
        drop(v494_4);
        let v494_8: Space = if (v494_5).is_empty() { Space::new() } else {
          let v495_6: Path = concat_path(&(v491_11_head),&(v493_6_head));
          let v495_7: Space = routine_73(c, &(v495_6), &(*p0), &(v493_6_tail));
          compose(&(v494_5),&(v495_7))
        };
        drop(v494_5);
        let v494_9: Space = intersect(&(*CONSTANT_7),&(v494_2));
        drop(v494_2);
        let v494_10: Space = if has_head(&(v494_9)) { singleton(&[]) } else { Space::new() };
        drop(v494_9);
        let v494_12: Space = if (v494_10).is_empty() { Space::new() } else {
          let v496_6: Path = concat_path(&(v491_11_head),&(v493_6_head));
          let v496_11: Space = routine_74(c, &(v496_6), &(*p0), &(v493_6_tail));
          drop(v496_6);
          compose(&(v494_10),&(v496_11))
        };
        drop(v494_10);
        let v494_13: Space = unite(&(v494_8),&(v494_12));
        v493_6.join_into((v494_13).clone());
      }
      drop(v493_6_cursor);
      compose(&(v492_5),&(v493_6))
    };
    drop(v492_5);
    let v492_8: Space = intersect(&(*CONSTANT_7),&(v492_2));
    drop(v492_2);
    let v492_9: Space = if has_head(&(v492_8)) { singleton(&[]) } else { Space::new() };
    drop(v492_8);
    let v492_11: Space = if (v492_9).is_empty() { Space::new() } else {
      let mut v497_10 = Space::new();
      let mut v497_10_cursor = (v491_11_tail).read_zipper();
      for v497_10_byte in v497_10_cursor.child_mask().iter() {
        v497_10_cursor.descend_to_byte(v497_10_byte);
        let v497_10_tail = v497_10_cursor.make_map();
        v497_10_cursor.ascend(1);
        let v497_10_head = Path::from_slice(&[v497_10_byte]);
        let v498_2: Space = singleton(&(v497_10_head));
        let v498_3: Space = intersect(&(*CONSTANT_7),&(v498_2));
        let v498_4: Space = if has_head(&(v498_3)) { singleton(&[]) } else { Space::new() };
        drop(v498_3);
        let v498_5: Space = subtract(&(*CONSTANT_0),&(v498_4));
        drop(v498_4);
        let v498_7: Space = if (v498_5).is_empty() { Space::new() } else {
          let v499_6: Space = routine_92(c, &(v497_10_head), &(*p0), &(v491_11_head), &(v497_10_tail));
          compose(&(v498_5),&(v499_6))
        };
        drop(v498_5);
        let v498_8: Space = intersect(&(*CONSTANT_7),&(v498_2));
        drop(v498_2);
        let v498_9: Space = if has_head(&(v498_8)) { singleton(&[]) } else { Space::new() };
        drop(v498_8);
        let v498_11: Space = if (v498_9).is_empty() { Space::new() } else {
          let v500_10: Space = routine_93(c, &(v497_10_head), &(*p0), &(v491_11_head), &(v497_10_tail));
          compose(&(v498_9),&(v500_10))
        };
        drop(v498_9);
        let v498_12: Space = unite(&(v498_7),&(v498_11));
        v497_10.join_into((v498_12).clone());
      }
      drop(v497_10_cursor);
      compose(&(v492_9),&(v497_10))
    };
    drop(v492_9);
    let v492_12: Space = unite(&(v492_7),&(v492_11));
    v491_11.join_into((v492_12).clone());
  }
  drop(v491_11_cursor);
  (v491_11).clone()
}

fn routine_43(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v501_5 = Space::new();
  let mut v501_5_cursor = (*s0).read_zipper();
  for v501_5_byte in v501_5_cursor.child_mask().iter() {
    v501_5_cursor.descend_to_byte(v501_5_byte);
    let v501_5_tail = v501_5_cursor.make_map();
    v501_5_cursor.ascend(1);
    let v501_5_head = Path::from_slice(&[v501_5_byte]);
    let v502_2: Space = singleton(&(v501_5_head));
    let v502_3: Space = intersect(&(*CONSTANT_7),&(v502_2));
    let v502_4: Space = if has_head(&(v502_3)) { singleton(&[]) } else { Space::new() };
    drop(v502_3);
    let v502_5: Space = subtract(&(*CONSTANT_0),&(v502_4));
    drop(v502_4);
    let v502_8: Space = if (v502_5).is_empty() { Space::new() } else {
      let v503_6: Path = concat_path(&(*p0),&(v501_5_head));
      let v503_7: Space = routine_43(c, &(v503_6), &(v501_5_tail));
      drop(v503_6);
      compose(&(v502_5),&(v503_7))
    };
    drop(v502_5);
    let v502_9: Space = intersect(&(*CONSTANT_7),&(v502_2));
    drop(v502_2);
    let v502_10: Space = if has_head(&(v502_9)) { singleton(&[]) } else { Space::new() };
    drop(v502_9);
    let v502_11: Space = compose(&(v502_10),&(v501_5_tail));
    drop(v502_10);
    let v502_12: Space = unite(&(v502_8),&(v502_11));
    drop(v502_11);
    v501_5.join_into((v502_12).clone());
  }
  drop(v501_5_cursor);
  (v501_5).clone()
}

fn routine_44(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_45(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v505_8 = Space::new();
  let mut v505_8_cursor = (*s0).read_zipper();
  for v505_8_byte in v505_8_cursor.child_mask().iter() {
    v505_8_cursor.descend_to_byte(v505_8_byte);
    let v505_8_tail = v505_8_cursor.make_map();
    v505_8_cursor.ascend(1);
    let v505_8_head = Path::from_slice(&[v505_8_byte]);
    let v506_2: Space = singleton(&(v505_8_head));
    let v506_3: Space = intersect(&(*CONSTANT_7),&(v506_2));
    let v506_4: Space = if has_head(&(v506_3)) { singleton(&[]) } else { Space::new() };
    drop(v506_3);
    let v506_5: Space = subtract(&(*CONSTANT_0),&(v506_4));
    drop(v506_4);
    let v506_8: Space = if (v506_5).is_empty() { Space::new() } else {
      let v507_6: Path = concat_path(&(*p0),&(v505_8_head));
      let v507_7: Space = routine_45(c, &(v507_6), &(v505_8_tail));
      compose(&(v506_5),&(v507_7))
    };
    drop(v506_5);
    let v506_9: Space = intersect(&(*CONSTANT_7),&(v506_2));
    drop(v506_2);
    let v506_10: Space = if has_head(&(v506_9)) { singleton(&[]) } else { Space::new() };
    drop(v506_9);
    let v506_12: Space = if (v506_10).is_empty() { Space::new() } else {
      let v508_6: Path = concat_path(&(*p0),&(v505_8_head));
      let mut v508_11 = Space::new();
      let mut v508_11_cursor = (v505_8_tail).read_zipper();
      for v508_11_byte in v508_11_cursor.child_mask().iter() {
        v508_11_cursor.descend_to_byte(v508_11_byte);
        let v508_11_tail = v508_11_cursor.make_map();
        v508_11_cursor.ascend(1);
        let v508_11_head = Path::from_slice(&[v508_11_byte]);
        let v509_2: Space = singleton(&(v508_11_head));
        let v509_3: Space = intersect(&(*CONSTANT_7),&(v509_2));
        let v509_4: Space = if has_head(&(v509_3)) { singleton(&[]) } else { Space::new() };
        drop(v509_3);
        let v509_5: Space = subtract(&(*CONSTANT_0),&(v509_4));
        drop(v509_4);
        let v509_7: Space = if (v509_5).is_empty() { Space::new() } else {
          let v510_6: Space = routine_75(c, &(v508_11_head), &(v508_6), &(v508_11_tail));
          compose(&(v509_5),&(v510_6))
        };
        drop(v509_5);
        let v509_8: Space = intersect(&(*CONSTANT_7),&(v509_2));
        drop(v509_2);
        let v509_9: Space = if has_head(&(v509_8)) { singleton(&[]) } else { Space::new() };
        drop(v509_8);
        let v509_11: Space = if (v509_9).is_empty() { Space::new() } else {
          let v511_10: Space = routine_76(c, &(v508_11_head), &(v508_6), &(v508_11_tail));
          compose(&(v509_9),&(v511_10))
        };
        drop(v509_9);
        let v509_12: Space = unite(&(v509_7),&(v509_11));
        v508_11.join_into((v509_12).clone());
      }
      drop(v508_11_cursor);
      drop(v508_6);
      compose(&(v506_10),&(v508_11))
    };
    drop(v506_10);
    let v506_13: Space = unite(&(v506_8),&(v506_12));
    v505_8.join_into((v506_13).clone());
  }
  drop(v505_8_cursor);
  (v505_8).clone()
}

fn routine_46(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v512_11 = Space::new();
  let mut v512_11_cursor = (*s0).read_zipper();
  for v512_11_byte in v512_11_cursor.child_mask().iter() {
    v512_11_cursor.descend_to_byte(v512_11_byte);
    let v512_11_tail = v512_11_cursor.make_map();
    v512_11_cursor.ascend(1);
    let v512_11_head = Path::from_slice(&[v512_11_byte]);
    let v513_2: Space = singleton(&(v512_11_head));
    let v513_3: Space = intersect(&(*CONSTANT_7),&(v513_2));
    let v513_4: Space = if has_head(&(v513_3)) { singleton(&[]) } else { Space::new() };
    drop(v513_3);
    let v513_5: Space = subtract(&(*CONSTANT_0),&(v513_4));
    drop(v513_4);
    let v513_7: Space = if (v513_5).is_empty() { Space::new() } else {
      let mut v514_6 = Space::new();
      let mut v514_6_cursor = (v512_11_tail).read_zipper();
      for v514_6_byte in v514_6_cursor.child_mask().iter() {
        v514_6_cursor.descend_to_byte(v514_6_byte);
        let v514_6_tail = v514_6_cursor.make_map();
        v514_6_cursor.ascend(1);
        let v514_6_head = Path::from_slice(&[v514_6_byte]);
        let v515_2: Space = singleton(&(v514_6_head));
        let v515_3: Space = intersect(&(*CONSTANT_7),&(v515_2));
        let v515_4: Space = if has_head(&(v515_3)) { singleton(&[]) } else { Space::new() };
        drop(v515_3);
        let v515_5: Space = subtract(&(*CONSTANT_0),&(v515_4));
        drop(v515_4);
        let v515_8: Space = if (v515_5).is_empty() { Space::new() } else {
          let v516_6: Path = concat_path(&(v512_11_head),&(v514_6_head));
          let v516_7: Space = routine_75(c, &(v516_6), &(*p0), &(v514_6_tail));
          compose(&(v515_5),&(v516_7))
        };
        drop(v515_5);
        let v515_9: Space = intersect(&(*CONSTANT_7),&(v515_2));
        drop(v515_2);
        let v515_10: Space = if has_head(&(v515_9)) { singleton(&[]) } else { Space::new() };
        drop(v515_9);
        let v515_12: Space = if (v515_10).is_empty() { Space::new() } else {
          let v517_6: Path = concat_path(&(v512_11_head),&(v514_6_head));
          let v517_11: Space = routine_76(c, &(v517_6), &(*p0), &(v514_6_tail));
          drop(v517_6);
          compose(&(v515_10),&(v517_11))
        };
        drop(v515_10);
        let v515_13: Space = unite(&(v515_8),&(v515_12));
        v514_6.join_into((v515_13).clone());
      }
      drop(v514_6_cursor);
      compose(&(v513_5),&(v514_6))
    };
    drop(v513_5);
    let v513_8: Space = intersect(&(*CONSTANT_7),&(v513_2));
    drop(v513_2);
    let v513_9: Space = if has_head(&(v513_8)) { singleton(&[]) } else { Space::new() };
    drop(v513_8);
    let v513_11: Space = if (v513_9).is_empty() { Space::new() } else {
      let mut v518_10 = Space::new();
      let mut v518_10_cursor = (v512_11_tail).read_zipper();
      for v518_10_byte in v518_10_cursor.child_mask().iter() {
        v518_10_cursor.descend_to_byte(v518_10_byte);
        let v518_10_tail = v518_10_cursor.make_map();
        v518_10_cursor.ascend(1);
        let v518_10_head = Path::from_slice(&[v518_10_byte]);
        let v519_2: Space = singleton(&(v518_10_head));
        let v519_3: Space = intersect(&(*CONSTANT_7),&(v519_2));
        let v519_4: Space = if has_head(&(v519_3)) { singleton(&[]) } else { Space::new() };
        drop(v519_3);
        let v519_5: Space = subtract(&(*CONSTANT_0),&(v519_4));
        drop(v519_4);
        let v519_7: Space = if (v519_5).is_empty() { Space::new() } else {
          let v520_6: Space = routine_94(c, &(v518_10_head), &(*p0), &(v512_11_head), &(v518_10_tail));
          compose(&(v519_5),&(v520_6))
        };
        drop(v519_5);
        let v519_8: Space = intersect(&(*CONSTANT_7),&(v519_2));
        drop(v519_2);
        let v519_9: Space = if has_head(&(v519_8)) { singleton(&[]) } else { Space::new() };
        drop(v519_8);
        let v519_11: Space = if (v519_9).is_empty() { Space::new() } else {
          let v521_10: Space = routine_95(c, &(v518_10_head), &(*p0), &(v512_11_head), &(v518_10_tail));
          compose(&(v519_9),&(v521_10))
        };
        drop(v519_9);
        let v519_12: Space = unite(&(v519_7),&(v519_11));
        v518_10.join_into((v519_12).clone());
      }
      drop(v518_10_cursor);
      compose(&(v513_9),&(v518_10))
    };
    drop(v513_9);
    let v513_12: Space = unite(&(v513_7),&(v513_11));
    v512_11.join_into((v513_12).clone());
  }
  drop(v512_11_cursor);
  (v512_11).clone()
}

fn routine_47(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v522_5 = Space::new();
  let mut v522_5_cursor = (*s0).read_zipper();
  for v522_5_byte in v522_5_cursor.child_mask().iter() {
    v522_5_cursor.descend_to_byte(v522_5_byte);
    let v522_5_tail = v522_5_cursor.make_map();
    v522_5_cursor.ascend(1);
    let v522_5_head = Path::from_slice(&[v522_5_byte]);
    let v523_2: Space = singleton(&(v522_5_head));
    let v523_3: Space = intersect(&(*CONSTANT_7),&(v523_2));
    let v523_4: Space = if has_head(&(v523_3)) { singleton(&[]) } else { Space::new() };
    drop(v523_3);
    let v523_5: Space = subtract(&(*CONSTANT_0),&(v523_4));
    drop(v523_4);
    let v523_8: Space = if (v523_5).is_empty() { Space::new() } else {
      let v524_6: Path = concat_path(&(*p0),&(v522_5_head));
      let v524_7: Space = routine_47(c, &(v524_6), &(v522_5_tail));
      drop(v524_6);
      compose(&(v523_5),&(v524_7))
    };
    drop(v523_5);
    let v523_9: Space = intersect(&(*CONSTANT_7),&(v523_2));
    drop(v523_2);
    let v523_10: Space = if has_head(&(v523_9)) { singleton(&[]) } else { Space::new() };
    drop(v523_9);
    let v523_11: Space = compose(&(v523_10),&(v522_5_tail));
    drop(v523_10);
    let v523_12: Space = unite(&(v523_8),&(v523_11));
    drop(v523_11);
    v522_5.join_into((v523_12).clone());
  }
  drop(v522_5_cursor);
  (v522_5).clone()
}

fn routine_48(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_49(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v526_8 = Space::new();
  let mut v526_8_cursor = (*s0).read_zipper();
  for v526_8_byte in v526_8_cursor.child_mask().iter() {
    v526_8_cursor.descend_to_byte(v526_8_byte);
    let v526_8_tail = v526_8_cursor.make_map();
    v526_8_cursor.ascend(1);
    let v526_8_head = Path::from_slice(&[v526_8_byte]);
    let v527_2: Space = singleton(&(v526_8_head));
    let v527_3: Space = intersect(&(*CONSTANT_7),&(v527_2));
    let v527_4: Space = if has_head(&(v527_3)) { singleton(&[]) } else { Space::new() };
    drop(v527_3);
    let v527_5: Space = subtract(&(*CONSTANT_0),&(v527_4));
    drop(v527_4);
    let v527_8: Space = if (v527_5).is_empty() { Space::new() } else {
      let v528_6: Path = concat_path(&(*p0),&(v526_8_head));
      let v528_7: Space = routine_49(c, &(v528_6), &(v526_8_tail));
      compose(&(v527_5),&(v528_7))
    };
    drop(v527_5);
    let v527_9: Space = intersect(&(*CONSTANT_7),&(v527_2));
    drop(v527_2);
    let v527_10: Space = if has_head(&(v527_9)) { singleton(&[]) } else { Space::new() };
    drop(v527_9);
    let v527_12: Space = if (v527_10).is_empty() { Space::new() } else {
      let v529_6: Path = concat_path(&(*p0),&(v526_8_head));
      let mut v529_11 = Space::new();
      let mut v529_11_cursor = (v526_8_tail).read_zipper();
      for v529_11_byte in v529_11_cursor.child_mask().iter() {
        v529_11_cursor.descend_to_byte(v529_11_byte);
        let v529_11_tail = v529_11_cursor.make_map();
        v529_11_cursor.ascend(1);
        let v529_11_head = Path::from_slice(&[v529_11_byte]);
        let v530_2: Space = singleton(&(v529_11_head));
        let v530_3: Space = intersect(&(*CONSTANT_7),&(v530_2));
        let v530_4: Space = if has_head(&(v530_3)) { singleton(&[]) } else { Space::new() };
        drop(v530_3);
        let v530_5: Space = subtract(&(*CONSTANT_0),&(v530_4));
        drop(v530_4);
        let v530_7: Space = if (v530_5).is_empty() { Space::new() } else {
          let v531_6: Space = routine_77(c, &(v529_11_head), &(v529_6), &(v529_11_tail));
          compose(&(v530_5),&(v531_6))
        };
        drop(v530_5);
        let v530_8: Space = intersect(&(*CONSTANT_7),&(v530_2));
        drop(v530_2);
        let v530_9: Space = if has_head(&(v530_8)) { singleton(&[]) } else { Space::new() };
        drop(v530_8);
        let v530_11: Space = if (v530_9).is_empty() { Space::new() } else {
          let v532_10: Space = routine_78(c, &(v529_11_head), &(v529_6), &(v529_11_tail));
          compose(&(v530_9),&(v532_10))
        };
        drop(v530_9);
        let v530_12: Space = unite(&(v530_7),&(v530_11));
        v529_11.join_into((v530_12).clone());
      }
      drop(v529_11_cursor);
      drop(v529_6);
      compose(&(v527_10),&(v529_11))
    };
    drop(v527_10);
    let v527_13: Space = unite(&(v527_8),&(v527_12));
    v526_8.join_into((v527_13).clone());
  }
  drop(v526_8_cursor);
  (v526_8).clone()
}

fn routine_50(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v533_11 = Space::new();
  let mut v533_11_cursor = (*s0).read_zipper();
  for v533_11_byte in v533_11_cursor.child_mask().iter() {
    v533_11_cursor.descend_to_byte(v533_11_byte);
    let v533_11_tail = v533_11_cursor.make_map();
    v533_11_cursor.ascend(1);
    let v533_11_head = Path::from_slice(&[v533_11_byte]);
    let v534_2: Space = singleton(&(v533_11_head));
    let v534_3: Space = intersect(&(*CONSTANT_7),&(v534_2));
    let v534_4: Space = if has_head(&(v534_3)) { singleton(&[]) } else { Space::new() };
    drop(v534_3);
    let v534_5: Space = subtract(&(*CONSTANT_0),&(v534_4));
    drop(v534_4);
    let v534_7: Space = if (v534_5).is_empty() { Space::new() } else {
      let mut v535_6 = Space::new();
      let mut v535_6_cursor = (v533_11_tail).read_zipper();
      for v535_6_byte in v535_6_cursor.child_mask().iter() {
        v535_6_cursor.descend_to_byte(v535_6_byte);
        let v535_6_tail = v535_6_cursor.make_map();
        v535_6_cursor.ascend(1);
        let v535_6_head = Path::from_slice(&[v535_6_byte]);
        let v536_2: Space = singleton(&(v535_6_head));
        let v536_3: Space = intersect(&(*CONSTANT_7),&(v536_2));
        let v536_4: Space = if has_head(&(v536_3)) { singleton(&[]) } else { Space::new() };
        drop(v536_3);
        let v536_5: Space = subtract(&(*CONSTANT_0),&(v536_4));
        drop(v536_4);
        let v536_8: Space = if (v536_5).is_empty() { Space::new() } else {
          let v537_6: Path = concat_path(&(v533_11_head),&(v535_6_head));
          let v537_7: Space = routine_77(c, &(v537_6), &(*p0), &(v535_6_tail));
          compose(&(v536_5),&(v537_7))
        };
        drop(v536_5);
        let v536_9: Space = intersect(&(*CONSTANT_7),&(v536_2));
        drop(v536_2);
        let v536_10: Space = if has_head(&(v536_9)) { singleton(&[]) } else { Space::new() };
        drop(v536_9);
        let v536_12: Space = if (v536_10).is_empty() { Space::new() } else {
          let v538_6: Path = concat_path(&(v533_11_head),&(v535_6_head));
          let v538_11: Space = routine_78(c, &(v538_6), &(*p0), &(v535_6_tail));
          drop(v538_6);
          compose(&(v536_10),&(v538_11))
        };
        drop(v536_10);
        let v536_13: Space = unite(&(v536_8),&(v536_12));
        v535_6.join_into((v536_13).clone());
      }
      drop(v535_6_cursor);
      compose(&(v534_5),&(v535_6))
    };
    drop(v534_5);
    let v534_8: Space = intersect(&(*CONSTANT_7),&(v534_2));
    drop(v534_2);
    let v534_9: Space = if has_head(&(v534_8)) { singleton(&[]) } else { Space::new() };
    drop(v534_8);
    let v534_11: Space = if (v534_9).is_empty() { Space::new() } else {
      let mut v539_10 = Space::new();
      let mut v539_10_cursor = (v533_11_tail).read_zipper();
      for v539_10_byte in v539_10_cursor.child_mask().iter() {
        v539_10_cursor.descend_to_byte(v539_10_byte);
        let v539_10_tail = v539_10_cursor.make_map();
        v539_10_cursor.ascend(1);
        let v539_10_head = Path::from_slice(&[v539_10_byte]);
        let v540_2: Space = singleton(&(v539_10_head));
        let v540_3: Space = intersect(&(*CONSTANT_7),&(v540_2));
        let v540_4: Space = if has_head(&(v540_3)) { singleton(&[]) } else { Space::new() };
        drop(v540_3);
        let v540_5: Space = subtract(&(*CONSTANT_0),&(v540_4));
        drop(v540_4);
        let v540_7: Space = if (v540_5).is_empty() { Space::new() } else {
          let v541_6: Space = routine_96(c, &(v539_10_head), &(*p0), &(v533_11_head), &(v539_10_tail));
          compose(&(v540_5),&(v541_6))
        };
        drop(v540_5);
        let v540_8: Space = intersect(&(*CONSTANT_7),&(v540_2));
        drop(v540_2);
        let v540_9: Space = if has_head(&(v540_8)) { singleton(&[]) } else { Space::new() };
        drop(v540_8);
        let v540_11: Space = if (v540_9).is_empty() { Space::new() } else {
          let v542_10: Space = routine_97(c, &(v539_10_head), &(*p0), &(v533_11_head), &(v539_10_tail));
          compose(&(v540_9),&(v542_10))
        };
        drop(v540_9);
        let v540_12: Space = unite(&(v540_7),&(v540_11));
        v539_10.join_into((v540_12).clone());
      }
      drop(v539_10_cursor);
      compose(&(v534_9),&(v539_10))
    };
    drop(v534_9);
    let v534_12: Space = unite(&(v534_7),&(v534_11));
    v533_11.join_into((v534_12).clone());
  }
  drop(v533_11_cursor);
  (v533_11).clone()
}

fn routine_51(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v543_5 = Space::new();
  let mut v543_5_cursor = (*s0).read_zipper();
  for v543_5_byte in v543_5_cursor.child_mask().iter() {
    v543_5_cursor.descend_to_byte(v543_5_byte);
    let v543_5_tail = v543_5_cursor.make_map();
    v543_5_cursor.ascend(1);
    let v543_5_head = Path::from_slice(&[v543_5_byte]);
    let v544_2: Space = singleton(&(v543_5_head));
    let v544_3: Space = intersect(&(*CONSTANT_7),&(v544_2));
    let v544_4: Space = if has_head(&(v544_3)) { singleton(&[]) } else { Space::new() };
    drop(v544_3);
    let v544_5: Space = subtract(&(*CONSTANT_0),&(v544_4));
    drop(v544_4);
    let v544_8: Space = if (v544_5).is_empty() { Space::new() } else {
      let v545_6: Path = concat_path(&(*p0),&(v543_5_head));
      let v545_7: Space = routine_51(c, &(v545_6), &(v543_5_tail));
      drop(v545_6);
      compose(&(v544_5),&(v545_7))
    };
    drop(v544_5);
    let v544_9: Space = intersect(&(*CONSTANT_7),&(v544_2));
    drop(v544_2);
    let v544_10: Space = if has_head(&(v544_9)) { singleton(&[]) } else { Space::new() };
    drop(v544_9);
    let v544_11: Space = compose(&(v544_10),&(v543_5_tail));
    drop(v544_10);
    let v544_12: Space = unite(&(v544_8),&(v544_11));
    drop(v544_11);
    v543_5.join_into((v544_12).clone());
  }
  drop(v543_5_cursor);
  (v543_5).clone()
}

fn routine_52(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_53(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v547_8 = Space::new();
  let mut v547_8_cursor = (*s0).read_zipper();
  for v547_8_byte in v547_8_cursor.child_mask().iter() {
    v547_8_cursor.descend_to_byte(v547_8_byte);
    let v547_8_tail = v547_8_cursor.make_map();
    v547_8_cursor.ascend(1);
    let v547_8_head = Path::from_slice(&[v547_8_byte]);
    let v548_2: Space = singleton(&(v547_8_head));
    let v548_3: Space = intersect(&(*CONSTANT_7),&(v548_2));
    let v548_4: Space = if has_head(&(v548_3)) { singleton(&[]) } else { Space::new() };
    drop(v548_3);
    let v548_5: Space = subtract(&(*CONSTANT_0),&(v548_4));
    drop(v548_4);
    let v548_8: Space = if (v548_5).is_empty() { Space::new() } else {
      let v549_6: Path = concat_path(&(*p0),&(v547_8_head));
      let v549_7: Space = routine_53(c, &(v549_6), &(v547_8_tail));
      compose(&(v548_5),&(v549_7))
    };
    drop(v548_5);
    let v548_9: Space = intersect(&(*CONSTANT_7),&(v548_2));
    drop(v548_2);
    let v548_10: Space = if has_head(&(v548_9)) { singleton(&[]) } else { Space::new() };
    drop(v548_9);
    let v548_12: Space = if (v548_10).is_empty() { Space::new() } else {
      let v550_6: Path = concat_path(&(*p0),&(v547_8_head));
      let mut v550_11 = Space::new();
      let mut v550_11_cursor = (v547_8_tail).read_zipper();
      for v550_11_byte in v550_11_cursor.child_mask().iter() {
        v550_11_cursor.descend_to_byte(v550_11_byte);
        let v550_11_tail = v550_11_cursor.make_map();
        v550_11_cursor.ascend(1);
        let v550_11_head = Path::from_slice(&[v550_11_byte]);
        let v551_2: Space = singleton(&(v550_11_head));
        let v551_3: Space = intersect(&(*CONSTANT_7),&(v551_2));
        let v551_4: Space = if has_head(&(v551_3)) { singleton(&[]) } else { Space::new() };
        drop(v551_3);
        let v551_5: Space = subtract(&(*CONSTANT_0),&(v551_4));
        drop(v551_4);
        let v551_7: Space = if (v551_5).is_empty() { Space::new() } else {
          let v552_6: Space = routine_79(c, &(v550_11_head), &(v550_6), &(v550_11_tail));
          compose(&(v551_5),&(v552_6))
        };
        drop(v551_5);
        let v551_8: Space = intersect(&(*CONSTANT_7),&(v551_2));
        drop(v551_2);
        let v551_9: Space = if has_head(&(v551_8)) { singleton(&[]) } else { Space::new() };
        drop(v551_8);
        let v551_11: Space = if (v551_9).is_empty() { Space::new() } else {
          let v553_10: Space = routine_80(c, &(v550_11_head), &(v550_6), &(v550_11_tail));
          compose(&(v551_9),&(v553_10))
        };
        drop(v551_9);
        let v551_12: Space = unite(&(v551_7),&(v551_11));
        v550_11.join_into((v551_12).clone());
      }
      drop(v550_11_cursor);
      drop(v550_6);
      compose(&(v548_10),&(v550_11))
    };
    drop(v548_10);
    let v548_13: Space = unite(&(v548_8),&(v548_12));
    v547_8.join_into((v548_13).clone());
  }
  drop(v547_8_cursor);
  (v547_8).clone()
}

fn routine_54(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v554_11 = Space::new();
  let mut v554_11_cursor = (*s0).read_zipper();
  for v554_11_byte in v554_11_cursor.child_mask().iter() {
    v554_11_cursor.descend_to_byte(v554_11_byte);
    let v554_11_tail = v554_11_cursor.make_map();
    v554_11_cursor.ascend(1);
    let v554_11_head = Path::from_slice(&[v554_11_byte]);
    let v555_2: Space = singleton(&(v554_11_head));
    let v555_3: Space = intersect(&(*CONSTANT_7),&(v555_2));
    let v555_4: Space = if has_head(&(v555_3)) { singleton(&[]) } else { Space::new() };
    drop(v555_3);
    let v555_5: Space = subtract(&(*CONSTANT_0),&(v555_4));
    drop(v555_4);
    let v555_7: Space = if (v555_5).is_empty() { Space::new() } else {
      let mut v556_6 = Space::new();
      let mut v556_6_cursor = (v554_11_tail).read_zipper();
      for v556_6_byte in v556_6_cursor.child_mask().iter() {
        v556_6_cursor.descend_to_byte(v556_6_byte);
        let v556_6_tail = v556_6_cursor.make_map();
        v556_6_cursor.ascend(1);
        let v556_6_head = Path::from_slice(&[v556_6_byte]);
        let v557_2: Space = singleton(&(v556_6_head));
        let v557_3: Space = intersect(&(*CONSTANT_7),&(v557_2));
        let v557_4: Space = if has_head(&(v557_3)) { singleton(&[]) } else { Space::new() };
        drop(v557_3);
        let v557_5: Space = subtract(&(*CONSTANT_0),&(v557_4));
        drop(v557_4);
        let v557_8: Space = if (v557_5).is_empty() { Space::new() } else {
          let v558_6: Path = concat_path(&(v554_11_head),&(v556_6_head));
          let v558_7: Space = routine_79(c, &(v558_6), &(*p0), &(v556_6_tail));
          compose(&(v557_5),&(v558_7))
        };
        drop(v557_5);
        let v557_9: Space = intersect(&(*CONSTANT_7),&(v557_2));
        drop(v557_2);
        let v557_10: Space = if has_head(&(v557_9)) { singleton(&[]) } else { Space::new() };
        drop(v557_9);
        let v557_12: Space = if (v557_10).is_empty() { Space::new() } else {
          let v559_6: Path = concat_path(&(v554_11_head),&(v556_6_head));
          let v559_11: Space = routine_80(c, &(v559_6), &(*p0), &(v556_6_tail));
          drop(v559_6);
          compose(&(v557_10),&(v559_11))
        };
        drop(v557_10);
        let v557_13: Space = unite(&(v557_8),&(v557_12));
        v556_6.join_into((v557_13).clone());
      }
      drop(v556_6_cursor);
      compose(&(v555_5),&(v556_6))
    };
    drop(v555_5);
    let v555_8: Space = intersect(&(*CONSTANT_7),&(v555_2));
    drop(v555_2);
    let v555_9: Space = if has_head(&(v555_8)) { singleton(&[]) } else { Space::new() };
    drop(v555_8);
    let v555_11: Space = if (v555_9).is_empty() { Space::new() } else {
      let mut v560_10 = Space::new();
      let mut v560_10_cursor = (v554_11_tail).read_zipper();
      for v560_10_byte in v560_10_cursor.child_mask().iter() {
        v560_10_cursor.descend_to_byte(v560_10_byte);
        let v560_10_tail = v560_10_cursor.make_map();
        v560_10_cursor.ascend(1);
        let v560_10_head = Path::from_slice(&[v560_10_byte]);
        let v561_2: Space = singleton(&(v560_10_head));
        let v561_3: Space = intersect(&(*CONSTANT_7),&(v561_2));
        let v561_4: Space = if has_head(&(v561_3)) { singleton(&[]) } else { Space::new() };
        drop(v561_3);
        let v561_5: Space = subtract(&(*CONSTANT_0),&(v561_4));
        drop(v561_4);
        let v561_7: Space = if (v561_5).is_empty() { Space::new() } else {
          let v562_6: Space = routine_98(c, &(v560_10_head), &(*p0), &(v554_11_head), &(v560_10_tail));
          compose(&(v561_5),&(v562_6))
        };
        drop(v561_5);
        let v561_8: Space = intersect(&(*CONSTANT_7),&(v561_2));
        drop(v561_2);
        let v561_9: Space = if has_head(&(v561_8)) { singleton(&[]) } else { Space::new() };
        drop(v561_8);
        let v561_11: Space = if (v561_9).is_empty() { Space::new() } else {
          let v563_10: Space = routine_99(c, &(v560_10_head), &(*p0), &(v554_11_head), &(v560_10_tail));
          compose(&(v561_9),&(v563_10))
        };
        drop(v561_9);
        let v561_12: Space = unite(&(v561_7),&(v561_11));
        v560_10.join_into((v561_12).clone());
      }
      drop(v560_10_cursor);
      compose(&(v555_9),&(v560_10))
    };
    drop(v555_9);
    let v555_12: Space = unite(&(v555_7),&(v555_11));
    v554_11.join_into((v555_12).clone());
  }
  drop(v554_11_cursor);
  (v554_11).clone()
}

fn routine_55(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v564_5 = Space::new();
  let mut v564_5_cursor = (*s0).read_zipper();
  for v564_5_byte in v564_5_cursor.child_mask().iter() {
    v564_5_cursor.descend_to_byte(v564_5_byte);
    let v564_5_tail = v564_5_cursor.make_map();
    v564_5_cursor.ascend(1);
    let v564_5_head = Path::from_slice(&[v564_5_byte]);
    let v565_2: Space = singleton(&(v564_5_head));
    let v565_3: Space = intersect(&(*CONSTANT_7),&(v565_2));
    let v565_4: Space = if has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
    drop(v565_3);
    let v565_5: Space = subtract(&(*CONSTANT_0),&(v565_4));
    drop(v565_4);
    let v565_8: Space = if (v565_5).is_empty() { Space::new() } else {
      let v566_6: Path = concat_path(&(*p0),&(v564_5_head));
      let v566_7: Space = routine_55(c, &(v566_6), &(v564_5_tail));
      drop(v566_6);
      compose(&(v565_5),&(v566_7))
    };
    drop(v565_5);
    let v565_9: Space = intersect(&(*CONSTANT_7),&(v565_2));
    drop(v565_2);
    let v565_10: Space = if has_head(&(v565_9)) { singleton(&[]) } else { Space::new() };
    drop(v565_9);
    let v565_11: Space = compose(&(v565_10),&(v564_5_tail));
    drop(v565_10);
    let v565_12: Space = unite(&(v565_8),&(v565_11));
    drop(v565_11);
    v564_5.join_into((v565_12).clone());
  }
  drop(v564_5_cursor);
  (v564_5).clone()
}

fn routine_56(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_57(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v568_8 = Space::new();
  let mut v568_8_cursor = (*s0).read_zipper();
  for v568_8_byte in v568_8_cursor.child_mask().iter() {
    v568_8_cursor.descend_to_byte(v568_8_byte);
    let v568_8_tail = v568_8_cursor.make_map();
    v568_8_cursor.ascend(1);
    let v568_8_head = Path::from_slice(&[v568_8_byte]);
    let v569_2: Space = singleton(&(v568_8_head));
    let v569_3: Space = intersect(&(*CONSTANT_7),&(v569_2));
    let v569_4: Space = if has_head(&(v569_3)) { singleton(&[]) } else { Space::new() };
    drop(v569_3);
    let v569_5: Space = subtract(&(*CONSTANT_0),&(v569_4));
    drop(v569_4);
    let v569_8: Space = if (v569_5).is_empty() { Space::new() } else {
      let v570_6: Path = concat_path(&(*p0),&(v568_8_head));
      let v570_7: Space = routine_57(c, &(v570_6), &(v568_8_tail));
      compose(&(v569_5),&(v570_7))
    };
    drop(v569_5);
    let v569_9: Space = intersect(&(*CONSTANT_7),&(v569_2));
    drop(v569_2);
    let v569_10: Space = if has_head(&(v569_9)) { singleton(&[]) } else { Space::new() };
    drop(v569_9);
    let v569_12: Space = if (v569_10).is_empty() { Space::new() } else {
      let v571_6: Path = concat_path(&(*p0),&(v568_8_head));
      let mut v571_11 = Space::new();
      let mut v571_11_cursor = (v568_8_tail).read_zipper();
      for v571_11_byte in v571_11_cursor.child_mask().iter() {
        v571_11_cursor.descend_to_byte(v571_11_byte);
        let v571_11_tail = v571_11_cursor.make_map();
        v571_11_cursor.ascend(1);
        let v571_11_head = Path::from_slice(&[v571_11_byte]);
        let v572_2: Space = singleton(&(v571_11_head));
        let v572_3: Space = intersect(&(*CONSTANT_7),&(v572_2));
        let v572_4: Space = if has_head(&(v572_3)) { singleton(&[]) } else { Space::new() };
        drop(v572_3);
        let v572_5: Space = subtract(&(*CONSTANT_0),&(v572_4));
        drop(v572_4);
        let v572_7: Space = if (v572_5).is_empty() { Space::new() } else {
          let v573_6: Space = routine_81(c, &(v571_11_head), &(v571_6), &(v571_11_tail));
          compose(&(v572_5),&(v573_6))
        };
        drop(v572_5);
        let v572_8: Space = intersect(&(*CONSTANT_7),&(v572_2));
        drop(v572_2);
        let v572_9: Space = if has_head(&(v572_8)) { singleton(&[]) } else { Space::new() };
        drop(v572_8);
        let v572_11: Space = if (v572_9).is_empty() { Space::new() } else {
          let v574_10: Space = routine_82(c, &(v571_11_head), &(v571_6), &(v571_11_tail));
          compose(&(v572_9),&(v574_10))
        };
        drop(v572_9);
        let v572_12: Space = unite(&(v572_7),&(v572_11));
        v571_11.join_into((v572_12).clone());
      }
      drop(v571_11_cursor);
      drop(v571_6);
      compose(&(v569_10),&(v571_11))
    };
    drop(v569_10);
    let v569_13: Space = unite(&(v569_8),&(v569_12));
    v568_8.join_into((v569_13).clone());
  }
  drop(v568_8_cursor);
  (v568_8).clone()
}

fn routine_58(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v575_11 = Space::new();
  let mut v575_11_cursor = (*s0).read_zipper();
  for v575_11_byte in v575_11_cursor.child_mask().iter() {
    v575_11_cursor.descend_to_byte(v575_11_byte);
    let v575_11_tail = v575_11_cursor.make_map();
    v575_11_cursor.ascend(1);
    let v575_11_head = Path::from_slice(&[v575_11_byte]);
    let v576_2: Space = singleton(&(v575_11_head));
    let v576_3: Space = intersect(&(*CONSTANT_7),&(v576_2));
    let v576_4: Space = if has_head(&(v576_3)) { singleton(&[]) } else { Space::new() };
    drop(v576_3);
    let v576_5: Space = subtract(&(*CONSTANT_0),&(v576_4));
    drop(v576_4);
    let v576_7: Space = if (v576_5).is_empty() { Space::new() } else {
      let mut v577_6 = Space::new();
      let mut v577_6_cursor = (v575_11_tail).read_zipper();
      for v577_6_byte in v577_6_cursor.child_mask().iter() {
        v577_6_cursor.descend_to_byte(v577_6_byte);
        let v577_6_tail = v577_6_cursor.make_map();
        v577_6_cursor.ascend(1);
        let v577_6_head = Path::from_slice(&[v577_6_byte]);
        let v578_2: Space = singleton(&(v577_6_head));
        let v578_3: Space = intersect(&(*CONSTANT_7),&(v578_2));
        let v578_4: Space = if has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
        drop(v578_3);
        let v578_5: Space = subtract(&(*CONSTANT_0),&(v578_4));
        drop(v578_4);
        let v578_8: Space = if (v578_5).is_empty() { Space::new() } else {
          let v579_6: Path = concat_path(&(v575_11_head),&(v577_6_head));
          let v579_7: Space = routine_81(c, &(v579_6), &(*p0), &(v577_6_tail));
          compose(&(v578_5),&(v579_7))
        };
        drop(v578_5);
        let v578_9: Space = intersect(&(*CONSTANT_7),&(v578_2));
        drop(v578_2);
        let v578_10: Space = if has_head(&(v578_9)) { singleton(&[]) } else { Space::new() };
        drop(v578_9);
        let v578_12: Space = if (v578_10).is_empty() { Space::new() } else {
          let v580_6: Path = concat_path(&(v575_11_head),&(v577_6_head));
          let v580_11: Space = routine_82(c, &(v580_6), &(*p0), &(v577_6_tail));
          drop(v580_6);
          compose(&(v578_10),&(v580_11))
        };
        drop(v578_10);
        let v578_13: Space = unite(&(v578_8),&(v578_12));
        v577_6.join_into((v578_13).clone());
      }
      drop(v577_6_cursor);
      compose(&(v576_5),&(v577_6))
    };
    drop(v576_5);
    let v576_8: Space = intersect(&(*CONSTANT_7),&(v576_2));
    drop(v576_2);
    let v576_9: Space = if has_head(&(v576_8)) { singleton(&[]) } else { Space::new() };
    drop(v576_8);
    let v576_11: Space = if (v576_9).is_empty() { Space::new() } else {
      let mut v581_10 = Space::new();
      let mut v581_10_cursor = (v575_11_tail).read_zipper();
      for v581_10_byte in v581_10_cursor.child_mask().iter() {
        v581_10_cursor.descend_to_byte(v581_10_byte);
        let v581_10_tail = v581_10_cursor.make_map();
        v581_10_cursor.ascend(1);
        let v581_10_head = Path::from_slice(&[v581_10_byte]);
        let v582_2: Space = singleton(&(v581_10_head));
        let v582_3: Space = intersect(&(*CONSTANT_7),&(v582_2));
        let v582_4: Space = if has_head(&(v582_3)) { singleton(&[]) } else { Space::new() };
        drop(v582_3);
        let v582_5: Space = subtract(&(*CONSTANT_0),&(v582_4));
        drop(v582_4);
        let v582_7: Space = if (v582_5).is_empty() { Space::new() } else {
          let v583_6: Space = routine_100(c, &(v581_10_head), &(*p0), &(v575_11_head), &(v581_10_tail));
          compose(&(v582_5),&(v583_6))
        };
        drop(v582_5);
        let v582_8: Space = intersect(&(*CONSTANT_7),&(v582_2));
        drop(v582_2);
        let v582_9: Space = if has_head(&(v582_8)) { singleton(&[]) } else { Space::new() };
        drop(v582_8);
        let v582_11: Space = if (v582_9).is_empty() { Space::new() } else {
          let v584_10: Space = routine_101(c, &(v581_10_head), &(*p0), &(v575_11_head), &(v581_10_tail));
          compose(&(v582_9),&(v584_10))
        };
        drop(v582_9);
        let v582_12: Space = unite(&(v582_7),&(v582_11));
        v581_10.join_into((v582_12).clone());
      }
      drop(v581_10_cursor);
      compose(&(v576_9),&(v581_10))
    };
    drop(v576_9);
    let v576_12: Space = unite(&(v576_7),&(v576_11));
    v575_11.join_into((v576_12).clone());
  }
  drop(v575_11_cursor);
  (v575_11).clone()
}

fn routine_59(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v585_8 = Space::new();
  let mut v585_8_cursor = (*s0).read_zipper();
  for v585_8_byte in v585_8_cursor.child_mask().iter() {
    v585_8_cursor.descend_to_byte(v585_8_byte);
    let v585_8_tail = v585_8_cursor.make_map();
    v585_8_cursor.ascend(1);
    let v585_8_head = Path::from_slice(&[v585_8_byte]);
    let v586_2: Space = singleton(&(v585_8_head));
    let v586_3: Space = intersect(&(*CONSTANT_7),&(v586_2));
    let v586_4: Space = if has_head(&(v586_3)) { singleton(&[]) } else { Space::new() };
    drop(v586_3);
    let v586_5: Space = subtract(&(*CONSTANT_0),&(v586_4));
    drop(v586_4);
    let v586_8: Space = if (v586_5).is_empty() { Space::new() } else {
      let v587_6: Path = concat_path(&(*p0),&(v585_8_head));
      let v587_7: Space = routine_59(c, &(v587_6), &(v585_8_tail));
      compose(&(v586_5),&(v587_7))
    };
    drop(v586_5);
    let v586_9: Space = intersect(&(*CONSTANT_7),&(v586_2));
    drop(v586_2);
    let v586_10: Space = if has_head(&(v586_9)) { singleton(&[]) } else { Space::new() };
    drop(v586_9);
    let v586_12: Space = if (v586_10).is_empty() { Space::new() } else {
      let v588_6: Path = concat_path(&(*p0),&(v585_8_head));
      let mut v588_11 = Space::new();
      let mut v588_11_cursor = (v585_8_tail).read_zipper();
      for v588_11_byte in v588_11_cursor.child_mask().iter() {
        v588_11_cursor.descend_to_byte(v588_11_byte);
        let v588_11_tail = v588_11_cursor.make_map();
        v588_11_cursor.ascend(1);
        let v588_11_head = Path::from_slice(&[v588_11_byte]);
        let v589_2: Space = singleton(&(v588_11_head));
        let v589_3: Space = intersect(&(*CONSTANT_7),&(v589_2));
        let v589_4: Space = if has_head(&(v589_3)) { singleton(&[]) } else { Space::new() };
        drop(v589_3);
        let v589_5: Space = subtract(&(*CONSTANT_0),&(v589_4));
        drop(v589_4);
        let v589_7: Space = if (v589_5).is_empty() { Space::new() } else {
          let v590_6: Space = routine_102(c, &(v588_11_head), &(v588_6), &(v588_11_tail));
          compose(&(v589_5),&(v590_6))
        };
        drop(v589_5);
        let v589_8: Space = intersect(&(*CONSTANT_7),&(v589_2));
        drop(v589_2);
        let v589_9: Space = if has_head(&(v589_8)) { singleton(&[]) } else { Space::new() };
        drop(v589_8);
        let v589_11: Space = if (v589_9).is_empty() { Space::new() } else {
          let v591_10: Space = routine_103(c, &(v588_11_head), &(v588_6), &(v588_11_tail));
          compose(&(v589_9),&(v591_10))
        };
        drop(v589_9);
        let v589_12: Space = unite(&(v589_7),&(v589_11));
        v588_11.join_into((v589_12).clone());
      }
      drop(v588_11_cursor);
      drop(v588_6);
      compose(&(v586_10),&(v588_11))
    };
    drop(v586_10);
    let v586_13: Space = unite(&(v586_8),&(v586_12));
    v585_8.join_into((v586_13).clone());
  }
  drop(v585_8_cursor);
  (v585_8).clone()
}

fn routine_60(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v592_7 = Space::new();
  let mut v592_7_cursor = (*s0).read_zipper();
  for v592_7_byte in v592_7_cursor.child_mask().iter() {
    v592_7_cursor.descend_to_byte(v592_7_byte);
    let v592_7_tail = v592_7_cursor.make_map();
    v592_7_cursor.ascend(1);
    let v592_7_head = Path::from_slice(&[v592_7_byte]);
    let v593_2: Space = singleton(&(v592_7_head));
    let v593_3: Space = intersect(&(*CONSTANT_7),&(v593_2));
    let v593_4: Space = if has_head(&(v593_3)) { singleton(&[]) } else { Space::new() };
    drop(v593_3);
    let v593_5: Space = subtract(&(*CONSTANT_0),&(v593_4));
    drop(v593_4);
    let v593_8: Space = if (v593_5).is_empty() { Space::new() } else {
      let v594_6: Path = concat_path(&(*p0),&(v592_7_head));
      let v594_7: Space = routine_60(c, &(v594_6), &(*p1), &(v592_7_tail), &(*s1));
      compose(&(v593_5),&(v594_7))
    };
    drop(v593_5);
    let v593_9: Space = intersect(&(*CONSTANT_7),&(v593_2));
    drop(v593_2);
    let v593_10: Space = if has_head(&(v593_9)) { singleton(&[]) } else { Space::new() };
    drop(v593_9);
    let v593_14: Space = if (v593_10).is_empty() { Space::new() } else {
      let v595_6: Path = concat_path(&(*p0),&(v592_7_head));
      let v595_11: Space = unwrap(&(v592_7_tail),&(*p1));
      let v595_12: Space = wrap(&(v595_11),&(v595_6));
      drop(v595_6);
      drop(v595_11);
      let v595_13: Space = compose(&(v595_12),&(*s1));
      drop(v595_12);
      compose(&(v593_10),&(v595_13))
    };
    drop(v593_10);
    let v593_15: Space = unite(&(v593_8),&(v593_14));
    drop(v593_14);
    v592_7.join_into((v593_15).clone());
  }
  drop(v592_7_cursor);
  (v592_7).clone()
}

fn routine_61(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v596_4: Space = unwrap(&(*s0),&(*p1));
  let v596_5: Space = wrap(&(v596_4),&(*p0));
  drop(v596_4);
  let v596_6: Space = if (v596_5).is_empty() { Space::new() } else {
    compose(&(v596_5),&(*s1))
  };
  drop(v596_5);
  (v596_6).clone()
}

fn routine_62(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v598_8 = Space::new();
  let mut v598_8_cursor = (*s0).read_zipper();
  for v598_8_byte in v598_8_cursor.child_mask().iter() {
    v598_8_cursor.descend_to_byte(v598_8_byte);
    let v598_8_tail = v598_8_cursor.make_map();
    v598_8_cursor.ascend(1);
    let v598_8_head = Path::from_slice(&[v598_8_byte]);
    let v599_2: Space = singleton(&(v598_8_head));
    let v599_3: Space = intersect(&(*CONSTANT_7),&(v599_2));
    let v599_4: Space = if has_head(&(v599_3)) { singleton(&[]) } else { Space::new() };
    drop(v599_3);
    let v599_5: Space = subtract(&(*CONSTANT_0),&(v599_4));
    drop(v599_4);
    let v599_8: Space = if (v599_5).is_empty() { Space::new() } else {
      let v600_6: Path = concat_path(&(*p0),&(v598_8_head));
      let v600_7: Space = routine_62(c, &(v600_6), &(v598_8_tail));
      compose(&(v599_5),&(v600_7))
    };
    drop(v599_5);
    let v599_9: Space = intersect(&(*CONSTANT_7),&(v599_2));
    drop(v599_2);
    let v599_10: Space = if has_head(&(v599_9)) { singleton(&[]) } else { Space::new() };
    drop(v599_9);
    let v599_12: Space = if (v599_10).is_empty() { Space::new() } else {
      let v601_6: Path = concat_path(&(*p0),&(v598_8_head));
      let mut v601_11 = Space::new();
      let mut v601_11_cursor = (v598_8_tail).read_zipper();
      for v601_11_byte in v601_11_cursor.child_mask().iter() {
        v601_11_cursor.descend_to_byte(v601_11_byte);
        let v601_11_tail = v601_11_cursor.make_map();
        v601_11_cursor.ascend(1);
        let v601_11_head = Path::from_slice(&[v601_11_byte]);
        let v602_2: Space = singleton(&(v601_11_head));
        let v602_3: Space = intersect(&(*CONSTANT_7),&(v602_2));
        let v602_4: Space = if has_head(&(v602_3)) { singleton(&[]) } else { Space::new() };
        drop(v602_3);
        let v602_5: Space = subtract(&(*CONSTANT_0),&(v602_4));
        drop(v602_4);
        let v602_7: Space = if (v602_5).is_empty() { Space::new() } else {
          let v603_6: Space = routine_104(c, &(v601_11_head), &(v601_6), &(v601_11_tail));
          compose(&(v602_5),&(v603_6))
        };
        drop(v602_5);
        let v602_8: Space = intersect(&(*CONSTANT_7),&(v602_2));
        drop(v602_2);
        let v602_9: Space = if has_head(&(v602_8)) { singleton(&[]) } else { Space::new() };
        drop(v602_8);
        let v602_11: Space = if (v602_9).is_empty() { Space::new() } else {
          let v604_10: Space = routine_105(c, &(v601_11_head), &(v601_6), &(v601_11_tail));
          compose(&(v602_9),&(v604_10))
        };
        drop(v602_9);
        let v602_12: Space = unite(&(v602_7),&(v602_11));
        v601_11.join_into((v602_12).clone());
      }
      drop(v601_11_cursor);
      drop(v601_6);
      compose(&(v599_10),&(v601_11))
    };
    drop(v599_10);
    let v599_13: Space = unite(&(v599_8),&(v599_12));
    v598_8.join_into((v599_13).clone());
  }
  drop(v598_8_cursor);
  (v598_8).clone()
}

fn routine_63(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v605_6 = Space::new();
  let mut v605_6_cursor = (*s0).read_zipper();
  for v605_6_byte in v605_6_cursor.child_mask().iter() {
    v605_6_cursor.descend_to_byte(v605_6_byte);
    let v605_6_tail = v605_6_cursor.make_map();
    v605_6_cursor.ascend(1);
    let v605_6_head = Path::from_slice(&[v605_6_byte]);
    let v606_2: Space = singleton(&(v605_6_head));
    let v606_3: Space = intersect(&(*CONSTANT_7),&(v606_2));
    let v606_4: Space = if has_head(&(v606_3)) { singleton(&[]) } else { Space::new() };
    drop(v606_3);
    let v606_5: Space = subtract(&(*CONSTANT_0),&(v606_4));
    drop(v606_4);
    let v606_8: Space = if (v606_5).is_empty() { Space::new() } else {
      let v607_6: Path = concat_path(&(*p0),&(v605_6_head));
      let v607_7: Space = routine_63(c, &(v607_6), &(v605_6_tail), &(*s1));
      compose(&(v606_5),&(v607_7))
    };
    drop(v606_5);
    let v606_9: Space = intersect(&(*CONSTANT_7),&(v606_2));
    drop(v606_2);
    let v606_10: Space = if has_head(&(v606_9)) { singleton(&[]) } else { Space::new() };
    drop(v606_9);
    let v606_12: Space = if (v606_10).is_empty() { Space::new() } else {
      let v608_6: Path = concat_path(&(*p0),&(v605_6_head));
      let v608_11: Space = routine_83(c, &(v608_6), &(*s1));
      drop(v608_6);
      compose(&(v606_10),&(v608_11))
    };
    drop(v606_10);
    let v606_13: Space = unite(&(v606_8),&(v606_12));
    v605_6.join_into((v606_13).clone());
  }
  drop(v605_6_cursor);
  (v605_6).clone()
}

fn routine_64(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v609_4: Space = singleton(&(*p0));
  let v609_5: Space = intersect(&(*CONSTANT_8),&(v609_4));
  let v609_29: Space = if (v609_5).is_empty() { Space::new() } else {
    let v610_7: Space = unwrap(&(*s1),&(*CONSTANT_22));
    let v610_10: Space = if (v610_7).is_empty() { Space::new() } else {
      let v611_9: Space = unwrap(&(*s1),&(*CONSTANT_23));
      compose(&(v610_7),&(v611_9))
    };
    let v610_13: Space = if (v610_10).is_empty() { Space::new() } else {
      let v612_12: Space = unwrap(&(*s1),&(*CONSTANT_24));
      compose(&(v610_10),&(v612_12))
    };
    drop(v610_10);
    let v610_16: Space = if (v610_13).is_empty() { Space::new() } else {
      let v613_15: Space = unwrap(&(*s1),&(*CONSTANT_25));
      compose(&(v610_13),&(v613_15))
    };
    drop(v610_13);
    let v610_19: Space = if (v610_16).is_empty() { Space::new() } else {
      let v614_18: Space = unwrap(&(*s1),&(*CONSTANT_26));
      compose(&(v610_16),&(v614_18))
    };
    drop(v610_16);
    let v610_22: Space = if (v610_19).is_empty() { Space::new() } else {
      let v615_21: Space = unwrap(&(*s1),&(*CONSTANT_27));
      compose(&(v610_19),&(v615_21))
    };
    drop(v610_19);
    let v610_25: Space = if (v610_22).is_empty() { Space::new() } else {
      let v616_24: Space = unwrap(&(*s1),&(*CONSTANT_28));
      compose(&(v610_22),&(v616_24))
    };
    drop(v610_22);
    let v610_28: Space = if (v610_25).is_empty() { Space::new() } else {
      let v617_27: Space = unwrap(&(*s1),&(*CONSTANT_29));
      compose(&(v610_25),&(v617_27))
    };
    drop(v610_25);
    compose(&(v609_5),&(v610_28))
  };
  drop(v609_5);
  let v609_31: Space = intersect(&(*CONSTANT_9),&(v609_4));
  let v609_41: Space = if (v609_31).is_empty() { Space::new() } else {
    let v618_33: Space = unwrap(&(*s1),&(*CONSTANT_30));
    let v618_34: Space = if (v618_33).is_empty() { Space::new() } else {
      let v619_9: Space = unwrap(&(*s1),&(*CONSTANT_23));
      compose(&(v618_33),&(v619_9))
    };
    let v618_35: Space = if (v618_34).is_empty() { Space::new() } else {
      let v620_12: Space = unwrap(&(*s1),&(*CONSTANT_24));
      compose(&(v618_34),&(v620_12))
    };
    drop(v618_34);
    let v618_36: Space = if (v618_35).is_empty() { Space::new() } else {
      let v621_15: Space = unwrap(&(*s1),&(*CONSTANT_25));
      compose(&(v618_35),&(v621_15))
    };
    drop(v618_35);
    let v618_37: Space = if (v618_36).is_empty() { Space::new() } else {
      let v622_18: Space = unwrap(&(*s1),&(*CONSTANT_26));
      compose(&(v618_36),&(v622_18))
    };
    drop(v618_36);
    let v618_38: Space = if (v618_37).is_empty() { Space::new() } else {
      let v623_21: Space = unwrap(&(*s1),&(*CONSTANT_27));
      compose(&(v618_37),&(v623_21))
    };
    drop(v618_37);
    let v618_39: Space = if (v618_38).is_empty() { Space::new() } else {
      let v624_24: Space = unwrap(&(*s1),&(*CONSTANT_28));
      compose(&(v618_38),&(v624_24))
    };
    drop(v618_38);
    let v618_40: Space = if (v618_39).is_empty() { Space::new() } else {
      let v625_27: Space = unwrap(&(*s1),&(*CONSTANT_29));
      compose(&(v618_39),&(v625_27))
    };
    drop(v618_39);
    compose(&(v609_31),&(v618_40))
  };
  drop(v609_31);
  let v609_42: Space = unite(&(v609_29),&(v609_41));
  drop(v609_29);
  drop(v609_41);
  let v609_44: Space = intersect(&(*CONSTANT_10),&(v609_4));
  let v609_52: Space = if (v609_44).is_empty() { Space::new() } else {
    let v626_33: Space = unwrap(&(*s1),&(*CONSTANT_30));
    let v626_45: Space = if (v626_33).is_empty() { Space::new() } else {
      let v627_7: Space = unwrap(&(*s1),&(*CONSTANT_22));
      compose(&(v626_33),&(v627_7))
    };
    drop(v626_33);
    let v626_46: Space = if (v626_45).is_empty() { Space::new() } else {
      let v628_12: Space = unwrap(&(*s1),&(*CONSTANT_24));
      compose(&(v626_45),&(v628_12))
    };
    let v626_47: Space = if (v626_46).is_empty() { Space::new() } else {
      let v629_15: Space = unwrap(&(*s1),&(*CONSTANT_25));
      compose(&(v626_46),&(v629_15))
    };
    drop(v626_46);
    let v626_48: Space = if (v626_47).is_empty() { Space::new() } else {
      let v630_18: Space = unwrap(&(*s1),&(*CONSTANT_26));
      compose(&(v626_47),&(v630_18))
    };
    drop(v626_47);
    let v626_49: Space = if (v626_48).is_empty() { Space::new() } else {
      let v631_21: Space = unwrap(&(*s1),&(*CONSTANT_27));
      compose(&(v626_48),&(v631_21))
    };
    drop(v626_48);
    let v626_50: Space = if (v626_49).is_empty() { Space::new() } else {
      let v632_24: Space = unwrap(&(*s1),&(*CONSTANT_28));
      compose(&(v626_49),&(v632_24))
    };
    drop(v626_49);
    let v626_51: Space = if (v626_50).is_empty() { Space::new() } else {
      let v633_27: Space = unwrap(&(*s1),&(*CONSTANT_29));
      compose(&(v626_50),&(v633_27))
    };
    drop(v626_50);
    compose(&(v609_44),&(v626_51))
  };
  drop(v609_44);
  let v609_53: Space = unite(&(v609_42),&(v609_52));
  drop(v609_42);
  drop(v609_52);
  let v609_55: Space = intersect(&(*CONSTANT_11),&(v609_4));
  let v609_62: Space = if (v609_55).is_empty() { Space::new() } else {
    let v634_33: Space = unwrap(&(*s1),&(*CONSTANT_30));
    let v634_45: Space = if (v634_33).is_empty() { Space::new() } else {
      let v635_7: Space = unwrap(&(*s1),&(*CONSTANT_22));
      compose(&(v634_33),&(v635_7))
    };
    drop(v634_33);
    let v634_56: Space = if (v634_45).is_empty() { Space::new() } else {
      let v636_9: Space = unwrap(&(*s1),&(*CONSTANT_23));
      compose(&(v634_45),&(v636_9))
    };
    drop(v634_45);
    let v634_57: Space = if (v634_56).is_empty() { Space::new() } else {
      let v637_15: Space = unwrap(&(*s1),&(*CONSTANT_25));
      compose(&(v634_56),&(v637_15))
    };
    let v634_58: Space = if (v634_57).is_empty() { Space::new() } else {
      let v638_18: Space = unwrap(&(*s1),&(*CONSTANT_26));
      compose(&(v634_57),&(v638_18))
    };
    drop(v634_57);
    let v634_59: Space = if (v634_58).is_empty() { Space::new() } else {
      let v639_21: Space = unwrap(&(*s1),&(*CONSTANT_27));
      compose(&(v634_58),&(v639_21))
    };
    drop(v634_58);
    let v634_60: Space = if (v634_59).is_empty() { Space::new() } else {
      let v640_24: Space = unwrap(&(*s1),&(*CONSTANT_28));
      compose(&(v634_59),&(v640_24))
    };
    drop(v634_59);
    let v634_61: Space = if (v634_60).is_empty() { Space::new() } else {
      let v641_27: Space = unwrap(&(*s1),&(*CONSTANT_29));
      compose(&(v634_60),&(v641_27))
    };
    drop(v634_60);
    compose(&(v609_55),&(v634_61))
  };
  drop(v609_55);
  let v609_63: Space = unite(&(v609_53),&(v609_62));
  drop(v609_53);
  drop(v609_62);
  let v609_65: Space = intersect(&(*CONSTANT_12),&(v609_4));
  let v609_71: Space = if (v609_65).is_empty() { Space::new() } else {
    let v642_33: Space = unwrap(&(*s1),&(*CONSTANT_30));
    let v642_45: Space = if (v642_33).is_empty() { Space::new() } else {
      let v643_7: Space = unwrap(&(*s1),&(*CONSTANT_22));
      compose(&(v642_33),&(v643_7))
    };
    drop(v642_33);
    let v642_56: Space = if (v642_45).is_empty() { Space::new() } else {
      let v644_9: Space = unwrap(&(*s1),&(*CONSTANT_23));
      compose(&(v642_45),&(v644_9))
    };
    drop(v642_45);
    let v642_66: Space = if (v642_56).is_empty() { Space::new() } else {
      let v645_12: Space = unwrap(&(*s1),&(*CONSTANT_24));
      compose(&(v642_56),&(v645_12))
    };
    drop(v642_56);
    let v642_67: Space = if (v642_66).is_empty() { Space::new() } else {
      let v646_18: Space = unwrap(&(*s1),&(*CONSTANT_26));
      compose(&(v642_66),&(v646_18))
    };
    let v642_68: Space = if (v642_67).is_empty() { Space::new() } else {
      let v647_21: Space = unwrap(&(*s1),&(*CONSTANT_27));
      compose(&(v642_67),&(v647_21))
    };
    drop(v642_67);
    let v642_69: Space = if (v642_68).is_empty() { Space::new() } else {
      let v648_24: Space = unwrap(&(*s1),&(*CONSTANT_28));
      compose(&(v642_68),&(v648_24))
    };
    drop(v642_68);
    let v642_70: Space = if (v642_69).is_empty() { Space::new() } else {
      let v649_27: Space = unwrap(&(*s1),&(*CONSTANT_29));
      compose(&(v642_69),&(v649_27))
    };
    drop(v642_69);
    compose(&(v609_65),&(v642_70))
  };
  drop(v609_65);
  let v609_72: Space = unite(&(v609_63),&(v609_71));
  drop(v609_63);
  drop(v609_71);
  let v609_74: Space = intersect(&(*CONSTANT_13),&(v609_4));
  let v609_79: Space = if (v609_74).is_empty() { Space::new() } else {
    let v650_33: Space = unwrap(&(*s1),&(*CONSTANT_30));
    let v650_45: Space = if (v650_33).is_empty() { Space::new() } else {
      let v651_7: Space = unwrap(&(*s1),&(*CONSTANT_22));
      compose(&(v650_33),&(v651_7))
    };
    drop(v650_33);
    let v650_56: Space = if (v650_45).is_empty() { Space::new() } else {
      let v652_9: Space = unwrap(&(*s1),&(*CONSTANT_23));
      compose(&(v650_45),&(v652_9))
    };
    drop(v650_45);
    let v650_66: Space = if (v650_56).is_empty() { Space::new() } else {
      let v653_12: Space = unwrap(&(*s1),&(*CONSTANT_24));
      compose(&(v650_56),&(v653_12))
    };
    drop(v650_56);
    let v650_75: Space = if (v650_66).is_empty() { Space::new() } else {
      let v654_15: Space = unwrap(&(*s1),&(*CONSTANT_25));
      compose(&(v650_66),&(v654_15))
    };
    drop(v650_66);
    let v650_76: Space = if (v650_75).is_empty() { Space::new() } else {
      let v655_21: Space = unwrap(&(*s1),&(*CONSTANT_27));
      compose(&(v650_75),&(v655_21))
    };
    let v650_77: Space = if (v650_76).is_empty() { Space::new() } else {
      let v656_24: Space = unwrap(&(*s1),&(*CONSTANT_28));
      compose(&(v650_76),&(v656_24))
    };
    drop(v650_76);
    let v650_78: Space = if (v650_77).is_empty() { Space::new() } else {
      let v657_27: Space = unwrap(&(*s1),&(*CONSTANT_29));
      compose(&(v650_77),&(v657_27))
    };
    drop(v650_77);
    compose(&(v609_74),&(v650_78))
  };
  drop(v609_74);
  let v609_80: Space = unite(&(v609_72),&(v609_79));
  drop(v609_72);
  drop(v609_79);
  let v609_82: Space = intersect(&(*CONSTANT_14),&(v609_4));
  let v609_86: Space = if (v609_82).is_empty() { Space::new() } else {
    let v658_33: Space = unwrap(&(*s1),&(*CONSTANT_30));
    let v658_45: Space = if (v658_33).is_empty() { Space::new() } else {
      let v659_7: Space = unwrap(&(*s1),&(*CONSTANT_22));
      compose(&(v658_33),&(v659_7))
    };
    drop(v658_33);
    let v658_56: Space = if (v658_45).is_empty() { Space::new() } else {
      let v660_9: Space = unwrap(&(*s1),&(*CONSTANT_23));
      compose(&(v658_45),&(v660_9))
    };
    drop(v658_45);
    let v658_66: Space = if (v658_56).is_empty() { Space::new() } else {
      let v661_12: Space = unwrap(&(*s1),&(*CONSTANT_24));
      compose(&(v658_56),&(v661_12))
    };
    drop(v658_56);
    let v658_75: Space = if (v658_66).is_empty() { Space::new() } else {
      let v662_15: Space = unwrap(&(*s1),&(*CONSTANT_25));
      compose(&(v658_66),&(v662_15))
    };
    drop(v658_66);
    let v658_83: Space = if (v658_75).is_empty() { Space::new() } else {
      let v663_18: Space = unwrap(&(*s1),&(*CONSTANT_26));
      compose(&(v658_75),&(v663_18))
    };
    drop(v658_75);
    let v658_84: Space = if (v658_83).is_empty() { Space::new() } else {
      let v664_24: Space = unwrap(&(*s1),&(*CONSTANT_28));
      compose(&(v658_83),&(v664_24))
    };
    let v658_85: Space = if (v658_84).is_empty() { Space::new() } else {
      let v665_27: Space = unwrap(&(*s1),&(*CONSTANT_29));
      compose(&(v658_84),&(v665_27))
    };
    drop(v658_84);
    compose(&(v609_82),&(v658_85))
  };
  drop(v609_82);
  let v609_87: Space = unite(&(v609_80),&(v609_86));
  drop(v609_80);
  drop(v609_86);
  let v609_89: Space = intersect(&(*CONSTANT_15),&(v609_4));
  let v609_92: Space = if (v609_89).is_empty() { Space::new() } else {
    let v666_33: Space = unwrap(&(*s1),&(*CONSTANT_30));
    let v666_45: Space = if (v666_33).is_empty() { Space::new() } else {
      let v667_7: Space = unwrap(&(*s1),&(*CONSTANT_22));
      compose(&(v666_33),&(v667_7))
    };
    drop(v666_33);
    let v666_56: Space = if (v666_45).is_empty() { Space::new() } else {
      let v668_9: Space = unwrap(&(*s1),&(*CONSTANT_23));
      compose(&(v666_45),&(v668_9))
    };
    drop(v666_45);
    let v666_66: Space = if (v666_56).is_empty() { Space::new() } else {
      let v669_12: Space = unwrap(&(*s1),&(*CONSTANT_24));
      compose(&(v666_56),&(v669_12))
    };
    drop(v666_56);
    let v666_75: Space = if (v666_66).is_empty() { Space::new() } else {
      let v670_15: Space = unwrap(&(*s1),&(*CONSTANT_25));
      compose(&(v666_66),&(v670_15))
    };
    drop(v666_66);
    let v666_83: Space = if (v666_75).is_empty() { Space::new() } else {
      let v671_18: Space = unwrap(&(*s1),&(*CONSTANT_26));
      compose(&(v666_75),&(v671_18))
    };
    drop(v666_75);
    let v666_90: Space = if (v666_83).is_empty() { Space::new() } else {
      let v672_21: Space = unwrap(&(*s1),&(*CONSTANT_27));
      compose(&(v666_83),&(v672_21))
    };
    drop(v666_83);
    let v666_91: Space = if (v666_90).is_empty() { Space::new() } else {
      let v673_27: Space = unwrap(&(*s1),&(*CONSTANT_29));
      compose(&(v666_90),&(v673_27))
    };
    compose(&(v609_89),&(v666_91))
  };
  drop(v609_89);
  let v609_93: Space = unite(&(v609_87),&(v609_92));
  drop(v609_87);
  drop(v609_92);
  let v609_95: Space = intersect(&(*CONSTANT_16),&(v609_4));
  drop(v609_4);
  let v609_97: Space = if (v609_95).is_empty() { Space::new() } else {
    let v674_33: Space = unwrap(&(*s1),&(*CONSTANT_30));
    let v674_45: Space = if (v674_33).is_empty() { Space::new() } else {
      let v675_7: Space = unwrap(&(*s1),&(*CONSTANT_22));
      compose(&(v674_33),&(v675_7))
    };
    drop(v674_33);
    let v674_56: Space = if (v674_45).is_empty() { Space::new() } else {
      let v676_9: Space = unwrap(&(*s1),&(*CONSTANT_23));
      compose(&(v674_45),&(v676_9))
    };
    drop(v674_45);
    let v674_66: Space = if (v674_56).is_empty() { Space::new() } else {
      let v677_12: Space = unwrap(&(*s1),&(*CONSTANT_24));
      compose(&(v674_56),&(v677_12))
    };
    drop(v674_56);
    let v674_75: Space = if (v674_66).is_empty() { Space::new() } else {
      let v678_15: Space = unwrap(&(*s1),&(*CONSTANT_25));
      compose(&(v674_66),&(v678_15))
    };
    drop(v674_66);
    let v674_83: Space = if (v674_75).is_empty() { Space::new() } else {
      let v679_18: Space = unwrap(&(*s1),&(*CONSTANT_26));
      compose(&(v674_75),&(v679_18))
    };
    drop(v674_75);
    let v674_90: Space = if (v674_83).is_empty() { Space::new() } else {
      let v680_21: Space = unwrap(&(*s1),&(*CONSTANT_27));
      compose(&(v674_83),&(v680_21))
    };
    drop(v674_83);
    let v674_96: Space = if (v674_90).is_empty() { Space::new() } else {
      let v681_24: Space = unwrap(&(*s1),&(*CONSTANT_28));
      compose(&(v674_90),&(v681_24))
    };
    drop(v674_90);
    compose(&(v609_95),&(v674_96))
  };
  drop(v609_95);
  let v609_98: Space = unite(&(v609_93),&(v609_97));
  drop(v609_93);
  drop(v609_97);
  (v609_98).clone()
}

fn routine_65(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v682_9 = Space::new();
  let mut v682_9_cursor = (*s0).read_zipper();
  for v682_9_byte in v682_9_cursor.child_mask().iter() {
    v682_9_cursor.descend_to_byte(v682_9_byte);
    let v682_9_tail = v682_9_cursor.make_map();
    v682_9_cursor.ascend(1);
    let v682_9_head = Path::from_slice(&[v682_9_byte]);
    let v683_2: Space = singleton(&(v682_9_head));
    let v683_3: Space = intersect(&(*CONSTANT_7),&(v683_2));
    let v683_4: Space = if has_head(&(v683_3)) { singleton(&[]) } else { Space::new() };
    drop(v683_3);
    let v683_5: Space = subtract(&(*CONSTANT_0),&(v683_4));
    drop(v683_4);
    let v683_8: Space = if (v683_5).is_empty() { Space::new() } else {
      let v684_6: Path = concat_path(&(*p0),&(v682_9_head));
      let v684_7: Space = routine_65(c, &(v684_6), &(*p1), &(v682_9_tail));
      compose(&(v683_5),&(v684_7))
    };
    drop(v683_5);
    let v683_9: Space = intersect(&(*CONSTANT_7),&(v683_2));
    drop(v683_2);
    let v683_10: Space = if has_head(&(v683_9)) { singleton(&[]) } else { Space::new() };
    drop(v683_9);
    let v683_12: Space = if (v683_10).is_empty() { Space::new() } else {
      let v685_6: Path = concat_path(&(*p0),&(v682_9_head));
      let mut v685_11 = Space::new();
      let mut v685_11_cursor = (v682_9_tail).read_zipper();
      for v685_11_byte in v685_11_cursor.child_mask().iter() {
        v685_11_cursor.descend_to_byte(v685_11_byte);
        let v685_11_tail = v685_11_cursor.make_map();
        v685_11_cursor.ascend(1);
        let v685_11_head = Path::from_slice(&[v685_11_byte]);
        let v686_2: Space = singleton(&(v685_11_head));
        let v686_3: Space = intersect(&(*CONSTANT_7),&(v686_2));
        let v686_4: Space = if has_head(&(v686_3)) { singleton(&[]) } else { Space::new() };
        drop(v686_3);
        let v686_5: Space = subtract(&(*CONSTANT_0),&(v686_4));
        drop(v686_4);
        let v686_7: Space = if (v686_5).is_empty() { Space::new() } else {
          let v687_6: Space = routine_84(c, &(v685_11_head), &(*p1), &(v685_6), &(v685_11_tail));
          compose(&(v686_5),&(v687_6))
        };
        drop(v686_5);
        let v686_8: Space = intersect(&(*CONSTANT_7),&(v686_2));
        drop(v686_2);
        let v686_9: Space = if has_head(&(v686_8)) { singleton(&[]) } else { Space::new() };
        drop(v686_8);
        let v686_11: Space = if (v686_9).is_empty() { Space::new() } else {
          let v688_10: Space = routine_85(c, &(v685_11_head), &(*p1), &(v685_6), &(v685_11_tail));
          compose(&(v686_9),&(v688_10))
        };
        drop(v686_9);
        let v686_12: Space = unite(&(v686_7),&(v686_11));
        v685_11.join_into((v686_12).clone());
      }
      drop(v685_11_cursor);
      drop(v685_6);
      compose(&(v683_10),&(v685_11))
    };
    drop(v683_10);
    let v683_13: Space = unite(&(v683_8),&(v683_12));
    v682_9.join_into((v683_13).clone());
  }
  drop(v682_9_cursor);
  (v682_9).clone()
}

fn routine_66(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v689_12 = Space::new();
  let mut v689_12_cursor = (*s0).read_zipper();
  for v689_12_byte in v689_12_cursor.child_mask().iter() {
    v689_12_cursor.descend_to_byte(v689_12_byte);
    let v689_12_tail = v689_12_cursor.make_map();
    v689_12_cursor.ascend(1);
    let v689_12_head = Path::from_slice(&[v689_12_byte]);
    let v690_2: Space = singleton(&(v689_12_head));
    let v690_3: Space = intersect(&(*CONSTANT_7),&(v690_2));
    let v690_4: Space = if has_head(&(v690_3)) { singleton(&[]) } else { Space::new() };
    drop(v690_3);
    let v690_5: Space = subtract(&(*CONSTANT_0),&(v690_4));
    drop(v690_4);
    let v690_7: Space = if (v690_5).is_empty() { Space::new() } else {
      let mut v691_6 = Space::new();
      let mut v691_6_cursor = (v689_12_tail).read_zipper();
      for v691_6_byte in v691_6_cursor.child_mask().iter() {
        v691_6_cursor.descend_to_byte(v691_6_byte);
        let v691_6_tail = v691_6_cursor.make_map();
        v691_6_cursor.ascend(1);
        let v691_6_head = Path::from_slice(&[v691_6_byte]);
        let v692_2: Space = singleton(&(v691_6_head));
        let v692_3: Space = intersect(&(*CONSTANT_7),&(v692_2));
        let v692_4: Space = if has_head(&(v692_3)) { singleton(&[]) } else { Space::new() };
        drop(v692_3);
        let v692_5: Space = subtract(&(*CONSTANT_0),&(v692_4));
        drop(v692_4);
        let v692_8: Space = if (v692_5).is_empty() { Space::new() } else {
          let v693_6: Path = concat_path(&(v689_12_head),&(v691_6_head));
          let v693_7: Space = routine_84(c, &(v693_6), &(*p1), &(*p0), &(v691_6_tail));
          compose(&(v692_5),&(v693_7))
        };
        drop(v692_5);
        let v692_9: Space = intersect(&(*CONSTANT_7),&(v692_2));
        drop(v692_2);
        let v692_10: Space = if has_head(&(v692_9)) { singleton(&[]) } else { Space::new() };
        drop(v692_9);
        let v692_12: Space = if (v692_10).is_empty() { Space::new() } else {
          let v694_6: Path = concat_path(&(v689_12_head),&(v691_6_head));
          let v694_11: Space = routine_85(c, &(v694_6), &(*p1), &(*p0), &(v691_6_tail));
          drop(v694_6);
          compose(&(v692_10),&(v694_11))
        };
        drop(v692_10);
        let v692_13: Space = unite(&(v692_8),&(v692_12));
        v691_6.join_into((v692_13).clone());
      }
      drop(v691_6_cursor);
      compose(&(v690_5),&(v691_6))
    };
    drop(v690_5);
    let v690_8: Space = intersect(&(*CONSTANT_7),&(v690_2));
    drop(v690_2);
    let v690_9: Space = if has_head(&(v690_8)) { singleton(&[]) } else { Space::new() };
    drop(v690_8);
    let v690_11: Space = if (v690_9).is_empty() { Space::new() } else {
      let mut v695_10 = Space::new();
      let mut v695_10_cursor = (v689_12_tail).read_zipper();
      for v695_10_byte in v695_10_cursor.child_mask().iter() {
        v695_10_cursor.descend_to_byte(v695_10_byte);
        let v695_10_tail = v695_10_cursor.make_map();
        v695_10_cursor.ascend(1);
        let v695_10_head = Path::from_slice(&[v695_10_byte]);
        let v696_2: Space = singleton(&(v695_10_head));
        let v696_3: Space = intersect(&(*CONSTANT_7),&(v696_2));
        let v696_4: Space = if has_head(&(v696_3)) { singleton(&[]) } else { Space::new() };
        drop(v696_3);
        let v696_5: Space = subtract(&(*CONSTANT_0),&(v696_4));
        drop(v696_4);
        let v696_7: Space = if (v696_5).is_empty() { Space::new() } else {
          let v697_6: Space = routine_106(c, &(v695_10_head), &(*p1), &(*p0), &(v689_12_head), &(v695_10_tail));
          compose(&(v696_5),&(v697_6))
        };
        drop(v696_5);
        let v696_8: Space = intersect(&(*CONSTANT_7),&(v696_2));
        drop(v696_2);
        let v696_9: Space = if has_head(&(v696_8)) { singleton(&[]) } else { Space::new() };
        drop(v696_8);
        let v696_11: Space = if (v696_9).is_empty() { Space::new() } else {
          let v698_10: Space = routine_107(c, &(v695_10_head), &(*p1), &(*p0), &(v689_12_head), &(v695_10_tail));
          compose(&(v696_9),&(v698_10))
        };
        drop(v696_9);
        let v696_12: Space = unite(&(v696_7),&(v696_11));
        v695_10.join_into((v696_12).clone());
      }
      drop(v695_10_cursor);
      compose(&(v690_9),&(v695_10))
    };
    drop(v690_9);
    let v690_12: Space = unite(&(v690_7),&(v690_11));
    v689_12.join_into((v690_12).clone());
  }
  drop(v689_12_cursor);
  (v689_12).clone()
}

fn routine_67(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v699_9 = Space::new();
  let mut v699_9_cursor = (*s0).read_zipper();
  for v699_9_byte in v699_9_cursor.child_mask().iter() {
    v699_9_cursor.descend_to_byte(v699_9_byte);
    let v699_9_tail = v699_9_cursor.make_map();
    v699_9_cursor.ascend(1);
    let v699_9_head = Path::from_slice(&[v699_9_byte]);
    let v700_2: Space = singleton(&(v699_9_head));
    let v700_3: Space = intersect(&(*CONSTANT_7),&(v700_2));
    let v700_4: Space = if has_head(&(v700_3)) { singleton(&[]) } else { Space::new() };
    drop(v700_3);
    let v700_5: Space = subtract(&(*CONSTANT_0),&(v700_4));
    drop(v700_4);
    let v700_8: Space = if (v700_5).is_empty() { Space::new() } else {
      let v701_6: Path = concat_path(&(*p0),&(v699_9_head));
      let v701_7: Space = routine_67(c, &(v701_6), &(*p1), &(v699_9_tail));
      compose(&(v700_5),&(v701_7))
    };
    drop(v700_5);
    let v700_9: Space = intersect(&(*CONSTANT_7),&(v700_2));
    drop(v700_2);
    let v700_10: Space = if has_head(&(v700_9)) { singleton(&[]) } else { Space::new() };
    drop(v700_9);
    let v700_12: Space = if (v700_10).is_empty() { Space::new() } else {
      let v702_6: Path = concat_path(&(*p0),&(v699_9_head));
      let mut v702_11 = Space::new();
      let mut v702_11_cursor = (v699_9_tail).read_zipper();
      for v702_11_byte in v702_11_cursor.child_mask().iter() {
        v702_11_cursor.descend_to_byte(v702_11_byte);
        let v702_11_tail = v702_11_cursor.make_map();
        v702_11_cursor.ascend(1);
        let v702_11_head = Path::from_slice(&[v702_11_byte]);
        let v703_2: Space = singleton(&(v702_11_head));
        let v703_3: Space = intersect(&(*CONSTANT_7),&(v703_2));
        let v703_4: Space = if has_head(&(v703_3)) { singleton(&[]) } else { Space::new() };
        drop(v703_3);
        let v703_5: Space = subtract(&(*CONSTANT_0),&(v703_4));
        drop(v703_4);
        let v703_7: Space = if (v703_5).is_empty() { Space::new() } else {
          let v704_6: Space = routine_86(c, &(v702_11_head), &(*p1), &(v702_6), &(v702_11_tail));
          compose(&(v703_5),&(v704_6))
        };
        drop(v703_5);
        let v703_8: Space = intersect(&(*CONSTANT_7),&(v703_2));
        drop(v703_2);
        let v703_9: Space = if has_head(&(v703_8)) { singleton(&[]) } else { Space::new() };
        drop(v703_8);
        let v703_11: Space = if (v703_9).is_empty() { Space::new() } else {
          let v705_10: Space = routine_87(c, &(v702_11_head), &(*p1), &(v702_6), &(v702_11_tail));
          compose(&(v703_9),&(v705_10))
        };
        drop(v703_9);
        let v703_12: Space = unite(&(v703_7),&(v703_11));
        v702_11.join_into((v703_12).clone());
      }
      drop(v702_11_cursor);
      drop(v702_6);
      compose(&(v700_10),&(v702_11))
    };
    drop(v700_10);
    let v700_13: Space = unite(&(v700_8),&(v700_12));
    v699_9.join_into((v700_13).clone());
  }
  drop(v699_9_cursor);
  (v699_9).clone()
}

fn routine_68(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v706_12 = Space::new();
  let mut v706_12_cursor = (*s0).read_zipper();
  for v706_12_byte in v706_12_cursor.child_mask().iter() {
    v706_12_cursor.descend_to_byte(v706_12_byte);
    let v706_12_tail = v706_12_cursor.make_map();
    v706_12_cursor.ascend(1);
    let v706_12_head = Path::from_slice(&[v706_12_byte]);
    let v707_2: Space = singleton(&(v706_12_head));
    let v707_3: Space = intersect(&(*CONSTANT_7),&(v707_2));
    let v707_4: Space = if has_head(&(v707_3)) { singleton(&[]) } else { Space::new() };
    drop(v707_3);
    let v707_5: Space = subtract(&(*CONSTANT_0),&(v707_4));
    drop(v707_4);
    let v707_7: Space = if (v707_5).is_empty() { Space::new() } else {
      let mut v708_6 = Space::new();
      let mut v708_6_cursor = (v706_12_tail).read_zipper();
      for v708_6_byte in v708_6_cursor.child_mask().iter() {
        v708_6_cursor.descend_to_byte(v708_6_byte);
        let v708_6_tail = v708_6_cursor.make_map();
        v708_6_cursor.ascend(1);
        let v708_6_head = Path::from_slice(&[v708_6_byte]);
        let v709_2: Space = singleton(&(v708_6_head));
        let v709_3: Space = intersect(&(*CONSTANT_7),&(v709_2));
        let v709_4: Space = if has_head(&(v709_3)) { singleton(&[]) } else { Space::new() };
        drop(v709_3);
        let v709_5: Space = subtract(&(*CONSTANT_0),&(v709_4));
        drop(v709_4);
        let v709_8: Space = if (v709_5).is_empty() { Space::new() } else {
          let v710_6: Path = concat_path(&(v706_12_head),&(v708_6_head));
          let v710_7: Space = routine_86(c, &(v710_6), &(*p1), &(*p0), &(v708_6_tail));
          compose(&(v709_5),&(v710_7))
        };
        drop(v709_5);
        let v709_9: Space = intersect(&(*CONSTANT_7),&(v709_2));
        drop(v709_2);
        let v709_10: Space = if has_head(&(v709_9)) { singleton(&[]) } else { Space::new() };
        drop(v709_9);
        let v709_12: Space = if (v709_10).is_empty() { Space::new() } else {
          let v711_6: Path = concat_path(&(v706_12_head),&(v708_6_head));
          let v711_11: Space = routine_87(c, &(v711_6), &(*p1), &(*p0), &(v708_6_tail));
          drop(v711_6);
          compose(&(v709_10),&(v711_11))
        };
        drop(v709_10);
        let v709_13: Space = unite(&(v709_8),&(v709_12));
        v708_6.join_into((v709_13).clone());
      }
      drop(v708_6_cursor);
      compose(&(v707_5),&(v708_6))
    };
    drop(v707_5);
    let v707_8: Space = intersect(&(*CONSTANT_7),&(v707_2));
    drop(v707_2);
    let v707_9: Space = if has_head(&(v707_8)) { singleton(&[]) } else { Space::new() };
    drop(v707_8);
    let v707_11: Space = if (v707_9).is_empty() { Space::new() } else {
      let mut v712_10 = Space::new();
      let mut v712_10_cursor = (v706_12_tail).read_zipper();
      for v712_10_byte in v712_10_cursor.child_mask().iter() {
        v712_10_cursor.descend_to_byte(v712_10_byte);
        let v712_10_tail = v712_10_cursor.make_map();
        v712_10_cursor.ascend(1);
        let v712_10_head = Path::from_slice(&[v712_10_byte]);
        let v713_2: Space = singleton(&(v712_10_head));
        let v713_3: Space = intersect(&(*CONSTANT_7),&(v713_2));
        let v713_4: Space = if has_head(&(v713_3)) { singleton(&[]) } else { Space::new() };
        drop(v713_3);
        let v713_5: Space = subtract(&(*CONSTANT_0),&(v713_4));
        drop(v713_4);
        let v713_7: Space = if (v713_5).is_empty() { Space::new() } else {
          let v714_6: Space = routine_108(c, &(v712_10_head), &(*p1), &(*p0), &(v706_12_head), &(v712_10_tail));
          compose(&(v713_5),&(v714_6))
        };
        drop(v713_5);
        let v713_8: Space = intersect(&(*CONSTANT_7),&(v713_2));
        drop(v713_2);
        let v713_9: Space = if has_head(&(v713_8)) { singleton(&[]) } else { Space::new() };
        drop(v713_8);
        let v713_11: Space = if (v713_9).is_empty() { Space::new() } else {
          let v715_10: Space = routine_109(c, &(v712_10_head), &(*p1), &(*p0), &(v706_12_head), &(v712_10_tail));
          compose(&(v713_9),&(v715_10))
        };
        drop(v713_9);
        let v713_12: Space = unite(&(v713_7),&(v713_11));
        v712_10.join_into((v713_12).clone());
      }
      drop(v712_10_cursor);
      compose(&(v707_9),&(v712_10))
    };
    drop(v707_9);
    let v707_12: Space = unite(&(v707_7),&(v707_11));
    v706_12.join_into((v707_12).clone());
  }
  drop(v706_12_cursor);
  (v706_12).clone()
}

fn routine_69(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v716_9 = Space::new();
  let mut v716_9_cursor = (*s0).read_zipper();
  for v716_9_byte in v716_9_cursor.child_mask().iter() {
    v716_9_cursor.descend_to_byte(v716_9_byte);
    let v716_9_tail = v716_9_cursor.make_map();
    v716_9_cursor.ascend(1);
    let v716_9_head = Path::from_slice(&[v716_9_byte]);
    let v717_2: Space = singleton(&(v716_9_head));
    let v717_3: Space = intersect(&(*CONSTANT_7),&(v717_2));
    let v717_4: Space = if has_head(&(v717_3)) { singleton(&[]) } else { Space::new() };
    drop(v717_3);
    let v717_5: Space = subtract(&(*CONSTANT_0),&(v717_4));
    drop(v717_4);
    let v717_8: Space = if (v717_5).is_empty() { Space::new() } else {
      let v718_6: Path = concat_path(&(*p0),&(v716_9_head));
      let v718_7: Space = routine_69(c, &(v718_6), &(*p1), &(v716_9_tail));
      compose(&(v717_5),&(v718_7))
    };
    drop(v717_5);
    let v717_9: Space = intersect(&(*CONSTANT_7),&(v717_2));
    drop(v717_2);
    let v717_10: Space = if has_head(&(v717_9)) { singleton(&[]) } else { Space::new() };
    drop(v717_9);
    let v717_12: Space = if (v717_10).is_empty() { Space::new() } else {
      let v719_6: Path = concat_path(&(*p0),&(v716_9_head));
      let mut v719_11 = Space::new();
      let mut v719_11_cursor = (v716_9_tail).read_zipper();
      for v719_11_byte in v719_11_cursor.child_mask().iter() {
        v719_11_cursor.descend_to_byte(v719_11_byte);
        let v719_11_tail = v719_11_cursor.make_map();
        v719_11_cursor.ascend(1);
        let v719_11_head = Path::from_slice(&[v719_11_byte]);
        let v720_2: Space = singleton(&(v719_11_head));
        let v720_3: Space = intersect(&(*CONSTANT_7),&(v720_2));
        let v720_4: Space = if has_head(&(v720_3)) { singleton(&[]) } else { Space::new() };
        drop(v720_3);
        let v720_5: Space = subtract(&(*CONSTANT_0),&(v720_4));
        drop(v720_4);
        let v720_7: Space = if (v720_5).is_empty() { Space::new() } else {
          let v721_6: Space = routine_88(c, &(v719_11_head), &(*p1), &(v719_6), &(v719_11_tail));
          compose(&(v720_5),&(v721_6))
        };
        drop(v720_5);
        let v720_8: Space = intersect(&(*CONSTANT_7),&(v720_2));
        drop(v720_2);
        let v720_9: Space = if has_head(&(v720_8)) { singleton(&[]) } else { Space::new() };
        drop(v720_8);
        let v720_11: Space = if (v720_9).is_empty() { Space::new() } else {
          let v722_10: Space = routine_89(c, &(v719_11_head), &(*p1), &(v719_6), &(v719_11_tail));
          compose(&(v720_9),&(v722_10))
        };
        drop(v720_9);
        let v720_12: Space = unite(&(v720_7),&(v720_11));
        v719_11.join_into((v720_12).clone());
      }
      drop(v719_11_cursor);
      drop(v719_6);
      compose(&(v717_10),&(v719_11))
    };
    drop(v717_10);
    let v717_13: Space = unite(&(v717_8),&(v717_12));
    v716_9.join_into((v717_13).clone());
  }
  drop(v716_9_cursor);
  (v716_9).clone()
}

fn routine_70(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v723_12 = Space::new();
  let mut v723_12_cursor = (*s0).read_zipper();
  for v723_12_byte in v723_12_cursor.child_mask().iter() {
    v723_12_cursor.descend_to_byte(v723_12_byte);
    let v723_12_tail = v723_12_cursor.make_map();
    v723_12_cursor.ascend(1);
    let v723_12_head = Path::from_slice(&[v723_12_byte]);
    let v724_2: Space = singleton(&(v723_12_head));
    let v724_3: Space = intersect(&(*CONSTANT_7),&(v724_2));
    let v724_4: Space = if has_head(&(v724_3)) { singleton(&[]) } else { Space::new() };
    drop(v724_3);
    let v724_5: Space = subtract(&(*CONSTANT_0),&(v724_4));
    drop(v724_4);
    let v724_7: Space = if (v724_5).is_empty() { Space::new() } else {
      let mut v725_6 = Space::new();
      let mut v725_6_cursor = (v723_12_tail).read_zipper();
      for v725_6_byte in v725_6_cursor.child_mask().iter() {
        v725_6_cursor.descend_to_byte(v725_6_byte);
        let v725_6_tail = v725_6_cursor.make_map();
        v725_6_cursor.ascend(1);
        let v725_6_head = Path::from_slice(&[v725_6_byte]);
        let v726_2: Space = singleton(&(v725_6_head));
        let v726_3: Space = intersect(&(*CONSTANT_7),&(v726_2));
        let v726_4: Space = if has_head(&(v726_3)) { singleton(&[]) } else { Space::new() };
        drop(v726_3);
        let v726_5: Space = subtract(&(*CONSTANT_0),&(v726_4));
        drop(v726_4);
        let v726_8: Space = if (v726_5).is_empty() { Space::new() } else {
          let v727_6: Path = concat_path(&(v723_12_head),&(v725_6_head));
          let v727_7: Space = routine_88(c, &(v727_6), &(*p1), &(*p0), &(v725_6_tail));
          compose(&(v726_5),&(v727_7))
        };
        drop(v726_5);
        let v726_9: Space = intersect(&(*CONSTANT_7),&(v726_2));
        drop(v726_2);
        let v726_10: Space = if has_head(&(v726_9)) { singleton(&[]) } else { Space::new() };
        drop(v726_9);
        let v726_12: Space = if (v726_10).is_empty() { Space::new() } else {
          let v728_6: Path = concat_path(&(v723_12_head),&(v725_6_head));
          let v728_11: Space = routine_89(c, &(v728_6), &(*p1), &(*p0), &(v725_6_tail));
          drop(v728_6);
          compose(&(v726_10),&(v728_11))
        };
        drop(v726_10);
        let v726_13: Space = unite(&(v726_8),&(v726_12));
        v725_6.join_into((v726_13).clone());
      }
      drop(v725_6_cursor);
      compose(&(v724_5),&(v725_6))
    };
    drop(v724_5);
    let v724_8: Space = intersect(&(*CONSTANT_7),&(v724_2));
    drop(v724_2);
    let v724_9: Space = if has_head(&(v724_8)) { singleton(&[]) } else { Space::new() };
    drop(v724_8);
    let v724_11: Space = if (v724_9).is_empty() { Space::new() } else {
      let mut v729_10 = Space::new();
      let mut v729_10_cursor = (v723_12_tail).read_zipper();
      for v729_10_byte in v729_10_cursor.child_mask().iter() {
        v729_10_cursor.descend_to_byte(v729_10_byte);
        let v729_10_tail = v729_10_cursor.make_map();
        v729_10_cursor.ascend(1);
        let v729_10_head = Path::from_slice(&[v729_10_byte]);
        let v730_2: Space = singleton(&(v729_10_head));
        let v730_3: Space = intersect(&(*CONSTANT_7),&(v730_2));
        let v730_4: Space = if has_head(&(v730_3)) { singleton(&[]) } else { Space::new() };
        drop(v730_3);
        let v730_5: Space = subtract(&(*CONSTANT_0),&(v730_4));
        drop(v730_4);
        let v730_7: Space = if (v730_5).is_empty() { Space::new() } else {
          let v731_6: Space = routine_110(c, &(v729_10_head), &(*p1), &(*p0), &(v723_12_head), &(v729_10_tail));
          compose(&(v730_5),&(v731_6))
        };
        drop(v730_5);
        let v730_8: Space = intersect(&(*CONSTANT_7),&(v730_2));
        drop(v730_2);
        let v730_9: Space = if has_head(&(v730_8)) { singleton(&[]) } else { Space::new() };
        drop(v730_8);
        let v730_11: Space = if (v730_9).is_empty() { Space::new() } else {
          let v732_10: Space = routine_111(c, &(v729_10_head), &(*p1), &(*p0), &(v723_12_head), &(v729_10_tail));
          compose(&(v730_9),&(v732_10))
        };
        drop(v730_9);
        let v730_12: Space = unite(&(v730_7),&(v730_11));
        v729_10.join_into((v730_12).clone());
      }
      drop(v729_10_cursor);
      compose(&(v724_9),&(v729_10))
    };
    drop(v724_9);
    let v724_12: Space = unite(&(v724_7),&(v724_11));
    v723_12.join_into((v724_12).clone());
  }
  drop(v723_12_cursor);
  (v723_12).clone()
}

fn routine_71(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v733_9 = Space::new();
  let mut v733_9_cursor = (*s0).read_zipper();
  for v733_9_byte in v733_9_cursor.child_mask().iter() {
    v733_9_cursor.descend_to_byte(v733_9_byte);
    let v733_9_tail = v733_9_cursor.make_map();
    v733_9_cursor.ascend(1);
    let v733_9_head = Path::from_slice(&[v733_9_byte]);
    let v734_2: Space = singleton(&(v733_9_head));
    let v734_3: Space = intersect(&(*CONSTANT_7),&(v734_2));
    let v734_4: Space = if has_head(&(v734_3)) { singleton(&[]) } else { Space::new() };
    drop(v734_3);
    let v734_5: Space = subtract(&(*CONSTANT_0),&(v734_4));
    drop(v734_4);
    let v734_8: Space = if (v734_5).is_empty() { Space::new() } else {
      let v735_6: Path = concat_path(&(*p0),&(v733_9_head));
      let v735_7: Space = routine_71(c, &(v735_6), &(*p1), &(v733_9_tail));
      compose(&(v734_5),&(v735_7))
    };
    drop(v734_5);
    let v734_9: Space = intersect(&(*CONSTANT_7),&(v734_2));
    drop(v734_2);
    let v734_10: Space = if has_head(&(v734_9)) { singleton(&[]) } else { Space::new() };
    drop(v734_9);
    let v734_12: Space = if (v734_10).is_empty() { Space::new() } else {
      let v736_6: Path = concat_path(&(*p0),&(v733_9_head));
      let mut v736_11 = Space::new();
      let mut v736_11_cursor = (v733_9_tail).read_zipper();
      for v736_11_byte in v736_11_cursor.child_mask().iter() {
        v736_11_cursor.descend_to_byte(v736_11_byte);
        let v736_11_tail = v736_11_cursor.make_map();
        v736_11_cursor.ascend(1);
        let v736_11_head = Path::from_slice(&[v736_11_byte]);
        let v737_2: Space = singleton(&(v736_11_head));
        let v737_3: Space = intersect(&(*CONSTANT_7),&(v737_2));
        let v737_4: Space = if has_head(&(v737_3)) { singleton(&[]) } else { Space::new() };
        drop(v737_3);
        let v737_5: Space = subtract(&(*CONSTANT_0),&(v737_4));
        drop(v737_4);
        let v737_7: Space = if (v737_5).is_empty() { Space::new() } else {
          let v738_6: Space = routine_90(c, &(v736_11_head), &(*p1), &(v736_6), &(v736_11_tail));
          compose(&(v737_5),&(v738_6))
        };
        drop(v737_5);
        let v737_8: Space = intersect(&(*CONSTANT_7),&(v737_2));
        drop(v737_2);
        let v737_9: Space = if has_head(&(v737_8)) { singleton(&[]) } else { Space::new() };
        drop(v737_8);
        let v737_11: Space = if (v737_9).is_empty() { Space::new() } else {
          let v739_10: Space = routine_91(c, &(v736_11_head), &(*p1), &(v736_6), &(v736_11_tail));
          compose(&(v737_9),&(v739_10))
        };
        drop(v737_9);
        let v737_12: Space = unite(&(v737_7),&(v737_11));
        v736_11.join_into((v737_12).clone());
      }
      drop(v736_11_cursor);
      drop(v736_6);
      compose(&(v734_10),&(v736_11))
    };
    drop(v734_10);
    let v734_13: Space = unite(&(v734_8),&(v734_12));
    v733_9.join_into((v734_13).clone());
  }
  drop(v733_9_cursor);
  (v733_9).clone()
}

fn routine_72(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v740_12 = Space::new();
  let mut v740_12_cursor = (*s0).read_zipper();
  for v740_12_byte in v740_12_cursor.child_mask().iter() {
    v740_12_cursor.descend_to_byte(v740_12_byte);
    let v740_12_tail = v740_12_cursor.make_map();
    v740_12_cursor.ascend(1);
    let v740_12_head = Path::from_slice(&[v740_12_byte]);
    let v741_2: Space = singleton(&(v740_12_head));
    let v741_3: Space = intersect(&(*CONSTANT_7),&(v741_2));
    let v741_4: Space = if has_head(&(v741_3)) { singleton(&[]) } else { Space::new() };
    drop(v741_3);
    let v741_5: Space = subtract(&(*CONSTANT_0),&(v741_4));
    drop(v741_4);
    let v741_7: Space = if (v741_5).is_empty() { Space::new() } else {
      let mut v742_6 = Space::new();
      let mut v742_6_cursor = (v740_12_tail).read_zipper();
      for v742_6_byte in v742_6_cursor.child_mask().iter() {
        v742_6_cursor.descend_to_byte(v742_6_byte);
        let v742_6_tail = v742_6_cursor.make_map();
        v742_6_cursor.ascend(1);
        let v742_6_head = Path::from_slice(&[v742_6_byte]);
        let v743_2: Space = singleton(&(v742_6_head));
        let v743_3: Space = intersect(&(*CONSTANT_7),&(v743_2));
        let v743_4: Space = if has_head(&(v743_3)) { singleton(&[]) } else { Space::new() };
        drop(v743_3);
        let v743_5: Space = subtract(&(*CONSTANT_0),&(v743_4));
        drop(v743_4);
        let v743_8: Space = if (v743_5).is_empty() { Space::new() } else {
          let v744_6: Path = concat_path(&(v740_12_head),&(v742_6_head));
          let v744_7: Space = routine_90(c, &(v744_6), &(*p1), &(*p0), &(v742_6_tail));
          compose(&(v743_5),&(v744_7))
        };
        drop(v743_5);
        let v743_9: Space = intersect(&(*CONSTANT_7),&(v743_2));
        drop(v743_2);
        let v743_10: Space = if has_head(&(v743_9)) { singleton(&[]) } else { Space::new() };
        drop(v743_9);
        let v743_12: Space = if (v743_10).is_empty() { Space::new() } else {
          let v745_6: Path = concat_path(&(v740_12_head),&(v742_6_head));
          let v745_11: Space = routine_91(c, &(v745_6), &(*p1), &(*p0), &(v742_6_tail));
          drop(v745_6);
          compose(&(v743_10),&(v745_11))
        };
        drop(v743_10);
        let v743_13: Space = unite(&(v743_8),&(v743_12));
        v742_6.join_into((v743_13).clone());
      }
      drop(v742_6_cursor);
      compose(&(v741_5),&(v742_6))
    };
    drop(v741_5);
    let v741_8: Space = intersect(&(*CONSTANT_7),&(v741_2));
    drop(v741_2);
    let v741_9: Space = if has_head(&(v741_8)) { singleton(&[]) } else { Space::new() };
    drop(v741_8);
    let v741_11: Space = if (v741_9).is_empty() { Space::new() } else {
      let mut v746_10 = Space::new();
      let mut v746_10_cursor = (v740_12_tail).read_zipper();
      for v746_10_byte in v746_10_cursor.child_mask().iter() {
        v746_10_cursor.descend_to_byte(v746_10_byte);
        let v746_10_tail = v746_10_cursor.make_map();
        v746_10_cursor.ascend(1);
        let v746_10_head = Path::from_slice(&[v746_10_byte]);
        let v747_2: Space = singleton(&(v746_10_head));
        let v747_3: Space = intersect(&(*CONSTANT_7),&(v747_2));
        let v747_4: Space = if has_head(&(v747_3)) { singleton(&[]) } else { Space::new() };
        drop(v747_3);
        let v747_5: Space = subtract(&(*CONSTANT_0),&(v747_4));
        drop(v747_4);
        let v747_7: Space = if (v747_5).is_empty() { Space::new() } else {
          let v748_6: Space = routine_112(c, &(v746_10_head), &(*p1), &(*p0), &(v740_12_head), &(v746_10_tail));
          compose(&(v747_5),&(v748_6))
        };
        drop(v747_5);
        let v747_8: Space = intersect(&(*CONSTANT_7),&(v747_2));
        drop(v747_2);
        let v747_9: Space = if has_head(&(v747_8)) { singleton(&[]) } else { Space::new() };
        drop(v747_8);
        let v747_11: Space = if (v747_9).is_empty() { Space::new() } else {
          let v749_10: Space = routine_113(c, &(v746_10_head), &(*p1), &(*p0), &(v740_12_head), &(v746_10_tail));
          compose(&(v747_9),&(v749_10))
        };
        drop(v747_9);
        let v747_12: Space = unite(&(v747_7),&(v747_11));
        v746_10.join_into((v747_12).clone());
      }
      drop(v746_10_cursor);
      compose(&(v741_9),&(v746_10))
    };
    drop(v741_9);
    let v741_12: Space = unite(&(v741_7),&(v741_11));
    v740_12.join_into((v741_12).clone());
  }
  drop(v740_12_cursor);
  (v740_12).clone()
}

fn routine_73(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v750_9 = Space::new();
  let mut v750_9_cursor = (*s0).read_zipper();
  for v750_9_byte in v750_9_cursor.child_mask().iter() {
    v750_9_cursor.descend_to_byte(v750_9_byte);
    let v750_9_tail = v750_9_cursor.make_map();
    v750_9_cursor.ascend(1);
    let v750_9_head = Path::from_slice(&[v750_9_byte]);
    let v751_2: Space = singleton(&(v750_9_head));
    let v751_3: Space = intersect(&(*CONSTANT_7),&(v751_2));
    let v751_4: Space = if has_head(&(v751_3)) { singleton(&[]) } else { Space::new() };
    drop(v751_3);
    let v751_5: Space = subtract(&(*CONSTANT_0),&(v751_4));
    drop(v751_4);
    let v751_8: Space = if (v751_5).is_empty() { Space::new() } else {
      let v752_6: Path = concat_path(&(*p0),&(v750_9_head));
      let v752_7: Space = routine_73(c, &(v752_6), &(*p1), &(v750_9_tail));
      compose(&(v751_5),&(v752_7))
    };
    drop(v751_5);
    let v751_9: Space = intersect(&(*CONSTANT_7),&(v751_2));
    drop(v751_2);
    let v751_10: Space = if has_head(&(v751_9)) { singleton(&[]) } else { Space::new() };
    drop(v751_9);
    let v751_12: Space = if (v751_10).is_empty() { Space::new() } else {
      let v753_6: Path = concat_path(&(*p0),&(v750_9_head));
      let mut v753_11 = Space::new();
      let mut v753_11_cursor = (v750_9_tail).read_zipper();
      for v753_11_byte in v753_11_cursor.child_mask().iter() {
        v753_11_cursor.descend_to_byte(v753_11_byte);
        let v753_11_tail = v753_11_cursor.make_map();
        v753_11_cursor.ascend(1);
        let v753_11_head = Path::from_slice(&[v753_11_byte]);
        let v754_2: Space = singleton(&(v753_11_head));
        let v754_3: Space = intersect(&(*CONSTANT_7),&(v754_2));
        let v754_4: Space = if has_head(&(v754_3)) { singleton(&[]) } else { Space::new() };
        drop(v754_3);
        let v754_5: Space = subtract(&(*CONSTANT_0),&(v754_4));
        drop(v754_4);
        let v754_7: Space = if (v754_5).is_empty() { Space::new() } else {
          let v755_6: Space = routine_92(c, &(v753_11_head), &(*p1), &(v753_6), &(v753_11_tail));
          compose(&(v754_5),&(v755_6))
        };
        drop(v754_5);
        let v754_8: Space = intersect(&(*CONSTANT_7),&(v754_2));
        drop(v754_2);
        let v754_9: Space = if has_head(&(v754_8)) { singleton(&[]) } else { Space::new() };
        drop(v754_8);
        let v754_11: Space = if (v754_9).is_empty() { Space::new() } else {
          let v756_10: Space = routine_93(c, &(v753_11_head), &(*p1), &(v753_6), &(v753_11_tail));
          compose(&(v754_9),&(v756_10))
        };
        drop(v754_9);
        let v754_12: Space = unite(&(v754_7),&(v754_11));
        v753_11.join_into((v754_12).clone());
      }
      drop(v753_11_cursor);
      drop(v753_6);
      compose(&(v751_10),&(v753_11))
    };
    drop(v751_10);
    let v751_13: Space = unite(&(v751_8),&(v751_12));
    v750_9.join_into((v751_13).clone());
  }
  drop(v750_9_cursor);
  (v750_9).clone()
}

fn routine_74(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v757_12 = Space::new();
  let mut v757_12_cursor = (*s0).read_zipper();
  for v757_12_byte in v757_12_cursor.child_mask().iter() {
    v757_12_cursor.descend_to_byte(v757_12_byte);
    let v757_12_tail = v757_12_cursor.make_map();
    v757_12_cursor.ascend(1);
    let v757_12_head = Path::from_slice(&[v757_12_byte]);
    let v758_2: Space = singleton(&(v757_12_head));
    let v758_3: Space = intersect(&(*CONSTANT_7),&(v758_2));
    let v758_4: Space = if has_head(&(v758_3)) { singleton(&[]) } else { Space::new() };
    drop(v758_3);
    let v758_5: Space = subtract(&(*CONSTANT_0),&(v758_4));
    drop(v758_4);
    let v758_7: Space = if (v758_5).is_empty() { Space::new() } else {
      let mut v759_6 = Space::new();
      let mut v759_6_cursor = (v757_12_tail).read_zipper();
      for v759_6_byte in v759_6_cursor.child_mask().iter() {
        v759_6_cursor.descend_to_byte(v759_6_byte);
        let v759_6_tail = v759_6_cursor.make_map();
        v759_6_cursor.ascend(1);
        let v759_6_head = Path::from_slice(&[v759_6_byte]);
        let v760_2: Space = singleton(&(v759_6_head));
        let v760_3: Space = intersect(&(*CONSTANT_7),&(v760_2));
        let v760_4: Space = if has_head(&(v760_3)) { singleton(&[]) } else { Space::new() };
        drop(v760_3);
        let v760_5: Space = subtract(&(*CONSTANT_0),&(v760_4));
        drop(v760_4);
        let v760_8: Space = if (v760_5).is_empty() { Space::new() } else {
          let v761_6: Path = concat_path(&(v757_12_head),&(v759_6_head));
          let v761_7: Space = routine_92(c, &(v761_6), &(*p1), &(*p0), &(v759_6_tail));
          compose(&(v760_5),&(v761_7))
        };
        drop(v760_5);
        let v760_9: Space = intersect(&(*CONSTANT_7),&(v760_2));
        drop(v760_2);
        let v760_10: Space = if has_head(&(v760_9)) { singleton(&[]) } else { Space::new() };
        drop(v760_9);
        let v760_12: Space = if (v760_10).is_empty() { Space::new() } else {
          let v762_6: Path = concat_path(&(v757_12_head),&(v759_6_head));
          let v762_11: Space = routine_93(c, &(v762_6), &(*p1), &(*p0), &(v759_6_tail));
          drop(v762_6);
          compose(&(v760_10),&(v762_11))
        };
        drop(v760_10);
        let v760_13: Space = unite(&(v760_8),&(v760_12));
        v759_6.join_into((v760_13).clone());
      }
      drop(v759_6_cursor);
      compose(&(v758_5),&(v759_6))
    };
    drop(v758_5);
    let v758_8: Space = intersect(&(*CONSTANT_7),&(v758_2));
    drop(v758_2);
    let v758_9: Space = if has_head(&(v758_8)) { singleton(&[]) } else { Space::new() };
    drop(v758_8);
    let v758_11: Space = if (v758_9).is_empty() { Space::new() } else {
      let mut v763_10 = Space::new();
      let mut v763_10_cursor = (v757_12_tail).read_zipper();
      for v763_10_byte in v763_10_cursor.child_mask().iter() {
        v763_10_cursor.descend_to_byte(v763_10_byte);
        let v763_10_tail = v763_10_cursor.make_map();
        v763_10_cursor.ascend(1);
        let v763_10_head = Path::from_slice(&[v763_10_byte]);
        let v764_2: Space = singleton(&(v763_10_head));
        let v764_3: Space = intersect(&(*CONSTANT_7),&(v764_2));
        let v764_4: Space = if has_head(&(v764_3)) { singleton(&[]) } else { Space::new() };
        drop(v764_3);
        let v764_5: Space = subtract(&(*CONSTANT_0),&(v764_4));
        drop(v764_4);
        let v764_7: Space = if (v764_5).is_empty() { Space::new() } else {
          let v765_6: Space = routine_114(c, &(v763_10_head), &(*p1), &(*p0), &(v757_12_head), &(v763_10_tail));
          compose(&(v764_5),&(v765_6))
        };
        drop(v764_5);
        let v764_8: Space = intersect(&(*CONSTANT_7),&(v764_2));
        drop(v764_2);
        let v764_9: Space = if has_head(&(v764_8)) { singleton(&[]) } else { Space::new() };
        drop(v764_8);
        let v764_11: Space = if (v764_9).is_empty() { Space::new() } else {
          let v766_10: Space = routine_115(c, &(v763_10_head), &(*p1), &(*p0), &(v757_12_head), &(v763_10_tail));
          compose(&(v764_9),&(v766_10))
        };
        drop(v764_9);
        let v764_12: Space = unite(&(v764_7),&(v764_11));
        v763_10.join_into((v764_12).clone());
      }
      drop(v763_10_cursor);
      compose(&(v758_9),&(v763_10))
    };
    drop(v758_9);
    let v758_12: Space = unite(&(v758_7),&(v758_11));
    v757_12.join_into((v758_12).clone());
  }
  drop(v757_12_cursor);
  (v757_12).clone()
}

fn routine_75(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v767_9 = Space::new();
  let mut v767_9_cursor = (*s0).read_zipper();
  for v767_9_byte in v767_9_cursor.child_mask().iter() {
    v767_9_cursor.descend_to_byte(v767_9_byte);
    let v767_9_tail = v767_9_cursor.make_map();
    v767_9_cursor.ascend(1);
    let v767_9_head = Path::from_slice(&[v767_9_byte]);
    let v768_2: Space = singleton(&(v767_9_head));
    let v768_3: Space = intersect(&(*CONSTANT_7),&(v768_2));
    let v768_4: Space = if has_head(&(v768_3)) { singleton(&[]) } else { Space::new() };
    drop(v768_3);
    let v768_5: Space = subtract(&(*CONSTANT_0),&(v768_4));
    drop(v768_4);
    let v768_8: Space = if (v768_5).is_empty() { Space::new() } else {
      let v769_6: Path = concat_path(&(*p0),&(v767_9_head));
      let v769_7: Space = routine_75(c, &(v769_6), &(*p1), &(v767_9_tail));
      compose(&(v768_5),&(v769_7))
    };
    drop(v768_5);
    let v768_9: Space = intersect(&(*CONSTANT_7),&(v768_2));
    drop(v768_2);
    let v768_10: Space = if has_head(&(v768_9)) { singleton(&[]) } else { Space::new() };
    drop(v768_9);
    let v768_12: Space = if (v768_10).is_empty() { Space::new() } else {
      let v770_6: Path = concat_path(&(*p0),&(v767_9_head));
      let mut v770_11 = Space::new();
      let mut v770_11_cursor = (v767_9_tail).read_zipper();
      for v770_11_byte in v770_11_cursor.child_mask().iter() {
        v770_11_cursor.descend_to_byte(v770_11_byte);
        let v770_11_tail = v770_11_cursor.make_map();
        v770_11_cursor.ascend(1);
        let v770_11_head = Path::from_slice(&[v770_11_byte]);
        let v771_2: Space = singleton(&(v770_11_head));
        let v771_3: Space = intersect(&(*CONSTANT_7),&(v771_2));
        let v771_4: Space = if has_head(&(v771_3)) { singleton(&[]) } else { Space::new() };
        drop(v771_3);
        let v771_5: Space = subtract(&(*CONSTANT_0),&(v771_4));
        drop(v771_4);
        let v771_7: Space = if (v771_5).is_empty() { Space::new() } else {
          let v772_6: Space = routine_94(c, &(v770_11_head), &(*p1), &(v770_6), &(v770_11_tail));
          compose(&(v771_5),&(v772_6))
        };
        drop(v771_5);
        let v771_8: Space = intersect(&(*CONSTANT_7),&(v771_2));
        drop(v771_2);
        let v771_9: Space = if has_head(&(v771_8)) { singleton(&[]) } else { Space::new() };
        drop(v771_8);
        let v771_11: Space = if (v771_9).is_empty() { Space::new() } else {
          let v773_10: Space = routine_95(c, &(v770_11_head), &(*p1), &(v770_6), &(v770_11_tail));
          compose(&(v771_9),&(v773_10))
        };
        drop(v771_9);
        let v771_12: Space = unite(&(v771_7),&(v771_11));
        v770_11.join_into((v771_12).clone());
      }
      drop(v770_11_cursor);
      drop(v770_6);
      compose(&(v768_10),&(v770_11))
    };
    drop(v768_10);
    let v768_13: Space = unite(&(v768_8),&(v768_12));
    v767_9.join_into((v768_13).clone());
  }
  drop(v767_9_cursor);
  (v767_9).clone()
}

fn routine_76(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v774_12 = Space::new();
  let mut v774_12_cursor = (*s0).read_zipper();
  for v774_12_byte in v774_12_cursor.child_mask().iter() {
    v774_12_cursor.descend_to_byte(v774_12_byte);
    let v774_12_tail = v774_12_cursor.make_map();
    v774_12_cursor.ascend(1);
    let v774_12_head = Path::from_slice(&[v774_12_byte]);
    let v775_2: Space = singleton(&(v774_12_head));
    let v775_3: Space = intersect(&(*CONSTANT_7),&(v775_2));
    let v775_4: Space = if has_head(&(v775_3)) { singleton(&[]) } else { Space::new() };
    drop(v775_3);
    let v775_5: Space = subtract(&(*CONSTANT_0),&(v775_4));
    drop(v775_4);
    let v775_7: Space = if (v775_5).is_empty() { Space::new() } else {
      let mut v776_6 = Space::new();
      let mut v776_6_cursor = (v774_12_tail).read_zipper();
      for v776_6_byte in v776_6_cursor.child_mask().iter() {
        v776_6_cursor.descend_to_byte(v776_6_byte);
        let v776_6_tail = v776_6_cursor.make_map();
        v776_6_cursor.ascend(1);
        let v776_6_head = Path::from_slice(&[v776_6_byte]);
        let v777_2: Space = singleton(&(v776_6_head));
        let v777_3: Space = intersect(&(*CONSTANT_7),&(v777_2));
        let v777_4: Space = if has_head(&(v777_3)) { singleton(&[]) } else { Space::new() };
        drop(v777_3);
        let v777_5: Space = subtract(&(*CONSTANT_0),&(v777_4));
        drop(v777_4);
        let v777_8: Space = if (v777_5).is_empty() { Space::new() } else {
          let v778_6: Path = concat_path(&(v774_12_head),&(v776_6_head));
          let v778_7: Space = routine_94(c, &(v778_6), &(*p1), &(*p0), &(v776_6_tail));
          compose(&(v777_5),&(v778_7))
        };
        drop(v777_5);
        let v777_9: Space = intersect(&(*CONSTANT_7),&(v777_2));
        drop(v777_2);
        let v777_10: Space = if has_head(&(v777_9)) { singleton(&[]) } else { Space::new() };
        drop(v777_9);
        let v777_12: Space = if (v777_10).is_empty() { Space::new() } else {
          let v779_6: Path = concat_path(&(v774_12_head),&(v776_6_head));
          let v779_11: Space = routine_95(c, &(v779_6), &(*p1), &(*p0), &(v776_6_tail));
          drop(v779_6);
          compose(&(v777_10),&(v779_11))
        };
        drop(v777_10);
        let v777_13: Space = unite(&(v777_8),&(v777_12));
        v776_6.join_into((v777_13).clone());
      }
      drop(v776_6_cursor);
      compose(&(v775_5),&(v776_6))
    };
    drop(v775_5);
    let v775_8: Space = intersect(&(*CONSTANT_7),&(v775_2));
    drop(v775_2);
    let v775_9: Space = if has_head(&(v775_8)) { singleton(&[]) } else { Space::new() };
    drop(v775_8);
    let v775_11: Space = if (v775_9).is_empty() { Space::new() } else {
      let mut v780_10 = Space::new();
      let mut v780_10_cursor = (v774_12_tail).read_zipper();
      for v780_10_byte in v780_10_cursor.child_mask().iter() {
        v780_10_cursor.descend_to_byte(v780_10_byte);
        let v780_10_tail = v780_10_cursor.make_map();
        v780_10_cursor.ascend(1);
        let v780_10_head = Path::from_slice(&[v780_10_byte]);
        let v781_2: Space = singleton(&(v780_10_head));
        let v781_3: Space = intersect(&(*CONSTANT_7),&(v781_2));
        let v781_4: Space = if has_head(&(v781_3)) { singleton(&[]) } else { Space::new() };
        drop(v781_3);
        let v781_5: Space = subtract(&(*CONSTANT_0),&(v781_4));
        drop(v781_4);
        let v781_7: Space = if (v781_5).is_empty() { Space::new() } else {
          let v782_6: Space = routine_116(c, &(v780_10_head), &(*p1), &(*p0), &(v774_12_head), &(v780_10_tail));
          compose(&(v781_5),&(v782_6))
        };
        drop(v781_5);
        let v781_8: Space = intersect(&(*CONSTANT_7),&(v781_2));
        drop(v781_2);
        let v781_9: Space = if has_head(&(v781_8)) { singleton(&[]) } else { Space::new() };
        drop(v781_8);
        let v781_11: Space = if (v781_9).is_empty() { Space::new() } else {
          let v783_10: Space = routine_117(c, &(v780_10_head), &(*p1), &(*p0), &(v774_12_head), &(v780_10_tail));
          compose(&(v781_9),&(v783_10))
        };
        drop(v781_9);
        let v781_12: Space = unite(&(v781_7),&(v781_11));
        v780_10.join_into((v781_12).clone());
      }
      drop(v780_10_cursor);
      compose(&(v775_9),&(v780_10))
    };
    drop(v775_9);
    let v775_12: Space = unite(&(v775_7),&(v775_11));
    v774_12.join_into((v775_12).clone());
  }
  drop(v774_12_cursor);
  (v774_12).clone()
}

fn routine_77(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v784_9 = Space::new();
  let mut v784_9_cursor = (*s0).read_zipper();
  for v784_9_byte in v784_9_cursor.child_mask().iter() {
    v784_9_cursor.descend_to_byte(v784_9_byte);
    let v784_9_tail = v784_9_cursor.make_map();
    v784_9_cursor.ascend(1);
    let v784_9_head = Path::from_slice(&[v784_9_byte]);
    let v785_2: Space = singleton(&(v784_9_head));
    let v785_3: Space = intersect(&(*CONSTANT_7),&(v785_2));
    let v785_4: Space = if has_head(&(v785_3)) { singleton(&[]) } else { Space::new() };
    drop(v785_3);
    let v785_5: Space = subtract(&(*CONSTANT_0),&(v785_4));
    drop(v785_4);
    let v785_8: Space = if (v785_5).is_empty() { Space::new() } else {
      let v786_6: Path = concat_path(&(*p0),&(v784_9_head));
      let v786_7: Space = routine_77(c, &(v786_6), &(*p1), &(v784_9_tail));
      compose(&(v785_5),&(v786_7))
    };
    drop(v785_5);
    let v785_9: Space = intersect(&(*CONSTANT_7),&(v785_2));
    drop(v785_2);
    let v785_10: Space = if has_head(&(v785_9)) { singleton(&[]) } else { Space::new() };
    drop(v785_9);
    let v785_12: Space = if (v785_10).is_empty() { Space::new() } else {
      let v787_6: Path = concat_path(&(*p0),&(v784_9_head));
      let mut v787_11 = Space::new();
      let mut v787_11_cursor = (v784_9_tail).read_zipper();
      for v787_11_byte in v787_11_cursor.child_mask().iter() {
        v787_11_cursor.descend_to_byte(v787_11_byte);
        let v787_11_tail = v787_11_cursor.make_map();
        v787_11_cursor.ascend(1);
        let v787_11_head = Path::from_slice(&[v787_11_byte]);
        let v788_2: Space = singleton(&(v787_11_head));
        let v788_3: Space = intersect(&(*CONSTANT_7),&(v788_2));
        let v788_4: Space = if has_head(&(v788_3)) { singleton(&[]) } else { Space::new() };
        drop(v788_3);
        let v788_5: Space = subtract(&(*CONSTANT_0),&(v788_4));
        drop(v788_4);
        let v788_7: Space = if (v788_5).is_empty() { Space::new() } else {
          let v789_6: Space = routine_96(c, &(v787_11_head), &(*p1), &(v787_6), &(v787_11_tail));
          compose(&(v788_5),&(v789_6))
        };
        drop(v788_5);
        let v788_8: Space = intersect(&(*CONSTANT_7),&(v788_2));
        drop(v788_2);
        let v788_9: Space = if has_head(&(v788_8)) { singleton(&[]) } else { Space::new() };
        drop(v788_8);
        let v788_11: Space = if (v788_9).is_empty() { Space::new() } else {
          let v790_10: Space = routine_97(c, &(v787_11_head), &(*p1), &(v787_6), &(v787_11_tail));
          compose(&(v788_9),&(v790_10))
        };
        drop(v788_9);
        let v788_12: Space = unite(&(v788_7),&(v788_11));
        v787_11.join_into((v788_12).clone());
      }
      drop(v787_11_cursor);
      drop(v787_6);
      compose(&(v785_10),&(v787_11))
    };
    drop(v785_10);
    let v785_13: Space = unite(&(v785_8),&(v785_12));
    v784_9.join_into((v785_13).clone());
  }
  drop(v784_9_cursor);
  (v784_9).clone()
}

fn routine_78(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v791_12 = Space::new();
  let mut v791_12_cursor = (*s0).read_zipper();
  for v791_12_byte in v791_12_cursor.child_mask().iter() {
    v791_12_cursor.descend_to_byte(v791_12_byte);
    let v791_12_tail = v791_12_cursor.make_map();
    v791_12_cursor.ascend(1);
    let v791_12_head = Path::from_slice(&[v791_12_byte]);
    let v792_2: Space = singleton(&(v791_12_head));
    let v792_3: Space = intersect(&(*CONSTANT_7),&(v792_2));
    let v792_4: Space = if has_head(&(v792_3)) { singleton(&[]) } else { Space::new() };
    drop(v792_3);
    let v792_5: Space = subtract(&(*CONSTANT_0),&(v792_4));
    drop(v792_4);
    let v792_7: Space = if (v792_5).is_empty() { Space::new() } else {
      let mut v793_6 = Space::new();
      let mut v793_6_cursor = (v791_12_tail).read_zipper();
      for v793_6_byte in v793_6_cursor.child_mask().iter() {
        v793_6_cursor.descend_to_byte(v793_6_byte);
        let v793_6_tail = v793_6_cursor.make_map();
        v793_6_cursor.ascend(1);
        let v793_6_head = Path::from_slice(&[v793_6_byte]);
        let v794_2: Space = singleton(&(v793_6_head));
        let v794_3: Space = intersect(&(*CONSTANT_7),&(v794_2));
        let v794_4: Space = if has_head(&(v794_3)) { singleton(&[]) } else { Space::new() };
        drop(v794_3);
        let v794_5: Space = subtract(&(*CONSTANT_0),&(v794_4));
        drop(v794_4);
        let v794_8: Space = if (v794_5).is_empty() { Space::new() } else {
          let v795_6: Path = concat_path(&(v791_12_head),&(v793_6_head));
          let v795_7: Space = routine_96(c, &(v795_6), &(*p1), &(*p0), &(v793_6_tail));
          compose(&(v794_5),&(v795_7))
        };
        drop(v794_5);
        let v794_9: Space = intersect(&(*CONSTANT_7),&(v794_2));
        drop(v794_2);
        let v794_10: Space = if has_head(&(v794_9)) { singleton(&[]) } else { Space::new() };
        drop(v794_9);
        let v794_12: Space = if (v794_10).is_empty() { Space::new() } else {
          let v796_6: Path = concat_path(&(v791_12_head),&(v793_6_head));
          let v796_11: Space = routine_97(c, &(v796_6), &(*p1), &(*p0), &(v793_6_tail));
          drop(v796_6);
          compose(&(v794_10),&(v796_11))
        };
        drop(v794_10);
        let v794_13: Space = unite(&(v794_8),&(v794_12));
        v793_6.join_into((v794_13).clone());
      }
      drop(v793_6_cursor);
      compose(&(v792_5),&(v793_6))
    };
    drop(v792_5);
    let v792_8: Space = intersect(&(*CONSTANT_7),&(v792_2));
    drop(v792_2);
    let v792_9: Space = if has_head(&(v792_8)) { singleton(&[]) } else { Space::new() };
    drop(v792_8);
    let v792_11: Space = if (v792_9).is_empty() { Space::new() } else {
      let mut v797_10 = Space::new();
      let mut v797_10_cursor = (v791_12_tail).read_zipper();
      for v797_10_byte in v797_10_cursor.child_mask().iter() {
        v797_10_cursor.descend_to_byte(v797_10_byte);
        let v797_10_tail = v797_10_cursor.make_map();
        v797_10_cursor.ascend(1);
        let v797_10_head = Path::from_slice(&[v797_10_byte]);
        let v798_2: Space = singleton(&(v797_10_head));
        let v798_3: Space = intersect(&(*CONSTANT_7),&(v798_2));
        let v798_4: Space = if has_head(&(v798_3)) { singleton(&[]) } else { Space::new() };
        drop(v798_3);
        let v798_5: Space = subtract(&(*CONSTANT_0),&(v798_4));
        drop(v798_4);
        let v798_7: Space = if (v798_5).is_empty() { Space::new() } else {
          let v799_6: Space = routine_118(c, &(v797_10_head), &(*p1), &(*p0), &(v791_12_head), &(v797_10_tail));
          compose(&(v798_5),&(v799_6))
        };
        drop(v798_5);
        let v798_8: Space = intersect(&(*CONSTANT_7),&(v798_2));
        drop(v798_2);
        let v798_9: Space = if has_head(&(v798_8)) { singleton(&[]) } else { Space::new() };
        drop(v798_8);
        let v798_11: Space = if (v798_9).is_empty() { Space::new() } else {
          let v800_10: Space = routine_119(c, &(v797_10_head), &(*p1), &(*p0), &(v791_12_head), &(v797_10_tail));
          compose(&(v798_9),&(v800_10))
        };
        drop(v798_9);
        let v798_12: Space = unite(&(v798_7),&(v798_11));
        v797_10.join_into((v798_12).clone());
      }
      drop(v797_10_cursor);
      compose(&(v792_9),&(v797_10))
    };
    drop(v792_9);
    let v792_12: Space = unite(&(v792_7),&(v792_11));
    v791_12.join_into((v792_12).clone());
  }
  drop(v791_12_cursor);
  (v791_12).clone()
}

fn routine_79(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v801_9 = Space::new();
  let mut v801_9_cursor = (*s0).read_zipper();
  for v801_9_byte in v801_9_cursor.child_mask().iter() {
    v801_9_cursor.descend_to_byte(v801_9_byte);
    let v801_9_tail = v801_9_cursor.make_map();
    v801_9_cursor.ascend(1);
    let v801_9_head = Path::from_slice(&[v801_9_byte]);
    let v802_2: Space = singleton(&(v801_9_head));
    let v802_3: Space = intersect(&(*CONSTANT_7),&(v802_2));
    let v802_4: Space = if has_head(&(v802_3)) { singleton(&[]) } else { Space::new() };
    drop(v802_3);
    let v802_5: Space = subtract(&(*CONSTANT_0),&(v802_4));
    drop(v802_4);
    let v802_8: Space = if (v802_5).is_empty() { Space::new() } else {
      let v803_6: Path = concat_path(&(*p0),&(v801_9_head));
      let v803_7: Space = routine_79(c, &(v803_6), &(*p1), &(v801_9_tail));
      compose(&(v802_5),&(v803_7))
    };
    drop(v802_5);
    let v802_9: Space = intersect(&(*CONSTANT_7),&(v802_2));
    drop(v802_2);
    let v802_10: Space = if has_head(&(v802_9)) { singleton(&[]) } else { Space::new() };
    drop(v802_9);
    let v802_12: Space = if (v802_10).is_empty() { Space::new() } else {
      let v804_6: Path = concat_path(&(*p0),&(v801_9_head));
      let mut v804_11 = Space::new();
      let mut v804_11_cursor = (v801_9_tail).read_zipper();
      for v804_11_byte in v804_11_cursor.child_mask().iter() {
        v804_11_cursor.descend_to_byte(v804_11_byte);
        let v804_11_tail = v804_11_cursor.make_map();
        v804_11_cursor.ascend(1);
        let v804_11_head = Path::from_slice(&[v804_11_byte]);
        let v805_2: Space = singleton(&(v804_11_head));
        let v805_3: Space = intersect(&(*CONSTANT_7),&(v805_2));
        let v805_4: Space = if has_head(&(v805_3)) { singleton(&[]) } else { Space::new() };
        drop(v805_3);
        let v805_5: Space = subtract(&(*CONSTANT_0),&(v805_4));
        drop(v805_4);
        let v805_7: Space = if (v805_5).is_empty() { Space::new() } else {
          let v806_6: Space = routine_98(c, &(v804_11_head), &(*p1), &(v804_6), &(v804_11_tail));
          compose(&(v805_5),&(v806_6))
        };
        drop(v805_5);
        let v805_8: Space = intersect(&(*CONSTANT_7),&(v805_2));
        drop(v805_2);
        let v805_9: Space = if has_head(&(v805_8)) { singleton(&[]) } else { Space::new() };
        drop(v805_8);
        let v805_11: Space = if (v805_9).is_empty() { Space::new() } else {
          let v807_10: Space = routine_99(c, &(v804_11_head), &(*p1), &(v804_6), &(v804_11_tail));
          compose(&(v805_9),&(v807_10))
        };
        drop(v805_9);
        let v805_12: Space = unite(&(v805_7),&(v805_11));
        v804_11.join_into((v805_12).clone());
      }
      drop(v804_11_cursor);
      drop(v804_6);
      compose(&(v802_10),&(v804_11))
    };
    drop(v802_10);
    let v802_13: Space = unite(&(v802_8),&(v802_12));
    v801_9.join_into((v802_13).clone());
  }
  drop(v801_9_cursor);
  (v801_9).clone()
}

fn routine_80(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v808_12 = Space::new();
  let mut v808_12_cursor = (*s0).read_zipper();
  for v808_12_byte in v808_12_cursor.child_mask().iter() {
    v808_12_cursor.descend_to_byte(v808_12_byte);
    let v808_12_tail = v808_12_cursor.make_map();
    v808_12_cursor.ascend(1);
    let v808_12_head = Path::from_slice(&[v808_12_byte]);
    let v809_2: Space = singleton(&(v808_12_head));
    let v809_3: Space = intersect(&(*CONSTANT_7),&(v809_2));
    let v809_4: Space = if has_head(&(v809_3)) { singleton(&[]) } else { Space::new() };
    drop(v809_3);
    let v809_5: Space = subtract(&(*CONSTANT_0),&(v809_4));
    drop(v809_4);
    let v809_7: Space = if (v809_5).is_empty() { Space::new() } else {
      let mut v810_6 = Space::new();
      let mut v810_6_cursor = (v808_12_tail).read_zipper();
      for v810_6_byte in v810_6_cursor.child_mask().iter() {
        v810_6_cursor.descend_to_byte(v810_6_byte);
        let v810_6_tail = v810_6_cursor.make_map();
        v810_6_cursor.ascend(1);
        let v810_6_head = Path::from_slice(&[v810_6_byte]);
        let v811_2: Space = singleton(&(v810_6_head));
        let v811_3: Space = intersect(&(*CONSTANT_7),&(v811_2));
        let v811_4: Space = if has_head(&(v811_3)) { singleton(&[]) } else { Space::new() };
        drop(v811_3);
        let v811_5: Space = subtract(&(*CONSTANT_0),&(v811_4));
        drop(v811_4);
        let v811_8: Space = if (v811_5).is_empty() { Space::new() } else {
          let v812_6: Path = concat_path(&(v808_12_head),&(v810_6_head));
          let v812_7: Space = routine_98(c, &(v812_6), &(*p1), &(*p0), &(v810_6_tail));
          compose(&(v811_5),&(v812_7))
        };
        drop(v811_5);
        let v811_9: Space = intersect(&(*CONSTANT_7),&(v811_2));
        drop(v811_2);
        let v811_10: Space = if has_head(&(v811_9)) { singleton(&[]) } else { Space::new() };
        drop(v811_9);
        let v811_12: Space = if (v811_10).is_empty() { Space::new() } else {
          let v813_6: Path = concat_path(&(v808_12_head),&(v810_6_head));
          let v813_11: Space = routine_99(c, &(v813_6), &(*p1), &(*p0), &(v810_6_tail));
          drop(v813_6);
          compose(&(v811_10),&(v813_11))
        };
        drop(v811_10);
        let v811_13: Space = unite(&(v811_8),&(v811_12));
        v810_6.join_into((v811_13).clone());
      }
      drop(v810_6_cursor);
      compose(&(v809_5),&(v810_6))
    };
    drop(v809_5);
    let v809_8: Space = intersect(&(*CONSTANT_7),&(v809_2));
    drop(v809_2);
    let v809_9: Space = if has_head(&(v809_8)) { singleton(&[]) } else { Space::new() };
    drop(v809_8);
    let v809_11: Space = if (v809_9).is_empty() { Space::new() } else {
      let mut v814_10 = Space::new();
      let mut v814_10_cursor = (v808_12_tail).read_zipper();
      for v814_10_byte in v814_10_cursor.child_mask().iter() {
        v814_10_cursor.descend_to_byte(v814_10_byte);
        let v814_10_tail = v814_10_cursor.make_map();
        v814_10_cursor.ascend(1);
        let v814_10_head = Path::from_slice(&[v814_10_byte]);
        let v815_2: Space = singleton(&(v814_10_head));
        let v815_3: Space = intersect(&(*CONSTANT_7),&(v815_2));
        let v815_4: Space = if has_head(&(v815_3)) { singleton(&[]) } else { Space::new() };
        drop(v815_3);
        let v815_5: Space = subtract(&(*CONSTANT_0),&(v815_4));
        drop(v815_4);
        let v815_7: Space = if (v815_5).is_empty() { Space::new() } else {
          let v816_6: Space = routine_120(c, &(v814_10_head), &(*p1), &(*p0), &(v808_12_head), &(v814_10_tail));
          compose(&(v815_5),&(v816_6))
        };
        drop(v815_5);
        let v815_8: Space = intersect(&(*CONSTANT_7),&(v815_2));
        drop(v815_2);
        let v815_9: Space = if has_head(&(v815_8)) { singleton(&[]) } else { Space::new() };
        drop(v815_8);
        let v815_11: Space = if (v815_9).is_empty() { Space::new() } else {
          let v817_10: Space = routine_121(c, &(v814_10_head), &(*p1), &(*p0), &(v808_12_head), &(v814_10_tail));
          compose(&(v815_9),&(v817_10))
        };
        drop(v815_9);
        let v815_12: Space = unite(&(v815_7),&(v815_11));
        v814_10.join_into((v815_12).clone());
      }
      drop(v814_10_cursor);
      compose(&(v809_9),&(v814_10))
    };
    drop(v809_9);
    let v809_12: Space = unite(&(v809_7),&(v809_11));
    v808_12.join_into((v809_12).clone());
  }
  drop(v808_12_cursor);
  (v808_12).clone()
}

fn routine_81(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v818_9 = Space::new();
  let mut v818_9_cursor = (*s0).read_zipper();
  for v818_9_byte in v818_9_cursor.child_mask().iter() {
    v818_9_cursor.descend_to_byte(v818_9_byte);
    let v818_9_tail = v818_9_cursor.make_map();
    v818_9_cursor.ascend(1);
    let v818_9_head = Path::from_slice(&[v818_9_byte]);
    let v819_2: Space = singleton(&(v818_9_head));
    let v819_3: Space = intersect(&(*CONSTANT_7),&(v819_2));
    let v819_4: Space = if has_head(&(v819_3)) { singleton(&[]) } else { Space::new() };
    drop(v819_3);
    let v819_5: Space = subtract(&(*CONSTANT_0),&(v819_4));
    drop(v819_4);
    let v819_8: Space = if (v819_5).is_empty() { Space::new() } else {
      let v820_6: Path = concat_path(&(*p0),&(v818_9_head));
      let v820_7: Space = routine_81(c, &(v820_6), &(*p1), &(v818_9_tail));
      compose(&(v819_5),&(v820_7))
    };
    drop(v819_5);
    let v819_9: Space = intersect(&(*CONSTANT_7),&(v819_2));
    drop(v819_2);
    let v819_10: Space = if has_head(&(v819_9)) { singleton(&[]) } else { Space::new() };
    drop(v819_9);
    let v819_12: Space = if (v819_10).is_empty() { Space::new() } else {
      let v821_6: Path = concat_path(&(*p0),&(v818_9_head));
      let mut v821_11 = Space::new();
      let mut v821_11_cursor = (v818_9_tail).read_zipper();
      for v821_11_byte in v821_11_cursor.child_mask().iter() {
        v821_11_cursor.descend_to_byte(v821_11_byte);
        let v821_11_tail = v821_11_cursor.make_map();
        v821_11_cursor.ascend(1);
        let v821_11_head = Path::from_slice(&[v821_11_byte]);
        let v822_2: Space = singleton(&(v821_11_head));
        let v822_3: Space = intersect(&(*CONSTANT_7),&(v822_2));
        let v822_4: Space = if has_head(&(v822_3)) { singleton(&[]) } else { Space::new() };
        drop(v822_3);
        let v822_5: Space = subtract(&(*CONSTANT_0),&(v822_4));
        drop(v822_4);
        let v822_7: Space = if (v822_5).is_empty() { Space::new() } else {
          let v823_6: Space = routine_100(c, &(v821_11_head), &(*p1), &(v821_6), &(v821_11_tail));
          compose(&(v822_5),&(v823_6))
        };
        drop(v822_5);
        let v822_8: Space = intersect(&(*CONSTANT_7),&(v822_2));
        drop(v822_2);
        let v822_9: Space = if has_head(&(v822_8)) { singleton(&[]) } else { Space::new() };
        drop(v822_8);
        let v822_11: Space = if (v822_9).is_empty() { Space::new() } else {
          let v824_10: Space = routine_101(c, &(v821_11_head), &(*p1), &(v821_6), &(v821_11_tail));
          compose(&(v822_9),&(v824_10))
        };
        drop(v822_9);
        let v822_12: Space = unite(&(v822_7),&(v822_11));
        v821_11.join_into((v822_12).clone());
      }
      drop(v821_11_cursor);
      drop(v821_6);
      compose(&(v819_10),&(v821_11))
    };
    drop(v819_10);
    let v819_13: Space = unite(&(v819_8),&(v819_12));
    v818_9.join_into((v819_13).clone());
  }
  drop(v818_9_cursor);
  (v818_9).clone()
}

fn routine_82(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v825_12 = Space::new();
  let mut v825_12_cursor = (*s0).read_zipper();
  for v825_12_byte in v825_12_cursor.child_mask().iter() {
    v825_12_cursor.descend_to_byte(v825_12_byte);
    let v825_12_tail = v825_12_cursor.make_map();
    v825_12_cursor.ascend(1);
    let v825_12_head = Path::from_slice(&[v825_12_byte]);
    let v826_2: Space = singleton(&(v825_12_head));
    let v826_3: Space = intersect(&(*CONSTANT_7),&(v826_2));
    let v826_4: Space = if has_head(&(v826_3)) { singleton(&[]) } else { Space::new() };
    drop(v826_3);
    let v826_5: Space = subtract(&(*CONSTANT_0),&(v826_4));
    drop(v826_4);
    let v826_7: Space = if (v826_5).is_empty() { Space::new() } else {
      let mut v827_6 = Space::new();
      let mut v827_6_cursor = (v825_12_tail).read_zipper();
      for v827_6_byte in v827_6_cursor.child_mask().iter() {
        v827_6_cursor.descend_to_byte(v827_6_byte);
        let v827_6_tail = v827_6_cursor.make_map();
        v827_6_cursor.ascend(1);
        let v827_6_head = Path::from_slice(&[v827_6_byte]);
        let v828_2: Space = singleton(&(v827_6_head));
        let v828_3: Space = intersect(&(*CONSTANT_7),&(v828_2));
        let v828_4: Space = if has_head(&(v828_3)) { singleton(&[]) } else { Space::new() };
        drop(v828_3);
        let v828_5: Space = subtract(&(*CONSTANT_0),&(v828_4));
        drop(v828_4);
        let v828_8: Space = if (v828_5).is_empty() { Space::new() } else {
          let v829_6: Path = concat_path(&(v825_12_head),&(v827_6_head));
          let v829_7: Space = routine_100(c, &(v829_6), &(*p1), &(*p0), &(v827_6_tail));
          compose(&(v828_5),&(v829_7))
        };
        drop(v828_5);
        let v828_9: Space = intersect(&(*CONSTANT_7),&(v828_2));
        drop(v828_2);
        let v828_10: Space = if has_head(&(v828_9)) { singleton(&[]) } else { Space::new() };
        drop(v828_9);
        let v828_12: Space = if (v828_10).is_empty() { Space::new() } else {
          let v830_6: Path = concat_path(&(v825_12_head),&(v827_6_head));
          let v830_11: Space = routine_101(c, &(v830_6), &(*p1), &(*p0), &(v827_6_tail));
          drop(v830_6);
          compose(&(v828_10),&(v830_11))
        };
        drop(v828_10);
        let v828_13: Space = unite(&(v828_8),&(v828_12));
        v827_6.join_into((v828_13).clone());
      }
      drop(v827_6_cursor);
      compose(&(v826_5),&(v827_6))
    };
    drop(v826_5);
    let v826_8: Space = intersect(&(*CONSTANT_7),&(v826_2));
    drop(v826_2);
    let v826_9: Space = if has_head(&(v826_8)) { singleton(&[]) } else { Space::new() };
    drop(v826_8);
    let v826_11: Space = if (v826_9).is_empty() { Space::new() } else {
      let mut v831_10 = Space::new();
      let mut v831_10_cursor = (v825_12_tail).read_zipper();
      for v831_10_byte in v831_10_cursor.child_mask().iter() {
        v831_10_cursor.descend_to_byte(v831_10_byte);
        let v831_10_tail = v831_10_cursor.make_map();
        v831_10_cursor.ascend(1);
        let v831_10_head = Path::from_slice(&[v831_10_byte]);
        let v832_2: Space = singleton(&(v831_10_head));
        let v832_3: Space = intersect(&(*CONSTANT_7),&(v832_2));
        let v832_4: Space = if has_head(&(v832_3)) { singleton(&[]) } else { Space::new() };
        drop(v832_3);
        let v832_5: Space = subtract(&(*CONSTANT_0),&(v832_4));
        drop(v832_4);
        let v832_7: Space = if (v832_5).is_empty() { Space::new() } else {
          let v833_6: Space = routine_122(c, &(v831_10_head), &(*p1), &(*p0), &(v825_12_head), &(v831_10_tail));
          compose(&(v832_5),&(v833_6))
        };
        drop(v832_5);
        let v832_8: Space = intersect(&(*CONSTANT_7),&(v832_2));
        drop(v832_2);
        let v832_9: Space = if has_head(&(v832_8)) { singleton(&[]) } else { Space::new() };
        drop(v832_8);
        let v832_11: Space = if (v832_9).is_empty() { Space::new() } else {
          let v834_10: Space = routine_123(c, &(v831_10_head), &(*p1), &(*p0), &(v825_12_head), &(v831_10_tail));
          compose(&(v832_9),&(v834_10))
        };
        drop(v832_9);
        let v832_12: Space = unite(&(v832_7),&(v832_11));
        v831_10.join_into((v832_12).clone());
      }
      drop(v831_10_cursor);
      compose(&(v826_9),&(v831_10))
    };
    drop(v826_9);
    let v826_12: Space = unite(&(v826_7),&(v826_11));
    v825_12.join_into((v826_12).clone());
  }
  drop(v825_12_cursor);
  (v825_12).clone()
}

fn routine_83(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v835_3: Space = singleton(&(*p0));
  let v835_4: Space = intersect(&(*CONSTANT_8),&(v835_3));
  let v835_28: Space = if (v835_4).is_empty() { Space::new() } else {
    let v836_6: Space = unwrap(&(*s0),&(*CONSTANT_22));
    let v836_9: Space = if (v836_6).is_empty() { Space::new() } else {
      let v837_8: Space = unwrap(&(*s0),&(*CONSTANT_23));
      compose(&(v836_6),&(v837_8))
    };
    let v836_12: Space = if (v836_9).is_empty() { Space::new() } else {
      let v838_11: Space = unwrap(&(*s0),&(*CONSTANT_24));
      compose(&(v836_9),&(v838_11))
    };
    drop(v836_9);
    let v836_15: Space = if (v836_12).is_empty() { Space::new() } else {
      let v839_14: Space = unwrap(&(*s0),&(*CONSTANT_25));
      compose(&(v836_12),&(v839_14))
    };
    drop(v836_12);
    let v836_18: Space = if (v836_15).is_empty() { Space::new() } else {
      let v840_17: Space = unwrap(&(*s0),&(*CONSTANT_26));
      compose(&(v836_15),&(v840_17))
    };
    drop(v836_15);
    let v836_21: Space = if (v836_18).is_empty() { Space::new() } else {
      let v841_20: Space = unwrap(&(*s0),&(*CONSTANT_27));
      compose(&(v836_18),&(v841_20))
    };
    drop(v836_18);
    let v836_24: Space = if (v836_21).is_empty() { Space::new() } else {
      let v842_23: Space = unwrap(&(*s0),&(*CONSTANT_28));
      compose(&(v836_21),&(v842_23))
    };
    drop(v836_21);
    let v836_27: Space = if (v836_24).is_empty() { Space::new() } else {
      let v843_26: Space = unwrap(&(*s0),&(*CONSTANT_29));
      compose(&(v836_24),&(v843_26))
    };
    drop(v836_24);
    compose(&(v835_4),&(v836_27))
  };
  drop(v835_4);
  let v835_30: Space = intersect(&(*CONSTANT_9),&(v835_3));
  let v835_40: Space = if (v835_30).is_empty() { Space::new() } else {
    let v844_32: Space = unwrap(&(*s0),&(*CONSTANT_30));
    let v844_33: Space = if (v844_32).is_empty() { Space::new() } else {
      let v845_8: Space = unwrap(&(*s0),&(*CONSTANT_23));
      compose(&(v844_32),&(v845_8))
    };
    let v844_34: Space = if (v844_33).is_empty() { Space::new() } else {
      let v846_11: Space = unwrap(&(*s0),&(*CONSTANT_24));
      compose(&(v844_33),&(v846_11))
    };
    drop(v844_33);
    let v844_35: Space = if (v844_34).is_empty() { Space::new() } else {
      let v847_14: Space = unwrap(&(*s0),&(*CONSTANT_25));
      compose(&(v844_34),&(v847_14))
    };
    drop(v844_34);
    let v844_36: Space = if (v844_35).is_empty() { Space::new() } else {
      let v848_17: Space = unwrap(&(*s0),&(*CONSTANT_26));
      compose(&(v844_35),&(v848_17))
    };
    drop(v844_35);
    let v844_37: Space = if (v844_36).is_empty() { Space::new() } else {
      let v849_20: Space = unwrap(&(*s0),&(*CONSTANT_27));
      compose(&(v844_36),&(v849_20))
    };
    drop(v844_36);
    let v844_38: Space = if (v844_37).is_empty() { Space::new() } else {
      let v850_23: Space = unwrap(&(*s0),&(*CONSTANT_28));
      compose(&(v844_37),&(v850_23))
    };
    drop(v844_37);
    let v844_39: Space = if (v844_38).is_empty() { Space::new() } else {
      let v851_26: Space = unwrap(&(*s0),&(*CONSTANT_29));
      compose(&(v844_38),&(v851_26))
    };
    drop(v844_38);
    compose(&(v835_30),&(v844_39))
  };
  drop(v835_30);
  let v835_41: Space = unite(&(v835_28),&(v835_40));
  drop(v835_28);
  drop(v835_40);
  let v835_43: Space = intersect(&(*CONSTANT_10),&(v835_3));
  let v835_51: Space = if (v835_43).is_empty() { Space::new() } else {
    let v852_32: Space = unwrap(&(*s0),&(*CONSTANT_30));
    let v852_44: Space = if (v852_32).is_empty() { Space::new() } else {
      let v853_6: Space = unwrap(&(*s0),&(*CONSTANT_22));
      compose(&(v852_32),&(v853_6))
    };
    drop(v852_32);
    let v852_45: Space = if (v852_44).is_empty() { Space::new() } else {
      let v854_11: Space = unwrap(&(*s0),&(*CONSTANT_24));
      compose(&(v852_44),&(v854_11))
    };
    let v852_46: Space = if (v852_45).is_empty() { Space::new() } else {
      let v855_14: Space = unwrap(&(*s0),&(*CONSTANT_25));
      compose(&(v852_45),&(v855_14))
    };
    drop(v852_45);
    let v852_47: Space = if (v852_46).is_empty() { Space::new() } else {
      let v856_17: Space = unwrap(&(*s0),&(*CONSTANT_26));
      compose(&(v852_46),&(v856_17))
    };
    drop(v852_46);
    let v852_48: Space = if (v852_47).is_empty() { Space::new() } else {
      let v857_20: Space = unwrap(&(*s0),&(*CONSTANT_27));
      compose(&(v852_47),&(v857_20))
    };
    drop(v852_47);
    let v852_49: Space = if (v852_48).is_empty() { Space::new() } else {
      let v858_23: Space = unwrap(&(*s0),&(*CONSTANT_28));
      compose(&(v852_48),&(v858_23))
    };
    drop(v852_48);
    let v852_50: Space = if (v852_49).is_empty() { Space::new() } else {
      let v859_26: Space = unwrap(&(*s0),&(*CONSTANT_29));
      compose(&(v852_49),&(v859_26))
    };
    drop(v852_49);
    compose(&(v835_43),&(v852_50))
  };
  drop(v835_43);
  let v835_52: Space = unite(&(v835_41),&(v835_51));
  drop(v835_41);
  drop(v835_51);
  let v835_54: Space = intersect(&(*CONSTANT_11),&(v835_3));
  let v835_61: Space = if (v835_54).is_empty() { Space::new() } else {
    let v860_32: Space = unwrap(&(*s0),&(*CONSTANT_30));
    let v860_44: Space = if (v860_32).is_empty() { Space::new() } else {
      let v861_6: Space = unwrap(&(*s0),&(*CONSTANT_22));
      compose(&(v860_32),&(v861_6))
    };
    drop(v860_32);
    let v860_55: Space = if (v860_44).is_empty() { Space::new() } else {
      let v862_8: Space = unwrap(&(*s0),&(*CONSTANT_23));
      compose(&(v860_44),&(v862_8))
    };
    drop(v860_44);
    let v860_56: Space = if (v860_55).is_empty() { Space::new() } else {
      let v863_14: Space = unwrap(&(*s0),&(*CONSTANT_25));
      compose(&(v860_55),&(v863_14))
    };
    let v860_57: Space = if (v860_56).is_empty() { Space::new() } else {
      let v864_17: Space = unwrap(&(*s0),&(*CONSTANT_26));
      compose(&(v860_56),&(v864_17))
    };
    drop(v860_56);
    let v860_58: Space = if (v860_57).is_empty() { Space::new() } else {
      let v865_20: Space = unwrap(&(*s0),&(*CONSTANT_27));
      compose(&(v860_57),&(v865_20))
    };
    drop(v860_57);
    let v860_59: Space = if (v860_58).is_empty() { Space::new() } else {
      let v866_23: Space = unwrap(&(*s0),&(*CONSTANT_28));
      compose(&(v860_58),&(v866_23))
    };
    drop(v860_58);
    let v860_60: Space = if (v860_59).is_empty() { Space::new() } else {
      let v867_26: Space = unwrap(&(*s0),&(*CONSTANT_29));
      compose(&(v860_59),&(v867_26))
    };
    drop(v860_59);
    compose(&(v835_54),&(v860_60))
  };
  drop(v835_54);
  let v835_62: Space = unite(&(v835_52),&(v835_61));
  drop(v835_52);
  drop(v835_61);
  let v835_64: Space = intersect(&(*CONSTANT_12),&(v835_3));
  let v835_70: Space = if (v835_64).is_empty() { Space::new() } else {
    let v868_32: Space = unwrap(&(*s0),&(*CONSTANT_30));
    let v868_44: Space = if (v868_32).is_empty() { Space::new() } else {
      let v869_6: Space = unwrap(&(*s0),&(*CONSTANT_22));
      compose(&(v868_32),&(v869_6))
    };
    drop(v868_32);
    let v868_55: Space = if (v868_44).is_empty() { Space::new() } else {
      let v870_8: Space = unwrap(&(*s0),&(*CONSTANT_23));
      compose(&(v868_44),&(v870_8))
    };
    drop(v868_44);
    let v868_65: Space = if (v868_55).is_empty() { Space::new() } else {
      let v871_11: Space = unwrap(&(*s0),&(*CONSTANT_24));
      compose(&(v868_55),&(v871_11))
    };
    drop(v868_55);
    let v868_66: Space = if (v868_65).is_empty() { Space::new() } else {
      let v872_17: Space = unwrap(&(*s0),&(*CONSTANT_26));
      compose(&(v868_65),&(v872_17))
    };
    let v868_67: Space = if (v868_66).is_empty() { Space::new() } else {
      let v873_20: Space = unwrap(&(*s0),&(*CONSTANT_27));
      compose(&(v868_66),&(v873_20))
    };
    drop(v868_66);
    let v868_68: Space = if (v868_67).is_empty() { Space::new() } else {
      let v874_23: Space = unwrap(&(*s0),&(*CONSTANT_28));
      compose(&(v868_67),&(v874_23))
    };
    drop(v868_67);
    let v868_69: Space = if (v868_68).is_empty() { Space::new() } else {
      let v875_26: Space = unwrap(&(*s0),&(*CONSTANT_29));
      compose(&(v868_68),&(v875_26))
    };
    drop(v868_68);
    compose(&(v835_64),&(v868_69))
  };
  drop(v835_64);
  let v835_71: Space = unite(&(v835_62),&(v835_70));
  drop(v835_62);
  drop(v835_70);
  let v835_73: Space = intersect(&(*CONSTANT_13),&(v835_3));
  let v835_78: Space = if (v835_73).is_empty() { Space::new() } else {
    let v876_32: Space = unwrap(&(*s0),&(*CONSTANT_30));
    let v876_44: Space = if (v876_32).is_empty() { Space::new() } else {
      let v877_6: Space = unwrap(&(*s0),&(*CONSTANT_22));
      compose(&(v876_32),&(v877_6))
    };
    drop(v876_32);
    let v876_55: Space = if (v876_44).is_empty() { Space::new() } else {
      let v878_8: Space = unwrap(&(*s0),&(*CONSTANT_23));
      compose(&(v876_44),&(v878_8))
    };
    drop(v876_44);
    let v876_65: Space = if (v876_55).is_empty() { Space::new() } else {
      let v879_11: Space = unwrap(&(*s0),&(*CONSTANT_24));
      compose(&(v876_55),&(v879_11))
    };
    drop(v876_55);
    let v876_74: Space = if (v876_65).is_empty() { Space::new() } else {
      let v880_14: Space = unwrap(&(*s0),&(*CONSTANT_25));
      compose(&(v876_65),&(v880_14))
    };
    drop(v876_65);
    let v876_75: Space = if (v876_74).is_empty() { Space::new() } else {
      let v881_20: Space = unwrap(&(*s0),&(*CONSTANT_27));
      compose(&(v876_74),&(v881_20))
    };
    let v876_76: Space = if (v876_75).is_empty() { Space::new() } else {
      let v882_23: Space = unwrap(&(*s0),&(*CONSTANT_28));
      compose(&(v876_75),&(v882_23))
    };
    drop(v876_75);
    let v876_77: Space = if (v876_76).is_empty() { Space::new() } else {
      let v883_26: Space = unwrap(&(*s0),&(*CONSTANT_29));
      compose(&(v876_76),&(v883_26))
    };
    drop(v876_76);
    compose(&(v835_73),&(v876_77))
  };
  drop(v835_73);
  let v835_79: Space = unite(&(v835_71),&(v835_78));
  drop(v835_71);
  drop(v835_78);
  let v835_81: Space = intersect(&(*CONSTANT_14),&(v835_3));
  let v835_85: Space = if (v835_81).is_empty() { Space::new() } else {
    let v884_32: Space = unwrap(&(*s0),&(*CONSTANT_30));
    let v884_44: Space = if (v884_32).is_empty() { Space::new() } else {
      let v885_6: Space = unwrap(&(*s0),&(*CONSTANT_22));
      compose(&(v884_32),&(v885_6))
    };
    drop(v884_32);
    let v884_55: Space = if (v884_44).is_empty() { Space::new() } else {
      let v886_8: Space = unwrap(&(*s0),&(*CONSTANT_23));
      compose(&(v884_44),&(v886_8))
    };
    drop(v884_44);
    let v884_65: Space = if (v884_55).is_empty() { Space::new() } else {
      let v887_11: Space = unwrap(&(*s0),&(*CONSTANT_24));
      compose(&(v884_55),&(v887_11))
    };
    drop(v884_55);
    let v884_74: Space = if (v884_65).is_empty() { Space::new() } else {
      let v888_14: Space = unwrap(&(*s0),&(*CONSTANT_25));
      compose(&(v884_65),&(v888_14))
    };
    drop(v884_65);
    let v884_82: Space = if (v884_74).is_empty() { Space::new() } else {
      let v889_17: Space = unwrap(&(*s0),&(*CONSTANT_26));
      compose(&(v884_74),&(v889_17))
    };
    drop(v884_74);
    let v884_83: Space = if (v884_82).is_empty() { Space::new() } else {
      let v890_23: Space = unwrap(&(*s0),&(*CONSTANT_28));
      compose(&(v884_82),&(v890_23))
    };
    let v884_84: Space = if (v884_83).is_empty() { Space::new() } else {
      let v891_26: Space = unwrap(&(*s0),&(*CONSTANT_29));
      compose(&(v884_83),&(v891_26))
    };
    drop(v884_83);
    compose(&(v835_81),&(v884_84))
  };
  drop(v835_81);
  let v835_86: Space = unite(&(v835_79),&(v835_85));
  drop(v835_79);
  drop(v835_85);
  let v835_88: Space = intersect(&(*CONSTANT_15),&(v835_3));
  let v835_91: Space = if (v835_88).is_empty() { Space::new() } else {
    let v892_32: Space = unwrap(&(*s0),&(*CONSTANT_30));
    let v892_44: Space = if (v892_32).is_empty() { Space::new() } else {
      let v893_6: Space = unwrap(&(*s0),&(*CONSTANT_22));
      compose(&(v892_32),&(v893_6))
    };
    drop(v892_32);
    let v892_55: Space = if (v892_44).is_empty() { Space::new() } else {
      let v894_8: Space = unwrap(&(*s0),&(*CONSTANT_23));
      compose(&(v892_44),&(v894_8))
    };
    drop(v892_44);
    let v892_65: Space = if (v892_55).is_empty() { Space::new() } else {
      let v895_11: Space = unwrap(&(*s0),&(*CONSTANT_24));
      compose(&(v892_55),&(v895_11))
    };
    drop(v892_55);
    let v892_74: Space = if (v892_65).is_empty() { Space::new() } else {
      let v896_14: Space = unwrap(&(*s0),&(*CONSTANT_25));
      compose(&(v892_65),&(v896_14))
    };
    drop(v892_65);
    let v892_82: Space = if (v892_74).is_empty() { Space::new() } else {
      let v897_17: Space = unwrap(&(*s0),&(*CONSTANT_26));
      compose(&(v892_74),&(v897_17))
    };
    drop(v892_74);
    let v892_89: Space = if (v892_82).is_empty() { Space::new() } else {
      let v898_20: Space = unwrap(&(*s0),&(*CONSTANT_27));
      compose(&(v892_82),&(v898_20))
    };
    drop(v892_82);
    let v892_90: Space = if (v892_89).is_empty() { Space::new() } else {
      let v899_26: Space = unwrap(&(*s0),&(*CONSTANT_29));
      compose(&(v892_89),&(v899_26))
    };
    compose(&(v835_88),&(v892_90))
  };
  drop(v835_88);
  let v835_92: Space = unite(&(v835_86),&(v835_91));
  drop(v835_86);
  drop(v835_91);
  let v835_94: Space = intersect(&(*CONSTANT_16),&(v835_3));
  drop(v835_3);
  let v835_96: Space = if (v835_94).is_empty() { Space::new() } else {
    let v900_32: Space = unwrap(&(*s0),&(*CONSTANT_30));
    let v900_44: Space = if (v900_32).is_empty() { Space::new() } else {
      let v901_6: Space = unwrap(&(*s0),&(*CONSTANT_22));
      compose(&(v900_32),&(v901_6))
    };
    drop(v900_32);
    let v900_55: Space = if (v900_44).is_empty() { Space::new() } else {
      let v902_8: Space = unwrap(&(*s0),&(*CONSTANT_23));
      compose(&(v900_44),&(v902_8))
    };
    drop(v900_44);
    let v900_65: Space = if (v900_55).is_empty() { Space::new() } else {
      let v903_11: Space = unwrap(&(*s0),&(*CONSTANT_24));
      compose(&(v900_55),&(v903_11))
    };
    drop(v900_55);
    let v900_74: Space = if (v900_65).is_empty() { Space::new() } else {
      let v904_14: Space = unwrap(&(*s0),&(*CONSTANT_25));
      compose(&(v900_65),&(v904_14))
    };
    drop(v900_65);
    let v900_82: Space = if (v900_74).is_empty() { Space::new() } else {
      let v905_17: Space = unwrap(&(*s0),&(*CONSTANT_26));
      compose(&(v900_74),&(v905_17))
    };
    drop(v900_74);
    let v900_89: Space = if (v900_82).is_empty() { Space::new() } else {
      let v906_20: Space = unwrap(&(*s0),&(*CONSTANT_27));
      compose(&(v900_82),&(v906_20))
    };
    drop(v900_82);
    let v900_95: Space = if (v900_89).is_empty() { Space::new() } else {
      let v907_23: Space = unwrap(&(*s0),&(*CONSTANT_28));
      compose(&(v900_89),&(v907_23))
    };
    drop(v900_89);
    compose(&(v835_94),&(v900_95))
  };
  drop(v835_94);
  let v835_97: Space = unite(&(v835_92),&(v835_96));
  drop(v835_92);
  drop(v835_96);
  (v835_97).clone()
}

fn routine_84(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v908_10 = Space::new();
  let mut v908_10_cursor = (*s0).read_zipper();
  for v908_10_byte in v908_10_cursor.child_mask().iter() {
    v908_10_cursor.descend_to_byte(v908_10_byte);
    let v908_10_tail = v908_10_cursor.make_map();
    v908_10_cursor.ascend(1);
    let v908_10_head = Path::from_slice(&[v908_10_byte]);
    let v909_2: Space = singleton(&(v908_10_head));
    let v909_3: Space = intersect(&(*CONSTANT_7),&(v909_2));
    let v909_4: Space = if has_head(&(v909_3)) { singleton(&[]) } else { Space::new() };
    drop(v909_3);
    let v909_5: Space = subtract(&(*CONSTANT_0),&(v909_4));
    drop(v909_4);
    let v909_8: Space = if (v909_5).is_empty() { Space::new() } else {
      let v910_6: Path = concat_path(&(*p0),&(v908_10_head));
      let v910_7: Space = routine_84(c, &(v910_6), &(*p1), &(*p2), &(v908_10_tail));
      compose(&(v909_5),&(v910_7))
    };
    drop(v909_5);
    let v909_9: Space = intersect(&(*CONSTANT_7),&(v909_2));
    drop(v909_2);
    let v909_10: Space = if has_head(&(v909_9)) { singleton(&[]) } else { Space::new() };
    drop(v909_9);
    let v909_12: Space = if (v909_10).is_empty() { Space::new() } else {
      let v911_6: Path = concat_path(&(*p0),&(v908_10_head));
      let mut v911_11 = Space::new();
      let mut v911_11_cursor = (v908_10_tail).read_zipper();
      for v911_11_byte in v911_11_cursor.child_mask().iter() {
        v911_11_cursor.descend_to_byte(v911_11_byte);
        let v911_11_tail = v911_11_cursor.make_map();
        v911_11_cursor.ascend(1);
        let v911_11_head = Path::from_slice(&[v911_11_byte]);
        let v912_2: Space = singleton(&(v911_11_head));
        let v912_3: Space = intersect(&(*CONSTANT_7),&(v912_2));
        let v912_4: Space = if has_head(&(v912_3)) { singleton(&[]) } else { Space::new() };
        drop(v912_3);
        let v912_5: Space = subtract(&(*CONSTANT_0),&(v912_4));
        drop(v912_4);
        let v912_7: Space = if (v912_5).is_empty() { Space::new() } else {
          let v913_6: Space = routine_106(c, &(v911_11_head), &(*p1), &(*p2), &(v911_6), &(v911_11_tail));
          compose(&(v912_5),&(v913_6))
        };
        drop(v912_5);
        let v912_8: Space = intersect(&(*CONSTANT_7),&(v912_2));
        drop(v912_2);
        let v912_9: Space = if has_head(&(v912_8)) { singleton(&[]) } else { Space::new() };
        drop(v912_8);
        let v912_11: Space = if (v912_9).is_empty() { Space::new() } else {
          let v914_10: Space = routine_107(c, &(v911_11_head), &(*p1), &(*p2), &(v911_6), &(v911_11_tail));
          compose(&(v912_9),&(v914_10))
        };
        drop(v912_9);
        let v912_12: Space = unite(&(v912_7),&(v912_11));
        v911_11.join_into((v912_12).clone());
      }
      drop(v911_11_cursor);
      drop(v911_6);
      compose(&(v909_10),&(v911_11))
    };
    drop(v909_10);
    let v909_13: Space = unite(&(v909_8),&(v909_12));
    v908_10.join_into((v909_13).clone());
  }
  drop(v908_10_cursor);
  (v908_10).clone()
}

fn routine_85(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v915_13 = Space::new();
  let mut v915_13_cursor = (*s0).read_zipper();
  for v915_13_byte in v915_13_cursor.child_mask().iter() {
    v915_13_cursor.descend_to_byte(v915_13_byte);
    let v915_13_tail = v915_13_cursor.make_map();
    v915_13_cursor.ascend(1);
    let v915_13_head = Path::from_slice(&[v915_13_byte]);
    let v916_2: Space = singleton(&(v915_13_head));
    let v916_3: Space = intersect(&(*CONSTANT_7),&(v916_2));
    let v916_4: Space = if has_head(&(v916_3)) { singleton(&[]) } else { Space::new() };
    drop(v916_3);
    let v916_5: Space = subtract(&(*CONSTANT_0),&(v916_4));
    drop(v916_4);
    let v916_7: Space = if (v916_5).is_empty() { Space::new() } else {
      let mut v917_6 = Space::new();
      let mut v917_6_cursor = (v915_13_tail).read_zipper();
      for v917_6_byte in v917_6_cursor.child_mask().iter() {
        v917_6_cursor.descend_to_byte(v917_6_byte);
        let v917_6_tail = v917_6_cursor.make_map();
        v917_6_cursor.ascend(1);
        let v917_6_head = Path::from_slice(&[v917_6_byte]);
        let v918_2: Space = singleton(&(v917_6_head));
        let v918_3: Space = intersect(&(*CONSTANT_7),&(v918_2));
        let v918_4: Space = if has_head(&(v918_3)) { singleton(&[]) } else { Space::new() };
        drop(v918_3);
        let v918_5: Space = subtract(&(*CONSTANT_0),&(v918_4));
        drop(v918_4);
        let v918_8: Space = if (v918_5).is_empty() { Space::new() } else {
          let v919_6: Path = concat_path(&(v915_13_head),&(v917_6_head));
          let v919_7: Space = routine_106(c, &(v919_6), &(*p1), &(*p2), &(*p0), &(v917_6_tail));
          compose(&(v918_5),&(v919_7))
        };
        drop(v918_5);
        let v918_9: Space = intersect(&(*CONSTANT_7),&(v918_2));
        drop(v918_2);
        let v918_10: Space = if has_head(&(v918_9)) { singleton(&[]) } else { Space::new() };
        drop(v918_9);
        let v918_12: Space = if (v918_10).is_empty() { Space::new() } else {
          let v920_6: Path = concat_path(&(v915_13_head),&(v917_6_head));
          let v920_11: Space = routine_107(c, &(v920_6), &(*p1), &(*p2), &(*p0), &(v917_6_tail));
          drop(v920_6);
          compose(&(v918_10),&(v920_11))
        };
        drop(v918_10);
        let v918_13: Space = unite(&(v918_8),&(v918_12));
        v917_6.join_into((v918_13).clone());
      }
      drop(v917_6_cursor);
      compose(&(v916_5),&(v917_6))
    };
    drop(v916_5);
    let v916_8: Space = intersect(&(*CONSTANT_7),&(v916_2));
    drop(v916_2);
    let v916_9: Space = if has_head(&(v916_8)) { singleton(&[]) } else { Space::new() };
    drop(v916_8);
    let v916_11: Space = if (v916_9).is_empty() { Space::new() } else {
      let mut v921_10 = Space::new();
      let mut v921_10_cursor = (v915_13_tail).read_zipper();
      for v921_10_byte in v921_10_cursor.child_mask().iter() {
        v921_10_cursor.descend_to_byte(v921_10_byte);
        let v921_10_tail = v921_10_cursor.make_map();
        v921_10_cursor.ascend(1);
        let v921_10_head = Path::from_slice(&[v921_10_byte]);
        let v922_2: Space = singleton(&(v921_10_head));
        let v922_3: Space = intersect(&(*CONSTANT_7),&(v922_2));
        let v922_4: Space = if has_head(&(v922_3)) { singleton(&[]) } else { Space::new() };
        drop(v922_3);
        let v922_5: Space = subtract(&(*CONSTANT_0),&(v922_4));
        drop(v922_4);
        let v922_7: Space = if (v922_5).is_empty() { Space::new() } else {
          let v923_6: Space = routine_124(c, &(v921_10_head), &(*p1), &(*p2), &(*p0), &(v915_13_head), &(v921_10_tail));
          compose(&(v922_5),&(v923_6))
        };
        drop(v922_5);
        let v922_8: Space = intersect(&(*CONSTANT_7),&(v922_2));
        drop(v922_2);
        let v922_9: Space = if has_head(&(v922_8)) { singleton(&[]) } else { Space::new() };
        drop(v922_8);
        let v922_11: Space = if (v922_9).is_empty() { Space::new() } else {
          let v924_10: Space = routine_125(c, &(v921_10_head), &(*p1), &(*p2), &(*p0), &(v915_13_head), &(v921_10_tail));
          compose(&(v922_9),&(v924_10))
        };
        drop(v922_9);
        let v922_12: Space = unite(&(v922_7),&(v922_11));
        v921_10.join_into((v922_12).clone());
      }
      drop(v921_10_cursor);
      compose(&(v916_9),&(v921_10))
    };
    drop(v916_9);
    let v916_12: Space = unite(&(v916_7),&(v916_11));
    v915_13.join_into((v916_12).clone());
  }
  drop(v915_13_cursor);
  (v915_13).clone()
}

fn routine_86(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v925_10 = Space::new();
  let mut v925_10_cursor = (*s0).read_zipper();
  for v925_10_byte in v925_10_cursor.child_mask().iter() {
    v925_10_cursor.descend_to_byte(v925_10_byte);
    let v925_10_tail = v925_10_cursor.make_map();
    v925_10_cursor.ascend(1);
    let v925_10_head = Path::from_slice(&[v925_10_byte]);
    let v926_2: Space = singleton(&(v925_10_head));
    let v926_3: Space = intersect(&(*CONSTANT_7),&(v926_2));
    let v926_4: Space = if has_head(&(v926_3)) { singleton(&[]) } else { Space::new() };
    drop(v926_3);
    let v926_5: Space = subtract(&(*CONSTANT_0),&(v926_4));
    drop(v926_4);
    let v926_8: Space = if (v926_5).is_empty() { Space::new() } else {
      let v927_6: Path = concat_path(&(*p0),&(v925_10_head));
      let v927_7: Space = routine_86(c, &(v927_6), &(*p1), &(*p2), &(v925_10_tail));
      compose(&(v926_5),&(v927_7))
    };
    drop(v926_5);
    let v926_9: Space = intersect(&(*CONSTANT_7),&(v926_2));
    drop(v926_2);
    let v926_10: Space = if has_head(&(v926_9)) { singleton(&[]) } else { Space::new() };
    drop(v926_9);
    let v926_12: Space = if (v926_10).is_empty() { Space::new() } else {
      let v928_6: Path = concat_path(&(*p0),&(v925_10_head));
      let mut v928_11 = Space::new();
      let mut v928_11_cursor = (v925_10_tail).read_zipper();
      for v928_11_byte in v928_11_cursor.child_mask().iter() {
        v928_11_cursor.descend_to_byte(v928_11_byte);
        let v928_11_tail = v928_11_cursor.make_map();
        v928_11_cursor.ascend(1);
        let v928_11_head = Path::from_slice(&[v928_11_byte]);
        let v929_2: Space = singleton(&(v928_11_head));
        let v929_3: Space = intersect(&(*CONSTANT_7),&(v929_2));
        let v929_4: Space = if has_head(&(v929_3)) { singleton(&[]) } else { Space::new() };
        drop(v929_3);
        let v929_5: Space = subtract(&(*CONSTANT_0),&(v929_4));
        drop(v929_4);
        let v929_7: Space = if (v929_5).is_empty() { Space::new() } else {
          let v930_6: Space = routine_108(c, &(v928_11_head), &(*p1), &(*p2), &(v928_6), &(v928_11_tail));
          compose(&(v929_5),&(v930_6))
        };
        drop(v929_5);
        let v929_8: Space = intersect(&(*CONSTANT_7),&(v929_2));
        drop(v929_2);
        let v929_9: Space = if has_head(&(v929_8)) { singleton(&[]) } else { Space::new() };
        drop(v929_8);
        let v929_11: Space = if (v929_9).is_empty() { Space::new() } else {
          let v931_10: Space = routine_109(c, &(v928_11_head), &(*p1), &(*p2), &(v928_6), &(v928_11_tail));
          compose(&(v929_9),&(v931_10))
        };
        drop(v929_9);
        let v929_12: Space = unite(&(v929_7),&(v929_11));
        v928_11.join_into((v929_12).clone());
      }
      drop(v928_11_cursor);
      drop(v928_6);
      compose(&(v926_10),&(v928_11))
    };
    drop(v926_10);
    let v926_13: Space = unite(&(v926_8),&(v926_12));
    v925_10.join_into((v926_13).clone());
  }
  drop(v925_10_cursor);
  (v925_10).clone()
}

fn routine_87(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v932_13 = Space::new();
  let mut v932_13_cursor = (*s0).read_zipper();
  for v932_13_byte in v932_13_cursor.child_mask().iter() {
    v932_13_cursor.descend_to_byte(v932_13_byte);
    let v932_13_tail = v932_13_cursor.make_map();
    v932_13_cursor.ascend(1);
    let v932_13_head = Path::from_slice(&[v932_13_byte]);
    let v933_2: Space = singleton(&(v932_13_head));
    let v933_3: Space = intersect(&(*CONSTANT_7),&(v933_2));
    let v933_4: Space = if has_head(&(v933_3)) { singleton(&[]) } else { Space::new() };
    drop(v933_3);
    let v933_5: Space = subtract(&(*CONSTANT_0),&(v933_4));
    drop(v933_4);
    let v933_7: Space = if (v933_5).is_empty() { Space::new() } else {
      let mut v934_6 = Space::new();
      let mut v934_6_cursor = (v932_13_tail).read_zipper();
      for v934_6_byte in v934_6_cursor.child_mask().iter() {
        v934_6_cursor.descend_to_byte(v934_6_byte);
        let v934_6_tail = v934_6_cursor.make_map();
        v934_6_cursor.ascend(1);
        let v934_6_head = Path::from_slice(&[v934_6_byte]);
        let v935_2: Space = singleton(&(v934_6_head));
        let v935_3: Space = intersect(&(*CONSTANT_7),&(v935_2));
        let v935_4: Space = if has_head(&(v935_3)) { singleton(&[]) } else { Space::new() };
        drop(v935_3);
        let v935_5: Space = subtract(&(*CONSTANT_0),&(v935_4));
        drop(v935_4);
        let v935_8: Space = if (v935_5).is_empty() { Space::new() } else {
          let v936_6: Path = concat_path(&(v932_13_head),&(v934_6_head));
          let v936_7: Space = routine_108(c, &(v936_6), &(*p1), &(*p2), &(*p0), &(v934_6_tail));
          compose(&(v935_5),&(v936_7))
        };
        drop(v935_5);
        let v935_9: Space = intersect(&(*CONSTANT_7),&(v935_2));
        drop(v935_2);
        let v935_10: Space = if has_head(&(v935_9)) { singleton(&[]) } else { Space::new() };
        drop(v935_9);
        let v935_12: Space = if (v935_10).is_empty() { Space::new() } else {
          let v937_6: Path = concat_path(&(v932_13_head),&(v934_6_head));
          let v937_11: Space = routine_109(c, &(v937_6), &(*p1), &(*p2), &(*p0), &(v934_6_tail));
          drop(v937_6);
          compose(&(v935_10),&(v937_11))
        };
        drop(v935_10);
        let v935_13: Space = unite(&(v935_8),&(v935_12));
        v934_6.join_into((v935_13).clone());
      }
      drop(v934_6_cursor);
      compose(&(v933_5),&(v934_6))
    };
    drop(v933_5);
    let v933_8: Space = intersect(&(*CONSTANT_7),&(v933_2));
    drop(v933_2);
    let v933_9: Space = if has_head(&(v933_8)) { singleton(&[]) } else { Space::new() };
    drop(v933_8);
    let v933_11: Space = if (v933_9).is_empty() { Space::new() } else {
      let mut v938_10 = Space::new();
      let mut v938_10_cursor = (v932_13_tail).read_zipper();
      for v938_10_byte in v938_10_cursor.child_mask().iter() {
        v938_10_cursor.descend_to_byte(v938_10_byte);
        let v938_10_tail = v938_10_cursor.make_map();
        v938_10_cursor.ascend(1);
        let v938_10_head = Path::from_slice(&[v938_10_byte]);
        let v939_2: Space = singleton(&(v938_10_head));
        let v939_3: Space = intersect(&(*CONSTANT_7),&(v939_2));
        let v939_4: Space = if has_head(&(v939_3)) { singleton(&[]) } else { Space::new() };
        drop(v939_3);
        let v939_5: Space = subtract(&(*CONSTANT_0),&(v939_4));
        drop(v939_4);
        let v939_7: Space = if (v939_5).is_empty() { Space::new() } else {
          let v940_6: Space = routine_126(c, &(v938_10_head), &(*p1), &(*p2), &(*p0), &(v932_13_head), &(v938_10_tail));
          compose(&(v939_5),&(v940_6))
        };
        drop(v939_5);
        let v939_8: Space = intersect(&(*CONSTANT_7),&(v939_2));
        drop(v939_2);
        let v939_9: Space = if has_head(&(v939_8)) { singleton(&[]) } else { Space::new() };
        drop(v939_8);
        let v939_11: Space = if (v939_9).is_empty() { Space::new() } else {
          let v941_10: Space = routine_127(c, &(v938_10_head), &(*p1), &(*p2), &(*p0), &(v932_13_head), &(v938_10_tail));
          compose(&(v939_9),&(v941_10))
        };
        drop(v939_9);
        let v939_12: Space = unite(&(v939_7),&(v939_11));
        v938_10.join_into((v939_12).clone());
      }
      drop(v938_10_cursor);
      compose(&(v933_9),&(v938_10))
    };
    drop(v933_9);
    let v933_12: Space = unite(&(v933_7),&(v933_11));
    v932_13.join_into((v933_12).clone());
  }
  drop(v932_13_cursor);
  (v932_13).clone()
}

fn routine_88(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v942_10 = Space::new();
  let mut v942_10_cursor = (*s0).read_zipper();
  for v942_10_byte in v942_10_cursor.child_mask().iter() {
    v942_10_cursor.descend_to_byte(v942_10_byte);
    let v942_10_tail = v942_10_cursor.make_map();
    v942_10_cursor.ascend(1);
    let v942_10_head = Path::from_slice(&[v942_10_byte]);
    let v943_2: Space = singleton(&(v942_10_head));
    let v943_3: Space = intersect(&(*CONSTANT_7),&(v943_2));
    let v943_4: Space = if has_head(&(v943_3)) { singleton(&[]) } else { Space::new() };
    drop(v943_3);
    let v943_5: Space = subtract(&(*CONSTANT_0),&(v943_4));
    drop(v943_4);
    let v943_8: Space = if (v943_5).is_empty() { Space::new() } else {
      let v944_6: Path = concat_path(&(*p0),&(v942_10_head));
      let v944_7: Space = routine_88(c, &(v944_6), &(*p1), &(*p2), &(v942_10_tail));
      compose(&(v943_5),&(v944_7))
    };
    drop(v943_5);
    let v943_9: Space = intersect(&(*CONSTANT_7),&(v943_2));
    drop(v943_2);
    let v943_10: Space = if has_head(&(v943_9)) { singleton(&[]) } else { Space::new() };
    drop(v943_9);
    let v943_12: Space = if (v943_10).is_empty() { Space::new() } else {
      let v945_6: Path = concat_path(&(*p0),&(v942_10_head));
      let mut v945_11 = Space::new();
      let mut v945_11_cursor = (v942_10_tail).read_zipper();
      for v945_11_byte in v945_11_cursor.child_mask().iter() {
        v945_11_cursor.descend_to_byte(v945_11_byte);
        let v945_11_tail = v945_11_cursor.make_map();
        v945_11_cursor.ascend(1);
        let v945_11_head = Path::from_slice(&[v945_11_byte]);
        let v946_2: Space = singleton(&(v945_11_head));
        let v946_3: Space = intersect(&(*CONSTANT_7),&(v946_2));
        let v946_4: Space = if has_head(&(v946_3)) { singleton(&[]) } else { Space::new() };
        drop(v946_3);
        let v946_5: Space = subtract(&(*CONSTANT_0),&(v946_4));
        drop(v946_4);
        let v946_7: Space = if (v946_5).is_empty() { Space::new() } else {
          let v947_6: Space = routine_110(c, &(v945_11_head), &(*p1), &(*p2), &(v945_6), &(v945_11_tail));
          compose(&(v946_5),&(v947_6))
        };
        drop(v946_5);
        let v946_8: Space = intersect(&(*CONSTANT_7),&(v946_2));
        drop(v946_2);
        let v946_9: Space = if has_head(&(v946_8)) { singleton(&[]) } else { Space::new() };
        drop(v946_8);
        let v946_11: Space = if (v946_9).is_empty() { Space::new() } else {
          let v948_10: Space = routine_111(c, &(v945_11_head), &(*p1), &(*p2), &(v945_6), &(v945_11_tail));
          compose(&(v946_9),&(v948_10))
        };
        drop(v946_9);
        let v946_12: Space = unite(&(v946_7),&(v946_11));
        v945_11.join_into((v946_12).clone());
      }
      drop(v945_11_cursor);
      drop(v945_6);
      compose(&(v943_10),&(v945_11))
    };
    drop(v943_10);
    let v943_13: Space = unite(&(v943_8),&(v943_12));
    v942_10.join_into((v943_13).clone());
  }
  drop(v942_10_cursor);
  (v942_10).clone()
}

fn routine_89(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v949_13 = Space::new();
  let mut v949_13_cursor = (*s0).read_zipper();
  for v949_13_byte in v949_13_cursor.child_mask().iter() {
    v949_13_cursor.descend_to_byte(v949_13_byte);
    let v949_13_tail = v949_13_cursor.make_map();
    v949_13_cursor.ascend(1);
    let v949_13_head = Path::from_slice(&[v949_13_byte]);
    let v950_2: Space = singleton(&(v949_13_head));
    let v950_3: Space = intersect(&(*CONSTANT_7),&(v950_2));
    let v950_4: Space = if has_head(&(v950_3)) { singleton(&[]) } else { Space::new() };
    drop(v950_3);
    let v950_5: Space = subtract(&(*CONSTANT_0),&(v950_4));
    drop(v950_4);
    let v950_7: Space = if (v950_5).is_empty() { Space::new() } else {
      let mut v951_6 = Space::new();
      let mut v951_6_cursor = (v949_13_tail).read_zipper();
      for v951_6_byte in v951_6_cursor.child_mask().iter() {
        v951_6_cursor.descend_to_byte(v951_6_byte);
        let v951_6_tail = v951_6_cursor.make_map();
        v951_6_cursor.ascend(1);
        let v951_6_head = Path::from_slice(&[v951_6_byte]);
        let v952_2: Space = singleton(&(v951_6_head));
        let v952_3: Space = intersect(&(*CONSTANT_7),&(v952_2));
        let v952_4: Space = if has_head(&(v952_3)) { singleton(&[]) } else { Space::new() };
        drop(v952_3);
        let v952_5: Space = subtract(&(*CONSTANT_0),&(v952_4));
        drop(v952_4);
        let v952_8: Space = if (v952_5).is_empty() { Space::new() } else {
          let v953_6: Path = concat_path(&(v949_13_head),&(v951_6_head));
          let v953_7: Space = routine_110(c, &(v953_6), &(*p1), &(*p2), &(*p0), &(v951_6_tail));
          compose(&(v952_5),&(v953_7))
        };
        drop(v952_5);
        let v952_9: Space = intersect(&(*CONSTANT_7),&(v952_2));
        drop(v952_2);
        let v952_10: Space = if has_head(&(v952_9)) { singleton(&[]) } else { Space::new() };
        drop(v952_9);
        let v952_12: Space = if (v952_10).is_empty() { Space::new() } else {
          let v954_6: Path = concat_path(&(v949_13_head),&(v951_6_head));
          let v954_11: Space = routine_111(c, &(v954_6), &(*p1), &(*p2), &(*p0), &(v951_6_tail));
          drop(v954_6);
          compose(&(v952_10),&(v954_11))
        };
        drop(v952_10);
        let v952_13: Space = unite(&(v952_8),&(v952_12));
        v951_6.join_into((v952_13).clone());
      }
      drop(v951_6_cursor);
      compose(&(v950_5),&(v951_6))
    };
    drop(v950_5);
    let v950_8: Space = intersect(&(*CONSTANT_7),&(v950_2));
    drop(v950_2);
    let v950_9: Space = if has_head(&(v950_8)) { singleton(&[]) } else { Space::new() };
    drop(v950_8);
    let v950_11: Space = if (v950_9).is_empty() { Space::new() } else {
      let mut v955_10 = Space::new();
      let mut v955_10_cursor = (v949_13_tail).read_zipper();
      for v955_10_byte in v955_10_cursor.child_mask().iter() {
        v955_10_cursor.descend_to_byte(v955_10_byte);
        let v955_10_tail = v955_10_cursor.make_map();
        v955_10_cursor.ascend(1);
        let v955_10_head = Path::from_slice(&[v955_10_byte]);
        let v956_2: Space = singleton(&(v955_10_head));
        let v956_3: Space = intersect(&(*CONSTANT_7),&(v956_2));
        let v956_4: Space = if has_head(&(v956_3)) { singleton(&[]) } else { Space::new() };
        drop(v956_3);
        let v956_5: Space = subtract(&(*CONSTANT_0),&(v956_4));
        drop(v956_4);
        let v956_7: Space = if (v956_5).is_empty() { Space::new() } else {
          let v957_6: Space = routine_128(c, &(v955_10_head), &(*p1), &(*p2), &(*p0), &(v949_13_head), &(v955_10_tail));
          compose(&(v956_5),&(v957_6))
        };
        drop(v956_5);
        let v956_8: Space = intersect(&(*CONSTANT_7),&(v956_2));
        drop(v956_2);
        let v956_9: Space = if has_head(&(v956_8)) { singleton(&[]) } else { Space::new() };
        drop(v956_8);
        let v956_11: Space = if (v956_9).is_empty() { Space::new() } else {
          let v958_10: Space = routine_129(c, &(v955_10_head), &(*p1), &(*p2), &(*p0), &(v949_13_head), &(v955_10_tail));
          compose(&(v956_9),&(v958_10))
        };
        drop(v956_9);
        let v956_12: Space = unite(&(v956_7),&(v956_11));
        v955_10.join_into((v956_12).clone());
      }
      drop(v955_10_cursor);
      compose(&(v950_9),&(v955_10))
    };
    drop(v950_9);
    let v950_12: Space = unite(&(v950_7),&(v950_11));
    v949_13.join_into((v950_12).clone());
  }
  drop(v949_13_cursor);
  (v949_13).clone()
}

fn routine_90(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v959_10 = Space::new();
  let mut v959_10_cursor = (*s0).read_zipper();
  for v959_10_byte in v959_10_cursor.child_mask().iter() {
    v959_10_cursor.descend_to_byte(v959_10_byte);
    let v959_10_tail = v959_10_cursor.make_map();
    v959_10_cursor.ascend(1);
    let v959_10_head = Path::from_slice(&[v959_10_byte]);
    let v960_2: Space = singleton(&(v959_10_head));
    let v960_3: Space = intersect(&(*CONSTANT_7),&(v960_2));
    let v960_4: Space = if has_head(&(v960_3)) { singleton(&[]) } else { Space::new() };
    drop(v960_3);
    let v960_5: Space = subtract(&(*CONSTANT_0),&(v960_4));
    drop(v960_4);
    let v960_8: Space = if (v960_5).is_empty() { Space::new() } else {
      let v961_6: Path = concat_path(&(*p0),&(v959_10_head));
      let v961_7: Space = routine_90(c, &(v961_6), &(*p1), &(*p2), &(v959_10_tail));
      compose(&(v960_5),&(v961_7))
    };
    drop(v960_5);
    let v960_9: Space = intersect(&(*CONSTANT_7),&(v960_2));
    drop(v960_2);
    let v960_10: Space = if has_head(&(v960_9)) { singleton(&[]) } else { Space::new() };
    drop(v960_9);
    let v960_12: Space = if (v960_10).is_empty() { Space::new() } else {
      let v962_6: Path = concat_path(&(*p0),&(v959_10_head));
      let mut v962_11 = Space::new();
      let mut v962_11_cursor = (v959_10_tail).read_zipper();
      for v962_11_byte in v962_11_cursor.child_mask().iter() {
        v962_11_cursor.descend_to_byte(v962_11_byte);
        let v962_11_tail = v962_11_cursor.make_map();
        v962_11_cursor.ascend(1);
        let v962_11_head = Path::from_slice(&[v962_11_byte]);
        let v963_2: Space = singleton(&(v962_11_head));
        let v963_3: Space = intersect(&(*CONSTANT_7),&(v963_2));
        let v963_4: Space = if has_head(&(v963_3)) { singleton(&[]) } else { Space::new() };
        drop(v963_3);
        let v963_5: Space = subtract(&(*CONSTANT_0),&(v963_4));
        drop(v963_4);
        let v963_7: Space = if (v963_5).is_empty() { Space::new() } else {
          let v964_6: Space = routine_112(c, &(v962_11_head), &(*p1), &(*p2), &(v962_6), &(v962_11_tail));
          compose(&(v963_5),&(v964_6))
        };
        drop(v963_5);
        let v963_8: Space = intersect(&(*CONSTANT_7),&(v963_2));
        drop(v963_2);
        let v963_9: Space = if has_head(&(v963_8)) { singleton(&[]) } else { Space::new() };
        drop(v963_8);
        let v963_11: Space = if (v963_9).is_empty() { Space::new() } else {
          let v965_10: Space = routine_113(c, &(v962_11_head), &(*p1), &(*p2), &(v962_6), &(v962_11_tail));
          compose(&(v963_9),&(v965_10))
        };
        drop(v963_9);
        let v963_12: Space = unite(&(v963_7),&(v963_11));
        v962_11.join_into((v963_12).clone());
      }
      drop(v962_11_cursor);
      drop(v962_6);
      compose(&(v960_10),&(v962_11))
    };
    drop(v960_10);
    let v960_13: Space = unite(&(v960_8),&(v960_12));
    v959_10.join_into((v960_13).clone());
  }
  drop(v959_10_cursor);
  (v959_10).clone()
}

fn routine_91(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v966_13 = Space::new();
  let mut v966_13_cursor = (*s0).read_zipper();
  for v966_13_byte in v966_13_cursor.child_mask().iter() {
    v966_13_cursor.descend_to_byte(v966_13_byte);
    let v966_13_tail = v966_13_cursor.make_map();
    v966_13_cursor.ascend(1);
    let v966_13_head = Path::from_slice(&[v966_13_byte]);
    let v967_2: Space = singleton(&(v966_13_head));
    let v967_3: Space = intersect(&(*CONSTANT_7),&(v967_2));
    let v967_4: Space = if has_head(&(v967_3)) { singleton(&[]) } else { Space::new() };
    drop(v967_3);
    let v967_5: Space = subtract(&(*CONSTANT_0),&(v967_4));
    drop(v967_4);
    let v967_7: Space = if (v967_5).is_empty() { Space::new() } else {
      let mut v968_6 = Space::new();
      let mut v968_6_cursor = (v966_13_tail).read_zipper();
      for v968_6_byte in v968_6_cursor.child_mask().iter() {
        v968_6_cursor.descend_to_byte(v968_6_byte);
        let v968_6_tail = v968_6_cursor.make_map();
        v968_6_cursor.ascend(1);
        let v968_6_head = Path::from_slice(&[v968_6_byte]);
        let v969_2: Space = singleton(&(v968_6_head));
        let v969_3: Space = intersect(&(*CONSTANT_7),&(v969_2));
        let v969_4: Space = if has_head(&(v969_3)) { singleton(&[]) } else { Space::new() };
        drop(v969_3);
        let v969_5: Space = subtract(&(*CONSTANT_0),&(v969_4));
        drop(v969_4);
        let v969_8: Space = if (v969_5).is_empty() { Space::new() } else {
          let v970_6: Path = concat_path(&(v966_13_head),&(v968_6_head));
          let v970_7: Space = routine_112(c, &(v970_6), &(*p1), &(*p2), &(*p0), &(v968_6_tail));
          compose(&(v969_5),&(v970_7))
        };
        drop(v969_5);
        let v969_9: Space = intersect(&(*CONSTANT_7),&(v969_2));
        drop(v969_2);
        let v969_10: Space = if has_head(&(v969_9)) { singleton(&[]) } else { Space::new() };
        drop(v969_9);
        let v969_12: Space = if (v969_10).is_empty() { Space::new() } else {
          let v971_6: Path = concat_path(&(v966_13_head),&(v968_6_head));
          let v971_11: Space = routine_113(c, &(v971_6), &(*p1), &(*p2), &(*p0), &(v968_6_tail));
          drop(v971_6);
          compose(&(v969_10),&(v971_11))
        };
        drop(v969_10);
        let v969_13: Space = unite(&(v969_8),&(v969_12));
        v968_6.join_into((v969_13).clone());
      }
      drop(v968_6_cursor);
      compose(&(v967_5),&(v968_6))
    };
    drop(v967_5);
    let v967_8: Space = intersect(&(*CONSTANT_7),&(v967_2));
    drop(v967_2);
    let v967_9: Space = if has_head(&(v967_8)) { singleton(&[]) } else { Space::new() };
    drop(v967_8);
    let v967_11: Space = if (v967_9).is_empty() { Space::new() } else {
      let mut v972_10 = Space::new();
      let mut v972_10_cursor = (v966_13_tail).read_zipper();
      for v972_10_byte in v972_10_cursor.child_mask().iter() {
        v972_10_cursor.descend_to_byte(v972_10_byte);
        let v972_10_tail = v972_10_cursor.make_map();
        v972_10_cursor.ascend(1);
        let v972_10_head = Path::from_slice(&[v972_10_byte]);
        let v973_2: Space = singleton(&(v972_10_head));
        let v973_3: Space = intersect(&(*CONSTANT_7),&(v973_2));
        let v973_4: Space = if has_head(&(v973_3)) { singleton(&[]) } else { Space::new() };
        drop(v973_3);
        let v973_5: Space = subtract(&(*CONSTANT_0),&(v973_4));
        drop(v973_4);
        let v973_7: Space = if (v973_5).is_empty() { Space::new() } else {
          let v974_6: Space = routine_130(c, &(v972_10_head), &(*p1), &(*p2), &(*p0), &(v966_13_head), &(v972_10_tail));
          compose(&(v973_5),&(v974_6))
        };
        drop(v973_5);
        let v973_8: Space = intersect(&(*CONSTANT_7),&(v973_2));
        drop(v973_2);
        let v973_9: Space = if has_head(&(v973_8)) { singleton(&[]) } else { Space::new() };
        drop(v973_8);
        let v973_11: Space = if (v973_9).is_empty() { Space::new() } else {
          let v975_10: Space = routine_131(c, &(v972_10_head), &(*p1), &(*p2), &(*p0), &(v966_13_head), &(v972_10_tail));
          compose(&(v973_9),&(v975_10))
        };
        drop(v973_9);
        let v973_12: Space = unite(&(v973_7),&(v973_11));
        v972_10.join_into((v973_12).clone());
      }
      drop(v972_10_cursor);
      compose(&(v967_9),&(v972_10))
    };
    drop(v967_9);
    let v967_12: Space = unite(&(v967_7),&(v967_11));
    v966_13.join_into((v967_12).clone());
  }
  drop(v966_13_cursor);
  (v966_13).clone()
}

fn routine_92(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v976_10 = Space::new();
  let mut v976_10_cursor = (*s0).read_zipper();
  for v976_10_byte in v976_10_cursor.child_mask().iter() {
    v976_10_cursor.descend_to_byte(v976_10_byte);
    let v976_10_tail = v976_10_cursor.make_map();
    v976_10_cursor.ascend(1);
    let v976_10_head = Path::from_slice(&[v976_10_byte]);
    let v977_2: Space = singleton(&(v976_10_head));
    let v977_3: Space = intersect(&(*CONSTANT_7),&(v977_2));
    let v977_4: Space = if has_head(&(v977_3)) { singleton(&[]) } else { Space::new() };
    drop(v977_3);
    let v977_5: Space = subtract(&(*CONSTANT_0),&(v977_4));
    drop(v977_4);
    let v977_8: Space = if (v977_5).is_empty() { Space::new() } else {
      let v978_6: Path = concat_path(&(*p0),&(v976_10_head));
      let v978_7: Space = routine_92(c, &(v978_6), &(*p1), &(*p2), &(v976_10_tail));
      compose(&(v977_5),&(v978_7))
    };
    drop(v977_5);
    let v977_9: Space = intersect(&(*CONSTANT_7),&(v977_2));
    drop(v977_2);
    let v977_10: Space = if has_head(&(v977_9)) { singleton(&[]) } else { Space::new() };
    drop(v977_9);
    let v977_12: Space = if (v977_10).is_empty() { Space::new() } else {
      let v979_6: Path = concat_path(&(*p0),&(v976_10_head));
      let mut v979_11 = Space::new();
      let mut v979_11_cursor = (v976_10_tail).read_zipper();
      for v979_11_byte in v979_11_cursor.child_mask().iter() {
        v979_11_cursor.descend_to_byte(v979_11_byte);
        let v979_11_tail = v979_11_cursor.make_map();
        v979_11_cursor.ascend(1);
        let v979_11_head = Path::from_slice(&[v979_11_byte]);
        let v980_2: Space = singleton(&(v979_11_head));
        let v980_3: Space = intersect(&(*CONSTANT_7),&(v980_2));
        let v980_4: Space = if has_head(&(v980_3)) { singleton(&[]) } else { Space::new() };
        drop(v980_3);
        let v980_5: Space = subtract(&(*CONSTANT_0),&(v980_4));
        drop(v980_4);
        let v980_7: Space = if (v980_5).is_empty() { Space::new() } else {
          let v981_6: Space = routine_114(c, &(v979_11_head), &(*p1), &(*p2), &(v979_6), &(v979_11_tail));
          compose(&(v980_5),&(v981_6))
        };
        drop(v980_5);
        let v980_8: Space = intersect(&(*CONSTANT_7),&(v980_2));
        drop(v980_2);
        let v980_9: Space = if has_head(&(v980_8)) { singleton(&[]) } else { Space::new() };
        drop(v980_8);
        let v980_11: Space = if (v980_9).is_empty() { Space::new() } else {
          let v982_10: Space = routine_115(c, &(v979_11_head), &(*p1), &(*p2), &(v979_6), &(v979_11_tail));
          compose(&(v980_9),&(v982_10))
        };
        drop(v980_9);
        let v980_12: Space = unite(&(v980_7),&(v980_11));
        v979_11.join_into((v980_12).clone());
      }
      drop(v979_11_cursor);
      drop(v979_6);
      compose(&(v977_10),&(v979_11))
    };
    drop(v977_10);
    let v977_13: Space = unite(&(v977_8),&(v977_12));
    v976_10.join_into((v977_13).clone());
  }
  drop(v976_10_cursor);
  (v976_10).clone()
}

fn routine_93(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v983_13 = Space::new();
  let mut v983_13_cursor = (*s0).read_zipper();
  for v983_13_byte in v983_13_cursor.child_mask().iter() {
    v983_13_cursor.descend_to_byte(v983_13_byte);
    let v983_13_tail = v983_13_cursor.make_map();
    v983_13_cursor.ascend(1);
    let v983_13_head = Path::from_slice(&[v983_13_byte]);
    let v984_2: Space = singleton(&(v983_13_head));
    let v984_3: Space = intersect(&(*CONSTANT_7),&(v984_2));
    let v984_4: Space = if has_head(&(v984_3)) { singleton(&[]) } else { Space::new() };
    drop(v984_3);
    let v984_5: Space = subtract(&(*CONSTANT_0),&(v984_4));
    drop(v984_4);
    let v984_7: Space = if (v984_5).is_empty() { Space::new() } else {
      let mut v985_6 = Space::new();
      let mut v985_6_cursor = (v983_13_tail).read_zipper();
      for v985_6_byte in v985_6_cursor.child_mask().iter() {
        v985_6_cursor.descend_to_byte(v985_6_byte);
        let v985_6_tail = v985_6_cursor.make_map();
        v985_6_cursor.ascend(1);
        let v985_6_head = Path::from_slice(&[v985_6_byte]);
        let v986_2: Space = singleton(&(v985_6_head));
        let v986_3: Space = intersect(&(*CONSTANT_7),&(v986_2));
        let v986_4: Space = if has_head(&(v986_3)) { singleton(&[]) } else { Space::new() };
        drop(v986_3);
        let v986_5: Space = subtract(&(*CONSTANT_0),&(v986_4));
        drop(v986_4);
        let v986_8: Space = if (v986_5).is_empty() { Space::new() } else {
          let v987_6: Path = concat_path(&(v983_13_head),&(v985_6_head));
          let v987_7: Space = routine_114(c, &(v987_6), &(*p1), &(*p2), &(*p0), &(v985_6_tail));
          compose(&(v986_5),&(v987_7))
        };
        drop(v986_5);
        let v986_9: Space = intersect(&(*CONSTANT_7),&(v986_2));
        drop(v986_2);
        let v986_10: Space = if has_head(&(v986_9)) { singleton(&[]) } else { Space::new() };
        drop(v986_9);
        let v986_12: Space = if (v986_10).is_empty() { Space::new() } else {
          let v988_6: Path = concat_path(&(v983_13_head),&(v985_6_head));
          let v988_11: Space = routine_115(c, &(v988_6), &(*p1), &(*p2), &(*p0), &(v985_6_tail));
          drop(v988_6);
          compose(&(v986_10),&(v988_11))
        };
        drop(v986_10);
        let v986_13: Space = unite(&(v986_8),&(v986_12));
        v985_6.join_into((v986_13).clone());
      }
      drop(v985_6_cursor);
      compose(&(v984_5),&(v985_6))
    };
    drop(v984_5);
    let v984_8: Space = intersect(&(*CONSTANT_7),&(v984_2));
    drop(v984_2);
    let v984_9: Space = if has_head(&(v984_8)) { singleton(&[]) } else { Space::new() };
    drop(v984_8);
    let v984_11: Space = if (v984_9).is_empty() { Space::new() } else {
      let mut v989_10 = Space::new();
      let mut v989_10_cursor = (v983_13_tail).read_zipper();
      for v989_10_byte in v989_10_cursor.child_mask().iter() {
        v989_10_cursor.descend_to_byte(v989_10_byte);
        let v989_10_tail = v989_10_cursor.make_map();
        v989_10_cursor.ascend(1);
        let v989_10_head = Path::from_slice(&[v989_10_byte]);
        let v990_2: Space = singleton(&(v989_10_head));
        let v990_3: Space = intersect(&(*CONSTANT_7),&(v990_2));
        let v990_4: Space = if has_head(&(v990_3)) { singleton(&[]) } else { Space::new() };
        drop(v990_3);
        let v990_5: Space = subtract(&(*CONSTANT_0),&(v990_4));
        drop(v990_4);
        let v990_7: Space = if (v990_5).is_empty() { Space::new() } else {
          let v991_6: Space = routine_132(c, &(v989_10_head), &(*p1), &(*p2), &(*p0), &(v983_13_head), &(v989_10_tail));
          compose(&(v990_5),&(v991_6))
        };
        drop(v990_5);
        let v990_8: Space = intersect(&(*CONSTANT_7),&(v990_2));
        drop(v990_2);
        let v990_9: Space = if has_head(&(v990_8)) { singleton(&[]) } else { Space::new() };
        drop(v990_8);
        let v990_11: Space = if (v990_9).is_empty() { Space::new() } else {
          let v992_10: Space = routine_133(c, &(v989_10_head), &(*p1), &(*p2), &(*p0), &(v983_13_head), &(v989_10_tail));
          compose(&(v990_9),&(v992_10))
        };
        drop(v990_9);
        let v990_12: Space = unite(&(v990_7),&(v990_11));
        v989_10.join_into((v990_12).clone());
      }
      drop(v989_10_cursor);
      compose(&(v984_9),&(v989_10))
    };
    drop(v984_9);
    let v984_12: Space = unite(&(v984_7),&(v984_11));
    v983_13.join_into((v984_12).clone());
  }
  drop(v983_13_cursor);
  (v983_13).clone()
}

fn routine_94(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v993_10 = Space::new();
  let mut v993_10_cursor = (*s0).read_zipper();
  for v993_10_byte in v993_10_cursor.child_mask().iter() {
    v993_10_cursor.descend_to_byte(v993_10_byte);
    let v993_10_tail = v993_10_cursor.make_map();
    v993_10_cursor.ascend(1);
    let v993_10_head = Path::from_slice(&[v993_10_byte]);
    let v994_2: Space = singleton(&(v993_10_head));
    let v994_3: Space = intersect(&(*CONSTANT_7),&(v994_2));
    let v994_4: Space = if has_head(&(v994_3)) { singleton(&[]) } else { Space::new() };
    drop(v994_3);
    let v994_5: Space = subtract(&(*CONSTANT_0),&(v994_4));
    drop(v994_4);
    let v994_8: Space = if (v994_5).is_empty() { Space::new() } else {
      let v995_6: Path = concat_path(&(*p0),&(v993_10_head));
      let v995_7: Space = routine_94(c, &(v995_6), &(*p1), &(*p2), &(v993_10_tail));
      compose(&(v994_5),&(v995_7))
    };
    drop(v994_5);
    let v994_9: Space = intersect(&(*CONSTANT_7),&(v994_2));
    drop(v994_2);
    let v994_10: Space = if has_head(&(v994_9)) { singleton(&[]) } else { Space::new() };
    drop(v994_9);
    let v994_12: Space = if (v994_10).is_empty() { Space::new() } else {
      let v996_6: Path = concat_path(&(*p0),&(v993_10_head));
      let mut v996_11 = Space::new();
      let mut v996_11_cursor = (v993_10_tail).read_zipper();
      for v996_11_byte in v996_11_cursor.child_mask().iter() {
        v996_11_cursor.descend_to_byte(v996_11_byte);
        let v996_11_tail = v996_11_cursor.make_map();
        v996_11_cursor.ascend(1);
        let v996_11_head = Path::from_slice(&[v996_11_byte]);
        let v997_2: Space = singleton(&(v996_11_head));
        let v997_3: Space = intersect(&(*CONSTANT_7),&(v997_2));
        let v997_4: Space = if has_head(&(v997_3)) { singleton(&[]) } else { Space::new() };
        drop(v997_3);
        let v997_5: Space = subtract(&(*CONSTANT_0),&(v997_4));
        drop(v997_4);
        let v997_7: Space = if (v997_5).is_empty() { Space::new() } else {
          let v998_6: Space = routine_116(c, &(v996_11_head), &(*p1), &(*p2), &(v996_6), &(v996_11_tail));
          compose(&(v997_5),&(v998_6))
        };
        drop(v997_5);
        let v997_8: Space = intersect(&(*CONSTANT_7),&(v997_2));
        drop(v997_2);
        let v997_9: Space = if has_head(&(v997_8)) { singleton(&[]) } else { Space::new() };
        drop(v997_8);
        let v997_11: Space = if (v997_9).is_empty() { Space::new() } else {
          let v999_10: Space = routine_117(c, &(v996_11_head), &(*p1), &(*p2), &(v996_6), &(v996_11_tail));
          compose(&(v997_9),&(v999_10))
        };
        drop(v997_9);
        let v997_12: Space = unite(&(v997_7),&(v997_11));
        v996_11.join_into((v997_12).clone());
      }
      drop(v996_11_cursor);
      drop(v996_6);
      compose(&(v994_10),&(v996_11))
    };
    drop(v994_10);
    let v994_13: Space = unite(&(v994_8),&(v994_12));
    v993_10.join_into((v994_13).clone());
  }
  drop(v993_10_cursor);
  (v993_10).clone()
}

fn routine_95(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v1000_13 = Space::new();
  let mut v1000_13_cursor = (*s0).read_zipper();
  for v1000_13_byte in v1000_13_cursor.child_mask().iter() {
    v1000_13_cursor.descend_to_byte(v1000_13_byte);
    let v1000_13_tail = v1000_13_cursor.make_map();
    v1000_13_cursor.ascend(1);
    let v1000_13_head = Path::from_slice(&[v1000_13_byte]);
    let v1001_2: Space = singleton(&(v1000_13_head));
    let v1001_3: Space = intersect(&(*CONSTANT_7),&(v1001_2));
    let v1001_4: Space = if has_head(&(v1001_3)) { singleton(&[]) } else { Space::new() };
    drop(v1001_3);
    let v1001_5: Space = subtract(&(*CONSTANT_0),&(v1001_4));
    drop(v1001_4);
    let v1001_7: Space = if (v1001_5).is_empty() { Space::new() } else {
      let mut v1002_6 = Space::new();
      let mut v1002_6_cursor = (v1000_13_tail).read_zipper();
      for v1002_6_byte in v1002_6_cursor.child_mask().iter() {
        v1002_6_cursor.descend_to_byte(v1002_6_byte);
        let v1002_6_tail = v1002_6_cursor.make_map();
        v1002_6_cursor.ascend(1);
        let v1002_6_head = Path::from_slice(&[v1002_6_byte]);
        let v1003_2: Space = singleton(&(v1002_6_head));
        let v1003_3: Space = intersect(&(*CONSTANT_7),&(v1003_2));
        let v1003_4: Space = if has_head(&(v1003_3)) { singleton(&[]) } else { Space::new() };
        drop(v1003_3);
        let v1003_5: Space = subtract(&(*CONSTANT_0),&(v1003_4));
        drop(v1003_4);
        let v1003_8: Space = if (v1003_5).is_empty() { Space::new() } else {
          let v1004_6: Path = concat_path(&(v1000_13_head),&(v1002_6_head));
          let v1004_7: Space = routine_116(c, &(v1004_6), &(*p1), &(*p2), &(*p0), &(v1002_6_tail));
          compose(&(v1003_5),&(v1004_7))
        };
        drop(v1003_5);
        let v1003_9: Space = intersect(&(*CONSTANT_7),&(v1003_2));
        drop(v1003_2);
        let v1003_10: Space = if has_head(&(v1003_9)) { singleton(&[]) } else { Space::new() };
        drop(v1003_9);
        let v1003_12: Space = if (v1003_10).is_empty() { Space::new() } else {
          let v1005_6: Path = concat_path(&(v1000_13_head),&(v1002_6_head));
          let v1005_11: Space = routine_117(c, &(v1005_6), &(*p1), &(*p2), &(*p0), &(v1002_6_tail));
          drop(v1005_6);
          compose(&(v1003_10),&(v1005_11))
        };
        drop(v1003_10);
        let v1003_13: Space = unite(&(v1003_8),&(v1003_12));
        v1002_6.join_into((v1003_13).clone());
      }
      drop(v1002_6_cursor);
      compose(&(v1001_5),&(v1002_6))
    };
    drop(v1001_5);
    let v1001_8: Space = intersect(&(*CONSTANT_7),&(v1001_2));
    drop(v1001_2);
    let v1001_9: Space = if has_head(&(v1001_8)) { singleton(&[]) } else { Space::new() };
    drop(v1001_8);
    let v1001_11: Space = if (v1001_9).is_empty() { Space::new() } else {
      let mut v1006_10 = Space::new();
      let mut v1006_10_cursor = (v1000_13_tail).read_zipper();
      for v1006_10_byte in v1006_10_cursor.child_mask().iter() {
        v1006_10_cursor.descend_to_byte(v1006_10_byte);
        let v1006_10_tail = v1006_10_cursor.make_map();
        v1006_10_cursor.ascend(1);
        let v1006_10_head = Path::from_slice(&[v1006_10_byte]);
        let v1007_2: Space = singleton(&(v1006_10_head));
        let v1007_3: Space = intersect(&(*CONSTANT_7),&(v1007_2));
        let v1007_4: Space = if has_head(&(v1007_3)) { singleton(&[]) } else { Space::new() };
        drop(v1007_3);
        let v1007_5: Space = subtract(&(*CONSTANT_0),&(v1007_4));
        drop(v1007_4);
        let v1007_7: Space = if (v1007_5).is_empty() { Space::new() } else {
          let v1008_6: Space = routine_134(c, &(v1006_10_head), &(*p1), &(*p2), &(*p0), &(v1000_13_head), &(v1006_10_tail));
          compose(&(v1007_5),&(v1008_6))
        };
        drop(v1007_5);
        let v1007_8: Space = intersect(&(*CONSTANT_7),&(v1007_2));
        drop(v1007_2);
        let v1007_9: Space = if has_head(&(v1007_8)) { singleton(&[]) } else { Space::new() };
        drop(v1007_8);
        let v1007_11: Space = if (v1007_9).is_empty() { Space::new() } else {
          let v1009_10: Space = routine_135(c, &(v1006_10_head), &(*p1), &(*p2), &(*p0), &(v1000_13_head), &(v1006_10_tail));
          compose(&(v1007_9),&(v1009_10))
        };
        drop(v1007_9);
        let v1007_12: Space = unite(&(v1007_7),&(v1007_11));
        v1006_10.join_into((v1007_12).clone());
      }
      drop(v1006_10_cursor);
      compose(&(v1001_9),&(v1006_10))
    };
    drop(v1001_9);
    let v1001_12: Space = unite(&(v1001_7),&(v1001_11));
    v1000_13.join_into((v1001_12).clone());
  }
  drop(v1000_13_cursor);
  (v1000_13).clone()
}

fn routine_96(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v1010_10 = Space::new();
  let mut v1010_10_cursor = (*s0).read_zipper();
  for v1010_10_byte in v1010_10_cursor.child_mask().iter() {
    v1010_10_cursor.descend_to_byte(v1010_10_byte);
    let v1010_10_tail = v1010_10_cursor.make_map();
    v1010_10_cursor.ascend(1);
    let v1010_10_head = Path::from_slice(&[v1010_10_byte]);
    let v1011_2: Space = singleton(&(v1010_10_head));
    let v1011_3: Space = intersect(&(*CONSTANT_7),&(v1011_2));
    let v1011_4: Space = if has_head(&(v1011_3)) { singleton(&[]) } else { Space::new() };
    drop(v1011_3);
    let v1011_5: Space = subtract(&(*CONSTANT_0),&(v1011_4));
    drop(v1011_4);
    let v1011_8: Space = if (v1011_5).is_empty() { Space::new() } else {
      let v1012_6: Path = concat_path(&(*p0),&(v1010_10_head));
      let v1012_7: Space = routine_96(c, &(v1012_6), &(*p1), &(*p2), &(v1010_10_tail));
      compose(&(v1011_5),&(v1012_7))
    };
    drop(v1011_5);
    let v1011_9: Space = intersect(&(*CONSTANT_7),&(v1011_2));
    drop(v1011_2);
    let v1011_10: Space = if has_head(&(v1011_9)) { singleton(&[]) } else { Space::new() };
    drop(v1011_9);
    let v1011_12: Space = if (v1011_10).is_empty() { Space::new() } else {
      let v1013_6: Path = concat_path(&(*p0),&(v1010_10_head));
      let mut v1013_11 = Space::new();
      let mut v1013_11_cursor = (v1010_10_tail).read_zipper();
      for v1013_11_byte in v1013_11_cursor.child_mask().iter() {
        v1013_11_cursor.descend_to_byte(v1013_11_byte);
        let v1013_11_tail = v1013_11_cursor.make_map();
        v1013_11_cursor.ascend(1);
        let v1013_11_head = Path::from_slice(&[v1013_11_byte]);
        let v1014_2: Space = singleton(&(v1013_11_head));
        let v1014_3: Space = intersect(&(*CONSTANT_7),&(v1014_2));
        let v1014_4: Space = if has_head(&(v1014_3)) { singleton(&[]) } else { Space::new() };
        drop(v1014_3);
        let v1014_5: Space = subtract(&(*CONSTANT_0),&(v1014_4));
        drop(v1014_4);
        let v1014_7: Space = if (v1014_5).is_empty() { Space::new() } else {
          let v1015_6: Space = routine_118(c, &(v1013_11_head), &(*p1), &(*p2), &(v1013_6), &(v1013_11_tail));
          compose(&(v1014_5),&(v1015_6))
        };
        drop(v1014_5);
        let v1014_8: Space = intersect(&(*CONSTANT_7),&(v1014_2));
        drop(v1014_2);
        let v1014_9: Space = if has_head(&(v1014_8)) { singleton(&[]) } else { Space::new() };
        drop(v1014_8);
        let v1014_11: Space = if (v1014_9).is_empty() { Space::new() } else {
          let v1016_10: Space = routine_119(c, &(v1013_11_head), &(*p1), &(*p2), &(v1013_6), &(v1013_11_tail));
          compose(&(v1014_9),&(v1016_10))
        };
        drop(v1014_9);
        let v1014_12: Space = unite(&(v1014_7),&(v1014_11));
        v1013_11.join_into((v1014_12).clone());
      }
      drop(v1013_11_cursor);
      drop(v1013_6);
      compose(&(v1011_10),&(v1013_11))
    };
    drop(v1011_10);
    let v1011_13: Space = unite(&(v1011_8),&(v1011_12));
    v1010_10.join_into((v1011_13).clone());
  }
  drop(v1010_10_cursor);
  (v1010_10).clone()
}

fn routine_97(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v1017_13 = Space::new();
  let mut v1017_13_cursor = (*s0).read_zipper();
  for v1017_13_byte in v1017_13_cursor.child_mask().iter() {
    v1017_13_cursor.descend_to_byte(v1017_13_byte);
    let v1017_13_tail = v1017_13_cursor.make_map();
    v1017_13_cursor.ascend(1);
    let v1017_13_head = Path::from_slice(&[v1017_13_byte]);
    let v1018_2: Space = singleton(&(v1017_13_head));
    let v1018_3: Space = intersect(&(*CONSTANT_7),&(v1018_2));
    let v1018_4: Space = if has_head(&(v1018_3)) { singleton(&[]) } else { Space::new() };
    drop(v1018_3);
    let v1018_5: Space = subtract(&(*CONSTANT_0),&(v1018_4));
    drop(v1018_4);
    let v1018_7: Space = if (v1018_5).is_empty() { Space::new() } else {
      let mut v1019_6 = Space::new();
      let mut v1019_6_cursor = (v1017_13_tail).read_zipper();
      for v1019_6_byte in v1019_6_cursor.child_mask().iter() {
        v1019_6_cursor.descend_to_byte(v1019_6_byte);
        let v1019_6_tail = v1019_6_cursor.make_map();
        v1019_6_cursor.ascend(1);
        let v1019_6_head = Path::from_slice(&[v1019_6_byte]);
        let v1020_2: Space = singleton(&(v1019_6_head));
        let v1020_3: Space = intersect(&(*CONSTANT_7),&(v1020_2));
        let v1020_4: Space = if has_head(&(v1020_3)) { singleton(&[]) } else { Space::new() };
        drop(v1020_3);
        let v1020_5: Space = subtract(&(*CONSTANT_0),&(v1020_4));
        drop(v1020_4);
        let v1020_8: Space = if (v1020_5).is_empty() { Space::new() } else {
          let v1021_6: Path = concat_path(&(v1017_13_head),&(v1019_6_head));
          let v1021_7: Space = routine_118(c, &(v1021_6), &(*p1), &(*p2), &(*p0), &(v1019_6_tail));
          compose(&(v1020_5),&(v1021_7))
        };
        drop(v1020_5);
        let v1020_9: Space = intersect(&(*CONSTANT_7),&(v1020_2));
        drop(v1020_2);
        let v1020_10: Space = if has_head(&(v1020_9)) { singleton(&[]) } else { Space::new() };
        drop(v1020_9);
        let v1020_12: Space = if (v1020_10).is_empty() { Space::new() } else {
          let v1022_6: Path = concat_path(&(v1017_13_head),&(v1019_6_head));
          let v1022_11: Space = routine_119(c, &(v1022_6), &(*p1), &(*p2), &(*p0), &(v1019_6_tail));
          drop(v1022_6);
          compose(&(v1020_10),&(v1022_11))
        };
        drop(v1020_10);
        let v1020_13: Space = unite(&(v1020_8),&(v1020_12));
        v1019_6.join_into((v1020_13).clone());
      }
      drop(v1019_6_cursor);
      compose(&(v1018_5),&(v1019_6))
    };
    drop(v1018_5);
    let v1018_8: Space = intersect(&(*CONSTANT_7),&(v1018_2));
    drop(v1018_2);
    let v1018_9: Space = if has_head(&(v1018_8)) { singleton(&[]) } else { Space::new() };
    drop(v1018_8);
    let v1018_11: Space = if (v1018_9).is_empty() { Space::new() } else {
      let mut v1023_10 = Space::new();
      let mut v1023_10_cursor = (v1017_13_tail).read_zipper();
      for v1023_10_byte in v1023_10_cursor.child_mask().iter() {
        v1023_10_cursor.descend_to_byte(v1023_10_byte);
        let v1023_10_tail = v1023_10_cursor.make_map();
        v1023_10_cursor.ascend(1);
        let v1023_10_head = Path::from_slice(&[v1023_10_byte]);
        let v1024_2: Space = singleton(&(v1023_10_head));
        let v1024_3: Space = intersect(&(*CONSTANT_7),&(v1024_2));
        let v1024_4: Space = if has_head(&(v1024_3)) { singleton(&[]) } else { Space::new() };
        drop(v1024_3);
        let v1024_5: Space = subtract(&(*CONSTANT_0),&(v1024_4));
        drop(v1024_4);
        let v1024_7: Space = if (v1024_5).is_empty() { Space::new() } else {
          let v1025_6: Space = routine_136(c, &(v1023_10_head), &(*p1), &(*p2), &(*p0), &(v1017_13_head), &(v1023_10_tail));
          compose(&(v1024_5),&(v1025_6))
        };
        drop(v1024_5);
        let v1024_8: Space = intersect(&(*CONSTANT_7),&(v1024_2));
        drop(v1024_2);
        let v1024_9: Space = if has_head(&(v1024_8)) { singleton(&[]) } else { Space::new() };
        drop(v1024_8);
        let v1024_11: Space = if (v1024_9).is_empty() { Space::new() } else {
          let v1026_10: Space = routine_137(c, &(v1023_10_head), &(*p1), &(*p2), &(*p0), &(v1017_13_head), &(v1023_10_tail));
          compose(&(v1024_9),&(v1026_10))
        };
        drop(v1024_9);
        let v1024_12: Space = unite(&(v1024_7),&(v1024_11));
        v1023_10.join_into((v1024_12).clone());
      }
      drop(v1023_10_cursor);
      compose(&(v1018_9),&(v1023_10))
    };
    drop(v1018_9);
    let v1018_12: Space = unite(&(v1018_7),&(v1018_11));
    v1017_13.join_into((v1018_12).clone());
  }
  drop(v1017_13_cursor);
  (v1017_13).clone()
}

fn routine_98(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v1027_10 = Space::new();
  let mut v1027_10_cursor = (*s0).read_zipper();
  for v1027_10_byte in v1027_10_cursor.child_mask().iter() {
    v1027_10_cursor.descend_to_byte(v1027_10_byte);
    let v1027_10_tail = v1027_10_cursor.make_map();
    v1027_10_cursor.ascend(1);
    let v1027_10_head = Path::from_slice(&[v1027_10_byte]);
    let v1028_2: Space = singleton(&(v1027_10_head));
    let v1028_3: Space = intersect(&(*CONSTANT_7),&(v1028_2));
    let v1028_4: Space = if has_head(&(v1028_3)) { singleton(&[]) } else { Space::new() };
    drop(v1028_3);
    let v1028_5: Space = subtract(&(*CONSTANT_0),&(v1028_4));
    drop(v1028_4);
    let v1028_8: Space = if (v1028_5).is_empty() { Space::new() } else {
      let v1029_6: Path = concat_path(&(*p0),&(v1027_10_head));
      let v1029_7: Space = routine_98(c, &(v1029_6), &(*p1), &(*p2), &(v1027_10_tail));
      compose(&(v1028_5),&(v1029_7))
    };
    drop(v1028_5);
    let v1028_9: Space = intersect(&(*CONSTANT_7),&(v1028_2));
    drop(v1028_2);
    let v1028_10: Space = if has_head(&(v1028_9)) { singleton(&[]) } else { Space::new() };
    drop(v1028_9);
    let v1028_12: Space = if (v1028_10).is_empty() { Space::new() } else {
      let v1030_6: Path = concat_path(&(*p0),&(v1027_10_head));
      let mut v1030_11 = Space::new();
      let mut v1030_11_cursor = (v1027_10_tail).read_zipper();
      for v1030_11_byte in v1030_11_cursor.child_mask().iter() {
        v1030_11_cursor.descend_to_byte(v1030_11_byte);
        let v1030_11_tail = v1030_11_cursor.make_map();
        v1030_11_cursor.ascend(1);
        let v1030_11_head = Path::from_slice(&[v1030_11_byte]);
        let v1031_2: Space = singleton(&(v1030_11_head));
        let v1031_3: Space = intersect(&(*CONSTANT_7),&(v1031_2));
        let v1031_4: Space = if has_head(&(v1031_3)) { singleton(&[]) } else { Space::new() };
        drop(v1031_3);
        let v1031_5: Space = subtract(&(*CONSTANT_0),&(v1031_4));
        drop(v1031_4);
        let v1031_7: Space = if (v1031_5).is_empty() { Space::new() } else {
          let v1032_6: Space = routine_120(c, &(v1030_11_head), &(*p1), &(*p2), &(v1030_6), &(v1030_11_tail));
          compose(&(v1031_5),&(v1032_6))
        };
        drop(v1031_5);
        let v1031_8: Space = intersect(&(*CONSTANT_7),&(v1031_2));
        drop(v1031_2);
        let v1031_9: Space = if has_head(&(v1031_8)) { singleton(&[]) } else { Space::new() };
        drop(v1031_8);
        let v1031_11: Space = if (v1031_9).is_empty() { Space::new() } else {
          let v1033_10: Space = routine_121(c, &(v1030_11_head), &(*p1), &(*p2), &(v1030_6), &(v1030_11_tail));
          compose(&(v1031_9),&(v1033_10))
        };
        drop(v1031_9);
        let v1031_12: Space = unite(&(v1031_7),&(v1031_11));
        v1030_11.join_into((v1031_12).clone());
      }
      drop(v1030_11_cursor);
      drop(v1030_6);
      compose(&(v1028_10),&(v1030_11))
    };
    drop(v1028_10);
    let v1028_13: Space = unite(&(v1028_8),&(v1028_12));
    v1027_10.join_into((v1028_13).clone());
  }
  drop(v1027_10_cursor);
  (v1027_10).clone()
}

fn routine_99(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v1034_13 = Space::new();
  let mut v1034_13_cursor = (*s0).read_zipper();
  for v1034_13_byte in v1034_13_cursor.child_mask().iter() {
    v1034_13_cursor.descend_to_byte(v1034_13_byte);
    let v1034_13_tail = v1034_13_cursor.make_map();
    v1034_13_cursor.ascend(1);
    let v1034_13_head = Path::from_slice(&[v1034_13_byte]);
    let v1035_2: Space = singleton(&(v1034_13_head));
    let v1035_3: Space = intersect(&(*CONSTANT_7),&(v1035_2));
    let v1035_4: Space = if has_head(&(v1035_3)) { singleton(&[]) } else { Space::new() };
    drop(v1035_3);
    let v1035_5: Space = subtract(&(*CONSTANT_0),&(v1035_4));
    drop(v1035_4);
    let v1035_7: Space = if (v1035_5).is_empty() { Space::new() } else {
      let mut v1036_6 = Space::new();
      let mut v1036_6_cursor = (v1034_13_tail).read_zipper();
      for v1036_6_byte in v1036_6_cursor.child_mask().iter() {
        v1036_6_cursor.descend_to_byte(v1036_6_byte);
        let v1036_6_tail = v1036_6_cursor.make_map();
        v1036_6_cursor.ascend(1);
        let v1036_6_head = Path::from_slice(&[v1036_6_byte]);
        let v1037_2: Space = singleton(&(v1036_6_head));
        let v1037_3: Space = intersect(&(*CONSTANT_7),&(v1037_2));
        let v1037_4: Space = if has_head(&(v1037_3)) { singleton(&[]) } else { Space::new() };
        drop(v1037_3);
        let v1037_5: Space = subtract(&(*CONSTANT_0),&(v1037_4));
        drop(v1037_4);
        let v1037_8: Space = if (v1037_5).is_empty() { Space::new() } else {
          let v1038_6: Path = concat_path(&(v1034_13_head),&(v1036_6_head));
          let v1038_7: Space = routine_120(c, &(v1038_6), &(*p1), &(*p2), &(*p0), &(v1036_6_tail));
          compose(&(v1037_5),&(v1038_7))
        };
        drop(v1037_5);
        let v1037_9: Space = intersect(&(*CONSTANT_7),&(v1037_2));
        drop(v1037_2);
        let v1037_10: Space = if has_head(&(v1037_9)) { singleton(&[]) } else { Space::new() };
        drop(v1037_9);
        let v1037_12: Space = if (v1037_10).is_empty() { Space::new() } else {
          let v1039_6: Path = concat_path(&(v1034_13_head),&(v1036_6_head));
          let v1039_11: Space = routine_121(c, &(v1039_6), &(*p1), &(*p2), &(*p0), &(v1036_6_tail));
          drop(v1039_6);
          compose(&(v1037_10),&(v1039_11))
        };
        drop(v1037_10);
        let v1037_13: Space = unite(&(v1037_8),&(v1037_12));
        v1036_6.join_into((v1037_13).clone());
      }
      drop(v1036_6_cursor);
      compose(&(v1035_5),&(v1036_6))
    };
    drop(v1035_5);
    let v1035_8: Space = intersect(&(*CONSTANT_7),&(v1035_2));
    drop(v1035_2);
    let v1035_9: Space = if has_head(&(v1035_8)) { singleton(&[]) } else { Space::new() };
    drop(v1035_8);
    let v1035_11: Space = if (v1035_9).is_empty() { Space::new() } else {
      let mut v1040_10 = Space::new();
      let mut v1040_10_cursor = (v1034_13_tail).read_zipper();
      for v1040_10_byte in v1040_10_cursor.child_mask().iter() {
        v1040_10_cursor.descend_to_byte(v1040_10_byte);
        let v1040_10_tail = v1040_10_cursor.make_map();
        v1040_10_cursor.ascend(1);
        let v1040_10_head = Path::from_slice(&[v1040_10_byte]);
        let v1041_2: Space = singleton(&(v1040_10_head));
        let v1041_3: Space = intersect(&(*CONSTANT_7),&(v1041_2));
        let v1041_4: Space = if has_head(&(v1041_3)) { singleton(&[]) } else { Space::new() };
        drop(v1041_3);
        let v1041_5: Space = subtract(&(*CONSTANT_0),&(v1041_4));
        drop(v1041_4);
        let v1041_7: Space = if (v1041_5).is_empty() { Space::new() } else {
          let v1042_6: Space = routine_138(c, &(v1040_10_head), &(*p1), &(*p2), &(*p0), &(v1034_13_head), &(v1040_10_tail));
          compose(&(v1041_5),&(v1042_6))
        };
        drop(v1041_5);
        let v1041_8: Space = intersect(&(*CONSTANT_7),&(v1041_2));
        drop(v1041_2);
        let v1041_9: Space = if has_head(&(v1041_8)) { singleton(&[]) } else { Space::new() };
        drop(v1041_8);
        let v1041_11: Space = if (v1041_9).is_empty() { Space::new() } else {
          let v1043_10: Space = routine_139(c, &(v1040_10_head), &(*p1), &(*p2), &(*p0), &(v1034_13_head), &(v1040_10_tail));
          compose(&(v1041_9),&(v1043_10))
        };
        drop(v1041_9);
        let v1041_12: Space = unite(&(v1041_7),&(v1041_11));
        v1040_10.join_into((v1041_12).clone());
      }
      drop(v1040_10_cursor);
      compose(&(v1035_9),&(v1040_10))
    };
    drop(v1035_9);
    let v1035_12: Space = unite(&(v1035_7),&(v1035_11));
    v1034_13.join_into((v1035_12).clone());
  }
  drop(v1034_13_cursor);
  (v1034_13).clone()
}

fn routine_100(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v1044_10 = Space::new();
  let mut v1044_10_cursor = (*s0).read_zipper();
  for v1044_10_byte in v1044_10_cursor.child_mask().iter() {
    v1044_10_cursor.descend_to_byte(v1044_10_byte);
    let v1044_10_tail = v1044_10_cursor.make_map();
    v1044_10_cursor.ascend(1);
    let v1044_10_head = Path::from_slice(&[v1044_10_byte]);
    let v1045_2: Space = singleton(&(v1044_10_head));
    let v1045_3: Space = intersect(&(*CONSTANT_7),&(v1045_2));
    let v1045_4: Space = if has_head(&(v1045_3)) { singleton(&[]) } else { Space::new() };
    drop(v1045_3);
    let v1045_5: Space = subtract(&(*CONSTANT_0),&(v1045_4));
    drop(v1045_4);
    let v1045_8: Space = if (v1045_5).is_empty() { Space::new() } else {
      let v1046_6: Path = concat_path(&(*p0),&(v1044_10_head));
      let v1046_7: Space = routine_100(c, &(v1046_6), &(*p1), &(*p2), &(v1044_10_tail));
      compose(&(v1045_5),&(v1046_7))
    };
    drop(v1045_5);
    let v1045_9: Space = intersect(&(*CONSTANT_7),&(v1045_2));
    drop(v1045_2);
    let v1045_10: Space = if has_head(&(v1045_9)) { singleton(&[]) } else { Space::new() };
    drop(v1045_9);
    let v1045_12: Space = if (v1045_10).is_empty() { Space::new() } else {
      let v1047_6: Path = concat_path(&(*p0),&(v1044_10_head));
      let mut v1047_11 = Space::new();
      let mut v1047_11_cursor = (v1044_10_tail).read_zipper();
      for v1047_11_byte in v1047_11_cursor.child_mask().iter() {
        v1047_11_cursor.descend_to_byte(v1047_11_byte);
        let v1047_11_tail = v1047_11_cursor.make_map();
        v1047_11_cursor.ascend(1);
        let v1047_11_head = Path::from_slice(&[v1047_11_byte]);
        let v1048_2: Space = singleton(&(v1047_11_head));
        let v1048_3: Space = intersect(&(*CONSTANT_7),&(v1048_2));
        let v1048_4: Space = if has_head(&(v1048_3)) { singleton(&[]) } else { Space::new() };
        drop(v1048_3);
        let v1048_5: Space = subtract(&(*CONSTANT_0),&(v1048_4));
        drop(v1048_4);
        let v1048_7: Space = if (v1048_5).is_empty() { Space::new() } else {
          let v1049_6: Space = routine_122(c, &(v1047_11_head), &(*p1), &(*p2), &(v1047_6), &(v1047_11_tail));
          compose(&(v1048_5),&(v1049_6))
        };
        drop(v1048_5);
        let v1048_8: Space = intersect(&(*CONSTANT_7),&(v1048_2));
        drop(v1048_2);
        let v1048_9: Space = if has_head(&(v1048_8)) { singleton(&[]) } else { Space::new() };
        drop(v1048_8);
        let v1048_11: Space = if (v1048_9).is_empty() { Space::new() } else {
          let v1050_10: Space = routine_123(c, &(v1047_11_head), &(*p1), &(*p2), &(v1047_6), &(v1047_11_tail));
          compose(&(v1048_9),&(v1050_10))
        };
        drop(v1048_9);
        let v1048_12: Space = unite(&(v1048_7),&(v1048_11));
        v1047_11.join_into((v1048_12).clone());
      }
      drop(v1047_11_cursor);
      drop(v1047_6);
      compose(&(v1045_10),&(v1047_11))
    };
    drop(v1045_10);
    let v1045_13: Space = unite(&(v1045_8),&(v1045_12));
    v1044_10.join_into((v1045_13).clone());
  }
  drop(v1044_10_cursor);
  (v1044_10).clone()
}

fn routine_101(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v1051_13 = Space::new();
  let mut v1051_13_cursor = (*s0).read_zipper();
  for v1051_13_byte in v1051_13_cursor.child_mask().iter() {
    v1051_13_cursor.descend_to_byte(v1051_13_byte);
    let v1051_13_tail = v1051_13_cursor.make_map();
    v1051_13_cursor.ascend(1);
    let v1051_13_head = Path::from_slice(&[v1051_13_byte]);
    let v1052_2: Space = singleton(&(v1051_13_head));
    let v1052_3: Space = intersect(&(*CONSTANT_7),&(v1052_2));
    let v1052_4: Space = if has_head(&(v1052_3)) { singleton(&[]) } else { Space::new() };
    drop(v1052_3);
    let v1052_5: Space = subtract(&(*CONSTANT_0),&(v1052_4));
    drop(v1052_4);
    let v1052_7: Space = if (v1052_5).is_empty() { Space::new() } else {
      let mut v1053_6 = Space::new();
      let mut v1053_6_cursor = (v1051_13_tail).read_zipper();
      for v1053_6_byte in v1053_6_cursor.child_mask().iter() {
        v1053_6_cursor.descend_to_byte(v1053_6_byte);
        let v1053_6_tail = v1053_6_cursor.make_map();
        v1053_6_cursor.ascend(1);
        let v1053_6_head = Path::from_slice(&[v1053_6_byte]);
        let v1054_2: Space = singleton(&(v1053_6_head));
        let v1054_3: Space = intersect(&(*CONSTANT_7),&(v1054_2));
        let v1054_4: Space = if has_head(&(v1054_3)) { singleton(&[]) } else { Space::new() };
        drop(v1054_3);
        let v1054_5: Space = subtract(&(*CONSTANT_0),&(v1054_4));
        drop(v1054_4);
        let v1054_8: Space = if (v1054_5).is_empty() { Space::new() } else {
          let v1055_6: Path = concat_path(&(v1051_13_head),&(v1053_6_head));
          let v1055_7: Space = routine_122(c, &(v1055_6), &(*p1), &(*p2), &(*p0), &(v1053_6_tail));
          compose(&(v1054_5),&(v1055_7))
        };
        drop(v1054_5);
        let v1054_9: Space = intersect(&(*CONSTANT_7),&(v1054_2));
        drop(v1054_2);
        let v1054_10: Space = if has_head(&(v1054_9)) { singleton(&[]) } else { Space::new() };
        drop(v1054_9);
        let v1054_12: Space = if (v1054_10).is_empty() { Space::new() } else {
          let v1056_6: Path = concat_path(&(v1051_13_head),&(v1053_6_head));
          let v1056_11: Space = routine_123(c, &(v1056_6), &(*p1), &(*p2), &(*p0), &(v1053_6_tail));
          drop(v1056_6);
          compose(&(v1054_10),&(v1056_11))
        };
        drop(v1054_10);
        let v1054_13: Space = unite(&(v1054_8),&(v1054_12));
        v1053_6.join_into((v1054_13).clone());
      }
      drop(v1053_6_cursor);
      compose(&(v1052_5),&(v1053_6))
    };
    drop(v1052_5);
    let v1052_8: Space = intersect(&(*CONSTANT_7),&(v1052_2));
    drop(v1052_2);
    let v1052_9: Space = if has_head(&(v1052_8)) { singleton(&[]) } else { Space::new() };
    drop(v1052_8);
    let v1052_11: Space = if (v1052_9).is_empty() { Space::new() } else {
      let mut v1057_10 = Space::new();
      let mut v1057_10_cursor = (v1051_13_tail).read_zipper();
      for v1057_10_byte in v1057_10_cursor.child_mask().iter() {
        v1057_10_cursor.descend_to_byte(v1057_10_byte);
        let v1057_10_tail = v1057_10_cursor.make_map();
        v1057_10_cursor.ascend(1);
        let v1057_10_head = Path::from_slice(&[v1057_10_byte]);
        let v1058_2: Space = singleton(&(v1057_10_head));
        let v1058_3: Space = intersect(&(*CONSTANT_7),&(v1058_2));
        let v1058_4: Space = if has_head(&(v1058_3)) { singleton(&[]) } else { Space::new() };
        drop(v1058_3);
        let v1058_5: Space = subtract(&(*CONSTANT_0),&(v1058_4));
        drop(v1058_4);
        let v1058_7: Space = if (v1058_5).is_empty() { Space::new() } else {
          let v1059_6: Space = routine_140(c, &(v1057_10_head), &(*p1), &(*p2), &(*p0), &(v1051_13_head), &(v1057_10_tail));
          compose(&(v1058_5),&(v1059_6))
        };
        drop(v1058_5);
        let v1058_8: Space = intersect(&(*CONSTANT_7),&(v1058_2));
        drop(v1058_2);
        let v1058_9: Space = if has_head(&(v1058_8)) { singleton(&[]) } else { Space::new() };
        drop(v1058_8);
        let v1058_11: Space = if (v1058_9).is_empty() { Space::new() } else {
          let v1060_10: Space = routine_141(c, &(v1057_10_head), &(*p1), &(*p2), &(*p0), &(v1051_13_head), &(v1057_10_tail));
          compose(&(v1058_9),&(v1060_10))
        };
        drop(v1058_9);
        let v1058_12: Space = unite(&(v1058_7),&(v1058_11));
        v1057_10.join_into((v1058_12).clone());
      }
      drop(v1057_10_cursor);
      compose(&(v1052_9),&(v1057_10))
    };
    drop(v1052_9);
    let v1052_12: Space = unite(&(v1052_7),&(v1052_11));
    v1051_13.join_into((v1052_12).clone());
  }
  drop(v1051_13_cursor);
  (v1051_13).clone()
}

fn routine_102(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1061_10 = Space::new();
  let mut v1061_10_cursor = (*s0).read_zipper();
  for v1061_10_byte in v1061_10_cursor.child_mask().iter() {
    v1061_10_cursor.descend_to_byte(v1061_10_byte);
    let v1061_10_tail = v1061_10_cursor.make_map();
    v1061_10_cursor.ascend(1);
    let v1061_10_head = Path::from_slice(&[v1061_10_byte]);
    let v1062_2: Space = singleton(&(v1061_10_head));
    let v1062_3: Space = intersect(&(*CONSTANT_7),&(v1062_2));
    let v1062_4: Space = if has_head(&(v1062_3)) { singleton(&[]) } else { Space::new() };
    drop(v1062_3);
    let v1062_5: Space = subtract(&(*CONSTANT_0),&(v1062_4));
    drop(v1062_4);
    let v1062_8: Space = if (v1062_5).is_empty() { Space::new() } else {
      let v1063_6: Path = concat_path(&(*p0),&(v1061_10_head));
      let v1063_7: Space = routine_102(c, &(v1063_6), &(*p1), &(v1061_10_tail));
      compose(&(v1062_5),&(v1063_7))
    };
    drop(v1062_5);
    let v1062_9: Space = intersect(&(*CONSTANT_7),&(v1062_2));
    drop(v1062_2);
    let v1062_10: Space = if has_head(&(v1062_9)) { singleton(&[]) } else { Space::new() };
    drop(v1062_9);
    let v1062_14: Space = if (v1062_10).is_empty() { Space::new() } else {
      let mut v1064_11 = Space::new();
      let mut v1064_11_cursor = (v1061_10_tail).read_zipper();
      for v1064_11_byte in v1064_11_cursor.child_mask().iter() {
        v1064_11_cursor.descend_to_byte(v1064_11_byte);
        let v1064_11_tail = v1064_11_cursor.make_map();
        v1064_11_cursor.ascend(1);
        let v1064_11_head = Path::from_slice(&[v1064_11_byte]);
        let v1065_2: Space = singleton(&(v1064_11_head));
        let v1065_3: Space = intersect(&(*CONSTANT_7),&(v1065_2));
        let v1065_4: Space = if has_head(&(v1065_3)) { singleton(&[]) } else { Space::new() };
        drop(v1065_3);
        let v1065_5: Space = subtract(&(*CONSTANT_0),&(v1065_4));
        drop(v1065_4);
        let v1065_7: Space = if (v1065_5).is_empty() { Space::new() } else {
          let v1066_6: Space = routine_142(c, &(v1064_11_head), &(v1064_11_tail));
          compose(&(v1065_5),&(v1066_6))
        };
        drop(v1065_5);
        let v1065_8: Space = intersect(&(*CONSTANT_7),&(v1065_2));
        drop(v1065_2);
        let v1065_9: Space = if has_head(&(v1065_8)) { singleton(&[]) } else { Space::new() };
        drop(v1065_8);
        let v1065_11: Space = if (v1065_9).is_empty() { Space::new() } else {
          let v1067_10: Space = routine_143(c, &(v1064_11_head), &(v1064_11_tail));
          compose(&(v1065_9),&(v1067_10))
        };
        drop(v1065_9);
        let v1065_12: Space = unite(&(v1065_7),&(v1065_11));
        v1064_11.join_into((v1065_12).clone());
      }
      drop(v1064_11_cursor);
      let v1064_12: Space = raffine(&(*CONSTANT_31),&(v1064_11));
      let v1064_13: Space = unite(&(v1064_12),&(v1061_10_tail));
      compose(&(v1062_10),&(v1064_13))
    };
    drop(v1062_10);
    let v1068_6: Path = concat_path(&(*p0),&(v1061_10_head));
    let v1062_15: Path = concat_path(&(*p1),&(v1068_6));
    let v1062_16: Space = wrap(&(v1062_14),&(v1062_15));
    drop(v1062_15);
    let v1062_17: Space = unite(&(v1062_8),&(v1062_16));
    v1061_10.join_into((v1062_17).clone());
  }
  drop(v1061_10_cursor);
  (v1061_10).clone()
}

fn routine_103(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1069_10 = Space::new();
  let mut v1069_10_cursor = (*s0).read_zipper();
  for v1069_10_byte in v1069_10_cursor.child_mask().iter() {
    v1069_10_cursor.descend_to_byte(v1069_10_byte);
    let v1069_10_tail = v1069_10_cursor.make_map();
    v1069_10_cursor.ascend(1);
    let v1069_10_head = Path::from_slice(&[v1069_10_byte]);
    let v1070_2: Space = singleton(&(v1069_10_head));
    let v1070_3: Space = intersect(&(*CONSTANT_7),&(v1070_2));
    let v1070_4: Space = if has_head(&(v1070_3)) { singleton(&[]) } else { Space::new() };
    drop(v1070_3);
    let v1070_5: Space = subtract(&(*CONSTANT_0),&(v1070_4));
    drop(v1070_4);
    let v1070_7: Space = if (v1070_5).is_empty() { Space::new() } else {
      let mut v1071_6 = Space::new();
      let mut v1071_6_cursor = (v1069_10_tail).read_zipper();
      for v1071_6_byte in v1071_6_cursor.child_mask().iter() {
        v1071_6_cursor.descend_to_byte(v1071_6_byte);
        let v1071_6_tail = v1071_6_cursor.make_map();
        v1071_6_cursor.ascend(1);
        let v1071_6_head = Path::from_slice(&[v1071_6_byte]);
        let v1072_2: Space = singleton(&(v1071_6_head));
        let v1072_3: Space = intersect(&(*CONSTANT_7),&(v1072_2));
        let v1072_4: Space = if has_head(&(v1072_3)) { singleton(&[]) } else { Space::new() };
        drop(v1072_3);
        let v1072_5: Space = subtract(&(*CONSTANT_0),&(v1072_4));
        drop(v1072_4);
        let v1072_8: Space = if (v1072_5).is_empty() { Space::new() } else {
          let v1073_6: Path = concat_path(&(v1069_10_head),&(v1071_6_head));
          let v1073_7: Space = routine_142(c, &(v1073_6), &(v1071_6_tail));
          compose(&(v1072_5),&(v1073_7))
        };
        drop(v1072_5);
        let v1072_9: Space = intersect(&(*CONSTANT_7),&(v1072_2));
        drop(v1072_2);
        let v1072_10: Space = if has_head(&(v1072_9)) { singleton(&[]) } else { Space::new() };
        drop(v1072_9);
        let v1072_12: Space = if (v1072_10).is_empty() { Space::new() } else {
          let v1074_6: Path = concat_path(&(v1069_10_head),&(v1071_6_head));
          let v1074_11: Space = routine_143(c, &(v1074_6), &(v1071_6_tail));
          drop(v1074_6);
          compose(&(v1072_10),&(v1074_11))
        };
        drop(v1072_10);
        let v1072_13: Space = unite(&(v1072_8),&(v1072_12));
        v1071_6.join_into((v1072_13).clone());
      }
      drop(v1071_6_cursor);
      compose(&(v1070_5),&(v1071_6))
    };
    drop(v1070_5);
    let v1070_8: Space = intersect(&(*CONSTANT_7),&(v1070_2));
    let v1070_9: Space = if has_head(&(v1070_8)) { singleton(&[]) } else { Space::new() };
    drop(v1070_8);
    let v1070_10: Space = compose(&(v1070_9),&(v1070_2));
    drop(v1070_2);
    drop(v1070_9);
    let v1070_11: Space = unite(&(v1070_7),&(v1070_10));
    drop(v1070_10);
    v1069_10.join_into((v1070_11).clone());
  }
  drop(v1069_10_cursor);
  let v1069_11: Space = raffine(&(*CONSTANT_31),&(v1069_10));
  let v1069_12: Space = unite(&(v1069_11),&(*s0));
  let v1069_13: Path = concat_path(&(*p1),&(*p0));
  let v1069_14: Space = wrap(&(v1069_12),&(v1069_13));
  drop(v1069_13);
  (v1069_14).clone()
}

fn routine_104(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1075_10 = Space::new();
  let mut v1075_10_cursor = (*s0).read_zipper();
  for v1075_10_byte in v1075_10_cursor.child_mask().iter() {
    v1075_10_cursor.descend_to_byte(v1075_10_byte);
    let v1075_10_tail = v1075_10_cursor.make_map();
    v1075_10_cursor.ascend(1);
    let v1075_10_head = Path::from_slice(&[v1075_10_byte]);
    let v1076_2: Space = singleton(&(v1075_10_head));
    let v1076_3: Space = intersect(&(*CONSTANT_7),&(v1076_2));
    let v1076_4: Space = if has_head(&(v1076_3)) { singleton(&[]) } else { Space::new() };
    drop(v1076_3);
    let v1076_5: Space = subtract(&(*CONSTANT_0),&(v1076_4));
    drop(v1076_4);
    let v1076_8: Space = if (v1076_5).is_empty() { Space::new() } else {
      let v1077_6: Path = concat_path(&(*p0),&(v1075_10_head));
      let v1077_7: Space = routine_104(c, &(v1077_6), &(*p1), &(v1075_10_tail));
      compose(&(v1076_5),&(v1077_7))
    };
    drop(v1076_5);
    let v1076_9: Space = intersect(&(*CONSTANT_7),&(v1076_2));
    drop(v1076_2);
    let v1076_10: Space = if has_head(&(v1076_9)) { singleton(&[]) } else { Space::new() };
    drop(v1076_9);
    let v1076_14: Space = if (v1076_10).is_empty() { Space::new() } else {
      let mut v1078_11 = Space::new();
      let mut v1078_11_cursor = (v1075_10_tail).read_zipper();
      for v1078_11_byte in v1078_11_cursor.child_mask().iter() {
        v1078_11_cursor.descend_to_byte(v1078_11_byte);
        let v1078_11_tail = v1078_11_cursor.make_map();
        v1078_11_cursor.ascend(1);
        let v1078_11_head = Path::from_slice(&[v1078_11_byte]);
        let v1079_2: Space = singleton(&(v1078_11_head));
        let v1079_3: Space = intersect(&(*CONSTANT_7),&(v1079_2));
        let v1079_4: Space = if has_head(&(v1079_3)) { singleton(&[]) } else { Space::new() };
        drop(v1079_3);
        let v1079_5: Space = subtract(&(*CONSTANT_0),&(v1079_4));
        drop(v1079_4);
        let v1079_7: Space = if (v1079_5).is_empty() { Space::new() } else {
          let v1080_6: Space = routine_144(c, &(v1078_11_head), &(v1078_11_tail));
          compose(&(v1079_5),&(v1080_6))
        };
        drop(v1079_5);
        let v1079_8: Space = intersect(&(*CONSTANT_7),&(v1079_2));
        drop(v1079_2);
        let v1079_9: Space = if has_head(&(v1079_8)) { singleton(&[]) } else { Space::new() };
        drop(v1079_8);
        let v1079_11: Space = if (v1079_9).is_empty() { Space::new() } else {
          let v1081_10: Space = routine_145(c, &(v1078_11_head), &(v1078_11_tail));
          compose(&(v1079_9),&(v1081_10))
        };
        drop(v1079_9);
        let v1079_12: Space = unite(&(v1079_7),&(v1079_11));
        v1078_11.join_into((v1079_12).clone());
      }
      drop(v1078_11_cursor);
      let v1078_12: Space = raffine(&(*CONSTANT_31),&(v1078_11));
      let v1078_13: Space = unite(&(v1078_12),&(v1075_10_tail));
      compose(&(v1076_10),&(v1078_13))
    };
    drop(v1076_10);
    let v1082_6: Path = concat_path(&(*p0),&(v1075_10_head));
    let v1076_15: Path = concat_path(&(*p1),&(v1082_6));
    let v1076_16: Space = wrap(&(v1076_14),&(v1076_15));
    drop(v1076_15);
    let v1076_17: Space = unite(&(v1076_8),&(v1076_16));
    v1075_10.join_into((v1076_17).clone());
  }
  drop(v1075_10_cursor);
  (v1075_10).clone()
}

fn routine_105(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1083_10 = Space::new();
  let mut v1083_10_cursor = (*s0).read_zipper();
  for v1083_10_byte in v1083_10_cursor.child_mask().iter() {
    v1083_10_cursor.descend_to_byte(v1083_10_byte);
    let v1083_10_tail = v1083_10_cursor.make_map();
    v1083_10_cursor.ascend(1);
    let v1083_10_head = Path::from_slice(&[v1083_10_byte]);
    let v1084_2: Space = singleton(&(v1083_10_head));
    let v1084_3: Space = intersect(&(*CONSTANT_7),&(v1084_2));
    let v1084_4: Space = if has_head(&(v1084_3)) { singleton(&[]) } else { Space::new() };
    drop(v1084_3);
    let v1084_5: Space = subtract(&(*CONSTANT_0),&(v1084_4));
    drop(v1084_4);
    let v1084_7: Space = if (v1084_5).is_empty() { Space::new() } else {
      let mut v1085_6 = Space::new();
      let mut v1085_6_cursor = (v1083_10_tail).read_zipper();
      for v1085_6_byte in v1085_6_cursor.child_mask().iter() {
        v1085_6_cursor.descend_to_byte(v1085_6_byte);
        let v1085_6_tail = v1085_6_cursor.make_map();
        v1085_6_cursor.ascend(1);
        let v1085_6_head = Path::from_slice(&[v1085_6_byte]);
        let v1086_2: Space = singleton(&(v1085_6_head));
        let v1086_3: Space = intersect(&(*CONSTANT_7),&(v1086_2));
        let v1086_4: Space = if has_head(&(v1086_3)) { singleton(&[]) } else { Space::new() };
        drop(v1086_3);
        let v1086_5: Space = subtract(&(*CONSTANT_0),&(v1086_4));
        drop(v1086_4);
        let v1086_8: Space = if (v1086_5).is_empty() { Space::new() } else {
          let v1087_6: Path = concat_path(&(v1083_10_head),&(v1085_6_head));
          let v1087_7: Space = routine_144(c, &(v1087_6), &(v1085_6_tail));
          compose(&(v1086_5),&(v1087_7))
        };
        drop(v1086_5);
        let v1086_9: Space = intersect(&(*CONSTANT_7),&(v1086_2));
        drop(v1086_2);
        let v1086_10: Space = if has_head(&(v1086_9)) { singleton(&[]) } else { Space::new() };
        drop(v1086_9);
        let v1086_12: Space = if (v1086_10).is_empty() { Space::new() } else {
          let v1088_6: Path = concat_path(&(v1083_10_head),&(v1085_6_head));
          let v1088_11: Space = routine_145(c, &(v1088_6), &(v1085_6_tail));
          drop(v1088_6);
          compose(&(v1086_10),&(v1088_11))
        };
        drop(v1086_10);
        let v1086_13: Space = unite(&(v1086_8),&(v1086_12));
        v1085_6.join_into((v1086_13).clone());
      }
      drop(v1085_6_cursor);
      compose(&(v1084_5),&(v1085_6))
    };
    drop(v1084_5);
    let v1084_8: Space = intersect(&(*CONSTANT_7),&(v1084_2));
    let v1084_9: Space = if has_head(&(v1084_8)) { singleton(&[]) } else { Space::new() };
    drop(v1084_8);
    let v1084_10: Space = compose(&(v1084_9),&(v1084_2));
    drop(v1084_2);
    drop(v1084_9);
    let v1084_11: Space = unite(&(v1084_7),&(v1084_10));
    drop(v1084_10);
    v1083_10.join_into((v1084_11).clone());
  }
  drop(v1083_10_cursor);
  let v1083_11: Space = raffine(&(*CONSTANT_31),&(v1083_10));
  let v1083_12: Space = unite(&(v1083_11),&(*s0));
  let v1083_13: Path = concat_path(&(*p1),&(*p0));
  let v1083_14: Space = wrap(&(v1083_12),&(v1083_13));
  drop(v1083_13);
  (v1083_14).clone()
}

fn routine_106(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1089_11 = Space::new();
  let mut v1089_11_cursor = (*s0).read_zipper();
  for v1089_11_byte in v1089_11_cursor.child_mask().iter() {
    v1089_11_cursor.descend_to_byte(v1089_11_byte);
    let v1089_11_tail = v1089_11_cursor.make_map();
    v1089_11_cursor.ascend(1);
    let v1089_11_head = Path::from_slice(&[v1089_11_byte]);
    let v1090_2: Space = singleton(&(v1089_11_head));
    let v1090_3: Space = intersect(&(*CONSTANT_7),&(v1090_2));
    let v1090_4: Space = if has_head(&(v1090_3)) { singleton(&[]) } else { Space::new() };
    drop(v1090_3);
    let v1090_5: Space = subtract(&(*CONSTANT_0),&(v1090_4));
    drop(v1090_4);
    let v1090_8: Space = if (v1090_5).is_empty() { Space::new() } else {
      let v1091_6: Path = concat_path(&(*p0),&(v1089_11_head));
      let v1091_7: Space = routine_106(c, &(v1091_6), &(*p1), &(*p2), &(*p3), &(v1089_11_tail));
      compose(&(v1090_5),&(v1091_7))
    };
    drop(v1090_5);
    let v1090_9: Space = intersect(&(*CONSTANT_7),&(v1090_2));
    drop(v1090_2);
    let v1090_10: Space = if has_head(&(v1090_9)) { singleton(&[]) } else { Space::new() };
    drop(v1090_9);
    let v1090_12: Space = if (v1090_10).is_empty() { Space::new() } else {
      let v1092_6: Path = concat_path(&(*p0),&(v1089_11_head));
      let mut v1092_11 = Space::new();
      let mut v1092_11_cursor = (v1089_11_tail).read_zipper();
      for v1092_11_byte in v1092_11_cursor.child_mask().iter() {
        v1092_11_cursor.descend_to_byte(v1092_11_byte);
        let v1092_11_tail = v1092_11_cursor.make_map();
        v1092_11_cursor.ascend(1);
        let v1092_11_head = Path::from_slice(&[v1092_11_byte]);
        let v1093_2: Space = singleton(&(v1092_11_head));
        let v1093_3: Space = intersect(&(*CONSTANT_7),&(v1093_2));
        let v1093_4: Space = if has_head(&(v1093_3)) { singleton(&[]) } else { Space::new() };
        drop(v1093_3);
        let v1093_5: Space = subtract(&(*CONSTANT_0),&(v1093_4));
        drop(v1093_4);
        let v1093_7: Space = if (v1093_5).is_empty() { Space::new() } else {
          let v1094_6: Space = routine_124(c, &(v1092_11_head), &(*p1), &(*p2), &(*p3), &(v1092_6), &(v1092_11_tail));
          compose(&(v1093_5),&(v1094_6))
        };
        drop(v1093_5);
        let v1093_8: Space = intersect(&(*CONSTANT_7),&(v1093_2));
        drop(v1093_2);
        let v1093_9: Space = if has_head(&(v1093_8)) { singleton(&[]) } else { Space::new() };
        drop(v1093_8);
        let v1093_11: Space = if (v1093_9).is_empty() { Space::new() } else {
          let v1095_10: Space = routine_125(c, &(v1092_11_head), &(*p1), &(*p2), &(*p3), &(v1092_6), &(v1092_11_tail));
          compose(&(v1093_9),&(v1095_10))
        };
        drop(v1093_9);
        let v1093_12: Space = unite(&(v1093_7),&(v1093_11));
        v1092_11.join_into((v1093_12).clone());
      }
      drop(v1092_11_cursor);
      drop(v1092_6);
      compose(&(v1090_10),&(v1092_11))
    };
    drop(v1090_10);
    let v1090_13: Space = unite(&(v1090_8),&(v1090_12));
    v1089_11.join_into((v1090_13).clone());
  }
  drop(v1089_11_cursor);
  (v1089_11).clone()
}

fn routine_107(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1096_14 = Space::new();
  let mut v1096_14_cursor = (*s0).read_zipper();
  for v1096_14_byte in v1096_14_cursor.child_mask().iter() {
    v1096_14_cursor.descend_to_byte(v1096_14_byte);
    let v1096_14_tail = v1096_14_cursor.make_map();
    v1096_14_cursor.ascend(1);
    let v1096_14_head = Path::from_slice(&[v1096_14_byte]);
    let v1097_2: Space = singleton(&(v1096_14_head));
    let v1097_3: Space = intersect(&(*CONSTANT_7),&(v1097_2));
    let v1097_4: Space = if has_head(&(v1097_3)) { singleton(&[]) } else { Space::new() };
    drop(v1097_3);
    let v1097_5: Space = subtract(&(*CONSTANT_0),&(v1097_4));
    drop(v1097_4);
    let v1097_7: Space = if (v1097_5).is_empty() { Space::new() } else {
      let mut v1098_6 = Space::new();
      let mut v1098_6_cursor = (v1096_14_tail).read_zipper();
      for v1098_6_byte in v1098_6_cursor.child_mask().iter() {
        v1098_6_cursor.descend_to_byte(v1098_6_byte);
        let v1098_6_tail = v1098_6_cursor.make_map();
        v1098_6_cursor.ascend(1);
        let v1098_6_head = Path::from_slice(&[v1098_6_byte]);
        let v1099_2: Space = singleton(&(v1098_6_head));
        let v1099_3: Space = intersect(&(*CONSTANT_7),&(v1099_2));
        let v1099_4: Space = if has_head(&(v1099_3)) { singleton(&[]) } else { Space::new() };
        drop(v1099_3);
        let v1099_5: Space = subtract(&(*CONSTANT_0),&(v1099_4));
        drop(v1099_4);
        let v1099_8: Space = if (v1099_5).is_empty() { Space::new() } else {
          let v1100_6: Path = concat_path(&(v1096_14_head),&(v1098_6_head));
          let v1100_7: Space = routine_124(c, &(v1100_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1098_6_tail));
          compose(&(v1099_5),&(v1100_7))
        };
        drop(v1099_5);
        let v1099_9: Space = intersect(&(*CONSTANT_7),&(v1099_2));
        drop(v1099_2);
        let v1099_10: Space = if has_head(&(v1099_9)) { singleton(&[]) } else { Space::new() };
        drop(v1099_9);
        let v1099_12: Space = if (v1099_10).is_empty() { Space::new() } else {
          let v1101_6: Path = concat_path(&(v1096_14_head),&(v1098_6_head));
          let v1101_11: Space = routine_125(c, &(v1101_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1098_6_tail));
          drop(v1101_6);
          compose(&(v1099_10),&(v1101_11))
        };
        drop(v1099_10);
        let v1099_13: Space = unite(&(v1099_8),&(v1099_12));
        v1098_6.join_into((v1099_13).clone());
      }
      drop(v1098_6_cursor);
      compose(&(v1097_5),&(v1098_6))
    };
    drop(v1097_5);
    let v1097_8: Space = intersect(&(*CONSTANT_7),&(v1097_2));
    drop(v1097_2);
    let v1097_9: Space = if has_head(&(v1097_8)) { singleton(&[]) } else { Space::new() };
    drop(v1097_8);
    let v1097_11: Space = if (v1097_9).is_empty() { Space::new() } else {
      let mut v1102_10 = Space::new();
      let mut v1102_10_cursor = (v1096_14_tail).read_zipper();
      for v1102_10_byte in v1102_10_cursor.child_mask().iter() {
        v1102_10_cursor.descend_to_byte(v1102_10_byte);
        let v1102_10_tail = v1102_10_cursor.make_map();
        v1102_10_cursor.ascend(1);
        let v1102_10_head = Path::from_slice(&[v1102_10_byte]);
        let v1103_2: Space = singleton(&(v1102_10_head));
        let v1103_3: Space = intersect(&(*CONSTANT_7),&(v1103_2));
        let v1103_4: Space = if has_head(&(v1103_3)) { singleton(&[]) } else { Space::new() };
        drop(v1103_3);
        let v1103_5: Space = subtract(&(*CONSTANT_0),&(v1103_4));
        drop(v1103_4);
        let v1103_7: Space = if (v1103_5).is_empty() { Space::new() } else {
          let v1104_6: Space = routine_146(c, &(v1102_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1096_14_head), &(v1102_10_tail));
          compose(&(v1103_5),&(v1104_6))
        };
        drop(v1103_5);
        let v1103_8: Space = intersect(&(*CONSTANT_7),&(v1103_2));
        drop(v1103_2);
        let v1103_9: Space = if has_head(&(v1103_8)) { singleton(&[]) } else { Space::new() };
        drop(v1103_8);
        let v1103_11: Space = if (v1103_9).is_empty() { Space::new() } else {
          let v1105_10: Space = routine_147(c, &(v1102_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1096_14_head), &(v1102_10_tail));
          compose(&(v1103_9),&(v1105_10))
        };
        drop(v1103_9);
        let v1103_12: Space = unite(&(v1103_7),&(v1103_11));
        v1102_10.join_into((v1103_12).clone());
      }
      drop(v1102_10_cursor);
      compose(&(v1097_9),&(v1102_10))
    };
    drop(v1097_9);
    let v1097_12: Space = unite(&(v1097_7),&(v1097_11));
    v1096_14.join_into((v1097_12).clone());
  }
  drop(v1096_14_cursor);
  (v1096_14).clone()
}

fn routine_108(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1106_11 = Space::new();
  let mut v1106_11_cursor = (*s0).read_zipper();
  for v1106_11_byte in v1106_11_cursor.child_mask().iter() {
    v1106_11_cursor.descend_to_byte(v1106_11_byte);
    let v1106_11_tail = v1106_11_cursor.make_map();
    v1106_11_cursor.ascend(1);
    let v1106_11_head = Path::from_slice(&[v1106_11_byte]);
    let v1107_2: Space = singleton(&(v1106_11_head));
    let v1107_3: Space = intersect(&(*CONSTANT_7),&(v1107_2));
    let v1107_4: Space = if has_head(&(v1107_3)) { singleton(&[]) } else { Space::new() };
    drop(v1107_3);
    let v1107_5: Space = subtract(&(*CONSTANT_0),&(v1107_4));
    drop(v1107_4);
    let v1107_8: Space = if (v1107_5).is_empty() { Space::new() } else {
      let v1108_6: Path = concat_path(&(*p0),&(v1106_11_head));
      let v1108_7: Space = routine_108(c, &(v1108_6), &(*p1), &(*p2), &(*p3), &(v1106_11_tail));
      compose(&(v1107_5),&(v1108_7))
    };
    drop(v1107_5);
    let v1107_9: Space = intersect(&(*CONSTANT_7),&(v1107_2));
    drop(v1107_2);
    let v1107_10: Space = if has_head(&(v1107_9)) { singleton(&[]) } else { Space::new() };
    drop(v1107_9);
    let v1107_12: Space = if (v1107_10).is_empty() { Space::new() } else {
      let v1109_6: Path = concat_path(&(*p0),&(v1106_11_head));
      let mut v1109_11 = Space::new();
      let mut v1109_11_cursor = (v1106_11_tail).read_zipper();
      for v1109_11_byte in v1109_11_cursor.child_mask().iter() {
        v1109_11_cursor.descend_to_byte(v1109_11_byte);
        let v1109_11_tail = v1109_11_cursor.make_map();
        v1109_11_cursor.ascend(1);
        let v1109_11_head = Path::from_slice(&[v1109_11_byte]);
        let v1110_2: Space = singleton(&(v1109_11_head));
        let v1110_3: Space = intersect(&(*CONSTANT_7),&(v1110_2));
        let v1110_4: Space = if has_head(&(v1110_3)) { singleton(&[]) } else { Space::new() };
        drop(v1110_3);
        let v1110_5: Space = subtract(&(*CONSTANT_0),&(v1110_4));
        drop(v1110_4);
        let v1110_7: Space = if (v1110_5).is_empty() { Space::new() } else {
          let v1111_6: Space = routine_126(c, &(v1109_11_head), &(*p1), &(*p2), &(*p3), &(v1109_6), &(v1109_11_tail));
          compose(&(v1110_5),&(v1111_6))
        };
        drop(v1110_5);
        let v1110_8: Space = intersect(&(*CONSTANT_7),&(v1110_2));
        drop(v1110_2);
        let v1110_9: Space = if has_head(&(v1110_8)) { singleton(&[]) } else { Space::new() };
        drop(v1110_8);
        let v1110_11: Space = if (v1110_9).is_empty() { Space::new() } else {
          let v1112_10: Space = routine_127(c, &(v1109_11_head), &(*p1), &(*p2), &(*p3), &(v1109_6), &(v1109_11_tail));
          compose(&(v1110_9),&(v1112_10))
        };
        drop(v1110_9);
        let v1110_12: Space = unite(&(v1110_7),&(v1110_11));
        v1109_11.join_into((v1110_12).clone());
      }
      drop(v1109_11_cursor);
      drop(v1109_6);
      compose(&(v1107_10),&(v1109_11))
    };
    drop(v1107_10);
    let v1107_13: Space = unite(&(v1107_8),&(v1107_12));
    v1106_11.join_into((v1107_13).clone());
  }
  drop(v1106_11_cursor);
  (v1106_11).clone()
}

fn routine_109(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1113_14 = Space::new();
  let mut v1113_14_cursor = (*s0).read_zipper();
  for v1113_14_byte in v1113_14_cursor.child_mask().iter() {
    v1113_14_cursor.descend_to_byte(v1113_14_byte);
    let v1113_14_tail = v1113_14_cursor.make_map();
    v1113_14_cursor.ascend(1);
    let v1113_14_head = Path::from_slice(&[v1113_14_byte]);
    let v1114_2: Space = singleton(&(v1113_14_head));
    let v1114_3: Space = intersect(&(*CONSTANT_7),&(v1114_2));
    let v1114_4: Space = if has_head(&(v1114_3)) { singleton(&[]) } else { Space::new() };
    drop(v1114_3);
    let v1114_5: Space = subtract(&(*CONSTANT_0),&(v1114_4));
    drop(v1114_4);
    let v1114_7: Space = if (v1114_5).is_empty() { Space::new() } else {
      let mut v1115_6 = Space::new();
      let mut v1115_6_cursor = (v1113_14_tail).read_zipper();
      for v1115_6_byte in v1115_6_cursor.child_mask().iter() {
        v1115_6_cursor.descend_to_byte(v1115_6_byte);
        let v1115_6_tail = v1115_6_cursor.make_map();
        v1115_6_cursor.ascend(1);
        let v1115_6_head = Path::from_slice(&[v1115_6_byte]);
        let v1116_2: Space = singleton(&(v1115_6_head));
        let v1116_3: Space = intersect(&(*CONSTANT_7),&(v1116_2));
        let v1116_4: Space = if has_head(&(v1116_3)) { singleton(&[]) } else { Space::new() };
        drop(v1116_3);
        let v1116_5: Space = subtract(&(*CONSTANT_0),&(v1116_4));
        drop(v1116_4);
        let v1116_8: Space = if (v1116_5).is_empty() { Space::new() } else {
          let v1117_6: Path = concat_path(&(v1113_14_head),&(v1115_6_head));
          let v1117_7: Space = routine_126(c, &(v1117_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1115_6_tail));
          compose(&(v1116_5),&(v1117_7))
        };
        drop(v1116_5);
        let v1116_9: Space = intersect(&(*CONSTANT_7),&(v1116_2));
        drop(v1116_2);
        let v1116_10: Space = if has_head(&(v1116_9)) { singleton(&[]) } else { Space::new() };
        drop(v1116_9);
        let v1116_12: Space = if (v1116_10).is_empty() { Space::new() } else {
          let v1118_6: Path = concat_path(&(v1113_14_head),&(v1115_6_head));
          let v1118_11: Space = routine_127(c, &(v1118_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1115_6_tail));
          drop(v1118_6);
          compose(&(v1116_10),&(v1118_11))
        };
        drop(v1116_10);
        let v1116_13: Space = unite(&(v1116_8),&(v1116_12));
        v1115_6.join_into((v1116_13).clone());
      }
      drop(v1115_6_cursor);
      compose(&(v1114_5),&(v1115_6))
    };
    drop(v1114_5);
    let v1114_8: Space = intersect(&(*CONSTANT_7),&(v1114_2));
    drop(v1114_2);
    let v1114_9: Space = if has_head(&(v1114_8)) { singleton(&[]) } else { Space::new() };
    drop(v1114_8);
    let v1114_11: Space = if (v1114_9).is_empty() { Space::new() } else {
      let mut v1119_10 = Space::new();
      let mut v1119_10_cursor = (v1113_14_tail).read_zipper();
      for v1119_10_byte in v1119_10_cursor.child_mask().iter() {
        v1119_10_cursor.descend_to_byte(v1119_10_byte);
        let v1119_10_tail = v1119_10_cursor.make_map();
        v1119_10_cursor.ascend(1);
        let v1119_10_head = Path::from_slice(&[v1119_10_byte]);
        let v1120_2: Space = singleton(&(v1119_10_head));
        let v1120_3: Space = intersect(&(*CONSTANT_7),&(v1120_2));
        let v1120_4: Space = if has_head(&(v1120_3)) { singleton(&[]) } else { Space::new() };
        drop(v1120_3);
        let v1120_5: Space = subtract(&(*CONSTANT_0),&(v1120_4));
        drop(v1120_4);
        let v1120_7: Space = if (v1120_5).is_empty() { Space::new() } else {
          let v1121_6: Space = routine_148(c, &(v1119_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1113_14_head), &(v1119_10_tail));
          compose(&(v1120_5),&(v1121_6))
        };
        drop(v1120_5);
        let v1120_8: Space = intersect(&(*CONSTANT_7),&(v1120_2));
        drop(v1120_2);
        let v1120_9: Space = if has_head(&(v1120_8)) { singleton(&[]) } else { Space::new() };
        drop(v1120_8);
        let v1120_11: Space = if (v1120_9).is_empty() { Space::new() } else {
          let v1122_10: Space = routine_149(c, &(v1119_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1113_14_head), &(v1119_10_tail));
          compose(&(v1120_9),&(v1122_10))
        };
        drop(v1120_9);
        let v1120_12: Space = unite(&(v1120_7),&(v1120_11));
        v1119_10.join_into((v1120_12).clone());
      }
      drop(v1119_10_cursor);
      compose(&(v1114_9),&(v1119_10))
    };
    drop(v1114_9);
    let v1114_12: Space = unite(&(v1114_7),&(v1114_11));
    v1113_14.join_into((v1114_12).clone());
  }
  drop(v1113_14_cursor);
  (v1113_14).clone()
}

fn routine_110(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1123_11 = Space::new();
  let mut v1123_11_cursor = (*s0).read_zipper();
  for v1123_11_byte in v1123_11_cursor.child_mask().iter() {
    v1123_11_cursor.descend_to_byte(v1123_11_byte);
    let v1123_11_tail = v1123_11_cursor.make_map();
    v1123_11_cursor.ascend(1);
    let v1123_11_head = Path::from_slice(&[v1123_11_byte]);
    let v1124_2: Space = singleton(&(v1123_11_head));
    let v1124_3: Space = intersect(&(*CONSTANT_7),&(v1124_2));
    let v1124_4: Space = if has_head(&(v1124_3)) { singleton(&[]) } else { Space::new() };
    drop(v1124_3);
    let v1124_5: Space = subtract(&(*CONSTANT_0),&(v1124_4));
    drop(v1124_4);
    let v1124_8: Space = if (v1124_5).is_empty() { Space::new() } else {
      let v1125_6: Path = concat_path(&(*p0),&(v1123_11_head));
      let v1125_7: Space = routine_110(c, &(v1125_6), &(*p1), &(*p2), &(*p3), &(v1123_11_tail));
      compose(&(v1124_5),&(v1125_7))
    };
    drop(v1124_5);
    let v1124_9: Space = intersect(&(*CONSTANT_7),&(v1124_2));
    drop(v1124_2);
    let v1124_10: Space = if has_head(&(v1124_9)) { singleton(&[]) } else { Space::new() };
    drop(v1124_9);
    let v1124_12: Space = if (v1124_10).is_empty() { Space::new() } else {
      let v1126_6: Path = concat_path(&(*p0),&(v1123_11_head));
      let mut v1126_11 = Space::new();
      let mut v1126_11_cursor = (v1123_11_tail).read_zipper();
      for v1126_11_byte in v1126_11_cursor.child_mask().iter() {
        v1126_11_cursor.descend_to_byte(v1126_11_byte);
        let v1126_11_tail = v1126_11_cursor.make_map();
        v1126_11_cursor.ascend(1);
        let v1126_11_head = Path::from_slice(&[v1126_11_byte]);
        let v1127_2: Space = singleton(&(v1126_11_head));
        let v1127_3: Space = intersect(&(*CONSTANT_7),&(v1127_2));
        let v1127_4: Space = if has_head(&(v1127_3)) { singleton(&[]) } else { Space::new() };
        drop(v1127_3);
        let v1127_5: Space = subtract(&(*CONSTANT_0),&(v1127_4));
        drop(v1127_4);
        let v1127_7: Space = if (v1127_5).is_empty() { Space::new() } else {
          let v1128_6: Space = routine_128(c, &(v1126_11_head), &(*p1), &(*p2), &(*p3), &(v1126_6), &(v1126_11_tail));
          compose(&(v1127_5),&(v1128_6))
        };
        drop(v1127_5);
        let v1127_8: Space = intersect(&(*CONSTANT_7),&(v1127_2));
        drop(v1127_2);
        let v1127_9: Space = if has_head(&(v1127_8)) { singleton(&[]) } else { Space::new() };
        drop(v1127_8);
        let v1127_11: Space = if (v1127_9).is_empty() { Space::new() } else {
          let v1129_10: Space = routine_129(c, &(v1126_11_head), &(*p1), &(*p2), &(*p3), &(v1126_6), &(v1126_11_tail));
          compose(&(v1127_9),&(v1129_10))
        };
        drop(v1127_9);
        let v1127_12: Space = unite(&(v1127_7),&(v1127_11));
        v1126_11.join_into((v1127_12).clone());
      }
      drop(v1126_11_cursor);
      drop(v1126_6);
      compose(&(v1124_10),&(v1126_11))
    };
    drop(v1124_10);
    let v1124_13: Space = unite(&(v1124_8),&(v1124_12));
    v1123_11.join_into((v1124_13).clone());
  }
  drop(v1123_11_cursor);
  (v1123_11).clone()
}

fn routine_111(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1130_14 = Space::new();
  let mut v1130_14_cursor = (*s0).read_zipper();
  for v1130_14_byte in v1130_14_cursor.child_mask().iter() {
    v1130_14_cursor.descend_to_byte(v1130_14_byte);
    let v1130_14_tail = v1130_14_cursor.make_map();
    v1130_14_cursor.ascend(1);
    let v1130_14_head = Path::from_slice(&[v1130_14_byte]);
    let v1131_2: Space = singleton(&(v1130_14_head));
    let v1131_3: Space = intersect(&(*CONSTANT_7),&(v1131_2));
    let v1131_4: Space = if has_head(&(v1131_3)) { singleton(&[]) } else { Space::new() };
    drop(v1131_3);
    let v1131_5: Space = subtract(&(*CONSTANT_0),&(v1131_4));
    drop(v1131_4);
    let v1131_7: Space = if (v1131_5).is_empty() { Space::new() } else {
      let mut v1132_6 = Space::new();
      let mut v1132_6_cursor = (v1130_14_tail).read_zipper();
      for v1132_6_byte in v1132_6_cursor.child_mask().iter() {
        v1132_6_cursor.descend_to_byte(v1132_6_byte);
        let v1132_6_tail = v1132_6_cursor.make_map();
        v1132_6_cursor.ascend(1);
        let v1132_6_head = Path::from_slice(&[v1132_6_byte]);
        let v1133_2: Space = singleton(&(v1132_6_head));
        let v1133_3: Space = intersect(&(*CONSTANT_7),&(v1133_2));
        let v1133_4: Space = if has_head(&(v1133_3)) { singleton(&[]) } else { Space::new() };
        drop(v1133_3);
        let v1133_5: Space = subtract(&(*CONSTANT_0),&(v1133_4));
        drop(v1133_4);
        let v1133_8: Space = if (v1133_5).is_empty() { Space::new() } else {
          let v1134_6: Path = concat_path(&(v1130_14_head),&(v1132_6_head));
          let v1134_7: Space = routine_128(c, &(v1134_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1132_6_tail));
          compose(&(v1133_5),&(v1134_7))
        };
        drop(v1133_5);
        let v1133_9: Space = intersect(&(*CONSTANT_7),&(v1133_2));
        drop(v1133_2);
        let v1133_10: Space = if has_head(&(v1133_9)) { singleton(&[]) } else { Space::new() };
        drop(v1133_9);
        let v1133_12: Space = if (v1133_10).is_empty() { Space::new() } else {
          let v1135_6: Path = concat_path(&(v1130_14_head),&(v1132_6_head));
          let v1135_11: Space = routine_129(c, &(v1135_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1132_6_tail));
          drop(v1135_6);
          compose(&(v1133_10),&(v1135_11))
        };
        drop(v1133_10);
        let v1133_13: Space = unite(&(v1133_8),&(v1133_12));
        v1132_6.join_into((v1133_13).clone());
      }
      drop(v1132_6_cursor);
      compose(&(v1131_5),&(v1132_6))
    };
    drop(v1131_5);
    let v1131_8: Space = intersect(&(*CONSTANT_7),&(v1131_2));
    drop(v1131_2);
    let v1131_9: Space = if has_head(&(v1131_8)) { singleton(&[]) } else { Space::new() };
    drop(v1131_8);
    let v1131_11: Space = if (v1131_9).is_empty() { Space::new() } else {
      let mut v1136_10 = Space::new();
      let mut v1136_10_cursor = (v1130_14_tail).read_zipper();
      for v1136_10_byte in v1136_10_cursor.child_mask().iter() {
        v1136_10_cursor.descend_to_byte(v1136_10_byte);
        let v1136_10_tail = v1136_10_cursor.make_map();
        v1136_10_cursor.ascend(1);
        let v1136_10_head = Path::from_slice(&[v1136_10_byte]);
        let v1137_2: Space = singleton(&(v1136_10_head));
        let v1137_3: Space = intersect(&(*CONSTANT_7),&(v1137_2));
        let v1137_4: Space = if has_head(&(v1137_3)) { singleton(&[]) } else { Space::new() };
        drop(v1137_3);
        let v1137_5: Space = subtract(&(*CONSTANT_0),&(v1137_4));
        drop(v1137_4);
        let v1137_7: Space = if (v1137_5).is_empty() { Space::new() } else {
          let v1138_6: Space = routine_150(c, &(v1136_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1130_14_head), &(v1136_10_tail));
          compose(&(v1137_5),&(v1138_6))
        };
        drop(v1137_5);
        let v1137_8: Space = intersect(&(*CONSTANT_7),&(v1137_2));
        drop(v1137_2);
        let v1137_9: Space = if has_head(&(v1137_8)) { singleton(&[]) } else { Space::new() };
        drop(v1137_8);
        let v1137_11: Space = if (v1137_9).is_empty() { Space::new() } else {
          let v1139_10: Space = routine_151(c, &(v1136_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1130_14_head), &(v1136_10_tail));
          compose(&(v1137_9),&(v1139_10))
        };
        drop(v1137_9);
        let v1137_12: Space = unite(&(v1137_7),&(v1137_11));
        v1136_10.join_into((v1137_12).clone());
      }
      drop(v1136_10_cursor);
      compose(&(v1131_9),&(v1136_10))
    };
    drop(v1131_9);
    let v1131_12: Space = unite(&(v1131_7),&(v1131_11));
    v1130_14.join_into((v1131_12).clone());
  }
  drop(v1130_14_cursor);
  (v1130_14).clone()
}

fn routine_112(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1140_11 = Space::new();
  let mut v1140_11_cursor = (*s0).read_zipper();
  for v1140_11_byte in v1140_11_cursor.child_mask().iter() {
    v1140_11_cursor.descend_to_byte(v1140_11_byte);
    let v1140_11_tail = v1140_11_cursor.make_map();
    v1140_11_cursor.ascend(1);
    let v1140_11_head = Path::from_slice(&[v1140_11_byte]);
    let v1141_2: Space = singleton(&(v1140_11_head));
    let v1141_3: Space = intersect(&(*CONSTANT_7),&(v1141_2));
    let v1141_4: Space = if has_head(&(v1141_3)) { singleton(&[]) } else { Space::new() };
    drop(v1141_3);
    let v1141_5: Space = subtract(&(*CONSTANT_0),&(v1141_4));
    drop(v1141_4);
    let v1141_8: Space = if (v1141_5).is_empty() { Space::new() } else {
      let v1142_6: Path = concat_path(&(*p0),&(v1140_11_head));
      let v1142_7: Space = routine_112(c, &(v1142_6), &(*p1), &(*p2), &(*p3), &(v1140_11_tail));
      compose(&(v1141_5),&(v1142_7))
    };
    drop(v1141_5);
    let v1141_9: Space = intersect(&(*CONSTANT_7),&(v1141_2));
    drop(v1141_2);
    let v1141_10: Space = if has_head(&(v1141_9)) { singleton(&[]) } else { Space::new() };
    drop(v1141_9);
    let v1141_12: Space = if (v1141_10).is_empty() { Space::new() } else {
      let v1143_6: Path = concat_path(&(*p0),&(v1140_11_head));
      let mut v1143_11 = Space::new();
      let mut v1143_11_cursor = (v1140_11_tail).read_zipper();
      for v1143_11_byte in v1143_11_cursor.child_mask().iter() {
        v1143_11_cursor.descend_to_byte(v1143_11_byte);
        let v1143_11_tail = v1143_11_cursor.make_map();
        v1143_11_cursor.ascend(1);
        let v1143_11_head = Path::from_slice(&[v1143_11_byte]);
        let v1144_2: Space = singleton(&(v1143_11_head));
        let v1144_3: Space = intersect(&(*CONSTANT_7),&(v1144_2));
        let v1144_4: Space = if has_head(&(v1144_3)) { singleton(&[]) } else { Space::new() };
        drop(v1144_3);
        let v1144_5: Space = subtract(&(*CONSTANT_0),&(v1144_4));
        drop(v1144_4);
        let v1144_7: Space = if (v1144_5).is_empty() { Space::new() } else {
          let v1145_6: Space = routine_130(c, &(v1143_11_head), &(*p1), &(*p2), &(*p3), &(v1143_6), &(v1143_11_tail));
          compose(&(v1144_5),&(v1145_6))
        };
        drop(v1144_5);
        let v1144_8: Space = intersect(&(*CONSTANT_7),&(v1144_2));
        drop(v1144_2);
        let v1144_9: Space = if has_head(&(v1144_8)) { singleton(&[]) } else { Space::new() };
        drop(v1144_8);
        let v1144_11: Space = if (v1144_9).is_empty() { Space::new() } else {
          let v1146_10: Space = routine_131(c, &(v1143_11_head), &(*p1), &(*p2), &(*p3), &(v1143_6), &(v1143_11_tail));
          compose(&(v1144_9),&(v1146_10))
        };
        drop(v1144_9);
        let v1144_12: Space = unite(&(v1144_7),&(v1144_11));
        v1143_11.join_into((v1144_12).clone());
      }
      drop(v1143_11_cursor);
      drop(v1143_6);
      compose(&(v1141_10),&(v1143_11))
    };
    drop(v1141_10);
    let v1141_13: Space = unite(&(v1141_8),&(v1141_12));
    v1140_11.join_into((v1141_13).clone());
  }
  drop(v1140_11_cursor);
  (v1140_11).clone()
}

fn routine_113(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1147_14 = Space::new();
  let mut v1147_14_cursor = (*s0).read_zipper();
  for v1147_14_byte in v1147_14_cursor.child_mask().iter() {
    v1147_14_cursor.descend_to_byte(v1147_14_byte);
    let v1147_14_tail = v1147_14_cursor.make_map();
    v1147_14_cursor.ascend(1);
    let v1147_14_head = Path::from_slice(&[v1147_14_byte]);
    let v1148_2: Space = singleton(&(v1147_14_head));
    let v1148_3: Space = intersect(&(*CONSTANT_7),&(v1148_2));
    let v1148_4: Space = if has_head(&(v1148_3)) { singleton(&[]) } else { Space::new() };
    drop(v1148_3);
    let v1148_5: Space = subtract(&(*CONSTANT_0),&(v1148_4));
    drop(v1148_4);
    let v1148_7: Space = if (v1148_5).is_empty() { Space::new() } else {
      let mut v1149_6 = Space::new();
      let mut v1149_6_cursor = (v1147_14_tail).read_zipper();
      for v1149_6_byte in v1149_6_cursor.child_mask().iter() {
        v1149_6_cursor.descend_to_byte(v1149_6_byte);
        let v1149_6_tail = v1149_6_cursor.make_map();
        v1149_6_cursor.ascend(1);
        let v1149_6_head = Path::from_slice(&[v1149_6_byte]);
        let v1150_2: Space = singleton(&(v1149_6_head));
        let v1150_3: Space = intersect(&(*CONSTANT_7),&(v1150_2));
        let v1150_4: Space = if has_head(&(v1150_3)) { singleton(&[]) } else { Space::new() };
        drop(v1150_3);
        let v1150_5: Space = subtract(&(*CONSTANT_0),&(v1150_4));
        drop(v1150_4);
        let v1150_8: Space = if (v1150_5).is_empty() { Space::new() } else {
          let v1151_6: Path = concat_path(&(v1147_14_head),&(v1149_6_head));
          let v1151_7: Space = routine_130(c, &(v1151_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1149_6_tail));
          compose(&(v1150_5),&(v1151_7))
        };
        drop(v1150_5);
        let v1150_9: Space = intersect(&(*CONSTANT_7),&(v1150_2));
        drop(v1150_2);
        let v1150_10: Space = if has_head(&(v1150_9)) { singleton(&[]) } else { Space::new() };
        drop(v1150_9);
        let v1150_12: Space = if (v1150_10).is_empty() { Space::new() } else {
          let v1152_6: Path = concat_path(&(v1147_14_head),&(v1149_6_head));
          let v1152_11: Space = routine_131(c, &(v1152_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1149_6_tail));
          drop(v1152_6);
          compose(&(v1150_10),&(v1152_11))
        };
        drop(v1150_10);
        let v1150_13: Space = unite(&(v1150_8),&(v1150_12));
        v1149_6.join_into((v1150_13).clone());
      }
      drop(v1149_6_cursor);
      compose(&(v1148_5),&(v1149_6))
    };
    drop(v1148_5);
    let v1148_8: Space = intersect(&(*CONSTANT_7),&(v1148_2));
    drop(v1148_2);
    let v1148_9: Space = if has_head(&(v1148_8)) { singleton(&[]) } else { Space::new() };
    drop(v1148_8);
    let v1148_11: Space = if (v1148_9).is_empty() { Space::new() } else {
      let mut v1153_10 = Space::new();
      let mut v1153_10_cursor = (v1147_14_tail).read_zipper();
      for v1153_10_byte in v1153_10_cursor.child_mask().iter() {
        v1153_10_cursor.descend_to_byte(v1153_10_byte);
        let v1153_10_tail = v1153_10_cursor.make_map();
        v1153_10_cursor.ascend(1);
        let v1153_10_head = Path::from_slice(&[v1153_10_byte]);
        let v1154_2: Space = singleton(&(v1153_10_head));
        let v1154_3: Space = intersect(&(*CONSTANT_7),&(v1154_2));
        let v1154_4: Space = if has_head(&(v1154_3)) { singleton(&[]) } else { Space::new() };
        drop(v1154_3);
        let v1154_5: Space = subtract(&(*CONSTANT_0),&(v1154_4));
        drop(v1154_4);
        let v1154_7: Space = if (v1154_5).is_empty() { Space::new() } else {
          let v1155_6: Space = routine_152(c, &(v1153_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1147_14_head), &(v1153_10_tail));
          compose(&(v1154_5),&(v1155_6))
        };
        drop(v1154_5);
        let v1154_8: Space = intersect(&(*CONSTANT_7),&(v1154_2));
        drop(v1154_2);
        let v1154_9: Space = if has_head(&(v1154_8)) { singleton(&[]) } else { Space::new() };
        drop(v1154_8);
        let v1154_11: Space = if (v1154_9).is_empty() { Space::new() } else {
          let v1156_10: Space = routine_153(c, &(v1153_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1147_14_head), &(v1153_10_tail));
          compose(&(v1154_9),&(v1156_10))
        };
        drop(v1154_9);
        let v1154_12: Space = unite(&(v1154_7),&(v1154_11));
        v1153_10.join_into((v1154_12).clone());
      }
      drop(v1153_10_cursor);
      compose(&(v1148_9),&(v1153_10))
    };
    drop(v1148_9);
    let v1148_12: Space = unite(&(v1148_7),&(v1148_11));
    v1147_14.join_into((v1148_12).clone());
  }
  drop(v1147_14_cursor);
  (v1147_14).clone()
}

fn routine_114(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1157_11 = Space::new();
  let mut v1157_11_cursor = (*s0).read_zipper();
  for v1157_11_byte in v1157_11_cursor.child_mask().iter() {
    v1157_11_cursor.descend_to_byte(v1157_11_byte);
    let v1157_11_tail = v1157_11_cursor.make_map();
    v1157_11_cursor.ascend(1);
    let v1157_11_head = Path::from_slice(&[v1157_11_byte]);
    let v1158_2: Space = singleton(&(v1157_11_head));
    let v1158_3: Space = intersect(&(*CONSTANT_7),&(v1158_2));
    let v1158_4: Space = if has_head(&(v1158_3)) { singleton(&[]) } else { Space::new() };
    drop(v1158_3);
    let v1158_5: Space = subtract(&(*CONSTANT_0),&(v1158_4));
    drop(v1158_4);
    let v1158_8: Space = if (v1158_5).is_empty() { Space::new() } else {
      let v1159_6: Path = concat_path(&(*p0),&(v1157_11_head));
      let v1159_7: Space = routine_114(c, &(v1159_6), &(*p1), &(*p2), &(*p3), &(v1157_11_tail));
      compose(&(v1158_5),&(v1159_7))
    };
    drop(v1158_5);
    let v1158_9: Space = intersect(&(*CONSTANT_7),&(v1158_2));
    drop(v1158_2);
    let v1158_10: Space = if has_head(&(v1158_9)) { singleton(&[]) } else { Space::new() };
    drop(v1158_9);
    let v1158_12: Space = if (v1158_10).is_empty() { Space::new() } else {
      let v1160_6: Path = concat_path(&(*p0),&(v1157_11_head));
      let mut v1160_11 = Space::new();
      let mut v1160_11_cursor = (v1157_11_tail).read_zipper();
      for v1160_11_byte in v1160_11_cursor.child_mask().iter() {
        v1160_11_cursor.descend_to_byte(v1160_11_byte);
        let v1160_11_tail = v1160_11_cursor.make_map();
        v1160_11_cursor.ascend(1);
        let v1160_11_head = Path::from_slice(&[v1160_11_byte]);
        let v1161_2: Space = singleton(&(v1160_11_head));
        let v1161_3: Space = intersect(&(*CONSTANT_7),&(v1161_2));
        let v1161_4: Space = if has_head(&(v1161_3)) { singleton(&[]) } else { Space::new() };
        drop(v1161_3);
        let v1161_5: Space = subtract(&(*CONSTANT_0),&(v1161_4));
        drop(v1161_4);
        let v1161_7: Space = if (v1161_5).is_empty() { Space::new() } else {
          let v1162_6: Space = routine_132(c, &(v1160_11_head), &(*p1), &(*p2), &(*p3), &(v1160_6), &(v1160_11_tail));
          compose(&(v1161_5),&(v1162_6))
        };
        drop(v1161_5);
        let v1161_8: Space = intersect(&(*CONSTANT_7),&(v1161_2));
        drop(v1161_2);
        let v1161_9: Space = if has_head(&(v1161_8)) { singleton(&[]) } else { Space::new() };
        drop(v1161_8);
        let v1161_11: Space = if (v1161_9).is_empty() { Space::new() } else {
          let v1163_10: Space = routine_133(c, &(v1160_11_head), &(*p1), &(*p2), &(*p3), &(v1160_6), &(v1160_11_tail));
          compose(&(v1161_9),&(v1163_10))
        };
        drop(v1161_9);
        let v1161_12: Space = unite(&(v1161_7),&(v1161_11));
        v1160_11.join_into((v1161_12).clone());
      }
      drop(v1160_11_cursor);
      drop(v1160_6);
      compose(&(v1158_10),&(v1160_11))
    };
    drop(v1158_10);
    let v1158_13: Space = unite(&(v1158_8),&(v1158_12));
    v1157_11.join_into((v1158_13).clone());
  }
  drop(v1157_11_cursor);
  (v1157_11).clone()
}

fn routine_115(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1164_14 = Space::new();
  let mut v1164_14_cursor = (*s0).read_zipper();
  for v1164_14_byte in v1164_14_cursor.child_mask().iter() {
    v1164_14_cursor.descend_to_byte(v1164_14_byte);
    let v1164_14_tail = v1164_14_cursor.make_map();
    v1164_14_cursor.ascend(1);
    let v1164_14_head = Path::from_slice(&[v1164_14_byte]);
    let v1165_2: Space = singleton(&(v1164_14_head));
    let v1165_3: Space = intersect(&(*CONSTANT_7),&(v1165_2));
    let v1165_4: Space = if has_head(&(v1165_3)) { singleton(&[]) } else { Space::new() };
    drop(v1165_3);
    let v1165_5: Space = subtract(&(*CONSTANT_0),&(v1165_4));
    drop(v1165_4);
    let v1165_7: Space = if (v1165_5).is_empty() { Space::new() } else {
      let mut v1166_6 = Space::new();
      let mut v1166_6_cursor = (v1164_14_tail).read_zipper();
      for v1166_6_byte in v1166_6_cursor.child_mask().iter() {
        v1166_6_cursor.descend_to_byte(v1166_6_byte);
        let v1166_6_tail = v1166_6_cursor.make_map();
        v1166_6_cursor.ascend(1);
        let v1166_6_head = Path::from_slice(&[v1166_6_byte]);
        let v1167_2: Space = singleton(&(v1166_6_head));
        let v1167_3: Space = intersect(&(*CONSTANT_7),&(v1167_2));
        let v1167_4: Space = if has_head(&(v1167_3)) { singleton(&[]) } else { Space::new() };
        drop(v1167_3);
        let v1167_5: Space = subtract(&(*CONSTANT_0),&(v1167_4));
        drop(v1167_4);
        let v1167_8: Space = if (v1167_5).is_empty() { Space::new() } else {
          let v1168_6: Path = concat_path(&(v1164_14_head),&(v1166_6_head));
          let v1168_7: Space = routine_132(c, &(v1168_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1166_6_tail));
          compose(&(v1167_5),&(v1168_7))
        };
        drop(v1167_5);
        let v1167_9: Space = intersect(&(*CONSTANT_7),&(v1167_2));
        drop(v1167_2);
        let v1167_10: Space = if has_head(&(v1167_9)) { singleton(&[]) } else { Space::new() };
        drop(v1167_9);
        let v1167_12: Space = if (v1167_10).is_empty() { Space::new() } else {
          let v1169_6: Path = concat_path(&(v1164_14_head),&(v1166_6_head));
          let v1169_11: Space = routine_133(c, &(v1169_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1166_6_tail));
          drop(v1169_6);
          compose(&(v1167_10),&(v1169_11))
        };
        drop(v1167_10);
        let v1167_13: Space = unite(&(v1167_8),&(v1167_12));
        v1166_6.join_into((v1167_13).clone());
      }
      drop(v1166_6_cursor);
      compose(&(v1165_5),&(v1166_6))
    };
    drop(v1165_5);
    let v1165_8: Space = intersect(&(*CONSTANT_7),&(v1165_2));
    drop(v1165_2);
    let v1165_9: Space = if has_head(&(v1165_8)) { singleton(&[]) } else { Space::new() };
    drop(v1165_8);
    let v1165_11: Space = if (v1165_9).is_empty() { Space::new() } else {
      let mut v1170_10 = Space::new();
      let mut v1170_10_cursor = (v1164_14_tail).read_zipper();
      for v1170_10_byte in v1170_10_cursor.child_mask().iter() {
        v1170_10_cursor.descend_to_byte(v1170_10_byte);
        let v1170_10_tail = v1170_10_cursor.make_map();
        v1170_10_cursor.ascend(1);
        let v1170_10_head = Path::from_slice(&[v1170_10_byte]);
        let v1171_2: Space = singleton(&(v1170_10_head));
        let v1171_3: Space = intersect(&(*CONSTANT_7),&(v1171_2));
        let v1171_4: Space = if has_head(&(v1171_3)) { singleton(&[]) } else { Space::new() };
        drop(v1171_3);
        let v1171_5: Space = subtract(&(*CONSTANT_0),&(v1171_4));
        drop(v1171_4);
        let v1171_7: Space = if (v1171_5).is_empty() { Space::new() } else {
          let v1172_6: Space = routine_154(c, &(v1170_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1164_14_head), &(v1170_10_tail));
          compose(&(v1171_5),&(v1172_6))
        };
        drop(v1171_5);
        let v1171_8: Space = intersect(&(*CONSTANT_7),&(v1171_2));
        drop(v1171_2);
        let v1171_9: Space = if has_head(&(v1171_8)) { singleton(&[]) } else { Space::new() };
        drop(v1171_8);
        let v1171_11: Space = if (v1171_9).is_empty() { Space::new() } else {
          let v1173_10: Space = routine_155(c, &(v1170_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1164_14_head), &(v1170_10_tail));
          compose(&(v1171_9),&(v1173_10))
        };
        drop(v1171_9);
        let v1171_12: Space = unite(&(v1171_7),&(v1171_11));
        v1170_10.join_into((v1171_12).clone());
      }
      drop(v1170_10_cursor);
      compose(&(v1165_9),&(v1170_10))
    };
    drop(v1165_9);
    let v1165_12: Space = unite(&(v1165_7),&(v1165_11));
    v1164_14.join_into((v1165_12).clone());
  }
  drop(v1164_14_cursor);
  (v1164_14).clone()
}

fn routine_116(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1174_11 = Space::new();
  let mut v1174_11_cursor = (*s0).read_zipper();
  for v1174_11_byte in v1174_11_cursor.child_mask().iter() {
    v1174_11_cursor.descend_to_byte(v1174_11_byte);
    let v1174_11_tail = v1174_11_cursor.make_map();
    v1174_11_cursor.ascend(1);
    let v1174_11_head = Path::from_slice(&[v1174_11_byte]);
    let v1175_2: Space = singleton(&(v1174_11_head));
    let v1175_3: Space = intersect(&(*CONSTANT_7),&(v1175_2));
    let v1175_4: Space = if has_head(&(v1175_3)) { singleton(&[]) } else { Space::new() };
    drop(v1175_3);
    let v1175_5: Space = subtract(&(*CONSTANT_0),&(v1175_4));
    drop(v1175_4);
    let v1175_8: Space = if (v1175_5).is_empty() { Space::new() } else {
      let v1176_6: Path = concat_path(&(*p0),&(v1174_11_head));
      let v1176_7: Space = routine_116(c, &(v1176_6), &(*p1), &(*p2), &(*p3), &(v1174_11_tail));
      compose(&(v1175_5),&(v1176_7))
    };
    drop(v1175_5);
    let v1175_9: Space = intersect(&(*CONSTANT_7),&(v1175_2));
    drop(v1175_2);
    let v1175_10: Space = if has_head(&(v1175_9)) { singleton(&[]) } else { Space::new() };
    drop(v1175_9);
    let v1175_12: Space = if (v1175_10).is_empty() { Space::new() } else {
      let v1177_6: Path = concat_path(&(*p0),&(v1174_11_head));
      let mut v1177_11 = Space::new();
      let mut v1177_11_cursor = (v1174_11_tail).read_zipper();
      for v1177_11_byte in v1177_11_cursor.child_mask().iter() {
        v1177_11_cursor.descend_to_byte(v1177_11_byte);
        let v1177_11_tail = v1177_11_cursor.make_map();
        v1177_11_cursor.ascend(1);
        let v1177_11_head = Path::from_slice(&[v1177_11_byte]);
        let v1178_2: Space = singleton(&(v1177_11_head));
        let v1178_3: Space = intersect(&(*CONSTANT_7),&(v1178_2));
        let v1178_4: Space = if has_head(&(v1178_3)) { singleton(&[]) } else { Space::new() };
        drop(v1178_3);
        let v1178_5: Space = subtract(&(*CONSTANT_0),&(v1178_4));
        drop(v1178_4);
        let v1178_7: Space = if (v1178_5).is_empty() { Space::new() } else {
          let v1179_6: Space = routine_134(c, &(v1177_11_head), &(*p1), &(*p2), &(*p3), &(v1177_6), &(v1177_11_tail));
          compose(&(v1178_5),&(v1179_6))
        };
        drop(v1178_5);
        let v1178_8: Space = intersect(&(*CONSTANT_7),&(v1178_2));
        drop(v1178_2);
        let v1178_9: Space = if has_head(&(v1178_8)) { singleton(&[]) } else { Space::new() };
        drop(v1178_8);
        let v1178_11: Space = if (v1178_9).is_empty() { Space::new() } else {
          let v1180_10: Space = routine_135(c, &(v1177_11_head), &(*p1), &(*p2), &(*p3), &(v1177_6), &(v1177_11_tail));
          compose(&(v1178_9),&(v1180_10))
        };
        drop(v1178_9);
        let v1178_12: Space = unite(&(v1178_7),&(v1178_11));
        v1177_11.join_into((v1178_12).clone());
      }
      drop(v1177_11_cursor);
      drop(v1177_6);
      compose(&(v1175_10),&(v1177_11))
    };
    drop(v1175_10);
    let v1175_13: Space = unite(&(v1175_8),&(v1175_12));
    v1174_11.join_into((v1175_13).clone());
  }
  drop(v1174_11_cursor);
  (v1174_11).clone()
}

fn routine_117(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1181_14 = Space::new();
  let mut v1181_14_cursor = (*s0).read_zipper();
  for v1181_14_byte in v1181_14_cursor.child_mask().iter() {
    v1181_14_cursor.descend_to_byte(v1181_14_byte);
    let v1181_14_tail = v1181_14_cursor.make_map();
    v1181_14_cursor.ascend(1);
    let v1181_14_head = Path::from_slice(&[v1181_14_byte]);
    let v1182_2: Space = singleton(&(v1181_14_head));
    let v1182_3: Space = intersect(&(*CONSTANT_7),&(v1182_2));
    let v1182_4: Space = if has_head(&(v1182_3)) { singleton(&[]) } else { Space::new() };
    drop(v1182_3);
    let v1182_5: Space = subtract(&(*CONSTANT_0),&(v1182_4));
    drop(v1182_4);
    let v1182_7: Space = if (v1182_5).is_empty() { Space::new() } else {
      let mut v1183_6 = Space::new();
      let mut v1183_6_cursor = (v1181_14_tail).read_zipper();
      for v1183_6_byte in v1183_6_cursor.child_mask().iter() {
        v1183_6_cursor.descend_to_byte(v1183_6_byte);
        let v1183_6_tail = v1183_6_cursor.make_map();
        v1183_6_cursor.ascend(1);
        let v1183_6_head = Path::from_slice(&[v1183_6_byte]);
        let v1184_2: Space = singleton(&(v1183_6_head));
        let v1184_3: Space = intersect(&(*CONSTANT_7),&(v1184_2));
        let v1184_4: Space = if has_head(&(v1184_3)) { singleton(&[]) } else { Space::new() };
        drop(v1184_3);
        let v1184_5: Space = subtract(&(*CONSTANT_0),&(v1184_4));
        drop(v1184_4);
        let v1184_8: Space = if (v1184_5).is_empty() { Space::new() } else {
          let v1185_6: Path = concat_path(&(v1181_14_head),&(v1183_6_head));
          let v1185_7: Space = routine_134(c, &(v1185_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1183_6_tail));
          compose(&(v1184_5),&(v1185_7))
        };
        drop(v1184_5);
        let v1184_9: Space = intersect(&(*CONSTANT_7),&(v1184_2));
        drop(v1184_2);
        let v1184_10: Space = if has_head(&(v1184_9)) { singleton(&[]) } else { Space::new() };
        drop(v1184_9);
        let v1184_12: Space = if (v1184_10).is_empty() { Space::new() } else {
          let v1186_6: Path = concat_path(&(v1181_14_head),&(v1183_6_head));
          let v1186_11: Space = routine_135(c, &(v1186_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1183_6_tail));
          drop(v1186_6);
          compose(&(v1184_10),&(v1186_11))
        };
        drop(v1184_10);
        let v1184_13: Space = unite(&(v1184_8),&(v1184_12));
        v1183_6.join_into((v1184_13).clone());
      }
      drop(v1183_6_cursor);
      compose(&(v1182_5),&(v1183_6))
    };
    drop(v1182_5);
    let v1182_8: Space = intersect(&(*CONSTANT_7),&(v1182_2));
    drop(v1182_2);
    let v1182_9: Space = if has_head(&(v1182_8)) { singleton(&[]) } else { Space::new() };
    drop(v1182_8);
    let v1182_11: Space = if (v1182_9).is_empty() { Space::new() } else {
      let mut v1187_10 = Space::new();
      let mut v1187_10_cursor = (v1181_14_tail).read_zipper();
      for v1187_10_byte in v1187_10_cursor.child_mask().iter() {
        v1187_10_cursor.descend_to_byte(v1187_10_byte);
        let v1187_10_tail = v1187_10_cursor.make_map();
        v1187_10_cursor.ascend(1);
        let v1187_10_head = Path::from_slice(&[v1187_10_byte]);
        let v1188_2: Space = singleton(&(v1187_10_head));
        let v1188_3: Space = intersect(&(*CONSTANT_7),&(v1188_2));
        let v1188_4: Space = if has_head(&(v1188_3)) { singleton(&[]) } else { Space::new() };
        drop(v1188_3);
        let v1188_5: Space = subtract(&(*CONSTANT_0),&(v1188_4));
        drop(v1188_4);
        let v1188_7: Space = if (v1188_5).is_empty() { Space::new() } else {
          let v1189_6: Space = routine_156(c, &(v1187_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1181_14_head), &(v1187_10_tail));
          compose(&(v1188_5),&(v1189_6))
        };
        drop(v1188_5);
        let v1188_8: Space = intersect(&(*CONSTANT_7),&(v1188_2));
        drop(v1188_2);
        let v1188_9: Space = if has_head(&(v1188_8)) { singleton(&[]) } else { Space::new() };
        drop(v1188_8);
        let v1188_11: Space = if (v1188_9).is_empty() { Space::new() } else {
          let v1190_10: Space = routine_157(c, &(v1187_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1181_14_head), &(v1187_10_tail));
          compose(&(v1188_9),&(v1190_10))
        };
        drop(v1188_9);
        let v1188_12: Space = unite(&(v1188_7),&(v1188_11));
        v1187_10.join_into((v1188_12).clone());
      }
      drop(v1187_10_cursor);
      compose(&(v1182_9),&(v1187_10))
    };
    drop(v1182_9);
    let v1182_12: Space = unite(&(v1182_7),&(v1182_11));
    v1181_14.join_into((v1182_12).clone());
  }
  drop(v1181_14_cursor);
  (v1181_14).clone()
}

fn routine_118(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1191_11 = Space::new();
  let mut v1191_11_cursor = (*s0).read_zipper();
  for v1191_11_byte in v1191_11_cursor.child_mask().iter() {
    v1191_11_cursor.descend_to_byte(v1191_11_byte);
    let v1191_11_tail = v1191_11_cursor.make_map();
    v1191_11_cursor.ascend(1);
    let v1191_11_head = Path::from_slice(&[v1191_11_byte]);
    let v1192_2: Space = singleton(&(v1191_11_head));
    let v1192_3: Space = intersect(&(*CONSTANT_7),&(v1192_2));
    let v1192_4: Space = if has_head(&(v1192_3)) { singleton(&[]) } else { Space::new() };
    drop(v1192_3);
    let v1192_5: Space = subtract(&(*CONSTANT_0),&(v1192_4));
    drop(v1192_4);
    let v1192_8: Space = if (v1192_5).is_empty() { Space::new() } else {
      let v1193_6: Path = concat_path(&(*p0),&(v1191_11_head));
      let v1193_7: Space = routine_118(c, &(v1193_6), &(*p1), &(*p2), &(*p3), &(v1191_11_tail));
      compose(&(v1192_5),&(v1193_7))
    };
    drop(v1192_5);
    let v1192_9: Space = intersect(&(*CONSTANT_7),&(v1192_2));
    drop(v1192_2);
    let v1192_10: Space = if has_head(&(v1192_9)) { singleton(&[]) } else { Space::new() };
    drop(v1192_9);
    let v1192_12: Space = if (v1192_10).is_empty() { Space::new() } else {
      let v1194_6: Path = concat_path(&(*p0),&(v1191_11_head));
      let mut v1194_11 = Space::new();
      let mut v1194_11_cursor = (v1191_11_tail).read_zipper();
      for v1194_11_byte in v1194_11_cursor.child_mask().iter() {
        v1194_11_cursor.descend_to_byte(v1194_11_byte);
        let v1194_11_tail = v1194_11_cursor.make_map();
        v1194_11_cursor.ascend(1);
        let v1194_11_head = Path::from_slice(&[v1194_11_byte]);
        let v1195_2: Space = singleton(&(v1194_11_head));
        let v1195_3: Space = intersect(&(*CONSTANT_7),&(v1195_2));
        let v1195_4: Space = if has_head(&(v1195_3)) { singleton(&[]) } else { Space::new() };
        drop(v1195_3);
        let v1195_5: Space = subtract(&(*CONSTANT_0),&(v1195_4));
        drop(v1195_4);
        let v1195_7: Space = if (v1195_5).is_empty() { Space::new() } else {
          let v1196_6: Space = routine_136(c, &(v1194_11_head), &(*p1), &(*p2), &(*p3), &(v1194_6), &(v1194_11_tail));
          compose(&(v1195_5),&(v1196_6))
        };
        drop(v1195_5);
        let v1195_8: Space = intersect(&(*CONSTANT_7),&(v1195_2));
        drop(v1195_2);
        let v1195_9: Space = if has_head(&(v1195_8)) { singleton(&[]) } else { Space::new() };
        drop(v1195_8);
        let v1195_11: Space = if (v1195_9).is_empty() { Space::new() } else {
          let v1197_10: Space = routine_137(c, &(v1194_11_head), &(*p1), &(*p2), &(*p3), &(v1194_6), &(v1194_11_tail));
          compose(&(v1195_9),&(v1197_10))
        };
        drop(v1195_9);
        let v1195_12: Space = unite(&(v1195_7),&(v1195_11));
        v1194_11.join_into((v1195_12).clone());
      }
      drop(v1194_11_cursor);
      drop(v1194_6);
      compose(&(v1192_10),&(v1194_11))
    };
    drop(v1192_10);
    let v1192_13: Space = unite(&(v1192_8),&(v1192_12));
    v1191_11.join_into((v1192_13).clone());
  }
  drop(v1191_11_cursor);
  (v1191_11).clone()
}

fn routine_119(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1198_14 = Space::new();
  let mut v1198_14_cursor = (*s0).read_zipper();
  for v1198_14_byte in v1198_14_cursor.child_mask().iter() {
    v1198_14_cursor.descend_to_byte(v1198_14_byte);
    let v1198_14_tail = v1198_14_cursor.make_map();
    v1198_14_cursor.ascend(1);
    let v1198_14_head = Path::from_slice(&[v1198_14_byte]);
    let v1199_2: Space = singleton(&(v1198_14_head));
    let v1199_3: Space = intersect(&(*CONSTANT_7),&(v1199_2));
    let v1199_4: Space = if has_head(&(v1199_3)) { singleton(&[]) } else { Space::new() };
    drop(v1199_3);
    let v1199_5: Space = subtract(&(*CONSTANT_0),&(v1199_4));
    drop(v1199_4);
    let v1199_7: Space = if (v1199_5).is_empty() { Space::new() } else {
      let mut v1200_6 = Space::new();
      let mut v1200_6_cursor = (v1198_14_tail).read_zipper();
      for v1200_6_byte in v1200_6_cursor.child_mask().iter() {
        v1200_6_cursor.descend_to_byte(v1200_6_byte);
        let v1200_6_tail = v1200_6_cursor.make_map();
        v1200_6_cursor.ascend(1);
        let v1200_6_head = Path::from_slice(&[v1200_6_byte]);
        let v1201_2: Space = singleton(&(v1200_6_head));
        let v1201_3: Space = intersect(&(*CONSTANT_7),&(v1201_2));
        let v1201_4: Space = if has_head(&(v1201_3)) { singleton(&[]) } else { Space::new() };
        drop(v1201_3);
        let v1201_5: Space = subtract(&(*CONSTANT_0),&(v1201_4));
        drop(v1201_4);
        let v1201_8: Space = if (v1201_5).is_empty() { Space::new() } else {
          let v1202_6: Path = concat_path(&(v1198_14_head),&(v1200_6_head));
          let v1202_7: Space = routine_136(c, &(v1202_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1200_6_tail));
          compose(&(v1201_5),&(v1202_7))
        };
        drop(v1201_5);
        let v1201_9: Space = intersect(&(*CONSTANT_7),&(v1201_2));
        drop(v1201_2);
        let v1201_10: Space = if has_head(&(v1201_9)) { singleton(&[]) } else { Space::new() };
        drop(v1201_9);
        let v1201_12: Space = if (v1201_10).is_empty() { Space::new() } else {
          let v1203_6: Path = concat_path(&(v1198_14_head),&(v1200_6_head));
          let v1203_11: Space = routine_137(c, &(v1203_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1200_6_tail));
          drop(v1203_6);
          compose(&(v1201_10),&(v1203_11))
        };
        drop(v1201_10);
        let v1201_13: Space = unite(&(v1201_8),&(v1201_12));
        v1200_6.join_into((v1201_13).clone());
      }
      drop(v1200_6_cursor);
      compose(&(v1199_5),&(v1200_6))
    };
    drop(v1199_5);
    let v1199_8: Space = intersect(&(*CONSTANT_7),&(v1199_2));
    drop(v1199_2);
    let v1199_9: Space = if has_head(&(v1199_8)) { singleton(&[]) } else { Space::new() };
    drop(v1199_8);
    let v1199_11: Space = if (v1199_9).is_empty() { Space::new() } else {
      let mut v1204_10 = Space::new();
      let mut v1204_10_cursor = (v1198_14_tail).read_zipper();
      for v1204_10_byte in v1204_10_cursor.child_mask().iter() {
        v1204_10_cursor.descend_to_byte(v1204_10_byte);
        let v1204_10_tail = v1204_10_cursor.make_map();
        v1204_10_cursor.ascend(1);
        let v1204_10_head = Path::from_slice(&[v1204_10_byte]);
        let v1205_2: Space = singleton(&(v1204_10_head));
        let v1205_3: Space = intersect(&(*CONSTANT_7),&(v1205_2));
        let v1205_4: Space = if has_head(&(v1205_3)) { singleton(&[]) } else { Space::new() };
        drop(v1205_3);
        let v1205_5: Space = subtract(&(*CONSTANT_0),&(v1205_4));
        drop(v1205_4);
        let v1205_7: Space = if (v1205_5).is_empty() { Space::new() } else {
          let v1206_6: Space = routine_158(c, &(v1204_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1198_14_head), &(v1204_10_tail));
          compose(&(v1205_5),&(v1206_6))
        };
        drop(v1205_5);
        let v1205_8: Space = intersect(&(*CONSTANT_7),&(v1205_2));
        drop(v1205_2);
        let v1205_9: Space = if has_head(&(v1205_8)) { singleton(&[]) } else { Space::new() };
        drop(v1205_8);
        let v1205_11: Space = if (v1205_9).is_empty() { Space::new() } else {
          let v1207_10: Space = routine_159(c, &(v1204_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1198_14_head), &(v1204_10_tail));
          compose(&(v1205_9),&(v1207_10))
        };
        drop(v1205_9);
        let v1205_12: Space = unite(&(v1205_7),&(v1205_11));
        v1204_10.join_into((v1205_12).clone());
      }
      drop(v1204_10_cursor);
      compose(&(v1199_9),&(v1204_10))
    };
    drop(v1199_9);
    let v1199_12: Space = unite(&(v1199_7),&(v1199_11));
    v1198_14.join_into((v1199_12).clone());
  }
  drop(v1198_14_cursor);
  (v1198_14).clone()
}

fn routine_120(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1208_11 = Space::new();
  let mut v1208_11_cursor = (*s0).read_zipper();
  for v1208_11_byte in v1208_11_cursor.child_mask().iter() {
    v1208_11_cursor.descend_to_byte(v1208_11_byte);
    let v1208_11_tail = v1208_11_cursor.make_map();
    v1208_11_cursor.ascend(1);
    let v1208_11_head = Path::from_slice(&[v1208_11_byte]);
    let v1209_2: Space = singleton(&(v1208_11_head));
    let v1209_3: Space = intersect(&(*CONSTANT_7),&(v1209_2));
    let v1209_4: Space = if has_head(&(v1209_3)) { singleton(&[]) } else { Space::new() };
    drop(v1209_3);
    let v1209_5: Space = subtract(&(*CONSTANT_0),&(v1209_4));
    drop(v1209_4);
    let v1209_8: Space = if (v1209_5).is_empty() { Space::new() } else {
      let v1210_6: Path = concat_path(&(*p0),&(v1208_11_head));
      let v1210_7: Space = routine_120(c, &(v1210_6), &(*p1), &(*p2), &(*p3), &(v1208_11_tail));
      compose(&(v1209_5),&(v1210_7))
    };
    drop(v1209_5);
    let v1209_9: Space = intersect(&(*CONSTANT_7),&(v1209_2));
    drop(v1209_2);
    let v1209_10: Space = if has_head(&(v1209_9)) { singleton(&[]) } else { Space::new() };
    drop(v1209_9);
    let v1209_12: Space = if (v1209_10).is_empty() { Space::new() } else {
      let v1211_6: Path = concat_path(&(*p0),&(v1208_11_head));
      let mut v1211_11 = Space::new();
      let mut v1211_11_cursor = (v1208_11_tail).read_zipper();
      for v1211_11_byte in v1211_11_cursor.child_mask().iter() {
        v1211_11_cursor.descend_to_byte(v1211_11_byte);
        let v1211_11_tail = v1211_11_cursor.make_map();
        v1211_11_cursor.ascend(1);
        let v1211_11_head = Path::from_slice(&[v1211_11_byte]);
        let v1212_2: Space = singleton(&(v1211_11_head));
        let v1212_3: Space = intersect(&(*CONSTANT_7),&(v1212_2));
        let v1212_4: Space = if has_head(&(v1212_3)) { singleton(&[]) } else { Space::new() };
        drop(v1212_3);
        let v1212_5: Space = subtract(&(*CONSTANT_0),&(v1212_4));
        drop(v1212_4);
        let v1212_7: Space = if (v1212_5).is_empty() { Space::new() } else {
          let v1213_6: Space = routine_138(c, &(v1211_11_head), &(*p1), &(*p2), &(*p3), &(v1211_6), &(v1211_11_tail));
          compose(&(v1212_5),&(v1213_6))
        };
        drop(v1212_5);
        let v1212_8: Space = intersect(&(*CONSTANT_7),&(v1212_2));
        drop(v1212_2);
        let v1212_9: Space = if has_head(&(v1212_8)) { singleton(&[]) } else { Space::new() };
        drop(v1212_8);
        let v1212_11: Space = if (v1212_9).is_empty() { Space::new() } else {
          let v1214_10: Space = routine_139(c, &(v1211_11_head), &(*p1), &(*p2), &(*p3), &(v1211_6), &(v1211_11_tail));
          compose(&(v1212_9),&(v1214_10))
        };
        drop(v1212_9);
        let v1212_12: Space = unite(&(v1212_7),&(v1212_11));
        v1211_11.join_into((v1212_12).clone());
      }
      drop(v1211_11_cursor);
      drop(v1211_6);
      compose(&(v1209_10),&(v1211_11))
    };
    drop(v1209_10);
    let v1209_13: Space = unite(&(v1209_8),&(v1209_12));
    v1208_11.join_into((v1209_13).clone());
  }
  drop(v1208_11_cursor);
  (v1208_11).clone()
}

fn routine_121(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1215_14 = Space::new();
  let mut v1215_14_cursor = (*s0).read_zipper();
  for v1215_14_byte in v1215_14_cursor.child_mask().iter() {
    v1215_14_cursor.descend_to_byte(v1215_14_byte);
    let v1215_14_tail = v1215_14_cursor.make_map();
    v1215_14_cursor.ascend(1);
    let v1215_14_head = Path::from_slice(&[v1215_14_byte]);
    let v1216_2: Space = singleton(&(v1215_14_head));
    let v1216_3: Space = intersect(&(*CONSTANT_7),&(v1216_2));
    let v1216_4: Space = if has_head(&(v1216_3)) { singleton(&[]) } else { Space::new() };
    drop(v1216_3);
    let v1216_5: Space = subtract(&(*CONSTANT_0),&(v1216_4));
    drop(v1216_4);
    let v1216_7: Space = if (v1216_5).is_empty() { Space::new() } else {
      let mut v1217_6 = Space::new();
      let mut v1217_6_cursor = (v1215_14_tail).read_zipper();
      for v1217_6_byte in v1217_6_cursor.child_mask().iter() {
        v1217_6_cursor.descend_to_byte(v1217_6_byte);
        let v1217_6_tail = v1217_6_cursor.make_map();
        v1217_6_cursor.ascend(1);
        let v1217_6_head = Path::from_slice(&[v1217_6_byte]);
        let v1218_2: Space = singleton(&(v1217_6_head));
        let v1218_3: Space = intersect(&(*CONSTANT_7),&(v1218_2));
        let v1218_4: Space = if has_head(&(v1218_3)) { singleton(&[]) } else { Space::new() };
        drop(v1218_3);
        let v1218_5: Space = subtract(&(*CONSTANT_0),&(v1218_4));
        drop(v1218_4);
        let v1218_8: Space = if (v1218_5).is_empty() { Space::new() } else {
          let v1219_6: Path = concat_path(&(v1215_14_head),&(v1217_6_head));
          let v1219_7: Space = routine_138(c, &(v1219_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1217_6_tail));
          compose(&(v1218_5),&(v1219_7))
        };
        drop(v1218_5);
        let v1218_9: Space = intersect(&(*CONSTANT_7),&(v1218_2));
        drop(v1218_2);
        let v1218_10: Space = if has_head(&(v1218_9)) { singleton(&[]) } else { Space::new() };
        drop(v1218_9);
        let v1218_12: Space = if (v1218_10).is_empty() { Space::new() } else {
          let v1220_6: Path = concat_path(&(v1215_14_head),&(v1217_6_head));
          let v1220_11: Space = routine_139(c, &(v1220_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1217_6_tail));
          drop(v1220_6);
          compose(&(v1218_10),&(v1220_11))
        };
        drop(v1218_10);
        let v1218_13: Space = unite(&(v1218_8),&(v1218_12));
        v1217_6.join_into((v1218_13).clone());
      }
      drop(v1217_6_cursor);
      compose(&(v1216_5),&(v1217_6))
    };
    drop(v1216_5);
    let v1216_8: Space = intersect(&(*CONSTANT_7),&(v1216_2));
    drop(v1216_2);
    let v1216_9: Space = if has_head(&(v1216_8)) { singleton(&[]) } else { Space::new() };
    drop(v1216_8);
    let v1216_11: Space = if (v1216_9).is_empty() { Space::new() } else {
      let mut v1221_10 = Space::new();
      let mut v1221_10_cursor = (v1215_14_tail).read_zipper();
      for v1221_10_byte in v1221_10_cursor.child_mask().iter() {
        v1221_10_cursor.descend_to_byte(v1221_10_byte);
        let v1221_10_tail = v1221_10_cursor.make_map();
        v1221_10_cursor.ascend(1);
        let v1221_10_head = Path::from_slice(&[v1221_10_byte]);
        let v1222_2: Space = singleton(&(v1221_10_head));
        let v1222_3: Space = intersect(&(*CONSTANT_7),&(v1222_2));
        let v1222_4: Space = if has_head(&(v1222_3)) { singleton(&[]) } else { Space::new() };
        drop(v1222_3);
        let v1222_5: Space = subtract(&(*CONSTANT_0),&(v1222_4));
        drop(v1222_4);
        let v1222_7: Space = if (v1222_5).is_empty() { Space::new() } else {
          let v1223_6: Space = routine_160(c, &(v1221_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1215_14_head), &(v1221_10_tail));
          compose(&(v1222_5),&(v1223_6))
        };
        drop(v1222_5);
        let v1222_8: Space = intersect(&(*CONSTANT_7),&(v1222_2));
        drop(v1222_2);
        let v1222_9: Space = if has_head(&(v1222_8)) { singleton(&[]) } else { Space::new() };
        drop(v1222_8);
        let v1222_11: Space = if (v1222_9).is_empty() { Space::new() } else {
          let v1224_10: Space = routine_161(c, &(v1221_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1215_14_head), &(v1221_10_tail));
          compose(&(v1222_9),&(v1224_10))
        };
        drop(v1222_9);
        let v1222_12: Space = unite(&(v1222_7),&(v1222_11));
        v1221_10.join_into((v1222_12).clone());
      }
      drop(v1221_10_cursor);
      compose(&(v1216_9),&(v1221_10))
    };
    drop(v1216_9);
    let v1216_12: Space = unite(&(v1216_7),&(v1216_11));
    v1215_14.join_into((v1216_12).clone());
  }
  drop(v1215_14_cursor);
  (v1215_14).clone()
}

fn routine_122(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1225_11 = Space::new();
  let mut v1225_11_cursor = (*s0).read_zipper();
  for v1225_11_byte in v1225_11_cursor.child_mask().iter() {
    v1225_11_cursor.descend_to_byte(v1225_11_byte);
    let v1225_11_tail = v1225_11_cursor.make_map();
    v1225_11_cursor.ascend(1);
    let v1225_11_head = Path::from_slice(&[v1225_11_byte]);
    let v1226_2: Space = singleton(&(v1225_11_head));
    let v1226_3: Space = intersect(&(*CONSTANT_7),&(v1226_2));
    let v1226_4: Space = if has_head(&(v1226_3)) { singleton(&[]) } else { Space::new() };
    drop(v1226_3);
    let v1226_5: Space = subtract(&(*CONSTANT_0),&(v1226_4));
    drop(v1226_4);
    let v1226_8: Space = if (v1226_5).is_empty() { Space::new() } else {
      let v1227_6: Path = concat_path(&(*p0),&(v1225_11_head));
      let v1227_7: Space = routine_122(c, &(v1227_6), &(*p1), &(*p2), &(*p3), &(v1225_11_tail));
      compose(&(v1226_5),&(v1227_7))
    };
    drop(v1226_5);
    let v1226_9: Space = intersect(&(*CONSTANT_7),&(v1226_2));
    drop(v1226_2);
    let v1226_10: Space = if has_head(&(v1226_9)) { singleton(&[]) } else { Space::new() };
    drop(v1226_9);
    let v1226_12: Space = if (v1226_10).is_empty() { Space::new() } else {
      let v1228_6: Path = concat_path(&(*p0),&(v1225_11_head));
      let mut v1228_11 = Space::new();
      let mut v1228_11_cursor = (v1225_11_tail).read_zipper();
      for v1228_11_byte in v1228_11_cursor.child_mask().iter() {
        v1228_11_cursor.descend_to_byte(v1228_11_byte);
        let v1228_11_tail = v1228_11_cursor.make_map();
        v1228_11_cursor.ascend(1);
        let v1228_11_head = Path::from_slice(&[v1228_11_byte]);
        let v1229_2: Space = singleton(&(v1228_11_head));
        let v1229_3: Space = intersect(&(*CONSTANT_7),&(v1229_2));
        let v1229_4: Space = if has_head(&(v1229_3)) { singleton(&[]) } else { Space::new() };
        drop(v1229_3);
        let v1229_5: Space = subtract(&(*CONSTANT_0),&(v1229_4));
        drop(v1229_4);
        let v1229_7: Space = if (v1229_5).is_empty() { Space::new() } else {
          let v1230_6: Space = routine_140(c, &(v1228_11_head), &(*p1), &(*p2), &(*p3), &(v1228_6), &(v1228_11_tail));
          compose(&(v1229_5),&(v1230_6))
        };
        drop(v1229_5);
        let v1229_8: Space = intersect(&(*CONSTANT_7),&(v1229_2));
        drop(v1229_2);
        let v1229_9: Space = if has_head(&(v1229_8)) { singleton(&[]) } else { Space::new() };
        drop(v1229_8);
        let v1229_11: Space = if (v1229_9).is_empty() { Space::new() } else {
          let v1231_10: Space = routine_141(c, &(v1228_11_head), &(*p1), &(*p2), &(*p3), &(v1228_6), &(v1228_11_tail));
          compose(&(v1229_9),&(v1231_10))
        };
        drop(v1229_9);
        let v1229_12: Space = unite(&(v1229_7),&(v1229_11));
        v1228_11.join_into((v1229_12).clone());
      }
      drop(v1228_11_cursor);
      drop(v1228_6);
      compose(&(v1226_10),&(v1228_11))
    };
    drop(v1226_10);
    let v1226_13: Space = unite(&(v1226_8),&(v1226_12));
    v1225_11.join_into((v1226_13).clone());
  }
  drop(v1225_11_cursor);
  (v1225_11).clone()
}

fn routine_123(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v1232_14 = Space::new();
  let mut v1232_14_cursor = (*s0).read_zipper();
  for v1232_14_byte in v1232_14_cursor.child_mask().iter() {
    v1232_14_cursor.descend_to_byte(v1232_14_byte);
    let v1232_14_tail = v1232_14_cursor.make_map();
    v1232_14_cursor.ascend(1);
    let v1232_14_head = Path::from_slice(&[v1232_14_byte]);
    let v1233_2: Space = singleton(&(v1232_14_head));
    let v1233_3: Space = intersect(&(*CONSTANT_7),&(v1233_2));
    let v1233_4: Space = if has_head(&(v1233_3)) { singleton(&[]) } else { Space::new() };
    drop(v1233_3);
    let v1233_5: Space = subtract(&(*CONSTANT_0),&(v1233_4));
    drop(v1233_4);
    let v1233_7: Space = if (v1233_5).is_empty() { Space::new() } else {
      let mut v1234_6 = Space::new();
      let mut v1234_6_cursor = (v1232_14_tail).read_zipper();
      for v1234_6_byte in v1234_6_cursor.child_mask().iter() {
        v1234_6_cursor.descend_to_byte(v1234_6_byte);
        let v1234_6_tail = v1234_6_cursor.make_map();
        v1234_6_cursor.ascend(1);
        let v1234_6_head = Path::from_slice(&[v1234_6_byte]);
        let v1235_2: Space = singleton(&(v1234_6_head));
        let v1235_3: Space = intersect(&(*CONSTANT_7),&(v1235_2));
        let v1235_4: Space = if has_head(&(v1235_3)) { singleton(&[]) } else { Space::new() };
        drop(v1235_3);
        let v1235_5: Space = subtract(&(*CONSTANT_0),&(v1235_4));
        drop(v1235_4);
        let v1235_8: Space = if (v1235_5).is_empty() { Space::new() } else {
          let v1236_6: Path = concat_path(&(v1232_14_head),&(v1234_6_head));
          let v1236_7: Space = routine_140(c, &(v1236_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1234_6_tail));
          compose(&(v1235_5),&(v1236_7))
        };
        drop(v1235_5);
        let v1235_9: Space = intersect(&(*CONSTANT_7),&(v1235_2));
        drop(v1235_2);
        let v1235_10: Space = if has_head(&(v1235_9)) { singleton(&[]) } else { Space::new() };
        drop(v1235_9);
        let v1235_12: Space = if (v1235_10).is_empty() { Space::new() } else {
          let v1237_6: Path = concat_path(&(v1232_14_head),&(v1234_6_head));
          let v1237_11: Space = routine_141(c, &(v1237_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v1234_6_tail));
          drop(v1237_6);
          compose(&(v1235_10),&(v1237_11))
        };
        drop(v1235_10);
        let v1235_13: Space = unite(&(v1235_8),&(v1235_12));
        v1234_6.join_into((v1235_13).clone());
      }
      drop(v1234_6_cursor);
      compose(&(v1233_5),&(v1234_6))
    };
    drop(v1233_5);
    let v1233_8: Space = intersect(&(*CONSTANT_7),&(v1233_2));
    drop(v1233_2);
    let v1233_9: Space = if has_head(&(v1233_8)) { singleton(&[]) } else { Space::new() };
    drop(v1233_8);
    let v1233_11: Space = if (v1233_9).is_empty() { Space::new() } else {
      let mut v1238_10 = Space::new();
      let mut v1238_10_cursor = (v1232_14_tail).read_zipper();
      for v1238_10_byte in v1238_10_cursor.child_mask().iter() {
        v1238_10_cursor.descend_to_byte(v1238_10_byte);
        let v1238_10_tail = v1238_10_cursor.make_map();
        v1238_10_cursor.ascend(1);
        let v1238_10_head = Path::from_slice(&[v1238_10_byte]);
        let v1239_2: Space = singleton(&(v1238_10_head));
        let v1239_3: Space = intersect(&(*CONSTANT_7),&(v1239_2));
        let v1239_4: Space = if has_head(&(v1239_3)) { singleton(&[]) } else { Space::new() };
        drop(v1239_3);
        let v1239_5: Space = subtract(&(*CONSTANT_0),&(v1239_4));
        drop(v1239_4);
        let v1239_7: Space = if (v1239_5).is_empty() { Space::new() } else {
          let v1240_6: Space = routine_162(c, &(v1238_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1232_14_head), &(v1238_10_tail));
          compose(&(v1239_5),&(v1240_6))
        };
        drop(v1239_5);
        let v1239_8: Space = intersect(&(*CONSTANT_7),&(v1239_2));
        drop(v1239_2);
        let v1239_9: Space = if has_head(&(v1239_8)) { singleton(&[]) } else { Space::new() };
        drop(v1239_8);
        let v1239_11: Space = if (v1239_9).is_empty() { Space::new() } else {
          let v1241_10: Space = routine_163(c, &(v1238_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v1232_14_head), &(v1238_10_tail));
          compose(&(v1239_9),&(v1241_10))
        };
        drop(v1239_9);
        let v1239_12: Space = unite(&(v1239_7),&(v1239_11));
        v1238_10.join_into((v1239_12).clone());
      }
      drop(v1238_10_cursor);
      compose(&(v1233_9),&(v1238_10))
    };
    drop(v1233_9);
    let v1233_12: Space = unite(&(v1233_7),&(v1233_11));
    v1232_14.join_into((v1233_12).clone());
  }
  drop(v1232_14_cursor);
  (v1232_14).clone()
}

fn routine_124(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1242_12 = Space::new();
  let mut v1242_12_cursor = (*s0).read_zipper();
  for v1242_12_byte in v1242_12_cursor.child_mask().iter() {
    v1242_12_cursor.descend_to_byte(v1242_12_byte);
    let v1242_12_tail = v1242_12_cursor.make_map();
    v1242_12_cursor.ascend(1);
    let v1242_12_head = Path::from_slice(&[v1242_12_byte]);
    let v1243_2: Space = singleton(&(v1242_12_head));
    let v1243_3: Space = intersect(&(*CONSTANT_7),&(v1243_2));
    let v1243_4: Space = if has_head(&(v1243_3)) { singleton(&[]) } else { Space::new() };
    drop(v1243_3);
    let v1243_5: Space = subtract(&(*CONSTANT_0),&(v1243_4));
    drop(v1243_4);
    let v1243_8: Space = if (v1243_5).is_empty() { Space::new() } else {
      let v1244_6: Path = concat_path(&(*p0),&(v1242_12_head));
      let v1244_7: Space = routine_124(c, &(v1244_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v1242_12_tail));
      compose(&(v1243_5),&(v1244_7))
    };
    drop(v1243_5);
    let v1243_9: Space = intersect(&(*CONSTANT_7),&(v1243_2));
    drop(v1243_2);
    let v1243_10: Space = if has_head(&(v1243_9)) { singleton(&[]) } else { Space::new() };
    drop(v1243_9);
    let v1243_12: Space = if (v1243_10).is_empty() { Space::new() } else {
      let v1245_6: Path = concat_path(&(*p0),&(v1242_12_head));
      let mut v1245_11 = Space::new();
      let mut v1245_11_cursor = (v1242_12_tail).read_zipper();
      for v1245_11_byte in v1245_11_cursor.child_mask().iter() {
        v1245_11_cursor.descend_to_byte(v1245_11_byte);
        let v1245_11_tail = v1245_11_cursor.make_map();
        v1245_11_cursor.ascend(1);
        let v1245_11_head = Path::from_slice(&[v1245_11_byte]);
        let v1246_2: Space = singleton(&(v1245_11_head));
        let v1246_3: Space = intersect(&(*CONSTANT_7),&(v1246_2));
        let v1246_4: Space = if has_head(&(v1246_3)) { singleton(&[]) } else { Space::new() };
        drop(v1246_3);
        let v1246_5: Space = subtract(&(*CONSTANT_0),&(v1246_4));
        drop(v1246_4);
        let v1246_7: Space = if (v1246_5).is_empty() { Space::new() } else {
          let v1247_6: Space = routine_146(c, &(v1245_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1245_6), &(v1245_11_tail));
          compose(&(v1246_5),&(v1247_6))
        };
        drop(v1246_5);
        let v1246_8: Space = intersect(&(*CONSTANT_7),&(v1246_2));
        drop(v1246_2);
        let v1246_9: Space = if has_head(&(v1246_8)) { singleton(&[]) } else { Space::new() };
        drop(v1246_8);
        let v1246_11: Space = if (v1246_9).is_empty() { Space::new() } else {
          let v1248_10: Space = routine_147(c, &(v1245_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1245_6), &(v1245_11_tail));
          compose(&(v1246_9),&(v1248_10))
        };
        drop(v1246_9);
        let v1246_12: Space = unite(&(v1246_7),&(v1246_11));
        v1245_11.join_into((v1246_12).clone());
      }
      drop(v1245_11_cursor);
      drop(v1245_6);
      compose(&(v1243_10),&(v1245_11))
    };
    drop(v1243_10);
    let v1243_13: Space = unite(&(v1243_8),&(v1243_12));
    v1242_12.join_into((v1243_13).clone());
  }
  drop(v1242_12_cursor);
  (v1242_12).clone()
}

fn routine_125(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1249_15 = Space::new();
  let mut v1249_15_cursor = (*s0).read_zipper();
  for v1249_15_byte in v1249_15_cursor.child_mask().iter() {
    v1249_15_cursor.descend_to_byte(v1249_15_byte);
    let v1249_15_tail = v1249_15_cursor.make_map();
    v1249_15_cursor.ascend(1);
    let v1249_15_head = Path::from_slice(&[v1249_15_byte]);
    let v1250_2: Space = singleton(&(v1249_15_head));
    let v1250_3: Space = intersect(&(*CONSTANT_7),&(v1250_2));
    let v1250_4: Space = if has_head(&(v1250_3)) { singleton(&[]) } else { Space::new() };
    drop(v1250_3);
    let v1250_5: Space = subtract(&(*CONSTANT_0),&(v1250_4));
    drop(v1250_4);
    let v1250_7: Space = if (v1250_5).is_empty() { Space::new() } else {
      let mut v1251_6 = Space::new();
      let mut v1251_6_cursor = (v1249_15_tail).read_zipper();
      for v1251_6_byte in v1251_6_cursor.child_mask().iter() {
        v1251_6_cursor.descend_to_byte(v1251_6_byte);
        let v1251_6_tail = v1251_6_cursor.make_map();
        v1251_6_cursor.ascend(1);
        let v1251_6_head = Path::from_slice(&[v1251_6_byte]);
        let v1252_2: Space = singleton(&(v1251_6_head));
        let v1252_3: Space = intersect(&(*CONSTANT_7),&(v1252_2));
        let v1252_4: Space = if has_head(&(v1252_3)) { singleton(&[]) } else { Space::new() };
        drop(v1252_3);
        let v1252_5: Space = subtract(&(*CONSTANT_0),&(v1252_4));
        drop(v1252_4);
        let v1252_8: Space = if (v1252_5).is_empty() { Space::new() } else {
          let v1253_6: Path = concat_path(&(v1249_15_head),&(v1251_6_head));
          let v1253_7: Space = routine_146(c, &(v1253_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1251_6_tail));
          compose(&(v1252_5),&(v1253_7))
        };
        drop(v1252_5);
        let v1252_9: Space = intersect(&(*CONSTANT_7),&(v1252_2));
        drop(v1252_2);
        let v1252_10: Space = if has_head(&(v1252_9)) { singleton(&[]) } else { Space::new() };
        drop(v1252_9);
        let v1252_12: Space = if (v1252_10).is_empty() { Space::new() } else {
          let v1254_6: Path = concat_path(&(v1249_15_head),&(v1251_6_head));
          let v1254_11: Space = routine_147(c, &(v1254_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1251_6_tail));
          drop(v1254_6);
          compose(&(v1252_10),&(v1254_11))
        };
        drop(v1252_10);
        let v1252_13: Space = unite(&(v1252_8),&(v1252_12));
        v1251_6.join_into((v1252_13).clone());
      }
      drop(v1251_6_cursor);
      compose(&(v1250_5),&(v1251_6))
    };
    drop(v1250_5);
    let v1250_8: Space = intersect(&(*CONSTANT_7),&(v1250_2));
    drop(v1250_2);
    let v1250_9: Space = if has_head(&(v1250_8)) { singleton(&[]) } else { Space::new() };
    drop(v1250_8);
    let v1250_11: Space = if (v1250_9).is_empty() { Space::new() } else {
      let mut v1255_10 = Space::new();
      let mut v1255_10_cursor = (v1249_15_tail).read_zipper();
      for v1255_10_byte in v1255_10_cursor.child_mask().iter() {
        v1255_10_cursor.descend_to_byte(v1255_10_byte);
        let v1255_10_tail = v1255_10_cursor.make_map();
        v1255_10_cursor.ascend(1);
        let v1255_10_head = Path::from_slice(&[v1255_10_byte]);
        let v1256_2: Space = singleton(&(v1255_10_head));
        let v1256_3: Space = intersect(&(*CONSTANT_7),&(v1256_2));
        let v1256_4: Space = if has_head(&(v1256_3)) { singleton(&[]) } else { Space::new() };
        drop(v1256_3);
        let v1256_5: Space = subtract(&(*CONSTANT_0),&(v1256_4));
        drop(v1256_4);
        let v1256_7: Space = if (v1256_5).is_empty() { Space::new() } else {
          let v1257_6: Space = routine_164(c, &(v1255_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1249_15_head), &(v1255_10_tail));
          compose(&(v1256_5),&(v1257_6))
        };
        drop(v1256_5);
        let v1256_8: Space = intersect(&(*CONSTANT_7),&(v1256_2));
        drop(v1256_2);
        let v1256_9: Space = if has_head(&(v1256_8)) { singleton(&[]) } else { Space::new() };
        drop(v1256_8);
        let v1256_11: Space = if (v1256_9).is_empty() { Space::new() } else {
          let v1258_10: Space = routine_165(c, &(v1255_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1249_15_head), &(v1255_10_tail));
          compose(&(v1256_9),&(v1258_10))
        };
        drop(v1256_9);
        let v1256_12: Space = unite(&(v1256_7),&(v1256_11));
        v1255_10.join_into((v1256_12).clone());
      }
      drop(v1255_10_cursor);
      compose(&(v1250_9),&(v1255_10))
    };
    drop(v1250_9);
    let v1250_12: Space = unite(&(v1250_7),&(v1250_11));
    v1249_15.join_into((v1250_12).clone());
  }
  drop(v1249_15_cursor);
  (v1249_15).clone()
}

fn routine_126(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1259_12 = Space::new();
  let mut v1259_12_cursor = (*s0).read_zipper();
  for v1259_12_byte in v1259_12_cursor.child_mask().iter() {
    v1259_12_cursor.descend_to_byte(v1259_12_byte);
    let v1259_12_tail = v1259_12_cursor.make_map();
    v1259_12_cursor.ascend(1);
    let v1259_12_head = Path::from_slice(&[v1259_12_byte]);
    let v1260_2: Space = singleton(&(v1259_12_head));
    let v1260_3: Space = intersect(&(*CONSTANT_7),&(v1260_2));
    let v1260_4: Space = if has_head(&(v1260_3)) { singleton(&[]) } else { Space::new() };
    drop(v1260_3);
    let v1260_5: Space = subtract(&(*CONSTANT_0),&(v1260_4));
    drop(v1260_4);
    let v1260_8: Space = if (v1260_5).is_empty() { Space::new() } else {
      let v1261_6: Path = concat_path(&(*p0),&(v1259_12_head));
      let v1261_7: Space = routine_126(c, &(v1261_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v1259_12_tail));
      compose(&(v1260_5),&(v1261_7))
    };
    drop(v1260_5);
    let v1260_9: Space = intersect(&(*CONSTANT_7),&(v1260_2));
    drop(v1260_2);
    let v1260_10: Space = if has_head(&(v1260_9)) { singleton(&[]) } else { Space::new() };
    drop(v1260_9);
    let v1260_12: Space = if (v1260_10).is_empty() { Space::new() } else {
      let v1262_6: Path = concat_path(&(*p0),&(v1259_12_head));
      let mut v1262_11 = Space::new();
      let mut v1262_11_cursor = (v1259_12_tail).read_zipper();
      for v1262_11_byte in v1262_11_cursor.child_mask().iter() {
        v1262_11_cursor.descend_to_byte(v1262_11_byte);
        let v1262_11_tail = v1262_11_cursor.make_map();
        v1262_11_cursor.ascend(1);
        let v1262_11_head = Path::from_slice(&[v1262_11_byte]);
        let v1263_2: Space = singleton(&(v1262_11_head));
        let v1263_3: Space = intersect(&(*CONSTANT_7),&(v1263_2));
        let v1263_4: Space = if has_head(&(v1263_3)) { singleton(&[]) } else { Space::new() };
        drop(v1263_3);
        let v1263_5: Space = subtract(&(*CONSTANT_0),&(v1263_4));
        drop(v1263_4);
        let v1263_7: Space = if (v1263_5).is_empty() { Space::new() } else {
          let v1264_6: Space = routine_148(c, &(v1262_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1262_6), &(v1262_11_tail));
          compose(&(v1263_5),&(v1264_6))
        };
        drop(v1263_5);
        let v1263_8: Space = intersect(&(*CONSTANT_7),&(v1263_2));
        drop(v1263_2);
        let v1263_9: Space = if has_head(&(v1263_8)) { singleton(&[]) } else { Space::new() };
        drop(v1263_8);
        let v1263_11: Space = if (v1263_9).is_empty() { Space::new() } else {
          let v1265_10: Space = routine_149(c, &(v1262_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1262_6), &(v1262_11_tail));
          compose(&(v1263_9),&(v1265_10))
        };
        drop(v1263_9);
        let v1263_12: Space = unite(&(v1263_7),&(v1263_11));
        v1262_11.join_into((v1263_12).clone());
      }
      drop(v1262_11_cursor);
      drop(v1262_6);
      compose(&(v1260_10),&(v1262_11))
    };
    drop(v1260_10);
    let v1260_13: Space = unite(&(v1260_8),&(v1260_12));
    v1259_12.join_into((v1260_13).clone());
  }
  drop(v1259_12_cursor);
  (v1259_12).clone()
}

fn routine_127(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1266_15 = Space::new();
  let mut v1266_15_cursor = (*s0).read_zipper();
  for v1266_15_byte in v1266_15_cursor.child_mask().iter() {
    v1266_15_cursor.descend_to_byte(v1266_15_byte);
    let v1266_15_tail = v1266_15_cursor.make_map();
    v1266_15_cursor.ascend(1);
    let v1266_15_head = Path::from_slice(&[v1266_15_byte]);
    let v1267_2: Space = singleton(&(v1266_15_head));
    let v1267_3: Space = intersect(&(*CONSTANT_7),&(v1267_2));
    let v1267_4: Space = if has_head(&(v1267_3)) { singleton(&[]) } else { Space::new() };
    drop(v1267_3);
    let v1267_5: Space = subtract(&(*CONSTANT_0),&(v1267_4));
    drop(v1267_4);
    let v1267_7: Space = if (v1267_5).is_empty() { Space::new() } else {
      let mut v1268_6 = Space::new();
      let mut v1268_6_cursor = (v1266_15_tail).read_zipper();
      for v1268_6_byte in v1268_6_cursor.child_mask().iter() {
        v1268_6_cursor.descend_to_byte(v1268_6_byte);
        let v1268_6_tail = v1268_6_cursor.make_map();
        v1268_6_cursor.ascend(1);
        let v1268_6_head = Path::from_slice(&[v1268_6_byte]);
        let v1269_2: Space = singleton(&(v1268_6_head));
        let v1269_3: Space = intersect(&(*CONSTANT_7),&(v1269_2));
        let v1269_4: Space = if has_head(&(v1269_3)) { singleton(&[]) } else { Space::new() };
        drop(v1269_3);
        let v1269_5: Space = subtract(&(*CONSTANT_0),&(v1269_4));
        drop(v1269_4);
        let v1269_8: Space = if (v1269_5).is_empty() { Space::new() } else {
          let v1270_6: Path = concat_path(&(v1266_15_head),&(v1268_6_head));
          let v1270_7: Space = routine_148(c, &(v1270_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1268_6_tail));
          compose(&(v1269_5),&(v1270_7))
        };
        drop(v1269_5);
        let v1269_9: Space = intersect(&(*CONSTANT_7),&(v1269_2));
        drop(v1269_2);
        let v1269_10: Space = if has_head(&(v1269_9)) { singleton(&[]) } else { Space::new() };
        drop(v1269_9);
        let v1269_12: Space = if (v1269_10).is_empty() { Space::new() } else {
          let v1271_6: Path = concat_path(&(v1266_15_head),&(v1268_6_head));
          let v1271_11: Space = routine_149(c, &(v1271_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1268_6_tail));
          drop(v1271_6);
          compose(&(v1269_10),&(v1271_11))
        };
        drop(v1269_10);
        let v1269_13: Space = unite(&(v1269_8),&(v1269_12));
        v1268_6.join_into((v1269_13).clone());
      }
      drop(v1268_6_cursor);
      compose(&(v1267_5),&(v1268_6))
    };
    drop(v1267_5);
    let v1267_8: Space = intersect(&(*CONSTANT_7),&(v1267_2));
    drop(v1267_2);
    let v1267_9: Space = if has_head(&(v1267_8)) { singleton(&[]) } else { Space::new() };
    drop(v1267_8);
    let v1267_11: Space = if (v1267_9).is_empty() { Space::new() } else {
      let mut v1272_10 = Space::new();
      let mut v1272_10_cursor = (v1266_15_tail).read_zipper();
      for v1272_10_byte in v1272_10_cursor.child_mask().iter() {
        v1272_10_cursor.descend_to_byte(v1272_10_byte);
        let v1272_10_tail = v1272_10_cursor.make_map();
        v1272_10_cursor.ascend(1);
        let v1272_10_head = Path::from_slice(&[v1272_10_byte]);
        let v1273_2: Space = singleton(&(v1272_10_head));
        let v1273_3: Space = intersect(&(*CONSTANT_7),&(v1273_2));
        let v1273_4: Space = if has_head(&(v1273_3)) { singleton(&[]) } else { Space::new() };
        drop(v1273_3);
        let v1273_5: Space = subtract(&(*CONSTANT_0),&(v1273_4));
        drop(v1273_4);
        let v1273_7: Space = if (v1273_5).is_empty() { Space::new() } else {
          let v1274_6: Space = routine_166(c, &(v1272_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1266_15_head), &(v1272_10_tail));
          compose(&(v1273_5),&(v1274_6))
        };
        drop(v1273_5);
        let v1273_8: Space = intersect(&(*CONSTANT_7),&(v1273_2));
        drop(v1273_2);
        let v1273_9: Space = if has_head(&(v1273_8)) { singleton(&[]) } else { Space::new() };
        drop(v1273_8);
        let v1273_11: Space = if (v1273_9).is_empty() { Space::new() } else {
          let v1275_10: Space = routine_167(c, &(v1272_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1266_15_head), &(v1272_10_tail));
          compose(&(v1273_9),&(v1275_10))
        };
        drop(v1273_9);
        let v1273_12: Space = unite(&(v1273_7),&(v1273_11));
        v1272_10.join_into((v1273_12).clone());
      }
      drop(v1272_10_cursor);
      compose(&(v1267_9),&(v1272_10))
    };
    drop(v1267_9);
    let v1267_12: Space = unite(&(v1267_7),&(v1267_11));
    v1266_15.join_into((v1267_12).clone());
  }
  drop(v1266_15_cursor);
  (v1266_15).clone()
}

fn routine_128(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1276_12 = Space::new();
  let mut v1276_12_cursor = (*s0).read_zipper();
  for v1276_12_byte in v1276_12_cursor.child_mask().iter() {
    v1276_12_cursor.descend_to_byte(v1276_12_byte);
    let v1276_12_tail = v1276_12_cursor.make_map();
    v1276_12_cursor.ascend(1);
    let v1276_12_head = Path::from_slice(&[v1276_12_byte]);
    let v1277_2: Space = singleton(&(v1276_12_head));
    let v1277_3: Space = intersect(&(*CONSTANT_7),&(v1277_2));
    let v1277_4: Space = if has_head(&(v1277_3)) { singleton(&[]) } else { Space::new() };
    drop(v1277_3);
    let v1277_5: Space = subtract(&(*CONSTANT_0),&(v1277_4));
    drop(v1277_4);
    let v1277_8: Space = if (v1277_5).is_empty() { Space::new() } else {
      let v1278_6: Path = concat_path(&(*p0),&(v1276_12_head));
      let v1278_7: Space = routine_128(c, &(v1278_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v1276_12_tail));
      compose(&(v1277_5),&(v1278_7))
    };
    drop(v1277_5);
    let v1277_9: Space = intersect(&(*CONSTANT_7),&(v1277_2));
    drop(v1277_2);
    let v1277_10: Space = if has_head(&(v1277_9)) { singleton(&[]) } else { Space::new() };
    drop(v1277_9);
    let v1277_12: Space = if (v1277_10).is_empty() { Space::new() } else {
      let v1279_6: Path = concat_path(&(*p0),&(v1276_12_head));
      let mut v1279_11 = Space::new();
      let mut v1279_11_cursor = (v1276_12_tail).read_zipper();
      for v1279_11_byte in v1279_11_cursor.child_mask().iter() {
        v1279_11_cursor.descend_to_byte(v1279_11_byte);
        let v1279_11_tail = v1279_11_cursor.make_map();
        v1279_11_cursor.ascend(1);
        let v1279_11_head = Path::from_slice(&[v1279_11_byte]);
        let v1280_2: Space = singleton(&(v1279_11_head));
        let v1280_3: Space = intersect(&(*CONSTANT_7),&(v1280_2));
        let v1280_4: Space = if has_head(&(v1280_3)) { singleton(&[]) } else { Space::new() };
        drop(v1280_3);
        let v1280_5: Space = subtract(&(*CONSTANT_0),&(v1280_4));
        drop(v1280_4);
        let v1280_7: Space = if (v1280_5).is_empty() { Space::new() } else {
          let v1281_6: Space = routine_150(c, &(v1279_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1279_6), &(v1279_11_tail));
          compose(&(v1280_5),&(v1281_6))
        };
        drop(v1280_5);
        let v1280_8: Space = intersect(&(*CONSTANT_7),&(v1280_2));
        drop(v1280_2);
        let v1280_9: Space = if has_head(&(v1280_8)) { singleton(&[]) } else { Space::new() };
        drop(v1280_8);
        let v1280_11: Space = if (v1280_9).is_empty() { Space::new() } else {
          let v1282_10: Space = routine_151(c, &(v1279_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1279_6), &(v1279_11_tail));
          compose(&(v1280_9),&(v1282_10))
        };
        drop(v1280_9);
        let v1280_12: Space = unite(&(v1280_7),&(v1280_11));
        v1279_11.join_into((v1280_12).clone());
      }
      drop(v1279_11_cursor);
      drop(v1279_6);
      compose(&(v1277_10),&(v1279_11))
    };
    drop(v1277_10);
    let v1277_13: Space = unite(&(v1277_8),&(v1277_12));
    v1276_12.join_into((v1277_13).clone());
  }
  drop(v1276_12_cursor);
  (v1276_12).clone()
}

fn routine_129(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1283_15 = Space::new();
  let mut v1283_15_cursor = (*s0).read_zipper();
  for v1283_15_byte in v1283_15_cursor.child_mask().iter() {
    v1283_15_cursor.descend_to_byte(v1283_15_byte);
    let v1283_15_tail = v1283_15_cursor.make_map();
    v1283_15_cursor.ascend(1);
    let v1283_15_head = Path::from_slice(&[v1283_15_byte]);
    let v1284_2: Space = singleton(&(v1283_15_head));
    let v1284_3: Space = intersect(&(*CONSTANT_7),&(v1284_2));
    let v1284_4: Space = if has_head(&(v1284_3)) { singleton(&[]) } else { Space::new() };
    drop(v1284_3);
    let v1284_5: Space = subtract(&(*CONSTANT_0),&(v1284_4));
    drop(v1284_4);
    let v1284_7: Space = if (v1284_5).is_empty() { Space::new() } else {
      let mut v1285_6 = Space::new();
      let mut v1285_6_cursor = (v1283_15_tail).read_zipper();
      for v1285_6_byte in v1285_6_cursor.child_mask().iter() {
        v1285_6_cursor.descend_to_byte(v1285_6_byte);
        let v1285_6_tail = v1285_6_cursor.make_map();
        v1285_6_cursor.ascend(1);
        let v1285_6_head = Path::from_slice(&[v1285_6_byte]);
        let v1286_2: Space = singleton(&(v1285_6_head));
        let v1286_3: Space = intersect(&(*CONSTANT_7),&(v1286_2));
        let v1286_4: Space = if has_head(&(v1286_3)) { singleton(&[]) } else { Space::new() };
        drop(v1286_3);
        let v1286_5: Space = subtract(&(*CONSTANT_0),&(v1286_4));
        drop(v1286_4);
        let v1286_8: Space = if (v1286_5).is_empty() { Space::new() } else {
          let v1287_6: Path = concat_path(&(v1283_15_head),&(v1285_6_head));
          let v1287_7: Space = routine_150(c, &(v1287_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1285_6_tail));
          compose(&(v1286_5),&(v1287_7))
        };
        drop(v1286_5);
        let v1286_9: Space = intersect(&(*CONSTANT_7),&(v1286_2));
        drop(v1286_2);
        let v1286_10: Space = if has_head(&(v1286_9)) { singleton(&[]) } else { Space::new() };
        drop(v1286_9);
        let v1286_12: Space = if (v1286_10).is_empty() { Space::new() } else {
          let v1288_6: Path = concat_path(&(v1283_15_head),&(v1285_6_head));
          let v1288_11: Space = routine_151(c, &(v1288_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1285_6_tail));
          drop(v1288_6);
          compose(&(v1286_10),&(v1288_11))
        };
        drop(v1286_10);
        let v1286_13: Space = unite(&(v1286_8),&(v1286_12));
        v1285_6.join_into((v1286_13).clone());
      }
      drop(v1285_6_cursor);
      compose(&(v1284_5),&(v1285_6))
    };
    drop(v1284_5);
    let v1284_8: Space = intersect(&(*CONSTANT_7),&(v1284_2));
    drop(v1284_2);
    let v1284_9: Space = if has_head(&(v1284_8)) { singleton(&[]) } else { Space::new() };
    drop(v1284_8);
    let v1284_11: Space = if (v1284_9).is_empty() { Space::new() } else {
      let mut v1289_10 = Space::new();
      let mut v1289_10_cursor = (v1283_15_tail).read_zipper();
      for v1289_10_byte in v1289_10_cursor.child_mask().iter() {
        v1289_10_cursor.descend_to_byte(v1289_10_byte);
        let v1289_10_tail = v1289_10_cursor.make_map();
        v1289_10_cursor.ascend(1);
        let v1289_10_head = Path::from_slice(&[v1289_10_byte]);
        let v1290_2: Space = singleton(&(v1289_10_head));
        let v1290_3: Space = intersect(&(*CONSTANT_7),&(v1290_2));
        let v1290_4: Space = if has_head(&(v1290_3)) { singleton(&[]) } else { Space::new() };
        drop(v1290_3);
        let v1290_5: Space = subtract(&(*CONSTANT_0),&(v1290_4));
        drop(v1290_4);
        let v1290_7: Space = if (v1290_5).is_empty() { Space::new() } else {
          let v1291_6: Space = routine_168(c, &(v1289_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1283_15_head), &(v1289_10_tail));
          compose(&(v1290_5),&(v1291_6))
        };
        drop(v1290_5);
        let v1290_8: Space = intersect(&(*CONSTANT_7),&(v1290_2));
        drop(v1290_2);
        let v1290_9: Space = if has_head(&(v1290_8)) { singleton(&[]) } else { Space::new() };
        drop(v1290_8);
        let v1290_11: Space = if (v1290_9).is_empty() { Space::new() } else {
          let v1292_10: Space = routine_169(c, &(v1289_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1283_15_head), &(v1289_10_tail));
          compose(&(v1290_9),&(v1292_10))
        };
        drop(v1290_9);
        let v1290_12: Space = unite(&(v1290_7),&(v1290_11));
        v1289_10.join_into((v1290_12).clone());
      }
      drop(v1289_10_cursor);
      compose(&(v1284_9),&(v1289_10))
    };
    drop(v1284_9);
    let v1284_12: Space = unite(&(v1284_7),&(v1284_11));
    v1283_15.join_into((v1284_12).clone());
  }
  drop(v1283_15_cursor);
  (v1283_15).clone()
}

fn routine_130(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1293_12 = Space::new();
  let mut v1293_12_cursor = (*s0).read_zipper();
  for v1293_12_byte in v1293_12_cursor.child_mask().iter() {
    v1293_12_cursor.descend_to_byte(v1293_12_byte);
    let v1293_12_tail = v1293_12_cursor.make_map();
    v1293_12_cursor.ascend(1);
    let v1293_12_head = Path::from_slice(&[v1293_12_byte]);
    let v1294_2: Space = singleton(&(v1293_12_head));
    let v1294_3: Space = intersect(&(*CONSTANT_7),&(v1294_2));
    let v1294_4: Space = if has_head(&(v1294_3)) { singleton(&[]) } else { Space::new() };
    drop(v1294_3);
    let v1294_5: Space = subtract(&(*CONSTANT_0),&(v1294_4));
    drop(v1294_4);
    let v1294_8: Space = if (v1294_5).is_empty() { Space::new() } else {
      let v1295_6: Path = concat_path(&(*p0),&(v1293_12_head));
      let v1295_7: Space = routine_130(c, &(v1295_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v1293_12_tail));
      compose(&(v1294_5),&(v1295_7))
    };
    drop(v1294_5);
    let v1294_9: Space = intersect(&(*CONSTANT_7),&(v1294_2));
    drop(v1294_2);
    let v1294_10: Space = if has_head(&(v1294_9)) { singleton(&[]) } else { Space::new() };
    drop(v1294_9);
    let v1294_12: Space = if (v1294_10).is_empty() { Space::new() } else {
      let v1296_6: Path = concat_path(&(*p0),&(v1293_12_head));
      let mut v1296_11 = Space::new();
      let mut v1296_11_cursor = (v1293_12_tail).read_zipper();
      for v1296_11_byte in v1296_11_cursor.child_mask().iter() {
        v1296_11_cursor.descend_to_byte(v1296_11_byte);
        let v1296_11_tail = v1296_11_cursor.make_map();
        v1296_11_cursor.ascend(1);
        let v1296_11_head = Path::from_slice(&[v1296_11_byte]);
        let v1297_2: Space = singleton(&(v1296_11_head));
        let v1297_3: Space = intersect(&(*CONSTANT_7),&(v1297_2));
        let v1297_4: Space = if has_head(&(v1297_3)) { singleton(&[]) } else { Space::new() };
        drop(v1297_3);
        let v1297_5: Space = subtract(&(*CONSTANT_0),&(v1297_4));
        drop(v1297_4);
        let v1297_7: Space = if (v1297_5).is_empty() { Space::new() } else {
          let v1298_6: Space = routine_152(c, &(v1296_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1296_6), &(v1296_11_tail));
          compose(&(v1297_5),&(v1298_6))
        };
        drop(v1297_5);
        let v1297_8: Space = intersect(&(*CONSTANT_7),&(v1297_2));
        drop(v1297_2);
        let v1297_9: Space = if has_head(&(v1297_8)) { singleton(&[]) } else { Space::new() };
        drop(v1297_8);
        let v1297_11: Space = if (v1297_9).is_empty() { Space::new() } else {
          let v1299_10: Space = routine_153(c, &(v1296_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1296_6), &(v1296_11_tail));
          compose(&(v1297_9),&(v1299_10))
        };
        drop(v1297_9);
        let v1297_12: Space = unite(&(v1297_7),&(v1297_11));
        v1296_11.join_into((v1297_12).clone());
      }
      drop(v1296_11_cursor);
      drop(v1296_6);
      compose(&(v1294_10),&(v1296_11))
    };
    drop(v1294_10);
    let v1294_13: Space = unite(&(v1294_8),&(v1294_12));
    v1293_12.join_into((v1294_13).clone());
  }
  drop(v1293_12_cursor);
  (v1293_12).clone()
}

fn routine_131(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1300_15 = Space::new();
  let mut v1300_15_cursor = (*s0).read_zipper();
  for v1300_15_byte in v1300_15_cursor.child_mask().iter() {
    v1300_15_cursor.descend_to_byte(v1300_15_byte);
    let v1300_15_tail = v1300_15_cursor.make_map();
    v1300_15_cursor.ascend(1);
    let v1300_15_head = Path::from_slice(&[v1300_15_byte]);
    let v1301_2: Space = singleton(&(v1300_15_head));
    let v1301_3: Space = intersect(&(*CONSTANT_7),&(v1301_2));
    let v1301_4: Space = if has_head(&(v1301_3)) { singleton(&[]) } else { Space::new() };
    drop(v1301_3);
    let v1301_5: Space = subtract(&(*CONSTANT_0),&(v1301_4));
    drop(v1301_4);
    let v1301_7: Space = if (v1301_5).is_empty() { Space::new() } else {
      let mut v1302_6 = Space::new();
      let mut v1302_6_cursor = (v1300_15_tail).read_zipper();
      for v1302_6_byte in v1302_6_cursor.child_mask().iter() {
        v1302_6_cursor.descend_to_byte(v1302_6_byte);
        let v1302_6_tail = v1302_6_cursor.make_map();
        v1302_6_cursor.ascend(1);
        let v1302_6_head = Path::from_slice(&[v1302_6_byte]);
        let v1303_2: Space = singleton(&(v1302_6_head));
        let v1303_3: Space = intersect(&(*CONSTANT_7),&(v1303_2));
        let v1303_4: Space = if has_head(&(v1303_3)) { singleton(&[]) } else { Space::new() };
        drop(v1303_3);
        let v1303_5: Space = subtract(&(*CONSTANT_0),&(v1303_4));
        drop(v1303_4);
        let v1303_8: Space = if (v1303_5).is_empty() { Space::new() } else {
          let v1304_6: Path = concat_path(&(v1300_15_head),&(v1302_6_head));
          let v1304_7: Space = routine_152(c, &(v1304_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1302_6_tail));
          compose(&(v1303_5),&(v1304_7))
        };
        drop(v1303_5);
        let v1303_9: Space = intersect(&(*CONSTANT_7),&(v1303_2));
        drop(v1303_2);
        let v1303_10: Space = if has_head(&(v1303_9)) { singleton(&[]) } else { Space::new() };
        drop(v1303_9);
        let v1303_12: Space = if (v1303_10).is_empty() { Space::new() } else {
          let v1305_6: Path = concat_path(&(v1300_15_head),&(v1302_6_head));
          let v1305_11: Space = routine_153(c, &(v1305_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1302_6_tail));
          drop(v1305_6);
          compose(&(v1303_10),&(v1305_11))
        };
        drop(v1303_10);
        let v1303_13: Space = unite(&(v1303_8),&(v1303_12));
        v1302_6.join_into((v1303_13).clone());
      }
      drop(v1302_6_cursor);
      compose(&(v1301_5),&(v1302_6))
    };
    drop(v1301_5);
    let v1301_8: Space = intersect(&(*CONSTANT_7),&(v1301_2));
    drop(v1301_2);
    let v1301_9: Space = if has_head(&(v1301_8)) { singleton(&[]) } else { Space::new() };
    drop(v1301_8);
    let v1301_11: Space = if (v1301_9).is_empty() { Space::new() } else {
      let mut v1306_10 = Space::new();
      let mut v1306_10_cursor = (v1300_15_tail).read_zipper();
      for v1306_10_byte in v1306_10_cursor.child_mask().iter() {
        v1306_10_cursor.descend_to_byte(v1306_10_byte);
        let v1306_10_tail = v1306_10_cursor.make_map();
        v1306_10_cursor.ascend(1);
        let v1306_10_head = Path::from_slice(&[v1306_10_byte]);
        let v1307_2: Space = singleton(&(v1306_10_head));
        let v1307_3: Space = intersect(&(*CONSTANT_7),&(v1307_2));
        let v1307_4: Space = if has_head(&(v1307_3)) { singleton(&[]) } else { Space::new() };
        drop(v1307_3);
        let v1307_5: Space = subtract(&(*CONSTANT_0),&(v1307_4));
        drop(v1307_4);
        let v1307_7: Space = if (v1307_5).is_empty() { Space::new() } else {
          let v1308_6: Space = routine_170(c, &(v1306_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1300_15_head), &(v1306_10_tail));
          compose(&(v1307_5),&(v1308_6))
        };
        drop(v1307_5);
        let v1307_8: Space = intersect(&(*CONSTANT_7),&(v1307_2));
        drop(v1307_2);
        let v1307_9: Space = if has_head(&(v1307_8)) { singleton(&[]) } else { Space::new() };
        drop(v1307_8);
        let v1307_11: Space = if (v1307_9).is_empty() { Space::new() } else {
          let v1309_10: Space = routine_171(c, &(v1306_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1300_15_head), &(v1306_10_tail));
          compose(&(v1307_9),&(v1309_10))
        };
        drop(v1307_9);
        let v1307_12: Space = unite(&(v1307_7),&(v1307_11));
        v1306_10.join_into((v1307_12).clone());
      }
      drop(v1306_10_cursor);
      compose(&(v1301_9),&(v1306_10))
    };
    drop(v1301_9);
    let v1301_12: Space = unite(&(v1301_7),&(v1301_11));
    v1300_15.join_into((v1301_12).clone());
  }
  drop(v1300_15_cursor);
  (v1300_15).clone()
}

fn routine_132(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1310_12 = Space::new();
  let mut v1310_12_cursor = (*s0).read_zipper();
  for v1310_12_byte in v1310_12_cursor.child_mask().iter() {
    v1310_12_cursor.descend_to_byte(v1310_12_byte);
    let v1310_12_tail = v1310_12_cursor.make_map();
    v1310_12_cursor.ascend(1);
    let v1310_12_head = Path::from_slice(&[v1310_12_byte]);
    let v1311_2: Space = singleton(&(v1310_12_head));
    let v1311_3: Space = intersect(&(*CONSTANT_7),&(v1311_2));
    let v1311_4: Space = if has_head(&(v1311_3)) { singleton(&[]) } else { Space::new() };
    drop(v1311_3);
    let v1311_5: Space = subtract(&(*CONSTANT_0),&(v1311_4));
    drop(v1311_4);
    let v1311_8: Space = if (v1311_5).is_empty() { Space::new() } else {
      let v1312_6: Path = concat_path(&(*p0),&(v1310_12_head));
      let v1312_7: Space = routine_132(c, &(v1312_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v1310_12_tail));
      compose(&(v1311_5),&(v1312_7))
    };
    drop(v1311_5);
    let v1311_9: Space = intersect(&(*CONSTANT_7),&(v1311_2));
    drop(v1311_2);
    let v1311_10: Space = if has_head(&(v1311_9)) { singleton(&[]) } else { Space::new() };
    drop(v1311_9);
    let v1311_12: Space = if (v1311_10).is_empty() { Space::new() } else {
      let v1313_6: Path = concat_path(&(*p0),&(v1310_12_head));
      let mut v1313_11 = Space::new();
      let mut v1313_11_cursor = (v1310_12_tail).read_zipper();
      for v1313_11_byte in v1313_11_cursor.child_mask().iter() {
        v1313_11_cursor.descend_to_byte(v1313_11_byte);
        let v1313_11_tail = v1313_11_cursor.make_map();
        v1313_11_cursor.ascend(1);
        let v1313_11_head = Path::from_slice(&[v1313_11_byte]);
        let v1314_2: Space = singleton(&(v1313_11_head));
        let v1314_3: Space = intersect(&(*CONSTANT_7),&(v1314_2));
        let v1314_4: Space = if has_head(&(v1314_3)) { singleton(&[]) } else { Space::new() };
        drop(v1314_3);
        let v1314_5: Space = subtract(&(*CONSTANT_0),&(v1314_4));
        drop(v1314_4);
        let v1314_7: Space = if (v1314_5).is_empty() { Space::new() } else {
          let v1315_6: Space = routine_154(c, &(v1313_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1313_6), &(v1313_11_tail));
          compose(&(v1314_5),&(v1315_6))
        };
        drop(v1314_5);
        let v1314_8: Space = intersect(&(*CONSTANT_7),&(v1314_2));
        drop(v1314_2);
        let v1314_9: Space = if has_head(&(v1314_8)) { singleton(&[]) } else { Space::new() };
        drop(v1314_8);
        let v1314_11: Space = if (v1314_9).is_empty() { Space::new() } else {
          let v1316_10: Space = routine_155(c, &(v1313_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1313_6), &(v1313_11_tail));
          compose(&(v1314_9),&(v1316_10))
        };
        drop(v1314_9);
        let v1314_12: Space = unite(&(v1314_7),&(v1314_11));
        v1313_11.join_into((v1314_12).clone());
      }
      drop(v1313_11_cursor);
      drop(v1313_6);
      compose(&(v1311_10),&(v1313_11))
    };
    drop(v1311_10);
    let v1311_13: Space = unite(&(v1311_8),&(v1311_12));
    v1310_12.join_into((v1311_13).clone());
  }
  drop(v1310_12_cursor);
  (v1310_12).clone()
}

fn routine_133(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1317_15 = Space::new();
  let mut v1317_15_cursor = (*s0).read_zipper();
  for v1317_15_byte in v1317_15_cursor.child_mask().iter() {
    v1317_15_cursor.descend_to_byte(v1317_15_byte);
    let v1317_15_tail = v1317_15_cursor.make_map();
    v1317_15_cursor.ascend(1);
    let v1317_15_head = Path::from_slice(&[v1317_15_byte]);
    let v1318_2: Space = singleton(&(v1317_15_head));
    let v1318_3: Space = intersect(&(*CONSTANT_7),&(v1318_2));
    let v1318_4: Space = if has_head(&(v1318_3)) { singleton(&[]) } else { Space::new() };
    drop(v1318_3);
    let v1318_5: Space = subtract(&(*CONSTANT_0),&(v1318_4));
    drop(v1318_4);
    let v1318_7: Space = if (v1318_5).is_empty() { Space::new() } else {
      let mut v1319_6 = Space::new();
      let mut v1319_6_cursor = (v1317_15_tail).read_zipper();
      for v1319_6_byte in v1319_6_cursor.child_mask().iter() {
        v1319_6_cursor.descend_to_byte(v1319_6_byte);
        let v1319_6_tail = v1319_6_cursor.make_map();
        v1319_6_cursor.ascend(1);
        let v1319_6_head = Path::from_slice(&[v1319_6_byte]);
        let v1320_2: Space = singleton(&(v1319_6_head));
        let v1320_3: Space = intersect(&(*CONSTANT_7),&(v1320_2));
        let v1320_4: Space = if has_head(&(v1320_3)) { singleton(&[]) } else { Space::new() };
        drop(v1320_3);
        let v1320_5: Space = subtract(&(*CONSTANT_0),&(v1320_4));
        drop(v1320_4);
        let v1320_8: Space = if (v1320_5).is_empty() { Space::new() } else {
          let v1321_6: Path = concat_path(&(v1317_15_head),&(v1319_6_head));
          let v1321_7: Space = routine_154(c, &(v1321_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1319_6_tail));
          compose(&(v1320_5),&(v1321_7))
        };
        drop(v1320_5);
        let v1320_9: Space = intersect(&(*CONSTANT_7),&(v1320_2));
        drop(v1320_2);
        let v1320_10: Space = if has_head(&(v1320_9)) { singleton(&[]) } else { Space::new() };
        drop(v1320_9);
        let v1320_12: Space = if (v1320_10).is_empty() { Space::new() } else {
          let v1322_6: Path = concat_path(&(v1317_15_head),&(v1319_6_head));
          let v1322_11: Space = routine_155(c, &(v1322_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1319_6_tail));
          drop(v1322_6);
          compose(&(v1320_10),&(v1322_11))
        };
        drop(v1320_10);
        let v1320_13: Space = unite(&(v1320_8),&(v1320_12));
        v1319_6.join_into((v1320_13).clone());
      }
      drop(v1319_6_cursor);
      compose(&(v1318_5),&(v1319_6))
    };
    drop(v1318_5);
    let v1318_8: Space = intersect(&(*CONSTANT_7),&(v1318_2));
    drop(v1318_2);
    let v1318_9: Space = if has_head(&(v1318_8)) { singleton(&[]) } else { Space::new() };
    drop(v1318_8);
    let v1318_11: Space = if (v1318_9).is_empty() { Space::new() } else {
      let mut v1323_10 = Space::new();
      let mut v1323_10_cursor = (v1317_15_tail).read_zipper();
      for v1323_10_byte in v1323_10_cursor.child_mask().iter() {
        v1323_10_cursor.descend_to_byte(v1323_10_byte);
        let v1323_10_tail = v1323_10_cursor.make_map();
        v1323_10_cursor.ascend(1);
        let v1323_10_head = Path::from_slice(&[v1323_10_byte]);
        let v1324_2: Space = singleton(&(v1323_10_head));
        let v1324_3: Space = intersect(&(*CONSTANT_7),&(v1324_2));
        let v1324_4: Space = if has_head(&(v1324_3)) { singleton(&[]) } else { Space::new() };
        drop(v1324_3);
        let v1324_5: Space = subtract(&(*CONSTANT_0),&(v1324_4));
        drop(v1324_4);
        let v1324_7: Space = if (v1324_5).is_empty() { Space::new() } else {
          let v1325_6: Space = routine_172(c, &(v1323_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1317_15_head), &(v1323_10_tail));
          compose(&(v1324_5),&(v1325_6))
        };
        drop(v1324_5);
        let v1324_8: Space = intersect(&(*CONSTANT_7),&(v1324_2));
        drop(v1324_2);
        let v1324_9: Space = if has_head(&(v1324_8)) { singleton(&[]) } else { Space::new() };
        drop(v1324_8);
        let v1324_11: Space = if (v1324_9).is_empty() { Space::new() } else {
          let v1326_10: Space = routine_173(c, &(v1323_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1317_15_head), &(v1323_10_tail));
          compose(&(v1324_9),&(v1326_10))
        };
        drop(v1324_9);
        let v1324_12: Space = unite(&(v1324_7),&(v1324_11));
        v1323_10.join_into((v1324_12).clone());
      }
      drop(v1323_10_cursor);
      compose(&(v1318_9),&(v1323_10))
    };
    drop(v1318_9);
    let v1318_12: Space = unite(&(v1318_7),&(v1318_11));
    v1317_15.join_into((v1318_12).clone());
  }
  drop(v1317_15_cursor);
  (v1317_15).clone()
}

fn routine_134(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1327_12 = Space::new();
  let mut v1327_12_cursor = (*s0).read_zipper();
  for v1327_12_byte in v1327_12_cursor.child_mask().iter() {
    v1327_12_cursor.descend_to_byte(v1327_12_byte);
    let v1327_12_tail = v1327_12_cursor.make_map();
    v1327_12_cursor.ascend(1);
    let v1327_12_head = Path::from_slice(&[v1327_12_byte]);
    let v1328_2: Space = singleton(&(v1327_12_head));
    let v1328_3: Space = intersect(&(*CONSTANT_7),&(v1328_2));
    let v1328_4: Space = if has_head(&(v1328_3)) { singleton(&[]) } else { Space::new() };
    drop(v1328_3);
    let v1328_5: Space = subtract(&(*CONSTANT_0),&(v1328_4));
    drop(v1328_4);
    let v1328_8: Space = if (v1328_5).is_empty() { Space::new() } else {
      let v1329_6: Path = concat_path(&(*p0),&(v1327_12_head));
      let v1329_7: Space = routine_134(c, &(v1329_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v1327_12_tail));
      compose(&(v1328_5),&(v1329_7))
    };
    drop(v1328_5);
    let v1328_9: Space = intersect(&(*CONSTANT_7),&(v1328_2));
    drop(v1328_2);
    let v1328_10: Space = if has_head(&(v1328_9)) { singleton(&[]) } else { Space::new() };
    drop(v1328_9);
    let v1328_12: Space = if (v1328_10).is_empty() { Space::new() } else {
      let v1330_6: Path = concat_path(&(*p0),&(v1327_12_head));
      let mut v1330_11 = Space::new();
      let mut v1330_11_cursor = (v1327_12_tail).read_zipper();
      for v1330_11_byte in v1330_11_cursor.child_mask().iter() {
        v1330_11_cursor.descend_to_byte(v1330_11_byte);
        let v1330_11_tail = v1330_11_cursor.make_map();
        v1330_11_cursor.ascend(1);
        let v1330_11_head = Path::from_slice(&[v1330_11_byte]);
        let v1331_2: Space = singleton(&(v1330_11_head));
        let v1331_3: Space = intersect(&(*CONSTANT_7),&(v1331_2));
        let v1331_4: Space = if has_head(&(v1331_3)) { singleton(&[]) } else { Space::new() };
        drop(v1331_3);
        let v1331_5: Space = subtract(&(*CONSTANT_0),&(v1331_4));
        drop(v1331_4);
        let v1331_7: Space = if (v1331_5).is_empty() { Space::new() } else {
          let v1332_6: Space = routine_156(c, &(v1330_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1330_6), &(v1330_11_tail));
          compose(&(v1331_5),&(v1332_6))
        };
        drop(v1331_5);
        let v1331_8: Space = intersect(&(*CONSTANT_7),&(v1331_2));
        drop(v1331_2);
        let v1331_9: Space = if has_head(&(v1331_8)) { singleton(&[]) } else { Space::new() };
        drop(v1331_8);
        let v1331_11: Space = if (v1331_9).is_empty() { Space::new() } else {
          let v1333_10: Space = routine_157(c, &(v1330_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1330_6), &(v1330_11_tail));
          compose(&(v1331_9),&(v1333_10))
        };
        drop(v1331_9);
        let v1331_12: Space = unite(&(v1331_7),&(v1331_11));
        v1330_11.join_into((v1331_12).clone());
      }
      drop(v1330_11_cursor);
      drop(v1330_6);
      compose(&(v1328_10),&(v1330_11))
    };
    drop(v1328_10);
    let v1328_13: Space = unite(&(v1328_8),&(v1328_12));
    v1327_12.join_into((v1328_13).clone());
  }
  drop(v1327_12_cursor);
  (v1327_12).clone()
}

fn routine_135(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1334_15 = Space::new();
  let mut v1334_15_cursor = (*s0).read_zipper();
  for v1334_15_byte in v1334_15_cursor.child_mask().iter() {
    v1334_15_cursor.descend_to_byte(v1334_15_byte);
    let v1334_15_tail = v1334_15_cursor.make_map();
    v1334_15_cursor.ascend(1);
    let v1334_15_head = Path::from_slice(&[v1334_15_byte]);
    let v1335_2: Space = singleton(&(v1334_15_head));
    let v1335_3: Space = intersect(&(*CONSTANT_7),&(v1335_2));
    let v1335_4: Space = if has_head(&(v1335_3)) { singleton(&[]) } else { Space::new() };
    drop(v1335_3);
    let v1335_5: Space = subtract(&(*CONSTANT_0),&(v1335_4));
    drop(v1335_4);
    let v1335_7: Space = if (v1335_5).is_empty() { Space::new() } else {
      let mut v1336_6 = Space::new();
      let mut v1336_6_cursor = (v1334_15_tail).read_zipper();
      for v1336_6_byte in v1336_6_cursor.child_mask().iter() {
        v1336_6_cursor.descend_to_byte(v1336_6_byte);
        let v1336_6_tail = v1336_6_cursor.make_map();
        v1336_6_cursor.ascend(1);
        let v1336_6_head = Path::from_slice(&[v1336_6_byte]);
        let v1337_2: Space = singleton(&(v1336_6_head));
        let v1337_3: Space = intersect(&(*CONSTANT_7),&(v1337_2));
        let v1337_4: Space = if has_head(&(v1337_3)) { singleton(&[]) } else { Space::new() };
        drop(v1337_3);
        let v1337_5: Space = subtract(&(*CONSTANT_0),&(v1337_4));
        drop(v1337_4);
        let v1337_8: Space = if (v1337_5).is_empty() { Space::new() } else {
          let v1338_6: Path = concat_path(&(v1334_15_head),&(v1336_6_head));
          let v1338_7: Space = routine_156(c, &(v1338_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1336_6_tail));
          compose(&(v1337_5),&(v1338_7))
        };
        drop(v1337_5);
        let v1337_9: Space = intersect(&(*CONSTANT_7),&(v1337_2));
        drop(v1337_2);
        let v1337_10: Space = if has_head(&(v1337_9)) { singleton(&[]) } else { Space::new() };
        drop(v1337_9);
        let v1337_12: Space = if (v1337_10).is_empty() { Space::new() } else {
          let v1339_6: Path = concat_path(&(v1334_15_head),&(v1336_6_head));
          let v1339_11: Space = routine_157(c, &(v1339_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1336_6_tail));
          drop(v1339_6);
          compose(&(v1337_10),&(v1339_11))
        };
        drop(v1337_10);
        let v1337_13: Space = unite(&(v1337_8),&(v1337_12));
        v1336_6.join_into((v1337_13).clone());
      }
      drop(v1336_6_cursor);
      compose(&(v1335_5),&(v1336_6))
    };
    drop(v1335_5);
    let v1335_8: Space = intersect(&(*CONSTANT_7),&(v1335_2));
    drop(v1335_2);
    let v1335_9: Space = if has_head(&(v1335_8)) { singleton(&[]) } else { Space::new() };
    drop(v1335_8);
    let v1335_11: Space = if (v1335_9).is_empty() { Space::new() } else {
      let mut v1340_10 = Space::new();
      let mut v1340_10_cursor = (v1334_15_tail).read_zipper();
      for v1340_10_byte in v1340_10_cursor.child_mask().iter() {
        v1340_10_cursor.descend_to_byte(v1340_10_byte);
        let v1340_10_tail = v1340_10_cursor.make_map();
        v1340_10_cursor.ascend(1);
        let v1340_10_head = Path::from_slice(&[v1340_10_byte]);
        let v1341_2: Space = singleton(&(v1340_10_head));
        let v1341_3: Space = intersect(&(*CONSTANT_7),&(v1341_2));
        let v1341_4: Space = if has_head(&(v1341_3)) { singleton(&[]) } else { Space::new() };
        drop(v1341_3);
        let v1341_5: Space = subtract(&(*CONSTANT_0),&(v1341_4));
        drop(v1341_4);
        let v1341_7: Space = if (v1341_5).is_empty() { Space::new() } else {
          let v1342_6: Space = routine_174(c, &(v1340_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1334_15_head), &(v1340_10_tail));
          compose(&(v1341_5),&(v1342_6))
        };
        drop(v1341_5);
        let v1341_8: Space = intersect(&(*CONSTANT_7),&(v1341_2));
        drop(v1341_2);
        let v1341_9: Space = if has_head(&(v1341_8)) { singleton(&[]) } else { Space::new() };
        drop(v1341_8);
        let v1341_11: Space = if (v1341_9).is_empty() { Space::new() } else {
          let v1343_10: Space = routine_175(c, &(v1340_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1334_15_head), &(v1340_10_tail));
          compose(&(v1341_9),&(v1343_10))
        };
        drop(v1341_9);
        let v1341_12: Space = unite(&(v1341_7),&(v1341_11));
        v1340_10.join_into((v1341_12).clone());
      }
      drop(v1340_10_cursor);
      compose(&(v1335_9),&(v1340_10))
    };
    drop(v1335_9);
    let v1335_12: Space = unite(&(v1335_7),&(v1335_11));
    v1334_15.join_into((v1335_12).clone());
  }
  drop(v1334_15_cursor);
  (v1334_15).clone()
}

fn routine_136(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1344_12 = Space::new();
  let mut v1344_12_cursor = (*s0).read_zipper();
  for v1344_12_byte in v1344_12_cursor.child_mask().iter() {
    v1344_12_cursor.descend_to_byte(v1344_12_byte);
    let v1344_12_tail = v1344_12_cursor.make_map();
    v1344_12_cursor.ascend(1);
    let v1344_12_head = Path::from_slice(&[v1344_12_byte]);
    let v1345_2: Space = singleton(&(v1344_12_head));
    let v1345_3: Space = intersect(&(*CONSTANT_7),&(v1345_2));
    let v1345_4: Space = if has_head(&(v1345_3)) { singleton(&[]) } else { Space::new() };
    drop(v1345_3);
    let v1345_5: Space = subtract(&(*CONSTANT_0),&(v1345_4));
    drop(v1345_4);
    let v1345_8: Space = if (v1345_5).is_empty() { Space::new() } else {
      let v1346_6: Path = concat_path(&(*p0),&(v1344_12_head));
      let v1346_7: Space = routine_136(c, &(v1346_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v1344_12_tail));
      compose(&(v1345_5),&(v1346_7))
    };
    drop(v1345_5);
    let v1345_9: Space = intersect(&(*CONSTANT_7),&(v1345_2));
    drop(v1345_2);
    let v1345_10: Space = if has_head(&(v1345_9)) { singleton(&[]) } else { Space::new() };
    drop(v1345_9);
    let v1345_12: Space = if (v1345_10).is_empty() { Space::new() } else {
      let v1347_6: Path = concat_path(&(*p0),&(v1344_12_head));
      let mut v1347_11 = Space::new();
      let mut v1347_11_cursor = (v1344_12_tail).read_zipper();
      for v1347_11_byte in v1347_11_cursor.child_mask().iter() {
        v1347_11_cursor.descend_to_byte(v1347_11_byte);
        let v1347_11_tail = v1347_11_cursor.make_map();
        v1347_11_cursor.ascend(1);
        let v1347_11_head = Path::from_slice(&[v1347_11_byte]);
        let v1348_2: Space = singleton(&(v1347_11_head));
        let v1348_3: Space = intersect(&(*CONSTANT_7),&(v1348_2));
        let v1348_4: Space = if has_head(&(v1348_3)) { singleton(&[]) } else { Space::new() };
        drop(v1348_3);
        let v1348_5: Space = subtract(&(*CONSTANT_0),&(v1348_4));
        drop(v1348_4);
        let v1348_7: Space = if (v1348_5).is_empty() { Space::new() } else {
          let v1349_6: Space = routine_158(c, &(v1347_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1347_6), &(v1347_11_tail));
          compose(&(v1348_5),&(v1349_6))
        };
        drop(v1348_5);
        let v1348_8: Space = intersect(&(*CONSTANT_7),&(v1348_2));
        drop(v1348_2);
        let v1348_9: Space = if has_head(&(v1348_8)) { singleton(&[]) } else { Space::new() };
        drop(v1348_8);
        let v1348_11: Space = if (v1348_9).is_empty() { Space::new() } else {
          let v1350_10: Space = routine_159(c, &(v1347_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1347_6), &(v1347_11_tail));
          compose(&(v1348_9),&(v1350_10))
        };
        drop(v1348_9);
        let v1348_12: Space = unite(&(v1348_7),&(v1348_11));
        v1347_11.join_into((v1348_12).clone());
      }
      drop(v1347_11_cursor);
      drop(v1347_6);
      compose(&(v1345_10),&(v1347_11))
    };
    drop(v1345_10);
    let v1345_13: Space = unite(&(v1345_8),&(v1345_12));
    v1344_12.join_into((v1345_13).clone());
  }
  drop(v1344_12_cursor);
  (v1344_12).clone()
}

fn routine_137(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1351_15 = Space::new();
  let mut v1351_15_cursor = (*s0).read_zipper();
  for v1351_15_byte in v1351_15_cursor.child_mask().iter() {
    v1351_15_cursor.descend_to_byte(v1351_15_byte);
    let v1351_15_tail = v1351_15_cursor.make_map();
    v1351_15_cursor.ascend(1);
    let v1351_15_head = Path::from_slice(&[v1351_15_byte]);
    let v1352_2: Space = singleton(&(v1351_15_head));
    let v1352_3: Space = intersect(&(*CONSTANT_7),&(v1352_2));
    let v1352_4: Space = if has_head(&(v1352_3)) { singleton(&[]) } else { Space::new() };
    drop(v1352_3);
    let v1352_5: Space = subtract(&(*CONSTANT_0),&(v1352_4));
    drop(v1352_4);
    let v1352_7: Space = if (v1352_5).is_empty() { Space::new() } else {
      let mut v1353_6 = Space::new();
      let mut v1353_6_cursor = (v1351_15_tail).read_zipper();
      for v1353_6_byte in v1353_6_cursor.child_mask().iter() {
        v1353_6_cursor.descend_to_byte(v1353_6_byte);
        let v1353_6_tail = v1353_6_cursor.make_map();
        v1353_6_cursor.ascend(1);
        let v1353_6_head = Path::from_slice(&[v1353_6_byte]);
        let v1354_2: Space = singleton(&(v1353_6_head));
        let v1354_3: Space = intersect(&(*CONSTANT_7),&(v1354_2));
        let v1354_4: Space = if has_head(&(v1354_3)) { singleton(&[]) } else { Space::new() };
        drop(v1354_3);
        let v1354_5: Space = subtract(&(*CONSTANT_0),&(v1354_4));
        drop(v1354_4);
        let v1354_8: Space = if (v1354_5).is_empty() { Space::new() } else {
          let v1355_6: Path = concat_path(&(v1351_15_head),&(v1353_6_head));
          let v1355_7: Space = routine_158(c, &(v1355_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1353_6_tail));
          compose(&(v1354_5),&(v1355_7))
        };
        drop(v1354_5);
        let v1354_9: Space = intersect(&(*CONSTANT_7),&(v1354_2));
        drop(v1354_2);
        let v1354_10: Space = if has_head(&(v1354_9)) { singleton(&[]) } else { Space::new() };
        drop(v1354_9);
        let v1354_12: Space = if (v1354_10).is_empty() { Space::new() } else {
          let v1356_6: Path = concat_path(&(v1351_15_head),&(v1353_6_head));
          let v1356_11: Space = routine_159(c, &(v1356_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1353_6_tail));
          drop(v1356_6);
          compose(&(v1354_10),&(v1356_11))
        };
        drop(v1354_10);
        let v1354_13: Space = unite(&(v1354_8),&(v1354_12));
        v1353_6.join_into((v1354_13).clone());
      }
      drop(v1353_6_cursor);
      compose(&(v1352_5),&(v1353_6))
    };
    drop(v1352_5);
    let v1352_8: Space = intersect(&(*CONSTANT_7),&(v1352_2));
    drop(v1352_2);
    let v1352_9: Space = if has_head(&(v1352_8)) { singleton(&[]) } else { Space::new() };
    drop(v1352_8);
    let v1352_11: Space = if (v1352_9).is_empty() { Space::new() } else {
      let mut v1357_10 = Space::new();
      let mut v1357_10_cursor = (v1351_15_tail).read_zipper();
      for v1357_10_byte in v1357_10_cursor.child_mask().iter() {
        v1357_10_cursor.descend_to_byte(v1357_10_byte);
        let v1357_10_tail = v1357_10_cursor.make_map();
        v1357_10_cursor.ascend(1);
        let v1357_10_head = Path::from_slice(&[v1357_10_byte]);
        let v1358_2: Space = singleton(&(v1357_10_head));
        let v1358_3: Space = intersect(&(*CONSTANT_7),&(v1358_2));
        let v1358_4: Space = if has_head(&(v1358_3)) { singleton(&[]) } else { Space::new() };
        drop(v1358_3);
        let v1358_5: Space = subtract(&(*CONSTANT_0),&(v1358_4));
        drop(v1358_4);
        let v1358_7: Space = if (v1358_5).is_empty() { Space::new() } else {
          let v1359_6: Space = routine_176(c, &(v1357_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1351_15_head), &(v1357_10_tail));
          compose(&(v1358_5),&(v1359_6))
        };
        drop(v1358_5);
        let v1358_8: Space = intersect(&(*CONSTANT_7),&(v1358_2));
        drop(v1358_2);
        let v1358_9: Space = if has_head(&(v1358_8)) { singleton(&[]) } else { Space::new() };
        drop(v1358_8);
        let v1358_11: Space = if (v1358_9).is_empty() { Space::new() } else {
          let v1360_10: Space = routine_177(c, &(v1357_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1351_15_head), &(v1357_10_tail));
          compose(&(v1358_9),&(v1360_10))
        };
        drop(v1358_9);
        let v1358_12: Space = unite(&(v1358_7),&(v1358_11));
        v1357_10.join_into((v1358_12).clone());
      }
      drop(v1357_10_cursor);
      compose(&(v1352_9),&(v1357_10))
    };
    drop(v1352_9);
    let v1352_12: Space = unite(&(v1352_7),&(v1352_11));
    v1351_15.join_into((v1352_12).clone());
  }
  drop(v1351_15_cursor);
  (v1351_15).clone()
}

fn routine_138(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1361_12 = Space::new();
  let mut v1361_12_cursor = (*s0).read_zipper();
  for v1361_12_byte in v1361_12_cursor.child_mask().iter() {
    v1361_12_cursor.descend_to_byte(v1361_12_byte);
    let v1361_12_tail = v1361_12_cursor.make_map();
    v1361_12_cursor.ascend(1);
    let v1361_12_head = Path::from_slice(&[v1361_12_byte]);
    let v1362_2: Space = singleton(&(v1361_12_head));
    let v1362_3: Space = intersect(&(*CONSTANT_7),&(v1362_2));
    let v1362_4: Space = if has_head(&(v1362_3)) { singleton(&[]) } else { Space::new() };
    drop(v1362_3);
    let v1362_5: Space = subtract(&(*CONSTANT_0),&(v1362_4));
    drop(v1362_4);
    let v1362_8: Space = if (v1362_5).is_empty() { Space::new() } else {
      let v1363_6: Path = concat_path(&(*p0),&(v1361_12_head));
      let v1363_7: Space = routine_138(c, &(v1363_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v1361_12_tail));
      compose(&(v1362_5),&(v1363_7))
    };
    drop(v1362_5);
    let v1362_9: Space = intersect(&(*CONSTANT_7),&(v1362_2));
    drop(v1362_2);
    let v1362_10: Space = if has_head(&(v1362_9)) { singleton(&[]) } else { Space::new() };
    drop(v1362_9);
    let v1362_12: Space = if (v1362_10).is_empty() { Space::new() } else {
      let v1364_6: Path = concat_path(&(*p0),&(v1361_12_head));
      let mut v1364_11 = Space::new();
      let mut v1364_11_cursor = (v1361_12_tail).read_zipper();
      for v1364_11_byte in v1364_11_cursor.child_mask().iter() {
        v1364_11_cursor.descend_to_byte(v1364_11_byte);
        let v1364_11_tail = v1364_11_cursor.make_map();
        v1364_11_cursor.ascend(1);
        let v1364_11_head = Path::from_slice(&[v1364_11_byte]);
        let v1365_2: Space = singleton(&(v1364_11_head));
        let v1365_3: Space = intersect(&(*CONSTANT_7),&(v1365_2));
        let v1365_4: Space = if has_head(&(v1365_3)) { singleton(&[]) } else { Space::new() };
        drop(v1365_3);
        let v1365_5: Space = subtract(&(*CONSTANT_0),&(v1365_4));
        drop(v1365_4);
        let v1365_7: Space = if (v1365_5).is_empty() { Space::new() } else {
          let v1366_6: Space = routine_160(c, &(v1364_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1364_6), &(v1364_11_tail));
          compose(&(v1365_5),&(v1366_6))
        };
        drop(v1365_5);
        let v1365_8: Space = intersect(&(*CONSTANT_7),&(v1365_2));
        drop(v1365_2);
        let v1365_9: Space = if has_head(&(v1365_8)) { singleton(&[]) } else { Space::new() };
        drop(v1365_8);
        let v1365_11: Space = if (v1365_9).is_empty() { Space::new() } else {
          let v1367_10: Space = routine_161(c, &(v1364_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1364_6), &(v1364_11_tail));
          compose(&(v1365_9),&(v1367_10))
        };
        drop(v1365_9);
        let v1365_12: Space = unite(&(v1365_7),&(v1365_11));
        v1364_11.join_into((v1365_12).clone());
      }
      drop(v1364_11_cursor);
      drop(v1364_6);
      compose(&(v1362_10),&(v1364_11))
    };
    drop(v1362_10);
    let v1362_13: Space = unite(&(v1362_8),&(v1362_12));
    v1361_12.join_into((v1362_13).clone());
  }
  drop(v1361_12_cursor);
  (v1361_12).clone()
}

fn routine_139(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1368_15 = Space::new();
  let mut v1368_15_cursor = (*s0).read_zipper();
  for v1368_15_byte in v1368_15_cursor.child_mask().iter() {
    v1368_15_cursor.descend_to_byte(v1368_15_byte);
    let v1368_15_tail = v1368_15_cursor.make_map();
    v1368_15_cursor.ascend(1);
    let v1368_15_head = Path::from_slice(&[v1368_15_byte]);
    let v1369_2: Space = singleton(&(v1368_15_head));
    let v1369_3: Space = intersect(&(*CONSTANT_7),&(v1369_2));
    let v1369_4: Space = if has_head(&(v1369_3)) { singleton(&[]) } else { Space::new() };
    drop(v1369_3);
    let v1369_5: Space = subtract(&(*CONSTANT_0),&(v1369_4));
    drop(v1369_4);
    let v1369_7: Space = if (v1369_5).is_empty() { Space::new() } else {
      let mut v1370_6 = Space::new();
      let mut v1370_6_cursor = (v1368_15_tail).read_zipper();
      for v1370_6_byte in v1370_6_cursor.child_mask().iter() {
        v1370_6_cursor.descend_to_byte(v1370_6_byte);
        let v1370_6_tail = v1370_6_cursor.make_map();
        v1370_6_cursor.ascend(1);
        let v1370_6_head = Path::from_slice(&[v1370_6_byte]);
        let v1371_2: Space = singleton(&(v1370_6_head));
        let v1371_3: Space = intersect(&(*CONSTANT_7),&(v1371_2));
        let v1371_4: Space = if has_head(&(v1371_3)) { singleton(&[]) } else { Space::new() };
        drop(v1371_3);
        let v1371_5: Space = subtract(&(*CONSTANT_0),&(v1371_4));
        drop(v1371_4);
        let v1371_8: Space = if (v1371_5).is_empty() { Space::new() } else {
          let v1372_6: Path = concat_path(&(v1368_15_head),&(v1370_6_head));
          let v1372_7: Space = routine_160(c, &(v1372_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1370_6_tail));
          compose(&(v1371_5),&(v1372_7))
        };
        drop(v1371_5);
        let v1371_9: Space = intersect(&(*CONSTANT_7),&(v1371_2));
        drop(v1371_2);
        let v1371_10: Space = if has_head(&(v1371_9)) { singleton(&[]) } else { Space::new() };
        drop(v1371_9);
        let v1371_12: Space = if (v1371_10).is_empty() { Space::new() } else {
          let v1373_6: Path = concat_path(&(v1368_15_head),&(v1370_6_head));
          let v1373_11: Space = routine_161(c, &(v1373_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1370_6_tail));
          drop(v1373_6);
          compose(&(v1371_10),&(v1373_11))
        };
        drop(v1371_10);
        let v1371_13: Space = unite(&(v1371_8),&(v1371_12));
        v1370_6.join_into((v1371_13).clone());
      }
      drop(v1370_6_cursor);
      compose(&(v1369_5),&(v1370_6))
    };
    drop(v1369_5);
    let v1369_8: Space = intersect(&(*CONSTANT_7),&(v1369_2));
    drop(v1369_2);
    let v1369_9: Space = if has_head(&(v1369_8)) { singleton(&[]) } else { Space::new() };
    drop(v1369_8);
    let v1369_11: Space = if (v1369_9).is_empty() { Space::new() } else {
      let mut v1374_10 = Space::new();
      let mut v1374_10_cursor = (v1368_15_tail).read_zipper();
      for v1374_10_byte in v1374_10_cursor.child_mask().iter() {
        v1374_10_cursor.descend_to_byte(v1374_10_byte);
        let v1374_10_tail = v1374_10_cursor.make_map();
        v1374_10_cursor.ascend(1);
        let v1374_10_head = Path::from_slice(&[v1374_10_byte]);
        let v1375_2: Space = singleton(&(v1374_10_head));
        let v1375_3: Space = intersect(&(*CONSTANT_7),&(v1375_2));
        let v1375_4: Space = if has_head(&(v1375_3)) { singleton(&[]) } else { Space::new() };
        drop(v1375_3);
        let v1375_5: Space = subtract(&(*CONSTANT_0),&(v1375_4));
        drop(v1375_4);
        let v1375_7: Space = if (v1375_5).is_empty() { Space::new() } else {
          let v1376_6: Space = routine_178(c, &(v1374_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1368_15_head), &(v1374_10_tail));
          compose(&(v1375_5),&(v1376_6))
        };
        drop(v1375_5);
        let v1375_8: Space = intersect(&(*CONSTANT_7),&(v1375_2));
        drop(v1375_2);
        let v1375_9: Space = if has_head(&(v1375_8)) { singleton(&[]) } else { Space::new() };
        drop(v1375_8);
        let v1375_11: Space = if (v1375_9).is_empty() { Space::new() } else {
          let v1377_10: Space = routine_179(c, &(v1374_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1368_15_head), &(v1374_10_tail));
          compose(&(v1375_9),&(v1377_10))
        };
        drop(v1375_9);
        let v1375_12: Space = unite(&(v1375_7),&(v1375_11));
        v1374_10.join_into((v1375_12).clone());
      }
      drop(v1374_10_cursor);
      compose(&(v1369_9),&(v1374_10))
    };
    drop(v1369_9);
    let v1369_12: Space = unite(&(v1369_7),&(v1369_11));
    v1368_15.join_into((v1369_12).clone());
  }
  drop(v1368_15_cursor);
  (v1368_15).clone()
}

fn routine_140(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1378_12 = Space::new();
  let mut v1378_12_cursor = (*s0).read_zipper();
  for v1378_12_byte in v1378_12_cursor.child_mask().iter() {
    v1378_12_cursor.descend_to_byte(v1378_12_byte);
    let v1378_12_tail = v1378_12_cursor.make_map();
    v1378_12_cursor.ascend(1);
    let v1378_12_head = Path::from_slice(&[v1378_12_byte]);
    let v1379_2: Space = singleton(&(v1378_12_head));
    let v1379_3: Space = intersect(&(*CONSTANT_7),&(v1379_2));
    let v1379_4: Space = if has_head(&(v1379_3)) { singleton(&[]) } else { Space::new() };
    drop(v1379_3);
    let v1379_5: Space = subtract(&(*CONSTANT_0),&(v1379_4));
    drop(v1379_4);
    let v1379_8: Space = if (v1379_5).is_empty() { Space::new() } else {
      let v1380_6: Path = concat_path(&(*p0),&(v1378_12_head));
      let v1380_7: Space = routine_140(c, &(v1380_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v1378_12_tail));
      compose(&(v1379_5),&(v1380_7))
    };
    drop(v1379_5);
    let v1379_9: Space = intersect(&(*CONSTANT_7),&(v1379_2));
    drop(v1379_2);
    let v1379_10: Space = if has_head(&(v1379_9)) { singleton(&[]) } else { Space::new() };
    drop(v1379_9);
    let v1379_12: Space = if (v1379_10).is_empty() { Space::new() } else {
      let v1381_6: Path = concat_path(&(*p0),&(v1378_12_head));
      let mut v1381_11 = Space::new();
      let mut v1381_11_cursor = (v1378_12_tail).read_zipper();
      for v1381_11_byte in v1381_11_cursor.child_mask().iter() {
        v1381_11_cursor.descend_to_byte(v1381_11_byte);
        let v1381_11_tail = v1381_11_cursor.make_map();
        v1381_11_cursor.ascend(1);
        let v1381_11_head = Path::from_slice(&[v1381_11_byte]);
        let v1382_2: Space = singleton(&(v1381_11_head));
        let v1382_3: Space = intersect(&(*CONSTANT_7),&(v1382_2));
        let v1382_4: Space = if has_head(&(v1382_3)) { singleton(&[]) } else { Space::new() };
        drop(v1382_3);
        let v1382_5: Space = subtract(&(*CONSTANT_0),&(v1382_4));
        drop(v1382_4);
        let v1382_7: Space = if (v1382_5).is_empty() { Space::new() } else {
          let v1383_6: Space = routine_162(c, &(v1381_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1381_6), &(v1381_11_tail));
          compose(&(v1382_5),&(v1383_6))
        };
        drop(v1382_5);
        let v1382_8: Space = intersect(&(*CONSTANT_7),&(v1382_2));
        drop(v1382_2);
        let v1382_9: Space = if has_head(&(v1382_8)) { singleton(&[]) } else { Space::new() };
        drop(v1382_8);
        let v1382_11: Space = if (v1382_9).is_empty() { Space::new() } else {
          let v1384_10: Space = routine_163(c, &(v1381_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v1381_6), &(v1381_11_tail));
          compose(&(v1382_9),&(v1384_10))
        };
        drop(v1382_9);
        let v1382_12: Space = unite(&(v1382_7),&(v1382_11));
        v1381_11.join_into((v1382_12).clone());
      }
      drop(v1381_11_cursor);
      drop(v1381_6);
      compose(&(v1379_10),&(v1381_11))
    };
    drop(v1379_10);
    let v1379_13: Space = unite(&(v1379_8),&(v1379_12));
    v1378_12.join_into((v1379_13).clone());
  }
  drop(v1378_12_cursor);
  (v1378_12).clone()
}

fn routine_141(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v1385_15 = Space::new();
  let mut v1385_15_cursor = (*s0).read_zipper();
  for v1385_15_byte in v1385_15_cursor.child_mask().iter() {
    v1385_15_cursor.descend_to_byte(v1385_15_byte);
    let v1385_15_tail = v1385_15_cursor.make_map();
    v1385_15_cursor.ascend(1);
    let v1385_15_head = Path::from_slice(&[v1385_15_byte]);
    let v1386_2: Space = singleton(&(v1385_15_head));
    let v1386_3: Space = intersect(&(*CONSTANT_7),&(v1386_2));
    let v1386_4: Space = if has_head(&(v1386_3)) { singleton(&[]) } else { Space::new() };
    drop(v1386_3);
    let v1386_5: Space = subtract(&(*CONSTANT_0),&(v1386_4));
    drop(v1386_4);
    let v1386_7: Space = if (v1386_5).is_empty() { Space::new() } else {
      let mut v1387_6 = Space::new();
      let mut v1387_6_cursor = (v1385_15_tail).read_zipper();
      for v1387_6_byte in v1387_6_cursor.child_mask().iter() {
        v1387_6_cursor.descend_to_byte(v1387_6_byte);
        let v1387_6_tail = v1387_6_cursor.make_map();
        v1387_6_cursor.ascend(1);
        let v1387_6_head = Path::from_slice(&[v1387_6_byte]);
        let v1388_2: Space = singleton(&(v1387_6_head));
        let v1388_3: Space = intersect(&(*CONSTANT_7),&(v1388_2));
        let v1388_4: Space = if has_head(&(v1388_3)) { singleton(&[]) } else { Space::new() };
        drop(v1388_3);
        let v1388_5: Space = subtract(&(*CONSTANT_0),&(v1388_4));
        drop(v1388_4);
        let v1388_8: Space = if (v1388_5).is_empty() { Space::new() } else {
          let v1389_6: Path = concat_path(&(v1385_15_head),&(v1387_6_head));
          let v1389_7: Space = routine_162(c, &(v1389_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1387_6_tail));
          compose(&(v1388_5),&(v1389_7))
        };
        drop(v1388_5);
        let v1388_9: Space = intersect(&(*CONSTANT_7),&(v1388_2));
        drop(v1388_2);
        let v1388_10: Space = if has_head(&(v1388_9)) { singleton(&[]) } else { Space::new() };
        drop(v1388_9);
        let v1388_12: Space = if (v1388_10).is_empty() { Space::new() } else {
          let v1390_6: Path = concat_path(&(v1385_15_head),&(v1387_6_head));
          let v1390_11: Space = routine_163(c, &(v1390_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1387_6_tail));
          drop(v1390_6);
          compose(&(v1388_10),&(v1390_11))
        };
        drop(v1388_10);
        let v1388_13: Space = unite(&(v1388_8),&(v1388_12));
        v1387_6.join_into((v1388_13).clone());
      }
      drop(v1387_6_cursor);
      compose(&(v1386_5),&(v1387_6))
    };
    drop(v1386_5);
    let v1386_8: Space = intersect(&(*CONSTANT_7),&(v1386_2));
    drop(v1386_2);
    let v1386_9: Space = if has_head(&(v1386_8)) { singleton(&[]) } else { Space::new() };
    drop(v1386_8);
    let v1386_11: Space = if (v1386_9).is_empty() { Space::new() } else {
      let mut v1391_10 = Space::new();
      let mut v1391_10_cursor = (v1385_15_tail).read_zipper();
      for v1391_10_byte in v1391_10_cursor.child_mask().iter() {
        v1391_10_cursor.descend_to_byte(v1391_10_byte);
        let v1391_10_tail = v1391_10_cursor.make_map();
        v1391_10_cursor.ascend(1);
        let v1391_10_head = Path::from_slice(&[v1391_10_byte]);
        let v1392_2: Space = singleton(&(v1391_10_head));
        let v1392_3: Space = intersect(&(*CONSTANT_7),&(v1392_2));
        let v1392_4: Space = if has_head(&(v1392_3)) { singleton(&[]) } else { Space::new() };
        drop(v1392_3);
        let v1392_5: Space = subtract(&(*CONSTANT_0),&(v1392_4));
        drop(v1392_4);
        let v1392_7: Space = if (v1392_5).is_empty() { Space::new() } else {
          let v1393_6: Space = routine_180(c, &(v1391_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1385_15_head), &(v1391_10_tail));
          compose(&(v1392_5),&(v1393_6))
        };
        drop(v1392_5);
        let v1392_8: Space = intersect(&(*CONSTANT_7),&(v1392_2));
        drop(v1392_2);
        let v1392_9: Space = if has_head(&(v1392_8)) { singleton(&[]) } else { Space::new() };
        drop(v1392_8);
        let v1392_11: Space = if (v1392_9).is_empty() { Space::new() } else {
          let v1394_10: Space = routine_181(c, &(v1391_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v1385_15_head), &(v1391_10_tail));
          compose(&(v1392_9),&(v1394_10))
        };
        drop(v1392_9);
        let v1392_12: Space = unite(&(v1392_7),&(v1392_11));
        v1391_10.join_into((v1392_12).clone());
      }
      drop(v1391_10_cursor);
      compose(&(v1386_9),&(v1391_10))
    };
    drop(v1386_9);
    let v1386_12: Space = unite(&(v1386_7),&(v1386_11));
    v1385_15.join_into((v1386_12).clone());
  }
  drop(v1385_15_cursor);
  (v1385_15).clone()
}

fn routine_142(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v1395_5 = Space::new();
  let mut v1395_5_cursor = (*s0).read_zipper();
  for v1395_5_byte in v1395_5_cursor.child_mask().iter() {
    v1395_5_cursor.descend_to_byte(v1395_5_byte);
    let v1395_5_tail = v1395_5_cursor.make_map();
    v1395_5_cursor.ascend(1);
    let v1395_5_head = Path::from_slice(&[v1395_5_byte]);
    let v1396_2: Space = singleton(&(v1395_5_head));
    let v1396_3: Space = intersect(&(*CONSTANT_7),&(v1396_2));
    let v1396_4: Space = if has_head(&(v1396_3)) { singleton(&[]) } else { Space::new() };
    drop(v1396_3);
    let v1396_5: Space = subtract(&(*CONSTANT_0),&(v1396_4));
    drop(v1396_4);
    let v1396_8: Space = if (v1396_5).is_empty() { Space::new() } else {
      let v1397_6: Path = concat_path(&(*p0),&(v1395_5_head));
      let v1397_7: Space = routine_142(c, &(v1397_6), &(v1395_5_tail));
      compose(&(v1396_5),&(v1397_7))
    };
    drop(v1396_5);
    let v1396_9: Space = intersect(&(*CONSTANT_7),&(v1396_2));
    drop(v1396_2);
    let v1396_10: Space = if has_head(&(v1396_9)) { singleton(&[]) } else { Space::new() };
    drop(v1396_9);
    let v1396_12: Space = if (v1396_10).is_empty() { Space::new() } else {
      let v1398_6: Path = concat_path(&(*p0),&(v1395_5_head));
      let v1398_11: Space = singleton(&(v1398_6));
      drop(v1398_6);
      compose(&(v1396_10),&(v1398_11))
    };
    drop(v1396_10);
    let v1396_13: Space = unite(&(v1396_8),&(v1396_12));
    drop(v1396_12);
    v1395_5.join_into((v1396_13).clone());
  }
  drop(v1395_5_cursor);
  (v1395_5).clone()
}

fn routine_143(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v1399_2: Space = singleton(&(*p0));
  (v1399_2).clone()
}

fn routine_144(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v1400_5 = Space::new();
  let mut v1400_5_cursor = (*s0).read_zipper();
  for v1400_5_byte in v1400_5_cursor.child_mask().iter() {
    v1400_5_cursor.descend_to_byte(v1400_5_byte);
    let v1400_5_tail = v1400_5_cursor.make_map();
    v1400_5_cursor.ascend(1);
    let v1400_5_head = Path::from_slice(&[v1400_5_byte]);
    let v1401_2: Space = singleton(&(v1400_5_head));
    let v1401_3: Space = intersect(&(*CONSTANT_7),&(v1401_2));
    let v1401_4: Space = if has_head(&(v1401_3)) { singleton(&[]) } else { Space::new() };
    drop(v1401_3);
    let v1401_5: Space = subtract(&(*CONSTANT_0),&(v1401_4));
    drop(v1401_4);
    let v1401_8: Space = if (v1401_5).is_empty() { Space::new() } else {
      let v1402_6: Path = concat_path(&(*p0),&(v1400_5_head));
      let v1402_7: Space = routine_144(c, &(v1402_6), &(v1400_5_tail));
      compose(&(v1401_5),&(v1402_7))
    };
    drop(v1401_5);
    let v1401_9: Space = intersect(&(*CONSTANT_7),&(v1401_2));
    drop(v1401_2);
    let v1401_10: Space = if has_head(&(v1401_9)) { singleton(&[]) } else { Space::new() };
    drop(v1401_9);
    let v1401_12: Space = if (v1401_10).is_empty() { Space::new() } else {
      let v1403_6: Path = concat_path(&(*p0),&(v1400_5_head));
      let v1403_11: Space = singleton(&(v1403_6));
      drop(v1403_6);
      compose(&(v1401_10),&(v1403_11))
    };
    drop(v1401_10);
    let v1401_13: Space = unite(&(v1401_8),&(v1401_12));
    drop(v1401_12);
    v1400_5.join_into((v1401_13).clone());
  }
  drop(v1400_5_cursor);
  (v1400_5).clone()
}

fn routine_145(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v1404_2: Space = singleton(&(*p0));
  (v1404_2).clone()
}

fn routine_146(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1405_13 = Space::new();
  let mut v1405_13_cursor = (*s0).read_zipper();
  for v1405_13_byte in v1405_13_cursor.child_mask().iter() {
    v1405_13_cursor.descend_to_byte(v1405_13_byte);
    let v1405_13_tail = v1405_13_cursor.make_map();
    v1405_13_cursor.ascend(1);
    let v1405_13_head = Path::from_slice(&[v1405_13_byte]);
    let v1406_2: Space = singleton(&(v1405_13_head));
    let v1406_3: Space = intersect(&(*CONSTANT_7),&(v1406_2));
    let v1406_4: Space = if has_head(&(v1406_3)) { singleton(&[]) } else { Space::new() };
    drop(v1406_3);
    let v1406_5: Space = subtract(&(*CONSTANT_0),&(v1406_4));
    drop(v1406_4);
    let v1406_8: Space = if (v1406_5).is_empty() { Space::new() } else {
      let v1407_6: Path = concat_path(&(*p0),&(v1405_13_head));
      let v1407_7: Space = routine_146(c, &(v1407_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1405_13_tail));
      compose(&(v1406_5),&(v1407_7))
    };
    drop(v1406_5);
    let v1406_9: Space = intersect(&(*CONSTANT_7),&(v1406_2));
    drop(v1406_2);
    let v1406_10: Space = if has_head(&(v1406_9)) { singleton(&[]) } else { Space::new() };
    drop(v1406_9);
    let v1406_12: Space = if (v1406_10).is_empty() { Space::new() } else {
      let v1408_6: Path = concat_path(&(*p0),&(v1405_13_head));
      let mut v1408_11 = Space::new();
      let mut v1408_11_cursor = (v1405_13_tail).read_zipper();
      for v1408_11_byte in v1408_11_cursor.child_mask().iter() {
        v1408_11_cursor.descend_to_byte(v1408_11_byte);
        let v1408_11_tail = v1408_11_cursor.make_map();
        v1408_11_cursor.ascend(1);
        let v1408_11_head = Path::from_slice(&[v1408_11_byte]);
        let v1409_2: Space = singleton(&(v1408_11_head));
        let v1409_3: Space = intersect(&(*CONSTANT_7),&(v1409_2));
        let v1409_4: Space = if has_head(&(v1409_3)) { singleton(&[]) } else { Space::new() };
        drop(v1409_3);
        let v1409_5: Space = subtract(&(*CONSTANT_0),&(v1409_4));
        drop(v1409_4);
        let v1409_7: Space = if (v1409_5).is_empty() { Space::new() } else {
          let v1410_6: Space = routine_164(c, &(v1408_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1408_6), &(v1408_11_tail));
          compose(&(v1409_5),&(v1410_6))
        };
        drop(v1409_5);
        let v1409_8: Space = intersect(&(*CONSTANT_7),&(v1409_2));
        drop(v1409_2);
        let v1409_9: Space = if has_head(&(v1409_8)) { singleton(&[]) } else { Space::new() };
        drop(v1409_8);
        let v1409_11: Space = if (v1409_9).is_empty() { Space::new() } else {
          let v1411_10: Space = routine_165(c, &(v1408_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1408_6), &(v1408_11_tail));
          compose(&(v1409_9),&(v1411_10))
        };
        drop(v1409_9);
        let v1409_12: Space = unite(&(v1409_7),&(v1409_11));
        v1408_11.join_into((v1409_12).clone());
      }
      drop(v1408_11_cursor);
      drop(v1408_6);
      compose(&(v1406_10),&(v1408_11))
    };
    drop(v1406_10);
    let v1406_13: Space = unite(&(v1406_8),&(v1406_12));
    v1405_13.join_into((v1406_13).clone());
  }
  drop(v1405_13_cursor);
  (v1405_13).clone()
}

fn routine_147(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1412_16 = Space::new();
  let mut v1412_16_cursor = (*s0).read_zipper();
  for v1412_16_byte in v1412_16_cursor.child_mask().iter() {
    v1412_16_cursor.descend_to_byte(v1412_16_byte);
    let v1412_16_tail = v1412_16_cursor.make_map();
    v1412_16_cursor.ascend(1);
    let v1412_16_head = Path::from_slice(&[v1412_16_byte]);
    let v1413_2: Space = singleton(&(v1412_16_head));
    let v1413_3: Space = intersect(&(*CONSTANT_7),&(v1413_2));
    let v1413_4: Space = if has_head(&(v1413_3)) { singleton(&[]) } else { Space::new() };
    drop(v1413_3);
    let v1413_5: Space = subtract(&(*CONSTANT_0),&(v1413_4));
    drop(v1413_4);
    let v1413_7: Space = if (v1413_5).is_empty() { Space::new() } else {
      let mut v1414_6 = Space::new();
      let mut v1414_6_cursor = (v1412_16_tail).read_zipper();
      for v1414_6_byte in v1414_6_cursor.child_mask().iter() {
        v1414_6_cursor.descend_to_byte(v1414_6_byte);
        let v1414_6_tail = v1414_6_cursor.make_map();
        v1414_6_cursor.ascend(1);
        let v1414_6_head = Path::from_slice(&[v1414_6_byte]);
        let v1415_2: Space = singleton(&(v1414_6_head));
        let v1415_3: Space = intersect(&(*CONSTANT_7),&(v1415_2));
        let v1415_4: Space = if has_head(&(v1415_3)) { singleton(&[]) } else { Space::new() };
        drop(v1415_3);
        let v1415_5: Space = subtract(&(*CONSTANT_0),&(v1415_4));
        drop(v1415_4);
        let v1415_8: Space = if (v1415_5).is_empty() { Space::new() } else {
          let v1416_6: Path = concat_path(&(v1412_16_head),&(v1414_6_head));
          let v1416_7: Space = routine_164(c, &(v1416_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1414_6_tail));
          compose(&(v1415_5),&(v1416_7))
        };
        drop(v1415_5);
        let v1415_9: Space = intersect(&(*CONSTANT_7),&(v1415_2));
        drop(v1415_2);
        let v1415_10: Space = if has_head(&(v1415_9)) { singleton(&[]) } else { Space::new() };
        drop(v1415_9);
        let v1415_12: Space = if (v1415_10).is_empty() { Space::new() } else {
          let v1417_6: Path = concat_path(&(v1412_16_head),&(v1414_6_head));
          let v1417_11: Space = routine_165(c, &(v1417_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1414_6_tail));
          drop(v1417_6);
          compose(&(v1415_10),&(v1417_11))
        };
        drop(v1415_10);
        let v1415_13: Space = unite(&(v1415_8),&(v1415_12));
        v1414_6.join_into((v1415_13).clone());
      }
      drop(v1414_6_cursor);
      compose(&(v1413_5),&(v1414_6))
    };
    drop(v1413_5);
    let v1413_8: Space = intersect(&(*CONSTANT_7),&(v1413_2));
    drop(v1413_2);
    let v1413_9: Space = if has_head(&(v1413_8)) { singleton(&[]) } else { Space::new() };
    drop(v1413_8);
    let v1413_11: Space = if (v1413_9).is_empty() { Space::new() } else {
      let mut v1418_10 = Space::new();
      let mut v1418_10_cursor = (v1412_16_tail).read_zipper();
      for v1418_10_byte in v1418_10_cursor.child_mask().iter() {
        v1418_10_cursor.descend_to_byte(v1418_10_byte);
        let v1418_10_tail = v1418_10_cursor.make_map();
        v1418_10_cursor.ascend(1);
        let v1418_10_head = Path::from_slice(&[v1418_10_byte]);
        let v1419_2: Space = singleton(&(v1418_10_head));
        let v1419_3: Space = intersect(&(*CONSTANT_7),&(v1419_2));
        let v1419_4: Space = if has_head(&(v1419_3)) { singleton(&[]) } else { Space::new() };
        drop(v1419_3);
        let v1419_5: Space = subtract(&(*CONSTANT_0),&(v1419_4));
        drop(v1419_4);
        let v1419_7: Space = if (v1419_5).is_empty() { Space::new() } else {
          let v1420_6: Space = routine_182(c, &(v1418_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1412_16_head), &(v1418_10_tail));
          compose(&(v1419_5),&(v1420_6))
        };
        drop(v1419_5);
        let v1419_8: Space = intersect(&(*CONSTANT_7),&(v1419_2));
        drop(v1419_2);
        let v1419_9: Space = if has_head(&(v1419_8)) { singleton(&[]) } else { Space::new() };
        drop(v1419_8);
        let v1419_11: Space = if (v1419_9).is_empty() { Space::new() } else {
          let v1421_10: Space = routine_183(c, &(v1418_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1412_16_head), &(v1418_10_tail));
          compose(&(v1419_9),&(v1421_10))
        };
        drop(v1419_9);
        let v1419_12: Space = unite(&(v1419_7),&(v1419_11));
        v1418_10.join_into((v1419_12).clone());
      }
      drop(v1418_10_cursor);
      compose(&(v1413_9),&(v1418_10))
    };
    drop(v1413_9);
    let v1413_12: Space = unite(&(v1413_7),&(v1413_11));
    v1412_16.join_into((v1413_12).clone());
  }
  drop(v1412_16_cursor);
  (v1412_16).clone()
}

fn routine_148(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1422_13 = Space::new();
  let mut v1422_13_cursor = (*s0).read_zipper();
  for v1422_13_byte in v1422_13_cursor.child_mask().iter() {
    v1422_13_cursor.descend_to_byte(v1422_13_byte);
    let v1422_13_tail = v1422_13_cursor.make_map();
    v1422_13_cursor.ascend(1);
    let v1422_13_head = Path::from_slice(&[v1422_13_byte]);
    let v1423_2: Space = singleton(&(v1422_13_head));
    let v1423_3: Space = intersect(&(*CONSTANT_7),&(v1423_2));
    let v1423_4: Space = if has_head(&(v1423_3)) { singleton(&[]) } else { Space::new() };
    drop(v1423_3);
    let v1423_5: Space = subtract(&(*CONSTANT_0),&(v1423_4));
    drop(v1423_4);
    let v1423_8: Space = if (v1423_5).is_empty() { Space::new() } else {
      let v1424_6: Path = concat_path(&(*p0),&(v1422_13_head));
      let v1424_7: Space = routine_148(c, &(v1424_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1422_13_tail));
      compose(&(v1423_5),&(v1424_7))
    };
    drop(v1423_5);
    let v1423_9: Space = intersect(&(*CONSTANT_7),&(v1423_2));
    drop(v1423_2);
    let v1423_10: Space = if has_head(&(v1423_9)) { singleton(&[]) } else { Space::new() };
    drop(v1423_9);
    let v1423_12: Space = if (v1423_10).is_empty() { Space::new() } else {
      let v1425_6: Path = concat_path(&(*p0),&(v1422_13_head));
      let mut v1425_11 = Space::new();
      let mut v1425_11_cursor = (v1422_13_tail).read_zipper();
      for v1425_11_byte in v1425_11_cursor.child_mask().iter() {
        v1425_11_cursor.descend_to_byte(v1425_11_byte);
        let v1425_11_tail = v1425_11_cursor.make_map();
        v1425_11_cursor.ascend(1);
        let v1425_11_head = Path::from_slice(&[v1425_11_byte]);
        let v1426_2: Space = singleton(&(v1425_11_head));
        let v1426_3: Space = intersect(&(*CONSTANT_7),&(v1426_2));
        let v1426_4: Space = if has_head(&(v1426_3)) { singleton(&[]) } else { Space::new() };
        drop(v1426_3);
        let v1426_5: Space = subtract(&(*CONSTANT_0),&(v1426_4));
        drop(v1426_4);
        let v1426_7: Space = if (v1426_5).is_empty() { Space::new() } else {
          let v1427_6: Space = routine_166(c, &(v1425_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1425_6), &(v1425_11_tail));
          compose(&(v1426_5),&(v1427_6))
        };
        drop(v1426_5);
        let v1426_8: Space = intersect(&(*CONSTANT_7),&(v1426_2));
        drop(v1426_2);
        let v1426_9: Space = if has_head(&(v1426_8)) { singleton(&[]) } else { Space::new() };
        drop(v1426_8);
        let v1426_11: Space = if (v1426_9).is_empty() { Space::new() } else {
          let v1428_10: Space = routine_167(c, &(v1425_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1425_6), &(v1425_11_tail));
          compose(&(v1426_9),&(v1428_10))
        };
        drop(v1426_9);
        let v1426_12: Space = unite(&(v1426_7),&(v1426_11));
        v1425_11.join_into((v1426_12).clone());
      }
      drop(v1425_11_cursor);
      drop(v1425_6);
      compose(&(v1423_10),&(v1425_11))
    };
    drop(v1423_10);
    let v1423_13: Space = unite(&(v1423_8),&(v1423_12));
    v1422_13.join_into((v1423_13).clone());
  }
  drop(v1422_13_cursor);
  (v1422_13).clone()
}

fn routine_149(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1429_16 = Space::new();
  let mut v1429_16_cursor = (*s0).read_zipper();
  for v1429_16_byte in v1429_16_cursor.child_mask().iter() {
    v1429_16_cursor.descend_to_byte(v1429_16_byte);
    let v1429_16_tail = v1429_16_cursor.make_map();
    v1429_16_cursor.ascend(1);
    let v1429_16_head = Path::from_slice(&[v1429_16_byte]);
    let v1430_2: Space = singleton(&(v1429_16_head));
    let v1430_3: Space = intersect(&(*CONSTANT_7),&(v1430_2));
    let v1430_4: Space = if has_head(&(v1430_3)) { singleton(&[]) } else { Space::new() };
    drop(v1430_3);
    let v1430_5: Space = subtract(&(*CONSTANT_0),&(v1430_4));
    drop(v1430_4);
    let v1430_7: Space = if (v1430_5).is_empty() { Space::new() } else {
      let mut v1431_6 = Space::new();
      let mut v1431_6_cursor = (v1429_16_tail).read_zipper();
      for v1431_6_byte in v1431_6_cursor.child_mask().iter() {
        v1431_6_cursor.descend_to_byte(v1431_6_byte);
        let v1431_6_tail = v1431_6_cursor.make_map();
        v1431_6_cursor.ascend(1);
        let v1431_6_head = Path::from_slice(&[v1431_6_byte]);
        let v1432_2: Space = singleton(&(v1431_6_head));
        let v1432_3: Space = intersect(&(*CONSTANT_7),&(v1432_2));
        let v1432_4: Space = if has_head(&(v1432_3)) { singleton(&[]) } else { Space::new() };
        drop(v1432_3);
        let v1432_5: Space = subtract(&(*CONSTANT_0),&(v1432_4));
        drop(v1432_4);
        let v1432_8: Space = if (v1432_5).is_empty() { Space::new() } else {
          let v1433_6: Path = concat_path(&(v1429_16_head),&(v1431_6_head));
          let v1433_7: Space = routine_166(c, &(v1433_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1431_6_tail));
          compose(&(v1432_5),&(v1433_7))
        };
        drop(v1432_5);
        let v1432_9: Space = intersect(&(*CONSTANT_7),&(v1432_2));
        drop(v1432_2);
        let v1432_10: Space = if has_head(&(v1432_9)) { singleton(&[]) } else { Space::new() };
        drop(v1432_9);
        let v1432_12: Space = if (v1432_10).is_empty() { Space::new() } else {
          let v1434_6: Path = concat_path(&(v1429_16_head),&(v1431_6_head));
          let v1434_11: Space = routine_167(c, &(v1434_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1431_6_tail));
          drop(v1434_6);
          compose(&(v1432_10),&(v1434_11))
        };
        drop(v1432_10);
        let v1432_13: Space = unite(&(v1432_8),&(v1432_12));
        v1431_6.join_into((v1432_13).clone());
      }
      drop(v1431_6_cursor);
      compose(&(v1430_5),&(v1431_6))
    };
    drop(v1430_5);
    let v1430_8: Space = intersect(&(*CONSTANT_7),&(v1430_2));
    drop(v1430_2);
    let v1430_9: Space = if has_head(&(v1430_8)) { singleton(&[]) } else { Space::new() };
    drop(v1430_8);
    let v1430_11: Space = if (v1430_9).is_empty() { Space::new() } else {
      let mut v1435_10 = Space::new();
      let mut v1435_10_cursor = (v1429_16_tail).read_zipper();
      for v1435_10_byte in v1435_10_cursor.child_mask().iter() {
        v1435_10_cursor.descend_to_byte(v1435_10_byte);
        let v1435_10_tail = v1435_10_cursor.make_map();
        v1435_10_cursor.ascend(1);
        let v1435_10_head = Path::from_slice(&[v1435_10_byte]);
        let v1436_2: Space = singleton(&(v1435_10_head));
        let v1436_3: Space = intersect(&(*CONSTANT_7),&(v1436_2));
        let v1436_4: Space = if has_head(&(v1436_3)) { singleton(&[]) } else { Space::new() };
        drop(v1436_3);
        let v1436_5: Space = subtract(&(*CONSTANT_0),&(v1436_4));
        drop(v1436_4);
        let v1436_7: Space = if (v1436_5).is_empty() { Space::new() } else {
          let v1437_6: Space = routine_184(c, &(v1435_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1429_16_head), &(v1435_10_tail));
          compose(&(v1436_5),&(v1437_6))
        };
        drop(v1436_5);
        let v1436_8: Space = intersect(&(*CONSTANT_7),&(v1436_2));
        drop(v1436_2);
        let v1436_9: Space = if has_head(&(v1436_8)) { singleton(&[]) } else { Space::new() };
        drop(v1436_8);
        let v1436_11: Space = if (v1436_9).is_empty() { Space::new() } else {
          let v1438_10: Space = routine_185(c, &(v1435_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1429_16_head), &(v1435_10_tail));
          compose(&(v1436_9),&(v1438_10))
        };
        drop(v1436_9);
        let v1436_12: Space = unite(&(v1436_7),&(v1436_11));
        v1435_10.join_into((v1436_12).clone());
      }
      drop(v1435_10_cursor);
      compose(&(v1430_9),&(v1435_10))
    };
    drop(v1430_9);
    let v1430_12: Space = unite(&(v1430_7),&(v1430_11));
    v1429_16.join_into((v1430_12).clone());
  }
  drop(v1429_16_cursor);
  (v1429_16).clone()
}

fn routine_150(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1439_13 = Space::new();
  let mut v1439_13_cursor = (*s0).read_zipper();
  for v1439_13_byte in v1439_13_cursor.child_mask().iter() {
    v1439_13_cursor.descend_to_byte(v1439_13_byte);
    let v1439_13_tail = v1439_13_cursor.make_map();
    v1439_13_cursor.ascend(1);
    let v1439_13_head = Path::from_slice(&[v1439_13_byte]);
    let v1440_2: Space = singleton(&(v1439_13_head));
    let v1440_3: Space = intersect(&(*CONSTANT_7),&(v1440_2));
    let v1440_4: Space = if has_head(&(v1440_3)) { singleton(&[]) } else { Space::new() };
    drop(v1440_3);
    let v1440_5: Space = subtract(&(*CONSTANT_0),&(v1440_4));
    drop(v1440_4);
    let v1440_8: Space = if (v1440_5).is_empty() { Space::new() } else {
      let v1441_6: Path = concat_path(&(*p0),&(v1439_13_head));
      let v1441_7: Space = routine_150(c, &(v1441_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1439_13_tail));
      compose(&(v1440_5),&(v1441_7))
    };
    drop(v1440_5);
    let v1440_9: Space = intersect(&(*CONSTANT_7),&(v1440_2));
    drop(v1440_2);
    let v1440_10: Space = if has_head(&(v1440_9)) { singleton(&[]) } else { Space::new() };
    drop(v1440_9);
    let v1440_12: Space = if (v1440_10).is_empty() { Space::new() } else {
      let v1442_6: Path = concat_path(&(*p0),&(v1439_13_head));
      let mut v1442_11 = Space::new();
      let mut v1442_11_cursor = (v1439_13_tail).read_zipper();
      for v1442_11_byte in v1442_11_cursor.child_mask().iter() {
        v1442_11_cursor.descend_to_byte(v1442_11_byte);
        let v1442_11_tail = v1442_11_cursor.make_map();
        v1442_11_cursor.ascend(1);
        let v1442_11_head = Path::from_slice(&[v1442_11_byte]);
        let v1443_2: Space = singleton(&(v1442_11_head));
        let v1443_3: Space = intersect(&(*CONSTANT_7),&(v1443_2));
        let v1443_4: Space = if has_head(&(v1443_3)) { singleton(&[]) } else { Space::new() };
        drop(v1443_3);
        let v1443_5: Space = subtract(&(*CONSTANT_0),&(v1443_4));
        drop(v1443_4);
        let v1443_7: Space = if (v1443_5).is_empty() { Space::new() } else {
          let v1444_6: Space = routine_168(c, &(v1442_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1442_6), &(v1442_11_tail));
          compose(&(v1443_5),&(v1444_6))
        };
        drop(v1443_5);
        let v1443_8: Space = intersect(&(*CONSTANT_7),&(v1443_2));
        drop(v1443_2);
        let v1443_9: Space = if has_head(&(v1443_8)) { singleton(&[]) } else { Space::new() };
        drop(v1443_8);
        let v1443_11: Space = if (v1443_9).is_empty() { Space::new() } else {
          let v1445_10: Space = routine_169(c, &(v1442_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1442_6), &(v1442_11_tail));
          compose(&(v1443_9),&(v1445_10))
        };
        drop(v1443_9);
        let v1443_12: Space = unite(&(v1443_7),&(v1443_11));
        v1442_11.join_into((v1443_12).clone());
      }
      drop(v1442_11_cursor);
      drop(v1442_6);
      compose(&(v1440_10),&(v1442_11))
    };
    drop(v1440_10);
    let v1440_13: Space = unite(&(v1440_8),&(v1440_12));
    v1439_13.join_into((v1440_13).clone());
  }
  drop(v1439_13_cursor);
  (v1439_13).clone()
}

fn routine_151(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1446_16 = Space::new();
  let mut v1446_16_cursor = (*s0).read_zipper();
  for v1446_16_byte in v1446_16_cursor.child_mask().iter() {
    v1446_16_cursor.descend_to_byte(v1446_16_byte);
    let v1446_16_tail = v1446_16_cursor.make_map();
    v1446_16_cursor.ascend(1);
    let v1446_16_head = Path::from_slice(&[v1446_16_byte]);
    let v1447_2: Space = singleton(&(v1446_16_head));
    let v1447_3: Space = intersect(&(*CONSTANT_7),&(v1447_2));
    let v1447_4: Space = if has_head(&(v1447_3)) { singleton(&[]) } else { Space::new() };
    drop(v1447_3);
    let v1447_5: Space = subtract(&(*CONSTANT_0),&(v1447_4));
    drop(v1447_4);
    let v1447_7: Space = if (v1447_5).is_empty() { Space::new() } else {
      let mut v1448_6 = Space::new();
      let mut v1448_6_cursor = (v1446_16_tail).read_zipper();
      for v1448_6_byte in v1448_6_cursor.child_mask().iter() {
        v1448_6_cursor.descend_to_byte(v1448_6_byte);
        let v1448_6_tail = v1448_6_cursor.make_map();
        v1448_6_cursor.ascend(1);
        let v1448_6_head = Path::from_slice(&[v1448_6_byte]);
        let v1449_2: Space = singleton(&(v1448_6_head));
        let v1449_3: Space = intersect(&(*CONSTANT_7),&(v1449_2));
        let v1449_4: Space = if has_head(&(v1449_3)) { singleton(&[]) } else { Space::new() };
        drop(v1449_3);
        let v1449_5: Space = subtract(&(*CONSTANT_0),&(v1449_4));
        drop(v1449_4);
        let v1449_8: Space = if (v1449_5).is_empty() { Space::new() } else {
          let v1450_6: Path = concat_path(&(v1446_16_head),&(v1448_6_head));
          let v1450_7: Space = routine_168(c, &(v1450_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1448_6_tail));
          compose(&(v1449_5),&(v1450_7))
        };
        drop(v1449_5);
        let v1449_9: Space = intersect(&(*CONSTANT_7),&(v1449_2));
        drop(v1449_2);
        let v1449_10: Space = if has_head(&(v1449_9)) { singleton(&[]) } else { Space::new() };
        drop(v1449_9);
        let v1449_12: Space = if (v1449_10).is_empty() { Space::new() } else {
          let v1451_6: Path = concat_path(&(v1446_16_head),&(v1448_6_head));
          let v1451_11: Space = routine_169(c, &(v1451_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1448_6_tail));
          drop(v1451_6);
          compose(&(v1449_10),&(v1451_11))
        };
        drop(v1449_10);
        let v1449_13: Space = unite(&(v1449_8),&(v1449_12));
        v1448_6.join_into((v1449_13).clone());
      }
      drop(v1448_6_cursor);
      compose(&(v1447_5),&(v1448_6))
    };
    drop(v1447_5);
    let v1447_8: Space = intersect(&(*CONSTANT_7),&(v1447_2));
    drop(v1447_2);
    let v1447_9: Space = if has_head(&(v1447_8)) { singleton(&[]) } else { Space::new() };
    drop(v1447_8);
    let v1447_11: Space = if (v1447_9).is_empty() { Space::new() } else {
      let mut v1452_10 = Space::new();
      let mut v1452_10_cursor = (v1446_16_tail).read_zipper();
      for v1452_10_byte in v1452_10_cursor.child_mask().iter() {
        v1452_10_cursor.descend_to_byte(v1452_10_byte);
        let v1452_10_tail = v1452_10_cursor.make_map();
        v1452_10_cursor.ascend(1);
        let v1452_10_head = Path::from_slice(&[v1452_10_byte]);
        let v1453_2: Space = singleton(&(v1452_10_head));
        let v1453_3: Space = intersect(&(*CONSTANT_7),&(v1453_2));
        let v1453_4: Space = if has_head(&(v1453_3)) { singleton(&[]) } else { Space::new() };
        drop(v1453_3);
        let v1453_5: Space = subtract(&(*CONSTANT_0),&(v1453_4));
        drop(v1453_4);
        let v1453_7: Space = if (v1453_5).is_empty() { Space::new() } else {
          let v1454_6: Space = routine_186(c, &(v1452_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1446_16_head), &(v1452_10_tail));
          compose(&(v1453_5),&(v1454_6))
        };
        drop(v1453_5);
        let v1453_8: Space = intersect(&(*CONSTANT_7),&(v1453_2));
        drop(v1453_2);
        let v1453_9: Space = if has_head(&(v1453_8)) { singleton(&[]) } else { Space::new() };
        drop(v1453_8);
        let v1453_11: Space = if (v1453_9).is_empty() { Space::new() } else {
          let v1455_10: Space = routine_187(c, &(v1452_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1446_16_head), &(v1452_10_tail));
          compose(&(v1453_9),&(v1455_10))
        };
        drop(v1453_9);
        let v1453_12: Space = unite(&(v1453_7),&(v1453_11));
        v1452_10.join_into((v1453_12).clone());
      }
      drop(v1452_10_cursor);
      compose(&(v1447_9),&(v1452_10))
    };
    drop(v1447_9);
    let v1447_12: Space = unite(&(v1447_7),&(v1447_11));
    v1446_16.join_into((v1447_12).clone());
  }
  drop(v1446_16_cursor);
  (v1446_16).clone()
}

fn routine_152(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1456_13 = Space::new();
  let mut v1456_13_cursor = (*s0).read_zipper();
  for v1456_13_byte in v1456_13_cursor.child_mask().iter() {
    v1456_13_cursor.descend_to_byte(v1456_13_byte);
    let v1456_13_tail = v1456_13_cursor.make_map();
    v1456_13_cursor.ascend(1);
    let v1456_13_head = Path::from_slice(&[v1456_13_byte]);
    let v1457_2: Space = singleton(&(v1456_13_head));
    let v1457_3: Space = intersect(&(*CONSTANT_7),&(v1457_2));
    let v1457_4: Space = if has_head(&(v1457_3)) { singleton(&[]) } else { Space::new() };
    drop(v1457_3);
    let v1457_5: Space = subtract(&(*CONSTANT_0),&(v1457_4));
    drop(v1457_4);
    let v1457_8: Space = if (v1457_5).is_empty() { Space::new() } else {
      let v1458_6: Path = concat_path(&(*p0),&(v1456_13_head));
      let v1458_7: Space = routine_152(c, &(v1458_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1456_13_tail));
      compose(&(v1457_5),&(v1458_7))
    };
    drop(v1457_5);
    let v1457_9: Space = intersect(&(*CONSTANT_7),&(v1457_2));
    drop(v1457_2);
    let v1457_10: Space = if has_head(&(v1457_9)) { singleton(&[]) } else { Space::new() };
    drop(v1457_9);
    let v1457_12: Space = if (v1457_10).is_empty() { Space::new() } else {
      let v1459_6: Path = concat_path(&(*p0),&(v1456_13_head));
      let mut v1459_11 = Space::new();
      let mut v1459_11_cursor = (v1456_13_tail).read_zipper();
      for v1459_11_byte in v1459_11_cursor.child_mask().iter() {
        v1459_11_cursor.descend_to_byte(v1459_11_byte);
        let v1459_11_tail = v1459_11_cursor.make_map();
        v1459_11_cursor.ascend(1);
        let v1459_11_head = Path::from_slice(&[v1459_11_byte]);
        let v1460_2: Space = singleton(&(v1459_11_head));
        let v1460_3: Space = intersect(&(*CONSTANT_7),&(v1460_2));
        let v1460_4: Space = if has_head(&(v1460_3)) { singleton(&[]) } else { Space::new() };
        drop(v1460_3);
        let v1460_5: Space = subtract(&(*CONSTANT_0),&(v1460_4));
        drop(v1460_4);
        let v1460_7: Space = if (v1460_5).is_empty() { Space::new() } else {
          let v1461_6: Space = routine_170(c, &(v1459_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1459_6), &(v1459_11_tail));
          compose(&(v1460_5),&(v1461_6))
        };
        drop(v1460_5);
        let v1460_8: Space = intersect(&(*CONSTANT_7),&(v1460_2));
        drop(v1460_2);
        let v1460_9: Space = if has_head(&(v1460_8)) { singleton(&[]) } else { Space::new() };
        drop(v1460_8);
        let v1460_11: Space = if (v1460_9).is_empty() { Space::new() } else {
          let v1462_10: Space = routine_171(c, &(v1459_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1459_6), &(v1459_11_tail));
          compose(&(v1460_9),&(v1462_10))
        };
        drop(v1460_9);
        let v1460_12: Space = unite(&(v1460_7),&(v1460_11));
        v1459_11.join_into((v1460_12).clone());
      }
      drop(v1459_11_cursor);
      drop(v1459_6);
      compose(&(v1457_10),&(v1459_11))
    };
    drop(v1457_10);
    let v1457_13: Space = unite(&(v1457_8),&(v1457_12));
    v1456_13.join_into((v1457_13).clone());
  }
  drop(v1456_13_cursor);
  (v1456_13).clone()
}

fn routine_153(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1463_16 = Space::new();
  let mut v1463_16_cursor = (*s0).read_zipper();
  for v1463_16_byte in v1463_16_cursor.child_mask().iter() {
    v1463_16_cursor.descend_to_byte(v1463_16_byte);
    let v1463_16_tail = v1463_16_cursor.make_map();
    v1463_16_cursor.ascend(1);
    let v1463_16_head = Path::from_slice(&[v1463_16_byte]);
    let v1464_2: Space = singleton(&(v1463_16_head));
    let v1464_3: Space = intersect(&(*CONSTANT_7),&(v1464_2));
    let v1464_4: Space = if has_head(&(v1464_3)) { singleton(&[]) } else { Space::new() };
    drop(v1464_3);
    let v1464_5: Space = subtract(&(*CONSTANT_0),&(v1464_4));
    drop(v1464_4);
    let v1464_7: Space = if (v1464_5).is_empty() { Space::new() } else {
      let mut v1465_6 = Space::new();
      let mut v1465_6_cursor = (v1463_16_tail).read_zipper();
      for v1465_6_byte in v1465_6_cursor.child_mask().iter() {
        v1465_6_cursor.descend_to_byte(v1465_6_byte);
        let v1465_6_tail = v1465_6_cursor.make_map();
        v1465_6_cursor.ascend(1);
        let v1465_6_head = Path::from_slice(&[v1465_6_byte]);
        let v1466_2: Space = singleton(&(v1465_6_head));
        let v1466_3: Space = intersect(&(*CONSTANT_7),&(v1466_2));
        let v1466_4: Space = if has_head(&(v1466_3)) { singleton(&[]) } else { Space::new() };
        drop(v1466_3);
        let v1466_5: Space = subtract(&(*CONSTANT_0),&(v1466_4));
        drop(v1466_4);
        let v1466_8: Space = if (v1466_5).is_empty() { Space::new() } else {
          let v1467_6: Path = concat_path(&(v1463_16_head),&(v1465_6_head));
          let v1467_7: Space = routine_170(c, &(v1467_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1465_6_tail));
          compose(&(v1466_5),&(v1467_7))
        };
        drop(v1466_5);
        let v1466_9: Space = intersect(&(*CONSTANT_7),&(v1466_2));
        drop(v1466_2);
        let v1466_10: Space = if has_head(&(v1466_9)) { singleton(&[]) } else { Space::new() };
        drop(v1466_9);
        let v1466_12: Space = if (v1466_10).is_empty() { Space::new() } else {
          let v1468_6: Path = concat_path(&(v1463_16_head),&(v1465_6_head));
          let v1468_11: Space = routine_171(c, &(v1468_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1465_6_tail));
          drop(v1468_6);
          compose(&(v1466_10),&(v1468_11))
        };
        drop(v1466_10);
        let v1466_13: Space = unite(&(v1466_8),&(v1466_12));
        v1465_6.join_into((v1466_13).clone());
      }
      drop(v1465_6_cursor);
      compose(&(v1464_5),&(v1465_6))
    };
    drop(v1464_5);
    let v1464_8: Space = intersect(&(*CONSTANT_7),&(v1464_2));
    drop(v1464_2);
    let v1464_9: Space = if has_head(&(v1464_8)) { singleton(&[]) } else { Space::new() };
    drop(v1464_8);
    let v1464_11: Space = if (v1464_9).is_empty() { Space::new() } else {
      let mut v1469_10 = Space::new();
      let mut v1469_10_cursor = (v1463_16_tail).read_zipper();
      for v1469_10_byte in v1469_10_cursor.child_mask().iter() {
        v1469_10_cursor.descend_to_byte(v1469_10_byte);
        let v1469_10_tail = v1469_10_cursor.make_map();
        v1469_10_cursor.ascend(1);
        let v1469_10_head = Path::from_slice(&[v1469_10_byte]);
        let v1470_2: Space = singleton(&(v1469_10_head));
        let v1470_3: Space = intersect(&(*CONSTANT_7),&(v1470_2));
        let v1470_4: Space = if has_head(&(v1470_3)) { singleton(&[]) } else { Space::new() };
        drop(v1470_3);
        let v1470_5: Space = subtract(&(*CONSTANT_0),&(v1470_4));
        drop(v1470_4);
        let v1470_7: Space = if (v1470_5).is_empty() { Space::new() } else {
          let v1471_6: Space = routine_188(c, &(v1469_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1463_16_head), &(v1469_10_tail));
          compose(&(v1470_5),&(v1471_6))
        };
        drop(v1470_5);
        let v1470_8: Space = intersect(&(*CONSTANT_7),&(v1470_2));
        drop(v1470_2);
        let v1470_9: Space = if has_head(&(v1470_8)) { singleton(&[]) } else { Space::new() };
        drop(v1470_8);
        let v1470_11: Space = if (v1470_9).is_empty() { Space::new() } else {
          let v1472_10: Space = routine_189(c, &(v1469_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1463_16_head), &(v1469_10_tail));
          compose(&(v1470_9),&(v1472_10))
        };
        drop(v1470_9);
        let v1470_12: Space = unite(&(v1470_7),&(v1470_11));
        v1469_10.join_into((v1470_12).clone());
      }
      drop(v1469_10_cursor);
      compose(&(v1464_9),&(v1469_10))
    };
    drop(v1464_9);
    let v1464_12: Space = unite(&(v1464_7),&(v1464_11));
    v1463_16.join_into((v1464_12).clone());
  }
  drop(v1463_16_cursor);
  (v1463_16).clone()
}

fn routine_154(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1473_13 = Space::new();
  let mut v1473_13_cursor = (*s0).read_zipper();
  for v1473_13_byte in v1473_13_cursor.child_mask().iter() {
    v1473_13_cursor.descend_to_byte(v1473_13_byte);
    let v1473_13_tail = v1473_13_cursor.make_map();
    v1473_13_cursor.ascend(1);
    let v1473_13_head = Path::from_slice(&[v1473_13_byte]);
    let v1474_2: Space = singleton(&(v1473_13_head));
    let v1474_3: Space = intersect(&(*CONSTANT_7),&(v1474_2));
    let v1474_4: Space = if has_head(&(v1474_3)) { singleton(&[]) } else { Space::new() };
    drop(v1474_3);
    let v1474_5: Space = subtract(&(*CONSTANT_0),&(v1474_4));
    drop(v1474_4);
    let v1474_8: Space = if (v1474_5).is_empty() { Space::new() } else {
      let v1475_6: Path = concat_path(&(*p0),&(v1473_13_head));
      let v1475_7: Space = routine_154(c, &(v1475_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1473_13_tail));
      compose(&(v1474_5),&(v1475_7))
    };
    drop(v1474_5);
    let v1474_9: Space = intersect(&(*CONSTANT_7),&(v1474_2));
    drop(v1474_2);
    let v1474_10: Space = if has_head(&(v1474_9)) { singleton(&[]) } else { Space::new() };
    drop(v1474_9);
    let v1474_12: Space = if (v1474_10).is_empty() { Space::new() } else {
      let v1476_6: Path = concat_path(&(*p0),&(v1473_13_head));
      let mut v1476_11 = Space::new();
      let mut v1476_11_cursor = (v1473_13_tail).read_zipper();
      for v1476_11_byte in v1476_11_cursor.child_mask().iter() {
        v1476_11_cursor.descend_to_byte(v1476_11_byte);
        let v1476_11_tail = v1476_11_cursor.make_map();
        v1476_11_cursor.ascend(1);
        let v1476_11_head = Path::from_slice(&[v1476_11_byte]);
        let v1477_2: Space = singleton(&(v1476_11_head));
        let v1477_3: Space = intersect(&(*CONSTANT_7),&(v1477_2));
        let v1477_4: Space = if has_head(&(v1477_3)) { singleton(&[]) } else { Space::new() };
        drop(v1477_3);
        let v1477_5: Space = subtract(&(*CONSTANT_0),&(v1477_4));
        drop(v1477_4);
        let v1477_7: Space = if (v1477_5).is_empty() { Space::new() } else {
          let v1478_6: Space = routine_172(c, &(v1476_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1476_6), &(v1476_11_tail));
          compose(&(v1477_5),&(v1478_6))
        };
        drop(v1477_5);
        let v1477_8: Space = intersect(&(*CONSTANT_7),&(v1477_2));
        drop(v1477_2);
        let v1477_9: Space = if has_head(&(v1477_8)) { singleton(&[]) } else { Space::new() };
        drop(v1477_8);
        let v1477_11: Space = if (v1477_9).is_empty() { Space::new() } else {
          let v1479_10: Space = routine_173(c, &(v1476_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1476_6), &(v1476_11_tail));
          compose(&(v1477_9),&(v1479_10))
        };
        drop(v1477_9);
        let v1477_12: Space = unite(&(v1477_7),&(v1477_11));
        v1476_11.join_into((v1477_12).clone());
      }
      drop(v1476_11_cursor);
      drop(v1476_6);
      compose(&(v1474_10),&(v1476_11))
    };
    drop(v1474_10);
    let v1474_13: Space = unite(&(v1474_8),&(v1474_12));
    v1473_13.join_into((v1474_13).clone());
  }
  drop(v1473_13_cursor);
  (v1473_13).clone()
}

fn routine_155(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1480_16 = Space::new();
  let mut v1480_16_cursor = (*s0).read_zipper();
  for v1480_16_byte in v1480_16_cursor.child_mask().iter() {
    v1480_16_cursor.descend_to_byte(v1480_16_byte);
    let v1480_16_tail = v1480_16_cursor.make_map();
    v1480_16_cursor.ascend(1);
    let v1480_16_head = Path::from_slice(&[v1480_16_byte]);
    let v1481_2: Space = singleton(&(v1480_16_head));
    let v1481_3: Space = intersect(&(*CONSTANT_7),&(v1481_2));
    let v1481_4: Space = if has_head(&(v1481_3)) { singleton(&[]) } else { Space::new() };
    drop(v1481_3);
    let v1481_5: Space = subtract(&(*CONSTANT_0),&(v1481_4));
    drop(v1481_4);
    let v1481_7: Space = if (v1481_5).is_empty() { Space::new() } else {
      let mut v1482_6 = Space::new();
      let mut v1482_6_cursor = (v1480_16_tail).read_zipper();
      for v1482_6_byte in v1482_6_cursor.child_mask().iter() {
        v1482_6_cursor.descend_to_byte(v1482_6_byte);
        let v1482_6_tail = v1482_6_cursor.make_map();
        v1482_6_cursor.ascend(1);
        let v1482_6_head = Path::from_slice(&[v1482_6_byte]);
        let v1483_2: Space = singleton(&(v1482_6_head));
        let v1483_3: Space = intersect(&(*CONSTANT_7),&(v1483_2));
        let v1483_4: Space = if has_head(&(v1483_3)) { singleton(&[]) } else { Space::new() };
        drop(v1483_3);
        let v1483_5: Space = subtract(&(*CONSTANT_0),&(v1483_4));
        drop(v1483_4);
        let v1483_8: Space = if (v1483_5).is_empty() { Space::new() } else {
          let v1484_6: Path = concat_path(&(v1480_16_head),&(v1482_6_head));
          let v1484_7: Space = routine_172(c, &(v1484_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1482_6_tail));
          compose(&(v1483_5),&(v1484_7))
        };
        drop(v1483_5);
        let v1483_9: Space = intersect(&(*CONSTANT_7),&(v1483_2));
        drop(v1483_2);
        let v1483_10: Space = if has_head(&(v1483_9)) { singleton(&[]) } else { Space::new() };
        drop(v1483_9);
        let v1483_12: Space = if (v1483_10).is_empty() { Space::new() } else {
          let v1485_6: Path = concat_path(&(v1480_16_head),&(v1482_6_head));
          let v1485_11: Space = routine_173(c, &(v1485_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1482_6_tail));
          drop(v1485_6);
          compose(&(v1483_10),&(v1485_11))
        };
        drop(v1483_10);
        let v1483_13: Space = unite(&(v1483_8),&(v1483_12));
        v1482_6.join_into((v1483_13).clone());
      }
      drop(v1482_6_cursor);
      compose(&(v1481_5),&(v1482_6))
    };
    drop(v1481_5);
    let v1481_8: Space = intersect(&(*CONSTANT_7),&(v1481_2));
    drop(v1481_2);
    let v1481_9: Space = if has_head(&(v1481_8)) { singleton(&[]) } else { Space::new() };
    drop(v1481_8);
    let v1481_11: Space = if (v1481_9).is_empty() { Space::new() } else {
      let mut v1486_10 = Space::new();
      let mut v1486_10_cursor = (v1480_16_tail).read_zipper();
      for v1486_10_byte in v1486_10_cursor.child_mask().iter() {
        v1486_10_cursor.descend_to_byte(v1486_10_byte);
        let v1486_10_tail = v1486_10_cursor.make_map();
        v1486_10_cursor.ascend(1);
        let v1486_10_head = Path::from_slice(&[v1486_10_byte]);
        let v1487_2: Space = singleton(&(v1486_10_head));
        let v1487_3: Space = intersect(&(*CONSTANT_7),&(v1487_2));
        let v1487_4: Space = if has_head(&(v1487_3)) { singleton(&[]) } else { Space::new() };
        drop(v1487_3);
        let v1487_5: Space = subtract(&(*CONSTANT_0),&(v1487_4));
        drop(v1487_4);
        let v1487_7: Space = if (v1487_5).is_empty() { Space::new() } else {
          let v1488_6: Space = routine_190(c, &(v1486_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1480_16_head), &(v1486_10_tail));
          compose(&(v1487_5),&(v1488_6))
        };
        drop(v1487_5);
        let v1487_8: Space = intersect(&(*CONSTANT_7),&(v1487_2));
        drop(v1487_2);
        let v1487_9: Space = if has_head(&(v1487_8)) { singleton(&[]) } else { Space::new() };
        drop(v1487_8);
        let v1487_11: Space = if (v1487_9).is_empty() { Space::new() } else {
          let v1489_10: Space = routine_191(c, &(v1486_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1480_16_head), &(v1486_10_tail));
          compose(&(v1487_9),&(v1489_10))
        };
        drop(v1487_9);
        let v1487_12: Space = unite(&(v1487_7),&(v1487_11));
        v1486_10.join_into((v1487_12).clone());
      }
      drop(v1486_10_cursor);
      compose(&(v1481_9),&(v1486_10))
    };
    drop(v1481_9);
    let v1481_12: Space = unite(&(v1481_7),&(v1481_11));
    v1480_16.join_into((v1481_12).clone());
  }
  drop(v1480_16_cursor);
  (v1480_16).clone()
}

fn routine_156(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1490_13 = Space::new();
  let mut v1490_13_cursor = (*s0).read_zipper();
  for v1490_13_byte in v1490_13_cursor.child_mask().iter() {
    v1490_13_cursor.descend_to_byte(v1490_13_byte);
    let v1490_13_tail = v1490_13_cursor.make_map();
    v1490_13_cursor.ascend(1);
    let v1490_13_head = Path::from_slice(&[v1490_13_byte]);
    let v1491_2: Space = singleton(&(v1490_13_head));
    let v1491_3: Space = intersect(&(*CONSTANT_7),&(v1491_2));
    let v1491_4: Space = if has_head(&(v1491_3)) { singleton(&[]) } else { Space::new() };
    drop(v1491_3);
    let v1491_5: Space = subtract(&(*CONSTANT_0),&(v1491_4));
    drop(v1491_4);
    let v1491_8: Space = if (v1491_5).is_empty() { Space::new() } else {
      let v1492_6: Path = concat_path(&(*p0),&(v1490_13_head));
      let v1492_7: Space = routine_156(c, &(v1492_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1490_13_tail));
      compose(&(v1491_5),&(v1492_7))
    };
    drop(v1491_5);
    let v1491_9: Space = intersect(&(*CONSTANT_7),&(v1491_2));
    drop(v1491_2);
    let v1491_10: Space = if has_head(&(v1491_9)) { singleton(&[]) } else { Space::new() };
    drop(v1491_9);
    let v1491_12: Space = if (v1491_10).is_empty() { Space::new() } else {
      let v1493_6: Path = concat_path(&(*p0),&(v1490_13_head));
      let mut v1493_11 = Space::new();
      let mut v1493_11_cursor = (v1490_13_tail).read_zipper();
      for v1493_11_byte in v1493_11_cursor.child_mask().iter() {
        v1493_11_cursor.descend_to_byte(v1493_11_byte);
        let v1493_11_tail = v1493_11_cursor.make_map();
        v1493_11_cursor.ascend(1);
        let v1493_11_head = Path::from_slice(&[v1493_11_byte]);
        let v1494_2: Space = singleton(&(v1493_11_head));
        let v1494_3: Space = intersect(&(*CONSTANT_7),&(v1494_2));
        let v1494_4: Space = if has_head(&(v1494_3)) { singleton(&[]) } else { Space::new() };
        drop(v1494_3);
        let v1494_5: Space = subtract(&(*CONSTANT_0),&(v1494_4));
        drop(v1494_4);
        let v1494_7: Space = if (v1494_5).is_empty() { Space::new() } else {
          let v1495_6: Space = routine_174(c, &(v1493_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1493_6), &(v1493_11_tail));
          compose(&(v1494_5),&(v1495_6))
        };
        drop(v1494_5);
        let v1494_8: Space = intersect(&(*CONSTANT_7),&(v1494_2));
        drop(v1494_2);
        let v1494_9: Space = if has_head(&(v1494_8)) { singleton(&[]) } else { Space::new() };
        drop(v1494_8);
        let v1494_11: Space = if (v1494_9).is_empty() { Space::new() } else {
          let v1496_10: Space = routine_175(c, &(v1493_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1493_6), &(v1493_11_tail));
          compose(&(v1494_9),&(v1496_10))
        };
        drop(v1494_9);
        let v1494_12: Space = unite(&(v1494_7),&(v1494_11));
        v1493_11.join_into((v1494_12).clone());
      }
      drop(v1493_11_cursor);
      drop(v1493_6);
      compose(&(v1491_10),&(v1493_11))
    };
    drop(v1491_10);
    let v1491_13: Space = unite(&(v1491_8),&(v1491_12));
    v1490_13.join_into((v1491_13).clone());
  }
  drop(v1490_13_cursor);
  (v1490_13).clone()
}

fn routine_157(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1497_16 = Space::new();
  let mut v1497_16_cursor = (*s0).read_zipper();
  for v1497_16_byte in v1497_16_cursor.child_mask().iter() {
    v1497_16_cursor.descend_to_byte(v1497_16_byte);
    let v1497_16_tail = v1497_16_cursor.make_map();
    v1497_16_cursor.ascend(1);
    let v1497_16_head = Path::from_slice(&[v1497_16_byte]);
    let v1498_2: Space = singleton(&(v1497_16_head));
    let v1498_3: Space = intersect(&(*CONSTANT_7),&(v1498_2));
    let v1498_4: Space = if has_head(&(v1498_3)) { singleton(&[]) } else { Space::new() };
    drop(v1498_3);
    let v1498_5: Space = subtract(&(*CONSTANT_0),&(v1498_4));
    drop(v1498_4);
    let v1498_7: Space = if (v1498_5).is_empty() { Space::new() } else {
      let mut v1499_6 = Space::new();
      let mut v1499_6_cursor = (v1497_16_tail).read_zipper();
      for v1499_6_byte in v1499_6_cursor.child_mask().iter() {
        v1499_6_cursor.descend_to_byte(v1499_6_byte);
        let v1499_6_tail = v1499_6_cursor.make_map();
        v1499_6_cursor.ascend(1);
        let v1499_6_head = Path::from_slice(&[v1499_6_byte]);
        let v1500_2: Space = singleton(&(v1499_6_head));
        let v1500_3: Space = intersect(&(*CONSTANT_7),&(v1500_2));
        let v1500_4: Space = if has_head(&(v1500_3)) { singleton(&[]) } else { Space::new() };
        drop(v1500_3);
        let v1500_5: Space = subtract(&(*CONSTANT_0),&(v1500_4));
        drop(v1500_4);
        let v1500_8: Space = if (v1500_5).is_empty() { Space::new() } else {
          let v1501_6: Path = concat_path(&(v1497_16_head),&(v1499_6_head));
          let v1501_7: Space = routine_174(c, &(v1501_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1499_6_tail));
          compose(&(v1500_5),&(v1501_7))
        };
        drop(v1500_5);
        let v1500_9: Space = intersect(&(*CONSTANT_7),&(v1500_2));
        drop(v1500_2);
        let v1500_10: Space = if has_head(&(v1500_9)) { singleton(&[]) } else { Space::new() };
        drop(v1500_9);
        let v1500_12: Space = if (v1500_10).is_empty() { Space::new() } else {
          let v1502_6: Path = concat_path(&(v1497_16_head),&(v1499_6_head));
          let v1502_11: Space = routine_175(c, &(v1502_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1499_6_tail));
          drop(v1502_6);
          compose(&(v1500_10),&(v1502_11))
        };
        drop(v1500_10);
        let v1500_13: Space = unite(&(v1500_8),&(v1500_12));
        v1499_6.join_into((v1500_13).clone());
      }
      drop(v1499_6_cursor);
      compose(&(v1498_5),&(v1499_6))
    };
    drop(v1498_5);
    let v1498_8: Space = intersect(&(*CONSTANT_7),&(v1498_2));
    drop(v1498_2);
    let v1498_9: Space = if has_head(&(v1498_8)) { singleton(&[]) } else { Space::new() };
    drop(v1498_8);
    let v1498_11: Space = if (v1498_9).is_empty() { Space::new() } else {
      let mut v1503_10 = Space::new();
      let mut v1503_10_cursor = (v1497_16_tail).read_zipper();
      for v1503_10_byte in v1503_10_cursor.child_mask().iter() {
        v1503_10_cursor.descend_to_byte(v1503_10_byte);
        let v1503_10_tail = v1503_10_cursor.make_map();
        v1503_10_cursor.ascend(1);
        let v1503_10_head = Path::from_slice(&[v1503_10_byte]);
        let v1504_2: Space = singleton(&(v1503_10_head));
        let v1504_3: Space = intersect(&(*CONSTANT_7),&(v1504_2));
        let v1504_4: Space = if has_head(&(v1504_3)) { singleton(&[]) } else { Space::new() };
        drop(v1504_3);
        let v1504_5: Space = subtract(&(*CONSTANT_0),&(v1504_4));
        drop(v1504_4);
        let v1504_7: Space = if (v1504_5).is_empty() { Space::new() } else {
          let v1505_6: Space = routine_192(c, &(v1503_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1497_16_head), &(v1503_10_tail));
          compose(&(v1504_5),&(v1505_6))
        };
        drop(v1504_5);
        let v1504_8: Space = intersect(&(*CONSTANT_7),&(v1504_2));
        drop(v1504_2);
        let v1504_9: Space = if has_head(&(v1504_8)) { singleton(&[]) } else { Space::new() };
        drop(v1504_8);
        let v1504_11: Space = if (v1504_9).is_empty() { Space::new() } else {
          let v1506_10: Space = routine_193(c, &(v1503_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1497_16_head), &(v1503_10_tail));
          compose(&(v1504_9),&(v1506_10))
        };
        drop(v1504_9);
        let v1504_12: Space = unite(&(v1504_7),&(v1504_11));
        v1503_10.join_into((v1504_12).clone());
      }
      drop(v1503_10_cursor);
      compose(&(v1498_9),&(v1503_10))
    };
    drop(v1498_9);
    let v1498_12: Space = unite(&(v1498_7),&(v1498_11));
    v1497_16.join_into((v1498_12).clone());
  }
  drop(v1497_16_cursor);
  (v1497_16).clone()
}

fn routine_158(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1507_13 = Space::new();
  let mut v1507_13_cursor = (*s0).read_zipper();
  for v1507_13_byte in v1507_13_cursor.child_mask().iter() {
    v1507_13_cursor.descend_to_byte(v1507_13_byte);
    let v1507_13_tail = v1507_13_cursor.make_map();
    v1507_13_cursor.ascend(1);
    let v1507_13_head = Path::from_slice(&[v1507_13_byte]);
    let v1508_2: Space = singleton(&(v1507_13_head));
    let v1508_3: Space = intersect(&(*CONSTANT_7),&(v1508_2));
    let v1508_4: Space = if has_head(&(v1508_3)) { singleton(&[]) } else { Space::new() };
    drop(v1508_3);
    let v1508_5: Space = subtract(&(*CONSTANT_0),&(v1508_4));
    drop(v1508_4);
    let v1508_8: Space = if (v1508_5).is_empty() { Space::new() } else {
      let v1509_6: Path = concat_path(&(*p0),&(v1507_13_head));
      let v1509_7: Space = routine_158(c, &(v1509_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1507_13_tail));
      compose(&(v1508_5),&(v1509_7))
    };
    drop(v1508_5);
    let v1508_9: Space = intersect(&(*CONSTANT_7),&(v1508_2));
    drop(v1508_2);
    let v1508_10: Space = if has_head(&(v1508_9)) { singleton(&[]) } else { Space::new() };
    drop(v1508_9);
    let v1508_12: Space = if (v1508_10).is_empty() { Space::new() } else {
      let v1510_6: Path = concat_path(&(*p0),&(v1507_13_head));
      let mut v1510_11 = Space::new();
      let mut v1510_11_cursor = (v1507_13_tail).read_zipper();
      for v1510_11_byte in v1510_11_cursor.child_mask().iter() {
        v1510_11_cursor.descend_to_byte(v1510_11_byte);
        let v1510_11_tail = v1510_11_cursor.make_map();
        v1510_11_cursor.ascend(1);
        let v1510_11_head = Path::from_slice(&[v1510_11_byte]);
        let v1511_2: Space = singleton(&(v1510_11_head));
        let v1511_3: Space = intersect(&(*CONSTANT_7),&(v1511_2));
        let v1511_4: Space = if has_head(&(v1511_3)) { singleton(&[]) } else { Space::new() };
        drop(v1511_3);
        let v1511_5: Space = subtract(&(*CONSTANT_0),&(v1511_4));
        drop(v1511_4);
        let v1511_7: Space = if (v1511_5).is_empty() { Space::new() } else {
          let v1512_6: Space = routine_176(c, &(v1510_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1510_6), &(v1510_11_tail));
          compose(&(v1511_5),&(v1512_6))
        };
        drop(v1511_5);
        let v1511_8: Space = intersect(&(*CONSTANT_7),&(v1511_2));
        drop(v1511_2);
        let v1511_9: Space = if has_head(&(v1511_8)) { singleton(&[]) } else { Space::new() };
        drop(v1511_8);
        let v1511_11: Space = if (v1511_9).is_empty() { Space::new() } else {
          let v1513_10: Space = routine_177(c, &(v1510_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1510_6), &(v1510_11_tail));
          compose(&(v1511_9),&(v1513_10))
        };
        drop(v1511_9);
        let v1511_12: Space = unite(&(v1511_7),&(v1511_11));
        v1510_11.join_into((v1511_12).clone());
      }
      drop(v1510_11_cursor);
      drop(v1510_6);
      compose(&(v1508_10),&(v1510_11))
    };
    drop(v1508_10);
    let v1508_13: Space = unite(&(v1508_8),&(v1508_12));
    v1507_13.join_into((v1508_13).clone());
  }
  drop(v1507_13_cursor);
  (v1507_13).clone()
}

fn routine_159(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1514_16 = Space::new();
  let mut v1514_16_cursor = (*s0).read_zipper();
  for v1514_16_byte in v1514_16_cursor.child_mask().iter() {
    v1514_16_cursor.descend_to_byte(v1514_16_byte);
    let v1514_16_tail = v1514_16_cursor.make_map();
    v1514_16_cursor.ascend(1);
    let v1514_16_head = Path::from_slice(&[v1514_16_byte]);
    let v1515_2: Space = singleton(&(v1514_16_head));
    let v1515_3: Space = intersect(&(*CONSTANT_7),&(v1515_2));
    let v1515_4: Space = if has_head(&(v1515_3)) { singleton(&[]) } else { Space::new() };
    drop(v1515_3);
    let v1515_5: Space = subtract(&(*CONSTANT_0),&(v1515_4));
    drop(v1515_4);
    let v1515_7: Space = if (v1515_5).is_empty() { Space::new() } else {
      let mut v1516_6 = Space::new();
      let mut v1516_6_cursor = (v1514_16_tail).read_zipper();
      for v1516_6_byte in v1516_6_cursor.child_mask().iter() {
        v1516_6_cursor.descend_to_byte(v1516_6_byte);
        let v1516_6_tail = v1516_6_cursor.make_map();
        v1516_6_cursor.ascend(1);
        let v1516_6_head = Path::from_slice(&[v1516_6_byte]);
        let v1517_2: Space = singleton(&(v1516_6_head));
        let v1517_3: Space = intersect(&(*CONSTANT_7),&(v1517_2));
        let v1517_4: Space = if has_head(&(v1517_3)) { singleton(&[]) } else { Space::new() };
        drop(v1517_3);
        let v1517_5: Space = subtract(&(*CONSTANT_0),&(v1517_4));
        drop(v1517_4);
        let v1517_8: Space = if (v1517_5).is_empty() { Space::new() } else {
          let v1518_6: Path = concat_path(&(v1514_16_head),&(v1516_6_head));
          let v1518_7: Space = routine_176(c, &(v1518_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1516_6_tail));
          compose(&(v1517_5),&(v1518_7))
        };
        drop(v1517_5);
        let v1517_9: Space = intersect(&(*CONSTANT_7),&(v1517_2));
        drop(v1517_2);
        let v1517_10: Space = if has_head(&(v1517_9)) { singleton(&[]) } else { Space::new() };
        drop(v1517_9);
        let v1517_12: Space = if (v1517_10).is_empty() { Space::new() } else {
          let v1519_6: Path = concat_path(&(v1514_16_head),&(v1516_6_head));
          let v1519_11: Space = routine_177(c, &(v1519_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1516_6_tail));
          drop(v1519_6);
          compose(&(v1517_10),&(v1519_11))
        };
        drop(v1517_10);
        let v1517_13: Space = unite(&(v1517_8),&(v1517_12));
        v1516_6.join_into((v1517_13).clone());
      }
      drop(v1516_6_cursor);
      compose(&(v1515_5),&(v1516_6))
    };
    drop(v1515_5);
    let v1515_8: Space = intersect(&(*CONSTANT_7),&(v1515_2));
    drop(v1515_2);
    let v1515_9: Space = if has_head(&(v1515_8)) { singleton(&[]) } else { Space::new() };
    drop(v1515_8);
    let v1515_11: Space = if (v1515_9).is_empty() { Space::new() } else {
      let mut v1520_10 = Space::new();
      let mut v1520_10_cursor = (v1514_16_tail).read_zipper();
      for v1520_10_byte in v1520_10_cursor.child_mask().iter() {
        v1520_10_cursor.descend_to_byte(v1520_10_byte);
        let v1520_10_tail = v1520_10_cursor.make_map();
        v1520_10_cursor.ascend(1);
        let v1520_10_head = Path::from_slice(&[v1520_10_byte]);
        let v1521_2: Space = singleton(&(v1520_10_head));
        let v1521_3: Space = intersect(&(*CONSTANT_7),&(v1521_2));
        let v1521_4: Space = if has_head(&(v1521_3)) { singleton(&[]) } else { Space::new() };
        drop(v1521_3);
        let v1521_5: Space = subtract(&(*CONSTANT_0),&(v1521_4));
        drop(v1521_4);
        let v1521_7: Space = if (v1521_5).is_empty() { Space::new() } else {
          let v1522_6: Space = routine_194(c, &(v1520_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1514_16_head), &(v1520_10_tail));
          compose(&(v1521_5),&(v1522_6))
        };
        drop(v1521_5);
        let v1521_8: Space = intersect(&(*CONSTANT_7),&(v1521_2));
        drop(v1521_2);
        let v1521_9: Space = if has_head(&(v1521_8)) { singleton(&[]) } else { Space::new() };
        drop(v1521_8);
        let v1521_11: Space = if (v1521_9).is_empty() { Space::new() } else {
          let v1523_10: Space = routine_195(c, &(v1520_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1514_16_head), &(v1520_10_tail));
          compose(&(v1521_9),&(v1523_10))
        };
        drop(v1521_9);
        let v1521_12: Space = unite(&(v1521_7),&(v1521_11));
        v1520_10.join_into((v1521_12).clone());
      }
      drop(v1520_10_cursor);
      compose(&(v1515_9),&(v1520_10))
    };
    drop(v1515_9);
    let v1515_12: Space = unite(&(v1515_7),&(v1515_11));
    v1514_16.join_into((v1515_12).clone());
  }
  drop(v1514_16_cursor);
  (v1514_16).clone()
}

fn routine_160(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1524_13 = Space::new();
  let mut v1524_13_cursor = (*s0).read_zipper();
  for v1524_13_byte in v1524_13_cursor.child_mask().iter() {
    v1524_13_cursor.descend_to_byte(v1524_13_byte);
    let v1524_13_tail = v1524_13_cursor.make_map();
    v1524_13_cursor.ascend(1);
    let v1524_13_head = Path::from_slice(&[v1524_13_byte]);
    let v1525_2: Space = singleton(&(v1524_13_head));
    let v1525_3: Space = intersect(&(*CONSTANT_7),&(v1525_2));
    let v1525_4: Space = if has_head(&(v1525_3)) { singleton(&[]) } else { Space::new() };
    drop(v1525_3);
    let v1525_5: Space = subtract(&(*CONSTANT_0),&(v1525_4));
    drop(v1525_4);
    let v1525_8: Space = if (v1525_5).is_empty() { Space::new() } else {
      let v1526_6: Path = concat_path(&(*p0),&(v1524_13_head));
      let v1526_7: Space = routine_160(c, &(v1526_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1524_13_tail));
      compose(&(v1525_5),&(v1526_7))
    };
    drop(v1525_5);
    let v1525_9: Space = intersect(&(*CONSTANT_7),&(v1525_2));
    drop(v1525_2);
    let v1525_10: Space = if has_head(&(v1525_9)) { singleton(&[]) } else { Space::new() };
    drop(v1525_9);
    let v1525_12: Space = if (v1525_10).is_empty() { Space::new() } else {
      let v1527_6: Path = concat_path(&(*p0),&(v1524_13_head));
      let mut v1527_11 = Space::new();
      let mut v1527_11_cursor = (v1524_13_tail).read_zipper();
      for v1527_11_byte in v1527_11_cursor.child_mask().iter() {
        v1527_11_cursor.descend_to_byte(v1527_11_byte);
        let v1527_11_tail = v1527_11_cursor.make_map();
        v1527_11_cursor.ascend(1);
        let v1527_11_head = Path::from_slice(&[v1527_11_byte]);
        let v1528_2: Space = singleton(&(v1527_11_head));
        let v1528_3: Space = intersect(&(*CONSTANT_7),&(v1528_2));
        let v1528_4: Space = if has_head(&(v1528_3)) { singleton(&[]) } else { Space::new() };
        drop(v1528_3);
        let v1528_5: Space = subtract(&(*CONSTANT_0),&(v1528_4));
        drop(v1528_4);
        let v1528_7: Space = if (v1528_5).is_empty() { Space::new() } else {
          let v1529_6: Space = routine_178(c, &(v1527_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1527_6), &(v1527_11_tail));
          compose(&(v1528_5),&(v1529_6))
        };
        drop(v1528_5);
        let v1528_8: Space = intersect(&(*CONSTANT_7),&(v1528_2));
        drop(v1528_2);
        let v1528_9: Space = if has_head(&(v1528_8)) { singleton(&[]) } else { Space::new() };
        drop(v1528_8);
        let v1528_11: Space = if (v1528_9).is_empty() { Space::new() } else {
          let v1530_10: Space = routine_179(c, &(v1527_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1527_6), &(v1527_11_tail));
          compose(&(v1528_9),&(v1530_10))
        };
        drop(v1528_9);
        let v1528_12: Space = unite(&(v1528_7),&(v1528_11));
        v1527_11.join_into((v1528_12).clone());
      }
      drop(v1527_11_cursor);
      drop(v1527_6);
      compose(&(v1525_10),&(v1527_11))
    };
    drop(v1525_10);
    let v1525_13: Space = unite(&(v1525_8),&(v1525_12));
    v1524_13.join_into((v1525_13).clone());
  }
  drop(v1524_13_cursor);
  (v1524_13).clone()
}

fn routine_161(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1531_16 = Space::new();
  let mut v1531_16_cursor = (*s0).read_zipper();
  for v1531_16_byte in v1531_16_cursor.child_mask().iter() {
    v1531_16_cursor.descend_to_byte(v1531_16_byte);
    let v1531_16_tail = v1531_16_cursor.make_map();
    v1531_16_cursor.ascend(1);
    let v1531_16_head = Path::from_slice(&[v1531_16_byte]);
    let v1532_2: Space = singleton(&(v1531_16_head));
    let v1532_3: Space = intersect(&(*CONSTANT_7),&(v1532_2));
    let v1532_4: Space = if has_head(&(v1532_3)) { singleton(&[]) } else { Space::new() };
    drop(v1532_3);
    let v1532_5: Space = subtract(&(*CONSTANT_0),&(v1532_4));
    drop(v1532_4);
    let v1532_7: Space = if (v1532_5).is_empty() { Space::new() } else {
      let mut v1533_6 = Space::new();
      let mut v1533_6_cursor = (v1531_16_tail).read_zipper();
      for v1533_6_byte in v1533_6_cursor.child_mask().iter() {
        v1533_6_cursor.descend_to_byte(v1533_6_byte);
        let v1533_6_tail = v1533_6_cursor.make_map();
        v1533_6_cursor.ascend(1);
        let v1533_6_head = Path::from_slice(&[v1533_6_byte]);
        let v1534_2: Space = singleton(&(v1533_6_head));
        let v1534_3: Space = intersect(&(*CONSTANT_7),&(v1534_2));
        let v1534_4: Space = if has_head(&(v1534_3)) { singleton(&[]) } else { Space::new() };
        drop(v1534_3);
        let v1534_5: Space = subtract(&(*CONSTANT_0),&(v1534_4));
        drop(v1534_4);
        let v1534_8: Space = if (v1534_5).is_empty() { Space::new() } else {
          let v1535_6: Path = concat_path(&(v1531_16_head),&(v1533_6_head));
          let v1535_7: Space = routine_178(c, &(v1535_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1533_6_tail));
          compose(&(v1534_5),&(v1535_7))
        };
        drop(v1534_5);
        let v1534_9: Space = intersect(&(*CONSTANT_7),&(v1534_2));
        drop(v1534_2);
        let v1534_10: Space = if has_head(&(v1534_9)) { singleton(&[]) } else { Space::new() };
        drop(v1534_9);
        let v1534_12: Space = if (v1534_10).is_empty() { Space::new() } else {
          let v1536_6: Path = concat_path(&(v1531_16_head),&(v1533_6_head));
          let v1536_11: Space = routine_179(c, &(v1536_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1533_6_tail));
          drop(v1536_6);
          compose(&(v1534_10),&(v1536_11))
        };
        drop(v1534_10);
        let v1534_13: Space = unite(&(v1534_8),&(v1534_12));
        v1533_6.join_into((v1534_13).clone());
      }
      drop(v1533_6_cursor);
      compose(&(v1532_5),&(v1533_6))
    };
    drop(v1532_5);
    let v1532_8: Space = intersect(&(*CONSTANT_7),&(v1532_2));
    drop(v1532_2);
    let v1532_9: Space = if has_head(&(v1532_8)) { singleton(&[]) } else { Space::new() };
    drop(v1532_8);
    let v1532_11: Space = if (v1532_9).is_empty() { Space::new() } else {
      let mut v1537_10 = Space::new();
      let mut v1537_10_cursor = (v1531_16_tail).read_zipper();
      for v1537_10_byte in v1537_10_cursor.child_mask().iter() {
        v1537_10_cursor.descend_to_byte(v1537_10_byte);
        let v1537_10_tail = v1537_10_cursor.make_map();
        v1537_10_cursor.ascend(1);
        let v1537_10_head = Path::from_slice(&[v1537_10_byte]);
        let v1538_2: Space = singleton(&(v1537_10_head));
        let v1538_3: Space = intersect(&(*CONSTANT_7),&(v1538_2));
        let v1538_4: Space = if has_head(&(v1538_3)) { singleton(&[]) } else { Space::new() };
        drop(v1538_3);
        let v1538_5: Space = subtract(&(*CONSTANT_0),&(v1538_4));
        drop(v1538_4);
        let v1538_7: Space = if (v1538_5).is_empty() { Space::new() } else {
          let v1539_6: Space = routine_196(c, &(v1537_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1531_16_head), &(v1537_10_tail));
          compose(&(v1538_5),&(v1539_6))
        };
        drop(v1538_5);
        let v1538_8: Space = intersect(&(*CONSTANT_7),&(v1538_2));
        drop(v1538_2);
        let v1538_9: Space = if has_head(&(v1538_8)) { singleton(&[]) } else { Space::new() };
        drop(v1538_8);
        let v1538_11: Space = if (v1538_9).is_empty() { Space::new() } else {
          let v1540_10: Space = routine_197(c, &(v1537_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1531_16_head), &(v1537_10_tail));
          compose(&(v1538_9),&(v1540_10))
        };
        drop(v1538_9);
        let v1538_12: Space = unite(&(v1538_7),&(v1538_11));
        v1537_10.join_into((v1538_12).clone());
      }
      drop(v1537_10_cursor);
      compose(&(v1532_9),&(v1537_10))
    };
    drop(v1532_9);
    let v1532_12: Space = unite(&(v1532_7),&(v1532_11));
    v1531_16.join_into((v1532_12).clone());
  }
  drop(v1531_16_cursor);
  (v1531_16).clone()
}

fn routine_162(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1541_13 = Space::new();
  let mut v1541_13_cursor = (*s0).read_zipper();
  for v1541_13_byte in v1541_13_cursor.child_mask().iter() {
    v1541_13_cursor.descend_to_byte(v1541_13_byte);
    let v1541_13_tail = v1541_13_cursor.make_map();
    v1541_13_cursor.ascend(1);
    let v1541_13_head = Path::from_slice(&[v1541_13_byte]);
    let v1542_2: Space = singleton(&(v1541_13_head));
    let v1542_3: Space = intersect(&(*CONSTANT_7),&(v1542_2));
    let v1542_4: Space = if has_head(&(v1542_3)) { singleton(&[]) } else { Space::new() };
    drop(v1542_3);
    let v1542_5: Space = subtract(&(*CONSTANT_0),&(v1542_4));
    drop(v1542_4);
    let v1542_8: Space = if (v1542_5).is_empty() { Space::new() } else {
      let v1543_6: Path = concat_path(&(*p0),&(v1541_13_head));
      let v1543_7: Space = routine_162(c, &(v1543_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1541_13_tail));
      compose(&(v1542_5),&(v1543_7))
    };
    drop(v1542_5);
    let v1542_9: Space = intersect(&(*CONSTANT_7),&(v1542_2));
    drop(v1542_2);
    let v1542_10: Space = if has_head(&(v1542_9)) { singleton(&[]) } else { Space::new() };
    drop(v1542_9);
    let v1542_12: Space = if (v1542_10).is_empty() { Space::new() } else {
      let v1544_6: Path = concat_path(&(*p0),&(v1541_13_head));
      let mut v1544_11 = Space::new();
      let mut v1544_11_cursor = (v1541_13_tail).read_zipper();
      for v1544_11_byte in v1544_11_cursor.child_mask().iter() {
        v1544_11_cursor.descend_to_byte(v1544_11_byte);
        let v1544_11_tail = v1544_11_cursor.make_map();
        v1544_11_cursor.ascend(1);
        let v1544_11_head = Path::from_slice(&[v1544_11_byte]);
        let v1545_2: Space = singleton(&(v1544_11_head));
        let v1545_3: Space = intersect(&(*CONSTANT_7),&(v1545_2));
        let v1545_4: Space = if has_head(&(v1545_3)) { singleton(&[]) } else { Space::new() };
        drop(v1545_3);
        let v1545_5: Space = subtract(&(*CONSTANT_0),&(v1545_4));
        drop(v1545_4);
        let v1545_7: Space = if (v1545_5).is_empty() { Space::new() } else {
          let v1546_6: Space = routine_180(c, &(v1544_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1544_6), &(v1544_11_tail));
          compose(&(v1545_5),&(v1546_6))
        };
        drop(v1545_5);
        let v1545_8: Space = intersect(&(*CONSTANT_7),&(v1545_2));
        drop(v1545_2);
        let v1545_9: Space = if has_head(&(v1545_8)) { singleton(&[]) } else { Space::new() };
        drop(v1545_8);
        let v1545_11: Space = if (v1545_9).is_empty() { Space::new() } else {
          let v1547_10: Space = routine_181(c, &(v1544_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v1544_6), &(v1544_11_tail));
          compose(&(v1545_9),&(v1547_10))
        };
        drop(v1545_9);
        let v1545_12: Space = unite(&(v1545_7),&(v1545_11));
        v1544_11.join_into((v1545_12).clone());
      }
      drop(v1544_11_cursor);
      drop(v1544_6);
      compose(&(v1542_10),&(v1544_11))
    };
    drop(v1542_10);
    let v1542_13: Space = unite(&(v1542_8),&(v1542_12));
    v1541_13.join_into((v1542_13).clone());
  }
  drop(v1541_13_cursor);
  (v1541_13).clone()
}

fn routine_163(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v1548_16 = Space::new();
  let mut v1548_16_cursor = (*s0).read_zipper();
  for v1548_16_byte in v1548_16_cursor.child_mask().iter() {
    v1548_16_cursor.descend_to_byte(v1548_16_byte);
    let v1548_16_tail = v1548_16_cursor.make_map();
    v1548_16_cursor.ascend(1);
    let v1548_16_head = Path::from_slice(&[v1548_16_byte]);
    let v1549_2: Space = singleton(&(v1548_16_head));
    let v1549_3: Space = intersect(&(*CONSTANT_7),&(v1549_2));
    let v1549_4: Space = if has_head(&(v1549_3)) { singleton(&[]) } else { Space::new() };
    drop(v1549_3);
    let v1549_5: Space = subtract(&(*CONSTANT_0),&(v1549_4));
    drop(v1549_4);
    let v1549_7: Space = if (v1549_5).is_empty() { Space::new() } else {
      let mut v1550_6 = Space::new();
      let mut v1550_6_cursor = (v1548_16_tail).read_zipper();
      for v1550_6_byte in v1550_6_cursor.child_mask().iter() {
        v1550_6_cursor.descend_to_byte(v1550_6_byte);
        let v1550_6_tail = v1550_6_cursor.make_map();
        v1550_6_cursor.ascend(1);
        let v1550_6_head = Path::from_slice(&[v1550_6_byte]);
        let v1551_2: Space = singleton(&(v1550_6_head));
        let v1551_3: Space = intersect(&(*CONSTANT_7),&(v1551_2));
        let v1551_4: Space = if has_head(&(v1551_3)) { singleton(&[]) } else { Space::new() };
        drop(v1551_3);
        let v1551_5: Space = subtract(&(*CONSTANT_0),&(v1551_4));
        drop(v1551_4);
        let v1551_8: Space = if (v1551_5).is_empty() { Space::new() } else {
          let v1552_6: Path = concat_path(&(v1548_16_head),&(v1550_6_head));
          let v1552_7: Space = routine_180(c, &(v1552_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1550_6_tail));
          compose(&(v1551_5),&(v1552_7))
        };
        drop(v1551_5);
        let v1551_9: Space = intersect(&(*CONSTANT_7),&(v1551_2));
        drop(v1551_2);
        let v1551_10: Space = if has_head(&(v1551_9)) { singleton(&[]) } else { Space::new() };
        drop(v1551_9);
        let v1551_12: Space = if (v1551_10).is_empty() { Space::new() } else {
          let v1553_6: Path = concat_path(&(v1548_16_head),&(v1550_6_head));
          let v1553_11: Space = routine_181(c, &(v1553_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1550_6_tail));
          drop(v1553_6);
          compose(&(v1551_10),&(v1553_11))
        };
        drop(v1551_10);
        let v1551_13: Space = unite(&(v1551_8),&(v1551_12));
        v1550_6.join_into((v1551_13).clone());
      }
      drop(v1550_6_cursor);
      compose(&(v1549_5),&(v1550_6))
    };
    drop(v1549_5);
    let v1549_8: Space = intersect(&(*CONSTANT_7),&(v1549_2));
    drop(v1549_2);
    let v1549_9: Space = if has_head(&(v1549_8)) { singleton(&[]) } else { Space::new() };
    drop(v1549_8);
    let v1549_11: Space = if (v1549_9).is_empty() { Space::new() } else {
      let mut v1554_10 = Space::new();
      let mut v1554_10_cursor = (v1548_16_tail).read_zipper();
      for v1554_10_byte in v1554_10_cursor.child_mask().iter() {
        v1554_10_cursor.descend_to_byte(v1554_10_byte);
        let v1554_10_tail = v1554_10_cursor.make_map();
        v1554_10_cursor.ascend(1);
        let v1554_10_head = Path::from_slice(&[v1554_10_byte]);
        let v1555_2: Space = singleton(&(v1554_10_head));
        let v1555_3: Space = intersect(&(*CONSTANT_7),&(v1555_2));
        let v1555_4: Space = if has_head(&(v1555_3)) { singleton(&[]) } else { Space::new() };
        drop(v1555_3);
        let v1555_5: Space = subtract(&(*CONSTANT_0),&(v1555_4));
        drop(v1555_4);
        let v1555_7: Space = if (v1555_5).is_empty() { Space::new() } else {
          let v1556_6: Space = routine_198(c, &(v1554_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1548_16_head), &(v1554_10_tail));
          compose(&(v1555_5),&(v1556_6))
        };
        drop(v1555_5);
        let v1555_8: Space = intersect(&(*CONSTANT_7),&(v1555_2));
        drop(v1555_2);
        let v1555_9: Space = if has_head(&(v1555_8)) { singleton(&[]) } else { Space::new() };
        drop(v1555_8);
        let v1555_11: Space = if (v1555_9).is_empty() { Space::new() } else {
          let v1557_10: Space = routine_199(c, &(v1554_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v1548_16_head), &(v1554_10_tail));
          compose(&(v1555_9),&(v1557_10))
        };
        drop(v1555_9);
        let v1555_12: Space = unite(&(v1555_7),&(v1555_11));
        v1554_10.join_into((v1555_12).clone());
      }
      drop(v1554_10_cursor);
      compose(&(v1549_9),&(v1554_10))
    };
    drop(v1549_9);
    let v1549_12: Space = unite(&(v1549_7),&(v1549_11));
    v1548_16.join_into((v1549_12).clone());
  }
  drop(v1548_16_cursor);
  (v1548_16).clone()
}

fn routine_164(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1558_14 = Space::new();
  let mut v1558_14_cursor = (*s0).read_zipper();
  for v1558_14_byte in v1558_14_cursor.child_mask().iter() {
    v1558_14_cursor.descend_to_byte(v1558_14_byte);
    let v1558_14_tail = v1558_14_cursor.make_map();
    v1558_14_cursor.ascend(1);
    let v1558_14_head = Path::from_slice(&[v1558_14_byte]);
    let v1559_2: Space = singleton(&(v1558_14_head));
    let v1559_3: Space = intersect(&(*CONSTANT_7),&(v1559_2));
    let v1559_4: Space = if has_head(&(v1559_3)) { singleton(&[]) } else { Space::new() };
    drop(v1559_3);
    let v1559_5: Space = subtract(&(*CONSTANT_0),&(v1559_4));
    drop(v1559_4);
    let v1559_8: Space = if (v1559_5).is_empty() { Space::new() } else {
      let v1560_6: Path = concat_path(&(*p0),&(v1558_14_head));
      let v1560_7: Space = routine_164(c, &(v1560_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1558_14_tail));
      compose(&(v1559_5),&(v1560_7))
    };
    drop(v1559_5);
    let v1559_9: Space = intersect(&(*CONSTANT_7),&(v1559_2));
    drop(v1559_2);
    let v1559_10: Space = if has_head(&(v1559_9)) { singleton(&[]) } else { Space::new() };
    drop(v1559_9);
    let v1559_12: Space = if (v1559_10).is_empty() { Space::new() } else {
      let v1561_6: Path = concat_path(&(*p0),&(v1558_14_head));
      let mut v1561_11 = Space::new();
      let mut v1561_11_cursor = (v1558_14_tail).read_zipper();
      for v1561_11_byte in v1561_11_cursor.child_mask().iter() {
        v1561_11_cursor.descend_to_byte(v1561_11_byte);
        let v1561_11_tail = v1561_11_cursor.make_map();
        v1561_11_cursor.ascend(1);
        let v1561_11_head = Path::from_slice(&[v1561_11_byte]);
        let v1562_2: Space = singleton(&(v1561_11_head));
        let v1562_3: Space = intersect(&(*CONSTANT_7),&(v1562_2));
        let v1562_4: Space = if has_head(&(v1562_3)) { singleton(&[]) } else { Space::new() };
        drop(v1562_3);
        let v1562_5: Space = subtract(&(*CONSTANT_0),&(v1562_4));
        drop(v1562_4);
        let v1562_7: Space = if (v1562_5).is_empty() { Space::new() } else {
          let v1563_6: Space = routine_182(c, &(v1561_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1561_6), &(v1561_11_tail));
          compose(&(v1562_5),&(v1563_6))
        };
        drop(v1562_5);
        let v1562_8: Space = intersect(&(*CONSTANT_7),&(v1562_2));
        drop(v1562_2);
        let v1562_9: Space = if has_head(&(v1562_8)) { singleton(&[]) } else { Space::new() };
        drop(v1562_8);
        let v1562_11: Space = if (v1562_9).is_empty() { Space::new() } else {
          let v1564_10: Space = routine_183(c, &(v1561_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1561_6), &(v1561_11_tail));
          compose(&(v1562_9),&(v1564_10))
        };
        drop(v1562_9);
        let v1562_12: Space = unite(&(v1562_7),&(v1562_11));
        v1561_11.join_into((v1562_12).clone());
      }
      drop(v1561_11_cursor);
      drop(v1561_6);
      compose(&(v1559_10),&(v1561_11))
    };
    drop(v1559_10);
    let v1559_13: Space = unite(&(v1559_8),&(v1559_12));
    v1558_14.join_into((v1559_13).clone());
  }
  drop(v1558_14_cursor);
  (v1558_14).clone()
}

fn routine_165(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let v1565_13: Path = concat_path(&(*CONSTANT_22),&(*p1));
  let v1565_14: Space = singleton(&(v1565_13));
  drop(v1565_13);
  let v1565_15: Space = unite(&(*CONSTANT_32),&(v1565_14));
  drop(v1565_14);
  let v1565_17: Path = concat_path(&(*CONSTANT_23),&(*p2));
  let v1565_18: Space = singleton(&(v1565_17));
  drop(v1565_17);
  let v1565_19: Space = unite(&(v1565_15),&(v1565_18));
  drop(v1565_15);
  drop(v1565_18);
  let v1565_21: Path = concat_path(&(*CONSTANT_24),&(*p3));
  let v1565_22: Space = singleton(&(v1565_21));
  drop(v1565_21);
  let v1565_23: Space = unite(&(v1565_19),&(v1565_22));
  drop(v1565_19);
  drop(v1565_22);
  let v1565_25: Path = concat_path(&(*CONSTANT_25),&(*p4));
  let v1565_26: Space = singleton(&(v1565_25));
  drop(v1565_25);
  let v1565_27: Space = unite(&(v1565_23),&(v1565_26));
  drop(v1565_23);
  drop(v1565_26);
  let v1565_29: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1565_30: Space = singleton(&(v1565_29));
  drop(v1565_29);
  let v1565_31: Space = unite(&(v1565_27),&(v1565_30));
  drop(v1565_27);
  drop(v1565_30);
  let v1565_33: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1565_34: Space = singleton(&(v1565_33));
  drop(v1565_33);
  let v1565_35: Space = unite(&(v1565_31),&(v1565_34));
  drop(v1565_31);
  drop(v1565_34);
  let v1565_37: Path = concat_path(&(*CONSTANT_28),&(*p0));
  let v1565_38: Space = singleton(&(v1565_37));
  drop(v1565_37);
  let v1565_39: Space = unite(&(v1565_35),&(v1565_38));
  drop(v1565_35);
  drop(v1565_38);
  let mut v1565_44 = Space::new();
  let mut v1565_44_cursor = (*s0).read_zipper();
  for v1565_44_byte in v1565_44_cursor.child_mask().iter() {
    v1565_44_cursor.descend_to_byte(v1565_44_byte);
    let v1565_44_tail = v1565_44_cursor.make_map();
    v1565_44_cursor.ascend(1);
    let v1565_44_head = Path::from_slice(&[v1565_44_byte]);
    let v1566_2: Space = singleton(&(v1565_44_head));
    let v1566_3: Space = intersect(&(*CONSTANT_7),&(v1566_2));
    let v1566_4: Space = if has_head(&(v1566_3)) { singleton(&[]) } else { Space::new() };
    drop(v1566_3);
    let v1566_5: Space = subtract(&(*CONSTANT_0),&(v1566_4));
    drop(v1566_4);
    let v1566_7: Space = if (v1566_5).is_empty() { Space::new() } else {
      let mut v1567_6 = Space::new();
      let mut v1567_6_cursor = (v1565_44_tail).read_zipper();
      for v1567_6_byte in v1567_6_cursor.child_mask().iter() {
        v1567_6_cursor.descend_to_byte(v1567_6_byte);
        let v1567_6_tail = v1567_6_cursor.make_map();
        v1567_6_cursor.ascend(1);
        let v1567_6_head = Path::from_slice(&[v1567_6_byte]);
        let v1568_2: Space = singleton(&(v1567_6_head));
        let v1568_3: Space = intersect(&(*CONSTANT_7),&(v1568_2));
        let v1568_4: Space = if has_head(&(v1568_3)) { singleton(&[]) } else { Space::new() };
        drop(v1568_3);
        let v1568_5: Space = subtract(&(*CONSTANT_0),&(v1568_4));
        drop(v1568_4);
        let v1568_8: Space = if (v1568_5).is_empty() { Space::new() } else {
          let v1569_6: Path = concat_path(&(v1565_44_head),&(v1567_6_head));
          let v1569_7: Space = routine_182(c, &(v1569_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1567_6_tail));
          compose(&(v1568_5),&(v1569_7))
        };
        drop(v1568_5);
        let v1568_9: Space = intersect(&(*CONSTANT_7),&(v1568_2));
        drop(v1568_2);
        let v1568_10: Space = if has_head(&(v1568_9)) { singleton(&[]) } else { Space::new() };
        drop(v1568_9);
        let v1568_12: Space = if (v1568_10).is_empty() { Space::new() } else {
          let v1570_6: Path = concat_path(&(v1565_44_head),&(v1567_6_head));
          let v1570_11: Space = routine_183(c, &(v1570_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1567_6_tail));
          drop(v1570_6);
          compose(&(v1568_10),&(v1570_11))
        };
        drop(v1568_10);
        let v1568_13: Space = unite(&(v1568_8),&(v1568_12));
        v1567_6.join_into((v1568_13).clone());
      }
      drop(v1567_6_cursor);
      compose(&(v1566_5),&(v1567_6))
    };
    drop(v1566_5);
    let v1566_8: Space = intersect(&(*CONSTANT_7),&(v1566_2));
    drop(v1566_2);
    let v1566_9: Space = if has_head(&(v1566_8)) { singleton(&[]) } else { Space::new() };
    drop(v1566_8);
    let v1566_13: Space = if (v1566_9).is_empty() { Space::new() } else {
      let v1571_10: Path = concat_path(&(*CONSTANT_29),&(v1565_44_head));
      let v1571_11: Space = singleton(&(v1571_10));
      drop(v1571_10);
      let v1571_12: Space = unite(&(v1565_39),&(v1571_11));
      drop(v1571_11);
      compose(&(v1566_9),&(v1571_12))
    };
    drop(v1566_9);
    let v1566_14: Space = unite(&(v1566_7),&(v1566_13));
    drop(v1566_13);
    v1565_44.join_into((v1566_14).clone());
  }
  drop(v1565_44_cursor);
  drop(v1565_39);
  (v1565_44).clone()
}

fn routine_166(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1572_14 = Space::new();
  let mut v1572_14_cursor = (*s0).read_zipper();
  for v1572_14_byte in v1572_14_cursor.child_mask().iter() {
    v1572_14_cursor.descend_to_byte(v1572_14_byte);
    let v1572_14_tail = v1572_14_cursor.make_map();
    v1572_14_cursor.ascend(1);
    let v1572_14_head = Path::from_slice(&[v1572_14_byte]);
    let v1573_2: Space = singleton(&(v1572_14_head));
    let v1573_3: Space = intersect(&(*CONSTANT_7),&(v1573_2));
    let v1573_4: Space = if has_head(&(v1573_3)) { singleton(&[]) } else { Space::new() };
    drop(v1573_3);
    let v1573_5: Space = subtract(&(*CONSTANT_0),&(v1573_4));
    drop(v1573_4);
    let v1573_8: Space = if (v1573_5).is_empty() { Space::new() } else {
      let v1574_6: Path = concat_path(&(*p0),&(v1572_14_head));
      let v1574_7: Space = routine_166(c, &(v1574_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1572_14_tail));
      compose(&(v1573_5),&(v1574_7))
    };
    drop(v1573_5);
    let v1573_9: Space = intersect(&(*CONSTANT_7),&(v1573_2));
    drop(v1573_2);
    let v1573_10: Space = if has_head(&(v1573_9)) { singleton(&[]) } else { Space::new() };
    drop(v1573_9);
    let v1573_12: Space = if (v1573_10).is_empty() { Space::new() } else {
      let v1575_6: Path = concat_path(&(*p0),&(v1572_14_head));
      let mut v1575_11 = Space::new();
      let mut v1575_11_cursor = (v1572_14_tail).read_zipper();
      for v1575_11_byte in v1575_11_cursor.child_mask().iter() {
        v1575_11_cursor.descend_to_byte(v1575_11_byte);
        let v1575_11_tail = v1575_11_cursor.make_map();
        v1575_11_cursor.ascend(1);
        let v1575_11_head = Path::from_slice(&[v1575_11_byte]);
        let v1576_2: Space = singleton(&(v1575_11_head));
        let v1576_3: Space = intersect(&(*CONSTANT_7),&(v1576_2));
        let v1576_4: Space = if has_head(&(v1576_3)) { singleton(&[]) } else { Space::new() };
        drop(v1576_3);
        let v1576_5: Space = subtract(&(*CONSTANT_0),&(v1576_4));
        drop(v1576_4);
        let v1576_7: Space = if (v1576_5).is_empty() { Space::new() } else {
          let v1577_6: Space = routine_184(c, &(v1575_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1575_6), &(v1575_11_tail));
          compose(&(v1576_5),&(v1577_6))
        };
        drop(v1576_5);
        let v1576_8: Space = intersect(&(*CONSTANT_7),&(v1576_2));
        drop(v1576_2);
        let v1576_9: Space = if has_head(&(v1576_8)) { singleton(&[]) } else { Space::new() };
        drop(v1576_8);
        let v1576_11: Space = if (v1576_9).is_empty() { Space::new() } else {
          let v1578_10: Space = routine_185(c, &(v1575_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1575_6), &(v1575_11_tail));
          compose(&(v1576_9),&(v1578_10))
        };
        drop(v1576_9);
        let v1576_12: Space = unite(&(v1576_7),&(v1576_11));
        v1575_11.join_into((v1576_12).clone());
      }
      drop(v1575_11_cursor);
      drop(v1575_6);
      compose(&(v1573_10),&(v1575_11))
    };
    drop(v1573_10);
    let v1573_13: Space = unite(&(v1573_8),&(v1573_12));
    v1572_14.join_into((v1573_13).clone());
  }
  drop(v1572_14_cursor);
  (v1572_14).clone()
}

fn routine_167(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let v1579_13: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1579_14: Space = singleton(&(v1579_13));
  drop(v1579_13);
  let v1579_15: Space = unite(&(*CONSTANT_33),&(v1579_14));
  drop(v1579_14);
  let v1579_17: Path = concat_path(&(*CONSTANT_23),&(*p2));
  let v1579_18: Space = singleton(&(v1579_17));
  drop(v1579_17);
  let v1579_19: Space = unite(&(v1579_15),&(v1579_18));
  drop(v1579_15);
  drop(v1579_18);
  let v1579_21: Path = concat_path(&(*CONSTANT_24),&(*p3));
  let v1579_22: Space = singleton(&(v1579_21));
  drop(v1579_21);
  let v1579_23: Space = unite(&(v1579_19),&(v1579_22));
  drop(v1579_19);
  drop(v1579_22);
  let v1579_25: Path = concat_path(&(*CONSTANT_25),&(*p4));
  let v1579_26: Space = singleton(&(v1579_25));
  drop(v1579_25);
  let v1579_27: Space = unite(&(v1579_23),&(v1579_26));
  drop(v1579_23);
  drop(v1579_26);
  let v1579_29: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1579_30: Space = singleton(&(v1579_29));
  drop(v1579_29);
  let v1579_31: Space = unite(&(v1579_27),&(v1579_30));
  drop(v1579_27);
  drop(v1579_30);
  let v1579_33: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1579_34: Space = singleton(&(v1579_33));
  drop(v1579_33);
  let v1579_35: Space = unite(&(v1579_31),&(v1579_34));
  drop(v1579_31);
  drop(v1579_34);
  let v1579_37: Path = concat_path(&(*CONSTANT_28),&(*p0));
  let v1579_38: Space = singleton(&(v1579_37));
  drop(v1579_37);
  let v1579_39: Space = unite(&(v1579_35),&(v1579_38));
  drop(v1579_35);
  drop(v1579_38);
  let mut v1579_44 = Space::new();
  let mut v1579_44_cursor = (*s0).read_zipper();
  for v1579_44_byte in v1579_44_cursor.child_mask().iter() {
    v1579_44_cursor.descend_to_byte(v1579_44_byte);
    let v1579_44_tail = v1579_44_cursor.make_map();
    v1579_44_cursor.ascend(1);
    let v1579_44_head = Path::from_slice(&[v1579_44_byte]);
    let v1580_2: Space = singleton(&(v1579_44_head));
    let v1580_3: Space = intersect(&(*CONSTANT_7),&(v1580_2));
    let v1580_4: Space = if has_head(&(v1580_3)) { singleton(&[]) } else { Space::new() };
    drop(v1580_3);
    let v1580_5: Space = subtract(&(*CONSTANT_0),&(v1580_4));
    drop(v1580_4);
    let v1580_7: Space = if (v1580_5).is_empty() { Space::new() } else {
      let mut v1581_6 = Space::new();
      let mut v1581_6_cursor = (v1579_44_tail).read_zipper();
      for v1581_6_byte in v1581_6_cursor.child_mask().iter() {
        v1581_6_cursor.descend_to_byte(v1581_6_byte);
        let v1581_6_tail = v1581_6_cursor.make_map();
        v1581_6_cursor.ascend(1);
        let v1581_6_head = Path::from_slice(&[v1581_6_byte]);
        let v1582_2: Space = singleton(&(v1581_6_head));
        let v1582_3: Space = intersect(&(*CONSTANT_7),&(v1582_2));
        let v1582_4: Space = if has_head(&(v1582_3)) { singleton(&[]) } else { Space::new() };
        drop(v1582_3);
        let v1582_5: Space = subtract(&(*CONSTANT_0),&(v1582_4));
        drop(v1582_4);
        let v1582_8: Space = if (v1582_5).is_empty() { Space::new() } else {
          let v1583_6: Path = concat_path(&(v1579_44_head),&(v1581_6_head));
          let v1583_7: Space = routine_184(c, &(v1583_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1581_6_tail));
          compose(&(v1582_5),&(v1583_7))
        };
        drop(v1582_5);
        let v1582_9: Space = intersect(&(*CONSTANT_7),&(v1582_2));
        drop(v1582_2);
        let v1582_10: Space = if has_head(&(v1582_9)) { singleton(&[]) } else { Space::new() };
        drop(v1582_9);
        let v1582_12: Space = if (v1582_10).is_empty() { Space::new() } else {
          let v1584_6: Path = concat_path(&(v1579_44_head),&(v1581_6_head));
          let v1584_11: Space = routine_185(c, &(v1584_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1581_6_tail));
          drop(v1584_6);
          compose(&(v1582_10),&(v1584_11))
        };
        drop(v1582_10);
        let v1582_13: Space = unite(&(v1582_8),&(v1582_12));
        v1581_6.join_into((v1582_13).clone());
      }
      drop(v1581_6_cursor);
      compose(&(v1580_5),&(v1581_6))
    };
    drop(v1580_5);
    let v1580_8: Space = intersect(&(*CONSTANT_7),&(v1580_2));
    drop(v1580_2);
    let v1580_9: Space = if has_head(&(v1580_8)) { singleton(&[]) } else { Space::new() };
    drop(v1580_8);
    let v1580_13: Space = if (v1580_9).is_empty() { Space::new() } else {
      let v1585_10: Path = concat_path(&(*CONSTANT_29),&(v1579_44_head));
      let v1585_11: Space = singleton(&(v1585_10));
      drop(v1585_10);
      let v1585_12: Space = unite(&(v1579_39),&(v1585_11));
      drop(v1585_11);
      compose(&(v1580_9),&(v1585_12))
    };
    drop(v1580_9);
    let v1580_14: Space = unite(&(v1580_7),&(v1580_13));
    drop(v1580_13);
    v1579_44.join_into((v1580_14).clone());
  }
  drop(v1579_44_cursor);
  drop(v1579_39);
  (v1579_44).clone()
}

fn routine_168(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1586_14 = Space::new();
  let mut v1586_14_cursor = (*s0).read_zipper();
  for v1586_14_byte in v1586_14_cursor.child_mask().iter() {
    v1586_14_cursor.descend_to_byte(v1586_14_byte);
    let v1586_14_tail = v1586_14_cursor.make_map();
    v1586_14_cursor.ascend(1);
    let v1586_14_head = Path::from_slice(&[v1586_14_byte]);
    let v1587_2: Space = singleton(&(v1586_14_head));
    let v1587_3: Space = intersect(&(*CONSTANT_7),&(v1587_2));
    let v1587_4: Space = if has_head(&(v1587_3)) { singleton(&[]) } else { Space::new() };
    drop(v1587_3);
    let v1587_5: Space = subtract(&(*CONSTANT_0),&(v1587_4));
    drop(v1587_4);
    let v1587_8: Space = if (v1587_5).is_empty() { Space::new() } else {
      let v1588_6: Path = concat_path(&(*p0),&(v1586_14_head));
      let v1588_7: Space = routine_168(c, &(v1588_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1586_14_tail));
      compose(&(v1587_5),&(v1588_7))
    };
    drop(v1587_5);
    let v1587_9: Space = intersect(&(*CONSTANT_7),&(v1587_2));
    drop(v1587_2);
    let v1587_10: Space = if has_head(&(v1587_9)) { singleton(&[]) } else { Space::new() };
    drop(v1587_9);
    let v1587_12: Space = if (v1587_10).is_empty() { Space::new() } else {
      let v1589_6: Path = concat_path(&(*p0),&(v1586_14_head));
      let mut v1589_11 = Space::new();
      let mut v1589_11_cursor = (v1586_14_tail).read_zipper();
      for v1589_11_byte in v1589_11_cursor.child_mask().iter() {
        v1589_11_cursor.descend_to_byte(v1589_11_byte);
        let v1589_11_tail = v1589_11_cursor.make_map();
        v1589_11_cursor.ascend(1);
        let v1589_11_head = Path::from_slice(&[v1589_11_byte]);
        let v1590_2: Space = singleton(&(v1589_11_head));
        let v1590_3: Space = intersect(&(*CONSTANT_7),&(v1590_2));
        let v1590_4: Space = if has_head(&(v1590_3)) { singleton(&[]) } else { Space::new() };
        drop(v1590_3);
        let v1590_5: Space = subtract(&(*CONSTANT_0),&(v1590_4));
        drop(v1590_4);
        let v1590_7: Space = if (v1590_5).is_empty() { Space::new() } else {
          let v1591_6: Space = routine_186(c, &(v1589_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1589_6), &(v1589_11_tail));
          compose(&(v1590_5),&(v1591_6))
        };
        drop(v1590_5);
        let v1590_8: Space = intersect(&(*CONSTANT_7),&(v1590_2));
        drop(v1590_2);
        let v1590_9: Space = if has_head(&(v1590_8)) { singleton(&[]) } else { Space::new() };
        drop(v1590_8);
        let v1590_11: Space = if (v1590_9).is_empty() { Space::new() } else {
          let v1592_10: Space = routine_187(c, &(v1589_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1589_6), &(v1589_11_tail));
          compose(&(v1590_9),&(v1592_10))
        };
        drop(v1590_9);
        let v1590_12: Space = unite(&(v1590_7),&(v1590_11));
        v1589_11.join_into((v1590_12).clone());
      }
      drop(v1589_11_cursor);
      drop(v1589_6);
      compose(&(v1587_10),&(v1589_11))
    };
    drop(v1587_10);
    let v1587_13: Space = unite(&(v1587_8),&(v1587_12));
    v1586_14.join_into((v1587_13).clone());
  }
  drop(v1586_14_cursor);
  (v1586_14).clone()
}

fn routine_169(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let v1593_13: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1593_14: Space = singleton(&(v1593_13));
  drop(v1593_13);
  let v1593_15: Space = unite(&(*CONSTANT_34),&(v1593_14));
  drop(v1593_14);
  let v1593_17: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1593_18: Space = singleton(&(v1593_17));
  drop(v1593_17);
  let v1593_19: Space = unite(&(v1593_15),&(v1593_18));
  drop(v1593_15);
  drop(v1593_18);
  let v1593_21: Path = concat_path(&(*CONSTANT_24),&(*p3));
  let v1593_22: Space = singleton(&(v1593_21));
  drop(v1593_21);
  let v1593_23: Space = unite(&(v1593_19),&(v1593_22));
  drop(v1593_19);
  drop(v1593_22);
  let v1593_25: Path = concat_path(&(*CONSTANT_25),&(*p4));
  let v1593_26: Space = singleton(&(v1593_25));
  drop(v1593_25);
  let v1593_27: Space = unite(&(v1593_23),&(v1593_26));
  drop(v1593_23);
  drop(v1593_26);
  let v1593_29: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1593_30: Space = singleton(&(v1593_29));
  drop(v1593_29);
  let v1593_31: Space = unite(&(v1593_27),&(v1593_30));
  drop(v1593_27);
  drop(v1593_30);
  let v1593_33: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1593_34: Space = singleton(&(v1593_33));
  drop(v1593_33);
  let v1593_35: Space = unite(&(v1593_31),&(v1593_34));
  drop(v1593_31);
  drop(v1593_34);
  let v1593_37: Path = concat_path(&(*CONSTANT_28),&(*p0));
  let v1593_38: Space = singleton(&(v1593_37));
  drop(v1593_37);
  let v1593_39: Space = unite(&(v1593_35),&(v1593_38));
  drop(v1593_35);
  drop(v1593_38);
  let mut v1593_44 = Space::new();
  let mut v1593_44_cursor = (*s0).read_zipper();
  for v1593_44_byte in v1593_44_cursor.child_mask().iter() {
    v1593_44_cursor.descend_to_byte(v1593_44_byte);
    let v1593_44_tail = v1593_44_cursor.make_map();
    v1593_44_cursor.ascend(1);
    let v1593_44_head = Path::from_slice(&[v1593_44_byte]);
    let v1594_2: Space = singleton(&(v1593_44_head));
    let v1594_3: Space = intersect(&(*CONSTANT_7),&(v1594_2));
    let v1594_4: Space = if has_head(&(v1594_3)) { singleton(&[]) } else { Space::new() };
    drop(v1594_3);
    let v1594_5: Space = subtract(&(*CONSTANT_0),&(v1594_4));
    drop(v1594_4);
    let v1594_7: Space = if (v1594_5).is_empty() { Space::new() } else {
      let mut v1595_6 = Space::new();
      let mut v1595_6_cursor = (v1593_44_tail).read_zipper();
      for v1595_6_byte in v1595_6_cursor.child_mask().iter() {
        v1595_6_cursor.descend_to_byte(v1595_6_byte);
        let v1595_6_tail = v1595_6_cursor.make_map();
        v1595_6_cursor.ascend(1);
        let v1595_6_head = Path::from_slice(&[v1595_6_byte]);
        let v1596_2: Space = singleton(&(v1595_6_head));
        let v1596_3: Space = intersect(&(*CONSTANT_7),&(v1596_2));
        let v1596_4: Space = if has_head(&(v1596_3)) { singleton(&[]) } else { Space::new() };
        drop(v1596_3);
        let v1596_5: Space = subtract(&(*CONSTANT_0),&(v1596_4));
        drop(v1596_4);
        let v1596_8: Space = if (v1596_5).is_empty() { Space::new() } else {
          let v1597_6: Path = concat_path(&(v1593_44_head),&(v1595_6_head));
          let v1597_7: Space = routine_186(c, &(v1597_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1595_6_tail));
          compose(&(v1596_5),&(v1597_7))
        };
        drop(v1596_5);
        let v1596_9: Space = intersect(&(*CONSTANT_7),&(v1596_2));
        drop(v1596_2);
        let v1596_10: Space = if has_head(&(v1596_9)) { singleton(&[]) } else { Space::new() };
        drop(v1596_9);
        let v1596_12: Space = if (v1596_10).is_empty() { Space::new() } else {
          let v1598_6: Path = concat_path(&(v1593_44_head),&(v1595_6_head));
          let v1598_11: Space = routine_187(c, &(v1598_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1595_6_tail));
          drop(v1598_6);
          compose(&(v1596_10),&(v1598_11))
        };
        drop(v1596_10);
        let v1596_13: Space = unite(&(v1596_8),&(v1596_12));
        v1595_6.join_into((v1596_13).clone());
      }
      drop(v1595_6_cursor);
      compose(&(v1594_5),&(v1595_6))
    };
    drop(v1594_5);
    let v1594_8: Space = intersect(&(*CONSTANT_7),&(v1594_2));
    drop(v1594_2);
    let v1594_9: Space = if has_head(&(v1594_8)) { singleton(&[]) } else { Space::new() };
    drop(v1594_8);
    let v1594_13: Space = if (v1594_9).is_empty() { Space::new() } else {
      let v1599_10: Path = concat_path(&(*CONSTANT_29),&(v1593_44_head));
      let v1599_11: Space = singleton(&(v1599_10));
      drop(v1599_10);
      let v1599_12: Space = unite(&(v1593_39),&(v1599_11));
      drop(v1599_11);
      compose(&(v1594_9),&(v1599_12))
    };
    drop(v1594_9);
    let v1594_14: Space = unite(&(v1594_7),&(v1594_13));
    drop(v1594_13);
    v1593_44.join_into((v1594_14).clone());
  }
  drop(v1593_44_cursor);
  drop(v1593_39);
  (v1593_44).clone()
}

fn routine_170(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1600_14 = Space::new();
  let mut v1600_14_cursor = (*s0).read_zipper();
  for v1600_14_byte in v1600_14_cursor.child_mask().iter() {
    v1600_14_cursor.descend_to_byte(v1600_14_byte);
    let v1600_14_tail = v1600_14_cursor.make_map();
    v1600_14_cursor.ascend(1);
    let v1600_14_head = Path::from_slice(&[v1600_14_byte]);
    let v1601_2: Space = singleton(&(v1600_14_head));
    let v1601_3: Space = intersect(&(*CONSTANT_7),&(v1601_2));
    let v1601_4: Space = if has_head(&(v1601_3)) { singleton(&[]) } else { Space::new() };
    drop(v1601_3);
    let v1601_5: Space = subtract(&(*CONSTANT_0),&(v1601_4));
    drop(v1601_4);
    let v1601_8: Space = if (v1601_5).is_empty() { Space::new() } else {
      let v1602_6: Path = concat_path(&(*p0),&(v1600_14_head));
      let v1602_7: Space = routine_170(c, &(v1602_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1600_14_tail));
      compose(&(v1601_5),&(v1602_7))
    };
    drop(v1601_5);
    let v1601_9: Space = intersect(&(*CONSTANT_7),&(v1601_2));
    drop(v1601_2);
    let v1601_10: Space = if has_head(&(v1601_9)) { singleton(&[]) } else { Space::new() };
    drop(v1601_9);
    let v1601_12: Space = if (v1601_10).is_empty() { Space::new() } else {
      let v1603_6: Path = concat_path(&(*p0),&(v1600_14_head));
      let mut v1603_11 = Space::new();
      let mut v1603_11_cursor = (v1600_14_tail).read_zipper();
      for v1603_11_byte in v1603_11_cursor.child_mask().iter() {
        v1603_11_cursor.descend_to_byte(v1603_11_byte);
        let v1603_11_tail = v1603_11_cursor.make_map();
        v1603_11_cursor.ascend(1);
        let v1603_11_head = Path::from_slice(&[v1603_11_byte]);
        let v1604_2: Space = singleton(&(v1603_11_head));
        let v1604_3: Space = intersect(&(*CONSTANT_7),&(v1604_2));
        let v1604_4: Space = if has_head(&(v1604_3)) { singleton(&[]) } else { Space::new() };
        drop(v1604_3);
        let v1604_5: Space = subtract(&(*CONSTANT_0),&(v1604_4));
        drop(v1604_4);
        let v1604_7: Space = if (v1604_5).is_empty() { Space::new() } else {
          let v1605_6: Space = routine_188(c, &(v1603_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1603_6), &(v1603_11_tail));
          compose(&(v1604_5),&(v1605_6))
        };
        drop(v1604_5);
        let v1604_8: Space = intersect(&(*CONSTANT_7),&(v1604_2));
        drop(v1604_2);
        let v1604_9: Space = if has_head(&(v1604_8)) { singleton(&[]) } else { Space::new() };
        drop(v1604_8);
        let v1604_11: Space = if (v1604_9).is_empty() { Space::new() } else {
          let v1606_10: Space = routine_189(c, &(v1603_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1603_6), &(v1603_11_tail));
          compose(&(v1604_9),&(v1606_10))
        };
        drop(v1604_9);
        let v1604_12: Space = unite(&(v1604_7),&(v1604_11));
        v1603_11.join_into((v1604_12).clone());
      }
      drop(v1603_11_cursor);
      drop(v1603_6);
      compose(&(v1601_10),&(v1603_11))
    };
    drop(v1601_10);
    let v1601_13: Space = unite(&(v1601_8),&(v1601_12));
    v1600_14.join_into((v1601_13).clone());
  }
  drop(v1600_14_cursor);
  (v1600_14).clone()
}

fn routine_171(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let v1607_13: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1607_14: Space = singleton(&(v1607_13));
  drop(v1607_13);
  let v1607_15: Space = unite(&(*CONSTANT_35),&(v1607_14));
  drop(v1607_14);
  let v1607_17: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1607_18: Space = singleton(&(v1607_17));
  drop(v1607_17);
  let v1607_19: Space = unite(&(v1607_15),&(v1607_18));
  drop(v1607_15);
  drop(v1607_18);
  let v1607_21: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1607_22: Space = singleton(&(v1607_21));
  drop(v1607_21);
  let v1607_23: Space = unite(&(v1607_19),&(v1607_22));
  drop(v1607_19);
  drop(v1607_22);
  let v1607_25: Path = concat_path(&(*CONSTANT_25),&(*p4));
  let v1607_26: Space = singleton(&(v1607_25));
  drop(v1607_25);
  let v1607_27: Space = unite(&(v1607_23),&(v1607_26));
  drop(v1607_23);
  drop(v1607_26);
  let v1607_29: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1607_30: Space = singleton(&(v1607_29));
  drop(v1607_29);
  let v1607_31: Space = unite(&(v1607_27),&(v1607_30));
  drop(v1607_27);
  drop(v1607_30);
  let v1607_33: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1607_34: Space = singleton(&(v1607_33));
  drop(v1607_33);
  let v1607_35: Space = unite(&(v1607_31),&(v1607_34));
  drop(v1607_31);
  drop(v1607_34);
  let v1607_37: Path = concat_path(&(*CONSTANT_28),&(*p0));
  let v1607_38: Space = singleton(&(v1607_37));
  drop(v1607_37);
  let v1607_39: Space = unite(&(v1607_35),&(v1607_38));
  drop(v1607_35);
  drop(v1607_38);
  let mut v1607_44 = Space::new();
  let mut v1607_44_cursor = (*s0).read_zipper();
  for v1607_44_byte in v1607_44_cursor.child_mask().iter() {
    v1607_44_cursor.descend_to_byte(v1607_44_byte);
    let v1607_44_tail = v1607_44_cursor.make_map();
    v1607_44_cursor.ascend(1);
    let v1607_44_head = Path::from_slice(&[v1607_44_byte]);
    let v1608_2: Space = singleton(&(v1607_44_head));
    let v1608_3: Space = intersect(&(*CONSTANT_7),&(v1608_2));
    let v1608_4: Space = if has_head(&(v1608_3)) { singleton(&[]) } else { Space::new() };
    drop(v1608_3);
    let v1608_5: Space = subtract(&(*CONSTANT_0),&(v1608_4));
    drop(v1608_4);
    let v1608_7: Space = if (v1608_5).is_empty() { Space::new() } else {
      let mut v1609_6 = Space::new();
      let mut v1609_6_cursor = (v1607_44_tail).read_zipper();
      for v1609_6_byte in v1609_6_cursor.child_mask().iter() {
        v1609_6_cursor.descend_to_byte(v1609_6_byte);
        let v1609_6_tail = v1609_6_cursor.make_map();
        v1609_6_cursor.ascend(1);
        let v1609_6_head = Path::from_slice(&[v1609_6_byte]);
        let v1610_2: Space = singleton(&(v1609_6_head));
        let v1610_3: Space = intersect(&(*CONSTANT_7),&(v1610_2));
        let v1610_4: Space = if has_head(&(v1610_3)) { singleton(&[]) } else { Space::new() };
        drop(v1610_3);
        let v1610_5: Space = subtract(&(*CONSTANT_0),&(v1610_4));
        drop(v1610_4);
        let v1610_8: Space = if (v1610_5).is_empty() { Space::new() } else {
          let v1611_6: Path = concat_path(&(v1607_44_head),&(v1609_6_head));
          let v1611_7: Space = routine_188(c, &(v1611_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1609_6_tail));
          compose(&(v1610_5),&(v1611_7))
        };
        drop(v1610_5);
        let v1610_9: Space = intersect(&(*CONSTANT_7),&(v1610_2));
        drop(v1610_2);
        let v1610_10: Space = if has_head(&(v1610_9)) { singleton(&[]) } else { Space::new() };
        drop(v1610_9);
        let v1610_12: Space = if (v1610_10).is_empty() { Space::new() } else {
          let v1612_6: Path = concat_path(&(v1607_44_head),&(v1609_6_head));
          let v1612_11: Space = routine_189(c, &(v1612_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1609_6_tail));
          drop(v1612_6);
          compose(&(v1610_10),&(v1612_11))
        };
        drop(v1610_10);
        let v1610_13: Space = unite(&(v1610_8),&(v1610_12));
        v1609_6.join_into((v1610_13).clone());
      }
      drop(v1609_6_cursor);
      compose(&(v1608_5),&(v1609_6))
    };
    drop(v1608_5);
    let v1608_8: Space = intersect(&(*CONSTANT_7),&(v1608_2));
    drop(v1608_2);
    let v1608_9: Space = if has_head(&(v1608_8)) { singleton(&[]) } else { Space::new() };
    drop(v1608_8);
    let v1608_13: Space = if (v1608_9).is_empty() { Space::new() } else {
      let v1613_10: Path = concat_path(&(*CONSTANT_29),&(v1607_44_head));
      let v1613_11: Space = singleton(&(v1613_10));
      drop(v1613_10);
      let v1613_12: Space = unite(&(v1607_39),&(v1613_11));
      drop(v1613_11);
      compose(&(v1608_9),&(v1613_12))
    };
    drop(v1608_9);
    let v1608_14: Space = unite(&(v1608_7),&(v1608_13));
    drop(v1608_13);
    v1607_44.join_into((v1608_14).clone());
  }
  drop(v1607_44_cursor);
  drop(v1607_39);
  (v1607_44).clone()
}

fn routine_172(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1614_14 = Space::new();
  let mut v1614_14_cursor = (*s0).read_zipper();
  for v1614_14_byte in v1614_14_cursor.child_mask().iter() {
    v1614_14_cursor.descend_to_byte(v1614_14_byte);
    let v1614_14_tail = v1614_14_cursor.make_map();
    v1614_14_cursor.ascend(1);
    let v1614_14_head = Path::from_slice(&[v1614_14_byte]);
    let v1615_2: Space = singleton(&(v1614_14_head));
    let v1615_3: Space = intersect(&(*CONSTANT_7),&(v1615_2));
    let v1615_4: Space = if has_head(&(v1615_3)) { singleton(&[]) } else { Space::new() };
    drop(v1615_3);
    let v1615_5: Space = subtract(&(*CONSTANT_0),&(v1615_4));
    drop(v1615_4);
    let v1615_8: Space = if (v1615_5).is_empty() { Space::new() } else {
      let v1616_6: Path = concat_path(&(*p0),&(v1614_14_head));
      let v1616_7: Space = routine_172(c, &(v1616_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1614_14_tail));
      compose(&(v1615_5),&(v1616_7))
    };
    drop(v1615_5);
    let v1615_9: Space = intersect(&(*CONSTANT_7),&(v1615_2));
    drop(v1615_2);
    let v1615_10: Space = if has_head(&(v1615_9)) { singleton(&[]) } else { Space::new() };
    drop(v1615_9);
    let v1615_12: Space = if (v1615_10).is_empty() { Space::new() } else {
      let v1617_6: Path = concat_path(&(*p0),&(v1614_14_head));
      let mut v1617_11 = Space::new();
      let mut v1617_11_cursor = (v1614_14_tail).read_zipper();
      for v1617_11_byte in v1617_11_cursor.child_mask().iter() {
        v1617_11_cursor.descend_to_byte(v1617_11_byte);
        let v1617_11_tail = v1617_11_cursor.make_map();
        v1617_11_cursor.ascend(1);
        let v1617_11_head = Path::from_slice(&[v1617_11_byte]);
        let v1618_2: Space = singleton(&(v1617_11_head));
        let v1618_3: Space = intersect(&(*CONSTANT_7),&(v1618_2));
        let v1618_4: Space = if has_head(&(v1618_3)) { singleton(&[]) } else { Space::new() };
        drop(v1618_3);
        let v1618_5: Space = subtract(&(*CONSTANT_0),&(v1618_4));
        drop(v1618_4);
        let v1618_7: Space = if (v1618_5).is_empty() { Space::new() } else {
          let v1619_6: Space = routine_190(c, &(v1617_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1617_6), &(v1617_11_tail));
          compose(&(v1618_5),&(v1619_6))
        };
        drop(v1618_5);
        let v1618_8: Space = intersect(&(*CONSTANT_7),&(v1618_2));
        drop(v1618_2);
        let v1618_9: Space = if has_head(&(v1618_8)) { singleton(&[]) } else { Space::new() };
        drop(v1618_8);
        let v1618_11: Space = if (v1618_9).is_empty() { Space::new() } else {
          let v1620_10: Space = routine_191(c, &(v1617_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1617_6), &(v1617_11_tail));
          compose(&(v1618_9),&(v1620_10))
        };
        drop(v1618_9);
        let v1618_12: Space = unite(&(v1618_7),&(v1618_11));
        v1617_11.join_into((v1618_12).clone());
      }
      drop(v1617_11_cursor);
      drop(v1617_6);
      compose(&(v1615_10),&(v1617_11))
    };
    drop(v1615_10);
    let v1615_13: Space = unite(&(v1615_8),&(v1615_12));
    v1614_14.join_into((v1615_13).clone());
  }
  drop(v1614_14_cursor);
  (v1614_14).clone()
}

fn routine_173(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let v1621_13: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1621_14: Space = singleton(&(v1621_13));
  drop(v1621_13);
  let v1621_15: Space = unite(&(*CONSTANT_36),&(v1621_14));
  drop(v1621_14);
  let v1621_17: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1621_18: Space = singleton(&(v1621_17));
  drop(v1621_17);
  let v1621_19: Space = unite(&(v1621_15),&(v1621_18));
  drop(v1621_15);
  drop(v1621_18);
  let v1621_21: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1621_22: Space = singleton(&(v1621_21));
  drop(v1621_21);
  let v1621_23: Space = unite(&(v1621_19),&(v1621_22));
  drop(v1621_19);
  drop(v1621_22);
  let v1621_25: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1621_26: Space = singleton(&(v1621_25));
  drop(v1621_25);
  let v1621_27: Space = unite(&(v1621_23),&(v1621_26));
  drop(v1621_23);
  drop(v1621_26);
  let v1621_29: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1621_30: Space = singleton(&(v1621_29));
  drop(v1621_29);
  let v1621_31: Space = unite(&(v1621_27),&(v1621_30));
  drop(v1621_27);
  drop(v1621_30);
  let v1621_33: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1621_34: Space = singleton(&(v1621_33));
  drop(v1621_33);
  let v1621_35: Space = unite(&(v1621_31),&(v1621_34));
  drop(v1621_31);
  drop(v1621_34);
  let v1621_37: Path = concat_path(&(*CONSTANT_28),&(*p0));
  let v1621_38: Space = singleton(&(v1621_37));
  drop(v1621_37);
  let v1621_39: Space = unite(&(v1621_35),&(v1621_38));
  drop(v1621_35);
  drop(v1621_38);
  let mut v1621_44 = Space::new();
  let mut v1621_44_cursor = (*s0).read_zipper();
  for v1621_44_byte in v1621_44_cursor.child_mask().iter() {
    v1621_44_cursor.descend_to_byte(v1621_44_byte);
    let v1621_44_tail = v1621_44_cursor.make_map();
    v1621_44_cursor.ascend(1);
    let v1621_44_head = Path::from_slice(&[v1621_44_byte]);
    let v1622_2: Space = singleton(&(v1621_44_head));
    let v1622_3: Space = intersect(&(*CONSTANT_7),&(v1622_2));
    let v1622_4: Space = if has_head(&(v1622_3)) { singleton(&[]) } else { Space::new() };
    drop(v1622_3);
    let v1622_5: Space = subtract(&(*CONSTANT_0),&(v1622_4));
    drop(v1622_4);
    let v1622_7: Space = if (v1622_5).is_empty() { Space::new() } else {
      let mut v1623_6 = Space::new();
      let mut v1623_6_cursor = (v1621_44_tail).read_zipper();
      for v1623_6_byte in v1623_6_cursor.child_mask().iter() {
        v1623_6_cursor.descend_to_byte(v1623_6_byte);
        let v1623_6_tail = v1623_6_cursor.make_map();
        v1623_6_cursor.ascend(1);
        let v1623_6_head = Path::from_slice(&[v1623_6_byte]);
        let v1624_2: Space = singleton(&(v1623_6_head));
        let v1624_3: Space = intersect(&(*CONSTANT_7),&(v1624_2));
        let v1624_4: Space = if has_head(&(v1624_3)) { singleton(&[]) } else { Space::new() };
        drop(v1624_3);
        let v1624_5: Space = subtract(&(*CONSTANT_0),&(v1624_4));
        drop(v1624_4);
        let v1624_8: Space = if (v1624_5).is_empty() { Space::new() } else {
          let v1625_6: Path = concat_path(&(v1621_44_head),&(v1623_6_head));
          let v1625_7: Space = routine_190(c, &(v1625_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1623_6_tail));
          compose(&(v1624_5),&(v1625_7))
        };
        drop(v1624_5);
        let v1624_9: Space = intersect(&(*CONSTANT_7),&(v1624_2));
        drop(v1624_2);
        let v1624_10: Space = if has_head(&(v1624_9)) { singleton(&[]) } else { Space::new() };
        drop(v1624_9);
        let v1624_12: Space = if (v1624_10).is_empty() { Space::new() } else {
          let v1626_6: Path = concat_path(&(v1621_44_head),&(v1623_6_head));
          let v1626_11: Space = routine_191(c, &(v1626_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1623_6_tail));
          drop(v1626_6);
          compose(&(v1624_10),&(v1626_11))
        };
        drop(v1624_10);
        let v1624_13: Space = unite(&(v1624_8),&(v1624_12));
        v1623_6.join_into((v1624_13).clone());
      }
      drop(v1623_6_cursor);
      compose(&(v1622_5),&(v1623_6))
    };
    drop(v1622_5);
    let v1622_8: Space = intersect(&(*CONSTANT_7),&(v1622_2));
    drop(v1622_2);
    let v1622_9: Space = if has_head(&(v1622_8)) { singleton(&[]) } else { Space::new() };
    drop(v1622_8);
    let v1622_13: Space = if (v1622_9).is_empty() { Space::new() } else {
      let v1627_10: Path = concat_path(&(*CONSTANT_29),&(v1621_44_head));
      let v1627_11: Space = singleton(&(v1627_10));
      drop(v1627_10);
      let v1627_12: Space = unite(&(v1621_39),&(v1627_11));
      drop(v1627_11);
      compose(&(v1622_9),&(v1627_12))
    };
    drop(v1622_9);
    let v1622_14: Space = unite(&(v1622_7),&(v1622_13));
    drop(v1622_13);
    v1621_44.join_into((v1622_14).clone());
  }
  drop(v1621_44_cursor);
  drop(v1621_39);
  (v1621_44).clone()
}

fn routine_174(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1628_14 = Space::new();
  let mut v1628_14_cursor = (*s0).read_zipper();
  for v1628_14_byte in v1628_14_cursor.child_mask().iter() {
    v1628_14_cursor.descend_to_byte(v1628_14_byte);
    let v1628_14_tail = v1628_14_cursor.make_map();
    v1628_14_cursor.ascend(1);
    let v1628_14_head = Path::from_slice(&[v1628_14_byte]);
    let v1629_2: Space = singleton(&(v1628_14_head));
    let v1629_3: Space = intersect(&(*CONSTANT_7),&(v1629_2));
    let v1629_4: Space = if has_head(&(v1629_3)) { singleton(&[]) } else { Space::new() };
    drop(v1629_3);
    let v1629_5: Space = subtract(&(*CONSTANT_0),&(v1629_4));
    drop(v1629_4);
    let v1629_8: Space = if (v1629_5).is_empty() { Space::new() } else {
      let v1630_6: Path = concat_path(&(*p0),&(v1628_14_head));
      let v1630_7: Space = routine_174(c, &(v1630_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1628_14_tail));
      compose(&(v1629_5),&(v1630_7))
    };
    drop(v1629_5);
    let v1629_9: Space = intersect(&(*CONSTANT_7),&(v1629_2));
    drop(v1629_2);
    let v1629_10: Space = if has_head(&(v1629_9)) { singleton(&[]) } else { Space::new() };
    drop(v1629_9);
    let v1629_12: Space = if (v1629_10).is_empty() { Space::new() } else {
      let v1631_6: Path = concat_path(&(*p0),&(v1628_14_head));
      let mut v1631_11 = Space::new();
      let mut v1631_11_cursor = (v1628_14_tail).read_zipper();
      for v1631_11_byte in v1631_11_cursor.child_mask().iter() {
        v1631_11_cursor.descend_to_byte(v1631_11_byte);
        let v1631_11_tail = v1631_11_cursor.make_map();
        v1631_11_cursor.ascend(1);
        let v1631_11_head = Path::from_slice(&[v1631_11_byte]);
        let v1632_2: Space = singleton(&(v1631_11_head));
        let v1632_3: Space = intersect(&(*CONSTANT_7),&(v1632_2));
        let v1632_4: Space = if has_head(&(v1632_3)) { singleton(&[]) } else { Space::new() };
        drop(v1632_3);
        let v1632_5: Space = subtract(&(*CONSTANT_0),&(v1632_4));
        drop(v1632_4);
        let v1632_7: Space = if (v1632_5).is_empty() { Space::new() } else {
          let v1633_6: Space = routine_192(c, &(v1631_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1631_6), &(v1631_11_tail));
          compose(&(v1632_5),&(v1633_6))
        };
        drop(v1632_5);
        let v1632_8: Space = intersect(&(*CONSTANT_7),&(v1632_2));
        drop(v1632_2);
        let v1632_9: Space = if has_head(&(v1632_8)) { singleton(&[]) } else { Space::new() };
        drop(v1632_8);
        let v1632_11: Space = if (v1632_9).is_empty() { Space::new() } else {
          let v1634_10: Space = routine_193(c, &(v1631_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1631_6), &(v1631_11_tail));
          compose(&(v1632_9),&(v1634_10))
        };
        drop(v1632_9);
        let v1632_12: Space = unite(&(v1632_7),&(v1632_11));
        v1631_11.join_into((v1632_12).clone());
      }
      drop(v1631_11_cursor);
      drop(v1631_6);
      compose(&(v1629_10),&(v1631_11))
    };
    drop(v1629_10);
    let v1629_13: Space = unite(&(v1629_8),&(v1629_12));
    v1628_14.join_into((v1629_13).clone());
  }
  drop(v1628_14_cursor);
  (v1628_14).clone()
}

fn routine_175(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let v1635_13: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1635_14: Space = singleton(&(v1635_13));
  drop(v1635_13);
  let v1635_15: Space = unite(&(*CONSTANT_37),&(v1635_14));
  drop(v1635_14);
  let v1635_17: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1635_18: Space = singleton(&(v1635_17));
  drop(v1635_17);
  let v1635_19: Space = unite(&(v1635_15),&(v1635_18));
  drop(v1635_15);
  drop(v1635_18);
  let v1635_21: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1635_22: Space = singleton(&(v1635_21));
  drop(v1635_21);
  let v1635_23: Space = unite(&(v1635_19),&(v1635_22));
  drop(v1635_19);
  drop(v1635_22);
  let v1635_25: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1635_26: Space = singleton(&(v1635_25));
  drop(v1635_25);
  let v1635_27: Space = unite(&(v1635_23),&(v1635_26));
  drop(v1635_23);
  drop(v1635_26);
  let v1635_29: Path = concat_path(&(*CONSTANT_25),&(*p5));
  let v1635_30: Space = singleton(&(v1635_29));
  drop(v1635_29);
  let v1635_31: Space = unite(&(v1635_27),&(v1635_30));
  drop(v1635_27);
  drop(v1635_30);
  let v1635_33: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1635_34: Space = singleton(&(v1635_33));
  drop(v1635_33);
  let v1635_35: Space = unite(&(v1635_31),&(v1635_34));
  drop(v1635_31);
  drop(v1635_34);
  let v1635_37: Path = concat_path(&(*CONSTANT_28),&(*p0));
  let v1635_38: Space = singleton(&(v1635_37));
  drop(v1635_37);
  let v1635_39: Space = unite(&(v1635_35),&(v1635_38));
  drop(v1635_35);
  drop(v1635_38);
  let mut v1635_44 = Space::new();
  let mut v1635_44_cursor = (*s0).read_zipper();
  for v1635_44_byte in v1635_44_cursor.child_mask().iter() {
    v1635_44_cursor.descend_to_byte(v1635_44_byte);
    let v1635_44_tail = v1635_44_cursor.make_map();
    v1635_44_cursor.ascend(1);
    let v1635_44_head = Path::from_slice(&[v1635_44_byte]);
    let v1636_2: Space = singleton(&(v1635_44_head));
    let v1636_3: Space = intersect(&(*CONSTANT_7),&(v1636_2));
    let v1636_4: Space = if has_head(&(v1636_3)) { singleton(&[]) } else { Space::new() };
    drop(v1636_3);
    let v1636_5: Space = subtract(&(*CONSTANT_0),&(v1636_4));
    drop(v1636_4);
    let v1636_7: Space = if (v1636_5).is_empty() { Space::new() } else {
      let mut v1637_6 = Space::new();
      let mut v1637_6_cursor = (v1635_44_tail).read_zipper();
      for v1637_6_byte in v1637_6_cursor.child_mask().iter() {
        v1637_6_cursor.descend_to_byte(v1637_6_byte);
        let v1637_6_tail = v1637_6_cursor.make_map();
        v1637_6_cursor.ascend(1);
        let v1637_6_head = Path::from_slice(&[v1637_6_byte]);
        let v1638_2: Space = singleton(&(v1637_6_head));
        let v1638_3: Space = intersect(&(*CONSTANT_7),&(v1638_2));
        let v1638_4: Space = if has_head(&(v1638_3)) { singleton(&[]) } else { Space::new() };
        drop(v1638_3);
        let v1638_5: Space = subtract(&(*CONSTANT_0),&(v1638_4));
        drop(v1638_4);
        let v1638_8: Space = if (v1638_5).is_empty() { Space::new() } else {
          let v1639_6: Path = concat_path(&(v1635_44_head),&(v1637_6_head));
          let v1639_7: Space = routine_192(c, &(v1639_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1637_6_tail));
          compose(&(v1638_5),&(v1639_7))
        };
        drop(v1638_5);
        let v1638_9: Space = intersect(&(*CONSTANT_7),&(v1638_2));
        drop(v1638_2);
        let v1638_10: Space = if has_head(&(v1638_9)) { singleton(&[]) } else { Space::new() };
        drop(v1638_9);
        let v1638_12: Space = if (v1638_10).is_empty() { Space::new() } else {
          let v1640_6: Path = concat_path(&(v1635_44_head),&(v1637_6_head));
          let v1640_11: Space = routine_193(c, &(v1640_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1637_6_tail));
          drop(v1640_6);
          compose(&(v1638_10),&(v1640_11))
        };
        drop(v1638_10);
        let v1638_13: Space = unite(&(v1638_8),&(v1638_12));
        v1637_6.join_into((v1638_13).clone());
      }
      drop(v1637_6_cursor);
      compose(&(v1636_5),&(v1637_6))
    };
    drop(v1636_5);
    let v1636_8: Space = intersect(&(*CONSTANT_7),&(v1636_2));
    drop(v1636_2);
    let v1636_9: Space = if has_head(&(v1636_8)) { singleton(&[]) } else { Space::new() };
    drop(v1636_8);
    let v1636_13: Space = if (v1636_9).is_empty() { Space::new() } else {
      let v1641_10: Path = concat_path(&(*CONSTANT_29),&(v1635_44_head));
      let v1641_11: Space = singleton(&(v1641_10));
      drop(v1641_10);
      let v1641_12: Space = unite(&(v1635_39),&(v1641_11));
      drop(v1641_11);
      compose(&(v1636_9),&(v1641_12))
    };
    drop(v1636_9);
    let v1636_14: Space = unite(&(v1636_7),&(v1636_13));
    drop(v1636_13);
    v1635_44.join_into((v1636_14).clone());
  }
  drop(v1635_44_cursor);
  drop(v1635_39);
  (v1635_44).clone()
}

fn routine_176(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1642_14 = Space::new();
  let mut v1642_14_cursor = (*s0).read_zipper();
  for v1642_14_byte in v1642_14_cursor.child_mask().iter() {
    v1642_14_cursor.descend_to_byte(v1642_14_byte);
    let v1642_14_tail = v1642_14_cursor.make_map();
    v1642_14_cursor.ascend(1);
    let v1642_14_head = Path::from_slice(&[v1642_14_byte]);
    let v1643_2: Space = singleton(&(v1642_14_head));
    let v1643_3: Space = intersect(&(*CONSTANT_7),&(v1643_2));
    let v1643_4: Space = if has_head(&(v1643_3)) { singleton(&[]) } else { Space::new() };
    drop(v1643_3);
    let v1643_5: Space = subtract(&(*CONSTANT_0),&(v1643_4));
    drop(v1643_4);
    let v1643_8: Space = if (v1643_5).is_empty() { Space::new() } else {
      let v1644_6: Path = concat_path(&(*p0),&(v1642_14_head));
      let v1644_7: Space = routine_176(c, &(v1644_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1642_14_tail));
      compose(&(v1643_5),&(v1644_7))
    };
    drop(v1643_5);
    let v1643_9: Space = intersect(&(*CONSTANT_7),&(v1643_2));
    drop(v1643_2);
    let v1643_10: Space = if has_head(&(v1643_9)) { singleton(&[]) } else { Space::new() };
    drop(v1643_9);
    let v1643_12: Space = if (v1643_10).is_empty() { Space::new() } else {
      let v1645_6: Path = concat_path(&(*p0),&(v1642_14_head));
      let mut v1645_11 = Space::new();
      let mut v1645_11_cursor = (v1642_14_tail).read_zipper();
      for v1645_11_byte in v1645_11_cursor.child_mask().iter() {
        v1645_11_cursor.descend_to_byte(v1645_11_byte);
        let v1645_11_tail = v1645_11_cursor.make_map();
        v1645_11_cursor.ascend(1);
        let v1645_11_head = Path::from_slice(&[v1645_11_byte]);
        let v1646_2: Space = singleton(&(v1645_11_head));
        let v1646_3: Space = intersect(&(*CONSTANT_7),&(v1646_2));
        let v1646_4: Space = if has_head(&(v1646_3)) { singleton(&[]) } else { Space::new() };
        drop(v1646_3);
        let v1646_5: Space = subtract(&(*CONSTANT_0),&(v1646_4));
        drop(v1646_4);
        let v1646_7: Space = if (v1646_5).is_empty() { Space::new() } else {
          let v1647_6: Space = routine_194(c, &(v1645_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1645_6), &(v1645_11_tail));
          compose(&(v1646_5),&(v1647_6))
        };
        drop(v1646_5);
        let v1646_8: Space = intersect(&(*CONSTANT_7),&(v1646_2));
        drop(v1646_2);
        let v1646_9: Space = if has_head(&(v1646_8)) { singleton(&[]) } else { Space::new() };
        drop(v1646_8);
        let v1646_11: Space = if (v1646_9).is_empty() { Space::new() } else {
          let v1648_10: Space = routine_195(c, &(v1645_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1645_6), &(v1645_11_tail));
          compose(&(v1646_9),&(v1648_10))
        };
        drop(v1646_9);
        let v1646_12: Space = unite(&(v1646_7),&(v1646_11));
        v1645_11.join_into((v1646_12).clone());
      }
      drop(v1645_11_cursor);
      drop(v1645_6);
      compose(&(v1643_10),&(v1645_11))
    };
    drop(v1643_10);
    let v1643_13: Space = unite(&(v1643_8),&(v1643_12));
    v1642_14.join_into((v1643_13).clone());
  }
  drop(v1642_14_cursor);
  (v1642_14).clone()
}

fn routine_177(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let v1649_13: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1649_14: Space = singleton(&(v1649_13));
  drop(v1649_13);
  let v1649_15: Space = unite(&(*CONSTANT_38),&(v1649_14));
  drop(v1649_14);
  let v1649_17: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1649_18: Space = singleton(&(v1649_17));
  drop(v1649_17);
  let v1649_19: Space = unite(&(v1649_15),&(v1649_18));
  drop(v1649_15);
  drop(v1649_18);
  let v1649_21: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1649_22: Space = singleton(&(v1649_21));
  drop(v1649_21);
  let v1649_23: Space = unite(&(v1649_19),&(v1649_22));
  drop(v1649_19);
  drop(v1649_22);
  let v1649_25: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1649_26: Space = singleton(&(v1649_25));
  drop(v1649_25);
  let v1649_27: Space = unite(&(v1649_23),&(v1649_26));
  drop(v1649_23);
  drop(v1649_26);
  let v1649_29: Path = concat_path(&(*CONSTANT_25),&(*p5));
  let v1649_30: Space = singleton(&(v1649_29));
  drop(v1649_29);
  let v1649_31: Space = unite(&(v1649_27),&(v1649_30));
  drop(v1649_27);
  drop(v1649_30);
  let v1649_33: Path = concat_path(&(*CONSTANT_26),&(*p6));
  let v1649_34: Space = singleton(&(v1649_33));
  drop(v1649_33);
  let v1649_35: Space = unite(&(v1649_31),&(v1649_34));
  drop(v1649_31);
  drop(v1649_34);
  let v1649_37: Path = concat_path(&(*CONSTANT_28),&(*p0));
  let v1649_38: Space = singleton(&(v1649_37));
  drop(v1649_37);
  let v1649_39: Space = unite(&(v1649_35),&(v1649_38));
  drop(v1649_35);
  drop(v1649_38);
  let mut v1649_44 = Space::new();
  let mut v1649_44_cursor = (*s0).read_zipper();
  for v1649_44_byte in v1649_44_cursor.child_mask().iter() {
    v1649_44_cursor.descend_to_byte(v1649_44_byte);
    let v1649_44_tail = v1649_44_cursor.make_map();
    v1649_44_cursor.ascend(1);
    let v1649_44_head = Path::from_slice(&[v1649_44_byte]);
    let v1650_2: Space = singleton(&(v1649_44_head));
    let v1650_3: Space = intersect(&(*CONSTANT_7),&(v1650_2));
    let v1650_4: Space = if has_head(&(v1650_3)) { singleton(&[]) } else { Space::new() };
    drop(v1650_3);
    let v1650_5: Space = subtract(&(*CONSTANT_0),&(v1650_4));
    drop(v1650_4);
    let v1650_7: Space = if (v1650_5).is_empty() { Space::new() } else {
      let mut v1651_6 = Space::new();
      let mut v1651_6_cursor = (v1649_44_tail).read_zipper();
      for v1651_6_byte in v1651_6_cursor.child_mask().iter() {
        v1651_6_cursor.descend_to_byte(v1651_6_byte);
        let v1651_6_tail = v1651_6_cursor.make_map();
        v1651_6_cursor.ascend(1);
        let v1651_6_head = Path::from_slice(&[v1651_6_byte]);
        let v1652_2: Space = singleton(&(v1651_6_head));
        let v1652_3: Space = intersect(&(*CONSTANT_7),&(v1652_2));
        let v1652_4: Space = if has_head(&(v1652_3)) { singleton(&[]) } else { Space::new() };
        drop(v1652_3);
        let v1652_5: Space = subtract(&(*CONSTANT_0),&(v1652_4));
        drop(v1652_4);
        let v1652_8: Space = if (v1652_5).is_empty() { Space::new() } else {
          let v1653_6: Path = concat_path(&(v1649_44_head),&(v1651_6_head));
          let v1653_7: Space = routine_194(c, &(v1653_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1651_6_tail));
          compose(&(v1652_5),&(v1653_7))
        };
        drop(v1652_5);
        let v1652_9: Space = intersect(&(*CONSTANT_7),&(v1652_2));
        drop(v1652_2);
        let v1652_10: Space = if has_head(&(v1652_9)) { singleton(&[]) } else { Space::new() };
        drop(v1652_9);
        let v1652_12: Space = if (v1652_10).is_empty() { Space::new() } else {
          let v1654_6: Path = concat_path(&(v1649_44_head),&(v1651_6_head));
          let v1654_11: Space = routine_195(c, &(v1654_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1651_6_tail));
          drop(v1654_6);
          compose(&(v1652_10),&(v1654_11))
        };
        drop(v1652_10);
        let v1652_13: Space = unite(&(v1652_8),&(v1652_12));
        v1651_6.join_into((v1652_13).clone());
      }
      drop(v1651_6_cursor);
      compose(&(v1650_5),&(v1651_6))
    };
    drop(v1650_5);
    let v1650_8: Space = intersect(&(*CONSTANT_7),&(v1650_2));
    drop(v1650_2);
    let v1650_9: Space = if has_head(&(v1650_8)) { singleton(&[]) } else { Space::new() };
    drop(v1650_8);
    let v1650_13: Space = if (v1650_9).is_empty() { Space::new() } else {
      let v1655_10: Path = concat_path(&(*CONSTANT_29),&(v1649_44_head));
      let v1655_11: Space = singleton(&(v1655_10));
      drop(v1655_10);
      let v1655_12: Space = unite(&(v1649_39),&(v1655_11));
      drop(v1655_11);
      compose(&(v1650_9),&(v1655_12))
    };
    drop(v1650_9);
    let v1650_14: Space = unite(&(v1650_7),&(v1650_13));
    drop(v1650_13);
    v1649_44.join_into((v1650_14).clone());
  }
  drop(v1649_44_cursor);
  drop(v1649_39);
  (v1649_44).clone()
}

fn routine_178(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1656_14 = Space::new();
  let mut v1656_14_cursor = (*s0).read_zipper();
  for v1656_14_byte in v1656_14_cursor.child_mask().iter() {
    v1656_14_cursor.descend_to_byte(v1656_14_byte);
    let v1656_14_tail = v1656_14_cursor.make_map();
    v1656_14_cursor.ascend(1);
    let v1656_14_head = Path::from_slice(&[v1656_14_byte]);
    let v1657_2: Space = singleton(&(v1656_14_head));
    let v1657_3: Space = intersect(&(*CONSTANT_7),&(v1657_2));
    let v1657_4: Space = if has_head(&(v1657_3)) { singleton(&[]) } else { Space::new() };
    drop(v1657_3);
    let v1657_5: Space = subtract(&(*CONSTANT_0),&(v1657_4));
    drop(v1657_4);
    let v1657_8: Space = if (v1657_5).is_empty() { Space::new() } else {
      let v1658_6: Path = concat_path(&(*p0),&(v1656_14_head));
      let v1658_7: Space = routine_178(c, &(v1658_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1656_14_tail));
      compose(&(v1657_5),&(v1658_7))
    };
    drop(v1657_5);
    let v1657_9: Space = intersect(&(*CONSTANT_7),&(v1657_2));
    drop(v1657_2);
    let v1657_10: Space = if has_head(&(v1657_9)) { singleton(&[]) } else { Space::new() };
    drop(v1657_9);
    let v1657_12: Space = if (v1657_10).is_empty() { Space::new() } else {
      let v1659_6: Path = concat_path(&(*p0),&(v1656_14_head));
      let mut v1659_11 = Space::new();
      let mut v1659_11_cursor = (v1656_14_tail).read_zipper();
      for v1659_11_byte in v1659_11_cursor.child_mask().iter() {
        v1659_11_cursor.descend_to_byte(v1659_11_byte);
        let v1659_11_tail = v1659_11_cursor.make_map();
        v1659_11_cursor.ascend(1);
        let v1659_11_head = Path::from_slice(&[v1659_11_byte]);
        let v1660_2: Space = singleton(&(v1659_11_head));
        let v1660_3: Space = intersect(&(*CONSTANT_7),&(v1660_2));
        let v1660_4: Space = if has_head(&(v1660_3)) { singleton(&[]) } else { Space::new() };
        drop(v1660_3);
        let v1660_5: Space = subtract(&(*CONSTANT_0),&(v1660_4));
        drop(v1660_4);
        let v1660_7: Space = if (v1660_5).is_empty() { Space::new() } else {
          let v1661_6: Space = routine_196(c, &(v1659_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1659_6), &(v1659_11_tail));
          compose(&(v1660_5),&(v1661_6))
        };
        drop(v1660_5);
        let v1660_8: Space = intersect(&(*CONSTANT_7),&(v1660_2));
        drop(v1660_2);
        let v1660_9: Space = if has_head(&(v1660_8)) { singleton(&[]) } else { Space::new() };
        drop(v1660_8);
        let v1660_11: Space = if (v1660_9).is_empty() { Space::new() } else {
          let v1662_10: Space = routine_197(c, &(v1659_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1659_6), &(v1659_11_tail));
          compose(&(v1660_9),&(v1662_10))
        };
        drop(v1660_9);
        let v1660_12: Space = unite(&(v1660_7),&(v1660_11));
        v1659_11.join_into((v1660_12).clone());
      }
      drop(v1659_11_cursor);
      drop(v1659_6);
      compose(&(v1657_10),&(v1659_11))
    };
    drop(v1657_10);
    let v1657_13: Space = unite(&(v1657_8),&(v1657_12));
    v1656_14.join_into((v1657_13).clone());
  }
  drop(v1656_14_cursor);
  (v1656_14).clone()
}

fn routine_179(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let v1663_13: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1663_14: Space = singleton(&(v1663_13));
  drop(v1663_13);
  let v1663_15: Space = unite(&(*CONSTANT_39),&(v1663_14));
  drop(v1663_14);
  let v1663_17: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1663_18: Space = singleton(&(v1663_17));
  drop(v1663_17);
  let v1663_19: Space = unite(&(v1663_15),&(v1663_18));
  drop(v1663_15);
  drop(v1663_18);
  let v1663_21: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1663_22: Space = singleton(&(v1663_21));
  drop(v1663_21);
  let v1663_23: Space = unite(&(v1663_19),&(v1663_22));
  drop(v1663_19);
  drop(v1663_22);
  let v1663_25: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1663_26: Space = singleton(&(v1663_25));
  drop(v1663_25);
  let v1663_27: Space = unite(&(v1663_23),&(v1663_26));
  drop(v1663_23);
  drop(v1663_26);
  let v1663_29: Path = concat_path(&(*CONSTANT_25),&(*p5));
  let v1663_30: Space = singleton(&(v1663_29));
  drop(v1663_29);
  let v1663_31: Space = unite(&(v1663_27),&(v1663_30));
  drop(v1663_27);
  drop(v1663_30);
  let v1663_33: Path = concat_path(&(*CONSTANT_26),&(*p6));
  let v1663_34: Space = singleton(&(v1663_33));
  drop(v1663_33);
  let v1663_35: Space = unite(&(v1663_31),&(v1663_34));
  drop(v1663_31);
  drop(v1663_34);
  let v1663_37: Path = concat_path(&(*CONSTANT_27),&(*p0));
  let v1663_38: Space = singleton(&(v1663_37));
  drop(v1663_37);
  let v1663_39: Space = unite(&(v1663_35),&(v1663_38));
  drop(v1663_35);
  drop(v1663_38);
  let mut v1663_44 = Space::new();
  let mut v1663_44_cursor = (*s0).read_zipper();
  for v1663_44_byte in v1663_44_cursor.child_mask().iter() {
    v1663_44_cursor.descend_to_byte(v1663_44_byte);
    let v1663_44_tail = v1663_44_cursor.make_map();
    v1663_44_cursor.ascend(1);
    let v1663_44_head = Path::from_slice(&[v1663_44_byte]);
    let v1664_2: Space = singleton(&(v1663_44_head));
    let v1664_3: Space = intersect(&(*CONSTANT_7),&(v1664_2));
    let v1664_4: Space = if has_head(&(v1664_3)) { singleton(&[]) } else { Space::new() };
    drop(v1664_3);
    let v1664_5: Space = subtract(&(*CONSTANT_0),&(v1664_4));
    drop(v1664_4);
    let v1664_7: Space = if (v1664_5).is_empty() { Space::new() } else {
      let mut v1665_6 = Space::new();
      let mut v1665_6_cursor = (v1663_44_tail).read_zipper();
      for v1665_6_byte in v1665_6_cursor.child_mask().iter() {
        v1665_6_cursor.descend_to_byte(v1665_6_byte);
        let v1665_6_tail = v1665_6_cursor.make_map();
        v1665_6_cursor.ascend(1);
        let v1665_6_head = Path::from_slice(&[v1665_6_byte]);
        let v1666_2: Space = singleton(&(v1665_6_head));
        let v1666_3: Space = intersect(&(*CONSTANT_7),&(v1666_2));
        let v1666_4: Space = if has_head(&(v1666_3)) { singleton(&[]) } else { Space::new() };
        drop(v1666_3);
        let v1666_5: Space = subtract(&(*CONSTANT_0),&(v1666_4));
        drop(v1666_4);
        let v1666_8: Space = if (v1666_5).is_empty() { Space::new() } else {
          let v1667_6: Path = concat_path(&(v1663_44_head),&(v1665_6_head));
          let v1667_7: Space = routine_196(c, &(v1667_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1665_6_tail));
          compose(&(v1666_5),&(v1667_7))
        };
        drop(v1666_5);
        let v1666_9: Space = intersect(&(*CONSTANT_7),&(v1666_2));
        drop(v1666_2);
        let v1666_10: Space = if has_head(&(v1666_9)) { singleton(&[]) } else { Space::new() };
        drop(v1666_9);
        let v1666_12: Space = if (v1666_10).is_empty() { Space::new() } else {
          let v1668_6: Path = concat_path(&(v1663_44_head),&(v1665_6_head));
          let v1668_11: Space = routine_197(c, &(v1668_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1665_6_tail));
          drop(v1668_6);
          compose(&(v1666_10),&(v1668_11))
        };
        drop(v1666_10);
        let v1666_13: Space = unite(&(v1666_8),&(v1666_12));
        v1665_6.join_into((v1666_13).clone());
      }
      drop(v1665_6_cursor);
      compose(&(v1664_5),&(v1665_6))
    };
    drop(v1664_5);
    let v1664_8: Space = intersect(&(*CONSTANT_7),&(v1664_2));
    drop(v1664_2);
    let v1664_9: Space = if has_head(&(v1664_8)) { singleton(&[]) } else { Space::new() };
    drop(v1664_8);
    let v1664_13: Space = if (v1664_9).is_empty() { Space::new() } else {
      let v1669_10: Path = concat_path(&(*CONSTANT_29),&(v1663_44_head));
      let v1669_11: Space = singleton(&(v1669_10));
      drop(v1669_10);
      let v1669_12: Space = unite(&(v1663_39),&(v1669_11));
      drop(v1669_11);
      compose(&(v1664_9),&(v1669_12))
    };
    drop(v1664_9);
    let v1664_14: Space = unite(&(v1664_7),&(v1664_13));
    drop(v1664_13);
    v1663_44.join_into((v1664_14).clone());
  }
  drop(v1663_44_cursor);
  drop(v1663_39);
  (v1663_44).clone()
}

fn routine_180(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1670_14 = Space::new();
  let mut v1670_14_cursor = (*s0).read_zipper();
  for v1670_14_byte in v1670_14_cursor.child_mask().iter() {
    v1670_14_cursor.descend_to_byte(v1670_14_byte);
    let v1670_14_tail = v1670_14_cursor.make_map();
    v1670_14_cursor.ascend(1);
    let v1670_14_head = Path::from_slice(&[v1670_14_byte]);
    let v1671_2: Space = singleton(&(v1670_14_head));
    let v1671_3: Space = intersect(&(*CONSTANT_7),&(v1671_2));
    let v1671_4: Space = if has_head(&(v1671_3)) { singleton(&[]) } else { Space::new() };
    drop(v1671_3);
    let v1671_5: Space = subtract(&(*CONSTANT_0),&(v1671_4));
    drop(v1671_4);
    let v1671_8: Space = if (v1671_5).is_empty() { Space::new() } else {
      let v1672_6: Path = concat_path(&(*p0),&(v1670_14_head));
      let v1672_7: Space = routine_180(c, &(v1672_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1670_14_tail));
      compose(&(v1671_5),&(v1672_7))
    };
    drop(v1671_5);
    let v1671_9: Space = intersect(&(*CONSTANT_7),&(v1671_2));
    drop(v1671_2);
    let v1671_10: Space = if has_head(&(v1671_9)) { singleton(&[]) } else { Space::new() };
    drop(v1671_9);
    let v1671_12: Space = if (v1671_10).is_empty() { Space::new() } else {
      let v1673_6: Path = concat_path(&(*p0),&(v1670_14_head));
      let mut v1673_11 = Space::new();
      let mut v1673_11_cursor = (v1670_14_tail).read_zipper();
      for v1673_11_byte in v1673_11_cursor.child_mask().iter() {
        v1673_11_cursor.descend_to_byte(v1673_11_byte);
        let v1673_11_tail = v1673_11_cursor.make_map();
        v1673_11_cursor.ascend(1);
        let v1673_11_head = Path::from_slice(&[v1673_11_byte]);
        let v1674_2: Space = singleton(&(v1673_11_head));
        let v1674_3: Space = intersect(&(*CONSTANT_7),&(v1674_2));
        let v1674_4: Space = if has_head(&(v1674_3)) { singleton(&[]) } else { Space::new() };
        drop(v1674_3);
        let v1674_5: Space = subtract(&(*CONSTANT_0),&(v1674_4));
        drop(v1674_4);
        let v1674_7: Space = if (v1674_5).is_empty() { Space::new() } else {
          let v1675_6: Space = routine_198(c, &(v1673_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1673_6), &(v1673_11_tail));
          compose(&(v1674_5),&(v1675_6))
        };
        drop(v1674_5);
        let v1674_8: Space = intersect(&(*CONSTANT_7),&(v1674_2));
        drop(v1674_2);
        let v1674_9: Space = if has_head(&(v1674_8)) { singleton(&[]) } else { Space::new() };
        drop(v1674_8);
        let v1674_11: Space = if (v1674_9).is_empty() { Space::new() } else {
          let v1676_10: Space = routine_199(c, &(v1673_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v1673_6), &(v1673_11_tail));
          compose(&(v1674_9),&(v1676_10))
        };
        drop(v1674_9);
        let v1674_12: Space = unite(&(v1674_7),&(v1674_11));
        v1673_11.join_into((v1674_12).clone());
      }
      drop(v1673_11_cursor);
      drop(v1673_6);
      compose(&(v1671_10),&(v1673_11))
    };
    drop(v1671_10);
    let v1671_13: Space = unite(&(v1671_8),&(v1671_12));
    v1670_14.join_into((v1671_13).clone());
  }
  drop(v1670_14_cursor);
  (v1670_14).clone()
}

fn routine_181(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let v1677_13: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1677_14: Space = singleton(&(v1677_13));
  drop(v1677_13);
  let v1677_15: Space = unite(&(*CONSTANT_40),&(v1677_14));
  drop(v1677_14);
  let v1677_17: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1677_18: Space = singleton(&(v1677_17));
  drop(v1677_17);
  let v1677_19: Space = unite(&(v1677_15),&(v1677_18));
  drop(v1677_15);
  drop(v1677_18);
  let v1677_21: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1677_22: Space = singleton(&(v1677_21));
  drop(v1677_21);
  let v1677_23: Space = unite(&(v1677_19),&(v1677_22));
  drop(v1677_19);
  drop(v1677_22);
  let v1677_25: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1677_26: Space = singleton(&(v1677_25));
  drop(v1677_25);
  let v1677_27: Space = unite(&(v1677_23),&(v1677_26));
  drop(v1677_23);
  drop(v1677_26);
  let v1677_29: Path = concat_path(&(*CONSTANT_25),&(*p5));
  let v1677_30: Space = singleton(&(v1677_29));
  drop(v1677_29);
  let v1677_31: Space = unite(&(v1677_27),&(v1677_30));
  drop(v1677_27);
  drop(v1677_30);
  let v1677_33: Path = concat_path(&(*CONSTANT_26),&(*p6));
  let v1677_34: Space = singleton(&(v1677_33));
  drop(v1677_33);
  let v1677_35: Space = unite(&(v1677_31),&(v1677_34));
  drop(v1677_31);
  drop(v1677_34);
  let v1677_37: Path = concat_path(&(*CONSTANT_27),&(*p0));
  let v1677_38: Space = singleton(&(v1677_37));
  drop(v1677_37);
  let v1677_39: Space = unite(&(v1677_35),&(v1677_38));
  drop(v1677_35);
  drop(v1677_38);
  let mut v1677_44 = Space::new();
  let mut v1677_44_cursor = (*s0).read_zipper();
  for v1677_44_byte in v1677_44_cursor.child_mask().iter() {
    v1677_44_cursor.descend_to_byte(v1677_44_byte);
    let v1677_44_tail = v1677_44_cursor.make_map();
    v1677_44_cursor.ascend(1);
    let v1677_44_head = Path::from_slice(&[v1677_44_byte]);
    let v1678_2: Space = singleton(&(v1677_44_head));
    let v1678_3: Space = intersect(&(*CONSTANT_7),&(v1678_2));
    let v1678_4: Space = if has_head(&(v1678_3)) { singleton(&[]) } else { Space::new() };
    drop(v1678_3);
    let v1678_5: Space = subtract(&(*CONSTANT_0),&(v1678_4));
    drop(v1678_4);
    let v1678_7: Space = if (v1678_5).is_empty() { Space::new() } else {
      let mut v1679_6 = Space::new();
      let mut v1679_6_cursor = (v1677_44_tail).read_zipper();
      for v1679_6_byte in v1679_6_cursor.child_mask().iter() {
        v1679_6_cursor.descend_to_byte(v1679_6_byte);
        let v1679_6_tail = v1679_6_cursor.make_map();
        v1679_6_cursor.ascend(1);
        let v1679_6_head = Path::from_slice(&[v1679_6_byte]);
        let v1680_2: Space = singleton(&(v1679_6_head));
        let v1680_3: Space = intersect(&(*CONSTANT_7),&(v1680_2));
        let v1680_4: Space = if has_head(&(v1680_3)) { singleton(&[]) } else { Space::new() };
        drop(v1680_3);
        let v1680_5: Space = subtract(&(*CONSTANT_0),&(v1680_4));
        drop(v1680_4);
        let v1680_8: Space = if (v1680_5).is_empty() { Space::new() } else {
          let v1681_6: Path = concat_path(&(v1677_44_head),&(v1679_6_head));
          let v1681_7: Space = routine_198(c, &(v1681_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1679_6_tail));
          compose(&(v1680_5),&(v1681_7))
        };
        drop(v1680_5);
        let v1680_9: Space = intersect(&(*CONSTANT_7),&(v1680_2));
        drop(v1680_2);
        let v1680_10: Space = if has_head(&(v1680_9)) { singleton(&[]) } else { Space::new() };
        drop(v1680_9);
        let v1680_12: Space = if (v1680_10).is_empty() { Space::new() } else {
          let v1682_6: Path = concat_path(&(v1677_44_head),&(v1679_6_head));
          let v1682_11: Space = routine_199(c, &(v1682_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1679_6_tail));
          drop(v1682_6);
          compose(&(v1680_10),&(v1682_11))
        };
        drop(v1680_10);
        let v1680_13: Space = unite(&(v1680_8),&(v1680_12));
        v1679_6.join_into((v1680_13).clone());
      }
      drop(v1679_6_cursor);
      compose(&(v1678_5),&(v1679_6))
    };
    drop(v1678_5);
    let v1678_8: Space = intersect(&(*CONSTANT_7),&(v1678_2));
    drop(v1678_2);
    let v1678_9: Space = if has_head(&(v1678_8)) { singleton(&[]) } else { Space::new() };
    drop(v1678_8);
    let v1678_13: Space = if (v1678_9).is_empty() { Space::new() } else {
      let v1683_10: Path = concat_path(&(*CONSTANT_28),&(v1677_44_head));
      let v1683_11: Space = singleton(&(v1683_10));
      drop(v1683_10);
      let v1683_12: Space = unite(&(v1677_39),&(v1683_11));
      drop(v1683_11);
      compose(&(v1678_9),&(v1683_12))
    };
    drop(v1678_9);
    let v1678_14: Space = unite(&(v1678_7),&(v1678_13));
    drop(v1678_13);
    v1677_44.join_into((v1678_14).clone());
  }
  drop(v1677_44_cursor);
  drop(v1677_39);
  (v1677_44).clone()
}

fn routine_182(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1684_14: Path = concat_path(&(*CONSTANT_22),&(*p1));
  let v1684_15: Space = singleton(&(v1684_14));
  drop(v1684_14);
  let v1684_16: Space = unite(&(*CONSTANT_32),&(v1684_15));
  drop(v1684_15);
  let v1684_18: Path = concat_path(&(*CONSTANT_23),&(*p2));
  let v1684_19: Space = singleton(&(v1684_18));
  drop(v1684_18);
  let v1684_20: Space = unite(&(v1684_16),&(v1684_19));
  drop(v1684_16);
  drop(v1684_19);
  let v1684_22: Path = concat_path(&(*CONSTANT_24),&(*p3));
  let v1684_23: Space = singleton(&(v1684_22));
  drop(v1684_22);
  let v1684_24: Space = unite(&(v1684_20),&(v1684_23));
  drop(v1684_20);
  drop(v1684_23);
  let v1684_26: Path = concat_path(&(*CONSTANT_25),&(*p4));
  let v1684_27: Space = singleton(&(v1684_26));
  drop(v1684_26);
  let v1684_28: Space = unite(&(v1684_24),&(v1684_27));
  drop(v1684_24);
  drop(v1684_27);
  let v1684_30: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1684_31: Space = singleton(&(v1684_30));
  drop(v1684_30);
  let v1684_32: Space = unite(&(v1684_28),&(v1684_31));
  drop(v1684_28);
  drop(v1684_31);
  let v1684_34: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1684_35: Space = singleton(&(v1684_34));
  drop(v1684_34);
  let v1684_36: Space = unite(&(v1684_32),&(v1684_35));
  drop(v1684_32);
  drop(v1684_35);
  let v1684_38: Path = concat_path(&(*CONSTANT_28),&(*p7));
  let v1684_39: Space = singleton(&(v1684_38));
  drop(v1684_38);
  let v1684_40: Space = unite(&(v1684_36),&(v1684_39));
  drop(v1684_36);
  drop(v1684_39);
  let mut v1684_42 = Space::new();
  let mut v1684_42_cursor = (*s0).read_zipper();
  for v1684_42_byte in v1684_42_cursor.child_mask().iter() {
    v1684_42_cursor.descend_to_byte(v1684_42_byte);
    let v1684_42_tail = v1684_42_cursor.make_map();
    v1684_42_cursor.ascend(1);
    let v1684_42_head = Path::from_slice(&[v1684_42_byte]);
    let v1685_2: Space = singleton(&(v1684_42_head));
    let v1685_3: Space = intersect(&(*CONSTANT_7),&(v1685_2));
    let v1685_4: Space = if has_head(&(v1685_3)) { singleton(&[]) } else { Space::new() };
    drop(v1685_3);
    let v1685_5: Space = subtract(&(*CONSTANT_0),&(v1685_4));
    drop(v1685_4);
    let v1685_8: Space = if (v1685_5).is_empty() { Space::new() } else {
      let v1686_6: Path = concat_path(&(*p0),&(v1684_42_head));
      let v1686_7: Space = routine_182(c, &(v1686_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1684_42_tail));
      compose(&(v1685_5),&(v1686_7))
    };
    drop(v1685_5);
    let v1685_9: Space = intersect(&(*CONSTANT_7),&(v1685_2));
    drop(v1685_2);
    let v1685_10: Space = if has_head(&(v1685_9)) { singleton(&[]) } else { Space::new() };
    drop(v1685_9);
    let v1685_14: Space = if (v1685_10).is_empty() { Space::new() } else {
      let v1687_6: Path = concat_path(&(*p0),&(v1684_42_head));
      let v1687_11: Path = concat_path(&(*CONSTANT_29),&(v1687_6));
      drop(v1687_6);
      let v1687_12: Space = singleton(&(v1687_11));
      drop(v1687_11);
      let v1687_13: Space = unite(&(v1684_40),&(v1687_12));
      drop(v1687_12);
      compose(&(v1685_10),&(v1687_13))
    };
    drop(v1685_10);
    let v1685_15: Space = unite(&(v1685_8),&(v1685_14));
    drop(v1685_14);
    v1684_42.join_into((v1685_15).clone());
  }
  drop(v1684_42_cursor);
  drop(v1684_40);
  (v1684_42).clone()
}

fn routine_183(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1688_11: Path = concat_path(&(*CONSTANT_22),&(*p1));
  let v1688_12: Space = singleton(&(v1688_11));
  drop(v1688_11);
  let v1688_13: Space = unite(&(*CONSTANT_32),&(v1688_12));
  drop(v1688_12);
  let v1688_15: Path = concat_path(&(*CONSTANT_23),&(*p2));
  let v1688_16: Space = singleton(&(v1688_15));
  drop(v1688_15);
  let v1688_17: Space = unite(&(v1688_13),&(v1688_16));
  drop(v1688_13);
  drop(v1688_16);
  let v1688_19: Path = concat_path(&(*CONSTANT_24),&(*p3));
  let v1688_20: Space = singleton(&(v1688_19));
  drop(v1688_19);
  let v1688_21: Space = unite(&(v1688_17),&(v1688_20));
  drop(v1688_17);
  drop(v1688_20);
  let v1688_23: Path = concat_path(&(*CONSTANT_25),&(*p4));
  let v1688_24: Space = singleton(&(v1688_23));
  drop(v1688_23);
  let v1688_25: Space = unite(&(v1688_21),&(v1688_24));
  drop(v1688_21);
  drop(v1688_24);
  let v1688_27: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1688_28: Space = singleton(&(v1688_27));
  drop(v1688_27);
  let v1688_29: Space = unite(&(v1688_25),&(v1688_28));
  drop(v1688_25);
  drop(v1688_28);
  let v1688_31: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1688_32: Space = singleton(&(v1688_31));
  drop(v1688_31);
  let v1688_33: Space = unite(&(v1688_29),&(v1688_32));
  drop(v1688_29);
  drop(v1688_32);
  let v1688_35: Path = concat_path(&(*CONSTANT_28),&(*p7));
  let v1688_36: Space = singleton(&(v1688_35));
  drop(v1688_35);
  let v1688_37: Space = unite(&(v1688_33),&(v1688_36));
  drop(v1688_33);
  drop(v1688_36);
  let v1688_39: Path = concat_path(&(*CONSTANT_29),&(*p0));
  let v1688_40: Space = singleton(&(v1688_39));
  drop(v1688_39);
  let v1688_41: Space = unite(&(v1688_37),&(v1688_40));
  drop(v1688_37);
  drop(v1688_40);
  (v1688_41).clone()
}

fn routine_184(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1689_14: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1689_15: Space = singleton(&(v1689_14));
  drop(v1689_14);
  let v1689_16: Space = unite(&(*CONSTANT_33),&(v1689_15));
  drop(v1689_15);
  let v1689_18: Path = concat_path(&(*CONSTANT_23),&(*p2));
  let v1689_19: Space = singleton(&(v1689_18));
  drop(v1689_18);
  let v1689_20: Space = unite(&(v1689_16),&(v1689_19));
  drop(v1689_16);
  drop(v1689_19);
  let v1689_22: Path = concat_path(&(*CONSTANT_24),&(*p3));
  let v1689_23: Space = singleton(&(v1689_22));
  drop(v1689_22);
  let v1689_24: Space = unite(&(v1689_20),&(v1689_23));
  drop(v1689_20);
  drop(v1689_23);
  let v1689_26: Path = concat_path(&(*CONSTANT_25),&(*p4));
  let v1689_27: Space = singleton(&(v1689_26));
  drop(v1689_26);
  let v1689_28: Space = unite(&(v1689_24),&(v1689_27));
  drop(v1689_24);
  drop(v1689_27);
  let v1689_30: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1689_31: Space = singleton(&(v1689_30));
  drop(v1689_30);
  let v1689_32: Space = unite(&(v1689_28),&(v1689_31));
  drop(v1689_28);
  drop(v1689_31);
  let v1689_34: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1689_35: Space = singleton(&(v1689_34));
  drop(v1689_34);
  let v1689_36: Space = unite(&(v1689_32),&(v1689_35));
  drop(v1689_32);
  drop(v1689_35);
  let v1689_38: Path = concat_path(&(*CONSTANT_28),&(*p7));
  let v1689_39: Space = singleton(&(v1689_38));
  drop(v1689_38);
  let v1689_40: Space = unite(&(v1689_36),&(v1689_39));
  drop(v1689_36);
  drop(v1689_39);
  let mut v1689_42 = Space::new();
  let mut v1689_42_cursor = (*s0).read_zipper();
  for v1689_42_byte in v1689_42_cursor.child_mask().iter() {
    v1689_42_cursor.descend_to_byte(v1689_42_byte);
    let v1689_42_tail = v1689_42_cursor.make_map();
    v1689_42_cursor.ascend(1);
    let v1689_42_head = Path::from_slice(&[v1689_42_byte]);
    let v1690_2: Space = singleton(&(v1689_42_head));
    let v1690_3: Space = intersect(&(*CONSTANT_7),&(v1690_2));
    let v1690_4: Space = if has_head(&(v1690_3)) { singleton(&[]) } else { Space::new() };
    drop(v1690_3);
    let v1690_5: Space = subtract(&(*CONSTANT_0),&(v1690_4));
    drop(v1690_4);
    let v1690_8: Space = if (v1690_5).is_empty() { Space::new() } else {
      let v1691_6: Path = concat_path(&(*p0),&(v1689_42_head));
      let v1691_7: Space = routine_184(c, &(v1691_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1689_42_tail));
      compose(&(v1690_5),&(v1691_7))
    };
    drop(v1690_5);
    let v1690_9: Space = intersect(&(*CONSTANT_7),&(v1690_2));
    drop(v1690_2);
    let v1690_10: Space = if has_head(&(v1690_9)) { singleton(&[]) } else { Space::new() };
    drop(v1690_9);
    let v1690_14: Space = if (v1690_10).is_empty() { Space::new() } else {
      let v1692_6: Path = concat_path(&(*p0),&(v1689_42_head));
      let v1692_11: Path = concat_path(&(*CONSTANT_29),&(v1692_6));
      drop(v1692_6);
      let v1692_12: Space = singleton(&(v1692_11));
      drop(v1692_11);
      let v1692_13: Space = unite(&(v1689_40),&(v1692_12));
      drop(v1692_12);
      compose(&(v1690_10),&(v1692_13))
    };
    drop(v1690_10);
    let v1690_15: Space = unite(&(v1690_8),&(v1690_14));
    drop(v1690_14);
    v1689_42.join_into((v1690_15).clone());
  }
  drop(v1689_42_cursor);
  drop(v1689_40);
  (v1689_42).clone()
}

fn routine_185(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1693_11: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1693_12: Space = singleton(&(v1693_11));
  drop(v1693_11);
  let v1693_13: Space = unite(&(*CONSTANT_33),&(v1693_12));
  drop(v1693_12);
  let v1693_15: Path = concat_path(&(*CONSTANT_23),&(*p2));
  let v1693_16: Space = singleton(&(v1693_15));
  drop(v1693_15);
  let v1693_17: Space = unite(&(v1693_13),&(v1693_16));
  drop(v1693_13);
  drop(v1693_16);
  let v1693_19: Path = concat_path(&(*CONSTANT_24),&(*p3));
  let v1693_20: Space = singleton(&(v1693_19));
  drop(v1693_19);
  let v1693_21: Space = unite(&(v1693_17),&(v1693_20));
  drop(v1693_17);
  drop(v1693_20);
  let v1693_23: Path = concat_path(&(*CONSTANT_25),&(*p4));
  let v1693_24: Space = singleton(&(v1693_23));
  drop(v1693_23);
  let v1693_25: Space = unite(&(v1693_21),&(v1693_24));
  drop(v1693_21);
  drop(v1693_24);
  let v1693_27: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1693_28: Space = singleton(&(v1693_27));
  drop(v1693_27);
  let v1693_29: Space = unite(&(v1693_25),&(v1693_28));
  drop(v1693_25);
  drop(v1693_28);
  let v1693_31: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1693_32: Space = singleton(&(v1693_31));
  drop(v1693_31);
  let v1693_33: Space = unite(&(v1693_29),&(v1693_32));
  drop(v1693_29);
  drop(v1693_32);
  let v1693_35: Path = concat_path(&(*CONSTANT_28),&(*p7));
  let v1693_36: Space = singleton(&(v1693_35));
  drop(v1693_35);
  let v1693_37: Space = unite(&(v1693_33),&(v1693_36));
  drop(v1693_33);
  drop(v1693_36);
  let v1693_39: Path = concat_path(&(*CONSTANT_29),&(*p0));
  let v1693_40: Space = singleton(&(v1693_39));
  drop(v1693_39);
  let v1693_41: Space = unite(&(v1693_37),&(v1693_40));
  drop(v1693_37);
  drop(v1693_40);
  (v1693_41).clone()
}

fn routine_186(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1694_14: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1694_15: Space = singleton(&(v1694_14));
  drop(v1694_14);
  let v1694_16: Space = unite(&(*CONSTANT_34),&(v1694_15));
  drop(v1694_15);
  let v1694_18: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1694_19: Space = singleton(&(v1694_18));
  drop(v1694_18);
  let v1694_20: Space = unite(&(v1694_16),&(v1694_19));
  drop(v1694_16);
  drop(v1694_19);
  let v1694_22: Path = concat_path(&(*CONSTANT_24),&(*p3));
  let v1694_23: Space = singleton(&(v1694_22));
  drop(v1694_22);
  let v1694_24: Space = unite(&(v1694_20),&(v1694_23));
  drop(v1694_20);
  drop(v1694_23);
  let v1694_26: Path = concat_path(&(*CONSTANT_25),&(*p4));
  let v1694_27: Space = singleton(&(v1694_26));
  drop(v1694_26);
  let v1694_28: Space = unite(&(v1694_24),&(v1694_27));
  drop(v1694_24);
  drop(v1694_27);
  let v1694_30: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1694_31: Space = singleton(&(v1694_30));
  drop(v1694_30);
  let v1694_32: Space = unite(&(v1694_28),&(v1694_31));
  drop(v1694_28);
  drop(v1694_31);
  let v1694_34: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1694_35: Space = singleton(&(v1694_34));
  drop(v1694_34);
  let v1694_36: Space = unite(&(v1694_32),&(v1694_35));
  drop(v1694_32);
  drop(v1694_35);
  let v1694_38: Path = concat_path(&(*CONSTANT_28),&(*p7));
  let v1694_39: Space = singleton(&(v1694_38));
  drop(v1694_38);
  let v1694_40: Space = unite(&(v1694_36),&(v1694_39));
  drop(v1694_36);
  drop(v1694_39);
  let mut v1694_42 = Space::new();
  let mut v1694_42_cursor = (*s0).read_zipper();
  for v1694_42_byte in v1694_42_cursor.child_mask().iter() {
    v1694_42_cursor.descend_to_byte(v1694_42_byte);
    let v1694_42_tail = v1694_42_cursor.make_map();
    v1694_42_cursor.ascend(1);
    let v1694_42_head = Path::from_slice(&[v1694_42_byte]);
    let v1695_2: Space = singleton(&(v1694_42_head));
    let v1695_3: Space = intersect(&(*CONSTANT_7),&(v1695_2));
    let v1695_4: Space = if has_head(&(v1695_3)) { singleton(&[]) } else { Space::new() };
    drop(v1695_3);
    let v1695_5: Space = subtract(&(*CONSTANT_0),&(v1695_4));
    drop(v1695_4);
    let v1695_8: Space = if (v1695_5).is_empty() { Space::new() } else {
      let v1696_6: Path = concat_path(&(*p0),&(v1694_42_head));
      let v1696_7: Space = routine_186(c, &(v1696_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1694_42_tail));
      compose(&(v1695_5),&(v1696_7))
    };
    drop(v1695_5);
    let v1695_9: Space = intersect(&(*CONSTANT_7),&(v1695_2));
    drop(v1695_2);
    let v1695_10: Space = if has_head(&(v1695_9)) { singleton(&[]) } else { Space::new() };
    drop(v1695_9);
    let v1695_14: Space = if (v1695_10).is_empty() { Space::new() } else {
      let v1697_6: Path = concat_path(&(*p0),&(v1694_42_head));
      let v1697_11: Path = concat_path(&(*CONSTANT_29),&(v1697_6));
      drop(v1697_6);
      let v1697_12: Space = singleton(&(v1697_11));
      drop(v1697_11);
      let v1697_13: Space = unite(&(v1694_40),&(v1697_12));
      drop(v1697_12);
      compose(&(v1695_10),&(v1697_13))
    };
    drop(v1695_10);
    let v1695_15: Space = unite(&(v1695_8),&(v1695_14));
    drop(v1695_14);
    v1694_42.join_into((v1695_15).clone());
  }
  drop(v1694_42_cursor);
  drop(v1694_40);
  (v1694_42).clone()
}

fn routine_187(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1698_11: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1698_12: Space = singleton(&(v1698_11));
  drop(v1698_11);
  let v1698_13: Space = unite(&(*CONSTANT_34),&(v1698_12));
  drop(v1698_12);
  let v1698_15: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1698_16: Space = singleton(&(v1698_15));
  drop(v1698_15);
  let v1698_17: Space = unite(&(v1698_13),&(v1698_16));
  drop(v1698_13);
  drop(v1698_16);
  let v1698_19: Path = concat_path(&(*CONSTANT_24),&(*p3));
  let v1698_20: Space = singleton(&(v1698_19));
  drop(v1698_19);
  let v1698_21: Space = unite(&(v1698_17),&(v1698_20));
  drop(v1698_17);
  drop(v1698_20);
  let v1698_23: Path = concat_path(&(*CONSTANT_25),&(*p4));
  let v1698_24: Space = singleton(&(v1698_23));
  drop(v1698_23);
  let v1698_25: Space = unite(&(v1698_21),&(v1698_24));
  drop(v1698_21);
  drop(v1698_24);
  let v1698_27: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1698_28: Space = singleton(&(v1698_27));
  drop(v1698_27);
  let v1698_29: Space = unite(&(v1698_25),&(v1698_28));
  drop(v1698_25);
  drop(v1698_28);
  let v1698_31: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1698_32: Space = singleton(&(v1698_31));
  drop(v1698_31);
  let v1698_33: Space = unite(&(v1698_29),&(v1698_32));
  drop(v1698_29);
  drop(v1698_32);
  let v1698_35: Path = concat_path(&(*CONSTANT_28),&(*p7));
  let v1698_36: Space = singleton(&(v1698_35));
  drop(v1698_35);
  let v1698_37: Space = unite(&(v1698_33),&(v1698_36));
  drop(v1698_33);
  drop(v1698_36);
  let v1698_39: Path = concat_path(&(*CONSTANT_29),&(*p0));
  let v1698_40: Space = singleton(&(v1698_39));
  drop(v1698_39);
  let v1698_41: Space = unite(&(v1698_37),&(v1698_40));
  drop(v1698_37);
  drop(v1698_40);
  (v1698_41).clone()
}

fn routine_188(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1699_14: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1699_15: Space = singleton(&(v1699_14));
  drop(v1699_14);
  let v1699_16: Space = unite(&(*CONSTANT_35),&(v1699_15));
  drop(v1699_15);
  let v1699_18: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1699_19: Space = singleton(&(v1699_18));
  drop(v1699_18);
  let v1699_20: Space = unite(&(v1699_16),&(v1699_19));
  drop(v1699_16);
  drop(v1699_19);
  let v1699_22: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1699_23: Space = singleton(&(v1699_22));
  drop(v1699_22);
  let v1699_24: Space = unite(&(v1699_20),&(v1699_23));
  drop(v1699_20);
  drop(v1699_23);
  let v1699_26: Path = concat_path(&(*CONSTANT_25),&(*p4));
  let v1699_27: Space = singleton(&(v1699_26));
  drop(v1699_26);
  let v1699_28: Space = unite(&(v1699_24),&(v1699_27));
  drop(v1699_24);
  drop(v1699_27);
  let v1699_30: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1699_31: Space = singleton(&(v1699_30));
  drop(v1699_30);
  let v1699_32: Space = unite(&(v1699_28),&(v1699_31));
  drop(v1699_28);
  drop(v1699_31);
  let v1699_34: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1699_35: Space = singleton(&(v1699_34));
  drop(v1699_34);
  let v1699_36: Space = unite(&(v1699_32),&(v1699_35));
  drop(v1699_32);
  drop(v1699_35);
  let v1699_38: Path = concat_path(&(*CONSTANT_28),&(*p7));
  let v1699_39: Space = singleton(&(v1699_38));
  drop(v1699_38);
  let v1699_40: Space = unite(&(v1699_36),&(v1699_39));
  drop(v1699_36);
  drop(v1699_39);
  let mut v1699_42 = Space::new();
  let mut v1699_42_cursor = (*s0).read_zipper();
  for v1699_42_byte in v1699_42_cursor.child_mask().iter() {
    v1699_42_cursor.descend_to_byte(v1699_42_byte);
    let v1699_42_tail = v1699_42_cursor.make_map();
    v1699_42_cursor.ascend(1);
    let v1699_42_head = Path::from_slice(&[v1699_42_byte]);
    let v1700_2: Space = singleton(&(v1699_42_head));
    let v1700_3: Space = intersect(&(*CONSTANT_7),&(v1700_2));
    let v1700_4: Space = if has_head(&(v1700_3)) { singleton(&[]) } else { Space::new() };
    drop(v1700_3);
    let v1700_5: Space = subtract(&(*CONSTANT_0),&(v1700_4));
    drop(v1700_4);
    let v1700_8: Space = if (v1700_5).is_empty() { Space::new() } else {
      let v1701_6: Path = concat_path(&(*p0),&(v1699_42_head));
      let v1701_7: Space = routine_188(c, &(v1701_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1699_42_tail));
      compose(&(v1700_5),&(v1701_7))
    };
    drop(v1700_5);
    let v1700_9: Space = intersect(&(*CONSTANT_7),&(v1700_2));
    drop(v1700_2);
    let v1700_10: Space = if has_head(&(v1700_9)) { singleton(&[]) } else { Space::new() };
    drop(v1700_9);
    let v1700_14: Space = if (v1700_10).is_empty() { Space::new() } else {
      let v1702_6: Path = concat_path(&(*p0),&(v1699_42_head));
      let v1702_11: Path = concat_path(&(*CONSTANT_29),&(v1702_6));
      drop(v1702_6);
      let v1702_12: Space = singleton(&(v1702_11));
      drop(v1702_11);
      let v1702_13: Space = unite(&(v1699_40),&(v1702_12));
      drop(v1702_12);
      compose(&(v1700_10),&(v1702_13))
    };
    drop(v1700_10);
    let v1700_15: Space = unite(&(v1700_8),&(v1700_14));
    drop(v1700_14);
    v1699_42.join_into((v1700_15).clone());
  }
  drop(v1699_42_cursor);
  drop(v1699_40);
  (v1699_42).clone()
}

fn routine_189(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1703_11: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1703_12: Space = singleton(&(v1703_11));
  drop(v1703_11);
  let v1703_13: Space = unite(&(*CONSTANT_35),&(v1703_12));
  drop(v1703_12);
  let v1703_15: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1703_16: Space = singleton(&(v1703_15));
  drop(v1703_15);
  let v1703_17: Space = unite(&(v1703_13),&(v1703_16));
  drop(v1703_13);
  drop(v1703_16);
  let v1703_19: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1703_20: Space = singleton(&(v1703_19));
  drop(v1703_19);
  let v1703_21: Space = unite(&(v1703_17),&(v1703_20));
  drop(v1703_17);
  drop(v1703_20);
  let v1703_23: Path = concat_path(&(*CONSTANT_25),&(*p4));
  let v1703_24: Space = singleton(&(v1703_23));
  drop(v1703_23);
  let v1703_25: Space = unite(&(v1703_21),&(v1703_24));
  drop(v1703_21);
  drop(v1703_24);
  let v1703_27: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1703_28: Space = singleton(&(v1703_27));
  drop(v1703_27);
  let v1703_29: Space = unite(&(v1703_25),&(v1703_28));
  drop(v1703_25);
  drop(v1703_28);
  let v1703_31: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1703_32: Space = singleton(&(v1703_31));
  drop(v1703_31);
  let v1703_33: Space = unite(&(v1703_29),&(v1703_32));
  drop(v1703_29);
  drop(v1703_32);
  let v1703_35: Path = concat_path(&(*CONSTANT_28),&(*p7));
  let v1703_36: Space = singleton(&(v1703_35));
  drop(v1703_35);
  let v1703_37: Space = unite(&(v1703_33),&(v1703_36));
  drop(v1703_33);
  drop(v1703_36);
  let v1703_39: Path = concat_path(&(*CONSTANT_29),&(*p0));
  let v1703_40: Space = singleton(&(v1703_39));
  drop(v1703_39);
  let v1703_41: Space = unite(&(v1703_37),&(v1703_40));
  drop(v1703_37);
  drop(v1703_40);
  (v1703_41).clone()
}

fn routine_190(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1704_14: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1704_15: Space = singleton(&(v1704_14));
  drop(v1704_14);
  let v1704_16: Space = unite(&(*CONSTANT_36),&(v1704_15));
  drop(v1704_15);
  let v1704_18: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1704_19: Space = singleton(&(v1704_18));
  drop(v1704_18);
  let v1704_20: Space = unite(&(v1704_16),&(v1704_19));
  drop(v1704_16);
  drop(v1704_19);
  let v1704_22: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1704_23: Space = singleton(&(v1704_22));
  drop(v1704_22);
  let v1704_24: Space = unite(&(v1704_20),&(v1704_23));
  drop(v1704_20);
  drop(v1704_23);
  let v1704_26: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1704_27: Space = singleton(&(v1704_26));
  drop(v1704_26);
  let v1704_28: Space = unite(&(v1704_24),&(v1704_27));
  drop(v1704_24);
  drop(v1704_27);
  let v1704_30: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1704_31: Space = singleton(&(v1704_30));
  drop(v1704_30);
  let v1704_32: Space = unite(&(v1704_28),&(v1704_31));
  drop(v1704_28);
  drop(v1704_31);
  let v1704_34: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1704_35: Space = singleton(&(v1704_34));
  drop(v1704_34);
  let v1704_36: Space = unite(&(v1704_32),&(v1704_35));
  drop(v1704_32);
  drop(v1704_35);
  let v1704_38: Path = concat_path(&(*CONSTANT_28),&(*p7));
  let v1704_39: Space = singleton(&(v1704_38));
  drop(v1704_38);
  let v1704_40: Space = unite(&(v1704_36),&(v1704_39));
  drop(v1704_36);
  drop(v1704_39);
  let mut v1704_42 = Space::new();
  let mut v1704_42_cursor = (*s0).read_zipper();
  for v1704_42_byte in v1704_42_cursor.child_mask().iter() {
    v1704_42_cursor.descend_to_byte(v1704_42_byte);
    let v1704_42_tail = v1704_42_cursor.make_map();
    v1704_42_cursor.ascend(1);
    let v1704_42_head = Path::from_slice(&[v1704_42_byte]);
    let v1705_2: Space = singleton(&(v1704_42_head));
    let v1705_3: Space = intersect(&(*CONSTANT_7),&(v1705_2));
    let v1705_4: Space = if has_head(&(v1705_3)) { singleton(&[]) } else { Space::new() };
    drop(v1705_3);
    let v1705_5: Space = subtract(&(*CONSTANT_0),&(v1705_4));
    drop(v1705_4);
    let v1705_8: Space = if (v1705_5).is_empty() { Space::new() } else {
      let v1706_6: Path = concat_path(&(*p0),&(v1704_42_head));
      let v1706_7: Space = routine_190(c, &(v1706_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1704_42_tail));
      compose(&(v1705_5),&(v1706_7))
    };
    drop(v1705_5);
    let v1705_9: Space = intersect(&(*CONSTANT_7),&(v1705_2));
    drop(v1705_2);
    let v1705_10: Space = if has_head(&(v1705_9)) { singleton(&[]) } else { Space::new() };
    drop(v1705_9);
    let v1705_14: Space = if (v1705_10).is_empty() { Space::new() } else {
      let v1707_6: Path = concat_path(&(*p0),&(v1704_42_head));
      let v1707_11: Path = concat_path(&(*CONSTANT_29),&(v1707_6));
      drop(v1707_6);
      let v1707_12: Space = singleton(&(v1707_11));
      drop(v1707_11);
      let v1707_13: Space = unite(&(v1704_40),&(v1707_12));
      drop(v1707_12);
      compose(&(v1705_10),&(v1707_13))
    };
    drop(v1705_10);
    let v1705_15: Space = unite(&(v1705_8),&(v1705_14));
    drop(v1705_14);
    v1704_42.join_into((v1705_15).clone());
  }
  drop(v1704_42_cursor);
  drop(v1704_40);
  (v1704_42).clone()
}

fn routine_191(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1708_11: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1708_12: Space = singleton(&(v1708_11));
  drop(v1708_11);
  let v1708_13: Space = unite(&(*CONSTANT_36),&(v1708_12));
  drop(v1708_12);
  let v1708_15: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1708_16: Space = singleton(&(v1708_15));
  drop(v1708_15);
  let v1708_17: Space = unite(&(v1708_13),&(v1708_16));
  drop(v1708_13);
  drop(v1708_16);
  let v1708_19: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1708_20: Space = singleton(&(v1708_19));
  drop(v1708_19);
  let v1708_21: Space = unite(&(v1708_17),&(v1708_20));
  drop(v1708_17);
  drop(v1708_20);
  let v1708_23: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1708_24: Space = singleton(&(v1708_23));
  drop(v1708_23);
  let v1708_25: Space = unite(&(v1708_21),&(v1708_24));
  drop(v1708_21);
  drop(v1708_24);
  let v1708_27: Path = concat_path(&(*CONSTANT_26),&(*p5));
  let v1708_28: Space = singleton(&(v1708_27));
  drop(v1708_27);
  let v1708_29: Space = unite(&(v1708_25),&(v1708_28));
  drop(v1708_25);
  drop(v1708_28);
  let v1708_31: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1708_32: Space = singleton(&(v1708_31));
  drop(v1708_31);
  let v1708_33: Space = unite(&(v1708_29),&(v1708_32));
  drop(v1708_29);
  drop(v1708_32);
  let v1708_35: Path = concat_path(&(*CONSTANT_28),&(*p7));
  let v1708_36: Space = singleton(&(v1708_35));
  drop(v1708_35);
  let v1708_37: Space = unite(&(v1708_33),&(v1708_36));
  drop(v1708_33);
  drop(v1708_36);
  let v1708_39: Path = concat_path(&(*CONSTANT_29),&(*p0));
  let v1708_40: Space = singleton(&(v1708_39));
  drop(v1708_39);
  let v1708_41: Space = unite(&(v1708_37),&(v1708_40));
  drop(v1708_37);
  drop(v1708_40);
  (v1708_41).clone()
}

fn routine_192(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1709_14: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1709_15: Space = singleton(&(v1709_14));
  drop(v1709_14);
  let v1709_16: Space = unite(&(*CONSTANT_37),&(v1709_15));
  drop(v1709_15);
  let v1709_18: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1709_19: Space = singleton(&(v1709_18));
  drop(v1709_18);
  let v1709_20: Space = unite(&(v1709_16),&(v1709_19));
  drop(v1709_16);
  drop(v1709_19);
  let v1709_22: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1709_23: Space = singleton(&(v1709_22));
  drop(v1709_22);
  let v1709_24: Space = unite(&(v1709_20),&(v1709_23));
  drop(v1709_20);
  drop(v1709_23);
  let v1709_26: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1709_27: Space = singleton(&(v1709_26));
  drop(v1709_26);
  let v1709_28: Space = unite(&(v1709_24),&(v1709_27));
  drop(v1709_24);
  drop(v1709_27);
  let v1709_30: Path = concat_path(&(*CONSTANT_25),&(*p5));
  let v1709_31: Space = singleton(&(v1709_30));
  drop(v1709_30);
  let v1709_32: Space = unite(&(v1709_28),&(v1709_31));
  drop(v1709_28);
  drop(v1709_31);
  let v1709_34: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1709_35: Space = singleton(&(v1709_34));
  drop(v1709_34);
  let v1709_36: Space = unite(&(v1709_32),&(v1709_35));
  drop(v1709_32);
  drop(v1709_35);
  let v1709_38: Path = concat_path(&(*CONSTANT_28),&(*p7));
  let v1709_39: Space = singleton(&(v1709_38));
  drop(v1709_38);
  let v1709_40: Space = unite(&(v1709_36),&(v1709_39));
  drop(v1709_36);
  drop(v1709_39);
  let mut v1709_42 = Space::new();
  let mut v1709_42_cursor = (*s0).read_zipper();
  for v1709_42_byte in v1709_42_cursor.child_mask().iter() {
    v1709_42_cursor.descend_to_byte(v1709_42_byte);
    let v1709_42_tail = v1709_42_cursor.make_map();
    v1709_42_cursor.ascend(1);
    let v1709_42_head = Path::from_slice(&[v1709_42_byte]);
    let v1710_2: Space = singleton(&(v1709_42_head));
    let v1710_3: Space = intersect(&(*CONSTANT_7),&(v1710_2));
    let v1710_4: Space = if has_head(&(v1710_3)) { singleton(&[]) } else { Space::new() };
    drop(v1710_3);
    let v1710_5: Space = subtract(&(*CONSTANT_0),&(v1710_4));
    drop(v1710_4);
    let v1710_8: Space = if (v1710_5).is_empty() { Space::new() } else {
      let v1711_6: Path = concat_path(&(*p0),&(v1709_42_head));
      let v1711_7: Space = routine_192(c, &(v1711_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1709_42_tail));
      compose(&(v1710_5),&(v1711_7))
    };
    drop(v1710_5);
    let v1710_9: Space = intersect(&(*CONSTANT_7),&(v1710_2));
    drop(v1710_2);
    let v1710_10: Space = if has_head(&(v1710_9)) { singleton(&[]) } else { Space::new() };
    drop(v1710_9);
    let v1710_14: Space = if (v1710_10).is_empty() { Space::new() } else {
      let v1712_6: Path = concat_path(&(*p0),&(v1709_42_head));
      let v1712_11: Path = concat_path(&(*CONSTANT_29),&(v1712_6));
      drop(v1712_6);
      let v1712_12: Space = singleton(&(v1712_11));
      drop(v1712_11);
      let v1712_13: Space = unite(&(v1709_40),&(v1712_12));
      drop(v1712_12);
      compose(&(v1710_10),&(v1712_13))
    };
    drop(v1710_10);
    let v1710_15: Space = unite(&(v1710_8),&(v1710_14));
    drop(v1710_14);
    v1709_42.join_into((v1710_15).clone());
  }
  drop(v1709_42_cursor);
  drop(v1709_40);
  (v1709_42).clone()
}

fn routine_193(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1713_11: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1713_12: Space = singleton(&(v1713_11));
  drop(v1713_11);
  let v1713_13: Space = unite(&(*CONSTANT_37),&(v1713_12));
  drop(v1713_12);
  let v1713_15: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1713_16: Space = singleton(&(v1713_15));
  drop(v1713_15);
  let v1713_17: Space = unite(&(v1713_13),&(v1713_16));
  drop(v1713_13);
  drop(v1713_16);
  let v1713_19: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1713_20: Space = singleton(&(v1713_19));
  drop(v1713_19);
  let v1713_21: Space = unite(&(v1713_17),&(v1713_20));
  drop(v1713_17);
  drop(v1713_20);
  let v1713_23: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1713_24: Space = singleton(&(v1713_23));
  drop(v1713_23);
  let v1713_25: Space = unite(&(v1713_21),&(v1713_24));
  drop(v1713_21);
  drop(v1713_24);
  let v1713_27: Path = concat_path(&(*CONSTANT_25),&(*p5));
  let v1713_28: Space = singleton(&(v1713_27));
  drop(v1713_27);
  let v1713_29: Space = unite(&(v1713_25),&(v1713_28));
  drop(v1713_25);
  drop(v1713_28);
  let v1713_31: Path = concat_path(&(*CONSTANT_27),&(*p6));
  let v1713_32: Space = singleton(&(v1713_31));
  drop(v1713_31);
  let v1713_33: Space = unite(&(v1713_29),&(v1713_32));
  drop(v1713_29);
  drop(v1713_32);
  let v1713_35: Path = concat_path(&(*CONSTANT_28),&(*p7));
  let v1713_36: Space = singleton(&(v1713_35));
  drop(v1713_35);
  let v1713_37: Space = unite(&(v1713_33),&(v1713_36));
  drop(v1713_33);
  drop(v1713_36);
  let v1713_39: Path = concat_path(&(*CONSTANT_29),&(*p0));
  let v1713_40: Space = singleton(&(v1713_39));
  drop(v1713_39);
  let v1713_41: Space = unite(&(v1713_37),&(v1713_40));
  drop(v1713_37);
  drop(v1713_40);
  (v1713_41).clone()
}

fn routine_194(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1714_14: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1714_15: Space = singleton(&(v1714_14));
  drop(v1714_14);
  let v1714_16: Space = unite(&(*CONSTANT_38),&(v1714_15));
  drop(v1714_15);
  let v1714_18: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1714_19: Space = singleton(&(v1714_18));
  drop(v1714_18);
  let v1714_20: Space = unite(&(v1714_16),&(v1714_19));
  drop(v1714_16);
  drop(v1714_19);
  let v1714_22: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1714_23: Space = singleton(&(v1714_22));
  drop(v1714_22);
  let v1714_24: Space = unite(&(v1714_20),&(v1714_23));
  drop(v1714_20);
  drop(v1714_23);
  let v1714_26: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1714_27: Space = singleton(&(v1714_26));
  drop(v1714_26);
  let v1714_28: Space = unite(&(v1714_24),&(v1714_27));
  drop(v1714_24);
  drop(v1714_27);
  let v1714_30: Path = concat_path(&(*CONSTANT_25),&(*p5));
  let v1714_31: Space = singleton(&(v1714_30));
  drop(v1714_30);
  let v1714_32: Space = unite(&(v1714_28),&(v1714_31));
  drop(v1714_28);
  drop(v1714_31);
  let v1714_34: Path = concat_path(&(*CONSTANT_26),&(*p6));
  let v1714_35: Space = singleton(&(v1714_34));
  drop(v1714_34);
  let v1714_36: Space = unite(&(v1714_32),&(v1714_35));
  drop(v1714_32);
  drop(v1714_35);
  let v1714_38: Path = concat_path(&(*CONSTANT_28),&(*p7));
  let v1714_39: Space = singleton(&(v1714_38));
  drop(v1714_38);
  let v1714_40: Space = unite(&(v1714_36),&(v1714_39));
  drop(v1714_36);
  drop(v1714_39);
  let mut v1714_42 = Space::new();
  let mut v1714_42_cursor = (*s0).read_zipper();
  for v1714_42_byte in v1714_42_cursor.child_mask().iter() {
    v1714_42_cursor.descend_to_byte(v1714_42_byte);
    let v1714_42_tail = v1714_42_cursor.make_map();
    v1714_42_cursor.ascend(1);
    let v1714_42_head = Path::from_slice(&[v1714_42_byte]);
    let v1715_2: Space = singleton(&(v1714_42_head));
    let v1715_3: Space = intersect(&(*CONSTANT_7),&(v1715_2));
    let v1715_4: Space = if has_head(&(v1715_3)) { singleton(&[]) } else { Space::new() };
    drop(v1715_3);
    let v1715_5: Space = subtract(&(*CONSTANT_0),&(v1715_4));
    drop(v1715_4);
    let v1715_8: Space = if (v1715_5).is_empty() { Space::new() } else {
      let v1716_6: Path = concat_path(&(*p0),&(v1714_42_head));
      let v1716_7: Space = routine_194(c, &(v1716_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1714_42_tail));
      compose(&(v1715_5),&(v1716_7))
    };
    drop(v1715_5);
    let v1715_9: Space = intersect(&(*CONSTANT_7),&(v1715_2));
    drop(v1715_2);
    let v1715_10: Space = if has_head(&(v1715_9)) { singleton(&[]) } else { Space::new() };
    drop(v1715_9);
    let v1715_14: Space = if (v1715_10).is_empty() { Space::new() } else {
      let v1717_6: Path = concat_path(&(*p0),&(v1714_42_head));
      let v1717_11: Path = concat_path(&(*CONSTANT_29),&(v1717_6));
      drop(v1717_6);
      let v1717_12: Space = singleton(&(v1717_11));
      drop(v1717_11);
      let v1717_13: Space = unite(&(v1714_40),&(v1717_12));
      drop(v1717_12);
      compose(&(v1715_10),&(v1717_13))
    };
    drop(v1715_10);
    let v1715_15: Space = unite(&(v1715_8),&(v1715_14));
    drop(v1715_14);
    v1714_42.join_into((v1715_15).clone());
  }
  drop(v1714_42_cursor);
  drop(v1714_40);
  (v1714_42).clone()
}

fn routine_195(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1718_11: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1718_12: Space = singleton(&(v1718_11));
  drop(v1718_11);
  let v1718_13: Space = unite(&(*CONSTANT_38),&(v1718_12));
  drop(v1718_12);
  let v1718_15: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1718_16: Space = singleton(&(v1718_15));
  drop(v1718_15);
  let v1718_17: Space = unite(&(v1718_13),&(v1718_16));
  drop(v1718_13);
  drop(v1718_16);
  let v1718_19: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1718_20: Space = singleton(&(v1718_19));
  drop(v1718_19);
  let v1718_21: Space = unite(&(v1718_17),&(v1718_20));
  drop(v1718_17);
  drop(v1718_20);
  let v1718_23: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1718_24: Space = singleton(&(v1718_23));
  drop(v1718_23);
  let v1718_25: Space = unite(&(v1718_21),&(v1718_24));
  drop(v1718_21);
  drop(v1718_24);
  let v1718_27: Path = concat_path(&(*CONSTANT_25),&(*p5));
  let v1718_28: Space = singleton(&(v1718_27));
  drop(v1718_27);
  let v1718_29: Space = unite(&(v1718_25),&(v1718_28));
  drop(v1718_25);
  drop(v1718_28);
  let v1718_31: Path = concat_path(&(*CONSTANT_26),&(*p6));
  let v1718_32: Space = singleton(&(v1718_31));
  drop(v1718_31);
  let v1718_33: Space = unite(&(v1718_29),&(v1718_32));
  drop(v1718_29);
  drop(v1718_32);
  let v1718_35: Path = concat_path(&(*CONSTANT_28),&(*p7));
  let v1718_36: Space = singleton(&(v1718_35));
  drop(v1718_35);
  let v1718_37: Space = unite(&(v1718_33),&(v1718_36));
  drop(v1718_33);
  drop(v1718_36);
  let v1718_39: Path = concat_path(&(*CONSTANT_29),&(*p0));
  let v1718_40: Space = singleton(&(v1718_39));
  drop(v1718_39);
  let v1718_41: Space = unite(&(v1718_37),&(v1718_40));
  drop(v1718_37);
  drop(v1718_40);
  (v1718_41).clone()
}

fn routine_196(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1719_14: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1719_15: Space = singleton(&(v1719_14));
  drop(v1719_14);
  let v1719_16: Space = unite(&(*CONSTANT_39),&(v1719_15));
  drop(v1719_15);
  let v1719_18: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1719_19: Space = singleton(&(v1719_18));
  drop(v1719_18);
  let v1719_20: Space = unite(&(v1719_16),&(v1719_19));
  drop(v1719_16);
  drop(v1719_19);
  let v1719_22: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1719_23: Space = singleton(&(v1719_22));
  drop(v1719_22);
  let v1719_24: Space = unite(&(v1719_20),&(v1719_23));
  drop(v1719_20);
  drop(v1719_23);
  let v1719_26: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1719_27: Space = singleton(&(v1719_26));
  drop(v1719_26);
  let v1719_28: Space = unite(&(v1719_24),&(v1719_27));
  drop(v1719_24);
  drop(v1719_27);
  let v1719_30: Path = concat_path(&(*CONSTANT_25),&(*p5));
  let v1719_31: Space = singleton(&(v1719_30));
  drop(v1719_30);
  let v1719_32: Space = unite(&(v1719_28),&(v1719_31));
  drop(v1719_28);
  drop(v1719_31);
  let v1719_34: Path = concat_path(&(*CONSTANT_26),&(*p6));
  let v1719_35: Space = singleton(&(v1719_34));
  drop(v1719_34);
  let v1719_36: Space = unite(&(v1719_32),&(v1719_35));
  drop(v1719_32);
  drop(v1719_35);
  let v1719_38: Path = concat_path(&(*CONSTANT_27),&(*p7));
  let v1719_39: Space = singleton(&(v1719_38));
  drop(v1719_38);
  let v1719_40: Space = unite(&(v1719_36),&(v1719_39));
  drop(v1719_36);
  drop(v1719_39);
  let mut v1719_42 = Space::new();
  let mut v1719_42_cursor = (*s0).read_zipper();
  for v1719_42_byte in v1719_42_cursor.child_mask().iter() {
    v1719_42_cursor.descend_to_byte(v1719_42_byte);
    let v1719_42_tail = v1719_42_cursor.make_map();
    v1719_42_cursor.ascend(1);
    let v1719_42_head = Path::from_slice(&[v1719_42_byte]);
    let v1720_2: Space = singleton(&(v1719_42_head));
    let v1720_3: Space = intersect(&(*CONSTANT_7),&(v1720_2));
    let v1720_4: Space = if has_head(&(v1720_3)) { singleton(&[]) } else { Space::new() };
    drop(v1720_3);
    let v1720_5: Space = subtract(&(*CONSTANT_0),&(v1720_4));
    drop(v1720_4);
    let v1720_8: Space = if (v1720_5).is_empty() { Space::new() } else {
      let v1721_6: Path = concat_path(&(*p0),&(v1719_42_head));
      let v1721_7: Space = routine_196(c, &(v1721_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1719_42_tail));
      compose(&(v1720_5),&(v1721_7))
    };
    drop(v1720_5);
    let v1720_9: Space = intersect(&(*CONSTANT_7),&(v1720_2));
    drop(v1720_2);
    let v1720_10: Space = if has_head(&(v1720_9)) { singleton(&[]) } else { Space::new() };
    drop(v1720_9);
    let v1720_14: Space = if (v1720_10).is_empty() { Space::new() } else {
      let v1722_6: Path = concat_path(&(*p0),&(v1719_42_head));
      let v1722_11: Path = concat_path(&(*CONSTANT_29),&(v1722_6));
      drop(v1722_6);
      let v1722_12: Space = singleton(&(v1722_11));
      drop(v1722_11);
      let v1722_13: Space = unite(&(v1719_40),&(v1722_12));
      drop(v1722_12);
      compose(&(v1720_10),&(v1722_13))
    };
    drop(v1720_10);
    let v1720_15: Space = unite(&(v1720_8),&(v1720_14));
    drop(v1720_14);
    v1719_42.join_into((v1720_15).clone());
  }
  drop(v1719_42_cursor);
  drop(v1719_40);
  (v1719_42).clone()
}

fn routine_197(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1723_11: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1723_12: Space = singleton(&(v1723_11));
  drop(v1723_11);
  let v1723_13: Space = unite(&(*CONSTANT_39),&(v1723_12));
  drop(v1723_12);
  let v1723_15: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1723_16: Space = singleton(&(v1723_15));
  drop(v1723_15);
  let v1723_17: Space = unite(&(v1723_13),&(v1723_16));
  drop(v1723_13);
  drop(v1723_16);
  let v1723_19: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1723_20: Space = singleton(&(v1723_19));
  drop(v1723_19);
  let v1723_21: Space = unite(&(v1723_17),&(v1723_20));
  drop(v1723_17);
  drop(v1723_20);
  let v1723_23: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1723_24: Space = singleton(&(v1723_23));
  drop(v1723_23);
  let v1723_25: Space = unite(&(v1723_21),&(v1723_24));
  drop(v1723_21);
  drop(v1723_24);
  let v1723_27: Path = concat_path(&(*CONSTANT_25),&(*p5));
  let v1723_28: Space = singleton(&(v1723_27));
  drop(v1723_27);
  let v1723_29: Space = unite(&(v1723_25),&(v1723_28));
  drop(v1723_25);
  drop(v1723_28);
  let v1723_31: Path = concat_path(&(*CONSTANT_26),&(*p6));
  let v1723_32: Space = singleton(&(v1723_31));
  drop(v1723_31);
  let v1723_33: Space = unite(&(v1723_29),&(v1723_32));
  drop(v1723_29);
  drop(v1723_32);
  let v1723_35: Path = concat_path(&(*CONSTANT_27),&(*p7));
  let v1723_36: Space = singleton(&(v1723_35));
  drop(v1723_35);
  let v1723_37: Space = unite(&(v1723_33),&(v1723_36));
  drop(v1723_33);
  drop(v1723_36);
  let v1723_39: Path = concat_path(&(*CONSTANT_29),&(*p0));
  let v1723_40: Space = singleton(&(v1723_39));
  drop(v1723_39);
  let v1723_41: Space = unite(&(v1723_37),&(v1723_40));
  drop(v1723_37);
  drop(v1723_40);
  (v1723_41).clone()
}

fn routine_198(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1724_14: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1724_15: Space = singleton(&(v1724_14));
  drop(v1724_14);
  let v1724_16: Space = unite(&(*CONSTANT_40),&(v1724_15));
  drop(v1724_15);
  let v1724_18: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1724_19: Space = singleton(&(v1724_18));
  drop(v1724_18);
  let v1724_20: Space = unite(&(v1724_16),&(v1724_19));
  drop(v1724_16);
  drop(v1724_19);
  let v1724_22: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1724_23: Space = singleton(&(v1724_22));
  drop(v1724_22);
  let v1724_24: Space = unite(&(v1724_20),&(v1724_23));
  drop(v1724_20);
  drop(v1724_23);
  let v1724_26: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1724_27: Space = singleton(&(v1724_26));
  drop(v1724_26);
  let v1724_28: Space = unite(&(v1724_24),&(v1724_27));
  drop(v1724_24);
  drop(v1724_27);
  let v1724_30: Path = concat_path(&(*CONSTANT_25),&(*p5));
  let v1724_31: Space = singleton(&(v1724_30));
  drop(v1724_30);
  let v1724_32: Space = unite(&(v1724_28),&(v1724_31));
  drop(v1724_28);
  drop(v1724_31);
  let v1724_34: Path = concat_path(&(*CONSTANT_26),&(*p6));
  let v1724_35: Space = singleton(&(v1724_34));
  drop(v1724_34);
  let v1724_36: Space = unite(&(v1724_32),&(v1724_35));
  drop(v1724_32);
  drop(v1724_35);
  let v1724_38: Path = concat_path(&(*CONSTANT_27),&(*p7));
  let v1724_39: Space = singleton(&(v1724_38));
  drop(v1724_38);
  let v1724_40: Space = unite(&(v1724_36),&(v1724_39));
  drop(v1724_36);
  drop(v1724_39);
  let mut v1724_42 = Space::new();
  let mut v1724_42_cursor = (*s0).read_zipper();
  for v1724_42_byte in v1724_42_cursor.child_mask().iter() {
    v1724_42_cursor.descend_to_byte(v1724_42_byte);
    let v1724_42_tail = v1724_42_cursor.make_map();
    v1724_42_cursor.ascend(1);
    let v1724_42_head = Path::from_slice(&[v1724_42_byte]);
    let v1725_2: Space = singleton(&(v1724_42_head));
    let v1725_3: Space = intersect(&(*CONSTANT_7),&(v1725_2));
    let v1725_4: Space = if has_head(&(v1725_3)) { singleton(&[]) } else { Space::new() };
    drop(v1725_3);
    let v1725_5: Space = subtract(&(*CONSTANT_0),&(v1725_4));
    drop(v1725_4);
    let v1725_8: Space = if (v1725_5).is_empty() { Space::new() } else {
      let v1726_6: Path = concat_path(&(*p0),&(v1724_42_head));
      let v1726_7: Space = routine_198(c, &(v1726_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v1724_42_tail));
      compose(&(v1725_5),&(v1726_7))
    };
    drop(v1725_5);
    let v1725_9: Space = intersect(&(*CONSTANT_7),&(v1725_2));
    drop(v1725_2);
    let v1725_10: Space = if has_head(&(v1725_9)) { singleton(&[]) } else { Space::new() };
    drop(v1725_9);
    let v1725_14: Space = if (v1725_10).is_empty() { Space::new() } else {
      let v1727_6: Path = concat_path(&(*p0),&(v1724_42_head));
      let v1727_11: Path = concat_path(&(*CONSTANT_28),&(v1727_6));
      drop(v1727_6);
      let v1727_12: Space = singleton(&(v1727_11));
      drop(v1727_11);
      let v1727_13: Space = unite(&(v1724_40),&(v1727_12));
      drop(v1727_12);
      compose(&(v1725_10),&(v1727_13))
    };
    drop(v1725_10);
    let v1725_15: Space = unite(&(v1725_8),&(v1725_14));
    drop(v1725_14);
    v1724_42.join_into((v1725_15).clone());
  }
  drop(v1724_42_cursor);
  drop(v1724_40);
  (v1724_42).clone()
}

fn routine_199(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v1728_11: Path = concat_path(&(*CONSTANT_30),&(*p1));
  let v1728_12: Space = singleton(&(v1728_11));
  drop(v1728_11);
  let v1728_13: Space = unite(&(*CONSTANT_40),&(v1728_12));
  drop(v1728_12);
  let v1728_15: Path = concat_path(&(*CONSTANT_22),&(*p2));
  let v1728_16: Space = singleton(&(v1728_15));
  drop(v1728_15);
  let v1728_17: Space = unite(&(v1728_13),&(v1728_16));
  drop(v1728_13);
  drop(v1728_16);
  let v1728_19: Path = concat_path(&(*CONSTANT_23),&(*p3));
  let v1728_20: Space = singleton(&(v1728_19));
  drop(v1728_19);
  let v1728_21: Space = unite(&(v1728_17),&(v1728_20));
  drop(v1728_17);
  drop(v1728_20);
  let v1728_23: Path = concat_path(&(*CONSTANT_24),&(*p4));
  let v1728_24: Space = singleton(&(v1728_23));
  drop(v1728_23);
  let v1728_25: Space = unite(&(v1728_21),&(v1728_24));
  drop(v1728_21);
  drop(v1728_24);
  let v1728_27: Path = concat_path(&(*CONSTANT_25),&(*p5));
  let v1728_28: Space = singleton(&(v1728_27));
  drop(v1728_27);
  let v1728_29: Space = unite(&(v1728_25),&(v1728_28));
  drop(v1728_25);
  drop(v1728_28);
  let v1728_31: Path = concat_path(&(*CONSTANT_26),&(*p6));
  let v1728_32: Space = singleton(&(v1728_31));
  drop(v1728_31);
  let v1728_33: Space = unite(&(v1728_29),&(v1728_32));
  drop(v1728_29);
  drop(v1728_32);
  let v1728_35: Path = concat_path(&(*CONSTANT_27),&(*p7));
  let v1728_36: Space = singleton(&(v1728_35));
  drop(v1728_35);
  let v1728_37: Space = unite(&(v1728_33),&(v1728_36));
  drop(v1728_33);
  drop(v1728_36);
  let v1728_39: Path = concat_path(&(*CONSTANT_28),&(*p0));
  let v1728_40: Space = singleton(&(v1728_39));
  drop(v1728_39);
  let v1728_41: Space = unite(&(v1728_37),&(v1728_40));
  drop(v1728_37);
  drop(v1728_40);
  (v1728_41).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
