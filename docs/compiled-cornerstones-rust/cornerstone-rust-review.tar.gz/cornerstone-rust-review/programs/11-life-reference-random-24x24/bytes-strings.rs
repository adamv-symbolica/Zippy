#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[48]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 49 48 0 4 0 49 49 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[49]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("53 4 0 49 51 0 4 0 49 52 0 4 0 50 48 0 5 48 0 49 50 0 5 48 0 49 56 0 5 48 0 50 51 0 4 48 0 54 0 4 48 0 57 0 5 49 0 49 49 0 5 49 0 49 50 0 5 49 0 50 51 0 4 49 0 51 0 4 49 0 53 0 5 50 0 49 54 0 5 50 0 49 57 0 4 50 0 50 0 5 51 0 49 52 0 5 51 0 50 48 0 5 51 0 50 49 0 4 51 0 57 0 4 52 0 48 0 5 52 0 49 56 0 4 52 0 54 0 4 52 0 56 0 4 52 0 57 0 4 53 0 49 0 5 53 0 49 54 0 5 53 0 49 55 0 5 53 0 49 57 0 5 53 0 50 48 0 4 53 0 51 0 4 53 0 53 0 4 53 0 54 0 4 54 0 48 0 5 55 0 49 50 0 5 55 0 49 54 0 5 55 0 49 56 0 4 55 0 50 0 4 55 0 51 0 4 55 0 52 0 4 55 0 54 0 4 55 0 55 0 4 55 0 57 0 5 56 0 49 48 0 5 56 0 49 50 0 5 56 0 49 51 0 5 56 0 49 53 0 5 56 0 49 55 0 5 56 0 50 50 0 4 56 0 53 0 5 57 0 49 56 0 5 57 0 50 49 0 4 57 0 51 0"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[50]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("21 4 0 49 48 0 4 0 49 51 0 4 0 50 49 0 5 48 0 49 53 0 4 48 0 50 0 4 48 0 53 0 4 48 0 55 0 4 48 0 57 0 5 49 0 49 51 0 5 49 0 49 53 0 4 49 0 52 0 4 49 0 56 0 4 49 0 57 0 5 50 0 49 54 0 4 50 0 50 0 5 50 0 50 50 0 4 51 0 49 0 4 51 0 50 0 4 51 0 53 0 4 51 0 55 0 4 51 0 57 0"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[51]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 3 0 49 0 3 0 50 0 4 0 50 49 0 3 0 53 0 3 0 55 0"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[52]));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 49 49 0 4 0 49 53 0 4 0 49 54 0 4 0 49 57 0 4 0 50 48 0 4 0 50 51 0 3 0 56 0"));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[53]));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 49 48 0 4 0 49 50 0 4 0 49 56 0 4 0 49 57 0 3 0 55 0"));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[54]));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 3 0 49 0 4 0 49 52 0 3 0 50 0 4 0 50 48 0 3 0 52 0 3 0 54 0"));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[55]));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 3 0 49 0 4 0 49 48 0 4 0 49 52 0 4 0 49 57 0 4 0 50 48 0 3 0 52 0 3 0 53 0"));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[56]));
static CONSTANT_18: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 0 49 49 0 4 0 49 57 0 4 0 50 49 0 3 0 53 0 3 0 54 0 3 0 57 0"));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[57]));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 4 0 49 50 0 4 0 49 55 0 4 0 49 57 0 4 0 50 51 0 3 0 51 0 3 0 52 0 3 0 53 0 3 0 55 0"));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("120 10 67 101 108 108 0 48 0 49 48 0 10 67 101 108 108 0 48 0 49 49 0 10 67 101 108 108 0 49 0 49 51 0 10 67 101 108 108 0 49 0 49 52 0 10 67 101 108 108 0 49 0 50 48 0 11 67 101 108 108 0 49 48 0 49 50 0 11 67 101 108 108 0 49 48 0 49 56 0 11 67 101 108 108 0 49 48 0 50 51 0 10 67 101 108 108 0 49 48 0 54 0 10 67 101 108 108 0 49 48 0 57 0 11 67 101 108 108 0 49 49 0 49 49 0 11 67 101 108 108 0 49 49 0 49 50 0 11 67 101 108 108 0 49 49 0 50 51 0 10 67 101 108 108 0 49 49 0 51 0 10 67 101 108 108 0 49 49 0 53 0 11 67 101 108 108 0 49 50 0 49 54 0 11 67 101 108 108 0 49 50 0 49 57 0 10 67 101 108 108 0 49 50 0 50 0 11 67 101 108 108 0 49 51 0 49 52 0 11 67 101 108 108 0 49 51 0 50 48 0 11 67 101 108 108 0 49 51 0 50 49 0 10 67 101 108 108 0 49 51 0 57 0 10 67 101 108 108 0 49 52 0 48 0 11 67 101 108 108 0 49 52 0 49 56 0 10 67 101 108 108 0 49 52 0 54 0 10 67 101 108 108 0 49 52 0 56 0 10 67 101 108 108 0 49 52 0 57 0 10 67 101 108 108 0 49 53 0 49 0 11 67 101 108 108 0 49 53 0 49 54 0 11 67 101 108 108 0 49 53 0 49 55 0 11 67 101 108 108 0 49 53 0 49 57 0 11 67 101 108 108 0 49 53 0 50 48 0 10 67 101 108 108 0 49 53 0 51 0 10 67 101 108 108 0 49 53 0 53 0 10 67 101 108 108 0 49 53 0 54 0 10 67 101 108 108 0 49 54 0 48 0 11 67 101 108 108 0 49 55 0 49 50 0 11 67 101 108 108 0 49 55 0 49 54 0 11 67 101 108 108 0 49 55 0 49 56 0 10 67 101 108 108 0 49 55 0 50 0 10 67 101 108 108 0 49 55 0 51 0 10 67 101 108 108 0 49 55 0 52 0 10 67 101 108 108 0 49 55 0 54 0 10 67 101 108 108 0 49 55 0 55 0 10 67 101 108 108 0 49 55 0 57 0 11 67 101 108 108 0 49 56 0 49 48 0 11 67 101 108 108 0 49 56 0 49 50 0 11 67 101 108 108 0 49 56 0 49 51 0 11 67 101 108 108 0 49 56 0 49 53 0 11 67 101 108 108 0 49 56 0 49 55 0 11 67 101 108 108 0 49 56 0 50 50 0 10 67 101 108 108 0 49 56 0 53 0 11 67 101 108 108 0 49 57 0 49 56 0 11 67 101 108 108 0 49 57 0 50 49 0 10 67 101 108 108 0 49 57 0 51 0 10 67 101 108 108 0 50 0 49 48 0 10 67 101 108 108 0 50 0 49 51 0 10 67 101 108 108 0 50 0 50 49 0 11 67 101 108 108 0 50 48 0 49 53 0 10 67 101 108 108 0 50 48 0 50 0 10 67 101 108 108 0 50 48 0 53 0 10 67 101 108 108 0 50 48 0 55 0 10 67 101 108 108 0 50 48 0 57 0 11 67 101 108 108 0 50 49 0 49 51 0 11 67 101 108 108 0 50 49 0 49 53 0 10 67 101 108 108 0 50 49 0 52 0 10 67 101 108 108 0 50 49 0 56 0 10 67 101 108 108 0 50 49 0 57 0 11 67 101 108 108 0 50 50 0 49 54 0 10 67 101 108 108 0 50 50 0 50 0 11 67 101 108 108 0 50 50 0 50 50 0 10 67 101 108 108 0 50 51 0 49 0 10 67 101 108 108 0 50 51 0 50 0 10 67 101 108 108 0 50 51 0 53 0 10 67 101 108 108 0 50 51 0 55 0 10 67 101 108 108 0 50 51 0 57 0 9 67 101 108 108 0 51 0 49 0 9 67 101 108 108 0 51 0 50 0 10 67 101 108 108 0 51 0 50 49 0 9 67 101 108 108 0 51 0 53 0 9 67 101 108 108 0 51 0 55 0 10 67 101 108 108 0 52 0 49 49 0 10 67 101 108 108 0 52 0 49 53 0 10 67 101 108 108 0 52 0 49 54 0 10 67 101 108 108 0 52 0 49 57 0 10 67 101 108 108 0 52 0 50 48 0 10 67 101 108 108 0 52 0 50 51 0 9 67 101 108 108 0 52 0 56 0 10 67 101 108 108 0 53 0 49 48 0 10 67 101 108 108 0 53 0 49 50 0 10 67 101 108 108 0 53 0 49 56 0 10 67 101 108 108 0 53 0 49 57 0 9 67 101 108 108 0 53 0 55 0 9 67 101 108 108 0 54 0 49 0 10 67 101 108 108 0 54 0 49 52 0 9 67 101 108 108 0 54 0 50 0 10 67 101 108 108 0 54 0 50 48 0 9 67 101 108 108 0 54 0 52 0 9 67 101 108 108 0 54 0 54 0 9 67 101 108 108 0 55 0 49 0 10 67 101 108 108 0 55 0 49 48 0 10 67 101 108 108 0 55 0 49 52 0 10 67 101 108 108 0 55 0 49 57 0 10 67 101 108 108 0 55 0 50 48 0 9 67 101 108 108 0 55 0 52 0 9 67 101 108 108 0 55 0 53 0 10 67 101 108 108 0 56 0 49 49 0 10 67 101 108 108 0 56 0 49 57 0 10 67 101 108 108 0 56 0 50 49 0 9 67 101 108 108 0 56 0 53 0 9 67 101 108 108 0 56 0 54 0 9 67 101 108 108 0 56 0 57 0 10 67 101 108 108 0 57 0 49 50 0 10 67 101 108 108 0 57 0 49 55 0 10 67 101 108 108 0 57 0 49 57 0 10 67 101 108 108 0 57 0 50 51 0 9 67 101 108 108 0 57 0 51 0 9 67 101 108 108 0 57 0 52 0 9 67 101 108 108 0 57 0 53 0 9 67 101 108 108 0 57 0 55 0"));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[67,101,108,108,0]));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 104 105 116 0"));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("387 6 45 49 0 45 49 0 6 45 49 0 45 50 0 5 45 49 0 48 0 8 45 49 48 0 45 49 48 0 8 45 49 48 0 45 49 49 0 7 45 49 48 0 45 57 0 8 45 49 49 0 45 49 48 0 8 45 49 49 0 45 49 49 0 8 45 49 49 0 45 49 50 0 8 45 49 50 0 45 49 49 0 8 45 49 50 0 45 49 50 0 8 45 49 50 0 45 49 51 0 8 45 49 51 0 45 49 50 0 8 45 49 51 0 45 49 51 0 8 45 49 51 0 45 49 52 0 8 45 49 52 0 45 49 51 0 8 45 49 52 0 45 49 52 0 8 45 49 52 0 45 49 53 0 8 45 49 53 0 45 49 52 0 8 45 49 53 0 45 49 53 0 8 45 49 53 0 45 49 54 0 8 45 49 54 0 45 49 53 0 8 45 49 54 0 45 49 54 0 8 45 49 54 0 45 49 55 0 8 45 49 55 0 45 49 54 0 8 45 49 55 0 45 49 55 0 8 45 49 55 0 45 49 56 0 8 45 49 56 0 45 49 55 0 8 45 49 56 0 45 49 56 0 8 45 49 56 0 45 49 57 0 8 45 49 57 0 45 49 56 0 8 45 49 57 0 45 49 57 0 8 45 49 57 0 45 50 48 0 6 45 50 0 45 49 0 6 45 50 0 45 50 0 6 45 50 0 45 51 0 8 45 50 48 0 45 49 57 0 8 45 50 48 0 45 50 48 0 8 45 50 48 0 45 50 49 0 8 45 50 49 0 45 50 48 0 8 45 50 49 0 45 50 49 0 8 45 50 49 0 45 50 50 0 8 45 50 50 0 45 50 49 0 8 45 50 50 0 45 50 50 0 8 45 50 50 0 45 50 51 0 8 45 50 51 0 45 50 50 0 8 45 50 51 0 45 50 51 0 8 45 50 51 0 45 50 52 0 8 45 50 52 0 45 50 51 0 8 45 50 52 0 45 50 52 0 8 45 50 52 0 45 50 53 0 8 45 50 53 0 45 50 52 0 8 45 50 53 0 45 50 53 0 8 45 50 53 0 45 50 54 0 8 45 50 54 0 45 50 53 0 8 45 50 54 0 45 50 54 0 8 45 50 54 0 45 50 55 0 8 45 50 55 0 45 50 54 0 8 45 50 55 0 45 50 55 0 8 45 50 55 0 45 50 56 0 8 45 50 56 0 45 50 55 0 8 45 50 56 0 45 50 56 0 8 45 50 56 0 45 50 57 0 8 45 50 57 0 45 50 56 0 8 45 50 57 0 45 50 57 0 8 45 50 57 0 45 51 48 0 6 45 51 0 45 50 0 6 45 51 0 45 51 0 6 45 51 0 45 52 0 8 45 51 48 0 45 50 57 0 8 45 51 48 0 45 51 48 0 8 45 51 48 0 45 51 49 0 8 45 51 49 0 45 51 48 0 8 45 51 49 0 45 51 49 0 8 45 51 49 0 45 51 50 0 8 45 51 50 0 45 51 49 0 8 45 51 50 0 45 51 50 0 8 45 51 50 0 45 51 51 0 8 45 51 51 0 45 51 50 0 8 45 51 51 0 45 51 51 0 8 45 51 51 0 45 51 52 0 8 45 51 52 0 45 51 51 0 8 45 51 52 0 45 51 52 0 8 45 51 52 0 45 51 53 0 8 45 51 53 0 45 51 52 0 8 45 51 53 0 45 51 53 0 8 45 51 53 0 45 51 54 0 8 45 51 54 0 45 51 53 0 8 45 51 54 0 45 51 54 0 8 45 51 54 0 45 51 55 0 8 45 51 55 0 45 51 54 0 8 45 51 55 0 45 51 55 0 8 45 51 55 0 45 51 56 0 8 45 51 56 0 45 51 55 0 8 45 51 56 0 45 51 56 0 8 45 51 56 0 45 51 57 0 8 45 51 57 0 45 51 56 0 8 45 51 57 0 45 51 57 0 8 45 51 57 0 45 52 48 0 6 45 52 0 45 51 0 6 45 52 0 45 52 0 6 45 52 0 45 53 0 8 45 52 48 0 45 51 57 0 8 45 52 48 0 45 52 48 0 8 45 52 48 0 45 52 49 0 8 45 52 49 0 45 52 48 0 8 45 52 49 0 45 52 49 0 8 45 52 49 0 45 52 50 0 8 45 52 50 0 45 52 49 0 8 45 52 50 0 45 52 50 0 8 45 52 50 0 45 52 51 0 8 45 52 51 0 45 52 50 0 8 45 52 51 0 45 52 51 0 8 45 52 51 0 45 52 52 0 8 45 52 52 0 45 52 51 0 8 45 52 52 0 45 52 52 0 8 45 52 52 0 45 52 53 0 8 45 52 53 0 45 52 52 0 8 45 52 53 0 45 52 53 0 8 45 52 53 0 45 52 54 0 8 45 52 54 0 45 52 53 0 8 45 52 54 0 45 52 54 0 8 45 52 54 0 45 52 55 0 8 45 52 55 0 45 52 54 0 8 45 52 55 0 45 52 55 0 8 45 52 55 0 45 52 56 0 8 45 52 56 0 45 52 55 0 8 45 52 56 0 45 52 56 0 8 45 52 56 0 45 52 57 0 8 45 52 57 0 45 52 56 0 8 45 52 57 0 45 52 57 0 8 45 52 57 0 45 53 48 0 6 45 53 0 45 52 0 6 45 53 0 45 53 0 6 45 53 0 45 54 0 8 45 53 48 0 45 52 57 0 8 45 53 48 0 45 53 48 0 8 45 53 48 0 45 53 49 0 8 45 53 49 0 45 53 48 0 8 45 53 49 0 45 53 49 0 8 45 53 49 0 45 53 50 0 8 45 53 50 0 45 53 49 0 8 45 53 50 0 45 53 50 0 8 45 53 50 0 45 53 51 0 8 45 53 51 0 45 53 50 0 8 45 53 51 0 45 53 51 0 8 45 53 51 0 45 53 52 0 8 45 53 52 0 45 53 51 0 8 45 53 52 0 45 53 52 0 8 45 53 52 0 45 53 53 0 8 45 53 53 0 45 53 52 0 8 45 53 53 0 45 53 53 0 8 45 53 53 0 45 53 54 0 8 45 53 54 0 45 53 53 0 8 45 53 54 0 45 53 54 0 8 45 53 54 0 45 53 55 0 8 45 53 55 0 45 53 54 0 8 45 53 55 0 45 53 55 0 8 45 53 55 0 45 53 56 0 8 45 53 56 0 45 53 55 0 8 45 53 56 0 45 53 56 0 8 45 53 56 0 45 53 57 0 8 45 53 57 0 45 53 56 0 8 45 53 57 0 45 53 57 0 8 45 53 57 0 45 54 48 0 6 45 54 0 45 53 0 6 45 54 0 45 54 0 6 45 54 0 45 55 0 8 45 54 48 0 45 53 57 0 8 45 54 48 0 45 54 48 0 8 45 54 48 0 45 54 49 0 8 45 54 49 0 45 54 48 0 8 45 54 49 0 45 54 49 0 8 45 54 49 0 45 54 50 0 8 45 54 50 0 45 54 49 0 8 45 54 50 0 45 54 50 0 8 45 54 50 0 45 54 51 0 8 45 54 51 0 45 54 50 0 8 45 54 51 0 45 54 51 0 8 45 54 51 0 45 54 52 0 8 45 54 52 0 45 54 51 0 8 45 54 52 0 45 54 52 0 8 45 54 52 0 45 54 53 0 6 45 55 0 45 54 0 6 45 55 0 45 55 0 6 45 55 0 45 56 0 6 45 56 0 45 55 0 6 45 56 0 45 56 0 6 45 56 0 45 57 0 7 45 57 0 45 49 48 0 6 45 57 0 45 56 0 6 45 57 0 45 57 0 5 48 0 45 49 0 4 48 0 48 0 4 48 0 49 0 4 49 0 48 0 4 49 0 49 0 4 49 0 50 0 6 49 48 0 49 48 0 6 49 48 0 49 49 0 5 49 48 0 57 0 6 49 49 0 49 48 0 6 49 49 0 49 49 0 6 49 49 0 49 50 0 6 49 50 0 49 49 0 6 49 50 0 49 50 0 6 49 50 0 49 51 0 6 49 51 0 49 50 0 6 49 51 0 49 51 0 6 49 51 0 49 52 0 6 49 52 0 49 51 0 6 49 52 0 49 52 0 6 49 52 0 49 53 0 6 49 53 0 49 52 0 6 49 53 0 49 53 0 6 49 53 0 49 54 0 6 49 54 0 49 53 0 6 49 54 0 49 54 0 6 49 54 0 49 55 0 6 49 55 0 49 54 0 6 49 55 0 49 55 0 6 49 55 0 49 56 0 6 49 56 0 49 55 0 6 49 56 0 49 56 0 6 49 56 0 49 57 0 6 49 57 0 49 56 0 6 49 57 0 49 57 0 6 49 57 0 50 48 0 4 50 0 49 0 4 50 0 50 0 4 50 0 51 0 6 50 48 0 49 57 0 6 50 48 0 50 48 0 6 50 48 0 50 49 0 6 50 49 0 50 48 0 6 50 49 0 50 49 0 6 50 49 0 50 50 0 6 50 50 0 50 49 0 6 50 50 0 50 50 0 6 50 50 0 50 51 0 6 50 51 0 50 50 0 6 50 51 0 50 51 0 6 50 51 0 50 52 0 6 50 52 0 50 51 0 6 50 52 0 50 52 0 6 50 52 0 50 53 0 6 50 53 0 50 52 0 6 50 53 0 50 53 0 6 50 53 0 50 54 0 6 50 54 0 50 53 0 6 50 54 0 50 54 0 6 50 54 0 50 55 0 6 50 55 0 50 54 0 6 50 55 0 50 55 0 6 50 55 0 50 56 0 6 50 56 0 50 55 0 6 50 56 0 50 56 0 6 50 56 0 50 57 0 6 50 57 0 50 56 0 6 50 57 0 50 57 0 6 50 57 0 51 48 0 4 51 0 50 0 4 51 0 51 0 4 51 0 52 0 6 51 48 0 50 57 0 6 51 48 0 51 48 0 6 51 48 0 51 49 0 6 51 49 0 51 48 0 6 51 49 0 51 49 0 6 51 49 0 51 50 0 6 51 50 0 51 49 0 6 51 50 0 51 50 0 6 51 50 0 51 51 0 6 51 51 0 51 50 0 6 51 51 0 51 51 0 6 51 51 0 51 52 0 6 51 52 0 51 51 0 6 51 52 0 51 52 0 6 51 52 0 51 53 0 6 51 53 0 51 52 0 6 51 53 0 51 53 0 6 51 53 0 51 54 0 6 51 54 0 51 53 0 6 51 54 0 51 54 0 6 51 54 0 51 55 0 6 51 55 0 51 54 0 6 51 55 0 51 55 0 6 51 55 0 51 56 0 6 51 56 0 51 55 0 6 51 56 0 51 56 0 6 51 56 0 51 57 0 6 51 57 0 51 56 0 6 51 57 0 51 57 0 6 51 57 0 52 48 0 4 52 0 51 0 4 52 0 52 0 4 52 0 53 0 6 52 48 0 51 57 0 6 52 48 0 52 48 0 6 52 48 0 52 49 0 6 52 49 0 52 48 0 6 52 49 0 52 49 0 6 52 49 0 52 50 0 6 52 50 0 52 49 0 6 52 50 0 52 50 0 6 52 50 0 52 51 0 6 52 51 0 52 50 0 6 52 51 0 52 51 0 6 52 51 0 52 52 0 6 52 52 0 52 51 0 6 52 52 0 52 52 0 6 52 52 0 52 53 0 6 52 53 0 52 52 0 6 52 53 0 52 53 0 6 52 53 0 52 54 0 6 52 54 0 52 53 0 6 52 54 0 52 54 0 6 52 54 0 52 55 0 6 52 55 0 52 54 0 6 52 55 0 52 55 0 6 52 55 0 52 56 0 6 52 56 0 52 55 0 6 52 56 0 52 56 0 6 52 56 0 52 57 0 6 52 57 0 52 56 0 6 52 57 0 52 57 0 6 52 57 0 53 48 0 4 53 0 52 0 4 53 0 53 0 4 53 0 54 0 6 53 48 0 52 57 0 6 53 48 0 53 48 0 6 53 48 0 53 49 0 6 53 49 0 53 48 0 6 53 49 0 53 49 0 6 53 49 0 53 50 0 6 53 50 0 53 49 0 6 53 50 0 53 50 0 6 53 50 0 53 51 0 6 53 51 0 53 50 0 6 53 51 0 53 51 0 6 53 51 0 53 52 0 6 53 52 0 53 51 0 6 53 52 0 53 52 0 6 53 52 0 53 53 0 6 53 53 0 53 52 0 6 53 53 0 53 53 0 6 53 53 0 53 54 0 6 53 54 0 53 53 0 6 53 54 0 53 54 0 6 53 54 0 53 55 0 6 53 55 0 53 54 0 6 53 55 0 53 55 0 6 53 55 0 53 56 0 6 53 56 0 53 55 0 6 53 56 0 53 56 0 6 53 56 0 53 57 0 6 53 57 0 53 56 0 6 53 57 0 53 57 0 6 53 57 0 54 48 0 4 54 0 53 0 4 54 0 54 0 4 54 0 55 0 6 54 48 0 53 57 0 6 54 48 0 54 48 0 6 54 48 0 54 49 0 6 54 49 0 54 48 0 6 54 49 0 54 49 0 6 54 49 0 54 50 0 6 54 50 0 54 49 0 6 54 50 0 54 50 0 6 54 50 0 54 51 0 6 54 51 0 54 50 0 6 54 51 0 54 51 0 6 54 51 0 54 52 0 6 54 52 0 54 51 0 6 54 52 0 54 52 0 6 54 52 0 54 53 0 4 55 0 54 0 4 55 0 55 0 4 55 0 56 0 4 56 0 55 0 4 56 0 56 0 4 56 0 57 0 5 57 0 49 48 0 4 57 0 56 0 4 57 0 57 0"));
fn routine_0(c: &mut Context) -> Space {
  let v0_40: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v1_3: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
    let v1_6: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4));
    let v1_7: Space = unite(&(v1_3),&(v1_6));
    let v1_10: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_6));
    let v1_11: Space = unite(&(v1_7),&(v1_10));
    let v1_14: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_8));
    let v1_15: Space = unite(&(v1_11),&(v1_14));
    let v1_18: Space = routine_1(c, &(*CONSTANT_9), &(*CONSTANT_10));
    let v1_19: Space = unite(&(v1_15),&(v1_18));
    let v1_22: Space = routine_1(c, &(*CONSTANT_11), &(*CONSTANT_12));
    let v1_23: Space = unite(&(v1_19),&(v1_22));
    let v1_26: Space = routine_1(c, &(*CONSTANT_13), &(*CONSTANT_14));
    let v1_27: Space = unite(&(v1_23),&(v1_26));
    let v1_30: Space = routine_1(c, &(*CONSTANT_15), &(*CONSTANT_16));
    let v1_31: Space = unite(&(v1_27),&(v1_30));
    let v1_34: Space = routine_1(c, &(*CONSTANT_17), &(*CONSTANT_18));
    let v1_35: Space = unite(&(v1_31),&(v1_34));
    let v1_38: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_20));
    let v1_39: Space = unite(&(v1_35),&(v1_38));
    compose(&(*CONSTANT_0),&(v1_39))
  };
  let mut v0_46 = Space::new();
  let mut v0_46_cursor = (v0_40).read_zipper();
  for v0_46_byte in v0_46_cursor.child_mask().iter() {
    v0_46_cursor.descend_to_byte(v0_46_byte);
    let v0_46_tail = v0_46_cursor.make_map();
    v0_46_cursor.ascend(1);
    let v0_46_head = Path::from_slice(&[v0_46_byte]);
    let v2_2: Space = singleton(&(v0_46_head));
    let v2_3: Space = intersect(&(*CONSTANT_21),&(v2_2));
    let v2_4: Space = if has_head(&(v2_3)) { singleton(&[]) } else { Space::new() };
    drop(v2_3);
    let v2_5: Space = subtract(&(*CONSTANT_0),&(v2_4));
    drop(v2_4);
    let v2_7: Space = if (v2_5).is_empty() { Space::new() } else {
      let v3_6: Space = routine_2(c, &(v0_46_head), &(v0_46_tail), &(*CONSTANT_22));
      compose(&(v2_5),&(v3_6))
    };
    drop(v2_5);
    let v2_8: Space = intersect(&(*CONSTANT_21),&(v2_2));
    drop(v2_2);
    let v2_9: Space = if has_head(&(v2_8)) { singleton(&[]) } else { Space::new() };
    drop(v2_8);
    let v2_11: Space = if (v2_9).is_empty() { Space::new() } else {
      let v4_10: Space = routine_3(c, &(v0_46_head), &(v0_46_tail), &(*CONSTANT_22));
      compose(&(v2_9),&(v4_10))
    };
    drop(v2_9);
    let v2_12: Space = unite(&(v2_7),&(v2_11));
    v0_46.join_into((v2_12).clone());
  }
  drop(v0_46_cursor);
  let v0_87: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v5_50: Space = routine_4(c, &(*CONSTANT_1), &(*CONSTANT_2), &(*CONSTANT_22));
    let v5_53: Space = routine_4(c, &(*CONSTANT_3), &(*CONSTANT_4), &(*CONSTANT_22));
    let v5_54: Space = unite(&(v5_50),&(v5_53));
    let v5_57: Space = routine_4(c, &(*CONSTANT_5), &(*CONSTANT_6), &(*CONSTANT_22));
    let v5_58: Space = unite(&(v5_54),&(v5_57));
    let v5_61: Space = routine_4(c, &(*CONSTANT_7), &(*CONSTANT_8), &(*CONSTANT_22));
    let v5_62: Space = unite(&(v5_58),&(v5_61));
    let v5_65: Space = routine_4(c, &(*CONSTANT_9), &(*CONSTANT_10), &(*CONSTANT_22));
    let v5_66: Space = unite(&(v5_62),&(v5_65));
    let v5_69: Space = routine_4(c, &(*CONSTANT_11), &(*CONSTANT_12), &(*CONSTANT_22));
    let v5_70: Space = unite(&(v5_66),&(v5_69));
    let v5_73: Space = routine_4(c, &(*CONSTANT_13), &(*CONSTANT_14), &(*CONSTANT_22));
    let v5_74: Space = unite(&(v5_70),&(v5_73));
    let v5_77: Space = routine_4(c, &(*CONSTANT_15), &(*CONSTANT_16), &(*CONSTANT_22));
    let v5_78: Space = unite(&(v5_74),&(v5_77));
    let v5_81: Space = routine_4(c, &(*CONSTANT_17), &(*CONSTANT_18), &(*CONSTANT_22));
    let v5_82: Space = unite(&(v5_78),&(v5_81));
    let v5_85: Space = routine_4(c, &(*CONSTANT_19), &(*CONSTANT_20), &(*CONSTANT_22));
    let v5_86: Space = unite(&(v5_82),&(v5_85));
    compose(&(*CONSTANT_0),&(v5_86))
  };
  let v0_88: Space = unite(&(v0_46),&(v0_87));
  let v0_90: Space = wrap(&(v0_88),&(*CONSTANT_23));
  (v0_90).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v6_8 = Space::new();
  let mut v6_8_cursor = (*s0).read_zipper();
  for v6_8_byte in v6_8_cursor.child_mask().iter() {
    v6_8_cursor.descend_to_byte(v6_8_byte);
    let v6_8_tail = v6_8_cursor.make_map();
    v6_8_cursor.ascend(1);
    let v6_8_head = Path::from_slice(&[v6_8_byte]);
    let v7_2: Space = singleton(&(v6_8_head));
    let v7_3: Space = intersect(&(*CONSTANT_21),&(v7_2));
    let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
    drop(v7_3);
    let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
    drop(v7_4);
    let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
      let v8_6: Path = concat_path(&(*p0),&(v6_8_head));
      let v8_7: Space = routine_1(c, &(v8_6), &(v6_8_tail));
      compose(&(v7_5),&(v8_7))
    };
    drop(v7_5);
    let v7_9: Space = intersect(&(*CONSTANT_21),&(v7_2));
    drop(v7_2);
    let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
    drop(v7_9);
    let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
      let v9_6: Path = concat_path(&(*p0),&(v6_8_head));
      let mut v9_11 = Space::new();
      let mut v9_11_cursor = (v6_8_tail).read_zipper();
      for v9_11_byte in v9_11_cursor.child_mask().iter() {
        v9_11_cursor.descend_to_byte(v9_11_byte);
        let v9_11_tail = v9_11_cursor.make_map();
        v9_11_cursor.ascend(1);
        let v9_11_head = Path::from_slice(&[v9_11_byte]);
        let v10_2: Space = singleton(&(v9_11_head));
        let v10_3: Space = intersect(&(*CONSTANT_21),&(v10_2));
        let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
        drop(v10_3);
        let v10_5: Space = subtract(&(*CONSTANT_0),&(v10_4));
        drop(v10_4);
        let v10_7: Space = if (v10_5).is_empty() { Space::new() } else {
          let v11_6: Space = routine_5(c, &(v9_11_head), &(v9_6), &(v9_11_tail));
          compose(&(v10_5),&(v11_6))
        };
        drop(v10_5);
        let v10_8: Space = intersect(&(*CONSTANT_21),&(v10_2));
        drop(v10_2);
        let v10_9: Space = if has_head(&(v10_8)) { singleton(&[]) } else { Space::new() };
        drop(v10_8);
        let v10_11: Space = if (v10_9).is_empty() { Space::new() } else {
          let v12_10: Space = routine_6(c, &(v9_11_head), &(v9_6), &(v9_11_tail));
          compose(&(v10_9),&(v12_10))
        };
        drop(v10_9);
        let v10_12: Space = unite(&(v10_7),&(v10_11));
        v9_11.join_into((v10_12).clone());
      }
      drop(v9_11_cursor);
      drop(v9_6);
      compose(&(v7_10),&(v9_11))
    };
    drop(v7_10);
    let v7_13: Space = unite(&(v7_8),&(v7_12));
    v6_8.join_into((v7_13).clone());
  }
  drop(v6_8_cursor);
  (v6_8).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v13_9 = Space::new();
  let mut v13_9_cursor = (*s0).read_zipper();
  for v13_9_byte in v13_9_cursor.child_mask().iter() {
    v13_9_cursor.descend_to_byte(v13_9_byte);
    let v13_9_tail = v13_9_cursor.make_map();
    v13_9_cursor.ascend(1);
    let v13_9_head = Path::from_slice(&[v13_9_byte]);
    let v14_2: Space = singleton(&(v13_9_head));
    let v14_3: Space = intersect(&(*CONSTANT_21),&(v14_2));
    let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
    drop(v14_3);
    let v14_5: Space = subtract(&(*CONSTANT_0),&(v14_4));
    drop(v14_4);
    let v14_8: Space = if (v14_5).is_empty() { Space::new() } else {
      let v15_6: Path = concat_path(&(*p0),&(v13_9_head));
      let v15_7: Space = routine_2(c, &(v15_6), &(v13_9_tail), &(*s1));
      compose(&(v14_5),&(v15_7))
    };
    drop(v14_5);
    let v14_9: Space = intersect(&(*CONSTANT_21),&(v14_2));
    drop(v14_2);
    let v14_10: Space = if has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
    drop(v14_9);
    let v14_12: Space = if (v14_10).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v13_9_head));
      let mut v16_11 = Space::new();
      let mut v16_11_cursor = (v13_9_tail).read_zipper();
      for v16_11_byte in v16_11_cursor.child_mask().iter() {
        v16_11_cursor.descend_to_byte(v16_11_byte);
        let v16_11_tail = v16_11_cursor.make_map();
        v16_11_cursor.ascend(1);
        let v16_11_head = Path::from_slice(&[v16_11_byte]);
        let v17_2: Space = singleton(&(v16_11_head));
        let v17_3: Space = intersect(&(*CONSTANT_21),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
        drop(v17_4);
        let v17_7: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Space = routine_7(c, &(v16_11_head), &(v16_6), &(v16_11_tail), &(*s1));
          compose(&(v17_5),&(v18_6))
        };
        drop(v17_5);
        let v17_8: Space = intersect(&(*CONSTANT_21),&(v17_2));
        drop(v17_2);
        let v17_9: Space = if has_head(&(v17_8)) { singleton(&[]) } else { Space::new() };
        drop(v17_8);
        let v17_11: Space = if (v17_9).is_empty() { Space::new() } else {
          let v19_10: Space = routine_8(c, &(v16_11_head), &(v16_6), &(v16_11_tail), &(*s1));
          compose(&(v17_9),&(v19_10))
        };
        drop(v17_9);
        let v17_12: Space = unite(&(v17_7),&(v17_11));
        v16_11.join_into((v17_12).clone());
      }
      drop(v16_11_cursor);
      drop(v16_6);
      compose(&(v14_10),&(v16_11))
    };
    drop(v14_10);
    let v14_13: Space = unite(&(v14_8),&(v14_12));
    v13_9.join_into((v14_13).clone());
  }
  drop(v13_9_cursor);
  (v13_9).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v20_7: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let mut v20_20 = Space::new();
  let mut v20_20_cursor = (*s0).read_zipper();
  for v20_20_byte in v20_20_cursor.child_mask().iter() {
    v20_20_cursor.descend_to_byte(v20_20_byte);
    let v20_20_tail = v20_20_cursor.make_map();
    v20_20_cursor.ascend(1);
    let v20_20_head = Path::from_slice(&[v20_20_byte]);
    let v21_2: Space = singleton(&(v20_20_head));
    let v21_3: Space = intersect(&(*CONSTANT_21),&(v21_2));
    let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
    drop(v21_3);
    let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
    drop(v21_4);
    let v21_7: Space = if (v21_5).is_empty() { Space::new() } else {
      let mut v22_6 = Space::new();
      let mut v22_6_cursor = (v20_20_tail).read_zipper();
      for v22_6_byte in v22_6_cursor.child_mask().iter() {
        v22_6_cursor.descend_to_byte(v22_6_byte);
        let v22_6_tail = v22_6_cursor.make_map();
        v22_6_cursor.ascend(1);
        let v22_6_head = Path::from_slice(&[v22_6_byte]);
        let v23_2: Space = singleton(&(v22_6_head));
        let v23_3: Space = intersect(&(*CONSTANT_21),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v20_20_head),&(v22_6_head));
          let v24_7: Space = routine_7(c, &(v24_6), &(*p0), &(v22_6_tail), &(*s1));
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_21),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_12: Space = if (v23_10).is_empty() { Space::new() } else {
          let v25_6: Path = concat_path(&(v20_20_head),&(v22_6_head));
          let v25_11: Space = routine_8(c, &(v25_6), &(*p0), &(v22_6_tail), &(*s1));
          drop(v25_6);
          compose(&(v23_10),&(v25_11))
        };
        drop(v23_10);
        let v23_13: Space = unite(&(v23_8),&(v23_12));
        v22_6.join_into((v23_13).clone());
      }
      drop(v22_6_cursor);
      compose(&(v21_5),&(v22_6))
    };
    drop(v21_5);
    let v21_8: Space = intersect(&(*CONSTANT_21),&(v21_2));
    drop(v21_2);
    let v21_9: Space = if has_head(&(v21_8)) { singleton(&[]) } else { Space::new() };
    drop(v21_8);
    let v21_21: Space = if (v21_9).is_empty() { Space::new() } else {
      let v26_10: Path = concat_path(&(*p0),&(v20_20_head));
      let v26_11: Space = routine_9(c, &(v26_10));
      let v26_12: Space = intersect(&(v20_7),&(v26_11));
      let v26_13: Space = range(&(v26_12),3,4);
      let mut v26_14 = Space::new();
      let mut v26_14_cursor = (v26_13).read_zipper();
      for v26_14_byte in v26_14_cursor.child_mask().iter() {
        v26_14_cursor.descend_to_byte(v26_14_byte);
        let v26_14_tail = v26_14_cursor.make_map();
        v26_14_cursor.ascend(1);
        let v26_14_head = Path::from_slice(&[v26_14_byte]);
        let v27_2: Space = singleton(&(v26_14_head));
        let v27_3: Space = intersect(&(*CONSTANT_21),&(v27_2));
        let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
        drop(v27_3);
        let v27_5: Space = subtract(&(*CONSTANT_0),&(v27_4));
        drop(v27_4);
        let v27_7: Space = if (v27_5).is_empty() { Space::new() } else {
          let v28_6: Space = routine_10(c, &(v26_14_head), &(v26_14_tail));
          compose(&(v27_5),&(v28_6))
        };
        drop(v27_5);
        let v27_8: Space = intersect(&(*CONSTANT_21),&(v27_2));
        drop(v27_2);
        let v27_9: Space = if has_head(&(v27_8)) { singleton(&[]) } else { Space::new() };
        drop(v27_8);
        let v27_11: Space = if (v27_9).is_empty() { Space::new() } else {
          let v29_10: Space = routine_11(c, &(v26_14_head), &(v26_14_tail));
          compose(&(v27_9),&(v29_10))
        };
        drop(v27_9);
        let v27_12: Space = unite(&(v27_7),&(v27_11));
        v26_14.join_into((v27_12).clone());
      }
      drop(v26_14_cursor);
      let v26_15: Space = range(&(v26_12),4,5);
      let mut v26_16 = Space::new();
      let mut v26_16_cursor = (v26_15).read_zipper();
      for v26_16_byte in v26_16_cursor.child_mask().iter() {
        v26_16_cursor.descend_to_byte(v26_16_byte);
        let v26_16_tail = v26_16_cursor.make_map();
        v26_16_cursor.ascend(1);
        let v26_16_head = Path::from_slice(&[v26_16_byte]);
        let v30_2: Space = singleton(&(v26_16_head));
        let v30_3: Space = intersect(&(*CONSTANT_21),&(v30_2));
        let v30_4: Space = if has_head(&(v30_3)) { singleton(&[]) } else { Space::new() };
        drop(v30_3);
        let v30_5: Space = subtract(&(*CONSTANT_0),&(v30_4));
        drop(v30_4);
        let v30_7: Space = if (v30_5).is_empty() { Space::new() } else {
          let v31_6: Space = routine_12(c, &(v26_16_head), &(v26_16_tail));
          compose(&(v30_5),&(v31_6))
        };
        drop(v30_5);
        let v30_8: Space = intersect(&(*CONSTANT_21),&(v30_2));
        drop(v30_2);
        let v30_9: Space = if has_head(&(v30_8)) { singleton(&[]) } else { Space::new() };
        drop(v30_8);
        let v30_11: Space = if (v30_9).is_empty() { Space::new() } else {
          let v32_10: Space = routine_13(c, &(v26_16_head), &(v26_16_tail));
          compose(&(v30_9),&(v32_10))
        };
        drop(v30_9);
        let v30_12: Space = unite(&(v30_7),&(v30_11));
        v26_16.join_into((v30_12).clone());
      }
      drop(v26_16_cursor);
      let v26_17: Space = subtract(&(v26_14),&(v26_16));
      let v26_19: Space = if (v26_17).is_empty() { Space::new() } else {
        let v33_18: Space = singleton(&(v26_10));
        compose(&(v26_17),&(v33_18))
      };
      let mut v26_20 = Space::new();
      let mut v26_20_cursor = (v26_19).read_zipper();
      for v26_20_byte in v26_20_cursor.child_mask().iter() {
        v26_20_cursor.descend_to_byte(v26_20_byte);
        let v26_20_tail = v26_20_cursor.make_map();
        v26_20_cursor.ascend(1);
        let v26_20_head = Path::from_slice(&[v26_20_byte]);
        let v34_2: Space = singleton(&(v26_20_head));
        let v34_3: Space = intersect(&(*CONSTANT_21),&(v34_2));
        let v34_4: Space = if has_head(&(v34_3)) { singleton(&[]) } else { Space::new() };
        drop(v34_3);
        let v34_5: Space = subtract(&(*CONSTANT_0),&(v34_4));
        drop(v34_4);
        let v34_7: Space = if (v34_5).is_empty() { Space::new() } else {
          let v35_6: Space = routine_14(c, &(v26_20_head), &(v26_20_tail));
          compose(&(v34_5),&(v35_6))
        };
        drop(v34_5);
        let v34_8: Space = intersect(&(*CONSTANT_21),&(v34_2));
        drop(v34_2);
        let v34_9: Space = if has_head(&(v34_8)) { singleton(&[]) } else { Space::new() };
        drop(v34_8);
        let v34_11: Space = if (v34_9).is_empty() { Space::new() } else {
          let v36_10: Space = routine_15(c, &(v26_20_head), &(v26_20_tail));
          compose(&(v34_9),&(v36_10))
        };
        drop(v34_9);
        let v34_12: Space = unite(&(v34_7),&(v34_11));
        v26_20.join_into((v34_12).clone());
      }
      drop(v26_20_cursor);
      compose(&(v21_9),&(v26_20))
    };
    drop(v21_9);
    let v21_22: Space = unite(&(v21_7),&(v21_21));
    v20_20.join_into((v21_22).clone());
  }
  drop(v20_20_cursor);
  drop(v20_7);
  (v20_20).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v37_9 = Space::new();
  let mut v37_9_cursor = (*s0).read_zipper();
  for v37_9_byte in v37_9_cursor.child_mask().iter() {
    v37_9_cursor.descend_to_byte(v37_9_byte);
    let v37_9_tail = v37_9_cursor.make_map();
    v37_9_cursor.ascend(1);
    let v37_9_head = Path::from_slice(&[v37_9_byte]);
    let v38_2: Space = singleton(&(v37_9_head));
    let v38_3: Space = intersect(&(*CONSTANT_21),&(v38_2));
    let v38_4: Space = if has_head(&(v38_3)) { singleton(&[]) } else { Space::new() };
    drop(v38_3);
    let v38_5: Space = subtract(&(*CONSTANT_0),&(v38_4));
    drop(v38_4);
    let v38_8: Space = if (v38_5).is_empty() { Space::new() } else {
      let v39_6: Path = concat_path(&(*p0),&(v37_9_head));
      let v39_7: Space = routine_4(c, &(v39_6), &(v37_9_tail), &(*s1));
      compose(&(v38_5),&(v39_7))
    };
    drop(v38_5);
    let v38_9: Space = intersect(&(*CONSTANT_21),&(v38_2));
    drop(v38_2);
    let v38_10: Space = if has_head(&(v38_9)) { singleton(&[]) } else { Space::new() };
    drop(v38_9);
    let v38_12: Space = if (v38_10).is_empty() { Space::new() } else {
      let v40_6: Path = concat_path(&(*p0),&(v37_9_head));
      let mut v40_11 = Space::new();
      let mut v40_11_cursor = (v37_9_tail).read_zipper();
      for v40_11_byte in v40_11_cursor.child_mask().iter() {
        v40_11_cursor.descend_to_byte(v40_11_byte);
        let v40_11_tail = v40_11_cursor.make_map();
        v40_11_cursor.ascend(1);
        let v40_11_head = Path::from_slice(&[v40_11_byte]);
        let v41_2: Space = singleton(&(v40_11_head));
        let v41_3: Space = intersect(&(*CONSTANT_21),&(v41_2));
        let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
        drop(v41_3);
        let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
        drop(v41_4);
        let v41_7: Space = if (v41_5).is_empty() { Space::new() } else {
          let v42_6: Space = routine_16(c, &(v40_11_head), &(v40_6), &(v40_11_tail), &(*s1));
          compose(&(v41_5),&(v42_6))
        };
        drop(v41_5);
        let v41_8: Space = intersect(&(*CONSTANT_21),&(v41_2));
        drop(v41_2);
        let v41_9: Space = if has_head(&(v41_8)) { singleton(&[]) } else { Space::new() };
        drop(v41_8);
        let v41_11: Space = if (v41_9).is_empty() { Space::new() } else {
          let v43_10: Space = routine_17(c, &(v40_11_head), &(v40_6), &(v40_11_tail), &(*s1));
          compose(&(v41_9),&(v43_10))
        };
        drop(v41_9);
        let v41_12: Space = unite(&(v41_7),&(v41_11));
        v40_11.join_into((v41_12).clone());
      }
      drop(v40_11_cursor);
      drop(v40_6);
      compose(&(v38_10),&(v40_11))
    };
    drop(v38_10);
    let v38_13: Space = unite(&(v38_8),&(v38_12));
    v37_9.join_into((v38_13).clone());
  }
  drop(v37_9_cursor);
  (v37_9).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v44_6 = Space::new();
  let mut v44_6_cursor = (*s0).read_zipper();
  for v44_6_byte in v44_6_cursor.child_mask().iter() {
    v44_6_cursor.descend_to_byte(v44_6_byte);
    let v44_6_tail = v44_6_cursor.make_map();
    v44_6_cursor.ascend(1);
    let v44_6_head = Path::from_slice(&[v44_6_byte]);
    let v45_2: Space = singleton(&(v44_6_head));
    let v45_3: Space = intersect(&(*CONSTANT_21),&(v45_2));
    let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
    drop(v45_3);
    let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
    drop(v45_4);
    let v45_8: Space = if (v45_5).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&(v44_6_head));
      let v46_7: Space = routine_5(c, &(v46_6), &(*p1), &(v44_6_tail));
      compose(&(v45_5),&(v46_7))
    };
    drop(v45_5);
    let v45_9: Space = intersect(&(*CONSTANT_21),&(v45_2));
    drop(v45_2);
    let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
    drop(v45_9);
    let v45_13: Space = if (v45_10).is_empty() { Space::new() } else {
      let v47_6: Path = concat_path(&(*p0),&(v44_6_head));
      let v47_11: Path = concat_path(&(*p1),&(v47_6));
      drop(v47_6);
      let v47_12: Space = routine_9(c, &(v47_11));
      drop(v47_11);
      compose(&(v45_10),&(v47_12))
    };
    drop(v45_10);
    let v45_14: Space = unite(&(v45_8),&(v45_13));
    v44_6.join_into((v45_14).clone());
  }
  drop(v44_6_cursor);
  (v44_6).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v48_3: Path = concat_path(&(*p1),&(*p0));
  let v48_4: Space = singleton(&(v48_3));
  drop(v48_3);
  let mut v48_8 = Space::new();
  let mut v48_8_cursor = (v48_4).read_zipper();
  for v48_8_byte in v48_8_cursor.child_mask().iter() {
    v48_8_cursor.descend_to_byte(v48_8_byte);
    let v48_8_tail = v48_8_cursor.make_map();
    v48_8_cursor.ascend(1);
    let v48_8_head = Path::from_slice(&[v48_8_byte]);
    let v49_2: Space = singleton(&(v48_8_head));
    let v49_3: Space = intersect(&(*CONSTANT_21),&(v49_2));
    let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
    drop(v49_3);
    let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
    drop(v49_4);
    let v49_7: Space = if (v49_5).is_empty() { Space::new() } else {
      let v50_6: Space = routine_18(c, &(v48_8_head), &(v48_8_tail));
      compose(&(v49_5),&(v50_6))
    };
    drop(v49_5);
    let v49_8: Space = intersect(&(*CONSTANT_21),&(v49_2));
    drop(v49_2);
    let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
    drop(v49_8);
    let v49_11: Space = if (v49_9).is_empty() { Space::new() } else {
      let v51_10: Space = routine_19(c, &(v48_8_head), &(v48_8_tail));
      compose(&(v49_9),&(v51_10))
    };
    drop(v49_9);
    let v49_12: Space = unite(&(v49_7),&(v49_11));
    v48_8.join_into((v49_12).clone());
  }
  drop(v48_8_cursor);
  drop(v48_4);
  (v48_8).clone()
}

fn routine_7(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v52_8: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let mut v52_18 = Space::new();
  let mut v52_18_cursor = (*s0).read_zipper();
  for v52_18_byte in v52_18_cursor.child_mask().iter() {
    v52_18_cursor.descend_to_byte(v52_18_byte);
    let v52_18_tail = v52_18_cursor.make_map();
    v52_18_cursor.ascend(1);
    let v52_18_head = Path::from_slice(&[v52_18_byte]);
    let v53_2: Space = singleton(&(v52_18_head));
    let v53_3: Space = intersect(&(*CONSTANT_21),&(v53_2));
    let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
    drop(v53_3);
    let v53_5: Space = subtract(&(*CONSTANT_0),&(v53_4));
    drop(v53_4);
    let v53_8: Space = if (v53_5).is_empty() { Space::new() } else {
      let v54_6: Path = concat_path(&(*p0),&(v52_18_head));
      let v54_7: Space = routine_7(c, &(v54_6), &(*p1), &(v52_18_tail), &(*s1));
      compose(&(v53_5),&(v54_7))
    };
    drop(v53_5);
    let v53_9: Space = intersect(&(*CONSTANT_21),&(v53_2));
    drop(v53_2);
    let v53_10: Space = if has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
    drop(v53_9);
    let v53_22: Space = if (v53_10).is_empty() { Space::new() } else {
      let v55_6: Path = concat_path(&(*p0),&(v52_18_head));
      let v55_11: Path = concat_path(&(*p1),&(v55_6));
      drop(v55_6);
      let v55_12: Space = routine_9(c, &(v55_11));
      let v55_13: Space = intersect(&(v52_8),&(v55_12));
      let v55_14: Space = range(&(v55_13),3,4);
      let mut v55_15 = Space::new();
      let mut v55_15_cursor = (v55_14).read_zipper();
      for v55_15_byte in v55_15_cursor.child_mask().iter() {
        v55_15_cursor.descend_to_byte(v55_15_byte);
        let v55_15_tail = v55_15_cursor.make_map();
        v55_15_cursor.ascend(1);
        let v55_15_head = Path::from_slice(&[v55_15_byte]);
        let v56_2: Space = singleton(&(v55_15_head));
        let v56_3: Space = intersect(&(*CONSTANT_21),&(v56_2));
        let v56_4: Space = if has_head(&(v56_3)) { singleton(&[]) } else { Space::new() };
        drop(v56_3);
        let v56_5: Space = subtract(&(*CONSTANT_0),&(v56_4));
        drop(v56_4);
        let v56_7: Space = if (v56_5).is_empty() { Space::new() } else {
          let v57_6: Space = routine_10(c, &(v55_15_head), &(v55_15_tail));
          compose(&(v56_5),&(v57_6))
        };
        drop(v56_5);
        let v56_8: Space = intersect(&(*CONSTANT_21),&(v56_2));
        drop(v56_2);
        let v56_9: Space = if has_head(&(v56_8)) { singleton(&[]) } else { Space::new() };
        drop(v56_8);
        let v56_11: Space = if (v56_9).is_empty() { Space::new() } else {
          let v58_10: Space = routine_11(c, &(v55_15_head), &(v55_15_tail));
          compose(&(v56_9),&(v58_10))
        };
        drop(v56_9);
        let v56_12: Space = unite(&(v56_7),&(v56_11));
        v55_15.join_into((v56_12).clone());
      }
      drop(v55_15_cursor);
      let v55_16: Space = range(&(v55_13),4,5);
      let mut v55_17 = Space::new();
      let mut v55_17_cursor = (v55_16).read_zipper();
      for v55_17_byte in v55_17_cursor.child_mask().iter() {
        v55_17_cursor.descend_to_byte(v55_17_byte);
        let v55_17_tail = v55_17_cursor.make_map();
        v55_17_cursor.ascend(1);
        let v55_17_head = Path::from_slice(&[v55_17_byte]);
        let v59_2: Space = singleton(&(v55_17_head));
        let v59_3: Space = intersect(&(*CONSTANT_21),&(v59_2));
        let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
        drop(v59_3);
        let v59_5: Space = subtract(&(*CONSTANT_0),&(v59_4));
        drop(v59_4);
        let v59_7: Space = if (v59_5).is_empty() { Space::new() } else {
          let v60_6: Space = routine_12(c, &(v55_17_head), &(v55_17_tail));
          compose(&(v59_5),&(v60_6))
        };
        drop(v59_5);
        let v59_8: Space = intersect(&(*CONSTANT_21),&(v59_2));
        drop(v59_2);
        let v59_9: Space = if has_head(&(v59_8)) { singleton(&[]) } else { Space::new() };
        drop(v59_8);
        let v59_11: Space = if (v59_9).is_empty() { Space::new() } else {
          let v61_10: Space = routine_13(c, &(v55_17_head), &(v55_17_tail));
          compose(&(v59_9),&(v61_10))
        };
        drop(v59_9);
        let v59_12: Space = unite(&(v59_7),&(v59_11));
        v55_17.join_into((v59_12).clone());
      }
      drop(v55_17_cursor);
      let v55_18: Space = subtract(&(v55_15),&(v55_17));
      let v55_20: Space = if (v55_18).is_empty() { Space::new() } else {
        let v62_19: Space = singleton(&(v55_11));
        compose(&(v55_18),&(v62_19))
      };
      let mut v55_21 = Space::new();
      let mut v55_21_cursor = (v55_20).read_zipper();
      for v55_21_byte in v55_21_cursor.child_mask().iter() {
        v55_21_cursor.descend_to_byte(v55_21_byte);
        let v55_21_tail = v55_21_cursor.make_map();
        v55_21_cursor.ascend(1);
        let v55_21_head = Path::from_slice(&[v55_21_byte]);
        let v63_2: Space = singleton(&(v55_21_head));
        let v63_3: Space = intersect(&(*CONSTANT_21),&(v63_2));
        let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
        drop(v63_3);
        let v63_5: Space = subtract(&(*CONSTANT_0),&(v63_4));
        drop(v63_4);
        let v63_7: Space = if (v63_5).is_empty() { Space::new() } else {
          let v64_6: Space = routine_14(c, &(v55_21_head), &(v55_21_tail));
          compose(&(v63_5),&(v64_6))
        };
        drop(v63_5);
        let v63_8: Space = intersect(&(*CONSTANT_21),&(v63_2));
        drop(v63_2);
        let v63_9: Space = if has_head(&(v63_8)) { singleton(&[]) } else { Space::new() };
        drop(v63_8);
        let v63_11: Space = if (v63_9).is_empty() { Space::new() } else {
          let v65_10: Space = routine_15(c, &(v55_21_head), &(v55_21_tail));
          compose(&(v63_9),&(v65_10))
        };
        drop(v63_9);
        let v63_12: Space = unite(&(v63_7),&(v63_11));
        v55_21.join_into((v63_12).clone());
      }
      drop(v55_21_cursor);
      compose(&(v53_10),&(v55_21))
    };
    drop(v53_10);
    let v53_23: Space = unite(&(v53_8),&(v53_22));
    v52_18.join_into((v53_23).clone());
  }
  drop(v52_18_cursor);
  drop(v52_8);
  (v52_18).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v66_5: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v66_6: Path = concat_path(&(*p1),&(*p0));
  let v66_7: Space = singleton(&(v66_6));
  drop(v66_6);
  let mut v66_11 = Space::new();
  let mut v66_11_cursor = (v66_7).read_zipper();
  for v66_11_byte in v66_11_cursor.child_mask().iter() {
    v66_11_cursor.descend_to_byte(v66_11_byte);
    let v66_11_tail = v66_11_cursor.make_map();
    v66_11_cursor.ascend(1);
    let v66_11_head = Path::from_slice(&[v66_11_byte]);
    let v67_2: Space = singleton(&(v66_11_head));
    let v67_3: Space = intersect(&(*CONSTANT_21),&(v67_2));
    let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
    drop(v67_3);
    let v67_5: Space = subtract(&(*CONSTANT_0),&(v67_4));
    drop(v67_4);
    let v67_7: Space = if (v67_5).is_empty() { Space::new() } else {
      let v68_6: Space = routine_18(c, &(v66_11_head), &(v66_11_tail));
      compose(&(v67_5),&(v68_6))
    };
    drop(v67_5);
    let v67_8: Space = intersect(&(*CONSTANT_21),&(v67_2));
    drop(v67_2);
    let v67_9: Space = if has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
    drop(v67_8);
    let v67_11: Space = if (v67_9).is_empty() { Space::new() } else {
      let v69_10: Space = routine_19(c, &(v66_11_head), &(v66_11_tail));
      compose(&(v67_9),&(v69_10))
    };
    drop(v67_9);
    let v67_12: Space = unite(&(v67_7),&(v67_11));
    v66_11.join_into((v67_12).clone());
  }
  drop(v66_11_cursor);
  let v66_12: Space = intersect(&(v66_5),&(v66_11));
  let v66_13: Space = range(&(v66_12),3,4);
  let mut v66_21 = Space::new();
  let mut v66_21_cursor = (v66_13).read_zipper();
  for v66_21_byte in v66_21_cursor.child_mask().iter() {
    v66_21_cursor.descend_to_byte(v66_21_byte);
    let v66_21_tail = v66_21_cursor.make_map();
    v66_21_cursor.ascend(1);
    let v66_21_head = Path::from_slice(&[v66_21_byte]);
    let v70_2: Space = singleton(&(v66_21_head));
    let v70_3: Space = intersect(&(*CONSTANT_21),&(v70_2));
    let v70_4: Space = if has_head(&(v70_3)) { singleton(&[]) } else { Space::new() };
    drop(v70_3);
    let v70_5: Space = subtract(&(*CONSTANT_0),&(v70_4));
    drop(v70_4);
    let v70_7: Space = if (v70_5).is_empty() { Space::new() } else {
      let mut v71_6 = Space::new();
      let mut v71_6_cursor = (v66_21_tail).read_zipper();
      for v71_6_byte in v71_6_cursor.child_mask().iter() {
        v71_6_cursor.descend_to_byte(v71_6_byte);
        let v71_6_tail = v71_6_cursor.make_map();
        v71_6_cursor.ascend(1);
        let v71_6_head = Path::from_slice(&[v71_6_byte]);
        let v72_2: Space = singleton(&(v71_6_head));
        let v72_3: Space = intersect(&(*CONSTANT_21),&(v72_2));
        let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
        drop(v72_3);
        let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
        drop(v72_4);
        let v72_8: Space = if (v72_5).is_empty() { Space::new() } else {
          let v73_6: Path = concat_path(&(v66_21_head),&(v71_6_head));
          let v73_7: Space = routine_10(c, &(v73_6), &(v71_6_tail));
          compose(&(v72_5),&(v73_7))
        };
        drop(v72_5);
        let v72_9: Space = intersect(&(*CONSTANT_21),&(v72_2));
        drop(v72_2);
        let v72_10: Space = if has_head(&(v72_9)) { singleton(&[]) } else { Space::new() };
        drop(v72_9);
        let v72_12: Space = if (v72_10).is_empty() { Space::new() } else {
          let v74_6: Path = concat_path(&(v66_21_head),&(v71_6_head));
          let v74_11: Space = routine_11(c, &(v74_6), &(v71_6_tail));
          drop(v74_6);
          compose(&(v72_10),&(v74_11))
        };
        drop(v72_10);
        let v72_13: Space = unite(&(v72_8),&(v72_12));
        v71_6.join_into((v72_13).clone());
      }
      drop(v71_6_cursor);
      compose(&(v70_5),&(v71_6))
    };
    drop(v70_5);
    let v70_8: Space = intersect(&(*CONSTANT_21),&(v70_2));
    drop(v70_2);
    let v70_9: Space = if has_head(&(v70_8)) { singleton(&[]) } else { Space::new() };
    drop(v70_8);
    let v70_10: Space = compose(&(v70_9),&(*CONSTANT_24));
    drop(v70_9);
    let v70_11: Space = unite(&(v70_7),&(v70_10));
    drop(v70_10);
    v66_21.join_into((v70_11).clone());
  }
  drop(v66_21_cursor);
  let mut v66_25 = Space::new();
  let mut v66_25_cursor = (v66_7).read_zipper();
  for v66_25_byte in v66_25_cursor.child_mask().iter() {
    v66_25_cursor.descend_to_byte(v66_25_byte);
    let v66_25_tail = v66_25_cursor.make_map();
    v66_25_cursor.ascend(1);
    let v66_25_head = Path::from_slice(&[v66_25_byte]);
    let v75_2: Space = singleton(&(v66_25_head));
    let v75_3: Space = intersect(&(*CONSTANT_21),&(v75_2));
    let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
    drop(v75_3);
    let v75_5: Space = subtract(&(*CONSTANT_0),&(v75_4));
    drop(v75_4);
    let v75_7: Space = if (v75_5).is_empty() { Space::new() } else {
      let v76_6: Space = routine_18(c, &(v66_25_head), &(v66_25_tail));
      compose(&(v75_5),&(v76_6))
    };
    drop(v75_5);
    let v75_8: Space = intersect(&(*CONSTANT_21),&(v75_2));
    drop(v75_2);
    let v75_9: Space = if has_head(&(v75_8)) { singleton(&[]) } else { Space::new() };
    drop(v75_8);
    let v75_11: Space = if (v75_9).is_empty() { Space::new() } else {
      let v77_10: Space = routine_19(c, &(v66_25_head), &(v66_25_tail));
      compose(&(v75_9),&(v77_10))
    };
    drop(v75_9);
    let v75_12: Space = unite(&(v75_7),&(v75_11));
    v66_25.join_into((v75_12).clone());
  }
  drop(v66_25_cursor);
  let v66_26: Space = intersect(&(v66_5),&(v66_25));
  drop(v66_5);
  let v66_27: Space = range(&(v66_26),4,5);
  let mut v66_35 = Space::new();
  let mut v66_35_cursor = (v66_27).read_zipper();
  for v66_35_byte in v66_35_cursor.child_mask().iter() {
    v66_35_cursor.descend_to_byte(v66_35_byte);
    let v66_35_tail = v66_35_cursor.make_map();
    v66_35_cursor.ascend(1);
    let v66_35_head = Path::from_slice(&[v66_35_byte]);
    let v78_2: Space = singleton(&(v66_35_head));
    let v78_3: Space = intersect(&(*CONSTANT_21),&(v78_2));
    let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
    drop(v78_3);
    let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
    drop(v78_4);
    let v78_7: Space = if (v78_5).is_empty() { Space::new() } else {
      let mut v79_6 = Space::new();
      let mut v79_6_cursor = (v66_35_tail).read_zipper();
      for v79_6_byte in v79_6_cursor.child_mask().iter() {
        v79_6_cursor.descend_to_byte(v79_6_byte);
        let v79_6_tail = v79_6_cursor.make_map();
        v79_6_cursor.ascend(1);
        let v79_6_head = Path::from_slice(&[v79_6_byte]);
        let v80_2: Space = singleton(&(v79_6_head));
        let v80_3: Space = intersect(&(*CONSTANT_21),&(v80_2));
        let v80_4: Space = if has_head(&(v80_3)) { singleton(&[]) } else { Space::new() };
        drop(v80_3);
        let v80_5: Space = subtract(&(*CONSTANT_0),&(v80_4));
        drop(v80_4);
        let v80_8: Space = if (v80_5).is_empty() { Space::new() } else {
          let v81_6: Path = concat_path(&(v66_35_head),&(v79_6_head));
          let v81_7: Space = routine_12(c, &(v81_6), &(v79_6_tail));
          compose(&(v80_5),&(v81_7))
        };
        drop(v80_5);
        let v80_9: Space = intersect(&(*CONSTANT_21),&(v80_2));
        drop(v80_2);
        let v80_10: Space = if has_head(&(v80_9)) { singleton(&[]) } else { Space::new() };
        drop(v80_9);
        let v80_12: Space = if (v80_10).is_empty() { Space::new() } else {
          let v82_6: Path = concat_path(&(v66_35_head),&(v79_6_head));
          let v82_11: Space = routine_13(c, &(v82_6), &(v79_6_tail));
          drop(v82_6);
          compose(&(v80_10),&(v82_11))
        };
        drop(v80_10);
        let v80_13: Space = unite(&(v80_8),&(v80_12));
        v79_6.join_into((v80_13).clone());
      }
      drop(v79_6_cursor);
      compose(&(v78_5),&(v79_6))
    };
    drop(v78_5);
    let v78_8: Space = intersect(&(*CONSTANT_21),&(v78_2));
    drop(v78_2);
    let v78_9: Space = if has_head(&(v78_8)) { singleton(&[]) } else { Space::new() };
    drop(v78_8);
    let v78_10: Space = compose(&(v78_9),&(*CONSTANT_24));
    drop(v78_9);
    let v78_11: Space = unite(&(v78_7),&(v78_10));
    drop(v78_10);
    v66_35.join_into((v78_11).clone());
  }
  drop(v66_35_cursor);
  let v66_36: Space = subtract(&(v66_21),&(v66_35));
  let v66_37: Space = if (v66_36).is_empty() { Space::new() } else {
    compose(&(v66_36),&(v66_7))
  };
  drop(v66_7);
  let mut v66_44 = Space::new();
  let mut v66_44_cursor = (v66_37).read_zipper();
  for v66_44_byte in v66_44_cursor.child_mask().iter() {
    v66_44_cursor.descend_to_byte(v66_44_byte);
    let v66_44_tail = v66_44_cursor.make_map();
    v66_44_cursor.ascend(1);
    let v66_44_head = Path::from_slice(&[v66_44_byte]);
    let v84_2: Space = singleton(&(v66_44_head));
    let v84_3: Space = intersect(&(*CONSTANT_21),&(v84_2));
    let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
    drop(v84_3);
    let v84_5: Space = subtract(&(*CONSTANT_0),&(v84_4));
    drop(v84_4);
    let v84_7: Space = if (v84_5).is_empty() { Space::new() } else {
      let mut v85_6 = Space::new();
      let mut v85_6_cursor = (v66_44_tail).read_zipper();
      for v85_6_byte in v85_6_cursor.child_mask().iter() {
        v85_6_cursor.descend_to_byte(v85_6_byte);
        let v85_6_tail = v85_6_cursor.make_map();
        v85_6_cursor.ascend(1);
        let v85_6_head = Path::from_slice(&[v85_6_byte]);
        let v86_2: Space = singleton(&(v85_6_head));
        let v86_3: Space = intersect(&(*CONSTANT_21),&(v86_2));
        let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
        drop(v86_3);
        let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
        drop(v86_4);
        let v86_8: Space = if (v86_5).is_empty() { Space::new() } else {
          let v87_6: Path = concat_path(&(v66_44_head),&(v85_6_head));
          let v87_7: Space = routine_14(c, &(v87_6), &(v85_6_tail));
          compose(&(v86_5),&(v87_7))
        };
        drop(v86_5);
        let v86_9: Space = intersect(&(*CONSTANT_21),&(v86_2));
        drop(v86_2);
        let v86_10: Space = if has_head(&(v86_9)) { singleton(&[]) } else { Space::new() };
        drop(v86_9);
        let v86_12: Space = if (v86_10).is_empty() { Space::new() } else {
          let v88_6: Path = concat_path(&(v66_44_head),&(v85_6_head));
          let v88_11: Space = routine_15(c, &(v88_6), &(v85_6_tail));
          drop(v88_6);
          compose(&(v86_10),&(v88_11))
        };
        drop(v86_10);
        let v86_13: Space = unite(&(v86_8),&(v86_12));
        v85_6.join_into((v86_13).clone());
      }
      drop(v85_6_cursor);
      compose(&(v84_5),&(v85_6))
    };
    drop(v84_5);
    let v84_8: Space = intersect(&(*CONSTANT_21),&(v84_2));
    drop(v84_2);
    let v84_9: Space = if has_head(&(v84_8)) { singleton(&[]) } else { Space::new() };
    drop(v84_8);
    let v84_10: Space = compose(&(v84_9),&(v66_44_tail));
    drop(v84_9);
    let v84_11: Space = unite(&(v84_7),&(v84_10));
    drop(v84_10);
    v66_44.join_into((v84_11).clone());
  }
  drop(v66_44_cursor);
  (v66_44).clone()
}

fn routine_9(c: &mut Context, p0: &Path) -> Space {
  let v89_1: Space = singleton(&(*p0));
  let mut v89_11 = Space::new();
  let mut v89_11_cursor = (v89_1).read_zipper();
  for v89_11_byte in v89_11_cursor.child_mask().iter() {
    v89_11_cursor.descend_to_byte(v89_11_byte);
    let v89_11_tail = v89_11_cursor.make_map();
    v89_11_cursor.ascend(1);
    let v89_11_head = Path::from_slice(&[v89_11_byte]);
    let v90_2: Space = singleton(&(v89_11_head));
    let v90_3: Space = intersect(&(*CONSTANT_21),&(v90_2));
    let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
    drop(v90_3);
    let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
    drop(v90_4);
    let v90_7: Space = if (v90_5).is_empty() { Space::new() } else {
      let mut v91_6 = Space::new();
      let mut v91_6_cursor = (v89_11_tail).read_zipper();
      for v91_6_byte in v91_6_cursor.child_mask().iter() {
        v91_6_cursor.descend_to_byte(v91_6_byte);
        let v91_6_tail = v91_6_cursor.make_map();
        v91_6_cursor.ascend(1);
        let v91_6_head = Path::from_slice(&[v91_6_byte]);
        let v92_2: Space = singleton(&(v91_6_head));
        let v92_3: Space = intersect(&(*CONSTANT_21),&(v92_2));
        let v92_4: Space = if has_head(&(v92_3)) { singleton(&[]) } else { Space::new() };
        drop(v92_3);
        let v92_5: Space = subtract(&(*CONSTANT_0),&(v92_4));
        drop(v92_4);
        let v92_8: Space = if (v92_5).is_empty() { Space::new() } else {
          let v93_6: Path = concat_path(&(v89_11_head),&(v91_6_head));
          let v93_7: Space = routine_18(c, &(v93_6), &(v91_6_tail));
          compose(&(v92_5),&(v93_7))
        };
        drop(v92_5);
        let v92_9: Space = intersect(&(*CONSTANT_21),&(v92_2));
        drop(v92_2);
        let v92_10: Space = if has_head(&(v92_9)) { singleton(&[]) } else { Space::new() };
        drop(v92_9);
        let v92_12: Space = if (v92_10).is_empty() { Space::new() } else {
          let v94_6: Path = concat_path(&(v89_11_head),&(v91_6_head));
          let v94_11: Space = routine_19(c, &(v94_6), &(v91_6_tail));
          drop(v94_6);
          compose(&(v92_10),&(v94_11))
        };
        drop(v92_10);
        let v92_13: Space = unite(&(v92_8),&(v92_12));
        v91_6.join_into((v92_13).clone());
      }
      drop(v91_6_cursor);
      compose(&(v90_5),&(v91_6))
    };
    drop(v90_5);
    let v90_8: Space = intersect(&(*CONSTANT_21),&(v90_2));
    drop(v90_2);
    let v90_9: Space = if has_head(&(v90_8)) { singleton(&[]) } else { Space::new() };
    drop(v90_8);
    let v90_11: Space = if (v90_9).is_empty() { Space::new() } else {
      let mut v95_10 = Space::new();
      let mut v95_10_cursor = (v89_11_tail).read_zipper();
      for v95_10_byte in v95_10_cursor.child_mask().iter() {
        v95_10_cursor.descend_to_byte(v95_10_byte);
        let v95_10_tail = v95_10_cursor.make_map();
        v95_10_cursor.ascend(1);
        let v95_10_head = Path::from_slice(&[v95_10_byte]);
        let v96_2: Space = singleton(&(v95_10_head));
        let v96_3: Space = intersect(&(*CONSTANT_21),&(v96_2));
        let v96_4: Space = if has_head(&(v96_3)) { singleton(&[]) } else { Space::new() };
        drop(v96_3);
        let v96_5: Space = subtract(&(*CONSTANT_0),&(v96_4));
        drop(v96_4);
        let v96_7: Space = if (v96_5).is_empty() { Space::new() } else {
          let v97_6: Space = routine_20(c, &(v95_10_head), &(v89_11_head), &(v95_10_tail));
          compose(&(v96_5),&(v97_6))
        };
        drop(v96_5);
        let v96_8: Space = intersect(&(*CONSTANT_21),&(v96_2));
        drop(v96_2);
        let v96_9: Space = if has_head(&(v96_8)) { singleton(&[]) } else { Space::new() };
        drop(v96_8);
        let v96_11: Space = if (v96_9).is_empty() { Space::new() } else {
          let v98_10: Space = routine_21(c, &(v95_10_head), &(v89_11_head), &(v95_10_tail));
          compose(&(v96_9),&(v98_10))
        };
        drop(v96_9);
        let v96_12: Space = unite(&(v96_7),&(v96_11));
        v95_10.join_into((v96_12).clone());
      }
      drop(v95_10_cursor);
      compose(&(v90_9),&(v95_10))
    };
    drop(v90_9);
    let v90_12: Space = unite(&(v90_7),&(v90_11));
    v89_11.join_into((v90_12).clone());
  }
  drop(v89_11_cursor);
  drop(v89_1);
  (v89_11).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v99_6 = Space::new();
  let mut v99_6_cursor = (*s0).read_zipper();
  for v99_6_byte in v99_6_cursor.child_mask().iter() {
    v99_6_cursor.descend_to_byte(v99_6_byte);
    let v99_6_tail = v99_6_cursor.make_map();
    v99_6_cursor.ascend(1);
    let v99_6_head = Path::from_slice(&[v99_6_byte]);
    let v100_2: Space = singleton(&(v99_6_head));
    let v100_3: Space = intersect(&(*CONSTANT_21),&(v100_2));
    let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
    drop(v100_3);
    let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
    drop(v100_4);
    let v100_8: Space = if (v100_5).is_empty() { Space::new() } else {
      let v101_6: Path = concat_path(&(*p0),&(v99_6_head));
      let v101_7: Space = routine_10(c, &(v101_6), &(v99_6_tail));
      drop(v101_6);
      compose(&(v100_5),&(v101_7))
    };
    drop(v100_5);
    let v100_9: Space = intersect(&(*CONSTANT_21),&(v100_2));
    drop(v100_2);
    let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
    drop(v100_9);
    let v100_11: Space = compose(&(v100_10),&(*CONSTANT_24));
    drop(v100_10);
    let v100_12: Space = unite(&(v100_8),&(v100_11));
    drop(v100_11);
    v99_6.join_into((v100_12).clone());
  }
  drop(v99_6_cursor);
  (v99_6).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*CONSTANT_24).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v103_6 = Space::new();
  let mut v103_6_cursor = (*s0).read_zipper();
  for v103_6_byte in v103_6_cursor.child_mask().iter() {
    v103_6_cursor.descend_to_byte(v103_6_byte);
    let v103_6_tail = v103_6_cursor.make_map();
    v103_6_cursor.ascend(1);
    let v103_6_head = Path::from_slice(&[v103_6_byte]);
    let v104_2: Space = singleton(&(v103_6_head));
    let v104_3: Space = intersect(&(*CONSTANT_21),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_8: Space = if (v104_5).is_empty() { Space::new() } else {
      let v105_6: Path = concat_path(&(*p0),&(v103_6_head));
      let v105_7: Space = routine_12(c, &(v105_6), &(v103_6_tail));
      drop(v105_6);
      compose(&(v104_5),&(v105_7))
    };
    drop(v104_5);
    let v104_9: Space = intersect(&(*CONSTANT_21),&(v104_2));
    drop(v104_2);
    let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
    drop(v104_9);
    let v104_11: Space = compose(&(v104_10),&(*CONSTANT_24));
    drop(v104_10);
    let v104_12: Space = unite(&(v104_8),&(v104_11));
    drop(v104_11);
    v103_6.join_into((v104_12).clone());
  }
  drop(v103_6_cursor);
  (v103_6).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*CONSTANT_24).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v107_5 = Space::new();
  let mut v107_5_cursor = (*s0).read_zipper();
  for v107_5_byte in v107_5_cursor.child_mask().iter() {
    v107_5_cursor.descend_to_byte(v107_5_byte);
    let v107_5_tail = v107_5_cursor.make_map();
    v107_5_cursor.ascend(1);
    let v107_5_head = Path::from_slice(&[v107_5_byte]);
    let v108_2: Space = singleton(&(v107_5_head));
    let v108_3: Space = intersect(&(*CONSTANT_21),&(v108_2));
    let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
    drop(v108_3);
    let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
    drop(v108_4);
    let v108_8: Space = if (v108_5).is_empty() { Space::new() } else {
      let v109_6: Path = concat_path(&(*p0),&(v107_5_head));
      let v109_7: Space = routine_14(c, &(v109_6), &(v107_5_tail));
      drop(v109_6);
      compose(&(v108_5),&(v109_7))
    };
    drop(v108_5);
    let v108_9: Space = intersect(&(*CONSTANT_21),&(v108_2));
    drop(v108_2);
    let v108_10: Space = if has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
    drop(v108_9);
    let v108_11: Space = compose(&(v108_10),&(v107_5_tail));
    drop(v108_10);
    let v108_12: Space = unite(&(v108_8),&(v108_11));
    drop(v108_11);
    v107_5.join_into((v108_12).clone());
  }
  drop(v107_5_cursor);
  (v107_5).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v111_8: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let mut v111_18 = Space::new();
  let mut v111_18_cursor = (*s0).read_zipper();
  for v111_18_byte in v111_18_cursor.child_mask().iter() {
    v111_18_cursor.descend_to_byte(v111_18_byte);
    let v111_18_tail = v111_18_cursor.make_map();
    v111_18_cursor.ascend(1);
    let v111_18_head = Path::from_slice(&[v111_18_byte]);
    let v112_2: Space = singleton(&(v111_18_head));
    let v112_3: Space = intersect(&(*CONSTANT_21),&(v112_2));
    let v112_4: Space = if has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
    drop(v112_3);
    let v112_5: Space = subtract(&(*CONSTANT_0),&(v112_4));
    drop(v112_4);
    let v112_8: Space = if (v112_5).is_empty() { Space::new() } else {
      let v113_6: Path = concat_path(&(*p0),&(v111_18_head));
      let v113_7: Space = routine_16(c, &(v113_6), &(*p1), &(v111_18_tail), &(*s1));
      compose(&(v112_5),&(v113_7))
    };
    drop(v112_5);
    let v112_9: Space = intersect(&(*CONSTANT_21),&(v112_2));
    drop(v112_2);
    let v112_10: Space = if has_head(&(v112_9)) { singleton(&[]) } else { Space::new() };
    drop(v112_9);
    let v112_22: Space = if (v112_10).is_empty() { Space::new() } else {
      let v114_6: Path = concat_path(&(*p0),&(v111_18_head));
      let v114_11: Path = concat_path(&(*p1),&(v114_6));
      drop(v114_6);
      let v114_12: Space = routine_9(c, &(v114_11));
      let v114_13: Space = intersect(&(v111_8),&(v114_12));
      let v114_14: Space = range(&(v114_13),2,3);
      let mut v114_15 = Space::new();
      let mut v114_15_cursor = (v114_14).read_zipper();
      for v114_15_byte in v114_15_cursor.child_mask().iter() {
        v114_15_cursor.descend_to_byte(v114_15_byte);
        let v114_15_tail = v114_15_cursor.make_map();
        v114_15_cursor.ascend(1);
        let v114_15_head = Path::from_slice(&[v114_15_byte]);
        let v115_2: Space = singleton(&(v114_15_head));
        let v115_3: Space = intersect(&(*CONSTANT_21),&(v115_2));
        let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
        drop(v115_3);
        let v115_5: Space = subtract(&(*CONSTANT_0),&(v115_4));
        drop(v115_4);
        let v115_7: Space = if (v115_5).is_empty() { Space::new() } else {
          let v116_6: Space = routine_22(c, &(v114_15_head), &(v114_15_tail));
          compose(&(v115_5),&(v116_6))
        };
        drop(v115_5);
        let v115_8: Space = intersect(&(*CONSTANT_21),&(v115_2));
        drop(v115_2);
        let v115_9: Space = if has_head(&(v115_8)) { singleton(&[]) } else { Space::new() };
        drop(v115_8);
        let v115_11: Space = if (v115_9).is_empty() { Space::new() } else {
          let v117_10: Space = routine_23(c, &(v114_15_head), &(v114_15_tail));
          compose(&(v115_9),&(v117_10))
        };
        drop(v115_9);
        let v115_12: Space = unite(&(v115_7),&(v115_11));
        v114_15.join_into((v115_12).clone());
      }
      drop(v114_15_cursor);
      let v114_16: Space = range(&(v114_13),3,4);
      let mut v114_17 = Space::new();
      let mut v114_17_cursor = (v114_16).read_zipper();
      for v114_17_byte in v114_17_cursor.child_mask().iter() {
        v114_17_cursor.descend_to_byte(v114_17_byte);
        let v114_17_tail = v114_17_cursor.make_map();
        v114_17_cursor.ascend(1);
        let v114_17_head = Path::from_slice(&[v114_17_byte]);
        let v118_2: Space = singleton(&(v114_17_head));
        let v118_3: Space = intersect(&(*CONSTANT_21),&(v118_2));
        let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
        drop(v118_3);
        let v118_5: Space = subtract(&(*CONSTANT_0),&(v118_4));
        drop(v118_4);
        let v118_7: Space = if (v118_5).is_empty() { Space::new() } else {
          let v119_6: Space = routine_24(c, &(v114_17_head), &(v114_17_tail));
          compose(&(v118_5),&(v119_6))
        };
        drop(v118_5);
        let v118_8: Space = intersect(&(*CONSTANT_21),&(v118_2));
        drop(v118_2);
        let v118_9: Space = if has_head(&(v118_8)) { singleton(&[]) } else { Space::new() };
        drop(v118_8);
        let v118_11: Space = if (v118_9).is_empty() { Space::new() } else {
          let v120_10: Space = routine_25(c, &(v114_17_head), &(v114_17_tail));
          compose(&(v118_9),&(v120_10))
        };
        drop(v118_9);
        let v118_12: Space = unite(&(v118_7),&(v118_11));
        v114_17.join_into((v118_12).clone());
      }
      drop(v114_17_cursor);
      let v114_18: Space = subtract(&(v114_15),&(v114_17));
      let v114_20: Space = if (v114_18).is_empty() { Space::new() } else {
        let v121_19: Space = singleton(&(v114_11));
        compose(&(v114_18),&(v121_19))
      };
      let mut v114_21 = Space::new();
      let mut v114_21_cursor = (v114_20).read_zipper();
      for v114_21_byte in v114_21_cursor.child_mask().iter() {
        v114_21_cursor.descend_to_byte(v114_21_byte);
        let v114_21_tail = v114_21_cursor.make_map();
        v114_21_cursor.ascend(1);
        let v114_21_head = Path::from_slice(&[v114_21_byte]);
        let v122_2: Space = singleton(&(v114_21_head));
        let v122_3: Space = intersect(&(*CONSTANT_21),&(v122_2));
        let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
        drop(v122_3);
        let v122_5: Space = subtract(&(*CONSTANT_0),&(v122_4));
        drop(v122_4);
        let v122_7: Space = if (v122_5).is_empty() { Space::new() } else {
          let v123_6: Space = routine_26(c, &(v114_21_head), &(v114_21_tail));
          compose(&(v122_5),&(v123_6))
        };
        drop(v122_5);
        let v122_8: Space = intersect(&(*CONSTANT_21),&(v122_2));
        drop(v122_2);
        let v122_9: Space = if has_head(&(v122_8)) { singleton(&[]) } else { Space::new() };
        drop(v122_8);
        let v122_11: Space = if (v122_9).is_empty() { Space::new() } else {
          let v124_10: Space = routine_27(c, &(v114_21_head), &(v114_21_tail));
          compose(&(v122_9),&(v124_10))
        };
        drop(v122_9);
        let v122_12: Space = unite(&(v122_7),&(v122_11));
        v114_21.join_into((v122_12).clone());
      }
      drop(v114_21_cursor);
      compose(&(v112_10),&(v114_21))
    };
    drop(v112_10);
    let v112_23: Space = unite(&(v112_8),&(v112_22));
    v111_18.join_into((v112_23).clone());
  }
  drop(v111_18_cursor);
  drop(v111_8);
  (v111_18).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v125_5: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v125_6: Path = concat_path(&(*p1),&(*p0));
  let v125_7: Space = singleton(&(v125_6));
  drop(v125_6);
  let mut v125_11 = Space::new();
  let mut v125_11_cursor = (v125_7).read_zipper();
  for v125_11_byte in v125_11_cursor.child_mask().iter() {
    v125_11_cursor.descend_to_byte(v125_11_byte);
    let v125_11_tail = v125_11_cursor.make_map();
    v125_11_cursor.ascend(1);
    let v125_11_head = Path::from_slice(&[v125_11_byte]);
    let v126_2: Space = singleton(&(v125_11_head));
    let v126_3: Space = intersect(&(*CONSTANT_21),&(v126_2));
    let v126_4: Space = if has_head(&(v126_3)) { singleton(&[]) } else { Space::new() };
    drop(v126_3);
    let v126_5: Space = subtract(&(*CONSTANT_0),&(v126_4));
    drop(v126_4);
    let v126_7: Space = if (v126_5).is_empty() { Space::new() } else {
      let v127_6: Space = routine_18(c, &(v125_11_head), &(v125_11_tail));
      compose(&(v126_5),&(v127_6))
    };
    drop(v126_5);
    let v126_8: Space = intersect(&(*CONSTANT_21),&(v126_2));
    drop(v126_2);
    let v126_9: Space = if has_head(&(v126_8)) { singleton(&[]) } else { Space::new() };
    drop(v126_8);
    let v126_11: Space = if (v126_9).is_empty() { Space::new() } else {
      let v128_10: Space = routine_19(c, &(v125_11_head), &(v125_11_tail));
      compose(&(v126_9),&(v128_10))
    };
    drop(v126_9);
    let v126_12: Space = unite(&(v126_7),&(v126_11));
    v125_11.join_into((v126_12).clone());
  }
  drop(v125_11_cursor);
  let v125_12: Space = intersect(&(v125_5),&(v125_11));
  let v125_13: Space = range(&(v125_12),2,3);
  let mut v125_21 = Space::new();
  let mut v125_21_cursor = (v125_13).read_zipper();
  for v125_21_byte in v125_21_cursor.child_mask().iter() {
    v125_21_cursor.descend_to_byte(v125_21_byte);
    let v125_21_tail = v125_21_cursor.make_map();
    v125_21_cursor.ascend(1);
    let v125_21_head = Path::from_slice(&[v125_21_byte]);
    let v129_2: Space = singleton(&(v125_21_head));
    let v129_3: Space = intersect(&(*CONSTANT_21),&(v129_2));
    let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
    drop(v129_3);
    let v129_5: Space = subtract(&(*CONSTANT_0),&(v129_4));
    drop(v129_4);
    let v129_7: Space = if (v129_5).is_empty() { Space::new() } else {
      let mut v130_6 = Space::new();
      let mut v130_6_cursor = (v125_21_tail).read_zipper();
      for v130_6_byte in v130_6_cursor.child_mask().iter() {
        v130_6_cursor.descend_to_byte(v130_6_byte);
        let v130_6_tail = v130_6_cursor.make_map();
        v130_6_cursor.ascend(1);
        let v130_6_head = Path::from_slice(&[v130_6_byte]);
        let v131_2: Space = singleton(&(v130_6_head));
        let v131_3: Space = intersect(&(*CONSTANT_21),&(v131_2));
        let v131_4: Space = if has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
        drop(v131_3);
        let v131_5: Space = subtract(&(*CONSTANT_0),&(v131_4));
        drop(v131_4);
        let v131_8: Space = if (v131_5).is_empty() { Space::new() } else {
          let v132_6: Path = concat_path(&(v125_21_head),&(v130_6_head));
          let v132_7: Space = routine_22(c, &(v132_6), &(v130_6_tail));
          compose(&(v131_5),&(v132_7))
        };
        drop(v131_5);
        let v131_9: Space = intersect(&(*CONSTANT_21),&(v131_2));
        drop(v131_2);
        let v131_10: Space = if has_head(&(v131_9)) { singleton(&[]) } else { Space::new() };
        drop(v131_9);
        let v131_12: Space = if (v131_10).is_empty() { Space::new() } else {
          let v133_6: Path = concat_path(&(v125_21_head),&(v130_6_head));
          let v133_11: Space = routine_23(c, &(v133_6), &(v130_6_tail));
          drop(v133_6);
          compose(&(v131_10),&(v133_11))
        };
        drop(v131_10);
        let v131_13: Space = unite(&(v131_8),&(v131_12));
        v130_6.join_into((v131_13).clone());
      }
      drop(v130_6_cursor);
      compose(&(v129_5),&(v130_6))
    };
    drop(v129_5);
    let v129_8: Space = intersect(&(*CONSTANT_21),&(v129_2));
    drop(v129_2);
    let v129_9: Space = if has_head(&(v129_8)) { singleton(&[]) } else { Space::new() };
    drop(v129_8);
    let v129_10: Space = compose(&(v129_9),&(*CONSTANT_24));
    drop(v129_9);
    let v129_11: Space = unite(&(v129_7),&(v129_10));
    drop(v129_10);
    v125_21.join_into((v129_11).clone());
  }
  drop(v125_21_cursor);
  let mut v125_25 = Space::new();
  let mut v125_25_cursor = (v125_7).read_zipper();
  for v125_25_byte in v125_25_cursor.child_mask().iter() {
    v125_25_cursor.descend_to_byte(v125_25_byte);
    let v125_25_tail = v125_25_cursor.make_map();
    v125_25_cursor.ascend(1);
    let v125_25_head = Path::from_slice(&[v125_25_byte]);
    let v134_2: Space = singleton(&(v125_25_head));
    let v134_3: Space = intersect(&(*CONSTANT_21),&(v134_2));
    let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
    drop(v134_3);
    let v134_5: Space = subtract(&(*CONSTANT_0),&(v134_4));
    drop(v134_4);
    let v134_7: Space = if (v134_5).is_empty() { Space::new() } else {
      let v135_6: Space = routine_18(c, &(v125_25_head), &(v125_25_tail));
      compose(&(v134_5),&(v135_6))
    };
    drop(v134_5);
    let v134_8: Space = intersect(&(*CONSTANT_21),&(v134_2));
    drop(v134_2);
    let v134_9: Space = if has_head(&(v134_8)) { singleton(&[]) } else { Space::new() };
    drop(v134_8);
    let v134_11: Space = if (v134_9).is_empty() { Space::new() } else {
      let v136_10: Space = routine_19(c, &(v125_25_head), &(v125_25_tail));
      compose(&(v134_9),&(v136_10))
    };
    drop(v134_9);
    let v134_12: Space = unite(&(v134_7),&(v134_11));
    v125_25.join_into((v134_12).clone());
  }
  drop(v125_25_cursor);
  let v125_26: Space = intersect(&(v125_5),&(v125_25));
  drop(v125_5);
  let v125_27: Space = range(&(v125_26),3,4);
  let mut v125_35 = Space::new();
  let mut v125_35_cursor = (v125_27).read_zipper();
  for v125_35_byte in v125_35_cursor.child_mask().iter() {
    v125_35_cursor.descend_to_byte(v125_35_byte);
    let v125_35_tail = v125_35_cursor.make_map();
    v125_35_cursor.ascend(1);
    let v125_35_head = Path::from_slice(&[v125_35_byte]);
    let v137_2: Space = singleton(&(v125_35_head));
    let v137_3: Space = intersect(&(*CONSTANT_21),&(v137_2));
    let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
    drop(v137_3);
    let v137_5: Space = subtract(&(*CONSTANT_0),&(v137_4));
    drop(v137_4);
    let v137_7: Space = if (v137_5).is_empty() { Space::new() } else {
      let mut v138_6 = Space::new();
      let mut v138_6_cursor = (v125_35_tail).read_zipper();
      for v138_6_byte in v138_6_cursor.child_mask().iter() {
        v138_6_cursor.descend_to_byte(v138_6_byte);
        let v138_6_tail = v138_6_cursor.make_map();
        v138_6_cursor.ascend(1);
        let v138_6_head = Path::from_slice(&[v138_6_byte]);
        let v139_2: Space = singleton(&(v138_6_head));
        let v139_3: Space = intersect(&(*CONSTANT_21),&(v139_2));
        let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
        drop(v139_3);
        let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
        drop(v139_4);
        let v139_8: Space = if (v139_5).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v125_35_head),&(v138_6_head));
          let v140_7: Space = routine_24(c, &(v140_6), &(v138_6_tail));
          compose(&(v139_5),&(v140_7))
        };
        drop(v139_5);
        let v139_9: Space = intersect(&(*CONSTANT_21),&(v139_2));
        drop(v139_2);
        let v139_10: Space = if has_head(&(v139_9)) { singleton(&[]) } else { Space::new() };
        drop(v139_9);
        let v139_12: Space = if (v139_10).is_empty() { Space::new() } else {
          let v141_6: Path = concat_path(&(v125_35_head),&(v138_6_head));
          let v141_11: Space = routine_25(c, &(v141_6), &(v138_6_tail));
          drop(v141_6);
          compose(&(v139_10),&(v141_11))
        };
        drop(v139_10);
        let v139_13: Space = unite(&(v139_8),&(v139_12));
        v138_6.join_into((v139_13).clone());
      }
      drop(v138_6_cursor);
      compose(&(v137_5),&(v138_6))
    };
    drop(v137_5);
    let v137_8: Space = intersect(&(*CONSTANT_21),&(v137_2));
    drop(v137_2);
    let v137_9: Space = if has_head(&(v137_8)) { singleton(&[]) } else { Space::new() };
    drop(v137_8);
    let v137_10: Space = compose(&(v137_9),&(*CONSTANT_24));
    drop(v137_9);
    let v137_11: Space = unite(&(v137_7),&(v137_10));
    drop(v137_10);
    v125_35.join_into((v137_11).clone());
  }
  drop(v125_35_cursor);
  let v125_36: Space = subtract(&(v125_21),&(v125_35));
  let v125_37: Space = if (v125_36).is_empty() { Space::new() } else {
    compose(&(v125_36),&(v125_7))
  };
  drop(v125_7);
  let mut v125_44 = Space::new();
  let mut v125_44_cursor = (v125_37).read_zipper();
  for v125_44_byte in v125_44_cursor.child_mask().iter() {
    v125_44_cursor.descend_to_byte(v125_44_byte);
    let v125_44_tail = v125_44_cursor.make_map();
    v125_44_cursor.ascend(1);
    let v125_44_head = Path::from_slice(&[v125_44_byte]);
    let v143_2: Space = singleton(&(v125_44_head));
    let v143_3: Space = intersect(&(*CONSTANT_21),&(v143_2));
    let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
    drop(v143_3);
    let v143_5: Space = subtract(&(*CONSTANT_0),&(v143_4));
    drop(v143_4);
    let v143_7: Space = if (v143_5).is_empty() { Space::new() } else {
      let mut v144_6 = Space::new();
      let mut v144_6_cursor = (v125_44_tail).read_zipper();
      for v144_6_byte in v144_6_cursor.child_mask().iter() {
        v144_6_cursor.descend_to_byte(v144_6_byte);
        let v144_6_tail = v144_6_cursor.make_map();
        v144_6_cursor.ascend(1);
        let v144_6_head = Path::from_slice(&[v144_6_byte]);
        let v145_2: Space = singleton(&(v144_6_head));
        let v145_3: Space = intersect(&(*CONSTANT_21),&(v145_2));
        let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
        drop(v145_3);
        let v145_5: Space = subtract(&(*CONSTANT_0),&(v145_4));
        drop(v145_4);
        let v145_8: Space = if (v145_5).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v125_44_head),&(v144_6_head));
          let v146_7: Space = routine_26(c, &(v146_6), &(v144_6_tail));
          compose(&(v145_5),&(v146_7))
        };
        drop(v145_5);
        let v145_9: Space = intersect(&(*CONSTANT_21),&(v145_2));
        drop(v145_2);
        let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
        drop(v145_9);
        let v145_12: Space = if (v145_10).is_empty() { Space::new() } else {
          let v147_6: Path = concat_path(&(v125_44_head),&(v144_6_head));
          let v147_11: Space = routine_27(c, &(v147_6), &(v144_6_tail));
          drop(v147_6);
          compose(&(v145_10),&(v147_11))
        };
        drop(v145_10);
        let v145_13: Space = unite(&(v145_8),&(v145_12));
        v144_6.join_into((v145_13).clone());
      }
      drop(v144_6_cursor);
      compose(&(v143_5),&(v144_6))
    };
    drop(v143_5);
    let v143_8: Space = intersect(&(*CONSTANT_21),&(v143_2));
    drop(v143_2);
    let v143_9: Space = if has_head(&(v143_8)) { singleton(&[]) } else { Space::new() };
    drop(v143_8);
    let v143_10: Space = compose(&(v143_9),&(v125_44_tail));
    drop(v143_9);
    let v143_11: Space = unite(&(v143_7),&(v143_10));
    drop(v143_10);
    v125_44.join_into((v143_11).clone());
  }
  drop(v125_44_cursor);
  (v125_44).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v148_8 = Space::new();
  let mut v148_8_cursor = (*s0).read_zipper();
  for v148_8_byte in v148_8_cursor.child_mask().iter() {
    v148_8_cursor.descend_to_byte(v148_8_byte);
    let v148_8_tail = v148_8_cursor.make_map();
    v148_8_cursor.ascend(1);
    let v148_8_head = Path::from_slice(&[v148_8_byte]);
    let v149_2: Space = singleton(&(v148_8_head));
    let v149_3: Space = intersect(&(*CONSTANT_21),&(v149_2));
    let v149_4: Space = if has_head(&(v149_3)) { singleton(&[]) } else { Space::new() };
    drop(v149_3);
    let v149_5: Space = subtract(&(*CONSTANT_0),&(v149_4));
    drop(v149_4);
    let v149_8: Space = if (v149_5).is_empty() { Space::new() } else {
      let v150_6: Path = concat_path(&(*p0),&(v148_8_head));
      let v150_7: Space = routine_18(c, &(v150_6), &(v148_8_tail));
      compose(&(v149_5),&(v150_7))
    };
    drop(v149_5);
    let v149_9: Space = intersect(&(*CONSTANT_21),&(v149_2));
    drop(v149_2);
    let v149_10: Space = if has_head(&(v149_9)) { singleton(&[]) } else { Space::new() };
    drop(v149_9);
    let v149_12: Space = if (v149_10).is_empty() { Space::new() } else {
      let v151_6: Path = concat_path(&(*p0),&(v148_8_head));
      let mut v151_11 = Space::new();
      let mut v151_11_cursor = (v148_8_tail).read_zipper();
      for v151_11_byte in v151_11_cursor.child_mask().iter() {
        v151_11_cursor.descend_to_byte(v151_11_byte);
        let v151_11_tail = v151_11_cursor.make_map();
        v151_11_cursor.ascend(1);
        let v151_11_head = Path::from_slice(&[v151_11_byte]);
        let v152_2: Space = singleton(&(v151_11_head));
        let v152_3: Space = intersect(&(*CONSTANT_21),&(v152_2));
        let v152_4: Space = if has_head(&(v152_3)) { singleton(&[]) } else { Space::new() };
        drop(v152_3);
        let v152_5: Space = subtract(&(*CONSTANT_0),&(v152_4));
        drop(v152_4);
        let v152_7: Space = if (v152_5).is_empty() { Space::new() } else {
          let v153_6: Space = routine_20(c, &(v151_11_head), &(v151_6), &(v151_11_tail));
          compose(&(v152_5),&(v153_6))
        };
        drop(v152_5);
        let v152_8: Space = intersect(&(*CONSTANT_21),&(v152_2));
        drop(v152_2);
        let v152_9: Space = if has_head(&(v152_8)) { singleton(&[]) } else { Space::new() };
        drop(v152_8);
        let v152_11: Space = if (v152_9).is_empty() { Space::new() } else {
          let v154_10: Space = routine_21(c, &(v151_11_head), &(v151_6), &(v151_11_tail));
          compose(&(v152_9),&(v154_10))
        };
        drop(v152_9);
        let v152_12: Space = unite(&(v152_7),&(v152_11));
        v151_11.join_into((v152_12).clone());
      }
      drop(v151_11_cursor);
      drop(v151_6);
      compose(&(v149_10),&(v151_11))
    };
    drop(v149_10);
    let v149_13: Space = unite(&(v149_8),&(v149_12));
    v148_8.join_into((v149_13).clone());
  }
  drop(v148_8_cursor);
  (v148_8).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v155_6: Space = unwrap(&(*CONSTANT_25),&(*p0));
  let mut v155_11 = Space::new();
  let mut v155_11_cursor = (*s0).read_zipper();
  for v155_11_byte in v155_11_cursor.child_mask().iter() {
    v155_11_cursor.descend_to_byte(v155_11_byte);
    let v155_11_tail = v155_11_cursor.make_map();
    v155_11_cursor.ascend(1);
    let v155_11_head = Path::from_slice(&[v155_11_byte]);
    let v156_2: Space = singleton(&(v155_11_head));
    let v156_3: Space = intersect(&(*CONSTANT_21),&(v156_2));
    let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
    drop(v156_3);
    let v156_5: Space = subtract(&(*CONSTANT_0),&(v156_4));
    drop(v156_4);
    let v156_7: Space = if (v156_5).is_empty() { Space::new() } else {
      let mut v157_6 = Space::new();
      let mut v157_6_cursor = (v155_11_tail).read_zipper();
      for v157_6_byte in v157_6_cursor.child_mask().iter() {
        v157_6_cursor.descend_to_byte(v157_6_byte);
        let v157_6_tail = v157_6_cursor.make_map();
        v157_6_cursor.ascend(1);
        let v157_6_head = Path::from_slice(&[v157_6_byte]);
        let v158_2: Space = singleton(&(v157_6_head));
        let v158_3: Space = intersect(&(*CONSTANT_21),&(v158_2));
        let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
        drop(v158_3);
        let v158_5: Space = subtract(&(*CONSTANT_0),&(v158_4));
        drop(v158_4);
        let v158_8: Space = if (v158_5).is_empty() { Space::new() } else {
          let v159_6: Path = concat_path(&(v155_11_head),&(v157_6_head));
          let v159_7: Space = routine_20(c, &(v159_6), &(*p0), &(v157_6_tail));
          compose(&(v158_5),&(v159_7))
        };
        drop(v158_5);
        let v158_9: Space = intersect(&(*CONSTANT_21),&(v158_2));
        drop(v158_2);
        let v158_10: Space = if has_head(&(v158_9)) { singleton(&[]) } else { Space::new() };
        drop(v158_9);
        let v158_12: Space = if (v158_10).is_empty() { Space::new() } else {
          let v160_6: Path = concat_path(&(v155_11_head),&(v157_6_head));
          let v160_11: Space = routine_21(c, &(v160_6), &(*p0), &(v157_6_tail));
          drop(v160_6);
          compose(&(v158_10),&(v160_11))
        };
        drop(v158_10);
        let v158_13: Space = unite(&(v158_8),&(v158_12));
        v157_6.join_into((v158_13).clone());
      }
      drop(v157_6_cursor);
      compose(&(v156_5),&(v157_6))
    };
    drop(v156_5);
    let v156_8: Space = intersect(&(*CONSTANT_21),&(v156_2));
    drop(v156_2);
    let v156_9: Space = if has_head(&(v156_8)) { singleton(&[]) } else { Space::new() };
    drop(v156_8);
    let v156_15: Space = if (v156_9).is_empty() { Space::new() } else {
      let v161_10: Space = unwrap(&(*CONSTANT_25),&(v155_11_head));
      let v161_11: Space = compose(&(v155_6),&(v161_10));
      drop(v161_10);
      let v161_12: Path = concat_path(&(*p0),&(v155_11_head));
      let v161_13: Space = singleton(&(v161_12));
      drop(v161_12);
      let v161_14: Space = subtract(&(v161_11),&(v161_13));
      drop(v161_11);
      drop(v161_13);
      compose(&(v156_9),&(v161_14))
    };
    drop(v156_9);
    let v156_16: Space = unite(&(v156_7),&(v156_15));
    drop(v156_15);
    v155_11.join_into((v156_16).clone());
  }
  drop(v155_11_cursor);
  drop(v155_6);
  (v155_11).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v162_7: Space = unwrap(&(*CONSTANT_25),&(*p1));
  let v162_9: Space = unwrap(&(*CONSTANT_25),&(*p0));
  let mut v162_10 = Space::new();
  let mut v162_10_cursor = (*s0).read_zipper();
  for v162_10_byte in v162_10_cursor.child_mask().iter() {
    v162_10_cursor.descend_to_byte(v162_10_byte);
    let v162_10_tail = v162_10_cursor.make_map();
    v162_10_cursor.ascend(1);
    let v162_10_head = Path::from_slice(&[v162_10_byte]);
    let v163_2: Space = singleton(&(v162_10_head));
    let v163_3: Space = intersect(&(*CONSTANT_21),&(v163_2));
    let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
    drop(v163_3);
    let v163_5: Space = subtract(&(*CONSTANT_0),&(v163_4));
    drop(v163_4);
    let v163_8: Space = if (v163_5).is_empty() { Space::new() } else {
      let v164_6: Path = concat_path(&(*p0),&(v162_10_head));
      let v164_7: Space = routine_20(c, &(v164_6), &(*p1), &(v162_10_tail));
      compose(&(v163_5),&(v164_7))
    };
    drop(v163_5);
    let v163_9: Space = intersect(&(*CONSTANT_21),&(v163_2));
    drop(v163_2);
    let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
    drop(v163_9);
    let v163_16: Space = if (v163_10).is_empty() { Space::new() } else {
      let v165_6: Path = concat_path(&(*p0),&(v162_10_head));
      let v165_12: Space = if (v162_7).is_empty() { Space::new() } else {
        let v166_11: Space = unwrap(&(v162_9),&(v162_10_head));
        compose(&(v162_7),&(v166_11))
      };
      let v165_13: Path = concat_path(&(*p1),&(v165_6));
      drop(v165_6);
      let v165_14: Space = singleton(&(v165_13));
      drop(v165_13);
      let v165_15: Space = subtract(&(v165_12),&(v165_14));
      drop(v165_12);
      drop(v165_14);
      compose(&(v163_10),&(v165_15))
    };
    drop(v163_10);
    let v163_17: Space = unite(&(v163_8),&(v163_16));
    drop(v163_16);
    v162_10.join_into((v163_17).clone());
  }
  drop(v162_10_cursor);
  drop(v162_7);
  drop(v162_9);
  (v162_10).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v167_4: Space = unwrap(&(*CONSTANT_25),&(*p1));
  let v167_7: Space = if (v167_4).is_empty() { Space::new() } else {
    let v168_6: Space = unwrap(&(*CONSTANT_25),&(*p0));
    compose(&(v167_4),&(v168_6))
  };
  drop(v167_4);
  let v167_8: Path = concat_path(&(*p1),&(*p0));
  let v167_9: Space = singleton(&(v167_8));
  drop(v167_8);
  let v167_10: Space = subtract(&(v167_7),&(v167_9));
  drop(v167_7);
  drop(v167_9);
  (v167_10).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v169_6 = Space::new();
  let mut v169_6_cursor = (*s0).read_zipper();
  for v169_6_byte in v169_6_cursor.child_mask().iter() {
    v169_6_cursor.descend_to_byte(v169_6_byte);
    let v169_6_tail = v169_6_cursor.make_map();
    v169_6_cursor.ascend(1);
    let v169_6_head = Path::from_slice(&[v169_6_byte]);
    let v170_2: Space = singleton(&(v169_6_head));
    let v170_3: Space = intersect(&(*CONSTANT_21),&(v170_2));
    let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
    drop(v170_3);
    let v170_5: Space = subtract(&(*CONSTANT_0),&(v170_4));
    drop(v170_4);
    let v170_8: Space = if (v170_5).is_empty() { Space::new() } else {
      let v171_6: Path = concat_path(&(*p0),&(v169_6_head));
      let v171_7: Space = routine_22(c, &(v171_6), &(v169_6_tail));
      drop(v171_6);
      compose(&(v170_5),&(v171_7))
    };
    drop(v170_5);
    let v170_9: Space = intersect(&(*CONSTANT_21),&(v170_2));
    drop(v170_2);
    let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
    drop(v170_9);
    let v170_11: Space = compose(&(v170_10),&(*CONSTANT_24));
    drop(v170_10);
    let v170_12: Space = unite(&(v170_8),&(v170_11));
    drop(v170_11);
    v169_6.join_into((v170_12).clone());
  }
  drop(v169_6_cursor);
  (v169_6).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*CONSTANT_24).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v173_6 = Space::new();
  let mut v173_6_cursor = (*s0).read_zipper();
  for v173_6_byte in v173_6_cursor.child_mask().iter() {
    v173_6_cursor.descend_to_byte(v173_6_byte);
    let v173_6_tail = v173_6_cursor.make_map();
    v173_6_cursor.ascend(1);
    let v173_6_head = Path::from_slice(&[v173_6_byte]);
    let v174_2: Space = singleton(&(v173_6_head));
    let v174_3: Space = intersect(&(*CONSTANT_21),&(v174_2));
    let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
    drop(v174_3);
    let v174_5: Space = subtract(&(*CONSTANT_0),&(v174_4));
    drop(v174_4);
    let v174_8: Space = if (v174_5).is_empty() { Space::new() } else {
      let v175_6: Path = concat_path(&(*p0),&(v173_6_head));
      let v175_7: Space = routine_24(c, &(v175_6), &(v173_6_tail));
      drop(v175_6);
      compose(&(v174_5),&(v175_7))
    };
    drop(v174_5);
    let v174_9: Space = intersect(&(*CONSTANT_21),&(v174_2));
    drop(v174_2);
    let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
    drop(v174_9);
    let v174_11: Space = compose(&(v174_10),&(*CONSTANT_24));
    drop(v174_10);
    let v174_12: Space = unite(&(v174_8),&(v174_11));
    drop(v174_11);
    v173_6.join_into((v174_12).clone());
  }
  drop(v173_6_cursor);
  (v173_6).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*CONSTANT_24).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v177_5 = Space::new();
  let mut v177_5_cursor = (*s0).read_zipper();
  for v177_5_byte in v177_5_cursor.child_mask().iter() {
    v177_5_cursor.descend_to_byte(v177_5_byte);
    let v177_5_tail = v177_5_cursor.make_map();
    v177_5_cursor.ascend(1);
    let v177_5_head = Path::from_slice(&[v177_5_byte]);
    let v178_2: Space = singleton(&(v177_5_head));
    let v178_3: Space = intersect(&(*CONSTANT_21),&(v178_2));
    let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
    drop(v178_3);
    let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
    drop(v178_4);
    let v178_8: Space = if (v178_5).is_empty() { Space::new() } else {
      let v179_6: Path = concat_path(&(*p0),&(v177_5_head));
      let v179_7: Space = routine_26(c, &(v179_6), &(v177_5_tail));
      drop(v179_6);
      compose(&(v178_5),&(v179_7))
    };
    drop(v178_5);
    let v178_9: Space = intersect(&(*CONSTANT_21),&(v178_2));
    drop(v178_2);
    let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
    drop(v178_9);
    let v178_11: Space = compose(&(v178_10),&(v177_5_tail));
    drop(v178_10);
    let v178_12: Space = unite(&(v178_8),&(v178_11));
    drop(v178_11);
    v177_5.join_into((v178_12).clone());
  }
  drop(v177_5_cursor);
  (v177_5).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
