#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,0,1,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,0,1,0,0,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>) -> Space {
  let mut v0_5 = Space::new();
  let mut v0_5_cursor = (*s1.expect("unbound native input")).read_zipper();
  for v0_5_byte in v0_5_cursor.child_mask().iter() {
    v0_5_cursor.descend_to_byte(v0_5_byte);
    let v0_5_tail = v0_5_cursor.make_map();
    v0_5_cursor.ascend(1);
    let v0_5_head = Path::from_slice(&[v0_5_byte]);
    let v1_2: Space = singleton(&(v0_5_head));
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let v2_6: Space = routine_1(c, &(v0_5_head), &(v0_5_tail), &(*s0.expect("unbound native input")));
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let v3_10: Space = routine_2(c, &(v0_5_head), &(v0_5_tail), &(*s0.expect("unbound native input")));
      compose(&(v1_9),&(v3_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_5.join_into((v1_12).clone());
  }
  drop(v0_5_cursor);
  let v0_7: Space = wrap(&(v0_5),&(*CONSTANT_2));
  (v0_7).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v4_12 = Space::new();
  let mut v4_12_cursor = (*s0).read_zipper();
  for v4_12_byte in v4_12_cursor.child_mask().iter() {
    v4_12_cursor.descend_to_byte(v4_12_byte);
    let v4_12_tail = v4_12_cursor.make_map();
    v4_12_cursor.ascend(1);
    let v4_12_head = Path::from_slice(&[v4_12_byte]);
    let v5_2: Space = singleton(&(v4_12_head));
    let v5_3: Space = intersect(&(*CONSTANT_1),&(v5_2));
    let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
    drop(v5_3);
    let v5_5: Space = subtract(&(*CONSTANT_0),&(v5_4));
    drop(v5_4);
    let v5_8: Space = if (v5_5).is_empty() { Space::new() } else {
      let v6_6: Path = concat_path(&(*p0),&(v4_12_head));
      let mut v6_7 = Space::new();
      let mut v6_7_cursor = (v4_12_tail).read_zipper();
      for v6_7_byte in v6_7_cursor.child_mask().iter() {
        v6_7_cursor.descend_to_byte(v6_7_byte);
        let v6_7_tail = v6_7_cursor.make_map();
        v6_7_cursor.ascend(1);
        let v6_7_head = Path::from_slice(&[v6_7_byte]);
        let v7_2: Space = singleton(&(v6_7_head));
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v6_6),&(v6_7_head));
          let v8_7: Space = routine_3(c, &(v8_6), &(v6_7_tail), &(*s1));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v6_6),&(v6_7_head));
          let v9_11: Space = routine_4(c, &(v9_6), &(v6_7_tail), &(*s1));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_7.join_into((v7_13).clone());
      }
      drop(v6_7_cursor);
      compose(&(v5_5),&(v6_7))
    };
    drop(v5_5);
    let v5_9: Space = intersect(&(*CONSTANT_1),&(v5_2));
    drop(v5_2);
    let v5_10: Space = if has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
    drop(v5_9);
    let v5_12: Space = if (v5_10).is_empty() { Space::new() } else {
      let v10_6: Path = concat_path(&(*p0),&(v4_12_head));
      let mut v10_11 = Space::new();
      let mut v10_11_cursor = (v4_12_tail).read_zipper();
      for v10_11_byte in v10_11_cursor.child_mask().iter() {
        v10_11_cursor.descend_to_byte(v10_11_byte);
        let v10_11_tail = v10_11_cursor.make_map();
        v10_11_cursor.ascend(1);
        let v10_11_head = Path::from_slice(&[v10_11_byte]);
        let v11_2: Space = singleton(&(v10_11_head));
        let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
        let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
        drop(v11_3);
        let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
        drop(v11_4);
        let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
          let v12_6: Path = concat_path(&(v10_6),&(v10_11_head));
          let v12_7: Space = routine_3(c, &(v12_6), &(v10_11_tail), &(*s1));
          compose(&(v11_5),&(v12_7))
        };
        drop(v11_5);
        let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
        drop(v11_2);
        let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
        drop(v11_9);
        let v11_12: Space = if (v11_10).is_empty() { Space::new() } else {
          let v13_6: Path = concat_path(&(v10_6),&(v10_11_head));
          let v13_11: Space = routine_5(c, &(v13_6), &(v10_11_tail), &(*s1));
          drop(v13_6);
          compose(&(v11_10),&(v13_11))
        };
        drop(v11_10);
        let v11_13: Space = unite(&(v11_8),&(v11_12));
        v10_11.join_into((v11_13).clone());
      }
      drop(v10_11_cursor);
      drop(v10_6);
      compose(&(v5_10),&(v10_11))
    };
    drop(v5_10);
    let v5_13: Space = unite(&(v5_8),&(v5_12));
    v4_12.join_into((v5_13).clone());
  }
  drop(v4_12_cursor);
  (v4_12).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v14_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v14_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v14_10: Space = unwrap(&(v14_9),&(*p0));
  let v14_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v14_22 = Space::new();
  let mut v14_22_cursor = (*s0).read_zipper();
  for v14_22_byte in v14_22_cursor.child_mask().iter() {
    v14_22_cursor.descend_to_byte(v14_22_byte);
    let v14_22_tail = v14_22_cursor.make_map();
    v14_22_cursor.ascend(1);
    let v14_22_head = Path::from_slice(&[v14_22_byte]);
    let v15_2: Space = singleton(&(v14_22_head));
    let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
    let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
    drop(v15_3);
    let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
    drop(v15_4);
    let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v14_22_head));
      let mut v16_7 = Space::new();
      let mut v16_7_cursor = (v14_22_tail).read_zipper();
      for v16_7_byte in v16_7_cursor.child_mask().iter() {
        v16_7_cursor.descend_to_byte(v16_7_byte);
        let v16_7_tail = v16_7_cursor.make_map();
        v16_7_cursor.ascend(1);
        let v16_7_head = Path::from_slice(&[v16_7_byte]);
        let v17_2: Space = singleton(&(v16_7_head));
        let v17_3: Space = intersect(&(*CONSTANT_1),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
        drop(v17_4);
        let v17_8: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v16_6),&(v16_7_head));
          let v18_7: Space = routine_3(c, &(v18_6), &(v16_7_tail), &(*s1));
          compose(&(v17_5),&(v18_7))
        };
        drop(v17_5);
        let v17_9: Space = intersect(&(*CONSTANT_1),&(v17_2));
        drop(v17_2);
        let v17_10: Space = if has_head(&(v17_9)) { singleton(&[]) } else { Space::new() };
        drop(v17_9);
        let v17_12: Space = if (v17_10).is_empty() { Space::new() } else {
          let v19_6: Path = concat_path(&(v16_6),&(v16_7_head));
          let v19_11: Space = routine_4(c, &(v19_6), &(v16_7_tail), &(*s1));
          drop(v19_6);
          compose(&(v17_10),&(v19_11))
        };
        drop(v17_10);
        let v17_13: Space = unite(&(v17_8),&(v17_12));
        v16_7.join_into((v17_13).clone());
      }
      drop(v16_7_cursor);
      compose(&(v15_5),&(v16_7))
    };
    drop(v15_5);
    let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
    drop(v15_2);
    let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
    drop(v15_9);
    let v15_18: Space = if (v15_10).is_empty() { Space::new() } else {
      let v20_11: Space = unwrap(&(v14_10),&(v14_22_head));
      let v20_12: Space = restrict_to(&(v14_9),&(v20_11));
      let mut v20_13 = Space::new();
      let mut v20_13_cursor = (v20_12).read_zipper();
      for v20_13_byte in v20_13_cursor.child_mask().iter() {
        v20_13_cursor.descend_to_byte(v20_13_byte);
        let v20_13_tail = v20_13_cursor.make_map();
        v20_13_cursor.ascend(1);
        let v20_13_head = Path::from_slice(&[v20_13_byte]);
        let v21_2: Space = singleton(&(v20_13_head));
        let v21_3: Space = intersect(&(*CONSTANT_1),&(v21_2));
        let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
        drop(v21_3);
        let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
        drop(v21_4);
        let v21_7: Space = if (v21_5).is_empty() { Space::new() } else {
          let v22_6: Space = routine_6(c, &(v20_13_head), &(v20_13_tail));
          compose(&(v21_5),&(v22_6))
        };
        drop(v21_5);
        let v21_8: Space = intersect(&(*CONSTANT_1),&(v21_2));
        drop(v21_2);
        let v21_9: Space = if has_head(&(v21_8)) { singleton(&[]) } else { Space::new() };
        drop(v21_8);
        let v21_11: Space = if (v21_9).is_empty() { Space::new() } else {
          let v23_10: Space = routine_7(c, &(v20_13_head), &(v20_13_tail));
          compose(&(v21_9),&(v23_10))
        };
        drop(v21_9);
        let v21_12: Space = unite(&(v21_7),&(v21_11));
        v20_13.join_into((v21_12).clone());
      }
      drop(v20_13_cursor);
      drop(v20_12);
      let v20_14: Space = restrict_to(&(v14_7),&(v20_13));
      let mut v20_15 = Space::new();
      let mut v20_15_cursor = (v20_14).read_zipper();
      for v20_15_byte in v20_15_cursor.child_mask().iter() {
        v20_15_cursor.descend_to_byte(v20_15_byte);
        let v20_15_tail = v20_15_cursor.make_map();
        v20_15_cursor.ascend(1);
        let v20_15_head = Path::from_slice(&[v20_15_byte]);
        let v24_2: Space = singleton(&(v20_15_head));
        let v24_3: Space = intersect(&(*CONSTANT_1),&(v24_2));
        let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
        drop(v24_3);
        let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
        drop(v24_4);
        let v24_7: Space = if (v24_5).is_empty() { Space::new() } else {
          let v25_6: Space = routine_8(c, &(v20_15_head), &(v20_15_tail));
          compose(&(v24_5),&(v25_6))
        };
        drop(v24_5);
        let v24_8: Space = intersect(&(*CONSTANT_1),&(v24_2));
        drop(v24_2);
        let v24_9: Space = if has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
        drop(v24_8);
        let v24_11: Space = if (v24_9).is_empty() { Space::new() } else {
          let v26_10: Space = routine_9(c, &(v20_15_head), &(v20_15_tail));
          compose(&(v24_9),&(v26_10))
        };
        drop(v24_9);
        let v24_12: Space = unite(&(v24_7),&(v24_11));
        v20_15.join_into((v24_12).clone());
      }
      drop(v20_15_cursor);
      let v20_16: Space = subtract(&(v20_15),&(v20_11));
      drop(v20_11);
      let v20_17: Space = intersect(&(v20_16),&(v14_12));
      compose(&(v15_10),&(v20_17))
    };
    drop(v15_10);
    let v27_6: Path = concat_path(&(*p0),&(v14_22_head));
    let v15_19: Space = wrap(&(v15_18),&(v27_6));
    let v15_20: Space = unite(&(v15_8),&(v15_19));
    v14_22.join_into((v15_20).clone());
  }
  drop(v14_22_cursor);
  drop(v14_7);
  drop(v14_9);
  drop(v14_10);
  drop(v14_12);
  (v14_22).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v28_12 = Space::new();
  let mut v28_12_cursor = (*s0).read_zipper();
  for v28_12_byte in v28_12_cursor.child_mask().iter() {
    v28_12_cursor.descend_to_byte(v28_12_byte);
    let v28_12_tail = v28_12_cursor.make_map();
    v28_12_cursor.ascend(1);
    let v28_12_head = Path::from_slice(&[v28_12_byte]);
    let v29_2: Space = singleton(&(v28_12_head));
    let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
    let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
    drop(v29_3);
    let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
    drop(v29_4);
    let v29_8: Space = if (v29_5).is_empty() { Space::new() } else {
      let v30_6: Path = concat_path(&(*p0),&(v28_12_head));
      let mut v30_7 = Space::new();
      let mut v30_7_cursor = (v28_12_tail).read_zipper();
      for v30_7_byte in v30_7_cursor.child_mask().iter() {
        v30_7_cursor.descend_to_byte(v30_7_byte);
        let v30_7_tail = v30_7_cursor.make_map();
        v30_7_cursor.ascend(1);
        let v30_7_head = Path::from_slice(&[v30_7_byte]);
        let v31_2: Space = singleton(&(v30_7_head));
        let v31_3: Space = intersect(&(*CONSTANT_1),&(v31_2));
        let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
        drop(v31_3);
        let v31_5: Space = subtract(&(*CONSTANT_0),&(v31_4));
        drop(v31_4);
        let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
          let v32_6: Path = concat_path(&(v30_6),&(v30_7_head));
          let v32_7: Space = routine_10(c, &(v32_6), &(v30_7_tail), &(*s1));
          compose(&(v31_5),&(v32_7))
        };
        drop(v31_5);
        let v31_9: Space = intersect(&(*CONSTANT_1),&(v31_2));
        drop(v31_2);
        let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
        drop(v31_9);
        let v31_12: Space = if (v31_10).is_empty() { Space::new() } else {
          let v33_6: Path = concat_path(&(v30_6),&(v30_7_head));
          let v33_11: Space = routine_11(c, &(v33_6), &(v30_7_tail), &(*s1));
          drop(v33_6);
          compose(&(v31_10),&(v33_11))
        };
        drop(v31_10);
        let v31_13: Space = unite(&(v31_8),&(v31_12));
        v30_7.join_into((v31_13).clone());
      }
      drop(v30_7_cursor);
      compose(&(v29_5),&(v30_7))
    };
    drop(v29_5);
    let v29_9: Space = intersect(&(*CONSTANT_1),&(v29_2));
    drop(v29_2);
    let v29_10: Space = if has_head(&(v29_9)) { singleton(&[]) } else { Space::new() };
    drop(v29_9);
    let v29_12: Space = if (v29_10).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&(v28_12_head));
      let mut v34_11 = Space::new();
      let mut v34_11_cursor = (v28_12_tail).read_zipper();
      for v34_11_byte in v34_11_cursor.child_mask().iter() {
        v34_11_cursor.descend_to_byte(v34_11_byte);
        let v34_11_tail = v34_11_cursor.make_map();
        v34_11_cursor.ascend(1);
        let v34_11_head = Path::from_slice(&[v34_11_byte]);
        let v35_2: Space = singleton(&(v34_11_head));
        let v35_3: Space = intersect(&(*CONSTANT_1),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_0),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (v35_5).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let v36_7: Space = routine_10(c, &(v36_6), &(v34_11_tail), &(*s1));
          compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = intersect(&(*CONSTANT_1),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (v35_10).is_empty() { Space::new() } else {
          let v37_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let v37_11: Space = routine_5(c, &(v37_6), &(v34_11_tail), &(*s1));
          drop(v37_6);
          compose(&(v35_10),&(v37_11))
        };
        drop(v35_10);
        let v35_13: Space = unite(&(v35_8),&(v35_12));
        v34_11.join_into((v35_13).clone());
      }
      drop(v34_11_cursor);
      drop(v34_6);
      compose(&(v29_10),&(v34_11))
    };
    drop(v29_10);
    let v29_13: Space = unite(&(v29_8),&(v29_12));
    v28_12.join_into((v29_13).clone());
  }
  drop(v28_12_cursor);
  (v28_12).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v38_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v38_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v38_10: Space = unwrap(&(v38_9),&(*p0));
  let v38_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v38_22 = Space::new();
  let mut v38_22_cursor = (*s0).read_zipper();
  for v38_22_byte in v38_22_cursor.child_mask().iter() {
    v38_22_cursor.descend_to_byte(v38_22_byte);
    let v38_22_tail = v38_22_cursor.make_map();
    v38_22_cursor.ascend(1);
    let v38_22_head = Path::from_slice(&[v38_22_byte]);
    let v39_2: Space = singleton(&(v38_22_head));
    let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
    let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
    drop(v39_3);
    let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
    drop(v39_4);
    let v39_8: Space = if (v39_5).is_empty() { Space::new() } else {
      let v40_6: Path = concat_path(&(*p0),&(v38_22_head));
      let mut v40_7 = Space::new();
      let mut v40_7_cursor = (v38_22_tail).read_zipper();
      for v40_7_byte in v40_7_cursor.child_mask().iter() {
        v40_7_cursor.descend_to_byte(v40_7_byte);
        let v40_7_tail = v40_7_cursor.make_map();
        v40_7_cursor.ascend(1);
        let v40_7_head = Path::from_slice(&[v40_7_byte]);
        let v41_2: Space = singleton(&(v40_7_head));
        let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
        let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
        drop(v41_3);
        let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
        drop(v41_4);
        let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
          let v42_6: Path = concat_path(&(v40_6),&(v40_7_head));
          let v42_7: Space = routine_10(c, &(v42_6), &(v40_7_tail), &(*s1));
          compose(&(v41_5),&(v42_7))
        };
        drop(v41_5);
        let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
        drop(v41_2);
        let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
        drop(v41_9);
        let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
          let v43_6: Path = concat_path(&(v40_6),&(v40_7_head));
          let v43_11: Space = routine_11(c, &(v43_6), &(v40_7_tail), &(*s1));
          drop(v43_6);
          compose(&(v41_10),&(v43_11))
        };
        drop(v41_10);
        let v41_13: Space = unite(&(v41_8),&(v41_12));
        v40_7.join_into((v41_13).clone());
      }
      drop(v40_7_cursor);
      compose(&(v39_5),&(v40_7))
    };
    drop(v39_5);
    let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
    drop(v39_2);
    let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
    drop(v39_9);
    let v39_18: Space = if (v39_10).is_empty() { Space::new() } else {
      let v44_11: Space = unwrap(&(v38_10),&(v38_22_head));
      let v44_12: Space = restrict_to(&(v38_9),&(v44_11));
      let mut v44_13 = Space::new();
      let mut v44_13_cursor = (v44_12).read_zipper();
      for v44_13_byte in v44_13_cursor.child_mask().iter() {
        v44_13_cursor.descend_to_byte(v44_13_byte);
        let v44_13_tail = v44_13_cursor.make_map();
        v44_13_cursor.ascend(1);
        let v44_13_head = Path::from_slice(&[v44_13_byte]);
        let v45_2: Space = singleton(&(v44_13_head));
        let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
        let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
        drop(v45_3);
        let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
        drop(v45_4);
        let v45_7: Space = if (v45_5).is_empty() { Space::new() } else {
          let v46_6: Space = routine_6(c, &(v44_13_head), &(v44_13_tail));
          compose(&(v45_5),&(v46_6))
        };
        drop(v45_5);
        let v45_8: Space = intersect(&(*CONSTANT_1),&(v45_2));
        drop(v45_2);
        let v45_9: Space = if has_head(&(v45_8)) { singleton(&[]) } else { Space::new() };
        drop(v45_8);
        let v45_11: Space = if (v45_9).is_empty() { Space::new() } else {
          let v47_10: Space = routine_7(c, &(v44_13_head), &(v44_13_tail));
          compose(&(v45_9),&(v47_10))
        };
        drop(v45_9);
        let v45_12: Space = unite(&(v45_7),&(v45_11));
        v44_13.join_into((v45_12).clone());
      }
      drop(v44_13_cursor);
      drop(v44_12);
      let v44_14: Space = restrict_to(&(v38_7),&(v44_13));
      let mut v44_15 = Space::new();
      let mut v44_15_cursor = (v44_14).read_zipper();
      for v44_15_byte in v44_15_cursor.child_mask().iter() {
        v44_15_cursor.descend_to_byte(v44_15_byte);
        let v44_15_tail = v44_15_cursor.make_map();
        v44_15_cursor.ascend(1);
        let v44_15_head = Path::from_slice(&[v44_15_byte]);
        let v48_2: Space = singleton(&(v44_15_head));
        let v48_3: Space = intersect(&(*CONSTANT_1),&(v48_2));
        let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
        drop(v48_3);
        let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
        drop(v48_4);
        let v48_7: Space = if (v48_5).is_empty() { Space::new() } else {
          let v49_6: Space = routine_8(c, &(v44_15_head), &(v44_15_tail));
          compose(&(v48_5),&(v49_6))
        };
        drop(v48_5);
        let v48_8: Space = intersect(&(*CONSTANT_1),&(v48_2));
        drop(v48_2);
        let v48_9: Space = if has_head(&(v48_8)) { singleton(&[]) } else { Space::new() };
        drop(v48_8);
        let v48_11: Space = if (v48_9).is_empty() { Space::new() } else {
          let v50_10: Space = routine_9(c, &(v44_15_head), &(v44_15_tail));
          compose(&(v48_9),&(v50_10))
        };
        drop(v48_9);
        let v48_12: Space = unite(&(v48_7),&(v48_11));
        v44_15.join_into((v48_12).clone());
      }
      drop(v44_15_cursor);
      let v44_16: Space = subtract(&(v44_15),&(v44_11));
      drop(v44_11);
      let v44_17: Space = intersect(&(v44_16),&(v38_12));
      compose(&(v39_10),&(v44_17))
    };
    drop(v39_10);
    let v51_6: Path = concat_path(&(*p0),&(v38_22_head));
    let v39_19: Space = wrap(&(v39_18),&(v51_6));
    let v39_20: Space = unite(&(v39_8),&(v39_19));
    v38_22.join_into((v39_20).clone());
  }
  drop(v38_22_cursor);
  drop(v38_7);
  drop(v38_9);
  drop(v38_10);
  drop(v38_12);
  (v38_22).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v52_4: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v52_6: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v52_7: Space = unwrap(&(v52_6),&(*p0));
  let v52_8: Space = restrict_to(&(v52_6),&(v52_7));
  drop(v52_6);
  let mut v52_18 = Space::new();
  let mut v52_18_cursor = (v52_8).read_zipper();
  for v52_18_byte in v52_18_cursor.child_mask().iter() {
    v52_18_cursor.descend_to_byte(v52_18_byte);
    let v52_18_tail = v52_18_cursor.make_map();
    v52_18_cursor.ascend(1);
    let v52_18_head = Path::from_slice(&[v52_18_byte]);
    let v53_2: Space = singleton(&(v52_18_head));
    let v53_3: Space = intersect(&(*CONSTANT_1),&(v53_2));
    let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
    drop(v53_3);
    let v53_5: Space = subtract(&(*CONSTANT_0),&(v53_4));
    drop(v53_4);
    let v53_7: Space = if (v53_5).is_empty() { Space::new() } else {
      let mut v54_6 = Space::new();
      let mut v54_6_cursor = (v52_18_tail).read_zipper();
      for v54_6_byte in v54_6_cursor.child_mask().iter() {
        v54_6_cursor.descend_to_byte(v54_6_byte);
        let v54_6_tail = v54_6_cursor.make_map();
        v54_6_cursor.ascend(1);
        let v54_6_head = Path::from_slice(&[v54_6_byte]);
        let v55_2: Space = singleton(&(v54_6_head));
        let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
        let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
        drop(v55_3);
        let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
        drop(v55_4);
        let v55_8: Space = if (v55_5).is_empty() { Space::new() } else {
          let v56_6: Path = concat_path(&(v52_18_head),&(v54_6_head));
          let v56_7: Space = routine_12(c, &(v56_6), &(v54_6_tail));
          compose(&(v55_5),&(v56_7))
        };
        drop(v55_5);
        let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
        drop(v55_2);
        let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
        drop(v55_9);
        let v55_12: Space = if (v55_10).is_empty() { Space::new() } else {
          let v57_6: Path = concat_path(&(v52_18_head),&(v54_6_head));
          let v57_11: Space = routine_13(c, &(v57_6), &(v54_6_tail));
          drop(v57_6);
          compose(&(v55_10),&(v57_11))
        };
        drop(v55_10);
        let v55_13: Space = unite(&(v55_8),&(v55_12));
        v54_6.join_into((v55_13).clone());
      }
      drop(v54_6_cursor);
      compose(&(v53_5),&(v54_6))
    };
    drop(v53_5);
    let v53_8: Space = intersect(&(*CONSTANT_1),&(v53_2));
    drop(v53_2);
    let v53_9: Space = if has_head(&(v53_8)) { singleton(&[]) } else { Space::new() };
    drop(v53_8);
    let v53_11: Space = if (v53_9).is_empty() { Space::new() } else {
      let mut v58_10 = Space::new();
      let mut v58_10_cursor = (v52_18_tail).read_zipper();
      for v58_10_byte in v58_10_cursor.child_mask().iter() {
        v58_10_cursor.descend_to_byte(v58_10_byte);
        let v58_10_tail = v58_10_cursor.make_map();
        v58_10_cursor.ascend(1);
        let v58_10_head = Path::from_slice(&[v58_10_byte]);
        let v59_2: Space = singleton(&(v58_10_head));
        let v59_3: Space = intersect(&(*CONSTANT_1),&(v59_2));
        let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
        drop(v59_3);
        let v59_5: Space = subtract(&(*CONSTANT_0),&(v59_4));
        drop(v59_4);
        let v59_8: Space = if (v59_5).is_empty() { Space::new() } else {
          let v60_6: Path = concat_path(&(v52_18_head),&(v58_10_head));
          let v60_7: Space = routine_12(c, &(v60_6), &(v58_10_tail));
          compose(&(v59_5),&(v60_7))
        };
        drop(v59_5);
        let v59_9: Space = intersect(&(*CONSTANT_1),&(v59_2));
        drop(v59_2);
        let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
        drop(v59_9);
        let v59_12: Space = if (v59_10).is_empty() { Space::new() } else {
          let v61_6: Path = concat_path(&(v52_18_head),&(v58_10_head));
          let v61_11: Space = routine_14(c, &(v61_6), &(v58_10_tail));
          drop(v61_6);
          compose(&(v59_10),&(v61_11))
        };
        drop(v59_10);
        let v59_13: Space = unite(&(v59_8),&(v59_12));
        v58_10.join_into((v59_13).clone());
      }
      drop(v58_10_cursor);
      compose(&(v53_9),&(v58_10))
    };
    drop(v53_9);
    let v53_12: Space = unite(&(v53_7),&(v53_11));
    v52_18.join_into((v53_12).clone());
  }
  drop(v52_18_cursor);
  drop(v52_8);
  let v52_19: Space = restrict_to(&(v52_4),&(v52_18));
  drop(v52_4);
  let mut v52_29 = Space::new();
  let mut v52_29_cursor = (v52_19).read_zipper();
  for v52_29_byte in v52_29_cursor.child_mask().iter() {
    v52_29_cursor.descend_to_byte(v52_29_byte);
    let v52_29_tail = v52_29_cursor.make_map();
    v52_29_cursor.ascend(1);
    let v52_29_head = Path::from_slice(&[v52_29_byte]);
    let v62_2: Space = singleton(&(v52_29_head));
    let v62_3: Space = intersect(&(*CONSTANT_1),&(v62_2));
    let v62_4: Space = if has_head(&(v62_3)) { singleton(&[]) } else { Space::new() };
    drop(v62_3);
    let v62_5: Space = subtract(&(*CONSTANT_0),&(v62_4));
    drop(v62_4);
    let v62_7: Space = if (v62_5).is_empty() { Space::new() } else {
      let mut v63_6 = Space::new();
      let mut v63_6_cursor = (v52_29_tail).read_zipper();
      for v63_6_byte in v63_6_cursor.child_mask().iter() {
        v63_6_cursor.descend_to_byte(v63_6_byte);
        let v63_6_tail = v63_6_cursor.make_map();
        v63_6_cursor.ascend(1);
        let v63_6_head = Path::from_slice(&[v63_6_byte]);
        let v64_2: Space = singleton(&(v63_6_head));
        let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
        let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
        drop(v64_3);
        let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
        drop(v64_4);
        let v64_8: Space = if (v64_5).is_empty() { Space::new() } else {
          let v65_6: Path = concat_path(&(v52_29_head),&(v63_6_head));
          let v65_7: Space = routine_15(c, &(v65_6), &(v63_6_tail));
          compose(&(v64_5),&(v65_7))
        };
        drop(v64_5);
        let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
        drop(v64_2);
        let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
        drop(v64_9);
        let v64_12: Space = if (v64_10).is_empty() { Space::new() } else {
          let v66_6: Path = concat_path(&(v52_29_head),&(v63_6_head));
          let v66_11: Space = routine_16(c, &(v66_6), &(v63_6_tail));
          drop(v66_6);
          compose(&(v64_10),&(v66_11))
        };
        drop(v64_10);
        let v64_13: Space = unite(&(v64_8),&(v64_12));
        v63_6.join_into((v64_13).clone());
      }
      drop(v63_6_cursor);
      compose(&(v62_5),&(v63_6))
    };
    drop(v62_5);
    let v62_8: Space = intersect(&(*CONSTANT_1),&(v62_2));
    drop(v62_2);
    let v62_9: Space = if has_head(&(v62_8)) { singleton(&[]) } else { Space::new() };
    drop(v62_8);
    let v62_11: Space = if (v62_9).is_empty() { Space::new() } else {
      let mut v67_10 = Space::new();
      let mut v67_10_cursor = (v52_29_tail).read_zipper();
      for v67_10_byte in v67_10_cursor.child_mask().iter() {
        v67_10_cursor.descend_to_byte(v67_10_byte);
        let v67_10_tail = v67_10_cursor.make_map();
        v67_10_cursor.ascend(1);
        let v67_10_head = Path::from_slice(&[v67_10_byte]);
        let v68_2: Space = singleton(&(v67_10_head));
        let v68_3: Space = intersect(&(*CONSTANT_1),&(v68_2));
        let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
        drop(v68_3);
        let v68_5: Space = subtract(&(*CONSTANT_0),&(v68_4));
        drop(v68_4);
        let v68_8: Space = if (v68_5).is_empty() { Space::new() } else {
          let v69_6: Path = concat_path(&(v52_29_head),&(v67_10_head));
          let v69_7: Space = routine_15(c, &(v69_6), &(v67_10_tail));
          compose(&(v68_5),&(v69_7))
        };
        drop(v68_5);
        let v68_9: Space = intersect(&(*CONSTANT_1),&(v68_2));
        drop(v68_2);
        let v68_10: Space = if has_head(&(v68_9)) { singleton(&[]) } else { Space::new() };
        drop(v68_9);
        let v68_12: Space = if (v68_10).is_empty() { Space::new() } else {
          let v70_6: Path = concat_path(&(v52_29_head),&(v67_10_head));
          let v70_11: Space = routine_17(c, &(v70_6), &(v67_10_tail));
          drop(v70_6);
          compose(&(v68_10),&(v70_11))
        };
        drop(v68_10);
        let v68_13: Space = unite(&(v68_8),&(v68_12));
        v67_10.join_into((v68_13).clone());
      }
      drop(v67_10_cursor);
      compose(&(v62_9),&(v67_10))
    };
    drop(v62_9);
    let v62_12: Space = unite(&(v62_7),&(v62_11));
    v52_29.join_into((v62_12).clone());
  }
  drop(v52_29_cursor);
  let v52_30: Space = subtract(&(v52_29),&(v52_7));
  drop(v52_7);
  let v52_32: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let v52_33: Space = intersect(&(v52_30),&(v52_32));
  drop(v52_32);
  let v52_34: Space = wrap(&(v52_33),&(*p0));
  (v52_34).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v71_11 = Space::new();
  let mut v71_11_cursor = (*s0).read_zipper();
  for v71_11_byte in v71_11_cursor.child_mask().iter() {
    v71_11_cursor.descend_to_byte(v71_11_byte);
    let v71_11_tail = v71_11_cursor.make_map();
    v71_11_cursor.ascend(1);
    let v71_11_head = Path::from_slice(&[v71_11_byte]);
    let v72_2: Space = singleton(&(v71_11_head));
    let v72_3: Space = intersect(&(*CONSTANT_1),&(v72_2));
    let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
    drop(v72_3);
    let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
    drop(v72_4);
    let v72_8: Space = if (v72_5).is_empty() { Space::new() } else {
      let v73_6: Path = concat_path(&(*p0),&(v71_11_head));
      let mut v73_7 = Space::new();
      let mut v73_7_cursor = (v71_11_tail).read_zipper();
      for v73_7_byte in v73_7_cursor.child_mask().iter() {
        v73_7_cursor.descend_to_byte(v73_7_byte);
        let v73_7_tail = v73_7_cursor.make_map();
        v73_7_cursor.ascend(1);
        let v73_7_head = Path::from_slice(&[v73_7_byte]);
        let v74_2: Space = singleton(&(v73_7_head));
        let v74_3: Space = intersect(&(*CONSTANT_1),&(v74_2));
        let v74_4: Space = if has_head(&(v74_3)) { singleton(&[]) } else { Space::new() };
        drop(v74_3);
        let v74_5: Space = subtract(&(*CONSTANT_0),&(v74_4));
        drop(v74_4);
        let v74_8: Space = if (v74_5).is_empty() { Space::new() } else {
          let v75_6: Path = concat_path(&(v73_6),&(v73_7_head));
          let v75_7: Space = routine_18(c, &(v75_6), &(v73_7_tail));
          compose(&(v74_5),&(v75_7))
        };
        drop(v74_5);
        let v74_9: Space = intersect(&(*CONSTANT_1),&(v74_2));
        drop(v74_2);
        let v74_10: Space = if has_head(&(v74_9)) { singleton(&[]) } else { Space::new() };
        drop(v74_9);
        let v74_12: Space = if (v74_10).is_empty() { Space::new() } else {
          let v76_6: Path = concat_path(&(v73_6),&(v73_7_head));
          let v76_11: Space = routine_19(c, &(v76_6), &(v73_7_tail));
          drop(v76_6);
          compose(&(v74_10),&(v76_11))
        };
        drop(v74_10);
        let v74_13: Space = unite(&(v74_8),&(v74_12));
        v73_7.join_into((v74_13).clone());
      }
      drop(v73_7_cursor);
      compose(&(v72_5),&(v73_7))
    };
    drop(v72_5);
    let v72_9: Space = intersect(&(*CONSTANT_1),&(v72_2));
    drop(v72_2);
    let v72_10: Space = if has_head(&(v72_9)) { singleton(&[]) } else { Space::new() };
    drop(v72_9);
    let v72_12: Space = if (v72_10).is_empty() { Space::new() } else {
      let v77_6: Path = concat_path(&(*p0),&(v71_11_head));
      let mut v77_11 = Space::new();
      let mut v77_11_cursor = (v71_11_tail).read_zipper();
      for v77_11_byte in v77_11_cursor.child_mask().iter() {
        v77_11_cursor.descend_to_byte(v77_11_byte);
        let v77_11_tail = v77_11_cursor.make_map();
        v77_11_cursor.ascend(1);
        let v77_11_head = Path::from_slice(&[v77_11_byte]);
        let v78_2: Space = singleton(&(v77_11_head));
        let v78_3: Space = intersect(&(*CONSTANT_1),&(v78_2));
        let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
        drop(v78_3);
        let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
        drop(v78_4);
        let v78_8: Space = if (v78_5).is_empty() { Space::new() } else {
          let v79_6: Path = concat_path(&(v77_6),&(v77_11_head));
          let v79_7: Space = routine_18(c, &(v79_6), &(v77_11_tail));
          compose(&(v78_5),&(v79_7))
        };
        drop(v78_5);
        let v78_9: Space = intersect(&(*CONSTANT_1),&(v78_2));
        drop(v78_2);
        let v78_10: Space = if has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
        drop(v78_9);
        let v78_12: Space = if (v78_10).is_empty() { Space::new() } else {
          let v80_6: Path = concat_path(&(v77_6),&(v77_11_head));
          let v80_11: Space = routine_14(c, &(v80_6), &(v77_11_tail));
          drop(v80_6);
          compose(&(v78_10),&(v80_11))
        };
        drop(v78_10);
        let v78_13: Space = unite(&(v78_8),&(v78_12));
        v77_11.join_into((v78_13).clone());
      }
      drop(v77_11_cursor);
      drop(v77_6);
      compose(&(v72_10),&(v77_11))
    };
    drop(v72_10);
    let v72_13: Space = unite(&(v72_8),&(v72_12));
    v71_11.join_into((v72_13).clone());
  }
  drop(v71_11_cursor);
  (v71_11).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v81_8 = Space::new();
  let mut v81_8_cursor = (*s0).read_zipper();
  for v81_8_byte in v81_8_cursor.child_mask().iter() {
    v81_8_cursor.descend_to_byte(v81_8_byte);
    let v81_8_tail = v81_8_cursor.make_map();
    v81_8_cursor.ascend(1);
    let v81_8_head = Path::from_slice(&[v81_8_byte]);
    let v82_2: Space = singleton(&(v81_8_head));
    let v82_3: Space = intersect(&(*CONSTANT_1),&(v82_2));
    let v82_4: Space = if has_head(&(v82_3)) { singleton(&[]) } else { Space::new() };
    drop(v82_3);
    let v82_5: Space = subtract(&(*CONSTANT_0),&(v82_4));
    drop(v82_4);
    let v82_8: Space = if (v82_5).is_empty() { Space::new() } else {
      let v83_6: Path = concat_path(&(*p0),&(v81_8_head));
      let mut v83_7 = Space::new();
      let mut v83_7_cursor = (v81_8_tail).read_zipper();
      for v83_7_byte in v83_7_cursor.child_mask().iter() {
        v83_7_cursor.descend_to_byte(v83_7_byte);
        let v83_7_tail = v83_7_cursor.make_map();
        v83_7_cursor.ascend(1);
        let v83_7_head = Path::from_slice(&[v83_7_byte]);
        let v84_2: Space = singleton(&(v83_7_head));
        let v84_3: Space = intersect(&(*CONSTANT_1),&(v84_2));
        let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
        drop(v84_3);
        let v84_5: Space = subtract(&(*CONSTANT_0),&(v84_4));
        drop(v84_4);
        let v84_8: Space = if (v84_5).is_empty() { Space::new() } else {
          let v85_6: Path = concat_path(&(v83_6),&(v83_7_head));
          let v85_7: Space = routine_18(c, &(v85_6), &(v83_7_tail));
          compose(&(v84_5),&(v85_7))
        };
        drop(v84_5);
        let v84_9: Space = intersect(&(*CONSTANT_1),&(v84_2));
        drop(v84_2);
        let v84_10: Space = if has_head(&(v84_9)) { singleton(&[]) } else { Space::new() };
        drop(v84_9);
        let v84_12: Space = if (v84_10).is_empty() { Space::new() } else {
          let v86_6: Path = concat_path(&(v83_6),&(v83_7_head));
          let v86_11: Space = routine_19(c, &(v86_6), &(v83_7_tail));
          drop(v86_6);
          compose(&(v84_10),&(v86_11))
        };
        drop(v84_10);
        let v84_13: Space = unite(&(v84_8),&(v84_12));
        v83_7.join_into((v84_13).clone());
      }
      drop(v83_7_cursor);
      drop(v83_6);
      compose(&(v82_5),&(v83_7))
    };
    drop(v82_5);
    let v82_9: Space = intersect(&(*CONSTANT_1),&(v82_2));
    drop(v82_2);
    let v82_10: Space = if has_head(&(v82_9)) { singleton(&[]) } else { Space::new() };
    drop(v82_9);
    let v82_11: Space = compose(&(v82_10),&(v81_8_tail));
    drop(v82_10);
    let v82_12: Space = unite(&(v82_8),&(v82_11));
    drop(v82_11);
    v81_8.join_into((v82_12).clone());
  }
  drop(v81_8_cursor);
  (v81_8).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v87_11 = Space::new();
  let mut v87_11_cursor = (*s0).read_zipper();
  for v87_11_byte in v87_11_cursor.child_mask().iter() {
    v87_11_cursor.descend_to_byte(v87_11_byte);
    let v87_11_tail = v87_11_cursor.make_map();
    v87_11_cursor.ascend(1);
    let v87_11_head = Path::from_slice(&[v87_11_byte]);
    let v88_2: Space = singleton(&(v87_11_head));
    let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
    let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
    drop(v88_3);
    let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
    drop(v88_4);
    let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
      let v89_6: Path = concat_path(&(*p0),&(v87_11_head));
      let mut v89_7 = Space::new();
      let mut v89_7_cursor = (v87_11_tail).read_zipper();
      for v89_7_byte in v89_7_cursor.child_mask().iter() {
        v89_7_cursor.descend_to_byte(v89_7_byte);
        let v89_7_tail = v89_7_cursor.make_map();
        v89_7_cursor.ascend(1);
        let v89_7_head = Path::from_slice(&[v89_7_byte]);
        let v90_2: Space = singleton(&(v89_7_head));
        let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
        let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
        drop(v90_3);
        let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
        drop(v90_4);
        let v90_8: Space = if (v90_5).is_empty() { Space::new() } else {
          let v91_6: Path = concat_path(&(v89_6),&(v89_7_head));
          let v91_7: Space = routine_20(c, &(v91_6), &(v89_7_tail));
          compose(&(v90_5),&(v91_7))
        };
        drop(v90_5);
        let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
        drop(v90_2);
        let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
        drop(v90_9);
        let v90_12: Space = if (v90_10).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v89_6),&(v89_7_head));
          let v92_11: Space = routine_21(c, &(v92_6), &(v89_7_tail));
          drop(v92_6);
          compose(&(v90_10),&(v92_11))
        };
        drop(v90_10);
        let v90_13: Space = unite(&(v90_8),&(v90_12));
        v89_7.join_into((v90_13).clone());
      }
      drop(v89_7_cursor);
      compose(&(v88_5),&(v89_7))
    };
    drop(v88_5);
    let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
    drop(v88_2);
    let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
    drop(v88_9);
    let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
      let v93_6: Path = concat_path(&(*p0),&(v87_11_head));
      let mut v93_11 = Space::new();
      let mut v93_11_cursor = (v87_11_tail).read_zipper();
      for v93_11_byte in v93_11_cursor.child_mask().iter() {
        v93_11_cursor.descend_to_byte(v93_11_byte);
        let v93_11_tail = v93_11_cursor.make_map();
        v93_11_cursor.ascend(1);
        let v93_11_head = Path::from_slice(&[v93_11_byte]);
        let v94_2: Space = singleton(&(v93_11_head));
        let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
        let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
        drop(v94_3);
        let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
        drop(v94_4);
        let v94_8: Space = if (v94_5).is_empty() { Space::new() } else {
          let v95_6: Path = concat_path(&(v93_6),&(v93_11_head));
          let v95_7: Space = routine_20(c, &(v95_6), &(v93_11_tail));
          compose(&(v94_5),&(v95_7))
        };
        drop(v94_5);
        let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
        drop(v94_2);
        let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
        drop(v94_9);
        let v94_12: Space = if (v94_10).is_empty() { Space::new() } else {
          let v96_6: Path = concat_path(&(v93_6),&(v93_11_head));
          let v96_11: Space = routine_17(c, &(v96_6), &(v93_11_tail));
          drop(v96_6);
          compose(&(v94_10),&(v96_11))
        };
        drop(v94_10);
        let v94_13: Space = unite(&(v94_8),&(v94_12));
        v93_11.join_into((v94_13).clone());
      }
      drop(v93_11_cursor);
      drop(v93_6);
      compose(&(v88_10),&(v93_11))
    };
    drop(v88_10);
    let v88_13: Space = unite(&(v88_8),&(v88_12));
    v87_11.join_into((v88_13).clone());
  }
  drop(v87_11_cursor);
  (v87_11).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v97_8 = Space::new();
  let mut v97_8_cursor = (*s0).read_zipper();
  for v97_8_byte in v97_8_cursor.child_mask().iter() {
    v97_8_cursor.descend_to_byte(v97_8_byte);
    let v97_8_tail = v97_8_cursor.make_map();
    v97_8_cursor.ascend(1);
    let v97_8_head = Path::from_slice(&[v97_8_byte]);
    let v98_2: Space = singleton(&(v97_8_head));
    let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
    let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
    drop(v98_3);
    let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
    drop(v98_4);
    let v98_8: Space = if (v98_5).is_empty() { Space::new() } else {
      let v99_6: Path = concat_path(&(*p0),&(v97_8_head));
      let mut v99_7 = Space::new();
      let mut v99_7_cursor = (v97_8_tail).read_zipper();
      for v99_7_byte in v99_7_cursor.child_mask().iter() {
        v99_7_cursor.descend_to_byte(v99_7_byte);
        let v99_7_tail = v99_7_cursor.make_map();
        v99_7_cursor.ascend(1);
        let v99_7_head = Path::from_slice(&[v99_7_byte]);
        let v100_2: Space = singleton(&(v99_7_head));
        let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
        let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
        drop(v100_3);
        let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
        drop(v100_4);
        let v100_8: Space = if (v100_5).is_empty() { Space::new() } else {
          let v101_6: Path = concat_path(&(v99_6),&(v99_7_head));
          let v101_7: Space = routine_20(c, &(v101_6), &(v99_7_tail));
          compose(&(v100_5),&(v101_7))
        };
        drop(v100_5);
        let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
        drop(v100_2);
        let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
        drop(v100_9);
        let v100_12: Space = if (v100_10).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v99_6),&(v99_7_head));
          let v102_11: Space = routine_21(c, &(v102_6), &(v99_7_tail));
          drop(v102_6);
          compose(&(v100_10),&(v102_11))
        };
        drop(v100_10);
        let v100_13: Space = unite(&(v100_8),&(v100_12));
        v99_7.join_into((v100_13).clone());
      }
      drop(v99_7_cursor);
      drop(v99_6);
      compose(&(v98_5),&(v99_7))
    };
    drop(v98_5);
    let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
    drop(v98_2);
    let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
    drop(v98_9);
    let v98_11: Space = compose(&(v98_10),&(v97_8_tail));
    drop(v98_10);
    let v98_12: Space = unite(&(v98_8),&(v98_11));
    drop(v98_11);
    v97_8.join_into((v98_12).clone());
  }
  drop(v97_8_cursor);
  (v97_8).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v103_12 = Space::new();
  let mut v103_12_cursor = (*s0).read_zipper();
  for v103_12_byte in v103_12_cursor.child_mask().iter() {
    v103_12_cursor.descend_to_byte(v103_12_byte);
    let v103_12_tail = v103_12_cursor.make_map();
    v103_12_cursor.ascend(1);
    let v103_12_head = Path::from_slice(&[v103_12_byte]);
    let v104_2: Space = singleton(&(v103_12_head));
    let v104_3: Space = intersect(&(*CONSTANT_1),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_8: Space = if (v104_5).is_empty() { Space::new() } else {
      let v105_6: Path = concat_path(&(*p0),&(v103_12_head));
      let mut v105_7 = Space::new();
      let mut v105_7_cursor = (v103_12_tail).read_zipper();
      for v105_7_byte in v105_7_cursor.child_mask().iter() {
        v105_7_cursor.descend_to_byte(v105_7_byte);
        let v105_7_tail = v105_7_cursor.make_map();
        v105_7_cursor.ascend(1);
        let v105_7_head = Path::from_slice(&[v105_7_byte]);
        let v106_2: Space = singleton(&(v105_7_head));
        let v106_3: Space = intersect(&(*CONSTANT_1),&(v106_2));
        let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
        drop(v106_4);
        let v106_8: Space = if (v106_5).is_empty() { Space::new() } else {
          let v107_6: Path = concat_path(&(v105_6),&(v105_7_head));
          let v107_7: Space = routine_22(c, &(v107_6), &(v105_7_tail), &(*s1));
          compose(&(v106_5),&(v107_7))
        };
        drop(v106_5);
        let v106_9: Space = intersect(&(*CONSTANT_1),&(v106_2));
        drop(v106_2);
        let v106_10: Space = if has_head(&(v106_9)) { singleton(&[]) } else { Space::new() };
        drop(v106_9);
        let v106_12: Space = if (v106_10).is_empty() { Space::new() } else {
          let v108_6: Path = concat_path(&(v105_6),&(v105_7_head));
          let v108_11: Space = routine_23(c, &(v108_6), &(v105_7_tail), &(*s1));
          drop(v108_6);
          compose(&(v106_10),&(v108_11))
        };
        drop(v106_10);
        let v106_13: Space = unite(&(v106_8),&(v106_12));
        v105_7.join_into((v106_13).clone());
      }
      drop(v105_7_cursor);
      compose(&(v104_5),&(v105_7))
    };
    drop(v104_5);
    let v104_9: Space = intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
    drop(v104_9);
    let v104_12: Space = if (v104_10).is_empty() { Space::new() } else {
      let v109_6: Path = concat_path(&(*p0),&(v103_12_head));
      let mut v109_11 = Space::new();
      let mut v109_11_cursor = (v103_12_tail).read_zipper();
      for v109_11_byte in v109_11_cursor.child_mask().iter() {
        v109_11_cursor.descend_to_byte(v109_11_byte);
        let v109_11_tail = v109_11_cursor.make_map();
        v109_11_cursor.ascend(1);
        let v109_11_head = Path::from_slice(&[v109_11_byte]);
        let v110_2: Space = singleton(&(v109_11_head));
        let v110_3: Space = intersect(&(*CONSTANT_1),&(v110_2));
        let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
        drop(v110_3);
        let v110_5: Space = subtract(&(*CONSTANT_0),&(v110_4));
        drop(v110_4);
        let v110_8: Space = if (v110_5).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v109_6),&(v109_11_head));
          let v111_7: Space = routine_22(c, &(v111_6), &(v109_11_tail), &(*s1));
          compose(&(v110_5),&(v111_7))
        };
        drop(v110_5);
        let v110_9: Space = intersect(&(*CONSTANT_1),&(v110_2));
        drop(v110_2);
        let v110_10: Space = if has_head(&(v110_9)) { singleton(&[]) } else { Space::new() };
        drop(v110_9);
        let v110_12: Space = if (v110_10).is_empty() { Space::new() } else {
          let v112_6: Path = concat_path(&(v109_6),&(v109_11_head));
          let v112_11: Space = routine_5(c, &(v112_6), &(v109_11_tail), &(*s1));
          drop(v112_6);
          compose(&(v110_10),&(v112_11))
        };
        drop(v110_10);
        let v110_13: Space = unite(&(v110_8),&(v110_12));
        v109_11.join_into((v110_13).clone());
      }
      drop(v109_11_cursor);
      drop(v109_6);
      compose(&(v104_10),&(v109_11))
    };
    drop(v104_10);
    let v104_13: Space = unite(&(v104_8),&(v104_12));
    v103_12.join_into((v104_13).clone());
  }
  drop(v103_12_cursor);
  (v103_12).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v113_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v113_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v113_10: Space = unwrap(&(v113_9),&(*p0));
  let v113_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v113_22 = Space::new();
  let mut v113_22_cursor = (*s0).read_zipper();
  for v113_22_byte in v113_22_cursor.child_mask().iter() {
    v113_22_cursor.descend_to_byte(v113_22_byte);
    let v113_22_tail = v113_22_cursor.make_map();
    v113_22_cursor.ascend(1);
    let v113_22_head = Path::from_slice(&[v113_22_byte]);
    let v114_2: Space = singleton(&(v113_22_head));
    let v114_3: Space = intersect(&(*CONSTANT_1),&(v114_2));
    let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
    drop(v114_3);
    let v114_5: Space = subtract(&(*CONSTANT_0),&(v114_4));
    drop(v114_4);
    let v114_8: Space = if (v114_5).is_empty() { Space::new() } else {
      let v115_6: Path = concat_path(&(*p0),&(v113_22_head));
      let mut v115_7 = Space::new();
      let mut v115_7_cursor = (v113_22_tail).read_zipper();
      for v115_7_byte in v115_7_cursor.child_mask().iter() {
        v115_7_cursor.descend_to_byte(v115_7_byte);
        let v115_7_tail = v115_7_cursor.make_map();
        v115_7_cursor.ascend(1);
        let v115_7_head = Path::from_slice(&[v115_7_byte]);
        let v116_2: Space = singleton(&(v115_7_head));
        let v116_3: Space = intersect(&(*CONSTANT_1),&(v116_2));
        let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
        drop(v116_3);
        let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
        drop(v116_4);
        let v116_8: Space = if (v116_5).is_empty() { Space::new() } else {
          let v117_6: Path = concat_path(&(v115_6),&(v115_7_head));
          let v117_7: Space = routine_22(c, &(v117_6), &(v115_7_tail), &(*s1));
          compose(&(v116_5),&(v117_7))
        };
        drop(v116_5);
        let v116_9: Space = intersect(&(*CONSTANT_1),&(v116_2));
        drop(v116_2);
        let v116_10: Space = if has_head(&(v116_9)) { singleton(&[]) } else { Space::new() };
        drop(v116_9);
        let v116_12: Space = if (v116_10).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v115_6),&(v115_7_head));
          let v118_11: Space = routine_23(c, &(v118_6), &(v115_7_tail), &(*s1));
          drop(v118_6);
          compose(&(v116_10),&(v118_11))
        };
        drop(v116_10);
        let v116_13: Space = unite(&(v116_8),&(v116_12));
        v115_7.join_into((v116_13).clone());
      }
      drop(v115_7_cursor);
      compose(&(v114_5),&(v115_7))
    };
    drop(v114_5);
    let v114_9: Space = intersect(&(*CONSTANT_1),&(v114_2));
    drop(v114_2);
    let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
    drop(v114_9);
    let v114_18: Space = if (v114_10).is_empty() { Space::new() } else {
      let v119_11: Space = unwrap(&(v113_10),&(v113_22_head));
      let v119_12: Space = restrict_to(&(v113_9),&(v119_11));
      let mut v119_13 = Space::new();
      let mut v119_13_cursor = (v119_12).read_zipper();
      for v119_13_byte in v119_13_cursor.child_mask().iter() {
        v119_13_cursor.descend_to_byte(v119_13_byte);
        let v119_13_tail = v119_13_cursor.make_map();
        v119_13_cursor.ascend(1);
        let v119_13_head = Path::from_slice(&[v119_13_byte]);
        let v120_2: Space = singleton(&(v119_13_head));
        let v120_3: Space = intersect(&(*CONSTANT_1),&(v120_2));
        let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
        drop(v120_3);
        let v120_5: Space = subtract(&(*CONSTANT_0),&(v120_4));
        drop(v120_4);
        let v120_7: Space = if (v120_5).is_empty() { Space::new() } else {
          let v121_6: Space = routine_6(c, &(v119_13_head), &(v119_13_tail));
          compose(&(v120_5),&(v121_6))
        };
        drop(v120_5);
        let v120_8: Space = intersect(&(*CONSTANT_1),&(v120_2));
        drop(v120_2);
        let v120_9: Space = if has_head(&(v120_8)) { singleton(&[]) } else { Space::new() };
        drop(v120_8);
        let v120_11: Space = if (v120_9).is_empty() { Space::new() } else {
          let v122_10: Space = routine_7(c, &(v119_13_head), &(v119_13_tail));
          compose(&(v120_9),&(v122_10))
        };
        drop(v120_9);
        let v120_12: Space = unite(&(v120_7),&(v120_11));
        v119_13.join_into((v120_12).clone());
      }
      drop(v119_13_cursor);
      drop(v119_12);
      let v119_14: Space = restrict_to(&(v113_7),&(v119_13));
      let mut v119_15 = Space::new();
      let mut v119_15_cursor = (v119_14).read_zipper();
      for v119_15_byte in v119_15_cursor.child_mask().iter() {
        v119_15_cursor.descend_to_byte(v119_15_byte);
        let v119_15_tail = v119_15_cursor.make_map();
        v119_15_cursor.ascend(1);
        let v119_15_head = Path::from_slice(&[v119_15_byte]);
        let v123_2: Space = singleton(&(v119_15_head));
        let v123_3: Space = intersect(&(*CONSTANT_1),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
        drop(v123_4);
        let v123_7: Space = if (v123_5).is_empty() { Space::new() } else {
          let v124_6: Space = routine_8(c, &(v119_15_head), &(v119_15_tail));
          compose(&(v123_5),&(v124_6))
        };
        drop(v123_5);
        let v123_8: Space = intersect(&(*CONSTANT_1),&(v123_2));
        drop(v123_2);
        let v123_9: Space = if has_head(&(v123_8)) { singleton(&[]) } else { Space::new() };
        drop(v123_8);
        let v123_11: Space = if (v123_9).is_empty() { Space::new() } else {
          let v125_10: Space = routine_9(c, &(v119_15_head), &(v119_15_tail));
          compose(&(v123_9),&(v125_10))
        };
        drop(v123_9);
        let v123_12: Space = unite(&(v123_7),&(v123_11));
        v119_15.join_into((v123_12).clone());
      }
      drop(v119_15_cursor);
      let v119_16: Space = subtract(&(v119_15),&(v119_11));
      drop(v119_11);
      let v119_17: Space = intersect(&(v119_16),&(v113_12));
      compose(&(v114_10),&(v119_17))
    };
    drop(v114_10);
    let v126_6: Path = concat_path(&(*p0),&(v113_22_head));
    let v114_19: Space = wrap(&(v114_18),&(v126_6));
    let v114_20: Space = unite(&(v114_8),&(v114_19));
    v113_22.join_into((v114_20).clone());
  }
  drop(v113_22_cursor);
  drop(v113_7);
  drop(v113_9);
  drop(v113_10);
  drop(v113_12);
  (v113_22).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v127_11 = Space::new();
  let mut v127_11_cursor = (*s0).read_zipper();
  for v127_11_byte in v127_11_cursor.child_mask().iter() {
    v127_11_cursor.descend_to_byte(v127_11_byte);
    let v127_11_tail = v127_11_cursor.make_map();
    v127_11_cursor.ascend(1);
    let v127_11_head = Path::from_slice(&[v127_11_byte]);
    let v128_2: Space = singleton(&(v127_11_head));
    let v128_3: Space = intersect(&(*CONSTANT_1),&(v128_2));
    let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
    drop(v128_3);
    let v128_5: Space = subtract(&(*CONSTANT_0),&(v128_4));
    drop(v128_4);
    let v128_8: Space = if (v128_5).is_empty() { Space::new() } else {
      let v129_6: Path = concat_path(&(*p0),&(v127_11_head));
      let mut v129_7 = Space::new();
      let mut v129_7_cursor = (v127_11_tail).read_zipper();
      for v129_7_byte in v129_7_cursor.child_mask().iter() {
        v129_7_cursor.descend_to_byte(v129_7_byte);
        let v129_7_tail = v129_7_cursor.make_map();
        v129_7_cursor.ascend(1);
        let v129_7_head = Path::from_slice(&[v129_7_byte]);
        let v130_2: Space = singleton(&(v129_7_head));
        let v130_3: Space = intersect(&(*CONSTANT_1),&(v130_2));
        let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
        drop(v130_3);
        let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
        drop(v130_4);
        let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
          let v131_6: Path = concat_path(&(v129_6),&(v129_7_head));
          let v131_7: Space = routine_24(c, &(v131_6), &(v129_7_tail));
          compose(&(v130_5),&(v131_7))
        };
        drop(v130_5);
        let v130_9: Space = intersect(&(*CONSTANT_1),&(v130_2));
        drop(v130_2);
        let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
        drop(v130_9);
        let v130_12: Space = if (v130_10).is_empty() { Space::new() } else {
          let v132_6: Path = concat_path(&(v129_6),&(v129_7_head));
          let v132_11: Space = routine_25(c, &(v132_6), &(v129_7_tail));
          drop(v132_6);
          compose(&(v130_10),&(v132_11))
        };
        drop(v130_10);
        let v130_13: Space = unite(&(v130_8),&(v130_12));
        v129_7.join_into((v130_13).clone());
      }
      drop(v129_7_cursor);
      compose(&(v128_5),&(v129_7))
    };
    drop(v128_5);
    let v128_9: Space = intersect(&(*CONSTANT_1),&(v128_2));
    drop(v128_2);
    let v128_10: Space = if has_head(&(v128_9)) { singleton(&[]) } else { Space::new() };
    drop(v128_9);
    let v128_12: Space = if (v128_10).is_empty() { Space::new() } else {
      let v133_6: Path = concat_path(&(*p0),&(v127_11_head));
      let mut v133_11 = Space::new();
      let mut v133_11_cursor = (v127_11_tail).read_zipper();
      for v133_11_byte in v133_11_cursor.child_mask().iter() {
        v133_11_cursor.descend_to_byte(v133_11_byte);
        let v133_11_tail = v133_11_cursor.make_map();
        v133_11_cursor.ascend(1);
        let v133_11_head = Path::from_slice(&[v133_11_byte]);
        let v134_2: Space = singleton(&(v133_11_head));
        let v134_3: Space = intersect(&(*CONSTANT_1),&(v134_2));
        let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
        drop(v134_3);
        let v134_5: Space = subtract(&(*CONSTANT_0),&(v134_4));
        drop(v134_4);
        let v134_8: Space = if (v134_5).is_empty() { Space::new() } else {
          let v135_6: Path = concat_path(&(v133_6),&(v133_11_head));
          let v135_7: Space = routine_24(c, &(v135_6), &(v133_11_tail));
          compose(&(v134_5),&(v135_7))
        };
        drop(v134_5);
        let v134_9: Space = intersect(&(*CONSTANT_1),&(v134_2));
        drop(v134_2);
        let v134_10: Space = if has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
        drop(v134_9);
        let v134_12: Space = if (v134_10).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v133_6),&(v133_11_head));
          let v136_11: Space = routine_14(c, &(v136_6), &(v133_11_tail));
          drop(v136_6);
          compose(&(v134_10),&(v136_11))
        };
        drop(v134_10);
        let v134_13: Space = unite(&(v134_8),&(v134_12));
        v133_11.join_into((v134_13).clone());
      }
      drop(v133_11_cursor);
      drop(v133_6);
      compose(&(v128_10),&(v133_11))
    };
    drop(v128_10);
    let v128_13: Space = unite(&(v128_8),&(v128_12));
    v127_11.join_into((v128_13).clone());
  }
  drop(v127_11_cursor);
  (v127_11).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v137_8 = Space::new();
  let mut v137_8_cursor = (*s0).read_zipper();
  for v137_8_byte in v137_8_cursor.child_mask().iter() {
    v137_8_cursor.descend_to_byte(v137_8_byte);
    let v137_8_tail = v137_8_cursor.make_map();
    v137_8_cursor.ascend(1);
    let v137_8_head = Path::from_slice(&[v137_8_byte]);
    let v138_2: Space = singleton(&(v137_8_head));
    let v138_3: Space = intersect(&(*CONSTANT_1),&(v138_2));
    let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
    drop(v138_3);
    let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
    drop(v138_4);
    let v138_8: Space = if (v138_5).is_empty() { Space::new() } else {
      let v139_6: Path = concat_path(&(*p0),&(v137_8_head));
      let mut v139_7 = Space::new();
      let mut v139_7_cursor = (v137_8_tail).read_zipper();
      for v139_7_byte in v139_7_cursor.child_mask().iter() {
        v139_7_cursor.descend_to_byte(v139_7_byte);
        let v139_7_tail = v139_7_cursor.make_map();
        v139_7_cursor.ascend(1);
        let v139_7_head = Path::from_slice(&[v139_7_byte]);
        let v140_2: Space = singleton(&(v139_7_head));
        let v140_3: Space = intersect(&(*CONSTANT_1),&(v140_2));
        let v140_4: Space = if has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
        drop(v140_3);
        let v140_5: Space = subtract(&(*CONSTANT_0),&(v140_4));
        drop(v140_4);
        let v140_8: Space = if (v140_5).is_empty() { Space::new() } else {
          let v141_6: Path = concat_path(&(v139_6),&(v139_7_head));
          let v141_7: Space = routine_24(c, &(v141_6), &(v139_7_tail));
          compose(&(v140_5),&(v141_7))
        };
        drop(v140_5);
        let v140_9: Space = intersect(&(*CONSTANT_1),&(v140_2));
        drop(v140_2);
        let v140_10: Space = if has_head(&(v140_9)) { singleton(&[]) } else { Space::new() };
        drop(v140_9);
        let v140_12: Space = if (v140_10).is_empty() { Space::new() } else {
          let v142_6: Path = concat_path(&(v139_6),&(v139_7_head));
          let v142_11: Space = routine_25(c, &(v142_6), &(v139_7_tail));
          drop(v142_6);
          compose(&(v140_10),&(v142_11))
        };
        drop(v140_10);
        let v140_13: Space = unite(&(v140_8),&(v140_12));
        v139_7.join_into((v140_13).clone());
      }
      drop(v139_7_cursor);
      drop(v139_6);
      compose(&(v138_5),&(v139_7))
    };
    drop(v138_5);
    let v138_9: Space = intersect(&(*CONSTANT_1),&(v138_2));
    drop(v138_2);
    let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
    drop(v138_9);
    let v138_11: Space = compose(&(v138_10),&(v137_8_tail));
    drop(v138_10);
    let v138_12: Space = unite(&(v138_8),&(v138_11));
    drop(v138_11);
    v137_8.join_into((v138_12).clone());
  }
  drop(v137_8_cursor);
  (v137_8).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v144_11 = Space::new();
  let mut v144_11_cursor = (*s0).read_zipper();
  for v144_11_byte in v144_11_cursor.child_mask().iter() {
    v144_11_cursor.descend_to_byte(v144_11_byte);
    let v144_11_tail = v144_11_cursor.make_map();
    v144_11_cursor.ascend(1);
    let v144_11_head = Path::from_slice(&[v144_11_byte]);
    let v145_2: Space = singleton(&(v144_11_head));
    let v145_3: Space = intersect(&(*CONSTANT_1),&(v145_2));
    let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
    drop(v145_3);
    let v145_5: Space = subtract(&(*CONSTANT_0),&(v145_4));
    drop(v145_4);
    let v145_8: Space = if (v145_5).is_empty() { Space::new() } else {
      let v146_6: Path = concat_path(&(*p0),&(v144_11_head));
      let mut v146_7 = Space::new();
      let mut v146_7_cursor = (v144_11_tail).read_zipper();
      for v146_7_byte in v146_7_cursor.child_mask().iter() {
        v146_7_cursor.descend_to_byte(v146_7_byte);
        let v146_7_tail = v146_7_cursor.make_map();
        v146_7_cursor.ascend(1);
        let v146_7_head = Path::from_slice(&[v146_7_byte]);
        let v147_2: Space = singleton(&(v146_7_head));
        let v147_3: Space = intersect(&(*CONSTANT_1),&(v147_2));
        let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
        drop(v147_3);
        let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
        drop(v147_4);
        let v147_8: Space = if (v147_5).is_empty() { Space::new() } else {
          let v148_6: Path = concat_path(&(v146_6),&(v146_7_head));
          let v148_7: Space = routine_26(c, &(v148_6), &(v146_7_tail));
          compose(&(v147_5),&(v148_7))
        };
        drop(v147_5);
        let v147_9: Space = intersect(&(*CONSTANT_1),&(v147_2));
        drop(v147_2);
        let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
        drop(v147_9);
        let v147_12: Space = if (v147_10).is_empty() { Space::new() } else {
          let v149_6: Path = concat_path(&(v146_6),&(v146_7_head));
          let v149_11: Space = routine_27(c, &(v149_6), &(v146_7_tail));
          drop(v149_6);
          compose(&(v147_10),&(v149_11))
        };
        drop(v147_10);
        let v147_13: Space = unite(&(v147_8),&(v147_12));
        v146_7.join_into((v147_13).clone());
      }
      drop(v146_7_cursor);
      compose(&(v145_5),&(v146_7))
    };
    drop(v145_5);
    let v145_9: Space = intersect(&(*CONSTANT_1),&(v145_2));
    drop(v145_2);
    let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
    drop(v145_9);
    let v145_12: Space = if (v145_10).is_empty() { Space::new() } else {
      let v150_6: Path = concat_path(&(*p0),&(v144_11_head));
      let mut v150_11 = Space::new();
      let mut v150_11_cursor = (v144_11_tail).read_zipper();
      for v150_11_byte in v150_11_cursor.child_mask().iter() {
        v150_11_cursor.descend_to_byte(v150_11_byte);
        let v150_11_tail = v150_11_cursor.make_map();
        v150_11_cursor.ascend(1);
        let v150_11_head = Path::from_slice(&[v150_11_byte]);
        let v151_2: Space = singleton(&(v150_11_head));
        let v151_3: Space = intersect(&(*CONSTANT_1),&(v151_2));
        let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
        drop(v151_3);
        let v151_5: Space = subtract(&(*CONSTANT_0),&(v151_4));
        drop(v151_4);
        let v151_8: Space = if (v151_5).is_empty() { Space::new() } else {
          let v152_6: Path = concat_path(&(v150_6),&(v150_11_head));
          let v152_7: Space = routine_26(c, &(v152_6), &(v150_11_tail));
          compose(&(v151_5),&(v152_7))
        };
        drop(v151_5);
        let v151_9: Space = intersect(&(*CONSTANT_1),&(v151_2));
        drop(v151_2);
        let v151_10: Space = if has_head(&(v151_9)) { singleton(&[]) } else { Space::new() };
        drop(v151_9);
        let v151_12: Space = if (v151_10).is_empty() { Space::new() } else {
          let v153_6: Path = concat_path(&(v150_6),&(v150_11_head));
          let v153_11: Space = routine_17(c, &(v153_6), &(v150_11_tail));
          drop(v153_6);
          compose(&(v151_10),&(v153_11))
        };
        drop(v151_10);
        let v151_13: Space = unite(&(v151_8),&(v151_12));
        v150_11.join_into((v151_13).clone());
      }
      drop(v150_11_cursor);
      drop(v150_6);
      compose(&(v145_10),&(v150_11))
    };
    drop(v145_10);
    let v145_13: Space = unite(&(v145_8),&(v145_12));
    v144_11.join_into((v145_13).clone());
  }
  drop(v144_11_cursor);
  (v144_11).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v154_8 = Space::new();
  let mut v154_8_cursor = (*s0).read_zipper();
  for v154_8_byte in v154_8_cursor.child_mask().iter() {
    v154_8_cursor.descend_to_byte(v154_8_byte);
    let v154_8_tail = v154_8_cursor.make_map();
    v154_8_cursor.ascend(1);
    let v154_8_head = Path::from_slice(&[v154_8_byte]);
    let v155_2: Space = singleton(&(v154_8_head));
    let v155_3: Space = intersect(&(*CONSTANT_1),&(v155_2));
    let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
    drop(v155_3);
    let v155_5: Space = subtract(&(*CONSTANT_0),&(v155_4));
    drop(v155_4);
    let v155_8: Space = if (v155_5).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&(v154_8_head));
      let mut v156_7 = Space::new();
      let mut v156_7_cursor = (v154_8_tail).read_zipper();
      for v156_7_byte in v156_7_cursor.child_mask().iter() {
        v156_7_cursor.descend_to_byte(v156_7_byte);
        let v156_7_tail = v156_7_cursor.make_map();
        v156_7_cursor.ascend(1);
        let v156_7_head = Path::from_slice(&[v156_7_byte]);
        let v157_2: Space = singleton(&(v156_7_head));
        let v157_3: Space = intersect(&(*CONSTANT_1),&(v157_2));
        let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = subtract(&(*CONSTANT_0),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&(v156_7_head));
          let v158_7: Space = routine_26(c, &(v158_6), &(v156_7_tail));
          compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = intersect(&(*CONSTANT_1),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
          let v159_6: Path = concat_path(&(v156_6),&(v156_7_head));
          let v159_11: Space = routine_27(c, &(v159_6), &(v156_7_tail));
          drop(v159_6);
          compose(&(v157_10),&(v159_11))
        };
        drop(v157_10);
        let v157_13: Space = unite(&(v157_8),&(v157_12));
        v156_7.join_into((v157_13).clone());
      }
      drop(v156_7_cursor);
      drop(v156_6);
      compose(&(v155_5),&(v156_7))
    };
    drop(v155_5);
    let v155_9: Space = intersect(&(*CONSTANT_1),&(v155_2));
    drop(v155_2);
    let v155_10: Space = if has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
    drop(v155_9);
    let v155_11: Space = compose(&(v155_10),&(v154_8_tail));
    drop(v155_10);
    let v155_12: Space = unite(&(v155_8),&(v155_11));
    drop(v155_11);
    v154_8.join_into((v155_12).clone());
  }
  drop(v154_8_cursor);
  (v154_8).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v161_11 = Space::new();
  let mut v161_11_cursor = (*s0).read_zipper();
  for v161_11_byte in v161_11_cursor.child_mask().iter() {
    v161_11_cursor.descend_to_byte(v161_11_byte);
    let v161_11_tail = v161_11_cursor.make_map();
    v161_11_cursor.ascend(1);
    let v161_11_head = Path::from_slice(&[v161_11_byte]);
    let v162_2: Space = singleton(&(v161_11_head));
    let v162_3: Space = intersect(&(*CONSTANT_1),&(v162_2));
    let v162_4: Space = if has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
    drop(v162_3);
    let v162_5: Space = subtract(&(*CONSTANT_0),&(v162_4));
    drop(v162_4);
    let v162_8: Space = if (v162_5).is_empty() { Space::new() } else {
      let v163_6: Path = concat_path(&(*p0),&(v161_11_head));
      let mut v163_7 = Space::new();
      let mut v163_7_cursor = (v161_11_tail).read_zipper();
      for v163_7_byte in v163_7_cursor.child_mask().iter() {
        v163_7_cursor.descend_to_byte(v163_7_byte);
        let v163_7_tail = v163_7_cursor.make_map();
        v163_7_cursor.ascend(1);
        let v163_7_head = Path::from_slice(&[v163_7_byte]);
        let v164_2: Space = singleton(&(v163_7_head));
        let v164_3: Space = intersect(&(*CONSTANT_1),&(v164_2));
        let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
        drop(v164_3);
        let v164_5: Space = subtract(&(*CONSTANT_0),&(v164_4));
        drop(v164_4);
        let v164_8: Space = if (v164_5).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v163_6),&(v163_7_head));
          let v165_7: Space = routine_28(c, &(v165_6), &(v163_7_tail));
          compose(&(v164_5),&(v165_7))
        };
        drop(v164_5);
        let v164_9: Space = intersect(&(*CONSTANT_1),&(v164_2));
        drop(v164_2);
        let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
        drop(v164_9);
        let v164_12: Space = if (v164_10).is_empty() { Space::new() } else {
          let v166_6: Path = concat_path(&(v163_6),&(v163_7_head));
          let v166_11: Space = routine_29(c, &(v166_6), &(v163_7_tail));
          drop(v166_6);
          compose(&(v164_10),&(v166_11))
        };
        drop(v164_10);
        let v164_13: Space = unite(&(v164_8),&(v164_12));
        v163_7.join_into((v164_13).clone());
      }
      drop(v163_7_cursor);
      compose(&(v162_5),&(v163_7))
    };
    drop(v162_5);
    let v162_9: Space = intersect(&(*CONSTANT_1),&(v162_2));
    drop(v162_2);
    let v162_10: Space = if has_head(&(v162_9)) { singleton(&[]) } else { Space::new() };
    drop(v162_9);
    let v162_12: Space = if (v162_10).is_empty() { Space::new() } else {
      let v167_6: Path = concat_path(&(*p0),&(v161_11_head));
      let mut v167_11 = Space::new();
      let mut v167_11_cursor = (v161_11_tail).read_zipper();
      for v167_11_byte in v167_11_cursor.child_mask().iter() {
        v167_11_cursor.descend_to_byte(v167_11_byte);
        let v167_11_tail = v167_11_cursor.make_map();
        v167_11_cursor.ascend(1);
        let v167_11_head = Path::from_slice(&[v167_11_byte]);
        let v168_2: Space = singleton(&(v167_11_head));
        let v168_3: Space = intersect(&(*CONSTANT_1),&(v168_2));
        let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
        drop(v168_3);
        let v168_5: Space = subtract(&(*CONSTANT_0),&(v168_4));
        drop(v168_4);
        let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
          let v169_6: Path = concat_path(&(v167_6),&(v167_11_head));
          let v169_7: Space = routine_28(c, &(v169_6), &(v167_11_tail));
          compose(&(v168_5),&(v169_7))
        };
        drop(v168_5);
        let v168_9: Space = intersect(&(*CONSTANT_1),&(v168_2));
        drop(v168_2);
        let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
        drop(v168_9);
        let v168_12: Space = if (v168_10).is_empty() { Space::new() } else {
          let v170_6: Path = concat_path(&(v167_6),&(v167_11_head));
          let v170_11: Space = routine_14(c, &(v170_6), &(v167_11_tail));
          drop(v170_6);
          compose(&(v168_10),&(v170_11))
        };
        drop(v168_10);
        let v168_13: Space = unite(&(v168_8),&(v168_12));
        v167_11.join_into((v168_13).clone());
      }
      drop(v167_11_cursor);
      drop(v167_6);
      compose(&(v162_10),&(v167_11))
    };
    drop(v162_10);
    let v162_13: Space = unite(&(v162_8),&(v162_12));
    v161_11.join_into((v162_13).clone());
  }
  drop(v161_11_cursor);
  (v161_11).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v171_8 = Space::new();
  let mut v171_8_cursor = (*s0).read_zipper();
  for v171_8_byte in v171_8_cursor.child_mask().iter() {
    v171_8_cursor.descend_to_byte(v171_8_byte);
    let v171_8_tail = v171_8_cursor.make_map();
    v171_8_cursor.ascend(1);
    let v171_8_head = Path::from_slice(&[v171_8_byte]);
    let v172_2: Space = singleton(&(v171_8_head));
    let v172_3: Space = intersect(&(*CONSTANT_1),&(v172_2));
    let v172_4: Space = if has_head(&(v172_3)) { singleton(&[]) } else { Space::new() };
    drop(v172_3);
    let v172_5: Space = subtract(&(*CONSTANT_0),&(v172_4));
    drop(v172_4);
    let v172_8: Space = if (v172_5).is_empty() { Space::new() } else {
      let v173_6: Path = concat_path(&(*p0),&(v171_8_head));
      let mut v173_7 = Space::new();
      let mut v173_7_cursor = (v171_8_tail).read_zipper();
      for v173_7_byte in v173_7_cursor.child_mask().iter() {
        v173_7_cursor.descend_to_byte(v173_7_byte);
        let v173_7_tail = v173_7_cursor.make_map();
        v173_7_cursor.ascend(1);
        let v173_7_head = Path::from_slice(&[v173_7_byte]);
        let v174_2: Space = singleton(&(v173_7_head));
        let v174_3: Space = intersect(&(*CONSTANT_1),&(v174_2));
        let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
        drop(v174_3);
        let v174_5: Space = subtract(&(*CONSTANT_0),&(v174_4));
        drop(v174_4);
        let v174_8: Space = if (v174_5).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v173_6),&(v173_7_head));
          let v175_7: Space = routine_28(c, &(v175_6), &(v173_7_tail));
          compose(&(v174_5),&(v175_7))
        };
        drop(v174_5);
        let v174_9: Space = intersect(&(*CONSTANT_1),&(v174_2));
        drop(v174_2);
        let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
        drop(v174_9);
        let v174_12: Space = if (v174_10).is_empty() { Space::new() } else {
          let v176_6: Path = concat_path(&(v173_6),&(v173_7_head));
          let v176_11: Space = routine_29(c, &(v176_6), &(v173_7_tail));
          drop(v176_6);
          compose(&(v174_10),&(v176_11))
        };
        drop(v174_10);
        let v174_13: Space = unite(&(v174_8),&(v174_12));
        v173_7.join_into((v174_13).clone());
      }
      drop(v173_7_cursor);
      drop(v173_6);
      compose(&(v172_5),&(v173_7))
    };
    drop(v172_5);
    let v172_9: Space = intersect(&(*CONSTANT_1),&(v172_2));
    drop(v172_2);
    let v172_10: Space = if has_head(&(v172_9)) { singleton(&[]) } else { Space::new() };
    drop(v172_9);
    let v172_11: Space = compose(&(v172_10),&(v171_8_tail));
    drop(v172_10);
    let v172_12: Space = unite(&(v172_8),&(v172_11));
    drop(v172_11);
    v171_8.join_into((v172_12).clone());
  }
  drop(v171_8_cursor);
  (v171_8).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v177_11 = Space::new();
  let mut v177_11_cursor = (*s0).read_zipper();
  for v177_11_byte in v177_11_cursor.child_mask().iter() {
    v177_11_cursor.descend_to_byte(v177_11_byte);
    let v177_11_tail = v177_11_cursor.make_map();
    v177_11_cursor.ascend(1);
    let v177_11_head = Path::from_slice(&[v177_11_byte]);
    let v178_2: Space = singleton(&(v177_11_head));
    let v178_3: Space = intersect(&(*CONSTANT_1),&(v178_2));
    let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
    drop(v178_3);
    let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
    drop(v178_4);
    let v178_8: Space = if (v178_5).is_empty() { Space::new() } else {
      let v179_6: Path = concat_path(&(*p0),&(v177_11_head));
      let mut v179_7 = Space::new();
      let mut v179_7_cursor = (v177_11_tail).read_zipper();
      for v179_7_byte in v179_7_cursor.child_mask().iter() {
        v179_7_cursor.descend_to_byte(v179_7_byte);
        let v179_7_tail = v179_7_cursor.make_map();
        v179_7_cursor.ascend(1);
        let v179_7_head = Path::from_slice(&[v179_7_byte]);
        let v180_2: Space = singleton(&(v179_7_head));
        let v180_3: Space = intersect(&(*CONSTANT_1),&(v180_2));
        let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
        drop(v180_3);
        let v180_5: Space = subtract(&(*CONSTANT_0),&(v180_4));
        drop(v180_4);
        let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v181_7: Space = routine_30(c, &(v181_6), &(v179_7_tail));
          compose(&(v180_5),&(v181_7))
        };
        drop(v180_5);
        let v180_9: Space = intersect(&(*CONSTANT_1),&(v180_2));
        drop(v180_2);
        let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
        drop(v180_9);
        let v180_12: Space = if (v180_10).is_empty() { Space::new() } else {
          let v182_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v182_11: Space = routine_31(c, &(v182_6), &(v179_7_tail));
          drop(v182_6);
          compose(&(v180_10),&(v182_11))
        };
        drop(v180_10);
        let v180_13: Space = unite(&(v180_8),&(v180_12));
        v179_7.join_into((v180_13).clone());
      }
      drop(v179_7_cursor);
      compose(&(v178_5),&(v179_7))
    };
    drop(v178_5);
    let v178_9: Space = intersect(&(*CONSTANT_1),&(v178_2));
    drop(v178_2);
    let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
    drop(v178_9);
    let v178_12: Space = if (v178_10).is_empty() { Space::new() } else {
      let v183_6: Path = concat_path(&(*p0),&(v177_11_head));
      let mut v183_11 = Space::new();
      let mut v183_11_cursor = (v177_11_tail).read_zipper();
      for v183_11_byte in v183_11_cursor.child_mask().iter() {
        v183_11_cursor.descend_to_byte(v183_11_byte);
        let v183_11_tail = v183_11_cursor.make_map();
        v183_11_cursor.ascend(1);
        let v183_11_head = Path::from_slice(&[v183_11_byte]);
        let v184_2: Space = singleton(&(v183_11_head));
        let v184_3: Space = intersect(&(*CONSTANT_1),&(v184_2));
        let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
        drop(v184_3);
        let v184_5: Space = subtract(&(*CONSTANT_0),&(v184_4));
        drop(v184_4);
        let v184_8: Space = if (v184_5).is_empty() { Space::new() } else {
          let v185_6: Path = concat_path(&(v183_6),&(v183_11_head));
          let v185_7: Space = routine_30(c, &(v185_6), &(v183_11_tail));
          compose(&(v184_5),&(v185_7))
        };
        drop(v184_5);
        let v184_9: Space = intersect(&(*CONSTANT_1),&(v184_2));
        drop(v184_2);
        let v184_10: Space = if has_head(&(v184_9)) { singleton(&[]) } else { Space::new() };
        drop(v184_9);
        let v184_12: Space = if (v184_10).is_empty() { Space::new() } else {
          let v186_6: Path = concat_path(&(v183_6),&(v183_11_head));
          let v186_11: Space = routine_17(c, &(v186_6), &(v183_11_tail));
          drop(v186_6);
          compose(&(v184_10),&(v186_11))
        };
        drop(v184_10);
        let v184_13: Space = unite(&(v184_8),&(v184_12));
        v183_11.join_into((v184_13).clone());
      }
      drop(v183_11_cursor);
      drop(v183_6);
      compose(&(v178_10),&(v183_11))
    };
    drop(v178_10);
    let v178_13: Space = unite(&(v178_8),&(v178_12));
    v177_11.join_into((v178_13).clone());
  }
  drop(v177_11_cursor);
  (v177_11).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v187_8 = Space::new();
  let mut v187_8_cursor = (*s0).read_zipper();
  for v187_8_byte in v187_8_cursor.child_mask().iter() {
    v187_8_cursor.descend_to_byte(v187_8_byte);
    let v187_8_tail = v187_8_cursor.make_map();
    v187_8_cursor.ascend(1);
    let v187_8_head = Path::from_slice(&[v187_8_byte]);
    let v188_2: Space = singleton(&(v187_8_head));
    let v188_3: Space = intersect(&(*CONSTANT_1),&(v188_2));
    let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
    drop(v188_3);
    let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
    drop(v188_4);
    let v188_8: Space = if (v188_5).is_empty() { Space::new() } else {
      let v189_6: Path = concat_path(&(*p0),&(v187_8_head));
      let mut v189_7 = Space::new();
      let mut v189_7_cursor = (v187_8_tail).read_zipper();
      for v189_7_byte in v189_7_cursor.child_mask().iter() {
        v189_7_cursor.descend_to_byte(v189_7_byte);
        let v189_7_tail = v189_7_cursor.make_map();
        v189_7_cursor.ascend(1);
        let v189_7_head = Path::from_slice(&[v189_7_byte]);
        let v190_2: Space = singleton(&(v189_7_head));
        let v190_3: Space = intersect(&(*CONSTANT_1),&(v190_2));
        let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
        drop(v190_3);
        let v190_5: Space = subtract(&(*CONSTANT_0),&(v190_4));
        drop(v190_4);
        let v190_8: Space = if (v190_5).is_empty() { Space::new() } else {
          let v191_6: Path = concat_path(&(v189_6),&(v189_7_head));
          let v191_7: Space = routine_30(c, &(v191_6), &(v189_7_tail));
          compose(&(v190_5),&(v191_7))
        };
        drop(v190_5);
        let v190_9: Space = intersect(&(*CONSTANT_1),&(v190_2));
        drop(v190_2);
        let v190_10: Space = if has_head(&(v190_9)) { singleton(&[]) } else { Space::new() };
        drop(v190_9);
        let v190_12: Space = if (v190_10).is_empty() { Space::new() } else {
          let v192_6: Path = concat_path(&(v189_6),&(v189_7_head));
          let v192_11: Space = routine_31(c, &(v192_6), &(v189_7_tail));
          drop(v192_6);
          compose(&(v190_10),&(v192_11))
        };
        drop(v190_10);
        let v190_13: Space = unite(&(v190_8),&(v190_12));
        v189_7.join_into((v190_13).clone());
      }
      drop(v189_7_cursor);
      drop(v189_6);
      compose(&(v188_5),&(v189_7))
    };
    drop(v188_5);
    let v188_9: Space = intersect(&(*CONSTANT_1),&(v188_2));
    drop(v188_2);
    let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
    drop(v188_9);
    let v188_11: Space = compose(&(v188_10),&(v187_8_tail));
    drop(v188_10);
    let v188_12: Space = unite(&(v188_8),&(v188_11));
    drop(v188_11);
    v187_8.join_into((v188_12).clone());
  }
  drop(v187_8_cursor);
  (v187_8).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v193_12 = Space::new();
  let mut v193_12_cursor = (*s0).read_zipper();
  for v193_12_byte in v193_12_cursor.child_mask().iter() {
    v193_12_cursor.descend_to_byte(v193_12_byte);
    let v193_12_tail = v193_12_cursor.make_map();
    v193_12_cursor.ascend(1);
    let v193_12_head = Path::from_slice(&[v193_12_byte]);
    let v194_2: Space = singleton(&(v193_12_head));
    let v194_3: Space = intersect(&(*CONSTANT_1),&(v194_2));
    let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
    drop(v194_3);
    let v194_5: Space = subtract(&(*CONSTANT_0),&(v194_4));
    drop(v194_4);
    let v194_8: Space = if (v194_5).is_empty() { Space::new() } else {
      let v195_6: Path = concat_path(&(*p0),&(v193_12_head));
      let mut v195_7 = Space::new();
      let mut v195_7_cursor = (v193_12_tail).read_zipper();
      for v195_7_byte in v195_7_cursor.child_mask().iter() {
        v195_7_cursor.descend_to_byte(v195_7_byte);
        let v195_7_tail = v195_7_cursor.make_map();
        v195_7_cursor.ascend(1);
        let v195_7_head = Path::from_slice(&[v195_7_byte]);
        let v196_2: Space = singleton(&(v195_7_head));
        let v196_3: Space = intersect(&(*CONSTANT_1),&(v196_2));
        let v196_4: Space = if has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
        drop(v196_3);
        let v196_5: Space = subtract(&(*CONSTANT_0),&(v196_4));
        drop(v196_4);
        let v196_8: Space = if (v196_5).is_empty() { Space::new() } else {
          let v197_6: Path = concat_path(&(v195_6),&(v195_7_head));
          let v197_7: Space = routine_32(c, &(v197_6), &(v195_7_tail), &(*s1));
          compose(&(v196_5),&(v197_7))
        };
        drop(v196_5);
        let v196_9: Space = intersect(&(*CONSTANT_1),&(v196_2));
        drop(v196_2);
        let v196_10: Space = if has_head(&(v196_9)) { singleton(&[]) } else { Space::new() };
        drop(v196_9);
        let v196_12: Space = if (v196_10).is_empty() { Space::new() } else {
          let v198_6: Path = concat_path(&(v195_6),&(v195_7_head));
          let v198_11: Space = routine_33(c, &(v198_6), &(v195_7_tail), &(*s1));
          drop(v198_6);
          compose(&(v196_10),&(v198_11))
        };
        drop(v196_10);
        let v196_13: Space = unite(&(v196_8),&(v196_12));
        v195_7.join_into((v196_13).clone());
      }
      drop(v195_7_cursor);
      compose(&(v194_5),&(v195_7))
    };
    drop(v194_5);
    let v194_9: Space = intersect(&(*CONSTANT_1),&(v194_2));
    drop(v194_2);
    let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
    drop(v194_9);
    let v194_12: Space = if (v194_10).is_empty() { Space::new() } else {
      let v199_6: Path = concat_path(&(*p0),&(v193_12_head));
      let mut v199_11 = Space::new();
      let mut v199_11_cursor = (v193_12_tail).read_zipper();
      for v199_11_byte in v199_11_cursor.child_mask().iter() {
        v199_11_cursor.descend_to_byte(v199_11_byte);
        let v199_11_tail = v199_11_cursor.make_map();
        v199_11_cursor.ascend(1);
        let v199_11_head = Path::from_slice(&[v199_11_byte]);
        let v200_2: Space = singleton(&(v199_11_head));
        let v200_3: Space = intersect(&(*CONSTANT_1),&(v200_2));
        let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
        drop(v200_3);
        let v200_5: Space = subtract(&(*CONSTANT_0),&(v200_4));
        drop(v200_4);
        let v200_8: Space = if (v200_5).is_empty() { Space::new() } else {
          let v201_6: Path = concat_path(&(v199_6),&(v199_11_head));
          let v201_7: Space = routine_32(c, &(v201_6), &(v199_11_tail), &(*s1));
          compose(&(v200_5),&(v201_7))
        };
        drop(v200_5);
        let v200_9: Space = intersect(&(*CONSTANT_1),&(v200_2));
        drop(v200_2);
        let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
        drop(v200_9);
        let v200_12: Space = if (v200_10).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v199_6),&(v199_11_head));
          let v202_11: Space = routine_5(c, &(v202_6), &(v199_11_tail), &(*s1));
          drop(v202_6);
          compose(&(v200_10),&(v202_11))
        };
        drop(v200_10);
        let v200_13: Space = unite(&(v200_8),&(v200_12));
        v199_11.join_into((v200_13).clone());
      }
      drop(v199_11_cursor);
      drop(v199_6);
      compose(&(v194_10),&(v199_11))
    };
    drop(v194_10);
    let v194_13: Space = unite(&(v194_8),&(v194_12));
    v193_12.join_into((v194_13).clone());
  }
  drop(v193_12_cursor);
  (v193_12).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v203_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v203_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v203_10: Space = unwrap(&(v203_9),&(*p0));
  let v203_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v203_22 = Space::new();
  let mut v203_22_cursor = (*s0).read_zipper();
  for v203_22_byte in v203_22_cursor.child_mask().iter() {
    v203_22_cursor.descend_to_byte(v203_22_byte);
    let v203_22_tail = v203_22_cursor.make_map();
    v203_22_cursor.ascend(1);
    let v203_22_head = Path::from_slice(&[v203_22_byte]);
    let v204_2: Space = singleton(&(v203_22_head));
    let v204_3: Space = intersect(&(*CONSTANT_1),&(v204_2));
    let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
    drop(v204_3);
    let v204_5: Space = subtract(&(*CONSTANT_0),&(v204_4));
    drop(v204_4);
    let v204_8: Space = if (v204_5).is_empty() { Space::new() } else {
      let v205_6: Path = concat_path(&(*p0),&(v203_22_head));
      let mut v205_7 = Space::new();
      let mut v205_7_cursor = (v203_22_tail).read_zipper();
      for v205_7_byte in v205_7_cursor.child_mask().iter() {
        v205_7_cursor.descend_to_byte(v205_7_byte);
        let v205_7_tail = v205_7_cursor.make_map();
        v205_7_cursor.ascend(1);
        let v205_7_head = Path::from_slice(&[v205_7_byte]);
        let v206_2: Space = singleton(&(v205_7_head));
        let v206_3: Space = intersect(&(*CONSTANT_1),&(v206_2));
        let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
        drop(v206_3);
        let v206_5: Space = subtract(&(*CONSTANT_0),&(v206_4));
        drop(v206_4);
        let v206_8: Space = if (v206_5).is_empty() { Space::new() } else {
          let v207_6: Path = concat_path(&(v205_6),&(v205_7_head));
          let v207_7: Space = routine_32(c, &(v207_6), &(v205_7_tail), &(*s1));
          compose(&(v206_5),&(v207_7))
        };
        drop(v206_5);
        let v206_9: Space = intersect(&(*CONSTANT_1),&(v206_2));
        drop(v206_2);
        let v206_10: Space = if has_head(&(v206_9)) { singleton(&[]) } else { Space::new() };
        drop(v206_9);
        let v206_12: Space = if (v206_10).is_empty() { Space::new() } else {
          let v208_6: Path = concat_path(&(v205_6),&(v205_7_head));
          let v208_11: Space = routine_33(c, &(v208_6), &(v205_7_tail), &(*s1));
          drop(v208_6);
          compose(&(v206_10),&(v208_11))
        };
        drop(v206_10);
        let v206_13: Space = unite(&(v206_8),&(v206_12));
        v205_7.join_into((v206_13).clone());
      }
      drop(v205_7_cursor);
      compose(&(v204_5),&(v205_7))
    };
    drop(v204_5);
    let v204_9: Space = intersect(&(*CONSTANT_1),&(v204_2));
    drop(v204_2);
    let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
    drop(v204_9);
    let v204_18: Space = if (v204_10).is_empty() { Space::new() } else {
      let v209_11: Space = unwrap(&(v203_10),&(v203_22_head));
      let v209_12: Space = restrict_to(&(v203_9),&(v209_11));
      let mut v209_13 = Space::new();
      let mut v209_13_cursor = (v209_12).read_zipper();
      for v209_13_byte in v209_13_cursor.child_mask().iter() {
        v209_13_cursor.descend_to_byte(v209_13_byte);
        let v209_13_tail = v209_13_cursor.make_map();
        v209_13_cursor.ascend(1);
        let v209_13_head = Path::from_slice(&[v209_13_byte]);
        let v210_2: Space = singleton(&(v209_13_head));
        let v210_3: Space = intersect(&(*CONSTANT_1),&(v210_2));
        let v210_4: Space = if has_head(&(v210_3)) { singleton(&[]) } else { Space::new() };
        drop(v210_3);
        let v210_5: Space = subtract(&(*CONSTANT_0),&(v210_4));
        drop(v210_4);
        let v210_7: Space = if (v210_5).is_empty() { Space::new() } else {
          let v211_6: Space = routine_6(c, &(v209_13_head), &(v209_13_tail));
          compose(&(v210_5),&(v211_6))
        };
        drop(v210_5);
        let v210_8: Space = intersect(&(*CONSTANT_1),&(v210_2));
        drop(v210_2);
        let v210_9: Space = if has_head(&(v210_8)) { singleton(&[]) } else { Space::new() };
        drop(v210_8);
        let v210_11: Space = if (v210_9).is_empty() { Space::new() } else {
          let v212_10: Space = routine_7(c, &(v209_13_head), &(v209_13_tail));
          compose(&(v210_9),&(v212_10))
        };
        drop(v210_9);
        let v210_12: Space = unite(&(v210_7),&(v210_11));
        v209_13.join_into((v210_12).clone());
      }
      drop(v209_13_cursor);
      drop(v209_12);
      let v209_14: Space = restrict_to(&(v203_7),&(v209_13));
      let mut v209_15 = Space::new();
      let mut v209_15_cursor = (v209_14).read_zipper();
      for v209_15_byte in v209_15_cursor.child_mask().iter() {
        v209_15_cursor.descend_to_byte(v209_15_byte);
        let v209_15_tail = v209_15_cursor.make_map();
        v209_15_cursor.ascend(1);
        let v209_15_head = Path::from_slice(&[v209_15_byte]);
        let v213_2: Space = singleton(&(v209_15_head));
        let v213_3: Space = intersect(&(*CONSTANT_1),&(v213_2));
        let v213_4: Space = if has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
        drop(v213_3);
        let v213_5: Space = subtract(&(*CONSTANT_0),&(v213_4));
        drop(v213_4);
        let v213_7: Space = if (v213_5).is_empty() { Space::new() } else {
          let v214_6: Space = routine_8(c, &(v209_15_head), &(v209_15_tail));
          compose(&(v213_5),&(v214_6))
        };
        drop(v213_5);
        let v213_8: Space = intersect(&(*CONSTANT_1),&(v213_2));
        drop(v213_2);
        let v213_9: Space = if has_head(&(v213_8)) { singleton(&[]) } else { Space::new() };
        drop(v213_8);
        let v213_11: Space = if (v213_9).is_empty() { Space::new() } else {
          let v215_10: Space = routine_9(c, &(v209_15_head), &(v209_15_tail));
          compose(&(v213_9),&(v215_10))
        };
        drop(v213_9);
        let v213_12: Space = unite(&(v213_7),&(v213_11));
        v209_15.join_into((v213_12).clone());
      }
      drop(v209_15_cursor);
      let v209_16: Space = subtract(&(v209_15),&(v209_11));
      drop(v209_11);
      let v209_17: Space = intersect(&(v209_16),&(v203_12));
      compose(&(v204_10),&(v209_17))
    };
    drop(v204_10);
    let v216_6: Path = concat_path(&(*p0),&(v203_22_head));
    let v204_19: Space = wrap(&(v204_18),&(v216_6));
    let v204_20: Space = unite(&(v204_8),&(v204_19));
    v203_22.join_into((v204_20).clone());
  }
  drop(v203_22_cursor);
  drop(v203_7);
  drop(v203_9);
  drop(v203_10);
  drop(v203_12);
  (v203_22).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v217_11 = Space::new();
  let mut v217_11_cursor = (*s0).read_zipper();
  for v217_11_byte in v217_11_cursor.child_mask().iter() {
    v217_11_cursor.descend_to_byte(v217_11_byte);
    let v217_11_tail = v217_11_cursor.make_map();
    v217_11_cursor.ascend(1);
    let v217_11_head = Path::from_slice(&[v217_11_byte]);
    let v218_2: Space = singleton(&(v217_11_head));
    let v218_3: Space = intersect(&(*CONSTANT_1),&(v218_2));
    let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
    drop(v218_3);
    let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
    drop(v218_4);
    let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
      let v219_6: Path = concat_path(&(*p0),&(v217_11_head));
      let mut v219_7 = Space::new();
      let mut v219_7_cursor = (v217_11_tail).read_zipper();
      for v219_7_byte in v219_7_cursor.child_mask().iter() {
        v219_7_cursor.descend_to_byte(v219_7_byte);
        let v219_7_tail = v219_7_cursor.make_map();
        v219_7_cursor.ascend(1);
        let v219_7_head = Path::from_slice(&[v219_7_byte]);
        let v220_2: Space = singleton(&(v219_7_head));
        let v220_3: Space = intersect(&(*CONSTANT_1),&(v220_2));
        let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
        drop(v220_3);
        let v220_5: Space = subtract(&(*CONSTANT_0),&(v220_4));
        drop(v220_4);
        let v220_8: Space = if (v220_5).is_empty() { Space::new() } else {
          let v221_6: Path = concat_path(&(v219_6),&(v219_7_head));
          let v221_7: Space = routine_34(c, &(v221_6), &(v219_7_tail));
          compose(&(v220_5),&(v221_7))
        };
        drop(v220_5);
        let v220_9: Space = intersect(&(*CONSTANT_1),&(v220_2));
        drop(v220_2);
        let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
        drop(v220_9);
        let v220_12: Space = if (v220_10).is_empty() { Space::new() } else {
          let v222_6: Path = concat_path(&(v219_6),&(v219_7_head));
          let v222_11: Space = routine_35(c, &(v222_6), &(v219_7_tail));
          drop(v222_6);
          compose(&(v220_10),&(v222_11))
        };
        drop(v220_10);
        let v220_13: Space = unite(&(v220_8),&(v220_12));
        v219_7.join_into((v220_13).clone());
      }
      drop(v219_7_cursor);
      compose(&(v218_5),&(v219_7))
    };
    drop(v218_5);
    let v218_9: Space = intersect(&(*CONSTANT_1),&(v218_2));
    drop(v218_2);
    let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
    drop(v218_9);
    let v218_12: Space = if (v218_10).is_empty() { Space::new() } else {
      let v223_6: Path = concat_path(&(*p0),&(v217_11_head));
      let mut v223_11 = Space::new();
      let mut v223_11_cursor = (v217_11_tail).read_zipper();
      for v223_11_byte in v223_11_cursor.child_mask().iter() {
        v223_11_cursor.descend_to_byte(v223_11_byte);
        let v223_11_tail = v223_11_cursor.make_map();
        v223_11_cursor.ascend(1);
        let v223_11_head = Path::from_slice(&[v223_11_byte]);
        let v224_2: Space = singleton(&(v223_11_head));
        let v224_3: Space = intersect(&(*CONSTANT_1),&(v224_2));
        let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
        drop(v224_3);
        let v224_5: Space = subtract(&(*CONSTANT_0),&(v224_4));
        drop(v224_4);
        let v224_8: Space = if (v224_5).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v223_6),&(v223_11_head));
          let v225_7: Space = routine_34(c, &(v225_6), &(v223_11_tail));
          compose(&(v224_5),&(v225_7))
        };
        drop(v224_5);
        let v224_9: Space = intersect(&(*CONSTANT_1),&(v224_2));
        drop(v224_2);
        let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
        drop(v224_9);
        let v224_12: Space = if (v224_10).is_empty() { Space::new() } else {
          let v226_6: Path = concat_path(&(v223_6),&(v223_11_head));
          let v226_11: Space = routine_14(c, &(v226_6), &(v223_11_tail));
          drop(v226_6);
          compose(&(v224_10),&(v226_11))
        };
        drop(v224_10);
        let v224_13: Space = unite(&(v224_8),&(v224_12));
        v223_11.join_into((v224_13).clone());
      }
      drop(v223_11_cursor);
      drop(v223_6);
      compose(&(v218_10),&(v223_11))
    };
    drop(v218_10);
    let v218_13: Space = unite(&(v218_8),&(v218_12));
    v217_11.join_into((v218_13).clone());
  }
  drop(v217_11_cursor);
  (v217_11).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v227_8 = Space::new();
  let mut v227_8_cursor = (*s0).read_zipper();
  for v227_8_byte in v227_8_cursor.child_mask().iter() {
    v227_8_cursor.descend_to_byte(v227_8_byte);
    let v227_8_tail = v227_8_cursor.make_map();
    v227_8_cursor.ascend(1);
    let v227_8_head = Path::from_slice(&[v227_8_byte]);
    let v228_2: Space = singleton(&(v227_8_head));
    let v228_3: Space = intersect(&(*CONSTANT_1),&(v228_2));
    let v228_4: Space = if has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
    drop(v228_3);
    let v228_5: Space = subtract(&(*CONSTANT_0),&(v228_4));
    drop(v228_4);
    let v228_8: Space = if (v228_5).is_empty() { Space::new() } else {
      let v229_6: Path = concat_path(&(*p0),&(v227_8_head));
      let mut v229_7 = Space::new();
      let mut v229_7_cursor = (v227_8_tail).read_zipper();
      for v229_7_byte in v229_7_cursor.child_mask().iter() {
        v229_7_cursor.descend_to_byte(v229_7_byte);
        let v229_7_tail = v229_7_cursor.make_map();
        v229_7_cursor.ascend(1);
        let v229_7_head = Path::from_slice(&[v229_7_byte]);
        let v230_2: Space = singleton(&(v229_7_head));
        let v230_3: Space = intersect(&(*CONSTANT_1),&(v230_2));
        let v230_4: Space = if has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
        drop(v230_3);
        let v230_5: Space = subtract(&(*CONSTANT_0),&(v230_4));
        drop(v230_4);
        let v230_8: Space = if (v230_5).is_empty() { Space::new() } else {
          let v231_6: Path = concat_path(&(v229_6),&(v229_7_head));
          let v231_7: Space = routine_34(c, &(v231_6), &(v229_7_tail));
          compose(&(v230_5),&(v231_7))
        };
        drop(v230_5);
        let v230_9: Space = intersect(&(*CONSTANT_1),&(v230_2));
        drop(v230_2);
        let v230_10: Space = if has_head(&(v230_9)) { singleton(&[]) } else { Space::new() };
        drop(v230_9);
        let v230_12: Space = if (v230_10).is_empty() { Space::new() } else {
          let v232_6: Path = concat_path(&(v229_6),&(v229_7_head));
          let v232_11: Space = routine_35(c, &(v232_6), &(v229_7_tail));
          drop(v232_6);
          compose(&(v230_10),&(v232_11))
        };
        drop(v230_10);
        let v230_13: Space = unite(&(v230_8),&(v230_12));
        v229_7.join_into((v230_13).clone());
      }
      drop(v229_7_cursor);
      drop(v229_6);
      compose(&(v228_5),&(v229_7))
    };
    drop(v228_5);
    let v228_9: Space = intersect(&(*CONSTANT_1),&(v228_2));
    drop(v228_2);
    let v228_10: Space = if has_head(&(v228_9)) { singleton(&[]) } else { Space::new() };
    drop(v228_9);
    let v228_11: Space = compose(&(v228_10),&(v227_8_tail));
    drop(v228_10);
    let v228_12: Space = unite(&(v228_8),&(v228_11));
    drop(v228_11);
    v227_8.join_into((v228_12).clone());
  }
  drop(v227_8_cursor);
  (v227_8).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v233_11 = Space::new();
  let mut v233_11_cursor = (*s0).read_zipper();
  for v233_11_byte in v233_11_cursor.child_mask().iter() {
    v233_11_cursor.descend_to_byte(v233_11_byte);
    let v233_11_tail = v233_11_cursor.make_map();
    v233_11_cursor.ascend(1);
    let v233_11_head = Path::from_slice(&[v233_11_byte]);
    let v234_2: Space = singleton(&(v233_11_head));
    let v234_3: Space = intersect(&(*CONSTANT_1),&(v234_2));
    let v234_4: Space = if has_head(&(v234_3)) { singleton(&[]) } else { Space::new() };
    drop(v234_3);
    let v234_5: Space = subtract(&(*CONSTANT_0),&(v234_4));
    drop(v234_4);
    let v234_8: Space = if (v234_5).is_empty() { Space::new() } else {
      let v235_6: Path = concat_path(&(*p0),&(v233_11_head));
      let mut v235_7 = Space::new();
      let mut v235_7_cursor = (v233_11_tail).read_zipper();
      for v235_7_byte in v235_7_cursor.child_mask().iter() {
        v235_7_cursor.descend_to_byte(v235_7_byte);
        let v235_7_tail = v235_7_cursor.make_map();
        v235_7_cursor.ascend(1);
        let v235_7_head = Path::from_slice(&[v235_7_byte]);
        let v236_2: Space = singleton(&(v235_7_head));
        let v236_3: Space = intersect(&(*CONSTANT_1),&(v236_2));
        let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
        drop(v236_3);
        let v236_5: Space = subtract(&(*CONSTANT_0),&(v236_4));
        drop(v236_4);
        let v236_8: Space = if (v236_5).is_empty() { Space::new() } else {
          let v237_6: Path = concat_path(&(v235_6),&(v235_7_head));
          let v237_7: Space = routine_36(c, &(v237_6), &(v235_7_tail));
          compose(&(v236_5),&(v237_7))
        };
        drop(v236_5);
        let v236_9: Space = intersect(&(*CONSTANT_1),&(v236_2));
        drop(v236_2);
        let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
        drop(v236_9);
        let v236_12: Space = if (v236_10).is_empty() { Space::new() } else {
          let v238_6: Path = concat_path(&(v235_6),&(v235_7_head));
          let v238_11: Space = routine_37(c, &(v238_6), &(v235_7_tail));
          drop(v238_6);
          compose(&(v236_10),&(v238_11))
        };
        drop(v236_10);
        let v236_13: Space = unite(&(v236_8),&(v236_12));
        v235_7.join_into((v236_13).clone());
      }
      drop(v235_7_cursor);
      compose(&(v234_5),&(v235_7))
    };
    drop(v234_5);
    let v234_9: Space = intersect(&(*CONSTANT_1),&(v234_2));
    drop(v234_2);
    let v234_10: Space = if has_head(&(v234_9)) { singleton(&[]) } else { Space::new() };
    drop(v234_9);
    let v234_12: Space = if (v234_10).is_empty() { Space::new() } else {
      let v239_6: Path = concat_path(&(*p0),&(v233_11_head));
      let mut v239_11 = Space::new();
      let mut v239_11_cursor = (v233_11_tail).read_zipper();
      for v239_11_byte in v239_11_cursor.child_mask().iter() {
        v239_11_cursor.descend_to_byte(v239_11_byte);
        let v239_11_tail = v239_11_cursor.make_map();
        v239_11_cursor.ascend(1);
        let v239_11_head = Path::from_slice(&[v239_11_byte]);
        let v240_2: Space = singleton(&(v239_11_head));
        let v240_3: Space = intersect(&(*CONSTANT_1),&(v240_2));
        let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
        drop(v240_3);
        let v240_5: Space = subtract(&(*CONSTANT_0),&(v240_4));
        drop(v240_4);
        let v240_8: Space = if (v240_5).is_empty() { Space::new() } else {
          let v241_6: Path = concat_path(&(v239_6),&(v239_11_head));
          let v241_7: Space = routine_36(c, &(v241_6), &(v239_11_tail));
          compose(&(v240_5),&(v241_7))
        };
        drop(v240_5);
        let v240_9: Space = intersect(&(*CONSTANT_1),&(v240_2));
        drop(v240_2);
        let v240_10: Space = if has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
        drop(v240_9);
        let v240_12: Space = if (v240_10).is_empty() { Space::new() } else {
          let v242_6: Path = concat_path(&(v239_6),&(v239_11_head));
          let v242_11: Space = routine_17(c, &(v242_6), &(v239_11_tail));
          drop(v242_6);
          compose(&(v240_10),&(v242_11))
        };
        drop(v240_10);
        let v240_13: Space = unite(&(v240_8),&(v240_12));
        v239_11.join_into((v240_13).clone());
      }
      drop(v239_11_cursor);
      drop(v239_6);
      compose(&(v234_10),&(v239_11))
    };
    drop(v234_10);
    let v234_13: Space = unite(&(v234_8),&(v234_12));
    v233_11.join_into((v234_13).clone());
  }
  drop(v233_11_cursor);
  (v233_11).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v243_8 = Space::new();
  let mut v243_8_cursor = (*s0).read_zipper();
  for v243_8_byte in v243_8_cursor.child_mask().iter() {
    v243_8_cursor.descend_to_byte(v243_8_byte);
    let v243_8_tail = v243_8_cursor.make_map();
    v243_8_cursor.ascend(1);
    let v243_8_head = Path::from_slice(&[v243_8_byte]);
    let v244_2: Space = singleton(&(v243_8_head));
    let v244_3: Space = intersect(&(*CONSTANT_1),&(v244_2));
    let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
    drop(v244_3);
    let v244_5: Space = subtract(&(*CONSTANT_0),&(v244_4));
    drop(v244_4);
    let v244_8: Space = if (v244_5).is_empty() { Space::new() } else {
      let v245_6: Path = concat_path(&(*p0),&(v243_8_head));
      let mut v245_7 = Space::new();
      let mut v245_7_cursor = (v243_8_tail).read_zipper();
      for v245_7_byte in v245_7_cursor.child_mask().iter() {
        v245_7_cursor.descend_to_byte(v245_7_byte);
        let v245_7_tail = v245_7_cursor.make_map();
        v245_7_cursor.ascend(1);
        let v245_7_head = Path::from_slice(&[v245_7_byte]);
        let v246_2: Space = singleton(&(v245_7_head));
        let v246_3: Space = intersect(&(*CONSTANT_1),&(v246_2));
        let v246_4: Space = if has_head(&(v246_3)) { singleton(&[]) } else { Space::new() };
        drop(v246_3);
        let v246_5: Space = subtract(&(*CONSTANT_0),&(v246_4));
        drop(v246_4);
        let v246_8: Space = if (v246_5).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v245_6),&(v245_7_head));
          let v247_7: Space = routine_36(c, &(v247_6), &(v245_7_tail));
          compose(&(v246_5),&(v247_7))
        };
        drop(v246_5);
        let v246_9: Space = intersect(&(*CONSTANT_1),&(v246_2));
        drop(v246_2);
        let v246_10: Space = if has_head(&(v246_9)) { singleton(&[]) } else { Space::new() };
        drop(v246_9);
        let v246_12: Space = if (v246_10).is_empty() { Space::new() } else {
          let v248_6: Path = concat_path(&(v245_6),&(v245_7_head));
          let v248_11: Space = routine_37(c, &(v248_6), &(v245_7_tail));
          drop(v248_6);
          compose(&(v246_10),&(v248_11))
        };
        drop(v246_10);
        let v246_13: Space = unite(&(v246_8),&(v246_12));
        v245_7.join_into((v246_13).clone());
      }
      drop(v245_7_cursor);
      drop(v245_6);
      compose(&(v244_5),&(v245_7))
    };
    drop(v244_5);
    let v244_9: Space = intersect(&(*CONSTANT_1),&(v244_2));
    drop(v244_2);
    let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
    drop(v244_9);
    let v244_11: Space = compose(&(v244_10),&(v243_8_tail));
    drop(v244_10);
    let v244_12: Space = unite(&(v244_8),&(v244_11));
    drop(v244_11);
    v243_8.join_into((v244_12).clone());
  }
  drop(v243_8_cursor);
  (v243_8).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v249_11 = Space::new();
  let mut v249_11_cursor = (*s0).read_zipper();
  for v249_11_byte in v249_11_cursor.child_mask().iter() {
    v249_11_cursor.descend_to_byte(v249_11_byte);
    let v249_11_tail = v249_11_cursor.make_map();
    v249_11_cursor.ascend(1);
    let v249_11_head = Path::from_slice(&[v249_11_byte]);
    let v250_2: Space = singleton(&(v249_11_head));
    let v250_3: Space = intersect(&(*CONSTANT_1),&(v250_2));
    let v250_4: Space = if has_head(&(v250_3)) { singleton(&[]) } else { Space::new() };
    drop(v250_3);
    let v250_5: Space = subtract(&(*CONSTANT_0),&(v250_4));
    drop(v250_4);
    let v250_8: Space = if (v250_5).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&(v249_11_head));
      let mut v251_7 = Space::new();
      let mut v251_7_cursor = (v249_11_tail).read_zipper();
      for v251_7_byte in v251_7_cursor.child_mask().iter() {
        v251_7_cursor.descend_to_byte(v251_7_byte);
        let v251_7_tail = v251_7_cursor.make_map();
        v251_7_cursor.ascend(1);
        let v251_7_head = Path::from_slice(&[v251_7_byte]);
        let v252_2: Space = singleton(&(v251_7_head));
        let v252_3: Space = intersect(&(*CONSTANT_1),&(v252_2));
        let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = subtract(&(*CONSTANT_0),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (v252_5).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&(v251_7_head));
          let v253_7: Space = routine_38(c, &(v253_6), &(v251_7_tail));
          compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = intersect(&(*CONSTANT_1),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_12: Space = if (v252_10).is_empty() { Space::new() } else {
          let v254_6: Path = concat_path(&(v251_6),&(v251_7_head));
          let v254_11: Space = routine_39(c, &(v254_6), &(v251_7_tail));
          drop(v254_6);
          compose(&(v252_10),&(v254_11))
        };
        drop(v252_10);
        let v252_13: Space = unite(&(v252_8),&(v252_12));
        v251_7.join_into((v252_13).clone());
      }
      drop(v251_7_cursor);
      compose(&(v250_5),&(v251_7))
    };
    drop(v250_5);
    let v250_9: Space = intersect(&(*CONSTANT_1),&(v250_2));
    drop(v250_2);
    let v250_10: Space = if has_head(&(v250_9)) { singleton(&[]) } else { Space::new() };
    drop(v250_9);
    let v250_12: Space = if (v250_10).is_empty() { Space::new() } else {
      let v255_6: Path = concat_path(&(*p0),&(v249_11_head));
      let mut v255_11 = Space::new();
      let mut v255_11_cursor = (v249_11_tail).read_zipper();
      for v255_11_byte in v255_11_cursor.child_mask().iter() {
        v255_11_cursor.descend_to_byte(v255_11_byte);
        let v255_11_tail = v255_11_cursor.make_map();
        v255_11_cursor.ascend(1);
        let v255_11_head = Path::from_slice(&[v255_11_byte]);
        let v256_2: Space = singleton(&(v255_11_head));
        let v256_3: Space = intersect(&(*CONSTANT_1),&(v256_2));
        let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
        drop(v256_3);
        let v256_5: Space = subtract(&(*CONSTANT_0),&(v256_4));
        drop(v256_4);
        let v256_8: Space = if (v256_5).is_empty() { Space::new() } else {
          let v257_6: Path = concat_path(&(v255_6),&(v255_11_head));
          let v257_7: Space = routine_38(c, &(v257_6), &(v255_11_tail));
          compose(&(v256_5),&(v257_7))
        };
        drop(v256_5);
        let v256_9: Space = intersect(&(*CONSTANT_1),&(v256_2));
        drop(v256_2);
        let v256_10: Space = if has_head(&(v256_9)) { singleton(&[]) } else { Space::new() };
        drop(v256_9);
        let v256_12: Space = if (v256_10).is_empty() { Space::new() } else {
          let v258_6: Path = concat_path(&(v255_6),&(v255_11_head));
          let v258_11: Space = routine_14(c, &(v258_6), &(v255_11_tail));
          drop(v258_6);
          compose(&(v256_10),&(v258_11))
        };
        drop(v256_10);
        let v256_13: Space = unite(&(v256_8),&(v256_12));
        v255_11.join_into((v256_13).clone());
      }
      drop(v255_11_cursor);
      drop(v255_6);
      compose(&(v250_10),&(v255_11))
    };
    drop(v250_10);
    let v250_13: Space = unite(&(v250_8),&(v250_12));
    v249_11.join_into((v250_13).clone());
  }
  drop(v249_11_cursor);
  (v249_11).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v259_8 = Space::new();
  let mut v259_8_cursor = (*s0).read_zipper();
  for v259_8_byte in v259_8_cursor.child_mask().iter() {
    v259_8_cursor.descend_to_byte(v259_8_byte);
    let v259_8_tail = v259_8_cursor.make_map();
    v259_8_cursor.ascend(1);
    let v259_8_head = Path::from_slice(&[v259_8_byte]);
    let v260_2: Space = singleton(&(v259_8_head));
    let v260_3: Space = intersect(&(*CONSTANT_1),&(v260_2));
    let v260_4: Space = if has_head(&(v260_3)) { singleton(&[]) } else { Space::new() };
    drop(v260_3);
    let v260_5: Space = subtract(&(*CONSTANT_0),&(v260_4));
    drop(v260_4);
    let v260_8: Space = if (v260_5).is_empty() { Space::new() } else {
      let v261_6: Path = concat_path(&(*p0),&(v259_8_head));
      let mut v261_7 = Space::new();
      let mut v261_7_cursor = (v259_8_tail).read_zipper();
      for v261_7_byte in v261_7_cursor.child_mask().iter() {
        v261_7_cursor.descend_to_byte(v261_7_byte);
        let v261_7_tail = v261_7_cursor.make_map();
        v261_7_cursor.ascend(1);
        let v261_7_head = Path::from_slice(&[v261_7_byte]);
        let v262_2: Space = singleton(&(v261_7_head));
        let v262_3: Space = intersect(&(*CONSTANT_1),&(v262_2));
        let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
        drop(v262_3);
        let v262_5: Space = subtract(&(*CONSTANT_0),&(v262_4));
        drop(v262_4);
        let v262_8: Space = if (v262_5).is_empty() { Space::new() } else {
          let v263_6: Path = concat_path(&(v261_6),&(v261_7_head));
          let v263_7: Space = routine_38(c, &(v263_6), &(v261_7_tail));
          compose(&(v262_5),&(v263_7))
        };
        drop(v262_5);
        let v262_9: Space = intersect(&(*CONSTANT_1),&(v262_2));
        drop(v262_2);
        let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
        drop(v262_9);
        let v262_12: Space = if (v262_10).is_empty() { Space::new() } else {
          let v264_6: Path = concat_path(&(v261_6),&(v261_7_head));
          let v264_11: Space = routine_39(c, &(v264_6), &(v261_7_tail));
          drop(v264_6);
          compose(&(v262_10),&(v264_11))
        };
        drop(v262_10);
        let v262_13: Space = unite(&(v262_8),&(v262_12));
        v261_7.join_into((v262_13).clone());
      }
      drop(v261_7_cursor);
      drop(v261_6);
      compose(&(v260_5),&(v261_7))
    };
    drop(v260_5);
    let v260_9: Space = intersect(&(*CONSTANT_1),&(v260_2));
    drop(v260_2);
    let v260_10: Space = if has_head(&(v260_9)) { singleton(&[]) } else { Space::new() };
    drop(v260_9);
    let v260_11: Space = compose(&(v260_10),&(v259_8_tail));
    drop(v260_10);
    let v260_12: Space = unite(&(v260_8),&(v260_11));
    drop(v260_11);
    v259_8.join_into((v260_12).clone());
  }
  drop(v259_8_cursor);
  (v259_8).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v265_11 = Space::new();
  let mut v265_11_cursor = (*s0).read_zipper();
  for v265_11_byte in v265_11_cursor.child_mask().iter() {
    v265_11_cursor.descend_to_byte(v265_11_byte);
    let v265_11_tail = v265_11_cursor.make_map();
    v265_11_cursor.ascend(1);
    let v265_11_head = Path::from_slice(&[v265_11_byte]);
    let v266_2: Space = singleton(&(v265_11_head));
    let v266_3: Space = intersect(&(*CONSTANT_1),&(v266_2));
    let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
    drop(v266_3);
    let v266_5: Space = subtract(&(*CONSTANT_0),&(v266_4));
    drop(v266_4);
    let v266_8: Space = if (v266_5).is_empty() { Space::new() } else {
      let v267_6: Path = concat_path(&(*p0),&(v265_11_head));
      let mut v267_7 = Space::new();
      let mut v267_7_cursor = (v265_11_tail).read_zipper();
      for v267_7_byte in v267_7_cursor.child_mask().iter() {
        v267_7_cursor.descend_to_byte(v267_7_byte);
        let v267_7_tail = v267_7_cursor.make_map();
        v267_7_cursor.ascend(1);
        let v267_7_head = Path::from_slice(&[v267_7_byte]);
        let v268_2: Space = singleton(&(v267_7_head));
        let v268_3: Space = intersect(&(*CONSTANT_1),&(v268_2));
        let v268_4: Space = if has_head(&(v268_3)) { singleton(&[]) } else { Space::new() };
        drop(v268_3);
        let v268_5: Space = subtract(&(*CONSTANT_0),&(v268_4));
        drop(v268_4);
        let v268_8: Space = if (v268_5).is_empty() { Space::new() } else {
          let v269_6: Path = concat_path(&(v267_6),&(v267_7_head));
          let v269_7: Space = routine_40(c, &(v269_6), &(v267_7_tail));
          compose(&(v268_5),&(v269_7))
        };
        drop(v268_5);
        let v268_9: Space = intersect(&(*CONSTANT_1),&(v268_2));
        drop(v268_2);
        let v268_10: Space = if has_head(&(v268_9)) { singleton(&[]) } else { Space::new() };
        drop(v268_9);
        let v268_12: Space = if (v268_10).is_empty() { Space::new() } else {
          let v270_6: Path = concat_path(&(v267_6),&(v267_7_head));
          let v270_11: Space = routine_41(c, &(v270_6), &(v267_7_tail));
          drop(v270_6);
          compose(&(v268_10),&(v270_11))
        };
        drop(v268_10);
        let v268_13: Space = unite(&(v268_8),&(v268_12));
        v267_7.join_into((v268_13).clone());
      }
      drop(v267_7_cursor);
      compose(&(v266_5),&(v267_7))
    };
    drop(v266_5);
    let v266_9: Space = intersect(&(*CONSTANT_1),&(v266_2));
    drop(v266_2);
    let v266_10: Space = if has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
    drop(v266_9);
    let v266_12: Space = if (v266_10).is_empty() { Space::new() } else {
      let v271_6: Path = concat_path(&(*p0),&(v265_11_head));
      let mut v271_11 = Space::new();
      let mut v271_11_cursor = (v265_11_tail).read_zipper();
      for v271_11_byte in v271_11_cursor.child_mask().iter() {
        v271_11_cursor.descend_to_byte(v271_11_byte);
        let v271_11_tail = v271_11_cursor.make_map();
        v271_11_cursor.ascend(1);
        let v271_11_head = Path::from_slice(&[v271_11_byte]);
        let v272_2: Space = singleton(&(v271_11_head));
        let v272_3: Space = intersect(&(*CONSTANT_1),&(v272_2));
        let v272_4: Space = if has_head(&(v272_3)) { singleton(&[]) } else { Space::new() };
        drop(v272_3);
        let v272_5: Space = subtract(&(*CONSTANT_0),&(v272_4));
        drop(v272_4);
        let v272_8: Space = if (v272_5).is_empty() { Space::new() } else {
          let v273_6: Path = concat_path(&(v271_6),&(v271_11_head));
          let v273_7: Space = routine_40(c, &(v273_6), &(v271_11_tail));
          compose(&(v272_5),&(v273_7))
        };
        drop(v272_5);
        let v272_9: Space = intersect(&(*CONSTANT_1),&(v272_2));
        drop(v272_2);
        let v272_10: Space = if has_head(&(v272_9)) { singleton(&[]) } else { Space::new() };
        drop(v272_9);
        let v272_12: Space = if (v272_10).is_empty() { Space::new() } else {
          let v274_6: Path = concat_path(&(v271_6),&(v271_11_head));
          let v274_11: Space = routine_17(c, &(v274_6), &(v271_11_tail));
          drop(v274_6);
          compose(&(v272_10),&(v274_11))
        };
        drop(v272_10);
        let v272_13: Space = unite(&(v272_8),&(v272_12));
        v271_11.join_into((v272_13).clone());
      }
      drop(v271_11_cursor);
      drop(v271_6);
      compose(&(v266_10),&(v271_11))
    };
    drop(v266_10);
    let v266_13: Space = unite(&(v266_8),&(v266_12));
    v265_11.join_into((v266_13).clone());
  }
  drop(v265_11_cursor);
  (v265_11).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v275_8 = Space::new();
  let mut v275_8_cursor = (*s0).read_zipper();
  for v275_8_byte in v275_8_cursor.child_mask().iter() {
    v275_8_cursor.descend_to_byte(v275_8_byte);
    let v275_8_tail = v275_8_cursor.make_map();
    v275_8_cursor.ascend(1);
    let v275_8_head = Path::from_slice(&[v275_8_byte]);
    let v276_2: Space = singleton(&(v275_8_head));
    let v276_3: Space = intersect(&(*CONSTANT_1),&(v276_2));
    let v276_4: Space = if has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
    drop(v276_3);
    let v276_5: Space = subtract(&(*CONSTANT_0),&(v276_4));
    drop(v276_4);
    let v276_8: Space = if (v276_5).is_empty() { Space::new() } else {
      let v277_6: Path = concat_path(&(*p0),&(v275_8_head));
      let mut v277_7 = Space::new();
      let mut v277_7_cursor = (v275_8_tail).read_zipper();
      for v277_7_byte in v277_7_cursor.child_mask().iter() {
        v277_7_cursor.descend_to_byte(v277_7_byte);
        let v277_7_tail = v277_7_cursor.make_map();
        v277_7_cursor.ascend(1);
        let v277_7_head = Path::from_slice(&[v277_7_byte]);
        let v278_2: Space = singleton(&(v277_7_head));
        let v278_3: Space = intersect(&(*CONSTANT_1),&(v278_2));
        let v278_4: Space = if has_head(&(v278_3)) { singleton(&[]) } else { Space::new() };
        drop(v278_3);
        let v278_5: Space = subtract(&(*CONSTANT_0),&(v278_4));
        drop(v278_4);
        let v278_8: Space = if (v278_5).is_empty() { Space::new() } else {
          let v279_6: Path = concat_path(&(v277_6),&(v277_7_head));
          let v279_7: Space = routine_40(c, &(v279_6), &(v277_7_tail));
          compose(&(v278_5),&(v279_7))
        };
        drop(v278_5);
        let v278_9: Space = intersect(&(*CONSTANT_1),&(v278_2));
        drop(v278_2);
        let v278_10: Space = if has_head(&(v278_9)) { singleton(&[]) } else { Space::new() };
        drop(v278_9);
        let v278_12: Space = if (v278_10).is_empty() { Space::new() } else {
          let v280_6: Path = concat_path(&(v277_6),&(v277_7_head));
          let v280_11: Space = routine_41(c, &(v280_6), &(v277_7_tail));
          drop(v280_6);
          compose(&(v278_10),&(v280_11))
        };
        drop(v278_10);
        let v278_13: Space = unite(&(v278_8),&(v278_12));
        v277_7.join_into((v278_13).clone());
      }
      drop(v277_7_cursor);
      drop(v277_6);
      compose(&(v276_5),&(v277_7))
    };
    drop(v276_5);
    let v276_9: Space = intersect(&(*CONSTANT_1),&(v276_2));
    drop(v276_2);
    let v276_10: Space = if has_head(&(v276_9)) { singleton(&[]) } else { Space::new() };
    drop(v276_9);
    let v276_11: Space = compose(&(v276_10),&(v275_8_tail));
    drop(v276_10);
    let v276_12: Space = unite(&(v276_8),&(v276_11));
    drop(v276_11);
    v275_8.join_into((v276_12).clone());
  }
  drop(v275_8_cursor);
  (v275_8).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v281_3 = Space::new();
  let mut v281_3_cursor = (*s0).read_zipper();
  for v281_3_byte in v281_3_cursor.child_mask().iter() {
    v281_3_cursor.descend_to_byte(v281_3_byte);
    let v281_3_tail = v281_3_cursor.make_map();
    v281_3_cursor.ascend(1);
    let v281_3_head = Path::from_slice(&[v281_3_byte]);
    let v282_2: Space = Space::new();
    v281_3.join_into((v282_2).clone());
  }
  drop(v281_3_cursor);
  (v281_3).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v283_5: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v283_7: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v283_8: Space = unwrap(&(v283_7),&(*p0));
  let v283_10: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v283_17 = Space::new();
  let mut v283_17_cursor = (*s0).read_zipper();
  for v283_17_byte in v283_17_cursor.child_mask().iter() {
    v283_17_cursor.descend_to_byte(v283_17_byte);
    let v283_17_tail = v283_17_cursor.make_map();
    v283_17_cursor.ascend(1);
    let v283_17_head = Path::from_slice(&[v283_17_byte]);
    let v284_2: Space = singleton(&(v283_17_head));
    let v284_3: Space = intersect(&(*CONSTANT_1),&(v284_2));
    drop(v284_2);
    let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_12: Space = if (v284_4).is_empty() { Space::new() } else {
      let v285_5: Space = unwrap(&(v283_8),&(v283_17_head));
      let v285_6: Space = restrict_to(&(v283_7),&(v285_5));
      let mut v285_7 = Space::new();
      let mut v285_7_cursor = (v285_6).read_zipper();
      for v285_7_byte in v285_7_cursor.child_mask().iter() {
        v285_7_cursor.descend_to_byte(v285_7_byte);
        let v285_7_tail = v285_7_cursor.make_map();
        v285_7_cursor.ascend(1);
        let v285_7_head = Path::from_slice(&[v285_7_byte]);
        let v286_2: Space = singleton(&(v285_7_head));
        let v286_3: Space = intersect(&(*CONSTANT_1),&(v286_2));
        let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = subtract(&(*CONSTANT_0),&(v286_4));
        drop(v286_4);
        let v286_7: Space = if (v286_5).is_empty() { Space::new() } else {
          let v287_6: Space = routine_6(c, &(v285_7_head), &(v285_7_tail));
          compose(&(v286_5),&(v287_6))
        };
        drop(v286_5);
        let v286_8: Space = intersect(&(*CONSTANT_1),&(v286_2));
        drop(v286_2);
        let v286_9: Space = if has_head(&(v286_8)) { singleton(&[]) } else { Space::new() };
        drop(v286_8);
        let v286_11: Space = if (v286_9).is_empty() { Space::new() } else {
          let v288_10: Space = routine_7(c, &(v285_7_head), &(v285_7_tail));
          compose(&(v286_9),&(v288_10))
        };
        drop(v286_9);
        let v286_12: Space = unite(&(v286_7),&(v286_11));
        v285_7.join_into((v286_12).clone());
      }
      drop(v285_7_cursor);
      drop(v285_6);
      let v285_8: Space = restrict_to(&(v283_5),&(v285_7));
      let mut v285_9 = Space::new();
      let mut v285_9_cursor = (v285_8).read_zipper();
      for v285_9_byte in v285_9_cursor.child_mask().iter() {
        v285_9_cursor.descend_to_byte(v285_9_byte);
        let v285_9_tail = v285_9_cursor.make_map();
        v285_9_cursor.ascend(1);
        let v285_9_head = Path::from_slice(&[v285_9_byte]);
        let v289_2: Space = singleton(&(v285_9_head));
        let v289_3: Space = intersect(&(*CONSTANT_1),&(v289_2));
        let v289_4: Space = if has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
        drop(v289_3);
        let v289_5: Space = subtract(&(*CONSTANT_0),&(v289_4));
        drop(v289_4);
        let v289_7: Space = if (v289_5).is_empty() { Space::new() } else {
          let v290_6: Space = routine_8(c, &(v285_9_head), &(v285_9_tail));
          compose(&(v289_5),&(v290_6))
        };
        drop(v289_5);
        let v289_8: Space = intersect(&(*CONSTANT_1),&(v289_2));
        drop(v289_2);
        let v289_9: Space = if has_head(&(v289_8)) { singleton(&[]) } else { Space::new() };
        drop(v289_8);
        let v289_11: Space = if (v289_9).is_empty() { Space::new() } else {
          let v291_10: Space = routine_9(c, &(v285_9_head), &(v285_9_tail));
          compose(&(v289_9),&(v291_10))
        };
        drop(v289_9);
        let v289_12: Space = unite(&(v289_7),&(v289_11));
        v285_9.join_into((v289_12).clone());
      }
      drop(v285_9_cursor);
      let v285_10: Space = subtract(&(v285_9),&(v285_5));
      drop(v285_5);
      let v285_11: Space = intersect(&(v285_10),&(v283_10));
      compose(&(v284_4),&(v285_11))
    };
    drop(v284_4);
    let v284_13: Path = concat_path(&(*p0),&(v283_17_head));
    let v284_14: Space = wrap(&(v284_12),&(v284_13));
    drop(v284_13);
    v283_17.join_into((v284_14).clone());
  }
  drop(v283_17_cursor);
  drop(v283_5);
  drop(v283_7);
  drop(v283_8);
  drop(v283_10);
  (v283_17).clone()
}

fn routine_34(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v292_11 = Space::new();
  let mut v292_11_cursor = (*s0).read_zipper();
  for v292_11_byte in v292_11_cursor.child_mask().iter() {
    v292_11_cursor.descend_to_byte(v292_11_byte);
    let v292_11_tail = v292_11_cursor.make_map();
    v292_11_cursor.ascend(1);
    let v292_11_head = Path::from_slice(&[v292_11_byte]);
    let v293_2: Space = singleton(&(v292_11_head));
    let v293_3: Space = intersect(&(*CONSTANT_1),&(v293_2));
    let v293_4: Space = if has_head(&(v293_3)) { singleton(&[]) } else { Space::new() };
    drop(v293_3);
    let v293_5: Space = subtract(&(*CONSTANT_0),&(v293_4));
    drop(v293_4);
    let v293_8: Space = if (v293_5).is_empty() { Space::new() } else {
      let v294_6: Path = concat_path(&(*p0),&(v292_11_head));
      let mut v294_7 = Space::new();
      let mut v294_7_cursor = (v292_11_tail).read_zipper();
      for v294_7_byte in v294_7_cursor.child_mask().iter() {
        v294_7_cursor.descend_to_byte(v294_7_byte);
        let v294_7_tail = v294_7_cursor.make_map();
        v294_7_cursor.ascend(1);
        let v294_7_head = Path::from_slice(&[v294_7_byte]);
        let v295_2: Space = singleton(&(v294_7_head));
        let v295_3: Space = intersect(&(*CONSTANT_1),&(v295_2));
        let v295_4: Space = if has_head(&(v295_3)) { singleton(&[]) } else { Space::new() };
        drop(v295_3);
        let v295_5: Space = subtract(&(*CONSTANT_0),&(v295_4));
        drop(v295_4);
        let v295_8: Space = if (v295_5).is_empty() { Space::new() } else {
          let v296_6: Path = concat_path(&(v294_6),&(v294_7_head));
          let v296_7: Space = routine_42(c, &(v296_6), &(v294_7_tail));
          compose(&(v295_5),&(v296_7))
        };
        drop(v295_5);
        let v295_9: Space = intersect(&(*CONSTANT_1),&(v295_2));
        drop(v295_2);
        let v295_10: Space = if has_head(&(v295_9)) { singleton(&[]) } else { Space::new() };
        drop(v295_9);
        let v295_12: Space = if (v295_10).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v294_6),&(v294_7_head));
          let v297_11: Space = routine_43(c, &(v297_6), &(v294_7_tail));
          drop(v297_6);
          compose(&(v295_10),&(v297_11))
        };
        drop(v295_10);
        let v295_13: Space = unite(&(v295_8),&(v295_12));
        v294_7.join_into((v295_13).clone());
      }
      drop(v294_7_cursor);
      compose(&(v293_5),&(v294_7))
    };
    drop(v293_5);
    let v293_9: Space = intersect(&(*CONSTANT_1),&(v293_2));
    drop(v293_2);
    let v293_10: Space = if has_head(&(v293_9)) { singleton(&[]) } else { Space::new() };
    drop(v293_9);
    let v293_12: Space = if (v293_10).is_empty() { Space::new() } else {
      let v298_6: Path = concat_path(&(*p0),&(v292_11_head));
      let mut v298_11 = Space::new();
      let mut v298_11_cursor = (v292_11_tail).read_zipper();
      for v298_11_byte in v298_11_cursor.child_mask().iter() {
        v298_11_cursor.descend_to_byte(v298_11_byte);
        let v298_11_tail = v298_11_cursor.make_map();
        v298_11_cursor.ascend(1);
        let v298_11_head = Path::from_slice(&[v298_11_byte]);
        let v299_2: Space = singleton(&(v298_11_head));
        let v299_3: Space = intersect(&(*CONSTANT_1),&(v299_2));
        let v299_4: Space = if has_head(&(v299_3)) { singleton(&[]) } else { Space::new() };
        drop(v299_3);
        let v299_5: Space = subtract(&(*CONSTANT_0),&(v299_4));
        drop(v299_4);
        let v299_8: Space = if (v299_5).is_empty() { Space::new() } else {
          let v300_6: Path = concat_path(&(v298_6),&(v298_11_head));
          let v300_7: Space = routine_42(c, &(v300_6), &(v298_11_tail));
          compose(&(v299_5),&(v300_7))
        };
        drop(v299_5);
        let v299_9: Space = intersect(&(*CONSTANT_1),&(v299_2));
        drop(v299_2);
        let v299_10: Space = if has_head(&(v299_9)) { singleton(&[]) } else { Space::new() };
        drop(v299_9);
        let v299_12: Space = if (v299_10).is_empty() { Space::new() } else {
          let v301_6: Path = concat_path(&(v298_6),&(v298_11_head));
          let v301_11: Space = routine_14(c, &(v301_6), &(v298_11_tail));
          drop(v301_6);
          compose(&(v299_10),&(v301_11))
        };
        drop(v299_10);
        let v299_13: Space = unite(&(v299_8),&(v299_12));
        v298_11.join_into((v299_13).clone());
      }
      drop(v298_11_cursor);
      drop(v298_6);
      compose(&(v293_10),&(v298_11))
    };
    drop(v293_10);
    let v293_13: Space = unite(&(v293_8),&(v293_12));
    v292_11.join_into((v293_13).clone());
  }
  drop(v292_11_cursor);
  (v292_11).clone()
}

fn routine_35(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v302_8 = Space::new();
  let mut v302_8_cursor = (*s0).read_zipper();
  for v302_8_byte in v302_8_cursor.child_mask().iter() {
    v302_8_cursor.descend_to_byte(v302_8_byte);
    let v302_8_tail = v302_8_cursor.make_map();
    v302_8_cursor.ascend(1);
    let v302_8_head = Path::from_slice(&[v302_8_byte]);
    let v303_2: Space = singleton(&(v302_8_head));
    let v303_3: Space = intersect(&(*CONSTANT_1),&(v303_2));
    let v303_4: Space = if has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
    drop(v303_3);
    let v303_5: Space = subtract(&(*CONSTANT_0),&(v303_4));
    drop(v303_4);
    let v303_8: Space = if (v303_5).is_empty() { Space::new() } else {
      let v304_6: Path = concat_path(&(*p0),&(v302_8_head));
      let mut v304_7 = Space::new();
      let mut v304_7_cursor = (v302_8_tail).read_zipper();
      for v304_7_byte in v304_7_cursor.child_mask().iter() {
        v304_7_cursor.descend_to_byte(v304_7_byte);
        let v304_7_tail = v304_7_cursor.make_map();
        v304_7_cursor.ascend(1);
        let v304_7_head = Path::from_slice(&[v304_7_byte]);
        let v305_2: Space = singleton(&(v304_7_head));
        let v305_3: Space = intersect(&(*CONSTANT_1),&(v305_2));
        let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
        drop(v305_3);
        let v305_5: Space = subtract(&(*CONSTANT_0),&(v305_4));
        drop(v305_4);
        let v305_8: Space = if (v305_5).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v304_6),&(v304_7_head));
          let v306_7: Space = routine_42(c, &(v306_6), &(v304_7_tail));
          compose(&(v305_5),&(v306_7))
        };
        drop(v305_5);
        let v305_9: Space = intersect(&(*CONSTANT_1),&(v305_2));
        drop(v305_2);
        let v305_10: Space = if has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
        drop(v305_9);
        let v305_12: Space = if (v305_10).is_empty() { Space::new() } else {
          let v307_6: Path = concat_path(&(v304_6),&(v304_7_head));
          let v307_11: Space = routine_43(c, &(v307_6), &(v304_7_tail));
          drop(v307_6);
          compose(&(v305_10),&(v307_11))
        };
        drop(v305_10);
        let v305_13: Space = unite(&(v305_8),&(v305_12));
        v304_7.join_into((v305_13).clone());
      }
      drop(v304_7_cursor);
      drop(v304_6);
      compose(&(v303_5),&(v304_7))
    };
    drop(v303_5);
    let v303_9: Space = intersect(&(*CONSTANT_1),&(v303_2));
    drop(v303_2);
    let v303_10: Space = if has_head(&(v303_9)) { singleton(&[]) } else { Space::new() };
    drop(v303_9);
    let v303_11: Space = compose(&(v303_10),&(v302_8_tail));
    drop(v303_10);
    let v303_12: Space = unite(&(v303_8),&(v303_11));
    drop(v303_11);
    v302_8.join_into((v303_12).clone());
  }
  drop(v302_8_cursor);
  (v302_8).clone()
}

fn routine_36(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v308_11 = Space::new();
  let mut v308_11_cursor = (*s0).read_zipper();
  for v308_11_byte in v308_11_cursor.child_mask().iter() {
    v308_11_cursor.descend_to_byte(v308_11_byte);
    let v308_11_tail = v308_11_cursor.make_map();
    v308_11_cursor.ascend(1);
    let v308_11_head = Path::from_slice(&[v308_11_byte]);
    let v309_2: Space = singleton(&(v308_11_head));
    let v309_3: Space = intersect(&(*CONSTANT_1),&(v309_2));
    let v309_4: Space = if has_head(&(v309_3)) { singleton(&[]) } else { Space::new() };
    drop(v309_3);
    let v309_5: Space = subtract(&(*CONSTANT_0),&(v309_4));
    drop(v309_4);
    let v309_8: Space = if (v309_5).is_empty() { Space::new() } else {
      let v310_6: Path = concat_path(&(*p0),&(v308_11_head));
      let mut v310_7 = Space::new();
      let mut v310_7_cursor = (v308_11_tail).read_zipper();
      for v310_7_byte in v310_7_cursor.child_mask().iter() {
        v310_7_cursor.descend_to_byte(v310_7_byte);
        let v310_7_tail = v310_7_cursor.make_map();
        v310_7_cursor.ascend(1);
        let v310_7_head = Path::from_slice(&[v310_7_byte]);
        let v311_2: Space = singleton(&(v310_7_head));
        let v311_3: Space = intersect(&(*CONSTANT_1),&(v311_2));
        let v311_4: Space = if has_head(&(v311_3)) { singleton(&[]) } else { Space::new() };
        drop(v311_3);
        let v311_5: Space = subtract(&(*CONSTANT_0),&(v311_4));
        drop(v311_4);
        let v311_8: Space = if (v311_5).is_empty() { Space::new() } else {
          let v312_6: Path = concat_path(&(v310_6),&(v310_7_head));
          let v312_7: Space = routine_44(c, &(v312_6), &(v310_7_tail));
          compose(&(v311_5),&(v312_7))
        };
        drop(v311_5);
        let v311_9: Space = intersect(&(*CONSTANT_1),&(v311_2));
        drop(v311_2);
        let v311_10: Space = if has_head(&(v311_9)) { singleton(&[]) } else { Space::new() };
        drop(v311_9);
        let v311_12: Space = if (v311_10).is_empty() { Space::new() } else {
          let v313_6: Path = concat_path(&(v310_6),&(v310_7_head));
          let v313_11: Space = routine_45(c, &(v313_6), &(v310_7_tail));
          drop(v313_6);
          compose(&(v311_10),&(v313_11))
        };
        drop(v311_10);
        let v311_13: Space = unite(&(v311_8),&(v311_12));
        v310_7.join_into((v311_13).clone());
      }
      drop(v310_7_cursor);
      compose(&(v309_5),&(v310_7))
    };
    drop(v309_5);
    let v309_9: Space = intersect(&(*CONSTANT_1),&(v309_2));
    drop(v309_2);
    let v309_10: Space = if has_head(&(v309_9)) { singleton(&[]) } else { Space::new() };
    drop(v309_9);
    let v309_12: Space = if (v309_10).is_empty() { Space::new() } else {
      let v314_6: Path = concat_path(&(*p0),&(v308_11_head));
      let mut v314_11 = Space::new();
      let mut v314_11_cursor = (v308_11_tail).read_zipper();
      for v314_11_byte in v314_11_cursor.child_mask().iter() {
        v314_11_cursor.descend_to_byte(v314_11_byte);
        let v314_11_tail = v314_11_cursor.make_map();
        v314_11_cursor.ascend(1);
        let v314_11_head = Path::from_slice(&[v314_11_byte]);
        let v315_2: Space = singleton(&(v314_11_head));
        let v315_3: Space = intersect(&(*CONSTANT_1),&(v315_2));
        let v315_4: Space = if has_head(&(v315_3)) { singleton(&[]) } else { Space::new() };
        drop(v315_3);
        let v315_5: Space = subtract(&(*CONSTANT_0),&(v315_4));
        drop(v315_4);
        let v315_8: Space = if (v315_5).is_empty() { Space::new() } else {
          let v316_6: Path = concat_path(&(v314_6),&(v314_11_head));
          let v316_7: Space = routine_44(c, &(v316_6), &(v314_11_tail));
          compose(&(v315_5),&(v316_7))
        };
        drop(v315_5);
        let v315_9: Space = intersect(&(*CONSTANT_1),&(v315_2));
        drop(v315_2);
        let v315_10: Space = if has_head(&(v315_9)) { singleton(&[]) } else { Space::new() };
        drop(v315_9);
        let v315_12: Space = if (v315_10).is_empty() { Space::new() } else {
          let v317_6: Path = concat_path(&(v314_6),&(v314_11_head));
          let v317_11: Space = routine_17(c, &(v317_6), &(v314_11_tail));
          drop(v317_6);
          compose(&(v315_10),&(v317_11))
        };
        drop(v315_10);
        let v315_13: Space = unite(&(v315_8),&(v315_12));
        v314_11.join_into((v315_13).clone());
      }
      drop(v314_11_cursor);
      drop(v314_6);
      compose(&(v309_10),&(v314_11))
    };
    drop(v309_10);
    let v309_13: Space = unite(&(v309_8),&(v309_12));
    v308_11.join_into((v309_13).clone());
  }
  drop(v308_11_cursor);
  (v308_11).clone()
}

fn routine_37(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v318_8 = Space::new();
  let mut v318_8_cursor = (*s0).read_zipper();
  for v318_8_byte in v318_8_cursor.child_mask().iter() {
    v318_8_cursor.descend_to_byte(v318_8_byte);
    let v318_8_tail = v318_8_cursor.make_map();
    v318_8_cursor.ascend(1);
    let v318_8_head = Path::from_slice(&[v318_8_byte]);
    let v319_2: Space = singleton(&(v318_8_head));
    let v319_3: Space = intersect(&(*CONSTANT_1),&(v319_2));
    let v319_4: Space = if has_head(&(v319_3)) { singleton(&[]) } else { Space::new() };
    drop(v319_3);
    let v319_5: Space = subtract(&(*CONSTANT_0),&(v319_4));
    drop(v319_4);
    let v319_8: Space = if (v319_5).is_empty() { Space::new() } else {
      let v320_6: Path = concat_path(&(*p0),&(v318_8_head));
      let mut v320_7 = Space::new();
      let mut v320_7_cursor = (v318_8_tail).read_zipper();
      for v320_7_byte in v320_7_cursor.child_mask().iter() {
        v320_7_cursor.descend_to_byte(v320_7_byte);
        let v320_7_tail = v320_7_cursor.make_map();
        v320_7_cursor.ascend(1);
        let v320_7_head = Path::from_slice(&[v320_7_byte]);
        let v321_2: Space = singleton(&(v320_7_head));
        let v321_3: Space = intersect(&(*CONSTANT_1),&(v321_2));
        let v321_4: Space = if has_head(&(v321_3)) { singleton(&[]) } else { Space::new() };
        drop(v321_3);
        let v321_5: Space = subtract(&(*CONSTANT_0),&(v321_4));
        drop(v321_4);
        let v321_8: Space = if (v321_5).is_empty() { Space::new() } else {
          let v322_6: Path = concat_path(&(v320_6),&(v320_7_head));
          let v322_7: Space = routine_44(c, &(v322_6), &(v320_7_tail));
          compose(&(v321_5),&(v322_7))
        };
        drop(v321_5);
        let v321_9: Space = intersect(&(*CONSTANT_1),&(v321_2));
        drop(v321_2);
        let v321_10: Space = if has_head(&(v321_9)) { singleton(&[]) } else { Space::new() };
        drop(v321_9);
        let v321_12: Space = if (v321_10).is_empty() { Space::new() } else {
          let v323_6: Path = concat_path(&(v320_6),&(v320_7_head));
          let v323_11: Space = routine_45(c, &(v323_6), &(v320_7_tail));
          drop(v323_6);
          compose(&(v321_10),&(v323_11))
        };
        drop(v321_10);
        let v321_13: Space = unite(&(v321_8),&(v321_12));
        v320_7.join_into((v321_13).clone());
      }
      drop(v320_7_cursor);
      drop(v320_6);
      compose(&(v319_5),&(v320_7))
    };
    drop(v319_5);
    let v319_9: Space = intersect(&(*CONSTANT_1),&(v319_2));
    drop(v319_2);
    let v319_10: Space = if has_head(&(v319_9)) { singleton(&[]) } else { Space::new() };
    drop(v319_9);
    let v319_11: Space = compose(&(v319_10),&(v318_8_tail));
    drop(v319_10);
    let v319_12: Space = unite(&(v319_8),&(v319_11));
    drop(v319_11);
    v318_8.join_into((v319_12).clone());
  }
  drop(v318_8_cursor);
  (v318_8).clone()
}

fn routine_38(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v324_11 = Space::new();
  let mut v324_11_cursor = (*s0).read_zipper();
  for v324_11_byte in v324_11_cursor.child_mask().iter() {
    v324_11_cursor.descend_to_byte(v324_11_byte);
    let v324_11_tail = v324_11_cursor.make_map();
    v324_11_cursor.ascend(1);
    let v324_11_head = Path::from_slice(&[v324_11_byte]);
    let v325_2: Space = singleton(&(v324_11_head));
    let v325_3: Space = intersect(&(*CONSTANT_1),&(v325_2));
    let v325_4: Space = if has_head(&(v325_3)) { singleton(&[]) } else { Space::new() };
    drop(v325_3);
    let v325_5: Space = subtract(&(*CONSTANT_0),&(v325_4));
    drop(v325_4);
    let v325_8: Space = if (v325_5).is_empty() { Space::new() } else {
      let v326_6: Path = concat_path(&(*p0),&(v324_11_head));
      let mut v326_7 = Space::new();
      let mut v326_7_cursor = (v324_11_tail).read_zipper();
      for v326_7_byte in v326_7_cursor.child_mask().iter() {
        v326_7_cursor.descend_to_byte(v326_7_byte);
        let v326_7_tail = v326_7_cursor.make_map();
        v326_7_cursor.ascend(1);
        let v326_7_head = Path::from_slice(&[v326_7_byte]);
        let v327_2: Space = singleton(&(v326_7_head));
        let v327_3: Space = intersect(&(*CONSTANT_1),&(v327_2));
        let v327_4: Space = if has_head(&(v327_3)) { singleton(&[]) } else { Space::new() };
        drop(v327_3);
        let v327_5: Space = subtract(&(*CONSTANT_0),&(v327_4));
        drop(v327_4);
        let v327_8: Space = if (v327_5).is_empty() { Space::new() } else {
          let v328_6: Path = concat_path(&(v326_6),&(v326_7_head));
          let v328_7: Space = routine_46(c, &(v328_6), &(v326_7_tail));
          compose(&(v327_5),&(v328_7))
        };
        drop(v327_5);
        let v327_9: Space = intersect(&(*CONSTANT_1),&(v327_2));
        drop(v327_2);
        let v327_10: Space = if has_head(&(v327_9)) { singleton(&[]) } else { Space::new() };
        drop(v327_9);
        let v327_12: Space = if (v327_10).is_empty() { Space::new() } else {
          let v329_6: Path = concat_path(&(v326_6),&(v326_7_head));
          let v329_11: Space = routine_47(c, &(v329_6), &(v326_7_tail));
          drop(v329_6);
          compose(&(v327_10),&(v329_11))
        };
        drop(v327_10);
        let v327_13: Space = unite(&(v327_8),&(v327_12));
        v326_7.join_into((v327_13).clone());
      }
      drop(v326_7_cursor);
      compose(&(v325_5),&(v326_7))
    };
    drop(v325_5);
    let v325_9: Space = intersect(&(*CONSTANT_1),&(v325_2));
    drop(v325_2);
    let v325_10: Space = if has_head(&(v325_9)) { singleton(&[]) } else { Space::new() };
    drop(v325_9);
    let v325_12: Space = if (v325_10).is_empty() { Space::new() } else {
      let v330_6: Path = concat_path(&(*p0),&(v324_11_head));
      let mut v330_11 = Space::new();
      let mut v330_11_cursor = (v324_11_tail).read_zipper();
      for v330_11_byte in v330_11_cursor.child_mask().iter() {
        v330_11_cursor.descend_to_byte(v330_11_byte);
        let v330_11_tail = v330_11_cursor.make_map();
        v330_11_cursor.ascend(1);
        let v330_11_head = Path::from_slice(&[v330_11_byte]);
        let v331_2: Space = singleton(&(v330_11_head));
        let v331_3: Space = intersect(&(*CONSTANT_1),&(v331_2));
        let v331_4: Space = if has_head(&(v331_3)) { singleton(&[]) } else { Space::new() };
        drop(v331_3);
        let v331_5: Space = subtract(&(*CONSTANT_0),&(v331_4));
        drop(v331_4);
        let v331_8: Space = if (v331_5).is_empty() { Space::new() } else {
          let v332_6: Path = concat_path(&(v330_6),&(v330_11_head));
          let v332_7: Space = routine_46(c, &(v332_6), &(v330_11_tail));
          compose(&(v331_5),&(v332_7))
        };
        drop(v331_5);
        let v331_9: Space = intersect(&(*CONSTANT_1),&(v331_2));
        drop(v331_2);
        let v331_10: Space = if has_head(&(v331_9)) { singleton(&[]) } else { Space::new() };
        drop(v331_9);
        let v331_12: Space = if (v331_10).is_empty() { Space::new() } else {
          let v333_6: Path = concat_path(&(v330_6),&(v330_11_head));
          let v333_11: Space = routine_14(c, &(v333_6), &(v330_11_tail));
          drop(v333_6);
          compose(&(v331_10),&(v333_11))
        };
        drop(v331_10);
        let v331_13: Space = unite(&(v331_8),&(v331_12));
        v330_11.join_into((v331_13).clone());
      }
      drop(v330_11_cursor);
      drop(v330_6);
      compose(&(v325_10),&(v330_11))
    };
    drop(v325_10);
    let v325_13: Space = unite(&(v325_8),&(v325_12));
    v324_11.join_into((v325_13).clone());
  }
  drop(v324_11_cursor);
  (v324_11).clone()
}

fn routine_39(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v334_8 = Space::new();
  let mut v334_8_cursor = (*s0).read_zipper();
  for v334_8_byte in v334_8_cursor.child_mask().iter() {
    v334_8_cursor.descend_to_byte(v334_8_byte);
    let v334_8_tail = v334_8_cursor.make_map();
    v334_8_cursor.ascend(1);
    let v334_8_head = Path::from_slice(&[v334_8_byte]);
    let v335_2: Space = singleton(&(v334_8_head));
    let v335_3: Space = intersect(&(*CONSTANT_1),&(v335_2));
    let v335_4: Space = if has_head(&(v335_3)) { singleton(&[]) } else { Space::new() };
    drop(v335_3);
    let v335_5: Space = subtract(&(*CONSTANT_0),&(v335_4));
    drop(v335_4);
    let v335_8: Space = if (v335_5).is_empty() { Space::new() } else {
      let v336_6: Path = concat_path(&(*p0),&(v334_8_head));
      let mut v336_7 = Space::new();
      let mut v336_7_cursor = (v334_8_tail).read_zipper();
      for v336_7_byte in v336_7_cursor.child_mask().iter() {
        v336_7_cursor.descend_to_byte(v336_7_byte);
        let v336_7_tail = v336_7_cursor.make_map();
        v336_7_cursor.ascend(1);
        let v336_7_head = Path::from_slice(&[v336_7_byte]);
        let v337_2: Space = singleton(&(v336_7_head));
        let v337_3: Space = intersect(&(*CONSTANT_1),&(v337_2));
        let v337_4: Space = if has_head(&(v337_3)) { singleton(&[]) } else { Space::new() };
        drop(v337_3);
        let v337_5: Space = subtract(&(*CONSTANT_0),&(v337_4));
        drop(v337_4);
        let v337_8: Space = if (v337_5).is_empty() { Space::new() } else {
          let v338_6: Path = concat_path(&(v336_6),&(v336_7_head));
          let v338_7: Space = routine_46(c, &(v338_6), &(v336_7_tail));
          compose(&(v337_5),&(v338_7))
        };
        drop(v337_5);
        let v337_9: Space = intersect(&(*CONSTANT_1),&(v337_2));
        drop(v337_2);
        let v337_10: Space = if has_head(&(v337_9)) { singleton(&[]) } else { Space::new() };
        drop(v337_9);
        let v337_12: Space = if (v337_10).is_empty() { Space::new() } else {
          let v339_6: Path = concat_path(&(v336_6),&(v336_7_head));
          let v339_11: Space = routine_47(c, &(v339_6), &(v336_7_tail));
          drop(v339_6);
          compose(&(v337_10),&(v339_11))
        };
        drop(v337_10);
        let v337_13: Space = unite(&(v337_8),&(v337_12));
        v336_7.join_into((v337_13).clone());
      }
      drop(v336_7_cursor);
      drop(v336_6);
      compose(&(v335_5),&(v336_7))
    };
    drop(v335_5);
    let v335_9: Space = intersect(&(*CONSTANT_1),&(v335_2));
    drop(v335_2);
    let v335_10: Space = if has_head(&(v335_9)) { singleton(&[]) } else { Space::new() };
    drop(v335_9);
    let v335_11: Space = compose(&(v335_10),&(v334_8_tail));
    drop(v335_10);
    let v335_12: Space = unite(&(v335_8),&(v335_11));
    drop(v335_11);
    v334_8.join_into((v335_12).clone());
  }
  drop(v334_8_cursor);
  (v334_8).clone()
}

fn routine_40(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v340_11 = Space::new();
  let mut v340_11_cursor = (*s0).read_zipper();
  for v340_11_byte in v340_11_cursor.child_mask().iter() {
    v340_11_cursor.descend_to_byte(v340_11_byte);
    let v340_11_tail = v340_11_cursor.make_map();
    v340_11_cursor.ascend(1);
    let v340_11_head = Path::from_slice(&[v340_11_byte]);
    let v341_2: Space = singleton(&(v340_11_head));
    let v341_3: Space = intersect(&(*CONSTANT_1),&(v341_2));
    let v341_4: Space = if has_head(&(v341_3)) { singleton(&[]) } else { Space::new() };
    drop(v341_3);
    let v341_5: Space = subtract(&(*CONSTANT_0),&(v341_4));
    drop(v341_4);
    let v341_8: Space = if (v341_5).is_empty() { Space::new() } else {
      let v342_6: Path = concat_path(&(*p0),&(v340_11_head));
      let mut v342_7 = Space::new();
      let mut v342_7_cursor = (v340_11_tail).read_zipper();
      for v342_7_byte in v342_7_cursor.child_mask().iter() {
        v342_7_cursor.descend_to_byte(v342_7_byte);
        let v342_7_tail = v342_7_cursor.make_map();
        v342_7_cursor.ascend(1);
        let v342_7_head = Path::from_slice(&[v342_7_byte]);
        let v343_2: Space = singleton(&(v342_7_head));
        let v343_3: Space = intersect(&(*CONSTANT_1),&(v343_2));
        let v343_4: Space = if has_head(&(v343_3)) { singleton(&[]) } else { Space::new() };
        drop(v343_3);
        let v343_5: Space = subtract(&(*CONSTANT_0),&(v343_4));
        drop(v343_4);
        let v343_8: Space = if (v343_5).is_empty() { Space::new() } else {
          let v344_6: Path = concat_path(&(v342_6),&(v342_7_head));
          let v344_7: Space = routine_48(c, &(v344_6), &(v342_7_tail));
          compose(&(v343_5),&(v344_7))
        };
        drop(v343_5);
        let v343_9: Space = intersect(&(*CONSTANT_1),&(v343_2));
        drop(v343_2);
        let v343_10: Space = if has_head(&(v343_9)) { singleton(&[]) } else { Space::new() };
        drop(v343_9);
        let v343_12: Space = if (v343_10).is_empty() { Space::new() } else {
          let v345_6: Path = concat_path(&(v342_6),&(v342_7_head));
          let v345_11: Space = routine_49(c, &(v345_6), &(v342_7_tail));
          drop(v345_6);
          compose(&(v343_10),&(v345_11))
        };
        drop(v343_10);
        let v343_13: Space = unite(&(v343_8),&(v343_12));
        v342_7.join_into((v343_13).clone());
      }
      drop(v342_7_cursor);
      compose(&(v341_5),&(v342_7))
    };
    drop(v341_5);
    let v341_9: Space = intersect(&(*CONSTANT_1),&(v341_2));
    drop(v341_2);
    let v341_10: Space = if has_head(&(v341_9)) { singleton(&[]) } else { Space::new() };
    drop(v341_9);
    let v341_12: Space = if (v341_10).is_empty() { Space::new() } else {
      let v346_6: Path = concat_path(&(*p0),&(v340_11_head));
      let mut v346_11 = Space::new();
      let mut v346_11_cursor = (v340_11_tail).read_zipper();
      for v346_11_byte in v346_11_cursor.child_mask().iter() {
        v346_11_cursor.descend_to_byte(v346_11_byte);
        let v346_11_tail = v346_11_cursor.make_map();
        v346_11_cursor.ascend(1);
        let v346_11_head = Path::from_slice(&[v346_11_byte]);
        let v347_2: Space = singleton(&(v346_11_head));
        let v347_3: Space = intersect(&(*CONSTANT_1),&(v347_2));
        let v347_4: Space = if has_head(&(v347_3)) { singleton(&[]) } else { Space::new() };
        drop(v347_3);
        let v347_5: Space = subtract(&(*CONSTANT_0),&(v347_4));
        drop(v347_4);
        let v347_8: Space = if (v347_5).is_empty() { Space::new() } else {
          let v348_6: Path = concat_path(&(v346_6),&(v346_11_head));
          let v348_7: Space = routine_48(c, &(v348_6), &(v346_11_tail));
          compose(&(v347_5),&(v348_7))
        };
        drop(v347_5);
        let v347_9: Space = intersect(&(*CONSTANT_1),&(v347_2));
        drop(v347_2);
        let v347_10: Space = if has_head(&(v347_9)) { singleton(&[]) } else { Space::new() };
        drop(v347_9);
        let v347_12: Space = if (v347_10).is_empty() { Space::new() } else {
          let v349_6: Path = concat_path(&(v346_6),&(v346_11_head));
          let v349_11: Space = routine_17(c, &(v349_6), &(v346_11_tail));
          drop(v349_6);
          compose(&(v347_10),&(v349_11))
        };
        drop(v347_10);
        let v347_13: Space = unite(&(v347_8),&(v347_12));
        v346_11.join_into((v347_13).clone());
      }
      drop(v346_11_cursor);
      drop(v346_6);
      compose(&(v341_10),&(v346_11))
    };
    drop(v341_10);
    let v341_13: Space = unite(&(v341_8),&(v341_12));
    v340_11.join_into((v341_13).clone());
  }
  drop(v340_11_cursor);
  (v340_11).clone()
}

fn routine_41(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v350_8 = Space::new();
  let mut v350_8_cursor = (*s0).read_zipper();
  for v350_8_byte in v350_8_cursor.child_mask().iter() {
    v350_8_cursor.descend_to_byte(v350_8_byte);
    let v350_8_tail = v350_8_cursor.make_map();
    v350_8_cursor.ascend(1);
    let v350_8_head = Path::from_slice(&[v350_8_byte]);
    let v351_2: Space = singleton(&(v350_8_head));
    let v351_3: Space = intersect(&(*CONSTANT_1),&(v351_2));
    let v351_4: Space = if has_head(&(v351_3)) { singleton(&[]) } else { Space::new() };
    drop(v351_3);
    let v351_5: Space = subtract(&(*CONSTANT_0),&(v351_4));
    drop(v351_4);
    let v351_8: Space = if (v351_5).is_empty() { Space::new() } else {
      let v352_6: Path = concat_path(&(*p0),&(v350_8_head));
      let mut v352_7 = Space::new();
      let mut v352_7_cursor = (v350_8_tail).read_zipper();
      for v352_7_byte in v352_7_cursor.child_mask().iter() {
        v352_7_cursor.descend_to_byte(v352_7_byte);
        let v352_7_tail = v352_7_cursor.make_map();
        v352_7_cursor.ascend(1);
        let v352_7_head = Path::from_slice(&[v352_7_byte]);
        let v353_2: Space = singleton(&(v352_7_head));
        let v353_3: Space = intersect(&(*CONSTANT_1),&(v353_2));
        let v353_4: Space = if has_head(&(v353_3)) { singleton(&[]) } else { Space::new() };
        drop(v353_3);
        let v353_5: Space = subtract(&(*CONSTANT_0),&(v353_4));
        drop(v353_4);
        let v353_8: Space = if (v353_5).is_empty() { Space::new() } else {
          let v354_6: Path = concat_path(&(v352_6),&(v352_7_head));
          let v354_7: Space = routine_48(c, &(v354_6), &(v352_7_tail));
          compose(&(v353_5),&(v354_7))
        };
        drop(v353_5);
        let v353_9: Space = intersect(&(*CONSTANT_1),&(v353_2));
        drop(v353_2);
        let v353_10: Space = if has_head(&(v353_9)) { singleton(&[]) } else { Space::new() };
        drop(v353_9);
        let v353_12: Space = if (v353_10).is_empty() { Space::new() } else {
          let v355_6: Path = concat_path(&(v352_6),&(v352_7_head));
          let v355_11: Space = routine_49(c, &(v355_6), &(v352_7_tail));
          drop(v355_6);
          compose(&(v353_10),&(v355_11))
        };
        drop(v353_10);
        let v353_13: Space = unite(&(v353_8),&(v353_12));
        v352_7.join_into((v353_13).clone());
      }
      drop(v352_7_cursor);
      drop(v352_6);
      compose(&(v351_5),&(v352_7))
    };
    drop(v351_5);
    let v351_9: Space = intersect(&(*CONSTANT_1),&(v351_2));
    drop(v351_2);
    let v351_10: Space = if has_head(&(v351_9)) { singleton(&[]) } else { Space::new() };
    drop(v351_9);
    let v351_11: Space = compose(&(v351_10),&(v350_8_tail));
    drop(v351_10);
    let v351_12: Space = unite(&(v351_8),&(v351_11));
    drop(v351_11);
    v350_8.join_into((v351_12).clone());
  }
  drop(v350_8_cursor);
  (v350_8).clone()
}

fn routine_42(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v356_6 = Space::new();
  let mut v356_6_cursor = (*s0).read_zipper();
  for v356_6_byte in v356_6_cursor.child_mask().iter() {
    v356_6_cursor.descend_to_byte(v356_6_byte);
    let v356_6_tail = v356_6_cursor.make_map();
    v356_6_cursor.ascend(1);
    let v356_6_head = Path::from_slice(&[v356_6_byte]);
    let v357_2: Space = singleton(&(v356_6_head));
    let v357_3: Space = intersect(&(*CONSTANT_1),&(v357_2));
    let v357_4: Space = if has_head(&(v357_3)) { singleton(&[]) } else { Space::new() };
    drop(v357_3);
    let v357_5: Space = subtract(&(*CONSTANT_0),&(v357_4));
    drop(v357_4);
    let mut v357_6 = Space::new();
    let mut v357_6_cursor = (v356_6_tail).read_zipper();
    for v357_6_byte in v357_6_cursor.child_mask().iter() {
      v357_6_cursor.descend_to_byte(v357_6_byte);
      let v357_6_tail = v357_6_cursor.make_map();
      v357_6_cursor.ascend(1);
      let v357_6_head = Path::from_slice(&[v357_6_byte]);
      let v358_2: Space = Space::new();
      v357_6.join_into((v358_2).clone());
    }
    drop(v357_6_cursor);
    let v357_7: Space = compose(&(v357_5),&(v357_6));
    drop(v357_5);
    drop(v357_6);
    let v357_8: Space = intersect(&(*CONSTANT_1),&(v357_2));
    drop(v357_2);
    let v357_9: Space = if has_head(&(v357_8)) { singleton(&[]) } else { Space::new() };
    drop(v357_8);
    let v357_12: Space = if (v357_9).is_empty() { Space::new() } else {
      let v359_10: Path = concat_path(&(*p0),&(v356_6_head));
      let mut v359_11 = Space::new();
      let mut v359_11_cursor = (v356_6_tail).read_zipper();
      for v359_11_byte in v359_11_cursor.child_mask().iter() {
        v359_11_cursor.descend_to_byte(v359_11_byte);
        let v359_11_tail = v359_11_cursor.make_map();
        v359_11_cursor.ascend(1);
        let v359_11_head = Path::from_slice(&[v359_11_byte]);
        let v360_2: Space = singleton(&(v359_11_head));
        let v360_3: Space = intersect(&(*CONSTANT_1),&(v360_2));
        drop(v360_2);
        let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
        drop(v360_3);
        let v360_7: Space = if (v360_4).is_empty() { Space::new() } else {
          let v361_5: Path = concat_path(&(v359_10),&(v359_11_head));
          let v361_6: Space = routine_14(c, &(v361_5), &(v359_11_tail));
          drop(v361_5);
          compose(&(v360_4),&(v361_6))
        };
        drop(v360_4);
        v359_11.join_into((v360_7).clone());
      }
      drop(v359_11_cursor);
      drop(v359_10);
      compose(&(v357_9),&(v359_11))
    };
    drop(v357_9);
    let v357_13: Space = unite(&(v357_7),&(v357_12));
    drop(v357_7);
    v356_6.join_into((v357_13).clone());
  }
  drop(v356_6_cursor);
  (v356_6).clone()
}

fn routine_43(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v362_5 = Space::new();
  let mut v362_5_cursor = (*s0).read_zipper();
  for v362_5_byte in v362_5_cursor.child_mask().iter() {
    v362_5_cursor.descend_to_byte(v362_5_byte);
    let v362_5_tail = v362_5_cursor.make_map();
    v362_5_cursor.ascend(1);
    let v362_5_head = Path::from_slice(&[v362_5_byte]);
    let v363_2: Space = singleton(&(v362_5_head));
    let v363_3: Space = intersect(&(*CONSTANT_1),&(v363_2));
    let v363_4: Space = if has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
    drop(v363_3);
    let v363_5: Space = subtract(&(*CONSTANT_0),&(v363_4));
    drop(v363_4);
    let mut v363_6 = Space::new();
    let mut v363_6_cursor = (v362_5_tail).read_zipper();
    for v363_6_byte in v363_6_cursor.child_mask().iter() {
      v363_6_cursor.descend_to_byte(v363_6_byte);
      let v363_6_tail = v363_6_cursor.make_map();
      v363_6_cursor.ascend(1);
      let v363_6_head = Path::from_slice(&[v363_6_byte]);
      let v364_2: Space = Space::new();
      v363_6.join_into((v364_2).clone());
    }
    drop(v363_6_cursor);
    let v363_7: Space = compose(&(v363_5),&(v363_6));
    drop(v363_5);
    drop(v363_6);
    let v363_8: Space = intersect(&(*CONSTANT_1),&(v363_2));
    drop(v363_2);
    let v363_9: Space = if has_head(&(v363_8)) { singleton(&[]) } else { Space::new() };
    drop(v363_8);
    let v363_10: Space = compose(&(v363_9),&(v362_5_tail));
    drop(v363_9);
    let v363_11: Space = unite(&(v363_7),&(v363_10));
    drop(v363_7);
    drop(v363_10);
    v362_5.join_into((v363_11).clone());
  }
  drop(v362_5_cursor);
  (v362_5).clone()
}

fn routine_44(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v365_6 = Space::new();
  let mut v365_6_cursor = (*s0).read_zipper();
  for v365_6_byte in v365_6_cursor.child_mask().iter() {
    v365_6_cursor.descend_to_byte(v365_6_byte);
    let v365_6_tail = v365_6_cursor.make_map();
    v365_6_cursor.ascend(1);
    let v365_6_head = Path::from_slice(&[v365_6_byte]);
    let v366_2: Space = singleton(&(v365_6_head));
    let v366_3: Space = intersect(&(*CONSTANT_1),&(v366_2));
    let v366_4: Space = if has_head(&(v366_3)) { singleton(&[]) } else { Space::new() };
    drop(v366_3);
    let v366_5: Space = subtract(&(*CONSTANT_0),&(v366_4));
    drop(v366_4);
    let mut v366_6 = Space::new();
    let mut v366_6_cursor = (v365_6_tail).read_zipper();
    for v366_6_byte in v366_6_cursor.child_mask().iter() {
      v366_6_cursor.descend_to_byte(v366_6_byte);
      let v366_6_tail = v366_6_cursor.make_map();
      v366_6_cursor.ascend(1);
      let v366_6_head = Path::from_slice(&[v366_6_byte]);
      let v367_2: Space = Space::new();
      v366_6.join_into((v367_2).clone());
    }
    drop(v366_6_cursor);
    let v366_7: Space = compose(&(v366_5),&(v366_6));
    drop(v366_5);
    drop(v366_6);
    let v366_8: Space = intersect(&(*CONSTANT_1),&(v366_2));
    drop(v366_2);
    let v366_9: Space = if has_head(&(v366_8)) { singleton(&[]) } else { Space::new() };
    drop(v366_8);
    let v366_12: Space = if (v366_9).is_empty() { Space::new() } else {
      let v368_10: Path = concat_path(&(*p0),&(v365_6_head));
      let mut v368_11 = Space::new();
      let mut v368_11_cursor = (v365_6_tail).read_zipper();
      for v368_11_byte in v368_11_cursor.child_mask().iter() {
        v368_11_cursor.descend_to_byte(v368_11_byte);
        let v368_11_tail = v368_11_cursor.make_map();
        v368_11_cursor.ascend(1);
        let v368_11_head = Path::from_slice(&[v368_11_byte]);
        let v369_2: Space = singleton(&(v368_11_head));
        let v369_3: Space = intersect(&(*CONSTANT_1),&(v369_2));
        drop(v369_2);
        let v369_4: Space = if has_head(&(v369_3)) { singleton(&[]) } else { Space::new() };
        drop(v369_3);
        let v369_7: Space = if (v369_4).is_empty() { Space::new() } else {
          let v370_5: Path = concat_path(&(v368_10),&(v368_11_head));
          let v370_6: Space = routine_17(c, &(v370_5), &(v368_11_tail));
          drop(v370_5);
          compose(&(v369_4),&(v370_6))
        };
        drop(v369_4);
        v368_11.join_into((v369_7).clone());
      }
      drop(v368_11_cursor);
      drop(v368_10);
      compose(&(v366_9),&(v368_11))
    };
    drop(v366_9);
    let v366_13: Space = unite(&(v366_7),&(v366_12));
    drop(v366_7);
    v365_6.join_into((v366_13).clone());
  }
  drop(v365_6_cursor);
  (v365_6).clone()
}

fn routine_45(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v371_5 = Space::new();
  let mut v371_5_cursor = (*s0).read_zipper();
  for v371_5_byte in v371_5_cursor.child_mask().iter() {
    v371_5_cursor.descend_to_byte(v371_5_byte);
    let v371_5_tail = v371_5_cursor.make_map();
    v371_5_cursor.ascend(1);
    let v371_5_head = Path::from_slice(&[v371_5_byte]);
    let v372_2: Space = singleton(&(v371_5_head));
    let v372_3: Space = intersect(&(*CONSTANT_1),&(v372_2));
    let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
    drop(v372_3);
    let v372_5: Space = subtract(&(*CONSTANT_0),&(v372_4));
    drop(v372_4);
    let mut v372_6 = Space::new();
    let mut v372_6_cursor = (v371_5_tail).read_zipper();
    for v372_6_byte in v372_6_cursor.child_mask().iter() {
      v372_6_cursor.descend_to_byte(v372_6_byte);
      let v372_6_tail = v372_6_cursor.make_map();
      v372_6_cursor.ascend(1);
      let v372_6_head = Path::from_slice(&[v372_6_byte]);
      let v373_2: Space = Space::new();
      v372_6.join_into((v373_2).clone());
    }
    drop(v372_6_cursor);
    let v372_7: Space = compose(&(v372_5),&(v372_6));
    drop(v372_5);
    drop(v372_6);
    let v372_8: Space = intersect(&(*CONSTANT_1),&(v372_2));
    drop(v372_2);
    let v372_9: Space = if has_head(&(v372_8)) { singleton(&[]) } else { Space::new() };
    drop(v372_8);
    let v372_10: Space = compose(&(v372_9),&(v371_5_tail));
    drop(v372_9);
    let v372_11: Space = unite(&(v372_7),&(v372_10));
    drop(v372_7);
    drop(v372_10);
    v371_5.join_into((v372_11).clone());
  }
  drop(v371_5_cursor);
  (v371_5).clone()
}

fn routine_46(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v374_2 = Space::new();
  let mut v374_2_cursor = (*s0).read_zipper();
  for v374_2_byte in v374_2_cursor.child_mask().iter() {
    v374_2_cursor.descend_to_byte(v374_2_byte);
    let v374_2_tail = v374_2_cursor.make_map();
    v374_2_cursor.ascend(1);
    let v374_2_head = Path::from_slice(&[v374_2_byte]);
    let v375_2: Space = Space::new();
    v374_2.join_into((v375_2).clone());
  }
  drop(v374_2_cursor);
  (v374_2).clone()
}

fn routine_47(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v376_3 = Space::new();
  let mut v376_3_cursor = (*s0).read_zipper();
  for v376_3_byte in v376_3_cursor.child_mask().iter() {
    v376_3_cursor.descend_to_byte(v376_3_byte);
    let v376_3_tail = v376_3_cursor.make_map();
    v376_3_cursor.ascend(1);
    let v376_3_head = Path::from_slice(&[v376_3_byte]);
    let v377_2: Space = singleton(&(v376_3_head));
    let v377_3: Space = intersect(&(*CONSTANT_1),&(v377_2));
    drop(v377_2);
    let v377_4: Space = if has_head(&(v377_3)) { singleton(&[]) } else { Space::new() };
    drop(v377_3);
    let v377_5: Space = compose(&(v377_4),&(v376_3_tail));
    drop(v377_4);
    v376_3.join_into((v377_5).clone());
  }
  drop(v376_3_cursor);
  (v376_3).clone()
}

fn routine_48(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v378_2 = Space::new();
  let mut v378_2_cursor = (*s0).read_zipper();
  for v378_2_byte in v378_2_cursor.child_mask().iter() {
    v378_2_cursor.descend_to_byte(v378_2_byte);
    let v378_2_tail = v378_2_cursor.make_map();
    v378_2_cursor.ascend(1);
    let v378_2_head = Path::from_slice(&[v378_2_byte]);
    let v379_2: Space = Space::new();
    v378_2.join_into((v379_2).clone());
  }
  drop(v378_2_cursor);
  (v378_2).clone()
}

fn routine_49(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v380_3 = Space::new();
  let mut v380_3_cursor = (*s0).read_zipper();
  for v380_3_byte in v380_3_cursor.child_mask().iter() {
    v380_3_cursor.descend_to_byte(v380_3_byte);
    let v380_3_tail = v380_3_cursor.make_map();
    v380_3_cursor.ascend(1);
    let v380_3_head = Path::from_slice(&[v380_3_byte]);
    let v381_2: Space = singleton(&(v380_3_head));
    let v381_3: Space = intersect(&(*CONSTANT_1),&(v381_2));
    drop(v381_2);
    let v381_4: Space = if has_head(&(v381_3)) { singleton(&[]) } else { Space::new() };
    drop(v381_3);
    let v381_5: Space = compose(&(v381_4),&(v380_3_tail));
    drop(v381_4);
    v380_3.join_into((v381_5).clone());
  }
  drop(v380_3_cursor);
  (v380_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
