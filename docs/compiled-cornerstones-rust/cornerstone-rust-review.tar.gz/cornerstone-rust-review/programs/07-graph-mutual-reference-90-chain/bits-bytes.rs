#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,1,0,0,0,0,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let mut v0_12 = Space::new();
  let mut v0_12_cursor = (v0_2).read_zipper();
  for v0_12_byte in v0_12_cursor.child_mask().iter() {
    v0_12_cursor.descend_to_byte(v0_12_byte);
    let v0_12_tail = v0_12_cursor.make_map();
    v0_12_cursor.ascend(1);
    let v0_12_head = Path::from_slice(&[v0_12_byte]);
    let v1_2: Space = singleton(&(v0_12_head));
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_12_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        let v2_6_tail = v2_6_cursor.make_map();
        v2_6_cursor.ascend(1);
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_12_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail), &(*s0.expect("unbound native input")));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_12_head),&(v2_6_head));
          let v5_11: Space = routine_2(c, &(v5_6), &(v2_6_tail), &(*s0.expect("unbound native input")));
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_cursor = (v0_12_tail).read_zipper();
      for v6_10_byte in v6_10_cursor.child_mask().iter() {
        v6_10_cursor.descend_to_byte(v6_10_byte);
        let v6_10_tail = v6_10_cursor.make_map();
        v6_10_cursor.ascend(1);
        let v6_10_head = Path::from_slice(&[v6_10_byte]);
        let v7_2: Space = singleton(&(v6_10_head));
        let v7_3: Space = intersect(&(*CONSTANT_2),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_1),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_12_head),&(v6_10_head));
          let v8_7: Space = routine_1(c, &(v8_6), &(v6_10_tail), &(*s0.expect("unbound native input")));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_2),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v0_12_head),&(v6_10_head));
          let v9_11: Space = routine_3(c, &(v9_6), &(v6_10_tail), &(*s0.expect("unbound native input")));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_10.join_into((v7_13).clone());
      }
      drop(v6_10_cursor);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_12.join_into((v1_12).clone());
  }
  drop(v0_12_cursor);
  drop(v0_2);
  let v0_14: Space = wrap(&(v0_12),&(*CONSTANT_3));
  (v0_14).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v10_12 = Space::new();
  let mut v10_12_cursor = (*s0).read_zipper();
  for v10_12_byte in v10_12_cursor.child_mask().iter() {
    v10_12_cursor.descend_to_byte(v10_12_byte);
    let v10_12_tail = v10_12_cursor.make_map();
    v10_12_cursor.ascend(1);
    let v10_12_head = Path::from_slice(&[v10_12_byte]);
    let v11_2: Space = singleton(&(v10_12_head));
    let v11_3: Space = intersect(&(*CONSTANT_2),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_1),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&(v10_12_head));
      let mut v12_7 = Space::new();
      let mut v12_7_cursor = (v10_12_tail).read_zipper();
      for v12_7_byte in v12_7_cursor.child_mask().iter() {
        v12_7_cursor.descend_to_byte(v12_7_byte);
        let v12_7_tail = v12_7_cursor.make_map();
        v12_7_cursor.ascend(1);
        let v12_7_head = Path::from_slice(&[v12_7_byte]);
        let v13_2: Space = singleton(&(v12_7_head));
        let v13_3: Space = intersect(&(*CONSTANT_2),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_1),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let v14_7: Space = routine_4(c, &(v14_6), &(v12_7_tail), &(*s1));
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_2),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
          let v15_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let v15_11: Space = routine_5(c, &(v15_6), &(v12_7_tail), &(*s1));
          drop(v15_6);
          compose(&(v13_10),&(v15_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        v12_7.join_into((v13_13).clone());
      }
      drop(v12_7_cursor);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_2),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_12: Space = if (v11_10).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v10_12_head));
      let mut v16_11 = Space::new();
      let mut v16_11_cursor = (v10_12_tail).read_zipper();
      for v16_11_byte in v16_11_cursor.child_mask().iter() {
        v16_11_cursor.descend_to_byte(v16_11_byte);
        let v16_11_tail = v16_11_cursor.make_map();
        v16_11_cursor.ascend(1);
        let v16_11_head = Path::from_slice(&[v16_11_byte]);
        let v17_2: Space = singleton(&(v16_11_head));
        let v17_3: Space = intersect(&(*CONSTANT_2),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_1),&(v17_4));
        drop(v17_4);
        let v17_8: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v16_6),&(v16_11_head));
          let v18_7: Space = routine_4(c, &(v18_6), &(v16_11_tail), &(*s1));
          compose(&(v17_5),&(v18_7))
        };
        drop(v17_5);
        let v17_9: Space = intersect(&(*CONSTANT_2),&(v17_2));
        drop(v17_2);
        let v17_10: Space = if has_head(&(v17_9)) { singleton(&[]) } else { Space::new() };
        drop(v17_9);
        let v17_12: Space = if (v17_10).is_empty() { Space::new() } else {
          let v19_6: Path = concat_path(&(v16_6),&(v16_11_head));
          let v19_11: Space = routine_3(c, &(v19_6), &(v16_11_tail), &(*s1));
          drop(v19_6);
          compose(&(v17_10),&(v19_11))
        };
        drop(v17_10);
        let v17_13: Space = unite(&(v17_8),&(v17_12));
        v16_11.join_into((v17_13).clone());
      }
      drop(v16_11_cursor);
      drop(v16_6);
      compose(&(v11_10),&(v16_11))
    };
    drop(v11_10);
    let v11_13: Space = unite(&(v11_8),&(v11_12));
    v10_12.join_into((v11_13).clone());
  }
  drop(v10_12_cursor);
  (v10_12).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v20_12 = Space::new();
  let mut v20_12_cursor = (*s0).read_zipper();
  for v20_12_byte in v20_12_cursor.child_mask().iter() {
    v20_12_cursor.descend_to_byte(v20_12_byte);
    let v20_12_tail = v20_12_cursor.make_map();
    v20_12_cursor.ascend(1);
    let v20_12_head = Path::from_slice(&[v20_12_byte]);
    let v21_2: Space = singleton(&(v20_12_head));
    let v21_3: Space = intersect(&(*CONSTANT_2),&(v21_2));
    let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
    drop(v21_3);
    let v21_5: Space = subtract(&(*CONSTANT_1),&(v21_4));
    drop(v21_4);
    let v21_8: Space = if (v21_5).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&(v20_12_head));
      let mut v22_7 = Space::new();
      let mut v22_7_cursor = (v20_12_tail).read_zipper();
      for v22_7_byte in v22_7_cursor.child_mask().iter() {
        v22_7_cursor.descend_to_byte(v22_7_byte);
        let v22_7_tail = v22_7_cursor.make_map();
        v22_7_cursor.ascend(1);
        let v22_7_head = Path::from_slice(&[v22_7_byte]);
        let v23_2: Space = singleton(&(v22_7_head));
        let v23_3: Space = intersect(&(*CONSTANT_2),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_1),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&(v22_7_head));
          let v24_7: Space = routine_4(c, &(v24_6), &(v22_7_tail), &(*s1));
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_2),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_12: Space = if (v23_10).is_empty() { Space::new() } else {
          let v25_6: Path = concat_path(&(v22_6),&(v22_7_head));
          let v25_11: Space = routine_5(c, &(v25_6), &(v22_7_tail), &(*s1));
          drop(v25_6);
          compose(&(v23_10),&(v25_11))
        };
        drop(v23_10);
        let v23_13: Space = unite(&(v23_8),&(v23_12));
        v22_7.join_into((v23_13).clone());
      }
      drop(v22_7_cursor);
      compose(&(v21_5),&(v22_7))
    };
    drop(v21_5);
    let v21_9: Space = intersect(&(*CONSTANT_2),&(v21_2));
    drop(v21_2);
    let v21_10: Space = if has_head(&(v21_9)) { singleton(&[]) } else { Space::new() };
    drop(v21_9);
    let v21_12: Space = if (v21_10).is_empty() { Space::new() } else {
      let v26_6: Path = concat_path(&(*p0),&(v20_12_head));
      let mut v26_11 = Space::new();
      let mut v26_11_cursor = (v20_12_tail).read_zipper();
      for v26_11_byte in v26_11_cursor.child_mask().iter() {
        v26_11_cursor.descend_to_byte(v26_11_byte);
        let v26_11_tail = v26_11_cursor.make_map();
        v26_11_cursor.ascend(1);
        let v26_11_head = Path::from_slice(&[v26_11_byte]);
        let v27_2: Space = singleton(&(v26_11_head));
        let v27_3: Space = intersect(&(*CONSTANT_2),&(v27_2));
        let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
        drop(v27_3);
        let v27_5: Space = subtract(&(*CONSTANT_1),&(v27_4));
        drop(v27_4);
        let v27_7: Space = if (v27_5).is_empty() { Space::new() } else {
          let v28_6: Space = routine_6(c, &(v26_11_head), &(v26_6), &(v26_11_tail), &(*s1));
          compose(&(v27_5),&(v28_6))
        };
        drop(v27_5);
        let v27_8: Space = intersect(&(*CONSTANT_2),&(v27_2));
        drop(v27_2);
        let v27_9: Space = if has_head(&(v27_8)) { singleton(&[]) } else { Space::new() };
        drop(v27_8);
        let v27_11: Space = if (v27_9).is_empty() { Space::new() } else {
          let v29_10: Space = routine_7(c, &(v26_11_head), &(v26_6), &(v26_11_tail), &(*s1));
          compose(&(v27_9),&(v29_10))
        };
        drop(v27_9);
        let v27_12: Space = unite(&(v27_7),&(v27_11));
        v26_11.join_into((v27_12).clone());
      }
      drop(v26_11_cursor);
      drop(v26_6);
      compose(&(v21_10),&(v26_11))
    };
    drop(v21_10);
    let v21_13: Space = unite(&(v21_8),&(v21_12));
    v20_12.join_into((v21_13).clone());
  }
  drop(v20_12_cursor);
  (v20_12).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v30_12 = Space::new();
  let mut v30_12_cursor = (*s0).read_zipper();
  for v30_12_byte in v30_12_cursor.child_mask().iter() {
    v30_12_cursor.descend_to_byte(v30_12_byte);
    let v30_12_tail = v30_12_cursor.make_map();
    v30_12_cursor.ascend(1);
    let v30_12_head = Path::from_slice(&[v30_12_byte]);
    let v31_2: Space = singleton(&(v30_12_head));
    let v31_3: Space = intersect(&(*CONSTANT_2),&(v31_2));
    let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
    drop(v31_3);
    let v31_5: Space = subtract(&(*CONSTANT_1),&(v31_4));
    drop(v31_4);
    let v31_7: Space = if (v31_5).is_empty() { Space::new() } else {
      let mut v32_6 = Space::new();
      let mut v32_6_cursor = (v30_12_tail).read_zipper();
      for v32_6_byte in v32_6_cursor.child_mask().iter() {
        v32_6_cursor.descend_to_byte(v32_6_byte);
        let v32_6_tail = v32_6_cursor.make_map();
        v32_6_cursor.ascend(1);
        let v32_6_head = Path::from_slice(&[v32_6_byte]);
        let v33_2: Space = singleton(&(v32_6_head));
        let v33_3: Space = intersect(&(*CONSTANT_2),&(v33_2));
        let v33_4: Space = if has_head(&(v33_3)) { singleton(&[]) } else { Space::new() };
        drop(v33_3);
        let v33_5: Space = subtract(&(*CONSTANT_1),&(v33_4));
        drop(v33_4);
        let v33_8: Space = if (v33_5).is_empty() { Space::new() } else {
          let v34_6: Path = concat_path(&(v30_12_head),&(v32_6_head));
          let v34_7: Space = routine_8(c, &(v34_6), &(*p0), &(v32_6_tail), &(*s1));
          compose(&(v33_5),&(v34_7))
        };
        drop(v33_5);
        let v33_9: Space = intersect(&(*CONSTANT_2),&(v33_2));
        drop(v33_2);
        let v33_10: Space = if has_head(&(v33_9)) { singleton(&[]) } else { Space::new() };
        drop(v33_9);
        let v33_12: Space = if (v33_10).is_empty() { Space::new() } else {
          let v35_6: Path = concat_path(&(v30_12_head),&(v32_6_head));
          let v35_11: Space = routine_9(c, &(v35_6), &(*p0), &(v32_6_tail), &(*s1));
          drop(v35_6);
          compose(&(v33_10),&(v35_11))
        };
        drop(v33_10);
        let v33_13: Space = unite(&(v33_8),&(v33_12));
        v32_6.join_into((v33_13).clone());
      }
      drop(v32_6_cursor);
      compose(&(v31_5),&(v32_6))
    };
    drop(v31_5);
    let v31_8: Space = intersect(&(*CONSTANT_2),&(v31_2));
    drop(v31_2);
    let v31_9: Space = if has_head(&(v31_8)) { singleton(&[]) } else { Space::new() };
    drop(v31_8);
    let v31_11: Space = if (v31_9).is_empty() { Space::new() } else {
      let mut v36_10 = Space::new();
      let mut v36_10_cursor = (v30_12_tail).read_zipper();
      for v36_10_byte in v36_10_cursor.child_mask().iter() {
        v36_10_cursor.descend_to_byte(v36_10_byte);
        let v36_10_tail = v36_10_cursor.make_map();
        v36_10_cursor.ascend(1);
        let v36_10_head = Path::from_slice(&[v36_10_byte]);
        let v37_2: Space = singleton(&(v36_10_head));
        let v37_3: Space = intersect(&(*CONSTANT_2),&(v37_2));
        let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
        drop(v37_3);
        let v37_5: Space = subtract(&(*CONSTANT_1),&(v37_4));
        drop(v37_4);
        let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
          let v38_6: Path = concat_path(&(v30_12_head),&(v36_10_head));
          let v38_7: Space = routine_8(c, &(v38_6), &(*p0), &(v36_10_tail), &(*s1));
          compose(&(v37_5),&(v38_7))
        };
        drop(v37_5);
        let v37_9: Space = intersect(&(*CONSTANT_2),&(v37_2));
        drop(v37_2);
        let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
        drop(v37_9);
        let v37_12: Space = if (v37_10).is_empty() { Space::new() } else {
          let v39_6: Path = concat_path(&(v30_12_head),&(v36_10_head));
          let v39_11: Space = routine_10(c, &(v39_6), &(*p0), &(v36_10_tail), &(*s1));
          drop(v39_6);
          compose(&(v37_10),&(v39_11))
        };
        drop(v37_10);
        let v37_13: Space = unite(&(v37_8),&(v37_12));
        v36_10.join_into((v37_13).clone());
      }
      drop(v36_10_cursor);
      compose(&(v31_9),&(v36_10))
    };
    drop(v31_9);
    let v31_12: Space = unite(&(v31_7),&(v31_11));
    v30_12.join_into((v31_12).clone());
  }
  drop(v30_12_cursor);
  (v30_12).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v40_12 = Space::new();
  let mut v40_12_cursor = (*s0).read_zipper();
  for v40_12_byte in v40_12_cursor.child_mask().iter() {
    v40_12_cursor.descend_to_byte(v40_12_byte);
    let v40_12_tail = v40_12_cursor.make_map();
    v40_12_cursor.ascend(1);
    let v40_12_head = Path::from_slice(&[v40_12_byte]);
    let v41_2: Space = singleton(&(v40_12_head));
    let v41_3: Space = intersect(&(*CONSTANT_2),&(v41_2));
    let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
    drop(v41_3);
    let v41_5: Space = subtract(&(*CONSTANT_1),&(v41_4));
    drop(v41_4);
    let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
      let v42_6: Path = concat_path(&(*p0),&(v40_12_head));
      let mut v42_7 = Space::new();
      let mut v42_7_cursor = (v40_12_tail).read_zipper();
      for v42_7_byte in v42_7_cursor.child_mask().iter() {
        v42_7_cursor.descend_to_byte(v42_7_byte);
        let v42_7_tail = v42_7_cursor.make_map();
        v42_7_cursor.ascend(1);
        let v42_7_head = Path::from_slice(&[v42_7_byte]);
        let v43_2: Space = singleton(&(v42_7_head));
        let v43_3: Space = intersect(&(*CONSTANT_2),&(v43_2));
        let v43_4: Space = if has_head(&(v43_3)) { singleton(&[]) } else { Space::new() };
        drop(v43_3);
        let v43_5: Space = subtract(&(*CONSTANT_1),&(v43_4));
        drop(v43_4);
        let v43_8: Space = if (v43_5).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v42_6),&(v42_7_head));
          let v44_7: Space = routine_11(c, &(v44_6), &(v42_7_tail), &(*s1));
          compose(&(v43_5),&(v44_7))
        };
        drop(v43_5);
        let v43_9: Space = intersect(&(*CONSTANT_2),&(v43_2));
        drop(v43_2);
        let v43_10: Space = if has_head(&(v43_9)) { singleton(&[]) } else { Space::new() };
        drop(v43_9);
        let v43_12: Space = if (v43_10).is_empty() { Space::new() } else {
          let v45_6: Path = concat_path(&(v42_6),&(v42_7_head));
          let v45_11: Space = routine_12(c, &(v45_6), &(v42_7_tail), &(*s1));
          drop(v45_6);
          compose(&(v43_10),&(v45_11))
        };
        drop(v43_10);
        let v43_13: Space = unite(&(v43_8),&(v43_12));
        v42_7.join_into((v43_13).clone());
      }
      drop(v42_7_cursor);
      compose(&(v41_5),&(v42_7))
    };
    drop(v41_5);
    let v41_9: Space = intersect(&(*CONSTANT_2),&(v41_2));
    drop(v41_2);
    let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
    drop(v41_9);
    let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&(v40_12_head));
      let mut v46_11 = Space::new();
      let mut v46_11_cursor = (v40_12_tail).read_zipper();
      for v46_11_byte in v46_11_cursor.child_mask().iter() {
        v46_11_cursor.descend_to_byte(v46_11_byte);
        let v46_11_tail = v46_11_cursor.make_map();
        v46_11_cursor.ascend(1);
        let v46_11_head = Path::from_slice(&[v46_11_byte]);
        let v47_2: Space = singleton(&(v46_11_head));
        let v47_3: Space = intersect(&(*CONSTANT_2),&(v47_2));
        let v47_4: Space = if has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = subtract(&(*CONSTANT_1),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (v47_5).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&(v46_11_head));
          let v48_7: Space = routine_11(c, &(v48_6), &(v46_11_tail), &(*s1));
          compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = intersect(&(*CONSTANT_2),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (v47_10).is_empty() { Space::new() } else {
          let v49_6: Path = concat_path(&(v46_6),&(v46_11_head));
          let v49_11: Space = routine_3(c, &(v49_6), &(v46_11_tail), &(*s1));
          drop(v49_6);
          compose(&(v47_10),&(v49_11))
        };
        drop(v47_10);
        let v47_13: Space = unite(&(v47_8),&(v47_12));
        v46_11.join_into((v47_13).clone());
      }
      drop(v46_11_cursor);
      drop(v46_6);
      compose(&(v41_10),&(v46_11))
    };
    drop(v41_10);
    let v41_13: Space = unite(&(v41_8),&(v41_12));
    v40_12.join_into((v41_13).clone());
  }
  drop(v40_12_cursor);
  (v40_12).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v50_12 = Space::new();
  let mut v50_12_cursor = (*s0).read_zipper();
  for v50_12_byte in v50_12_cursor.child_mask().iter() {
    v50_12_cursor.descend_to_byte(v50_12_byte);
    let v50_12_tail = v50_12_cursor.make_map();
    v50_12_cursor.ascend(1);
    let v50_12_head = Path::from_slice(&[v50_12_byte]);
    let v51_2: Space = singleton(&(v50_12_head));
    let v51_3: Space = intersect(&(*CONSTANT_2),&(v51_2));
    let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
    drop(v51_3);
    let v51_5: Space = subtract(&(*CONSTANT_1),&(v51_4));
    drop(v51_4);
    let v51_8: Space = if (v51_5).is_empty() { Space::new() } else {
      let v52_6: Path = concat_path(&(*p0),&(v50_12_head));
      let mut v52_7 = Space::new();
      let mut v52_7_cursor = (v50_12_tail).read_zipper();
      for v52_7_byte in v52_7_cursor.child_mask().iter() {
        v52_7_cursor.descend_to_byte(v52_7_byte);
        let v52_7_tail = v52_7_cursor.make_map();
        v52_7_cursor.ascend(1);
        let v52_7_head = Path::from_slice(&[v52_7_byte]);
        let v53_2: Space = singleton(&(v52_7_head));
        let v53_3: Space = intersect(&(*CONSTANT_2),&(v53_2));
        let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
        drop(v53_3);
        let v53_5: Space = subtract(&(*CONSTANT_1),&(v53_4));
        drop(v53_4);
        let v53_8: Space = if (v53_5).is_empty() { Space::new() } else {
          let v54_6: Path = concat_path(&(v52_6),&(v52_7_head));
          let v54_7: Space = routine_11(c, &(v54_6), &(v52_7_tail), &(*s1));
          compose(&(v53_5),&(v54_7))
        };
        drop(v53_5);
        let v53_9: Space = intersect(&(*CONSTANT_2),&(v53_2));
        drop(v53_2);
        let v53_10: Space = if has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
        drop(v53_9);
        let v53_12: Space = if (v53_10).is_empty() { Space::new() } else {
          let v55_6: Path = concat_path(&(v52_6),&(v52_7_head));
          let v55_11: Space = routine_12(c, &(v55_6), &(v52_7_tail), &(*s1));
          drop(v55_6);
          compose(&(v53_10),&(v55_11))
        };
        drop(v53_10);
        let v53_13: Space = unite(&(v53_8),&(v53_12));
        v52_7.join_into((v53_13).clone());
      }
      drop(v52_7_cursor);
      compose(&(v51_5),&(v52_7))
    };
    drop(v51_5);
    let v51_9: Space = intersect(&(*CONSTANT_2),&(v51_2));
    drop(v51_2);
    let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
    drop(v51_9);
    let v51_12: Space = if (v51_10).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&(v50_12_head));
      let mut v56_11 = Space::new();
      let mut v56_11_cursor = (v50_12_tail).read_zipper();
      for v56_11_byte in v56_11_cursor.child_mask().iter() {
        v56_11_cursor.descend_to_byte(v56_11_byte);
        let v56_11_tail = v56_11_cursor.make_map();
        v56_11_cursor.ascend(1);
        let v56_11_head = Path::from_slice(&[v56_11_byte]);
        let v57_2: Space = singleton(&(v56_11_head));
        let v57_3: Space = intersect(&(*CONSTANT_2),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_1),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (v57_5).is_empty() { Space::new() } else {
          let v58_6: Space = routine_6(c, &(v56_11_head), &(v56_6), &(v56_11_tail), &(*s1));
          compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = intersect(&(*CONSTANT_2),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (v57_9).is_empty() { Space::new() } else {
          let v59_10: Space = routine_7(c, &(v56_11_head), &(v56_6), &(v56_11_tail), &(*s1));
          compose(&(v57_9),&(v59_10))
        };
        drop(v57_9);
        let v57_12: Space = unite(&(v57_7),&(v57_11));
        v56_11.join_into((v57_12).clone());
      }
      drop(v56_11_cursor);
      drop(v56_6);
      compose(&(v51_10),&(v56_11))
    };
    drop(v51_10);
    let v51_13: Space = unite(&(v51_8),&(v51_12));
    v50_12.join_into((v51_13).clone());
  }
  drop(v50_12_cursor);
  (v50_12).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v60_13 = Space::new();
  let mut v60_13_cursor = (*s0).read_zipper();
  for v60_13_byte in v60_13_cursor.child_mask().iter() {
    v60_13_cursor.descend_to_byte(v60_13_byte);
    let v60_13_tail = v60_13_cursor.make_map();
    v60_13_cursor.ascend(1);
    let v60_13_head = Path::from_slice(&[v60_13_byte]);
    let v61_2: Space = singleton(&(v60_13_head));
    let v61_3: Space = intersect(&(*CONSTANT_2),&(v61_2));
    let v61_4: Space = if has_head(&(v61_3)) { singleton(&[]) } else { Space::new() };
    drop(v61_3);
    let v61_5: Space = subtract(&(*CONSTANT_1),&(v61_4));
    drop(v61_4);
    let v61_8: Space = if (v61_5).is_empty() { Space::new() } else {
      let v62_6: Path = concat_path(&(*p0),&(v60_13_head));
      let mut v62_7 = Space::new();
      let mut v62_7_cursor = (v60_13_tail).read_zipper();
      for v62_7_byte in v62_7_cursor.child_mask().iter() {
        v62_7_cursor.descend_to_byte(v62_7_byte);
        let v62_7_tail = v62_7_cursor.make_map();
        v62_7_cursor.ascend(1);
        let v62_7_head = Path::from_slice(&[v62_7_byte]);
        let v63_2: Space = singleton(&(v62_7_head));
        let v63_3: Space = intersect(&(*CONSTANT_2),&(v63_2));
        let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
        drop(v63_3);
        let v63_5: Space = subtract(&(*CONSTANT_1),&(v63_4));
        drop(v63_4);
        let v63_8: Space = if (v63_5).is_empty() { Space::new() } else {
          let v64_6: Path = concat_path(&(v62_6),&(v62_7_head));
          let v64_7: Space = routine_13(c, &(v64_6), &(*p1), &(v62_7_tail), &(*s1));
          compose(&(v63_5),&(v64_7))
        };
        drop(v63_5);
        let v63_9: Space = intersect(&(*CONSTANT_2),&(v63_2));
        drop(v63_2);
        let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
        drop(v63_9);
        let v63_12: Space = if (v63_10).is_empty() { Space::new() } else {
          let v65_6: Path = concat_path(&(v62_6),&(v62_7_head));
          let v65_11: Space = routine_14(c, &(v65_6), &(*p1), &(v62_7_tail), &(*s1));
          drop(v65_6);
          compose(&(v63_10),&(v65_11))
        };
        drop(v63_10);
        let v63_13: Space = unite(&(v63_8),&(v63_12));
        v62_7.join_into((v63_13).clone());
      }
      drop(v62_7_cursor);
      compose(&(v61_5),&(v62_7))
    };
    drop(v61_5);
    let v61_9: Space = intersect(&(*CONSTANT_2),&(v61_2));
    drop(v61_2);
    let v61_10: Space = if has_head(&(v61_9)) { singleton(&[]) } else { Space::new() };
    drop(v61_9);
    let v61_12: Space = if (v61_10).is_empty() { Space::new() } else {
      let v66_6: Path = concat_path(&(*p0),&(v60_13_head));
      let mut v66_11 = Space::new();
      let mut v66_11_cursor = (v60_13_tail).read_zipper();
      for v66_11_byte in v66_11_cursor.child_mask().iter() {
        v66_11_cursor.descend_to_byte(v66_11_byte);
        let v66_11_tail = v66_11_cursor.make_map();
        v66_11_cursor.ascend(1);
        let v66_11_head = Path::from_slice(&[v66_11_byte]);
        let v67_2: Space = singleton(&(v66_11_head));
        let v67_3: Space = intersect(&(*CONSTANT_2),&(v67_2));
        let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
        drop(v67_3);
        let v67_5: Space = subtract(&(*CONSTANT_1),&(v67_4));
        drop(v67_4);
        let v67_8: Space = if (v67_5).is_empty() { Space::new() } else {
          let v68_6: Path = concat_path(&(v66_6),&(v66_11_head));
          let v68_7: Space = routine_13(c, &(v68_6), &(*p1), &(v66_11_tail), &(*s1));
          compose(&(v67_5),&(v68_7))
        };
        drop(v67_5);
        let v67_9: Space = intersect(&(*CONSTANT_2),&(v67_2));
        drop(v67_2);
        let v67_10: Space = if has_head(&(v67_9)) { singleton(&[]) } else { Space::new() };
        drop(v67_9);
        let v67_12: Space = if (v67_10).is_empty() { Space::new() } else {
          let v69_6: Path = concat_path(&(v66_6),&(v66_11_head));
          let v69_11: Space = routine_10(c, &(v69_6), &(*p1), &(v66_11_tail), &(*s1));
          drop(v69_6);
          compose(&(v67_10),&(v69_11))
        };
        drop(v67_10);
        let v67_13: Space = unite(&(v67_8),&(v67_12));
        v66_11.join_into((v67_13).clone());
      }
      drop(v66_11_cursor);
      drop(v66_6);
      compose(&(v61_10),&(v66_11))
    };
    drop(v61_10);
    let v61_13: Space = unite(&(v61_8),&(v61_12));
    v60_13.join_into((v61_13).clone());
  }
  drop(v60_13_cursor);
  (v60_13).clone()
}

fn routine_7(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v70_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v70_9: Space = unwrap(&(v70_8),&(*p0));
  drop(v70_8);
  let mut v70_13 = Space::new();
  let mut v70_13_cursor = (*s0).read_zipper();
  for v70_13_byte in v70_13_cursor.child_mask().iter() {
    v70_13_cursor.descend_to_byte(v70_13_byte);
    let v70_13_tail = v70_13_cursor.make_map();
    v70_13_cursor.ascend(1);
    let v70_13_head = Path::from_slice(&[v70_13_byte]);
    let v71_2: Space = singleton(&(v70_13_head));
    let v71_3: Space = intersect(&(*CONSTANT_2),&(v71_2));
    let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
    drop(v71_3);
    let v71_5: Space = subtract(&(*CONSTANT_1),&(v71_4));
    drop(v71_4);
    let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
      let v72_6: Path = concat_path(&(*p0),&(v70_13_head));
      let mut v72_7 = Space::new();
      let mut v72_7_cursor = (v70_13_tail).read_zipper();
      for v72_7_byte in v72_7_cursor.child_mask().iter() {
        v72_7_cursor.descend_to_byte(v72_7_byte);
        let v72_7_tail = v72_7_cursor.make_map();
        v72_7_cursor.ascend(1);
        let v72_7_head = Path::from_slice(&[v72_7_byte]);
        let v73_2: Space = singleton(&(v72_7_head));
        let v73_3: Space = intersect(&(*CONSTANT_2),&(v73_2));
        let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
        drop(v73_3);
        let v73_5: Space = subtract(&(*CONSTANT_1),&(v73_4));
        drop(v73_4);
        let v73_8: Space = if (v73_5).is_empty() { Space::new() } else {
          let v74_6: Path = concat_path(&(v72_6),&(v72_7_head));
          let v74_7: Space = routine_13(c, &(v74_6), &(*p1), &(v72_7_tail), &(*s1));
          compose(&(v73_5),&(v74_7))
        };
        drop(v73_5);
        let v73_9: Space = intersect(&(*CONSTANT_2),&(v73_2));
        drop(v73_2);
        let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
        drop(v73_9);
        let v73_12: Space = if (v73_10).is_empty() { Space::new() } else {
          let v75_6: Path = concat_path(&(v72_6),&(v72_7_head));
          let v75_11: Space = routine_14(c, &(v75_6), &(*p1), &(v72_7_tail), &(*s1));
          drop(v75_6);
          compose(&(v73_10),&(v75_11))
        };
        drop(v73_10);
        let v73_13: Space = unite(&(v73_8),&(v73_12));
        v72_7.join_into((v73_13).clone());
      }
      drop(v72_7_cursor);
      compose(&(v71_5),&(v72_7))
    };
    drop(v71_5);
    let v71_9: Space = intersect(&(*CONSTANT_2),&(v71_2));
    drop(v71_2);
    let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
    drop(v71_9);
    let v71_13: Space = if (v71_10).is_empty() { Space::new() } else {
      let v76_11: Space = unwrap(&(v70_9),&(v70_13_head));
      let v76_12: Space = unwrap(&(v76_11),&(*p1));
      drop(v76_11);
      compose(&(v71_10),&(v76_12))
    };
    drop(v71_10);
    let v77_6: Path = concat_path(&(*p0),&(v70_13_head));
    let v71_14: Space = wrap(&(v71_13),&(v77_6));
    drop(v71_13);
    let v71_15: Space = wrap(&(v71_14),&(*p1));
    drop(v71_14);
    let v71_16: Space = unite(&(v71_8),&(v71_15));
    drop(v71_15);
    v70_13.join_into((v71_16).clone());
  }
  drop(v70_13_cursor);
  drop(v70_9);
  (v70_13).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v78_13 = Space::new();
  let mut v78_13_cursor = (*s0).read_zipper();
  for v78_13_byte in v78_13_cursor.child_mask().iter() {
    v78_13_cursor.descend_to_byte(v78_13_byte);
    let v78_13_tail = v78_13_cursor.make_map();
    v78_13_cursor.ascend(1);
    let v78_13_head = Path::from_slice(&[v78_13_byte]);
    let v79_2: Space = singleton(&(v78_13_head));
    let v79_3: Space = intersect(&(*CONSTANT_2),&(v79_2));
    let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
    drop(v79_3);
    let v79_5: Space = subtract(&(*CONSTANT_1),&(v79_4));
    drop(v79_4);
    let v79_8: Space = if (v79_5).is_empty() { Space::new() } else {
      let v80_6: Path = concat_path(&(*p0),&(v78_13_head));
      let mut v80_7 = Space::new();
      let mut v80_7_cursor = (v78_13_tail).read_zipper();
      for v80_7_byte in v80_7_cursor.child_mask().iter() {
        v80_7_cursor.descend_to_byte(v80_7_byte);
        let v80_7_tail = v80_7_cursor.make_map();
        v80_7_cursor.ascend(1);
        let v80_7_head = Path::from_slice(&[v80_7_byte]);
        let v81_2: Space = singleton(&(v80_7_head));
        let v81_3: Space = intersect(&(*CONSTANT_2),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_1),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
          let v82_6: Path = concat_path(&(v80_6),&(v80_7_head));
          let v82_7: Space = routine_15(c, &(v82_6), &(*p1), &(v80_7_tail), &(*s1));
          compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = intersect(&(*CONSTANT_2),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_12: Space = if (v81_10).is_empty() { Space::new() } else {
          let v83_6: Path = concat_path(&(v80_6),&(v80_7_head));
          let v83_11: Space = routine_16(c, &(v83_6), &(*p1), &(v80_7_tail), &(*s1));
          drop(v83_6);
          compose(&(v81_10),&(v83_11))
        };
        drop(v81_10);
        let v81_13: Space = unite(&(v81_8),&(v81_12));
        v80_7.join_into((v81_13).clone());
      }
      drop(v80_7_cursor);
      compose(&(v79_5),&(v80_7))
    };
    drop(v79_5);
    let v79_9: Space = intersect(&(*CONSTANT_2),&(v79_2));
    drop(v79_2);
    let v79_10: Space = if has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
    drop(v79_9);
    let v79_12: Space = if (v79_10).is_empty() { Space::new() } else {
      let v84_6: Path = concat_path(&(*p0),&(v78_13_head));
      let mut v84_11 = Space::new();
      let mut v84_11_cursor = (v78_13_tail).read_zipper();
      for v84_11_byte in v84_11_cursor.child_mask().iter() {
        v84_11_cursor.descend_to_byte(v84_11_byte);
        let v84_11_tail = v84_11_cursor.make_map();
        v84_11_cursor.ascend(1);
        let v84_11_head = Path::from_slice(&[v84_11_byte]);
        let v85_2: Space = singleton(&(v84_11_head));
        let v85_3: Space = intersect(&(*CONSTANT_2),&(v85_2));
        let v85_4: Space = if has_head(&(v85_3)) { singleton(&[]) } else { Space::new() };
        drop(v85_3);
        let v85_5: Space = subtract(&(*CONSTANT_1),&(v85_4));
        drop(v85_4);
        let v85_8: Space = if (v85_5).is_empty() { Space::new() } else {
          let v86_6: Path = concat_path(&(v84_6),&(v84_11_head));
          let v86_7: Space = routine_15(c, &(v86_6), &(*p1), &(v84_11_tail), &(*s1));
          compose(&(v85_5),&(v86_7))
        };
        drop(v85_5);
        let v85_9: Space = intersect(&(*CONSTANT_2),&(v85_2));
        drop(v85_2);
        let v85_10: Space = if has_head(&(v85_9)) { singleton(&[]) } else { Space::new() };
        drop(v85_9);
        let v85_12: Space = if (v85_10).is_empty() { Space::new() } else {
          let v87_6: Path = concat_path(&(v84_6),&(v84_11_head));
          let v87_11: Space = routine_10(c, &(v87_6), &(*p1), &(v84_11_tail), &(*s1));
          drop(v87_6);
          compose(&(v85_10),&(v87_11))
        };
        drop(v85_10);
        let v85_13: Space = unite(&(v85_8),&(v85_12));
        v84_11.join_into((v85_13).clone());
      }
      drop(v84_11_cursor);
      drop(v84_6);
      compose(&(v79_10),&(v84_11))
    };
    drop(v79_10);
    let v79_13: Space = unite(&(v79_8),&(v79_12));
    v78_13.join_into((v79_13).clone());
  }
  drop(v78_13_cursor);
  (v78_13).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v88_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v88_9: Space = unwrap(&(v88_8),&(*p0));
  drop(v88_8);
  let mut v88_13 = Space::new();
  let mut v88_13_cursor = (*s0).read_zipper();
  for v88_13_byte in v88_13_cursor.child_mask().iter() {
    v88_13_cursor.descend_to_byte(v88_13_byte);
    let v88_13_tail = v88_13_cursor.make_map();
    v88_13_cursor.ascend(1);
    let v88_13_head = Path::from_slice(&[v88_13_byte]);
    let v89_2: Space = singleton(&(v88_13_head));
    let v89_3: Space = intersect(&(*CONSTANT_2),&(v89_2));
    let v89_4: Space = if has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
    drop(v89_3);
    let v89_5: Space = subtract(&(*CONSTANT_1),&(v89_4));
    drop(v89_4);
    let v89_8: Space = if (v89_5).is_empty() { Space::new() } else {
      let v90_6: Path = concat_path(&(*p0),&(v88_13_head));
      let mut v90_7 = Space::new();
      let mut v90_7_cursor = (v88_13_tail).read_zipper();
      for v90_7_byte in v90_7_cursor.child_mask().iter() {
        v90_7_cursor.descend_to_byte(v90_7_byte);
        let v90_7_tail = v90_7_cursor.make_map();
        v90_7_cursor.ascend(1);
        let v90_7_head = Path::from_slice(&[v90_7_byte]);
        let v91_2: Space = singleton(&(v90_7_head));
        let v91_3: Space = intersect(&(*CONSTANT_2),&(v91_2));
        let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
        drop(v91_3);
        let v91_5: Space = subtract(&(*CONSTANT_1),&(v91_4));
        drop(v91_4);
        let v91_8: Space = if (v91_5).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v90_6),&(v90_7_head));
          let v92_7: Space = routine_15(c, &(v92_6), &(*p1), &(v90_7_tail), &(*s1));
          compose(&(v91_5),&(v92_7))
        };
        drop(v91_5);
        let v91_9: Space = intersect(&(*CONSTANT_2),&(v91_2));
        drop(v91_2);
        let v91_10: Space = if has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
        drop(v91_9);
        let v91_12: Space = if (v91_10).is_empty() { Space::new() } else {
          let v93_6: Path = concat_path(&(v90_6),&(v90_7_head));
          let v93_11: Space = routine_16(c, &(v93_6), &(*p1), &(v90_7_tail), &(*s1));
          drop(v93_6);
          compose(&(v91_10),&(v93_11))
        };
        drop(v91_10);
        let v91_13: Space = unite(&(v91_8),&(v91_12));
        v90_7.join_into((v91_13).clone());
      }
      drop(v90_7_cursor);
      compose(&(v89_5),&(v90_7))
    };
    drop(v89_5);
    let v89_9: Space = intersect(&(*CONSTANT_2),&(v89_2));
    drop(v89_2);
    let v89_10: Space = if has_head(&(v89_9)) { singleton(&[]) } else { Space::new() };
    drop(v89_9);
    let v89_13: Space = if (v89_10).is_empty() { Space::new() } else {
      let v94_11: Space = unwrap(&(v88_9),&(v88_13_head));
      let v94_12: Space = unwrap(&(v94_11),&(*p1));
      drop(v94_11);
      compose(&(v89_10),&(v94_12))
    };
    drop(v89_10);
    let v95_6: Path = concat_path(&(*p0),&(v88_13_head));
    let v89_14: Space = wrap(&(v89_13),&(v95_6));
    drop(v89_13);
    let v89_15: Space = wrap(&(v89_14),&(*p1));
    drop(v89_14);
    let v89_16: Space = unite(&(v89_8),&(v89_15));
    drop(v89_15);
    v88_13.join_into((v89_16).clone());
  }
  drop(v88_13_cursor);
  drop(v88_9);
  (v88_13).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v96_5: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v96_6: Space = unwrap(&(v96_5),&(*p0));
  drop(v96_5);
  let v96_7: Space = unwrap(&(v96_6),&(*p1));
  drop(v96_6);
  let v96_8: Space = wrap(&(v96_7),&(*p0));
  drop(v96_7);
  let v96_9: Space = wrap(&(v96_8),&(*p1));
  drop(v96_8);
  (v96_9).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v97_12 = Space::new();
  let mut v97_12_cursor = (*s0).read_zipper();
  for v97_12_byte in v97_12_cursor.child_mask().iter() {
    v97_12_cursor.descend_to_byte(v97_12_byte);
    let v97_12_tail = v97_12_cursor.make_map();
    v97_12_cursor.ascend(1);
    let v97_12_head = Path::from_slice(&[v97_12_byte]);
    let v98_2: Space = singleton(&(v97_12_head));
    let v98_3: Space = intersect(&(*CONSTANT_2),&(v98_2));
    let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
    drop(v98_3);
    let v98_5: Space = subtract(&(*CONSTANT_1),&(v98_4));
    drop(v98_4);
    let v98_8: Space = if (v98_5).is_empty() { Space::new() } else {
      let v99_6: Path = concat_path(&(*p0),&(v97_12_head));
      let mut v99_7 = Space::new();
      let mut v99_7_cursor = (v97_12_tail).read_zipper();
      for v99_7_byte in v99_7_cursor.child_mask().iter() {
        v99_7_cursor.descend_to_byte(v99_7_byte);
        let v99_7_tail = v99_7_cursor.make_map();
        v99_7_cursor.ascend(1);
        let v99_7_head = Path::from_slice(&[v99_7_byte]);
        let v100_2: Space = singleton(&(v99_7_head));
        let v100_3: Space = intersect(&(*CONSTANT_2),&(v100_2));
        let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
        drop(v100_3);
        let v100_5: Space = subtract(&(*CONSTANT_1),&(v100_4));
        drop(v100_4);
        let v100_8: Space = if (v100_5).is_empty() { Space::new() } else {
          let v101_6: Path = concat_path(&(v99_6),&(v99_7_head));
          let v101_7: Space = routine_17(c, &(v101_6), &(v99_7_tail), &(*s1));
          compose(&(v100_5),&(v101_7))
        };
        drop(v100_5);
        let v100_9: Space = intersect(&(*CONSTANT_2),&(v100_2));
        drop(v100_2);
        let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
        drop(v100_9);
        let v100_12: Space = if (v100_10).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v99_6),&(v99_7_head));
          let v102_11: Space = routine_18(c, &(v102_6), &(v99_7_tail), &(*s1));
          drop(v102_6);
          compose(&(v100_10),&(v102_11))
        };
        drop(v100_10);
        let v100_13: Space = unite(&(v100_8),&(v100_12));
        v99_7.join_into((v100_13).clone());
      }
      drop(v99_7_cursor);
      compose(&(v98_5),&(v99_7))
    };
    drop(v98_5);
    let v98_9: Space = intersect(&(*CONSTANT_2),&(v98_2));
    drop(v98_2);
    let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
    drop(v98_9);
    let v98_12: Space = if (v98_10).is_empty() { Space::new() } else {
      let v103_6: Path = concat_path(&(*p0),&(v97_12_head));
      let mut v103_11 = Space::new();
      let mut v103_11_cursor = (v97_12_tail).read_zipper();
      for v103_11_byte in v103_11_cursor.child_mask().iter() {
        v103_11_cursor.descend_to_byte(v103_11_byte);
        let v103_11_tail = v103_11_cursor.make_map();
        v103_11_cursor.ascend(1);
        let v103_11_head = Path::from_slice(&[v103_11_byte]);
        let v104_2: Space = singleton(&(v103_11_head));
        let v104_3: Space = intersect(&(*CONSTANT_2),&(v104_2));
        let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
        drop(v104_3);
        let v104_5: Space = subtract(&(*CONSTANT_1),&(v104_4));
        drop(v104_4);
        let v104_8: Space = if (v104_5).is_empty() { Space::new() } else {
          let v105_6: Path = concat_path(&(v103_6),&(v103_11_head));
          let v105_7: Space = routine_17(c, &(v105_6), &(v103_11_tail), &(*s1));
          compose(&(v104_5),&(v105_7))
        };
        drop(v104_5);
        let v104_9: Space = intersect(&(*CONSTANT_2),&(v104_2));
        drop(v104_2);
        let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
        drop(v104_9);
        let v104_12: Space = if (v104_10).is_empty() { Space::new() } else {
          let v106_6: Path = concat_path(&(v103_6),&(v103_11_head));
          let v106_11: Space = routine_3(c, &(v106_6), &(v103_11_tail), &(*s1));
          drop(v106_6);
          compose(&(v104_10),&(v106_11))
        };
        drop(v104_10);
        let v104_13: Space = unite(&(v104_8),&(v104_12));
        v103_11.join_into((v104_13).clone());
      }
      drop(v103_11_cursor);
      drop(v103_6);
      compose(&(v98_10),&(v103_11))
    };
    drop(v98_10);
    let v98_13: Space = unite(&(v98_8),&(v98_12));
    v97_12.join_into((v98_13).clone());
  }
  drop(v97_12_cursor);
  (v97_12).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v107_12 = Space::new();
  let mut v107_12_cursor = (*s0).read_zipper();
  for v107_12_byte in v107_12_cursor.child_mask().iter() {
    v107_12_cursor.descend_to_byte(v107_12_byte);
    let v107_12_tail = v107_12_cursor.make_map();
    v107_12_cursor.ascend(1);
    let v107_12_head = Path::from_slice(&[v107_12_byte]);
    let v108_2: Space = singleton(&(v107_12_head));
    let v108_3: Space = intersect(&(*CONSTANT_2),&(v108_2));
    let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
    drop(v108_3);
    let v108_5: Space = subtract(&(*CONSTANT_1),&(v108_4));
    drop(v108_4);
    let v108_8: Space = if (v108_5).is_empty() { Space::new() } else {
      let v109_6: Path = concat_path(&(*p0),&(v107_12_head));
      let mut v109_7 = Space::new();
      let mut v109_7_cursor = (v107_12_tail).read_zipper();
      for v109_7_byte in v109_7_cursor.child_mask().iter() {
        v109_7_cursor.descend_to_byte(v109_7_byte);
        let v109_7_tail = v109_7_cursor.make_map();
        v109_7_cursor.ascend(1);
        let v109_7_head = Path::from_slice(&[v109_7_byte]);
        let v110_2: Space = singleton(&(v109_7_head));
        let v110_3: Space = intersect(&(*CONSTANT_2),&(v110_2));
        let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
        drop(v110_3);
        let v110_5: Space = subtract(&(*CONSTANT_1),&(v110_4));
        drop(v110_4);
        let v110_8: Space = if (v110_5).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v109_6),&(v109_7_head));
          let v111_7: Space = routine_17(c, &(v111_6), &(v109_7_tail), &(*s1));
          compose(&(v110_5),&(v111_7))
        };
        drop(v110_5);
        let v110_9: Space = intersect(&(*CONSTANT_2),&(v110_2));
        drop(v110_2);
        let v110_10: Space = if has_head(&(v110_9)) { singleton(&[]) } else { Space::new() };
        drop(v110_9);
        let v110_12: Space = if (v110_10).is_empty() { Space::new() } else {
          let v112_6: Path = concat_path(&(v109_6),&(v109_7_head));
          let v112_11: Space = routine_18(c, &(v112_6), &(v109_7_tail), &(*s1));
          drop(v112_6);
          compose(&(v110_10),&(v112_11))
        };
        drop(v110_10);
        let v110_13: Space = unite(&(v110_8),&(v110_12));
        v109_7.join_into((v110_13).clone());
      }
      drop(v109_7_cursor);
      compose(&(v108_5),&(v109_7))
    };
    drop(v108_5);
    let v108_9: Space = intersect(&(*CONSTANT_2),&(v108_2));
    drop(v108_2);
    let v108_10: Space = if has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
    drop(v108_9);
    let v108_12: Space = if (v108_10).is_empty() { Space::new() } else {
      let v113_6: Path = concat_path(&(*p0),&(v107_12_head));
      let mut v113_11 = Space::new();
      let mut v113_11_cursor = (v107_12_tail).read_zipper();
      for v113_11_byte in v113_11_cursor.child_mask().iter() {
        v113_11_cursor.descend_to_byte(v113_11_byte);
        let v113_11_tail = v113_11_cursor.make_map();
        v113_11_cursor.ascend(1);
        let v113_11_head = Path::from_slice(&[v113_11_byte]);
        let v114_2: Space = singleton(&(v113_11_head));
        let v114_3: Space = intersect(&(*CONSTANT_2),&(v114_2));
        let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
        drop(v114_3);
        let v114_5: Space = subtract(&(*CONSTANT_1),&(v114_4));
        drop(v114_4);
        let v114_7: Space = if (v114_5).is_empty() { Space::new() } else {
          let v115_6: Space = routine_6(c, &(v113_11_head), &(v113_6), &(v113_11_tail), &(*s1));
          compose(&(v114_5),&(v115_6))
        };
        drop(v114_5);
        let v114_8: Space = intersect(&(*CONSTANT_2),&(v114_2));
        drop(v114_2);
        let v114_9: Space = if has_head(&(v114_8)) { singleton(&[]) } else { Space::new() };
        drop(v114_8);
        let v114_11: Space = if (v114_9).is_empty() { Space::new() } else {
          let v116_10: Space = routine_7(c, &(v113_11_head), &(v113_6), &(v113_11_tail), &(*s1));
          compose(&(v114_9),&(v116_10))
        };
        drop(v114_9);
        let v114_12: Space = unite(&(v114_7),&(v114_11));
        v113_11.join_into((v114_12).clone());
      }
      drop(v113_11_cursor);
      drop(v113_6);
      compose(&(v108_10),&(v113_11))
    };
    drop(v108_10);
    let v108_13: Space = unite(&(v108_8),&(v108_12));
    v107_12.join_into((v108_13).clone());
  }
  drop(v107_12_cursor);
  (v107_12).clone()
}

fn routine_13(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v117_13 = Space::new();
  let mut v117_13_cursor = (*s0).read_zipper();
  for v117_13_byte in v117_13_cursor.child_mask().iter() {
    v117_13_cursor.descend_to_byte(v117_13_byte);
    let v117_13_tail = v117_13_cursor.make_map();
    v117_13_cursor.ascend(1);
    let v117_13_head = Path::from_slice(&[v117_13_byte]);
    let v118_2: Space = singleton(&(v117_13_head));
    let v118_3: Space = intersect(&(*CONSTANT_2),&(v118_2));
    let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
    drop(v118_3);
    let v118_5: Space = subtract(&(*CONSTANT_1),&(v118_4));
    drop(v118_4);
    let v118_8: Space = if (v118_5).is_empty() { Space::new() } else {
      let v119_6: Path = concat_path(&(*p0),&(v117_13_head));
      let mut v119_7 = Space::new();
      let mut v119_7_cursor = (v117_13_tail).read_zipper();
      for v119_7_byte in v119_7_cursor.child_mask().iter() {
        v119_7_cursor.descend_to_byte(v119_7_byte);
        let v119_7_tail = v119_7_cursor.make_map();
        v119_7_cursor.ascend(1);
        let v119_7_head = Path::from_slice(&[v119_7_byte]);
        let v120_2: Space = singleton(&(v119_7_head));
        let v120_3: Space = intersect(&(*CONSTANT_2),&(v120_2));
        let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
        drop(v120_3);
        let v120_5: Space = subtract(&(*CONSTANT_1),&(v120_4));
        drop(v120_4);
        let v120_8: Space = if (v120_5).is_empty() { Space::new() } else {
          let v121_6: Path = concat_path(&(v119_6),&(v119_7_head));
          let v121_7: Space = routine_19(c, &(v121_6), &(*p1), &(v119_7_tail), &(*s1));
          compose(&(v120_5),&(v121_7))
        };
        drop(v120_5);
        let v120_9: Space = intersect(&(*CONSTANT_2),&(v120_2));
        drop(v120_2);
        let v120_10: Space = if has_head(&(v120_9)) { singleton(&[]) } else { Space::new() };
        drop(v120_9);
        let v120_12: Space = if (v120_10).is_empty() { Space::new() } else {
          let v122_6: Path = concat_path(&(v119_6),&(v119_7_head));
          let v122_11: Space = routine_20(c, &(v122_6), &(*p1), &(v119_7_tail), &(*s1));
          drop(v122_6);
          compose(&(v120_10),&(v122_11))
        };
        drop(v120_10);
        let v120_13: Space = unite(&(v120_8),&(v120_12));
        v119_7.join_into((v120_13).clone());
      }
      drop(v119_7_cursor);
      compose(&(v118_5),&(v119_7))
    };
    drop(v118_5);
    let v118_9: Space = intersect(&(*CONSTANT_2),&(v118_2));
    drop(v118_2);
    let v118_10: Space = if has_head(&(v118_9)) { singleton(&[]) } else { Space::new() };
    drop(v118_9);
    let v118_12: Space = if (v118_10).is_empty() { Space::new() } else {
      let v123_6: Path = concat_path(&(*p0),&(v117_13_head));
      let mut v123_11 = Space::new();
      let mut v123_11_cursor = (v117_13_tail).read_zipper();
      for v123_11_byte in v123_11_cursor.child_mask().iter() {
        v123_11_cursor.descend_to_byte(v123_11_byte);
        let v123_11_tail = v123_11_cursor.make_map();
        v123_11_cursor.ascend(1);
        let v123_11_head = Path::from_slice(&[v123_11_byte]);
        let v124_2: Space = singleton(&(v123_11_head));
        let v124_3: Space = intersect(&(*CONSTANT_2),&(v124_2));
        let v124_4: Space = if has_head(&(v124_3)) { singleton(&[]) } else { Space::new() };
        drop(v124_3);
        let v124_5: Space = subtract(&(*CONSTANT_1),&(v124_4));
        drop(v124_4);
        let v124_8: Space = if (v124_5).is_empty() { Space::new() } else {
          let v125_6: Path = concat_path(&(v123_6),&(v123_11_head));
          let v125_7: Space = routine_19(c, &(v125_6), &(*p1), &(v123_11_tail), &(*s1));
          compose(&(v124_5),&(v125_7))
        };
        drop(v124_5);
        let v124_9: Space = intersect(&(*CONSTANT_2),&(v124_2));
        drop(v124_2);
        let v124_10: Space = if has_head(&(v124_9)) { singleton(&[]) } else { Space::new() };
        drop(v124_9);
        let v124_12: Space = if (v124_10).is_empty() { Space::new() } else {
          let v126_6: Path = concat_path(&(v123_6),&(v123_11_head));
          let v126_11: Space = routine_10(c, &(v126_6), &(*p1), &(v123_11_tail), &(*s1));
          drop(v126_6);
          compose(&(v124_10),&(v126_11))
        };
        drop(v124_10);
        let v124_13: Space = unite(&(v124_8),&(v124_12));
        v123_11.join_into((v124_13).clone());
      }
      drop(v123_11_cursor);
      drop(v123_6);
      compose(&(v118_10),&(v123_11))
    };
    drop(v118_10);
    let v118_13: Space = unite(&(v118_8),&(v118_12));
    v117_13.join_into((v118_13).clone());
  }
  drop(v117_13_cursor);
  (v117_13).clone()
}

fn routine_14(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v127_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v127_9: Space = unwrap(&(v127_8),&(*p0));
  drop(v127_8);
  let mut v127_13 = Space::new();
  let mut v127_13_cursor = (*s0).read_zipper();
  for v127_13_byte in v127_13_cursor.child_mask().iter() {
    v127_13_cursor.descend_to_byte(v127_13_byte);
    let v127_13_tail = v127_13_cursor.make_map();
    v127_13_cursor.ascend(1);
    let v127_13_head = Path::from_slice(&[v127_13_byte]);
    let v128_2: Space = singleton(&(v127_13_head));
    let v128_3: Space = intersect(&(*CONSTANT_2),&(v128_2));
    let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
    drop(v128_3);
    let v128_5: Space = subtract(&(*CONSTANT_1),&(v128_4));
    drop(v128_4);
    let v128_8: Space = if (v128_5).is_empty() { Space::new() } else {
      let v129_6: Path = concat_path(&(*p0),&(v127_13_head));
      let mut v129_7 = Space::new();
      let mut v129_7_cursor = (v127_13_tail).read_zipper();
      for v129_7_byte in v129_7_cursor.child_mask().iter() {
        v129_7_cursor.descend_to_byte(v129_7_byte);
        let v129_7_tail = v129_7_cursor.make_map();
        v129_7_cursor.ascend(1);
        let v129_7_head = Path::from_slice(&[v129_7_byte]);
        let v130_2: Space = singleton(&(v129_7_head));
        let v130_3: Space = intersect(&(*CONSTANT_2),&(v130_2));
        let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
        drop(v130_3);
        let v130_5: Space = subtract(&(*CONSTANT_1),&(v130_4));
        drop(v130_4);
        let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
          let v131_6: Path = concat_path(&(v129_6),&(v129_7_head));
          let v131_7: Space = routine_19(c, &(v131_6), &(*p1), &(v129_7_tail), &(*s1));
          compose(&(v130_5),&(v131_7))
        };
        drop(v130_5);
        let v130_9: Space = intersect(&(*CONSTANT_2),&(v130_2));
        drop(v130_2);
        let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
        drop(v130_9);
        let v130_12: Space = if (v130_10).is_empty() { Space::new() } else {
          let v132_6: Path = concat_path(&(v129_6),&(v129_7_head));
          let v132_11: Space = routine_20(c, &(v132_6), &(*p1), &(v129_7_tail), &(*s1));
          drop(v132_6);
          compose(&(v130_10),&(v132_11))
        };
        drop(v130_10);
        let v130_13: Space = unite(&(v130_8),&(v130_12));
        v129_7.join_into((v130_13).clone());
      }
      drop(v129_7_cursor);
      compose(&(v128_5),&(v129_7))
    };
    drop(v128_5);
    let v128_9: Space = intersect(&(*CONSTANT_2),&(v128_2));
    drop(v128_2);
    let v128_10: Space = if has_head(&(v128_9)) { singleton(&[]) } else { Space::new() };
    drop(v128_9);
    let v128_13: Space = if (v128_10).is_empty() { Space::new() } else {
      let v133_11: Space = unwrap(&(v127_9),&(v127_13_head));
      let v133_12: Space = unwrap(&(v133_11),&(*p1));
      drop(v133_11);
      compose(&(v128_10),&(v133_12))
    };
    drop(v128_10);
    let v134_6: Path = concat_path(&(*p0),&(v127_13_head));
    let v128_14: Space = wrap(&(v128_13),&(v134_6));
    drop(v128_13);
    let v128_15: Space = wrap(&(v128_14),&(*p1));
    drop(v128_14);
    let v128_16: Space = unite(&(v128_8),&(v128_15));
    drop(v128_15);
    v127_13.join_into((v128_16).clone());
  }
  drop(v127_13_cursor);
  drop(v127_9);
  (v127_13).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v135_13 = Space::new();
  let mut v135_13_cursor = (*s0).read_zipper();
  for v135_13_byte in v135_13_cursor.child_mask().iter() {
    v135_13_cursor.descend_to_byte(v135_13_byte);
    let v135_13_tail = v135_13_cursor.make_map();
    v135_13_cursor.ascend(1);
    let v135_13_head = Path::from_slice(&[v135_13_byte]);
    let v136_2: Space = singleton(&(v135_13_head));
    let v136_3: Space = intersect(&(*CONSTANT_2),&(v136_2));
    let v136_4: Space = if has_head(&(v136_3)) { singleton(&[]) } else { Space::new() };
    drop(v136_3);
    let v136_5: Space = subtract(&(*CONSTANT_1),&(v136_4));
    drop(v136_4);
    let v136_8: Space = if (v136_5).is_empty() { Space::new() } else {
      let v137_6: Path = concat_path(&(*p0),&(v135_13_head));
      let mut v137_7 = Space::new();
      let mut v137_7_cursor = (v135_13_tail).read_zipper();
      for v137_7_byte in v137_7_cursor.child_mask().iter() {
        v137_7_cursor.descend_to_byte(v137_7_byte);
        let v137_7_tail = v137_7_cursor.make_map();
        v137_7_cursor.ascend(1);
        let v137_7_head = Path::from_slice(&[v137_7_byte]);
        let v138_2: Space = singleton(&(v137_7_head));
        let v138_3: Space = intersect(&(*CONSTANT_2),&(v138_2));
        let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
        drop(v138_3);
        let v138_5: Space = subtract(&(*CONSTANT_1),&(v138_4));
        drop(v138_4);
        let v138_8: Space = if (v138_5).is_empty() { Space::new() } else {
          let v139_6: Path = concat_path(&(v137_6),&(v137_7_head));
          let v139_7: Space = routine_21(c, &(v139_6), &(*p1), &(v137_7_tail), &(*s1));
          compose(&(v138_5),&(v139_7))
        };
        drop(v138_5);
        let v138_9: Space = intersect(&(*CONSTANT_2),&(v138_2));
        drop(v138_2);
        let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
        drop(v138_9);
        let v138_12: Space = if (v138_10).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v137_6),&(v137_7_head));
          let v140_11: Space = routine_22(c, &(v140_6), &(*p1), &(v137_7_tail), &(*s1));
          drop(v140_6);
          compose(&(v138_10),&(v140_11))
        };
        drop(v138_10);
        let v138_13: Space = unite(&(v138_8),&(v138_12));
        v137_7.join_into((v138_13).clone());
      }
      drop(v137_7_cursor);
      compose(&(v136_5),&(v137_7))
    };
    drop(v136_5);
    let v136_9: Space = intersect(&(*CONSTANT_2),&(v136_2));
    drop(v136_2);
    let v136_10: Space = if has_head(&(v136_9)) { singleton(&[]) } else { Space::new() };
    drop(v136_9);
    let v136_12: Space = if (v136_10).is_empty() { Space::new() } else {
      let v141_6: Path = concat_path(&(*p0),&(v135_13_head));
      let mut v141_11 = Space::new();
      let mut v141_11_cursor = (v135_13_tail).read_zipper();
      for v141_11_byte in v141_11_cursor.child_mask().iter() {
        v141_11_cursor.descend_to_byte(v141_11_byte);
        let v141_11_tail = v141_11_cursor.make_map();
        v141_11_cursor.ascend(1);
        let v141_11_head = Path::from_slice(&[v141_11_byte]);
        let v142_2: Space = singleton(&(v141_11_head));
        let v142_3: Space = intersect(&(*CONSTANT_2),&(v142_2));
        let v142_4: Space = if has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
        drop(v142_3);
        let v142_5: Space = subtract(&(*CONSTANT_1),&(v142_4));
        drop(v142_4);
        let v142_8: Space = if (v142_5).is_empty() { Space::new() } else {
          let v143_6: Path = concat_path(&(v141_6),&(v141_11_head));
          let v143_7: Space = routine_21(c, &(v143_6), &(*p1), &(v141_11_tail), &(*s1));
          compose(&(v142_5),&(v143_7))
        };
        drop(v142_5);
        let v142_9: Space = intersect(&(*CONSTANT_2),&(v142_2));
        drop(v142_2);
        let v142_10: Space = if has_head(&(v142_9)) { singleton(&[]) } else { Space::new() };
        drop(v142_9);
        let v142_12: Space = if (v142_10).is_empty() { Space::new() } else {
          let v144_6: Path = concat_path(&(v141_6),&(v141_11_head));
          let v144_11: Space = routine_10(c, &(v144_6), &(*p1), &(v141_11_tail), &(*s1));
          drop(v144_6);
          compose(&(v142_10),&(v144_11))
        };
        drop(v142_10);
        let v142_13: Space = unite(&(v142_8),&(v142_12));
        v141_11.join_into((v142_13).clone());
      }
      drop(v141_11_cursor);
      drop(v141_6);
      compose(&(v136_10),&(v141_11))
    };
    drop(v136_10);
    let v136_13: Space = unite(&(v136_8),&(v136_12));
    v135_13.join_into((v136_13).clone());
  }
  drop(v135_13_cursor);
  (v135_13).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v145_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v145_9: Space = unwrap(&(v145_8),&(*p0));
  drop(v145_8);
  let mut v145_13 = Space::new();
  let mut v145_13_cursor = (*s0).read_zipper();
  for v145_13_byte in v145_13_cursor.child_mask().iter() {
    v145_13_cursor.descend_to_byte(v145_13_byte);
    let v145_13_tail = v145_13_cursor.make_map();
    v145_13_cursor.ascend(1);
    let v145_13_head = Path::from_slice(&[v145_13_byte]);
    let v146_2: Space = singleton(&(v145_13_head));
    let v146_3: Space = intersect(&(*CONSTANT_2),&(v146_2));
    let v146_4: Space = if has_head(&(v146_3)) { singleton(&[]) } else { Space::new() };
    drop(v146_3);
    let v146_5: Space = subtract(&(*CONSTANT_1),&(v146_4));
    drop(v146_4);
    let v146_8: Space = if (v146_5).is_empty() { Space::new() } else {
      let v147_6: Path = concat_path(&(*p0),&(v145_13_head));
      let mut v147_7 = Space::new();
      let mut v147_7_cursor = (v145_13_tail).read_zipper();
      for v147_7_byte in v147_7_cursor.child_mask().iter() {
        v147_7_cursor.descend_to_byte(v147_7_byte);
        let v147_7_tail = v147_7_cursor.make_map();
        v147_7_cursor.ascend(1);
        let v147_7_head = Path::from_slice(&[v147_7_byte]);
        let v148_2: Space = singleton(&(v147_7_head));
        let v148_3: Space = intersect(&(*CONSTANT_2),&(v148_2));
        let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
        drop(v148_3);
        let v148_5: Space = subtract(&(*CONSTANT_1),&(v148_4));
        drop(v148_4);
        let v148_8: Space = if (v148_5).is_empty() { Space::new() } else {
          let v149_6: Path = concat_path(&(v147_6),&(v147_7_head));
          let v149_7: Space = routine_21(c, &(v149_6), &(*p1), &(v147_7_tail), &(*s1));
          compose(&(v148_5),&(v149_7))
        };
        drop(v148_5);
        let v148_9: Space = intersect(&(*CONSTANT_2),&(v148_2));
        drop(v148_2);
        let v148_10: Space = if has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
        drop(v148_9);
        let v148_12: Space = if (v148_10).is_empty() { Space::new() } else {
          let v150_6: Path = concat_path(&(v147_6),&(v147_7_head));
          let v150_11: Space = routine_22(c, &(v150_6), &(*p1), &(v147_7_tail), &(*s1));
          drop(v150_6);
          compose(&(v148_10),&(v150_11))
        };
        drop(v148_10);
        let v148_13: Space = unite(&(v148_8),&(v148_12));
        v147_7.join_into((v148_13).clone());
      }
      drop(v147_7_cursor);
      compose(&(v146_5),&(v147_7))
    };
    drop(v146_5);
    let v146_9: Space = intersect(&(*CONSTANT_2),&(v146_2));
    drop(v146_2);
    let v146_10: Space = if has_head(&(v146_9)) { singleton(&[]) } else { Space::new() };
    drop(v146_9);
    let v146_13: Space = if (v146_10).is_empty() { Space::new() } else {
      let v151_11: Space = unwrap(&(v145_9),&(v145_13_head));
      let v151_12: Space = unwrap(&(v151_11),&(*p1));
      drop(v151_11);
      compose(&(v146_10),&(v151_12))
    };
    drop(v146_10);
    let v152_6: Path = concat_path(&(*p0),&(v145_13_head));
    let v146_14: Space = wrap(&(v146_13),&(v152_6));
    drop(v146_13);
    let v146_15: Space = wrap(&(v146_14),&(*p1));
    drop(v146_14);
    let v146_16: Space = unite(&(v146_8),&(v146_15));
    drop(v146_15);
    v145_13.join_into((v146_16).clone());
  }
  drop(v145_13_cursor);
  drop(v145_9);
  (v145_13).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v153_12 = Space::new();
  let mut v153_12_cursor = (*s0).read_zipper();
  for v153_12_byte in v153_12_cursor.child_mask().iter() {
    v153_12_cursor.descend_to_byte(v153_12_byte);
    let v153_12_tail = v153_12_cursor.make_map();
    v153_12_cursor.ascend(1);
    let v153_12_head = Path::from_slice(&[v153_12_byte]);
    let v154_2: Space = singleton(&(v153_12_head));
    let v154_3: Space = intersect(&(*CONSTANT_2),&(v154_2));
    let v154_4: Space = if has_head(&(v154_3)) { singleton(&[]) } else { Space::new() };
    drop(v154_3);
    let v154_5: Space = subtract(&(*CONSTANT_1),&(v154_4));
    drop(v154_4);
    let v154_8: Space = if (v154_5).is_empty() { Space::new() } else {
      let v155_6: Path = concat_path(&(*p0),&(v153_12_head));
      let mut v155_7 = Space::new();
      let mut v155_7_cursor = (v153_12_tail).read_zipper();
      for v155_7_byte in v155_7_cursor.child_mask().iter() {
        v155_7_cursor.descend_to_byte(v155_7_byte);
        let v155_7_tail = v155_7_cursor.make_map();
        v155_7_cursor.ascend(1);
        let v155_7_head = Path::from_slice(&[v155_7_byte]);
        let v156_2: Space = singleton(&(v155_7_head));
        let v156_3: Space = intersect(&(*CONSTANT_2),&(v156_2));
        let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
        drop(v156_3);
        let v156_5: Space = subtract(&(*CONSTANT_1),&(v156_4));
        drop(v156_4);
        let v156_8: Space = if (v156_5).is_empty() { Space::new() } else {
          let v157_6: Path = concat_path(&(v155_6),&(v155_7_head));
          let v157_7: Space = routine_23(c, &(v157_6), &(v155_7_tail), &(*s1));
          compose(&(v156_5),&(v157_7))
        };
        drop(v156_5);
        let v156_9: Space = intersect(&(*CONSTANT_2),&(v156_2));
        drop(v156_2);
        let v156_10: Space = if has_head(&(v156_9)) { singleton(&[]) } else { Space::new() };
        drop(v156_9);
        let v156_12: Space = if (v156_10).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v155_6),&(v155_7_head));
          let v158_11: Space = routine_24(c, &(v158_6), &(v155_7_tail), &(*s1));
          drop(v158_6);
          compose(&(v156_10),&(v158_11))
        };
        drop(v156_10);
        let v156_13: Space = unite(&(v156_8),&(v156_12));
        v155_7.join_into((v156_13).clone());
      }
      drop(v155_7_cursor);
      compose(&(v154_5),&(v155_7))
    };
    drop(v154_5);
    let v154_9: Space = intersect(&(*CONSTANT_2),&(v154_2));
    drop(v154_2);
    let v154_10: Space = if has_head(&(v154_9)) { singleton(&[]) } else { Space::new() };
    drop(v154_9);
    let v154_12: Space = if (v154_10).is_empty() { Space::new() } else {
      let v159_6: Path = concat_path(&(*p0),&(v153_12_head));
      let mut v159_11 = Space::new();
      let mut v159_11_cursor = (v153_12_tail).read_zipper();
      for v159_11_byte in v159_11_cursor.child_mask().iter() {
        v159_11_cursor.descend_to_byte(v159_11_byte);
        let v159_11_tail = v159_11_cursor.make_map();
        v159_11_cursor.ascend(1);
        let v159_11_head = Path::from_slice(&[v159_11_byte]);
        let v160_2: Space = singleton(&(v159_11_head));
        let v160_3: Space = intersect(&(*CONSTANT_2),&(v160_2));
        let v160_4: Space = if has_head(&(v160_3)) { singleton(&[]) } else { Space::new() };
        drop(v160_3);
        let v160_5: Space = subtract(&(*CONSTANT_1),&(v160_4));
        drop(v160_4);
        let v160_8: Space = if (v160_5).is_empty() { Space::new() } else {
          let v161_6: Path = concat_path(&(v159_6),&(v159_11_head));
          let v161_7: Space = routine_23(c, &(v161_6), &(v159_11_tail), &(*s1));
          compose(&(v160_5),&(v161_7))
        };
        drop(v160_5);
        let v160_9: Space = intersect(&(*CONSTANT_2),&(v160_2));
        drop(v160_2);
        let v160_10: Space = if has_head(&(v160_9)) { singleton(&[]) } else { Space::new() };
        drop(v160_9);
        let v160_12: Space = if (v160_10).is_empty() { Space::new() } else {
          let v162_6: Path = concat_path(&(v159_6),&(v159_11_head));
          let v162_11: Space = routine_3(c, &(v162_6), &(v159_11_tail), &(*s1));
          drop(v162_6);
          compose(&(v160_10),&(v162_11))
        };
        drop(v160_10);
        let v160_13: Space = unite(&(v160_8),&(v160_12));
        v159_11.join_into((v160_13).clone());
      }
      drop(v159_11_cursor);
      drop(v159_6);
      compose(&(v154_10),&(v159_11))
    };
    drop(v154_10);
    let v154_13: Space = unite(&(v154_8),&(v154_12));
    v153_12.join_into((v154_13).clone());
  }
  drop(v153_12_cursor);
  (v153_12).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v163_12 = Space::new();
  let mut v163_12_cursor = (*s0).read_zipper();
  for v163_12_byte in v163_12_cursor.child_mask().iter() {
    v163_12_cursor.descend_to_byte(v163_12_byte);
    let v163_12_tail = v163_12_cursor.make_map();
    v163_12_cursor.ascend(1);
    let v163_12_head = Path::from_slice(&[v163_12_byte]);
    let v164_2: Space = singleton(&(v163_12_head));
    let v164_3: Space = intersect(&(*CONSTANT_2),&(v164_2));
    let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
    drop(v164_3);
    let v164_5: Space = subtract(&(*CONSTANT_1),&(v164_4));
    drop(v164_4);
    let v164_8: Space = if (v164_5).is_empty() { Space::new() } else {
      let v165_6: Path = concat_path(&(*p0),&(v163_12_head));
      let mut v165_7 = Space::new();
      let mut v165_7_cursor = (v163_12_tail).read_zipper();
      for v165_7_byte in v165_7_cursor.child_mask().iter() {
        v165_7_cursor.descend_to_byte(v165_7_byte);
        let v165_7_tail = v165_7_cursor.make_map();
        v165_7_cursor.ascend(1);
        let v165_7_head = Path::from_slice(&[v165_7_byte]);
        let v166_2: Space = singleton(&(v165_7_head));
        let v166_3: Space = intersect(&(*CONSTANT_2),&(v166_2));
        let v166_4: Space = if has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
        drop(v166_3);
        let v166_5: Space = subtract(&(*CONSTANT_1),&(v166_4));
        drop(v166_4);
        let v166_8: Space = if (v166_5).is_empty() { Space::new() } else {
          let v167_6: Path = concat_path(&(v165_6),&(v165_7_head));
          let v167_7: Space = routine_23(c, &(v167_6), &(v165_7_tail), &(*s1));
          compose(&(v166_5),&(v167_7))
        };
        drop(v166_5);
        let v166_9: Space = intersect(&(*CONSTANT_2),&(v166_2));
        drop(v166_2);
        let v166_10: Space = if has_head(&(v166_9)) { singleton(&[]) } else { Space::new() };
        drop(v166_9);
        let v166_12: Space = if (v166_10).is_empty() { Space::new() } else {
          let v168_6: Path = concat_path(&(v165_6),&(v165_7_head));
          let v168_11: Space = routine_24(c, &(v168_6), &(v165_7_tail), &(*s1));
          drop(v168_6);
          compose(&(v166_10),&(v168_11))
        };
        drop(v166_10);
        let v166_13: Space = unite(&(v166_8),&(v166_12));
        v165_7.join_into((v166_13).clone());
      }
      drop(v165_7_cursor);
      compose(&(v164_5),&(v165_7))
    };
    drop(v164_5);
    let v164_9: Space = intersect(&(*CONSTANT_2),&(v164_2));
    drop(v164_2);
    let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
    drop(v164_9);
    let v164_12: Space = if (v164_10).is_empty() { Space::new() } else {
      let v169_6: Path = concat_path(&(*p0),&(v163_12_head));
      let mut v169_11 = Space::new();
      let mut v169_11_cursor = (v163_12_tail).read_zipper();
      for v169_11_byte in v169_11_cursor.child_mask().iter() {
        v169_11_cursor.descend_to_byte(v169_11_byte);
        let v169_11_tail = v169_11_cursor.make_map();
        v169_11_cursor.ascend(1);
        let v169_11_head = Path::from_slice(&[v169_11_byte]);
        let v170_2: Space = singleton(&(v169_11_head));
        let v170_3: Space = intersect(&(*CONSTANT_2),&(v170_2));
        let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
        drop(v170_3);
        let v170_5: Space = subtract(&(*CONSTANT_1),&(v170_4));
        drop(v170_4);
        let v170_7: Space = if (v170_5).is_empty() { Space::new() } else {
          let v171_6: Space = routine_6(c, &(v169_11_head), &(v169_6), &(v169_11_tail), &(*s1));
          compose(&(v170_5),&(v171_6))
        };
        drop(v170_5);
        let v170_8: Space = intersect(&(*CONSTANT_2),&(v170_2));
        drop(v170_2);
        let v170_9: Space = if has_head(&(v170_8)) { singleton(&[]) } else { Space::new() };
        drop(v170_8);
        let v170_11: Space = if (v170_9).is_empty() { Space::new() } else {
          let v172_10: Space = routine_7(c, &(v169_11_head), &(v169_6), &(v169_11_tail), &(*s1));
          compose(&(v170_9),&(v172_10))
        };
        drop(v170_9);
        let v170_12: Space = unite(&(v170_7),&(v170_11));
        v169_11.join_into((v170_12).clone());
      }
      drop(v169_11_cursor);
      drop(v169_6);
      compose(&(v164_10),&(v169_11))
    };
    drop(v164_10);
    let v164_13: Space = unite(&(v164_8),&(v164_12));
    v163_12.join_into((v164_13).clone());
  }
  drop(v163_12_cursor);
  (v163_12).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v173_13 = Space::new();
  let mut v173_13_cursor = (*s0).read_zipper();
  for v173_13_byte in v173_13_cursor.child_mask().iter() {
    v173_13_cursor.descend_to_byte(v173_13_byte);
    let v173_13_tail = v173_13_cursor.make_map();
    v173_13_cursor.ascend(1);
    let v173_13_head = Path::from_slice(&[v173_13_byte]);
    let v174_2: Space = singleton(&(v173_13_head));
    let v174_3: Space = intersect(&(*CONSTANT_2),&(v174_2));
    let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
    drop(v174_3);
    let v174_5: Space = subtract(&(*CONSTANT_1),&(v174_4));
    drop(v174_4);
    let v174_8: Space = if (v174_5).is_empty() { Space::new() } else {
      let v175_6: Path = concat_path(&(*p0),&(v173_13_head));
      let mut v175_7 = Space::new();
      let mut v175_7_cursor = (v173_13_tail).read_zipper();
      for v175_7_byte in v175_7_cursor.child_mask().iter() {
        v175_7_cursor.descend_to_byte(v175_7_byte);
        let v175_7_tail = v175_7_cursor.make_map();
        v175_7_cursor.ascend(1);
        let v175_7_head = Path::from_slice(&[v175_7_byte]);
        let v176_2: Space = singleton(&(v175_7_head));
        let v176_3: Space = intersect(&(*CONSTANT_2),&(v176_2));
        let v176_4: Space = if has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
        drop(v176_3);
        let v176_5: Space = subtract(&(*CONSTANT_1),&(v176_4));
        drop(v176_4);
        let v176_8: Space = if (v176_5).is_empty() { Space::new() } else {
          let v177_6: Path = concat_path(&(v175_6),&(v175_7_head));
          let v177_7: Space = routine_25(c, &(v177_6), &(*p1), &(v175_7_tail), &(*s1));
          compose(&(v176_5),&(v177_7))
        };
        drop(v176_5);
        let v176_9: Space = intersect(&(*CONSTANT_2),&(v176_2));
        drop(v176_2);
        let v176_10: Space = if has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
        drop(v176_9);
        let v176_12: Space = if (v176_10).is_empty() { Space::new() } else {
          let v178_6: Path = concat_path(&(v175_6),&(v175_7_head));
          let v178_11: Space = routine_26(c, &(v178_6), &(*p1), &(v175_7_tail), &(*s1));
          drop(v178_6);
          compose(&(v176_10),&(v178_11))
        };
        drop(v176_10);
        let v176_13: Space = unite(&(v176_8),&(v176_12));
        v175_7.join_into((v176_13).clone());
      }
      drop(v175_7_cursor);
      compose(&(v174_5),&(v175_7))
    };
    drop(v174_5);
    let v174_9: Space = intersect(&(*CONSTANT_2),&(v174_2));
    drop(v174_2);
    let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
    drop(v174_9);
    let v174_12: Space = if (v174_10).is_empty() { Space::new() } else {
      let v179_6: Path = concat_path(&(*p0),&(v173_13_head));
      let mut v179_11 = Space::new();
      let mut v179_11_cursor = (v173_13_tail).read_zipper();
      for v179_11_byte in v179_11_cursor.child_mask().iter() {
        v179_11_cursor.descend_to_byte(v179_11_byte);
        let v179_11_tail = v179_11_cursor.make_map();
        v179_11_cursor.ascend(1);
        let v179_11_head = Path::from_slice(&[v179_11_byte]);
        let v180_2: Space = singleton(&(v179_11_head));
        let v180_3: Space = intersect(&(*CONSTANT_2),&(v180_2));
        let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
        drop(v180_3);
        let v180_5: Space = subtract(&(*CONSTANT_1),&(v180_4));
        drop(v180_4);
        let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v179_6),&(v179_11_head));
          let v181_7: Space = routine_25(c, &(v181_6), &(*p1), &(v179_11_tail), &(*s1));
          compose(&(v180_5),&(v181_7))
        };
        drop(v180_5);
        let v180_9: Space = intersect(&(*CONSTANT_2),&(v180_2));
        drop(v180_2);
        let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
        drop(v180_9);
        let v180_12: Space = if (v180_10).is_empty() { Space::new() } else {
          let v182_6: Path = concat_path(&(v179_6),&(v179_11_head));
          let v182_11: Space = routine_10(c, &(v182_6), &(*p1), &(v179_11_tail), &(*s1));
          drop(v182_6);
          compose(&(v180_10),&(v182_11))
        };
        drop(v180_10);
        let v180_13: Space = unite(&(v180_8),&(v180_12));
        v179_11.join_into((v180_13).clone());
      }
      drop(v179_11_cursor);
      drop(v179_6);
      compose(&(v174_10),&(v179_11))
    };
    drop(v174_10);
    let v174_13: Space = unite(&(v174_8),&(v174_12));
    v173_13.join_into((v174_13).clone());
  }
  drop(v173_13_cursor);
  (v173_13).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v183_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v183_9: Space = unwrap(&(v183_8),&(*p0));
  drop(v183_8);
  let mut v183_13 = Space::new();
  let mut v183_13_cursor = (*s0).read_zipper();
  for v183_13_byte in v183_13_cursor.child_mask().iter() {
    v183_13_cursor.descend_to_byte(v183_13_byte);
    let v183_13_tail = v183_13_cursor.make_map();
    v183_13_cursor.ascend(1);
    let v183_13_head = Path::from_slice(&[v183_13_byte]);
    let v184_2: Space = singleton(&(v183_13_head));
    let v184_3: Space = intersect(&(*CONSTANT_2),&(v184_2));
    let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
    drop(v184_3);
    let v184_5: Space = subtract(&(*CONSTANT_1),&(v184_4));
    drop(v184_4);
    let v184_8: Space = if (v184_5).is_empty() { Space::new() } else {
      let v185_6: Path = concat_path(&(*p0),&(v183_13_head));
      let mut v185_7 = Space::new();
      let mut v185_7_cursor = (v183_13_tail).read_zipper();
      for v185_7_byte in v185_7_cursor.child_mask().iter() {
        v185_7_cursor.descend_to_byte(v185_7_byte);
        let v185_7_tail = v185_7_cursor.make_map();
        v185_7_cursor.ascend(1);
        let v185_7_head = Path::from_slice(&[v185_7_byte]);
        let v186_2: Space = singleton(&(v185_7_head));
        let v186_3: Space = intersect(&(*CONSTANT_2),&(v186_2));
        let v186_4: Space = if has_head(&(v186_3)) { singleton(&[]) } else { Space::new() };
        drop(v186_3);
        let v186_5: Space = subtract(&(*CONSTANT_1),&(v186_4));
        drop(v186_4);
        let v186_8: Space = if (v186_5).is_empty() { Space::new() } else {
          let v187_6: Path = concat_path(&(v185_6),&(v185_7_head));
          let v187_7: Space = routine_25(c, &(v187_6), &(*p1), &(v185_7_tail), &(*s1));
          compose(&(v186_5),&(v187_7))
        };
        drop(v186_5);
        let v186_9: Space = intersect(&(*CONSTANT_2),&(v186_2));
        drop(v186_2);
        let v186_10: Space = if has_head(&(v186_9)) { singleton(&[]) } else { Space::new() };
        drop(v186_9);
        let v186_12: Space = if (v186_10).is_empty() { Space::new() } else {
          let v188_6: Path = concat_path(&(v185_6),&(v185_7_head));
          let v188_11: Space = routine_26(c, &(v188_6), &(*p1), &(v185_7_tail), &(*s1));
          drop(v188_6);
          compose(&(v186_10),&(v188_11))
        };
        drop(v186_10);
        let v186_13: Space = unite(&(v186_8),&(v186_12));
        v185_7.join_into((v186_13).clone());
      }
      drop(v185_7_cursor);
      compose(&(v184_5),&(v185_7))
    };
    drop(v184_5);
    let v184_9: Space = intersect(&(*CONSTANT_2),&(v184_2));
    drop(v184_2);
    let v184_10: Space = if has_head(&(v184_9)) { singleton(&[]) } else { Space::new() };
    drop(v184_9);
    let v184_13: Space = if (v184_10).is_empty() { Space::new() } else {
      let v189_11: Space = unwrap(&(v183_9),&(v183_13_head));
      let v189_12: Space = unwrap(&(v189_11),&(*p1));
      drop(v189_11);
      compose(&(v184_10),&(v189_12))
    };
    drop(v184_10);
    let v190_6: Path = concat_path(&(*p0),&(v183_13_head));
    let v184_14: Space = wrap(&(v184_13),&(v190_6));
    drop(v184_13);
    let v184_15: Space = wrap(&(v184_14),&(*p1));
    drop(v184_14);
    let v184_16: Space = unite(&(v184_8),&(v184_15));
    drop(v184_15);
    v183_13.join_into((v184_16).clone());
  }
  drop(v183_13_cursor);
  drop(v183_9);
  (v183_13).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v191_13 = Space::new();
  let mut v191_13_cursor = (*s0).read_zipper();
  for v191_13_byte in v191_13_cursor.child_mask().iter() {
    v191_13_cursor.descend_to_byte(v191_13_byte);
    let v191_13_tail = v191_13_cursor.make_map();
    v191_13_cursor.ascend(1);
    let v191_13_head = Path::from_slice(&[v191_13_byte]);
    let v192_2: Space = singleton(&(v191_13_head));
    let v192_3: Space = intersect(&(*CONSTANT_2),&(v192_2));
    let v192_4: Space = if has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
    drop(v192_3);
    let v192_5: Space = subtract(&(*CONSTANT_1),&(v192_4));
    drop(v192_4);
    let v192_8: Space = if (v192_5).is_empty() { Space::new() } else {
      let v193_6: Path = concat_path(&(*p0),&(v191_13_head));
      let mut v193_7 = Space::new();
      let mut v193_7_cursor = (v191_13_tail).read_zipper();
      for v193_7_byte in v193_7_cursor.child_mask().iter() {
        v193_7_cursor.descend_to_byte(v193_7_byte);
        let v193_7_tail = v193_7_cursor.make_map();
        v193_7_cursor.ascend(1);
        let v193_7_head = Path::from_slice(&[v193_7_byte]);
        let v194_2: Space = singleton(&(v193_7_head));
        let v194_3: Space = intersect(&(*CONSTANT_2),&(v194_2));
        let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
        drop(v194_3);
        let v194_5: Space = subtract(&(*CONSTANT_1),&(v194_4));
        drop(v194_4);
        let v194_8: Space = if (v194_5).is_empty() { Space::new() } else {
          let v195_6: Path = concat_path(&(v193_6),&(v193_7_head));
          let v195_7: Space = routine_27(c, &(v195_6), &(*p1), &(v193_7_tail), &(*s1));
          compose(&(v194_5),&(v195_7))
        };
        drop(v194_5);
        let v194_9: Space = intersect(&(*CONSTANT_2),&(v194_2));
        drop(v194_2);
        let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
        drop(v194_9);
        let v194_12: Space = if (v194_10).is_empty() { Space::new() } else {
          let v196_6: Path = concat_path(&(v193_6),&(v193_7_head));
          let v196_11: Space = routine_28(c, &(v196_6), &(*p1), &(v193_7_tail), &(*s1));
          drop(v196_6);
          compose(&(v194_10),&(v196_11))
        };
        drop(v194_10);
        let v194_13: Space = unite(&(v194_8),&(v194_12));
        v193_7.join_into((v194_13).clone());
      }
      drop(v193_7_cursor);
      compose(&(v192_5),&(v193_7))
    };
    drop(v192_5);
    let v192_9: Space = intersect(&(*CONSTANT_2),&(v192_2));
    drop(v192_2);
    let v192_10: Space = if has_head(&(v192_9)) { singleton(&[]) } else { Space::new() };
    drop(v192_9);
    let v192_12: Space = if (v192_10).is_empty() { Space::new() } else {
      let v197_6: Path = concat_path(&(*p0),&(v191_13_head));
      let mut v197_11 = Space::new();
      let mut v197_11_cursor = (v191_13_tail).read_zipper();
      for v197_11_byte in v197_11_cursor.child_mask().iter() {
        v197_11_cursor.descend_to_byte(v197_11_byte);
        let v197_11_tail = v197_11_cursor.make_map();
        v197_11_cursor.ascend(1);
        let v197_11_head = Path::from_slice(&[v197_11_byte]);
        let v198_2: Space = singleton(&(v197_11_head));
        let v198_3: Space = intersect(&(*CONSTANT_2),&(v198_2));
        let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
        drop(v198_3);
        let v198_5: Space = subtract(&(*CONSTANT_1),&(v198_4));
        drop(v198_4);
        let v198_8: Space = if (v198_5).is_empty() { Space::new() } else {
          let v199_6: Path = concat_path(&(v197_6),&(v197_11_head));
          let v199_7: Space = routine_27(c, &(v199_6), &(*p1), &(v197_11_tail), &(*s1));
          compose(&(v198_5),&(v199_7))
        };
        drop(v198_5);
        let v198_9: Space = intersect(&(*CONSTANT_2),&(v198_2));
        drop(v198_2);
        let v198_10: Space = if has_head(&(v198_9)) { singleton(&[]) } else { Space::new() };
        drop(v198_9);
        let v198_12: Space = if (v198_10).is_empty() { Space::new() } else {
          let v200_6: Path = concat_path(&(v197_6),&(v197_11_head));
          let v200_11: Space = routine_10(c, &(v200_6), &(*p1), &(v197_11_tail), &(*s1));
          drop(v200_6);
          compose(&(v198_10),&(v200_11))
        };
        drop(v198_10);
        let v198_13: Space = unite(&(v198_8),&(v198_12));
        v197_11.join_into((v198_13).clone());
      }
      drop(v197_11_cursor);
      drop(v197_6);
      compose(&(v192_10),&(v197_11))
    };
    drop(v192_10);
    let v192_13: Space = unite(&(v192_8),&(v192_12));
    v191_13.join_into((v192_13).clone());
  }
  drop(v191_13_cursor);
  (v191_13).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v201_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v201_9: Space = unwrap(&(v201_8),&(*p0));
  drop(v201_8);
  let mut v201_13 = Space::new();
  let mut v201_13_cursor = (*s0).read_zipper();
  for v201_13_byte in v201_13_cursor.child_mask().iter() {
    v201_13_cursor.descend_to_byte(v201_13_byte);
    let v201_13_tail = v201_13_cursor.make_map();
    v201_13_cursor.ascend(1);
    let v201_13_head = Path::from_slice(&[v201_13_byte]);
    let v202_2: Space = singleton(&(v201_13_head));
    let v202_3: Space = intersect(&(*CONSTANT_2),&(v202_2));
    let v202_4: Space = if has_head(&(v202_3)) { singleton(&[]) } else { Space::new() };
    drop(v202_3);
    let v202_5: Space = subtract(&(*CONSTANT_1),&(v202_4));
    drop(v202_4);
    let v202_8: Space = if (v202_5).is_empty() { Space::new() } else {
      let v203_6: Path = concat_path(&(*p0),&(v201_13_head));
      let mut v203_7 = Space::new();
      let mut v203_7_cursor = (v201_13_tail).read_zipper();
      for v203_7_byte in v203_7_cursor.child_mask().iter() {
        v203_7_cursor.descend_to_byte(v203_7_byte);
        let v203_7_tail = v203_7_cursor.make_map();
        v203_7_cursor.ascend(1);
        let v203_7_head = Path::from_slice(&[v203_7_byte]);
        let v204_2: Space = singleton(&(v203_7_head));
        let v204_3: Space = intersect(&(*CONSTANT_2),&(v204_2));
        let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
        drop(v204_3);
        let v204_5: Space = subtract(&(*CONSTANT_1),&(v204_4));
        drop(v204_4);
        let v204_8: Space = if (v204_5).is_empty() { Space::new() } else {
          let v205_6: Path = concat_path(&(v203_6),&(v203_7_head));
          let v205_7: Space = routine_27(c, &(v205_6), &(*p1), &(v203_7_tail), &(*s1));
          compose(&(v204_5),&(v205_7))
        };
        drop(v204_5);
        let v204_9: Space = intersect(&(*CONSTANT_2),&(v204_2));
        drop(v204_2);
        let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
        drop(v204_9);
        let v204_12: Space = if (v204_10).is_empty() { Space::new() } else {
          let v206_6: Path = concat_path(&(v203_6),&(v203_7_head));
          let v206_11: Space = routine_28(c, &(v206_6), &(*p1), &(v203_7_tail), &(*s1));
          drop(v206_6);
          compose(&(v204_10),&(v206_11))
        };
        drop(v204_10);
        let v204_13: Space = unite(&(v204_8),&(v204_12));
        v203_7.join_into((v204_13).clone());
      }
      drop(v203_7_cursor);
      compose(&(v202_5),&(v203_7))
    };
    drop(v202_5);
    let v202_9: Space = intersect(&(*CONSTANT_2),&(v202_2));
    drop(v202_2);
    let v202_10: Space = if has_head(&(v202_9)) { singleton(&[]) } else { Space::new() };
    drop(v202_9);
    let v202_13: Space = if (v202_10).is_empty() { Space::new() } else {
      let v207_11: Space = unwrap(&(v201_9),&(v201_13_head));
      let v207_12: Space = unwrap(&(v207_11),&(*p1));
      drop(v207_11);
      compose(&(v202_10),&(v207_12))
    };
    drop(v202_10);
    let v208_6: Path = concat_path(&(*p0),&(v201_13_head));
    let v202_14: Space = wrap(&(v202_13),&(v208_6));
    drop(v202_13);
    let v202_15: Space = wrap(&(v202_14),&(*p1));
    drop(v202_14);
    let v202_16: Space = unite(&(v202_8),&(v202_15));
    drop(v202_15);
    v201_13.join_into((v202_16).clone());
  }
  drop(v201_13_cursor);
  drop(v201_9);
  (v201_13).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v209_3 = Space::new();
  let mut v209_3_cursor = (*s0).read_zipper();
  for v209_3_byte in v209_3_cursor.child_mask().iter() {
    v209_3_cursor.descend_to_byte(v209_3_byte);
    let v209_3_tail = v209_3_cursor.make_map();
    v209_3_cursor.ascend(1);
    let v209_3_head = Path::from_slice(&[v209_3_byte]);
    let v210_2: Space = Space::new();
    v209_3.join_into((v210_2).clone());
  }
  drop(v209_3_cursor);
  (v209_3).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v211_7 = Space::new();
  let mut v211_7_cursor = (*s0).read_zipper();
  for v211_7_byte in v211_7_cursor.child_mask().iter() {
    v211_7_cursor.descend_to_byte(v211_7_byte);
    let v211_7_tail = v211_7_cursor.make_map();
    v211_7_cursor.ascend(1);
    let v211_7_head = Path::from_slice(&[v211_7_byte]);
    let v212_2: Space = singleton(&(v211_7_head));
    let v212_3: Space = intersect(&(*CONSTANT_2),&(v212_2));
    drop(v212_2);
    let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
    drop(v212_3);
    let v212_7: Space = if (v212_4).is_empty() { Space::new() } else {
      let v213_5: Path = concat_path(&(*p0),&(v211_7_head));
      let mut v213_6 = Space::new();
      let mut v213_6_cursor = (v211_7_tail).read_zipper();
      for v213_6_byte in v213_6_cursor.child_mask().iter() {
        v213_6_cursor.descend_to_byte(v213_6_byte);
        let v213_6_tail = v213_6_cursor.make_map();
        v213_6_cursor.ascend(1);
        let v213_6_head = Path::from_slice(&[v213_6_byte]);
        let v214_2: Space = singleton(&(v213_6_head));
        let v214_3: Space = intersect(&(*CONSTANT_2),&(v214_2));
        let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
        drop(v214_3);
        let v214_5: Space = subtract(&(*CONSTANT_1),&(v214_4));
        drop(v214_4);
        let v214_7: Space = if (v214_5).is_empty() { Space::new() } else {
          let v215_6: Space = routine_6(c, &(v213_6_head), &(v213_5), &(v213_6_tail), &(*s1));
          compose(&(v214_5),&(v215_6))
        };
        drop(v214_5);
        let v214_8: Space = intersect(&(*CONSTANT_2),&(v214_2));
        drop(v214_2);
        let v214_9: Space = if has_head(&(v214_8)) { singleton(&[]) } else { Space::new() };
        drop(v214_8);
        let v214_11: Space = if (v214_9).is_empty() { Space::new() } else {
          let v216_10: Space = routine_7(c, &(v213_6_head), &(v213_5), &(v213_6_tail), &(*s1));
          compose(&(v214_9),&(v216_10))
        };
        drop(v214_9);
        let v214_12: Space = unite(&(v214_7),&(v214_11));
        v213_6.join_into((v214_12).clone());
      }
      drop(v213_6_cursor);
      drop(v213_5);
      compose(&(v212_4),&(v213_6))
    };
    drop(v212_4);
    v211_7.join_into((v212_7).clone());
  }
  drop(v211_7_cursor);
  (v211_7).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v217_13 = Space::new();
  let mut v217_13_cursor = (*s0).read_zipper();
  for v217_13_byte in v217_13_cursor.child_mask().iter() {
    v217_13_cursor.descend_to_byte(v217_13_byte);
    let v217_13_tail = v217_13_cursor.make_map();
    v217_13_cursor.ascend(1);
    let v217_13_head = Path::from_slice(&[v217_13_byte]);
    let v218_2: Space = singleton(&(v217_13_head));
    let v218_3: Space = intersect(&(*CONSTANT_2),&(v218_2));
    let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
    drop(v218_3);
    let v218_5: Space = subtract(&(*CONSTANT_1),&(v218_4));
    drop(v218_4);
    let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
      let v219_6: Path = concat_path(&(*p0),&(v217_13_head));
      let mut v219_7 = Space::new();
      let mut v219_7_cursor = (v217_13_tail).read_zipper();
      for v219_7_byte in v219_7_cursor.child_mask().iter() {
        v219_7_cursor.descend_to_byte(v219_7_byte);
        let v219_7_tail = v219_7_cursor.make_map();
        v219_7_cursor.ascend(1);
        let v219_7_head = Path::from_slice(&[v219_7_byte]);
        let v220_2: Space = singleton(&(v219_7_head));
        let v220_3: Space = intersect(&(*CONSTANT_2),&(v220_2));
        let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
        drop(v220_3);
        let v220_5: Space = subtract(&(*CONSTANT_1),&(v220_4));
        drop(v220_4);
        let v220_8: Space = if (v220_5).is_empty() { Space::new() } else {
          let v221_6: Path = concat_path(&(v219_6),&(v219_7_head));
          let v221_7: Space = routine_29(c, &(v221_6), &(*p1), &(v219_7_tail), &(*s1));
          compose(&(v220_5),&(v221_7))
        };
        drop(v220_5);
        let v220_9: Space = intersect(&(*CONSTANT_2),&(v220_2));
        drop(v220_2);
        let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
        drop(v220_9);
        let v220_12: Space = if (v220_10).is_empty() { Space::new() } else {
          let v222_6: Path = concat_path(&(v219_6),&(v219_7_head));
          let v222_11: Space = routine_30(c, &(v222_6), &(*p1), &(v219_7_tail), &(*s1));
          drop(v222_6);
          compose(&(v220_10),&(v222_11))
        };
        drop(v220_10);
        let v220_13: Space = unite(&(v220_8),&(v220_12));
        v219_7.join_into((v220_13).clone());
      }
      drop(v219_7_cursor);
      compose(&(v218_5),&(v219_7))
    };
    drop(v218_5);
    let v218_9: Space = intersect(&(*CONSTANT_2),&(v218_2));
    drop(v218_2);
    let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
    drop(v218_9);
    let v218_12: Space = if (v218_10).is_empty() { Space::new() } else {
      let v223_6: Path = concat_path(&(*p0),&(v217_13_head));
      let mut v223_11 = Space::new();
      let mut v223_11_cursor = (v217_13_tail).read_zipper();
      for v223_11_byte in v223_11_cursor.child_mask().iter() {
        v223_11_cursor.descend_to_byte(v223_11_byte);
        let v223_11_tail = v223_11_cursor.make_map();
        v223_11_cursor.ascend(1);
        let v223_11_head = Path::from_slice(&[v223_11_byte]);
        let v224_2: Space = singleton(&(v223_11_head));
        let v224_3: Space = intersect(&(*CONSTANT_2),&(v224_2));
        let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
        drop(v224_3);
        let v224_5: Space = subtract(&(*CONSTANT_1),&(v224_4));
        drop(v224_4);
        let v224_8: Space = if (v224_5).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v223_6),&(v223_11_head));
          let v225_7: Space = routine_29(c, &(v225_6), &(*p1), &(v223_11_tail), &(*s1));
          compose(&(v224_5),&(v225_7))
        };
        drop(v224_5);
        let v224_9: Space = intersect(&(*CONSTANT_2),&(v224_2));
        drop(v224_2);
        let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
        drop(v224_9);
        let v224_12: Space = if (v224_10).is_empty() { Space::new() } else {
          let v226_6: Path = concat_path(&(v223_6),&(v223_11_head));
          let v226_11: Space = routine_10(c, &(v226_6), &(*p1), &(v223_11_tail), &(*s1));
          drop(v226_6);
          compose(&(v224_10),&(v226_11))
        };
        drop(v224_10);
        let v224_13: Space = unite(&(v224_8),&(v224_12));
        v223_11.join_into((v224_13).clone());
      }
      drop(v223_11_cursor);
      drop(v223_6);
      compose(&(v218_10),&(v223_11))
    };
    drop(v218_10);
    let v218_13: Space = unite(&(v218_8),&(v218_12));
    v217_13.join_into((v218_13).clone());
  }
  drop(v217_13_cursor);
  (v217_13).clone()
}

fn routine_26(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v227_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v227_9: Space = unwrap(&(v227_8),&(*p0));
  drop(v227_8);
  let mut v227_13 = Space::new();
  let mut v227_13_cursor = (*s0).read_zipper();
  for v227_13_byte in v227_13_cursor.child_mask().iter() {
    v227_13_cursor.descend_to_byte(v227_13_byte);
    let v227_13_tail = v227_13_cursor.make_map();
    v227_13_cursor.ascend(1);
    let v227_13_head = Path::from_slice(&[v227_13_byte]);
    let v228_2: Space = singleton(&(v227_13_head));
    let v228_3: Space = intersect(&(*CONSTANT_2),&(v228_2));
    let v228_4: Space = if has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
    drop(v228_3);
    let v228_5: Space = subtract(&(*CONSTANT_1),&(v228_4));
    drop(v228_4);
    let v228_8: Space = if (v228_5).is_empty() { Space::new() } else {
      let v229_6: Path = concat_path(&(*p0),&(v227_13_head));
      let mut v229_7 = Space::new();
      let mut v229_7_cursor = (v227_13_tail).read_zipper();
      for v229_7_byte in v229_7_cursor.child_mask().iter() {
        v229_7_cursor.descend_to_byte(v229_7_byte);
        let v229_7_tail = v229_7_cursor.make_map();
        v229_7_cursor.ascend(1);
        let v229_7_head = Path::from_slice(&[v229_7_byte]);
        let v230_2: Space = singleton(&(v229_7_head));
        let v230_3: Space = intersect(&(*CONSTANT_2),&(v230_2));
        let v230_4: Space = if has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
        drop(v230_3);
        let v230_5: Space = subtract(&(*CONSTANT_1),&(v230_4));
        drop(v230_4);
        let v230_8: Space = if (v230_5).is_empty() { Space::new() } else {
          let v231_6: Path = concat_path(&(v229_6),&(v229_7_head));
          let v231_7: Space = routine_29(c, &(v231_6), &(*p1), &(v229_7_tail), &(*s1));
          compose(&(v230_5),&(v231_7))
        };
        drop(v230_5);
        let v230_9: Space = intersect(&(*CONSTANT_2),&(v230_2));
        drop(v230_2);
        let v230_10: Space = if has_head(&(v230_9)) { singleton(&[]) } else { Space::new() };
        drop(v230_9);
        let v230_12: Space = if (v230_10).is_empty() { Space::new() } else {
          let v232_6: Path = concat_path(&(v229_6),&(v229_7_head));
          let v232_11: Space = routine_30(c, &(v232_6), &(*p1), &(v229_7_tail), &(*s1));
          drop(v232_6);
          compose(&(v230_10),&(v232_11))
        };
        drop(v230_10);
        let v230_13: Space = unite(&(v230_8),&(v230_12));
        v229_7.join_into((v230_13).clone());
      }
      drop(v229_7_cursor);
      compose(&(v228_5),&(v229_7))
    };
    drop(v228_5);
    let v228_9: Space = intersect(&(*CONSTANT_2),&(v228_2));
    drop(v228_2);
    let v228_10: Space = if has_head(&(v228_9)) { singleton(&[]) } else { Space::new() };
    drop(v228_9);
    let v228_13: Space = if (v228_10).is_empty() { Space::new() } else {
      let v233_11: Space = unwrap(&(v227_9),&(v227_13_head));
      let v233_12: Space = unwrap(&(v233_11),&(*p1));
      drop(v233_11);
      compose(&(v228_10),&(v233_12))
    };
    drop(v228_10);
    let v234_6: Path = concat_path(&(*p0),&(v227_13_head));
    let v228_14: Space = wrap(&(v228_13),&(v234_6));
    drop(v228_13);
    let v228_15: Space = wrap(&(v228_14),&(*p1));
    drop(v228_14);
    let v228_16: Space = unite(&(v228_8),&(v228_15));
    drop(v228_15);
    v227_13.join_into((v228_16).clone());
  }
  drop(v227_13_cursor);
  drop(v227_9);
  (v227_13).clone()
}

fn routine_27(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v235_13 = Space::new();
  let mut v235_13_cursor = (*s0).read_zipper();
  for v235_13_byte in v235_13_cursor.child_mask().iter() {
    v235_13_cursor.descend_to_byte(v235_13_byte);
    let v235_13_tail = v235_13_cursor.make_map();
    v235_13_cursor.ascend(1);
    let v235_13_head = Path::from_slice(&[v235_13_byte]);
    let v236_2: Space = singleton(&(v235_13_head));
    let v236_3: Space = intersect(&(*CONSTANT_2),&(v236_2));
    let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
    drop(v236_3);
    let v236_5: Space = subtract(&(*CONSTANT_1),&(v236_4));
    drop(v236_4);
    let v236_8: Space = if (v236_5).is_empty() { Space::new() } else {
      let v237_6: Path = concat_path(&(*p0),&(v235_13_head));
      let mut v237_7 = Space::new();
      let mut v237_7_cursor = (v235_13_tail).read_zipper();
      for v237_7_byte in v237_7_cursor.child_mask().iter() {
        v237_7_cursor.descend_to_byte(v237_7_byte);
        let v237_7_tail = v237_7_cursor.make_map();
        v237_7_cursor.ascend(1);
        let v237_7_head = Path::from_slice(&[v237_7_byte]);
        let v238_2: Space = singleton(&(v237_7_head));
        let v238_3: Space = intersect(&(*CONSTANT_2),&(v238_2));
        let v238_4: Space = if has_head(&(v238_3)) { singleton(&[]) } else { Space::new() };
        drop(v238_3);
        let v238_5: Space = subtract(&(*CONSTANT_1),&(v238_4));
        drop(v238_4);
        let v238_8: Space = if (v238_5).is_empty() { Space::new() } else {
          let v239_6: Path = concat_path(&(v237_6),&(v237_7_head));
          let v239_7: Space = routine_31(c, &(v239_6), &(*p1), &(v237_7_tail), &(*s1));
          compose(&(v238_5),&(v239_7))
        };
        drop(v238_5);
        let v238_9: Space = intersect(&(*CONSTANT_2),&(v238_2));
        drop(v238_2);
        let v238_10: Space = if has_head(&(v238_9)) { singleton(&[]) } else { Space::new() };
        drop(v238_9);
        let v238_12: Space = if (v238_10).is_empty() { Space::new() } else {
          let v240_6: Path = concat_path(&(v237_6),&(v237_7_head));
          let v240_11: Space = routine_32(c, &(v240_6), &(*p1), &(v237_7_tail), &(*s1));
          drop(v240_6);
          compose(&(v238_10),&(v240_11))
        };
        drop(v238_10);
        let v238_13: Space = unite(&(v238_8),&(v238_12));
        v237_7.join_into((v238_13).clone());
      }
      drop(v237_7_cursor);
      compose(&(v236_5),&(v237_7))
    };
    drop(v236_5);
    let v236_9: Space = intersect(&(*CONSTANT_2),&(v236_2));
    drop(v236_2);
    let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
    drop(v236_9);
    let v236_12: Space = if (v236_10).is_empty() { Space::new() } else {
      let v241_6: Path = concat_path(&(*p0),&(v235_13_head));
      let mut v241_11 = Space::new();
      let mut v241_11_cursor = (v235_13_tail).read_zipper();
      for v241_11_byte in v241_11_cursor.child_mask().iter() {
        v241_11_cursor.descend_to_byte(v241_11_byte);
        let v241_11_tail = v241_11_cursor.make_map();
        v241_11_cursor.ascend(1);
        let v241_11_head = Path::from_slice(&[v241_11_byte]);
        let v242_2: Space = singleton(&(v241_11_head));
        let v242_3: Space = intersect(&(*CONSTANT_2),&(v242_2));
        let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = subtract(&(*CONSTANT_1),&(v242_4));
        drop(v242_4);
        let v242_8: Space = if (v242_5).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v241_6),&(v241_11_head));
          let v243_7: Space = routine_31(c, &(v243_6), &(*p1), &(v241_11_tail), &(*s1));
          compose(&(v242_5),&(v243_7))
        };
        drop(v242_5);
        let v242_9: Space = intersect(&(*CONSTANT_2),&(v242_2));
        drop(v242_2);
        let v242_10: Space = if has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
        drop(v242_9);
        let v242_12: Space = if (v242_10).is_empty() { Space::new() } else {
          let v244_6: Path = concat_path(&(v241_6),&(v241_11_head));
          let v244_11: Space = routine_10(c, &(v244_6), &(*p1), &(v241_11_tail), &(*s1));
          drop(v244_6);
          compose(&(v242_10),&(v244_11))
        };
        drop(v242_10);
        let v242_13: Space = unite(&(v242_8),&(v242_12));
        v241_11.join_into((v242_13).clone());
      }
      drop(v241_11_cursor);
      drop(v241_6);
      compose(&(v236_10),&(v241_11))
    };
    drop(v236_10);
    let v236_13: Space = unite(&(v236_8),&(v236_12));
    v235_13.join_into((v236_13).clone());
  }
  drop(v235_13_cursor);
  (v235_13).clone()
}

fn routine_28(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v245_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v245_9: Space = unwrap(&(v245_8),&(*p0));
  drop(v245_8);
  let mut v245_13 = Space::new();
  let mut v245_13_cursor = (*s0).read_zipper();
  for v245_13_byte in v245_13_cursor.child_mask().iter() {
    v245_13_cursor.descend_to_byte(v245_13_byte);
    let v245_13_tail = v245_13_cursor.make_map();
    v245_13_cursor.ascend(1);
    let v245_13_head = Path::from_slice(&[v245_13_byte]);
    let v246_2: Space = singleton(&(v245_13_head));
    let v246_3: Space = intersect(&(*CONSTANT_2),&(v246_2));
    let v246_4: Space = if has_head(&(v246_3)) { singleton(&[]) } else { Space::new() };
    drop(v246_3);
    let v246_5: Space = subtract(&(*CONSTANT_1),&(v246_4));
    drop(v246_4);
    let v246_8: Space = if (v246_5).is_empty() { Space::new() } else {
      let v247_6: Path = concat_path(&(*p0),&(v245_13_head));
      let mut v247_7 = Space::new();
      let mut v247_7_cursor = (v245_13_tail).read_zipper();
      for v247_7_byte in v247_7_cursor.child_mask().iter() {
        v247_7_cursor.descend_to_byte(v247_7_byte);
        let v247_7_tail = v247_7_cursor.make_map();
        v247_7_cursor.ascend(1);
        let v247_7_head = Path::from_slice(&[v247_7_byte]);
        let v248_2: Space = singleton(&(v247_7_head));
        let v248_3: Space = intersect(&(*CONSTANT_2),&(v248_2));
        let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
        drop(v248_3);
        let v248_5: Space = subtract(&(*CONSTANT_1),&(v248_4));
        drop(v248_4);
        let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
          let v249_6: Path = concat_path(&(v247_6),&(v247_7_head));
          let v249_7: Space = routine_31(c, &(v249_6), &(*p1), &(v247_7_tail), &(*s1));
          compose(&(v248_5),&(v249_7))
        };
        drop(v248_5);
        let v248_9: Space = intersect(&(*CONSTANT_2),&(v248_2));
        drop(v248_2);
        let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
        drop(v248_9);
        let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
          let v250_6: Path = concat_path(&(v247_6),&(v247_7_head));
          let v250_11: Space = routine_32(c, &(v250_6), &(*p1), &(v247_7_tail), &(*s1));
          drop(v250_6);
          compose(&(v248_10),&(v250_11))
        };
        drop(v248_10);
        let v248_13: Space = unite(&(v248_8),&(v248_12));
        v247_7.join_into((v248_13).clone());
      }
      drop(v247_7_cursor);
      compose(&(v246_5),&(v247_7))
    };
    drop(v246_5);
    let v246_9: Space = intersect(&(*CONSTANT_2),&(v246_2));
    drop(v246_2);
    let v246_10: Space = if has_head(&(v246_9)) { singleton(&[]) } else { Space::new() };
    drop(v246_9);
    let v246_13: Space = if (v246_10).is_empty() { Space::new() } else {
      let v251_11: Space = unwrap(&(v245_9),&(v245_13_head));
      let v251_12: Space = unwrap(&(v251_11),&(*p1));
      drop(v251_11);
      compose(&(v246_10),&(v251_12))
    };
    drop(v246_10);
    let v252_6: Path = concat_path(&(*p0),&(v245_13_head));
    let v246_14: Space = wrap(&(v246_13),&(v252_6));
    drop(v246_13);
    let v246_15: Space = wrap(&(v246_14),&(*p1));
    drop(v246_14);
    let v246_16: Space = unite(&(v246_8),&(v246_15));
    drop(v246_15);
    v245_13.join_into((v246_16).clone());
  }
  drop(v245_13_cursor);
  drop(v245_9);
  (v245_13).clone()
}

fn routine_29(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v253_8 = Space::new();
  let mut v253_8_cursor = (*s0).read_zipper();
  for v253_8_byte in v253_8_cursor.child_mask().iter() {
    v253_8_cursor.descend_to_byte(v253_8_byte);
    let v253_8_tail = v253_8_cursor.make_map();
    v253_8_cursor.ascend(1);
    let v253_8_head = Path::from_slice(&[v253_8_byte]);
    let v254_2: Space = singleton(&(v253_8_head));
    let v254_3: Space = intersect(&(*CONSTANT_2),&(v254_2));
    let v254_4: Space = if has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
    drop(v254_3);
    let v254_5: Space = subtract(&(*CONSTANT_1),&(v254_4));
    drop(v254_4);
    let mut v254_6 = Space::new();
    let mut v254_6_cursor = (v253_8_tail).read_zipper();
    for v254_6_byte in v254_6_cursor.child_mask().iter() {
      v254_6_cursor.descend_to_byte(v254_6_byte);
      let v254_6_tail = v254_6_cursor.make_map();
      v254_6_cursor.ascend(1);
      let v254_6_head = Path::from_slice(&[v254_6_byte]);
      let v255_2: Space = Space::new();
      v254_6.join_into((v255_2).clone());
    }
    drop(v254_6_cursor);
    let v254_7: Space = compose(&(v254_5),&(v254_6));
    drop(v254_5);
    drop(v254_6);
    let v254_8: Space = intersect(&(*CONSTANT_2),&(v254_2));
    drop(v254_2);
    let v254_9: Space = if has_head(&(v254_8)) { singleton(&[]) } else { Space::new() };
    drop(v254_8);
    let v254_12: Space = if (v254_9).is_empty() { Space::new() } else {
      let v256_10: Path = concat_path(&(*p0),&(v253_8_head));
      let mut v256_11 = Space::new();
      let mut v256_11_cursor = (v253_8_tail).read_zipper();
      for v256_11_byte in v256_11_cursor.child_mask().iter() {
        v256_11_cursor.descend_to_byte(v256_11_byte);
        let v256_11_tail = v256_11_cursor.make_map();
        v256_11_cursor.ascend(1);
        let v256_11_head = Path::from_slice(&[v256_11_byte]);
        let v257_2: Space = singleton(&(v256_11_head));
        let v257_3: Space = intersect(&(*CONSTANT_2),&(v257_2));
        drop(v257_2);
        let v257_4: Space = if has_head(&(v257_3)) { singleton(&[]) } else { Space::new() };
        drop(v257_3);
        let v257_7: Space = if (v257_4).is_empty() { Space::new() } else {
          let v258_5: Path = concat_path(&(v256_10),&(v256_11_head));
          let v258_6: Space = routine_10(c, &(v258_5), &(*p1), &(v256_11_tail), &(*s1));
          drop(v258_5);
          compose(&(v257_4),&(v258_6))
        };
        drop(v257_4);
        v256_11.join_into((v257_7).clone());
      }
      drop(v256_11_cursor);
      drop(v256_10);
      compose(&(v254_9),&(v256_11))
    };
    drop(v254_9);
    let v254_13: Space = unite(&(v254_7),&(v254_12));
    drop(v254_7);
    v253_8.join_into((v254_13).clone());
  }
  drop(v253_8_cursor);
  (v253_8).clone()
}

fn routine_30(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v259_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v259_9: Space = unwrap(&(v259_8),&(*p0));
  drop(v259_8);
  let mut v259_10 = Space::new();
  let mut v259_10_cursor = (*s0).read_zipper();
  for v259_10_byte in v259_10_cursor.child_mask().iter() {
    v259_10_cursor.descend_to_byte(v259_10_byte);
    let v259_10_tail = v259_10_cursor.make_map();
    v259_10_cursor.ascend(1);
    let v259_10_head = Path::from_slice(&[v259_10_byte]);
    let v260_2: Space = singleton(&(v259_10_head));
    let v260_3: Space = intersect(&(*CONSTANT_2),&(v260_2));
    let v260_4: Space = if has_head(&(v260_3)) { singleton(&[]) } else { Space::new() };
    drop(v260_3);
    let v260_5: Space = subtract(&(*CONSTANT_1),&(v260_4));
    drop(v260_4);
    let mut v260_6 = Space::new();
    let mut v260_6_cursor = (v259_10_tail).read_zipper();
    for v260_6_byte in v260_6_cursor.child_mask().iter() {
      v260_6_cursor.descend_to_byte(v260_6_byte);
      let v260_6_tail = v260_6_cursor.make_map();
      v260_6_cursor.ascend(1);
      let v260_6_head = Path::from_slice(&[v260_6_byte]);
      let v261_2: Space = Space::new();
      v260_6.join_into((v261_2).clone());
    }
    drop(v260_6_cursor);
    let v260_7: Space = compose(&(v260_5),&(v260_6));
    drop(v260_5);
    drop(v260_6);
    let v260_8: Space = intersect(&(*CONSTANT_2),&(v260_2));
    drop(v260_2);
    let v260_9: Space = if has_head(&(v260_8)) { singleton(&[]) } else { Space::new() };
    drop(v260_8);
    let v260_12: Space = if (v260_9).is_empty() { Space::new() } else {
      let v262_10: Space = unwrap(&(v259_9),&(v259_10_head));
      let v262_11: Space = unwrap(&(v262_10),&(*p1));
      drop(v262_10);
      compose(&(v260_9),&(v262_11))
    };
    drop(v260_9);
    let v260_13: Path = concat_path(&(*p0),&(v259_10_head));
    let v260_14: Space = wrap(&(v260_12),&(v260_13));
    drop(v260_12);
    drop(v260_13);
    let v260_15: Space = wrap(&(v260_14),&(*p1));
    drop(v260_14);
    let v260_16: Space = unite(&(v260_7),&(v260_15));
    drop(v260_7);
    drop(v260_15);
    v259_10.join_into((v260_16).clone());
  }
  drop(v259_10_cursor);
  drop(v259_9);
  (v259_10).clone()
}

fn routine_31(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v263_4 = Space::new();
  let mut v263_4_cursor = (*s0).read_zipper();
  for v263_4_byte in v263_4_cursor.child_mask().iter() {
    v263_4_cursor.descend_to_byte(v263_4_byte);
    let v263_4_tail = v263_4_cursor.make_map();
    v263_4_cursor.ascend(1);
    let v263_4_head = Path::from_slice(&[v263_4_byte]);
    let v264_2: Space = Space::new();
    v263_4.join_into((v264_2).clone());
  }
  drop(v263_4_cursor);
  (v263_4).clone()
}

fn routine_32(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v265_6: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v265_7: Space = unwrap(&(v265_6),&(*p0));
  drop(v265_6);
  let mut v265_8 = Space::new();
  let mut v265_8_cursor = (*s0).read_zipper();
  for v265_8_byte in v265_8_cursor.child_mask().iter() {
    v265_8_cursor.descend_to_byte(v265_8_byte);
    let v265_8_tail = v265_8_cursor.make_map();
    v265_8_cursor.ascend(1);
    let v265_8_head = Path::from_slice(&[v265_8_byte]);
    let v266_2: Space = singleton(&(v265_8_head));
    let v266_3: Space = intersect(&(*CONSTANT_2),&(v266_2));
    drop(v266_2);
    let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
    drop(v266_3);
    let v266_7: Space = if (v266_4).is_empty() { Space::new() } else {
      let v267_5: Space = unwrap(&(v265_7),&(v265_8_head));
      let v267_6: Space = unwrap(&(v267_5),&(*p1));
      drop(v267_5);
      compose(&(v266_4),&(v267_6))
    };
    drop(v266_4);
    let v266_8: Path = concat_path(&(*p0),&(v265_8_head));
    let v266_9: Space = wrap(&(v266_7),&(v266_8));
    drop(v266_7);
    drop(v266_8);
    v265_8.join_into((v266_9).clone());
  }
  drop(v265_8_cursor);
  drop(v265_7);
  let v265_9: Space = wrap(&(v265_8),&(*p1));
  drop(v265_8);
  (v265_9).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
