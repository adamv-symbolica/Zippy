#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,1,0,0,0,0,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let mut v0_12 = Space::new();
  let mut v0_12_cursor = (v0_2).read_zipper();
  for v0_12_byte in v0_12_cursor.child_mask().iter() {
    v0_12_cursor.descend_to_byte(v0_12_byte);
    let v0_12_tail = v0_12_cursor.make_map();
    v0_12_cursor.ascend(1);
    let v0_12_head = Path::from_slice(&[v0_12_byte]);
    let v1_2: Space = singleton(&(v0_12_head));
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_12_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        let v2_6_tail = v2_6_cursor.make_map();
        v2_6_cursor.ascend(1);
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_12_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail), &(*s0.expect("unbound native input")));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_12_head),&(v2_6_head));
          let v5_11: Space = routine_2(c, &(v5_6), &(v2_6_tail), &(*s0.expect("unbound native input")));
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_cursor = (v0_12_tail).read_zipper();
      for v6_10_byte in v6_10_cursor.child_mask().iter() {
        v6_10_cursor.descend_to_byte(v6_10_byte);
        let v6_10_tail = v6_10_cursor.make_map();
        v6_10_cursor.ascend(1);
        let v6_10_head = Path::from_slice(&[v6_10_byte]);
        let v7_2: Space = singleton(&(v6_10_head));
        let v7_3: Space = intersect(&(*CONSTANT_2),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_1),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_12_head),&(v6_10_head));
          let v8_7: Space = routine_1(c, &(v8_6), &(v6_10_tail), &(*s0.expect("unbound native input")));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_2),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v0_12_head),&(v6_10_head));
          let v9_11: Space = routine_3(c, &(v9_6), &(v6_10_tail), &(*s0.expect("unbound native input")));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_10.join_into((v7_13).clone());
      }
      drop(v6_10_cursor);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_12.join_into((v1_12).clone());
  }
  drop(v0_12_cursor);
  drop(v0_2);
  let v0_14: Space = wrap(&(v0_12),&(*CONSTANT_3));
  (v0_14).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v10_12 = Space::new();
  let mut v10_12_cursor = (*s0).read_zipper();
  for v10_12_byte in v10_12_cursor.child_mask().iter() {
    v10_12_cursor.descend_to_byte(v10_12_byte);
    let v10_12_tail = v10_12_cursor.make_map();
    v10_12_cursor.ascend(1);
    let v10_12_head = Path::from_slice(&[v10_12_byte]);
    let v11_2: Space = singleton(&(v10_12_head));
    let v11_3: Space = intersect(&(*CONSTANT_2),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_1),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&(v10_12_head));
      let mut v12_7 = Space::new();
      let mut v12_7_cursor = (v10_12_tail).read_zipper();
      for v12_7_byte in v12_7_cursor.child_mask().iter() {
        v12_7_cursor.descend_to_byte(v12_7_byte);
        let v12_7_tail = v12_7_cursor.make_map();
        v12_7_cursor.ascend(1);
        let v12_7_head = Path::from_slice(&[v12_7_byte]);
        let v13_2: Space = singleton(&(v12_7_head));
        let v13_3: Space = intersect(&(*CONSTANT_2),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_1),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let v14_7: Space = routine_4(c, &(v14_6), &(v12_7_tail), &(*s1));
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_2),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
          let v15_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let v15_11: Space = routine_5(c, &(v15_6), &(v12_7_tail), &(*s1));
          drop(v15_6);
          compose(&(v13_10),&(v15_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        v12_7.join_into((v13_13).clone());
      }
      drop(v12_7_cursor);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_2),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_12: Space = if (v11_10).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v10_12_head));
      let mut v16_11 = Space::new();
      let mut v16_11_cursor = (v10_12_tail).read_zipper();
      for v16_11_byte in v16_11_cursor.child_mask().iter() {
        v16_11_cursor.descend_to_byte(v16_11_byte);
        let v16_11_tail = v16_11_cursor.make_map();
        v16_11_cursor.ascend(1);
        let v16_11_head = Path::from_slice(&[v16_11_byte]);
        let v17_2: Space = singleton(&(v16_11_head));
        let v17_3: Space = intersect(&(*CONSTANT_2),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_1),&(v17_4));
        drop(v17_4);
        let v17_8: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v16_6),&(v16_11_head));
          let v18_7: Space = routine_4(c, &(v18_6), &(v16_11_tail), &(*s1));
          compose(&(v17_5),&(v18_7))
        };
        drop(v17_5);
        let v17_9: Space = intersect(&(*CONSTANT_2),&(v17_2));
        drop(v17_2);
        let v17_10: Space = if has_head(&(v17_9)) { singleton(&[]) } else { Space::new() };
        drop(v17_9);
        let v17_12: Space = if (v17_10).is_empty() { Space::new() } else {
          let v19_6: Path = concat_path(&(v16_6),&(v16_11_head));
          let v19_11: Space = routine_3(c, &(v19_6), &(v16_11_tail), &(*s1));
          drop(v19_6);
          compose(&(v17_10),&(v19_11))
        };
        drop(v17_10);
        let v17_13: Space = unite(&(v17_8),&(v17_12));
        v16_11.join_into((v17_13).clone());
      }
      drop(v16_11_cursor);
      drop(v16_6);
      compose(&(v11_10),&(v16_11))
    };
    drop(v11_10);
    let v11_13: Space = unite(&(v11_8),&(v11_12));
    v10_12.join_into((v11_13).clone());
  }
  drop(v10_12_cursor);
  (v10_12).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v20_12 = Space::new();
  let mut v20_12_cursor = (*s0).read_zipper();
  for v20_12_byte in v20_12_cursor.child_mask().iter() {
    v20_12_cursor.descend_to_byte(v20_12_byte);
    let v20_12_tail = v20_12_cursor.make_map();
    v20_12_cursor.ascend(1);
    let v20_12_head = Path::from_slice(&[v20_12_byte]);
    let v21_2: Space = singleton(&(v20_12_head));
    let v21_3: Space = intersect(&(*CONSTANT_2),&(v21_2));
    let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
    drop(v21_3);
    let v21_5: Space = subtract(&(*CONSTANT_1),&(v21_4));
    drop(v21_4);
    let v21_8: Space = if (v21_5).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&(v20_12_head));
      let mut v22_7 = Space::new();
      let mut v22_7_cursor = (v20_12_tail).read_zipper();
      for v22_7_byte in v22_7_cursor.child_mask().iter() {
        v22_7_cursor.descend_to_byte(v22_7_byte);
        let v22_7_tail = v22_7_cursor.make_map();
        v22_7_cursor.ascend(1);
        let v22_7_head = Path::from_slice(&[v22_7_byte]);
        let v23_2: Space = singleton(&(v22_7_head));
        let v23_3: Space = intersect(&(*CONSTANT_2),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_1),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&(v22_7_head));
          let v24_7: Space = routine_4(c, &(v24_6), &(v22_7_tail), &(*s1));
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_2),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_12: Space = if (v23_10).is_empty() { Space::new() } else {
          let v25_6: Path = concat_path(&(v22_6),&(v22_7_head));
          let v25_11: Space = routine_5(c, &(v25_6), &(v22_7_tail), &(*s1));
          drop(v25_6);
          compose(&(v23_10),&(v25_11))
        };
        drop(v23_10);
        let v23_13: Space = unite(&(v23_8),&(v23_12));
        v22_7.join_into((v23_13).clone());
      }
      drop(v22_7_cursor);
      compose(&(v21_5),&(v22_7))
    };
    drop(v21_5);
    let v21_9: Space = intersect(&(*CONSTANT_2),&(v21_2));
    drop(v21_2);
    let v21_10: Space = if has_head(&(v21_9)) { singleton(&[]) } else { Space::new() };
    drop(v21_9);
    let v21_12: Space = if (v21_10).is_empty() { Space::new() } else {
      let v26_6: Path = concat_path(&(*p0),&(v20_12_head));
      let mut v26_11 = Space::new();
      let mut v26_11_cursor = (v20_12_tail).read_zipper();
      for v26_11_byte in v26_11_cursor.child_mask().iter() {
        v26_11_cursor.descend_to_byte(v26_11_byte);
        let v26_11_tail = v26_11_cursor.make_map();
        v26_11_cursor.ascend(1);
        let v26_11_head = Path::from_slice(&[v26_11_byte]);
        let v27_2: Space = singleton(&(v26_11_head));
        let v27_3: Space = intersect(&(*CONSTANT_2),&(v27_2));
        let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
        drop(v27_3);
        let v27_5: Space = subtract(&(*CONSTANT_1),&(v27_4));
        drop(v27_4);
        let v27_7: Space = if (v27_5).is_empty() { Space::new() } else {
          let v28_6: Space = routine_6(c, &(v26_11_head), &(v26_6), &(v26_11_tail), &(*s1));
          compose(&(v27_5),&(v28_6))
        };
        drop(v27_5);
        let v27_8: Space = intersect(&(*CONSTANT_2),&(v27_2));
        drop(v27_2);
        let v27_9: Space = if has_head(&(v27_8)) { singleton(&[]) } else { Space::new() };
        drop(v27_8);
        let v27_11: Space = if (v27_9).is_empty() { Space::new() } else {
          let v29_10: Space = routine_7(c, &(v26_11_head), &(v26_6), &(v26_11_tail), &(*s1));
          compose(&(v27_9),&(v29_10))
        };
        drop(v27_9);
        let v27_12: Space = unite(&(v27_7),&(v27_11));
        v26_11.join_into((v27_12).clone());
      }
      drop(v26_11_cursor);
      drop(v26_6);
      compose(&(v21_10),&(v26_11))
    };
    drop(v21_10);
    let v21_13: Space = unite(&(v21_8),&(v21_12));
    v20_12.join_into((v21_13).clone());
  }
  drop(v20_12_cursor);
  (v20_12).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v30_12 = Space::new();
  let mut v30_12_cursor = (*s0).read_zipper();
  for v30_12_byte in v30_12_cursor.child_mask().iter() {
    v30_12_cursor.descend_to_byte(v30_12_byte);
    let v30_12_tail = v30_12_cursor.make_map();
    v30_12_cursor.ascend(1);
    let v30_12_head = Path::from_slice(&[v30_12_byte]);
    let v31_2: Space = singleton(&(v30_12_head));
    let v31_3: Space = intersect(&(*CONSTANT_2),&(v31_2));
    let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
    drop(v31_3);
    let v31_5: Space = subtract(&(*CONSTANT_1),&(v31_4));
    drop(v31_4);
    let v31_7: Space = if (v31_5).is_empty() { Space::new() } else {
      let mut v32_6 = Space::new();
      let mut v32_6_cursor = (v30_12_tail).read_zipper();
      for v32_6_byte in v32_6_cursor.child_mask().iter() {
        v32_6_cursor.descend_to_byte(v32_6_byte);
        let v32_6_tail = v32_6_cursor.make_map();
        v32_6_cursor.ascend(1);
        let v32_6_head = Path::from_slice(&[v32_6_byte]);
        let v33_2: Space = singleton(&(v32_6_head));
        let v33_3: Space = intersect(&(*CONSTANT_2),&(v33_2));
        let v33_4: Space = if has_head(&(v33_3)) { singleton(&[]) } else { Space::new() };
        drop(v33_3);
        let v33_5: Space = subtract(&(*CONSTANT_1),&(v33_4));
        drop(v33_4);
        let v33_8: Space = if (v33_5).is_empty() { Space::new() } else {
          let v34_6: Path = concat_path(&(v30_12_head),&(v32_6_head));
          let v34_7: Space = routine_8(c, &(v34_6), &(*p0), &(v32_6_tail), &(*s1));
          compose(&(v33_5),&(v34_7))
        };
        drop(v33_5);
        let v33_9: Space = intersect(&(*CONSTANT_2),&(v33_2));
        drop(v33_2);
        let v33_10: Space = if has_head(&(v33_9)) { singleton(&[]) } else { Space::new() };
        drop(v33_9);
        let v33_12: Space = if (v33_10).is_empty() { Space::new() } else {
          let v35_6: Path = concat_path(&(v30_12_head),&(v32_6_head));
          let v35_11: Space = routine_9(c, &(v35_6), &(*p0), &(v32_6_tail), &(*s1));
          drop(v35_6);
          compose(&(v33_10),&(v35_11))
        };
        drop(v33_10);
        let v33_13: Space = unite(&(v33_8),&(v33_12));
        v32_6.join_into((v33_13).clone());
      }
      drop(v32_6_cursor);
      compose(&(v31_5),&(v32_6))
    };
    drop(v31_5);
    let v31_8: Space = intersect(&(*CONSTANT_2),&(v31_2));
    drop(v31_2);
    let v31_9: Space = if has_head(&(v31_8)) { singleton(&[]) } else { Space::new() };
    drop(v31_8);
    let v31_11: Space = if (v31_9).is_empty() { Space::new() } else {
      let mut v36_10 = Space::new();
      let mut v36_10_cursor = (v30_12_tail).read_zipper();
      for v36_10_byte in v36_10_cursor.child_mask().iter() {
        v36_10_cursor.descend_to_byte(v36_10_byte);
        let v36_10_tail = v36_10_cursor.make_map();
        v36_10_cursor.ascend(1);
        let v36_10_head = Path::from_slice(&[v36_10_byte]);
        let v37_2: Space = singleton(&(v36_10_head));
        let v37_3: Space = intersect(&(*CONSTANT_2),&(v37_2));
        let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
        drop(v37_3);
        let v37_5: Space = subtract(&(*CONSTANT_1),&(v37_4));
        drop(v37_4);
        let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
          let v38_6: Path = concat_path(&(v30_12_head),&(v36_10_head));
          let v38_7: Space = routine_8(c, &(v38_6), &(*p0), &(v36_10_tail), &(*s1));
          compose(&(v37_5),&(v38_7))
        };
        drop(v37_5);
        let v37_9: Space = intersect(&(*CONSTANT_2),&(v37_2));
        drop(v37_2);
        let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
        drop(v37_9);
        let v37_12: Space = if (v37_10).is_empty() { Space::new() } else {
          let v39_6: Path = concat_path(&(v30_12_head),&(v36_10_head));
          let v39_11: Space = routine_10(c, &(v39_6), &(*p0), &(v36_10_tail), &(*s1));
          drop(v39_6);
          compose(&(v37_10),&(v39_11))
        };
        drop(v37_10);
        let v37_13: Space = unite(&(v37_8),&(v37_12));
        v36_10.join_into((v37_13).clone());
      }
      drop(v36_10_cursor);
      compose(&(v31_9),&(v36_10))
    };
    drop(v31_9);
    let v31_12: Space = unite(&(v31_7),&(v31_11));
    v30_12.join_into((v31_12).clone());
  }
  drop(v30_12_cursor);
  (v30_12).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v40_12 = Space::new();
  let mut v40_12_cursor = (*s0).read_zipper();
  for v40_12_byte in v40_12_cursor.child_mask().iter() {
    v40_12_cursor.descend_to_byte(v40_12_byte);
    let v40_12_tail = v40_12_cursor.make_map();
    v40_12_cursor.ascend(1);
    let v40_12_head = Path::from_slice(&[v40_12_byte]);
    let v41_2: Space = singleton(&(v40_12_head));
    let v41_3: Space = intersect(&(*CONSTANT_2),&(v41_2));
    let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
    drop(v41_3);
    let v41_5: Space = subtract(&(*CONSTANT_1),&(v41_4));
    drop(v41_4);
    let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
      let v42_6: Path = concat_path(&(*p0),&(v40_12_head));
      let mut v42_7 = Space::new();
      let mut v42_7_cursor = (v40_12_tail).read_zipper();
      for v42_7_byte in v42_7_cursor.child_mask().iter() {
        v42_7_cursor.descend_to_byte(v42_7_byte);
        let v42_7_tail = v42_7_cursor.make_map();
        v42_7_cursor.ascend(1);
        let v42_7_head = Path::from_slice(&[v42_7_byte]);
        let v43_2: Space = singleton(&(v42_7_head));
        let v43_3: Space = intersect(&(*CONSTANT_2),&(v43_2));
        let v43_4: Space = if has_head(&(v43_3)) { singleton(&[]) } else { Space::new() };
        drop(v43_3);
        let v43_5: Space = subtract(&(*CONSTANT_1),&(v43_4));
        drop(v43_4);
        let v43_8: Space = if (v43_5).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v42_6),&(v42_7_head));
          let v44_7: Space = routine_11(c, &(v44_6), &(v42_7_tail), &(*s1));
          compose(&(v43_5),&(v44_7))
        };
        drop(v43_5);
        let v43_9: Space = intersect(&(*CONSTANT_2),&(v43_2));
        drop(v43_2);
        let v43_10: Space = if has_head(&(v43_9)) { singleton(&[]) } else { Space::new() };
        drop(v43_9);
        let v43_12: Space = if (v43_10).is_empty() { Space::new() } else {
          let v45_6: Path = concat_path(&(v42_6),&(v42_7_head));
          let v45_11: Space = routine_12(c, &(v45_6), &(v42_7_tail), &(*s1));
          drop(v45_6);
          compose(&(v43_10),&(v45_11))
        };
        drop(v43_10);
        let v43_13: Space = unite(&(v43_8),&(v43_12));
        v42_7.join_into((v43_13).clone());
      }
      drop(v42_7_cursor);
      compose(&(v41_5),&(v42_7))
    };
    drop(v41_5);
    let v41_9: Space = intersect(&(*CONSTANT_2),&(v41_2));
    drop(v41_2);
    let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
    drop(v41_9);
    let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&(v40_12_head));
      let mut v46_11 = Space::new();
      let mut v46_11_cursor = (v40_12_tail).read_zipper();
      for v46_11_byte in v46_11_cursor.child_mask().iter() {
        v46_11_cursor.descend_to_byte(v46_11_byte);
        let v46_11_tail = v46_11_cursor.make_map();
        v46_11_cursor.ascend(1);
        let v46_11_head = Path::from_slice(&[v46_11_byte]);
        let v47_2: Space = singleton(&(v46_11_head));
        let v47_3: Space = intersect(&(*CONSTANT_2),&(v47_2));
        let v47_4: Space = if has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = subtract(&(*CONSTANT_1),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (v47_5).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&(v46_11_head));
          let v48_7: Space = routine_11(c, &(v48_6), &(v46_11_tail), &(*s1));
          compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = intersect(&(*CONSTANT_2),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (v47_10).is_empty() { Space::new() } else {
          let v49_6: Path = concat_path(&(v46_6),&(v46_11_head));
          let v49_11: Space = routine_3(c, &(v49_6), &(v46_11_tail), &(*s1));
          drop(v49_6);
          compose(&(v47_10),&(v49_11))
        };
        drop(v47_10);
        let v47_13: Space = unite(&(v47_8),&(v47_12));
        v46_11.join_into((v47_13).clone());
      }
      drop(v46_11_cursor);
      drop(v46_6);
      compose(&(v41_10),&(v46_11))
    };
    drop(v41_10);
    let v41_13: Space = unite(&(v41_8),&(v41_12));
    v40_12.join_into((v41_13).clone());
  }
  drop(v40_12_cursor);
  (v40_12).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v50_12 = Space::new();
  let mut v50_12_cursor = (*s0).read_zipper();
  for v50_12_byte in v50_12_cursor.child_mask().iter() {
    v50_12_cursor.descend_to_byte(v50_12_byte);
    let v50_12_tail = v50_12_cursor.make_map();
    v50_12_cursor.ascend(1);
    let v50_12_head = Path::from_slice(&[v50_12_byte]);
    let v51_2: Space = singleton(&(v50_12_head));
    let v51_3: Space = intersect(&(*CONSTANT_2),&(v51_2));
    let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
    drop(v51_3);
    let v51_5: Space = subtract(&(*CONSTANT_1),&(v51_4));
    drop(v51_4);
    let v51_8: Space = if (v51_5).is_empty() { Space::new() } else {
      let v52_6: Path = concat_path(&(*p0),&(v50_12_head));
      let mut v52_7 = Space::new();
      let mut v52_7_cursor = (v50_12_tail).read_zipper();
      for v52_7_byte in v52_7_cursor.child_mask().iter() {
        v52_7_cursor.descend_to_byte(v52_7_byte);
        let v52_7_tail = v52_7_cursor.make_map();
        v52_7_cursor.ascend(1);
        let v52_7_head = Path::from_slice(&[v52_7_byte]);
        let v53_2: Space = singleton(&(v52_7_head));
        let v53_3: Space = intersect(&(*CONSTANT_2),&(v53_2));
        let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
        drop(v53_3);
        let v53_5: Space = subtract(&(*CONSTANT_1),&(v53_4));
        drop(v53_4);
        let v53_8: Space = if (v53_5).is_empty() { Space::new() } else {
          let v54_6: Path = concat_path(&(v52_6),&(v52_7_head));
          let v54_7: Space = routine_11(c, &(v54_6), &(v52_7_tail), &(*s1));
          compose(&(v53_5),&(v54_7))
        };
        drop(v53_5);
        let v53_9: Space = intersect(&(*CONSTANT_2),&(v53_2));
        drop(v53_2);
        let v53_10: Space = if has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
        drop(v53_9);
        let v53_12: Space = if (v53_10).is_empty() { Space::new() } else {
          let v55_6: Path = concat_path(&(v52_6),&(v52_7_head));
          let v55_11: Space = routine_12(c, &(v55_6), &(v52_7_tail), &(*s1));
          drop(v55_6);
          compose(&(v53_10),&(v55_11))
        };
        drop(v53_10);
        let v53_13: Space = unite(&(v53_8),&(v53_12));
        v52_7.join_into((v53_13).clone());
      }
      drop(v52_7_cursor);
      compose(&(v51_5),&(v52_7))
    };
    drop(v51_5);
    let v51_9: Space = intersect(&(*CONSTANT_2),&(v51_2));
    drop(v51_2);
    let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
    drop(v51_9);
    let v51_12: Space = if (v51_10).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&(v50_12_head));
      let mut v56_11 = Space::new();
      let mut v56_11_cursor = (v50_12_tail).read_zipper();
      for v56_11_byte in v56_11_cursor.child_mask().iter() {
        v56_11_cursor.descend_to_byte(v56_11_byte);
        let v56_11_tail = v56_11_cursor.make_map();
        v56_11_cursor.ascend(1);
        let v56_11_head = Path::from_slice(&[v56_11_byte]);
        let v57_2: Space = singleton(&(v56_11_head));
        let v57_3: Space = intersect(&(*CONSTANT_2),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_1),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (v57_5).is_empty() { Space::new() } else {
          let v58_6: Space = routine_6(c, &(v56_11_head), &(v56_6), &(v56_11_tail), &(*s1));
          compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = intersect(&(*CONSTANT_2),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (v57_9).is_empty() { Space::new() } else {
          let v59_10: Space = routine_7(c, &(v56_11_head), &(v56_6), &(v56_11_tail), &(*s1));
          compose(&(v57_9),&(v59_10))
        };
        drop(v57_9);
        let v57_12: Space = unite(&(v57_7),&(v57_11));
        v56_11.join_into((v57_12).clone());
      }
      drop(v56_11_cursor);
      drop(v56_6);
      compose(&(v51_10),&(v56_11))
    };
    drop(v51_10);
    let v51_13: Space = unite(&(v51_8),&(v51_12));
    v50_12.join_into((v51_13).clone());
  }
  drop(v50_12_cursor);
  (v50_12).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v60_13 = Space::new();
  let mut v60_13_cursor = (*s0).read_zipper();
  for v60_13_byte in v60_13_cursor.child_mask().iter() {
    v60_13_cursor.descend_to_byte(v60_13_byte);
    let v60_13_tail = v60_13_cursor.make_map();
    v60_13_cursor.ascend(1);
    let v60_13_head = Path::from_slice(&[v60_13_byte]);
    let v61_2: Space = singleton(&(v60_13_head));
    let v61_3: Space = intersect(&(*CONSTANT_2),&(v61_2));
    let v61_4: Space = if has_head(&(v61_3)) { singleton(&[]) } else { Space::new() };
    drop(v61_3);
    let v61_5: Space = subtract(&(*CONSTANT_1),&(v61_4));
    drop(v61_4);
    let v61_8: Space = if (v61_5).is_empty() { Space::new() } else {
      let v62_6: Path = concat_path(&(*p0),&(v60_13_head));
      let mut v62_7 = Space::new();
      let mut v62_7_cursor = (v60_13_tail).read_zipper();
      for v62_7_byte in v62_7_cursor.child_mask().iter() {
        v62_7_cursor.descend_to_byte(v62_7_byte);
        let v62_7_tail = v62_7_cursor.make_map();
        v62_7_cursor.ascend(1);
        let v62_7_head = Path::from_slice(&[v62_7_byte]);
        let v63_2: Space = singleton(&(v62_7_head));
        let v63_3: Space = intersect(&(*CONSTANT_2),&(v63_2));
        let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
        drop(v63_3);
        let v63_5: Space = subtract(&(*CONSTANT_1),&(v63_4));
        drop(v63_4);
        let v63_8: Space = if (v63_5).is_empty() { Space::new() } else {
          let v64_6: Path = concat_path(&(v62_6),&(v62_7_head));
          let v64_7: Space = routine_13(c, &(v64_6), &(*p1), &(v62_7_tail), &(*s1));
          compose(&(v63_5),&(v64_7))
        };
        drop(v63_5);
        let v63_9: Space = intersect(&(*CONSTANT_2),&(v63_2));
        drop(v63_2);
        let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
        drop(v63_9);
        let v63_12: Space = if (v63_10).is_empty() { Space::new() } else {
          let v65_6: Path = concat_path(&(v62_6),&(v62_7_head));
          let v65_11: Space = routine_14(c, &(v65_6), &(*p1), &(v62_7_tail), &(*s1));
          drop(v65_6);
          compose(&(v63_10),&(v65_11))
        };
        drop(v63_10);
        let v63_13: Space = unite(&(v63_8),&(v63_12));
        v62_7.join_into((v63_13).clone());
      }
      drop(v62_7_cursor);
      compose(&(v61_5),&(v62_7))
    };
    drop(v61_5);
    let v61_9: Space = intersect(&(*CONSTANT_2),&(v61_2));
    drop(v61_2);
    let v61_10: Space = if has_head(&(v61_9)) { singleton(&[]) } else { Space::new() };
    drop(v61_9);
    let v61_12: Space = if (v61_10).is_empty() { Space::new() } else {
      let v66_6: Path = concat_path(&(*p0),&(v60_13_head));
      let mut v66_11 = Space::new();
      let mut v66_11_cursor = (v60_13_tail).read_zipper();
      for v66_11_byte in v66_11_cursor.child_mask().iter() {
        v66_11_cursor.descend_to_byte(v66_11_byte);
        let v66_11_tail = v66_11_cursor.make_map();
        v66_11_cursor.ascend(1);
        let v66_11_head = Path::from_slice(&[v66_11_byte]);
        let v67_2: Space = singleton(&(v66_11_head));
        let v67_3: Space = intersect(&(*CONSTANT_2),&(v67_2));
        let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
        drop(v67_3);
        let v67_5: Space = subtract(&(*CONSTANT_1),&(v67_4));
        drop(v67_4);
        let v67_8: Space = if (v67_5).is_empty() { Space::new() } else {
          let v68_6: Path = concat_path(&(v66_6),&(v66_11_head));
          let v68_7: Space = routine_13(c, &(v68_6), &(*p1), &(v66_11_tail), &(*s1));
          compose(&(v67_5),&(v68_7))
        };
        drop(v67_5);
        let v67_9: Space = intersect(&(*CONSTANT_2),&(v67_2));
        drop(v67_2);
        let v67_10: Space = if has_head(&(v67_9)) { singleton(&[]) } else { Space::new() };
        drop(v67_9);
        let v67_12: Space = if (v67_10).is_empty() { Space::new() } else {
          let v69_6: Path = concat_path(&(v66_6),&(v66_11_head));
          let v69_11: Space = routine_10(c, &(v69_6), &(*p1), &(v66_11_tail), &(*s1));
          drop(v69_6);
          compose(&(v67_10),&(v69_11))
        };
        drop(v67_10);
        let v67_13: Space = unite(&(v67_8),&(v67_12));
        v66_11.join_into((v67_13).clone());
      }
      drop(v66_11_cursor);
      drop(v66_6);
      compose(&(v61_10),&(v66_11))
    };
    drop(v61_10);
    let v61_13: Space = unite(&(v61_8),&(v61_12));
    v60_13.join_into((v61_13).clone());
  }
  drop(v60_13_cursor);
  (v60_13).clone()
}

fn routine_7(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v70_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v70_9: Space = unwrap(&(v70_8),&(*p0));
  drop(v70_8);
  let mut v70_16 = Space::new();
  let mut v70_16_cursor = (*s0).read_zipper();
  for v70_16_byte in v70_16_cursor.child_mask().iter() {
    v70_16_cursor.descend_to_byte(v70_16_byte);
    let v70_16_tail = v70_16_cursor.make_map();
    v70_16_cursor.ascend(1);
    let v70_16_head = Path::from_slice(&[v70_16_byte]);
    let v71_2: Space = singleton(&(v70_16_head));
    let v71_3: Space = intersect(&(*CONSTANT_2),&(v71_2));
    let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
    drop(v71_3);
    let v71_5: Space = subtract(&(*CONSTANT_1),&(v71_4));
    drop(v71_4);
    let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
      let v72_6: Path = concat_path(&(*p0),&(v70_16_head));
      let mut v72_7 = Space::new();
      let mut v72_7_cursor = (v70_16_tail).read_zipper();
      for v72_7_byte in v72_7_cursor.child_mask().iter() {
        v72_7_cursor.descend_to_byte(v72_7_byte);
        let v72_7_tail = v72_7_cursor.make_map();
        v72_7_cursor.ascend(1);
        let v72_7_head = Path::from_slice(&[v72_7_byte]);
        let v73_2: Space = singleton(&(v72_7_head));
        let v73_3: Space = intersect(&(*CONSTANT_2),&(v73_2));
        let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
        drop(v73_3);
        let v73_5: Space = subtract(&(*CONSTANT_1),&(v73_4));
        drop(v73_4);
        let v73_8: Space = if (v73_5).is_empty() { Space::new() } else {
          let v74_6: Path = concat_path(&(v72_6),&(v72_7_head));
          let v74_7: Space = routine_13(c, &(v74_6), &(*p1), &(v72_7_tail), &(*s1));
          compose(&(v73_5),&(v74_7))
        };
        drop(v73_5);
        let v73_9: Space = intersect(&(*CONSTANT_2),&(v73_2));
        drop(v73_2);
        let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
        drop(v73_9);
        let v73_12: Space = if (v73_10).is_empty() { Space::new() } else {
          let v75_6: Path = concat_path(&(v72_6),&(v72_7_head));
          let v75_11: Space = routine_14(c, &(v75_6), &(*p1), &(v72_7_tail), &(*s1));
          drop(v75_6);
          compose(&(v73_10),&(v75_11))
        };
        drop(v73_10);
        let v73_13: Space = unite(&(v73_8),&(v73_12));
        v72_7.join_into((v73_13).clone());
      }
      drop(v72_7_cursor);
      drop(v72_6);
      compose(&(v71_5),&(v72_7))
    };
    drop(v71_5);
    let v71_9: Space = intersect(&(*CONSTANT_2),&(v71_2));
    drop(v71_2);
    let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
    drop(v71_9);
    let v71_13: Space = if (v71_10).is_empty() { Space::new() } else {
      let v76_11: Space = unwrap(&(v70_9),&(v70_16_head));
      let mut v76_12 = Space::new();
      let mut v76_12_cursor = (v76_11).read_zipper();
      for v76_12_byte in v76_12_cursor.child_mask().iter() {
        v76_12_cursor.descend_to_byte(v76_12_byte);
        let v76_12_tail = v76_12_cursor.make_map();
        v76_12_cursor.ascend(1);
        let v76_12_head = Path::from_slice(&[v76_12_byte]);
        let v77_2: Space = singleton(&(v76_12_head));
        let v77_3: Space = intersect(&(*CONSTANT_2),&(v77_2));
        let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
        drop(v77_3);
        let v77_5: Space = subtract(&(*CONSTANT_1),&(v77_4));
        drop(v77_4);
        let v77_7: Space = if (v77_5).is_empty() { Space::new() } else {
          let v78_6: Space = routine_15(c, &(v76_12_head), &(*p1), &(v76_12_tail));
          compose(&(v77_5),&(v78_6))
        };
        drop(v77_5);
        let v77_8: Space = intersect(&(*CONSTANT_2),&(v77_2));
        drop(v77_2);
        let v77_9: Space = if has_head(&(v77_8)) { singleton(&[]) } else { Space::new() };
        drop(v77_8);
        let v77_11: Space = if (v77_9).is_empty() { Space::new() } else {
          let v79_10: Space = routine_16(c, &(v76_12_head), &(*p1), &(v76_12_tail));
          compose(&(v77_9),&(v79_10))
        };
        drop(v77_9);
        let v77_12: Space = unite(&(v77_7),&(v77_11));
        v76_12.join_into((v77_12).clone());
      }
      drop(v76_12_cursor);
      drop(v76_11);
      compose(&(v71_10),&(v76_12))
    };
    drop(v71_10);
    let v71_14: Space = unite(&(v71_8),&(v71_13));
    v70_16.join_into((v71_14).clone());
  }
  drop(v70_16_cursor);
  drop(v70_9);
  (v70_16).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v80_13 = Space::new();
  let mut v80_13_cursor = (*s0).read_zipper();
  for v80_13_byte in v80_13_cursor.child_mask().iter() {
    v80_13_cursor.descend_to_byte(v80_13_byte);
    let v80_13_tail = v80_13_cursor.make_map();
    v80_13_cursor.ascend(1);
    let v80_13_head = Path::from_slice(&[v80_13_byte]);
    let v81_2: Space = singleton(&(v80_13_head));
    let v81_3: Space = intersect(&(*CONSTANT_2),&(v81_2));
    let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
    drop(v81_3);
    let v81_5: Space = subtract(&(*CONSTANT_1),&(v81_4));
    drop(v81_4);
    let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
      let v82_6: Path = concat_path(&(*p0),&(v80_13_head));
      let mut v82_7 = Space::new();
      let mut v82_7_cursor = (v80_13_tail).read_zipper();
      for v82_7_byte in v82_7_cursor.child_mask().iter() {
        v82_7_cursor.descend_to_byte(v82_7_byte);
        let v82_7_tail = v82_7_cursor.make_map();
        v82_7_cursor.ascend(1);
        let v82_7_head = Path::from_slice(&[v82_7_byte]);
        let v83_2: Space = singleton(&(v82_7_head));
        let v83_3: Space = intersect(&(*CONSTANT_2),&(v83_2));
        let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
        drop(v83_3);
        let v83_5: Space = subtract(&(*CONSTANT_1),&(v83_4));
        drop(v83_4);
        let v83_8: Space = if (v83_5).is_empty() { Space::new() } else {
          let v84_6: Path = concat_path(&(v82_6),&(v82_7_head));
          let v84_7: Space = routine_17(c, &(v84_6), &(*p1), &(v82_7_tail), &(*s1));
          compose(&(v83_5),&(v84_7))
        };
        drop(v83_5);
        let v83_9: Space = intersect(&(*CONSTANT_2),&(v83_2));
        drop(v83_2);
        let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
        drop(v83_9);
        let v83_12: Space = if (v83_10).is_empty() { Space::new() } else {
          let v85_6: Path = concat_path(&(v82_6),&(v82_7_head));
          let v85_11: Space = routine_18(c, &(v85_6), &(*p1), &(v82_7_tail), &(*s1));
          drop(v85_6);
          compose(&(v83_10),&(v85_11))
        };
        drop(v83_10);
        let v83_13: Space = unite(&(v83_8),&(v83_12));
        v82_7.join_into((v83_13).clone());
      }
      drop(v82_7_cursor);
      compose(&(v81_5),&(v82_7))
    };
    drop(v81_5);
    let v81_9: Space = intersect(&(*CONSTANT_2),&(v81_2));
    drop(v81_2);
    let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
    drop(v81_9);
    let v81_12: Space = if (v81_10).is_empty() { Space::new() } else {
      let v86_6: Path = concat_path(&(*p0),&(v80_13_head));
      let mut v86_11 = Space::new();
      let mut v86_11_cursor = (v80_13_tail).read_zipper();
      for v86_11_byte in v86_11_cursor.child_mask().iter() {
        v86_11_cursor.descend_to_byte(v86_11_byte);
        let v86_11_tail = v86_11_cursor.make_map();
        v86_11_cursor.ascend(1);
        let v86_11_head = Path::from_slice(&[v86_11_byte]);
        let v87_2: Space = singleton(&(v86_11_head));
        let v87_3: Space = intersect(&(*CONSTANT_2),&(v87_2));
        let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
        drop(v87_3);
        let v87_5: Space = subtract(&(*CONSTANT_1),&(v87_4));
        drop(v87_4);
        let v87_8: Space = if (v87_5).is_empty() { Space::new() } else {
          let v88_6: Path = concat_path(&(v86_6),&(v86_11_head));
          let v88_7: Space = routine_17(c, &(v88_6), &(*p1), &(v86_11_tail), &(*s1));
          compose(&(v87_5),&(v88_7))
        };
        drop(v87_5);
        let v87_9: Space = intersect(&(*CONSTANT_2),&(v87_2));
        drop(v87_2);
        let v87_10: Space = if has_head(&(v87_9)) { singleton(&[]) } else { Space::new() };
        drop(v87_9);
        let v87_12: Space = if (v87_10).is_empty() { Space::new() } else {
          let v89_6: Path = concat_path(&(v86_6),&(v86_11_head));
          let v89_11: Space = routine_10(c, &(v89_6), &(*p1), &(v86_11_tail), &(*s1));
          drop(v89_6);
          compose(&(v87_10),&(v89_11))
        };
        drop(v87_10);
        let v87_13: Space = unite(&(v87_8),&(v87_12));
        v86_11.join_into((v87_13).clone());
      }
      drop(v86_11_cursor);
      drop(v86_6);
      compose(&(v81_10),&(v86_11))
    };
    drop(v81_10);
    let v81_13: Space = unite(&(v81_8),&(v81_12));
    v80_13.join_into((v81_13).clone());
  }
  drop(v80_13_cursor);
  (v80_13).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v90_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v90_9: Space = unwrap(&(v90_8),&(*p0));
  drop(v90_8);
  let mut v90_16 = Space::new();
  let mut v90_16_cursor = (*s0).read_zipper();
  for v90_16_byte in v90_16_cursor.child_mask().iter() {
    v90_16_cursor.descend_to_byte(v90_16_byte);
    let v90_16_tail = v90_16_cursor.make_map();
    v90_16_cursor.ascend(1);
    let v90_16_head = Path::from_slice(&[v90_16_byte]);
    let v91_2: Space = singleton(&(v90_16_head));
    let v91_3: Space = intersect(&(*CONSTANT_2),&(v91_2));
    let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
    drop(v91_3);
    let v91_5: Space = subtract(&(*CONSTANT_1),&(v91_4));
    drop(v91_4);
    let v91_8: Space = if (v91_5).is_empty() { Space::new() } else {
      let v92_6: Path = concat_path(&(*p0),&(v90_16_head));
      let mut v92_7 = Space::new();
      let mut v92_7_cursor = (v90_16_tail).read_zipper();
      for v92_7_byte in v92_7_cursor.child_mask().iter() {
        v92_7_cursor.descend_to_byte(v92_7_byte);
        let v92_7_tail = v92_7_cursor.make_map();
        v92_7_cursor.ascend(1);
        let v92_7_head = Path::from_slice(&[v92_7_byte]);
        let v93_2: Space = singleton(&(v92_7_head));
        let v93_3: Space = intersect(&(*CONSTANT_2),&(v93_2));
        let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
        drop(v93_3);
        let v93_5: Space = subtract(&(*CONSTANT_1),&(v93_4));
        drop(v93_4);
        let v93_8: Space = if (v93_5).is_empty() { Space::new() } else {
          let v94_6: Path = concat_path(&(v92_6),&(v92_7_head));
          let v94_7: Space = routine_17(c, &(v94_6), &(*p1), &(v92_7_tail), &(*s1));
          compose(&(v93_5),&(v94_7))
        };
        drop(v93_5);
        let v93_9: Space = intersect(&(*CONSTANT_2),&(v93_2));
        drop(v93_2);
        let v93_10: Space = if has_head(&(v93_9)) { singleton(&[]) } else { Space::new() };
        drop(v93_9);
        let v93_12: Space = if (v93_10).is_empty() { Space::new() } else {
          let v95_6: Path = concat_path(&(v92_6),&(v92_7_head));
          let v95_11: Space = routine_18(c, &(v95_6), &(*p1), &(v92_7_tail), &(*s1));
          drop(v95_6);
          compose(&(v93_10),&(v95_11))
        };
        drop(v93_10);
        let v93_13: Space = unite(&(v93_8),&(v93_12));
        v92_7.join_into((v93_13).clone());
      }
      drop(v92_7_cursor);
      drop(v92_6);
      compose(&(v91_5),&(v92_7))
    };
    drop(v91_5);
    let v91_9: Space = intersect(&(*CONSTANT_2),&(v91_2));
    drop(v91_2);
    let v91_10: Space = if has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
    drop(v91_9);
    let v91_13: Space = if (v91_10).is_empty() { Space::new() } else {
      let v96_11: Space = unwrap(&(v90_9),&(v90_16_head));
      let mut v96_12 = Space::new();
      let mut v96_12_cursor = (v96_11).read_zipper();
      for v96_12_byte in v96_12_cursor.child_mask().iter() {
        v96_12_cursor.descend_to_byte(v96_12_byte);
        let v96_12_tail = v96_12_cursor.make_map();
        v96_12_cursor.ascend(1);
        let v96_12_head = Path::from_slice(&[v96_12_byte]);
        let v97_2: Space = singleton(&(v96_12_head));
        let v97_3: Space = intersect(&(*CONSTANT_2),&(v97_2));
        let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
        drop(v97_3);
        let v97_5: Space = subtract(&(*CONSTANT_1),&(v97_4));
        drop(v97_4);
        let v97_7: Space = if (v97_5).is_empty() { Space::new() } else {
          let v98_6: Space = routine_15(c, &(v96_12_head), &(*p1), &(v96_12_tail));
          compose(&(v97_5),&(v98_6))
        };
        drop(v97_5);
        let v97_8: Space = intersect(&(*CONSTANT_2),&(v97_2));
        drop(v97_2);
        let v97_9: Space = if has_head(&(v97_8)) { singleton(&[]) } else { Space::new() };
        drop(v97_8);
        let v97_11: Space = if (v97_9).is_empty() { Space::new() } else {
          let v99_10: Space = routine_16(c, &(v96_12_head), &(*p1), &(v96_12_tail));
          compose(&(v97_9),&(v99_10))
        };
        drop(v97_9);
        let v97_12: Space = unite(&(v97_7),&(v97_11));
        v96_12.join_into((v97_12).clone());
      }
      drop(v96_12_cursor);
      drop(v96_11);
      compose(&(v91_10),&(v96_12))
    };
    drop(v91_10);
    let v91_14: Space = unite(&(v91_8),&(v91_13));
    v90_16.join_into((v91_14).clone());
  }
  drop(v90_16_cursor);
  drop(v90_9);
  (v90_16).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v100_5: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v100_6: Space = unwrap(&(v100_5),&(*p0));
  drop(v100_5);
  let mut v100_16 = Space::new();
  let mut v100_16_cursor = (v100_6).read_zipper();
  for v100_16_byte in v100_16_cursor.child_mask().iter() {
    v100_16_cursor.descend_to_byte(v100_16_byte);
    let v100_16_tail = v100_16_cursor.make_map();
    v100_16_cursor.ascend(1);
    let v100_16_head = Path::from_slice(&[v100_16_byte]);
    let v101_2: Space = singleton(&(v100_16_head));
    let v101_3: Space = intersect(&(*CONSTANT_2),&(v101_2));
    let v101_4: Space = if has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
    drop(v101_3);
    let v101_5: Space = subtract(&(*CONSTANT_1),&(v101_4));
    drop(v101_4);
    let v101_7: Space = if (v101_5).is_empty() { Space::new() } else {
      let mut v102_6 = Space::new();
      let mut v102_6_cursor = (v100_16_tail).read_zipper();
      for v102_6_byte in v102_6_cursor.child_mask().iter() {
        v102_6_cursor.descend_to_byte(v102_6_byte);
        let v102_6_tail = v102_6_cursor.make_map();
        v102_6_cursor.ascend(1);
        let v102_6_head = Path::from_slice(&[v102_6_byte]);
        let v103_2: Space = singleton(&(v102_6_head));
        let v103_3: Space = intersect(&(*CONSTANT_2),&(v103_2));
        let v103_4: Space = if has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
        drop(v103_3);
        let v103_5: Space = subtract(&(*CONSTANT_1),&(v103_4));
        drop(v103_4);
        let v103_8: Space = if (v103_5).is_empty() { Space::new() } else {
          let v104_6: Path = concat_path(&(v100_16_head),&(v102_6_head));
          let v104_7: Space = routine_19(c, &(v104_6), &(*p1), &(v102_6_tail));
          compose(&(v103_5),&(v104_7))
        };
        drop(v103_5);
        let v103_9: Space = intersect(&(*CONSTANT_2),&(v103_2));
        drop(v103_2);
        let v103_10: Space = if has_head(&(v103_9)) { singleton(&[]) } else { Space::new() };
        drop(v103_9);
        let v103_12: Space = if (v103_10).is_empty() { Space::new() } else {
          let v105_6: Path = concat_path(&(v100_16_head),&(v102_6_head));
          let v105_11: Space = routine_20(c, &(v105_6), &(*p1), &(v102_6_tail));
          drop(v105_6);
          compose(&(v103_10),&(v105_11))
        };
        drop(v103_10);
        let v103_13: Space = unite(&(v103_8),&(v103_12));
        v102_6.join_into((v103_13).clone());
      }
      drop(v102_6_cursor);
      compose(&(v101_5),&(v102_6))
    };
    drop(v101_5);
    let v101_8: Space = intersect(&(*CONSTANT_2),&(v101_2));
    drop(v101_2);
    let v101_9: Space = if has_head(&(v101_8)) { singleton(&[]) } else { Space::new() };
    drop(v101_8);
    let v101_11: Space = if (v101_9).is_empty() { Space::new() } else {
      let mut v106_10 = Space::new();
      let mut v106_10_cursor = (v100_16_tail).read_zipper();
      for v106_10_byte in v106_10_cursor.child_mask().iter() {
        v106_10_cursor.descend_to_byte(v106_10_byte);
        let v106_10_tail = v106_10_cursor.make_map();
        v106_10_cursor.ascend(1);
        let v106_10_head = Path::from_slice(&[v106_10_byte]);
        let v107_2: Space = singleton(&(v106_10_head));
        let v107_3: Space = intersect(&(*CONSTANT_2),&(v107_2));
        let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
        drop(v107_3);
        let v107_5: Space = subtract(&(*CONSTANT_1),&(v107_4));
        drop(v107_4);
        let v107_8: Space = if (v107_5).is_empty() { Space::new() } else {
          let v108_6: Path = concat_path(&(v100_16_head),&(v106_10_head));
          let v108_7: Space = routine_19(c, &(v108_6), &(*p1), &(v106_10_tail));
          compose(&(v107_5),&(v108_7))
        };
        drop(v107_5);
        let v107_9: Space = intersect(&(*CONSTANT_2),&(v107_2));
        drop(v107_2);
        let v107_10: Space = if has_head(&(v107_9)) { singleton(&[]) } else { Space::new() };
        drop(v107_9);
        let v107_12: Space = if (v107_10).is_empty() { Space::new() } else {
          let v109_6: Path = concat_path(&(v100_16_head),&(v106_10_head));
          let v109_11: Space = routine_21(c, &(v109_6), &(*p1), &(v106_10_tail));
          drop(v109_6);
          compose(&(v107_10),&(v109_11))
        };
        drop(v107_10);
        let v107_13: Space = unite(&(v107_8),&(v107_12));
        v106_10.join_into((v107_13).clone());
      }
      drop(v106_10_cursor);
      compose(&(v101_9),&(v106_10))
    };
    drop(v101_9);
    let v101_12: Space = unite(&(v101_7),&(v101_11));
    v100_16.join_into((v101_12).clone());
  }
  drop(v100_16_cursor);
  drop(v100_6);
  (v100_16).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v110_12 = Space::new();
  let mut v110_12_cursor = (*s0).read_zipper();
  for v110_12_byte in v110_12_cursor.child_mask().iter() {
    v110_12_cursor.descend_to_byte(v110_12_byte);
    let v110_12_tail = v110_12_cursor.make_map();
    v110_12_cursor.ascend(1);
    let v110_12_head = Path::from_slice(&[v110_12_byte]);
    let v111_2: Space = singleton(&(v110_12_head));
    let v111_3: Space = intersect(&(*CONSTANT_2),&(v111_2));
    let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = subtract(&(*CONSTANT_1),&(v111_4));
    drop(v111_4);
    let v111_8: Space = if (v111_5).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&(v110_12_head));
      let mut v112_7 = Space::new();
      let mut v112_7_cursor = (v110_12_tail).read_zipper();
      for v112_7_byte in v112_7_cursor.child_mask().iter() {
        v112_7_cursor.descend_to_byte(v112_7_byte);
        let v112_7_tail = v112_7_cursor.make_map();
        v112_7_cursor.ascend(1);
        let v112_7_head = Path::from_slice(&[v112_7_byte]);
        let v113_2: Space = singleton(&(v112_7_head));
        let v113_3: Space = intersect(&(*CONSTANT_2),&(v113_2));
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = subtract(&(*CONSTANT_1),&(v113_4));
        drop(v113_4);
        let v113_8: Space = if (v113_5).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v112_6),&(v112_7_head));
          let v114_7: Space = routine_22(c, &(v114_6), &(v112_7_tail), &(*s1));
          compose(&(v113_5),&(v114_7))
        };
        drop(v113_5);
        let v113_9: Space = intersect(&(*CONSTANT_2),&(v113_2));
        drop(v113_2);
        let v113_10: Space = if has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
        drop(v113_9);
        let v113_12: Space = if (v113_10).is_empty() { Space::new() } else {
          let v115_6: Path = concat_path(&(v112_6),&(v112_7_head));
          let v115_11: Space = routine_23(c, &(v115_6), &(v112_7_tail), &(*s1));
          drop(v115_6);
          compose(&(v113_10),&(v115_11))
        };
        drop(v113_10);
        let v113_13: Space = unite(&(v113_8),&(v113_12));
        v112_7.join_into((v113_13).clone());
      }
      drop(v112_7_cursor);
      compose(&(v111_5),&(v112_7))
    };
    drop(v111_5);
    let v111_9: Space = intersect(&(*CONSTANT_2),&(v111_2));
    drop(v111_2);
    let v111_10: Space = if has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
    drop(v111_9);
    let v111_12: Space = if (v111_10).is_empty() { Space::new() } else {
      let v116_6: Path = concat_path(&(*p0),&(v110_12_head));
      let mut v116_11 = Space::new();
      let mut v116_11_cursor = (v110_12_tail).read_zipper();
      for v116_11_byte in v116_11_cursor.child_mask().iter() {
        v116_11_cursor.descend_to_byte(v116_11_byte);
        let v116_11_tail = v116_11_cursor.make_map();
        v116_11_cursor.ascend(1);
        let v116_11_head = Path::from_slice(&[v116_11_byte]);
        let v117_2: Space = singleton(&(v116_11_head));
        let v117_3: Space = intersect(&(*CONSTANT_2),&(v117_2));
        let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
        drop(v117_3);
        let v117_5: Space = subtract(&(*CONSTANT_1),&(v117_4));
        drop(v117_4);
        let v117_8: Space = if (v117_5).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v116_6),&(v116_11_head));
          let v118_7: Space = routine_22(c, &(v118_6), &(v116_11_tail), &(*s1));
          compose(&(v117_5),&(v118_7))
        };
        drop(v117_5);
        let v117_9: Space = intersect(&(*CONSTANT_2),&(v117_2));
        drop(v117_2);
        let v117_10: Space = if has_head(&(v117_9)) { singleton(&[]) } else { Space::new() };
        drop(v117_9);
        let v117_12: Space = if (v117_10).is_empty() { Space::new() } else {
          let v119_6: Path = concat_path(&(v116_6),&(v116_11_head));
          let v119_11: Space = routine_3(c, &(v119_6), &(v116_11_tail), &(*s1));
          drop(v119_6);
          compose(&(v117_10),&(v119_11))
        };
        drop(v117_10);
        let v117_13: Space = unite(&(v117_8),&(v117_12));
        v116_11.join_into((v117_13).clone());
      }
      drop(v116_11_cursor);
      drop(v116_6);
      compose(&(v111_10),&(v116_11))
    };
    drop(v111_10);
    let v111_13: Space = unite(&(v111_8),&(v111_12));
    v110_12.join_into((v111_13).clone());
  }
  drop(v110_12_cursor);
  (v110_12).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v120_12 = Space::new();
  let mut v120_12_cursor = (*s0).read_zipper();
  for v120_12_byte in v120_12_cursor.child_mask().iter() {
    v120_12_cursor.descend_to_byte(v120_12_byte);
    let v120_12_tail = v120_12_cursor.make_map();
    v120_12_cursor.ascend(1);
    let v120_12_head = Path::from_slice(&[v120_12_byte]);
    let v121_2: Space = singleton(&(v120_12_head));
    let v121_3: Space = intersect(&(*CONSTANT_2),&(v121_2));
    let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
    drop(v121_3);
    let v121_5: Space = subtract(&(*CONSTANT_1),&(v121_4));
    drop(v121_4);
    let v121_8: Space = if (v121_5).is_empty() { Space::new() } else {
      let v122_6: Path = concat_path(&(*p0),&(v120_12_head));
      let mut v122_7 = Space::new();
      let mut v122_7_cursor = (v120_12_tail).read_zipper();
      for v122_7_byte in v122_7_cursor.child_mask().iter() {
        v122_7_cursor.descend_to_byte(v122_7_byte);
        let v122_7_tail = v122_7_cursor.make_map();
        v122_7_cursor.ascend(1);
        let v122_7_head = Path::from_slice(&[v122_7_byte]);
        let v123_2: Space = singleton(&(v122_7_head));
        let v123_3: Space = intersect(&(*CONSTANT_2),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_1),&(v123_4));
        drop(v123_4);
        let v123_8: Space = if (v123_5).is_empty() { Space::new() } else {
          let v124_6: Path = concat_path(&(v122_6),&(v122_7_head));
          let v124_7: Space = routine_22(c, &(v124_6), &(v122_7_tail), &(*s1));
          compose(&(v123_5),&(v124_7))
        };
        drop(v123_5);
        let v123_9: Space = intersect(&(*CONSTANT_2),&(v123_2));
        drop(v123_2);
        let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
        drop(v123_9);
        let v123_12: Space = if (v123_10).is_empty() { Space::new() } else {
          let v125_6: Path = concat_path(&(v122_6),&(v122_7_head));
          let v125_11: Space = routine_23(c, &(v125_6), &(v122_7_tail), &(*s1));
          drop(v125_6);
          compose(&(v123_10),&(v125_11))
        };
        drop(v123_10);
        let v123_13: Space = unite(&(v123_8),&(v123_12));
        v122_7.join_into((v123_13).clone());
      }
      drop(v122_7_cursor);
      compose(&(v121_5),&(v122_7))
    };
    drop(v121_5);
    let v121_9: Space = intersect(&(*CONSTANT_2),&(v121_2));
    drop(v121_2);
    let v121_10: Space = if has_head(&(v121_9)) { singleton(&[]) } else { Space::new() };
    drop(v121_9);
    let v121_12: Space = if (v121_10).is_empty() { Space::new() } else {
      let v126_6: Path = concat_path(&(*p0),&(v120_12_head));
      let mut v126_11 = Space::new();
      let mut v126_11_cursor = (v120_12_tail).read_zipper();
      for v126_11_byte in v126_11_cursor.child_mask().iter() {
        v126_11_cursor.descend_to_byte(v126_11_byte);
        let v126_11_tail = v126_11_cursor.make_map();
        v126_11_cursor.ascend(1);
        let v126_11_head = Path::from_slice(&[v126_11_byte]);
        let v127_2: Space = singleton(&(v126_11_head));
        let v127_3: Space = intersect(&(*CONSTANT_2),&(v127_2));
        let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
        drop(v127_3);
        let v127_5: Space = subtract(&(*CONSTANT_1),&(v127_4));
        drop(v127_4);
        let v127_7: Space = if (v127_5).is_empty() { Space::new() } else {
          let v128_6: Space = routine_6(c, &(v126_11_head), &(v126_6), &(v126_11_tail), &(*s1));
          compose(&(v127_5),&(v128_6))
        };
        drop(v127_5);
        let v127_8: Space = intersect(&(*CONSTANT_2),&(v127_2));
        drop(v127_2);
        let v127_9: Space = if has_head(&(v127_8)) { singleton(&[]) } else { Space::new() };
        drop(v127_8);
        let v127_11: Space = if (v127_9).is_empty() { Space::new() } else {
          let v129_10: Space = routine_7(c, &(v126_11_head), &(v126_6), &(v126_11_tail), &(*s1));
          compose(&(v127_9),&(v129_10))
        };
        drop(v127_9);
        let v127_12: Space = unite(&(v127_7),&(v127_11));
        v126_11.join_into((v127_12).clone());
      }
      drop(v126_11_cursor);
      drop(v126_6);
      compose(&(v121_10),&(v126_11))
    };
    drop(v121_10);
    let v121_13: Space = unite(&(v121_8),&(v121_12));
    v120_12.join_into((v121_13).clone());
  }
  drop(v120_12_cursor);
  (v120_12).clone()
}

fn routine_13(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v130_13 = Space::new();
  let mut v130_13_cursor = (*s0).read_zipper();
  for v130_13_byte in v130_13_cursor.child_mask().iter() {
    v130_13_cursor.descend_to_byte(v130_13_byte);
    let v130_13_tail = v130_13_cursor.make_map();
    v130_13_cursor.ascend(1);
    let v130_13_head = Path::from_slice(&[v130_13_byte]);
    let v131_2: Space = singleton(&(v130_13_head));
    let v131_3: Space = intersect(&(*CONSTANT_2),&(v131_2));
    let v131_4: Space = if has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
    drop(v131_3);
    let v131_5: Space = subtract(&(*CONSTANT_1),&(v131_4));
    drop(v131_4);
    let v131_8: Space = if (v131_5).is_empty() { Space::new() } else {
      let v132_6: Path = concat_path(&(*p0),&(v130_13_head));
      let mut v132_7 = Space::new();
      let mut v132_7_cursor = (v130_13_tail).read_zipper();
      for v132_7_byte in v132_7_cursor.child_mask().iter() {
        v132_7_cursor.descend_to_byte(v132_7_byte);
        let v132_7_tail = v132_7_cursor.make_map();
        v132_7_cursor.ascend(1);
        let v132_7_head = Path::from_slice(&[v132_7_byte]);
        let v133_2: Space = singleton(&(v132_7_head));
        let v133_3: Space = intersect(&(*CONSTANT_2),&(v133_2));
        let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
        drop(v133_3);
        let v133_5: Space = subtract(&(*CONSTANT_1),&(v133_4));
        drop(v133_4);
        let v133_8: Space = if (v133_5).is_empty() { Space::new() } else {
          let v134_6: Path = concat_path(&(v132_6),&(v132_7_head));
          let v134_7: Space = routine_24(c, &(v134_6), &(*p1), &(v132_7_tail), &(*s1));
          compose(&(v133_5),&(v134_7))
        };
        drop(v133_5);
        let v133_9: Space = intersect(&(*CONSTANT_2),&(v133_2));
        drop(v133_2);
        let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
        drop(v133_9);
        let v133_12: Space = if (v133_10).is_empty() { Space::new() } else {
          let v135_6: Path = concat_path(&(v132_6),&(v132_7_head));
          let v135_11: Space = routine_25(c, &(v135_6), &(*p1), &(v132_7_tail), &(*s1));
          drop(v135_6);
          compose(&(v133_10),&(v135_11))
        };
        drop(v133_10);
        let v133_13: Space = unite(&(v133_8),&(v133_12));
        v132_7.join_into((v133_13).clone());
      }
      drop(v132_7_cursor);
      compose(&(v131_5),&(v132_7))
    };
    drop(v131_5);
    let v131_9: Space = intersect(&(*CONSTANT_2),&(v131_2));
    drop(v131_2);
    let v131_10: Space = if has_head(&(v131_9)) { singleton(&[]) } else { Space::new() };
    drop(v131_9);
    let v131_12: Space = if (v131_10).is_empty() { Space::new() } else {
      let v136_6: Path = concat_path(&(*p0),&(v130_13_head));
      let mut v136_11 = Space::new();
      let mut v136_11_cursor = (v130_13_tail).read_zipper();
      for v136_11_byte in v136_11_cursor.child_mask().iter() {
        v136_11_cursor.descend_to_byte(v136_11_byte);
        let v136_11_tail = v136_11_cursor.make_map();
        v136_11_cursor.ascend(1);
        let v136_11_head = Path::from_slice(&[v136_11_byte]);
        let v137_2: Space = singleton(&(v136_11_head));
        let v137_3: Space = intersect(&(*CONSTANT_2),&(v137_2));
        let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
        drop(v137_3);
        let v137_5: Space = subtract(&(*CONSTANT_1),&(v137_4));
        drop(v137_4);
        let v137_8: Space = if (v137_5).is_empty() { Space::new() } else {
          let v138_6: Path = concat_path(&(v136_6),&(v136_11_head));
          let v138_7: Space = routine_24(c, &(v138_6), &(*p1), &(v136_11_tail), &(*s1));
          compose(&(v137_5),&(v138_7))
        };
        drop(v137_5);
        let v137_9: Space = intersect(&(*CONSTANT_2),&(v137_2));
        drop(v137_2);
        let v137_10: Space = if has_head(&(v137_9)) { singleton(&[]) } else { Space::new() };
        drop(v137_9);
        let v137_12: Space = if (v137_10).is_empty() { Space::new() } else {
          let v139_6: Path = concat_path(&(v136_6),&(v136_11_head));
          let v139_11: Space = routine_10(c, &(v139_6), &(*p1), &(v136_11_tail), &(*s1));
          drop(v139_6);
          compose(&(v137_10),&(v139_11))
        };
        drop(v137_10);
        let v137_13: Space = unite(&(v137_8),&(v137_12));
        v136_11.join_into((v137_13).clone());
      }
      drop(v136_11_cursor);
      drop(v136_6);
      compose(&(v131_10),&(v136_11))
    };
    drop(v131_10);
    let v131_13: Space = unite(&(v131_8),&(v131_12));
    v130_13.join_into((v131_13).clone());
  }
  drop(v130_13_cursor);
  (v130_13).clone()
}

fn routine_14(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v140_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v140_9: Space = unwrap(&(v140_8),&(*p0));
  drop(v140_8);
  let mut v140_16 = Space::new();
  let mut v140_16_cursor = (*s0).read_zipper();
  for v140_16_byte in v140_16_cursor.child_mask().iter() {
    v140_16_cursor.descend_to_byte(v140_16_byte);
    let v140_16_tail = v140_16_cursor.make_map();
    v140_16_cursor.ascend(1);
    let v140_16_head = Path::from_slice(&[v140_16_byte]);
    let v141_2: Space = singleton(&(v140_16_head));
    let v141_3: Space = intersect(&(*CONSTANT_2),&(v141_2));
    let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
    drop(v141_3);
    let v141_5: Space = subtract(&(*CONSTANT_1),&(v141_4));
    drop(v141_4);
    let v141_8: Space = if (v141_5).is_empty() { Space::new() } else {
      let v142_6: Path = concat_path(&(*p0),&(v140_16_head));
      let mut v142_7 = Space::new();
      let mut v142_7_cursor = (v140_16_tail).read_zipper();
      for v142_7_byte in v142_7_cursor.child_mask().iter() {
        v142_7_cursor.descend_to_byte(v142_7_byte);
        let v142_7_tail = v142_7_cursor.make_map();
        v142_7_cursor.ascend(1);
        let v142_7_head = Path::from_slice(&[v142_7_byte]);
        let v143_2: Space = singleton(&(v142_7_head));
        let v143_3: Space = intersect(&(*CONSTANT_2),&(v143_2));
        let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
        drop(v143_3);
        let v143_5: Space = subtract(&(*CONSTANT_1),&(v143_4));
        drop(v143_4);
        let v143_8: Space = if (v143_5).is_empty() { Space::new() } else {
          let v144_6: Path = concat_path(&(v142_6),&(v142_7_head));
          let v144_7: Space = routine_24(c, &(v144_6), &(*p1), &(v142_7_tail), &(*s1));
          compose(&(v143_5),&(v144_7))
        };
        drop(v143_5);
        let v143_9: Space = intersect(&(*CONSTANT_2),&(v143_2));
        drop(v143_2);
        let v143_10: Space = if has_head(&(v143_9)) { singleton(&[]) } else { Space::new() };
        drop(v143_9);
        let v143_12: Space = if (v143_10).is_empty() { Space::new() } else {
          let v145_6: Path = concat_path(&(v142_6),&(v142_7_head));
          let v145_11: Space = routine_25(c, &(v145_6), &(*p1), &(v142_7_tail), &(*s1));
          drop(v145_6);
          compose(&(v143_10),&(v145_11))
        };
        drop(v143_10);
        let v143_13: Space = unite(&(v143_8),&(v143_12));
        v142_7.join_into((v143_13).clone());
      }
      drop(v142_7_cursor);
      drop(v142_6);
      compose(&(v141_5),&(v142_7))
    };
    drop(v141_5);
    let v141_9: Space = intersect(&(*CONSTANT_2),&(v141_2));
    drop(v141_2);
    let v141_10: Space = if has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
    drop(v141_9);
    let v141_13: Space = if (v141_10).is_empty() { Space::new() } else {
      let v146_11: Space = unwrap(&(v140_9),&(v140_16_head));
      let mut v146_12 = Space::new();
      let mut v146_12_cursor = (v146_11).read_zipper();
      for v146_12_byte in v146_12_cursor.child_mask().iter() {
        v146_12_cursor.descend_to_byte(v146_12_byte);
        let v146_12_tail = v146_12_cursor.make_map();
        v146_12_cursor.ascend(1);
        let v146_12_head = Path::from_slice(&[v146_12_byte]);
        let v147_2: Space = singleton(&(v146_12_head));
        let v147_3: Space = intersect(&(*CONSTANT_2),&(v147_2));
        let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
        drop(v147_3);
        let v147_5: Space = subtract(&(*CONSTANT_1),&(v147_4));
        drop(v147_4);
        let v147_7: Space = if (v147_5).is_empty() { Space::new() } else {
          let v148_6: Space = routine_15(c, &(v146_12_head), &(*p1), &(v146_12_tail));
          compose(&(v147_5),&(v148_6))
        };
        drop(v147_5);
        let v147_8: Space = intersect(&(*CONSTANT_2),&(v147_2));
        drop(v147_2);
        let v147_9: Space = if has_head(&(v147_8)) { singleton(&[]) } else { Space::new() };
        drop(v147_8);
        let v147_11: Space = if (v147_9).is_empty() { Space::new() } else {
          let v149_10: Space = routine_16(c, &(v146_12_head), &(*p1), &(v146_12_tail));
          compose(&(v147_9),&(v149_10))
        };
        drop(v147_9);
        let v147_12: Space = unite(&(v147_7),&(v147_11));
        v146_12.join_into((v147_12).clone());
      }
      drop(v146_12_cursor);
      drop(v146_11);
      compose(&(v141_10),&(v146_12))
    };
    drop(v141_10);
    let v141_14: Space = unite(&(v141_8),&(v141_13));
    v140_16.join_into((v141_14).clone());
  }
  drop(v140_16_cursor);
  drop(v140_9);
  (v140_16).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v150_12 = Space::new();
  let mut v150_12_cursor = (*s0).read_zipper();
  for v150_12_byte in v150_12_cursor.child_mask().iter() {
    v150_12_cursor.descend_to_byte(v150_12_byte);
    let v150_12_tail = v150_12_cursor.make_map();
    v150_12_cursor.ascend(1);
    let v150_12_head = Path::from_slice(&[v150_12_byte]);
    let v151_2: Space = singleton(&(v150_12_head));
    let v151_3: Space = intersect(&(*CONSTANT_2),&(v151_2));
    let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
    drop(v151_3);
    let v151_5: Space = subtract(&(*CONSTANT_1),&(v151_4));
    drop(v151_4);
    let v151_8: Space = if (v151_5).is_empty() { Space::new() } else {
      let v152_6: Path = concat_path(&(*p0),&(v150_12_head));
      let mut v152_7 = Space::new();
      let mut v152_7_cursor = (v150_12_tail).read_zipper();
      for v152_7_byte in v152_7_cursor.child_mask().iter() {
        v152_7_cursor.descend_to_byte(v152_7_byte);
        let v152_7_tail = v152_7_cursor.make_map();
        v152_7_cursor.ascend(1);
        let v152_7_head = Path::from_slice(&[v152_7_byte]);
        let v153_2: Space = singleton(&(v152_7_head));
        let v153_3: Space = intersect(&(*CONSTANT_2),&(v153_2));
        let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
        drop(v153_3);
        let v153_5: Space = subtract(&(*CONSTANT_1),&(v153_4));
        drop(v153_4);
        let v153_8: Space = if (v153_5).is_empty() { Space::new() } else {
          let v154_6: Path = concat_path(&(v152_6),&(v152_7_head));
          let v154_7: Space = routine_26(c, &(v154_6), &(*p1), &(v152_7_tail));
          compose(&(v153_5),&(v154_7))
        };
        drop(v153_5);
        let v153_9: Space = intersect(&(*CONSTANT_2),&(v153_2));
        drop(v153_2);
        let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
        drop(v153_9);
        let v153_12: Space = if (v153_10).is_empty() { Space::new() } else {
          let v155_6: Path = concat_path(&(v152_6),&(v152_7_head));
          let v155_11: Space = routine_27(c, &(v155_6), &(*p1), &(v152_7_tail));
          drop(v155_6);
          compose(&(v153_10),&(v155_11))
        };
        drop(v153_10);
        let v153_13: Space = unite(&(v153_8),&(v153_12));
        v152_7.join_into((v153_13).clone());
      }
      drop(v152_7_cursor);
      compose(&(v151_5),&(v152_7))
    };
    drop(v151_5);
    let v151_9: Space = intersect(&(*CONSTANT_2),&(v151_2));
    drop(v151_2);
    let v151_10: Space = if has_head(&(v151_9)) { singleton(&[]) } else { Space::new() };
    drop(v151_9);
    let v151_12: Space = if (v151_10).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&(v150_12_head));
      let mut v156_11 = Space::new();
      let mut v156_11_cursor = (v150_12_tail).read_zipper();
      for v156_11_byte in v156_11_cursor.child_mask().iter() {
        v156_11_cursor.descend_to_byte(v156_11_byte);
        let v156_11_tail = v156_11_cursor.make_map();
        v156_11_cursor.ascend(1);
        let v156_11_head = Path::from_slice(&[v156_11_byte]);
        let v157_2: Space = singleton(&(v156_11_head));
        let v157_3: Space = intersect(&(*CONSTANT_2),&(v157_2));
        let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = subtract(&(*CONSTANT_1),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&(v156_11_head));
          let v158_7: Space = routine_26(c, &(v158_6), &(*p1), &(v156_11_tail));
          compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = intersect(&(*CONSTANT_2),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
          let v159_6: Path = concat_path(&(v156_6),&(v156_11_head));
          let v159_11: Space = routine_21(c, &(v159_6), &(*p1), &(v156_11_tail));
          drop(v159_6);
          compose(&(v157_10),&(v159_11))
        };
        drop(v157_10);
        let v157_13: Space = unite(&(v157_8),&(v157_12));
        v156_11.join_into((v157_13).clone());
      }
      drop(v156_11_cursor);
      drop(v156_6);
      compose(&(v151_10),&(v156_11))
    };
    drop(v151_10);
    let v151_13: Space = unite(&(v151_8),&(v151_12));
    v150_12.join_into((v151_13).clone());
  }
  drop(v150_12_cursor);
  (v150_12).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v160_9 = Space::new();
  let mut v160_9_cursor = (*s0).read_zipper();
  for v160_9_byte in v160_9_cursor.child_mask().iter() {
    v160_9_cursor.descend_to_byte(v160_9_byte);
    let v160_9_tail = v160_9_cursor.make_map();
    v160_9_cursor.ascend(1);
    let v160_9_head = Path::from_slice(&[v160_9_byte]);
    let v161_2: Space = singleton(&(v160_9_head));
    let v161_3: Space = intersect(&(*CONSTANT_2),&(v161_2));
    let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
    drop(v161_3);
    let v161_5: Space = subtract(&(*CONSTANT_1),&(v161_4));
    drop(v161_4);
    let v161_8: Space = if (v161_5).is_empty() { Space::new() } else {
      let v162_6: Path = concat_path(&(*p0),&(v160_9_head));
      let mut v162_7 = Space::new();
      let mut v162_7_cursor = (v160_9_tail).read_zipper();
      for v162_7_byte in v162_7_cursor.child_mask().iter() {
        v162_7_cursor.descend_to_byte(v162_7_byte);
        let v162_7_tail = v162_7_cursor.make_map();
        v162_7_cursor.ascend(1);
        let v162_7_head = Path::from_slice(&[v162_7_byte]);
        let v163_2: Space = singleton(&(v162_7_head));
        let v163_3: Space = intersect(&(*CONSTANT_2),&(v163_2));
        let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
        drop(v163_3);
        let v163_5: Space = subtract(&(*CONSTANT_1),&(v163_4));
        drop(v163_4);
        let v163_8: Space = if (v163_5).is_empty() { Space::new() } else {
          let v164_6: Path = concat_path(&(v162_6),&(v162_7_head));
          let v164_7: Space = routine_26(c, &(v164_6), &(*p1), &(v162_7_tail));
          compose(&(v163_5),&(v164_7))
        };
        drop(v163_5);
        let v163_9: Space = intersect(&(*CONSTANT_2),&(v163_2));
        drop(v163_2);
        let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
        drop(v163_9);
        let v163_12: Space = if (v163_10).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v162_6),&(v162_7_head));
          let v165_11: Space = routine_27(c, &(v165_6), &(*p1), &(v162_7_tail));
          drop(v165_6);
          compose(&(v163_10),&(v165_11))
        };
        drop(v163_10);
        let v163_13: Space = unite(&(v163_8),&(v163_12));
        v162_7.join_into((v163_13).clone());
      }
      drop(v162_7_cursor);
      compose(&(v161_5),&(v162_7))
    };
    drop(v161_5);
    let v161_9: Space = intersect(&(*CONSTANT_2),&(v161_2));
    drop(v161_2);
    let v161_10: Space = if has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
    drop(v161_9);
    let v161_11: Space = compose(&(v161_10),&(v160_9_tail));
    drop(v161_10);
    let v166_6: Path = concat_path(&(*p0),&(v160_9_head));
    let v161_12: Space = wrap(&(v161_11),&(v166_6));
    drop(v161_11);
    let v161_13: Space = wrap(&(v161_12),&(*p1));
    drop(v161_12);
    let v161_14: Space = unite(&(v161_8),&(v161_13));
    drop(v161_13);
    v160_9.join_into((v161_14).clone());
  }
  drop(v160_9_cursor);
  (v160_9).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v167_13 = Space::new();
  let mut v167_13_cursor = (*s0).read_zipper();
  for v167_13_byte in v167_13_cursor.child_mask().iter() {
    v167_13_cursor.descend_to_byte(v167_13_byte);
    let v167_13_tail = v167_13_cursor.make_map();
    v167_13_cursor.ascend(1);
    let v167_13_head = Path::from_slice(&[v167_13_byte]);
    let v168_2: Space = singleton(&(v167_13_head));
    let v168_3: Space = intersect(&(*CONSTANT_2),&(v168_2));
    let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
    drop(v168_3);
    let v168_5: Space = subtract(&(*CONSTANT_1),&(v168_4));
    drop(v168_4);
    let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
      let v169_6: Path = concat_path(&(*p0),&(v167_13_head));
      let mut v169_7 = Space::new();
      let mut v169_7_cursor = (v167_13_tail).read_zipper();
      for v169_7_byte in v169_7_cursor.child_mask().iter() {
        v169_7_cursor.descend_to_byte(v169_7_byte);
        let v169_7_tail = v169_7_cursor.make_map();
        v169_7_cursor.ascend(1);
        let v169_7_head = Path::from_slice(&[v169_7_byte]);
        let v170_2: Space = singleton(&(v169_7_head));
        let v170_3: Space = intersect(&(*CONSTANT_2),&(v170_2));
        let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
        drop(v170_3);
        let v170_5: Space = subtract(&(*CONSTANT_1),&(v170_4));
        drop(v170_4);
        let v170_8: Space = if (v170_5).is_empty() { Space::new() } else {
          let v171_6: Path = concat_path(&(v169_6),&(v169_7_head));
          let v171_7: Space = routine_28(c, &(v171_6), &(*p1), &(v169_7_tail), &(*s1));
          compose(&(v170_5),&(v171_7))
        };
        drop(v170_5);
        let v170_9: Space = intersect(&(*CONSTANT_2),&(v170_2));
        drop(v170_2);
        let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
        drop(v170_9);
        let v170_12: Space = if (v170_10).is_empty() { Space::new() } else {
          let v172_6: Path = concat_path(&(v169_6),&(v169_7_head));
          let v172_11: Space = routine_29(c, &(v172_6), &(*p1), &(v169_7_tail), &(*s1));
          drop(v172_6);
          compose(&(v170_10),&(v172_11))
        };
        drop(v170_10);
        let v170_13: Space = unite(&(v170_8),&(v170_12));
        v169_7.join_into((v170_13).clone());
      }
      drop(v169_7_cursor);
      compose(&(v168_5),&(v169_7))
    };
    drop(v168_5);
    let v168_9: Space = intersect(&(*CONSTANT_2),&(v168_2));
    drop(v168_2);
    let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
    drop(v168_9);
    let v168_12: Space = if (v168_10).is_empty() { Space::new() } else {
      let v173_6: Path = concat_path(&(*p0),&(v167_13_head));
      let mut v173_11 = Space::new();
      let mut v173_11_cursor = (v167_13_tail).read_zipper();
      for v173_11_byte in v173_11_cursor.child_mask().iter() {
        v173_11_cursor.descend_to_byte(v173_11_byte);
        let v173_11_tail = v173_11_cursor.make_map();
        v173_11_cursor.ascend(1);
        let v173_11_head = Path::from_slice(&[v173_11_byte]);
        let v174_2: Space = singleton(&(v173_11_head));
        let v174_3: Space = intersect(&(*CONSTANT_2),&(v174_2));
        let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
        drop(v174_3);
        let v174_5: Space = subtract(&(*CONSTANT_1),&(v174_4));
        drop(v174_4);
        let v174_8: Space = if (v174_5).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v173_6),&(v173_11_head));
          let v175_7: Space = routine_28(c, &(v175_6), &(*p1), &(v173_11_tail), &(*s1));
          compose(&(v174_5),&(v175_7))
        };
        drop(v174_5);
        let v174_9: Space = intersect(&(*CONSTANT_2),&(v174_2));
        drop(v174_2);
        let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
        drop(v174_9);
        let v174_12: Space = if (v174_10).is_empty() { Space::new() } else {
          let v176_6: Path = concat_path(&(v173_6),&(v173_11_head));
          let v176_11: Space = routine_10(c, &(v176_6), &(*p1), &(v173_11_tail), &(*s1));
          drop(v176_6);
          compose(&(v174_10),&(v176_11))
        };
        drop(v174_10);
        let v174_13: Space = unite(&(v174_8),&(v174_12));
        v173_11.join_into((v174_13).clone());
      }
      drop(v173_11_cursor);
      drop(v173_6);
      compose(&(v168_10),&(v173_11))
    };
    drop(v168_10);
    let v168_13: Space = unite(&(v168_8),&(v168_12));
    v167_13.join_into((v168_13).clone());
  }
  drop(v167_13_cursor);
  (v167_13).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v177_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v177_9: Space = unwrap(&(v177_8),&(*p0));
  drop(v177_8);
  let mut v177_16 = Space::new();
  let mut v177_16_cursor = (*s0).read_zipper();
  for v177_16_byte in v177_16_cursor.child_mask().iter() {
    v177_16_cursor.descend_to_byte(v177_16_byte);
    let v177_16_tail = v177_16_cursor.make_map();
    v177_16_cursor.ascend(1);
    let v177_16_head = Path::from_slice(&[v177_16_byte]);
    let v178_2: Space = singleton(&(v177_16_head));
    let v178_3: Space = intersect(&(*CONSTANT_2),&(v178_2));
    let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
    drop(v178_3);
    let v178_5: Space = subtract(&(*CONSTANT_1),&(v178_4));
    drop(v178_4);
    let v178_8: Space = if (v178_5).is_empty() { Space::new() } else {
      let v179_6: Path = concat_path(&(*p0),&(v177_16_head));
      let mut v179_7 = Space::new();
      let mut v179_7_cursor = (v177_16_tail).read_zipper();
      for v179_7_byte in v179_7_cursor.child_mask().iter() {
        v179_7_cursor.descend_to_byte(v179_7_byte);
        let v179_7_tail = v179_7_cursor.make_map();
        v179_7_cursor.ascend(1);
        let v179_7_head = Path::from_slice(&[v179_7_byte]);
        let v180_2: Space = singleton(&(v179_7_head));
        let v180_3: Space = intersect(&(*CONSTANT_2),&(v180_2));
        let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
        drop(v180_3);
        let v180_5: Space = subtract(&(*CONSTANT_1),&(v180_4));
        drop(v180_4);
        let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v181_7: Space = routine_28(c, &(v181_6), &(*p1), &(v179_7_tail), &(*s1));
          compose(&(v180_5),&(v181_7))
        };
        drop(v180_5);
        let v180_9: Space = intersect(&(*CONSTANT_2),&(v180_2));
        drop(v180_2);
        let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
        drop(v180_9);
        let v180_12: Space = if (v180_10).is_empty() { Space::new() } else {
          let v182_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v182_11: Space = routine_29(c, &(v182_6), &(*p1), &(v179_7_tail), &(*s1));
          drop(v182_6);
          compose(&(v180_10),&(v182_11))
        };
        drop(v180_10);
        let v180_13: Space = unite(&(v180_8),&(v180_12));
        v179_7.join_into((v180_13).clone());
      }
      drop(v179_7_cursor);
      drop(v179_6);
      compose(&(v178_5),&(v179_7))
    };
    drop(v178_5);
    let v178_9: Space = intersect(&(*CONSTANT_2),&(v178_2));
    drop(v178_2);
    let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
    drop(v178_9);
    let v178_13: Space = if (v178_10).is_empty() { Space::new() } else {
      let v183_11: Space = unwrap(&(v177_9),&(v177_16_head));
      let mut v183_12 = Space::new();
      let mut v183_12_cursor = (v183_11).read_zipper();
      for v183_12_byte in v183_12_cursor.child_mask().iter() {
        v183_12_cursor.descend_to_byte(v183_12_byte);
        let v183_12_tail = v183_12_cursor.make_map();
        v183_12_cursor.ascend(1);
        let v183_12_head = Path::from_slice(&[v183_12_byte]);
        let v184_2: Space = singleton(&(v183_12_head));
        let v184_3: Space = intersect(&(*CONSTANT_2),&(v184_2));
        let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
        drop(v184_3);
        let v184_5: Space = subtract(&(*CONSTANT_1),&(v184_4));
        drop(v184_4);
        let v184_7: Space = if (v184_5).is_empty() { Space::new() } else {
          let v185_6: Space = routine_15(c, &(v183_12_head), &(*p1), &(v183_12_tail));
          compose(&(v184_5),&(v185_6))
        };
        drop(v184_5);
        let v184_8: Space = intersect(&(*CONSTANT_2),&(v184_2));
        drop(v184_2);
        let v184_9: Space = if has_head(&(v184_8)) { singleton(&[]) } else { Space::new() };
        drop(v184_8);
        let v184_11: Space = if (v184_9).is_empty() { Space::new() } else {
          let v186_10: Space = routine_16(c, &(v183_12_head), &(*p1), &(v183_12_tail));
          compose(&(v184_9),&(v186_10))
        };
        drop(v184_9);
        let v184_12: Space = unite(&(v184_7),&(v184_11));
        v183_12.join_into((v184_12).clone());
      }
      drop(v183_12_cursor);
      drop(v183_11);
      compose(&(v178_10),&(v183_12))
    };
    drop(v178_10);
    let v178_14: Space = unite(&(v178_8),&(v178_13));
    v177_16.join_into((v178_14).clone());
  }
  drop(v177_16_cursor);
  drop(v177_9);
  (v177_16).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v187_12 = Space::new();
  let mut v187_12_cursor = (*s0).read_zipper();
  for v187_12_byte in v187_12_cursor.child_mask().iter() {
    v187_12_cursor.descend_to_byte(v187_12_byte);
    let v187_12_tail = v187_12_cursor.make_map();
    v187_12_cursor.ascend(1);
    let v187_12_head = Path::from_slice(&[v187_12_byte]);
    let v188_2: Space = singleton(&(v187_12_head));
    let v188_3: Space = intersect(&(*CONSTANT_2),&(v188_2));
    let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
    drop(v188_3);
    let v188_5: Space = subtract(&(*CONSTANT_1),&(v188_4));
    drop(v188_4);
    let v188_8: Space = if (v188_5).is_empty() { Space::new() } else {
      let v189_6: Path = concat_path(&(*p0),&(v187_12_head));
      let mut v189_7 = Space::new();
      let mut v189_7_cursor = (v187_12_tail).read_zipper();
      for v189_7_byte in v189_7_cursor.child_mask().iter() {
        v189_7_cursor.descend_to_byte(v189_7_byte);
        let v189_7_tail = v189_7_cursor.make_map();
        v189_7_cursor.ascend(1);
        let v189_7_head = Path::from_slice(&[v189_7_byte]);
        let v190_2: Space = singleton(&(v189_7_head));
        let v190_3: Space = intersect(&(*CONSTANT_2),&(v190_2));
        let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
        drop(v190_3);
        let v190_5: Space = subtract(&(*CONSTANT_1),&(v190_4));
        drop(v190_4);
        let v190_8: Space = if (v190_5).is_empty() { Space::new() } else {
          let v191_6: Path = concat_path(&(v189_6),&(v189_7_head));
          let v191_7: Space = routine_30(c, &(v191_6), &(*p1), &(v189_7_tail));
          compose(&(v190_5),&(v191_7))
        };
        drop(v190_5);
        let v190_9: Space = intersect(&(*CONSTANT_2),&(v190_2));
        drop(v190_2);
        let v190_10: Space = if has_head(&(v190_9)) { singleton(&[]) } else { Space::new() };
        drop(v190_9);
        let v190_12: Space = if (v190_10).is_empty() { Space::new() } else {
          let v192_6: Path = concat_path(&(v189_6),&(v189_7_head));
          let v192_11: Space = routine_31(c, &(v192_6), &(*p1), &(v189_7_tail));
          drop(v192_6);
          compose(&(v190_10),&(v192_11))
        };
        drop(v190_10);
        let v190_13: Space = unite(&(v190_8),&(v190_12));
        v189_7.join_into((v190_13).clone());
      }
      drop(v189_7_cursor);
      compose(&(v188_5),&(v189_7))
    };
    drop(v188_5);
    let v188_9: Space = intersect(&(*CONSTANT_2),&(v188_2));
    drop(v188_2);
    let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
    drop(v188_9);
    let v188_12: Space = if (v188_10).is_empty() { Space::new() } else {
      let v193_6: Path = concat_path(&(*p0),&(v187_12_head));
      let mut v193_11 = Space::new();
      let mut v193_11_cursor = (v187_12_tail).read_zipper();
      for v193_11_byte in v193_11_cursor.child_mask().iter() {
        v193_11_cursor.descend_to_byte(v193_11_byte);
        let v193_11_tail = v193_11_cursor.make_map();
        v193_11_cursor.ascend(1);
        let v193_11_head = Path::from_slice(&[v193_11_byte]);
        let v194_2: Space = singleton(&(v193_11_head));
        let v194_3: Space = intersect(&(*CONSTANT_2),&(v194_2));
        let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
        drop(v194_3);
        let v194_5: Space = subtract(&(*CONSTANT_1),&(v194_4));
        drop(v194_4);
        let v194_8: Space = if (v194_5).is_empty() { Space::new() } else {
          let v195_6: Path = concat_path(&(v193_6),&(v193_11_head));
          let v195_7: Space = routine_30(c, &(v195_6), &(*p1), &(v193_11_tail));
          compose(&(v194_5),&(v195_7))
        };
        drop(v194_5);
        let v194_9: Space = intersect(&(*CONSTANT_2),&(v194_2));
        drop(v194_2);
        let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
        drop(v194_9);
        let v194_12: Space = if (v194_10).is_empty() { Space::new() } else {
          let v196_6: Path = concat_path(&(v193_6),&(v193_11_head));
          let v196_11: Space = routine_21(c, &(v196_6), &(*p1), &(v193_11_tail));
          drop(v196_6);
          compose(&(v194_10),&(v196_11))
        };
        drop(v194_10);
        let v194_13: Space = unite(&(v194_8),&(v194_12));
        v193_11.join_into((v194_13).clone());
      }
      drop(v193_11_cursor);
      drop(v193_6);
      compose(&(v188_10),&(v193_11))
    };
    drop(v188_10);
    let v188_13: Space = unite(&(v188_8),&(v188_12));
    v187_12.join_into((v188_13).clone());
  }
  drop(v187_12_cursor);
  (v187_12).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v197_9 = Space::new();
  let mut v197_9_cursor = (*s0).read_zipper();
  for v197_9_byte in v197_9_cursor.child_mask().iter() {
    v197_9_cursor.descend_to_byte(v197_9_byte);
    let v197_9_tail = v197_9_cursor.make_map();
    v197_9_cursor.ascend(1);
    let v197_9_head = Path::from_slice(&[v197_9_byte]);
    let v198_2: Space = singleton(&(v197_9_head));
    let v198_3: Space = intersect(&(*CONSTANT_2),&(v198_2));
    let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
    drop(v198_3);
    let v198_5: Space = subtract(&(*CONSTANT_1),&(v198_4));
    drop(v198_4);
    let v198_8: Space = if (v198_5).is_empty() { Space::new() } else {
      let v199_6: Path = concat_path(&(*p0),&(v197_9_head));
      let mut v199_7 = Space::new();
      let mut v199_7_cursor = (v197_9_tail).read_zipper();
      for v199_7_byte in v199_7_cursor.child_mask().iter() {
        v199_7_cursor.descend_to_byte(v199_7_byte);
        let v199_7_tail = v199_7_cursor.make_map();
        v199_7_cursor.ascend(1);
        let v199_7_head = Path::from_slice(&[v199_7_byte]);
        let v200_2: Space = singleton(&(v199_7_head));
        let v200_3: Space = intersect(&(*CONSTANT_2),&(v200_2));
        let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
        drop(v200_3);
        let v200_5: Space = subtract(&(*CONSTANT_1),&(v200_4));
        drop(v200_4);
        let v200_8: Space = if (v200_5).is_empty() { Space::new() } else {
          let v201_6: Path = concat_path(&(v199_6),&(v199_7_head));
          let v201_7: Space = routine_30(c, &(v201_6), &(*p1), &(v199_7_tail));
          compose(&(v200_5),&(v201_7))
        };
        drop(v200_5);
        let v200_9: Space = intersect(&(*CONSTANT_2),&(v200_2));
        drop(v200_2);
        let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
        drop(v200_9);
        let v200_12: Space = if (v200_10).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v199_6),&(v199_7_head));
          let v202_11: Space = routine_31(c, &(v202_6), &(*p1), &(v199_7_tail));
          drop(v202_6);
          compose(&(v200_10),&(v202_11))
        };
        drop(v200_10);
        let v200_13: Space = unite(&(v200_8),&(v200_12));
        v199_7.join_into((v200_13).clone());
      }
      drop(v199_7_cursor);
      compose(&(v198_5),&(v199_7))
    };
    drop(v198_5);
    let v198_9: Space = intersect(&(*CONSTANT_2),&(v198_2));
    drop(v198_2);
    let v198_10: Space = if has_head(&(v198_9)) { singleton(&[]) } else { Space::new() };
    drop(v198_9);
    let v198_11: Space = compose(&(v198_10),&(v197_9_tail));
    drop(v198_10);
    let v203_6: Path = concat_path(&(*p0),&(v197_9_head));
    let v198_12: Space = wrap(&(v198_11),&(v203_6));
    drop(v198_11);
    let v198_13: Space = wrap(&(v198_12),&(*p1));
    drop(v198_12);
    let v198_14: Space = unite(&(v198_8),&(v198_13));
    drop(v198_13);
    v197_9.join_into((v198_14).clone());
  }
  drop(v197_9_cursor);
  (v197_9).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v204_3: Space = wrap(&(*s0),&(*p0));
  let v204_4: Space = wrap(&(v204_3),&(*p1));
  drop(v204_3);
  (v204_4).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v205_12 = Space::new();
  let mut v205_12_cursor = (*s0).read_zipper();
  for v205_12_byte in v205_12_cursor.child_mask().iter() {
    v205_12_cursor.descend_to_byte(v205_12_byte);
    let v205_12_tail = v205_12_cursor.make_map();
    v205_12_cursor.ascend(1);
    let v205_12_head = Path::from_slice(&[v205_12_byte]);
    let v206_2: Space = singleton(&(v205_12_head));
    let v206_3: Space = intersect(&(*CONSTANT_2),&(v206_2));
    let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
    drop(v206_3);
    let v206_5: Space = subtract(&(*CONSTANT_1),&(v206_4));
    drop(v206_4);
    let v206_8: Space = if (v206_5).is_empty() { Space::new() } else {
      let v207_6: Path = concat_path(&(*p0),&(v205_12_head));
      let mut v207_7 = Space::new();
      let mut v207_7_cursor = (v205_12_tail).read_zipper();
      for v207_7_byte in v207_7_cursor.child_mask().iter() {
        v207_7_cursor.descend_to_byte(v207_7_byte);
        let v207_7_tail = v207_7_cursor.make_map();
        v207_7_cursor.ascend(1);
        let v207_7_head = Path::from_slice(&[v207_7_byte]);
        let v208_2: Space = singleton(&(v207_7_head));
        let v208_3: Space = intersect(&(*CONSTANT_2),&(v208_2));
        let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
        drop(v208_3);
        let v208_5: Space = subtract(&(*CONSTANT_1),&(v208_4));
        drop(v208_4);
        let v208_8: Space = if (v208_5).is_empty() { Space::new() } else {
          let v209_6: Path = concat_path(&(v207_6),&(v207_7_head));
          let v209_7: Space = routine_32(c, &(v209_6), &(v207_7_tail), &(*s1));
          compose(&(v208_5),&(v209_7))
        };
        drop(v208_5);
        let v208_9: Space = intersect(&(*CONSTANT_2),&(v208_2));
        drop(v208_2);
        let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
        drop(v208_9);
        let v208_12: Space = if (v208_10).is_empty() { Space::new() } else {
          let v210_6: Path = concat_path(&(v207_6),&(v207_7_head));
          let v210_11: Space = routine_33(c, &(v210_6), &(v207_7_tail), &(*s1));
          drop(v210_6);
          compose(&(v208_10),&(v210_11))
        };
        drop(v208_10);
        let v208_13: Space = unite(&(v208_8),&(v208_12));
        v207_7.join_into((v208_13).clone());
      }
      drop(v207_7_cursor);
      compose(&(v206_5),&(v207_7))
    };
    drop(v206_5);
    let v206_9: Space = intersect(&(*CONSTANT_2),&(v206_2));
    drop(v206_2);
    let v206_10: Space = if has_head(&(v206_9)) { singleton(&[]) } else { Space::new() };
    drop(v206_9);
    let v206_12: Space = if (v206_10).is_empty() { Space::new() } else {
      let v211_6: Path = concat_path(&(*p0),&(v205_12_head));
      let mut v211_11 = Space::new();
      let mut v211_11_cursor = (v205_12_tail).read_zipper();
      for v211_11_byte in v211_11_cursor.child_mask().iter() {
        v211_11_cursor.descend_to_byte(v211_11_byte);
        let v211_11_tail = v211_11_cursor.make_map();
        v211_11_cursor.ascend(1);
        let v211_11_head = Path::from_slice(&[v211_11_byte]);
        let v212_2: Space = singleton(&(v211_11_head));
        let v212_3: Space = intersect(&(*CONSTANT_2),&(v212_2));
        let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
        drop(v212_3);
        let v212_5: Space = subtract(&(*CONSTANT_1),&(v212_4));
        drop(v212_4);
        let v212_8: Space = if (v212_5).is_empty() { Space::new() } else {
          let v213_6: Path = concat_path(&(v211_6),&(v211_11_head));
          let v213_7: Space = routine_32(c, &(v213_6), &(v211_11_tail), &(*s1));
          compose(&(v212_5),&(v213_7))
        };
        drop(v212_5);
        let v212_9: Space = intersect(&(*CONSTANT_2),&(v212_2));
        drop(v212_2);
        let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
        drop(v212_9);
        let v212_12: Space = if (v212_10).is_empty() { Space::new() } else {
          let v214_6: Path = concat_path(&(v211_6),&(v211_11_head));
          let v214_11: Space = routine_3(c, &(v214_6), &(v211_11_tail), &(*s1));
          drop(v214_6);
          compose(&(v212_10),&(v214_11))
        };
        drop(v212_10);
        let v212_13: Space = unite(&(v212_8),&(v212_12));
        v211_11.join_into((v212_13).clone());
      }
      drop(v211_11_cursor);
      drop(v211_6);
      compose(&(v206_10),&(v211_11))
    };
    drop(v206_10);
    let v206_13: Space = unite(&(v206_8),&(v206_12));
    v205_12.join_into((v206_13).clone());
  }
  drop(v205_12_cursor);
  (v205_12).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v215_12 = Space::new();
  let mut v215_12_cursor = (*s0).read_zipper();
  for v215_12_byte in v215_12_cursor.child_mask().iter() {
    v215_12_cursor.descend_to_byte(v215_12_byte);
    let v215_12_tail = v215_12_cursor.make_map();
    v215_12_cursor.ascend(1);
    let v215_12_head = Path::from_slice(&[v215_12_byte]);
    let v216_2: Space = singleton(&(v215_12_head));
    let v216_3: Space = intersect(&(*CONSTANT_2),&(v216_2));
    let v216_4: Space = if has_head(&(v216_3)) { singleton(&[]) } else { Space::new() };
    drop(v216_3);
    let v216_5: Space = subtract(&(*CONSTANT_1),&(v216_4));
    drop(v216_4);
    let v216_8: Space = if (v216_5).is_empty() { Space::new() } else {
      let v217_6: Path = concat_path(&(*p0),&(v215_12_head));
      let mut v217_7 = Space::new();
      let mut v217_7_cursor = (v215_12_tail).read_zipper();
      for v217_7_byte in v217_7_cursor.child_mask().iter() {
        v217_7_cursor.descend_to_byte(v217_7_byte);
        let v217_7_tail = v217_7_cursor.make_map();
        v217_7_cursor.ascend(1);
        let v217_7_head = Path::from_slice(&[v217_7_byte]);
        let v218_2: Space = singleton(&(v217_7_head));
        let v218_3: Space = intersect(&(*CONSTANT_2),&(v218_2));
        let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
        drop(v218_3);
        let v218_5: Space = subtract(&(*CONSTANT_1),&(v218_4));
        drop(v218_4);
        let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
          let v219_6: Path = concat_path(&(v217_6),&(v217_7_head));
          let v219_7: Space = routine_32(c, &(v219_6), &(v217_7_tail), &(*s1));
          compose(&(v218_5),&(v219_7))
        };
        drop(v218_5);
        let v218_9: Space = intersect(&(*CONSTANT_2),&(v218_2));
        drop(v218_2);
        let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
        drop(v218_9);
        let v218_12: Space = if (v218_10).is_empty() { Space::new() } else {
          let v220_6: Path = concat_path(&(v217_6),&(v217_7_head));
          let v220_11: Space = routine_33(c, &(v220_6), &(v217_7_tail), &(*s1));
          drop(v220_6);
          compose(&(v218_10),&(v220_11))
        };
        drop(v218_10);
        let v218_13: Space = unite(&(v218_8),&(v218_12));
        v217_7.join_into((v218_13).clone());
      }
      drop(v217_7_cursor);
      compose(&(v216_5),&(v217_7))
    };
    drop(v216_5);
    let v216_9: Space = intersect(&(*CONSTANT_2),&(v216_2));
    drop(v216_2);
    let v216_10: Space = if has_head(&(v216_9)) { singleton(&[]) } else { Space::new() };
    drop(v216_9);
    let v216_12: Space = if (v216_10).is_empty() { Space::new() } else {
      let v221_6: Path = concat_path(&(*p0),&(v215_12_head));
      let mut v221_11 = Space::new();
      let mut v221_11_cursor = (v215_12_tail).read_zipper();
      for v221_11_byte in v221_11_cursor.child_mask().iter() {
        v221_11_cursor.descend_to_byte(v221_11_byte);
        let v221_11_tail = v221_11_cursor.make_map();
        v221_11_cursor.ascend(1);
        let v221_11_head = Path::from_slice(&[v221_11_byte]);
        let v222_2: Space = singleton(&(v221_11_head));
        let v222_3: Space = intersect(&(*CONSTANT_2),&(v222_2));
        let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
        drop(v222_3);
        let v222_5: Space = subtract(&(*CONSTANT_1),&(v222_4));
        drop(v222_4);
        let v222_7: Space = if (v222_5).is_empty() { Space::new() } else {
          let v223_6: Space = routine_6(c, &(v221_11_head), &(v221_6), &(v221_11_tail), &(*s1));
          compose(&(v222_5),&(v223_6))
        };
        drop(v222_5);
        let v222_8: Space = intersect(&(*CONSTANT_2),&(v222_2));
        drop(v222_2);
        let v222_9: Space = if has_head(&(v222_8)) { singleton(&[]) } else { Space::new() };
        drop(v222_8);
        let v222_11: Space = if (v222_9).is_empty() { Space::new() } else {
          let v224_10: Space = routine_7(c, &(v221_11_head), &(v221_6), &(v221_11_tail), &(*s1));
          compose(&(v222_9),&(v224_10))
        };
        drop(v222_9);
        let v222_12: Space = unite(&(v222_7),&(v222_11));
        v221_11.join_into((v222_12).clone());
      }
      drop(v221_11_cursor);
      drop(v221_6);
      compose(&(v216_10),&(v221_11))
    };
    drop(v216_10);
    let v216_13: Space = unite(&(v216_8),&(v216_12));
    v215_12.join_into((v216_13).clone());
  }
  drop(v215_12_cursor);
  (v215_12).clone()
}

fn routine_24(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v225_13 = Space::new();
  let mut v225_13_cursor = (*s0).read_zipper();
  for v225_13_byte in v225_13_cursor.child_mask().iter() {
    v225_13_cursor.descend_to_byte(v225_13_byte);
    let v225_13_tail = v225_13_cursor.make_map();
    v225_13_cursor.ascend(1);
    let v225_13_head = Path::from_slice(&[v225_13_byte]);
    let v226_2: Space = singleton(&(v225_13_head));
    let v226_3: Space = intersect(&(*CONSTANT_2),&(v226_2));
    let v226_4: Space = if has_head(&(v226_3)) { singleton(&[]) } else { Space::new() };
    drop(v226_3);
    let v226_5: Space = subtract(&(*CONSTANT_1),&(v226_4));
    drop(v226_4);
    let v226_8: Space = if (v226_5).is_empty() { Space::new() } else {
      let v227_6: Path = concat_path(&(*p0),&(v225_13_head));
      let mut v227_7 = Space::new();
      let mut v227_7_cursor = (v225_13_tail).read_zipper();
      for v227_7_byte in v227_7_cursor.child_mask().iter() {
        v227_7_cursor.descend_to_byte(v227_7_byte);
        let v227_7_tail = v227_7_cursor.make_map();
        v227_7_cursor.ascend(1);
        let v227_7_head = Path::from_slice(&[v227_7_byte]);
        let v228_2: Space = singleton(&(v227_7_head));
        let v228_3: Space = intersect(&(*CONSTANT_2),&(v228_2));
        let v228_4: Space = if has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
        drop(v228_3);
        let v228_5: Space = subtract(&(*CONSTANT_1),&(v228_4));
        drop(v228_4);
        let v228_8: Space = if (v228_5).is_empty() { Space::new() } else {
          let v229_6: Path = concat_path(&(v227_6),&(v227_7_head));
          let v229_7: Space = routine_34(c, &(v229_6), &(*p1), &(v227_7_tail), &(*s1));
          compose(&(v228_5),&(v229_7))
        };
        drop(v228_5);
        let v228_9: Space = intersect(&(*CONSTANT_2),&(v228_2));
        drop(v228_2);
        let v228_10: Space = if has_head(&(v228_9)) { singleton(&[]) } else { Space::new() };
        drop(v228_9);
        let v228_12: Space = if (v228_10).is_empty() { Space::new() } else {
          let v230_6: Path = concat_path(&(v227_6),&(v227_7_head));
          let v230_11: Space = routine_35(c, &(v230_6), &(*p1), &(v227_7_tail), &(*s1));
          drop(v230_6);
          compose(&(v228_10),&(v230_11))
        };
        drop(v228_10);
        let v228_13: Space = unite(&(v228_8),&(v228_12));
        v227_7.join_into((v228_13).clone());
      }
      drop(v227_7_cursor);
      compose(&(v226_5),&(v227_7))
    };
    drop(v226_5);
    let v226_9: Space = intersect(&(*CONSTANT_2),&(v226_2));
    drop(v226_2);
    let v226_10: Space = if has_head(&(v226_9)) { singleton(&[]) } else { Space::new() };
    drop(v226_9);
    let v226_12: Space = if (v226_10).is_empty() { Space::new() } else {
      let v231_6: Path = concat_path(&(*p0),&(v225_13_head));
      let mut v231_11 = Space::new();
      let mut v231_11_cursor = (v225_13_tail).read_zipper();
      for v231_11_byte in v231_11_cursor.child_mask().iter() {
        v231_11_cursor.descend_to_byte(v231_11_byte);
        let v231_11_tail = v231_11_cursor.make_map();
        v231_11_cursor.ascend(1);
        let v231_11_head = Path::from_slice(&[v231_11_byte]);
        let v232_2: Space = singleton(&(v231_11_head));
        let v232_3: Space = intersect(&(*CONSTANT_2),&(v232_2));
        let v232_4: Space = if has_head(&(v232_3)) { singleton(&[]) } else { Space::new() };
        drop(v232_3);
        let v232_5: Space = subtract(&(*CONSTANT_1),&(v232_4));
        drop(v232_4);
        let v232_8: Space = if (v232_5).is_empty() { Space::new() } else {
          let v233_6: Path = concat_path(&(v231_6),&(v231_11_head));
          let v233_7: Space = routine_34(c, &(v233_6), &(*p1), &(v231_11_tail), &(*s1));
          compose(&(v232_5),&(v233_7))
        };
        drop(v232_5);
        let v232_9: Space = intersect(&(*CONSTANT_2),&(v232_2));
        drop(v232_2);
        let v232_10: Space = if has_head(&(v232_9)) { singleton(&[]) } else { Space::new() };
        drop(v232_9);
        let v232_12: Space = if (v232_10).is_empty() { Space::new() } else {
          let v234_6: Path = concat_path(&(v231_6),&(v231_11_head));
          let v234_11: Space = routine_10(c, &(v234_6), &(*p1), &(v231_11_tail), &(*s1));
          drop(v234_6);
          compose(&(v232_10),&(v234_11))
        };
        drop(v232_10);
        let v232_13: Space = unite(&(v232_8),&(v232_12));
        v231_11.join_into((v232_13).clone());
      }
      drop(v231_11_cursor);
      drop(v231_6);
      compose(&(v226_10),&(v231_11))
    };
    drop(v226_10);
    let v226_13: Space = unite(&(v226_8),&(v226_12));
    v225_13.join_into((v226_13).clone());
  }
  drop(v225_13_cursor);
  (v225_13).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v235_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v235_9: Space = unwrap(&(v235_8),&(*p0));
  drop(v235_8);
  let mut v235_16 = Space::new();
  let mut v235_16_cursor = (*s0).read_zipper();
  for v235_16_byte in v235_16_cursor.child_mask().iter() {
    v235_16_cursor.descend_to_byte(v235_16_byte);
    let v235_16_tail = v235_16_cursor.make_map();
    v235_16_cursor.ascend(1);
    let v235_16_head = Path::from_slice(&[v235_16_byte]);
    let v236_2: Space = singleton(&(v235_16_head));
    let v236_3: Space = intersect(&(*CONSTANT_2),&(v236_2));
    let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
    drop(v236_3);
    let v236_5: Space = subtract(&(*CONSTANT_1),&(v236_4));
    drop(v236_4);
    let v236_8: Space = if (v236_5).is_empty() { Space::new() } else {
      let v237_6: Path = concat_path(&(*p0),&(v235_16_head));
      let mut v237_7 = Space::new();
      let mut v237_7_cursor = (v235_16_tail).read_zipper();
      for v237_7_byte in v237_7_cursor.child_mask().iter() {
        v237_7_cursor.descend_to_byte(v237_7_byte);
        let v237_7_tail = v237_7_cursor.make_map();
        v237_7_cursor.ascend(1);
        let v237_7_head = Path::from_slice(&[v237_7_byte]);
        let v238_2: Space = singleton(&(v237_7_head));
        let v238_3: Space = intersect(&(*CONSTANT_2),&(v238_2));
        let v238_4: Space = if has_head(&(v238_3)) { singleton(&[]) } else { Space::new() };
        drop(v238_3);
        let v238_5: Space = subtract(&(*CONSTANT_1),&(v238_4));
        drop(v238_4);
        let v238_8: Space = if (v238_5).is_empty() { Space::new() } else {
          let v239_6: Path = concat_path(&(v237_6),&(v237_7_head));
          let v239_7: Space = routine_34(c, &(v239_6), &(*p1), &(v237_7_tail), &(*s1));
          compose(&(v238_5),&(v239_7))
        };
        drop(v238_5);
        let v238_9: Space = intersect(&(*CONSTANT_2),&(v238_2));
        drop(v238_2);
        let v238_10: Space = if has_head(&(v238_9)) { singleton(&[]) } else { Space::new() };
        drop(v238_9);
        let v238_12: Space = if (v238_10).is_empty() { Space::new() } else {
          let v240_6: Path = concat_path(&(v237_6),&(v237_7_head));
          let v240_11: Space = routine_35(c, &(v240_6), &(*p1), &(v237_7_tail), &(*s1));
          drop(v240_6);
          compose(&(v238_10),&(v240_11))
        };
        drop(v238_10);
        let v238_13: Space = unite(&(v238_8),&(v238_12));
        v237_7.join_into((v238_13).clone());
      }
      drop(v237_7_cursor);
      drop(v237_6);
      compose(&(v236_5),&(v237_7))
    };
    drop(v236_5);
    let v236_9: Space = intersect(&(*CONSTANT_2),&(v236_2));
    drop(v236_2);
    let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
    drop(v236_9);
    let v236_13: Space = if (v236_10).is_empty() { Space::new() } else {
      let v241_11: Space = unwrap(&(v235_9),&(v235_16_head));
      let mut v241_12 = Space::new();
      let mut v241_12_cursor = (v241_11).read_zipper();
      for v241_12_byte in v241_12_cursor.child_mask().iter() {
        v241_12_cursor.descend_to_byte(v241_12_byte);
        let v241_12_tail = v241_12_cursor.make_map();
        v241_12_cursor.ascend(1);
        let v241_12_head = Path::from_slice(&[v241_12_byte]);
        let v242_2: Space = singleton(&(v241_12_head));
        let v242_3: Space = intersect(&(*CONSTANT_2),&(v242_2));
        let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = subtract(&(*CONSTANT_1),&(v242_4));
        drop(v242_4);
        let v242_7: Space = if (v242_5).is_empty() { Space::new() } else {
          let v243_6: Space = routine_15(c, &(v241_12_head), &(*p1), &(v241_12_tail));
          compose(&(v242_5),&(v243_6))
        };
        drop(v242_5);
        let v242_8: Space = intersect(&(*CONSTANT_2),&(v242_2));
        drop(v242_2);
        let v242_9: Space = if has_head(&(v242_8)) { singleton(&[]) } else { Space::new() };
        drop(v242_8);
        let v242_11: Space = if (v242_9).is_empty() { Space::new() } else {
          let v244_10: Space = routine_16(c, &(v241_12_head), &(*p1), &(v241_12_tail));
          compose(&(v242_9),&(v244_10))
        };
        drop(v242_9);
        let v242_12: Space = unite(&(v242_7),&(v242_11));
        v241_12.join_into((v242_12).clone());
      }
      drop(v241_12_cursor);
      drop(v241_11);
      compose(&(v236_10),&(v241_12))
    };
    drop(v236_10);
    let v236_14: Space = unite(&(v236_8),&(v236_13));
    v235_16.join_into((v236_14).clone());
  }
  drop(v235_16_cursor);
  drop(v235_9);
  (v235_16).clone()
}

fn routine_26(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v245_12 = Space::new();
  let mut v245_12_cursor = (*s0).read_zipper();
  for v245_12_byte in v245_12_cursor.child_mask().iter() {
    v245_12_cursor.descend_to_byte(v245_12_byte);
    let v245_12_tail = v245_12_cursor.make_map();
    v245_12_cursor.ascend(1);
    let v245_12_head = Path::from_slice(&[v245_12_byte]);
    let v246_2: Space = singleton(&(v245_12_head));
    let v246_3: Space = intersect(&(*CONSTANT_2),&(v246_2));
    let v246_4: Space = if has_head(&(v246_3)) { singleton(&[]) } else { Space::new() };
    drop(v246_3);
    let v246_5: Space = subtract(&(*CONSTANT_1),&(v246_4));
    drop(v246_4);
    let v246_8: Space = if (v246_5).is_empty() { Space::new() } else {
      let v247_6: Path = concat_path(&(*p0),&(v245_12_head));
      let mut v247_7 = Space::new();
      let mut v247_7_cursor = (v245_12_tail).read_zipper();
      for v247_7_byte in v247_7_cursor.child_mask().iter() {
        v247_7_cursor.descend_to_byte(v247_7_byte);
        let v247_7_tail = v247_7_cursor.make_map();
        v247_7_cursor.ascend(1);
        let v247_7_head = Path::from_slice(&[v247_7_byte]);
        let v248_2: Space = singleton(&(v247_7_head));
        let v248_3: Space = intersect(&(*CONSTANT_2),&(v248_2));
        let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
        drop(v248_3);
        let v248_5: Space = subtract(&(*CONSTANT_1),&(v248_4));
        drop(v248_4);
        let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
          let v249_6: Path = concat_path(&(v247_6),&(v247_7_head));
          let v249_7: Space = routine_36(c, &(v249_6), &(*p1), &(v247_7_tail));
          compose(&(v248_5),&(v249_7))
        };
        drop(v248_5);
        let v248_9: Space = intersect(&(*CONSTANT_2),&(v248_2));
        drop(v248_2);
        let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
        drop(v248_9);
        let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
          let v250_6: Path = concat_path(&(v247_6),&(v247_7_head));
          let v250_11: Space = routine_37(c, &(v250_6), &(*p1), &(v247_7_tail));
          drop(v250_6);
          compose(&(v248_10),&(v250_11))
        };
        drop(v248_10);
        let v248_13: Space = unite(&(v248_8),&(v248_12));
        v247_7.join_into((v248_13).clone());
      }
      drop(v247_7_cursor);
      compose(&(v246_5),&(v247_7))
    };
    drop(v246_5);
    let v246_9: Space = intersect(&(*CONSTANT_2),&(v246_2));
    drop(v246_2);
    let v246_10: Space = if has_head(&(v246_9)) { singleton(&[]) } else { Space::new() };
    drop(v246_9);
    let v246_12: Space = if (v246_10).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&(v245_12_head));
      let mut v251_11 = Space::new();
      let mut v251_11_cursor = (v245_12_tail).read_zipper();
      for v251_11_byte in v251_11_cursor.child_mask().iter() {
        v251_11_cursor.descend_to_byte(v251_11_byte);
        let v251_11_tail = v251_11_cursor.make_map();
        v251_11_cursor.ascend(1);
        let v251_11_head = Path::from_slice(&[v251_11_byte]);
        let v252_2: Space = singleton(&(v251_11_head));
        let v252_3: Space = intersect(&(*CONSTANT_2),&(v252_2));
        let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = subtract(&(*CONSTANT_1),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (v252_5).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&(v251_11_head));
          let v253_7: Space = routine_36(c, &(v253_6), &(*p1), &(v251_11_tail));
          compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = intersect(&(*CONSTANT_2),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_12: Space = if (v252_10).is_empty() { Space::new() } else {
          let v254_6: Path = concat_path(&(v251_6),&(v251_11_head));
          let v254_11: Space = routine_21(c, &(v254_6), &(*p1), &(v251_11_tail));
          drop(v254_6);
          compose(&(v252_10),&(v254_11))
        };
        drop(v252_10);
        let v252_13: Space = unite(&(v252_8),&(v252_12));
        v251_11.join_into((v252_13).clone());
      }
      drop(v251_11_cursor);
      drop(v251_6);
      compose(&(v246_10),&(v251_11))
    };
    drop(v246_10);
    let v246_13: Space = unite(&(v246_8),&(v246_12));
    v245_12.join_into((v246_13).clone());
  }
  drop(v245_12_cursor);
  (v245_12).clone()
}

fn routine_27(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v255_9 = Space::new();
  let mut v255_9_cursor = (*s0).read_zipper();
  for v255_9_byte in v255_9_cursor.child_mask().iter() {
    v255_9_cursor.descend_to_byte(v255_9_byte);
    let v255_9_tail = v255_9_cursor.make_map();
    v255_9_cursor.ascend(1);
    let v255_9_head = Path::from_slice(&[v255_9_byte]);
    let v256_2: Space = singleton(&(v255_9_head));
    let v256_3: Space = intersect(&(*CONSTANT_2),&(v256_2));
    let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
    drop(v256_3);
    let v256_5: Space = subtract(&(*CONSTANT_1),&(v256_4));
    drop(v256_4);
    let v256_8: Space = if (v256_5).is_empty() { Space::new() } else {
      let v257_6: Path = concat_path(&(*p0),&(v255_9_head));
      let mut v257_7 = Space::new();
      let mut v257_7_cursor = (v255_9_tail).read_zipper();
      for v257_7_byte in v257_7_cursor.child_mask().iter() {
        v257_7_cursor.descend_to_byte(v257_7_byte);
        let v257_7_tail = v257_7_cursor.make_map();
        v257_7_cursor.ascend(1);
        let v257_7_head = Path::from_slice(&[v257_7_byte]);
        let v258_2: Space = singleton(&(v257_7_head));
        let v258_3: Space = intersect(&(*CONSTANT_2),&(v258_2));
        let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
        drop(v258_3);
        let v258_5: Space = subtract(&(*CONSTANT_1),&(v258_4));
        drop(v258_4);
        let v258_8: Space = if (v258_5).is_empty() { Space::new() } else {
          let v259_6: Path = concat_path(&(v257_6),&(v257_7_head));
          let v259_7: Space = routine_36(c, &(v259_6), &(*p1), &(v257_7_tail));
          compose(&(v258_5),&(v259_7))
        };
        drop(v258_5);
        let v258_9: Space = intersect(&(*CONSTANT_2),&(v258_2));
        drop(v258_2);
        let v258_10: Space = if has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
        drop(v258_9);
        let v258_12: Space = if (v258_10).is_empty() { Space::new() } else {
          let v260_6: Path = concat_path(&(v257_6),&(v257_7_head));
          let v260_11: Space = routine_37(c, &(v260_6), &(*p1), &(v257_7_tail));
          drop(v260_6);
          compose(&(v258_10),&(v260_11))
        };
        drop(v258_10);
        let v258_13: Space = unite(&(v258_8),&(v258_12));
        v257_7.join_into((v258_13).clone());
      }
      drop(v257_7_cursor);
      compose(&(v256_5),&(v257_7))
    };
    drop(v256_5);
    let v256_9: Space = intersect(&(*CONSTANT_2),&(v256_2));
    drop(v256_2);
    let v256_10: Space = if has_head(&(v256_9)) { singleton(&[]) } else { Space::new() };
    drop(v256_9);
    let v256_11: Space = compose(&(v256_10),&(v255_9_tail));
    drop(v256_10);
    let v261_6: Path = concat_path(&(*p0),&(v255_9_head));
    let v256_12: Space = wrap(&(v256_11),&(v261_6));
    drop(v256_11);
    let v256_13: Space = wrap(&(v256_12),&(*p1));
    drop(v256_12);
    let v256_14: Space = unite(&(v256_8),&(v256_13));
    drop(v256_13);
    v255_9.join_into((v256_14).clone());
  }
  drop(v255_9_cursor);
  (v255_9).clone()
}

fn routine_28(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v262_13 = Space::new();
  let mut v262_13_cursor = (*s0).read_zipper();
  for v262_13_byte in v262_13_cursor.child_mask().iter() {
    v262_13_cursor.descend_to_byte(v262_13_byte);
    let v262_13_tail = v262_13_cursor.make_map();
    v262_13_cursor.ascend(1);
    let v262_13_head = Path::from_slice(&[v262_13_byte]);
    let v263_2: Space = singleton(&(v262_13_head));
    let v263_3: Space = intersect(&(*CONSTANT_2),&(v263_2));
    let v263_4: Space = if has_head(&(v263_3)) { singleton(&[]) } else { Space::new() };
    drop(v263_3);
    let v263_5: Space = subtract(&(*CONSTANT_1),&(v263_4));
    drop(v263_4);
    let v263_8: Space = if (v263_5).is_empty() { Space::new() } else {
      let v264_6: Path = concat_path(&(*p0),&(v262_13_head));
      let mut v264_7 = Space::new();
      let mut v264_7_cursor = (v262_13_tail).read_zipper();
      for v264_7_byte in v264_7_cursor.child_mask().iter() {
        v264_7_cursor.descend_to_byte(v264_7_byte);
        let v264_7_tail = v264_7_cursor.make_map();
        v264_7_cursor.ascend(1);
        let v264_7_head = Path::from_slice(&[v264_7_byte]);
        let v265_2: Space = singleton(&(v264_7_head));
        let v265_3: Space = intersect(&(*CONSTANT_2),&(v265_2));
        let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
        drop(v265_3);
        let v265_5: Space = subtract(&(*CONSTANT_1),&(v265_4));
        drop(v265_4);
        let v265_8: Space = if (v265_5).is_empty() { Space::new() } else {
          let v266_6: Path = concat_path(&(v264_6),&(v264_7_head));
          let v266_7: Space = routine_38(c, &(v266_6), &(*p1), &(v264_7_tail), &(*s1));
          compose(&(v265_5),&(v266_7))
        };
        drop(v265_5);
        let v265_9: Space = intersect(&(*CONSTANT_2),&(v265_2));
        drop(v265_2);
        let v265_10: Space = if has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
        drop(v265_9);
        let v265_12: Space = if (v265_10).is_empty() { Space::new() } else {
          let v267_6: Path = concat_path(&(v264_6),&(v264_7_head));
          let v267_11: Space = routine_39(c, &(v267_6), &(*p1), &(v264_7_tail), &(*s1));
          drop(v267_6);
          compose(&(v265_10),&(v267_11))
        };
        drop(v265_10);
        let v265_13: Space = unite(&(v265_8),&(v265_12));
        v264_7.join_into((v265_13).clone());
      }
      drop(v264_7_cursor);
      compose(&(v263_5),&(v264_7))
    };
    drop(v263_5);
    let v263_9: Space = intersect(&(*CONSTANT_2),&(v263_2));
    drop(v263_2);
    let v263_10: Space = if has_head(&(v263_9)) { singleton(&[]) } else { Space::new() };
    drop(v263_9);
    let v263_12: Space = if (v263_10).is_empty() { Space::new() } else {
      let v268_6: Path = concat_path(&(*p0),&(v262_13_head));
      let mut v268_11 = Space::new();
      let mut v268_11_cursor = (v262_13_tail).read_zipper();
      for v268_11_byte in v268_11_cursor.child_mask().iter() {
        v268_11_cursor.descend_to_byte(v268_11_byte);
        let v268_11_tail = v268_11_cursor.make_map();
        v268_11_cursor.ascend(1);
        let v268_11_head = Path::from_slice(&[v268_11_byte]);
        let v269_2: Space = singleton(&(v268_11_head));
        let v269_3: Space = intersect(&(*CONSTANT_2),&(v269_2));
        let v269_4: Space = if has_head(&(v269_3)) { singleton(&[]) } else { Space::new() };
        drop(v269_3);
        let v269_5: Space = subtract(&(*CONSTANT_1),&(v269_4));
        drop(v269_4);
        let v269_8: Space = if (v269_5).is_empty() { Space::new() } else {
          let v270_6: Path = concat_path(&(v268_6),&(v268_11_head));
          let v270_7: Space = routine_38(c, &(v270_6), &(*p1), &(v268_11_tail), &(*s1));
          compose(&(v269_5),&(v270_7))
        };
        drop(v269_5);
        let v269_9: Space = intersect(&(*CONSTANT_2),&(v269_2));
        drop(v269_2);
        let v269_10: Space = if has_head(&(v269_9)) { singleton(&[]) } else { Space::new() };
        drop(v269_9);
        let v269_12: Space = if (v269_10).is_empty() { Space::new() } else {
          let v271_6: Path = concat_path(&(v268_6),&(v268_11_head));
          let v271_11: Space = routine_10(c, &(v271_6), &(*p1), &(v268_11_tail), &(*s1));
          drop(v271_6);
          compose(&(v269_10),&(v271_11))
        };
        drop(v269_10);
        let v269_13: Space = unite(&(v269_8),&(v269_12));
        v268_11.join_into((v269_13).clone());
      }
      drop(v268_11_cursor);
      drop(v268_6);
      compose(&(v263_10),&(v268_11))
    };
    drop(v263_10);
    let v263_13: Space = unite(&(v263_8),&(v263_12));
    v262_13.join_into((v263_13).clone());
  }
  drop(v262_13_cursor);
  (v262_13).clone()
}

fn routine_29(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v272_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v272_9: Space = unwrap(&(v272_8),&(*p0));
  drop(v272_8);
  let mut v272_16 = Space::new();
  let mut v272_16_cursor = (*s0).read_zipper();
  for v272_16_byte in v272_16_cursor.child_mask().iter() {
    v272_16_cursor.descend_to_byte(v272_16_byte);
    let v272_16_tail = v272_16_cursor.make_map();
    v272_16_cursor.ascend(1);
    let v272_16_head = Path::from_slice(&[v272_16_byte]);
    let v273_2: Space = singleton(&(v272_16_head));
    let v273_3: Space = intersect(&(*CONSTANT_2),&(v273_2));
    let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
    drop(v273_3);
    let v273_5: Space = subtract(&(*CONSTANT_1),&(v273_4));
    drop(v273_4);
    let v273_8: Space = if (v273_5).is_empty() { Space::new() } else {
      let v274_6: Path = concat_path(&(*p0),&(v272_16_head));
      let mut v274_7 = Space::new();
      let mut v274_7_cursor = (v272_16_tail).read_zipper();
      for v274_7_byte in v274_7_cursor.child_mask().iter() {
        v274_7_cursor.descend_to_byte(v274_7_byte);
        let v274_7_tail = v274_7_cursor.make_map();
        v274_7_cursor.ascend(1);
        let v274_7_head = Path::from_slice(&[v274_7_byte]);
        let v275_2: Space = singleton(&(v274_7_head));
        let v275_3: Space = intersect(&(*CONSTANT_2),&(v275_2));
        let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
        drop(v275_3);
        let v275_5: Space = subtract(&(*CONSTANT_1),&(v275_4));
        drop(v275_4);
        let v275_8: Space = if (v275_5).is_empty() { Space::new() } else {
          let v276_6: Path = concat_path(&(v274_6),&(v274_7_head));
          let v276_7: Space = routine_38(c, &(v276_6), &(*p1), &(v274_7_tail), &(*s1));
          compose(&(v275_5),&(v276_7))
        };
        drop(v275_5);
        let v275_9: Space = intersect(&(*CONSTANT_2),&(v275_2));
        drop(v275_2);
        let v275_10: Space = if has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
        drop(v275_9);
        let v275_12: Space = if (v275_10).is_empty() { Space::new() } else {
          let v277_6: Path = concat_path(&(v274_6),&(v274_7_head));
          let v277_11: Space = routine_39(c, &(v277_6), &(*p1), &(v274_7_tail), &(*s1));
          drop(v277_6);
          compose(&(v275_10),&(v277_11))
        };
        drop(v275_10);
        let v275_13: Space = unite(&(v275_8),&(v275_12));
        v274_7.join_into((v275_13).clone());
      }
      drop(v274_7_cursor);
      drop(v274_6);
      compose(&(v273_5),&(v274_7))
    };
    drop(v273_5);
    let v273_9: Space = intersect(&(*CONSTANT_2),&(v273_2));
    drop(v273_2);
    let v273_10: Space = if has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
    drop(v273_9);
    let v273_13: Space = if (v273_10).is_empty() { Space::new() } else {
      let v278_11: Space = unwrap(&(v272_9),&(v272_16_head));
      let mut v278_12 = Space::new();
      let mut v278_12_cursor = (v278_11).read_zipper();
      for v278_12_byte in v278_12_cursor.child_mask().iter() {
        v278_12_cursor.descend_to_byte(v278_12_byte);
        let v278_12_tail = v278_12_cursor.make_map();
        v278_12_cursor.ascend(1);
        let v278_12_head = Path::from_slice(&[v278_12_byte]);
        let v279_2: Space = singleton(&(v278_12_head));
        let v279_3: Space = intersect(&(*CONSTANT_2),&(v279_2));
        let v279_4: Space = if has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
        drop(v279_3);
        let v279_5: Space = subtract(&(*CONSTANT_1),&(v279_4));
        drop(v279_4);
        let v279_7: Space = if (v279_5).is_empty() { Space::new() } else {
          let v280_6: Space = routine_15(c, &(v278_12_head), &(*p1), &(v278_12_tail));
          compose(&(v279_5),&(v280_6))
        };
        drop(v279_5);
        let v279_8: Space = intersect(&(*CONSTANT_2),&(v279_2));
        drop(v279_2);
        let v279_9: Space = if has_head(&(v279_8)) { singleton(&[]) } else { Space::new() };
        drop(v279_8);
        let v279_11: Space = if (v279_9).is_empty() { Space::new() } else {
          let v281_10: Space = routine_16(c, &(v278_12_head), &(*p1), &(v278_12_tail));
          compose(&(v279_9),&(v281_10))
        };
        drop(v279_9);
        let v279_12: Space = unite(&(v279_7),&(v279_11));
        v278_12.join_into((v279_12).clone());
      }
      drop(v278_12_cursor);
      drop(v278_11);
      compose(&(v273_10),&(v278_12))
    };
    drop(v273_10);
    let v273_14: Space = unite(&(v273_8),&(v273_13));
    v272_16.join_into((v273_14).clone());
  }
  drop(v272_16_cursor);
  drop(v272_9);
  (v272_16).clone()
}

fn routine_30(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v282_12 = Space::new();
  let mut v282_12_cursor = (*s0).read_zipper();
  for v282_12_byte in v282_12_cursor.child_mask().iter() {
    v282_12_cursor.descend_to_byte(v282_12_byte);
    let v282_12_tail = v282_12_cursor.make_map();
    v282_12_cursor.ascend(1);
    let v282_12_head = Path::from_slice(&[v282_12_byte]);
    let v283_2: Space = singleton(&(v282_12_head));
    let v283_3: Space = intersect(&(*CONSTANT_2),&(v283_2));
    let v283_4: Space = if has_head(&(v283_3)) { singleton(&[]) } else { Space::new() };
    drop(v283_3);
    let v283_5: Space = subtract(&(*CONSTANT_1),&(v283_4));
    drop(v283_4);
    let v283_8: Space = if (v283_5).is_empty() { Space::new() } else {
      let v284_6: Path = concat_path(&(*p0),&(v282_12_head));
      let mut v284_7 = Space::new();
      let mut v284_7_cursor = (v282_12_tail).read_zipper();
      for v284_7_byte in v284_7_cursor.child_mask().iter() {
        v284_7_cursor.descend_to_byte(v284_7_byte);
        let v284_7_tail = v284_7_cursor.make_map();
        v284_7_cursor.ascend(1);
        let v284_7_head = Path::from_slice(&[v284_7_byte]);
        let v285_2: Space = singleton(&(v284_7_head));
        let v285_3: Space = intersect(&(*CONSTANT_2),&(v285_2));
        let v285_4: Space = if has_head(&(v285_3)) { singleton(&[]) } else { Space::new() };
        drop(v285_3);
        let v285_5: Space = subtract(&(*CONSTANT_1),&(v285_4));
        drop(v285_4);
        let v285_8: Space = if (v285_5).is_empty() { Space::new() } else {
          let v286_6: Path = concat_path(&(v284_6),&(v284_7_head));
          let v286_7: Space = routine_40(c, &(v286_6), &(*p1), &(v284_7_tail));
          compose(&(v285_5),&(v286_7))
        };
        drop(v285_5);
        let v285_9: Space = intersect(&(*CONSTANT_2),&(v285_2));
        drop(v285_2);
        let v285_10: Space = if has_head(&(v285_9)) { singleton(&[]) } else { Space::new() };
        drop(v285_9);
        let v285_12: Space = if (v285_10).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v284_6),&(v284_7_head));
          let v287_11: Space = routine_41(c, &(v287_6), &(*p1), &(v284_7_tail));
          drop(v287_6);
          compose(&(v285_10),&(v287_11))
        };
        drop(v285_10);
        let v285_13: Space = unite(&(v285_8),&(v285_12));
        v284_7.join_into((v285_13).clone());
      }
      drop(v284_7_cursor);
      compose(&(v283_5),&(v284_7))
    };
    drop(v283_5);
    let v283_9: Space = intersect(&(*CONSTANT_2),&(v283_2));
    drop(v283_2);
    let v283_10: Space = if has_head(&(v283_9)) { singleton(&[]) } else { Space::new() };
    drop(v283_9);
    let v283_12: Space = if (v283_10).is_empty() { Space::new() } else {
      let v288_6: Path = concat_path(&(*p0),&(v282_12_head));
      let mut v288_11 = Space::new();
      let mut v288_11_cursor = (v282_12_tail).read_zipper();
      for v288_11_byte in v288_11_cursor.child_mask().iter() {
        v288_11_cursor.descend_to_byte(v288_11_byte);
        let v288_11_tail = v288_11_cursor.make_map();
        v288_11_cursor.ascend(1);
        let v288_11_head = Path::from_slice(&[v288_11_byte]);
        let v289_2: Space = singleton(&(v288_11_head));
        let v289_3: Space = intersect(&(*CONSTANT_2),&(v289_2));
        let v289_4: Space = if has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
        drop(v289_3);
        let v289_5: Space = subtract(&(*CONSTANT_1),&(v289_4));
        drop(v289_4);
        let v289_8: Space = if (v289_5).is_empty() { Space::new() } else {
          let v290_6: Path = concat_path(&(v288_6),&(v288_11_head));
          let v290_7: Space = routine_40(c, &(v290_6), &(*p1), &(v288_11_tail));
          compose(&(v289_5),&(v290_7))
        };
        drop(v289_5);
        let v289_9: Space = intersect(&(*CONSTANT_2),&(v289_2));
        drop(v289_2);
        let v289_10: Space = if has_head(&(v289_9)) { singleton(&[]) } else { Space::new() };
        drop(v289_9);
        let v289_12: Space = if (v289_10).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v288_6),&(v288_11_head));
          let v291_11: Space = routine_21(c, &(v291_6), &(*p1), &(v288_11_tail));
          drop(v291_6);
          compose(&(v289_10),&(v291_11))
        };
        drop(v289_10);
        let v289_13: Space = unite(&(v289_8),&(v289_12));
        v288_11.join_into((v289_13).clone());
      }
      drop(v288_11_cursor);
      drop(v288_6);
      compose(&(v283_10),&(v288_11))
    };
    drop(v283_10);
    let v283_13: Space = unite(&(v283_8),&(v283_12));
    v282_12.join_into((v283_13).clone());
  }
  drop(v282_12_cursor);
  (v282_12).clone()
}

fn routine_31(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v292_9 = Space::new();
  let mut v292_9_cursor = (*s0).read_zipper();
  for v292_9_byte in v292_9_cursor.child_mask().iter() {
    v292_9_cursor.descend_to_byte(v292_9_byte);
    let v292_9_tail = v292_9_cursor.make_map();
    v292_9_cursor.ascend(1);
    let v292_9_head = Path::from_slice(&[v292_9_byte]);
    let v293_2: Space = singleton(&(v292_9_head));
    let v293_3: Space = intersect(&(*CONSTANT_2),&(v293_2));
    let v293_4: Space = if has_head(&(v293_3)) { singleton(&[]) } else { Space::new() };
    drop(v293_3);
    let v293_5: Space = subtract(&(*CONSTANT_1),&(v293_4));
    drop(v293_4);
    let v293_8: Space = if (v293_5).is_empty() { Space::new() } else {
      let v294_6: Path = concat_path(&(*p0),&(v292_9_head));
      let mut v294_7 = Space::new();
      let mut v294_7_cursor = (v292_9_tail).read_zipper();
      for v294_7_byte in v294_7_cursor.child_mask().iter() {
        v294_7_cursor.descend_to_byte(v294_7_byte);
        let v294_7_tail = v294_7_cursor.make_map();
        v294_7_cursor.ascend(1);
        let v294_7_head = Path::from_slice(&[v294_7_byte]);
        let v295_2: Space = singleton(&(v294_7_head));
        let v295_3: Space = intersect(&(*CONSTANT_2),&(v295_2));
        let v295_4: Space = if has_head(&(v295_3)) { singleton(&[]) } else { Space::new() };
        drop(v295_3);
        let v295_5: Space = subtract(&(*CONSTANT_1),&(v295_4));
        drop(v295_4);
        let v295_8: Space = if (v295_5).is_empty() { Space::new() } else {
          let v296_6: Path = concat_path(&(v294_6),&(v294_7_head));
          let v296_7: Space = routine_40(c, &(v296_6), &(*p1), &(v294_7_tail));
          compose(&(v295_5),&(v296_7))
        };
        drop(v295_5);
        let v295_9: Space = intersect(&(*CONSTANT_2),&(v295_2));
        drop(v295_2);
        let v295_10: Space = if has_head(&(v295_9)) { singleton(&[]) } else { Space::new() };
        drop(v295_9);
        let v295_12: Space = if (v295_10).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v294_6),&(v294_7_head));
          let v297_11: Space = routine_41(c, &(v297_6), &(*p1), &(v294_7_tail));
          drop(v297_6);
          compose(&(v295_10),&(v297_11))
        };
        drop(v295_10);
        let v295_13: Space = unite(&(v295_8),&(v295_12));
        v294_7.join_into((v295_13).clone());
      }
      drop(v294_7_cursor);
      compose(&(v293_5),&(v294_7))
    };
    drop(v293_5);
    let v293_9: Space = intersect(&(*CONSTANT_2),&(v293_2));
    drop(v293_2);
    let v293_10: Space = if has_head(&(v293_9)) { singleton(&[]) } else { Space::new() };
    drop(v293_9);
    let v293_11: Space = compose(&(v293_10),&(v292_9_tail));
    drop(v293_10);
    let v298_6: Path = concat_path(&(*p0),&(v292_9_head));
    let v293_12: Space = wrap(&(v293_11),&(v298_6));
    drop(v293_11);
    let v293_13: Space = wrap(&(v293_12),&(*p1));
    drop(v293_12);
    let v293_14: Space = unite(&(v293_8),&(v293_13));
    drop(v293_13);
    v292_9.join_into((v293_14).clone());
  }
  drop(v292_9_cursor);
  (v292_9).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v299_3 = Space::new();
  let mut v299_3_cursor = (*s0).read_zipper();
  for v299_3_byte in v299_3_cursor.child_mask().iter() {
    v299_3_cursor.descend_to_byte(v299_3_byte);
    let v299_3_tail = v299_3_cursor.make_map();
    v299_3_cursor.ascend(1);
    let v299_3_head = Path::from_slice(&[v299_3_byte]);
    let v300_2: Space = Space::new();
    v299_3.join_into((v300_2).clone());
  }
  drop(v299_3_cursor);
  (v299_3).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v301_7 = Space::new();
  let mut v301_7_cursor = (*s0).read_zipper();
  for v301_7_byte in v301_7_cursor.child_mask().iter() {
    v301_7_cursor.descend_to_byte(v301_7_byte);
    let v301_7_tail = v301_7_cursor.make_map();
    v301_7_cursor.ascend(1);
    let v301_7_head = Path::from_slice(&[v301_7_byte]);
    let v302_2: Space = singleton(&(v301_7_head));
    let v302_3: Space = intersect(&(*CONSTANT_2),&(v302_2));
    drop(v302_2);
    let v302_4: Space = if has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
    drop(v302_3);
    let v302_7: Space = if (v302_4).is_empty() { Space::new() } else {
      let v303_5: Path = concat_path(&(*p0),&(v301_7_head));
      let mut v303_6 = Space::new();
      let mut v303_6_cursor = (v301_7_tail).read_zipper();
      for v303_6_byte in v303_6_cursor.child_mask().iter() {
        v303_6_cursor.descend_to_byte(v303_6_byte);
        let v303_6_tail = v303_6_cursor.make_map();
        v303_6_cursor.ascend(1);
        let v303_6_head = Path::from_slice(&[v303_6_byte]);
        let v304_2: Space = singleton(&(v303_6_head));
        let v304_3: Space = intersect(&(*CONSTANT_2),&(v304_2));
        let v304_4: Space = if has_head(&(v304_3)) { singleton(&[]) } else { Space::new() };
        drop(v304_3);
        let v304_5: Space = subtract(&(*CONSTANT_1),&(v304_4));
        drop(v304_4);
        let v304_7: Space = if (v304_5).is_empty() { Space::new() } else {
          let v305_6: Space = routine_6(c, &(v303_6_head), &(v303_5), &(v303_6_tail), &(*s1));
          compose(&(v304_5),&(v305_6))
        };
        drop(v304_5);
        let v304_8: Space = intersect(&(*CONSTANT_2),&(v304_2));
        drop(v304_2);
        let v304_9: Space = if has_head(&(v304_8)) { singleton(&[]) } else { Space::new() };
        drop(v304_8);
        let v304_11: Space = if (v304_9).is_empty() { Space::new() } else {
          let v306_10: Space = routine_7(c, &(v303_6_head), &(v303_5), &(v303_6_tail), &(*s1));
          compose(&(v304_9),&(v306_10))
        };
        drop(v304_9);
        let v304_12: Space = unite(&(v304_7),&(v304_11));
        v303_6.join_into((v304_12).clone());
      }
      drop(v303_6_cursor);
      drop(v303_5);
      compose(&(v302_4),&(v303_6))
    };
    drop(v302_4);
    v301_7.join_into((v302_7).clone());
  }
  drop(v301_7_cursor);
  (v301_7).clone()
}

fn routine_34(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v307_13 = Space::new();
  let mut v307_13_cursor = (*s0).read_zipper();
  for v307_13_byte in v307_13_cursor.child_mask().iter() {
    v307_13_cursor.descend_to_byte(v307_13_byte);
    let v307_13_tail = v307_13_cursor.make_map();
    v307_13_cursor.ascend(1);
    let v307_13_head = Path::from_slice(&[v307_13_byte]);
    let v308_2: Space = singleton(&(v307_13_head));
    let v308_3: Space = intersect(&(*CONSTANT_2),&(v308_2));
    let v308_4: Space = if has_head(&(v308_3)) { singleton(&[]) } else { Space::new() };
    drop(v308_3);
    let v308_5: Space = subtract(&(*CONSTANT_1),&(v308_4));
    drop(v308_4);
    let v308_8: Space = if (v308_5).is_empty() { Space::new() } else {
      let v309_6: Path = concat_path(&(*p0),&(v307_13_head));
      let mut v309_7 = Space::new();
      let mut v309_7_cursor = (v307_13_tail).read_zipper();
      for v309_7_byte in v309_7_cursor.child_mask().iter() {
        v309_7_cursor.descend_to_byte(v309_7_byte);
        let v309_7_tail = v309_7_cursor.make_map();
        v309_7_cursor.ascend(1);
        let v309_7_head = Path::from_slice(&[v309_7_byte]);
        let v310_2: Space = singleton(&(v309_7_head));
        let v310_3: Space = intersect(&(*CONSTANT_2),&(v310_2));
        let v310_4: Space = if has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
        drop(v310_3);
        let v310_5: Space = subtract(&(*CONSTANT_1),&(v310_4));
        drop(v310_4);
        let v310_8: Space = if (v310_5).is_empty() { Space::new() } else {
          let v311_6: Path = concat_path(&(v309_6),&(v309_7_head));
          let v311_7: Space = routine_42(c, &(v311_6), &(*p1), &(v309_7_tail), &(*s1));
          compose(&(v310_5),&(v311_7))
        };
        drop(v310_5);
        let v310_9: Space = intersect(&(*CONSTANT_2),&(v310_2));
        drop(v310_2);
        let v310_10: Space = if has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
        drop(v310_9);
        let v310_12: Space = if (v310_10).is_empty() { Space::new() } else {
          let v312_6: Path = concat_path(&(v309_6),&(v309_7_head));
          let v312_11: Space = routine_43(c, &(v312_6), &(*p1), &(v309_7_tail), &(*s1));
          drop(v312_6);
          compose(&(v310_10),&(v312_11))
        };
        drop(v310_10);
        let v310_13: Space = unite(&(v310_8),&(v310_12));
        v309_7.join_into((v310_13).clone());
      }
      drop(v309_7_cursor);
      compose(&(v308_5),&(v309_7))
    };
    drop(v308_5);
    let v308_9: Space = intersect(&(*CONSTANT_2),&(v308_2));
    drop(v308_2);
    let v308_10: Space = if has_head(&(v308_9)) { singleton(&[]) } else { Space::new() };
    drop(v308_9);
    let v308_12: Space = if (v308_10).is_empty() { Space::new() } else {
      let v313_6: Path = concat_path(&(*p0),&(v307_13_head));
      let mut v313_11 = Space::new();
      let mut v313_11_cursor = (v307_13_tail).read_zipper();
      for v313_11_byte in v313_11_cursor.child_mask().iter() {
        v313_11_cursor.descend_to_byte(v313_11_byte);
        let v313_11_tail = v313_11_cursor.make_map();
        v313_11_cursor.ascend(1);
        let v313_11_head = Path::from_slice(&[v313_11_byte]);
        let v314_2: Space = singleton(&(v313_11_head));
        let v314_3: Space = intersect(&(*CONSTANT_2),&(v314_2));
        let v314_4: Space = if has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
        drop(v314_3);
        let v314_5: Space = subtract(&(*CONSTANT_1),&(v314_4));
        drop(v314_4);
        let v314_8: Space = if (v314_5).is_empty() { Space::new() } else {
          let v315_6: Path = concat_path(&(v313_6),&(v313_11_head));
          let v315_7: Space = routine_42(c, &(v315_6), &(*p1), &(v313_11_tail), &(*s1));
          compose(&(v314_5),&(v315_7))
        };
        drop(v314_5);
        let v314_9: Space = intersect(&(*CONSTANT_2),&(v314_2));
        drop(v314_2);
        let v314_10: Space = if has_head(&(v314_9)) { singleton(&[]) } else { Space::new() };
        drop(v314_9);
        let v314_12: Space = if (v314_10).is_empty() { Space::new() } else {
          let v316_6: Path = concat_path(&(v313_6),&(v313_11_head));
          let v316_11: Space = routine_10(c, &(v316_6), &(*p1), &(v313_11_tail), &(*s1));
          drop(v316_6);
          compose(&(v314_10),&(v316_11))
        };
        drop(v314_10);
        let v314_13: Space = unite(&(v314_8),&(v314_12));
        v313_11.join_into((v314_13).clone());
      }
      drop(v313_11_cursor);
      drop(v313_6);
      compose(&(v308_10),&(v313_11))
    };
    drop(v308_10);
    let v308_13: Space = unite(&(v308_8),&(v308_12));
    v307_13.join_into((v308_13).clone());
  }
  drop(v307_13_cursor);
  (v307_13).clone()
}

fn routine_35(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v317_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v317_9: Space = unwrap(&(v317_8),&(*p0));
  drop(v317_8);
  let mut v317_16 = Space::new();
  let mut v317_16_cursor = (*s0).read_zipper();
  for v317_16_byte in v317_16_cursor.child_mask().iter() {
    v317_16_cursor.descend_to_byte(v317_16_byte);
    let v317_16_tail = v317_16_cursor.make_map();
    v317_16_cursor.ascend(1);
    let v317_16_head = Path::from_slice(&[v317_16_byte]);
    let v318_2: Space = singleton(&(v317_16_head));
    let v318_3: Space = intersect(&(*CONSTANT_2),&(v318_2));
    let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
    drop(v318_3);
    let v318_5: Space = subtract(&(*CONSTANT_1),&(v318_4));
    drop(v318_4);
    let v318_8: Space = if (v318_5).is_empty() { Space::new() } else {
      let v319_6: Path = concat_path(&(*p0),&(v317_16_head));
      let mut v319_7 = Space::new();
      let mut v319_7_cursor = (v317_16_tail).read_zipper();
      for v319_7_byte in v319_7_cursor.child_mask().iter() {
        v319_7_cursor.descend_to_byte(v319_7_byte);
        let v319_7_tail = v319_7_cursor.make_map();
        v319_7_cursor.ascend(1);
        let v319_7_head = Path::from_slice(&[v319_7_byte]);
        let v320_2: Space = singleton(&(v319_7_head));
        let v320_3: Space = intersect(&(*CONSTANT_2),&(v320_2));
        let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
        drop(v320_3);
        let v320_5: Space = subtract(&(*CONSTANT_1),&(v320_4));
        drop(v320_4);
        let v320_8: Space = if (v320_5).is_empty() { Space::new() } else {
          let v321_6: Path = concat_path(&(v319_6),&(v319_7_head));
          let v321_7: Space = routine_42(c, &(v321_6), &(*p1), &(v319_7_tail), &(*s1));
          compose(&(v320_5),&(v321_7))
        };
        drop(v320_5);
        let v320_9: Space = intersect(&(*CONSTANT_2),&(v320_2));
        drop(v320_2);
        let v320_10: Space = if has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
        drop(v320_9);
        let v320_12: Space = if (v320_10).is_empty() { Space::new() } else {
          let v322_6: Path = concat_path(&(v319_6),&(v319_7_head));
          let v322_11: Space = routine_43(c, &(v322_6), &(*p1), &(v319_7_tail), &(*s1));
          drop(v322_6);
          compose(&(v320_10),&(v322_11))
        };
        drop(v320_10);
        let v320_13: Space = unite(&(v320_8),&(v320_12));
        v319_7.join_into((v320_13).clone());
      }
      drop(v319_7_cursor);
      drop(v319_6);
      compose(&(v318_5),&(v319_7))
    };
    drop(v318_5);
    let v318_9: Space = intersect(&(*CONSTANT_2),&(v318_2));
    drop(v318_2);
    let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
    drop(v318_9);
    let v318_13: Space = if (v318_10).is_empty() { Space::new() } else {
      let v323_11: Space = unwrap(&(v317_9),&(v317_16_head));
      let mut v323_12 = Space::new();
      let mut v323_12_cursor = (v323_11).read_zipper();
      for v323_12_byte in v323_12_cursor.child_mask().iter() {
        v323_12_cursor.descend_to_byte(v323_12_byte);
        let v323_12_tail = v323_12_cursor.make_map();
        v323_12_cursor.ascend(1);
        let v323_12_head = Path::from_slice(&[v323_12_byte]);
        let v324_2: Space = singleton(&(v323_12_head));
        let v324_3: Space = intersect(&(*CONSTANT_2),&(v324_2));
        let v324_4: Space = if has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
        drop(v324_3);
        let v324_5: Space = subtract(&(*CONSTANT_1),&(v324_4));
        drop(v324_4);
        let v324_7: Space = if (v324_5).is_empty() { Space::new() } else {
          let v325_6: Space = routine_15(c, &(v323_12_head), &(*p1), &(v323_12_tail));
          compose(&(v324_5),&(v325_6))
        };
        drop(v324_5);
        let v324_8: Space = intersect(&(*CONSTANT_2),&(v324_2));
        drop(v324_2);
        let v324_9: Space = if has_head(&(v324_8)) { singleton(&[]) } else { Space::new() };
        drop(v324_8);
        let v324_11: Space = if (v324_9).is_empty() { Space::new() } else {
          let v326_10: Space = routine_16(c, &(v323_12_head), &(*p1), &(v323_12_tail));
          compose(&(v324_9),&(v326_10))
        };
        drop(v324_9);
        let v324_12: Space = unite(&(v324_7),&(v324_11));
        v323_12.join_into((v324_12).clone());
      }
      drop(v323_12_cursor);
      drop(v323_11);
      compose(&(v318_10),&(v323_12))
    };
    drop(v318_10);
    let v318_14: Space = unite(&(v318_8),&(v318_13));
    v317_16.join_into((v318_14).clone());
  }
  drop(v317_16_cursor);
  drop(v317_9);
  (v317_16).clone()
}

fn routine_36(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v327_12 = Space::new();
  let mut v327_12_cursor = (*s0).read_zipper();
  for v327_12_byte in v327_12_cursor.child_mask().iter() {
    v327_12_cursor.descend_to_byte(v327_12_byte);
    let v327_12_tail = v327_12_cursor.make_map();
    v327_12_cursor.ascend(1);
    let v327_12_head = Path::from_slice(&[v327_12_byte]);
    let v328_2: Space = singleton(&(v327_12_head));
    let v328_3: Space = intersect(&(*CONSTANT_2),&(v328_2));
    let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
    drop(v328_3);
    let v328_5: Space = subtract(&(*CONSTANT_1),&(v328_4));
    drop(v328_4);
    let v328_8: Space = if (v328_5).is_empty() { Space::new() } else {
      let v329_6: Path = concat_path(&(*p0),&(v327_12_head));
      let mut v329_7 = Space::new();
      let mut v329_7_cursor = (v327_12_tail).read_zipper();
      for v329_7_byte in v329_7_cursor.child_mask().iter() {
        v329_7_cursor.descend_to_byte(v329_7_byte);
        let v329_7_tail = v329_7_cursor.make_map();
        v329_7_cursor.ascend(1);
        let v329_7_head = Path::from_slice(&[v329_7_byte]);
        let v330_2: Space = singleton(&(v329_7_head));
        let v330_3: Space = intersect(&(*CONSTANT_2),&(v330_2));
        let v330_4: Space = if has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
        drop(v330_3);
        let v330_5: Space = subtract(&(*CONSTANT_1),&(v330_4));
        drop(v330_4);
        let v330_8: Space = if (v330_5).is_empty() { Space::new() } else {
          let v331_6: Path = concat_path(&(v329_6),&(v329_7_head));
          let v331_7: Space = routine_44(c, &(v331_6), &(*p1), &(v329_7_tail));
          compose(&(v330_5),&(v331_7))
        };
        drop(v330_5);
        let v330_9: Space = intersect(&(*CONSTANT_2),&(v330_2));
        drop(v330_2);
        let v330_10: Space = if has_head(&(v330_9)) { singleton(&[]) } else { Space::new() };
        drop(v330_9);
        let v330_12: Space = if (v330_10).is_empty() { Space::new() } else {
          let v332_6: Path = concat_path(&(v329_6),&(v329_7_head));
          let v332_11: Space = routine_45(c, &(v332_6), &(*p1), &(v329_7_tail));
          drop(v332_6);
          compose(&(v330_10),&(v332_11))
        };
        drop(v330_10);
        let v330_13: Space = unite(&(v330_8),&(v330_12));
        v329_7.join_into((v330_13).clone());
      }
      drop(v329_7_cursor);
      compose(&(v328_5),&(v329_7))
    };
    drop(v328_5);
    let v328_9: Space = intersect(&(*CONSTANT_2),&(v328_2));
    drop(v328_2);
    let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
    drop(v328_9);
    let v328_12: Space = if (v328_10).is_empty() { Space::new() } else {
      let v333_6: Path = concat_path(&(*p0),&(v327_12_head));
      let mut v333_11 = Space::new();
      let mut v333_11_cursor = (v327_12_tail).read_zipper();
      for v333_11_byte in v333_11_cursor.child_mask().iter() {
        v333_11_cursor.descend_to_byte(v333_11_byte);
        let v333_11_tail = v333_11_cursor.make_map();
        v333_11_cursor.ascend(1);
        let v333_11_head = Path::from_slice(&[v333_11_byte]);
        let v334_2: Space = singleton(&(v333_11_head));
        let v334_3: Space = intersect(&(*CONSTANT_2),&(v334_2));
        let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
        drop(v334_3);
        let v334_5: Space = subtract(&(*CONSTANT_1),&(v334_4));
        drop(v334_4);
        let v334_8: Space = if (v334_5).is_empty() { Space::new() } else {
          let v335_6: Path = concat_path(&(v333_6),&(v333_11_head));
          let v335_7: Space = routine_44(c, &(v335_6), &(*p1), &(v333_11_tail));
          compose(&(v334_5),&(v335_7))
        };
        drop(v334_5);
        let v334_9: Space = intersect(&(*CONSTANT_2),&(v334_2));
        drop(v334_2);
        let v334_10: Space = if has_head(&(v334_9)) { singleton(&[]) } else { Space::new() };
        drop(v334_9);
        let v334_12: Space = if (v334_10).is_empty() { Space::new() } else {
          let v336_6: Path = concat_path(&(v333_6),&(v333_11_head));
          let v336_11: Space = routine_21(c, &(v336_6), &(*p1), &(v333_11_tail));
          drop(v336_6);
          compose(&(v334_10),&(v336_11))
        };
        drop(v334_10);
        let v334_13: Space = unite(&(v334_8),&(v334_12));
        v333_11.join_into((v334_13).clone());
      }
      drop(v333_11_cursor);
      drop(v333_6);
      compose(&(v328_10),&(v333_11))
    };
    drop(v328_10);
    let v328_13: Space = unite(&(v328_8),&(v328_12));
    v327_12.join_into((v328_13).clone());
  }
  drop(v327_12_cursor);
  (v327_12).clone()
}

fn routine_37(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v337_9 = Space::new();
  let mut v337_9_cursor = (*s0).read_zipper();
  for v337_9_byte in v337_9_cursor.child_mask().iter() {
    v337_9_cursor.descend_to_byte(v337_9_byte);
    let v337_9_tail = v337_9_cursor.make_map();
    v337_9_cursor.ascend(1);
    let v337_9_head = Path::from_slice(&[v337_9_byte]);
    let v338_2: Space = singleton(&(v337_9_head));
    let v338_3: Space = intersect(&(*CONSTANT_2),&(v338_2));
    let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
    drop(v338_3);
    let v338_5: Space = subtract(&(*CONSTANT_1),&(v338_4));
    drop(v338_4);
    let v338_8: Space = if (v338_5).is_empty() { Space::new() } else {
      let v339_6: Path = concat_path(&(*p0),&(v337_9_head));
      let mut v339_7 = Space::new();
      let mut v339_7_cursor = (v337_9_tail).read_zipper();
      for v339_7_byte in v339_7_cursor.child_mask().iter() {
        v339_7_cursor.descend_to_byte(v339_7_byte);
        let v339_7_tail = v339_7_cursor.make_map();
        v339_7_cursor.ascend(1);
        let v339_7_head = Path::from_slice(&[v339_7_byte]);
        let v340_2: Space = singleton(&(v339_7_head));
        let v340_3: Space = intersect(&(*CONSTANT_2),&(v340_2));
        let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
        drop(v340_3);
        let v340_5: Space = subtract(&(*CONSTANT_1),&(v340_4));
        drop(v340_4);
        let v340_8: Space = if (v340_5).is_empty() { Space::new() } else {
          let v341_6: Path = concat_path(&(v339_6),&(v339_7_head));
          let v341_7: Space = routine_44(c, &(v341_6), &(*p1), &(v339_7_tail));
          compose(&(v340_5),&(v341_7))
        };
        drop(v340_5);
        let v340_9: Space = intersect(&(*CONSTANT_2),&(v340_2));
        drop(v340_2);
        let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
        drop(v340_9);
        let v340_12: Space = if (v340_10).is_empty() { Space::new() } else {
          let v342_6: Path = concat_path(&(v339_6),&(v339_7_head));
          let v342_11: Space = routine_45(c, &(v342_6), &(*p1), &(v339_7_tail));
          drop(v342_6);
          compose(&(v340_10),&(v342_11))
        };
        drop(v340_10);
        let v340_13: Space = unite(&(v340_8),&(v340_12));
        v339_7.join_into((v340_13).clone());
      }
      drop(v339_7_cursor);
      compose(&(v338_5),&(v339_7))
    };
    drop(v338_5);
    let v338_9: Space = intersect(&(*CONSTANT_2),&(v338_2));
    drop(v338_2);
    let v338_10: Space = if has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
    drop(v338_9);
    let v338_11: Space = compose(&(v338_10),&(v337_9_tail));
    drop(v338_10);
    let v343_6: Path = concat_path(&(*p0),&(v337_9_head));
    let v338_12: Space = wrap(&(v338_11),&(v343_6));
    drop(v338_11);
    let v338_13: Space = wrap(&(v338_12),&(*p1));
    drop(v338_12);
    let v338_14: Space = unite(&(v338_8),&(v338_13));
    drop(v338_13);
    v337_9.join_into((v338_14).clone());
  }
  drop(v337_9_cursor);
  (v337_9).clone()
}

fn routine_38(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v344_13 = Space::new();
  let mut v344_13_cursor = (*s0).read_zipper();
  for v344_13_byte in v344_13_cursor.child_mask().iter() {
    v344_13_cursor.descend_to_byte(v344_13_byte);
    let v344_13_tail = v344_13_cursor.make_map();
    v344_13_cursor.ascend(1);
    let v344_13_head = Path::from_slice(&[v344_13_byte]);
    let v345_2: Space = singleton(&(v344_13_head));
    let v345_3: Space = intersect(&(*CONSTANT_2),&(v345_2));
    let v345_4: Space = if has_head(&(v345_3)) { singleton(&[]) } else { Space::new() };
    drop(v345_3);
    let v345_5: Space = subtract(&(*CONSTANT_1),&(v345_4));
    drop(v345_4);
    let v345_8: Space = if (v345_5).is_empty() { Space::new() } else {
      let v346_6: Path = concat_path(&(*p0),&(v344_13_head));
      let mut v346_7 = Space::new();
      let mut v346_7_cursor = (v344_13_tail).read_zipper();
      for v346_7_byte in v346_7_cursor.child_mask().iter() {
        v346_7_cursor.descend_to_byte(v346_7_byte);
        let v346_7_tail = v346_7_cursor.make_map();
        v346_7_cursor.ascend(1);
        let v346_7_head = Path::from_slice(&[v346_7_byte]);
        let v347_2: Space = singleton(&(v346_7_head));
        let v347_3: Space = intersect(&(*CONSTANT_2),&(v347_2));
        let v347_4: Space = if has_head(&(v347_3)) { singleton(&[]) } else { Space::new() };
        drop(v347_3);
        let v347_5: Space = subtract(&(*CONSTANT_1),&(v347_4));
        drop(v347_4);
        let v347_8: Space = if (v347_5).is_empty() { Space::new() } else {
          let v348_6: Path = concat_path(&(v346_6),&(v346_7_head));
          let v348_7: Space = routine_46(c, &(v348_6), &(*p1), &(v346_7_tail), &(*s1));
          compose(&(v347_5),&(v348_7))
        };
        drop(v347_5);
        let v347_9: Space = intersect(&(*CONSTANT_2),&(v347_2));
        drop(v347_2);
        let v347_10: Space = if has_head(&(v347_9)) { singleton(&[]) } else { Space::new() };
        drop(v347_9);
        let v347_12: Space = if (v347_10).is_empty() { Space::new() } else {
          let v349_6: Path = concat_path(&(v346_6),&(v346_7_head));
          let v349_11: Space = routine_47(c, &(v349_6), &(*p1), &(v346_7_tail), &(*s1));
          drop(v349_6);
          compose(&(v347_10),&(v349_11))
        };
        drop(v347_10);
        let v347_13: Space = unite(&(v347_8),&(v347_12));
        v346_7.join_into((v347_13).clone());
      }
      drop(v346_7_cursor);
      compose(&(v345_5),&(v346_7))
    };
    drop(v345_5);
    let v345_9: Space = intersect(&(*CONSTANT_2),&(v345_2));
    drop(v345_2);
    let v345_10: Space = if has_head(&(v345_9)) { singleton(&[]) } else { Space::new() };
    drop(v345_9);
    let v345_12: Space = if (v345_10).is_empty() { Space::new() } else {
      let v350_6: Path = concat_path(&(*p0),&(v344_13_head));
      let mut v350_11 = Space::new();
      let mut v350_11_cursor = (v344_13_tail).read_zipper();
      for v350_11_byte in v350_11_cursor.child_mask().iter() {
        v350_11_cursor.descend_to_byte(v350_11_byte);
        let v350_11_tail = v350_11_cursor.make_map();
        v350_11_cursor.ascend(1);
        let v350_11_head = Path::from_slice(&[v350_11_byte]);
        let v351_2: Space = singleton(&(v350_11_head));
        let v351_3: Space = intersect(&(*CONSTANT_2),&(v351_2));
        let v351_4: Space = if has_head(&(v351_3)) { singleton(&[]) } else { Space::new() };
        drop(v351_3);
        let v351_5: Space = subtract(&(*CONSTANT_1),&(v351_4));
        drop(v351_4);
        let v351_8: Space = if (v351_5).is_empty() { Space::new() } else {
          let v352_6: Path = concat_path(&(v350_6),&(v350_11_head));
          let v352_7: Space = routine_46(c, &(v352_6), &(*p1), &(v350_11_tail), &(*s1));
          compose(&(v351_5),&(v352_7))
        };
        drop(v351_5);
        let v351_9: Space = intersect(&(*CONSTANT_2),&(v351_2));
        drop(v351_2);
        let v351_10: Space = if has_head(&(v351_9)) { singleton(&[]) } else { Space::new() };
        drop(v351_9);
        let v351_12: Space = if (v351_10).is_empty() { Space::new() } else {
          let v353_6: Path = concat_path(&(v350_6),&(v350_11_head));
          let v353_11: Space = routine_10(c, &(v353_6), &(*p1), &(v350_11_tail), &(*s1));
          drop(v353_6);
          compose(&(v351_10),&(v353_11))
        };
        drop(v351_10);
        let v351_13: Space = unite(&(v351_8),&(v351_12));
        v350_11.join_into((v351_13).clone());
      }
      drop(v350_11_cursor);
      drop(v350_6);
      compose(&(v345_10),&(v350_11))
    };
    drop(v345_10);
    let v345_13: Space = unite(&(v345_8),&(v345_12));
    v344_13.join_into((v345_13).clone());
  }
  drop(v344_13_cursor);
  (v344_13).clone()
}

fn routine_39(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v354_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v354_9: Space = unwrap(&(v354_8),&(*p0));
  drop(v354_8);
  let mut v354_16 = Space::new();
  let mut v354_16_cursor = (*s0).read_zipper();
  for v354_16_byte in v354_16_cursor.child_mask().iter() {
    v354_16_cursor.descend_to_byte(v354_16_byte);
    let v354_16_tail = v354_16_cursor.make_map();
    v354_16_cursor.ascend(1);
    let v354_16_head = Path::from_slice(&[v354_16_byte]);
    let v355_2: Space = singleton(&(v354_16_head));
    let v355_3: Space = intersect(&(*CONSTANT_2),&(v355_2));
    let v355_4: Space = if has_head(&(v355_3)) { singleton(&[]) } else { Space::new() };
    drop(v355_3);
    let v355_5: Space = subtract(&(*CONSTANT_1),&(v355_4));
    drop(v355_4);
    let v355_8: Space = if (v355_5).is_empty() { Space::new() } else {
      let v356_6: Path = concat_path(&(*p0),&(v354_16_head));
      let mut v356_7 = Space::new();
      let mut v356_7_cursor = (v354_16_tail).read_zipper();
      for v356_7_byte in v356_7_cursor.child_mask().iter() {
        v356_7_cursor.descend_to_byte(v356_7_byte);
        let v356_7_tail = v356_7_cursor.make_map();
        v356_7_cursor.ascend(1);
        let v356_7_head = Path::from_slice(&[v356_7_byte]);
        let v357_2: Space = singleton(&(v356_7_head));
        let v357_3: Space = intersect(&(*CONSTANT_2),&(v357_2));
        let v357_4: Space = if has_head(&(v357_3)) { singleton(&[]) } else { Space::new() };
        drop(v357_3);
        let v357_5: Space = subtract(&(*CONSTANT_1),&(v357_4));
        drop(v357_4);
        let v357_8: Space = if (v357_5).is_empty() { Space::new() } else {
          let v358_6: Path = concat_path(&(v356_6),&(v356_7_head));
          let v358_7: Space = routine_46(c, &(v358_6), &(*p1), &(v356_7_tail), &(*s1));
          compose(&(v357_5),&(v358_7))
        };
        drop(v357_5);
        let v357_9: Space = intersect(&(*CONSTANT_2),&(v357_2));
        drop(v357_2);
        let v357_10: Space = if has_head(&(v357_9)) { singleton(&[]) } else { Space::new() };
        drop(v357_9);
        let v357_12: Space = if (v357_10).is_empty() { Space::new() } else {
          let v359_6: Path = concat_path(&(v356_6),&(v356_7_head));
          let v359_11: Space = routine_47(c, &(v359_6), &(*p1), &(v356_7_tail), &(*s1));
          drop(v359_6);
          compose(&(v357_10),&(v359_11))
        };
        drop(v357_10);
        let v357_13: Space = unite(&(v357_8),&(v357_12));
        v356_7.join_into((v357_13).clone());
      }
      drop(v356_7_cursor);
      drop(v356_6);
      compose(&(v355_5),&(v356_7))
    };
    drop(v355_5);
    let v355_9: Space = intersect(&(*CONSTANT_2),&(v355_2));
    drop(v355_2);
    let v355_10: Space = if has_head(&(v355_9)) { singleton(&[]) } else { Space::new() };
    drop(v355_9);
    let v355_13: Space = if (v355_10).is_empty() { Space::new() } else {
      let v360_11: Space = unwrap(&(v354_9),&(v354_16_head));
      let mut v360_12 = Space::new();
      let mut v360_12_cursor = (v360_11).read_zipper();
      for v360_12_byte in v360_12_cursor.child_mask().iter() {
        v360_12_cursor.descend_to_byte(v360_12_byte);
        let v360_12_tail = v360_12_cursor.make_map();
        v360_12_cursor.ascend(1);
        let v360_12_head = Path::from_slice(&[v360_12_byte]);
        let v361_2: Space = singleton(&(v360_12_head));
        let v361_3: Space = intersect(&(*CONSTANT_2),&(v361_2));
        let v361_4: Space = if has_head(&(v361_3)) { singleton(&[]) } else { Space::new() };
        drop(v361_3);
        let v361_5: Space = subtract(&(*CONSTANT_1),&(v361_4));
        drop(v361_4);
        let v361_7: Space = if (v361_5).is_empty() { Space::new() } else {
          let v362_6: Space = routine_15(c, &(v360_12_head), &(*p1), &(v360_12_tail));
          compose(&(v361_5),&(v362_6))
        };
        drop(v361_5);
        let v361_8: Space = intersect(&(*CONSTANT_2),&(v361_2));
        drop(v361_2);
        let v361_9: Space = if has_head(&(v361_8)) { singleton(&[]) } else { Space::new() };
        drop(v361_8);
        let v361_11: Space = if (v361_9).is_empty() { Space::new() } else {
          let v363_10: Space = routine_16(c, &(v360_12_head), &(*p1), &(v360_12_tail));
          compose(&(v361_9),&(v363_10))
        };
        drop(v361_9);
        let v361_12: Space = unite(&(v361_7),&(v361_11));
        v360_12.join_into((v361_12).clone());
      }
      drop(v360_12_cursor);
      drop(v360_11);
      compose(&(v355_10),&(v360_12))
    };
    drop(v355_10);
    let v355_14: Space = unite(&(v355_8),&(v355_13));
    v354_16.join_into((v355_14).clone());
  }
  drop(v354_16_cursor);
  drop(v354_9);
  (v354_16).clone()
}

fn routine_40(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v364_12 = Space::new();
  let mut v364_12_cursor = (*s0).read_zipper();
  for v364_12_byte in v364_12_cursor.child_mask().iter() {
    v364_12_cursor.descend_to_byte(v364_12_byte);
    let v364_12_tail = v364_12_cursor.make_map();
    v364_12_cursor.ascend(1);
    let v364_12_head = Path::from_slice(&[v364_12_byte]);
    let v365_2: Space = singleton(&(v364_12_head));
    let v365_3: Space = intersect(&(*CONSTANT_2),&(v365_2));
    let v365_4: Space = if has_head(&(v365_3)) { singleton(&[]) } else { Space::new() };
    drop(v365_3);
    let v365_5: Space = subtract(&(*CONSTANT_1),&(v365_4));
    drop(v365_4);
    let v365_8: Space = if (v365_5).is_empty() { Space::new() } else {
      let v366_6: Path = concat_path(&(*p0),&(v364_12_head));
      let mut v366_7 = Space::new();
      let mut v366_7_cursor = (v364_12_tail).read_zipper();
      for v366_7_byte in v366_7_cursor.child_mask().iter() {
        v366_7_cursor.descend_to_byte(v366_7_byte);
        let v366_7_tail = v366_7_cursor.make_map();
        v366_7_cursor.ascend(1);
        let v366_7_head = Path::from_slice(&[v366_7_byte]);
        let v367_2: Space = singleton(&(v366_7_head));
        let v367_3: Space = intersect(&(*CONSTANT_2),&(v367_2));
        let v367_4: Space = if has_head(&(v367_3)) { singleton(&[]) } else { Space::new() };
        drop(v367_3);
        let v367_5: Space = subtract(&(*CONSTANT_1),&(v367_4));
        drop(v367_4);
        let v367_8: Space = if (v367_5).is_empty() { Space::new() } else {
          let v368_6: Path = concat_path(&(v366_6),&(v366_7_head));
          let v368_7: Space = routine_48(c, &(v368_6), &(*p1), &(v366_7_tail));
          compose(&(v367_5),&(v368_7))
        };
        drop(v367_5);
        let v367_9: Space = intersect(&(*CONSTANT_2),&(v367_2));
        drop(v367_2);
        let v367_10: Space = if has_head(&(v367_9)) { singleton(&[]) } else { Space::new() };
        drop(v367_9);
        let v367_12: Space = if (v367_10).is_empty() { Space::new() } else {
          let v369_6: Path = concat_path(&(v366_6),&(v366_7_head));
          let v369_11: Space = routine_49(c, &(v369_6), &(*p1), &(v366_7_tail));
          drop(v369_6);
          compose(&(v367_10),&(v369_11))
        };
        drop(v367_10);
        let v367_13: Space = unite(&(v367_8),&(v367_12));
        v366_7.join_into((v367_13).clone());
      }
      drop(v366_7_cursor);
      compose(&(v365_5),&(v366_7))
    };
    drop(v365_5);
    let v365_9: Space = intersect(&(*CONSTANT_2),&(v365_2));
    drop(v365_2);
    let v365_10: Space = if has_head(&(v365_9)) { singleton(&[]) } else { Space::new() };
    drop(v365_9);
    let v365_12: Space = if (v365_10).is_empty() { Space::new() } else {
      let v370_6: Path = concat_path(&(*p0),&(v364_12_head));
      let mut v370_11 = Space::new();
      let mut v370_11_cursor = (v364_12_tail).read_zipper();
      for v370_11_byte in v370_11_cursor.child_mask().iter() {
        v370_11_cursor.descend_to_byte(v370_11_byte);
        let v370_11_tail = v370_11_cursor.make_map();
        v370_11_cursor.ascend(1);
        let v370_11_head = Path::from_slice(&[v370_11_byte]);
        let v371_2: Space = singleton(&(v370_11_head));
        let v371_3: Space = intersect(&(*CONSTANT_2),&(v371_2));
        let v371_4: Space = if has_head(&(v371_3)) { singleton(&[]) } else { Space::new() };
        drop(v371_3);
        let v371_5: Space = subtract(&(*CONSTANT_1),&(v371_4));
        drop(v371_4);
        let v371_8: Space = if (v371_5).is_empty() { Space::new() } else {
          let v372_6: Path = concat_path(&(v370_6),&(v370_11_head));
          let v372_7: Space = routine_48(c, &(v372_6), &(*p1), &(v370_11_tail));
          compose(&(v371_5),&(v372_7))
        };
        drop(v371_5);
        let v371_9: Space = intersect(&(*CONSTANT_2),&(v371_2));
        drop(v371_2);
        let v371_10: Space = if has_head(&(v371_9)) { singleton(&[]) } else { Space::new() };
        drop(v371_9);
        let v371_12: Space = if (v371_10).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v370_6),&(v370_11_head));
          let v373_11: Space = routine_21(c, &(v373_6), &(*p1), &(v370_11_tail));
          drop(v373_6);
          compose(&(v371_10),&(v373_11))
        };
        drop(v371_10);
        let v371_13: Space = unite(&(v371_8),&(v371_12));
        v370_11.join_into((v371_13).clone());
      }
      drop(v370_11_cursor);
      drop(v370_6);
      compose(&(v365_10),&(v370_11))
    };
    drop(v365_10);
    let v365_13: Space = unite(&(v365_8),&(v365_12));
    v364_12.join_into((v365_13).clone());
  }
  drop(v364_12_cursor);
  (v364_12).clone()
}

fn routine_41(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v374_9 = Space::new();
  let mut v374_9_cursor = (*s0).read_zipper();
  for v374_9_byte in v374_9_cursor.child_mask().iter() {
    v374_9_cursor.descend_to_byte(v374_9_byte);
    let v374_9_tail = v374_9_cursor.make_map();
    v374_9_cursor.ascend(1);
    let v374_9_head = Path::from_slice(&[v374_9_byte]);
    let v375_2: Space = singleton(&(v374_9_head));
    let v375_3: Space = intersect(&(*CONSTANT_2),&(v375_2));
    let v375_4: Space = if has_head(&(v375_3)) { singleton(&[]) } else { Space::new() };
    drop(v375_3);
    let v375_5: Space = subtract(&(*CONSTANT_1),&(v375_4));
    drop(v375_4);
    let v375_8: Space = if (v375_5).is_empty() { Space::new() } else {
      let v376_6: Path = concat_path(&(*p0),&(v374_9_head));
      let mut v376_7 = Space::new();
      let mut v376_7_cursor = (v374_9_tail).read_zipper();
      for v376_7_byte in v376_7_cursor.child_mask().iter() {
        v376_7_cursor.descend_to_byte(v376_7_byte);
        let v376_7_tail = v376_7_cursor.make_map();
        v376_7_cursor.ascend(1);
        let v376_7_head = Path::from_slice(&[v376_7_byte]);
        let v377_2: Space = singleton(&(v376_7_head));
        let v377_3: Space = intersect(&(*CONSTANT_2),&(v377_2));
        let v377_4: Space = if has_head(&(v377_3)) { singleton(&[]) } else { Space::new() };
        drop(v377_3);
        let v377_5: Space = subtract(&(*CONSTANT_1),&(v377_4));
        drop(v377_4);
        let v377_8: Space = if (v377_5).is_empty() { Space::new() } else {
          let v378_6: Path = concat_path(&(v376_6),&(v376_7_head));
          let v378_7: Space = routine_48(c, &(v378_6), &(*p1), &(v376_7_tail));
          compose(&(v377_5),&(v378_7))
        };
        drop(v377_5);
        let v377_9: Space = intersect(&(*CONSTANT_2),&(v377_2));
        drop(v377_2);
        let v377_10: Space = if has_head(&(v377_9)) { singleton(&[]) } else { Space::new() };
        drop(v377_9);
        let v377_12: Space = if (v377_10).is_empty() { Space::new() } else {
          let v379_6: Path = concat_path(&(v376_6),&(v376_7_head));
          let v379_11: Space = routine_49(c, &(v379_6), &(*p1), &(v376_7_tail));
          drop(v379_6);
          compose(&(v377_10),&(v379_11))
        };
        drop(v377_10);
        let v377_13: Space = unite(&(v377_8),&(v377_12));
        v376_7.join_into((v377_13).clone());
      }
      drop(v376_7_cursor);
      compose(&(v375_5),&(v376_7))
    };
    drop(v375_5);
    let v375_9: Space = intersect(&(*CONSTANT_2),&(v375_2));
    drop(v375_2);
    let v375_10: Space = if has_head(&(v375_9)) { singleton(&[]) } else { Space::new() };
    drop(v375_9);
    let v375_11: Space = compose(&(v375_10),&(v374_9_tail));
    drop(v375_10);
    let v380_6: Path = concat_path(&(*p0),&(v374_9_head));
    let v375_12: Space = wrap(&(v375_11),&(v380_6));
    drop(v375_11);
    let v375_13: Space = wrap(&(v375_12),&(*p1));
    drop(v375_12);
    let v375_14: Space = unite(&(v375_8),&(v375_13));
    drop(v375_13);
    v374_9.join_into((v375_14).clone());
  }
  drop(v374_9_cursor);
  (v374_9).clone()
}

fn routine_42(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v381_8 = Space::new();
  let mut v381_8_cursor = (*s0).read_zipper();
  for v381_8_byte in v381_8_cursor.child_mask().iter() {
    v381_8_cursor.descend_to_byte(v381_8_byte);
    let v381_8_tail = v381_8_cursor.make_map();
    v381_8_cursor.ascend(1);
    let v381_8_head = Path::from_slice(&[v381_8_byte]);
    let v382_2: Space = singleton(&(v381_8_head));
    let v382_3: Space = intersect(&(*CONSTANT_2),&(v382_2));
    let v382_4: Space = if has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
    drop(v382_3);
    let v382_5: Space = subtract(&(*CONSTANT_1),&(v382_4));
    drop(v382_4);
    let mut v382_6 = Space::new();
    let mut v382_6_cursor = (v381_8_tail).read_zipper();
    for v382_6_byte in v382_6_cursor.child_mask().iter() {
      v382_6_cursor.descend_to_byte(v382_6_byte);
      let v382_6_tail = v382_6_cursor.make_map();
      v382_6_cursor.ascend(1);
      let v382_6_head = Path::from_slice(&[v382_6_byte]);
      let v383_2: Space = Space::new();
      v382_6.join_into((v383_2).clone());
    }
    drop(v382_6_cursor);
    let v382_7: Space = compose(&(v382_5),&(v382_6));
    drop(v382_5);
    drop(v382_6);
    let v382_8: Space = intersect(&(*CONSTANT_2),&(v382_2));
    drop(v382_2);
    let v382_9: Space = if has_head(&(v382_8)) { singleton(&[]) } else { Space::new() };
    drop(v382_8);
    let v382_12: Space = if (v382_9).is_empty() { Space::new() } else {
      let v384_10: Path = concat_path(&(*p0),&(v381_8_head));
      let mut v384_11 = Space::new();
      let mut v384_11_cursor = (v381_8_tail).read_zipper();
      for v384_11_byte in v384_11_cursor.child_mask().iter() {
        v384_11_cursor.descend_to_byte(v384_11_byte);
        let v384_11_tail = v384_11_cursor.make_map();
        v384_11_cursor.ascend(1);
        let v384_11_head = Path::from_slice(&[v384_11_byte]);
        let v385_2: Space = singleton(&(v384_11_head));
        let v385_3: Space = intersect(&(*CONSTANT_2),&(v385_2));
        drop(v385_2);
        let v385_4: Space = if has_head(&(v385_3)) { singleton(&[]) } else { Space::new() };
        drop(v385_3);
        let v385_7: Space = if (v385_4).is_empty() { Space::new() } else {
          let v386_5: Path = concat_path(&(v384_10),&(v384_11_head));
          let v386_6: Space = routine_10(c, &(v386_5), &(*p1), &(v384_11_tail), &(*s1));
          drop(v386_5);
          compose(&(v385_4),&(v386_6))
        };
        drop(v385_4);
        v384_11.join_into((v385_7).clone());
      }
      drop(v384_11_cursor);
      drop(v384_10);
      compose(&(v382_9),&(v384_11))
    };
    drop(v382_9);
    let v382_13: Space = unite(&(v382_7),&(v382_12));
    drop(v382_7);
    v381_8.join_into((v382_13).clone());
  }
  drop(v381_8_cursor);
  (v381_8).clone()
}

fn routine_43(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v387_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v387_9: Space = unwrap(&(v387_8),&(*p0));
  drop(v387_8);
  let mut v387_13 = Space::new();
  let mut v387_13_cursor = (*s0).read_zipper();
  for v387_13_byte in v387_13_cursor.child_mask().iter() {
    v387_13_cursor.descend_to_byte(v387_13_byte);
    let v387_13_tail = v387_13_cursor.make_map();
    v387_13_cursor.ascend(1);
    let v387_13_head = Path::from_slice(&[v387_13_byte]);
    let v388_2: Space = singleton(&(v387_13_head));
    let v388_3: Space = intersect(&(*CONSTANT_2),&(v388_2));
    let v388_4: Space = if has_head(&(v388_3)) { singleton(&[]) } else { Space::new() };
    drop(v388_3);
    let v388_5: Space = subtract(&(*CONSTANT_1),&(v388_4));
    drop(v388_4);
    let mut v388_6 = Space::new();
    let mut v388_6_cursor = (v387_13_tail).read_zipper();
    for v388_6_byte in v388_6_cursor.child_mask().iter() {
      v388_6_cursor.descend_to_byte(v388_6_byte);
      let v388_6_tail = v388_6_cursor.make_map();
      v388_6_cursor.ascend(1);
      let v388_6_head = Path::from_slice(&[v388_6_byte]);
      let v389_2: Space = Space::new();
      v388_6.join_into((v389_2).clone());
    }
    drop(v388_6_cursor);
    let v388_7: Space = compose(&(v388_5),&(v388_6));
    drop(v388_5);
    drop(v388_6);
    let v388_8: Space = intersect(&(*CONSTANT_2),&(v388_2));
    drop(v388_2);
    let v388_9: Space = if has_head(&(v388_8)) { singleton(&[]) } else { Space::new() };
    drop(v388_8);
    let v388_12: Space = if (v388_9).is_empty() { Space::new() } else {
      let v390_10: Space = unwrap(&(v387_9),&(v387_13_head));
      let mut v390_11 = Space::new();
      let mut v390_11_cursor = (v390_10).read_zipper();
      for v390_11_byte in v390_11_cursor.child_mask().iter() {
        v390_11_cursor.descend_to_byte(v390_11_byte);
        let v390_11_tail = v390_11_cursor.make_map();
        v390_11_cursor.ascend(1);
        let v390_11_head = Path::from_slice(&[v390_11_byte]);
        let v391_2: Space = singleton(&(v390_11_head));
        let v391_3: Space = intersect(&(*CONSTANT_2),&(v391_2));
        let v391_4: Space = if has_head(&(v391_3)) { singleton(&[]) } else { Space::new() };
        drop(v391_3);
        let v391_5: Space = subtract(&(*CONSTANT_1),&(v391_4));
        drop(v391_4);
        let v391_7: Space = if (v391_5).is_empty() { Space::new() } else {
          let v392_6: Space = routine_15(c, &(v390_11_head), &(*p1), &(v390_11_tail));
          compose(&(v391_5),&(v392_6))
        };
        drop(v391_5);
        let v391_8: Space = intersect(&(*CONSTANT_2),&(v391_2));
        drop(v391_2);
        let v391_9: Space = if has_head(&(v391_8)) { singleton(&[]) } else { Space::new() };
        drop(v391_8);
        let v391_11: Space = if (v391_9).is_empty() { Space::new() } else {
          let v393_10: Space = routine_16(c, &(v390_11_head), &(*p1), &(v390_11_tail));
          compose(&(v391_9),&(v393_10))
        };
        drop(v391_9);
        let v391_12: Space = unite(&(v391_7),&(v391_11));
        v390_11.join_into((v391_12).clone());
      }
      drop(v390_11_cursor);
      drop(v390_10);
      compose(&(v388_9),&(v390_11))
    };
    drop(v388_9);
    let v388_13: Space = unite(&(v388_7),&(v388_12));
    drop(v388_7);
    v387_13.join_into((v388_13).clone());
  }
  drop(v387_13_cursor);
  drop(v387_9);
  (v387_13).clone()
}

fn routine_44(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v394_12 = Space::new();
  let mut v394_12_cursor = (*s0).read_zipper();
  for v394_12_byte in v394_12_cursor.child_mask().iter() {
    v394_12_cursor.descend_to_byte(v394_12_byte);
    let v394_12_tail = v394_12_cursor.make_map();
    v394_12_cursor.ascend(1);
    let v394_12_head = Path::from_slice(&[v394_12_byte]);
    let v395_2: Space = singleton(&(v394_12_head));
    let v395_3: Space = intersect(&(*CONSTANT_2),&(v395_2));
    let v395_4: Space = if has_head(&(v395_3)) { singleton(&[]) } else { Space::new() };
    drop(v395_3);
    let v395_5: Space = subtract(&(*CONSTANT_1),&(v395_4));
    drop(v395_4);
    let v395_8: Space = if (v395_5).is_empty() { Space::new() } else {
      let v396_6: Path = concat_path(&(*p0),&(v394_12_head));
      let mut v396_7 = Space::new();
      let mut v396_7_cursor = (v394_12_tail).read_zipper();
      for v396_7_byte in v396_7_cursor.child_mask().iter() {
        v396_7_cursor.descend_to_byte(v396_7_byte);
        let v396_7_tail = v396_7_cursor.make_map();
        v396_7_cursor.ascend(1);
        let v396_7_head = Path::from_slice(&[v396_7_byte]);
        let v397_2: Space = singleton(&(v396_7_head));
        let v397_3: Space = intersect(&(*CONSTANT_2),&(v397_2));
        let v397_4: Space = if has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
        drop(v397_3);
        let v397_5: Space = subtract(&(*CONSTANT_1),&(v397_4));
        drop(v397_4);
        let v397_8: Space = if (v397_5).is_empty() { Space::new() } else {
          let v398_6: Path = concat_path(&(v396_6),&(v396_7_head));
          let v398_7: Space = routine_50(c, &(v398_6), &(*p1), &(v396_7_tail));
          compose(&(v397_5),&(v398_7))
        };
        drop(v397_5);
        let v397_9: Space = intersect(&(*CONSTANT_2),&(v397_2));
        drop(v397_2);
        let v397_10: Space = if has_head(&(v397_9)) { singleton(&[]) } else { Space::new() };
        drop(v397_9);
        let v397_12: Space = if (v397_10).is_empty() { Space::new() } else {
          let v399_6: Path = concat_path(&(v396_6),&(v396_7_head));
          let v399_11: Space = routine_51(c, &(v399_6), &(*p1), &(v396_7_tail));
          drop(v399_6);
          compose(&(v397_10),&(v399_11))
        };
        drop(v397_10);
        let v397_13: Space = unite(&(v397_8),&(v397_12));
        v396_7.join_into((v397_13).clone());
      }
      drop(v396_7_cursor);
      compose(&(v395_5),&(v396_7))
    };
    drop(v395_5);
    let v395_9: Space = intersect(&(*CONSTANT_2),&(v395_2));
    drop(v395_2);
    let v395_10: Space = if has_head(&(v395_9)) { singleton(&[]) } else { Space::new() };
    drop(v395_9);
    let v395_12: Space = if (v395_10).is_empty() { Space::new() } else {
      let v400_6: Path = concat_path(&(*p0),&(v394_12_head));
      let mut v400_11 = Space::new();
      let mut v400_11_cursor = (v394_12_tail).read_zipper();
      for v400_11_byte in v400_11_cursor.child_mask().iter() {
        v400_11_cursor.descend_to_byte(v400_11_byte);
        let v400_11_tail = v400_11_cursor.make_map();
        v400_11_cursor.ascend(1);
        let v400_11_head = Path::from_slice(&[v400_11_byte]);
        let v401_2: Space = singleton(&(v400_11_head));
        let v401_3: Space = intersect(&(*CONSTANT_2),&(v401_2));
        let v401_4: Space = if has_head(&(v401_3)) { singleton(&[]) } else { Space::new() };
        drop(v401_3);
        let v401_5: Space = subtract(&(*CONSTANT_1),&(v401_4));
        drop(v401_4);
        let v401_8: Space = if (v401_5).is_empty() { Space::new() } else {
          let v402_6: Path = concat_path(&(v400_6),&(v400_11_head));
          let v402_7: Space = routine_50(c, &(v402_6), &(*p1), &(v400_11_tail));
          compose(&(v401_5),&(v402_7))
        };
        drop(v401_5);
        let v401_9: Space = intersect(&(*CONSTANT_2),&(v401_2));
        drop(v401_2);
        let v401_10: Space = if has_head(&(v401_9)) { singleton(&[]) } else { Space::new() };
        drop(v401_9);
        let v401_12: Space = if (v401_10).is_empty() { Space::new() } else {
          let v403_6: Path = concat_path(&(v400_6),&(v400_11_head));
          let v403_11: Space = routine_21(c, &(v403_6), &(*p1), &(v400_11_tail));
          drop(v403_6);
          compose(&(v401_10),&(v403_11))
        };
        drop(v401_10);
        let v401_13: Space = unite(&(v401_8),&(v401_12));
        v400_11.join_into((v401_13).clone());
      }
      drop(v400_11_cursor);
      drop(v400_6);
      compose(&(v395_10),&(v400_11))
    };
    drop(v395_10);
    let v395_13: Space = unite(&(v395_8),&(v395_12));
    v394_12.join_into((v395_13).clone());
  }
  drop(v394_12_cursor);
  (v394_12).clone()
}

fn routine_45(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v404_9 = Space::new();
  let mut v404_9_cursor = (*s0).read_zipper();
  for v404_9_byte in v404_9_cursor.child_mask().iter() {
    v404_9_cursor.descend_to_byte(v404_9_byte);
    let v404_9_tail = v404_9_cursor.make_map();
    v404_9_cursor.ascend(1);
    let v404_9_head = Path::from_slice(&[v404_9_byte]);
    let v405_2: Space = singleton(&(v404_9_head));
    let v405_3: Space = intersect(&(*CONSTANT_2),&(v405_2));
    let v405_4: Space = if has_head(&(v405_3)) { singleton(&[]) } else { Space::new() };
    drop(v405_3);
    let v405_5: Space = subtract(&(*CONSTANT_1),&(v405_4));
    drop(v405_4);
    let v405_8: Space = if (v405_5).is_empty() { Space::new() } else {
      let v406_6: Path = concat_path(&(*p0),&(v404_9_head));
      let mut v406_7 = Space::new();
      let mut v406_7_cursor = (v404_9_tail).read_zipper();
      for v406_7_byte in v406_7_cursor.child_mask().iter() {
        v406_7_cursor.descend_to_byte(v406_7_byte);
        let v406_7_tail = v406_7_cursor.make_map();
        v406_7_cursor.ascend(1);
        let v406_7_head = Path::from_slice(&[v406_7_byte]);
        let v407_2: Space = singleton(&(v406_7_head));
        let v407_3: Space = intersect(&(*CONSTANT_2),&(v407_2));
        let v407_4: Space = if has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
        drop(v407_3);
        let v407_5: Space = subtract(&(*CONSTANT_1),&(v407_4));
        drop(v407_4);
        let v407_8: Space = if (v407_5).is_empty() { Space::new() } else {
          let v408_6: Path = concat_path(&(v406_6),&(v406_7_head));
          let v408_7: Space = routine_50(c, &(v408_6), &(*p1), &(v406_7_tail));
          compose(&(v407_5),&(v408_7))
        };
        drop(v407_5);
        let v407_9: Space = intersect(&(*CONSTANT_2),&(v407_2));
        drop(v407_2);
        let v407_10: Space = if has_head(&(v407_9)) { singleton(&[]) } else { Space::new() };
        drop(v407_9);
        let v407_12: Space = if (v407_10).is_empty() { Space::new() } else {
          let v409_6: Path = concat_path(&(v406_6),&(v406_7_head));
          let v409_11: Space = routine_51(c, &(v409_6), &(*p1), &(v406_7_tail));
          drop(v409_6);
          compose(&(v407_10),&(v409_11))
        };
        drop(v407_10);
        let v407_13: Space = unite(&(v407_8),&(v407_12));
        v406_7.join_into((v407_13).clone());
      }
      drop(v406_7_cursor);
      compose(&(v405_5),&(v406_7))
    };
    drop(v405_5);
    let v405_9: Space = intersect(&(*CONSTANT_2),&(v405_2));
    drop(v405_2);
    let v405_10: Space = if has_head(&(v405_9)) { singleton(&[]) } else { Space::new() };
    drop(v405_9);
    let v405_11: Space = compose(&(v405_10),&(v404_9_tail));
    drop(v405_10);
    let v410_6: Path = concat_path(&(*p0),&(v404_9_head));
    let v405_12: Space = wrap(&(v405_11),&(v410_6));
    drop(v405_11);
    let v405_13: Space = wrap(&(v405_12),&(*p1));
    drop(v405_12);
    let v405_14: Space = unite(&(v405_8),&(v405_13));
    drop(v405_13);
    v404_9.join_into((v405_14).clone());
  }
  drop(v404_9_cursor);
  (v404_9).clone()
}

fn routine_46(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v411_4 = Space::new();
  let mut v411_4_cursor = (*s0).read_zipper();
  for v411_4_byte in v411_4_cursor.child_mask().iter() {
    v411_4_cursor.descend_to_byte(v411_4_byte);
    let v411_4_tail = v411_4_cursor.make_map();
    v411_4_cursor.ascend(1);
    let v411_4_head = Path::from_slice(&[v411_4_byte]);
    let v412_2: Space = Space::new();
    v411_4.join_into((v412_2).clone());
  }
  drop(v411_4_cursor);
  (v411_4).clone()
}

fn routine_47(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v413_6: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v413_7: Space = unwrap(&(v413_6),&(*p0));
  drop(v413_6);
  let mut v413_11 = Space::new();
  let mut v413_11_cursor = (*s0).read_zipper();
  for v413_11_byte in v413_11_cursor.child_mask().iter() {
    v413_11_cursor.descend_to_byte(v413_11_byte);
    let v413_11_tail = v413_11_cursor.make_map();
    v413_11_cursor.ascend(1);
    let v413_11_head = Path::from_slice(&[v413_11_byte]);
    let v414_2: Space = singleton(&(v413_11_head));
    let v414_3: Space = intersect(&(*CONSTANT_2),&(v414_2));
    drop(v414_2);
    let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
    drop(v414_3);
    let v414_7: Space = if (v414_4).is_empty() { Space::new() } else {
      let v415_5: Space = unwrap(&(v413_7),&(v413_11_head));
      let mut v415_6 = Space::new();
      let mut v415_6_cursor = (v415_5).read_zipper();
      for v415_6_byte in v415_6_cursor.child_mask().iter() {
        v415_6_cursor.descend_to_byte(v415_6_byte);
        let v415_6_tail = v415_6_cursor.make_map();
        v415_6_cursor.ascend(1);
        let v415_6_head = Path::from_slice(&[v415_6_byte]);
        let v416_2: Space = singleton(&(v415_6_head));
        let v416_3: Space = intersect(&(*CONSTANT_2),&(v416_2));
        let v416_4: Space = if has_head(&(v416_3)) { singleton(&[]) } else { Space::new() };
        drop(v416_3);
        let v416_5: Space = subtract(&(*CONSTANT_1),&(v416_4));
        drop(v416_4);
        let v416_7: Space = if (v416_5).is_empty() { Space::new() } else {
          let v417_6: Space = routine_15(c, &(v415_6_head), &(*p1), &(v415_6_tail));
          compose(&(v416_5),&(v417_6))
        };
        drop(v416_5);
        let v416_8: Space = intersect(&(*CONSTANT_2),&(v416_2));
        drop(v416_2);
        let v416_9: Space = if has_head(&(v416_8)) { singleton(&[]) } else { Space::new() };
        drop(v416_8);
        let v416_11: Space = if (v416_9).is_empty() { Space::new() } else {
          let v418_10: Space = routine_16(c, &(v415_6_head), &(*p1), &(v415_6_tail));
          compose(&(v416_9),&(v418_10))
        };
        drop(v416_9);
        let v416_12: Space = unite(&(v416_7),&(v416_11));
        v415_6.join_into((v416_12).clone());
      }
      drop(v415_6_cursor);
      drop(v415_5);
      compose(&(v414_4),&(v415_6))
    };
    drop(v414_4);
    v413_11.join_into((v414_7).clone());
  }
  drop(v413_11_cursor);
  drop(v413_7);
  (v413_11).clone()
}

fn routine_48(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v419_12 = Space::new();
  let mut v419_12_cursor = (*s0).read_zipper();
  for v419_12_byte in v419_12_cursor.child_mask().iter() {
    v419_12_cursor.descend_to_byte(v419_12_byte);
    let v419_12_tail = v419_12_cursor.make_map();
    v419_12_cursor.ascend(1);
    let v419_12_head = Path::from_slice(&[v419_12_byte]);
    let v420_2: Space = singleton(&(v419_12_head));
    let v420_3: Space = intersect(&(*CONSTANT_2),&(v420_2));
    let v420_4: Space = if has_head(&(v420_3)) { singleton(&[]) } else { Space::new() };
    drop(v420_3);
    let v420_5: Space = subtract(&(*CONSTANT_1),&(v420_4));
    drop(v420_4);
    let v420_8: Space = if (v420_5).is_empty() { Space::new() } else {
      let v421_6: Path = concat_path(&(*p0),&(v419_12_head));
      let mut v421_7 = Space::new();
      let mut v421_7_cursor = (v419_12_tail).read_zipper();
      for v421_7_byte in v421_7_cursor.child_mask().iter() {
        v421_7_cursor.descend_to_byte(v421_7_byte);
        let v421_7_tail = v421_7_cursor.make_map();
        v421_7_cursor.ascend(1);
        let v421_7_head = Path::from_slice(&[v421_7_byte]);
        let v422_2: Space = singleton(&(v421_7_head));
        let v422_3: Space = intersect(&(*CONSTANT_2),&(v422_2));
        let v422_4: Space = if has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
        drop(v422_3);
        let v422_5: Space = subtract(&(*CONSTANT_1),&(v422_4));
        drop(v422_4);
        let v422_8: Space = if (v422_5).is_empty() { Space::new() } else {
          let v423_6: Path = concat_path(&(v421_6),&(v421_7_head));
          let v423_7: Space = routine_52(c, &(v423_6), &(*p1), &(v421_7_tail));
          compose(&(v422_5),&(v423_7))
        };
        drop(v422_5);
        let v422_9: Space = intersect(&(*CONSTANT_2),&(v422_2));
        drop(v422_2);
        let v422_10: Space = if has_head(&(v422_9)) { singleton(&[]) } else { Space::new() };
        drop(v422_9);
        let v422_12: Space = if (v422_10).is_empty() { Space::new() } else {
          let v424_6: Path = concat_path(&(v421_6),&(v421_7_head));
          let v424_11: Space = routine_53(c, &(v424_6), &(*p1), &(v421_7_tail));
          drop(v424_6);
          compose(&(v422_10),&(v424_11))
        };
        drop(v422_10);
        let v422_13: Space = unite(&(v422_8),&(v422_12));
        v421_7.join_into((v422_13).clone());
      }
      drop(v421_7_cursor);
      compose(&(v420_5),&(v421_7))
    };
    drop(v420_5);
    let v420_9: Space = intersect(&(*CONSTANT_2),&(v420_2));
    drop(v420_2);
    let v420_10: Space = if has_head(&(v420_9)) { singleton(&[]) } else { Space::new() };
    drop(v420_9);
    let v420_12: Space = if (v420_10).is_empty() { Space::new() } else {
      let v425_6: Path = concat_path(&(*p0),&(v419_12_head));
      let mut v425_11 = Space::new();
      let mut v425_11_cursor = (v419_12_tail).read_zipper();
      for v425_11_byte in v425_11_cursor.child_mask().iter() {
        v425_11_cursor.descend_to_byte(v425_11_byte);
        let v425_11_tail = v425_11_cursor.make_map();
        v425_11_cursor.ascend(1);
        let v425_11_head = Path::from_slice(&[v425_11_byte]);
        let v426_2: Space = singleton(&(v425_11_head));
        let v426_3: Space = intersect(&(*CONSTANT_2),&(v426_2));
        let v426_4: Space = if has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
        drop(v426_3);
        let v426_5: Space = subtract(&(*CONSTANT_1),&(v426_4));
        drop(v426_4);
        let v426_8: Space = if (v426_5).is_empty() { Space::new() } else {
          let v427_6: Path = concat_path(&(v425_6),&(v425_11_head));
          let v427_7: Space = routine_52(c, &(v427_6), &(*p1), &(v425_11_tail));
          compose(&(v426_5),&(v427_7))
        };
        drop(v426_5);
        let v426_9: Space = intersect(&(*CONSTANT_2),&(v426_2));
        drop(v426_2);
        let v426_10: Space = if has_head(&(v426_9)) { singleton(&[]) } else { Space::new() };
        drop(v426_9);
        let v426_12: Space = if (v426_10).is_empty() { Space::new() } else {
          let v428_6: Path = concat_path(&(v425_6),&(v425_11_head));
          let v428_11: Space = routine_21(c, &(v428_6), &(*p1), &(v425_11_tail));
          drop(v428_6);
          compose(&(v426_10),&(v428_11))
        };
        drop(v426_10);
        let v426_13: Space = unite(&(v426_8),&(v426_12));
        v425_11.join_into((v426_13).clone());
      }
      drop(v425_11_cursor);
      drop(v425_6);
      compose(&(v420_10),&(v425_11))
    };
    drop(v420_10);
    let v420_13: Space = unite(&(v420_8),&(v420_12));
    v419_12.join_into((v420_13).clone());
  }
  drop(v419_12_cursor);
  (v419_12).clone()
}

fn routine_49(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v429_9 = Space::new();
  let mut v429_9_cursor = (*s0).read_zipper();
  for v429_9_byte in v429_9_cursor.child_mask().iter() {
    v429_9_cursor.descend_to_byte(v429_9_byte);
    let v429_9_tail = v429_9_cursor.make_map();
    v429_9_cursor.ascend(1);
    let v429_9_head = Path::from_slice(&[v429_9_byte]);
    let v430_2: Space = singleton(&(v429_9_head));
    let v430_3: Space = intersect(&(*CONSTANT_2),&(v430_2));
    let v430_4: Space = if has_head(&(v430_3)) { singleton(&[]) } else { Space::new() };
    drop(v430_3);
    let v430_5: Space = subtract(&(*CONSTANT_1),&(v430_4));
    drop(v430_4);
    let v430_8: Space = if (v430_5).is_empty() { Space::new() } else {
      let v431_6: Path = concat_path(&(*p0),&(v429_9_head));
      let mut v431_7 = Space::new();
      let mut v431_7_cursor = (v429_9_tail).read_zipper();
      for v431_7_byte in v431_7_cursor.child_mask().iter() {
        v431_7_cursor.descend_to_byte(v431_7_byte);
        let v431_7_tail = v431_7_cursor.make_map();
        v431_7_cursor.ascend(1);
        let v431_7_head = Path::from_slice(&[v431_7_byte]);
        let v432_2: Space = singleton(&(v431_7_head));
        let v432_3: Space = intersect(&(*CONSTANT_2),&(v432_2));
        let v432_4: Space = if has_head(&(v432_3)) { singleton(&[]) } else { Space::new() };
        drop(v432_3);
        let v432_5: Space = subtract(&(*CONSTANT_1),&(v432_4));
        drop(v432_4);
        let v432_8: Space = if (v432_5).is_empty() { Space::new() } else {
          let v433_6: Path = concat_path(&(v431_6),&(v431_7_head));
          let v433_7: Space = routine_52(c, &(v433_6), &(*p1), &(v431_7_tail));
          compose(&(v432_5),&(v433_7))
        };
        drop(v432_5);
        let v432_9: Space = intersect(&(*CONSTANT_2),&(v432_2));
        drop(v432_2);
        let v432_10: Space = if has_head(&(v432_9)) { singleton(&[]) } else { Space::new() };
        drop(v432_9);
        let v432_12: Space = if (v432_10).is_empty() { Space::new() } else {
          let v434_6: Path = concat_path(&(v431_6),&(v431_7_head));
          let v434_11: Space = routine_53(c, &(v434_6), &(*p1), &(v431_7_tail));
          drop(v434_6);
          compose(&(v432_10),&(v434_11))
        };
        drop(v432_10);
        let v432_13: Space = unite(&(v432_8),&(v432_12));
        v431_7.join_into((v432_13).clone());
      }
      drop(v431_7_cursor);
      compose(&(v430_5),&(v431_7))
    };
    drop(v430_5);
    let v430_9: Space = intersect(&(*CONSTANT_2),&(v430_2));
    drop(v430_2);
    let v430_10: Space = if has_head(&(v430_9)) { singleton(&[]) } else { Space::new() };
    drop(v430_9);
    let v430_11: Space = compose(&(v430_10),&(v429_9_tail));
    drop(v430_10);
    let v435_6: Path = concat_path(&(*p0),&(v429_9_head));
    let v430_12: Space = wrap(&(v430_11),&(v435_6));
    drop(v430_11);
    let v430_13: Space = wrap(&(v430_12),&(*p1));
    drop(v430_12);
    let v430_14: Space = unite(&(v430_8),&(v430_13));
    drop(v430_13);
    v429_9.join_into((v430_14).clone());
  }
  drop(v429_9_cursor);
  (v429_9).clone()
}

fn routine_50(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v436_7 = Space::new();
  let mut v436_7_cursor = (*s0).read_zipper();
  for v436_7_byte in v436_7_cursor.child_mask().iter() {
    v436_7_cursor.descend_to_byte(v436_7_byte);
    let v436_7_tail = v436_7_cursor.make_map();
    v436_7_cursor.ascend(1);
    let v436_7_head = Path::from_slice(&[v436_7_byte]);
    let v437_2: Space = singleton(&(v436_7_head));
    let v437_3: Space = intersect(&(*CONSTANT_2),&(v437_2));
    let v437_4: Space = if has_head(&(v437_3)) { singleton(&[]) } else { Space::new() };
    drop(v437_3);
    let v437_5: Space = subtract(&(*CONSTANT_1),&(v437_4));
    drop(v437_4);
    let mut v437_6 = Space::new();
    let mut v437_6_cursor = (v436_7_tail).read_zipper();
    for v437_6_byte in v437_6_cursor.child_mask().iter() {
      v437_6_cursor.descend_to_byte(v437_6_byte);
      let v437_6_tail = v437_6_cursor.make_map();
      v437_6_cursor.ascend(1);
      let v437_6_head = Path::from_slice(&[v437_6_byte]);
      let v438_2: Space = Space::new();
      v437_6.join_into((v438_2).clone());
    }
    drop(v437_6_cursor);
    let v437_7: Space = compose(&(v437_5),&(v437_6));
    drop(v437_5);
    drop(v437_6);
    let v437_8: Space = intersect(&(*CONSTANT_2),&(v437_2));
    drop(v437_2);
    let v437_9: Space = if has_head(&(v437_8)) { singleton(&[]) } else { Space::new() };
    drop(v437_8);
    let v437_12: Space = if (v437_9).is_empty() { Space::new() } else {
      let v439_10: Path = concat_path(&(*p0),&(v436_7_head));
      let mut v439_11 = Space::new();
      let mut v439_11_cursor = (v436_7_tail).read_zipper();
      for v439_11_byte in v439_11_cursor.child_mask().iter() {
        v439_11_cursor.descend_to_byte(v439_11_byte);
        let v439_11_tail = v439_11_cursor.make_map();
        v439_11_cursor.ascend(1);
        let v439_11_head = Path::from_slice(&[v439_11_byte]);
        let v440_2: Space = singleton(&(v439_11_head));
        let v440_3: Space = intersect(&(*CONSTANT_2),&(v440_2));
        drop(v440_2);
        let v440_4: Space = if has_head(&(v440_3)) { singleton(&[]) } else { Space::new() };
        drop(v440_3);
        let v440_7: Space = if (v440_4).is_empty() { Space::new() } else {
          let v441_5: Path = concat_path(&(v439_10),&(v439_11_head));
          let v441_6: Space = routine_21(c, &(v441_5), &(*p1), &(v439_11_tail));
          drop(v441_5);
          compose(&(v440_4),&(v441_6))
        };
        drop(v440_4);
        v439_11.join_into((v440_7).clone());
      }
      drop(v439_11_cursor);
      drop(v439_10);
      compose(&(v437_9),&(v439_11))
    };
    drop(v437_9);
    let v437_13: Space = unite(&(v437_7),&(v437_12));
    drop(v437_7);
    v436_7.join_into((v437_13).clone());
  }
  drop(v436_7_cursor);
  (v436_7).clone()
}

fn routine_51(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v442_6 = Space::new();
  let mut v442_6_cursor = (*s0).read_zipper();
  for v442_6_byte in v442_6_cursor.child_mask().iter() {
    v442_6_cursor.descend_to_byte(v442_6_byte);
    let v442_6_tail = v442_6_cursor.make_map();
    v442_6_cursor.ascend(1);
    let v442_6_head = Path::from_slice(&[v442_6_byte]);
    let v443_2: Space = singleton(&(v442_6_head));
    let v443_3: Space = intersect(&(*CONSTANT_2),&(v443_2));
    let v443_4: Space = if has_head(&(v443_3)) { singleton(&[]) } else { Space::new() };
    drop(v443_3);
    let v443_5: Space = subtract(&(*CONSTANT_1),&(v443_4));
    drop(v443_4);
    let mut v443_6 = Space::new();
    let mut v443_6_cursor = (v442_6_tail).read_zipper();
    for v443_6_byte in v443_6_cursor.child_mask().iter() {
      v443_6_cursor.descend_to_byte(v443_6_byte);
      let v443_6_tail = v443_6_cursor.make_map();
      v443_6_cursor.ascend(1);
      let v443_6_head = Path::from_slice(&[v443_6_byte]);
      let v444_2: Space = Space::new();
      v443_6.join_into((v444_2).clone());
    }
    drop(v443_6_cursor);
    let v443_7: Space = compose(&(v443_5),&(v443_6));
    drop(v443_5);
    drop(v443_6);
    let v443_8: Space = intersect(&(*CONSTANT_2),&(v443_2));
    drop(v443_2);
    let v443_9: Space = if has_head(&(v443_8)) { singleton(&[]) } else { Space::new() };
    drop(v443_8);
    let v443_10: Space = compose(&(v443_9),&(v442_6_tail));
    drop(v443_9);
    let v443_11: Path = concat_path(&(*p0),&(v442_6_head));
    let v443_12: Space = wrap(&(v443_10),&(v443_11));
    drop(v443_10);
    drop(v443_11);
    let v443_13: Space = wrap(&(v443_12),&(*p1));
    drop(v443_12);
    let v443_14: Space = unite(&(v443_7),&(v443_13));
    drop(v443_7);
    drop(v443_13);
    v442_6.join_into((v443_14).clone());
  }
  drop(v442_6_cursor);
  (v442_6).clone()
}

fn routine_52(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v445_3 = Space::new();
  let mut v445_3_cursor = (*s0).read_zipper();
  for v445_3_byte in v445_3_cursor.child_mask().iter() {
    v445_3_cursor.descend_to_byte(v445_3_byte);
    let v445_3_tail = v445_3_cursor.make_map();
    v445_3_cursor.ascend(1);
    let v445_3_head = Path::from_slice(&[v445_3_byte]);
    let v446_2: Space = Space::new();
    v445_3.join_into((v446_2).clone());
  }
  drop(v445_3_cursor);
  (v445_3).clone()
}

fn routine_53(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v447_4 = Space::new();
  let mut v447_4_cursor = (*s0).read_zipper();
  for v447_4_byte in v447_4_cursor.child_mask().iter() {
    v447_4_cursor.descend_to_byte(v447_4_byte);
    let v447_4_tail = v447_4_cursor.make_map();
    v447_4_cursor.ascend(1);
    let v447_4_head = Path::from_slice(&[v447_4_byte]);
    let v448_2: Space = singleton(&(v447_4_head));
    let v448_3: Space = intersect(&(*CONSTANT_2),&(v448_2));
    drop(v448_2);
    let v448_4: Space = if has_head(&(v448_3)) { singleton(&[]) } else { Space::new() };
    drop(v448_3);
    let v448_5: Space = compose(&(v448_4),&(v447_4_tail));
    drop(v448_4);
    let v448_6: Path = concat_path(&(*p0),&(v447_4_head));
    let v448_7: Space = wrap(&(v448_5),&(v448_6));
    drop(v448_5);
    drop(v448_6);
    v447_4.join_into((v448_7).clone());
  }
  drop(v447_4_cursor);
  let v447_5: Space = wrap(&(v447_4),&(*p1));
  drop(v447_4);
  (v447_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
