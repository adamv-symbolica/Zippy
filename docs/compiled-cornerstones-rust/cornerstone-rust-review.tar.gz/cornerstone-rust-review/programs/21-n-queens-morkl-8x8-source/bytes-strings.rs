#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[49,0]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[50,0]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[51,0]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[52,0]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[53,0]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[54,0]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[55,0]));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[56,0]));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 2 49 0 2 50 0 2 51 0 2 52 0 2 53 0 2 54 0 2 55 0 2 56 0"));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[49]));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[50]));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[51]));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[52]));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[53]));
static CONSTANT_16: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[54]));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[55]));
static CONSTANT_18: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[56]));
static CONSTANT_19: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("64 4 49 0 49 0 4 49 0 50 0 4 49 0 51 0 4 49 0 52 0 4 49 0 53 0 4 49 0 54 0 4 49 0 55 0 4 49 0 56 0 4 50 0 49 0 4 50 0 50 0 4 50 0 51 0 4 50 0 52 0 4 50 0 53 0 4 50 0 54 0 4 50 0 55 0 4 50 0 56 0 4 51 0 49 0 4 51 0 50 0 4 51 0 51 0 4 51 0 52 0 4 51 0 53 0 4 51 0 54 0 4 51 0 55 0 4 51 0 56 0 4 52 0 49 0 4 52 0 50 0 4 52 0 51 0 4 52 0 52 0 4 52 0 53 0 4 52 0 54 0 4 52 0 55 0 4 52 0 56 0 4 53 0 49 0 4 53 0 50 0 4 53 0 51 0 4 53 0 52 0 4 53 0 53 0 4 53 0 54 0 4 53 0 55 0 4 53 0 56 0 4 54 0 49 0 4 54 0 50 0 4 54 0 51 0 4 54 0 52 0 4 54 0 53 0 4 54 0 54 0 4 54 0 55 0 4 54 0 56 0 4 55 0 49 0 4 55 0 50 0 4 55 0 51 0 4 55 0 52 0 4 55 0 53 0 4 55 0 54 0 4 55 0 55 0 4 55 0 56 0 4 56 0 49 0 4 56 0 50 0 4 56 0 51 0 4 56 0 52 0 4 56 0 53 0 4 56 0 54 0 4 56 0 55 0 4 56 0 56 0"));
static CONSTANT_20: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("100 6 49 0 49 0 48 0 6 49 0 49 0 50 0 6 49 0 50 0 51 0 6 49 0 51 0 52 0 6 49 0 52 0 53 0 6 49 0 53 0 54 0 6 49 0 54 0 55 0 6 49 0 55 0 56 0 6 49 0 56 0 57 0 6 50 0 49 0 49 0 6 50 0 49 0 51 0 6 50 0 50 0 48 0 6 50 0 50 0 52 0 6 50 0 51 0 53 0 6 50 0 52 0 54 0 6 50 0 53 0 55 0 6 50 0 54 0 56 0 6 50 0 55 0 57 0 7 50 0 56 0 49 48 0 6 51 0 49 0 50 0 6 51 0 49 0 52 0 6 51 0 50 0 49 0 6 51 0 50 0 53 0 6 51 0 51 0 48 0 6 51 0 51 0 54 0 6 51 0 52 0 55 0 6 51 0 53 0 56 0 6 51 0 54 0 57 0 7 51 0 55 0 49 48 0 7 51 0 56 0 49 49 0 6 52 0 49 0 51 0 6 52 0 49 0 53 0 6 52 0 50 0 50 0 6 52 0 50 0 54 0 6 52 0 51 0 49 0 6 52 0 51 0 55 0 6 52 0 52 0 48 0 6 52 0 52 0 56 0 6 52 0 53 0 57 0 7 52 0 54 0 49 48 0 7 52 0 55 0 49 49 0 7 52 0 56 0 49 50 0 6 53 0 49 0 52 0 6 53 0 49 0 54 0 6 53 0 50 0 51 0 6 53 0 50 0 55 0 6 53 0 51 0 50 0 6 53 0 51 0 56 0 6 53 0 52 0 49 0 6 53 0 52 0 57 0 6 53 0 53 0 48 0 7 53 0 53 0 49 48 0 7 53 0 54 0 49 49 0 7 53 0 55 0 49 50 0 7 53 0 56 0 49 51 0 6 54 0 49 0 53 0 6 54 0 49 0 55 0 6 54 0 50 0 52 0 6 54 0 50 0 56 0 6 54 0 51 0 51 0 6 54 0 51 0 57 0 7 54 0 52 0 49 48 0 6 54 0 52 0 50 0 6 54 0 53 0 49 0 7 54 0 53 0 49 49 0 6 54 0 54 0 48 0 7 54 0 54 0 49 50 0 7 54 0 55 0 49 51 0 7 54 0 56 0 49 52 0 6 55 0 49 0 54 0 6 55 0 49 0 56 0 6 55 0 50 0 53 0 6 55 0 50 0 57 0 7 55 0 51 0 49 48 0 6 55 0 51 0 52 0 7 55 0 52 0 49 49 0 6 55 0 52 0 51 0 7 55 0 53 0 49 50 0 6 55 0 53 0 50 0 6 55 0 54 0 49 0 7 55 0 54 0 49 51 0 6 55 0 55 0 48 0 7 55 0 55 0 49 52 0 7 55 0 56 0 49 53 0 6 56 0 49 0 55 0 6 56 0 49 0 57 0 7 56 0 50 0 49 48 0 6 56 0 50 0 54 0 7 56 0 51 0 49 49 0 6 56 0 51 0 53 0 7 56 0 52 0 49 50 0 6 56 0 52 0 52 0 7 56 0 53 0 49 51 0 6 56 0 53 0 51 0 7 56 0 54 0 49 52 0 6 56 0 54 0 50 0 6 56 0 55 0 49 0 7 56 0 55 0 49 53 0 6 56 0 56 0 48 0 7 56 0 56 0 49 54 0"));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 4 49 0 49 0 4 50 0 49 0 4 50 0 50 0 4 51 0 49 0 4 51 0 50 0 4 51 0 51 0 4 52 0 49 0 4 52 0 50 0 4 52 0 51 0 4 52 0 52 0 4 53 0 49 0 4 53 0 50 0 4 53 0 51 0 4 53 0 52 0 4 53 0 53 0 4 54 0 49 0 4 54 0 50 0 4 54 0 51 0 4 54 0 52 0 4 54 0 53 0 4 54 0 54 0 4 55 0 49 0 4 55 0 50 0 4 55 0 51 0 4 55 0 52 0 4 55 0 53 0 4 55 0 54 0 4 55 0 55 0 4 56 0 49 0 4 56 0 50 0 4 56 0 51 0 4 56 0 52 0 4 56 0 53 0 4 56 0 54 0 4 56 0 55 0 4 56 0 56 0"));
#[inline(never)]
fn native_block_0(c: &mut Context) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v0_34: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v1_33: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v2_4: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_0));
      let v2_7: Space = routine_1(c, &(*CONSTANT_2), &(*CONSTANT_0));
      let v2_8: Space = unite(&(v2_4),&(v2_7));
      let v2_11: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_0));
      let v2_12: Space = unite(&(v2_8),&(v2_11));
      let v2_15: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_0));
      let v2_16: Space = unite(&(v2_12),&(v2_15));
      let v2_19: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_0));
      let v2_20: Space = unite(&(v2_16),&(v2_19));
      let v2_23: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_0));
      let v2_24: Space = unite(&(v2_20),&(v2_23));
      let v2_27: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_0));
      let v2_28: Space = unite(&(v2_24),&(v2_27));
      let v2_31: Space = routine_1(c, &(*CONSTANT_8), &(*CONSTANT_0));
      let v2_32: Space = unite(&(v2_28),&(v2_31));
      compose(&(*CONSTANT_0),&(v2_32))
    };
    compose(&(*CONSTANT_0),&(v1_33))
  };
  let mut v0_45 = Space::new();
  let mut v0_45_cursor = (v0_34).read_zipper();
  for v0_45_byte in v0_45_cursor.child_mask().iter() {
    v0_45_cursor.descend_to_byte(v0_45_byte);
    let v0_45_tail = v0_45_cursor.make_map();
    v0_45_cursor.ascend(1);
    let v0_45_head = Path::from_slice(&[v0_45_byte]);
    let v3_2: Space = singleton(&(v0_45_head));
    let v3_3: Space = intersect(&(*CONSTANT_9),&(v3_2));
    let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
    drop(v3_3);
    let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
    drop(v3_4);
    let v3_7: Space = if (v3_5).is_empty() { Space::new() } else {
      let mut v4_6 = Space::new();
      let mut v4_6_cursor = (v0_45_tail).read_zipper();
      for v4_6_byte in v4_6_cursor.child_mask().iter() {
        v4_6_cursor.descend_to_byte(v4_6_byte);
        let v4_6_tail = v4_6_cursor.make_map();
        v4_6_cursor.ascend(1);
        let v4_6_head = Path::from_slice(&[v4_6_byte]);
        let v5_2: Space = singleton(&(v4_6_head));
        let v5_3: Space = intersect(&(*CONSTANT_9),&(v5_2));
        let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
        drop(v5_3);
        let v5_5: Space = subtract(&(*CONSTANT_0),&(v5_4));
        drop(v5_4);
        let v5_8: Space = if (v5_5).is_empty() { Space::new() } else {
          let v6_6: Path = concat_path(&(v0_45_head),&(v4_6_head));
          let v6_7: Space = routine_2(c, &(v6_6), &(v4_6_tail));
          compose(&(v5_5),&(v6_7))
        };
        drop(v5_5);
        let v5_9: Space = intersect(&(*CONSTANT_9),&(v5_2));
        drop(v5_2);
        let v5_10: Space = if has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
        drop(v5_9);
        let v5_12: Space = if (v5_10).is_empty() { Space::new() } else {
          let v7_6: Path = concat_path(&(v0_45_head),&(v4_6_head));
          let v7_11: Space = routine_3(c, &(v7_6), &(v4_6_tail));
          drop(v7_6);
          compose(&(v5_10),&(v7_11))
        };
        drop(v5_10);
        let v5_13: Space = unite(&(v5_8),&(v5_12));
        v4_6.join_into((v5_13).clone());
      }
      drop(v4_6_cursor);
      compose(&(v3_5),&(v4_6))
    };
    drop(v3_5);
    let v3_8: Space = intersect(&(*CONSTANT_9),&(v3_2));
    drop(v3_2);
    let v3_9: Space = if has_head(&(v3_8)) { singleton(&[]) } else { Space::new() };
    drop(v3_8);
    let v3_13: Space = if (v3_9).is_empty() { Space::new() } else {
      let v8_10: Space = unwrap(&(v0_45_tail),&(*CONSTANT_2));
      let v8_11: Space = subtract(&(*CONSTANT_10),&(v8_10));
      drop(v8_10);
      let mut v8_12 = Space::new();
      let mut v8_12_cursor = (v8_11).read_zipper();
      for v8_12_byte in v8_12_cursor.child_mask().iter() {
        v8_12_cursor.descend_to_byte(v8_12_byte);
        let v8_12_tail = v8_12_cursor.make_map();
        v8_12_cursor.ascend(1);
        let v8_12_head = Path::from_slice(&[v8_12_byte]);
        let v9_2: Space = singleton(&(v8_12_head));
        let v9_3: Space = intersect(&(*CONSTANT_9),&(v9_2));
        let v9_4: Space = if has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
        drop(v9_3);
        let v9_5: Space = subtract(&(*CONSTANT_0),&(v9_4));
        drop(v9_4);
        let v9_7: Space = if (v9_5).is_empty() { Space::new() } else {
          let v10_6: Space = routine_4(c, &(v8_12_head), &(v0_45_head), &(v8_12_tail), &(v0_45_tail));
          compose(&(v9_5),&(v10_6))
        };
        drop(v9_5);
        let v9_8: Space = intersect(&(*CONSTANT_9),&(v9_2));
        drop(v9_2);
        let v9_9: Space = if has_head(&(v9_8)) { singleton(&[]) } else { Space::new() };
        drop(v9_8);
        let v9_11: Space = if (v9_9).is_empty() { Space::new() } else {
          let v11_10: Space = routine_5(c, &(v8_12_head), &(v0_45_head), &(v8_12_tail), &(v0_45_tail));
          compose(&(v9_9),&(v11_10))
        };
        drop(v9_9);
        let v9_12: Space = unite(&(v9_7),&(v9_11));
        v8_12.join_into((v9_12).clone());
      }
      drop(v8_12_cursor);
      drop(v8_11);
      compose(&(v3_9),&(v8_12))
    };
    drop(v3_9);
    let v3_14: Space = unite(&(v3_7),&(v3_13));
    v0_45.join_into((v3_14).clone());
  }
  drop(v0_45_cursor);
  let mut v0_55 = Space::new();
  let mut v0_55_cursor = (v0_45).read_zipper();
  for v0_55_byte in v0_55_cursor.child_mask().iter() {
    v0_55_cursor.descend_to_byte(v0_55_byte);
    let v0_55_tail = v0_55_cursor.make_map();
    v0_55_cursor.ascend(1);
    let v0_55_head = Path::from_slice(&[v0_55_byte]);
    let v12_2: Space = singleton(&(v0_55_head));
    let v12_3: Space = intersect(&(*CONSTANT_9),&(v12_2));
    let v12_4: Space = if has_head(&(v12_3)) { singleton(&[]) } else { Space::new() };
    drop(v12_3);
    let v12_5: Space = subtract(&(*CONSTANT_0),&(v12_4));
    drop(v12_4);
    let v12_7: Space = if (v12_5).is_empty() { Space::new() } else {
      let mut v13_6 = Space::new();
      let mut v13_6_cursor = (v0_55_tail).read_zipper();
      for v13_6_byte in v13_6_cursor.child_mask().iter() {
        v13_6_cursor.descend_to_byte(v13_6_byte);
        let v13_6_tail = v13_6_cursor.make_map();
        v13_6_cursor.ascend(1);
        let v13_6_head = Path::from_slice(&[v13_6_byte]);
        let v14_2: Space = singleton(&(v13_6_head));
        let v14_3: Space = intersect(&(*CONSTANT_9),&(v14_2));
        let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
        drop(v14_3);
        let v14_5: Space = subtract(&(*CONSTANT_0),&(v14_4));
        drop(v14_4);
        let v14_8: Space = if (v14_5).is_empty() { Space::new() } else {
          let v15_6: Path = concat_path(&(v0_55_head),&(v13_6_head));
          let v15_7: Space = routine_6(c, &(v15_6), &(v13_6_tail));
          compose(&(v14_5),&(v15_7))
        };
        drop(v14_5);
        let v14_9: Space = intersect(&(*CONSTANT_9),&(v14_2));
        drop(v14_2);
        let v14_10: Space = if has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
        drop(v14_9);
        let v14_12: Space = if (v14_10).is_empty() { Space::new() } else {
          let v16_6: Path = concat_path(&(v0_55_head),&(v13_6_head));
          let v16_11: Space = routine_7(c, &(v16_6), &(v13_6_tail));
          drop(v16_6);
          compose(&(v14_10),&(v16_11))
        };
        drop(v14_10);
        let v14_13: Space = unite(&(v14_8),&(v14_12));
        v13_6.join_into((v14_13).clone());
      }
      drop(v13_6_cursor);
      compose(&(v12_5),&(v13_6))
    };
    drop(v12_5);
    let v12_8: Space = intersect(&(*CONSTANT_9),&(v12_2));
    drop(v12_2);
    let v12_9: Space = if has_head(&(v12_8)) { singleton(&[]) } else { Space::new() };
    drop(v12_8);
    let v12_11: Space = if (v12_9).is_empty() { Space::new() } else {
      let mut v17_10 = Space::new();
      let mut v17_10_cursor = (v0_55_tail).read_zipper();
      for v17_10_byte in v17_10_cursor.child_mask().iter() {
        v17_10_cursor.descend_to_byte(v17_10_byte);
        let v17_10_tail = v17_10_cursor.make_map();
        v17_10_cursor.ascend(1);
        let v17_10_head = Path::from_slice(&[v17_10_byte]);
        let v18_2: Space = singleton(&(v17_10_head));
        let v18_3: Space = intersect(&(*CONSTANT_9),&(v18_2));
        let v18_4: Space = if has_head(&(v18_3)) { singleton(&[]) } else { Space::new() };
        drop(v18_3);
        let v18_5: Space = subtract(&(*CONSTANT_0),&(v18_4));
        drop(v18_4);
        let v18_7: Space = if (v18_5).is_empty() { Space::new() } else {
          let v19_6: Space = routine_8(c, &(v17_10_head), &(v0_55_head), &(v17_10_tail));
          compose(&(v18_5),&(v19_6))
        };
        drop(v18_5);
        let v18_8: Space = intersect(&(*CONSTANT_9),&(v18_2));
        drop(v18_2);
        let v18_9: Space = if has_head(&(v18_8)) { singleton(&[]) } else { Space::new() };
        drop(v18_8);
        let v18_11: Space = if (v18_9).is_empty() { Space::new() } else {
          let v20_10: Space = routine_9(c, &(v17_10_head), &(v0_55_head), &(v17_10_tail));
          compose(&(v18_9),&(v20_10))
        };
        drop(v18_9);
        let v18_12: Space = unite(&(v18_7),&(v18_11));
        v17_10.join_into((v18_12).clone());
      }
      drop(v17_10_cursor);
      compose(&(v12_9),&(v17_10))
    };
    drop(v12_9);
    let v12_12: Space = unite(&(v12_7),&(v12_11));
    v0_55.join_into((v12_12).clone());
  }
  drop(v0_55_cursor);
  let mut v0_65 = Space::new();
  let mut v0_65_cursor = (v0_55).read_zipper();
  for v0_65_byte in v0_65_cursor.child_mask().iter() {
    v0_65_cursor.descend_to_byte(v0_65_byte);
    let v0_65_tail = v0_65_cursor.make_map();
    v0_65_cursor.ascend(1);
    let v0_65_head = Path::from_slice(&[v0_65_byte]);
    let v21_2: Space = singleton(&(v0_65_head));
    let v21_3: Space = intersect(&(*CONSTANT_9),&(v21_2));
    let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
    drop(v21_3);
    let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
    drop(v21_4);
    let v21_7: Space = if (v21_5).is_empty() { Space::new() } else {
      let mut v22_6 = Space::new();
      let mut v22_6_cursor = (v0_65_tail).read_zipper();
      for v22_6_byte in v22_6_cursor.child_mask().iter() {
        v22_6_cursor.descend_to_byte(v22_6_byte);
        let v22_6_tail = v22_6_cursor.make_map();
        v22_6_cursor.ascend(1);
        let v22_6_head = Path::from_slice(&[v22_6_byte]);
        let v23_2: Space = singleton(&(v22_6_head));
        let v23_3: Space = intersect(&(*CONSTANT_9),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v0_65_head),&(v22_6_head));
          let v24_7: Space = routine_10(c, &(v24_6), &(v22_6_tail));
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_9),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_12: Space = if (v23_10).is_empty() { Space::new() } else {
          let v25_6: Path = concat_path(&(v0_65_head),&(v22_6_head));
          let v25_11: Space = routine_11(c, &(v25_6), &(v22_6_tail));
          drop(v25_6);
          compose(&(v23_10),&(v25_11))
        };
        drop(v23_10);
        let v23_13: Space = unite(&(v23_8),&(v23_12));
        v22_6.join_into((v23_13).clone());
      }
      drop(v22_6_cursor);
      compose(&(v21_5),&(v22_6))
    };
    drop(v21_5);
    let v21_8: Space = intersect(&(*CONSTANT_9),&(v21_2));
    drop(v21_2);
    let v21_9: Space = if has_head(&(v21_8)) { singleton(&[]) } else { Space::new() };
    drop(v21_8);
    let v21_11: Space = if (v21_9).is_empty() { Space::new() } else {
      let mut v26_10 = Space::new();
      let mut v26_10_cursor = (v0_65_tail).read_zipper();
      for v26_10_byte in v26_10_cursor.child_mask().iter() {
        v26_10_cursor.descend_to_byte(v26_10_byte);
        let v26_10_tail = v26_10_cursor.make_map();
        v26_10_cursor.ascend(1);
        let v26_10_head = Path::from_slice(&[v26_10_byte]);
        let v27_2: Space = singleton(&(v26_10_head));
        let v27_3: Space = intersect(&(*CONSTANT_9),&(v27_2));
        let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
        drop(v27_3);
        let v27_5: Space = subtract(&(*CONSTANT_0),&(v27_4));
        drop(v27_4);
        let v27_7: Space = if (v27_5).is_empty() { Space::new() } else {
          let v28_6: Space = routine_12(c, &(v26_10_head), &(v0_65_head), &(v26_10_tail));
          compose(&(v27_5),&(v28_6))
        };
        drop(v27_5);
        let v27_8: Space = intersect(&(*CONSTANT_9),&(v27_2));
        drop(v27_2);
        let v27_9: Space = if has_head(&(v27_8)) { singleton(&[]) } else { Space::new() };
        drop(v27_8);
        let v27_11: Space = if (v27_9).is_empty() { Space::new() } else {
          let v29_10: Space = routine_13(c, &(v26_10_head), &(v0_65_head), &(v26_10_tail));
          compose(&(v27_9),&(v29_10))
        };
        drop(v27_9);
        let v27_12: Space = unite(&(v27_7),&(v27_11));
        v26_10.join_into((v27_12).clone());
      }
      drop(v26_10_cursor);
      compose(&(v21_9),&(v26_10))
    };
    drop(v21_9);
    let v21_12: Space = unite(&(v21_7),&(v21_11));
    v0_65.join_into((v21_12).clone());
  }
  drop(v0_65_cursor);
  let mut v0_75 = Space::new();
  let mut v0_75_cursor = (v0_65).read_zipper();
  for v0_75_byte in v0_75_cursor.child_mask().iter() {
    v0_75_cursor.descend_to_byte(v0_75_byte);
    let v0_75_tail = v0_75_cursor.make_map();
    v0_75_cursor.ascend(1);
    let v0_75_head = Path::from_slice(&[v0_75_byte]);
    let v30_2: Space = singleton(&(v0_75_head));
    let v30_3: Space = intersect(&(*CONSTANT_9),&(v30_2));
    let v30_4: Space = if has_head(&(v30_3)) { singleton(&[]) } else { Space::new() };
    drop(v30_3);
    let v30_5: Space = subtract(&(*CONSTANT_0),&(v30_4));
    drop(v30_4);
    let v30_7: Space = if (v30_5).is_empty() { Space::new() } else {
      let mut v31_6 = Space::new();
      let mut v31_6_cursor = (v0_75_tail).read_zipper();
      for v31_6_byte in v31_6_cursor.child_mask().iter() {
        v31_6_cursor.descend_to_byte(v31_6_byte);
        let v31_6_tail = v31_6_cursor.make_map();
        v31_6_cursor.ascend(1);
        let v31_6_head = Path::from_slice(&[v31_6_byte]);
        let v32_2: Space = singleton(&(v31_6_head));
        let v32_3: Space = intersect(&(*CONSTANT_9),&(v32_2));
        let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
        drop(v32_3);
        let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
        drop(v32_4);
        let v32_8: Space = if (v32_5).is_empty() { Space::new() } else {
          let v33_6: Path = concat_path(&(v0_75_head),&(v31_6_head));
          let v33_7: Space = routine_14(c, &(v33_6), &(v31_6_tail));
          compose(&(v32_5),&(v33_7))
        };
        drop(v32_5);
        let v32_9: Space = intersect(&(*CONSTANT_9),&(v32_2));
        drop(v32_2);
        let v32_10: Space = if has_head(&(v32_9)) { singleton(&[]) } else { Space::new() };
        drop(v32_9);
        let v32_12: Space = if (v32_10).is_empty() { Space::new() } else {
          let v34_6: Path = concat_path(&(v0_75_head),&(v31_6_head));
          let v34_11: Space = routine_15(c, &(v34_6), &(v31_6_tail));
          drop(v34_6);
          compose(&(v32_10),&(v34_11))
        };
        drop(v32_10);
        let v32_13: Space = unite(&(v32_8),&(v32_12));
        v31_6.join_into((v32_13).clone());
      }
      drop(v31_6_cursor);
      compose(&(v30_5),&(v31_6))
    };
    drop(v30_5);
    let v30_8: Space = intersect(&(*CONSTANT_9),&(v30_2));
    drop(v30_2);
    let v30_9: Space = if has_head(&(v30_8)) { singleton(&[]) } else { Space::new() };
    drop(v30_8);
    let v30_11: Space = if (v30_9).is_empty() { Space::new() } else {
      let mut v35_10 = Space::new();
      let mut v35_10_cursor = (v0_75_tail).read_zipper();
      for v35_10_byte in v35_10_cursor.child_mask().iter() {
        v35_10_cursor.descend_to_byte(v35_10_byte);
        let v35_10_tail = v35_10_cursor.make_map();
        v35_10_cursor.ascend(1);
        let v35_10_head = Path::from_slice(&[v35_10_byte]);
        let v36_2: Space = singleton(&(v35_10_head));
        let v36_3: Space = intersect(&(*CONSTANT_9),&(v36_2));
        let v36_4: Space = if has_head(&(v36_3)) { singleton(&[]) } else { Space::new() };
        drop(v36_3);
        let v36_5: Space = subtract(&(*CONSTANT_0),&(v36_4));
        drop(v36_4);
        let v36_7: Space = if (v36_5).is_empty() { Space::new() } else {
          let v37_6: Space = routine_16(c, &(v35_10_head), &(v0_75_head), &(v35_10_tail));
          compose(&(v36_5),&(v37_6))
        };
        drop(v36_5);
        let v36_8: Space = intersect(&(*CONSTANT_9),&(v36_2));
        drop(v36_2);
        let v36_9: Space = if has_head(&(v36_8)) { singleton(&[]) } else { Space::new() };
        drop(v36_8);
        let v36_11: Space = if (v36_9).is_empty() { Space::new() } else {
          let v38_10: Space = routine_17(c, &(v35_10_head), &(v0_75_head), &(v35_10_tail));
          compose(&(v36_9),&(v38_10))
        };
        drop(v36_9);
        let v36_12: Space = unite(&(v36_7),&(v36_11));
        v35_10.join_into((v36_12).clone());
      }
      drop(v35_10_cursor);
      compose(&(v30_9),&(v35_10))
    };
    drop(v30_9);
    let v30_12: Space = unite(&(v30_7),&(v30_11));
    v0_75.join_into((v30_12).clone());
  }
  drop(v0_75_cursor);
  let mut v0_85 = Space::new();
  let mut v0_85_cursor = (v0_75).read_zipper();
  for v0_85_byte in v0_85_cursor.child_mask().iter() {
    v0_85_cursor.descend_to_byte(v0_85_byte);
    let v0_85_tail = v0_85_cursor.make_map();
    v0_85_cursor.ascend(1);
    let v0_85_head = Path::from_slice(&[v0_85_byte]);
    let v39_2: Space = singleton(&(v0_85_head));
    let v39_3: Space = intersect(&(*CONSTANT_9),&(v39_2));
    let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
    drop(v39_3);
    let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
    drop(v39_4);
    let v39_7: Space = if (v39_5).is_empty() { Space::new() } else {
      let mut v40_6 = Space::new();
      let mut v40_6_cursor = (v0_85_tail).read_zipper();
      for v40_6_byte in v40_6_cursor.child_mask().iter() {
        v40_6_cursor.descend_to_byte(v40_6_byte);
        let v40_6_tail = v40_6_cursor.make_map();
        v40_6_cursor.ascend(1);
        let v40_6_head = Path::from_slice(&[v40_6_byte]);
        let v41_2: Space = singleton(&(v40_6_head));
        let v41_3: Space = intersect(&(*CONSTANT_9),&(v41_2));
        let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
        drop(v41_3);
        let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
        drop(v41_4);
        let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
          let v42_6: Path = concat_path(&(v0_85_head),&(v40_6_head));
          let v42_7: Space = routine_18(c, &(v42_6), &(v40_6_tail));
          compose(&(v41_5),&(v42_7))
        };
        drop(v41_5);
        let v41_9: Space = intersect(&(*CONSTANT_9),&(v41_2));
        drop(v41_2);
        let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
        drop(v41_9);
        let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
          let v43_6: Path = concat_path(&(v0_85_head),&(v40_6_head));
          let v43_11: Space = routine_19(c, &(v43_6), &(v40_6_tail));
          drop(v43_6);
          compose(&(v41_10),&(v43_11))
        };
        drop(v41_10);
        let v41_13: Space = unite(&(v41_8),&(v41_12));
        v40_6.join_into((v41_13).clone());
      }
      drop(v40_6_cursor);
      compose(&(v39_5),&(v40_6))
    };
    drop(v39_5);
    let v39_8: Space = intersect(&(*CONSTANT_9),&(v39_2));
    drop(v39_2);
    let v39_9: Space = if has_head(&(v39_8)) { singleton(&[]) } else { Space::new() };
    drop(v39_8);
    let v39_11: Space = if (v39_9).is_empty() { Space::new() } else {
      let mut v44_10 = Space::new();
      let mut v44_10_cursor = (v0_85_tail).read_zipper();
      for v44_10_byte in v44_10_cursor.child_mask().iter() {
        v44_10_cursor.descend_to_byte(v44_10_byte);
        let v44_10_tail = v44_10_cursor.make_map();
        v44_10_cursor.ascend(1);
        let v44_10_head = Path::from_slice(&[v44_10_byte]);
        let v45_2: Space = singleton(&(v44_10_head));
        let v45_3: Space = intersect(&(*CONSTANT_9),&(v45_2));
        let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
        drop(v45_3);
        let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
        drop(v45_4);
        let v45_7: Space = if (v45_5).is_empty() { Space::new() } else {
          let v46_6: Space = routine_20(c, &(v44_10_head), &(v0_85_head), &(v44_10_tail));
          compose(&(v45_5),&(v46_6))
        };
        drop(v45_5);
        let v45_8: Space = intersect(&(*CONSTANT_9),&(v45_2));
        drop(v45_2);
        let v45_9: Space = if has_head(&(v45_8)) { singleton(&[]) } else { Space::new() };
        drop(v45_8);
        let v45_11: Space = if (v45_9).is_empty() { Space::new() } else {
          let v47_10: Space = routine_21(c, &(v44_10_head), &(v0_85_head), &(v44_10_tail));
          compose(&(v45_9),&(v47_10))
        };
        drop(v45_9);
        let v45_12: Space = unite(&(v45_7),&(v45_11));
        v44_10.join_into((v45_12).clone());
      }
      drop(v44_10_cursor);
      compose(&(v39_9),&(v44_10))
    };
    drop(v39_9);
    let v39_12: Space = unite(&(v39_7),&(v39_11));
    v0_85.join_into((v39_12).clone());
  }
  drop(v0_85_cursor);
  let mut v0_95 = Space::new();
  let mut v0_95_cursor = (v0_85).read_zipper();
  for v0_95_byte in v0_95_cursor.child_mask().iter() {
    v0_95_cursor.descend_to_byte(v0_95_byte);
    let v0_95_tail = v0_95_cursor.make_map();
    v0_95_cursor.ascend(1);
    let v0_95_head = Path::from_slice(&[v0_95_byte]);
    let v48_2: Space = singleton(&(v0_95_head));
    let v48_3: Space = intersect(&(*CONSTANT_9),&(v48_2));
    let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
    drop(v48_3);
    let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
    drop(v48_4);
    let v48_7: Space = if (v48_5).is_empty() { Space::new() } else {
      let mut v49_6 = Space::new();
      let mut v49_6_cursor = (v0_95_tail).read_zipper();
      for v49_6_byte in v49_6_cursor.child_mask().iter() {
        v49_6_cursor.descend_to_byte(v49_6_byte);
        let v49_6_tail = v49_6_cursor.make_map();
        v49_6_cursor.ascend(1);
        let v49_6_head = Path::from_slice(&[v49_6_byte]);
        let v50_2: Space = singleton(&(v49_6_head));
        let v50_3: Space = intersect(&(*CONSTANT_9),&(v50_2));
        let v50_4: Space = if has_head(&(v50_3)) { singleton(&[]) } else { Space::new() };
        drop(v50_3);
        let v50_5: Space = subtract(&(*CONSTANT_0),&(v50_4));
        drop(v50_4);
        let v50_8: Space = if (v50_5).is_empty() { Space::new() } else {
          let v51_6: Path = concat_path(&(v0_95_head),&(v49_6_head));
          let v51_7: Space = routine_22(c, &(v51_6), &(v49_6_tail));
          compose(&(v50_5),&(v51_7))
        };
        drop(v50_5);
        let v50_9: Space = intersect(&(*CONSTANT_9),&(v50_2));
        drop(v50_2);
        let v50_10: Space = if has_head(&(v50_9)) { singleton(&[]) } else { Space::new() };
        drop(v50_9);
        let v50_12: Space = if (v50_10).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v0_95_head),&(v49_6_head));
          let v52_11: Space = routine_23(c, &(v52_6), &(v49_6_tail));
          drop(v52_6);
          compose(&(v50_10),&(v52_11))
        };
        drop(v50_10);
        let v50_13: Space = unite(&(v50_8),&(v50_12));
        v49_6.join_into((v50_13).clone());
      }
      drop(v49_6_cursor);
      compose(&(v48_5),&(v49_6))
    };
    drop(v48_5);
    let v48_8: Space = intersect(&(*CONSTANT_9),&(v48_2));
    drop(v48_2);
    let v48_9: Space = if has_head(&(v48_8)) { singleton(&[]) } else { Space::new() };
    drop(v48_8);
    let v48_11: Space = if (v48_9).is_empty() { Space::new() } else {
      let mut v53_10 = Space::new();
      let mut v53_10_cursor = (v0_95_tail).read_zipper();
      for v53_10_byte in v53_10_cursor.child_mask().iter() {
        v53_10_cursor.descend_to_byte(v53_10_byte);
        let v53_10_tail = v53_10_cursor.make_map();
        v53_10_cursor.ascend(1);
        let v53_10_head = Path::from_slice(&[v53_10_byte]);
        let v54_2: Space = singleton(&(v53_10_head));
        let v54_3: Space = intersect(&(*CONSTANT_9),&(v54_2));
        let v54_4: Space = if has_head(&(v54_3)) { singleton(&[]) } else { Space::new() };
        drop(v54_3);
        let v54_5: Space = subtract(&(*CONSTANT_0),&(v54_4));
        drop(v54_4);
        let v54_7: Space = if (v54_5).is_empty() { Space::new() } else {
          let v55_6: Space = routine_24(c, &(v53_10_head), &(v0_95_head), &(v53_10_tail));
          compose(&(v54_5),&(v55_6))
        };
        drop(v54_5);
        let v54_8: Space = intersect(&(*CONSTANT_9),&(v54_2));
        drop(v54_2);
        let v54_9: Space = if has_head(&(v54_8)) { singleton(&[]) } else { Space::new() };
        drop(v54_8);
        let v54_11: Space = if (v54_9).is_empty() { Space::new() } else {
          let v56_10: Space = routine_25(c, &(v53_10_head), &(v0_95_head), &(v53_10_tail));
          compose(&(v54_9),&(v56_10))
        };
        drop(v54_9);
        let v54_12: Space = unite(&(v54_7),&(v54_11));
        v53_10.join_into((v54_12).clone());
      }
      drop(v53_10_cursor);
      compose(&(v48_9),&(v53_10))
    };
    drop(v48_9);
    let v48_12: Space = unite(&(v48_7),&(v48_11));
    v0_95.join_into((v48_12).clone());
  }
  drop(v0_95_cursor);
  let mut v0_105 = Space::new();
  let mut v0_105_cursor = (v0_95).read_zipper();
  for v0_105_byte in v0_105_cursor.child_mask().iter() {
    v0_105_cursor.descend_to_byte(v0_105_byte);
    let v0_105_tail = v0_105_cursor.make_map();
    v0_105_cursor.ascend(1);
    let v0_105_head = Path::from_slice(&[v0_105_byte]);
    let v57_2: Space = singleton(&(v0_105_head));
    let v57_3: Space = intersect(&(*CONSTANT_9),&(v57_2));
    let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
    drop(v57_3);
    let v57_5: Space = subtract(&(*CONSTANT_0),&(v57_4));
    drop(v57_4);
    let v57_7: Space = if (v57_5).is_empty() { Space::new() } else {
      let mut v58_6 = Space::new();
      let mut v58_6_cursor = (v0_105_tail).read_zipper();
      for v58_6_byte in v58_6_cursor.child_mask().iter() {
        v58_6_cursor.descend_to_byte(v58_6_byte);
        let v58_6_tail = v58_6_cursor.make_map();
        v58_6_cursor.ascend(1);
        let v58_6_head = Path::from_slice(&[v58_6_byte]);
        let v59_2: Space = singleton(&(v58_6_head));
        let v59_3: Space = intersect(&(*CONSTANT_9),&(v59_2));
        let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
        drop(v59_3);
        let v59_5: Space = subtract(&(*CONSTANT_0),&(v59_4));
        drop(v59_4);
        let v59_8: Space = if (v59_5).is_empty() { Space::new() } else {
          let v60_6: Path = concat_path(&(v0_105_head),&(v58_6_head));
          let v60_7: Space = routine_26(c, &(v60_6), &(v58_6_tail));
          compose(&(v59_5),&(v60_7))
        };
        drop(v59_5);
        let v59_9: Space = intersect(&(*CONSTANT_9),&(v59_2));
        drop(v59_2);
        let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
        drop(v59_9);
        let v59_12: Space = if (v59_10).is_empty() { Space::new() } else {
          let v61_6: Path = concat_path(&(v0_105_head),&(v58_6_head));
          let v61_11: Space = routine_27(c, &(v61_6), &(v58_6_tail));
          drop(v61_6);
          compose(&(v59_10),&(v61_11))
        };
        drop(v59_10);
        let v59_13: Space = unite(&(v59_8),&(v59_12));
        v58_6.join_into((v59_13).clone());
      }
      drop(v58_6_cursor);
      compose(&(v57_5),&(v58_6))
    };
    drop(v57_5);
    let v57_8: Space = intersect(&(*CONSTANT_9),&(v57_2));
    drop(v57_2);
    let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
    drop(v57_8);
    let v57_11: Space = if (v57_9).is_empty() { Space::new() } else {
      let mut v62_10 = Space::new();
      let mut v62_10_cursor = (v0_105_tail).read_zipper();
      for v62_10_byte in v62_10_cursor.child_mask().iter() {
        v62_10_cursor.descend_to_byte(v62_10_byte);
        let v62_10_tail = v62_10_cursor.make_map();
        v62_10_cursor.ascend(1);
        let v62_10_head = Path::from_slice(&[v62_10_byte]);
        let v63_2: Space = singleton(&(v62_10_head));
        let v63_3: Space = intersect(&(*CONSTANT_9),&(v63_2));
        let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
        drop(v63_3);
        let v63_5: Space = subtract(&(*CONSTANT_0),&(v63_4));
        drop(v63_4);
        let v63_7: Space = if (v63_5).is_empty() { Space::new() } else {
          let v64_6: Space = routine_28(c, &(v62_10_head), &(v0_105_head), &(v62_10_tail));
          compose(&(v63_5),&(v64_6))
        };
        drop(v63_5);
        let v63_8: Space = intersect(&(*CONSTANT_9),&(v63_2));
        drop(v63_2);
        let v63_9: Space = if has_head(&(v63_8)) { singleton(&[]) } else { Space::new() };
        drop(v63_8);
        let v63_11: Space = if (v63_9).is_empty() { Space::new() } else {
          let v65_10: Space = routine_29(c, &(v62_10_head), &(v0_105_head), &(v62_10_tail));
          compose(&(v63_9),&(v65_10))
        };
        drop(v63_9);
        let v63_12: Space = unite(&(v63_7),&(v63_11));
        v62_10.join_into((v63_12).clone());
      }
      drop(v62_10_cursor);
      compose(&(v57_9),&(v62_10))
    };
    drop(v57_9);
    let v57_12: Space = unite(&(v57_7),&(v57_11));
    v0_105.join_into((v57_12).clone());
  }
  drop(v0_105_cursor);
  let mut v0_115 = Space::new();
  let mut v0_115_cursor = (v0_105).read_zipper();
  for v0_115_byte in v0_115_cursor.child_mask().iter() {
    v0_115_cursor.descend_to_byte(v0_115_byte);
    let v0_115_tail = v0_115_cursor.make_map();
    v0_115_cursor.ascend(1);
    let v0_115_head = Path::from_slice(&[v0_115_byte]);
    let v66_2: Space = singleton(&(v0_115_head));
    let v66_3: Space = intersect(&(*CONSTANT_9),&(v66_2));
    let v66_4: Space = if has_head(&(v66_3)) { singleton(&[]) } else { Space::new() };
    drop(v66_3);
    let v66_5: Space = subtract(&(*CONSTANT_0),&(v66_4));
    drop(v66_4);
    let v66_7: Space = if (v66_5).is_empty() { Space::new() } else {
      let mut v67_6 = Space::new();
      let mut v67_6_cursor = (v0_115_tail).read_zipper();
      for v67_6_byte in v67_6_cursor.child_mask().iter() {
        v67_6_cursor.descend_to_byte(v67_6_byte);
        let v67_6_tail = v67_6_cursor.make_map();
        v67_6_cursor.ascend(1);
        let v67_6_head = Path::from_slice(&[v67_6_byte]);
        let v68_2: Space = singleton(&(v67_6_head));
        let v68_3: Space = intersect(&(*CONSTANT_9),&(v68_2));
        let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
        drop(v68_3);
        let v68_5: Space = subtract(&(*CONSTANT_0),&(v68_4));
        drop(v68_4);
        let v68_8: Space = if (v68_5).is_empty() { Space::new() } else {
          let v69_6: Path = concat_path(&(v0_115_head),&(v67_6_head));
          let v69_7: Space = routine_30(c, &(v69_6), &(v67_6_tail));
          compose(&(v68_5),&(v69_7))
        };
        drop(v68_5);
        let v68_9: Space = intersect(&(*CONSTANT_9),&(v68_2));
        drop(v68_2);
        let v68_10: Space = if has_head(&(v68_9)) { singleton(&[]) } else { Space::new() };
        drop(v68_9);
        let v68_12: Space = if (v68_10).is_empty() { Space::new() } else {
          let v70_6: Path = concat_path(&(v0_115_head),&(v67_6_head));
          let v70_11: Space = routine_31(c, &(v70_6), &(v67_6_tail));
          drop(v70_6);
          compose(&(v68_10),&(v70_11))
        };
        drop(v68_10);
        let v68_13: Space = unite(&(v68_8),&(v68_12));
        v67_6.join_into((v68_13).clone());
      }
      drop(v67_6_cursor);
      compose(&(v66_5),&(v67_6))
    };
    drop(v66_5);
    let v66_8: Space = intersect(&(*CONSTANT_9),&(v66_2));
    drop(v66_2);
    let v66_9: Space = if has_head(&(v66_8)) { singleton(&[]) } else { Space::new() };
    drop(v66_8);
    let v66_11: Space = if (v66_9).is_empty() { Space::new() } else {
      let mut v71_10 = Space::new();
      let mut v71_10_cursor = (v0_115_tail).read_zipper();
      for v71_10_byte in v71_10_cursor.child_mask().iter() {
        v71_10_cursor.descend_to_byte(v71_10_byte);
        let v71_10_tail = v71_10_cursor.make_map();
        v71_10_cursor.ascend(1);
        let v71_10_head = Path::from_slice(&[v71_10_byte]);
        let v72_2: Space = singleton(&(v71_10_head));
        let v72_3: Space = intersect(&(*CONSTANT_9),&(v72_2));
        let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
        drop(v72_3);
        let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
        drop(v72_4);
        let v72_7: Space = if (v72_5).is_empty() { Space::new() } else {
          let v73_6: Space = routine_32(c, &(v71_10_head), &(v0_115_head), &(v71_10_tail));
          compose(&(v72_5),&(v73_6))
        };
        drop(v72_5);
        let v72_8: Space = intersect(&(*CONSTANT_9),&(v72_2));
        drop(v72_2);
        let v72_9: Space = if has_head(&(v72_8)) { singleton(&[]) } else { Space::new() };
        drop(v72_8);
        let v72_11: Space = if (v72_9).is_empty() { Space::new() } else {
          let v74_10: Space = routine_33(c, &(v71_10_head), &(v0_115_head), &(v71_10_tail));
          compose(&(v72_9),&(v74_10))
        };
        drop(v72_9);
        let v72_12: Space = unite(&(v72_7),&(v72_11));
        v71_10.join_into((v72_12).clone());
      }
      drop(v71_10_cursor);
      compose(&(v66_9),&(v71_10))
    };
    drop(v66_9);
    let v66_12: Space = unite(&(v66_7),&(v66_11));
    v0_115.join_into((v66_12).clone());
  }
  drop(v0_115_cursor);

((v0_105).clone(),(v0_115).clone(),(v0_34).clone(),(v0_45).clone(),(v0_55).clone(),(v0_65).clone(),(v0_75).clone(),(v0_85).clone(),(v0_95).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let (v0_105,v0_115,v0_34,v0_45,v0_55,v0_65,v0_75,v0_85,v0_95,) = native_block_0(c);
  (v0_115).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v75_35: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v76_6: Space = routine_34(c, &(*CONSTANT_11), &(*CONSTANT_1), &(*p0), &(*CONSTANT_9));
    let v76_9: Space = routine_34(c, &(*CONSTANT_12), &(*CONSTANT_1), &(*p0), &(*CONSTANT_9));
    let v76_10: Space = unite(&(v76_6),&(v76_9));
    let v76_13: Space = routine_34(c, &(*CONSTANT_13), &(*CONSTANT_1), &(*p0), &(*CONSTANT_9));
    let v76_14: Space = unite(&(v76_10),&(v76_13));
    let v76_17: Space = routine_34(c, &(*CONSTANT_14), &(*CONSTANT_1), &(*p0), &(*CONSTANT_9));
    let v76_18: Space = unite(&(v76_14),&(v76_17));
    let v76_21: Space = routine_34(c, &(*CONSTANT_15), &(*CONSTANT_1), &(*p0), &(*CONSTANT_9));
    let v76_22: Space = unite(&(v76_18),&(v76_21));
    let v76_25: Space = routine_34(c, &(*CONSTANT_16), &(*CONSTANT_1), &(*p0), &(*CONSTANT_9));
    let v76_26: Space = unite(&(v76_22),&(v76_25));
    let v76_29: Space = routine_34(c, &(*CONSTANT_17), &(*CONSTANT_1), &(*p0), &(*CONSTANT_9));
    let v76_30: Space = unite(&(v76_26),&(v76_29));
    let v76_33: Space = routine_34(c, &(*CONSTANT_18), &(*CONSTANT_1), &(*p0), &(*CONSTANT_9));
    let v76_34: Space = unite(&(v76_30),&(v76_33));
    compose(&(*CONSTANT_0),&(v76_34))
  };
  let v75_37: Space = intersect(&(v75_35),&(*CONSTANT_19));
  let v75_39: Space = wrap(&(v75_37),&(*CONSTANT_20));
  let v75_40: Space = wrap(&(v75_39),&(*p0));
  (v75_40).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v77_10 = Space::new();
  let mut v77_10_cursor = (*s0).read_zipper();
  for v77_10_byte in v77_10_cursor.child_mask().iter() {
    v77_10_cursor.descend_to_byte(v77_10_byte);
    let v77_10_tail = v77_10_cursor.make_map();
    v77_10_cursor.ascend(1);
    let v77_10_head = Path::from_slice(&[v77_10_byte]);
    let v78_2: Space = singleton(&(v77_10_head));
    let v78_3: Space = intersect(&(*CONSTANT_9),&(v78_2));
    let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
    drop(v78_3);
    let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
    drop(v78_4);
    let v78_8: Space = if (v78_5).is_empty() { Space::new() } else {
      let v79_6: Path = concat_path(&(*p0),&(v77_10_head));
      let v79_7: Space = routine_2(c, &(v79_6), &(v77_10_tail));
      compose(&(v78_5),&(v79_7))
    };
    drop(v78_5);
    let v78_9: Space = intersect(&(*CONSTANT_9),&(v78_2));
    drop(v78_2);
    let v78_10: Space = if has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
    drop(v78_9);
    let v78_14: Space = if (v78_10).is_empty() { Space::new() } else {
      let v80_6: Path = concat_path(&(*p0),&(v77_10_head));
      let v80_11: Space = unwrap(&(v77_10_tail),&(*CONSTANT_2));
      let v80_12: Space = subtract(&(*CONSTANT_10),&(v80_11));
      drop(v80_11);
      let mut v80_13 = Space::new();
      let mut v80_13_cursor = (v80_12).read_zipper();
      for v80_13_byte in v80_13_cursor.child_mask().iter() {
        v80_13_cursor.descend_to_byte(v80_13_byte);
        let v80_13_tail = v80_13_cursor.make_map();
        v80_13_cursor.ascend(1);
        let v80_13_head = Path::from_slice(&[v80_13_byte]);
        let v81_2: Space = singleton(&(v80_13_head));
        let v81_3: Space = intersect(&(*CONSTANT_9),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_7: Space = if (v81_5).is_empty() { Space::new() } else {
          let v82_6: Space = routine_4(c, &(v80_13_head), &(v80_6), &(v80_13_tail), &(v77_10_tail));
          compose(&(v81_5),&(v82_6))
        };
        drop(v81_5);
        let v81_8: Space = intersect(&(*CONSTANT_9),&(v81_2));
        drop(v81_2);
        let v81_9: Space = if has_head(&(v81_8)) { singleton(&[]) } else { Space::new() };
        drop(v81_8);
        let v81_11: Space = if (v81_9).is_empty() { Space::new() } else {
          let v83_10: Space = routine_5(c, &(v80_13_head), &(v80_6), &(v80_13_tail), &(v77_10_tail));
          compose(&(v81_9),&(v83_10))
        };
        drop(v81_9);
        let v81_12: Space = unite(&(v81_7),&(v81_11));
        v80_13.join_into((v81_12).clone());
      }
      drop(v80_13_cursor);
      drop(v80_6);
      drop(v80_12);
      compose(&(v78_10),&(v80_13))
    };
    drop(v78_10);
    let v78_15: Space = unite(&(v78_8),&(v78_14));
    v77_10.join_into((v78_15).clone());
  }
  drop(v77_10_cursor);
  (v77_10).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v84_4: Space = unwrap(&(*s0),&(*CONSTANT_2));
  let v84_5: Space = subtract(&(*CONSTANT_10),&(v84_4));
  drop(v84_4);
  let mut v84_13 = Space::new();
  let mut v84_13_cursor = (v84_5).read_zipper();
  for v84_13_byte in v84_13_cursor.child_mask().iter() {
    v84_13_cursor.descend_to_byte(v84_13_byte);
    let v84_13_tail = v84_13_cursor.make_map();
    v84_13_cursor.ascend(1);
    let v84_13_head = Path::from_slice(&[v84_13_byte]);
    let v85_2: Space = singleton(&(v84_13_head));
    let v85_3: Space = intersect(&(*CONSTANT_9),&(v85_2));
    let v85_4: Space = if has_head(&(v85_3)) { singleton(&[]) } else { Space::new() };
    drop(v85_3);
    let v85_5: Space = subtract(&(*CONSTANT_0),&(v85_4));
    drop(v85_4);
    let v85_7: Space = if (v85_5).is_empty() { Space::new() } else {
      let mut v86_6 = Space::new();
      let mut v86_6_cursor = (v84_13_tail).read_zipper();
      for v86_6_byte in v86_6_cursor.child_mask().iter() {
        v86_6_cursor.descend_to_byte(v86_6_byte);
        let v86_6_tail = v86_6_cursor.make_map();
        v86_6_cursor.ascend(1);
        let v86_6_head = Path::from_slice(&[v86_6_byte]);
        let v87_2: Space = singleton(&(v86_6_head));
        let v87_3: Space = intersect(&(*CONSTANT_9),&(v87_2));
        let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
        drop(v87_3);
        let v87_5: Space = subtract(&(*CONSTANT_0),&(v87_4));
        drop(v87_4);
        let v87_8: Space = if (v87_5).is_empty() { Space::new() } else {
          let v88_6: Path = concat_path(&(v84_13_head),&(v86_6_head));
          let v88_7: Space = routine_4(c, &(v88_6), &(*p0), &(v86_6_tail), &(*s0));
          compose(&(v87_5),&(v88_7))
        };
        drop(v87_5);
        let v87_9: Space = intersect(&(*CONSTANT_9),&(v87_2));
        drop(v87_2);
        let v87_10: Space = if has_head(&(v87_9)) { singleton(&[]) } else { Space::new() };
        drop(v87_9);
        let v87_12: Space = if (v87_10).is_empty() { Space::new() } else {
          let v89_6: Path = concat_path(&(v84_13_head),&(v86_6_head));
          let v89_11: Space = routine_5(c, &(v89_6), &(*p0), &(v86_6_tail), &(*s0));
          drop(v89_6);
          compose(&(v87_10),&(v89_11))
        };
        drop(v87_10);
        let v87_13: Space = unite(&(v87_8),&(v87_12));
        v86_6.join_into((v87_13).clone());
      }
      drop(v86_6_cursor);
      compose(&(v85_5),&(v86_6))
    };
    drop(v85_5);
    let v85_8: Space = intersect(&(*CONSTANT_9),&(v85_2));
    drop(v85_2);
    let v85_9: Space = if has_head(&(v85_8)) { singleton(&[]) } else { Space::new() };
    drop(v85_8);
    let v85_12: Space = if (v85_9).is_empty() { Space::new() } else {
      let v90_10: Space = routine_35(c, &(v84_13_head), &(*CONSTANT_2), &(*CONSTANT_8));
      let v90_11: Space = unite(&(*s0),&(v90_10));
      compose(&(v85_9),&(v90_11))
    };
    drop(v85_9);
    let v85_13: Space = wrap(&(v85_12),&(*p0));
    let v85_14: Space = wrap(&(v85_13),&(v84_13_head));
    let v85_15: Space = unite(&(v85_7),&(v85_14));
    v84_13.join_into((v85_15).clone());
  }
  drop(v84_13_cursor);
  drop(v84_5);
  (v84_13).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v91_9 = Space::new();
  let mut v91_9_cursor = (*s0).read_zipper();
  for v91_9_byte in v91_9_cursor.child_mask().iter() {
    v91_9_cursor.descend_to_byte(v91_9_byte);
    let v91_9_tail = v91_9_cursor.make_map();
    v91_9_cursor.ascend(1);
    let v91_9_head = Path::from_slice(&[v91_9_byte]);
    let v92_2: Space = singleton(&(v91_9_head));
    let v92_3: Space = intersect(&(*CONSTANT_9),&(v92_2));
    let v92_4: Space = if has_head(&(v92_3)) { singleton(&[]) } else { Space::new() };
    drop(v92_3);
    let v92_5: Space = subtract(&(*CONSTANT_0),&(v92_4));
    drop(v92_4);
    let v92_8: Space = if (v92_5).is_empty() { Space::new() } else {
      let v93_6: Path = concat_path(&(*p0),&(v91_9_head));
      let v93_7: Space = routine_4(c, &(v93_6), &(*p1), &(v91_9_tail), &(*s1));
      compose(&(v92_5),&(v93_7))
    };
    drop(v92_5);
    let v92_9: Space = intersect(&(*CONSTANT_9),&(v92_2));
    drop(v92_2);
    let v92_10: Space = if has_head(&(v92_9)) { singleton(&[]) } else { Space::new() };
    drop(v92_9);
    let v92_13: Space = if (v92_10).is_empty() { Space::new() } else {
      let v94_6: Path = concat_path(&(*p0),&(v91_9_head));
      let v94_11: Space = routine_35(c, &(v94_6), &(*CONSTANT_2), &(*CONSTANT_8));
      let v94_12: Space = unite(&(*s1),&(v94_11));
      compose(&(v92_10),&(v94_12))
    };
    drop(v92_10);
    let v92_14: Space = wrap(&(v92_13),&(*p1));
    let v95_6: Path = concat_path(&(*p0),&(v91_9_head));
    let v92_15: Space = wrap(&(v92_14),&(v95_6));
    let v92_16: Space = unite(&(v92_8),&(v92_15));
    v91_9.join_into((v92_16).clone());
  }
  drop(v91_9_cursor);
  (v91_9).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v96_37: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v97_8: Space = routine_34(c, &(*CONSTANT_11), &(*CONSTANT_2), &(*p0), &(*CONSTANT_9));
    let v97_11: Space = routine_34(c, &(*CONSTANT_12), &(*CONSTANT_2), &(*p0), &(*CONSTANT_9));
    let v97_12: Space = unite(&(v97_8),&(v97_11));
    let v97_15: Space = routine_34(c, &(*CONSTANT_13), &(*CONSTANT_2), &(*p0), &(*CONSTANT_9));
    let v97_16: Space = unite(&(v97_12),&(v97_15));
    let v97_19: Space = routine_34(c, &(*CONSTANT_14), &(*CONSTANT_2), &(*p0), &(*CONSTANT_9));
    let v97_20: Space = unite(&(v97_16),&(v97_19));
    let v97_23: Space = routine_34(c, &(*CONSTANT_15), &(*CONSTANT_2), &(*p0), &(*CONSTANT_9));
    let v97_24: Space = unite(&(v97_20),&(v97_23));
    let v97_27: Space = routine_34(c, &(*CONSTANT_16), &(*CONSTANT_2), &(*p0), &(*CONSTANT_9));
    let v97_28: Space = unite(&(v97_24),&(v97_27));
    let v97_31: Space = routine_34(c, &(*CONSTANT_17), &(*CONSTANT_2), &(*p0), &(*CONSTANT_9));
    let v97_32: Space = unite(&(v97_28),&(v97_31));
    let v97_35: Space = routine_34(c, &(*CONSTANT_18), &(*CONSTANT_2), &(*p0), &(*CONSTANT_9));
    let v97_36: Space = unite(&(v97_32),&(v97_35));
    compose(&(*CONSTANT_0),&(v97_36))
  };
  let v96_39: Space = intersect(&(v96_37),&(*CONSTANT_19));
  let v96_40: Space = unite(&(v96_39),&(*s1));
  let v96_41: Space = wrap(&(v96_40),&(*p1));
  let v96_42: Space = wrap(&(v96_41),&(*p0));
  (v96_42).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v98_8 = Space::new();
  let mut v98_8_cursor = (*s0).read_zipper();
  for v98_8_byte in v98_8_cursor.child_mask().iter() {
    v98_8_cursor.descend_to_byte(v98_8_byte);
    let v98_8_tail = v98_8_cursor.make_map();
    v98_8_cursor.ascend(1);
    let v98_8_head = Path::from_slice(&[v98_8_byte]);
    let v99_2: Space = singleton(&(v98_8_head));
    let v99_3: Space = intersect(&(*CONSTANT_9),&(v99_2));
    let v99_4: Space = if has_head(&(v99_3)) { singleton(&[]) } else { Space::new() };
    drop(v99_3);
    let v99_5: Space = subtract(&(*CONSTANT_0),&(v99_4));
    drop(v99_4);
    let v99_8: Space = if (v99_5).is_empty() { Space::new() } else {
      let v100_6: Path = concat_path(&(*p0),&(v98_8_head));
      let v100_7: Space = routine_6(c, &(v100_6), &(v98_8_tail));
      compose(&(v99_5),&(v100_7))
    };
    drop(v99_5);
    let v99_9: Space = intersect(&(*CONSTANT_9),&(v99_2));
    drop(v99_2);
    let v99_10: Space = if has_head(&(v99_9)) { singleton(&[]) } else { Space::new() };
    drop(v99_9);
    let v99_12: Space = if (v99_10).is_empty() { Space::new() } else {
      let v101_6: Path = concat_path(&(*p0),&(v98_8_head));
      let mut v101_11 = Space::new();
      let mut v101_11_cursor = (v98_8_tail).read_zipper();
      for v101_11_byte in v101_11_cursor.child_mask().iter() {
        v101_11_cursor.descend_to_byte(v101_11_byte);
        let v101_11_tail = v101_11_cursor.make_map();
        v101_11_cursor.ascend(1);
        let v101_11_head = Path::from_slice(&[v101_11_byte]);
        let v102_2: Space = singleton(&(v101_11_head));
        let v102_3: Space = intersect(&(*CONSTANT_9),&(v102_2));
        let v102_4: Space = if has_head(&(v102_3)) { singleton(&[]) } else { Space::new() };
        drop(v102_3);
        let v102_5: Space = subtract(&(*CONSTANT_0),&(v102_4));
        drop(v102_4);
        let v102_7: Space = if (v102_5).is_empty() { Space::new() } else {
          let v103_6: Space = routine_8(c, &(v101_11_head), &(v101_6), &(v101_11_tail));
          compose(&(v102_5),&(v103_6))
        };
        drop(v102_5);
        let v102_8: Space = intersect(&(*CONSTANT_9),&(v102_2));
        drop(v102_2);
        let v102_9: Space = if has_head(&(v102_8)) { singleton(&[]) } else { Space::new() };
        drop(v102_8);
        let v102_11: Space = if (v102_9).is_empty() { Space::new() } else {
          let v104_10: Space = routine_9(c, &(v101_11_head), &(v101_6), &(v101_11_tail));
          compose(&(v102_9),&(v104_10))
        };
        drop(v102_9);
        let v102_12: Space = unite(&(v102_7),&(v102_11));
        v101_11.join_into((v102_12).clone());
      }
      drop(v101_11_cursor);
      drop(v101_6);
      compose(&(v99_10),&(v101_11))
    };
    drop(v99_10);
    let v99_13: Space = unite(&(v99_8),&(v99_12));
    v98_8.join_into((v99_13).clone());
  }
  drop(v98_8_cursor);
  (v98_8).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v105_13 = Space::new();
  let mut v105_13_cursor = (*s0).read_zipper();
  for v105_13_byte in v105_13_cursor.child_mask().iter() {
    v105_13_cursor.descend_to_byte(v105_13_byte);
    let v105_13_tail = v105_13_cursor.make_map();
    v105_13_cursor.ascend(1);
    let v105_13_head = Path::from_slice(&[v105_13_byte]);
    let v106_2: Space = singleton(&(v105_13_head));
    let v106_3: Space = intersect(&(*CONSTANT_9),&(v106_2));
    let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
    drop(v106_3);
    let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
    drop(v106_4);
    let v106_7: Space = if (v106_5).is_empty() { Space::new() } else {
      let mut v107_6 = Space::new();
      let mut v107_6_cursor = (v105_13_tail).read_zipper();
      for v107_6_byte in v107_6_cursor.child_mask().iter() {
        v107_6_cursor.descend_to_byte(v107_6_byte);
        let v107_6_tail = v107_6_cursor.make_map();
        v107_6_cursor.ascend(1);
        let v107_6_head = Path::from_slice(&[v107_6_byte]);
        let v108_2: Space = singleton(&(v107_6_head));
        let v108_3: Space = intersect(&(*CONSTANT_9),&(v108_2));
        let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
        drop(v108_3);
        let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
        drop(v108_4);
        let v108_8: Space = if (v108_5).is_empty() { Space::new() } else {
          let v109_6: Path = concat_path(&(v105_13_head),&(v107_6_head));
          let v109_7: Space = routine_8(c, &(v109_6), &(*p0), &(v107_6_tail));
          compose(&(v108_5),&(v109_7))
        };
        drop(v108_5);
        let v108_9: Space = intersect(&(*CONSTANT_9),&(v108_2));
        drop(v108_2);
        let v108_10: Space = if has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
        drop(v108_9);
        let v108_12: Space = if (v108_10).is_empty() { Space::new() } else {
          let v110_6: Path = concat_path(&(v105_13_head),&(v107_6_head));
          let v110_11: Space = routine_9(c, &(v110_6), &(*p0), &(v107_6_tail));
          drop(v110_6);
          compose(&(v108_10),&(v110_11))
        };
        drop(v108_10);
        let v108_13: Space = unite(&(v108_8),&(v108_12));
        v107_6.join_into((v108_13).clone());
      }
      drop(v107_6_cursor);
      compose(&(v106_5),&(v107_6))
    };
    drop(v106_5);
    let v106_8: Space = intersect(&(*CONSTANT_9),&(v106_2));
    drop(v106_2);
    let v106_9: Space = if has_head(&(v106_8)) { singleton(&[]) } else { Space::new() };
    drop(v106_8);
    let v106_13: Space = if (v106_9).is_empty() { Space::new() } else {
      let v111_10: Space = unwrap(&(v105_13_tail),&(*CONSTANT_3));
      let v111_11: Space = subtract(&(*CONSTANT_10),&(v111_10));
      drop(v111_10);
      let mut v111_12 = Space::new();
      let mut v111_12_cursor = (v111_11).read_zipper();
      for v111_12_byte in v111_12_cursor.child_mask().iter() {
        v111_12_cursor.descend_to_byte(v111_12_byte);
        let v111_12_tail = v111_12_cursor.make_map();
        v111_12_cursor.ascend(1);
        let v111_12_head = Path::from_slice(&[v111_12_byte]);
        let v112_2: Space = singleton(&(v111_12_head));
        let v112_3: Space = intersect(&(*CONSTANT_9),&(v112_2));
        let v112_4: Space = if has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
        drop(v112_3);
        let v112_5: Space = subtract(&(*CONSTANT_0),&(v112_4));
        drop(v112_4);
        let v112_7: Space = if (v112_5).is_empty() { Space::new() } else {
          let v113_6: Space = routine_36(c, &(v111_12_head), &(*p0), &(v105_13_head), &(v111_12_tail), &(v105_13_tail));
          compose(&(v112_5),&(v113_6))
        };
        drop(v112_5);
        let v112_8: Space = intersect(&(*CONSTANT_9),&(v112_2));
        drop(v112_2);
        let v112_9: Space = if has_head(&(v112_8)) { singleton(&[]) } else { Space::new() };
        drop(v112_8);
        let v112_11: Space = if (v112_9).is_empty() { Space::new() } else {
          let v114_10: Space = routine_37(c, &(v111_12_head), &(*p0), &(v105_13_head), &(v111_12_tail), &(v105_13_tail));
          compose(&(v112_9),&(v114_10))
        };
        drop(v112_9);
        let v112_12: Space = unite(&(v112_7),&(v112_11));
        v111_12.join_into((v112_12).clone());
      }
      drop(v111_12_cursor);
      drop(v111_11);
      compose(&(v106_9),&(v111_12))
    };
    drop(v106_9);
    let v106_14: Space = unite(&(v106_7),&(v106_13));
    v105_13.join_into((v106_14).clone());
  }
  drop(v105_13_cursor);
  (v105_13).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v115_11 = Space::new();
  let mut v115_11_cursor = (*s0).read_zipper();
  for v115_11_byte in v115_11_cursor.child_mask().iter() {
    v115_11_cursor.descend_to_byte(v115_11_byte);
    let v115_11_tail = v115_11_cursor.make_map();
    v115_11_cursor.ascend(1);
    let v115_11_head = Path::from_slice(&[v115_11_byte]);
    let v116_2: Space = singleton(&(v115_11_head));
    let v116_3: Space = intersect(&(*CONSTANT_9),&(v116_2));
    let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
    drop(v116_3);
    let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
    drop(v116_4);
    let v116_8: Space = if (v116_5).is_empty() { Space::new() } else {
      let v117_6: Path = concat_path(&(*p0),&(v115_11_head));
      let v117_7: Space = routine_8(c, &(v117_6), &(*p1), &(v115_11_tail));
      compose(&(v116_5),&(v117_7))
    };
    drop(v116_5);
    let v116_9: Space = intersect(&(*CONSTANT_9),&(v116_2));
    drop(v116_2);
    let v116_10: Space = if has_head(&(v116_9)) { singleton(&[]) } else { Space::new() };
    drop(v116_9);
    let v116_14: Space = if (v116_10).is_empty() { Space::new() } else {
      let v118_6: Path = concat_path(&(*p0),&(v115_11_head));
      let v118_11: Space = unwrap(&(v115_11_tail),&(*CONSTANT_3));
      let v118_12: Space = subtract(&(*CONSTANT_10),&(v118_11));
      drop(v118_11);
      let mut v118_13 = Space::new();
      let mut v118_13_cursor = (v118_12).read_zipper();
      for v118_13_byte in v118_13_cursor.child_mask().iter() {
        v118_13_cursor.descend_to_byte(v118_13_byte);
        let v118_13_tail = v118_13_cursor.make_map();
        v118_13_cursor.ascend(1);
        let v118_13_head = Path::from_slice(&[v118_13_byte]);
        let v119_2: Space = singleton(&(v118_13_head));
        let v119_3: Space = intersect(&(*CONSTANT_9),&(v119_2));
        let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
        drop(v119_3);
        let v119_5: Space = subtract(&(*CONSTANT_0),&(v119_4));
        drop(v119_4);
        let v119_7: Space = if (v119_5).is_empty() { Space::new() } else {
          let v120_6: Space = routine_36(c, &(v118_13_head), &(*p1), &(v118_6), &(v118_13_tail), &(v115_11_tail));
          compose(&(v119_5),&(v120_6))
        };
        drop(v119_5);
        let v119_8: Space = intersect(&(*CONSTANT_9),&(v119_2));
        drop(v119_2);
        let v119_9: Space = if has_head(&(v119_8)) { singleton(&[]) } else { Space::new() };
        drop(v119_8);
        let v119_11: Space = if (v119_9).is_empty() { Space::new() } else {
          let v121_10: Space = routine_37(c, &(v118_13_head), &(*p1), &(v118_6), &(v118_13_tail), &(v115_11_tail));
          compose(&(v119_9),&(v121_10))
        };
        drop(v119_9);
        let v119_12: Space = unite(&(v119_7),&(v119_11));
        v118_13.join_into((v119_12).clone());
      }
      drop(v118_13_cursor);
      drop(v118_6);
      drop(v118_12);
      compose(&(v116_10),&(v118_13))
    };
    drop(v116_10);
    let v116_15: Space = unite(&(v116_8),&(v116_14));
    v115_11.join_into((v116_15).clone());
  }
  drop(v115_11_cursor);
  (v115_11).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v122_5: Space = unwrap(&(*s0),&(*CONSTANT_3));
  let v122_6: Space = subtract(&(*CONSTANT_10),&(v122_5));
  drop(v122_5);
  let v122_11: Path = concat_path(&(*p1),&(*p0));
  let mut v122_15 = Space::new();
  let mut v122_15_cursor = (v122_6).read_zipper();
  for v122_15_byte in v122_15_cursor.child_mask().iter() {
    v122_15_cursor.descend_to_byte(v122_15_byte);
    let v122_15_tail = v122_15_cursor.make_map();
    v122_15_cursor.ascend(1);
    let v122_15_head = Path::from_slice(&[v122_15_byte]);
    let v123_2: Space = singleton(&(v122_15_head));
    let v123_3: Space = intersect(&(*CONSTANT_9),&(v123_2));
    let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
    drop(v123_3);
    let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
    drop(v123_4);
    let v123_7: Space = if (v123_5).is_empty() { Space::new() } else {
      let mut v124_6 = Space::new();
      let mut v124_6_cursor = (v122_15_tail).read_zipper();
      for v124_6_byte in v124_6_cursor.child_mask().iter() {
        v124_6_cursor.descend_to_byte(v124_6_byte);
        let v124_6_tail = v124_6_cursor.make_map();
        v124_6_cursor.ascend(1);
        let v124_6_head = Path::from_slice(&[v124_6_byte]);
        let v125_2: Space = singleton(&(v124_6_head));
        let v125_3: Space = intersect(&(*CONSTANT_9),&(v125_2));
        let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
        drop(v125_3);
        let v125_5: Space = subtract(&(*CONSTANT_0),&(v125_4));
        drop(v125_4);
        let v125_8: Space = if (v125_5).is_empty() { Space::new() } else {
          let v126_6: Path = concat_path(&(v122_15_head),&(v124_6_head));
          let v126_7: Space = routine_36(c, &(v126_6), &(*p1), &(*p0), &(v124_6_tail), &(*s0));
          compose(&(v125_5),&(v126_7))
        };
        drop(v125_5);
        let v125_9: Space = intersect(&(*CONSTANT_9),&(v125_2));
        drop(v125_2);
        let v125_10: Space = if has_head(&(v125_9)) { singleton(&[]) } else { Space::new() };
        drop(v125_9);
        let v125_12: Space = if (v125_10).is_empty() { Space::new() } else {
          let v127_6: Path = concat_path(&(v122_15_head),&(v124_6_head));
          let v127_11: Space = routine_37(c, &(v127_6), &(*p1), &(*p0), &(v124_6_tail), &(*s0));
          drop(v127_6);
          compose(&(v125_10),&(v127_11))
        };
        drop(v125_10);
        let v125_13: Space = unite(&(v125_8),&(v125_12));
        v124_6.join_into((v125_13).clone());
      }
      drop(v124_6_cursor);
      compose(&(v123_5),&(v124_6))
    };
    drop(v123_5);
    let v123_8: Space = intersect(&(*CONSTANT_9),&(v123_2));
    drop(v123_2);
    let v123_9: Space = if has_head(&(v123_8)) { singleton(&[]) } else { Space::new() };
    drop(v123_8);
    let v123_12: Space = if (v123_9).is_empty() { Space::new() } else {
      let v128_10: Space = routine_35(c, &(v122_15_head), &(*CONSTANT_3), &(*CONSTANT_8));
      let v128_11: Space = unite(&(*s0),&(v128_10));
      compose(&(v123_9),&(v128_11))
    };
    drop(v123_9);
    let v123_13: Space = wrap(&(v123_12),&(v122_11));
    let v123_14: Space = wrap(&(v123_13),&(v122_15_head));
    let v123_15: Space = unite(&(v123_7),&(v123_14));
    v122_15.join_into((v123_15).clone());
  }
  drop(v122_15_cursor);
  drop(v122_6);
  drop(v122_11);
  (v122_15).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v129_8 = Space::new();
  let mut v129_8_cursor = (*s0).read_zipper();
  for v129_8_byte in v129_8_cursor.child_mask().iter() {
    v129_8_cursor.descend_to_byte(v129_8_byte);
    let v129_8_tail = v129_8_cursor.make_map();
    v129_8_cursor.ascend(1);
    let v129_8_head = Path::from_slice(&[v129_8_byte]);
    let v130_2: Space = singleton(&(v129_8_head));
    let v130_3: Space = intersect(&(*CONSTANT_9),&(v130_2));
    let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
    drop(v130_3);
    let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
    drop(v130_4);
    let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
      let v131_6: Path = concat_path(&(*p0),&(v129_8_head));
      let v131_7: Space = routine_10(c, &(v131_6), &(v129_8_tail));
      compose(&(v130_5),&(v131_7))
    };
    drop(v130_5);
    let v130_9: Space = intersect(&(*CONSTANT_9),&(v130_2));
    drop(v130_2);
    let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
    drop(v130_9);
    let v130_12: Space = if (v130_10).is_empty() { Space::new() } else {
      let v132_6: Path = concat_path(&(*p0),&(v129_8_head));
      let mut v132_11 = Space::new();
      let mut v132_11_cursor = (v129_8_tail).read_zipper();
      for v132_11_byte in v132_11_cursor.child_mask().iter() {
        v132_11_cursor.descend_to_byte(v132_11_byte);
        let v132_11_tail = v132_11_cursor.make_map();
        v132_11_cursor.ascend(1);
        let v132_11_head = Path::from_slice(&[v132_11_byte]);
        let v133_2: Space = singleton(&(v132_11_head));
        let v133_3: Space = intersect(&(*CONSTANT_9),&(v133_2));
        let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
        drop(v133_3);
        let v133_5: Space = subtract(&(*CONSTANT_0),&(v133_4));
        drop(v133_4);
        let v133_7: Space = if (v133_5).is_empty() { Space::new() } else {
          let v134_6: Space = routine_12(c, &(v132_11_head), &(v132_6), &(v132_11_tail));
          compose(&(v133_5),&(v134_6))
        };
        drop(v133_5);
        let v133_8: Space = intersect(&(*CONSTANT_9),&(v133_2));
        drop(v133_2);
        let v133_9: Space = if has_head(&(v133_8)) { singleton(&[]) } else { Space::new() };
        drop(v133_8);
        let v133_11: Space = if (v133_9).is_empty() { Space::new() } else {
          let v135_10: Space = routine_13(c, &(v132_11_head), &(v132_6), &(v132_11_tail));
          compose(&(v133_9),&(v135_10))
        };
        drop(v133_9);
        let v133_12: Space = unite(&(v133_7),&(v133_11));
        v132_11.join_into((v133_12).clone());
      }
      drop(v132_11_cursor);
      drop(v132_6);
      compose(&(v130_10),&(v132_11))
    };
    drop(v130_10);
    let v130_13: Space = unite(&(v130_8),&(v130_12));
    v129_8.join_into((v130_13).clone());
  }
  drop(v129_8_cursor);
  (v129_8).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v136_11 = Space::new();
  let mut v136_11_cursor = (*s0).read_zipper();
  for v136_11_byte in v136_11_cursor.child_mask().iter() {
    v136_11_cursor.descend_to_byte(v136_11_byte);
    let v136_11_tail = v136_11_cursor.make_map();
    v136_11_cursor.ascend(1);
    let v136_11_head = Path::from_slice(&[v136_11_byte]);
    let v137_2: Space = singleton(&(v136_11_head));
    let v137_3: Space = intersect(&(*CONSTANT_9),&(v137_2));
    let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
    drop(v137_3);
    let v137_5: Space = subtract(&(*CONSTANT_0),&(v137_4));
    drop(v137_4);
    let v137_7: Space = if (v137_5).is_empty() { Space::new() } else {
      let mut v138_6 = Space::new();
      let mut v138_6_cursor = (v136_11_tail).read_zipper();
      for v138_6_byte in v138_6_cursor.child_mask().iter() {
        v138_6_cursor.descend_to_byte(v138_6_byte);
        let v138_6_tail = v138_6_cursor.make_map();
        v138_6_cursor.ascend(1);
        let v138_6_head = Path::from_slice(&[v138_6_byte]);
        let v139_2: Space = singleton(&(v138_6_head));
        let v139_3: Space = intersect(&(*CONSTANT_9),&(v139_2));
        let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
        drop(v139_3);
        let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
        drop(v139_4);
        let v139_8: Space = if (v139_5).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v136_11_head),&(v138_6_head));
          let v140_7: Space = routine_12(c, &(v140_6), &(*p0), &(v138_6_tail));
          compose(&(v139_5),&(v140_7))
        };
        drop(v139_5);
        let v139_9: Space = intersect(&(*CONSTANT_9),&(v139_2));
        drop(v139_2);
        let v139_10: Space = if has_head(&(v139_9)) { singleton(&[]) } else { Space::new() };
        drop(v139_9);
        let v139_12: Space = if (v139_10).is_empty() { Space::new() } else {
          let v141_6: Path = concat_path(&(v136_11_head),&(v138_6_head));
          let v141_11: Space = routine_13(c, &(v141_6), &(*p0), &(v138_6_tail));
          drop(v141_6);
          compose(&(v139_10),&(v141_11))
        };
        drop(v139_10);
        let v139_13: Space = unite(&(v139_8),&(v139_12));
        v138_6.join_into((v139_13).clone());
      }
      drop(v138_6_cursor);
      compose(&(v137_5),&(v138_6))
    };
    drop(v137_5);
    let v137_8: Space = intersect(&(*CONSTANT_9),&(v137_2));
    drop(v137_2);
    let v137_9: Space = if has_head(&(v137_8)) { singleton(&[]) } else { Space::new() };
    drop(v137_8);
    let v137_11: Space = if (v137_9).is_empty() { Space::new() } else {
      let mut v142_10 = Space::new();
      let mut v142_10_cursor = (v136_11_tail).read_zipper();
      for v142_10_byte in v142_10_cursor.child_mask().iter() {
        v142_10_cursor.descend_to_byte(v142_10_byte);
        let v142_10_tail = v142_10_cursor.make_map();
        v142_10_cursor.ascend(1);
        let v142_10_head = Path::from_slice(&[v142_10_byte]);
        let v143_2: Space = singleton(&(v142_10_head));
        let v143_3: Space = intersect(&(*CONSTANT_9),&(v143_2));
        let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
        drop(v143_3);
        let v143_5: Space = subtract(&(*CONSTANT_0),&(v143_4));
        drop(v143_4);
        let v143_7: Space = if (v143_5).is_empty() { Space::new() } else {
          let v144_6: Space = routine_38(c, &(v142_10_head), &(*p0), &(v136_11_head), &(v142_10_tail));
          compose(&(v143_5),&(v144_6))
        };
        drop(v143_5);
        let v143_8: Space = intersect(&(*CONSTANT_9),&(v143_2));
        drop(v143_2);
        let v143_9: Space = if has_head(&(v143_8)) { singleton(&[]) } else { Space::new() };
        drop(v143_8);
        let v143_11: Space = if (v143_9).is_empty() { Space::new() } else {
          let v145_10: Space = routine_39(c, &(v142_10_head), &(*p0), &(v136_11_head), &(v142_10_tail));
          compose(&(v143_9),&(v145_10))
        };
        drop(v143_9);
        let v143_12: Space = unite(&(v143_7),&(v143_11));
        v142_10.join_into((v143_12).clone());
      }
      drop(v142_10_cursor);
      compose(&(v137_9),&(v142_10))
    };
    drop(v137_9);
    let v137_12: Space = unite(&(v137_7),&(v137_11));
    v136_11.join_into((v137_12).clone());
  }
  drop(v136_11_cursor);
  (v136_11).clone()
}

fn routine_12(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v146_9 = Space::new();
  let mut v146_9_cursor = (*s0).read_zipper();
  for v146_9_byte in v146_9_cursor.child_mask().iter() {
    v146_9_cursor.descend_to_byte(v146_9_byte);
    let v146_9_tail = v146_9_cursor.make_map();
    v146_9_cursor.ascend(1);
    let v146_9_head = Path::from_slice(&[v146_9_byte]);
    let v147_2: Space = singleton(&(v146_9_head));
    let v147_3: Space = intersect(&(*CONSTANT_9),&(v147_2));
    let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
    drop(v147_3);
    let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
    drop(v147_4);
    let v147_8: Space = if (v147_5).is_empty() { Space::new() } else {
      let v148_6: Path = concat_path(&(*p0),&(v146_9_head));
      let v148_7: Space = routine_12(c, &(v148_6), &(*p1), &(v146_9_tail));
      compose(&(v147_5),&(v148_7))
    };
    drop(v147_5);
    let v147_9: Space = intersect(&(*CONSTANT_9),&(v147_2));
    drop(v147_2);
    let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
    drop(v147_9);
    let v147_12: Space = if (v147_10).is_empty() { Space::new() } else {
      let v149_6: Path = concat_path(&(*p0),&(v146_9_head));
      let mut v149_11 = Space::new();
      let mut v149_11_cursor = (v146_9_tail).read_zipper();
      for v149_11_byte in v149_11_cursor.child_mask().iter() {
        v149_11_cursor.descend_to_byte(v149_11_byte);
        let v149_11_tail = v149_11_cursor.make_map();
        v149_11_cursor.ascend(1);
        let v149_11_head = Path::from_slice(&[v149_11_byte]);
        let v150_2: Space = singleton(&(v149_11_head));
        let v150_3: Space = intersect(&(*CONSTANT_9),&(v150_2));
        let v150_4: Space = if has_head(&(v150_3)) { singleton(&[]) } else { Space::new() };
        drop(v150_3);
        let v150_5: Space = subtract(&(*CONSTANT_0),&(v150_4));
        drop(v150_4);
        let v150_7: Space = if (v150_5).is_empty() { Space::new() } else {
          let v151_6: Space = routine_38(c, &(v149_11_head), &(*p1), &(v149_6), &(v149_11_tail));
          compose(&(v150_5),&(v151_6))
        };
        drop(v150_5);
        let v150_8: Space = intersect(&(*CONSTANT_9),&(v150_2));
        drop(v150_2);
        let v150_9: Space = if has_head(&(v150_8)) { singleton(&[]) } else { Space::new() };
        drop(v150_8);
        let v150_11: Space = if (v150_9).is_empty() { Space::new() } else {
          let v152_10: Space = routine_39(c, &(v149_11_head), &(*p1), &(v149_6), &(v149_11_tail));
          compose(&(v150_9),&(v152_10))
        };
        drop(v150_9);
        let v150_12: Space = unite(&(v150_7),&(v150_11));
        v149_11.join_into((v150_12).clone());
      }
      drop(v149_11_cursor);
      drop(v149_6);
      compose(&(v147_10),&(v149_11))
    };
    drop(v147_10);
    let v147_13: Space = unite(&(v147_8),&(v147_12));
    v146_9.join_into((v147_13).clone());
  }
  drop(v146_9_cursor);
  (v146_9).clone()
}

fn routine_13(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v153_14 = Space::new();
  let mut v153_14_cursor = (*s0).read_zipper();
  for v153_14_byte in v153_14_cursor.child_mask().iter() {
    v153_14_cursor.descend_to_byte(v153_14_byte);
    let v153_14_tail = v153_14_cursor.make_map();
    v153_14_cursor.ascend(1);
    let v153_14_head = Path::from_slice(&[v153_14_byte]);
    let v154_2: Space = singleton(&(v153_14_head));
    let v154_3: Space = intersect(&(*CONSTANT_9),&(v154_2));
    let v154_4: Space = if has_head(&(v154_3)) { singleton(&[]) } else { Space::new() };
    drop(v154_3);
    let v154_5: Space = subtract(&(*CONSTANT_0),&(v154_4));
    drop(v154_4);
    let v154_7: Space = if (v154_5).is_empty() { Space::new() } else {
      let mut v155_6 = Space::new();
      let mut v155_6_cursor = (v153_14_tail).read_zipper();
      for v155_6_byte in v155_6_cursor.child_mask().iter() {
        v155_6_cursor.descend_to_byte(v155_6_byte);
        let v155_6_tail = v155_6_cursor.make_map();
        v155_6_cursor.ascend(1);
        let v155_6_head = Path::from_slice(&[v155_6_byte]);
        let v156_2: Space = singleton(&(v155_6_head));
        let v156_3: Space = intersect(&(*CONSTANT_9),&(v156_2));
        let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
        drop(v156_3);
        let v156_5: Space = subtract(&(*CONSTANT_0),&(v156_4));
        drop(v156_4);
        let v156_8: Space = if (v156_5).is_empty() { Space::new() } else {
          let v157_6: Path = concat_path(&(v153_14_head),&(v155_6_head));
          let v157_7: Space = routine_38(c, &(v157_6), &(*p1), &(*p0), &(v155_6_tail));
          compose(&(v156_5),&(v157_7))
        };
        drop(v156_5);
        let v156_9: Space = intersect(&(*CONSTANT_9),&(v156_2));
        drop(v156_2);
        let v156_10: Space = if has_head(&(v156_9)) { singleton(&[]) } else { Space::new() };
        drop(v156_9);
        let v156_12: Space = if (v156_10).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v153_14_head),&(v155_6_head));
          let v158_11: Space = routine_39(c, &(v158_6), &(*p1), &(*p0), &(v155_6_tail));
          drop(v158_6);
          compose(&(v156_10),&(v158_11))
        };
        drop(v156_10);
        let v156_13: Space = unite(&(v156_8),&(v156_12));
        v155_6.join_into((v156_13).clone());
      }
      drop(v155_6_cursor);
      compose(&(v154_5),&(v155_6))
    };
    drop(v154_5);
    let v154_8: Space = intersect(&(*CONSTANT_9),&(v154_2));
    drop(v154_2);
    let v154_9: Space = if has_head(&(v154_8)) { singleton(&[]) } else { Space::new() };
    drop(v154_8);
    let v154_13: Space = if (v154_9).is_empty() { Space::new() } else {
      let v159_10: Space = unwrap(&(v153_14_tail),&(*CONSTANT_4));
      let v159_11: Space = subtract(&(*CONSTANT_10),&(v159_10));
      drop(v159_10);
      let mut v159_12 = Space::new();
      let mut v159_12_cursor = (v159_11).read_zipper();
      for v159_12_byte in v159_12_cursor.child_mask().iter() {
        v159_12_cursor.descend_to_byte(v159_12_byte);
        let v159_12_tail = v159_12_cursor.make_map();
        v159_12_cursor.ascend(1);
        let v159_12_head = Path::from_slice(&[v159_12_byte]);
        let v160_2: Space = singleton(&(v159_12_head));
        let v160_3: Space = intersect(&(*CONSTANT_9),&(v160_2));
        let v160_4: Space = if has_head(&(v160_3)) { singleton(&[]) } else { Space::new() };
        drop(v160_3);
        let v160_5: Space = subtract(&(*CONSTANT_0),&(v160_4));
        drop(v160_4);
        let v160_7: Space = if (v160_5).is_empty() { Space::new() } else {
          let v161_6: Space = routine_40(c, &(v159_12_head), &(*p1), &(*p0), &(v153_14_head), &(v159_12_tail), &(v153_14_tail));
          compose(&(v160_5),&(v161_6))
        };
        drop(v160_5);
        let v160_8: Space = intersect(&(*CONSTANT_9),&(v160_2));
        drop(v160_2);
        let v160_9: Space = if has_head(&(v160_8)) { singleton(&[]) } else { Space::new() };
        drop(v160_8);
        let v160_11: Space = if (v160_9).is_empty() { Space::new() } else {
          let v162_10: Space = routine_41(c, &(v159_12_head), &(*p1), &(*p0), &(v153_14_head), &(v159_12_tail), &(v153_14_tail));
          compose(&(v160_9),&(v162_10))
        };
        drop(v160_9);
        let v160_12: Space = unite(&(v160_7),&(v160_11));
        v159_12.join_into((v160_12).clone());
      }
      drop(v159_12_cursor);
      drop(v159_11);
      compose(&(v154_9),&(v159_12))
    };
    drop(v154_9);
    let v154_14: Space = unite(&(v154_7),&(v154_13));
    v153_14.join_into((v154_14).clone());
  }
  drop(v153_14_cursor);
  (v153_14).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v163_8 = Space::new();
  let mut v163_8_cursor = (*s0).read_zipper();
  for v163_8_byte in v163_8_cursor.child_mask().iter() {
    v163_8_cursor.descend_to_byte(v163_8_byte);
    let v163_8_tail = v163_8_cursor.make_map();
    v163_8_cursor.ascend(1);
    let v163_8_head = Path::from_slice(&[v163_8_byte]);
    let v164_2: Space = singleton(&(v163_8_head));
    let v164_3: Space = intersect(&(*CONSTANT_9),&(v164_2));
    let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
    drop(v164_3);
    let v164_5: Space = subtract(&(*CONSTANT_0),&(v164_4));
    drop(v164_4);
    let v164_8: Space = if (v164_5).is_empty() { Space::new() } else {
      let v165_6: Path = concat_path(&(*p0),&(v163_8_head));
      let v165_7: Space = routine_14(c, &(v165_6), &(v163_8_tail));
      compose(&(v164_5),&(v165_7))
    };
    drop(v164_5);
    let v164_9: Space = intersect(&(*CONSTANT_9),&(v164_2));
    drop(v164_2);
    let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
    drop(v164_9);
    let v164_12: Space = if (v164_10).is_empty() { Space::new() } else {
      let v166_6: Path = concat_path(&(*p0),&(v163_8_head));
      let mut v166_11 = Space::new();
      let mut v166_11_cursor = (v163_8_tail).read_zipper();
      for v166_11_byte in v166_11_cursor.child_mask().iter() {
        v166_11_cursor.descend_to_byte(v166_11_byte);
        let v166_11_tail = v166_11_cursor.make_map();
        v166_11_cursor.ascend(1);
        let v166_11_head = Path::from_slice(&[v166_11_byte]);
        let v167_2: Space = singleton(&(v166_11_head));
        let v167_3: Space = intersect(&(*CONSTANT_9),&(v167_2));
        let v167_4: Space = if has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
        drop(v167_3);
        let v167_5: Space = subtract(&(*CONSTANT_0),&(v167_4));
        drop(v167_4);
        let v167_7: Space = if (v167_5).is_empty() { Space::new() } else {
          let v168_6: Space = routine_16(c, &(v166_11_head), &(v166_6), &(v166_11_tail));
          compose(&(v167_5),&(v168_6))
        };
        drop(v167_5);
        let v167_8: Space = intersect(&(*CONSTANT_9),&(v167_2));
        drop(v167_2);
        let v167_9: Space = if has_head(&(v167_8)) { singleton(&[]) } else { Space::new() };
        drop(v167_8);
        let v167_11: Space = if (v167_9).is_empty() { Space::new() } else {
          let v169_10: Space = routine_17(c, &(v166_11_head), &(v166_6), &(v166_11_tail));
          compose(&(v167_9),&(v169_10))
        };
        drop(v167_9);
        let v167_12: Space = unite(&(v167_7),&(v167_11));
        v166_11.join_into((v167_12).clone());
      }
      drop(v166_11_cursor);
      drop(v166_6);
      compose(&(v164_10),&(v166_11))
    };
    drop(v164_10);
    let v164_13: Space = unite(&(v164_8),&(v164_12));
    v163_8.join_into((v164_13).clone());
  }
  drop(v163_8_cursor);
  (v163_8).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v170_11 = Space::new();
  let mut v170_11_cursor = (*s0).read_zipper();
  for v170_11_byte in v170_11_cursor.child_mask().iter() {
    v170_11_cursor.descend_to_byte(v170_11_byte);
    let v170_11_tail = v170_11_cursor.make_map();
    v170_11_cursor.ascend(1);
    let v170_11_head = Path::from_slice(&[v170_11_byte]);
    let v171_2: Space = singleton(&(v170_11_head));
    let v171_3: Space = intersect(&(*CONSTANT_9),&(v171_2));
    let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
    drop(v171_3);
    let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
    drop(v171_4);
    let v171_7: Space = if (v171_5).is_empty() { Space::new() } else {
      let mut v172_6 = Space::new();
      let mut v172_6_cursor = (v170_11_tail).read_zipper();
      for v172_6_byte in v172_6_cursor.child_mask().iter() {
        v172_6_cursor.descend_to_byte(v172_6_byte);
        let v172_6_tail = v172_6_cursor.make_map();
        v172_6_cursor.ascend(1);
        let v172_6_head = Path::from_slice(&[v172_6_byte]);
        let v173_2: Space = singleton(&(v172_6_head));
        let v173_3: Space = intersect(&(*CONSTANT_9),&(v173_2));
        let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
        drop(v173_3);
        let v173_5: Space = subtract(&(*CONSTANT_0),&(v173_4));
        drop(v173_4);
        let v173_8: Space = if (v173_5).is_empty() { Space::new() } else {
          let v174_6: Path = concat_path(&(v170_11_head),&(v172_6_head));
          let v174_7: Space = routine_16(c, &(v174_6), &(*p0), &(v172_6_tail));
          compose(&(v173_5),&(v174_7))
        };
        drop(v173_5);
        let v173_9: Space = intersect(&(*CONSTANT_9),&(v173_2));
        drop(v173_2);
        let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
        drop(v173_9);
        let v173_12: Space = if (v173_10).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v170_11_head),&(v172_6_head));
          let v175_11: Space = routine_17(c, &(v175_6), &(*p0), &(v172_6_tail));
          drop(v175_6);
          compose(&(v173_10),&(v175_11))
        };
        drop(v173_10);
        let v173_13: Space = unite(&(v173_8),&(v173_12));
        v172_6.join_into((v173_13).clone());
      }
      drop(v172_6_cursor);
      compose(&(v171_5),&(v172_6))
    };
    drop(v171_5);
    let v171_8: Space = intersect(&(*CONSTANT_9),&(v171_2));
    drop(v171_2);
    let v171_9: Space = if has_head(&(v171_8)) { singleton(&[]) } else { Space::new() };
    drop(v171_8);
    let v171_11: Space = if (v171_9).is_empty() { Space::new() } else {
      let mut v176_10 = Space::new();
      let mut v176_10_cursor = (v170_11_tail).read_zipper();
      for v176_10_byte in v176_10_cursor.child_mask().iter() {
        v176_10_cursor.descend_to_byte(v176_10_byte);
        let v176_10_tail = v176_10_cursor.make_map();
        v176_10_cursor.ascend(1);
        let v176_10_head = Path::from_slice(&[v176_10_byte]);
        let v177_2: Space = singleton(&(v176_10_head));
        let v177_3: Space = intersect(&(*CONSTANT_9),&(v177_2));
        let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
        drop(v177_3);
        let v177_5: Space = subtract(&(*CONSTANT_0),&(v177_4));
        drop(v177_4);
        let v177_7: Space = if (v177_5).is_empty() { Space::new() } else {
          let v178_6: Space = routine_42(c, &(v176_10_head), &(v170_11_head), &(*p0), &(v176_10_tail));
          compose(&(v177_5),&(v178_6))
        };
        drop(v177_5);
        let v177_8: Space = intersect(&(*CONSTANT_9),&(v177_2));
        drop(v177_2);
        let v177_9: Space = if has_head(&(v177_8)) { singleton(&[]) } else { Space::new() };
        drop(v177_8);
        let v177_11: Space = if (v177_9).is_empty() { Space::new() } else {
          let v179_10: Space = routine_43(c, &(v176_10_head), &(v170_11_head), &(*p0), &(v176_10_tail));
          compose(&(v177_9),&(v179_10))
        };
        drop(v177_9);
        let v177_12: Space = unite(&(v177_7),&(v177_11));
        v176_10.join_into((v177_12).clone());
      }
      drop(v176_10_cursor);
      compose(&(v171_9),&(v176_10))
    };
    drop(v171_9);
    let v171_12: Space = unite(&(v171_7),&(v171_11));
    v170_11.join_into((v171_12).clone());
  }
  drop(v170_11_cursor);
  (v170_11).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v180_9 = Space::new();
  let mut v180_9_cursor = (*s0).read_zipper();
  for v180_9_byte in v180_9_cursor.child_mask().iter() {
    v180_9_cursor.descend_to_byte(v180_9_byte);
    let v180_9_tail = v180_9_cursor.make_map();
    v180_9_cursor.ascend(1);
    let v180_9_head = Path::from_slice(&[v180_9_byte]);
    let v181_2: Space = singleton(&(v180_9_head));
    let v181_3: Space = intersect(&(*CONSTANT_9),&(v181_2));
    let v181_4: Space = if has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
    drop(v181_3);
    let v181_5: Space = subtract(&(*CONSTANT_0),&(v181_4));
    drop(v181_4);
    let v181_8: Space = if (v181_5).is_empty() { Space::new() } else {
      let v182_6: Path = concat_path(&(*p0),&(v180_9_head));
      let v182_7: Space = routine_16(c, &(v182_6), &(*p1), &(v180_9_tail));
      compose(&(v181_5),&(v182_7))
    };
    drop(v181_5);
    let v181_9: Space = intersect(&(*CONSTANT_9),&(v181_2));
    drop(v181_2);
    let v181_10: Space = if has_head(&(v181_9)) { singleton(&[]) } else { Space::new() };
    drop(v181_9);
    let v181_12: Space = if (v181_10).is_empty() { Space::new() } else {
      let v183_6: Path = concat_path(&(*p0),&(v180_9_head));
      let mut v183_11 = Space::new();
      let mut v183_11_cursor = (v180_9_tail).read_zipper();
      for v183_11_byte in v183_11_cursor.child_mask().iter() {
        v183_11_cursor.descend_to_byte(v183_11_byte);
        let v183_11_tail = v183_11_cursor.make_map();
        v183_11_cursor.ascend(1);
        let v183_11_head = Path::from_slice(&[v183_11_byte]);
        let v184_2: Space = singleton(&(v183_11_head));
        let v184_3: Space = intersect(&(*CONSTANT_9),&(v184_2));
        let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
        drop(v184_3);
        let v184_5: Space = subtract(&(*CONSTANT_0),&(v184_4));
        drop(v184_4);
        let v184_7: Space = if (v184_5).is_empty() { Space::new() } else {
          let v185_6: Space = routine_42(c, &(v183_11_head), &(v183_6), &(*p1), &(v183_11_tail));
          compose(&(v184_5),&(v185_6))
        };
        drop(v184_5);
        let v184_8: Space = intersect(&(*CONSTANT_9),&(v184_2));
        drop(v184_2);
        let v184_9: Space = if has_head(&(v184_8)) { singleton(&[]) } else { Space::new() };
        drop(v184_8);
        let v184_11: Space = if (v184_9).is_empty() { Space::new() } else {
          let v186_10: Space = routine_43(c, &(v183_11_head), &(v183_6), &(*p1), &(v183_11_tail));
          compose(&(v184_9),&(v186_10))
        };
        drop(v184_9);
        let v184_12: Space = unite(&(v184_7),&(v184_11));
        v183_11.join_into((v184_12).clone());
      }
      drop(v183_11_cursor);
      drop(v183_6);
      compose(&(v181_10),&(v183_11))
    };
    drop(v181_10);
    let v181_13: Space = unite(&(v181_8),&(v181_12));
    v180_9.join_into((v181_13).clone());
  }
  drop(v180_9_cursor);
  (v180_9).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v187_12 = Space::new();
  let mut v187_12_cursor = (*s0).read_zipper();
  for v187_12_byte in v187_12_cursor.child_mask().iter() {
    v187_12_cursor.descend_to_byte(v187_12_byte);
    let v187_12_tail = v187_12_cursor.make_map();
    v187_12_cursor.ascend(1);
    let v187_12_head = Path::from_slice(&[v187_12_byte]);
    let v188_2: Space = singleton(&(v187_12_head));
    let v188_3: Space = intersect(&(*CONSTANT_9),&(v188_2));
    let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
    drop(v188_3);
    let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
    drop(v188_4);
    let v188_7: Space = if (v188_5).is_empty() { Space::new() } else {
      let mut v189_6 = Space::new();
      let mut v189_6_cursor = (v187_12_tail).read_zipper();
      for v189_6_byte in v189_6_cursor.child_mask().iter() {
        v189_6_cursor.descend_to_byte(v189_6_byte);
        let v189_6_tail = v189_6_cursor.make_map();
        v189_6_cursor.ascend(1);
        let v189_6_head = Path::from_slice(&[v189_6_byte]);
        let v190_2: Space = singleton(&(v189_6_head));
        let v190_3: Space = intersect(&(*CONSTANT_9),&(v190_2));
        let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
        drop(v190_3);
        let v190_5: Space = subtract(&(*CONSTANT_0),&(v190_4));
        drop(v190_4);
        let v190_8: Space = if (v190_5).is_empty() { Space::new() } else {
          let v191_6: Path = concat_path(&(v187_12_head),&(v189_6_head));
          let v191_7: Space = routine_42(c, &(v191_6), &(*p0), &(*p1), &(v189_6_tail));
          compose(&(v190_5),&(v191_7))
        };
        drop(v190_5);
        let v190_9: Space = intersect(&(*CONSTANT_9),&(v190_2));
        drop(v190_2);
        let v190_10: Space = if has_head(&(v190_9)) { singleton(&[]) } else { Space::new() };
        drop(v190_9);
        let v190_12: Space = if (v190_10).is_empty() { Space::new() } else {
          let v192_6: Path = concat_path(&(v187_12_head),&(v189_6_head));
          let v192_11: Space = routine_43(c, &(v192_6), &(*p0), &(*p1), &(v189_6_tail));
          drop(v192_6);
          compose(&(v190_10),&(v192_11))
        };
        drop(v190_10);
        let v190_13: Space = unite(&(v190_8),&(v190_12));
        v189_6.join_into((v190_13).clone());
      }
      drop(v189_6_cursor);
      compose(&(v188_5),&(v189_6))
    };
    drop(v188_5);
    let v188_8: Space = intersect(&(*CONSTANT_9),&(v188_2));
    drop(v188_2);
    let v188_9: Space = if has_head(&(v188_8)) { singleton(&[]) } else { Space::new() };
    drop(v188_8);
    let v188_11: Space = if (v188_9).is_empty() { Space::new() } else {
      let mut v193_10 = Space::new();
      let mut v193_10_cursor = (v187_12_tail).read_zipper();
      for v193_10_byte in v193_10_cursor.child_mask().iter() {
        v193_10_cursor.descend_to_byte(v193_10_byte);
        let v193_10_tail = v193_10_cursor.make_map();
        v193_10_cursor.ascend(1);
        let v193_10_head = Path::from_slice(&[v193_10_byte]);
        let v194_2: Space = singleton(&(v193_10_head));
        let v194_3: Space = intersect(&(*CONSTANT_9),&(v194_2));
        let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
        drop(v194_3);
        let v194_5: Space = subtract(&(*CONSTANT_0),&(v194_4));
        drop(v194_4);
        let v194_7: Space = if (v194_5).is_empty() { Space::new() } else {
          let v195_6: Space = routine_44(c, &(v193_10_head), &(*p0), &(v187_12_head), &(*p1), &(v193_10_tail));
          compose(&(v194_5),&(v195_6))
        };
        drop(v194_5);
        let v194_8: Space = intersect(&(*CONSTANT_9),&(v194_2));
        drop(v194_2);
        let v194_9: Space = if has_head(&(v194_8)) { singleton(&[]) } else { Space::new() };
        drop(v194_8);
        let v194_11: Space = if (v194_9).is_empty() { Space::new() } else {
          let v196_10: Space = routine_45(c, &(v193_10_head), &(*p0), &(v187_12_head), &(*p1), &(v193_10_tail));
          compose(&(v194_9),&(v196_10))
        };
        drop(v194_9);
        let v194_12: Space = unite(&(v194_7),&(v194_11));
        v193_10.join_into((v194_12).clone());
      }
      drop(v193_10_cursor);
      compose(&(v188_9),&(v193_10))
    };
    drop(v188_9);
    let v188_12: Space = unite(&(v188_7),&(v188_11));
    v187_12.join_into((v188_12).clone());
  }
  drop(v187_12_cursor);
  (v187_12).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v197_8 = Space::new();
  let mut v197_8_cursor = (*s0).read_zipper();
  for v197_8_byte in v197_8_cursor.child_mask().iter() {
    v197_8_cursor.descend_to_byte(v197_8_byte);
    let v197_8_tail = v197_8_cursor.make_map();
    v197_8_cursor.ascend(1);
    let v197_8_head = Path::from_slice(&[v197_8_byte]);
    let v198_2: Space = singleton(&(v197_8_head));
    let v198_3: Space = intersect(&(*CONSTANT_9),&(v198_2));
    let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
    drop(v198_3);
    let v198_5: Space = subtract(&(*CONSTANT_0),&(v198_4));
    drop(v198_4);
    let v198_8: Space = if (v198_5).is_empty() { Space::new() } else {
      let v199_6: Path = concat_path(&(*p0),&(v197_8_head));
      let v199_7: Space = routine_18(c, &(v199_6), &(v197_8_tail));
      compose(&(v198_5),&(v199_7))
    };
    drop(v198_5);
    let v198_9: Space = intersect(&(*CONSTANT_9),&(v198_2));
    drop(v198_2);
    let v198_10: Space = if has_head(&(v198_9)) { singleton(&[]) } else { Space::new() };
    drop(v198_9);
    let v198_12: Space = if (v198_10).is_empty() { Space::new() } else {
      let v200_6: Path = concat_path(&(*p0),&(v197_8_head));
      let mut v200_11 = Space::new();
      let mut v200_11_cursor = (v197_8_tail).read_zipper();
      for v200_11_byte in v200_11_cursor.child_mask().iter() {
        v200_11_cursor.descend_to_byte(v200_11_byte);
        let v200_11_tail = v200_11_cursor.make_map();
        v200_11_cursor.ascend(1);
        let v200_11_head = Path::from_slice(&[v200_11_byte]);
        let v201_2: Space = singleton(&(v200_11_head));
        let v201_3: Space = intersect(&(*CONSTANT_9),&(v201_2));
        let v201_4: Space = if has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
        drop(v201_3);
        let v201_5: Space = subtract(&(*CONSTANT_0),&(v201_4));
        drop(v201_4);
        let v201_7: Space = if (v201_5).is_empty() { Space::new() } else {
          let v202_6: Space = routine_20(c, &(v200_11_head), &(v200_6), &(v200_11_tail));
          compose(&(v201_5),&(v202_6))
        };
        drop(v201_5);
        let v201_8: Space = intersect(&(*CONSTANT_9),&(v201_2));
        drop(v201_2);
        let v201_9: Space = if has_head(&(v201_8)) { singleton(&[]) } else { Space::new() };
        drop(v201_8);
        let v201_11: Space = if (v201_9).is_empty() { Space::new() } else {
          let v203_10: Space = routine_21(c, &(v200_11_head), &(v200_6), &(v200_11_tail));
          compose(&(v201_9),&(v203_10))
        };
        drop(v201_9);
        let v201_12: Space = unite(&(v201_7),&(v201_11));
        v200_11.join_into((v201_12).clone());
      }
      drop(v200_11_cursor);
      drop(v200_6);
      compose(&(v198_10),&(v200_11))
    };
    drop(v198_10);
    let v198_13: Space = unite(&(v198_8),&(v198_12));
    v197_8.join_into((v198_13).clone());
  }
  drop(v197_8_cursor);
  (v197_8).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v204_11 = Space::new();
  let mut v204_11_cursor = (*s0).read_zipper();
  for v204_11_byte in v204_11_cursor.child_mask().iter() {
    v204_11_cursor.descend_to_byte(v204_11_byte);
    let v204_11_tail = v204_11_cursor.make_map();
    v204_11_cursor.ascend(1);
    let v204_11_head = Path::from_slice(&[v204_11_byte]);
    let v205_2: Space = singleton(&(v204_11_head));
    let v205_3: Space = intersect(&(*CONSTANT_9),&(v205_2));
    let v205_4: Space = if has_head(&(v205_3)) { singleton(&[]) } else { Space::new() };
    drop(v205_3);
    let v205_5: Space = subtract(&(*CONSTANT_0),&(v205_4));
    drop(v205_4);
    let v205_7: Space = if (v205_5).is_empty() { Space::new() } else {
      let mut v206_6 = Space::new();
      let mut v206_6_cursor = (v204_11_tail).read_zipper();
      for v206_6_byte in v206_6_cursor.child_mask().iter() {
        v206_6_cursor.descend_to_byte(v206_6_byte);
        let v206_6_tail = v206_6_cursor.make_map();
        v206_6_cursor.ascend(1);
        let v206_6_head = Path::from_slice(&[v206_6_byte]);
        let v207_2: Space = singleton(&(v206_6_head));
        let v207_3: Space = intersect(&(*CONSTANT_9),&(v207_2));
        let v207_4: Space = if has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
        drop(v207_3);
        let v207_5: Space = subtract(&(*CONSTANT_0),&(v207_4));
        drop(v207_4);
        let v207_8: Space = if (v207_5).is_empty() { Space::new() } else {
          let v208_6: Path = concat_path(&(v204_11_head),&(v206_6_head));
          let v208_7: Space = routine_20(c, &(v208_6), &(*p0), &(v206_6_tail));
          compose(&(v207_5),&(v208_7))
        };
        drop(v207_5);
        let v207_9: Space = intersect(&(*CONSTANT_9),&(v207_2));
        drop(v207_2);
        let v207_10: Space = if has_head(&(v207_9)) { singleton(&[]) } else { Space::new() };
        drop(v207_9);
        let v207_12: Space = if (v207_10).is_empty() { Space::new() } else {
          let v209_6: Path = concat_path(&(v204_11_head),&(v206_6_head));
          let v209_11: Space = routine_21(c, &(v209_6), &(*p0), &(v206_6_tail));
          drop(v209_6);
          compose(&(v207_10),&(v209_11))
        };
        drop(v207_10);
        let v207_13: Space = unite(&(v207_8),&(v207_12));
        v206_6.join_into((v207_13).clone());
      }
      drop(v206_6_cursor);
      compose(&(v205_5),&(v206_6))
    };
    drop(v205_5);
    let v205_8: Space = intersect(&(*CONSTANT_9),&(v205_2));
    drop(v205_2);
    let v205_9: Space = if has_head(&(v205_8)) { singleton(&[]) } else { Space::new() };
    drop(v205_8);
    let v205_11: Space = if (v205_9).is_empty() { Space::new() } else {
      let mut v210_10 = Space::new();
      let mut v210_10_cursor = (v204_11_tail).read_zipper();
      for v210_10_byte in v210_10_cursor.child_mask().iter() {
        v210_10_cursor.descend_to_byte(v210_10_byte);
        let v210_10_tail = v210_10_cursor.make_map();
        v210_10_cursor.ascend(1);
        let v210_10_head = Path::from_slice(&[v210_10_byte]);
        let v211_2: Space = singleton(&(v210_10_head));
        let v211_3: Space = intersect(&(*CONSTANT_9),&(v211_2));
        let v211_4: Space = if has_head(&(v211_3)) { singleton(&[]) } else { Space::new() };
        drop(v211_3);
        let v211_5: Space = subtract(&(*CONSTANT_0),&(v211_4));
        drop(v211_4);
        let v211_7: Space = if (v211_5).is_empty() { Space::new() } else {
          let v212_6: Space = routine_46(c, &(v210_10_head), &(*p0), &(v204_11_head), &(v210_10_tail));
          compose(&(v211_5),&(v212_6))
        };
        drop(v211_5);
        let v211_8: Space = intersect(&(*CONSTANT_9),&(v211_2));
        drop(v211_2);
        let v211_9: Space = if has_head(&(v211_8)) { singleton(&[]) } else { Space::new() };
        drop(v211_8);
        let v211_11: Space = if (v211_9).is_empty() { Space::new() } else {
          let v213_10: Space = routine_47(c, &(v210_10_head), &(*p0), &(v204_11_head), &(v210_10_tail));
          compose(&(v211_9),&(v213_10))
        };
        drop(v211_9);
        let v211_12: Space = unite(&(v211_7),&(v211_11));
        v210_10.join_into((v211_12).clone());
      }
      drop(v210_10_cursor);
      compose(&(v205_9),&(v210_10))
    };
    drop(v205_9);
    let v205_12: Space = unite(&(v205_7),&(v205_11));
    v204_11.join_into((v205_12).clone());
  }
  drop(v204_11_cursor);
  (v204_11).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v214_9 = Space::new();
  let mut v214_9_cursor = (*s0).read_zipper();
  for v214_9_byte in v214_9_cursor.child_mask().iter() {
    v214_9_cursor.descend_to_byte(v214_9_byte);
    let v214_9_tail = v214_9_cursor.make_map();
    v214_9_cursor.ascend(1);
    let v214_9_head = Path::from_slice(&[v214_9_byte]);
    let v215_2: Space = singleton(&(v214_9_head));
    let v215_3: Space = intersect(&(*CONSTANT_9),&(v215_2));
    let v215_4: Space = if has_head(&(v215_3)) { singleton(&[]) } else { Space::new() };
    drop(v215_3);
    let v215_5: Space = subtract(&(*CONSTANT_0),&(v215_4));
    drop(v215_4);
    let v215_8: Space = if (v215_5).is_empty() { Space::new() } else {
      let v216_6: Path = concat_path(&(*p0),&(v214_9_head));
      let v216_7: Space = routine_20(c, &(v216_6), &(*p1), &(v214_9_tail));
      compose(&(v215_5),&(v216_7))
    };
    drop(v215_5);
    let v215_9: Space = intersect(&(*CONSTANT_9),&(v215_2));
    drop(v215_2);
    let v215_10: Space = if has_head(&(v215_9)) { singleton(&[]) } else { Space::new() };
    drop(v215_9);
    let v215_12: Space = if (v215_10).is_empty() { Space::new() } else {
      let v217_6: Path = concat_path(&(*p0),&(v214_9_head));
      let mut v217_11 = Space::new();
      let mut v217_11_cursor = (v214_9_tail).read_zipper();
      for v217_11_byte in v217_11_cursor.child_mask().iter() {
        v217_11_cursor.descend_to_byte(v217_11_byte);
        let v217_11_tail = v217_11_cursor.make_map();
        v217_11_cursor.ascend(1);
        let v217_11_head = Path::from_slice(&[v217_11_byte]);
        let v218_2: Space = singleton(&(v217_11_head));
        let v218_3: Space = intersect(&(*CONSTANT_9),&(v218_2));
        let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
        drop(v218_3);
        let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
        drop(v218_4);
        let v218_7: Space = if (v218_5).is_empty() { Space::new() } else {
          let v219_6: Space = routine_46(c, &(v217_11_head), &(*p1), &(v217_6), &(v217_11_tail));
          compose(&(v218_5),&(v219_6))
        };
        drop(v218_5);
        let v218_8: Space = intersect(&(*CONSTANT_9),&(v218_2));
        drop(v218_2);
        let v218_9: Space = if has_head(&(v218_8)) { singleton(&[]) } else { Space::new() };
        drop(v218_8);
        let v218_11: Space = if (v218_9).is_empty() { Space::new() } else {
          let v220_10: Space = routine_47(c, &(v217_11_head), &(*p1), &(v217_6), &(v217_11_tail));
          compose(&(v218_9),&(v220_10))
        };
        drop(v218_9);
        let v218_12: Space = unite(&(v218_7),&(v218_11));
        v217_11.join_into((v218_12).clone());
      }
      drop(v217_11_cursor);
      drop(v217_6);
      compose(&(v215_10),&(v217_11))
    };
    drop(v215_10);
    let v215_13: Space = unite(&(v215_8),&(v215_12));
    v214_9.join_into((v215_13).clone());
  }
  drop(v214_9_cursor);
  (v214_9).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v221_12 = Space::new();
  let mut v221_12_cursor = (*s0).read_zipper();
  for v221_12_byte in v221_12_cursor.child_mask().iter() {
    v221_12_cursor.descend_to_byte(v221_12_byte);
    let v221_12_tail = v221_12_cursor.make_map();
    v221_12_cursor.ascend(1);
    let v221_12_head = Path::from_slice(&[v221_12_byte]);
    let v222_2: Space = singleton(&(v221_12_head));
    let v222_3: Space = intersect(&(*CONSTANT_9),&(v222_2));
    let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
    drop(v222_3);
    let v222_5: Space = subtract(&(*CONSTANT_0),&(v222_4));
    drop(v222_4);
    let v222_7: Space = if (v222_5).is_empty() { Space::new() } else {
      let mut v223_6 = Space::new();
      let mut v223_6_cursor = (v221_12_tail).read_zipper();
      for v223_6_byte in v223_6_cursor.child_mask().iter() {
        v223_6_cursor.descend_to_byte(v223_6_byte);
        let v223_6_tail = v223_6_cursor.make_map();
        v223_6_cursor.ascend(1);
        let v223_6_head = Path::from_slice(&[v223_6_byte]);
        let v224_2: Space = singleton(&(v223_6_head));
        let v224_3: Space = intersect(&(*CONSTANT_9),&(v224_2));
        let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
        drop(v224_3);
        let v224_5: Space = subtract(&(*CONSTANT_0),&(v224_4));
        drop(v224_4);
        let v224_8: Space = if (v224_5).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v221_12_head),&(v223_6_head));
          let v225_7: Space = routine_46(c, &(v225_6), &(*p1), &(*p0), &(v223_6_tail));
          compose(&(v224_5),&(v225_7))
        };
        drop(v224_5);
        let v224_9: Space = intersect(&(*CONSTANT_9),&(v224_2));
        drop(v224_2);
        let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
        drop(v224_9);
        let v224_12: Space = if (v224_10).is_empty() { Space::new() } else {
          let v226_6: Path = concat_path(&(v221_12_head),&(v223_6_head));
          let v226_11: Space = routine_47(c, &(v226_6), &(*p1), &(*p0), &(v223_6_tail));
          drop(v226_6);
          compose(&(v224_10),&(v226_11))
        };
        drop(v224_10);
        let v224_13: Space = unite(&(v224_8),&(v224_12));
        v223_6.join_into((v224_13).clone());
      }
      drop(v223_6_cursor);
      compose(&(v222_5),&(v223_6))
    };
    drop(v222_5);
    let v222_8: Space = intersect(&(*CONSTANT_9),&(v222_2));
    drop(v222_2);
    let v222_9: Space = if has_head(&(v222_8)) { singleton(&[]) } else { Space::new() };
    drop(v222_8);
    let v222_11: Space = if (v222_9).is_empty() { Space::new() } else {
      let mut v227_10 = Space::new();
      let mut v227_10_cursor = (v221_12_tail).read_zipper();
      for v227_10_byte in v227_10_cursor.child_mask().iter() {
        v227_10_cursor.descend_to_byte(v227_10_byte);
        let v227_10_tail = v227_10_cursor.make_map();
        v227_10_cursor.ascend(1);
        let v227_10_head = Path::from_slice(&[v227_10_byte]);
        let v228_2: Space = singleton(&(v227_10_head));
        let v228_3: Space = intersect(&(*CONSTANT_9),&(v228_2));
        let v228_4: Space = if has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
        drop(v228_3);
        let v228_5: Space = subtract(&(*CONSTANT_0),&(v228_4));
        drop(v228_4);
        let v228_7: Space = if (v228_5).is_empty() { Space::new() } else {
          let v229_6: Space = routine_48(c, &(v227_10_head), &(*p1), &(*p0), &(v221_12_head), &(v227_10_tail));
          compose(&(v228_5),&(v229_6))
        };
        drop(v228_5);
        let v228_8: Space = intersect(&(*CONSTANT_9),&(v228_2));
        drop(v228_2);
        let v228_9: Space = if has_head(&(v228_8)) { singleton(&[]) } else { Space::new() };
        drop(v228_8);
        let v228_11: Space = if (v228_9).is_empty() { Space::new() } else {
          let v230_10: Space = routine_49(c, &(v227_10_head), &(*p1), &(*p0), &(v221_12_head), &(v227_10_tail));
          compose(&(v228_9),&(v230_10))
        };
        drop(v228_9);
        let v228_12: Space = unite(&(v228_7),&(v228_11));
        v227_10.join_into((v228_12).clone());
      }
      drop(v227_10_cursor);
      compose(&(v222_9),&(v227_10))
    };
    drop(v222_9);
    let v222_12: Space = unite(&(v222_7),&(v222_11));
    v221_12.join_into((v222_12).clone());
  }
  drop(v221_12_cursor);
  (v221_12).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v231_8 = Space::new();
  let mut v231_8_cursor = (*s0).read_zipper();
  for v231_8_byte in v231_8_cursor.child_mask().iter() {
    v231_8_cursor.descend_to_byte(v231_8_byte);
    let v231_8_tail = v231_8_cursor.make_map();
    v231_8_cursor.ascend(1);
    let v231_8_head = Path::from_slice(&[v231_8_byte]);
    let v232_2: Space = singleton(&(v231_8_head));
    let v232_3: Space = intersect(&(*CONSTANT_9),&(v232_2));
    let v232_4: Space = if has_head(&(v232_3)) { singleton(&[]) } else { Space::new() };
    drop(v232_3);
    let v232_5: Space = subtract(&(*CONSTANT_0),&(v232_4));
    drop(v232_4);
    let v232_8: Space = if (v232_5).is_empty() { Space::new() } else {
      let v233_6: Path = concat_path(&(*p0),&(v231_8_head));
      let v233_7: Space = routine_22(c, &(v233_6), &(v231_8_tail));
      compose(&(v232_5),&(v233_7))
    };
    drop(v232_5);
    let v232_9: Space = intersect(&(*CONSTANT_9),&(v232_2));
    drop(v232_2);
    let v232_10: Space = if has_head(&(v232_9)) { singleton(&[]) } else { Space::new() };
    drop(v232_9);
    let v232_12: Space = if (v232_10).is_empty() { Space::new() } else {
      let v234_6: Path = concat_path(&(*p0),&(v231_8_head));
      let mut v234_11 = Space::new();
      let mut v234_11_cursor = (v231_8_tail).read_zipper();
      for v234_11_byte in v234_11_cursor.child_mask().iter() {
        v234_11_cursor.descend_to_byte(v234_11_byte);
        let v234_11_tail = v234_11_cursor.make_map();
        v234_11_cursor.ascend(1);
        let v234_11_head = Path::from_slice(&[v234_11_byte]);
        let v235_2: Space = singleton(&(v234_11_head));
        let v235_3: Space = intersect(&(*CONSTANT_9),&(v235_2));
        let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
        drop(v235_3);
        let v235_5: Space = subtract(&(*CONSTANT_0),&(v235_4));
        drop(v235_4);
        let v235_7: Space = if (v235_5).is_empty() { Space::new() } else {
          let v236_6: Space = routine_24(c, &(v234_11_head), &(v234_6), &(v234_11_tail));
          compose(&(v235_5),&(v236_6))
        };
        drop(v235_5);
        let v235_8: Space = intersect(&(*CONSTANT_9),&(v235_2));
        drop(v235_2);
        let v235_9: Space = if has_head(&(v235_8)) { singleton(&[]) } else { Space::new() };
        drop(v235_8);
        let v235_11: Space = if (v235_9).is_empty() { Space::new() } else {
          let v237_10: Space = routine_25(c, &(v234_11_head), &(v234_6), &(v234_11_tail));
          compose(&(v235_9),&(v237_10))
        };
        drop(v235_9);
        let v235_12: Space = unite(&(v235_7),&(v235_11));
        v234_11.join_into((v235_12).clone());
      }
      drop(v234_11_cursor);
      drop(v234_6);
      compose(&(v232_10),&(v234_11))
    };
    drop(v232_10);
    let v232_13: Space = unite(&(v232_8),&(v232_12));
    v231_8.join_into((v232_13).clone());
  }
  drop(v231_8_cursor);
  (v231_8).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v238_11 = Space::new();
  let mut v238_11_cursor = (*s0).read_zipper();
  for v238_11_byte in v238_11_cursor.child_mask().iter() {
    v238_11_cursor.descend_to_byte(v238_11_byte);
    let v238_11_tail = v238_11_cursor.make_map();
    v238_11_cursor.ascend(1);
    let v238_11_head = Path::from_slice(&[v238_11_byte]);
    let v239_2: Space = singleton(&(v238_11_head));
    let v239_3: Space = intersect(&(*CONSTANT_9),&(v239_2));
    let v239_4: Space = if has_head(&(v239_3)) { singleton(&[]) } else { Space::new() };
    drop(v239_3);
    let v239_5: Space = subtract(&(*CONSTANT_0),&(v239_4));
    drop(v239_4);
    let v239_7: Space = if (v239_5).is_empty() { Space::new() } else {
      let mut v240_6 = Space::new();
      let mut v240_6_cursor = (v238_11_tail).read_zipper();
      for v240_6_byte in v240_6_cursor.child_mask().iter() {
        v240_6_cursor.descend_to_byte(v240_6_byte);
        let v240_6_tail = v240_6_cursor.make_map();
        v240_6_cursor.ascend(1);
        let v240_6_head = Path::from_slice(&[v240_6_byte]);
        let v241_2: Space = singleton(&(v240_6_head));
        let v241_3: Space = intersect(&(*CONSTANT_9),&(v241_2));
        let v241_4: Space = if has_head(&(v241_3)) { singleton(&[]) } else { Space::new() };
        drop(v241_3);
        let v241_5: Space = subtract(&(*CONSTANT_0),&(v241_4));
        drop(v241_4);
        let v241_8: Space = if (v241_5).is_empty() { Space::new() } else {
          let v242_6: Path = concat_path(&(v238_11_head),&(v240_6_head));
          let v242_7: Space = routine_24(c, &(v242_6), &(*p0), &(v240_6_tail));
          compose(&(v241_5),&(v242_7))
        };
        drop(v241_5);
        let v241_9: Space = intersect(&(*CONSTANT_9),&(v241_2));
        drop(v241_2);
        let v241_10: Space = if has_head(&(v241_9)) { singleton(&[]) } else { Space::new() };
        drop(v241_9);
        let v241_12: Space = if (v241_10).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v238_11_head),&(v240_6_head));
          let v243_11: Space = routine_25(c, &(v243_6), &(*p0), &(v240_6_tail));
          drop(v243_6);
          compose(&(v241_10),&(v243_11))
        };
        drop(v241_10);
        let v241_13: Space = unite(&(v241_8),&(v241_12));
        v240_6.join_into((v241_13).clone());
      }
      drop(v240_6_cursor);
      compose(&(v239_5),&(v240_6))
    };
    drop(v239_5);
    let v239_8: Space = intersect(&(*CONSTANT_9),&(v239_2));
    drop(v239_2);
    let v239_9: Space = if has_head(&(v239_8)) { singleton(&[]) } else { Space::new() };
    drop(v239_8);
    let v239_11: Space = if (v239_9).is_empty() { Space::new() } else {
      let mut v244_10 = Space::new();
      let mut v244_10_cursor = (v238_11_tail).read_zipper();
      for v244_10_byte in v244_10_cursor.child_mask().iter() {
        v244_10_cursor.descend_to_byte(v244_10_byte);
        let v244_10_tail = v244_10_cursor.make_map();
        v244_10_cursor.ascend(1);
        let v244_10_head = Path::from_slice(&[v244_10_byte]);
        let v245_2: Space = singleton(&(v244_10_head));
        let v245_3: Space = intersect(&(*CONSTANT_9),&(v245_2));
        let v245_4: Space = if has_head(&(v245_3)) { singleton(&[]) } else { Space::new() };
        drop(v245_3);
        let v245_5: Space = subtract(&(*CONSTANT_0),&(v245_4));
        drop(v245_4);
        let v245_7: Space = if (v245_5).is_empty() { Space::new() } else {
          let v246_6: Space = routine_50(c, &(v244_10_head), &(*p0), &(v238_11_head), &(v244_10_tail));
          compose(&(v245_5),&(v246_6))
        };
        drop(v245_5);
        let v245_8: Space = intersect(&(*CONSTANT_9),&(v245_2));
        drop(v245_2);
        let v245_9: Space = if has_head(&(v245_8)) { singleton(&[]) } else { Space::new() };
        drop(v245_8);
        let v245_11: Space = if (v245_9).is_empty() { Space::new() } else {
          let v247_10: Space = routine_51(c, &(v244_10_head), &(*p0), &(v238_11_head), &(v244_10_tail));
          compose(&(v245_9),&(v247_10))
        };
        drop(v245_9);
        let v245_12: Space = unite(&(v245_7),&(v245_11));
        v244_10.join_into((v245_12).clone());
      }
      drop(v244_10_cursor);
      compose(&(v239_9),&(v244_10))
    };
    drop(v239_9);
    let v239_12: Space = unite(&(v239_7),&(v239_11));
    v238_11.join_into((v239_12).clone());
  }
  drop(v238_11_cursor);
  (v238_11).clone()
}

fn routine_24(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v248_9 = Space::new();
  let mut v248_9_cursor = (*s0).read_zipper();
  for v248_9_byte in v248_9_cursor.child_mask().iter() {
    v248_9_cursor.descend_to_byte(v248_9_byte);
    let v248_9_tail = v248_9_cursor.make_map();
    v248_9_cursor.ascend(1);
    let v248_9_head = Path::from_slice(&[v248_9_byte]);
    let v249_2: Space = singleton(&(v248_9_head));
    let v249_3: Space = intersect(&(*CONSTANT_9),&(v249_2));
    let v249_4: Space = if has_head(&(v249_3)) { singleton(&[]) } else { Space::new() };
    drop(v249_3);
    let v249_5: Space = subtract(&(*CONSTANT_0),&(v249_4));
    drop(v249_4);
    let v249_8: Space = if (v249_5).is_empty() { Space::new() } else {
      let v250_6: Path = concat_path(&(*p0),&(v248_9_head));
      let v250_7: Space = routine_24(c, &(v250_6), &(*p1), &(v248_9_tail));
      compose(&(v249_5),&(v250_7))
    };
    drop(v249_5);
    let v249_9: Space = intersect(&(*CONSTANT_9),&(v249_2));
    drop(v249_2);
    let v249_10: Space = if has_head(&(v249_9)) { singleton(&[]) } else { Space::new() };
    drop(v249_9);
    let v249_12: Space = if (v249_10).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&(v248_9_head));
      let mut v251_11 = Space::new();
      let mut v251_11_cursor = (v248_9_tail).read_zipper();
      for v251_11_byte in v251_11_cursor.child_mask().iter() {
        v251_11_cursor.descend_to_byte(v251_11_byte);
        let v251_11_tail = v251_11_cursor.make_map();
        v251_11_cursor.ascend(1);
        let v251_11_head = Path::from_slice(&[v251_11_byte]);
        let v252_2: Space = singleton(&(v251_11_head));
        let v252_3: Space = intersect(&(*CONSTANT_9),&(v252_2));
        let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = subtract(&(*CONSTANT_0),&(v252_4));
        drop(v252_4);
        let v252_7: Space = if (v252_5).is_empty() { Space::new() } else {
          let v253_6: Space = routine_50(c, &(v251_11_head), &(*p1), &(v251_6), &(v251_11_tail));
          compose(&(v252_5),&(v253_6))
        };
        drop(v252_5);
        let v252_8: Space = intersect(&(*CONSTANT_9),&(v252_2));
        drop(v252_2);
        let v252_9: Space = if has_head(&(v252_8)) { singleton(&[]) } else { Space::new() };
        drop(v252_8);
        let v252_11: Space = if (v252_9).is_empty() { Space::new() } else {
          let v254_10: Space = routine_51(c, &(v251_11_head), &(*p1), &(v251_6), &(v251_11_tail));
          compose(&(v252_9),&(v254_10))
        };
        drop(v252_9);
        let v252_12: Space = unite(&(v252_7),&(v252_11));
        v251_11.join_into((v252_12).clone());
      }
      drop(v251_11_cursor);
      drop(v251_6);
      compose(&(v249_10),&(v251_11))
    };
    drop(v249_10);
    let v249_13: Space = unite(&(v249_8),&(v249_12));
    v248_9.join_into((v249_13).clone());
  }
  drop(v248_9_cursor);
  (v248_9).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v255_12 = Space::new();
  let mut v255_12_cursor = (*s0).read_zipper();
  for v255_12_byte in v255_12_cursor.child_mask().iter() {
    v255_12_cursor.descend_to_byte(v255_12_byte);
    let v255_12_tail = v255_12_cursor.make_map();
    v255_12_cursor.ascend(1);
    let v255_12_head = Path::from_slice(&[v255_12_byte]);
    let v256_2: Space = singleton(&(v255_12_head));
    let v256_3: Space = intersect(&(*CONSTANT_9),&(v256_2));
    let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
    drop(v256_3);
    let v256_5: Space = subtract(&(*CONSTANT_0),&(v256_4));
    drop(v256_4);
    let v256_7: Space = if (v256_5).is_empty() { Space::new() } else {
      let mut v257_6 = Space::new();
      let mut v257_6_cursor = (v255_12_tail).read_zipper();
      for v257_6_byte in v257_6_cursor.child_mask().iter() {
        v257_6_cursor.descend_to_byte(v257_6_byte);
        let v257_6_tail = v257_6_cursor.make_map();
        v257_6_cursor.ascend(1);
        let v257_6_head = Path::from_slice(&[v257_6_byte]);
        let v258_2: Space = singleton(&(v257_6_head));
        let v258_3: Space = intersect(&(*CONSTANT_9),&(v258_2));
        let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
        drop(v258_3);
        let v258_5: Space = subtract(&(*CONSTANT_0),&(v258_4));
        drop(v258_4);
        let v258_8: Space = if (v258_5).is_empty() { Space::new() } else {
          let v259_6: Path = concat_path(&(v255_12_head),&(v257_6_head));
          let v259_7: Space = routine_50(c, &(v259_6), &(*p1), &(*p0), &(v257_6_tail));
          compose(&(v258_5),&(v259_7))
        };
        drop(v258_5);
        let v258_9: Space = intersect(&(*CONSTANT_9),&(v258_2));
        drop(v258_2);
        let v258_10: Space = if has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
        drop(v258_9);
        let v258_12: Space = if (v258_10).is_empty() { Space::new() } else {
          let v260_6: Path = concat_path(&(v255_12_head),&(v257_6_head));
          let v260_11: Space = routine_51(c, &(v260_6), &(*p1), &(*p0), &(v257_6_tail));
          drop(v260_6);
          compose(&(v258_10),&(v260_11))
        };
        drop(v258_10);
        let v258_13: Space = unite(&(v258_8),&(v258_12));
        v257_6.join_into((v258_13).clone());
      }
      drop(v257_6_cursor);
      compose(&(v256_5),&(v257_6))
    };
    drop(v256_5);
    let v256_8: Space = intersect(&(*CONSTANT_9),&(v256_2));
    drop(v256_2);
    let v256_9: Space = if has_head(&(v256_8)) { singleton(&[]) } else { Space::new() };
    drop(v256_8);
    let v256_11: Space = if (v256_9).is_empty() { Space::new() } else {
      let mut v261_10 = Space::new();
      let mut v261_10_cursor = (v255_12_tail).read_zipper();
      for v261_10_byte in v261_10_cursor.child_mask().iter() {
        v261_10_cursor.descend_to_byte(v261_10_byte);
        let v261_10_tail = v261_10_cursor.make_map();
        v261_10_cursor.ascend(1);
        let v261_10_head = Path::from_slice(&[v261_10_byte]);
        let v262_2: Space = singleton(&(v261_10_head));
        let v262_3: Space = intersect(&(*CONSTANT_9),&(v262_2));
        let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
        drop(v262_3);
        let v262_5: Space = subtract(&(*CONSTANT_0),&(v262_4));
        drop(v262_4);
        let v262_7: Space = if (v262_5).is_empty() { Space::new() } else {
          let v263_6: Space = routine_52(c, &(v261_10_head), &(*p1), &(*p0), &(v255_12_head), &(v261_10_tail));
          compose(&(v262_5),&(v263_6))
        };
        drop(v262_5);
        let v262_8: Space = intersect(&(*CONSTANT_9),&(v262_2));
        drop(v262_2);
        let v262_9: Space = if has_head(&(v262_8)) { singleton(&[]) } else { Space::new() };
        drop(v262_8);
        let v262_11: Space = if (v262_9).is_empty() { Space::new() } else {
          let v264_10: Space = routine_53(c, &(v261_10_head), &(*p1), &(*p0), &(v255_12_head), &(v261_10_tail));
          compose(&(v262_9),&(v264_10))
        };
        drop(v262_9);
        let v262_12: Space = unite(&(v262_7),&(v262_11));
        v261_10.join_into((v262_12).clone());
      }
      drop(v261_10_cursor);
      compose(&(v256_9),&(v261_10))
    };
    drop(v256_9);
    let v256_12: Space = unite(&(v256_7),&(v256_11));
    v255_12.join_into((v256_12).clone());
  }
  drop(v255_12_cursor);
  (v255_12).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v265_8 = Space::new();
  let mut v265_8_cursor = (*s0).read_zipper();
  for v265_8_byte in v265_8_cursor.child_mask().iter() {
    v265_8_cursor.descend_to_byte(v265_8_byte);
    let v265_8_tail = v265_8_cursor.make_map();
    v265_8_cursor.ascend(1);
    let v265_8_head = Path::from_slice(&[v265_8_byte]);
    let v266_2: Space = singleton(&(v265_8_head));
    let v266_3: Space = intersect(&(*CONSTANT_9),&(v266_2));
    let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
    drop(v266_3);
    let v266_5: Space = subtract(&(*CONSTANT_0),&(v266_4));
    drop(v266_4);
    let v266_8: Space = if (v266_5).is_empty() { Space::new() } else {
      let v267_6: Path = concat_path(&(*p0),&(v265_8_head));
      let v267_7: Space = routine_26(c, &(v267_6), &(v265_8_tail));
      compose(&(v266_5),&(v267_7))
    };
    drop(v266_5);
    let v266_9: Space = intersect(&(*CONSTANT_9),&(v266_2));
    drop(v266_2);
    let v266_10: Space = if has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
    drop(v266_9);
    let v266_12: Space = if (v266_10).is_empty() { Space::new() } else {
      let v268_6: Path = concat_path(&(*p0),&(v265_8_head));
      let mut v268_11 = Space::new();
      let mut v268_11_cursor = (v265_8_tail).read_zipper();
      for v268_11_byte in v268_11_cursor.child_mask().iter() {
        v268_11_cursor.descend_to_byte(v268_11_byte);
        let v268_11_tail = v268_11_cursor.make_map();
        v268_11_cursor.ascend(1);
        let v268_11_head = Path::from_slice(&[v268_11_byte]);
        let v269_2: Space = singleton(&(v268_11_head));
        let v269_3: Space = intersect(&(*CONSTANT_9),&(v269_2));
        let v269_4: Space = if has_head(&(v269_3)) { singleton(&[]) } else { Space::new() };
        drop(v269_3);
        let v269_5: Space = subtract(&(*CONSTANT_0),&(v269_4));
        drop(v269_4);
        let v269_7: Space = if (v269_5).is_empty() { Space::new() } else {
          let v270_6: Space = routine_28(c, &(v268_11_head), &(v268_6), &(v268_11_tail));
          compose(&(v269_5),&(v270_6))
        };
        drop(v269_5);
        let v269_8: Space = intersect(&(*CONSTANT_9),&(v269_2));
        drop(v269_2);
        let v269_9: Space = if has_head(&(v269_8)) { singleton(&[]) } else { Space::new() };
        drop(v269_8);
        let v269_11: Space = if (v269_9).is_empty() { Space::new() } else {
          let v271_10: Space = routine_29(c, &(v268_11_head), &(v268_6), &(v268_11_tail));
          compose(&(v269_9),&(v271_10))
        };
        drop(v269_9);
        let v269_12: Space = unite(&(v269_7),&(v269_11));
        v268_11.join_into((v269_12).clone());
      }
      drop(v268_11_cursor);
      drop(v268_6);
      compose(&(v266_10),&(v268_11))
    };
    drop(v266_10);
    let v266_13: Space = unite(&(v266_8),&(v266_12));
    v265_8.join_into((v266_13).clone());
  }
  drop(v265_8_cursor);
  (v265_8).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v272_11 = Space::new();
  let mut v272_11_cursor = (*s0).read_zipper();
  for v272_11_byte in v272_11_cursor.child_mask().iter() {
    v272_11_cursor.descend_to_byte(v272_11_byte);
    let v272_11_tail = v272_11_cursor.make_map();
    v272_11_cursor.ascend(1);
    let v272_11_head = Path::from_slice(&[v272_11_byte]);
    let v273_2: Space = singleton(&(v272_11_head));
    let v273_3: Space = intersect(&(*CONSTANT_9),&(v273_2));
    let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
    drop(v273_3);
    let v273_5: Space = subtract(&(*CONSTANT_0),&(v273_4));
    drop(v273_4);
    let v273_7: Space = if (v273_5).is_empty() { Space::new() } else {
      let mut v274_6 = Space::new();
      let mut v274_6_cursor = (v272_11_tail).read_zipper();
      for v274_6_byte in v274_6_cursor.child_mask().iter() {
        v274_6_cursor.descend_to_byte(v274_6_byte);
        let v274_6_tail = v274_6_cursor.make_map();
        v274_6_cursor.ascend(1);
        let v274_6_head = Path::from_slice(&[v274_6_byte]);
        let v275_2: Space = singleton(&(v274_6_head));
        let v275_3: Space = intersect(&(*CONSTANT_9),&(v275_2));
        let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
        drop(v275_3);
        let v275_5: Space = subtract(&(*CONSTANT_0),&(v275_4));
        drop(v275_4);
        let v275_8: Space = if (v275_5).is_empty() { Space::new() } else {
          let v276_6: Path = concat_path(&(v272_11_head),&(v274_6_head));
          let v276_7: Space = routine_28(c, &(v276_6), &(*p0), &(v274_6_tail));
          compose(&(v275_5),&(v276_7))
        };
        drop(v275_5);
        let v275_9: Space = intersect(&(*CONSTANT_9),&(v275_2));
        drop(v275_2);
        let v275_10: Space = if has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
        drop(v275_9);
        let v275_12: Space = if (v275_10).is_empty() { Space::new() } else {
          let v277_6: Path = concat_path(&(v272_11_head),&(v274_6_head));
          let v277_11: Space = routine_29(c, &(v277_6), &(*p0), &(v274_6_tail));
          drop(v277_6);
          compose(&(v275_10),&(v277_11))
        };
        drop(v275_10);
        let v275_13: Space = unite(&(v275_8),&(v275_12));
        v274_6.join_into((v275_13).clone());
      }
      drop(v274_6_cursor);
      compose(&(v273_5),&(v274_6))
    };
    drop(v273_5);
    let v273_8: Space = intersect(&(*CONSTANT_9),&(v273_2));
    drop(v273_2);
    let v273_9: Space = if has_head(&(v273_8)) { singleton(&[]) } else { Space::new() };
    drop(v273_8);
    let v273_11: Space = if (v273_9).is_empty() { Space::new() } else {
      let mut v278_10 = Space::new();
      let mut v278_10_cursor = (v272_11_tail).read_zipper();
      for v278_10_byte in v278_10_cursor.child_mask().iter() {
        v278_10_cursor.descend_to_byte(v278_10_byte);
        let v278_10_tail = v278_10_cursor.make_map();
        v278_10_cursor.ascend(1);
        let v278_10_head = Path::from_slice(&[v278_10_byte]);
        let v279_2: Space = singleton(&(v278_10_head));
        let v279_3: Space = intersect(&(*CONSTANT_9),&(v279_2));
        let v279_4: Space = if has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
        drop(v279_3);
        let v279_5: Space = subtract(&(*CONSTANT_0),&(v279_4));
        drop(v279_4);
        let v279_7: Space = if (v279_5).is_empty() { Space::new() } else {
          let v280_6: Space = routine_54(c, &(v278_10_head), &(*p0), &(v272_11_head), &(v278_10_tail));
          compose(&(v279_5),&(v280_6))
        };
        drop(v279_5);
        let v279_8: Space = intersect(&(*CONSTANT_9),&(v279_2));
        drop(v279_2);
        let v279_9: Space = if has_head(&(v279_8)) { singleton(&[]) } else { Space::new() };
        drop(v279_8);
        let v279_11: Space = if (v279_9).is_empty() { Space::new() } else {
          let v281_10: Space = routine_55(c, &(v278_10_head), &(*p0), &(v272_11_head), &(v278_10_tail));
          compose(&(v279_9),&(v281_10))
        };
        drop(v279_9);
        let v279_12: Space = unite(&(v279_7),&(v279_11));
        v278_10.join_into((v279_12).clone());
      }
      drop(v278_10_cursor);
      compose(&(v273_9),&(v278_10))
    };
    drop(v273_9);
    let v273_12: Space = unite(&(v273_7),&(v273_11));
    v272_11.join_into((v273_12).clone());
  }
  drop(v272_11_cursor);
  (v272_11).clone()
}

fn routine_28(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v282_9 = Space::new();
  let mut v282_9_cursor = (*s0).read_zipper();
  for v282_9_byte in v282_9_cursor.child_mask().iter() {
    v282_9_cursor.descend_to_byte(v282_9_byte);
    let v282_9_tail = v282_9_cursor.make_map();
    v282_9_cursor.ascend(1);
    let v282_9_head = Path::from_slice(&[v282_9_byte]);
    let v283_2: Space = singleton(&(v282_9_head));
    let v283_3: Space = intersect(&(*CONSTANT_9),&(v283_2));
    let v283_4: Space = if has_head(&(v283_3)) { singleton(&[]) } else { Space::new() };
    drop(v283_3);
    let v283_5: Space = subtract(&(*CONSTANT_0),&(v283_4));
    drop(v283_4);
    let v283_8: Space = if (v283_5).is_empty() { Space::new() } else {
      let v284_6: Path = concat_path(&(*p0),&(v282_9_head));
      let v284_7: Space = routine_28(c, &(v284_6), &(*p1), &(v282_9_tail));
      compose(&(v283_5),&(v284_7))
    };
    drop(v283_5);
    let v283_9: Space = intersect(&(*CONSTANT_9),&(v283_2));
    drop(v283_2);
    let v283_10: Space = if has_head(&(v283_9)) { singleton(&[]) } else { Space::new() };
    drop(v283_9);
    let v283_12: Space = if (v283_10).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&(v282_9_head));
      let mut v285_11 = Space::new();
      let mut v285_11_cursor = (v282_9_tail).read_zipper();
      for v285_11_byte in v285_11_cursor.child_mask().iter() {
        v285_11_cursor.descend_to_byte(v285_11_byte);
        let v285_11_tail = v285_11_cursor.make_map();
        v285_11_cursor.ascend(1);
        let v285_11_head = Path::from_slice(&[v285_11_byte]);
        let v286_2: Space = singleton(&(v285_11_head));
        let v286_3: Space = intersect(&(*CONSTANT_9),&(v286_2));
        let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = subtract(&(*CONSTANT_0),&(v286_4));
        drop(v286_4);
        let v286_7: Space = if (v286_5).is_empty() { Space::new() } else {
          let v287_6: Space = routine_54(c, &(v285_11_head), &(*p1), &(v285_6), &(v285_11_tail));
          compose(&(v286_5),&(v287_6))
        };
        drop(v286_5);
        let v286_8: Space = intersect(&(*CONSTANT_9),&(v286_2));
        drop(v286_2);
        let v286_9: Space = if has_head(&(v286_8)) { singleton(&[]) } else { Space::new() };
        drop(v286_8);
        let v286_11: Space = if (v286_9).is_empty() { Space::new() } else {
          let v288_10: Space = routine_55(c, &(v285_11_head), &(*p1), &(v285_6), &(v285_11_tail));
          compose(&(v286_9),&(v288_10))
        };
        drop(v286_9);
        let v286_12: Space = unite(&(v286_7),&(v286_11));
        v285_11.join_into((v286_12).clone());
      }
      drop(v285_11_cursor);
      drop(v285_6);
      compose(&(v283_10),&(v285_11))
    };
    drop(v283_10);
    let v283_13: Space = unite(&(v283_8),&(v283_12));
    v282_9.join_into((v283_13).clone());
  }
  drop(v282_9_cursor);
  (v282_9).clone()
}

fn routine_29(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v289_12 = Space::new();
  let mut v289_12_cursor = (*s0).read_zipper();
  for v289_12_byte in v289_12_cursor.child_mask().iter() {
    v289_12_cursor.descend_to_byte(v289_12_byte);
    let v289_12_tail = v289_12_cursor.make_map();
    v289_12_cursor.ascend(1);
    let v289_12_head = Path::from_slice(&[v289_12_byte]);
    let v290_2: Space = singleton(&(v289_12_head));
    let v290_3: Space = intersect(&(*CONSTANT_9),&(v290_2));
    let v290_4: Space = if has_head(&(v290_3)) { singleton(&[]) } else { Space::new() };
    drop(v290_3);
    let v290_5: Space = subtract(&(*CONSTANT_0),&(v290_4));
    drop(v290_4);
    let v290_7: Space = if (v290_5).is_empty() { Space::new() } else {
      let mut v291_6 = Space::new();
      let mut v291_6_cursor = (v289_12_tail).read_zipper();
      for v291_6_byte in v291_6_cursor.child_mask().iter() {
        v291_6_cursor.descend_to_byte(v291_6_byte);
        let v291_6_tail = v291_6_cursor.make_map();
        v291_6_cursor.ascend(1);
        let v291_6_head = Path::from_slice(&[v291_6_byte]);
        let v292_2: Space = singleton(&(v291_6_head));
        let v292_3: Space = intersect(&(*CONSTANT_9),&(v292_2));
        let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
        drop(v292_3);
        let v292_5: Space = subtract(&(*CONSTANT_0),&(v292_4));
        drop(v292_4);
        let v292_8: Space = if (v292_5).is_empty() { Space::new() } else {
          let v293_6: Path = concat_path(&(v289_12_head),&(v291_6_head));
          let v293_7: Space = routine_54(c, &(v293_6), &(*p1), &(*p0), &(v291_6_tail));
          compose(&(v292_5),&(v293_7))
        };
        drop(v292_5);
        let v292_9: Space = intersect(&(*CONSTANT_9),&(v292_2));
        drop(v292_2);
        let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
        drop(v292_9);
        let v292_12: Space = if (v292_10).is_empty() { Space::new() } else {
          let v294_6: Path = concat_path(&(v289_12_head),&(v291_6_head));
          let v294_11: Space = routine_55(c, &(v294_6), &(*p1), &(*p0), &(v291_6_tail));
          drop(v294_6);
          compose(&(v292_10),&(v294_11))
        };
        drop(v292_10);
        let v292_13: Space = unite(&(v292_8),&(v292_12));
        v291_6.join_into((v292_13).clone());
      }
      drop(v291_6_cursor);
      compose(&(v290_5),&(v291_6))
    };
    drop(v290_5);
    let v290_8: Space = intersect(&(*CONSTANT_9),&(v290_2));
    drop(v290_2);
    let v290_9: Space = if has_head(&(v290_8)) { singleton(&[]) } else { Space::new() };
    drop(v290_8);
    let v290_11: Space = if (v290_9).is_empty() { Space::new() } else {
      let mut v295_10 = Space::new();
      let mut v295_10_cursor = (v289_12_tail).read_zipper();
      for v295_10_byte in v295_10_cursor.child_mask().iter() {
        v295_10_cursor.descend_to_byte(v295_10_byte);
        let v295_10_tail = v295_10_cursor.make_map();
        v295_10_cursor.ascend(1);
        let v295_10_head = Path::from_slice(&[v295_10_byte]);
        let v296_2: Space = singleton(&(v295_10_head));
        let v296_3: Space = intersect(&(*CONSTANT_9),&(v296_2));
        let v296_4: Space = if has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = subtract(&(*CONSTANT_0),&(v296_4));
        drop(v296_4);
        let v296_7: Space = if (v296_5).is_empty() { Space::new() } else {
          let v297_6: Space = routine_56(c, &(v295_10_head), &(*p1), &(*p0), &(v289_12_head), &(v295_10_tail));
          compose(&(v296_5),&(v297_6))
        };
        drop(v296_5);
        let v296_8: Space = intersect(&(*CONSTANT_9),&(v296_2));
        drop(v296_2);
        let v296_9: Space = if has_head(&(v296_8)) { singleton(&[]) } else { Space::new() };
        drop(v296_8);
        let v296_11: Space = if (v296_9).is_empty() { Space::new() } else {
          let v298_10: Space = routine_57(c, &(v295_10_head), &(*p1), &(*p0), &(v289_12_head), &(v295_10_tail));
          compose(&(v296_9),&(v298_10))
        };
        drop(v296_9);
        let v296_12: Space = unite(&(v296_7),&(v296_11));
        v295_10.join_into((v296_12).clone());
      }
      drop(v295_10_cursor);
      compose(&(v290_9),&(v295_10))
    };
    drop(v290_9);
    let v290_12: Space = unite(&(v290_7),&(v290_11));
    v289_12.join_into((v290_12).clone());
  }
  drop(v289_12_cursor);
  (v289_12).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v299_8 = Space::new();
  let mut v299_8_cursor = (*s0).read_zipper();
  for v299_8_byte in v299_8_cursor.child_mask().iter() {
    v299_8_cursor.descend_to_byte(v299_8_byte);
    let v299_8_tail = v299_8_cursor.make_map();
    v299_8_cursor.ascend(1);
    let v299_8_head = Path::from_slice(&[v299_8_byte]);
    let v300_2: Space = singleton(&(v299_8_head));
    let v300_3: Space = intersect(&(*CONSTANT_9),&(v300_2));
    let v300_4: Space = if has_head(&(v300_3)) { singleton(&[]) } else { Space::new() };
    drop(v300_3);
    let v300_5: Space = subtract(&(*CONSTANT_0),&(v300_4));
    drop(v300_4);
    let v300_8: Space = if (v300_5).is_empty() { Space::new() } else {
      let v301_6: Path = concat_path(&(*p0),&(v299_8_head));
      let v301_7: Space = routine_30(c, &(v301_6), &(v299_8_tail));
      compose(&(v300_5),&(v301_7))
    };
    drop(v300_5);
    let v300_9: Space = intersect(&(*CONSTANT_9),&(v300_2));
    drop(v300_2);
    let v300_10: Space = if has_head(&(v300_9)) { singleton(&[]) } else { Space::new() };
    drop(v300_9);
    let v300_12: Space = if (v300_10).is_empty() { Space::new() } else {
      let v302_6: Path = concat_path(&(*p0),&(v299_8_head));
      let mut v302_11 = Space::new();
      let mut v302_11_cursor = (v299_8_tail).read_zipper();
      for v302_11_byte in v302_11_cursor.child_mask().iter() {
        v302_11_cursor.descend_to_byte(v302_11_byte);
        let v302_11_tail = v302_11_cursor.make_map();
        v302_11_cursor.ascend(1);
        let v302_11_head = Path::from_slice(&[v302_11_byte]);
        let v303_2: Space = singleton(&(v302_11_head));
        let v303_3: Space = intersect(&(*CONSTANT_9),&(v303_2));
        let v303_4: Space = if has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
        drop(v303_3);
        let v303_5: Space = subtract(&(*CONSTANT_0),&(v303_4));
        drop(v303_4);
        let v303_7: Space = if (v303_5).is_empty() { Space::new() } else {
          let v304_6: Space = routine_32(c, &(v302_11_head), &(v302_6), &(v302_11_tail));
          compose(&(v303_5),&(v304_6))
        };
        drop(v303_5);
        let v303_8: Space = intersect(&(*CONSTANT_9),&(v303_2));
        drop(v303_2);
        let v303_9: Space = if has_head(&(v303_8)) { singleton(&[]) } else { Space::new() };
        drop(v303_8);
        let v303_11: Space = if (v303_9).is_empty() { Space::new() } else {
          let v305_10: Space = routine_33(c, &(v302_11_head), &(v302_6), &(v302_11_tail));
          compose(&(v303_9),&(v305_10))
        };
        drop(v303_9);
        let v303_12: Space = unite(&(v303_7),&(v303_11));
        v302_11.join_into((v303_12).clone());
      }
      drop(v302_11_cursor);
      drop(v302_6);
      compose(&(v300_10),&(v302_11))
    };
    drop(v300_10);
    let v300_13: Space = unite(&(v300_8),&(v300_12));
    v299_8.join_into((v300_13).clone());
  }
  drop(v299_8_cursor);
  (v299_8).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v306_11 = Space::new();
  let mut v306_11_cursor = (*s0).read_zipper();
  for v306_11_byte in v306_11_cursor.child_mask().iter() {
    v306_11_cursor.descend_to_byte(v306_11_byte);
    let v306_11_tail = v306_11_cursor.make_map();
    v306_11_cursor.ascend(1);
    let v306_11_head = Path::from_slice(&[v306_11_byte]);
    let v307_2: Space = singleton(&(v306_11_head));
    let v307_3: Space = intersect(&(*CONSTANT_9),&(v307_2));
    let v307_4: Space = if has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
    drop(v307_3);
    let v307_5: Space = subtract(&(*CONSTANT_0),&(v307_4));
    drop(v307_4);
    let v307_7: Space = if (v307_5).is_empty() { Space::new() } else {
      let mut v308_6 = Space::new();
      let mut v308_6_cursor = (v306_11_tail).read_zipper();
      for v308_6_byte in v308_6_cursor.child_mask().iter() {
        v308_6_cursor.descend_to_byte(v308_6_byte);
        let v308_6_tail = v308_6_cursor.make_map();
        v308_6_cursor.ascend(1);
        let v308_6_head = Path::from_slice(&[v308_6_byte]);
        let v309_2: Space = singleton(&(v308_6_head));
        let v309_3: Space = intersect(&(*CONSTANT_9),&(v309_2));
        let v309_4: Space = if has_head(&(v309_3)) { singleton(&[]) } else { Space::new() };
        drop(v309_3);
        let v309_5: Space = subtract(&(*CONSTANT_0),&(v309_4));
        drop(v309_4);
        let v309_8: Space = if (v309_5).is_empty() { Space::new() } else {
          let v310_6: Path = concat_path(&(v306_11_head),&(v308_6_head));
          let v310_7: Space = routine_32(c, &(v310_6), &(*p0), &(v308_6_tail));
          compose(&(v309_5),&(v310_7))
        };
        drop(v309_5);
        let v309_9: Space = intersect(&(*CONSTANT_9),&(v309_2));
        drop(v309_2);
        let v309_10: Space = if has_head(&(v309_9)) { singleton(&[]) } else { Space::new() };
        drop(v309_9);
        let v309_12: Space = if (v309_10).is_empty() { Space::new() } else {
          let v311_6: Path = concat_path(&(v306_11_head),&(v308_6_head));
          let v311_11: Space = routine_33(c, &(v311_6), &(*p0), &(v308_6_tail));
          drop(v311_6);
          compose(&(v309_10),&(v311_11))
        };
        drop(v309_10);
        let v309_13: Space = unite(&(v309_8),&(v309_12));
        v308_6.join_into((v309_13).clone());
      }
      drop(v308_6_cursor);
      compose(&(v307_5),&(v308_6))
    };
    drop(v307_5);
    let v307_8: Space = intersect(&(*CONSTANT_9),&(v307_2));
    drop(v307_2);
    let v307_9: Space = if has_head(&(v307_8)) { singleton(&[]) } else { Space::new() };
    drop(v307_8);
    let v307_11: Space = if (v307_9).is_empty() { Space::new() } else {
      let mut v312_10 = Space::new();
      let mut v312_10_cursor = (v306_11_tail).read_zipper();
      for v312_10_byte in v312_10_cursor.child_mask().iter() {
        v312_10_cursor.descend_to_byte(v312_10_byte);
        let v312_10_tail = v312_10_cursor.make_map();
        v312_10_cursor.ascend(1);
        let v312_10_head = Path::from_slice(&[v312_10_byte]);
        let v313_2: Space = singleton(&(v312_10_head));
        let v313_3: Space = intersect(&(*CONSTANT_9),&(v313_2));
        let v313_4: Space = if has_head(&(v313_3)) { singleton(&[]) } else { Space::new() };
        drop(v313_3);
        let v313_5: Space = subtract(&(*CONSTANT_0),&(v313_4));
        drop(v313_4);
        let v313_7: Space = if (v313_5).is_empty() { Space::new() } else {
          let v314_6: Space = routine_58(c, &(v312_10_head), &(*p0), &(v306_11_head), &(v312_10_tail));
          compose(&(v313_5),&(v314_6))
        };
        drop(v313_5);
        let v313_8: Space = intersect(&(*CONSTANT_9),&(v313_2));
        drop(v313_2);
        let v313_9: Space = if has_head(&(v313_8)) { singleton(&[]) } else { Space::new() };
        drop(v313_8);
        let v313_11: Space = if (v313_9).is_empty() { Space::new() } else {
          let v315_10: Space = routine_59(c, &(v312_10_head), &(*p0), &(v306_11_head), &(v312_10_tail));
          compose(&(v313_9),&(v315_10))
        };
        drop(v313_9);
        let v313_12: Space = unite(&(v313_7),&(v313_11));
        v312_10.join_into((v313_12).clone());
      }
      drop(v312_10_cursor);
      compose(&(v307_9),&(v312_10))
    };
    drop(v307_9);
    let v307_12: Space = unite(&(v307_7),&(v307_11));
    v306_11.join_into((v307_12).clone());
  }
  drop(v306_11_cursor);
  (v306_11).clone()
}

fn routine_32(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v316_9 = Space::new();
  let mut v316_9_cursor = (*s0).read_zipper();
  for v316_9_byte in v316_9_cursor.child_mask().iter() {
    v316_9_cursor.descend_to_byte(v316_9_byte);
    let v316_9_tail = v316_9_cursor.make_map();
    v316_9_cursor.ascend(1);
    let v316_9_head = Path::from_slice(&[v316_9_byte]);
    let v317_2: Space = singleton(&(v316_9_head));
    let v317_3: Space = intersect(&(*CONSTANT_9),&(v317_2));
    let v317_4: Space = if has_head(&(v317_3)) { singleton(&[]) } else { Space::new() };
    drop(v317_3);
    let v317_5: Space = subtract(&(*CONSTANT_0),&(v317_4));
    drop(v317_4);
    let v317_8: Space = if (v317_5).is_empty() { Space::new() } else {
      let v318_6: Path = concat_path(&(*p0),&(v316_9_head));
      let v318_7: Space = routine_32(c, &(v318_6), &(*p1), &(v316_9_tail));
      compose(&(v317_5),&(v318_7))
    };
    drop(v317_5);
    let v317_9: Space = intersect(&(*CONSTANT_9),&(v317_2));
    drop(v317_2);
    let v317_10: Space = if has_head(&(v317_9)) { singleton(&[]) } else { Space::new() };
    drop(v317_9);
    let v317_12: Space = if (v317_10).is_empty() { Space::new() } else {
      let v319_6: Path = concat_path(&(*p0),&(v316_9_head));
      let mut v319_11 = Space::new();
      let mut v319_11_cursor = (v316_9_tail).read_zipper();
      for v319_11_byte in v319_11_cursor.child_mask().iter() {
        v319_11_cursor.descend_to_byte(v319_11_byte);
        let v319_11_tail = v319_11_cursor.make_map();
        v319_11_cursor.ascend(1);
        let v319_11_head = Path::from_slice(&[v319_11_byte]);
        let v320_2: Space = singleton(&(v319_11_head));
        let v320_3: Space = intersect(&(*CONSTANT_9),&(v320_2));
        let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
        drop(v320_3);
        let v320_5: Space = subtract(&(*CONSTANT_0),&(v320_4));
        drop(v320_4);
        let v320_7: Space = if (v320_5).is_empty() { Space::new() } else {
          let v321_6: Space = routine_58(c, &(v319_11_head), &(*p1), &(v319_6), &(v319_11_tail));
          compose(&(v320_5),&(v321_6))
        };
        drop(v320_5);
        let v320_8: Space = intersect(&(*CONSTANT_9),&(v320_2));
        drop(v320_2);
        let v320_9: Space = if has_head(&(v320_8)) { singleton(&[]) } else { Space::new() };
        drop(v320_8);
        let v320_11: Space = if (v320_9).is_empty() { Space::new() } else {
          let v322_10: Space = routine_59(c, &(v319_11_head), &(*p1), &(v319_6), &(v319_11_tail));
          compose(&(v320_9),&(v322_10))
        };
        drop(v320_9);
        let v320_12: Space = unite(&(v320_7),&(v320_11));
        v319_11.join_into((v320_12).clone());
      }
      drop(v319_11_cursor);
      drop(v319_6);
      compose(&(v317_10),&(v319_11))
    };
    drop(v317_10);
    let v317_13: Space = unite(&(v317_8),&(v317_12));
    v316_9.join_into((v317_13).clone());
  }
  drop(v316_9_cursor);
  (v316_9).clone()
}

fn routine_33(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v323_12 = Space::new();
  let mut v323_12_cursor = (*s0).read_zipper();
  for v323_12_byte in v323_12_cursor.child_mask().iter() {
    v323_12_cursor.descend_to_byte(v323_12_byte);
    let v323_12_tail = v323_12_cursor.make_map();
    v323_12_cursor.ascend(1);
    let v323_12_head = Path::from_slice(&[v323_12_byte]);
    let v324_2: Space = singleton(&(v323_12_head));
    let v324_3: Space = intersect(&(*CONSTANT_9),&(v324_2));
    let v324_4: Space = if has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
    drop(v324_3);
    let v324_5: Space = subtract(&(*CONSTANT_0),&(v324_4));
    drop(v324_4);
    let v324_7: Space = if (v324_5).is_empty() { Space::new() } else {
      let mut v325_6 = Space::new();
      let mut v325_6_cursor = (v323_12_tail).read_zipper();
      for v325_6_byte in v325_6_cursor.child_mask().iter() {
        v325_6_cursor.descend_to_byte(v325_6_byte);
        let v325_6_tail = v325_6_cursor.make_map();
        v325_6_cursor.ascend(1);
        let v325_6_head = Path::from_slice(&[v325_6_byte]);
        let v326_2: Space = singleton(&(v325_6_head));
        let v326_3: Space = intersect(&(*CONSTANT_9),&(v326_2));
        let v326_4: Space = if has_head(&(v326_3)) { singleton(&[]) } else { Space::new() };
        drop(v326_3);
        let v326_5: Space = subtract(&(*CONSTANT_0),&(v326_4));
        drop(v326_4);
        let v326_8: Space = if (v326_5).is_empty() { Space::new() } else {
          let v327_6: Path = concat_path(&(v323_12_head),&(v325_6_head));
          let v327_7: Space = routine_58(c, &(v327_6), &(*p1), &(*p0), &(v325_6_tail));
          compose(&(v326_5),&(v327_7))
        };
        drop(v326_5);
        let v326_9: Space = intersect(&(*CONSTANT_9),&(v326_2));
        drop(v326_2);
        let v326_10: Space = if has_head(&(v326_9)) { singleton(&[]) } else { Space::new() };
        drop(v326_9);
        let v326_12: Space = if (v326_10).is_empty() { Space::new() } else {
          let v328_6: Path = concat_path(&(v323_12_head),&(v325_6_head));
          let v328_11: Space = routine_59(c, &(v328_6), &(*p1), &(*p0), &(v325_6_tail));
          drop(v328_6);
          compose(&(v326_10),&(v328_11))
        };
        drop(v326_10);
        let v326_13: Space = unite(&(v326_8),&(v326_12));
        v325_6.join_into((v326_13).clone());
      }
      drop(v325_6_cursor);
      compose(&(v324_5),&(v325_6))
    };
    drop(v324_5);
    let v324_8: Space = intersect(&(*CONSTANT_9),&(v324_2));
    drop(v324_2);
    let v324_9: Space = if has_head(&(v324_8)) { singleton(&[]) } else { Space::new() };
    drop(v324_8);
    let v324_11: Space = if (v324_9).is_empty() { Space::new() } else {
      let mut v329_10 = Space::new();
      let mut v329_10_cursor = (v323_12_tail).read_zipper();
      for v329_10_byte in v329_10_cursor.child_mask().iter() {
        v329_10_cursor.descend_to_byte(v329_10_byte);
        let v329_10_tail = v329_10_cursor.make_map();
        v329_10_cursor.ascend(1);
        let v329_10_head = Path::from_slice(&[v329_10_byte]);
        let v330_2: Space = singleton(&(v329_10_head));
        let v330_3: Space = intersect(&(*CONSTANT_9),&(v330_2));
        let v330_4: Space = if has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
        drop(v330_3);
        let v330_5: Space = subtract(&(*CONSTANT_0),&(v330_4));
        drop(v330_4);
        let v330_7: Space = if (v330_5).is_empty() { Space::new() } else {
          let v331_6: Space = routine_60(c, &(v329_10_head), &(*p1), &(*p0), &(v323_12_head), &(v329_10_tail));
          compose(&(v330_5),&(v331_6))
        };
        drop(v330_5);
        let v330_8: Space = intersect(&(*CONSTANT_9),&(v330_2));
        drop(v330_2);
        let v330_9: Space = if has_head(&(v330_8)) { singleton(&[]) } else { Space::new() };
        drop(v330_8);
        let v330_11: Space = if (v330_9).is_empty() { Space::new() } else {
          let v332_10: Space = routine_61(c, &(v329_10_head), &(*p1), &(*p0), &(v323_12_head), &(v329_10_tail));
          compose(&(v330_9),&(v332_10))
        };
        drop(v330_9);
        let v330_12: Space = unite(&(v330_7),&(v330_11));
        v329_10.join_into((v330_12).clone());
      }
      drop(v329_10_cursor);
      compose(&(v324_9),&(v329_10))
    };
    drop(v324_9);
    let v324_12: Space = unite(&(v324_7),&(v324_11));
    v323_12.join_into((v324_12).clone());
  }
  drop(v323_12_cursor);
  (v323_12).clone()
}

fn routine_34(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v333_8: Space = unwrap(&(*CONSTANT_21),&(*p1));
  let v333_9: Space = unwrap(&(v333_8),&(*p0));
  drop(v333_8);
  let v333_11: Space = unwrap(&(*CONSTANT_21),&(*p2));
  let v333_12: Space = unwrap(&(v333_11),&(*p0));
  drop(v333_11);
  let mut v333_13 = Space::new();
  let mut v333_13_cursor = (*s0).read_zipper();
  for v333_13_byte in v333_13_cursor.child_mask().iter() {
    v333_13_cursor.descend_to_byte(v333_13_byte);
    let v333_13_tail = v333_13_cursor.make_map();
    v333_13_cursor.ascend(1);
    let v333_13_head = Path::from_slice(&[v333_13_byte]);
    let v334_2: Space = singleton(&(v333_13_head));
    let v334_3: Space = intersect(&(*CONSTANT_9),&(v334_2));
    let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
    drop(v334_3);
    let v334_5: Space = subtract(&(*CONSTANT_0),&(v334_4));
    drop(v334_4);
    let v334_8: Space = if (v334_5).is_empty() { Space::new() } else {
      let v335_6: Path = concat_path(&(*p0),&(v333_13_head));
      let v335_7: Space = routine_34(c, &(v335_6), &(*p1), &(*p2), &(v333_13_tail));
      compose(&(v334_5),&(v335_7))
    };
    drop(v334_5);
    let v334_9: Space = intersect(&(*CONSTANT_9),&(v334_2));
    drop(v334_2);
    let v334_10: Space = if has_head(&(v334_9)) { singleton(&[]) } else { Space::new() };
    drop(v334_9);
    let v334_20: Space = if (v334_10).is_empty() { Space::new() } else {
      let v336_6: Path = concat_path(&(*p0),&(v333_13_head));
      let v336_11: Space = unwrap(&(v333_9),&(v333_13_head));
      let v336_13: Space = if (v336_11).is_empty() { Space::new() } else {
        let v337_12: Space = unwrap(&(v333_12),&(v333_13_head));
        compose(&(v336_11),&(v337_12))
      };
      drop(v336_11);
      let v336_14: Path = concat_path(&(v336_6),&(*p2));
      let v336_15: Space = singleton(&(v336_14));
      drop(v336_14);
      let v336_16: Space = unite(&(v336_13),&(v336_15));
      drop(v336_13);
      drop(v336_15);
      let v336_17: Path = concat_path(&(*p1),&(v336_6));
      drop(v336_6);
      let v336_18: Space = singleton(&(v336_17));
      drop(v336_17);
      let v336_19: Space = unite(&(v336_16),&(v336_18));
      drop(v336_16);
      drop(v336_18);
      compose(&(v334_10),&(v336_19))
    };
    drop(v334_10);
    let v334_21: Space = unite(&(v334_8),&(v334_20));
    drop(v334_20);
    v333_13.join_into((v334_21).clone());
  }
  drop(v333_13_cursor);
  drop(v333_9);
  drop(v333_12);
  (v333_13).clone()
}

fn routine_35(c: &mut Context, p0: &Path, p1: &Path, p2: &Path) -> Space {
  let v338_4: Space = unwrap(&(*CONSTANT_22),&(*p2));
  let v338_7: Space = if (v338_4).is_empty() { Space::new() } else {
    let v339_6: Space = unwrap(&(*CONSTANT_22),&(*p2));
    compose(&(v338_4),&(v339_6))
  };
  drop(v338_4);
  let v338_9: Space = unwrap(&(*CONSTANT_22),&(*p2));
  let v338_14: Space = unwrap(&(*CONSTANT_21),&(*p1));
  let v338_16: Space = unwrap(&(*CONSTANT_21),&(*p0));
  let mut v338_20 = Space::new();
  let mut v338_20_cursor = (v338_9).read_zipper();
  for v338_20_byte in v338_20_cursor.child_mask().iter() {
    v338_20_cursor.descend_to_byte(v338_20_byte);
    let v338_20_tail = v338_20_cursor.make_map();
    v338_20_cursor.ascend(1);
    let v338_20_head = Path::from_slice(&[v338_20_byte]);
    let v340_2: Space = singleton(&(v338_20_head));
    let v340_3: Space = intersect(&(*CONSTANT_9),&(v340_2));
    let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
    drop(v340_3);
    let v340_5: Space = subtract(&(*CONSTANT_0),&(v340_4));
    drop(v340_4);
    let v340_7: Space = if (v340_5).is_empty() { Space::new() } else {
      let mut v341_6 = Space::new();
      let mut v341_6_cursor = (v338_20_tail).read_zipper();
      for v341_6_byte in v341_6_cursor.child_mask().iter() {
        v341_6_cursor.descend_to_byte(v341_6_byte);
        let v341_6_tail = v341_6_cursor.make_map();
        v341_6_cursor.ascend(1);
        let v341_6_head = Path::from_slice(&[v341_6_byte]);
        let v342_2: Space = singleton(&(v341_6_head));
        let v342_3: Space = intersect(&(*CONSTANT_9),&(v342_2));
        let v342_4: Space = if has_head(&(v342_3)) { singleton(&[]) } else { Space::new() };
        drop(v342_3);
        let v342_5: Space = subtract(&(*CONSTANT_0),&(v342_4));
        drop(v342_4);
        let v342_8: Space = if (v342_5).is_empty() { Space::new() } else {
          let v343_6: Path = concat_path(&(v338_20_head),&(v341_6_head));
          let v343_7: Space = routine_34(c, &(v343_6), &(*p1), &(*p0), &(v341_6_tail));
          compose(&(v342_5),&(v343_7))
        };
        drop(v342_5);
        let v342_9: Space = intersect(&(*CONSTANT_9),&(v342_2));
        drop(v342_2);
        let v342_10: Space = if has_head(&(v342_9)) { singleton(&[]) } else { Space::new() };
        drop(v342_9);
        let v342_12: Space = if (v342_10).is_empty() { Space::new() } else {
          let v344_6: Path = concat_path(&(v338_20_head),&(v341_6_head));
          let v344_11: Space = routine_62(c, &(v344_6), &(*p1), &(*p0), &(v341_6_tail));
          drop(v344_6);
          compose(&(v342_10),&(v344_11))
        };
        drop(v342_10);
        let v342_13: Space = unite(&(v342_8),&(v342_12));
        v341_6.join_into((v342_13).clone());
      }
      drop(v341_6_cursor);
      compose(&(v340_5),&(v341_6))
    };
    drop(v340_5);
    let v340_8: Space = intersect(&(*CONSTANT_9),&(v340_2));
    drop(v340_2);
    let v340_9: Space = if has_head(&(v340_8)) { singleton(&[]) } else { Space::new() };
    drop(v340_8);
    let v340_19: Space = if (v340_9).is_empty() { Space::new() } else {
      let v345_10: Space = unwrap(&(v338_14),&(v338_20_head));
      let v345_12: Space = if (v345_10).is_empty() { Space::new() } else {
        let v346_11: Space = unwrap(&(v338_16),&(v338_20_head));
        compose(&(v345_10),&(v346_11))
      };
      drop(v345_10);
      let v345_13: Path = concat_path(&(v338_20_head),&(*p0));
      let v345_14: Space = singleton(&(v345_13));
      drop(v345_13);
      let v345_15: Space = unite(&(v345_12),&(v345_14));
      drop(v345_12);
      drop(v345_14);
      let v345_16: Path = concat_path(&(*p1),&(v338_20_head));
      let v345_17: Space = singleton(&(v345_16));
      drop(v345_16);
      let v345_18: Space = unite(&(v345_15),&(v345_17));
      drop(v345_15);
      drop(v345_17);
      compose(&(v340_9),&(v345_18))
    };
    drop(v340_9);
    let v340_20: Space = unite(&(v340_7),&(v340_19));
    drop(v340_19);
    v338_20.join_into((v340_20).clone());
  }
  drop(v338_20_cursor);
  drop(v338_9);
  drop(v338_14);
  drop(v338_16);
  let v338_21: Space = intersect(&(v338_7),&(v338_20));
  drop(v338_7);
  (v338_21).clone()
}

fn routine_36(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space, s1: &Space) -> Space {
  let v347_10: Path = concat_path(&(*p1),&(*p2));
  let mut v347_11 = Space::new();
  let mut v347_11_cursor = (*s0).read_zipper();
  for v347_11_byte in v347_11_cursor.child_mask().iter() {
    v347_11_cursor.descend_to_byte(v347_11_byte);
    let v347_11_tail = v347_11_cursor.make_map();
    v347_11_cursor.ascend(1);
    let v347_11_head = Path::from_slice(&[v347_11_byte]);
    let v348_2: Space = singleton(&(v347_11_head));
    let v348_3: Space = intersect(&(*CONSTANT_9),&(v348_2));
    let v348_4: Space = if has_head(&(v348_3)) { singleton(&[]) } else { Space::new() };
    drop(v348_3);
    let v348_5: Space = subtract(&(*CONSTANT_0),&(v348_4));
    drop(v348_4);
    let v348_8: Space = if (v348_5).is_empty() { Space::new() } else {
      let v349_6: Path = concat_path(&(*p0),&(v347_11_head));
      let v349_7: Space = routine_36(c, &(v349_6), &(*p1), &(*p2), &(v347_11_tail), &(*s1));
      compose(&(v348_5),&(v349_7))
    };
    drop(v348_5);
    let v348_9: Space = intersect(&(*CONSTANT_9),&(v348_2));
    drop(v348_2);
    let v348_10: Space = if has_head(&(v348_9)) { singleton(&[]) } else { Space::new() };
    drop(v348_9);
    let v348_13: Space = if (v348_10).is_empty() { Space::new() } else {
      let v350_6: Path = concat_path(&(*p0),&(v347_11_head));
      let v350_11: Space = routine_35(c, &(v350_6), &(*CONSTANT_3), &(*CONSTANT_8));
      let v350_12: Space = unite(&(*s1),&(v350_11));
      compose(&(v348_10),&(v350_12))
    };
    drop(v348_10);
    let v348_14: Space = wrap(&(v348_13),&(v347_10));
    let v351_6: Path = concat_path(&(*p0),&(v347_11_head));
    let v348_15: Space = wrap(&(v348_14),&(v351_6));
    let v348_16: Space = unite(&(v348_8),&(v348_15));
    v347_11.join_into((v348_16).clone());
  }
  drop(v347_11_cursor);
  drop(v347_10);
  (v347_11).clone()
}

fn routine_37(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space, s1: &Space) -> Space {
  let v352_38: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v353_9: Space = routine_34(c, &(*CONSTANT_11), &(*CONSTANT_3), &(*p0), &(*CONSTANT_9));
    let v353_12: Space = routine_34(c, &(*CONSTANT_12), &(*CONSTANT_3), &(*p0), &(*CONSTANT_9));
    let v353_13: Space = unite(&(v353_9),&(v353_12));
    let v353_16: Space = routine_34(c, &(*CONSTANT_13), &(*CONSTANT_3), &(*p0), &(*CONSTANT_9));
    let v353_17: Space = unite(&(v353_13),&(v353_16));
    let v353_20: Space = routine_34(c, &(*CONSTANT_14), &(*CONSTANT_3), &(*p0), &(*CONSTANT_9));
    let v353_21: Space = unite(&(v353_17),&(v353_20));
    let v353_24: Space = routine_34(c, &(*CONSTANT_15), &(*CONSTANT_3), &(*p0), &(*CONSTANT_9));
    let v353_25: Space = unite(&(v353_21),&(v353_24));
    let v353_28: Space = routine_34(c, &(*CONSTANT_16), &(*CONSTANT_3), &(*p0), &(*CONSTANT_9));
    let v353_29: Space = unite(&(v353_25),&(v353_28));
    let v353_32: Space = routine_34(c, &(*CONSTANT_17), &(*CONSTANT_3), &(*p0), &(*CONSTANT_9));
    let v353_33: Space = unite(&(v353_29),&(v353_32));
    let v353_36: Space = routine_34(c, &(*CONSTANT_18), &(*CONSTANT_3), &(*p0), &(*CONSTANT_9));
    let v353_37: Space = unite(&(v353_33),&(v353_36));
    compose(&(*CONSTANT_0),&(v353_37))
  };
  let v352_40: Space = intersect(&(v352_38),&(*CONSTANT_19));
  let v352_41: Space = unite(&(v352_40),&(*s1));
  let v352_42: Path = concat_path(&(*p1),&(*p2));
  let v352_43: Space = wrap(&(v352_41),&(v352_42));
  drop(v352_42);
  let v352_44: Space = wrap(&(v352_43),&(*p0));
  (v352_44).clone()
}

fn routine_38(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v354_12 = Space::new();
  let mut v354_12_cursor = (*s0).read_zipper();
  for v354_12_byte in v354_12_cursor.child_mask().iter() {
    v354_12_cursor.descend_to_byte(v354_12_byte);
    let v354_12_tail = v354_12_cursor.make_map();
    v354_12_cursor.ascend(1);
    let v354_12_head = Path::from_slice(&[v354_12_byte]);
    let v355_2: Space = singleton(&(v354_12_head));
    let v355_3: Space = intersect(&(*CONSTANT_9),&(v355_2));
    let v355_4: Space = if has_head(&(v355_3)) { singleton(&[]) } else { Space::new() };
    drop(v355_3);
    let v355_5: Space = subtract(&(*CONSTANT_0),&(v355_4));
    drop(v355_4);
    let v355_8: Space = if (v355_5).is_empty() { Space::new() } else {
      let v356_6: Path = concat_path(&(*p0),&(v354_12_head));
      let v356_7: Space = routine_38(c, &(v356_6), &(*p1), &(*p2), &(v354_12_tail));
      compose(&(v355_5),&(v356_7))
    };
    drop(v355_5);
    let v355_9: Space = intersect(&(*CONSTANT_9),&(v355_2));
    drop(v355_2);
    let v355_10: Space = if has_head(&(v355_9)) { singleton(&[]) } else { Space::new() };
    drop(v355_9);
    let v355_14: Space = if (v355_10).is_empty() { Space::new() } else {
      let v357_6: Path = concat_path(&(*p0),&(v354_12_head));
      let v357_11: Space = unwrap(&(v354_12_tail),&(*CONSTANT_4));
      let v357_12: Space = subtract(&(*CONSTANT_10),&(v357_11));
      drop(v357_11);
      let mut v357_13 = Space::new();
      let mut v357_13_cursor = (v357_12).read_zipper();
      for v357_13_byte in v357_13_cursor.child_mask().iter() {
        v357_13_cursor.descend_to_byte(v357_13_byte);
        let v357_13_tail = v357_13_cursor.make_map();
        v357_13_cursor.ascend(1);
        let v357_13_head = Path::from_slice(&[v357_13_byte]);
        let v358_2: Space = singleton(&(v357_13_head));
        let v358_3: Space = intersect(&(*CONSTANT_9),&(v358_2));
        let v358_4: Space = if has_head(&(v358_3)) { singleton(&[]) } else { Space::new() };
        drop(v358_3);
        let v358_5: Space = subtract(&(*CONSTANT_0),&(v358_4));
        drop(v358_4);
        let v358_7: Space = if (v358_5).is_empty() { Space::new() } else {
          let v359_6: Space = routine_40(c, &(v357_13_head), &(*p1), &(*p2), &(v357_6), &(v357_13_tail), &(v354_12_tail));
          compose(&(v358_5),&(v359_6))
        };
        drop(v358_5);
        let v358_8: Space = intersect(&(*CONSTANT_9),&(v358_2));
        drop(v358_2);
        let v358_9: Space = if has_head(&(v358_8)) { singleton(&[]) } else { Space::new() };
        drop(v358_8);
        let v358_11: Space = if (v358_9).is_empty() { Space::new() } else {
          let v360_10: Space = routine_41(c, &(v357_13_head), &(*p1), &(*p2), &(v357_6), &(v357_13_tail), &(v354_12_tail));
          compose(&(v358_9),&(v360_10))
        };
        drop(v358_9);
        let v358_12: Space = unite(&(v358_7),&(v358_11));
        v357_13.join_into((v358_12).clone());
      }
      drop(v357_13_cursor);
      drop(v357_6);
      drop(v357_12);
      compose(&(v355_10),&(v357_13))
    };
    drop(v355_10);
    let v355_15: Space = unite(&(v355_8),&(v355_14));
    v354_12.join_into((v355_15).clone());
  }
  drop(v354_12_cursor);
  (v354_12).clone()
}

fn routine_39(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v361_6: Space = unwrap(&(*s0),&(*CONSTANT_4));
  let v361_7: Space = subtract(&(*CONSTANT_10),&(v361_6));
  drop(v361_6);
  let v361_12: Path = concat_path(&(*p1),&(*p2));
  let v361_13: Path = concat_path(&(v361_12),&(*p0));
  drop(v361_12);
  let mut v361_17 = Space::new();
  let mut v361_17_cursor = (v361_7).read_zipper();
  for v361_17_byte in v361_17_cursor.child_mask().iter() {
    v361_17_cursor.descend_to_byte(v361_17_byte);
    let v361_17_tail = v361_17_cursor.make_map();
    v361_17_cursor.ascend(1);
    let v361_17_head = Path::from_slice(&[v361_17_byte]);
    let v362_2: Space = singleton(&(v361_17_head));
    let v362_3: Space = intersect(&(*CONSTANT_9),&(v362_2));
    let v362_4: Space = if has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
    drop(v362_3);
    let v362_5: Space = subtract(&(*CONSTANT_0),&(v362_4));
    drop(v362_4);
    let v362_7: Space = if (v362_5).is_empty() { Space::new() } else {
      let mut v363_6 = Space::new();
      let mut v363_6_cursor = (v361_17_tail).read_zipper();
      for v363_6_byte in v363_6_cursor.child_mask().iter() {
        v363_6_cursor.descend_to_byte(v363_6_byte);
        let v363_6_tail = v363_6_cursor.make_map();
        v363_6_cursor.ascend(1);
        let v363_6_head = Path::from_slice(&[v363_6_byte]);
        let v364_2: Space = singleton(&(v363_6_head));
        let v364_3: Space = intersect(&(*CONSTANT_9),&(v364_2));
        let v364_4: Space = if has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
        drop(v364_3);
        let v364_5: Space = subtract(&(*CONSTANT_0),&(v364_4));
        drop(v364_4);
        let v364_8: Space = if (v364_5).is_empty() { Space::new() } else {
          let v365_6: Path = concat_path(&(v361_17_head),&(v363_6_head));
          let v365_7: Space = routine_40(c, &(v365_6), &(*p1), &(*p2), &(*p0), &(v363_6_tail), &(*s0));
          compose(&(v364_5),&(v365_7))
        };
        drop(v364_5);
        let v364_9: Space = intersect(&(*CONSTANT_9),&(v364_2));
        drop(v364_2);
        let v364_10: Space = if has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
        drop(v364_9);
        let v364_12: Space = if (v364_10).is_empty() { Space::new() } else {
          let v366_6: Path = concat_path(&(v361_17_head),&(v363_6_head));
          let v366_11: Space = routine_41(c, &(v366_6), &(*p1), &(*p2), &(*p0), &(v363_6_tail), &(*s0));
          drop(v366_6);
          compose(&(v364_10),&(v366_11))
        };
        drop(v364_10);
        let v364_13: Space = unite(&(v364_8),&(v364_12));
        v363_6.join_into((v364_13).clone());
      }
      drop(v363_6_cursor);
      compose(&(v362_5),&(v363_6))
    };
    drop(v362_5);
    let v362_8: Space = intersect(&(*CONSTANT_9),&(v362_2));
    drop(v362_2);
    let v362_9: Space = if has_head(&(v362_8)) { singleton(&[]) } else { Space::new() };
    drop(v362_8);
    let v362_12: Space = if (v362_9).is_empty() { Space::new() } else {
      let v367_10: Space = routine_35(c, &(v361_17_head), &(*CONSTANT_4), &(*CONSTANT_8));
      let v367_11: Space = unite(&(*s0),&(v367_10));
      compose(&(v362_9),&(v367_11))
    };
    drop(v362_9);
    let v362_13: Space = wrap(&(v362_12),&(v361_13));
    let v362_14: Space = wrap(&(v362_13),&(v361_17_head));
    let v362_15: Space = unite(&(v362_7),&(v362_14));
    v361_17.join_into((v362_15).clone());
  }
  drop(v361_17_cursor);
  drop(v361_7);
  drop(v361_13);
  (v361_17).clone()
}

fn routine_40(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space, s1: &Space) -> Space {
  let v368_11: Path = concat_path(&(*p1),&(*p2));
  let v368_12: Path = concat_path(&(v368_11),&(*p3));
  drop(v368_11);
  let mut v368_13 = Space::new();
  let mut v368_13_cursor = (*s0).read_zipper();
  for v368_13_byte in v368_13_cursor.child_mask().iter() {
    v368_13_cursor.descend_to_byte(v368_13_byte);
    let v368_13_tail = v368_13_cursor.make_map();
    v368_13_cursor.ascend(1);
    let v368_13_head = Path::from_slice(&[v368_13_byte]);
    let v369_2: Space = singleton(&(v368_13_head));
    let v369_3: Space = intersect(&(*CONSTANT_9),&(v369_2));
    let v369_4: Space = if has_head(&(v369_3)) { singleton(&[]) } else { Space::new() };
    drop(v369_3);
    let v369_5: Space = subtract(&(*CONSTANT_0),&(v369_4));
    drop(v369_4);
    let v369_8: Space = if (v369_5).is_empty() { Space::new() } else {
      let v370_6: Path = concat_path(&(*p0),&(v368_13_head));
      let v370_7: Space = routine_40(c, &(v370_6), &(*p1), &(*p2), &(*p3), &(v368_13_tail), &(*s1));
      compose(&(v369_5),&(v370_7))
    };
    drop(v369_5);
    let v369_9: Space = intersect(&(*CONSTANT_9),&(v369_2));
    drop(v369_2);
    let v369_10: Space = if has_head(&(v369_9)) { singleton(&[]) } else { Space::new() };
    drop(v369_9);
    let v369_13: Space = if (v369_10).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&(v368_13_head));
      let v371_11: Space = routine_35(c, &(v371_6), &(*CONSTANT_4), &(*CONSTANT_8));
      let v371_12: Space = unite(&(*s1),&(v371_11));
      compose(&(v369_10),&(v371_12))
    };
    drop(v369_10);
    let v369_14: Space = wrap(&(v369_13),&(v368_12));
    let v372_6: Path = concat_path(&(*p0),&(v368_13_head));
    let v369_15: Space = wrap(&(v369_14),&(v372_6));
    let v369_16: Space = unite(&(v369_8),&(v369_15));
    v368_13.join_into((v369_16).clone());
  }
  drop(v368_13_cursor);
  drop(v368_12);
  (v368_13).clone()
}

fn routine_41(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space, s1: &Space) -> Space {
  let v373_39: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v374_10: Space = routine_34(c, &(*CONSTANT_11), &(*CONSTANT_4), &(*p0), &(*CONSTANT_9));
    let v374_13: Space = routine_34(c, &(*CONSTANT_12), &(*CONSTANT_4), &(*p0), &(*CONSTANT_9));
    let v374_14: Space = unite(&(v374_10),&(v374_13));
    let v374_17: Space = routine_34(c, &(*CONSTANT_13), &(*CONSTANT_4), &(*p0), &(*CONSTANT_9));
    let v374_18: Space = unite(&(v374_14),&(v374_17));
    let v374_21: Space = routine_34(c, &(*CONSTANT_14), &(*CONSTANT_4), &(*p0), &(*CONSTANT_9));
    let v374_22: Space = unite(&(v374_18),&(v374_21));
    let v374_25: Space = routine_34(c, &(*CONSTANT_15), &(*CONSTANT_4), &(*p0), &(*CONSTANT_9));
    let v374_26: Space = unite(&(v374_22),&(v374_25));
    let v374_29: Space = routine_34(c, &(*CONSTANT_16), &(*CONSTANT_4), &(*p0), &(*CONSTANT_9));
    let v374_30: Space = unite(&(v374_26),&(v374_29));
    let v374_33: Space = routine_34(c, &(*CONSTANT_17), &(*CONSTANT_4), &(*p0), &(*CONSTANT_9));
    let v374_34: Space = unite(&(v374_30),&(v374_33));
    let v374_37: Space = routine_34(c, &(*CONSTANT_18), &(*CONSTANT_4), &(*p0), &(*CONSTANT_9));
    let v374_38: Space = unite(&(v374_34),&(v374_37));
    compose(&(*CONSTANT_0),&(v374_38))
  };
  let v373_41: Space = intersect(&(v373_39),&(*CONSTANT_19));
  let v373_42: Space = unite(&(v373_41),&(*s1));
  let v373_43: Path = concat_path(&(*p1),&(*p2));
  let v373_44: Path = concat_path(&(v373_43),&(*p3));
  drop(v373_43);
  let v373_45: Space = wrap(&(v373_42),&(v373_44));
  drop(v373_44);
  let v373_46: Space = wrap(&(v373_45),&(*p0));
  (v373_46).clone()
}

fn routine_42(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v375_10 = Space::new();
  let mut v375_10_cursor = (*s0).read_zipper();
  for v375_10_byte in v375_10_cursor.child_mask().iter() {
    v375_10_cursor.descend_to_byte(v375_10_byte);
    let v375_10_tail = v375_10_cursor.make_map();
    v375_10_cursor.ascend(1);
    let v375_10_head = Path::from_slice(&[v375_10_byte]);
    let v376_2: Space = singleton(&(v375_10_head));
    let v376_3: Space = intersect(&(*CONSTANT_9),&(v376_2));
    let v376_4: Space = if has_head(&(v376_3)) { singleton(&[]) } else { Space::new() };
    drop(v376_3);
    let v376_5: Space = subtract(&(*CONSTANT_0),&(v376_4));
    drop(v376_4);
    let v376_8: Space = if (v376_5).is_empty() { Space::new() } else {
      let v377_6: Path = concat_path(&(*p0),&(v375_10_head));
      let v377_7: Space = routine_42(c, &(v377_6), &(*p1), &(*p2), &(v375_10_tail));
      compose(&(v376_5),&(v377_7))
    };
    drop(v376_5);
    let v376_9: Space = intersect(&(*CONSTANT_9),&(v376_2));
    drop(v376_2);
    let v376_10: Space = if has_head(&(v376_9)) { singleton(&[]) } else { Space::new() };
    drop(v376_9);
    let v376_12: Space = if (v376_10).is_empty() { Space::new() } else {
      let v378_6: Path = concat_path(&(*p0),&(v375_10_head));
      let mut v378_11 = Space::new();
      let mut v378_11_cursor = (v375_10_tail).read_zipper();
      for v378_11_byte in v378_11_cursor.child_mask().iter() {
        v378_11_cursor.descend_to_byte(v378_11_byte);
        let v378_11_tail = v378_11_cursor.make_map();
        v378_11_cursor.ascend(1);
        let v378_11_head = Path::from_slice(&[v378_11_byte]);
        let v379_2: Space = singleton(&(v378_11_head));
        let v379_3: Space = intersect(&(*CONSTANT_9),&(v379_2));
        let v379_4: Space = if has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
        drop(v379_3);
        let v379_5: Space = subtract(&(*CONSTANT_0),&(v379_4));
        drop(v379_4);
        let v379_7: Space = if (v379_5).is_empty() { Space::new() } else {
          let v380_6: Space = routine_44(c, &(v378_11_head), &(*p1), &(v378_6), &(*p2), &(v378_11_tail));
          compose(&(v379_5),&(v380_6))
        };
        drop(v379_5);
        let v379_8: Space = intersect(&(*CONSTANT_9),&(v379_2));
        drop(v379_2);
        let v379_9: Space = if has_head(&(v379_8)) { singleton(&[]) } else { Space::new() };
        drop(v379_8);
        let v379_11: Space = if (v379_9).is_empty() { Space::new() } else {
          let v381_10: Space = routine_45(c, &(v378_11_head), &(*p1), &(v378_6), &(*p2), &(v378_11_tail));
          compose(&(v379_9),&(v381_10))
        };
        drop(v379_9);
        let v379_12: Space = unite(&(v379_7),&(v379_11));
        v378_11.join_into((v379_12).clone());
      }
      drop(v378_11_cursor);
      drop(v378_6);
      compose(&(v376_10),&(v378_11))
    };
    drop(v376_10);
    let v376_13: Space = unite(&(v376_8),&(v376_12));
    v375_10.join_into((v376_13).clone());
  }
  drop(v375_10_cursor);
  (v375_10).clone()
}

fn routine_43(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v382_15 = Space::new();
  let mut v382_15_cursor = (*s0).read_zipper();
  for v382_15_byte in v382_15_cursor.child_mask().iter() {
    v382_15_cursor.descend_to_byte(v382_15_byte);
    let v382_15_tail = v382_15_cursor.make_map();
    v382_15_cursor.ascend(1);
    let v382_15_head = Path::from_slice(&[v382_15_byte]);
    let v383_2: Space = singleton(&(v382_15_head));
    let v383_3: Space = intersect(&(*CONSTANT_9),&(v383_2));
    let v383_4: Space = if has_head(&(v383_3)) { singleton(&[]) } else { Space::new() };
    drop(v383_3);
    let v383_5: Space = subtract(&(*CONSTANT_0),&(v383_4));
    drop(v383_4);
    let v383_7: Space = if (v383_5).is_empty() { Space::new() } else {
      let mut v384_6 = Space::new();
      let mut v384_6_cursor = (v382_15_tail).read_zipper();
      for v384_6_byte in v384_6_cursor.child_mask().iter() {
        v384_6_cursor.descend_to_byte(v384_6_byte);
        let v384_6_tail = v384_6_cursor.make_map();
        v384_6_cursor.ascend(1);
        let v384_6_head = Path::from_slice(&[v384_6_byte]);
        let v385_2: Space = singleton(&(v384_6_head));
        let v385_3: Space = intersect(&(*CONSTANT_9),&(v385_2));
        let v385_4: Space = if has_head(&(v385_3)) { singleton(&[]) } else { Space::new() };
        drop(v385_3);
        let v385_5: Space = subtract(&(*CONSTANT_0),&(v385_4));
        drop(v385_4);
        let v385_8: Space = if (v385_5).is_empty() { Space::new() } else {
          let v386_6: Path = concat_path(&(v382_15_head),&(v384_6_head));
          let v386_7: Space = routine_44(c, &(v386_6), &(*p1), &(*p0), &(*p2), &(v384_6_tail));
          compose(&(v385_5),&(v386_7))
        };
        drop(v385_5);
        let v385_9: Space = intersect(&(*CONSTANT_9),&(v385_2));
        drop(v385_2);
        let v385_10: Space = if has_head(&(v385_9)) { singleton(&[]) } else { Space::new() };
        drop(v385_9);
        let v385_12: Space = if (v385_10).is_empty() { Space::new() } else {
          let v387_6: Path = concat_path(&(v382_15_head),&(v384_6_head));
          let v387_11: Space = routine_45(c, &(v387_6), &(*p1), &(*p0), &(*p2), &(v384_6_tail));
          drop(v387_6);
          compose(&(v385_10),&(v387_11))
        };
        drop(v385_10);
        let v385_13: Space = unite(&(v385_8),&(v385_12));
        v384_6.join_into((v385_13).clone());
      }
      drop(v384_6_cursor);
      compose(&(v383_5),&(v384_6))
    };
    drop(v383_5);
    let v383_8: Space = intersect(&(*CONSTANT_9),&(v383_2));
    drop(v383_2);
    let v383_9: Space = if has_head(&(v383_8)) { singleton(&[]) } else { Space::new() };
    drop(v383_8);
    let v383_13: Space = if (v383_9).is_empty() { Space::new() } else {
      let v388_10: Space = unwrap(&(v382_15_tail),&(*CONSTANT_5));
      let v388_11: Space = subtract(&(*CONSTANT_10),&(v388_10));
      drop(v388_10);
      let mut v388_12 = Space::new();
      let mut v388_12_cursor = (v388_11).read_zipper();
      for v388_12_byte in v388_12_cursor.child_mask().iter() {
        v388_12_cursor.descend_to_byte(v388_12_byte);
        let v388_12_tail = v388_12_cursor.make_map();
        v388_12_cursor.ascend(1);
        let v388_12_head = Path::from_slice(&[v388_12_byte]);
        let v389_2: Space = singleton(&(v388_12_head));
        let v389_3: Space = intersect(&(*CONSTANT_9),&(v389_2));
        let v389_4: Space = if has_head(&(v389_3)) { singleton(&[]) } else { Space::new() };
        drop(v389_3);
        let v389_5: Space = subtract(&(*CONSTANT_0),&(v389_4));
        drop(v389_4);
        let v389_7: Space = if (v389_5).is_empty() { Space::new() } else {
          let v390_6: Space = routine_63(c, &(v388_12_head), &(*p1), &(*p0), &(v382_15_head), &(*p2), &(v388_12_tail), &(v382_15_tail));
          compose(&(v389_5),&(v390_6))
        };
        drop(v389_5);
        let v389_8: Space = intersect(&(*CONSTANT_9),&(v389_2));
        drop(v389_2);
        let v389_9: Space = if has_head(&(v389_8)) { singleton(&[]) } else { Space::new() };
        drop(v389_8);
        let v389_11: Space = if (v389_9).is_empty() { Space::new() } else {
          let v391_10: Space = routine_64(c, &(v388_12_head), &(*p1), &(*p0), &(v382_15_head), &(*p2), &(v388_12_tail), &(v382_15_tail));
          compose(&(v389_9),&(v391_10))
        };
        drop(v389_9);
        let v389_12: Space = unite(&(v389_7),&(v389_11));
        v388_12.join_into((v389_12).clone());
      }
      drop(v388_12_cursor);
      drop(v388_11);
      compose(&(v383_9),&(v388_12))
    };
    drop(v383_9);
    let v383_14: Space = unite(&(v383_7),&(v383_13));
    v382_15.join_into((v383_14).clone());
  }
  drop(v382_15_cursor);
  (v382_15).clone()
}

fn routine_44(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v392_13 = Space::new();
  let mut v392_13_cursor = (*s0).read_zipper();
  for v392_13_byte in v392_13_cursor.child_mask().iter() {
    v392_13_cursor.descend_to_byte(v392_13_byte);
    let v392_13_tail = v392_13_cursor.make_map();
    v392_13_cursor.ascend(1);
    let v392_13_head = Path::from_slice(&[v392_13_byte]);
    let v393_2: Space = singleton(&(v392_13_head));
    let v393_3: Space = intersect(&(*CONSTANT_9),&(v393_2));
    let v393_4: Space = if has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
    drop(v393_3);
    let v393_5: Space = subtract(&(*CONSTANT_0),&(v393_4));
    drop(v393_4);
    let v393_8: Space = if (v393_5).is_empty() { Space::new() } else {
      let v394_6: Path = concat_path(&(*p0),&(v392_13_head));
      let v394_7: Space = routine_44(c, &(v394_6), &(*p1), &(*p2), &(*p3), &(v392_13_tail));
      compose(&(v393_5),&(v394_7))
    };
    drop(v393_5);
    let v393_9: Space = intersect(&(*CONSTANT_9),&(v393_2));
    drop(v393_2);
    let v393_10: Space = if has_head(&(v393_9)) { singleton(&[]) } else { Space::new() };
    drop(v393_9);
    let v393_14: Space = if (v393_10).is_empty() { Space::new() } else {
      let v395_6: Path = concat_path(&(*p0),&(v392_13_head));
      let v395_11: Space = unwrap(&(v392_13_tail),&(*CONSTANT_5));
      let v395_12: Space = subtract(&(*CONSTANT_10),&(v395_11));
      drop(v395_11);
      let mut v395_13 = Space::new();
      let mut v395_13_cursor = (v395_12).read_zipper();
      for v395_13_byte in v395_13_cursor.child_mask().iter() {
        v395_13_cursor.descend_to_byte(v395_13_byte);
        let v395_13_tail = v395_13_cursor.make_map();
        v395_13_cursor.ascend(1);
        let v395_13_head = Path::from_slice(&[v395_13_byte]);
        let v396_2: Space = singleton(&(v395_13_head));
        let v396_3: Space = intersect(&(*CONSTANT_9),&(v396_2));
        let v396_4: Space = if has_head(&(v396_3)) { singleton(&[]) } else { Space::new() };
        drop(v396_3);
        let v396_5: Space = subtract(&(*CONSTANT_0),&(v396_4));
        drop(v396_4);
        let v396_7: Space = if (v396_5).is_empty() { Space::new() } else {
          let v397_6: Space = routine_63(c, &(v395_13_head), &(*p1), &(*p2), &(v395_6), &(*p3), &(v395_13_tail), &(v392_13_tail));
          compose(&(v396_5),&(v397_6))
        };
        drop(v396_5);
        let v396_8: Space = intersect(&(*CONSTANT_9),&(v396_2));
        drop(v396_2);
        let v396_9: Space = if has_head(&(v396_8)) { singleton(&[]) } else { Space::new() };
        drop(v396_8);
        let v396_11: Space = if (v396_9).is_empty() { Space::new() } else {
          let v398_10: Space = routine_64(c, &(v395_13_head), &(*p1), &(*p2), &(v395_6), &(*p3), &(v395_13_tail), &(v392_13_tail));
          compose(&(v396_9),&(v398_10))
        };
        drop(v396_9);
        let v396_12: Space = unite(&(v396_7),&(v396_11));
        v395_13.join_into((v396_12).clone());
      }
      drop(v395_13_cursor);
      drop(v395_6);
      drop(v395_12);
      compose(&(v393_10),&(v395_13))
    };
    drop(v393_10);
    let v393_15: Space = unite(&(v393_8),&(v393_14));
    v392_13.join_into((v393_15).clone());
  }
  drop(v392_13_cursor);
  (v392_13).clone()
}

fn routine_45(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let v399_7: Space = unwrap(&(*s0),&(*CONSTANT_5));
  let v399_8: Space = subtract(&(*CONSTANT_10),&(v399_7));
  drop(v399_7);
  let v399_13: Path = concat_path(&(*p3),&(*p1));
  let v399_14: Path = concat_path(&(v399_13),&(*p2));
  drop(v399_13);
  let v399_15: Path = concat_path(&(v399_14),&(*p0));
  drop(v399_14);
  let mut v399_19 = Space::new();
  let mut v399_19_cursor = (v399_8).read_zipper();
  for v399_19_byte in v399_19_cursor.child_mask().iter() {
    v399_19_cursor.descend_to_byte(v399_19_byte);
    let v399_19_tail = v399_19_cursor.make_map();
    v399_19_cursor.ascend(1);
    let v399_19_head = Path::from_slice(&[v399_19_byte]);
    let v400_2: Space = singleton(&(v399_19_head));
    let v400_3: Space = intersect(&(*CONSTANT_9),&(v400_2));
    let v400_4: Space = if has_head(&(v400_3)) { singleton(&[]) } else { Space::new() };
    drop(v400_3);
    let v400_5: Space = subtract(&(*CONSTANT_0),&(v400_4));
    drop(v400_4);
    let v400_7: Space = if (v400_5).is_empty() { Space::new() } else {
      let mut v401_6 = Space::new();
      let mut v401_6_cursor = (v399_19_tail).read_zipper();
      for v401_6_byte in v401_6_cursor.child_mask().iter() {
        v401_6_cursor.descend_to_byte(v401_6_byte);
        let v401_6_tail = v401_6_cursor.make_map();
        v401_6_cursor.ascend(1);
        let v401_6_head = Path::from_slice(&[v401_6_byte]);
        let v402_2: Space = singleton(&(v401_6_head));
        let v402_3: Space = intersect(&(*CONSTANT_9),&(v402_2));
        let v402_4: Space = if has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
        drop(v402_3);
        let v402_5: Space = subtract(&(*CONSTANT_0),&(v402_4));
        drop(v402_4);
        let v402_8: Space = if (v402_5).is_empty() { Space::new() } else {
          let v403_6: Path = concat_path(&(v399_19_head),&(v401_6_head));
          let v403_7: Space = routine_63(c, &(v403_6), &(*p1), &(*p2), &(*p0), &(*p3), &(v401_6_tail), &(*s0));
          compose(&(v402_5),&(v403_7))
        };
        drop(v402_5);
        let v402_9: Space = intersect(&(*CONSTANT_9),&(v402_2));
        drop(v402_2);
        let v402_10: Space = if has_head(&(v402_9)) { singleton(&[]) } else { Space::new() };
        drop(v402_9);
        let v402_12: Space = if (v402_10).is_empty() { Space::new() } else {
          let v404_6: Path = concat_path(&(v399_19_head),&(v401_6_head));
          let v404_11: Space = routine_64(c, &(v404_6), &(*p1), &(*p2), &(*p0), &(*p3), &(v401_6_tail), &(*s0));
          drop(v404_6);
          compose(&(v402_10),&(v404_11))
        };
        drop(v402_10);
        let v402_13: Space = unite(&(v402_8),&(v402_12));
        v401_6.join_into((v402_13).clone());
      }
      drop(v401_6_cursor);
      compose(&(v400_5),&(v401_6))
    };
    drop(v400_5);
    let v400_8: Space = intersect(&(*CONSTANT_9),&(v400_2));
    drop(v400_2);
    let v400_9: Space = if has_head(&(v400_8)) { singleton(&[]) } else { Space::new() };
    drop(v400_8);
    let v400_12: Space = if (v400_9).is_empty() { Space::new() } else {
      let v405_10: Space = routine_35(c, &(v399_19_head), &(*CONSTANT_5), &(*CONSTANT_8));
      let v405_11: Space = unite(&(*s0),&(v405_10));
      compose(&(v400_9),&(v405_11))
    };
    drop(v400_9);
    let v400_13: Space = wrap(&(v400_12),&(v399_15));
    let v400_14: Space = wrap(&(v400_13),&(v399_19_head));
    let v400_15: Space = unite(&(v400_7),&(v400_14));
    v399_19.join_into((v400_15).clone());
  }
  drop(v399_19_cursor);
  drop(v399_8);
  drop(v399_15);
  (v399_19).clone()
}

fn routine_46(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v406_10 = Space::new();
  let mut v406_10_cursor = (*s0).read_zipper();
  for v406_10_byte in v406_10_cursor.child_mask().iter() {
    v406_10_cursor.descend_to_byte(v406_10_byte);
    let v406_10_tail = v406_10_cursor.make_map();
    v406_10_cursor.ascend(1);
    let v406_10_head = Path::from_slice(&[v406_10_byte]);
    let v407_2: Space = singleton(&(v406_10_head));
    let v407_3: Space = intersect(&(*CONSTANT_9),&(v407_2));
    let v407_4: Space = if has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
    drop(v407_3);
    let v407_5: Space = subtract(&(*CONSTANT_0),&(v407_4));
    drop(v407_4);
    let v407_8: Space = if (v407_5).is_empty() { Space::new() } else {
      let v408_6: Path = concat_path(&(*p0),&(v406_10_head));
      let v408_7: Space = routine_46(c, &(v408_6), &(*p1), &(*p2), &(v406_10_tail));
      compose(&(v407_5),&(v408_7))
    };
    drop(v407_5);
    let v407_9: Space = intersect(&(*CONSTANT_9),&(v407_2));
    drop(v407_2);
    let v407_10: Space = if has_head(&(v407_9)) { singleton(&[]) } else { Space::new() };
    drop(v407_9);
    let v407_12: Space = if (v407_10).is_empty() { Space::new() } else {
      let v409_6: Path = concat_path(&(*p0),&(v406_10_head));
      let mut v409_11 = Space::new();
      let mut v409_11_cursor = (v406_10_tail).read_zipper();
      for v409_11_byte in v409_11_cursor.child_mask().iter() {
        v409_11_cursor.descend_to_byte(v409_11_byte);
        let v409_11_tail = v409_11_cursor.make_map();
        v409_11_cursor.ascend(1);
        let v409_11_head = Path::from_slice(&[v409_11_byte]);
        let v410_2: Space = singleton(&(v409_11_head));
        let v410_3: Space = intersect(&(*CONSTANT_9),&(v410_2));
        let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
        drop(v410_3);
        let v410_5: Space = subtract(&(*CONSTANT_0),&(v410_4));
        drop(v410_4);
        let v410_7: Space = if (v410_5).is_empty() { Space::new() } else {
          let v411_6: Space = routine_48(c, &(v409_11_head), &(*p1), &(*p2), &(v409_6), &(v409_11_tail));
          compose(&(v410_5),&(v411_6))
        };
        drop(v410_5);
        let v410_8: Space = intersect(&(*CONSTANT_9),&(v410_2));
        drop(v410_2);
        let v410_9: Space = if has_head(&(v410_8)) { singleton(&[]) } else { Space::new() };
        drop(v410_8);
        let v410_11: Space = if (v410_9).is_empty() { Space::new() } else {
          let v412_10: Space = routine_49(c, &(v409_11_head), &(*p1), &(*p2), &(v409_6), &(v409_11_tail));
          compose(&(v410_9),&(v412_10))
        };
        drop(v410_9);
        let v410_12: Space = unite(&(v410_7),&(v410_11));
        v409_11.join_into((v410_12).clone());
      }
      drop(v409_11_cursor);
      drop(v409_6);
      compose(&(v407_10),&(v409_11))
    };
    drop(v407_10);
    let v407_13: Space = unite(&(v407_8),&(v407_12));
    v406_10.join_into((v407_13).clone());
  }
  drop(v406_10_cursor);
  (v406_10).clone()
}

fn routine_47(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v413_13 = Space::new();
  let mut v413_13_cursor = (*s0).read_zipper();
  for v413_13_byte in v413_13_cursor.child_mask().iter() {
    v413_13_cursor.descend_to_byte(v413_13_byte);
    let v413_13_tail = v413_13_cursor.make_map();
    v413_13_cursor.ascend(1);
    let v413_13_head = Path::from_slice(&[v413_13_byte]);
    let v414_2: Space = singleton(&(v413_13_head));
    let v414_3: Space = intersect(&(*CONSTANT_9),&(v414_2));
    let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
    drop(v414_3);
    let v414_5: Space = subtract(&(*CONSTANT_0),&(v414_4));
    drop(v414_4);
    let v414_7: Space = if (v414_5).is_empty() { Space::new() } else {
      let mut v415_6 = Space::new();
      let mut v415_6_cursor = (v413_13_tail).read_zipper();
      for v415_6_byte in v415_6_cursor.child_mask().iter() {
        v415_6_cursor.descend_to_byte(v415_6_byte);
        let v415_6_tail = v415_6_cursor.make_map();
        v415_6_cursor.ascend(1);
        let v415_6_head = Path::from_slice(&[v415_6_byte]);
        let v416_2: Space = singleton(&(v415_6_head));
        let v416_3: Space = intersect(&(*CONSTANT_9),&(v416_2));
        let v416_4: Space = if has_head(&(v416_3)) { singleton(&[]) } else { Space::new() };
        drop(v416_3);
        let v416_5: Space = subtract(&(*CONSTANT_0),&(v416_4));
        drop(v416_4);
        let v416_8: Space = if (v416_5).is_empty() { Space::new() } else {
          let v417_6: Path = concat_path(&(v413_13_head),&(v415_6_head));
          let v417_7: Space = routine_48(c, &(v417_6), &(*p1), &(*p2), &(*p0), &(v415_6_tail));
          compose(&(v416_5),&(v417_7))
        };
        drop(v416_5);
        let v416_9: Space = intersect(&(*CONSTANT_9),&(v416_2));
        drop(v416_2);
        let v416_10: Space = if has_head(&(v416_9)) { singleton(&[]) } else { Space::new() };
        drop(v416_9);
        let v416_12: Space = if (v416_10).is_empty() { Space::new() } else {
          let v418_6: Path = concat_path(&(v413_13_head),&(v415_6_head));
          let v418_11: Space = routine_49(c, &(v418_6), &(*p1), &(*p2), &(*p0), &(v415_6_tail));
          drop(v418_6);
          compose(&(v416_10),&(v418_11))
        };
        drop(v416_10);
        let v416_13: Space = unite(&(v416_8),&(v416_12));
        v415_6.join_into((v416_13).clone());
      }
      drop(v415_6_cursor);
      compose(&(v414_5),&(v415_6))
    };
    drop(v414_5);
    let v414_8: Space = intersect(&(*CONSTANT_9),&(v414_2));
    drop(v414_2);
    let v414_9: Space = if has_head(&(v414_8)) { singleton(&[]) } else { Space::new() };
    drop(v414_8);
    let v414_11: Space = if (v414_9).is_empty() { Space::new() } else {
      let mut v419_10 = Space::new();
      let mut v419_10_cursor = (v413_13_tail).read_zipper();
      for v419_10_byte in v419_10_cursor.child_mask().iter() {
        v419_10_cursor.descend_to_byte(v419_10_byte);
        let v419_10_tail = v419_10_cursor.make_map();
        v419_10_cursor.ascend(1);
        let v419_10_head = Path::from_slice(&[v419_10_byte]);
        let v420_2: Space = singleton(&(v419_10_head));
        let v420_3: Space = intersect(&(*CONSTANT_9),&(v420_2));
        let v420_4: Space = if has_head(&(v420_3)) { singleton(&[]) } else { Space::new() };
        drop(v420_3);
        let v420_5: Space = subtract(&(*CONSTANT_0),&(v420_4));
        drop(v420_4);
        let v420_7: Space = if (v420_5).is_empty() { Space::new() } else {
          let v421_6: Space = routine_65(c, &(v419_10_head), &(*p1), &(*p2), &(*p0), &(v413_13_head), &(v419_10_tail));
          compose(&(v420_5),&(v421_6))
        };
        drop(v420_5);
        let v420_8: Space = intersect(&(*CONSTANT_9),&(v420_2));
        drop(v420_2);
        let v420_9: Space = if has_head(&(v420_8)) { singleton(&[]) } else { Space::new() };
        drop(v420_8);
        let v420_11: Space = if (v420_9).is_empty() { Space::new() } else {
          let v422_10: Space = routine_66(c, &(v419_10_head), &(*p1), &(*p2), &(*p0), &(v413_13_head), &(v419_10_tail));
          compose(&(v420_9),&(v422_10))
        };
        drop(v420_9);
        let v420_12: Space = unite(&(v420_7),&(v420_11));
        v419_10.join_into((v420_12).clone());
      }
      drop(v419_10_cursor);
      compose(&(v414_9),&(v419_10))
    };
    drop(v414_9);
    let v414_12: Space = unite(&(v414_7),&(v414_11));
    v413_13.join_into((v414_12).clone());
  }
  drop(v413_13_cursor);
  (v413_13).clone()
}

fn routine_48(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v423_11 = Space::new();
  let mut v423_11_cursor = (*s0).read_zipper();
  for v423_11_byte in v423_11_cursor.child_mask().iter() {
    v423_11_cursor.descend_to_byte(v423_11_byte);
    let v423_11_tail = v423_11_cursor.make_map();
    v423_11_cursor.ascend(1);
    let v423_11_head = Path::from_slice(&[v423_11_byte]);
    let v424_2: Space = singleton(&(v423_11_head));
    let v424_3: Space = intersect(&(*CONSTANT_9),&(v424_2));
    let v424_4: Space = if has_head(&(v424_3)) { singleton(&[]) } else { Space::new() };
    drop(v424_3);
    let v424_5: Space = subtract(&(*CONSTANT_0),&(v424_4));
    drop(v424_4);
    let v424_8: Space = if (v424_5).is_empty() { Space::new() } else {
      let v425_6: Path = concat_path(&(*p0),&(v423_11_head));
      let v425_7: Space = routine_48(c, &(v425_6), &(*p1), &(*p2), &(*p3), &(v423_11_tail));
      compose(&(v424_5),&(v425_7))
    };
    drop(v424_5);
    let v424_9: Space = intersect(&(*CONSTANT_9),&(v424_2));
    drop(v424_2);
    let v424_10: Space = if has_head(&(v424_9)) { singleton(&[]) } else { Space::new() };
    drop(v424_9);
    let v424_12: Space = if (v424_10).is_empty() { Space::new() } else {
      let v426_6: Path = concat_path(&(*p0),&(v423_11_head));
      let mut v426_11 = Space::new();
      let mut v426_11_cursor = (v423_11_tail).read_zipper();
      for v426_11_byte in v426_11_cursor.child_mask().iter() {
        v426_11_cursor.descend_to_byte(v426_11_byte);
        let v426_11_tail = v426_11_cursor.make_map();
        v426_11_cursor.ascend(1);
        let v426_11_head = Path::from_slice(&[v426_11_byte]);
        let v427_2: Space = singleton(&(v426_11_head));
        let v427_3: Space = intersect(&(*CONSTANT_9),&(v427_2));
        let v427_4: Space = if has_head(&(v427_3)) { singleton(&[]) } else { Space::new() };
        drop(v427_3);
        let v427_5: Space = subtract(&(*CONSTANT_0),&(v427_4));
        drop(v427_4);
        let v427_7: Space = if (v427_5).is_empty() { Space::new() } else {
          let v428_6: Space = routine_65(c, &(v426_11_head), &(*p1), &(*p2), &(*p3), &(v426_6), &(v426_11_tail));
          compose(&(v427_5),&(v428_6))
        };
        drop(v427_5);
        let v427_8: Space = intersect(&(*CONSTANT_9),&(v427_2));
        drop(v427_2);
        let v427_9: Space = if has_head(&(v427_8)) { singleton(&[]) } else { Space::new() };
        drop(v427_8);
        let v427_11: Space = if (v427_9).is_empty() { Space::new() } else {
          let v429_10: Space = routine_66(c, &(v426_11_head), &(*p1), &(*p2), &(*p3), &(v426_6), &(v426_11_tail));
          compose(&(v427_9),&(v429_10))
        };
        drop(v427_9);
        let v427_12: Space = unite(&(v427_7),&(v427_11));
        v426_11.join_into((v427_12).clone());
      }
      drop(v426_11_cursor);
      drop(v426_6);
      compose(&(v424_10),&(v426_11))
    };
    drop(v424_10);
    let v424_13: Space = unite(&(v424_8),&(v424_12));
    v423_11.join_into((v424_13).clone());
  }
  drop(v423_11_cursor);
  (v423_11).clone()
}

fn routine_49(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v430_16 = Space::new();
  let mut v430_16_cursor = (*s0).read_zipper();
  for v430_16_byte in v430_16_cursor.child_mask().iter() {
    v430_16_cursor.descend_to_byte(v430_16_byte);
    let v430_16_tail = v430_16_cursor.make_map();
    v430_16_cursor.ascend(1);
    let v430_16_head = Path::from_slice(&[v430_16_byte]);
    let v431_2: Space = singleton(&(v430_16_head));
    let v431_3: Space = intersect(&(*CONSTANT_9),&(v431_2));
    let v431_4: Space = if has_head(&(v431_3)) { singleton(&[]) } else { Space::new() };
    drop(v431_3);
    let v431_5: Space = subtract(&(*CONSTANT_0),&(v431_4));
    drop(v431_4);
    let v431_7: Space = if (v431_5).is_empty() { Space::new() } else {
      let mut v432_6 = Space::new();
      let mut v432_6_cursor = (v430_16_tail).read_zipper();
      for v432_6_byte in v432_6_cursor.child_mask().iter() {
        v432_6_cursor.descend_to_byte(v432_6_byte);
        let v432_6_tail = v432_6_cursor.make_map();
        v432_6_cursor.ascend(1);
        let v432_6_head = Path::from_slice(&[v432_6_byte]);
        let v433_2: Space = singleton(&(v432_6_head));
        let v433_3: Space = intersect(&(*CONSTANT_9),&(v433_2));
        let v433_4: Space = if has_head(&(v433_3)) { singleton(&[]) } else { Space::new() };
        drop(v433_3);
        let v433_5: Space = subtract(&(*CONSTANT_0),&(v433_4));
        drop(v433_4);
        let v433_8: Space = if (v433_5).is_empty() { Space::new() } else {
          let v434_6: Path = concat_path(&(v430_16_head),&(v432_6_head));
          let v434_7: Space = routine_65(c, &(v434_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v432_6_tail));
          compose(&(v433_5),&(v434_7))
        };
        drop(v433_5);
        let v433_9: Space = intersect(&(*CONSTANT_9),&(v433_2));
        drop(v433_2);
        let v433_10: Space = if has_head(&(v433_9)) { singleton(&[]) } else { Space::new() };
        drop(v433_9);
        let v433_12: Space = if (v433_10).is_empty() { Space::new() } else {
          let v435_6: Path = concat_path(&(v430_16_head),&(v432_6_head));
          let v435_11: Space = routine_66(c, &(v435_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v432_6_tail));
          drop(v435_6);
          compose(&(v433_10),&(v435_11))
        };
        drop(v433_10);
        let v433_13: Space = unite(&(v433_8),&(v433_12));
        v432_6.join_into((v433_13).clone());
      }
      drop(v432_6_cursor);
      compose(&(v431_5),&(v432_6))
    };
    drop(v431_5);
    let v431_8: Space = intersect(&(*CONSTANT_9),&(v431_2));
    drop(v431_2);
    let v431_9: Space = if has_head(&(v431_8)) { singleton(&[]) } else { Space::new() };
    drop(v431_8);
    let v431_13: Space = if (v431_9).is_empty() { Space::new() } else {
      let v436_10: Space = unwrap(&(v430_16_tail),&(*CONSTANT_6));
      let v436_11: Space = subtract(&(*CONSTANT_10),&(v436_10));
      drop(v436_10);
      let mut v436_12 = Space::new();
      let mut v436_12_cursor = (v436_11).read_zipper();
      for v436_12_byte in v436_12_cursor.child_mask().iter() {
        v436_12_cursor.descend_to_byte(v436_12_byte);
        let v436_12_tail = v436_12_cursor.make_map();
        v436_12_cursor.ascend(1);
        let v436_12_head = Path::from_slice(&[v436_12_byte]);
        let v437_2: Space = singleton(&(v436_12_head));
        let v437_3: Space = intersect(&(*CONSTANT_9),&(v437_2));
        let v437_4: Space = if has_head(&(v437_3)) { singleton(&[]) } else { Space::new() };
        drop(v437_3);
        let v437_5: Space = subtract(&(*CONSTANT_0),&(v437_4));
        drop(v437_4);
        let v437_7: Space = if (v437_5).is_empty() { Space::new() } else {
          let v438_6: Space = routine_67(c, &(v436_12_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v430_16_head), &(v436_12_tail), &(v430_16_tail));
          compose(&(v437_5),&(v438_6))
        };
        drop(v437_5);
        let v437_8: Space = intersect(&(*CONSTANT_9),&(v437_2));
        drop(v437_2);
        let v437_9: Space = if has_head(&(v437_8)) { singleton(&[]) } else { Space::new() };
        drop(v437_8);
        let v437_11: Space = if (v437_9).is_empty() { Space::new() } else {
          let v439_10: Space = routine_68(c, &(v436_12_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v430_16_head), &(v436_12_tail), &(v430_16_tail));
          compose(&(v437_9),&(v439_10))
        };
        drop(v437_9);
        let v437_12: Space = unite(&(v437_7),&(v437_11));
        v436_12.join_into((v437_12).clone());
      }
      drop(v436_12_cursor);
      drop(v436_11);
      compose(&(v431_9),&(v436_12))
    };
    drop(v431_9);
    let v431_14: Space = unite(&(v431_7),&(v431_13));
    v430_16.join_into((v431_14).clone());
  }
  drop(v430_16_cursor);
  (v430_16).clone()
}

fn routine_50(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v440_10 = Space::new();
  let mut v440_10_cursor = (*s0).read_zipper();
  for v440_10_byte in v440_10_cursor.child_mask().iter() {
    v440_10_cursor.descend_to_byte(v440_10_byte);
    let v440_10_tail = v440_10_cursor.make_map();
    v440_10_cursor.ascend(1);
    let v440_10_head = Path::from_slice(&[v440_10_byte]);
    let v441_2: Space = singleton(&(v440_10_head));
    let v441_3: Space = intersect(&(*CONSTANT_9),&(v441_2));
    let v441_4: Space = if has_head(&(v441_3)) { singleton(&[]) } else { Space::new() };
    drop(v441_3);
    let v441_5: Space = subtract(&(*CONSTANT_0),&(v441_4));
    drop(v441_4);
    let v441_8: Space = if (v441_5).is_empty() { Space::new() } else {
      let v442_6: Path = concat_path(&(*p0),&(v440_10_head));
      let v442_7: Space = routine_50(c, &(v442_6), &(*p1), &(*p2), &(v440_10_tail));
      compose(&(v441_5),&(v442_7))
    };
    drop(v441_5);
    let v441_9: Space = intersect(&(*CONSTANT_9),&(v441_2));
    drop(v441_2);
    let v441_10: Space = if has_head(&(v441_9)) { singleton(&[]) } else { Space::new() };
    drop(v441_9);
    let v441_12: Space = if (v441_10).is_empty() { Space::new() } else {
      let v443_6: Path = concat_path(&(*p0),&(v440_10_head));
      let mut v443_11 = Space::new();
      let mut v443_11_cursor = (v440_10_tail).read_zipper();
      for v443_11_byte in v443_11_cursor.child_mask().iter() {
        v443_11_cursor.descend_to_byte(v443_11_byte);
        let v443_11_tail = v443_11_cursor.make_map();
        v443_11_cursor.ascend(1);
        let v443_11_head = Path::from_slice(&[v443_11_byte]);
        let v444_2: Space = singleton(&(v443_11_head));
        let v444_3: Space = intersect(&(*CONSTANT_9),&(v444_2));
        let v444_4: Space = if has_head(&(v444_3)) { singleton(&[]) } else { Space::new() };
        drop(v444_3);
        let v444_5: Space = subtract(&(*CONSTANT_0),&(v444_4));
        drop(v444_4);
        let v444_7: Space = if (v444_5).is_empty() { Space::new() } else {
          let v445_6: Space = routine_52(c, &(v443_11_head), &(*p1), &(*p2), &(v443_6), &(v443_11_tail));
          compose(&(v444_5),&(v445_6))
        };
        drop(v444_5);
        let v444_8: Space = intersect(&(*CONSTANT_9),&(v444_2));
        drop(v444_2);
        let v444_9: Space = if has_head(&(v444_8)) { singleton(&[]) } else { Space::new() };
        drop(v444_8);
        let v444_11: Space = if (v444_9).is_empty() { Space::new() } else {
          let v446_10: Space = routine_53(c, &(v443_11_head), &(*p1), &(*p2), &(v443_6), &(v443_11_tail));
          compose(&(v444_9),&(v446_10))
        };
        drop(v444_9);
        let v444_12: Space = unite(&(v444_7),&(v444_11));
        v443_11.join_into((v444_12).clone());
      }
      drop(v443_11_cursor);
      drop(v443_6);
      compose(&(v441_10),&(v443_11))
    };
    drop(v441_10);
    let v441_13: Space = unite(&(v441_8),&(v441_12));
    v440_10.join_into((v441_13).clone());
  }
  drop(v440_10_cursor);
  (v440_10).clone()
}

fn routine_51(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v447_13 = Space::new();
  let mut v447_13_cursor = (*s0).read_zipper();
  for v447_13_byte in v447_13_cursor.child_mask().iter() {
    v447_13_cursor.descend_to_byte(v447_13_byte);
    let v447_13_tail = v447_13_cursor.make_map();
    v447_13_cursor.ascend(1);
    let v447_13_head = Path::from_slice(&[v447_13_byte]);
    let v448_2: Space = singleton(&(v447_13_head));
    let v448_3: Space = intersect(&(*CONSTANT_9),&(v448_2));
    let v448_4: Space = if has_head(&(v448_3)) { singleton(&[]) } else { Space::new() };
    drop(v448_3);
    let v448_5: Space = subtract(&(*CONSTANT_0),&(v448_4));
    drop(v448_4);
    let v448_7: Space = if (v448_5).is_empty() { Space::new() } else {
      let mut v449_6 = Space::new();
      let mut v449_6_cursor = (v447_13_tail).read_zipper();
      for v449_6_byte in v449_6_cursor.child_mask().iter() {
        v449_6_cursor.descend_to_byte(v449_6_byte);
        let v449_6_tail = v449_6_cursor.make_map();
        v449_6_cursor.ascend(1);
        let v449_6_head = Path::from_slice(&[v449_6_byte]);
        let v450_2: Space = singleton(&(v449_6_head));
        let v450_3: Space = intersect(&(*CONSTANT_9),&(v450_2));
        let v450_4: Space = if has_head(&(v450_3)) { singleton(&[]) } else { Space::new() };
        drop(v450_3);
        let v450_5: Space = subtract(&(*CONSTANT_0),&(v450_4));
        drop(v450_4);
        let v450_8: Space = if (v450_5).is_empty() { Space::new() } else {
          let v451_6: Path = concat_path(&(v447_13_head),&(v449_6_head));
          let v451_7: Space = routine_52(c, &(v451_6), &(*p1), &(*p2), &(*p0), &(v449_6_tail));
          compose(&(v450_5),&(v451_7))
        };
        drop(v450_5);
        let v450_9: Space = intersect(&(*CONSTANT_9),&(v450_2));
        drop(v450_2);
        let v450_10: Space = if has_head(&(v450_9)) { singleton(&[]) } else { Space::new() };
        drop(v450_9);
        let v450_12: Space = if (v450_10).is_empty() { Space::new() } else {
          let v452_6: Path = concat_path(&(v447_13_head),&(v449_6_head));
          let v452_11: Space = routine_53(c, &(v452_6), &(*p1), &(*p2), &(*p0), &(v449_6_tail));
          drop(v452_6);
          compose(&(v450_10),&(v452_11))
        };
        drop(v450_10);
        let v450_13: Space = unite(&(v450_8),&(v450_12));
        v449_6.join_into((v450_13).clone());
      }
      drop(v449_6_cursor);
      compose(&(v448_5),&(v449_6))
    };
    drop(v448_5);
    let v448_8: Space = intersect(&(*CONSTANT_9),&(v448_2));
    drop(v448_2);
    let v448_9: Space = if has_head(&(v448_8)) { singleton(&[]) } else { Space::new() };
    drop(v448_8);
    let v448_11: Space = if (v448_9).is_empty() { Space::new() } else {
      let mut v453_10 = Space::new();
      let mut v453_10_cursor = (v447_13_tail).read_zipper();
      for v453_10_byte in v453_10_cursor.child_mask().iter() {
        v453_10_cursor.descend_to_byte(v453_10_byte);
        let v453_10_tail = v453_10_cursor.make_map();
        v453_10_cursor.ascend(1);
        let v453_10_head = Path::from_slice(&[v453_10_byte]);
        let v454_2: Space = singleton(&(v453_10_head));
        let v454_3: Space = intersect(&(*CONSTANT_9),&(v454_2));
        let v454_4: Space = if has_head(&(v454_3)) { singleton(&[]) } else { Space::new() };
        drop(v454_3);
        let v454_5: Space = subtract(&(*CONSTANT_0),&(v454_4));
        drop(v454_4);
        let v454_7: Space = if (v454_5).is_empty() { Space::new() } else {
          let v455_6: Space = routine_69(c, &(v453_10_head), &(*p1), &(*p2), &(*p0), &(v447_13_head), &(v453_10_tail));
          compose(&(v454_5),&(v455_6))
        };
        drop(v454_5);
        let v454_8: Space = intersect(&(*CONSTANT_9),&(v454_2));
        drop(v454_2);
        let v454_9: Space = if has_head(&(v454_8)) { singleton(&[]) } else { Space::new() };
        drop(v454_8);
        let v454_11: Space = if (v454_9).is_empty() { Space::new() } else {
          let v456_10: Space = routine_70(c, &(v453_10_head), &(*p1), &(*p2), &(*p0), &(v447_13_head), &(v453_10_tail));
          compose(&(v454_9),&(v456_10))
        };
        drop(v454_9);
        let v454_12: Space = unite(&(v454_7),&(v454_11));
        v453_10.join_into((v454_12).clone());
      }
      drop(v453_10_cursor);
      compose(&(v448_9),&(v453_10))
    };
    drop(v448_9);
    let v448_12: Space = unite(&(v448_7),&(v448_11));
    v447_13.join_into((v448_12).clone());
  }
  drop(v447_13_cursor);
  (v447_13).clone()
}

fn routine_52(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v457_11 = Space::new();
  let mut v457_11_cursor = (*s0).read_zipper();
  for v457_11_byte in v457_11_cursor.child_mask().iter() {
    v457_11_cursor.descend_to_byte(v457_11_byte);
    let v457_11_tail = v457_11_cursor.make_map();
    v457_11_cursor.ascend(1);
    let v457_11_head = Path::from_slice(&[v457_11_byte]);
    let v458_2: Space = singleton(&(v457_11_head));
    let v458_3: Space = intersect(&(*CONSTANT_9),&(v458_2));
    let v458_4: Space = if has_head(&(v458_3)) { singleton(&[]) } else { Space::new() };
    drop(v458_3);
    let v458_5: Space = subtract(&(*CONSTANT_0),&(v458_4));
    drop(v458_4);
    let v458_8: Space = if (v458_5).is_empty() { Space::new() } else {
      let v459_6: Path = concat_path(&(*p0),&(v457_11_head));
      let v459_7: Space = routine_52(c, &(v459_6), &(*p1), &(*p2), &(*p3), &(v457_11_tail));
      compose(&(v458_5),&(v459_7))
    };
    drop(v458_5);
    let v458_9: Space = intersect(&(*CONSTANT_9),&(v458_2));
    drop(v458_2);
    let v458_10: Space = if has_head(&(v458_9)) { singleton(&[]) } else { Space::new() };
    drop(v458_9);
    let v458_12: Space = if (v458_10).is_empty() { Space::new() } else {
      let v460_6: Path = concat_path(&(*p0),&(v457_11_head));
      let mut v460_11 = Space::new();
      let mut v460_11_cursor = (v457_11_tail).read_zipper();
      for v460_11_byte in v460_11_cursor.child_mask().iter() {
        v460_11_cursor.descend_to_byte(v460_11_byte);
        let v460_11_tail = v460_11_cursor.make_map();
        v460_11_cursor.ascend(1);
        let v460_11_head = Path::from_slice(&[v460_11_byte]);
        let v461_2: Space = singleton(&(v460_11_head));
        let v461_3: Space = intersect(&(*CONSTANT_9),&(v461_2));
        let v461_4: Space = if has_head(&(v461_3)) { singleton(&[]) } else { Space::new() };
        drop(v461_3);
        let v461_5: Space = subtract(&(*CONSTANT_0),&(v461_4));
        drop(v461_4);
        let v461_7: Space = if (v461_5).is_empty() { Space::new() } else {
          let v462_6: Space = routine_69(c, &(v460_11_head), &(*p1), &(*p2), &(*p3), &(v460_6), &(v460_11_tail));
          compose(&(v461_5),&(v462_6))
        };
        drop(v461_5);
        let v461_8: Space = intersect(&(*CONSTANT_9),&(v461_2));
        drop(v461_2);
        let v461_9: Space = if has_head(&(v461_8)) { singleton(&[]) } else { Space::new() };
        drop(v461_8);
        let v461_11: Space = if (v461_9).is_empty() { Space::new() } else {
          let v463_10: Space = routine_70(c, &(v460_11_head), &(*p1), &(*p2), &(*p3), &(v460_6), &(v460_11_tail));
          compose(&(v461_9),&(v463_10))
        };
        drop(v461_9);
        let v461_12: Space = unite(&(v461_7),&(v461_11));
        v460_11.join_into((v461_12).clone());
      }
      drop(v460_11_cursor);
      drop(v460_6);
      compose(&(v458_10),&(v460_11))
    };
    drop(v458_10);
    let v458_13: Space = unite(&(v458_8),&(v458_12));
    v457_11.join_into((v458_13).clone());
  }
  drop(v457_11_cursor);
  (v457_11).clone()
}

fn routine_53(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v464_14 = Space::new();
  let mut v464_14_cursor = (*s0).read_zipper();
  for v464_14_byte in v464_14_cursor.child_mask().iter() {
    v464_14_cursor.descend_to_byte(v464_14_byte);
    let v464_14_tail = v464_14_cursor.make_map();
    v464_14_cursor.ascend(1);
    let v464_14_head = Path::from_slice(&[v464_14_byte]);
    let v465_2: Space = singleton(&(v464_14_head));
    let v465_3: Space = intersect(&(*CONSTANT_9),&(v465_2));
    let v465_4: Space = if has_head(&(v465_3)) { singleton(&[]) } else { Space::new() };
    drop(v465_3);
    let v465_5: Space = subtract(&(*CONSTANT_0),&(v465_4));
    drop(v465_4);
    let v465_7: Space = if (v465_5).is_empty() { Space::new() } else {
      let mut v466_6 = Space::new();
      let mut v466_6_cursor = (v464_14_tail).read_zipper();
      for v466_6_byte in v466_6_cursor.child_mask().iter() {
        v466_6_cursor.descend_to_byte(v466_6_byte);
        let v466_6_tail = v466_6_cursor.make_map();
        v466_6_cursor.ascend(1);
        let v466_6_head = Path::from_slice(&[v466_6_byte]);
        let v467_2: Space = singleton(&(v466_6_head));
        let v467_3: Space = intersect(&(*CONSTANT_9),&(v467_2));
        let v467_4: Space = if has_head(&(v467_3)) { singleton(&[]) } else { Space::new() };
        drop(v467_3);
        let v467_5: Space = subtract(&(*CONSTANT_0),&(v467_4));
        drop(v467_4);
        let v467_8: Space = if (v467_5).is_empty() { Space::new() } else {
          let v468_6: Path = concat_path(&(v464_14_head),&(v466_6_head));
          let v468_7: Space = routine_69(c, &(v468_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v466_6_tail));
          compose(&(v467_5),&(v468_7))
        };
        drop(v467_5);
        let v467_9: Space = intersect(&(*CONSTANT_9),&(v467_2));
        drop(v467_2);
        let v467_10: Space = if has_head(&(v467_9)) { singleton(&[]) } else { Space::new() };
        drop(v467_9);
        let v467_12: Space = if (v467_10).is_empty() { Space::new() } else {
          let v469_6: Path = concat_path(&(v464_14_head),&(v466_6_head));
          let v469_11: Space = routine_70(c, &(v469_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v466_6_tail));
          drop(v469_6);
          compose(&(v467_10),&(v469_11))
        };
        drop(v467_10);
        let v467_13: Space = unite(&(v467_8),&(v467_12));
        v466_6.join_into((v467_13).clone());
      }
      drop(v466_6_cursor);
      compose(&(v465_5),&(v466_6))
    };
    drop(v465_5);
    let v465_8: Space = intersect(&(*CONSTANT_9),&(v465_2));
    drop(v465_2);
    let v465_9: Space = if has_head(&(v465_8)) { singleton(&[]) } else { Space::new() };
    drop(v465_8);
    let v465_11: Space = if (v465_9).is_empty() { Space::new() } else {
      let mut v470_10 = Space::new();
      let mut v470_10_cursor = (v464_14_tail).read_zipper();
      for v470_10_byte in v470_10_cursor.child_mask().iter() {
        v470_10_cursor.descend_to_byte(v470_10_byte);
        let v470_10_tail = v470_10_cursor.make_map();
        v470_10_cursor.ascend(1);
        let v470_10_head = Path::from_slice(&[v470_10_byte]);
        let v471_2: Space = singleton(&(v470_10_head));
        let v471_3: Space = intersect(&(*CONSTANT_9),&(v471_2));
        let v471_4: Space = if has_head(&(v471_3)) { singleton(&[]) } else { Space::new() };
        drop(v471_3);
        let v471_5: Space = subtract(&(*CONSTANT_0),&(v471_4));
        drop(v471_4);
        let v471_7: Space = if (v471_5).is_empty() { Space::new() } else {
          let v472_6: Space = routine_71(c, &(v470_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v464_14_head), &(v470_10_tail));
          compose(&(v471_5),&(v472_6))
        };
        drop(v471_5);
        let v471_8: Space = intersect(&(*CONSTANT_9),&(v471_2));
        drop(v471_2);
        let v471_9: Space = if has_head(&(v471_8)) { singleton(&[]) } else { Space::new() };
        drop(v471_8);
        let v471_11: Space = if (v471_9).is_empty() { Space::new() } else {
          let v473_10: Space = routine_72(c, &(v470_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v464_14_head), &(v470_10_tail));
          compose(&(v471_9),&(v473_10))
        };
        drop(v471_9);
        let v471_12: Space = unite(&(v471_7),&(v471_11));
        v470_10.join_into((v471_12).clone());
      }
      drop(v470_10_cursor);
      compose(&(v465_9),&(v470_10))
    };
    drop(v465_9);
    let v465_12: Space = unite(&(v465_7),&(v465_11));
    v464_14.join_into((v465_12).clone());
  }
  drop(v464_14_cursor);
  (v464_14).clone()
}

fn routine_54(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v474_10 = Space::new();
  let mut v474_10_cursor = (*s0).read_zipper();
  for v474_10_byte in v474_10_cursor.child_mask().iter() {
    v474_10_cursor.descend_to_byte(v474_10_byte);
    let v474_10_tail = v474_10_cursor.make_map();
    v474_10_cursor.ascend(1);
    let v474_10_head = Path::from_slice(&[v474_10_byte]);
    let v475_2: Space = singleton(&(v474_10_head));
    let v475_3: Space = intersect(&(*CONSTANT_9),&(v475_2));
    let v475_4: Space = if has_head(&(v475_3)) { singleton(&[]) } else { Space::new() };
    drop(v475_3);
    let v475_5: Space = subtract(&(*CONSTANT_0),&(v475_4));
    drop(v475_4);
    let v475_8: Space = if (v475_5).is_empty() { Space::new() } else {
      let v476_6: Path = concat_path(&(*p0),&(v474_10_head));
      let v476_7: Space = routine_54(c, &(v476_6), &(*p1), &(*p2), &(v474_10_tail));
      compose(&(v475_5),&(v476_7))
    };
    drop(v475_5);
    let v475_9: Space = intersect(&(*CONSTANT_9),&(v475_2));
    drop(v475_2);
    let v475_10: Space = if has_head(&(v475_9)) { singleton(&[]) } else { Space::new() };
    drop(v475_9);
    let v475_12: Space = if (v475_10).is_empty() { Space::new() } else {
      let v477_6: Path = concat_path(&(*p0),&(v474_10_head));
      let mut v477_11 = Space::new();
      let mut v477_11_cursor = (v474_10_tail).read_zipper();
      for v477_11_byte in v477_11_cursor.child_mask().iter() {
        v477_11_cursor.descend_to_byte(v477_11_byte);
        let v477_11_tail = v477_11_cursor.make_map();
        v477_11_cursor.ascend(1);
        let v477_11_head = Path::from_slice(&[v477_11_byte]);
        let v478_2: Space = singleton(&(v477_11_head));
        let v478_3: Space = intersect(&(*CONSTANT_9),&(v478_2));
        let v478_4: Space = if has_head(&(v478_3)) { singleton(&[]) } else { Space::new() };
        drop(v478_3);
        let v478_5: Space = subtract(&(*CONSTANT_0),&(v478_4));
        drop(v478_4);
        let v478_7: Space = if (v478_5).is_empty() { Space::new() } else {
          let v479_6: Space = routine_56(c, &(v477_11_head), &(*p1), &(*p2), &(v477_6), &(v477_11_tail));
          compose(&(v478_5),&(v479_6))
        };
        drop(v478_5);
        let v478_8: Space = intersect(&(*CONSTANT_9),&(v478_2));
        drop(v478_2);
        let v478_9: Space = if has_head(&(v478_8)) { singleton(&[]) } else { Space::new() };
        drop(v478_8);
        let v478_11: Space = if (v478_9).is_empty() { Space::new() } else {
          let v480_10: Space = routine_57(c, &(v477_11_head), &(*p1), &(*p2), &(v477_6), &(v477_11_tail));
          compose(&(v478_9),&(v480_10))
        };
        drop(v478_9);
        let v478_12: Space = unite(&(v478_7),&(v478_11));
        v477_11.join_into((v478_12).clone());
      }
      drop(v477_11_cursor);
      drop(v477_6);
      compose(&(v475_10),&(v477_11))
    };
    drop(v475_10);
    let v475_13: Space = unite(&(v475_8),&(v475_12));
    v474_10.join_into((v475_13).clone());
  }
  drop(v474_10_cursor);
  (v474_10).clone()
}

fn routine_55(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v481_13 = Space::new();
  let mut v481_13_cursor = (*s0).read_zipper();
  for v481_13_byte in v481_13_cursor.child_mask().iter() {
    v481_13_cursor.descend_to_byte(v481_13_byte);
    let v481_13_tail = v481_13_cursor.make_map();
    v481_13_cursor.ascend(1);
    let v481_13_head = Path::from_slice(&[v481_13_byte]);
    let v482_2: Space = singleton(&(v481_13_head));
    let v482_3: Space = intersect(&(*CONSTANT_9),&(v482_2));
    let v482_4: Space = if has_head(&(v482_3)) { singleton(&[]) } else { Space::new() };
    drop(v482_3);
    let v482_5: Space = subtract(&(*CONSTANT_0),&(v482_4));
    drop(v482_4);
    let v482_7: Space = if (v482_5).is_empty() { Space::new() } else {
      let mut v483_6 = Space::new();
      let mut v483_6_cursor = (v481_13_tail).read_zipper();
      for v483_6_byte in v483_6_cursor.child_mask().iter() {
        v483_6_cursor.descend_to_byte(v483_6_byte);
        let v483_6_tail = v483_6_cursor.make_map();
        v483_6_cursor.ascend(1);
        let v483_6_head = Path::from_slice(&[v483_6_byte]);
        let v484_2: Space = singleton(&(v483_6_head));
        let v484_3: Space = intersect(&(*CONSTANT_9),&(v484_2));
        let v484_4: Space = if has_head(&(v484_3)) { singleton(&[]) } else { Space::new() };
        drop(v484_3);
        let v484_5: Space = subtract(&(*CONSTANT_0),&(v484_4));
        drop(v484_4);
        let v484_8: Space = if (v484_5).is_empty() { Space::new() } else {
          let v485_6: Path = concat_path(&(v481_13_head),&(v483_6_head));
          let v485_7: Space = routine_56(c, &(v485_6), &(*p1), &(*p2), &(*p0), &(v483_6_tail));
          compose(&(v484_5),&(v485_7))
        };
        drop(v484_5);
        let v484_9: Space = intersect(&(*CONSTANT_9),&(v484_2));
        drop(v484_2);
        let v484_10: Space = if has_head(&(v484_9)) { singleton(&[]) } else { Space::new() };
        drop(v484_9);
        let v484_12: Space = if (v484_10).is_empty() { Space::new() } else {
          let v486_6: Path = concat_path(&(v481_13_head),&(v483_6_head));
          let v486_11: Space = routine_57(c, &(v486_6), &(*p1), &(*p2), &(*p0), &(v483_6_tail));
          drop(v486_6);
          compose(&(v484_10),&(v486_11))
        };
        drop(v484_10);
        let v484_13: Space = unite(&(v484_8),&(v484_12));
        v483_6.join_into((v484_13).clone());
      }
      drop(v483_6_cursor);
      compose(&(v482_5),&(v483_6))
    };
    drop(v482_5);
    let v482_8: Space = intersect(&(*CONSTANT_9),&(v482_2));
    drop(v482_2);
    let v482_9: Space = if has_head(&(v482_8)) { singleton(&[]) } else { Space::new() };
    drop(v482_8);
    let v482_11: Space = if (v482_9).is_empty() { Space::new() } else {
      let mut v487_10 = Space::new();
      let mut v487_10_cursor = (v481_13_tail).read_zipper();
      for v487_10_byte in v487_10_cursor.child_mask().iter() {
        v487_10_cursor.descend_to_byte(v487_10_byte);
        let v487_10_tail = v487_10_cursor.make_map();
        v487_10_cursor.ascend(1);
        let v487_10_head = Path::from_slice(&[v487_10_byte]);
        let v488_2: Space = singleton(&(v487_10_head));
        let v488_3: Space = intersect(&(*CONSTANT_9),&(v488_2));
        let v488_4: Space = if has_head(&(v488_3)) { singleton(&[]) } else { Space::new() };
        drop(v488_3);
        let v488_5: Space = subtract(&(*CONSTANT_0),&(v488_4));
        drop(v488_4);
        let v488_7: Space = if (v488_5).is_empty() { Space::new() } else {
          let v489_6: Space = routine_73(c, &(v487_10_head), &(*p1), &(*p2), &(*p0), &(v481_13_head), &(v487_10_tail));
          compose(&(v488_5),&(v489_6))
        };
        drop(v488_5);
        let v488_8: Space = intersect(&(*CONSTANT_9),&(v488_2));
        drop(v488_2);
        let v488_9: Space = if has_head(&(v488_8)) { singleton(&[]) } else { Space::new() };
        drop(v488_8);
        let v488_11: Space = if (v488_9).is_empty() { Space::new() } else {
          let v490_10: Space = routine_74(c, &(v487_10_head), &(*p1), &(*p2), &(*p0), &(v481_13_head), &(v487_10_tail));
          compose(&(v488_9),&(v490_10))
        };
        drop(v488_9);
        let v488_12: Space = unite(&(v488_7),&(v488_11));
        v487_10.join_into((v488_12).clone());
      }
      drop(v487_10_cursor);
      compose(&(v482_9),&(v487_10))
    };
    drop(v482_9);
    let v482_12: Space = unite(&(v482_7),&(v482_11));
    v481_13.join_into((v482_12).clone());
  }
  drop(v481_13_cursor);
  (v481_13).clone()
}

fn routine_56(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v491_11 = Space::new();
  let mut v491_11_cursor = (*s0).read_zipper();
  for v491_11_byte in v491_11_cursor.child_mask().iter() {
    v491_11_cursor.descend_to_byte(v491_11_byte);
    let v491_11_tail = v491_11_cursor.make_map();
    v491_11_cursor.ascend(1);
    let v491_11_head = Path::from_slice(&[v491_11_byte]);
    let v492_2: Space = singleton(&(v491_11_head));
    let v492_3: Space = intersect(&(*CONSTANT_9),&(v492_2));
    let v492_4: Space = if has_head(&(v492_3)) { singleton(&[]) } else { Space::new() };
    drop(v492_3);
    let v492_5: Space = subtract(&(*CONSTANT_0),&(v492_4));
    drop(v492_4);
    let v492_8: Space = if (v492_5).is_empty() { Space::new() } else {
      let v493_6: Path = concat_path(&(*p0),&(v491_11_head));
      let v493_7: Space = routine_56(c, &(v493_6), &(*p1), &(*p2), &(*p3), &(v491_11_tail));
      compose(&(v492_5),&(v493_7))
    };
    drop(v492_5);
    let v492_9: Space = intersect(&(*CONSTANT_9),&(v492_2));
    drop(v492_2);
    let v492_10: Space = if has_head(&(v492_9)) { singleton(&[]) } else { Space::new() };
    drop(v492_9);
    let v492_12: Space = if (v492_10).is_empty() { Space::new() } else {
      let v494_6: Path = concat_path(&(*p0),&(v491_11_head));
      let mut v494_11 = Space::new();
      let mut v494_11_cursor = (v491_11_tail).read_zipper();
      for v494_11_byte in v494_11_cursor.child_mask().iter() {
        v494_11_cursor.descend_to_byte(v494_11_byte);
        let v494_11_tail = v494_11_cursor.make_map();
        v494_11_cursor.ascend(1);
        let v494_11_head = Path::from_slice(&[v494_11_byte]);
        let v495_2: Space = singleton(&(v494_11_head));
        let v495_3: Space = intersect(&(*CONSTANT_9),&(v495_2));
        let v495_4: Space = if has_head(&(v495_3)) { singleton(&[]) } else { Space::new() };
        drop(v495_3);
        let v495_5: Space = subtract(&(*CONSTANT_0),&(v495_4));
        drop(v495_4);
        let v495_7: Space = if (v495_5).is_empty() { Space::new() } else {
          let v496_6: Space = routine_73(c, &(v494_11_head), &(*p1), &(*p2), &(*p3), &(v494_6), &(v494_11_tail));
          compose(&(v495_5),&(v496_6))
        };
        drop(v495_5);
        let v495_8: Space = intersect(&(*CONSTANT_9),&(v495_2));
        drop(v495_2);
        let v495_9: Space = if has_head(&(v495_8)) { singleton(&[]) } else { Space::new() };
        drop(v495_8);
        let v495_11: Space = if (v495_9).is_empty() { Space::new() } else {
          let v497_10: Space = routine_74(c, &(v494_11_head), &(*p1), &(*p2), &(*p3), &(v494_6), &(v494_11_tail));
          compose(&(v495_9),&(v497_10))
        };
        drop(v495_9);
        let v495_12: Space = unite(&(v495_7),&(v495_11));
        v494_11.join_into((v495_12).clone());
      }
      drop(v494_11_cursor);
      drop(v494_6);
      compose(&(v492_10),&(v494_11))
    };
    drop(v492_10);
    let v492_13: Space = unite(&(v492_8),&(v492_12));
    v491_11.join_into((v492_13).clone());
  }
  drop(v491_11_cursor);
  (v491_11).clone()
}

fn routine_57(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v498_14 = Space::new();
  let mut v498_14_cursor = (*s0).read_zipper();
  for v498_14_byte in v498_14_cursor.child_mask().iter() {
    v498_14_cursor.descend_to_byte(v498_14_byte);
    let v498_14_tail = v498_14_cursor.make_map();
    v498_14_cursor.ascend(1);
    let v498_14_head = Path::from_slice(&[v498_14_byte]);
    let v499_2: Space = singleton(&(v498_14_head));
    let v499_3: Space = intersect(&(*CONSTANT_9),&(v499_2));
    let v499_4: Space = if has_head(&(v499_3)) { singleton(&[]) } else { Space::new() };
    drop(v499_3);
    let v499_5: Space = subtract(&(*CONSTANT_0),&(v499_4));
    drop(v499_4);
    let v499_7: Space = if (v499_5).is_empty() { Space::new() } else {
      let mut v500_6 = Space::new();
      let mut v500_6_cursor = (v498_14_tail).read_zipper();
      for v500_6_byte in v500_6_cursor.child_mask().iter() {
        v500_6_cursor.descend_to_byte(v500_6_byte);
        let v500_6_tail = v500_6_cursor.make_map();
        v500_6_cursor.ascend(1);
        let v500_6_head = Path::from_slice(&[v500_6_byte]);
        let v501_2: Space = singleton(&(v500_6_head));
        let v501_3: Space = intersect(&(*CONSTANT_9),&(v501_2));
        let v501_4: Space = if has_head(&(v501_3)) { singleton(&[]) } else { Space::new() };
        drop(v501_3);
        let v501_5: Space = subtract(&(*CONSTANT_0),&(v501_4));
        drop(v501_4);
        let v501_8: Space = if (v501_5).is_empty() { Space::new() } else {
          let v502_6: Path = concat_path(&(v498_14_head),&(v500_6_head));
          let v502_7: Space = routine_73(c, &(v502_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v500_6_tail));
          compose(&(v501_5),&(v502_7))
        };
        drop(v501_5);
        let v501_9: Space = intersect(&(*CONSTANT_9),&(v501_2));
        drop(v501_2);
        let v501_10: Space = if has_head(&(v501_9)) { singleton(&[]) } else { Space::new() };
        drop(v501_9);
        let v501_12: Space = if (v501_10).is_empty() { Space::new() } else {
          let v503_6: Path = concat_path(&(v498_14_head),&(v500_6_head));
          let v503_11: Space = routine_74(c, &(v503_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v500_6_tail));
          drop(v503_6);
          compose(&(v501_10),&(v503_11))
        };
        drop(v501_10);
        let v501_13: Space = unite(&(v501_8),&(v501_12));
        v500_6.join_into((v501_13).clone());
      }
      drop(v500_6_cursor);
      compose(&(v499_5),&(v500_6))
    };
    drop(v499_5);
    let v499_8: Space = intersect(&(*CONSTANT_9),&(v499_2));
    drop(v499_2);
    let v499_9: Space = if has_head(&(v499_8)) { singleton(&[]) } else { Space::new() };
    drop(v499_8);
    let v499_11: Space = if (v499_9).is_empty() { Space::new() } else {
      let mut v504_10 = Space::new();
      let mut v504_10_cursor = (v498_14_tail).read_zipper();
      for v504_10_byte in v504_10_cursor.child_mask().iter() {
        v504_10_cursor.descend_to_byte(v504_10_byte);
        let v504_10_tail = v504_10_cursor.make_map();
        v504_10_cursor.ascend(1);
        let v504_10_head = Path::from_slice(&[v504_10_byte]);
        let v505_2: Space = singleton(&(v504_10_head));
        let v505_3: Space = intersect(&(*CONSTANT_9),&(v505_2));
        let v505_4: Space = if has_head(&(v505_3)) { singleton(&[]) } else { Space::new() };
        drop(v505_3);
        let v505_5: Space = subtract(&(*CONSTANT_0),&(v505_4));
        drop(v505_4);
        let v505_7: Space = if (v505_5).is_empty() { Space::new() } else {
          let v506_6: Space = routine_75(c, &(v504_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v498_14_head), &(v504_10_tail));
          compose(&(v505_5),&(v506_6))
        };
        drop(v505_5);
        let v505_8: Space = intersect(&(*CONSTANT_9),&(v505_2));
        drop(v505_2);
        let v505_9: Space = if has_head(&(v505_8)) { singleton(&[]) } else { Space::new() };
        drop(v505_8);
        let v505_11: Space = if (v505_9).is_empty() { Space::new() } else {
          let v507_10: Space = routine_76(c, &(v504_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v498_14_head), &(v504_10_tail));
          compose(&(v505_9),&(v507_10))
        };
        drop(v505_9);
        let v505_12: Space = unite(&(v505_7),&(v505_11));
        v504_10.join_into((v505_12).clone());
      }
      drop(v504_10_cursor);
      compose(&(v499_9),&(v504_10))
    };
    drop(v499_9);
    let v499_12: Space = unite(&(v499_7),&(v499_11));
    v498_14.join_into((v499_12).clone());
  }
  drop(v498_14_cursor);
  (v498_14).clone()
}

fn routine_58(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v508_10 = Space::new();
  let mut v508_10_cursor = (*s0).read_zipper();
  for v508_10_byte in v508_10_cursor.child_mask().iter() {
    v508_10_cursor.descend_to_byte(v508_10_byte);
    let v508_10_tail = v508_10_cursor.make_map();
    v508_10_cursor.ascend(1);
    let v508_10_head = Path::from_slice(&[v508_10_byte]);
    let v509_2: Space = singleton(&(v508_10_head));
    let v509_3: Space = intersect(&(*CONSTANT_9),&(v509_2));
    let v509_4: Space = if has_head(&(v509_3)) { singleton(&[]) } else { Space::new() };
    drop(v509_3);
    let v509_5: Space = subtract(&(*CONSTANT_0),&(v509_4));
    drop(v509_4);
    let v509_8: Space = if (v509_5).is_empty() { Space::new() } else {
      let v510_6: Path = concat_path(&(*p0),&(v508_10_head));
      let v510_7: Space = routine_58(c, &(v510_6), &(*p1), &(*p2), &(v508_10_tail));
      compose(&(v509_5),&(v510_7))
    };
    drop(v509_5);
    let v509_9: Space = intersect(&(*CONSTANT_9),&(v509_2));
    drop(v509_2);
    let v509_10: Space = if has_head(&(v509_9)) { singleton(&[]) } else { Space::new() };
    drop(v509_9);
    let v509_12: Space = if (v509_10).is_empty() { Space::new() } else {
      let v511_6: Path = concat_path(&(*p0),&(v508_10_head));
      let mut v511_11 = Space::new();
      let mut v511_11_cursor = (v508_10_tail).read_zipper();
      for v511_11_byte in v511_11_cursor.child_mask().iter() {
        v511_11_cursor.descend_to_byte(v511_11_byte);
        let v511_11_tail = v511_11_cursor.make_map();
        v511_11_cursor.ascend(1);
        let v511_11_head = Path::from_slice(&[v511_11_byte]);
        let v512_2: Space = singleton(&(v511_11_head));
        let v512_3: Space = intersect(&(*CONSTANT_9),&(v512_2));
        let v512_4: Space = if has_head(&(v512_3)) { singleton(&[]) } else { Space::new() };
        drop(v512_3);
        let v512_5: Space = subtract(&(*CONSTANT_0),&(v512_4));
        drop(v512_4);
        let v512_7: Space = if (v512_5).is_empty() { Space::new() } else {
          let v513_6: Space = routine_60(c, &(v511_11_head), &(*p1), &(*p2), &(v511_6), &(v511_11_tail));
          compose(&(v512_5),&(v513_6))
        };
        drop(v512_5);
        let v512_8: Space = intersect(&(*CONSTANT_9),&(v512_2));
        drop(v512_2);
        let v512_9: Space = if has_head(&(v512_8)) { singleton(&[]) } else { Space::new() };
        drop(v512_8);
        let v512_11: Space = if (v512_9).is_empty() { Space::new() } else {
          let v514_10: Space = routine_61(c, &(v511_11_head), &(*p1), &(*p2), &(v511_6), &(v511_11_tail));
          compose(&(v512_9),&(v514_10))
        };
        drop(v512_9);
        let v512_12: Space = unite(&(v512_7),&(v512_11));
        v511_11.join_into((v512_12).clone());
      }
      drop(v511_11_cursor);
      drop(v511_6);
      compose(&(v509_10),&(v511_11))
    };
    drop(v509_10);
    let v509_13: Space = unite(&(v509_8),&(v509_12));
    v508_10.join_into((v509_13).clone());
  }
  drop(v508_10_cursor);
  (v508_10).clone()
}

fn routine_59(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v515_13 = Space::new();
  let mut v515_13_cursor = (*s0).read_zipper();
  for v515_13_byte in v515_13_cursor.child_mask().iter() {
    v515_13_cursor.descend_to_byte(v515_13_byte);
    let v515_13_tail = v515_13_cursor.make_map();
    v515_13_cursor.ascend(1);
    let v515_13_head = Path::from_slice(&[v515_13_byte]);
    let v516_2: Space = singleton(&(v515_13_head));
    let v516_3: Space = intersect(&(*CONSTANT_9),&(v516_2));
    let v516_4: Space = if has_head(&(v516_3)) { singleton(&[]) } else { Space::new() };
    drop(v516_3);
    let v516_5: Space = subtract(&(*CONSTANT_0),&(v516_4));
    drop(v516_4);
    let v516_7: Space = if (v516_5).is_empty() { Space::new() } else {
      let mut v517_6 = Space::new();
      let mut v517_6_cursor = (v515_13_tail).read_zipper();
      for v517_6_byte in v517_6_cursor.child_mask().iter() {
        v517_6_cursor.descend_to_byte(v517_6_byte);
        let v517_6_tail = v517_6_cursor.make_map();
        v517_6_cursor.ascend(1);
        let v517_6_head = Path::from_slice(&[v517_6_byte]);
        let v518_2: Space = singleton(&(v517_6_head));
        let v518_3: Space = intersect(&(*CONSTANT_9),&(v518_2));
        let v518_4: Space = if has_head(&(v518_3)) { singleton(&[]) } else { Space::new() };
        drop(v518_3);
        let v518_5: Space = subtract(&(*CONSTANT_0),&(v518_4));
        drop(v518_4);
        let v518_8: Space = if (v518_5).is_empty() { Space::new() } else {
          let v519_6: Path = concat_path(&(v515_13_head),&(v517_6_head));
          let v519_7: Space = routine_60(c, &(v519_6), &(*p1), &(*p2), &(*p0), &(v517_6_tail));
          compose(&(v518_5),&(v519_7))
        };
        drop(v518_5);
        let v518_9: Space = intersect(&(*CONSTANT_9),&(v518_2));
        drop(v518_2);
        let v518_10: Space = if has_head(&(v518_9)) { singleton(&[]) } else { Space::new() };
        drop(v518_9);
        let v518_12: Space = if (v518_10).is_empty() { Space::new() } else {
          let v520_6: Path = concat_path(&(v515_13_head),&(v517_6_head));
          let v520_11: Space = routine_61(c, &(v520_6), &(*p1), &(*p2), &(*p0), &(v517_6_tail));
          drop(v520_6);
          compose(&(v518_10),&(v520_11))
        };
        drop(v518_10);
        let v518_13: Space = unite(&(v518_8),&(v518_12));
        v517_6.join_into((v518_13).clone());
      }
      drop(v517_6_cursor);
      compose(&(v516_5),&(v517_6))
    };
    drop(v516_5);
    let v516_8: Space = intersect(&(*CONSTANT_9),&(v516_2));
    drop(v516_2);
    let v516_9: Space = if has_head(&(v516_8)) { singleton(&[]) } else { Space::new() };
    drop(v516_8);
    let v516_11: Space = if (v516_9).is_empty() { Space::new() } else {
      let mut v521_10 = Space::new();
      let mut v521_10_cursor = (v515_13_tail).read_zipper();
      for v521_10_byte in v521_10_cursor.child_mask().iter() {
        v521_10_cursor.descend_to_byte(v521_10_byte);
        let v521_10_tail = v521_10_cursor.make_map();
        v521_10_cursor.ascend(1);
        let v521_10_head = Path::from_slice(&[v521_10_byte]);
        let v522_2: Space = singleton(&(v521_10_head));
        let v522_3: Space = intersect(&(*CONSTANT_9),&(v522_2));
        let v522_4: Space = if has_head(&(v522_3)) { singleton(&[]) } else { Space::new() };
        drop(v522_3);
        let v522_5: Space = subtract(&(*CONSTANT_0),&(v522_4));
        drop(v522_4);
        let v522_7: Space = if (v522_5).is_empty() { Space::new() } else {
          let v523_6: Space = routine_77(c, &(v521_10_head), &(*p1), &(*p2), &(*p0), &(v515_13_head), &(v521_10_tail));
          compose(&(v522_5),&(v523_6))
        };
        drop(v522_5);
        let v522_8: Space = intersect(&(*CONSTANT_9),&(v522_2));
        drop(v522_2);
        let v522_9: Space = if has_head(&(v522_8)) { singleton(&[]) } else { Space::new() };
        drop(v522_8);
        let v522_11: Space = if (v522_9).is_empty() { Space::new() } else {
          let v524_10: Space = routine_78(c, &(v521_10_head), &(*p1), &(*p2), &(*p0), &(v515_13_head), &(v521_10_tail));
          compose(&(v522_9),&(v524_10))
        };
        drop(v522_9);
        let v522_12: Space = unite(&(v522_7),&(v522_11));
        v521_10.join_into((v522_12).clone());
      }
      drop(v521_10_cursor);
      compose(&(v516_9),&(v521_10))
    };
    drop(v516_9);
    let v516_12: Space = unite(&(v516_7),&(v516_11));
    v515_13.join_into((v516_12).clone());
  }
  drop(v515_13_cursor);
  (v515_13).clone()
}

fn routine_60(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v525_11 = Space::new();
  let mut v525_11_cursor = (*s0).read_zipper();
  for v525_11_byte in v525_11_cursor.child_mask().iter() {
    v525_11_cursor.descend_to_byte(v525_11_byte);
    let v525_11_tail = v525_11_cursor.make_map();
    v525_11_cursor.ascend(1);
    let v525_11_head = Path::from_slice(&[v525_11_byte]);
    let v526_2: Space = singleton(&(v525_11_head));
    let v526_3: Space = intersect(&(*CONSTANT_9),&(v526_2));
    let v526_4: Space = if has_head(&(v526_3)) { singleton(&[]) } else { Space::new() };
    drop(v526_3);
    let v526_5: Space = subtract(&(*CONSTANT_0),&(v526_4));
    drop(v526_4);
    let v526_8: Space = if (v526_5).is_empty() { Space::new() } else {
      let v527_6: Path = concat_path(&(*p0),&(v525_11_head));
      let v527_7: Space = routine_60(c, &(v527_6), &(*p1), &(*p2), &(*p3), &(v525_11_tail));
      compose(&(v526_5),&(v527_7))
    };
    drop(v526_5);
    let v526_9: Space = intersect(&(*CONSTANT_9),&(v526_2));
    drop(v526_2);
    let v526_10: Space = if has_head(&(v526_9)) { singleton(&[]) } else { Space::new() };
    drop(v526_9);
    let v526_12: Space = if (v526_10).is_empty() { Space::new() } else {
      let v528_6: Path = concat_path(&(*p0),&(v525_11_head));
      let mut v528_11 = Space::new();
      let mut v528_11_cursor = (v525_11_tail).read_zipper();
      for v528_11_byte in v528_11_cursor.child_mask().iter() {
        v528_11_cursor.descend_to_byte(v528_11_byte);
        let v528_11_tail = v528_11_cursor.make_map();
        v528_11_cursor.ascend(1);
        let v528_11_head = Path::from_slice(&[v528_11_byte]);
        let v529_2: Space = singleton(&(v528_11_head));
        let v529_3: Space = intersect(&(*CONSTANT_9),&(v529_2));
        let v529_4: Space = if has_head(&(v529_3)) { singleton(&[]) } else { Space::new() };
        drop(v529_3);
        let v529_5: Space = subtract(&(*CONSTANT_0),&(v529_4));
        drop(v529_4);
        let v529_7: Space = if (v529_5).is_empty() { Space::new() } else {
          let v530_6: Space = routine_77(c, &(v528_11_head), &(*p1), &(*p2), &(*p3), &(v528_6), &(v528_11_tail));
          compose(&(v529_5),&(v530_6))
        };
        drop(v529_5);
        let v529_8: Space = intersect(&(*CONSTANT_9),&(v529_2));
        drop(v529_2);
        let v529_9: Space = if has_head(&(v529_8)) { singleton(&[]) } else { Space::new() };
        drop(v529_8);
        let v529_11: Space = if (v529_9).is_empty() { Space::new() } else {
          let v531_10: Space = routine_78(c, &(v528_11_head), &(*p1), &(*p2), &(*p3), &(v528_6), &(v528_11_tail));
          compose(&(v529_9),&(v531_10))
        };
        drop(v529_9);
        let v529_12: Space = unite(&(v529_7),&(v529_11));
        v528_11.join_into((v529_12).clone());
      }
      drop(v528_11_cursor);
      drop(v528_6);
      compose(&(v526_10),&(v528_11))
    };
    drop(v526_10);
    let v526_13: Space = unite(&(v526_8),&(v526_12));
    v525_11.join_into((v526_13).clone());
  }
  drop(v525_11_cursor);
  (v525_11).clone()
}

fn routine_61(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v532_14 = Space::new();
  let mut v532_14_cursor = (*s0).read_zipper();
  for v532_14_byte in v532_14_cursor.child_mask().iter() {
    v532_14_cursor.descend_to_byte(v532_14_byte);
    let v532_14_tail = v532_14_cursor.make_map();
    v532_14_cursor.ascend(1);
    let v532_14_head = Path::from_slice(&[v532_14_byte]);
    let v533_2: Space = singleton(&(v532_14_head));
    let v533_3: Space = intersect(&(*CONSTANT_9),&(v533_2));
    let v533_4: Space = if has_head(&(v533_3)) { singleton(&[]) } else { Space::new() };
    drop(v533_3);
    let v533_5: Space = subtract(&(*CONSTANT_0),&(v533_4));
    drop(v533_4);
    let v533_7: Space = if (v533_5).is_empty() { Space::new() } else {
      let mut v534_6 = Space::new();
      let mut v534_6_cursor = (v532_14_tail).read_zipper();
      for v534_6_byte in v534_6_cursor.child_mask().iter() {
        v534_6_cursor.descend_to_byte(v534_6_byte);
        let v534_6_tail = v534_6_cursor.make_map();
        v534_6_cursor.ascend(1);
        let v534_6_head = Path::from_slice(&[v534_6_byte]);
        let v535_2: Space = singleton(&(v534_6_head));
        let v535_3: Space = intersect(&(*CONSTANT_9),&(v535_2));
        let v535_4: Space = if has_head(&(v535_3)) { singleton(&[]) } else { Space::new() };
        drop(v535_3);
        let v535_5: Space = subtract(&(*CONSTANT_0),&(v535_4));
        drop(v535_4);
        let v535_8: Space = if (v535_5).is_empty() { Space::new() } else {
          let v536_6: Path = concat_path(&(v532_14_head),&(v534_6_head));
          let v536_7: Space = routine_77(c, &(v536_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v534_6_tail));
          compose(&(v535_5),&(v536_7))
        };
        drop(v535_5);
        let v535_9: Space = intersect(&(*CONSTANT_9),&(v535_2));
        drop(v535_2);
        let v535_10: Space = if has_head(&(v535_9)) { singleton(&[]) } else { Space::new() };
        drop(v535_9);
        let v535_12: Space = if (v535_10).is_empty() { Space::new() } else {
          let v537_6: Path = concat_path(&(v532_14_head),&(v534_6_head));
          let v537_11: Space = routine_78(c, &(v537_6), &(*p1), &(*p2), &(*p3), &(*p0), &(v534_6_tail));
          drop(v537_6);
          compose(&(v535_10),&(v537_11))
        };
        drop(v535_10);
        let v535_13: Space = unite(&(v535_8),&(v535_12));
        v534_6.join_into((v535_13).clone());
      }
      drop(v534_6_cursor);
      compose(&(v533_5),&(v534_6))
    };
    drop(v533_5);
    let v533_8: Space = intersect(&(*CONSTANT_9),&(v533_2));
    drop(v533_2);
    let v533_9: Space = if has_head(&(v533_8)) { singleton(&[]) } else { Space::new() };
    drop(v533_8);
    let v533_11: Space = if (v533_9).is_empty() { Space::new() } else {
      let mut v538_10 = Space::new();
      let mut v538_10_cursor = (v532_14_tail).read_zipper();
      for v538_10_byte in v538_10_cursor.child_mask().iter() {
        v538_10_cursor.descend_to_byte(v538_10_byte);
        let v538_10_tail = v538_10_cursor.make_map();
        v538_10_cursor.ascend(1);
        let v538_10_head = Path::from_slice(&[v538_10_byte]);
        let v539_2: Space = singleton(&(v538_10_head));
        let v539_3: Space = intersect(&(*CONSTANT_9),&(v539_2));
        let v539_4: Space = if has_head(&(v539_3)) { singleton(&[]) } else { Space::new() };
        drop(v539_3);
        let v539_5: Space = subtract(&(*CONSTANT_0),&(v539_4));
        drop(v539_4);
        let v539_7: Space = if (v539_5).is_empty() { Space::new() } else {
          let v540_6: Space = routine_79(c, &(v538_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v532_14_head), &(v538_10_tail));
          compose(&(v539_5),&(v540_6))
        };
        drop(v539_5);
        let v539_8: Space = intersect(&(*CONSTANT_9),&(v539_2));
        drop(v539_2);
        let v539_9: Space = if has_head(&(v539_8)) { singleton(&[]) } else { Space::new() };
        drop(v539_8);
        let v539_11: Space = if (v539_9).is_empty() { Space::new() } else {
          let v541_10: Space = routine_80(c, &(v538_10_head), &(*p1), &(*p2), &(*p3), &(*p0), &(v532_14_head), &(v538_10_tail));
          compose(&(v539_9),&(v541_10))
        };
        drop(v539_9);
        let v539_12: Space = unite(&(v539_7),&(v539_11));
        v538_10.join_into((v539_12).clone());
      }
      drop(v538_10_cursor);
      compose(&(v533_9),&(v538_10))
    };
    drop(v533_9);
    let v533_12: Space = unite(&(v533_7),&(v533_11));
    v532_14.join_into((v533_12).clone());
  }
  drop(v532_14_cursor);
  (v532_14).clone()
}

fn routine_62(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v542_5: Space = unwrap(&(*CONSTANT_21),&(*p1));
  let v542_6: Space = unwrap(&(v542_5),&(*p0));
  drop(v542_5);
  let v542_10: Space = if (v542_6).is_empty() { Space::new() } else {
    let v543_8: Space = unwrap(&(*CONSTANT_21),&(*p2));
    let v543_9: Space = unwrap(&(v543_8),&(*p0));
    drop(v543_8);
    compose(&(v542_6),&(v543_9))
  };
  drop(v542_6);
  let v542_11: Path = concat_path(&(*p0),&(*p2));
  let v542_12: Space = singleton(&(v542_11));
  drop(v542_11);
  let v542_13: Space = unite(&(v542_10),&(v542_12));
  drop(v542_10);
  drop(v542_12);
  let v542_14: Path = concat_path(&(*p1),&(*p0));
  let v542_15: Space = singleton(&(v542_14));
  drop(v542_14);
  let v542_16: Space = unite(&(v542_13),&(v542_15));
  drop(v542_13);
  drop(v542_15);
  (v542_16).clone()
}

fn routine_63(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space, s1: &Space) -> Space {
  let v544_12: Path = concat_path(&(*p4),&(*p1));
  let v544_13: Path = concat_path(&(v544_12),&(*p2));
  drop(v544_12);
  let v544_14: Path = concat_path(&(v544_13),&(*p3));
  drop(v544_13);
  let mut v544_15 = Space::new();
  let mut v544_15_cursor = (*s0).read_zipper();
  for v544_15_byte in v544_15_cursor.child_mask().iter() {
    v544_15_cursor.descend_to_byte(v544_15_byte);
    let v544_15_tail = v544_15_cursor.make_map();
    v544_15_cursor.ascend(1);
    let v544_15_head = Path::from_slice(&[v544_15_byte]);
    let v545_2: Space = singleton(&(v544_15_head));
    let v545_3: Space = intersect(&(*CONSTANT_9),&(v545_2));
    let v545_4: Space = if has_head(&(v545_3)) { singleton(&[]) } else { Space::new() };
    drop(v545_3);
    let v545_5: Space = subtract(&(*CONSTANT_0),&(v545_4));
    drop(v545_4);
    let v545_8: Space = if (v545_5).is_empty() { Space::new() } else {
      let v546_6: Path = concat_path(&(*p0),&(v544_15_head));
      let v546_7: Space = routine_63(c, &(v546_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v544_15_tail), &(*s1));
      compose(&(v545_5),&(v546_7))
    };
    drop(v545_5);
    let v545_9: Space = intersect(&(*CONSTANT_9),&(v545_2));
    drop(v545_2);
    let v545_10: Space = if has_head(&(v545_9)) { singleton(&[]) } else { Space::new() };
    drop(v545_9);
    let v545_13: Space = if (v545_10).is_empty() { Space::new() } else {
      let v547_6: Path = concat_path(&(*p0),&(v544_15_head));
      let v547_11: Space = routine_35(c, &(v547_6), &(*CONSTANT_5), &(*CONSTANT_8));
      let v547_12: Space = unite(&(*s1),&(v547_11));
      compose(&(v545_10),&(v547_12))
    };
    drop(v545_10);
    let v545_14: Space = wrap(&(v545_13),&(v544_14));
    let v548_6: Path = concat_path(&(*p0),&(v544_15_head));
    let v545_15: Space = wrap(&(v545_14),&(v548_6));
    let v545_16: Space = unite(&(v545_8),&(v545_15));
    v544_15.join_into((v545_16).clone());
  }
  drop(v544_15_cursor);
  drop(v544_14);
  (v544_15).clone()
}

fn routine_64(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space, s1: &Space) -> Space {
  let v549_40: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v550_11: Space = routine_34(c, &(*CONSTANT_11), &(*CONSTANT_5), &(*p0), &(*CONSTANT_9));
    let v550_14: Space = routine_34(c, &(*CONSTANT_12), &(*CONSTANT_5), &(*p0), &(*CONSTANT_9));
    let v550_15: Space = unite(&(v550_11),&(v550_14));
    let v550_18: Space = routine_34(c, &(*CONSTANT_13), &(*CONSTANT_5), &(*p0), &(*CONSTANT_9));
    let v550_19: Space = unite(&(v550_15),&(v550_18));
    let v550_22: Space = routine_34(c, &(*CONSTANT_14), &(*CONSTANT_5), &(*p0), &(*CONSTANT_9));
    let v550_23: Space = unite(&(v550_19),&(v550_22));
    let v550_26: Space = routine_34(c, &(*CONSTANT_15), &(*CONSTANT_5), &(*p0), &(*CONSTANT_9));
    let v550_27: Space = unite(&(v550_23),&(v550_26));
    let v550_30: Space = routine_34(c, &(*CONSTANT_16), &(*CONSTANT_5), &(*p0), &(*CONSTANT_9));
    let v550_31: Space = unite(&(v550_27),&(v550_30));
    let v550_34: Space = routine_34(c, &(*CONSTANT_17), &(*CONSTANT_5), &(*p0), &(*CONSTANT_9));
    let v550_35: Space = unite(&(v550_31),&(v550_34));
    let v550_38: Space = routine_34(c, &(*CONSTANT_18), &(*CONSTANT_5), &(*p0), &(*CONSTANT_9));
    let v550_39: Space = unite(&(v550_35),&(v550_38));
    compose(&(*CONSTANT_0),&(v550_39))
  };
  let v549_42: Space = intersect(&(v549_40),&(*CONSTANT_19));
  let v549_43: Space = unite(&(v549_42),&(*s1));
  let v549_44: Path = concat_path(&(*p4),&(*p1));
  let v549_45: Path = concat_path(&(v549_44),&(*p2));
  drop(v549_44);
  let v549_46: Path = concat_path(&(v549_45),&(*p3));
  drop(v549_45);
  let v549_47: Space = wrap(&(v549_43),&(v549_46));
  drop(v549_46);
  let v549_48: Space = wrap(&(v549_47),&(*p0));
  (v549_48).clone()
}

fn routine_65(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v551_14 = Space::new();
  let mut v551_14_cursor = (*s0).read_zipper();
  for v551_14_byte in v551_14_cursor.child_mask().iter() {
    v551_14_cursor.descend_to_byte(v551_14_byte);
    let v551_14_tail = v551_14_cursor.make_map();
    v551_14_cursor.ascend(1);
    let v551_14_head = Path::from_slice(&[v551_14_byte]);
    let v552_2: Space = singleton(&(v551_14_head));
    let v552_3: Space = intersect(&(*CONSTANT_9),&(v552_2));
    let v552_4: Space = if has_head(&(v552_3)) { singleton(&[]) } else { Space::new() };
    drop(v552_3);
    let v552_5: Space = subtract(&(*CONSTANT_0),&(v552_4));
    drop(v552_4);
    let v552_8: Space = if (v552_5).is_empty() { Space::new() } else {
      let v553_6: Path = concat_path(&(*p0),&(v551_14_head));
      let v553_7: Space = routine_65(c, &(v553_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v551_14_tail));
      compose(&(v552_5),&(v553_7))
    };
    drop(v552_5);
    let v552_9: Space = intersect(&(*CONSTANT_9),&(v552_2));
    drop(v552_2);
    let v552_10: Space = if has_head(&(v552_9)) { singleton(&[]) } else { Space::new() };
    drop(v552_9);
    let v552_14: Space = if (v552_10).is_empty() { Space::new() } else {
      let v554_6: Path = concat_path(&(*p0),&(v551_14_head));
      let v554_11: Space = unwrap(&(v551_14_tail),&(*CONSTANT_6));
      let v554_12: Space = subtract(&(*CONSTANT_10),&(v554_11));
      drop(v554_11);
      let mut v554_13 = Space::new();
      let mut v554_13_cursor = (v554_12).read_zipper();
      for v554_13_byte in v554_13_cursor.child_mask().iter() {
        v554_13_cursor.descend_to_byte(v554_13_byte);
        let v554_13_tail = v554_13_cursor.make_map();
        v554_13_cursor.ascend(1);
        let v554_13_head = Path::from_slice(&[v554_13_byte]);
        let v555_2: Space = singleton(&(v554_13_head));
        let v555_3: Space = intersect(&(*CONSTANT_9),&(v555_2));
        let v555_4: Space = if has_head(&(v555_3)) { singleton(&[]) } else { Space::new() };
        drop(v555_3);
        let v555_5: Space = subtract(&(*CONSTANT_0),&(v555_4));
        drop(v555_4);
        let v555_7: Space = if (v555_5).is_empty() { Space::new() } else {
          let v556_6: Space = routine_67(c, &(v554_13_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v554_6), &(v554_13_tail), &(v551_14_tail));
          compose(&(v555_5),&(v556_6))
        };
        drop(v555_5);
        let v555_8: Space = intersect(&(*CONSTANT_9),&(v555_2));
        drop(v555_2);
        let v555_9: Space = if has_head(&(v555_8)) { singleton(&[]) } else { Space::new() };
        drop(v555_8);
        let v555_11: Space = if (v555_9).is_empty() { Space::new() } else {
          let v557_10: Space = routine_68(c, &(v554_13_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v554_6), &(v554_13_tail), &(v551_14_tail));
          compose(&(v555_9),&(v557_10))
        };
        drop(v555_9);
        let v555_12: Space = unite(&(v555_7),&(v555_11));
        v554_13.join_into((v555_12).clone());
      }
      drop(v554_13_cursor);
      drop(v554_6);
      drop(v554_12);
      compose(&(v552_10),&(v554_13))
    };
    drop(v552_10);
    let v552_15: Space = unite(&(v552_8),&(v552_14));
    v551_14.join_into((v552_15).clone());
  }
  drop(v551_14_cursor);
  (v551_14).clone()
}

fn routine_66(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let v558_8: Space = unwrap(&(*s0),&(*CONSTANT_6));
  let v558_9: Space = subtract(&(*CONSTANT_10),&(v558_8));
  drop(v558_8);
  let v558_14: Path = concat_path(&(*p1),&(*p2));
  let v558_15: Path = concat_path(&(v558_14),&(*p3));
  drop(v558_14);
  let v558_16: Path = concat_path(&(v558_15),&(*p4));
  drop(v558_15);
  let v558_17: Path = concat_path(&(v558_16),&(*p0));
  drop(v558_16);
  let mut v558_21 = Space::new();
  let mut v558_21_cursor = (v558_9).read_zipper();
  for v558_21_byte in v558_21_cursor.child_mask().iter() {
    v558_21_cursor.descend_to_byte(v558_21_byte);
    let v558_21_tail = v558_21_cursor.make_map();
    v558_21_cursor.ascend(1);
    let v558_21_head = Path::from_slice(&[v558_21_byte]);
    let v559_2: Space = singleton(&(v558_21_head));
    let v559_3: Space = intersect(&(*CONSTANT_9),&(v559_2));
    let v559_4: Space = if has_head(&(v559_3)) { singleton(&[]) } else { Space::new() };
    drop(v559_3);
    let v559_5: Space = subtract(&(*CONSTANT_0),&(v559_4));
    drop(v559_4);
    let v559_7: Space = if (v559_5).is_empty() { Space::new() } else {
      let mut v560_6 = Space::new();
      let mut v560_6_cursor = (v558_21_tail).read_zipper();
      for v560_6_byte in v560_6_cursor.child_mask().iter() {
        v560_6_cursor.descend_to_byte(v560_6_byte);
        let v560_6_tail = v560_6_cursor.make_map();
        v560_6_cursor.ascend(1);
        let v560_6_head = Path::from_slice(&[v560_6_byte]);
        let v561_2: Space = singleton(&(v560_6_head));
        let v561_3: Space = intersect(&(*CONSTANT_9),&(v561_2));
        let v561_4: Space = if has_head(&(v561_3)) { singleton(&[]) } else { Space::new() };
        drop(v561_3);
        let v561_5: Space = subtract(&(*CONSTANT_0),&(v561_4));
        drop(v561_4);
        let v561_8: Space = if (v561_5).is_empty() { Space::new() } else {
          let v562_6: Path = concat_path(&(v558_21_head),&(v560_6_head));
          let v562_7: Space = routine_67(c, &(v562_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v560_6_tail), &(*s0));
          compose(&(v561_5),&(v562_7))
        };
        drop(v561_5);
        let v561_9: Space = intersect(&(*CONSTANT_9),&(v561_2));
        drop(v561_2);
        let v561_10: Space = if has_head(&(v561_9)) { singleton(&[]) } else { Space::new() };
        drop(v561_9);
        let v561_12: Space = if (v561_10).is_empty() { Space::new() } else {
          let v563_6: Path = concat_path(&(v558_21_head),&(v560_6_head));
          let v563_11: Space = routine_68(c, &(v563_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v560_6_tail), &(*s0));
          drop(v563_6);
          compose(&(v561_10),&(v563_11))
        };
        drop(v561_10);
        let v561_13: Space = unite(&(v561_8),&(v561_12));
        v560_6.join_into((v561_13).clone());
      }
      drop(v560_6_cursor);
      compose(&(v559_5),&(v560_6))
    };
    drop(v559_5);
    let v559_8: Space = intersect(&(*CONSTANT_9),&(v559_2));
    drop(v559_2);
    let v559_9: Space = if has_head(&(v559_8)) { singleton(&[]) } else { Space::new() };
    drop(v559_8);
    let v559_12: Space = if (v559_9).is_empty() { Space::new() } else {
      let v564_10: Space = routine_35(c, &(v558_21_head), &(*CONSTANT_6), &(*CONSTANT_8));
      let v564_11: Space = unite(&(*s0),&(v564_10));
      compose(&(v559_9),&(v564_11))
    };
    drop(v559_9);
    let v559_13: Space = wrap(&(v559_12),&(v558_17));
    let v559_14: Space = wrap(&(v559_13),&(v558_21_head));
    let v559_15: Space = unite(&(v559_7),&(v559_14));
    v558_21.join_into((v559_15).clone());
  }
  drop(v558_21_cursor);
  drop(v558_9);
  drop(v558_17);
  (v558_21).clone()
}

fn routine_67(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space, s1: &Space) -> Space {
  let v565_13: Path = concat_path(&(*p1),&(*p2));
  let v565_14: Path = concat_path(&(v565_13),&(*p3));
  drop(v565_13);
  let v565_15: Path = concat_path(&(v565_14),&(*p4));
  drop(v565_14);
  let v565_16: Path = concat_path(&(v565_15),&(*p5));
  drop(v565_15);
  let mut v565_17 = Space::new();
  let mut v565_17_cursor = (*s0).read_zipper();
  for v565_17_byte in v565_17_cursor.child_mask().iter() {
    v565_17_cursor.descend_to_byte(v565_17_byte);
    let v565_17_tail = v565_17_cursor.make_map();
    v565_17_cursor.ascend(1);
    let v565_17_head = Path::from_slice(&[v565_17_byte]);
    let v566_2: Space = singleton(&(v565_17_head));
    let v566_3: Space = intersect(&(*CONSTANT_9),&(v566_2));
    let v566_4: Space = if has_head(&(v566_3)) { singleton(&[]) } else { Space::new() };
    drop(v566_3);
    let v566_5: Space = subtract(&(*CONSTANT_0),&(v566_4));
    drop(v566_4);
    let v566_8: Space = if (v566_5).is_empty() { Space::new() } else {
      let v567_6: Path = concat_path(&(*p0),&(v565_17_head));
      let v567_7: Space = routine_67(c, &(v567_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v565_17_tail), &(*s1));
      compose(&(v566_5),&(v567_7))
    };
    drop(v566_5);
    let v566_9: Space = intersect(&(*CONSTANT_9),&(v566_2));
    drop(v566_2);
    let v566_10: Space = if has_head(&(v566_9)) { singleton(&[]) } else { Space::new() };
    drop(v566_9);
    let v566_13: Space = if (v566_10).is_empty() { Space::new() } else {
      let v568_6: Path = concat_path(&(*p0),&(v565_17_head));
      let v568_11: Space = routine_35(c, &(v568_6), &(*CONSTANT_6), &(*CONSTANT_8));
      let v568_12: Space = unite(&(*s1),&(v568_11));
      compose(&(v566_10),&(v568_12))
    };
    drop(v566_10);
    let v566_14: Space = wrap(&(v566_13),&(v565_16));
    let v569_6: Path = concat_path(&(*p0),&(v565_17_head));
    let v566_15: Space = wrap(&(v566_14),&(v569_6));
    let v566_16: Space = unite(&(v566_8),&(v566_15));
    v565_17.join_into((v566_16).clone());
  }
  drop(v565_17_cursor);
  drop(v565_16);
  (v565_17).clone()
}

fn routine_68(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space, s1: &Space) -> Space {
  let v570_41: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v571_12: Space = routine_34(c, &(*CONSTANT_11), &(*CONSTANT_6), &(*p0), &(*CONSTANT_9));
    let v571_15: Space = routine_34(c, &(*CONSTANT_12), &(*CONSTANT_6), &(*p0), &(*CONSTANT_9));
    let v571_16: Space = unite(&(v571_12),&(v571_15));
    let v571_19: Space = routine_34(c, &(*CONSTANT_13), &(*CONSTANT_6), &(*p0), &(*CONSTANT_9));
    let v571_20: Space = unite(&(v571_16),&(v571_19));
    let v571_23: Space = routine_34(c, &(*CONSTANT_14), &(*CONSTANT_6), &(*p0), &(*CONSTANT_9));
    let v571_24: Space = unite(&(v571_20),&(v571_23));
    let v571_27: Space = routine_34(c, &(*CONSTANT_15), &(*CONSTANT_6), &(*p0), &(*CONSTANT_9));
    let v571_28: Space = unite(&(v571_24),&(v571_27));
    let v571_31: Space = routine_34(c, &(*CONSTANT_16), &(*CONSTANT_6), &(*p0), &(*CONSTANT_9));
    let v571_32: Space = unite(&(v571_28),&(v571_31));
    let v571_35: Space = routine_34(c, &(*CONSTANT_17), &(*CONSTANT_6), &(*p0), &(*CONSTANT_9));
    let v571_36: Space = unite(&(v571_32),&(v571_35));
    let v571_39: Space = routine_34(c, &(*CONSTANT_18), &(*CONSTANT_6), &(*p0), &(*CONSTANT_9));
    let v571_40: Space = unite(&(v571_36),&(v571_39));
    compose(&(*CONSTANT_0),&(v571_40))
  };
  let v570_43: Space = intersect(&(v570_41),&(*CONSTANT_19));
  let v570_44: Space = unite(&(v570_43),&(*s1));
  let v570_45: Path = concat_path(&(*p1),&(*p2));
  let v570_46: Path = concat_path(&(v570_45),&(*p3));
  drop(v570_45);
  let v570_47: Path = concat_path(&(v570_46),&(*p4));
  drop(v570_46);
  let v570_48: Path = concat_path(&(v570_47),&(*p5));
  drop(v570_47);
  let v570_49: Space = wrap(&(v570_44),&(v570_48));
  drop(v570_48);
  let v570_50: Space = wrap(&(v570_49),&(*p0));
  (v570_50).clone()
}

fn routine_69(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v572_12 = Space::new();
  let mut v572_12_cursor = (*s0).read_zipper();
  for v572_12_byte in v572_12_cursor.child_mask().iter() {
    v572_12_cursor.descend_to_byte(v572_12_byte);
    let v572_12_tail = v572_12_cursor.make_map();
    v572_12_cursor.ascend(1);
    let v572_12_head = Path::from_slice(&[v572_12_byte]);
    let v573_2: Space = singleton(&(v572_12_head));
    let v573_3: Space = intersect(&(*CONSTANT_9),&(v573_2));
    let v573_4: Space = if has_head(&(v573_3)) { singleton(&[]) } else { Space::new() };
    drop(v573_3);
    let v573_5: Space = subtract(&(*CONSTANT_0),&(v573_4));
    drop(v573_4);
    let v573_8: Space = if (v573_5).is_empty() { Space::new() } else {
      let v574_6: Path = concat_path(&(*p0),&(v572_12_head));
      let v574_7: Space = routine_69(c, &(v574_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v572_12_tail));
      compose(&(v573_5),&(v574_7))
    };
    drop(v573_5);
    let v573_9: Space = intersect(&(*CONSTANT_9),&(v573_2));
    drop(v573_2);
    let v573_10: Space = if has_head(&(v573_9)) { singleton(&[]) } else { Space::new() };
    drop(v573_9);
    let v573_12: Space = if (v573_10).is_empty() { Space::new() } else {
      let v575_6: Path = concat_path(&(*p0),&(v572_12_head));
      let mut v575_11 = Space::new();
      let mut v575_11_cursor = (v572_12_tail).read_zipper();
      for v575_11_byte in v575_11_cursor.child_mask().iter() {
        v575_11_cursor.descend_to_byte(v575_11_byte);
        let v575_11_tail = v575_11_cursor.make_map();
        v575_11_cursor.ascend(1);
        let v575_11_head = Path::from_slice(&[v575_11_byte]);
        let v576_2: Space = singleton(&(v575_11_head));
        let v576_3: Space = intersect(&(*CONSTANT_9),&(v576_2));
        let v576_4: Space = if has_head(&(v576_3)) { singleton(&[]) } else { Space::new() };
        drop(v576_3);
        let v576_5: Space = subtract(&(*CONSTANT_0),&(v576_4));
        drop(v576_4);
        let v576_7: Space = if (v576_5).is_empty() { Space::new() } else {
          let v577_6: Space = routine_71(c, &(v575_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v575_6), &(v575_11_tail));
          compose(&(v576_5),&(v577_6))
        };
        drop(v576_5);
        let v576_8: Space = intersect(&(*CONSTANT_9),&(v576_2));
        drop(v576_2);
        let v576_9: Space = if has_head(&(v576_8)) { singleton(&[]) } else { Space::new() };
        drop(v576_8);
        let v576_11: Space = if (v576_9).is_empty() { Space::new() } else {
          let v578_10: Space = routine_72(c, &(v575_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v575_6), &(v575_11_tail));
          compose(&(v576_9),&(v578_10))
        };
        drop(v576_9);
        let v576_12: Space = unite(&(v576_7),&(v576_11));
        v575_11.join_into((v576_12).clone());
      }
      drop(v575_11_cursor);
      drop(v575_6);
      compose(&(v573_10),&(v575_11))
    };
    drop(v573_10);
    let v573_13: Space = unite(&(v573_8),&(v573_12));
    v572_12.join_into((v573_13).clone());
  }
  drop(v572_12_cursor);
  (v572_12).clone()
}

fn routine_70(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v579_17 = Space::new();
  let mut v579_17_cursor = (*s0).read_zipper();
  for v579_17_byte in v579_17_cursor.child_mask().iter() {
    v579_17_cursor.descend_to_byte(v579_17_byte);
    let v579_17_tail = v579_17_cursor.make_map();
    v579_17_cursor.ascend(1);
    let v579_17_head = Path::from_slice(&[v579_17_byte]);
    let v580_2: Space = singleton(&(v579_17_head));
    let v580_3: Space = intersect(&(*CONSTANT_9),&(v580_2));
    let v580_4: Space = if has_head(&(v580_3)) { singleton(&[]) } else { Space::new() };
    drop(v580_3);
    let v580_5: Space = subtract(&(*CONSTANT_0),&(v580_4));
    drop(v580_4);
    let v580_7: Space = if (v580_5).is_empty() { Space::new() } else {
      let mut v581_6 = Space::new();
      let mut v581_6_cursor = (v579_17_tail).read_zipper();
      for v581_6_byte in v581_6_cursor.child_mask().iter() {
        v581_6_cursor.descend_to_byte(v581_6_byte);
        let v581_6_tail = v581_6_cursor.make_map();
        v581_6_cursor.ascend(1);
        let v581_6_head = Path::from_slice(&[v581_6_byte]);
        let v582_2: Space = singleton(&(v581_6_head));
        let v582_3: Space = intersect(&(*CONSTANT_9),&(v582_2));
        let v582_4: Space = if has_head(&(v582_3)) { singleton(&[]) } else { Space::new() };
        drop(v582_3);
        let v582_5: Space = subtract(&(*CONSTANT_0),&(v582_4));
        drop(v582_4);
        let v582_8: Space = if (v582_5).is_empty() { Space::new() } else {
          let v583_6: Path = concat_path(&(v579_17_head),&(v581_6_head));
          let v583_7: Space = routine_71(c, &(v583_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v581_6_tail));
          compose(&(v582_5),&(v583_7))
        };
        drop(v582_5);
        let v582_9: Space = intersect(&(*CONSTANT_9),&(v582_2));
        drop(v582_2);
        let v582_10: Space = if has_head(&(v582_9)) { singleton(&[]) } else { Space::new() };
        drop(v582_9);
        let v582_12: Space = if (v582_10).is_empty() { Space::new() } else {
          let v584_6: Path = concat_path(&(v579_17_head),&(v581_6_head));
          let v584_11: Space = routine_72(c, &(v584_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v581_6_tail));
          drop(v584_6);
          compose(&(v582_10),&(v584_11))
        };
        drop(v582_10);
        let v582_13: Space = unite(&(v582_8),&(v582_12));
        v581_6.join_into((v582_13).clone());
      }
      drop(v581_6_cursor);
      compose(&(v580_5),&(v581_6))
    };
    drop(v580_5);
    let v580_8: Space = intersect(&(*CONSTANT_9),&(v580_2));
    drop(v580_2);
    let v580_9: Space = if has_head(&(v580_8)) { singleton(&[]) } else { Space::new() };
    drop(v580_8);
    let v580_13: Space = if (v580_9).is_empty() { Space::new() } else {
      let v585_10: Space = unwrap(&(v579_17_tail),&(*CONSTANT_7));
      let v585_11: Space = subtract(&(*CONSTANT_10),&(v585_10));
      drop(v585_10);
      let mut v585_12 = Space::new();
      let mut v585_12_cursor = (v585_11).read_zipper();
      for v585_12_byte in v585_12_cursor.child_mask().iter() {
        v585_12_cursor.descend_to_byte(v585_12_byte);
        let v585_12_tail = v585_12_cursor.make_map();
        v585_12_cursor.ascend(1);
        let v585_12_head = Path::from_slice(&[v585_12_byte]);
        let v586_2: Space = singleton(&(v585_12_head));
        let v586_3: Space = intersect(&(*CONSTANT_9),&(v586_2));
        let v586_4: Space = if has_head(&(v586_3)) { singleton(&[]) } else { Space::new() };
        drop(v586_3);
        let v586_5: Space = subtract(&(*CONSTANT_0),&(v586_4));
        drop(v586_4);
        let v586_7: Space = if (v586_5).is_empty() { Space::new() } else {
          let v587_6: Space = routine_81(c, &(v585_12_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v579_17_head), &(v585_12_tail), &(v579_17_tail));
          compose(&(v586_5),&(v587_6))
        };
        drop(v586_5);
        let v586_8: Space = intersect(&(*CONSTANT_9),&(v586_2));
        drop(v586_2);
        let v586_9: Space = if has_head(&(v586_8)) { singleton(&[]) } else { Space::new() };
        drop(v586_8);
        let v586_11: Space = if (v586_9).is_empty() { Space::new() } else {
          let v588_10: Space = routine_82(c, &(v585_12_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v579_17_head), &(v585_12_tail), &(v579_17_tail));
          compose(&(v586_9),&(v588_10))
        };
        drop(v586_9);
        let v586_12: Space = unite(&(v586_7),&(v586_11));
        v585_12.join_into((v586_12).clone());
      }
      drop(v585_12_cursor);
      drop(v585_11);
      compose(&(v580_9),&(v585_12))
    };
    drop(v580_9);
    let v580_14: Space = unite(&(v580_7),&(v580_13));
    v579_17.join_into((v580_14).clone());
  }
  drop(v579_17_cursor);
  (v579_17).clone()
}

fn routine_71(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v589_15 = Space::new();
  let mut v589_15_cursor = (*s0).read_zipper();
  for v589_15_byte in v589_15_cursor.child_mask().iter() {
    v589_15_cursor.descend_to_byte(v589_15_byte);
    let v589_15_tail = v589_15_cursor.make_map();
    v589_15_cursor.ascend(1);
    let v589_15_head = Path::from_slice(&[v589_15_byte]);
    let v590_2: Space = singleton(&(v589_15_head));
    let v590_3: Space = intersect(&(*CONSTANT_9),&(v590_2));
    let v590_4: Space = if has_head(&(v590_3)) { singleton(&[]) } else { Space::new() };
    drop(v590_3);
    let v590_5: Space = subtract(&(*CONSTANT_0),&(v590_4));
    drop(v590_4);
    let v590_8: Space = if (v590_5).is_empty() { Space::new() } else {
      let v591_6: Path = concat_path(&(*p0),&(v589_15_head));
      let v591_7: Space = routine_71(c, &(v591_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v589_15_tail));
      compose(&(v590_5),&(v591_7))
    };
    drop(v590_5);
    let v590_9: Space = intersect(&(*CONSTANT_9),&(v590_2));
    drop(v590_2);
    let v590_10: Space = if has_head(&(v590_9)) { singleton(&[]) } else { Space::new() };
    drop(v590_9);
    let v590_14: Space = if (v590_10).is_empty() { Space::new() } else {
      let v592_6: Path = concat_path(&(*p0),&(v589_15_head));
      let v592_11: Space = unwrap(&(v589_15_tail),&(*CONSTANT_7));
      let v592_12: Space = subtract(&(*CONSTANT_10),&(v592_11));
      drop(v592_11);
      let mut v592_13 = Space::new();
      let mut v592_13_cursor = (v592_12).read_zipper();
      for v592_13_byte in v592_13_cursor.child_mask().iter() {
        v592_13_cursor.descend_to_byte(v592_13_byte);
        let v592_13_tail = v592_13_cursor.make_map();
        v592_13_cursor.ascend(1);
        let v592_13_head = Path::from_slice(&[v592_13_byte]);
        let v593_2: Space = singleton(&(v592_13_head));
        let v593_3: Space = intersect(&(*CONSTANT_9),&(v593_2));
        let v593_4: Space = if has_head(&(v593_3)) { singleton(&[]) } else { Space::new() };
        drop(v593_3);
        let v593_5: Space = subtract(&(*CONSTANT_0),&(v593_4));
        drop(v593_4);
        let v593_7: Space = if (v593_5).is_empty() { Space::new() } else {
          let v594_6: Space = routine_81(c, &(v592_13_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v592_6), &(v592_13_tail), &(v589_15_tail));
          compose(&(v593_5),&(v594_6))
        };
        drop(v593_5);
        let v593_8: Space = intersect(&(*CONSTANT_9),&(v593_2));
        drop(v593_2);
        let v593_9: Space = if has_head(&(v593_8)) { singleton(&[]) } else { Space::new() };
        drop(v593_8);
        let v593_11: Space = if (v593_9).is_empty() { Space::new() } else {
          let v595_10: Space = routine_82(c, &(v592_13_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v592_6), &(v592_13_tail), &(v589_15_tail));
          compose(&(v593_9),&(v595_10))
        };
        drop(v593_9);
        let v593_12: Space = unite(&(v593_7),&(v593_11));
        v592_13.join_into((v593_12).clone());
      }
      drop(v592_13_cursor);
      drop(v592_6);
      drop(v592_12);
      compose(&(v590_10),&(v592_13))
    };
    drop(v590_10);
    let v590_15: Space = unite(&(v590_8),&(v590_14));
    v589_15.join_into((v590_15).clone());
  }
  drop(v589_15_cursor);
  (v589_15).clone()
}

fn routine_72(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let v596_9: Space = unwrap(&(*s0),&(*CONSTANT_7));
  let v596_10: Space = subtract(&(*CONSTANT_10),&(v596_9));
  drop(v596_9);
  let v596_15: Path = concat_path(&(*p1),&(*p2));
  let v596_16: Path = concat_path(&(v596_15),&(*p3));
  drop(v596_15);
  let v596_17: Path = concat_path(&(v596_16),&(*p4));
  drop(v596_16);
  let v596_18: Path = concat_path(&(v596_17),&(*p5));
  drop(v596_17);
  let v596_19: Path = concat_path(&(v596_18),&(*p0));
  drop(v596_18);
  let mut v596_23 = Space::new();
  let mut v596_23_cursor = (v596_10).read_zipper();
  for v596_23_byte in v596_23_cursor.child_mask().iter() {
    v596_23_cursor.descend_to_byte(v596_23_byte);
    let v596_23_tail = v596_23_cursor.make_map();
    v596_23_cursor.ascend(1);
    let v596_23_head = Path::from_slice(&[v596_23_byte]);
    let v597_2: Space = singleton(&(v596_23_head));
    let v597_3: Space = intersect(&(*CONSTANT_9),&(v597_2));
    let v597_4: Space = if has_head(&(v597_3)) { singleton(&[]) } else { Space::new() };
    drop(v597_3);
    let v597_5: Space = subtract(&(*CONSTANT_0),&(v597_4));
    drop(v597_4);
    let v597_7: Space = if (v597_5).is_empty() { Space::new() } else {
      let mut v598_6 = Space::new();
      let mut v598_6_cursor = (v596_23_tail).read_zipper();
      for v598_6_byte in v598_6_cursor.child_mask().iter() {
        v598_6_cursor.descend_to_byte(v598_6_byte);
        let v598_6_tail = v598_6_cursor.make_map();
        v598_6_cursor.ascend(1);
        let v598_6_head = Path::from_slice(&[v598_6_byte]);
        let v599_2: Space = singleton(&(v598_6_head));
        let v599_3: Space = intersect(&(*CONSTANT_9),&(v599_2));
        let v599_4: Space = if has_head(&(v599_3)) { singleton(&[]) } else { Space::new() };
        drop(v599_3);
        let v599_5: Space = subtract(&(*CONSTANT_0),&(v599_4));
        drop(v599_4);
        let v599_8: Space = if (v599_5).is_empty() { Space::new() } else {
          let v600_6: Path = concat_path(&(v596_23_head),&(v598_6_head));
          let v600_7: Space = routine_81(c, &(v600_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v598_6_tail), &(*s0));
          compose(&(v599_5),&(v600_7))
        };
        drop(v599_5);
        let v599_9: Space = intersect(&(*CONSTANT_9),&(v599_2));
        drop(v599_2);
        let v599_10: Space = if has_head(&(v599_9)) { singleton(&[]) } else { Space::new() };
        drop(v599_9);
        let v599_12: Space = if (v599_10).is_empty() { Space::new() } else {
          let v601_6: Path = concat_path(&(v596_23_head),&(v598_6_head));
          let v601_11: Space = routine_82(c, &(v601_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v598_6_tail), &(*s0));
          drop(v601_6);
          compose(&(v599_10),&(v601_11))
        };
        drop(v599_10);
        let v599_13: Space = unite(&(v599_8),&(v599_12));
        v598_6.join_into((v599_13).clone());
      }
      drop(v598_6_cursor);
      compose(&(v597_5),&(v598_6))
    };
    drop(v597_5);
    let v597_8: Space = intersect(&(*CONSTANT_9),&(v597_2));
    drop(v597_2);
    let v597_9: Space = if has_head(&(v597_8)) { singleton(&[]) } else { Space::new() };
    drop(v597_8);
    let v597_12: Space = if (v597_9).is_empty() { Space::new() } else {
      let v602_10: Space = routine_35(c, &(v596_23_head), &(*CONSTANT_7), &(*CONSTANT_8));
      let v602_11: Space = unite(&(*s0),&(v602_10));
      compose(&(v597_9),&(v602_11))
    };
    drop(v597_9);
    let v597_13: Space = wrap(&(v597_12),&(v596_19));
    let v597_14: Space = wrap(&(v597_13),&(v596_23_head));
    let v597_15: Space = unite(&(v597_7),&(v597_14));
    v596_23.join_into((v597_15).clone());
  }
  drop(v596_23_cursor);
  drop(v596_10);
  drop(v596_19);
  (v596_23).clone()
}

fn routine_73(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v603_12 = Space::new();
  let mut v603_12_cursor = (*s0).read_zipper();
  for v603_12_byte in v603_12_cursor.child_mask().iter() {
    v603_12_cursor.descend_to_byte(v603_12_byte);
    let v603_12_tail = v603_12_cursor.make_map();
    v603_12_cursor.ascend(1);
    let v603_12_head = Path::from_slice(&[v603_12_byte]);
    let v604_2: Space = singleton(&(v603_12_head));
    let v604_3: Space = intersect(&(*CONSTANT_9),&(v604_2));
    let v604_4: Space = if has_head(&(v604_3)) { singleton(&[]) } else { Space::new() };
    drop(v604_3);
    let v604_5: Space = subtract(&(*CONSTANT_0),&(v604_4));
    drop(v604_4);
    let v604_8: Space = if (v604_5).is_empty() { Space::new() } else {
      let v605_6: Path = concat_path(&(*p0),&(v603_12_head));
      let v605_7: Space = routine_73(c, &(v605_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v603_12_tail));
      compose(&(v604_5),&(v605_7))
    };
    drop(v604_5);
    let v604_9: Space = intersect(&(*CONSTANT_9),&(v604_2));
    drop(v604_2);
    let v604_10: Space = if has_head(&(v604_9)) { singleton(&[]) } else { Space::new() };
    drop(v604_9);
    let v604_12: Space = if (v604_10).is_empty() { Space::new() } else {
      let v606_6: Path = concat_path(&(*p0),&(v603_12_head));
      let mut v606_11 = Space::new();
      let mut v606_11_cursor = (v603_12_tail).read_zipper();
      for v606_11_byte in v606_11_cursor.child_mask().iter() {
        v606_11_cursor.descend_to_byte(v606_11_byte);
        let v606_11_tail = v606_11_cursor.make_map();
        v606_11_cursor.ascend(1);
        let v606_11_head = Path::from_slice(&[v606_11_byte]);
        let v607_2: Space = singleton(&(v606_11_head));
        let v607_3: Space = intersect(&(*CONSTANT_9),&(v607_2));
        let v607_4: Space = if has_head(&(v607_3)) { singleton(&[]) } else { Space::new() };
        drop(v607_3);
        let v607_5: Space = subtract(&(*CONSTANT_0),&(v607_4));
        drop(v607_4);
        let v607_7: Space = if (v607_5).is_empty() { Space::new() } else {
          let v608_6: Space = routine_75(c, &(v606_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v606_6), &(v606_11_tail));
          compose(&(v607_5),&(v608_6))
        };
        drop(v607_5);
        let v607_8: Space = intersect(&(*CONSTANT_9),&(v607_2));
        drop(v607_2);
        let v607_9: Space = if has_head(&(v607_8)) { singleton(&[]) } else { Space::new() };
        drop(v607_8);
        let v607_11: Space = if (v607_9).is_empty() { Space::new() } else {
          let v609_10: Space = routine_76(c, &(v606_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v606_6), &(v606_11_tail));
          compose(&(v607_9),&(v609_10))
        };
        drop(v607_9);
        let v607_12: Space = unite(&(v607_7),&(v607_11));
        v606_11.join_into((v607_12).clone());
      }
      drop(v606_11_cursor);
      drop(v606_6);
      compose(&(v604_10),&(v606_11))
    };
    drop(v604_10);
    let v604_13: Space = unite(&(v604_8),&(v604_12));
    v603_12.join_into((v604_13).clone());
  }
  drop(v603_12_cursor);
  (v603_12).clone()
}

fn routine_74(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v610_15 = Space::new();
  let mut v610_15_cursor = (*s0).read_zipper();
  for v610_15_byte in v610_15_cursor.child_mask().iter() {
    v610_15_cursor.descend_to_byte(v610_15_byte);
    let v610_15_tail = v610_15_cursor.make_map();
    v610_15_cursor.ascend(1);
    let v610_15_head = Path::from_slice(&[v610_15_byte]);
    let v611_2: Space = singleton(&(v610_15_head));
    let v611_3: Space = intersect(&(*CONSTANT_9),&(v611_2));
    let v611_4: Space = if has_head(&(v611_3)) { singleton(&[]) } else { Space::new() };
    drop(v611_3);
    let v611_5: Space = subtract(&(*CONSTANT_0),&(v611_4));
    drop(v611_4);
    let v611_7: Space = if (v611_5).is_empty() { Space::new() } else {
      let mut v612_6 = Space::new();
      let mut v612_6_cursor = (v610_15_tail).read_zipper();
      for v612_6_byte in v612_6_cursor.child_mask().iter() {
        v612_6_cursor.descend_to_byte(v612_6_byte);
        let v612_6_tail = v612_6_cursor.make_map();
        v612_6_cursor.ascend(1);
        let v612_6_head = Path::from_slice(&[v612_6_byte]);
        let v613_2: Space = singleton(&(v612_6_head));
        let v613_3: Space = intersect(&(*CONSTANT_9),&(v613_2));
        let v613_4: Space = if has_head(&(v613_3)) { singleton(&[]) } else { Space::new() };
        drop(v613_3);
        let v613_5: Space = subtract(&(*CONSTANT_0),&(v613_4));
        drop(v613_4);
        let v613_8: Space = if (v613_5).is_empty() { Space::new() } else {
          let v614_6: Path = concat_path(&(v610_15_head),&(v612_6_head));
          let v614_7: Space = routine_75(c, &(v614_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v612_6_tail));
          compose(&(v613_5),&(v614_7))
        };
        drop(v613_5);
        let v613_9: Space = intersect(&(*CONSTANT_9),&(v613_2));
        drop(v613_2);
        let v613_10: Space = if has_head(&(v613_9)) { singleton(&[]) } else { Space::new() };
        drop(v613_9);
        let v613_12: Space = if (v613_10).is_empty() { Space::new() } else {
          let v615_6: Path = concat_path(&(v610_15_head),&(v612_6_head));
          let v615_11: Space = routine_76(c, &(v615_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v612_6_tail));
          drop(v615_6);
          compose(&(v613_10),&(v615_11))
        };
        drop(v613_10);
        let v613_13: Space = unite(&(v613_8),&(v613_12));
        v612_6.join_into((v613_13).clone());
      }
      drop(v612_6_cursor);
      compose(&(v611_5),&(v612_6))
    };
    drop(v611_5);
    let v611_8: Space = intersect(&(*CONSTANT_9),&(v611_2));
    drop(v611_2);
    let v611_9: Space = if has_head(&(v611_8)) { singleton(&[]) } else { Space::new() };
    drop(v611_8);
    let v611_11: Space = if (v611_9).is_empty() { Space::new() } else {
      let mut v616_10 = Space::new();
      let mut v616_10_cursor = (v610_15_tail).read_zipper();
      for v616_10_byte in v616_10_cursor.child_mask().iter() {
        v616_10_cursor.descend_to_byte(v616_10_byte);
        let v616_10_tail = v616_10_cursor.make_map();
        v616_10_cursor.ascend(1);
        let v616_10_head = Path::from_slice(&[v616_10_byte]);
        let v617_2: Space = singleton(&(v616_10_head));
        let v617_3: Space = intersect(&(*CONSTANT_9),&(v617_2));
        let v617_4: Space = if has_head(&(v617_3)) { singleton(&[]) } else { Space::new() };
        drop(v617_3);
        let v617_5: Space = subtract(&(*CONSTANT_0),&(v617_4));
        drop(v617_4);
        let v617_7: Space = if (v617_5).is_empty() { Space::new() } else {
          let v618_6: Space = routine_83(c, &(v616_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v610_15_head), &(v616_10_tail));
          compose(&(v617_5),&(v618_6))
        };
        drop(v617_5);
        let v617_8: Space = intersect(&(*CONSTANT_9),&(v617_2));
        drop(v617_2);
        let v617_9: Space = if has_head(&(v617_8)) { singleton(&[]) } else { Space::new() };
        drop(v617_8);
        let v617_11: Space = if (v617_9).is_empty() { Space::new() } else {
          let v619_10: Space = routine_84(c, &(v616_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v610_15_head), &(v616_10_tail));
          compose(&(v617_9),&(v619_10))
        };
        drop(v617_9);
        let v617_12: Space = unite(&(v617_7),&(v617_11));
        v616_10.join_into((v617_12).clone());
      }
      drop(v616_10_cursor);
      compose(&(v611_9),&(v616_10))
    };
    drop(v611_9);
    let v611_12: Space = unite(&(v611_7),&(v611_11));
    v610_15.join_into((v611_12).clone());
  }
  drop(v610_15_cursor);
  (v610_15).clone()
}

fn routine_75(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v620_13 = Space::new();
  let mut v620_13_cursor = (*s0).read_zipper();
  for v620_13_byte in v620_13_cursor.child_mask().iter() {
    v620_13_cursor.descend_to_byte(v620_13_byte);
    let v620_13_tail = v620_13_cursor.make_map();
    v620_13_cursor.ascend(1);
    let v620_13_head = Path::from_slice(&[v620_13_byte]);
    let v621_2: Space = singleton(&(v620_13_head));
    let v621_3: Space = intersect(&(*CONSTANT_9),&(v621_2));
    let v621_4: Space = if has_head(&(v621_3)) { singleton(&[]) } else { Space::new() };
    drop(v621_3);
    let v621_5: Space = subtract(&(*CONSTANT_0),&(v621_4));
    drop(v621_4);
    let v621_8: Space = if (v621_5).is_empty() { Space::new() } else {
      let v622_6: Path = concat_path(&(*p0),&(v620_13_head));
      let v622_7: Space = routine_75(c, &(v622_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v620_13_tail));
      compose(&(v621_5),&(v622_7))
    };
    drop(v621_5);
    let v621_9: Space = intersect(&(*CONSTANT_9),&(v621_2));
    drop(v621_2);
    let v621_10: Space = if has_head(&(v621_9)) { singleton(&[]) } else { Space::new() };
    drop(v621_9);
    let v621_12: Space = if (v621_10).is_empty() { Space::new() } else {
      let v623_6: Path = concat_path(&(*p0),&(v620_13_head));
      let mut v623_11 = Space::new();
      let mut v623_11_cursor = (v620_13_tail).read_zipper();
      for v623_11_byte in v623_11_cursor.child_mask().iter() {
        v623_11_cursor.descend_to_byte(v623_11_byte);
        let v623_11_tail = v623_11_cursor.make_map();
        v623_11_cursor.ascend(1);
        let v623_11_head = Path::from_slice(&[v623_11_byte]);
        let v624_2: Space = singleton(&(v623_11_head));
        let v624_3: Space = intersect(&(*CONSTANT_9),&(v624_2));
        let v624_4: Space = if has_head(&(v624_3)) { singleton(&[]) } else { Space::new() };
        drop(v624_3);
        let v624_5: Space = subtract(&(*CONSTANT_0),&(v624_4));
        drop(v624_4);
        let v624_7: Space = if (v624_5).is_empty() { Space::new() } else {
          let v625_6: Space = routine_83(c, &(v623_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v623_6), &(v623_11_tail));
          compose(&(v624_5),&(v625_6))
        };
        drop(v624_5);
        let v624_8: Space = intersect(&(*CONSTANT_9),&(v624_2));
        drop(v624_2);
        let v624_9: Space = if has_head(&(v624_8)) { singleton(&[]) } else { Space::new() };
        drop(v624_8);
        let v624_11: Space = if (v624_9).is_empty() { Space::new() } else {
          let v626_10: Space = routine_84(c, &(v623_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v623_6), &(v623_11_tail));
          compose(&(v624_9),&(v626_10))
        };
        drop(v624_9);
        let v624_12: Space = unite(&(v624_7),&(v624_11));
        v623_11.join_into((v624_12).clone());
      }
      drop(v623_11_cursor);
      drop(v623_6);
      compose(&(v621_10),&(v623_11))
    };
    drop(v621_10);
    let v621_13: Space = unite(&(v621_8),&(v621_12));
    v620_13.join_into((v621_13).clone());
  }
  drop(v620_13_cursor);
  (v620_13).clone()
}

fn routine_76(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v627_18 = Space::new();
  let mut v627_18_cursor = (*s0).read_zipper();
  for v627_18_byte in v627_18_cursor.child_mask().iter() {
    v627_18_cursor.descend_to_byte(v627_18_byte);
    let v627_18_tail = v627_18_cursor.make_map();
    v627_18_cursor.ascend(1);
    let v627_18_head = Path::from_slice(&[v627_18_byte]);
    let v628_2: Space = singleton(&(v627_18_head));
    let v628_3: Space = intersect(&(*CONSTANT_9),&(v628_2));
    let v628_4: Space = if has_head(&(v628_3)) { singleton(&[]) } else { Space::new() };
    drop(v628_3);
    let v628_5: Space = subtract(&(*CONSTANT_0),&(v628_4));
    drop(v628_4);
    let v628_7: Space = if (v628_5).is_empty() { Space::new() } else {
      let mut v629_6 = Space::new();
      let mut v629_6_cursor = (v627_18_tail).read_zipper();
      for v629_6_byte in v629_6_cursor.child_mask().iter() {
        v629_6_cursor.descend_to_byte(v629_6_byte);
        let v629_6_tail = v629_6_cursor.make_map();
        v629_6_cursor.ascend(1);
        let v629_6_head = Path::from_slice(&[v629_6_byte]);
        let v630_2: Space = singleton(&(v629_6_head));
        let v630_3: Space = intersect(&(*CONSTANT_9),&(v630_2));
        let v630_4: Space = if has_head(&(v630_3)) { singleton(&[]) } else { Space::new() };
        drop(v630_3);
        let v630_5: Space = subtract(&(*CONSTANT_0),&(v630_4));
        drop(v630_4);
        let v630_8: Space = if (v630_5).is_empty() { Space::new() } else {
          let v631_6: Path = concat_path(&(v627_18_head),&(v629_6_head));
          let v631_7: Space = routine_83(c, &(v631_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v629_6_tail));
          compose(&(v630_5),&(v631_7))
        };
        drop(v630_5);
        let v630_9: Space = intersect(&(*CONSTANT_9),&(v630_2));
        drop(v630_2);
        let v630_10: Space = if has_head(&(v630_9)) { singleton(&[]) } else { Space::new() };
        drop(v630_9);
        let v630_12: Space = if (v630_10).is_empty() { Space::new() } else {
          let v632_6: Path = concat_path(&(v627_18_head),&(v629_6_head));
          let v632_11: Space = routine_84(c, &(v632_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v629_6_tail));
          drop(v632_6);
          compose(&(v630_10),&(v632_11))
        };
        drop(v630_10);
        let v630_13: Space = unite(&(v630_8),&(v630_12));
        v629_6.join_into((v630_13).clone());
      }
      drop(v629_6_cursor);
      compose(&(v628_5),&(v629_6))
    };
    drop(v628_5);
    let v628_8: Space = intersect(&(*CONSTANT_9),&(v628_2));
    drop(v628_2);
    let v628_9: Space = if has_head(&(v628_8)) { singleton(&[]) } else { Space::new() };
    drop(v628_8);
    let v628_13: Space = if (v628_9).is_empty() { Space::new() } else {
      let v633_10: Space = unwrap(&(v627_18_tail),&(*CONSTANT_8));
      let v633_11: Space = subtract(&(*CONSTANT_10),&(v633_10));
      drop(v633_10);
      let mut v633_12 = Space::new();
      let mut v633_12_cursor = (v633_11).read_zipper();
      for v633_12_byte in v633_12_cursor.child_mask().iter() {
        v633_12_cursor.descend_to_byte(v633_12_byte);
        let v633_12_tail = v633_12_cursor.make_map();
        v633_12_cursor.ascend(1);
        let v633_12_head = Path::from_slice(&[v633_12_byte]);
        let v634_2: Space = singleton(&(v633_12_head));
        let v634_3: Space = intersect(&(*CONSTANT_9),&(v634_2));
        let v634_4: Space = if has_head(&(v634_3)) { singleton(&[]) } else { Space::new() };
        drop(v634_3);
        let v634_5: Space = subtract(&(*CONSTANT_0),&(v634_4));
        drop(v634_4);
        let v634_7: Space = if (v634_5).is_empty() { Space::new() } else {
          let v635_6: Space = routine_85(c, &(v633_12_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v627_18_head), &(v633_12_tail), &(v627_18_tail));
          compose(&(v634_5),&(v635_6))
        };
        drop(v634_5);
        let v634_8: Space = intersect(&(*CONSTANT_9),&(v634_2));
        drop(v634_2);
        let v634_9: Space = if has_head(&(v634_8)) { singleton(&[]) } else { Space::new() };
        drop(v634_8);
        let v634_11: Space = if (v634_9).is_empty() { Space::new() } else {
          let v636_10: Space = routine_86(c, &(v633_12_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v627_18_head), &(v633_12_tail), &(v627_18_tail));
          compose(&(v634_9),&(v636_10))
        };
        drop(v634_9);
        let v634_12: Space = unite(&(v634_7),&(v634_11));
        v633_12.join_into((v634_12).clone());
      }
      drop(v633_12_cursor);
      drop(v633_11);
      compose(&(v628_9),&(v633_12))
    };
    drop(v628_9);
    let v628_14: Space = unite(&(v628_7),&(v628_13));
    v627_18.join_into((v628_14).clone());
  }
  drop(v627_18_cursor);
  (v627_18).clone()
}

fn routine_77(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v637_12 = Space::new();
  let mut v637_12_cursor = (*s0).read_zipper();
  for v637_12_byte in v637_12_cursor.child_mask().iter() {
    v637_12_cursor.descend_to_byte(v637_12_byte);
    let v637_12_tail = v637_12_cursor.make_map();
    v637_12_cursor.ascend(1);
    let v637_12_head = Path::from_slice(&[v637_12_byte]);
    let v638_2: Space = singleton(&(v637_12_head));
    let v638_3: Space = intersect(&(*CONSTANT_9),&(v638_2));
    let v638_4: Space = if has_head(&(v638_3)) { singleton(&[]) } else { Space::new() };
    drop(v638_3);
    let v638_5: Space = subtract(&(*CONSTANT_0),&(v638_4));
    drop(v638_4);
    let v638_8: Space = if (v638_5).is_empty() { Space::new() } else {
      let v639_6: Path = concat_path(&(*p0),&(v637_12_head));
      let v639_7: Space = routine_77(c, &(v639_6), &(*p1), &(*p2), &(*p3), &(*p4), &(v637_12_tail));
      compose(&(v638_5),&(v639_7))
    };
    drop(v638_5);
    let v638_9: Space = intersect(&(*CONSTANT_9),&(v638_2));
    drop(v638_2);
    let v638_10: Space = if has_head(&(v638_9)) { singleton(&[]) } else { Space::new() };
    drop(v638_9);
    let v638_12: Space = if (v638_10).is_empty() { Space::new() } else {
      let v640_6: Path = concat_path(&(*p0),&(v637_12_head));
      let mut v640_11 = Space::new();
      let mut v640_11_cursor = (v637_12_tail).read_zipper();
      for v640_11_byte in v640_11_cursor.child_mask().iter() {
        v640_11_cursor.descend_to_byte(v640_11_byte);
        let v640_11_tail = v640_11_cursor.make_map();
        v640_11_cursor.ascend(1);
        let v640_11_head = Path::from_slice(&[v640_11_byte]);
        let v641_2: Space = singleton(&(v640_11_head));
        let v641_3: Space = intersect(&(*CONSTANT_9),&(v641_2));
        let v641_4: Space = if has_head(&(v641_3)) { singleton(&[]) } else { Space::new() };
        drop(v641_3);
        let v641_5: Space = subtract(&(*CONSTANT_0),&(v641_4));
        drop(v641_4);
        let v641_7: Space = if (v641_5).is_empty() { Space::new() } else {
          let v642_6: Space = routine_79(c, &(v640_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v640_6), &(v640_11_tail));
          compose(&(v641_5),&(v642_6))
        };
        drop(v641_5);
        let v641_8: Space = intersect(&(*CONSTANT_9),&(v641_2));
        drop(v641_2);
        let v641_9: Space = if has_head(&(v641_8)) { singleton(&[]) } else { Space::new() };
        drop(v641_8);
        let v641_11: Space = if (v641_9).is_empty() { Space::new() } else {
          let v643_10: Space = routine_80(c, &(v640_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(v640_6), &(v640_11_tail));
          compose(&(v641_9),&(v643_10))
        };
        drop(v641_9);
        let v641_12: Space = unite(&(v641_7),&(v641_11));
        v640_11.join_into((v641_12).clone());
      }
      drop(v640_11_cursor);
      drop(v640_6);
      compose(&(v638_10),&(v640_11))
    };
    drop(v638_10);
    let v638_13: Space = unite(&(v638_8),&(v638_12));
    v637_12.join_into((v638_13).clone());
  }
  drop(v637_12_cursor);
  (v637_12).clone()
}

fn routine_78(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v644_15 = Space::new();
  let mut v644_15_cursor = (*s0).read_zipper();
  for v644_15_byte in v644_15_cursor.child_mask().iter() {
    v644_15_cursor.descend_to_byte(v644_15_byte);
    let v644_15_tail = v644_15_cursor.make_map();
    v644_15_cursor.ascend(1);
    let v644_15_head = Path::from_slice(&[v644_15_byte]);
    let v645_2: Space = singleton(&(v644_15_head));
    let v645_3: Space = intersect(&(*CONSTANT_9),&(v645_2));
    let v645_4: Space = if has_head(&(v645_3)) { singleton(&[]) } else { Space::new() };
    drop(v645_3);
    let v645_5: Space = subtract(&(*CONSTANT_0),&(v645_4));
    drop(v645_4);
    let v645_7: Space = if (v645_5).is_empty() { Space::new() } else {
      let mut v646_6 = Space::new();
      let mut v646_6_cursor = (v644_15_tail).read_zipper();
      for v646_6_byte in v646_6_cursor.child_mask().iter() {
        v646_6_cursor.descend_to_byte(v646_6_byte);
        let v646_6_tail = v646_6_cursor.make_map();
        v646_6_cursor.ascend(1);
        let v646_6_head = Path::from_slice(&[v646_6_byte]);
        let v647_2: Space = singleton(&(v646_6_head));
        let v647_3: Space = intersect(&(*CONSTANT_9),&(v647_2));
        let v647_4: Space = if has_head(&(v647_3)) { singleton(&[]) } else { Space::new() };
        drop(v647_3);
        let v647_5: Space = subtract(&(*CONSTANT_0),&(v647_4));
        drop(v647_4);
        let v647_8: Space = if (v647_5).is_empty() { Space::new() } else {
          let v648_6: Path = concat_path(&(v644_15_head),&(v646_6_head));
          let v648_7: Space = routine_79(c, &(v648_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v646_6_tail));
          compose(&(v647_5),&(v648_7))
        };
        drop(v647_5);
        let v647_9: Space = intersect(&(*CONSTANT_9),&(v647_2));
        drop(v647_2);
        let v647_10: Space = if has_head(&(v647_9)) { singleton(&[]) } else { Space::new() };
        drop(v647_9);
        let v647_12: Space = if (v647_10).is_empty() { Space::new() } else {
          let v649_6: Path = concat_path(&(v644_15_head),&(v646_6_head));
          let v649_11: Space = routine_80(c, &(v649_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v646_6_tail));
          drop(v649_6);
          compose(&(v647_10),&(v649_11))
        };
        drop(v647_10);
        let v647_13: Space = unite(&(v647_8),&(v647_12));
        v646_6.join_into((v647_13).clone());
      }
      drop(v646_6_cursor);
      compose(&(v645_5),&(v646_6))
    };
    drop(v645_5);
    let v645_8: Space = intersect(&(*CONSTANT_9),&(v645_2));
    drop(v645_2);
    let v645_9: Space = if has_head(&(v645_8)) { singleton(&[]) } else { Space::new() };
    drop(v645_8);
    let v645_11: Space = if (v645_9).is_empty() { Space::new() } else {
      let mut v650_10 = Space::new();
      let mut v650_10_cursor = (v644_15_tail).read_zipper();
      for v650_10_byte in v650_10_cursor.child_mask().iter() {
        v650_10_cursor.descend_to_byte(v650_10_byte);
        let v650_10_tail = v650_10_cursor.make_map();
        v650_10_cursor.ascend(1);
        let v650_10_head = Path::from_slice(&[v650_10_byte]);
        let v651_2: Space = singleton(&(v650_10_head));
        let v651_3: Space = intersect(&(*CONSTANT_9),&(v651_2));
        let v651_4: Space = if has_head(&(v651_3)) { singleton(&[]) } else { Space::new() };
        drop(v651_3);
        let v651_5: Space = subtract(&(*CONSTANT_0),&(v651_4));
        drop(v651_4);
        let v651_7: Space = if (v651_5).is_empty() { Space::new() } else {
          let v652_6: Space = routine_87(c, &(v650_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v644_15_head), &(v650_10_tail));
          compose(&(v651_5),&(v652_6))
        };
        drop(v651_5);
        let v651_8: Space = intersect(&(*CONSTANT_9),&(v651_2));
        drop(v651_2);
        let v651_9: Space = if has_head(&(v651_8)) { singleton(&[]) } else { Space::new() };
        drop(v651_8);
        let v651_11: Space = if (v651_9).is_empty() { Space::new() } else {
          let v653_10: Space = routine_88(c, &(v650_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v644_15_head), &(v650_10_tail));
          compose(&(v651_9),&(v653_10))
        };
        drop(v651_9);
        let v651_12: Space = unite(&(v651_7),&(v651_11));
        v650_10.join_into((v651_12).clone());
      }
      drop(v650_10_cursor);
      compose(&(v645_9),&(v650_10))
    };
    drop(v645_9);
    let v645_12: Space = unite(&(v645_7),&(v645_11));
    v644_15.join_into((v645_12).clone());
  }
  drop(v644_15_cursor);
  (v644_15).clone()
}

fn routine_79(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v654_13 = Space::new();
  let mut v654_13_cursor = (*s0).read_zipper();
  for v654_13_byte in v654_13_cursor.child_mask().iter() {
    v654_13_cursor.descend_to_byte(v654_13_byte);
    let v654_13_tail = v654_13_cursor.make_map();
    v654_13_cursor.ascend(1);
    let v654_13_head = Path::from_slice(&[v654_13_byte]);
    let v655_2: Space = singleton(&(v654_13_head));
    let v655_3: Space = intersect(&(*CONSTANT_9),&(v655_2));
    let v655_4: Space = if has_head(&(v655_3)) { singleton(&[]) } else { Space::new() };
    drop(v655_3);
    let v655_5: Space = subtract(&(*CONSTANT_0),&(v655_4));
    drop(v655_4);
    let v655_8: Space = if (v655_5).is_empty() { Space::new() } else {
      let v656_6: Path = concat_path(&(*p0),&(v654_13_head));
      let v656_7: Space = routine_79(c, &(v656_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v654_13_tail));
      compose(&(v655_5),&(v656_7))
    };
    drop(v655_5);
    let v655_9: Space = intersect(&(*CONSTANT_9),&(v655_2));
    drop(v655_2);
    let v655_10: Space = if has_head(&(v655_9)) { singleton(&[]) } else { Space::new() };
    drop(v655_9);
    let v655_12: Space = if (v655_10).is_empty() { Space::new() } else {
      let v657_6: Path = concat_path(&(*p0),&(v654_13_head));
      let mut v657_11 = Space::new();
      let mut v657_11_cursor = (v654_13_tail).read_zipper();
      for v657_11_byte in v657_11_cursor.child_mask().iter() {
        v657_11_cursor.descend_to_byte(v657_11_byte);
        let v657_11_tail = v657_11_cursor.make_map();
        v657_11_cursor.ascend(1);
        let v657_11_head = Path::from_slice(&[v657_11_byte]);
        let v658_2: Space = singleton(&(v657_11_head));
        let v658_3: Space = intersect(&(*CONSTANT_9),&(v658_2));
        let v658_4: Space = if has_head(&(v658_3)) { singleton(&[]) } else { Space::new() };
        drop(v658_3);
        let v658_5: Space = subtract(&(*CONSTANT_0),&(v658_4));
        drop(v658_4);
        let v658_7: Space = if (v658_5).is_empty() { Space::new() } else {
          let v659_6: Space = routine_87(c, &(v657_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v657_6), &(v657_11_tail));
          compose(&(v658_5),&(v659_6))
        };
        drop(v658_5);
        let v658_8: Space = intersect(&(*CONSTANT_9),&(v658_2));
        drop(v658_2);
        let v658_9: Space = if has_head(&(v658_8)) { singleton(&[]) } else { Space::new() };
        drop(v658_8);
        let v658_11: Space = if (v658_9).is_empty() { Space::new() } else {
          let v660_10: Space = routine_88(c, &(v657_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(v657_6), &(v657_11_tail));
          compose(&(v658_9),&(v660_10))
        };
        drop(v658_9);
        let v658_12: Space = unite(&(v658_7),&(v658_11));
        v657_11.join_into((v658_12).clone());
      }
      drop(v657_11_cursor);
      drop(v657_6);
      compose(&(v655_10),&(v657_11))
    };
    drop(v655_10);
    let v655_13: Space = unite(&(v655_8),&(v655_12));
    v654_13.join_into((v655_13).clone());
  }
  drop(v654_13_cursor);
  (v654_13).clone()
}

fn routine_80(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v661_16 = Space::new();
  let mut v661_16_cursor = (*s0).read_zipper();
  for v661_16_byte in v661_16_cursor.child_mask().iter() {
    v661_16_cursor.descend_to_byte(v661_16_byte);
    let v661_16_tail = v661_16_cursor.make_map();
    v661_16_cursor.ascend(1);
    let v661_16_head = Path::from_slice(&[v661_16_byte]);
    let v662_2: Space = singleton(&(v661_16_head));
    let v662_3: Space = intersect(&(*CONSTANT_9),&(v662_2));
    let v662_4: Space = if has_head(&(v662_3)) { singleton(&[]) } else { Space::new() };
    drop(v662_3);
    let v662_5: Space = subtract(&(*CONSTANT_0),&(v662_4));
    drop(v662_4);
    let v662_7: Space = if (v662_5).is_empty() { Space::new() } else {
      let mut v663_6 = Space::new();
      let mut v663_6_cursor = (v661_16_tail).read_zipper();
      for v663_6_byte in v663_6_cursor.child_mask().iter() {
        v663_6_cursor.descend_to_byte(v663_6_byte);
        let v663_6_tail = v663_6_cursor.make_map();
        v663_6_cursor.ascend(1);
        let v663_6_head = Path::from_slice(&[v663_6_byte]);
        let v664_2: Space = singleton(&(v663_6_head));
        let v664_3: Space = intersect(&(*CONSTANT_9),&(v664_2));
        let v664_4: Space = if has_head(&(v664_3)) { singleton(&[]) } else { Space::new() };
        drop(v664_3);
        let v664_5: Space = subtract(&(*CONSTANT_0),&(v664_4));
        drop(v664_4);
        let v664_8: Space = if (v664_5).is_empty() { Space::new() } else {
          let v665_6: Path = concat_path(&(v661_16_head),&(v663_6_head));
          let v665_7: Space = routine_87(c, &(v665_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v663_6_tail));
          compose(&(v664_5),&(v665_7))
        };
        drop(v664_5);
        let v664_9: Space = intersect(&(*CONSTANT_9),&(v664_2));
        drop(v664_2);
        let v664_10: Space = if has_head(&(v664_9)) { singleton(&[]) } else { Space::new() };
        drop(v664_9);
        let v664_12: Space = if (v664_10).is_empty() { Space::new() } else {
          let v666_6: Path = concat_path(&(v661_16_head),&(v663_6_head));
          let v666_11: Space = routine_88(c, &(v666_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v663_6_tail));
          drop(v666_6);
          compose(&(v664_10),&(v666_11))
        };
        drop(v664_10);
        let v664_13: Space = unite(&(v664_8),&(v664_12));
        v663_6.join_into((v664_13).clone());
      }
      drop(v663_6_cursor);
      compose(&(v662_5),&(v663_6))
    };
    drop(v662_5);
    let v662_8: Space = intersect(&(*CONSTANT_9),&(v662_2));
    drop(v662_2);
    let v662_9: Space = if has_head(&(v662_8)) { singleton(&[]) } else { Space::new() };
    drop(v662_8);
    let v662_11: Space = if (v662_9).is_empty() { Space::new() } else {
      let mut v667_10 = Space::new();
      let mut v667_10_cursor = (v661_16_tail).read_zipper();
      for v667_10_byte in v667_10_cursor.child_mask().iter() {
        v667_10_cursor.descend_to_byte(v667_10_byte);
        let v667_10_tail = v667_10_cursor.make_map();
        v667_10_cursor.ascend(1);
        let v667_10_head = Path::from_slice(&[v667_10_byte]);
        let v668_2: Space = singleton(&(v667_10_head));
        let v668_3: Space = intersect(&(*CONSTANT_9),&(v668_2));
        let v668_4: Space = if has_head(&(v668_3)) { singleton(&[]) } else { Space::new() };
        drop(v668_3);
        let v668_5: Space = subtract(&(*CONSTANT_0),&(v668_4));
        drop(v668_4);
        let v668_7: Space = if (v668_5).is_empty() { Space::new() } else {
          let v669_6: Space = routine_89(c, &(v667_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v661_16_head), &(v667_10_tail));
          compose(&(v668_5),&(v669_6))
        };
        drop(v668_5);
        let v668_8: Space = intersect(&(*CONSTANT_9),&(v668_2));
        drop(v668_2);
        let v668_9: Space = if has_head(&(v668_8)) { singleton(&[]) } else { Space::new() };
        drop(v668_8);
        let v668_11: Space = if (v668_9).is_empty() { Space::new() } else {
          let v670_10: Space = routine_90(c, &(v667_10_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v661_16_head), &(v667_10_tail));
          compose(&(v668_9),&(v670_10))
        };
        drop(v668_9);
        let v668_12: Space = unite(&(v668_7),&(v668_11));
        v667_10.join_into((v668_12).clone());
      }
      drop(v667_10_cursor);
      compose(&(v662_9),&(v667_10))
    };
    drop(v662_9);
    let v662_12: Space = unite(&(v662_7),&(v662_11));
    v661_16.join_into((v662_12).clone());
  }
  drop(v661_16_cursor);
  (v661_16).clone()
}

fn routine_81(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space, s1: &Space) -> Space {
  let v671_14: Path = concat_path(&(*p1),&(*p2));
  let v671_15: Path = concat_path(&(v671_14),&(*p3));
  drop(v671_14);
  let v671_16: Path = concat_path(&(v671_15),&(*p4));
  drop(v671_15);
  let v671_17: Path = concat_path(&(v671_16),&(*p5));
  drop(v671_16);
  let v671_18: Path = concat_path(&(v671_17),&(*p6));
  drop(v671_17);
  let mut v671_19 = Space::new();
  let mut v671_19_cursor = (*s0).read_zipper();
  for v671_19_byte in v671_19_cursor.child_mask().iter() {
    v671_19_cursor.descend_to_byte(v671_19_byte);
    let v671_19_tail = v671_19_cursor.make_map();
    v671_19_cursor.ascend(1);
    let v671_19_head = Path::from_slice(&[v671_19_byte]);
    let v672_2: Space = singleton(&(v671_19_head));
    let v672_3: Space = intersect(&(*CONSTANT_9),&(v672_2));
    let v672_4: Space = if has_head(&(v672_3)) { singleton(&[]) } else { Space::new() };
    drop(v672_3);
    let v672_5: Space = subtract(&(*CONSTANT_0),&(v672_4));
    drop(v672_4);
    let v672_8: Space = if (v672_5).is_empty() { Space::new() } else {
      let v673_6: Path = concat_path(&(*p0),&(v671_19_head));
      let v673_7: Space = routine_81(c, &(v673_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v671_19_tail), &(*s1));
      compose(&(v672_5),&(v673_7))
    };
    drop(v672_5);
    let v672_9: Space = intersect(&(*CONSTANT_9),&(v672_2));
    drop(v672_2);
    let v672_10: Space = if has_head(&(v672_9)) { singleton(&[]) } else { Space::new() };
    drop(v672_9);
    let v672_13: Space = if (v672_10).is_empty() { Space::new() } else {
      let v674_6: Path = concat_path(&(*p0),&(v671_19_head));
      let v674_11: Space = routine_35(c, &(v674_6), &(*CONSTANT_7), &(*CONSTANT_8));
      let v674_12: Space = unite(&(*s1),&(v674_11));
      compose(&(v672_10),&(v674_12))
    };
    drop(v672_10);
    let v672_14: Space = wrap(&(v672_13),&(v671_18));
    let v675_6: Path = concat_path(&(*p0),&(v671_19_head));
    let v672_15: Space = wrap(&(v672_14),&(v675_6));
    let v672_16: Space = unite(&(v672_8),&(v672_15));
    v671_19.join_into((v672_16).clone());
  }
  drop(v671_19_cursor);
  drop(v671_18);
  (v671_19).clone()
}

fn routine_82(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space, s1: &Space) -> Space {
  let v676_42: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v677_13: Space = routine_34(c, &(*CONSTANT_11), &(*CONSTANT_7), &(*p0), &(*CONSTANT_9));
    let v677_16: Space = routine_34(c, &(*CONSTANT_12), &(*CONSTANT_7), &(*p0), &(*CONSTANT_9));
    let v677_17: Space = unite(&(v677_13),&(v677_16));
    let v677_20: Space = routine_34(c, &(*CONSTANT_13), &(*CONSTANT_7), &(*p0), &(*CONSTANT_9));
    let v677_21: Space = unite(&(v677_17),&(v677_20));
    let v677_24: Space = routine_34(c, &(*CONSTANT_14), &(*CONSTANT_7), &(*p0), &(*CONSTANT_9));
    let v677_25: Space = unite(&(v677_21),&(v677_24));
    let v677_28: Space = routine_34(c, &(*CONSTANT_15), &(*CONSTANT_7), &(*p0), &(*CONSTANT_9));
    let v677_29: Space = unite(&(v677_25),&(v677_28));
    let v677_32: Space = routine_34(c, &(*CONSTANT_16), &(*CONSTANT_7), &(*p0), &(*CONSTANT_9));
    let v677_33: Space = unite(&(v677_29),&(v677_32));
    let v677_36: Space = routine_34(c, &(*CONSTANT_17), &(*CONSTANT_7), &(*p0), &(*CONSTANT_9));
    let v677_37: Space = unite(&(v677_33),&(v677_36));
    let v677_40: Space = routine_34(c, &(*CONSTANT_18), &(*CONSTANT_7), &(*p0), &(*CONSTANT_9));
    let v677_41: Space = unite(&(v677_37),&(v677_40));
    compose(&(*CONSTANT_0),&(v677_41))
  };
  let v676_44: Space = intersect(&(v676_42),&(*CONSTANT_19));
  let v676_45: Space = unite(&(v676_44),&(*s1));
  let v676_46: Path = concat_path(&(*p1),&(*p2));
  let v676_47: Path = concat_path(&(v676_46),&(*p3));
  drop(v676_46);
  let v676_48: Path = concat_path(&(v676_47),&(*p4));
  drop(v676_47);
  let v676_49: Path = concat_path(&(v676_48),&(*p5));
  drop(v676_48);
  let v676_50: Path = concat_path(&(v676_49),&(*p6));
  drop(v676_49);
  let v676_51: Space = wrap(&(v676_45),&(v676_50));
  drop(v676_50);
  let v676_52: Space = wrap(&(v676_51),&(*p0));
  (v676_52).clone()
}

fn routine_83(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v678_16 = Space::new();
  let mut v678_16_cursor = (*s0).read_zipper();
  for v678_16_byte in v678_16_cursor.child_mask().iter() {
    v678_16_cursor.descend_to_byte(v678_16_byte);
    let v678_16_tail = v678_16_cursor.make_map();
    v678_16_cursor.ascend(1);
    let v678_16_head = Path::from_slice(&[v678_16_byte]);
    let v679_2: Space = singleton(&(v678_16_head));
    let v679_3: Space = intersect(&(*CONSTANT_9),&(v679_2));
    let v679_4: Space = if has_head(&(v679_3)) { singleton(&[]) } else { Space::new() };
    drop(v679_3);
    let v679_5: Space = subtract(&(*CONSTANT_0),&(v679_4));
    drop(v679_4);
    let v679_8: Space = if (v679_5).is_empty() { Space::new() } else {
      let v680_6: Path = concat_path(&(*p0),&(v678_16_head));
      let v680_7: Space = routine_83(c, &(v680_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v678_16_tail));
      compose(&(v679_5),&(v680_7))
    };
    drop(v679_5);
    let v679_9: Space = intersect(&(*CONSTANT_9),&(v679_2));
    drop(v679_2);
    let v679_10: Space = if has_head(&(v679_9)) { singleton(&[]) } else { Space::new() };
    drop(v679_9);
    let v679_14: Space = if (v679_10).is_empty() { Space::new() } else {
      let v681_6: Path = concat_path(&(*p0),&(v678_16_head));
      let v681_11: Space = unwrap(&(v678_16_tail),&(*CONSTANT_8));
      let v681_12: Space = subtract(&(*CONSTANT_10),&(v681_11));
      drop(v681_11);
      let mut v681_13 = Space::new();
      let mut v681_13_cursor = (v681_12).read_zipper();
      for v681_13_byte in v681_13_cursor.child_mask().iter() {
        v681_13_cursor.descend_to_byte(v681_13_byte);
        let v681_13_tail = v681_13_cursor.make_map();
        v681_13_cursor.ascend(1);
        let v681_13_head = Path::from_slice(&[v681_13_byte]);
        let v682_2: Space = singleton(&(v681_13_head));
        let v682_3: Space = intersect(&(*CONSTANT_9),&(v682_2));
        let v682_4: Space = if has_head(&(v682_3)) { singleton(&[]) } else { Space::new() };
        drop(v682_3);
        let v682_5: Space = subtract(&(*CONSTANT_0),&(v682_4));
        drop(v682_4);
        let v682_7: Space = if (v682_5).is_empty() { Space::new() } else {
          let v683_6: Space = routine_85(c, &(v681_13_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v681_6), &(v681_13_tail), &(v678_16_tail));
          compose(&(v682_5),&(v683_6))
        };
        drop(v682_5);
        let v682_8: Space = intersect(&(*CONSTANT_9),&(v682_2));
        drop(v682_2);
        let v682_9: Space = if has_head(&(v682_8)) { singleton(&[]) } else { Space::new() };
        drop(v682_8);
        let v682_11: Space = if (v682_9).is_empty() { Space::new() } else {
          let v684_10: Space = routine_86(c, &(v681_13_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v681_6), &(v681_13_tail), &(v678_16_tail));
          compose(&(v682_9),&(v684_10))
        };
        drop(v682_9);
        let v682_12: Space = unite(&(v682_7),&(v682_11));
        v681_13.join_into((v682_12).clone());
      }
      drop(v681_13_cursor);
      drop(v681_6);
      drop(v681_12);
      compose(&(v679_10),&(v681_13))
    };
    drop(v679_10);
    let v679_15: Space = unite(&(v679_8),&(v679_14));
    v678_16.join_into((v679_15).clone());
  }
  drop(v678_16_cursor);
  (v678_16).clone()
}

fn routine_84(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let v685_10: Space = unwrap(&(*s0),&(*CONSTANT_8));
  let v685_11: Space = subtract(&(*CONSTANT_10),&(v685_10));
  drop(v685_10);
  let v685_15: Path = concat_path(&(*p1),&(*p2));
  let v685_16: Path = concat_path(&(v685_15),&(*p3));
  drop(v685_15);
  let v685_17: Path = concat_path(&(v685_16),&(*p4));
  drop(v685_16);
  let v685_18: Path = concat_path(&(v685_17),&(*p5));
  drop(v685_17);
  let v685_19: Path = concat_path(&(v685_18),&(*p6));
  drop(v685_18);
  let v685_20: Path = concat_path(&(v685_19),&(*p0));
  drop(v685_19);
  let mut v685_24 = Space::new();
  let mut v685_24_cursor = (v685_11).read_zipper();
  for v685_24_byte in v685_24_cursor.child_mask().iter() {
    v685_24_cursor.descend_to_byte(v685_24_byte);
    let v685_24_tail = v685_24_cursor.make_map();
    v685_24_cursor.ascend(1);
    let v685_24_head = Path::from_slice(&[v685_24_byte]);
    let v686_2: Space = singleton(&(v685_24_head));
    let v686_3: Space = intersect(&(*CONSTANT_9),&(v686_2));
    let v686_4: Space = if has_head(&(v686_3)) { singleton(&[]) } else { Space::new() };
    drop(v686_3);
    let v686_5: Space = subtract(&(*CONSTANT_0),&(v686_4));
    drop(v686_4);
    let v686_7: Space = if (v686_5).is_empty() { Space::new() } else {
      let mut v687_6 = Space::new();
      let mut v687_6_cursor = (v685_24_tail).read_zipper();
      for v687_6_byte in v687_6_cursor.child_mask().iter() {
        v687_6_cursor.descend_to_byte(v687_6_byte);
        let v687_6_tail = v687_6_cursor.make_map();
        v687_6_cursor.ascend(1);
        let v687_6_head = Path::from_slice(&[v687_6_byte]);
        let v688_2: Space = singleton(&(v687_6_head));
        let v688_3: Space = intersect(&(*CONSTANT_9),&(v688_2));
        let v688_4: Space = if has_head(&(v688_3)) { singleton(&[]) } else { Space::new() };
        drop(v688_3);
        let v688_5: Space = subtract(&(*CONSTANT_0),&(v688_4));
        drop(v688_4);
        let v688_8: Space = if (v688_5).is_empty() { Space::new() } else {
          let v689_6: Path = concat_path(&(v685_24_head),&(v687_6_head));
          let v689_7: Space = routine_85(c, &(v689_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v687_6_tail), &(*s0));
          compose(&(v688_5),&(v689_7))
        };
        drop(v688_5);
        let v688_9: Space = intersect(&(*CONSTANT_9),&(v688_2));
        drop(v688_2);
        let v688_10: Space = if has_head(&(v688_9)) { singleton(&[]) } else { Space::new() };
        drop(v688_9);
        let v688_12: Space = if (v688_10).is_empty() { Space::new() } else {
          let v690_6: Path = concat_path(&(v685_24_head),&(v687_6_head));
          let v690_11: Space = routine_86(c, &(v690_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v687_6_tail), &(*s0));
          drop(v690_6);
          compose(&(v688_10),&(v690_11))
        };
        drop(v688_10);
        let v688_13: Space = unite(&(v688_8),&(v688_12));
        v687_6.join_into((v688_13).clone());
      }
      drop(v687_6_cursor);
      compose(&(v686_5),&(v687_6))
    };
    drop(v686_5);
    let v686_8: Space = intersect(&(*CONSTANT_9),&(v686_2));
    drop(v686_2);
    let v686_9: Space = if has_head(&(v686_8)) { singleton(&[]) } else { Space::new() };
    drop(v686_8);
    let v686_12: Space = if (v686_9).is_empty() { Space::new() } else {
      let v691_10: Space = routine_35(c, &(v685_24_head), &(*CONSTANT_8), &(*CONSTANT_8));
      let v691_11: Space = unite(&(*s0),&(v691_10));
      compose(&(v686_9),&(v691_11))
    };
    drop(v686_9);
    let v686_13: Space = wrap(&(v686_12),&(v685_20));
    let v686_14: Space = wrap(&(v686_13),&(v685_24_head));
    let v686_15: Space = unite(&(v686_7),&(v686_14));
    v685_24.join_into((v686_15).clone());
  }
  drop(v685_24_cursor);
  drop(v685_11);
  drop(v685_20);
  (v685_24).clone()
}

fn routine_85(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space, s1: &Space) -> Space {
  let v692_14: Path = concat_path(&(*p1),&(*p2));
  let v692_15: Path = concat_path(&(v692_14),&(*p3));
  drop(v692_14);
  let v692_16: Path = concat_path(&(v692_15),&(*p4));
  drop(v692_15);
  let v692_17: Path = concat_path(&(v692_16),&(*p5));
  drop(v692_16);
  let v692_18: Path = concat_path(&(v692_17),&(*p6));
  drop(v692_17);
  let v692_19: Path = concat_path(&(v692_18),&(*p7));
  drop(v692_18);
  let mut v692_20 = Space::new();
  let mut v692_20_cursor = (*s0).read_zipper();
  for v692_20_byte in v692_20_cursor.child_mask().iter() {
    v692_20_cursor.descend_to_byte(v692_20_byte);
    let v692_20_tail = v692_20_cursor.make_map();
    v692_20_cursor.ascend(1);
    let v692_20_head = Path::from_slice(&[v692_20_byte]);
    let v693_2: Space = singleton(&(v692_20_head));
    let v693_3: Space = intersect(&(*CONSTANT_9),&(v693_2));
    let v693_4: Space = if has_head(&(v693_3)) { singleton(&[]) } else { Space::new() };
    drop(v693_3);
    let v693_5: Space = subtract(&(*CONSTANT_0),&(v693_4));
    drop(v693_4);
    let v693_8: Space = if (v693_5).is_empty() { Space::new() } else {
      let v694_6: Path = concat_path(&(*p0),&(v692_20_head));
      let v694_7: Space = routine_85(c, &(v694_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v692_20_tail), &(*s1));
      compose(&(v693_5),&(v694_7))
    };
    drop(v693_5);
    let v693_9: Space = intersect(&(*CONSTANT_9),&(v693_2));
    drop(v693_2);
    let v693_10: Space = if has_head(&(v693_9)) { singleton(&[]) } else { Space::new() };
    drop(v693_9);
    let v693_13: Space = if (v693_10).is_empty() { Space::new() } else {
      let v695_6: Path = concat_path(&(*p0),&(v692_20_head));
      let v695_11: Space = routine_35(c, &(v695_6), &(*CONSTANT_8), &(*CONSTANT_8));
      let v695_12: Space = unite(&(*s1),&(v695_11));
      compose(&(v693_10),&(v695_12))
    };
    drop(v693_10);
    let v693_14: Space = wrap(&(v693_13),&(v692_19));
    let v696_6: Path = concat_path(&(*p0),&(v692_20_head));
    let v693_15: Space = wrap(&(v693_14),&(v696_6));
    let v693_16: Space = unite(&(v693_8),&(v693_15));
    v692_20.join_into((v693_16).clone());
  }
  drop(v692_20_cursor);
  drop(v692_19);
  (v692_20).clone()
}

fn routine_86(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space, s1: &Space) -> Space {
  let v697_43: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v698_14: Space = routine_34(c, &(*CONSTANT_11), &(*CONSTANT_8), &(*p0), &(*CONSTANT_9));
    let v698_17: Space = routine_34(c, &(*CONSTANT_12), &(*CONSTANT_8), &(*p0), &(*CONSTANT_9));
    let v698_18: Space = unite(&(v698_14),&(v698_17));
    let v698_21: Space = routine_34(c, &(*CONSTANT_13), &(*CONSTANT_8), &(*p0), &(*CONSTANT_9));
    let v698_22: Space = unite(&(v698_18),&(v698_21));
    let v698_25: Space = routine_34(c, &(*CONSTANT_14), &(*CONSTANT_8), &(*p0), &(*CONSTANT_9));
    let v698_26: Space = unite(&(v698_22),&(v698_25));
    let v698_29: Space = routine_34(c, &(*CONSTANT_15), &(*CONSTANT_8), &(*p0), &(*CONSTANT_9));
    let v698_30: Space = unite(&(v698_26),&(v698_29));
    let v698_33: Space = routine_34(c, &(*CONSTANT_16), &(*CONSTANT_8), &(*p0), &(*CONSTANT_9));
    let v698_34: Space = unite(&(v698_30),&(v698_33));
    let v698_37: Space = routine_34(c, &(*CONSTANT_17), &(*CONSTANT_8), &(*p0), &(*CONSTANT_9));
    let v698_38: Space = unite(&(v698_34),&(v698_37));
    let v698_41: Space = routine_34(c, &(*CONSTANT_18), &(*CONSTANT_8), &(*p0), &(*CONSTANT_9));
    let v698_42: Space = unite(&(v698_38),&(v698_41));
    compose(&(*CONSTANT_0),&(v698_42))
  };
  let v697_45: Space = intersect(&(v697_43),&(*CONSTANT_19));
  let v697_46: Space = unite(&(v697_45),&(*s1));
  let v697_47: Path = concat_path(&(*p1),&(*p2));
  let v697_48: Path = concat_path(&(v697_47),&(*p3));
  drop(v697_47);
  let v697_49: Path = concat_path(&(v697_48),&(*p4));
  drop(v697_48);
  let v697_50: Path = concat_path(&(v697_49),&(*p5));
  drop(v697_49);
  let v697_51: Path = concat_path(&(v697_50),&(*p6));
  drop(v697_50);
  let v697_52: Path = concat_path(&(v697_51),&(*p7));
  drop(v697_51);
  let v697_53: Space = wrap(&(v697_46),&(v697_52));
  drop(v697_52);
  let v697_54: Space = wrap(&(v697_53),&(*p0));
  (v697_54).clone()
}

fn routine_87(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v699_14 = Space::new();
  let mut v699_14_cursor = (*s0).read_zipper();
  for v699_14_byte in v699_14_cursor.child_mask().iter() {
    v699_14_cursor.descend_to_byte(v699_14_byte);
    let v699_14_tail = v699_14_cursor.make_map();
    v699_14_cursor.ascend(1);
    let v699_14_head = Path::from_slice(&[v699_14_byte]);
    let v700_2: Space = singleton(&(v699_14_head));
    let v700_3: Space = intersect(&(*CONSTANT_9),&(v700_2));
    let v700_4: Space = if has_head(&(v700_3)) { singleton(&[]) } else { Space::new() };
    drop(v700_3);
    let v700_5: Space = subtract(&(*CONSTANT_0),&(v700_4));
    drop(v700_4);
    let v700_8: Space = if (v700_5).is_empty() { Space::new() } else {
      let v701_6: Path = concat_path(&(*p0),&(v699_14_head));
      let v701_7: Space = routine_87(c, &(v701_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v699_14_tail));
      compose(&(v700_5),&(v701_7))
    };
    drop(v700_5);
    let v700_9: Space = intersect(&(*CONSTANT_9),&(v700_2));
    drop(v700_2);
    let v700_10: Space = if has_head(&(v700_9)) { singleton(&[]) } else { Space::new() };
    drop(v700_9);
    let v700_12: Space = if (v700_10).is_empty() { Space::new() } else {
      let v702_6: Path = concat_path(&(*p0),&(v699_14_head));
      let mut v702_11 = Space::new();
      let mut v702_11_cursor = (v699_14_tail).read_zipper();
      for v702_11_byte in v702_11_cursor.child_mask().iter() {
        v702_11_cursor.descend_to_byte(v702_11_byte);
        let v702_11_tail = v702_11_cursor.make_map();
        v702_11_cursor.ascend(1);
        let v702_11_head = Path::from_slice(&[v702_11_byte]);
        let v703_2: Space = singleton(&(v702_11_head));
        let v703_3: Space = intersect(&(*CONSTANT_9),&(v703_2));
        let v703_4: Space = if has_head(&(v703_3)) { singleton(&[]) } else { Space::new() };
        drop(v703_3);
        let v703_5: Space = subtract(&(*CONSTANT_0),&(v703_4));
        drop(v703_4);
        let v703_7: Space = if (v703_5).is_empty() { Space::new() } else {
          let v704_6: Space = routine_89(c, &(v702_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v702_6), &(v702_11_tail));
          compose(&(v703_5),&(v704_6))
        };
        drop(v703_5);
        let v703_8: Space = intersect(&(*CONSTANT_9),&(v703_2));
        drop(v703_2);
        let v703_9: Space = if has_head(&(v703_8)) { singleton(&[]) } else { Space::new() };
        drop(v703_8);
        let v703_11: Space = if (v703_9).is_empty() { Space::new() } else {
          let v705_10: Space = routine_90(c, &(v702_11_head), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(v702_6), &(v702_11_tail));
          compose(&(v703_9),&(v705_10))
        };
        drop(v703_9);
        let v703_12: Space = unite(&(v703_7),&(v703_11));
        v702_11.join_into((v703_12).clone());
      }
      drop(v702_11_cursor);
      drop(v702_6);
      compose(&(v700_10),&(v702_11))
    };
    drop(v700_10);
    let v700_13: Space = unite(&(v700_8),&(v700_12));
    v699_14.join_into((v700_13).clone());
  }
  drop(v699_14_cursor);
  (v699_14).clone()
}

fn routine_88(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let v706_11: Path = concat_path(&(*p1),&(*p2));
  let v706_12: Path = concat_path(&(v706_11),&(*p3));
  drop(v706_11);
  let v706_13: Path = concat_path(&(v706_12),&(*p4));
  drop(v706_12);
  let v706_14: Path = concat_path(&(v706_13),&(*p5));
  drop(v706_13);
  let v706_15: Path = concat_path(&(v706_14),&(*p6));
  drop(v706_14);
  let v706_16: Path = concat_path(&(v706_15),&(*p0));
  drop(v706_15);
  let mut v706_20 = Space::new();
  let mut v706_20_cursor = (*s0).read_zipper();
  for v706_20_byte in v706_20_cursor.child_mask().iter() {
    v706_20_cursor.descend_to_byte(v706_20_byte);
    let v706_20_tail = v706_20_cursor.make_map();
    v706_20_cursor.ascend(1);
    let v706_20_head = Path::from_slice(&[v706_20_byte]);
    let v707_2: Space = singleton(&(v706_20_head));
    let v707_3: Space = intersect(&(*CONSTANT_9),&(v707_2));
    let v707_4: Space = if has_head(&(v707_3)) { singleton(&[]) } else { Space::new() };
    drop(v707_3);
    let v707_5: Space = subtract(&(*CONSTANT_0),&(v707_4));
    drop(v707_4);
    let v707_7: Space = if (v707_5).is_empty() { Space::new() } else {
      let mut v708_6 = Space::new();
      let mut v708_6_cursor = (v706_20_tail).read_zipper();
      for v708_6_byte in v708_6_cursor.child_mask().iter() {
        v708_6_cursor.descend_to_byte(v708_6_byte);
        let v708_6_tail = v708_6_cursor.make_map();
        v708_6_cursor.ascend(1);
        let v708_6_head = Path::from_slice(&[v708_6_byte]);
        let v709_2: Space = singleton(&(v708_6_head));
        let v709_3: Space = intersect(&(*CONSTANT_9),&(v709_2));
        let v709_4: Space = if has_head(&(v709_3)) { singleton(&[]) } else { Space::new() };
        drop(v709_3);
        let v709_5: Space = subtract(&(*CONSTANT_0),&(v709_4));
        drop(v709_4);
        let v709_8: Space = if (v709_5).is_empty() { Space::new() } else {
          let v710_6: Path = concat_path(&(v706_20_head),&(v708_6_head));
          let v710_7: Space = routine_89(c, &(v710_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v708_6_tail));
          compose(&(v709_5),&(v710_7))
        };
        drop(v709_5);
        let v709_9: Space = intersect(&(*CONSTANT_9),&(v709_2));
        drop(v709_2);
        let v709_10: Space = if has_head(&(v709_9)) { singleton(&[]) } else { Space::new() };
        drop(v709_9);
        let v709_12: Space = if (v709_10).is_empty() { Space::new() } else {
          let v711_6: Path = concat_path(&(v706_20_head),&(v708_6_head));
          let v711_11: Space = routine_90(c, &(v711_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v708_6_tail));
          drop(v711_6);
          compose(&(v709_10),&(v711_11))
        };
        drop(v709_10);
        let v709_13: Space = unite(&(v709_8),&(v709_12));
        v708_6.join_into((v709_13).clone());
      }
      drop(v708_6_cursor);
      compose(&(v707_5),&(v708_6))
    };
    drop(v707_5);
    let v707_8: Space = intersect(&(*CONSTANT_9),&(v707_2));
    drop(v707_2);
    let v707_9: Space = if has_head(&(v707_8)) { singleton(&[]) } else { Space::new() };
    drop(v707_8);
    let v707_12: Space = if (v707_9).is_empty() { Space::new() } else {
      let v712_10: Path = concat_path(&(v706_16),&(v706_20_head));
      let v712_11: Space = singleton(&(v712_10));
      drop(v712_10);
      compose(&(v707_9),&(v712_11))
    };
    drop(v707_9);
    let v707_13: Space = unite(&(v707_7),&(v707_12));
    drop(v707_12);
    v706_20.join_into((v707_13).clone());
  }
  drop(v706_20_cursor);
  drop(v706_16);
  (v706_20).clone()
}

fn routine_89(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v713_12: Path = concat_path(&(*p1),&(*p2));
  let v713_13: Path = concat_path(&(v713_12),&(*p3));
  drop(v713_12);
  let v713_14: Path = concat_path(&(v713_13),&(*p4));
  drop(v713_13);
  let v713_15: Path = concat_path(&(v713_14),&(*p5));
  drop(v713_14);
  let v713_16: Path = concat_path(&(v713_15),&(*p6));
  drop(v713_15);
  let v713_17: Path = concat_path(&(v713_16),&(*p7));
  drop(v713_16);
  let mut v713_18 = Space::new();
  let mut v713_18_cursor = (*s0).read_zipper();
  for v713_18_byte in v713_18_cursor.child_mask().iter() {
    v713_18_cursor.descend_to_byte(v713_18_byte);
    let v713_18_tail = v713_18_cursor.make_map();
    v713_18_cursor.ascend(1);
    let v713_18_head = Path::from_slice(&[v713_18_byte]);
    let v714_2: Space = singleton(&(v713_18_head));
    let v714_3: Space = intersect(&(*CONSTANT_9),&(v714_2));
    let v714_4: Space = if has_head(&(v714_3)) { singleton(&[]) } else { Space::new() };
    drop(v714_3);
    let v714_5: Space = subtract(&(*CONSTANT_0),&(v714_4));
    drop(v714_4);
    let v714_8: Space = if (v714_5).is_empty() { Space::new() } else {
      let v715_6: Path = concat_path(&(*p0),&(v713_18_head));
      let v715_7: Space = routine_89(c, &(v715_6), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(v713_18_tail));
      compose(&(v714_5),&(v715_7))
    };
    drop(v714_5);
    let v714_9: Space = intersect(&(*CONSTANT_9),&(v714_2));
    drop(v714_2);
    let v714_10: Space = if has_head(&(v714_9)) { singleton(&[]) } else { Space::new() };
    drop(v714_9);
    let v714_13: Space = if (v714_10).is_empty() { Space::new() } else {
      let v716_6: Path = concat_path(&(*p0),&(v713_18_head));
      let v716_11: Path = concat_path(&(v713_17),&(v716_6));
      drop(v716_6);
      let v716_12: Space = singleton(&(v716_11));
      drop(v716_11);
      compose(&(v714_10),&(v716_12))
    };
    drop(v714_10);
    let v714_14: Space = unite(&(v714_8),&(v714_13));
    drop(v714_13);
    v713_18.join_into((v714_14).clone());
  }
  drop(v713_18_cursor);
  drop(v713_17);
  (v713_18).clone()
}

fn routine_90(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v717_9: Path = concat_path(&(*p1),&(*p2));
  let v717_10: Path = concat_path(&(v717_9),&(*p3));
  drop(v717_9);
  let v717_11: Path = concat_path(&(v717_10),&(*p4));
  drop(v717_10);
  let v717_12: Path = concat_path(&(v717_11),&(*p5));
  drop(v717_11);
  let v717_13: Path = concat_path(&(v717_12),&(*p6));
  drop(v717_12);
  let v717_14: Path = concat_path(&(v717_13),&(*p7));
  drop(v717_13);
  let v717_15: Path = concat_path(&(v717_14),&(*p0));
  drop(v717_14);
  let v717_16: Space = singleton(&(v717_15));
  drop(v717_15);
  (v717_16).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
