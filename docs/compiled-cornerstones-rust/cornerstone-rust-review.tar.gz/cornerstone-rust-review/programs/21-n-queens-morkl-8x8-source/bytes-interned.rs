#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,7]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,3]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,6]));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 4 0 0 0 0 4 0 0 0 1 4 0 0 0 2 4 0 0 0 3 4 0 0 0 4 4 0 0 0 5 4 0 0 0 6 4 0 0 0 7"));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 8 0 0 0 0 0 0 0 0 8 0 0 0 1 0 0 0 0 8 0 0 0 1 0 0 0 1 8 0 0 0 2 0 0 0 0 8 0 0 0 2 0 0 0 1 8 0 0 0 2 0 0 0 2 8 0 0 0 3 0 0 0 0 8 0 0 0 3 0 0 0 1 8 0 0 0 3 0 0 0 2 8 0 0 0 3 0 0 0 3 8 0 0 0 4 0 0 0 0 8 0 0 0 4 0 0 0 1 8 0 0 0 4 0 0 0 2 8 0 0 0 4 0 0 0 3 8 0 0 0 4 0 0 0 4 8 0 0 0 5 0 0 0 0 8 0 0 0 5 0 0 0 1 8 0 0 0 5 0 0 0 2 8 0 0 0 5 0 0 0 3 8 0 0 0 5 0 0 0 4 8 0 0 0 5 0 0 0 5 8 0 0 0 6 0 0 0 0 8 0 0 0 6 0 0 0 1 8 0 0 0 6 0 0 0 2 8 0 0 0 6 0 0 0 3 8 0 0 0 6 0 0 0 4 8 0 0 0 6 0 0 0 5 8 0 0 0 6 0 0 0 6 8 0 0 0 7 0 0 0 0 8 0 0 0 7 0 0 0 1 8 0 0 0 7 0 0 0 2 8 0 0 0 7 0 0 0 3 8 0 0 0 7 0 0 0 4 8 0 0 0 7 0 0 0 5 8 0 0 0 7 0 0 0 6 8 0 0 0 7 0 0 0 7"));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("100 12 0 0 0 0 0 0 0 0 0 0 0 1 12 0 0 0 0 0 0 0 0 0 0 0 16 12 0 0 0 0 0 0 0 1 0 0 0 2 12 0 0 0 0 0 0 0 2 0 0 0 3 12 0 0 0 0 0 0 0 3 0 0 0 4 12 0 0 0 0 0 0 0 4 0 0 0 5 12 0 0 0 0 0 0 0 5 0 0 0 6 12 0 0 0 0 0 0 0 6 0 0 0 7 12 0 0 0 0 0 0 0 7 0 0 0 8 12 0 0 0 1 0 0 0 0 0 0 0 0 12 0 0 0 1 0 0 0 0 0 0 0 2 12 0 0 0 1 0 0 0 1 0 0 0 3 12 0 0 0 1 0 0 0 1 0 0 0 16 12 0 0 0 1 0 0 0 2 0 0 0 4 12 0 0 0 1 0 0 0 3 0 0 0 5 12 0 0 0 1 0 0 0 4 0 0 0 6 12 0 0 0 1 0 0 0 5 0 0 0 7 12 0 0 0 1 0 0 0 6 0 0 0 8 12 0 0 0 1 0 0 0 7 0 0 0 9 12 0 0 0 2 0 0 0 0 0 0 0 1 12 0 0 0 2 0 0 0 0 0 0 0 3 12 0 0 0 2 0 0 0 1 0 0 0 0 12 0 0 0 2 0 0 0 1 0 0 0 4 12 0 0 0 2 0 0 0 2 0 0 0 5 12 0 0 0 2 0 0 0 2 0 0 0 16 12 0 0 0 2 0 0 0 3 0 0 0 6 12 0 0 0 2 0 0 0 4 0 0 0 7 12 0 0 0 2 0 0 0 5 0 0 0 8 12 0 0 0 2 0 0 0 6 0 0 0 9 12 0 0 0 2 0 0 0 7 0 0 0 10 12 0 0 0 3 0 0 0 0 0 0 0 2 12 0 0 0 3 0 0 0 0 0 0 0 4 12 0 0 0 3 0 0 0 1 0 0 0 1 12 0 0 0 3 0 0 0 1 0 0 0 5 12 0 0 0 3 0 0 0 2 0 0 0 0 12 0 0 0 3 0 0 0 2 0 0 0 6 12 0 0 0 3 0 0 0 3 0 0 0 7 12 0 0 0 3 0 0 0 3 0 0 0 16 12 0 0 0 3 0 0 0 4 0 0 0 8 12 0 0 0 3 0 0 0 5 0 0 0 9 12 0 0 0 3 0 0 0 6 0 0 0 10 12 0 0 0 3 0 0 0 7 0 0 0 11 12 0 0 0 4 0 0 0 0 0 0 0 3 12 0 0 0 4 0 0 0 0 0 0 0 5 12 0 0 0 4 0 0 0 1 0 0 0 2 12 0 0 0 4 0 0 0 1 0 0 0 6 12 0 0 0 4 0 0 0 2 0 0 0 1 12 0 0 0 4 0 0 0 2 0 0 0 7 12 0 0 0 4 0 0 0 3 0 0 0 0 12 0 0 0 4 0 0 0 3 0 0 0 8 12 0 0 0 4 0 0 0 4 0 0 0 9 12 0 0 0 4 0 0 0 4 0 0 0 16 12 0 0 0 4 0 0 0 5 0 0 0 10 12 0 0 0 4 0 0 0 6 0 0 0 11 12 0 0 0 4 0 0 0 7 0 0 0 12 12 0 0 0 5 0 0 0 0 0 0 0 4 12 0 0 0 5 0 0 0 0 0 0 0 6 12 0 0 0 5 0 0 0 1 0 0 0 3 12 0 0 0 5 0 0 0 1 0 0 0 7 12 0 0 0 5 0 0 0 2 0 0 0 2 12 0 0 0 5 0 0 0 2 0 0 0 8 12 0 0 0 5 0 0 0 3 0 0 0 1 12 0 0 0 5 0 0 0 3 0 0 0 9 12 0 0 0 5 0 0 0 4 0 0 0 0 12 0 0 0 5 0 0 0 4 0 0 0 10 12 0 0 0 5 0 0 0 5 0 0 0 11 12 0 0 0 5 0 0 0 5 0 0 0 16 12 0 0 0 5 0 0 0 6 0 0 0 12 12 0 0 0 5 0 0 0 7 0 0 0 13 12 0 0 0 6 0 0 0 0 0 0 0 5 12 0 0 0 6 0 0 0 0 0 0 0 7 12 0 0 0 6 0 0 0 1 0 0 0 4 12 0 0 0 6 0 0 0 1 0 0 0 8 12 0 0 0 6 0 0 0 2 0 0 0 3 12 0 0 0 6 0 0 0 2 0 0 0 9 12 0 0 0 6 0 0 0 3 0 0 0 2 12 0 0 0 6 0 0 0 3 0 0 0 10 12 0 0 0 6 0 0 0 4 0 0 0 1 12 0 0 0 6 0 0 0 4 0 0 0 11 12 0 0 0 6 0 0 0 5 0 0 0 0 12 0 0 0 6 0 0 0 5 0 0 0 12 12 0 0 0 6 0 0 0 6 0 0 0 13 12 0 0 0 6 0 0 0 6 0 0 0 16 12 0 0 0 6 0 0 0 7 0 0 0 14 12 0 0 0 7 0 0 0 0 0 0 0 6 12 0 0 0 7 0 0 0 0 0 0 0 8 12 0 0 0 7 0 0 0 1 0 0 0 5 12 0 0 0 7 0 0 0 1 0 0 0 9 12 0 0 0 7 0 0 0 2 0 0 0 4 12 0 0 0 7 0 0 0 2 0 0 0 10 12 0 0 0 7 0 0 0 3 0 0 0 3 12 0 0 0 7 0 0 0 3 0 0 0 11 12 0 0 0 7 0 0 0 4 0 0 0 2 12 0 0 0 7 0 0 0 4 0 0 0 12 12 0 0 0 7 0 0 0 5 0 0 0 1 12 0 0 0 7 0 0 0 5 0 0 0 13 12 0 0 0 7 0 0 0 6 0 0 0 0 12 0 0 0 7 0 0 0 6 0 0 0 14 12 0 0 0 7 0 0 0 7 0 0 0 15 12 0 0 0 7 0 0 0 7 0 0 0 16"));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("64 8 0 0 0 0 0 0 0 0 8 0 0 0 0 0 0 0 1 8 0 0 0 0 0 0 0 2 8 0 0 0 0 0 0 0 3 8 0 0 0 0 0 0 0 4 8 0 0 0 0 0 0 0 5 8 0 0 0 0 0 0 0 6 8 0 0 0 0 0 0 0 7 8 0 0 0 1 0 0 0 0 8 0 0 0 1 0 0 0 1 8 0 0 0 1 0 0 0 2 8 0 0 0 1 0 0 0 3 8 0 0 0 1 0 0 0 4 8 0 0 0 1 0 0 0 5 8 0 0 0 1 0 0 0 6 8 0 0 0 1 0 0 0 7 8 0 0 0 2 0 0 0 0 8 0 0 0 2 0 0 0 1 8 0 0 0 2 0 0 0 2 8 0 0 0 2 0 0 0 3 8 0 0 0 2 0 0 0 4 8 0 0 0 2 0 0 0 5 8 0 0 0 2 0 0 0 6 8 0 0 0 2 0 0 0 7 8 0 0 0 3 0 0 0 0 8 0 0 0 3 0 0 0 1 8 0 0 0 3 0 0 0 2 8 0 0 0 3 0 0 0 3 8 0 0 0 3 0 0 0 4 8 0 0 0 3 0 0 0 5 8 0 0 0 3 0 0 0 6 8 0 0 0 3 0 0 0 7 8 0 0 0 4 0 0 0 0 8 0 0 0 4 0 0 0 1 8 0 0 0 4 0 0 0 2 8 0 0 0 4 0 0 0 3 8 0 0 0 4 0 0 0 4 8 0 0 0 4 0 0 0 5 8 0 0 0 4 0 0 0 6 8 0 0 0 4 0 0 0 7 8 0 0 0 5 0 0 0 0 8 0 0 0 5 0 0 0 1 8 0 0 0 5 0 0 0 2 8 0 0 0 5 0 0 0 3 8 0 0 0 5 0 0 0 4 8 0 0 0 5 0 0 0 5 8 0 0 0 5 0 0 0 6 8 0 0 0 5 0 0 0 7 8 0 0 0 6 0 0 0 0 8 0 0 0 6 0 0 0 1 8 0 0 0 6 0 0 0 2 8 0 0 0 6 0 0 0 3 8 0 0 0 6 0 0 0 4 8 0 0 0 6 0 0 0 5 8 0 0 0 6 0 0 0 6 8 0 0 0 6 0 0 0 7 8 0 0 0 7 0 0 0 0 8 0 0 0 7 0 0 0 1 8 0 0 0 7 0 0 0 2 8 0 0 0 7 0 0 0 3 8 0 0 0 7 0 0 0 4 8 0 0 0 7 0 0 0 5 8 0 0 0 7 0 0 0 6 8 0 0 0 7 0 0 0 7"));
#[inline(never)]
fn native_block_0(c: &mut Context) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v0_2: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_4: Space = wrap(&(v0_2),&(*CONSTANT_2));
  let v0_5: Space = wrap(&(v0_4),&(*CONSTANT_0));
  let v0_7: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_8: Space = wrap(&(v0_7),&(*CONSTANT_2));
  let v0_9: Space = wrap(&(v0_8),&(*CONSTANT_3));
  let v0_10: Space = unite(&(v0_5),&(v0_9));
  let v0_12: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_13: Space = wrap(&(v0_12),&(*CONSTANT_2));
  let v0_14: Space = wrap(&(v0_13),&(*CONSTANT_4));
  let v0_15: Space = unite(&(v0_10),&(v0_14));
  let v0_17: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_18: Space = wrap(&(v0_17),&(*CONSTANT_2));
  let v0_19: Space = wrap(&(v0_18),&(*CONSTANT_5));
  let v0_20: Space = unite(&(v0_15),&(v0_19));
  let v0_22: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_23: Space = wrap(&(v0_22),&(*CONSTANT_2));
  let v0_24: Space = wrap(&(v0_23),&(*CONSTANT_6));
  let v0_25: Space = unite(&(v0_20),&(v0_24));
  let v0_27: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_28: Space = wrap(&(v0_27),&(*CONSTANT_2));
  let v0_29: Space = wrap(&(v0_28),&(*CONSTANT_7));
  let v0_30: Space = unite(&(v0_25),&(v0_29));
  let v0_32: Space = routine_1(c, &(*CONSTANT_8), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_33: Space = wrap(&(v0_32),&(*CONSTANT_2));
  let v0_34: Space = wrap(&(v0_33),&(*CONSTANT_8));
  let v0_35: Space = unite(&(v0_30),&(v0_34));
  let v0_36: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_0), &(*CONSTANT_1));
  let v0_37: Space = wrap(&(v0_36),&(*CONSTANT_2));
  let v0_38: Space = wrap(&(v0_37),&(*CONSTANT_1));
  let v0_39: Space = unite(&(v0_35),&(v0_38));
  let mut v0_41 = Space::new();
  let mut v0_41_cursor = (v0_39).read_zipper();
  for v0_41_byte in v0_41_cursor.child_mask().iter() {
    v0_41_cursor.descend_to_byte(v0_41_byte);
    let v0_41_tail = v0_41_cursor.make_map();
    v0_41_cursor.ascend(1);
    let v0_41_head = Path::from_slice(&[v0_41_byte]);
    let mut v1_2 = Space::new();
    let mut v1_2_cursor = (v0_41_tail).read_zipper();
    for v1_2_byte in v1_2_cursor.child_mask().iter() {
      v1_2_cursor.descend_to_byte(v1_2_byte);
      let v1_2_tail = v1_2_cursor.make_map();
      v1_2_cursor.ascend(1);
      let v1_2_head = Path::from_slice(&[v1_2_byte]);
      let v2_2: Path = concat_path(&(v0_41_head),&(v1_2_head));
      let mut v2_3 = Space::new();
      let mut v2_3_cursor = (v1_2_tail).read_zipper();
      for v2_3_byte in v2_3_cursor.child_mask().iter() {
        v2_3_cursor.descend_to_byte(v2_3_byte);
        let v2_3_tail = v2_3_cursor.make_map();
        v2_3_cursor.ascend(1);
        let v2_3_head = Path::from_slice(&[v2_3_byte]);
        let v3_2: Path = concat_path(&(v2_2),&(v2_3_head));
        let mut v3_3 = Space::new();
        let mut v3_3_cursor = (v2_3_tail).read_zipper();
        for v3_3_byte in v3_3_cursor.child_mask().iter() {
          v3_3_cursor.descend_to_byte(v3_3_byte);
          let v3_3_tail = v3_3_cursor.make_map();
          v3_3_cursor.ascend(1);
          let v3_3_head = Path::from_slice(&[v3_3_byte]);
          let v4_2: Space = unwrap(&(v3_3_tail),&(*CONSTANT_3));
          let v4_3: Space = subtract(&(*CONSTANT_9),&(v4_2));
          drop(v4_2);
          let v4_4: Path = concat_path(&(v3_2),&(v3_3_head));
          let mut v4_5 = Space::new();
          let mut v4_5_cursor = (v4_3).read_zipper();
          for v4_5_byte in v4_5_cursor.child_mask().iter() {
            v4_5_cursor.descend_to_byte(v4_5_byte);
            let v4_5_tail = v4_5_cursor.make_map();
            v4_5_cursor.ascend(1);
            let v4_5_head = Path::from_slice(&[v4_5_byte]);
            let mut v5_2 = Space::new();
            let mut v5_2_cursor = (v4_5_tail).read_zipper();
            for v5_2_byte in v5_2_cursor.child_mask().iter() {
              v5_2_cursor.descend_to_byte(v5_2_byte);
              let v5_2_tail = v5_2_cursor.make_map();
              v5_2_cursor.ascend(1);
              let v5_2_head = Path::from_slice(&[v5_2_byte]);
              let v6_2: Path = concat_path(&(v4_5_head),&(v5_2_head));
              let mut v6_3 = Space::new();
              let mut v6_3_cursor = (v5_2_tail).read_zipper();
              for v6_3_byte in v6_3_cursor.child_mask().iter() {
                v6_3_cursor.descend_to_byte(v6_3_byte);
                let v6_3_tail = v6_3_cursor.make_map();
                v6_3_cursor.ascend(1);
                let v6_3_head = Path::from_slice(&[v6_3_byte]);
                let v7_2: Path = concat_path(&(v6_2),&(v6_3_head));
                let mut v7_3 = Space::new();
                let mut v7_3_cursor = (v6_3_tail).read_zipper();
                for v7_3_byte in v7_3_cursor.child_mask().iter() {
                  v7_3_cursor.descend_to_byte(v7_3_byte);
                  let v7_3_tail = v7_3_cursor.make_map();
                  v7_3_cursor.ascend(1);
                  let v7_3_head = Path::from_slice(&[v7_3_byte]);
                  let v8_2: Path = concat_path(&(v7_2),&(v7_3_head));
                  let v8_3: Space = routine_2(c, &(v8_2), &(v4_4), &(v7_3_tail), &(v3_3_tail));
                  drop(v8_2);
                  v7_3.join_into((v8_3).clone());
                }
                drop(v7_3_cursor);
                drop(v7_2);
                v6_3.join_into((v7_3).clone());
              }
              drop(v6_3_cursor);
              drop(v6_2);
              v5_2.join_into((v6_3).clone());
            }
            drop(v5_2_cursor);
            v4_5.join_into((v5_2).clone());
          }
          drop(v4_5_cursor);
          drop(v4_3);
          drop(v4_4);
          v3_3.join_into((v4_5).clone());
        }
        drop(v3_3_cursor);
        drop(v3_2);
        v2_3.join_into((v3_3).clone());
      }
      drop(v2_3_cursor);
      drop(v2_2);
      v1_2.join_into((v2_3).clone());
    }
    drop(v1_2_cursor);
    v0_41.join_into((v1_2).clone());
  }
  drop(v0_41_cursor);
  let mut v0_42 = Space::new();
  let mut v0_42_cursor = (v0_41).read_zipper();
  for v0_42_byte in v0_42_cursor.child_mask().iter() {
    v0_42_cursor.descend_to_byte(v0_42_byte);
    let v0_42_tail = v0_42_cursor.make_map();
    v0_42_cursor.ascend(1);
    let v0_42_head = Path::from_slice(&[v0_42_byte]);
    let mut v9_2 = Space::new();
    let mut v9_2_cursor = (v0_42_tail).read_zipper();
    for v9_2_byte in v9_2_cursor.child_mask().iter() {
      v9_2_cursor.descend_to_byte(v9_2_byte);
      let v9_2_tail = v9_2_cursor.make_map();
      v9_2_cursor.ascend(1);
      let v9_2_head = Path::from_slice(&[v9_2_byte]);
      let v10_2: Path = concat_path(&(v0_42_head),&(v9_2_head));
      let mut v10_3 = Space::new();
      let mut v10_3_cursor = (v9_2_tail).read_zipper();
      for v10_3_byte in v10_3_cursor.child_mask().iter() {
        v10_3_cursor.descend_to_byte(v10_3_byte);
        let v10_3_tail = v10_3_cursor.make_map();
        v10_3_cursor.ascend(1);
        let v10_3_head = Path::from_slice(&[v10_3_byte]);
        let v11_2: Path = concat_path(&(v10_2),&(v10_3_head));
        let mut v11_3 = Space::new();
        let mut v11_3_cursor = (v10_3_tail).read_zipper();
        for v11_3_byte in v11_3_cursor.child_mask().iter() {
          v11_3_cursor.descend_to_byte(v11_3_byte);
          let v11_3_tail = v11_3_cursor.make_map();
          v11_3_cursor.ascend(1);
          let v11_3_head = Path::from_slice(&[v11_3_byte]);
          let v12_2: Path = concat_path(&(v11_2),&(v11_3_head));
          let mut v12_3 = Space::new();
          let mut v12_3_cursor = (v11_3_tail).read_zipper();
          for v12_3_byte in v12_3_cursor.child_mask().iter() {
            v12_3_cursor.descend_to_byte(v12_3_byte);
            let v12_3_tail = v12_3_cursor.make_map();
            v12_3_cursor.ascend(1);
            let v12_3_head = Path::from_slice(&[v12_3_byte]);
            let mut v13_2 = Space::new();
            let mut v13_2_cursor = (v12_3_tail).read_zipper();
            for v13_2_byte in v13_2_cursor.child_mask().iter() {
              v13_2_cursor.descend_to_byte(v13_2_byte);
              let v13_2_tail = v13_2_cursor.make_map();
              v13_2_cursor.ascend(1);
              let v13_2_head = Path::from_slice(&[v13_2_byte]);
              let v14_2: Path = concat_path(&(v12_3_head),&(v13_2_head));
              let mut v14_3 = Space::new();
              let mut v14_3_cursor = (v13_2_tail).read_zipper();
              for v14_3_byte in v14_3_cursor.child_mask().iter() {
                v14_3_cursor.descend_to_byte(v14_3_byte);
                let v14_3_tail = v14_3_cursor.make_map();
                v14_3_cursor.ascend(1);
                let v14_3_head = Path::from_slice(&[v14_3_byte]);
                let v15_2: Path = concat_path(&(v14_2),&(v14_3_head));
                let mut v15_3 = Space::new();
                let mut v15_3_cursor = (v14_3_tail).read_zipper();
                for v15_3_byte in v15_3_cursor.child_mask().iter() {
                  v15_3_cursor.descend_to_byte(v15_3_byte);
                  let v15_3_tail = v15_3_cursor.make_map();
                  v15_3_cursor.ascend(1);
                  let v15_3_head = Path::from_slice(&[v15_3_byte]);
                  let v16_2: Path = concat_path(&(v15_2),&(v15_3_head));
                  let v16_3: Space = routine_3(c, &(v16_2), &(v12_2), &(v15_3_tail));
                  drop(v16_2);
                  v15_3.join_into((v16_3).clone());
                }
                drop(v15_3_cursor);
                drop(v15_2);
                v14_3.join_into((v15_3).clone());
              }
              drop(v14_3_cursor);
              drop(v14_2);
              v13_2.join_into((v14_3).clone());
            }
            drop(v13_2_cursor);
            v12_3.join_into((v13_2).clone());
          }
          drop(v12_3_cursor);
          drop(v12_2);
          v11_3.join_into((v12_3).clone());
        }
        drop(v11_3_cursor);
        drop(v11_2);
        v10_3.join_into((v11_3).clone());
      }
      drop(v10_3_cursor);
      drop(v10_2);
      v9_2.join_into((v10_3).clone());
    }
    drop(v9_2_cursor);
    v0_42.join_into((v9_2).clone());
  }
  drop(v0_42_cursor);
  let mut v0_43 = Space::new();
  let mut v0_43_cursor = (v0_42).read_zipper();
  for v0_43_byte in v0_43_cursor.child_mask().iter() {
    v0_43_cursor.descend_to_byte(v0_43_byte);
    let v0_43_tail = v0_43_cursor.make_map();
    v0_43_cursor.ascend(1);
    let v0_43_head = Path::from_slice(&[v0_43_byte]);
    let mut v17_2 = Space::new();
    let mut v17_2_cursor = (v0_43_tail).read_zipper();
    for v17_2_byte in v17_2_cursor.child_mask().iter() {
      v17_2_cursor.descend_to_byte(v17_2_byte);
      let v17_2_tail = v17_2_cursor.make_map();
      v17_2_cursor.ascend(1);
      let v17_2_head = Path::from_slice(&[v17_2_byte]);
      let v18_2: Path = concat_path(&(v0_43_head),&(v17_2_head));
      let mut v18_3 = Space::new();
      let mut v18_3_cursor = (v17_2_tail).read_zipper();
      for v18_3_byte in v18_3_cursor.child_mask().iter() {
        v18_3_cursor.descend_to_byte(v18_3_byte);
        let v18_3_tail = v18_3_cursor.make_map();
        v18_3_cursor.ascend(1);
        let v18_3_head = Path::from_slice(&[v18_3_byte]);
        let v19_2: Path = concat_path(&(v18_2),&(v18_3_head));
        let mut v19_3 = Space::new();
        let mut v19_3_cursor = (v18_3_tail).read_zipper();
        for v19_3_byte in v19_3_cursor.child_mask().iter() {
          v19_3_cursor.descend_to_byte(v19_3_byte);
          let v19_3_tail = v19_3_cursor.make_map();
          v19_3_cursor.ascend(1);
          let v19_3_head = Path::from_slice(&[v19_3_byte]);
          let v20_2: Path = concat_path(&(v19_2),&(v19_3_head));
          let mut v20_3 = Space::new();
          let mut v20_3_cursor = (v19_3_tail).read_zipper();
          for v20_3_byte in v20_3_cursor.child_mask().iter() {
            v20_3_cursor.descend_to_byte(v20_3_byte);
            let v20_3_tail = v20_3_cursor.make_map();
            v20_3_cursor.ascend(1);
            let v20_3_head = Path::from_slice(&[v20_3_byte]);
            let mut v21_2 = Space::new();
            let mut v21_2_cursor = (v20_3_tail).read_zipper();
            for v21_2_byte in v21_2_cursor.child_mask().iter() {
              v21_2_cursor.descend_to_byte(v21_2_byte);
              let v21_2_tail = v21_2_cursor.make_map();
              v21_2_cursor.ascend(1);
              let v21_2_head = Path::from_slice(&[v21_2_byte]);
              let v22_2: Path = concat_path(&(v20_3_head),&(v21_2_head));
              let mut v22_3 = Space::new();
              let mut v22_3_cursor = (v21_2_tail).read_zipper();
              for v22_3_byte in v22_3_cursor.child_mask().iter() {
                v22_3_cursor.descend_to_byte(v22_3_byte);
                let v22_3_tail = v22_3_cursor.make_map();
                v22_3_cursor.ascend(1);
                let v22_3_head = Path::from_slice(&[v22_3_byte]);
                let v23_2: Path = concat_path(&(v22_2),&(v22_3_head));
                let mut v23_3 = Space::new();
                let mut v23_3_cursor = (v22_3_tail).read_zipper();
                for v23_3_byte in v23_3_cursor.child_mask().iter() {
                  v23_3_cursor.descend_to_byte(v23_3_byte);
                  let v23_3_tail = v23_3_cursor.make_map();
                  v23_3_cursor.ascend(1);
                  let v23_3_head = Path::from_slice(&[v23_3_byte]);
                  let v24_2: Path = concat_path(&(v23_2),&(v23_3_head));
                  let v24_3: Space = routine_4(c, &(v24_2), &(v20_2), &(v23_3_tail));
                  drop(v24_2);
                  v23_3.join_into((v24_3).clone());
                }
                drop(v23_3_cursor);
                drop(v23_2);
                v22_3.join_into((v23_3).clone());
              }
              drop(v22_3_cursor);
              drop(v22_2);
              v21_2.join_into((v22_3).clone());
            }
            drop(v21_2_cursor);
            v20_3.join_into((v21_2).clone());
          }
          drop(v20_3_cursor);
          drop(v20_2);
          v19_3.join_into((v20_3).clone());
        }
        drop(v19_3_cursor);
        drop(v19_2);
        v18_3.join_into((v19_3).clone());
      }
      drop(v18_3_cursor);
      drop(v18_2);
      v17_2.join_into((v18_3).clone());
    }
    drop(v17_2_cursor);
    v0_43.join_into((v17_2).clone());
  }
  drop(v0_43_cursor);
  let mut v0_44 = Space::new();
  let mut v0_44_cursor = (v0_43).read_zipper();
  for v0_44_byte in v0_44_cursor.child_mask().iter() {
    v0_44_cursor.descend_to_byte(v0_44_byte);
    let v0_44_tail = v0_44_cursor.make_map();
    v0_44_cursor.ascend(1);
    let v0_44_head = Path::from_slice(&[v0_44_byte]);
    let mut v25_2 = Space::new();
    let mut v25_2_cursor = (v0_44_tail).read_zipper();
    for v25_2_byte in v25_2_cursor.child_mask().iter() {
      v25_2_cursor.descend_to_byte(v25_2_byte);
      let v25_2_tail = v25_2_cursor.make_map();
      v25_2_cursor.ascend(1);
      let v25_2_head = Path::from_slice(&[v25_2_byte]);
      let v26_2: Path = concat_path(&(v0_44_head),&(v25_2_head));
      let mut v26_3 = Space::new();
      let mut v26_3_cursor = (v25_2_tail).read_zipper();
      for v26_3_byte in v26_3_cursor.child_mask().iter() {
        v26_3_cursor.descend_to_byte(v26_3_byte);
        let v26_3_tail = v26_3_cursor.make_map();
        v26_3_cursor.ascend(1);
        let v26_3_head = Path::from_slice(&[v26_3_byte]);
        let v27_2: Path = concat_path(&(v26_2),&(v26_3_head));
        let mut v27_3 = Space::new();
        let mut v27_3_cursor = (v26_3_tail).read_zipper();
        for v27_3_byte in v27_3_cursor.child_mask().iter() {
          v27_3_cursor.descend_to_byte(v27_3_byte);
          let v27_3_tail = v27_3_cursor.make_map();
          v27_3_cursor.ascend(1);
          let v27_3_head = Path::from_slice(&[v27_3_byte]);
          let v28_2: Path = concat_path(&(v27_2),&(v27_3_head));
          let mut v28_3 = Space::new();
          let mut v28_3_cursor = (v27_3_tail).read_zipper();
          for v28_3_byte in v28_3_cursor.child_mask().iter() {
            v28_3_cursor.descend_to_byte(v28_3_byte);
            let v28_3_tail = v28_3_cursor.make_map();
            v28_3_cursor.ascend(1);
            let v28_3_head = Path::from_slice(&[v28_3_byte]);
            let mut v29_2 = Space::new();
            let mut v29_2_cursor = (v28_3_tail).read_zipper();
            for v29_2_byte in v29_2_cursor.child_mask().iter() {
              v29_2_cursor.descend_to_byte(v29_2_byte);
              let v29_2_tail = v29_2_cursor.make_map();
              v29_2_cursor.ascend(1);
              let v29_2_head = Path::from_slice(&[v29_2_byte]);
              let v30_2: Path = concat_path(&(v28_3_head),&(v29_2_head));
              let mut v30_3 = Space::new();
              let mut v30_3_cursor = (v29_2_tail).read_zipper();
              for v30_3_byte in v30_3_cursor.child_mask().iter() {
                v30_3_cursor.descend_to_byte(v30_3_byte);
                let v30_3_tail = v30_3_cursor.make_map();
                v30_3_cursor.ascend(1);
                let v30_3_head = Path::from_slice(&[v30_3_byte]);
                let v31_2: Path = concat_path(&(v30_2),&(v30_3_head));
                let mut v31_3 = Space::new();
                let mut v31_3_cursor = (v30_3_tail).read_zipper();
                for v31_3_byte in v31_3_cursor.child_mask().iter() {
                  v31_3_cursor.descend_to_byte(v31_3_byte);
                  let v31_3_tail = v31_3_cursor.make_map();
                  v31_3_cursor.ascend(1);
                  let v31_3_head = Path::from_slice(&[v31_3_byte]);
                  let v32_2: Path = concat_path(&(v31_2),&(v31_3_head));
                  let v32_3: Space = routine_5(c, &(v32_2), &(v28_2), &(v31_3_tail));
                  drop(v32_2);
                  v31_3.join_into((v32_3).clone());
                }
                drop(v31_3_cursor);
                drop(v31_2);
                v30_3.join_into((v31_3).clone());
              }
              drop(v30_3_cursor);
              drop(v30_2);
              v29_2.join_into((v30_3).clone());
            }
            drop(v29_2_cursor);
            v28_3.join_into((v29_2).clone());
          }
          drop(v28_3_cursor);
          drop(v28_2);
          v27_3.join_into((v28_3).clone());
        }
        drop(v27_3_cursor);
        drop(v27_2);
        v26_3.join_into((v27_3).clone());
      }
      drop(v26_3_cursor);
      drop(v26_2);
      v25_2.join_into((v26_3).clone());
    }
    drop(v25_2_cursor);
    v0_44.join_into((v25_2).clone());
  }
  drop(v0_44_cursor);
  let mut v0_45 = Space::new();
  let mut v0_45_cursor = (v0_44).read_zipper();
  for v0_45_byte in v0_45_cursor.child_mask().iter() {
    v0_45_cursor.descend_to_byte(v0_45_byte);
    let v0_45_tail = v0_45_cursor.make_map();
    v0_45_cursor.ascend(1);
    let v0_45_head = Path::from_slice(&[v0_45_byte]);
    let mut v33_2 = Space::new();
    let mut v33_2_cursor = (v0_45_tail).read_zipper();
    for v33_2_byte in v33_2_cursor.child_mask().iter() {
      v33_2_cursor.descend_to_byte(v33_2_byte);
      let v33_2_tail = v33_2_cursor.make_map();
      v33_2_cursor.ascend(1);
      let v33_2_head = Path::from_slice(&[v33_2_byte]);
      let v34_2: Path = concat_path(&(v0_45_head),&(v33_2_head));
      let mut v34_3 = Space::new();
      let mut v34_3_cursor = (v33_2_tail).read_zipper();
      for v34_3_byte in v34_3_cursor.child_mask().iter() {
        v34_3_cursor.descend_to_byte(v34_3_byte);
        let v34_3_tail = v34_3_cursor.make_map();
        v34_3_cursor.ascend(1);
        let v34_3_head = Path::from_slice(&[v34_3_byte]);
        let v35_2: Path = concat_path(&(v34_2),&(v34_3_head));
        let mut v35_3 = Space::new();
        let mut v35_3_cursor = (v34_3_tail).read_zipper();
        for v35_3_byte in v35_3_cursor.child_mask().iter() {
          v35_3_cursor.descend_to_byte(v35_3_byte);
          let v35_3_tail = v35_3_cursor.make_map();
          v35_3_cursor.ascend(1);
          let v35_3_head = Path::from_slice(&[v35_3_byte]);
          let v36_2: Path = concat_path(&(v35_2),&(v35_3_head));
          let mut v36_3 = Space::new();
          let mut v36_3_cursor = (v35_3_tail).read_zipper();
          for v36_3_byte in v36_3_cursor.child_mask().iter() {
            v36_3_cursor.descend_to_byte(v36_3_byte);
            let v36_3_tail = v36_3_cursor.make_map();
            v36_3_cursor.ascend(1);
            let v36_3_head = Path::from_slice(&[v36_3_byte]);
            let mut v37_2 = Space::new();
            let mut v37_2_cursor = (v36_3_tail).read_zipper();
            for v37_2_byte in v37_2_cursor.child_mask().iter() {
              v37_2_cursor.descend_to_byte(v37_2_byte);
              let v37_2_tail = v37_2_cursor.make_map();
              v37_2_cursor.ascend(1);
              let v37_2_head = Path::from_slice(&[v37_2_byte]);
              let v38_2: Path = concat_path(&(v36_3_head),&(v37_2_head));
              let mut v38_3 = Space::new();
              let mut v38_3_cursor = (v37_2_tail).read_zipper();
              for v38_3_byte in v38_3_cursor.child_mask().iter() {
                v38_3_cursor.descend_to_byte(v38_3_byte);
                let v38_3_tail = v38_3_cursor.make_map();
                v38_3_cursor.ascend(1);
                let v38_3_head = Path::from_slice(&[v38_3_byte]);
                let v39_2: Path = concat_path(&(v38_2),&(v38_3_head));
                let mut v39_3 = Space::new();
                let mut v39_3_cursor = (v38_3_tail).read_zipper();
                for v39_3_byte in v39_3_cursor.child_mask().iter() {
                  v39_3_cursor.descend_to_byte(v39_3_byte);
                  let v39_3_tail = v39_3_cursor.make_map();
                  v39_3_cursor.ascend(1);
                  let v39_3_head = Path::from_slice(&[v39_3_byte]);
                  let v40_2: Path = concat_path(&(v39_2),&(v39_3_head));
                  let v40_3: Space = routine_6(c, &(v40_2), &(v36_2), &(v39_3_tail));
                  drop(v40_2);
                  v39_3.join_into((v40_3).clone());
                }
                drop(v39_3_cursor);
                drop(v39_2);
                v38_3.join_into((v39_3).clone());
              }
              drop(v38_3_cursor);
              drop(v38_2);
              v37_2.join_into((v38_3).clone());
            }
            drop(v37_2_cursor);
            v36_3.join_into((v37_2).clone());
          }
          drop(v36_3_cursor);
          drop(v36_2);
          v35_3.join_into((v36_3).clone());
        }
        drop(v35_3_cursor);
        drop(v35_2);
        v34_3.join_into((v35_3).clone());
      }
      drop(v34_3_cursor);
      drop(v34_2);
      v33_2.join_into((v34_3).clone());
    }
    drop(v33_2_cursor);
    v0_45.join_into((v33_2).clone());
  }
  drop(v0_45_cursor);
  let mut v0_46 = Space::new();
  let mut v0_46_cursor = (v0_45).read_zipper();
  for v0_46_byte in v0_46_cursor.child_mask().iter() {
    v0_46_cursor.descend_to_byte(v0_46_byte);
    let v0_46_tail = v0_46_cursor.make_map();
    v0_46_cursor.ascend(1);
    let v0_46_head = Path::from_slice(&[v0_46_byte]);
    let mut v41_2 = Space::new();
    let mut v41_2_cursor = (v0_46_tail).read_zipper();
    for v41_2_byte in v41_2_cursor.child_mask().iter() {
      v41_2_cursor.descend_to_byte(v41_2_byte);
      let v41_2_tail = v41_2_cursor.make_map();
      v41_2_cursor.ascend(1);
      let v41_2_head = Path::from_slice(&[v41_2_byte]);
      let v42_2: Path = concat_path(&(v0_46_head),&(v41_2_head));
      let mut v42_3 = Space::new();
      let mut v42_3_cursor = (v41_2_tail).read_zipper();
      for v42_3_byte in v42_3_cursor.child_mask().iter() {
        v42_3_cursor.descend_to_byte(v42_3_byte);
        let v42_3_tail = v42_3_cursor.make_map();
        v42_3_cursor.ascend(1);
        let v42_3_head = Path::from_slice(&[v42_3_byte]);
        let v43_2: Path = concat_path(&(v42_2),&(v42_3_head));
        let mut v43_3 = Space::new();
        let mut v43_3_cursor = (v42_3_tail).read_zipper();
        for v43_3_byte in v43_3_cursor.child_mask().iter() {
          v43_3_cursor.descend_to_byte(v43_3_byte);
          let v43_3_tail = v43_3_cursor.make_map();
          v43_3_cursor.ascend(1);
          let v43_3_head = Path::from_slice(&[v43_3_byte]);
          let v44_2: Path = concat_path(&(v43_2),&(v43_3_head));
          let mut v44_3 = Space::new();
          let mut v44_3_cursor = (v43_3_tail).read_zipper();
          for v44_3_byte in v44_3_cursor.child_mask().iter() {
            v44_3_cursor.descend_to_byte(v44_3_byte);
            let v44_3_tail = v44_3_cursor.make_map();
            v44_3_cursor.ascend(1);
            let v44_3_head = Path::from_slice(&[v44_3_byte]);
            let mut v45_2 = Space::new();
            let mut v45_2_cursor = (v44_3_tail).read_zipper();
            for v45_2_byte in v45_2_cursor.child_mask().iter() {
              v45_2_cursor.descend_to_byte(v45_2_byte);
              let v45_2_tail = v45_2_cursor.make_map();
              v45_2_cursor.ascend(1);
              let v45_2_head = Path::from_slice(&[v45_2_byte]);
              let v46_2: Path = concat_path(&(v44_3_head),&(v45_2_head));
              let mut v46_3 = Space::new();
              let mut v46_3_cursor = (v45_2_tail).read_zipper();
              for v46_3_byte in v46_3_cursor.child_mask().iter() {
                v46_3_cursor.descend_to_byte(v46_3_byte);
                let v46_3_tail = v46_3_cursor.make_map();
                v46_3_cursor.ascend(1);
                let v46_3_head = Path::from_slice(&[v46_3_byte]);
                let v47_2: Path = concat_path(&(v46_2),&(v46_3_head));
                let mut v47_3 = Space::new();
                let mut v47_3_cursor = (v46_3_tail).read_zipper();
                for v47_3_byte in v47_3_cursor.child_mask().iter() {
                  v47_3_cursor.descend_to_byte(v47_3_byte);
                  let v47_3_tail = v47_3_cursor.make_map();
                  v47_3_cursor.ascend(1);
                  let v47_3_head = Path::from_slice(&[v47_3_byte]);
                  let v48_2: Path = concat_path(&(v47_2),&(v47_3_head));
                  let v48_3: Space = routine_7(c, &(v48_2), &(v44_2), &(v47_3_tail));
                  drop(v48_2);
                  v47_3.join_into((v48_3).clone());
                }
                drop(v47_3_cursor);
                drop(v47_2);
                v46_3.join_into((v47_3).clone());
              }
              drop(v46_3_cursor);
              drop(v46_2);
              v45_2.join_into((v46_3).clone());
            }
            drop(v45_2_cursor);
            v44_3.join_into((v45_2).clone());
          }
          drop(v44_3_cursor);
          drop(v44_2);
          v43_3.join_into((v44_3).clone());
        }
        drop(v43_3_cursor);
        drop(v43_2);
        v42_3.join_into((v43_3).clone());
      }
      drop(v42_3_cursor);
      drop(v42_2);
      v41_2.join_into((v42_3).clone());
    }
    drop(v41_2_cursor);
    v0_46.join_into((v41_2).clone());
  }
  drop(v0_46_cursor);
  let mut v0_47 = Space::new();
  let mut v0_47_cursor = (v0_46).read_zipper();
  for v0_47_byte in v0_47_cursor.child_mask().iter() {
    v0_47_cursor.descend_to_byte(v0_47_byte);
    let v0_47_tail = v0_47_cursor.make_map();
    v0_47_cursor.ascend(1);
    let v0_47_head = Path::from_slice(&[v0_47_byte]);
    let mut v49_2 = Space::new();
    let mut v49_2_cursor = (v0_47_tail).read_zipper();
    for v49_2_byte in v49_2_cursor.child_mask().iter() {
      v49_2_cursor.descend_to_byte(v49_2_byte);
      let v49_2_tail = v49_2_cursor.make_map();
      v49_2_cursor.ascend(1);
      let v49_2_head = Path::from_slice(&[v49_2_byte]);
      let v50_2: Path = concat_path(&(v0_47_head),&(v49_2_head));
      let mut v50_3 = Space::new();
      let mut v50_3_cursor = (v49_2_tail).read_zipper();
      for v50_3_byte in v50_3_cursor.child_mask().iter() {
        v50_3_cursor.descend_to_byte(v50_3_byte);
        let v50_3_tail = v50_3_cursor.make_map();
        v50_3_cursor.ascend(1);
        let v50_3_head = Path::from_slice(&[v50_3_byte]);
        let v51_2: Path = concat_path(&(v50_2),&(v50_3_head));
        let mut v51_3 = Space::new();
        let mut v51_3_cursor = (v50_3_tail).read_zipper();
        for v51_3_byte in v51_3_cursor.child_mask().iter() {
          v51_3_cursor.descend_to_byte(v51_3_byte);
          let v51_3_tail = v51_3_cursor.make_map();
          v51_3_cursor.ascend(1);
          let v51_3_head = Path::from_slice(&[v51_3_byte]);
          let v52_2: Path = concat_path(&(v51_2),&(v51_3_head));
          let mut v52_3 = Space::new();
          let mut v52_3_cursor = (v51_3_tail).read_zipper();
          for v52_3_byte in v52_3_cursor.child_mask().iter() {
            v52_3_cursor.descend_to_byte(v52_3_byte);
            let v52_3_tail = v52_3_cursor.make_map();
            v52_3_cursor.ascend(1);
            let v52_3_head = Path::from_slice(&[v52_3_byte]);
            let mut v53_2 = Space::new();
            let mut v53_2_cursor = (v52_3_tail).read_zipper();
            for v53_2_byte in v53_2_cursor.child_mask().iter() {
              v53_2_cursor.descend_to_byte(v53_2_byte);
              let v53_2_tail = v53_2_cursor.make_map();
              v53_2_cursor.ascend(1);
              let v53_2_head = Path::from_slice(&[v53_2_byte]);
              let v54_2: Path = concat_path(&(v52_3_head),&(v53_2_head));
              let mut v54_3 = Space::new();
              let mut v54_3_cursor = (v53_2_tail).read_zipper();
              for v54_3_byte in v54_3_cursor.child_mask().iter() {
                v54_3_cursor.descend_to_byte(v54_3_byte);
                let v54_3_tail = v54_3_cursor.make_map();
                v54_3_cursor.ascend(1);
                let v54_3_head = Path::from_slice(&[v54_3_byte]);
                let v55_2: Path = concat_path(&(v54_2),&(v54_3_head));
                let mut v55_3 = Space::new();
                let mut v55_3_cursor = (v54_3_tail).read_zipper();
                for v55_3_byte in v55_3_cursor.child_mask().iter() {
                  v55_3_cursor.descend_to_byte(v55_3_byte);
                  let v55_3_tail = v55_3_cursor.make_map();
                  v55_3_cursor.ascend(1);
                  let v55_3_head = Path::from_slice(&[v55_3_byte]);
                  let v56_2: Path = concat_path(&(v55_2),&(v55_3_head));
                  let v56_3: Space = routine_8(c, &(v56_2), &(v52_2), &(v55_3_tail));
                  drop(v56_2);
                  v55_3.join_into((v56_3).clone());
                }
                drop(v55_3_cursor);
                drop(v55_2);
                v54_3.join_into((v55_3).clone());
              }
              drop(v54_3_cursor);
              drop(v54_2);
              v53_2.join_into((v54_3).clone());
            }
            drop(v53_2_cursor);
            v52_3.join_into((v53_2).clone());
          }
          drop(v52_3_cursor);
          drop(v52_2);
          v51_3.join_into((v52_3).clone());
        }
        drop(v51_3_cursor);
        drop(v51_2);
        v50_3.join_into((v51_3).clone());
      }
      drop(v50_3_cursor);
      drop(v50_2);
      v49_2.join_into((v50_3).clone());
    }
    drop(v49_2_cursor);
    v0_47.join_into((v49_2).clone());
  }
  drop(v0_47_cursor);
  let mut v0_48 = Space::new();
  let mut v0_48_cursor = (v0_47).read_zipper();
  for v0_48_byte in v0_48_cursor.child_mask().iter() {
    v0_48_cursor.descend_to_byte(v0_48_byte);
    let v0_48_tail = v0_48_cursor.make_map();
    v0_48_cursor.ascend(1);
    let v0_48_head = Path::from_slice(&[v0_48_byte]);
    let mut v57_2 = Space::new();
    let mut v57_2_cursor = (v0_48_tail).read_zipper();
    for v57_2_byte in v57_2_cursor.child_mask().iter() {
      v57_2_cursor.descend_to_byte(v57_2_byte);
      let v57_2_tail = v57_2_cursor.make_map();
      v57_2_cursor.ascend(1);
      let v57_2_head = Path::from_slice(&[v57_2_byte]);
      let v58_2: Path = concat_path(&(v0_48_head),&(v57_2_head));
      let mut v58_3 = Space::new();
      let mut v58_3_cursor = (v57_2_tail).read_zipper();
      for v58_3_byte in v58_3_cursor.child_mask().iter() {
        v58_3_cursor.descend_to_byte(v58_3_byte);
        let v58_3_tail = v58_3_cursor.make_map();
        v58_3_cursor.ascend(1);
        let v58_3_head = Path::from_slice(&[v58_3_byte]);
        let v59_2: Path = concat_path(&(v58_2),&(v58_3_head));
        let mut v59_3 = Space::new();
        let mut v59_3_cursor = (v58_3_tail).read_zipper();
        for v59_3_byte in v59_3_cursor.child_mask().iter() {
          v59_3_cursor.descend_to_byte(v59_3_byte);
          let v59_3_tail = v59_3_cursor.make_map();
          v59_3_cursor.ascend(1);
          let v59_3_head = Path::from_slice(&[v59_3_byte]);
          let v60_2: Path = concat_path(&(v59_2),&(v59_3_head));
          let mut v60_3 = Space::new();
          let mut v60_3_cursor = (v59_3_tail).read_zipper();
          for v60_3_byte in v60_3_cursor.child_mask().iter() {
            v60_3_cursor.descend_to_byte(v60_3_byte);
            let v60_3_tail = v60_3_cursor.make_map();
            v60_3_cursor.ascend(1);
            let v60_3_head = Path::from_slice(&[v60_3_byte]);
            let mut v61_2 = Space::new();
            let mut v61_2_cursor = (v60_3_tail).read_zipper();
            for v61_2_byte in v61_2_cursor.child_mask().iter() {
              v61_2_cursor.descend_to_byte(v61_2_byte);
              let v61_2_tail = v61_2_cursor.make_map();
              v61_2_cursor.ascend(1);
              let v61_2_head = Path::from_slice(&[v61_2_byte]);
              let v62_2: Path = concat_path(&(v60_3_head),&(v61_2_head));
              let mut v62_3 = Space::new();
              let mut v62_3_cursor = (v61_2_tail).read_zipper();
              for v62_3_byte in v62_3_cursor.child_mask().iter() {
                v62_3_cursor.descend_to_byte(v62_3_byte);
                let v62_3_tail = v62_3_cursor.make_map();
                v62_3_cursor.ascend(1);
                let v62_3_head = Path::from_slice(&[v62_3_byte]);
                let v63_2: Path = concat_path(&(v62_2),&(v62_3_head));
                let mut v63_3 = Space::new();
                let mut v63_3_cursor = (v62_3_tail).read_zipper();
                for v63_3_byte in v63_3_cursor.child_mask().iter() {
                  v63_3_cursor.descend_to_byte(v63_3_byte);
                  let v63_3_tail = v63_3_cursor.make_map();
                  v63_3_cursor.ascend(1);
                  let v63_3_head = Path::from_slice(&[v63_3_byte]);
                  let v64_2: Path = concat_path(&(v63_2),&(v63_3_head));
                  let v64_3: Space = routine_9(c, &(v64_2), &(v60_2), &(v63_3_tail));
                  drop(v64_2);
                  v63_3.join_into((v64_3).clone());
                }
                drop(v63_3_cursor);
                drop(v63_2);
                v62_3.join_into((v63_3).clone());
              }
              drop(v62_3_cursor);
              drop(v62_2);
              v61_2.join_into((v62_3).clone());
            }
            drop(v61_2_cursor);
            v60_3.join_into((v61_2).clone());
          }
          drop(v60_3_cursor);
          drop(v60_2);
          v59_3.join_into((v60_3).clone());
        }
        drop(v59_3_cursor);
        drop(v59_2);
        v58_3.join_into((v59_3).clone());
      }
      drop(v58_3_cursor);
      drop(v58_2);
      v57_2.join_into((v58_3).clone());
    }
    drop(v57_2_cursor);
    v0_48.join_into((v57_2).clone());
  }
  drop(v0_48_cursor);

((v0_10).clone(),(v0_12).clone(),(v0_13).clone(),(v0_14).clone(),(v0_15).clone(),(v0_17).clone(),(v0_18).clone(),(v0_19).clone(),(v0_2).clone(),(v0_20).clone(),(v0_22).clone(),(v0_23).clone(),(v0_24).clone(),(v0_25).clone(),(v0_27).clone(),(v0_28).clone(),(v0_29).clone(),(v0_30).clone(),(v0_32).clone(),(v0_33).clone(),(v0_34).clone(),(v0_35).clone(),(v0_36).clone(),(v0_37).clone(),(v0_38).clone(),(v0_39).clone(),(v0_4).clone(),(v0_41).clone(),(v0_42).clone(),(v0_43).clone(),(v0_44).clone(),(v0_45).clone(),(v0_46).clone(),(v0_47).clone(),(v0_48).clone(),(v0_5).clone(),(v0_7).clone(),(v0_8).clone(),(v0_9).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let (v0_10,v0_12,v0_13,v0_14,v0_15,v0_17,v0_18,v0_19,v0_2,v0_20,v0_22,v0_23,v0_24,v0_25,v0_27,v0_28,v0_29,v0_30,v0_32,v0_33,v0_34,v0_35,v0_36,v0_37,v0_38,v0_39,v0_4,v0_41,v0_42,v0_43,v0_44,v0_45,v0_46,v0_47,v0_48,v0_5,v0_7,v0_8,v0_9,) = native_block_0(c);
  (v0_48).clone()
}

fn routine_1(c: &mut Context, p0: &Path, p1: &Path, p2: &Path) -> Space {
  let v65_4: Space = unwrap(&(*CONSTANT_10),&(*p2));
  let v65_7: Space = if (v65_4).is_empty() { Space::new() } else {
    let v66_6: Space = unwrap(&(*CONSTANT_10),&(*p2));
    compose(&(v65_4),&(v66_6))
  };
  drop(v65_4);
  let v65_9: Space = unwrap(&(*CONSTANT_10),&(*p2));
  let v65_12: Space = unwrap(&(*CONSTANT_11),&(*p1));
  let v65_13: Space = unwrap(&(*CONSTANT_11),&(*p0));
  let mut v65_14 = Space::new();
  let mut v65_14_cursor = (v65_9).read_zipper();
  for v65_14_byte in v65_14_cursor.child_mask().iter() {
    v65_14_cursor.descend_to_byte(v65_14_byte);
    let v65_14_tail = v65_14_cursor.make_map();
    v65_14_cursor.ascend(1);
    let v65_14_head = Path::from_slice(&[v65_14_byte]);
    let v67_2: Space = unwrap(&(v65_12),&(v65_14_head));
    let v67_3: Space = unwrap(&(v65_13),&(v65_14_head));
    let mut v67_4 = Space::new();
    let mut v67_4_cursor = (v65_14_tail).read_zipper();
    for v67_4_byte in v67_4_cursor.child_mask().iter() {
      v67_4_cursor.descend_to_byte(v67_4_byte);
      let v67_4_tail = v67_4_cursor.make_map();
      v67_4_cursor.ascend(1);
      let v67_4_head = Path::from_slice(&[v67_4_byte]);
      let v68_2: Path = concat_path(&(v65_14_head),&(v67_4_head));
      let v68_3: Space = unwrap(&(v67_2),&(v67_4_head));
      let v68_4: Space = unwrap(&(v67_3),&(v67_4_head));
      let mut v68_5 = Space::new();
      let mut v68_5_cursor = (v67_4_tail).read_zipper();
      for v68_5_byte in v68_5_cursor.child_mask().iter() {
        v68_5_cursor.descend_to_byte(v68_5_byte);
        let v68_5_tail = v68_5_cursor.make_map();
        v68_5_cursor.ascend(1);
        let v68_5_head = Path::from_slice(&[v68_5_byte]);
        let v69_2: Space = unwrap(&(v68_3),&(v68_5_head));
        let v69_3: Space = unwrap(&(v68_4),&(v68_5_head));
        let v69_4: Path = concat_path(&(v68_2),&(v68_5_head));
        let mut v69_5 = Space::new();
        let mut v69_5_cursor = (v68_5_tail).read_zipper();
        for v69_5_byte in v69_5_cursor.child_mask().iter() {
          v69_5_cursor.descend_to_byte(v69_5_byte);
          let v69_5_tail = v69_5_cursor.make_map();
          v69_5_cursor.ascend(1);
          let v69_5_head = Path::from_slice(&[v69_5_byte]);
          let v70_2: Space = unwrap(&(v69_2),&(v69_5_head));
          let v70_4: Space = if (v70_2).is_empty() { Space::new() } else {
            let v71_3: Space = unwrap(&(v69_3),&(v69_5_head));
            compose(&(v70_2),&(v71_3))
          };
          drop(v70_2);
          let v70_5: Path = concat_path(&(v69_4),&(v69_5_head));
          let v70_6: Path = concat_path(&(v70_5),&(*p0));
          let v70_7: Space = singleton(&(v70_6));
          drop(v70_6);
          let v70_8: Space = unite(&(v70_4),&(v70_7));
          drop(v70_4);
          drop(v70_7);
          let v70_9: Path = concat_path(&(*p1),&(v70_5));
          drop(v70_5);
          let v70_10: Space = singleton(&(v70_9));
          drop(v70_9);
          let v70_11: Space = unite(&(v70_8),&(v70_10));
          drop(v70_8);
          drop(v70_10);
          v69_5.join_into((v70_11).clone());
        }
        drop(v69_5_cursor);
        drop(v69_2);
        drop(v69_3);
        drop(v69_4);
        v68_5.join_into((v69_5).clone());
      }
      drop(v68_5_cursor);
      drop(v68_2);
      drop(v68_3);
      drop(v68_4);
      v67_4.join_into((v68_5).clone());
    }
    drop(v67_4_cursor);
    drop(v67_2);
    drop(v67_3);
    v65_14.join_into((v67_4).clone());
  }
  drop(v65_14_cursor);
  drop(v65_9);
  drop(v65_12);
  drop(v65_13);
  let v65_15: Space = intersect(&(v65_7),&(v65_14));
  drop(v65_7);
  drop(v65_14);
  (v65_15).clone()
}

fn routine_2(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v72_7: Space = routine_10(c, &(*CONSTANT_0), &(*CONSTANT_3), &(*p0), &(*CONSTANT_12));
  let v72_9: Space = routine_10(c, &(*CONSTANT_3), &(*CONSTANT_3), &(*p0), &(*CONSTANT_12));
  let v72_10: Space = unite(&(v72_7),&(v72_9));
  let v72_13: Space = routine_10(c, &(*CONSTANT_4), &(*CONSTANT_3), &(*p0), &(*CONSTANT_12));
  let v72_14: Space = unite(&(v72_10),&(v72_13));
  let v72_17: Space = routine_10(c, &(*CONSTANT_5), &(*CONSTANT_3), &(*p0), &(*CONSTANT_12));
  let v72_18: Space = unite(&(v72_14),&(v72_17));
  let v72_21: Space = routine_10(c, &(*CONSTANT_6), &(*CONSTANT_3), &(*p0), &(*CONSTANT_12));
  let v72_22: Space = unite(&(v72_18),&(v72_21));
  let v72_25: Space = routine_10(c, &(*CONSTANT_7), &(*CONSTANT_3), &(*p0), &(*CONSTANT_12));
  let v72_26: Space = unite(&(v72_22),&(v72_25));
  let v72_29: Space = routine_10(c, &(*CONSTANT_8), &(*CONSTANT_3), &(*p0), &(*CONSTANT_12));
  let v72_30: Space = unite(&(v72_26),&(v72_29));
  let v72_33: Space = routine_10(c, &(*CONSTANT_1), &(*CONSTANT_3), &(*p0), &(*CONSTANT_12));
  let v72_34: Space = unite(&(v72_30),&(v72_33));
  let v72_36: Space = intersect(&(v72_34),&(*CONSTANT_13));
  let v72_37: Space = unite(&(v72_36),&(*s1));
  let v72_38: Space = wrap(&(v72_37),&(*p1));
  let v72_39: Space = wrap(&(v72_38),&(*p0));
  (v72_39).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v73_5: Space = unwrap(&(*s0),&(*CONSTANT_4));
  let v73_6: Space = subtract(&(*CONSTANT_9),&(v73_5));
  drop(v73_5);
  let v73_8: Path = concat_path(&(*p1),&(*p0));
  let mut v73_9 = Space::new();
  let mut v73_9_cursor = (v73_6).read_zipper();
  for v73_9_byte in v73_9_cursor.child_mask().iter() {
    v73_9_cursor.descend_to_byte(v73_9_byte);
    let v73_9_tail = v73_9_cursor.make_map();
    v73_9_cursor.ascend(1);
    let v73_9_head = Path::from_slice(&[v73_9_byte]);
    let mut v74_2 = Space::new();
    let mut v74_2_cursor = (v73_9_tail).read_zipper();
    for v74_2_byte in v74_2_cursor.child_mask().iter() {
      v74_2_cursor.descend_to_byte(v74_2_byte);
      let v74_2_tail = v74_2_cursor.make_map();
      v74_2_cursor.ascend(1);
      let v74_2_head = Path::from_slice(&[v74_2_byte]);
      let v75_2: Path = concat_path(&(v73_9_head),&(v74_2_head));
      let mut v75_3 = Space::new();
      let mut v75_3_cursor = (v74_2_tail).read_zipper();
      for v75_3_byte in v75_3_cursor.child_mask().iter() {
        v75_3_cursor.descend_to_byte(v75_3_byte);
        let v75_3_tail = v75_3_cursor.make_map();
        v75_3_cursor.ascend(1);
        let v75_3_head = Path::from_slice(&[v75_3_byte]);
        let v76_2: Path = concat_path(&(v75_2),&(v75_3_head));
        let mut v76_3 = Space::new();
        let mut v76_3_cursor = (v75_3_tail).read_zipper();
        for v76_3_byte in v76_3_cursor.child_mask().iter() {
          v76_3_cursor.descend_to_byte(v76_3_byte);
          let v76_3_tail = v76_3_cursor.make_map();
          v76_3_cursor.ascend(1);
          let v76_3_head = Path::from_slice(&[v76_3_byte]);
          let v77_2: Path = concat_path(&(v76_2),&(v76_3_head));
          let v77_3: Space = routine_1(c, &(v77_2), &(*CONSTANT_4), &(*CONSTANT_1));
          let v77_4: Space = unite(&(*s0),&(v77_3));
          let v77_5: Space = wrap(&(v77_4),&(v73_8));
          let v77_6: Space = wrap(&(v77_5),&(v77_2));
          drop(v77_2);
          v76_3.join_into((v77_6).clone());
        }
        drop(v76_3_cursor);
        drop(v76_2);
        v75_3.join_into((v76_3).clone());
      }
      drop(v75_3_cursor);
      drop(v75_2);
      v74_2.join_into((v75_3).clone());
    }
    drop(v74_2_cursor);
    v73_9.join_into((v74_2).clone());
  }
  drop(v73_9_cursor);
  drop(v73_6);
  drop(v73_8);
  (v73_9).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v78_5 = Space::new();
  let mut v78_5_cursor = (*s0).read_zipper();
  for v78_5_byte in v78_5_cursor.child_mask().iter() {
    v78_5_cursor.descend_to_byte(v78_5_byte);
    let v78_5_tail = v78_5_cursor.make_map();
    v78_5_cursor.ascend(1);
    let v78_5_head = Path::from_slice(&[v78_5_byte]);
    let mut v79_2 = Space::new();
    let mut v79_2_cursor = (v78_5_tail).read_zipper();
    for v79_2_byte in v79_2_cursor.child_mask().iter() {
      v79_2_cursor.descend_to_byte(v79_2_byte);
      let v79_2_tail = v79_2_cursor.make_map();
      v79_2_cursor.ascend(1);
      let v79_2_head = Path::from_slice(&[v79_2_byte]);
      let v80_2: Path = concat_path(&(v78_5_head),&(v79_2_head));
      let mut v80_3 = Space::new();
      let mut v80_3_cursor = (v79_2_tail).read_zipper();
      for v80_3_byte in v80_3_cursor.child_mask().iter() {
        v80_3_cursor.descend_to_byte(v80_3_byte);
        let v80_3_tail = v80_3_cursor.make_map();
        v80_3_cursor.ascend(1);
        let v80_3_head = Path::from_slice(&[v80_3_byte]);
        let v81_2: Path = concat_path(&(v80_2),&(v80_3_head));
        let mut v81_3 = Space::new();
        let mut v81_3_cursor = (v80_3_tail).read_zipper();
        for v81_3_byte in v81_3_cursor.child_mask().iter() {
          v81_3_cursor.descend_to_byte(v81_3_byte);
          let v81_3_tail = v81_3_cursor.make_map();
          v81_3_cursor.ascend(1);
          let v81_3_head = Path::from_slice(&[v81_3_byte]);
          let v82_2: Space = unwrap(&(v81_3_tail),&(*CONSTANT_5));
          let v82_3: Space = subtract(&(*CONSTANT_9),&(v82_2));
          drop(v82_2);
          let v82_4: Path = concat_path(&(v81_2),&(v81_3_head));
          let mut v82_5 = Space::new();
          let mut v82_5_cursor = (v82_3).read_zipper();
          for v82_5_byte in v82_5_cursor.child_mask().iter() {
            v82_5_cursor.descend_to_byte(v82_5_byte);
            let v82_5_tail = v82_5_cursor.make_map();
            v82_5_cursor.ascend(1);
            let v82_5_head = Path::from_slice(&[v82_5_byte]);
            let mut v83_2 = Space::new();
            let mut v83_2_cursor = (v82_5_tail).read_zipper();
            for v83_2_byte in v83_2_cursor.child_mask().iter() {
              v83_2_cursor.descend_to_byte(v83_2_byte);
              let v83_2_tail = v83_2_cursor.make_map();
              v83_2_cursor.ascend(1);
              let v83_2_head = Path::from_slice(&[v83_2_byte]);
              let v84_2: Path = concat_path(&(v82_5_head),&(v83_2_head));
              let mut v84_3 = Space::new();
              let mut v84_3_cursor = (v83_2_tail).read_zipper();
              for v84_3_byte in v84_3_cursor.child_mask().iter() {
                v84_3_cursor.descend_to_byte(v84_3_byte);
                let v84_3_tail = v84_3_cursor.make_map();
                v84_3_cursor.ascend(1);
                let v84_3_head = Path::from_slice(&[v84_3_byte]);
                let v85_2: Path = concat_path(&(v84_2),&(v84_3_head));
                let mut v85_3 = Space::new();
                let mut v85_3_cursor = (v84_3_tail).read_zipper();
                for v85_3_byte in v85_3_cursor.child_mask().iter() {
                  v85_3_cursor.descend_to_byte(v85_3_byte);
                  let v85_3_tail = v85_3_cursor.make_map();
                  v85_3_cursor.ascend(1);
                  let v85_3_head = Path::from_slice(&[v85_3_byte]);
                  let v86_2: Path = concat_path(&(v85_2),&(v85_3_head));
                  let v86_3: Space = routine_11(c, &(v86_2), &(*p1), &(*p0), &(v82_4), &(v85_3_tail), &(v81_3_tail));
                  drop(v86_2);
                  v85_3.join_into((v86_3).clone());
                }
                drop(v85_3_cursor);
                drop(v85_2);
                v84_3.join_into((v85_3).clone());
              }
              drop(v84_3_cursor);
              drop(v84_2);
              v83_2.join_into((v84_3).clone());
            }
            drop(v83_2_cursor);
            v82_5.join_into((v83_2).clone());
          }
          drop(v82_5_cursor);
          drop(v82_3);
          drop(v82_4);
          v81_3.join_into((v82_5).clone());
        }
        drop(v81_3_cursor);
        drop(v81_2);
        v80_3.join_into((v81_3).clone());
      }
      drop(v80_3_cursor);
      drop(v80_2);
      v79_2.join_into((v80_3).clone());
    }
    drop(v79_2_cursor);
    v78_5.join_into((v79_2).clone());
  }
  drop(v78_5_cursor);
  (v78_5).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v87_3 = Space::new();
  let mut v87_3_cursor = (*s0).read_zipper();
  for v87_3_byte in v87_3_cursor.child_mask().iter() {
    v87_3_cursor.descend_to_byte(v87_3_byte);
    let v87_3_tail = v87_3_cursor.make_map();
    v87_3_cursor.ascend(1);
    let v87_3_head = Path::from_slice(&[v87_3_byte]);
    let mut v88_2 = Space::new();
    let mut v88_2_cursor = (v87_3_tail).read_zipper();
    for v88_2_byte in v88_2_cursor.child_mask().iter() {
      v88_2_cursor.descend_to_byte(v88_2_byte);
      let v88_2_tail = v88_2_cursor.make_map();
      v88_2_cursor.ascend(1);
      let v88_2_head = Path::from_slice(&[v88_2_byte]);
      let v89_2: Path = concat_path(&(v87_3_head),&(v88_2_head));
      let mut v89_3 = Space::new();
      let mut v89_3_cursor = (v88_2_tail).read_zipper();
      for v89_3_byte in v89_3_cursor.child_mask().iter() {
        v89_3_cursor.descend_to_byte(v89_3_byte);
        let v89_3_tail = v89_3_cursor.make_map();
        v89_3_cursor.ascend(1);
        let v89_3_head = Path::from_slice(&[v89_3_byte]);
        let v90_2: Path = concat_path(&(v89_2),&(v89_3_head));
        let mut v90_3 = Space::new();
        let mut v90_3_cursor = (v89_3_tail).read_zipper();
        for v90_3_byte in v90_3_cursor.child_mask().iter() {
          v90_3_cursor.descend_to_byte(v90_3_byte);
          let v90_3_tail = v90_3_cursor.make_map();
          v90_3_cursor.ascend(1);
          let v90_3_head = Path::from_slice(&[v90_3_byte]);
          let v91_2: Path = concat_path(&(v90_2),&(v90_3_head));
          let mut v91_3 = Space::new();
          let mut v91_3_cursor = (v90_3_tail).read_zipper();
          for v91_3_byte in v91_3_cursor.child_mask().iter() {
            v91_3_cursor.descend_to_byte(v91_3_byte);
            let v91_3_tail = v91_3_cursor.make_map();
            v91_3_cursor.ascend(1);
            let v91_3_head = Path::from_slice(&[v91_3_byte]);
            let mut v92_2 = Space::new();
            let mut v92_2_cursor = (v91_3_tail).read_zipper();
            for v92_2_byte in v92_2_cursor.child_mask().iter() {
              v92_2_cursor.descend_to_byte(v92_2_byte);
              let v92_2_tail = v92_2_cursor.make_map();
              v92_2_cursor.ascend(1);
              let v92_2_head = Path::from_slice(&[v92_2_byte]);
              let v93_2: Path = concat_path(&(v91_3_head),&(v92_2_head));
              let mut v93_3 = Space::new();
              let mut v93_3_cursor = (v92_2_tail).read_zipper();
              for v93_3_byte in v93_3_cursor.child_mask().iter() {
                v93_3_cursor.descend_to_byte(v93_3_byte);
                let v93_3_tail = v93_3_cursor.make_map();
                v93_3_cursor.ascend(1);
                let v93_3_head = Path::from_slice(&[v93_3_byte]);
                let v94_2: Path = concat_path(&(v93_2),&(v93_3_head));
                let mut v94_3 = Space::new();
                let mut v94_3_cursor = (v93_3_tail).read_zipper();
                for v94_3_byte in v94_3_cursor.child_mask().iter() {
                  v94_3_cursor.descend_to_byte(v94_3_byte);
                  let v94_3_tail = v94_3_cursor.make_map();
                  v94_3_cursor.ascend(1);
                  let v94_3_head = Path::from_slice(&[v94_3_byte]);
                  let v95_2: Path = concat_path(&(v94_2),&(v94_3_head));
                  let v95_3: Space = routine_12(c, &(v95_2), &(*p0), &(v91_2), &(*p1), &(v94_3_tail));
                  drop(v95_2);
                  v94_3.join_into((v95_3).clone());
                }
                drop(v94_3_cursor);
                drop(v94_2);
                v93_3.join_into((v94_3).clone());
              }
              drop(v93_3_cursor);
              drop(v93_2);
              v92_2.join_into((v93_3).clone());
            }
            drop(v92_2_cursor);
            v91_3.join_into((v92_2).clone());
          }
          drop(v91_3_cursor);
          drop(v91_2);
          v90_3.join_into((v91_3).clone());
        }
        drop(v90_3_cursor);
        drop(v90_2);
        v89_3.join_into((v90_3).clone());
      }
      drop(v89_3_cursor);
      drop(v89_2);
      v88_2.join_into((v89_3).clone());
    }
    drop(v88_2_cursor);
    v87_3.join_into((v88_2).clone());
  }
  drop(v87_3_cursor);
  (v87_3).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v96_3 = Space::new();
  let mut v96_3_cursor = (*s0).read_zipper();
  for v96_3_byte in v96_3_cursor.child_mask().iter() {
    v96_3_cursor.descend_to_byte(v96_3_byte);
    let v96_3_tail = v96_3_cursor.make_map();
    v96_3_cursor.ascend(1);
    let v96_3_head = Path::from_slice(&[v96_3_byte]);
    let mut v97_2 = Space::new();
    let mut v97_2_cursor = (v96_3_tail).read_zipper();
    for v97_2_byte in v97_2_cursor.child_mask().iter() {
      v97_2_cursor.descend_to_byte(v97_2_byte);
      let v97_2_tail = v97_2_cursor.make_map();
      v97_2_cursor.ascend(1);
      let v97_2_head = Path::from_slice(&[v97_2_byte]);
      let v98_2: Path = concat_path(&(v96_3_head),&(v97_2_head));
      let mut v98_3 = Space::new();
      let mut v98_3_cursor = (v97_2_tail).read_zipper();
      for v98_3_byte in v98_3_cursor.child_mask().iter() {
        v98_3_cursor.descend_to_byte(v98_3_byte);
        let v98_3_tail = v98_3_cursor.make_map();
        v98_3_cursor.ascend(1);
        let v98_3_head = Path::from_slice(&[v98_3_byte]);
        let v99_2: Path = concat_path(&(v98_2),&(v98_3_head));
        let mut v99_3 = Space::new();
        let mut v99_3_cursor = (v98_3_tail).read_zipper();
        for v99_3_byte in v99_3_cursor.child_mask().iter() {
          v99_3_cursor.descend_to_byte(v99_3_byte);
          let v99_3_tail = v99_3_cursor.make_map();
          v99_3_cursor.ascend(1);
          let v99_3_head = Path::from_slice(&[v99_3_byte]);
          let v100_2: Path = concat_path(&(v99_2),&(v99_3_head));
          let mut v100_3 = Space::new();
          let mut v100_3_cursor = (v99_3_tail).read_zipper();
          for v100_3_byte in v100_3_cursor.child_mask().iter() {
            v100_3_cursor.descend_to_byte(v100_3_byte);
            let v100_3_tail = v100_3_cursor.make_map();
            v100_3_cursor.ascend(1);
            let v100_3_head = Path::from_slice(&[v100_3_byte]);
            let mut v101_2 = Space::new();
            let mut v101_2_cursor = (v100_3_tail).read_zipper();
            for v101_2_byte in v101_2_cursor.child_mask().iter() {
              v101_2_cursor.descend_to_byte(v101_2_byte);
              let v101_2_tail = v101_2_cursor.make_map();
              v101_2_cursor.ascend(1);
              let v101_2_head = Path::from_slice(&[v101_2_byte]);
              let v102_2: Path = concat_path(&(v100_3_head),&(v101_2_head));
              let mut v102_3 = Space::new();
              let mut v102_3_cursor = (v101_2_tail).read_zipper();
              for v102_3_byte in v102_3_cursor.child_mask().iter() {
                v102_3_cursor.descend_to_byte(v102_3_byte);
                let v102_3_tail = v102_3_cursor.make_map();
                v102_3_cursor.ascend(1);
                let v102_3_head = Path::from_slice(&[v102_3_byte]);
                let v103_2: Path = concat_path(&(v102_2),&(v102_3_head));
                let mut v103_3 = Space::new();
                let mut v103_3_cursor = (v102_3_tail).read_zipper();
                for v103_3_byte in v103_3_cursor.child_mask().iter() {
                  v103_3_cursor.descend_to_byte(v103_3_byte);
                  let v103_3_tail = v103_3_cursor.make_map();
                  v103_3_cursor.ascend(1);
                  let v103_3_head = Path::from_slice(&[v103_3_byte]);
                  let v104_2: Path = concat_path(&(v103_2),&(v103_3_head));
                  let v104_3: Space = routine_13(c, &(v104_2), &(*p1), &(*p0), &(v100_2), &(v103_3_tail));
                  drop(v104_2);
                  v103_3.join_into((v104_3).clone());
                }
                drop(v103_3_cursor);
                drop(v103_2);
                v102_3.join_into((v103_3).clone());
              }
              drop(v102_3_cursor);
              drop(v102_2);
              v101_2.join_into((v102_3).clone());
            }
            drop(v101_2_cursor);
            v100_3.join_into((v101_2).clone());
          }
          drop(v100_3_cursor);
          drop(v100_2);
          v99_3.join_into((v100_3).clone());
        }
        drop(v99_3_cursor);
        drop(v99_2);
        v98_3.join_into((v99_3).clone());
      }
      drop(v98_3_cursor);
      drop(v98_2);
      v97_2.join_into((v98_3).clone());
    }
    drop(v97_2_cursor);
    v96_3.join_into((v97_2).clone());
  }
  drop(v96_3_cursor);
  (v96_3).clone()
}

fn routine_7(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v105_3 = Space::new();
  let mut v105_3_cursor = (*s0).read_zipper();
  for v105_3_byte in v105_3_cursor.child_mask().iter() {
    v105_3_cursor.descend_to_byte(v105_3_byte);
    let v105_3_tail = v105_3_cursor.make_map();
    v105_3_cursor.ascend(1);
    let v105_3_head = Path::from_slice(&[v105_3_byte]);
    let mut v106_2 = Space::new();
    let mut v106_2_cursor = (v105_3_tail).read_zipper();
    for v106_2_byte in v106_2_cursor.child_mask().iter() {
      v106_2_cursor.descend_to_byte(v106_2_byte);
      let v106_2_tail = v106_2_cursor.make_map();
      v106_2_cursor.ascend(1);
      let v106_2_head = Path::from_slice(&[v106_2_byte]);
      let v107_2: Path = concat_path(&(v105_3_head),&(v106_2_head));
      let mut v107_3 = Space::new();
      let mut v107_3_cursor = (v106_2_tail).read_zipper();
      for v107_3_byte in v107_3_cursor.child_mask().iter() {
        v107_3_cursor.descend_to_byte(v107_3_byte);
        let v107_3_tail = v107_3_cursor.make_map();
        v107_3_cursor.ascend(1);
        let v107_3_head = Path::from_slice(&[v107_3_byte]);
        let v108_2: Path = concat_path(&(v107_2),&(v107_3_head));
        let mut v108_3 = Space::new();
        let mut v108_3_cursor = (v107_3_tail).read_zipper();
        for v108_3_byte in v108_3_cursor.child_mask().iter() {
          v108_3_cursor.descend_to_byte(v108_3_byte);
          let v108_3_tail = v108_3_cursor.make_map();
          v108_3_cursor.ascend(1);
          let v108_3_head = Path::from_slice(&[v108_3_byte]);
          let v109_2: Path = concat_path(&(v108_2),&(v108_3_head));
          let mut v109_3 = Space::new();
          let mut v109_3_cursor = (v108_3_tail).read_zipper();
          for v109_3_byte in v109_3_cursor.child_mask().iter() {
            v109_3_cursor.descend_to_byte(v109_3_byte);
            let v109_3_tail = v109_3_cursor.make_map();
            v109_3_cursor.ascend(1);
            let v109_3_head = Path::from_slice(&[v109_3_byte]);
            let mut v110_2 = Space::new();
            let mut v110_2_cursor = (v109_3_tail).read_zipper();
            for v110_2_byte in v110_2_cursor.child_mask().iter() {
              v110_2_cursor.descend_to_byte(v110_2_byte);
              let v110_2_tail = v110_2_cursor.make_map();
              v110_2_cursor.ascend(1);
              let v110_2_head = Path::from_slice(&[v110_2_byte]);
              let v111_2: Path = concat_path(&(v109_3_head),&(v110_2_head));
              let mut v111_3 = Space::new();
              let mut v111_3_cursor = (v110_2_tail).read_zipper();
              for v111_3_byte in v111_3_cursor.child_mask().iter() {
                v111_3_cursor.descend_to_byte(v111_3_byte);
                let v111_3_tail = v111_3_cursor.make_map();
                v111_3_cursor.ascend(1);
                let v111_3_head = Path::from_slice(&[v111_3_byte]);
                let v112_2: Path = concat_path(&(v111_2),&(v111_3_head));
                let mut v112_3 = Space::new();
                let mut v112_3_cursor = (v111_3_tail).read_zipper();
                for v112_3_byte in v112_3_cursor.child_mask().iter() {
                  v112_3_cursor.descend_to_byte(v112_3_byte);
                  let v112_3_tail = v112_3_cursor.make_map();
                  v112_3_cursor.ascend(1);
                  let v112_3_head = Path::from_slice(&[v112_3_byte]);
                  let v113_2: Path = concat_path(&(v112_2),&(v112_3_head));
                  let v113_3: Space = routine_14(c, &(v113_2), &(*p1), &(*p0), &(v109_2), &(v112_3_tail));
                  drop(v113_2);
                  v112_3.join_into((v113_3).clone());
                }
                drop(v112_3_cursor);
                drop(v112_2);
                v111_3.join_into((v112_3).clone());
              }
              drop(v111_3_cursor);
              drop(v111_2);
              v110_2.join_into((v111_3).clone());
            }
            drop(v110_2_cursor);
            v109_3.join_into((v110_2).clone());
          }
          drop(v109_3_cursor);
          drop(v109_2);
          v108_3.join_into((v109_3).clone());
        }
        drop(v108_3_cursor);
        drop(v108_2);
        v107_3.join_into((v108_3).clone());
      }
      drop(v107_3_cursor);
      drop(v107_2);
      v106_2.join_into((v107_3).clone());
    }
    drop(v106_2_cursor);
    v105_3.join_into((v106_2).clone());
  }
  drop(v105_3_cursor);
  (v105_3).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v114_3 = Space::new();
  let mut v114_3_cursor = (*s0).read_zipper();
  for v114_3_byte in v114_3_cursor.child_mask().iter() {
    v114_3_cursor.descend_to_byte(v114_3_byte);
    let v114_3_tail = v114_3_cursor.make_map();
    v114_3_cursor.ascend(1);
    let v114_3_head = Path::from_slice(&[v114_3_byte]);
    let mut v115_2 = Space::new();
    let mut v115_2_cursor = (v114_3_tail).read_zipper();
    for v115_2_byte in v115_2_cursor.child_mask().iter() {
      v115_2_cursor.descend_to_byte(v115_2_byte);
      let v115_2_tail = v115_2_cursor.make_map();
      v115_2_cursor.ascend(1);
      let v115_2_head = Path::from_slice(&[v115_2_byte]);
      let v116_2: Path = concat_path(&(v114_3_head),&(v115_2_head));
      let mut v116_3 = Space::new();
      let mut v116_3_cursor = (v115_2_tail).read_zipper();
      for v116_3_byte in v116_3_cursor.child_mask().iter() {
        v116_3_cursor.descend_to_byte(v116_3_byte);
        let v116_3_tail = v116_3_cursor.make_map();
        v116_3_cursor.ascend(1);
        let v116_3_head = Path::from_slice(&[v116_3_byte]);
        let v117_2: Path = concat_path(&(v116_2),&(v116_3_head));
        let mut v117_3 = Space::new();
        let mut v117_3_cursor = (v116_3_tail).read_zipper();
        for v117_3_byte in v117_3_cursor.child_mask().iter() {
          v117_3_cursor.descend_to_byte(v117_3_byte);
          let v117_3_tail = v117_3_cursor.make_map();
          v117_3_cursor.ascend(1);
          let v117_3_head = Path::from_slice(&[v117_3_byte]);
          let v118_2: Path = concat_path(&(v117_2),&(v117_3_head));
          let mut v118_3 = Space::new();
          let mut v118_3_cursor = (v117_3_tail).read_zipper();
          for v118_3_byte in v118_3_cursor.child_mask().iter() {
            v118_3_cursor.descend_to_byte(v118_3_byte);
            let v118_3_tail = v118_3_cursor.make_map();
            v118_3_cursor.ascend(1);
            let v118_3_head = Path::from_slice(&[v118_3_byte]);
            let mut v119_2 = Space::new();
            let mut v119_2_cursor = (v118_3_tail).read_zipper();
            for v119_2_byte in v119_2_cursor.child_mask().iter() {
              v119_2_cursor.descend_to_byte(v119_2_byte);
              let v119_2_tail = v119_2_cursor.make_map();
              v119_2_cursor.ascend(1);
              let v119_2_head = Path::from_slice(&[v119_2_byte]);
              let v120_2: Path = concat_path(&(v118_3_head),&(v119_2_head));
              let mut v120_3 = Space::new();
              let mut v120_3_cursor = (v119_2_tail).read_zipper();
              for v120_3_byte in v120_3_cursor.child_mask().iter() {
                v120_3_cursor.descend_to_byte(v120_3_byte);
                let v120_3_tail = v120_3_cursor.make_map();
                v120_3_cursor.ascend(1);
                let v120_3_head = Path::from_slice(&[v120_3_byte]);
                let v121_2: Path = concat_path(&(v120_2),&(v120_3_head));
                let mut v121_3 = Space::new();
                let mut v121_3_cursor = (v120_3_tail).read_zipper();
                for v121_3_byte in v121_3_cursor.child_mask().iter() {
                  v121_3_cursor.descend_to_byte(v121_3_byte);
                  let v121_3_tail = v121_3_cursor.make_map();
                  v121_3_cursor.ascend(1);
                  let v121_3_head = Path::from_slice(&[v121_3_byte]);
                  let v122_2: Path = concat_path(&(v121_2),&(v121_3_head));
                  let v122_3: Space = routine_15(c, &(v122_2), &(*p1), &(*p0), &(v118_2), &(v121_3_tail));
                  drop(v122_2);
                  v121_3.join_into((v122_3).clone());
                }
                drop(v121_3_cursor);
                drop(v121_2);
                v120_3.join_into((v121_3).clone());
              }
              drop(v120_3_cursor);
              drop(v120_2);
              v119_2.join_into((v120_3).clone());
            }
            drop(v119_2_cursor);
            v118_3.join_into((v119_2).clone());
          }
          drop(v118_3_cursor);
          drop(v118_2);
          v117_3.join_into((v118_3).clone());
        }
        drop(v117_3_cursor);
        drop(v117_2);
        v116_3.join_into((v117_3).clone());
      }
      drop(v116_3_cursor);
      drop(v116_2);
      v115_2.join_into((v116_3).clone());
    }
    drop(v115_2_cursor);
    v114_3.join_into((v115_2).clone());
  }
  drop(v114_3_cursor);
  (v114_3).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v123_3 = Space::new();
  let mut v123_3_cursor = (*s0).read_zipper();
  for v123_3_byte in v123_3_cursor.child_mask().iter() {
    v123_3_cursor.descend_to_byte(v123_3_byte);
    let v123_3_tail = v123_3_cursor.make_map();
    v123_3_cursor.ascend(1);
    let v123_3_head = Path::from_slice(&[v123_3_byte]);
    let mut v124_2 = Space::new();
    let mut v124_2_cursor = (v123_3_tail).read_zipper();
    for v124_2_byte in v124_2_cursor.child_mask().iter() {
      v124_2_cursor.descend_to_byte(v124_2_byte);
      let v124_2_tail = v124_2_cursor.make_map();
      v124_2_cursor.ascend(1);
      let v124_2_head = Path::from_slice(&[v124_2_byte]);
      let v125_2: Path = concat_path(&(v123_3_head),&(v124_2_head));
      let mut v125_3 = Space::new();
      let mut v125_3_cursor = (v124_2_tail).read_zipper();
      for v125_3_byte in v125_3_cursor.child_mask().iter() {
        v125_3_cursor.descend_to_byte(v125_3_byte);
        let v125_3_tail = v125_3_cursor.make_map();
        v125_3_cursor.ascend(1);
        let v125_3_head = Path::from_slice(&[v125_3_byte]);
        let v126_2: Path = concat_path(&(v125_2),&(v125_3_head));
        let mut v126_3 = Space::new();
        let mut v126_3_cursor = (v125_3_tail).read_zipper();
        for v126_3_byte in v126_3_cursor.child_mask().iter() {
          v126_3_cursor.descend_to_byte(v126_3_byte);
          let v126_3_tail = v126_3_cursor.make_map();
          v126_3_cursor.ascend(1);
          let v126_3_head = Path::from_slice(&[v126_3_byte]);
          let v127_2: Path = concat_path(&(v126_2),&(v126_3_head));
          let mut v127_3 = Space::new();
          let mut v127_3_cursor = (v126_3_tail).read_zipper();
          for v127_3_byte in v127_3_cursor.child_mask().iter() {
            v127_3_cursor.descend_to_byte(v127_3_byte);
            let v127_3_tail = v127_3_cursor.make_map();
            v127_3_cursor.ascend(1);
            let v127_3_head = Path::from_slice(&[v127_3_byte]);
            let mut v128_2 = Space::new();
            let mut v128_2_cursor = (v127_3_tail).read_zipper();
            for v128_2_byte in v128_2_cursor.child_mask().iter() {
              v128_2_cursor.descend_to_byte(v128_2_byte);
              let v128_2_tail = v128_2_cursor.make_map();
              v128_2_cursor.ascend(1);
              let v128_2_head = Path::from_slice(&[v128_2_byte]);
              let v129_2: Path = concat_path(&(v127_3_head),&(v128_2_head));
              let mut v129_3 = Space::new();
              let mut v129_3_cursor = (v128_2_tail).read_zipper();
              for v129_3_byte in v129_3_cursor.child_mask().iter() {
                v129_3_cursor.descend_to_byte(v129_3_byte);
                let v129_3_tail = v129_3_cursor.make_map();
                v129_3_cursor.ascend(1);
                let v129_3_head = Path::from_slice(&[v129_3_byte]);
                let v130_2: Path = concat_path(&(v129_2),&(v129_3_head));
                let mut v130_3 = Space::new();
                let mut v130_3_cursor = (v129_3_tail).read_zipper();
                for v130_3_byte in v130_3_cursor.child_mask().iter() {
                  v130_3_cursor.descend_to_byte(v130_3_byte);
                  let v130_3_tail = v130_3_cursor.make_map();
                  v130_3_cursor.ascend(1);
                  let v130_3_head = Path::from_slice(&[v130_3_byte]);
                  let v131_2: Path = concat_path(&(v130_2),&(v130_3_head));
                  let v131_3: Space = routine_16(c, &(v131_2), &(*p1), &(*p0), &(v127_2), &(v130_3_tail));
                  drop(v131_2);
                  v130_3.join_into((v131_3).clone());
                }
                drop(v130_3_cursor);
                drop(v130_2);
                v129_3.join_into((v130_3).clone());
              }
              drop(v129_3_cursor);
              drop(v129_2);
              v128_2.join_into((v129_3).clone());
            }
            drop(v128_2_cursor);
            v127_3.join_into((v128_2).clone());
          }
          drop(v127_3_cursor);
          drop(v127_2);
          v126_3.join_into((v127_3).clone());
        }
        drop(v126_3_cursor);
        drop(v126_2);
        v125_3.join_into((v126_3).clone());
      }
      drop(v125_3_cursor);
      drop(v125_2);
      v124_2.join_into((v125_3).clone());
    }
    drop(v124_2_cursor);
    v123_3.join_into((v124_2).clone());
  }
  drop(v123_3_cursor);
  (v123_3).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v132_5: Space = unwrap(&(*CONSTANT_11),&(*p1));
  let v132_6: Space = unwrap(&(v132_5),&(*p0));
  drop(v132_5);
  let v132_10: Space = if (v132_6).is_empty() { Space::new() } else {
    let v133_8: Space = unwrap(&(*CONSTANT_11),&(*p2));
    let v133_9: Space = unwrap(&(v133_8),&(*p0));
    drop(v133_8);
    compose(&(v132_6),&(v133_9))
  };
  drop(v132_6);
  let v132_11: Path = concat_path(&(*p0),&(*p2));
  let v132_12: Space = singleton(&(v132_11));
  drop(v132_11);
  let v132_13: Space = unite(&(v132_10),&(v132_12));
  drop(v132_10);
  drop(v132_12);
  let v132_14: Path = concat_path(&(*p1),&(*p0));
  let v132_15: Space = singleton(&(v132_14));
  drop(v132_14);
  let v132_16: Space = unite(&(v132_13),&(v132_15));
  drop(v132_13);
  drop(v132_15);
  (v132_16).clone()
}

fn routine_11(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space, s1: &Space) -> Space {
  let v134_9: Space = routine_10(c, &(*CONSTANT_0), &(*CONSTANT_5), &(*p0), &(*CONSTANT_12));
  let v134_12: Space = routine_10(c, &(*CONSTANT_3), &(*CONSTANT_5), &(*p0), &(*CONSTANT_12));
  let v134_13: Space = unite(&(v134_9),&(v134_12));
  let v134_16: Space = routine_10(c, &(*CONSTANT_4), &(*CONSTANT_5), &(*p0), &(*CONSTANT_12));
  let v134_17: Space = unite(&(v134_13),&(v134_16));
  let v134_19: Space = routine_10(c, &(*CONSTANT_5), &(*CONSTANT_5), &(*p0), &(*CONSTANT_12));
  let v134_20: Space = unite(&(v134_17),&(v134_19));
  let v134_23: Space = routine_10(c, &(*CONSTANT_6), &(*CONSTANT_5), &(*p0), &(*CONSTANT_12));
  let v134_24: Space = unite(&(v134_20),&(v134_23));
  let v134_27: Space = routine_10(c, &(*CONSTANT_7), &(*CONSTANT_5), &(*p0), &(*CONSTANT_12));
  let v134_28: Space = unite(&(v134_24),&(v134_27));
  let v134_31: Space = routine_10(c, &(*CONSTANT_8), &(*CONSTANT_5), &(*p0), &(*CONSTANT_12));
  let v134_32: Space = unite(&(v134_28),&(v134_31));
  let v134_35: Space = routine_10(c, &(*CONSTANT_1), &(*CONSTANT_5), &(*p0), &(*CONSTANT_12));
  let v134_36: Space = unite(&(v134_32),&(v134_35));
  let v134_38: Space = intersect(&(v134_36),&(*CONSTANT_13));
  let v134_39: Space = unite(&(v134_38),&(*s1));
  let v134_40: Path = concat_path(&(*p1),&(*p2));
  let v134_41: Path = concat_path(&(v134_40),&(*p3));
  drop(v134_40);
  let v134_42: Space = wrap(&(v134_39),&(v134_41));
  drop(v134_41);
  let v134_43: Space = wrap(&(v134_42),&(*p0));
  (v134_43).clone()
}

fn routine_12(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let v135_7: Space = unwrap(&(*s0),&(*CONSTANT_6));
  let v135_8: Space = subtract(&(*CONSTANT_9),&(v135_7));
  drop(v135_7);
  let v135_10: Path = concat_path(&(*p3),&(*p1));
  let v135_11: Path = concat_path(&(v135_10),&(*p2));
  drop(v135_10);
  let v135_12: Path = concat_path(&(v135_11),&(*p0));
  drop(v135_11);
  let mut v135_13 = Space::new();
  let mut v135_13_cursor = (v135_8).read_zipper();
  for v135_13_byte in v135_13_cursor.child_mask().iter() {
    v135_13_cursor.descend_to_byte(v135_13_byte);
    let v135_13_tail = v135_13_cursor.make_map();
    v135_13_cursor.ascend(1);
    let v135_13_head = Path::from_slice(&[v135_13_byte]);
    let mut v136_2 = Space::new();
    let mut v136_2_cursor = (v135_13_tail).read_zipper();
    for v136_2_byte in v136_2_cursor.child_mask().iter() {
      v136_2_cursor.descend_to_byte(v136_2_byte);
      let v136_2_tail = v136_2_cursor.make_map();
      v136_2_cursor.ascend(1);
      let v136_2_head = Path::from_slice(&[v136_2_byte]);
      let v137_2: Path = concat_path(&(v135_13_head),&(v136_2_head));
      let mut v137_3 = Space::new();
      let mut v137_3_cursor = (v136_2_tail).read_zipper();
      for v137_3_byte in v137_3_cursor.child_mask().iter() {
        v137_3_cursor.descend_to_byte(v137_3_byte);
        let v137_3_tail = v137_3_cursor.make_map();
        v137_3_cursor.ascend(1);
        let v137_3_head = Path::from_slice(&[v137_3_byte]);
        let v138_2: Path = concat_path(&(v137_2),&(v137_3_head));
        let mut v138_3 = Space::new();
        let mut v138_3_cursor = (v137_3_tail).read_zipper();
        for v138_3_byte in v138_3_cursor.child_mask().iter() {
          v138_3_cursor.descend_to_byte(v138_3_byte);
          let v138_3_tail = v138_3_cursor.make_map();
          v138_3_cursor.ascend(1);
          let v138_3_head = Path::from_slice(&[v138_3_byte]);
          let v139_2: Path = concat_path(&(v138_2),&(v138_3_head));
          let v139_3: Space = routine_1(c, &(v139_2), &(*CONSTANT_6), &(*CONSTANT_1));
          let v139_4: Space = unite(&(*s0),&(v139_3));
          let v139_5: Space = wrap(&(v139_4),&(v135_12));
          let v139_6: Space = wrap(&(v139_5),&(v139_2));
          drop(v139_2);
          v138_3.join_into((v139_6).clone());
        }
        drop(v138_3_cursor);
        drop(v138_2);
        v137_3.join_into((v138_3).clone());
      }
      drop(v137_3_cursor);
      drop(v137_2);
      v136_2.join_into((v137_3).clone());
    }
    drop(v136_2_cursor);
    v135_13.join_into((v136_2).clone());
  }
  drop(v135_13_cursor);
  drop(v135_8);
  drop(v135_12);
  (v135_13).clone()
}

fn routine_13(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v140_7 = Space::new();
  let mut v140_7_cursor = (*s0).read_zipper();
  for v140_7_byte in v140_7_cursor.child_mask().iter() {
    v140_7_cursor.descend_to_byte(v140_7_byte);
    let v140_7_tail = v140_7_cursor.make_map();
    v140_7_cursor.ascend(1);
    let v140_7_head = Path::from_slice(&[v140_7_byte]);
    let mut v141_2 = Space::new();
    let mut v141_2_cursor = (v140_7_tail).read_zipper();
    for v141_2_byte in v141_2_cursor.child_mask().iter() {
      v141_2_cursor.descend_to_byte(v141_2_byte);
      let v141_2_tail = v141_2_cursor.make_map();
      v141_2_cursor.ascend(1);
      let v141_2_head = Path::from_slice(&[v141_2_byte]);
      let v142_2: Path = concat_path(&(v140_7_head),&(v141_2_head));
      let mut v142_3 = Space::new();
      let mut v142_3_cursor = (v141_2_tail).read_zipper();
      for v142_3_byte in v142_3_cursor.child_mask().iter() {
        v142_3_cursor.descend_to_byte(v142_3_byte);
        let v142_3_tail = v142_3_cursor.make_map();
        v142_3_cursor.ascend(1);
        let v142_3_head = Path::from_slice(&[v142_3_byte]);
        let v143_2: Path = concat_path(&(v142_2),&(v142_3_head));
        let mut v143_3 = Space::new();
        let mut v143_3_cursor = (v142_3_tail).read_zipper();
        for v143_3_byte in v143_3_cursor.child_mask().iter() {
          v143_3_cursor.descend_to_byte(v143_3_byte);
          let v143_3_tail = v143_3_cursor.make_map();
          v143_3_cursor.ascend(1);
          let v143_3_head = Path::from_slice(&[v143_3_byte]);
          let v144_2: Space = unwrap(&(v143_3_tail),&(*CONSTANT_7));
          let v144_3: Space = subtract(&(*CONSTANT_9),&(v144_2));
          drop(v144_2);
          let v144_4: Path = concat_path(&(v143_2),&(v143_3_head));
          let mut v144_5 = Space::new();
          let mut v144_5_cursor = (v144_3).read_zipper();
          for v144_5_byte in v144_5_cursor.child_mask().iter() {
            v144_5_cursor.descend_to_byte(v144_5_byte);
            let v144_5_tail = v144_5_cursor.make_map();
            v144_5_cursor.ascend(1);
            let v144_5_head = Path::from_slice(&[v144_5_byte]);
            let mut v145_2 = Space::new();
            let mut v145_2_cursor = (v144_5_tail).read_zipper();
            for v145_2_byte in v145_2_cursor.child_mask().iter() {
              v145_2_cursor.descend_to_byte(v145_2_byte);
              let v145_2_tail = v145_2_cursor.make_map();
              v145_2_cursor.ascend(1);
              let v145_2_head = Path::from_slice(&[v145_2_byte]);
              let v146_2: Path = concat_path(&(v144_5_head),&(v145_2_head));
              let mut v146_3 = Space::new();
              let mut v146_3_cursor = (v145_2_tail).read_zipper();
              for v146_3_byte in v146_3_cursor.child_mask().iter() {
                v146_3_cursor.descend_to_byte(v146_3_byte);
                let v146_3_tail = v146_3_cursor.make_map();
                v146_3_cursor.ascend(1);
                let v146_3_head = Path::from_slice(&[v146_3_byte]);
                let v147_2: Path = concat_path(&(v146_2),&(v146_3_head));
                let mut v147_3 = Space::new();
                let mut v147_3_cursor = (v146_3_tail).read_zipper();
                for v147_3_byte in v147_3_cursor.child_mask().iter() {
                  v147_3_cursor.descend_to_byte(v147_3_byte);
                  let v147_3_tail = v147_3_cursor.make_map();
                  v147_3_cursor.ascend(1);
                  let v147_3_head = Path::from_slice(&[v147_3_byte]);
                  let v148_2: Path = concat_path(&(v147_2),&(v147_3_head));
                  let v148_3: Space = routine_17(c, &(v148_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v144_4), &(v147_3_tail), &(v143_3_tail));
                  drop(v148_2);
                  v147_3.join_into((v148_3).clone());
                }
                drop(v147_3_cursor);
                drop(v147_2);
                v146_3.join_into((v147_3).clone());
              }
              drop(v146_3_cursor);
              drop(v146_2);
              v145_2.join_into((v146_3).clone());
            }
            drop(v145_2_cursor);
            v144_5.join_into((v145_2).clone());
          }
          drop(v144_5_cursor);
          drop(v144_3);
          drop(v144_4);
          v143_3.join_into((v144_5).clone());
        }
        drop(v143_3_cursor);
        drop(v143_2);
        v142_3.join_into((v143_3).clone());
      }
      drop(v142_3_cursor);
      drop(v142_2);
      v141_2.join_into((v142_3).clone());
    }
    drop(v141_2_cursor);
    v140_7.join_into((v141_2).clone());
  }
  drop(v140_7_cursor);
  (v140_7).clone()
}

fn routine_14(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v149_5 = Space::new();
  let mut v149_5_cursor = (*s0).read_zipper();
  for v149_5_byte in v149_5_cursor.child_mask().iter() {
    v149_5_cursor.descend_to_byte(v149_5_byte);
    let v149_5_tail = v149_5_cursor.make_map();
    v149_5_cursor.ascend(1);
    let v149_5_head = Path::from_slice(&[v149_5_byte]);
    let mut v150_2 = Space::new();
    let mut v150_2_cursor = (v149_5_tail).read_zipper();
    for v150_2_byte in v150_2_cursor.child_mask().iter() {
      v150_2_cursor.descend_to_byte(v150_2_byte);
      let v150_2_tail = v150_2_cursor.make_map();
      v150_2_cursor.ascend(1);
      let v150_2_head = Path::from_slice(&[v150_2_byte]);
      let v151_2: Path = concat_path(&(v149_5_head),&(v150_2_head));
      let mut v151_3 = Space::new();
      let mut v151_3_cursor = (v150_2_tail).read_zipper();
      for v151_3_byte in v151_3_cursor.child_mask().iter() {
        v151_3_cursor.descend_to_byte(v151_3_byte);
        let v151_3_tail = v151_3_cursor.make_map();
        v151_3_cursor.ascend(1);
        let v151_3_head = Path::from_slice(&[v151_3_byte]);
        let v152_2: Path = concat_path(&(v151_2),&(v151_3_head));
        let mut v152_3 = Space::new();
        let mut v152_3_cursor = (v151_3_tail).read_zipper();
        for v152_3_byte in v152_3_cursor.child_mask().iter() {
          v152_3_cursor.descend_to_byte(v152_3_byte);
          let v152_3_tail = v152_3_cursor.make_map();
          v152_3_cursor.ascend(1);
          let v152_3_head = Path::from_slice(&[v152_3_byte]);
          let v153_2: Path = concat_path(&(v152_2),&(v152_3_head));
          let mut v153_3 = Space::new();
          let mut v153_3_cursor = (v152_3_tail).read_zipper();
          for v153_3_byte in v153_3_cursor.child_mask().iter() {
            v153_3_cursor.descend_to_byte(v153_3_byte);
            let v153_3_tail = v153_3_cursor.make_map();
            v153_3_cursor.ascend(1);
            let v153_3_head = Path::from_slice(&[v153_3_byte]);
            let mut v154_2 = Space::new();
            let mut v154_2_cursor = (v153_3_tail).read_zipper();
            for v154_2_byte in v154_2_cursor.child_mask().iter() {
              v154_2_cursor.descend_to_byte(v154_2_byte);
              let v154_2_tail = v154_2_cursor.make_map();
              v154_2_cursor.ascend(1);
              let v154_2_head = Path::from_slice(&[v154_2_byte]);
              let v155_2: Path = concat_path(&(v153_3_head),&(v154_2_head));
              let mut v155_3 = Space::new();
              let mut v155_3_cursor = (v154_2_tail).read_zipper();
              for v155_3_byte in v155_3_cursor.child_mask().iter() {
                v155_3_cursor.descend_to_byte(v155_3_byte);
                let v155_3_tail = v155_3_cursor.make_map();
                v155_3_cursor.ascend(1);
                let v155_3_head = Path::from_slice(&[v155_3_byte]);
                let v156_2: Path = concat_path(&(v155_2),&(v155_3_head));
                let mut v156_3 = Space::new();
                let mut v156_3_cursor = (v155_3_tail).read_zipper();
                for v156_3_byte in v156_3_cursor.child_mask().iter() {
                  v156_3_cursor.descend_to_byte(v156_3_byte);
                  let v156_3_tail = v156_3_cursor.make_map();
                  v156_3_cursor.ascend(1);
                  let v156_3_head = Path::from_slice(&[v156_3_byte]);
                  let v157_2: Path = concat_path(&(v156_2),&(v156_3_head));
                  let v157_3: Space = routine_18(c, &(v157_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v153_2), &(v156_3_tail));
                  drop(v157_2);
                  v156_3.join_into((v157_3).clone());
                }
                drop(v156_3_cursor);
                drop(v156_2);
                v155_3.join_into((v156_3).clone());
              }
              drop(v155_3_cursor);
              drop(v155_2);
              v154_2.join_into((v155_3).clone());
            }
            drop(v154_2_cursor);
            v153_3.join_into((v154_2).clone());
          }
          drop(v153_3_cursor);
          drop(v153_2);
          v152_3.join_into((v153_3).clone());
        }
        drop(v152_3_cursor);
        drop(v152_2);
        v151_3.join_into((v152_3).clone());
      }
      drop(v151_3_cursor);
      drop(v151_2);
      v150_2.join_into((v151_3).clone());
    }
    drop(v150_2_cursor);
    v149_5.join_into((v150_2).clone());
  }
  drop(v149_5_cursor);
  (v149_5).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v158_5 = Space::new();
  let mut v158_5_cursor = (*s0).read_zipper();
  for v158_5_byte in v158_5_cursor.child_mask().iter() {
    v158_5_cursor.descend_to_byte(v158_5_byte);
    let v158_5_tail = v158_5_cursor.make_map();
    v158_5_cursor.ascend(1);
    let v158_5_head = Path::from_slice(&[v158_5_byte]);
    let mut v159_2 = Space::new();
    let mut v159_2_cursor = (v158_5_tail).read_zipper();
    for v159_2_byte in v159_2_cursor.child_mask().iter() {
      v159_2_cursor.descend_to_byte(v159_2_byte);
      let v159_2_tail = v159_2_cursor.make_map();
      v159_2_cursor.ascend(1);
      let v159_2_head = Path::from_slice(&[v159_2_byte]);
      let v160_2: Path = concat_path(&(v158_5_head),&(v159_2_head));
      let mut v160_3 = Space::new();
      let mut v160_3_cursor = (v159_2_tail).read_zipper();
      for v160_3_byte in v160_3_cursor.child_mask().iter() {
        v160_3_cursor.descend_to_byte(v160_3_byte);
        let v160_3_tail = v160_3_cursor.make_map();
        v160_3_cursor.ascend(1);
        let v160_3_head = Path::from_slice(&[v160_3_byte]);
        let v161_2: Path = concat_path(&(v160_2),&(v160_3_head));
        let mut v161_3 = Space::new();
        let mut v161_3_cursor = (v160_3_tail).read_zipper();
        for v161_3_byte in v161_3_cursor.child_mask().iter() {
          v161_3_cursor.descend_to_byte(v161_3_byte);
          let v161_3_tail = v161_3_cursor.make_map();
          v161_3_cursor.ascend(1);
          let v161_3_head = Path::from_slice(&[v161_3_byte]);
          let v162_2: Path = concat_path(&(v161_2),&(v161_3_head));
          let mut v162_3 = Space::new();
          let mut v162_3_cursor = (v161_3_tail).read_zipper();
          for v162_3_byte in v162_3_cursor.child_mask().iter() {
            v162_3_cursor.descend_to_byte(v162_3_byte);
            let v162_3_tail = v162_3_cursor.make_map();
            v162_3_cursor.ascend(1);
            let v162_3_head = Path::from_slice(&[v162_3_byte]);
            let mut v163_2 = Space::new();
            let mut v163_2_cursor = (v162_3_tail).read_zipper();
            for v163_2_byte in v163_2_cursor.child_mask().iter() {
              v163_2_cursor.descend_to_byte(v163_2_byte);
              let v163_2_tail = v163_2_cursor.make_map();
              v163_2_cursor.ascend(1);
              let v163_2_head = Path::from_slice(&[v163_2_byte]);
              let v164_2: Path = concat_path(&(v162_3_head),&(v163_2_head));
              let mut v164_3 = Space::new();
              let mut v164_3_cursor = (v163_2_tail).read_zipper();
              for v164_3_byte in v164_3_cursor.child_mask().iter() {
                v164_3_cursor.descend_to_byte(v164_3_byte);
                let v164_3_tail = v164_3_cursor.make_map();
                v164_3_cursor.ascend(1);
                let v164_3_head = Path::from_slice(&[v164_3_byte]);
                let v165_2: Path = concat_path(&(v164_2),&(v164_3_head));
                let mut v165_3 = Space::new();
                let mut v165_3_cursor = (v164_3_tail).read_zipper();
                for v165_3_byte in v165_3_cursor.child_mask().iter() {
                  v165_3_cursor.descend_to_byte(v165_3_byte);
                  let v165_3_tail = v165_3_cursor.make_map();
                  v165_3_cursor.ascend(1);
                  let v165_3_head = Path::from_slice(&[v165_3_byte]);
                  let v166_2: Path = concat_path(&(v165_2),&(v165_3_head));
                  let v166_3: Space = routine_19(c, &(v166_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v162_2), &(v165_3_tail));
                  drop(v166_2);
                  v165_3.join_into((v166_3).clone());
                }
                drop(v165_3_cursor);
                drop(v165_2);
                v164_3.join_into((v165_3).clone());
              }
              drop(v164_3_cursor);
              drop(v164_2);
              v163_2.join_into((v164_3).clone());
            }
            drop(v163_2_cursor);
            v162_3.join_into((v163_2).clone());
          }
          drop(v162_3_cursor);
          drop(v162_2);
          v161_3.join_into((v162_3).clone());
        }
        drop(v161_3_cursor);
        drop(v161_2);
        v160_3.join_into((v161_3).clone());
      }
      drop(v160_3_cursor);
      drop(v160_2);
      v159_2.join_into((v160_3).clone());
    }
    drop(v159_2_cursor);
    v158_5.join_into((v159_2).clone());
  }
  drop(v158_5_cursor);
  (v158_5).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v167_5 = Space::new();
  let mut v167_5_cursor = (*s0).read_zipper();
  for v167_5_byte in v167_5_cursor.child_mask().iter() {
    v167_5_cursor.descend_to_byte(v167_5_byte);
    let v167_5_tail = v167_5_cursor.make_map();
    v167_5_cursor.ascend(1);
    let v167_5_head = Path::from_slice(&[v167_5_byte]);
    let mut v168_2 = Space::new();
    let mut v168_2_cursor = (v167_5_tail).read_zipper();
    for v168_2_byte in v168_2_cursor.child_mask().iter() {
      v168_2_cursor.descend_to_byte(v168_2_byte);
      let v168_2_tail = v168_2_cursor.make_map();
      v168_2_cursor.ascend(1);
      let v168_2_head = Path::from_slice(&[v168_2_byte]);
      let v169_2: Path = concat_path(&(v167_5_head),&(v168_2_head));
      let mut v169_3 = Space::new();
      let mut v169_3_cursor = (v168_2_tail).read_zipper();
      for v169_3_byte in v169_3_cursor.child_mask().iter() {
        v169_3_cursor.descend_to_byte(v169_3_byte);
        let v169_3_tail = v169_3_cursor.make_map();
        v169_3_cursor.ascend(1);
        let v169_3_head = Path::from_slice(&[v169_3_byte]);
        let v170_2: Path = concat_path(&(v169_2),&(v169_3_head));
        let mut v170_3 = Space::new();
        let mut v170_3_cursor = (v169_3_tail).read_zipper();
        for v170_3_byte in v170_3_cursor.child_mask().iter() {
          v170_3_cursor.descend_to_byte(v170_3_byte);
          let v170_3_tail = v170_3_cursor.make_map();
          v170_3_cursor.ascend(1);
          let v170_3_head = Path::from_slice(&[v170_3_byte]);
          let v171_2: Path = concat_path(&(v170_2),&(v170_3_head));
          let mut v171_3 = Space::new();
          let mut v171_3_cursor = (v170_3_tail).read_zipper();
          for v171_3_byte in v171_3_cursor.child_mask().iter() {
            v171_3_cursor.descend_to_byte(v171_3_byte);
            let v171_3_tail = v171_3_cursor.make_map();
            v171_3_cursor.ascend(1);
            let v171_3_head = Path::from_slice(&[v171_3_byte]);
            let mut v172_2 = Space::new();
            let mut v172_2_cursor = (v171_3_tail).read_zipper();
            for v172_2_byte in v172_2_cursor.child_mask().iter() {
              v172_2_cursor.descend_to_byte(v172_2_byte);
              let v172_2_tail = v172_2_cursor.make_map();
              v172_2_cursor.ascend(1);
              let v172_2_head = Path::from_slice(&[v172_2_byte]);
              let v173_2: Path = concat_path(&(v171_3_head),&(v172_2_head));
              let mut v173_3 = Space::new();
              let mut v173_3_cursor = (v172_2_tail).read_zipper();
              for v173_3_byte in v173_3_cursor.child_mask().iter() {
                v173_3_cursor.descend_to_byte(v173_3_byte);
                let v173_3_tail = v173_3_cursor.make_map();
                v173_3_cursor.ascend(1);
                let v173_3_head = Path::from_slice(&[v173_3_byte]);
                let v174_2: Path = concat_path(&(v173_2),&(v173_3_head));
                let mut v174_3 = Space::new();
                let mut v174_3_cursor = (v173_3_tail).read_zipper();
                for v174_3_byte in v174_3_cursor.child_mask().iter() {
                  v174_3_cursor.descend_to_byte(v174_3_byte);
                  let v174_3_tail = v174_3_cursor.make_map();
                  v174_3_cursor.ascend(1);
                  let v174_3_head = Path::from_slice(&[v174_3_byte]);
                  let v175_2: Path = concat_path(&(v174_2),&(v174_3_head));
                  let v175_3: Space = routine_20(c, &(v175_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v171_2), &(v174_3_tail));
                  drop(v175_2);
                  v174_3.join_into((v175_3).clone());
                }
                drop(v174_3_cursor);
                drop(v174_2);
                v173_3.join_into((v174_3).clone());
              }
              drop(v173_3_cursor);
              drop(v173_2);
              v172_2.join_into((v173_3).clone());
            }
            drop(v172_2_cursor);
            v171_3.join_into((v172_2).clone());
          }
          drop(v171_3_cursor);
          drop(v171_2);
          v170_3.join_into((v171_3).clone());
        }
        drop(v170_3_cursor);
        drop(v170_2);
        v169_3.join_into((v170_3).clone());
      }
      drop(v169_3_cursor);
      drop(v169_2);
      v168_2.join_into((v169_3).clone());
    }
    drop(v168_2_cursor);
    v167_5.join_into((v168_2).clone());
  }
  drop(v167_5_cursor);
  (v167_5).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space, s1: &Space) -> Space {
  let v176_11: Space = routine_10(c, &(*CONSTANT_0), &(*CONSTANT_7), &(*p0), &(*CONSTANT_12));
  let v176_14: Space = routine_10(c, &(*CONSTANT_3), &(*CONSTANT_7), &(*p0), &(*CONSTANT_12));
  let v176_15: Space = unite(&(v176_11),&(v176_14));
  let v176_18: Space = routine_10(c, &(*CONSTANT_4), &(*CONSTANT_7), &(*p0), &(*CONSTANT_12));
  let v176_19: Space = unite(&(v176_15),&(v176_18));
  let v176_22: Space = routine_10(c, &(*CONSTANT_5), &(*CONSTANT_7), &(*p0), &(*CONSTANT_12));
  let v176_23: Space = unite(&(v176_19),&(v176_22));
  let v176_26: Space = routine_10(c, &(*CONSTANT_6), &(*CONSTANT_7), &(*p0), &(*CONSTANT_12));
  let v176_27: Space = unite(&(v176_23),&(v176_26));
  let v176_29: Space = routine_10(c, &(*CONSTANT_7), &(*CONSTANT_7), &(*p0), &(*CONSTANT_12));
  let v176_30: Space = unite(&(v176_27),&(v176_29));
  let v176_33: Space = routine_10(c, &(*CONSTANT_8), &(*CONSTANT_7), &(*p0), &(*CONSTANT_12));
  let v176_34: Space = unite(&(v176_30),&(v176_33));
  let v176_37: Space = routine_10(c, &(*CONSTANT_1), &(*CONSTANT_7), &(*p0), &(*CONSTANT_12));
  let v176_38: Space = unite(&(v176_34),&(v176_37));
  let v176_40: Space = intersect(&(v176_38),&(*CONSTANT_13));
  let v176_41: Space = unite(&(v176_40),&(*s1));
  let v176_42: Path = concat_path(&(*p1),&(*p2));
  let v176_43: Path = concat_path(&(v176_42),&(*p3));
  drop(v176_42);
  let v176_44: Path = concat_path(&(v176_43),&(*p4));
  drop(v176_43);
  let v176_45: Path = concat_path(&(v176_44),&(*p5));
  drop(v176_44);
  let v176_46: Space = wrap(&(v176_41),&(v176_45));
  drop(v176_45);
  let v176_47: Space = wrap(&(v176_46),&(*p0));
  (v176_47).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let v177_9: Space = unwrap(&(*s0),&(*CONSTANT_8));
  let v177_10: Space = subtract(&(*CONSTANT_9),&(v177_9));
  drop(v177_9);
  let v177_12: Path = concat_path(&(*p1),&(*p2));
  let v177_13: Path = concat_path(&(v177_12),&(*p3));
  drop(v177_12);
  let v177_14: Path = concat_path(&(v177_13),&(*p4));
  drop(v177_13);
  let v177_15: Path = concat_path(&(v177_14),&(*p5));
  drop(v177_14);
  let v177_16: Path = concat_path(&(v177_15),&(*p0));
  drop(v177_15);
  let mut v177_17 = Space::new();
  let mut v177_17_cursor = (v177_10).read_zipper();
  for v177_17_byte in v177_17_cursor.child_mask().iter() {
    v177_17_cursor.descend_to_byte(v177_17_byte);
    let v177_17_tail = v177_17_cursor.make_map();
    v177_17_cursor.ascend(1);
    let v177_17_head = Path::from_slice(&[v177_17_byte]);
    let mut v178_2 = Space::new();
    let mut v178_2_cursor = (v177_17_tail).read_zipper();
    for v178_2_byte in v178_2_cursor.child_mask().iter() {
      v178_2_cursor.descend_to_byte(v178_2_byte);
      let v178_2_tail = v178_2_cursor.make_map();
      v178_2_cursor.ascend(1);
      let v178_2_head = Path::from_slice(&[v178_2_byte]);
      let v179_2: Path = concat_path(&(v177_17_head),&(v178_2_head));
      let mut v179_3 = Space::new();
      let mut v179_3_cursor = (v178_2_tail).read_zipper();
      for v179_3_byte in v179_3_cursor.child_mask().iter() {
        v179_3_cursor.descend_to_byte(v179_3_byte);
        let v179_3_tail = v179_3_cursor.make_map();
        v179_3_cursor.ascend(1);
        let v179_3_head = Path::from_slice(&[v179_3_byte]);
        let v180_2: Path = concat_path(&(v179_2),&(v179_3_head));
        let mut v180_3 = Space::new();
        let mut v180_3_cursor = (v179_3_tail).read_zipper();
        for v180_3_byte in v180_3_cursor.child_mask().iter() {
          v180_3_cursor.descend_to_byte(v180_3_byte);
          let v180_3_tail = v180_3_cursor.make_map();
          v180_3_cursor.ascend(1);
          let v180_3_head = Path::from_slice(&[v180_3_byte]);
          let v181_2: Path = concat_path(&(v180_2),&(v180_3_head));
          let v181_3: Space = routine_1(c, &(v181_2), &(*CONSTANT_8), &(*CONSTANT_1));
          let v181_4: Space = unite(&(*s0),&(v181_3));
          let v181_5: Space = wrap(&(v181_4),&(v177_16));
          let v181_6: Space = wrap(&(v181_5),&(v181_2));
          drop(v181_2);
          v180_3.join_into((v181_6).clone());
        }
        drop(v180_3_cursor);
        drop(v180_2);
        v179_3.join_into((v180_3).clone());
      }
      drop(v179_3_cursor);
      drop(v179_2);
      v178_2.join_into((v179_3).clone());
    }
    drop(v178_2_cursor);
    v177_17.join_into((v178_2).clone());
  }
  drop(v177_17_cursor);
  drop(v177_10);
  drop(v177_16);
  (v177_17).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v182_9 = Space::new();
  let mut v182_9_cursor = (*s0).read_zipper();
  for v182_9_byte in v182_9_cursor.child_mask().iter() {
    v182_9_cursor.descend_to_byte(v182_9_byte);
    let v182_9_tail = v182_9_cursor.make_map();
    v182_9_cursor.ascend(1);
    let v182_9_head = Path::from_slice(&[v182_9_byte]);
    let mut v183_2 = Space::new();
    let mut v183_2_cursor = (v182_9_tail).read_zipper();
    for v183_2_byte in v183_2_cursor.child_mask().iter() {
      v183_2_cursor.descend_to_byte(v183_2_byte);
      let v183_2_tail = v183_2_cursor.make_map();
      v183_2_cursor.ascend(1);
      let v183_2_head = Path::from_slice(&[v183_2_byte]);
      let v184_2: Path = concat_path(&(v182_9_head),&(v183_2_head));
      let mut v184_3 = Space::new();
      let mut v184_3_cursor = (v183_2_tail).read_zipper();
      for v184_3_byte in v184_3_cursor.child_mask().iter() {
        v184_3_cursor.descend_to_byte(v184_3_byte);
        let v184_3_tail = v184_3_cursor.make_map();
        v184_3_cursor.ascend(1);
        let v184_3_head = Path::from_slice(&[v184_3_byte]);
        let v185_2: Path = concat_path(&(v184_2),&(v184_3_head));
        let mut v185_3 = Space::new();
        let mut v185_3_cursor = (v184_3_tail).read_zipper();
        for v185_3_byte in v185_3_cursor.child_mask().iter() {
          v185_3_cursor.descend_to_byte(v185_3_byte);
          let v185_3_tail = v185_3_cursor.make_map();
          v185_3_cursor.ascend(1);
          let v185_3_head = Path::from_slice(&[v185_3_byte]);
          let v186_2: Space = unwrap(&(v185_3_tail),&(*CONSTANT_1));
          let v186_3: Space = subtract(&(*CONSTANT_9),&(v186_2));
          drop(v186_2);
          let v186_4: Path = concat_path(&(v185_2),&(v185_3_head));
          let mut v186_5 = Space::new();
          let mut v186_5_cursor = (v186_3).read_zipper();
          for v186_5_byte in v186_5_cursor.child_mask().iter() {
            v186_5_cursor.descend_to_byte(v186_5_byte);
            let v186_5_tail = v186_5_cursor.make_map();
            v186_5_cursor.ascend(1);
            let v186_5_head = Path::from_slice(&[v186_5_byte]);
            let mut v187_2 = Space::new();
            let mut v187_2_cursor = (v186_5_tail).read_zipper();
            for v187_2_byte in v187_2_cursor.child_mask().iter() {
              v187_2_cursor.descend_to_byte(v187_2_byte);
              let v187_2_tail = v187_2_cursor.make_map();
              v187_2_cursor.ascend(1);
              let v187_2_head = Path::from_slice(&[v187_2_byte]);
              let v188_2: Path = concat_path(&(v186_5_head),&(v187_2_head));
              let mut v188_3 = Space::new();
              let mut v188_3_cursor = (v187_2_tail).read_zipper();
              for v188_3_byte in v188_3_cursor.child_mask().iter() {
                v188_3_cursor.descend_to_byte(v188_3_byte);
                let v188_3_tail = v188_3_cursor.make_map();
                v188_3_cursor.ascend(1);
                let v188_3_head = Path::from_slice(&[v188_3_byte]);
                let v189_2: Path = concat_path(&(v188_2),&(v188_3_head));
                let mut v189_3 = Space::new();
                let mut v189_3_cursor = (v188_3_tail).read_zipper();
                for v189_3_byte in v189_3_cursor.child_mask().iter() {
                  v189_3_cursor.descend_to_byte(v189_3_byte);
                  let v189_3_tail = v189_3_cursor.make_map();
                  v189_3_cursor.ascend(1);
                  let v189_3_head = Path::from_slice(&[v189_3_byte]);
                  let v190_2: Path = concat_path(&(v189_2),&(v189_3_head));
                  let v190_3: Space = routine_21(c, &(v190_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v186_4), &(v189_3_tail), &(v185_3_tail));
                  drop(v190_2);
                  v189_3.join_into((v190_3).clone());
                }
                drop(v189_3_cursor);
                drop(v189_2);
                v188_3.join_into((v189_3).clone());
              }
              drop(v188_3_cursor);
              drop(v188_2);
              v187_2.join_into((v188_3).clone());
            }
            drop(v187_2_cursor);
            v186_5.join_into((v187_2).clone());
          }
          drop(v186_5_cursor);
          drop(v186_3);
          drop(v186_4);
          v185_3.join_into((v186_5).clone());
        }
        drop(v185_3_cursor);
        drop(v185_2);
        v184_3.join_into((v185_3).clone());
      }
      drop(v184_3_cursor);
      drop(v184_2);
      v183_2.join_into((v184_3).clone());
    }
    drop(v183_2_cursor);
    v182_9.join_into((v183_2).clone());
  }
  drop(v182_9_cursor);
  (v182_9).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v191_7 = Space::new();
  let mut v191_7_cursor = (*s0).read_zipper();
  for v191_7_byte in v191_7_cursor.child_mask().iter() {
    v191_7_cursor.descend_to_byte(v191_7_byte);
    let v191_7_tail = v191_7_cursor.make_map();
    v191_7_cursor.ascend(1);
    let v191_7_head = Path::from_slice(&[v191_7_byte]);
    let mut v192_2 = Space::new();
    let mut v192_2_cursor = (v191_7_tail).read_zipper();
    for v192_2_byte in v192_2_cursor.child_mask().iter() {
      v192_2_cursor.descend_to_byte(v192_2_byte);
      let v192_2_tail = v192_2_cursor.make_map();
      v192_2_cursor.ascend(1);
      let v192_2_head = Path::from_slice(&[v192_2_byte]);
      let v193_2: Path = concat_path(&(v191_7_head),&(v192_2_head));
      let mut v193_3 = Space::new();
      let mut v193_3_cursor = (v192_2_tail).read_zipper();
      for v193_3_byte in v193_3_cursor.child_mask().iter() {
        v193_3_cursor.descend_to_byte(v193_3_byte);
        let v193_3_tail = v193_3_cursor.make_map();
        v193_3_cursor.ascend(1);
        let v193_3_head = Path::from_slice(&[v193_3_byte]);
        let v194_2: Path = concat_path(&(v193_2),&(v193_3_head));
        let mut v194_3 = Space::new();
        let mut v194_3_cursor = (v193_3_tail).read_zipper();
        for v194_3_byte in v194_3_cursor.child_mask().iter() {
          v194_3_cursor.descend_to_byte(v194_3_byte);
          let v194_3_tail = v194_3_cursor.make_map();
          v194_3_cursor.ascend(1);
          let v194_3_head = Path::from_slice(&[v194_3_byte]);
          let v195_2: Path = concat_path(&(v194_2),&(v194_3_head));
          let mut v195_3 = Space::new();
          let mut v195_3_cursor = (v194_3_tail).read_zipper();
          for v195_3_byte in v195_3_cursor.child_mask().iter() {
            v195_3_cursor.descend_to_byte(v195_3_byte);
            let v195_3_tail = v195_3_cursor.make_map();
            v195_3_cursor.ascend(1);
            let v195_3_head = Path::from_slice(&[v195_3_byte]);
            let mut v196_2 = Space::new();
            let mut v196_2_cursor = (v195_3_tail).read_zipper();
            for v196_2_byte in v196_2_cursor.child_mask().iter() {
              v196_2_cursor.descend_to_byte(v196_2_byte);
              let v196_2_tail = v196_2_cursor.make_map();
              v196_2_cursor.ascend(1);
              let v196_2_head = Path::from_slice(&[v196_2_byte]);
              let v197_2: Path = concat_path(&(v195_3_head),&(v196_2_head));
              let mut v197_3 = Space::new();
              let mut v197_3_cursor = (v196_2_tail).read_zipper();
              for v197_3_byte in v197_3_cursor.child_mask().iter() {
                v197_3_cursor.descend_to_byte(v197_3_byte);
                let v197_3_tail = v197_3_cursor.make_map();
                v197_3_cursor.ascend(1);
                let v197_3_head = Path::from_slice(&[v197_3_byte]);
                let v198_2: Path = concat_path(&(v197_2),&(v197_3_head));
                let mut v198_3 = Space::new();
                let mut v198_3_cursor = (v197_3_tail).read_zipper();
                for v198_3_byte in v198_3_cursor.child_mask().iter() {
                  v198_3_cursor.descend_to_byte(v198_3_byte);
                  let v198_3_tail = v198_3_cursor.make_map();
                  v198_3_cursor.ascend(1);
                  let v198_3_head = Path::from_slice(&[v198_3_byte]);
                  let v199_2: Path = concat_path(&(v198_2),&(v198_3_head));
                  let v199_3: Space = routine_22(c, &(v199_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v195_2), &(v198_3_tail));
                  drop(v199_2);
                  v198_3.join_into((v199_3).clone());
                }
                drop(v198_3_cursor);
                drop(v198_2);
                v197_3.join_into((v198_3).clone());
              }
              drop(v197_3_cursor);
              drop(v197_2);
              v196_2.join_into((v197_3).clone());
            }
            drop(v196_2_cursor);
            v195_3.join_into((v196_2).clone());
          }
          drop(v195_3_cursor);
          drop(v195_2);
          v194_3.join_into((v195_3).clone());
        }
        drop(v194_3_cursor);
        drop(v194_2);
        v193_3.join_into((v194_3).clone());
      }
      drop(v193_3_cursor);
      drop(v193_2);
      v192_2.join_into((v193_3).clone());
    }
    drop(v192_2_cursor);
    v191_7.join_into((v192_2).clone());
  }
  drop(v191_7_cursor);
  (v191_7).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space, s1: &Space) -> Space {
  let v200_13: Space = routine_10(c, &(*CONSTANT_0), &(*CONSTANT_1), &(*p0), &(*CONSTANT_12));
  let v200_16: Space = routine_10(c, &(*CONSTANT_3), &(*CONSTANT_1), &(*p0), &(*CONSTANT_12));
  let v200_17: Space = unite(&(v200_13),&(v200_16));
  let v200_20: Space = routine_10(c, &(*CONSTANT_4), &(*CONSTANT_1), &(*p0), &(*CONSTANT_12));
  let v200_21: Space = unite(&(v200_17),&(v200_20));
  let v200_24: Space = routine_10(c, &(*CONSTANT_5), &(*CONSTANT_1), &(*p0), &(*CONSTANT_12));
  let v200_25: Space = unite(&(v200_21),&(v200_24));
  let v200_28: Space = routine_10(c, &(*CONSTANT_6), &(*CONSTANT_1), &(*p0), &(*CONSTANT_12));
  let v200_29: Space = unite(&(v200_25),&(v200_28));
  let v200_32: Space = routine_10(c, &(*CONSTANT_7), &(*CONSTANT_1), &(*p0), &(*CONSTANT_12));
  let v200_33: Space = unite(&(v200_29),&(v200_32));
  let v200_36: Space = routine_10(c, &(*CONSTANT_8), &(*CONSTANT_1), &(*p0), &(*CONSTANT_12));
  let v200_37: Space = unite(&(v200_33),&(v200_36));
  let v200_39: Space = routine_10(c, &(*CONSTANT_1), &(*CONSTANT_1), &(*p0), &(*CONSTANT_12));
  let v200_40: Space = unite(&(v200_37),&(v200_39));
  let v200_42: Space = intersect(&(v200_40),&(*CONSTANT_13));
  let v200_43: Space = unite(&(v200_42),&(*s1));
  let v200_44: Path = concat_path(&(*p1),&(*p2));
  let v200_45: Path = concat_path(&(v200_44),&(*p3));
  drop(v200_44);
  let v200_46: Path = concat_path(&(v200_45),&(*p4));
  drop(v200_45);
  let v200_47: Path = concat_path(&(v200_46),&(*p5));
  drop(v200_46);
  let v200_48: Path = concat_path(&(v200_47),&(*p6));
  drop(v200_47);
  let v200_49: Path = concat_path(&(v200_48),&(*p7));
  drop(v200_48);
  let v200_50: Space = wrap(&(v200_43),&(v200_49));
  drop(v200_49);
  let v200_51: Space = wrap(&(v200_50),&(*p0));
  (v200_51).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let v201_9: Path = concat_path(&(*p1),&(*p2));
  let v201_10: Path = concat_path(&(v201_9),&(*p3));
  drop(v201_9);
  let v201_11: Path = concat_path(&(v201_10),&(*p4));
  drop(v201_10);
  let v201_12: Path = concat_path(&(v201_11),&(*p5));
  drop(v201_11);
  let v201_13: Path = concat_path(&(v201_12),&(*p6));
  drop(v201_12);
  let v201_14: Path = concat_path(&(v201_13),&(*p7));
  drop(v201_13);
  let v201_15: Path = concat_path(&(v201_14),&(*p0));
  drop(v201_14);
  let v201_16: Space = singleton(&(v201_15));
  drop(v201_15);
  (v201_16).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
