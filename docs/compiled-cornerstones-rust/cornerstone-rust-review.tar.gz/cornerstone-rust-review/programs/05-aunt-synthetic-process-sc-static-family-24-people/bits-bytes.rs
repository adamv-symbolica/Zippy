#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,1,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 15 0 0 0 0 0 1 1 0 0 1 0 0 0 1 1 14 0 0 0 0 0 1 1 1 0 0 1 0 1 1 13 0 0 0 0 1 1 0 0 0 0 0 1 1 13 0 0 0 0 1 1 1 0 0 0 0 1 1 15 0 0 0 1 0 1 1 0 0 1 0 0 0 1 1 15 0 0 0 1 0 1 1 0 1 0 0 0 0 1 1 11 0 0 0 1 1 0 0 1 0 1 1 11 0 0 0 1 1 0 1 0 0 1 1 15 0 0 1 0 0 1 1 0 0 0 0 0 0 1 1 15 0 0 1 0 0 1 1 1 0 0 0 0 0 1 1 13 0 0 1 0 1 1 0 0 1 0 0 1 1 13 0 0 1 0 1 1 1 0 1 0 0 1 1 10 0 0 1 1 0 0 0 0 1 1 10 0 0 1 1 1 0 0 0 1 1 15 0 1 0 0 0 1 1 0 0 0 0 0 0 1 1 14 0 1 0 0 0 1 1 0 1 0 1 0 1 1 13 0 1 0 0 1 1 0 0 1 0 0 1 1 13 0 1 0 0 1 1 0 1 0 0 0 1 1 12 0 1 0 1 1 0 0 0 0 0 1 1 12 0 1 0 1 1 0 0 0 1 0 1 1 9 0 1 1 0 0 0 0 1 1 8 0 1 1 0 1 0 1 1 14 1 0 0 0 0 1 1 0 1 0 1 0 1 1 14 1 0 0 0 0 1 1 1 0 0 1 0 1 1 13 1 0 0 0 1 1 0 1 0 0 0 1 1 13 1 0 0 0 1 1 1 0 0 0 0 1 1 11 1 0 0 1 1 0 0 1 0 1 1 11 1 0 0 1 1 1 0 1 0 1 1 15 1 0 1 0 0 1 1 0 1 0 0 0 0 1 1 15 1 0 1 0 0 1 1 1 0 0 0 0 0 1 1 13 1 0 1 0 1 1 0 0 0 1 0 1 1 13 1 0 1 0 1 1 1 0 1 0 0 1 1 10 1 0 1 1 0 1 0 0 1 1 10 1 0 1 1 1 0 0 0 1 1 7 1 1 0 1 0 1 1 8 1 1 1 0 1 0 1 1"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 15 0 0 0 0 0 0 1 1 0 0 1 0 0 1 1 15 0 0 0 0 0 0 1 1 0 1 0 0 0 1 1 13 0 0 0 0 0 1 1 0 0 0 0 1 1 12 0 0 0 0 0 1 1 0 1 0 1 1 10 0 0 0 0 1 1 0 0 1 1 9 0 0 0 0 1 1 0 1 1 12 0 0 0 1 0 1 1 0 1 0 1 1 13 0 0 0 1 0 1 1 1 0 1 0 1 1 15 0 0 1 0 0 0 1 1 0 0 0 0 0 1 1 15 0 0 1 0 0 0 1 1 0 0 0 1 0 1 1 13 0 0 1 0 0 1 1 0 0 1 0 1 1 13 0 0 1 0 0 1 1 0 1 0 0 1 1 11 0 0 1 0 1 1 0 0 0 1 1 11 0 0 1 0 1 1 1 0 0 1 1 15 0 1 0 0 0 0 1 1 0 0 0 1 0 1 1 15 0 1 0 0 0 0 1 1 1 0 1 0 0 1 1 13 0 1 0 0 0 1 1 0 1 0 0 1 1 13 0 1 0 0 0 1 1 1 0 0 0 1 1 11 0 1 0 0 1 1 0 0 0 1 1 10 0 1 0 0 1 1 1 0 1 1 14 0 1 0 1 0 1 1 0 1 0 0 0 1 1 14 0 1 0 1 0 1 1 1 0 0 0 0 1 1 8 0 1 0 1 1 0 1 1 7 0 1 0 1 1 1 1 15 1 0 0 0 0 0 1 1 0 0 1 0 0 1 1 15 1 0 0 0 0 0 1 1 1 0 1 0 0 1 1 13 1 0 0 0 0 1 1 0 0 0 0 1 1 13 1 0 0 0 0 1 1 1 0 0 0 1 1 10 1 0 0 0 1 1 0 0 1 1 10 1 0 0 0 1 1 1 0 1 1 14 1 0 0 1 0 1 1 0 0 0 0 0 1 1 14 1 0 0 1 0 1 1 1 0 0 0 0 1 1 13 1 0 1 0 0 1 1 0 0 1 0 1 1 13 1 0 1 0 0 1 1 1 0 1 0 1 1 11 1 0 1 0 1 1 1 0 0 1 1 8 1 0 1 0 1 1 1 1"));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("12 8 0 0 0 0 0 0 1 1 7 0 0 0 0 0 1 1 5 0 0 0 1 1 6 0 0 1 0 1 1 4 0 0 1 1 8 0 1 0 0 0 0 1 1 7 0 1 0 0 0 1 1 5 0 1 0 1 1 6 1 0 0 0 1 1 7 1 0 0 1 0 1 1 7 1 0 1 0 0 1 1 2 1 1"));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_4 = Space::new();
  let mut v0_4_cursor = (*s0.expect("unbound native input")).read_zipper();
  for v0_4_byte in v0_4_cursor.child_mask().iter() {
    v0_4_cursor.descend_to_byte(v0_4_byte);
    let v0_4_tail = v0_4_cursor.make_map();
    v0_4_cursor.ascend(1);
    let v0_4_head = Path::from_slice(&[v0_4_byte]);
    let v1_2: Space = singleton(&(v0_4_head));
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let v2_6: Space = routine_1(c, &(v0_4_head), &(v0_4_tail));
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let v3_10: Space = routine_2(c, &(v0_4_head), &(v0_4_tail));
      compose(&(v1_9),&(v3_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_4.join_into((v1_12).clone());
  }
  drop(v0_4_cursor);
  let v0_6: Space = wrap(&(v0_4),&(*CONSTANT_2));
  (v0_6).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v4_11 = Space::new();
  let mut v4_11_cursor = (*s0).read_zipper();
  for v4_11_byte in v4_11_cursor.child_mask().iter() {
    v4_11_cursor.descend_to_byte(v4_11_byte);
    let v4_11_tail = v4_11_cursor.make_map();
    v4_11_cursor.ascend(1);
    let v4_11_head = Path::from_slice(&[v4_11_byte]);
    let v5_2: Space = singleton(&(v4_11_head));
    let v5_3: Space = intersect(&(*CONSTANT_1),&(v5_2));
    let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
    drop(v5_3);
    let v5_5: Space = subtract(&(*CONSTANT_0),&(v5_4));
    drop(v5_4);
    let v5_8: Space = if (v5_5).is_empty() { Space::new() } else {
      let v6_6: Path = concat_path(&(*p0),&(v4_11_head));
      let mut v6_7 = Space::new();
      let mut v6_7_cursor = (v4_11_tail).read_zipper();
      for v6_7_byte in v6_7_cursor.child_mask().iter() {
        v6_7_cursor.descend_to_byte(v6_7_byte);
        let v6_7_tail = v6_7_cursor.make_map();
        v6_7_cursor.ascend(1);
        let v6_7_head = Path::from_slice(&[v6_7_byte]);
        let v7_2: Space = singleton(&(v6_7_head));
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v6_6),&(v6_7_head));
          let v8_7: Space = routine_3(c, &(v8_6), &(v6_7_tail));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v6_6),&(v6_7_head));
          let v9_11: Space = routine_4(c, &(v9_6), &(v6_7_tail));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_7.join_into((v7_13).clone());
      }
      drop(v6_7_cursor);
      compose(&(v5_5),&(v6_7))
    };
    drop(v5_5);
    let v5_9: Space = intersect(&(*CONSTANT_1),&(v5_2));
    drop(v5_2);
    let v5_10: Space = if has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
    drop(v5_9);
    let v5_12: Space = if (v5_10).is_empty() { Space::new() } else {
      let v10_6: Path = concat_path(&(*p0),&(v4_11_head));
      let mut v10_11 = Space::new();
      let mut v10_11_cursor = (v4_11_tail).read_zipper();
      for v10_11_byte in v10_11_cursor.child_mask().iter() {
        v10_11_cursor.descend_to_byte(v10_11_byte);
        let v10_11_tail = v10_11_cursor.make_map();
        v10_11_cursor.ascend(1);
        let v10_11_head = Path::from_slice(&[v10_11_byte]);
        let v11_2: Space = singleton(&(v10_11_head));
        let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
        let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
        drop(v11_3);
        let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
        drop(v11_4);
        let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
          let v12_6: Path = concat_path(&(v10_6),&(v10_11_head));
          let v12_7: Space = routine_3(c, &(v12_6), &(v10_11_tail));
          compose(&(v11_5),&(v12_7))
        };
        drop(v11_5);
        let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
        drop(v11_2);
        let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
        drop(v11_9);
        let v11_12: Space = if (v11_10).is_empty() { Space::new() } else {
          let v13_6: Path = concat_path(&(v10_6),&(v10_11_head));
          let v13_11: Space = routine_5(c, &(v13_6), &(v10_11_tail));
          drop(v13_6);
          compose(&(v11_10),&(v13_11))
        };
        drop(v11_10);
        let v11_13: Space = unite(&(v11_8),&(v11_12));
        v10_11.join_into((v11_13).clone());
      }
      drop(v10_11_cursor);
      drop(v10_6);
      compose(&(v5_10),&(v10_11))
    };
    drop(v5_10);
    let v5_13: Space = unite(&(v5_8),&(v5_12));
    v4_11.join_into((v5_13).clone());
  }
  drop(v4_11_cursor);
  (v4_11).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v14_8: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v14_10: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v14_21 = Space::new();
  let mut v14_21_cursor = (*s0).read_zipper();
  for v14_21_byte in v14_21_cursor.child_mask().iter() {
    v14_21_cursor.descend_to_byte(v14_21_byte);
    let v14_21_tail = v14_21_cursor.make_map();
    v14_21_cursor.ascend(1);
    let v14_21_head = Path::from_slice(&[v14_21_byte]);
    let v15_2: Space = singleton(&(v14_21_head));
    let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
    let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
    drop(v15_3);
    let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
    drop(v15_4);
    let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v14_21_head));
      let mut v16_7 = Space::new();
      let mut v16_7_cursor = (v14_21_tail).read_zipper();
      for v16_7_byte in v16_7_cursor.child_mask().iter() {
        v16_7_cursor.descend_to_byte(v16_7_byte);
        let v16_7_tail = v16_7_cursor.make_map();
        v16_7_cursor.ascend(1);
        let v16_7_head = Path::from_slice(&[v16_7_byte]);
        let v17_2: Space = singleton(&(v16_7_head));
        let v17_3: Space = intersect(&(*CONSTANT_1),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
        drop(v17_4);
        let v17_8: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v16_6),&(v16_7_head));
          let v18_7: Space = routine_3(c, &(v18_6), &(v16_7_tail));
          compose(&(v17_5),&(v18_7))
        };
        drop(v17_5);
        let v17_9: Space = intersect(&(*CONSTANT_1),&(v17_2));
        drop(v17_2);
        let v17_10: Space = if has_head(&(v17_9)) { singleton(&[]) } else { Space::new() };
        drop(v17_9);
        let v17_12: Space = if (v17_10).is_empty() { Space::new() } else {
          let v19_6: Path = concat_path(&(v16_6),&(v16_7_head));
          let v19_11: Space = routine_4(c, &(v19_6), &(v16_7_tail));
          drop(v19_6);
          compose(&(v17_10),&(v19_11))
        };
        drop(v17_10);
        let v17_13: Space = unite(&(v17_8),&(v17_12));
        v16_7.join_into((v17_13).clone());
      }
      drop(v16_7_cursor);
      compose(&(v15_5),&(v16_7))
    };
    drop(v15_5);
    let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
    drop(v15_2);
    let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
    drop(v15_9);
    let v15_19: Space = if (v15_10).is_empty() { Space::new() } else {
      let v20_11: Space = unwrap(&(v14_8),&(v14_21_head));
      let v20_12: Space = restrict_to(&(*CONSTANT_4),&(v20_11));
      drop(v20_11);
      let mut v20_13 = Space::new();
      let mut v20_13_cursor = (v20_12).read_zipper();
      for v20_13_byte in v20_13_cursor.child_mask().iter() {
        v20_13_cursor.descend_to_byte(v20_13_byte);
        let v20_13_tail = v20_13_cursor.make_map();
        v20_13_cursor.ascend(1);
        let v20_13_head = Path::from_slice(&[v20_13_byte]);
        let v21_2: Space = singleton(&(v20_13_head));
        let v21_3: Space = intersect(&(*CONSTANT_1),&(v21_2));
        let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
        drop(v21_3);
        let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
        drop(v21_4);
        let v21_7: Space = if (v21_5).is_empty() { Space::new() } else {
          let v22_6: Space = routine_6(c, &(v20_13_head), &(v20_13_tail));
          compose(&(v21_5),&(v22_6))
        };
        drop(v21_5);
        let v21_8: Space = intersect(&(*CONSTANT_1),&(v21_2));
        drop(v21_2);
        let v21_9: Space = if has_head(&(v21_8)) { singleton(&[]) } else { Space::new() };
        drop(v21_8);
        let v21_11: Space = if (v21_9).is_empty() { Space::new() } else {
          let v23_10: Space = routine_7(c, &(v20_13_head), &(v20_13_tail));
          compose(&(v21_9),&(v23_10))
        };
        drop(v21_9);
        let v21_12: Space = unite(&(v21_7),&(v21_11));
        v20_13.join_into((v21_12).clone());
      }
      drop(v20_13_cursor);
      drop(v20_12);
      let v20_14: Space = restrict_to(&(*CONSTANT_3),&(v20_13));
      let mut v20_15 = Space::new();
      let mut v20_15_cursor = (v20_14).read_zipper();
      for v20_15_byte in v20_15_cursor.child_mask().iter() {
        v20_15_cursor.descend_to_byte(v20_15_byte);
        let v20_15_tail = v20_15_cursor.make_map();
        v20_15_cursor.ascend(1);
        let v20_15_head = Path::from_slice(&[v20_15_byte]);
        let v24_2: Space = singleton(&(v20_15_head));
        let v24_3: Space = intersect(&(*CONSTANT_1),&(v24_2));
        let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
        drop(v24_3);
        let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
        drop(v24_4);
        let v24_7: Space = if (v24_5).is_empty() { Space::new() } else {
          let v25_6: Space = routine_8(c, &(v20_15_head), &(v20_15_tail));
          compose(&(v24_5),&(v25_6))
        };
        drop(v24_5);
        let v24_8: Space = intersect(&(*CONSTANT_1),&(v24_2));
        drop(v24_2);
        let v24_9: Space = if has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
        drop(v24_8);
        let v24_11: Space = if (v24_9).is_empty() { Space::new() } else {
          let v26_10: Space = routine_9(c, &(v20_15_head), &(v20_15_tail));
          compose(&(v24_9),&(v26_10))
        };
        drop(v24_9);
        let v24_12: Space = unite(&(v24_7),&(v24_11));
        v20_15.join_into((v24_12).clone());
      }
      drop(v20_15_cursor);
      let v20_16: Space = unwrap(&(v14_10),&(v14_21_head));
      let v20_17: Space = subtract(&(v20_15),&(v20_16));
      drop(v20_16);
      let v20_18: Space = intersect(&(v20_17),&(*CONSTANT_5));
      compose(&(v15_10),&(v20_18))
    };
    drop(v15_10);
    let v27_6: Path = concat_path(&(*p0),&(v14_21_head));
    let v15_20: Space = wrap(&(v15_19),&(v27_6));
    let v15_21: Space = unite(&(v15_8),&(v15_20));
    v14_21.join_into((v15_21).clone());
  }
  drop(v14_21_cursor);
  drop(v14_8);
  drop(v14_10);
  (v14_21).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v28_11 = Space::new();
  let mut v28_11_cursor = (*s0).read_zipper();
  for v28_11_byte in v28_11_cursor.child_mask().iter() {
    v28_11_cursor.descend_to_byte(v28_11_byte);
    let v28_11_tail = v28_11_cursor.make_map();
    v28_11_cursor.ascend(1);
    let v28_11_head = Path::from_slice(&[v28_11_byte]);
    let v29_2: Space = singleton(&(v28_11_head));
    let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
    let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
    drop(v29_3);
    let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
    drop(v29_4);
    let v29_8: Space = if (v29_5).is_empty() { Space::new() } else {
      let v30_6: Path = concat_path(&(*p0),&(v28_11_head));
      let mut v30_7 = Space::new();
      let mut v30_7_cursor = (v28_11_tail).read_zipper();
      for v30_7_byte in v30_7_cursor.child_mask().iter() {
        v30_7_cursor.descend_to_byte(v30_7_byte);
        let v30_7_tail = v30_7_cursor.make_map();
        v30_7_cursor.ascend(1);
        let v30_7_head = Path::from_slice(&[v30_7_byte]);
        let v31_2: Space = singleton(&(v30_7_head));
        let v31_3: Space = intersect(&(*CONSTANT_1),&(v31_2));
        let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
        drop(v31_3);
        let v31_5: Space = subtract(&(*CONSTANT_0),&(v31_4));
        drop(v31_4);
        let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
          let v32_6: Path = concat_path(&(v30_6),&(v30_7_head));
          let v32_7: Space = routine_10(c, &(v32_6), &(v30_7_tail));
          compose(&(v31_5),&(v32_7))
        };
        drop(v31_5);
        let v31_9: Space = intersect(&(*CONSTANT_1),&(v31_2));
        drop(v31_2);
        let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
        drop(v31_9);
        let v31_12: Space = if (v31_10).is_empty() { Space::new() } else {
          let v33_6: Path = concat_path(&(v30_6),&(v30_7_head));
          let v33_11: Space = routine_11(c, &(v33_6), &(v30_7_tail));
          drop(v33_6);
          compose(&(v31_10),&(v33_11))
        };
        drop(v31_10);
        let v31_13: Space = unite(&(v31_8),&(v31_12));
        v30_7.join_into((v31_13).clone());
      }
      drop(v30_7_cursor);
      compose(&(v29_5),&(v30_7))
    };
    drop(v29_5);
    let v29_9: Space = intersect(&(*CONSTANT_1),&(v29_2));
    drop(v29_2);
    let v29_10: Space = if has_head(&(v29_9)) { singleton(&[]) } else { Space::new() };
    drop(v29_9);
    let v29_12: Space = if (v29_10).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&(v28_11_head));
      let mut v34_11 = Space::new();
      let mut v34_11_cursor = (v28_11_tail).read_zipper();
      for v34_11_byte in v34_11_cursor.child_mask().iter() {
        v34_11_cursor.descend_to_byte(v34_11_byte);
        let v34_11_tail = v34_11_cursor.make_map();
        v34_11_cursor.ascend(1);
        let v34_11_head = Path::from_slice(&[v34_11_byte]);
        let v35_2: Space = singleton(&(v34_11_head));
        let v35_3: Space = intersect(&(*CONSTANT_1),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_0),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (v35_5).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let v36_7: Space = routine_10(c, &(v36_6), &(v34_11_tail));
          compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = intersect(&(*CONSTANT_1),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (v35_10).is_empty() { Space::new() } else {
          let v37_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let v37_11: Space = routine_5(c, &(v37_6), &(v34_11_tail));
          drop(v37_6);
          compose(&(v35_10),&(v37_11))
        };
        drop(v35_10);
        let v35_13: Space = unite(&(v35_8),&(v35_12));
        v34_11.join_into((v35_13).clone());
      }
      drop(v34_11_cursor);
      drop(v34_6);
      compose(&(v29_10),&(v34_11))
    };
    drop(v29_10);
    let v29_13: Space = unite(&(v29_8),&(v29_12));
    v28_11.join_into((v29_13).clone());
  }
  drop(v28_11_cursor);
  (v28_11).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v38_8: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v38_10: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v38_21 = Space::new();
  let mut v38_21_cursor = (*s0).read_zipper();
  for v38_21_byte in v38_21_cursor.child_mask().iter() {
    v38_21_cursor.descend_to_byte(v38_21_byte);
    let v38_21_tail = v38_21_cursor.make_map();
    v38_21_cursor.ascend(1);
    let v38_21_head = Path::from_slice(&[v38_21_byte]);
    let v39_2: Space = singleton(&(v38_21_head));
    let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
    let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
    drop(v39_3);
    let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
    drop(v39_4);
    let v39_8: Space = if (v39_5).is_empty() { Space::new() } else {
      let v40_6: Path = concat_path(&(*p0),&(v38_21_head));
      let mut v40_7 = Space::new();
      let mut v40_7_cursor = (v38_21_tail).read_zipper();
      for v40_7_byte in v40_7_cursor.child_mask().iter() {
        v40_7_cursor.descend_to_byte(v40_7_byte);
        let v40_7_tail = v40_7_cursor.make_map();
        v40_7_cursor.ascend(1);
        let v40_7_head = Path::from_slice(&[v40_7_byte]);
        let v41_2: Space = singleton(&(v40_7_head));
        let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
        let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
        drop(v41_3);
        let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
        drop(v41_4);
        let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
          let v42_6: Path = concat_path(&(v40_6),&(v40_7_head));
          let v42_7: Space = routine_10(c, &(v42_6), &(v40_7_tail));
          compose(&(v41_5),&(v42_7))
        };
        drop(v41_5);
        let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
        drop(v41_2);
        let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
        drop(v41_9);
        let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
          let v43_6: Path = concat_path(&(v40_6),&(v40_7_head));
          let v43_11: Space = routine_11(c, &(v43_6), &(v40_7_tail));
          drop(v43_6);
          compose(&(v41_10),&(v43_11))
        };
        drop(v41_10);
        let v41_13: Space = unite(&(v41_8),&(v41_12));
        v40_7.join_into((v41_13).clone());
      }
      drop(v40_7_cursor);
      compose(&(v39_5),&(v40_7))
    };
    drop(v39_5);
    let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
    drop(v39_2);
    let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
    drop(v39_9);
    let v39_19: Space = if (v39_10).is_empty() { Space::new() } else {
      let v44_11: Space = unwrap(&(v38_8),&(v38_21_head));
      let v44_12: Space = restrict_to(&(*CONSTANT_4),&(v44_11));
      drop(v44_11);
      let mut v44_13 = Space::new();
      let mut v44_13_cursor = (v44_12).read_zipper();
      for v44_13_byte in v44_13_cursor.child_mask().iter() {
        v44_13_cursor.descend_to_byte(v44_13_byte);
        let v44_13_tail = v44_13_cursor.make_map();
        v44_13_cursor.ascend(1);
        let v44_13_head = Path::from_slice(&[v44_13_byte]);
        let v45_2: Space = singleton(&(v44_13_head));
        let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
        let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
        drop(v45_3);
        let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
        drop(v45_4);
        let v45_7: Space = if (v45_5).is_empty() { Space::new() } else {
          let v46_6: Space = routine_6(c, &(v44_13_head), &(v44_13_tail));
          compose(&(v45_5),&(v46_6))
        };
        drop(v45_5);
        let v45_8: Space = intersect(&(*CONSTANT_1),&(v45_2));
        drop(v45_2);
        let v45_9: Space = if has_head(&(v45_8)) { singleton(&[]) } else { Space::new() };
        drop(v45_8);
        let v45_11: Space = if (v45_9).is_empty() { Space::new() } else {
          let v47_10: Space = routine_7(c, &(v44_13_head), &(v44_13_tail));
          compose(&(v45_9),&(v47_10))
        };
        drop(v45_9);
        let v45_12: Space = unite(&(v45_7),&(v45_11));
        v44_13.join_into((v45_12).clone());
      }
      drop(v44_13_cursor);
      drop(v44_12);
      let v44_14: Space = restrict_to(&(*CONSTANT_3),&(v44_13));
      let mut v44_15 = Space::new();
      let mut v44_15_cursor = (v44_14).read_zipper();
      for v44_15_byte in v44_15_cursor.child_mask().iter() {
        v44_15_cursor.descend_to_byte(v44_15_byte);
        let v44_15_tail = v44_15_cursor.make_map();
        v44_15_cursor.ascend(1);
        let v44_15_head = Path::from_slice(&[v44_15_byte]);
        let v48_2: Space = singleton(&(v44_15_head));
        let v48_3: Space = intersect(&(*CONSTANT_1),&(v48_2));
        let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
        drop(v48_3);
        let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
        drop(v48_4);
        let v48_7: Space = if (v48_5).is_empty() { Space::new() } else {
          let v49_6: Space = routine_8(c, &(v44_15_head), &(v44_15_tail));
          compose(&(v48_5),&(v49_6))
        };
        drop(v48_5);
        let v48_8: Space = intersect(&(*CONSTANT_1),&(v48_2));
        drop(v48_2);
        let v48_9: Space = if has_head(&(v48_8)) { singleton(&[]) } else { Space::new() };
        drop(v48_8);
        let v48_11: Space = if (v48_9).is_empty() { Space::new() } else {
          let v50_10: Space = routine_9(c, &(v44_15_head), &(v44_15_tail));
          compose(&(v48_9),&(v50_10))
        };
        drop(v48_9);
        let v48_12: Space = unite(&(v48_7),&(v48_11));
        v44_15.join_into((v48_12).clone());
      }
      drop(v44_15_cursor);
      let v44_16: Space = unwrap(&(v38_10),&(v38_21_head));
      let v44_17: Space = subtract(&(v44_15),&(v44_16));
      drop(v44_16);
      let v44_18: Space = intersect(&(v44_17),&(*CONSTANT_5));
      compose(&(v39_10),&(v44_18))
    };
    drop(v39_10);
    let v51_6: Path = concat_path(&(*p0),&(v38_21_head));
    let v39_20: Space = wrap(&(v39_19),&(v51_6));
    let v39_21: Space = unite(&(v39_8),&(v39_20));
    v38_21.join_into((v39_21).clone());
  }
  drop(v38_21_cursor);
  drop(v38_8);
  drop(v38_10);
  (v38_21).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v52_5: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v52_6: Space = restrict_to(&(*CONSTANT_4),&(v52_5));
  drop(v52_5);
  let mut v52_16 = Space::new();
  let mut v52_16_cursor = (v52_6).read_zipper();
  for v52_16_byte in v52_16_cursor.child_mask().iter() {
    v52_16_cursor.descend_to_byte(v52_16_byte);
    let v52_16_tail = v52_16_cursor.make_map();
    v52_16_cursor.ascend(1);
    let v52_16_head = Path::from_slice(&[v52_16_byte]);
    let v53_2: Space = singleton(&(v52_16_head));
    let v53_3: Space = intersect(&(*CONSTANT_1),&(v53_2));
    let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
    drop(v53_3);
    let v53_5: Space = subtract(&(*CONSTANT_0),&(v53_4));
    drop(v53_4);
    let v53_7: Space = if (v53_5).is_empty() { Space::new() } else {
      let mut v54_6 = Space::new();
      let mut v54_6_cursor = (v52_16_tail).read_zipper();
      for v54_6_byte in v54_6_cursor.child_mask().iter() {
        v54_6_cursor.descend_to_byte(v54_6_byte);
        let v54_6_tail = v54_6_cursor.make_map();
        v54_6_cursor.ascend(1);
        let v54_6_head = Path::from_slice(&[v54_6_byte]);
        let v55_2: Space = singleton(&(v54_6_head));
        let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
        let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
        drop(v55_3);
        let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
        drop(v55_4);
        let v55_8: Space = if (v55_5).is_empty() { Space::new() } else {
          let v56_6: Path = concat_path(&(v52_16_head),&(v54_6_head));
          let v56_7: Space = routine_12(c, &(v56_6), &(v54_6_tail));
          compose(&(v55_5),&(v56_7))
        };
        drop(v55_5);
        let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
        drop(v55_2);
        let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
        drop(v55_9);
        let v55_12: Space = if (v55_10).is_empty() { Space::new() } else {
          let v57_6: Path = concat_path(&(v52_16_head),&(v54_6_head));
          let v57_11: Space = routine_13(c, &(v57_6), &(v54_6_tail));
          drop(v57_6);
          compose(&(v55_10),&(v57_11))
        };
        drop(v55_10);
        let v55_13: Space = unite(&(v55_8),&(v55_12));
        v54_6.join_into((v55_13).clone());
      }
      drop(v54_6_cursor);
      compose(&(v53_5),&(v54_6))
    };
    drop(v53_5);
    let v53_8: Space = intersect(&(*CONSTANT_1),&(v53_2));
    drop(v53_2);
    let v53_9: Space = if has_head(&(v53_8)) { singleton(&[]) } else { Space::new() };
    drop(v53_8);
    let v53_11: Space = if (v53_9).is_empty() { Space::new() } else {
      let mut v58_10 = Space::new();
      let mut v58_10_cursor = (v52_16_tail).read_zipper();
      for v58_10_byte in v58_10_cursor.child_mask().iter() {
        v58_10_cursor.descend_to_byte(v58_10_byte);
        let v58_10_tail = v58_10_cursor.make_map();
        v58_10_cursor.ascend(1);
        let v58_10_head = Path::from_slice(&[v58_10_byte]);
        let v59_2: Space = singleton(&(v58_10_head));
        let v59_3: Space = intersect(&(*CONSTANT_1),&(v59_2));
        let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
        drop(v59_3);
        let v59_5: Space = subtract(&(*CONSTANT_0),&(v59_4));
        drop(v59_4);
        let v59_8: Space = if (v59_5).is_empty() { Space::new() } else {
          let v60_6: Path = concat_path(&(v52_16_head),&(v58_10_head));
          let v60_7: Space = routine_12(c, &(v60_6), &(v58_10_tail));
          compose(&(v59_5),&(v60_7))
        };
        drop(v59_5);
        let v59_9: Space = intersect(&(*CONSTANT_1),&(v59_2));
        drop(v59_2);
        let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
        drop(v59_9);
        let v59_12: Space = if (v59_10).is_empty() { Space::new() } else {
          let v61_6: Path = concat_path(&(v52_16_head),&(v58_10_head));
          let v61_11: Space = routine_14(c, &(v61_6), &(v58_10_tail));
          drop(v61_6);
          compose(&(v59_10),&(v61_11))
        };
        drop(v59_10);
        let v59_13: Space = unite(&(v59_8),&(v59_12));
        v58_10.join_into((v59_13).clone());
      }
      drop(v58_10_cursor);
      compose(&(v53_9),&(v58_10))
    };
    drop(v53_9);
    let v53_12: Space = unite(&(v53_7),&(v53_11));
    v52_16.join_into((v53_12).clone());
  }
  drop(v52_16_cursor);
  drop(v52_6);
  let v52_17: Space = restrict_to(&(*CONSTANT_3),&(v52_16));
  let mut v52_27 = Space::new();
  let mut v52_27_cursor = (v52_17).read_zipper();
  for v52_27_byte in v52_27_cursor.child_mask().iter() {
    v52_27_cursor.descend_to_byte(v52_27_byte);
    let v52_27_tail = v52_27_cursor.make_map();
    v52_27_cursor.ascend(1);
    let v52_27_head = Path::from_slice(&[v52_27_byte]);
    let v62_2: Space = singleton(&(v52_27_head));
    let v62_3: Space = intersect(&(*CONSTANT_1),&(v62_2));
    let v62_4: Space = if has_head(&(v62_3)) { singleton(&[]) } else { Space::new() };
    drop(v62_3);
    let v62_5: Space = subtract(&(*CONSTANT_0),&(v62_4));
    drop(v62_4);
    let v62_7: Space = if (v62_5).is_empty() { Space::new() } else {
      let mut v63_6 = Space::new();
      let mut v63_6_cursor = (v52_27_tail).read_zipper();
      for v63_6_byte in v63_6_cursor.child_mask().iter() {
        v63_6_cursor.descend_to_byte(v63_6_byte);
        let v63_6_tail = v63_6_cursor.make_map();
        v63_6_cursor.ascend(1);
        let v63_6_head = Path::from_slice(&[v63_6_byte]);
        let v64_2: Space = singleton(&(v63_6_head));
        let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
        let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
        drop(v64_3);
        let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
        drop(v64_4);
        let v64_8: Space = if (v64_5).is_empty() { Space::new() } else {
          let v65_6: Path = concat_path(&(v52_27_head),&(v63_6_head));
          let v65_7: Space = routine_15(c, &(v65_6), &(v63_6_tail));
          compose(&(v64_5),&(v65_7))
        };
        drop(v64_5);
        let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
        drop(v64_2);
        let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
        drop(v64_9);
        let v64_12: Space = if (v64_10).is_empty() { Space::new() } else {
          let v66_6: Path = concat_path(&(v52_27_head),&(v63_6_head));
          let v66_11: Space = routine_16(c, &(v66_6), &(v63_6_tail));
          drop(v66_6);
          compose(&(v64_10),&(v66_11))
        };
        drop(v64_10);
        let v64_13: Space = unite(&(v64_8),&(v64_12));
        v63_6.join_into((v64_13).clone());
      }
      drop(v63_6_cursor);
      compose(&(v62_5),&(v63_6))
    };
    drop(v62_5);
    let v62_8: Space = intersect(&(*CONSTANT_1),&(v62_2));
    drop(v62_2);
    let v62_9: Space = if has_head(&(v62_8)) { singleton(&[]) } else { Space::new() };
    drop(v62_8);
    let v62_11: Space = if (v62_9).is_empty() { Space::new() } else {
      let mut v67_10 = Space::new();
      let mut v67_10_cursor = (v52_27_tail).read_zipper();
      for v67_10_byte in v67_10_cursor.child_mask().iter() {
        v67_10_cursor.descend_to_byte(v67_10_byte);
        let v67_10_tail = v67_10_cursor.make_map();
        v67_10_cursor.ascend(1);
        let v67_10_head = Path::from_slice(&[v67_10_byte]);
        let v68_2: Space = singleton(&(v67_10_head));
        let v68_3: Space = intersect(&(*CONSTANT_1),&(v68_2));
        let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
        drop(v68_3);
        let v68_5: Space = subtract(&(*CONSTANT_0),&(v68_4));
        drop(v68_4);
        let v68_8: Space = if (v68_5).is_empty() { Space::new() } else {
          let v69_6: Path = concat_path(&(v52_27_head),&(v67_10_head));
          let v69_7: Space = routine_15(c, &(v69_6), &(v67_10_tail));
          compose(&(v68_5),&(v69_7))
        };
        drop(v68_5);
        let v68_9: Space = intersect(&(*CONSTANT_1),&(v68_2));
        drop(v68_2);
        let v68_10: Space = if has_head(&(v68_9)) { singleton(&[]) } else { Space::new() };
        drop(v68_9);
        let v68_12: Space = if (v68_10).is_empty() { Space::new() } else {
          let v70_6: Path = concat_path(&(v52_27_head),&(v67_10_head));
          let v70_11: Space = routine_17(c, &(v70_6), &(v67_10_tail));
          drop(v70_6);
          compose(&(v68_10),&(v70_11))
        };
        drop(v68_10);
        let v68_13: Space = unite(&(v68_8),&(v68_12));
        v67_10.join_into((v68_13).clone());
      }
      drop(v67_10_cursor);
      compose(&(v62_9),&(v67_10))
    };
    drop(v62_9);
    let v62_12: Space = unite(&(v62_7),&(v62_11));
    v52_27.join_into((v62_12).clone());
  }
  drop(v52_27_cursor);
  let v52_29: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v52_30: Space = subtract(&(v52_27),&(v52_29));
  drop(v52_29);
  let v52_32: Space = intersect(&(v52_30),&(*CONSTANT_5));
  let v52_33: Space = wrap(&(v52_32),&(*p0));
  (v52_33).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v71_11 = Space::new();
  let mut v71_11_cursor = (*s0).read_zipper();
  for v71_11_byte in v71_11_cursor.child_mask().iter() {
    v71_11_cursor.descend_to_byte(v71_11_byte);
    let v71_11_tail = v71_11_cursor.make_map();
    v71_11_cursor.ascend(1);
    let v71_11_head = Path::from_slice(&[v71_11_byte]);
    let v72_2: Space = singleton(&(v71_11_head));
    let v72_3: Space = intersect(&(*CONSTANT_1),&(v72_2));
    let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
    drop(v72_3);
    let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
    drop(v72_4);
    let v72_8: Space = if (v72_5).is_empty() { Space::new() } else {
      let v73_6: Path = concat_path(&(*p0),&(v71_11_head));
      let mut v73_7 = Space::new();
      let mut v73_7_cursor = (v71_11_tail).read_zipper();
      for v73_7_byte in v73_7_cursor.child_mask().iter() {
        v73_7_cursor.descend_to_byte(v73_7_byte);
        let v73_7_tail = v73_7_cursor.make_map();
        v73_7_cursor.ascend(1);
        let v73_7_head = Path::from_slice(&[v73_7_byte]);
        let v74_2: Space = singleton(&(v73_7_head));
        let v74_3: Space = intersect(&(*CONSTANT_1),&(v74_2));
        let v74_4: Space = if has_head(&(v74_3)) { singleton(&[]) } else { Space::new() };
        drop(v74_3);
        let v74_5: Space = subtract(&(*CONSTANT_0),&(v74_4));
        drop(v74_4);
        let v74_8: Space = if (v74_5).is_empty() { Space::new() } else {
          let v75_6: Path = concat_path(&(v73_6),&(v73_7_head));
          let v75_7: Space = routine_18(c, &(v75_6), &(v73_7_tail));
          compose(&(v74_5),&(v75_7))
        };
        drop(v74_5);
        let v74_9: Space = intersect(&(*CONSTANT_1),&(v74_2));
        drop(v74_2);
        let v74_10: Space = if has_head(&(v74_9)) { singleton(&[]) } else { Space::new() };
        drop(v74_9);
        let v74_12: Space = if (v74_10).is_empty() { Space::new() } else {
          let v76_6: Path = concat_path(&(v73_6),&(v73_7_head));
          let v76_11: Space = routine_19(c, &(v76_6), &(v73_7_tail));
          drop(v76_6);
          compose(&(v74_10),&(v76_11))
        };
        drop(v74_10);
        let v74_13: Space = unite(&(v74_8),&(v74_12));
        v73_7.join_into((v74_13).clone());
      }
      drop(v73_7_cursor);
      compose(&(v72_5),&(v73_7))
    };
    drop(v72_5);
    let v72_9: Space = intersect(&(*CONSTANT_1),&(v72_2));
    drop(v72_2);
    let v72_10: Space = if has_head(&(v72_9)) { singleton(&[]) } else { Space::new() };
    drop(v72_9);
    let v72_12: Space = if (v72_10).is_empty() { Space::new() } else {
      let v77_6: Path = concat_path(&(*p0),&(v71_11_head));
      let mut v77_11 = Space::new();
      let mut v77_11_cursor = (v71_11_tail).read_zipper();
      for v77_11_byte in v77_11_cursor.child_mask().iter() {
        v77_11_cursor.descend_to_byte(v77_11_byte);
        let v77_11_tail = v77_11_cursor.make_map();
        v77_11_cursor.ascend(1);
        let v77_11_head = Path::from_slice(&[v77_11_byte]);
        let v78_2: Space = singleton(&(v77_11_head));
        let v78_3: Space = intersect(&(*CONSTANT_1),&(v78_2));
        let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
        drop(v78_3);
        let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
        drop(v78_4);
        let v78_8: Space = if (v78_5).is_empty() { Space::new() } else {
          let v79_6: Path = concat_path(&(v77_6),&(v77_11_head));
          let v79_7: Space = routine_18(c, &(v79_6), &(v77_11_tail));
          compose(&(v78_5),&(v79_7))
        };
        drop(v78_5);
        let v78_9: Space = intersect(&(*CONSTANT_1),&(v78_2));
        drop(v78_2);
        let v78_10: Space = if has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
        drop(v78_9);
        let v78_12: Space = if (v78_10).is_empty() { Space::new() } else {
          let v80_6: Path = concat_path(&(v77_6),&(v77_11_head));
          let v80_11: Space = routine_14(c, &(v80_6), &(v77_11_tail));
          drop(v80_6);
          compose(&(v78_10),&(v80_11))
        };
        drop(v78_10);
        let v78_13: Space = unite(&(v78_8),&(v78_12));
        v77_11.join_into((v78_13).clone());
      }
      drop(v77_11_cursor);
      drop(v77_6);
      compose(&(v72_10),&(v77_11))
    };
    drop(v72_10);
    let v72_13: Space = unite(&(v72_8),&(v72_12));
    v71_11.join_into((v72_13).clone());
  }
  drop(v71_11_cursor);
  (v71_11).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v81_8 = Space::new();
  let mut v81_8_cursor = (*s0).read_zipper();
  for v81_8_byte in v81_8_cursor.child_mask().iter() {
    v81_8_cursor.descend_to_byte(v81_8_byte);
    let v81_8_tail = v81_8_cursor.make_map();
    v81_8_cursor.ascend(1);
    let v81_8_head = Path::from_slice(&[v81_8_byte]);
    let v82_2: Space = singleton(&(v81_8_head));
    let v82_3: Space = intersect(&(*CONSTANT_1),&(v82_2));
    let v82_4: Space = if has_head(&(v82_3)) { singleton(&[]) } else { Space::new() };
    drop(v82_3);
    let v82_5: Space = subtract(&(*CONSTANT_0),&(v82_4));
    drop(v82_4);
    let v82_8: Space = if (v82_5).is_empty() { Space::new() } else {
      let v83_6: Path = concat_path(&(*p0),&(v81_8_head));
      let mut v83_7 = Space::new();
      let mut v83_7_cursor = (v81_8_tail).read_zipper();
      for v83_7_byte in v83_7_cursor.child_mask().iter() {
        v83_7_cursor.descend_to_byte(v83_7_byte);
        let v83_7_tail = v83_7_cursor.make_map();
        v83_7_cursor.ascend(1);
        let v83_7_head = Path::from_slice(&[v83_7_byte]);
        let v84_2: Space = singleton(&(v83_7_head));
        let v84_3: Space = intersect(&(*CONSTANT_1),&(v84_2));
        let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
        drop(v84_3);
        let v84_5: Space = subtract(&(*CONSTANT_0),&(v84_4));
        drop(v84_4);
        let v84_8: Space = if (v84_5).is_empty() { Space::new() } else {
          let v85_6: Path = concat_path(&(v83_6),&(v83_7_head));
          let v85_7: Space = routine_18(c, &(v85_6), &(v83_7_tail));
          compose(&(v84_5),&(v85_7))
        };
        drop(v84_5);
        let v84_9: Space = intersect(&(*CONSTANT_1),&(v84_2));
        drop(v84_2);
        let v84_10: Space = if has_head(&(v84_9)) { singleton(&[]) } else { Space::new() };
        drop(v84_9);
        let v84_12: Space = if (v84_10).is_empty() { Space::new() } else {
          let v86_6: Path = concat_path(&(v83_6),&(v83_7_head));
          let v86_11: Space = routine_19(c, &(v86_6), &(v83_7_tail));
          drop(v86_6);
          compose(&(v84_10),&(v86_11))
        };
        drop(v84_10);
        let v84_13: Space = unite(&(v84_8),&(v84_12));
        v83_7.join_into((v84_13).clone());
      }
      drop(v83_7_cursor);
      drop(v83_6);
      compose(&(v82_5),&(v83_7))
    };
    drop(v82_5);
    let v82_9: Space = intersect(&(*CONSTANT_1),&(v82_2));
    drop(v82_2);
    let v82_10: Space = if has_head(&(v82_9)) { singleton(&[]) } else { Space::new() };
    drop(v82_9);
    let v82_11: Space = compose(&(v82_10),&(v81_8_tail));
    drop(v82_10);
    let v82_12: Space = unite(&(v82_8),&(v82_11));
    drop(v82_11);
    v81_8.join_into((v82_12).clone());
  }
  drop(v81_8_cursor);
  (v81_8).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v87_11 = Space::new();
  let mut v87_11_cursor = (*s0).read_zipper();
  for v87_11_byte in v87_11_cursor.child_mask().iter() {
    v87_11_cursor.descend_to_byte(v87_11_byte);
    let v87_11_tail = v87_11_cursor.make_map();
    v87_11_cursor.ascend(1);
    let v87_11_head = Path::from_slice(&[v87_11_byte]);
    let v88_2: Space = singleton(&(v87_11_head));
    let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
    let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
    drop(v88_3);
    let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
    drop(v88_4);
    let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
      let v89_6: Path = concat_path(&(*p0),&(v87_11_head));
      let mut v89_7 = Space::new();
      let mut v89_7_cursor = (v87_11_tail).read_zipper();
      for v89_7_byte in v89_7_cursor.child_mask().iter() {
        v89_7_cursor.descend_to_byte(v89_7_byte);
        let v89_7_tail = v89_7_cursor.make_map();
        v89_7_cursor.ascend(1);
        let v89_7_head = Path::from_slice(&[v89_7_byte]);
        let v90_2: Space = singleton(&(v89_7_head));
        let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
        let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
        drop(v90_3);
        let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
        drop(v90_4);
        let v90_8: Space = if (v90_5).is_empty() { Space::new() } else {
          let v91_6: Path = concat_path(&(v89_6),&(v89_7_head));
          let v91_7: Space = routine_20(c, &(v91_6), &(v89_7_tail));
          compose(&(v90_5),&(v91_7))
        };
        drop(v90_5);
        let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
        drop(v90_2);
        let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
        drop(v90_9);
        let v90_12: Space = if (v90_10).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v89_6),&(v89_7_head));
          let v92_11: Space = routine_21(c, &(v92_6), &(v89_7_tail));
          drop(v92_6);
          compose(&(v90_10),&(v92_11))
        };
        drop(v90_10);
        let v90_13: Space = unite(&(v90_8),&(v90_12));
        v89_7.join_into((v90_13).clone());
      }
      drop(v89_7_cursor);
      compose(&(v88_5),&(v89_7))
    };
    drop(v88_5);
    let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
    drop(v88_2);
    let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
    drop(v88_9);
    let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
      let v93_6: Path = concat_path(&(*p0),&(v87_11_head));
      let mut v93_11 = Space::new();
      let mut v93_11_cursor = (v87_11_tail).read_zipper();
      for v93_11_byte in v93_11_cursor.child_mask().iter() {
        v93_11_cursor.descend_to_byte(v93_11_byte);
        let v93_11_tail = v93_11_cursor.make_map();
        v93_11_cursor.ascend(1);
        let v93_11_head = Path::from_slice(&[v93_11_byte]);
        let v94_2: Space = singleton(&(v93_11_head));
        let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
        let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
        drop(v94_3);
        let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
        drop(v94_4);
        let v94_8: Space = if (v94_5).is_empty() { Space::new() } else {
          let v95_6: Path = concat_path(&(v93_6),&(v93_11_head));
          let v95_7: Space = routine_20(c, &(v95_6), &(v93_11_tail));
          compose(&(v94_5),&(v95_7))
        };
        drop(v94_5);
        let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
        drop(v94_2);
        let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
        drop(v94_9);
        let v94_12: Space = if (v94_10).is_empty() { Space::new() } else {
          let v96_6: Path = concat_path(&(v93_6),&(v93_11_head));
          let v96_11: Space = routine_17(c, &(v96_6), &(v93_11_tail));
          drop(v96_6);
          compose(&(v94_10),&(v96_11))
        };
        drop(v94_10);
        let v94_13: Space = unite(&(v94_8),&(v94_12));
        v93_11.join_into((v94_13).clone());
      }
      drop(v93_11_cursor);
      drop(v93_6);
      compose(&(v88_10),&(v93_11))
    };
    drop(v88_10);
    let v88_13: Space = unite(&(v88_8),&(v88_12));
    v87_11.join_into((v88_13).clone());
  }
  drop(v87_11_cursor);
  (v87_11).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v97_8 = Space::new();
  let mut v97_8_cursor = (*s0).read_zipper();
  for v97_8_byte in v97_8_cursor.child_mask().iter() {
    v97_8_cursor.descend_to_byte(v97_8_byte);
    let v97_8_tail = v97_8_cursor.make_map();
    v97_8_cursor.ascend(1);
    let v97_8_head = Path::from_slice(&[v97_8_byte]);
    let v98_2: Space = singleton(&(v97_8_head));
    let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
    let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
    drop(v98_3);
    let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
    drop(v98_4);
    let v98_8: Space = if (v98_5).is_empty() { Space::new() } else {
      let v99_6: Path = concat_path(&(*p0),&(v97_8_head));
      let mut v99_7 = Space::new();
      let mut v99_7_cursor = (v97_8_tail).read_zipper();
      for v99_7_byte in v99_7_cursor.child_mask().iter() {
        v99_7_cursor.descend_to_byte(v99_7_byte);
        let v99_7_tail = v99_7_cursor.make_map();
        v99_7_cursor.ascend(1);
        let v99_7_head = Path::from_slice(&[v99_7_byte]);
        let v100_2: Space = singleton(&(v99_7_head));
        let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
        let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
        drop(v100_3);
        let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
        drop(v100_4);
        let v100_8: Space = if (v100_5).is_empty() { Space::new() } else {
          let v101_6: Path = concat_path(&(v99_6),&(v99_7_head));
          let v101_7: Space = routine_20(c, &(v101_6), &(v99_7_tail));
          compose(&(v100_5),&(v101_7))
        };
        drop(v100_5);
        let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
        drop(v100_2);
        let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
        drop(v100_9);
        let v100_12: Space = if (v100_10).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v99_6),&(v99_7_head));
          let v102_11: Space = routine_21(c, &(v102_6), &(v99_7_tail));
          drop(v102_6);
          compose(&(v100_10),&(v102_11))
        };
        drop(v100_10);
        let v100_13: Space = unite(&(v100_8),&(v100_12));
        v99_7.join_into((v100_13).clone());
      }
      drop(v99_7_cursor);
      drop(v99_6);
      compose(&(v98_5),&(v99_7))
    };
    drop(v98_5);
    let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
    drop(v98_2);
    let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
    drop(v98_9);
    let v98_11: Space = compose(&(v98_10),&(v97_8_tail));
    drop(v98_10);
    let v98_12: Space = unite(&(v98_8),&(v98_11));
    drop(v98_11);
    v97_8.join_into((v98_12).clone());
  }
  drop(v97_8_cursor);
  (v97_8).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v103_11 = Space::new();
  let mut v103_11_cursor = (*s0).read_zipper();
  for v103_11_byte in v103_11_cursor.child_mask().iter() {
    v103_11_cursor.descend_to_byte(v103_11_byte);
    let v103_11_tail = v103_11_cursor.make_map();
    v103_11_cursor.ascend(1);
    let v103_11_head = Path::from_slice(&[v103_11_byte]);
    let v104_2: Space = singleton(&(v103_11_head));
    let v104_3: Space = intersect(&(*CONSTANT_1),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_8: Space = if (v104_5).is_empty() { Space::new() } else {
      let v105_6: Path = concat_path(&(*p0),&(v103_11_head));
      let mut v105_7 = Space::new();
      let mut v105_7_cursor = (v103_11_tail).read_zipper();
      for v105_7_byte in v105_7_cursor.child_mask().iter() {
        v105_7_cursor.descend_to_byte(v105_7_byte);
        let v105_7_tail = v105_7_cursor.make_map();
        v105_7_cursor.ascend(1);
        let v105_7_head = Path::from_slice(&[v105_7_byte]);
        let v106_2: Space = singleton(&(v105_7_head));
        let v106_3: Space = intersect(&(*CONSTANT_1),&(v106_2));
        let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
        drop(v106_4);
        let v106_8: Space = if (v106_5).is_empty() { Space::new() } else {
          let v107_6: Path = concat_path(&(v105_6),&(v105_7_head));
          let v107_7: Space = routine_22(c, &(v107_6), &(v105_7_tail));
          compose(&(v106_5),&(v107_7))
        };
        drop(v106_5);
        let v106_9: Space = intersect(&(*CONSTANT_1),&(v106_2));
        drop(v106_2);
        let v106_10: Space = if has_head(&(v106_9)) { singleton(&[]) } else { Space::new() };
        drop(v106_9);
        let v106_12: Space = if (v106_10).is_empty() { Space::new() } else {
          let v108_6: Path = concat_path(&(v105_6),&(v105_7_head));
          let v108_11: Space = routine_23(c, &(v108_6), &(v105_7_tail));
          drop(v108_6);
          compose(&(v106_10),&(v108_11))
        };
        drop(v106_10);
        let v106_13: Space = unite(&(v106_8),&(v106_12));
        v105_7.join_into((v106_13).clone());
      }
      drop(v105_7_cursor);
      compose(&(v104_5),&(v105_7))
    };
    drop(v104_5);
    let v104_9: Space = intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
    drop(v104_9);
    let v104_12: Space = if (v104_10).is_empty() { Space::new() } else {
      let v109_6: Path = concat_path(&(*p0),&(v103_11_head));
      let mut v109_11 = Space::new();
      let mut v109_11_cursor = (v103_11_tail).read_zipper();
      for v109_11_byte in v109_11_cursor.child_mask().iter() {
        v109_11_cursor.descend_to_byte(v109_11_byte);
        let v109_11_tail = v109_11_cursor.make_map();
        v109_11_cursor.ascend(1);
        let v109_11_head = Path::from_slice(&[v109_11_byte]);
        let v110_2: Space = singleton(&(v109_11_head));
        let v110_3: Space = intersect(&(*CONSTANT_1),&(v110_2));
        let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
        drop(v110_3);
        let v110_5: Space = subtract(&(*CONSTANT_0),&(v110_4));
        drop(v110_4);
        let v110_8: Space = if (v110_5).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v109_6),&(v109_11_head));
          let v111_7: Space = routine_22(c, &(v111_6), &(v109_11_tail));
          compose(&(v110_5),&(v111_7))
        };
        drop(v110_5);
        let v110_9: Space = intersect(&(*CONSTANT_1),&(v110_2));
        drop(v110_2);
        let v110_10: Space = if has_head(&(v110_9)) { singleton(&[]) } else { Space::new() };
        drop(v110_9);
        let v110_12: Space = if (v110_10).is_empty() { Space::new() } else {
          let v112_6: Path = concat_path(&(v109_6),&(v109_11_head));
          let v112_11: Space = routine_5(c, &(v112_6), &(v109_11_tail));
          drop(v112_6);
          compose(&(v110_10),&(v112_11))
        };
        drop(v110_10);
        let v110_13: Space = unite(&(v110_8),&(v110_12));
        v109_11.join_into((v110_13).clone());
      }
      drop(v109_11_cursor);
      drop(v109_6);
      compose(&(v104_10),&(v109_11))
    };
    drop(v104_10);
    let v104_13: Space = unite(&(v104_8),&(v104_12));
    v103_11.join_into((v104_13).clone());
  }
  drop(v103_11_cursor);
  (v103_11).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v113_8: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v113_10: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v113_21 = Space::new();
  let mut v113_21_cursor = (*s0).read_zipper();
  for v113_21_byte in v113_21_cursor.child_mask().iter() {
    v113_21_cursor.descend_to_byte(v113_21_byte);
    let v113_21_tail = v113_21_cursor.make_map();
    v113_21_cursor.ascend(1);
    let v113_21_head = Path::from_slice(&[v113_21_byte]);
    let v114_2: Space = singleton(&(v113_21_head));
    let v114_3: Space = intersect(&(*CONSTANT_1),&(v114_2));
    let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
    drop(v114_3);
    let v114_5: Space = subtract(&(*CONSTANT_0),&(v114_4));
    drop(v114_4);
    let v114_8: Space = if (v114_5).is_empty() { Space::new() } else {
      let v115_6: Path = concat_path(&(*p0),&(v113_21_head));
      let mut v115_7 = Space::new();
      let mut v115_7_cursor = (v113_21_tail).read_zipper();
      for v115_7_byte in v115_7_cursor.child_mask().iter() {
        v115_7_cursor.descend_to_byte(v115_7_byte);
        let v115_7_tail = v115_7_cursor.make_map();
        v115_7_cursor.ascend(1);
        let v115_7_head = Path::from_slice(&[v115_7_byte]);
        let v116_2: Space = singleton(&(v115_7_head));
        let v116_3: Space = intersect(&(*CONSTANT_1),&(v116_2));
        let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
        drop(v116_3);
        let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
        drop(v116_4);
        let v116_8: Space = if (v116_5).is_empty() { Space::new() } else {
          let v117_6: Path = concat_path(&(v115_6),&(v115_7_head));
          let v117_7: Space = routine_22(c, &(v117_6), &(v115_7_tail));
          compose(&(v116_5),&(v117_7))
        };
        drop(v116_5);
        let v116_9: Space = intersect(&(*CONSTANT_1),&(v116_2));
        drop(v116_2);
        let v116_10: Space = if has_head(&(v116_9)) { singleton(&[]) } else { Space::new() };
        drop(v116_9);
        let v116_12: Space = if (v116_10).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v115_6),&(v115_7_head));
          let v118_11: Space = routine_23(c, &(v118_6), &(v115_7_tail));
          drop(v118_6);
          compose(&(v116_10),&(v118_11))
        };
        drop(v116_10);
        let v116_13: Space = unite(&(v116_8),&(v116_12));
        v115_7.join_into((v116_13).clone());
      }
      drop(v115_7_cursor);
      compose(&(v114_5),&(v115_7))
    };
    drop(v114_5);
    let v114_9: Space = intersect(&(*CONSTANT_1),&(v114_2));
    drop(v114_2);
    let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
    drop(v114_9);
    let v114_19: Space = if (v114_10).is_empty() { Space::new() } else {
      let v119_11: Space = unwrap(&(v113_8),&(v113_21_head));
      let v119_12: Space = restrict_to(&(*CONSTANT_4),&(v119_11));
      drop(v119_11);
      let mut v119_13 = Space::new();
      let mut v119_13_cursor = (v119_12).read_zipper();
      for v119_13_byte in v119_13_cursor.child_mask().iter() {
        v119_13_cursor.descend_to_byte(v119_13_byte);
        let v119_13_tail = v119_13_cursor.make_map();
        v119_13_cursor.ascend(1);
        let v119_13_head = Path::from_slice(&[v119_13_byte]);
        let v120_2: Space = singleton(&(v119_13_head));
        let v120_3: Space = intersect(&(*CONSTANT_1),&(v120_2));
        let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
        drop(v120_3);
        let v120_5: Space = subtract(&(*CONSTANT_0),&(v120_4));
        drop(v120_4);
        let v120_7: Space = if (v120_5).is_empty() { Space::new() } else {
          let v121_6: Space = routine_6(c, &(v119_13_head), &(v119_13_tail));
          compose(&(v120_5),&(v121_6))
        };
        drop(v120_5);
        let v120_8: Space = intersect(&(*CONSTANT_1),&(v120_2));
        drop(v120_2);
        let v120_9: Space = if has_head(&(v120_8)) { singleton(&[]) } else { Space::new() };
        drop(v120_8);
        let v120_11: Space = if (v120_9).is_empty() { Space::new() } else {
          let v122_10: Space = routine_7(c, &(v119_13_head), &(v119_13_tail));
          compose(&(v120_9),&(v122_10))
        };
        drop(v120_9);
        let v120_12: Space = unite(&(v120_7),&(v120_11));
        v119_13.join_into((v120_12).clone());
      }
      drop(v119_13_cursor);
      drop(v119_12);
      let v119_14: Space = restrict_to(&(*CONSTANT_3),&(v119_13));
      let mut v119_15 = Space::new();
      let mut v119_15_cursor = (v119_14).read_zipper();
      for v119_15_byte in v119_15_cursor.child_mask().iter() {
        v119_15_cursor.descend_to_byte(v119_15_byte);
        let v119_15_tail = v119_15_cursor.make_map();
        v119_15_cursor.ascend(1);
        let v119_15_head = Path::from_slice(&[v119_15_byte]);
        let v123_2: Space = singleton(&(v119_15_head));
        let v123_3: Space = intersect(&(*CONSTANT_1),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
        drop(v123_4);
        let v123_7: Space = if (v123_5).is_empty() { Space::new() } else {
          let v124_6: Space = routine_8(c, &(v119_15_head), &(v119_15_tail));
          compose(&(v123_5),&(v124_6))
        };
        drop(v123_5);
        let v123_8: Space = intersect(&(*CONSTANT_1),&(v123_2));
        drop(v123_2);
        let v123_9: Space = if has_head(&(v123_8)) { singleton(&[]) } else { Space::new() };
        drop(v123_8);
        let v123_11: Space = if (v123_9).is_empty() { Space::new() } else {
          let v125_10: Space = routine_9(c, &(v119_15_head), &(v119_15_tail));
          compose(&(v123_9),&(v125_10))
        };
        drop(v123_9);
        let v123_12: Space = unite(&(v123_7),&(v123_11));
        v119_15.join_into((v123_12).clone());
      }
      drop(v119_15_cursor);
      let v119_16: Space = unwrap(&(v113_10),&(v113_21_head));
      let v119_17: Space = subtract(&(v119_15),&(v119_16));
      drop(v119_16);
      let v119_18: Space = intersect(&(v119_17),&(*CONSTANT_5));
      compose(&(v114_10),&(v119_18))
    };
    drop(v114_10);
    let v126_6: Path = concat_path(&(*p0),&(v113_21_head));
    let v114_20: Space = wrap(&(v114_19),&(v126_6));
    let v114_21: Space = unite(&(v114_8),&(v114_20));
    v113_21.join_into((v114_21).clone());
  }
  drop(v113_21_cursor);
  drop(v113_8);
  drop(v113_10);
  (v113_21).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v127_11 = Space::new();
  let mut v127_11_cursor = (*s0).read_zipper();
  for v127_11_byte in v127_11_cursor.child_mask().iter() {
    v127_11_cursor.descend_to_byte(v127_11_byte);
    let v127_11_tail = v127_11_cursor.make_map();
    v127_11_cursor.ascend(1);
    let v127_11_head = Path::from_slice(&[v127_11_byte]);
    let v128_2: Space = singleton(&(v127_11_head));
    let v128_3: Space = intersect(&(*CONSTANT_1),&(v128_2));
    let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
    drop(v128_3);
    let v128_5: Space = subtract(&(*CONSTANT_0),&(v128_4));
    drop(v128_4);
    let v128_8: Space = if (v128_5).is_empty() { Space::new() } else {
      let v129_6: Path = concat_path(&(*p0),&(v127_11_head));
      let mut v129_7 = Space::new();
      let mut v129_7_cursor = (v127_11_tail).read_zipper();
      for v129_7_byte in v129_7_cursor.child_mask().iter() {
        v129_7_cursor.descend_to_byte(v129_7_byte);
        let v129_7_tail = v129_7_cursor.make_map();
        v129_7_cursor.ascend(1);
        let v129_7_head = Path::from_slice(&[v129_7_byte]);
        let v130_2: Space = singleton(&(v129_7_head));
        let v130_3: Space = intersect(&(*CONSTANT_1),&(v130_2));
        let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
        drop(v130_3);
        let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
        drop(v130_4);
        let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
          let v131_6: Path = concat_path(&(v129_6),&(v129_7_head));
          let v131_7: Space = routine_24(c, &(v131_6), &(v129_7_tail));
          compose(&(v130_5),&(v131_7))
        };
        drop(v130_5);
        let v130_9: Space = intersect(&(*CONSTANT_1),&(v130_2));
        drop(v130_2);
        let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
        drop(v130_9);
        let v130_12: Space = if (v130_10).is_empty() { Space::new() } else {
          let v132_6: Path = concat_path(&(v129_6),&(v129_7_head));
          let v132_11: Space = routine_25(c, &(v132_6), &(v129_7_tail));
          drop(v132_6);
          compose(&(v130_10),&(v132_11))
        };
        drop(v130_10);
        let v130_13: Space = unite(&(v130_8),&(v130_12));
        v129_7.join_into((v130_13).clone());
      }
      drop(v129_7_cursor);
      compose(&(v128_5),&(v129_7))
    };
    drop(v128_5);
    let v128_9: Space = intersect(&(*CONSTANT_1),&(v128_2));
    drop(v128_2);
    let v128_10: Space = if has_head(&(v128_9)) { singleton(&[]) } else { Space::new() };
    drop(v128_9);
    let v128_12: Space = if (v128_10).is_empty() { Space::new() } else {
      let v133_6: Path = concat_path(&(*p0),&(v127_11_head));
      let mut v133_11 = Space::new();
      let mut v133_11_cursor = (v127_11_tail).read_zipper();
      for v133_11_byte in v133_11_cursor.child_mask().iter() {
        v133_11_cursor.descend_to_byte(v133_11_byte);
        let v133_11_tail = v133_11_cursor.make_map();
        v133_11_cursor.ascend(1);
        let v133_11_head = Path::from_slice(&[v133_11_byte]);
        let v134_2: Space = singleton(&(v133_11_head));
        let v134_3: Space = intersect(&(*CONSTANT_1),&(v134_2));
        let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
        drop(v134_3);
        let v134_5: Space = subtract(&(*CONSTANT_0),&(v134_4));
        drop(v134_4);
        let v134_8: Space = if (v134_5).is_empty() { Space::new() } else {
          let v135_6: Path = concat_path(&(v133_6),&(v133_11_head));
          let v135_7: Space = routine_24(c, &(v135_6), &(v133_11_tail));
          compose(&(v134_5),&(v135_7))
        };
        drop(v134_5);
        let v134_9: Space = intersect(&(*CONSTANT_1),&(v134_2));
        drop(v134_2);
        let v134_10: Space = if has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
        drop(v134_9);
        let v134_12: Space = if (v134_10).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v133_6),&(v133_11_head));
          let v136_11: Space = routine_14(c, &(v136_6), &(v133_11_tail));
          drop(v136_6);
          compose(&(v134_10),&(v136_11))
        };
        drop(v134_10);
        let v134_13: Space = unite(&(v134_8),&(v134_12));
        v133_11.join_into((v134_13).clone());
      }
      drop(v133_11_cursor);
      drop(v133_6);
      compose(&(v128_10),&(v133_11))
    };
    drop(v128_10);
    let v128_13: Space = unite(&(v128_8),&(v128_12));
    v127_11.join_into((v128_13).clone());
  }
  drop(v127_11_cursor);
  (v127_11).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v137_8 = Space::new();
  let mut v137_8_cursor = (*s0).read_zipper();
  for v137_8_byte in v137_8_cursor.child_mask().iter() {
    v137_8_cursor.descend_to_byte(v137_8_byte);
    let v137_8_tail = v137_8_cursor.make_map();
    v137_8_cursor.ascend(1);
    let v137_8_head = Path::from_slice(&[v137_8_byte]);
    let v138_2: Space = singleton(&(v137_8_head));
    let v138_3: Space = intersect(&(*CONSTANT_1),&(v138_2));
    let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
    drop(v138_3);
    let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
    drop(v138_4);
    let v138_8: Space = if (v138_5).is_empty() { Space::new() } else {
      let v139_6: Path = concat_path(&(*p0),&(v137_8_head));
      let mut v139_7 = Space::new();
      let mut v139_7_cursor = (v137_8_tail).read_zipper();
      for v139_7_byte in v139_7_cursor.child_mask().iter() {
        v139_7_cursor.descend_to_byte(v139_7_byte);
        let v139_7_tail = v139_7_cursor.make_map();
        v139_7_cursor.ascend(1);
        let v139_7_head = Path::from_slice(&[v139_7_byte]);
        let v140_2: Space = singleton(&(v139_7_head));
        let v140_3: Space = intersect(&(*CONSTANT_1),&(v140_2));
        let v140_4: Space = if has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
        drop(v140_3);
        let v140_5: Space = subtract(&(*CONSTANT_0),&(v140_4));
        drop(v140_4);
        let v140_8: Space = if (v140_5).is_empty() { Space::new() } else {
          let v141_6: Path = concat_path(&(v139_6),&(v139_7_head));
          let v141_7: Space = routine_24(c, &(v141_6), &(v139_7_tail));
          compose(&(v140_5),&(v141_7))
        };
        drop(v140_5);
        let v140_9: Space = intersect(&(*CONSTANT_1),&(v140_2));
        drop(v140_2);
        let v140_10: Space = if has_head(&(v140_9)) { singleton(&[]) } else { Space::new() };
        drop(v140_9);
        let v140_12: Space = if (v140_10).is_empty() { Space::new() } else {
          let v142_6: Path = concat_path(&(v139_6),&(v139_7_head));
          let v142_11: Space = routine_25(c, &(v142_6), &(v139_7_tail));
          drop(v142_6);
          compose(&(v140_10),&(v142_11))
        };
        drop(v140_10);
        let v140_13: Space = unite(&(v140_8),&(v140_12));
        v139_7.join_into((v140_13).clone());
      }
      drop(v139_7_cursor);
      drop(v139_6);
      compose(&(v138_5),&(v139_7))
    };
    drop(v138_5);
    let v138_9: Space = intersect(&(*CONSTANT_1),&(v138_2));
    drop(v138_2);
    let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
    drop(v138_9);
    let v138_11: Space = compose(&(v138_10),&(v137_8_tail));
    drop(v138_10);
    let v138_12: Space = unite(&(v138_8),&(v138_11));
    drop(v138_11);
    v137_8.join_into((v138_12).clone());
  }
  drop(v137_8_cursor);
  (v137_8).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v144_11 = Space::new();
  let mut v144_11_cursor = (*s0).read_zipper();
  for v144_11_byte in v144_11_cursor.child_mask().iter() {
    v144_11_cursor.descend_to_byte(v144_11_byte);
    let v144_11_tail = v144_11_cursor.make_map();
    v144_11_cursor.ascend(1);
    let v144_11_head = Path::from_slice(&[v144_11_byte]);
    let v145_2: Space = singleton(&(v144_11_head));
    let v145_3: Space = intersect(&(*CONSTANT_1),&(v145_2));
    let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
    drop(v145_3);
    let v145_5: Space = subtract(&(*CONSTANT_0),&(v145_4));
    drop(v145_4);
    let v145_8: Space = if (v145_5).is_empty() { Space::new() } else {
      let v146_6: Path = concat_path(&(*p0),&(v144_11_head));
      let mut v146_7 = Space::new();
      let mut v146_7_cursor = (v144_11_tail).read_zipper();
      for v146_7_byte in v146_7_cursor.child_mask().iter() {
        v146_7_cursor.descend_to_byte(v146_7_byte);
        let v146_7_tail = v146_7_cursor.make_map();
        v146_7_cursor.ascend(1);
        let v146_7_head = Path::from_slice(&[v146_7_byte]);
        let v147_2: Space = singleton(&(v146_7_head));
        let v147_3: Space = intersect(&(*CONSTANT_1),&(v147_2));
        let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
        drop(v147_3);
        let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
        drop(v147_4);
        let v147_8: Space = if (v147_5).is_empty() { Space::new() } else {
          let v148_6: Path = concat_path(&(v146_6),&(v146_7_head));
          let v148_7: Space = routine_26(c, &(v148_6), &(v146_7_tail));
          compose(&(v147_5),&(v148_7))
        };
        drop(v147_5);
        let v147_9: Space = intersect(&(*CONSTANT_1),&(v147_2));
        drop(v147_2);
        let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
        drop(v147_9);
        let v147_12: Space = if (v147_10).is_empty() { Space::new() } else {
          let v149_6: Path = concat_path(&(v146_6),&(v146_7_head));
          let v149_11: Space = routine_27(c, &(v149_6), &(v146_7_tail));
          drop(v149_6);
          compose(&(v147_10),&(v149_11))
        };
        drop(v147_10);
        let v147_13: Space = unite(&(v147_8),&(v147_12));
        v146_7.join_into((v147_13).clone());
      }
      drop(v146_7_cursor);
      compose(&(v145_5),&(v146_7))
    };
    drop(v145_5);
    let v145_9: Space = intersect(&(*CONSTANT_1),&(v145_2));
    drop(v145_2);
    let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
    drop(v145_9);
    let v145_12: Space = if (v145_10).is_empty() { Space::new() } else {
      let v150_6: Path = concat_path(&(*p0),&(v144_11_head));
      let mut v150_11 = Space::new();
      let mut v150_11_cursor = (v144_11_tail).read_zipper();
      for v150_11_byte in v150_11_cursor.child_mask().iter() {
        v150_11_cursor.descend_to_byte(v150_11_byte);
        let v150_11_tail = v150_11_cursor.make_map();
        v150_11_cursor.ascend(1);
        let v150_11_head = Path::from_slice(&[v150_11_byte]);
        let v151_2: Space = singleton(&(v150_11_head));
        let v151_3: Space = intersect(&(*CONSTANT_1),&(v151_2));
        let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
        drop(v151_3);
        let v151_5: Space = subtract(&(*CONSTANT_0),&(v151_4));
        drop(v151_4);
        let v151_8: Space = if (v151_5).is_empty() { Space::new() } else {
          let v152_6: Path = concat_path(&(v150_6),&(v150_11_head));
          let v152_7: Space = routine_26(c, &(v152_6), &(v150_11_tail));
          compose(&(v151_5),&(v152_7))
        };
        drop(v151_5);
        let v151_9: Space = intersect(&(*CONSTANT_1),&(v151_2));
        drop(v151_2);
        let v151_10: Space = if has_head(&(v151_9)) { singleton(&[]) } else { Space::new() };
        drop(v151_9);
        let v151_12: Space = if (v151_10).is_empty() { Space::new() } else {
          let v153_6: Path = concat_path(&(v150_6),&(v150_11_head));
          let v153_11: Space = routine_17(c, &(v153_6), &(v150_11_tail));
          drop(v153_6);
          compose(&(v151_10),&(v153_11))
        };
        drop(v151_10);
        let v151_13: Space = unite(&(v151_8),&(v151_12));
        v150_11.join_into((v151_13).clone());
      }
      drop(v150_11_cursor);
      drop(v150_6);
      compose(&(v145_10),&(v150_11))
    };
    drop(v145_10);
    let v145_13: Space = unite(&(v145_8),&(v145_12));
    v144_11.join_into((v145_13).clone());
  }
  drop(v144_11_cursor);
  (v144_11).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v154_8 = Space::new();
  let mut v154_8_cursor = (*s0).read_zipper();
  for v154_8_byte in v154_8_cursor.child_mask().iter() {
    v154_8_cursor.descend_to_byte(v154_8_byte);
    let v154_8_tail = v154_8_cursor.make_map();
    v154_8_cursor.ascend(1);
    let v154_8_head = Path::from_slice(&[v154_8_byte]);
    let v155_2: Space = singleton(&(v154_8_head));
    let v155_3: Space = intersect(&(*CONSTANT_1),&(v155_2));
    let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
    drop(v155_3);
    let v155_5: Space = subtract(&(*CONSTANT_0),&(v155_4));
    drop(v155_4);
    let v155_8: Space = if (v155_5).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&(v154_8_head));
      let mut v156_7 = Space::new();
      let mut v156_7_cursor = (v154_8_tail).read_zipper();
      for v156_7_byte in v156_7_cursor.child_mask().iter() {
        v156_7_cursor.descend_to_byte(v156_7_byte);
        let v156_7_tail = v156_7_cursor.make_map();
        v156_7_cursor.ascend(1);
        let v156_7_head = Path::from_slice(&[v156_7_byte]);
        let v157_2: Space = singleton(&(v156_7_head));
        let v157_3: Space = intersect(&(*CONSTANT_1),&(v157_2));
        let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = subtract(&(*CONSTANT_0),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&(v156_7_head));
          let v158_7: Space = routine_26(c, &(v158_6), &(v156_7_tail));
          compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = intersect(&(*CONSTANT_1),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
          let v159_6: Path = concat_path(&(v156_6),&(v156_7_head));
          let v159_11: Space = routine_27(c, &(v159_6), &(v156_7_tail));
          drop(v159_6);
          compose(&(v157_10),&(v159_11))
        };
        drop(v157_10);
        let v157_13: Space = unite(&(v157_8),&(v157_12));
        v156_7.join_into((v157_13).clone());
      }
      drop(v156_7_cursor);
      drop(v156_6);
      compose(&(v155_5),&(v156_7))
    };
    drop(v155_5);
    let v155_9: Space = intersect(&(*CONSTANT_1),&(v155_2));
    drop(v155_2);
    let v155_10: Space = if has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
    drop(v155_9);
    let v155_11: Space = compose(&(v155_10),&(v154_8_tail));
    drop(v155_10);
    let v155_12: Space = unite(&(v155_8),&(v155_11));
    drop(v155_11);
    v154_8.join_into((v155_12).clone());
  }
  drop(v154_8_cursor);
  (v154_8).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v161_11 = Space::new();
  let mut v161_11_cursor = (*s0).read_zipper();
  for v161_11_byte in v161_11_cursor.child_mask().iter() {
    v161_11_cursor.descend_to_byte(v161_11_byte);
    let v161_11_tail = v161_11_cursor.make_map();
    v161_11_cursor.ascend(1);
    let v161_11_head = Path::from_slice(&[v161_11_byte]);
    let v162_2: Space = singleton(&(v161_11_head));
    let v162_3: Space = intersect(&(*CONSTANT_1),&(v162_2));
    let v162_4: Space = if has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
    drop(v162_3);
    let v162_5: Space = subtract(&(*CONSTANT_0),&(v162_4));
    drop(v162_4);
    let v162_8: Space = if (v162_5).is_empty() { Space::new() } else {
      let v163_6: Path = concat_path(&(*p0),&(v161_11_head));
      let mut v163_7 = Space::new();
      let mut v163_7_cursor = (v161_11_tail).read_zipper();
      for v163_7_byte in v163_7_cursor.child_mask().iter() {
        v163_7_cursor.descend_to_byte(v163_7_byte);
        let v163_7_tail = v163_7_cursor.make_map();
        v163_7_cursor.ascend(1);
        let v163_7_head = Path::from_slice(&[v163_7_byte]);
        let v164_2: Space = singleton(&(v163_7_head));
        let v164_3: Space = intersect(&(*CONSTANT_1),&(v164_2));
        let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
        drop(v164_3);
        let v164_5: Space = subtract(&(*CONSTANT_0),&(v164_4));
        drop(v164_4);
        let v164_8: Space = if (v164_5).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v163_6),&(v163_7_head));
          let v165_7: Space = routine_28(c, &(v165_6), &(v163_7_tail));
          compose(&(v164_5),&(v165_7))
        };
        drop(v164_5);
        let v164_9: Space = intersect(&(*CONSTANT_1),&(v164_2));
        drop(v164_2);
        let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
        drop(v164_9);
        let v164_12: Space = if (v164_10).is_empty() { Space::new() } else {
          let v166_6: Path = concat_path(&(v163_6),&(v163_7_head));
          let v166_11: Space = routine_29(c, &(v166_6), &(v163_7_tail));
          drop(v166_6);
          compose(&(v164_10),&(v166_11))
        };
        drop(v164_10);
        let v164_13: Space = unite(&(v164_8),&(v164_12));
        v163_7.join_into((v164_13).clone());
      }
      drop(v163_7_cursor);
      compose(&(v162_5),&(v163_7))
    };
    drop(v162_5);
    let v162_9: Space = intersect(&(*CONSTANT_1),&(v162_2));
    drop(v162_2);
    let v162_10: Space = if has_head(&(v162_9)) { singleton(&[]) } else { Space::new() };
    drop(v162_9);
    let v162_12: Space = if (v162_10).is_empty() { Space::new() } else {
      let v167_6: Path = concat_path(&(*p0),&(v161_11_head));
      let mut v167_11 = Space::new();
      let mut v167_11_cursor = (v161_11_tail).read_zipper();
      for v167_11_byte in v167_11_cursor.child_mask().iter() {
        v167_11_cursor.descend_to_byte(v167_11_byte);
        let v167_11_tail = v167_11_cursor.make_map();
        v167_11_cursor.ascend(1);
        let v167_11_head = Path::from_slice(&[v167_11_byte]);
        let v168_2: Space = singleton(&(v167_11_head));
        let v168_3: Space = intersect(&(*CONSTANT_1),&(v168_2));
        let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
        drop(v168_3);
        let v168_5: Space = subtract(&(*CONSTANT_0),&(v168_4));
        drop(v168_4);
        let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
          let v169_6: Path = concat_path(&(v167_6),&(v167_11_head));
          let v169_7: Space = routine_28(c, &(v169_6), &(v167_11_tail));
          compose(&(v168_5),&(v169_7))
        };
        drop(v168_5);
        let v168_9: Space = intersect(&(*CONSTANT_1),&(v168_2));
        drop(v168_2);
        let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
        drop(v168_9);
        let v168_12: Space = if (v168_10).is_empty() { Space::new() } else {
          let v170_6: Path = concat_path(&(v167_6),&(v167_11_head));
          let v170_11: Space = routine_14(c, &(v170_6), &(v167_11_tail));
          drop(v170_6);
          compose(&(v168_10),&(v170_11))
        };
        drop(v168_10);
        let v168_13: Space = unite(&(v168_8),&(v168_12));
        v167_11.join_into((v168_13).clone());
      }
      drop(v167_11_cursor);
      drop(v167_6);
      compose(&(v162_10),&(v167_11))
    };
    drop(v162_10);
    let v162_13: Space = unite(&(v162_8),&(v162_12));
    v161_11.join_into((v162_13).clone());
  }
  drop(v161_11_cursor);
  (v161_11).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v171_8 = Space::new();
  let mut v171_8_cursor = (*s0).read_zipper();
  for v171_8_byte in v171_8_cursor.child_mask().iter() {
    v171_8_cursor.descend_to_byte(v171_8_byte);
    let v171_8_tail = v171_8_cursor.make_map();
    v171_8_cursor.ascend(1);
    let v171_8_head = Path::from_slice(&[v171_8_byte]);
    let v172_2: Space = singleton(&(v171_8_head));
    let v172_3: Space = intersect(&(*CONSTANT_1),&(v172_2));
    let v172_4: Space = if has_head(&(v172_3)) { singleton(&[]) } else { Space::new() };
    drop(v172_3);
    let v172_5: Space = subtract(&(*CONSTANT_0),&(v172_4));
    drop(v172_4);
    let v172_8: Space = if (v172_5).is_empty() { Space::new() } else {
      let v173_6: Path = concat_path(&(*p0),&(v171_8_head));
      let mut v173_7 = Space::new();
      let mut v173_7_cursor = (v171_8_tail).read_zipper();
      for v173_7_byte in v173_7_cursor.child_mask().iter() {
        v173_7_cursor.descend_to_byte(v173_7_byte);
        let v173_7_tail = v173_7_cursor.make_map();
        v173_7_cursor.ascend(1);
        let v173_7_head = Path::from_slice(&[v173_7_byte]);
        let v174_2: Space = singleton(&(v173_7_head));
        let v174_3: Space = intersect(&(*CONSTANT_1),&(v174_2));
        let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
        drop(v174_3);
        let v174_5: Space = subtract(&(*CONSTANT_0),&(v174_4));
        drop(v174_4);
        let v174_8: Space = if (v174_5).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v173_6),&(v173_7_head));
          let v175_7: Space = routine_28(c, &(v175_6), &(v173_7_tail));
          compose(&(v174_5),&(v175_7))
        };
        drop(v174_5);
        let v174_9: Space = intersect(&(*CONSTANT_1),&(v174_2));
        drop(v174_2);
        let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
        drop(v174_9);
        let v174_12: Space = if (v174_10).is_empty() { Space::new() } else {
          let v176_6: Path = concat_path(&(v173_6),&(v173_7_head));
          let v176_11: Space = routine_29(c, &(v176_6), &(v173_7_tail));
          drop(v176_6);
          compose(&(v174_10),&(v176_11))
        };
        drop(v174_10);
        let v174_13: Space = unite(&(v174_8),&(v174_12));
        v173_7.join_into((v174_13).clone());
      }
      drop(v173_7_cursor);
      drop(v173_6);
      compose(&(v172_5),&(v173_7))
    };
    drop(v172_5);
    let v172_9: Space = intersect(&(*CONSTANT_1),&(v172_2));
    drop(v172_2);
    let v172_10: Space = if has_head(&(v172_9)) { singleton(&[]) } else { Space::new() };
    drop(v172_9);
    let v172_11: Space = compose(&(v172_10),&(v171_8_tail));
    drop(v172_10);
    let v172_12: Space = unite(&(v172_8),&(v172_11));
    drop(v172_11);
    v171_8.join_into((v172_12).clone());
  }
  drop(v171_8_cursor);
  (v171_8).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v177_11 = Space::new();
  let mut v177_11_cursor = (*s0).read_zipper();
  for v177_11_byte in v177_11_cursor.child_mask().iter() {
    v177_11_cursor.descend_to_byte(v177_11_byte);
    let v177_11_tail = v177_11_cursor.make_map();
    v177_11_cursor.ascend(1);
    let v177_11_head = Path::from_slice(&[v177_11_byte]);
    let v178_2: Space = singleton(&(v177_11_head));
    let v178_3: Space = intersect(&(*CONSTANT_1),&(v178_2));
    let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
    drop(v178_3);
    let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
    drop(v178_4);
    let v178_8: Space = if (v178_5).is_empty() { Space::new() } else {
      let v179_6: Path = concat_path(&(*p0),&(v177_11_head));
      let mut v179_7 = Space::new();
      let mut v179_7_cursor = (v177_11_tail).read_zipper();
      for v179_7_byte in v179_7_cursor.child_mask().iter() {
        v179_7_cursor.descend_to_byte(v179_7_byte);
        let v179_7_tail = v179_7_cursor.make_map();
        v179_7_cursor.ascend(1);
        let v179_7_head = Path::from_slice(&[v179_7_byte]);
        let v180_2: Space = singleton(&(v179_7_head));
        let v180_3: Space = intersect(&(*CONSTANT_1),&(v180_2));
        let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
        drop(v180_3);
        let v180_5: Space = subtract(&(*CONSTANT_0),&(v180_4));
        drop(v180_4);
        let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v181_7: Space = routine_30(c, &(v181_6), &(v179_7_tail));
          compose(&(v180_5),&(v181_7))
        };
        drop(v180_5);
        let v180_9: Space = intersect(&(*CONSTANT_1),&(v180_2));
        drop(v180_2);
        let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
        drop(v180_9);
        let v180_12: Space = if (v180_10).is_empty() { Space::new() } else {
          let v182_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v182_11: Space = routine_31(c, &(v182_6), &(v179_7_tail));
          drop(v182_6);
          compose(&(v180_10),&(v182_11))
        };
        drop(v180_10);
        let v180_13: Space = unite(&(v180_8),&(v180_12));
        v179_7.join_into((v180_13).clone());
      }
      drop(v179_7_cursor);
      compose(&(v178_5),&(v179_7))
    };
    drop(v178_5);
    let v178_9: Space = intersect(&(*CONSTANT_1),&(v178_2));
    drop(v178_2);
    let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
    drop(v178_9);
    let v178_12: Space = if (v178_10).is_empty() { Space::new() } else {
      let v183_6: Path = concat_path(&(*p0),&(v177_11_head));
      let mut v183_11 = Space::new();
      let mut v183_11_cursor = (v177_11_tail).read_zipper();
      for v183_11_byte in v183_11_cursor.child_mask().iter() {
        v183_11_cursor.descend_to_byte(v183_11_byte);
        let v183_11_tail = v183_11_cursor.make_map();
        v183_11_cursor.ascend(1);
        let v183_11_head = Path::from_slice(&[v183_11_byte]);
        let v184_2: Space = singleton(&(v183_11_head));
        let v184_3: Space = intersect(&(*CONSTANT_1),&(v184_2));
        let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
        drop(v184_3);
        let v184_5: Space = subtract(&(*CONSTANT_0),&(v184_4));
        drop(v184_4);
        let v184_8: Space = if (v184_5).is_empty() { Space::new() } else {
          let v185_6: Path = concat_path(&(v183_6),&(v183_11_head));
          let v185_7: Space = routine_30(c, &(v185_6), &(v183_11_tail));
          compose(&(v184_5),&(v185_7))
        };
        drop(v184_5);
        let v184_9: Space = intersect(&(*CONSTANT_1),&(v184_2));
        drop(v184_2);
        let v184_10: Space = if has_head(&(v184_9)) { singleton(&[]) } else { Space::new() };
        drop(v184_9);
        let v184_12: Space = if (v184_10).is_empty() { Space::new() } else {
          let v186_6: Path = concat_path(&(v183_6),&(v183_11_head));
          let v186_11: Space = routine_17(c, &(v186_6), &(v183_11_tail));
          drop(v186_6);
          compose(&(v184_10),&(v186_11))
        };
        drop(v184_10);
        let v184_13: Space = unite(&(v184_8),&(v184_12));
        v183_11.join_into((v184_13).clone());
      }
      drop(v183_11_cursor);
      drop(v183_6);
      compose(&(v178_10),&(v183_11))
    };
    drop(v178_10);
    let v178_13: Space = unite(&(v178_8),&(v178_12));
    v177_11.join_into((v178_13).clone());
  }
  drop(v177_11_cursor);
  (v177_11).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v187_8 = Space::new();
  let mut v187_8_cursor = (*s0).read_zipper();
  for v187_8_byte in v187_8_cursor.child_mask().iter() {
    v187_8_cursor.descend_to_byte(v187_8_byte);
    let v187_8_tail = v187_8_cursor.make_map();
    v187_8_cursor.ascend(1);
    let v187_8_head = Path::from_slice(&[v187_8_byte]);
    let v188_2: Space = singleton(&(v187_8_head));
    let v188_3: Space = intersect(&(*CONSTANT_1),&(v188_2));
    let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
    drop(v188_3);
    let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
    drop(v188_4);
    let v188_8: Space = if (v188_5).is_empty() { Space::new() } else {
      let v189_6: Path = concat_path(&(*p0),&(v187_8_head));
      let mut v189_7 = Space::new();
      let mut v189_7_cursor = (v187_8_tail).read_zipper();
      for v189_7_byte in v189_7_cursor.child_mask().iter() {
        v189_7_cursor.descend_to_byte(v189_7_byte);
        let v189_7_tail = v189_7_cursor.make_map();
        v189_7_cursor.ascend(1);
        let v189_7_head = Path::from_slice(&[v189_7_byte]);
        let v190_2: Space = singleton(&(v189_7_head));
        let v190_3: Space = intersect(&(*CONSTANT_1),&(v190_2));
        let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
        drop(v190_3);
        let v190_5: Space = subtract(&(*CONSTANT_0),&(v190_4));
        drop(v190_4);
        let v190_8: Space = if (v190_5).is_empty() { Space::new() } else {
          let v191_6: Path = concat_path(&(v189_6),&(v189_7_head));
          let v191_7: Space = routine_30(c, &(v191_6), &(v189_7_tail));
          compose(&(v190_5),&(v191_7))
        };
        drop(v190_5);
        let v190_9: Space = intersect(&(*CONSTANT_1),&(v190_2));
        drop(v190_2);
        let v190_10: Space = if has_head(&(v190_9)) { singleton(&[]) } else { Space::new() };
        drop(v190_9);
        let v190_12: Space = if (v190_10).is_empty() { Space::new() } else {
          let v192_6: Path = concat_path(&(v189_6),&(v189_7_head));
          let v192_11: Space = routine_31(c, &(v192_6), &(v189_7_tail));
          drop(v192_6);
          compose(&(v190_10),&(v192_11))
        };
        drop(v190_10);
        let v190_13: Space = unite(&(v190_8),&(v190_12));
        v189_7.join_into((v190_13).clone());
      }
      drop(v189_7_cursor);
      drop(v189_6);
      compose(&(v188_5),&(v189_7))
    };
    drop(v188_5);
    let v188_9: Space = intersect(&(*CONSTANT_1),&(v188_2));
    drop(v188_2);
    let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
    drop(v188_9);
    let v188_11: Space = compose(&(v188_10),&(v187_8_tail));
    drop(v188_10);
    let v188_12: Space = unite(&(v188_8),&(v188_11));
    drop(v188_11);
    v187_8.join_into((v188_12).clone());
  }
  drop(v187_8_cursor);
  (v187_8).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v193_2 = Space::new();
  let mut v193_2_cursor = (*s0).read_zipper();
  for v193_2_byte in v193_2_cursor.child_mask().iter() {
    v193_2_cursor.descend_to_byte(v193_2_byte);
    let v193_2_tail = v193_2_cursor.make_map();
    v193_2_cursor.ascend(1);
    let v193_2_head = Path::from_slice(&[v193_2_byte]);
    let v194_2: Space = Space::new();
    v193_2.join_into((v194_2).clone());
  }
  drop(v193_2_cursor);
  (v193_2).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v195_6: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v195_8: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v195_16 = Space::new();
  let mut v195_16_cursor = (*s0).read_zipper();
  for v195_16_byte in v195_16_cursor.child_mask().iter() {
    v195_16_cursor.descend_to_byte(v195_16_byte);
    let v195_16_tail = v195_16_cursor.make_map();
    v195_16_cursor.ascend(1);
    let v195_16_head = Path::from_slice(&[v195_16_byte]);
    let v196_2: Space = singleton(&(v195_16_head));
    let v196_3: Space = intersect(&(*CONSTANT_1),&(v196_2));
    drop(v196_2);
    let v196_4: Space = if has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
    drop(v196_3);
    let v196_13: Space = if (v196_4).is_empty() { Space::new() } else {
      let v197_5: Space = unwrap(&(v195_6),&(v195_16_head));
      let v197_6: Space = restrict_to(&(*CONSTANT_4),&(v197_5));
      drop(v197_5);
      let mut v197_7 = Space::new();
      let mut v197_7_cursor = (v197_6).read_zipper();
      for v197_7_byte in v197_7_cursor.child_mask().iter() {
        v197_7_cursor.descend_to_byte(v197_7_byte);
        let v197_7_tail = v197_7_cursor.make_map();
        v197_7_cursor.ascend(1);
        let v197_7_head = Path::from_slice(&[v197_7_byte]);
        let v198_2: Space = singleton(&(v197_7_head));
        let v198_3: Space = intersect(&(*CONSTANT_1),&(v198_2));
        let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
        drop(v198_3);
        let v198_5: Space = subtract(&(*CONSTANT_0),&(v198_4));
        drop(v198_4);
        let v198_7: Space = if (v198_5).is_empty() { Space::new() } else {
          let v199_6: Space = routine_6(c, &(v197_7_head), &(v197_7_tail));
          compose(&(v198_5),&(v199_6))
        };
        drop(v198_5);
        let v198_8: Space = intersect(&(*CONSTANT_1),&(v198_2));
        drop(v198_2);
        let v198_9: Space = if has_head(&(v198_8)) { singleton(&[]) } else { Space::new() };
        drop(v198_8);
        let v198_11: Space = if (v198_9).is_empty() { Space::new() } else {
          let v200_10: Space = routine_7(c, &(v197_7_head), &(v197_7_tail));
          compose(&(v198_9),&(v200_10))
        };
        drop(v198_9);
        let v198_12: Space = unite(&(v198_7),&(v198_11));
        v197_7.join_into((v198_12).clone());
      }
      drop(v197_7_cursor);
      drop(v197_6);
      let v197_8: Space = restrict_to(&(*CONSTANT_3),&(v197_7));
      let mut v197_9 = Space::new();
      let mut v197_9_cursor = (v197_8).read_zipper();
      for v197_9_byte in v197_9_cursor.child_mask().iter() {
        v197_9_cursor.descend_to_byte(v197_9_byte);
        let v197_9_tail = v197_9_cursor.make_map();
        v197_9_cursor.ascend(1);
        let v197_9_head = Path::from_slice(&[v197_9_byte]);
        let v201_2: Space = singleton(&(v197_9_head));
        let v201_3: Space = intersect(&(*CONSTANT_1),&(v201_2));
        let v201_4: Space = if has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
        drop(v201_3);
        let v201_5: Space = subtract(&(*CONSTANT_0),&(v201_4));
        drop(v201_4);
        let v201_7: Space = if (v201_5).is_empty() { Space::new() } else {
          let v202_6: Space = routine_8(c, &(v197_9_head), &(v197_9_tail));
          compose(&(v201_5),&(v202_6))
        };
        drop(v201_5);
        let v201_8: Space = intersect(&(*CONSTANT_1),&(v201_2));
        drop(v201_2);
        let v201_9: Space = if has_head(&(v201_8)) { singleton(&[]) } else { Space::new() };
        drop(v201_8);
        let v201_11: Space = if (v201_9).is_empty() { Space::new() } else {
          let v203_10: Space = routine_9(c, &(v197_9_head), &(v197_9_tail));
          compose(&(v201_9),&(v203_10))
        };
        drop(v201_9);
        let v201_12: Space = unite(&(v201_7),&(v201_11));
        v197_9.join_into((v201_12).clone());
      }
      drop(v197_9_cursor);
      let v197_10: Space = unwrap(&(v195_8),&(v195_16_head));
      let v197_11: Space = subtract(&(v197_9),&(v197_10));
      drop(v197_10);
      let v197_12: Space = intersect(&(v197_11),&(*CONSTANT_5));
      compose(&(v196_4),&(v197_12))
    };
    drop(v196_4);
    let v196_14: Path = concat_path(&(*p0),&(v195_16_head));
    let v196_15: Space = wrap(&(v196_13),&(v196_14));
    drop(v196_14);
    v195_16.join_into((v196_15).clone());
  }
  drop(v195_16_cursor);
  drop(v195_6);
  drop(v195_8);
  (v195_16).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v204_11 = Space::new();
  let mut v204_11_cursor = (*s0).read_zipper();
  for v204_11_byte in v204_11_cursor.child_mask().iter() {
    v204_11_cursor.descend_to_byte(v204_11_byte);
    let v204_11_tail = v204_11_cursor.make_map();
    v204_11_cursor.ascend(1);
    let v204_11_head = Path::from_slice(&[v204_11_byte]);
    let v205_2: Space = singleton(&(v204_11_head));
    let v205_3: Space = intersect(&(*CONSTANT_1),&(v205_2));
    let v205_4: Space = if has_head(&(v205_3)) { singleton(&[]) } else { Space::new() };
    drop(v205_3);
    let v205_5: Space = subtract(&(*CONSTANT_0),&(v205_4));
    drop(v205_4);
    let v205_8: Space = if (v205_5).is_empty() { Space::new() } else {
      let v206_6: Path = concat_path(&(*p0),&(v204_11_head));
      let mut v206_7 = Space::new();
      let mut v206_7_cursor = (v204_11_tail).read_zipper();
      for v206_7_byte in v206_7_cursor.child_mask().iter() {
        v206_7_cursor.descend_to_byte(v206_7_byte);
        let v206_7_tail = v206_7_cursor.make_map();
        v206_7_cursor.ascend(1);
        let v206_7_head = Path::from_slice(&[v206_7_byte]);
        let v207_2: Space = singleton(&(v206_7_head));
        let v207_3: Space = intersect(&(*CONSTANT_1),&(v207_2));
        let v207_4: Space = if has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
        drop(v207_3);
        let v207_5: Space = subtract(&(*CONSTANT_0),&(v207_4));
        drop(v207_4);
        let v207_8: Space = if (v207_5).is_empty() { Space::new() } else {
          let v208_6: Path = concat_path(&(v206_6),&(v206_7_head));
          let v208_7: Space = routine_32(c, &(v208_6), &(v206_7_tail));
          compose(&(v207_5),&(v208_7))
        };
        drop(v207_5);
        let v207_9: Space = intersect(&(*CONSTANT_1),&(v207_2));
        drop(v207_2);
        let v207_10: Space = if has_head(&(v207_9)) { singleton(&[]) } else { Space::new() };
        drop(v207_9);
        let v207_12: Space = if (v207_10).is_empty() { Space::new() } else {
          let v209_6: Path = concat_path(&(v206_6),&(v206_7_head));
          let v209_11: Space = routine_33(c, &(v209_6), &(v206_7_tail));
          drop(v209_6);
          compose(&(v207_10),&(v209_11))
        };
        drop(v207_10);
        let v207_13: Space = unite(&(v207_8),&(v207_12));
        v206_7.join_into((v207_13).clone());
      }
      drop(v206_7_cursor);
      compose(&(v205_5),&(v206_7))
    };
    drop(v205_5);
    let v205_9: Space = intersect(&(*CONSTANT_1),&(v205_2));
    drop(v205_2);
    let v205_10: Space = if has_head(&(v205_9)) { singleton(&[]) } else { Space::new() };
    drop(v205_9);
    let v205_12: Space = if (v205_10).is_empty() { Space::new() } else {
      let v210_6: Path = concat_path(&(*p0),&(v204_11_head));
      let mut v210_11 = Space::new();
      let mut v210_11_cursor = (v204_11_tail).read_zipper();
      for v210_11_byte in v210_11_cursor.child_mask().iter() {
        v210_11_cursor.descend_to_byte(v210_11_byte);
        let v210_11_tail = v210_11_cursor.make_map();
        v210_11_cursor.ascend(1);
        let v210_11_head = Path::from_slice(&[v210_11_byte]);
        let v211_2: Space = singleton(&(v210_11_head));
        let v211_3: Space = intersect(&(*CONSTANT_1),&(v211_2));
        let v211_4: Space = if has_head(&(v211_3)) { singleton(&[]) } else { Space::new() };
        drop(v211_3);
        let v211_5: Space = subtract(&(*CONSTANT_0),&(v211_4));
        drop(v211_4);
        let v211_8: Space = if (v211_5).is_empty() { Space::new() } else {
          let v212_6: Path = concat_path(&(v210_6),&(v210_11_head));
          let v212_7: Space = routine_32(c, &(v212_6), &(v210_11_tail));
          compose(&(v211_5),&(v212_7))
        };
        drop(v211_5);
        let v211_9: Space = intersect(&(*CONSTANT_1),&(v211_2));
        drop(v211_2);
        let v211_10: Space = if has_head(&(v211_9)) { singleton(&[]) } else { Space::new() };
        drop(v211_9);
        let v211_12: Space = if (v211_10).is_empty() { Space::new() } else {
          let v213_6: Path = concat_path(&(v210_6),&(v210_11_head));
          let v213_11: Space = routine_14(c, &(v213_6), &(v210_11_tail));
          drop(v213_6);
          compose(&(v211_10),&(v213_11))
        };
        drop(v211_10);
        let v211_13: Space = unite(&(v211_8),&(v211_12));
        v210_11.join_into((v211_13).clone());
      }
      drop(v210_11_cursor);
      drop(v210_6);
      compose(&(v205_10),&(v210_11))
    };
    drop(v205_10);
    let v205_13: Space = unite(&(v205_8),&(v205_12));
    v204_11.join_into((v205_13).clone());
  }
  drop(v204_11_cursor);
  (v204_11).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v214_8 = Space::new();
  let mut v214_8_cursor = (*s0).read_zipper();
  for v214_8_byte in v214_8_cursor.child_mask().iter() {
    v214_8_cursor.descend_to_byte(v214_8_byte);
    let v214_8_tail = v214_8_cursor.make_map();
    v214_8_cursor.ascend(1);
    let v214_8_head = Path::from_slice(&[v214_8_byte]);
    let v215_2: Space = singleton(&(v214_8_head));
    let v215_3: Space = intersect(&(*CONSTANT_1),&(v215_2));
    let v215_4: Space = if has_head(&(v215_3)) { singleton(&[]) } else { Space::new() };
    drop(v215_3);
    let v215_5: Space = subtract(&(*CONSTANT_0),&(v215_4));
    drop(v215_4);
    let v215_8: Space = if (v215_5).is_empty() { Space::new() } else {
      let v216_6: Path = concat_path(&(*p0),&(v214_8_head));
      let mut v216_7 = Space::new();
      let mut v216_7_cursor = (v214_8_tail).read_zipper();
      for v216_7_byte in v216_7_cursor.child_mask().iter() {
        v216_7_cursor.descend_to_byte(v216_7_byte);
        let v216_7_tail = v216_7_cursor.make_map();
        v216_7_cursor.ascend(1);
        let v216_7_head = Path::from_slice(&[v216_7_byte]);
        let v217_2: Space = singleton(&(v216_7_head));
        let v217_3: Space = intersect(&(*CONSTANT_1),&(v217_2));
        let v217_4: Space = if has_head(&(v217_3)) { singleton(&[]) } else { Space::new() };
        drop(v217_3);
        let v217_5: Space = subtract(&(*CONSTANT_0),&(v217_4));
        drop(v217_4);
        let v217_8: Space = if (v217_5).is_empty() { Space::new() } else {
          let v218_6: Path = concat_path(&(v216_6),&(v216_7_head));
          let v218_7: Space = routine_32(c, &(v218_6), &(v216_7_tail));
          compose(&(v217_5),&(v218_7))
        };
        drop(v217_5);
        let v217_9: Space = intersect(&(*CONSTANT_1),&(v217_2));
        drop(v217_2);
        let v217_10: Space = if has_head(&(v217_9)) { singleton(&[]) } else { Space::new() };
        drop(v217_9);
        let v217_12: Space = if (v217_10).is_empty() { Space::new() } else {
          let v219_6: Path = concat_path(&(v216_6),&(v216_7_head));
          let v219_11: Space = routine_33(c, &(v219_6), &(v216_7_tail));
          drop(v219_6);
          compose(&(v217_10),&(v219_11))
        };
        drop(v217_10);
        let v217_13: Space = unite(&(v217_8),&(v217_12));
        v216_7.join_into((v217_13).clone());
      }
      drop(v216_7_cursor);
      drop(v216_6);
      compose(&(v215_5),&(v216_7))
    };
    drop(v215_5);
    let v215_9: Space = intersect(&(*CONSTANT_1),&(v215_2));
    drop(v215_2);
    let v215_10: Space = if has_head(&(v215_9)) { singleton(&[]) } else { Space::new() };
    drop(v215_9);
    let v215_11: Space = compose(&(v215_10),&(v214_8_tail));
    drop(v215_10);
    let v215_12: Space = unite(&(v215_8),&(v215_11));
    drop(v215_11);
    v214_8.join_into((v215_12).clone());
  }
  drop(v214_8_cursor);
  (v214_8).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v220_11 = Space::new();
  let mut v220_11_cursor = (*s0).read_zipper();
  for v220_11_byte in v220_11_cursor.child_mask().iter() {
    v220_11_cursor.descend_to_byte(v220_11_byte);
    let v220_11_tail = v220_11_cursor.make_map();
    v220_11_cursor.ascend(1);
    let v220_11_head = Path::from_slice(&[v220_11_byte]);
    let v221_2: Space = singleton(&(v220_11_head));
    let v221_3: Space = intersect(&(*CONSTANT_1),&(v221_2));
    let v221_4: Space = if has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
    drop(v221_3);
    let v221_5: Space = subtract(&(*CONSTANT_0),&(v221_4));
    drop(v221_4);
    let v221_8: Space = if (v221_5).is_empty() { Space::new() } else {
      let v222_6: Path = concat_path(&(*p0),&(v220_11_head));
      let mut v222_7 = Space::new();
      let mut v222_7_cursor = (v220_11_tail).read_zipper();
      for v222_7_byte in v222_7_cursor.child_mask().iter() {
        v222_7_cursor.descend_to_byte(v222_7_byte);
        let v222_7_tail = v222_7_cursor.make_map();
        v222_7_cursor.ascend(1);
        let v222_7_head = Path::from_slice(&[v222_7_byte]);
        let v223_2: Space = singleton(&(v222_7_head));
        let v223_3: Space = intersect(&(*CONSTANT_1),&(v223_2));
        let v223_4: Space = if has_head(&(v223_3)) { singleton(&[]) } else { Space::new() };
        drop(v223_3);
        let v223_5: Space = subtract(&(*CONSTANT_0),&(v223_4));
        drop(v223_4);
        let v223_8: Space = if (v223_5).is_empty() { Space::new() } else {
          let v224_6: Path = concat_path(&(v222_6),&(v222_7_head));
          let v224_7: Space = routine_34(c, &(v224_6), &(v222_7_tail));
          compose(&(v223_5),&(v224_7))
        };
        drop(v223_5);
        let v223_9: Space = intersect(&(*CONSTANT_1),&(v223_2));
        drop(v223_2);
        let v223_10: Space = if has_head(&(v223_9)) { singleton(&[]) } else { Space::new() };
        drop(v223_9);
        let v223_12: Space = if (v223_10).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v222_6),&(v222_7_head));
          let v225_11: Space = routine_35(c, &(v225_6), &(v222_7_tail));
          drop(v225_6);
          compose(&(v223_10),&(v225_11))
        };
        drop(v223_10);
        let v223_13: Space = unite(&(v223_8),&(v223_12));
        v222_7.join_into((v223_13).clone());
      }
      drop(v222_7_cursor);
      compose(&(v221_5),&(v222_7))
    };
    drop(v221_5);
    let v221_9: Space = intersect(&(*CONSTANT_1),&(v221_2));
    drop(v221_2);
    let v221_10: Space = if has_head(&(v221_9)) { singleton(&[]) } else { Space::new() };
    drop(v221_9);
    let v221_12: Space = if (v221_10).is_empty() { Space::new() } else {
      let v226_6: Path = concat_path(&(*p0),&(v220_11_head));
      let mut v226_11 = Space::new();
      let mut v226_11_cursor = (v220_11_tail).read_zipper();
      for v226_11_byte in v226_11_cursor.child_mask().iter() {
        v226_11_cursor.descend_to_byte(v226_11_byte);
        let v226_11_tail = v226_11_cursor.make_map();
        v226_11_cursor.ascend(1);
        let v226_11_head = Path::from_slice(&[v226_11_byte]);
        let v227_2: Space = singleton(&(v226_11_head));
        let v227_3: Space = intersect(&(*CONSTANT_1),&(v227_2));
        let v227_4: Space = if has_head(&(v227_3)) { singleton(&[]) } else { Space::new() };
        drop(v227_3);
        let v227_5: Space = subtract(&(*CONSTANT_0),&(v227_4));
        drop(v227_4);
        let v227_8: Space = if (v227_5).is_empty() { Space::new() } else {
          let v228_6: Path = concat_path(&(v226_6),&(v226_11_head));
          let v228_7: Space = routine_34(c, &(v228_6), &(v226_11_tail));
          compose(&(v227_5),&(v228_7))
        };
        drop(v227_5);
        let v227_9: Space = intersect(&(*CONSTANT_1),&(v227_2));
        drop(v227_2);
        let v227_10: Space = if has_head(&(v227_9)) { singleton(&[]) } else { Space::new() };
        drop(v227_9);
        let v227_12: Space = if (v227_10).is_empty() { Space::new() } else {
          let v229_6: Path = concat_path(&(v226_6),&(v226_11_head));
          let v229_11: Space = routine_17(c, &(v229_6), &(v226_11_tail));
          drop(v229_6);
          compose(&(v227_10),&(v229_11))
        };
        drop(v227_10);
        let v227_13: Space = unite(&(v227_8),&(v227_12));
        v226_11.join_into((v227_13).clone());
      }
      drop(v226_11_cursor);
      drop(v226_6);
      compose(&(v221_10),&(v226_11))
    };
    drop(v221_10);
    let v221_13: Space = unite(&(v221_8),&(v221_12));
    v220_11.join_into((v221_13).clone());
  }
  drop(v220_11_cursor);
  (v220_11).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v230_8 = Space::new();
  let mut v230_8_cursor = (*s0).read_zipper();
  for v230_8_byte in v230_8_cursor.child_mask().iter() {
    v230_8_cursor.descend_to_byte(v230_8_byte);
    let v230_8_tail = v230_8_cursor.make_map();
    v230_8_cursor.ascend(1);
    let v230_8_head = Path::from_slice(&[v230_8_byte]);
    let v231_2: Space = singleton(&(v230_8_head));
    let v231_3: Space = intersect(&(*CONSTANT_1),&(v231_2));
    let v231_4: Space = if has_head(&(v231_3)) { singleton(&[]) } else { Space::new() };
    drop(v231_3);
    let v231_5: Space = subtract(&(*CONSTANT_0),&(v231_4));
    drop(v231_4);
    let v231_8: Space = if (v231_5).is_empty() { Space::new() } else {
      let v232_6: Path = concat_path(&(*p0),&(v230_8_head));
      let mut v232_7 = Space::new();
      let mut v232_7_cursor = (v230_8_tail).read_zipper();
      for v232_7_byte in v232_7_cursor.child_mask().iter() {
        v232_7_cursor.descend_to_byte(v232_7_byte);
        let v232_7_tail = v232_7_cursor.make_map();
        v232_7_cursor.ascend(1);
        let v232_7_head = Path::from_slice(&[v232_7_byte]);
        let v233_2: Space = singleton(&(v232_7_head));
        let v233_3: Space = intersect(&(*CONSTANT_1),&(v233_2));
        let v233_4: Space = if has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
        drop(v233_3);
        let v233_5: Space = subtract(&(*CONSTANT_0),&(v233_4));
        drop(v233_4);
        let v233_8: Space = if (v233_5).is_empty() { Space::new() } else {
          let v234_6: Path = concat_path(&(v232_6),&(v232_7_head));
          let v234_7: Space = routine_34(c, &(v234_6), &(v232_7_tail));
          compose(&(v233_5),&(v234_7))
        };
        drop(v233_5);
        let v233_9: Space = intersect(&(*CONSTANT_1),&(v233_2));
        drop(v233_2);
        let v233_10: Space = if has_head(&(v233_9)) { singleton(&[]) } else { Space::new() };
        drop(v233_9);
        let v233_12: Space = if (v233_10).is_empty() { Space::new() } else {
          let v235_6: Path = concat_path(&(v232_6),&(v232_7_head));
          let v235_11: Space = routine_35(c, &(v235_6), &(v232_7_tail));
          drop(v235_6);
          compose(&(v233_10),&(v235_11))
        };
        drop(v233_10);
        let v233_13: Space = unite(&(v233_8),&(v233_12));
        v232_7.join_into((v233_13).clone());
      }
      drop(v232_7_cursor);
      drop(v232_6);
      compose(&(v231_5),&(v232_7))
    };
    drop(v231_5);
    let v231_9: Space = intersect(&(*CONSTANT_1),&(v231_2));
    drop(v231_2);
    let v231_10: Space = if has_head(&(v231_9)) { singleton(&[]) } else { Space::new() };
    drop(v231_9);
    let v231_11: Space = compose(&(v231_10),&(v230_8_tail));
    drop(v231_10);
    let v231_12: Space = unite(&(v231_8),&(v231_11));
    drop(v231_11);
    v230_8.join_into((v231_12).clone());
  }
  drop(v230_8_cursor);
  (v230_8).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v236_11 = Space::new();
  let mut v236_11_cursor = (*s0).read_zipper();
  for v236_11_byte in v236_11_cursor.child_mask().iter() {
    v236_11_cursor.descend_to_byte(v236_11_byte);
    let v236_11_tail = v236_11_cursor.make_map();
    v236_11_cursor.ascend(1);
    let v236_11_head = Path::from_slice(&[v236_11_byte]);
    let v237_2: Space = singleton(&(v236_11_head));
    let v237_3: Space = intersect(&(*CONSTANT_1),&(v237_2));
    let v237_4: Space = if has_head(&(v237_3)) { singleton(&[]) } else { Space::new() };
    drop(v237_3);
    let v237_5: Space = subtract(&(*CONSTANT_0),&(v237_4));
    drop(v237_4);
    let v237_8: Space = if (v237_5).is_empty() { Space::new() } else {
      let v238_6: Path = concat_path(&(*p0),&(v236_11_head));
      let mut v238_7 = Space::new();
      let mut v238_7_cursor = (v236_11_tail).read_zipper();
      for v238_7_byte in v238_7_cursor.child_mask().iter() {
        v238_7_cursor.descend_to_byte(v238_7_byte);
        let v238_7_tail = v238_7_cursor.make_map();
        v238_7_cursor.ascend(1);
        let v238_7_head = Path::from_slice(&[v238_7_byte]);
        let v239_2: Space = singleton(&(v238_7_head));
        let v239_3: Space = intersect(&(*CONSTANT_1),&(v239_2));
        let v239_4: Space = if has_head(&(v239_3)) { singleton(&[]) } else { Space::new() };
        drop(v239_3);
        let v239_5: Space = subtract(&(*CONSTANT_0),&(v239_4));
        drop(v239_4);
        let v239_8: Space = if (v239_5).is_empty() { Space::new() } else {
          let v240_6: Path = concat_path(&(v238_6),&(v238_7_head));
          let v240_7: Space = routine_36(c, &(v240_6), &(v238_7_tail));
          compose(&(v239_5),&(v240_7))
        };
        drop(v239_5);
        let v239_9: Space = intersect(&(*CONSTANT_1),&(v239_2));
        drop(v239_2);
        let v239_10: Space = if has_head(&(v239_9)) { singleton(&[]) } else { Space::new() };
        drop(v239_9);
        let v239_12: Space = if (v239_10).is_empty() { Space::new() } else {
          let v241_6: Path = concat_path(&(v238_6),&(v238_7_head));
          let v241_11: Space = routine_37(c, &(v241_6), &(v238_7_tail));
          drop(v241_6);
          compose(&(v239_10),&(v241_11))
        };
        drop(v239_10);
        let v239_13: Space = unite(&(v239_8),&(v239_12));
        v238_7.join_into((v239_13).clone());
      }
      drop(v238_7_cursor);
      compose(&(v237_5),&(v238_7))
    };
    drop(v237_5);
    let v237_9: Space = intersect(&(*CONSTANT_1),&(v237_2));
    drop(v237_2);
    let v237_10: Space = if has_head(&(v237_9)) { singleton(&[]) } else { Space::new() };
    drop(v237_9);
    let v237_12: Space = if (v237_10).is_empty() { Space::new() } else {
      let v242_6: Path = concat_path(&(*p0),&(v236_11_head));
      let mut v242_11 = Space::new();
      let mut v242_11_cursor = (v236_11_tail).read_zipper();
      for v242_11_byte in v242_11_cursor.child_mask().iter() {
        v242_11_cursor.descend_to_byte(v242_11_byte);
        let v242_11_tail = v242_11_cursor.make_map();
        v242_11_cursor.ascend(1);
        let v242_11_head = Path::from_slice(&[v242_11_byte]);
        let v243_2: Space = singleton(&(v242_11_head));
        let v243_3: Space = intersect(&(*CONSTANT_1),&(v243_2));
        let v243_4: Space = if has_head(&(v243_3)) { singleton(&[]) } else { Space::new() };
        drop(v243_3);
        let v243_5: Space = subtract(&(*CONSTANT_0),&(v243_4));
        drop(v243_4);
        let v243_8: Space = if (v243_5).is_empty() { Space::new() } else {
          let v244_6: Path = concat_path(&(v242_6),&(v242_11_head));
          let v244_7: Space = routine_36(c, &(v244_6), &(v242_11_tail));
          compose(&(v243_5),&(v244_7))
        };
        drop(v243_5);
        let v243_9: Space = intersect(&(*CONSTANT_1),&(v243_2));
        drop(v243_2);
        let v243_10: Space = if has_head(&(v243_9)) { singleton(&[]) } else { Space::new() };
        drop(v243_9);
        let v243_12: Space = if (v243_10).is_empty() { Space::new() } else {
          let v245_6: Path = concat_path(&(v242_6),&(v242_11_head));
          let v245_11: Space = routine_14(c, &(v245_6), &(v242_11_tail));
          drop(v245_6);
          compose(&(v243_10),&(v245_11))
        };
        drop(v243_10);
        let v243_13: Space = unite(&(v243_8),&(v243_12));
        v242_11.join_into((v243_13).clone());
      }
      drop(v242_11_cursor);
      drop(v242_6);
      compose(&(v237_10),&(v242_11))
    };
    drop(v237_10);
    let v237_13: Space = unite(&(v237_8),&(v237_12));
    v236_11.join_into((v237_13).clone());
  }
  drop(v236_11_cursor);
  (v236_11).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v246_8 = Space::new();
  let mut v246_8_cursor = (*s0).read_zipper();
  for v246_8_byte in v246_8_cursor.child_mask().iter() {
    v246_8_cursor.descend_to_byte(v246_8_byte);
    let v246_8_tail = v246_8_cursor.make_map();
    v246_8_cursor.ascend(1);
    let v246_8_head = Path::from_slice(&[v246_8_byte]);
    let v247_2: Space = singleton(&(v246_8_head));
    let v247_3: Space = intersect(&(*CONSTANT_1),&(v247_2));
    let v247_4: Space = if has_head(&(v247_3)) { singleton(&[]) } else { Space::new() };
    drop(v247_3);
    let v247_5: Space = subtract(&(*CONSTANT_0),&(v247_4));
    drop(v247_4);
    let v247_8: Space = if (v247_5).is_empty() { Space::new() } else {
      let v248_6: Path = concat_path(&(*p0),&(v246_8_head));
      let mut v248_7 = Space::new();
      let mut v248_7_cursor = (v246_8_tail).read_zipper();
      for v248_7_byte in v248_7_cursor.child_mask().iter() {
        v248_7_cursor.descend_to_byte(v248_7_byte);
        let v248_7_tail = v248_7_cursor.make_map();
        v248_7_cursor.ascend(1);
        let v248_7_head = Path::from_slice(&[v248_7_byte]);
        let v249_2: Space = singleton(&(v248_7_head));
        let v249_3: Space = intersect(&(*CONSTANT_1),&(v249_2));
        let v249_4: Space = if has_head(&(v249_3)) { singleton(&[]) } else { Space::new() };
        drop(v249_3);
        let v249_5: Space = subtract(&(*CONSTANT_0),&(v249_4));
        drop(v249_4);
        let v249_8: Space = if (v249_5).is_empty() { Space::new() } else {
          let v250_6: Path = concat_path(&(v248_6),&(v248_7_head));
          let v250_7: Space = routine_36(c, &(v250_6), &(v248_7_tail));
          compose(&(v249_5),&(v250_7))
        };
        drop(v249_5);
        let v249_9: Space = intersect(&(*CONSTANT_1),&(v249_2));
        drop(v249_2);
        let v249_10: Space = if has_head(&(v249_9)) { singleton(&[]) } else { Space::new() };
        drop(v249_9);
        let v249_12: Space = if (v249_10).is_empty() { Space::new() } else {
          let v251_6: Path = concat_path(&(v248_6),&(v248_7_head));
          let v251_11: Space = routine_37(c, &(v251_6), &(v248_7_tail));
          drop(v251_6);
          compose(&(v249_10),&(v251_11))
        };
        drop(v249_10);
        let v249_13: Space = unite(&(v249_8),&(v249_12));
        v248_7.join_into((v249_13).clone());
      }
      drop(v248_7_cursor);
      drop(v248_6);
      compose(&(v247_5),&(v248_7))
    };
    drop(v247_5);
    let v247_9: Space = intersect(&(*CONSTANT_1),&(v247_2));
    drop(v247_2);
    let v247_10: Space = if has_head(&(v247_9)) { singleton(&[]) } else { Space::new() };
    drop(v247_9);
    let v247_11: Space = compose(&(v247_10),&(v246_8_tail));
    drop(v247_10);
    let v247_12: Space = unite(&(v247_8),&(v247_11));
    drop(v247_11);
    v246_8.join_into((v247_12).clone());
  }
  drop(v246_8_cursor);
  (v246_8).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v252_11 = Space::new();
  let mut v252_11_cursor = (*s0).read_zipper();
  for v252_11_byte in v252_11_cursor.child_mask().iter() {
    v252_11_cursor.descend_to_byte(v252_11_byte);
    let v252_11_tail = v252_11_cursor.make_map();
    v252_11_cursor.ascend(1);
    let v252_11_head = Path::from_slice(&[v252_11_byte]);
    let v253_2: Space = singleton(&(v252_11_head));
    let v253_3: Space = intersect(&(*CONSTANT_1),&(v253_2));
    let v253_4: Space = if has_head(&(v253_3)) { singleton(&[]) } else { Space::new() };
    drop(v253_3);
    let v253_5: Space = subtract(&(*CONSTANT_0),&(v253_4));
    drop(v253_4);
    let v253_8: Space = if (v253_5).is_empty() { Space::new() } else {
      let v254_6: Path = concat_path(&(*p0),&(v252_11_head));
      let mut v254_7 = Space::new();
      let mut v254_7_cursor = (v252_11_tail).read_zipper();
      for v254_7_byte in v254_7_cursor.child_mask().iter() {
        v254_7_cursor.descend_to_byte(v254_7_byte);
        let v254_7_tail = v254_7_cursor.make_map();
        v254_7_cursor.ascend(1);
        let v254_7_head = Path::from_slice(&[v254_7_byte]);
        let v255_2: Space = singleton(&(v254_7_head));
        let v255_3: Space = intersect(&(*CONSTANT_1),&(v255_2));
        let v255_4: Space = if has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
        drop(v255_3);
        let v255_5: Space = subtract(&(*CONSTANT_0),&(v255_4));
        drop(v255_4);
        let v255_8: Space = if (v255_5).is_empty() { Space::new() } else {
          let v256_6: Path = concat_path(&(v254_6),&(v254_7_head));
          let v256_7: Space = routine_38(c, &(v256_6), &(v254_7_tail));
          compose(&(v255_5),&(v256_7))
        };
        drop(v255_5);
        let v255_9: Space = intersect(&(*CONSTANT_1),&(v255_2));
        drop(v255_2);
        let v255_10: Space = if has_head(&(v255_9)) { singleton(&[]) } else { Space::new() };
        drop(v255_9);
        let v255_12: Space = if (v255_10).is_empty() { Space::new() } else {
          let v257_6: Path = concat_path(&(v254_6),&(v254_7_head));
          let v257_11: Space = routine_39(c, &(v257_6), &(v254_7_tail));
          drop(v257_6);
          compose(&(v255_10),&(v257_11))
        };
        drop(v255_10);
        let v255_13: Space = unite(&(v255_8),&(v255_12));
        v254_7.join_into((v255_13).clone());
      }
      drop(v254_7_cursor);
      compose(&(v253_5),&(v254_7))
    };
    drop(v253_5);
    let v253_9: Space = intersect(&(*CONSTANT_1),&(v253_2));
    drop(v253_2);
    let v253_10: Space = if has_head(&(v253_9)) { singleton(&[]) } else { Space::new() };
    drop(v253_9);
    let v253_12: Space = if (v253_10).is_empty() { Space::new() } else {
      let v258_6: Path = concat_path(&(*p0),&(v252_11_head));
      let mut v258_11 = Space::new();
      let mut v258_11_cursor = (v252_11_tail).read_zipper();
      for v258_11_byte in v258_11_cursor.child_mask().iter() {
        v258_11_cursor.descend_to_byte(v258_11_byte);
        let v258_11_tail = v258_11_cursor.make_map();
        v258_11_cursor.ascend(1);
        let v258_11_head = Path::from_slice(&[v258_11_byte]);
        let v259_2: Space = singleton(&(v258_11_head));
        let v259_3: Space = intersect(&(*CONSTANT_1),&(v259_2));
        let v259_4: Space = if has_head(&(v259_3)) { singleton(&[]) } else { Space::new() };
        drop(v259_3);
        let v259_5: Space = subtract(&(*CONSTANT_0),&(v259_4));
        drop(v259_4);
        let v259_8: Space = if (v259_5).is_empty() { Space::new() } else {
          let v260_6: Path = concat_path(&(v258_6),&(v258_11_head));
          let v260_7: Space = routine_38(c, &(v260_6), &(v258_11_tail));
          compose(&(v259_5),&(v260_7))
        };
        drop(v259_5);
        let v259_9: Space = intersect(&(*CONSTANT_1),&(v259_2));
        drop(v259_2);
        let v259_10: Space = if has_head(&(v259_9)) { singleton(&[]) } else { Space::new() };
        drop(v259_9);
        let v259_12: Space = if (v259_10).is_empty() { Space::new() } else {
          let v261_6: Path = concat_path(&(v258_6),&(v258_11_head));
          let v261_11: Space = routine_17(c, &(v261_6), &(v258_11_tail));
          drop(v261_6);
          compose(&(v259_10),&(v261_11))
        };
        drop(v259_10);
        let v259_13: Space = unite(&(v259_8),&(v259_12));
        v258_11.join_into((v259_13).clone());
      }
      drop(v258_11_cursor);
      drop(v258_6);
      compose(&(v253_10),&(v258_11))
    };
    drop(v253_10);
    let v253_13: Space = unite(&(v253_8),&(v253_12));
    v252_11.join_into((v253_13).clone());
  }
  drop(v252_11_cursor);
  (v252_11).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v262_8 = Space::new();
  let mut v262_8_cursor = (*s0).read_zipper();
  for v262_8_byte in v262_8_cursor.child_mask().iter() {
    v262_8_cursor.descend_to_byte(v262_8_byte);
    let v262_8_tail = v262_8_cursor.make_map();
    v262_8_cursor.ascend(1);
    let v262_8_head = Path::from_slice(&[v262_8_byte]);
    let v263_2: Space = singleton(&(v262_8_head));
    let v263_3: Space = intersect(&(*CONSTANT_1),&(v263_2));
    let v263_4: Space = if has_head(&(v263_3)) { singleton(&[]) } else { Space::new() };
    drop(v263_3);
    let v263_5: Space = subtract(&(*CONSTANT_0),&(v263_4));
    drop(v263_4);
    let v263_8: Space = if (v263_5).is_empty() { Space::new() } else {
      let v264_6: Path = concat_path(&(*p0),&(v262_8_head));
      let mut v264_7 = Space::new();
      let mut v264_7_cursor = (v262_8_tail).read_zipper();
      for v264_7_byte in v264_7_cursor.child_mask().iter() {
        v264_7_cursor.descend_to_byte(v264_7_byte);
        let v264_7_tail = v264_7_cursor.make_map();
        v264_7_cursor.ascend(1);
        let v264_7_head = Path::from_slice(&[v264_7_byte]);
        let v265_2: Space = singleton(&(v264_7_head));
        let v265_3: Space = intersect(&(*CONSTANT_1),&(v265_2));
        let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
        drop(v265_3);
        let v265_5: Space = subtract(&(*CONSTANT_0),&(v265_4));
        drop(v265_4);
        let v265_8: Space = if (v265_5).is_empty() { Space::new() } else {
          let v266_6: Path = concat_path(&(v264_6),&(v264_7_head));
          let v266_7: Space = routine_38(c, &(v266_6), &(v264_7_tail));
          compose(&(v265_5),&(v266_7))
        };
        drop(v265_5);
        let v265_9: Space = intersect(&(*CONSTANT_1),&(v265_2));
        drop(v265_2);
        let v265_10: Space = if has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
        drop(v265_9);
        let v265_12: Space = if (v265_10).is_empty() { Space::new() } else {
          let v267_6: Path = concat_path(&(v264_6),&(v264_7_head));
          let v267_11: Space = routine_39(c, &(v267_6), &(v264_7_tail));
          drop(v267_6);
          compose(&(v265_10),&(v267_11))
        };
        drop(v265_10);
        let v265_13: Space = unite(&(v265_8),&(v265_12));
        v264_7.join_into((v265_13).clone());
      }
      drop(v264_7_cursor);
      drop(v264_6);
      compose(&(v263_5),&(v264_7))
    };
    drop(v263_5);
    let v263_9: Space = intersect(&(*CONSTANT_1),&(v263_2));
    drop(v263_2);
    let v263_10: Space = if has_head(&(v263_9)) { singleton(&[]) } else { Space::new() };
    drop(v263_9);
    let v263_11: Space = compose(&(v263_10),&(v262_8_tail));
    drop(v263_10);
    let v263_12: Space = unite(&(v263_8),&(v263_11));
    drop(v263_11);
    v262_8.join_into((v263_12).clone());
  }
  drop(v262_8_cursor);
  (v262_8).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v268_6 = Space::new();
  let mut v268_6_cursor = (*s0).read_zipper();
  for v268_6_byte in v268_6_cursor.child_mask().iter() {
    v268_6_cursor.descend_to_byte(v268_6_byte);
    let v268_6_tail = v268_6_cursor.make_map();
    v268_6_cursor.ascend(1);
    let v268_6_head = Path::from_slice(&[v268_6_byte]);
    let v269_2: Space = singleton(&(v268_6_head));
    let v269_3: Space = intersect(&(*CONSTANT_1),&(v269_2));
    let v269_4: Space = if has_head(&(v269_3)) { singleton(&[]) } else { Space::new() };
    drop(v269_3);
    let v269_5: Space = subtract(&(*CONSTANT_0),&(v269_4));
    drop(v269_4);
    let mut v269_6 = Space::new();
    let mut v269_6_cursor = (v268_6_tail).read_zipper();
    for v269_6_byte in v269_6_cursor.child_mask().iter() {
      v269_6_cursor.descend_to_byte(v269_6_byte);
      let v269_6_tail = v269_6_cursor.make_map();
      v269_6_cursor.ascend(1);
      let v269_6_head = Path::from_slice(&[v269_6_byte]);
      let v270_2: Space = Space::new();
      v269_6.join_into((v270_2).clone());
    }
    drop(v269_6_cursor);
    let v269_7: Space = compose(&(v269_5),&(v269_6));
    drop(v269_5);
    drop(v269_6);
    let v269_8: Space = intersect(&(*CONSTANT_1),&(v269_2));
    drop(v269_2);
    let v269_9: Space = if has_head(&(v269_8)) { singleton(&[]) } else { Space::new() };
    drop(v269_8);
    let v269_12: Space = if (v269_9).is_empty() { Space::new() } else {
      let v271_10: Path = concat_path(&(*p0),&(v268_6_head));
      let mut v271_11 = Space::new();
      let mut v271_11_cursor = (v268_6_tail).read_zipper();
      for v271_11_byte in v271_11_cursor.child_mask().iter() {
        v271_11_cursor.descend_to_byte(v271_11_byte);
        let v271_11_tail = v271_11_cursor.make_map();
        v271_11_cursor.ascend(1);
        let v271_11_head = Path::from_slice(&[v271_11_byte]);
        let v272_2: Space = singleton(&(v271_11_head));
        let v272_3: Space = intersect(&(*CONSTANT_1),&(v272_2));
        drop(v272_2);
        let v272_4: Space = if has_head(&(v272_3)) { singleton(&[]) } else { Space::new() };
        drop(v272_3);
        let v272_7: Space = if (v272_4).is_empty() { Space::new() } else {
          let v273_5: Path = concat_path(&(v271_10),&(v271_11_head));
          let v273_6: Space = routine_14(c, &(v273_5), &(v271_11_tail));
          drop(v273_5);
          compose(&(v272_4),&(v273_6))
        };
        drop(v272_4);
        v271_11.join_into((v272_7).clone());
      }
      drop(v271_11_cursor);
      drop(v271_10);
      compose(&(v269_9),&(v271_11))
    };
    drop(v269_9);
    let v269_13: Space = unite(&(v269_7),&(v269_12));
    drop(v269_7);
    v268_6.join_into((v269_13).clone());
  }
  drop(v268_6_cursor);
  (v268_6).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v274_5 = Space::new();
  let mut v274_5_cursor = (*s0).read_zipper();
  for v274_5_byte in v274_5_cursor.child_mask().iter() {
    v274_5_cursor.descend_to_byte(v274_5_byte);
    let v274_5_tail = v274_5_cursor.make_map();
    v274_5_cursor.ascend(1);
    let v274_5_head = Path::from_slice(&[v274_5_byte]);
    let v275_2: Space = singleton(&(v274_5_head));
    let v275_3: Space = intersect(&(*CONSTANT_1),&(v275_2));
    let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
    drop(v275_3);
    let v275_5: Space = subtract(&(*CONSTANT_0),&(v275_4));
    drop(v275_4);
    let mut v275_6 = Space::new();
    let mut v275_6_cursor = (v274_5_tail).read_zipper();
    for v275_6_byte in v275_6_cursor.child_mask().iter() {
      v275_6_cursor.descend_to_byte(v275_6_byte);
      let v275_6_tail = v275_6_cursor.make_map();
      v275_6_cursor.ascend(1);
      let v275_6_head = Path::from_slice(&[v275_6_byte]);
      let v276_2: Space = Space::new();
      v275_6.join_into((v276_2).clone());
    }
    drop(v275_6_cursor);
    let v275_7: Space = compose(&(v275_5),&(v275_6));
    drop(v275_5);
    drop(v275_6);
    let v275_8: Space = intersect(&(*CONSTANT_1),&(v275_2));
    drop(v275_2);
    let v275_9: Space = if has_head(&(v275_8)) { singleton(&[]) } else { Space::new() };
    drop(v275_8);
    let v275_10: Space = compose(&(v275_9),&(v274_5_tail));
    drop(v275_9);
    let v275_11: Space = unite(&(v275_7),&(v275_10));
    drop(v275_7);
    drop(v275_10);
    v274_5.join_into((v275_11).clone());
  }
  drop(v274_5_cursor);
  (v274_5).clone()
}

fn routine_34(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v277_6 = Space::new();
  let mut v277_6_cursor = (*s0).read_zipper();
  for v277_6_byte in v277_6_cursor.child_mask().iter() {
    v277_6_cursor.descend_to_byte(v277_6_byte);
    let v277_6_tail = v277_6_cursor.make_map();
    v277_6_cursor.ascend(1);
    let v277_6_head = Path::from_slice(&[v277_6_byte]);
    let v278_2: Space = singleton(&(v277_6_head));
    let v278_3: Space = intersect(&(*CONSTANT_1),&(v278_2));
    let v278_4: Space = if has_head(&(v278_3)) { singleton(&[]) } else { Space::new() };
    drop(v278_3);
    let v278_5: Space = subtract(&(*CONSTANT_0),&(v278_4));
    drop(v278_4);
    let mut v278_6 = Space::new();
    let mut v278_6_cursor = (v277_6_tail).read_zipper();
    for v278_6_byte in v278_6_cursor.child_mask().iter() {
      v278_6_cursor.descend_to_byte(v278_6_byte);
      let v278_6_tail = v278_6_cursor.make_map();
      v278_6_cursor.ascend(1);
      let v278_6_head = Path::from_slice(&[v278_6_byte]);
      let v279_2: Space = Space::new();
      v278_6.join_into((v279_2).clone());
    }
    drop(v278_6_cursor);
    let v278_7: Space = compose(&(v278_5),&(v278_6));
    drop(v278_5);
    drop(v278_6);
    let v278_8: Space = intersect(&(*CONSTANT_1),&(v278_2));
    drop(v278_2);
    let v278_9: Space = if has_head(&(v278_8)) { singleton(&[]) } else { Space::new() };
    drop(v278_8);
    let v278_12: Space = if (v278_9).is_empty() { Space::new() } else {
      let v280_10: Path = concat_path(&(*p0),&(v277_6_head));
      let mut v280_11 = Space::new();
      let mut v280_11_cursor = (v277_6_tail).read_zipper();
      for v280_11_byte in v280_11_cursor.child_mask().iter() {
        v280_11_cursor.descend_to_byte(v280_11_byte);
        let v280_11_tail = v280_11_cursor.make_map();
        v280_11_cursor.ascend(1);
        let v280_11_head = Path::from_slice(&[v280_11_byte]);
        let v281_2: Space = singleton(&(v280_11_head));
        let v281_3: Space = intersect(&(*CONSTANT_1),&(v281_2));
        drop(v281_2);
        let v281_4: Space = if has_head(&(v281_3)) { singleton(&[]) } else { Space::new() };
        drop(v281_3);
        let v281_7: Space = if (v281_4).is_empty() { Space::new() } else {
          let v282_5: Path = concat_path(&(v280_10),&(v280_11_head));
          let v282_6: Space = routine_17(c, &(v282_5), &(v280_11_tail));
          drop(v282_5);
          compose(&(v281_4),&(v282_6))
        };
        drop(v281_4);
        v280_11.join_into((v281_7).clone());
      }
      drop(v280_11_cursor);
      drop(v280_10);
      compose(&(v278_9),&(v280_11))
    };
    drop(v278_9);
    let v278_13: Space = unite(&(v278_7),&(v278_12));
    drop(v278_7);
    v277_6.join_into((v278_13).clone());
  }
  drop(v277_6_cursor);
  (v277_6).clone()
}

fn routine_35(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v283_5 = Space::new();
  let mut v283_5_cursor = (*s0).read_zipper();
  for v283_5_byte in v283_5_cursor.child_mask().iter() {
    v283_5_cursor.descend_to_byte(v283_5_byte);
    let v283_5_tail = v283_5_cursor.make_map();
    v283_5_cursor.ascend(1);
    let v283_5_head = Path::from_slice(&[v283_5_byte]);
    let v284_2: Space = singleton(&(v283_5_head));
    let v284_3: Space = intersect(&(*CONSTANT_1),&(v284_2));
    let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = subtract(&(*CONSTANT_0),&(v284_4));
    drop(v284_4);
    let mut v284_6 = Space::new();
    let mut v284_6_cursor = (v283_5_tail).read_zipper();
    for v284_6_byte in v284_6_cursor.child_mask().iter() {
      v284_6_cursor.descend_to_byte(v284_6_byte);
      let v284_6_tail = v284_6_cursor.make_map();
      v284_6_cursor.ascend(1);
      let v284_6_head = Path::from_slice(&[v284_6_byte]);
      let v285_2: Space = Space::new();
      v284_6.join_into((v285_2).clone());
    }
    drop(v284_6_cursor);
    let v284_7: Space = compose(&(v284_5),&(v284_6));
    drop(v284_5);
    drop(v284_6);
    let v284_8: Space = intersect(&(*CONSTANT_1),&(v284_2));
    drop(v284_2);
    let v284_9: Space = if has_head(&(v284_8)) { singleton(&[]) } else { Space::new() };
    drop(v284_8);
    let v284_10: Space = compose(&(v284_9),&(v283_5_tail));
    drop(v284_9);
    let v284_11: Space = unite(&(v284_7),&(v284_10));
    drop(v284_7);
    drop(v284_10);
    v283_5.join_into((v284_11).clone());
  }
  drop(v283_5_cursor);
  (v283_5).clone()
}

fn routine_36(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v286_2 = Space::new();
  let mut v286_2_cursor = (*s0).read_zipper();
  for v286_2_byte in v286_2_cursor.child_mask().iter() {
    v286_2_cursor.descend_to_byte(v286_2_byte);
    let v286_2_tail = v286_2_cursor.make_map();
    v286_2_cursor.ascend(1);
    let v286_2_head = Path::from_slice(&[v286_2_byte]);
    let v287_2: Space = Space::new();
    v286_2.join_into((v287_2).clone());
  }
  drop(v286_2_cursor);
  (v286_2).clone()
}

fn routine_37(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v288_3 = Space::new();
  let mut v288_3_cursor = (*s0).read_zipper();
  for v288_3_byte in v288_3_cursor.child_mask().iter() {
    v288_3_cursor.descend_to_byte(v288_3_byte);
    let v288_3_tail = v288_3_cursor.make_map();
    v288_3_cursor.ascend(1);
    let v288_3_head = Path::from_slice(&[v288_3_byte]);
    let v289_2: Space = singleton(&(v288_3_head));
    let v289_3: Space = intersect(&(*CONSTANT_1),&(v289_2));
    drop(v289_2);
    let v289_4: Space = if has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
    drop(v289_3);
    let v289_5: Space = compose(&(v289_4),&(v288_3_tail));
    drop(v289_4);
    v288_3.join_into((v289_5).clone());
  }
  drop(v288_3_cursor);
  (v288_3).clone()
}

fn routine_38(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v290_2 = Space::new();
  let mut v290_2_cursor = (*s0).read_zipper();
  for v290_2_byte in v290_2_cursor.child_mask().iter() {
    v290_2_cursor.descend_to_byte(v290_2_byte);
    let v290_2_tail = v290_2_cursor.make_map();
    v290_2_cursor.ascend(1);
    let v290_2_head = Path::from_slice(&[v290_2_byte]);
    let v291_2: Space = Space::new();
    v290_2.join_into((v291_2).clone());
  }
  drop(v290_2_cursor);
  (v290_2).clone()
}

fn routine_39(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v292_3 = Space::new();
  let mut v292_3_cursor = (*s0).read_zipper();
  for v292_3_byte in v292_3_cursor.child_mask().iter() {
    v292_3_cursor.descend_to_byte(v292_3_byte);
    let v292_3_tail = v292_3_cursor.make_map();
    v292_3_cursor.ascend(1);
    let v292_3_head = Path::from_slice(&[v292_3_byte]);
    let v293_2: Space = singleton(&(v292_3_head));
    let v293_3: Space = intersect(&(*CONSTANT_1),&(v293_2));
    drop(v293_2);
    let v293_4: Space = if has_head(&(v293_3)) { singleton(&[]) } else { Space::new() };
    drop(v293_3);
    let v293_5: Space = compose(&(v293_4),&(v292_3_tail));
    drop(v293_4);
    v292_3.join_into((v293_5).clone());
  }
  drop(v292_3_cursor);
  (v292_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
