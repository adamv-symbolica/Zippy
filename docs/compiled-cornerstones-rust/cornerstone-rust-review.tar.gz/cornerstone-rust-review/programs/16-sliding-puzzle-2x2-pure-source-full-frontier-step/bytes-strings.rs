#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66,76]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 7 0 49 0 51 0 50 0 7 0 50 0 49 0 51 0 7 0 51 0 50 0 49 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66,82]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84,76]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 7 0 49 0 50 0 51 0 7 0 50 0 51 0 49 0 7 0 51 0 49 0 50 0"));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84,82]));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 66 76 0"));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 66 82 0"));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 84 76 0"));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 84 82 0"));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66]));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 10 76 0 82 0 66 76 0 66 82 0 10 76 0 82 0 66 82 0 66 76 0 10 76 0 85 0 66 76 0 84 76 0 10 76 0 85 0 84 76 0 66 76 0 10 82 0 76 0 66 76 0 66 82 0 10 82 0 76 0 66 82 0 66 76 0 10 82 0 85 0 66 82 0 84 82 0 10 82 0 85 0 84 82 0 66 82 0"));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84]));
static CONSTANT_15: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 10 76 0 68 0 66 76 0 84 76 0 10 76 0 68 0 84 76 0 66 76 0 10 76 0 82 0 84 76 0 84 82 0 10 76 0 82 0 84 82 0 84 76 0 10 82 0 68 0 66 82 0 84 82 0 10 82 0 68 0 84 82 0 66 82 0 10 82 0 76 0 84 76 0 84 82 0 10 82 0 76 0 84 82 0 84 76 0"));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 9 0 82 0 66 76 0 66 82 0 9 0 82 0 66 82 0 66 76 0 9 0 85 0 66 76 0 84 76 0 9 0 85 0 84 76 0 66 76 0"));
static CONSTANT_17: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 9 0 76 0 66 76 0 66 82 0 9 0 76 0 66 82 0 66 76 0 9 0 85 0 66 82 0 84 82 0 9 0 85 0 84 82 0 66 82 0"));
static CONSTANT_18: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 9 0 68 0 66 76 0 84 76 0 9 0 68 0 84 76 0 66 76 0 9 0 82 0 84 76 0 84 82 0 9 0 82 0 84 82 0 84 76 0"));
static CONSTANT_19: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 9 0 68 0 66 82 0 84 82 0 9 0 68 0 84 82 0 66 82 0 9 0 76 0 84 76 0 84 82 0 9 0 76 0 84 82 0 84 76 0"));
static CONSTANT_20: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84,76,0]));
static CONSTANT_21: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84,82,0]));
static CONSTANT_22: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66,82,0]));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66,76,0]));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 66 76 0 95 0"));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 66 82 0 95 0"));
static CONSTANT_26: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 84 76 0 95 0"));
static CONSTANT_27: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 84 82 0 95 0"));
static CONSTANT_28: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 6 66 76 0 66 76 0 6 66 82 0 66 82 0 6 84 76 0 84 76 0 6 84 82 0 84 82 0"));
fn routine_0(c: &mut Context) -> Space {
  let v0_18: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v1_17: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v2_4: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
      let v2_7: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_2));
      let v2_8: Space = unite(&(v2_4),&(v2_7));
      let v2_11: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_5));
      let v2_12: Space = unite(&(v2_8),&(v2_11));
      let v2_15: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_5));
      let v2_16: Space = unite(&(v2_12),&(v2_15));
      compose(&(*CONSTANT_0),&(v2_16))
    };
    compose(&(*CONSTANT_0),&(v1_17))
  };
  (v0_18).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v3_8 = Space::new();
  let mut v3_8_cursor = (*s0).read_zipper();
  for v3_8_byte in v3_8_cursor.child_mask().iter() {
    v3_8_cursor.descend_to_byte(v3_8_byte);
    let v3_8_tail = v3_8_cursor.make_map();
    v3_8_cursor.ascend(1);
    let v3_8_head = Path::from_slice(&[v3_8_byte]);
    let v4_2: Space = singleton(&(v3_8_head));
    let v4_3: Space = intersect(&(*CONSTANT_7),&(v4_2));
    let v4_4: Space = if has_head(&(v4_3)) { singleton(&[]) } else { Space::new() };
    drop(v4_3);
    let v4_5: Space = subtract(&(*CONSTANT_0),&(v4_4));
    drop(v4_4);
    let v4_8: Space = if (v4_5).is_empty() { Space::new() } else {
      let v5_6: Path = concat_path(&(*p0),&(v3_8_head));
      let v5_7: Space = routine_1(c, &(v5_6), &(v3_8_tail));
      compose(&(v4_5),&(v5_7))
    };
    drop(v4_5);
    let v4_9: Space = intersect(&(*CONSTANT_7),&(v4_2));
    drop(v4_2);
    let v4_10: Space = if has_head(&(v4_9)) { singleton(&[]) } else { Space::new() };
    drop(v4_9);
    let v4_12: Space = if (v4_10).is_empty() { Space::new() } else {
      let v6_6: Path = concat_path(&(*p0),&(v3_8_head));
      let mut v6_11 = Space::new();
      let mut v6_11_cursor = (v3_8_tail).read_zipper();
      for v6_11_byte in v6_11_cursor.child_mask().iter() {
        v6_11_cursor.descend_to_byte(v6_11_byte);
        let v6_11_tail = v6_11_cursor.make_map();
        v6_11_cursor.ascend(1);
        let v6_11_head = Path::from_slice(&[v6_11_byte]);
        let v7_2: Space = singleton(&(v6_11_head));
        let v7_3: Space = intersect(&(*CONSTANT_7),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_7: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Space = routine_2(c, &(v6_11_head), &(v6_6), &(v6_11_tail));
          compose(&(v7_5),&(v8_6))
        };
        drop(v7_5);
        let v7_8: Space = intersect(&(*CONSTANT_7),&(v7_2));
        drop(v7_2);
        let v7_9: Space = if has_head(&(v7_8)) { singleton(&[]) } else { Space::new() };
        drop(v7_8);
        let v7_11: Space = if (v7_9).is_empty() { Space::new() } else {
          let v9_10: Space = routine_3(c, &(v6_11_head), &(v6_6), &(v6_11_tail));
          compose(&(v7_9),&(v9_10))
        };
        drop(v7_9);
        let v7_12: Space = unite(&(v7_7),&(v7_11));
        v6_11.join_into((v7_12).clone());
      }
      drop(v6_11_cursor);
      drop(v6_6);
      compose(&(v4_10),&(v6_11))
    };
    drop(v4_10);
    let v4_13: Space = unite(&(v4_8),&(v4_12));
    v3_8.join_into((v4_13).clone());
  }
  drop(v3_8_cursor);
  (v3_8).clone()
}

fn routine_2(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v10_9 = Space::new();
  let mut v10_9_cursor = (*s0).read_zipper();
  for v10_9_byte in v10_9_cursor.child_mask().iter() {
    v10_9_cursor.descend_to_byte(v10_9_byte);
    let v10_9_tail = v10_9_cursor.make_map();
    v10_9_cursor.ascend(1);
    let v10_9_head = Path::from_slice(&[v10_9_byte]);
    let v11_2: Space = singleton(&(v10_9_head));
    let v11_3: Space = intersect(&(*CONSTANT_7),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&(v10_9_head));
      let v12_7: Space = routine_2(c, &(v12_6), &(*p1), &(v10_9_tail));
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_7),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_12: Space = if (v11_10).is_empty() { Space::new() } else {
      let v13_6: Path = concat_path(&(*p0),&(v10_9_head));
      let mut v13_11 = Space::new();
      let mut v13_11_cursor = (v10_9_tail).read_zipper();
      for v13_11_byte in v13_11_cursor.child_mask().iter() {
        v13_11_cursor.descend_to_byte(v13_11_byte);
        let v13_11_tail = v13_11_cursor.make_map();
        v13_11_cursor.ascend(1);
        let v13_11_head = Path::from_slice(&[v13_11_byte]);
        let v14_2: Space = singleton(&(v13_11_head));
        let v14_3: Space = intersect(&(*CONSTANT_7),&(v14_2));
        let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
        drop(v14_3);
        let v14_5: Space = subtract(&(*CONSTANT_0),&(v14_4));
        drop(v14_4);
        let v14_7: Space = if (v14_5).is_empty() { Space::new() } else {
          let v15_6: Space = routine_4(c, &(v13_11_head), &(*p1), &(v13_6), &(v13_11_tail));
          compose(&(v14_5),&(v15_6))
        };
        drop(v14_5);
        let v14_8: Space = intersect(&(*CONSTANT_7),&(v14_2));
        drop(v14_2);
        let v14_9: Space = if has_head(&(v14_8)) { singleton(&[]) } else { Space::new() };
        drop(v14_8);
        let v14_11: Space = if (v14_9).is_empty() { Space::new() } else {
          let v16_10: Space = routine_5(c, &(v13_11_head), &(*p1), &(v13_6), &(v13_11_tail));
          compose(&(v14_9),&(v16_10))
        };
        drop(v14_9);
        let v14_12: Space = unite(&(v14_7),&(v14_11));
        v13_11.join_into((v14_12).clone());
      }
      drop(v13_11_cursor);
      drop(v13_6);
      compose(&(v11_10),&(v13_11))
    };
    drop(v11_10);
    let v11_13: Space = unite(&(v11_8),&(v11_12));
    v10_9.join_into((v11_13).clone());
  }
  drop(v10_9_cursor);
  (v10_9).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v17_12 = Space::new();
  let mut v17_12_cursor = (*s0).read_zipper();
  for v17_12_byte in v17_12_cursor.child_mask().iter() {
    v17_12_cursor.descend_to_byte(v17_12_byte);
    let v17_12_tail = v17_12_cursor.make_map();
    v17_12_cursor.ascend(1);
    let v17_12_head = Path::from_slice(&[v17_12_byte]);
    let v18_2: Space = singleton(&(v17_12_head));
    let v18_3: Space = intersect(&(*CONSTANT_7),&(v18_2));
    let v18_4: Space = if has_head(&(v18_3)) { singleton(&[]) } else { Space::new() };
    drop(v18_3);
    let v18_5: Space = subtract(&(*CONSTANT_0),&(v18_4));
    drop(v18_4);
    let v18_7: Space = if (v18_5).is_empty() { Space::new() } else {
      let mut v19_6 = Space::new();
      let mut v19_6_cursor = (v17_12_tail).read_zipper();
      for v19_6_byte in v19_6_cursor.child_mask().iter() {
        v19_6_cursor.descend_to_byte(v19_6_byte);
        let v19_6_tail = v19_6_cursor.make_map();
        v19_6_cursor.ascend(1);
        let v19_6_head = Path::from_slice(&[v19_6_byte]);
        let v20_2: Space = singleton(&(v19_6_head));
        let v20_3: Space = intersect(&(*CONSTANT_7),&(v20_2));
        let v20_4: Space = if has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
        drop(v20_3);
        let v20_5: Space = subtract(&(*CONSTANT_0),&(v20_4));
        drop(v20_4);
        let v20_8: Space = if (v20_5).is_empty() { Space::new() } else {
          let v21_6: Path = concat_path(&(v17_12_head),&(v19_6_head));
          let v21_7: Space = routine_4(c, &(v21_6), &(*p1), &(*p0), &(v19_6_tail));
          compose(&(v20_5),&(v21_7))
        };
        drop(v20_5);
        let v20_9: Space = intersect(&(*CONSTANT_7),&(v20_2));
        drop(v20_2);
        let v20_10: Space = if has_head(&(v20_9)) { singleton(&[]) } else { Space::new() };
        drop(v20_9);
        let v20_12: Space = if (v20_10).is_empty() { Space::new() } else {
          let v22_6: Path = concat_path(&(v17_12_head),&(v19_6_head));
          let v22_11: Space = routine_5(c, &(v22_6), &(*p1), &(*p0), &(v19_6_tail));
          drop(v22_6);
          compose(&(v20_10),&(v22_11))
        };
        drop(v20_10);
        let v20_13: Space = unite(&(v20_8),&(v20_12));
        v19_6.join_into((v20_13).clone());
      }
      drop(v19_6_cursor);
      compose(&(v18_5),&(v19_6))
    };
    drop(v18_5);
    let v18_8: Space = intersect(&(*CONSTANT_7),&(v18_2));
    drop(v18_2);
    let v18_9: Space = if has_head(&(v18_8)) { singleton(&[]) } else { Space::new() };
    drop(v18_8);
    let v18_11: Space = if (v18_9).is_empty() { Space::new() } else {
      let mut v23_10 = Space::new();
      let mut v23_10_cursor = (v17_12_tail).read_zipper();
      for v23_10_byte in v23_10_cursor.child_mask().iter() {
        v23_10_cursor.descend_to_byte(v23_10_byte);
        let v23_10_tail = v23_10_cursor.make_map();
        v23_10_cursor.ascend(1);
        let v23_10_head = Path::from_slice(&[v23_10_byte]);
        let v24_2: Space = singleton(&(v23_10_head));
        let v24_3: Space = intersect(&(*CONSTANT_7),&(v24_2));
        let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
        drop(v24_3);
        let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
        drop(v24_4);
        let v24_7: Space = if (v24_5).is_empty() { Space::new() } else {
          let v25_6: Space = routine_6(c, &(v23_10_head), &(*p1), &(*p0), &(v17_12_head), &(v23_10_tail));
          compose(&(v24_5),&(v25_6))
        };
        drop(v24_5);
        let v24_8: Space = intersect(&(*CONSTANT_7),&(v24_2));
        drop(v24_2);
        let v24_9: Space = if has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
        drop(v24_8);
        let v24_11: Space = if (v24_9).is_empty() { Space::new() } else {
          let v26_10: Space = routine_7(c, &(v23_10_head), &(*p1), &(*p0), &(v17_12_head), &(v23_10_tail));
          compose(&(v24_9),&(v26_10))
        };
        drop(v24_9);
        let v24_12: Space = unite(&(v24_7),&(v24_11));
        v23_10.join_into((v24_12).clone());
      }
      drop(v23_10_cursor);
      compose(&(v18_9),&(v23_10))
    };
    drop(v18_9);
    let v18_12: Space = unite(&(v18_7),&(v18_11));
    v17_12.join_into((v18_12).clone());
  }
  drop(v17_12_cursor);
  (v17_12).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v27_10 = Space::new();
  let mut v27_10_cursor = (*s0).read_zipper();
  for v27_10_byte in v27_10_cursor.child_mask().iter() {
    v27_10_cursor.descend_to_byte(v27_10_byte);
    let v27_10_tail = v27_10_cursor.make_map();
    v27_10_cursor.ascend(1);
    let v27_10_head = Path::from_slice(&[v27_10_byte]);
    let v28_2: Space = singleton(&(v27_10_head));
    let v28_3: Space = intersect(&(*CONSTANT_7),&(v28_2));
    let v28_4: Space = if has_head(&(v28_3)) { singleton(&[]) } else { Space::new() };
    drop(v28_3);
    let v28_5: Space = subtract(&(*CONSTANT_0),&(v28_4));
    drop(v28_4);
    let v28_8: Space = if (v28_5).is_empty() { Space::new() } else {
      let v29_6: Path = concat_path(&(*p0),&(v27_10_head));
      let v29_7: Space = routine_4(c, &(v29_6), &(*p1), &(*p2), &(v27_10_tail));
      compose(&(v28_5),&(v29_7))
    };
    drop(v28_5);
    let v28_9: Space = intersect(&(*CONSTANT_7),&(v28_2));
    drop(v28_2);
    let v28_10: Space = if has_head(&(v28_9)) { singleton(&[]) } else { Space::new() };
    drop(v28_9);
    let v28_12: Space = if (v28_10).is_empty() { Space::new() } else {
      let v30_6: Path = concat_path(&(*p0),&(v27_10_head));
      let mut v30_11 = Space::new();
      let mut v30_11_cursor = (v27_10_tail).read_zipper();
      for v30_11_byte in v30_11_cursor.child_mask().iter() {
        v30_11_cursor.descend_to_byte(v30_11_byte);
        let v30_11_tail = v30_11_cursor.make_map();
        v30_11_cursor.ascend(1);
        let v30_11_head = Path::from_slice(&[v30_11_byte]);
        let v31_2: Space = singleton(&(v30_11_head));
        let v31_3: Space = intersect(&(*CONSTANT_7),&(v31_2));
        let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
        drop(v31_3);
        let v31_5: Space = subtract(&(*CONSTANT_0),&(v31_4));
        drop(v31_4);
        let v31_7: Space = if (v31_5).is_empty() { Space::new() } else {
          let v32_6: Space = routine_6(c, &(v30_11_head), &(*p1), &(*p2), &(v30_6), &(v30_11_tail));
          compose(&(v31_5),&(v32_6))
        };
        drop(v31_5);
        let v31_8: Space = intersect(&(*CONSTANT_7),&(v31_2));
        drop(v31_2);
        let v31_9: Space = if has_head(&(v31_8)) { singleton(&[]) } else { Space::new() };
        drop(v31_8);
        let v31_11: Space = if (v31_9).is_empty() { Space::new() } else {
          let v33_10: Space = routine_7(c, &(v30_11_head), &(*p1), &(*p2), &(v30_6), &(v30_11_tail));
          compose(&(v31_9),&(v33_10))
        };
        drop(v31_9);
        let v31_12: Space = unite(&(v31_7),&(v31_11));
        v30_11.join_into((v31_12).clone());
      }
      drop(v30_11_cursor);
      drop(v30_6);
      compose(&(v28_10),&(v30_11))
    };
    drop(v28_10);
    let v28_13: Space = unite(&(v28_8),&(v28_12));
    v27_10.join_into((v28_13).clone());
  }
  drop(v27_10_cursor);
  (v27_10).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v34_7: Path = concat_path(&(*p2),&(*p0));
  let mut v34_17 = Space::new();
  let mut v34_17_cursor = (*s0).read_zipper();
  for v34_17_byte in v34_17_cursor.child_mask().iter() {
    v34_17_cursor.descend_to_byte(v34_17_byte);
    let v34_17_tail = v34_17_cursor.make_map();
    v34_17_cursor.ascend(1);
    let v34_17_head = Path::from_slice(&[v34_17_byte]);
    let v35_2: Space = singleton(&(v34_17_head));
    let v35_3: Space = intersect(&(*CONSTANT_7),&(v35_2));
    let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
    drop(v35_3);
    let v35_5: Space = subtract(&(*CONSTANT_0),&(v35_4));
    drop(v35_4);
    let v35_7: Space = if (v35_5).is_empty() { Space::new() } else {
      let mut v36_6 = Space::new();
      let mut v36_6_cursor = (v34_17_tail).read_zipper();
      for v36_6_byte in v36_6_cursor.child_mask().iter() {
        v36_6_cursor.descend_to_byte(v36_6_byte);
        let v36_6_tail = v36_6_cursor.make_map();
        v36_6_cursor.ascend(1);
        let v36_6_head = Path::from_slice(&[v36_6_byte]);
        let v37_2: Space = singleton(&(v36_6_head));
        let v37_3: Space = intersect(&(*CONSTANT_7),&(v37_2));
        let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
        drop(v37_3);
        let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
        drop(v37_4);
        let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
          let v38_6: Path = concat_path(&(v34_17_head),&(v36_6_head));
          let v38_7: Space = routine_6(c, &(v38_6), &(*p1), &(*p2), &(*p0), &(v36_6_tail));
          compose(&(v37_5),&(v38_7))
        };
        drop(v37_5);
        let v37_9: Space = intersect(&(*CONSTANT_7),&(v37_2));
        drop(v37_2);
        let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
        drop(v37_9);
        let v37_12: Space = if (v37_10).is_empty() { Space::new() } else {
          let v39_6: Path = concat_path(&(v34_17_head),&(v36_6_head));
          let v39_11: Space = routine_7(c, &(v39_6), &(*p1), &(*p2), &(*p0), &(v36_6_tail));
          drop(v39_6);
          compose(&(v37_10),&(v39_11))
        };
        drop(v37_10);
        let v37_13: Space = unite(&(v37_8),&(v37_12));
        v36_6.join_into((v37_13).clone());
      }
      drop(v36_6_cursor);
      compose(&(v35_5),&(v36_6))
    };
    drop(v35_5);
    let v35_8: Space = intersect(&(*CONSTANT_7),&(v35_2));
    drop(v35_2);
    let v35_9: Space = if has_head(&(v35_8)) { singleton(&[]) } else { Space::new() };
    drop(v35_8);
    let v35_15: Space = if (v35_9).is_empty() { Space::new() } else {
      let v40_10: Path = concat_path(&(v34_7),&(v34_17_head));
      let v40_11: Space = singleton(&(v40_10));
      drop(v40_10);
      let v40_12: Space = routine_8(c, &(*p1), &(v40_11));
      drop(v40_11);
      let mut v40_13 = Space::new();
      let mut v40_13_cursor = (v40_12).read_zipper();
      for v40_13_byte in v40_13_cursor.child_mask().iter() {
        v40_13_cursor.descend_to_byte(v40_13_byte);
        let v40_13_tail = v40_13_cursor.make_map();
        v40_13_cursor.ascend(1);
        let v40_13_head = Path::from_slice(&[v40_13_byte]);
        let v41_2: Space = singleton(&(v40_13_head));
        let v41_3: Space = intersect(&(*CONSTANT_7),&(v41_2));
        let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
        drop(v41_3);
        let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
        drop(v41_4);
        let v41_7: Space = if (v41_5).is_empty() { Space::new() } else {
          let v42_6: Space = routine_9(c, &(v40_13_head), &(*p1), &(v40_13_tail));
          compose(&(v41_5),&(v42_6))
        };
        drop(v41_5);
        let v41_8: Space = intersect(&(*CONSTANT_7),&(v41_2));
        drop(v41_2);
        let v41_9: Space = if has_head(&(v41_8)) { singleton(&[]) } else { Space::new() };
        drop(v41_8);
        let v41_11: Space = if (v41_9).is_empty() { Space::new() } else {
          let v43_10: Space = routine_10(c, &(v40_13_head), &(*p1), &(v40_13_tail));
          compose(&(v41_9),&(v43_10))
        };
        drop(v41_9);
        let v41_12: Space = unite(&(v41_7),&(v41_11));
        v40_13.join_into((v41_12).clone());
      }
      drop(v40_13_cursor);
      let mut v40_14 = Space::new();
      let mut v40_14_cursor = (v40_13).read_zipper();
      for v40_14_byte in v40_14_cursor.child_mask().iter() {
        v40_14_cursor.descend_to_byte(v40_14_byte);
        let v40_14_tail = v40_14_cursor.make_map();
        v40_14_cursor.ascend(1);
        let v40_14_head = Path::from_slice(&[v40_14_byte]);
        let v44_2: Space = singleton(&(v40_14_head));
        let v44_3: Space = intersect(&(*CONSTANT_7),&(v44_2));
        let v44_4: Space = if has_head(&(v44_3)) { singleton(&[]) } else { Space::new() };
        drop(v44_3);
        let v44_5: Space = subtract(&(*CONSTANT_0),&(v44_4));
        drop(v44_4);
        let v44_7: Space = if (v44_5).is_empty() { Space::new() } else {
          let v45_6: Space = routine_11(c, &(v40_14_head), &(*p1), &(v40_14_tail));
          compose(&(v44_5),&(v45_6))
        };
        drop(v44_5);
        let v44_8: Space = intersect(&(*CONSTANT_7),&(v44_2));
        drop(v44_2);
        let v44_9: Space = if has_head(&(v44_8)) { singleton(&[]) } else { Space::new() };
        drop(v44_8);
        let v44_11: Space = if (v44_9).is_empty() { Space::new() } else {
          let v46_10: Space = routine_12(c, &(v40_14_head), &(*p1), &(v40_14_tail));
          compose(&(v44_9),&(v46_10))
        };
        drop(v44_9);
        let v44_12: Space = unite(&(v44_7),&(v44_11));
        v40_14.join_into((v44_12).clone());
      }
      drop(v40_14_cursor);
      compose(&(v35_9),&(v40_14))
    };
    drop(v35_9);
    let v35_16: Space = unite(&(v35_7),&(v35_15));
    v34_17.join_into((v35_16).clone());
  }
  drop(v34_17_cursor);
  drop(v34_7);
  (v34_17).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let v47_8: Path = concat_path(&(*p2),&(*p3));
  let mut v47_15 = Space::new();
  let mut v47_15_cursor = (*s0).read_zipper();
  for v47_15_byte in v47_15_cursor.child_mask().iter() {
    v47_15_cursor.descend_to_byte(v47_15_byte);
    let v47_15_tail = v47_15_cursor.make_map();
    v47_15_cursor.ascend(1);
    let v47_15_head = Path::from_slice(&[v47_15_byte]);
    let v48_2: Space = singleton(&(v47_15_head));
    let v48_3: Space = intersect(&(*CONSTANT_7),&(v48_2));
    let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
    drop(v48_3);
    let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
    drop(v48_4);
    let v48_8: Space = if (v48_5).is_empty() { Space::new() } else {
      let v49_6: Path = concat_path(&(*p0),&(v47_15_head));
      let v49_7: Space = routine_6(c, &(v49_6), &(*p1), &(*p2), &(*p3), &(v47_15_tail));
      compose(&(v48_5),&(v49_7))
    };
    drop(v48_5);
    let v48_9: Space = intersect(&(*CONSTANT_7),&(v48_2));
    drop(v48_2);
    let v48_10: Space = if has_head(&(v48_9)) { singleton(&[]) } else { Space::new() };
    drop(v48_9);
    let v48_16: Space = if (v48_10).is_empty() { Space::new() } else {
      let v50_6: Path = concat_path(&(*p0),&(v47_15_head));
      let v50_11: Path = concat_path(&(v47_8),&(v50_6));
      drop(v50_6);
      let v50_12: Space = singleton(&(v50_11));
      drop(v50_11);
      let v50_13: Space = routine_8(c, &(*p1), &(v50_12));
      drop(v50_12);
      let mut v50_14 = Space::new();
      let mut v50_14_cursor = (v50_13).read_zipper();
      for v50_14_byte in v50_14_cursor.child_mask().iter() {
        v50_14_cursor.descend_to_byte(v50_14_byte);
        let v50_14_tail = v50_14_cursor.make_map();
        v50_14_cursor.ascend(1);
        let v50_14_head = Path::from_slice(&[v50_14_byte]);
        let v51_2: Space = singleton(&(v50_14_head));
        let v51_3: Space = intersect(&(*CONSTANT_7),&(v51_2));
        let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
        drop(v51_3);
        let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
        drop(v51_4);
        let v51_7: Space = if (v51_5).is_empty() { Space::new() } else {
          let v52_6: Space = routine_9(c, &(v50_14_head), &(*p1), &(v50_14_tail));
          compose(&(v51_5),&(v52_6))
        };
        drop(v51_5);
        let v51_8: Space = intersect(&(*CONSTANT_7),&(v51_2));
        drop(v51_2);
        let v51_9: Space = if has_head(&(v51_8)) { singleton(&[]) } else { Space::new() };
        drop(v51_8);
        let v51_11: Space = if (v51_9).is_empty() { Space::new() } else {
          let v53_10: Space = routine_10(c, &(v50_14_head), &(*p1), &(v50_14_tail));
          compose(&(v51_9),&(v53_10))
        };
        drop(v51_9);
        let v51_12: Space = unite(&(v51_7),&(v51_11));
        v50_14.join_into((v51_12).clone());
      }
      drop(v50_14_cursor);
      let mut v50_15 = Space::new();
      let mut v50_15_cursor = (v50_14).read_zipper();
      for v50_15_byte in v50_15_cursor.child_mask().iter() {
        v50_15_cursor.descend_to_byte(v50_15_byte);
        let v50_15_tail = v50_15_cursor.make_map();
        v50_15_cursor.ascend(1);
        let v50_15_head = Path::from_slice(&[v50_15_byte]);
        let v54_2: Space = singleton(&(v50_15_head));
        let v54_3: Space = intersect(&(*CONSTANT_7),&(v54_2));
        let v54_4: Space = if has_head(&(v54_3)) { singleton(&[]) } else { Space::new() };
        drop(v54_3);
        let v54_5: Space = subtract(&(*CONSTANT_0),&(v54_4));
        drop(v54_4);
        let v54_7: Space = if (v54_5).is_empty() { Space::new() } else {
          let v55_6: Space = routine_11(c, &(v50_15_head), &(*p1), &(v50_15_tail));
          compose(&(v54_5),&(v55_6))
        };
        drop(v54_5);
        let v54_8: Space = intersect(&(*CONSTANT_7),&(v54_2));
        drop(v54_2);
        let v54_9: Space = if has_head(&(v54_8)) { singleton(&[]) } else { Space::new() };
        drop(v54_8);
        let v54_11: Space = if (v54_9).is_empty() { Space::new() } else {
          let v56_10: Space = routine_12(c, &(v50_15_head), &(*p1), &(v50_15_tail));
          compose(&(v54_9),&(v56_10))
        };
        drop(v54_9);
        let v54_12: Space = unite(&(v54_7),&(v54_11));
        v50_15.join_into((v54_12).clone());
      }
      drop(v50_15_cursor);
      compose(&(v48_10),&(v50_15))
    };
    drop(v48_10);
    let v48_17: Space = unite(&(v48_8),&(v48_16));
    v47_15.join_into((v48_17).clone());
  }
  drop(v47_15_cursor);
  drop(v47_8);
  (v47_15).clone()
}

fn routine_7(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let v57_6: Space = singleton(&(*p1));
  let v57_7: Space = intersect(&(*CONSTANT_8),&(v57_6));
  let mut v57_11 = Space::new();
  let mut v57_11_cursor = (v57_7).read_zipper();
  for v57_11_byte in v57_11_cursor.child_mask().iter() {
    v57_11_cursor.descend_to_byte(v57_11_byte);
    let v57_11_tail = v57_11_cursor.make_map();
    v57_11_cursor.ascend(1);
    let v57_11_head = Path::from_slice(&[v57_11_byte]);
    let v58_2: Space = singleton(&(v57_11_head));
    let v58_3: Space = intersect(&(*CONSTANT_7),&(v58_2));
    let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
    drop(v58_3);
    let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
    drop(v58_4);
    let v58_7: Space = if (v58_5).is_empty() { Space::new() } else {
      let v59_6: Space = routine_13(c, &(v57_11_head), &(v57_11_tail));
      compose(&(v58_5),&(v59_6))
    };
    drop(v58_5);
    let v58_8: Space = intersect(&(*CONSTANT_7),&(v58_2));
    drop(v58_2);
    let v58_9: Space = if has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
    drop(v58_8);
    let v58_11: Space = if (v58_9).is_empty() { Space::new() } else {
      let v60_10: Space = routine_14(c, &(v57_11_head), &(v57_11_tail));
      compose(&(v58_9),&(v60_10))
    };
    drop(v58_9);
    let v58_12: Space = unite(&(v58_7),&(v58_11));
    v57_11.join_into((v58_12).clone());
  }
  drop(v57_11_cursor);
  drop(v57_7);
  let v57_19: Space = if (v57_11).is_empty() { Space::new() } else {
    let v61_12: Path = concat_path(&(*p2),&(*p3));
    let v61_13: Path = concat_path(&(v61_12),&(*p0));
    drop(v61_12);
    let v61_14: Space = singleton(&(v61_13));
    drop(v61_13);
    let mut v61_18 = Space::new();
    let mut v61_18_cursor = (v61_14).read_zipper();
    for v61_18_byte in v61_18_cursor.child_mask().iter() {
      v61_18_cursor.descend_to_byte(v61_18_byte);
      let v61_18_tail = v61_18_cursor.make_map();
      v61_18_cursor.ascend(1);
      let v61_18_head = Path::from_slice(&[v61_18_byte]);
      let v62_2: Space = singleton(&(v61_18_head));
      let v62_3: Space = intersect(&(*CONSTANT_7),&(v62_2));
      let v62_4: Space = if has_head(&(v62_3)) { singleton(&[]) } else { Space::new() };
      drop(v62_3);
      let v62_5: Space = subtract(&(*CONSTANT_0),&(v62_4));
      drop(v62_4);
      let v62_7: Space = if (v62_5).is_empty() { Space::new() } else {
        let v63_6: Space = routine_15(c, &(v61_18_head), &(v61_18_tail));
        compose(&(v62_5),&(v63_6))
      };
      drop(v62_5);
      let v62_8: Space = intersect(&(*CONSTANT_7),&(v62_2));
      drop(v62_2);
      let v62_9: Space = if has_head(&(v62_8)) { singleton(&[]) } else { Space::new() };
      drop(v62_8);
      let v62_11: Space = if (v62_9).is_empty() { Space::new() } else {
        let v64_10: Space = routine_16(c, &(v61_18_head), &(v61_18_tail));
        compose(&(v62_9),&(v64_10))
      };
      drop(v62_9);
      let v62_12: Space = unite(&(v62_7),&(v62_11));
      v61_18.join_into((v62_12).clone());
    }
    drop(v61_18_cursor);
    compose(&(v57_11),&(v61_18))
  };
  let v57_21: Space = intersect(&(*CONSTANT_9),&(v57_6));
  let mut v57_25 = Space::new();
  let mut v57_25_cursor = (v57_21).read_zipper();
  for v57_25_byte in v57_25_cursor.child_mask().iter() {
    v57_25_cursor.descend_to_byte(v57_25_byte);
    let v57_25_tail = v57_25_cursor.make_map();
    v57_25_cursor.ascend(1);
    let v57_25_head = Path::from_slice(&[v57_25_byte]);
    let v65_2: Space = singleton(&(v57_25_head));
    let v65_3: Space = intersect(&(*CONSTANT_7),&(v65_2));
    let v65_4: Space = if has_head(&(v65_3)) { singleton(&[]) } else { Space::new() };
    drop(v65_3);
    let v65_5: Space = subtract(&(*CONSTANT_0),&(v65_4));
    drop(v65_4);
    let v65_7: Space = if (v65_5).is_empty() { Space::new() } else {
      let v66_6: Space = routine_17(c, &(v57_25_head), &(v57_25_tail));
      compose(&(v65_5),&(v66_6))
    };
    drop(v65_5);
    let v65_8: Space = intersect(&(*CONSTANT_7),&(v65_2));
    drop(v65_2);
    let v65_9: Space = if has_head(&(v65_8)) { singleton(&[]) } else { Space::new() };
    drop(v65_8);
    let v65_11: Space = if (v65_9).is_empty() { Space::new() } else {
      let v67_10: Space = routine_18(c, &(v57_25_head), &(v57_25_tail));
      compose(&(v65_9),&(v67_10))
    };
    drop(v65_9);
    let v65_12: Space = unite(&(v65_7),&(v65_11));
    v57_25.join_into((v65_12).clone());
  }
  drop(v57_25_cursor);
  drop(v57_21);
  let v57_30: Space = if (v57_25).is_empty() { Space::new() } else {
    let v68_12: Path = concat_path(&(*p2),&(*p3));
    let v68_13: Path = concat_path(&(v68_12),&(*p0));
    drop(v68_12);
    let v68_14: Space = singleton(&(v68_13));
    drop(v68_13);
    let mut v68_29 = Space::new();
    let mut v68_29_cursor = (v68_14).read_zipper();
    for v68_29_byte in v68_29_cursor.child_mask().iter() {
      v68_29_cursor.descend_to_byte(v68_29_byte);
      let v68_29_tail = v68_29_cursor.make_map();
      v68_29_cursor.ascend(1);
      let v68_29_head = Path::from_slice(&[v68_29_byte]);
      let v69_2: Space = singleton(&(v68_29_head));
      let v69_3: Space = intersect(&(*CONSTANT_7),&(v69_2));
      let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
      drop(v69_3);
      let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
      drop(v69_4);
      let v69_7: Space = if (v69_5).is_empty() { Space::new() } else {
        let v70_6: Space = routine_19(c, &(v68_29_head), &(v68_29_tail));
        compose(&(v69_5),&(v70_6))
      };
      drop(v69_5);
      let v69_8: Space = intersect(&(*CONSTANT_7),&(v69_2));
      drop(v69_2);
      let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
      drop(v69_8);
      let v69_11: Space = if (v69_9).is_empty() { Space::new() } else {
        let v71_10: Space = routine_20(c, &(v68_29_head), &(v68_29_tail));
        compose(&(v69_9),&(v71_10))
      };
      drop(v69_9);
      let v69_12: Space = unite(&(v69_7),&(v69_11));
      v68_29.join_into((v69_12).clone());
    }
    drop(v68_29_cursor);
    compose(&(v57_25),&(v68_29))
  };
  let v57_31: Space = unite(&(v57_19),&(v57_30));
  let v57_33: Space = intersect(&(*CONSTANT_10),&(v57_6));
  let mut v57_37 = Space::new();
  let mut v57_37_cursor = (v57_33).read_zipper();
  for v57_37_byte in v57_37_cursor.child_mask().iter() {
    v57_37_cursor.descend_to_byte(v57_37_byte);
    let v57_37_tail = v57_37_cursor.make_map();
    v57_37_cursor.ascend(1);
    let v57_37_head = Path::from_slice(&[v57_37_byte]);
    let v72_2: Space = singleton(&(v57_37_head));
    let v72_3: Space = intersect(&(*CONSTANT_7),&(v72_2));
    let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
    drop(v72_3);
    let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
    drop(v72_4);
    let v72_7: Space = if (v72_5).is_empty() { Space::new() } else {
      let v73_6: Space = routine_21(c, &(v57_37_head), &(v57_37_tail));
      compose(&(v72_5),&(v73_6))
    };
    drop(v72_5);
    let v72_8: Space = intersect(&(*CONSTANT_7),&(v72_2));
    drop(v72_2);
    let v72_9: Space = if has_head(&(v72_8)) { singleton(&[]) } else { Space::new() };
    drop(v72_8);
    let v72_11: Space = if (v72_9).is_empty() { Space::new() } else {
      let v74_10: Space = routine_22(c, &(v57_37_head), &(v57_37_tail));
      compose(&(v72_9),&(v74_10))
    };
    drop(v72_9);
    let v72_12: Space = unite(&(v72_7),&(v72_11));
    v57_37.join_into((v72_12).clone());
  }
  drop(v57_37_cursor);
  drop(v57_33);
  let v57_42: Space = if (v57_37).is_empty() { Space::new() } else {
    let v75_12: Path = concat_path(&(*p2),&(*p3));
    let v75_13: Path = concat_path(&(v75_12),&(*p0));
    drop(v75_12);
    let v75_14: Space = singleton(&(v75_13));
    drop(v75_13);
    let mut v75_41 = Space::new();
    let mut v75_41_cursor = (v75_14).read_zipper();
    for v75_41_byte in v75_41_cursor.child_mask().iter() {
      v75_41_cursor.descend_to_byte(v75_41_byte);
      let v75_41_tail = v75_41_cursor.make_map();
      v75_41_cursor.ascend(1);
      let v75_41_head = Path::from_slice(&[v75_41_byte]);
      let v76_2: Space = singleton(&(v75_41_head));
      let v76_3: Space = intersect(&(*CONSTANT_7),&(v76_2));
      let v76_4: Space = if has_head(&(v76_3)) { singleton(&[]) } else { Space::new() };
      drop(v76_3);
      let v76_5: Space = subtract(&(*CONSTANT_0),&(v76_4));
      drop(v76_4);
      let v76_7: Space = if (v76_5).is_empty() { Space::new() } else {
        let v77_6: Space = routine_23(c, &(v75_41_head), &(v75_41_tail));
        compose(&(v76_5),&(v77_6))
      };
      drop(v76_5);
      let v76_8: Space = intersect(&(*CONSTANT_7),&(v76_2));
      drop(v76_2);
      let v76_9: Space = if has_head(&(v76_8)) { singleton(&[]) } else { Space::new() };
      drop(v76_8);
      let v76_11: Space = if (v76_9).is_empty() { Space::new() } else {
        let v78_10: Space = routine_24(c, &(v75_41_head), &(v75_41_tail));
        compose(&(v76_9),&(v78_10))
      };
      drop(v76_9);
      let v76_12: Space = unite(&(v76_7),&(v76_11));
      v75_41.join_into((v76_12).clone());
    }
    drop(v75_41_cursor);
    compose(&(v57_37),&(v75_41))
  };
  let v57_43: Space = unite(&(v57_31),&(v57_42));
  let v57_45: Space = intersect(&(*CONSTANT_11),&(v57_6));
  drop(v57_6);
  let mut v57_49 = Space::new();
  let mut v57_49_cursor = (v57_45).read_zipper();
  for v57_49_byte in v57_49_cursor.child_mask().iter() {
    v57_49_cursor.descend_to_byte(v57_49_byte);
    let v57_49_tail = v57_49_cursor.make_map();
    v57_49_cursor.ascend(1);
    let v57_49_head = Path::from_slice(&[v57_49_byte]);
    let v79_2: Space = singleton(&(v57_49_head));
    let v79_3: Space = intersect(&(*CONSTANT_7),&(v79_2));
    let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
    drop(v79_3);
    let v79_5: Space = subtract(&(*CONSTANT_0),&(v79_4));
    drop(v79_4);
    let v79_7: Space = if (v79_5).is_empty() { Space::new() } else {
      let v80_6: Space = routine_25(c, &(v57_49_head), &(v57_49_tail));
      compose(&(v79_5),&(v80_6))
    };
    drop(v79_5);
    let v79_8: Space = intersect(&(*CONSTANT_7),&(v79_2));
    drop(v79_2);
    let v79_9: Space = if has_head(&(v79_8)) { singleton(&[]) } else { Space::new() };
    drop(v79_8);
    let v79_11: Space = if (v79_9).is_empty() { Space::new() } else {
      let v81_10: Space = routine_26(c, &(v57_49_head), &(v57_49_tail));
      compose(&(v79_9),&(v81_10))
    };
    drop(v79_9);
    let v79_12: Space = unite(&(v79_7),&(v79_11));
    v57_49.join_into((v79_12).clone());
  }
  drop(v57_49_cursor);
  drop(v57_45);
  let v57_54: Space = if (v57_49).is_empty() { Space::new() } else {
    let v82_12: Path = concat_path(&(*p2),&(*p3));
    let v82_13: Path = concat_path(&(v82_12),&(*p0));
    drop(v82_12);
    let v82_14: Space = singleton(&(v82_13));
    drop(v82_13);
    let mut v82_53 = Space::new();
    let mut v82_53_cursor = (v82_14).read_zipper();
    for v82_53_byte in v82_53_cursor.child_mask().iter() {
      v82_53_cursor.descend_to_byte(v82_53_byte);
      let v82_53_tail = v82_53_cursor.make_map();
      v82_53_cursor.ascend(1);
      let v82_53_head = Path::from_slice(&[v82_53_byte]);
      let v83_2: Space = singleton(&(v82_53_head));
      let v83_3: Space = intersect(&(*CONSTANT_7),&(v83_2));
      let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
      drop(v83_3);
      let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
      drop(v83_4);
      let v83_7: Space = if (v83_5).is_empty() { Space::new() } else {
        let v84_6: Space = routine_27(c, &(v82_53_head), &(v82_53_tail));
        compose(&(v83_5),&(v84_6))
      };
      drop(v83_5);
      let v83_8: Space = intersect(&(*CONSTANT_7),&(v83_2));
      drop(v83_2);
      let v83_9: Space = if has_head(&(v83_8)) { singleton(&[]) } else { Space::new() };
      drop(v83_8);
      let v83_11: Space = if (v83_9).is_empty() { Space::new() } else {
        let v85_10: Space = routine_28(c, &(v82_53_head), &(v82_53_tail));
        compose(&(v83_9),&(v85_10))
      };
      drop(v83_9);
      let v83_12: Space = unite(&(v83_7),&(v83_11));
      v82_53.join_into((v83_12).clone());
    }
    drop(v82_53_cursor);
    drop(v82_14);
    compose(&(v57_49),&(v82_53))
  };
  let v57_55: Space = unite(&(v57_43),&(v57_54));
  let mut v57_70 = Space::new();
  let mut v57_70_cursor = (v57_55).read_zipper();
  for v57_70_byte in v57_70_cursor.child_mask().iter() {
    v57_70_cursor.descend_to_byte(v57_70_byte);
    let v57_70_tail = v57_70_cursor.make_map();
    v57_70_cursor.ascend(1);
    let v57_70_head = Path::from_slice(&[v57_70_byte]);
    let v86_2: Space = singleton(&(v57_70_head));
    let v86_3: Space = intersect(&(*CONSTANT_7),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (v86_5).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_cursor = (v57_70_tail).read_zipper();
      for v87_6_byte in v87_6_cursor.child_mask().iter() {
        v87_6_cursor.descend_to_byte(v87_6_byte);
        let v87_6_tail = v87_6_cursor.make_map();
        v87_6_cursor.ascend(1);
        let v87_6_head = Path::from_slice(&[v87_6_byte]);
        let v88_2: Space = singleton(&(v87_6_head));
        let v88_3: Space = intersect(&(*CONSTANT_7),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
          let v89_6: Path = concat_path(&(v57_70_head),&(v87_6_head));
          let v89_7: Space = routine_9(c, &(v89_6), &(*p1), &(v87_6_tail));
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_7),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
          let v90_6: Path = concat_path(&(v57_70_head),&(v87_6_head));
          let v90_11: Space = routine_10(c, &(v90_6), &(*p1), &(v87_6_tail));
          drop(v90_6);
          compose(&(v88_10),&(v90_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        v87_6.join_into((v88_13).clone());
      }
      drop(v87_6_cursor);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_7),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_16: Space = if (v86_9).is_empty() { Space::new() } else {
      let v91_13: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v92_10: Space = routine_29(c, &(*CONSTANT_12), &(*CONSTANT_13));
        let v92_11: Space = routine_29(c, &(*CONSTANT_14), &(*CONSTANT_15));
        let v92_12: Space = unite(&(v92_10),&(v92_11));
        compose(&(*CONSTANT_0),&(v92_12))
      };
      let v91_14: Space = unwrap(&(v91_13),&(*p1));
      let mut v91_15 = Space::new();
      let mut v91_15_cursor = (v91_14).read_zipper();
      for v91_15_byte in v91_15_cursor.child_mask().iter() {
        v91_15_cursor.descend_to_byte(v91_15_byte);
        let v91_15_tail = v91_15_cursor.make_map();
        v91_15_cursor.ascend(1);
        let v91_15_head = Path::from_slice(&[v91_15_byte]);
        let v93_2: Space = singleton(&(v91_15_head));
        let v93_3: Space = intersect(&(*CONSTANT_7),&(v93_2));
        let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
        drop(v93_3);
        let v93_5: Space = subtract(&(*CONSTANT_0),&(v93_4));
        drop(v93_4);
        let v93_7: Space = if (v93_5).is_empty() { Space::new() } else {
          let v94_6: Space = routine_30(c, &(v91_15_head), &(v57_70_head), &(v91_15_tail), &(v57_70_tail));
          compose(&(v93_5),&(v94_6))
        };
        drop(v93_5);
        let v93_8: Space = intersect(&(*CONSTANT_7),&(v93_2));
        drop(v93_2);
        let v93_9: Space = if has_head(&(v93_8)) { singleton(&[]) } else { Space::new() };
        drop(v93_8);
        let v93_11: Space = if (v93_9).is_empty() { Space::new() } else {
          let v95_10: Space = routine_31(c, &(v91_15_head), &(v57_70_head), &(v91_15_tail), &(v57_70_tail));
          compose(&(v93_9),&(v95_10))
        };
        drop(v93_9);
        let v93_12: Space = unite(&(v93_7),&(v93_11));
        v91_15.join_into((v93_12).clone());
      }
      drop(v91_15_cursor);
      compose(&(v86_9),&(v91_15))
    };
    drop(v86_9);
    let v86_17: Space = unite(&(v86_7),&(v86_16));
    v57_70.join_into((v86_17).clone());
  }
  drop(v57_70_cursor);
  let mut v57_83 = Space::new();
  let mut v57_83_cursor = (v57_70).read_zipper();
  for v57_83_byte in v57_83_cursor.child_mask().iter() {
    v57_83_cursor.descend_to_byte(v57_83_byte);
    let v57_83_tail = v57_83_cursor.make_map();
    v57_83_cursor.ascend(1);
    let v57_83_head = Path::from_slice(&[v57_83_byte]);
    let v96_2: Space = singleton(&(v57_83_head));
    let v96_3: Space = intersect(&(*CONSTANT_7),&(v96_2));
    let v96_4: Space = if has_head(&(v96_3)) { singleton(&[]) } else { Space::new() };
    drop(v96_3);
    let v96_5: Space = subtract(&(*CONSTANT_0),&(v96_4));
    drop(v96_4);
    let v96_7: Space = if (v96_5).is_empty() { Space::new() } else {
      let mut v97_6 = Space::new();
      let mut v97_6_cursor = (v57_83_tail).read_zipper();
      for v97_6_byte in v97_6_cursor.child_mask().iter() {
        v97_6_cursor.descend_to_byte(v97_6_byte);
        let v97_6_tail = v97_6_cursor.make_map();
        v97_6_cursor.ascend(1);
        let v97_6_head = Path::from_slice(&[v97_6_byte]);
        let v98_2: Space = singleton(&(v97_6_head));
        let v98_3: Space = intersect(&(*CONSTANT_7),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (v98_5).is_empty() { Space::new() } else {
          let v99_6: Path = concat_path(&(v57_83_head),&(v97_6_head));
          let v99_7: Space = routine_11(c, &(v99_6), &(*p1), &(v97_6_tail));
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_7),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_12: Space = if (v98_10).is_empty() { Space::new() } else {
          let v100_6: Path = concat_path(&(v57_83_head),&(v97_6_head));
          let v100_11: Space = routine_12(c, &(v100_6), &(*p1), &(v97_6_tail));
          drop(v100_6);
          compose(&(v98_10),&(v100_11))
        };
        drop(v98_10);
        let v98_13: Space = unite(&(v98_8),&(v98_12));
        v97_6.join_into((v98_13).clone());
      }
      drop(v97_6_cursor);
      compose(&(v96_5),&(v97_6))
    };
    drop(v96_5);
    let v96_8: Space = intersect(&(*CONSTANT_7),&(v96_2));
    drop(v96_2);
    let v96_9: Space = if has_head(&(v96_8)) { singleton(&[]) } else { Space::new() };
    drop(v96_8);
    let v96_18: Space = if (v96_9).is_empty() { Space::new() } else {
      let v101_13: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v102_10: Space = routine_32(c, &(*CONSTANT_12), &(*CONSTANT_13));
        let v102_11: Space = routine_32(c, &(*CONSTANT_14), &(*CONSTANT_15));
        let v102_12: Space = unite(&(v102_10),&(v102_11));
        compose(&(*CONSTANT_0),&(v102_12))
      };
      let v101_14: Space = unwrap(&(v101_13),&(*p1));
      let v101_15: Space = unwrap(&(v101_14),&(v57_83_head));
      let v101_16: Space = unwrap(&(v101_15),&(*p1));
      let mut v101_17 = Space::new();
      let mut v101_17_cursor = (v101_16).read_zipper();
      for v101_17_byte in v101_17_cursor.child_mask().iter() {
        v101_17_cursor.descend_to_byte(v101_17_byte);
        let v101_17_tail = v101_17_cursor.make_map();
        v101_17_cursor.ascend(1);
        let v101_17_head = Path::from_slice(&[v101_17_byte]);
        let v103_2: Space = singleton(&(v101_17_head));
        let v103_3: Space = intersect(&(*CONSTANT_7),&(v103_2));
        let v103_4: Space = if has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
        drop(v103_3);
        let v103_5: Space = subtract(&(*CONSTANT_0),&(v103_4));
        drop(v103_4);
        let v103_7: Space = if (v103_5).is_empty() { Space::new() } else {
          let v104_6: Space = routine_33(c, &(v101_17_head), &(v101_17_tail), &(v57_83_tail));
          compose(&(v103_5),&(v104_6))
        };
        drop(v103_5);
        let v103_8: Space = intersect(&(*CONSTANT_7),&(v103_2));
        drop(v103_2);
        let v103_9: Space = if has_head(&(v103_8)) { singleton(&[]) } else { Space::new() };
        drop(v103_8);
        let v103_11: Space = if (v103_9).is_empty() { Space::new() } else {
          let v105_10: Space = routine_34(c, &(v101_17_head), &(v101_17_tail), &(v57_83_tail));
          compose(&(v103_9),&(v105_10))
        };
        drop(v103_9);
        let v103_12: Space = unite(&(v103_7),&(v103_11));
        v101_17.join_into((v103_12).clone());
      }
      drop(v101_17_cursor);
      compose(&(v96_9),&(v101_17))
    };
    drop(v96_9);
    let v96_19: Space = unite(&(v96_7),&(v96_18));
    v57_83.join_into((v96_19).clone());
  }
  drop(v57_83_cursor);
  (v57_83).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v106_3: Space = singleton(&(*p0));
  let v106_4: Space = intersect(&(*CONSTANT_8),&(v106_3));
  let mut v106_11 = Space::new();
  let mut v106_11_cursor = (v106_4).read_zipper();
  for v106_11_byte in v106_11_cursor.child_mask().iter() {
    v106_11_cursor.descend_to_byte(v106_11_byte);
    let v106_11_tail = v106_11_cursor.make_map();
    v106_11_cursor.ascend(1);
    let v106_11_head = Path::from_slice(&[v106_11_byte]);
    let v107_2: Space = singleton(&(v106_11_head));
    let v107_3: Space = intersect(&(*CONSTANT_7),&(v107_2));
    let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
    drop(v107_3);
    let v107_5: Space = subtract(&(*CONSTANT_0),&(v107_4));
    drop(v107_4);
    let v107_7: Space = if (v107_5).is_empty() { Space::new() } else {
      let mut v108_6 = Space::new();
      let mut v108_6_cursor = (v106_11_tail).read_zipper();
      for v108_6_byte in v108_6_cursor.child_mask().iter() {
        v108_6_cursor.descend_to_byte(v108_6_byte);
        let v108_6_tail = v108_6_cursor.make_map();
        v108_6_cursor.ascend(1);
        let v108_6_head = Path::from_slice(&[v108_6_byte]);
        let v109_2: Space = singleton(&(v108_6_head));
        let v109_3: Space = intersect(&(*CONSTANT_7),&(v109_2));
        let v109_4: Space = if has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
        drop(v109_3);
        let v109_5: Space = subtract(&(*CONSTANT_0),&(v109_4));
        drop(v109_4);
        let v109_8: Space = if (v109_5).is_empty() { Space::new() } else {
          let v110_6: Path = concat_path(&(v106_11_head),&(v108_6_head));
          let v110_7: Space = routine_13(c, &(v110_6), &(v108_6_tail));
          compose(&(v109_5),&(v110_7))
        };
        drop(v109_5);
        let v109_9: Space = intersect(&(*CONSTANT_7),&(v109_2));
        drop(v109_2);
        let v109_10: Space = if has_head(&(v109_9)) { singleton(&[]) } else { Space::new() };
        drop(v109_9);
        let v109_12: Space = if (v109_10).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v106_11_head),&(v108_6_head));
          let v111_11: Space = routine_14(c, &(v111_6), &(v108_6_tail));
          drop(v111_6);
          compose(&(v109_10),&(v111_11))
        };
        drop(v109_10);
        let v109_13: Space = unite(&(v109_8),&(v109_12));
        v108_6.join_into((v109_13).clone());
      }
      drop(v108_6_cursor);
      compose(&(v107_5),&(v108_6))
    };
    drop(v107_5);
    let v107_8: Space = intersect(&(*CONSTANT_7),&(v107_2));
    drop(v107_2);
    let v107_9: Space = if has_head(&(v107_8)) { singleton(&[]) } else { Space::new() };
    drop(v107_8);
    let v107_10: Space = compose(&(v107_9),&(v106_11_tail));
    drop(v107_9);
    let v107_11: Space = unite(&(v107_7),&(v107_10));
    drop(v107_10);
    v106_11.join_into((v107_11).clone());
  }
  drop(v106_11_cursor);
  drop(v106_4);
  let v106_22: Space = if (v106_11).is_empty() { Space::new() } else {
    let mut v112_21 = Space::new();
    let mut v112_21_cursor = (*s0).read_zipper();
    for v112_21_byte in v112_21_cursor.child_mask().iter() {
      v112_21_cursor.descend_to_byte(v112_21_byte);
      let v112_21_tail = v112_21_cursor.make_map();
      v112_21_cursor.ascend(1);
      let v112_21_head = Path::from_slice(&[v112_21_byte]);
      let v113_2: Space = singleton(&(v112_21_head));
      let v113_3: Space = intersect(&(*CONSTANT_7),&(v113_2));
      let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
      drop(v113_3);
      let v113_5: Space = subtract(&(*CONSTANT_0),&(v113_4));
      drop(v113_4);
      let v113_7: Space = if (v113_5).is_empty() { Space::new() } else {
        let mut v114_6 = Space::new();
        let mut v114_6_cursor = (v112_21_tail).read_zipper();
        for v114_6_byte in v114_6_cursor.child_mask().iter() {
          v114_6_cursor.descend_to_byte(v114_6_byte);
          let v114_6_tail = v114_6_cursor.make_map();
          v114_6_cursor.ascend(1);
          let v114_6_head = Path::from_slice(&[v114_6_byte]);
          let v115_2: Space = singleton(&(v114_6_head));
          let v115_3: Space = intersect(&(*CONSTANT_7),&(v115_2));
          let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
          drop(v115_3);
          let v115_5: Space = subtract(&(*CONSTANT_0),&(v115_4));
          drop(v115_4);
          let v115_8: Space = if (v115_5).is_empty() { Space::new() } else {
            let v116_6: Path = concat_path(&(v112_21_head),&(v114_6_head));
            let v116_7: Space = routine_15(c, &(v116_6), &(v114_6_tail));
            compose(&(v115_5),&(v116_7))
          };
          drop(v115_5);
          let v115_9: Space = intersect(&(*CONSTANT_7),&(v115_2));
          drop(v115_2);
          let v115_10: Space = if has_head(&(v115_9)) { singleton(&[]) } else { Space::new() };
          drop(v115_9);
          let v115_12: Space = if (v115_10).is_empty() { Space::new() } else {
            let v117_6: Path = concat_path(&(v112_21_head),&(v114_6_head));
            let v117_11: Space = routine_16(c, &(v117_6), &(v114_6_tail));
            drop(v117_6);
            compose(&(v115_10),&(v117_11))
          };
          drop(v115_10);
          let v115_13: Space = unite(&(v115_8),&(v115_12));
          v114_6.join_into((v115_13).clone());
        }
        drop(v114_6_cursor);
        compose(&(v113_5),&(v114_6))
      };
      drop(v113_5);
      let v113_8: Space = intersect(&(*CONSTANT_7),&(v113_2));
      drop(v113_2);
      let v113_9: Space = if has_head(&(v113_8)) { singleton(&[]) } else { Space::new() };
      drop(v113_8);
      let v113_11: Space = if (v113_9).is_empty() { Space::new() } else {
        let mut v118_10 = Space::new();
        let mut v118_10_cursor = (v112_21_tail).read_zipper();
        for v118_10_byte in v118_10_cursor.child_mask().iter() {
          v118_10_cursor.descend_to_byte(v118_10_byte);
          let v118_10_tail = v118_10_cursor.make_map();
          v118_10_cursor.ascend(1);
          let v118_10_head = Path::from_slice(&[v118_10_byte]);
          let v119_2: Space = singleton(&(v118_10_head));
          let v119_3: Space = intersect(&(*CONSTANT_7),&(v119_2));
          let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
          drop(v119_3);
          let v119_5: Space = subtract(&(*CONSTANT_0),&(v119_4));
          drop(v119_4);
          let v119_7: Space = if (v119_5).is_empty() { Space::new() } else {
            let v120_6: Space = routine_35(c, &(v118_10_head), &(v112_21_head), &(v118_10_tail));
            compose(&(v119_5),&(v120_6))
          };
          drop(v119_5);
          let v119_8: Space = intersect(&(*CONSTANT_7),&(v119_2));
          drop(v119_2);
          let v119_9: Space = if has_head(&(v119_8)) { singleton(&[]) } else { Space::new() };
          drop(v119_8);
          let v119_11: Space = if (v119_9).is_empty() { Space::new() } else {
            let v121_10: Space = routine_36(c, &(v118_10_head), &(v112_21_head), &(v118_10_tail));
            compose(&(v119_9),&(v121_10))
          };
          drop(v119_9);
          let v119_12: Space = unite(&(v119_7),&(v119_11));
          v118_10.join_into((v119_12).clone());
        }
        drop(v118_10_cursor);
        compose(&(v113_9),&(v118_10))
      };
      drop(v113_9);
      let v113_12: Space = unite(&(v113_7),&(v113_11));
      v112_21.join_into((v113_12).clone());
    }
    drop(v112_21_cursor);
    compose(&(v106_11),&(v112_21))
  };
  let v106_24: Space = intersect(&(*CONSTANT_9),&(v106_3));
  let mut v106_31 = Space::new();
  let mut v106_31_cursor = (v106_24).read_zipper();
  for v106_31_byte in v106_31_cursor.child_mask().iter() {
    v106_31_cursor.descend_to_byte(v106_31_byte);
    let v106_31_tail = v106_31_cursor.make_map();
    v106_31_cursor.ascend(1);
    let v106_31_head = Path::from_slice(&[v106_31_byte]);
    let v122_2: Space = singleton(&(v106_31_head));
    let v122_3: Space = intersect(&(*CONSTANT_7),&(v122_2));
    let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
    drop(v122_3);
    let v122_5: Space = subtract(&(*CONSTANT_0),&(v122_4));
    drop(v122_4);
    let v122_7: Space = if (v122_5).is_empty() { Space::new() } else {
      let mut v123_6 = Space::new();
      let mut v123_6_cursor = (v106_31_tail).read_zipper();
      for v123_6_byte in v123_6_cursor.child_mask().iter() {
        v123_6_cursor.descend_to_byte(v123_6_byte);
        let v123_6_tail = v123_6_cursor.make_map();
        v123_6_cursor.ascend(1);
        let v123_6_head = Path::from_slice(&[v123_6_byte]);
        let v124_2: Space = singleton(&(v123_6_head));
        let v124_3: Space = intersect(&(*CONSTANT_7),&(v124_2));
        let v124_4: Space = if has_head(&(v124_3)) { singleton(&[]) } else { Space::new() };
        drop(v124_3);
        let v124_5: Space = subtract(&(*CONSTANT_0),&(v124_4));
        drop(v124_4);
        let v124_8: Space = if (v124_5).is_empty() { Space::new() } else {
          let v125_6: Path = concat_path(&(v106_31_head),&(v123_6_head));
          let v125_7: Space = routine_17(c, &(v125_6), &(v123_6_tail));
          compose(&(v124_5),&(v125_7))
        };
        drop(v124_5);
        let v124_9: Space = intersect(&(*CONSTANT_7),&(v124_2));
        drop(v124_2);
        let v124_10: Space = if has_head(&(v124_9)) { singleton(&[]) } else { Space::new() };
        drop(v124_9);
        let v124_12: Space = if (v124_10).is_empty() { Space::new() } else {
          let v126_6: Path = concat_path(&(v106_31_head),&(v123_6_head));
          let v126_11: Space = routine_18(c, &(v126_6), &(v123_6_tail));
          drop(v126_6);
          compose(&(v124_10),&(v126_11))
        };
        drop(v124_10);
        let v124_13: Space = unite(&(v124_8),&(v124_12));
        v123_6.join_into((v124_13).clone());
      }
      drop(v123_6_cursor);
      compose(&(v122_5),&(v123_6))
    };
    drop(v122_5);
    let v122_8: Space = intersect(&(*CONSTANT_7),&(v122_2));
    drop(v122_2);
    let v122_9: Space = if has_head(&(v122_8)) { singleton(&[]) } else { Space::new() };
    drop(v122_8);
    let v122_10: Space = compose(&(v122_9),&(v106_31_tail));
    drop(v122_9);
    let v122_11: Space = unite(&(v122_7),&(v122_10));
    drop(v122_10);
    v106_31.join_into((v122_11).clone());
  }
  drop(v106_31_cursor);
  drop(v106_24);
  let v106_42: Space = if (v106_31).is_empty() { Space::new() } else {
    let mut v127_41 = Space::new();
    let mut v127_41_cursor = (*s0).read_zipper();
    for v127_41_byte in v127_41_cursor.child_mask().iter() {
      v127_41_cursor.descend_to_byte(v127_41_byte);
      let v127_41_tail = v127_41_cursor.make_map();
      v127_41_cursor.ascend(1);
      let v127_41_head = Path::from_slice(&[v127_41_byte]);
      let v128_2: Space = singleton(&(v127_41_head));
      let v128_3: Space = intersect(&(*CONSTANT_7),&(v128_2));
      let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
      drop(v128_3);
      let v128_5: Space = subtract(&(*CONSTANT_0),&(v128_4));
      drop(v128_4);
      let v128_7: Space = if (v128_5).is_empty() { Space::new() } else {
        let mut v129_6 = Space::new();
        let mut v129_6_cursor = (v127_41_tail).read_zipper();
        for v129_6_byte in v129_6_cursor.child_mask().iter() {
          v129_6_cursor.descend_to_byte(v129_6_byte);
          let v129_6_tail = v129_6_cursor.make_map();
          v129_6_cursor.ascend(1);
          let v129_6_head = Path::from_slice(&[v129_6_byte]);
          let v130_2: Space = singleton(&(v129_6_head));
          let v130_3: Space = intersect(&(*CONSTANT_7),&(v130_2));
          let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
          drop(v130_3);
          let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
          drop(v130_4);
          let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
            let v131_6: Path = concat_path(&(v127_41_head),&(v129_6_head));
            let v131_7: Space = routine_19(c, &(v131_6), &(v129_6_tail));
            compose(&(v130_5),&(v131_7))
          };
          drop(v130_5);
          let v130_9: Space = intersect(&(*CONSTANT_7),&(v130_2));
          drop(v130_2);
          let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
          drop(v130_9);
          let v130_12: Space = if (v130_10).is_empty() { Space::new() } else {
            let v132_6: Path = concat_path(&(v127_41_head),&(v129_6_head));
            let v132_11: Space = routine_20(c, &(v132_6), &(v129_6_tail));
            drop(v132_6);
            compose(&(v130_10),&(v132_11))
          };
          drop(v130_10);
          let v130_13: Space = unite(&(v130_8),&(v130_12));
          v129_6.join_into((v130_13).clone());
        }
        drop(v129_6_cursor);
        compose(&(v128_5),&(v129_6))
      };
      drop(v128_5);
      let v128_8: Space = intersect(&(*CONSTANT_7),&(v128_2));
      drop(v128_2);
      let v128_9: Space = if has_head(&(v128_8)) { singleton(&[]) } else { Space::new() };
      drop(v128_8);
      let v128_11: Space = if (v128_9).is_empty() { Space::new() } else {
        let mut v133_10 = Space::new();
        let mut v133_10_cursor = (v127_41_tail).read_zipper();
        for v133_10_byte in v133_10_cursor.child_mask().iter() {
          v133_10_cursor.descend_to_byte(v133_10_byte);
          let v133_10_tail = v133_10_cursor.make_map();
          v133_10_cursor.ascend(1);
          let v133_10_head = Path::from_slice(&[v133_10_byte]);
          let v134_2: Space = singleton(&(v133_10_head));
          let v134_3: Space = intersect(&(*CONSTANT_7),&(v134_2));
          let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
          drop(v134_3);
          let v134_5: Space = subtract(&(*CONSTANT_0),&(v134_4));
          drop(v134_4);
          let v134_7: Space = if (v134_5).is_empty() { Space::new() } else {
            let v135_6: Space = routine_37(c, &(v133_10_head), &(v127_41_head), &(v133_10_tail));
            compose(&(v134_5),&(v135_6))
          };
          drop(v134_5);
          let v134_8: Space = intersect(&(*CONSTANT_7),&(v134_2));
          drop(v134_2);
          let v134_9: Space = if has_head(&(v134_8)) { singleton(&[]) } else { Space::new() };
          drop(v134_8);
          let v134_11: Space = if (v134_9).is_empty() { Space::new() } else {
            let v136_10: Space = routine_38(c, &(v133_10_head), &(v127_41_head), &(v133_10_tail));
            compose(&(v134_9),&(v136_10))
          };
          drop(v134_9);
          let v134_12: Space = unite(&(v134_7),&(v134_11));
          v133_10.join_into((v134_12).clone());
        }
        drop(v133_10_cursor);
        compose(&(v128_9),&(v133_10))
      };
      drop(v128_9);
      let v128_12: Space = unite(&(v128_7),&(v128_11));
      v127_41.join_into((v128_12).clone());
    }
    drop(v127_41_cursor);
    compose(&(v106_31),&(v127_41))
  };
  let v106_43: Space = unite(&(v106_22),&(v106_42));
  let v106_45: Space = intersect(&(*CONSTANT_10),&(v106_3));
  let mut v106_52 = Space::new();
  let mut v106_52_cursor = (v106_45).read_zipper();
  for v106_52_byte in v106_52_cursor.child_mask().iter() {
    v106_52_cursor.descend_to_byte(v106_52_byte);
    let v106_52_tail = v106_52_cursor.make_map();
    v106_52_cursor.ascend(1);
    let v106_52_head = Path::from_slice(&[v106_52_byte]);
    let v137_2: Space = singleton(&(v106_52_head));
    let v137_3: Space = intersect(&(*CONSTANT_7),&(v137_2));
    let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
    drop(v137_3);
    let v137_5: Space = subtract(&(*CONSTANT_0),&(v137_4));
    drop(v137_4);
    let v137_7: Space = if (v137_5).is_empty() { Space::new() } else {
      let mut v138_6 = Space::new();
      let mut v138_6_cursor = (v106_52_tail).read_zipper();
      for v138_6_byte in v138_6_cursor.child_mask().iter() {
        v138_6_cursor.descend_to_byte(v138_6_byte);
        let v138_6_tail = v138_6_cursor.make_map();
        v138_6_cursor.ascend(1);
        let v138_6_head = Path::from_slice(&[v138_6_byte]);
        let v139_2: Space = singleton(&(v138_6_head));
        let v139_3: Space = intersect(&(*CONSTANT_7),&(v139_2));
        let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
        drop(v139_3);
        let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
        drop(v139_4);
        let v139_8: Space = if (v139_5).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v106_52_head),&(v138_6_head));
          let v140_7: Space = routine_21(c, &(v140_6), &(v138_6_tail));
          compose(&(v139_5),&(v140_7))
        };
        drop(v139_5);
        let v139_9: Space = intersect(&(*CONSTANT_7),&(v139_2));
        drop(v139_2);
        let v139_10: Space = if has_head(&(v139_9)) { singleton(&[]) } else { Space::new() };
        drop(v139_9);
        let v139_12: Space = if (v139_10).is_empty() { Space::new() } else {
          let v141_6: Path = concat_path(&(v106_52_head),&(v138_6_head));
          let v141_11: Space = routine_22(c, &(v141_6), &(v138_6_tail));
          drop(v141_6);
          compose(&(v139_10),&(v141_11))
        };
        drop(v139_10);
        let v139_13: Space = unite(&(v139_8),&(v139_12));
        v138_6.join_into((v139_13).clone());
      }
      drop(v138_6_cursor);
      compose(&(v137_5),&(v138_6))
    };
    drop(v137_5);
    let v137_8: Space = intersect(&(*CONSTANT_7),&(v137_2));
    drop(v137_2);
    let v137_9: Space = if has_head(&(v137_8)) { singleton(&[]) } else { Space::new() };
    drop(v137_8);
    let v137_10: Space = compose(&(v137_9),&(v106_52_tail));
    drop(v137_9);
    let v137_11: Space = unite(&(v137_7),&(v137_10));
    drop(v137_10);
    v106_52.join_into((v137_11).clone());
  }
  drop(v106_52_cursor);
  drop(v106_45);
  let v106_63: Space = if (v106_52).is_empty() { Space::new() } else {
    let mut v142_62 = Space::new();
    let mut v142_62_cursor = (*s0).read_zipper();
    for v142_62_byte in v142_62_cursor.child_mask().iter() {
      v142_62_cursor.descend_to_byte(v142_62_byte);
      let v142_62_tail = v142_62_cursor.make_map();
      v142_62_cursor.ascend(1);
      let v142_62_head = Path::from_slice(&[v142_62_byte]);
      let v143_2: Space = singleton(&(v142_62_head));
      let v143_3: Space = intersect(&(*CONSTANT_7),&(v143_2));
      let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
      drop(v143_3);
      let v143_5: Space = subtract(&(*CONSTANT_0),&(v143_4));
      drop(v143_4);
      let v143_7: Space = if (v143_5).is_empty() { Space::new() } else {
        let mut v144_6 = Space::new();
        let mut v144_6_cursor = (v142_62_tail).read_zipper();
        for v144_6_byte in v144_6_cursor.child_mask().iter() {
          v144_6_cursor.descend_to_byte(v144_6_byte);
          let v144_6_tail = v144_6_cursor.make_map();
          v144_6_cursor.ascend(1);
          let v144_6_head = Path::from_slice(&[v144_6_byte]);
          let v145_2: Space = singleton(&(v144_6_head));
          let v145_3: Space = intersect(&(*CONSTANT_7),&(v145_2));
          let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
          drop(v145_3);
          let v145_5: Space = subtract(&(*CONSTANT_0),&(v145_4));
          drop(v145_4);
          let v145_8: Space = if (v145_5).is_empty() { Space::new() } else {
            let v146_6: Path = concat_path(&(v142_62_head),&(v144_6_head));
            let v146_7: Space = routine_23(c, &(v146_6), &(v144_6_tail));
            compose(&(v145_5),&(v146_7))
          };
          drop(v145_5);
          let v145_9: Space = intersect(&(*CONSTANT_7),&(v145_2));
          drop(v145_2);
          let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
          drop(v145_9);
          let v145_12: Space = if (v145_10).is_empty() { Space::new() } else {
            let v147_6: Path = concat_path(&(v142_62_head),&(v144_6_head));
            let v147_11: Space = routine_24(c, &(v147_6), &(v144_6_tail));
            drop(v147_6);
            compose(&(v145_10),&(v147_11))
          };
          drop(v145_10);
          let v145_13: Space = unite(&(v145_8),&(v145_12));
          v144_6.join_into((v145_13).clone());
        }
        drop(v144_6_cursor);
        compose(&(v143_5),&(v144_6))
      };
      drop(v143_5);
      let v143_8: Space = intersect(&(*CONSTANT_7),&(v143_2));
      drop(v143_2);
      let v143_9: Space = if has_head(&(v143_8)) { singleton(&[]) } else { Space::new() };
      drop(v143_8);
      let v143_11: Space = if (v143_9).is_empty() { Space::new() } else {
        let mut v148_10 = Space::new();
        let mut v148_10_cursor = (v142_62_tail).read_zipper();
        for v148_10_byte in v148_10_cursor.child_mask().iter() {
          v148_10_cursor.descend_to_byte(v148_10_byte);
          let v148_10_tail = v148_10_cursor.make_map();
          v148_10_cursor.ascend(1);
          let v148_10_head = Path::from_slice(&[v148_10_byte]);
          let v149_2: Space = singleton(&(v148_10_head));
          let v149_3: Space = intersect(&(*CONSTANT_7),&(v149_2));
          let v149_4: Space = if has_head(&(v149_3)) { singleton(&[]) } else { Space::new() };
          drop(v149_3);
          let v149_5: Space = subtract(&(*CONSTANT_0),&(v149_4));
          drop(v149_4);
          let v149_7: Space = if (v149_5).is_empty() { Space::new() } else {
            let v150_6: Space = routine_39(c, &(v148_10_head), &(v142_62_head), &(v148_10_tail));
            compose(&(v149_5),&(v150_6))
          };
          drop(v149_5);
          let v149_8: Space = intersect(&(*CONSTANT_7),&(v149_2));
          drop(v149_2);
          let v149_9: Space = if has_head(&(v149_8)) { singleton(&[]) } else { Space::new() };
          drop(v149_8);
          let v149_11: Space = if (v149_9).is_empty() { Space::new() } else {
            let v151_10: Space = routine_40(c, &(v148_10_head), &(v142_62_head), &(v148_10_tail));
            compose(&(v149_9),&(v151_10))
          };
          drop(v149_9);
          let v149_12: Space = unite(&(v149_7),&(v149_11));
          v148_10.join_into((v149_12).clone());
        }
        drop(v148_10_cursor);
        compose(&(v143_9),&(v148_10))
      };
      drop(v143_9);
      let v143_12: Space = unite(&(v143_7),&(v143_11));
      v142_62.join_into((v143_12).clone());
    }
    drop(v142_62_cursor);
    compose(&(v106_52),&(v142_62))
  };
  let v106_64: Space = unite(&(v106_43),&(v106_63));
  let v106_66: Space = intersect(&(*CONSTANT_11),&(v106_3));
  drop(v106_3);
  let mut v106_73 = Space::new();
  let mut v106_73_cursor = (v106_66).read_zipper();
  for v106_73_byte in v106_73_cursor.child_mask().iter() {
    v106_73_cursor.descend_to_byte(v106_73_byte);
    let v106_73_tail = v106_73_cursor.make_map();
    v106_73_cursor.ascend(1);
    let v106_73_head = Path::from_slice(&[v106_73_byte]);
    let v152_2: Space = singleton(&(v106_73_head));
    let v152_3: Space = intersect(&(*CONSTANT_7),&(v152_2));
    let v152_4: Space = if has_head(&(v152_3)) { singleton(&[]) } else { Space::new() };
    drop(v152_3);
    let v152_5: Space = subtract(&(*CONSTANT_0),&(v152_4));
    drop(v152_4);
    let v152_7: Space = if (v152_5).is_empty() { Space::new() } else {
      let mut v153_6 = Space::new();
      let mut v153_6_cursor = (v106_73_tail).read_zipper();
      for v153_6_byte in v153_6_cursor.child_mask().iter() {
        v153_6_cursor.descend_to_byte(v153_6_byte);
        let v153_6_tail = v153_6_cursor.make_map();
        v153_6_cursor.ascend(1);
        let v153_6_head = Path::from_slice(&[v153_6_byte]);
        let v154_2: Space = singleton(&(v153_6_head));
        let v154_3: Space = intersect(&(*CONSTANT_7),&(v154_2));
        let v154_4: Space = if has_head(&(v154_3)) { singleton(&[]) } else { Space::new() };
        drop(v154_3);
        let v154_5: Space = subtract(&(*CONSTANT_0),&(v154_4));
        drop(v154_4);
        let v154_8: Space = if (v154_5).is_empty() { Space::new() } else {
          let v155_6: Path = concat_path(&(v106_73_head),&(v153_6_head));
          let v155_7: Space = routine_25(c, &(v155_6), &(v153_6_tail));
          compose(&(v154_5),&(v155_7))
        };
        drop(v154_5);
        let v154_9: Space = intersect(&(*CONSTANT_7),&(v154_2));
        drop(v154_2);
        let v154_10: Space = if has_head(&(v154_9)) { singleton(&[]) } else { Space::new() };
        drop(v154_9);
        let v154_12: Space = if (v154_10).is_empty() { Space::new() } else {
          let v156_6: Path = concat_path(&(v106_73_head),&(v153_6_head));
          let v156_11: Space = routine_26(c, &(v156_6), &(v153_6_tail));
          drop(v156_6);
          compose(&(v154_10),&(v156_11))
        };
        drop(v154_10);
        let v154_13: Space = unite(&(v154_8),&(v154_12));
        v153_6.join_into((v154_13).clone());
      }
      drop(v153_6_cursor);
      compose(&(v152_5),&(v153_6))
    };
    drop(v152_5);
    let v152_8: Space = intersect(&(*CONSTANT_7),&(v152_2));
    drop(v152_2);
    let v152_9: Space = if has_head(&(v152_8)) { singleton(&[]) } else { Space::new() };
    drop(v152_8);
    let v152_10: Space = compose(&(v152_9),&(v106_73_tail));
    drop(v152_9);
    let v152_11: Space = unite(&(v152_7),&(v152_10));
    drop(v152_10);
    v106_73.join_into((v152_11).clone());
  }
  drop(v106_73_cursor);
  drop(v106_66);
  let v106_84: Space = if (v106_73).is_empty() { Space::new() } else {
    let mut v157_83 = Space::new();
    let mut v157_83_cursor = (*s0).read_zipper();
    for v157_83_byte in v157_83_cursor.child_mask().iter() {
      v157_83_cursor.descend_to_byte(v157_83_byte);
      let v157_83_tail = v157_83_cursor.make_map();
      v157_83_cursor.ascend(1);
      let v157_83_head = Path::from_slice(&[v157_83_byte]);
      let v158_2: Space = singleton(&(v157_83_head));
      let v158_3: Space = intersect(&(*CONSTANT_7),&(v158_2));
      let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
      drop(v158_3);
      let v158_5: Space = subtract(&(*CONSTANT_0),&(v158_4));
      drop(v158_4);
      let v158_7: Space = if (v158_5).is_empty() { Space::new() } else {
        let mut v159_6 = Space::new();
        let mut v159_6_cursor = (v157_83_tail).read_zipper();
        for v159_6_byte in v159_6_cursor.child_mask().iter() {
          v159_6_cursor.descend_to_byte(v159_6_byte);
          let v159_6_tail = v159_6_cursor.make_map();
          v159_6_cursor.ascend(1);
          let v159_6_head = Path::from_slice(&[v159_6_byte]);
          let v160_2: Space = singleton(&(v159_6_head));
          let v160_3: Space = intersect(&(*CONSTANT_7),&(v160_2));
          let v160_4: Space = if has_head(&(v160_3)) { singleton(&[]) } else { Space::new() };
          drop(v160_3);
          let v160_5: Space = subtract(&(*CONSTANT_0),&(v160_4));
          drop(v160_4);
          let v160_8: Space = if (v160_5).is_empty() { Space::new() } else {
            let v161_6: Path = concat_path(&(v157_83_head),&(v159_6_head));
            let v161_7: Space = routine_27(c, &(v161_6), &(v159_6_tail));
            compose(&(v160_5),&(v161_7))
          };
          drop(v160_5);
          let v160_9: Space = intersect(&(*CONSTANT_7),&(v160_2));
          drop(v160_2);
          let v160_10: Space = if has_head(&(v160_9)) { singleton(&[]) } else { Space::new() };
          drop(v160_9);
          let v160_12: Space = if (v160_10).is_empty() { Space::new() } else {
            let v162_6: Path = concat_path(&(v157_83_head),&(v159_6_head));
            let v162_11: Space = routine_28(c, &(v162_6), &(v159_6_tail));
            drop(v162_6);
            compose(&(v160_10),&(v162_11))
          };
          drop(v160_10);
          let v160_13: Space = unite(&(v160_8),&(v160_12));
          v159_6.join_into((v160_13).clone());
        }
        drop(v159_6_cursor);
        compose(&(v158_5),&(v159_6))
      };
      drop(v158_5);
      let v158_8: Space = intersect(&(*CONSTANT_7),&(v158_2));
      drop(v158_2);
      let v158_9: Space = if has_head(&(v158_8)) { singleton(&[]) } else { Space::new() };
      drop(v158_8);
      let v158_11: Space = if (v158_9).is_empty() { Space::new() } else {
        let mut v163_10 = Space::new();
        let mut v163_10_cursor = (v157_83_tail).read_zipper();
        for v163_10_byte in v163_10_cursor.child_mask().iter() {
          v163_10_cursor.descend_to_byte(v163_10_byte);
          let v163_10_tail = v163_10_cursor.make_map();
          v163_10_cursor.ascend(1);
          let v163_10_head = Path::from_slice(&[v163_10_byte]);
          let v164_2: Space = singleton(&(v163_10_head));
          let v164_3: Space = intersect(&(*CONSTANT_7),&(v164_2));
          let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
          drop(v164_3);
          let v164_5: Space = subtract(&(*CONSTANT_0),&(v164_4));
          drop(v164_4);
          let v164_7: Space = if (v164_5).is_empty() { Space::new() } else {
            let v165_6: Space = routine_41(c, &(v163_10_head), &(v157_83_head), &(v163_10_tail));
            compose(&(v164_5),&(v165_6))
          };
          drop(v164_5);
          let v164_8: Space = intersect(&(*CONSTANT_7),&(v164_2));
          drop(v164_2);
          let v164_9: Space = if has_head(&(v164_8)) { singleton(&[]) } else { Space::new() };
          drop(v164_8);
          let v164_11: Space = if (v164_9).is_empty() { Space::new() } else {
            let v166_10: Space = routine_42(c, &(v163_10_head), &(v157_83_head), &(v163_10_tail));
            compose(&(v164_9),&(v166_10))
          };
          drop(v164_9);
          let v164_12: Space = unite(&(v164_7),&(v164_11));
          v163_10.join_into((v164_12).clone());
        }
        drop(v163_10_cursor);
        compose(&(v158_9),&(v163_10))
      };
      drop(v158_9);
      let v158_12: Space = unite(&(v158_7),&(v158_11));
      v157_83.join_into((v158_12).clone());
    }
    drop(v157_83_cursor);
    compose(&(v106_73),&(v157_83))
  };
  let v106_85: Space = unite(&(v106_64),&(v106_84));
  (v106_85).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v167_14 = Space::new();
  let mut v167_14_cursor = (*s0).read_zipper();
  for v167_14_byte in v167_14_cursor.child_mask().iter() {
    v167_14_cursor.descend_to_byte(v167_14_byte);
    let v167_14_tail = v167_14_cursor.make_map();
    v167_14_cursor.ascend(1);
    let v167_14_head = Path::from_slice(&[v167_14_byte]);
    let v168_2: Space = singleton(&(v167_14_head));
    let v168_3: Space = intersect(&(*CONSTANT_7),&(v168_2));
    let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
    drop(v168_3);
    let v168_5: Space = subtract(&(*CONSTANT_0),&(v168_4));
    drop(v168_4);
    let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
      let v169_6: Path = concat_path(&(*p0),&(v167_14_head));
      let v169_7: Space = routine_9(c, &(v169_6), &(*p1), &(v167_14_tail));
      compose(&(v168_5),&(v169_7))
    };
    drop(v168_5);
    let v168_9: Space = intersect(&(*CONSTANT_7),&(v168_2));
    drop(v168_2);
    let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
    drop(v168_9);
    let v168_17: Space = if (v168_10).is_empty() { Space::new() } else {
      let v170_6: Path = concat_path(&(*p0),&(v167_14_head));
      let v170_14: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v171_11: Space = routine_29(c, &(*CONSTANT_12), &(*CONSTANT_13));
        let v171_12: Space = routine_29(c, &(*CONSTANT_14), &(*CONSTANT_15));
        let v171_13: Space = unite(&(v171_11),&(v171_12));
        compose(&(*CONSTANT_0),&(v171_13))
      };
      let v170_15: Space = unwrap(&(v170_14),&(*p1));
      let mut v170_16 = Space::new();
      let mut v170_16_cursor = (v170_15).read_zipper();
      for v170_16_byte in v170_16_cursor.child_mask().iter() {
        v170_16_cursor.descend_to_byte(v170_16_byte);
        let v170_16_tail = v170_16_cursor.make_map();
        v170_16_cursor.ascend(1);
        let v170_16_head = Path::from_slice(&[v170_16_byte]);
        let v172_2: Space = singleton(&(v170_16_head));
        let v172_3: Space = intersect(&(*CONSTANT_7),&(v172_2));
        let v172_4: Space = if has_head(&(v172_3)) { singleton(&[]) } else { Space::new() };
        drop(v172_3);
        let v172_5: Space = subtract(&(*CONSTANT_0),&(v172_4));
        drop(v172_4);
        let v172_7: Space = if (v172_5).is_empty() { Space::new() } else {
          let v173_6: Space = routine_30(c, &(v170_16_head), &(v170_6), &(v170_16_tail), &(v167_14_tail));
          compose(&(v172_5),&(v173_6))
        };
        drop(v172_5);
        let v172_8: Space = intersect(&(*CONSTANT_7),&(v172_2));
        drop(v172_2);
        let v172_9: Space = if has_head(&(v172_8)) { singleton(&[]) } else { Space::new() };
        drop(v172_8);
        let v172_11: Space = if (v172_9).is_empty() { Space::new() } else {
          let v174_10: Space = routine_31(c, &(v170_16_head), &(v170_6), &(v170_16_tail), &(v167_14_tail));
          compose(&(v172_9),&(v174_10))
        };
        drop(v172_9);
        let v172_12: Space = unite(&(v172_7),&(v172_11));
        v170_16.join_into((v172_12).clone());
      }
      drop(v170_16_cursor);
      drop(v170_6);
      compose(&(v168_10),&(v170_16))
    };
    drop(v168_10);
    let v168_18: Space = unite(&(v168_8),&(v168_17));
    v167_14.join_into((v168_18).clone());
  }
  drop(v167_14_cursor);
  (v167_14).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v175_21: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v176_20: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v177_7: Space = routine_29(c, &(*CONSTANT_1), &(*CONSTANT_16));
      let v177_10: Space = routine_29(c, &(*CONSTANT_3), &(*CONSTANT_17));
      let v177_11: Space = unite(&(v177_7),&(v177_10));
      let v177_14: Space = routine_29(c, &(*CONSTANT_4), &(*CONSTANT_18));
      let v177_15: Space = unite(&(v177_11),&(v177_14));
      let v177_18: Space = routine_29(c, &(*CONSTANT_6), &(*CONSTANT_19));
      let v177_19: Space = unite(&(v177_15),&(v177_18));
      compose(&(*CONSTANT_0),&(v177_19))
    };
    compose(&(*CONSTANT_0),&(v176_20))
  };
  let v175_22: Space = unwrap(&(v175_21),&(*p1));
  let mut v175_29 = Space::new();
  let mut v175_29_cursor = (v175_22).read_zipper();
  for v175_29_byte in v175_29_cursor.child_mask().iter() {
    v175_29_cursor.descend_to_byte(v175_29_byte);
    let v175_29_tail = v175_29_cursor.make_map();
    v175_29_cursor.ascend(1);
    let v175_29_head = Path::from_slice(&[v175_29_byte]);
    let v178_2: Space = singleton(&(v175_29_head));
    let v178_3: Space = intersect(&(*CONSTANT_7),&(v178_2));
    let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
    drop(v178_3);
    let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
    drop(v178_4);
    let v178_7: Space = if (v178_5).is_empty() { Space::new() } else {
      let mut v179_6 = Space::new();
      let mut v179_6_cursor = (v175_29_tail).read_zipper();
      for v179_6_byte in v179_6_cursor.child_mask().iter() {
        v179_6_cursor.descend_to_byte(v179_6_byte);
        let v179_6_tail = v179_6_cursor.make_map();
        v179_6_cursor.ascend(1);
        let v179_6_head = Path::from_slice(&[v179_6_byte]);
        let v180_2: Space = singleton(&(v179_6_head));
        let v180_3: Space = intersect(&(*CONSTANT_7),&(v180_2));
        let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
        drop(v180_3);
        let v180_5: Space = subtract(&(*CONSTANT_0),&(v180_4));
        drop(v180_4);
        let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v175_29_head),&(v179_6_head));
          let v181_7: Space = routine_30(c, &(v181_6), &(*p0), &(v179_6_tail), &(*s0));
          compose(&(v180_5),&(v181_7))
        };
        drop(v180_5);
        let v180_9: Space = intersect(&(*CONSTANT_7),&(v180_2));
        drop(v180_2);
        let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
        drop(v180_9);
        let v180_12: Space = if (v180_10).is_empty() { Space::new() } else {
          let v182_6: Path = concat_path(&(v175_29_head),&(v179_6_head));
          let v182_11: Space = routine_31(c, &(v182_6), &(*p0), &(v179_6_tail), &(*s0));
          drop(v182_6);
          compose(&(v180_10),&(v182_11))
        };
        drop(v180_10);
        let v180_13: Space = unite(&(v180_8),&(v180_12));
        v179_6.join_into((v180_13).clone());
      }
      drop(v179_6_cursor);
      compose(&(v178_5),&(v179_6))
    };
    drop(v178_5);
    let v178_8: Space = intersect(&(*CONSTANT_7),&(v178_2));
    drop(v178_2);
    let v178_9: Space = if has_head(&(v178_8)) { singleton(&[]) } else { Space::new() };
    drop(v178_8);
    let v178_13: Space = if (v178_9).is_empty() { Space::new() } else {
      let v183_10: Space = unwrap(&(v175_29_tail),&(*p0));
      let v183_11: Space = wrap(&(v183_10),&(v175_29_head));
      drop(v183_10);
      let v183_12: Space = compose(&(v183_11),&(*s0));
      drop(v183_11);
      compose(&(v178_9),&(v183_12))
    };
    drop(v178_9);
    let v178_14: Space = unite(&(v178_7),&(v178_13));
    drop(v178_13);
    v175_29.join_into((v178_14).clone());
  }
  drop(v175_29_cursor);
  (v175_29).clone()
}

fn routine_11(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v184_14 = Space::new();
  let mut v184_14_cursor = (*s0).read_zipper();
  for v184_14_byte in v184_14_cursor.child_mask().iter() {
    v184_14_cursor.descend_to_byte(v184_14_byte);
    let v184_14_tail = v184_14_cursor.make_map();
    v184_14_cursor.ascend(1);
    let v184_14_head = Path::from_slice(&[v184_14_byte]);
    let v185_2: Space = singleton(&(v184_14_head));
    let v185_3: Space = intersect(&(*CONSTANT_7),&(v185_2));
    let v185_4: Space = if has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
    drop(v185_3);
    let v185_5: Space = subtract(&(*CONSTANT_0),&(v185_4));
    drop(v185_4);
    let v185_8: Space = if (v185_5).is_empty() { Space::new() } else {
      let v186_6: Path = concat_path(&(*p0),&(v184_14_head));
      let v186_7: Space = routine_11(c, &(v186_6), &(*p1), &(v184_14_tail));
      drop(v186_6);
      compose(&(v185_5),&(v186_7))
    };
    drop(v185_5);
    let v185_9: Space = intersect(&(*CONSTANT_7),&(v185_2));
    drop(v185_2);
    let v185_10: Space = if has_head(&(v185_9)) { singleton(&[]) } else { Space::new() };
    drop(v185_9);
    let v185_20: Space = if (v185_10).is_empty() { Space::new() } else {
      let v187_14: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v188_11: Space = routine_32(c, &(*CONSTANT_12), &(*CONSTANT_13));
        let v188_12: Space = routine_32(c, &(*CONSTANT_14), &(*CONSTANT_15));
        let v188_13: Space = unite(&(v188_11),&(v188_12));
        compose(&(*CONSTANT_0),&(v188_13))
      };
      let v187_15: Space = unwrap(&(v187_14),&(*p1));
      let v187_16: Space = unwrap(&(v187_15),&(*p0));
      let v187_17: Space = unwrap(&(v187_16),&(v184_14_head));
      let v187_18: Space = unwrap(&(v187_17),&(*p1));
      let mut v187_19 = Space::new();
      let mut v187_19_cursor = (v187_18).read_zipper();
      for v187_19_byte in v187_19_cursor.child_mask().iter() {
        v187_19_cursor.descend_to_byte(v187_19_byte);
        let v187_19_tail = v187_19_cursor.make_map();
        v187_19_cursor.ascend(1);
        let v187_19_head = Path::from_slice(&[v187_19_byte]);
        let v189_2: Space = singleton(&(v187_19_head));
        let v189_3: Space = intersect(&(*CONSTANT_7),&(v189_2));
        let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
        drop(v189_3);
        let v189_5: Space = subtract(&(*CONSTANT_0),&(v189_4));
        drop(v189_4);
        let v189_7: Space = if (v189_5).is_empty() { Space::new() } else {
          let v190_6: Space = routine_33(c, &(v187_19_head), &(v187_19_tail), &(v184_14_tail));
          compose(&(v189_5),&(v190_6))
        };
        drop(v189_5);
        let v189_8: Space = intersect(&(*CONSTANT_7),&(v189_2));
        drop(v189_2);
        let v189_9: Space = if has_head(&(v189_8)) { singleton(&[]) } else { Space::new() };
        drop(v189_8);
        let v189_11: Space = if (v189_9).is_empty() { Space::new() } else {
          let v191_10: Space = routine_34(c, &(v187_19_head), &(v187_19_tail), &(v184_14_tail));
          compose(&(v189_9),&(v191_10))
        };
        drop(v189_9);
        let v189_12: Space = unite(&(v189_7),&(v189_11));
        v187_19.join_into((v189_12).clone());
      }
      drop(v187_19_cursor);
      compose(&(v185_10),&(v187_19))
    };
    drop(v185_10);
    let v185_21: Space = unite(&(v185_8),&(v185_20));
    v184_14.join_into((v185_21).clone());
  }
  drop(v184_14_cursor);
  (v184_14).clone()
}

fn routine_12(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v192_21: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v193_20: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v194_7: Space = routine_32(c, &(*CONSTANT_1), &(*CONSTANT_16));
      let v194_10: Space = routine_32(c, &(*CONSTANT_3), &(*CONSTANT_17));
      let v194_11: Space = unite(&(v194_7),&(v194_10));
      let v194_14: Space = routine_32(c, &(*CONSTANT_4), &(*CONSTANT_18));
      let v194_15: Space = unite(&(v194_11),&(v194_14));
      let v194_18: Space = routine_32(c, &(*CONSTANT_6), &(*CONSTANT_19));
      let v194_19: Space = unite(&(v194_15),&(v194_18));
      compose(&(*CONSTANT_0),&(v194_19))
    };
    compose(&(*CONSTANT_0),&(v193_20))
  };
  let v192_22: Space = unwrap(&(v192_21),&(*p1));
  let v192_23: Space = unwrap(&(v192_22),&(*p0));
  let v192_24: Space = unwrap(&(v192_23),&(*p1));
  let mut v192_31 = Space::new();
  let mut v192_31_cursor = (v192_24).read_zipper();
  for v192_31_byte in v192_31_cursor.child_mask().iter() {
    v192_31_cursor.descend_to_byte(v192_31_byte);
    let v192_31_tail = v192_31_cursor.make_map();
    v192_31_cursor.ascend(1);
    let v192_31_head = Path::from_slice(&[v192_31_byte]);
    let v195_2: Space = singleton(&(v192_31_head));
    let v195_3: Space = intersect(&(*CONSTANT_7),&(v195_2));
    let v195_4: Space = if has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
    drop(v195_3);
    let v195_5: Space = subtract(&(*CONSTANT_0),&(v195_4));
    drop(v195_4);
    let v195_7: Space = if (v195_5).is_empty() { Space::new() } else {
      let mut v196_6 = Space::new();
      let mut v196_6_cursor = (v192_31_tail).read_zipper();
      for v196_6_byte in v196_6_cursor.child_mask().iter() {
        v196_6_cursor.descend_to_byte(v196_6_byte);
        let v196_6_tail = v196_6_cursor.make_map();
        v196_6_cursor.ascend(1);
        let v196_6_head = Path::from_slice(&[v196_6_byte]);
        let v197_2: Space = singleton(&(v196_6_head));
        let v197_3: Space = intersect(&(*CONSTANT_7),&(v197_2));
        let v197_4: Space = if has_head(&(v197_3)) { singleton(&[]) } else { Space::new() };
        drop(v197_3);
        let v197_5: Space = subtract(&(*CONSTANT_0),&(v197_4));
        drop(v197_4);
        let v197_8: Space = if (v197_5).is_empty() { Space::new() } else {
          let v198_6: Path = concat_path(&(v192_31_head),&(v196_6_head));
          let v198_7: Space = routine_33(c, &(v198_6), &(v196_6_tail), &(*s0));
          compose(&(v197_5),&(v198_7))
        };
        drop(v197_5);
        let v197_9: Space = intersect(&(*CONSTANT_7),&(v197_2));
        drop(v197_2);
        let v197_10: Space = if has_head(&(v197_9)) { singleton(&[]) } else { Space::new() };
        drop(v197_9);
        let v197_12: Space = if (v197_10).is_empty() { Space::new() } else {
          let v199_6: Path = concat_path(&(v192_31_head),&(v196_6_head));
          let v199_11: Space = routine_34(c, &(v199_6), &(v196_6_tail), &(*s0));
          drop(v199_6);
          compose(&(v197_10),&(v199_11))
        };
        drop(v197_10);
        let v197_13: Space = unite(&(v197_8),&(v197_12));
        v196_6.join_into((v197_13).clone());
      }
      drop(v196_6_cursor);
      compose(&(v195_5),&(v196_6))
    };
    drop(v195_5);
    let v195_8: Space = intersect(&(*CONSTANT_7),&(v195_2));
    drop(v195_2);
    let v195_9: Space = if has_head(&(v195_8)) { singleton(&[]) } else { Space::new() };
    drop(v195_8);
    let v195_11: Space = if (v195_9).is_empty() { Space::new() } else {
      let v200_10: Space = routine_43(c, &(v192_31_head), &(*s0));
      compose(&(v195_9),&(v200_10))
    };
    drop(v195_9);
    let v195_12: Space = unite(&(v195_7),&(v195_11));
    v192_31.join_into((v195_12).clone());
  }
  drop(v192_31_cursor);
  (v192_31).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v201_5 = Space::new();
  let mut v201_5_cursor = (*s0).read_zipper();
  for v201_5_byte in v201_5_cursor.child_mask().iter() {
    v201_5_cursor.descend_to_byte(v201_5_byte);
    let v201_5_tail = v201_5_cursor.make_map();
    v201_5_cursor.ascend(1);
    let v201_5_head = Path::from_slice(&[v201_5_byte]);
    let v202_2: Space = singleton(&(v201_5_head));
    let v202_3: Space = intersect(&(*CONSTANT_7),&(v202_2));
    let v202_4: Space = if has_head(&(v202_3)) { singleton(&[]) } else { Space::new() };
    drop(v202_3);
    let v202_5: Space = subtract(&(*CONSTANT_0),&(v202_4));
    drop(v202_4);
    let v202_8: Space = if (v202_5).is_empty() { Space::new() } else {
      let v203_6: Path = concat_path(&(*p0),&(v201_5_head));
      let v203_7: Space = routine_13(c, &(v203_6), &(v201_5_tail));
      drop(v203_6);
      compose(&(v202_5),&(v203_7))
    };
    drop(v202_5);
    let v202_9: Space = intersect(&(*CONSTANT_7),&(v202_2));
    drop(v202_2);
    let v202_10: Space = if has_head(&(v202_9)) { singleton(&[]) } else { Space::new() };
    drop(v202_9);
    let v202_11: Space = compose(&(v202_10),&(v201_5_tail));
    drop(v202_10);
    let v202_12: Space = unite(&(v202_8),&(v202_11));
    drop(v202_11);
    v201_5.join_into((v202_12).clone());
  }
  drop(v201_5_cursor);
  (v201_5).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v205_8 = Space::new();
  let mut v205_8_cursor = (*s0).read_zipper();
  for v205_8_byte in v205_8_cursor.child_mask().iter() {
    v205_8_cursor.descend_to_byte(v205_8_byte);
    let v205_8_tail = v205_8_cursor.make_map();
    v205_8_cursor.ascend(1);
    let v205_8_head = Path::from_slice(&[v205_8_byte]);
    let v206_2: Space = singleton(&(v205_8_head));
    let v206_3: Space = intersect(&(*CONSTANT_7),&(v206_2));
    let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
    drop(v206_3);
    let v206_5: Space = subtract(&(*CONSTANT_0),&(v206_4));
    drop(v206_4);
    let v206_8: Space = if (v206_5).is_empty() { Space::new() } else {
      let v207_6: Path = concat_path(&(*p0),&(v205_8_head));
      let v207_7: Space = routine_15(c, &(v207_6), &(v205_8_tail));
      compose(&(v206_5),&(v207_7))
    };
    drop(v206_5);
    let v206_9: Space = intersect(&(*CONSTANT_7),&(v206_2));
    drop(v206_2);
    let v206_10: Space = if has_head(&(v206_9)) { singleton(&[]) } else { Space::new() };
    drop(v206_9);
    let v206_12: Space = if (v206_10).is_empty() { Space::new() } else {
      let v208_6: Path = concat_path(&(*p0),&(v205_8_head));
      let mut v208_11 = Space::new();
      let mut v208_11_cursor = (v205_8_tail).read_zipper();
      for v208_11_byte in v208_11_cursor.child_mask().iter() {
        v208_11_cursor.descend_to_byte(v208_11_byte);
        let v208_11_tail = v208_11_cursor.make_map();
        v208_11_cursor.ascend(1);
        let v208_11_head = Path::from_slice(&[v208_11_byte]);
        let v209_2: Space = singleton(&(v208_11_head));
        let v209_3: Space = intersect(&(*CONSTANT_7),&(v209_2));
        let v209_4: Space = if has_head(&(v209_3)) { singleton(&[]) } else { Space::new() };
        drop(v209_3);
        let v209_5: Space = subtract(&(*CONSTANT_0),&(v209_4));
        drop(v209_4);
        let v209_7: Space = if (v209_5).is_empty() { Space::new() } else {
          let v210_6: Space = routine_35(c, &(v208_11_head), &(v208_6), &(v208_11_tail));
          compose(&(v209_5),&(v210_6))
        };
        drop(v209_5);
        let v209_8: Space = intersect(&(*CONSTANT_7),&(v209_2));
        drop(v209_2);
        let v209_9: Space = if has_head(&(v209_8)) { singleton(&[]) } else { Space::new() };
        drop(v209_8);
        let v209_11: Space = if (v209_9).is_empty() { Space::new() } else {
          let v211_10: Space = routine_36(c, &(v208_11_head), &(v208_6), &(v208_11_tail));
          compose(&(v209_9),&(v211_10))
        };
        drop(v209_9);
        let v209_12: Space = unite(&(v209_7),&(v209_11));
        v208_11.join_into((v209_12).clone());
      }
      drop(v208_11_cursor);
      drop(v208_6);
      compose(&(v206_10),&(v208_11))
    };
    drop(v206_10);
    let v206_13: Space = unite(&(v206_8),&(v206_12));
    v205_8.join_into((v206_13).clone());
  }
  drop(v205_8_cursor);
  (v205_8).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v212_11 = Space::new();
  let mut v212_11_cursor = (*s0).read_zipper();
  for v212_11_byte in v212_11_cursor.child_mask().iter() {
    v212_11_cursor.descend_to_byte(v212_11_byte);
    let v212_11_tail = v212_11_cursor.make_map();
    v212_11_cursor.ascend(1);
    let v212_11_head = Path::from_slice(&[v212_11_byte]);
    let v213_2: Space = singleton(&(v212_11_head));
    let v213_3: Space = intersect(&(*CONSTANT_7),&(v213_2));
    let v213_4: Space = if has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
    drop(v213_3);
    let v213_5: Space = subtract(&(*CONSTANT_0),&(v213_4));
    drop(v213_4);
    let v213_7: Space = if (v213_5).is_empty() { Space::new() } else {
      let mut v214_6 = Space::new();
      let mut v214_6_cursor = (v212_11_tail).read_zipper();
      for v214_6_byte in v214_6_cursor.child_mask().iter() {
        v214_6_cursor.descend_to_byte(v214_6_byte);
        let v214_6_tail = v214_6_cursor.make_map();
        v214_6_cursor.ascend(1);
        let v214_6_head = Path::from_slice(&[v214_6_byte]);
        let v215_2: Space = singleton(&(v214_6_head));
        let v215_3: Space = intersect(&(*CONSTANT_7),&(v215_2));
        let v215_4: Space = if has_head(&(v215_3)) { singleton(&[]) } else { Space::new() };
        drop(v215_3);
        let v215_5: Space = subtract(&(*CONSTANT_0),&(v215_4));
        drop(v215_4);
        let v215_8: Space = if (v215_5).is_empty() { Space::new() } else {
          let v216_6: Path = concat_path(&(v212_11_head),&(v214_6_head));
          let v216_7: Space = routine_35(c, &(v216_6), &(*p0), &(v214_6_tail));
          compose(&(v215_5),&(v216_7))
        };
        drop(v215_5);
        let v215_9: Space = intersect(&(*CONSTANT_7),&(v215_2));
        drop(v215_2);
        let v215_10: Space = if has_head(&(v215_9)) { singleton(&[]) } else { Space::new() };
        drop(v215_9);
        let v215_12: Space = if (v215_10).is_empty() { Space::new() } else {
          let v217_6: Path = concat_path(&(v212_11_head),&(v214_6_head));
          let v217_11: Space = routine_36(c, &(v217_6), &(*p0), &(v214_6_tail));
          drop(v217_6);
          compose(&(v215_10),&(v217_11))
        };
        drop(v215_10);
        let v215_13: Space = unite(&(v215_8),&(v215_12));
        v214_6.join_into((v215_13).clone());
      }
      drop(v214_6_cursor);
      compose(&(v213_5),&(v214_6))
    };
    drop(v213_5);
    let v213_8: Space = intersect(&(*CONSTANT_7),&(v213_2));
    drop(v213_2);
    let v213_9: Space = if has_head(&(v213_8)) { singleton(&[]) } else { Space::new() };
    drop(v213_8);
    let v213_11: Space = if (v213_9).is_empty() { Space::new() } else {
      let mut v218_10 = Space::new();
      let mut v218_10_cursor = (v212_11_tail).read_zipper();
      for v218_10_byte in v218_10_cursor.child_mask().iter() {
        v218_10_cursor.descend_to_byte(v218_10_byte);
        let v218_10_tail = v218_10_cursor.make_map();
        v218_10_cursor.ascend(1);
        let v218_10_head = Path::from_slice(&[v218_10_byte]);
        let v219_2: Space = singleton(&(v218_10_head));
        let v219_3: Space = intersect(&(*CONSTANT_7),&(v219_2));
        let v219_4: Space = if has_head(&(v219_3)) { singleton(&[]) } else { Space::new() };
        drop(v219_3);
        let v219_5: Space = subtract(&(*CONSTANT_0),&(v219_4));
        drop(v219_4);
        let v219_7: Space = if (v219_5).is_empty() { Space::new() } else {
          let v220_6: Space = routine_44(c, &(v218_10_head), &(*p0), &(v212_11_head), &(v218_10_tail));
          compose(&(v219_5),&(v220_6))
        };
        drop(v219_5);
        let v219_8: Space = intersect(&(*CONSTANT_7),&(v219_2));
        drop(v219_2);
        let v219_9: Space = if has_head(&(v219_8)) { singleton(&[]) } else { Space::new() };
        drop(v219_8);
        let v219_11: Space = if (v219_9).is_empty() { Space::new() } else {
          let v221_10: Space = routine_45(c, &(v218_10_head), &(*p0), &(v212_11_head), &(v218_10_tail));
          compose(&(v219_9),&(v221_10))
        };
        drop(v219_9);
        let v219_12: Space = unite(&(v219_7),&(v219_11));
        v218_10.join_into((v219_12).clone());
      }
      drop(v218_10_cursor);
      compose(&(v213_9),&(v218_10))
    };
    drop(v213_9);
    let v213_12: Space = unite(&(v213_7),&(v213_11));
    v212_11.join_into((v213_12).clone());
  }
  drop(v212_11_cursor);
  (v212_11).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v222_5 = Space::new();
  let mut v222_5_cursor = (*s0).read_zipper();
  for v222_5_byte in v222_5_cursor.child_mask().iter() {
    v222_5_cursor.descend_to_byte(v222_5_byte);
    let v222_5_tail = v222_5_cursor.make_map();
    v222_5_cursor.ascend(1);
    let v222_5_head = Path::from_slice(&[v222_5_byte]);
    let v223_2: Space = singleton(&(v222_5_head));
    let v223_3: Space = intersect(&(*CONSTANT_7),&(v223_2));
    let v223_4: Space = if has_head(&(v223_3)) { singleton(&[]) } else { Space::new() };
    drop(v223_3);
    let v223_5: Space = subtract(&(*CONSTANT_0),&(v223_4));
    drop(v223_4);
    let v223_8: Space = if (v223_5).is_empty() { Space::new() } else {
      let v224_6: Path = concat_path(&(*p0),&(v222_5_head));
      let v224_7: Space = routine_17(c, &(v224_6), &(v222_5_tail));
      drop(v224_6);
      compose(&(v223_5),&(v224_7))
    };
    drop(v223_5);
    let v223_9: Space = intersect(&(*CONSTANT_7),&(v223_2));
    drop(v223_2);
    let v223_10: Space = if has_head(&(v223_9)) { singleton(&[]) } else { Space::new() };
    drop(v223_9);
    let v223_11: Space = compose(&(v223_10),&(v222_5_tail));
    drop(v223_10);
    let v223_12: Space = unite(&(v223_8),&(v223_11));
    drop(v223_11);
    v222_5.join_into((v223_12).clone());
  }
  drop(v222_5_cursor);
  (v222_5).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v226_8 = Space::new();
  let mut v226_8_cursor = (*s0).read_zipper();
  for v226_8_byte in v226_8_cursor.child_mask().iter() {
    v226_8_cursor.descend_to_byte(v226_8_byte);
    let v226_8_tail = v226_8_cursor.make_map();
    v226_8_cursor.ascend(1);
    let v226_8_head = Path::from_slice(&[v226_8_byte]);
    let v227_2: Space = singleton(&(v226_8_head));
    let v227_3: Space = intersect(&(*CONSTANT_7),&(v227_2));
    let v227_4: Space = if has_head(&(v227_3)) { singleton(&[]) } else { Space::new() };
    drop(v227_3);
    let v227_5: Space = subtract(&(*CONSTANT_0),&(v227_4));
    drop(v227_4);
    let v227_8: Space = if (v227_5).is_empty() { Space::new() } else {
      let v228_6: Path = concat_path(&(*p0),&(v226_8_head));
      let v228_7: Space = routine_19(c, &(v228_6), &(v226_8_tail));
      compose(&(v227_5),&(v228_7))
    };
    drop(v227_5);
    let v227_9: Space = intersect(&(*CONSTANT_7),&(v227_2));
    drop(v227_2);
    let v227_10: Space = if has_head(&(v227_9)) { singleton(&[]) } else { Space::new() };
    drop(v227_9);
    let v227_12: Space = if (v227_10).is_empty() { Space::new() } else {
      let v229_6: Path = concat_path(&(*p0),&(v226_8_head));
      let mut v229_11 = Space::new();
      let mut v229_11_cursor = (v226_8_tail).read_zipper();
      for v229_11_byte in v229_11_cursor.child_mask().iter() {
        v229_11_cursor.descend_to_byte(v229_11_byte);
        let v229_11_tail = v229_11_cursor.make_map();
        v229_11_cursor.ascend(1);
        let v229_11_head = Path::from_slice(&[v229_11_byte]);
        let v230_2: Space = singleton(&(v229_11_head));
        let v230_3: Space = intersect(&(*CONSTANT_7),&(v230_2));
        let v230_4: Space = if has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
        drop(v230_3);
        let v230_5: Space = subtract(&(*CONSTANT_0),&(v230_4));
        drop(v230_4);
        let v230_7: Space = if (v230_5).is_empty() { Space::new() } else {
          let v231_6: Space = routine_37(c, &(v229_11_head), &(v229_6), &(v229_11_tail));
          compose(&(v230_5),&(v231_6))
        };
        drop(v230_5);
        let v230_8: Space = intersect(&(*CONSTANT_7),&(v230_2));
        drop(v230_2);
        let v230_9: Space = if has_head(&(v230_8)) { singleton(&[]) } else { Space::new() };
        drop(v230_8);
        let v230_11: Space = if (v230_9).is_empty() { Space::new() } else {
          let v232_10: Space = routine_38(c, &(v229_11_head), &(v229_6), &(v229_11_tail));
          compose(&(v230_9),&(v232_10))
        };
        drop(v230_9);
        let v230_12: Space = unite(&(v230_7),&(v230_11));
        v229_11.join_into((v230_12).clone());
      }
      drop(v229_11_cursor);
      drop(v229_6);
      compose(&(v227_10),&(v229_11))
    };
    drop(v227_10);
    let v227_13: Space = unite(&(v227_8),&(v227_12));
    v226_8.join_into((v227_13).clone());
  }
  drop(v226_8_cursor);
  (v226_8).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v233_11 = Space::new();
  let mut v233_11_cursor = (*s0).read_zipper();
  for v233_11_byte in v233_11_cursor.child_mask().iter() {
    v233_11_cursor.descend_to_byte(v233_11_byte);
    let v233_11_tail = v233_11_cursor.make_map();
    v233_11_cursor.ascend(1);
    let v233_11_head = Path::from_slice(&[v233_11_byte]);
    let v234_2: Space = singleton(&(v233_11_head));
    let v234_3: Space = intersect(&(*CONSTANT_7),&(v234_2));
    let v234_4: Space = if has_head(&(v234_3)) { singleton(&[]) } else { Space::new() };
    drop(v234_3);
    let v234_5: Space = subtract(&(*CONSTANT_0),&(v234_4));
    drop(v234_4);
    let v234_7: Space = if (v234_5).is_empty() { Space::new() } else {
      let mut v235_6 = Space::new();
      let mut v235_6_cursor = (v233_11_tail).read_zipper();
      for v235_6_byte in v235_6_cursor.child_mask().iter() {
        v235_6_cursor.descend_to_byte(v235_6_byte);
        let v235_6_tail = v235_6_cursor.make_map();
        v235_6_cursor.ascend(1);
        let v235_6_head = Path::from_slice(&[v235_6_byte]);
        let v236_2: Space = singleton(&(v235_6_head));
        let v236_3: Space = intersect(&(*CONSTANT_7),&(v236_2));
        let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
        drop(v236_3);
        let v236_5: Space = subtract(&(*CONSTANT_0),&(v236_4));
        drop(v236_4);
        let v236_8: Space = if (v236_5).is_empty() { Space::new() } else {
          let v237_6: Path = concat_path(&(v233_11_head),&(v235_6_head));
          let v237_7: Space = routine_37(c, &(v237_6), &(*p0), &(v235_6_tail));
          compose(&(v236_5),&(v237_7))
        };
        drop(v236_5);
        let v236_9: Space = intersect(&(*CONSTANT_7),&(v236_2));
        drop(v236_2);
        let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
        drop(v236_9);
        let v236_12: Space = if (v236_10).is_empty() { Space::new() } else {
          let v238_6: Path = concat_path(&(v233_11_head),&(v235_6_head));
          let v238_11: Space = routine_38(c, &(v238_6), &(*p0), &(v235_6_tail));
          drop(v238_6);
          compose(&(v236_10),&(v238_11))
        };
        drop(v236_10);
        let v236_13: Space = unite(&(v236_8),&(v236_12));
        v235_6.join_into((v236_13).clone());
      }
      drop(v235_6_cursor);
      compose(&(v234_5),&(v235_6))
    };
    drop(v234_5);
    let v234_8: Space = intersect(&(*CONSTANT_7),&(v234_2));
    drop(v234_2);
    let v234_9: Space = if has_head(&(v234_8)) { singleton(&[]) } else { Space::new() };
    drop(v234_8);
    let v234_11: Space = if (v234_9).is_empty() { Space::new() } else {
      let mut v239_10 = Space::new();
      let mut v239_10_cursor = (v233_11_tail).read_zipper();
      for v239_10_byte in v239_10_cursor.child_mask().iter() {
        v239_10_cursor.descend_to_byte(v239_10_byte);
        let v239_10_tail = v239_10_cursor.make_map();
        v239_10_cursor.ascend(1);
        let v239_10_head = Path::from_slice(&[v239_10_byte]);
        let v240_2: Space = singleton(&(v239_10_head));
        let v240_3: Space = intersect(&(*CONSTANT_7),&(v240_2));
        let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
        drop(v240_3);
        let v240_5: Space = subtract(&(*CONSTANT_0),&(v240_4));
        drop(v240_4);
        let v240_7: Space = if (v240_5).is_empty() { Space::new() } else {
          let v241_6: Space = routine_46(c, &(v239_10_head), &(*p0), &(v233_11_head), &(v239_10_tail));
          compose(&(v240_5),&(v241_6))
        };
        drop(v240_5);
        let v240_8: Space = intersect(&(*CONSTANT_7),&(v240_2));
        drop(v240_2);
        let v240_9: Space = if has_head(&(v240_8)) { singleton(&[]) } else { Space::new() };
        drop(v240_8);
        let v240_11: Space = if (v240_9).is_empty() { Space::new() } else {
          let v242_10: Space = routine_47(c, &(v239_10_head), &(*p0), &(v233_11_head), &(v239_10_tail));
          compose(&(v240_9),&(v242_10))
        };
        drop(v240_9);
        let v240_12: Space = unite(&(v240_7),&(v240_11));
        v239_10.join_into((v240_12).clone());
      }
      drop(v239_10_cursor);
      compose(&(v234_9),&(v239_10))
    };
    drop(v234_9);
    let v234_12: Space = unite(&(v234_7),&(v234_11));
    v233_11.join_into((v234_12).clone());
  }
  drop(v233_11_cursor);
  (v233_11).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v243_5 = Space::new();
  let mut v243_5_cursor = (*s0).read_zipper();
  for v243_5_byte in v243_5_cursor.child_mask().iter() {
    v243_5_cursor.descend_to_byte(v243_5_byte);
    let v243_5_tail = v243_5_cursor.make_map();
    v243_5_cursor.ascend(1);
    let v243_5_head = Path::from_slice(&[v243_5_byte]);
    let v244_2: Space = singleton(&(v243_5_head));
    let v244_3: Space = intersect(&(*CONSTANT_7),&(v244_2));
    let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
    drop(v244_3);
    let v244_5: Space = subtract(&(*CONSTANT_0),&(v244_4));
    drop(v244_4);
    let v244_8: Space = if (v244_5).is_empty() { Space::new() } else {
      let v245_6: Path = concat_path(&(*p0),&(v243_5_head));
      let v245_7: Space = routine_21(c, &(v245_6), &(v243_5_tail));
      drop(v245_6);
      compose(&(v244_5),&(v245_7))
    };
    drop(v244_5);
    let v244_9: Space = intersect(&(*CONSTANT_7),&(v244_2));
    drop(v244_2);
    let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
    drop(v244_9);
    let v244_11: Space = compose(&(v244_10),&(v243_5_tail));
    drop(v244_10);
    let v244_12: Space = unite(&(v244_8),&(v244_11));
    drop(v244_11);
    v243_5.join_into((v244_12).clone());
  }
  drop(v243_5_cursor);
  (v243_5).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v247_8 = Space::new();
  let mut v247_8_cursor = (*s0).read_zipper();
  for v247_8_byte in v247_8_cursor.child_mask().iter() {
    v247_8_cursor.descend_to_byte(v247_8_byte);
    let v247_8_tail = v247_8_cursor.make_map();
    v247_8_cursor.ascend(1);
    let v247_8_head = Path::from_slice(&[v247_8_byte]);
    let v248_2: Space = singleton(&(v247_8_head));
    let v248_3: Space = intersect(&(*CONSTANT_7),&(v248_2));
    let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
    drop(v248_3);
    let v248_5: Space = subtract(&(*CONSTANT_0),&(v248_4));
    drop(v248_4);
    let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
      let v249_6: Path = concat_path(&(*p0),&(v247_8_head));
      let v249_7: Space = routine_23(c, &(v249_6), &(v247_8_tail));
      compose(&(v248_5),&(v249_7))
    };
    drop(v248_5);
    let v248_9: Space = intersect(&(*CONSTANT_7),&(v248_2));
    drop(v248_2);
    let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
    drop(v248_9);
    let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
      let v250_6: Path = concat_path(&(*p0),&(v247_8_head));
      let mut v250_11 = Space::new();
      let mut v250_11_cursor = (v247_8_tail).read_zipper();
      for v250_11_byte in v250_11_cursor.child_mask().iter() {
        v250_11_cursor.descend_to_byte(v250_11_byte);
        let v250_11_tail = v250_11_cursor.make_map();
        v250_11_cursor.ascend(1);
        let v250_11_head = Path::from_slice(&[v250_11_byte]);
        let v251_2: Space = singleton(&(v250_11_head));
        let v251_3: Space = intersect(&(*CONSTANT_7),&(v251_2));
        let v251_4: Space = if has_head(&(v251_3)) { singleton(&[]) } else { Space::new() };
        drop(v251_3);
        let v251_5: Space = subtract(&(*CONSTANT_0),&(v251_4));
        drop(v251_4);
        let v251_7: Space = if (v251_5).is_empty() { Space::new() } else {
          let v252_6: Space = routine_39(c, &(v250_11_head), &(v250_6), &(v250_11_tail));
          compose(&(v251_5),&(v252_6))
        };
        drop(v251_5);
        let v251_8: Space = intersect(&(*CONSTANT_7),&(v251_2));
        drop(v251_2);
        let v251_9: Space = if has_head(&(v251_8)) { singleton(&[]) } else { Space::new() };
        drop(v251_8);
        let v251_11: Space = if (v251_9).is_empty() { Space::new() } else {
          let v253_10: Space = routine_40(c, &(v250_11_head), &(v250_6), &(v250_11_tail));
          compose(&(v251_9),&(v253_10))
        };
        drop(v251_9);
        let v251_12: Space = unite(&(v251_7),&(v251_11));
        v250_11.join_into((v251_12).clone());
      }
      drop(v250_11_cursor);
      drop(v250_6);
      compose(&(v248_10),&(v250_11))
    };
    drop(v248_10);
    let v248_13: Space = unite(&(v248_8),&(v248_12));
    v247_8.join_into((v248_13).clone());
  }
  drop(v247_8_cursor);
  (v247_8).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v254_11 = Space::new();
  let mut v254_11_cursor = (*s0).read_zipper();
  for v254_11_byte in v254_11_cursor.child_mask().iter() {
    v254_11_cursor.descend_to_byte(v254_11_byte);
    let v254_11_tail = v254_11_cursor.make_map();
    v254_11_cursor.ascend(1);
    let v254_11_head = Path::from_slice(&[v254_11_byte]);
    let v255_2: Space = singleton(&(v254_11_head));
    let v255_3: Space = intersect(&(*CONSTANT_7),&(v255_2));
    let v255_4: Space = if has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
    drop(v255_3);
    let v255_5: Space = subtract(&(*CONSTANT_0),&(v255_4));
    drop(v255_4);
    let v255_7: Space = if (v255_5).is_empty() { Space::new() } else {
      let mut v256_6 = Space::new();
      let mut v256_6_cursor = (v254_11_tail).read_zipper();
      for v256_6_byte in v256_6_cursor.child_mask().iter() {
        v256_6_cursor.descend_to_byte(v256_6_byte);
        let v256_6_tail = v256_6_cursor.make_map();
        v256_6_cursor.ascend(1);
        let v256_6_head = Path::from_slice(&[v256_6_byte]);
        let v257_2: Space = singleton(&(v256_6_head));
        let v257_3: Space = intersect(&(*CONSTANT_7),&(v257_2));
        let v257_4: Space = if has_head(&(v257_3)) { singleton(&[]) } else { Space::new() };
        drop(v257_3);
        let v257_5: Space = subtract(&(*CONSTANT_0),&(v257_4));
        drop(v257_4);
        let v257_8: Space = if (v257_5).is_empty() { Space::new() } else {
          let v258_6: Path = concat_path(&(v254_11_head),&(v256_6_head));
          let v258_7: Space = routine_39(c, &(v258_6), &(*p0), &(v256_6_tail));
          compose(&(v257_5),&(v258_7))
        };
        drop(v257_5);
        let v257_9: Space = intersect(&(*CONSTANT_7),&(v257_2));
        drop(v257_2);
        let v257_10: Space = if has_head(&(v257_9)) { singleton(&[]) } else { Space::new() };
        drop(v257_9);
        let v257_12: Space = if (v257_10).is_empty() { Space::new() } else {
          let v259_6: Path = concat_path(&(v254_11_head),&(v256_6_head));
          let v259_11: Space = routine_40(c, &(v259_6), &(*p0), &(v256_6_tail));
          drop(v259_6);
          compose(&(v257_10),&(v259_11))
        };
        drop(v257_10);
        let v257_13: Space = unite(&(v257_8),&(v257_12));
        v256_6.join_into((v257_13).clone());
      }
      drop(v256_6_cursor);
      compose(&(v255_5),&(v256_6))
    };
    drop(v255_5);
    let v255_8: Space = intersect(&(*CONSTANT_7),&(v255_2));
    drop(v255_2);
    let v255_9: Space = if has_head(&(v255_8)) { singleton(&[]) } else { Space::new() };
    drop(v255_8);
    let v255_11: Space = if (v255_9).is_empty() { Space::new() } else {
      let mut v260_10 = Space::new();
      let mut v260_10_cursor = (v254_11_tail).read_zipper();
      for v260_10_byte in v260_10_cursor.child_mask().iter() {
        v260_10_cursor.descend_to_byte(v260_10_byte);
        let v260_10_tail = v260_10_cursor.make_map();
        v260_10_cursor.ascend(1);
        let v260_10_head = Path::from_slice(&[v260_10_byte]);
        let v261_2: Space = singleton(&(v260_10_head));
        let v261_3: Space = intersect(&(*CONSTANT_7),&(v261_2));
        let v261_4: Space = if has_head(&(v261_3)) { singleton(&[]) } else { Space::new() };
        drop(v261_3);
        let v261_5: Space = subtract(&(*CONSTANT_0),&(v261_4));
        drop(v261_4);
        let v261_7: Space = if (v261_5).is_empty() { Space::new() } else {
          let v262_6: Space = routine_48(c, &(v260_10_head), &(*p0), &(v254_11_head), &(v260_10_tail));
          compose(&(v261_5),&(v262_6))
        };
        drop(v261_5);
        let v261_8: Space = intersect(&(*CONSTANT_7),&(v261_2));
        drop(v261_2);
        let v261_9: Space = if has_head(&(v261_8)) { singleton(&[]) } else { Space::new() };
        drop(v261_8);
        let v261_11: Space = if (v261_9).is_empty() { Space::new() } else {
          let v263_10: Space = routine_49(c, &(v260_10_head), &(*p0), &(v254_11_head), &(v260_10_tail));
          compose(&(v261_9),&(v263_10))
        };
        drop(v261_9);
        let v261_12: Space = unite(&(v261_7),&(v261_11));
        v260_10.join_into((v261_12).clone());
      }
      drop(v260_10_cursor);
      compose(&(v255_9),&(v260_10))
    };
    drop(v255_9);
    let v255_12: Space = unite(&(v255_7),&(v255_11));
    v254_11.join_into((v255_12).clone());
  }
  drop(v254_11_cursor);
  (v254_11).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v264_5 = Space::new();
  let mut v264_5_cursor = (*s0).read_zipper();
  for v264_5_byte in v264_5_cursor.child_mask().iter() {
    v264_5_cursor.descend_to_byte(v264_5_byte);
    let v264_5_tail = v264_5_cursor.make_map();
    v264_5_cursor.ascend(1);
    let v264_5_head = Path::from_slice(&[v264_5_byte]);
    let v265_2: Space = singleton(&(v264_5_head));
    let v265_3: Space = intersect(&(*CONSTANT_7),&(v265_2));
    let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
    drop(v265_3);
    let v265_5: Space = subtract(&(*CONSTANT_0),&(v265_4));
    drop(v265_4);
    let v265_8: Space = if (v265_5).is_empty() { Space::new() } else {
      let v266_6: Path = concat_path(&(*p0),&(v264_5_head));
      let v266_7: Space = routine_25(c, &(v266_6), &(v264_5_tail));
      drop(v266_6);
      compose(&(v265_5),&(v266_7))
    };
    drop(v265_5);
    let v265_9: Space = intersect(&(*CONSTANT_7),&(v265_2));
    drop(v265_2);
    let v265_10: Space = if has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
    drop(v265_9);
    let v265_11: Space = compose(&(v265_10),&(v264_5_tail));
    drop(v265_10);
    let v265_12: Space = unite(&(v265_8),&(v265_11));
    drop(v265_11);
    v264_5.join_into((v265_12).clone());
  }
  drop(v264_5_cursor);
  (v264_5).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v268_8 = Space::new();
  let mut v268_8_cursor = (*s0).read_zipper();
  for v268_8_byte in v268_8_cursor.child_mask().iter() {
    v268_8_cursor.descend_to_byte(v268_8_byte);
    let v268_8_tail = v268_8_cursor.make_map();
    v268_8_cursor.ascend(1);
    let v268_8_head = Path::from_slice(&[v268_8_byte]);
    let v269_2: Space = singleton(&(v268_8_head));
    let v269_3: Space = intersect(&(*CONSTANT_7),&(v269_2));
    let v269_4: Space = if has_head(&(v269_3)) { singleton(&[]) } else { Space::new() };
    drop(v269_3);
    let v269_5: Space = subtract(&(*CONSTANT_0),&(v269_4));
    drop(v269_4);
    let v269_8: Space = if (v269_5).is_empty() { Space::new() } else {
      let v270_6: Path = concat_path(&(*p0),&(v268_8_head));
      let v270_7: Space = routine_27(c, &(v270_6), &(v268_8_tail));
      compose(&(v269_5),&(v270_7))
    };
    drop(v269_5);
    let v269_9: Space = intersect(&(*CONSTANT_7),&(v269_2));
    drop(v269_2);
    let v269_10: Space = if has_head(&(v269_9)) { singleton(&[]) } else { Space::new() };
    drop(v269_9);
    let v269_12: Space = if (v269_10).is_empty() { Space::new() } else {
      let v271_6: Path = concat_path(&(*p0),&(v268_8_head));
      let mut v271_11 = Space::new();
      let mut v271_11_cursor = (v268_8_tail).read_zipper();
      for v271_11_byte in v271_11_cursor.child_mask().iter() {
        v271_11_cursor.descend_to_byte(v271_11_byte);
        let v271_11_tail = v271_11_cursor.make_map();
        v271_11_cursor.ascend(1);
        let v271_11_head = Path::from_slice(&[v271_11_byte]);
        let v272_2: Space = singleton(&(v271_11_head));
        let v272_3: Space = intersect(&(*CONSTANT_7),&(v272_2));
        let v272_4: Space = if has_head(&(v272_3)) { singleton(&[]) } else { Space::new() };
        drop(v272_3);
        let v272_5: Space = subtract(&(*CONSTANT_0),&(v272_4));
        drop(v272_4);
        let v272_7: Space = if (v272_5).is_empty() { Space::new() } else {
          let v273_6: Space = routine_41(c, &(v271_11_head), &(v271_6), &(v271_11_tail));
          compose(&(v272_5),&(v273_6))
        };
        drop(v272_5);
        let v272_8: Space = intersect(&(*CONSTANT_7),&(v272_2));
        drop(v272_2);
        let v272_9: Space = if has_head(&(v272_8)) { singleton(&[]) } else { Space::new() };
        drop(v272_8);
        let v272_11: Space = if (v272_9).is_empty() { Space::new() } else {
          let v274_10: Space = routine_42(c, &(v271_11_head), &(v271_6), &(v271_11_tail));
          compose(&(v272_9),&(v274_10))
        };
        drop(v272_9);
        let v272_12: Space = unite(&(v272_7),&(v272_11));
        v271_11.join_into((v272_12).clone());
      }
      drop(v271_11_cursor);
      drop(v271_6);
      compose(&(v269_10),&(v271_11))
    };
    drop(v269_10);
    let v269_13: Space = unite(&(v269_8),&(v269_12));
    v268_8.join_into((v269_13).clone());
  }
  drop(v268_8_cursor);
  (v268_8).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v275_11 = Space::new();
  let mut v275_11_cursor = (*s0).read_zipper();
  for v275_11_byte in v275_11_cursor.child_mask().iter() {
    v275_11_cursor.descend_to_byte(v275_11_byte);
    let v275_11_tail = v275_11_cursor.make_map();
    v275_11_cursor.ascend(1);
    let v275_11_head = Path::from_slice(&[v275_11_byte]);
    let v276_2: Space = singleton(&(v275_11_head));
    let v276_3: Space = intersect(&(*CONSTANT_7),&(v276_2));
    let v276_4: Space = if has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
    drop(v276_3);
    let v276_5: Space = subtract(&(*CONSTANT_0),&(v276_4));
    drop(v276_4);
    let v276_7: Space = if (v276_5).is_empty() { Space::new() } else {
      let mut v277_6 = Space::new();
      let mut v277_6_cursor = (v275_11_tail).read_zipper();
      for v277_6_byte in v277_6_cursor.child_mask().iter() {
        v277_6_cursor.descend_to_byte(v277_6_byte);
        let v277_6_tail = v277_6_cursor.make_map();
        v277_6_cursor.ascend(1);
        let v277_6_head = Path::from_slice(&[v277_6_byte]);
        let v278_2: Space = singleton(&(v277_6_head));
        let v278_3: Space = intersect(&(*CONSTANT_7),&(v278_2));
        let v278_4: Space = if has_head(&(v278_3)) { singleton(&[]) } else { Space::new() };
        drop(v278_3);
        let v278_5: Space = subtract(&(*CONSTANT_0),&(v278_4));
        drop(v278_4);
        let v278_8: Space = if (v278_5).is_empty() { Space::new() } else {
          let v279_6: Path = concat_path(&(v275_11_head),&(v277_6_head));
          let v279_7: Space = routine_41(c, &(v279_6), &(*p0), &(v277_6_tail));
          compose(&(v278_5),&(v279_7))
        };
        drop(v278_5);
        let v278_9: Space = intersect(&(*CONSTANT_7),&(v278_2));
        drop(v278_2);
        let v278_10: Space = if has_head(&(v278_9)) { singleton(&[]) } else { Space::new() };
        drop(v278_9);
        let v278_12: Space = if (v278_10).is_empty() { Space::new() } else {
          let v280_6: Path = concat_path(&(v275_11_head),&(v277_6_head));
          let v280_11: Space = routine_42(c, &(v280_6), &(*p0), &(v277_6_tail));
          drop(v280_6);
          compose(&(v278_10),&(v280_11))
        };
        drop(v278_10);
        let v278_13: Space = unite(&(v278_8),&(v278_12));
        v277_6.join_into((v278_13).clone());
      }
      drop(v277_6_cursor);
      compose(&(v276_5),&(v277_6))
    };
    drop(v276_5);
    let v276_8: Space = intersect(&(*CONSTANT_7),&(v276_2));
    drop(v276_2);
    let v276_9: Space = if has_head(&(v276_8)) { singleton(&[]) } else { Space::new() };
    drop(v276_8);
    let v276_11: Space = if (v276_9).is_empty() { Space::new() } else {
      let mut v281_10 = Space::new();
      let mut v281_10_cursor = (v275_11_tail).read_zipper();
      for v281_10_byte in v281_10_cursor.child_mask().iter() {
        v281_10_cursor.descend_to_byte(v281_10_byte);
        let v281_10_tail = v281_10_cursor.make_map();
        v281_10_cursor.ascend(1);
        let v281_10_head = Path::from_slice(&[v281_10_byte]);
        let v282_2: Space = singleton(&(v281_10_head));
        let v282_3: Space = intersect(&(*CONSTANT_7),&(v282_2));
        let v282_4: Space = if has_head(&(v282_3)) { singleton(&[]) } else { Space::new() };
        drop(v282_3);
        let v282_5: Space = subtract(&(*CONSTANT_0),&(v282_4));
        drop(v282_4);
        let v282_7: Space = if (v282_5).is_empty() { Space::new() } else {
          let v283_6: Space = routine_50(c, &(v281_10_head), &(*p0), &(v275_11_head), &(v281_10_tail));
          compose(&(v282_5),&(v283_6))
        };
        drop(v282_5);
        let v282_8: Space = intersect(&(*CONSTANT_7),&(v282_2));
        drop(v282_2);
        let v282_9: Space = if has_head(&(v282_8)) { singleton(&[]) } else { Space::new() };
        drop(v282_8);
        let v282_11: Space = if (v282_9).is_empty() { Space::new() } else {
          let v284_10: Space = routine_51(c, &(v281_10_head), &(*p0), &(v275_11_head), &(v281_10_tail));
          compose(&(v282_9),&(v284_10))
        };
        drop(v282_9);
        let v282_12: Space = unite(&(v282_7),&(v282_11));
        v281_10.join_into((v282_12).clone());
      }
      drop(v281_10_cursor);
      compose(&(v276_9),&(v281_10))
    };
    drop(v276_9);
    let v276_12: Space = unite(&(v276_7),&(v276_11));
    v275_11.join_into((v276_12).clone());
  }
  drop(v275_11_cursor);
  (v275_11).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v285_8 = Space::new();
  let mut v285_8_cursor = (*s0).read_zipper();
  for v285_8_byte in v285_8_cursor.child_mask().iter() {
    v285_8_cursor.descend_to_byte(v285_8_byte);
    let v285_8_tail = v285_8_cursor.make_map();
    v285_8_cursor.ascend(1);
    let v285_8_head = Path::from_slice(&[v285_8_byte]);
    let v286_2: Space = singleton(&(v285_8_head));
    let v286_3: Space = intersect(&(*CONSTANT_7),&(v286_2));
    let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
    drop(v286_3);
    let v286_5: Space = subtract(&(*CONSTANT_0),&(v286_4));
    drop(v286_4);
    let v286_8: Space = if (v286_5).is_empty() { Space::new() } else {
      let v287_6: Path = concat_path(&(*p0),&(v285_8_head));
      let v287_7: Space = routine_29(c, &(v287_6), &(v285_8_tail));
      compose(&(v286_5),&(v287_7))
    };
    drop(v286_5);
    let v286_9: Space = intersect(&(*CONSTANT_7),&(v286_2));
    drop(v286_2);
    let v286_10: Space = if has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
    drop(v286_9);
    let v286_12: Space = if (v286_10).is_empty() { Space::new() } else {
      let v288_6: Path = concat_path(&(*p0),&(v285_8_head));
      let mut v288_11 = Space::new();
      let mut v288_11_cursor = (v285_8_tail).read_zipper();
      for v288_11_byte in v288_11_cursor.child_mask().iter() {
        v288_11_cursor.descend_to_byte(v288_11_byte);
        let v288_11_tail = v288_11_cursor.make_map();
        v288_11_cursor.ascend(1);
        let v288_11_head = Path::from_slice(&[v288_11_byte]);
        let v289_2: Space = singleton(&(v288_11_head));
        let v289_3: Space = intersect(&(*CONSTANT_7),&(v289_2));
        let v289_4: Space = if has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
        drop(v289_3);
        let v289_5: Space = subtract(&(*CONSTANT_0),&(v289_4));
        drop(v289_4);
        let v289_7: Space = if (v289_5).is_empty() { Space::new() } else {
          let v290_6: Space = routine_52(c, &(v288_11_head), &(v288_6), &(v288_11_tail));
          compose(&(v289_5),&(v290_6))
        };
        drop(v289_5);
        let v289_8: Space = intersect(&(*CONSTANT_7),&(v289_2));
        drop(v289_2);
        let v289_9: Space = if has_head(&(v289_8)) { singleton(&[]) } else { Space::new() };
        drop(v289_8);
        let v289_11: Space = if (v289_9).is_empty() { Space::new() } else {
          let v291_10: Space = routine_53(c, &(v288_11_head), &(v288_6), &(v288_11_tail));
          compose(&(v289_9),&(v291_10))
        };
        drop(v289_9);
        let v289_12: Space = unite(&(v289_7),&(v289_11));
        v288_11.join_into((v289_12).clone());
      }
      drop(v288_11_cursor);
      drop(v288_6);
      compose(&(v286_10),&(v288_11))
    };
    drop(v286_10);
    let v286_13: Space = unite(&(v286_8),&(v286_12));
    v285_8.join_into((v286_13).clone());
  }
  drop(v285_8_cursor);
  (v285_8).clone()
}

fn routine_30(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v292_7 = Space::new();
  let mut v292_7_cursor = (*s0).read_zipper();
  for v292_7_byte in v292_7_cursor.child_mask().iter() {
    v292_7_cursor.descend_to_byte(v292_7_byte);
    let v292_7_tail = v292_7_cursor.make_map();
    v292_7_cursor.ascend(1);
    let v292_7_head = Path::from_slice(&[v292_7_byte]);
    let v293_2: Space = singleton(&(v292_7_head));
    let v293_3: Space = intersect(&(*CONSTANT_7),&(v293_2));
    let v293_4: Space = if has_head(&(v293_3)) { singleton(&[]) } else { Space::new() };
    drop(v293_3);
    let v293_5: Space = subtract(&(*CONSTANT_0),&(v293_4));
    drop(v293_4);
    let v293_8: Space = if (v293_5).is_empty() { Space::new() } else {
      let v294_6: Path = concat_path(&(*p0),&(v292_7_head));
      let v294_7: Space = routine_30(c, &(v294_6), &(*p1), &(v292_7_tail), &(*s1));
      compose(&(v293_5),&(v294_7))
    };
    drop(v293_5);
    let v293_9: Space = intersect(&(*CONSTANT_7),&(v293_2));
    drop(v293_2);
    let v293_10: Space = if has_head(&(v293_9)) { singleton(&[]) } else { Space::new() };
    drop(v293_9);
    let v293_14: Space = if (v293_10).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&(v292_7_head));
      let v295_11: Space = unwrap(&(v292_7_tail),&(*p1));
      let v295_12: Space = wrap(&(v295_11),&(v295_6));
      drop(v295_6);
      drop(v295_11);
      let v295_13: Space = compose(&(v295_12),&(*s1));
      drop(v295_12);
      compose(&(v293_10),&(v295_13))
    };
    drop(v293_10);
    let v293_15: Space = unite(&(v293_8),&(v293_14));
    drop(v293_14);
    v292_7.join_into((v293_15).clone());
  }
  drop(v292_7_cursor);
  (v292_7).clone()
}

fn routine_31(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v296_4: Space = unwrap(&(*s0),&(*p1));
  let v296_5: Space = wrap(&(v296_4),&(*p0));
  drop(v296_4);
  let v296_6: Space = if (v296_5).is_empty() { Space::new() } else {
    compose(&(v296_5),&(*s1))
  };
  drop(v296_5);
  (v296_6).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v298_8 = Space::new();
  let mut v298_8_cursor = (*s0).read_zipper();
  for v298_8_byte in v298_8_cursor.child_mask().iter() {
    v298_8_cursor.descend_to_byte(v298_8_byte);
    let v298_8_tail = v298_8_cursor.make_map();
    v298_8_cursor.ascend(1);
    let v298_8_head = Path::from_slice(&[v298_8_byte]);
    let v299_2: Space = singleton(&(v298_8_head));
    let v299_3: Space = intersect(&(*CONSTANT_7),&(v299_2));
    let v299_4: Space = if has_head(&(v299_3)) { singleton(&[]) } else { Space::new() };
    drop(v299_3);
    let v299_5: Space = subtract(&(*CONSTANT_0),&(v299_4));
    drop(v299_4);
    let v299_8: Space = if (v299_5).is_empty() { Space::new() } else {
      let v300_6: Path = concat_path(&(*p0),&(v298_8_head));
      let v300_7: Space = routine_32(c, &(v300_6), &(v298_8_tail));
      compose(&(v299_5),&(v300_7))
    };
    drop(v299_5);
    let v299_9: Space = intersect(&(*CONSTANT_7),&(v299_2));
    drop(v299_2);
    let v299_10: Space = if has_head(&(v299_9)) { singleton(&[]) } else { Space::new() };
    drop(v299_9);
    let v299_12: Space = if (v299_10).is_empty() { Space::new() } else {
      let v301_6: Path = concat_path(&(*p0),&(v298_8_head));
      let mut v301_11 = Space::new();
      let mut v301_11_cursor = (v298_8_tail).read_zipper();
      for v301_11_byte in v301_11_cursor.child_mask().iter() {
        v301_11_cursor.descend_to_byte(v301_11_byte);
        let v301_11_tail = v301_11_cursor.make_map();
        v301_11_cursor.ascend(1);
        let v301_11_head = Path::from_slice(&[v301_11_byte]);
        let v302_2: Space = singleton(&(v301_11_head));
        let v302_3: Space = intersect(&(*CONSTANT_7),&(v302_2));
        let v302_4: Space = if has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
        drop(v302_3);
        let v302_5: Space = subtract(&(*CONSTANT_0),&(v302_4));
        drop(v302_4);
        let v302_7: Space = if (v302_5).is_empty() { Space::new() } else {
          let v303_6: Space = routine_54(c, &(v301_11_head), &(v301_6), &(v301_11_tail));
          compose(&(v302_5),&(v303_6))
        };
        drop(v302_5);
        let v302_8: Space = intersect(&(*CONSTANT_7),&(v302_2));
        drop(v302_2);
        let v302_9: Space = if has_head(&(v302_8)) { singleton(&[]) } else { Space::new() };
        drop(v302_8);
        let v302_11: Space = if (v302_9).is_empty() { Space::new() } else {
          let v304_10: Space = routine_55(c, &(v301_11_head), &(v301_6), &(v301_11_tail));
          compose(&(v302_9),&(v304_10))
        };
        drop(v302_9);
        let v302_12: Space = unite(&(v302_7),&(v302_11));
        v301_11.join_into((v302_12).clone());
      }
      drop(v301_11_cursor);
      drop(v301_6);
      compose(&(v299_10),&(v301_11))
    };
    drop(v299_10);
    let v299_13: Space = unite(&(v299_8),&(v299_12));
    v298_8.join_into((v299_13).clone());
  }
  drop(v298_8_cursor);
  (v298_8).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v305_6 = Space::new();
  let mut v305_6_cursor = (*s0).read_zipper();
  for v305_6_byte in v305_6_cursor.child_mask().iter() {
    v305_6_cursor.descend_to_byte(v305_6_byte);
    let v305_6_tail = v305_6_cursor.make_map();
    v305_6_cursor.ascend(1);
    let v305_6_head = Path::from_slice(&[v305_6_byte]);
    let v306_2: Space = singleton(&(v305_6_head));
    let v306_3: Space = intersect(&(*CONSTANT_7),&(v306_2));
    let v306_4: Space = if has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
    drop(v306_3);
    let v306_5: Space = subtract(&(*CONSTANT_0),&(v306_4));
    drop(v306_4);
    let v306_8: Space = if (v306_5).is_empty() { Space::new() } else {
      let v307_6: Path = concat_path(&(*p0),&(v305_6_head));
      let v307_7: Space = routine_33(c, &(v307_6), &(v305_6_tail), &(*s1));
      compose(&(v306_5),&(v307_7))
    };
    drop(v306_5);
    let v306_9: Space = intersect(&(*CONSTANT_7),&(v306_2));
    drop(v306_2);
    let v306_10: Space = if has_head(&(v306_9)) { singleton(&[]) } else { Space::new() };
    drop(v306_9);
    let v306_12: Space = if (v306_10).is_empty() { Space::new() } else {
      let v308_6: Path = concat_path(&(*p0),&(v305_6_head));
      let v308_11: Space = routine_43(c, &(v308_6), &(*s1));
      drop(v308_6);
      compose(&(v306_10),&(v308_11))
    };
    drop(v306_10);
    let v306_13: Space = unite(&(v306_8),&(v306_12));
    v305_6.join_into((v306_13).clone());
  }
  drop(v305_6_cursor);
  (v305_6).clone()
}

fn routine_34(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v309_4: Space = singleton(&(*p0));
  let v309_5: Space = intersect(&(*CONSTANT_8),&(v309_4));
  let v309_14: Space = if (v309_5).is_empty() { Space::new() } else {
    let v310_7: Space = unwrap(&(*s1),&(*CONSTANT_20));
    let v310_10: Space = if (v310_7).is_empty() { Space::new() } else {
      let v311_9: Space = unwrap(&(*s1),&(*CONSTANT_21));
      compose(&(v310_7),&(v311_9))
    };
    let v310_13: Space = if (v310_10).is_empty() { Space::new() } else {
      let v312_12: Space = unwrap(&(*s1),&(*CONSTANT_22));
      compose(&(v310_10),&(v312_12))
    };
    compose(&(v309_5),&(v310_13))
  };
  drop(v309_5);
  let v309_16: Space = intersect(&(*CONSTANT_9),&(v309_4));
  let v309_20: Space = if (v309_16).is_empty() { Space::new() } else {
    let v313_7: Space = unwrap(&(*s1),&(*CONSTANT_20));
    let v313_10: Space = if (v313_7).is_empty() { Space::new() } else {
      let v314_9: Space = unwrap(&(*s1),&(*CONSTANT_21));
      compose(&(v313_7),&(v314_9))
    };
    let v313_19: Space = if (v313_10).is_empty() { Space::new() } else {
      let v315_18: Space = unwrap(&(*s1),&(*CONSTANT_23));
      compose(&(v313_10),&(v315_18))
    };
    drop(v313_10);
    compose(&(v309_16),&(v313_19))
  };
  drop(v309_16);
  let v309_21: Space = unite(&(v309_14),&(v309_20));
  drop(v309_14);
  drop(v309_20);
  let v309_23: Space = intersect(&(*CONSTANT_10),&(v309_4));
  let v309_26: Space = if (v309_23).is_empty() { Space::new() } else {
    let v316_9: Space = unwrap(&(*s1),&(*CONSTANT_21));
    let v316_24: Space = if (v316_9).is_empty() { Space::new() } else {
      let v317_18: Space = unwrap(&(*s1),&(*CONSTANT_23));
      compose(&(v316_9),&(v317_18))
    };
    drop(v316_9);
    let v316_25: Space = if (v316_24).is_empty() { Space::new() } else {
      let v318_12: Space = unwrap(&(*s1),&(*CONSTANT_22));
      compose(&(v316_24),&(v318_12))
    };
    drop(v316_24);
    compose(&(v309_23),&(v316_25))
  };
  drop(v309_23);
  let v309_27: Space = unite(&(v309_21),&(v309_26));
  drop(v309_21);
  drop(v309_26);
  let v309_29: Space = intersect(&(*CONSTANT_11),&(v309_4));
  drop(v309_4);
  let v309_32: Space = if (v309_29).is_empty() { Space::new() } else {
    let v319_7: Space = unwrap(&(*s1),&(*CONSTANT_20));
    let v319_30: Space = if (v319_7).is_empty() { Space::new() } else {
      let v320_18: Space = unwrap(&(*s1),&(*CONSTANT_23));
      compose(&(v319_7),&(v320_18))
    };
    drop(v319_7);
    let v319_31: Space = if (v319_30).is_empty() { Space::new() } else {
      let v321_12: Space = unwrap(&(*s1),&(*CONSTANT_22));
      compose(&(v319_30),&(v321_12))
    };
    drop(v319_30);
    compose(&(v309_29),&(v319_31))
  };
  drop(v309_29);
  let v309_33: Space = unite(&(v309_27),&(v309_32));
  drop(v309_27);
  drop(v309_32);
  (v309_33).clone()
}

fn routine_35(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v322_9 = Space::new();
  let mut v322_9_cursor = (*s0).read_zipper();
  for v322_9_byte in v322_9_cursor.child_mask().iter() {
    v322_9_cursor.descend_to_byte(v322_9_byte);
    let v322_9_tail = v322_9_cursor.make_map();
    v322_9_cursor.ascend(1);
    let v322_9_head = Path::from_slice(&[v322_9_byte]);
    let v323_2: Space = singleton(&(v322_9_head));
    let v323_3: Space = intersect(&(*CONSTANT_7),&(v323_2));
    let v323_4: Space = if has_head(&(v323_3)) { singleton(&[]) } else { Space::new() };
    drop(v323_3);
    let v323_5: Space = subtract(&(*CONSTANT_0),&(v323_4));
    drop(v323_4);
    let v323_8: Space = if (v323_5).is_empty() { Space::new() } else {
      let v324_6: Path = concat_path(&(*p0),&(v322_9_head));
      let v324_7: Space = routine_35(c, &(v324_6), &(*p1), &(v322_9_tail));
      compose(&(v323_5),&(v324_7))
    };
    drop(v323_5);
    let v323_9: Space = intersect(&(*CONSTANT_7),&(v323_2));
    drop(v323_2);
    let v323_10: Space = if has_head(&(v323_9)) { singleton(&[]) } else { Space::new() };
    drop(v323_9);
    let v323_12: Space = if (v323_10).is_empty() { Space::new() } else {
      let v325_6: Path = concat_path(&(*p0),&(v322_9_head));
      let mut v325_11 = Space::new();
      let mut v325_11_cursor = (v322_9_tail).read_zipper();
      for v325_11_byte in v325_11_cursor.child_mask().iter() {
        v325_11_cursor.descend_to_byte(v325_11_byte);
        let v325_11_tail = v325_11_cursor.make_map();
        v325_11_cursor.ascend(1);
        let v325_11_head = Path::from_slice(&[v325_11_byte]);
        let v326_2: Space = singleton(&(v325_11_head));
        let v326_3: Space = intersect(&(*CONSTANT_7),&(v326_2));
        let v326_4: Space = if has_head(&(v326_3)) { singleton(&[]) } else { Space::new() };
        drop(v326_3);
        let v326_5: Space = subtract(&(*CONSTANT_0),&(v326_4));
        drop(v326_4);
        let v326_7: Space = if (v326_5).is_empty() { Space::new() } else {
          let v327_6: Space = routine_44(c, &(v325_11_head), &(*p1), &(v325_6), &(v325_11_tail));
          compose(&(v326_5),&(v327_6))
        };
        drop(v326_5);
        let v326_8: Space = intersect(&(*CONSTANT_7),&(v326_2));
        drop(v326_2);
        let v326_9: Space = if has_head(&(v326_8)) { singleton(&[]) } else { Space::new() };
        drop(v326_8);
        let v326_11: Space = if (v326_9).is_empty() { Space::new() } else {
          let v328_10: Space = routine_45(c, &(v325_11_head), &(*p1), &(v325_6), &(v325_11_tail));
          compose(&(v326_9),&(v328_10))
        };
        drop(v326_9);
        let v326_12: Space = unite(&(v326_7),&(v326_11));
        v325_11.join_into((v326_12).clone());
      }
      drop(v325_11_cursor);
      drop(v325_6);
      compose(&(v323_10),&(v325_11))
    };
    drop(v323_10);
    let v323_13: Space = unite(&(v323_8),&(v323_12));
    v322_9.join_into((v323_13).clone());
  }
  drop(v322_9_cursor);
  (v322_9).clone()
}

fn routine_36(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v329_9: Path = concat_path(&(*CONSTANT_20),&(*p1));
  let v329_10: Space = singleton(&(v329_9));
  drop(v329_9);
  let v329_12: Path = concat_path(&(*CONSTANT_21),&(*p0));
  let v329_13: Space = singleton(&(v329_12));
  drop(v329_12);
  let mut v329_17 = Space::new();
  let mut v329_17_cursor = (*s0).read_zipper();
  for v329_17_byte in v329_17_cursor.child_mask().iter() {
    v329_17_cursor.descend_to_byte(v329_17_byte);
    let v329_17_tail = v329_17_cursor.make_map();
    v329_17_cursor.ascend(1);
    let v329_17_head = Path::from_slice(&[v329_17_byte]);
    let v330_2: Space = singleton(&(v329_17_head));
    let v330_3: Space = intersect(&(*CONSTANT_7),&(v330_2));
    let v330_4: Space = if has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
    drop(v330_3);
    let v330_5: Space = subtract(&(*CONSTANT_0),&(v330_4));
    drop(v330_4);
    let v330_7: Space = if (v330_5).is_empty() { Space::new() } else {
      let mut v331_6 = Space::new();
      let mut v331_6_cursor = (v329_17_tail).read_zipper();
      for v331_6_byte in v331_6_cursor.child_mask().iter() {
        v331_6_cursor.descend_to_byte(v331_6_byte);
        let v331_6_tail = v331_6_cursor.make_map();
        v331_6_cursor.ascend(1);
        let v331_6_head = Path::from_slice(&[v331_6_byte]);
        let v332_2: Space = singleton(&(v331_6_head));
        let v332_3: Space = intersect(&(*CONSTANT_7),&(v332_2));
        let v332_4: Space = if has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
        drop(v332_3);
        let v332_5: Space = subtract(&(*CONSTANT_0),&(v332_4));
        drop(v332_4);
        let v332_8: Space = if (v332_5).is_empty() { Space::new() } else {
          let v333_6: Path = concat_path(&(v329_17_head),&(v331_6_head));
          let v333_7: Space = routine_44(c, &(v333_6), &(*p1), &(*p0), &(v331_6_tail));
          compose(&(v332_5),&(v333_7))
        };
        drop(v332_5);
        let v332_9: Space = intersect(&(*CONSTANT_7),&(v332_2));
        drop(v332_2);
        let v332_10: Space = if has_head(&(v332_9)) { singleton(&[]) } else { Space::new() };
        drop(v332_9);
        let v332_12: Space = if (v332_10).is_empty() { Space::new() } else {
          let v334_6: Path = concat_path(&(v329_17_head),&(v331_6_head));
          let v334_11: Space = routine_45(c, &(v334_6), &(*p1), &(*p0), &(v331_6_tail));
          drop(v334_6);
          compose(&(v332_10),&(v334_11))
        };
        drop(v332_10);
        let v332_13: Space = unite(&(v332_8),&(v332_12));
        v331_6.join_into((v332_13).clone());
      }
      drop(v331_6_cursor);
      compose(&(v330_5),&(v331_6))
    };
    drop(v330_5);
    let v330_8: Space = intersect(&(*CONSTANT_7),&(v330_2));
    drop(v330_2);
    let v330_9: Space = if has_head(&(v330_8)) { singleton(&[]) } else { Space::new() };
    drop(v330_8);
    let v330_15: Space = if (v330_9).is_empty() { Space::new() } else {
      let v335_10: Path = concat_path(&(*CONSTANT_22),&(v329_17_head));
      let v335_11: Space = singleton(&(v335_10));
      drop(v335_10);
      let v335_12: Space = unite(&(*CONSTANT_24),&(v335_11));
      drop(v335_11);
      let v335_13: Space = unite(&(v335_12),&(v329_10));
      drop(v335_12);
      let v335_14: Space = unite(&(v335_13),&(v329_13));
      drop(v335_13);
      compose(&(v330_9),&(v335_14))
    };
    drop(v330_9);
    let v330_16: Space = unite(&(v330_7),&(v330_15));
    drop(v330_15);
    v329_17.join_into((v330_16).clone());
  }
  drop(v329_17_cursor);
  drop(v329_10);
  drop(v329_13);
  (v329_17).clone()
}

fn routine_37(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v336_9 = Space::new();
  let mut v336_9_cursor = (*s0).read_zipper();
  for v336_9_byte in v336_9_cursor.child_mask().iter() {
    v336_9_cursor.descend_to_byte(v336_9_byte);
    let v336_9_tail = v336_9_cursor.make_map();
    v336_9_cursor.ascend(1);
    let v336_9_head = Path::from_slice(&[v336_9_byte]);
    let v337_2: Space = singleton(&(v336_9_head));
    let v337_3: Space = intersect(&(*CONSTANT_7),&(v337_2));
    let v337_4: Space = if has_head(&(v337_3)) { singleton(&[]) } else { Space::new() };
    drop(v337_3);
    let v337_5: Space = subtract(&(*CONSTANT_0),&(v337_4));
    drop(v337_4);
    let v337_8: Space = if (v337_5).is_empty() { Space::new() } else {
      let v338_6: Path = concat_path(&(*p0),&(v336_9_head));
      let v338_7: Space = routine_37(c, &(v338_6), &(*p1), &(v336_9_tail));
      compose(&(v337_5),&(v338_7))
    };
    drop(v337_5);
    let v337_9: Space = intersect(&(*CONSTANT_7),&(v337_2));
    drop(v337_2);
    let v337_10: Space = if has_head(&(v337_9)) { singleton(&[]) } else { Space::new() };
    drop(v337_9);
    let v337_12: Space = if (v337_10).is_empty() { Space::new() } else {
      let v339_6: Path = concat_path(&(*p0),&(v336_9_head));
      let mut v339_11 = Space::new();
      let mut v339_11_cursor = (v336_9_tail).read_zipper();
      for v339_11_byte in v339_11_cursor.child_mask().iter() {
        v339_11_cursor.descend_to_byte(v339_11_byte);
        let v339_11_tail = v339_11_cursor.make_map();
        v339_11_cursor.ascend(1);
        let v339_11_head = Path::from_slice(&[v339_11_byte]);
        let v340_2: Space = singleton(&(v339_11_head));
        let v340_3: Space = intersect(&(*CONSTANT_7),&(v340_2));
        let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
        drop(v340_3);
        let v340_5: Space = subtract(&(*CONSTANT_0),&(v340_4));
        drop(v340_4);
        let v340_7: Space = if (v340_5).is_empty() { Space::new() } else {
          let v341_6: Space = routine_46(c, &(v339_11_head), &(*p1), &(v339_6), &(v339_11_tail));
          compose(&(v340_5),&(v341_6))
        };
        drop(v340_5);
        let v340_8: Space = intersect(&(*CONSTANT_7),&(v340_2));
        drop(v340_2);
        let v340_9: Space = if has_head(&(v340_8)) { singleton(&[]) } else { Space::new() };
        drop(v340_8);
        let v340_11: Space = if (v340_9).is_empty() { Space::new() } else {
          let v342_10: Space = routine_47(c, &(v339_11_head), &(*p1), &(v339_6), &(v339_11_tail));
          compose(&(v340_9),&(v342_10))
        };
        drop(v340_9);
        let v340_12: Space = unite(&(v340_7),&(v340_11));
        v339_11.join_into((v340_12).clone());
      }
      drop(v339_11_cursor);
      drop(v339_6);
      compose(&(v337_10),&(v339_11))
    };
    drop(v337_10);
    let v337_13: Space = unite(&(v337_8),&(v337_12));
    v336_9.join_into((v337_13).clone());
  }
  drop(v336_9_cursor);
  (v336_9).clone()
}

fn routine_38(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v343_9: Path = concat_path(&(*CONSTANT_20),&(*p1));
  let v343_10: Space = singleton(&(v343_9));
  drop(v343_9);
  let v343_12: Path = concat_path(&(*CONSTANT_21),&(*p0));
  let v343_13: Space = singleton(&(v343_12));
  drop(v343_12);
  let mut v343_17 = Space::new();
  let mut v343_17_cursor = (*s0).read_zipper();
  for v343_17_byte in v343_17_cursor.child_mask().iter() {
    v343_17_cursor.descend_to_byte(v343_17_byte);
    let v343_17_tail = v343_17_cursor.make_map();
    v343_17_cursor.ascend(1);
    let v343_17_head = Path::from_slice(&[v343_17_byte]);
    let v344_2: Space = singleton(&(v343_17_head));
    let v344_3: Space = intersect(&(*CONSTANT_7),&(v344_2));
    let v344_4: Space = if has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
    drop(v344_3);
    let v344_5: Space = subtract(&(*CONSTANT_0),&(v344_4));
    drop(v344_4);
    let v344_7: Space = if (v344_5).is_empty() { Space::new() } else {
      let mut v345_6 = Space::new();
      let mut v345_6_cursor = (v343_17_tail).read_zipper();
      for v345_6_byte in v345_6_cursor.child_mask().iter() {
        v345_6_cursor.descend_to_byte(v345_6_byte);
        let v345_6_tail = v345_6_cursor.make_map();
        v345_6_cursor.ascend(1);
        let v345_6_head = Path::from_slice(&[v345_6_byte]);
        let v346_2: Space = singleton(&(v345_6_head));
        let v346_3: Space = intersect(&(*CONSTANT_7),&(v346_2));
        let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
        drop(v346_3);
        let v346_5: Space = subtract(&(*CONSTANT_0),&(v346_4));
        drop(v346_4);
        let v346_8: Space = if (v346_5).is_empty() { Space::new() } else {
          let v347_6: Path = concat_path(&(v343_17_head),&(v345_6_head));
          let v347_7: Space = routine_46(c, &(v347_6), &(*p1), &(*p0), &(v345_6_tail));
          compose(&(v346_5),&(v347_7))
        };
        drop(v346_5);
        let v346_9: Space = intersect(&(*CONSTANT_7),&(v346_2));
        drop(v346_2);
        let v346_10: Space = if has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
        drop(v346_9);
        let v346_12: Space = if (v346_10).is_empty() { Space::new() } else {
          let v348_6: Path = concat_path(&(v343_17_head),&(v345_6_head));
          let v348_11: Space = routine_47(c, &(v348_6), &(*p1), &(*p0), &(v345_6_tail));
          drop(v348_6);
          compose(&(v346_10),&(v348_11))
        };
        drop(v346_10);
        let v346_13: Space = unite(&(v346_8),&(v346_12));
        v345_6.join_into((v346_13).clone());
      }
      drop(v345_6_cursor);
      compose(&(v344_5),&(v345_6))
    };
    drop(v344_5);
    let v344_8: Space = intersect(&(*CONSTANT_7),&(v344_2));
    drop(v344_2);
    let v344_9: Space = if has_head(&(v344_8)) { singleton(&[]) } else { Space::new() };
    drop(v344_8);
    let v344_15: Space = if (v344_9).is_empty() { Space::new() } else {
      let v349_10: Path = concat_path(&(*CONSTANT_23),&(v343_17_head));
      let v349_11: Space = singleton(&(v349_10));
      drop(v349_10);
      let v349_12: Space = unite(&(*CONSTANT_25),&(v349_11));
      drop(v349_11);
      let v349_13: Space = unite(&(v349_12),&(v343_10));
      drop(v349_12);
      let v349_14: Space = unite(&(v349_13),&(v343_13));
      drop(v349_13);
      compose(&(v344_9),&(v349_14))
    };
    drop(v344_9);
    let v344_16: Space = unite(&(v344_7),&(v344_15));
    drop(v344_15);
    v343_17.join_into((v344_16).clone());
  }
  drop(v343_17_cursor);
  drop(v343_10);
  drop(v343_13);
  (v343_17).clone()
}

fn routine_39(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v350_9 = Space::new();
  let mut v350_9_cursor = (*s0).read_zipper();
  for v350_9_byte in v350_9_cursor.child_mask().iter() {
    v350_9_cursor.descend_to_byte(v350_9_byte);
    let v350_9_tail = v350_9_cursor.make_map();
    v350_9_cursor.ascend(1);
    let v350_9_head = Path::from_slice(&[v350_9_byte]);
    let v351_2: Space = singleton(&(v350_9_head));
    let v351_3: Space = intersect(&(*CONSTANT_7),&(v351_2));
    let v351_4: Space = if has_head(&(v351_3)) { singleton(&[]) } else { Space::new() };
    drop(v351_3);
    let v351_5: Space = subtract(&(*CONSTANT_0),&(v351_4));
    drop(v351_4);
    let v351_8: Space = if (v351_5).is_empty() { Space::new() } else {
      let v352_6: Path = concat_path(&(*p0),&(v350_9_head));
      let v352_7: Space = routine_39(c, &(v352_6), &(*p1), &(v350_9_tail));
      compose(&(v351_5),&(v352_7))
    };
    drop(v351_5);
    let v351_9: Space = intersect(&(*CONSTANT_7),&(v351_2));
    drop(v351_2);
    let v351_10: Space = if has_head(&(v351_9)) { singleton(&[]) } else { Space::new() };
    drop(v351_9);
    let v351_12: Space = if (v351_10).is_empty() { Space::new() } else {
      let v353_6: Path = concat_path(&(*p0),&(v350_9_head));
      let mut v353_11 = Space::new();
      let mut v353_11_cursor = (v350_9_tail).read_zipper();
      for v353_11_byte in v353_11_cursor.child_mask().iter() {
        v353_11_cursor.descend_to_byte(v353_11_byte);
        let v353_11_tail = v353_11_cursor.make_map();
        v353_11_cursor.ascend(1);
        let v353_11_head = Path::from_slice(&[v353_11_byte]);
        let v354_2: Space = singleton(&(v353_11_head));
        let v354_3: Space = intersect(&(*CONSTANT_7),&(v354_2));
        let v354_4: Space = if has_head(&(v354_3)) { singleton(&[]) } else { Space::new() };
        drop(v354_3);
        let v354_5: Space = subtract(&(*CONSTANT_0),&(v354_4));
        drop(v354_4);
        let v354_7: Space = if (v354_5).is_empty() { Space::new() } else {
          let v355_6: Space = routine_48(c, &(v353_11_head), &(*p1), &(v353_6), &(v353_11_tail));
          compose(&(v354_5),&(v355_6))
        };
        drop(v354_5);
        let v354_8: Space = intersect(&(*CONSTANT_7),&(v354_2));
        drop(v354_2);
        let v354_9: Space = if has_head(&(v354_8)) { singleton(&[]) } else { Space::new() };
        drop(v354_8);
        let v354_11: Space = if (v354_9).is_empty() { Space::new() } else {
          let v356_10: Space = routine_49(c, &(v353_11_head), &(*p1), &(v353_6), &(v353_11_tail));
          compose(&(v354_9),&(v356_10))
        };
        drop(v354_9);
        let v354_12: Space = unite(&(v354_7),&(v354_11));
        v353_11.join_into((v354_12).clone());
      }
      drop(v353_11_cursor);
      drop(v353_6);
      compose(&(v351_10),&(v353_11))
    };
    drop(v351_10);
    let v351_13: Space = unite(&(v351_8),&(v351_12));
    v350_9.join_into((v351_13).clone());
  }
  drop(v350_9_cursor);
  (v350_9).clone()
}

fn routine_40(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v357_8: Path = concat_path(&(*CONSTANT_23),&(*p0));
  let v357_9: Space = singleton(&(v357_8));
  drop(v357_8);
  let v357_10: Space = unite(&(*CONSTANT_26),&(v357_9));
  drop(v357_9);
  let v357_13: Path = concat_path(&(*CONSTANT_21),&(*p1));
  let v357_14: Space = singleton(&(v357_13));
  drop(v357_13);
  let mut v357_18 = Space::new();
  let mut v357_18_cursor = (*s0).read_zipper();
  for v357_18_byte in v357_18_cursor.child_mask().iter() {
    v357_18_cursor.descend_to_byte(v357_18_byte);
    let v357_18_tail = v357_18_cursor.make_map();
    v357_18_cursor.ascend(1);
    let v357_18_head = Path::from_slice(&[v357_18_byte]);
    let v358_2: Space = singleton(&(v357_18_head));
    let v358_3: Space = intersect(&(*CONSTANT_7),&(v358_2));
    let v358_4: Space = if has_head(&(v358_3)) { singleton(&[]) } else { Space::new() };
    drop(v358_3);
    let v358_5: Space = subtract(&(*CONSTANT_0),&(v358_4));
    drop(v358_4);
    let v358_7: Space = if (v358_5).is_empty() { Space::new() } else {
      let mut v359_6 = Space::new();
      let mut v359_6_cursor = (v357_18_tail).read_zipper();
      for v359_6_byte in v359_6_cursor.child_mask().iter() {
        v359_6_cursor.descend_to_byte(v359_6_byte);
        let v359_6_tail = v359_6_cursor.make_map();
        v359_6_cursor.ascend(1);
        let v359_6_head = Path::from_slice(&[v359_6_byte]);
        let v360_2: Space = singleton(&(v359_6_head));
        let v360_3: Space = intersect(&(*CONSTANT_7),&(v360_2));
        let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
        drop(v360_3);
        let v360_5: Space = subtract(&(*CONSTANT_0),&(v360_4));
        drop(v360_4);
        let v360_8: Space = if (v360_5).is_empty() { Space::new() } else {
          let v361_6: Path = concat_path(&(v357_18_head),&(v359_6_head));
          let v361_7: Space = routine_48(c, &(v361_6), &(*p1), &(*p0), &(v359_6_tail));
          compose(&(v360_5),&(v361_7))
        };
        drop(v360_5);
        let v360_9: Space = intersect(&(*CONSTANT_7),&(v360_2));
        drop(v360_2);
        let v360_10: Space = if has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
        drop(v360_9);
        let v360_12: Space = if (v360_10).is_empty() { Space::new() } else {
          let v362_6: Path = concat_path(&(v357_18_head),&(v359_6_head));
          let v362_11: Space = routine_49(c, &(v362_6), &(*p1), &(*p0), &(v359_6_tail));
          drop(v362_6);
          compose(&(v360_10),&(v362_11))
        };
        drop(v360_10);
        let v360_13: Space = unite(&(v360_8),&(v360_12));
        v359_6.join_into((v360_13).clone());
      }
      drop(v359_6_cursor);
      compose(&(v358_5),&(v359_6))
    };
    drop(v358_5);
    let v358_8: Space = intersect(&(*CONSTANT_7),&(v358_2));
    drop(v358_2);
    let v358_9: Space = if has_head(&(v358_8)) { singleton(&[]) } else { Space::new() };
    drop(v358_8);
    let v358_14: Space = if (v358_9).is_empty() { Space::new() } else {
      let v363_10: Path = concat_path(&(*CONSTANT_22),&(v357_18_head));
      let v363_11: Space = singleton(&(v363_10));
      drop(v363_10);
      let v363_12: Space = unite(&(v357_10),&(v363_11));
      drop(v363_11);
      let v363_13: Space = unite(&(v363_12),&(v357_14));
      drop(v363_12);
      compose(&(v358_9),&(v363_13))
    };
    drop(v358_9);
    let v358_15: Space = unite(&(v358_7),&(v358_14));
    drop(v358_14);
    v357_18.join_into((v358_15).clone());
  }
  drop(v357_18_cursor);
  drop(v357_10);
  drop(v357_14);
  (v357_18).clone()
}

fn routine_41(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v364_9 = Space::new();
  let mut v364_9_cursor = (*s0).read_zipper();
  for v364_9_byte in v364_9_cursor.child_mask().iter() {
    v364_9_cursor.descend_to_byte(v364_9_byte);
    let v364_9_tail = v364_9_cursor.make_map();
    v364_9_cursor.ascend(1);
    let v364_9_head = Path::from_slice(&[v364_9_byte]);
    let v365_2: Space = singleton(&(v364_9_head));
    let v365_3: Space = intersect(&(*CONSTANT_7),&(v365_2));
    let v365_4: Space = if has_head(&(v365_3)) { singleton(&[]) } else { Space::new() };
    drop(v365_3);
    let v365_5: Space = subtract(&(*CONSTANT_0),&(v365_4));
    drop(v365_4);
    let v365_8: Space = if (v365_5).is_empty() { Space::new() } else {
      let v366_6: Path = concat_path(&(*p0),&(v364_9_head));
      let v366_7: Space = routine_41(c, &(v366_6), &(*p1), &(v364_9_tail));
      compose(&(v365_5),&(v366_7))
    };
    drop(v365_5);
    let v365_9: Space = intersect(&(*CONSTANT_7),&(v365_2));
    drop(v365_2);
    let v365_10: Space = if has_head(&(v365_9)) { singleton(&[]) } else { Space::new() };
    drop(v365_9);
    let v365_12: Space = if (v365_10).is_empty() { Space::new() } else {
      let v367_6: Path = concat_path(&(*p0),&(v364_9_head));
      let mut v367_11 = Space::new();
      let mut v367_11_cursor = (v364_9_tail).read_zipper();
      for v367_11_byte in v367_11_cursor.child_mask().iter() {
        v367_11_cursor.descend_to_byte(v367_11_byte);
        let v367_11_tail = v367_11_cursor.make_map();
        v367_11_cursor.ascend(1);
        let v367_11_head = Path::from_slice(&[v367_11_byte]);
        let v368_2: Space = singleton(&(v367_11_head));
        let v368_3: Space = intersect(&(*CONSTANT_7),&(v368_2));
        let v368_4: Space = if has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
        drop(v368_3);
        let v368_5: Space = subtract(&(*CONSTANT_0),&(v368_4));
        drop(v368_4);
        let v368_7: Space = if (v368_5).is_empty() { Space::new() } else {
          let v369_6: Space = routine_50(c, &(v367_11_head), &(*p1), &(v367_6), &(v367_11_tail));
          compose(&(v368_5),&(v369_6))
        };
        drop(v368_5);
        let v368_8: Space = intersect(&(*CONSTANT_7),&(v368_2));
        drop(v368_2);
        let v368_9: Space = if has_head(&(v368_8)) { singleton(&[]) } else { Space::new() };
        drop(v368_8);
        let v368_11: Space = if (v368_9).is_empty() { Space::new() } else {
          let v370_10: Space = routine_51(c, &(v367_11_head), &(*p1), &(v367_6), &(v367_11_tail));
          compose(&(v368_9),&(v370_10))
        };
        drop(v368_9);
        let v368_12: Space = unite(&(v368_7),&(v368_11));
        v367_11.join_into((v368_12).clone());
      }
      drop(v367_11_cursor);
      drop(v367_6);
      compose(&(v365_10),&(v367_11))
    };
    drop(v365_10);
    let v365_13: Space = unite(&(v365_8),&(v365_12));
    v364_9.join_into((v365_13).clone());
  }
  drop(v364_9_cursor);
  (v364_9).clone()
}

fn routine_42(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v371_8: Path = concat_path(&(*CONSTANT_23),&(*p0));
  let v371_9: Space = singleton(&(v371_8));
  drop(v371_8);
  let v371_10: Space = unite(&(*CONSTANT_27),&(v371_9));
  drop(v371_9);
  let v371_13: Path = concat_path(&(*CONSTANT_20),&(*p1));
  let v371_14: Space = singleton(&(v371_13));
  drop(v371_13);
  let mut v371_18 = Space::new();
  let mut v371_18_cursor = (*s0).read_zipper();
  for v371_18_byte in v371_18_cursor.child_mask().iter() {
    v371_18_cursor.descend_to_byte(v371_18_byte);
    let v371_18_tail = v371_18_cursor.make_map();
    v371_18_cursor.ascend(1);
    let v371_18_head = Path::from_slice(&[v371_18_byte]);
    let v372_2: Space = singleton(&(v371_18_head));
    let v372_3: Space = intersect(&(*CONSTANT_7),&(v372_2));
    let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
    drop(v372_3);
    let v372_5: Space = subtract(&(*CONSTANT_0),&(v372_4));
    drop(v372_4);
    let v372_7: Space = if (v372_5).is_empty() { Space::new() } else {
      let mut v373_6 = Space::new();
      let mut v373_6_cursor = (v371_18_tail).read_zipper();
      for v373_6_byte in v373_6_cursor.child_mask().iter() {
        v373_6_cursor.descend_to_byte(v373_6_byte);
        let v373_6_tail = v373_6_cursor.make_map();
        v373_6_cursor.ascend(1);
        let v373_6_head = Path::from_slice(&[v373_6_byte]);
        let v374_2: Space = singleton(&(v373_6_head));
        let v374_3: Space = intersect(&(*CONSTANT_7),&(v374_2));
        let v374_4: Space = if has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
        drop(v374_3);
        let v374_5: Space = subtract(&(*CONSTANT_0),&(v374_4));
        drop(v374_4);
        let v374_8: Space = if (v374_5).is_empty() { Space::new() } else {
          let v375_6: Path = concat_path(&(v371_18_head),&(v373_6_head));
          let v375_7: Space = routine_50(c, &(v375_6), &(*p1), &(*p0), &(v373_6_tail));
          compose(&(v374_5),&(v375_7))
        };
        drop(v374_5);
        let v374_9: Space = intersect(&(*CONSTANT_7),&(v374_2));
        drop(v374_2);
        let v374_10: Space = if has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
        drop(v374_9);
        let v374_12: Space = if (v374_10).is_empty() { Space::new() } else {
          let v376_6: Path = concat_path(&(v371_18_head),&(v373_6_head));
          let v376_11: Space = routine_51(c, &(v376_6), &(*p1), &(*p0), &(v373_6_tail));
          drop(v376_6);
          compose(&(v374_10),&(v376_11))
        };
        drop(v374_10);
        let v374_13: Space = unite(&(v374_8),&(v374_12));
        v373_6.join_into((v374_13).clone());
      }
      drop(v373_6_cursor);
      compose(&(v372_5),&(v373_6))
    };
    drop(v372_5);
    let v372_8: Space = intersect(&(*CONSTANT_7),&(v372_2));
    drop(v372_2);
    let v372_9: Space = if has_head(&(v372_8)) { singleton(&[]) } else { Space::new() };
    drop(v372_8);
    let v372_14: Space = if (v372_9).is_empty() { Space::new() } else {
      let v377_10: Path = concat_path(&(*CONSTANT_22),&(v371_18_head));
      let v377_11: Space = singleton(&(v377_10));
      drop(v377_10);
      let v377_12: Space = unite(&(v371_10),&(v377_11));
      drop(v377_11);
      let v377_13: Space = unite(&(v377_12),&(v371_14));
      drop(v377_12);
      compose(&(v372_9),&(v377_13))
    };
    drop(v372_9);
    let v372_15: Space = unite(&(v372_7),&(v372_14));
    drop(v372_14);
    v371_18.join_into((v372_15).clone());
  }
  drop(v371_18_cursor);
  drop(v371_10);
  drop(v371_14);
  (v371_18).clone()
}

fn routine_43(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v378_3: Space = singleton(&(*p0));
  let v378_4: Space = intersect(&(*CONSTANT_8),&(v378_3));
  let v378_13: Space = if (v378_4).is_empty() { Space::new() } else {
    let v379_6: Space = unwrap(&(*s0),&(*CONSTANT_20));
    let v379_9: Space = if (v379_6).is_empty() { Space::new() } else {
      let v380_8: Space = unwrap(&(*s0),&(*CONSTANT_21));
      compose(&(v379_6),&(v380_8))
    };
    let v379_12: Space = if (v379_9).is_empty() { Space::new() } else {
      let v381_11: Space = unwrap(&(*s0),&(*CONSTANT_22));
      compose(&(v379_9),&(v381_11))
    };
    compose(&(v378_4),&(v379_12))
  };
  drop(v378_4);
  let v378_15: Space = intersect(&(*CONSTANT_9),&(v378_3));
  let v378_19: Space = if (v378_15).is_empty() { Space::new() } else {
    let v382_6: Space = unwrap(&(*s0),&(*CONSTANT_20));
    let v382_9: Space = if (v382_6).is_empty() { Space::new() } else {
      let v383_8: Space = unwrap(&(*s0),&(*CONSTANT_21));
      compose(&(v382_6),&(v383_8))
    };
    let v382_18: Space = if (v382_9).is_empty() { Space::new() } else {
      let v384_17: Space = unwrap(&(*s0),&(*CONSTANT_23));
      compose(&(v382_9),&(v384_17))
    };
    drop(v382_9);
    compose(&(v378_15),&(v382_18))
  };
  drop(v378_15);
  let v378_20: Space = unite(&(v378_13),&(v378_19));
  drop(v378_13);
  drop(v378_19);
  let v378_22: Space = intersect(&(*CONSTANT_10),&(v378_3));
  let v378_25: Space = if (v378_22).is_empty() { Space::new() } else {
    let v385_8: Space = unwrap(&(*s0),&(*CONSTANT_21));
    let v385_23: Space = if (v385_8).is_empty() { Space::new() } else {
      let v386_17: Space = unwrap(&(*s0),&(*CONSTANT_23));
      compose(&(v385_8),&(v386_17))
    };
    drop(v385_8);
    let v385_24: Space = if (v385_23).is_empty() { Space::new() } else {
      let v387_11: Space = unwrap(&(*s0),&(*CONSTANT_22));
      compose(&(v385_23),&(v387_11))
    };
    drop(v385_23);
    compose(&(v378_22),&(v385_24))
  };
  drop(v378_22);
  let v378_26: Space = unite(&(v378_20),&(v378_25));
  drop(v378_20);
  drop(v378_25);
  let v378_28: Space = intersect(&(*CONSTANT_11),&(v378_3));
  drop(v378_3);
  let v378_31: Space = if (v378_28).is_empty() { Space::new() } else {
    let v388_6: Space = unwrap(&(*s0),&(*CONSTANT_20));
    let v388_29: Space = if (v388_6).is_empty() { Space::new() } else {
      let v389_17: Space = unwrap(&(*s0),&(*CONSTANT_23));
      compose(&(v388_6),&(v389_17))
    };
    drop(v388_6);
    let v388_30: Space = if (v388_29).is_empty() { Space::new() } else {
      let v390_11: Space = unwrap(&(*s0),&(*CONSTANT_22));
      compose(&(v388_29),&(v390_11))
    };
    drop(v388_29);
    compose(&(v378_28),&(v388_30))
  };
  drop(v378_28);
  let v378_32: Space = unite(&(v378_26),&(v378_31));
  drop(v378_26);
  drop(v378_31);
  (v378_32).clone()
}

fn routine_44(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v391_10: Path = concat_path(&(*CONSTANT_20),&(*p1));
  let v391_11: Space = singleton(&(v391_10));
  drop(v391_10);
  let v391_13: Path = concat_path(&(*CONSTANT_21),&(*p2));
  let v391_14: Space = singleton(&(v391_13));
  drop(v391_13);
  let mut v391_15 = Space::new();
  let mut v391_15_cursor = (*s0).read_zipper();
  for v391_15_byte in v391_15_cursor.child_mask().iter() {
    v391_15_cursor.descend_to_byte(v391_15_byte);
    let v391_15_tail = v391_15_cursor.make_map();
    v391_15_cursor.ascend(1);
    let v391_15_head = Path::from_slice(&[v391_15_byte]);
    let v392_2: Space = singleton(&(v391_15_head));
    let v392_3: Space = intersect(&(*CONSTANT_7),&(v392_2));
    let v392_4: Space = if has_head(&(v392_3)) { singleton(&[]) } else { Space::new() };
    drop(v392_3);
    let v392_5: Space = subtract(&(*CONSTANT_0),&(v392_4));
    drop(v392_4);
    let v392_8: Space = if (v392_5).is_empty() { Space::new() } else {
      let v393_6: Path = concat_path(&(*p0),&(v391_15_head));
      let v393_7: Space = routine_44(c, &(v393_6), &(*p1), &(*p2), &(v391_15_tail));
      compose(&(v392_5),&(v393_7))
    };
    drop(v392_5);
    let v392_9: Space = intersect(&(*CONSTANT_7),&(v392_2));
    drop(v392_2);
    let v392_10: Space = if has_head(&(v392_9)) { singleton(&[]) } else { Space::new() };
    drop(v392_9);
    let v392_16: Space = if (v392_10).is_empty() { Space::new() } else {
      let v394_6: Path = concat_path(&(*p0),&(v391_15_head));
      let v394_11: Path = concat_path(&(*CONSTANT_22),&(v394_6));
      drop(v394_6);
      let v394_12: Space = singleton(&(v394_11));
      drop(v394_11);
      let v394_13: Space = unite(&(*CONSTANT_24),&(v394_12));
      drop(v394_12);
      let v394_14: Space = unite(&(v394_13),&(v391_11));
      drop(v394_13);
      let v394_15: Space = unite(&(v394_14),&(v391_14));
      drop(v394_14);
      compose(&(v392_10),&(v394_15))
    };
    drop(v392_10);
    let v392_17: Space = unite(&(v392_8),&(v392_16));
    drop(v392_16);
    v391_15.join_into((v392_17).clone());
  }
  drop(v391_15_cursor);
  drop(v391_11);
  drop(v391_14);
  (v391_15).clone()
}

fn routine_45(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v395_6: Path = concat_path(&(*CONSTANT_22),&(*p0));
  let v395_7: Space = singleton(&(v395_6));
  drop(v395_6);
  let v395_8: Space = unite(&(*CONSTANT_24),&(v395_7));
  drop(v395_7);
  let v395_10: Path = concat_path(&(*CONSTANT_20),&(*p1));
  let v395_11: Space = singleton(&(v395_10));
  drop(v395_10);
  let v395_12: Space = unite(&(v395_8),&(v395_11));
  drop(v395_8);
  drop(v395_11);
  let v395_14: Path = concat_path(&(*CONSTANT_21),&(*p2));
  let v395_15: Space = singleton(&(v395_14));
  drop(v395_14);
  let v395_16: Space = unite(&(v395_12),&(v395_15));
  drop(v395_12);
  drop(v395_15);
  (v395_16).clone()
}

fn routine_46(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v396_10: Path = concat_path(&(*CONSTANT_20),&(*p1));
  let v396_11: Space = singleton(&(v396_10));
  drop(v396_10);
  let v396_13: Path = concat_path(&(*CONSTANT_21),&(*p2));
  let v396_14: Space = singleton(&(v396_13));
  drop(v396_13);
  let mut v396_15 = Space::new();
  let mut v396_15_cursor = (*s0).read_zipper();
  for v396_15_byte in v396_15_cursor.child_mask().iter() {
    v396_15_cursor.descend_to_byte(v396_15_byte);
    let v396_15_tail = v396_15_cursor.make_map();
    v396_15_cursor.ascend(1);
    let v396_15_head = Path::from_slice(&[v396_15_byte]);
    let v397_2: Space = singleton(&(v396_15_head));
    let v397_3: Space = intersect(&(*CONSTANT_7),&(v397_2));
    let v397_4: Space = if has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
    drop(v397_3);
    let v397_5: Space = subtract(&(*CONSTANT_0),&(v397_4));
    drop(v397_4);
    let v397_8: Space = if (v397_5).is_empty() { Space::new() } else {
      let v398_6: Path = concat_path(&(*p0),&(v396_15_head));
      let v398_7: Space = routine_46(c, &(v398_6), &(*p1), &(*p2), &(v396_15_tail));
      compose(&(v397_5),&(v398_7))
    };
    drop(v397_5);
    let v397_9: Space = intersect(&(*CONSTANT_7),&(v397_2));
    drop(v397_2);
    let v397_10: Space = if has_head(&(v397_9)) { singleton(&[]) } else { Space::new() };
    drop(v397_9);
    let v397_16: Space = if (v397_10).is_empty() { Space::new() } else {
      let v399_6: Path = concat_path(&(*p0),&(v396_15_head));
      let v399_11: Path = concat_path(&(*CONSTANT_23),&(v399_6));
      drop(v399_6);
      let v399_12: Space = singleton(&(v399_11));
      drop(v399_11);
      let v399_13: Space = unite(&(*CONSTANT_25),&(v399_12));
      drop(v399_12);
      let v399_14: Space = unite(&(v399_13),&(v396_11));
      drop(v399_13);
      let v399_15: Space = unite(&(v399_14),&(v396_14));
      drop(v399_14);
      compose(&(v397_10),&(v399_15))
    };
    drop(v397_10);
    let v397_17: Space = unite(&(v397_8),&(v397_16));
    drop(v397_16);
    v396_15.join_into((v397_17).clone());
  }
  drop(v396_15_cursor);
  drop(v396_11);
  drop(v396_14);
  (v396_15).clone()
}

fn routine_47(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v400_6: Path = concat_path(&(*CONSTANT_23),&(*p0));
  let v400_7: Space = singleton(&(v400_6));
  drop(v400_6);
  let v400_8: Space = unite(&(*CONSTANT_25),&(v400_7));
  drop(v400_7);
  let v400_10: Path = concat_path(&(*CONSTANT_20),&(*p1));
  let v400_11: Space = singleton(&(v400_10));
  drop(v400_10);
  let v400_12: Space = unite(&(v400_8),&(v400_11));
  drop(v400_8);
  drop(v400_11);
  let v400_14: Path = concat_path(&(*CONSTANT_21),&(*p2));
  let v400_15: Space = singleton(&(v400_14));
  drop(v400_14);
  let v400_16: Space = unite(&(v400_12),&(v400_15));
  drop(v400_12);
  drop(v400_15);
  (v400_16).clone()
}

fn routine_48(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v401_9: Path = concat_path(&(*CONSTANT_23),&(*p2));
  let v401_10: Space = singleton(&(v401_9));
  drop(v401_9);
  let v401_11: Space = unite(&(*CONSTANT_26),&(v401_10));
  drop(v401_10);
  let v401_14: Path = concat_path(&(*CONSTANT_21),&(*p1));
  let v401_15: Space = singleton(&(v401_14));
  drop(v401_14);
  let mut v401_16 = Space::new();
  let mut v401_16_cursor = (*s0).read_zipper();
  for v401_16_byte in v401_16_cursor.child_mask().iter() {
    v401_16_cursor.descend_to_byte(v401_16_byte);
    let v401_16_tail = v401_16_cursor.make_map();
    v401_16_cursor.ascend(1);
    let v401_16_head = Path::from_slice(&[v401_16_byte]);
    let v402_2: Space = singleton(&(v401_16_head));
    let v402_3: Space = intersect(&(*CONSTANT_7),&(v402_2));
    let v402_4: Space = if has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
    drop(v402_3);
    let v402_5: Space = subtract(&(*CONSTANT_0),&(v402_4));
    drop(v402_4);
    let v402_8: Space = if (v402_5).is_empty() { Space::new() } else {
      let v403_6: Path = concat_path(&(*p0),&(v401_16_head));
      let v403_7: Space = routine_48(c, &(v403_6), &(*p1), &(*p2), &(v401_16_tail));
      compose(&(v402_5),&(v403_7))
    };
    drop(v402_5);
    let v402_9: Space = intersect(&(*CONSTANT_7),&(v402_2));
    drop(v402_2);
    let v402_10: Space = if has_head(&(v402_9)) { singleton(&[]) } else { Space::new() };
    drop(v402_9);
    let v402_15: Space = if (v402_10).is_empty() { Space::new() } else {
      let v404_6: Path = concat_path(&(*p0),&(v401_16_head));
      let v404_11: Path = concat_path(&(*CONSTANT_22),&(v404_6));
      drop(v404_6);
      let v404_12: Space = singleton(&(v404_11));
      drop(v404_11);
      let v404_13: Space = unite(&(v401_11),&(v404_12));
      drop(v404_12);
      let v404_14: Space = unite(&(v404_13),&(v401_15));
      drop(v404_13);
      compose(&(v402_10),&(v404_14))
    };
    drop(v402_10);
    let v402_16: Space = unite(&(v402_8),&(v402_15));
    drop(v402_15);
    v401_16.join_into((v402_16).clone());
  }
  drop(v401_16_cursor);
  drop(v401_11);
  drop(v401_15);
  (v401_16).clone()
}

fn routine_49(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v405_6: Path = concat_path(&(*CONSTANT_23),&(*p2));
  let v405_7: Space = singleton(&(v405_6));
  drop(v405_6);
  let v405_8: Space = unite(&(*CONSTANT_26),&(v405_7));
  drop(v405_7);
  let v405_10: Path = concat_path(&(*CONSTANT_22),&(*p0));
  let v405_11: Space = singleton(&(v405_10));
  drop(v405_10);
  let v405_12: Space = unite(&(v405_8),&(v405_11));
  drop(v405_8);
  drop(v405_11);
  let v405_14: Path = concat_path(&(*CONSTANT_21),&(*p1));
  let v405_15: Space = singleton(&(v405_14));
  drop(v405_14);
  let v405_16: Space = unite(&(v405_12),&(v405_15));
  drop(v405_12);
  drop(v405_15);
  (v405_16).clone()
}

fn routine_50(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v406_9: Path = concat_path(&(*CONSTANT_23),&(*p2));
  let v406_10: Space = singleton(&(v406_9));
  drop(v406_9);
  let v406_11: Space = unite(&(*CONSTANT_27),&(v406_10));
  drop(v406_10);
  let v406_14: Path = concat_path(&(*CONSTANT_20),&(*p1));
  let v406_15: Space = singleton(&(v406_14));
  drop(v406_14);
  let mut v406_16 = Space::new();
  let mut v406_16_cursor = (*s0).read_zipper();
  for v406_16_byte in v406_16_cursor.child_mask().iter() {
    v406_16_cursor.descend_to_byte(v406_16_byte);
    let v406_16_tail = v406_16_cursor.make_map();
    v406_16_cursor.ascend(1);
    let v406_16_head = Path::from_slice(&[v406_16_byte]);
    let v407_2: Space = singleton(&(v406_16_head));
    let v407_3: Space = intersect(&(*CONSTANT_7),&(v407_2));
    let v407_4: Space = if has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
    drop(v407_3);
    let v407_5: Space = subtract(&(*CONSTANT_0),&(v407_4));
    drop(v407_4);
    let v407_8: Space = if (v407_5).is_empty() { Space::new() } else {
      let v408_6: Path = concat_path(&(*p0),&(v406_16_head));
      let v408_7: Space = routine_50(c, &(v408_6), &(*p1), &(*p2), &(v406_16_tail));
      compose(&(v407_5),&(v408_7))
    };
    drop(v407_5);
    let v407_9: Space = intersect(&(*CONSTANT_7),&(v407_2));
    drop(v407_2);
    let v407_10: Space = if has_head(&(v407_9)) { singleton(&[]) } else { Space::new() };
    drop(v407_9);
    let v407_15: Space = if (v407_10).is_empty() { Space::new() } else {
      let v409_6: Path = concat_path(&(*p0),&(v406_16_head));
      let v409_11: Path = concat_path(&(*CONSTANT_22),&(v409_6));
      drop(v409_6);
      let v409_12: Space = singleton(&(v409_11));
      drop(v409_11);
      let v409_13: Space = unite(&(v406_11),&(v409_12));
      drop(v409_12);
      let v409_14: Space = unite(&(v409_13),&(v406_15));
      drop(v409_13);
      compose(&(v407_10),&(v409_14))
    };
    drop(v407_10);
    let v407_16: Space = unite(&(v407_8),&(v407_15));
    drop(v407_15);
    v406_16.join_into((v407_16).clone());
  }
  drop(v406_16_cursor);
  drop(v406_11);
  drop(v406_15);
  (v406_16).clone()
}

fn routine_51(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v410_6: Path = concat_path(&(*CONSTANT_23),&(*p2));
  let v410_7: Space = singleton(&(v410_6));
  drop(v410_6);
  let v410_8: Space = unite(&(*CONSTANT_27),&(v410_7));
  drop(v410_7);
  let v410_10: Path = concat_path(&(*CONSTANT_22),&(*p0));
  let v410_11: Space = singleton(&(v410_10));
  drop(v410_10);
  let v410_12: Space = unite(&(v410_8),&(v410_11));
  drop(v410_8);
  drop(v410_11);
  let v410_14: Path = concat_path(&(*CONSTANT_20),&(*p1));
  let v410_15: Space = singleton(&(v410_14));
  drop(v410_14);
  let v410_16: Space = unite(&(v410_12),&(v410_15));
  drop(v410_12);
  drop(v410_15);
  (v410_16).clone()
}

fn routine_52(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v411_10 = Space::new();
  let mut v411_10_cursor = (*s0).read_zipper();
  for v411_10_byte in v411_10_cursor.child_mask().iter() {
    v411_10_cursor.descend_to_byte(v411_10_byte);
    let v411_10_tail = v411_10_cursor.make_map();
    v411_10_cursor.ascend(1);
    let v411_10_head = Path::from_slice(&[v411_10_byte]);
    let v412_2: Space = singleton(&(v411_10_head));
    let v412_3: Space = intersect(&(*CONSTANT_7),&(v412_2));
    let v412_4: Space = if has_head(&(v412_3)) { singleton(&[]) } else { Space::new() };
    drop(v412_3);
    let v412_5: Space = subtract(&(*CONSTANT_0),&(v412_4));
    drop(v412_4);
    let v412_8: Space = if (v412_5).is_empty() { Space::new() } else {
      let v413_6: Path = concat_path(&(*p0),&(v411_10_head));
      let v413_7: Space = routine_52(c, &(v413_6), &(*p1), &(v411_10_tail));
      compose(&(v412_5),&(v413_7))
    };
    drop(v412_5);
    let v412_9: Space = intersect(&(*CONSTANT_7),&(v412_2));
    drop(v412_2);
    let v412_10: Space = if has_head(&(v412_9)) { singleton(&[]) } else { Space::new() };
    drop(v412_9);
    let v412_14: Space = if (v412_10).is_empty() { Space::new() } else {
      let mut v414_11 = Space::new();
      let mut v414_11_cursor = (v411_10_tail).read_zipper();
      for v414_11_byte in v414_11_cursor.child_mask().iter() {
        v414_11_cursor.descend_to_byte(v414_11_byte);
        let v414_11_tail = v414_11_cursor.make_map();
        v414_11_cursor.ascend(1);
        let v414_11_head = Path::from_slice(&[v414_11_byte]);
        let v415_2: Space = singleton(&(v414_11_head));
        let v415_3: Space = intersect(&(*CONSTANT_7),&(v415_2));
        let v415_4: Space = if has_head(&(v415_3)) { singleton(&[]) } else { Space::new() };
        drop(v415_3);
        let v415_5: Space = subtract(&(*CONSTANT_0),&(v415_4));
        drop(v415_4);
        let v415_7: Space = if (v415_5).is_empty() { Space::new() } else {
          let v416_6: Space = routine_56(c, &(v414_11_head), &(v414_11_tail));
          compose(&(v415_5),&(v416_6))
        };
        drop(v415_5);
        let v415_8: Space = intersect(&(*CONSTANT_7),&(v415_2));
        drop(v415_2);
        let v415_9: Space = if has_head(&(v415_8)) { singleton(&[]) } else { Space::new() };
        drop(v415_8);
        let v415_11: Space = if (v415_9).is_empty() { Space::new() } else {
          let v417_10: Space = routine_57(c, &(v414_11_head), &(v414_11_tail));
          compose(&(v415_9),&(v417_10))
        };
        drop(v415_9);
        let v415_12: Space = unite(&(v415_7),&(v415_11));
        v414_11.join_into((v415_12).clone());
      }
      drop(v414_11_cursor);
      let v414_12: Space = raffine(&(*CONSTANT_28),&(v414_11));
      let v414_13: Space = unite(&(v414_12),&(v411_10_tail));
      compose(&(v412_10),&(v414_13))
    };
    drop(v412_10);
    let v418_6: Path = concat_path(&(*p0),&(v411_10_head));
    let v412_15: Path = concat_path(&(*p1),&(v418_6));
    let v412_16: Space = wrap(&(v412_14),&(v412_15));
    drop(v412_15);
    let v412_17: Space = unite(&(v412_8),&(v412_16));
    v411_10.join_into((v412_17).clone());
  }
  drop(v411_10_cursor);
  (v411_10).clone()
}

fn routine_53(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v419_10 = Space::new();
  let mut v419_10_cursor = (*s0).read_zipper();
  for v419_10_byte in v419_10_cursor.child_mask().iter() {
    v419_10_cursor.descend_to_byte(v419_10_byte);
    let v419_10_tail = v419_10_cursor.make_map();
    v419_10_cursor.ascend(1);
    let v419_10_head = Path::from_slice(&[v419_10_byte]);
    let v420_2: Space = singleton(&(v419_10_head));
    let v420_3: Space = intersect(&(*CONSTANT_7),&(v420_2));
    let v420_4: Space = if has_head(&(v420_3)) { singleton(&[]) } else { Space::new() };
    drop(v420_3);
    let v420_5: Space = subtract(&(*CONSTANT_0),&(v420_4));
    drop(v420_4);
    let v420_7: Space = if (v420_5).is_empty() { Space::new() } else {
      let mut v421_6 = Space::new();
      let mut v421_6_cursor = (v419_10_tail).read_zipper();
      for v421_6_byte in v421_6_cursor.child_mask().iter() {
        v421_6_cursor.descend_to_byte(v421_6_byte);
        let v421_6_tail = v421_6_cursor.make_map();
        v421_6_cursor.ascend(1);
        let v421_6_head = Path::from_slice(&[v421_6_byte]);
        let v422_2: Space = singleton(&(v421_6_head));
        let v422_3: Space = intersect(&(*CONSTANT_7),&(v422_2));
        let v422_4: Space = if has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
        drop(v422_3);
        let v422_5: Space = subtract(&(*CONSTANT_0),&(v422_4));
        drop(v422_4);
        let v422_8: Space = if (v422_5).is_empty() { Space::new() } else {
          let v423_6: Path = concat_path(&(v419_10_head),&(v421_6_head));
          let v423_7: Space = routine_56(c, &(v423_6), &(v421_6_tail));
          compose(&(v422_5),&(v423_7))
        };
        drop(v422_5);
        let v422_9: Space = intersect(&(*CONSTANT_7),&(v422_2));
        drop(v422_2);
        let v422_10: Space = if has_head(&(v422_9)) { singleton(&[]) } else { Space::new() };
        drop(v422_9);
        let v422_12: Space = if (v422_10).is_empty() { Space::new() } else {
          let v424_6: Path = concat_path(&(v419_10_head),&(v421_6_head));
          let v424_11: Space = routine_57(c, &(v424_6), &(v421_6_tail));
          drop(v424_6);
          compose(&(v422_10),&(v424_11))
        };
        drop(v422_10);
        let v422_13: Space = unite(&(v422_8),&(v422_12));
        v421_6.join_into((v422_13).clone());
      }
      drop(v421_6_cursor);
      compose(&(v420_5),&(v421_6))
    };
    drop(v420_5);
    let v420_8: Space = intersect(&(*CONSTANT_7),&(v420_2));
    let v420_9: Space = if has_head(&(v420_8)) { singleton(&[]) } else { Space::new() };
    drop(v420_8);
    let v420_10: Space = compose(&(v420_9),&(v420_2));
    drop(v420_2);
    drop(v420_9);
    let v420_11: Space = unite(&(v420_7),&(v420_10));
    drop(v420_10);
    v419_10.join_into((v420_11).clone());
  }
  drop(v419_10_cursor);
  let v419_11: Space = raffine(&(*CONSTANT_28),&(v419_10));
  let v419_12: Space = unite(&(v419_11),&(*s0));
  let v419_13: Path = concat_path(&(*p1),&(*p0));
  let v419_14: Space = wrap(&(v419_12),&(v419_13));
  drop(v419_13);
  (v419_14).clone()
}

fn routine_54(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v425_10 = Space::new();
  let mut v425_10_cursor = (*s0).read_zipper();
  for v425_10_byte in v425_10_cursor.child_mask().iter() {
    v425_10_cursor.descend_to_byte(v425_10_byte);
    let v425_10_tail = v425_10_cursor.make_map();
    v425_10_cursor.ascend(1);
    let v425_10_head = Path::from_slice(&[v425_10_byte]);
    let v426_2: Space = singleton(&(v425_10_head));
    let v426_3: Space = intersect(&(*CONSTANT_7),&(v426_2));
    let v426_4: Space = if has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
    drop(v426_3);
    let v426_5: Space = subtract(&(*CONSTANT_0),&(v426_4));
    drop(v426_4);
    let v426_8: Space = if (v426_5).is_empty() { Space::new() } else {
      let v427_6: Path = concat_path(&(*p0),&(v425_10_head));
      let v427_7: Space = routine_54(c, &(v427_6), &(*p1), &(v425_10_tail));
      compose(&(v426_5),&(v427_7))
    };
    drop(v426_5);
    let v426_9: Space = intersect(&(*CONSTANT_7),&(v426_2));
    drop(v426_2);
    let v426_10: Space = if has_head(&(v426_9)) { singleton(&[]) } else { Space::new() };
    drop(v426_9);
    let v426_14: Space = if (v426_10).is_empty() { Space::new() } else {
      let mut v428_11 = Space::new();
      let mut v428_11_cursor = (v425_10_tail).read_zipper();
      for v428_11_byte in v428_11_cursor.child_mask().iter() {
        v428_11_cursor.descend_to_byte(v428_11_byte);
        let v428_11_tail = v428_11_cursor.make_map();
        v428_11_cursor.ascend(1);
        let v428_11_head = Path::from_slice(&[v428_11_byte]);
        let v429_2: Space = singleton(&(v428_11_head));
        let v429_3: Space = intersect(&(*CONSTANT_7),&(v429_2));
        let v429_4: Space = if has_head(&(v429_3)) { singleton(&[]) } else { Space::new() };
        drop(v429_3);
        let v429_5: Space = subtract(&(*CONSTANT_0),&(v429_4));
        drop(v429_4);
        let v429_7: Space = if (v429_5).is_empty() { Space::new() } else {
          let v430_6: Space = routine_58(c, &(v428_11_head), &(v428_11_tail));
          compose(&(v429_5),&(v430_6))
        };
        drop(v429_5);
        let v429_8: Space = intersect(&(*CONSTANT_7),&(v429_2));
        drop(v429_2);
        let v429_9: Space = if has_head(&(v429_8)) { singleton(&[]) } else { Space::new() };
        drop(v429_8);
        let v429_11: Space = if (v429_9).is_empty() { Space::new() } else {
          let v431_10: Space = routine_59(c, &(v428_11_head), &(v428_11_tail));
          compose(&(v429_9),&(v431_10))
        };
        drop(v429_9);
        let v429_12: Space = unite(&(v429_7),&(v429_11));
        v428_11.join_into((v429_12).clone());
      }
      drop(v428_11_cursor);
      let v428_12: Space = raffine(&(*CONSTANT_28),&(v428_11));
      let v428_13: Space = unite(&(v428_12),&(v425_10_tail));
      compose(&(v426_10),&(v428_13))
    };
    drop(v426_10);
    let v432_6: Path = concat_path(&(*p0),&(v425_10_head));
    let v426_15: Path = concat_path(&(*p1),&(v432_6));
    let v426_16: Space = wrap(&(v426_14),&(v426_15));
    drop(v426_15);
    let v426_17: Space = unite(&(v426_8),&(v426_16));
    v425_10.join_into((v426_17).clone());
  }
  drop(v425_10_cursor);
  (v425_10).clone()
}

fn routine_55(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v433_10 = Space::new();
  let mut v433_10_cursor = (*s0).read_zipper();
  for v433_10_byte in v433_10_cursor.child_mask().iter() {
    v433_10_cursor.descend_to_byte(v433_10_byte);
    let v433_10_tail = v433_10_cursor.make_map();
    v433_10_cursor.ascend(1);
    let v433_10_head = Path::from_slice(&[v433_10_byte]);
    let v434_2: Space = singleton(&(v433_10_head));
    let v434_3: Space = intersect(&(*CONSTANT_7),&(v434_2));
    let v434_4: Space = if has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
    drop(v434_3);
    let v434_5: Space = subtract(&(*CONSTANT_0),&(v434_4));
    drop(v434_4);
    let v434_7: Space = if (v434_5).is_empty() { Space::new() } else {
      let mut v435_6 = Space::new();
      let mut v435_6_cursor = (v433_10_tail).read_zipper();
      for v435_6_byte in v435_6_cursor.child_mask().iter() {
        v435_6_cursor.descend_to_byte(v435_6_byte);
        let v435_6_tail = v435_6_cursor.make_map();
        v435_6_cursor.ascend(1);
        let v435_6_head = Path::from_slice(&[v435_6_byte]);
        let v436_2: Space = singleton(&(v435_6_head));
        let v436_3: Space = intersect(&(*CONSTANT_7),&(v436_2));
        let v436_4: Space = if has_head(&(v436_3)) { singleton(&[]) } else { Space::new() };
        drop(v436_3);
        let v436_5: Space = subtract(&(*CONSTANT_0),&(v436_4));
        drop(v436_4);
        let v436_8: Space = if (v436_5).is_empty() { Space::new() } else {
          let v437_6: Path = concat_path(&(v433_10_head),&(v435_6_head));
          let v437_7: Space = routine_58(c, &(v437_6), &(v435_6_tail));
          compose(&(v436_5),&(v437_7))
        };
        drop(v436_5);
        let v436_9: Space = intersect(&(*CONSTANT_7),&(v436_2));
        drop(v436_2);
        let v436_10: Space = if has_head(&(v436_9)) { singleton(&[]) } else { Space::new() };
        drop(v436_9);
        let v436_12: Space = if (v436_10).is_empty() { Space::new() } else {
          let v438_6: Path = concat_path(&(v433_10_head),&(v435_6_head));
          let v438_11: Space = routine_59(c, &(v438_6), &(v435_6_tail));
          drop(v438_6);
          compose(&(v436_10),&(v438_11))
        };
        drop(v436_10);
        let v436_13: Space = unite(&(v436_8),&(v436_12));
        v435_6.join_into((v436_13).clone());
      }
      drop(v435_6_cursor);
      compose(&(v434_5),&(v435_6))
    };
    drop(v434_5);
    let v434_8: Space = intersect(&(*CONSTANT_7),&(v434_2));
    let v434_9: Space = if has_head(&(v434_8)) { singleton(&[]) } else { Space::new() };
    drop(v434_8);
    let v434_10: Space = compose(&(v434_9),&(v434_2));
    drop(v434_2);
    drop(v434_9);
    let v434_11: Space = unite(&(v434_7),&(v434_10));
    drop(v434_10);
    v433_10.join_into((v434_11).clone());
  }
  drop(v433_10_cursor);
  let v433_11: Space = raffine(&(*CONSTANT_28),&(v433_10));
  let v433_12: Space = unite(&(v433_11),&(*s0));
  let v433_13: Path = concat_path(&(*p1),&(*p0));
  let v433_14: Space = wrap(&(v433_12),&(v433_13));
  drop(v433_13);
  (v433_14).clone()
}

fn routine_56(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v439_5 = Space::new();
  let mut v439_5_cursor = (*s0).read_zipper();
  for v439_5_byte in v439_5_cursor.child_mask().iter() {
    v439_5_cursor.descend_to_byte(v439_5_byte);
    let v439_5_tail = v439_5_cursor.make_map();
    v439_5_cursor.ascend(1);
    let v439_5_head = Path::from_slice(&[v439_5_byte]);
    let v440_2: Space = singleton(&(v439_5_head));
    let v440_3: Space = intersect(&(*CONSTANT_7),&(v440_2));
    let v440_4: Space = if has_head(&(v440_3)) { singleton(&[]) } else { Space::new() };
    drop(v440_3);
    let v440_5: Space = subtract(&(*CONSTANT_0),&(v440_4));
    drop(v440_4);
    let v440_8: Space = if (v440_5).is_empty() { Space::new() } else {
      let v441_6: Path = concat_path(&(*p0),&(v439_5_head));
      let v441_7: Space = routine_56(c, &(v441_6), &(v439_5_tail));
      compose(&(v440_5),&(v441_7))
    };
    drop(v440_5);
    let v440_9: Space = intersect(&(*CONSTANT_7),&(v440_2));
    drop(v440_2);
    let v440_10: Space = if has_head(&(v440_9)) { singleton(&[]) } else { Space::new() };
    drop(v440_9);
    let v440_12: Space = if (v440_10).is_empty() { Space::new() } else {
      let v442_6: Path = concat_path(&(*p0),&(v439_5_head));
      let v442_11: Space = singleton(&(v442_6));
      drop(v442_6);
      compose(&(v440_10),&(v442_11))
    };
    drop(v440_10);
    let v440_13: Space = unite(&(v440_8),&(v440_12));
    drop(v440_12);
    v439_5.join_into((v440_13).clone());
  }
  drop(v439_5_cursor);
  (v439_5).clone()
}

fn routine_57(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v443_2: Space = singleton(&(*p0));
  (v443_2).clone()
}

fn routine_58(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v444_5 = Space::new();
  let mut v444_5_cursor = (*s0).read_zipper();
  for v444_5_byte in v444_5_cursor.child_mask().iter() {
    v444_5_cursor.descend_to_byte(v444_5_byte);
    let v444_5_tail = v444_5_cursor.make_map();
    v444_5_cursor.ascend(1);
    let v444_5_head = Path::from_slice(&[v444_5_byte]);
    let v445_2: Space = singleton(&(v444_5_head));
    let v445_3: Space = intersect(&(*CONSTANT_7),&(v445_2));
    let v445_4: Space = if has_head(&(v445_3)) { singleton(&[]) } else { Space::new() };
    drop(v445_3);
    let v445_5: Space = subtract(&(*CONSTANT_0),&(v445_4));
    drop(v445_4);
    let v445_8: Space = if (v445_5).is_empty() { Space::new() } else {
      let v446_6: Path = concat_path(&(*p0),&(v444_5_head));
      let v446_7: Space = routine_58(c, &(v446_6), &(v444_5_tail));
      compose(&(v445_5),&(v446_7))
    };
    drop(v445_5);
    let v445_9: Space = intersect(&(*CONSTANT_7),&(v445_2));
    drop(v445_2);
    let v445_10: Space = if has_head(&(v445_9)) { singleton(&[]) } else { Space::new() };
    drop(v445_9);
    let v445_12: Space = if (v445_10).is_empty() { Space::new() } else {
      let v447_6: Path = concat_path(&(*p0),&(v444_5_head));
      let v447_11: Space = singleton(&(v447_6));
      drop(v447_6);
      compose(&(v445_10),&(v447_11))
    };
    drop(v445_10);
    let v445_13: Space = unite(&(v445_8),&(v445_12));
    drop(v445_12);
    v444_5.join_into((v445_13).clone());
  }
  drop(v444_5_cursor);
  (v444_5).clone()
}

fn routine_59(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v448_2: Space = singleton(&(*p0));
  (v448_2).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
