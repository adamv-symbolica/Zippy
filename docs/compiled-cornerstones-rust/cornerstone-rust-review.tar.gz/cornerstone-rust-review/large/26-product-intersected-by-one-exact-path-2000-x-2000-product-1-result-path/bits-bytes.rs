#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>, s2: Option<&Space>) -> Space {
  let v0_3: Space = if (*s0.expect("unbound native input")).is_empty() { Space::new() } else {
    compose(&(*s0.expect("unbound native input")),&(*s1.expect("unbound native input")))
  };
  let v0_4: Space = intersect(&(v0_3),&(*s2.expect("unbound native input")));
  drop(v0_3);
  (v0_4).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1),e.space(2)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
