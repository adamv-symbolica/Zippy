#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,0,1,0,0,1,1]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,0,0,1,0,0,1,1]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,0,1,0,0,1,1]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,0,1,0,0,1,1,1,0,0,0,1,0,0,1,1]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,0,0,1,0,0,1,1,1,0,0,0,1,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = wrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let v0_4: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_1));
  let mut v0_14 = Space::new();
  let mut v0_14_cursor = (v0_4).read_zipper();
  for v0_14_byte in v0_14_cursor.child_mask().iter() {
    v0_14_cursor.descend_to_byte(v0_14_byte);
    let v0_14_tail = v0_14_cursor.make_map();
    v0_14_cursor.ascend(1);
    let v0_14_head = Path::from_slice(&[v0_14_byte]);
    let v1_2: Space = singleton(&(v0_14_head));
    let v1_3: Space = intersect(&(*CONSTANT_3),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_2),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_14_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        let v2_6_tail = v2_6_cursor.make_map();
        v2_6_cursor.ascend(1);
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_3),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_2),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_14_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_3),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_14_head),&(v2_6_head));
          let v5_11: Space = routine_2(c, &(v5_6), &(v2_6_tail));
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_3),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_cursor = (v0_14_tail).read_zipper();
      for v6_10_byte in v6_10_cursor.child_mask().iter() {
        v6_10_cursor.descend_to_byte(v6_10_byte);
        let v6_10_tail = v6_10_cursor.make_map();
        v6_10_cursor.ascend(1);
        let v6_10_head = Path::from_slice(&[v6_10_byte]);
        let v7_2: Space = singleton(&(v6_10_head));
        let v7_3: Space = intersect(&(*CONSTANT_3),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_2),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_14_head),&(v6_10_head));
          let v8_7: Space = routine_1(c, &(v8_6), &(v6_10_tail));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_3),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v0_14_head),&(v6_10_head));
          let v9_11: Space = routine_3(c, &(v9_6), &(v6_10_tail));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_10.join_into((v7_13).clone());
      }
      drop(v6_10_cursor);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_14.join_into((v1_12).clone());
  }
  drop(v0_14_cursor);
  drop(v0_4);
  let v0_16: Space = wrap(&(v0_14),&(*CONSTANT_4));
  let v0_17: Space = unite(&(v0_2),&(v0_16));
  drop(v0_2);
  let mut v0_57: Space = (v0_17).clone();
  loop {
    let v10_1: Space = unwrap(&(v0_57),&(*CONSTANT_0));
    let v10_2: Space = unwrap(&(v0_57),&(*CONSTANT_4));
    let v10_3: Space = unite(&(v10_1),&(v10_2));
    let v10_4: Space = wrap(&(v10_3),&(*CONSTANT_0));
    drop(v10_3);
    let v10_5: Space = unwrap(&(v10_1),&(*CONSTANT_5));
    let mut v10_6 = Space::new();
    let mut v10_6_cursor = (v10_5).read_zipper();
    for v10_6_byte in v10_6_cursor.child_mask().iter() {
      v10_6_cursor.descend_to_byte(v10_6_byte);
      let v10_6_tail = v10_6_cursor.make_map();
      v10_6_cursor.ascend(1);
      let v10_6_head = Path::from_slice(&[v10_6_byte]);
      let v11_2: Space = singleton(&(v10_6_head));
      let v11_3: Space = intersect(&(*CONSTANT_3),&(v11_2));
      let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
      drop(v11_3);
      let v11_5: Space = subtract(&(*CONSTANT_2),&(v11_4));
      drop(v11_4);
      let v11_7: Space = if (v11_5).is_empty() { Space::new() } else {
        let mut v12_6 = Space::new();
        let mut v12_6_cursor = (v10_6_tail).read_zipper();
        for v12_6_byte in v12_6_cursor.child_mask().iter() {
          v12_6_cursor.descend_to_byte(v12_6_byte);
          let v12_6_tail = v12_6_cursor.make_map();
          v12_6_cursor.ascend(1);
          let v12_6_head = Path::from_slice(&[v12_6_byte]);
          let v13_2: Space = singleton(&(v12_6_head));
          let v13_3: Space = intersect(&(*CONSTANT_3),&(v13_2));
          let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
          drop(v13_3);
          let v13_5: Space = subtract(&(*CONSTANT_2),&(v13_4));
          drop(v13_4);
          let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
            let v14_6: Path = concat_path(&(v10_6_head),&(v12_6_head));
            let v14_7: Space = routine_4(c, &(v14_6), &(v12_6_tail), &(v0_57));
            compose(&(v13_5),&(v14_7))
          };
          drop(v13_5);
          let v13_9: Space = intersect(&(*CONSTANT_3),&(v13_2));
          drop(v13_2);
          let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
          drop(v13_9);
          let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
            let v15_6: Path = concat_path(&(v10_6_head),&(v12_6_head));
            let v15_11: Space = routine_5(c, &(v15_6), &(v12_6_tail), &(v0_57));
            drop(v15_6);
            compose(&(v13_10),&(v15_11))
          };
          drop(v13_10);
          let v13_13: Space = unite(&(v13_8),&(v13_12));
          v12_6.join_into((v13_13).clone());
        }
        drop(v12_6_cursor);
        compose(&(v11_5),&(v12_6))
      };
      drop(v11_5);
      let v11_8: Space = intersect(&(*CONSTANT_3),&(v11_2));
      drop(v11_2);
      let v11_9: Space = if has_head(&(v11_8)) { singleton(&[]) } else { Space::new() };
      drop(v11_8);
      let v11_11: Space = if (v11_9).is_empty() { Space::new() } else {
        let mut v16_10 = Space::new();
        let mut v16_10_cursor = (v10_6_tail).read_zipper();
        for v16_10_byte in v16_10_cursor.child_mask().iter() {
          v16_10_cursor.descend_to_byte(v16_10_byte);
          let v16_10_tail = v16_10_cursor.make_map();
          v16_10_cursor.ascend(1);
          let v16_10_head = Path::from_slice(&[v16_10_byte]);
          let v17_2: Space = singleton(&(v16_10_head));
          let v17_3: Space = intersect(&(*CONSTANT_3),&(v17_2));
          let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
          drop(v17_3);
          let v17_5: Space = subtract(&(*CONSTANT_2),&(v17_4));
          drop(v17_4);
          let v17_8: Space = if (v17_5).is_empty() { Space::new() } else {
            let v18_6: Path = concat_path(&(v10_6_head),&(v16_10_head));
            let v18_7: Space = routine_4(c, &(v18_6), &(v16_10_tail), &(v0_57));
            compose(&(v17_5),&(v18_7))
          };
          drop(v17_5);
          let v17_9: Space = intersect(&(*CONSTANT_3),&(v17_2));
          drop(v17_2);
          let v17_10: Space = if has_head(&(v17_9)) { singleton(&[]) } else { Space::new() };
          drop(v17_9);
          let v17_12: Space = if (v17_10).is_empty() { Space::new() } else {
            let v19_6: Path = concat_path(&(v10_6_head),&(v16_10_head));
            let v19_11: Space = routine_6(c, &(v19_6), &(v16_10_tail), &(v0_57));
            drop(v19_6);
            compose(&(v17_10),&(v19_11))
          };
          drop(v17_10);
          let v17_13: Space = unite(&(v17_8),&(v17_12));
          v16_10.join_into((v17_13).clone());
        }
        drop(v16_10_cursor);
        compose(&(v11_9),&(v16_10))
      };
      drop(v11_9);
      let v11_12: Space = unite(&(v11_7),&(v11_11));
      v10_6.join_into((v11_12).clone());
    }
    drop(v10_6_cursor);
    drop(v10_5);
    let v10_7: Space = unwrap(&(v10_1),&(*CONSTANT_1));
    drop(v10_1);
    let mut v10_8 = Space::new();
    let mut v10_8_cursor = (v10_7).read_zipper();
    for v10_8_byte in v10_8_cursor.child_mask().iter() {
      v10_8_cursor.descend_to_byte(v10_8_byte);
      let v10_8_tail = v10_8_cursor.make_map();
      v10_8_cursor.ascend(1);
      let v10_8_head = Path::from_slice(&[v10_8_byte]);
      let v20_2: Space = singleton(&(v10_8_head));
      let v20_3: Space = intersect(&(*CONSTANT_3),&(v20_2));
      let v20_4: Space = if has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
      drop(v20_3);
      let v20_5: Space = subtract(&(*CONSTANT_2),&(v20_4));
      drop(v20_4);
      let v20_7: Space = if (v20_5).is_empty() { Space::new() } else {
        let mut v21_6 = Space::new();
        let mut v21_6_cursor = (v10_8_tail).read_zipper();
        for v21_6_byte in v21_6_cursor.child_mask().iter() {
          v21_6_cursor.descend_to_byte(v21_6_byte);
          let v21_6_tail = v21_6_cursor.make_map();
          v21_6_cursor.ascend(1);
          let v21_6_head = Path::from_slice(&[v21_6_byte]);
          let v22_2: Space = singleton(&(v21_6_head));
          let v22_3: Space = intersect(&(*CONSTANT_3),&(v22_2));
          let v22_4: Space = if has_head(&(v22_3)) { singleton(&[]) } else { Space::new() };
          drop(v22_3);
          let v22_5: Space = subtract(&(*CONSTANT_2),&(v22_4));
          drop(v22_4);
          let v22_8: Space = if (v22_5).is_empty() { Space::new() } else {
            let v23_6: Path = concat_path(&(v10_8_head),&(v21_6_head));
            let v23_7: Space = routine_7(c, &(v23_6), &(v21_6_tail));
            compose(&(v22_5),&(v23_7))
          };
          drop(v22_5);
          let v22_9: Space = intersect(&(*CONSTANT_3),&(v22_2));
          drop(v22_2);
          let v22_10: Space = if has_head(&(v22_9)) { singleton(&[]) } else { Space::new() };
          drop(v22_9);
          let v22_12: Space = if (v22_10).is_empty() { Space::new() } else {
            let v24_6: Path = concat_path(&(v10_8_head),&(v21_6_head));
            let v24_11: Space = routine_8(c, &(v24_6), &(v21_6_tail));
            drop(v24_6);
            compose(&(v22_10),&(v24_11))
          };
          drop(v22_10);
          let v22_13: Space = unite(&(v22_8),&(v22_12));
          v21_6.join_into((v22_13).clone());
        }
        drop(v21_6_cursor);
        compose(&(v20_5),&(v21_6))
      };
      drop(v20_5);
      let v20_8: Space = intersect(&(*CONSTANT_3),&(v20_2));
      drop(v20_2);
      let v20_9: Space = if has_head(&(v20_8)) { singleton(&[]) } else { Space::new() };
      drop(v20_8);
      let v20_11: Space = if (v20_9).is_empty() { Space::new() } else {
        let mut v25_10 = Space::new();
        let mut v25_10_cursor = (v10_8_tail).read_zipper();
        for v25_10_byte in v25_10_cursor.child_mask().iter() {
          v25_10_cursor.descend_to_byte(v25_10_byte);
          let v25_10_tail = v25_10_cursor.make_map();
          v25_10_cursor.ascend(1);
          let v25_10_head = Path::from_slice(&[v25_10_byte]);
          let v26_2: Space = singleton(&(v25_10_head));
          let v26_3: Space = intersect(&(*CONSTANT_3),&(v26_2));
          let v26_4: Space = if has_head(&(v26_3)) { singleton(&[]) } else { Space::new() };
          drop(v26_3);
          let v26_5: Space = subtract(&(*CONSTANT_2),&(v26_4));
          drop(v26_4);
          let v26_8: Space = if (v26_5).is_empty() { Space::new() } else {
            let v27_6: Path = concat_path(&(v10_8_head),&(v25_10_head));
            let v27_7: Space = routine_7(c, &(v27_6), &(v25_10_tail));
            compose(&(v26_5),&(v27_7))
          };
          drop(v26_5);
          let v26_9: Space = intersect(&(*CONSTANT_3),&(v26_2));
          drop(v26_2);
          let v26_10: Space = if has_head(&(v26_9)) { singleton(&[]) } else { Space::new() };
          drop(v26_9);
          let v26_12: Space = if (v26_10).is_empty() { Space::new() } else {
            let v28_6: Path = concat_path(&(v10_8_head),&(v25_10_head));
            let v28_11: Space = routine_9(c, &(v28_6), &(v25_10_tail));
            drop(v28_6);
            compose(&(v26_10),&(v28_11))
          };
          drop(v26_10);
          let v26_13: Space = unite(&(v26_8),&(v26_12));
          v25_10.join_into((v26_13).clone());
        }
        drop(v25_10_cursor);
        compose(&(v20_9),&(v25_10))
      };
      drop(v20_9);
      let v20_12: Space = unite(&(v20_7),&(v20_11));
      v10_8.join_into((v20_12).clone());
    }
    drop(v10_8_cursor);
    drop(v10_7);
    let v10_9: Space = unite(&(v10_6),&(v10_8));
    let v10_10: Space = unwrap(&(v10_2),&(*CONSTANT_5));
    drop(v10_2);
    let mut v10_11 = Space::new();
    let mut v10_11_cursor = (v10_10).read_zipper();
    for v10_11_byte in v10_11_cursor.child_mask().iter() {
      v10_11_cursor.descend_to_byte(v10_11_byte);
      let v10_11_tail = v10_11_cursor.make_map();
      v10_11_cursor.ascend(1);
      let v10_11_head = Path::from_slice(&[v10_11_byte]);
      let v29_2: Space = singleton(&(v10_11_head));
      let v29_3: Space = intersect(&(*CONSTANT_3),&(v29_2));
      let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
      drop(v29_3);
      let v29_5: Space = subtract(&(*CONSTANT_2),&(v29_4));
      drop(v29_4);
      let v29_7: Space = if (v29_5).is_empty() { Space::new() } else {
        let mut v30_6 = Space::new();
        let mut v30_6_cursor = (v10_11_tail).read_zipper();
        for v30_6_byte in v30_6_cursor.child_mask().iter() {
          v30_6_cursor.descend_to_byte(v30_6_byte);
          let v30_6_tail = v30_6_cursor.make_map();
          v30_6_cursor.ascend(1);
          let v30_6_head = Path::from_slice(&[v30_6_byte]);
          let v31_2: Space = singleton(&(v30_6_head));
          let v31_3: Space = intersect(&(*CONSTANT_3),&(v31_2));
          let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
          drop(v31_3);
          let v31_5: Space = subtract(&(*CONSTANT_2),&(v31_4));
          drop(v31_4);
          let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
            let v32_6: Path = concat_path(&(v10_11_head),&(v30_6_head));
            let v32_7: Space = routine_10(c, &(v32_6), &(v30_6_tail), &(v0_57));
            compose(&(v31_5),&(v32_7))
          };
          drop(v31_5);
          let v31_9: Space = intersect(&(*CONSTANT_3),&(v31_2));
          drop(v31_2);
          let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
          drop(v31_9);
          let v31_12: Space = if (v31_10).is_empty() { Space::new() } else {
            let v33_6: Path = concat_path(&(v10_11_head),&(v30_6_head));
            let v33_11: Space = routine_11(c, &(v33_6), &(v30_6_tail), &(v0_57));
            drop(v33_6);
            compose(&(v31_10),&(v33_11))
          };
          drop(v31_10);
          let v31_13: Space = unite(&(v31_8),&(v31_12));
          v30_6.join_into((v31_13).clone());
        }
        drop(v30_6_cursor);
        compose(&(v29_5),&(v30_6))
      };
      drop(v29_5);
      let v29_8: Space = intersect(&(*CONSTANT_3),&(v29_2));
      drop(v29_2);
      let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
      drop(v29_8);
      let v29_11: Space = if (v29_9).is_empty() { Space::new() } else {
        let mut v34_10 = Space::new();
        let mut v34_10_cursor = (v10_11_tail).read_zipper();
        for v34_10_byte in v34_10_cursor.child_mask().iter() {
          v34_10_cursor.descend_to_byte(v34_10_byte);
          let v34_10_tail = v34_10_cursor.make_map();
          v34_10_cursor.ascend(1);
          let v34_10_head = Path::from_slice(&[v34_10_byte]);
          let v35_2: Space = singleton(&(v34_10_head));
          let v35_3: Space = intersect(&(*CONSTANT_3),&(v35_2));
          let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
          drop(v35_3);
          let v35_5: Space = subtract(&(*CONSTANT_2),&(v35_4));
          drop(v35_4);
          let v35_8: Space = if (v35_5).is_empty() { Space::new() } else {
            let v36_6: Path = concat_path(&(v10_11_head),&(v34_10_head));
            let v36_7: Space = routine_10(c, &(v36_6), &(v34_10_tail), &(v0_57));
            compose(&(v35_5),&(v36_7))
          };
          drop(v35_5);
          let v35_9: Space = intersect(&(*CONSTANT_3),&(v35_2));
          drop(v35_2);
          let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
          drop(v35_9);
          let v35_12: Space = if (v35_10).is_empty() { Space::new() } else {
            let v37_6: Path = concat_path(&(v10_11_head),&(v34_10_head));
            let v37_11: Space = routine_12(c, &(v37_6), &(v34_10_tail), &(v0_57));
            drop(v37_6);
            compose(&(v35_10),&(v37_11))
          };
          drop(v35_10);
          let v35_13: Space = unite(&(v35_8),&(v35_12));
          v34_10.join_into((v35_13).clone());
        }
        drop(v34_10_cursor);
        compose(&(v29_9),&(v34_10))
      };
      drop(v29_9);
      let v29_12: Space = unite(&(v29_7),&(v29_11));
      v10_11.join_into((v29_12).clone());
    }
    drop(v10_11_cursor);
    let v10_12: Space = unite(&(v10_9),&(v10_11));
    let mut v10_13 = Space::new();
    let mut v10_13_cursor = (v10_10).read_zipper();
    for v10_13_byte in v10_13_cursor.child_mask().iter() {
      v10_13_cursor.descend_to_byte(v10_13_byte);
      let v10_13_tail = v10_13_cursor.make_map();
      v10_13_cursor.ascend(1);
      let v10_13_head = Path::from_slice(&[v10_13_byte]);
      let v38_2: Space = singleton(&(v10_13_head));
      let v38_3: Space = intersect(&(*CONSTANT_3),&(v38_2));
      let v38_4: Space = if has_head(&(v38_3)) { singleton(&[]) } else { Space::new() };
      drop(v38_3);
      let v38_5: Space = subtract(&(*CONSTANT_2),&(v38_4));
      drop(v38_4);
      let v38_7: Space = if (v38_5).is_empty() { Space::new() } else {
        let mut v39_6 = Space::new();
        let mut v39_6_cursor = (v10_13_tail).read_zipper();
        for v39_6_byte in v39_6_cursor.child_mask().iter() {
          v39_6_cursor.descend_to_byte(v39_6_byte);
          let v39_6_tail = v39_6_cursor.make_map();
          v39_6_cursor.ascend(1);
          let v39_6_head = Path::from_slice(&[v39_6_byte]);
          let v40_2: Space = singleton(&(v39_6_head));
          let v40_3: Space = intersect(&(*CONSTANT_3),&(v40_2));
          let v40_4: Space = if has_head(&(v40_3)) { singleton(&[]) } else { Space::new() };
          drop(v40_3);
          let v40_5: Space = subtract(&(*CONSTANT_2),&(v40_4));
          drop(v40_4);
          let v40_8: Space = if (v40_5).is_empty() { Space::new() } else {
            let v41_6: Path = concat_path(&(v10_13_head),&(v39_6_head));
            let v41_7: Space = routine_13(c, &(v41_6), &(v39_6_tail), &(v0_57));
            compose(&(v40_5),&(v41_7))
          };
          drop(v40_5);
          let v40_9: Space = intersect(&(*CONSTANT_3),&(v40_2));
          drop(v40_2);
          let v40_10: Space = if has_head(&(v40_9)) { singleton(&[]) } else { Space::new() };
          drop(v40_9);
          let v40_12: Space = if (v40_10).is_empty() { Space::new() } else {
            let v42_6: Path = concat_path(&(v10_13_head),&(v39_6_head));
            let v42_11: Space = routine_14(c, &(v42_6), &(v39_6_tail), &(v0_57));
            drop(v42_6);
            compose(&(v40_10),&(v42_11))
          };
          drop(v40_10);
          let v40_13: Space = unite(&(v40_8),&(v40_12));
          v39_6.join_into((v40_13).clone());
        }
        drop(v39_6_cursor);
        compose(&(v38_5),&(v39_6))
      };
      drop(v38_5);
      let v38_8: Space = intersect(&(*CONSTANT_3),&(v38_2));
      drop(v38_2);
      let v38_9: Space = if has_head(&(v38_8)) { singleton(&[]) } else { Space::new() };
      drop(v38_8);
      let v38_11: Space = if (v38_9).is_empty() { Space::new() } else {
        let mut v43_10 = Space::new();
        let mut v43_10_cursor = (v10_13_tail).read_zipper();
        for v43_10_byte in v43_10_cursor.child_mask().iter() {
          v43_10_cursor.descend_to_byte(v43_10_byte);
          let v43_10_tail = v43_10_cursor.make_map();
          v43_10_cursor.ascend(1);
          let v43_10_head = Path::from_slice(&[v43_10_byte]);
          let v44_2: Space = singleton(&(v43_10_head));
          let v44_3: Space = intersect(&(*CONSTANT_3),&(v44_2));
          let v44_4: Space = if has_head(&(v44_3)) { singleton(&[]) } else { Space::new() };
          drop(v44_3);
          let v44_5: Space = subtract(&(*CONSTANT_2),&(v44_4));
          drop(v44_4);
          let v44_8: Space = if (v44_5).is_empty() { Space::new() } else {
            let v45_6: Path = concat_path(&(v10_13_head),&(v43_10_head));
            let v45_7: Space = routine_13(c, &(v45_6), &(v43_10_tail), &(v0_57));
            compose(&(v44_5),&(v45_7))
          };
          drop(v44_5);
          let v44_9: Space = intersect(&(*CONSTANT_3),&(v44_2));
          drop(v44_2);
          let v44_10: Space = if has_head(&(v44_9)) { singleton(&[]) } else { Space::new() };
          drop(v44_9);
          let v44_12: Space = if (v44_10).is_empty() { Space::new() } else {
            let v46_6: Path = concat_path(&(v10_13_head),&(v43_10_head));
            let v46_11: Space = routine_15(c, &(v46_6), &(v43_10_tail), &(v0_57));
            drop(v46_6);
            compose(&(v44_10),&(v46_11))
          };
          drop(v44_10);
          let v44_13: Space = unite(&(v44_8),&(v44_12));
          v43_10.join_into((v44_13).clone());
        }
        drop(v43_10_cursor);
        compose(&(v38_9),&(v43_10))
      };
      drop(v38_9);
      let v38_12: Space = unite(&(v38_7),&(v38_11));
      v10_13.join_into((v38_12).clone());
    }
    drop(v10_13_cursor);
    drop(v10_10);
    let v10_14: Space = unite(&(v10_12),&(v10_13));
    let v10_15: Space = unwrap(&(v0_57),&(*CONSTANT_6));
    let v10_16: Space = subtract(&(v10_14),&(v10_15));
    drop(v10_15);
    let v10_17: Space = unwrap(&(v0_57),&(*CONSTANT_7));
    let v10_18: Space = subtract(&(v10_16),&(v10_17));
    drop(v10_17);
    let v10_19: Space = wrap(&(v10_18),&(*CONSTANT_7));
    let v10_20: Space = unite(&(v10_4),&(v10_19));
    drop(v10_4);
    let v10_21: Space = unite(&(v10_20),&(v0_57));
    let v0_57_next = unite(&v0_57,&(v10_21));
    if equal(&v0_57_next,&v0_57) { break; }
    v0_57 = v0_57_next;
  }
  let v0_58: Space = unwrap(&(v0_57),&(*CONSTANT_6));
  (v0_58).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v47_11 = Space::new();
  let mut v47_11_cursor = (*s0).read_zipper();
  for v47_11_byte in v47_11_cursor.child_mask().iter() {
    v47_11_cursor.descend_to_byte(v47_11_byte);
    let v47_11_tail = v47_11_cursor.make_map();
    v47_11_cursor.ascend(1);
    let v47_11_head = Path::from_slice(&[v47_11_byte]);
    let v48_2: Space = singleton(&(v47_11_head));
    let v48_3: Space = intersect(&(*CONSTANT_3),&(v48_2));
    let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
    drop(v48_3);
    let v48_5: Space = subtract(&(*CONSTANT_2),&(v48_4));
    drop(v48_4);
    let v48_8: Space = if (v48_5).is_empty() { Space::new() } else {
      let v49_6: Path = concat_path(&(*p0),&(v47_11_head));
      let mut v49_7 = Space::new();
      let mut v49_7_cursor = (v47_11_tail).read_zipper();
      for v49_7_byte in v49_7_cursor.child_mask().iter() {
        v49_7_cursor.descend_to_byte(v49_7_byte);
        let v49_7_tail = v49_7_cursor.make_map();
        v49_7_cursor.ascend(1);
        let v49_7_head = Path::from_slice(&[v49_7_byte]);
        let v50_2: Space = singleton(&(v49_7_head));
        let v50_3: Space = intersect(&(*CONSTANT_3),&(v50_2));
        let v50_4: Space = if has_head(&(v50_3)) { singleton(&[]) } else { Space::new() };
        drop(v50_3);
        let v50_5: Space = subtract(&(*CONSTANT_2),&(v50_4));
        drop(v50_4);
        let v50_8: Space = if (v50_5).is_empty() { Space::new() } else {
          let v51_6: Path = concat_path(&(v49_6),&(v49_7_head));
          let v51_7: Space = routine_16(c, &(v51_6), &(v49_7_tail));
          compose(&(v50_5),&(v51_7))
        };
        drop(v50_5);
        let v50_9: Space = intersect(&(*CONSTANT_3),&(v50_2));
        drop(v50_2);
        let v50_10: Space = if has_head(&(v50_9)) { singleton(&[]) } else { Space::new() };
        drop(v50_9);
        let v50_12: Space = if (v50_10).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v49_6),&(v49_7_head));
          let v52_11: Space = routine_17(c, &(v52_6), &(v49_7_tail));
          drop(v52_6);
          compose(&(v50_10),&(v52_11))
        };
        drop(v50_10);
        let v50_13: Space = unite(&(v50_8),&(v50_12));
        v49_7.join_into((v50_13).clone());
      }
      drop(v49_7_cursor);
      compose(&(v48_5),&(v49_7))
    };
    drop(v48_5);
    let v48_9: Space = intersect(&(*CONSTANT_3),&(v48_2));
    drop(v48_2);
    let v48_10: Space = if has_head(&(v48_9)) { singleton(&[]) } else { Space::new() };
    drop(v48_9);
    let v48_12: Space = if (v48_10).is_empty() { Space::new() } else {
      let v53_6: Path = concat_path(&(*p0),&(v47_11_head));
      let mut v53_11 = Space::new();
      let mut v53_11_cursor = (v47_11_tail).read_zipper();
      for v53_11_byte in v53_11_cursor.child_mask().iter() {
        v53_11_cursor.descend_to_byte(v53_11_byte);
        let v53_11_tail = v53_11_cursor.make_map();
        v53_11_cursor.ascend(1);
        let v53_11_head = Path::from_slice(&[v53_11_byte]);
        let v54_2: Space = singleton(&(v53_11_head));
        let v54_3: Space = intersect(&(*CONSTANT_3),&(v54_2));
        let v54_4: Space = if has_head(&(v54_3)) { singleton(&[]) } else { Space::new() };
        drop(v54_3);
        let v54_5: Space = subtract(&(*CONSTANT_2),&(v54_4));
        drop(v54_4);
        let v54_8: Space = if (v54_5).is_empty() { Space::new() } else {
          let v55_6: Path = concat_path(&(v53_6),&(v53_11_head));
          let v55_7: Space = routine_16(c, &(v55_6), &(v53_11_tail));
          compose(&(v54_5),&(v55_7))
        };
        drop(v54_5);
        let v54_9: Space = intersect(&(*CONSTANT_3),&(v54_2));
        drop(v54_2);
        let v54_10: Space = if has_head(&(v54_9)) { singleton(&[]) } else { Space::new() };
        drop(v54_9);
        let v54_12: Space = if (v54_10).is_empty() { Space::new() } else {
          let v56_6: Path = concat_path(&(v53_6),&(v53_11_head));
          let v56_11: Space = routine_3(c, &(v56_6), &(v53_11_tail));
          drop(v56_6);
          compose(&(v54_10),&(v56_11))
        };
        drop(v54_10);
        let v54_13: Space = unite(&(v54_8),&(v54_12));
        v53_11.join_into((v54_13).clone());
      }
      drop(v53_11_cursor);
      drop(v53_6);
      compose(&(v48_10),&(v53_11))
    };
    drop(v48_10);
    let v48_13: Space = unite(&(v48_8),&(v48_12));
    v47_11.join_into((v48_13).clone());
  }
  drop(v47_11_cursor);
  (v47_11).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v57_11 = Space::new();
  let mut v57_11_cursor = (*s0).read_zipper();
  for v57_11_byte in v57_11_cursor.child_mask().iter() {
    v57_11_cursor.descend_to_byte(v57_11_byte);
    let v57_11_tail = v57_11_cursor.make_map();
    v57_11_cursor.ascend(1);
    let v57_11_head = Path::from_slice(&[v57_11_byte]);
    let v58_2: Space = singleton(&(v57_11_head));
    let v58_3: Space = intersect(&(*CONSTANT_3),&(v58_2));
    let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
    drop(v58_3);
    let v58_5: Space = subtract(&(*CONSTANT_2),&(v58_4));
    drop(v58_4);
    let v58_8: Space = if (v58_5).is_empty() { Space::new() } else {
      let v59_6: Path = concat_path(&(*p0),&(v57_11_head));
      let mut v59_7 = Space::new();
      let mut v59_7_cursor = (v57_11_tail).read_zipper();
      for v59_7_byte in v59_7_cursor.child_mask().iter() {
        v59_7_cursor.descend_to_byte(v59_7_byte);
        let v59_7_tail = v59_7_cursor.make_map();
        v59_7_cursor.ascend(1);
        let v59_7_head = Path::from_slice(&[v59_7_byte]);
        let v60_2: Space = singleton(&(v59_7_head));
        let v60_3: Space = intersect(&(*CONSTANT_3),&(v60_2));
        let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
        drop(v60_3);
        let v60_5: Space = subtract(&(*CONSTANT_2),&(v60_4));
        drop(v60_4);
        let v60_8: Space = if (v60_5).is_empty() { Space::new() } else {
          let v61_6: Path = concat_path(&(v59_6),&(v59_7_head));
          let v61_7: Space = routine_16(c, &(v61_6), &(v59_7_tail));
          compose(&(v60_5),&(v61_7))
        };
        drop(v60_5);
        let v60_9: Space = intersect(&(*CONSTANT_3),&(v60_2));
        drop(v60_2);
        let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
        drop(v60_9);
        let v60_12: Space = if (v60_10).is_empty() { Space::new() } else {
          let v62_6: Path = concat_path(&(v59_6),&(v59_7_head));
          let v62_11: Space = routine_17(c, &(v62_6), &(v59_7_tail));
          drop(v62_6);
          compose(&(v60_10),&(v62_11))
        };
        drop(v60_10);
        let v60_13: Space = unite(&(v60_8),&(v60_12));
        v59_7.join_into((v60_13).clone());
      }
      drop(v59_7_cursor);
      compose(&(v58_5),&(v59_7))
    };
    drop(v58_5);
    let v58_9: Space = intersect(&(*CONSTANT_3),&(v58_2));
    drop(v58_2);
    let v58_10: Space = if has_head(&(v58_9)) { singleton(&[]) } else { Space::new() };
    drop(v58_9);
    let v58_12: Space = if (v58_10).is_empty() { Space::new() } else {
      let v63_6: Path = concat_path(&(*p0),&(v57_11_head));
      let mut v63_11 = Space::new();
      let mut v63_11_cursor = (v57_11_tail).read_zipper();
      for v63_11_byte in v63_11_cursor.child_mask().iter() {
        v63_11_cursor.descend_to_byte(v63_11_byte);
        let v63_11_tail = v63_11_cursor.make_map();
        v63_11_cursor.ascend(1);
        let v63_11_head = Path::from_slice(&[v63_11_byte]);
        let v64_2: Space = singleton(&(v63_11_head));
        let v64_3: Space = intersect(&(*CONSTANT_3),&(v64_2));
        let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
        drop(v64_3);
        let v64_5: Space = subtract(&(*CONSTANT_2),&(v64_4));
        drop(v64_4);
        let v64_7: Space = if (v64_5).is_empty() { Space::new() } else {
          let v65_6: Space = routine_18(c, &(v63_11_head), &(v63_6), &(v63_11_tail));
          compose(&(v64_5),&(v65_6))
        };
        drop(v64_5);
        let v64_8: Space = intersect(&(*CONSTANT_3),&(v64_2));
        drop(v64_2);
        let v64_9: Space = if has_head(&(v64_8)) { singleton(&[]) } else { Space::new() };
        drop(v64_8);
        let v64_11: Space = if (v64_9).is_empty() { Space::new() } else {
          let v66_10: Space = routine_19(c, &(v63_11_head), &(v63_6), &(v63_11_tail));
          compose(&(v64_9),&(v66_10))
        };
        drop(v64_9);
        let v64_12: Space = unite(&(v64_7),&(v64_11));
        v63_11.join_into((v64_12).clone());
      }
      drop(v63_11_cursor);
      drop(v63_6);
      compose(&(v58_10),&(v63_11))
    };
    drop(v58_10);
    let v58_13: Space = unite(&(v58_8),&(v58_12));
    v57_11.join_into((v58_13).clone());
  }
  drop(v57_11_cursor);
  (v57_11).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v67_11 = Space::new();
  let mut v67_11_cursor = (*s0).read_zipper();
  for v67_11_byte in v67_11_cursor.child_mask().iter() {
    v67_11_cursor.descend_to_byte(v67_11_byte);
    let v67_11_tail = v67_11_cursor.make_map();
    v67_11_cursor.ascend(1);
    let v67_11_head = Path::from_slice(&[v67_11_byte]);
    let v68_2: Space = singleton(&(v67_11_head));
    let v68_3: Space = intersect(&(*CONSTANT_3),&(v68_2));
    let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
    drop(v68_3);
    let v68_5: Space = subtract(&(*CONSTANT_2),&(v68_4));
    drop(v68_4);
    let v68_7: Space = if (v68_5).is_empty() { Space::new() } else {
      let mut v69_6 = Space::new();
      let mut v69_6_cursor = (v67_11_tail).read_zipper();
      for v69_6_byte in v69_6_cursor.child_mask().iter() {
        v69_6_cursor.descend_to_byte(v69_6_byte);
        let v69_6_tail = v69_6_cursor.make_map();
        v69_6_cursor.ascend(1);
        let v69_6_head = Path::from_slice(&[v69_6_byte]);
        let v70_2: Space = singleton(&(v69_6_head));
        let v70_3: Space = intersect(&(*CONSTANT_3),&(v70_2));
        let v70_4: Space = if has_head(&(v70_3)) { singleton(&[]) } else { Space::new() };
        drop(v70_3);
        let v70_5: Space = subtract(&(*CONSTANT_2),&(v70_4));
        drop(v70_4);
        let v70_8: Space = if (v70_5).is_empty() { Space::new() } else {
          let v71_6: Path = concat_path(&(v67_11_head),&(v69_6_head));
          let v71_7: Space = routine_20(c, &(v71_6), &(*p0), &(v69_6_tail));
          compose(&(v70_5),&(v71_7))
        };
        drop(v70_5);
        let v70_9: Space = intersect(&(*CONSTANT_3),&(v70_2));
        drop(v70_2);
        let v70_10: Space = if has_head(&(v70_9)) { singleton(&[]) } else { Space::new() };
        drop(v70_9);
        let v70_12: Space = if (v70_10).is_empty() { Space::new() } else {
          let v72_6: Path = concat_path(&(v67_11_head),&(v69_6_head));
          let v72_11: Space = routine_21(c, &(v72_6), &(*p0), &(v69_6_tail));
          drop(v72_6);
          compose(&(v70_10),&(v72_11))
        };
        drop(v70_10);
        let v70_13: Space = unite(&(v70_8),&(v70_12));
        v69_6.join_into((v70_13).clone());
      }
      drop(v69_6_cursor);
      compose(&(v68_5),&(v69_6))
    };
    drop(v68_5);
    let v68_8: Space = intersect(&(*CONSTANT_3),&(v68_2));
    drop(v68_2);
    let v68_9: Space = if has_head(&(v68_8)) { singleton(&[]) } else { Space::new() };
    drop(v68_8);
    let v68_11: Space = if (v68_9).is_empty() { Space::new() } else {
      let mut v73_10 = Space::new();
      let mut v73_10_cursor = (v67_11_tail).read_zipper();
      for v73_10_byte in v73_10_cursor.child_mask().iter() {
        v73_10_cursor.descend_to_byte(v73_10_byte);
        let v73_10_tail = v73_10_cursor.make_map();
        v73_10_cursor.ascend(1);
        let v73_10_head = Path::from_slice(&[v73_10_byte]);
        let v74_2: Space = singleton(&(v73_10_head));
        let v74_3: Space = intersect(&(*CONSTANT_3),&(v74_2));
        let v74_4: Space = if has_head(&(v74_3)) { singleton(&[]) } else { Space::new() };
        drop(v74_3);
        let v74_5: Space = subtract(&(*CONSTANT_2),&(v74_4));
        drop(v74_4);
        let v74_8: Space = if (v74_5).is_empty() { Space::new() } else {
          let v75_6: Path = concat_path(&(v67_11_head),&(v73_10_head));
          let v75_7: Space = routine_20(c, &(v75_6), &(*p0), &(v73_10_tail));
          compose(&(v74_5),&(v75_7))
        };
        drop(v74_5);
        let v74_9: Space = intersect(&(*CONSTANT_3),&(v74_2));
        drop(v74_2);
        let v74_10: Space = if has_head(&(v74_9)) { singleton(&[]) } else { Space::new() };
        drop(v74_9);
        let v74_12: Space = if (v74_10).is_empty() { Space::new() } else {
          let v76_6: Path = concat_path(&(v67_11_head),&(v73_10_head));
          let v76_11: Space = routine_22(c, &(v76_6), &(*p0), &(v73_10_tail));
          drop(v76_6);
          compose(&(v74_10),&(v76_11))
        };
        drop(v74_10);
        let v74_13: Space = unite(&(v74_8),&(v74_12));
        v73_10.join_into((v74_13).clone());
      }
      drop(v73_10_cursor);
      compose(&(v68_9),&(v73_10))
    };
    drop(v68_9);
    let v68_12: Space = unite(&(v68_7),&(v68_11));
    v67_11.join_into((v68_12).clone());
  }
  drop(v67_11_cursor);
  (v67_11).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v77_12 = Space::new();
  let mut v77_12_cursor = (*s0).read_zipper();
  for v77_12_byte in v77_12_cursor.child_mask().iter() {
    v77_12_cursor.descend_to_byte(v77_12_byte);
    let v77_12_tail = v77_12_cursor.make_map();
    v77_12_cursor.ascend(1);
    let v77_12_head = Path::from_slice(&[v77_12_byte]);
    let v78_2: Space = singleton(&(v77_12_head));
    let v78_3: Space = intersect(&(*CONSTANT_3),&(v78_2));
    let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
    drop(v78_3);
    let v78_5: Space = subtract(&(*CONSTANT_2),&(v78_4));
    drop(v78_4);
    let v78_8: Space = if (v78_5).is_empty() { Space::new() } else {
      let v79_6: Path = concat_path(&(*p0),&(v77_12_head));
      let mut v79_7 = Space::new();
      let mut v79_7_cursor = (v77_12_tail).read_zipper();
      for v79_7_byte in v79_7_cursor.child_mask().iter() {
        v79_7_cursor.descend_to_byte(v79_7_byte);
        let v79_7_tail = v79_7_cursor.make_map();
        v79_7_cursor.ascend(1);
        let v79_7_head = Path::from_slice(&[v79_7_byte]);
        let v80_2: Space = singleton(&(v79_7_head));
        let v80_3: Space = intersect(&(*CONSTANT_3),&(v80_2));
        let v80_4: Space = if has_head(&(v80_3)) { singleton(&[]) } else { Space::new() };
        drop(v80_3);
        let v80_5: Space = subtract(&(*CONSTANT_2),&(v80_4));
        drop(v80_4);
        let v80_8: Space = if (v80_5).is_empty() { Space::new() } else {
          let v81_6: Path = concat_path(&(v79_6),&(v79_7_head));
          let v81_7: Space = routine_23(c, &(v81_6), &(v79_7_tail), &(*s1));
          compose(&(v80_5),&(v81_7))
        };
        drop(v80_5);
        let v80_9: Space = intersect(&(*CONSTANT_3),&(v80_2));
        drop(v80_2);
        let v80_10: Space = if has_head(&(v80_9)) { singleton(&[]) } else { Space::new() };
        drop(v80_9);
        let v80_12: Space = if (v80_10).is_empty() { Space::new() } else {
          let v82_6: Path = concat_path(&(v79_6),&(v79_7_head));
          let v82_11: Space = routine_24(c, &(v82_6), &(v79_7_tail), &(*s1));
          drop(v82_6);
          compose(&(v80_10),&(v82_11))
        };
        drop(v80_10);
        let v80_13: Space = unite(&(v80_8),&(v80_12));
        v79_7.join_into((v80_13).clone());
      }
      drop(v79_7_cursor);
      compose(&(v78_5),&(v79_7))
    };
    drop(v78_5);
    let v78_9: Space = intersect(&(*CONSTANT_3),&(v78_2));
    drop(v78_2);
    let v78_10: Space = if has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
    drop(v78_9);
    let v78_12: Space = if (v78_10).is_empty() { Space::new() } else {
      let v83_6: Path = concat_path(&(*p0),&(v77_12_head));
      let mut v83_11 = Space::new();
      let mut v83_11_cursor = (v77_12_tail).read_zipper();
      for v83_11_byte in v83_11_cursor.child_mask().iter() {
        v83_11_cursor.descend_to_byte(v83_11_byte);
        let v83_11_tail = v83_11_cursor.make_map();
        v83_11_cursor.ascend(1);
        let v83_11_head = Path::from_slice(&[v83_11_byte]);
        let v84_2: Space = singleton(&(v83_11_head));
        let v84_3: Space = intersect(&(*CONSTANT_3),&(v84_2));
        let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
        drop(v84_3);
        let v84_5: Space = subtract(&(*CONSTANT_2),&(v84_4));
        drop(v84_4);
        let v84_8: Space = if (v84_5).is_empty() { Space::new() } else {
          let v85_6: Path = concat_path(&(v83_6),&(v83_11_head));
          let v85_7: Space = routine_23(c, &(v85_6), &(v83_11_tail), &(*s1));
          compose(&(v84_5),&(v85_7))
        };
        drop(v84_5);
        let v84_9: Space = intersect(&(*CONSTANT_3),&(v84_2));
        drop(v84_2);
        let v84_10: Space = if has_head(&(v84_9)) { singleton(&[]) } else { Space::new() };
        drop(v84_9);
        let v84_12: Space = if (v84_10).is_empty() { Space::new() } else {
          let v86_6: Path = concat_path(&(v83_6),&(v83_11_head));
          let v86_11: Space = routine_6(c, &(v86_6), &(v83_11_tail), &(*s1));
          drop(v86_6);
          compose(&(v84_10),&(v86_11))
        };
        drop(v84_10);
        let v84_13: Space = unite(&(v84_8),&(v84_12));
        v83_11.join_into((v84_13).clone());
      }
      drop(v83_11_cursor);
      drop(v83_6);
      compose(&(v78_10),&(v83_11))
    };
    drop(v78_10);
    let v78_13: Space = unite(&(v78_8),&(v78_12));
    v77_12.join_into((v78_13).clone());
  }
  drop(v77_12_cursor);
  (v77_12).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v87_12 = Space::new();
  let mut v87_12_cursor = (*s0).read_zipper();
  for v87_12_byte in v87_12_cursor.child_mask().iter() {
    v87_12_cursor.descend_to_byte(v87_12_byte);
    let v87_12_tail = v87_12_cursor.make_map();
    v87_12_cursor.ascend(1);
    let v87_12_head = Path::from_slice(&[v87_12_byte]);
    let v88_2: Space = singleton(&(v87_12_head));
    let v88_3: Space = intersect(&(*CONSTANT_3),&(v88_2));
    let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
    drop(v88_3);
    let v88_5: Space = subtract(&(*CONSTANT_2),&(v88_4));
    drop(v88_4);
    let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
      let v89_6: Path = concat_path(&(*p0),&(v87_12_head));
      let mut v89_7 = Space::new();
      let mut v89_7_cursor = (v87_12_tail).read_zipper();
      for v89_7_byte in v89_7_cursor.child_mask().iter() {
        v89_7_cursor.descend_to_byte(v89_7_byte);
        let v89_7_tail = v89_7_cursor.make_map();
        v89_7_cursor.ascend(1);
        let v89_7_head = Path::from_slice(&[v89_7_byte]);
        let v90_2: Space = singleton(&(v89_7_head));
        let v90_3: Space = intersect(&(*CONSTANT_3),&(v90_2));
        let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
        drop(v90_3);
        let v90_5: Space = subtract(&(*CONSTANT_2),&(v90_4));
        drop(v90_4);
        let v90_8: Space = if (v90_5).is_empty() { Space::new() } else {
          let v91_6: Path = concat_path(&(v89_6),&(v89_7_head));
          let v91_7: Space = routine_23(c, &(v91_6), &(v89_7_tail), &(*s1));
          compose(&(v90_5),&(v91_7))
        };
        drop(v90_5);
        let v90_9: Space = intersect(&(*CONSTANT_3),&(v90_2));
        drop(v90_2);
        let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
        drop(v90_9);
        let v90_12: Space = if (v90_10).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v89_6),&(v89_7_head));
          let v92_11: Space = routine_24(c, &(v92_6), &(v89_7_tail), &(*s1));
          drop(v92_6);
          compose(&(v90_10),&(v92_11))
        };
        drop(v90_10);
        let v90_13: Space = unite(&(v90_8),&(v90_12));
        v89_7.join_into((v90_13).clone());
      }
      drop(v89_7_cursor);
      compose(&(v88_5),&(v89_7))
    };
    drop(v88_5);
    let v88_9: Space = intersect(&(*CONSTANT_3),&(v88_2));
    drop(v88_2);
    let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
    drop(v88_9);
    let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
      let v93_6: Path = concat_path(&(*p0),&(v87_12_head));
      let mut v93_11 = Space::new();
      let mut v93_11_cursor = (v87_12_tail).read_zipper();
      for v93_11_byte in v93_11_cursor.child_mask().iter() {
        v93_11_cursor.descend_to_byte(v93_11_byte);
        let v93_11_tail = v93_11_cursor.make_map();
        v93_11_cursor.ascend(1);
        let v93_11_head = Path::from_slice(&[v93_11_byte]);
        let v94_2: Space = singleton(&(v93_11_head));
        let v94_3: Space = intersect(&(*CONSTANT_3),&(v94_2));
        let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
        drop(v94_3);
        let v94_5: Space = subtract(&(*CONSTANT_2),&(v94_4));
        drop(v94_4);
        let v94_7: Space = if (v94_5).is_empty() { Space::new() } else {
          let v95_6: Space = routine_25(c, &(v93_11_head), &(v93_6), &(v93_11_tail), &(*s1));
          compose(&(v94_5),&(v95_6))
        };
        drop(v94_5);
        let v94_8: Space = intersect(&(*CONSTANT_3),&(v94_2));
        drop(v94_2);
        let v94_9: Space = if has_head(&(v94_8)) { singleton(&[]) } else { Space::new() };
        drop(v94_8);
        let v94_11: Space = if (v94_9).is_empty() { Space::new() } else {
          let v96_10: Space = routine_26(c, &(v93_11_head), &(v93_6), &(v93_11_tail), &(*s1));
          compose(&(v94_9),&(v96_10))
        };
        drop(v94_9);
        let v94_12: Space = unite(&(v94_7),&(v94_11));
        v93_11.join_into((v94_12).clone());
      }
      drop(v93_11_cursor);
      drop(v93_6);
      compose(&(v88_10),&(v93_11))
    };
    drop(v88_10);
    let v88_13: Space = unite(&(v88_8),&(v88_12));
    v87_12.join_into((v88_13).clone());
  }
  drop(v87_12_cursor);
  (v87_12).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v97_12 = Space::new();
  let mut v97_12_cursor = (*s0).read_zipper();
  for v97_12_byte in v97_12_cursor.child_mask().iter() {
    v97_12_cursor.descend_to_byte(v97_12_byte);
    let v97_12_tail = v97_12_cursor.make_map();
    v97_12_cursor.ascend(1);
    let v97_12_head = Path::from_slice(&[v97_12_byte]);
    let v98_2: Space = singleton(&(v97_12_head));
    let v98_3: Space = intersect(&(*CONSTANT_3),&(v98_2));
    let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
    drop(v98_3);
    let v98_5: Space = subtract(&(*CONSTANT_2),&(v98_4));
    drop(v98_4);
    let v98_7: Space = if (v98_5).is_empty() { Space::new() } else {
      let mut v99_6 = Space::new();
      let mut v99_6_cursor = (v97_12_tail).read_zipper();
      for v99_6_byte in v99_6_cursor.child_mask().iter() {
        v99_6_cursor.descend_to_byte(v99_6_byte);
        let v99_6_tail = v99_6_cursor.make_map();
        v99_6_cursor.ascend(1);
        let v99_6_head = Path::from_slice(&[v99_6_byte]);
        let v100_2: Space = singleton(&(v99_6_head));
        let v100_3: Space = intersect(&(*CONSTANT_3),&(v100_2));
        let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
        drop(v100_3);
        let v100_5: Space = subtract(&(*CONSTANT_2),&(v100_4));
        drop(v100_4);
        let v100_8: Space = if (v100_5).is_empty() { Space::new() } else {
          let v101_6: Path = concat_path(&(v97_12_head),&(v99_6_head));
          let v101_7: Space = routine_27(c, &(v101_6), &(*p0), &(v99_6_tail), &(*s1));
          compose(&(v100_5),&(v101_7))
        };
        drop(v100_5);
        let v100_9: Space = intersect(&(*CONSTANT_3),&(v100_2));
        drop(v100_2);
        let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
        drop(v100_9);
        let v100_12: Space = if (v100_10).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v97_12_head),&(v99_6_head));
          let v102_11: Space = routine_28(c, &(v102_6), &(*p0), &(v99_6_tail), &(*s1));
          drop(v102_6);
          compose(&(v100_10),&(v102_11))
        };
        drop(v100_10);
        let v100_13: Space = unite(&(v100_8),&(v100_12));
        v99_6.join_into((v100_13).clone());
      }
      drop(v99_6_cursor);
      compose(&(v98_5),&(v99_6))
    };
    drop(v98_5);
    let v98_8: Space = intersect(&(*CONSTANT_3),&(v98_2));
    drop(v98_2);
    let v98_9: Space = if has_head(&(v98_8)) { singleton(&[]) } else { Space::new() };
    drop(v98_8);
    let v98_11: Space = if (v98_9).is_empty() { Space::new() } else {
      let mut v103_10 = Space::new();
      let mut v103_10_cursor = (v97_12_tail).read_zipper();
      for v103_10_byte in v103_10_cursor.child_mask().iter() {
        v103_10_cursor.descend_to_byte(v103_10_byte);
        let v103_10_tail = v103_10_cursor.make_map();
        v103_10_cursor.ascend(1);
        let v103_10_head = Path::from_slice(&[v103_10_byte]);
        let v104_2: Space = singleton(&(v103_10_head));
        let v104_3: Space = intersect(&(*CONSTANT_3),&(v104_2));
        let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
        drop(v104_3);
        let v104_5: Space = subtract(&(*CONSTANT_2),&(v104_4));
        drop(v104_4);
        let v104_8: Space = if (v104_5).is_empty() { Space::new() } else {
          let v105_6: Path = concat_path(&(v97_12_head),&(v103_10_head));
          let v105_7: Space = routine_27(c, &(v105_6), &(*p0), &(v103_10_tail), &(*s1));
          compose(&(v104_5),&(v105_7))
        };
        drop(v104_5);
        let v104_9: Space = intersect(&(*CONSTANT_3),&(v104_2));
        drop(v104_2);
        let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
        drop(v104_9);
        let v104_12: Space = if (v104_10).is_empty() { Space::new() } else {
          let v106_6: Path = concat_path(&(v97_12_head),&(v103_10_head));
          let v106_11: Space = routine_29(c, &(v106_6), &(*p0), &(v103_10_tail), &(*s1));
          drop(v106_6);
          compose(&(v104_10),&(v106_11))
        };
        drop(v104_10);
        let v104_13: Space = unite(&(v104_8),&(v104_12));
        v103_10.join_into((v104_13).clone());
      }
      drop(v103_10_cursor);
      compose(&(v98_9),&(v103_10))
    };
    drop(v98_9);
    let v98_12: Space = unite(&(v98_7),&(v98_11));
    v97_12.join_into((v98_12).clone());
  }
  drop(v97_12_cursor);
  (v97_12).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v107_11 = Space::new();
  let mut v107_11_cursor = (*s0).read_zipper();
  for v107_11_byte in v107_11_cursor.child_mask().iter() {
    v107_11_cursor.descend_to_byte(v107_11_byte);
    let v107_11_tail = v107_11_cursor.make_map();
    v107_11_cursor.ascend(1);
    let v107_11_head = Path::from_slice(&[v107_11_byte]);
    let v108_2: Space = singleton(&(v107_11_head));
    let v108_3: Space = intersect(&(*CONSTANT_3),&(v108_2));
    let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
    drop(v108_3);
    let v108_5: Space = subtract(&(*CONSTANT_2),&(v108_4));
    drop(v108_4);
    let v108_8: Space = if (v108_5).is_empty() { Space::new() } else {
      let v109_6: Path = concat_path(&(*p0),&(v107_11_head));
      let mut v109_7 = Space::new();
      let mut v109_7_cursor = (v107_11_tail).read_zipper();
      for v109_7_byte in v109_7_cursor.child_mask().iter() {
        v109_7_cursor.descend_to_byte(v109_7_byte);
        let v109_7_tail = v109_7_cursor.make_map();
        v109_7_cursor.ascend(1);
        let v109_7_head = Path::from_slice(&[v109_7_byte]);
        let v110_2: Space = singleton(&(v109_7_head));
        let v110_3: Space = intersect(&(*CONSTANT_3),&(v110_2));
        let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
        drop(v110_3);
        let v110_5: Space = subtract(&(*CONSTANT_2),&(v110_4));
        drop(v110_4);
        let v110_8: Space = if (v110_5).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v109_6),&(v109_7_head));
          let v111_7: Space = routine_30(c, &(v111_6), &(v109_7_tail));
          compose(&(v110_5),&(v111_7))
        };
        drop(v110_5);
        let v110_9: Space = intersect(&(*CONSTANT_3),&(v110_2));
        drop(v110_2);
        let v110_10: Space = if has_head(&(v110_9)) { singleton(&[]) } else { Space::new() };
        drop(v110_9);
        let v110_12: Space = if (v110_10).is_empty() { Space::new() } else {
          let v112_6: Path = concat_path(&(v109_6),&(v109_7_head));
          let v112_11: Space = routine_31(c, &(v112_6), &(v109_7_tail));
          drop(v112_6);
          compose(&(v110_10),&(v112_11))
        };
        drop(v110_10);
        let v110_13: Space = unite(&(v110_8),&(v110_12));
        v109_7.join_into((v110_13).clone());
      }
      drop(v109_7_cursor);
      compose(&(v108_5),&(v109_7))
    };
    drop(v108_5);
    let v108_9: Space = intersect(&(*CONSTANT_3),&(v108_2));
    drop(v108_2);
    let v108_10: Space = if has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
    drop(v108_9);
    let v108_12: Space = if (v108_10).is_empty() { Space::new() } else {
      let v113_6: Path = concat_path(&(*p0),&(v107_11_head));
      let mut v113_11 = Space::new();
      let mut v113_11_cursor = (v107_11_tail).read_zipper();
      for v113_11_byte in v113_11_cursor.child_mask().iter() {
        v113_11_cursor.descend_to_byte(v113_11_byte);
        let v113_11_tail = v113_11_cursor.make_map();
        v113_11_cursor.ascend(1);
        let v113_11_head = Path::from_slice(&[v113_11_byte]);
        let v114_2: Space = singleton(&(v113_11_head));
        let v114_3: Space = intersect(&(*CONSTANT_3),&(v114_2));
        let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
        drop(v114_3);
        let v114_5: Space = subtract(&(*CONSTANT_2),&(v114_4));
        drop(v114_4);
        let v114_8: Space = if (v114_5).is_empty() { Space::new() } else {
          let v115_6: Path = concat_path(&(v113_6),&(v113_11_head));
          let v115_7: Space = routine_30(c, &(v115_6), &(v113_11_tail));
          compose(&(v114_5),&(v115_7))
        };
        drop(v114_5);
        let v114_9: Space = intersect(&(*CONSTANT_3),&(v114_2));
        drop(v114_2);
        let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
        drop(v114_9);
        let v114_12: Space = if (v114_10).is_empty() { Space::new() } else {
          let v116_6: Path = concat_path(&(v113_6),&(v113_11_head));
          let v116_11: Space = routine_9(c, &(v116_6), &(v113_11_tail));
          drop(v116_6);
          compose(&(v114_10),&(v116_11))
        };
        drop(v114_10);
        let v114_13: Space = unite(&(v114_8),&(v114_12));
        v113_11.join_into((v114_13).clone());
      }
      drop(v113_11_cursor);
      drop(v113_6);
      compose(&(v108_10),&(v113_11))
    };
    drop(v108_10);
    let v108_13: Space = unite(&(v108_8),&(v108_12));
    v107_11.join_into((v108_13).clone());
  }
  drop(v107_11_cursor);
  (v107_11).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v117_11 = Space::new();
  let mut v117_11_cursor = (*s0).read_zipper();
  for v117_11_byte in v117_11_cursor.child_mask().iter() {
    v117_11_cursor.descend_to_byte(v117_11_byte);
    let v117_11_tail = v117_11_cursor.make_map();
    v117_11_cursor.ascend(1);
    let v117_11_head = Path::from_slice(&[v117_11_byte]);
    let v118_2: Space = singleton(&(v117_11_head));
    let v118_3: Space = intersect(&(*CONSTANT_3),&(v118_2));
    let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
    drop(v118_3);
    let v118_5: Space = subtract(&(*CONSTANT_2),&(v118_4));
    drop(v118_4);
    let v118_8: Space = if (v118_5).is_empty() { Space::new() } else {
      let v119_6: Path = concat_path(&(*p0),&(v117_11_head));
      let mut v119_7 = Space::new();
      let mut v119_7_cursor = (v117_11_tail).read_zipper();
      for v119_7_byte in v119_7_cursor.child_mask().iter() {
        v119_7_cursor.descend_to_byte(v119_7_byte);
        let v119_7_tail = v119_7_cursor.make_map();
        v119_7_cursor.ascend(1);
        let v119_7_head = Path::from_slice(&[v119_7_byte]);
        let v120_2: Space = singleton(&(v119_7_head));
        let v120_3: Space = intersect(&(*CONSTANT_3),&(v120_2));
        let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
        drop(v120_3);
        let v120_5: Space = subtract(&(*CONSTANT_2),&(v120_4));
        drop(v120_4);
        let v120_8: Space = if (v120_5).is_empty() { Space::new() } else {
          let v121_6: Path = concat_path(&(v119_6),&(v119_7_head));
          let v121_7: Space = routine_30(c, &(v121_6), &(v119_7_tail));
          compose(&(v120_5),&(v121_7))
        };
        drop(v120_5);
        let v120_9: Space = intersect(&(*CONSTANT_3),&(v120_2));
        drop(v120_2);
        let v120_10: Space = if has_head(&(v120_9)) { singleton(&[]) } else { Space::new() };
        drop(v120_9);
        let v120_12: Space = if (v120_10).is_empty() { Space::new() } else {
          let v122_6: Path = concat_path(&(v119_6),&(v119_7_head));
          let v122_11: Space = routine_31(c, &(v122_6), &(v119_7_tail));
          drop(v122_6);
          compose(&(v120_10),&(v122_11))
        };
        drop(v120_10);
        let v120_13: Space = unite(&(v120_8),&(v120_12));
        v119_7.join_into((v120_13).clone());
      }
      drop(v119_7_cursor);
      compose(&(v118_5),&(v119_7))
    };
    drop(v118_5);
    let v118_9: Space = intersect(&(*CONSTANT_3),&(v118_2));
    drop(v118_2);
    let v118_10: Space = if has_head(&(v118_9)) { singleton(&[]) } else { Space::new() };
    drop(v118_9);
    let v118_12: Space = if (v118_10).is_empty() { Space::new() } else {
      let v123_6: Path = concat_path(&(*p0),&(v117_11_head));
      let mut v123_11 = Space::new();
      let mut v123_11_cursor = (v117_11_tail).read_zipper();
      for v123_11_byte in v123_11_cursor.child_mask().iter() {
        v123_11_cursor.descend_to_byte(v123_11_byte);
        let v123_11_tail = v123_11_cursor.make_map();
        v123_11_cursor.ascend(1);
        let v123_11_head = Path::from_slice(&[v123_11_byte]);
        let v124_2: Space = singleton(&(v123_11_head));
        let v124_3: Space = intersect(&(*CONSTANT_3),&(v124_2));
        let v124_4: Space = if has_head(&(v124_3)) { singleton(&[]) } else { Space::new() };
        drop(v124_3);
        let v124_5: Space = subtract(&(*CONSTANT_2),&(v124_4));
        drop(v124_4);
        let v124_7: Space = if (v124_5).is_empty() { Space::new() } else {
          let v125_6: Space = routine_32(c, &(v123_11_head), &(v123_6), &(v123_11_tail));
          compose(&(v124_5),&(v125_6))
        };
        drop(v124_5);
        let v124_8: Space = intersect(&(*CONSTANT_3),&(v124_2));
        drop(v124_2);
        let v124_9: Space = if has_head(&(v124_8)) { singleton(&[]) } else { Space::new() };
        drop(v124_8);
        let v124_11: Space = if (v124_9).is_empty() { Space::new() } else {
          let v126_10: Space = routine_33(c, &(v123_11_head), &(v123_6), &(v123_11_tail));
          compose(&(v124_9),&(v126_10))
        };
        drop(v124_9);
        let v124_12: Space = unite(&(v124_7),&(v124_11));
        v123_11.join_into((v124_12).clone());
      }
      drop(v123_11_cursor);
      drop(v123_6);
      compose(&(v118_10),&(v123_11))
    };
    drop(v118_10);
    let v118_13: Space = unite(&(v118_8),&(v118_12));
    v117_11.join_into((v118_13).clone());
  }
  drop(v117_11_cursor);
  (v117_11).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v127_11 = Space::new();
  let mut v127_11_cursor = (*s0).read_zipper();
  for v127_11_byte in v127_11_cursor.child_mask().iter() {
    v127_11_cursor.descend_to_byte(v127_11_byte);
    let v127_11_tail = v127_11_cursor.make_map();
    v127_11_cursor.ascend(1);
    let v127_11_head = Path::from_slice(&[v127_11_byte]);
    let v128_2: Space = singleton(&(v127_11_head));
    let v128_3: Space = intersect(&(*CONSTANT_3),&(v128_2));
    let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
    drop(v128_3);
    let v128_5: Space = subtract(&(*CONSTANT_2),&(v128_4));
    drop(v128_4);
    let v128_7: Space = if (v128_5).is_empty() { Space::new() } else {
      let mut v129_6 = Space::new();
      let mut v129_6_cursor = (v127_11_tail).read_zipper();
      for v129_6_byte in v129_6_cursor.child_mask().iter() {
        v129_6_cursor.descend_to_byte(v129_6_byte);
        let v129_6_tail = v129_6_cursor.make_map();
        v129_6_cursor.ascend(1);
        let v129_6_head = Path::from_slice(&[v129_6_byte]);
        let v130_2: Space = singleton(&(v129_6_head));
        let v130_3: Space = intersect(&(*CONSTANT_3),&(v130_2));
        let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
        drop(v130_3);
        let v130_5: Space = subtract(&(*CONSTANT_2),&(v130_4));
        drop(v130_4);
        let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
          let v131_6: Path = concat_path(&(v127_11_head),&(v129_6_head));
          let v131_7: Space = routine_34(c, &(v131_6), &(*p0), &(v129_6_tail));
          compose(&(v130_5),&(v131_7))
        };
        drop(v130_5);
        let v130_9: Space = intersect(&(*CONSTANT_3),&(v130_2));
        drop(v130_2);
        let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
        drop(v130_9);
        let v130_12: Space = if (v130_10).is_empty() { Space::new() } else {
          let v132_6: Path = concat_path(&(v127_11_head),&(v129_6_head));
          let v132_11: Space = routine_35(c, &(v132_6), &(*p0), &(v129_6_tail));
          drop(v132_6);
          compose(&(v130_10),&(v132_11))
        };
        drop(v130_10);
        let v130_13: Space = unite(&(v130_8),&(v130_12));
        v129_6.join_into((v130_13).clone());
      }
      drop(v129_6_cursor);
      compose(&(v128_5),&(v129_6))
    };
    drop(v128_5);
    let v128_8: Space = intersect(&(*CONSTANT_3),&(v128_2));
    drop(v128_2);
    let v128_9: Space = if has_head(&(v128_8)) { singleton(&[]) } else { Space::new() };
    drop(v128_8);
    let v128_11: Space = if (v128_9).is_empty() { Space::new() } else {
      let mut v133_10 = Space::new();
      let mut v133_10_cursor = (v127_11_tail).read_zipper();
      for v133_10_byte in v133_10_cursor.child_mask().iter() {
        v133_10_cursor.descend_to_byte(v133_10_byte);
        let v133_10_tail = v133_10_cursor.make_map();
        v133_10_cursor.ascend(1);
        let v133_10_head = Path::from_slice(&[v133_10_byte]);
        let v134_2: Space = singleton(&(v133_10_head));
        let v134_3: Space = intersect(&(*CONSTANT_3),&(v134_2));
        let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
        drop(v134_3);
        let v134_5: Space = subtract(&(*CONSTANT_2),&(v134_4));
        drop(v134_4);
        let v134_8: Space = if (v134_5).is_empty() { Space::new() } else {
          let v135_6: Path = concat_path(&(v127_11_head),&(v133_10_head));
          let v135_7: Space = routine_34(c, &(v135_6), &(*p0), &(v133_10_tail));
          compose(&(v134_5),&(v135_7))
        };
        drop(v134_5);
        let v134_9: Space = intersect(&(*CONSTANT_3),&(v134_2));
        drop(v134_2);
        let v134_10: Space = if has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
        drop(v134_9);
        let v134_12: Space = if (v134_10).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v127_11_head),&(v133_10_head));
          let v136_11: Space = routine_36(c, &(v136_6), &(*p0), &(v133_10_tail));
          drop(v136_6);
          compose(&(v134_10),&(v136_11))
        };
        drop(v134_10);
        let v134_13: Space = unite(&(v134_8),&(v134_12));
        v133_10.join_into((v134_13).clone());
      }
      drop(v133_10_cursor);
      compose(&(v128_9),&(v133_10))
    };
    drop(v128_9);
    let v128_12: Space = unite(&(v128_7),&(v128_11));
    v127_11.join_into((v128_12).clone());
  }
  drop(v127_11_cursor);
  (v127_11).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v137_12 = Space::new();
  let mut v137_12_cursor = (*s0).read_zipper();
  for v137_12_byte in v137_12_cursor.child_mask().iter() {
    v137_12_cursor.descend_to_byte(v137_12_byte);
    let v137_12_tail = v137_12_cursor.make_map();
    v137_12_cursor.ascend(1);
    let v137_12_head = Path::from_slice(&[v137_12_byte]);
    let v138_2: Space = singleton(&(v137_12_head));
    let v138_3: Space = intersect(&(*CONSTANT_3),&(v138_2));
    let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
    drop(v138_3);
    let v138_5: Space = subtract(&(*CONSTANT_2),&(v138_4));
    drop(v138_4);
    let v138_8: Space = if (v138_5).is_empty() { Space::new() } else {
      let v139_6: Path = concat_path(&(*p0),&(v137_12_head));
      let mut v139_7 = Space::new();
      let mut v139_7_cursor = (v137_12_tail).read_zipper();
      for v139_7_byte in v139_7_cursor.child_mask().iter() {
        v139_7_cursor.descend_to_byte(v139_7_byte);
        let v139_7_tail = v139_7_cursor.make_map();
        v139_7_cursor.ascend(1);
        let v139_7_head = Path::from_slice(&[v139_7_byte]);
        let v140_2: Space = singleton(&(v139_7_head));
        let v140_3: Space = intersect(&(*CONSTANT_3),&(v140_2));
        let v140_4: Space = if has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
        drop(v140_3);
        let v140_5: Space = subtract(&(*CONSTANT_2),&(v140_4));
        drop(v140_4);
        let v140_8: Space = if (v140_5).is_empty() { Space::new() } else {
          let v141_6: Path = concat_path(&(v139_6),&(v139_7_head));
          let v141_7: Space = routine_37(c, &(v141_6), &(v139_7_tail), &(*s1));
          compose(&(v140_5),&(v141_7))
        };
        drop(v140_5);
        let v140_9: Space = intersect(&(*CONSTANT_3),&(v140_2));
        drop(v140_2);
        let v140_10: Space = if has_head(&(v140_9)) { singleton(&[]) } else { Space::new() };
        drop(v140_9);
        let v140_12: Space = if (v140_10).is_empty() { Space::new() } else {
          let v142_6: Path = concat_path(&(v139_6),&(v139_7_head));
          let v142_11: Space = routine_38(c, &(v142_6), &(v139_7_tail), &(*s1));
          drop(v142_6);
          compose(&(v140_10),&(v142_11))
        };
        drop(v140_10);
        let v140_13: Space = unite(&(v140_8),&(v140_12));
        v139_7.join_into((v140_13).clone());
      }
      drop(v139_7_cursor);
      compose(&(v138_5),&(v139_7))
    };
    drop(v138_5);
    let v138_9: Space = intersect(&(*CONSTANT_3),&(v138_2));
    drop(v138_2);
    let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
    drop(v138_9);
    let v138_12: Space = if (v138_10).is_empty() { Space::new() } else {
      let v143_6: Path = concat_path(&(*p0),&(v137_12_head));
      let mut v143_11 = Space::new();
      let mut v143_11_cursor = (v137_12_tail).read_zipper();
      for v143_11_byte in v143_11_cursor.child_mask().iter() {
        v143_11_cursor.descend_to_byte(v143_11_byte);
        let v143_11_tail = v143_11_cursor.make_map();
        v143_11_cursor.ascend(1);
        let v143_11_head = Path::from_slice(&[v143_11_byte]);
        let v144_2: Space = singleton(&(v143_11_head));
        let v144_3: Space = intersect(&(*CONSTANT_3),&(v144_2));
        let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
        drop(v144_3);
        let v144_5: Space = subtract(&(*CONSTANT_2),&(v144_4));
        drop(v144_4);
        let v144_8: Space = if (v144_5).is_empty() { Space::new() } else {
          let v145_6: Path = concat_path(&(v143_6),&(v143_11_head));
          let v145_7: Space = routine_37(c, &(v145_6), &(v143_11_tail), &(*s1));
          compose(&(v144_5),&(v145_7))
        };
        drop(v144_5);
        let v144_9: Space = intersect(&(*CONSTANT_3),&(v144_2));
        drop(v144_2);
        let v144_10: Space = if has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
        drop(v144_9);
        let v144_12: Space = if (v144_10).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v143_6),&(v143_11_head));
          let v146_11: Space = routine_12(c, &(v146_6), &(v143_11_tail), &(*s1));
          drop(v146_6);
          compose(&(v144_10),&(v146_11))
        };
        drop(v144_10);
        let v144_13: Space = unite(&(v144_8),&(v144_12));
        v143_11.join_into((v144_13).clone());
      }
      drop(v143_11_cursor);
      drop(v143_6);
      compose(&(v138_10),&(v143_11))
    };
    drop(v138_10);
    let v138_13: Space = unite(&(v138_8),&(v138_12));
    v137_12.join_into((v138_13).clone());
  }
  drop(v137_12_cursor);
  (v137_12).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v147_12 = Space::new();
  let mut v147_12_cursor = (*s0).read_zipper();
  for v147_12_byte in v147_12_cursor.child_mask().iter() {
    v147_12_cursor.descend_to_byte(v147_12_byte);
    let v147_12_tail = v147_12_cursor.make_map();
    v147_12_cursor.ascend(1);
    let v147_12_head = Path::from_slice(&[v147_12_byte]);
    let v148_2: Space = singleton(&(v147_12_head));
    let v148_3: Space = intersect(&(*CONSTANT_3),&(v148_2));
    let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
    drop(v148_3);
    let v148_5: Space = subtract(&(*CONSTANT_2),&(v148_4));
    drop(v148_4);
    let v148_8: Space = if (v148_5).is_empty() { Space::new() } else {
      let v149_6: Path = concat_path(&(*p0),&(v147_12_head));
      let mut v149_7 = Space::new();
      let mut v149_7_cursor = (v147_12_tail).read_zipper();
      for v149_7_byte in v149_7_cursor.child_mask().iter() {
        v149_7_cursor.descend_to_byte(v149_7_byte);
        let v149_7_tail = v149_7_cursor.make_map();
        v149_7_cursor.ascend(1);
        let v149_7_head = Path::from_slice(&[v149_7_byte]);
        let v150_2: Space = singleton(&(v149_7_head));
        let v150_3: Space = intersect(&(*CONSTANT_3),&(v150_2));
        let v150_4: Space = if has_head(&(v150_3)) { singleton(&[]) } else { Space::new() };
        drop(v150_3);
        let v150_5: Space = subtract(&(*CONSTANT_2),&(v150_4));
        drop(v150_4);
        let v150_8: Space = if (v150_5).is_empty() { Space::new() } else {
          let v151_6: Path = concat_path(&(v149_6),&(v149_7_head));
          let v151_7: Space = routine_37(c, &(v151_6), &(v149_7_tail), &(*s1));
          compose(&(v150_5),&(v151_7))
        };
        drop(v150_5);
        let v150_9: Space = intersect(&(*CONSTANT_3),&(v150_2));
        drop(v150_2);
        let v150_10: Space = if has_head(&(v150_9)) { singleton(&[]) } else { Space::new() };
        drop(v150_9);
        let v150_12: Space = if (v150_10).is_empty() { Space::new() } else {
          let v152_6: Path = concat_path(&(v149_6),&(v149_7_head));
          let v152_11: Space = routine_38(c, &(v152_6), &(v149_7_tail), &(*s1));
          drop(v152_6);
          compose(&(v150_10),&(v152_11))
        };
        drop(v150_10);
        let v150_13: Space = unite(&(v150_8),&(v150_12));
        v149_7.join_into((v150_13).clone());
      }
      drop(v149_7_cursor);
      compose(&(v148_5),&(v149_7))
    };
    drop(v148_5);
    let v148_9: Space = intersect(&(*CONSTANT_3),&(v148_2));
    drop(v148_2);
    let v148_10: Space = if has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
    drop(v148_9);
    let v148_12: Space = if (v148_10).is_empty() { Space::new() } else {
      let v153_6: Path = concat_path(&(*p0),&(v147_12_head));
      let mut v153_11 = Space::new();
      let mut v153_11_cursor = (v147_12_tail).read_zipper();
      for v153_11_byte in v153_11_cursor.child_mask().iter() {
        v153_11_cursor.descend_to_byte(v153_11_byte);
        let v153_11_tail = v153_11_cursor.make_map();
        v153_11_cursor.ascend(1);
        let v153_11_head = Path::from_slice(&[v153_11_byte]);
        let v154_2: Space = singleton(&(v153_11_head));
        let v154_3: Space = intersect(&(*CONSTANT_3),&(v154_2));
        let v154_4: Space = if has_head(&(v154_3)) { singleton(&[]) } else { Space::new() };
        drop(v154_3);
        let v154_5: Space = subtract(&(*CONSTANT_2),&(v154_4));
        drop(v154_4);
        let v154_7: Space = if (v154_5).is_empty() { Space::new() } else {
          let v155_6: Space = routine_39(c, &(v153_11_head), &(v153_6), &(v153_11_tail), &(*s1));
          compose(&(v154_5),&(v155_6))
        };
        drop(v154_5);
        let v154_8: Space = intersect(&(*CONSTANT_3),&(v154_2));
        drop(v154_2);
        let v154_9: Space = if has_head(&(v154_8)) { singleton(&[]) } else { Space::new() };
        drop(v154_8);
        let v154_11: Space = if (v154_9).is_empty() { Space::new() } else {
          let v156_10: Space = routine_40(c, &(v153_11_head), &(v153_6), &(v153_11_tail), &(*s1));
          compose(&(v154_9),&(v156_10))
        };
        drop(v154_9);
        let v154_12: Space = unite(&(v154_7),&(v154_11));
        v153_11.join_into((v154_12).clone());
      }
      drop(v153_11_cursor);
      drop(v153_6);
      compose(&(v148_10),&(v153_11))
    };
    drop(v148_10);
    let v148_13: Space = unite(&(v148_8),&(v148_12));
    v147_12.join_into((v148_13).clone());
  }
  drop(v147_12_cursor);
  (v147_12).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v157_12 = Space::new();
  let mut v157_12_cursor = (*s0).read_zipper();
  for v157_12_byte in v157_12_cursor.child_mask().iter() {
    v157_12_cursor.descend_to_byte(v157_12_byte);
    let v157_12_tail = v157_12_cursor.make_map();
    v157_12_cursor.ascend(1);
    let v157_12_head = Path::from_slice(&[v157_12_byte]);
    let v158_2: Space = singleton(&(v157_12_head));
    let v158_3: Space = intersect(&(*CONSTANT_3),&(v158_2));
    let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
    drop(v158_3);
    let v158_5: Space = subtract(&(*CONSTANT_2),&(v158_4));
    drop(v158_4);
    let v158_7: Space = if (v158_5).is_empty() { Space::new() } else {
      let mut v159_6 = Space::new();
      let mut v159_6_cursor = (v157_12_tail).read_zipper();
      for v159_6_byte in v159_6_cursor.child_mask().iter() {
        v159_6_cursor.descend_to_byte(v159_6_byte);
        let v159_6_tail = v159_6_cursor.make_map();
        v159_6_cursor.ascend(1);
        let v159_6_head = Path::from_slice(&[v159_6_byte]);
        let v160_2: Space = singleton(&(v159_6_head));
        let v160_3: Space = intersect(&(*CONSTANT_3),&(v160_2));
        let v160_4: Space = if has_head(&(v160_3)) { singleton(&[]) } else { Space::new() };
        drop(v160_3);
        let v160_5: Space = subtract(&(*CONSTANT_2),&(v160_4));
        drop(v160_4);
        let v160_8: Space = if (v160_5).is_empty() { Space::new() } else {
          let v161_6: Path = concat_path(&(v157_12_head),&(v159_6_head));
          let v161_7: Space = routine_41(c, &(v161_6), &(*p0), &(v159_6_tail), &(*s1));
          compose(&(v160_5),&(v161_7))
        };
        drop(v160_5);
        let v160_9: Space = intersect(&(*CONSTANT_3),&(v160_2));
        drop(v160_2);
        let v160_10: Space = if has_head(&(v160_9)) { singleton(&[]) } else { Space::new() };
        drop(v160_9);
        let v160_12: Space = if (v160_10).is_empty() { Space::new() } else {
          let v162_6: Path = concat_path(&(v157_12_head),&(v159_6_head));
          let v162_11: Space = routine_42(c, &(v162_6), &(*p0), &(v159_6_tail), &(*s1));
          drop(v162_6);
          compose(&(v160_10),&(v162_11))
        };
        drop(v160_10);
        let v160_13: Space = unite(&(v160_8),&(v160_12));
        v159_6.join_into((v160_13).clone());
      }
      drop(v159_6_cursor);
      compose(&(v158_5),&(v159_6))
    };
    drop(v158_5);
    let v158_8: Space = intersect(&(*CONSTANT_3),&(v158_2));
    drop(v158_2);
    let v158_9: Space = if has_head(&(v158_8)) { singleton(&[]) } else { Space::new() };
    drop(v158_8);
    let v158_11: Space = if (v158_9).is_empty() { Space::new() } else {
      let mut v163_10 = Space::new();
      let mut v163_10_cursor = (v157_12_tail).read_zipper();
      for v163_10_byte in v163_10_cursor.child_mask().iter() {
        v163_10_cursor.descend_to_byte(v163_10_byte);
        let v163_10_tail = v163_10_cursor.make_map();
        v163_10_cursor.ascend(1);
        let v163_10_head = Path::from_slice(&[v163_10_byte]);
        let v164_2: Space = singleton(&(v163_10_head));
        let v164_3: Space = intersect(&(*CONSTANT_3),&(v164_2));
        let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
        drop(v164_3);
        let v164_5: Space = subtract(&(*CONSTANT_2),&(v164_4));
        drop(v164_4);
        let v164_8: Space = if (v164_5).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v157_12_head),&(v163_10_head));
          let v165_7: Space = routine_41(c, &(v165_6), &(*p0), &(v163_10_tail), &(*s1));
          compose(&(v164_5),&(v165_7))
        };
        drop(v164_5);
        let v164_9: Space = intersect(&(*CONSTANT_3),&(v164_2));
        drop(v164_2);
        let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
        drop(v164_9);
        let v164_12: Space = if (v164_10).is_empty() { Space::new() } else {
          let v166_6: Path = concat_path(&(v157_12_head),&(v163_10_head));
          let v166_11: Space = routine_43(c, &(v166_6), &(*p0), &(v163_10_tail), &(*s1));
          drop(v166_6);
          compose(&(v164_10),&(v166_11))
        };
        drop(v164_10);
        let v164_13: Space = unite(&(v164_8),&(v164_12));
        v163_10.join_into((v164_13).clone());
      }
      drop(v163_10_cursor);
      compose(&(v158_9),&(v163_10))
    };
    drop(v158_9);
    let v158_12: Space = unite(&(v158_7),&(v158_11));
    v157_12.join_into((v158_12).clone());
  }
  drop(v157_12_cursor);
  (v157_12).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v167_12 = Space::new();
  let mut v167_12_cursor = (*s0).read_zipper();
  for v167_12_byte in v167_12_cursor.child_mask().iter() {
    v167_12_cursor.descend_to_byte(v167_12_byte);
    let v167_12_tail = v167_12_cursor.make_map();
    v167_12_cursor.ascend(1);
    let v167_12_head = Path::from_slice(&[v167_12_byte]);
    let v168_2: Space = singleton(&(v167_12_head));
    let v168_3: Space = intersect(&(*CONSTANT_3),&(v168_2));
    let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
    drop(v168_3);
    let v168_5: Space = subtract(&(*CONSTANT_2),&(v168_4));
    drop(v168_4);
    let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
      let v169_6: Path = concat_path(&(*p0),&(v167_12_head));
      let mut v169_7 = Space::new();
      let mut v169_7_cursor = (v167_12_tail).read_zipper();
      for v169_7_byte in v169_7_cursor.child_mask().iter() {
        v169_7_cursor.descend_to_byte(v169_7_byte);
        let v169_7_tail = v169_7_cursor.make_map();
        v169_7_cursor.ascend(1);
        let v169_7_head = Path::from_slice(&[v169_7_byte]);
        let v170_2: Space = singleton(&(v169_7_head));
        let v170_3: Space = intersect(&(*CONSTANT_3),&(v170_2));
        let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
        drop(v170_3);
        let v170_5: Space = subtract(&(*CONSTANT_2),&(v170_4));
        drop(v170_4);
        let v170_8: Space = if (v170_5).is_empty() { Space::new() } else {
          let v171_6: Path = concat_path(&(v169_6),&(v169_7_head));
          let v171_7: Space = routine_44(c, &(v171_6), &(v169_7_tail), &(*s1));
          compose(&(v170_5),&(v171_7))
        };
        drop(v170_5);
        let v170_9: Space = intersect(&(*CONSTANT_3),&(v170_2));
        drop(v170_2);
        let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
        drop(v170_9);
        let v170_12: Space = if (v170_10).is_empty() { Space::new() } else {
          let v172_6: Path = concat_path(&(v169_6),&(v169_7_head));
          let v172_11: Space = routine_45(c, &(v172_6), &(v169_7_tail), &(*s1));
          drop(v172_6);
          compose(&(v170_10),&(v172_11))
        };
        drop(v170_10);
        let v170_13: Space = unite(&(v170_8),&(v170_12));
        v169_7.join_into((v170_13).clone());
      }
      drop(v169_7_cursor);
      compose(&(v168_5),&(v169_7))
    };
    drop(v168_5);
    let v168_9: Space = intersect(&(*CONSTANT_3),&(v168_2));
    drop(v168_2);
    let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
    drop(v168_9);
    let v168_12: Space = if (v168_10).is_empty() { Space::new() } else {
      let v173_6: Path = concat_path(&(*p0),&(v167_12_head));
      let mut v173_11 = Space::new();
      let mut v173_11_cursor = (v167_12_tail).read_zipper();
      for v173_11_byte in v173_11_cursor.child_mask().iter() {
        v173_11_cursor.descend_to_byte(v173_11_byte);
        let v173_11_tail = v173_11_cursor.make_map();
        v173_11_cursor.ascend(1);
        let v173_11_head = Path::from_slice(&[v173_11_byte]);
        let v174_2: Space = singleton(&(v173_11_head));
        let v174_3: Space = intersect(&(*CONSTANT_3),&(v174_2));
        let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
        drop(v174_3);
        let v174_5: Space = subtract(&(*CONSTANT_2),&(v174_4));
        drop(v174_4);
        let v174_8: Space = if (v174_5).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v173_6),&(v173_11_head));
          let v175_7: Space = routine_44(c, &(v175_6), &(v173_11_tail), &(*s1));
          compose(&(v174_5),&(v175_7))
        };
        drop(v174_5);
        let v174_9: Space = intersect(&(*CONSTANT_3),&(v174_2));
        drop(v174_2);
        let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
        drop(v174_9);
        let v174_12: Space = if (v174_10).is_empty() { Space::new() } else {
          let v176_6: Path = concat_path(&(v173_6),&(v173_11_head));
          let v176_11: Space = routine_15(c, &(v176_6), &(v173_11_tail), &(*s1));
          drop(v176_6);
          compose(&(v174_10),&(v176_11))
        };
        drop(v174_10);
        let v174_13: Space = unite(&(v174_8),&(v174_12));
        v173_11.join_into((v174_13).clone());
      }
      drop(v173_11_cursor);
      drop(v173_6);
      compose(&(v168_10),&(v173_11))
    };
    drop(v168_10);
    let v168_13: Space = unite(&(v168_8),&(v168_12));
    v167_12.join_into((v168_13).clone());
  }
  drop(v167_12_cursor);
  (v167_12).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v177_12 = Space::new();
  let mut v177_12_cursor = (*s0).read_zipper();
  for v177_12_byte in v177_12_cursor.child_mask().iter() {
    v177_12_cursor.descend_to_byte(v177_12_byte);
    let v177_12_tail = v177_12_cursor.make_map();
    v177_12_cursor.ascend(1);
    let v177_12_head = Path::from_slice(&[v177_12_byte]);
    let v178_2: Space = singleton(&(v177_12_head));
    let v178_3: Space = intersect(&(*CONSTANT_3),&(v178_2));
    let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
    drop(v178_3);
    let v178_5: Space = subtract(&(*CONSTANT_2),&(v178_4));
    drop(v178_4);
    let v178_8: Space = if (v178_5).is_empty() { Space::new() } else {
      let v179_6: Path = concat_path(&(*p0),&(v177_12_head));
      let mut v179_7 = Space::new();
      let mut v179_7_cursor = (v177_12_tail).read_zipper();
      for v179_7_byte in v179_7_cursor.child_mask().iter() {
        v179_7_cursor.descend_to_byte(v179_7_byte);
        let v179_7_tail = v179_7_cursor.make_map();
        v179_7_cursor.ascend(1);
        let v179_7_head = Path::from_slice(&[v179_7_byte]);
        let v180_2: Space = singleton(&(v179_7_head));
        let v180_3: Space = intersect(&(*CONSTANT_3),&(v180_2));
        let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
        drop(v180_3);
        let v180_5: Space = subtract(&(*CONSTANT_2),&(v180_4));
        drop(v180_4);
        let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v181_7: Space = routine_44(c, &(v181_6), &(v179_7_tail), &(*s1));
          compose(&(v180_5),&(v181_7))
        };
        drop(v180_5);
        let v180_9: Space = intersect(&(*CONSTANT_3),&(v180_2));
        drop(v180_2);
        let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
        drop(v180_9);
        let v180_12: Space = if (v180_10).is_empty() { Space::new() } else {
          let v182_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v182_11: Space = routine_45(c, &(v182_6), &(v179_7_tail), &(*s1));
          drop(v182_6);
          compose(&(v180_10),&(v182_11))
        };
        drop(v180_10);
        let v180_13: Space = unite(&(v180_8),&(v180_12));
        v179_7.join_into((v180_13).clone());
      }
      drop(v179_7_cursor);
      compose(&(v178_5),&(v179_7))
    };
    drop(v178_5);
    let v178_9: Space = intersect(&(*CONSTANT_3),&(v178_2));
    drop(v178_2);
    let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
    drop(v178_9);
    let v178_12: Space = if (v178_10).is_empty() { Space::new() } else {
      let v183_6: Path = concat_path(&(*p0),&(v177_12_head));
      let mut v183_11 = Space::new();
      let mut v183_11_cursor = (v177_12_tail).read_zipper();
      for v183_11_byte in v183_11_cursor.child_mask().iter() {
        v183_11_cursor.descend_to_byte(v183_11_byte);
        let v183_11_tail = v183_11_cursor.make_map();
        v183_11_cursor.ascend(1);
        let v183_11_head = Path::from_slice(&[v183_11_byte]);
        let v184_2: Space = singleton(&(v183_11_head));
        let v184_3: Space = intersect(&(*CONSTANT_3),&(v184_2));
        let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
        drop(v184_3);
        let v184_5: Space = subtract(&(*CONSTANT_2),&(v184_4));
        drop(v184_4);
        let v184_7: Space = if (v184_5).is_empty() { Space::new() } else {
          let v185_6: Space = routine_46(c, &(v183_11_head), &(v183_6), &(v183_11_tail), &(*s1));
          compose(&(v184_5),&(v185_6))
        };
        drop(v184_5);
        let v184_8: Space = intersect(&(*CONSTANT_3),&(v184_2));
        drop(v184_2);
        let v184_9: Space = if has_head(&(v184_8)) { singleton(&[]) } else { Space::new() };
        drop(v184_8);
        let v184_11: Space = if (v184_9).is_empty() { Space::new() } else {
          let v186_10: Space = routine_47(c, &(v183_11_head), &(v183_6), &(v183_11_tail), &(*s1));
          compose(&(v184_9),&(v186_10))
        };
        drop(v184_9);
        let v184_12: Space = unite(&(v184_7),&(v184_11));
        v183_11.join_into((v184_12).clone());
      }
      drop(v183_11_cursor);
      drop(v183_6);
      compose(&(v178_10),&(v183_11))
    };
    drop(v178_10);
    let v178_13: Space = unite(&(v178_8),&(v178_12));
    v177_12.join_into((v178_13).clone());
  }
  drop(v177_12_cursor);
  (v177_12).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v187_12 = Space::new();
  let mut v187_12_cursor = (*s0).read_zipper();
  for v187_12_byte in v187_12_cursor.child_mask().iter() {
    v187_12_cursor.descend_to_byte(v187_12_byte);
    let v187_12_tail = v187_12_cursor.make_map();
    v187_12_cursor.ascend(1);
    let v187_12_head = Path::from_slice(&[v187_12_byte]);
    let v188_2: Space = singleton(&(v187_12_head));
    let v188_3: Space = intersect(&(*CONSTANT_3),&(v188_2));
    let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
    drop(v188_3);
    let v188_5: Space = subtract(&(*CONSTANT_2),&(v188_4));
    drop(v188_4);
    let v188_7: Space = if (v188_5).is_empty() { Space::new() } else {
      let mut v189_6 = Space::new();
      let mut v189_6_cursor = (v187_12_tail).read_zipper();
      for v189_6_byte in v189_6_cursor.child_mask().iter() {
        v189_6_cursor.descend_to_byte(v189_6_byte);
        let v189_6_tail = v189_6_cursor.make_map();
        v189_6_cursor.ascend(1);
        let v189_6_head = Path::from_slice(&[v189_6_byte]);
        let v190_2: Space = singleton(&(v189_6_head));
        let v190_3: Space = intersect(&(*CONSTANT_3),&(v190_2));
        let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
        drop(v190_3);
        let v190_5: Space = subtract(&(*CONSTANT_2),&(v190_4));
        drop(v190_4);
        let v190_8: Space = if (v190_5).is_empty() { Space::new() } else {
          let v191_6: Path = concat_path(&(v187_12_head),&(v189_6_head));
          let v191_7: Space = routine_48(c, &(v191_6), &(*p0), &(v189_6_tail), &(*s1));
          compose(&(v190_5),&(v191_7))
        };
        drop(v190_5);
        let v190_9: Space = intersect(&(*CONSTANT_3),&(v190_2));
        drop(v190_2);
        let v190_10: Space = if has_head(&(v190_9)) { singleton(&[]) } else { Space::new() };
        drop(v190_9);
        let v190_12: Space = if (v190_10).is_empty() { Space::new() } else {
          let v192_6: Path = concat_path(&(v187_12_head),&(v189_6_head));
          let v192_11: Space = routine_49(c, &(v192_6), &(*p0), &(v189_6_tail), &(*s1));
          drop(v192_6);
          compose(&(v190_10),&(v192_11))
        };
        drop(v190_10);
        let v190_13: Space = unite(&(v190_8),&(v190_12));
        v189_6.join_into((v190_13).clone());
      }
      drop(v189_6_cursor);
      compose(&(v188_5),&(v189_6))
    };
    drop(v188_5);
    let v188_8: Space = intersect(&(*CONSTANT_3),&(v188_2));
    drop(v188_2);
    let v188_9: Space = if has_head(&(v188_8)) { singleton(&[]) } else { Space::new() };
    drop(v188_8);
    let v188_11: Space = if (v188_9).is_empty() { Space::new() } else {
      let mut v193_10 = Space::new();
      let mut v193_10_cursor = (v187_12_tail).read_zipper();
      for v193_10_byte in v193_10_cursor.child_mask().iter() {
        v193_10_cursor.descend_to_byte(v193_10_byte);
        let v193_10_tail = v193_10_cursor.make_map();
        v193_10_cursor.ascend(1);
        let v193_10_head = Path::from_slice(&[v193_10_byte]);
        let v194_2: Space = singleton(&(v193_10_head));
        let v194_3: Space = intersect(&(*CONSTANT_3),&(v194_2));
        let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
        drop(v194_3);
        let v194_5: Space = subtract(&(*CONSTANT_2),&(v194_4));
        drop(v194_4);
        let v194_8: Space = if (v194_5).is_empty() { Space::new() } else {
          let v195_6: Path = concat_path(&(v187_12_head),&(v193_10_head));
          let v195_7: Space = routine_48(c, &(v195_6), &(*p0), &(v193_10_tail), &(*s1));
          compose(&(v194_5),&(v195_7))
        };
        drop(v194_5);
        let v194_9: Space = intersect(&(*CONSTANT_3),&(v194_2));
        drop(v194_2);
        let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
        drop(v194_9);
        let v194_12: Space = if (v194_10).is_empty() { Space::new() } else {
          let v196_6: Path = concat_path(&(v187_12_head),&(v193_10_head));
          let v196_11: Space = routine_50(c, &(v196_6), &(*p0), &(v193_10_tail), &(*s1));
          drop(v196_6);
          compose(&(v194_10),&(v196_11))
        };
        drop(v194_10);
        let v194_13: Space = unite(&(v194_8),&(v194_12));
        v193_10.join_into((v194_13).clone());
      }
      drop(v193_10_cursor);
      compose(&(v188_9),&(v193_10))
    };
    drop(v188_9);
    let v188_12: Space = unite(&(v188_7),&(v188_11));
    v187_12.join_into((v188_12).clone());
  }
  drop(v187_12_cursor);
  (v187_12).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v197_11 = Space::new();
  let mut v197_11_cursor = (*s0).read_zipper();
  for v197_11_byte in v197_11_cursor.child_mask().iter() {
    v197_11_cursor.descend_to_byte(v197_11_byte);
    let v197_11_tail = v197_11_cursor.make_map();
    v197_11_cursor.ascend(1);
    let v197_11_head = Path::from_slice(&[v197_11_byte]);
    let v198_2: Space = singleton(&(v197_11_head));
    let v198_3: Space = intersect(&(*CONSTANT_3),&(v198_2));
    let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
    drop(v198_3);
    let v198_5: Space = subtract(&(*CONSTANT_2),&(v198_4));
    drop(v198_4);
    let v198_8: Space = if (v198_5).is_empty() { Space::new() } else {
      let v199_6: Path = concat_path(&(*p0),&(v197_11_head));
      let mut v199_7 = Space::new();
      let mut v199_7_cursor = (v197_11_tail).read_zipper();
      for v199_7_byte in v199_7_cursor.child_mask().iter() {
        v199_7_cursor.descend_to_byte(v199_7_byte);
        let v199_7_tail = v199_7_cursor.make_map();
        v199_7_cursor.ascend(1);
        let v199_7_head = Path::from_slice(&[v199_7_byte]);
        let v200_2: Space = singleton(&(v199_7_head));
        let v200_3: Space = intersect(&(*CONSTANT_3),&(v200_2));
        let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
        drop(v200_3);
        let v200_5: Space = subtract(&(*CONSTANT_2),&(v200_4));
        drop(v200_4);
        let v200_8: Space = if (v200_5).is_empty() { Space::new() } else {
          let v201_6: Path = concat_path(&(v199_6),&(v199_7_head));
          let v201_7: Space = routine_51(c, &(v201_6), &(v199_7_tail));
          compose(&(v200_5),&(v201_7))
        };
        drop(v200_5);
        let v200_9: Space = intersect(&(*CONSTANT_3),&(v200_2));
        drop(v200_2);
        let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
        drop(v200_9);
        let v200_12: Space = if (v200_10).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v199_6),&(v199_7_head));
          let v202_11: Space = routine_52(c, &(v202_6), &(v199_7_tail));
          drop(v202_6);
          compose(&(v200_10),&(v202_11))
        };
        drop(v200_10);
        let v200_13: Space = unite(&(v200_8),&(v200_12));
        v199_7.join_into((v200_13).clone());
      }
      drop(v199_7_cursor);
      compose(&(v198_5),&(v199_7))
    };
    drop(v198_5);
    let v198_9: Space = intersect(&(*CONSTANT_3),&(v198_2));
    drop(v198_2);
    let v198_10: Space = if has_head(&(v198_9)) { singleton(&[]) } else { Space::new() };
    drop(v198_9);
    let v198_12: Space = if (v198_10).is_empty() { Space::new() } else {
      let v203_6: Path = concat_path(&(*p0),&(v197_11_head));
      let mut v203_11 = Space::new();
      let mut v203_11_cursor = (v197_11_tail).read_zipper();
      for v203_11_byte in v203_11_cursor.child_mask().iter() {
        v203_11_cursor.descend_to_byte(v203_11_byte);
        let v203_11_tail = v203_11_cursor.make_map();
        v203_11_cursor.ascend(1);
        let v203_11_head = Path::from_slice(&[v203_11_byte]);
        let v204_2: Space = singleton(&(v203_11_head));
        let v204_3: Space = intersect(&(*CONSTANT_3),&(v204_2));
        let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
        drop(v204_3);
        let v204_5: Space = subtract(&(*CONSTANT_2),&(v204_4));
        drop(v204_4);
        let v204_8: Space = if (v204_5).is_empty() { Space::new() } else {
          let v205_6: Path = concat_path(&(v203_6),&(v203_11_head));
          let v205_7: Space = routine_51(c, &(v205_6), &(v203_11_tail));
          compose(&(v204_5),&(v205_7))
        };
        drop(v204_5);
        let v204_9: Space = intersect(&(*CONSTANT_3),&(v204_2));
        drop(v204_2);
        let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
        drop(v204_9);
        let v204_12: Space = if (v204_10).is_empty() { Space::new() } else {
          let v206_6: Path = concat_path(&(v203_6),&(v203_11_head));
          let v206_11: Space = routine_3(c, &(v206_6), &(v203_11_tail));
          drop(v206_6);
          compose(&(v204_10),&(v206_11))
        };
        drop(v204_10);
        let v204_13: Space = unite(&(v204_8),&(v204_12));
        v203_11.join_into((v204_13).clone());
      }
      drop(v203_11_cursor);
      drop(v203_6);
      compose(&(v198_10),&(v203_11))
    };
    drop(v198_10);
    let v198_13: Space = unite(&(v198_8),&(v198_12));
    v197_11.join_into((v198_13).clone());
  }
  drop(v197_11_cursor);
  (v197_11).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v207_11 = Space::new();
  let mut v207_11_cursor = (*s0).read_zipper();
  for v207_11_byte in v207_11_cursor.child_mask().iter() {
    v207_11_cursor.descend_to_byte(v207_11_byte);
    let v207_11_tail = v207_11_cursor.make_map();
    v207_11_cursor.ascend(1);
    let v207_11_head = Path::from_slice(&[v207_11_byte]);
    let v208_2: Space = singleton(&(v207_11_head));
    let v208_3: Space = intersect(&(*CONSTANT_3),&(v208_2));
    let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
    drop(v208_3);
    let v208_5: Space = subtract(&(*CONSTANT_2),&(v208_4));
    drop(v208_4);
    let v208_8: Space = if (v208_5).is_empty() { Space::new() } else {
      let v209_6: Path = concat_path(&(*p0),&(v207_11_head));
      let mut v209_7 = Space::new();
      let mut v209_7_cursor = (v207_11_tail).read_zipper();
      for v209_7_byte in v209_7_cursor.child_mask().iter() {
        v209_7_cursor.descend_to_byte(v209_7_byte);
        let v209_7_tail = v209_7_cursor.make_map();
        v209_7_cursor.ascend(1);
        let v209_7_head = Path::from_slice(&[v209_7_byte]);
        let v210_2: Space = singleton(&(v209_7_head));
        let v210_3: Space = intersect(&(*CONSTANT_3),&(v210_2));
        let v210_4: Space = if has_head(&(v210_3)) { singleton(&[]) } else { Space::new() };
        drop(v210_3);
        let v210_5: Space = subtract(&(*CONSTANT_2),&(v210_4));
        drop(v210_4);
        let v210_8: Space = if (v210_5).is_empty() { Space::new() } else {
          let v211_6: Path = concat_path(&(v209_6),&(v209_7_head));
          let v211_7: Space = routine_51(c, &(v211_6), &(v209_7_tail));
          compose(&(v210_5),&(v211_7))
        };
        drop(v210_5);
        let v210_9: Space = intersect(&(*CONSTANT_3),&(v210_2));
        drop(v210_2);
        let v210_10: Space = if has_head(&(v210_9)) { singleton(&[]) } else { Space::new() };
        drop(v210_9);
        let v210_12: Space = if (v210_10).is_empty() { Space::new() } else {
          let v212_6: Path = concat_path(&(v209_6),&(v209_7_head));
          let v212_11: Space = routine_52(c, &(v212_6), &(v209_7_tail));
          drop(v212_6);
          compose(&(v210_10),&(v212_11))
        };
        drop(v210_10);
        let v210_13: Space = unite(&(v210_8),&(v210_12));
        v209_7.join_into((v210_13).clone());
      }
      drop(v209_7_cursor);
      compose(&(v208_5),&(v209_7))
    };
    drop(v208_5);
    let v208_9: Space = intersect(&(*CONSTANT_3),&(v208_2));
    drop(v208_2);
    let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
    drop(v208_9);
    let v208_12: Space = if (v208_10).is_empty() { Space::new() } else {
      let v213_6: Path = concat_path(&(*p0),&(v207_11_head));
      let mut v213_11 = Space::new();
      let mut v213_11_cursor = (v207_11_tail).read_zipper();
      for v213_11_byte in v213_11_cursor.child_mask().iter() {
        v213_11_cursor.descend_to_byte(v213_11_byte);
        let v213_11_tail = v213_11_cursor.make_map();
        v213_11_cursor.ascend(1);
        let v213_11_head = Path::from_slice(&[v213_11_byte]);
        let v214_2: Space = singleton(&(v213_11_head));
        let v214_3: Space = intersect(&(*CONSTANT_3),&(v214_2));
        let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
        drop(v214_3);
        let v214_5: Space = subtract(&(*CONSTANT_2),&(v214_4));
        drop(v214_4);
        let v214_7: Space = if (v214_5).is_empty() { Space::new() } else {
          let v215_6: Space = routine_18(c, &(v213_11_head), &(v213_6), &(v213_11_tail));
          compose(&(v214_5),&(v215_6))
        };
        drop(v214_5);
        let v214_8: Space = intersect(&(*CONSTANT_3),&(v214_2));
        drop(v214_2);
        let v214_9: Space = if has_head(&(v214_8)) { singleton(&[]) } else { Space::new() };
        drop(v214_8);
        let v214_11: Space = if (v214_9).is_empty() { Space::new() } else {
          let v216_10: Space = routine_19(c, &(v213_11_head), &(v213_6), &(v213_11_tail));
          compose(&(v214_9),&(v216_10))
        };
        drop(v214_9);
        let v214_12: Space = unite(&(v214_7),&(v214_11));
        v213_11.join_into((v214_12).clone());
      }
      drop(v213_11_cursor);
      drop(v213_6);
      compose(&(v208_10),&(v213_11))
    };
    drop(v208_10);
    let v208_13: Space = unite(&(v208_8),&(v208_12));
    v207_11.join_into((v208_13).clone());
  }
  drop(v207_11_cursor);
  (v207_11).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v217_12 = Space::new();
  let mut v217_12_cursor = (*s0).read_zipper();
  for v217_12_byte in v217_12_cursor.child_mask().iter() {
    v217_12_cursor.descend_to_byte(v217_12_byte);
    let v217_12_tail = v217_12_cursor.make_map();
    v217_12_cursor.ascend(1);
    let v217_12_head = Path::from_slice(&[v217_12_byte]);
    let v218_2: Space = singleton(&(v217_12_head));
    let v218_3: Space = intersect(&(*CONSTANT_3),&(v218_2));
    let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
    drop(v218_3);
    let v218_5: Space = subtract(&(*CONSTANT_2),&(v218_4));
    drop(v218_4);
    let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
      let v219_6: Path = concat_path(&(*p0),&(v217_12_head));
      let mut v219_7 = Space::new();
      let mut v219_7_cursor = (v217_12_tail).read_zipper();
      for v219_7_byte in v219_7_cursor.child_mask().iter() {
        v219_7_cursor.descend_to_byte(v219_7_byte);
        let v219_7_tail = v219_7_cursor.make_map();
        v219_7_cursor.ascend(1);
        let v219_7_head = Path::from_slice(&[v219_7_byte]);
        let v220_2: Space = singleton(&(v219_7_head));
        let v220_3: Space = intersect(&(*CONSTANT_3),&(v220_2));
        let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
        drop(v220_3);
        let v220_5: Space = subtract(&(*CONSTANT_2),&(v220_4));
        drop(v220_4);
        let v220_8: Space = if (v220_5).is_empty() { Space::new() } else {
          let v221_6: Path = concat_path(&(v219_6),&(v219_7_head));
          let v221_7: Space = routine_53(c, &(v221_6), &(*p1), &(v219_7_tail));
          compose(&(v220_5),&(v221_7))
        };
        drop(v220_5);
        let v220_9: Space = intersect(&(*CONSTANT_3),&(v220_2));
        drop(v220_2);
        let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
        drop(v220_9);
        let v220_12: Space = if (v220_10).is_empty() { Space::new() } else {
          let v222_6: Path = concat_path(&(v219_6),&(v219_7_head));
          let v222_11: Space = routine_54(c, &(v222_6), &(*p1), &(v219_7_tail));
          drop(v222_6);
          compose(&(v220_10),&(v222_11))
        };
        drop(v220_10);
        let v220_13: Space = unite(&(v220_8),&(v220_12));
        v219_7.join_into((v220_13).clone());
      }
      drop(v219_7_cursor);
      compose(&(v218_5),&(v219_7))
    };
    drop(v218_5);
    let v218_9: Space = intersect(&(*CONSTANT_3),&(v218_2));
    drop(v218_2);
    let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
    drop(v218_9);
    let v218_12: Space = if (v218_10).is_empty() { Space::new() } else {
      let v223_6: Path = concat_path(&(*p0),&(v217_12_head));
      let mut v223_11 = Space::new();
      let mut v223_11_cursor = (v217_12_tail).read_zipper();
      for v223_11_byte in v223_11_cursor.child_mask().iter() {
        v223_11_cursor.descend_to_byte(v223_11_byte);
        let v223_11_tail = v223_11_cursor.make_map();
        v223_11_cursor.ascend(1);
        let v223_11_head = Path::from_slice(&[v223_11_byte]);
        let v224_2: Space = singleton(&(v223_11_head));
        let v224_3: Space = intersect(&(*CONSTANT_3),&(v224_2));
        let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
        drop(v224_3);
        let v224_5: Space = subtract(&(*CONSTANT_2),&(v224_4));
        drop(v224_4);
        let v224_8: Space = if (v224_5).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v223_6),&(v223_11_head));
          let v225_7: Space = routine_53(c, &(v225_6), &(*p1), &(v223_11_tail));
          compose(&(v224_5),&(v225_7))
        };
        drop(v224_5);
        let v224_9: Space = intersect(&(*CONSTANT_3),&(v224_2));
        drop(v224_2);
        let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
        drop(v224_9);
        let v224_12: Space = if (v224_10).is_empty() { Space::new() } else {
          let v226_6: Path = concat_path(&(v223_6),&(v223_11_head));
          let v226_11: Space = routine_22(c, &(v226_6), &(*p1), &(v223_11_tail));
          drop(v226_6);
          compose(&(v224_10),&(v226_11))
        };
        drop(v224_10);
        let v224_13: Space = unite(&(v224_8),&(v224_12));
        v223_11.join_into((v224_13).clone());
      }
      drop(v223_11_cursor);
      drop(v223_6);
      compose(&(v218_10),&(v223_11))
    };
    drop(v218_10);
    let v218_13: Space = unite(&(v218_8),&(v218_12));
    v217_12.join_into((v218_13).clone());
  }
  drop(v217_12_cursor);
  (v217_12).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v227_10 = Space::new();
  let mut v227_10_cursor = (*s0).read_zipper();
  for v227_10_byte in v227_10_cursor.child_mask().iter() {
    v227_10_cursor.descend_to_byte(v227_10_byte);
    let v227_10_tail = v227_10_cursor.make_map();
    v227_10_cursor.ascend(1);
    let v227_10_head = Path::from_slice(&[v227_10_byte]);
    let v228_2: Space = singleton(&(v227_10_head));
    let v228_3: Space = intersect(&(*CONSTANT_3),&(v228_2));
    let v228_4: Space = if has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
    drop(v228_3);
    let v228_5: Space = compose(&(v228_4),&(v227_10_tail));
    drop(v228_4);
    let v229_6: Path = concat_path(&(*p0),&(v227_10_head));
    let v228_7: Space = wrap(&(v228_5),&(v229_6));
    drop(v228_5);
    let v228_8: Space = wrap(&(v228_7),&(*p1));
    drop(v228_7);
    let v228_9: Space = wrap(&(v228_8),&(*CONSTANT_5));
    drop(v228_8);
    let v228_10: Space = intersect(&(*CONSTANT_3),&(v228_2));
    drop(v228_2);
    let v228_11: Space = if has_head(&(v228_10)) { singleton(&[]) } else { Space::new() };
    drop(v228_10);
    let v228_12: Space = subtract(&(*CONSTANT_2),&(v228_11));
    drop(v228_11);
    let v228_14: Space = if (v228_12).is_empty() { Space::new() } else {
      let mut v230_13 = Space::new();
      let mut v230_13_cursor = (v227_10_tail).read_zipper();
      for v230_13_byte in v230_13_cursor.child_mask().iter() {
        v230_13_cursor.descend_to_byte(v230_13_byte);
        let v230_13_tail = v230_13_cursor.make_map();
        v230_13_cursor.ascend(1);
        let v230_13_head = Path::from_slice(&[v230_13_byte]);
        let v231_2: Space = singleton(&(v230_13_head));
        let v231_3: Space = intersect(&(*CONSTANT_3),&(v231_2));
        let v231_4: Space = if has_head(&(v231_3)) { singleton(&[]) } else { Space::new() };
        drop(v231_3);
        let v231_5: Space = subtract(&(*CONSTANT_2),&(v231_4));
        drop(v231_4);
        let v231_8: Space = if (v231_5).is_empty() { Space::new() } else {
          let v232_6: Path = concat_path(&(v229_6),&(v230_13_head));
          let v232_7: Space = routine_53(c, &(v232_6), &(*p1), &(v230_13_tail));
          compose(&(v231_5),&(v232_7))
        };
        drop(v231_5);
        let v231_9: Space = intersect(&(*CONSTANT_3),&(v231_2));
        drop(v231_2);
        let v231_10: Space = if has_head(&(v231_9)) { singleton(&[]) } else { Space::new() };
        drop(v231_9);
        let v231_12: Space = if (v231_10).is_empty() { Space::new() } else {
          let v233_6: Path = concat_path(&(v229_6),&(v230_13_head));
          let v233_11: Space = routine_54(c, &(v233_6), &(*p1), &(v230_13_tail));
          drop(v233_6);
          compose(&(v231_10),&(v233_11))
        };
        drop(v231_10);
        let v231_13: Space = unite(&(v231_8),&(v231_12));
        v230_13.join_into((v231_13).clone());
      }
      drop(v230_13_cursor);
      compose(&(v228_12),&(v230_13))
    };
    drop(v228_12);
    let v228_15: Space = unite(&(v228_9),&(v228_14));
    drop(v228_9);
    v227_10.join_into((v228_15).clone());
  }
  drop(v227_10_cursor);
  (v227_10).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v234_12 = Space::new();
  let mut v234_12_cursor = (*s0).read_zipper();
  for v234_12_byte in v234_12_cursor.child_mask().iter() {
    v234_12_cursor.descend_to_byte(v234_12_byte);
    let v234_12_tail = v234_12_cursor.make_map();
    v234_12_cursor.ascend(1);
    let v234_12_head = Path::from_slice(&[v234_12_byte]);
    let v235_2: Space = singleton(&(v234_12_head));
    let v235_3: Space = intersect(&(*CONSTANT_3),&(v235_2));
    let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
    drop(v235_3);
    let v235_5: Space = subtract(&(*CONSTANT_2),&(v235_4));
    drop(v235_4);
    let v235_8: Space = if (v235_5).is_empty() { Space::new() } else {
      let v236_6: Path = concat_path(&(*p0),&(v234_12_head));
      let mut v236_7 = Space::new();
      let mut v236_7_cursor = (v234_12_tail).read_zipper();
      for v236_7_byte in v236_7_cursor.child_mask().iter() {
        v236_7_cursor.descend_to_byte(v236_7_byte);
        let v236_7_tail = v236_7_cursor.make_map();
        v236_7_cursor.ascend(1);
        let v236_7_head = Path::from_slice(&[v236_7_byte]);
        let v237_2: Space = singleton(&(v236_7_head));
        let v237_3: Space = intersect(&(*CONSTANT_3),&(v237_2));
        let v237_4: Space = if has_head(&(v237_3)) { singleton(&[]) } else { Space::new() };
        drop(v237_3);
        let v237_5: Space = subtract(&(*CONSTANT_2),&(v237_4));
        drop(v237_4);
        let v237_8: Space = if (v237_5).is_empty() { Space::new() } else {
          let v238_6: Path = concat_path(&(v236_6),&(v236_7_head));
          let v238_7: Space = routine_55(c, &(v238_6), &(*p1), &(v236_7_tail));
          compose(&(v237_5),&(v238_7))
        };
        drop(v237_5);
        let v237_9: Space = intersect(&(*CONSTANT_3),&(v237_2));
        drop(v237_2);
        let v237_10: Space = if has_head(&(v237_9)) { singleton(&[]) } else { Space::new() };
        drop(v237_9);
        let v237_12: Space = if (v237_10).is_empty() { Space::new() } else {
          let v239_6: Path = concat_path(&(v236_6),&(v236_7_head));
          let v239_11: Space = routine_56(c, &(v239_6), &(*p1), &(v236_7_tail));
          drop(v239_6);
          compose(&(v237_10),&(v239_11))
        };
        drop(v237_10);
        let v237_13: Space = unite(&(v237_8),&(v237_12));
        v236_7.join_into((v237_13).clone());
      }
      drop(v236_7_cursor);
      compose(&(v235_5),&(v236_7))
    };
    drop(v235_5);
    let v235_9: Space = intersect(&(*CONSTANT_3),&(v235_2));
    drop(v235_2);
    let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
    drop(v235_9);
    let v235_12: Space = if (v235_10).is_empty() { Space::new() } else {
      let v240_6: Path = concat_path(&(*p0),&(v234_12_head));
      let mut v240_11 = Space::new();
      let mut v240_11_cursor = (v234_12_tail).read_zipper();
      for v240_11_byte in v240_11_cursor.child_mask().iter() {
        v240_11_cursor.descend_to_byte(v240_11_byte);
        let v240_11_tail = v240_11_cursor.make_map();
        v240_11_cursor.ascend(1);
        let v240_11_head = Path::from_slice(&[v240_11_byte]);
        let v241_2: Space = singleton(&(v240_11_head));
        let v241_3: Space = intersect(&(*CONSTANT_3),&(v241_2));
        let v241_4: Space = if has_head(&(v241_3)) { singleton(&[]) } else { Space::new() };
        drop(v241_3);
        let v241_5: Space = subtract(&(*CONSTANT_2),&(v241_4));
        drop(v241_4);
        let v241_8: Space = if (v241_5).is_empty() { Space::new() } else {
          let v242_6: Path = concat_path(&(v240_6),&(v240_11_head));
          let v242_7: Space = routine_55(c, &(v242_6), &(*p1), &(v240_11_tail));
          compose(&(v241_5),&(v242_7))
        };
        drop(v241_5);
        let v241_9: Space = intersect(&(*CONSTANT_3),&(v241_2));
        drop(v241_2);
        let v241_10: Space = if has_head(&(v241_9)) { singleton(&[]) } else { Space::new() };
        drop(v241_9);
        let v241_12: Space = if (v241_10).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v240_6),&(v240_11_head));
          let v243_11: Space = routine_22(c, &(v243_6), &(*p1), &(v240_11_tail));
          drop(v243_6);
          compose(&(v241_10),&(v243_11))
        };
        drop(v241_10);
        let v241_13: Space = unite(&(v241_8),&(v241_12));
        v240_11.join_into((v241_13).clone());
      }
      drop(v240_11_cursor);
      drop(v240_6);
      compose(&(v235_10),&(v240_11))
    };
    drop(v235_10);
    let v235_13: Space = unite(&(v235_8),&(v235_12));
    v234_12.join_into((v235_13).clone());
  }
  drop(v234_12_cursor);
  (v234_12).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v244_10 = Space::new();
  let mut v244_10_cursor = (*s0).read_zipper();
  for v244_10_byte in v244_10_cursor.child_mask().iter() {
    v244_10_cursor.descend_to_byte(v244_10_byte);
    let v244_10_tail = v244_10_cursor.make_map();
    v244_10_cursor.ascend(1);
    let v244_10_head = Path::from_slice(&[v244_10_byte]);
    let v245_2: Space = singleton(&(v244_10_head));
    let v245_3: Space = intersect(&(*CONSTANT_3),&(v245_2));
    let v245_4: Space = if has_head(&(v245_3)) { singleton(&[]) } else { Space::new() };
    drop(v245_3);
    let v245_5: Space = compose(&(v245_4),&(v244_10_tail));
    drop(v245_4);
    let v246_6: Path = concat_path(&(*p0),&(v244_10_head));
    let v245_7: Space = wrap(&(v245_5),&(v246_6));
    drop(v245_5);
    let v245_8: Space = wrap(&(v245_7),&(*p1));
    drop(v245_7);
    let v245_9: Space = wrap(&(v245_8),&(*CONSTANT_5));
    drop(v245_8);
    let v245_10: Space = intersect(&(*CONSTANT_3),&(v245_2));
    drop(v245_2);
    let v245_11: Space = if has_head(&(v245_10)) { singleton(&[]) } else { Space::new() };
    drop(v245_10);
    let v245_12: Space = subtract(&(*CONSTANT_2),&(v245_11));
    drop(v245_11);
    let v245_14: Space = if (v245_12).is_empty() { Space::new() } else {
      let mut v247_13 = Space::new();
      let mut v247_13_cursor = (v244_10_tail).read_zipper();
      for v247_13_byte in v247_13_cursor.child_mask().iter() {
        v247_13_cursor.descend_to_byte(v247_13_byte);
        let v247_13_tail = v247_13_cursor.make_map();
        v247_13_cursor.ascend(1);
        let v247_13_head = Path::from_slice(&[v247_13_byte]);
        let v248_2: Space = singleton(&(v247_13_head));
        let v248_3: Space = intersect(&(*CONSTANT_3),&(v248_2));
        let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
        drop(v248_3);
        let v248_5: Space = subtract(&(*CONSTANT_2),&(v248_4));
        drop(v248_4);
        let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
          let v249_6: Path = concat_path(&(v246_6),&(v247_13_head));
          let v249_7: Space = routine_55(c, &(v249_6), &(*p1), &(v247_13_tail));
          compose(&(v248_5),&(v249_7))
        };
        drop(v248_5);
        let v248_9: Space = intersect(&(*CONSTANT_3),&(v248_2));
        drop(v248_2);
        let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
        drop(v248_9);
        let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
          let v250_6: Path = concat_path(&(v246_6),&(v247_13_head));
          let v250_11: Space = routine_56(c, &(v250_6), &(*p1), &(v247_13_tail));
          drop(v250_6);
          compose(&(v248_10),&(v250_11))
        };
        drop(v248_10);
        let v248_13: Space = unite(&(v248_8),&(v248_12));
        v247_13.join_into((v248_13).clone());
      }
      drop(v247_13_cursor);
      compose(&(v245_12),&(v247_13))
    };
    drop(v245_12);
    let v245_15: Space = unite(&(v245_9),&(v245_14));
    drop(v245_9);
    v244_10.join_into((v245_15).clone());
  }
  drop(v244_10_cursor);
  (v244_10).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v251_3: Space = wrap(&(*s0),&(*p0));
  let v251_4: Space = wrap(&(v251_3),&(*p1));
  drop(v251_3);
  let v251_6: Space = wrap(&(v251_4),&(*CONSTANT_5));
  drop(v251_4);
  (v251_6).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v252_12 = Space::new();
  let mut v252_12_cursor = (*s0).read_zipper();
  for v252_12_byte in v252_12_cursor.child_mask().iter() {
    v252_12_cursor.descend_to_byte(v252_12_byte);
    let v252_12_tail = v252_12_cursor.make_map();
    v252_12_cursor.ascend(1);
    let v252_12_head = Path::from_slice(&[v252_12_byte]);
    let v253_2: Space = singleton(&(v252_12_head));
    let v253_3: Space = intersect(&(*CONSTANT_3),&(v253_2));
    let v253_4: Space = if has_head(&(v253_3)) { singleton(&[]) } else { Space::new() };
    drop(v253_3);
    let v253_5: Space = subtract(&(*CONSTANT_2),&(v253_4));
    drop(v253_4);
    let v253_8: Space = if (v253_5).is_empty() { Space::new() } else {
      let v254_6: Path = concat_path(&(*p0),&(v252_12_head));
      let mut v254_7 = Space::new();
      let mut v254_7_cursor = (v252_12_tail).read_zipper();
      for v254_7_byte in v254_7_cursor.child_mask().iter() {
        v254_7_cursor.descend_to_byte(v254_7_byte);
        let v254_7_tail = v254_7_cursor.make_map();
        v254_7_cursor.ascend(1);
        let v254_7_head = Path::from_slice(&[v254_7_byte]);
        let v255_2: Space = singleton(&(v254_7_head));
        let v255_3: Space = intersect(&(*CONSTANT_3),&(v255_2));
        let v255_4: Space = if has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
        drop(v255_3);
        let v255_5: Space = subtract(&(*CONSTANT_2),&(v255_4));
        drop(v255_4);
        let v255_8: Space = if (v255_5).is_empty() { Space::new() } else {
          let v256_6: Path = concat_path(&(v254_6),&(v254_7_head));
          let v256_7: Space = routine_57(c, &(v256_6), &(v254_7_tail), &(*s1));
          compose(&(v255_5),&(v256_7))
        };
        drop(v255_5);
        let v255_9: Space = intersect(&(*CONSTANT_3),&(v255_2));
        drop(v255_2);
        let v255_10: Space = if has_head(&(v255_9)) { singleton(&[]) } else { Space::new() };
        drop(v255_9);
        let v255_12: Space = if (v255_10).is_empty() { Space::new() } else {
          let v257_6: Path = concat_path(&(v254_6),&(v254_7_head));
          let v257_11: Space = routine_58(c, &(v257_6), &(v254_7_tail), &(*s1));
          drop(v257_6);
          compose(&(v255_10),&(v257_11))
        };
        drop(v255_10);
        let v255_13: Space = unite(&(v255_8),&(v255_12));
        v254_7.join_into((v255_13).clone());
      }
      drop(v254_7_cursor);
      compose(&(v253_5),&(v254_7))
    };
    drop(v253_5);
    let v253_9: Space = intersect(&(*CONSTANT_3),&(v253_2));
    drop(v253_2);
    let v253_10: Space = if has_head(&(v253_9)) { singleton(&[]) } else { Space::new() };
    drop(v253_9);
    let v253_12: Space = if (v253_10).is_empty() { Space::new() } else {
      let v258_6: Path = concat_path(&(*p0),&(v252_12_head));
      let mut v258_11 = Space::new();
      let mut v258_11_cursor = (v252_12_tail).read_zipper();
      for v258_11_byte in v258_11_cursor.child_mask().iter() {
        v258_11_cursor.descend_to_byte(v258_11_byte);
        let v258_11_tail = v258_11_cursor.make_map();
        v258_11_cursor.ascend(1);
        let v258_11_head = Path::from_slice(&[v258_11_byte]);
        let v259_2: Space = singleton(&(v258_11_head));
        let v259_3: Space = intersect(&(*CONSTANT_3),&(v259_2));
        let v259_4: Space = if has_head(&(v259_3)) { singleton(&[]) } else { Space::new() };
        drop(v259_3);
        let v259_5: Space = subtract(&(*CONSTANT_2),&(v259_4));
        drop(v259_4);
        let v259_8: Space = if (v259_5).is_empty() { Space::new() } else {
          let v260_6: Path = concat_path(&(v258_6),&(v258_11_head));
          let v260_7: Space = routine_57(c, &(v260_6), &(v258_11_tail), &(*s1));
          compose(&(v259_5),&(v260_7))
        };
        drop(v259_5);
        let v259_9: Space = intersect(&(*CONSTANT_3),&(v259_2));
        drop(v259_2);
        let v259_10: Space = if has_head(&(v259_9)) { singleton(&[]) } else { Space::new() };
        drop(v259_9);
        let v259_12: Space = if (v259_10).is_empty() { Space::new() } else {
          let v261_6: Path = concat_path(&(v258_6),&(v258_11_head));
          let v261_11: Space = routine_6(c, &(v261_6), &(v258_11_tail), &(*s1));
          drop(v261_6);
          compose(&(v259_10),&(v261_11))
        };
        drop(v259_10);
        let v259_13: Space = unite(&(v259_8),&(v259_12));
        v258_11.join_into((v259_13).clone());
      }
      drop(v258_11_cursor);
      drop(v258_6);
      compose(&(v253_10),&(v258_11))
    };
    drop(v253_10);
    let v253_13: Space = unite(&(v253_8),&(v253_12));
    v252_12.join_into((v253_13).clone());
  }
  drop(v252_12_cursor);
  (v252_12).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v262_12 = Space::new();
  let mut v262_12_cursor = (*s0).read_zipper();
  for v262_12_byte in v262_12_cursor.child_mask().iter() {
    v262_12_cursor.descend_to_byte(v262_12_byte);
    let v262_12_tail = v262_12_cursor.make_map();
    v262_12_cursor.ascend(1);
    let v262_12_head = Path::from_slice(&[v262_12_byte]);
    let v263_2: Space = singleton(&(v262_12_head));
    let v263_3: Space = intersect(&(*CONSTANT_3),&(v263_2));
    let v263_4: Space = if has_head(&(v263_3)) { singleton(&[]) } else { Space::new() };
    drop(v263_3);
    let v263_5: Space = subtract(&(*CONSTANT_2),&(v263_4));
    drop(v263_4);
    let v263_8: Space = if (v263_5).is_empty() { Space::new() } else {
      let v264_6: Path = concat_path(&(*p0),&(v262_12_head));
      let mut v264_7 = Space::new();
      let mut v264_7_cursor = (v262_12_tail).read_zipper();
      for v264_7_byte in v264_7_cursor.child_mask().iter() {
        v264_7_cursor.descend_to_byte(v264_7_byte);
        let v264_7_tail = v264_7_cursor.make_map();
        v264_7_cursor.ascend(1);
        let v264_7_head = Path::from_slice(&[v264_7_byte]);
        let v265_2: Space = singleton(&(v264_7_head));
        let v265_3: Space = intersect(&(*CONSTANT_3),&(v265_2));
        let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
        drop(v265_3);
        let v265_5: Space = subtract(&(*CONSTANT_2),&(v265_4));
        drop(v265_4);
        let v265_8: Space = if (v265_5).is_empty() { Space::new() } else {
          let v266_6: Path = concat_path(&(v264_6),&(v264_7_head));
          let v266_7: Space = routine_57(c, &(v266_6), &(v264_7_tail), &(*s1));
          compose(&(v265_5),&(v266_7))
        };
        drop(v265_5);
        let v265_9: Space = intersect(&(*CONSTANT_3),&(v265_2));
        drop(v265_2);
        let v265_10: Space = if has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
        drop(v265_9);
        let v265_12: Space = if (v265_10).is_empty() { Space::new() } else {
          let v267_6: Path = concat_path(&(v264_6),&(v264_7_head));
          let v267_11: Space = routine_58(c, &(v267_6), &(v264_7_tail), &(*s1));
          drop(v267_6);
          compose(&(v265_10),&(v267_11))
        };
        drop(v265_10);
        let v265_13: Space = unite(&(v265_8),&(v265_12));
        v264_7.join_into((v265_13).clone());
      }
      drop(v264_7_cursor);
      compose(&(v263_5),&(v264_7))
    };
    drop(v263_5);
    let v263_9: Space = intersect(&(*CONSTANT_3),&(v263_2));
    drop(v263_2);
    let v263_10: Space = if has_head(&(v263_9)) { singleton(&[]) } else { Space::new() };
    drop(v263_9);
    let v263_12: Space = if (v263_10).is_empty() { Space::new() } else {
      let v268_6: Path = concat_path(&(*p0),&(v262_12_head));
      let mut v268_11 = Space::new();
      let mut v268_11_cursor = (v262_12_tail).read_zipper();
      for v268_11_byte in v268_11_cursor.child_mask().iter() {
        v268_11_cursor.descend_to_byte(v268_11_byte);
        let v268_11_tail = v268_11_cursor.make_map();
        v268_11_cursor.ascend(1);
        let v268_11_head = Path::from_slice(&[v268_11_byte]);
        let v269_2: Space = singleton(&(v268_11_head));
        let v269_3: Space = intersect(&(*CONSTANT_3),&(v269_2));
        let v269_4: Space = if has_head(&(v269_3)) { singleton(&[]) } else { Space::new() };
        drop(v269_3);
        let v269_5: Space = subtract(&(*CONSTANT_2),&(v269_4));
        drop(v269_4);
        let v269_7: Space = if (v269_5).is_empty() { Space::new() } else {
          let v270_6: Space = routine_25(c, &(v268_11_head), &(v268_6), &(v268_11_tail), &(*s1));
          compose(&(v269_5),&(v270_6))
        };
        drop(v269_5);
        let v269_8: Space = intersect(&(*CONSTANT_3),&(v269_2));
        drop(v269_2);
        let v269_9: Space = if has_head(&(v269_8)) { singleton(&[]) } else { Space::new() };
        drop(v269_8);
        let v269_11: Space = if (v269_9).is_empty() { Space::new() } else {
          let v271_10: Space = routine_26(c, &(v268_11_head), &(v268_6), &(v268_11_tail), &(*s1));
          compose(&(v269_9),&(v271_10))
        };
        drop(v269_9);
        let v269_12: Space = unite(&(v269_7),&(v269_11));
        v268_11.join_into((v269_12).clone());
      }
      drop(v268_11_cursor);
      drop(v268_6);
      compose(&(v263_10),&(v268_11))
    };
    drop(v263_10);
    let v263_13: Space = unite(&(v263_8),&(v263_12));
    v262_12.join_into((v263_13).clone());
  }
  drop(v262_12_cursor);
  (v262_12).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v272_13 = Space::new();
  let mut v272_13_cursor = (*s0).read_zipper();
  for v272_13_byte in v272_13_cursor.child_mask().iter() {
    v272_13_cursor.descend_to_byte(v272_13_byte);
    let v272_13_tail = v272_13_cursor.make_map();
    v272_13_cursor.ascend(1);
    let v272_13_head = Path::from_slice(&[v272_13_byte]);
    let v273_2: Space = singleton(&(v272_13_head));
    let v273_3: Space = intersect(&(*CONSTANT_3),&(v273_2));
    let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
    drop(v273_3);
    let v273_5: Space = subtract(&(*CONSTANT_2),&(v273_4));
    drop(v273_4);
    let v273_8: Space = if (v273_5).is_empty() { Space::new() } else {
      let v274_6: Path = concat_path(&(*p0),&(v272_13_head));
      let mut v274_7 = Space::new();
      let mut v274_7_cursor = (v272_13_tail).read_zipper();
      for v274_7_byte in v274_7_cursor.child_mask().iter() {
        v274_7_cursor.descend_to_byte(v274_7_byte);
        let v274_7_tail = v274_7_cursor.make_map();
        v274_7_cursor.ascend(1);
        let v274_7_head = Path::from_slice(&[v274_7_byte]);
        let v275_2: Space = singleton(&(v274_7_head));
        let v275_3: Space = intersect(&(*CONSTANT_3),&(v275_2));
        let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
        drop(v275_3);
        let v275_5: Space = subtract(&(*CONSTANT_2),&(v275_4));
        drop(v275_4);
        let v275_8: Space = if (v275_5).is_empty() { Space::new() } else {
          let v276_6: Path = concat_path(&(v274_6),&(v274_7_head));
          let v276_7: Space = routine_59(c, &(v276_6), &(*p1), &(v274_7_tail), &(*s1));
          compose(&(v275_5),&(v276_7))
        };
        drop(v275_5);
        let v275_9: Space = intersect(&(*CONSTANT_3),&(v275_2));
        drop(v275_2);
        let v275_10: Space = if has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
        drop(v275_9);
        let v275_12: Space = if (v275_10).is_empty() { Space::new() } else {
          let v277_6: Path = concat_path(&(v274_6),&(v274_7_head));
          let v277_11: Space = routine_60(c, &(v277_6), &(*p1), &(v274_7_tail), &(*s1));
          drop(v277_6);
          compose(&(v275_10),&(v277_11))
        };
        drop(v275_10);
        let v275_13: Space = unite(&(v275_8),&(v275_12));
        v274_7.join_into((v275_13).clone());
      }
      drop(v274_7_cursor);
      compose(&(v273_5),&(v274_7))
    };
    drop(v273_5);
    let v273_9: Space = intersect(&(*CONSTANT_3),&(v273_2));
    drop(v273_2);
    let v273_10: Space = if has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
    drop(v273_9);
    let v273_12: Space = if (v273_10).is_empty() { Space::new() } else {
      let v278_6: Path = concat_path(&(*p0),&(v272_13_head));
      let mut v278_11 = Space::new();
      let mut v278_11_cursor = (v272_13_tail).read_zipper();
      for v278_11_byte in v278_11_cursor.child_mask().iter() {
        v278_11_cursor.descend_to_byte(v278_11_byte);
        let v278_11_tail = v278_11_cursor.make_map();
        v278_11_cursor.ascend(1);
        let v278_11_head = Path::from_slice(&[v278_11_byte]);
        let v279_2: Space = singleton(&(v278_11_head));
        let v279_3: Space = intersect(&(*CONSTANT_3),&(v279_2));
        let v279_4: Space = if has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
        drop(v279_3);
        let v279_5: Space = subtract(&(*CONSTANT_2),&(v279_4));
        drop(v279_4);
        let v279_8: Space = if (v279_5).is_empty() { Space::new() } else {
          let v280_6: Path = concat_path(&(v278_6),&(v278_11_head));
          let v280_7: Space = routine_59(c, &(v280_6), &(*p1), &(v278_11_tail), &(*s1));
          compose(&(v279_5),&(v280_7))
        };
        drop(v279_5);
        let v279_9: Space = intersect(&(*CONSTANT_3),&(v279_2));
        drop(v279_2);
        let v279_10: Space = if has_head(&(v279_9)) { singleton(&[]) } else { Space::new() };
        drop(v279_9);
        let v279_12: Space = if (v279_10).is_empty() { Space::new() } else {
          let v281_6: Path = concat_path(&(v278_6),&(v278_11_head));
          let v281_11: Space = routine_29(c, &(v281_6), &(*p1), &(v278_11_tail), &(*s1));
          drop(v281_6);
          compose(&(v279_10),&(v281_11))
        };
        drop(v279_10);
        let v279_13: Space = unite(&(v279_8),&(v279_12));
        v278_11.join_into((v279_13).clone());
      }
      drop(v278_11_cursor);
      drop(v278_6);
      compose(&(v273_10),&(v278_11))
    };
    drop(v273_10);
    let v273_13: Space = unite(&(v273_8),&(v273_12));
    v272_13.join_into((v273_13).clone());
  }
  drop(v272_13_cursor);
  (v272_13).clone()
}

fn routine_26(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v282_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v282_10: Space = unwrap(&(v282_8),&(*CONSTANT_5));
  drop(v282_8);
  let v282_11: Space = unwrap(&(v282_10),&(*p0));
  drop(v282_10);
  let mut v282_18 = Space::new();
  let mut v282_18_cursor = (*s0).read_zipper();
  for v282_18_byte in v282_18_cursor.child_mask().iter() {
    v282_18_cursor.descend_to_byte(v282_18_byte);
    let v282_18_tail = v282_18_cursor.make_map();
    v282_18_cursor.ascend(1);
    let v282_18_head = Path::from_slice(&[v282_18_byte]);
    let v283_2: Space = singleton(&(v282_18_head));
    let v283_3: Space = intersect(&(*CONSTANT_3),&(v283_2));
    let v283_4: Space = if has_head(&(v283_3)) { singleton(&[]) } else { Space::new() };
    drop(v283_3);
    let v283_5: Space = subtract(&(*CONSTANT_2),&(v283_4));
    drop(v283_4);
    let v283_8: Space = if (v283_5).is_empty() { Space::new() } else {
      let v284_6: Path = concat_path(&(*p0),&(v282_18_head));
      let mut v284_7 = Space::new();
      let mut v284_7_cursor = (v282_18_tail).read_zipper();
      for v284_7_byte in v284_7_cursor.child_mask().iter() {
        v284_7_cursor.descend_to_byte(v284_7_byte);
        let v284_7_tail = v284_7_cursor.make_map();
        v284_7_cursor.ascend(1);
        let v284_7_head = Path::from_slice(&[v284_7_byte]);
        let v285_2: Space = singleton(&(v284_7_head));
        let v285_3: Space = intersect(&(*CONSTANT_3),&(v285_2));
        let v285_4: Space = if has_head(&(v285_3)) { singleton(&[]) } else { Space::new() };
        drop(v285_3);
        let v285_5: Space = subtract(&(*CONSTANT_2),&(v285_4));
        drop(v285_4);
        let v285_8: Space = if (v285_5).is_empty() { Space::new() } else {
          let v286_6: Path = concat_path(&(v284_6),&(v284_7_head));
          let v286_7: Space = routine_59(c, &(v286_6), &(*p1), &(v284_7_tail), &(*s1));
          compose(&(v285_5),&(v286_7))
        };
        drop(v285_5);
        let v285_9: Space = intersect(&(*CONSTANT_3),&(v285_2));
        drop(v285_2);
        let v285_10: Space = if has_head(&(v285_9)) { singleton(&[]) } else { Space::new() };
        drop(v285_9);
        let v285_12: Space = if (v285_10).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v284_6),&(v284_7_head));
          let v287_11: Space = routine_60(c, &(v287_6), &(*p1), &(v284_7_tail), &(*s1));
          drop(v287_6);
          compose(&(v285_10),&(v287_11))
        };
        drop(v285_10);
        let v285_13: Space = unite(&(v285_8),&(v285_12));
        v284_7.join_into((v285_13).clone());
      }
      drop(v284_7_cursor);
      drop(v284_6);
      compose(&(v283_5),&(v284_7))
    };
    drop(v283_5);
    let v283_9: Space = intersect(&(*CONSTANT_3),&(v283_2));
    drop(v283_2);
    let v283_10: Space = if has_head(&(v283_9)) { singleton(&[]) } else { Space::new() };
    drop(v283_9);
    let v283_13: Space = if (v283_10).is_empty() { Space::new() } else {
      let v288_11: Space = unwrap(&(v282_11),&(v282_18_head));
      let mut v288_12 = Space::new();
      let mut v288_12_cursor = (v288_11).read_zipper();
      for v288_12_byte in v288_12_cursor.child_mask().iter() {
        v288_12_cursor.descend_to_byte(v288_12_byte);
        let v288_12_tail = v288_12_cursor.make_map();
        v288_12_cursor.ascend(1);
        let v288_12_head = Path::from_slice(&[v288_12_byte]);
        let v289_2: Space = singleton(&(v288_12_head));
        let v289_3: Space = intersect(&(*CONSTANT_3),&(v289_2));
        let v289_4: Space = if has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
        drop(v289_3);
        let v289_5: Space = subtract(&(*CONSTANT_2),&(v289_4));
        drop(v289_4);
        let v289_7: Space = if (v289_5).is_empty() { Space::new() } else {
          let v290_6: Space = routine_61(c, &(v288_12_head), &(*p1), &(v288_12_tail));
          compose(&(v289_5),&(v290_6))
        };
        drop(v289_5);
        let v289_8: Space = intersect(&(*CONSTANT_3),&(v289_2));
        drop(v289_2);
        let v289_9: Space = if has_head(&(v289_8)) { singleton(&[]) } else { Space::new() };
        drop(v289_8);
        let v289_11: Space = if (v289_9).is_empty() { Space::new() } else {
          let v291_10: Space = routine_62(c, &(v288_12_head), &(*p1), &(v288_12_tail));
          compose(&(v289_9),&(v291_10))
        };
        drop(v289_9);
        let v289_12: Space = unite(&(v289_7),&(v289_11));
        v288_12.join_into((v289_12).clone());
      }
      drop(v288_12_cursor);
      drop(v288_11);
      compose(&(v283_10),&(v288_12))
    };
    drop(v283_10);
    let v283_14: Space = unite(&(v283_8),&(v283_13));
    v282_18.join_into((v283_14).clone());
  }
  drop(v282_18_cursor);
  drop(v282_11);
  (v282_18).clone()
}

fn routine_27(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v292_13 = Space::new();
  let mut v292_13_cursor = (*s0).read_zipper();
  for v292_13_byte in v292_13_cursor.child_mask().iter() {
    v292_13_cursor.descend_to_byte(v292_13_byte);
    let v292_13_tail = v292_13_cursor.make_map();
    v292_13_cursor.ascend(1);
    let v292_13_head = Path::from_slice(&[v292_13_byte]);
    let v293_2: Space = singleton(&(v292_13_head));
    let v293_3: Space = intersect(&(*CONSTANT_3),&(v293_2));
    let v293_4: Space = if has_head(&(v293_3)) { singleton(&[]) } else { Space::new() };
    drop(v293_3);
    let v293_5: Space = subtract(&(*CONSTANT_2),&(v293_4));
    drop(v293_4);
    let v293_8: Space = if (v293_5).is_empty() { Space::new() } else {
      let v294_6: Path = concat_path(&(*p0),&(v292_13_head));
      let mut v294_7 = Space::new();
      let mut v294_7_cursor = (v292_13_tail).read_zipper();
      for v294_7_byte in v294_7_cursor.child_mask().iter() {
        v294_7_cursor.descend_to_byte(v294_7_byte);
        let v294_7_tail = v294_7_cursor.make_map();
        v294_7_cursor.ascend(1);
        let v294_7_head = Path::from_slice(&[v294_7_byte]);
        let v295_2: Space = singleton(&(v294_7_head));
        let v295_3: Space = intersect(&(*CONSTANT_3),&(v295_2));
        let v295_4: Space = if has_head(&(v295_3)) { singleton(&[]) } else { Space::new() };
        drop(v295_3);
        let v295_5: Space = subtract(&(*CONSTANT_2),&(v295_4));
        drop(v295_4);
        let v295_8: Space = if (v295_5).is_empty() { Space::new() } else {
          let v296_6: Path = concat_path(&(v294_6),&(v294_7_head));
          let v296_7: Space = routine_63(c, &(v296_6), &(*p1), &(v294_7_tail), &(*s1));
          compose(&(v295_5),&(v296_7))
        };
        drop(v295_5);
        let v295_9: Space = intersect(&(*CONSTANT_3),&(v295_2));
        drop(v295_2);
        let v295_10: Space = if has_head(&(v295_9)) { singleton(&[]) } else { Space::new() };
        drop(v295_9);
        let v295_12: Space = if (v295_10).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v294_6),&(v294_7_head));
          let v297_11: Space = routine_64(c, &(v297_6), &(*p1), &(v294_7_tail), &(*s1));
          drop(v297_6);
          compose(&(v295_10),&(v297_11))
        };
        drop(v295_10);
        let v295_13: Space = unite(&(v295_8),&(v295_12));
        v294_7.join_into((v295_13).clone());
      }
      drop(v294_7_cursor);
      compose(&(v293_5),&(v294_7))
    };
    drop(v293_5);
    let v293_9: Space = intersect(&(*CONSTANT_3),&(v293_2));
    drop(v293_2);
    let v293_10: Space = if has_head(&(v293_9)) { singleton(&[]) } else { Space::new() };
    drop(v293_9);
    let v293_12: Space = if (v293_10).is_empty() { Space::new() } else {
      let v298_6: Path = concat_path(&(*p0),&(v292_13_head));
      let mut v298_11 = Space::new();
      let mut v298_11_cursor = (v292_13_tail).read_zipper();
      for v298_11_byte in v298_11_cursor.child_mask().iter() {
        v298_11_cursor.descend_to_byte(v298_11_byte);
        let v298_11_tail = v298_11_cursor.make_map();
        v298_11_cursor.ascend(1);
        let v298_11_head = Path::from_slice(&[v298_11_byte]);
        let v299_2: Space = singleton(&(v298_11_head));
        let v299_3: Space = intersect(&(*CONSTANT_3),&(v299_2));
        let v299_4: Space = if has_head(&(v299_3)) { singleton(&[]) } else { Space::new() };
        drop(v299_3);
        let v299_5: Space = subtract(&(*CONSTANT_2),&(v299_4));
        drop(v299_4);
        let v299_8: Space = if (v299_5).is_empty() { Space::new() } else {
          let v300_6: Path = concat_path(&(v298_6),&(v298_11_head));
          let v300_7: Space = routine_63(c, &(v300_6), &(*p1), &(v298_11_tail), &(*s1));
          compose(&(v299_5),&(v300_7))
        };
        drop(v299_5);
        let v299_9: Space = intersect(&(*CONSTANT_3),&(v299_2));
        drop(v299_2);
        let v299_10: Space = if has_head(&(v299_9)) { singleton(&[]) } else { Space::new() };
        drop(v299_9);
        let v299_12: Space = if (v299_10).is_empty() { Space::new() } else {
          let v301_6: Path = concat_path(&(v298_6),&(v298_11_head));
          let v301_11: Space = routine_29(c, &(v301_6), &(*p1), &(v298_11_tail), &(*s1));
          drop(v301_6);
          compose(&(v299_10),&(v301_11))
        };
        drop(v299_10);
        let v299_13: Space = unite(&(v299_8),&(v299_12));
        v298_11.join_into((v299_13).clone());
      }
      drop(v298_11_cursor);
      drop(v298_6);
      compose(&(v293_10),&(v298_11))
    };
    drop(v293_10);
    let v293_13: Space = unite(&(v293_8),&(v293_12));
    v292_13.join_into((v293_13).clone());
  }
  drop(v292_13_cursor);
  (v292_13).clone()
}

fn routine_28(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v302_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v302_10: Space = unwrap(&(v302_8),&(*CONSTANT_5));
  drop(v302_8);
  let v302_11: Space = unwrap(&(v302_10),&(*p0));
  drop(v302_10);
  let mut v302_18 = Space::new();
  let mut v302_18_cursor = (*s0).read_zipper();
  for v302_18_byte in v302_18_cursor.child_mask().iter() {
    v302_18_cursor.descend_to_byte(v302_18_byte);
    let v302_18_tail = v302_18_cursor.make_map();
    v302_18_cursor.ascend(1);
    let v302_18_head = Path::from_slice(&[v302_18_byte]);
    let v303_2: Space = singleton(&(v302_18_head));
    let v303_3: Space = intersect(&(*CONSTANT_3),&(v303_2));
    let v303_4: Space = if has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
    drop(v303_3);
    let v303_5: Space = subtract(&(*CONSTANT_2),&(v303_4));
    drop(v303_4);
    let v303_8: Space = if (v303_5).is_empty() { Space::new() } else {
      let v304_6: Path = concat_path(&(*p0),&(v302_18_head));
      let mut v304_7 = Space::new();
      let mut v304_7_cursor = (v302_18_tail).read_zipper();
      for v304_7_byte in v304_7_cursor.child_mask().iter() {
        v304_7_cursor.descend_to_byte(v304_7_byte);
        let v304_7_tail = v304_7_cursor.make_map();
        v304_7_cursor.ascend(1);
        let v304_7_head = Path::from_slice(&[v304_7_byte]);
        let v305_2: Space = singleton(&(v304_7_head));
        let v305_3: Space = intersect(&(*CONSTANT_3),&(v305_2));
        let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
        drop(v305_3);
        let v305_5: Space = subtract(&(*CONSTANT_2),&(v305_4));
        drop(v305_4);
        let v305_8: Space = if (v305_5).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v304_6),&(v304_7_head));
          let v306_7: Space = routine_63(c, &(v306_6), &(*p1), &(v304_7_tail), &(*s1));
          compose(&(v305_5),&(v306_7))
        };
        drop(v305_5);
        let v305_9: Space = intersect(&(*CONSTANT_3),&(v305_2));
        drop(v305_2);
        let v305_10: Space = if has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
        drop(v305_9);
        let v305_12: Space = if (v305_10).is_empty() { Space::new() } else {
          let v307_6: Path = concat_path(&(v304_6),&(v304_7_head));
          let v307_11: Space = routine_64(c, &(v307_6), &(*p1), &(v304_7_tail), &(*s1));
          drop(v307_6);
          compose(&(v305_10),&(v307_11))
        };
        drop(v305_10);
        let v305_13: Space = unite(&(v305_8),&(v305_12));
        v304_7.join_into((v305_13).clone());
      }
      drop(v304_7_cursor);
      drop(v304_6);
      compose(&(v303_5),&(v304_7))
    };
    drop(v303_5);
    let v303_9: Space = intersect(&(*CONSTANT_3),&(v303_2));
    drop(v303_2);
    let v303_10: Space = if has_head(&(v303_9)) { singleton(&[]) } else { Space::new() };
    drop(v303_9);
    let v303_13: Space = if (v303_10).is_empty() { Space::new() } else {
      let v308_11: Space = unwrap(&(v302_11),&(v302_18_head));
      let mut v308_12 = Space::new();
      let mut v308_12_cursor = (v308_11).read_zipper();
      for v308_12_byte in v308_12_cursor.child_mask().iter() {
        v308_12_cursor.descend_to_byte(v308_12_byte);
        let v308_12_tail = v308_12_cursor.make_map();
        v308_12_cursor.ascend(1);
        let v308_12_head = Path::from_slice(&[v308_12_byte]);
        let v309_2: Space = singleton(&(v308_12_head));
        let v309_3: Space = intersect(&(*CONSTANT_3),&(v309_2));
        let v309_4: Space = if has_head(&(v309_3)) { singleton(&[]) } else { Space::new() };
        drop(v309_3);
        let v309_5: Space = subtract(&(*CONSTANT_2),&(v309_4));
        drop(v309_4);
        let v309_7: Space = if (v309_5).is_empty() { Space::new() } else {
          let v310_6: Space = routine_61(c, &(v308_12_head), &(*p1), &(v308_12_tail));
          compose(&(v309_5),&(v310_6))
        };
        drop(v309_5);
        let v309_8: Space = intersect(&(*CONSTANT_3),&(v309_2));
        drop(v309_2);
        let v309_9: Space = if has_head(&(v309_8)) { singleton(&[]) } else { Space::new() };
        drop(v309_8);
        let v309_11: Space = if (v309_9).is_empty() { Space::new() } else {
          let v311_10: Space = routine_62(c, &(v308_12_head), &(*p1), &(v308_12_tail));
          compose(&(v309_9),&(v311_10))
        };
        drop(v309_9);
        let v309_12: Space = unite(&(v309_7),&(v309_11));
        v308_12.join_into((v309_12).clone());
      }
      drop(v308_12_cursor);
      drop(v308_11);
      compose(&(v303_10),&(v308_12))
    };
    drop(v303_10);
    let v303_14: Space = unite(&(v303_8),&(v303_13));
    v302_18.join_into((v303_14).clone());
  }
  drop(v302_18_cursor);
  drop(v302_11);
  (v302_18).clone()
}

fn routine_29(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v312_5: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v312_7: Space = unwrap(&(v312_5),&(*CONSTANT_5));
  drop(v312_5);
  let v312_8: Space = unwrap(&(v312_7),&(*p0));
  drop(v312_7);
  let mut v312_18 = Space::new();
  let mut v312_18_cursor = (v312_8).read_zipper();
  for v312_18_byte in v312_18_cursor.child_mask().iter() {
    v312_18_cursor.descend_to_byte(v312_18_byte);
    let v312_18_tail = v312_18_cursor.make_map();
    v312_18_cursor.ascend(1);
    let v312_18_head = Path::from_slice(&[v312_18_byte]);
    let v313_2: Space = singleton(&(v312_18_head));
    let v313_3: Space = intersect(&(*CONSTANT_3),&(v313_2));
    let v313_4: Space = if has_head(&(v313_3)) { singleton(&[]) } else { Space::new() };
    drop(v313_3);
    let v313_5: Space = subtract(&(*CONSTANT_2),&(v313_4));
    drop(v313_4);
    let v313_7: Space = if (v313_5).is_empty() { Space::new() } else {
      let mut v314_6 = Space::new();
      let mut v314_6_cursor = (v312_18_tail).read_zipper();
      for v314_6_byte in v314_6_cursor.child_mask().iter() {
        v314_6_cursor.descend_to_byte(v314_6_byte);
        let v314_6_tail = v314_6_cursor.make_map();
        v314_6_cursor.ascend(1);
        let v314_6_head = Path::from_slice(&[v314_6_byte]);
        let v315_2: Space = singleton(&(v314_6_head));
        let v315_3: Space = intersect(&(*CONSTANT_3),&(v315_2));
        let v315_4: Space = if has_head(&(v315_3)) { singleton(&[]) } else { Space::new() };
        drop(v315_3);
        let v315_5: Space = subtract(&(*CONSTANT_2),&(v315_4));
        drop(v315_4);
        let v315_8: Space = if (v315_5).is_empty() { Space::new() } else {
          let v316_6: Path = concat_path(&(v312_18_head),&(v314_6_head));
          let v316_7: Space = routine_65(c, &(v316_6), &(*p1), &(v314_6_tail));
          compose(&(v315_5),&(v316_7))
        };
        drop(v315_5);
        let v315_9: Space = intersect(&(*CONSTANT_3),&(v315_2));
        drop(v315_2);
        let v315_10: Space = if has_head(&(v315_9)) { singleton(&[]) } else { Space::new() };
        drop(v315_9);
        let v315_12: Space = if (v315_10).is_empty() { Space::new() } else {
          let v317_6: Path = concat_path(&(v312_18_head),&(v314_6_head));
          let v317_11: Space = routine_66(c, &(v317_6), &(*p1), &(v314_6_tail));
          drop(v317_6);
          compose(&(v315_10),&(v317_11))
        };
        drop(v315_10);
        let v315_13: Space = unite(&(v315_8),&(v315_12));
        v314_6.join_into((v315_13).clone());
      }
      drop(v314_6_cursor);
      compose(&(v313_5),&(v314_6))
    };
    drop(v313_5);
    let v313_8: Space = intersect(&(*CONSTANT_3),&(v313_2));
    drop(v313_2);
    let v313_9: Space = if has_head(&(v313_8)) { singleton(&[]) } else { Space::new() };
    drop(v313_8);
    let v313_11: Space = if (v313_9).is_empty() { Space::new() } else {
      let mut v318_10 = Space::new();
      let mut v318_10_cursor = (v312_18_tail).read_zipper();
      for v318_10_byte in v318_10_cursor.child_mask().iter() {
        v318_10_cursor.descend_to_byte(v318_10_byte);
        let v318_10_tail = v318_10_cursor.make_map();
        v318_10_cursor.ascend(1);
        let v318_10_head = Path::from_slice(&[v318_10_byte]);
        let v319_2: Space = singleton(&(v318_10_head));
        let v319_3: Space = intersect(&(*CONSTANT_3),&(v319_2));
        let v319_4: Space = if has_head(&(v319_3)) { singleton(&[]) } else { Space::new() };
        drop(v319_3);
        let v319_5: Space = subtract(&(*CONSTANT_2),&(v319_4));
        drop(v319_4);
        let v319_8: Space = if (v319_5).is_empty() { Space::new() } else {
          let v320_6: Path = concat_path(&(v312_18_head),&(v318_10_head));
          let v320_7: Space = routine_65(c, &(v320_6), &(*p1), &(v318_10_tail));
          compose(&(v319_5),&(v320_7))
        };
        drop(v319_5);
        let v319_9: Space = intersect(&(*CONSTANT_3),&(v319_2));
        drop(v319_2);
        let v319_10: Space = if has_head(&(v319_9)) { singleton(&[]) } else { Space::new() };
        drop(v319_9);
        let v319_12: Space = if (v319_10).is_empty() { Space::new() } else {
          let v321_6: Path = concat_path(&(v312_18_head),&(v318_10_head));
          let v321_11: Space = routine_67(c, &(v321_6), &(*p1), &(v318_10_tail));
          drop(v321_6);
          compose(&(v319_10),&(v321_11))
        };
        drop(v319_10);
        let v319_13: Space = unite(&(v319_8),&(v319_12));
        v318_10.join_into((v319_13).clone());
      }
      drop(v318_10_cursor);
      compose(&(v313_9),&(v318_10))
    };
    drop(v313_9);
    let v313_12: Space = unite(&(v313_7),&(v313_11));
    v312_18.join_into((v313_12).clone());
  }
  drop(v312_18_cursor);
  drop(v312_8);
  (v312_18).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v322_11 = Space::new();
  let mut v322_11_cursor = (*s0).read_zipper();
  for v322_11_byte in v322_11_cursor.child_mask().iter() {
    v322_11_cursor.descend_to_byte(v322_11_byte);
    let v322_11_tail = v322_11_cursor.make_map();
    v322_11_cursor.ascend(1);
    let v322_11_head = Path::from_slice(&[v322_11_byte]);
    let v323_2: Space = singleton(&(v322_11_head));
    let v323_3: Space = intersect(&(*CONSTANT_3),&(v323_2));
    let v323_4: Space = if has_head(&(v323_3)) { singleton(&[]) } else { Space::new() };
    drop(v323_3);
    let v323_5: Space = subtract(&(*CONSTANT_2),&(v323_4));
    drop(v323_4);
    let v323_8: Space = if (v323_5).is_empty() { Space::new() } else {
      let v324_6: Path = concat_path(&(*p0),&(v322_11_head));
      let mut v324_7 = Space::new();
      let mut v324_7_cursor = (v322_11_tail).read_zipper();
      for v324_7_byte in v324_7_cursor.child_mask().iter() {
        v324_7_cursor.descend_to_byte(v324_7_byte);
        let v324_7_tail = v324_7_cursor.make_map();
        v324_7_cursor.ascend(1);
        let v324_7_head = Path::from_slice(&[v324_7_byte]);
        let v325_2: Space = singleton(&(v324_7_head));
        let v325_3: Space = intersect(&(*CONSTANT_3),&(v325_2));
        let v325_4: Space = if has_head(&(v325_3)) { singleton(&[]) } else { Space::new() };
        drop(v325_3);
        let v325_5: Space = subtract(&(*CONSTANT_2),&(v325_4));
        drop(v325_4);
        let v325_8: Space = if (v325_5).is_empty() { Space::new() } else {
          let v326_6: Path = concat_path(&(v324_6),&(v324_7_head));
          let v326_7: Space = routine_68(c, &(v326_6), &(v324_7_tail));
          compose(&(v325_5),&(v326_7))
        };
        drop(v325_5);
        let v325_9: Space = intersect(&(*CONSTANT_3),&(v325_2));
        drop(v325_2);
        let v325_10: Space = if has_head(&(v325_9)) { singleton(&[]) } else { Space::new() };
        drop(v325_9);
        let v325_12: Space = if (v325_10).is_empty() { Space::new() } else {
          let v327_6: Path = concat_path(&(v324_6),&(v324_7_head));
          let v327_11: Space = routine_69(c, &(v327_6), &(v324_7_tail));
          drop(v327_6);
          compose(&(v325_10),&(v327_11))
        };
        drop(v325_10);
        let v325_13: Space = unite(&(v325_8),&(v325_12));
        v324_7.join_into((v325_13).clone());
      }
      drop(v324_7_cursor);
      compose(&(v323_5),&(v324_7))
    };
    drop(v323_5);
    let v323_9: Space = intersect(&(*CONSTANT_3),&(v323_2));
    drop(v323_2);
    let v323_10: Space = if has_head(&(v323_9)) { singleton(&[]) } else { Space::new() };
    drop(v323_9);
    let v323_12: Space = if (v323_10).is_empty() { Space::new() } else {
      let v328_6: Path = concat_path(&(*p0),&(v322_11_head));
      let mut v328_11 = Space::new();
      let mut v328_11_cursor = (v322_11_tail).read_zipper();
      for v328_11_byte in v328_11_cursor.child_mask().iter() {
        v328_11_cursor.descend_to_byte(v328_11_byte);
        let v328_11_tail = v328_11_cursor.make_map();
        v328_11_cursor.ascend(1);
        let v328_11_head = Path::from_slice(&[v328_11_byte]);
        let v329_2: Space = singleton(&(v328_11_head));
        let v329_3: Space = intersect(&(*CONSTANT_3),&(v329_2));
        let v329_4: Space = if has_head(&(v329_3)) { singleton(&[]) } else { Space::new() };
        drop(v329_3);
        let v329_5: Space = subtract(&(*CONSTANT_2),&(v329_4));
        drop(v329_4);
        let v329_8: Space = if (v329_5).is_empty() { Space::new() } else {
          let v330_6: Path = concat_path(&(v328_6),&(v328_11_head));
          let v330_7: Space = routine_68(c, &(v330_6), &(v328_11_tail));
          compose(&(v329_5),&(v330_7))
        };
        drop(v329_5);
        let v329_9: Space = intersect(&(*CONSTANT_3),&(v329_2));
        drop(v329_2);
        let v329_10: Space = if has_head(&(v329_9)) { singleton(&[]) } else { Space::new() };
        drop(v329_9);
        let v329_12: Space = if (v329_10).is_empty() { Space::new() } else {
          let v331_6: Path = concat_path(&(v328_6),&(v328_11_head));
          let v331_11: Space = routine_9(c, &(v331_6), &(v328_11_tail));
          drop(v331_6);
          compose(&(v329_10),&(v331_11))
        };
        drop(v329_10);
        let v329_13: Space = unite(&(v329_8),&(v329_12));
        v328_11.join_into((v329_13).clone());
      }
      drop(v328_11_cursor);
      drop(v328_6);
      compose(&(v323_10),&(v328_11))
    };
    drop(v323_10);
    let v323_13: Space = unite(&(v323_8),&(v323_12));
    v322_11.join_into((v323_13).clone());
  }
  drop(v322_11_cursor);
  (v322_11).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v332_11 = Space::new();
  let mut v332_11_cursor = (*s0).read_zipper();
  for v332_11_byte in v332_11_cursor.child_mask().iter() {
    v332_11_cursor.descend_to_byte(v332_11_byte);
    let v332_11_tail = v332_11_cursor.make_map();
    v332_11_cursor.ascend(1);
    let v332_11_head = Path::from_slice(&[v332_11_byte]);
    let v333_2: Space = singleton(&(v332_11_head));
    let v333_3: Space = intersect(&(*CONSTANT_3),&(v333_2));
    let v333_4: Space = if has_head(&(v333_3)) { singleton(&[]) } else { Space::new() };
    drop(v333_3);
    let v333_5: Space = subtract(&(*CONSTANT_2),&(v333_4));
    drop(v333_4);
    let v333_8: Space = if (v333_5).is_empty() { Space::new() } else {
      let v334_6: Path = concat_path(&(*p0),&(v332_11_head));
      let mut v334_7 = Space::new();
      let mut v334_7_cursor = (v332_11_tail).read_zipper();
      for v334_7_byte in v334_7_cursor.child_mask().iter() {
        v334_7_cursor.descend_to_byte(v334_7_byte);
        let v334_7_tail = v334_7_cursor.make_map();
        v334_7_cursor.ascend(1);
        let v334_7_head = Path::from_slice(&[v334_7_byte]);
        let v335_2: Space = singleton(&(v334_7_head));
        let v335_3: Space = intersect(&(*CONSTANT_3),&(v335_2));
        let v335_4: Space = if has_head(&(v335_3)) { singleton(&[]) } else { Space::new() };
        drop(v335_3);
        let v335_5: Space = subtract(&(*CONSTANT_2),&(v335_4));
        drop(v335_4);
        let v335_8: Space = if (v335_5).is_empty() { Space::new() } else {
          let v336_6: Path = concat_path(&(v334_6),&(v334_7_head));
          let v336_7: Space = routine_68(c, &(v336_6), &(v334_7_tail));
          compose(&(v335_5),&(v336_7))
        };
        drop(v335_5);
        let v335_9: Space = intersect(&(*CONSTANT_3),&(v335_2));
        drop(v335_2);
        let v335_10: Space = if has_head(&(v335_9)) { singleton(&[]) } else { Space::new() };
        drop(v335_9);
        let v335_12: Space = if (v335_10).is_empty() { Space::new() } else {
          let v337_6: Path = concat_path(&(v334_6),&(v334_7_head));
          let v337_11: Space = routine_69(c, &(v337_6), &(v334_7_tail));
          drop(v337_6);
          compose(&(v335_10),&(v337_11))
        };
        drop(v335_10);
        let v335_13: Space = unite(&(v335_8),&(v335_12));
        v334_7.join_into((v335_13).clone());
      }
      drop(v334_7_cursor);
      compose(&(v333_5),&(v334_7))
    };
    drop(v333_5);
    let v333_9: Space = intersect(&(*CONSTANT_3),&(v333_2));
    drop(v333_2);
    let v333_10: Space = if has_head(&(v333_9)) { singleton(&[]) } else { Space::new() };
    drop(v333_9);
    let v333_12: Space = if (v333_10).is_empty() { Space::new() } else {
      let v338_6: Path = concat_path(&(*p0),&(v332_11_head));
      let mut v338_11 = Space::new();
      let mut v338_11_cursor = (v332_11_tail).read_zipper();
      for v338_11_byte in v338_11_cursor.child_mask().iter() {
        v338_11_cursor.descend_to_byte(v338_11_byte);
        let v338_11_tail = v338_11_cursor.make_map();
        v338_11_cursor.ascend(1);
        let v338_11_head = Path::from_slice(&[v338_11_byte]);
        let v339_2: Space = singleton(&(v338_11_head));
        let v339_3: Space = intersect(&(*CONSTANT_3),&(v339_2));
        let v339_4: Space = if has_head(&(v339_3)) { singleton(&[]) } else { Space::new() };
        drop(v339_3);
        let v339_5: Space = subtract(&(*CONSTANT_2),&(v339_4));
        drop(v339_4);
        let v339_7: Space = if (v339_5).is_empty() { Space::new() } else {
          let v340_6: Space = routine_32(c, &(v338_11_head), &(v338_6), &(v338_11_tail));
          compose(&(v339_5),&(v340_6))
        };
        drop(v339_5);
        let v339_8: Space = intersect(&(*CONSTANT_3),&(v339_2));
        drop(v339_2);
        let v339_9: Space = if has_head(&(v339_8)) { singleton(&[]) } else { Space::new() };
        drop(v339_8);
        let v339_11: Space = if (v339_9).is_empty() { Space::new() } else {
          let v341_10: Space = routine_33(c, &(v338_11_head), &(v338_6), &(v338_11_tail));
          compose(&(v339_9),&(v341_10))
        };
        drop(v339_9);
        let v339_12: Space = unite(&(v339_7),&(v339_11));
        v338_11.join_into((v339_12).clone());
      }
      drop(v338_11_cursor);
      drop(v338_6);
      compose(&(v333_10),&(v338_11))
    };
    drop(v333_10);
    let v333_13: Space = unite(&(v333_8),&(v333_12));
    v332_11.join_into((v333_13).clone());
  }
  drop(v332_11_cursor);
  (v332_11).clone()
}

fn routine_32(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v342_12 = Space::new();
  let mut v342_12_cursor = (*s0).read_zipper();
  for v342_12_byte in v342_12_cursor.child_mask().iter() {
    v342_12_cursor.descend_to_byte(v342_12_byte);
    let v342_12_tail = v342_12_cursor.make_map();
    v342_12_cursor.ascend(1);
    let v342_12_head = Path::from_slice(&[v342_12_byte]);
    let v343_2: Space = singleton(&(v342_12_head));
    let v343_3: Space = intersect(&(*CONSTANT_3),&(v343_2));
    let v343_4: Space = if has_head(&(v343_3)) { singleton(&[]) } else { Space::new() };
    drop(v343_3);
    let v343_5: Space = subtract(&(*CONSTANT_2),&(v343_4));
    drop(v343_4);
    let v343_8: Space = if (v343_5).is_empty() { Space::new() } else {
      let v344_6: Path = concat_path(&(*p0),&(v342_12_head));
      let mut v344_7 = Space::new();
      let mut v344_7_cursor = (v342_12_tail).read_zipper();
      for v344_7_byte in v344_7_cursor.child_mask().iter() {
        v344_7_cursor.descend_to_byte(v344_7_byte);
        let v344_7_tail = v344_7_cursor.make_map();
        v344_7_cursor.ascend(1);
        let v344_7_head = Path::from_slice(&[v344_7_byte]);
        let v345_2: Space = singleton(&(v344_7_head));
        let v345_3: Space = intersect(&(*CONSTANT_3),&(v345_2));
        let v345_4: Space = if has_head(&(v345_3)) { singleton(&[]) } else { Space::new() };
        drop(v345_3);
        let v345_5: Space = subtract(&(*CONSTANT_2),&(v345_4));
        drop(v345_4);
        let v345_8: Space = if (v345_5).is_empty() { Space::new() } else {
          let v346_6: Path = concat_path(&(v344_6),&(v344_7_head));
          let v346_7: Space = routine_70(c, &(v346_6), &(*p1), &(v344_7_tail));
          compose(&(v345_5),&(v346_7))
        };
        drop(v345_5);
        let v345_9: Space = intersect(&(*CONSTANT_3),&(v345_2));
        drop(v345_2);
        let v345_10: Space = if has_head(&(v345_9)) { singleton(&[]) } else { Space::new() };
        drop(v345_9);
        let v345_12: Space = if (v345_10).is_empty() { Space::new() } else {
          let v347_6: Path = concat_path(&(v344_6),&(v344_7_head));
          let v347_11: Space = routine_71(c, &(v347_6), &(*p1), &(v344_7_tail));
          drop(v347_6);
          compose(&(v345_10),&(v347_11))
        };
        drop(v345_10);
        let v345_13: Space = unite(&(v345_8),&(v345_12));
        v344_7.join_into((v345_13).clone());
      }
      drop(v344_7_cursor);
      compose(&(v343_5),&(v344_7))
    };
    drop(v343_5);
    let v343_9: Space = intersect(&(*CONSTANT_3),&(v343_2));
    drop(v343_2);
    let v343_10: Space = if has_head(&(v343_9)) { singleton(&[]) } else { Space::new() };
    drop(v343_9);
    let v343_12: Space = if (v343_10).is_empty() { Space::new() } else {
      let v348_6: Path = concat_path(&(*p0),&(v342_12_head));
      let mut v348_11 = Space::new();
      let mut v348_11_cursor = (v342_12_tail).read_zipper();
      for v348_11_byte in v348_11_cursor.child_mask().iter() {
        v348_11_cursor.descend_to_byte(v348_11_byte);
        let v348_11_tail = v348_11_cursor.make_map();
        v348_11_cursor.ascend(1);
        let v348_11_head = Path::from_slice(&[v348_11_byte]);
        let v349_2: Space = singleton(&(v348_11_head));
        let v349_3: Space = intersect(&(*CONSTANT_3),&(v349_2));
        let v349_4: Space = if has_head(&(v349_3)) { singleton(&[]) } else { Space::new() };
        drop(v349_3);
        let v349_5: Space = subtract(&(*CONSTANT_2),&(v349_4));
        drop(v349_4);
        let v349_8: Space = if (v349_5).is_empty() { Space::new() } else {
          let v350_6: Path = concat_path(&(v348_6),&(v348_11_head));
          let v350_7: Space = routine_70(c, &(v350_6), &(*p1), &(v348_11_tail));
          compose(&(v349_5),&(v350_7))
        };
        drop(v349_5);
        let v349_9: Space = intersect(&(*CONSTANT_3),&(v349_2));
        drop(v349_2);
        let v349_10: Space = if has_head(&(v349_9)) { singleton(&[]) } else { Space::new() };
        drop(v349_9);
        let v349_12: Space = if (v349_10).is_empty() { Space::new() } else {
          let v351_6: Path = concat_path(&(v348_6),&(v348_11_head));
          let v351_11: Space = routine_36(c, &(v351_6), &(*p1), &(v348_11_tail));
          drop(v351_6);
          compose(&(v349_10),&(v351_11))
        };
        drop(v349_10);
        let v349_13: Space = unite(&(v349_8),&(v349_12));
        v348_11.join_into((v349_13).clone());
      }
      drop(v348_11_cursor);
      drop(v348_6);
      compose(&(v343_10),&(v348_11))
    };
    drop(v343_10);
    let v343_13: Space = unite(&(v343_8),&(v343_12));
    v342_12.join_into((v343_13).clone());
  }
  drop(v342_12_cursor);
  (v342_12).clone()
}

fn routine_33(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v352_9 = Space::new();
  let mut v352_9_cursor = (*s0).read_zipper();
  for v352_9_byte in v352_9_cursor.child_mask().iter() {
    v352_9_cursor.descend_to_byte(v352_9_byte);
    let v352_9_tail = v352_9_cursor.make_map();
    v352_9_cursor.ascend(1);
    let v352_9_head = Path::from_slice(&[v352_9_byte]);
    let v353_2: Space = singleton(&(v352_9_head));
    let v353_3: Space = intersect(&(*CONSTANT_3),&(v353_2));
    let v353_4: Space = if has_head(&(v353_3)) { singleton(&[]) } else { Space::new() };
    drop(v353_3);
    let v353_5: Space = subtract(&(*CONSTANT_2),&(v353_4));
    drop(v353_4);
    let v353_8: Space = if (v353_5).is_empty() { Space::new() } else {
      let v354_6: Path = concat_path(&(*p0),&(v352_9_head));
      let mut v354_7 = Space::new();
      let mut v354_7_cursor = (v352_9_tail).read_zipper();
      for v354_7_byte in v354_7_cursor.child_mask().iter() {
        v354_7_cursor.descend_to_byte(v354_7_byte);
        let v354_7_tail = v354_7_cursor.make_map();
        v354_7_cursor.ascend(1);
        let v354_7_head = Path::from_slice(&[v354_7_byte]);
        let v355_2: Space = singleton(&(v354_7_head));
        let v355_3: Space = intersect(&(*CONSTANT_3),&(v355_2));
        let v355_4: Space = if has_head(&(v355_3)) { singleton(&[]) } else { Space::new() };
        drop(v355_3);
        let v355_5: Space = subtract(&(*CONSTANT_2),&(v355_4));
        drop(v355_4);
        let v355_8: Space = if (v355_5).is_empty() { Space::new() } else {
          let v356_6: Path = concat_path(&(v354_6),&(v354_7_head));
          let v356_7: Space = routine_70(c, &(v356_6), &(*p1), &(v354_7_tail));
          compose(&(v355_5),&(v356_7))
        };
        drop(v355_5);
        let v355_9: Space = intersect(&(*CONSTANT_3),&(v355_2));
        drop(v355_2);
        let v355_10: Space = if has_head(&(v355_9)) { singleton(&[]) } else { Space::new() };
        drop(v355_9);
        let v355_12: Space = if (v355_10).is_empty() { Space::new() } else {
          let v357_6: Path = concat_path(&(v354_6),&(v354_7_head));
          let v357_11: Space = routine_71(c, &(v357_6), &(*p1), &(v354_7_tail));
          drop(v357_6);
          compose(&(v355_10),&(v357_11))
        };
        drop(v355_10);
        let v355_13: Space = unite(&(v355_8),&(v355_12));
        v354_7.join_into((v355_13).clone());
      }
      drop(v354_7_cursor);
      compose(&(v353_5),&(v354_7))
    };
    drop(v353_5);
    let v353_9: Space = intersect(&(*CONSTANT_3),&(v353_2));
    drop(v353_2);
    let v353_10: Space = if has_head(&(v353_9)) { singleton(&[]) } else { Space::new() };
    drop(v353_9);
    let v353_11: Space = compose(&(v353_10),&(v352_9_tail));
    drop(v353_10);
    let v358_6: Path = concat_path(&(*p0),&(v352_9_head));
    let v353_12: Space = wrap(&(v353_11),&(v358_6));
    drop(v353_11);
    let v353_13: Space = wrap(&(v353_12),&(*p1));
    drop(v353_12);
    let v353_14: Space = unite(&(v353_8),&(v353_13));
    drop(v353_13);
    v352_9.join_into((v353_14).clone());
  }
  drop(v352_9_cursor);
  (v352_9).clone()
}

fn routine_34(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v359_12 = Space::new();
  let mut v359_12_cursor = (*s0).read_zipper();
  for v359_12_byte in v359_12_cursor.child_mask().iter() {
    v359_12_cursor.descend_to_byte(v359_12_byte);
    let v359_12_tail = v359_12_cursor.make_map();
    v359_12_cursor.ascend(1);
    let v359_12_head = Path::from_slice(&[v359_12_byte]);
    let v360_2: Space = singleton(&(v359_12_head));
    let v360_3: Space = intersect(&(*CONSTANT_3),&(v360_2));
    let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
    drop(v360_3);
    let v360_5: Space = subtract(&(*CONSTANT_2),&(v360_4));
    drop(v360_4);
    let v360_8: Space = if (v360_5).is_empty() { Space::new() } else {
      let v361_6: Path = concat_path(&(*p0),&(v359_12_head));
      let mut v361_7 = Space::new();
      let mut v361_7_cursor = (v359_12_tail).read_zipper();
      for v361_7_byte in v361_7_cursor.child_mask().iter() {
        v361_7_cursor.descend_to_byte(v361_7_byte);
        let v361_7_tail = v361_7_cursor.make_map();
        v361_7_cursor.ascend(1);
        let v361_7_head = Path::from_slice(&[v361_7_byte]);
        let v362_2: Space = singleton(&(v361_7_head));
        let v362_3: Space = intersect(&(*CONSTANT_3),&(v362_2));
        let v362_4: Space = if has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
        drop(v362_3);
        let v362_5: Space = subtract(&(*CONSTANT_2),&(v362_4));
        drop(v362_4);
        let v362_8: Space = if (v362_5).is_empty() { Space::new() } else {
          let v363_6: Path = concat_path(&(v361_6),&(v361_7_head));
          let v363_7: Space = routine_72(c, &(v363_6), &(*p1), &(v361_7_tail));
          compose(&(v362_5),&(v363_7))
        };
        drop(v362_5);
        let v362_9: Space = intersect(&(*CONSTANT_3),&(v362_2));
        drop(v362_2);
        let v362_10: Space = if has_head(&(v362_9)) { singleton(&[]) } else { Space::new() };
        drop(v362_9);
        let v362_12: Space = if (v362_10).is_empty() { Space::new() } else {
          let v364_6: Path = concat_path(&(v361_6),&(v361_7_head));
          let v364_11: Space = routine_73(c, &(v364_6), &(*p1), &(v361_7_tail));
          drop(v364_6);
          compose(&(v362_10),&(v364_11))
        };
        drop(v362_10);
        let v362_13: Space = unite(&(v362_8),&(v362_12));
        v361_7.join_into((v362_13).clone());
      }
      drop(v361_7_cursor);
      compose(&(v360_5),&(v361_7))
    };
    drop(v360_5);
    let v360_9: Space = intersect(&(*CONSTANT_3),&(v360_2));
    drop(v360_2);
    let v360_10: Space = if has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
    drop(v360_9);
    let v360_12: Space = if (v360_10).is_empty() { Space::new() } else {
      let v365_6: Path = concat_path(&(*p0),&(v359_12_head));
      let mut v365_11 = Space::new();
      let mut v365_11_cursor = (v359_12_tail).read_zipper();
      for v365_11_byte in v365_11_cursor.child_mask().iter() {
        v365_11_cursor.descend_to_byte(v365_11_byte);
        let v365_11_tail = v365_11_cursor.make_map();
        v365_11_cursor.ascend(1);
        let v365_11_head = Path::from_slice(&[v365_11_byte]);
        let v366_2: Space = singleton(&(v365_11_head));
        let v366_3: Space = intersect(&(*CONSTANT_3),&(v366_2));
        let v366_4: Space = if has_head(&(v366_3)) { singleton(&[]) } else { Space::new() };
        drop(v366_3);
        let v366_5: Space = subtract(&(*CONSTANT_2),&(v366_4));
        drop(v366_4);
        let v366_8: Space = if (v366_5).is_empty() { Space::new() } else {
          let v367_6: Path = concat_path(&(v365_6),&(v365_11_head));
          let v367_7: Space = routine_72(c, &(v367_6), &(*p1), &(v365_11_tail));
          compose(&(v366_5),&(v367_7))
        };
        drop(v366_5);
        let v366_9: Space = intersect(&(*CONSTANT_3),&(v366_2));
        drop(v366_2);
        let v366_10: Space = if has_head(&(v366_9)) { singleton(&[]) } else { Space::new() };
        drop(v366_9);
        let v366_12: Space = if (v366_10).is_empty() { Space::new() } else {
          let v368_6: Path = concat_path(&(v365_6),&(v365_11_head));
          let v368_11: Space = routine_36(c, &(v368_6), &(*p1), &(v365_11_tail));
          drop(v368_6);
          compose(&(v366_10),&(v368_11))
        };
        drop(v366_10);
        let v366_13: Space = unite(&(v366_8),&(v366_12));
        v365_11.join_into((v366_13).clone());
      }
      drop(v365_11_cursor);
      drop(v365_6);
      compose(&(v360_10),&(v365_11))
    };
    drop(v360_10);
    let v360_13: Space = unite(&(v360_8),&(v360_12));
    v359_12.join_into((v360_13).clone());
  }
  drop(v359_12_cursor);
  (v359_12).clone()
}

fn routine_35(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v369_9 = Space::new();
  let mut v369_9_cursor = (*s0).read_zipper();
  for v369_9_byte in v369_9_cursor.child_mask().iter() {
    v369_9_cursor.descend_to_byte(v369_9_byte);
    let v369_9_tail = v369_9_cursor.make_map();
    v369_9_cursor.ascend(1);
    let v369_9_head = Path::from_slice(&[v369_9_byte]);
    let v370_2: Space = singleton(&(v369_9_head));
    let v370_3: Space = intersect(&(*CONSTANT_3),&(v370_2));
    let v370_4: Space = if has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
    drop(v370_3);
    let v370_5: Space = subtract(&(*CONSTANT_2),&(v370_4));
    drop(v370_4);
    let v370_8: Space = if (v370_5).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&(v369_9_head));
      let mut v371_7 = Space::new();
      let mut v371_7_cursor = (v369_9_tail).read_zipper();
      for v371_7_byte in v371_7_cursor.child_mask().iter() {
        v371_7_cursor.descend_to_byte(v371_7_byte);
        let v371_7_tail = v371_7_cursor.make_map();
        v371_7_cursor.ascend(1);
        let v371_7_head = Path::from_slice(&[v371_7_byte]);
        let v372_2: Space = singleton(&(v371_7_head));
        let v372_3: Space = intersect(&(*CONSTANT_3),&(v372_2));
        let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
        drop(v372_3);
        let v372_5: Space = subtract(&(*CONSTANT_2),&(v372_4));
        drop(v372_4);
        let v372_8: Space = if (v372_5).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v371_6),&(v371_7_head));
          let v373_7: Space = routine_72(c, &(v373_6), &(*p1), &(v371_7_tail));
          compose(&(v372_5),&(v373_7))
        };
        drop(v372_5);
        let v372_9: Space = intersect(&(*CONSTANT_3),&(v372_2));
        drop(v372_2);
        let v372_10: Space = if has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
        drop(v372_9);
        let v372_12: Space = if (v372_10).is_empty() { Space::new() } else {
          let v374_6: Path = concat_path(&(v371_6),&(v371_7_head));
          let v374_11: Space = routine_73(c, &(v374_6), &(*p1), &(v371_7_tail));
          drop(v374_6);
          compose(&(v372_10),&(v374_11))
        };
        drop(v372_10);
        let v372_13: Space = unite(&(v372_8),&(v372_12));
        v371_7.join_into((v372_13).clone());
      }
      drop(v371_7_cursor);
      compose(&(v370_5),&(v371_7))
    };
    drop(v370_5);
    let v370_9: Space = intersect(&(*CONSTANT_3),&(v370_2));
    drop(v370_2);
    let v370_10: Space = if has_head(&(v370_9)) { singleton(&[]) } else { Space::new() };
    drop(v370_9);
    let v370_11: Space = compose(&(v370_10),&(v369_9_tail));
    drop(v370_10);
    let v375_6: Path = concat_path(&(*p0),&(v369_9_head));
    let v370_12: Space = wrap(&(v370_11),&(v375_6));
    drop(v370_11);
    let v370_13: Space = wrap(&(v370_12),&(*p1));
    drop(v370_12);
    let v370_14: Space = unite(&(v370_8),&(v370_13));
    drop(v370_13);
    v369_9.join_into((v370_14).clone());
  }
  drop(v369_9_cursor);
  (v369_9).clone()
}

fn routine_36(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v376_3: Space = wrap(&(*s0),&(*p0));
  let v376_4: Space = wrap(&(v376_3),&(*p1));
  drop(v376_3);
  (v376_4).clone()
}

fn routine_37(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v377_12 = Space::new();
  let mut v377_12_cursor = (*s0).read_zipper();
  for v377_12_byte in v377_12_cursor.child_mask().iter() {
    v377_12_cursor.descend_to_byte(v377_12_byte);
    let v377_12_tail = v377_12_cursor.make_map();
    v377_12_cursor.ascend(1);
    let v377_12_head = Path::from_slice(&[v377_12_byte]);
    let v378_2: Space = singleton(&(v377_12_head));
    let v378_3: Space = intersect(&(*CONSTANT_3),&(v378_2));
    let v378_4: Space = if has_head(&(v378_3)) { singleton(&[]) } else { Space::new() };
    drop(v378_3);
    let v378_5: Space = subtract(&(*CONSTANT_2),&(v378_4));
    drop(v378_4);
    let v378_8: Space = if (v378_5).is_empty() { Space::new() } else {
      let v379_6: Path = concat_path(&(*p0),&(v377_12_head));
      let mut v379_7 = Space::new();
      let mut v379_7_cursor = (v377_12_tail).read_zipper();
      for v379_7_byte in v379_7_cursor.child_mask().iter() {
        v379_7_cursor.descend_to_byte(v379_7_byte);
        let v379_7_tail = v379_7_cursor.make_map();
        v379_7_cursor.ascend(1);
        let v379_7_head = Path::from_slice(&[v379_7_byte]);
        let v380_2: Space = singleton(&(v379_7_head));
        let v380_3: Space = intersect(&(*CONSTANT_3),&(v380_2));
        let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
        drop(v380_3);
        let v380_5: Space = subtract(&(*CONSTANT_2),&(v380_4));
        drop(v380_4);
        let v380_8: Space = if (v380_5).is_empty() { Space::new() } else {
          let v381_6: Path = concat_path(&(v379_6),&(v379_7_head));
          let v381_7: Space = routine_74(c, &(v381_6), &(v379_7_tail), &(*s1));
          compose(&(v380_5),&(v381_7))
        };
        drop(v380_5);
        let v380_9: Space = intersect(&(*CONSTANT_3),&(v380_2));
        drop(v380_2);
        let v380_10: Space = if has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
        drop(v380_9);
        let v380_12: Space = if (v380_10).is_empty() { Space::new() } else {
          let v382_6: Path = concat_path(&(v379_6),&(v379_7_head));
          let v382_11: Space = routine_75(c, &(v382_6), &(v379_7_tail), &(*s1));
          drop(v382_6);
          compose(&(v380_10),&(v382_11))
        };
        drop(v380_10);
        let v380_13: Space = unite(&(v380_8),&(v380_12));
        v379_7.join_into((v380_13).clone());
      }
      drop(v379_7_cursor);
      compose(&(v378_5),&(v379_7))
    };
    drop(v378_5);
    let v378_9: Space = intersect(&(*CONSTANT_3),&(v378_2));
    drop(v378_2);
    let v378_10: Space = if has_head(&(v378_9)) { singleton(&[]) } else { Space::new() };
    drop(v378_9);
    let v378_12: Space = if (v378_10).is_empty() { Space::new() } else {
      let v383_6: Path = concat_path(&(*p0),&(v377_12_head));
      let mut v383_11 = Space::new();
      let mut v383_11_cursor = (v377_12_tail).read_zipper();
      for v383_11_byte in v383_11_cursor.child_mask().iter() {
        v383_11_cursor.descend_to_byte(v383_11_byte);
        let v383_11_tail = v383_11_cursor.make_map();
        v383_11_cursor.ascend(1);
        let v383_11_head = Path::from_slice(&[v383_11_byte]);
        let v384_2: Space = singleton(&(v383_11_head));
        let v384_3: Space = intersect(&(*CONSTANT_3),&(v384_2));
        let v384_4: Space = if has_head(&(v384_3)) { singleton(&[]) } else { Space::new() };
        drop(v384_3);
        let v384_5: Space = subtract(&(*CONSTANT_2),&(v384_4));
        drop(v384_4);
        let v384_8: Space = if (v384_5).is_empty() { Space::new() } else {
          let v385_6: Path = concat_path(&(v383_6),&(v383_11_head));
          let v385_7: Space = routine_74(c, &(v385_6), &(v383_11_tail), &(*s1));
          compose(&(v384_5),&(v385_7))
        };
        drop(v384_5);
        let v384_9: Space = intersect(&(*CONSTANT_3),&(v384_2));
        drop(v384_2);
        let v384_10: Space = if has_head(&(v384_9)) { singleton(&[]) } else { Space::new() };
        drop(v384_9);
        let v384_12: Space = if (v384_10).is_empty() { Space::new() } else {
          let v386_6: Path = concat_path(&(v383_6),&(v383_11_head));
          let v386_11: Space = routine_12(c, &(v386_6), &(v383_11_tail), &(*s1));
          drop(v386_6);
          compose(&(v384_10),&(v386_11))
        };
        drop(v384_10);
        let v384_13: Space = unite(&(v384_8),&(v384_12));
        v383_11.join_into((v384_13).clone());
      }
      drop(v383_11_cursor);
      drop(v383_6);
      compose(&(v378_10),&(v383_11))
    };
    drop(v378_10);
    let v378_13: Space = unite(&(v378_8),&(v378_12));
    v377_12.join_into((v378_13).clone());
  }
  drop(v377_12_cursor);
  (v377_12).clone()
}

fn routine_38(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v387_12 = Space::new();
  let mut v387_12_cursor = (*s0).read_zipper();
  for v387_12_byte in v387_12_cursor.child_mask().iter() {
    v387_12_cursor.descend_to_byte(v387_12_byte);
    let v387_12_tail = v387_12_cursor.make_map();
    v387_12_cursor.ascend(1);
    let v387_12_head = Path::from_slice(&[v387_12_byte]);
    let v388_2: Space = singleton(&(v387_12_head));
    let v388_3: Space = intersect(&(*CONSTANT_3),&(v388_2));
    let v388_4: Space = if has_head(&(v388_3)) { singleton(&[]) } else { Space::new() };
    drop(v388_3);
    let v388_5: Space = subtract(&(*CONSTANT_2),&(v388_4));
    drop(v388_4);
    let v388_8: Space = if (v388_5).is_empty() { Space::new() } else {
      let v389_6: Path = concat_path(&(*p0),&(v387_12_head));
      let mut v389_7 = Space::new();
      let mut v389_7_cursor = (v387_12_tail).read_zipper();
      for v389_7_byte in v389_7_cursor.child_mask().iter() {
        v389_7_cursor.descend_to_byte(v389_7_byte);
        let v389_7_tail = v389_7_cursor.make_map();
        v389_7_cursor.ascend(1);
        let v389_7_head = Path::from_slice(&[v389_7_byte]);
        let v390_2: Space = singleton(&(v389_7_head));
        let v390_3: Space = intersect(&(*CONSTANT_3),&(v390_2));
        let v390_4: Space = if has_head(&(v390_3)) { singleton(&[]) } else { Space::new() };
        drop(v390_3);
        let v390_5: Space = subtract(&(*CONSTANT_2),&(v390_4));
        drop(v390_4);
        let v390_8: Space = if (v390_5).is_empty() { Space::new() } else {
          let v391_6: Path = concat_path(&(v389_6),&(v389_7_head));
          let v391_7: Space = routine_74(c, &(v391_6), &(v389_7_tail), &(*s1));
          compose(&(v390_5),&(v391_7))
        };
        drop(v390_5);
        let v390_9: Space = intersect(&(*CONSTANT_3),&(v390_2));
        drop(v390_2);
        let v390_10: Space = if has_head(&(v390_9)) { singleton(&[]) } else { Space::new() };
        drop(v390_9);
        let v390_12: Space = if (v390_10).is_empty() { Space::new() } else {
          let v392_6: Path = concat_path(&(v389_6),&(v389_7_head));
          let v392_11: Space = routine_75(c, &(v392_6), &(v389_7_tail), &(*s1));
          drop(v392_6);
          compose(&(v390_10),&(v392_11))
        };
        drop(v390_10);
        let v390_13: Space = unite(&(v390_8),&(v390_12));
        v389_7.join_into((v390_13).clone());
      }
      drop(v389_7_cursor);
      compose(&(v388_5),&(v389_7))
    };
    drop(v388_5);
    let v388_9: Space = intersect(&(*CONSTANT_3),&(v388_2));
    drop(v388_2);
    let v388_10: Space = if has_head(&(v388_9)) { singleton(&[]) } else { Space::new() };
    drop(v388_9);
    let v388_12: Space = if (v388_10).is_empty() { Space::new() } else {
      let v393_6: Path = concat_path(&(*p0),&(v387_12_head));
      let mut v393_11 = Space::new();
      let mut v393_11_cursor = (v387_12_tail).read_zipper();
      for v393_11_byte in v393_11_cursor.child_mask().iter() {
        v393_11_cursor.descend_to_byte(v393_11_byte);
        let v393_11_tail = v393_11_cursor.make_map();
        v393_11_cursor.ascend(1);
        let v393_11_head = Path::from_slice(&[v393_11_byte]);
        let v394_2: Space = singleton(&(v393_11_head));
        let v394_3: Space = intersect(&(*CONSTANT_3),&(v394_2));
        let v394_4: Space = if has_head(&(v394_3)) { singleton(&[]) } else { Space::new() };
        drop(v394_3);
        let v394_5: Space = subtract(&(*CONSTANT_2),&(v394_4));
        drop(v394_4);
        let v394_7: Space = if (v394_5).is_empty() { Space::new() } else {
          let v395_6: Space = routine_39(c, &(v393_11_head), &(v393_6), &(v393_11_tail), &(*s1));
          compose(&(v394_5),&(v395_6))
        };
        drop(v394_5);
        let v394_8: Space = intersect(&(*CONSTANT_3),&(v394_2));
        drop(v394_2);
        let v394_9: Space = if has_head(&(v394_8)) { singleton(&[]) } else { Space::new() };
        drop(v394_8);
        let v394_11: Space = if (v394_9).is_empty() { Space::new() } else {
          let v396_10: Space = routine_40(c, &(v393_11_head), &(v393_6), &(v393_11_tail), &(*s1));
          compose(&(v394_9),&(v396_10))
        };
        drop(v394_9);
        let v394_12: Space = unite(&(v394_7),&(v394_11));
        v393_11.join_into((v394_12).clone());
      }
      drop(v393_11_cursor);
      drop(v393_6);
      compose(&(v388_10),&(v393_11))
    };
    drop(v388_10);
    let v388_13: Space = unite(&(v388_8),&(v388_12));
    v387_12.join_into((v388_13).clone());
  }
  drop(v387_12_cursor);
  (v387_12).clone()
}

fn routine_39(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v397_13 = Space::new();
  let mut v397_13_cursor = (*s0).read_zipper();
  for v397_13_byte in v397_13_cursor.child_mask().iter() {
    v397_13_cursor.descend_to_byte(v397_13_byte);
    let v397_13_tail = v397_13_cursor.make_map();
    v397_13_cursor.ascend(1);
    let v397_13_head = Path::from_slice(&[v397_13_byte]);
    let v398_2: Space = singleton(&(v397_13_head));
    let v398_3: Space = intersect(&(*CONSTANT_3),&(v398_2));
    let v398_4: Space = if has_head(&(v398_3)) { singleton(&[]) } else { Space::new() };
    drop(v398_3);
    let v398_5: Space = subtract(&(*CONSTANT_2),&(v398_4));
    drop(v398_4);
    let v398_8: Space = if (v398_5).is_empty() { Space::new() } else {
      let v399_6: Path = concat_path(&(*p0),&(v397_13_head));
      let mut v399_7 = Space::new();
      let mut v399_7_cursor = (v397_13_tail).read_zipper();
      for v399_7_byte in v399_7_cursor.child_mask().iter() {
        v399_7_cursor.descend_to_byte(v399_7_byte);
        let v399_7_tail = v399_7_cursor.make_map();
        v399_7_cursor.ascend(1);
        let v399_7_head = Path::from_slice(&[v399_7_byte]);
        let v400_2: Space = singleton(&(v399_7_head));
        let v400_3: Space = intersect(&(*CONSTANT_3),&(v400_2));
        let v400_4: Space = if has_head(&(v400_3)) { singleton(&[]) } else { Space::new() };
        drop(v400_3);
        let v400_5: Space = subtract(&(*CONSTANT_2),&(v400_4));
        drop(v400_4);
        let v400_8: Space = if (v400_5).is_empty() { Space::new() } else {
          let v401_6: Path = concat_path(&(v399_6),&(v399_7_head));
          let v401_7: Space = routine_76(c, &(v401_6), &(*p1), &(v399_7_tail), &(*s1));
          compose(&(v400_5),&(v401_7))
        };
        drop(v400_5);
        let v400_9: Space = intersect(&(*CONSTANT_3),&(v400_2));
        drop(v400_2);
        let v400_10: Space = if has_head(&(v400_9)) { singleton(&[]) } else { Space::new() };
        drop(v400_9);
        let v400_12: Space = if (v400_10).is_empty() { Space::new() } else {
          let v402_6: Path = concat_path(&(v399_6),&(v399_7_head));
          let v402_11: Space = routine_77(c, &(v402_6), &(*p1), &(v399_7_tail), &(*s1));
          drop(v402_6);
          compose(&(v400_10),&(v402_11))
        };
        drop(v400_10);
        let v400_13: Space = unite(&(v400_8),&(v400_12));
        v399_7.join_into((v400_13).clone());
      }
      drop(v399_7_cursor);
      compose(&(v398_5),&(v399_7))
    };
    drop(v398_5);
    let v398_9: Space = intersect(&(*CONSTANT_3),&(v398_2));
    drop(v398_2);
    let v398_10: Space = if has_head(&(v398_9)) { singleton(&[]) } else { Space::new() };
    drop(v398_9);
    let v398_12: Space = if (v398_10).is_empty() { Space::new() } else {
      let v403_6: Path = concat_path(&(*p0),&(v397_13_head));
      let mut v403_11 = Space::new();
      let mut v403_11_cursor = (v397_13_tail).read_zipper();
      for v403_11_byte in v403_11_cursor.child_mask().iter() {
        v403_11_cursor.descend_to_byte(v403_11_byte);
        let v403_11_tail = v403_11_cursor.make_map();
        v403_11_cursor.ascend(1);
        let v403_11_head = Path::from_slice(&[v403_11_byte]);
        let v404_2: Space = singleton(&(v403_11_head));
        let v404_3: Space = intersect(&(*CONSTANT_3),&(v404_2));
        let v404_4: Space = if has_head(&(v404_3)) { singleton(&[]) } else { Space::new() };
        drop(v404_3);
        let v404_5: Space = subtract(&(*CONSTANT_2),&(v404_4));
        drop(v404_4);
        let v404_8: Space = if (v404_5).is_empty() { Space::new() } else {
          let v405_6: Path = concat_path(&(v403_6),&(v403_11_head));
          let v405_7: Space = routine_76(c, &(v405_6), &(*p1), &(v403_11_tail), &(*s1));
          compose(&(v404_5),&(v405_7))
        };
        drop(v404_5);
        let v404_9: Space = intersect(&(*CONSTANT_3),&(v404_2));
        drop(v404_2);
        let v404_10: Space = if has_head(&(v404_9)) { singleton(&[]) } else { Space::new() };
        drop(v404_9);
        let v404_12: Space = if (v404_10).is_empty() { Space::new() } else {
          let v406_6: Path = concat_path(&(v403_6),&(v403_11_head));
          let v406_11: Space = routine_43(c, &(v406_6), &(*p1), &(v403_11_tail), &(*s1));
          drop(v406_6);
          compose(&(v404_10),&(v406_11))
        };
        drop(v404_10);
        let v404_13: Space = unite(&(v404_8),&(v404_12));
        v403_11.join_into((v404_13).clone());
      }
      drop(v403_11_cursor);
      drop(v403_6);
      compose(&(v398_10),&(v403_11))
    };
    drop(v398_10);
    let v398_13: Space = unite(&(v398_8),&(v398_12));
    v397_13.join_into((v398_13).clone());
  }
  drop(v397_13_cursor);
  (v397_13).clone()
}

fn routine_40(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v407_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v407_10: Space = unwrap(&(v407_8),&(*CONSTANT_5));
  drop(v407_8);
  let v407_11: Space = unwrap(&(v407_10),&(*p0));
  drop(v407_10);
  let mut v407_18 = Space::new();
  let mut v407_18_cursor = (*s0).read_zipper();
  for v407_18_byte in v407_18_cursor.child_mask().iter() {
    v407_18_cursor.descend_to_byte(v407_18_byte);
    let v407_18_tail = v407_18_cursor.make_map();
    v407_18_cursor.ascend(1);
    let v407_18_head = Path::from_slice(&[v407_18_byte]);
    let v408_2: Space = singleton(&(v407_18_head));
    let v408_3: Space = intersect(&(*CONSTANT_3),&(v408_2));
    let v408_4: Space = if has_head(&(v408_3)) { singleton(&[]) } else { Space::new() };
    drop(v408_3);
    let v408_5: Space = subtract(&(*CONSTANT_2),&(v408_4));
    drop(v408_4);
    let v408_8: Space = if (v408_5).is_empty() { Space::new() } else {
      let v409_6: Path = concat_path(&(*p0),&(v407_18_head));
      let mut v409_7 = Space::new();
      let mut v409_7_cursor = (v407_18_tail).read_zipper();
      for v409_7_byte in v409_7_cursor.child_mask().iter() {
        v409_7_cursor.descend_to_byte(v409_7_byte);
        let v409_7_tail = v409_7_cursor.make_map();
        v409_7_cursor.ascend(1);
        let v409_7_head = Path::from_slice(&[v409_7_byte]);
        let v410_2: Space = singleton(&(v409_7_head));
        let v410_3: Space = intersect(&(*CONSTANT_3),&(v410_2));
        let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
        drop(v410_3);
        let v410_5: Space = subtract(&(*CONSTANT_2),&(v410_4));
        drop(v410_4);
        let v410_8: Space = if (v410_5).is_empty() { Space::new() } else {
          let v411_6: Path = concat_path(&(v409_6),&(v409_7_head));
          let v411_7: Space = routine_76(c, &(v411_6), &(*p1), &(v409_7_tail), &(*s1));
          compose(&(v410_5),&(v411_7))
        };
        drop(v410_5);
        let v410_9: Space = intersect(&(*CONSTANT_3),&(v410_2));
        drop(v410_2);
        let v410_10: Space = if has_head(&(v410_9)) { singleton(&[]) } else { Space::new() };
        drop(v410_9);
        let v410_12: Space = if (v410_10).is_empty() { Space::new() } else {
          let v412_6: Path = concat_path(&(v409_6),&(v409_7_head));
          let v412_11: Space = routine_77(c, &(v412_6), &(*p1), &(v409_7_tail), &(*s1));
          drop(v412_6);
          compose(&(v410_10),&(v412_11))
        };
        drop(v410_10);
        let v410_13: Space = unite(&(v410_8),&(v410_12));
        v409_7.join_into((v410_13).clone());
      }
      drop(v409_7_cursor);
      drop(v409_6);
      compose(&(v408_5),&(v409_7))
    };
    drop(v408_5);
    let v408_9: Space = intersect(&(*CONSTANT_3),&(v408_2));
    drop(v408_2);
    let v408_10: Space = if has_head(&(v408_9)) { singleton(&[]) } else { Space::new() };
    drop(v408_9);
    let v408_13: Space = if (v408_10).is_empty() { Space::new() } else {
      let v413_11: Space = unwrap(&(v407_11),&(v407_18_head));
      let mut v413_12 = Space::new();
      let mut v413_12_cursor = (v413_11).read_zipper();
      for v413_12_byte in v413_12_cursor.child_mask().iter() {
        v413_12_cursor.descend_to_byte(v413_12_byte);
        let v413_12_tail = v413_12_cursor.make_map();
        v413_12_cursor.ascend(1);
        let v413_12_head = Path::from_slice(&[v413_12_byte]);
        let v414_2: Space = singleton(&(v413_12_head));
        let v414_3: Space = intersect(&(*CONSTANT_3),&(v414_2));
        let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
        drop(v414_3);
        let v414_5: Space = subtract(&(*CONSTANT_2),&(v414_4));
        drop(v414_4);
        let v414_7: Space = if (v414_5).is_empty() { Space::new() } else {
          let v415_6: Space = routine_78(c, &(v413_12_head), &(*p1), &(v413_12_tail));
          compose(&(v414_5),&(v415_6))
        };
        drop(v414_5);
        let v414_8: Space = intersect(&(*CONSTANT_3),&(v414_2));
        drop(v414_2);
        let v414_9: Space = if has_head(&(v414_8)) { singleton(&[]) } else { Space::new() };
        drop(v414_8);
        let v414_11: Space = if (v414_9).is_empty() { Space::new() } else {
          let v416_10: Space = routine_79(c, &(v413_12_head), &(*p1), &(v413_12_tail));
          compose(&(v414_9),&(v416_10))
        };
        drop(v414_9);
        let v414_12: Space = unite(&(v414_7),&(v414_11));
        v413_12.join_into((v414_12).clone());
      }
      drop(v413_12_cursor);
      drop(v413_11);
      compose(&(v408_10),&(v413_12))
    };
    drop(v408_10);
    let v408_14: Space = unite(&(v408_8),&(v408_13));
    v407_18.join_into((v408_14).clone());
  }
  drop(v407_18_cursor);
  drop(v407_11);
  (v407_18).clone()
}

fn routine_41(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v417_13 = Space::new();
  let mut v417_13_cursor = (*s0).read_zipper();
  for v417_13_byte in v417_13_cursor.child_mask().iter() {
    v417_13_cursor.descend_to_byte(v417_13_byte);
    let v417_13_tail = v417_13_cursor.make_map();
    v417_13_cursor.ascend(1);
    let v417_13_head = Path::from_slice(&[v417_13_byte]);
    let v418_2: Space = singleton(&(v417_13_head));
    let v418_3: Space = intersect(&(*CONSTANT_3),&(v418_2));
    let v418_4: Space = if has_head(&(v418_3)) { singleton(&[]) } else { Space::new() };
    drop(v418_3);
    let v418_5: Space = subtract(&(*CONSTANT_2),&(v418_4));
    drop(v418_4);
    let v418_8: Space = if (v418_5).is_empty() { Space::new() } else {
      let v419_6: Path = concat_path(&(*p0),&(v417_13_head));
      let mut v419_7 = Space::new();
      let mut v419_7_cursor = (v417_13_tail).read_zipper();
      for v419_7_byte in v419_7_cursor.child_mask().iter() {
        v419_7_cursor.descend_to_byte(v419_7_byte);
        let v419_7_tail = v419_7_cursor.make_map();
        v419_7_cursor.ascend(1);
        let v419_7_head = Path::from_slice(&[v419_7_byte]);
        let v420_2: Space = singleton(&(v419_7_head));
        let v420_3: Space = intersect(&(*CONSTANT_3),&(v420_2));
        let v420_4: Space = if has_head(&(v420_3)) { singleton(&[]) } else { Space::new() };
        drop(v420_3);
        let v420_5: Space = subtract(&(*CONSTANT_2),&(v420_4));
        drop(v420_4);
        let v420_8: Space = if (v420_5).is_empty() { Space::new() } else {
          let v421_6: Path = concat_path(&(v419_6),&(v419_7_head));
          let v421_7: Space = routine_80(c, &(v421_6), &(*p1), &(v419_7_tail), &(*s1));
          compose(&(v420_5),&(v421_7))
        };
        drop(v420_5);
        let v420_9: Space = intersect(&(*CONSTANT_3),&(v420_2));
        drop(v420_2);
        let v420_10: Space = if has_head(&(v420_9)) { singleton(&[]) } else { Space::new() };
        drop(v420_9);
        let v420_12: Space = if (v420_10).is_empty() { Space::new() } else {
          let v422_6: Path = concat_path(&(v419_6),&(v419_7_head));
          let v422_11: Space = routine_81(c, &(v422_6), &(*p1), &(v419_7_tail), &(*s1));
          drop(v422_6);
          compose(&(v420_10),&(v422_11))
        };
        drop(v420_10);
        let v420_13: Space = unite(&(v420_8),&(v420_12));
        v419_7.join_into((v420_13).clone());
      }
      drop(v419_7_cursor);
      compose(&(v418_5),&(v419_7))
    };
    drop(v418_5);
    let v418_9: Space = intersect(&(*CONSTANT_3),&(v418_2));
    drop(v418_2);
    let v418_10: Space = if has_head(&(v418_9)) { singleton(&[]) } else { Space::new() };
    drop(v418_9);
    let v418_12: Space = if (v418_10).is_empty() { Space::new() } else {
      let v423_6: Path = concat_path(&(*p0),&(v417_13_head));
      let mut v423_11 = Space::new();
      let mut v423_11_cursor = (v417_13_tail).read_zipper();
      for v423_11_byte in v423_11_cursor.child_mask().iter() {
        v423_11_cursor.descend_to_byte(v423_11_byte);
        let v423_11_tail = v423_11_cursor.make_map();
        v423_11_cursor.ascend(1);
        let v423_11_head = Path::from_slice(&[v423_11_byte]);
        let v424_2: Space = singleton(&(v423_11_head));
        let v424_3: Space = intersect(&(*CONSTANT_3),&(v424_2));
        let v424_4: Space = if has_head(&(v424_3)) { singleton(&[]) } else { Space::new() };
        drop(v424_3);
        let v424_5: Space = subtract(&(*CONSTANT_2),&(v424_4));
        drop(v424_4);
        let v424_8: Space = if (v424_5).is_empty() { Space::new() } else {
          let v425_6: Path = concat_path(&(v423_6),&(v423_11_head));
          let v425_7: Space = routine_80(c, &(v425_6), &(*p1), &(v423_11_tail), &(*s1));
          compose(&(v424_5),&(v425_7))
        };
        drop(v424_5);
        let v424_9: Space = intersect(&(*CONSTANT_3),&(v424_2));
        drop(v424_2);
        let v424_10: Space = if has_head(&(v424_9)) { singleton(&[]) } else { Space::new() };
        drop(v424_9);
        let v424_12: Space = if (v424_10).is_empty() { Space::new() } else {
          let v426_6: Path = concat_path(&(v423_6),&(v423_11_head));
          let v426_11: Space = routine_43(c, &(v426_6), &(*p1), &(v423_11_tail), &(*s1));
          drop(v426_6);
          compose(&(v424_10),&(v426_11))
        };
        drop(v424_10);
        let v424_13: Space = unite(&(v424_8),&(v424_12));
        v423_11.join_into((v424_13).clone());
      }
      drop(v423_11_cursor);
      drop(v423_6);
      compose(&(v418_10),&(v423_11))
    };
    drop(v418_10);
    let v418_13: Space = unite(&(v418_8),&(v418_12));
    v417_13.join_into((v418_13).clone());
  }
  drop(v417_13_cursor);
  (v417_13).clone()
}

fn routine_42(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v427_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v427_10: Space = unwrap(&(v427_8),&(*CONSTANT_5));
  drop(v427_8);
  let v427_11: Space = unwrap(&(v427_10),&(*p0));
  drop(v427_10);
  let mut v427_18 = Space::new();
  let mut v427_18_cursor = (*s0).read_zipper();
  for v427_18_byte in v427_18_cursor.child_mask().iter() {
    v427_18_cursor.descend_to_byte(v427_18_byte);
    let v427_18_tail = v427_18_cursor.make_map();
    v427_18_cursor.ascend(1);
    let v427_18_head = Path::from_slice(&[v427_18_byte]);
    let v428_2: Space = singleton(&(v427_18_head));
    let v428_3: Space = intersect(&(*CONSTANT_3),&(v428_2));
    let v428_4: Space = if has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
    drop(v428_3);
    let v428_5: Space = subtract(&(*CONSTANT_2),&(v428_4));
    drop(v428_4);
    let v428_8: Space = if (v428_5).is_empty() { Space::new() } else {
      let v429_6: Path = concat_path(&(*p0),&(v427_18_head));
      let mut v429_7 = Space::new();
      let mut v429_7_cursor = (v427_18_tail).read_zipper();
      for v429_7_byte in v429_7_cursor.child_mask().iter() {
        v429_7_cursor.descend_to_byte(v429_7_byte);
        let v429_7_tail = v429_7_cursor.make_map();
        v429_7_cursor.ascend(1);
        let v429_7_head = Path::from_slice(&[v429_7_byte]);
        let v430_2: Space = singleton(&(v429_7_head));
        let v430_3: Space = intersect(&(*CONSTANT_3),&(v430_2));
        let v430_4: Space = if has_head(&(v430_3)) { singleton(&[]) } else { Space::new() };
        drop(v430_3);
        let v430_5: Space = subtract(&(*CONSTANT_2),&(v430_4));
        drop(v430_4);
        let v430_8: Space = if (v430_5).is_empty() { Space::new() } else {
          let v431_6: Path = concat_path(&(v429_6),&(v429_7_head));
          let v431_7: Space = routine_80(c, &(v431_6), &(*p1), &(v429_7_tail), &(*s1));
          compose(&(v430_5),&(v431_7))
        };
        drop(v430_5);
        let v430_9: Space = intersect(&(*CONSTANT_3),&(v430_2));
        drop(v430_2);
        let v430_10: Space = if has_head(&(v430_9)) { singleton(&[]) } else { Space::new() };
        drop(v430_9);
        let v430_12: Space = if (v430_10).is_empty() { Space::new() } else {
          let v432_6: Path = concat_path(&(v429_6),&(v429_7_head));
          let v432_11: Space = routine_81(c, &(v432_6), &(*p1), &(v429_7_tail), &(*s1));
          drop(v432_6);
          compose(&(v430_10),&(v432_11))
        };
        drop(v430_10);
        let v430_13: Space = unite(&(v430_8),&(v430_12));
        v429_7.join_into((v430_13).clone());
      }
      drop(v429_7_cursor);
      drop(v429_6);
      compose(&(v428_5),&(v429_7))
    };
    drop(v428_5);
    let v428_9: Space = intersect(&(*CONSTANT_3),&(v428_2));
    drop(v428_2);
    let v428_10: Space = if has_head(&(v428_9)) { singleton(&[]) } else { Space::new() };
    drop(v428_9);
    let v428_13: Space = if (v428_10).is_empty() { Space::new() } else {
      let v433_11: Space = unwrap(&(v427_11),&(v427_18_head));
      let mut v433_12 = Space::new();
      let mut v433_12_cursor = (v433_11).read_zipper();
      for v433_12_byte in v433_12_cursor.child_mask().iter() {
        v433_12_cursor.descend_to_byte(v433_12_byte);
        let v433_12_tail = v433_12_cursor.make_map();
        v433_12_cursor.ascend(1);
        let v433_12_head = Path::from_slice(&[v433_12_byte]);
        let v434_2: Space = singleton(&(v433_12_head));
        let v434_3: Space = intersect(&(*CONSTANT_3),&(v434_2));
        let v434_4: Space = if has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
        drop(v434_3);
        let v434_5: Space = subtract(&(*CONSTANT_2),&(v434_4));
        drop(v434_4);
        let v434_7: Space = if (v434_5).is_empty() { Space::new() } else {
          let v435_6: Space = routine_78(c, &(v433_12_head), &(*p1), &(v433_12_tail));
          compose(&(v434_5),&(v435_6))
        };
        drop(v434_5);
        let v434_8: Space = intersect(&(*CONSTANT_3),&(v434_2));
        drop(v434_2);
        let v434_9: Space = if has_head(&(v434_8)) { singleton(&[]) } else { Space::new() };
        drop(v434_8);
        let v434_11: Space = if (v434_9).is_empty() { Space::new() } else {
          let v436_10: Space = routine_79(c, &(v433_12_head), &(*p1), &(v433_12_tail));
          compose(&(v434_9),&(v436_10))
        };
        drop(v434_9);
        let v434_12: Space = unite(&(v434_7),&(v434_11));
        v433_12.join_into((v434_12).clone());
      }
      drop(v433_12_cursor);
      drop(v433_11);
      compose(&(v428_10),&(v433_12))
    };
    drop(v428_10);
    let v428_14: Space = unite(&(v428_8),&(v428_13));
    v427_18.join_into((v428_14).clone());
  }
  drop(v427_18_cursor);
  drop(v427_11);
  (v427_18).clone()
}

fn routine_43(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v437_5: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v437_7: Space = unwrap(&(v437_5),&(*CONSTANT_5));
  drop(v437_5);
  let v437_8: Space = unwrap(&(v437_7),&(*p0));
  drop(v437_7);
  let mut v437_18 = Space::new();
  let mut v437_18_cursor = (v437_8).read_zipper();
  for v437_18_byte in v437_18_cursor.child_mask().iter() {
    v437_18_cursor.descend_to_byte(v437_18_byte);
    let v437_18_tail = v437_18_cursor.make_map();
    v437_18_cursor.ascend(1);
    let v437_18_head = Path::from_slice(&[v437_18_byte]);
    let v438_2: Space = singleton(&(v437_18_head));
    let v438_3: Space = intersect(&(*CONSTANT_3),&(v438_2));
    let v438_4: Space = if has_head(&(v438_3)) { singleton(&[]) } else { Space::new() };
    drop(v438_3);
    let v438_5: Space = subtract(&(*CONSTANT_2),&(v438_4));
    drop(v438_4);
    let v438_7: Space = if (v438_5).is_empty() { Space::new() } else {
      let mut v439_6 = Space::new();
      let mut v439_6_cursor = (v437_18_tail).read_zipper();
      for v439_6_byte in v439_6_cursor.child_mask().iter() {
        v439_6_cursor.descend_to_byte(v439_6_byte);
        let v439_6_tail = v439_6_cursor.make_map();
        v439_6_cursor.ascend(1);
        let v439_6_head = Path::from_slice(&[v439_6_byte]);
        let v440_2: Space = singleton(&(v439_6_head));
        let v440_3: Space = intersect(&(*CONSTANT_3),&(v440_2));
        let v440_4: Space = if has_head(&(v440_3)) { singleton(&[]) } else { Space::new() };
        drop(v440_3);
        let v440_5: Space = subtract(&(*CONSTANT_2),&(v440_4));
        drop(v440_4);
        let v440_8: Space = if (v440_5).is_empty() { Space::new() } else {
          let v441_6: Path = concat_path(&(v437_18_head),&(v439_6_head));
          let v441_7: Space = routine_82(c, &(v441_6), &(*p1), &(v439_6_tail));
          compose(&(v440_5),&(v441_7))
        };
        drop(v440_5);
        let v440_9: Space = intersect(&(*CONSTANT_3),&(v440_2));
        drop(v440_2);
        let v440_10: Space = if has_head(&(v440_9)) { singleton(&[]) } else { Space::new() };
        drop(v440_9);
        let v440_12: Space = if (v440_10).is_empty() { Space::new() } else {
          let v442_6: Path = concat_path(&(v437_18_head),&(v439_6_head));
          let v442_11: Space = routine_83(c, &(v442_6), &(*p1), &(v439_6_tail));
          drop(v442_6);
          compose(&(v440_10),&(v442_11))
        };
        drop(v440_10);
        let v440_13: Space = unite(&(v440_8),&(v440_12));
        v439_6.join_into((v440_13).clone());
      }
      drop(v439_6_cursor);
      compose(&(v438_5),&(v439_6))
    };
    drop(v438_5);
    let v438_8: Space = intersect(&(*CONSTANT_3),&(v438_2));
    drop(v438_2);
    let v438_9: Space = if has_head(&(v438_8)) { singleton(&[]) } else { Space::new() };
    drop(v438_8);
    let v438_11: Space = if (v438_9).is_empty() { Space::new() } else {
      let mut v443_10 = Space::new();
      let mut v443_10_cursor = (v437_18_tail).read_zipper();
      for v443_10_byte in v443_10_cursor.child_mask().iter() {
        v443_10_cursor.descend_to_byte(v443_10_byte);
        let v443_10_tail = v443_10_cursor.make_map();
        v443_10_cursor.ascend(1);
        let v443_10_head = Path::from_slice(&[v443_10_byte]);
        let v444_2: Space = singleton(&(v443_10_head));
        let v444_3: Space = intersect(&(*CONSTANT_3),&(v444_2));
        let v444_4: Space = if has_head(&(v444_3)) { singleton(&[]) } else { Space::new() };
        drop(v444_3);
        let v444_5: Space = subtract(&(*CONSTANT_2),&(v444_4));
        drop(v444_4);
        let v444_8: Space = if (v444_5).is_empty() { Space::new() } else {
          let v445_6: Path = concat_path(&(v437_18_head),&(v443_10_head));
          let v445_7: Space = routine_82(c, &(v445_6), &(*p1), &(v443_10_tail));
          compose(&(v444_5),&(v445_7))
        };
        drop(v444_5);
        let v444_9: Space = intersect(&(*CONSTANT_3),&(v444_2));
        drop(v444_2);
        let v444_10: Space = if has_head(&(v444_9)) { singleton(&[]) } else { Space::new() };
        drop(v444_9);
        let v444_12: Space = if (v444_10).is_empty() { Space::new() } else {
          let v446_6: Path = concat_path(&(v437_18_head),&(v443_10_head));
          let v446_11: Space = routine_84(c, &(v446_6), &(*p1), &(v443_10_tail));
          drop(v446_6);
          compose(&(v444_10),&(v446_11))
        };
        drop(v444_10);
        let v444_13: Space = unite(&(v444_8),&(v444_12));
        v443_10.join_into((v444_13).clone());
      }
      drop(v443_10_cursor);
      compose(&(v438_9),&(v443_10))
    };
    drop(v438_9);
    let v438_12: Space = unite(&(v438_7),&(v438_11));
    v437_18.join_into((v438_12).clone());
  }
  drop(v437_18_cursor);
  drop(v437_8);
  (v437_18).clone()
}

fn routine_44(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v447_12 = Space::new();
  let mut v447_12_cursor = (*s0).read_zipper();
  for v447_12_byte in v447_12_cursor.child_mask().iter() {
    v447_12_cursor.descend_to_byte(v447_12_byte);
    let v447_12_tail = v447_12_cursor.make_map();
    v447_12_cursor.ascend(1);
    let v447_12_head = Path::from_slice(&[v447_12_byte]);
    let v448_2: Space = singleton(&(v447_12_head));
    let v448_3: Space = intersect(&(*CONSTANT_3),&(v448_2));
    let v448_4: Space = if has_head(&(v448_3)) { singleton(&[]) } else { Space::new() };
    drop(v448_3);
    let v448_5: Space = subtract(&(*CONSTANT_2),&(v448_4));
    drop(v448_4);
    let v448_8: Space = if (v448_5).is_empty() { Space::new() } else {
      let v449_6: Path = concat_path(&(*p0),&(v447_12_head));
      let mut v449_7 = Space::new();
      let mut v449_7_cursor = (v447_12_tail).read_zipper();
      for v449_7_byte in v449_7_cursor.child_mask().iter() {
        v449_7_cursor.descend_to_byte(v449_7_byte);
        let v449_7_tail = v449_7_cursor.make_map();
        v449_7_cursor.ascend(1);
        let v449_7_head = Path::from_slice(&[v449_7_byte]);
        let v450_2: Space = singleton(&(v449_7_head));
        let v450_3: Space = intersect(&(*CONSTANT_3),&(v450_2));
        let v450_4: Space = if has_head(&(v450_3)) { singleton(&[]) } else { Space::new() };
        drop(v450_3);
        let v450_5: Space = subtract(&(*CONSTANT_2),&(v450_4));
        drop(v450_4);
        let v450_8: Space = if (v450_5).is_empty() { Space::new() } else {
          let v451_6: Path = concat_path(&(v449_6),&(v449_7_head));
          let v451_7: Space = routine_85(c, &(v451_6), &(v449_7_tail), &(*s1));
          compose(&(v450_5),&(v451_7))
        };
        drop(v450_5);
        let v450_9: Space = intersect(&(*CONSTANT_3),&(v450_2));
        drop(v450_2);
        let v450_10: Space = if has_head(&(v450_9)) { singleton(&[]) } else { Space::new() };
        drop(v450_9);
        let v450_12: Space = if (v450_10).is_empty() { Space::new() } else {
          let v452_6: Path = concat_path(&(v449_6),&(v449_7_head));
          let v452_11: Space = routine_86(c, &(v452_6), &(v449_7_tail), &(*s1));
          drop(v452_6);
          compose(&(v450_10),&(v452_11))
        };
        drop(v450_10);
        let v450_13: Space = unite(&(v450_8),&(v450_12));
        v449_7.join_into((v450_13).clone());
      }
      drop(v449_7_cursor);
      compose(&(v448_5),&(v449_7))
    };
    drop(v448_5);
    let v448_9: Space = intersect(&(*CONSTANT_3),&(v448_2));
    drop(v448_2);
    let v448_10: Space = if has_head(&(v448_9)) { singleton(&[]) } else { Space::new() };
    drop(v448_9);
    let v448_12: Space = if (v448_10).is_empty() { Space::new() } else {
      let v453_6: Path = concat_path(&(*p0),&(v447_12_head));
      let mut v453_11 = Space::new();
      let mut v453_11_cursor = (v447_12_tail).read_zipper();
      for v453_11_byte in v453_11_cursor.child_mask().iter() {
        v453_11_cursor.descend_to_byte(v453_11_byte);
        let v453_11_tail = v453_11_cursor.make_map();
        v453_11_cursor.ascend(1);
        let v453_11_head = Path::from_slice(&[v453_11_byte]);
        let v454_2: Space = singleton(&(v453_11_head));
        let v454_3: Space = intersect(&(*CONSTANT_3),&(v454_2));
        let v454_4: Space = if has_head(&(v454_3)) { singleton(&[]) } else { Space::new() };
        drop(v454_3);
        let v454_5: Space = subtract(&(*CONSTANT_2),&(v454_4));
        drop(v454_4);
        let v454_8: Space = if (v454_5).is_empty() { Space::new() } else {
          let v455_6: Path = concat_path(&(v453_6),&(v453_11_head));
          let v455_7: Space = routine_85(c, &(v455_6), &(v453_11_tail), &(*s1));
          compose(&(v454_5),&(v455_7))
        };
        drop(v454_5);
        let v454_9: Space = intersect(&(*CONSTANT_3),&(v454_2));
        drop(v454_2);
        let v454_10: Space = if has_head(&(v454_9)) { singleton(&[]) } else { Space::new() };
        drop(v454_9);
        let v454_12: Space = if (v454_10).is_empty() { Space::new() } else {
          let v456_6: Path = concat_path(&(v453_6),&(v453_11_head));
          let v456_11: Space = routine_15(c, &(v456_6), &(v453_11_tail), &(*s1));
          drop(v456_6);
          compose(&(v454_10),&(v456_11))
        };
        drop(v454_10);
        let v454_13: Space = unite(&(v454_8),&(v454_12));
        v453_11.join_into((v454_13).clone());
      }
      drop(v453_11_cursor);
      drop(v453_6);
      compose(&(v448_10),&(v453_11))
    };
    drop(v448_10);
    let v448_13: Space = unite(&(v448_8),&(v448_12));
    v447_12.join_into((v448_13).clone());
  }
  drop(v447_12_cursor);
  (v447_12).clone()
}

fn routine_45(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v457_12 = Space::new();
  let mut v457_12_cursor = (*s0).read_zipper();
  for v457_12_byte in v457_12_cursor.child_mask().iter() {
    v457_12_cursor.descend_to_byte(v457_12_byte);
    let v457_12_tail = v457_12_cursor.make_map();
    v457_12_cursor.ascend(1);
    let v457_12_head = Path::from_slice(&[v457_12_byte]);
    let v458_2: Space = singleton(&(v457_12_head));
    let v458_3: Space = intersect(&(*CONSTANT_3),&(v458_2));
    let v458_4: Space = if has_head(&(v458_3)) { singleton(&[]) } else { Space::new() };
    drop(v458_3);
    let v458_5: Space = subtract(&(*CONSTANT_2),&(v458_4));
    drop(v458_4);
    let v458_8: Space = if (v458_5).is_empty() { Space::new() } else {
      let v459_6: Path = concat_path(&(*p0),&(v457_12_head));
      let mut v459_7 = Space::new();
      let mut v459_7_cursor = (v457_12_tail).read_zipper();
      for v459_7_byte in v459_7_cursor.child_mask().iter() {
        v459_7_cursor.descend_to_byte(v459_7_byte);
        let v459_7_tail = v459_7_cursor.make_map();
        v459_7_cursor.ascend(1);
        let v459_7_head = Path::from_slice(&[v459_7_byte]);
        let v460_2: Space = singleton(&(v459_7_head));
        let v460_3: Space = intersect(&(*CONSTANT_3),&(v460_2));
        let v460_4: Space = if has_head(&(v460_3)) { singleton(&[]) } else { Space::new() };
        drop(v460_3);
        let v460_5: Space = subtract(&(*CONSTANT_2),&(v460_4));
        drop(v460_4);
        let v460_8: Space = if (v460_5).is_empty() { Space::new() } else {
          let v461_6: Path = concat_path(&(v459_6),&(v459_7_head));
          let v461_7: Space = routine_85(c, &(v461_6), &(v459_7_tail), &(*s1));
          compose(&(v460_5),&(v461_7))
        };
        drop(v460_5);
        let v460_9: Space = intersect(&(*CONSTANT_3),&(v460_2));
        drop(v460_2);
        let v460_10: Space = if has_head(&(v460_9)) { singleton(&[]) } else { Space::new() };
        drop(v460_9);
        let v460_12: Space = if (v460_10).is_empty() { Space::new() } else {
          let v462_6: Path = concat_path(&(v459_6),&(v459_7_head));
          let v462_11: Space = routine_86(c, &(v462_6), &(v459_7_tail), &(*s1));
          drop(v462_6);
          compose(&(v460_10),&(v462_11))
        };
        drop(v460_10);
        let v460_13: Space = unite(&(v460_8),&(v460_12));
        v459_7.join_into((v460_13).clone());
      }
      drop(v459_7_cursor);
      compose(&(v458_5),&(v459_7))
    };
    drop(v458_5);
    let v458_9: Space = intersect(&(*CONSTANT_3),&(v458_2));
    drop(v458_2);
    let v458_10: Space = if has_head(&(v458_9)) { singleton(&[]) } else { Space::new() };
    drop(v458_9);
    let v458_12: Space = if (v458_10).is_empty() { Space::new() } else {
      let v463_6: Path = concat_path(&(*p0),&(v457_12_head));
      let mut v463_11 = Space::new();
      let mut v463_11_cursor = (v457_12_tail).read_zipper();
      for v463_11_byte in v463_11_cursor.child_mask().iter() {
        v463_11_cursor.descend_to_byte(v463_11_byte);
        let v463_11_tail = v463_11_cursor.make_map();
        v463_11_cursor.ascend(1);
        let v463_11_head = Path::from_slice(&[v463_11_byte]);
        let v464_2: Space = singleton(&(v463_11_head));
        let v464_3: Space = intersect(&(*CONSTANT_3),&(v464_2));
        let v464_4: Space = if has_head(&(v464_3)) { singleton(&[]) } else { Space::new() };
        drop(v464_3);
        let v464_5: Space = subtract(&(*CONSTANT_2),&(v464_4));
        drop(v464_4);
        let v464_7: Space = if (v464_5).is_empty() { Space::new() } else {
          let v465_6: Space = routine_46(c, &(v463_11_head), &(v463_6), &(v463_11_tail), &(*s1));
          compose(&(v464_5),&(v465_6))
        };
        drop(v464_5);
        let v464_8: Space = intersect(&(*CONSTANT_3),&(v464_2));
        drop(v464_2);
        let v464_9: Space = if has_head(&(v464_8)) { singleton(&[]) } else { Space::new() };
        drop(v464_8);
        let v464_11: Space = if (v464_9).is_empty() { Space::new() } else {
          let v466_10: Space = routine_47(c, &(v463_11_head), &(v463_6), &(v463_11_tail), &(*s1));
          compose(&(v464_9),&(v466_10))
        };
        drop(v464_9);
        let v464_12: Space = unite(&(v464_7),&(v464_11));
        v463_11.join_into((v464_12).clone());
      }
      drop(v463_11_cursor);
      drop(v463_6);
      compose(&(v458_10),&(v463_11))
    };
    drop(v458_10);
    let v458_13: Space = unite(&(v458_8),&(v458_12));
    v457_12.join_into((v458_13).clone());
  }
  drop(v457_12_cursor);
  (v457_12).clone()
}

fn routine_46(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v467_13 = Space::new();
  let mut v467_13_cursor = (*s0).read_zipper();
  for v467_13_byte in v467_13_cursor.child_mask().iter() {
    v467_13_cursor.descend_to_byte(v467_13_byte);
    let v467_13_tail = v467_13_cursor.make_map();
    v467_13_cursor.ascend(1);
    let v467_13_head = Path::from_slice(&[v467_13_byte]);
    let v468_2: Space = singleton(&(v467_13_head));
    let v468_3: Space = intersect(&(*CONSTANT_3),&(v468_2));
    let v468_4: Space = if has_head(&(v468_3)) { singleton(&[]) } else { Space::new() };
    drop(v468_3);
    let v468_5: Space = subtract(&(*CONSTANT_2),&(v468_4));
    drop(v468_4);
    let v468_8: Space = if (v468_5).is_empty() { Space::new() } else {
      let v469_6: Path = concat_path(&(*p0),&(v467_13_head));
      let mut v469_7 = Space::new();
      let mut v469_7_cursor = (v467_13_tail).read_zipper();
      for v469_7_byte in v469_7_cursor.child_mask().iter() {
        v469_7_cursor.descend_to_byte(v469_7_byte);
        let v469_7_tail = v469_7_cursor.make_map();
        v469_7_cursor.ascend(1);
        let v469_7_head = Path::from_slice(&[v469_7_byte]);
        let v470_2: Space = singleton(&(v469_7_head));
        let v470_3: Space = intersect(&(*CONSTANT_3),&(v470_2));
        let v470_4: Space = if has_head(&(v470_3)) { singleton(&[]) } else { Space::new() };
        drop(v470_3);
        let v470_5: Space = subtract(&(*CONSTANT_2),&(v470_4));
        drop(v470_4);
        let v470_8: Space = if (v470_5).is_empty() { Space::new() } else {
          let v471_6: Path = concat_path(&(v469_6),&(v469_7_head));
          let v471_7: Space = routine_87(c, &(v471_6), &(*p1), &(v469_7_tail), &(*s1));
          compose(&(v470_5),&(v471_7))
        };
        drop(v470_5);
        let v470_9: Space = intersect(&(*CONSTANT_3),&(v470_2));
        drop(v470_2);
        let v470_10: Space = if has_head(&(v470_9)) { singleton(&[]) } else { Space::new() };
        drop(v470_9);
        let v470_12: Space = if (v470_10).is_empty() { Space::new() } else {
          let v472_6: Path = concat_path(&(v469_6),&(v469_7_head));
          let v472_11: Space = routine_88(c, &(v472_6), &(*p1), &(v469_7_tail), &(*s1));
          drop(v472_6);
          compose(&(v470_10),&(v472_11))
        };
        drop(v470_10);
        let v470_13: Space = unite(&(v470_8),&(v470_12));
        v469_7.join_into((v470_13).clone());
      }
      drop(v469_7_cursor);
      compose(&(v468_5),&(v469_7))
    };
    drop(v468_5);
    let v468_9: Space = intersect(&(*CONSTANT_3),&(v468_2));
    drop(v468_2);
    let v468_10: Space = if has_head(&(v468_9)) { singleton(&[]) } else { Space::new() };
    drop(v468_9);
    let v468_12: Space = if (v468_10).is_empty() { Space::new() } else {
      let v473_6: Path = concat_path(&(*p0),&(v467_13_head));
      let mut v473_11 = Space::new();
      let mut v473_11_cursor = (v467_13_tail).read_zipper();
      for v473_11_byte in v473_11_cursor.child_mask().iter() {
        v473_11_cursor.descend_to_byte(v473_11_byte);
        let v473_11_tail = v473_11_cursor.make_map();
        v473_11_cursor.ascend(1);
        let v473_11_head = Path::from_slice(&[v473_11_byte]);
        let v474_2: Space = singleton(&(v473_11_head));
        let v474_3: Space = intersect(&(*CONSTANT_3),&(v474_2));
        let v474_4: Space = if has_head(&(v474_3)) { singleton(&[]) } else { Space::new() };
        drop(v474_3);
        let v474_5: Space = subtract(&(*CONSTANT_2),&(v474_4));
        drop(v474_4);
        let v474_8: Space = if (v474_5).is_empty() { Space::new() } else {
          let v475_6: Path = concat_path(&(v473_6),&(v473_11_head));
          let v475_7: Space = routine_87(c, &(v475_6), &(*p1), &(v473_11_tail), &(*s1));
          compose(&(v474_5),&(v475_7))
        };
        drop(v474_5);
        let v474_9: Space = intersect(&(*CONSTANT_3),&(v474_2));
        drop(v474_2);
        let v474_10: Space = if has_head(&(v474_9)) { singleton(&[]) } else { Space::new() };
        drop(v474_9);
        let v474_12: Space = if (v474_10).is_empty() { Space::new() } else {
          let v476_6: Path = concat_path(&(v473_6),&(v473_11_head));
          let v476_11: Space = routine_50(c, &(v476_6), &(*p1), &(v473_11_tail), &(*s1));
          drop(v476_6);
          compose(&(v474_10),&(v476_11))
        };
        drop(v474_10);
        let v474_13: Space = unite(&(v474_8),&(v474_12));
        v473_11.join_into((v474_13).clone());
      }
      drop(v473_11_cursor);
      drop(v473_6);
      compose(&(v468_10),&(v473_11))
    };
    drop(v468_10);
    let v468_13: Space = unite(&(v468_8),&(v468_12));
    v467_13.join_into((v468_13).clone());
  }
  drop(v467_13_cursor);
  (v467_13).clone()
}

fn routine_47(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v477_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v477_10: Space = unwrap(&(v477_8),&(*CONSTANT_5));
  drop(v477_8);
  let v477_11: Space = unwrap(&(v477_10),&(*p0));
  drop(v477_10);
  let mut v477_18 = Space::new();
  let mut v477_18_cursor = (*s0).read_zipper();
  for v477_18_byte in v477_18_cursor.child_mask().iter() {
    v477_18_cursor.descend_to_byte(v477_18_byte);
    let v477_18_tail = v477_18_cursor.make_map();
    v477_18_cursor.ascend(1);
    let v477_18_head = Path::from_slice(&[v477_18_byte]);
    let v478_2: Space = singleton(&(v477_18_head));
    let v478_3: Space = intersect(&(*CONSTANT_3),&(v478_2));
    let v478_4: Space = if has_head(&(v478_3)) { singleton(&[]) } else { Space::new() };
    drop(v478_3);
    let v478_5: Space = subtract(&(*CONSTANT_2),&(v478_4));
    drop(v478_4);
    let v478_8: Space = if (v478_5).is_empty() { Space::new() } else {
      let v479_6: Path = concat_path(&(*p0),&(v477_18_head));
      let mut v479_7 = Space::new();
      let mut v479_7_cursor = (v477_18_tail).read_zipper();
      for v479_7_byte in v479_7_cursor.child_mask().iter() {
        v479_7_cursor.descend_to_byte(v479_7_byte);
        let v479_7_tail = v479_7_cursor.make_map();
        v479_7_cursor.ascend(1);
        let v479_7_head = Path::from_slice(&[v479_7_byte]);
        let v480_2: Space = singleton(&(v479_7_head));
        let v480_3: Space = intersect(&(*CONSTANT_3),&(v480_2));
        let v480_4: Space = if has_head(&(v480_3)) { singleton(&[]) } else { Space::new() };
        drop(v480_3);
        let v480_5: Space = subtract(&(*CONSTANT_2),&(v480_4));
        drop(v480_4);
        let v480_8: Space = if (v480_5).is_empty() { Space::new() } else {
          let v481_6: Path = concat_path(&(v479_6),&(v479_7_head));
          let v481_7: Space = routine_87(c, &(v481_6), &(*p1), &(v479_7_tail), &(*s1));
          compose(&(v480_5),&(v481_7))
        };
        drop(v480_5);
        let v480_9: Space = intersect(&(*CONSTANT_3),&(v480_2));
        drop(v480_2);
        let v480_10: Space = if has_head(&(v480_9)) { singleton(&[]) } else { Space::new() };
        drop(v480_9);
        let v480_12: Space = if (v480_10).is_empty() { Space::new() } else {
          let v482_6: Path = concat_path(&(v479_6),&(v479_7_head));
          let v482_11: Space = routine_88(c, &(v482_6), &(*p1), &(v479_7_tail), &(*s1));
          drop(v482_6);
          compose(&(v480_10),&(v482_11))
        };
        drop(v480_10);
        let v480_13: Space = unite(&(v480_8),&(v480_12));
        v479_7.join_into((v480_13).clone());
      }
      drop(v479_7_cursor);
      drop(v479_6);
      compose(&(v478_5),&(v479_7))
    };
    drop(v478_5);
    let v478_9: Space = intersect(&(*CONSTANT_3),&(v478_2));
    drop(v478_2);
    let v478_10: Space = if has_head(&(v478_9)) { singleton(&[]) } else { Space::new() };
    drop(v478_9);
    let v478_13: Space = if (v478_10).is_empty() { Space::new() } else {
      let v483_11: Space = unwrap(&(v477_11),&(v477_18_head));
      let mut v483_12 = Space::new();
      let mut v483_12_cursor = (v483_11).read_zipper();
      for v483_12_byte in v483_12_cursor.child_mask().iter() {
        v483_12_cursor.descend_to_byte(v483_12_byte);
        let v483_12_tail = v483_12_cursor.make_map();
        v483_12_cursor.ascend(1);
        let v483_12_head = Path::from_slice(&[v483_12_byte]);
        let v484_2: Space = singleton(&(v483_12_head));
        let v484_3: Space = intersect(&(*CONSTANT_3),&(v484_2));
        let v484_4: Space = if has_head(&(v484_3)) { singleton(&[]) } else { Space::new() };
        drop(v484_3);
        let v484_5: Space = subtract(&(*CONSTANT_2),&(v484_4));
        drop(v484_4);
        let v484_7: Space = if (v484_5).is_empty() { Space::new() } else {
          let v485_6: Space = routine_89(c, &(v483_12_head), &(*p1), &(v483_12_tail));
          compose(&(v484_5),&(v485_6))
        };
        drop(v484_5);
        let v484_8: Space = intersect(&(*CONSTANT_3),&(v484_2));
        drop(v484_2);
        let v484_9: Space = if has_head(&(v484_8)) { singleton(&[]) } else { Space::new() };
        drop(v484_8);
        let v484_11: Space = if (v484_9).is_empty() { Space::new() } else {
          let v486_10: Space = routine_90(c, &(v483_12_head), &(*p1), &(v483_12_tail));
          compose(&(v484_9),&(v486_10))
        };
        drop(v484_9);
        let v484_12: Space = unite(&(v484_7),&(v484_11));
        v483_12.join_into((v484_12).clone());
      }
      drop(v483_12_cursor);
      drop(v483_11);
      compose(&(v478_10),&(v483_12))
    };
    drop(v478_10);
    let v478_14: Space = unite(&(v478_8),&(v478_13));
    v477_18.join_into((v478_14).clone());
  }
  drop(v477_18_cursor);
  drop(v477_11);
  (v477_18).clone()
}

fn routine_48(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v487_13 = Space::new();
  let mut v487_13_cursor = (*s0).read_zipper();
  for v487_13_byte in v487_13_cursor.child_mask().iter() {
    v487_13_cursor.descend_to_byte(v487_13_byte);
    let v487_13_tail = v487_13_cursor.make_map();
    v487_13_cursor.ascend(1);
    let v487_13_head = Path::from_slice(&[v487_13_byte]);
    let v488_2: Space = singleton(&(v487_13_head));
    let v488_3: Space = intersect(&(*CONSTANT_3),&(v488_2));
    let v488_4: Space = if has_head(&(v488_3)) { singleton(&[]) } else { Space::new() };
    drop(v488_3);
    let v488_5: Space = subtract(&(*CONSTANT_2),&(v488_4));
    drop(v488_4);
    let v488_8: Space = if (v488_5).is_empty() { Space::new() } else {
      let v489_6: Path = concat_path(&(*p0),&(v487_13_head));
      let mut v489_7 = Space::new();
      let mut v489_7_cursor = (v487_13_tail).read_zipper();
      for v489_7_byte in v489_7_cursor.child_mask().iter() {
        v489_7_cursor.descend_to_byte(v489_7_byte);
        let v489_7_tail = v489_7_cursor.make_map();
        v489_7_cursor.ascend(1);
        let v489_7_head = Path::from_slice(&[v489_7_byte]);
        let v490_2: Space = singleton(&(v489_7_head));
        let v490_3: Space = intersect(&(*CONSTANT_3),&(v490_2));
        let v490_4: Space = if has_head(&(v490_3)) { singleton(&[]) } else { Space::new() };
        drop(v490_3);
        let v490_5: Space = subtract(&(*CONSTANT_2),&(v490_4));
        drop(v490_4);
        let v490_8: Space = if (v490_5).is_empty() { Space::new() } else {
          let v491_6: Path = concat_path(&(v489_6),&(v489_7_head));
          let v491_7: Space = routine_91(c, &(v491_6), &(*p1), &(v489_7_tail), &(*s1));
          compose(&(v490_5),&(v491_7))
        };
        drop(v490_5);
        let v490_9: Space = intersect(&(*CONSTANT_3),&(v490_2));
        drop(v490_2);
        let v490_10: Space = if has_head(&(v490_9)) { singleton(&[]) } else { Space::new() };
        drop(v490_9);
        let v490_12: Space = if (v490_10).is_empty() { Space::new() } else {
          let v492_6: Path = concat_path(&(v489_6),&(v489_7_head));
          let v492_11: Space = routine_92(c, &(v492_6), &(*p1), &(v489_7_tail), &(*s1));
          drop(v492_6);
          compose(&(v490_10),&(v492_11))
        };
        drop(v490_10);
        let v490_13: Space = unite(&(v490_8),&(v490_12));
        v489_7.join_into((v490_13).clone());
      }
      drop(v489_7_cursor);
      compose(&(v488_5),&(v489_7))
    };
    drop(v488_5);
    let v488_9: Space = intersect(&(*CONSTANT_3),&(v488_2));
    drop(v488_2);
    let v488_10: Space = if has_head(&(v488_9)) { singleton(&[]) } else { Space::new() };
    drop(v488_9);
    let v488_12: Space = if (v488_10).is_empty() { Space::new() } else {
      let v493_6: Path = concat_path(&(*p0),&(v487_13_head));
      let mut v493_11 = Space::new();
      let mut v493_11_cursor = (v487_13_tail).read_zipper();
      for v493_11_byte in v493_11_cursor.child_mask().iter() {
        v493_11_cursor.descend_to_byte(v493_11_byte);
        let v493_11_tail = v493_11_cursor.make_map();
        v493_11_cursor.ascend(1);
        let v493_11_head = Path::from_slice(&[v493_11_byte]);
        let v494_2: Space = singleton(&(v493_11_head));
        let v494_3: Space = intersect(&(*CONSTANT_3),&(v494_2));
        let v494_4: Space = if has_head(&(v494_3)) { singleton(&[]) } else { Space::new() };
        drop(v494_3);
        let v494_5: Space = subtract(&(*CONSTANT_2),&(v494_4));
        drop(v494_4);
        let v494_8: Space = if (v494_5).is_empty() { Space::new() } else {
          let v495_6: Path = concat_path(&(v493_6),&(v493_11_head));
          let v495_7: Space = routine_91(c, &(v495_6), &(*p1), &(v493_11_tail), &(*s1));
          compose(&(v494_5),&(v495_7))
        };
        drop(v494_5);
        let v494_9: Space = intersect(&(*CONSTANT_3),&(v494_2));
        drop(v494_2);
        let v494_10: Space = if has_head(&(v494_9)) { singleton(&[]) } else { Space::new() };
        drop(v494_9);
        let v494_12: Space = if (v494_10).is_empty() { Space::new() } else {
          let v496_6: Path = concat_path(&(v493_6),&(v493_11_head));
          let v496_11: Space = routine_50(c, &(v496_6), &(*p1), &(v493_11_tail), &(*s1));
          drop(v496_6);
          compose(&(v494_10),&(v496_11))
        };
        drop(v494_10);
        let v494_13: Space = unite(&(v494_8),&(v494_12));
        v493_11.join_into((v494_13).clone());
      }
      drop(v493_11_cursor);
      drop(v493_6);
      compose(&(v488_10),&(v493_11))
    };
    drop(v488_10);
    let v488_13: Space = unite(&(v488_8),&(v488_12));
    v487_13.join_into((v488_13).clone());
  }
  drop(v487_13_cursor);
  (v487_13).clone()
}

fn routine_49(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v497_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v497_10: Space = unwrap(&(v497_8),&(*CONSTANT_5));
  drop(v497_8);
  let v497_11: Space = unwrap(&(v497_10),&(*p0));
  drop(v497_10);
  let mut v497_18 = Space::new();
  let mut v497_18_cursor = (*s0).read_zipper();
  for v497_18_byte in v497_18_cursor.child_mask().iter() {
    v497_18_cursor.descend_to_byte(v497_18_byte);
    let v497_18_tail = v497_18_cursor.make_map();
    v497_18_cursor.ascend(1);
    let v497_18_head = Path::from_slice(&[v497_18_byte]);
    let v498_2: Space = singleton(&(v497_18_head));
    let v498_3: Space = intersect(&(*CONSTANT_3),&(v498_2));
    let v498_4: Space = if has_head(&(v498_3)) { singleton(&[]) } else { Space::new() };
    drop(v498_3);
    let v498_5: Space = subtract(&(*CONSTANT_2),&(v498_4));
    drop(v498_4);
    let v498_8: Space = if (v498_5).is_empty() { Space::new() } else {
      let v499_6: Path = concat_path(&(*p0),&(v497_18_head));
      let mut v499_7 = Space::new();
      let mut v499_7_cursor = (v497_18_tail).read_zipper();
      for v499_7_byte in v499_7_cursor.child_mask().iter() {
        v499_7_cursor.descend_to_byte(v499_7_byte);
        let v499_7_tail = v499_7_cursor.make_map();
        v499_7_cursor.ascend(1);
        let v499_7_head = Path::from_slice(&[v499_7_byte]);
        let v500_2: Space = singleton(&(v499_7_head));
        let v500_3: Space = intersect(&(*CONSTANT_3),&(v500_2));
        let v500_4: Space = if has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
        drop(v500_3);
        let v500_5: Space = subtract(&(*CONSTANT_2),&(v500_4));
        drop(v500_4);
        let v500_8: Space = if (v500_5).is_empty() { Space::new() } else {
          let v501_6: Path = concat_path(&(v499_6),&(v499_7_head));
          let v501_7: Space = routine_91(c, &(v501_6), &(*p1), &(v499_7_tail), &(*s1));
          compose(&(v500_5),&(v501_7))
        };
        drop(v500_5);
        let v500_9: Space = intersect(&(*CONSTANT_3),&(v500_2));
        drop(v500_2);
        let v500_10: Space = if has_head(&(v500_9)) { singleton(&[]) } else { Space::new() };
        drop(v500_9);
        let v500_12: Space = if (v500_10).is_empty() { Space::new() } else {
          let v502_6: Path = concat_path(&(v499_6),&(v499_7_head));
          let v502_11: Space = routine_92(c, &(v502_6), &(*p1), &(v499_7_tail), &(*s1));
          drop(v502_6);
          compose(&(v500_10),&(v502_11))
        };
        drop(v500_10);
        let v500_13: Space = unite(&(v500_8),&(v500_12));
        v499_7.join_into((v500_13).clone());
      }
      drop(v499_7_cursor);
      drop(v499_6);
      compose(&(v498_5),&(v499_7))
    };
    drop(v498_5);
    let v498_9: Space = intersect(&(*CONSTANT_3),&(v498_2));
    drop(v498_2);
    let v498_10: Space = if has_head(&(v498_9)) { singleton(&[]) } else { Space::new() };
    drop(v498_9);
    let v498_13: Space = if (v498_10).is_empty() { Space::new() } else {
      let v503_11: Space = unwrap(&(v497_11),&(v497_18_head));
      let mut v503_12 = Space::new();
      let mut v503_12_cursor = (v503_11).read_zipper();
      for v503_12_byte in v503_12_cursor.child_mask().iter() {
        v503_12_cursor.descend_to_byte(v503_12_byte);
        let v503_12_tail = v503_12_cursor.make_map();
        v503_12_cursor.ascend(1);
        let v503_12_head = Path::from_slice(&[v503_12_byte]);
        let v504_2: Space = singleton(&(v503_12_head));
        let v504_3: Space = intersect(&(*CONSTANT_3),&(v504_2));
        let v504_4: Space = if has_head(&(v504_3)) { singleton(&[]) } else { Space::new() };
        drop(v504_3);
        let v504_5: Space = subtract(&(*CONSTANT_2),&(v504_4));
        drop(v504_4);
        let v504_7: Space = if (v504_5).is_empty() { Space::new() } else {
          let v505_6: Space = routine_89(c, &(v503_12_head), &(*p1), &(v503_12_tail));
          compose(&(v504_5),&(v505_6))
        };
        drop(v504_5);
        let v504_8: Space = intersect(&(*CONSTANT_3),&(v504_2));
        drop(v504_2);
        let v504_9: Space = if has_head(&(v504_8)) { singleton(&[]) } else { Space::new() };
        drop(v504_8);
        let v504_11: Space = if (v504_9).is_empty() { Space::new() } else {
          let v506_10: Space = routine_90(c, &(v503_12_head), &(*p1), &(v503_12_tail));
          compose(&(v504_9),&(v506_10))
        };
        drop(v504_9);
        let v504_12: Space = unite(&(v504_7),&(v504_11));
        v503_12.join_into((v504_12).clone());
      }
      drop(v503_12_cursor);
      drop(v503_11);
      compose(&(v498_10),&(v503_12))
    };
    drop(v498_10);
    let v498_14: Space = unite(&(v498_8),&(v498_13));
    v497_18.join_into((v498_14).clone());
  }
  drop(v497_18_cursor);
  drop(v497_11);
  (v497_18).clone()
}

fn routine_50(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v507_5: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v507_7: Space = unwrap(&(v507_5),&(*CONSTANT_5));
  drop(v507_5);
  let v507_8: Space = unwrap(&(v507_7),&(*p0));
  drop(v507_7);
  let mut v507_18 = Space::new();
  let mut v507_18_cursor = (v507_8).read_zipper();
  for v507_18_byte in v507_18_cursor.child_mask().iter() {
    v507_18_cursor.descend_to_byte(v507_18_byte);
    let v507_18_tail = v507_18_cursor.make_map();
    v507_18_cursor.ascend(1);
    let v507_18_head = Path::from_slice(&[v507_18_byte]);
    let v508_2: Space = singleton(&(v507_18_head));
    let v508_3: Space = intersect(&(*CONSTANT_3),&(v508_2));
    let v508_4: Space = if has_head(&(v508_3)) { singleton(&[]) } else { Space::new() };
    drop(v508_3);
    let v508_5: Space = subtract(&(*CONSTANT_2),&(v508_4));
    drop(v508_4);
    let v508_7: Space = if (v508_5).is_empty() { Space::new() } else {
      let mut v509_6 = Space::new();
      let mut v509_6_cursor = (v507_18_tail).read_zipper();
      for v509_6_byte in v509_6_cursor.child_mask().iter() {
        v509_6_cursor.descend_to_byte(v509_6_byte);
        let v509_6_tail = v509_6_cursor.make_map();
        v509_6_cursor.ascend(1);
        let v509_6_head = Path::from_slice(&[v509_6_byte]);
        let v510_2: Space = singleton(&(v509_6_head));
        let v510_3: Space = intersect(&(*CONSTANT_3),&(v510_2));
        let v510_4: Space = if has_head(&(v510_3)) { singleton(&[]) } else { Space::new() };
        drop(v510_3);
        let v510_5: Space = subtract(&(*CONSTANT_2),&(v510_4));
        drop(v510_4);
        let v510_8: Space = if (v510_5).is_empty() { Space::new() } else {
          let v511_6: Path = concat_path(&(v507_18_head),&(v509_6_head));
          let v511_7: Space = routine_93(c, &(v511_6), &(*p1), &(v509_6_tail));
          compose(&(v510_5),&(v511_7))
        };
        drop(v510_5);
        let v510_9: Space = intersect(&(*CONSTANT_3),&(v510_2));
        drop(v510_2);
        let v510_10: Space = if has_head(&(v510_9)) { singleton(&[]) } else { Space::new() };
        drop(v510_9);
        let v510_12: Space = if (v510_10).is_empty() { Space::new() } else {
          let v512_6: Path = concat_path(&(v507_18_head),&(v509_6_head));
          let v512_11: Space = routine_94(c, &(v512_6), &(*p1), &(v509_6_tail));
          drop(v512_6);
          compose(&(v510_10),&(v512_11))
        };
        drop(v510_10);
        let v510_13: Space = unite(&(v510_8),&(v510_12));
        v509_6.join_into((v510_13).clone());
      }
      drop(v509_6_cursor);
      compose(&(v508_5),&(v509_6))
    };
    drop(v508_5);
    let v508_8: Space = intersect(&(*CONSTANT_3),&(v508_2));
    drop(v508_2);
    let v508_9: Space = if has_head(&(v508_8)) { singleton(&[]) } else { Space::new() };
    drop(v508_8);
    let v508_11: Space = if (v508_9).is_empty() { Space::new() } else {
      let mut v513_10 = Space::new();
      let mut v513_10_cursor = (v507_18_tail).read_zipper();
      for v513_10_byte in v513_10_cursor.child_mask().iter() {
        v513_10_cursor.descend_to_byte(v513_10_byte);
        let v513_10_tail = v513_10_cursor.make_map();
        v513_10_cursor.ascend(1);
        let v513_10_head = Path::from_slice(&[v513_10_byte]);
        let v514_2: Space = singleton(&(v513_10_head));
        let v514_3: Space = intersect(&(*CONSTANT_3),&(v514_2));
        let v514_4: Space = if has_head(&(v514_3)) { singleton(&[]) } else { Space::new() };
        drop(v514_3);
        let v514_5: Space = subtract(&(*CONSTANT_2),&(v514_4));
        drop(v514_4);
        let v514_8: Space = if (v514_5).is_empty() { Space::new() } else {
          let v515_6: Path = concat_path(&(v507_18_head),&(v513_10_head));
          let v515_7: Space = routine_93(c, &(v515_6), &(*p1), &(v513_10_tail));
          compose(&(v514_5),&(v515_7))
        };
        drop(v514_5);
        let v514_9: Space = intersect(&(*CONSTANT_3),&(v514_2));
        drop(v514_2);
        let v514_10: Space = if has_head(&(v514_9)) { singleton(&[]) } else { Space::new() };
        drop(v514_9);
        let v514_12: Space = if (v514_10).is_empty() { Space::new() } else {
          let v516_6: Path = concat_path(&(v507_18_head),&(v513_10_head));
          let v516_11: Space = routine_95(c, &(v516_6), &(*p1), &(v513_10_tail));
          drop(v516_6);
          compose(&(v514_10),&(v516_11))
        };
        drop(v514_10);
        let v514_13: Space = unite(&(v514_8),&(v514_12));
        v513_10.join_into((v514_13).clone());
      }
      drop(v513_10_cursor);
      compose(&(v508_9),&(v513_10))
    };
    drop(v508_9);
    let v508_12: Space = unite(&(v508_7),&(v508_11));
    v507_18.join_into((v508_12).clone());
  }
  drop(v507_18_cursor);
  drop(v507_8);
  (v507_18).clone()
}

fn routine_51(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v517_11 = Space::new();
  let mut v517_11_cursor = (*s0).read_zipper();
  for v517_11_byte in v517_11_cursor.child_mask().iter() {
    v517_11_cursor.descend_to_byte(v517_11_byte);
    let v517_11_tail = v517_11_cursor.make_map();
    v517_11_cursor.ascend(1);
    let v517_11_head = Path::from_slice(&[v517_11_byte]);
    let v518_2: Space = singleton(&(v517_11_head));
    let v518_3: Space = intersect(&(*CONSTANT_3),&(v518_2));
    let v518_4: Space = if has_head(&(v518_3)) { singleton(&[]) } else { Space::new() };
    drop(v518_3);
    let v518_5: Space = subtract(&(*CONSTANT_2),&(v518_4));
    drop(v518_4);
    let v518_8: Space = if (v518_5).is_empty() { Space::new() } else {
      let v519_6: Path = concat_path(&(*p0),&(v517_11_head));
      let mut v519_7 = Space::new();
      let mut v519_7_cursor = (v517_11_tail).read_zipper();
      for v519_7_byte in v519_7_cursor.child_mask().iter() {
        v519_7_cursor.descend_to_byte(v519_7_byte);
        let v519_7_tail = v519_7_cursor.make_map();
        v519_7_cursor.ascend(1);
        let v519_7_head = Path::from_slice(&[v519_7_byte]);
        let v520_2: Space = singleton(&(v519_7_head));
        let v520_3: Space = intersect(&(*CONSTANT_3),&(v520_2));
        let v520_4: Space = if has_head(&(v520_3)) { singleton(&[]) } else { Space::new() };
        drop(v520_3);
        let v520_5: Space = subtract(&(*CONSTANT_2),&(v520_4));
        drop(v520_4);
        let v520_8: Space = if (v520_5).is_empty() { Space::new() } else {
          let v521_6: Path = concat_path(&(v519_6),&(v519_7_head));
          let v521_7: Space = routine_96(c, &(v521_6), &(v519_7_tail));
          compose(&(v520_5),&(v521_7))
        };
        drop(v520_5);
        let v520_9: Space = intersect(&(*CONSTANT_3),&(v520_2));
        drop(v520_2);
        let v520_10: Space = if has_head(&(v520_9)) { singleton(&[]) } else { Space::new() };
        drop(v520_9);
        let v520_12: Space = if (v520_10).is_empty() { Space::new() } else {
          let v522_6: Path = concat_path(&(v519_6),&(v519_7_head));
          let v522_11: Space = routine_97(c, &(v522_6), &(v519_7_tail));
          drop(v522_6);
          compose(&(v520_10),&(v522_11))
        };
        drop(v520_10);
        let v520_13: Space = unite(&(v520_8),&(v520_12));
        v519_7.join_into((v520_13).clone());
      }
      drop(v519_7_cursor);
      compose(&(v518_5),&(v519_7))
    };
    drop(v518_5);
    let v518_9: Space = intersect(&(*CONSTANT_3),&(v518_2));
    drop(v518_2);
    let v518_10: Space = if has_head(&(v518_9)) { singleton(&[]) } else { Space::new() };
    drop(v518_9);
    let v518_12: Space = if (v518_10).is_empty() { Space::new() } else {
      let v523_6: Path = concat_path(&(*p0),&(v517_11_head));
      let mut v523_11 = Space::new();
      let mut v523_11_cursor = (v517_11_tail).read_zipper();
      for v523_11_byte in v523_11_cursor.child_mask().iter() {
        v523_11_cursor.descend_to_byte(v523_11_byte);
        let v523_11_tail = v523_11_cursor.make_map();
        v523_11_cursor.ascend(1);
        let v523_11_head = Path::from_slice(&[v523_11_byte]);
        let v524_2: Space = singleton(&(v523_11_head));
        let v524_3: Space = intersect(&(*CONSTANT_3),&(v524_2));
        let v524_4: Space = if has_head(&(v524_3)) { singleton(&[]) } else { Space::new() };
        drop(v524_3);
        let v524_5: Space = subtract(&(*CONSTANT_2),&(v524_4));
        drop(v524_4);
        let v524_8: Space = if (v524_5).is_empty() { Space::new() } else {
          let v525_6: Path = concat_path(&(v523_6),&(v523_11_head));
          let v525_7: Space = routine_96(c, &(v525_6), &(v523_11_tail));
          compose(&(v524_5),&(v525_7))
        };
        drop(v524_5);
        let v524_9: Space = intersect(&(*CONSTANT_3),&(v524_2));
        drop(v524_2);
        let v524_10: Space = if has_head(&(v524_9)) { singleton(&[]) } else { Space::new() };
        drop(v524_9);
        let v524_12: Space = if (v524_10).is_empty() { Space::new() } else {
          let v526_6: Path = concat_path(&(v523_6),&(v523_11_head));
          let v526_11: Space = routine_3(c, &(v526_6), &(v523_11_tail));
          drop(v526_6);
          compose(&(v524_10),&(v526_11))
        };
        drop(v524_10);
        let v524_13: Space = unite(&(v524_8),&(v524_12));
        v523_11.join_into((v524_13).clone());
      }
      drop(v523_11_cursor);
      drop(v523_6);
      compose(&(v518_10),&(v523_11))
    };
    drop(v518_10);
    let v518_13: Space = unite(&(v518_8),&(v518_12));
    v517_11.join_into((v518_13).clone());
  }
  drop(v517_11_cursor);
  (v517_11).clone()
}

fn routine_52(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v527_11 = Space::new();
  let mut v527_11_cursor = (*s0).read_zipper();
  for v527_11_byte in v527_11_cursor.child_mask().iter() {
    v527_11_cursor.descend_to_byte(v527_11_byte);
    let v527_11_tail = v527_11_cursor.make_map();
    v527_11_cursor.ascend(1);
    let v527_11_head = Path::from_slice(&[v527_11_byte]);
    let v528_2: Space = singleton(&(v527_11_head));
    let v528_3: Space = intersect(&(*CONSTANT_3),&(v528_2));
    let v528_4: Space = if has_head(&(v528_3)) { singleton(&[]) } else { Space::new() };
    drop(v528_3);
    let v528_5: Space = subtract(&(*CONSTANT_2),&(v528_4));
    drop(v528_4);
    let v528_8: Space = if (v528_5).is_empty() { Space::new() } else {
      let v529_6: Path = concat_path(&(*p0),&(v527_11_head));
      let mut v529_7 = Space::new();
      let mut v529_7_cursor = (v527_11_tail).read_zipper();
      for v529_7_byte in v529_7_cursor.child_mask().iter() {
        v529_7_cursor.descend_to_byte(v529_7_byte);
        let v529_7_tail = v529_7_cursor.make_map();
        v529_7_cursor.ascend(1);
        let v529_7_head = Path::from_slice(&[v529_7_byte]);
        let v530_2: Space = singleton(&(v529_7_head));
        let v530_3: Space = intersect(&(*CONSTANT_3),&(v530_2));
        let v530_4: Space = if has_head(&(v530_3)) { singleton(&[]) } else { Space::new() };
        drop(v530_3);
        let v530_5: Space = subtract(&(*CONSTANT_2),&(v530_4));
        drop(v530_4);
        let v530_8: Space = if (v530_5).is_empty() { Space::new() } else {
          let v531_6: Path = concat_path(&(v529_6),&(v529_7_head));
          let v531_7: Space = routine_96(c, &(v531_6), &(v529_7_tail));
          compose(&(v530_5),&(v531_7))
        };
        drop(v530_5);
        let v530_9: Space = intersect(&(*CONSTANT_3),&(v530_2));
        drop(v530_2);
        let v530_10: Space = if has_head(&(v530_9)) { singleton(&[]) } else { Space::new() };
        drop(v530_9);
        let v530_12: Space = if (v530_10).is_empty() { Space::new() } else {
          let v532_6: Path = concat_path(&(v529_6),&(v529_7_head));
          let v532_11: Space = routine_97(c, &(v532_6), &(v529_7_tail));
          drop(v532_6);
          compose(&(v530_10),&(v532_11))
        };
        drop(v530_10);
        let v530_13: Space = unite(&(v530_8),&(v530_12));
        v529_7.join_into((v530_13).clone());
      }
      drop(v529_7_cursor);
      compose(&(v528_5),&(v529_7))
    };
    drop(v528_5);
    let v528_9: Space = intersect(&(*CONSTANT_3),&(v528_2));
    drop(v528_2);
    let v528_10: Space = if has_head(&(v528_9)) { singleton(&[]) } else { Space::new() };
    drop(v528_9);
    let v528_12: Space = if (v528_10).is_empty() { Space::new() } else {
      let v533_6: Path = concat_path(&(*p0),&(v527_11_head));
      let mut v533_11 = Space::new();
      let mut v533_11_cursor = (v527_11_tail).read_zipper();
      for v533_11_byte in v533_11_cursor.child_mask().iter() {
        v533_11_cursor.descend_to_byte(v533_11_byte);
        let v533_11_tail = v533_11_cursor.make_map();
        v533_11_cursor.ascend(1);
        let v533_11_head = Path::from_slice(&[v533_11_byte]);
        let v534_2: Space = singleton(&(v533_11_head));
        let v534_3: Space = intersect(&(*CONSTANT_3),&(v534_2));
        let v534_4: Space = if has_head(&(v534_3)) { singleton(&[]) } else { Space::new() };
        drop(v534_3);
        let v534_5: Space = subtract(&(*CONSTANT_2),&(v534_4));
        drop(v534_4);
        let v534_7: Space = if (v534_5).is_empty() { Space::new() } else {
          let v535_6: Space = routine_18(c, &(v533_11_head), &(v533_6), &(v533_11_tail));
          compose(&(v534_5),&(v535_6))
        };
        drop(v534_5);
        let v534_8: Space = intersect(&(*CONSTANT_3),&(v534_2));
        drop(v534_2);
        let v534_9: Space = if has_head(&(v534_8)) { singleton(&[]) } else { Space::new() };
        drop(v534_8);
        let v534_11: Space = if (v534_9).is_empty() { Space::new() } else {
          let v536_10: Space = routine_19(c, &(v533_11_head), &(v533_6), &(v533_11_tail));
          compose(&(v534_9),&(v536_10))
        };
        drop(v534_9);
        let v534_12: Space = unite(&(v534_7),&(v534_11));
        v533_11.join_into((v534_12).clone());
      }
      drop(v533_11_cursor);
      drop(v533_6);
      compose(&(v528_10),&(v533_11))
    };
    drop(v528_10);
    let v528_13: Space = unite(&(v528_8),&(v528_12));
    v527_11.join_into((v528_13).clone());
  }
  drop(v527_11_cursor);
  (v527_11).clone()
}

fn routine_53(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v537_12 = Space::new();
  let mut v537_12_cursor = (*s0).read_zipper();
  for v537_12_byte in v537_12_cursor.child_mask().iter() {
    v537_12_cursor.descend_to_byte(v537_12_byte);
    let v537_12_tail = v537_12_cursor.make_map();
    v537_12_cursor.ascend(1);
    let v537_12_head = Path::from_slice(&[v537_12_byte]);
    let v538_2: Space = singleton(&(v537_12_head));
    let v538_3: Space = intersect(&(*CONSTANT_3),&(v538_2));
    let v538_4: Space = if has_head(&(v538_3)) { singleton(&[]) } else { Space::new() };
    drop(v538_3);
    let v538_5: Space = subtract(&(*CONSTANT_2),&(v538_4));
    drop(v538_4);
    let v538_8: Space = if (v538_5).is_empty() { Space::new() } else {
      let v539_6: Path = concat_path(&(*p0),&(v537_12_head));
      let mut v539_7 = Space::new();
      let mut v539_7_cursor = (v537_12_tail).read_zipper();
      for v539_7_byte in v539_7_cursor.child_mask().iter() {
        v539_7_cursor.descend_to_byte(v539_7_byte);
        let v539_7_tail = v539_7_cursor.make_map();
        v539_7_cursor.ascend(1);
        let v539_7_head = Path::from_slice(&[v539_7_byte]);
        let v540_2: Space = singleton(&(v539_7_head));
        let v540_3: Space = intersect(&(*CONSTANT_3),&(v540_2));
        let v540_4: Space = if has_head(&(v540_3)) { singleton(&[]) } else { Space::new() };
        drop(v540_3);
        let v540_5: Space = subtract(&(*CONSTANT_2),&(v540_4));
        drop(v540_4);
        let v540_8: Space = if (v540_5).is_empty() { Space::new() } else {
          let v541_6: Path = concat_path(&(v539_6),&(v539_7_head));
          let v541_7: Space = routine_98(c, &(v541_6), &(*p1), &(v539_7_tail));
          compose(&(v540_5),&(v541_7))
        };
        drop(v540_5);
        let v540_9: Space = intersect(&(*CONSTANT_3),&(v540_2));
        drop(v540_2);
        let v540_10: Space = if has_head(&(v540_9)) { singleton(&[]) } else { Space::new() };
        drop(v540_9);
        let v540_12: Space = if (v540_10).is_empty() { Space::new() } else {
          let v542_6: Path = concat_path(&(v539_6),&(v539_7_head));
          let v542_11: Space = routine_99(c, &(v542_6), &(*p1), &(v539_7_tail));
          drop(v542_6);
          compose(&(v540_10),&(v542_11))
        };
        drop(v540_10);
        let v540_13: Space = unite(&(v540_8),&(v540_12));
        v539_7.join_into((v540_13).clone());
      }
      drop(v539_7_cursor);
      compose(&(v538_5),&(v539_7))
    };
    drop(v538_5);
    let v538_9: Space = intersect(&(*CONSTANT_3),&(v538_2));
    drop(v538_2);
    let v538_10: Space = if has_head(&(v538_9)) { singleton(&[]) } else { Space::new() };
    drop(v538_9);
    let v538_12: Space = if (v538_10).is_empty() { Space::new() } else {
      let v543_6: Path = concat_path(&(*p0),&(v537_12_head));
      let mut v543_11 = Space::new();
      let mut v543_11_cursor = (v537_12_tail).read_zipper();
      for v543_11_byte in v543_11_cursor.child_mask().iter() {
        v543_11_cursor.descend_to_byte(v543_11_byte);
        let v543_11_tail = v543_11_cursor.make_map();
        v543_11_cursor.ascend(1);
        let v543_11_head = Path::from_slice(&[v543_11_byte]);
        let v544_2: Space = singleton(&(v543_11_head));
        let v544_3: Space = intersect(&(*CONSTANT_3),&(v544_2));
        let v544_4: Space = if has_head(&(v544_3)) { singleton(&[]) } else { Space::new() };
        drop(v544_3);
        let v544_5: Space = subtract(&(*CONSTANT_2),&(v544_4));
        drop(v544_4);
        let v544_8: Space = if (v544_5).is_empty() { Space::new() } else {
          let v545_6: Path = concat_path(&(v543_6),&(v543_11_head));
          let v545_7: Space = routine_98(c, &(v545_6), &(*p1), &(v543_11_tail));
          compose(&(v544_5),&(v545_7))
        };
        drop(v544_5);
        let v544_9: Space = intersect(&(*CONSTANT_3),&(v544_2));
        drop(v544_2);
        let v544_10: Space = if has_head(&(v544_9)) { singleton(&[]) } else { Space::new() };
        drop(v544_9);
        let v544_12: Space = if (v544_10).is_empty() { Space::new() } else {
          let v546_6: Path = concat_path(&(v543_6),&(v543_11_head));
          let v546_11: Space = routine_22(c, &(v546_6), &(*p1), &(v543_11_tail));
          drop(v546_6);
          compose(&(v544_10),&(v546_11))
        };
        drop(v544_10);
        let v544_13: Space = unite(&(v544_8),&(v544_12));
        v543_11.join_into((v544_13).clone());
      }
      drop(v543_11_cursor);
      drop(v543_6);
      compose(&(v538_10),&(v543_11))
    };
    drop(v538_10);
    let v538_13: Space = unite(&(v538_8),&(v538_12));
    v537_12.join_into((v538_13).clone());
  }
  drop(v537_12_cursor);
  (v537_12).clone()
}

fn routine_54(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v547_10 = Space::new();
  let mut v547_10_cursor = (*s0).read_zipper();
  for v547_10_byte in v547_10_cursor.child_mask().iter() {
    v547_10_cursor.descend_to_byte(v547_10_byte);
    let v547_10_tail = v547_10_cursor.make_map();
    v547_10_cursor.ascend(1);
    let v547_10_head = Path::from_slice(&[v547_10_byte]);
    let v548_2: Space = singleton(&(v547_10_head));
    let v548_3: Space = intersect(&(*CONSTANT_3),&(v548_2));
    let v548_4: Space = if has_head(&(v548_3)) { singleton(&[]) } else { Space::new() };
    drop(v548_3);
    let v548_5: Space = compose(&(v548_4),&(v547_10_tail));
    drop(v548_4);
    let v549_6: Path = concat_path(&(*p0),&(v547_10_head));
    let v548_7: Space = wrap(&(v548_5),&(v549_6));
    drop(v548_5);
    let v548_8: Space = wrap(&(v548_7),&(*p1));
    drop(v548_7);
    let v548_9: Space = wrap(&(v548_8),&(*CONSTANT_5));
    drop(v548_8);
    let v548_10: Space = intersect(&(*CONSTANT_3),&(v548_2));
    drop(v548_2);
    let v548_11: Space = if has_head(&(v548_10)) { singleton(&[]) } else { Space::new() };
    drop(v548_10);
    let v548_12: Space = subtract(&(*CONSTANT_2),&(v548_11));
    drop(v548_11);
    let v548_14: Space = if (v548_12).is_empty() { Space::new() } else {
      let mut v550_13 = Space::new();
      let mut v550_13_cursor = (v547_10_tail).read_zipper();
      for v550_13_byte in v550_13_cursor.child_mask().iter() {
        v550_13_cursor.descend_to_byte(v550_13_byte);
        let v550_13_tail = v550_13_cursor.make_map();
        v550_13_cursor.ascend(1);
        let v550_13_head = Path::from_slice(&[v550_13_byte]);
        let v551_2: Space = singleton(&(v550_13_head));
        let v551_3: Space = intersect(&(*CONSTANT_3),&(v551_2));
        let v551_4: Space = if has_head(&(v551_3)) { singleton(&[]) } else { Space::new() };
        drop(v551_3);
        let v551_5: Space = subtract(&(*CONSTANT_2),&(v551_4));
        drop(v551_4);
        let v551_8: Space = if (v551_5).is_empty() { Space::new() } else {
          let v552_6: Path = concat_path(&(v549_6),&(v550_13_head));
          let v552_7: Space = routine_98(c, &(v552_6), &(*p1), &(v550_13_tail));
          compose(&(v551_5),&(v552_7))
        };
        drop(v551_5);
        let v551_9: Space = intersect(&(*CONSTANT_3),&(v551_2));
        drop(v551_2);
        let v551_10: Space = if has_head(&(v551_9)) { singleton(&[]) } else { Space::new() };
        drop(v551_9);
        let v551_12: Space = if (v551_10).is_empty() { Space::new() } else {
          let v553_6: Path = concat_path(&(v549_6),&(v550_13_head));
          let v553_11: Space = routine_99(c, &(v553_6), &(*p1), &(v550_13_tail));
          drop(v553_6);
          compose(&(v551_10),&(v553_11))
        };
        drop(v551_10);
        let v551_13: Space = unite(&(v551_8),&(v551_12));
        v550_13.join_into((v551_13).clone());
      }
      drop(v550_13_cursor);
      compose(&(v548_12),&(v550_13))
    };
    drop(v548_12);
    let v548_15: Space = unite(&(v548_9),&(v548_14));
    drop(v548_9);
    v547_10.join_into((v548_15).clone());
  }
  drop(v547_10_cursor);
  (v547_10).clone()
}

fn routine_55(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v554_12 = Space::new();
  let mut v554_12_cursor = (*s0).read_zipper();
  for v554_12_byte in v554_12_cursor.child_mask().iter() {
    v554_12_cursor.descend_to_byte(v554_12_byte);
    let v554_12_tail = v554_12_cursor.make_map();
    v554_12_cursor.ascend(1);
    let v554_12_head = Path::from_slice(&[v554_12_byte]);
    let v555_2: Space = singleton(&(v554_12_head));
    let v555_3: Space = intersect(&(*CONSTANT_3),&(v555_2));
    let v555_4: Space = if has_head(&(v555_3)) { singleton(&[]) } else { Space::new() };
    drop(v555_3);
    let v555_5: Space = subtract(&(*CONSTANT_2),&(v555_4));
    drop(v555_4);
    let v555_8: Space = if (v555_5).is_empty() { Space::new() } else {
      let v556_6: Path = concat_path(&(*p0),&(v554_12_head));
      let mut v556_7 = Space::new();
      let mut v556_7_cursor = (v554_12_tail).read_zipper();
      for v556_7_byte in v556_7_cursor.child_mask().iter() {
        v556_7_cursor.descend_to_byte(v556_7_byte);
        let v556_7_tail = v556_7_cursor.make_map();
        v556_7_cursor.ascend(1);
        let v556_7_head = Path::from_slice(&[v556_7_byte]);
        let v557_2: Space = singleton(&(v556_7_head));
        let v557_3: Space = intersect(&(*CONSTANT_3),&(v557_2));
        let v557_4: Space = if has_head(&(v557_3)) { singleton(&[]) } else { Space::new() };
        drop(v557_3);
        let v557_5: Space = subtract(&(*CONSTANT_2),&(v557_4));
        drop(v557_4);
        let v557_8: Space = if (v557_5).is_empty() { Space::new() } else {
          let v558_6: Path = concat_path(&(v556_6),&(v556_7_head));
          let v558_7: Space = routine_100(c, &(v558_6), &(*p1), &(v556_7_tail));
          compose(&(v557_5),&(v558_7))
        };
        drop(v557_5);
        let v557_9: Space = intersect(&(*CONSTANT_3),&(v557_2));
        drop(v557_2);
        let v557_10: Space = if has_head(&(v557_9)) { singleton(&[]) } else { Space::new() };
        drop(v557_9);
        let v557_12: Space = if (v557_10).is_empty() { Space::new() } else {
          let v559_6: Path = concat_path(&(v556_6),&(v556_7_head));
          let v559_11: Space = routine_101(c, &(v559_6), &(*p1), &(v556_7_tail));
          drop(v559_6);
          compose(&(v557_10),&(v559_11))
        };
        drop(v557_10);
        let v557_13: Space = unite(&(v557_8),&(v557_12));
        v556_7.join_into((v557_13).clone());
      }
      drop(v556_7_cursor);
      compose(&(v555_5),&(v556_7))
    };
    drop(v555_5);
    let v555_9: Space = intersect(&(*CONSTANT_3),&(v555_2));
    drop(v555_2);
    let v555_10: Space = if has_head(&(v555_9)) { singleton(&[]) } else { Space::new() };
    drop(v555_9);
    let v555_12: Space = if (v555_10).is_empty() { Space::new() } else {
      let v560_6: Path = concat_path(&(*p0),&(v554_12_head));
      let mut v560_11 = Space::new();
      let mut v560_11_cursor = (v554_12_tail).read_zipper();
      for v560_11_byte in v560_11_cursor.child_mask().iter() {
        v560_11_cursor.descend_to_byte(v560_11_byte);
        let v560_11_tail = v560_11_cursor.make_map();
        v560_11_cursor.ascend(1);
        let v560_11_head = Path::from_slice(&[v560_11_byte]);
        let v561_2: Space = singleton(&(v560_11_head));
        let v561_3: Space = intersect(&(*CONSTANT_3),&(v561_2));
        let v561_4: Space = if has_head(&(v561_3)) { singleton(&[]) } else { Space::new() };
        drop(v561_3);
        let v561_5: Space = subtract(&(*CONSTANT_2),&(v561_4));
        drop(v561_4);
        let v561_8: Space = if (v561_5).is_empty() { Space::new() } else {
          let v562_6: Path = concat_path(&(v560_6),&(v560_11_head));
          let v562_7: Space = routine_100(c, &(v562_6), &(*p1), &(v560_11_tail));
          compose(&(v561_5),&(v562_7))
        };
        drop(v561_5);
        let v561_9: Space = intersect(&(*CONSTANT_3),&(v561_2));
        drop(v561_2);
        let v561_10: Space = if has_head(&(v561_9)) { singleton(&[]) } else { Space::new() };
        drop(v561_9);
        let v561_12: Space = if (v561_10).is_empty() { Space::new() } else {
          let v563_6: Path = concat_path(&(v560_6),&(v560_11_head));
          let v563_11: Space = routine_22(c, &(v563_6), &(*p1), &(v560_11_tail));
          drop(v563_6);
          compose(&(v561_10),&(v563_11))
        };
        drop(v561_10);
        let v561_13: Space = unite(&(v561_8),&(v561_12));
        v560_11.join_into((v561_13).clone());
      }
      drop(v560_11_cursor);
      drop(v560_6);
      compose(&(v555_10),&(v560_11))
    };
    drop(v555_10);
    let v555_13: Space = unite(&(v555_8),&(v555_12));
    v554_12.join_into((v555_13).clone());
  }
  drop(v554_12_cursor);
  (v554_12).clone()
}

fn routine_56(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v564_10 = Space::new();
  let mut v564_10_cursor = (*s0).read_zipper();
  for v564_10_byte in v564_10_cursor.child_mask().iter() {
    v564_10_cursor.descend_to_byte(v564_10_byte);
    let v564_10_tail = v564_10_cursor.make_map();
    v564_10_cursor.ascend(1);
    let v564_10_head = Path::from_slice(&[v564_10_byte]);
    let v565_2: Space = singleton(&(v564_10_head));
    let v565_3: Space = intersect(&(*CONSTANT_3),&(v565_2));
    let v565_4: Space = if has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
    drop(v565_3);
    let v565_5: Space = compose(&(v565_4),&(v564_10_tail));
    drop(v565_4);
    let v566_6: Path = concat_path(&(*p0),&(v564_10_head));
    let v565_7: Space = wrap(&(v565_5),&(v566_6));
    drop(v565_5);
    let v565_8: Space = wrap(&(v565_7),&(*p1));
    drop(v565_7);
    let v565_9: Space = wrap(&(v565_8),&(*CONSTANT_5));
    drop(v565_8);
    let v565_10: Space = intersect(&(*CONSTANT_3),&(v565_2));
    drop(v565_2);
    let v565_11: Space = if has_head(&(v565_10)) { singleton(&[]) } else { Space::new() };
    drop(v565_10);
    let v565_12: Space = subtract(&(*CONSTANT_2),&(v565_11));
    drop(v565_11);
    let v565_14: Space = if (v565_12).is_empty() { Space::new() } else {
      let mut v567_13 = Space::new();
      let mut v567_13_cursor = (v564_10_tail).read_zipper();
      for v567_13_byte in v567_13_cursor.child_mask().iter() {
        v567_13_cursor.descend_to_byte(v567_13_byte);
        let v567_13_tail = v567_13_cursor.make_map();
        v567_13_cursor.ascend(1);
        let v567_13_head = Path::from_slice(&[v567_13_byte]);
        let v568_2: Space = singleton(&(v567_13_head));
        let v568_3: Space = intersect(&(*CONSTANT_3),&(v568_2));
        let v568_4: Space = if has_head(&(v568_3)) { singleton(&[]) } else { Space::new() };
        drop(v568_3);
        let v568_5: Space = subtract(&(*CONSTANT_2),&(v568_4));
        drop(v568_4);
        let v568_8: Space = if (v568_5).is_empty() { Space::new() } else {
          let v569_6: Path = concat_path(&(v566_6),&(v567_13_head));
          let v569_7: Space = routine_100(c, &(v569_6), &(*p1), &(v567_13_tail));
          compose(&(v568_5),&(v569_7))
        };
        drop(v568_5);
        let v568_9: Space = intersect(&(*CONSTANT_3),&(v568_2));
        drop(v568_2);
        let v568_10: Space = if has_head(&(v568_9)) { singleton(&[]) } else { Space::new() };
        drop(v568_9);
        let v568_12: Space = if (v568_10).is_empty() { Space::new() } else {
          let v570_6: Path = concat_path(&(v566_6),&(v567_13_head));
          let v570_11: Space = routine_101(c, &(v570_6), &(*p1), &(v567_13_tail));
          drop(v570_6);
          compose(&(v568_10),&(v570_11))
        };
        drop(v568_10);
        let v568_13: Space = unite(&(v568_8),&(v568_12));
        v567_13.join_into((v568_13).clone());
      }
      drop(v567_13_cursor);
      compose(&(v565_12),&(v567_13))
    };
    drop(v565_12);
    let v565_15: Space = unite(&(v565_9),&(v565_14));
    drop(v565_9);
    v564_10.join_into((v565_15).clone());
  }
  drop(v564_10_cursor);
  (v564_10).clone()
}

fn routine_57(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v571_12 = Space::new();
  let mut v571_12_cursor = (*s0).read_zipper();
  for v571_12_byte in v571_12_cursor.child_mask().iter() {
    v571_12_cursor.descend_to_byte(v571_12_byte);
    let v571_12_tail = v571_12_cursor.make_map();
    v571_12_cursor.ascend(1);
    let v571_12_head = Path::from_slice(&[v571_12_byte]);
    let v572_2: Space = singleton(&(v571_12_head));
    let v572_3: Space = intersect(&(*CONSTANT_3),&(v572_2));
    let v572_4: Space = if has_head(&(v572_3)) { singleton(&[]) } else { Space::new() };
    drop(v572_3);
    let v572_5: Space = subtract(&(*CONSTANT_2),&(v572_4));
    drop(v572_4);
    let v572_8: Space = if (v572_5).is_empty() { Space::new() } else {
      let v573_6: Path = concat_path(&(*p0),&(v571_12_head));
      let mut v573_7 = Space::new();
      let mut v573_7_cursor = (v571_12_tail).read_zipper();
      for v573_7_byte in v573_7_cursor.child_mask().iter() {
        v573_7_cursor.descend_to_byte(v573_7_byte);
        let v573_7_tail = v573_7_cursor.make_map();
        v573_7_cursor.ascend(1);
        let v573_7_head = Path::from_slice(&[v573_7_byte]);
        let v574_2: Space = singleton(&(v573_7_head));
        let v574_3: Space = intersect(&(*CONSTANT_3),&(v574_2));
        let v574_4: Space = if has_head(&(v574_3)) { singleton(&[]) } else { Space::new() };
        drop(v574_3);
        let v574_5: Space = subtract(&(*CONSTANT_2),&(v574_4));
        drop(v574_4);
        let v574_8: Space = if (v574_5).is_empty() { Space::new() } else {
          let v575_6: Path = concat_path(&(v573_6),&(v573_7_head));
          let v575_7: Space = routine_102(c, &(v575_6), &(v573_7_tail), &(*s1));
          compose(&(v574_5),&(v575_7))
        };
        drop(v574_5);
        let v574_9: Space = intersect(&(*CONSTANT_3),&(v574_2));
        drop(v574_2);
        let v574_10: Space = if has_head(&(v574_9)) { singleton(&[]) } else { Space::new() };
        drop(v574_9);
        let v574_12: Space = if (v574_10).is_empty() { Space::new() } else {
          let v576_6: Path = concat_path(&(v573_6),&(v573_7_head));
          let v576_11: Space = routine_103(c, &(v576_6), &(v573_7_tail), &(*s1));
          drop(v576_6);
          compose(&(v574_10),&(v576_11))
        };
        drop(v574_10);
        let v574_13: Space = unite(&(v574_8),&(v574_12));
        v573_7.join_into((v574_13).clone());
      }
      drop(v573_7_cursor);
      compose(&(v572_5),&(v573_7))
    };
    drop(v572_5);
    let v572_9: Space = intersect(&(*CONSTANT_3),&(v572_2));
    drop(v572_2);
    let v572_10: Space = if has_head(&(v572_9)) { singleton(&[]) } else { Space::new() };
    drop(v572_9);
    let v572_12: Space = if (v572_10).is_empty() { Space::new() } else {
      let v577_6: Path = concat_path(&(*p0),&(v571_12_head));
      let mut v577_11 = Space::new();
      let mut v577_11_cursor = (v571_12_tail).read_zipper();
      for v577_11_byte in v577_11_cursor.child_mask().iter() {
        v577_11_cursor.descend_to_byte(v577_11_byte);
        let v577_11_tail = v577_11_cursor.make_map();
        v577_11_cursor.ascend(1);
        let v577_11_head = Path::from_slice(&[v577_11_byte]);
        let v578_2: Space = singleton(&(v577_11_head));
        let v578_3: Space = intersect(&(*CONSTANT_3),&(v578_2));
        let v578_4: Space = if has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
        drop(v578_3);
        let v578_5: Space = subtract(&(*CONSTANT_2),&(v578_4));
        drop(v578_4);
        let v578_8: Space = if (v578_5).is_empty() { Space::new() } else {
          let v579_6: Path = concat_path(&(v577_6),&(v577_11_head));
          let v579_7: Space = routine_102(c, &(v579_6), &(v577_11_tail), &(*s1));
          compose(&(v578_5),&(v579_7))
        };
        drop(v578_5);
        let v578_9: Space = intersect(&(*CONSTANT_3),&(v578_2));
        drop(v578_2);
        let v578_10: Space = if has_head(&(v578_9)) { singleton(&[]) } else { Space::new() };
        drop(v578_9);
        let v578_12: Space = if (v578_10).is_empty() { Space::new() } else {
          let v580_6: Path = concat_path(&(v577_6),&(v577_11_head));
          let v580_11: Space = routine_6(c, &(v580_6), &(v577_11_tail), &(*s1));
          drop(v580_6);
          compose(&(v578_10),&(v580_11))
        };
        drop(v578_10);
        let v578_13: Space = unite(&(v578_8),&(v578_12));
        v577_11.join_into((v578_13).clone());
      }
      drop(v577_11_cursor);
      drop(v577_6);
      compose(&(v572_10),&(v577_11))
    };
    drop(v572_10);
    let v572_13: Space = unite(&(v572_8),&(v572_12));
    v571_12.join_into((v572_13).clone());
  }
  drop(v571_12_cursor);
  (v571_12).clone()
}

fn routine_58(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v581_12 = Space::new();
  let mut v581_12_cursor = (*s0).read_zipper();
  for v581_12_byte in v581_12_cursor.child_mask().iter() {
    v581_12_cursor.descend_to_byte(v581_12_byte);
    let v581_12_tail = v581_12_cursor.make_map();
    v581_12_cursor.ascend(1);
    let v581_12_head = Path::from_slice(&[v581_12_byte]);
    let v582_2: Space = singleton(&(v581_12_head));
    let v582_3: Space = intersect(&(*CONSTANT_3),&(v582_2));
    let v582_4: Space = if has_head(&(v582_3)) { singleton(&[]) } else { Space::new() };
    drop(v582_3);
    let v582_5: Space = subtract(&(*CONSTANT_2),&(v582_4));
    drop(v582_4);
    let v582_8: Space = if (v582_5).is_empty() { Space::new() } else {
      let v583_6: Path = concat_path(&(*p0),&(v581_12_head));
      let mut v583_7 = Space::new();
      let mut v583_7_cursor = (v581_12_tail).read_zipper();
      for v583_7_byte in v583_7_cursor.child_mask().iter() {
        v583_7_cursor.descend_to_byte(v583_7_byte);
        let v583_7_tail = v583_7_cursor.make_map();
        v583_7_cursor.ascend(1);
        let v583_7_head = Path::from_slice(&[v583_7_byte]);
        let v584_2: Space = singleton(&(v583_7_head));
        let v584_3: Space = intersect(&(*CONSTANT_3),&(v584_2));
        let v584_4: Space = if has_head(&(v584_3)) { singleton(&[]) } else { Space::new() };
        drop(v584_3);
        let v584_5: Space = subtract(&(*CONSTANT_2),&(v584_4));
        drop(v584_4);
        let v584_8: Space = if (v584_5).is_empty() { Space::new() } else {
          let v585_6: Path = concat_path(&(v583_6),&(v583_7_head));
          let v585_7: Space = routine_102(c, &(v585_6), &(v583_7_tail), &(*s1));
          compose(&(v584_5),&(v585_7))
        };
        drop(v584_5);
        let v584_9: Space = intersect(&(*CONSTANT_3),&(v584_2));
        drop(v584_2);
        let v584_10: Space = if has_head(&(v584_9)) { singleton(&[]) } else { Space::new() };
        drop(v584_9);
        let v584_12: Space = if (v584_10).is_empty() { Space::new() } else {
          let v586_6: Path = concat_path(&(v583_6),&(v583_7_head));
          let v586_11: Space = routine_103(c, &(v586_6), &(v583_7_tail), &(*s1));
          drop(v586_6);
          compose(&(v584_10),&(v586_11))
        };
        drop(v584_10);
        let v584_13: Space = unite(&(v584_8),&(v584_12));
        v583_7.join_into((v584_13).clone());
      }
      drop(v583_7_cursor);
      compose(&(v582_5),&(v583_7))
    };
    drop(v582_5);
    let v582_9: Space = intersect(&(*CONSTANT_3),&(v582_2));
    drop(v582_2);
    let v582_10: Space = if has_head(&(v582_9)) { singleton(&[]) } else { Space::new() };
    drop(v582_9);
    let v582_12: Space = if (v582_10).is_empty() { Space::new() } else {
      let v587_6: Path = concat_path(&(*p0),&(v581_12_head));
      let mut v587_11 = Space::new();
      let mut v587_11_cursor = (v581_12_tail).read_zipper();
      for v587_11_byte in v587_11_cursor.child_mask().iter() {
        v587_11_cursor.descend_to_byte(v587_11_byte);
        let v587_11_tail = v587_11_cursor.make_map();
        v587_11_cursor.ascend(1);
        let v587_11_head = Path::from_slice(&[v587_11_byte]);
        let v588_2: Space = singleton(&(v587_11_head));
        let v588_3: Space = intersect(&(*CONSTANT_3),&(v588_2));
        let v588_4: Space = if has_head(&(v588_3)) { singleton(&[]) } else { Space::new() };
        drop(v588_3);
        let v588_5: Space = subtract(&(*CONSTANT_2),&(v588_4));
        drop(v588_4);
        let v588_7: Space = if (v588_5).is_empty() { Space::new() } else {
          let v589_6: Space = routine_25(c, &(v587_11_head), &(v587_6), &(v587_11_tail), &(*s1));
          compose(&(v588_5),&(v589_6))
        };
        drop(v588_5);
        let v588_8: Space = intersect(&(*CONSTANT_3),&(v588_2));
        drop(v588_2);
        let v588_9: Space = if has_head(&(v588_8)) { singleton(&[]) } else { Space::new() };
        drop(v588_8);
        let v588_11: Space = if (v588_9).is_empty() { Space::new() } else {
          let v590_10: Space = routine_26(c, &(v587_11_head), &(v587_6), &(v587_11_tail), &(*s1));
          compose(&(v588_9),&(v590_10))
        };
        drop(v588_9);
        let v588_12: Space = unite(&(v588_7),&(v588_11));
        v587_11.join_into((v588_12).clone());
      }
      drop(v587_11_cursor);
      drop(v587_6);
      compose(&(v582_10),&(v587_11))
    };
    drop(v582_10);
    let v582_13: Space = unite(&(v582_8),&(v582_12));
    v581_12.join_into((v582_13).clone());
  }
  drop(v581_12_cursor);
  (v581_12).clone()
}

fn routine_59(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v591_13 = Space::new();
  let mut v591_13_cursor = (*s0).read_zipper();
  for v591_13_byte in v591_13_cursor.child_mask().iter() {
    v591_13_cursor.descend_to_byte(v591_13_byte);
    let v591_13_tail = v591_13_cursor.make_map();
    v591_13_cursor.ascend(1);
    let v591_13_head = Path::from_slice(&[v591_13_byte]);
    let v592_2: Space = singleton(&(v591_13_head));
    let v592_3: Space = intersect(&(*CONSTANT_3),&(v592_2));
    let v592_4: Space = if has_head(&(v592_3)) { singleton(&[]) } else { Space::new() };
    drop(v592_3);
    let v592_5: Space = subtract(&(*CONSTANT_2),&(v592_4));
    drop(v592_4);
    let v592_8: Space = if (v592_5).is_empty() { Space::new() } else {
      let v593_6: Path = concat_path(&(*p0),&(v591_13_head));
      let mut v593_7 = Space::new();
      let mut v593_7_cursor = (v591_13_tail).read_zipper();
      for v593_7_byte in v593_7_cursor.child_mask().iter() {
        v593_7_cursor.descend_to_byte(v593_7_byte);
        let v593_7_tail = v593_7_cursor.make_map();
        v593_7_cursor.ascend(1);
        let v593_7_head = Path::from_slice(&[v593_7_byte]);
        let v594_2: Space = singleton(&(v593_7_head));
        let v594_3: Space = intersect(&(*CONSTANT_3),&(v594_2));
        let v594_4: Space = if has_head(&(v594_3)) { singleton(&[]) } else { Space::new() };
        drop(v594_3);
        let v594_5: Space = subtract(&(*CONSTANT_2),&(v594_4));
        drop(v594_4);
        let v594_8: Space = if (v594_5).is_empty() { Space::new() } else {
          let v595_6: Path = concat_path(&(v593_6),&(v593_7_head));
          let v595_7: Space = routine_104(c, &(v595_6), &(*p1), &(v593_7_tail), &(*s1));
          compose(&(v594_5),&(v595_7))
        };
        drop(v594_5);
        let v594_9: Space = intersect(&(*CONSTANT_3),&(v594_2));
        drop(v594_2);
        let v594_10: Space = if has_head(&(v594_9)) { singleton(&[]) } else { Space::new() };
        drop(v594_9);
        let v594_12: Space = if (v594_10).is_empty() { Space::new() } else {
          let v596_6: Path = concat_path(&(v593_6),&(v593_7_head));
          let v596_11: Space = routine_105(c, &(v596_6), &(*p1), &(v593_7_tail), &(*s1));
          drop(v596_6);
          compose(&(v594_10),&(v596_11))
        };
        drop(v594_10);
        let v594_13: Space = unite(&(v594_8),&(v594_12));
        v593_7.join_into((v594_13).clone());
      }
      drop(v593_7_cursor);
      compose(&(v592_5),&(v593_7))
    };
    drop(v592_5);
    let v592_9: Space = intersect(&(*CONSTANT_3),&(v592_2));
    drop(v592_2);
    let v592_10: Space = if has_head(&(v592_9)) { singleton(&[]) } else { Space::new() };
    drop(v592_9);
    let v592_12: Space = if (v592_10).is_empty() { Space::new() } else {
      let v597_6: Path = concat_path(&(*p0),&(v591_13_head));
      let mut v597_11 = Space::new();
      let mut v597_11_cursor = (v591_13_tail).read_zipper();
      for v597_11_byte in v597_11_cursor.child_mask().iter() {
        v597_11_cursor.descend_to_byte(v597_11_byte);
        let v597_11_tail = v597_11_cursor.make_map();
        v597_11_cursor.ascend(1);
        let v597_11_head = Path::from_slice(&[v597_11_byte]);
        let v598_2: Space = singleton(&(v597_11_head));
        let v598_3: Space = intersect(&(*CONSTANT_3),&(v598_2));
        let v598_4: Space = if has_head(&(v598_3)) { singleton(&[]) } else { Space::new() };
        drop(v598_3);
        let v598_5: Space = subtract(&(*CONSTANT_2),&(v598_4));
        drop(v598_4);
        let v598_8: Space = if (v598_5).is_empty() { Space::new() } else {
          let v599_6: Path = concat_path(&(v597_6),&(v597_11_head));
          let v599_7: Space = routine_104(c, &(v599_6), &(*p1), &(v597_11_tail), &(*s1));
          compose(&(v598_5),&(v599_7))
        };
        drop(v598_5);
        let v598_9: Space = intersect(&(*CONSTANT_3),&(v598_2));
        drop(v598_2);
        let v598_10: Space = if has_head(&(v598_9)) { singleton(&[]) } else { Space::new() };
        drop(v598_9);
        let v598_12: Space = if (v598_10).is_empty() { Space::new() } else {
          let v600_6: Path = concat_path(&(v597_6),&(v597_11_head));
          let v600_11: Space = routine_29(c, &(v600_6), &(*p1), &(v597_11_tail), &(*s1));
          drop(v600_6);
          compose(&(v598_10),&(v600_11))
        };
        drop(v598_10);
        let v598_13: Space = unite(&(v598_8),&(v598_12));
        v597_11.join_into((v598_13).clone());
      }
      drop(v597_11_cursor);
      drop(v597_6);
      compose(&(v592_10),&(v597_11))
    };
    drop(v592_10);
    let v592_13: Space = unite(&(v592_8),&(v592_12));
    v591_13.join_into((v592_13).clone());
  }
  drop(v591_13_cursor);
  (v591_13).clone()
}

fn routine_60(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v601_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v601_10: Space = unwrap(&(v601_8),&(*CONSTANT_5));
  drop(v601_8);
  let v601_11: Space = unwrap(&(v601_10),&(*p0));
  drop(v601_10);
  let mut v601_18 = Space::new();
  let mut v601_18_cursor = (*s0).read_zipper();
  for v601_18_byte in v601_18_cursor.child_mask().iter() {
    v601_18_cursor.descend_to_byte(v601_18_byte);
    let v601_18_tail = v601_18_cursor.make_map();
    v601_18_cursor.ascend(1);
    let v601_18_head = Path::from_slice(&[v601_18_byte]);
    let v602_2: Space = singleton(&(v601_18_head));
    let v602_3: Space = intersect(&(*CONSTANT_3),&(v602_2));
    let v602_4: Space = if has_head(&(v602_3)) { singleton(&[]) } else { Space::new() };
    drop(v602_3);
    let v602_5: Space = subtract(&(*CONSTANT_2),&(v602_4));
    drop(v602_4);
    let v602_8: Space = if (v602_5).is_empty() { Space::new() } else {
      let v603_6: Path = concat_path(&(*p0),&(v601_18_head));
      let mut v603_7 = Space::new();
      let mut v603_7_cursor = (v601_18_tail).read_zipper();
      for v603_7_byte in v603_7_cursor.child_mask().iter() {
        v603_7_cursor.descend_to_byte(v603_7_byte);
        let v603_7_tail = v603_7_cursor.make_map();
        v603_7_cursor.ascend(1);
        let v603_7_head = Path::from_slice(&[v603_7_byte]);
        let v604_2: Space = singleton(&(v603_7_head));
        let v604_3: Space = intersect(&(*CONSTANT_3),&(v604_2));
        let v604_4: Space = if has_head(&(v604_3)) { singleton(&[]) } else { Space::new() };
        drop(v604_3);
        let v604_5: Space = subtract(&(*CONSTANT_2),&(v604_4));
        drop(v604_4);
        let v604_8: Space = if (v604_5).is_empty() { Space::new() } else {
          let v605_6: Path = concat_path(&(v603_6),&(v603_7_head));
          let v605_7: Space = routine_104(c, &(v605_6), &(*p1), &(v603_7_tail), &(*s1));
          compose(&(v604_5),&(v605_7))
        };
        drop(v604_5);
        let v604_9: Space = intersect(&(*CONSTANT_3),&(v604_2));
        drop(v604_2);
        let v604_10: Space = if has_head(&(v604_9)) { singleton(&[]) } else { Space::new() };
        drop(v604_9);
        let v604_12: Space = if (v604_10).is_empty() { Space::new() } else {
          let v606_6: Path = concat_path(&(v603_6),&(v603_7_head));
          let v606_11: Space = routine_105(c, &(v606_6), &(*p1), &(v603_7_tail), &(*s1));
          drop(v606_6);
          compose(&(v604_10),&(v606_11))
        };
        drop(v604_10);
        let v604_13: Space = unite(&(v604_8),&(v604_12));
        v603_7.join_into((v604_13).clone());
      }
      drop(v603_7_cursor);
      drop(v603_6);
      compose(&(v602_5),&(v603_7))
    };
    drop(v602_5);
    let v602_9: Space = intersect(&(*CONSTANT_3),&(v602_2));
    drop(v602_2);
    let v602_10: Space = if has_head(&(v602_9)) { singleton(&[]) } else { Space::new() };
    drop(v602_9);
    let v602_13: Space = if (v602_10).is_empty() { Space::new() } else {
      let v607_11: Space = unwrap(&(v601_11),&(v601_18_head));
      let mut v607_12 = Space::new();
      let mut v607_12_cursor = (v607_11).read_zipper();
      for v607_12_byte in v607_12_cursor.child_mask().iter() {
        v607_12_cursor.descend_to_byte(v607_12_byte);
        let v607_12_tail = v607_12_cursor.make_map();
        v607_12_cursor.ascend(1);
        let v607_12_head = Path::from_slice(&[v607_12_byte]);
        let v608_2: Space = singleton(&(v607_12_head));
        let v608_3: Space = intersect(&(*CONSTANT_3),&(v608_2));
        let v608_4: Space = if has_head(&(v608_3)) { singleton(&[]) } else { Space::new() };
        drop(v608_3);
        let v608_5: Space = subtract(&(*CONSTANT_2),&(v608_4));
        drop(v608_4);
        let v608_7: Space = if (v608_5).is_empty() { Space::new() } else {
          let v609_6: Space = routine_61(c, &(v607_12_head), &(*p1), &(v607_12_tail));
          compose(&(v608_5),&(v609_6))
        };
        drop(v608_5);
        let v608_8: Space = intersect(&(*CONSTANT_3),&(v608_2));
        drop(v608_2);
        let v608_9: Space = if has_head(&(v608_8)) { singleton(&[]) } else { Space::new() };
        drop(v608_8);
        let v608_11: Space = if (v608_9).is_empty() { Space::new() } else {
          let v610_10: Space = routine_62(c, &(v607_12_head), &(*p1), &(v607_12_tail));
          compose(&(v608_9),&(v610_10))
        };
        drop(v608_9);
        let v608_12: Space = unite(&(v608_7),&(v608_11));
        v607_12.join_into((v608_12).clone());
      }
      drop(v607_12_cursor);
      drop(v607_11);
      compose(&(v602_10),&(v607_12))
    };
    drop(v602_10);
    let v602_14: Space = unite(&(v602_8),&(v602_13));
    v601_18.join_into((v602_14).clone());
  }
  drop(v601_18_cursor);
  drop(v601_11);
  (v601_18).clone()
}

fn routine_61(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v611_12 = Space::new();
  let mut v611_12_cursor = (*s0).read_zipper();
  for v611_12_byte in v611_12_cursor.child_mask().iter() {
    v611_12_cursor.descend_to_byte(v611_12_byte);
    let v611_12_tail = v611_12_cursor.make_map();
    v611_12_cursor.ascend(1);
    let v611_12_head = Path::from_slice(&[v611_12_byte]);
    let v612_2: Space = singleton(&(v611_12_head));
    let v612_3: Space = intersect(&(*CONSTANT_3),&(v612_2));
    let v612_4: Space = if has_head(&(v612_3)) { singleton(&[]) } else { Space::new() };
    drop(v612_3);
    let v612_5: Space = subtract(&(*CONSTANT_2),&(v612_4));
    drop(v612_4);
    let v612_8: Space = if (v612_5).is_empty() { Space::new() } else {
      let v613_6: Path = concat_path(&(*p0),&(v611_12_head));
      let mut v613_7 = Space::new();
      let mut v613_7_cursor = (v611_12_tail).read_zipper();
      for v613_7_byte in v613_7_cursor.child_mask().iter() {
        v613_7_cursor.descend_to_byte(v613_7_byte);
        let v613_7_tail = v613_7_cursor.make_map();
        v613_7_cursor.ascend(1);
        let v613_7_head = Path::from_slice(&[v613_7_byte]);
        let v614_2: Space = singleton(&(v613_7_head));
        let v614_3: Space = intersect(&(*CONSTANT_3),&(v614_2));
        let v614_4: Space = if has_head(&(v614_3)) { singleton(&[]) } else { Space::new() };
        drop(v614_3);
        let v614_5: Space = subtract(&(*CONSTANT_2),&(v614_4));
        drop(v614_4);
        let v614_8: Space = if (v614_5).is_empty() { Space::new() } else {
          let v615_6: Path = concat_path(&(v613_6),&(v613_7_head));
          let v615_7: Space = routine_106(c, &(v615_6), &(*p1), &(v613_7_tail));
          compose(&(v614_5),&(v615_7))
        };
        drop(v614_5);
        let v614_9: Space = intersect(&(*CONSTANT_3),&(v614_2));
        drop(v614_2);
        let v614_10: Space = if has_head(&(v614_9)) { singleton(&[]) } else { Space::new() };
        drop(v614_9);
        let v614_12: Space = if (v614_10).is_empty() { Space::new() } else {
          let v616_6: Path = concat_path(&(v613_6),&(v613_7_head));
          let v616_11: Space = routine_107(c, &(v616_6), &(*p1), &(v613_7_tail));
          drop(v616_6);
          compose(&(v614_10),&(v616_11))
        };
        drop(v614_10);
        let v614_13: Space = unite(&(v614_8),&(v614_12));
        v613_7.join_into((v614_13).clone());
      }
      drop(v613_7_cursor);
      compose(&(v612_5),&(v613_7))
    };
    drop(v612_5);
    let v612_9: Space = intersect(&(*CONSTANT_3),&(v612_2));
    drop(v612_2);
    let v612_10: Space = if has_head(&(v612_9)) { singleton(&[]) } else { Space::new() };
    drop(v612_9);
    let v612_12: Space = if (v612_10).is_empty() { Space::new() } else {
      let v617_6: Path = concat_path(&(*p0),&(v611_12_head));
      let mut v617_11 = Space::new();
      let mut v617_11_cursor = (v611_12_tail).read_zipper();
      for v617_11_byte in v617_11_cursor.child_mask().iter() {
        v617_11_cursor.descend_to_byte(v617_11_byte);
        let v617_11_tail = v617_11_cursor.make_map();
        v617_11_cursor.ascend(1);
        let v617_11_head = Path::from_slice(&[v617_11_byte]);
        let v618_2: Space = singleton(&(v617_11_head));
        let v618_3: Space = intersect(&(*CONSTANT_3),&(v618_2));
        let v618_4: Space = if has_head(&(v618_3)) { singleton(&[]) } else { Space::new() };
        drop(v618_3);
        let v618_5: Space = subtract(&(*CONSTANT_2),&(v618_4));
        drop(v618_4);
        let v618_8: Space = if (v618_5).is_empty() { Space::new() } else {
          let v619_6: Path = concat_path(&(v617_6),&(v617_11_head));
          let v619_7: Space = routine_106(c, &(v619_6), &(*p1), &(v617_11_tail));
          compose(&(v618_5),&(v619_7))
        };
        drop(v618_5);
        let v618_9: Space = intersect(&(*CONSTANT_3),&(v618_2));
        drop(v618_2);
        let v618_10: Space = if has_head(&(v618_9)) { singleton(&[]) } else { Space::new() };
        drop(v618_9);
        let v618_12: Space = if (v618_10).is_empty() { Space::new() } else {
          let v620_6: Path = concat_path(&(v617_6),&(v617_11_head));
          let v620_11: Space = routine_67(c, &(v620_6), &(*p1), &(v617_11_tail));
          drop(v620_6);
          compose(&(v618_10),&(v620_11))
        };
        drop(v618_10);
        let v618_13: Space = unite(&(v618_8),&(v618_12));
        v617_11.join_into((v618_13).clone());
      }
      drop(v617_11_cursor);
      drop(v617_6);
      compose(&(v612_10),&(v617_11))
    };
    drop(v612_10);
    let v612_13: Space = unite(&(v612_8),&(v612_12));
    v611_12.join_into((v612_13).clone());
  }
  drop(v611_12_cursor);
  (v611_12).clone()
}

fn routine_62(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v621_9 = Space::new();
  let mut v621_9_cursor = (*s0).read_zipper();
  for v621_9_byte in v621_9_cursor.child_mask().iter() {
    v621_9_cursor.descend_to_byte(v621_9_byte);
    let v621_9_tail = v621_9_cursor.make_map();
    v621_9_cursor.ascend(1);
    let v621_9_head = Path::from_slice(&[v621_9_byte]);
    let v622_2: Space = singleton(&(v621_9_head));
    let v622_3: Space = intersect(&(*CONSTANT_3),&(v622_2));
    let v622_4: Space = if has_head(&(v622_3)) { singleton(&[]) } else { Space::new() };
    drop(v622_3);
    let v622_5: Space = subtract(&(*CONSTANT_2),&(v622_4));
    drop(v622_4);
    let v622_8: Space = if (v622_5).is_empty() { Space::new() } else {
      let v623_6: Path = concat_path(&(*p0),&(v621_9_head));
      let mut v623_7 = Space::new();
      let mut v623_7_cursor = (v621_9_tail).read_zipper();
      for v623_7_byte in v623_7_cursor.child_mask().iter() {
        v623_7_cursor.descend_to_byte(v623_7_byte);
        let v623_7_tail = v623_7_cursor.make_map();
        v623_7_cursor.ascend(1);
        let v623_7_head = Path::from_slice(&[v623_7_byte]);
        let v624_2: Space = singleton(&(v623_7_head));
        let v624_3: Space = intersect(&(*CONSTANT_3),&(v624_2));
        let v624_4: Space = if has_head(&(v624_3)) { singleton(&[]) } else { Space::new() };
        drop(v624_3);
        let v624_5: Space = subtract(&(*CONSTANT_2),&(v624_4));
        drop(v624_4);
        let v624_8: Space = if (v624_5).is_empty() { Space::new() } else {
          let v625_6: Path = concat_path(&(v623_6),&(v623_7_head));
          let v625_7: Space = routine_106(c, &(v625_6), &(*p1), &(v623_7_tail));
          compose(&(v624_5),&(v625_7))
        };
        drop(v624_5);
        let v624_9: Space = intersect(&(*CONSTANT_3),&(v624_2));
        drop(v624_2);
        let v624_10: Space = if has_head(&(v624_9)) { singleton(&[]) } else { Space::new() };
        drop(v624_9);
        let v624_12: Space = if (v624_10).is_empty() { Space::new() } else {
          let v626_6: Path = concat_path(&(v623_6),&(v623_7_head));
          let v626_11: Space = routine_107(c, &(v626_6), &(*p1), &(v623_7_tail));
          drop(v626_6);
          compose(&(v624_10),&(v626_11))
        };
        drop(v624_10);
        let v624_13: Space = unite(&(v624_8),&(v624_12));
        v623_7.join_into((v624_13).clone());
      }
      drop(v623_7_cursor);
      compose(&(v622_5),&(v623_7))
    };
    drop(v622_5);
    let v622_9: Space = intersect(&(*CONSTANT_3),&(v622_2));
    drop(v622_2);
    let v622_10: Space = if has_head(&(v622_9)) { singleton(&[]) } else { Space::new() };
    drop(v622_9);
    let v622_11: Space = compose(&(v622_10),&(v621_9_tail));
    drop(v622_10);
    let v627_6: Path = concat_path(&(*p0),&(v621_9_head));
    let v622_12: Space = wrap(&(v622_11),&(v627_6));
    drop(v622_11);
    let v622_13: Space = wrap(&(v622_12),&(*p1));
    drop(v622_12);
    let v622_14: Space = unite(&(v622_8),&(v622_13));
    drop(v622_13);
    v621_9.join_into((v622_14).clone());
  }
  drop(v621_9_cursor);
  (v621_9).clone()
}

fn routine_63(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v628_13 = Space::new();
  let mut v628_13_cursor = (*s0).read_zipper();
  for v628_13_byte in v628_13_cursor.child_mask().iter() {
    v628_13_cursor.descend_to_byte(v628_13_byte);
    let v628_13_tail = v628_13_cursor.make_map();
    v628_13_cursor.ascend(1);
    let v628_13_head = Path::from_slice(&[v628_13_byte]);
    let v629_2: Space = singleton(&(v628_13_head));
    let v629_3: Space = intersect(&(*CONSTANT_3),&(v629_2));
    let v629_4: Space = if has_head(&(v629_3)) { singleton(&[]) } else { Space::new() };
    drop(v629_3);
    let v629_5: Space = subtract(&(*CONSTANT_2),&(v629_4));
    drop(v629_4);
    let v629_8: Space = if (v629_5).is_empty() { Space::new() } else {
      let v630_6: Path = concat_path(&(*p0),&(v628_13_head));
      let mut v630_7 = Space::new();
      let mut v630_7_cursor = (v628_13_tail).read_zipper();
      for v630_7_byte in v630_7_cursor.child_mask().iter() {
        v630_7_cursor.descend_to_byte(v630_7_byte);
        let v630_7_tail = v630_7_cursor.make_map();
        v630_7_cursor.ascend(1);
        let v630_7_head = Path::from_slice(&[v630_7_byte]);
        let v631_2: Space = singleton(&(v630_7_head));
        let v631_3: Space = intersect(&(*CONSTANT_3),&(v631_2));
        let v631_4: Space = if has_head(&(v631_3)) { singleton(&[]) } else { Space::new() };
        drop(v631_3);
        let v631_5: Space = subtract(&(*CONSTANT_2),&(v631_4));
        drop(v631_4);
        let v631_8: Space = if (v631_5).is_empty() { Space::new() } else {
          let v632_6: Path = concat_path(&(v630_6),&(v630_7_head));
          let v632_7: Space = routine_108(c, &(v632_6), &(*p1), &(v630_7_tail), &(*s1));
          compose(&(v631_5),&(v632_7))
        };
        drop(v631_5);
        let v631_9: Space = intersect(&(*CONSTANT_3),&(v631_2));
        drop(v631_2);
        let v631_10: Space = if has_head(&(v631_9)) { singleton(&[]) } else { Space::new() };
        drop(v631_9);
        let v631_12: Space = if (v631_10).is_empty() { Space::new() } else {
          let v633_6: Path = concat_path(&(v630_6),&(v630_7_head));
          let v633_11: Space = routine_109(c, &(v633_6), &(*p1), &(v630_7_tail), &(*s1));
          drop(v633_6);
          compose(&(v631_10),&(v633_11))
        };
        drop(v631_10);
        let v631_13: Space = unite(&(v631_8),&(v631_12));
        v630_7.join_into((v631_13).clone());
      }
      drop(v630_7_cursor);
      compose(&(v629_5),&(v630_7))
    };
    drop(v629_5);
    let v629_9: Space = intersect(&(*CONSTANT_3),&(v629_2));
    drop(v629_2);
    let v629_10: Space = if has_head(&(v629_9)) { singleton(&[]) } else { Space::new() };
    drop(v629_9);
    let v629_12: Space = if (v629_10).is_empty() { Space::new() } else {
      let v634_6: Path = concat_path(&(*p0),&(v628_13_head));
      let mut v634_11 = Space::new();
      let mut v634_11_cursor = (v628_13_tail).read_zipper();
      for v634_11_byte in v634_11_cursor.child_mask().iter() {
        v634_11_cursor.descend_to_byte(v634_11_byte);
        let v634_11_tail = v634_11_cursor.make_map();
        v634_11_cursor.ascend(1);
        let v634_11_head = Path::from_slice(&[v634_11_byte]);
        let v635_2: Space = singleton(&(v634_11_head));
        let v635_3: Space = intersect(&(*CONSTANT_3),&(v635_2));
        let v635_4: Space = if has_head(&(v635_3)) { singleton(&[]) } else { Space::new() };
        drop(v635_3);
        let v635_5: Space = subtract(&(*CONSTANT_2),&(v635_4));
        drop(v635_4);
        let v635_8: Space = if (v635_5).is_empty() { Space::new() } else {
          let v636_6: Path = concat_path(&(v634_6),&(v634_11_head));
          let v636_7: Space = routine_108(c, &(v636_6), &(*p1), &(v634_11_tail), &(*s1));
          compose(&(v635_5),&(v636_7))
        };
        drop(v635_5);
        let v635_9: Space = intersect(&(*CONSTANT_3),&(v635_2));
        drop(v635_2);
        let v635_10: Space = if has_head(&(v635_9)) { singleton(&[]) } else { Space::new() };
        drop(v635_9);
        let v635_12: Space = if (v635_10).is_empty() { Space::new() } else {
          let v637_6: Path = concat_path(&(v634_6),&(v634_11_head));
          let v637_11: Space = routine_29(c, &(v637_6), &(*p1), &(v634_11_tail), &(*s1));
          drop(v637_6);
          compose(&(v635_10),&(v637_11))
        };
        drop(v635_10);
        let v635_13: Space = unite(&(v635_8),&(v635_12));
        v634_11.join_into((v635_13).clone());
      }
      drop(v634_11_cursor);
      drop(v634_6);
      compose(&(v629_10),&(v634_11))
    };
    drop(v629_10);
    let v629_13: Space = unite(&(v629_8),&(v629_12));
    v628_13.join_into((v629_13).clone());
  }
  drop(v628_13_cursor);
  (v628_13).clone()
}

fn routine_64(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v638_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v638_10: Space = unwrap(&(v638_8),&(*CONSTANT_5));
  drop(v638_8);
  let v638_11: Space = unwrap(&(v638_10),&(*p0));
  drop(v638_10);
  let mut v638_18 = Space::new();
  let mut v638_18_cursor = (*s0).read_zipper();
  for v638_18_byte in v638_18_cursor.child_mask().iter() {
    v638_18_cursor.descend_to_byte(v638_18_byte);
    let v638_18_tail = v638_18_cursor.make_map();
    v638_18_cursor.ascend(1);
    let v638_18_head = Path::from_slice(&[v638_18_byte]);
    let v639_2: Space = singleton(&(v638_18_head));
    let v639_3: Space = intersect(&(*CONSTANT_3),&(v639_2));
    let v639_4: Space = if has_head(&(v639_3)) { singleton(&[]) } else { Space::new() };
    drop(v639_3);
    let v639_5: Space = subtract(&(*CONSTANT_2),&(v639_4));
    drop(v639_4);
    let v639_8: Space = if (v639_5).is_empty() { Space::new() } else {
      let v640_6: Path = concat_path(&(*p0),&(v638_18_head));
      let mut v640_7 = Space::new();
      let mut v640_7_cursor = (v638_18_tail).read_zipper();
      for v640_7_byte in v640_7_cursor.child_mask().iter() {
        v640_7_cursor.descend_to_byte(v640_7_byte);
        let v640_7_tail = v640_7_cursor.make_map();
        v640_7_cursor.ascend(1);
        let v640_7_head = Path::from_slice(&[v640_7_byte]);
        let v641_2: Space = singleton(&(v640_7_head));
        let v641_3: Space = intersect(&(*CONSTANT_3),&(v641_2));
        let v641_4: Space = if has_head(&(v641_3)) { singleton(&[]) } else { Space::new() };
        drop(v641_3);
        let v641_5: Space = subtract(&(*CONSTANT_2),&(v641_4));
        drop(v641_4);
        let v641_8: Space = if (v641_5).is_empty() { Space::new() } else {
          let v642_6: Path = concat_path(&(v640_6),&(v640_7_head));
          let v642_7: Space = routine_108(c, &(v642_6), &(*p1), &(v640_7_tail), &(*s1));
          compose(&(v641_5),&(v642_7))
        };
        drop(v641_5);
        let v641_9: Space = intersect(&(*CONSTANT_3),&(v641_2));
        drop(v641_2);
        let v641_10: Space = if has_head(&(v641_9)) { singleton(&[]) } else { Space::new() };
        drop(v641_9);
        let v641_12: Space = if (v641_10).is_empty() { Space::new() } else {
          let v643_6: Path = concat_path(&(v640_6),&(v640_7_head));
          let v643_11: Space = routine_109(c, &(v643_6), &(*p1), &(v640_7_tail), &(*s1));
          drop(v643_6);
          compose(&(v641_10),&(v643_11))
        };
        drop(v641_10);
        let v641_13: Space = unite(&(v641_8),&(v641_12));
        v640_7.join_into((v641_13).clone());
      }
      drop(v640_7_cursor);
      drop(v640_6);
      compose(&(v639_5),&(v640_7))
    };
    drop(v639_5);
    let v639_9: Space = intersect(&(*CONSTANT_3),&(v639_2));
    drop(v639_2);
    let v639_10: Space = if has_head(&(v639_9)) { singleton(&[]) } else { Space::new() };
    drop(v639_9);
    let v639_13: Space = if (v639_10).is_empty() { Space::new() } else {
      let v644_11: Space = unwrap(&(v638_11),&(v638_18_head));
      let mut v644_12 = Space::new();
      let mut v644_12_cursor = (v644_11).read_zipper();
      for v644_12_byte in v644_12_cursor.child_mask().iter() {
        v644_12_cursor.descend_to_byte(v644_12_byte);
        let v644_12_tail = v644_12_cursor.make_map();
        v644_12_cursor.ascend(1);
        let v644_12_head = Path::from_slice(&[v644_12_byte]);
        let v645_2: Space = singleton(&(v644_12_head));
        let v645_3: Space = intersect(&(*CONSTANT_3),&(v645_2));
        let v645_4: Space = if has_head(&(v645_3)) { singleton(&[]) } else { Space::new() };
        drop(v645_3);
        let v645_5: Space = subtract(&(*CONSTANT_2),&(v645_4));
        drop(v645_4);
        let v645_7: Space = if (v645_5).is_empty() { Space::new() } else {
          let v646_6: Space = routine_61(c, &(v644_12_head), &(*p1), &(v644_12_tail));
          compose(&(v645_5),&(v646_6))
        };
        drop(v645_5);
        let v645_8: Space = intersect(&(*CONSTANT_3),&(v645_2));
        drop(v645_2);
        let v645_9: Space = if has_head(&(v645_8)) { singleton(&[]) } else { Space::new() };
        drop(v645_8);
        let v645_11: Space = if (v645_9).is_empty() { Space::new() } else {
          let v647_10: Space = routine_62(c, &(v644_12_head), &(*p1), &(v644_12_tail));
          compose(&(v645_9),&(v647_10))
        };
        drop(v645_9);
        let v645_12: Space = unite(&(v645_7),&(v645_11));
        v644_12.join_into((v645_12).clone());
      }
      drop(v644_12_cursor);
      drop(v644_11);
      compose(&(v639_10),&(v644_12))
    };
    drop(v639_10);
    let v639_14: Space = unite(&(v639_8),&(v639_13));
    v638_18.join_into((v639_14).clone());
  }
  drop(v638_18_cursor);
  drop(v638_11);
  (v638_18).clone()
}

fn routine_65(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v648_12 = Space::new();
  let mut v648_12_cursor = (*s0).read_zipper();
  for v648_12_byte in v648_12_cursor.child_mask().iter() {
    v648_12_cursor.descend_to_byte(v648_12_byte);
    let v648_12_tail = v648_12_cursor.make_map();
    v648_12_cursor.ascend(1);
    let v648_12_head = Path::from_slice(&[v648_12_byte]);
    let v649_2: Space = singleton(&(v648_12_head));
    let v649_3: Space = intersect(&(*CONSTANT_3),&(v649_2));
    let v649_4: Space = if has_head(&(v649_3)) { singleton(&[]) } else { Space::new() };
    drop(v649_3);
    let v649_5: Space = subtract(&(*CONSTANT_2),&(v649_4));
    drop(v649_4);
    let v649_8: Space = if (v649_5).is_empty() { Space::new() } else {
      let v650_6: Path = concat_path(&(*p0),&(v648_12_head));
      let mut v650_7 = Space::new();
      let mut v650_7_cursor = (v648_12_tail).read_zipper();
      for v650_7_byte in v650_7_cursor.child_mask().iter() {
        v650_7_cursor.descend_to_byte(v650_7_byte);
        let v650_7_tail = v650_7_cursor.make_map();
        v650_7_cursor.ascend(1);
        let v650_7_head = Path::from_slice(&[v650_7_byte]);
        let v651_2: Space = singleton(&(v650_7_head));
        let v651_3: Space = intersect(&(*CONSTANT_3),&(v651_2));
        let v651_4: Space = if has_head(&(v651_3)) { singleton(&[]) } else { Space::new() };
        drop(v651_3);
        let v651_5: Space = subtract(&(*CONSTANT_2),&(v651_4));
        drop(v651_4);
        let v651_8: Space = if (v651_5).is_empty() { Space::new() } else {
          let v652_6: Path = concat_path(&(v650_6),&(v650_7_head));
          let v652_7: Space = routine_110(c, &(v652_6), &(*p1), &(v650_7_tail));
          compose(&(v651_5),&(v652_7))
        };
        drop(v651_5);
        let v651_9: Space = intersect(&(*CONSTANT_3),&(v651_2));
        drop(v651_2);
        let v651_10: Space = if has_head(&(v651_9)) { singleton(&[]) } else { Space::new() };
        drop(v651_9);
        let v651_12: Space = if (v651_10).is_empty() { Space::new() } else {
          let v653_6: Path = concat_path(&(v650_6),&(v650_7_head));
          let v653_11: Space = routine_111(c, &(v653_6), &(*p1), &(v650_7_tail));
          drop(v653_6);
          compose(&(v651_10),&(v653_11))
        };
        drop(v651_10);
        let v651_13: Space = unite(&(v651_8),&(v651_12));
        v650_7.join_into((v651_13).clone());
      }
      drop(v650_7_cursor);
      compose(&(v649_5),&(v650_7))
    };
    drop(v649_5);
    let v649_9: Space = intersect(&(*CONSTANT_3),&(v649_2));
    drop(v649_2);
    let v649_10: Space = if has_head(&(v649_9)) { singleton(&[]) } else { Space::new() };
    drop(v649_9);
    let v649_12: Space = if (v649_10).is_empty() { Space::new() } else {
      let v654_6: Path = concat_path(&(*p0),&(v648_12_head));
      let mut v654_11 = Space::new();
      let mut v654_11_cursor = (v648_12_tail).read_zipper();
      for v654_11_byte in v654_11_cursor.child_mask().iter() {
        v654_11_cursor.descend_to_byte(v654_11_byte);
        let v654_11_tail = v654_11_cursor.make_map();
        v654_11_cursor.ascend(1);
        let v654_11_head = Path::from_slice(&[v654_11_byte]);
        let v655_2: Space = singleton(&(v654_11_head));
        let v655_3: Space = intersect(&(*CONSTANT_3),&(v655_2));
        let v655_4: Space = if has_head(&(v655_3)) { singleton(&[]) } else { Space::new() };
        drop(v655_3);
        let v655_5: Space = subtract(&(*CONSTANT_2),&(v655_4));
        drop(v655_4);
        let v655_8: Space = if (v655_5).is_empty() { Space::new() } else {
          let v656_6: Path = concat_path(&(v654_6),&(v654_11_head));
          let v656_7: Space = routine_110(c, &(v656_6), &(*p1), &(v654_11_tail));
          compose(&(v655_5),&(v656_7))
        };
        drop(v655_5);
        let v655_9: Space = intersect(&(*CONSTANT_3),&(v655_2));
        drop(v655_2);
        let v655_10: Space = if has_head(&(v655_9)) { singleton(&[]) } else { Space::new() };
        drop(v655_9);
        let v655_12: Space = if (v655_10).is_empty() { Space::new() } else {
          let v657_6: Path = concat_path(&(v654_6),&(v654_11_head));
          let v657_11: Space = routine_67(c, &(v657_6), &(*p1), &(v654_11_tail));
          drop(v657_6);
          compose(&(v655_10),&(v657_11))
        };
        drop(v655_10);
        let v655_13: Space = unite(&(v655_8),&(v655_12));
        v654_11.join_into((v655_13).clone());
      }
      drop(v654_11_cursor);
      drop(v654_6);
      compose(&(v649_10),&(v654_11))
    };
    drop(v649_10);
    let v649_13: Space = unite(&(v649_8),&(v649_12));
    v648_12.join_into((v649_13).clone());
  }
  drop(v648_12_cursor);
  (v648_12).clone()
}

fn routine_66(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v658_9 = Space::new();
  let mut v658_9_cursor = (*s0).read_zipper();
  for v658_9_byte in v658_9_cursor.child_mask().iter() {
    v658_9_cursor.descend_to_byte(v658_9_byte);
    let v658_9_tail = v658_9_cursor.make_map();
    v658_9_cursor.ascend(1);
    let v658_9_head = Path::from_slice(&[v658_9_byte]);
    let v659_2: Space = singleton(&(v658_9_head));
    let v659_3: Space = intersect(&(*CONSTANT_3),&(v659_2));
    let v659_4: Space = if has_head(&(v659_3)) { singleton(&[]) } else { Space::new() };
    drop(v659_3);
    let v659_5: Space = subtract(&(*CONSTANT_2),&(v659_4));
    drop(v659_4);
    let v659_8: Space = if (v659_5).is_empty() { Space::new() } else {
      let v660_6: Path = concat_path(&(*p0),&(v658_9_head));
      let mut v660_7 = Space::new();
      let mut v660_7_cursor = (v658_9_tail).read_zipper();
      for v660_7_byte in v660_7_cursor.child_mask().iter() {
        v660_7_cursor.descend_to_byte(v660_7_byte);
        let v660_7_tail = v660_7_cursor.make_map();
        v660_7_cursor.ascend(1);
        let v660_7_head = Path::from_slice(&[v660_7_byte]);
        let v661_2: Space = singleton(&(v660_7_head));
        let v661_3: Space = intersect(&(*CONSTANT_3),&(v661_2));
        let v661_4: Space = if has_head(&(v661_3)) { singleton(&[]) } else { Space::new() };
        drop(v661_3);
        let v661_5: Space = subtract(&(*CONSTANT_2),&(v661_4));
        drop(v661_4);
        let v661_8: Space = if (v661_5).is_empty() { Space::new() } else {
          let v662_6: Path = concat_path(&(v660_6),&(v660_7_head));
          let v662_7: Space = routine_110(c, &(v662_6), &(*p1), &(v660_7_tail));
          compose(&(v661_5),&(v662_7))
        };
        drop(v661_5);
        let v661_9: Space = intersect(&(*CONSTANT_3),&(v661_2));
        drop(v661_2);
        let v661_10: Space = if has_head(&(v661_9)) { singleton(&[]) } else { Space::new() };
        drop(v661_9);
        let v661_12: Space = if (v661_10).is_empty() { Space::new() } else {
          let v663_6: Path = concat_path(&(v660_6),&(v660_7_head));
          let v663_11: Space = routine_111(c, &(v663_6), &(*p1), &(v660_7_tail));
          drop(v663_6);
          compose(&(v661_10),&(v663_11))
        };
        drop(v661_10);
        let v661_13: Space = unite(&(v661_8),&(v661_12));
        v660_7.join_into((v661_13).clone());
      }
      drop(v660_7_cursor);
      compose(&(v659_5),&(v660_7))
    };
    drop(v659_5);
    let v659_9: Space = intersect(&(*CONSTANT_3),&(v659_2));
    drop(v659_2);
    let v659_10: Space = if has_head(&(v659_9)) { singleton(&[]) } else { Space::new() };
    drop(v659_9);
    let v659_11: Space = compose(&(v659_10),&(v658_9_tail));
    drop(v659_10);
    let v664_6: Path = concat_path(&(*p0),&(v658_9_head));
    let v659_12: Space = wrap(&(v659_11),&(v664_6));
    drop(v659_11);
    let v659_13: Space = wrap(&(v659_12),&(*p1));
    drop(v659_12);
    let v659_14: Space = unite(&(v659_8),&(v659_13));
    drop(v659_13);
    v658_9.join_into((v659_14).clone());
  }
  drop(v658_9_cursor);
  (v658_9).clone()
}

fn routine_67(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v665_3: Space = wrap(&(*s0),&(*p0));
  let v665_4: Space = wrap(&(v665_3),&(*p1));
  drop(v665_3);
  (v665_4).clone()
}

fn routine_68(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v666_11 = Space::new();
  let mut v666_11_cursor = (*s0).read_zipper();
  for v666_11_byte in v666_11_cursor.child_mask().iter() {
    v666_11_cursor.descend_to_byte(v666_11_byte);
    let v666_11_tail = v666_11_cursor.make_map();
    v666_11_cursor.ascend(1);
    let v666_11_head = Path::from_slice(&[v666_11_byte]);
    let v667_2: Space = singleton(&(v666_11_head));
    let v667_3: Space = intersect(&(*CONSTANT_3),&(v667_2));
    let v667_4: Space = if has_head(&(v667_3)) { singleton(&[]) } else { Space::new() };
    drop(v667_3);
    let v667_5: Space = subtract(&(*CONSTANT_2),&(v667_4));
    drop(v667_4);
    let v667_8: Space = if (v667_5).is_empty() { Space::new() } else {
      let v668_6: Path = concat_path(&(*p0),&(v666_11_head));
      let mut v668_7 = Space::new();
      let mut v668_7_cursor = (v666_11_tail).read_zipper();
      for v668_7_byte in v668_7_cursor.child_mask().iter() {
        v668_7_cursor.descend_to_byte(v668_7_byte);
        let v668_7_tail = v668_7_cursor.make_map();
        v668_7_cursor.ascend(1);
        let v668_7_head = Path::from_slice(&[v668_7_byte]);
        let v669_2: Space = singleton(&(v668_7_head));
        let v669_3: Space = intersect(&(*CONSTANT_3),&(v669_2));
        let v669_4: Space = if has_head(&(v669_3)) { singleton(&[]) } else { Space::new() };
        drop(v669_3);
        let v669_5: Space = subtract(&(*CONSTANT_2),&(v669_4));
        drop(v669_4);
        let v669_8: Space = if (v669_5).is_empty() { Space::new() } else {
          let v670_6: Path = concat_path(&(v668_6),&(v668_7_head));
          let v670_7: Space = routine_112(c, &(v670_6), &(v668_7_tail));
          compose(&(v669_5),&(v670_7))
        };
        drop(v669_5);
        let v669_9: Space = intersect(&(*CONSTANT_3),&(v669_2));
        drop(v669_2);
        let v669_10: Space = if has_head(&(v669_9)) { singleton(&[]) } else { Space::new() };
        drop(v669_9);
        let v669_12: Space = if (v669_10).is_empty() { Space::new() } else {
          let v671_6: Path = concat_path(&(v668_6),&(v668_7_head));
          let v671_11: Space = routine_113(c, &(v671_6), &(v668_7_tail));
          drop(v671_6);
          compose(&(v669_10),&(v671_11))
        };
        drop(v669_10);
        let v669_13: Space = unite(&(v669_8),&(v669_12));
        v668_7.join_into((v669_13).clone());
      }
      drop(v668_7_cursor);
      compose(&(v667_5),&(v668_7))
    };
    drop(v667_5);
    let v667_9: Space = intersect(&(*CONSTANT_3),&(v667_2));
    drop(v667_2);
    let v667_10: Space = if has_head(&(v667_9)) { singleton(&[]) } else { Space::new() };
    drop(v667_9);
    let v667_12: Space = if (v667_10).is_empty() { Space::new() } else {
      let v672_6: Path = concat_path(&(*p0),&(v666_11_head));
      let mut v672_11 = Space::new();
      let mut v672_11_cursor = (v666_11_tail).read_zipper();
      for v672_11_byte in v672_11_cursor.child_mask().iter() {
        v672_11_cursor.descend_to_byte(v672_11_byte);
        let v672_11_tail = v672_11_cursor.make_map();
        v672_11_cursor.ascend(1);
        let v672_11_head = Path::from_slice(&[v672_11_byte]);
        let v673_2: Space = singleton(&(v672_11_head));
        let v673_3: Space = intersect(&(*CONSTANT_3),&(v673_2));
        let v673_4: Space = if has_head(&(v673_3)) { singleton(&[]) } else { Space::new() };
        drop(v673_3);
        let v673_5: Space = subtract(&(*CONSTANT_2),&(v673_4));
        drop(v673_4);
        let v673_8: Space = if (v673_5).is_empty() { Space::new() } else {
          let v674_6: Path = concat_path(&(v672_6),&(v672_11_head));
          let v674_7: Space = routine_112(c, &(v674_6), &(v672_11_tail));
          compose(&(v673_5),&(v674_7))
        };
        drop(v673_5);
        let v673_9: Space = intersect(&(*CONSTANT_3),&(v673_2));
        drop(v673_2);
        let v673_10: Space = if has_head(&(v673_9)) { singleton(&[]) } else { Space::new() };
        drop(v673_9);
        let v673_12: Space = if (v673_10).is_empty() { Space::new() } else {
          let v675_6: Path = concat_path(&(v672_6),&(v672_11_head));
          let v675_11: Space = routine_9(c, &(v675_6), &(v672_11_tail));
          drop(v675_6);
          compose(&(v673_10),&(v675_11))
        };
        drop(v673_10);
        let v673_13: Space = unite(&(v673_8),&(v673_12));
        v672_11.join_into((v673_13).clone());
      }
      drop(v672_11_cursor);
      drop(v672_6);
      compose(&(v667_10),&(v672_11))
    };
    drop(v667_10);
    let v667_13: Space = unite(&(v667_8),&(v667_12));
    v666_11.join_into((v667_13).clone());
  }
  drop(v666_11_cursor);
  (v666_11).clone()
}

fn routine_69(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v676_11 = Space::new();
  let mut v676_11_cursor = (*s0).read_zipper();
  for v676_11_byte in v676_11_cursor.child_mask().iter() {
    v676_11_cursor.descend_to_byte(v676_11_byte);
    let v676_11_tail = v676_11_cursor.make_map();
    v676_11_cursor.ascend(1);
    let v676_11_head = Path::from_slice(&[v676_11_byte]);
    let v677_2: Space = singleton(&(v676_11_head));
    let v677_3: Space = intersect(&(*CONSTANT_3),&(v677_2));
    let v677_4: Space = if has_head(&(v677_3)) { singleton(&[]) } else { Space::new() };
    drop(v677_3);
    let v677_5: Space = subtract(&(*CONSTANT_2),&(v677_4));
    drop(v677_4);
    let v677_8: Space = if (v677_5).is_empty() { Space::new() } else {
      let v678_6: Path = concat_path(&(*p0),&(v676_11_head));
      let mut v678_7 = Space::new();
      let mut v678_7_cursor = (v676_11_tail).read_zipper();
      for v678_7_byte in v678_7_cursor.child_mask().iter() {
        v678_7_cursor.descend_to_byte(v678_7_byte);
        let v678_7_tail = v678_7_cursor.make_map();
        v678_7_cursor.ascend(1);
        let v678_7_head = Path::from_slice(&[v678_7_byte]);
        let v679_2: Space = singleton(&(v678_7_head));
        let v679_3: Space = intersect(&(*CONSTANT_3),&(v679_2));
        let v679_4: Space = if has_head(&(v679_3)) { singleton(&[]) } else { Space::new() };
        drop(v679_3);
        let v679_5: Space = subtract(&(*CONSTANT_2),&(v679_4));
        drop(v679_4);
        let v679_8: Space = if (v679_5).is_empty() { Space::new() } else {
          let v680_6: Path = concat_path(&(v678_6),&(v678_7_head));
          let v680_7: Space = routine_112(c, &(v680_6), &(v678_7_tail));
          compose(&(v679_5),&(v680_7))
        };
        drop(v679_5);
        let v679_9: Space = intersect(&(*CONSTANT_3),&(v679_2));
        drop(v679_2);
        let v679_10: Space = if has_head(&(v679_9)) { singleton(&[]) } else { Space::new() };
        drop(v679_9);
        let v679_12: Space = if (v679_10).is_empty() { Space::new() } else {
          let v681_6: Path = concat_path(&(v678_6),&(v678_7_head));
          let v681_11: Space = routine_113(c, &(v681_6), &(v678_7_tail));
          drop(v681_6);
          compose(&(v679_10),&(v681_11))
        };
        drop(v679_10);
        let v679_13: Space = unite(&(v679_8),&(v679_12));
        v678_7.join_into((v679_13).clone());
      }
      drop(v678_7_cursor);
      compose(&(v677_5),&(v678_7))
    };
    drop(v677_5);
    let v677_9: Space = intersect(&(*CONSTANT_3),&(v677_2));
    drop(v677_2);
    let v677_10: Space = if has_head(&(v677_9)) { singleton(&[]) } else { Space::new() };
    drop(v677_9);
    let v677_12: Space = if (v677_10).is_empty() { Space::new() } else {
      let v682_6: Path = concat_path(&(*p0),&(v676_11_head));
      let mut v682_11 = Space::new();
      let mut v682_11_cursor = (v676_11_tail).read_zipper();
      for v682_11_byte in v682_11_cursor.child_mask().iter() {
        v682_11_cursor.descend_to_byte(v682_11_byte);
        let v682_11_tail = v682_11_cursor.make_map();
        v682_11_cursor.ascend(1);
        let v682_11_head = Path::from_slice(&[v682_11_byte]);
        let v683_2: Space = singleton(&(v682_11_head));
        let v683_3: Space = intersect(&(*CONSTANT_3),&(v683_2));
        let v683_4: Space = if has_head(&(v683_3)) { singleton(&[]) } else { Space::new() };
        drop(v683_3);
        let v683_5: Space = subtract(&(*CONSTANT_2),&(v683_4));
        drop(v683_4);
        let v683_7: Space = if (v683_5).is_empty() { Space::new() } else {
          let v684_6: Space = routine_32(c, &(v682_11_head), &(v682_6), &(v682_11_tail));
          compose(&(v683_5),&(v684_6))
        };
        drop(v683_5);
        let v683_8: Space = intersect(&(*CONSTANT_3),&(v683_2));
        drop(v683_2);
        let v683_9: Space = if has_head(&(v683_8)) { singleton(&[]) } else { Space::new() };
        drop(v683_8);
        let v683_11: Space = if (v683_9).is_empty() { Space::new() } else {
          let v685_10: Space = routine_33(c, &(v682_11_head), &(v682_6), &(v682_11_tail));
          compose(&(v683_9),&(v685_10))
        };
        drop(v683_9);
        let v683_12: Space = unite(&(v683_7),&(v683_11));
        v682_11.join_into((v683_12).clone());
      }
      drop(v682_11_cursor);
      drop(v682_6);
      compose(&(v677_10),&(v682_11))
    };
    drop(v677_10);
    let v677_13: Space = unite(&(v677_8),&(v677_12));
    v676_11.join_into((v677_13).clone());
  }
  drop(v676_11_cursor);
  (v676_11).clone()
}

fn routine_70(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v686_12 = Space::new();
  let mut v686_12_cursor = (*s0).read_zipper();
  for v686_12_byte in v686_12_cursor.child_mask().iter() {
    v686_12_cursor.descend_to_byte(v686_12_byte);
    let v686_12_tail = v686_12_cursor.make_map();
    v686_12_cursor.ascend(1);
    let v686_12_head = Path::from_slice(&[v686_12_byte]);
    let v687_2: Space = singleton(&(v686_12_head));
    let v687_3: Space = intersect(&(*CONSTANT_3),&(v687_2));
    let v687_4: Space = if has_head(&(v687_3)) { singleton(&[]) } else { Space::new() };
    drop(v687_3);
    let v687_5: Space = subtract(&(*CONSTANT_2),&(v687_4));
    drop(v687_4);
    let v687_8: Space = if (v687_5).is_empty() { Space::new() } else {
      let v688_6: Path = concat_path(&(*p0),&(v686_12_head));
      let mut v688_7 = Space::new();
      let mut v688_7_cursor = (v686_12_tail).read_zipper();
      for v688_7_byte in v688_7_cursor.child_mask().iter() {
        v688_7_cursor.descend_to_byte(v688_7_byte);
        let v688_7_tail = v688_7_cursor.make_map();
        v688_7_cursor.ascend(1);
        let v688_7_head = Path::from_slice(&[v688_7_byte]);
        let v689_2: Space = singleton(&(v688_7_head));
        let v689_3: Space = intersect(&(*CONSTANT_3),&(v689_2));
        let v689_4: Space = if has_head(&(v689_3)) { singleton(&[]) } else { Space::new() };
        drop(v689_3);
        let v689_5: Space = subtract(&(*CONSTANT_2),&(v689_4));
        drop(v689_4);
        let v689_8: Space = if (v689_5).is_empty() { Space::new() } else {
          let v690_6: Path = concat_path(&(v688_6),&(v688_7_head));
          let v690_7: Space = routine_114(c, &(v690_6), &(*p1), &(v688_7_tail));
          compose(&(v689_5),&(v690_7))
        };
        drop(v689_5);
        let v689_9: Space = intersect(&(*CONSTANT_3),&(v689_2));
        drop(v689_2);
        let v689_10: Space = if has_head(&(v689_9)) { singleton(&[]) } else { Space::new() };
        drop(v689_9);
        let v689_12: Space = if (v689_10).is_empty() { Space::new() } else {
          let v691_6: Path = concat_path(&(v688_6),&(v688_7_head));
          let v691_11: Space = routine_115(c, &(v691_6), &(*p1), &(v688_7_tail));
          drop(v691_6);
          compose(&(v689_10),&(v691_11))
        };
        drop(v689_10);
        let v689_13: Space = unite(&(v689_8),&(v689_12));
        v688_7.join_into((v689_13).clone());
      }
      drop(v688_7_cursor);
      compose(&(v687_5),&(v688_7))
    };
    drop(v687_5);
    let v687_9: Space = intersect(&(*CONSTANT_3),&(v687_2));
    drop(v687_2);
    let v687_10: Space = if has_head(&(v687_9)) { singleton(&[]) } else { Space::new() };
    drop(v687_9);
    let v687_12: Space = if (v687_10).is_empty() { Space::new() } else {
      let v692_6: Path = concat_path(&(*p0),&(v686_12_head));
      let mut v692_11 = Space::new();
      let mut v692_11_cursor = (v686_12_tail).read_zipper();
      for v692_11_byte in v692_11_cursor.child_mask().iter() {
        v692_11_cursor.descend_to_byte(v692_11_byte);
        let v692_11_tail = v692_11_cursor.make_map();
        v692_11_cursor.ascend(1);
        let v692_11_head = Path::from_slice(&[v692_11_byte]);
        let v693_2: Space = singleton(&(v692_11_head));
        let v693_3: Space = intersect(&(*CONSTANT_3),&(v693_2));
        let v693_4: Space = if has_head(&(v693_3)) { singleton(&[]) } else { Space::new() };
        drop(v693_3);
        let v693_5: Space = subtract(&(*CONSTANT_2),&(v693_4));
        drop(v693_4);
        let v693_8: Space = if (v693_5).is_empty() { Space::new() } else {
          let v694_6: Path = concat_path(&(v692_6),&(v692_11_head));
          let v694_7: Space = routine_114(c, &(v694_6), &(*p1), &(v692_11_tail));
          compose(&(v693_5),&(v694_7))
        };
        drop(v693_5);
        let v693_9: Space = intersect(&(*CONSTANT_3),&(v693_2));
        drop(v693_2);
        let v693_10: Space = if has_head(&(v693_9)) { singleton(&[]) } else { Space::new() };
        drop(v693_9);
        let v693_12: Space = if (v693_10).is_empty() { Space::new() } else {
          let v695_6: Path = concat_path(&(v692_6),&(v692_11_head));
          let v695_11: Space = routine_36(c, &(v695_6), &(*p1), &(v692_11_tail));
          drop(v695_6);
          compose(&(v693_10),&(v695_11))
        };
        drop(v693_10);
        let v693_13: Space = unite(&(v693_8),&(v693_12));
        v692_11.join_into((v693_13).clone());
      }
      drop(v692_11_cursor);
      drop(v692_6);
      compose(&(v687_10),&(v692_11))
    };
    drop(v687_10);
    let v687_13: Space = unite(&(v687_8),&(v687_12));
    v686_12.join_into((v687_13).clone());
  }
  drop(v686_12_cursor);
  (v686_12).clone()
}

fn routine_71(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v696_9 = Space::new();
  let mut v696_9_cursor = (*s0).read_zipper();
  for v696_9_byte in v696_9_cursor.child_mask().iter() {
    v696_9_cursor.descend_to_byte(v696_9_byte);
    let v696_9_tail = v696_9_cursor.make_map();
    v696_9_cursor.ascend(1);
    let v696_9_head = Path::from_slice(&[v696_9_byte]);
    let v697_2: Space = singleton(&(v696_9_head));
    let v697_3: Space = intersect(&(*CONSTANT_3),&(v697_2));
    let v697_4: Space = if has_head(&(v697_3)) { singleton(&[]) } else { Space::new() };
    drop(v697_3);
    let v697_5: Space = subtract(&(*CONSTANT_2),&(v697_4));
    drop(v697_4);
    let v697_8: Space = if (v697_5).is_empty() { Space::new() } else {
      let v698_6: Path = concat_path(&(*p0),&(v696_9_head));
      let mut v698_7 = Space::new();
      let mut v698_7_cursor = (v696_9_tail).read_zipper();
      for v698_7_byte in v698_7_cursor.child_mask().iter() {
        v698_7_cursor.descend_to_byte(v698_7_byte);
        let v698_7_tail = v698_7_cursor.make_map();
        v698_7_cursor.ascend(1);
        let v698_7_head = Path::from_slice(&[v698_7_byte]);
        let v699_2: Space = singleton(&(v698_7_head));
        let v699_3: Space = intersect(&(*CONSTANT_3),&(v699_2));
        let v699_4: Space = if has_head(&(v699_3)) { singleton(&[]) } else { Space::new() };
        drop(v699_3);
        let v699_5: Space = subtract(&(*CONSTANT_2),&(v699_4));
        drop(v699_4);
        let v699_8: Space = if (v699_5).is_empty() { Space::new() } else {
          let v700_6: Path = concat_path(&(v698_6),&(v698_7_head));
          let v700_7: Space = routine_114(c, &(v700_6), &(*p1), &(v698_7_tail));
          compose(&(v699_5),&(v700_7))
        };
        drop(v699_5);
        let v699_9: Space = intersect(&(*CONSTANT_3),&(v699_2));
        drop(v699_2);
        let v699_10: Space = if has_head(&(v699_9)) { singleton(&[]) } else { Space::new() };
        drop(v699_9);
        let v699_12: Space = if (v699_10).is_empty() { Space::new() } else {
          let v701_6: Path = concat_path(&(v698_6),&(v698_7_head));
          let v701_11: Space = routine_115(c, &(v701_6), &(*p1), &(v698_7_tail));
          drop(v701_6);
          compose(&(v699_10),&(v701_11))
        };
        drop(v699_10);
        let v699_13: Space = unite(&(v699_8),&(v699_12));
        v698_7.join_into((v699_13).clone());
      }
      drop(v698_7_cursor);
      compose(&(v697_5),&(v698_7))
    };
    drop(v697_5);
    let v697_9: Space = intersect(&(*CONSTANT_3),&(v697_2));
    drop(v697_2);
    let v697_10: Space = if has_head(&(v697_9)) { singleton(&[]) } else { Space::new() };
    drop(v697_9);
    let v697_11: Space = compose(&(v697_10),&(v696_9_tail));
    drop(v697_10);
    let v702_6: Path = concat_path(&(*p0),&(v696_9_head));
    let v697_12: Space = wrap(&(v697_11),&(v702_6));
    drop(v697_11);
    let v697_13: Space = wrap(&(v697_12),&(*p1));
    drop(v697_12);
    let v697_14: Space = unite(&(v697_8),&(v697_13));
    drop(v697_13);
    v696_9.join_into((v697_14).clone());
  }
  drop(v696_9_cursor);
  (v696_9).clone()
}

fn routine_72(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v703_12 = Space::new();
  let mut v703_12_cursor = (*s0).read_zipper();
  for v703_12_byte in v703_12_cursor.child_mask().iter() {
    v703_12_cursor.descend_to_byte(v703_12_byte);
    let v703_12_tail = v703_12_cursor.make_map();
    v703_12_cursor.ascend(1);
    let v703_12_head = Path::from_slice(&[v703_12_byte]);
    let v704_2: Space = singleton(&(v703_12_head));
    let v704_3: Space = intersect(&(*CONSTANT_3),&(v704_2));
    let v704_4: Space = if has_head(&(v704_3)) { singleton(&[]) } else { Space::new() };
    drop(v704_3);
    let v704_5: Space = subtract(&(*CONSTANT_2),&(v704_4));
    drop(v704_4);
    let v704_8: Space = if (v704_5).is_empty() { Space::new() } else {
      let v705_6: Path = concat_path(&(*p0),&(v703_12_head));
      let mut v705_7 = Space::new();
      let mut v705_7_cursor = (v703_12_tail).read_zipper();
      for v705_7_byte in v705_7_cursor.child_mask().iter() {
        v705_7_cursor.descend_to_byte(v705_7_byte);
        let v705_7_tail = v705_7_cursor.make_map();
        v705_7_cursor.ascend(1);
        let v705_7_head = Path::from_slice(&[v705_7_byte]);
        let v706_2: Space = singleton(&(v705_7_head));
        let v706_3: Space = intersect(&(*CONSTANT_3),&(v706_2));
        let v706_4: Space = if has_head(&(v706_3)) { singleton(&[]) } else { Space::new() };
        drop(v706_3);
        let v706_5: Space = subtract(&(*CONSTANT_2),&(v706_4));
        drop(v706_4);
        let v706_8: Space = if (v706_5).is_empty() { Space::new() } else {
          let v707_6: Path = concat_path(&(v705_6),&(v705_7_head));
          let v707_7: Space = routine_116(c, &(v707_6), &(*p1), &(v705_7_tail));
          compose(&(v706_5),&(v707_7))
        };
        drop(v706_5);
        let v706_9: Space = intersect(&(*CONSTANT_3),&(v706_2));
        drop(v706_2);
        let v706_10: Space = if has_head(&(v706_9)) { singleton(&[]) } else { Space::new() };
        drop(v706_9);
        let v706_12: Space = if (v706_10).is_empty() { Space::new() } else {
          let v708_6: Path = concat_path(&(v705_6),&(v705_7_head));
          let v708_11: Space = routine_117(c, &(v708_6), &(*p1), &(v705_7_tail));
          drop(v708_6);
          compose(&(v706_10),&(v708_11))
        };
        drop(v706_10);
        let v706_13: Space = unite(&(v706_8),&(v706_12));
        v705_7.join_into((v706_13).clone());
      }
      drop(v705_7_cursor);
      compose(&(v704_5),&(v705_7))
    };
    drop(v704_5);
    let v704_9: Space = intersect(&(*CONSTANT_3),&(v704_2));
    drop(v704_2);
    let v704_10: Space = if has_head(&(v704_9)) { singleton(&[]) } else { Space::new() };
    drop(v704_9);
    let v704_12: Space = if (v704_10).is_empty() { Space::new() } else {
      let v709_6: Path = concat_path(&(*p0),&(v703_12_head));
      let mut v709_11 = Space::new();
      let mut v709_11_cursor = (v703_12_tail).read_zipper();
      for v709_11_byte in v709_11_cursor.child_mask().iter() {
        v709_11_cursor.descend_to_byte(v709_11_byte);
        let v709_11_tail = v709_11_cursor.make_map();
        v709_11_cursor.ascend(1);
        let v709_11_head = Path::from_slice(&[v709_11_byte]);
        let v710_2: Space = singleton(&(v709_11_head));
        let v710_3: Space = intersect(&(*CONSTANT_3),&(v710_2));
        let v710_4: Space = if has_head(&(v710_3)) { singleton(&[]) } else { Space::new() };
        drop(v710_3);
        let v710_5: Space = subtract(&(*CONSTANT_2),&(v710_4));
        drop(v710_4);
        let v710_8: Space = if (v710_5).is_empty() { Space::new() } else {
          let v711_6: Path = concat_path(&(v709_6),&(v709_11_head));
          let v711_7: Space = routine_116(c, &(v711_6), &(*p1), &(v709_11_tail));
          compose(&(v710_5),&(v711_7))
        };
        drop(v710_5);
        let v710_9: Space = intersect(&(*CONSTANT_3),&(v710_2));
        drop(v710_2);
        let v710_10: Space = if has_head(&(v710_9)) { singleton(&[]) } else { Space::new() };
        drop(v710_9);
        let v710_12: Space = if (v710_10).is_empty() { Space::new() } else {
          let v712_6: Path = concat_path(&(v709_6),&(v709_11_head));
          let v712_11: Space = routine_36(c, &(v712_6), &(*p1), &(v709_11_tail));
          drop(v712_6);
          compose(&(v710_10),&(v712_11))
        };
        drop(v710_10);
        let v710_13: Space = unite(&(v710_8),&(v710_12));
        v709_11.join_into((v710_13).clone());
      }
      drop(v709_11_cursor);
      drop(v709_6);
      compose(&(v704_10),&(v709_11))
    };
    drop(v704_10);
    let v704_13: Space = unite(&(v704_8),&(v704_12));
    v703_12.join_into((v704_13).clone());
  }
  drop(v703_12_cursor);
  (v703_12).clone()
}

fn routine_73(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v713_9 = Space::new();
  let mut v713_9_cursor = (*s0).read_zipper();
  for v713_9_byte in v713_9_cursor.child_mask().iter() {
    v713_9_cursor.descend_to_byte(v713_9_byte);
    let v713_9_tail = v713_9_cursor.make_map();
    v713_9_cursor.ascend(1);
    let v713_9_head = Path::from_slice(&[v713_9_byte]);
    let v714_2: Space = singleton(&(v713_9_head));
    let v714_3: Space = intersect(&(*CONSTANT_3),&(v714_2));
    let v714_4: Space = if has_head(&(v714_3)) { singleton(&[]) } else { Space::new() };
    drop(v714_3);
    let v714_5: Space = subtract(&(*CONSTANT_2),&(v714_4));
    drop(v714_4);
    let v714_8: Space = if (v714_5).is_empty() { Space::new() } else {
      let v715_6: Path = concat_path(&(*p0),&(v713_9_head));
      let mut v715_7 = Space::new();
      let mut v715_7_cursor = (v713_9_tail).read_zipper();
      for v715_7_byte in v715_7_cursor.child_mask().iter() {
        v715_7_cursor.descend_to_byte(v715_7_byte);
        let v715_7_tail = v715_7_cursor.make_map();
        v715_7_cursor.ascend(1);
        let v715_7_head = Path::from_slice(&[v715_7_byte]);
        let v716_2: Space = singleton(&(v715_7_head));
        let v716_3: Space = intersect(&(*CONSTANT_3),&(v716_2));
        let v716_4: Space = if has_head(&(v716_3)) { singleton(&[]) } else { Space::new() };
        drop(v716_3);
        let v716_5: Space = subtract(&(*CONSTANT_2),&(v716_4));
        drop(v716_4);
        let v716_8: Space = if (v716_5).is_empty() { Space::new() } else {
          let v717_6: Path = concat_path(&(v715_6),&(v715_7_head));
          let v717_7: Space = routine_116(c, &(v717_6), &(*p1), &(v715_7_tail));
          compose(&(v716_5),&(v717_7))
        };
        drop(v716_5);
        let v716_9: Space = intersect(&(*CONSTANT_3),&(v716_2));
        drop(v716_2);
        let v716_10: Space = if has_head(&(v716_9)) { singleton(&[]) } else { Space::new() };
        drop(v716_9);
        let v716_12: Space = if (v716_10).is_empty() { Space::new() } else {
          let v718_6: Path = concat_path(&(v715_6),&(v715_7_head));
          let v718_11: Space = routine_117(c, &(v718_6), &(*p1), &(v715_7_tail));
          drop(v718_6);
          compose(&(v716_10),&(v718_11))
        };
        drop(v716_10);
        let v716_13: Space = unite(&(v716_8),&(v716_12));
        v715_7.join_into((v716_13).clone());
      }
      drop(v715_7_cursor);
      compose(&(v714_5),&(v715_7))
    };
    drop(v714_5);
    let v714_9: Space = intersect(&(*CONSTANT_3),&(v714_2));
    drop(v714_2);
    let v714_10: Space = if has_head(&(v714_9)) { singleton(&[]) } else { Space::new() };
    drop(v714_9);
    let v714_11: Space = compose(&(v714_10),&(v713_9_tail));
    drop(v714_10);
    let v719_6: Path = concat_path(&(*p0),&(v713_9_head));
    let v714_12: Space = wrap(&(v714_11),&(v719_6));
    drop(v714_11);
    let v714_13: Space = wrap(&(v714_12),&(*p1));
    drop(v714_12);
    let v714_14: Space = unite(&(v714_8),&(v714_13));
    drop(v714_13);
    v713_9.join_into((v714_14).clone());
  }
  drop(v713_9_cursor);
  (v713_9).clone()
}

fn routine_74(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v720_12 = Space::new();
  let mut v720_12_cursor = (*s0).read_zipper();
  for v720_12_byte in v720_12_cursor.child_mask().iter() {
    v720_12_cursor.descend_to_byte(v720_12_byte);
    let v720_12_tail = v720_12_cursor.make_map();
    v720_12_cursor.ascend(1);
    let v720_12_head = Path::from_slice(&[v720_12_byte]);
    let v721_2: Space = singleton(&(v720_12_head));
    let v721_3: Space = intersect(&(*CONSTANT_3),&(v721_2));
    let v721_4: Space = if has_head(&(v721_3)) { singleton(&[]) } else { Space::new() };
    drop(v721_3);
    let v721_5: Space = subtract(&(*CONSTANT_2),&(v721_4));
    drop(v721_4);
    let v721_8: Space = if (v721_5).is_empty() { Space::new() } else {
      let v722_6: Path = concat_path(&(*p0),&(v720_12_head));
      let mut v722_7 = Space::new();
      let mut v722_7_cursor = (v720_12_tail).read_zipper();
      for v722_7_byte in v722_7_cursor.child_mask().iter() {
        v722_7_cursor.descend_to_byte(v722_7_byte);
        let v722_7_tail = v722_7_cursor.make_map();
        v722_7_cursor.ascend(1);
        let v722_7_head = Path::from_slice(&[v722_7_byte]);
        let v723_2: Space = singleton(&(v722_7_head));
        let v723_3: Space = intersect(&(*CONSTANT_3),&(v723_2));
        let v723_4: Space = if has_head(&(v723_3)) { singleton(&[]) } else { Space::new() };
        drop(v723_3);
        let v723_5: Space = subtract(&(*CONSTANT_2),&(v723_4));
        drop(v723_4);
        let v723_8: Space = if (v723_5).is_empty() { Space::new() } else {
          let v724_6: Path = concat_path(&(v722_6),&(v722_7_head));
          let v724_7: Space = routine_118(c, &(v724_6), &(v722_7_tail), &(*s1));
          compose(&(v723_5),&(v724_7))
        };
        drop(v723_5);
        let v723_9: Space = intersect(&(*CONSTANT_3),&(v723_2));
        drop(v723_2);
        let v723_10: Space = if has_head(&(v723_9)) { singleton(&[]) } else { Space::new() };
        drop(v723_9);
        let v723_12: Space = if (v723_10).is_empty() { Space::new() } else {
          let v725_6: Path = concat_path(&(v722_6),&(v722_7_head));
          let v725_11: Space = routine_119(c, &(v725_6), &(v722_7_tail), &(*s1));
          drop(v725_6);
          compose(&(v723_10),&(v725_11))
        };
        drop(v723_10);
        let v723_13: Space = unite(&(v723_8),&(v723_12));
        v722_7.join_into((v723_13).clone());
      }
      drop(v722_7_cursor);
      compose(&(v721_5),&(v722_7))
    };
    drop(v721_5);
    let v721_9: Space = intersect(&(*CONSTANT_3),&(v721_2));
    drop(v721_2);
    let v721_10: Space = if has_head(&(v721_9)) { singleton(&[]) } else { Space::new() };
    drop(v721_9);
    let v721_12: Space = if (v721_10).is_empty() { Space::new() } else {
      let v726_6: Path = concat_path(&(*p0),&(v720_12_head));
      let mut v726_11 = Space::new();
      let mut v726_11_cursor = (v720_12_tail).read_zipper();
      for v726_11_byte in v726_11_cursor.child_mask().iter() {
        v726_11_cursor.descend_to_byte(v726_11_byte);
        let v726_11_tail = v726_11_cursor.make_map();
        v726_11_cursor.ascend(1);
        let v726_11_head = Path::from_slice(&[v726_11_byte]);
        let v727_2: Space = singleton(&(v726_11_head));
        let v727_3: Space = intersect(&(*CONSTANT_3),&(v727_2));
        let v727_4: Space = if has_head(&(v727_3)) { singleton(&[]) } else { Space::new() };
        drop(v727_3);
        let v727_5: Space = subtract(&(*CONSTANT_2),&(v727_4));
        drop(v727_4);
        let v727_8: Space = if (v727_5).is_empty() { Space::new() } else {
          let v728_6: Path = concat_path(&(v726_6),&(v726_11_head));
          let v728_7: Space = routine_118(c, &(v728_6), &(v726_11_tail), &(*s1));
          compose(&(v727_5),&(v728_7))
        };
        drop(v727_5);
        let v727_9: Space = intersect(&(*CONSTANT_3),&(v727_2));
        drop(v727_2);
        let v727_10: Space = if has_head(&(v727_9)) { singleton(&[]) } else { Space::new() };
        drop(v727_9);
        let v727_12: Space = if (v727_10).is_empty() { Space::new() } else {
          let v729_6: Path = concat_path(&(v726_6),&(v726_11_head));
          let v729_11: Space = routine_12(c, &(v729_6), &(v726_11_tail), &(*s1));
          drop(v729_6);
          compose(&(v727_10),&(v729_11))
        };
        drop(v727_10);
        let v727_13: Space = unite(&(v727_8),&(v727_12));
        v726_11.join_into((v727_13).clone());
      }
      drop(v726_11_cursor);
      drop(v726_6);
      compose(&(v721_10),&(v726_11))
    };
    drop(v721_10);
    let v721_13: Space = unite(&(v721_8),&(v721_12));
    v720_12.join_into((v721_13).clone());
  }
  drop(v720_12_cursor);
  (v720_12).clone()
}

fn routine_75(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v730_12 = Space::new();
  let mut v730_12_cursor = (*s0).read_zipper();
  for v730_12_byte in v730_12_cursor.child_mask().iter() {
    v730_12_cursor.descend_to_byte(v730_12_byte);
    let v730_12_tail = v730_12_cursor.make_map();
    v730_12_cursor.ascend(1);
    let v730_12_head = Path::from_slice(&[v730_12_byte]);
    let v731_2: Space = singleton(&(v730_12_head));
    let v731_3: Space = intersect(&(*CONSTANT_3),&(v731_2));
    let v731_4: Space = if has_head(&(v731_3)) { singleton(&[]) } else { Space::new() };
    drop(v731_3);
    let v731_5: Space = subtract(&(*CONSTANT_2),&(v731_4));
    drop(v731_4);
    let v731_8: Space = if (v731_5).is_empty() { Space::new() } else {
      let v732_6: Path = concat_path(&(*p0),&(v730_12_head));
      let mut v732_7 = Space::new();
      let mut v732_7_cursor = (v730_12_tail).read_zipper();
      for v732_7_byte in v732_7_cursor.child_mask().iter() {
        v732_7_cursor.descend_to_byte(v732_7_byte);
        let v732_7_tail = v732_7_cursor.make_map();
        v732_7_cursor.ascend(1);
        let v732_7_head = Path::from_slice(&[v732_7_byte]);
        let v733_2: Space = singleton(&(v732_7_head));
        let v733_3: Space = intersect(&(*CONSTANT_3),&(v733_2));
        let v733_4: Space = if has_head(&(v733_3)) { singleton(&[]) } else { Space::new() };
        drop(v733_3);
        let v733_5: Space = subtract(&(*CONSTANT_2),&(v733_4));
        drop(v733_4);
        let v733_8: Space = if (v733_5).is_empty() { Space::new() } else {
          let v734_6: Path = concat_path(&(v732_6),&(v732_7_head));
          let v734_7: Space = routine_118(c, &(v734_6), &(v732_7_tail), &(*s1));
          compose(&(v733_5),&(v734_7))
        };
        drop(v733_5);
        let v733_9: Space = intersect(&(*CONSTANT_3),&(v733_2));
        drop(v733_2);
        let v733_10: Space = if has_head(&(v733_9)) { singleton(&[]) } else { Space::new() };
        drop(v733_9);
        let v733_12: Space = if (v733_10).is_empty() { Space::new() } else {
          let v735_6: Path = concat_path(&(v732_6),&(v732_7_head));
          let v735_11: Space = routine_119(c, &(v735_6), &(v732_7_tail), &(*s1));
          drop(v735_6);
          compose(&(v733_10),&(v735_11))
        };
        drop(v733_10);
        let v733_13: Space = unite(&(v733_8),&(v733_12));
        v732_7.join_into((v733_13).clone());
      }
      drop(v732_7_cursor);
      compose(&(v731_5),&(v732_7))
    };
    drop(v731_5);
    let v731_9: Space = intersect(&(*CONSTANT_3),&(v731_2));
    drop(v731_2);
    let v731_10: Space = if has_head(&(v731_9)) { singleton(&[]) } else { Space::new() };
    drop(v731_9);
    let v731_12: Space = if (v731_10).is_empty() { Space::new() } else {
      let v736_6: Path = concat_path(&(*p0),&(v730_12_head));
      let mut v736_11 = Space::new();
      let mut v736_11_cursor = (v730_12_tail).read_zipper();
      for v736_11_byte in v736_11_cursor.child_mask().iter() {
        v736_11_cursor.descend_to_byte(v736_11_byte);
        let v736_11_tail = v736_11_cursor.make_map();
        v736_11_cursor.ascend(1);
        let v736_11_head = Path::from_slice(&[v736_11_byte]);
        let v737_2: Space = singleton(&(v736_11_head));
        let v737_3: Space = intersect(&(*CONSTANT_3),&(v737_2));
        let v737_4: Space = if has_head(&(v737_3)) { singleton(&[]) } else { Space::new() };
        drop(v737_3);
        let v737_5: Space = subtract(&(*CONSTANT_2),&(v737_4));
        drop(v737_4);
        let v737_7: Space = if (v737_5).is_empty() { Space::new() } else {
          let v738_6: Space = routine_39(c, &(v736_11_head), &(v736_6), &(v736_11_tail), &(*s1));
          compose(&(v737_5),&(v738_6))
        };
        drop(v737_5);
        let v737_8: Space = intersect(&(*CONSTANT_3),&(v737_2));
        drop(v737_2);
        let v737_9: Space = if has_head(&(v737_8)) { singleton(&[]) } else { Space::new() };
        drop(v737_8);
        let v737_11: Space = if (v737_9).is_empty() { Space::new() } else {
          let v739_10: Space = routine_40(c, &(v736_11_head), &(v736_6), &(v736_11_tail), &(*s1));
          compose(&(v737_9),&(v739_10))
        };
        drop(v737_9);
        let v737_12: Space = unite(&(v737_7),&(v737_11));
        v736_11.join_into((v737_12).clone());
      }
      drop(v736_11_cursor);
      drop(v736_6);
      compose(&(v731_10),&(v736_11))
    };
    drop(v731_10);
    let v731_13: Space = unite(&(v731_8),&(v731_12));
    v730_12.join_into((v731_13).clone());
  }
  drop(v730_12_cursor);
  (v730_12).clone()
}

fn routine_76(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v740_13 = Space::new();
  let mut v740_13_cursor = (*s0).read_zipper();
  for v740_13_byte in v740_13_cursor.child_mask().iter() {
    v740_13_cursor.descend_to_byte(v740_13_byte);
    let v740_13_tail = v740_13_cursor.make_map();
    v740_13_cursor.ascend(1);
    let v740_13_head = Path::from_slice(&[v740_13_byte]);
    let v741_2: Space = singleton(&(v740_13_head));
    let v741_3: Space = intersect(&(*CONSTANT_3),&(v741_2));
    let v741_4: Space = if has_head(&(v741_3)) { singleton(&[]) } else { Space::new() };
    drop(v741_3);
    let v741_5: Space = subtract(&(*CONSTANT_2),&(v741_4));
    drop(v741_4);
    let v741_8: Space = if (v741_5).is_empty() { Space::new() } else {
      let v742_6: Path = concat_path(&(*p0),&(v740_13_head));
      let mut v742_7 = Space::new();
      let mut v742_7_cursor = (v740_13_tail).read_zipper();
      for v742_7_byte in v742_7_cursor.child_mask().iter() {
        v742_7_cursor.descend_to_byte(v742_7_byte);
        let v742_7_tail = v742_7_cursor.make_map();
        v742_7_cursor.ascend(1);
        let v742_7_head = Path::from_slice(&[v742_7_byte]);
        let v743_2: Space = singleton(&(v742_7_head));
        let v743_3: Space = intersect(&(*CONSTANT_3),&(v743_2));
        let v743_4: Space = if has_head(&(v743_3)) { singleton(&[]) } else { Space::new() };
        drop(v743_3);
        let v743_5: Space = subtract(&(*CONSTANT_2),&(v743_4));
        drop(v743_4);
        let v743_8: Space = if (v743_5).is_empty() { Space::new() } else {
          let v744_6: Path = concat_path(&(v742_6),&(v742_7_head));
          let v744_7: Space = routine_120(c, &(v744_6), &(*p1), &(v742_7_tail), &(*s1));
          compose(&(v743_5),&(v744_7))
        };
        drop(v743_5);
        let v743_9: Space = intersect(&(*CONSTANT_3),&(v743_2));
        drop(v743_2);
        let v743_10: Space = if has_head(&(v743_9)) { singleton(&[]) } else { Space::new() };
        drop(v743_9);
        let v743_12: Space = if (v743_10).is_empty() { Space::new() } else {
          let v745_6: Path = concat_path(&(v742_6),&(v742_7_head));
          let v745_11: Space = routine_121(c, &(v745_6), &(*p1), &(v742_7_tail), &(*s1));
          drop(v745_6);
          compose(&(v743_10),&(v745_11))
        };
        drop(v743_10);
        let v743_13: Space = unite(&(v743_8),&(v743_12));
        v742_7.join_into((v743_13).clone());
      }
      drop(v742_7_cursor);
      compose(&(v741_5),&(v742_7))
    };
    drop(v741_5);
    let v741_9: Space = intersect(&(*CONSTANT_3),&(v741_2));
    drop(v741_2);
    let v741_10: Space = if has_head(&(v741_9)) { singleton(&[]) } else { Space::new() };
    drop(v741_9);
    let v741_12: Space = if (v741_10).is_empty() { Space::new() } else {
      let v746_6: Path = concat_path(&(*p0),&(v740_13_head));
      let mut v746_11 = Space::new();
      let mut v746_11_cursor = (v740_13_tail).read_zipper();
      for v746_11_byte in v746_11_cursor.child_mask().iter() {
        v746_11_cursor.descend_to_byte(v746_11_byte);
        let v746_11_tail = v746_11_cursor.make_map();
        v746_11_cursor.ascend(1);
        let v746_11_head = Path::from_slice(&[v746_11_byte]);
        let v747_2: Space = singleton(&(v746_11_head));
        let v747_3: Space = intersect(&(*CONSTANT_3),&(v747_2));
        let v747_4: Space = if has_head(&(v747_3)) { singleton(&[]) } else { Space::new() };
        drop(v747_3);
        let v747_5: Space = subtract(&(*CONSTANT_2),&(v747_4));
        drop(v747_4);
        let v747_8: Space = if (v747_5).is_empty() { Space::new() } else {
          let v748_6: Path = concat_path(&(v746_6),&(v746_11_head));
          let v748_7: Space = routine_120(c, &(v748_6), &(*p1), &(v746_11_tail), &(*s1));
          compose(&(v747_5),&(v748_7))
        };
        drop(v747_5);
        let v747_9: Space = intersect(&(*CONSTANT_3),&(v747_2));
        drop(v747_2);
        let v747_10: Space = if has_head(&(v747_9)) { singleton(&[]) } else { Space::new() };
        drop(v747_9);
        let v747_12: Space = if (v747_10).is_empty() { Space::new() } else {
          let v749_6: Path = concat_path(&(v746_6),&(v746_11_head));
          let v749_11: Space = routine_43(c, &(v749_6), &(*p1), &(v746_11_tail), &(*s1));
          drop(v749_6);
          compose(&(v747_10),&(v749_11))
        };
        drop(v747_10);
        let v747_13: Space = unite(&(v747_8),&(v747_12));
        v746_11.join_into((v747_13).clone());
      }
      drop(v746_11_cursor);
      drop(v746_6);
      compose(&(v741_10),&(v746_11))
    };
    drop(v741_10);
    let v741_13: Space = unite(&(v741_8),&(v741_12));
    v740_13.join_into((v741_13).clone());
  }
  drop(v740_13_cursor);
  (v740_13).clone()
}

fn routine_77(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v750_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v750_10: Space = unwrap(&(v750_8),&(*CONSTANT_5));
  drop(v750_8);
  let v750_11: Space = unwrap(&(v750_10),&(*p0));
  drop(v750_10);
  let mut v750_18 = Space::new();
  let mut v750_18_cursor = (*s0).read_zipper();
  for v750_18_byte in v750_18_cursor.child_mask().iter() {
    v750_18_cursor.descend_to_byte(v750_18_byte);
    let v750_18_tail = v750_18_cursor.make_map();
    v750_18_cursor.ascend(1);
    let v750_18_head = Path::from_slice(&[v750_18_byte]);
    let v751_2: Space = singleton(&(v750_18_head));
    let v751_3: Space = intersect(&(*CONSTANT_3),&(v751_2));
    let v751_4: Space = if has_head(&(v751_3)) { singleton(&[]) } else { Space::new() };
    drop(v751_3);
    let v751_5: Space = subtract(&(*CONSTANT_2),&(v751_4));
    drop(v751_4);
    let v751_8: Space = if (v751_5).is_empty() { Space::new() } else {
      let v752_6: Path = concat_path(&(*p0),&(v750_18_head));
      let mut v752_7 = Space::new();
      let mut v752_7_cursor = (v750_18_tail).read_zipper();
      for v752_7_byte in v752_7_cursor.child_mask().iter() {
        v752_7_cursor.descend_to_byte(v752_7_byte);
        let v752_7_tail = v752_7_cursor.make_map();
        v752_7_cursor.ascend(1);
        let v752_7_head = Path::from_slice(&[v752_7_byte]);
        let v753_2: Space = singleton(&(v752_7_head));
        let v753_3: Space = intersect(&(*CONSTANT_3),&(v753_2));
        let v753_4: Space = if has_head(&(v753_3)) { singleton(&[]) } else { Space::new() };
        drop(v753_3);
        let v753_5: Space = subtract(&(*CONSTANT_2),&(v753_4));
        drop(v753_4);
        let v753_8: Space = if (v753_5).is_empty() { Space::new() } else {
          let v754_6: Path = concat_path(&(v752_6),&(v752_7_head));
          let v754_7: Space = routine_120(c, &(v754_6), &(*p1), &(v752_7_tail), &(*s1));
          compose(&(v753_5),&(v754_7))
        };
        drop(v753_5);
        let v753_9: Space = intersect(&(*CONSTANT_3),&(v753_2));
        drop(v753_2);
        let v753_10: Space = if has_head(&(v753_9)) { singleton(&[]) } else { Space::new() };
        drop(v753_9);
        let v753_12: Space = if (v753_10).is_empty() { Space::new() } else {
          let v755_6: Path = concat_path(&(v752_6),&(v752_7_head));
          let v755_11: Space = routine_121(c, &(v755_6), &(*p1), &(v752_7_tail), &(*s1));
          drop(v755_6);
          compose(&(v753_10),&(v755_11))
        };
        drop(v753_10);
        let v753_13: Space = unite(&(v753_8),&(v753_12));
        v752_7.join_into((v753_13).clone());
      }
      drop(v752_7_cursor);
      drop(v752_6);
      compose(&(v751_5),&(v752_7))
    };
    drop(v751_5);
    let v751_9: Space = intersect(&(*CONSTANT_3),&(v751_2));
    drop(v751_2);
    let v751_10: Space = if has_head(&(v751_9)) { singleton(&[]) } else { Space::new() };
    drop(v751_9);
    let v751_13: Space = if (v751_10).is_empty() { Space::new() } else {
      let v756_11: Space = unwrap(&(v750_11),&(v750_18_head));
      let mut v756_12 = Space::new();
      let mut v756_12_cursor = (v756_11).read_zipper();
      for v756_12_byte in v756_12_cursor.child_mask().iter() {
        v756_12_cursor.descend_to_byte(v756_12_byte);
        let v756_12_tail = v756_12_cursor.make_map();
        v756_12_cursor.ascend(1);
        let v756_12_head = Path::from_slice(&[v756_12_byte]);
        let v757_2: Space = singleton(&(v756_12_head));
        let v757_3: Space = intersect(&(*CONSTANT_3),&(v757_2));
        let v757_4: Space = if has_head(&(v757_3)) { singleton(&[]) } else { Space::new() };
        drop(v757_3);
        let v757_5: Space = subtract(&(*CONSTANT_2),&(v757_4));
        drop(v757_4);
        let v757_7: Space = if (v757_5).is_empty() { Space::new() } else {
          let v758_6: Space = routine_78(c, &(v756_12_head), &(*p1), &(v756_12_tail));
          compose(&(v757_5),&(v758_6))
        };
        drop(v757_5);
        let v757_8: Space = intersect(&(*CONSTANT_3),&(v757_2));
        drop(v757_2);
        let v757_9: Space = if has_head(&(v757_8)) { singleton(&[]) } else { Space::new() };
        drop(v757_8);
        let v757_11: Space = if (v757_9).is_empty() { Space::new() } else {
          let v759_10: Space = routine_79(c, &(v756_12_head), &(*p1), &(v756_12_tail));
          compose(&(v757_9),&(v759_10))
        };
        drop(v757_9);
        let v757_12: Space = unite(&(v757_7),&(v757_11));
        v756_12.join_into((v757_12).clone());
      }
      drop(v756_12_cursor);
      drop(v756_11);
      compose(&(v751_10),&(v756_12))
    };
    drop(v751_10);
    let v751_14: Space = unite(&(v751_8),&(v751_13));
    v750_18.join_into((v751_14).clone());
  }
  drop(v750_18_cursor);
  drop(v750_11);
  (v750_18).clone()
}

fn routine_78(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v760_12 = Space::new();
  let mut v760_12_cursor = (*s0).read_zipper();
  for v760_12_byte in v760_12_cursor.child_mask().iter() {
    v760_12_cursor.descend_to_byte(v760_12_byte);
    let v760_12_tail = v760_12_cursor.make_map();
    v760_12_cursor.ascend(1);
    let v760_12_head = Path::from_slice(&[v760_12_byte]);
    let v761_2: Space = singleton(&(v760_12_head));
    let v761_3: Space = intersect(&(*CONSTANT_3),&(v761_2));
    let v761_4: Space = if has_head(&(v761_3)) { singleton(&[]) } else { Space::new() };
    drop(v761_3);
    let v761_5: Space = subtract(&(*CONSTANT_2),&(v761_4));
    drop(v761_4);
    let v761_8: Space = if (v761_5).is_empty() { Space::new() } else {
      let v762_6: Path = concat_path(&(*p0),&(v760_12_head));
      let mut v762_7 = Space::new();
      let mut v762_7_cursor = (v760_12_tail).read_zipper();
      for v762_7_byte in v762_7_cursor.child_mask().iter() {
        v762_7_cursor.descend_to_byte(v762_7_byte);
        let v762_7_tail = v762_7_cursor.make_map();
        v762_7_cursor.ascend(1);
        let v762_7_head = Path::from_slice(&[v762_7_byte]);
        let v763_2: Space = singleton(&(v762_7_head));
        let v763_3: Space = intersect(&(*CONSTANT_3),&(v763_2));
        let v763_4: Space = if has_head(&(v763_3)) { singleton(&[]) } else { Space::new() };
        drop(v763_3);
        let v763_5: Space = subtract(&(*CONSTANT_2),&(v763_4));
        drop(v763_4);
        let v763_8: Space = if (v763_5).is_empty() { Space::new() } else {
          let v764_6: Path = concat_path(&(v762_6),&(v762_7_head));
          let v764_7: Space = routine_122(c, &(v764_6), &(*p1), &(v762_7_tail));
          compose(&(v763_5),&(v764_7))
        };
        drop(v763_5);
        let v763_9: Space = intersect(&(*CONSTANT_3),&(v763_2));
        drop(v763_2);
        let v763_10: Space = if has_head(&(v763_9)) { singleton(&[]) } else { Space::new() };
        drop(v763_9);
        let v763_12: Space = if (v763_10).is_empty() { Space::new() } else {
          let v765_6: Path = concat_path(&(v762_6),&(v762_7_head));
          let v765_11: Space = routine_123(c, &(v765_6), &(*p1), &(v762_7_tail));
          drop(v765_6);
          compose(&(v763_10),&(v765_11))
        };
        drop(v763_10);
        let v763_13: Space = unite(&(v763_8),&(v763_12));
        v762_7.join_into((v763_13).clone());
      }
      drop(v762_7_cursor);
      compose(&(v761_5),&(v762_7))
    };
    drop(v761_5);
    let v761_9: Space = intersect(&(*CONSTANT_3),&(v761_2));
    drop(v761_2);
    let v761_10: Space = if has_head(&(v761_9)) { singleton(&[]) } else { Space::new() };
    drop(v761_9);
    let v761_12: Space = if (v761_10).is_empty() { Space::new() } else {
      let v766_6: Path = concat_path(&(*p0),&(v760_12_head));
      let mut v766_11 = Space::new();
      let mut v766_11_cursor = (v760_12_tail).read_zipper();
      for v766_11_byte in v766_11_cursor.child_mask().iter() {
        v766_11_cursor.descend_to_byte(v766_11_byte);
        let v766_11_tail = v766_11_cursor.make_map();
        v766_11_cursor.ascend(1);
        let v766_11_head = Path::from_slice(&[v766_11_byte]);
        let v767_2: Space = singleton(&(v766_11_head));
        let v767_3: Space = intersect(&(*CONSTANT_3),&(v767_2));
        let v767_4: Space = if has_head(&(v767_3)) { singleton(&[]) } else { Space::new() };
        drop(v767_3);
        let v767_5: Space = subtract(&(*CONSTANT_2),&(v767_4));
        drop(v767_4);
        let v767_8: Space = if (v767_5).is_empty() { Space::new() } else {
          let v768_6: Path = concat_path(&(v766_6),&(v766_11_head));
          let v768_7: Space = routine_122(c, &(v768_6), &(*p1), &(v766_11_tail));
          compose(&(v767_5),&(v768_7))
        };
        drop(v767_5);
        let v767_9: Space = intersect(&(*CONSTANT_3),&(v767_2));
        drop(v767_2);
        let v767_10: Space = if has_head(&(v767_9)) { singleton(&[]) } else { Space::new() };
        drop(v767_9);
        let v767_12: Space = if (v767_10).is_empty() { Space::new() } else {
          let v769_6: Path = concat_path(&(v766_6),&(v766_11_head));
          let v769_11: Space = routine_84(c, &(v769_6), &(*p1), &(v766_11_tail));
          drop(v769_6);
          compose(&(v767_10),&(v769_11))
        };
        drop(v767_10);
        let v767_13: Space = unite(&(v767_8),&(v767_12));
        v766_11.join_into((v767_13).clone());
      }
      drop(v766_11_cursor);
      drop(v766_6);
      compose(&(v761_10),&(v766_11))
    };
    drop(v761_10);
    let v761_13: Space = unite(&(v761_8),&(v761_12));
    v760_12.join_into((v761_13).clone());
  }
  drop(v760_12_cursor);
  (v760_12).clone()
}

fn routine_79(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v770_9 = Space::new();
  let mut v770_9_cursor = (*s0).read_zipper();
  for v770_9_byte in v770_9_cursor.child_mask().iter() {
    v770_9_cursor.descend_to_byte(v770_9_byte);
    let v770_9_tail = v770_9_cursor.make_map();
    v770_9_cursor.ascend(1);
    let v770_9_head = Path::from_slice(&[v770_9_byte]);
    let v771_2: Space = singleton(&(v770_9_head));
    let v771_3: Space = intersect(&(*CONSTANT_3),&(v771_2));
    let v771_4: Space = if has_head(&(v771_3)) { singleton(&[]) } else { Space::new() };
    drop(v771_3);
    let v771_5: Space = subtract(&(*CONSTANT_2),&(v771_4));
    drop(v771_4);
    let v771_8: Space = if (v771_5).is_empty() { Space::new() } else {
      let v772_6: Path = concat_path(&(*p0),&(v770_9_head));
      let mut v772_7 = Space::new();
      let mut v772_7_cursor = (v770_9_tail).read_zipper();
      for v772_7_byte in v772_7_cursor.child_mask().iter() {
        v772_7_cursor.descend_to_byte(v772_7_byte);
        let v772_7_tail = v772_7_cursor.make_map();
        v772_7_cursor.ascend(1);
        let v772_7_head = Path::from_slice(&[v772_7_byte]);
        let v773_2: Space = singleton(&(v772_7_head));
        let v773_3: Space = intersect(&(*CONSTANT_3),&(v773_2));
        let v773_4: Space = if has_head(&(v773_3)) { singleton(&[]) } else { Space::new() };
        drop(v773_3);
        let v773_5: Space = subtract(&(*CONSTANT_2),&(v773_4));
        drop(v773_4);
        let v773_8: Space = if (v773_5).is_empty() { Space::new() } else {
          let v774_6: Path = concat_path(&(v772_6),&(v772_7_head));
          let v774_7: Space = routine_122(c, &(v774_6), &(*p1), &(v772_7_tail));
          compose(&(v773_5),&(v774_7))
        };
        drop(v773_5);
        let v773_9: Space = intersect(&(*CONSTANT_3),&(v773_2));
        drop(v773_2);
        let v773_10: Space = if has_head(&(v773_9)) { singleton(&[]) } else { Space::new() };
        drop(v773_9);
        let v773_12: Space = if (v773_10).is_empty() { Space::new() } else {
          let v775_6: Path = concat_path(&(v772_6),&(v772_7_head));
          let v775_11: Space = routine_123(c, &(v775_6), &(*p1), &(v772_7_tail));
          drop(v775_6);
          compose(&(v773_10),&(v775_11))
        };
        drop(v773_10);
        let v773_13: Space = unite(&(v773_8),&(v773_12));
        v772_7.join_into((v773_13).clone());
      }
      drop(v772_7_cursor);
      compose(&(v771_5),&(v772_7))
    };
    drop(v771_5);
    let v771_9: Space = intersect(&(*CONSTANT_3),&(v771_2));
    drop(v771_2);
    let v771_10: Space = if has_head(&(v771_9)) { singleton(&[]) } else { Space::new() };
    drop(v771_9);
    let v771_11: Space = compose(&(v771_10),&(v770_9_tail));
    drop(v771_10);
    let v776_6: Path = concat_path(&(*p0),&(v770_9_head));
    let v771_12: Space = wrap(&(v771_11),&(v776_6));
    drop(v771_11);
    let v771_13: Space = wrap(&(v771_12),&(*p1));
    drop(v771_12);
    let v771_14: Space = unite(&(v771_8),&(v771_13));
    drop(v771_13);
    v770_9.join_into((v771_14).clone());
  }
  drop(v770_9_cursor);
  (v770_9).clone()
}

fn routine_80(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v777_13 = Space::new();
  let mut v777_13_cursor = (*s0).read_zipper();
  for v777_13_byte in v777_13_cursor.child_mask().iter() {
    v777_13_cursor.descend_to_byte(v777_13_byte);
    let v777_13_tail = v777_13_cursor.make_map();
    v777_13_cursor.ascend(1);
    let v777_13_head = Path::from_slice(&[v777_13_byte]);
    let v778_2: Space = singleton(&(v777_13_head));
    let v778_3: Space = intersect(&(*CONSTANT_3),&(v778_2));
    let v778_4: Space = if has_head(&(v778_3)) { singleton(&[]) } else { Space::new() };
    drop(v778_3);
    let v778_5: Space = subtract(&(*CONSTANT_2),&(v778_4));
    drop(v778_4);
    let v778_8: Space = if (v778_5).is_empty() { Space::new() } else {
      let v779_6: Path = concat_path(&(*p0),&(v777_13_head));
      let mut v779_7 = Space::new();
      let mut v779_7_cursor = (v777_13_tail).read_zipper();
      for v779_7_byte in v779_7_cursor.child_mask().iter() {
        v779_7_cursor.descend_to_byte(v779_7_byte);
        let v779_7_tail = v779_7_cursor.make_map();
        v779_7_cursor.ascend(1);
        let v779_7_head = Path::from_slice(&[v779_7_byte]);
        let v780_2: Space = singleton(&(v779_7_head));
        let v780_3: Space = intersect(&(*CONSTANT_3),&(v780_2));
        let v780_4: Space = if has_head(&(v780_3)) { singleton(&[]) } else { Space::new() };
        drop(v780_3);
        let v780_5: Space = subtract(&(*CONSTANT_2),&(v780_4));
        drop(v780_4);
        let v780_8: Space = if (v780_5).is_empty() { Space::new() } else {
          let v781_6: Path = concat_path(&(v779_6),&(v779_7_head));
          let v781_7: Space = routine_124(c, &(v781_6), &(*p1), &(v779_7_tail), &(*s1));
          compose(&(v780_5),&(v781_7))
        };
        drop(v780_5);
        let v780_9: Space = intersect(&(*CONSTANT_3),&(v780_2));
        drop(v780_2);
        let v780_10: Space = if has_head(&(v780_9)) { singleton(&[]) } else { Space::new() };
        drop(v780_9);
        let v780_12: Space = if (v780_10).is_empty() { Space::new() } else {
          let v782_6: Path = concat_path(&(v779_6),&(v779_7_head));
          let v782_11: Space = routine_125(c, &(v782_6), &(*p1), &(v779_7_tail), &(*s1));
          drop(v782_6);
          compose(&(v780_10),&(v782_11))
        };
        drop(v780_10);
        let v780_13: Space = unite(&(v780_8),&(v780_12));
        v779_7.join_into((v780_13).clone());
      }
      drop(v779_7_cursor);
      compose(&(v778_5),&(v779_7))
    };
    drop(v778_5);
    let v778_9: Space = intersect(&(*CONSTANT_3),&(v778_2));
    drop(v778_2);
    let v778_10: Space = if has_head(&(v778_9)) { singleton(&[]) } else { Space::new() };
    drop(v778_9);
    let v778_12: Space = if (v778_10).is_empty() { Space::new() } else {
      let v783_6: Path = concat_path(&(*p0),&(v777_13_head));
      let mut v783_11 = Space::new();
      let mut v783_11_cursor = (v777_13_tail).read_zipper();
      for v783_11_byte in v783_11_cursor.child_mask().iter() {
        v783_11_cursor.descend_to_byte(v783_11_byte);
        let v783_11_tail = v783_11_cursor.make_map();
        v783_11_cursor.ascend(1);
        let v783_11_head = Path::from_slice(&[v783_11_byte]);
        let v784_2: Space = singleton(&(v783_11_head));
        let v784_3: Space = intersect(&(*CONSTANT_3),&(v784_2));
        let v784_4: Space = if has_head(&(v784_3)) { singleton(&[]) } else { Space::new() };
        drop(v784_3);
        let v784_5: Space = subtract(&(*CONSTANT_2),&(v784_4));
        drop(v784_4);
        let v784_8: Space = if (v784_5).is_empty() { Space::new() } else {
          let v785_6: Path = concat_path(&(v783_6),&(v783_11_head));
          let v785_7: Space = routine_124(c, &(v785_6), &(*p1), &(v783_11_tail), &(*s1));
          compose(&(v784_5),&(v785_7))
        };
        drop(v784_5);
        let v784_9: Space = intersect(&(*CONSTANT_3),&(v784_2));
        drop(v784_2);
        let v784_10: Space = if has_head(&(v784_9)) { singleton(&[]) } else { Space::new() };
        drop(v784_9);
        let v784_12: Space = if (v784_10).is_empty() { Space::new() } else {
          let v786_6: Path = concat_path(&(v783_6),&(v783_11_head));
          let v786_11: Space = routine_43(c, &(v786_6), &(*p1), &(v783_11_tail), &(*s1));
          drop(v786_6);
          compose(&(v784_10),&(v786_11))
        };
        drop(v784_10);
        let v784_13: Space = unite(&(v784_8),&(v784_12));
        v783_11.join_into((v784_13).clone());
      }
      drop(v783_11_cursor);
      drop(v783_6);
      compose(&(v778_10),&(v783_11))
    };
    drop(v778_10);
    let v778_13: Space = unite(&(v778_8),&(v778_12));
    v777_13.join_into((v778_13).clone());
  }
  drop(v777_13_cursor);
  (v777_13).clone()
}

fn routine_81(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v787_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v787_10: Space = unwrap(&(v787_8),&(*CONSTANT_5));
  drop(v787_8);
  let v787_11: Space = unwrap(&(v787_10),&(*p0));
  drop(v787_10);
  let mut v787_18 = Space::new();
  let mut v787_18_cursor = (*s0).read_zipper();
  for v787_18_byte in v787_18_cursor.child_mask().iter() {
    v787_18_cursor.descend_to_byte(v787_18_byte);
    let v787_18_tail = v787_18_cursor.make_map();
    v787_18_cursor.ascend(1);
    let v787_18_head = Path::from_slice(&[v787_18_byte]);
    let v788_2: Space = singleton(&(v787_18_head));
    let v788_3: Space = intersect(&(*CONSTANT_3),&(v788_2));
    let v788_4: Space = if has_head(&(v788_3)) { singleton(&[]) } else { Space::new() };
    drop(v788_3);
    let v788_5: Space = subtract(&(*CONSTANT_2),&(v788_4));
    drop(v788_4);
    let v788_8: Space = if (v788_5).is_empty() { Space::new() } else {
      let v789_6: Path = concat_path(&(*p0),&(v787_18_head));
      let mut v789_7 = Space::new();
      let mut v789_7_cursor = (v787_18_tail).read_zipper();
      for v789_7_byte in v789_7_cursor.child_mask().iter() {
        v789_7_cursor.descend_to_byte(v789_7_byte);
        let v789_7_tail = v789_7_cursor.make_map();
        v789_7_cursor.ascend(1);
        let v789_7_head = Path::from_slice(&[v789_7_byte]);
        let v790_2: Space = singleton(&(v789_7_head));
        let v790_3: Space = intersect(&(*CONSTANT_3),&(v790_2));
        let v790_4: Space = if has_head(&(v790_3)) { singleton(&[]) } else { Space::new() };
        drop(v790_3);
        let v790_5: Space = subtract(&(*CONSTANT_2),&(v790_4));
        drop(v790_4);
        let v790_8: Space = if (v790_5).is_empty() { Space::new() } else {
          let v791_6: Path = concat_path(&(v789_6),&(v789_7_head));
          let v791_7: Space = routine_124(c, &(v791_6), &(*p1), &(v789_7_tail), &(*s1));
          compose(&(v790_5),&(v791_7))
        };
        drop(v790_5);
        let v790_9: Space = intersect(&(*CONSTANT_3),&(v790_2));
        drop(v790_2);
        let v790_10: Space = if has_head(&(v790_9)) { singleton(&[]) } else { Space::new() };
        drop(v790_9);
        let v790_12: Space = if (v790_10).is_empty() { Space::new() } else {
          let v792_6: Path = concat_path(&(v789_6),&(v789_7_head));
          let v792_11: Space = routine_125(c, &(v792_6), &(*p1), &(v789_7_tail), &(*s1));
          drop(v792_6);
          compose(&(v790_10),&(v792_11))
        };
        drop(v790_10);
        let v790_13: Space = unite(&(v790_8),&(v790_12));
        v789_7.join_into((v790_13).clone());
      }
      drop(v789_7_cursor);
      drop(v789_6);
      compose(&(v788_5),&(v789_7))
    };
    drop(v788_5);
    let v788_9: Space = intersect(&(*CONSTANT_3),&(v788_2));
    drop(v788_2);
    let v788_10: Space = if has_head(&(v788_9)) { singleton(&[]) } else { Space::new() };
    drop(v788_9);
    let v788_13: Space = if (v788_10).is_empty() { Space::new() } else {
      let v793_11: Space = unwrap(&(v787_11),&(v787_18_head));
      let mut v793_12 = Space::new();
      let mut v793_12_cursor = (v793_11).read_zipper();
      for v793_12_byte in v793_12_cursor.child_mask().iter() {
        v793_12_cursor.descend_to_byte(v793_12_byte);
        let v793_12_tail = v793_12_cursor.make_map();
        v793_12_cursor.ascend(1);
        let v793_12_head = Path::from_slice(&[v793_12_byte]);
        let v794_2: Space = singleton(&(v793_12_head));
        let v794_3: Space = intersect(&(*CONSTANT_3),&(v794_2));
        let v794_4: Space = if has_head(&(v794_3)) { singleton(&[]) } else { Space::new() };
        drop(v794_3);
        let v794_5: Space = subtract(&(*CONSTANT_2),&(v794_4));
        drop(v794_4);
        let v794_7: Space = if (v794_5).is_empty() { Space::new() } else {
          let v795_6: Space = routine_78(c, &(v793_12_head), &(*p1), &(v793_12_tail));
          compose(&(v794_5),&(v795_6))
        };
        drop(v794_5);
        let v794_8: Space = intersect(&(*CONSTANT_3),&(v794_2));
        drop(v794_2);
        let v794_9: Space = if has_head(&(v794_8)) { singleton(&[]) } else { Space::new() };
        drop(v794_8);
        let v794_11: Space = if (v794_9).is_empty() { Space::new() } else {
          let v796_10: Space = routine_79(c, &(v793_12_head), &(*p1), &(v793_12_tail));
          compose(&(v794_9),&(v796_10))
        };
        drop(v794_9);
        let v794_12: Space = unite(&(v794_7),&(v794_11));
        v793_12.join_into((v794_12).clone());
      }
      drop(v793_12_cursor);
      drop(v793_11);
      compose(&(v788_10),&(v793_12))
    };
    drop(v788_10);
    let v788_14: Space = unite(&(v788_8),&(v788_13));
    v787_18.join_into((v788_14).clone());
  }
  drop(v787_18_cursor);
  drop(v787_11);
  (v787_18).clone()
}

fn routine_82(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v797_12 = Space::new();
  let mut v797_12_cursor = (*s0).read_zipper();
  for v797_12_byte in v797_12_cursor.child_mask().iter() {
    v797_12_cursor.descend_to_byte(v797_12_byte);
    let v797_12_tail = v797_12_cursor.make_map();
    v797_12_cursor.ascend(1);
    let v797_12_head = Path::from_slice(&[v797_12_byte]);
    let v798_2: Space = singleton(&(v797_12_head));
    let v798_3: Space = intersect(&(*CONSTANT_3),&(v798_2));
    let v798_4: Space = if has_head(&(v798_3)) { singleton(&[]) } else { Space::new() };
    drop(v798_3);
    let v798_5: Space = subtract(&(*CONSTANT_2),&(v798_4));
    drop(v798_4);
    let v798_8: Space = if (v798_5).is_empty() { Space::new() } else {
      let v799_6: Path = concat_path(&(*p0),&(v797_12_head));
      let mut v799_7 = Space::new();
      let mut v799_7_cursor = (v797_12_tail).read_zipper();
      for v799_7_byte in v799_7_cursor.child_mask().iter() {
        v799_7_cursor.descend_to_byte(v799_7_byte);
        let v799_7_tail = v799_7_cursor.make_map();
        v799_7_cursor.ascend(1);
        let v799_7_head = Path::from_slice(&[v799_7_byte]);
        let v800_2: Space = singleton(&(v799_7_head));
        let v800_3: Space = intersect(&(*CONSTANT_3),&(v800_2));
        let v800_4: Space = if has_head(&(v800_3)) { singleton(&[]) } else { Space::new() };
        drop(v800_3);
        let v800_5: Space = subtract(&(*CONSTANT_2),&(v800_4));
        drop(v800_4);
        let v800_8: Space = if (v800_5).is_empty() { Space::new() } else {
          let v801_6: Path = concat_path(&(v799_6),&(v799_7_head));
          let v801_7: Space = routine_126(c, &(v801_6), &(*p1), &(v799_7_tail));
          compose(&(v800_5),&(v801_7))
        };
        drop(v800_5);
        let v800_9: Space = intersect(&(*CONSTANT_3),&(v800_2));
        drop(v800_2);
        let v800_10: Space = if has_head(&(v800_9)) { singleton(&[]) } else { Space::new() };
        drop(v800_9);
        let v800_12: Space = if (v800_10).is_empty() { Space::new() } else {
          let v802_6: Path = concat_path(&(v799_6),&(v799_7_head));
          let v802_11: Space = routine_127(c, &(v802_6), &(*p1), &(v799_7_tail));
          drop(v802_6);
          compose(&(v800_10),&(v802_11))
        };
        drop(v800_10);
        let v800_13: Space = unite(&(v800_8),&(v800_12));
        v799_7.join_into((v800_13).clone());
      }
      drop(v799_7_cursor);
      compose(&(v798_5),&(v799_7))
    };
    drop(v798_5);
    let v798_9: Space = intersect(&(*CONSTANT_3),&(v798_2));
    drop(v798_2);
    let v798_10: Space = if has_head(&(v798_9)) { singleton(&[]) } else { Space::new() };
    drop(v798_9);
    let v798_12: Space = if (v798_10).is_empty() { Space::new() } else {
      let v803_6: Path = concat_path(&(*p0),&(v797_12_head));
      let mut v803_11 = Space::new();
      let mut v803_11_cursor = (v797_12_tail).read_zipper();
      for v803_11_byte in v803_11_cursor.child_mask().iter() {
        v803_11_cursor.descend_to_byte(v803_11_byte);
        let v803_11_tail = v803_11_cursor.make_map();
        v803_11_cursor.ascend(1);
        let v803_11_head = Path::from_slice(&[v803_11_byte]);
        let v804_2: Space = singleton(&(v803_11_head));
        let v804_3: Space = intersect(&(*CONSTANT_3),&(v804_2));
        let v804_4: Space = if has_head(&(v804_3)) { singleton(&[]) } else { Space::new() };
        drop(v804_3);
        let v804_5: Space = subtract(&(*CONSTANT_2),&(v804_4));
        drop(v804_4);
        let v804_8: Space = if (v804_5).is_empty() { Space::new() } else {
          let v805_6: Path = concat_path(&(v803_6),&(v803_11_head));
          let v805_7: Space = routine_126(c, &(v805_6), &(*p1), &(v803_11_tail));
          compose(&(v804_5),&(v805_7))
        };
        drop(v804_5);
        let v804_9: Space = intersect(&(*CONSTANT_3),&(v804_2));
        drop(v804_2);
        let v804_10: Space = if has_head(&(v804_9)) { singleton(&[]) } else { Space::new() };
        drop(v804_9);
        let v804_12: Space = if (v804_10).is_empty() { Space::new() } else {
          let v806_6: Path = concat_path(&(v803_6),&(v803_11_head));
          let v806_11: Space = routine_84(c, &(v806_6), &(*p1), &(v803_11_tail));
          drop(v806_6);
          compose(&(v804_10),&(v806_11))
        };
        drop(v804_10);
        let v804_13: Space = unite(&(v804_8),&(v804_12));
        v803_11.join_into((v804_13).clone());
      }
      drop(v803_11_cursor);
      drop(v803_6);
      compose(&(v798_10),&(v803_11))
    };
    drop(v798_10);
    let v798_13: Space = unite(&(v798_8),&(v798_12));
    v797_12.join_into((v798_13).clone());
  }
  drop(v797_12_cursor);
  (v797_12).clone()
}

fn routine_83(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v807_9 = Space::new();
  let mut v807_9_cursor = (*s0).read_zipper();
  for v807_9_byte in v807_9_cursor.child_mask().iter() {
    v807_9_cursor.descend_to_byte(v807_9_byte);
    let v807_9_tail = v807_9_cursor.make_map();
    v807_9_cursor.ascend(1);
    let v807_9_head = Path::from_slice(&[v807_9_byte]);
    let v808_2: Space = singleton(&(v807_9_head));
    let v808_3: Space = intersect(&(*CONSTANT_3),&(v808_2));
    let v808_4: Space = if has_head(&(v808_3)) { singleton(&[]) } else { Space::new() };
    drop(v808_3);
    let v808_5: Space = subtract(&(*CONSTANT_2),&(v808_4));
    drop(v808_4);
    let v808_8: Space = if (v808_5).is_empty() { Space::new() } else {
      let v809_6: Path = concat_path(&(*p0),&(v807_9_head));
      let mut v809_7 = Space::new();
      let mut v809_7_cursor = (v807_9_tail).read_zipper();
      for v809_7_byte in v809_7_cursor.child_mask().iter() {
        v809_7_cursor.descend_to_byte(v809_7_byte);
        let v809_7_tail = v809_7_cursor.make_map();
        v809_7_cursor.ascend(1);
        let v809_7_head = Path::from_slice(&[v809_7_byte]);
        let v810_2: Space = singleton(&(v809_7_head));
        let v810_3: Space = intersect(&(*CONSTANT_3),&(v810_2));
        let v810_4: Space = if has_head(&(v810_3)) { singleton(&[]) } else { Space::new() };
        drop(v810_3);
        let v810_5: Space = subtract(&(*CONSTANT_2),&(v810_4));
        drop(v810_4);
        let v810_8: Space = if (v810_5).is_empty() { Space::new() } else {
          let v811_6: Path = concat_path(&(v809_6),&(v809_7_head));
          let v811_7: Space = routine_126(c, &(v811_6), &(*p1), &(v809_7_tail));
          compose(&(v810_5),&(v811_7))
        };
        drop(v810_5);
        let v810_9: Space = intersect(&(*CONSTANT_3),&(v810_2));
        drop(v810_2);
        let v810_10: Space = if has_head(&(v810_9)) { singleton(&[]) } else { Space::new() };
        drop(v810_9);
        let v810_12: Space = if (v810_10).is_empty() { Space::new() } else {
          let v812_6: Path = concat_path(&(v809_6),&(v809_7_head));
          let v812_11: Space = routine_127(c, &(v812_6), &(*p1), &(v809_7_tail));
          drop(v812_6);
          compose(&(v810_10),&(v812_11))
        };
        drop(v810_10);
        let v810_13: Space = unite(&(v810_8),&(v810_12));
        v809_7.join_into((v810_13).clone());
      }
      drop(v809_7_cursor);
      compose(&(v808_5),&(v809_7))
    };
    drop(v808_5);
    let v808_9: Space = intersect(&(*CONSTANT_3),&(v808_2));
    drop(v808_2);
    let v808_10: Space = if has_head(&(v808_9)) { singleton(&[]) } else { Space::new() };
    drop(v808_9);
    let v808_11: Space = compose(&(v808_10),&(v807_9_tail));
    drop(v808_10);
    let v813_6: Path = concat_path(&(*p0),&(v807_9_head));
    let v808_12: Space = wrap(&(v808_11),&(v813_6));
    drop(v808_11);
    let v808_13: Space = wrap(&(v808_12),&(*p1));
    drop(v808_12);
    let v808_14: Space = unite(&(v808_8),&(v808_13));
    drop(v808_13);
    v807_9.join_into((v808_14).clone());
  }
  drop(v807_9_cursor);
  (v807_9).clone()
}

fn routine_84(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v814_3: Space = wrap(&(*s0),&(*p0));
  let v814_4: Space = wrap(&(v814_3),&(*p1));
  drop(v814_3);
  (v814_4).clone()
}

fn routine_85(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v815_12 = Space::new();
  let mut v815_12_cursor = (*s0).read_zipper();
  for v815_12_byte in v815_12_cursor.child_mask().iter() {
    v815_12_cursor.descend_to_byte(v815_12_byte);
    let v815_12_tail = v815_12_cursor.make_map();
    v815_12_cursor.ascend(1);
    let v815_12_head = Path::from_slice(&[v815_12_byte]);
    let v816_2: Space = singleton(&(v815_12_head));
    let v816_3: Space = intersect(&(*CONSTANT_3),&(v816_2));
    let v816_4: Space = if has_head(&(v816_3)) { singleton(&[]) } else { Space::new() };
    drop(v816_3);
    let v816_5: Space = subtract(&(*CONSTANT_2),&(v816_4));
    drop(v816_4);
    let v816_8: Space = if (v816_5).is_empty() { Space::new() } else {
      let v817_6: Path = concat_path(&(*p0),&(v815_12_head));
      let mut v817_7 = Space::new();
      let mut v817_7_cursor = (v815_12_tail).read_zipper();
      for v817_7_byte in v817_7_cursor.child_mask().iter() {
        v817_7_cursor.descend_to_byte(v817_7_byte);
        let v817_7_tail = v817_7_cursor.make_map();
        v817_7_cursor.ascend(1);
        let v817_7_head = Path::from_slice(&[v817_7_byte]);
        let v818_2: Space = singleton(&(v817_7_head));
        let v818_3: Space = intersect(&(*CONSTANT_3),&(v818_2));
        let v818_4: Space = if has_head(&(v818_3)) { singleton(&[]) } else { Space::new() };
        drop(v818_3);
        let v818_5: Space = subtract(&(*CONSTANT_2),&(v818_4));
        drop(v818_4);
        let v818_8: Space = if (v818_5).is_empty() { Space::new() } else {
          let v819_6: Path = concat_path(&(v817_6),&(v817_7_head));
          let v819_7: Space = routine_128(c, &(v819_6), &(v817_7_tail), &(*s1));
          compose(&(v818_5),&(v819_7))
        };
        drop(v818_5);
        let v818_9: Space = intersect(&(*CONSTANT_3),&(v818_2));
        drop(v818_2);
        let v818_10: Space = if has_head(&(v818_9)) { singleton(&[]) } else { Space::new() };
        drop(v818_9);
        let v818_12: Space = if (v818_10).is_empty() { Space::new() } else {
          let v820_6: Path = concat_path(&(v817_6),&(v817_7_head));
          let v820_11: Space = routine_129(c, &(v820_6), &(v817_7_tail), &(*s1));
          drop(v820_6);
          compose(&(v818_10),&(v820_11))
        };
        drop(v818_10);
        let v818_13: Space = unite(&(v818_8),&(v818_12));
        v817_7.join_into((v818_13).clone());
      }
      drop(v817_7_cursor);
      compose(&(v816_5),&(v817_7))
    };
    drop(v816_5);
    let v816_9: Space = intersect(&(*CONSTANT_3),&(v816_2));
    drop(v816_2);
    let v816_10: Space = if has_head(&(v816_9)) { singleton(&[]) } else { Space::new() };
    drop(v816_9);
    let v816_12: Space = if (v816_10).is_empty() { Space::new() } else {
      let v821_6: Path = concat_path(&(*p0),&(v815_12_head));
      let mut v821_11 = Space::new();
      let mut v821_11_cursor = (v815_12_tail).read_zipper();
      for v821_11_byte in v821_11_cursor.child_mask().iter() {
        v821_11_cursor.descend_to_byte(v821_11_byte);
        let v821_11_tail = v821_11_cursor.make_map();
        v821_11_cursor.ascend(1);
        let v821_11_head = Path::from_slice(&[v821_11_byte]);
        let v822_2: Space = singleton(&(v821_11_head));
        let v822_3: Space = intersect(&(*CONSTANT_3),&(v822_2));
        let v822_4: Space = if has_head(&(v822_3)) { singleton(&[]) } else { Space::new() };
        drop(v822_3);
        let v822_5: Space = subtract(&(*CONSTANT_2),&(v822_4));
        drop(v822_4);
        let v822_8: Space = if (v822_5).is_empty() { Space::new() } else {
          let v823_6: Path = concat_path(&(v821_6),&(v821_11_head));
          let v823_7: Space = routine_128(c, &(v823_6), &(v821_11_tail), &(*s1));
          compose(&(v822_5),&(v823_7))
        };
        drop(v822_5);
        let v822_9: Space = intersect(&(*CONSTANT_3),&(v822_2));
        drop(v822_2);
        let v822_10: Space = if has_head(&(v822_9)) { singleton(&[]) } else { Space::new() };
        drop(v822_9);
        let v822_12: Space = if (v822_10).is_empty() { Space::new() } else {
          let v824_6: Path = concat_path(&(v821_6),&(v821_11_head));
          let v824_11: Space = routine_15(c, &(v824_6), &(v821_11_tail), &(*s1));
          drop(v824_6);
          compose(&(v822_10),&(v824_11))
        };
        drop(v822_10);
        let v822_13: Space = unite(&(v822_8),&(v822_12));
        v821_11.join_into((v822_13).clone());
      }
      drop(v821_11_cursor);
      drop(v821_6);
      compose(&(v816_10),&(v821_11))
    };
    drop(v816_10);
    let v816_13: Space = unite(&(v816_8),&(v816_12));
    v815_12.join_into((v816_13).clone());
  }
  drop(v815_12_cursor);
  (v815_12).clone()
}

fn routine_86(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v825_12 = Space::new();
  let mut v825_12_cursor = (*s0).read_zipper();
  for v825_12_byte in v825_12_cursor.child_mask().iter() {
    v825_12_cursor.descend_to_byte(v825_12_byte);
    let v825_12_tail = v825_12_cursor.make_map();
    v825_12_cursor.ascend(1);
    let v825_12_head = Path::from_slice(&[v825_12_byte]);
    let v826_2: Space = singleton(&(v825_12_head));
    let v826_3: Space = intersect(&(*CONSTANT_3),&(v826_2));
    let v826_4: Space = if has_head(&(v826_3)) { singleton(&[]) } else { Space::new() };
    drop(v826_3);
    let v826_5: Space = subtract(&(*CONSTANT_2),&(v826_4));
    drop(v826_4);
    let v826_8: Space = if (v826_5).is_empty() { Space::new() } else {
      let v827_6: Path = concat_path(&(*p0),&(v825_12_head));
      let mut v827_7 = Space::new();
      let mut v827_7_cursor = (v825_12_tail).read_zipper();
      for v827_7_byte in v827_7_cursor.child_mask().iter() {
        v827_7_cursor.descend_to_byte(v827_7_byte);
        let v827_7_tail = v827_7_cursor.make_map();
        v827_7_cursor.ascend(1);
        let v827_7_head = Path::from_slice(&[v827_7_byte]);
        let v828_2: Space = singleton(&(v827_7_head));
        let v828_3: Space = intersect(&(*CONSTANT_3),&(v828_2));
        let v828_4: Space = if has_head(&(v828_3)) { singleton(&[]) } else { Space::new() };
        drop(v828_3);
        let v828_5: Space = subtract(&(*CONSTANT_2),&(v828_4));
        drop(v828_4);
        let v828_8: Space = if (v828_5).is_empty() { Space::new() } else {
          let v829_6: Path = concat_path(&(v827_6),&(v827_7_head));
          let v829_7: Space = routine_128(c, &(v829_6), &(v827_7_tail), &(*s1));
          compose(&(v828_5),&(v829_7))
        };
        drop(v828_5);
        let v828_9: Space = intersect(&(*CONSTANT_3),&(v828_2));
        drop(v828_2);
        let v828_10: Space = if has_head(&(v828_9)) { singleton(&[]) } else { Space::new() };
        drop(v828_9);
        let v828_12: Space = if (v828_10).is_empty() { Space::new() } else {
          let v830_6: Path = concat_path(&(v827_6),&(v827_7_head));
          let v830_11: Space = routine_129(c, &(v830_6), &(v827_7_tail), &(*s1));
          drop(v830_6);
          compose(&(v828_10),&(v830_11))
        };
        drop(v828_10);
        let v828_13: Space = unite(&(v828_8),&(v828_12));
        v827_7.join_into((v828_13).clone());
      }
      drop(v827_7_cursor);
      compose(&(v826_5),&(v827_7))
    };
    drop(v826_5);
    let v826_9: Space = intersect(&(*CONSTANT_3),&(v826_2));
    drop(v826_2);
    let v826_10: Space = if has_head(&(v826_9)) { singleton(&[]) } else { Space::new() };
    drop(v826_9);
    let v826_12: Space = if (v826_10).is_empty() { Space::new() } else {
      let v831_6: Path = concat_path(&(*p0),&(v825_12_head));
      let mut v831_11 = Space::new();
      let mut v831_11_cursor = (v825_12_tail).read_zipper();
      for v831_11_byte in v831_11_cursor.child_mask().iter() {
        v831_11_cursor.descend_to_byte(v831_11_byte);
        let v831_11_tail = v831_11_cursor.make_map();
        v831_11_cursor.ascend(1);
        let v831_11_head = Path::from_slice(&[v831_11_byte]);
        let v832_2: Space = singleton(&(v831_11_head));
        let v832_3: Space = intersect(&(*CONSTANT_3),&(v832_2));
        let v832_4: Space = if has_head(&(v832_3)) { singleton(&[]) } else { Space::new() };
        drop(v832_3);
        let v832_5: Space = subtract(&(*CONSTANT_2),&(v832_4));
        drop(v832_4);
        let v832_7: Space = if (v832_5).is_empty() { Space::new() } else {
          let v833_6: Space = routine_46(c, &(v831_11_head), &(v831_6), &(v831_11_tail), &(*s1));
          compose(&(v832_5),&(v833_6))
        };
        drop(v832_5);
        let v832_8: Space = intersect(&(*CONSTANT_3),&(v832_2));
        drop(v832_2);
        let v832_9: Space = if has_head(&(v832_8)) { singleton(&[]) } else { Space::new() };
        drop(v832_8);
        let v832_11: Space = if (v832_9).is_empty() { Space::new() } else {
          let v834_10: Space = routine_47(c, &(v831_11_head), &(v831_6), &(v831_11_tail), &(*s1));
          compose(&(v832_9),&(v834_10))
        };
        drop(v832_9);
        let v832_12: Space = unite(&(v832_7),&(v832_11));
        v831_11.join_into((v832_12).clone());
      }
      drop(v831_11_cursor);
      drop(v831_6);
      compose(&(v826_10),&(v831_11))
    };
    drop(v826_10);
    let v826_13: Space = unite(&(v826_8),&(v826_12));
    v825_12.join_into((v826_13).clone());
  }
  drop(v825_12_cursor);
  (v825_12).clone()
}

fn routine_87(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v835_13 = Space::new();
  let mut v835_13_cursor = (*s0).read_zipper();
  for v835_13_byte in v835_13_cursor.child_mask().iter() {
    v835_13_cursor.descend_to_byte(v835_13_byte);
    let v835_13_tail = v835_13_cursor.make_map();
    v835_13_cursor.ascend(1);
    let v835_13_head = Path::from_slice(&[v835_13_byte]);
    let v836_2: Space = singleton(&(v835_13_head));
    let v836_3: Space = intersect(&(*CONSTANT_3),&(v836_2));
    let v836_4: Space = if has_head(&(v836_3)) { singleton(&[]) } else { Space::new() };
    drop(v836_3);
    let v836_5: Space = subtract(&(*CONSTANT_2),&(v836_4));
    drop(v836_4);
    let v836_8: Space = if (v836_5).is_empty() { Space::new() } else {
      let v837_6: Path = concat_path(&(*p0),&(v835_13_head));
      let mut v837_7 = Space::new();
      let mut v837_7_cursor = (v835_13_tail).read_zipper();
      for v837_7_byte in v837_7_cursor.child_mask().iter() {
        v837_7_cursor.descend_to_byte(v837_7_byte);
        let v837_7_tail = v837_7_cursor.make_map();
        v837_7_cursor.ascend(1);
        let v837_7_head = Path::from_slice(&[v837_7_byte]);
        let v838_2: Space = singleton(&(v837_7_head));
        let v838_3: Space = intersect(&(*CONSTANT_3),&(v838_2));
        let v838_4: Space = if has_head(&(v838_3)) { singleton(&[]) } else { Space::new() };
        drop(v838_3);
        let v838_5: Space = subtract(&(*CONSTANT_2),&(v838_4));
        drop(v838_4);
        let v838_8: Space = if (v838_5).is_empty() { Space::new() } else {
          let v839_6: Path = concat_path(&(v837_6),&(v837_7_head));
          let v839_7: Space = routine_130(c, &(v839_6), &(*p1), &(v837_7_tail), &(*s1));
          compose(&(v838_5),&(v839_7))
        };
        drop(v838_5);
        let v838_9: Space = intersect(&(*CONSTANT_3),&(v838_2));
        drop(v838_2);
        let v838_10: Space = if has_head(&(v838_9)) { singleton(&[]) } else { Space::new() };
        drop(v838_9);
        let v838_12: Space = if (v838_10).is_empty() { Space::new() } else {
          let v840_6: Path = concat_path(&(v837_6),&(v837_7_head));
          let v840_11: Space = routine_131(c, &(v840_6), &(*p1), &(v837_7_tail), &(*s1));
          drop(v840_6);
          compose(&(v838_10),&(v840_11))
        };
        drop(v838_10);
        let v838_13: Space = unite(&(v838_8),&(v838_12));
        v837_7.join_into((v838_13).clone());
      }
      drop(v837_7_cursor);
      compose(&(v836_5),&(v837_7))
    };
    drop(v836_5);
    let v836_9: Space = intersect(&(*CONSTANT_3),&(v836_2));
    drop(v836_2);
    let v836_10: Space = if has_head(&(v836_9)) { singleton(&[]) } else { Space::new() };
    drop(v836_9);
    let v836_12: Space = if (v836_10).is_empty() { Space::new() } else {
      let v841_6: Path = concat_path(&(*p0),&(v835_13_head));
      let mut v841_11 = Space::new();
      let mut v841_11_cursor = (v835_13_tail).read_zipper();
      for v841_11_byte in v841_11_cursor.child_mask().iter() {
        v841_11_cursor.descend_to_byte(v841_11_byte);
        let v841_11_tail = v841_11_cursor.make_map();
        v841_11_cursor.ascend(1);
        let v841_11_head = Path::from_slice(&[v841_11_byte]);
        let v842_2: Space = singleton(&(v841_11_head));
        let v842_3: Space = intersect(&(*CONSTANT_3),&(v842_2));
        let v842_4: Space = if has_head(&(v842_3)) { singleton(&[]) } else { Space::new() };
        drop(v842_3);
        let v842_5: Space = subtract(&(*CONSTANT_2),&(v842_4));
        drop(v842_4);
        let v842_8: Space = if (v842_5).is_empty() { Space::new() } else {
          let v843_6: Path = concat_path(&(v841_6),&(v841_11_head));
          let v843_7: Space = routine_130(c, &(v843_6), &(*p1), &(v841_11_tail), &(*s1));
          compose(&(v842_5),&(v843_7))
        };
        drop(v842_5);
        let v842_9: Space = intersect(&(*CONSTANT_3),&(v842_2));
        drop(v842_2);
        let v842_10: Space = if has_head(&(v842_9)) { singleton(&[]) } else { Space::new() };
        drop(v842_9);
        let v842_12: Space = if (v842_10).is_empty() { Space::new() } else {
          let v844_6: Path = concat_path(&(v841_6),&(v841_11_head));
          let v844_11: Space = routine_50(c, &(v844_6), &(*p1), &(v841_11_tail), &(*s1));
          drop(v844_6);
          compose(&(v842_10),&(v844_11))
        };
        drop(v842_10);
        let v842_13: Space = unite(&(v842_8),&(v842_12));
        v841_11.join_into((v842_13).clone());
      }
      drop(v841_11_cursor);
      drop(v841_6);
      compose(&(v836_10),&(v841_11))
    };
    drop(v836_10);
    let v836_13: Space = unite(&(v836_8),&(v836_12));
    v835_13.join_into((v836_13).clone());
  }
  drop(v835_13_cursor);
  (v835_13).clone()
}

fn routine_88(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v845_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v845_10: Space = unwrap(&(v845_8),&(*CONSTANT_5));
  drop(v845_8);
  let v845_11: Space = unwrap(&(v845_10),&(*p0));
  drop(v845_10);
  let mut v845_18 = Space::new();
  let mut v845_18_cursor = (*s0).read_zipper();
  for v845_18_byte in v845_18_cursor.child_mask().iter() {
    v845_18_cursor.descend_to_byte(v845_18_byte);
    let v845_18_tail = v845_18_cursor.make_map();
    v845_18_cursor.ascend(1);
    let v845_18_head = Path::from_slice(&[v845_18_byte]);
    let v846_2: Space = singleton(&(v845_18_head));
    let v846_3: Space = intersect(&(*CONSTANT_3),&(v846_2));
    let v846_4: Space = if has_head(&(v846_3)) { singleton(&[]) } else { Space::new() };
    drop(v846_3);
    let v846_5: Space = subtract(&(*CONSTANT_2),&(v846_4));
    drop(v846_4);
    let v846_8: Space = if (v846_5).is_empty() { Space::new() } else {
      let v847_6: Path = concat_path(&(*p0),&(v845_18_head));
      let mut v847_7 = Space::new();
      let mut v847_7_cursor = (v845_18_tail).read_zipper();
      for v847_7_byte in v847_7_cursor.child_mask().iter() {
        v847_7_cursor.descend_to_byte(v847_7_byte);
        let v847_7_tail = v847_7_cursor.make_map();
        v847_7_cursor.ascend(1);
        let v847_7_head = Path::from_slice(&[v847_7_byte]);
        let v848_2: Space = singleton(&(v847_7_head));
        let v848_3: Space = intersect(&(*CONSTANT_3),&(v848_2));
        let v848_4: Space = if has_head(&(v848_3)) { singleton(&[]) } else { Space::new() };
        drop(v848_3);
        let v848_5: Space = subtract(&(*CONSTANT_2),&(v848_4));
        drop(v848_4);
        let v848_8: Space = if (v848_5).is_empty() { Space::new() } else {
          let v849_6: Path = concat_path(&(v847_6),&(v847_7_head));
          let v849_7: Space = routine_130(c, &(v849_6), &(*p1), &(v847_7_tail), &(*s1));
          compose(&(v848_5),&(v849_7))
        };
        drop(v848_5);
        let v848_9: Space = intersect(&(*CONSTANT_3),&(v848_2));
        drop(v848_2);
        let v848_10: Space = if has_head(&(v848_9)) { singleton(&[]) } else { Space::new() };
        drop(v848_9);
        let v848_12: Space = if (v848_10).is_empty() { Space::new() } else {
          let v850_6: Path = concat_path(&(v847_6),&(v847_7_head));
          let v850_11: Space = routine_131(c, &(v850_6), &(*p1), &(v847_7_tail), &(*s1));
          drop(v850_6);
          compose(&(v848_10),&(v850_11))
        };
        drop(v848_10);
        let v848_13: Space = unite(&(v848_8),&(v848_12));
        v847_7.join_into((v848_13).clone());
      }
      drop(v847_7_cursor);
      drop(v847_6);
      compose(&(v846_5),&(v847_7))
    };
    drop(v846_5);
    let v846_9: Space = intersect(&(*CONSTANT_3),&(v846_2));
    drop(v846_2);
    let v846_10: Space = if has_head(&(v846_9)) { singleton(&[]) } else { Space::new() };
    drop(v846_9);
    let v846_13: Space = if (v846_10).is_empty() { Space::new() } else {
      let v851_11: Space = unwrap(&(v845_11),&(v845_18_head));
      let mut v851_12 = Space::new();
      let mut v851_12_cursor = (v851_11).read_zipper();
      for v851_12_byte in v851_12_cursor.child_mask().iter() {
        v851_12_cursor.descend_to_byte(v851_12_byte);
        let v851_12_tail = v851_12_cursor.make_map();
        v851_12_cursor.ascend(1);
        let v851_12_head = Path::from_slice(&[v851_12_byte]);
        let v852_2: Space = singleton(&(v851_12_head));
        let v852_3: Space = intersect(&(*CONSTANT_3),&(v852_2));
        let v852_4: Space = if has_head(&(v852_3)) { singleton(&[]) } else { Space::new() };
        drop(v852_3);
        let v852_5: Space = subtract(&(*CONSTANT_2),&(v852_4));
        drop(v852_4);
        let v852_7: Space = if (v852_5).is_empty() { Space::new() } else {
          let v853_6: Space = routine_89(c, &(v851_12_head), &(*p1), &(v851_12_tail));
          compose(&(v852_5),&(v853_6))
        };
        drop(v852_5);
        let v852_8: Space = intersect(&(*CONSTANT_3),&(v852_2));
        drop(v852_2);
        let v852_9: Space = if has_head(&(v852_8)) { singleton(&[]) } else { Space::new() };
        drop(v852_8);
        let v852_11: Space = if (v852_9).is_empty() { Space::new() } else {
          let v854_10: Space = routine_90(c, &(v851_12_head), &(*p1), &(v851_12_tail));
          compose(&(v852_9),&(v854_10))
        };
        drop(v852_9);
        let v852_12: Space = unite(&(v852_7),&(v852_11));
        v851_12.join_into((v852_12).clone());
      }
      drop(v851_12_cursor);
      drop(v851_11);
      compose(&(v846_10),&(v851_12))
    };
    drop(v846_10);
    let v846_14: Space = unite(&(v846_8),&(v846_13));
    v845_18.join_into((v846_14).clone());
  }
  drop(v845_18_cursor);
  drop(v845_11);
  (v845_18).clone()
}

fn routine_89(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v855_12 = Space::new();
  let mut v855_12_cursor = (*s0).read_zipper();
  for v855_12_byte in v855_12_cursor.child_mask().iter() {
    v855_12_cursor.descend_to_byte(v855_12_byte);
    let v855_12_tail = v855_12_cursor.make_map();
    v855_12_cursor.ascend(1);
    let v855_12_head = Path::from_slice(&[v855_12_byte]);
    let v856_2: Space = singleton(&(v855_12_head));
    let v856_3: Space = intersect(&(*CONSTANT_3),&(v856_2));
    let v856_4: Space = if has_head(&(v856_3)) { singleton(&[]) } else { Space::new() };
    drop(v856_3);
    let v856_5: Space = subtract(&(*CONSTANT_2),&(v856_4));
    drop(v856_4);
    let v856_8: Space = if (v856_5).is_empty() { Space::new() } else {
      let v857_6: Path = concat_path(&(*p0),&(v855_12_head));
      let mut v857_7 = Space::new();
      let mut v857_7_cursor = (v855_12_tail).read_zipper();
      for v857_7_byte in v857_7_cursor.child_mask().iter() {
        v857_7_cursor.descend_to_byte(v857_7_byte);
        let v857_7_tail = v857_7_cursor.make_map();
        v857_7_cursor.ascend(1);
        let v857_7_head = Path::from_slice(&[v857_7_byte]);
        let v858_2: Space = singleton(&(v857_7_head));
        let v858_3: Space = intersect(&(*CONSTANT_3),&(v858_2));
        let v858_4: Space = if has_head(&(v858_3)) { singleton(&[]) } else { Space::new() };
        drop(v858_3);
        let v858_5: Space = subtract(&(*CONSTANT_2),&(v858_4));
        drop(v858_4);
        let v858_8: Space = if (v858_5).is_empty() { Space::new() } else {
          let v859_6: Path = concat_path(&(v857_6),&(v857_7_head));
          let v859_7: Space = routine_132(c, &(v859_6), &(*p1), &(v857_7_tail));
          compose(&(v858_5),&(v859_7))
        };
        drop(v858_5);
        let v858_9: Space = intersect(&(*CONSTANT_3),&(v858_2));
        drop(v858_2);
        let v858_10: Space = if has_head(&(v858_9)) { singleton(&[]) } else { Space::new() };
        drop(v858_9);
        let v858_12: Space = if (v858_10).is_empty() { Space::new() } else {
          let v860_6: Path = concat_path(&(v857_6),&(v857_7_head));
          let v860_11: Space = routine_133(c, &(v860_6), &(*p1), &(v857_7_tail));
          drop(v860_6);
          compose(&(v858_10),&(v860_11))
        };
        drop(v858_10);
        let v858_13: Space = unite(&(v858_8),&(v858_12));
        v857_7.join_into((v858_13).clone());
      }
      drop(v857_7_cursor);
      compose(&(v856_5),&(v857_7))
    };
    drop(v856_5);
    let v856_9: Space = intersect(&(*CONSTANT_3),&(v856_2));
    drop(v856_2);
    let v856_10: Space = if has_head(&(v856_9)) { singleton(&[]) } else { Space::new() };
    drop(v856_9);
    let v856_12: Space = if (v856_10).is_empty() { Space::new() } else {
      let v861_6: Path = concat_path(&(*p0),&(v855_12_head));
      let mut v861_11 = Space::new();
      let mut v861_11_cursor = (v855_12_tail).read_zipper();
      for v861_11_byte in v861_11_cursor.child_mask().iter() {
        v861_11_cursor.descend_to_byte(v861_11_byte);
        let v861_11_tail = v861_11_cursor.make_map();
        v861_11_cursor.ascend(1);
        let v861_11_head = Path::from_slice(&[v861_11_byte]);
        let v862_2: Space = singleton(&(v861_11_head));
        let v862_3: Space = intersect(&(*CONSTANT_3),&(v862_2));
        let v862_4: Space = if has_head(&(v862_3)) { singleton(&[]) } else { Space::new() };
        drop(v862_3);
        let v862_5: Space = subtract(&(*CONSTANT_2),&(v862_4));
        drop(v862_4);
        let v862_8: Space = if (v862_5).is_empty() { Space::new() } else {
          let v863_6: Path = concat_path(&(v861_6),&(v861_11_head));
          let v863_7: Space = routine_132(c, &(v863_6), &(*p1), &(v861_11_tail));
          compose(&(v862_5),&(v863_7))
        };
        drop(v862_5);
        let v862_9: Space = intersect(&(*CONSTANT_3),&(v862_2));
        drop(v862_2);
        let v862_10: Space = if has_head(&(v862_9)) { singleton(&[]) } else { Space::new() };
        drop(v862_9);
        let v862_12: Space = if (v862_10).is_empty() { Space::new() } else {
          let v864_6: Path = concat_path(&(v861_6),&(v861_11_head));
          let v864_11: Space = routine_95(c, &(v864_6), &(*p1), &(v861_11_tail));
          drop(v864_6);
          compose(&(v862_10),&(v864_11))
        };
        drop(v862_10);
        let v862_13: Space = unite(&(v862_8),&(v862_12));
        v861_11.join_into((v862_13).clone());
      }
      drop(v861_11_cursor);
      drop(v861_6);
      compose(&(v856_10),&(v861_11))
    };
    drop(v856_10);
    let v856_13: Space = unite(&(v856_8),&(v856_12));
    v855_12.join_into((v856_13).clone());
  }
  drop(v855_12_cursor);
  (v855_12).clone()
}

fn routine_90(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v865_9 = Space::new();
  let mut v865_9_cursor = (*s0).read_zipper();
  for v865_9_byte in v865_9_cursor.child_mask().iter() {
    v865_9_cursor.descend_to_byte(v865_9_byte);
    let v865_9_tail = v865_9_cursor.make_map();
    v865_9_cursor.ascend(1);
    let v865_9_head = Path::from_slice(&[v865_9_byte]);
    let v866_2: Space = singleton(&(v865_9_head));
    let v866_3: Space = intersect(&(*CONSTANT_3),&(v866_2));
    let v866_4: Space = if has_head(&(v866_3)) { singleton(&[]) } else { Space::new() };
    drop(v866_3);
    let v866_5: Space = subtract(&(*CONSTANT_2),&(v866_4));
    drop(v866_4);
    let v866_8: Space = if (v866_5).is_empty() { Space::new() } else {
      let v867_6: Path = concat_path(&(*p0),&(v865_9_head));
      let mut v867_7 = Space::new();
      let mut v867_7_cursor = (v865_9_tail).read_zipper();
      for v867_7_byte in v867_7_cursor.child_mask().iter() {
        v867_7_cursor.descend_to_byte(v867_7_byte);
        let v867_7_tail = v867_7_cursor.make_map();
        v867_7_cursor.ascend(1);
        let v867_7_head = Path::from_slice(&[v867_7_byte]);
        let v868_2: Space = singleton(&(v867_7_head));
        let v868_3: Space = intersect(&(*CONSTANT_3),&(v868_2));
        let v868_4: Space = if has_head(&(v868_3)) { singleton(&[]) } else { Space::new() };
        drop(v868_3);
        let v868_5: Space = subtract(&(*CONSTANT_2),&(v868_4));
        drop(v868_4);
        let v868_8: Space = if (v868_5).is_empty() { Space::new() } else {
          let v869_6: Path = concat_path(&(v867_6),&(v867_7_head));
          let v869_7: Space = routine_132(c, &(v869_6), &(*p1), &(v867_7_tail));
          compose(&(v868_5),&(v869_7))
        };
        drop(v868_5);
        let v868_9: Space = intersect(&(*CONSTANT_3),&(v868_2));
        drop(v868_2);
        let v868_10: Space = if has_head(&(v868_9)) { singleton(&[]) } else { Space::new() };
        drop(v868_9);
        let v868_12: Space = if (v868_10).is_empty() { Space::new() } else {
          let v870_6: Path = concat_path(&(v867_6),&(v867_7_head));
          let v870_11: Space = routine_133(c, &(v870_6), &(*p1), &(v867_7_tail));
          drop(v870_6);
          compose(&(v868_10),&(v870_11))
        };
        drop(v868_10);
        let v868_13: Space = unite(&(v868_8),&(v868_12));
        v867_7.join_into((v868_13).clone());
      }
      drop(v867_7_cursor);
      compose(&(v866_5),&(v867_7))
    };
    drop(v866_5);
    let v866_9: Space = intersect(&(*CONSTANT_3),&(v866_2));
    drop(v866_2);
    let v866_10: Space = if has_head(&(v866_9)) { singleton(&[]) } else { Space::new() };
    drop(v866_9);
    let v866_11: Space = compose(&(v866_10),&(v865_9_tail));
    drop(v866_10);
    let v871_6: Path = concat_path(&(*p0),&(v865_9_head));
    let v866_12: Space = wrap(&(v866_11),&(v871_6));
    drop(v866_11);
    let v866_13: Space = wrap(&(v866_12),&(*p1));
    drop(v866_12);
    let v866_14: Space = unite(&(v866_8),&(v866_13));
    drop(v866_13);
    v865_9.join_into((v866_14).clone());
  }
  drop(v865_9_cursor);
  (v865_9).clone()
}

fn routine_91(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v872_13 = Space::new();
  let mut v872_13_cursor = (*s0).read_zipper();
  for v872_13_byte in v872_13_cursor.child_mask().iter() {
    v872_13_cursor.descend_to_byte(v872_13_byte);
    let v872_13_tail = v872_13_cursor.make_map();
    v872_13_cursor.ascend(1);
    let v872_13_head = Path::from_slice(&[v872_13_byte]);
    let v873_2: Space = singleton(&(v872_13_head));
    let v873_3: Space = intersect(&(*CONSTANT_3),&(v873_2));
    let v873_4: Space = if has_head(&(v873_3)) { singleton(&[]) } else { Space::new() };
    drop(v873_3);
    let v873_5: Space = subtract(&(*CONSTANT_2),&(v873_4));
    drop(v873_4);
    let v873_8: Space = if (v873_5).is_empty() { Space::new() } else {
      let v874_6: Path = concat_path(&(*p0),&(v872_13_head));
      let mut v874_7 = Space::new();
      let mut v874_7_cursor = (v872_13_tail).read_zipper();
      for v874_7_byte in v874_7_cursor.child_mask().iter() {
        v874_7_cursor.descend_to_byte(v874_7_byte);
        let v874_7_tail = v874_7_cursor.make_map();
        v874_7_cursor.ascend(1);
        let v874_7_head = Path::from_slice(&[v874_7_byte]);
        let v875_2: Space = singleton(&(v874_7_head));
        let v875_3: Space = intersect(&(*CONSTANT_3),&(v875_2));
        let v875_4: Space = if has_head(&(v875_3)) { singleton(&[]) } else { Space::new() };
        drop(v875_3);
        let v875_5: Space = subtract(&(*CONSTANT_2),&(v875_4));
        drop(v875_4);
        let v875_8: Space = if (v875_5).is_empty() { Space::new() } else {
          let v876_6: Path = concat_path(&(v874_6),&(v874_7_head));
          let v876_7: Space = routine_134(c, &(v876_6), &(*p1), &(v874_7_tail), &(*s1));
          compose(&(v875_5),&(v876_7))
        };
        drop(v875_5);
        let v875_9: Space = intersect(&(*CONSTANT_3),&(v875_2));
        drop(v875_2);
        let v875_10: Space = if has_head(&(v875_9)) { singleton(&[]) } else { Space::new() };
        drop(v875_9);
        let v875_12: Space = if (v875_10).is_empty() { Space::new() } else {
          let v877_6: Path = concat_path(&(v874_6),&(v874_7_head));
          let v877_11: Space = routine_135(c, &(v877_6), &(*p1), &(v874_7_tail), &(*s1));
          drop(v877_6);
          compose(&(v875_10),&(v877_11))
        };
        drop(v875_10);
        let v875_13: Space = unite(&(v875_8),&(v875_12));
        v874_7.join_into((v875_13).clone());
      }
      drop(v874_7_cursor);
      compose(&(v873_5),&(v874_7))
    };
    drop(v873_5);
    let v873_9: Space = intersect(&(*CONSTANT_3),&(v873_2));
    drop(v873_2);
    let v873_10: Space = if has_head(&(v873_9)) { singleton(&[]) } else { Space::new() };
    drop(v873_9);
    let v873_12: Space = if (v873_10).is_empty() { Space::new() } else {
      let v878_6: Path = concat_path(&(*p0),&(v872_13_head));
      let mut v878_11 = Space::new();
      let mut v878_11_cursor = (v872_13_tail).read_zipper();
      for v878_11_byte in v878_11_cursor.child_mask().iter() {
        v878_11_cursor.descend_to_byte(v878_11_byte);
        let v878_11_tail = v878_11_cursor.make_map();
        v878_11_cursor.ascend(1);
        let v878_11_head = Path::from_slice(&[v878_11_byte]);
        let v879_2: Space = singleton(&(v878_11_head));
        let v879_3: Space = intersect(&(*CONSTANT_3),&(v879_2));
        let v879_4: Space = if has_head(&(v879_3)) { singleton(&[]) } else { Space::new() };
        drop(v879_3);
        let v879_5: Space = subtract(&(*CONSTANT_2),&(v879_4));
        drop(v879_4);
        let v879_8: Space = if (v879_5).is_empty() { Space::new() } else {
          let v880_6: Path = concat_path(&(v878_6),&(v878_11_head));
          let v880_7: Space = routine_134(c, &(v880_6), &(*p1), &(v878_11_tail), &(*s1));
          compose(&(v879_5),&(v880_7))
        };
        drop(v879_5);
        let v879_9: Space = intersect(&(*CONSTANT_3),&(v879_2));
        drop(v879_2);
        let v879_10: Space = if has_head(&(v879_9)) { singleton(&[]) } else { Space::new() };
        drop(v879_9);
        let v879_12: Space = if (v879_10).is_empty() { Space::new() } else {
          let v881_6: Path = concat_path(&(v878_6),&(v878_11_head));
          let v881_11: Space = routine_50(c, &(v881_6), &(*p1), &(v878_11_tail), &(*s1));
          drop(v881_6);
          compose(&(v879_10),&(v881_11))
        };
        drop(v879_10);
        let v879_13: Space = unite(&(v879_8),&(v879_12));
        v878_11.join_into((v879_13).clone());
      }
      drop(v878_11_cursor);
      drop(v878_6);
      compose(&(v873_10),&(v878_11))
    };
    drop(v873_10);
    let v873_13: Space = unite(&(v873_8),&(v873_12));
    v872_13.join_into((v873_13).clone());
  }
  drop(v872_13_cursor);
  (v872_13).clone()
}

fn routine_92(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v882_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v882_10: Space = unwrap(&(v882_8),&(*CONSTANT_5));
  drop(v882_8);
  let v882_11: Space = unwrap(&(v882_10),&(*p0));
  drop(v882_10);
  let mut v882_18 = Space::new();
  let mut v882_18_cursor = (*s0).read_zipper();
  for v882_18_byte in v882_18_cursor.child_mask().iter() {
    v882_18_cursor.descend_to_byte(v882_18_byte);
    let v882_18_tail = v882_18_cursor.make_map();
    v882_18_cursor.ascend(1);
    let v882_18_head = Path::from_slice(&[v882_18_byte]);
    let v883_2: Space = singleton(&(v882_18_head));
    let v883_3: Space = intersect(&(*CONSTANT_3),&(v883_2));
    let v883_4: Space = if has_head(&(v883_3)) { singleton(&[]) } else { Space::new() };
    drop(v883_3);
    let v883_5: Space = subtract(&(*CONSTANT_2),&(v883_4));
    drop(v883_4);
    let v883_8: Space = if (v883_5).is_empty() { Space::new() } else {
      let v884_6: Path = concat_path(&(*p0),&(v882_18_head));
      let mut v884_7 = Space::new();
      let mut v884_7_cursor = (v882_18_tail).read_zipper();
      for v884_7_byte in v884_7_cursor.child_mask().iter() {
        v884_7_cursor.descend_to_byte(v884_7_byte);
        let v884_7_tail = v884_7_cursor.make_map();
        v884_7_cursor.ascend(1);
        let v884_7_head = Path::from_slice(&[v884_7_byte]);
        let v885_2: Space = singleton(&(v884_7_head));
        let v885_3: Space = intersect(&(*CONSTANT_3),&(v885_2));
        let v885_4: Space = if has_head(&(v885_3)) { singleton(&[]) } else { Space::new() };
        drop(v885_3);
        let v885_5: Space = subtract(&(*CONSTANT_2),&(v885_4));
        drop(v885_4);
        let v885_8: Space = if (v885_5).is_empty() { Space::new() } else {
          let v886_6: Path = concat_path(&(v884_6),&(v884_7_head));
          let v886_7: Space = routine_134(c, &(v886_6), &(*p1), &(v884_7_tail), &(*s1));
          compose(&(v885_5),&(v886_7))
        };
        drop(v885_5);
        let v885_9: Space = intersect(&(*CONSTANT_3),&(v885_2));
        drop(v885_2);
        let v885_10: Space = if has_head(&(v885_9)) { singleton(&[]) } else { Space::new() };
        drop(v885_9);
        let v885_12: Space = if (v885_10).is_empty() { Space::new() } else {
          let v887_6: Path = concat_path(&(v884_6),&(v884_7_head));
          let v887_11: Space = routine_135(c, &(v887_6), &(*p1), &(v884_7_tail), &(*s1));
          drop(v887_6);
          compose(&(v885_10),&(v887_11))
        };
        drop(v885_10);
        let v885_13: Space = unite(&(v885_8),&(v885_12));
        v884_7.join_into((v885_13).clone());
      }
      drop(v884_7_cursor);
      drop(v884_6);
      compose(&(v883_5),&(v884_7))
    };
    drop(v883_5);
    let v883_9: Space = intersect(&(*CONSTANT_3),&(v883_2));
    drop(v883_2);
    let v883_10: Space = if has_head(&(v883_9)) { singleton(&[]) } else { Space::new() };
    drop(v883_9);
    let v883_13: Space = if (v883_10).is_empty() { Space::new() } else {
      let v888_11: Space = unwrap(&(v882_11),&(v882_18_head));
      let mut v888_12 = Space::new();
      let mut v888_12_cursor = (v888_11).read_zipper();
      for v888_12_byte in v888_12_cursor.child_mask().iter() {
        v888_12_cursor.descend_to_byte(v888_12_byte);
        let v888_12_tail = v888_12_cursor.make_map();
        v888_12_cursor.ascend(1);
        let v888_12_head = Path::from_slice(&[v888_12_byte]);
        let v889_2: Space = singleton(&(v888_12_head));
        let v889_3: Space = intersect(&(*CONSTANT_3),&(v889_2));
        let v889_4: Space = if has_head(&(v889_3)) { singleton(&[]) } else { Space::new() };
        drop(v889_3);
        let v889_5: Space = subtract(&(*CONSTANT_2),&(v889_4));
        drop(v889_4);
        let v889_7: Space = if (v889_5).is_empty() { Space::new() } else {
          let v890_6: Space = routine_89(c, &(v888_12_head), &(*p1), &(v888_12_tail));
          compose(&(v889_5),&(v890_6))
        };
        drop(v889_5);
        let v889_8: Space = intersect(&(*CONSTANT_3),&(v889_2));
        drop(v889_2);
        let v889_9: Space = if has_head(&(v889_8)) { singleton(&[]) } else { Space::new() };
        drop(v889_8);
        let v889_11: Space = if (v889_9).is_empty() { Space::new() } else {
          let v891_10: Space = routine_90(c, &(v888_12_head), &(*p1), &(v888_12_tail));
          compose(&(v889_9),&(v891_10))
        };
        drop(v889_9);
        let v889_12: Space = unite(&(v889_7),&(v889_11));
        v888_12.join_into((v889_12).clone());
      }
      drop(v888_12_cursor);
      drop(v888_11);
      compose(&(v883_10),&(v888_12))
    };
    drop(v883_10);
    let v883_14: Space = unite(&(v883_8),&(v883_13));
    v882_18.join_into((v883_14).clone());
  }
  drop(v882_18_cursor);
  drop(v882_11);
  (v882_18).clone()
}

fn routine_93(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v892_12 = Space::new();
  let mut v892_12_cursor = (*s0).read_zipper();
  for v892_12_byte in v892_12_cursor.child_mask().iter() {
    v892_12_cursor.descend_to_byte(v892_12_byte);
    let v892_12_tail = v892_12_cursor.make_map();
    v892_12_cursor.ascend(1);
    let v892_12_head = Path::from_slice(&[v892_12_byte]);
    let v893_2: Space = singleton(&(v892_12_head));
    let v893_3: Space = intersect(&(*CONSTANT_3),&(v893_2));
    let v893_4: Space = if has_head(&(v893_3)) { singleton(&[]) } else { Space::new() };
    drop(v893_3);
    let v893_5: Space = subtract(&(*CONSTANT_2),&(v893_4));
    drop(v893_4);
    let v893_8: Space = if (v893_5).is_empty() { Space::new() } else {
      let v894_6: Path = concat_path(&(*p0),&(v892_12_head));
      let mut v894_7 = Space::new();
      let mut v894_7_cursor = (v892_12_tail).read_zipper();
      for v894_7_byte in v894_7_cursor.child_mask().iter() {
        v894_7_cursor.descend_to_byte(v894_7_byte);
        let v894_7_tail = v894_7_cursor.make_map();
        v894_7_cursor.ascend(1);
        let v894_7_head = Path::from_slice(&[v894_7_byte]);
        let v895_2: Space = singleton(&(v894_7_head));
        let v895_3: Space = intersect(&(*CONSTANT_3),&(v895_2));
        let v895_4: Space = if has_head(&(v895_3)) { singleton(&[]) } else { Space::new() };
        drop(v895_3);
        let v895_5: Space = subtract(&(*CONSTANT_2),&(v895_4));
        drop(v895_4);
        let v895_8: Space = if (v895_5).is_empty() { Space::new() } else {
          let v896_6: Path = concat_path(&(v894_6),&(v894_7_head));
          let v896_7: Space = routine_136(c, &(v896_6), &(*p1), &(v894_7_tail));
          compose(&(v895_5),&(v896_7))
        };
        drop(v895_5);
        let v895_9: Space = intersect(&(*CONSTANT_3),&(v895_2));
        drop(v895_2);
        let v895_10: Space = if has_head(&(v895_9)) { singleton(&[]) } else { Space::new() };
        drop(v895_9);
        let v895_12: Space = if (v895_10).is_empty() { Space::new() } else {
          let v897_6: Path = concat_path(&(v894_6),&(v894_7_head));
          let v897_11: Space = routine_137(c, &(v897_6), &(*p1), &(v894_7_tail));
          drop(v897_6);
          compose(&(v895_10),&(v897_11))
        };
        drop(v895_10);
        let v895_13: Space = unite(&(v895_8),&(v895_12));
        v894_7.join_into((v895_13).clone());
      }
      drop(v894_7_cursor);
      compose(&(v893_5),&(v894_7))
    };
    drop(v893_5);
    let v893_9: Space = intersect(&(*CONSTANT_3),&(v893_2));
    drop(v893_2);
    let v893_10: Space = if has_head(&(v893_9)) { singleton(&[]) } else { Space::new() };
    drop(v893_9);
    let v893_12: Space = if (v893_10).is_empty() { Space::new() } else {
      let v898_6: Path = concat_path(&(*p0),&(v892_12_head));
      let mut v898_11 = Space::new();
      let mut v898_11_cursor = (v892_12_tail).read_zipper();
      for v898_11_byte in v898_11_cursor.child_mask().iter() {
        v898_11_cursor.descend_to_byte(v898_11_byte);
        let v898_11_tail = v898_11_cursor.make_map();
        v898_11_cursor.ascend(1);
        let v898_11_head = Path::from_slice(&[v898_11_byte]);
        let v899_2: Space = singleton(&(v898_11_head));
        let v899_3: Space = intersect(&(*CONSTANT_3),&(v899_2));
        let v899_4: Space = if has_head(&(v899_3)) { singleton(&[]) } else { Space::new() };
        drop(v899_3);
        let v899_5: Space = subtract(&(*CONSTANT_2),&(v899_4));
        drop(v899_4);
        let v899_8: Space = if (v899_5).is_empty() { Space::new() } else {
          let v900_6: Path = concat_path(&(v898_6),&(v898_11_head));
          let v900_7: Space = routine_136(c, &(v900_6), &(*p1), &(v898_11_tail));
          compose(&(v899_5),&(v900_7))
        };
        drop(v899_5);
        let v899_9: Space = intersect(&(*CONSTANT_3),&(v899_2));
        drop(v899_2);
        let v899_10: Space = if has_head(&(v899_9)) { singleton(&[]) } else { Space::new() };
        drop(v899_9);
        let v899_12: Space = if (v899_10).is_empty() { Space::new() } else {
          let v901_6: Path = concat_path(&(v898_6),&(v898_11_head));
          let v901_11: Space = routine_95(c, &(v901_6), &(*p1), &(v898_11_tail));
          drop(v901_6);
          compose(&(v899_10),&(v901_11))
        };
        drop(v899_10);
        let v899_13: Space = unite(&(v899_8),&(v899_12));
        v898_11.join_into((v899_13).clone());
      }
      drop(v898_11_cursor);
      drop(v898_6);
      compose(&(v893_10),&(v898_11))
    };
    drop(v893_10);
    let v893_13: Space = unite(&(v893_8),&(v893_12));
    v892_12.join_into((v893_13).clone());
  }
  drop(v892_12_cursor);
  (v892_12).clone()
}

fn routine_94(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v902_9 = Space::new();
  let mut v902_9_cursor = (*s0).read_zipper();
  for v902_9_byte in v902_9_cursor.child_mask().iter() {
    v902_9_cursor.descend_to_byte(v902_9_byte);
    let v902_9_tail = v902_9_cursor.make_map();
    v902_9_cursor.ascend(1);
    let v902_9_head = Path::from_slice(&[v902_9_byte]);
    let v903_2: Space = singleton(&(v902_9_head));
    let v903_3: Space = intersect(&(*CONSTANT_3),&(v903_2));
    let v903_4: Space = if has_head(&(v903_3)) { singleton(&[]) } else { Space::new() };
    drop(v903_3);
    let v903_5: Space = subtract(&(*CONSTANT_2),&(v903_4));
    drop(v903_4);
    let v903_8: Space = if (v903_5).is_empty() { Space::new() } else {
      let v904_6: Path = concat_path(&(*p0),&(v902_9_head));
      let mut v904_7 = Space::new();
      let mut v904_7_cursor = (v902_9_tail).read_zipper();
      for v904_7_byte in v904_7_cursor.child_mask().iter() {
        v904_7_cursor.descend_to_byte(v904_7_byte);
        let v904_7_tail = v904_7_cursor.make_map();
        v904_7_cursor.ascend(1);
        let v904_7_head = Path::from_slice(&[v904_7_byte]);
        let v905_2: Space = singleton(&(v904_7_head));
        let v905_3: Space = intersect(&(*CONSTANT_3),&(v905_2));
        let v905_4: Space = if has_head(&(v905_3)) { singleton(&[]) } else { Space::new() };
        drop(v905_3);
        let v905_5: Space = subtract(&(*CONSTANT_2),&(v905_4));
        drop(v905_4);
        let v905_8: Space = if (v905_5).is_empty() { Space::new() } else {
          let v906_6: Path = concat_path(&(v904_6),&(v904_7_head));
          let v906_7: Space = routine_136(c, &(v906_6), &(*p1), &(v904_7_tail));
          compose(&(v905_5),&(v906_7))
        };
        drop(v905_5);
        let v905_9: Space = intersect(&(*CONSTANT_3),&(v905_2));
        drop(v905_2);
        let v905_10: Space = if has_head(&(v905_9)) { singleton(&[]) } else { Space::new() };
        drop(v905_9);
        let v905_12: Space = if (v905_10).is_empty() { Space::new() } else {
          let v907_6: Path = concat_path(&(v904_6),&(v904_7_head));
          let v907_11: Space = routine_137(c, &(v907_6), &(*p1), &(v904_7_tail));
          drop(v907_6);
          compose(&(v905_10),&(v907_11))
        };
        drop(v905_10);
        let v905_13: Space = unite(&(v905_8),&(v905_12));
        v904_7.join_into((v905_13).clone());
      }
      drop(v904_7_cursor);
      compose(&(v903_5),&(v904_7))
    };
    drop(v903_5);
    let v903_9: Space = intersect(&(*CONSTANT_3),&(v903_2));
    drop(v903_2);
    let v903_10: Space = if has_head(&(v903_9)) { singleton(&[]) } else { Space::new() };
    drop(v903_9);
    let v903_11: Space = compose(&(v903_10),&(v902_9_tail));
    drop(v903_10);
    let v908_6: Path = concat_path(&(*p0),&(v902_9_head));
    let v903_12: Space = wrap(&(v903_11),&(v908_6));
    drop(v903_11);
    let v903_13: Space = wrap(&(v903_12),&(*p1));
    drop(v903_12);
    let v903_14: Space = unite(&(v903_8),&(v903_13));
    drop(v903_13);
    v902_9.join_into((v903_14).clone());
  }
  drop(v902_9_cursor);
  (v902_9).clone()
}

fn routine_95(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v909_3: Space = wrap(&(*s0),&(*p0));
  let v909_4: Space = wrap(&(v909_3),&(*p1));
  drop(v909_3);
  (v909_4).clone()
}

fn routine_96(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v910_2 = Space::new();
  let mut v910_2_cursor = (*s0).read_zipper();
  for v910_2_byte in v910_2_cursor.child_mask().iter() {
    v910_2_cursor.descend_to_byte(v910_2_byte);
    let v910_2_tail = v910_2_cursor.make_map();
    v910_2_cursor.ascend(1);
    let v910_2_head = Path::from_slice(&[v910_2_byte]);
    let v911_2: Space = Space::new();
    v910_2.join_into((v911_2).clone());
  }
  drop(v910_2_cursor);
  (v910_2).clone()
}

fn routine_97(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v912_6 = Space::new();
  let mut v912_6_cursor = (*s0).read_zipper();
  for v912_6_byte in v912_6_cursor.child_mask().iter() {
    v912_6_cursor.descend_to_byte(v912_6_byte);
    let v912_6_tail = v912_6_cursor.make_map();
    v912_6_cursor.ascend(1);
    let v912_6_head = Path::from_slice(&[v912_6_byte]);
    let v913_2: Space = singleton(&(v912_6_head));
    let v913_3: Space = intersect(&(*CONSTANT_3),&(v913_2));
    drop(v913_2);
    let v913_4: Space = if has_head(&(v913_3)) { singleton(&[]) } else { Space::new() };
    drop(v913_3);
    let v913_7: Space = if (v913_4).is_empty() { Space::new() } else {
      let v914_5: Path = concat_path(&(*p0),&(v912_6_head));
      let mut v914_6 = Space::new();
      let mut v914_6_cursor = (v912_6_tail).read_zipper();
      for v914_6_byte in v914_6_cursor.child_mask().iter() {
        v914_6_cursor.descend_to_byte(v914_6_byte);
        let v914_6_tail = v914_6_cursor.make_map();
        v914_6_cursor.ascend(1);
        let v914_6_head = Path::from_slice(&[v914_6_byte]);
        let v915_2: Space = singleton(&(v914_6_head));
        let v915_3: Space = intersect(&(*CONSTANT_3),&(v915_2));
        let v915_4: Space = if has_head(&(v915_3)) { singleton(&[]) } else { Space::new() };
        drop(v915_3);
        let v915_5: Space = subtract(&(*CONSTANT_2),&(v915_4));
        drop(v915_4);
        let v915_7: Space = if (v915_5).is_empty() { Space::new() } else {
          let v916_6: Space = routine_18(c, &(v914_6_head), &(v914_5), &(v914_6_tail));
          compose(&(v915_5),&(v916_6))
        };
        drop(v915_5);
        let v915_8: Space = intersect(&(*CONSTANT_3),&(v915_2));
        drop(v915_2);
        let v915_9: Space = if has_head(&(v915_8)) { singleton(&[]) } else { Space::new() };
        drop(v915_8);
        let v915_11: Space = if (v915_9).is_empty() { Space::new() } else {
          let v917_10: Space = routine_19(c, &(v914_6_head), &(v914_5), &(v914_6_tail));
          compose(&(v915_9),&(v917_10))
        };
        drop(v915_9);
        let v915_12: Space = unite(&(v915_7),&(v915_11));
        v914_6.join_into((v915_12).clone());
      }
      drop(v914_6_cursor);
      drop(v914_5);
      compose(&(v913_4),&(v914_6))
    };
    drop(v913_4);
    v912_6.join_into((v913_7).clone());
  }
  drop(v912_6_cursor);
  (v912_6).clone()
}

fn routine_98(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v918_12 = Space::new();
  let mut v918_12_cursor = (*s0).read_zipper();
  for v918_12_byte in v918_12_cursor.child_mask().iter() {
    v918_12_cursor.descend_to_byte(v918_12_byte);
    let v918_12_tail = v918_12_cursor.make_map();
    v918_12_cursor.ascend(1);
    let v918_12_head = Path::from_slice(&[v918_12_byte]);
    let v919_2: Space = singleton(&(v918_12_head));
    let v919_3: Space = intersect(&(*CONSTANT_3),&(v919_2));
    let v919_4: Space = if has_head(&(v919_3)) { singleton(&[]) } else { Space::new() };
    drop(v919_3);
    let v919_5: Space = subtract(&(*CONSTANT_2),&(v919_4));
    drop(v919_4);
    let v919_8: Space = if (v919_5).is_empty() { Space::new() } else {
      let v920_6: Path = concat_path(&(*p0),&(v918_12_head));
      let mut v920_7 = Space::new();
      let mut v920_7_cursor = (v918_12_tail).read_zipper();
      for v920_7_byte in v920_7_cursor.child_mask().iter() {
        v920_7_cursor.descend_to_byte(v920_7_byte);
        let v920_7_tail = v920_7_cursor.make_map();
        v920_7_cursor.ascend(1);
        let v920_7_head = Path::from_slice(&[v920_7_byte]);
        let v921_2: Space = singleton(&(v920_7_head));
        let v921_3: Space = intersect(&(*CONSTANT_3),&(v921_2));
        let v921_4: Space = if has_head(&(v921_3)) { singleton(&[]) } else { Space::new() };
        drop(v921_3);
        let v921_5: Space = subtract(&(*CONSTANT_2),&(v921_4));
        drop(v921_4);
        let v921_8: Space = if (v921_5).is_empty() { Space::new() } else {
          let v922_6: Path = concat_path(&(v920_6),&(v920_7_head));
          let v922_7: Space = routine_138(c, &(v922_6), &(*p1), &(v920_7_tail));
          compose(&(v921_5),&(v922_7))
        };
        drop(v921_5);
        let v921_9: Space = intersect(&(*CONSTANT_3),&(v921_2));
        drop(v921_2);
        let v921_10: Space = if has_head(&(v921_9)) { singleton(&[]) } else { Space::new() };
        drop(v921_9);
        let v921_12: Space = if (v921_10).is_empty() { Space::new() } else {
          let v923_6: Path = concat_path(&(v920_6),&(v920_7_head));
          let v923_11: Space = routine_139(c, &(v923_6), &(*p1), &(v920_7_tail));
          drop(v923_6);
          compose(&(v921_10),&(v923_11))
        };
        drop(v921_10);
        let v921_13: Space = unite(&(v921_8),&(v921_12));
        v920_7.join_into((v921_13).clone());
      }
      drop(v920_7_cursor);
      compose(&(v919_5),&(v920_7))
    };
    drop(v919_5);
    let v919_9: Space = intersect(&(*CONSTANT_3),&(v919_2));
    drop(v919_2);
    let v919_10: Space = if has_head(&(v919_9)) { singleton(&[]) } else { Space::new() };
    drop(v919_9);
    let v919_12: Space = if (v919_10).is_empty() { Space::new() } else {
      let v924_6: Path = concat_path(&(*p0),&(v918_12_head));
      let mut v924_11 = Space::new();
      let mut v924_11_cursor = (v918_12_tail).read_zipper();
      for v924_11_byte in v924_11_cursor.child_mask().iter() {
        v924_11_cursor.descend_to_byte(v924_11_byte);
        let v924_11_tail = v924_11_cursor.make_map();
        v924_11_cursor.ascend(1);
        let v924_11_head = Path::from_slice(&[v924_11_byte]);
        let v925_2: Space = singleton(&(v924_11_head));
        let v925_3: Space = intersect(&(*CONSTANT_3),&(v925_2));
        let v925_4: Space = if has_head(&(v925_3)) { singleton(&[]) } else { Space::new() };
        drop(v925_3);
        let v925_5: Space = subtract(&(*CONSTANT_2),&(v925_4));
        drop(v925_4);
        let v925_8: Space = if (v925_5).is_empty() { Space::new() } else {
          let v926_6: Path = concat_path(&(v924_6),&(v924_11_head));
          let v926_7: Space = routine_138(c, &(v926_6), &(*p1), &(v924_11_tail));
          compose(&(v925_5),&(v926_7))
        };
        drop(v925_5);
        let v925_9: Space = intersect(&(*CONSTANT_3),&(v925_2));
        drop(v925_2);
        let v925_10: Space = if has_head(&(v925_9)) { singleton(&[]) } else { Space::new() };
        drop(v925_9);
        let v925_12: Space = if (v925_10).is_empty() { Space::new() } else {
          let v927_6: Path = concat_path(&(v924_6),&(v924_11_head));
          let v927_11: Space = routine_22(c, &(v927_6), &(*p1), &(v924_11_tail));
          drop(v927_6);
          compose(&(v925_10),&(v927_11))
        };
        drop(v925_10);
        let v925_13: Space = unite(&(v925_8),&(v925_12));
        v924_11.join_into((v925_13).clone());
      }
      drop(v924_11_cursor);
      drop(v924_6);
      compose(&(v919_10),&(v924_11))
    };
    drop(v919_10);
    let v919_13: Space = unite(&(v919_8),&(v919_12));
    v918_12.join_into((v919_13).clone());
  }
  drop(v918_12_cursor);
  (v918_12).clone()
}

fn routine_99(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v928_10 = Space::new();
  let mut v928_10_cursor = (*s0).read_zipper();
  for v928_10_byte in v928_10_cursor.child_mask().iter() {
    v928_10_cursor.descend_to_byte(v928_10_byte);
    let v928_10_tail = v928_10_cursor.make_map();
    v928_10_cursor.ascend(1);
    let v928_10_head = Path::from_slice(&[v928_10_byte]);
    let v929_2: Space = singleton(&(v928_10_head));
    let v929_3: Space = intersect(&(*CONSTANT_3),&(v929_2));
    let v929_4: Space = if has_head(&(v929_3)) { singleton(&[]) } else { Space::new() };
    drop(v929_3);
    let v929_5: Space = compose(&(v929_4),&(v928_10_tail));
    drop(v929_4);
    let v930_6: Path = concat_path(&(*p0),&(v928_10_head));
    let v929_7: Space = wrap(&(v929_5),&(v930_6));
    drop(v929_5);
    let v929_8: Space = wrap(&(v929_7),&(*p1));
    drop(v929_7);
    let v929_9: Space = wrap(&(v929_8),&(*CONSTANT_5));
    drop(v929_8);
    let v929_10: Space = intersect(&(*CONSTANT_3),&(v929_2));
    drop(v929_2);
    let v929_11: Space = if has_head(&(v929_10)) { singleton(&[]) } else { Space::new() };
    drop(v929_10);
    let v929_12: Space = subtract(&(*CONSTANT_2),&(v929_11));
    drop(v929_11);
    let v929_14: Space = if (v929_12).is_empty() { Space::new() } else {
      let mut v931_13 = Space::new();
      let mut v931_13_cursor = (v928_10_tail).read_zipper();
      for v931_13_byte in v931_13_cursor.child_mask().iter() {
        v931_13_cursor.descend_to_byte(v931_13_byte);
        let v931_13_tail = v931_13_cursor.make_map();
        v931_13_cursor.ascend(1);
        let v931_13_head = Path::from_slice(&[v931_13_byte]);
        let v932_2: Space = singleton(&(v931_13_head));
        let v932_3: Space = intersect(&(*CONSTANT_3),&(v932_2));
        let v932_4: Space = if has_head(&(v932_3)) { singleton(&[]) } else { Space::new() };
        drop(v932_3);
        let v932_5: Space = subtract(&(*CONSTANT_2),&(v932_4));
        drop(v932_4);
        let v932_8: Space = if (v932_5).is_empty() { Space::new() } else {
          let v933_6: Path = concat_path(&(v930_6),&(v931_13_head));
          let v933_7: Space = routine_138(c, &(v933_6), &(*p1), &(v931_13_tail));
          compose(&(v932_5),&(v933_7))
        };
        drop(v932_5);
        let v932_9: Space = intersect(&(*CONSTANT_3),&(v932_2));
        drop(v932_2);
        let v932_10: Space = if has_head(&(v932_9)) { singleton(&[]) } else { Space::new() };
        drop(v932_9);
        let v932_12: Space = if (v932_10).is_empty() { Space::new() } else {
          let v934_6: Path = concat_path(&(v930_6),&(v931_13_head));
          let v934_11: Space = routine_139(c, &(v934_6), &(*p1), &(v931_13_tail));
          drop(v934_6);
          compose(&(v932_10),&(v934_11))
        };
        drop(v932_10);
        let v932_13: Space = unite(&(v932_8),&(v932_12));
        v931_13.join_into((v932_13).clone());
      }
      drop(v931_13_cursor);
      compose(&(v929_12),&(v931_13))
    };
    drop(v929_12);
    let v929_15: Space = unite(&(v929_9),&(v929_14));
    drop(v929_9);
    v928_10.join_into((v929_15).clone());
  }
  drop(v928_10_cursor);
  (v928_10).clone()
}

fn routine_100(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v935_12 = Space::new();
  let mut v935_12_cursor = (*s0).read_zipper();
  for v935_12_byte in v935_12_cursor.child_mask().iter() {
    v935_12_cursor.descend_to_byte(v935_12_byte);
    let v935_12_tail = v935_12_cursor.make_map();
    v935_12_cursor.ascend(1);
    let v935_12_head = Path::from_slice(&[v935_12_byte]);
    let v936_2: Space = singleton(&(v935_12_head));
    let v936_3: Space = intersect(&(*CONSTANT_3),&(v936_2));
    let v936_4: Space = if has_head(&(v936_3)) { singleton(&[]) } else { Space::new() };
    drop(v936_3);
    let v936_5: Space = subtract(&(*CONSTANT_2),&(v936_4));
    drop(v936_4);
    let v936_8: Space = if (v936_5).is_empty() { Space::new() } else {
      let v937_6: Path = concat_path(&(*p0),&(v935_12_head));
      let mut v937_7 = Space::new();
      let mut v937_7_cursor = (v935_12_tail).read_zipper();
      for v937_7_byte in v937_7_cursor.child_mask().iter() {
        v937_7_cursor.descend_to_byte(v937_7_byte);
        let v937_7_tail = v937_7_cursor.make_map();
        v937_7_cursor.ascend(1);
        let v937_7_head = Path::from_slice(&[v937_7_byte]);
        let v938_2: Space = singleton(&(v937_7_head));
        let v938_3: Space = intersect(&(*CONSTANT_3),&(v938_2));
        let v938_4: Space = if has_head(&(v938_3)) { singleton(&[]) } else { Space::new() };
        drop(v938_3);
        let v938_5: Space = subtract(&(*CONSTANT_2),&(v938_4));
        drop(v938_4);
        let v938_8: Space = if (v938_5).is_empty() { Space::new() } else {
          let v939_6: Path = concat_path(&(v937_6),&(v937_7_head));
          let v939_7: Space = routine_140(c, &(v939_6), &(*p1), &(v937_7_tail));
          compose(&(v938_5),&(v939_7))
        };
        drop(v938_5);
        let v938_9: Space = intersect(&(*CONSTANT_3),&(v938_2));
        drop(v938_2);
        let v938_10: Space = if has_head(&(v938_9)) { singleton(&[]) } else { Space::new() };
        drop(v938_9);
        let v938_12: Space = if (v938_10).is_empty() { Space::new() } else {
          let v940_6: Path = concat_path(&(v937_6),&(v937_7_head));
          let v940_11: Space = routine_141(c, &(v940_6), &(*p1), &(v937_7_tail));
          drop(v940_6);
          compose(&(v938_10),&(v940_11))
        };
        drop(v938_10);
        let v938_13: Space = unite(&(v938_8),&(v938_12));
        v937_7.join_into((v938_13).clone());
      }
      drop(v937_7_cursor);
      compose(&(v936_5),&(v937_7))
    };
    drop(v936_5);
    let v936_9: Space = intersect(&(*CONSTANT_3),&(v936_2));
    drop(v936_2);
    let v936_10: Space = if has_head(&(v936_9)) { singleton(&[]) } else { Space::new() };
    drop(v936_9);
    let v936_12: Space = if (v936_10).is_empty() { Space::new() } else {
      let v941_6: Path = concat_path(&(*p0),&(v935_12_head));
      let mut v941_11 = Space::new();
      let mut v941_11_cursor = (v935_12_tail).read_zipper();
      for v941_11_byte in v941_11_cursor.child_mask().iter() {
        v941_11_cursor.descend_to_byte(v941_11_byte);
        let v941_11_tail = v941_11_cursor.make_map();
        v941_11_cursor.ascend(1);
        let v941_11_head = Path::from_slice(&[v941_11_byte]);
        let v942_2: Space = singleton(&(v941_11_head));
        let v942_3: Space = intersect(&(*CONSTANT_3),&(v942_2));
        let v942_4: Space = if has_head(&(v942_3)) { singleton(&[]) } else { Space::new() };
        drop(v942_3);
        let v942_5: Space = subtract(&(*CONSTANT_2),&(v942_4));
        drop(v942_4);
        let v942_8: Space = if (v942_5).is_empty() { Space::new() } else {
          let v943_6: Path = concat_path(&(v941_6),&(v941_11_head));
          let v943_7: Space = routine_140(c, &(v943_6), &(*p1), &(v941_11_tail));
          compose(&(v942_5),&(v943_7))
        };
        drop(v942_5);
        let v942_9: Space = intersect(&(*CONSTANT_3),&(v942_2));
        drop(v942_2);
        let v942_10: Space = if has_head(&(v942_9)) { singleton(&[]) } else { Space::new() };
        drop(v942_9);
        let v942_12: Space = if (v942_10).is_empty() { Space::new() } else {
          let v944_6: Path = concat_path(&(v941_6),&(v941_11_head));
          let v944_11: Space = routine_22(c, &(v944_6), &(*p1), &(v941_11_tail));
          drop(v944_6);
          compose(&(v942_10),&(v944_11))
        };
        drop(v942_10);
        let v942_13: Space = unite(&(v942_8),&(v942_12));
        v941_11.join_into((v942_13).clone());
      }
      drop(v941_11_cursor);
      drop(v941_6);
      compose(&(v936_10),&(v941_11))
    };
    drop(v936_10);
    let v936_13: Space = unite(&(v936_8),&(v936_12));
    v935_12.join_into((v936_13).clone());
  }
  drop(v935_12_cursor);
  (v935_12).clone()
}

fn routine_101(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v945_10 = Space::new();
  let mut v945_10_cursor = (*s0).read_zipper();
  for v945_10_byte in v945_10_cursor.child_mask().iter() {
    v945_10_cursor.descend_to_byte(v945_10_byte);
    let v945_10_tail = v945_10_cursor.make_map();
    v945_10_cursor.ascend(1);
    let v945_10_head = Path::from_slice(&[v945_10_byte]);
    let v946_2: Space = singleton(&(v945_10_head));
    let v946_3: Space = intersect(&(*CONSTANT_3),&(v946_2));
    let v946_4: Space = if has_head(&(v946_3)) { singleton(&[]) } else { Space::new() };
    drop(v946_3);
    let v946_5: Space = compose(&(v946_4),&(v945_10_tail));
    drop(v946_4);
    let v947_6: Path = concat_path(&(*p0),&(v945_10_head));
    let v946_7: Space = wrap(&(v946_5),&(v947_6));
    drop(v946_5);
    let v946_8: Space = wrap(&(v946_7),&(*p1));
    drop(v946_7);
    let v946_9: Space = wrap(&(v946_8),&(*CONSTANT_5));
    drop(v946_8);
    let v946_10: Space = intersect(&(*CONSTANT_3),&(v946_2));
    drop(v946_2);
    let v946_11: Space = if has_head(&(v946_10)) { singleton(&[]) } else { Space::new() };
    drop(v946_10);
    let v946_12: Space = subtract(&(*CONSTANT_2),&(v946_11));
    drop(v946_11);
    let v946_14: Space = if (v946_12).is_empty() { Space::new() } else {
      let mut v948_13 = Space::new();
      let mut v948_13_cursor = (v945_10_tail).read_zipper();
      for v948_13_byte in v948_13_cursor.child_mask().iter() {
        v948_13_cursor.descend_to_byte(v948_13_byte);
        let v948_13_tail = v948_13_cursor.make_map();
        v948_13_cursor.ascend(1);
        let v948_13_head = Path::from_slice(&[v948_13_byte]);
        let v949_2: Space = singleton(&(v948_13_head));
        let v949_3: Space = intersect(&(*CONSTANT_3),&(v949_2));
        let v949_4: Space = if has_head(&(v949_3)) { singleton(&[]) } else { Space::new() };
        drop(v949_3);
        let v949_5: Space = subtract(&(*CONSTANT_2),&(v949_4));
        drop(v949_4);
        let v949_8: Space = if (v949_5).is_empty() { Space::new() } else {
          let v950_6: Path = concat_path(&(v947_6),&(v948_13_head));
          let v950_7: Space = routine_140(c, &(v950_6), &(*p1), &(v948_13_tail));
          compose(&(v949_5),&(v950_7))
        };
        drop(v949_5);
        let v949_9: Space = intersect(&(*CONSTANT_3),&(v949_2));
        drop(v949_2);
        let v949_10: Space = if has_head(&(v949_9)) { singleton(&[]) } else { Space::new() };
        drop(v949_9);
        let v949_12: Space = if (v949_10).is_empty() { Space::new() } else {
          let v951_6: Path = concat_path(&(v947_6),&(v948_13_head));
          let v951_11: Space = routine_141(c, &(v951_6), &(*p1), &(v948_13_tail));
          drop(v951_6);
          compose(&(v949_10),&(v951_11))
        };
        drop(v949_10);
        let v949_13: Space = unite(&(v949_8),&(v949_12));
        v948_13.join_into((v949_13).clone());
      }
      drop(v948_13_cursor);
      compose(&(v946_12),&(v948_13))
    };
    drop(v946_12);
    let v946_15: Space = unite(&(v946_9),&(v946_14));
    drop(v946_9);
    v945_10.join_into((v946_15).clone());
  }
  drop(v945_10_cursor);
  (v945_10).clone()
}

fn routine_102(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v952_3 = Space::new();
  let mut v952_3_cursor = (*s0).read_zipper();
  for v952_3_byte in v952_3_cursor.child_mask().iter() {
    v952_3_cursor.descend_to_byte(v952_3_byte);
    let v952_3_tail = v952_3_cursor.make_map();
    v952_3_cursor.ascend(1);
    let v952_3_head = Path::from_slice(&[v952_3_byte]);
    let v953_2: Space = Space::new();
    v952_3.join_into((v953_2).clone());
  }
  drop(v952_3_cursor);
  (v952_3).clone()
}

fn routine_103(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v954_7 = Space::new();
  let mut v954_7_cursor = (*s0).read_zipper();
  for v954_7_byte in v954_7_cursor.child_mask().iter() {
    v954_7_cursor.descend_to_byte(v954_7_byte);
    let v954_7_tail = v954_7_cursor.make_map();
    v954_7_cursor.ascend(1);
    let v954_7_head = Path::from_slice(&[v954_7_byte]);
    let v955_2: Space = singleton(&(v954_7_head));
    let v955_3: Space = intersect(&(*CONSTANT_3),&(v955_2));
    drop(v955_2);
    let v955_4: Space = if has_head(&(v955_3)) { singleton(&[]) } else { Space::new() };
    drop(v955_3);
    let v955_7: Space = if (v955_4).is_empty() { Space::new() } else {
      let v956_5: Path = concat_path(&(*p0),&(v954_7_head));
      let mut v956_6 = Space::new();
      let mut v956_6_cursor = (v954_7_tail).read_zipper();
      for v956_6_byte in v956_6_cursor.child_mask().iter() {
        v956_6_cursor.descend_to_byte(v956_6_byte);
        let v956_6_tail = v956_6_cursor.make_map();
        v956_6_cursor.ascend(1);
        let v956_6_head = Path::from_slice(&[v956_6_byte]);
        let v957_2: Space = singleton(&(v956_6_head));
        let v957_3: Space = intersect(&(*CONSTANT_3),&(v957_2));
        let v957_4: Space = if has_head(&(v957_3)) { singleton(&[]) } else { Space::new() };
        drop(v957_3);
        let v957_5: Space = subtract(&(*CONSTANT_2),&(v957_4));
        drop(v957_4);
        let v957_7: Space = if (v957_5).is_empty() { Space::new() } else {
          let v958_6: Space = routine_25(c, &(v956_6_head), &(v956_5), &(v956_6_tail), &(*s1));
          compose(&(v957_5),&(v958_6))
        };
        drop(v957_5);
        let v957_8: Space = intersect(&(*CONSTANT_3),&(v957_2));
        drop(v957_2);
        let v957_9: Space = if has_head(&(v957_8)) { singleton(&[]) } else { Space::new() };
        drop(v957_8);
        let v957_11: Space = if (v957_9).is_empty() { Space::new() } else {
          let v959_10: Space = routine_26(c, &(v956_6_head), &(v956_5), &(v956_6_tail), &(*s1));
          compose(&(v957_9),&(v959_10))
        };
        drop(v957_9);
        let v957_12: Space = unite(&(v957_7),&(v957_11));
        v956_6.join_into((v957_12).clone());
      }
      drop(v956_6_cursor);
      drop(v956_5);
      compose(&(v955_4),&(v956_6))
    };
    drop(v955_4);
    v954_7.join_into((v955_7).clone());
  }
  drop(v954_7_cursor);
  (v954_7).clone()
}

fn routine_104(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v960_13 = Space::new();
  let mut v960_13_cursor = (*s0).read_zipper();
  for v960_13_byte in v960_13_cursor.child_mask().iter() {
    v960_13_cursor.descend_to_byte(v960_13_byte);
    let v960_13_tail = v960_13_cursor.make_map();
    v960_13_cursor.ascend(1);
    let v960_13_head = Path::from_slice(&[v960_13_byte]);
    let v961_2: Space = singleton(&(v960_13_head));
    let v961_3: Space = intersect(&(*CONSTANT_3),&(v961_2));
    let v961_4: Space = if has_head(&(v961_3)) { singleton(&[]) } else { Space::new() };
    drop(v961_3);
    let v961_5: Space = subtract(&(*CONSTANT_2),&(v961_4));
    drop(v961_4);
    let v961_8: Space = if (v961_5).is_empty() { Space::new() } else {
      let v962_6: Path = concat_path(&(*p0),&(v960_13_head));
      let mut v962_7 = Space::new();
      let mut v962_7_cursor = (v960_13_tail).read_zipper();
      for v962_7_byte in v962_7_cursor.child_mask().iter() {
        v962_7_cursor.descend_to_byte(v962_7_byte);
        let v962_7_tail = v962_7_cursor.make_map();
        v962_7_cursor.ascend(1);
        let v962_7_head = Path::from_slice(&[v962_7_byte]);
        let v963_2: Space = singleton(&(v962_7_head));
        let v963_3: Space = intersect(&(*CONSTANT_3),&(v963_2));
        let v963_4: Space = if has_head(&(v963_3)) { singleton(&[]) } else { Space::new() };
        drop(v963_3);
        let v963_5: Space = subtract(&(*CONSTANT_2),&(v963_4));
        drop(v963_4);
        let v963_8: Space = if (v963_5).is_empty() { Space::new() } else {
          let v964_6: Path = concat_path(&(v962_6),&(v962_7_head));
          let v964_7: Space = routine_142(c, &(v964_6), &(*p1), &(v962_7_tail), &(*s1));
          compose(&(v963_5),&(v964_7))
        };
        drop(v963_5);
        let v963_9: Space = intersect(&(*CONSTANT_3),&(v963_2));
        drop(v963_2);
        let v963_10: Space = if has_head(&(v963_9)) { singleton(&[]) } else { Space::new() };
        drop(v963_9);
        let v963_12: Space = if (v963_10).is_empty() { Space::new() } else {
          let v965_6: Path = concat_path(&(v962_6),&(v962_7_head));
          let v965_11: Space = routine_143(c, &(v965_6), &(*p1), &(v962_7_tail), &(*s1));
          drop(v965_6);
          compose(&(v963_10),&(v965_11))
        };
        drop(v963_10);
        let v963_13: Space = unite(&(v963_8),&(v963_12));
        v962_7.join_into((v963_13).clone());
      }
      drop(v962_7_cursor);
      compose(&(v961_5),&(v962_7))
    };
    drop(v961_5);
    let v961_9: Space = intersect(&(*CONSTANT_3),&(v961_2));
    drop(v961_2);
    let v961_10: Space = if has_head(&(v961_9)) { singleton(&[]) } else { Space::new() };
    drop(v961_9);
    let v961_12: Space = if (v961_10).is_empty() { Space::new() } else {
      let v966_6: Path = concat_path(&(*p0),&(v960_13_head));
      let mut v966_11 = Space::new();
      let mut v966_11_cursor = (v960_13_tail).read_zipper();
      for v966_11_byte in v966_11_cursor.child_mask().iter() {
        v966_11_cursor.descend_to_byte(v966_11_byte);
        let v966_11_tail = v966_11_cursor.make_map();
        v966_11_cursor.ascend(1);
        let v966_11_head = Path::from_slice(&[v966_11_byte]);
        let v967_2: Space = singleton(&(v966_11_head));
        let v967_3: Space = intersect(&(*CONSTANT_3),&(v967_2));
        let v967_4: Space = if has_head(&(v967_3)) { singleton(&[]) } else { Space::new() };
        drop(v967_3);
        let v967_5: Space = subtract(&(*CONSTANT_2),&(v967_4));
        drop(v967_4);
        let v967_8: Space = if (v967_5).is_empty() { Space::new() } else {
          let v968_6: Path = concat_path(&(v966_6),&(v966_11_head));
          let v968_7: Space = routine_142(c, &(v968_6), &(*p1), &(v966_11_tail), &(*s1));
          compose(&(v967_5),&(v968_7))
        };
        drop(v967_5);
        let v967_9: Space = intersect(&(*CONSTANT_3),&(v967_2));
        drop(v967_2);
        let v967_10: Space = if has_head(&(v967_9)) { singleton(&[]) } else { Space::new() };
        drop(v967_9);
        let v967_12: Space = if (v967_10).is_empty() { Space::new() } else {
          let v969_6: Path = concat_path(&(v966_6),&(v966_11_head));
          let v969_11: Space = routine_29(c, &(v969_6), &(*p1), &(v966_11_tail), &(*s1));
          drop(v969_6);
          compose(&(v967_10),&(v969_11))
        };
        drop(v967_10);
        let v967_13: Space = unite(&(v967_8),&(v967_12));
        v966_11.join_into((v967_13).clone());
      }
      drop(v966_11_cursor);
      drop(v966_6);
      compose(&(v961_10),&(v966_11))
    };
    drop(v961_10);
    let v961_13: Space = unite(&(v961_8),&(v961_12));
    v960_13.join_into((v961_13).clone());
  }
  drop(v960_13_cursor);
  (v960_13).clone()
}

fn routine_105(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v970_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v970_10: Space = unwrap(&(v970_8),&(*CONSTANT_5));
  drop(v970_8);
  let v970_11: Space = unwrap(&(v970_10),&(*p0));
  drop(v970_10);
  let mut v970_18 = Space::new();
  let mut v970_18_cursor = (*s0).read_zipper();
  for v970_18_byte in v970_18_cursor.child_mask().iter() {
    v970_18_cursor.descend_to_byte(v970_18_byte);
    let v970_18_tail = v970_18_cursor.make_map();
    v970_18_cursor.ascend(1);
    let v970_18_head = Path::from_slice(&[v970_18_byte]);
    let v971_2: Space = singleton(&(v970_18_head));
    let v971_3: Space = intersect(&(*CONSTANT_3),&(v971_2));
    let v971_4: Space = if has_head(&(v971_3)) { singleton(&[]) } else { Space::new() };
    drop(v971_3);
    let v971_5: Space = subtract(&(*CONSTANT_2),&(v971_4));
    drop(v971_4);
    let v971_8: Space = if (v971_5).is_empty() { Space::new() } else {
      let v972_6: Path = concat_path(&(*p0),&(v970_18_head));
      let mut v972_7 = Space::new();
      let mut v972_7_cursor = (v970_18_tail).read_zipper();
      for v972_7_byte in v972_7_cursor.child_mask().iter() {
        v972_7_cursor.descend_to_byte(v972_7_byte);
        let v972_7_tail = v972_7_cursor.make_map();
        v972_7_cursor.ascend(1);
        let v972_7_head = Path::from_slice(&[v972_7_byte]);
        let v973_2: Space = singleton(&(v972_7_head));
        let v973_3: Space = intersect(&(*CONSTANT_3),&(v973_2));
        let v973_4: Space = if has_head(&(v973_3)) { singleton(&[]) } else { Space::new() };
        drop(v973_3);
        let v973_5: Space = subtract(&(*CONSTANT_2),&(v973_4));
        drop(v973_4);
        let v973_8: Space = if (v973_5).is_empty() { Space::new() } else {
          let v974_6: Path = concat_path(&(v972_6),&(v972_7_head));
          let v974_7: Space = routine_142(c, &(v974_6), &(*p1), &(v972_7_tail), &(*s1));
          compose(&(v973_5),&(v974_7))
        };
        drop(v973_5);
        let v973_9: Space = intersect(&(*CONSTANT_3),&(v973_2));
        drop(v973_2);
        let v973_10: Space = if has_head(&(v973_9)) { singleton(&[]) } else { Space::new() };
        drop(v973_9);
        let v973_12: Space = if (v973_10).is_empty() { Space::new() } else {
          let v975_6: Path = concat_path(&(v972_6),&(v972_7_head));
          let v975_11: Space = routine_143(c, &(v975_6), &(*p1), &(v972_7_tail), &(*s1));
          drop(v975_6);
          compose(&(v973_10),&(v975_11))
        };
        drop(v973_10);
        let v973_13: Space = unite(&(v973_8),&(v973_12));
        v972_7.join_into((v973_13).clone());
      }
      drop(v972_7_cursor);
      drop(v972_6);
      compose(&(v971_5),&(v972_7))
    };
    drop(v971_5);
    let v971_9: Space = intersect(&(*CONSTANT_3),&(v971_2));
    drop(v971_2);
    let v971_10: Space = if has_head(&(v971_9)) { singleton(&[]) } else { Space::new() };
    drop(v971_9);
    let v971_13: Space = if (v971_10).is_empty() { Space::new() } else {
      let v976_11: Space = unwrap(&(v970_11),&(v970_18_head));
      let mut v976_12 = Space::new();
      let mut v976_12_cursor = (v976_11).read_zipper();
      for v976_12_byte in v976_12_cursor.child_mask().iter() {
        v976_12_cursor.descend_to_byte(v976_12_byte);
        let v976_12_tail = v976_12_cursor.make_map();
        v976_12_cursor.ascend(1);
        let v976_12_head = Path::from_slice(&[v976_12_byte]);
        let v977_2: Space = singleton(&(v976_12_head));
        let v977_3: Space = intersect(&(*CONSTANT_3),&(v977_2));
        let v977_4: Space = if has_head(&(v977_3)) { singleton(&[]) } else { Space::new() };
        drop(v977_3);
        let v977_5: Space = subtract(&(*CONSTANT_2),&(v977_4));
        drop(v977_4);
        let v977_7: Space = if (v977_5).is_empty() { Space::new() } else {
          let v978_6: Space = routine_61(c, &(v976_12_head), &(*p1), &(v976_12_tail));
          compose(&(v977_5),&(v978_6))
        };
        drop(v977_5);
        let v977_8: Space = intersect(&(*CONSTANT_3),&(v977_2));
        drop(v977_2);
        let v977_9: Space = if has_head(&(v977_8)) { singleton(&[]) } else { Space::new() };
        drop(v977_8);
        let v977_11: Space = if (v977_9).is_empty() { Space::new() } else {
          let v979_10: Space = routine_62(c, &(v976_12_head), &(*p1), &(v976_12_tail));
          compose(&(v977_9),&(v979_10))
        };
        drop(v977_9);
        let v977_12: Space = unite(&(v977_7),&(v977_11));
        v976_12.join_into((v977_12).clone());
      }
      drop(v976_12_cursor);
      drop(v976_11);
      compose(&(v971_10),&(v976_12))
    };
    drop(v971_10);
    let v971_14: Space = unite(&(v971_8),&(v971_13));
    v970_18.join_into((v971_14).clone());
  }
  drop(v970_18_cursor);
  drop(v970_11);
  (v970_18).clone()
}

fn routine_106(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v980_12 = Space::new();
  let mut v980_12_cursor = (*s0).read_zipper();
  for v980_12_byte in v980_12_cursor.child_mask().iter() {
    v980_12_cursor.descend_to_byte(v980_12_byte);
    let v980_12_tail = v980_12_cursor.make_map();
    v980_12_cursor.ascend(1);
    let v980_12_head = Path::from_slice(&[v980_12_byte]);
    let v981_2: Space = singleton(&(v980_12_head));
    let v981_3: Space = intersect(&(*CONSTANT_3),&(v981_2));
    let v981_4: Space = if has_head(&(v981_3)) { singleton(&[]) } else { Space::new() };
    drop(v981_3);
    let v981_5: Space = subtract(&(*CONSTANT_2),&(v981_4));
    drop(v981_4);
    let v981_8: Space = if (v981_5).is_empty() { Space::new() } else {
      let v982_6: Path = concat_path(&(*p0),&(v980_12_head));
      let mut v982_7 = Space::new();
      let mut v982_7_cursor = (v980_12_tail).read_zipper();
      for v982_7_byte in v982_7_cursor.child_mask().iter() {
        v982_7_cursor.descend_to_byte(v982_7_byte);
        let v982_7_tail = v982_7_cursor.make_map();
        v982_7_cursor.ascend(1);
        let v982_7_head = Path::from_slice(&[v982_7_byte]);
        let v983_2: Space = singleton(&(v982_7_head));
        let v983_3: Space = intersect(&(*CONSTANT_3),&(v983_2));
        let v983_4: Space = if has_head(&(v983_3)) { singleton(&[]) } else { Space::new() };
        drop(v983_3);
        let v983_5: Space = subtract(&(*CONSTANT_2),&(v983_4));
        drop(v983_4);
        let v983_8: Space = if (v983_5).is_empty() { Space::new() } else {
          let v984_6: Path = concat_path(&(v982_6),&(v982_7_head));
          let v984_7: Space = routine_144(c, &(v984_6), &(*p1), &(v982_7_tail));
          compose(&(v983_5),&(v984_7))
        };
        drop(v983_5);
        let v983_9: Space = intersect(&(*CONSTANT_3),&(v983_2));
        drop(v983_2);
        let v983_10: Space = if has_head(&(v983_9)) { singleton(&[]) } else { Space::new() };
        drop(v983_9);
        let v983_12: Space = if (v983_10).is_empty() { Space::new() } else {
          let v985_6: Path = concat_path(&(v982_6),&(v982_7_head));
          let v985_11: Space = routine_145(c, &(v985_6), &(*p1), &(v982_7_tail));
          drop(v985_6);
          compose(&(v983_10),&(v985_11))
        };
        drop(v983_10);
        let v983_13: Space = unite(&(v983_8),&(v983_12));
        v982_7.join_into((v983_13).clone());
      }
      drop(v982_7_cursor);
      compose(&(v981_5),&(v982_7))
    };
    drop(v981_5);
    let v981_9: Space = intersect(&(*CONSTANT_3),&(v981_2));
    drop(v981_2);
    let v981_10: Space = if has_head(&(v981_9)) { singleton(&[]) } else { Space::new() };
    drop(v981_9);
    let v981_12: Space = if (v981_10).is_empty() { Space::new() } else {
      let v986_6: Path = concat_path(&(*p0),&(v980_12_head));
      let mut v986_11 = Space::new();
      let mut v986_11_cursor = (v980_12_tail).read_zipper();
      for v986_11_byte in v986_11_cursor.child_mask().iter() {
        v986_11_cursor.descend_to_byte(v986_11_byte);
        let v986_11_tail = v986_11_cursor.make_map();
        v986_11_cursor.ascend(1);
        let v986_11_head = Path::from_slice(&[v986_11_byte]);
        let v987_2: Space = singleton(&(v986_11_head));
        let v987_3: Space = intersect(&(*CONSTANT_3),&(v987_2));
        let v987_4: Space = if has_head(&(v987_3)) { singleton(&[]) } else { Space::new() };
        drop(v987_3);
        let v987_5: Space = subtract(&(*CONSTANT_2),&(v987_4));
        drop(v987_4);
        let v987_8: Space = if (v987_5).is_empty() { Space::new() } else {
          let v988_6: Path = concat_path(&(v986_6),&(v986_11_head));
          let v988_7: Space = routine_144(c, &(v988_6), &(*p1), &(v986_11_tail));
          compose(&(v987_5),&(v988_7))
        };
        drop(v987_5);
        let v987_9: Space = intersect(&(*CONSTANT_3),&(v987_2));
        drop(v987_2);
        let v987_10: Space = if has_head(&(v987_9)) { singleton(&[]) } else { Space::new() };
        drop(v987_9);
        let v987_12: Space = if (v987_10).is_empty() { Space::new() } else {
          let v989_6: Path = concat_path(&(v986_6),&(v986_11_head));
          let v989_11: Space = routine_67(c, &(v989_6), &(*p1), &(v986_11_tail));
          drop(v989_6);
          compose(&(v987_10),&(v989_11))
        };
        drop(v987_10);
        let v987_13: Space = unite(&(v987_8),&(v987_12));
        v986_11.join_into((v987_13).clone());
      }
      drop(v986_11_cursor);
      drop(v986_6);
      compose(&(v981_10),&(v986_11))
    };
    drop(v981_10);
    let v981_13: Space = unite(&(v981_8),&(v981_12));
    v980_12.join_into((v981_13).clone());
  }
  drop(v980_12_cursor);
  (v980_12).clone()
}

fn routine_107(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v990_9 = Space::new();
  let mut v990_9_cursor = (*s0).read_zipper();
  for v990_9_byte in v990_9_cursor.child_mask().iter() {
    v990_9_cursor.descend_to_byte(v990_9_byte);
    let v990_9_tail = v990_9_cursor.make_map();
    v990_9_cursor.ascend(1);
    let v990_9_head = Path::from_slice(&[v990_9_byte]);
    let v991_2: Space = singleton(&(v990_9_head));
    let v991_3: Space = intersect(&(*CONSTANT_3),&(v991_2));
    let v991_4: Space = if has_head(&(v991_3)) { singleton(&[]) } else { Space::new() };
    drop(v991_3);
    let v991_5: Space = subtract(&(*CONSTANT_2),&(v991_4));
    drop(v991_4);
    let v991_8: Space = if (v991_5).is_empty() { Space::new() } else {
      let v992_6: Path = concat_path(&(*p0),&(v990_9_head));
      let mut v992_7 = Space::new();
      let mut v992_7_cursor = (v990_9_tail).read_zipper();
      for v992_7_byte in v992_7_cursor.child_mask().iter() {
        v992_7_cursor.descend_to_byte(v992_7_byte);
        let v992_7_tail = v992_7_cursor.make_map();
        v992_7_cursor.ascend(1);
        let v992_7_head = Path::from_slice(&[v992_7_byte]);
        let v993_2: Space = singleton(&(v992_7_head));
        let v993_3: Space = intersect(&(*CONSTANT_3),&(v993_2));
        let v993_4: Space = if has_head(&(v993_3)) { singleton(&[]) } else { Space::new() };
        drop(v993_3);
        let v993_5: Space = subtract(&(*CONSTANT_2),&(v993_4));
        drop(v993_4);
        let v993_8: Space = if (v993_5).is_empty() { Space::new() } else {
          let v994_6: Path = concat_path(&(v992_6),&(v992_7_head));
          let v994_7: Space = routine_144(c, &(v994_6), &(*p1), &(v992_7_tail));
          compose(&(v993_5),&(v994_7))
        };
        drop(v993_5);
        let v993_9: Space = intersect(&(*CONSTANT_3),&(v993_2));
        drop(v993_2);
        let v993_10: Space = if has_head(&(v993_9)) { singleton(&[]) } else { Space::new() };
        drop(v993_9);
        let v993_12: Space = if (v993_10).is_empty() { Space::new() } else {
          let v995_6: Path = concat_path(&(v992_6),&(v992_7_head));
          let v995_11: Space = routine_145(c, &(v995_6), &(*p1), &(v992_7_tail));
          drop(v995_6);
          compose(&(v993_10),&(v995_11))
        };
        drop(v993_10);
        let v993_13: Space = unite(&(v993_8),&(v993_12));
        v992_7.join_into((v993_13).clone());
      }
      drop(v992_7_cursor);
      compose(&(v991_5),&(v992_7))
    };
    drop(v991_5);
    let v991_9: Space = intersect(&(*CONSTANT_3),&(v991_2));
    drop(v991_2);
    let v991_10: Space = if has_head(&(v991_9)) { singleton(&[]) } else { Space::new() };
    drop(v991_9);
    let v991_11: Space = compose(&(v991_10),&(v990_9_tail));
    drop(v991_10);
    let v996_6: Path = concat_path(&(*p0),&(v990_9_head));
    let v991_12: Space = wrap(&(v991_11),&(v996_6));
    drop(v991_11);
    let v991_13: Space = wrap(&(v991_12),&(*p1));
    drop(v991_12);
    let v991_14: Space = unite(&(v991_8),&(v991_13));
    drop(v991_13);
    v990_9.join_into((v991_14).clone());
  }
  drop(v990_9_cursor);
  (v990_9).clone()
}

fn routine_108(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v997_13 = Space::new();
  let mut v997_13_cursor = (*s0).read_zipper();
  for v997_13_byte in v997_13_cursor.child_mask().iter() {
    v997_13_cursor.descend_to_byte(v997_13_byte);
    let v997_13_tail = v997_13_cursor.make_map();
    v997_13_cursor.ascend(1);
    let v997_13_head = Path::from_slice(&[v997_13_byte]);
    let v998_2: Space = singleton(&(v997_13_head));
    let v998_3: Space = intersect(&(*CONSTANT_3),&(v998_2));
    let v998_4: Space = if has_head(&(v998_3)) { singleton(&[]) } else { Space::new() };
    drop(v998_3);
    let v998_5: Space = subtract(&(*CONSTANT_2),&(v998_4));
    drop(v998_4);
    let v998_8: Space = if (v998_5).is_empty() { Space::new() } else {
      let v999_6: Path = concat_path(&(*p0),&(v997_13_head));
      let mut v999_7 = Space::new();
      let mut v999_7_cursor = (v997_13_tail).read_zipper();
      for v999_7_byte in v999_7_cursor.child_mask().iter() {
        v999_7_cursor.descend_to_byte(v999_7_byte);
        let v999_7_tail = v999_7_cursor.make_map();
        v999_7_cursor.ascend(1);
        let v999_7_head = Path::from_slice(&[v999_7_byte]);
        let v1000_2: Space = singleton(&(v999_7_head));
        let v1000_3: Space = intersect(&(*CONSTANT_3),&(v1000_2));
        let v1000_4: Space = if has_head(&(v1000_3)) { singleton(&[]) } else { Space::new() };
        drop(v1000_3);
        let v1000_5: Space = subtract(&(*CONSTANT_2),&(v1000_4));
        drop(v1000_4);
        let v1000_8: Space = if (v1000_5).is_empty() { Space::new() } else {
          let v1001_6: Path = concat_path(&(v999_6),&(v999_7_head));
          let v1001_7: Space = routine_146(c, &(v1001_6), &(*p1), &(v999_7_tail), &(*s1));
          compose(&(v1000_5),&(v1001_7))
        };
        drop(v1000_5);
        let v1000_9: Space = intersect(&(*CONSTANT_3),&(v1000_2));
        drop(v1000_2);
        let v1000_10: Space = if has_head(&(v1000_9)) { singleton(&[]) } else { Space::new() };
        drop(v1000_9);
        let v1000_12: Space = if (v1000_10).is_empty() { Space::new() } else {
          let v1002_6: Path = concat_path(&(v999_6),&(v999_7_head));
          let v1002_11: Space = routine_147(c, &(v1002_6), &(*p1), &(v999_7_tail), &(*s1));
          drop(v1002_6);
          compose(&(v1000_10),&(v1002_11))
        };
        drop(v1000_10);
        let v1000_13: Space = unite(&(v1000_8),&(v1000_12));
        v999_7.join_into((v1000_13).clone());
      }
      drop(v999_7_cursor);
      compose(&(v998_5),&(v999_7))
    };
    drop(v998_5);
    let v998_9: Space = intersect(&(*CONSTANT_3),&(v998_2));
    drop(v998_2);
    let v998_10: Space = if has_head(&(v998_9)) { singleton(&[]) } else { Space::new() };
    drop(v998_9);
    let v998_12: Space = if (v998_10).is_empty() { Space::new() } else {
      let v1003_6: Path = concat_path(&(*p0),&(v997_13_head));
      let mut v1003_11 = Space::new();
      let mut v1003_11_cursor = (v997_13_tail).read_zipper();
      for v1003_11_byte in v1003_11_cursor.child_mask().iter() {
        v1003_11_cursor.descend_to_byte(v1003_11_byte);
        let v1003_11_tail = v1003_11_cursor.make_map();
        v1003_11_cursor.ascend(1);
        let v1003_11_head = Path::from_slice(&[v1003_11_byte]);
        let v1004_2: Space = singleton(&(v1003_11_head));
        let v1004_3: Space = intersect(&(*CONSTANT_3),&(v1004_2));
        let v1004_4: Space = if has_head(&(v1004_3)) { singleton(&[]) } else { Space::new() };
        drop(v1004_3);
        let v1004_5: Space = subtract(&(*CONSTANT_2),&(v1004_4));
        drop(v1004_4);
        let v1004_8: Space = if (v1004_5).is_empty() { Space::new() } else {
          let v1005_6: Path = concat_path(&(v1003_6),&(v1003_11_head));
          let v1005_7: Space = routine_146(c, &(v1005_6), &(*p1), &(v1003_11_tail), &(*s1));
          compose(&(v1004_5),&(v1005_7))
        };
        drop(v1004_5);
        let v1004_9: Space = intersect(&(*CONSTANT_3),&(v1004_2));
        drop(v1004_2);
        let v1004_10: Space = if has_head(&(v1004_9)) { singleton(&[]) } else { Space::new() };
        drop(v1004_9);
        let v1004_12: Space = if (v1004_10).is_empty() { Space::new() } else {
          let v1006_6: Path = concat_path(&(v1003_6),&(v1003_11_head));
          let v1006_11: Space = routine_29(c, &(v1006_6), &(*p1), &(v1003_11_tail), &(*s1));
          drop(v1006_6);
          compose(&(v1004_10),&(v1006_11))
        };
        drop(v1004_10);
        let v1004_13: Space = unite(&(v1004_8),&(v1004_12));
        v1003_11.join_into((v1004_13).clone());
      }
      drop(v1003_11_cursor);
      drop(v1003_6);
      compose(&(v998_10),&(v1003_11))
    };
    drop(v998_10);
    let v998_13: Space = unite(&(v998_8),&(v998_12));
    v997_13.join_into((v998_13).clone());
  }
  drop(v997_13_cursor);
  (v997_13).clone()
}

fn routine_109(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1007_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v1007_10: Space = unwrap(&(v1007_8),&(*CONSTANT_5));
  drop(v1007_8);
  let v1007_11: Space = unwrap(&(v1007_10),&(*p0));
  drop(v1007_10);
  let mut v1007_18 = Space::new();
  let mut v1007_18_cursor = (*s0).read_zipper();
  for v1007_18_byte in v1007_18_cursor.child_mask().iter() {
    v1007_18_cursor.descend_to_byte(v1007_18_byte);
    let v1007_18_tail = v1007_18_cursor.make_map();
    v1007_18_cursor.ascend(1);
    let v1007_18_head = Path::from_slice(&[v1007_18_byte]);
    let v1008_2: Space = singleton(&(v1007_18_head));
    let v1008_3: Space = intersect(&(*CONSTANT_3),&(v1008_2));
    let v1008_4: Space = if has_head(&(v1008_3)) { singleton(&[]) } else { Space::new() };
    drop(v1008_3);
    let v1008_5: Space = subtract(&(*CONSTANT_2),&(v1008_4));
    drop(v1008_4);
    let v1008_8: Space = if (v1008_5).is_empty() { Space::new() } else {
      let v1009_6: Path = concat_path(&(*p0),&(v1007_18_head));
      let mut v1009_7 = Space::new();
      let mut v1009_7_cursor = (v1007_18_tail).read_zipper();
      for v1009_7_byte in v1009_7_cursor.child_mask().iter() {
        v1009_7_cursor.descend_to_byte(v1009_7_byte);
        let v1009_7_tail = v1009_7_cursor.make_map();
        v1009_7_cursor.ascend(1);
        let v1009_7_head = Path::from_slice(&[v1009_7_byte]);
        let v1010_2: Space = singleton(&(v1009_7_head));
        let v1010_3: Space = intersect(&(*CONSTANT_3),&(v1010_2));
        let v1010_4: Space = if has_head(&(v1010_3)) { singleton(&[]) } else { Space::new() };
        drop(v1010_3);
        let v1010_5: Space = subtract(&(*CONSTANT_2),&(v1010_4));
        drop(v1010_4);
        let v1010_8: Space = if (v1010_5).is_empty() { Space::new() } else {
          let v1011_6: Path = concat_path(&(v1009_6),&(v1009_7_head));
          let v1011_7: Space = routine_146(c, &(v1011_6), &(*p1), &(v1009_7_tail), &(*s1));
          compose(&(v1010_5),&(v1011_7))
        };
        drop(v1010_5);
        let v1010_9: Space = intersect(&(*CONSTANT_3),&(v1010_2));
        drop(v1010_2);
        let v1010_10: Space = if has_head(&(v1010_9)) { singleton(&[]) } else { Space::new() };
        drop(v1010_9);
        let v1010_12: Space = if (v1010_10).is_empty() { Space::new() } else {
          let v1012_6: Path = concat_path(&(v1009_6),&(v1009_7_head));
          let v1012_11: Space = routine_147(c, &(v1012_6), &(*p1), &(v1009_7_tail), &(*s1));
          drop(v1012_6);
          compose(&(v1010_10),&(v1012_11))
        };
        drop(v1010_10);
        let v1010_13: Space = unite(&(v1010_8),&(v1010_12));
        v1009_7.join_into((v1010_13).clone());
      }
      drop(v1009_7_cursor);
      drop(v1009_6);
      compose(&(v1008_5),&(v1009_7))
    };
    drop(v1008_5);
    let v1008_9: Space = intersect(&(*CONSTANT_3),&(v1008_2));
    drop(v1008_2);
    let v1008_10: Space = if has_head(&(v1008_9)) { singleton(&[]) } else { Space::new() };
    drop(v1008_9);
    let v1008_13: Space = if (v1008_10).is_empty() { Space::new() } else {
      let v1013_11: Space = unwrap(&(v1007_11),&(v1007_18_head));
      let mut v1013_12 = Space::new();
      let mut v1013_12_cursor = (v1013_11).read_zipper();
      for v1013_12_byte in v1013_12_cursor.child_mask().iter() {
        v1013_12_cursor.descend_to_byte(v1013_12_byte);
        let v1013_12_tail = v1013_12_cursor.make_map();
        v1013_12_cursor.ascend(1);
        let v1013_12_head = Path::from_slice(&[v1013_12_byte]);
        let v1014_2: Space = singleton(&(v1013_12_head));
        let v1014_3: Space = intersect(&(*CONSTANT_3),&(v1014_2));
        let v1014_4: Space = if has_head(&(v1014_3)) { singleton(&[]) } else { Space::new() };
        drop(v1014_3);
        let v1014_5: Space = subtract(&(*CONSTANT_2),&(v1014_4));
        drop(v1014_4);
        let v1014_7: Space = if (v1014_5).is_empty() { Space::new() } else {
          let v1015_6: Space = routine_61(c, &(v1013_12_head), &(*p1), &(v1013_12_tail));
          compose(&(v1014_5),&(v1015_6))
        };
        drop(v1014_5);
        let v1014_8: Space = intersect(&(*CONSTANT_3),&(v1014_2));
        drop(v1014_2);
        let v1014_9: Space = if has_head(&(v1014_8)) { singleton(&[]) } else { Space::new() };
        drop(v1014_8);
        let v1014_11: Space = if (v1014_9).is_empty() { Space::new() } else {
          let v1016_10: Space = routine_62(c, &(v1013_12_head), &(*p1), &(v1013_12_tail));
          compose(&(v1014_9),&(v1016_10))
        };
        drop(v1014_9);
        let v1014_12: Space = unite(&(v1014_7),&(v1014_11));
        v1013_12.join_into((v1014_12).clone());
      }
      drop(v1013_12_cursor);
      drop(v1013_11);
      compose(&(v1008_10),&(v1013_12))
    };
    drop(v1008_10);
    let v1008_14: Space = unite(&(v1008_8),&(v1008_13));
    v1007_18.join_into((v1008_14).clone());
  }
  drop(v1007_18_cursor);
  drop(v1007_11);
  (v1007_18).clone()
}

fn routine_110(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1017_12 = Space::new();
  let mut v1017_12_cursor = (*s0).read_zipper();
  for v1017_12_byte in v1017_12_cursor.child_mask().iter() {
    v1017_12_cursor.descend_to_byte(v1017_12_byte);
    let v1017_12_tail = v1017_12_cursor.make_map();
    v1017_12_cursor.ascend(1);
    let v1017_12_head = Path::from_slice(&[v1017_12_byte]);
    let v1018_2: Space = singleton(&(v1017_12_head));
    let v1018_3: Space = intersect(&(*CONSTANT_3),&(v1018_2));
    let v1018_4: Space = if has_head(&(v1018_3)) { singleton(&[]) } else { Space::new() };
    drop(v1018_3);
    let v1018_5: Space = subtract(&(*CONSTANT_2),&(v1018_4));
    drop(v1018_4);
    let v1018_8: Space = if (v1018_5).is_empty() { Space::new() } else {
      let v1019_6: Path = concat_path(&(*p0),&(v1017_12_head));
      let mut v1019_7 = Space::new();
      let mut v1019_7_cursor = (v1017_12_tail).read_zipper();
      for v1019_7_byte in v1019_7_cursor.child_mask().iter() {
        v1019_7_cursor.descend_to_byte(v1019_7_byte);
        let v1019_7_tail = v1019_7_cursor.make_map();
        v1019_7_cursor.ascend(1);
        let v1019_7_head = Path::from_slice(&[v1019_7_byte]);
        let v1020_2: Space = singleton(&(v1019_7_head));
        let v1020_3: Space = intersect(&(*CONSTANT_3),&(v1020_2));
        let v1020_4: Space = if has_head(&(v1020_3)) { singleton(&[]) } else { Space::new() };
        drop(v1020_3);
        let v1020_5: Space = subtract(&(*CONSTANT_2),&(v1020_4));
        drop(v1020_4);
        let v1020_8: Space = if (v1020_5).is_empty() { Space::new() } else {
          let v1021_6: Path = concat_path(&(v1019_6),&(v1019_7_head));
          let v1021_7: Space = routine_148(c, &(v1021_6), &(*p1), &(v1019_7_tail));
          compose(&(v1020_5),&(v1021_7))
        };
        drop(v1020_5);
        let v1020_9: Space = intersect(&(*CONSTANT_3),&(v1020_2));
        drop(v1020_2);
        let v1020_10: Space = if has_head(&(v1020_9)) { singleton(&[]) } else { Space::new() };
        drop(v1020_9);
        let v1020_12: Space = if (v1020_10).is_empty() { Space::new() } else {
          let v1022_6: Path = concat_path(&(v1019_6),&(v1019_7_head));
          let v1022_11: Space = routine_149(c, &(v1022_6), &(*p1), &(v1019_7_tail));
          drop(v1022_6);
          compose(&(v1020_10),&(v1022_11))
        };
        drop(v1020_10);
        let v1020_13: Space = unite(&(v1020_8),&(v1020_12));
        v1019_7.join_into((v1020_13).clone());
      }
      drop(v1019_7_cursor);
      compose(&(v1018_5),&(v1019_7))
    };
    drop(v1018_5);
    let v1018_9: Space = intersect(&(*CONSTANT_3),&(v1018_2));
    drop(v1018_2);
    let v1018_10: Space = if has_head(&(v1018_9)) { singleton(&[]) } else { Space::new() };
    drop(v1018_9);
    let v1018_12: Space = if (v1018_10).is_empty() { Space::new() } else {
      let v1023_6: Path = concat_path(&(*p0),&(v1017_12_head));
      let mut v1023_11 = Space::new();
      let mut v1023_11_cursor = (v1017_12_tail).read_zipper();
      for v1023_11_byte in v1023_11_cursor.child_mask().iter() {
        v1023_11_cursor.descend_to_byte(v1023_11_byte);
        let v1023_11_tail = v1023_11_cursor.make_map();
        v1023_11_cursor.ascend(1);
        let v1023_11_head = Path::from_slice(&[v1023_11_byte]);
        let v1024_2: Space = singleton(&(v1023_11_head));
        let v1024_3: Space = intersect(&(*CONSTANT_3),&(v1024_2));
        let v1024_4: Space = if has_head(&(v1024_3)) { singleton(&[]) } else { Space::new() };
        drop(v1024_3);
        let v1024_5: Space = subtract(&(*CONSTANT_2),&(v1024_4));
        drop(v1024_4);
        let v1024_8: Space = if (v1024_5).is_empty() { Space::new() } else {
          let v1025_6: Path = concat_path(&(v1023_6),&(v1023_11_head));
          let v1025_7: Space = routine_148(c, &(v1025_6), &(*p1), &(v1023_11_tail));
          compose(&(v1024_5),&(v1025_7))
        };
        drop(v1024_5);
        let v1024_9: Space = intersect(&(*CONSTANT_3),&(v1024_2));
        drop(v1024_2);
        let v1024_10: Space = if has_head(&(v1024_9)) { singleton(&[]) } else { Space::new() };
        drop(v1024_9);
        let v1024_12: Space = if (v1024_10).is_empty() { Space::new() } else {
          let v1026_6: Path = concat_path(&(v1023_6),&(v1023_11_head));
          let v1026_11: Space = routine_67(c, &(v1026_6), &(*p1), &(v1023_11_tail));
          drop(v1026_6);
          compose(&(v1024_10),&(v1026_11))
        };
        drop(v1024_10);
        let v1024_13: Space = unite(&(v1024_8),&(v1024_12));
        v1023_11.join_into((v1024_13).clone());
      }
      drop(v1023_11_cursor);
      drop(v1023_6);
      compose(&(v1018_10),&(v1023_11))
    };
    drop(v1018_10);
    let v1018_13: Space = unite(&(v1018_8),&(v1018_12));
    v1017_12.join_into((v1018_13).clone());
  }
  drop(v1017_12_cursor);
  (v1017_12).clone()
}

fn routine_111(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1027_9 = Space::new();
  let mut v1027_9_cursor = (*s0).read_zipper();
  for v1027_9_byte in v1027_9_cursor.child_mask().iter() {
    v1027_9_cursor.descend_to_byte(v1027_9_byte);
    let v1027_9_tail = v1027_9_cursor.make_map();
    v1027_9_cursor.ascend(1);
    let v1027_9_head = Path::from_slice(&[v1027_9_byte]);
    let v1028_2: Space = singleton(&(v1027_9_head));
    let v1028_3: Space = intersect(&(*CONSTANT_3),&(v1028_2));
    let v1028_4: Space = if has_head(&(v1028_3)) { singleton(&[]) } else { Space::new() };
    drop(v1028_3);
    let v1028_5: Space = subtract(&(*CONSTANT_2),&(v1028_4));
    drop(v1028_4);
    let v1028_8: Space = if (v1028_5).is_empty() { Space::new() } else {
      let v1029_6: Path = concat_path(&(*p0),&(v1027_9_head));
      let mut v1029_7 = Space::new();
      let mut v1029_7_cursor = (v1027_9_tail).read_zipper();
      for v1029_7_byte in v1029_7_cursor.child_mask().iter() {
        v1029_7_cursor.descend_to_byte(v1029_7_byte);
        let v1029_7_tail = v1029_7_cursor.make_map();
        v1029_7_cursor.ascend(1);
        let v1029_7_head = Path::from_slice(&[v1029_7_byte]);
        let v1030_2: Space = singleton(&(v1029_7_head));
        let v1030_3: Space = intersect(&(*CONSTANT_3),&(v1030_2));
        let v1030_4: Space = if has_head(&(v1030_3)) { singleton(&[]) } else { Space::new() };
        drop(v1030_3);
        let v1030_5: Space = subtract(&(*CONSTANT_2),&(v1030_4));
        drop(v1030_4);
        let v1030_8: Space = if (v1030_5).is_empty() { Space::new() } else {
          let v1031_6: Path = concat_path(&(v1029_6),&(v1029_7_head));
          let v1031_7: Space = routine_148(c, &(v1031_6), &(*p1), &(v1029_7_tail));
          compose(&(v1030_5),&(v1031_7))
        };
        drop(v1030_5);
        let v1030_9: Space = intersect(&(*CONSTANT_3),&(v1030_2));
        drop(v1030_2);
        let v1030_10: Space = if has_head(&(v1030_9)) { singleton(&[]) } else { Space::new() };
        drop(v1030_9);
        let v1030_12: Space = if (v1030_10).is_empty() { Space::new() } else {
          let v1032_6: Path = concat_path(&(v1029_6),&(v1029_7_head));
          let v1032_11: Space = routine_149(c, &(v1032_6), &(*p1), &(v1029_7_tail));
          drop(v1032_6);
          compose(&(v1030_10),&(v1032_11))
        };
        drop(v1030_10);
        let v1030_13: Space = unite(&(v1030_8),&(v1030_12));
        v1029_7.join_into((v1030_13).clone());
      }
      drop(v1029_7_cursor);
      compose(&(v1028_5),&(v1029_7))
    };
    drop(v1028_5);
    let v1028_9: Space = intersect(&(*CONSTANT_3),&(v1028_2));
    drop(v1028_2);
    let v1028_10: Space = if has_head(&(v1028_9)) { singleton(&[]) } else { Space::new() };
    drop(v1028_9);
    let v1028_11: Space = compose(&(v1028_10),&(v1027_9_tail));
    drop(v1028_10);
    let v1033_6: Path = concat_path(&(*p0),&(v1027_9_head));
    let v1028_12: Space = wrap(&(v1028_11),&(v1033_6));
    drop(v1028_11);
    let v1028_13: Space = wrap(&(v1028_12),&(*p1));
    drop(v1028_12);
    let v1028_14: Space = unite(&(v1028_8),&(v1028_13));
    drop(v1028_13);
    v1027_9.join_into((v1028_14).clone());
  }
  drop(v1027_9_cursor);
  (v1027_9).clone()
}

fn routine_112(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v1034_2 = Space::new();
  let mut v1034_2_cursor = (*s0).read_zipper();
  for v1034_2_byte in v1034_2_cursor.child_mask().iter() {
    v1034_2_cursor.descend_to_byte(v1034_2_byte);
    let v1034_2_tail = v1034_2_cursor.make_map();
    v1034_2_cursor.ascend(1);
    let v1034_2_head = Path::from_slice(&[v1034_2_byte]);
    let v1035_2: Space = Space::new();
    v1034_2.join_into((v1035_2).clone());
  }
  drop(v1034_2_cursor);
  (v1034_2).clone()
}

fn routine_113(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v1036_6 = Space::new();
  let mut v1036_6_cursor = (*s0).read_zipper();
  for v1036_6_byte in v1036_6_cursor.child_mask().iter() {
    v1036_6_cursor.descend_to_byte(v1036_6_byte);
    let v1036_6_tail = v1036_6_cursor.make_map();
    v1036_6_cursor.ascend(1);
    let v1036_6_head = Path::from_slice(&[v1036_6_byte]);
    let v1037_2: Space = singleton(&(v1036_6_head));
    let v1037_3: Space = intersect(&(*CONSTANT_3),&(v1037_2));
    drop(v1037_2);
    let v1037_4: Space = if has_head(&(v1037_3)) { singleton(&[]) } else { Space::new() };
    drop(v1037_3);
    let v1037_7: Space = if (v1037_4).is_empty() { Space::new() } else {
      let v1038_5: Path = concat_path(&(*p0),&(v1036_6_head));
      let mut v1038_6 = Space::new();
      let mut v1038_6_cursor = (v1036_6_tail).read_zipper();
      for v1038_6_byte in v1038_6_cursor.child_mask().iter() {
        v1038_6_cursor.descend_to_byte(v1038_6_byte);
        let v1038_6_tail = v1038_6_cursor.make_map();
        v1038_6_cursor.ascend(1);
        let v1038_6_head = Path::from_slice(&[v1038_6_byte]);
        let v1039_2: Space = singleton(&(v1038_6_head));
        let v1039_3: Space = intersect(&(*CONSTANT_3),&(v1039_2));
        let v1039_4: Space = if has_head(&(v1039_3)) { singleton(&[]) } else { Space::new() };
        drop(v1039_3);
        let v1039_5: Space = subtract(&(*CONSTANT_2),&(v1039_4));
        drop(v1039_4);
        let v1039_7: Space = if (v1039_5).is_empty() { Space::new() } else {
          let v1040_6: Space = routine_32(c, &(v1038_6_head), &(v1038_5), &(v1038_6_tail));
          compose(&(v1039_5),&(v1040_6))
        };
        drop(v1039_5);
        let v1039_8: Space = intersect(&(*CONSTANT_3),&(v1039_2));
        drop(v1039_2);
        let v1039_9: Space = if has_head(&(v1039_8)) { singleton(&[]) } else { Space::new() };
        drop(v1039_8);
        let v1039_11: Space = if (v1039_9).is_empty() { Space::new() } else {
          let v1041_10: Space = routine_33(c, &(v1038_6_head), &(v1038_5), &(v1038_6_tail));
          compose(&(v1039_9),&(v1041_10))
        };
        drop(v1039_9);
        let v1039_12: Space = unite(&(v1039_7),&(v1039_11));
        v1038_6.join_into((v1039_12).clone());
      }
      drop(v1038_6_cursor);
      drop(v1038_5);
      compose(&(v1037_4),&(v1038_6))
    };
    drop(v1037_4);
    v1036_6.join_into((v1037_7).clone());
  }
  drop(v1036_6_cursor);
  (v1036_6).clone()
}

fn routine_114(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1042_12 = Space::new();
  let mut v1042_12_cursor = (*s0).read_zipper();
  for v1042_12_byte in v1042_12_cursor.child_mask().iter() {
    v1042_12_cursor.descend_to_byte(v1042_12_byte);
    let v1042_12_tail = v1042_12_cursor.make_map();
    v1042_12_cursor.ascend(1);
    let v1042_12_head = Path::from_slice(&[v1042_12_byte]);
    let v1043_2: Space = singleton(&(v1042_12_head));
    let v1043_3: Space = intersect(&(*CONSTANT_3),&(v1043_2));
    let v1043_4: Space = if has_head(&(v1043_3)) { singleton(&[]) } else { Space::new() };
    drop(v1043_3);
    let v1043_5: Space = subtract(&(*CONSTANT_2),&(v1043_4));
    drop(v1043_4);
    let v1043_8: Space = if (v1043_5).is_empty() { Space::new() } else {
      let v1044_6: Path = concat_path(&(*p0),&(v1042_12_head));
      let mut v1044_7 = Space::new();
      let mut v1044_7_cursor = (v1042_12_tail).read_zipper();
      for v1044_7_byte in v1044_7_cursor.child_mask().iter() {
        v1044_7_cursor.descend_to_byte(v1044_7_byte);
        let v1044_7_tail = v1044_7_cursor.make_map();
        v1044_7_cursor.ascend(1);
        let v1044_7_head = Path::from_slice(&[v1044_7_byte]);
        let v1045_2: Space = singleton(&(v1044_7_head));
        let v1045_3: Space = intersect(&(*CONSTANT_3),&(v1045_2));
        let v1045_4: Space = if has_head(&(v1045_3)) { singleton(&[]) } else { Space::new() };
        drop(v1045_3);
        let v1045_5: Space = subtract(&(*CONSTANT_2),&(v1045_4));
        drop(v1045_4);
        let v1045_8: Space = if (v1045_5).is_empty() { Space::new() } else {
          let v1046_6: Path = concat_path(&(v1044_6),&(v1044_7_head));
          let v1046_7: Space = routine_150(c, &(v1046_6), &(*p1), &(v1044_7_tail));
          compose(&(v1045_5),&(v1046_7))
        };
        drop(v1045_5);
        let v1045_9: Space = intersect(&(*CONSTANT_3),&(v1045_2));
        drop(v1045_2);
        let v1045_10: Space = if has_head(&(v1045_9)) { singleton(&[]) } else { Space::new() };
        drop(v1045_9);
        let v1045_12: Space = if (v1045_10).is_empty() { Space::new() } else {
          let v1047_6: Path = concat_path(&(v1044_6),&(v1044_7_head));
          let v1047_11: Space = routine_151(c, &(v1047_6), &(*p1), &(v1044_7_tail));
          drop(v1047_6);
          compose(&(v1045_10),&(v1047_11))
        };
        drop(v1045_10);
        let v1045_13: Space = unite(&(v1045_8),&(v1045_12));
        v1044_7.join_into((v1045_13).clone());
      }
      drop(v1044_7_cursor);
      compose(&(v1043_5),&(v1044_7))
    };
    drop(v1043_5);
    let v1043_9: Space = intersect(&(*CONSTANT_3),&(v1043_2));
    drop(v1043_2);
    let v1043_10: Space = if has_head(&(v1043_9)) { singleton(&[]) } else { Space::new() };
    drop(v1043_9);
    let v1043_12: Space = if (v1043_10).is_empty() { Space::new() } else {
      let v1048_6: Path = concat_path(&(*p0),&(v1042_12_head));
      let mut v1048_11 = Space::new();
      let mut v1048_11_cursor = (v1042_12_tail).read_zipper();
      for v1048_11_byte in v1048_11_cursor.child_mask().iter() {
        v1048_11_cursor.descend_to_byte(v1048_11_byte);
        let v1048_11_tail = v1048_11_cursor.make_map();
        v1048_11_cursor.ascend(1);
        let v1048_11_head = Path::from_slice(&[v1048_11_byte]);
        let v1049_2: Space = singleton(&(v1048_11_head));
        let v1049_3: Space = intersect(&(*CONSTANT_3),&(v1049_2));
        let v1049_4: Space = if has_head(&(v1049_3)) { singleton(&[]) } else { Space::new() };
        drop(v1049_3);
        let v1049_5: Space = subtract(&(*CONSTANT_2),&(v1049_4));
        drop(v1049_4);
        let v1049_8: Space = if (v1049_5).is_empty() { Space::new() } else {
          let v1050_6: Path = concat_path(&(v1048_6),&(v1048_11_head));
          let v1050_7: Space = routine_150(c, &(v1050_6), &(*p1), &(v1048_11_tail));
          compose(&(v1049_5),&(v1050_7))
        };
        drop(v1049_5);
        let v1049_9: Space = intersect(&(*CONSTANT_3),&(v1049_2));
        drop(v1049_2);
        let v1049_10: Space = if has_head(&(v1049_9)) { singleton(&[]) } else { Space::new() };
        drop(v1049_9);
        let v1049_12: Space = if (v1049_10).is_empty() { Space::new() } else {
          let v1051_6: Path = concat_path(&(v1048_6),&(v1048_11_head));
          let v1051_11: Space = routine_36(c, &(v1051_6), &(*p1), &(v1048_11_tail));
          drop(v1051_6);
          compose(&(v1049_10),&(v1051_11))
        };
        drop(v1049_10);
        let v1049_13: Space = unite(&(v1049_8),&(v1049_12));
        v1048_11.join_into((v1049_13).clone());
      }
      drop(v1048_11_cursor);
      drop(v1048_6);
      compose(&(v1043_10),&(v1048_11))
    };
    drop(v1043_10);
    let v1043_13: Space = unite(&(v1043_8),&(v1043_12));
    v1042_12.join_into((v1043_13).clone());
  }
  drop(v1042_12_cursor);
  (v1042_12).clone()
}

fn routine_115(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1052_9 = Space::new();
  let mut v1052_9_cursor = (*s0).read_zipper();
  for v1052_9_byte in v1052_9_cursor.child_mask().iter() {
    v1052_9_cursor.descend_to_byte(v1052_9_byte);
    let v1052_9_tail = v1052_9_cursor.make_map();
    v1052_9_cursor.ascend(1);
    let v1052_9_head = Path::from_slice(&[v1052_9_byte]);
    let v1053_2: Space = singleton(&(v1052_9_head));
    let v1053_3: Space = intersect(&(*CONSTANT_3),&(v1053_2));
    let v1053_4: Space = if has_head(&(v1053_3)) { singleton(&[]) } else { Space::new() };
    drop(v1053_3);
    let v1053_5: Space = subtract(&(*CONSTANT_2),&(v1053_4));
    drop(v1053_4);
    let v1053_8: Space = if (v1053_5).is_empty() { Space::new() } else {
      let v1054_6: Path = concat_path(&(*p0),&(v1052_9_head));
      let mut v1054_7 = Space::new();
      let mut v1054_7_cursor = (v1052_9_tail).read_zipper();
      for v1054_7_byte in v1054_7_cursor.child_mask().iter() {
        v1054_7_cursor.descend_to_byte(v1054_7_byte);
        let v1054_7_tail = v1054_7_cursor.make_map();
        v1054_7_cursor.ascend(1);
        let v1054_7_head = Path::from_slice(&[v1054_7_byte]);
        let v1055_2: Space = singleton(&(v1054_7_head));
        let v1055_3: Space = intersect(&(*CONSTANT_3),&(v1055_2));
        let v1055_4: Space = if has_head(&(v1055_3)) { singleton(&[]) } else { Space::new() };
        drop(v1055_3);
        let v1055_5: Space = subtract(&(*CONSTANT_2),&(v1055_4));
        drop(v1055_4);
        let v1055_8: Space = if (v1055_5).is_empty() { Space::new() } else {
          let v1056_6: Path = concat_path(&(v1054_6),&(v1054_7_head));
          let v1056_7: Space = routine_150(c, &(v1056_6), &(*p1), &(v1054_7_tail));
          compose(&(v1055_5),&(v1056_7))
        };
        drop(v1055_5);
        let v1055_9: Space = intersect(&(*CONSTANT_3),&(v1055_2));
        drop(v1055_2);
        let v1055_10: Space = if has_head(&(v1055_9)) { singleton(&[]) } else { Space::new() };
        drop(v1055_9);
        let v1055_12: Space = if (v1055_10).is_empty() { Space::new() } else {
          let v1057_6: Path = concat_path(&(v1054_6),&(v1054_7_head));
          let v1057_11: Space = routine_151(c, &(v1057_6), &(*p1), &(v1054_7_tail));
          drop(v1057_6);
          compose(&(v1055_10),&(v1057_11))
        };
        drop(v1055_10);
        let v1055_13: Space = unite(&(v1055_8),&(v1055_12));
        v1054_7.join_into((v1055_13).clone());
      }
      drop(v1054_7_cursor);
      compose(&(v1053_5),&(v1054_7))
    };
    drop(v1053_5);
    let v1053_9: Space = intersect(&(*CONSTANT_3),&(v1053_2));
    drop(v1053_2);
    let v1053_10: Space = if has_head(&(v1053_9)) { singleton(&[]) } else { Space::new() };
    drop(v1053_9);
    let v1053_11: Space = compose(&(v1053_10),&(v1052_9_tail));
    drop(v1053_10);
    let v1058_6: Path = concat_path(&(*p0),&(v1052_9_head));
    let v1053_12: Space = wrap(&(v1053_11),&(v1058_6));
    drop(v1053_11);
    let v1053_13: Space = wrap(&(v1053_12),&(*p1));
    drop(v1053_12);
    let v1053_14: Space = unite(&(v1053_8),&(v1053_13));
    drop(v1053_13);
    v1052_9.join_into((v1053_14).clone());
  }
  drop(v1052_9_cursor);
  (v1052_9).clone()
}

fn routine_116(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1059_12 = Space::new();
  let mut v1059_12_cursor = (*s0).read_zipper();
  for v1059_12_byte in v1059_12_cursor.child_mask().iter() {
    v1059_12_cursor.descend_to_byte(v1059_12_byte);
    let v1059_12_tail = v1059_12_cursor.make_map();
    v1059_12_cursor.ascend(1);
    let v1059_12_head = Path::from_slice(&[v1059_12_byte]);
    let v1060_2: Space = singleton(&(v1059_12_head));
    let v1060_3: Space = intersect(&(*CONSTANT_3),&(v1060_2));
    let v1060_4: Space = if has_head(&(v1060_3)) { singleton(&[]) } else { Space::new() };
    drop(v1060_3);
    let v1060_5: Space = subtract(&(*CONSTANT_2),&(v1060_4));
    drop(v1060_4);
    let v1060_8: Space = if (v1060_5).is_empty() { Space::new() } else {
      let v1061_6: Path = concat_path(&(*p0),&(v1059_12_head));
      let mut v1061_7 = Space::new();
      let mut v1061_7_cursor = (v1059_12_tail).read_zipper();
      for v1061_7_byte in v1061_7_cursor.child_mask().iter() {
        v1061_7_cursor.descend_to_byte(v1061_7_byte);
        let v1061_7_tail = v1061_7_cursor.make_map();
        v1061_7_cursor.ascend(1);
        let v1061_7_head = Path::from_slice(&[v1061_7_byte]);
        let v1062_2: Space = singleton(&(v1061_7_head));
        let v1062_3: Space = intersect(&(*CONSTANT_3),&(v1062_2));
        let v1062_4: Space = if has_head(&(v1062_3)) { singleton(&[]) } else { Space::new() };
        drop(v1062_3);
        let v1062_5: Space = subtract(&(*CONSTANT_2),&(v1062_4));
        drop(v1062_4);
        let v1062_8: Space = if (v1062_5).is_empty() { Space::new() } else {
          let v1063_6: Path = concat_path(&(v1061_6),&(v1061_7_head));
          let v1063_7: Space = routine_152(c, &(v1063_6), &(*p1), &(v1061_7_tail));
          compose(&(v1062_5),&(v1063_7))
        };
        drop(v1062_5);
        let v1062_9: Space = intersect(&(*CONSTANT_3),&(v1062_2));
        drop(v1062_2);
        let v1062_10: Space = if has_head(&(v1062_9)) { singleton(&[]) } else { Space::new() };
        drop(v1062_9);
        let v1062_12: Space = if (v1062_10).is_empty() { Space::new() } else {
          let v1064_6: Path = concat_path(&(v1061_6),&(v1061_7_head));
          let v1064_11: Space = routine_153(c, &(v1064_6), &(*p1), &(v1061_7_tail));
          drop(v1064_6);
          compose(&(v1062_10),&(v1064_11))
        };
        drop(v1062_10);
        let v1062_13: Space = unite(&(v1062_8),&(v1062_12));
        v1061_7.join_into((v1062_13).clone());
      }
      drop(v1061_7_cursor);
      compose(&(v1060_5),&(v1061_7))
    };
    drop(v1060_5);
    let v1060_9: Space = intersect(&(*CONSTANT_3),&(v1060_2));
    drop(v1060_2);
    let v1060_10: Space = if has_head(&(v1060_9)) { singleton(&[]) } else { Space::new() };
    drop(v1060_9);
    let v1060_12: Space = if (v1060_10).is_empty() { Space::new() } else {
      let v1065_6: Path = concat_path(&(*p0),&(v1059_12_head));
      let mut v1065_11 = Space::new();
      let mut v1065_11_cursor = (v1059_12_tail).read_zipper();
      for v1065_11_byte in v1065_11_cursor.child_mask().iter() {
        v1065_11_cursor.descend_to_byte(v1065_11_byte);
        let v1065_11_tail = v1065_11_cursor.make_map();
        v1065_11_cursor.ascend(1);
        let v1065_11_head = Path::from_slice(&[v1065_11_byte]);
        let v1066_2: Space = singleton(&(v1065_11_head));
        let v1066_3: Space = intersect(&(*CONSTANT_3),&(v1066_2));
        let v1066_4: Space = if has_head(&(v1066_3)) { singleton(&[]) } else { Space::new() };
        drop(v1066_3);
        let v1066_5: Space = subtract(&(*CONSTANT_2),&(v1066_4));
        drop(v1066_4);
        let v1066_8: Space = if (v1066_5).is_empty() { Space::new() } else {
          let v1067_6: Path = concat_path(&(v1065_6),&(v1065_11_head));
          let v1067_7: Space = routine_152(c, &(v1067_6), &(*p1), &(v1065_11_tail));
          compose(&(v1066_5),&(v1067_7))
        };
        drop(v1066_5);
        let v1066_9: Space = intersect(&(*CONSTANT_3),&(v1066_2));
        drop(v1066_2);
        let v1066_10: Space = if has_head(&(v1066_9)) { singleton(&[]) } else { Space::new() };
        drop(v1066_9);
        let v1066_12: Space = if (v1066_10).is_empty() { Space::new() } else {
          let v1068_6: Path = concat_path(&(v1065_6),&(v1065_11_head));
          let v1068_11: Space = routine_36(c, &(v1068_6), &(*p1), &(v1065_11_tail));
          drop(v1068_6);
          compose(&(v1066_10),&(v1068_11))
        };
        drop(v1066_10);
        let v1066_13: Space = unite(&(v1066_8),&(v1066_12));
        v1065_11.join_into((v1066_13).clone());
      }
      drop(v1065_11_cursor);
      drop(v1065_6);
      compose(&(v1060_10),&(v1065_11))
    };
    drop(v1060_10);
    let v1060_13: Space = unite(&(v1060_8),&(v1060_12));
    v1059_12.join_into((v1060_13).clone());
  }
  drop(v1059_12_cursor);
  (v1059_12).clone()
}

fn routine_117(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1069_9 = Space::new();
  let mut v1069_9_cursor = (*s0).read_zipper();
  for v1069_9_byte in v1069_9_cursor.child_mask().iter() {
    v1069_9_cursor.descend_to_byte(v1069_9_byte);
    let v1069_9_tail = v1069_9_cursor.make_map();
    v1069_9_cursor.ascend(1);
    let v1069_9_head = Path::from_slice(&[v1069_9_byte]);
    let v1070_2: Space = singleton(&(v1069_9_head));
    let v1070_3: Space = intersect(&(*CONSTANT_3),&(v1070_2));
    let v1070_4: Space = if has_head(&(v1070_3)) { singleton(&[]) } else { Space::new() };
    drop(v1070_3);
    let v1070_5: Space = subtract(&(*CONSTANT_2),&(v1070_4));
    drop(v1070_4);
    let v1070_8: Space = if (v1070_5).is_empty() { Space::new() } else {
      let v1071_6: Path = concat_path(&(*p0),&(v1069_9_head));
      let mut v1071_7 = Space::new();
      let mut v1071_7_cursor = (v1069_9_tail).read_zipper();
      for v1071_7_byte in v1071_7_cursor.child_mask().iter() {
        v1071_7_cursor.descend_to_byte(v1071_7_byte);
        let v1071_7_tail = v1071_7_cursor.make_map();
        v1071_7_cursor.ascend(1);
        let v1071_7_head = Path::from_slice(&[v1071_7_byte]);
        let v1072_2: Space = singleton(&(v1071_7_head));
        let v1072_3: Space = intersect(&(*CONSTANT_3),&(v1072_2));
        let v1072_4: Space = if has_head(&(v1072_3)) { singleton(&[]) } else { Space::new() };
        drop(v1072_3);
        let v1072_5: Space = subtract(&(*CONSTANT_2),&(v1072_4));
        drop(v1072_4);
        let v1072_8: Space = if (v1072_5).is_empty() { Space::new() } else {
          let v1073_6: Path = concat_path(&(v1071_6),&(v1071_7_head));
          let v1073_7: Space = routine_152(c, &(v1073_6), &(*p1), &(v1071_7_tail));
          compose(&(v1072_5),&(v1073_7))
        };
        drop(v1072_5);
        let v1072_9: Space = intersect(&(*CONSTANT_3),&(v1072_2));
        drop(v1072_2);
        let v1072_10: Space = if has_head(&(v1072_9)) { singleton(&[]) } else { Space::new() };
        drop(v1072_9);
        let v1072_12: Space = if (v1072_10).is_empty() { Space::new() } else {
          let v1074_6: Path = concat_path(&(v1071_6),&(v1071_7_head));
          let v1074_11: Space = routine_153(c, &(v1074_6), &(*p1), &(v1071_7_tail));
          drop(v1074_6);
          compose(&(v1072_10),&(v1074_11))
        };
        drop(v1072_10);
        let v1072_13: Space = unite(&(v1072_8),&(v1072_12));
        v1071_7.join_into((v1072_13).clone());
      }
      drop(v1071_7_cursor);
      compose(&(v1070_5),&(v1071_7))
    };
    drop(v1070_5);
    let v1070_9: Space = intersect(&(*CONSTANT_3),&(v1070_2));
    drop(v1070_2);
    let v1070_10: Space = if has_head(&(v1070_9)) { singleton(&[]) } else { Space::new() };
    drop(v1070_9);
    let v1070_11: Space = compose(&(v1070_10),&(v1069_9_tail));
    drop(v1070_10);
    let v1075_6: Path = concat_path(&(*p0),&(v1069_9_head));
    let v1070_12: Space = wrap(&(v1070_11),&(v1075_6));
    drop(v1070_11);
    let v1070_13: Space = wrap(&(v1070_12),&(*p1));
    drop(v1070_12);
    let v1070_14: Space = unite(&(v1070_8),&(v1070_13));
    drop(v1070_13);
    v1069_9.join_into((v1070_14).clone());
  }
  drop(v1069_9_cursor);
  (v1069_9).clone()
}

fn routine_118(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1076_3 = Space::new();
  let mut v1076_3_cursor = (*s0).read_zipper();
  for v1076_3_byte in v1076_3_cursor.child_mask().iter() {
    v1076_3_cursor.descend_to_byte(v1076_3_byte);
    let v1076_3_tail = v1076_3_cursor.make_map();
    v1076_3_cursor.ascend(1);
    let v1076_3_head = Path::from_slice(&[v1076_3_byte]);
    let v1077_2: Space = Space::new();
    v1076_3.join_into((v1077_2).clone());
  }
  drop(v1076_3_cursor);
  (v1076_3).clone()
}

fn routine_119(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1078_7 = Space::new();
  let mut v1078_7_cursor = (*s0).read_zipper();
  for v1078_7_byte in v1078_7_cursor.child_mask().iter() {
    v1078_7_cursor.descend_to_byte(v1078_7_byte);
    let v1078_7_tail = v1078_7_cursor.make_map();
    v1078_7_cursor.ascend(1);
    let v1078_7_head = Path::from_slice(&[v1078_7_byte]);
    let v1079_2: Space = singleton(&(v1078_7_head));
    let v1079_3: Space = intersect(&(*CONSTANT_3),&(v1079_2));
    drop(v1079_2);
    let v1079_4: Space = if has_head(&(v1079_3)) { singleton(&[]) } else { Space::new() };
    drop(v1079_3);
    let v1079_7: Space = if (v1079_4).is_empty() { Space::new() } else {
      let v1080_5: Path = concat_path(&(*p0),&(v1078_7_head));
      let mut v1080_6 = Space::new();
      let mut v1080_6_cursor = (v1078_7_tail).read_zipper();
      for v1080_6_byte in v1080_6_cursor.child_mask().iter() {
        v1080_6_cursor.descend_to_byte(v1080_6_byte);
        let v1080_6_tail = v1080_6_cursor.make_map();
        v1080_6_cursor.ascend(1);
        let v1080_6_head = Path::from_slice(&[v1080_6_byte]);
        let v1081_2: Space = singleton(&(v1080_6_head));
        let v1081_3: Space = intersect(&(*CONSTANT_3),&(v1081_2));
        let v1081_4: Space = if has_head(&(v1081_3)) { singleton(&[]) } else { Space::new() };
        drop(v1081_3);
        let v1081_5: Space = subtract(&(*CONSTANT_2),&(v1081_4));
        drop(v1081_4);
        let v1081_7: Space = if (v1081_5).is_empty() { Space::new() } else {
          let v1082_6: Space = routine_39(c, &(v1080_6_head), &(v1080_5), &(v1080_6_tail), &(*s1));
          compose(&(v1081_5),&(v1082_6))
        };
        drop(v1081_5);
        let v1081_8: Space = intersect(&(*CONSTANT_3),&(v1081_2));
        drop(v1081_2);
        let v1081_9: Space = if has_head(&(v1081_8)) { singleton(&[]) } else { Space::new() };
        drop(v1081_8);
        let v1081_11: Space = if (v1081_9).is_empty() { Space::new() } else {
          let v1083_10: Space = routine_40(c, &(v1080_6_head), &(v1080_5), &(v1080_6_tail), &(*s1));
          compose(&(v1081_9),&(v1083_10))
        };
        drop(v1081_9);
        let v1081_12: Space = unite(&(v1081_7),&(v1081_11));
        v1080_6.join_into((v1081_12).clone());
      }
      drop(v1080_6_cursor);
      drop(v1080_5);
      compose(&(v1079_4),&(v1080_6))
    };
    drop(v1079_4);
    v1078_7.join_into((v1079_7).clone());
  }
  drop(v1078_7_cursor);
  (v1078_7).clone()
}

fn routine_120(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1084_13 = Space::new();
  let mut v1084_13_cursor = (*s0).read_zipper();
  for v1084_13_byte in v1084_13_cursor.child_mask().iter() {
    v1084_13_cursor.descend_to_byte(v1084_13_byte);
    let v1084_13_tail = v1084_13_cursor.make_map();
    v1084_13_cursor.ascend(1);
    let v1084_13_head = Path::from_slice(&[v1084_13_byte]);
    let v1085_2: Space = singleton(&(v1084_13_head));
    let v1085_3: Space = intersect(&(*CONSTANT_3),&(v1085_2));
    let v1085_4: Space = if has_head(&(v1085_3)) { singleton(&[]) } else { Space::new() };
    drop(v1085_3);
    let v1085_5: Space = subtract(&(*CONSTANT_2),&(v1085_4));
    drop(v1085_4);
    let v1085_8: Space = if (v1085_5).is_empty() { Space::new() } else {
      let v1086_6: Path = concat_path(&(*p0),&(v1084_13_head));
      let mut v1086_7 = Space::new();
      let mut v1086_7_cursor = (v1084_13_tail).read_zipper();
      for v1086_7_byte in v1086_7_cursor.child_mask().iter() {
        v1086_7_cursor.descend_to_byte(v1086_7_byte);
        let v1086_7_tail = v1086_7_cursor.make_map();
        v1086_7_cursor.ascend(1);
        let v1086_7_head = Path::from_slice(&[v1086_7_byte]);
        let v1087_2: Space = singleton(&(v1086_7_head));
        let v1087_3: Space = intersect(&(*CONSTANT_3),&(v1087_2));
        let v1087_4: Space = if has_head(&(v1087_3)) { singleton(&[]) } else { Space::new() };
        drop(v1087_3);
        let v1087_5: Space = subtract(&(*CONSTANT_2),&(v1087_4));
        drop(v1087_4);
        let v1087_8: Space = if (v1087_5).is_empty() { Space::new() } else {
          let v1088_6: Path = concat_path(&(v1086_6),&(v1086_7_head));
          let v1088_7: Space = routine_154(c, &(v1088_6), &(*p1), &(v1086_7_tail), &(*s1));
          compose(&(v1087_5),&(v1088_7))
        };
        drop(v1087_5);
        let v1087_9: Space = intersect(&(*CONSTANT_3),&(v1087_2));
        drop(v1087_2);
        let v1087_10: Space = if has_head(&(v1087_9)) { singleton(&[]) } else { Space::new() };
        drop(v1087_9);
        let v1087_12: Space = if (v1087_10).is_empty() { Space::new() } else {
          let v1089_6: Path = concat_path(&(v1086_6),&(v1086_7_head));
          let v1089_11: Space = routine_155(c, &(v1089_6), &(*p1), &(v1086_7_tail), &(*s1));
          drop(v1089_6);
          compose(&(v1087_10),&(v1089_11))
        };
        drop(v1087_10);
        let v1087_13: Space = unite(&(v1087_8),&(v1087_12));
        v1086_7.join_into((v1087_13).clone());
      }
      drop(v1086_7_cursor);
      compose(&(v1085_5),&(v1086_7))
    };
    drop(v1085_5);
    let v1085_9: Space = intersect(&(*CONSTANT_3),&(v1085_2));
    drop(v1085_2);
    let v1085_10: Space = if has_head(&(v1085_9)) { singleton(&[]) } else { Space::new() };
    drop(v1085_9);
    let v1085_12: Space = if (v1085_10).is_empty() { Space::new() } else {
      let v1090_6: Path = concat_path(&(*p0),&(v1084_13_head));
      let mut v1090_11 = Space::new();
      let mut v1090_11_cursor = (v1084_13_tail).read_zipper();
      for v1090_11_byte in v1090_11_cursor.child_mask().iter() {
        v1090_11_cursor.descend_to_byte(v1090_11_byte);
        let v1090_11_tail = v1090_11_cursor.make_map();
        v1090_11_cursor.ascend(1);
        let v1090_11_head = Path::from_slice(&[v1090_11_byte]);
        let v1091_2: Space = singleton(&(v1090_11_head));
        let v1091_3: Space = intersect(&(*CONSTANT_3),&(v1091_2));
        let v1091_4: Space = if has_head(&(v1091_3)) { singleton(&[]) } else { Space::new() };
        drop(v1091_3);
        let v1091_5: Space = subtract(&(*CONSTANT_2),&(v1091_4));
        drop(v1091_4);
        let v1091_8: Space = if (v1091_5).is_empty() { Space::new() } else {
          let v1092_6: Path = concat_path(&(v1090_6),&(v1090_11_head));
          let v1092_7: Space = routine_154(c, &(v1092_6), &(*p1), &(v1090_11_tail), &(*s1));
          compose(&(v1091_5),&(v1092_7))
        };
        drop(v1091_5);
        let v1091_9: Space = intersect(&(*CONSTANT_3),&(v1091_2));
        drop(v1091_2);
        let v1091_10: Space = if has_head(&(v1091_9)) { singleton(&[]) } else { Space::new() };
        drop(v1091_9);
        let v1091_12: Space = if (v1091_10).is_empty() { Space::new() } else {
          let v1093_6: Path = concat_path(&(v1090_6),&(v1090_11_head));
          let v1093_11: Space = routine_43(c, &(v1093_6), &(*p1), &(v1090_11_tail), &(*s1));
          drop(v1093_6);
          compose(&(v1091_10),&(v1093_11))
        };
        drop(v1091_10);
        let v1091_13: Space = unite(&(v1091_8),&(v1091_12));
        v1090_11.join_into((v1091_13).clone());
      }
      drop(v1090_11_cursor);
      drop(v1090_6);
      compose(&(v1085_10),&(v1090_11))
    };
    drop(v1085_10);
    let v1085_13: Space = unite(&(v1085_8),&(v1085_12));
    v1084_13.join_into((v1085_13).clone());
  }
  drop(v1084_13_cursor);
  (v1084_13).clone()
}

fn routine_121(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1094_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v1094_10: Space = unwrap(&(v1094_8),&(*CONSTANT_5));
  drop(v1094_8);
  let v1094_11: Space = unwrap(&(v1094_10),&(*p0));
  drop(v1094_10);
  let mut v1094_18 = Space::new();
  let mut v1094_18_cursor = (*s0).read_zipper();
  for v1094_18_byte in v1094_18_cursor.child_mask().iter() {
    v1094_18_cursor.descend_to_byte(v1094_18_byte);
    let v1094_18_tail = v1094_18_cursor.make_map();
    v1094_18_cursor.ascend(1);
    let v1094_18_head = Path::from_slice(&[v1094_18_byte]);
    let v1095_2: Space = singleton(&(v1094_18_head));
    let v1095_3: Space = intersect(&(*CONSTANT_3),&(v1095_2));
    let v1095_4: Space = if has_head(&(v1095_3)) { singleton(&[]) } else { Space::new() };
    drop(v1095_3);
    let v1095_5: Space = subtract(&(*CONSTANT_2),&(v1095_4));
    drop(v1095_4);
    let v1095_8: Space = if (v1095_5).is_empty() { Space::new() } else {
      let v1096_6: Path = concat_path(&(*p0),&(v1094_18_head));
      let mut v1096_7 = Space::new();
      let mut v1096_7_cursor = (v1094_18_tail).read_zipper();
      for v1096_7_byte in v1096_7_cursor.child_mask().iter() {
        v1096_7_cursor.descend_to_byte(v1096_7_byte);
        let v1096_7_tail = v1096_7_cursor.make_map();
        v1096_7_cursor.ascend(1);
        let v1096_7_head = Path::from_slice(&[v1096_7_byte]);
        let v1097_2: Space = singleton(&(v1096_7_head));
        let v1097_3: Space = intersect(&(*CONSTANT_3),&(v1097_2));
        let v1097_4: Space = if has_head(&(v1097_3)) { singleton(&[]) } else { Space::new() };
        drop(v1097_3);
        let v1097_5: Space = subtract(&(*CONSTANT_2),&(v1097_4));
        drop(v1097_4);
        let v1097_8: Space = if (v1097_5).is_empty() { Space::new() } else {
          let v1098_6: Path = concat_path(&(v1096_6),&(v1096_7_head));
          let v1098_7: Space = routine_154(c, &(v1098_6), &(*p1), &(v1096_7_tail), &(*s1));
          compose(&(v1097_5),&(v1098_7))
        };
        drop(v1097_5);
        let v1097_9: Space = intersect(&(*CONSTANT_3),&(v1097_2));
        drop(v1097_2);
        let v1097_10: Space = if has_head(&(v1097_9)) { singleton(&[]) } else { Space::new() };
        drop(v1097_9);
        let v1097_12: Space = if (v1097_10).is_empty() { Space::new() } else {
          let v1099_6: Path = concat_path(&(v1096_6),&(v1096_7_head));
          let v1099_11: Space = routine_155(c, &(v1099_6), &(*p1), &(v1096_7_tail), &(*s1));
          drop(v1099_6);
          compose(&(v1097_10),&(v1099_11))
        };
        drop(v1097_10);
        let v1097_13: Space = unite(&(v1097_8),&(v1097_12));
        v1096_7.join_into((v1097_13).clone());
      }
      drop(v1096_7_cursor);
      drop(v1096_6);
      compose(&(v1095_5),&(v1096_7))
    };
    drop(v1095_5);
    let v1095_9: Space = intersect(&(*CONSTANT_3),&(v1095_2));
    drop(v1095_2);
    let v1095_10: Space = if has_head(&(v1095_9)) { singleton(&[]) } else { Space::new() };
    drop(v1095_9);
    let v1095_13: Space = if (v1095_10).is_empty() { Space::new() } else {
      let v1100_11: Space = unwrap(&(v1094_11),&(v1094_18_head));
      let mut v1100_12 = Space::new();
      let mut v1100_12_cursor = (v1100_11).read_zipper();
      for v1100_12_byte in v1100_12_cursor.child_mask().iter() {
        v1100_12_cursor.descend_to_byte(v1100_12_byte);
        let v1100_12_tail = v1100_12_cursor.make_map();
        v1100_12_cursor.ascend(1);
        let v1100_12_head = Path::from_slice(&[v1100_12_byte]);
        let v1101_2: Space = singleton(&(v1100_12_head));
        let v1101_3: Space = intersect(&(*CONSTANT_3),&(v1101_2));
        let v1101_4: Space = if has_head(&(v1101_3)) { singleton(&[]) } else { Space::new() };
        drop(v1101_3);
        let v1101_5: Space = subtract(&(*CONSTANT_2),&(v1101_4));
        drop(v1101_4);
        let v1101_7: Space = if (v1101_5).is_empty() { Space::new() } else {
          let v1102_6: Space = routine_78(c, &(v1100_12_head), &(*p1), &(v1100_12_tail));
          compose(&(v1101_5),&(v1102_6))
        };
        drop(v1101_5);
        let v1101_8: Space = intersect(&(*CONSTANT_3),&(v1101_2));
        drop(v1101_2);
        let v1101_9: Space = if has_head(&(v1101_8)) { singleton(&[]) } else { Space::new() };
        drop(v1101_8);
        let v1101_11: Space = if (v1101_9).is_empty() { Space::new() } else {
          let v1103_10: Space = routine_79(c, &(v1100_12_head), &(*p1), &(v1100_12_tail));
          compose(&(v1101_9),&(v1103_10))
        };
        drop(v1101_9);
        let v1101_12: Space = unite(&(v1101_7),&(v1101_11));
        v1100_12.join_into((v1101_12).clone());
      }
      drop(v1100_12_cursor);
      drop(v1100_11);
      compose(&(v1095_10),&(v1100_12))
    };
    drop(v1095_10);
    let v1095_14: Space = unite(&(v1095_8),&(v1095_13));
    v1094_18.join_into((v1095_14).clone());
  }
  drop(v1094_18_cursor);
  drop(v1094_11);
  (v1094_18).clone()
}

fn routine_122(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1104_12 = Space::new();
  let mut v1104_12_cursor = (*s0).read_zipper();
  for v1104_12_byte in v1104_12_cursor.child_mask().iter() {
    v1104_12_cursor.descend_to_byte(v1104_12_byte);
    let v1104_12_tail = v1104_12_cursor.make_map();
    v1104_12_cursor.ascend(1);
    let v1104_12_head = Path::from_slice(&[v1104_12_byte]);
    let v1105_2: Space = singleton(&(v1104_12_head));
    let v1105_3: Space = intersect(&(*CONSTANT_3),&(v1105_2));
    let v1105_4: Space = if has_head(&(v1105_3)) { singleton(&[]) } else { Space::new() };
    drop(v1105_3);
    let v1105_5: Space = subtract(&(*CONSTANT_2),&(v1105_4));
    drop(v1105_4);
    let v1105_8: Space = if (v1105_5).is_empty() { Space::new() } else {
      let v1106_6: Path = concat_path(&(*p0),&(v1104_12_head));
      let mut v1106_7 = Space::new();
      let mut v1106_7_cursor = (v1104_12_tail).read_zipper();
      for v1106_7_byte in v1106_7_cursor.child_mask().iter() {
        v1106_7_cursor.descend_to_byte(v1106_7_byte);
        let v1106_7_tail = v1106_7_cursor.make_map();
        v1106_7_cursor.ascend(1);
        let v1106_7_head = Path::from_slice(&[v1106_7_byte]);
        let v1107_2: Space = singleton(&(v1106_7_head));
        let v1107_3: Space = intersect(&(*CONSTANT_3),&(v1107_2));
        let v1107_4: Space = if has_head(&(v1107_3)) { singleton(&[]) } else { Space::new() };
        drop(v1107_3);
        let v1107_5: Space = subtract(&(*CONSTANT_2),&(v1107_4));
        drop(v1107_4);
        let v1107_8: Space = if (v1107_5).is_empty() { Space::new() } else {
          let v1108_6: Path = concat_path(&(v1106_6),&(v1106_7_head));
          let v1108_7: Space = routine_156(c, &(v1108_6), &(*p1), &(v1106_7_tail));
          compose(&(v1107_5),&(v1108_7))
        };
        drop(v1107_5);
        let v1107_9: Space = intersect(&(*CONSTANT_3),&(v1107_2));
        drop(v1107_2);
        let v1107_10: Space = if has_head(&(v1107_9)) { singleton(&[]) } else { Space::new() };
        drop(v1107_9);
        let v1107_12: Space = if (v1107_10).is_empty() { Space::new() } else {
          let v1109_6: Path = concat_path(&(v1106_6),&(v1106_7_head));
          let v1109_11: Space = routine_157(c, &(v1109_6), &(*p1), &(v1106_7_tail));
          drop(v1109_6);
          compose(&(v1107_10),&(v1109_11))
        };
        drop(v1107_10);
        let v1107_13: Space = unite(&(v1107_8),&(v1107_12));
        v1106_7.join_into((v1107_13).clone());
      }
      drop(v1106_7_cursor);
      compose(&(v1105_5),&(v1106_7))
    };
    drop(v1105_5);
    let v1105_9: Space = intersect(&(*CONSTANT_3),&(v1105_2));
    drop(v1105_2);
    let v1105_10: Space = if has_head(&(v1105_9)) { singleton(&[]) } else { Space::new() };
    drop(v1105_9);
    let v1105_12: Space = if (v1105_10).is_empty() { Space::new() } else {
      let v1110_6: Path = concat_path(&(*p0),&(v1104_12_head));
      let mut v1110_11 = Space::new();
      let mut v1110_11_cursor = (v1104_12_tail).read_zipper();
      for v1110_11_byte in v1110_11_cursor.child_mask().iter() {
        v1110_11_cursor.descend_to_byte(v1110_11_byte);
        let v1110_11_tail = v1110_11_cursor.make_map();
        v1110_11_cursor.ascend(1);
        let v1110_11_head = Path::from_slice(&[v1110_11_byte]);
        let v1111_2: Space = singleton(&(v1110_11_head));
        let v1111_3: Space = intersect(&(*CONSTANT_3),&(v1111_2));
        let v1111_4: Space = if has_head(&(v1111_3)) { singleton(&[]) } else { Space::new() };
        drop(v1111_3);
        let v1111_5: Space = subtract(&(*CONSTANT_2),&(v1111_4));
        drop(v1111_4);
        let v1111_8: Space = if (v1111_5).is_empty() { Space::new() } else {
          let v1112_6: Path = concat_path(&(v1110_6),&(v1110_11_head));
          let v1112_7: Space = routine_156(c, &(v1112_6), &(*p1), &(v1110_11_tail));
          compose(&(v1111_5),&(v1112_7))
        };
        drop(v1111_5);
        let v1111_9: Space = intersect(&(*CONSTANT_3),&(v1111_2));
        drop(v1111_2);
        let v1111_10: Space = if has_head(&(v1111_9)) { singleton(&[]) } else { Space::new() };
        drop(v1111_9);
        let v1111_12: Space = if (v1111_10).is_empty() { Space::new() } else {
          let v1113_6: Path = concat_path(&(v1110_6),&(v1110_11_head));
          let v1113_11: Space = routine_84(c, &(v1113_6), &(*p1), &(v1110_11_tail));
          drop(v1113_6);
          compose(&(v1111_10),&(v1113_11))
        };
        drop(v1111_10);
        let v1111_13: Space = unite(&(v1111_8),&(v1111_12));
        v1110_11.join_into((v1111_13).clone());
      }
      drop(v1110_11_cursor);
      drop(v1110_6);
      compose(&(v1105_10),&(v1110_11))
    };
    drop(v1105_10);
    let v1105_13: Space = unite(&(v1105_8),&(v1105_12));
    v1104_12.join_into((v1105_13).clone());
  }
  drop(v1104_12_cursor);
  (v1104_12).clone()
}

fn routine_123(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1114_9 = Space::new();
  let mut v1114_9_cursor = (*s0).read_zipper();
  for v1114_9_byte in v1114_9_cursor.child_mask().iter() {
    v1114_9_cursor.descend_to_byte(v1114_9_byte);
    let v1114_9_tail = v1114_9_cursor.make_map();
    v1114_9_cursor.ascend(1);
    let v1114_9_head = Path::from_slice(&[v1114_9_byte]);
    let v1115_2: Space = singleton(&(v1114_9_head));
    let v1115_3: Space = intersect(&(*CONSTANT_3),&(v1115_2));
    let v1115_4: Space = if has_head(&(v1115_3)) { singleton(&[]) } else { Space::new() };
    drop(v1115_3);
    let v1115_5: Space = subtract(&(*CONSTANT_2),&(v1115_4));
    drop(v1115_4);
    let v1115_8: Space = if (v1115_5).is_empty() { Space::new() } else {
      let v1116_6: Path = concat_path(&(*p0),&(v1114_9_head));
      let mut v1116_7 = Space::new();
      let mut v1116_7_cursor = (v1114_9_tail).read_zipper();
      for v1116_7_byte in v1116_7_cursor.child_mask().iter() {
        v1116_7_cursor.descend_to_byte(v1116_7_byte);
        let v1116_7_tail = v1116_7_cursor.make_map();
        v1116_7_cursor.ascend(1);
        let v1116_7_head = Path::from_slice(&[v1116_7_byte]);
        let v1117_2: Space = singleton(&(v1116_7_head));
        let v1117_3: Space = intersect(&(*CONSTANT_3),&(v1117_2));
        let v1117_4: Space = if has_head(&(v1117_3)) { singleton(&[]) } else { Space::new() };
        drop(v1117_3);
        let v1117_5: Space = subtract(&(*CONSTANT_2),&(v1117_4));
        drop(v1117_4);
        let v1117_8: Space = if (v1117_5).is_empty() { Space::new() } else {
          let v1118_6: Path = concat_path(&(v1116_6),&(v1116_7_head));
          let v1118_7: Space = routine_156(c, &(v1118_6), &(*p1), &(v1116_7_tail));
          compose(&(v1117_5),&(v1118_7))
        };
        drop(v1117_5);
        let v1117_9: Space = intersect(&(*CONSTANT_3),&(v1117_2));
        drop(v1117_2);
        let v1117_10: Space = if has_head(&(v1117_9)) { singleton(&[]) } else { Space::new() };
        drop(v1117_9);
        let v1117_12: Space = if (v1117_10).is_empty() { Space::new() } else {
          let v1119_6: Path = concat_path(&(v1116_6),&(v1116_7_head));
          let v1119_11: Space = routine_157(c, &(v1119_6), &(*p1), &(v1116_7_tail));
          drop(v1119_6);
          compose(&(v1117_10),&(v1119_11))
        };
        drop(v1117_10);
        let v1117_13: Space = unite(&(v1117_8),&(v1117_12));
        v1116_7.join_into((v1117_13).clone());
      }
      drop(v1116_7_cursor);
      compose(&(v1115_5),&(v1116_7))
    };
    drop(v1115_5);
    let v1115_9: Space = intersect(&(*CONSTANT_3),&(v1115_2));
    drop(v1115_2);
    let v1115_10: Space = if has_head(&(v1115_9)) { singleton(&[]) } else { Space::new() };
    drop(v1115_9);
    let v1115_11: Space = compose(&(v1115_10),&(v1114_9_tail));
    drop(v1115_10);
    let v1120_6: Path = concat_path(&(*p0),&(v1114_9_head));
    let v1115_12: Space = wrap(&(v1115_11),&(v1120_6));
    drop(v1115_11);
    let v1115_13: Space = wrap(&(v1115_12),&(*p1));
    drop(v1115_12);
    let v1115_14: Space = unite(&(v1115_8),&(v1115_13));
    drop(v1115_13);
    v1114_9.join_into((v1115_14).clone());
  }
  drop(v1114_9_cursor);
  (v1114_9).clone()
}

fn routine_124(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1121_13 = Space::new();
  let mut v1121_13_cursor = (*s0).read_zipper();
  for v1121_13_byte in v1121_13_cursor.child_mask().iter() {
    v1121_13_cursor.descend_to_byte(v1121_13_byte);
    let v1121_13_tail = v1121_13_cursor.make_map();
    v1121_13_cursor.ascend(1);
    let v1121_13_head = Path::from_slice(&[v1121_13_byte]);
    let v1122_2: Space = singleton(&(v1121_13_head));
    let v1122_3: Space = intersect(&(*CONSTANT_3),&(v1122_2));
    let v1122_4: Space = if has_head(&(v1122_3)) { singleton(&[]) } else { Space::new() };
    drop(v1122_3);
    let v1122_5: Space = subtract(&(*CONSTANT_2),&(v1122_4));
    drop(v1122_4);
    let v1122_8: Space = if (v1122_5).is_empty() { Space::new() } else {
      let v1123_6: Path = concat_path(&(*p0),&(v1121_13_head));
      let mut v1123_7 = Space::new();
      let mut v1123_7_cursor = (v1121_13_tail).read_zipper();
      for v1123_7_byte in v1123_7_cursor.child_mask().iter() {
        v1123_7_cursor.descend_to_byte(v1123_7_byte);
        let v1123_7_tail = v1123_7_cursor.make_map();
        v1123_7_cursor.ascend(1);
        let v1123_7_head = Path::from_slice(&[v1123_7_byte]);
        let v1124_2: Space = singleton(&(v1123_7_head));
        let v1124_3: Space = intersect(&(*CONSTANT_3),&(v1124_2));
        let v1124_4: Space = if has_head(&(v1124_3)) { singleton(&[]) } else { Space::new() };
        drop(v1124_3);
        let v1124_5: Space = subtract(&(*CONSTANT_2),&(v1124_4));
        drop(v1124_4);
        let v1124_8: Space = if (v1124_5).is_empty() { Space::new() } else {
          let v1125_6: Path = concat_path(&(v1123_6),&(v1123_7_head));
          let v1125_7: Space = routine_158(c, &(v1125_6), &(*p1), &(v1123_7_tail), &(*s1));
          compose(&(v1124_5),&(v1125_7))
        };
        drop(v1124_5);
        let v1124_9: Space = intersect(&(*CONSTANT_3),&(v1124_2));
        drop(v1124_2);
        let v1124_10: Space = if has_head(&(v1124_9)) { singleton(&[]) } else { Space::new() };
        drop(v1124_9);
        let v1124_12: Space = if (v1124_10).is_empty() { Space::new() } else {
          let v1126_6: Path = concat_path(&(v1123_6),&(v1123_7_head));
          let v1126_11: Space = routine_159(c, &(v1126_6), &(*p1), &(v1123_7_tail), &(*s1));
          drop(v1126_6);
          compose(&(v1124_10),&(v1126_11))
        };
        drop(v1124_10);
        let v1124_13: Space = unite(&(v1124_8),&(v1124_12));
        v1123_7.join_into((v1124_13).clone());
      }
      drop(v1123_7_cursor);
      compose(&(v1122_5),&(v1123_7))
    };
    drop(v1122_5);
    let v1122_9: Space = intersect(&(*CONSTANT_3),&(v1122_2));
    drop(v1122_2);
    let v1122_10: Space = if has_head(&(v1122_9)) { singleton(&[]) } else { Space::new() };
    drop(v1122_9);
    let v1122_12: Space = if (v1122_10).is_empty() { Space::new() } else {
      let v1127_6: Path = concat_path(&(*p0),&(v1121_13_head));
      let mut v1127_11 = Space::new();
      let mut v1127_11_cursor = (v1121_13_tail).read_zipper();
      for v1127_11_byte in v1127_11_cursor.child_mask().iter() {
        v1127_11_cursor.descend_to_byte(v1127_11_byte);
        let v1127_11_tail = v1127_11_cursor.make_map();
        v1127_11_cursor.ascend(1);
        let v1127_11_head = Path::from_slice(&[v1127_11_byte]);
        let v1128_2: Space = singleton(&(v1127_11_head));
        let v1128_3: Space = intersect(&(*CONSTANT_3),&(v1128_2));
        let v1128_4: Space = if has_head(&(v1128_3)) { singleton(&[]) } else { Space::new() };
        drop(v1128_3);
        let v1128_5: Space = subtract(&(*CONSTANT_2),&(v1128_4));
        drop(v1128_4);
        let v1128_8: Space = if (v1128_5).is_empty() { Space::new() } else {
          let v1129_6: Path = concat_path(&(v1127_6),&(v1127_11_head));
          let v1129_7: Space = routine_158(c, &(v1129_6), &(*p1), &(v1127_11_tail), &(*s1));
          compose(&(v1128_5),&(v1129_7))
        };
        drop(v1128_5);
        let v1128_9: Space = intersect(&(*CONSTANT_3),&(v1128_2));
        drop(v1128_2);
        let v1128_10: Space = if has_head(&(v1128_9)) { singleton(&[]) } else { Space::new() };
        drop(v1128_9);
        let v1128_12: Space = if (v1128_10).is_empty() { Space::new() } else {
          let v1130_6: Path = concat_path(&(v1127_6),&(v1127_11_head));
          let v1130_11: Space = routine_43(c, &(v1130_6), &(*p1), &(v1127_11_tail), &(*s1));
          drop(v1130_6);
          compose(&(v1128_10),&(v1130_11))
        };
        drop(v1128_10);
        let v1128_13: Space = unite(&(v1128_8),&(v1128_12));
        v1127_11.join_into((v1128_13).clone());
      }
      drop(v1127_11_cursor);
      drop(v1127_6);
      compose(&(v1122_10),&(v1127_11))
    };
    drop(v1122_10);
    let v1122_13: Space = unite(&(v1122_8),&(v1122_12));
    v1121_13.join_into((v1122_13).clone());
  }
  drop(v1121_13_cursor);
  (v1121_13).clone()
}

fn routine_125(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1131_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v1131_10: Space = unwrap(&(v1131_8),&(*CONSTANT_5));
  drop(v1131_8);
  let v1131_11: Space = unwrap(&(v1131_10),&(*p0));
  drop(v1131_10);
  let mut v1131_18 = Space::new();
  let mut v1131_18_cursor = (*s0).read_zipper();
  for v1131_18_byte in v1131_18_cursor.child_mask().iter() {
    v1131_18_cursor.descend_to_byte(v1131_18_byte);
    let v1131_18_tail = v1131_18_cursor.make_map();
    v1131_18_cursor.ascend(1);
    let v1131_18_head = Path::from_slice(&[v1131_18_byte]);
    let v1132_2: Space = singleton(&(v1131_18_head));
    let v1132_3: Space = intersect(&(*CONSTANT_3),&(v1132_2));
    let v1132_4: Space = if has_head(&(v1132_3)) { singleton(&[]) } else { Space::new() };
    drop(v1132_3);
    let v1132_5: Space = subtract(&(*CONSTANT_2),&(v1132_4));
    drop(v1132_4);
    let v1132_8: Space = if (v1132_5).is_empty() { Space::new() } else {
      let v1133_6: Path = concat_path(&(*p0),&(v1131_18_head));
      let mut v1133_7 = Space::new();
      let mut v1133_7_cursor = (v1131_18_tail).read_zipper();
      for v1133_7_byte in v1133_7_cursor.child_mask().iter() {
        v1133_7_cursor.descend_to_byte(v1133_7_byte);
        let v1133_7_tail = v1133_7_cursor.make_map();
        v1133_7_cursor.ascend(1);
        let v1133_7_head = Path::from_slice(&[v1133_7_byte]);
        let v1134_2: Space = singleton(&(v1133_7_head));
        let v1134_3: Space = intersect(&(*CONSTANT_3),&(v1134_2));
        let v1134_4: Space = if has_head(&(v1134_3)) { singleton(&[]) } else { Space::new() };
        drop(v1134_3);
        let v1134_5: Space = subtract(&(*CONSTANT_2),&(v1134_4));
        drop(v1134_4);
        let v1134_8: Space = if (v1134_5).is_empty() { Space::new() } else {
          let v1135_6: Path = concat_path(&(v1133_6),&(v1133_7_head));
          let v1135_7: Space = routine_158(c, &(v1135_6), &(*p1), &(v1133_7_tail), &(*s1));
          compose(&(v1134_5),&(v1135_7))
        };
        drop(v1134_5);
        let v1134_9: Space = intersect(&(*CONSTANT_3),&(v1134_2));
        drop(v1134_2);
        let v1134_10: Space = if has_head(&(v1134_9)) { singleton(&[]) } else { Space::new() };
        drop(v1134_9);
        let v1134_12: Space = if (v1134_10).is_empty() { Space::new() } else {
          let v1136_6: Path = concat_path(&(v1133_6),&(v1133_7_head));
          let v1136_11: Space = routine_159(c, &(v1136_6), &(*p1), &(v1133_7_tail), &(*s1));
          drop(v1136_6);
          compose(&(v1134_10),&(v1136_11))
        };
        drop(v1134_10);
        let v1134_13: Space = unite(&(v1134_8),&(v1134_12));
        v1133_7.join_into((v1134_13).clone());
      }
      drop(v1133_7_cursor);
      drop(v1133_6);
      compose(&(v1132_5),&(v1133_7))
    };
    drop(v1132_5);
    let v1132_9: Space = intersect(&(*CONSTANT_3),&(v1132_2));
    drop(v1132_2);
    let v1132_10: Space = if has_head(&(v1132_9)) { singleton(&[]) } else { Space::new() };
    drop(v1132_9);
    let v1132_13: Space = if (v1132_10).is_empty() { Space::new() } else {
      let v1137_11: Space = unwrap(&(v1131_11),&(v1131_18_head));
      let mut v1137_12 = Space::new();
      let mut v1137_12_cursor = (v1137_11).read_zipper();
      for v1137_12_byte in v1137_12_cursor.child_mask().iter() {
        v1137_12_cursor.descend_to_byte(v1137_12_byte);
        let v1137_12_tail = v1137_12_cursor.make_map();
        v1137_12_cursor.ascend(1);
        let v1137_12_head = Path::from_slice(&[v1137_12_byte]);
        let v1138_2: Space = singleton(&(v1137_12_head));
        let v1138_3: Space = intersect(&(*CONSTANT_3),&(v1138_2));
        let v1138_4: Space = if has_head(&(v1138_3)) { singleton(&[]) } else { Space::new() };
        drop(v1138_3);
        let v1138_5: Space = subtract(&(*CONSTANT_2),&(v1138_4));
        drop(v1138_4);
        let v1138_7: Space = if (v1138_5).is_empty() { Space::new() } else {
          let v1139_6: Space = routine_78(c, &(v1137_12_head), &(*p1), &(v1137_12_tail));
          compose(&(v1138_5),&(v1139_6))
        };
        drop(v1138_5);
        let v1138_8: Space = intersect(&(*CONSTANT_3),&(v1138_2));
        drop(v1138_2);
        let v1138_9: Space = if has_head(&(v1138_8)) { singleton(&[]) } else { Space::new() };
        drop(v1138_8);
        let v1138_11: Space = if (v1138_9).is_empty() { Space::new() } else {
          let v1140_10: Space = routine_79(c, &(v1137_12_head), &(*p1), &(v1137_12_tail));
          compose(&(v1138_9),&(v1140_10))
        };
        drop(v1138_9);
        let v1138_12: Space = unite(&(v1138_7),&(v1138_11));
        v1137_12.join_into((v1138_12).clone());
      }
      drop(v1137_12_cursor);
      drop(v1137_11);
      compose(&(v1132_10),&(v1137_12))
    };
    drop(v1132_10);
    let v1132_14: Space = unite(&(v1132_8),&(v1132_13));
    v1131_18.join_into((v1132_14).clone());
  }
  drop(v1131_18_cursor);
  drop(v1131_11);
  (v1131_18).clone()
}

fn routine_126(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1141_12 = Space::new();
  let mut v1141_12_cursor = (*s0).read_zipper();
  for v1141_12_byte in v1141_12_cursor.child_mask().iter() {
    v1141_12_cursor.descend_to_byte(v1141_12_byte);
    let v1141_12_tail = v1141_12_cursor.make_map();
    v1141_12_cursor.ascend(1);
    let v1141_12_head = Path::from_slice(&[v1141_12_byte]);
    let v1142_2: Space = singleton(&(v1141_12_head));
    let v1142_3: Space = intersect(&(*CONSTANT_3),&(v1142_2));
    let v1142_4: Space = if has_head(&(v1142_3)) { singleton(&[]) } else { Space::new() };
    drop(v1142_3);
    let v1142_5: Space = subtract(&(*CONSTANT_2),&(v1142_4));
    drop(v1142_4);
    let v1142_8: Space = if (v1142_5).is_empty() { Space::new() } else {
      let v1143_6: Path = concat_path(&(*p0),&(v1141_12_head));
      let mut v1143_7 = Space::new();
      let mut v1143_7_cursor = (v1141_12_tail).read_zipper();
      for v1143_7_byte in v1143_7_cursor.child_mask().iter() {
        v1143_7_cursor.descend_to_byte(v1143_7_byte);
        let v1143_7_tail = v1143_7_cursor.make_map();
        v1143_7_cursor.ascend(1);
        let v1143_7_head = Path::from_slice(&[v1143_7_byte]);
        let v1144_2: Space = singleton(&(v1143_7_head));
        let v1144_3: Space = intersect(&(*CONSTANT_3),&(v1144_2));
        let v1144_4: Space = if has_head(&(v1144_3)) { singleton(&[]) } else { Space::new() };
        drop(v1144_3);
        let v1144_5: Space = subtract(&(*CONSTANT_2),&(v1144_4));
        drop(v1144_4);
        let v1144_8: Space = if (v1144_5).is_empty() { Space::new() } else {
          let v1145_6: Path = concat_path(&(v1143_6),&(v1143_7_head));
          let v1145_7: Space = routine_160(c, &(v1145_6), &(*p1), &(v1143_7_tail));
          compose(&(v1144_5),&(v1145_7))
        };
        drop(v1144_5);
        let v1144_9: Space = intersect(&(*CONSTANT_3),&(v1144_2));
        drop(v1144_2);
        let v1144_10: Space = if has_head(&(v1144_9)) { singleton(&[]) } else { Space::new() };
        drop(v1144_9);
        let v1144_12: Space = if (v1144_10).is_empty() { Space::new() } else {
          let v1146_6: Path = concat_path(&(v1143_6),&(v1143_7_head));
          let v1146_11: Space = routine_161(c, &(v1146_6), &(*p1), &(v1143_7_tail));
          drop(v1146_6);
          compose(&(v1144_10),&(v1146_11))
        };
        drop(v1144_10);
        let v1144_13: Space = unite(&(v1144_8),&(v1144_12));
        v1143_7.join_into((v1144_13).clone());
      }
      drop(v1143_7_cursor);
      compose(&(v1142_5),&(v1143_7))
    };
    drop(v1142_5);
    let v1142_9: Space = intersect(&(*CONSTANT_3),&(v1142_2));
    drop(v1142_2);
    let v1142_10: Space = if has_head(&(v1142_9)) { singleton(&[]) } else { Space::new() };
    drop(v1142_9);
    let v1142_12: Space = if (v1142_10).is_empty() { Space::new() } else {
      let v1147_6: Path = concat_path(&(*p0),&(v1141_12_head));
      let mut v1147_11 = Space::new();
      let mut v1147_11_cursor = (v1141_12_tail).read_zipper();
      for v1147_11_byte in v1147_11_cursor.child_mask().iter() {
        v1147_11_cursor.descend_to_byte(v1147_11_byte);
        let v1147_11_tail = v1147_11_cursor.make_map();
        v1147_11_cursor.ascend(1);
        let v1147_11_head = Path::from_slice(&[v1147_11_byte]);
        let v1148_2: Space = singleton(&(v1147_11_head));
        let v1148_3: Space = intersect(&(*CONSTANT_3),&(v1148_2));
        let v1148_4: Space = if has_head(&(v1148_3)) { singleton(&[]) } else { Space::new() };
        drop(v1148_3);
        let v1148_5: Space = subtract(&(*CONSTANT_2),&(v1148_4));
        drop(v1148_4);
        let v1148_8: Space = if (v1148_5).is_empty() { Space::new() } else {
          let v1149_6: Path = concat_path(&(v1147_6),&(v1147_11_head));
          let v1149_7: Space = routine_160(c, &(v1149_6), &(*p1), &(v1147_11_tail));
          compose(&(v1148_5),&(v1149_7))
        };
        drop(v1148_5);
        let v1148_9: Space = intersect(&(*CONSTANT_3),&(v1148_2));
        drop(v1148_2);
        let v1148_10: Space = if has_head(&(v1148_9)) { singleton(&[]) } else { Space::new() };
        drop(v1148_9);
        let v1148_12: Space = if (v1148_10).is_empty() { Space::new() } else {
          let v1150_6: Path = concat_path(&(v1147_6),&(v1147_11_head));
          let v1150_11: Space = routine_84(c, &(v1150_6), &(*p1), &(v1147_11_tail));
          drop(v1150_6);
          compose(&(v1148_10),&(v1150_11))
        };
        drop(v1148_10);
        let v1148_13: Space = unite(&(v1148_8),&(v1148_12));
        v1147_11.join_into((v1148_13).clone());
      }
      drop(v1147_11_cursor);
      drop(v1147_6);
      compose(&(v1142_10),&(v1147_11))
    };
    drop(v1142_10);
    let v1142_13: Space = unite(&(v1142_8),&(v1142_12));
    v1141_12.join_into((v1142_13).clone());
  }
  drop(v1141_12_cursor);
  (v1141_12).clone()
}

fn routine_127(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1151_9 = Space::new();
  let mut v1151_9_cursor = (*s0).read_zipper();
  for v1151_9_byte in v1151_9_cursor.child_mask().iter() {
    v1151_9_cursor.descend_to_byte(v1151_9_byte);
    let v1151_9_tail = v1151_9_cursor.make_map();
    v1151_9_cursor.ascend(1);
    let v1151_9_head = Path::from_slice(&[v1151_9_byte]);
    let v1152_2: Space = singleton(&(v1151_9_head));
    let v1152_3: Space = intersect(&(*CONSTANT_3),&(v1152_2));
    let v1152_4: Space = if has_head(&(v1152_3)) { singleton(&[]) } else { Space::new() };
    drop(v1152_3);
    let v1152_5: Space = subtract(&(*CONSTANT_2),&(v1152_4));
    drop(v1152_4);
    let v1152_8: Space = if (v1152_5).is_empty() { Space::new() } else {
      let v1153_6: Path = concat_path(&(*p0),&(v1151_9_head));
      let mut v1153_7 = Space::new();
      let mut v1153_7_cursor = (v1151_9_tail).read_zipper();
      for v1153_7_byte in v1153_7_cursor.child_mask().iter() {
        v1153_7_cursor.descend_to_byte(v1153_7_byte);
        let v1153_7_tail = v1153_7_cursor.make_map();
        v1153_7_cursor.ascend(1);
        let v1153_7_head = Path::from_slice(&[v1153_7_byte]);
        let v1154_2: Space = singleton(&(v1153_7_head));
        let v1154_3: Space = intersect(&(*CONSTANT_3),&(v1154_2));
        let v1154_4: Space = if has_head(&(v1154_3)) { singleton(&[]) } else { Space::new() };
        drop(v1154_3);
        let v1154_5: Space = subtract(&(*CONSTANT_2),&(v1154_4));
        drop(v1154_4);
        let v1154_8: Space = if (v1154_5).is_empty() { Space::new() } else {
          let v1155_6: Path = concat_path(&(v1153_6),&(v1153_7_head));
          let v1155_7: Space = routine_160(c, &(v1155_6), &(*p1), &(v1153_7_tail));
          compose(&(v1154_5),&(v1155_7))
        };
        drop(v1154_5);
        let v1154_9: Space = intersect(&(*CONSTANT_3),&(v1154_2));
        drop(v1154_2);
        let v1154_10: Space = if has_head(&(v1154_9)) { singleton(&[]) } else { Space::new() };
        drop(v1154_9);
        let v1154_12: Space = if (v1154_10).is_empty() { Space::new() } else {
          let v1156_6: Path = concat_path(&(v1153_6),&(v1153_7_head));
          let v1156_11: Space = routine_161(c, &(v1156_6), &(*p1), &(v1153_7_tail));
          drop(v1156_6);
          compose(&(v1154_10),&(v1156_11))
        };
        drop(v1154_10);
        let v1154_13: Space = unite(&(v1154_8),&(v1154_12));
        v1153_7.join_into((v1154_13).clone());
      }
      drop(v1153_7_cursor);
      compose(&(v1152_5),&(v1153_7))
    };
    drop(v1152_5);
    let v1152_9: Space = intersect(&(*CONSTANT_3),&(v1152_2));
    drop(v1152_2);
    let v1152_10: Space = if has_head(&(v1152_9)) { singleton(&[]) } else { Space::new() };
    drop(v1152_9);
    let v1152_11: Space = compose(&(v1152_10),&(v1151_9_tail));
    drop(v1152_10);
    let v1157_6: Path = concat_path(&(*p0),&(v1151_9_head));
    let v1152_12: Space = wrap(&(v1152_11),&(v1157_6));
    drop(v1152_11);
    let v1152_13: Space = wrap(&(v1152_12),&(*p1));
    drop(v1152_12);
    let v1152_14: Space = unite(&(v1152_8),&(v1152_13));
    drop(v1152_13);
    v1151_9.join_into((v1152_14).clone());
  }
  drop(v1151_9_cursor);
  (v1151_9).clone()
}

fn routine_128(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1158_3 = Space::new();
  let mut v1158_3_cursor = (*s0).read_zipper();
  for v1158_3_byte in v1158_3_cursor.child_mask().iter() {
    v1158_3_cursor.descend_to_byte(v1158_3_byte);
    let v1158_3_tail = v1158_3_cursor.make_map();
    v1158_3_cursor.ascend(1);
    let v1158_3_head = Path::from_slice(&[v1158_3_byte]);
    let v1159_2: Space = Space::new();
    v1158_3.join_into((v1159_2).clone());
  }
  drop(v1158_3_cursor);
  (v1158_3).clone()
}

fn routine_129(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1160_7 = Space::new();
  let mut v1160_7_cursor = (*s0).read_zipper();
  for v1160_7_byte in v1160_7_cursor.child_mask().iter() {
    v1160_7_cursor.descend_to_byte(v1160_7_byte);
    let v1160_7_tail = v1160_7_cursor.make_map();
    v1160_7_cursor.ascend(1);
    let v1160_7_head = Path::from_slice(&[v1160_7_byte]);
    let v1161_2: Space = singleton(&(v1160_7_head));
    let v1161_3: Space = intersect(&(*CONSTANT_3),&(v1161_2));
    drop(v1161_2);
    let v1161_4: Space = if has_head(&(v1161_3)) { singleton(&[]) } else { Space::new() };
    drop(v1161_3);
    let v1161_7: Space = if (v1161_4).is_empty() { Space::new() } else {
      let v1162_5: Path = concat_path(&(*p0),&(v1160_7_head));
      let mut v1162_6 = Space::new();
      let mut v1162_6_cursor = (v1160_7_tail).read_zipper();
      for v1162_6_byte in v1162_6_cursor.child_mask().iter() {
        v1162_6_cursor.descend_to_byte(v1162_6_byte);
        let v1162_6_tail = v1162_6_cursor.make_map();
        v1162_6_cursor.ascend(1);
        let v1162_6_head = Path::from_slice(&[v1162_6_byte]);
        let v1163_2: Space = singleton(&(v1162_6_head));
        let v1163_3: Space = intersect(&(*CONSTANT_3),&(v1163_2));
        let v1163_4: Space = if has_head(&(v1163_3)) { singleton(&[]) } else { Space::new() };
        drop(v1163_3);
        let v1163_5: Space = subtract(&(*CONSTANT_2),&(v1163_4));
        drop(v1163_4);
        let v1163_7: Space = if (v1163_5).is_empty() { Space::new() } else {
          let v1164_6: Space = routine_46(c, &(v1162_6_head), &(v1162_5), &(v1162_6_tail), &(*s1));
          compose(&(v1163_5),&(v1164_6))
        };
        drop(v1163_5);
        let v1163_8: Space = intersect(&(*CONSTANT_3),&(v1163_2));
        drop(v1163_2);
        let v1163_9: Space = if has_head(&(v1163_8)) { singleton(&[]) } else { Space::new() };
        drop(v1163_8);
        let v1163_11: Space = if (v1163_9).is_empty() { Space::new() } else {
          let v1165_10: Space = routine_47(c, &(v1162_6_head), &(v1162_5), &(v1162_6_tail), &(*s1));
          compose(&(v1163_9),&(v1165_10))
        };
        drop(v1163_9);
        let v1163_12: Space = unite(&(v1163_7),&(v1163_11));
        v1162_6.join_into((v1163_12).clone());
      }
      drop(v1162_6_cursor);
      drop(v1162_5);
      compose(&(v1161_4),&(v1162_6))
    };
    drop(v1161_4);
    v1160_7.join_into((v1161_7).clone());
  }
  drop(v1160_7_cursor);
  (v1160_7).clone()
}

fn routine_130(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1166_13 = Space::new();
  let mut v1166_13_cursor = (*s0).read_zipper();
  for v1166_13_byte in v1166_13_cursor.child_mask().iter() {
    v1166_13_cursor.descend_to_byte(v1166_13_byte);
    let v1166_13_tail = v1166_13_cursor.make_map();
    v1166_13_cursor.ascend(1);
    let v1166_13_head = Path::from_slice(&[v1166_13_byte]);
    let v1167_2: Space = singleton(&(v1166_13_head));
    let v1167_3: Space = intersect(&(*CONSTANT_3),&(v1167_2));
    let v1167_4: Space = if has_head(&(v1167_3)) { singleton(&[]) } else { Space::new() };
    drop(v1167_3);
    let v1167_5: Space = subtract(&(*CONSTANT_2),&(v1167_4));
    drop(v1167_4);
    let v1167_8: Space = if (v1167_5).is_empty() { Space::new() } else {
      let v1168_6: Path = concat_path(&(*p0),&(v1166_13_head));
      let mut v1168_7 = Space::new();
      let mut v1168_7_cursor = (v1166_13_tail).read_zipper();
      for v1168_7_byte in v1168_7_cursor.child_mask().iter() {
        v1168_7_cursor.descend_to_byte(v1168_7_byte);
        let v1168_7_tail = v1168_7_cursor.make_map();
        v1168_7_cursor.ascend(1);
        let v1168_7_head = Path::from_slice(&[v1168_7_byte]);
        let v1169_2: Space = singleton(&(v1168_7_head));
        let v1169_3: Space = intersect(&(*CONSTANT_3),&(v1169_2));
        let v1169_4: Space = if has_head(&(v1169_3)) { singleton(&[]) } else { Space::new() };
        drop(v1169_3);
        let v1169_5: Space = subtract(&(*CONSTANT_2),&(v1169_4));
        drop(v1169_4);
        let v1169_8: Space = if (v1169_5).is_empty() { Space::new() } else {
          let v1170_6: Path = concat_path(&(v1168_6),&(v1168_7_head));
          let v1170_7: Space = routine_162(c, &(v1170_6), &(*p1), &(v1168_7_tail), &(*s1));
          compose(&(v1169_5),&(v1170_7))
        };
        drop(v1169_5);
        let v1169_9: Space = intersect(&(*CONSTANT_3),&(v1169_2));
        drop(v1169_2);
        let v1169_10: Space = if has_head(&(v1169_9)) { singleton(&[]) } else { Space::new() };
        drop(v1169_9);
        let v1169_12: Space = if (v1169_10).is_empty() { Space::new() } else {
          let v1171_6: Path = concat_path(&(v1168_6),&(v1168_7_head));
          let v1171_11: Space = routine_163(c, &(v1171_6), &(*p1), &(v1168_7_tail), &(*s1));
          drop(v1171_6);
          compose(&(v1169_10),&(v1171_11))
        };
        drop(v1169_10);
        let v1169_13: Space = unite(&(v1169_8),&(v1169_12));
        v1168_7.join_into((v1169_13).clone());
      }
      drop(v1168_7_cursor);
      compose(&(v1167_5),&(v1168_7))
    };
    drop(v1167_5);
    let v1167_9: Space = intersect(&(*CONSTANT_3),&(v1167_2));
    drop(v1167_2);
    let v1167_10: Space = if has_head(&(v1167_9)) { singleton(&[]) } else { Space::new() };
    drop(v1167_9);
    let v1167_12: Space = if (v1167_10).is_empty() { Space::new() } else {
      let v1172_6: Path = concat_path(&(*p0),&(v1166_13_head));
      let mut v1172_11 = Space::new();
      let mut v1172_11_cursor = (v1166_13_tail).read_zipper();
      for v1172_11_byte in v1172_11_cursor.child_mask().iter() {
        v1172_11_cursor.descend_to_byte(v1172_11_byte);
        let v1172_11_tail = v1172_11_cursor.make_map();
        v1172_11_cursor.ascend(1);
        let v1172_11_head = Path::from_slice(&[v1172_11_byte]);
        let v1173_2: Space = singleton(&(v1172_11_head));
        let v1173_3: Space = intersect(&(*CONSTANT_3),&(v1173_2));
        let v1173_4: Space = if has_head(&(v1173_3)) { singleton(&[]) } else { Space::new() };
        drop(v1173_3);
        let v1173_5: Space = subtract(&(*CONSTANT_2),&(v1173_4));
        drop(v1173_4);
        let v1173_8: Space = if (v1173_5).is_empty() { Space::new() } else {
          let v1174_6: Path = concat_path(&(v1172_6),&(v1172_11_head));
          let v1174_7: Space = routine_162(c, &(v1174_6), &(*p1), &(v1172_11_tail), &(*s1));
          compose(&(v1173_5),&(v1174_7))
        };
        drop(v1173_5);
        let v1173_9: Space = intersect(&(*CONSTANT_3),&(v1173_2));
        drop(v1173_2);
        let v1173_10: Space = if has_head(&(v1173_9)) { singleton(&[]) } else { Space::new() };
        drop(v1173_9);
        let v1173_12: Space = if (v1173_10).is_empty() { Space::new() } else {
          let v1175_6: Path = concat_path(&(v1172_6),&(v1172_11_head));
          let v1175_11: Space = routine_50(c, &(v1175_6), &(*p1), &(v1172_11_tail), &(*s1));
          drop(v1175_6);
          compose(&(v1173_10),&(v1175_11))
        };
        drop(v1173_10);
        let v1173_13: Space = unite(&(v1173_8),&(v1173_12));
        v1172_11.join_into((v1173_13).clone());
      }
      drop(v1172_11_cursor);
      drop(v1172_6);
      compose(&(v1167_10),&(v1172_11))
    };
    drop(v1167_10);
    let v1167_13: Space = unite(&(v1167_8),&(v1167_12));
    v1166_13.join_into((v1167_13).clone());
  }
  drop(v1166_13_cursor);
  (v1166_13).clone()
}

fn routine_131(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1176_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v1176_10: Space = unwrap(&(v1176_8),&(*CONSTANT_5));
  drop(v1176_8);
  let v1176_11: Space = unwrap(&(v1176_10),&(*p0));
  drop(v1176_10);
  let mut v1176_18 = Space::new();
  let mut v1176_18_cursor = (*s0).read_zipper();
  for v1176_18_byte in v1176_18_cursor.child_mask().iter() {
    v1176_18_cursor.descend_to_byte(v1176_18_byte);
    let v1176_18_tail = v1176_18_cursor.make_map();
    v1176_18_cursor.ascend(1);
    let v1176_18_head = Path::from_slice(&[v1176_18_byte]);
    let v1177_2: Space = singleton(&(v1176_18_head));
    let v1177_3: Space = intersect(&(*CONSTANT_3),&(v1177_2));
    let v1177_4: Space = if has_head(&(v1177_3)) { singleton(&[]) } else { Space::new() };
    drop(v1177_3);
    let v1177_5: Space = subtract(&(*CONSTANT_2),&(v1177_4));
    drop(v1177_4);
    let v1177_8: Space = if (v1177_5).is_empty() { Space::new() } else {
      let v1178_6: Path = concat_path(&(*p0),&(v1176_18_head));
      let mut v1178_7 = Space::new();
      let mut v1178_7_cursor = (v1176_18_tail).read_zipper();
      for v1178_7_byte in v1178_7_cursor.child_mask().iter() {
        v1178_7_cursor.descend_to_byte(v1178_7_byte);
        let v1178_7_tail = v1178_7_cursor.make_map();
        v1178_7_cursor.ascend(1);
        let v1178_7_head = Path::from_slice(&[v1178_7_byte]);
        let v1179_2: Space = singleton(&(v1178_7_head));
        let v1179_3: Space = intersect(&(*CONSTANT_3),&(v1179_2));
        let v1179_4: Space = if has_head(&(v1179_3)) { singleton(&[]) } else { Space::new() };
        drop(v1179_3);
        let v1179_5: Space = subtract(&(*CONSTANT_2),&(v1179_4));
        drop(v1179_4);
        let v1179_8: Space = if (v1179_5).is_empty() { Space::new() } else {
          let v1180_6: Path = concat_path(&(v1178_6),&(v1178_7_head));
          let v1180_7: Space = routine_162(c, &(v1180_6), &(*p1), &(v1178_7_tail), &(*s1));
          compose(&(v1179_5),&(v1180_7))
        };
        drop(v1179_5);
        let v1179_9: Space = intersect(&(*CONSTANT_3),&(v1179_2));
        drop(v1179_2);
        let v1179_10: Space = if has_head(&(v1179_9)) { singleton(&[]) } else { Space::new() };
        drop(v1179_9);
        let v1179_12: Space = if (v1179_10).is_empty() { Space::new() } else {
          let v1181_6: Path = concat_path(&(v1178_6),&(v1178_7_head));
          let v1181_11: Space = routine_163(c, &(v1181_6), &(*p1), &(v1178_7_tail), &(*s1));
          drop(v1181_6);
          compose(&(v1179_10),&(v1181_11))
        };
        drop(v1179_10);
        let v1179_13: Space = unite(&(v1179_8),&(v1179_12));
        v1178_7.join_into((v1179_13).clone());
      }
      drop(v1178_7_cursor);
      drop(v1178_6);
      compose(&(v1177_5),&(v1178_7))
    };
    drop(v1177_5);
    let v1177_9: Space = intersect(&(*CONSTANT_3),&(v1177_2));
    drop(v1177_2);
    let v1177_10: Space = if has_head(&(v1177_9)) { singleton(&[]) } else { Space::new() };
    drop(v1177_9);
    let v1177_13: Space = if (v1177_10).is_empty() { Space::new() } else {
      let v1182_11: Space = unwrap(&(v1176_11),&(v1176_18_head));
      let mut v1182_12 = Space::new();
      let mut v1182_12_cursor = (v1182_11).read_zipper();
      for v1182_12_byte in v1182_12_cursor.child_mask().iter() {
        v1182_12_cursor.descend_to_byte(v1182_12_byte);
        let v1182_12_tail = v1182_12_cursor.make_map();
        v1182_12_cursor.ascend(1);
        let v1182_12_head = Path::from_slice(&[v1182_12_byte]);
        let v1183_2: Space = singleton(&(v1182_12_head));
        let v1183_3: Space = intersect(&(*CONSTANT_3),&(v1183_2));
        let v1183_4: Space = if has_head(&(v1183_3)) { singleton(&[]) } else { Space::new() };
        drop(v1183_3);
        let v1183_5: Space = subtract(&(*CONSTANT_2),&(v1183_4));
        drop(v1183_4);
        let v1183_7: Space = if (v1183_5).is_empty() { Space::new() } else {
          let v1184_6: Space = routine_89(c, &(v1182_12_head), &(*p1), &(v1182_12_tail));
          compose(&(v1183_5),&(v1184_6))
        };
        drop(v1183_5);
        let v1183_8: Space = intersect(&(*CONSTANT_3),&(v1183_2));
        drop(v1183_2);
        let v1183_9: Space = if has_head(&(v1183_8)) { singleton(&[]) } else { Space::new() };
        drop(v1183_8);
        let v1183_11: Space = if (v1183_9).is_empty() { Space::new() } else {
          let v1185_10: Space = routine_90(c, &(v1182_12_head), &(*p1), &(v1182_12_tail));
          compose(&(v1183_9),&(v1185_10))
        };
        drop(v1183_9);
        let v1183_12: Space = unite(&(v1183_7),&(v1183_11));
        v1182_12.join_into((v1183_12).clone());
      }
      drop(v1182_12_cursor);
      drop(v1182_11);
      compose(&(v1177_10),&(v1182_12))
    };
    drop(v1177_10);
    let v1177_14: Space = unite(&(v1177_8),&(v1177_13));
    v1176_18.join_into((v1177_14).clone());
  }
  drop(v1176_18_cursor);
  drop(v1176_11);
  (v1176_18).clone()
}

fn routine_132(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1186_12 = Space::new();
  let mut v1186_12_cursor = (*s0).read_zipper();
  for v1186_12_byte in v1186_12_cursor.child_mask().iter() {
    v1186_12_cursor.descend_to_byte(v1186_12_byte);
    let v1186_12_tail = v1186_12_cursor.make_map();
    v1186_12_cursor.ascend(1);
    let v1186_12_head = Path::from_slice(&[v1186_12_byte]);
    let v1187_2: Space = singleton(&(v1186_12_head));
    let v1187_3: Space = intersect(&(*CONSTANT_3),&(v1187_2));
    let v1187_4: Space = if has_head(&(v1187_3)) { singleton(&[]) } else { Space::new() };
    drop(v1187_3);
    let v1187_5: Space = subtract(&(*CONSTANT_2),&(v1187_4));
    drop(v1187_4);
    let v1187_8: Space = if (v1187_5).is_empty() { Space::new() } else {
      let v1188_6: Path = concat_path(&(*p0),&(v1186_12_head));
      let mut v1188_7 = Space::new();
      let mut v1188_7_cursor = (v1186_12_tail).read_zipper();
      for v1188_7_byte in v1188_7_cursor.child_mask().iter() {
        v1188_7_cursor.descend_to_byte(v1188_7_byte);
        let v1188_7_tail = v1188_7_cursor.make_map();
        v1188_7_cursor.ascend(1);
        let v1188_7_head = Path::from_slice(&[v1188_7_byte]);
        let v1189_2: Space = singleton(&(v1188_7_head));
        let v1189_3: Space = intersect(&(*CONSTANT_3),&(v1189_2));
        let v1189_4: Space = if has_head(&(v1189_3)) { singleton(&[]) } else { Space::new() };
        drop(v1189_3);
        let v1189_5: Space = subtract(&(*CONSTANT_2),&(v1189_4));
        drop(v1189_4);
        let v1189_8: Space = if (v1189_5).is_empty() { Space::new() } else {
          let v1190_6: Path = concat_path(&(v1188_6),&(v1188_7_head));
          let v1190_7: Space = routine_164(c, &(v1190_6), &(*p1), &(v1188_7_tail));
          compose(&(v1189_5),&(v1190_7))
        };
        drop(v1189_5);
        let v1189_9: Space = intersect(&(*CONSTANT_3),&(v1189_2));
        drop(v1189_2);
        let v1189_10: Space = if has_head(&(v1189_9)) { singleton(&[]) } else { Space::new() };
        drop(v1189_9);
        let v1189_12: Space = if (v1189_10).is_empty() { Space::new() } else {
          let v1191_6: Path = concat_path(&(v1188_6),&(v1188_7_head));
          let v1191_11: Space = routine_165(c, &(v1191_6), &(*p1), &(v1188_7_tail));
          drop(v1191_6);
          compose(&(v1189_10),&(v1191_11))
        };
        drop(v1189_10);
        let v1189_13: Space = unite(&(v1189_8),&(v1189_12));
        v1188_7.join_into((v1189_13).clone());
      }
      drop(v1188_7_cursor);
      compose(&(v1187_5),&(v1188_7))
    };
    drop(v1187_5);
    let v1187_9: Space = intersect(&(*CONSTANT_3),&(v1187_2));
    drop(v1187_2);
    let v1187_10: Space = if has_head(&(v1187_9)) { singleton(&[]) } else { Space::new() };
    drop(v1187_9);
    let v1187_12: Space = if (v1187_10).is_empty() { Space::new() } else {
      let v1192_6: Path = concat_path(&(*p0),&(v1186_12_head));
      let mut v1192_11 = Space::new();
      let mut v1192_11_cursor = (v1186_12_tail).read_zipper();
      for v1192_11_byte in v1192_11_cursor.child_mask().iter() {
        v1192_11_cursor.descend_to_byte(v1192_11_byte);
        let v1192_11_tail = v1192_11_cursor.make_map();
        v1192_11_cursor.ascend(1);
        let v1192_11_head = Path::from_slice(&[v1192_11_byte]);
        let v1193_2: Space = singleton(&(v1192_11_head));
        let v1193_3: Space = intersect(&(*CONSTANT_3),&(v1193_2));
        let v1193_4: Space = if has_head(&(v1193_3)) { singleton(&[]) } else { Space::new() };
        drop(v1193_3);
        let v1193_5: Space = subtract(&(*CONSTANT_2),&(v1193_4));
        drop(v1193_4);
        let v1193_8: Space = if (v1193_5).is_empty() { Space::new() } else {
          let v1194_6: Path = concat_path(&(v1192_6),&(v1192_11_head));
          let v1194_7: Space = routine_164(c, &(v1194_6), &(*p1), &(v1192_11_tail));
          compose(&(v1193_5),&(v1194_7))
        };
        drop(v1193_5);
        let v1193_9: Space = intersect(&(*CONSTANT_3),&(v1193_2));
        drop(v1193_2);
        let v1193_10: Space = if has_head(&(v1193_9)) { singleton(&[]) } else { Space::new() };
        drop(v1193_9);
        let v1193_12: Space = if (v1193_10).is_empty() { Space::new() } else {
          let v1195_6: Path = concat_path(&(v1192_6),&(v1192_11_head));
          let v1195_11: Space = routine_95(c, &(v1195_6), &(*p1), &(v1192_11_tail));
          drop(v1195_6);
          compose(&(v1193_10),&(v1195_11))
        };
        drop(v1193_10);
        let v1193_13: Space = unite(&(v1193_8),&(v1193_12));
        v1192_11.join_into((v1193_13).clone());
      }
      drop(v1192_11_cursor);
      drop(v1192_6);
      compose(&(v1187_10),&(v1192_11))
    };
    drop(v1187_10);
    let v1187_13: Space = unite(&(v1187_8),&(v1187_12));
    v1186_12.join_into((v1187_13).clone());
  }
  drop(v1186_12_cursor);
  (v1186_12).clone()
}

fn routine_133(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1196_9 = Space::new();
  let mut v1196_9_cursor = (*s0).read_zipper();
  for v1196_9_byte in v1196_9_cursor.child_mask().iter() {
    v1196_9_cursor.descend_to_byte(v1196_9_byte);
    let v1196_9_tail = v1196_9_cursor.make_map();
    v1196_9_cursor.ascend(1);
    let v1196_9_head = Path::from_slice(&[v1196_9_byte]);
    let v1197_2: Space = singleton(&(v1196_9_head));
    let v1197_3: Space = intersect(&(*CONSTANT_3),&(v1197_2));
    let v1197_4: Space = if has_head(&(v1197_3)) { singleton(&[]) } else { Space::new() };
    drop(v1197_3);
    let v1197_5: Space = subtract(&(*CONSTANT_2),&(v1197_4));
    drop(v1197_4);
    let v1197_8: Space = if (v1197_5).is_empty() { Space::new() } else {
      let v1198_6: Path = concat_path(&(*p0),&(v1196_9_head));
      let mut v1198_7 = Space::new();
      let mut v1198_7_cursor = (v1196_9_tail).read_zipper();
      for v1198_7_byte in v1198_7_cursor.child_mask().iter() {
        v1198_7_cursor.descend_to_byte(v1198_7_byte);
        let v1198_7_tail = v1198_7_cursor.make_map();
        v1198_7_cursor.ascend(1);
        let v1198_7_head = Path::from_slice(&[v1198_7_byte]);
        let v1199_2: Space = singleton(&(v1198_7_head));
        let v1199_3: Space = intersect(&(*CONSTANT_3),&(v1199_2));
        let v1199_4: Space = if has_head(&(v1199_3)) { singleton(&[]) } else { Space::new() };
        drop(v1199_3);
        let v1199_5: Space = subtract(&(*CONSTANT_2),&(v1199_4));
        drop(v1199_4);
        let v1199_8: Space = if (v1199_5).is_empty() { Space::new() } else {
          let v1200_6: Path = concat_path(&(v1198_6),&(v1198_7_head));
          let v1200_7: Space = routine_164(c, &(v1200_6), &(*p1), &(v1198_7_tail));
          compose(&(v1199_5),&(v1200_7))
        };
        drop(v1199_5);
        let v1199_9: Space = intersect(&(*CONSTANT_3),&(v1199_2));
        drop(v1199_2);
        let v1199_10: Space = if has_head(&(v1199_9)) { singleton(&[]) } else { Space::new() };
        drop(v1199_9);
        let v1199_12: Space = if (v1199_10).is_empty() { Space::new() } else {
          let v1201_6: Path = concat_path(&(v1198_6),&(v1198_7_head));
          let v1201_11: Space = routine_165(c, &(v1201_6), &(*p1), &(v1198_7_tail));
          drop(v1201_6);
          compose(&(v1199_10),&(v1201_11))
        };
        drop(v1199_10);
        let v1199_13: Space = unite(&(v1199_8),&(v1199_12));
        v1198_7.join_into((v1199_13).clone());
      }
      drop(v1198_7_cursor);
      compose(&(v1197_5),&(v1198_7))
    };
    drop(v1197_5);
    let v1197_9: Space = intersect(&(*CONSTANT_3),&(v1197_2));
    drop(v1197_2);
    let v1197_10: Space = if has_head(&(v1197_9)) { singleton(&[]) } else { Space::new() };
    drop(v1197_9);
    let v1197_11: Space = compose(&(v1197_10),&(v1196_9_tail));
    drop(v1197_10);
    let v1202_6: Path = concat_path(&(*p0),&(v1196_9_head));
    let v1197_12: Space = wrap(&(v1197_11),&(v1202_6));
    drop(v1197_11);
    let v1197_13: Space = wrap(&(v1197_12),&(*p1));
    drop(v1197_12);
    let v1197_14: Space = unite(&(v1197_8),&(v1197_13));
    drop(v1197_13);
    v1196_9.join_into((v1197_14).clone());
  }
  drop(v1196_9_cursor);
  (v1196_9).clone()
}

fn routine_134(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1203_13 = Space::new();
  let mut v1203_13_cursor = (*s0).read_zipper();
  for v1203_13_byte in v1203_13_cursor.child_mask().iter() {
    v1203_13_cursor.descend_to_byte(v1203_13_byte);
    let v1203_13_tail = v1203_13_cursor.make_map();
    v1203_13_cursor.ascend(1);
    let v1203_13_head = Path::from_slice(&[v1203_13_byte]);
    let v1204_2: Space = singleton(&(v1203_13_head));
    let v1204_3: Space = intersect(&(*CONSTANT_3),&(v1204_2));
    let v1204_4: Space = if has_head(&(v1204_3)) { singleton(&[]) } else { Space::new() };
    drop(v1204_3);
    let v1204_5: Space = subtract(&(*CONSTANT_2),&(v1204_4));
    drop(v1204_4);
    let v1204_8: Space = if (v1204_5).is_empty() { Space::new() } else {
      let v1205_6: Path = concat_path(&(*p0),&(v1203_13_head));
      let mut v1205_7 = Space::new();
      let mut v1205_7_cursor = (v1203_13_tail).read_zipper();
      for v1205_7_byte in v1205_7_cursor.child_mask().iter() {
        v1205_7_cursor.descend_to_byte(v1205_7_byte);
        let v1205_7_tail = v1205_7_cursor.make_map();
        v1205_7_cursor.ascend(1);
        let v1205_7_head = Path::from_slice(&[v1205_7_byte]);
        let v1206_2: Space = singleton(&(v1205_7_head));
        let v1206_3: Space = intersect(&(*CONSTANT_3),&(v1206_2));
        let v1206_4: Space = if has_head(&(v1206_3)) { singleton(&[]) } else { Space::new() };
        drop(v1206_3);
        let v1206_5: Space = subtract(&(*CONSTANT_2),&(v1206_4));
        drop(v1206_4);
        let v1206_8: Space = if (v1206_5).is_empty() { Space::new() } else {
          let v1207_6: Path = concat_path(&(v1205_6),&(v1205_7_head));
          let v1207_7: Space = routine_166(c, &(v1207_6), &(*p1), &(v1205_7_tail), &(*s1));
          compose(&(v1206_5),&(v1207_7))
        };
        drop(v1206_5);
        let v1206_9: Space = intersect(&(*CONSTANT_3),&(v1206_2));
        drop(v1206_2);
        let v1206_10: Space = if has_head(&(v1206_9)) { singleton(&[]) } else { Space::new() };
        drop(v1206_9);
        let v1206_12: Space = if (v1206_10).is_empty() { Space::new() } else {
          let v1208_6: Path = concat_path(&(v1205_6),&(v1205_7_head));
          let v1208_11: Space = routine_167(c, &(v1208_6), &(*p1), &(v1205_7_tail), &(*s1));
          drop(v1208_6);
          compose(&(v1206_10),&(v1208_11))
        };
        drop(v1206_10);
        let v1206_13: Space = unite(&(v1206_8),&(v1206_12));
        v1205_7.join_into((v1206_13).clone());
      }
      drop(v1205_7_cursor);
      compose(&(v1204_5),&(v1205_7))
    };
    drop(v1204_5);
    let v1204_9: Space = intersect(&(*CONSTANT_3),&(v1204_2));
    drop(v1204_2);
    let v1204_10: Space = if has_head(&(v1204_9)) { singleton(&[]) } else { Space::new() };
    drop(v1204_9);
    let v1204_12: Space = if (v1204_10).is_empty() { Space::new() } else {
      let v1209_6: Path = concat_path(&(*p0),&(v1203_13_head));
      let mut v1209_11 = Space::new();
      let mut v1209_11_cursor = (v1203_13_tail).read_zipper();
      for v1209_11_byte in v1209_11_cursor.child_mask().iter() {
        v1209_11_cursor.descend_to_byte(v1209_11_byte);
        let v1209_11_tail = v1209_11_cursor.make_map();
        v1209_11_cursor.ascend(1);
        let v1209_11_head = Path::from_slice(&[v1209_11_byte]);
        let v1210_2: Space = singleton(&(v1209_11_head));
        let v1210_3: Space = intersect(&(*CONSTANT_3),&(v1210_2));
        let v1210_4: Space = if has_head(&(v1210_3)) { singleton(&[]) } else { Space::new() };
        drop(v1210_3);
        let v1210_5: Space = subtract(&(*CONSTANT_2),&(v1210_4));
        drop(v1210_4);
        let v1210_8: Space = if (v1210_5).is_empty() { Space::new() } else {
          let v1211_6: Path = concat_path(&(v1209_6),&(v1209_11_head));
          let v1211_7: Space = routine_166(c, &(v1211_6), &(*p1), &(v1209_11_tail), &(*s1));
          compose(&(v1210_5),&(v1211_7))
        };
        drop(v1210_5);
        let v1210_9: Space = intersect(&(*CONSTANT_3),&(v1210_2));
        drop(v1210_2);
        let v1210_10: Space = if has_head(&(v1210_9)) { singleton(&[]) } else { Space::new() };
        drop(v1210_9);
        let v1210_12: Space = if (v1210_10).is_empty() { Space::new() } else {
          let v1212_6: Path = concat_path(&(v1209_6),&(v1209_11_head));
          let v1212_11: Space = routine_50(c, &(v1212_6), &(*p1), &(v1209_11_tail), &(*s1));
          drop(v1212_6);
          compose(&(v1210_10),&(v1212_11))
        };
        drop(v1210_10);
        let v1210_13: Space = unite(&(v1210_8),&(v1210_12));
        v1209_11.join_into((v1210_13).clone());
      }
      drop(v1209_11_cursor);
      drop(v1209_6);
      compose(&(v1204_10),&(v1209_11))
    };
    drop(v1204_10);
    let v1204_13: Space = unite(&(v1204_8),&(v1204_12));
    v1203_13.join_into((v1204_13).clone());
  }
  drop(v1203_13_cursor);
  (v1203_13).clone()
}

fn routine_135(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1213_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v1213_10: Space = unwrap(&(v1213_8),&(*CONSTANT_5));
  drop(v1213_8);
  let v1213_11: Space = unwrap(&(v1213_10),&(*p0));
  drop(v1213_10);
  let mut v1213_18 = Space::new();
  let mut v1213_18_cursor = (*s0).read_zipper();
  for v1213_18_byte in v1213_18_cursor.child_mask().iter() {
    v1213_18_cursor.descend_to_byte(v1213_18_byte);
    let v1213_18_tail = v1213_18_cursor.make_map();
    v1213_18_cursor.ascend(1);
    let v1213_18_head = Path::from_slice(&[v1213_18_byte]);
    let v1214_2: Space = singleton(&(v1213_18_head));
    let v1214_3: Space = intersect(&(*CONSTANT_3),&(v1214_2));
    let v1214_4: Space = if has_head(&(v1214_3)) { singleton(&[]) } else { Space::new() };
    drop(v1214_3);
    let v1214_5: Space = subtract(&(*CONSTANT_2),&(v1214_4));
    drop(v1214_4);
    let v1214_8: Space = if (v1214_5).is_empty() { Space::new() } else {
      let v1215_6: Path = concat_path(&(*p0),&(v1213_18_head));
      let mut v1215_7 = Space::new();
      let mut v1215_7_cursor = (v1213_18_tail).read_zipper();
      for v1215_7_byte in v1215_7_cursor.child_mask().iter() {
        v1215_7_cursor.descend_to_byte(v1215_7_byte);
        let v1215_7_tail = v1215_7_cursor.make_map();
        v1215_7_cursor.ascend(1);
        let v1215_7_head = Path::from_slice(&[v1215_7_byte]);
        let v1216_2: Space = singleton(&(v1215_7_head));
        let v1216_3: Space = intersect(&(*CONSTANT_3),&(v1216_2));
        let v1216_4: Space = if has_head(&(v1216_3)) { singleton(&[]) } else { Space::new() };
        drop(v1216_3);
        let v1216_5: Space = subtract(&(*CONSTANT_2),&(v1216_4));
        drop(v1216_4);
        let v1216_8: Space = if (v1216_5).is_empty() { Space::new() } else {
          let v1217_6: Path = concat_path(&(v1215_6),&(v1215_7_head));
          let v1217_7: Space = routine_166(c, &(v1217_6), &(*p1), &(v1215_7_tail), &(*s1));
          compose(&(v1216_5),&(v1217_7))
        };
        drop(v1216_5);
        let v1216_9: Space = intersect(&(*CONSTANT_3),&(v1216_2));
        drop(v1216_2);
        let v1216_10: Space = if has_head(&(v1216_9)) { singleton(&[]) } else { Space::new() };
        drop(v1216_9);
        let v1216_12: Space = if (v1216_10).is_empty() { Space::new() } else {
          let v1218_6: Path = concat_path(&(v1215_6),&(v1215_7_head));
          let v1218_11: Space = routine_167(c, &(v1218_6), &(*p1), &(v1215_7_tail), &(*s1));
          drop(v1218_6);
          compose(&(v1216_10),&(v1218_11))
        };
        drop(v1216_10);
        let v1216_13: Space = unite(&(v1216_8),&(v1216_12));
        v1215_7.join_into((v1216_13).clone());
      }
      drop(v1215_7_cursor);
      drop(v1215_6);
      compose(&(v1214_5),&(v1215_7))
    };
    drop(v1214_5);
    let v1214_9: Space = intersect(&(*CONSTANT_3),&(v1214_2));
    drop(v1214_2);
    let v1214_10: Space = if has_head(&(v1214_9)) { singleton(&[]) } else { Space::new() };
    drop(v1214_9);
    let v1214_13: Space = if (v1214_10).is_empty() { Space::new() } else {
      let v1219_11: Space = unwrap(&(v1213_11),&(v1213_18_head));
      let mut v1219_12 = Space::new();
      let mut v1219_12_cursor = (v1219_11).read_zipper();
      for v1219_12_byte in v1219_12_cursor.child_mask().iter() {
        v1219_12_cursor.descend_to_byte(v1219_12_byte);
        let v1219_12_tail = v1219_12_cursor.make_map();
        v1219_12_cursor.ascend(1);
        let v1219_12_head = Path::from_slice(&[v1219_12_byte]);
        let v1220_2: Space = singleton(&(v1219_12_head));
        let v1220_3: Space = intersect(&(*CONSTANT_3),&(v1220_2));
        let v1220_4: Space = if has_head(&(v1220_3)) { singleton(&[]) } else { Space::new() };
        drop(v1220_3);
        let v1220_5: Space = subtract(&(*CONSTANT_2),&(v1220_4));
        drop(v1220_4);
        let v1220_7: Space = if (v1220_5).is_empty() { Space::new() } else {
          let v1221_6: Space = routine_89(c, &(v1219_12_head), &(*p1), &(v1219_12_tail));
          compose(&(v1220_5),&(v1221_6))
        };
        drop(v1220_5);
        let v1220_8: Space = intersect(&(*CONSTANT_3),&(v1220_2));
        drop(v1220_2);
        let v1220_9: Space = if has_head(&(v1220_8)) { singleton(&[]) } else { Space::new() };
        drop(v1220_8);
        let v1220_11: Space = if (v1220_9).is_empty() { Space::new() } else {
          let v1222_10: Space = routine_90(c, &(v1219_12_head), &(*p1), &(v1219_12_tail));
          compose(&(v1220_9),&(v1222_10))
        };
        drop(v1220_9);
        let v1220_12: Space = unite(&(v1220_7),&(v1220_11));
        v1219_12.join_into((v1220_12).clone());
      }
      drop(v1219_12_cursor);
      drop(v1219_11);
      compose(&(v1214_10),&(v1219_12))
    };
    drop(v1214_10);
    let v1214_14: Space = unite(&(v1214_8),&(v1214_13));
    v1213_18.join_into((v1214_14).clone());
  }
  drop(v1213_18_cursor);
  drop(v1213_11);
  (v1213_18).clone()
}

fn routine_136(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1223_12 = Space::new();
  let mut v1223_12_cursor = (*s0).read_zipper();
  for v1223_12_byte in v1223_12_cursor.child_mask().iter() {
    v1223_12_cursor.descend_to_byte(v1223_12_byte);
    let v1223_12_tail = v1223_12_cursor.make_map();
    v1223_12_cursor.ascend(1);
    let v1223_12_head = Path::from_slice(&[v1223_12_byte]);
    let v1224_2: Space = singleton(&(v1223_12_head));
    let v1224_3: Space = intersect(&(*CONSTANT_3),&(v1224_2));
    let v1224_4: Space = if has_head(&(v1224_3)) { singleton(&[]) } else { Space::new() };
    drop(v1224_3);
    let v1224_5: Space = subtract(&(*CONSTANT_2),&(v1224_4));
    drop(v1224_4);
    let v1224_8: Space = if (v1224_5).is_empty() { Space::new() } else {
      let v1225_6: Path = concat_path(&(*p0),&(v1223_12_head));
      let mut v1225_7 = Space::new();
      let mut v1225_7_cursor = (v1223_12_tail).read_zipper();
      for v1225_7_byte in v1225_7_cursor.child_mask().iter() {
        v1225_7_cursor.descend_to_byte(v1225_7_byte);
        let v1225_7_tail = v1225_7_cursor.make_map();
        v1225_7_cursor.ascend(1);
        let v1225_7_head = Path::from_slice(&[v1225_7_byte]);
        let v1226_2: Space = singleton(&(v1225_7_head));
        let v1226_3: Space = intersect(&(*CONSTANT_3),&(v1226_2));
        let v1226_4: Space = if has_head(&(v1226_3)) { singleton(&[]) } else { Space::new() };
        drop(v1226_3);
        let v1226_5: Space = subtract(&(*CONSTANT_2),&(v1226_4));
        drop(v1226_4);
        let v1226_8: Space = if (v1226_5).is_empty() { Space::new() } else {
          let v1227_6: Path = concat_path(&(v1225_6),&(v1225_7_head));
          let v1227_7: Space = routine_168(c, &(v1227_6), &(*p1), &(v1225_7_tail));
          compose(&(v1226_5),&(v1227_7))
        };
        drop(v1226_5);
        let v1226_9: Space = intersect(&(*CONSTANT_3),&(v1226_2));
        drop(v1226_2);
        let v1226_10: Space = if has_head(&(v1226_9)) { singleton(&[]) } else { Space::new() };
        drop(v1226_9);
        let v1226_12: Space = if (v1226_10).is_empty() { Space::new() } else {
          let v1228_6: Path = concat_path(&(v1225_6),&(v1225_7_head));
          let v1228_11: Space = routine_169(c, &(v1228_6), &(*p1), &(v1225_7_tail));
          drop(v1228_6);
          compose(&(v1226_10),&(v1228_11))
        };
        drop(v1226_10);
        let v1226_13: Space = unite(&(v1226_8),&(v1226_12));
        v1225_7.join_into((v1226_13).clone());
      }
      drop(v1225_7_cursor);
      compose(&(v1224_5),&(v1225_7))
    };
    drop(v1224_5);
    let v1224_9: Space = intersect(&(*CONSTANT_3),&(v1224_2));
    drop(v1224_2);
    let v1224_10: Space = if has_head(&(v1224_9)) { singleton(&[]) } else { Space::new() };
    drop(v1224_9);
    let v1224_12: Space = if (v1224_10).is_empty() { Space::new() } else {
      let v1229_6: Path = concat_path(&(*p0),&(v1223_12_head));
      let mut v1229_11 = Space::new();
      let mut v1229_11_cursor = (v1223_12_tail).read_zipper();
      for v1229_11_byte in v1229_11_cursor.child_mask().iter() {
        v1229_11_cursor.descend_to_byte(v1229_11_byte);
        let v1229_11_tail = v1229_11_cursor.make_map();
        v1229_11_cursor.ascend(1);
        let v1229_11_head = Path::from_slice(&[v1229_11_byte]);
        let v1230_2: Space = singleton(&(v1229_11_head));
        let v1230_3: Space = intersect(&(*CONSTANT_3),&(v1230_2));
        let v1230_4: Space = if has_head(&(v1230_3)) { singleton(&[]) } else { Space::new() };
        drop(v1230_3);
        let v1230_5: Space = subtract(&(*CONSTANT_2),&(v1230_4));
        drop(v1230_4);
        let v1230_8: Space = if (v1230_5).is_empty() { Space::new() } else {
          let v1231_6: Path = concat_path(&(v1229_6),&(v1229_11_head));
          let v1231_7: Space = routine_168(c, &(v1231_6), &(*p1), &(v1229_11_tail));
          compose(&(v1230_5),&(v1231_7))
        };
        drop(v1230_5);
        let v1230_9: Space = intersect(&(*CONSTANT_3),&(v1230_2));
        drop(v1230_2);
        let v1230_10: Space = if has_head(&(v1230_9)) { singleton(&[]) } else { Space::new() };
        drop(v1230_9);
        let v1230_12: Space = if (v1230_10).is_empty() { Space::new() } else {
          let v1232_6: Path = concat_path(&(v1229_6),&(v1229_11_head));
          let v1232_11: Space = routine_95(c, &(v1232_6), &(*p1), &(v1229_11_tail));
          drop(v1232_6);
          compose(&(v1230_10),&(v1232_11))
        };
        drop(v1230_10);
        let v1230_13: Space = unite(&(v1230_8),&(v1230_12));
        v1229_11.join_into((v1230_13).clone());
      }
      drop(v1229_11_cursor);
      drop(v1229_6);
      compose(&(v1224_10),&(v1229_11))
    };
    drop(v1224_10);
    let v1224_13: Space = unite(&(v1224_8),&(v1224_12));
    v1223_12.join_into((v1224_13).clone());
  }
  drop(v1223_12_cursor);
  (v1223_12).clone()
}

fn routine_137(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1233_9 = Space::new();
  let mut v1233_9_cursor = (*s0).read_zipper();
  for v1233_9_byte in v1233_9_cursor.child_mask().iter() {
    v1233_9_cursor.descend_to_byte(v1233_9_byte);
    let v1233_9_tail = v1233_9_cursor.make_map();
    v1233_9_cursor.ascend(1);
    let v1233_9_head = Path::from_slice(&[v1233_9_byte]);
    let v1234_2: Space = singleton(&(v1233_9_head));
    let v1234_3: Space = intersect(&(*CONSTANT_3),&(v1234_2));
    let v1234_4: Space = if has_head(&(v1234_3)) { singleton(&[]) } else { Space::new() };
    drop(v1234_3);
    let v1234_5: Space = subtract(&(*CONSTANT_2),&(v1234_4));
    drop(v1234_4);
    let v1234_8: Space = if (v1234_5).is_empty() { Space::new() } else {
      let v1235_6: Path = concat_path(&(*p0),&(v1233_9_head));
      let mut v1235_7 = Space::new();
      let mut v1235_7_cursor = (v1233_9_tail).read_zipper();
      for v1235_7_byte in v1235_7_cursor.child_mask().iter() {
        v1235_7_cursor.descend_to_byte(v1235_7_byte);
        let v1235_7_tail = v1235_7_cursor.make_map();
        v1235_7_cursor.ascend(1);
        let v1235_7_head = Path::from_slice(&[v1235_7_byte]);
        let v1236_2: Space = singleton(&(v1235_7_head));
        let v1236_3: Space = intersect(&(*CONSTANT_3),&(v1236_2));
        let v1236_4: Space = if has_head(&(v1236_3)) { singleton(&[]) } else { Space::new() };
        drop(v1236_3);
        let v1236_5: Space = subtract(&(*CONSTANT_2),&(v1236_4));
        drop(v1236_4);
        let v1236_8: Space = if (v1236_5).is_empty() { Space::new() } else {
          let v1237_6: Path = concat_path(&(v1235_6),&(v1235_7_head));
          let v1237_7: Space = routine_168(c, &(v1237_6), &(*p1), &(v1235_7_tail));
          compose(&(v1236_5),&(v1237_7))
        };
        drop(v1236_5);
        let v1236_9: Space = intersect(&(*CONSTANT_3),&(v1236_2));
        drop(v1236_2);
        let v1236_10: Space = if has_head(&(v1236_9)) { singleton(&[]) } else { Space::new() };
        drop(v1236_9);
        let v1236_12: Space = if (v1236_10).is_empty() { Space::new() } else {
          let v1238_6: Path = concat_path(&(v1235_6),&(v1235_7_head));
          let v1238_11: Space = routine_169(c, &(v1238_6), &(*p1), &(v1235_7_tail));
          drop(v1238_6);
          compose(&(v1236_10),&(v1238_11))
        };
        drop(v1236_10);
        let v1236_13: Space = unite(&(v1236_8),&(v1236_12));
        v1235_7.join_into((v1236_13).clone());
      }
      drop(v1235_7_cursor);
      compose(&(v1234_5),&(v1235_7))
    };
    drop(v1234_5);
    let v1234_9: Space = intersect(&(*CONSTANT_3),&(v1234_2));
    drop(v1234_2);
    let v1234_10: Space = if has_head(&(v1234_9)) { singleton(&[]) } else { Space::new() };
    drop(v1234_9);
    let v1234_11: Space = compose(&(v1234_10),&(v1233_9_tail));
    drop(v1234_10);
    let v1239_6: Path = concat_path(&(*p0),&(v1233_9_head));
    let v1234_12: Space = wrap(&(v1234_11),&(v1239_6));
    drop(v1234_11);
    let v1234_13: Space = wrap(&(v1234_12),&(*p1));
    drop(v1234_12);
    let v1234_14: Space = unite(&(v1234_8),&(v1234_13));
    drop(v1234_13);
    v1233_9.join_into((v1234_14).clone());
  }
  drop(v1233_9_cursor);
  (v1233_9).clone()
}

fn routine_138(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1240_7 = Space::new();
  let mut v1240_7_cursor = (*s0).read_zipper();
  for v1240_7_byte in v1240_7_cursor.child_mask().iter() {
    v1240_7_cursor.descend_to_byte(v1240_7_byte);
    let v1240_7_tail = v1240_7_cursor.make_map();
    v1240_7_cursor.ascend(1);
    let v1240_7_head = Path::from_slice(&[v1240_7_byte]);
    let v1241_2: Space = singleton(&(v1240_7_head));
    let v1241_3: Space = intersect(&(*CONSTANT_3),&(v1241_2));
    let v1241_4: Space = if has_head(&(v1241_3)) { singleton(&[]) } else { Space::new() };
    drop(v1241_3);
    let v1241_5: Space = subtract(&(*CONSTANT_2),&(v1241_4));
    drop(v1241_4);
    let mut v1241_6 = Space::new();
    let mut v1241_6_cursor = (v1240_7_tail).read_zipper();
    for v1241_6_byte in v1241_6_cursor.child_mask().iter() {
      v1241_6_cursor.descend_to_byte(v1241_6_byte);
      let v1241_6_tail = v1241_6_cursor.make_map();
      v1241_6_cursor.ascend(1);
      let v1241_6_head = Path::from_slice(&[v1241_6_byte]);
      let v1242_2: Space = Space::new();
      v1241_6.join_into((v1242_2).clone());
    }
    drop(v1241_6_cursor);
    let v1241_7: Space = compose(&(v1241_5),&(v1241_6));
    drop(v1241_5);
    drop(v1241_6);
    let v1241_8: Space = intersect(&(*CONSTANT_3),&(v1241_2));
    drop(v1241_2);
    let v1241_9: Space = if has_head(&(v1241_8)) { singleton(&[]) } else { Space::new() };
    drop(v1241_8);
    let v1241_12: Space = if (v1241_9).is_empty() { Space::new() } else {
      let v1243_10: Path = concat_path(&(*p0),&(v1240_7_head));
      let mut v1243_11 = Space::new();
      let mut v1243_11_cursor = (v1240_7_tail).read_zipper();
      for v1243_11_byte in v1243_11_cursor.child_mask().iter() {
        v1243_11_cursor.descend_to_byte(v1243_11_byte);
        let v1243_11_tail = v1243_11_cursor.make_map();
        v1243_11_cursor.ascend(1);
        let v1243_11_head = Path::from_slice(&[v1243_11_byte]);
        let v1244_2: Space = singleton(&(v1243_11_head));
        let v1244_3: Space = intersect(&(*CONSTANT_3),&(v1244_2));
        drop(v1244_2);
        let v1244_4: Space = if has_head(&(v1244_3)) { singleton(&[]) } else { Space::new() };
        drop(v1244_3);
        let v1244_7: Space = if (v1244_4).is_empty() { Space::new() } else {
          let v1245_5: Path = concat_path(&(v1243_10),&(v1243_11_head));
          let v1245_6: Space = routine_22(c, &(v1245_5), &(*p1), &(v1243_11_tail));
          drop(v1245_5);
          compose(&(v1244_4),&(v1245_6))
        };
        drop(v1244_4);
        v1243_11.join_into((v1244_7).clone());
      }
      drop(v1243_11_cursor);
      drop(v1243_10);
      compose(&(v1241_9),&(v1243_11))
    };
    drop(v1241_9);
    let v1241_13: Space = unite(&(v1241_7),&(v1241_12));
    drop(v1241_7);
    v1240_7.join_into((v1241_13).clone());
  }
  drop(v1240_7_cursor);
  (v1240_7).clone()
}

fn routine_139(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1246_7 = Space::new();
  let mut v1246_7_cursor = (*s0).read_zipper();
  for v1246_7_byte in v1246_7_cursor.child_mask().iter() {
    v1246_7_cursor.descend_to_byte(v1246_7_byte);
    let v1246_7_tail = v1246_7_cursor.make_map();
    v1246_7_cursor.ascend(1);
    let v1246_7_head = Path::from_slice(&[v1246_7_byte]);
    let v1247_2: Space = singleton(&(v1246_7_head));
    let v1247_3: Space = intersect(&(*CONSTANT_3),&(v1247_2));
    let v1247_4: Space = if has_head(&(v1247_3)) { singleton(&[]) } else { Space::new() };
    drop(v1247_3);
    let v1247_5: Space = compose(&(v1247_4),&(v1246_7_tail));
    drop(v1247_4);
    let v1247_6: Path = concat_path(&(*p0),&(v1246_7_head));
    let v1247_7: Space = wrap(&(v1247_5),&(v1247_6));
    drop(v1247_5);
    drop(v1247_6);
    let v1247_8: Space = wrap(&(v1247_7),&(*p1));
    drop(v1247_7);
    let v1247_9: Space = wrap(&(v1247_8),&(*CONSTANT_5));
    drop(v1247_8);
    let v1247_10: Space = intersect(&(*CONSTANT_3),&(v1247_2));
    drop(v1247_2);
    let v1247_11: Space = if has_head(&(v1247_10)) { singleton(&[]) } else { Space::new() };
    drop(v1247_10);
    let v1247_12: Space = subtract(&(*CONSTANT_2),&(v1247_11));
    drop(v1247_11);
    let mut v1247_13 = Space::new();
    let mut v1247_13_cursor = (v1246_7_tail).read_zipper();
    for v1247_13_byte in v1247_13_cursor.child_mask().iter() {
      v1247_13_cursor.descend_to_byte(v1247_13_byte);
      let v1247_13_tail = v1247_13_cursor.make_map();
      v1247_13_cursor.ascend(1);
      let v1247_13_head = Path::from_slice(&[v1247_13_byte]);
      let v1248_2: Space = Space::new();
      v1247_13.join_into((v1248_2).clone());
    }
    drop(v1247_13_cursor);
    let v1247_14: Space = compose(&(v1247_12),&(v1247_13));
    drop(v1247_12);
    drop(v1247_13);
    let v1247_15: Space = unite(&(v1247_9),&(v1247_14));
    drop(v1247_9);
    drop(v1247_14);
    v1246_7.join_into((v1247_15).clone());
  }
  drop(v1246_7_cursor);
  (v1246_7).clone()
}

fn routine_140(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1249_3 = Space::new();
  let mut v1249_3_cursor = (*s0).read_zipper();
  for v1249_3_byte in v1249_3_cursor.child_mask().iter() {
    v1249_3_cursor.descend_to_byte(v1249_3_byte);
    let v1249_3_tail = v1249_3_cursor.make_map();
    v1249_3_cursor.ascend(1);
    let v1249_3_head = Path::from_slice(&[v1249_3_byte]);
    let v1250_2: Space = Space::new();
    v1249_3.join_into((v1250_2).clone());
  }
  drop(v1249_3_cursor);
  (v1249_3).clone()
}

fn routine_141(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1251_4 = Space::new();
  let mut v1251_4_cursor = (*s0).read_zipper();
  for v1251_4_byte in v1251_4_cursor.child_mask().iter() {
    v1251_4_cursor.descend_to_byte(v1251_4_byte);
    let v1251_4_tail = v1251_4_cursor.make_map();
    v1251_4_cursor.ascend(1);
    let v1251_4_head = Path::from_slice(&[v1251_4_byte]);
    let v1252_2: Space = singleton(&(v1251_4_head));
    let v1252_3: Space = intersect(&(*CONSTANT_3),&(v1252_2));
    drop(v1252_2);
    let v1252_4: Space = if has_head(&(v1252_3)) { singleton(&[]) } else { Space::new() };
    drop(v1252_3);
    let v1252_5: Space = compose(&(v1252_4),&(v1251_4_tail));
    drop(v1252_4);
    let v1252_6: Path = concat_path(&(*p0),&(v1251_4_head));
    let v1252_7: Space = wrap(&(v1252_5),&(v1252_6));
    drop(v1252_5);
    drop(v1252_6);
    v1251_4.join_into((v1252_7).clone());
  }
  drop(v1251_4_cursor);
  let v1251_5: Space = wrap(&(v1251_4),&(*p1));
  drop(v1251_4);
  let v1251_7: Space = wrap(&(v1251_5),&(*CONSTANT_5));
  drop(v1251_5);
  (v1251_7).clone()
}

fn routine_142(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1253_8 = Space::new();
  let mut v1253_8_cursor = (*s0).read_zipper();
  for v1253_8_byte in v1253_8_cursor.child_mask().iter() {
    v1253_8_cursor.descend_to_byte(v1253_8_byte);
    let v1253_8_tail = v1253_8_cursor.make_map();
    v1253_8_cursor.ascend(1);
    let v1253_8_head = Path::from_slice(&[v1253_8_byte]);
    let v1254_2: Space = singleton(&(v1253_8_head));
    let v1254_3: Space = intersect(&(*CONSTANT_3),&(v1254_2));
    let v1254_4: Space = if has_head(&(v1254_3)) { singleton(&[]) } else { Space::new() };
    drop(v1254_3);
    let v1254_5: Space = subtract(&(*CONSTANT_2),&(v1254_4));
    drop(v1254_4);
    let mut v1254_6 = Space::new();
    let mut v1254_6_cursor = (v1253_8_tail).read_zipper();
    for v1254_6_byte in v1254_6_cursor.child_mask().iter() {
      v1254_6_cursor.descend_to_byte(v1254_6_byte);
      let v1254_6_tail = v1254_6_cursor.make_map();
      v1254_6_cursor.ascend(1);
      let v1254_6_head = Path::from_slice(&[v1254_6_byte]);
      let v1255_2: Space = Space::new();
      v1254_6.join_into((v1255_2).clone());
    }
    drop(v1254_6_cursor);
    let v1254_7: Space = compose(&(v1254_5),&(v1254_6));
    drop(v1254_5);
    drop(v1254_6);
    let v1254_8: Space = intersect(&(*CONSTANT_3),&(v1254_2));
    drop(v1254_2);
    let v1254_9: Space = if has_head(&(v1254_8)) { singleton(&[]) } else { Space::new() };
    drop(v1254_8);
    let v1254_12: Space = if (v1254_9).is_empty() { Space::new() } else {
      let v1256_10: Path = concat_path(&(*p0),&(v1253_8_head));
      let mut v1256_11 = Space::new();
      let mut v1256_11_cursor = (v1253_8_tail).read_zipper();
      for v1256_11_byte in v1256_11_cursor.child_mask().iter() {
        v1256_11_cursor.descend_to_byte(v1256_11_byte);
        let v1256_11_tail = v1256_11_cursor.make_map();
        v1256_11_cursor.ascend(1);
        let v1256_11_head = Path::from_slice(&[v1256_11_byte]);
        let v1257_2: Space = singleton(&(v1256_11_head));
        let v1257_3: Space = intersect(&(*CONSTANT_3),&(v1257_2));
        drop(v1257_2);
        let v1257_4: Space = if has_head(&(v1257_3)) { singleton(&[]) } else { Space::new() };
        drop(v1257_3);
        let v1257_7: Space = if (v1257_4).is_empty() { Space::new() } else {
          let v1258_5: Path = concat_path(&(v1256_10),&(v1256_11_head));
          let v1258_6: Space = routine_29(c, &(v1258_5), &(*p1), &(v1256_11_tail), &(*s1));
          drop(v1258_5);
          compose(&(v1257_4),&(v1258_6))
        };
        drop(v1257_4);
        v1256_11.join_into((v1257_7).clone());
      }
      drop(v1256_11_cursor);
      drop(v1256_10);
      compose(&(v1254_9),&(v1256_11))
    };
    drop(v1254_9);
    let v1254_13: Space = unite(&(v1254_7),&(v1254_12));
    drop(v1254_7);
    v1253_8.join_into((v1254_13).clone());
  }
  drop(v1253_8_cursor);
  (v1253_8).clone()
}

fn routine_143(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1259_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v1259_10: Space = unwrap(&(v1259_8),&(*CONSTANT_5));
  drop(v1259_8);
  let v1259_11: Space = unwrap(&(v1259_10),&(*p0));
  drop(v1259_10);
  let mut v1259_15 = Space::new();
  let mut v1259_15_cursor = (*s0).read_zipper();
  for v1259_15_byte in v1259_15_cursor.child_mask().iter() {
    v1259_15_cursor.descend_to_byte(v1259_15_byte);
    let v1259_15_tail = v1259_15_cursor.make_map();
    v1259_15_cursor.ascend(1);
    let v1259_15_head = Path::from_slice(&[v1259_15_byte]);
    let v1260_2: Space = singleton(&(v1259_15_head));
    let v1260_3: Space = intersect(&(*CONSTANT_3),&(v1260_2));
    let v1260_4: Space = if has_head(&(v1260_3)) { singleton(&[]) } else { Space::new() };
    drop(v1260_3);
    let v1260_5: Space = subtract(&(*CONSTANT_2),&(v1260_4));
    drop(v1260_4);
    let mut v1260_6 = Space::new();
    let mut v1260_6_cursor = (v1259_15_tail).read_zipper();
    for v1260_6_byte in v1260_6_cursor.child_mask().iter() {
      v1260_6_cursor.descend_to_byte(v1260_6_byte);
      let v1260_6_tail = v1260_6_cursor.make_map();
      v1260_6_cursor.ascend(1);
      let v1260_6_head = Path::from_slice(&[v1260_6_byte]);
      let v1261_2: Space = Space::new();
      v1260_6.join_into((v1261_2).clone());
    }
    drop(v1260_6_cursor);
    let v1260_7: Space = compose(&(v1260_5),&(v1260_6));
    drop(v1260_5);
    drop(v1260_6);
    let v1260_8: Space = intersect(&(*CONSTANT_3),&(v1260_2));
    drop(v1260_2);
    let v1260_9: Space = if has_head(&(v1260_8)) { singleton(&[]) } else { Space::new() };
    drop(v1260_8);
    let v1260_12: Space = if (v1260_9).is_empty() { Space::new() } else {
      let v1262_10: Space = unwrap(&(v1259_11),&(v1259_15_head));
      let mut v1262_11 = Space::new();
      let mut v1262_11_cursor = (v1262_10).read_zipper();
      for v1262_11_byte in v1262_11_cursor.child_mask().iter() {
        v1262_11_cursor.descend_to_byte(v1262_11_byte);
        let v1262_11_tail = v1262_11_cursor.make_map();
        v1262_11_cursor.ascend(1);
        let v1262_11_head = Path::from_slice(&[v1262_11_byte]);
        let v1263_2: Space = singleton(&(v1262_11_head));
        let v1263_3: Space = intersect(&(*CONSTANT_3),&(v1263_2));
        let v1263_4: Space = if has_head(&(v1263_3)) { singleton(&[]) } else { Space::new() };
        drop(v1263_3);
        let v1263_5: Space = subtract(&(*CONSTANT_2),&(v1263_4));
        drop(v1263_4);
        let v1263_7: Space = if (v1263_5).is_empty() { Space::new() } else {
          let v1264_6: Space = routine_61(c, &(v1262_11_head), &(*p1), &(v1262_11_tail));
          compose(&(v1263_5),&(v1264_6))
        };
        drop(v1263_5);
        let v1263_8: Space = intersect(&(*CONSTANT_3),&(v1263_2));
        drop(v1263_2);
        let v1263_9: Space = if has_head(&(v1263_8)) { singleton(&[]) } else { Space::new() };
        drop(v1263_8);
        let v1263_11: Space = if (v1263_9).is_empty() { Space::new() } else {
          let v1265_10: Space = routine_62(c, &(v1262_11_head), &(*p1), &(v1262_11_tail));
          compose(&(v1263_9),&(v1265_10))
        };
        drop(v1263_9);
        let v1263_12: Space = unite(&(v1263_7),&(v1263_11));
        v1262_11.join_into((v1263_12).clone());
      }
      drop(v1262_11_cursor);
      drop(v1262_10);
      compose(&(v1260_9),&(v1262_11))
    };
    drop(v1260_9);
    let v1260_13: Space = unite(&(v1260_7),&(v1260_12));
    drop(v1260_7);
    v1259_15.join_into((v1260_13).clone());
  }
  drop(v1259_15_cursor);
  drop(v1259_11);
  (v1259_15).clone()
}

fn routine_144(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1266_12 = Space::new();
  let mut v1266_12_cursor = (*s0).read_zipper();
  for v1266_12_byte in v1266_12_cursor.child_mask().iter() {
    v1266_12_cursor.descend_to_byte(v1266_12_byte);
    let v1266_12_tail = v1266_12_cursor.make_map();
    v1266_12_cursor.ascend(1);
    let v1266_12_head = Path::from_slice(&[v1266_12_byte]);
    let v1267_2: Space = singleton(&(v1266_12_head));
    let v1267_3: Space = intersect(&(*CONSTANT_3),&(v1267_2));
    let v1267_4: Space = if has_head(&(v1267_3)) { singleton(&[]) } else { Space::new() };
    drop(v1267_3);
    let v1267_5: Space = subtract(&(*CONSTANT_2),&(v1267_4));
    drop(v1267_4);
    let v1267_8: Space = if (v1267_5).is_empty() { Space::new() } else {
      let v1268_6: Path = concat_path(&(*p0),&(v1266_12_head));
      let mut v1268_7 = Space::new();
      let mut v1268_7_cursor = (v1266_12_tail).read_zipper();
      for v1268_7_byte in v1268_7_cursor.child_mask().iter() {
        v1268_7_cursor.descend_to_byte(v1268_7_byte);
        let v1268_7_tail = v1268_7_cursor.make_map();
        v1268_7_cursor.ascend(1);
        let v1268_7_head = Path::from_slice(&[v1268_7_byte]);
        let v1269_2: Space = singleton(&(v1268_7_head));
        let v1269_3: Space = intersect(&(*CONSTANT_3),&(v1269_2));
        let v1269_4: Space = if has_head(&(v1269_3)) { singleton(&[]) } else { Space::new() };
        drop(v1269_3);
        let v1269_5: Space = subtract(&(*CONSTANT_2),&(v1269_4));
        drop(v1269_4);
        let v1269_8: Space = if (v1269_5).is_empty() { Space::new() } else {
          let v1270_6: Path = concat_path(&(v1268_6),&(v1268_7_head));
          let v1270_7: Space = routine_170(c, &(v1270_6), &(*p1), &(v1268_7_tail));
          compose(&(v1269_5),&(v1270_7))
        };
        drop(v1269_5);
        let v1269_9: Space = intersect(&(*CONSTANT_3),&(v1269_2));
        drop(v1269_2);
        let v1269_10: Space = if has_head(&(v1269_9)) { singleton(&[]) } else { Space::new() };
        drop(v1269_9);
        let v1269_12: Space = if (v1269_10).is_empty() { Space::new() } else {
          let v1271_6: Path = concat_path(&(v1268_6),&(v1268_7_head));
          let v1271_11: Space = routine_171(c, &(v1271_6), &(*p1), &(v1268_7_tail));
          drop(v1271_6);
          compose(&(v1269_10),&(v1271_11))
        };
        drop(v1269_10);
        let v1269_13: Space = unite(&(v1269_8),&(v1269_12));
        v1268_7.join_into((v1269_13).clone());
      }
      drop(v1268_7_cursor);
      compose(&(v1267_5),&(v1268_7))
    };
    drop(v1267_5);
    let v1267_9: Space = intersect(&(*CONSTANT_3),&(v1267_2));
    drop(v1267_2);
    let v1267_10: Space = if has_head(&(v1267_9)) { singleton(&[]) } else { Space::new() };
    drop(v1267_9);
    let v1267_12: Space = if (v1267_10).is_empty() { Space::new() } else {
      let v1272_6: Path = concat_path(&(*p0),&(v1266_12_head));
      let mut v1272_11 = Space::new();
      let mut v1272_11_cursor = (v1266_12_tail).read_zipper();
      for v1272_11_byte in v1272_11_cursor.child_mask().iter() {
        v1272_11_cursor.descend_to_byte(v1272_11_byte);
        let v1272_11_tail = v1272_11_cursor.make_map();
        v1272_11_cursor.ascend(1);
        let v1272_11_head = Path::from_slice(&[v1272_11_byte]);
        let v1273_2: Space = singleton(&(v1272_11_head));
        let v1273_3: Space = intersect(&(*CONSTANT_3),&(v1273_2));
        let v1273_4: Space = if has_head(&(v1273_3)) { singleton(&[]) } else { Space::new() };
        drop(v1273_3);
        let v1273_5: Space = subtract(&(*CONSTANT_2),&(v1273_4));
        drop(v1273_4);
        let v1273_8: Space = if (v1273_5).is_empty() { Space::new() } else {
          let v1274_6: Path = concat_path(&(v1272_6),&(v1272_11_head));
          let v1274_7: Space = routine_170(c, &(v1274_6), &(*p1), &(v1272_11_tail));
          compose(&(v1273_5),&(v1274_7))
        };
        drop(v1273_5);
        let v1273_9: Space = intersect(&(*CONSTANT_3),&(v1273_2));
        drop(v1273_2);
        let v1273_10: Space = if has_head(&(v1273_9)) { singleton(&[]) } else { Space::new() };
        drop(v1273_9);
        let v1273_12: Space = if (v1273_10).is_empty() { Space::new() } else {
          let v1275_6: Path = concat_path(&(v1272_6),&(v1272_11_head));
          let v1275_11: Space = routine_67(c, &(v1275_6), &(*p1), &(v1272_11_tail));
          drop(v1275_6);
          compose(&(v1273_10),&(v1275_11))
        };
        drop(v1273_10);
        let v1273_13: Space = unite(&(v1273_8),&(v1273_12));
        v1272_11.join_into((v1273_13).clone());
      }
      drop(v1272_11_cursor);
      drop(v1272_6);
      compose(&(v1267_10),&(v1272_11))
    };
    drop(v1267_10);
    let v1267_13: Space = unite(&(v1267_8),&(v1267_12));
    v1266_12.join_into((v1267_13).clone());
  }
  drop(v1266_12_cursor);
  (v1266_12).clone()
}

fn routine_145(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1276_9 = Space::new();
  let mut v1276_9_cursor = (*s0).read_zipper();
  for v1276_9_byte in v1276_9_cursor.child_mask().iter() {
    v1276_9_cursor.descend_to_byte(v1276_9_byte);
    let v1276_9_tail = v1276_9_cursor.make_map();
    v1276_9_cursor.ascend(1);
    let v1276_9_head = Path::from_slice(&[v1276_9_byte]);
    let v1277_2: Space = singleton(&(v1276_9_head));
    let v1277_3: Space = intersect(&(*CONSTANT_3),&(v1277_2));
    let v1277_4: Space = if has_head(&(v1277_3)) { singleton(&[]) } else { Space::new() };
    drop(v1277_3);
    let v1277_5: Space = subtract(&(*CONSTANT_2),&(v1277_4));
    drop(v1277_4);
    let v1277_8: Space = if (v1277_5).is_empty() { Space::new() } else {
      let v1278_6: Path = concat_path(&(*p0),&(v1276_9_head));
      let mut v1278_7 = Space::new();
      let mut v1278_7_cursor = (v1276_9_tail).read_zipper();
      for v1278_7_byte in v1278_7_cursor.child_mask().iter() {
        v1278_7_cursor.descend_to_byte(v1278_7_byte);
        let v1278_7_tail = v1278_7_cursor.make_map();
        v1278_7_cursor.ascend(1);
        let v1278_7_head = Path::from_slice(&[v1278_7_byte]);
        let v1279_2: Space = singleton(&(v1278_7_head));
        let v1279_3: Space = intersect(&(*CONSTANT_3),&(v1279_2));
        let v1279_4: Space = if has_head(&(v1279_3)) { singleton(&[]) } else { Space::new() };
        drop(v1279_3);
        let v1279_5: Space = subtract(&(*CONSTANT_2),&(v1279_4));
        drop(v1279_4);
        let v1279_8: Space = if (v1279_5).is_empty() { Space::new() } else {
          let v1280_6: Path = concat_path(&(v1278_6),&(v1278_7_head));
          let v1280_7: Space = routine_170(c, &(v1280_6), &(*p1), &(v1278_7_tail));
          compose(&(v1279_5),&(v1280_7))
        };
        drop(v1279_5);
        let v1279_9: Space = intersect(&(*CONSTANT_3),&(v1279_2));
        drop(v1279_2);
        let v1279_10: Space = if has_head(&(v1279_9)) { singleton(&[]) } else { Space::new() };
        drop(v1279_9);
        let v1279_12: Space = if (v1279_10).is_empty() { Space::new() } else {
          let v1281_6: Path = concat_path(&(v1278_6),&(v1278_7_head));
          let v1281_11: Space = routine_171(c, &(v1281_6), &(*p1), &(v1278_7_tail));
          drop(v1281_6);
          compose(&(v1279_10),&(v1281_11))
        };
        drop(v1279_10);
        let v1279_13: Space = unite(&(v1279_8),&(v1279_12));
        v1278_7.join_into((v1279_13).clone());
      }
      drop(v1278_7_cursor);
      compose(&(v1277_5),&(v1278_7))
    };
    drop(v1277_5);
    let v1277_9: Space = intersect(&(*CONSTANT_3),&(v1277_2));
    drop(v1277_2);
    let v1277_10: Space = if has_head(&(v1277_9)) { singleton(&[]) } else { Space::new() };
    drop(v1277_9);
    let v1277_11: Space = compose(&(v1277_10),&(v1276_9_tail));
    drop(v1277_10);
    let v1282_6: Path = concat_path(&(*p0),&(v1276_9_head));
    let v1277_12: Space = wrap(&(v1277_11),&(v1282_6));
    drop(v1277_11);
    let v1277_13: Space = wrap(&(v1277_12),&(*p1));
    drop(v1277_12);
    let v1277_14: Space = unite(&(v1277_8),&(v1277_13));
    drop(v1277_13);
    v1276_9.join_into((v1277_14).clone());
  }
  drop(v1276_9_cursor);
  (v1276_9).clone()
}

fn routine_146(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1283_4 = Space::new();
  let mut v1283_4_cursor = (*s0).read_zipper();
  for v1283_4_byte in v1283_4_cursor.child_mask().iter() {
    v1283_4_cursor.descend_to_byte(v1283_4_byte);
    let v1283_4_tail = v1283_4_cursor.make_map();
    v1283_4_cursor.ascend(1);
    let v1283_4_head = Path::from_slice(&[v1283_4_byte]);
    let v1284_2: Space = Space::new();
    v1283_4.join_into((v1284_2).clone());
  }
  drop(v1283_4_cursor);
  (v1283_4).clone()
}

fn routine_147(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1285_6: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v1285_8: Space = unwrap(&(v1285_6),&(*CONSTANT_5));
  drop(v1285_6);
  let v1285_9: Space = unwrap(&(v1285_8),&(*p0));
  drop(v1285_8);
  let mut v1285_13 = Space::new();
  let mut v1285_13_cursor = (*s0).read_zipper();
  for v1285_13_byte in v1285_13_cursor.child_mask().iter() {
    v1285_13_cursor.descend_to_byte(v1285_13_byte);
    let v1285_13_tail = v1285_13_cursor.make_map();
    v1285_13_cursor.ascend(1);
    let v1285_13_head = Path::from_slice(&[v1285_13_byte]);
    let v1286_2: Space = singleton(&(v1285_13_head));
    let v1286_3: Space = intersect(&(*CONSTANT_3),&(v1286_2));
    drop(v1286_2);
    let v1286_4: Space = if has_head(&(v1286_3)) { singleton(&[]) } else { Space::new() };
    drop(v1286_3);
    let v1286_7: Space = if (v1286_4).is_empty() { Space::new() } else {
      let v1287_5: Space = unwrap(&(v1285_9),&(v1285_13_head));
      let mut v1287_6 = Space::new();
      let mut v1287_6_cursor = (v1287_5).read_zipper();
      for v1287_6_byte in v1287_6_cursor.child_mask().iter() {
        v1287_6_cursor.descend_to_byte(v1287_6_byte);
        let v1287_6_tail = v1287_6_cursor.make_map();
        v1287_6_cursor.ascend(1);
        let v1287_6_head = Path::from_slice(&[v1287_6_byte]);
        let v1288_2: Space = singleton(&(v1287_6_head));
        let v1288_3: Space = intersect(&(*CONSTANT_3),&(v1288_2));
        let v1288_4: Space = if has_head(&(v1288_3)) { singleton(&[]) } else { Space::new() };
        drop(v1288_3);
        let v1288_5: Space = subtract(&(*CONSTANT_2),&(v1288_4));
        drop(v1288_4);
        let v1288_7: Space = if (v1288_5).is_empty() { Space::new() } else {
          let v1289_6: Space = routine_61(c, &(v1287_6_head), &(*p1), &(v1287_6_tail));
          compose(&(v1288_5),&(v1289_6))
        };
        drop(v1288_5);
        let v1288_8: Space = intersect(&(*CONSTANT_3),&(v1288_2));
        drop(v1288_2);
        let v1288_9: Space = if has_head(&(v1288_8)) { singleton(&[]) } else { Space::new() };
        drop(v1288_8);
        let v1288_11: Space = if (v1288_9).is_empty() { Space::new() } else {
          let v1290_10: Space = routine_62(c, &(v1287_6_head), &(*p1), &(v1287_6_tail));
          compose(&(v1288_9),&(v1290_10))
        };
        drop(v1288_9);
        let v1288_12: Space = unite(&(v1288_7),&(v1288_11));
        v1287_6.join_into((v1288_12).clone());
      }
      drop(v1287_6_cursor);
      drop(v1287_5);
      compose(&(v1286_4),&(v1287_6))
    };
    drop(v1286_4);
    v1285_13.join_into((v1286_7).clone());
  }
  drop(v1285_13_cursor);
  drop(v1285_9);
  (v1285_13).clone()
}

fn routine_148(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1291_12 = Space::new();
  let mut v1291_12_cursor = (*s0).read_zipper();
  for v1291_12_byte in v1291_12_cursor.child_mask().iter() {
    v1291_12_cursor.descend_to_byte(v1291_12_byte);
    let v1291_12_tail = v1291_12_cursor.make_map();
    v1291_12_cursor.ascend(1);
    let v1291_12_head = Path::from_slice(&[v1291_12_byte]);
    let v1292_2: Space = singleton(&(v1291_12_head));
    let v1292_3: Space = intersect(&(*CONSTANT_3),&(v1292_2));
    let v1292_4: Space = if has_head(&(v1292_3)) { singleton(&[]) } else { Space::new() };
    drop(v1292_3);
    let v1292_5: Space = subtract(&(*CONSTANT_2),&(v1292_4));
    drop(v1292_4);
    let v1292_8: Space = if (v1292_5).is_empty() { Space::new() } else {
      let v1293_6: Path = concat_path(&(*p0),&(v1291_12_head));
      let mut v1293_7 = Space::new();
      let mut v1293_7_cursor = (v1291_12_tail).read_zipper();
      for v1293_7_byte in v1293_7_cursor.child_mask().iter() {
        v1293_7_cursor.descend_to_byte(v1293_7_byte);
        let v1293_7_tail = v1293_7_cursor.make_map();
        v1293_7_cursor.ascend(1);
        let v1293_7_head = Path::from_slice(&[v1293_7_byte]);
        let v1294_2: Space = singleton(&(v1293_7_head));
        let v1294_3: Space = intersect(&(*CONSTANT_3),&(v1294_2));
        let v1294_4: Space = if has_head(&(v1294_3)) { singleton(&[]) } else { Space::new() };
        drop(v1294_3);
        let v1294_5: Space = subtract(&(*CONSTANT_2),&(v1294_4));
        drop(v1294_4);
        let v1294_8: Space = if (v1294_5).is_empty() { Space::new() } else {
          let v1295_6: Path = concat_path(&(v1293_6),&(v1293_7_head));
          let v1295_7: Space = routine_172(c, &(v1295_6), &(*p1), &(v1293_7_tail));
          compose(&(v1294_5),&(v1295_7))
        };
        drop(v1294_5);
        let v1294_9: Space = intersect(&(*CONSTANT_3),&(v1294_2));
        drop(v1294_2);
        let v1294_10: Space = if has_head(&(v1294_9)) { singleton(&[]) } else { Space::new() };
        drop(v1294_9);
        let v1294_12: Space = if (v1294_10).is_empty() { Space::new() } else {
          let v1296_6: Path = concat_path(&(v1293_6),&(v1293_7_head));
          let v1296_11: Space = routine_173(c, &(v1296_6), &(*p1), &(v1293_7_tail));
          drop(v1296_6);
          compose(&(v1294_10),&(v1296_11))
        };
        drop(v1294_10);
        let v1294_13: Space = unite(&(v1294_8),&(v1294_12));
        v1293_7.join_into((v1294_13).clone());
      }
      drop(v1293_7_cursor);
      compose(&(v1292_5),&(v1293_7))
    };
    drop(v1292_5);
    let v1292_9: Space = intersect(&(*CONSTANT_3),&(v1292_2));
    drop(v1292_2);
    let v1292_10: Space = if has_head(&(v1292_9)) { singleton(&[]) } else { Space::new() };
    drop(v1292_9);
    let v1292_12: Space = if (v1292_10).is_empty() { Space::new() } else {
      let v1297_6: Path = concat_path(&(*p0),&(v1291_12_head));
      let mut v1297_11 = Space::new();
      let mut v1297_11_cursor = (v1291_12_tail).read_zipper();
      for v1297_11_byte in v1297_11_cursor.child_mask().iter() {
        v1297_11_cursor.descend_to_byte(v1297_11_byte);
        let v1297_11_tail = v1297_11_cursor.make_map();
        v1297_11_cursor.ascend(1);
        let v1297_11_head = Path::from_slice(&[v1297_11_byte]);
        let v1298_2: Space = singleton(&(v1297_11_head));
        let v1298_3: Space = intersect(&(*CONSTANT_3),&(v1298_2));
        let v1298_4: Space = if has_head(&(v1298_3)) { singleton(&[]) } else { Space::new() };
        drop(v1298_3);
        let v1298_5: Space = subtract(&(*CONSTANT_2),&(v1298_4));
        drop(v1298_4);
        let v1298_8: Space = if (v1298_5).is_empty() { Space::new() } else {
          let v1299_6: Path = concat_path(&(v1297_6),&(v1297_11_head));
          let v1299_7: Space = routine_172(c, &(v1299_6), &(*p1), &(v1297_11_tail));
          compose(&(v1298_5),&(v1299_7))
        };
        drop(v1298_5);
        let v1298_9: Space = intersect(&(*CONSTANT_3),&(v1298_2));
        drop(v1298_2);
        let v1298_10: Space = if has_head(&(v1298_9)) { singleton(&[]) } else { Space::new() };
        drop(v1298_9);
        let v1298_12: Space = if (v1298_10).is_empty() { Space::new() } else {
          let v1300_6: Path = concat_path(&(v1297_6),&(v1297_11_head));
          let v1300_11: Space = routine_67(c, &(v1300_6), &(*p1), &(v1297_11_tail));
          drop(v1300_6);
          compose(&(v1298_10),&(v1300_11))
        };
        drop(v1298_10);
        let v1298_13: Space = unite(&(v1298_8),&(v1298_12));
        v1297_11.join_into((v1298_13).clone());
      }
      drop(v1297_11_cursor);
      drop(v1297_6);
      compose(&(v1292_10),&(v1297_11))
    };
    drop(v1292_10);
    let v1292_13: Space = unite(&(v1292_8),&(v1292_12));
    v1291_12.join_into((v1292_13).clone());
  }
  drop(v1291_12_cursor);
  (v1291_12).clone()
}

fn routine_149(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1301_9 = Space::new();
  let mut v1301_9_cursor = (*s0).read_zipper();
  for v1301_9_byte in v1301_9_cursor.child_mask().iter() {
    v1301_9_cursor.descend_to_byte(v1301_9_byte);
    let v1301_9_tail = v1301_9_cursor.make_map();
    v1301_9_cursor.ascend(1);
    let v1301_9_head = Path::from_slice(&[v1301_9_byte]);
    let v1302_2: Space = singleton(&(v1301_9_head));
    let v1302_3: Space = intersect(&(*CONSTANT_3),&(v1302_2));
    let v1302_4: Space = if has_head(&(v1302_3)) { singleton(&[]) } else { Space::new() };
    drop(v1302_3);
    let v1302_5: Space = subtract(&(*CONSTANT_2),&(v1302_4));
    drop(v1302_4);
    let v1302_8: Space = if (v1302_5).is_empty() { Space::new() } else {
      let v1303_6: Path = concat_path(&(*p0),&(v1301_9_head));
      let mut v1303_7 = Space::new();
      let mut v1303_7_cursor = (v1301_9_tail).read_zipper();
      for v1303_7_byte in v1303_7_cursor.child_mask().iter() {
        v1303_7_cursor.descend_to_byte(v1303_7_byte);
        let v1303_7_tail = v1303_7_cursor.make_map();
        v1303_7_cursor.ascend(1);
        let v1303_7_head = Path::from_slice(&[v1303_7_byte]);
        let v1304_2: Space = singleton(&(v1303_7_head));
        let v1304_3: Space = intersect(&(*CONSTANT_3),&(v1304_2));
        let v1304_4: Space = if has_head(&(v1304_3)) { singleton(&[]) } else { Space::new() };
        drop(v1304_3);
        let v1304_5: Space = subtract(&(*CONSTANT_2),&(v1304_4));
        drop(v1304_4);
        let v1304_8: Space = if (v1304_5).is_empty() { Space::new() } else {
          let v1305_6: Path = concat_path(&(v1303_6),&(v1303_7_head));
          let v1305_7: Space = routine_172(c, &(v1305_6), &(*p1), &(v1303_7_tail));
          compose(&(v1304_5),&(v1305_7))
        };
        drop(v1304_5);
        let v1304_9: Space = intersect(&(*CONSTANT_3),&(v1304_2));
        drop(v1304_2);
        let v1304_10: Space = if has_head(&(v1304_9)) { singleton(&[]) } else { Space::new() };
        drop(v1304_9);
        let v1304_12: Space = if (v1304_10).is_empty() { Space::new() } else {
          let v1306_6: Path = concat_path(&(v1303_6),&(v1303_7_head));
          let v1306_11: Space = routine_173(c, &(v1306_6), &(*p1), &(v1303_7_tail));
          drop(v1306_6);
          compose(&(v1304_10),&(v1306_11))
        };
        drop(v1304_10);
        let v1304_13: Space = unite(&(v1304_8),&(v1304_12));
        v1303_7.join_into((v1304_13).clone());
      }
      drop(v1303_7_cursor);
      compose(&(v1302_5),&(v1303_7))
    };
    drop(v1302_5);
    let v1302_9: Space = intersect(&(*CONSTANT_3),&(v1302_2));
    drop(v1302_2);
    let v1302_10: Space = if has_head(&(v1302_9)) { singleton(&[]) } else { Space::new() };
    drop(v1302_9);
    let v1302_11: Space = compose(&(v1302_10),&(v1301_9_tail));
    drop(v1302_10);
    let v1307_6: Path = concat_path(&(*p0),&(v1301_9_head));
    let v1302_12: Space = wrap(&(v1302_11),&(v1307_6));
    drop(v1302_11);
    let v1302_13: Space = wrap(&(v1302_12),&(*p1));
    drop(v1302_12);
    let v1302_14: Space = unite(&(v1302_8),&(v1302_13));
    drop(v1302_13);
    v1301_9.join_into((v1302_14).clone());
  }
  drop(v1301_9_cursor);
  (v1301_9).clone()
}

fn routine_150(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1308_7 = Space::new();
  let mut v1308_7_cursor = (*s0).read_zipper();
  for v1308_7_byte in v1308_7_cursor.child_mask().iter() {
    v1308_7_cursor.descend_to_byte(v1308_7_byte);
    let v1308_7_tail = v1308_7_cursor.make_map();
    v1308_7_cursor.ascend(1);
    let v1308_7_head = Path::from_slice(&[v1308_7_byte]);
    let v1309_2: Space = singleton(&(v1308_7_head));
    let v1309_3: Space = intersect(&(*CONSTANT_3),&(v1309_2));
    let v1309_4: Space = if has_head(&(v1309_3)) { singleton(&[]) } else { Space::new() };
    drop(v1309_3);
    let v1309_5: Space = subtract(&(*CONSTANT_2),&(v1309_4));
    drop(v1309_4);
    let mut v1309_6 = Space::new();
    let mut v1309_6_cursor = (v1308_7_tail).read_zipper();
    for v1309_6_byte in v1309_6_cursor.child_mask().iter() {
      v1309_6_cursor.descend_to_byte(v1309_6_byte);
      let v1309_6_tail = v1309_6_cursor.make_map();
      v1309_6_cursor.ascend(1);
      let v1309_6_head = Path::from_slice(&[v1309_6_byte]);
      let v1310_2: Space = Space::new();
      v1309_6.join_into((v1310_2).clone());
    }
    drop(v1309_6_cursor);
    let v1309_7: Space = compose(&(v1309_5),&(v1309_6));
    drop(v1309_5);
    drop(v1309_6);
    let v1309_8: Space = intersect(&(*CONSTANT_3),&(v1309_2));
    drop(v1309_2);
    let v1309_9: Space = if has_head(&(v1309_8)) { singleton(&[]) } else { Space::new() };
    drop(v1309_8);
    let v1309_12: Space = if (v1309_9).is_empty() { Space::new() } else {
      let v1311_10: Path = concat_path(&(*p0),&(v1308_7_head));
      let mut v1311_11 = Space::new();
      let mut v1311_11_cursor = (v1308_7_tail).read_zipper();
      for v1311_11_byte in v1311_11_cursor.child_mask().iter() {
        v1311_11_cursor.descend_to_byte(v1311_11_byte);
        let v1311_11_tail = v1311_11_cursor.make_map();
        v1311_11_cursor.ascend(1);
        let v1311_11_head = Path::from_slice(&[v1311_11_byte]);
        let v1312_2: Space = singleton(&(v1311_11_head));
        let v1312_3: Space = intersect(&(*CONSTANT_3),&(v1312_2));
        drop(v1312_2);
        let v1312_4: Space = if has_head(&(v1312_3)) { singleton(&[]) } else { Space::new() };
        drop(v1312_3);
        let v1312_7: Space = if (v1312_4).is_empty() { Space::new() } else {
          let v1313_5: Path = concat_path(&(v1311_10),&(v1311_11_head));
          let v1313_6: Space = routine_36(c, &(v1313_5), &(*p1), &(v1311_11_tail));
          drop(v1313_5);
          compose(&(v1312_4),&(v1313_6))
        };
        drop(v1312_4);
        v1311_11.join_into((v1312_7).clone());
      }
      drop(v1311_11_cursor);
      drop(v1311_10);
      compose(&(v1309_9),&(v1311_11))
    };
    drop(v1309_9);
    let v1309_13: Space = unite(&(v1309_7),&(v1309_12));
    drop(v1309_7);
    v1308_7.join_into((v1309_13).clone());
  }
  drop(v1308_7_cursor);
  (v1308_7).clone()
}

fn routine_151(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1314_6 = Space::new();
  let mut v1314_6_cursor = (*s0).read_zipper();
  for v1314_6_byte in v1314_6_cursor.child_mask().iter() {
    v1314_6_cursor.descend_to_byte(v1314_6_byte);
    let v1314_6_tail = v1314_6_cursor.make_map();
    v1314_6_cursor.ascend(1);
    let v1314_6_head = Path::from_slice(&[v1314_6_byte]);
    let v1315_2: Space = singleton(&(v1314_6_head));
    let v1315_3: Space = intersect(&(*CONSTANT_3),&(v1315_2));
    let v1315_4: Space = if has_head(&(v1315_3)) { singleton(&[]) } else { Space::new() };
    drop(v1315_3);
    let v1315_5: Space = subtract(&(*CONSTANT_2),&(v1315_4));
    drop(v1315_4);
    let mut v1315_6 = Space::new();
    let mut v1315_6_cursor = (v1314_6_tail).read_zipper();
    for v1315_6_byte in v1315_6_cursor.child_mask().iter() {
      v1315_6_cursor.descend_to_byte(v1315_6_byte);
      let v1315_6_tail = v1315_6_cursor.make_map();
      v1315_6_cursor.ascend(1);
      let v1315_6_head = Path::from_slice(&[v1315_6_byte]);
      let v1316_2: Space = Space::new();
      v1315_6.join_into((v1316_2).clone());
    }
    drop(v1315_6_cursor);
    let v1315_7: Space = compose(&(v1315_5),&(v1315_6));
    drop(v1315_5);
    drop(v1315_6);
    let v1315_8: Space = intersect(&(*CONSTANT_3),&(v1315_2));
    drop(v1315_2);
    let v1315_9: Space = if has_head(&(v1315_8)) { singleton(&[]) } else { Space::new() };
    drop(v1315_8);
    let v1315_10: Space = compose(&(v1315_9),&(v1314_6_tail));
    drop(v1315_9);
    let v1315_11: Path = concat_path(&(*p0),&(v1314_6_head));
    let v1315_12: Space = wrap(&(v1315_10),&(v1315_11));
    drop(v1315_10);
    drop(v1315_11);
    let v1315_13: Space = wrap(&(v1315_12),&(*p1));
    drop(v1315_12);
    let v1315_14: Space = unite(&(v1315_7),&(v1315_13));
    drop(v1315_7);
    drop(v1315_13);
    v1314_6.join_into((v1315_14).clone());
  }
  drop(v1314_6_cursor);
  (v1314_6).clone()
}

fn routine_152(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1317_3 = Space::new();
  let mut v1317_3_cursor = (*s0).read_zipper();
  for v1317_3_byte in v1317_3_cursor.child_mask().iter() {
    v1317_3_cursor.descend_to_byte(v1317_3_byte);
    let v1317_3_tail = v1317_3_cursor.make_map();
    v1317_3_cursor.ascend(1);
    let v1317_3_head = Path::from_slice(&[v1317_3_byte]);
    let v1318_2: Space = Space::new();
    v1317_3.join_into((v1318_2).clone());
  }
  drop(v1317_3_cursor);
  (v1317_3).clone()
}

fn routine_153(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1319_4 = Space::new();
  let mut v1319_4_cursor = (*s0).read_zipper();
  for v1319_4_byte in v1319_4_cursor.child_mask().iter() {
    v1319_4_cursor.descend_to_byte(v1319_4_byte);
    let v1319_4_tail = v1319_4_cursor.make_map();
    v1319_4_cursor.ascend(1);
    let v1319_4_head = Path::from_slice(&[v1319_4_byte]);
    let v1320_2: Space = singleton(&(v1319_4_head));
    let v1320_3: Space = intersect(&(*CONSTANT_3),&(v1320_2));
    drop(v1320_2);
    let v1320_4: Space = if has_head(&(v1320_3)) { singleton(&[]) } else { Space::new() };
    drop(v1320_3);
    let v1320_5: Space = compose(&(v1320_4),&(v1319_4_tail));
    drop(v1320_4);
    let v1320_6: Path = concat_path(&(*p0),&(v1319_4_head));
    let v1320_7: Space = wrap(&(v1320_5),&(v1320_6));
    drop(v1320_5);
    drop(v1320_6);
    v1319_4.join_into((v1320_7).clone());
  }
  drop(v1319_4_cursor);
  let v1319_5: Space = wrap(&(v1319_4),&(*p1));
  drop(v1319_4);
  (v1319_5).clone()
}

fn routine_154(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1321_8 = Space::new();
  let mut v1321_8_cursor = (*s0).read_zipper();
  for v1321_8_byte in v1321_8_cursor.child_mask().iter() {
    v1321_8_cursor.descend_to_byte(v1321_8_byte);
    let v1321_8_tail = v1321_8_cursor.make_map();
    v1321_8_cursor.ascend(1);
    let v1321_8_head = Path::from_slice(&[v1321_8_byte]);
    let v1322_2: Space = singleton(&(v1321_8_head));
    let v1322_3: Space = intersect(&(*CONSTANT_3),&(v1322_2));
    let v1322_4: Space = if has_head(&(v1322_3)) { singleton(&[]) } else { Space::new() };
    drop(v1322_3);
    let v1322_5: Space = subtract(&(*CONSTANT_2),&(v1322_4));
    drop(v1322_4);
    let mut v1322_6 = Space::new();
    let mut v1322_6_cursor = (v1321_8_tail).read_zipper();
    for v1322_6_byte in v1322_6_cursor.child_mask().iter() {
      v1322_6_cursor.descend_to_byte(v1322_6_byte);
      let v1322_6_tail = v1322_6_cursor.make_map();
      v1322_6_cursor.ascend(1);
      let v1322_6_head = Path::from_slice(&[v1322_6_byte]);
      let v1323_2: Space = Space::new();
      v1322_6.join_into((v1323_2).clone());
    }
    drop(v1322_6_cursor);
    let v1322_7: Space = compose(&(v1322_5),&(v1322_6));
    drop(v1322_5);
    drop(v1322_6);
    let v1322_8: Space = intersect(&(*CONSTANT_3),&(v1322_2));
    drop(v1322_2);
    let v1322_9: Space = if has_head(&(v1322_8)) { singleton(&[]) } else { Space::new() };
    drop(v1322_8);
    let v1322_12: Space = if (v1322_9).is_empty() { Space::new() } else {
      let v1324_10: Path = concat_path(&(*p0),&(v1321_8_head));
      let mut v1324_11 = Space::new();
      let mut v1324_11_cursor = (v1321_8_tail).read_zipper();
      for v1324_11_byte in v1324_11_cursor.child_mask().iter() {
        v1324_11_cursor.descend_to_byte(v1324_11_byte);
        let v1324_11_tail = v1324_11_cursor.make_map();
        v1324_11_cursor.ascend(1);
        let v1324_11_head = Path::from_slice(&[v1324_11_byte]);
        let v1325_2: Space = singleton(&(v1324_11_head));
        let v1325_3: Space = intersect(&(*CONSTANT_3),&(v1325_2));
        drop(v1325_2);
        let v1325_4: Space = if has_head(&(v1325_3)) { singleton(&[]) } else { Space::new() };
        drop(v1325_3);
        let v1325_7: Space = if (v1325_4).is_empty() { Space::new() } else {
          let v1326_5: Path = concat_path(&(v1324_10),&(v1324_11_head));
          let v1326_6: Space = routine_43(c, &(v1326_5), &(*p1), &(v1324_11_tail), &(*s1));
          drop(v1326_5);
          compose(&(v1325_4),&(v1326_6))
        };
        drop(v1325_4);
        v1324_11.join_into((v1325_7).clone());
      }
      drop(v1324_11_cursor);
      drop(v1324_10);
      compose(&(v1322_9),&(v1324_11))
    };
    drop(v1322_9);
    let v1322_13: Space = unite(&(v1322_7),&(v1322_12));
    drop(v1322_7);
    v1321_8.join_into((v1322_13).clone());
  }
  drop(v1321_8_cursor);
  (v1321_8).clone()
}

fn routine_155(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1327_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v1327_10: Space = unwrap(&(v1327_8),&(*CONSTANT_5));
  drop(v1327_8);
  let v1327_11: Space = unwrap(&(v1327_10),&(*p0));
  drop(v1327_10);
  let mut v1327_15 = Space::new();
  let mut v1327_15_cursor = (*s0).read_zipper();
  for v1327_15_byte in v1327_15_cursor.child_mask().iter() {
    v1327_15_cursor.descend_to_byte(v1327_15_byte);
    let v1327_15_tail = v1327_15_cursor.make_map();
    v1327_15_cursor.ascend(1);
    let v1327_15_head = Path::from_slice(&[v1327_15_byte]);
    let v1328_2: Space = singleton(&(v1327_15_head));
    let v1328_3: Space = intersect(&(*CONSTANT_3),&(v1328_2));
    let v1328_4: Space = if has_head(&(v1328_3)) { singleton(&[]) } else { Space::new() };
    drop(v1328_3);
    let v1328_5: Space = subtract(&(*CONSTANT_2),&(v1328_4));
    drop(v1328_4);
    let mut v1328_6 = Space::new();
    let mut v1328_6_cursor = (v1327_15_tail).read_zipper();
    for v1328_6_byte in v1328_6_cursor.child_mask().iter() {
      v1328_6_cursor.descend_to_byte(v1328_6_byte);
      let v1328_6_tail = v1328_6_cursor.make_map();
      v1328_6_cursor.ascend(1);
      let v1328_6_head = Path::from_slice(&[v1328_6_byte]);
      let v1329_2: Space = Space::new();
      v1328_6.join_into((v1329_2).clone());
    }
    drop(v1328_6_cursor);
    let v1328_7: Space = compose(&(v1328_5),&(v1328_6));
    drop(v1328_5);
    drop(v1328_6);
    let v1328_8: Space = intersect(&(*CONSTANT_3),&(v1328_2));
    drop(v1328_2);
    let v1328_9: Space = if has_head(&(v1328_8)) { singleton(&[]) } else { Space::new() };
    drop(v1328_8);
    let v1328_12: Space = if (v1328_9).is_empty() { Space::new() } else {
      let v1330_10: Space = unwrap(&(v1327_11),&(v1327_15_head));
      let mut v1330_11 = Space::new();
      let mut v1330_11_cursor = (v1330_10).read_zipper();
      for v1330_11_byte in v1330_11_cursor.child_mask().iter() {
        v1330_11_cursor.descend_to_byte(v1330_11_byte);
        let v1330_11_tail = v1330_11_cursor.make_map();
        v1330_11_cursor.ascend(1);
        let v1330_11_head = Path::from_slice(&[v1330_11_byte]);
        let v1331_2: Space = singleton(&(v1330_11_head));
        let v1331_3: Space = intersect(&(*CONSTANT_3),&(v1331_2));
        let v1331_4: Space = if has_head(&(v1331_3)) { singleton(&[]) } else { Space::new() };
        drop(v1331_3);
        let v1331_5: Space = subtract(&(*CONSTANT_2),&(v1331_4));
        drop(v1331_4);
        let v1331_7: Space = if (v1331_5).is_empty() { Space::new() } else {
          let v1332_6: Space = routine_78(c, &(v1330_11_head), &(*p1), &(v1330_11_tail));
          compose(&(v1331_5),&(v1332_6))
        };
        drop(v1331_5);
        let v1331_8: Space = intersect(&(*CONSTANT_3),&(v1331_2));
        drop(v1331_2);
        let v1331_9: Space = if has_head(&(v1331_8)) { singleton(&[]) } else { Space::new() };
        drop(v1331_8);
        let v1331_11: Space = if (v1331_9).is_empty() { Space::new() } else {
          let v1333_10: Space = routine_79(c, &(v1330_11_head), &(*p1), &(v1330_11_tail));
          compose(&(v1331_9),&(v1333_10))
        };
        drop(v1331_9);
        let v1331_12: Space = unite(&(v1331_7),&(v1331_11));
        v1330_11.join_into((v1331_12).clone());
      }
      drop(v1330_11_cursor);
      drop(v1330_10);
      compose(&(v1328_9),&(v1330_11))
    };
    drop(v1328_9);
    let v1328_13: Space = unite(&(v1328_7),&(v1328_12));
    drop(v1328_7);
    v1327_15.join_into((v1328_13).clone());
  }
  drop(v1327_15_cursor);
  drop(v1327_11);
  (v1327_15).clone()
}

fn routine_156(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1334_12 = Space::new();
  let mut v1334_12_cursor = (*s0).read_zipper();
  for v1334_12_byte in v1334_12_cursor.child_mask().iter() {
    v1334_12_cursor.descend_to_byte(v1334_12_byte);
    let v1334_12_tail = v1334_12_cursor.make_map();
    v1334_12_cursor.ascend(1);
    let v1334_12_head = Path::from_slice(&[v1334_12_byte]);
    let v1335_2: Space = singleton(&(v1334_12_head));
    let v1335_3: Space = intersect(&(*CONSTANT_3),&(v1335_2));
    let v1335_4: Space = if has_head(&(v1335_3)) { singleton(&[]) } else { Space::new() };
    drop(v1335_3);
    let v1335_5: Space = subtract(&(*CONSTANT_2),&(v1335_4));
    drop(v1335_4);
    let v1335_8: Space = if (v1335_5).is_empty() { Space::new() } else {
      let v1336_6: Path = concat_path(&(*p0),&(v1334_12_head));
      let mut v1336_7 = Space::new();
      let mut v1336_7_cursor = (v1334_12_tail).read_zipper();
      for v1336_7_byte in v1336_7_cursor.child_mask().iter() {
        v1336_7_cursor.descend_to_byte(v1336_7_byte);
        let v1336_7_tail = v1336_7_cursor.make_map();
        v1336_7_cursor.ascend(1);
        let v1336_7_head = Path::from_slice(&[v1336_7_byte]);
        let v1337_2: Space = singleton(&(v1336_7_head));
        let v1337_3: Space = intersect(&(*CONSTANT_3),&(v1337_2));
        let v1337_4: Space = if has_head(&(v1337_3)) { singleton(&[]) } else { Space::new() };
        drop(v1337_3);
        let v1337_5: Space = subtract(&(*CONSTANT_2),&(v1337_4));
        drop(v1337_4);
        let v1337_8: Space = if (v1337_5).is_empty() { Space::new() } else {
          let v1338_6: Path = concat_path(&(v1336_6),&(v1336_7_head));
          let v1338_7: Space = routine_174(c, &(v1338_6), &(*p1), &(v1336_7_tail));
          compose(&(v1337_5),&(v1338_7))
        };
        drop(v1337_5);
        let v1337_9: Space = intersect(&(*CONSTANT_3),&(v1337_2));
        drop(v1337_2);
        let v1337_10: Space = if has_head(&(v1337_9)) { singleton(&[]) } else { Space::new() };
        drop(v1337_9);
        let v1337_12: Space = if (v1337_10).is_empty() { Space::new() } else {
          let v1339_6: Path = concat_path(&(v1336_6),&(v1336_7_head));
          let v1339_11: Space = routine_175(c, &(v1339_6), &(*p1), &(v1336_7_tail));
          drop(v1339_6);
          compose(&(v1337_10),&(v1339_11))
        };
        drop(v1337_10);
        let v1337_13: Space = unite(&(v1337_8),&(v1337_12));
        v1336_7.join_into((v1337_13).clone());
      }
      drop(v1336_7_cursor);
      compose(&(v1335_5),&(v1336_7))
    };
    drop(v1335_5);
    let v1335_9: Space = intersect(&(*CONSTANT_3),&(v1335_2));
    drop(v1335_2);
    let v1335_10: Space = if has_head(&(v1335_9)) { singleton(&[]) } else { Space::new() };
    drop(v1335_9);
    let v1335_12: Space = if (v1335_10).is_empty() { Space::new() } else {
      let v1340_6: Path = concat_path(&(*p0),&(v1334_12_head));
      let mut v1340_11 = Space::new();
      let mut v1340_11_cursor = (v1334_12_tail).read_zipper();
      for v1340_11_byte in v1340_11_cursor.child_mask().iter() {
        v1340_11_cursor.descend_to_byte(v1340_11_byte);
        let v1340_11_tail = v1340_11_cursor.make_map();
        v1340_11_cursor.ascend(1);
        let v1340_11_head = Path::from_slice(&[v1340_11_byte]);
        let v1341_2: Space = singleton(&(v1340_11_head));
        let v1341_3: Space = intersect(&(*CONSTANT_3),&(v1341_2));
        let v1341_4: Space = if has_head(&(v1341_3)) { singleton(&[]) } else { Space::new() };
        drop(v1341_3);
        let v1341_5: Space = subtract(&(*CONSTANT_2),&(v1341_4));
        drop(v1341_4);
        let v1341_8: Space = if (v1341_5).is_empty() { Space::new() } else {
          let v1342_6: Path = concat_path(&(v1340_6),&(v1340_11_head));
          let v1342_7: Space = routine_174(c, &(v1342_6), &(*p1), &(v1340_11_tail));
          compose(&(v1341_5),&(v1342_7))
        };
        drop(v1341_5);
        let v1341_9: Space = intersect(&(*CONSTANT_3),&(v1341_2));
        drop(v1341_2);
        let v1341_10: Space = if has_head(&(v1341_9)) { singleton(&[]) } else { Space::new() };
        drop(v1341_9);
        let v1341_12: Space = if (v1341_10).is_empty() { Space::new() } else {
          let v1343_6: Path = concat_path(&(v1340_6),&(v1340_11_head));
          let v1343_11: Space = routine_84(c, &(v1343_6), &(*p1), &(v1340_11_tail));
          drop(v1343_6);
          compose(&(v1341_10),&(v1343_11))
        };
        drop(v1341_10);
        let v1341_13: Space = unite(&(v1341_8),&(v1341_12));
        v1340_11.join_into((v1341_13).clone());
      }
      drop(v1340_11_cursor);
      drop(v1340_6);
      compose(&(v1335_10),&(v1340_11))
    };
    drop(v1335_10);
    let v1335_13: Space = unite(&(v1335_8),&(v1335_12));
    v1334_12.join_into((v1335_13).clone());
  }
  drop(v1334_12_cursor);
  (v1334_12).clone()
}

fn routine_157(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1344_9 = Space::new();
  let mut v1344_9_cursor = (*s0).read_zipper();
  for v1344_9_byte in v1344_9_cursor.child_mask().iter() {
    v1344_9_cursor.descend_to_byte(v1344_9_byte);
    let v1344_9_tail = v1344_9_cursor.make_map();
    v1344_9_cursor.ascend(1);
    let v1344_9_head = Path::from_slice(&[v1344_9_byte]);
    let v1345_2: Space = singleton(&(v1344_9_head));
    let v1345_3: Space = intersect(&(*CONSTANT_3),&(v1345_2));
    let v1345_4: Space = if has_head(&(v1345_3)) { singleton(&[]) } else { Space::new() };
    drop(v1345_3);
    let v1345_5: Space = subtract(&(*CONSTANT_2),&(v1345_4));
    drop(v1345_4);
    let v1345_8: Space = if (v1345_5).is_empty() { Space::new() } else {
      let v1346_6: Path = concat_path(&(*p0),&(v1344_9_head));
      let mut v1346_7 = Space::new();
      let mut v1346_7_cursor = (v1344_9_tail).read_zipper();
      for v1346_7_byte in v1346_7_cursor.child_mask().iter() {
        v1346_7_cursor.descend_to_byte(v1346_7_byte);
        let v1346_7_tail = v1346_7_cursor.make_map();
        v1346_7_cursor.ascend(1);
        let v1346_7_head = Path::from_slice(&[v1346_7_byte]);
        let v1347_2: Space = singleton(&(v1346_7_head));
        let v1347_3: Space = intersect(&(*CONSTANT_3),&(v1347_2));
        let v1347_4: Space = if has_head(&(v1347_3)) { singleton(&[]) } else { Space::new() };
        drop(v1347_3);
        let v1347_5: Space = subtract(&(*CONSTANT_2),&(v1347_4));
        drop(v1347_4);
        let v1347_8: Space = if (v1347_5).is_empty() { Space::new() } else {
          let v1348_6: Path = concat_path(&(v1346_6),&(v1346_7_head));
          let v1348_7: Space = routine_174(c, &(v1348_6), &(*p1), &(v1346_7_tail));
          compose(&(v1347_5),&(v1348_7))
        };
        drop(v1347_5);
        let v1347_9: Space = intersect(&(*CONSTANT_3),&(v1347_2));
        drop(v1347_2);
        let v1347_10: Space = if has_head(&(v1347_9)) { singleton(&[]) } else { Space::new() };
        drop(v1347_9);
        let v1347_12: Space = if (v1347_10).is_empty() { Space::new() } else {
          let v1349_6: Path = concat_path(&(v1346_6),&(v1346_7_head));
          let v1349_11: Space = routine_175(c, &(v1349_6), &(*p1), &(v1346_7_tail));
          drop(v1349_6);
          compose(&(v1347_10),&(v1349_11))
        };
        drop(v1347_10);
        let v1347_13: Space = unite(&(v1347_8),&(v1347_12));
        v1346_7.join_into((v1347_13).clone());
      }
      drop(v1346_7_cursor);
      compose(&(v1345_5),&(v1346_7))
    };
    drop(v1345_5);
    let v1345_9: Space = intersect(&(*CONSTANT_3),&(v1345_2));
    drop(v1345_2);
    let v1345_10: Space = if has_head(&(v1345_9)) { singleton(&[]) } else { Space::new() };
    drop(v1345_9);
    let v1345_11: Space = compose(&(v1345_10),&(v1344_9_tail));
    drop(v1345_10);
    let v1350_6: Path = concat_path(&(*p0),&(v1344_9_head));
    let v1345_12: Space = wrap(&(v1345_11),&(v1350_6));
    drop(v1345_11);
    let v1345_13: Space = wrap(&(v1345_12),&(*p1));
    drop(v1345_12);
    let v1345_14: Space = unite(&(v1345_8),&(v1345_13));
    drop(v1345_13);
    v1344_9.join_into((v1345_14).clone());
  }
  drop(v1344_9_cursor);
  (v1344_9).clone()
}

fn routine_158(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1351_4 = Space::new();
  let mut v1351_4_cursor = (*s0).read_zipper();
  for v1351_4_byte in v1351_4_cursor.child_mask().iter() {
    v1351_4_cursor.descend_to_byte(v1351_4_byte);
    let v1351_4_tail = v1351_4_cursor.make_map();
    v1351_4_cursor.ascend(1);
    let v1351_4_head = Path::from_slice(&[v1351_4_byte]);
    let v1352_2: Space = Space::new();
    v1351_4.join_into((v1352_2).clone());
  }
  drop(v1351_4_cursor);
  (v1351_4).clone()
}

fn routine_159(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1353_6: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v1353_8: Space = unwrap(&(v1353_6),&(*CONSTANT_5));
  drop(v1353_6);
  let v1353_9: Space = unwrap(&(v1353_8),&(*p0));
  drop(v1353_8);
  let mut v1353_13 = Space::new();
  let mut v1353_13_cursor = (*s0).read_zipper();
  for v1353_13_byte in v1353_13_cursor.child_mask().iter() {
    v1353_13_cursor.descend_to_byte(v1353_13_byte);
    let v1353_13_tail = v1353_13_cursor.make_map();
    v1353_13_cursor.ascend(1);
    let v1353_13_head = Path::from_slice(&[v1353_13_byte]);
    let v1354_2: Space = singleton(&(v1353_13_head));
    let v1354_3: Space = intersect(&(*CONSTANT_3),&(v1354_2));
    drop(v1354_2);
    let v1354_4: Space = if has_head(&(v1354_3)) { singleton(&[]) } else { Space::new() };
    drop(v1354_3);
    let v1354_7: Space = if (v1354_4).is_empty() { Space::new() } else {
      let v1355_5: Space = unwrap(&(v1353_9),&(v1353_13_head));
      let mut v1355_6 = Space::new();
      let mut v1355_6_cursor = (v1355_5).read_zipper();
      for v1355_6_byte in v1355_6_cursor.child_mask().iter() {
        v1355_6_cursor.descend_to_byte(v1355_6_byte);
        let v1355_6_tail = v1355_6_cursor.make_map();
        v1355_6_cursor.ascend(1);
        let v1355_6_head = Path::from_slice(&[v1355_6_byte]);
        let v1356_2: Space = singleton(&(v1355_6_head));
        let v1356_3: Space = intersect(&(*CONSTANT_3),&(v1356_2));
        let v1356_4: Space = if has_head(&(v1356_3)) { singleton(&[]) } else { Space::new() };
        drop(v1356_3);
        let v1356_5: Space = subtract(&(*CONSTANT_2),&(v1356_4));
        drop(v1356_4);
        let v1356_7: Space = if (v1356_5).is_empty() { Space::new() } else {
          let v1357_6: Space = routine_78(c, &(v1355_6_head), &(*p1), &(v1355_6_tail));
          compose(&(v1356_5),&(v1357_6))
        };
        drop(v1356_5);
        let v1356_8: Space = intersect(&(*CONSTANT_3),&(v1356_2));
        drop(v1356_2);
        let v1356_9: Space = if has_head(&(v1356_8)) { singleton(&[]) } else { Space::new() };
        drop(v1356_8);
        let v1356_11: Space = if (v1356_9).is_empty() { Space::new() } else {
          let v1358_10: Space = routine_79(c, &(v1355_6_head), &(*p1), &(v1355_6_tail));
          compose(&(v1356_9),&(v1358_10))
        };
        drop(v1356_9);
        let v1356_12: Space = unite(&(v1356_7),&(v1356_11));
        v1355_6.join_into((v1356_12).clone());
      }
      drop(v1355_6_cursor);
      drop(v1355_5);
      compose(&(v1354_4),&(v1355_6))
    };
    drop(v1354_4);
    v1353_13.join_into((v1354_7).clone());
  }
  drop(v1353_13_cursor);
  drop(v1353_9);
  (v1353_13).clone()
}

fn routine_160(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1359_12 = Space::new();
  let mut v1359_12_cursor = (*s0).read_zipper();
  for v1359_12_byte in v1359_12_cursor.child_mask().iter() {
    v1359_12_cursor.descend_to_byte(v1359_12_byte);
    let v1359_12_tail = v1359_12_cursor.make_map();
    v1359_12_cursor.ascend(1);
    let v1359_12_head = Path::from_slice(&[v1359_12_byte]);
    let v1360_2: Space = singleton(&(v1359_12_head));
    let v1360_3: Space = intersect(&(*CONSTANT_3),&(v1360_2));
    let v1360_4: Space = if has_head(&(v1360_3)) { singleton(&[]) } else { Space::new() };
    drop(v1360_3);
    let v1360_5: Space = subtract(&(*CONSTANT_2),&(v1360_4));
    drop(v1360_4);
    let v1360_8: Space = if (v1360_5).is_empty() { Space::new() } else {
      let v1361_6: Path = concat_path(&(*p0),&(v1359_12_head));
      let mut v1361_7 = Space::new();
      let mut v1361_7_cursor = (v1359_12_tail).read_zipper();
      for v1361_7_byte in v1361_7_cursor.child_mask().iter() {
        v1361_7_cursor.descend_to_byte(v1361_7_byte);
        let v1361_7_tail = v1361_7_cursor.make_map();
        v1361_7_cursor.ascend(1);
        let v1361_7_head = Path::from_slice(&[v1361_7_byte]);
        let v1362_2: Space = singleton(&(v1361_7_head));
        let v1362_3: Space = intersect(&(*CONSTANT_3),&(v1362_2));
        let v1362_4: Space = if has_head(&(v1362_3)) { singleton(&[]) } else { Space::new() };
        drop(v1362_3);
        let v1362_5: Space = subtract(&(*CONSTANT_2),&(v1362_4));
        drop(v1362_4);
        let v1362_8: Space = if (v1362_5).is_empty() { Space::new() } else {
          let v1363_6: Path = concat_path(&(v1361_6),&(v1361_7_head));
          let v1363_7: Space = routine_176(c, &(v1363_6), &(*p1), &(v1361_7_tail));
          compose(&(v1362_5),&(v1363_7))
        };
        drop(v1362_5);
        let v1362_9: Space = intersect(&(*CONSTANT_3),&(v1362_2));
        drop(v1362_2);
        let v1362_10: Space = if has_head(&(v1362_9)) { singleton(&[]) } else { Space::new() };
        drop(v1362_9);
        let v1362_12: Space = if (v1362_10).is_empty() { Space::new() } else {
          let v1364_6: Path = concat_path(&(v1361_6),&(v1361_7_head));
          let v1364_11: Space = routine_177(c, &(v1364_6), &(*p1), &(v1361_7_tail));
          drop(v1364_6);
          compose(&(v1362_10),&(v1364_11))
        };
        drop(v1362_10);
        let v1362_13: Space = unite(&(v1362_8),&(v1362_12));
        v1361_7.join_into((v1362_13).clone());
      }
      drop(v1361_7_cursor);
      compose(&(v1360_5),&(v1361_7))
    };
    drop(v1360_5);
    let v1360_9: Space = intersect(&(*CONSTANT_3),&(v1360_2));
    drop(v1360_2);
    let v1360_10: Space = if has_head(&(v1360_9)) { singleton(&[]) } else { Space::new() };
    drop(v1360_9);
    let v1360_12: Space = if (v1360_10).is_empty() { Space::new() } else {
      let v1365_6: Path = concat_path(&(*p0),&(v1359_12_head));
      let mut v1365_11 = Space::new();
      let mut v1365_11_cursor = (v1359_12_tail).read_zipper();
      for v1365_11_byte in v1365_11_cursor.child_mask().iter() {
        v1365_11_cursor.descend_to_byte(v1365_11_byte);
        let v1365_11_tail = v1365_11_cursor.make_map();
        v1365_11_cursor.ascend(1);
        let v1365_11_head = Path::from_slice(&[v1365_11_byte]);
        let v1366_2: Space = singleton(&(v1365_11_head));
        let v1366_3: Space = intersect(&(*CONSTANT_3),&(v1366_2));
        let v1366_4: Space = if has_head(&(v1366_3)) { singleton(&[]) } else { Space::new() };
        drop(v1366_3);
        let v1366_5: Space = subtract(&(*CONSTANT_2),&(v1366_4));
        drop(v1366_4);
        let v1366_8: Space = if (v1366_5).is_empty() { Space::new() } else {
          let v1367_6: Path = concat_path(&(v1365_6),&(v1365_11_head));
          let v1367_7: Space = routine_176(c, &(v1367_6), &(*p1), &(v1365_11_tail));
          compose(&(v1366_5),&(v1367_7))
        };
        drop(v1366_5);
        let v1366_9: Space = intersect(&(*CONSTANT_3),&(v1366_2));
        drop(v1366_2);
        let v1366_10: Space = if has_head(&(v1366_9)) { singleton(&[]) } else { Space::new() };
        drop(v1366_9);
        let v1366_12: Space = if (v1366_10).is_empty() { Space::new() } else {
          let v1368_6: Path = concat_path(&(v1365_6),&(v1365_11_head));
          let v1368_11: Space = routine_84(c, &(v1368_6), &(*p1), &(v1365_11_tail));
          drop(v1368_6);
          compose(&(v1366_10),&(v1368_11))
        };
        drop(v1366_10);
        let v1366_13: Space = unite(&(v1366_8),&(v1366_12));
        v1365_11.join_into((v1366_13).clone());
      }
      drop(v1365_11_cursor);
      drop(v1365_6);
      compose(&(v1360_10),&(v1365_11))
    };
    drop(v1360_10);
    let v1360_13: Space = unite(&(v1360_8),&(v1360_12));
    v1359_12.join_into((v1360_13).clone());
  }
  drop(v1359_12_cursor);
  (v1359_12).clone()
}

fn routine_161(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1369_9 = Space::new();
  let mut v1369_9_cursor = (*s0).read_zipper();
  for v1369_9_byte in v1369_9_cursor.child_mask().iter() {
    v1369_9_cursor.descend_to_byte(v1369_9_byte);
    let v1369_9_tail = v1369_9_cursor.make_map();
    v1369_9_cursor.ascend(1);
    let v1369_9_head = Path::from_slice(&[v1369_9_byte]);
    let v1370_2: Space = singleton(&(v1369_9_head));
    let v1370_3: Space = intersect(&(*CONSTANT_3),&(v1370_2));
    let v1370_4: Space = if has_head(&(v1370_3)) { singleton(&[]) } else { Space::new() };
    drop(v1370_3);
    let v1370_5: Space = subtract(&(*CONSTANT_2),&(v1370_4));
    drop(v1370_4);
    let v1370_8: Space = if (v1370_5).is_empty() { Space::new() } else {
      let v1371_6: Path = concat_path(&(*p0),&(v1369_9_head));
      let mut v1371_7 = Space::new();
      let mut v1371_7_cursor = (v1369_9_tail).read_zipper();
      for v1371_7_byte in v1371_7_cursor.child_mask().iter() {
        v1371_7_cursor.descend_to_byte(v1371_7_byte);
        let v1371_7_tail = v1371_7_cursor.make_map();
        v1371_7_cursor.ascend(1);
        let v1371_7_head = Path::from_slice(&[v1371_7_byte]);
        let v1372_2: Space = singleton(&(v1371_7_head));
        let v1372_3: Space = intersect(&(*CONSTANT_3),&(v1372_2));
        let v1372_4: Space = if has_head(&(v1372_3)) { singleton(&[]) } else { Space::new() };
        drop(v1372_3);
        let v1372_5: Space = subtract(&(*CONSTANT_2),&(v1372_4));
        drop(v1372_4);
        let v1372_8: Space = if (v1372_5).is_empty() { Space::new() } else {
          let v1373_6: Path = concat_path(&(v1371_6),&(v1371_7_head));
          let v1373_7: Space = routine_176(c, &(v1373_6), &(*p1), &(v1371_7_tail));
          compose(&(v1372_5),&(v1373_7))
        };
        drop(v1372_5);
        let v1372_9: Space = intersect(&(*CONSTANT_3),&(v1372_2));
        drop(v1372_2);
        let v1372_10: Space = if has_head(&(v1372_9)) { singleton(&[]) } else { Space::new() };
        drop(v1372_9);
        let v1372_12: Space = if (v1372_10).is_empty() { Space::new() } else {
          let v1374_6: Path = concat_path(&(v1371_6),&(v1371_7_head));
          let v1374_11: Space = routine_177(c, &(v1374_6), &(*p1), &(v1371_7_tail));
          drop(v1374_6);
          compose(&(v1372_10),&(v1374_11))
        };
        drop(v1372_10);
        let v1372_13: Space = unite(&(v1372_8),&(v1372_12));
        v1371_7.join_into((v1372_13).clone());
      }
      drop(v1371_7_cursor);
      compose(&(v1370_5),&(v1371_7))
    };
    drop(v1370_5);
    let v1370_9: Space = intersect(&(*CONSTANT_3),&(v1370_2));
    drop(v1370_2);
    let v1370_10: Space = if has_head(&(v1370_9)) { singleton(&[]) } else { Space::new() };
    drop(v1370_9);
    let v1370_11: Space = compose(&(v1370_10),&(v1369_9_tail));
    drop(v1370_10);
    let v1375_6: Path = concat_path(&(*p0),&(v1369_9_head));
    let v1370_12: Space = wrap(&(v1370_11),&(v1375_6));
    drop(v1370_11);
    let v1370_13: Space = wrap(&(v1370_12),&(*p1));
    drop(v1370_12);
    let v1370_14: Space = unite(&(v1370_8),&(v1370_13));
    drop(v1370_13);
    v1369_9.join_into((v1370_14).clone());
  }
  drop(v1369_9_cursor);
  (v1369_9).clone()
}

fn routine_162(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1376_8 = Space::new();
  let mut v1376_8_cursor = (*s0).read_zipper();
  for v1376_8_byte in v1376_8_cursor.child_mask().iter() {
    v1376_8_cursor.descend_to_byte(v1376_8_byte);
    let v1376_8_tail = v1376_8_cursor.make_map();
    v1376_8_cursor.ascend(1);
    let v1376_8_head = Path::from_slice(&[v1376_8_byte]);
    let v1377_2: Space = singleton(&(v1376_8_head));
    let v1377_3: Space = intersect(&(*CONSTANT_3),&(v1377_2));
    let v1377_4: Space = if has_head(&(v1377_3)) { singleton(&[]) } else { Space::new() };
    drop(v1377_3);
    let v1377_5: Space = subtract(&(*CONSTANT_2),&(v1377_4));
    drop(v1377_4);
    let mut v1377_6 = Space::new();
    let mut v1377_6_cursor = (v1376_8_tail).read_zipper();
    for v1377_6_byte in v1377_6_cursor.child_mask().iter() {
      v1377_6_cursor.descend_to_byte(v1377_6_byte);
      let v1377_6_tail = v1377_6_cursor.make_map();
      v1377_6_cursor.ascend(1);
      let v1377_6_head = Path::from_slice(&[v1377_6_byte]);
      let v1378_2: Space = Space::new();
      v1377_6.join_into((v1378_2).clone());
    }
    drop(v1377_6_cursor);
    let v1377_7: Space = compose(&(v1377_5),&(v1377_6));
    drop(v1377_5);
    drop(v1377_6);
    let v1377_8: Space = intersect(&(*CONSTANT_3),&(v1377_2));
    drop(v1377_2);
    let v1377_9: Space = if has_head(&(v1377_8)) { singleton(&[]) } else { Space::new() };
    drop(v1377_8);
    let v1377_12: Space = if (v1377_9).is_empty() { Space::new() } else {
      let v1379_10: Path = concat_path(&(*p0),&(v1376_8_head));
      let mut v1379_11 = Space::new();
      let mut v1379_11_cursor = (v1376_8_tail).read_zipper();
      for v1379_11_byte in v1379_11_cursor.child_mask().iter() {
        v1379_11_cursor.descend_to_byte(v1379_11_byte);
        let v1379_11_tail = v1379_11_cursor.make_map();
        v1379_11_cursor.ascend(1);
        let v1379_11_head = Path::from_slice(&[v1379_11_byte]);
        let v1380_2: Space = singleton(&(v1379_11_head));
        let v1380_3: Space = intersect(&(*CONSTANT_3),&(v1380_2));
        drop(v1380_2);
        let v1380_4: Space = if has_head(&(v1380_3)) { singleton(&[]) } else { Space::new() };
        drop(v1380_3);
        let v1380_7: Space = if (v1380_4).is_empty() { Space::new() } else {
          let v1381_5: Path = concat_path(&(v1379_10),&(v1379_11_head));
          let v1381_6: Space = routine_50(c, &(v1381_5), &(*p1), &(v1379_11_tail), &(*s1));
          drop(v1381_5);
          compose(&(v1380_4),&(v1381_6))
        };
        drop(v1380_4);
        v1379_11.join_into((v1380_7).clone());
      }
      drop(v1379_11_cursor);
      drop(v1379_10);
      compose(&(v1377_9),&(v1379_11))
    };
    drop(v1377_9);
    let v1377_13: Space = unite(&(v1377_7),&(v1377_12));
    drop(v1377_7);
    v1376_8.join_into((v1377_13).clone());
  }
  drop(v1376_8_cursor);
  (v1376_8).clone()
}

fn routine_163(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1382_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v1382_10: Space = unwrap(&(v1382_8),&(*CONSTANT_5));
  drop(v1382_8);
  let v1382_11: Space = unwrap(&(v1382_10),&(*p0));
  drop(v1382_10);
  let mut v1382_15 = Space::new();
  let mut v1382_15_cursor = (*s0).read_zipper();
  for v1382_15_byte in v1382_15_cursor.child_mask().iter() {
    v1382_15_cursor.descend_to_byte(v1382_15_byte);
    let v1382_15_tail = v1382_15_cursor.make_map();
    v1382_15_cursor.ascend(1);
    let v1382_15_head = Path::from_slice(&[v1382_15_byte]);
    let v1383_2: Space = singleton(&(v1382_15_head));
    let v1383_3: Space = intersect(&(*CONSTANT_3),&(v1383_2));
    let v1383_4: Space = if has_head(&(v1383_3)) { singleton(&[]) } else { Space::new() };
    drop(v1383_3);
    let v1383_5: Space = subtract(&(*CONSTANT_2),&(v1383_4));
    drop(v1383_4);
    let mut v1383_6 = Space::new();
    let mut v1383_6_cursor = (v1382_15_tail).read_zipper();
    for v1383_6_byte in v1383_6_cursor.child_mask().iter() {
      v1383_6_cursor.descend_to_byte(v1383_6_byte);
      let v1383_6_tail = v1383_6_cursor.make_map();
      v1383_6_cursor.ascend(1);
      let v1383_6_head = Path::from_slice(&[v1383_6_byte]);
      let v1384_2: Space = Space::new();
      v1383_6.join_into((v1384_2).clone());
    }
    drop(v1383_6_cursor);
    let v1383_7: Space = compose(&(v1383_5),&(v1383_6));
    drop(v1383_5);
    drop(v1383_6);
    let v1383_8: Space = intersect(&(*CONSTANT_3),&(v1383_2));
    drop(v1383_2);
    let v1383_9: Space = if has_head(&(v1383_8)) { singleton(&[]) } else { Space::new() };
    drop(v1383_8);
    let v1383_12: Space = if (v1383_9).is_empty() { Space::new() } else {
      let v1385_10: Space = unwrap(&(v1382_11),&(v1382_15_head));
      let mut v1385_11 = Space::new();
      let mut v1385_11_cursor = (v1385_10).read_zipper();
      for v1385_11_byte in v1385_11_cursor.child_mask().iter() {
        v1385_11_cursor.descend_to_byte(v1385_11_byte);
        let v1385_11_tail = v1385_11_cursor.make_map();
        v1385_11_cursor.ascend(1);
        let v1385_11_head = Path::from_slice(&[v1385_11_byte]);
        let v1386_2: Space = singleton(&(v1385_11_head));
        let v1386_3: Space = intersect(&(*CONSTANT_3),&(v1386_2));
        let v1386_4: Space = if has_head(&(v1386_3)) { singleton(&[]) } else { Space::new() };
        drop(v1386_3);
        let v1386_5: Space = subtract(&(*CONSTANT_2),&(v1386_4));
        drop(v1386_4);
        let v1386_7: Space = if (v1386_5).is_empty() { Space::new() } else {
          let v1387_6: Space = routine_89(c, &(v1385_11_head), &(*p1), &(v1385_11_tail));
          compose(&(v1386_5),&(v1387_6))
        };
        drop(v1386_5);
        let v1386_8: Space = intersect(&(*CONSTANT_3),&(v1386_2));
        drop(v1386_2);
        let v1386_9: Space = if has_head(&(v1386_8)) { singleton(&[]) } else { Space::new() };
        drop(v1386_8);
        let v1386_11: Space = if (v1386_9).is_empty() { Space::new() } else {
          let v1388_10: Space = routine_90(c, &(v1385_11_head), &(*p1), &(v1385_11_tail));
          compose(&(v1386_9),&(v1388_10))
        };
        drop(v1386_9);
        let v1386_12: Space = unite(&(v1386_7),&(v1386_11));
        v1385_11.join_into((v1386_12).clone());
      }
      drop(v1385_11_cursor);
      drop(v1385_10);
      compose(&(v1383_9),&(v1385_11))
    };
    drop(v1383_9);
    let v1383_13: Space = unite(&(v1383_7),&(v1383_12));
    drop(v1383_7);
    v1382_15.join_into((v1383_13).clone());
  }
  drop(v1382_15_cursor);
  drop(v1382_11);
  (v1382_15).clone()
}

fn routine_164(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1389_12 = Space::new();
  let mut v1389_12_cursor = (*s0).read_zipper();
  for v1389_12_byte in v1389_12_cursor.child_mask().iter() {
    v1389_12_cursor.descend_to_byte(v1389_12_byte);
    let v1389_12_tail = v1389_12_cursor.make_map();
    v1389_12_cursor.ascend(1);
    let v1389_12_head = Path::from_slice(&[v1389_12_byte]);
    let v1390_2: Space = singleton(&(v1389_12_head));
    let v1390_3: Space = intersect(&(*CONSTANT_3),&(v1390_2));
    let v1390_4: Space = if has_head(&(v1390_3)) { singleton(&[]) } else { Space::new() };
    drop(v1390_3);
    let v1390_5: Space = subtract(&(*CONSTANT_2),&(v1390_4));
    drop(v1390_4);
    let v1390_8: Space = if (v1390_5).is_empty() { Space::new() } else {
      let v1391_6: Path = concat_path(&(*p0),&(v1389_12_head));
      let mut v1391_7 = Space::new();
      let mut v1391_7_cursor = (v1389_12_tail).read_zipper();
      for v1391_7_byte in v1391_7_cursor.child_mask().iter() {
        v1391_7_cursor.descend_to_byte(v1391_7_byte);
        let v1391_7_tail = v1391_7_cursor.make_map();
        v1391_7_cursor.ascend(1);
        let v1391_7_head = Path::from_slice(&[v1391_7_byte]);
        let v1392_2: Space = singleton(&(v1391_7_head));
        let v1392_3: Space = intersect(&(*CONSTANT_3),&(v1392_2));
        let v1392_4: Space = if has_head(&(v1392_3)) { singleton(&[]) } else { Space::new() };
        drop(v1392_3);
        let v1392_5: Space = subtract(&(*CONSTANT_2),&(v1392_4));
        drop(v1392_4);
        let v1392_8: Space = if (v1392_5).is_empty() { Space::new() } else {
          let v1393_6: Path = concat_path(&(v1391_6),&(v1391_7_head));
          let v1393_7: Space = routine_178(c, &(v1393_6), &(*p1), &(v1391_7_tail));
          compose(&(v1392_5),&(v1393_7))
        };
        drop(v1392_5);
        let v1392_9: Space = intersect(&(*CONSTANT_3),&(v1392_2));
        drop(v1392_2);
        let v1392_10: Space = if has_head(&(v1392_9)) { singleton(&[]) } else { Space::new() };
        drop(v1392_9);
        let v1392_12: Space = if (v1392_10).is_empty() { Space::new() } else {
          let v1394_6: Path = concat_path(&(v1391_6),&(v1391_7_head));
          let v1394_11: Space = routine_179(c, &(v1394_6), &(*p1), &(v1391_7_tail));
          drop(v1394_6);
          compose(&(v1392_10),&(v1394_11))
        };
        drop(v1392_10);
        let v1392_13: Space = unite(&(v1392_8),&(v1392_12));
        v1391_7.join_into((v1392_13).clone());
      }
      drop(v1391_7_cursor);
      compose(&(v1390_5),&(v1391_7))
    };
    drop(v1390_5);
    let v1390_9: Space = intersect(&(*CONSTANT_3),&(v1390_2));
    drop(v1390_2);
    let v1390_10: Space = if has_head(&(v1390_9)) { singleton(&[]) } else { Space::new() };
    drop(v1390_9);
    let v1390_12: Space = if (v1390_10).is_empty() { Space::new() } else {
      let v1395_6: Path = concat_path(&(*p0),&(v1389_12_head));
      let mut v1395_11 = Space::new();
      let mut v1395_11_cursor = (v1389_12_tail).read_zipper();
      for v1395_11_byte in v1395_11_cursor.child_mask().iter() {
        v1395_11_cursor.descend_to_byte(v1395_11_byte);
        let v1395_11_tail = v1395_11_cursor.make_map();
        v1395_11_cursor.ascend(1);
        let v1395_11_head = Path::from_slice(&[v1395_11_byte]);
        let v1396_2: Space = singleton(&(v1395_11_head));
        let v1396_3: Space = intersect(&(*CONSTANT_3),&(v1396_2));
        let v1396_4: Space = if has_head(&(v1396_3)) { singleton(&[]) } else { Space::new() };
        drop(v1396_3);
        let v1396_5: Space = subtract(&(*CONSTANT_2),&(v1396_4));
        drop(v1396_4);
        let v1396_8: Space = if (v1396_5).is_empty() { Space::new() } else {
          let v1397_6: Path = concat_path(&(v1395_6),&(v1395_11_head));
          let v1397_7: Space = routine_178(c, &(v1397_6), &(*p1), &(v1395_11_tail));
          compose(&(v1396_5),&(v1397_7))
        };
        drop(v1396_5);
        let v1396_9: Space = intersect(&(*CONSTANT_3),&(v1396_2));
        drop(v1396_2);
        let v1396_10: Space = if has_head(&(v1396_9)) { singleton(&[]) } else { Space::new() };
        drop(v1396_9);
        let v1396_12: Space = if (v1396_10).is_empty() { Space::new() } else {
          let v1398_6: Path = concat_path(&(v1395_6),&(v1395_11_head));
          let v1398_11: Space = routine_95(c, &(v1398_6), &(*p1), &(v1395_11_tail));
          drop(v1398_6);
          compose(&(v1396_10),&(v1398_11))
        };
        drop(v1396_10);
        let v1396_13: Space = unite(&(v1396_8),&(v1396_12));
        v1395_11.join_into((v1396_13).clone());
      }
      drop(v1395_11_cursor);
      drop(v1395_6);
      compose(&(v1390_10),&(v1395_11))
    };
    drop(v1390_10);
    let v1390_13: Space = unite(&(v1390_8),&(v1390_12));
    v1389_12.join_into((v1390_13).clone());
  }
  drop(v1389_12_cursor);
  (v1389_12).clone()
}

fn routine_165(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1399_9 = Space::new();
  let mut v1399_9_cursor = (*s0).read_zipper();
  for v1399_9_byte in v1399_9_cursor.child_mask().iter() {
    v1399_9_cursor.descend_to_byte(v1399_9_byte);
    let v1399_9_tail = v1399_9_cursor.make_map();
    v1399_9_cursor.ascend(1);
    let v1399_9_head = Path::from_slice(&[v1399_9_byte]);
    let v1400_2: Space = singleton(&(v1399_9_head));
    let v1400_3: Space = intersect(&(*CONSTANT_3),&(v1400_2));
    let v1400_4: Space = if has_head(&(v1400_3)) { singleton(&[]) } else { Space::new() };
    drop(v1400_3);
    let v1400_5: Space = subtract(&(*CONSTANT_2),&(v1400_4));
    drop(v1400_4);
    let v1400_8: Space = if (v1400_5).is_empty() { Space::new() } else {
      let v1401_6: Path = concat_path(&(*p0),&(v1399_9_head));
      let mut v1401_7 = Space::new();
      let mut v1401_7_cursor = (v1399_9_tail).read_zipper();
      for v1401_7_byte in v1401_7_cursor.child_mask().iter() {
        v1401_7_cursor.descend_to_byte(v1401_7_byte);
        let v1401_7_tail = v1401_7_cursor.make_map();
        v1401_7_cursor.ascend(1);
        let v1401_7_head = Path::from_slice(&[v1401_7_byte]);
        let v1402_2: Space = singleton(&(v1401_7_head));
        let v1402_3: Space = intersect(&(*CONSTANT_3),&(v1402_2));
        let v1402_4: Space = if has_head(&(v1402_3)) { singleton(&[]) } else { Space::new() };
        drop(v1402_3);
        let v1402_5: Space = subtract(&(*CONSTANT_2),&(v1402_4));
        drop(v1402_4);
        let v1402_8: Space = if (v1402_5).is_empty() { Space::new() } else {
          let v1403_6: Path = concat_path(&(v1401_6),&(v1401_7_head));
          let v1403_7: Space = routine_178(c, &(v1403_6), &(*p1), &(v1401_7_tail));
          compose(&(v1402_5),&(v1403_7))
        };
        drop(v1402_5);
        let v1402_9: Space = intersect(&(*CONSTANT_3),&(v1402_2));
        drop(v1402_2);
        let v1402_10: Space = if has_head(&(v1402_9)) { singleton(&[]) } else { Space::new() };
        drop(v1402_9);
        let v1402_12: Space = if (v1402_10).is_empty() { Space::new() } else {
          let v1404_6: Path = concat_path(&(v1401_6),&(v1401_7_head));
          let v1404_11: Space = routine_179(c, &(v1404_6), &(*p1), &(v1401_7_tail));
          drop(v1404_6);
          compose(&(v1402_10),&(v1404_11))
        };
        drop(v1402_10);
        let v1402_13: Space = unite(&(v1402_8),&(v1402_12));
        v1401_7.join_into((v1402_13).clone());
      }
      drop(v1401_7_cursor);
      compose(&(v1400_5),&(v1401_7))
    };
    drop(v1400_5);
    let v1400_9: Space = intersect(&(*CONSTANT_3),&(v1400_2));
    drop(v1400_2);
    let v1400_10: Space = if has_head(&(v1400_9)) { singleton(&[]) } else { Space::new() };
    drop(v1400_9);
    let v1400_11: Space = compose(&(v1400_10),&(v1399_9_tail));
    drop(v1400_10);
    let v1405_6: Path = concat_path(&(*p0),&(v1399_9_head));
    let v1400_12: Space = wrap(&(v1400_11),&(v1405_6));
    drop(v1400_11);
    let v1400_13: Space = wrap(&(v1400_12),&(*p1));
    drop(v1400_12);
    let v1400_14: Space = unite(&(v1400_8),&(v1400_13));
    drop(v1400_13);
    v1399_9.join_into((v1400_14).clone());
  }
  drop(v1399_9_cursor);
  (v1399_9).clone()
}

fn routine_166(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1406_4 = Space::new();
  let mut v1406_4_cursor = (*s0).read_zipper();
  for v1406_4_byte in v1406_4_cursor.child_mask().iter() {
    v1406_4_cursor.descend_to_byte(v1406_4_byte);
    let v1406_4_tail = v1406_4_cursor.make_map();
    v1406_4_cursor.ascend(1);
    let v1406_4_head = Path::from_slice(&[v1406_4_byte]);
    let v1407_2: Space = Space::new();
    v1406_4.join_into((v1407_2).clone());
  }
  drop(v1406_4_cursor);
  (v1406_4).clone()
}

fn routine_167(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1408_6: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v1408_8: Space = unwrap(&(v1408_6),&(*CONSTANT_5));
  drop(v1408_6);
  let v1408_9: Space = unwrap(&(v1408_8),&(*p0));
  drop(v1408_8);
  let mut v1408_13 = Space::new();
  let mut v1408_13_cursor = (*s0).read_zipper();
  for v1408_13_byte in v1408_13_cursor.child_mask().iter() {
    v1408_13_cursor.descend_to_byte(v1408_13_byte);
    let v1408_13_tail = v1408_13_cursor.make_map();
    v1408_13_cursor.ascend(1);
    let v1408_13_head = Path::from_slice(&[v1408_13_byte]);
    let v1409_2: Space = singleton(&(v1408_13_head));
    let v1409_3: Space = intersect(&(*CONSTANT_3),&(v1409_2));
    drop(v1409_2);
    let v1409_4: Space = if has_head(&(v1409_3)) { singleton(&[]) } else { Space::new() };
    drop(v1409_3);
    let v1409_7: Space = if (v1409_4).is_empty() { Space::new() } else {
      let v1410_5: Space = unwrap(&(v1408_9),&(v1408_13_head));
      let mut v1410_6 = Space::new();
      let mut v1410_6_cursor = (v1410_5).read_zipper();
      for v1410_6_byte in v1410_6_cursor.child_mask().iter() {
        v1410_6_cursor.descend_to_byte(v1410_6_byte);
        let v1410_6_tail = v1410_6_cursor.make_map();
        v1410_6_cursor.ascend(1);
        let v1410_6_head = Path::from_slice(&[v1410_6_byte]);
        let v1411_2: Space = singleton(&(v1410_6_head));
        let v1411_3: Space = intersect(&(*CONSTANT_3),&(v1411_2));
        let v1411_4: Space = if has_head(&(v1411_3)) { singleton(&[]) } else { Space::new() };
        drop(v1411_3);
        let v1411_5: Space = subtract(&(*CONSTANT_2),&(v1411_4));
        drop(v1411_4);
        let v1411_7: Space = if (v1411_5).is_empty() { Space::new() } else {
          let v1412_6: Space = routine_89(c, &(v1410_6_head), &(*p1), &(v1410_6_tail));
          compose(&(v1411_5),&(v1412_6))
        };
        drop(v1411_5);
        let v1411_8: Space = intersect(&(*CONSTANT_3),&(v1411_2));
        drop(v1411_2);
        let v1411_9: Space = if has_head(&(v1411_8)) { singleton(&[]) } else { Space::new() };
        drop(v1411_8);
        let v1411_11: Space = if (v1411_9).is_empty() { Space::new() } else {
          let v1413_10: Space = routine_90(c, &(v1410_6_head), &(*p1), &(v1410_6_tail));
          compose(&(v1411_9),&(v1413_10))
        };
        drop(v1411_9);
        let v1411_12: Space = unite(&(v1411_7),&(v1411_11));
        v1410_6.join_into((v1411_12).clone());
      }
      drop(v1410_6_cursor);
      drop(v1410_5);
      compose(&(v1409_4),&(v1410_6))
    };
    drop(v1409_4);
    v1408_13.join_into((v1409_7).clone());
  }
  drop(v1408_13_cursor);
  drop(v1408_9);
  (v1408_13).clone()
}

fn routine_168(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1414_12 = Space::new();
  let mut v1414_12_cursor = (*s0).read_zipper();
  for v1414_12_byte in v1414_12_cursor.child_mask().iter() {
    v1414_12_cursor.descend_to_byte(v1414_12_byte);
    let v1414_12_tail = v1414_12_cursor.make_map();
    v1414_12_cursor.ascend(1);
    let v1414_12_head = Path::from_slice(&[v1414_12_byte]);
    let v1415_2: Space = singleton(&(v1414_12_head));
    let v1415_3: Space = intersect(&(*CONSTANT_3),&(v1415_2));
    let v1415_4: Space = if has_head(&(v1415_3)) { singleton(&[]) } else { Space::new() };
    drop(v1415_3);
    let v1415_5: Space = subtract(&(*CONSTANT_2),&(v1415_4));
    drop(v1415_4);
    let v1415_8: Space = if (v1415_5).is_empty() { Space::new() } else {
      let v1416_6: Path = concat_path(&(*p0),&(v1414_12_head));
      let mut v1416_7 = Space::new();
      let mut v1416_7_cursor = (v1414_12_tail).read_zipper();
      for v1416_7_byte in v1416_7_cursor.child_mask().iter() {
        v1416_7_cursor.descend_to_byte(v1416_7_byte);
        let v1416_7_tail = v1416_7_cursor.make_map();
        v1416_7_cursor.ascend(1);
        let v1416_7_head = Path::from_slice(&[v1416_7_byte]);
        let v1417_2: Space = singleton(&(v1416_7_head));
        let v1417_3: Space = intersect(&(*CONSTANT_3),&(v1417_2));
        let v1417_4: Space = if has_head(&(v1417_3)) { singleton(&[]) } else { Space::new() };
        drop(v1417_3);
        let v1417_5: Space = subtract(&(*CONSTANT_2),&(v1417_4));
        drop(v1417_4);
        let v1417_8: Space = if (v1417_5).is_empty() { Space::new() } else {
          let v1418_6: Path = concat_path(&(v1416_6),&(v1416_7_head));
          let v1418_7: Space = routine_180(c, &(v1418_6), &(*p1), &(v1416_7_tail));
          compose(&(v1417_5),&(v1418_7))
        };
        drop(v1417_5);
        let v1417_9: Space = intersect(&(*CONSTANT_3),&(v1417_2));
        drop(v1417_2);
        let v1417_10: Space = if has_head(&(v1417_9)) { singleton(&[]) } else { Space::new() };
        drop(v1417_9);
        let v1417_12: Space = if (v1417_10).is_empty() { Space::new() } else {
          let v1419_6: Path = concat_path(&(v1416_6),&(v1416_7_head));
          let v1419_11: Space = routine_181(c, &(v1419_6), &(*p1), &(v1416_7_tail));
          drop(v1419_6);
          compose(&(v1417_10),&(v1419_11))
        };
        drop(v1417_10);
        let v1417_13: Space = unite(&(v1417_8),&(v1417_12));
        v1416_7.join_into((v1417_13).clone());
      }
      drop(v1416_7_cursor);
      compose(&(v1415_5),&(v1416_7))
    };
    drop(v1415_5);
    let v1415_9: Space = intersect(&(*CONSTANT_3),&(v1415_2));
    drop(v1415_2);
    let v1415_10: Space = if has_head(&(v1415_9)) { singleton(&[]) } else { Space::new() };
    drop(v1415_9);
    let v1415_12: Space = if (v1415_10).is_empty() { Space::new() } else {
      let v1420_6: Path = concat_path(&(*p0),&(v1414_12_head));
      let mut v1420_11 = Space::new();
      let mut v1420_11_cursor = (v1414_12_tail).read_zipper();
      for v1420_11_byte in v1420_11_cursor.child_mask().iter() {
        v1420_11_cursor.descend_to_byte(v1420_11_byte);
        let v1420_11_tail = v1420_11_cursor.make_map();
        v1420_11_cursor.ascend(1);
        let v1420_11_head = Path::from_slice(&[v1420_11_byte]);
        let v1421_2: Space = singleton(&(v1420_11_head));
        let v1421_3: Space = intersect(&(*CONSTANT_3),&(v1421_2));
        let v1421_4: Space = if has_head(&(v1421_3)) { singleton(&[]) } else { Space::new() };
        drop(v1421_3);
        let v1421_5: Space = subtract(&(*CONSTANT_2),&(v1421_4));
        drop(v1421_4);
        let v1421_8: Space = if (v1421_5).is_empty() { Space::new() } else {
          let v1422_6: Path = concat_path(&(v1420_6),&(v1420_11_head));
          let v1422_7: Space = routine_180(c, &(v1422_6), &(*p1), &(v1420_11_tail));
          compose(&(v1421_5),&(v1422_7))
        };
        drop(v1421_5);
        let v1421_9: Space = intersect(&(*CONSTANT_3),&(v1421_2));
        drop(v1421_2);
        let v1421_10: Space = if has_head(&(v1421_9)) { singleton(&[]) } else { Space::new() };
        drop(v1421_9);
        let v1421_12: Space = if (v1421_10).is_empty() { Space::new() } else {
          let v1423_6: Path = concat_path(&(v1420_6),&(v1420_11_head));
          let v1423_11: Space = routine_95(c, &(v1423_6), &(*p1), &(v1420_11_tail));
          drop(v1423_6);
          compose(&(v1421_10),&(v1423_11))
        };
        drop(v1421_10);
        let v1421_13: Space = unite(&(v1421_8),&(v1421_12));
        v1420_11.join_into((v1421_13).clone());
      }
      drop(v1420_11_cursor);
      drop(v1420_6);
      compose(&(v1415_10),&(v1420_11))
    };
    drop(v1415_10);
    let v1415_13: Space = unite(&(v1415_8),&(v1415_12));
    v1414_12.join_into((v1415_13).clone());
  }
  drop(v1414_12_cursor);
  (v1414_12).clone()
}

fn routine_169(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1424_9 = Space::new();
  let mut v1424_9_cursor = (*s0).read_zipper();
  for v1424_9_byte in v1424_9_cursor.child_mask().iter() {
    v1424_9_cursor.descend_to_byte(v1424_9_byte);
    let v1424_9_tail = v1424_9_cursor.make_map();
    v1424_9_cursor.ascend(1);
    let v1424_9_head = Path::from_slice(&[v1424_9_byte]);
    let v1425_2: Space = singleton(&(v1424_9_head));
    let v1425_3: Space = intersect(&(*CONSTANT_3),&(v1425_2));
    let v1425_4: Space = if has_head(&(v1425_3)) { singleton(&[]) } else { Space::new() };
    drop(v1425_3);
    let v1425_5: Space = subtract(&(*CONSTANT_2),&(v1425_4));
    drop(v1425_4);
    let v1425_8: Space = if (v1425_5).is_empty() { Space::new() } else {
      let v1426_6: Path = concat_path(&(*p0),&(v1424_9_head));
      let mut v1426_7 = Space::new();
      let mut v1426_7_cursor = (v1424_9_tail).read_zipper();
      for v1426_7_byte in v1426_7_cursor.child_mask().iter() {
        v1426_7_cursor.descend_to_byte(v1426_7_byte);
        let v1426_7_tail = v1426_7_cursor.make_map();
        v1426_7_cursor.ascend(1);
        let v1426_7_head = Path::from_slice(&[v1426_7_byte]);
        let v1427_2: Space = singleton(&(v1426_7_head));
        let v1427_3: Space = intersect(&(*CONSTANT_3),&(v1427_2));
        let v1427_4: Space = if has_head(&(v1427_3)) { singleton(&[]) } else { Space::new() };
        drop(v1427_3);
        let v1427_5: Space = subtract(&(*CONSTANT_2),&(v1427_4));
        drop(v1427_4);
        let v1427_8: Space = if (v1427_5).is_empty() { Space::new() } else {
          let v1428_6: Path = concat_path(&(v1426_6),&(v1426_7_head));
          let v1428_7: Space = routine_180(c, &(v1428_6), &(*p1), &(v1426_7_tail));
          compose(&(v1427_5),&(v1428_7))
        };
        drop(v1427_5);
        let v1427_9: Space = intersect(&(*CONSTANT_3),&(v1427_2));
        drop(v1427_2);
        let v1427_10: Space = if has_head(&(v1427_9)) { singleton(&[]) } else { Space::new() };
        drop(v1427_9);
        let v1427_12: Space = if (v1427_10).is_empty() { Space::new() } else {
          let v1429_6: Path = concat_path(&(v1426_6),&(v1426_7_head));
          let v1429_11: Space = routine_181(c, &(v1429_6), &(*p1), &(v1426_7_tail));
          drop(v1429_6);
          compose(&(v1427_10),&(v1429_11))
        };
        drop(v1427_10);
        let v1427_13: Space = unite(&(v1427_8),&(v1427_12));
        v1426_7.join_into((v1427_13).clone());
      }
      drop(v1426_7_cursor);
      compose(&(v1425_5),&(v1426_7))
    };
    drop(v1425_5);
    let v1425_9: Space = intersect(&(*CONSTANT_3),&(v1425_2));
    drop(v1425_2);
    let v1425_10: Space = if has_head(&(v1425_9)) { singleton(&[]) } else { Space::new() };
    drop(v1425_9);
    let v1425_11: Space = compose(&(v1425_10),&(v1424_9_tail));
    drop(v1425_10);
    let v1430_6: Path = concat_path(&(*p0),&(v1424_9_head));
    let v1425_12: Space = wrap(&(v1425_11),&(v1430_6));
    drop(v1425_11);
    let v1425_13: Space = wrap(&(v1425_12),&(*p1));
    drop(v1425_12);
    let v1425_14: Space = unite(&(v1425_8),&(v1425_13));
    drop(v1425_13);
    v1424_9.join_into((v1425_14).clone());
  }
  drop(v1424_9_cursor);
  (v1424_9).clone()
}

fn routine_170(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1431_7 = Space::new();
  let mut v1431_7_cursor = (*s0).read_zipper();
  for v1431_7_byte in v1431_7_cursor.child_mask().iter() {
    v1431_7_cursor.descend_to_byte(v1431_7_byte);
    let v1431_7_tail = v1431_7_cursor.make_map();
    v1431_7_cursor.ascend(1);
    let v1431_7_head = Path::from_slice(&[v1431_7_byte]);
    let v1432_2: Space = singleton(&(v1431_7_head));
    let v1432_3: Space = intersect(&(*CONSTANT_3),&(v1432_2));
    let v1432_4: Space = if has_head(&(v1432_3)) { singleton(&[]) } else { Space::new() };
    drop(v1432_3);
    let v1432_5: Space = subtract(&(*CONSTANT_2),&(v1432_4));
    drop(v1432_4);
    let mut v1432_6 = Space::new();
    let mut v1432_6_cursor = (v1431_7_tail).read_zipper();
    for v1432_6_byte in v1432_6_cursor.child_mask().iter() {
      v1432_6_cursor.descend_to_byte(v1432_6_byte);
      let v1432_6_tail = v1432_6_cursor.make_map();
      v1432_6_cursor.ascend(1);
      let v1432_6_head = Path::from_slice(&[v1432_6_byte]);
      let v1433_2: Space = Space::new();
      v1432_6.join_into((v1433_2).clone());
    }
    drop(v1432_6_cursor);
    let v1432_7: Space = compose(&(v1432_5),&(v1432_6));
    drop(v1432_5);
    drop(v1432_6);
    let v1432_8: Space = intersect(&(*CONSTANT_3),&(v1432_2));
    drop(v1432_2);
    let v1432_9: Space = if has_head(&(v1432_8)) { singleton(&[]) } else { Space::new() };
    drop(v1432_8);
    let v1432_12: Space = if (v1432_9).is_empty() { Space::new() } else {
      let v1434_10: Path = concat_path(&(*p0),&(v1431_7_head));
      let mut v1434_11 = Space::new();
      let mut v1434_11_cursor = (v1431_7_tail).read_zipper();
      for v1434_11_byte in v1434_11_cursor.child_mask().iter() {
        v1434_11_cursor.descend_to_byte(v1434_11_byte);
        let v1434_11_tail = v1434_11_cursor.make_map();
        v1434_11_cursor.ascend(1);
        let v1434_11_head = Path::from_slice(&[v1434_11_byte]);
        let v1435_2: Space = singleton(&(v1434_11_head));
        let v1435_3: Space = intersect(&(*CONSTANT_3),&(v1435_2));
        drop(v1435_2);
        let v1435_4: Space = if has_head(&(v1435_3)) { singleton(&[]) } else { Space::new() };
        drop(v1435_3);
        let v1435_7: Space = if (v1435_4).is_empty() { Space::new() } else {
          let v1436_5: Path = concat_path(&(v1434_10),&(v1434_11_head));
          let v1436_6: Space = routine_67(c, &(v1436_5), &(*p1), &(v1434_11_tail));
          drop(v1436_5);
          compose(&(v1435_4),&(v1436_6))
        };
        drop(v1435_4);
        v1434_11.join_into((v1435_7).clone());
      }
      drop(v1434_11_cursor);
      drop(v1434_10);
      compose(&(v1432_9),&(v1434_11))
    };
    drop(v1432_9);
    let v1432_13: Space = unite(&(v1432_7),&(v1432_12));
    drop(v1432_7);
    v1431_7.join_into((v1432_13).clone());
  }
  drop(v1431_7_cursor);
  (v1431_7).clone()
}

fn routine_171(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1437_6 = Space::new();
  let mut v1437_6_cursor = (*s0).read_zipper();
  for v1437_6_byte in v1437_6_cursor.child_mask().iter() {
    v1437_6_cursor.descend_to_byte(v1437_6_byte);
    let v1437_6_tail = v1437_6_cursor.make_map();
    v1437_6_cursor.ascend(1);
    let v1437_6_head = Path::from_slice(&[v1437_6_byte]);
    let v1438_2: Space = singleton(&(v1437_6_head));
    let v1438_3: Space = intersect(&(*CONSTANT_3),&(v1438_2));
    let v1438_4: Space = if has_head(&(v1438_3)) { singleton(&[]) } else { Space::new() };
    drop(v1438_3);
    let v1438_5: Space = subtract(&(*CONSTANT_2),&(v1438_4));
    drop(v1438_4);
    let mut v1438_6 = Space::new();
    let mut v1438_6_cursor = (v1437_6_tail).read_zipper();
    for v1438_6_byte in v1438_6_cursor.child_mask().iter() {
      v1438_6_cursor.descend_to_byte(v1438_6_byte);
      let v1438_6_tail = v1438_6_cursor.make_map();
      v1438_6_cursor.ascend(1);
      let v1438_6_head = Path::from_slice(&[v1438_6_byte]);
      let v1439_2: Space = Space::new();
      v1438_6.join_into((v1439_2).clone());
    }
    drop(v1438_6_cursor);
    let v1438_7: Space = compose(&(v1438_5),&(v1438_6));
    drop(v1438_5);
    drop(v1438_6);
    let v1438_8: Space = intersect(&(*CONSTANT_3),&(v1438_2));
    drop(v1438_2);
    let v1438_9: Space = if has_head(&(v1438_8)) { singleton(&[]) } else { Space::new() };
    drop(v1438_8);
    let v1438_10: Space = compose(&(v1438_9),&(v1437_6_tail));
    drop(v1438_9);
    let v1438_11: Path = concat_path(&(*p0),&(v1437_6_head));
    let v1438_12: Space = wrap(&(v1438_10),&(v1438_11));
    drop(v1438_10);
    drop(v1438_11);
    let v1438_13: Space = wrap(&(v1438_12),&(*p1));
    drop(v1438_12);
    let v1438_14: Space = unite(&(v1438_7),&(v1438_13));
    drop(v1438_7);
    drop(v1438_13);
    v1437_6.join_into((v1438_14).clone());
  }
  drop(v1437_6_cursor);
  (v1437_6).clone()
}

fn routine_172(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1440_3 = Space::new();
  let mut v1440_3_cursor = (*s0).read_zipper();
  for v1440_3_byte in v1440_3_cursor.child_mask().iter() {
    v1440_3_cursor.descend_to_byte(v1440_3_byte);
    let v1440_3_tail = v1440_3_cursor.make_map();
    v1440_3_cursor.ascend(1);
    let v1440_3_head = Path::from_slice(&[v1440_3_byte]);
    let v1441_2: Space = Space::new();
    v1440_3.join_into((v1441_2).clone());
  }
  drop(v1440_3_cursor);
  (v1440_3).clone()
}

fn routine_173(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1442_4 = Space::new();
  let mut v1442_4_cursor = (*s0).read_zipper();
  for v1442_4_byte in v1442_4_cursor.child_mask().iter() {
    v1442_4_cursor.descend_to_byte(v1442_4_byte);
    let v1442_4_tail = v1442_4_cursor.make_map();
    v1442_4_cursor.ascend(1);
    let v1442_4_head = Path::from_slice(&[v1442_4_byte]);
    let v1443_2: Space = singleton(&(v1442_4_head));
    let v1443_3: Space = intersect(&(*CONSTANT_3),&(v1443_2));
    drop(v1443_2);
    let v1443_4: Space = if has_head(&(v1443_3)) { singleton(&[]) } else { Space::new() };
    drop(v1443_3);
    let v1443_5: Space = compose(&(v1443_4),&(v1442_4_tail));
    drop(v1443_4);
    let v1443_6: Path = concat_path(&(*p0),&(v1442_4_head));
    let v1443_7: Space = wrap(&(v1443_5),&(v1443_6));
    drop(v1443_5);
    drop(v1443_6);
    v1442_4.join_into((v1443_7).clone());
  }
  drop(v1442_4_cursor);
  let v1442_5: Space = wrap(&(v1442_4),&(*p1));
  drop(v1442_4);
  (v1442_5).clone()
}

fn routine_174(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1444_7 = Space::new();
  let mut v1444_7_cursor = (*s0).read_zipper();
  for v1444_7_byte in v1444_7_cursor.child_mask().iter() {
    v1444_7_cursor.descend_to_byte(v1444_7_byte);
    let v1444_7_tail = v1444_7_cursor.make_map();
    v1444_7_cursor.ascend(1);
    let v1444_7_head = Path::from_slice(&[v1444_7_byte]);
    let v1445_2: Space = singleton(&(v1444_7_head));
    let v1445_3: Space = intersect(&(*CONSTANT_3),&(v1445_2));
    let v1445_4: Space = if has_head(&(v1445_3)) { singleton(&[]) } else { Space::new() };
    drop(v1445_3);
    let v1445_5: Space = subtract(&(*CONSTANT_2),&(v1445_4));
    drop(v1445_4);
    let mut v1445_6 = Space::new();
    let mut v1445_6_cursor = (v1444_7_tail).read_zipper();
    for v1445_6_byte in v1445_6_cursor.child_mask().iter() {
      v1445_6_cursor.descend_to_byte(v1445_6_byte);
      let v1445_6_tail = v1445_6_cursor.make_map();
      v1445_6_cursor.ascend(1);
      let v1445_6_head = Path::from_slice(&[v1445_6_byte]);
      let v1446_2: Space = Space::new();
      v1445_6.join_into((v1446_2).clone());
    }
    drop(v1445_6_cursor);
    let v1445_7: Space = compose(&(v1445_5),&(v1445_6));
    drop(v1445_5);
    drop(v1445_6);
    let v1445_8: Space = intersect(&(*CONSTANT_3),&(v1445_2));
    drop(v1445_2);
    let v1445_9: Space = if has_head(&(v1445_8)) { singleton(&[]) } else { Space::new() };
    drop(v1445_8);
    let v1445_12: Space = if (v1445_9).is_empty() { Space::new() } else {
      let v1447_10: Path = concat_path(&(*p0),&(v1444_7_head));
      let mut v1447_11 = Space::new();
      let mut v1447_11_cursor = (v1444_7_tail).read_zipper();
      for v1447_11_byte in v1447_11_cursor.child_mask().iter() {
        v1447_11_cursor.descend_to_byte(v1447_11_byte);
        let v1447_11_tail = v1447_11_cursor.make_map();
        v1447_11_cursor.ascend(1);
        let v1447_11_head = Path::from_slice(&[v1447_11_byte]);
        let v1448_2: Space = singleton(&(v1447_11_head));
        let v1448_3: Space = intersect(&(*CONSTANT_3),&(v1448_2));
        drop(v1448_2);
        let v1448_4: Space = if has_head(&(v1448_3)) { singleton(&[]) } else { Space::new() };
        drop(v1448_3);
        let v1448_7: Space = if (v1448_4).is_empty() { Space::new() } else {
          let v1449_5: Path = concat_path(&(v1447_10),&(v1447_11_head));
          let v1449_6: Space = routine_84(c, &(v1449_5), &(*p1), &(v1447_11_tail));
          drop(v1449_5);
          compose(&(v1448_4),&(v1449_6))
        };
        drop(v1448_4);
        v1447_11.join_into((v1448_7).clone());
      }
      drop(v1447_11_cursor);
      drop(v1447_10);
      compose(&(v1445_9),&(v1447_11))
    };
    drop(v1445_9);
    let v1445_13: Space = unite(&(v1445_7),&(v1445_12));
    drop(v1445_7);
    v1444_7.join_into((v1445_13).clone());
  }
  drop(v1444_7_cursor);
  (v1444_7).clone()
}

fn routine_175(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1450_6 = Space::new();
  let mut v1450_6_cursor = (*s0).read_zipper();
  for v1450_6_byte in v1450_6_cursor.child_mask().iter() {
    v1450_6_cursor.descend_to_byte(v1450_6_byte);
    let v1450_6_tail = v1450_6_cursor.make_map();
    v1450_6_cursor.ascend(1);
    let v1450_6_head = Path::from_slice(&[v1450_6_byte]);
    let v1451_2: Space = singleton(&(v1450_6_head));
    let v1451_3: Space = intersect(&(*CONSTANT_3),&(v1451_2));
    let v1451_4: Space = if has_head(&(v1451_3)) { singleton(&[]) } else { Space::new() };
    drop(v1451_3);
    let v1451_5: Space = subtract(&(*CONSTANT_2),&(v1451_4));
    drop(v1451_4);
    let mut v1451_6 = Space::new();
    let mut v1451_6_cursor = (v1450_6_tail).read_zipper();
    for v1451_6_byte in v1451_6_cursor.child_mask().iter() {
      v1451_6_cursor.descend_to_byte(v1451_6_byte);
      let v1451_6_tail = v1451_6_cursor.make_map();
      v1451_6_cursor.ascend(1);
      let v1451_6_head = Path::from_slice(&[v1451_6_byte]);
      let v1452_2: Space = Space::new();
      v1451_6.join_into((v1452_2).clone());
    }
    drop(v1451_6_cursor);
    let v1451_7: Space = compose(&(v1451_5),&(v1451_6));
    drop(v1451_5);
    drop(v1451_6);
    let v1451_8: Space = intersect(&(*CONSTANT_3),&(v1451_2));
    drop(v1451_2);
    let v1451_9: Space = if has_head(&(v1451_8)) { singleton(&[]) } else { Space::new() };
    drop(v1451_8);
    let v1451_10: Space = compose(&(v1451_9),&(v1450_6_tail));
    drop(v1451_9);
    let v1451_11: Path = concat_path(&(*p0),&(v1450_6_head));
    let v1451_12: Space = wrap(&(v1451_10),&(v1451_11));
    drop(v1451_10);
    drop(v1451_11);
    let v1451_13: Space = wrap(&(v1451_12),&(*p1));
    drop(v1451_12);
    let v1451_14: Space = unite(&(v1451_7),&(v1451_13));
    drop(v1451_7);
    drop(v1451_13);
    v1450_6.join_into((v1451_14).clone());
  }
  drop(v1450_6_cursor);
  (v1450_6).clone()
}

fn routine_176(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1453_3 = Space::new();
  let mut v1453_3_cursor = (*s0).read_zipper();
  for v1453_3_byte in v1453_3_cursor.child_mask().iter() {
    v1453_3_cursor.descend_to_byte(v1453_3_byte);
    let v1453_3_tail = v1453_3_cursor.make_map();
    v1453_3_cursor.ascend(1);
    let v1453_3_head = Path::from_slice(&[v1453_3_byte]);
    let v1454_2: Space = Space::new();
    v1453_3.join_into((v1454_2).clone());
  }
  drop(v1453_3_cursor);
  (v1453_3).clone()
}

fn routine_177(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1455_4 = Space::new();
  let mut v1455_4_cursor = (*s0).read_zipper();
  for v1455_4_byte in v1455_4_cursor.child_mask().iter() {
    v1455_4_cursor.descend_to_byte(v1455_4_byte);
    let v1455_4_tail = v1455_4_cursor.make_map();
    v1455_4_cursor.ascend(1);
    let v1455_4_head = Path::from_slice(&[v1455_4_byte]);
    let v1456_2: Space = singleton(&(v1455_4_head));
    let v1456_3: Space = intersect(&(*CONSTANT_3),&(v1456_2));
    drop(v1456_2);
    let v1456_4: Space = if has_head(&(v1456_3)) { singleton(&[]) } else { Space::new() };
    drop(v1456_3);
    let v1456_5: Space = compose(&(v1456_4),&(v1455_4_tail));
    drop(v1456_4);
    let v1456_6: Path = concat_path(&(*p0),&(v1455_4_head));
    let v1456_7: Space = wrap(&(v1456_5),&(v1456_6));
    drop(v1456_5);
    drop(v1456_6);
    v1455_4.join_into((v1456_7).clone());
  }
  drop(v1455_4_cursor);
  let v1455_5: Space = wrap(&(v1455_4),&(*p1));
  drop(v1455_4);
  (v1455_5).clone()
}

fn routine_178(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1457_7 = Space::new();
  let mut v1457_7_cursor = (*s0).read_zipper();
  for v1457_7_byte in v1457_7_cursor.child_mask().iter() {
    v1457_7_cursor.descend_to_byte(v1457_7_byte);
    let v1457_7_tail = v1457_7_cursor.make_map();
    v1457_7_cursor.ascend(1);
    let v1457_7_head = Path::from_slice(&[v1457_7_byte]);
    let v1458_2: Space = singleton(&(v1457_7_head));
    let v1458_3: Space = intersect(&(*CONSTANT_3),&(v1458_2));
    let v1458_4: Space = if has_head(&(v1458_3)) { singleton(&[]) } else { Space::new() };
    drop(v1458_3);
    let v1458_5: Space = subtract(&(*CONSTANT_2),&(v1458_4));
    drop(v1458_4);
    let mut v1458_6 = Space::new();
    let mut v1458_6_cursor = (v1457_7_tail).read_zipper();
    for v1458_6_byte in v1458_6_cursor.child_mask().iter() {
      v1458_6_cursor.descend_to_byte(v1458_6_byte);
      let v1458_6_tail = v1458_6_cursor.make_map();
      v1458_6_cursor.ascend(1);
      let v1458_6_head = Path::from_slice(&[v1458_6_byte]);
      let v1459_2: Space = Space::new();
      v1458_6.join_into((v1459_2).clone());
    }
    drop(v1458_6_cursor);
    let v1458_7: Space = compose(&(v1458_5),&(v1458_6));
    drop(v1458_5);
    drop(v1458_6);
    let v1458_8: Space = intersect(&(*CONSTANT_3),&(v1458_2));
    drop(v1458_2);
    let v1458_9: Space = if has_head(&(v1458_8)) { singleton(&[]) } else { Space::new() };
    drop(v1458_8);
    let v1458_12: Space = if (v1458_9).is_empty() { Space::new() } else {
      let v1460_10: Path = concat_path(&(*p0),&(v1457_7_head));
      let mut v1460_11 = Space::new();
      let mut v1460_11_cursor = (v1457_7_tail).read_zipper();
      for v1460_11_byte in v1460_11_cursor.child_mask().iter() {
        v1460_11_cursor.descend_to_byte(v1460_11_byte);
        let v1460_11_tail = v1460_11_cursor.make_map();
        v1460_11_cursor.ascend(1);
        let v1460_11_head = Path::from_slice(&[v1460_11_byte]);
        let v1461_2: Space = singleton(&(v1460_11_head));
        let v1461_3: Space = intersect(&(*CONSTANT_3),&(v1461_2));
        drop(v1461_2);
        let v1461_4: Space = if has_head(&(v1461_3)) { singleton(&[]) } else { Space::new() };
        drop(v1461_3);
        let v1461_7: Space = if (v1461_4).is_empty() { Space::new() } else {
          let v1462_5: Path = concat_path(&(v1460_10),&(v1460_11_head));
          let v1462_6: Space = routine_95(c, &(v1462_5), &(*p1), &(v1460_11_tail));
          drop(v1462_5);
          compose(&(v1461_4),&(v1462_6))
        };
        drop(v1461_4);
        v1460_11.join_into((v1461_7).clone());
      }
      drop(v1460_11_cursor);
      drop(v1460_10);
      compose(&(v1458_9),&(v1460_11))
    };
    drop(v1458_9);
    let v1458_13: Space = unite(&(v1458_7),&(v1458_12));
    drop(v1458_7);
    v1457_7.join_into((v1458_13).clone());
  }
  drop(v1457_7_cursor);
  (v1457_7).clone()
}

fn routine_179(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1463_6 = Space::new();
  let mut v1463_6_cursor = (*s0).read_zipper();
  for v1463_6_byte in v1463_6_cursor.child_mask().iter() {
    v1463_6_cursor.descend_to_byte(v1463_6_byte);
    let v1463_6_tail = v1463_6_cursor.make_map();
    v1463_6_cursor.ascend(1);
    let v1463_6_head = Path::from_slice(&[v1463_6_byte]);
    let v1464_2: Space = singleton(&(v1463_6_head));
    let v1464_3: Space = intersect(&(*CONSTANT_3),&(v1464_2));
    let v1464_4: Space = if has_head(&(v1464_3)) { singleton(&[]) } else { Space::new() };
    drop(v1464_3);
    let v1464_5: Space = subtract(&(*CONSTANT_2),&(v1464_4));
    drop(v1464_4);
    let mut v1464_6 = Space::new();
    let mut v1464_6_cursor = (v1463_6_tail).read_zipper();
    for v1464_6_byte in v1464_6_cursor.child_mask().iter() {
      v1464_6_cursor.descend_to_byte(v1464_6_byte);
      let v1464_6_tail = v1464_6_cursor.make_map();
      v1464_6_cursor.ascend(1);
      let v1464_6_head = Path::from_slice(&[v1464_6_byte]);
      let v1465_2: Space = Space::new();
      v1464_6.join_into((v1465_2).clone());
    }
    drop(v1464_6_cursor);
    let v1464_7: Space = compose(&(v1464_5),&(v1464_6));
    drop(v1464_5);
    drop(v1464_6);
    let v1464_8: Space = intersect(&(*CONSTANT_3),&(v1464_2));
    drop(v1464_2);
    let v1464_9: Space = if has_head(&(v1464_8)) { singleton(&[]) } else { Space::new() };
    drop(v1464_8);
    let v1464_10: Space = compose(&(v1464_9),&(v1463_6_tail));
    drop(v1464_9);
    let v1464_11: Path = concat_path(&(*p0),&(v1463_6_head));
    let v1464_12: Space = wrap(&(v1464_10),&(v1464_11));
    drop(v1464_10);
    drop(v1464_11);
    let v1464_13: Space = wrap(&(v1464_12),&(*p1));
    drop(v1464_12);
    let v1464_14: Space = unite(&(v1464_7),&(v1464_13));
    drop(v1464_7);
    drop(v1464_13);
    v1463_6.join_into((v1464_14).clone());
  }
  drop(v1463_6_cursor);
  (v1463_6).clone()
}

fn routine_180(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1466_3 = Space::new();
  let mut v1466_3_cursor = (*s0).read_zipper();
  for v1466_3_byte in v1466_3_cursor.child_mask().iter() {
    v1466_3_cursor.descend_to_byte(v1466_3_byte);
    let v1466_3_tail = v1466_3_cursor.make_map();
    v1466_3_cursor.ascend(1);
    let v1466_3_head = Path::from_slice(&[v1466_3_byte]);
    let v1467_2: Space = Space::new();
    v1466_3.join_into((v1467_2).clone());
  }
  drop(v1466_3_cursor);
  (v1466_3).clone()
}

fn routine_181(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1468_4 = Space::new();
  let mut v1468_4_cursor = (*s0).read_zipper();
  for v1468_4_byte in v1468_4_cursor.child_mask().iter() {
    v1468_4_cursor.descend_to_byte(v1468_4_byte);
    let v1468_4_tail = v1468_4_cursor.make_map();
    v1468_4_cursor.ascend(1);
    let v1468_4_head = Path::from_slice(&[v1468_4_byte]);
    let v1469_2: Space = singleton(&(v1468_4_head));
    let v1469_3: Space = intersect(&(*CONSTANT_3),&(v1469_2));
    drop(v1469_2);
    let v1469_4: Space = if has_head(&(v1469_3)) { singleton(&[]) } else { Space::new() };
    drop(v1469_3);
    let v1469_5: Space = compose(&(v1469_4),&(v1468_4_tail));
    drop(v1469_4);
    let v1469_6: Path = concat_path(&(*p0),&(v1468_4_head));
    let v1469_7: Space = wrap(&(v1469_5),&(v1469_6));
    drop(v1469_5);
    drop(v1469_6);
    v1468_4.join_into((v1469_7).clone());
  }
  drop(v1468_4_cursor);
  let v1468_5: Space = wrap(&(v1468_4),&(*p1));
  drop(v1468_4);
  (v1468_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
