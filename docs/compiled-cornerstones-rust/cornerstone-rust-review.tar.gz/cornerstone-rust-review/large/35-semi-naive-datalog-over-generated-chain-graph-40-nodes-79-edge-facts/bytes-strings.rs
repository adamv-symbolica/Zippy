#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[99,111,109,112,108,101,116,101,0]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[101,100,103,101,0]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[100,101,108,116,97,0]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[112,97,116,104,0]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[99,111,109,112,108,101,116,101,0,112,97,116,104,0]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[100,101,108,116,97,0,112,97,116,104,0]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = wrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let v0_4: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_1));
  let mut v0_14 = Space::new();
  let mut v0_14_cursor = (v0_4).read_zipper();
  for v0_14_byte in v0_14_cursor.child_mask().iter() {
    v0_14_cursor.descend_to_byte(v0_14_byte);
    let v0_14_tail = v0_14_cursor.make_map();
    v0_14_cursor.ascend(1);
    let v0_14_head = Path::from_slice(&[v0_14_byte]);
    let v1_2: Space = singleton(&(v0_14_head));
    let v1_3: Space = intersect(&(*CONSTANT_3),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_2),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_14_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        let v2_6_tail = v2_6_cursor.make_map();
        v2_6_cursor.ascend(1);
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_3),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_2),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_14_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_3),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_14_head),&(v2_6_head));
          let v5_11: Space = routine_2(c, &(v5_6), &(v2_6_tail));
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_3),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_cursor = (v0_14_tail).read_zipper();
      for v6_10_byte in v6_10_cursor.child_mask().iter() {
        v6_10_cursor.descend_to_byte(v6_10_byte);
        let v6_10_tail = v6_10_cursor.make_map();
        v6_10_cursor.ascend(1);
        let v6_10_head = Path::from_slice(&[v6_10_byte]);
        let v7_2: Space = singleton(&(v6_10_head));
        let v7_3: Space = intersect(&(*CONSTANT_3),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_2),&(v7_4));
        drop(v7_4);
        let v7_7: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Space = routine_3(c, &(v6_10_head), &(v0_14_head), &(v6_10_tail));
          compose(&(v7_5),&(v8_6))
        };
        drop(v7_5);
        let v7_8: Space = intersect(&(*CONSTANT_3),&(v7_2));
        drop(v7_2);
        let v7_9: Space = if has_head(&(v7_8)) { singleton(&[]) } else { Space::new() };
        drop(v7_8);
        let v7_11: Space = if (v7_9).is_empty() { Space::new() } else {
          let v9_10: Space = routine_4(c, &(v6_10_head), &(v0_14_head), &(v6_10_tail));
          compose(&(v7_9),&(v9_10))
        };
        drop(v7_9);
        let v7_12: Space = unite(&(v7_7),&(v7_11));
        v6_10.join_into((v7_12).clone());
      }
      drop(v6_10_cursor);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_14.join_into((v1_12).clone());
  }
  drop(v0_14_cursor);
  drop(v0_4);
  let v0_16: Space = wrap(&(v0_14),&(*CONSTANT_4));
  let v0_17: Space = unite(&(v0_2),&(v0_16));
  drop(v0_2);
  let mut v0_57: Space = (v0_17).clone();
  loop {
    let v10_1: Space = unwrap(&(v0_57),&(*CONSTANT_0));
    let v10_2: Space = unwrap(&(v0_57),&(*CONSTANT_4));
    let v10_3: Space = unite(&(v10_1),&(v10_2));
    let v10_4: Space = wrap(&(v10_3),&(*CONSTANT_0));
    drop(v10_3);
    let v10_5: Space = unwrap(&(v10_1),&(*CONSTANT_1));
    let mut v10_6 = Space::new();
    let mut v10_6_cursor = (v10_5).read_zipper();
    for v10_6_byte in v10_6_cursor.child_mask().iter() {
      v10_6_cursor.descend_to_byte(v10_6_byte);
      let v10_6_tail = v10_6_cursor.make_map();
      v10_6_cursor.ascend(1);
      let v10_6_head = Path::from_slice(&[v10_6_byte]);
      let v11_2: Space = singleton(&(v10_6_head));
      let v11_3: Space = intersect(&(*CONSTANT_3),&(v11_2));
      let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
      drop(v11_3);
      let v11_5: Space = subtract(&(*CONSTANT_2),&(v11_4));
      drop(v11_4);
      let v11_7: Space = if (v11_5).is_empty() { Space::new() } else {
        let mut v12_6 = Space::new();
        let mut v12_6_cursor = (v10_6_tail).read_zipper();
        for v12_6_byte in v12_6_cursor.child_mask().iter() {
          v12_6_cursor.descend_to_byte(v12_6_byte);
          let v12_6_tail = v12_6_cursor.make_map();
          v12_6_cursor.ascend(1);
          let v12_6_head = Path::from_slice(&[v12_6_byte]);
          let v13_2: Space = singleton(&(v12_6_head));
          let v13_3: Space = intersect(&(*CONSTANT_3),&(v13_2));
          let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
          drop(v13_3);
          let v13_5: Space = subtract(&(*CONSTANT_2),&(v13_4));
          drop(v13_4);
          let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
            let v14_6: Path = concat_path(&(v10_6_head),&(v12_6_head));
            let v14_7: Space = routine_5(c, &(v14_6), &(v12_6_tail));
            compose(&(v13_5),&(v14_7))
          };
          drop(v13_5);
          let v13_9: Space = intersect(&(*CONSTANT_3),&(v13_2));
          drop(v13_2);
          let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
          drop(v13_9);
          let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
            let v15_6: Path = concat_path(&(v10_6_head),&(v12_6_head));
            let v15_11: Space = routine_6(c, &(v15_6), &(v12_6_tail));
            drop(v15_6);
            compose(&(v13_10),&(v15_11))
          };
          drop(v13_10);
          let v13_13: Space = unite(&(v13_8),&(v13_12));
          v12_6.join_into((v13_13).clone());
        }
        drop(v12_6_cursor);
        compose(&(v11_5),&(v12_6))
      };
      drop(v11_5);
      let v11_8: Space = intersect(&(*CONSTANT_3),&(v11_2));
      drop(v11_2);
      let v11_9: Space = if has_head(&(v11_8)) { singleton(&[]) } else { Space::new() };
      drop(v11_8);
      let v11_11: Space = if (v11_9).is_empty() { Space::new() } else {
        let mut v16_10 = Space::new();
        let mut v16_10_cursor = (v10_6_tail).read_zipper();
        for v16_10_byte in v16_10_cursor.child_mask().iter() {
          v16_10_cursor.descend_to_byte(v16_10_byte);
          let v16_10_tail = v16_10_cursor.make_map();
          v16_10_cursor.ascend(1);
          let v16_10_head = Path::from_slice(&[v16_10_byte]);
          let v17_2: Space = singleton(&(v16_10_head));
          let v17_3: Space = intersect(&(*CONSTANT_3),&(v17_2));
          let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
          drop(v17_3);
          let v17_5: Space = subtract(&(*CONSTANT_2),&(v17_4));
          drop(v17_4);
          let v17_7: Space = if (v17_5).is_empty() { Space::new() } else {
            let v18_6: Space = routine_7(c, &(v16_10_head), &(v10_6_head), &(v16_10_tail));
            compose(&(v17_5),&(v18_6))
          };
          drop(v17_5);
          let v17_8: Space = intersect(&(*CONSTANT_3),&(v17_2));
          drop(v17_2);
          let v17_9: Space = if has_head(&(v17_8)) { singleton(&[]) } else { Space::new() };
          drop(v17_8);
          let v17_11: Space = if (v17_9).is_empty() { Space::new() } else {
            let v19_10: Space = routine_8(c, &(v16_10_head), &(v10_6_head), &(v16_10_tail));
            compose(&(v17_9),&(v19_10))
          };
          drop(v17_9);
          let v17_12: Space = unite(&(v17_7),&(v17_11));
          v16_10.join_into((v17_12).clone());
        }
        drop(v16_10_cursor);
        compose(&(v11_9),&(v16_10))
      };
      drop(v11_9);
      let v11_12: Space = unite(&(v11_7),&(v11_11));
      v10_6.join_into((v11_12).clone());
    }
    drop(v10_6_cursor);
    drop(v10_5);
    let v10_7: Space = unwrap(&(v10_1),&(*CONSTANT_5));
    drop(v10_1);
    let mut v10_8 = Space::new();
    let mut v10_8_cursor = (v10_7).read_zipper();
    for v10_8_byte in v10_8_cursor.child_mask().iter() {
      v10_8_cursor.descend_to_byte(v10_8_byte);
      let v10_8_tail = v10_8_cursor.make_map();
      v10_8_cursor.ascend(1);
      let v10_8_head = Path::from_slice(&[v10_8_byte]);
      let v20_2: Space = singleton(&(v10_8_head));
      let v20_3: Space = intersect(&(*CONSTANT_3),&(v20_2));
      let v20_4: Space = if has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
      drop(v20_3);
      let v20_5: Space = subtract(&(*CONSTANT_2),&(v20_4));
      drop(v20_4);
      let v20_7: Space = if (v20_5).is_empty() { Space::new() } else {
        let mut v21_6 = Space::new();
        let mut v21_6_cursor = (v10_8_tail).read_zipper();
        for v21_6_byte in v21_6_cursor.child_mask().iter() {
          v21_6_cursor.descend_to_byte(v21_6_byte);
          let v21_6_tail = v21_6_cursor.make_map();
          v21_6_cursor.ascend(1);
          let v21_6_head = Path::from_slice(&[v21_6_byte]);
          let v22_2: Space = singleton(&(v21_6_head));
          let v22_3: Space = intersect(&(*CONSTANT_3),&(v22_2));
          let v22_4: Space = if has_head(&(v22_3)) { singleton(&[]) } else { Space::new() };
          drop(v22_3);
          let v22_5: Space = subtract(&(*CONSTANT_2),&(v22_4));
          drop(v22_4);
          let v22_8: Space = if (v22_5).is_empty() { Space::new() } else {
            let v23_6: Path = concat_path(&(v10_8_head),&(v21_6_head));
            let v23_7: Space = routine_9(c, &(v23_6), &(v21_6_tail), &(v0_57));
            compose(&(v22_5),&(v23_7))
          };
          drop(v22_5);
          let v22_9: Space = intersect(&(*CONSTANT_3),&(v22_2));
          drop(v22_2);
          let v22_10: Space = if has_head(&(v22_9)) { singleton(&[]) } else { Space::new() };
          drop(v22_9);
          let v22_12: Space = if (v22_10).is_empty() { Space::new() } else {
            let v24_6: Path = concat_path(&(v10_8_head),&(v21_6_head));
            let v24_11: Space = routine_10(c, &(v24_6), &(v21_6_tail), &(v0_57));
            drop(v24_6);
            compose(&(v22_10),&(v24_11))
          };
          drop(v22_10);
          let v22_13: Space = unite(&(v22_8),&(v22_12));
          v21_6.join_into((v22_13).clone());
        }
        drop(v21_6_cursor);
        compose(&(v20_5),&(v21_6))
      };
      drop(v20_5);
      let v20_8: Space = intersect(&(*CONSTANT_3),&(v20_2));
      drop(v20_2);
      let v20_9: Space = if has_head(&(v20_8)) { singleton(&[]) } else { Space::new() };
      drop(v20_8);
      let v20_11: Space = if (v20_9).is_empty() { Space::new() } else {
        let mut v25_10 = Space::new();
        let mut v25_10_cursor = (v10_8_tail).read_zipper();
        for v25_10_byte in v25_10_cursor.child_mask().iter() {
          v25_10_cursor.descend_to_byte(v25_10_byte);
          let v25_10_tail = v25_10_cursor.make_map();
          v25_10_cursor.ascend(1);
          let v25_10_head = Path::from_slice(&[v25_10_byte]);
          let v26_2: Space = singleton(&(v25_10_head));
          let v26_3: Space = intersect(&(*CONSTANT_3),&(v26_2));
          let v26_4: Space = if has_head(&(v26_3)) { singleton(&[]) } else { Space::new() };
          drop(v26_3);
          let v26_5: Space = subtract(&(*CONSTANT_2),&(v26_4));
          drop(v26_4);
          let v26_7: Space = if (v26_5).is_empty() { Space::new() } else {
            let v27_6: Space = routine_11(c, &(v25_10_head), &(v10_8_head), &(v25_10_tail), &(v0_57));
            compose(&(v26_5),&(v27_6))
          };
          drop(v26_5);
          let v26_8: Space = intersect(&(*CONSTANT_3),&(v26_2));
          drop(v26_2);
          let v26_9: Space = if has_head(&(v26_8)) { singleton(&[]) } else { Space::new() };
          drop(v26_8);
          let v26_11: Space = if (v26_9).is_empty() { Space::new() } else {
            let v28_10: Space = routine_12(c, &(v25_10_head), &(v10_8_head), &(v25_10_tail), &(v0_57));
            compose(&(v26_9),&(v28_10))
          };
          drop(v26_9);
          let v26_12: Space = unite(&(v26_7),&(v26_11));
          v25_10.join_into((v26_12).clone());
        }
        drop(v25_10_cursor);
        compose(&(v20_9),&(v25_10))
      };
      drop(v20_9);
      let v20_12: Space = unite(&(v20_7),&(v20_11));
      v10_8.join_into((v20_12).clone());
    }
    drop(v10_8_cursor);
    drop(v10_7);
    let v10_9: Space = unite(&(v10_6),&(v10_8));
    let v10_10: Space = unwrap(&(v10_2),&(*CONSTANT_5));
    drop(v10_2);
    let mut v10_11 = Space::new();
    let mut v10_11_cursor = (v10_10).read_zipper();
    for v10_11_byte in v10_11_cursor.child_mask().iter() {
      v10_11_cursor.descend_to_byte(v10_11_byte);
      let v10_11_tail = v10_11_cursor.make_map();
      v10_11_cursor.ascend(1);
      let v10_11_head = Path::from_slice(&[v10_11_byte]);
      let v29_2: Space = singleton(&(v10_11_head));
      let v29_3: Space = intersect(&(*CONSTANT_3),&(v29_2));
      let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
      drop(v29_3);
      let v29_5: Space = subtract(&(*CONSTANT_2),&(v29_4));
      drop(v29_4);
      let v29_7: Space = if (v29_5).is_empty() { Space::new() } else {
        let mut v30_6 = Space::new();
        let mut v30_6_cursor = (v10_11_tail).read_zipper();
        for v30_6_byte in v30_6_cursor.child_mask().iter() {
          v30_6_cursor.descend_to_byte(v30_6_byte);
          let v30_6_tail = v30_6_cursor.make_map();
          v30_6_cursor.ascend(1);
          let v30_6_head = Path::from_slice(&[v30_6_byte]);
          let v31_2: Space = singleton(&(v30_6_head));
          let v31_3: Space = intersect(&(*CONSTANT_3),&(v31_2));
          let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
          drop(v31_3);
          let v31_5: Space = subtract(&(*CONSTANT_2),&(v31_4));
          drop(v31_4);
          let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
            let v32_6: Path = concat_path(&(v10_11_head),&(v30_6_head));
            let v32_7: Space = routine_13(c, &(v32_6), &(v30_6_tail), &(v0_57));
            compose(&(v31_5),&(v32_7))
          };
          drop(v31_5);
          let v31_9: Space = intersect(&(*CONSTANT_3),&(v31_2));
          drop(v31_2);
          let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
          drop(v31_9);
          let v31_12: Space = if (v31_10).is_empty() { Space::new() } else {
            let v33_6: Path = concat_path(&(v10_11_head),&(v30_6_head));
            let v33_11: Space = routine_14(c, &(v33_6), &(v30_6_tail), &(v0_57));
            drop(v33_6);
            compose(&(v31_10),&(v33_11))
          };
          drop(v31_10);
          let v31_13: Space = unite(&(v31_8),&(v31_12));
          v30_6.join_into((v31_13).clone());
        }
        drop(v30_6_cursor);
        compose(&(v29_5),&(v30_6))
      };
      drop(v29_5);
      let v29_8: Space = intersect(&(*CONSTANT_3),&(v29_2));
      drop(v29_2);
      let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
      drop(v29_8);
      let v29_11: Space = if (v29_9).is_empty() { Space::new() } else {
        let mut v34_10 = Space::new();
        let mut v34_10_cursor = (v10_11_tail).read_zipper();
        for v34_10_byte in v34_10_cursor.child_mask().iter() {
          v34_10_cursor.descend_to_byte(v34_10_byte);
          let v34_10_tail = v34_10_cursor.make_map();
          v34_10_cursor.ascend(1);
          let v34_10_head = Path::from_slice(&[v34_10_byte]);
          let v35_2: Space = singleton(&(v34_10_head));
          let v35_3: Space = intersect(&(*CONSTANT_3),&(v35_2));
          let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
          drop(v35_3);
          let v35_5: Space = subtract(&(*CONSTANT_2),&(v35_4));
          drop(v35_4);
          let v35_7: Space = if (v35_5).is_empty() { Space::new() } else {
            let v36_6: Space = routine_15(c, &(v34_10_head), &(v10_11_head), &(v34_10_tail), &(v0_57));
            compose(&(v35_5),&(v36_6))
          };
          drop(v35_5);
          let v35_8: Space = intersect(&(*CONSTANT_3),&(v35_2));
          drop(v35_2);
          let v35_9: Space = if has_head(&(v35_8)) { singleton(&[]) } else { Space::new() };
          drop(v35_8);
          let v35_11: Space = if (v35_9).is_empty() { Space::new() } else {
            let v37_10: Space = routine_16(c, &(v34_10_head), &(v10_11_head), &(v34_10_tail), &(v0_57));
            compose(&(v35_9),&(v37_10))
          };
          drop(v35_9);
          let v35_12: Space = unite(&(v35_7),&(v35_11));
          v34_10.join_into((v35_12).clone());
        }
        drop(v34_10_cursor);
        compose(&(v29_9),&(v34_10))
      };
      drop(v29_9);
      let v29_12: Space = unite(&(v29_7),&(v29_11));
      v10_11.join_into((v29_12).clone());
    }
    drop(v10_11_cursor);
    let v10_12: Space = unite(&(v10_9),&(v10_11));
    let mut v10_13 = Space::new();
    let mut v10_13_cursor = (v10_10).read_zipper();
    for v10_13_byte in v10_13_cursor.child_mask().iter() {
      v10_13_cursor.descend_to_byte(v10_13_byte);
      let v10_13_tail = v10_13_cursor.make_map();
      v10_13_cursor.ascend(1);
      let v10_13_head = Path::from_slice(&[v10_13_byte]);
      let v38_2: Space = singleton(&(v10_13_head));
      let v38_3: Space = intersect(&(*CONSTANT_3),&(v38_2));
      let v38_4: Space = if has_head(&(v38_3)) { singleton(&[]) } else { Space::new() };
      drop(v38_3);
      let v38_5: Space = subtract(&(*CONSTANT_2),&(v38_4));
      drop(v38_4);
      let v38_7: Space = if (v38_5).is_empty() { Space::new() } else {
        let mut v39_6 = Space::new();
        let mut v39_6_cursor = (v10_13_tail).read_zipper();
        for v39_6_byte in v39_6_cursor.child_mask().iter() {
          v39_6_cursor.descend_to_byte(v39_6_byte);
          let v39_6_tail = v39_6_cursor.make_map();
          v39_6_cursor.ascend(1);
          let v39_6_head = Path::from_slice(&[v39_6_byte]);
          let v40_2: Space = singleton(&(v39_6_head));
          let v40_3: Space = intersect(&(*CONSTANT_3),&(v40_2));
          let v40_4: Space = if has_head(&(v40_3)) { singleton(&[]) } else { Space::new() };
          drop(v40_3);
          let v40_5: Space = subtract(&(*CONSTANT_2),&(v40_4));
          drop(v40_4);
          let v40_8: Space = if (v40_5).is_empty() { Space::new() } else {
            let v41_6: Path = concat_path(&(v10_13_head),&(v39_6_head));
            let v41_7: Space = routine_17(c, &(v41_6), &(v39_6_tail), &(v0_57));
            compose(&(v40_5),&(v41_7))
          };
          drop(v40_5);
          let v40_9: Space = intersect(&(*CONSTANT_3),&(v40_2));
          drop(v40_2);
          let v40_10: Space = if has_head(&(v40_9)) { singleton(&[]) } else { Space::new() };
          drop(v40_9);
          let v40_12: Space = if (v40_10).is_empty() { Space::new() } else {
            let v42_6: Path = concat_path(&(v10_13_head),&(v39_6_head));
            let v42_11: Space = routine_18(c, &(v42_6), &(v39_6_tail), &(v0_57));
            drop(v42_6);
            compose(&(v40_10),&(v42_11))
          };
          drop(v40_10);
          let v40_13: Space = unite(&(v40_8),&(v40_12));
          v39_6.join_into((v40_13).clone());
        }
        drop(v39_6_cursor);
        compose(&(v38_5),&(v39_6))
      };
      drop(v38_5);
      let v38_8: Space = intersect(&(*CONSTANT_3),&(v38_2));
      drop(v38_2);
      let v38_9: Space = if has_head(&(v38_8)) { singleton(&[]) } else { Space::new() };
      drop(v38_8);
      let v38_11: Space = if (v38_9).is_empty() { Space::new() } else {
        let mut v43_10 = Space::new();
        let mut v43_10_cursor = (v10_13_tail).read_zipper();
        for v43_10_byte in v43_10_cursor.child_mask().iter() {
          v43_10_cursor.descend_to_byte(v43_10_byte);
          let v43_10_tail = v43_10_cursor.make_map();
          v43_10_cursor.ascend(1);
          let v43_10_head = Path::from_slice(&[v43_10_byte]);
          let v44_2: Space = singleton(&(v43_10_head));
          let v44_3: Space = intersect(&(*CONSTANT_3),&(v44_2));
          let v44_4: Space = if has_head(&(v44_3)) { singleton(&[]) } else { Space::new() };
          drop(v44_3);
          let v44_5: Space = subtract(&(*CONSTANT_2),&(v44_4));
          drop(v44_4);
          let v44_7: Space = if (v44_5).is_empty() { Space::new() } else {
            let v45_6: Space = routine_19(c, &(v43_10_head), &(v10_13_head), &(v43_10_tail), &(v0_57));
            compose(&(v44_5),&(v45_6))
          };
          drop(v44_5);
          let v44_8: Space = intersect(&(*CONSTANT_3),&(v44_2));
          drop(v44_2);
          let v44_9: Space = if has_head(&(v44_8)) { singleton(&[]) } else { Space::new() };
          drop(v44_8);
          let v44_11: Space = if (v44_9).is_empty() { Space::new() } else {
            let v46_10: Space = routine_20(c, &(v43_10_head), &(v10_13_head), &(v43_10_tail), &(v0_57));
            compose(&(v44_9),&(v46_10))
          };
          drop(v44_9);
          let v44_12: Space = unite(&(v44_7),&(v44_11));
          v43_10.join_into((v44_12).clone());
        }
        drop(v43_10_cursor);
        compose(&(v38_9),&(v43_10))
      };
      drop(v38_9);
      let v38_12: Space = unite(&(v38_7),&(v38_11));
      v10_13.join_into((v38_12).clone());
    }
    drop(v10_13_cursor);
    drop(v10_10);
    let v10_14: Space = unite(&(v10_12),&(v10_13));
    let v10_15: Space = unwrap(&(v0_57),&(*CONSTANT_6));
    let v10_16: Space = subtract(&(v10_14),&(v10_15));
    drop(v10_15);
    let v10_17: Space = unwrap(&(v0_57),&(*CONSTANT_7));
    let v10_18: Space = subtract(&(v10_16),&(v10_17));
    drop(v10_17);
    let v10_19: Space = wrap(&(v10_18),&(*CONSTANT_7));
    let v10_20: Space = unite(&(v10_4),&(v10_19));
    drop(v10_4);
    let v10_21: Space = unite(&(v10_20),&(v0_57));
    let v0_57_next = unite(&v0_57,&(v10_21));
    if equal(&v0_57_next,&v0_57) { break; }
    v0_57 = v0_57_next;
  }
  let v0_58: Space = unwrap(&(v0_57),&(*CONSTANT_6));
  (v0_58).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v47_8 = Space::new();
  let mut v47_8_cursor = (*s0).read_zipper();
  for v47_8_byte in v47_8_cursor.child_mask().iter() {
    v47_8_cursor.descend_to_byte(v47_8_byte);
    let v47_8_tail = v47_8_cursor.make_map();
    v47_8_cursor.ascend(1);
    let v47_8_head = Path::from_slice(&[v47_8_byte]);
    let v48_2: Space = singleton(&(v47_8_head));
    let v48_3: Space = intersect(&(*CONSTANT_3),&(v48_2));
    let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
    drop(v48_3);
    let v48_5: Space = subtract(&(*CONSTANT_2),&(v48_4));
    drop(v48_4);
    let v48_8: Space = if (v48_5).is_empty() { Space::new() } else {
      let v49_6: Path = concat_path(&(*p0),&(v47_8_head));
      let v49_7: Space = routine_1(c, &(v49_6), &(v47_8_tail));
      compose(&(v48_5),&(v49_7))
    };
    drop(v48_5);
    let v48_9: Space = intersect(&(*CONSTANT_3),&(v48_2));
    drop(v48_2);
    let v48_10: Space = if has_head(&(v48_9)) { singleton(&[]) } else { Space::new() };
    drop(v48_9);
    let v48_12: Space = if (v48_10).is_empty() { Space::new() } else {
      let v50_6: Path = concat_path(&(*p0),&(v47_8_head));
      let mut v50_11 = Space::new();
      let mut v50_11_cursor = (v47_8_tail).read_zipper();
      for v50_11_byte in v50_11_cursor.child_mask().iter() {
        v50_11_cursor.descend_to_byte(v50_11_byte);
        let v50_11_tail = v50_11_cursor.make_map();
        v50_11_cursor.ascend(1);
        let v50_11_head = Path::from_slice(&[v50_11_byte]);
        let v51_2: Space = singleton(&(v50_11_head));
        let v51_3: Space = intersect(&(*CONSTANT_3),&(v51_2));
        let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
        drop(v51_3);
        let v51_5: Space = subtract(&(*CONSTANT_2),&(v51_4));
        drop(v51_4);
        let v51_7: Space = if (v51_5).is_empty() { Space::new() } else {
          let v52_6: Space = routine_3(c, &(v50_11_head), &(v50_6), &(v50_11_tail));
          compose(&(v51_5),&(v52_6))
        };
        drop(v51_5);
        let v51_8: Space = intersect(&(*CONSTANT_3),&(v51_2));
        drop(v51_2);
        let v51_9: Space = if has_head(&(v51_8)) { singleton(&[]) } else { Space::new() };
        drop(v51_8);
        let v51_11: Space = if (v51_9).is_empty() { Space::new() } else {
          let v53_10: Space = routine_4(c, &(v50_11_head), &(v50_6), &(v50_11_tail));
          compose(&(v51_9),&(v53_10))
        };
        drop(v51_9);
        let v51_12: Space = unite(&(v51_7),&(v51_11));
        v50_11.join_into((v51_12).clone());
      }
      drop(v50_11_cursor);
      drop(v50_6);
      compose(&(v48_10),&(v50_11))
    };
    drop(v48_10);
    let v48_13: Space = unite(&(v48_8),&(v48_12));
    v47_8.join_into((v48_13).clone());
  }
  drop(v47_8_cursor);
  (v47_8).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v54_9 = Space::new();
  let mut v54_9_cursor = (*s0).read_zipper();
  for v54_9_byte in v54_9_cursor.child_mask().iter() {
    v54_9_cursor.descend_to_byte(v54_9_byte);
    let v54_9_tail = v54_9_cursor.make_map();
    v54_9_cursor.ascend(1);
    let v54_9_head = Path::from_slice(&[v54_9_byte]);
    let v55_2: Space = singleton(&(v54_9_head));
    let v55_3: Space = intersect(&(*CONSTANT_3),&(v55_2));
    let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
    drop(v55_3);
    let v55_5: Space = compose(&(v55_4),&(v54_9_tail));
    drop(v55_4);
    let v55_6: Space = wrap(&(v55_5),&(v54_9_head));
    drop(v55_5);
    let v55_7: Space = wrap(&(v55_6),&(*p0));
    drop(v55_6);
    let v55_8: Space = wrap(&(v55_7),&(*CONSTANT_5));
    drop(v55_7);
    let v55_9: Space = intersect(&(*CONSTANT_3),&(v55_2));
    drop(v55_2);
    let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
    drop(v55_9);
    let v55_11: Space = subtract(&(*CONSTANT_2),&(v55_10));
    drop(v55_10);
    let v55_13: Space = if (v55_11).is_empty() { Space::new() } else {
      let mut v56_12 = Space::new();
      let mut v56_12_cursor = (v54_9_tail).read_zipper();
      for v56_12_byte in v56_12_cursor.child_mask().iter() {
        v56_12_cursor.descend_to_byte(v56_12_byte);
        let v56_12_tail = v56_12_cursor.make_map();
        v56_12_cursor.ascend(1);
        let v56_12_head = Path::from_slice(&[v56_12_byte]);
        let v57_2: Space = singleton(&(v56_12_head));
        let v57_3: Space = intersect(&(*CONSTANT_3),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_2),&(v57_4));
        drop(v57_4);
        let v57_8: Space = if (v57_5).is_empty() { Space::new() } else {
          let v58_6: Path = concat_path(&(v54_9_head),&(v56_12_head));
          let v58_7: Space = routine_3(c, &(v58_6), &(*p0), &(v56_12_tail));
          compose(&(v57_5),&(v58_7))
        };
        drop(v57_5);
        let v57_9: Space = intersect(&(*CONSTANT_3),&(v57_2));
        drop(v57_2);
        let v57_10: Space = if has_head(&(v57_9)) { singleton(&[]) } else { Space::new() };
        drop(v57_9);
        let v57_12: Space = if (v57_10).is_empty() { Space::new() } else {
          let v59_6: Path = concat_path(&(v54_9_head),&(v56_12_head));
          let v59_11: Space = routine_4(c, &(v59_6), &(*p0), &(v56_12_tail));
          drop(v59_6);
          compose(&(v57_10),&(v59_11))
        };
        drop(v57_10);
        let v57_13: Space = unite(&(v57_8),&(v57_12));
        v56_12.join_into((v57_13).clone());
      }
      drop(v56_12_cursor);
      compose(&(v55_11),&(v56_12))
    };
    drop(v55_11);
    let v55_14: Space = unite(&(v55_8),&(v55_13));
    drop(v55_8);
    v54_9.join_into((v55_14).clone());
  }
  drop(v54_9_cursor);
  (v54_9).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v60_7 = Space::new();
  let mut v60_7_cursor = (*s0).read_zipper();
  for v60_7_byte in v60_7_cursor.child_mask().iter() {
    v60_7_cursor.descend_to_byte(v60_7_byte);
    let v60_7_tail = v60_7_cursor.make_map();
    v60_7_cursor.ascend(1);
    let v60_7_head = Path::from_slice(&[v60_7_byte]);
    let v61_2: Space = singleton(&(v60_7_head));
    let v61_3: Space = intersect(&(*CONSTANT_3),&(v61_2));
    let v61_4: Space = if has_head(&(v61_3)) { singleton(&[]) } else { Space::new() };
    drop(v61_3);
    let v61_5: Space = compose(&(v61_4),&(v60_7_tail));
    drop(v61_4);
    let v62_6: Path = concat_path(&(*p0),&(v60_7_head));
    let v61_7: Space = wrap(&(v61_5),&(v62_6));
    drop(v61_5);
    let v61_8: Space = wrap(&(v61_7),&(*p1));
    drop(v61_7);
    let v61_9: Space = wrap(&(v61_8),&(*CONSTANT_5));
    drop(v61_8);
    let v61_10: Space = intersect(&(*CONSTANT_3),&(v61_2));
    drop(v61_2);
    let v61_11: Space = if has_head(&(v61_10)) { singleton(&[]) } else { Space::new() };
    drop(v61_10);
    let v61_12: Space = subtract(&(*CONSTANT_2),&(v61_11));
    drop(v61_11);
    let v61_14: Space = if (v61_12).is_empty() { Space::new() } else {
      let v63_13: Space = routine_3(c, &(v62_6), &(*p1), &(v60_7_tail));
      compose(&(v61_12),&(v63_13))
    };
    drop(v61_12);
    let v61_15: Space = unite(&(v61_9),&(v61_14));
    drop(v61_9);
    v60_7.join_into((v61_15).clone());
  }
  drop(v60_7_cursor);
  (v60_7).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v64_3: Space = wrap(&(*s0),&(*p0));
  let v64_4: Space = wrap(&(v64_3),&(*p1));
  drop(v64_3);
  let v64_6: Space = wrap(&(v64_4),&(*CONSTANT_5));
  drop(v64_4);
  (v64_6).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v65_8 = Space::new();
  let mut v65_8_cursor = (*s0).read_zipper();
  for v65_8_byte in v65_8_cursor.child_mask().iter() {
    v65_8_cursor.descend_to_byte(v65_8_byte);
    let v65_8_tail = v65_8_cursor.make_map();
    v65_8_cursor.ascend(1);
    let v65_8_head = Path::from_slice(&[v65_8_byte]);
    let v66_2: Space = singleton(&(v65_8_head));
    let v66_3: Space = intersect(&(*CONSTANT_3),&(v66_2));
    let v66_4: Space = if has_head(&(v66_3)) { singleton(&[]) } else { Space::new() };
    drop(v66_3);
    let v66_5: Space = subtract(&(*CONSTANT_2),&(v66_4));
    drop(v66_4);
    let v66_8: Space = if (v66_5).is_empty() { Space::new() } else {
      let v67_6: Path = concat_path(&(*p0),&(v65_8_head));
      let v67_7: Space = routine_5(c, &(v67_6), &(v65_8_tail));
      compose(&(v66_5),&(v67_7))
    };
    drop(v66_5);
    let v66_9: Space = intersect(&(*CONSTANT_3),&(v66_2));
    drop(v66_2);
    let v66_10: Space = if has_head(&(v66_9)) { singleton(&[]) } else { Space::new() };
    drop(v66_9);
    let v66_12: Space = if (v66_10).is_empty() { Space::new() } else {
      let v68_6: Path = concat_path(&(*p0),&(v65_8_head));
      let mut v68_11 = Space::new();
      let mut v68_11_cursor = (v65_8_tail).read_zipper();
      for v68_11_byte in v68_11_cursor.child_mask().iter() {
        v68_11_cursor.descend_to_byte(v68_11_byte);
        let v68_11_tail = v68_11_cursor.make_map();
        v68_11_cursor.ascend(1);
        let v68_11_head = Path::from_slice(&[v68_11_byte]);
        let v69_2: Space = singleton(&(v68_11_head));
        let v69_3: Space = intersect(&(*CONSTANT_3),&(v69_2));
        let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
        drop(v69_3);
        let v69_5: Space = subtract(&(*CONSTANT_2),&(v69_4));
        drop(v69_4);
        let v69_7: Space = if (v69_5).is_empty() { Space::new() } else {
          let v70_6: Space = routine_7(c, &(v68_11_head), &(v68_6), &(v68_11_tail));
          compose(&(v69_5),&(v70_6))
        };
        drop(v69_5);
        let v69_8: Space = intersect(&(*CONSTANT_3),&(v69_2));
        drop(v69_2);
        let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
        drop(v69_8);
        let v69_11: Space = if (v69_9).is_empty() { Space::new() } else {
          let v71_10: Space = routine_8(c, &(v68_11_head), &(v68_6), &(v68_11_tail));
          compose(&(v69_9),&(v71_10))
        };
        drop(v69_9);
        let v69_12: Space = unite(&(v69_7),&(v69_11));
        v68_11.join_into((v69_12).clone());
      }
      drop(v68_11_cursor);
      drop(v68_6);
      compose(&(v66_10),&(v68_11))
    };
    drop(v66_10);
    let v66_13: Space = unite(&(v66_8),&(v66_12));
    v65_8.join_into((v66_13).clone());
  }
  drop(v65_8_cursor);
  (v65_8).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v72_8 = Space::new();
  let mut v72_8_cursor = (*s0).read_zipper();
  for v72_8_byte in v72_8_cursor.child_mask().iter() {
    v72_8_cursor.descend_to_byte(v72_8_byte);
    let v72_8_tail = v72_8_cursor.make_map();
    v72_8_cursor.ascend(1);
    let v72_8_head = Path::from_slice(&[v72_8_byte]);
    let v73_2: Space = singleton(&(v72_8_head));
    let v73_3: Space = intersect(&(*CONSTANT_3),&(v73_2));
    let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
    drop(v73_3);
    let v73_5: Space = subtract(&(*CONSTANT_2),&(v73_4));
    drop(v73_4);
    let v73_7: Space = if (v73_5).is_empty() { Space::new() } else {
      let mut v74_6 = Space::new();
      let mut v74_6_cursor = (v72_8_tail).read_zipper();
      for v74_6_byte in v74_6_cursor.child_mask().iter() {
        v74_6_cursor.descend_to_byte(v74_6_byte);
        let v74_6_tail = v74_6_cursor.make_map();
        v74_6_cursor.ascend(1);
        let v74_6_head = Path::from_slice(&[v74_6_byte]);
        let v75_2: Space = singleton(&(v74_6_head));
        let v75_3: Space = intersect(&(*CONSTANT_3),&(v75_2));
        let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
        drop(v75_3);
        let v75_5: Space = subtract(&(*CONSTANT_2),&(v75_4));
        drop(v75_4);
        let v75_8: Space = if (v75_5).is_empty() { Space::new() } else {
          let v76_6: Path = concat_path(&(v72_8_head),&(v74_6_head));
          let v76_7: Space = routine_7(c, &(v76_6), &(*p0), &(v74_6_tail));
          compose(&(v75_5),&(v76_7))
        };
        drop(v75_5);
        let v75_9: Space = intersect(&(*CONSTANT_3),&(v75_2));
        drop(v75_2);
        let v75_10: Space = if has_head(&(v75_9)) { singleton(&[]) } else { Space::new() };
        drop(v75_9);
        let v75_12: Space = if (v75_10).is_empty() { Space::new() } else {
          let v77_6: Path = concat_path(&(v72_8_head),&(v74_6_head));
          let v77_11: Space = routine_8(c, &(v77_6), &(*p0), &(v74_6_tail));
          drop(v77_6);
          compose(&(v75_10),&(v77_11))
        };
        drop(v75_10);
        let v75_13: Space = unite(&(v75_8),&(v75_12));
        v74_6.join_into((v75_13).clone());
      }
      drop(v74_6_cursor);
      compose(&(v73_5),&(v74_6))
    };
    drop(v73_5);
    let v73_8: Space = intersect(&(*CONSTANT_3),&(v73_2));
    drop(v73_2);
    let v73_9: Space = if has_head(&(v73_8)) { singleton(&[]) } else { Space::new() };
    drop(v73_8);
    let v73_10: Space = compose(&(v73_9),&(v72_8_tail));
    drop(v73_9);
    let v73_11: Space = wrap(&(v73_10),&(v72_8_head));
    drop(v73_10);
    let v73_12: Space = wrap(&(v73_11),&(*p0));
    drop(v73_11);
    let v73_13: Space = unite(&(v73_7),&(v73_12));
    drop(v73_12);
    v72_8.join_into((v73_13).clone());
  }
  drop(v72_8_cursor);
  (v72_8).clone()
}

fn routine_7(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v78_6 = Space::new();
  let mut v78_6_cursor = (*s0).read_zipper();
  for v78_6_byte in v78_6_cursor.child_mask().iter() {
    v78_6_cursor.descend_to_byte(v78_6_byte);
    let v78_6_tail = v78_6_cursor.make_map();
    v78_6_cursor.ascend(1);
    let v78_6_head = Path::from_slice(&[v78_6_byte]);
    let v79_2: Space = singleton(&(v78_6_head));
    let v79_3: Space = intersect(&(*CONSTANT_3),&(v79_2));
    let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
    drop(v79_3);
    let v79_5: Space = subtract(&(*CONSTANT_2),&(v79_4));
    drop(v79_4);
    let v79_8: Space = if (v79_5).is_empty() { Space::new() } else {
      let v80_6: Path = concat_path(&(*p0),&(v78_6_head));
      let v80_7: Space = routine_7(c, &(v80_6), &(*p1), &(v78_6_tail));
      compose(&(v79_5),&(v80_7))
    };
    drop(v79_5);
    let v79_9: Space = intersect(&(*CONSTANT_3),&(v79_2));
    drop(v79_2);
    let v79_10: Space = if has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
    drop(v79_9);
    let v79_11: Space = compose(&(v79_10),&(v78_6_tail));
    drop(v79_10);
    let v81_6: Path = concat_path(&(*p0),&(v78_6_head));
    let v79_12: Space = wrap(&(v79_11),&(v81_6));
    drop(v79_11);
    let v79_13: Space = wrap(&(v79_12),&(*p1));
    drop(v79_12);
    let v79_14: Space = unite(&(v79_8),&(v79_13));
    drop(v79_13);
    v78_6.join_into((v79_14).clone());
  }
  drop(v78_6_cursor);
  (v78_6).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v82_3: Space = wrap(&(*s0),&(*p0));
  let v82_4: Space = wrap(&(v82_3),&(*p1));
  drop(v82_3);
  (v82_4).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v83_9 = Space::new();
  let mut v83_9_cursor = (*s0).read_zipper();
  for v83_9_byte in v83_9_cursor.child_mask().iter() {
    v83_9_cursor.descend_to_byte(v83_9_byte);
    let v83_9_tail = v83_9_cursor.make_map();
    v83_9_cursor.ascend(1);
    let v83_9_head = Path::from_slice(&[v83_9_byte]);
    let v84_2: Space = singleton(&(v83_9_head));
    let v84_3: Space = intersect(&(*CONSTANT_3),&(v84_2));
    let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
    drop(v84_3);
    let v84_5: Space = subtract(&(*CONSTANT_2),&(v84_4));
    drop(v84_4);
    let v84_8: Space = if (v84_5).is_empty() { Space::new() } else {
      let v85_6: Path = concat_path(&(*p0),&(v83_9_head));
      let v85_7: Space = routine_9(c, &(v85_6), &(v83_9_tail), &(*s1));
      compose(&(v84_5),&(v85_7))
    };
    drop(v84_5);
    let v84_9: Space = intersect(&(*CONSTANT_3),&(v84_2));
    drop(v84_2);
    let v84_10: Space = if has_head(&(v84_9)) { singleton(&[]) } else { Space::new() };
    drop(v84_9);
    let v84_12: Space = if (v84_10).is_empty() { Space::new() } else {
      let v86_6: Path = concat_path(&(*p0),&(v83_9_head));
      let mut v86_11 = Space::new();
      let mut v86_11_cursor = (v83_9_tail).read_zipper();
      for v86_11_byte in v86_11_cursor.child_mask().iter() {
        v86_11_cursor.descend_to_byte(v86_11_byte);
        let v86_11_tail = v86_11_cursor.make_map();
        v86_11_cursor.ascend(1);
        let v86_11_head = Path::from_slice(&[v86_11_byte]);
        let v87_2: Space = singleton(&(v86_11_head));
        let v87_3: Space = intersect(&(*CONSTANT_3),&(v87_2));
        let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
        drop(v87_3);
        let v87_5: Space = subtract(&(*CONSTANT_2),&(v87_4));
        drop(v87_4);
        let v87_7: Space = if (v87_5).is_empty() { Space::new() } else {
          let v88_6: Space = routine_11(c, &(v86_11_head), &(v86_6), &(v86_11_tail), &(*s1));
          compose(&(v87_5),&(v88_6))
        };
        drop(v87_5);
        let v87_8: Space = intersect(&(*CONSTANT_3),&(v87_2));
        drop(v87_2);
        let v87_9: Space = if has_head(&(v87_8)) { singleton(&[]) } else { Space::new() };
        drop(v87_8);
        let v87_11: Space = if (v87_9).is_empty() { Space::new() } else {
          let v89_10: Space = routine_12(c, &(v86_11_head), &(v86_6), &(v86_11_tail), &(*s1));
          compose(&(v87_9),&(v89_10))
        };
        drop(v87_9);
        let v87_12: Space = unite(&(v87_7),&(v87_11));
        v86_11.join_into((v87_12).clone());
      }
      drop(v86_11_cursor);
      drop(v86_6);
      compose(&(v84_10),&(v86_11))
    };
    drop(v84_10);
    let v84_13: Space = unite(&(v84_8),&(v84_12));
    v83_9.join_into((v84_13).clone());
  }
  drop(v83_9_cursor);
  (v83_9).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v90_7: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v90_9: Space = unwrap(&(v90_7),&(*CONSTANT_5));
  drop(v90_7);
  let mut v90_16 = Space::new();
  let mut v90_16_cursor = (*s0).read_zipper();
  for v90_16_byte in v90_16_cursor.child_mask().iter() {
    v90_16_cursor.descend_to_byte(v90_16_byte);
    let v90_16_tail = v90_16_cursor.make_map();
    v90_16_cursor.ascend(1);
    let v90_16_head = Path::from_slice(&[v90_16_byte]);
    let v91_2: Space = singleton(&(v90_16_head));
    let v91_3: Space = intersect(&(*CONSTANT_3),&(v91_2));
    let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
    drop(v91_3);
    let v91_5: Space = subtract(&(*CONSTANT_2),&(v91_4));
    drop(v91_4);
    let v91_7: Space = if (v91_5).is_empty() { Space::new() } else {
      let mut v92_6 = Space::new();
      let mut v92_6_cursor = (v90_16_tail).read_zipper();
      for v92_6_byte in v92_6_cursor.child_mask().iter() {
        v92_6_cursor.descend_to_byte(v92_6_byte);
        let v92_6_tail = v92_6_cursor.make_map();
        v92_6_cursor.ascend(1);
        let v92_6_head = Path::from_slice(&[v92_6_byte]);
        let v93_2: Space = singleton(&(v92_6_head));
        let v93_3: Space = intersect(&(*CONSTANT_3),&(v93_2));
        let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
        drop(v93_3);
        let v93_5: Space = subtract(&(*CONSTANT_2),&(v93_4));
        drop(v93_4);
        let v93_8: Space = if (v93_5).is_empty() { Space::new() } else {
          let v94_6: Path = concat_path(&(v90_16_head),&(v92_6_head));
          let v94_7: Space = routine_11(c, &(v94_6), &(*p0), &(v92_6_tail), &(*s1));
          compose(&(v93_5),&(v94_7))
        };
        drop(v93_5);
        let v93_9: Space = intersect(&(*CONSTANT_3),&(v93_2));
        drop(v93_2);
        let v93_10: Space = if has_head(&(v93_9)) { singleton(&[]) } else { Space::new() };
        drop(v93_9);
        let v93_12: Space = if (v93_10).is_empty() { Space::new() } else {
          let v95_6: Path = concat_path(&(v90_16_head),&(v92_6_head));
          let v95_11: Space = routine_12(c, &(v95_6), &(*p0), &(v92_6_tail), &(*s1));
          drop(v95_6);
          compose(&(v93_10),&(v95_11))
        };
        drop(v93_10);
        let v93_13: Space = unite(&(v93_8),&(v93_12));
        v92_6.join_into((v93_13).clone());
      }
      drop(v92_6_cursor);
      compose(&(v91_5),&(v92_6))
    };
    drop(v91_5);
    let v91_8: Space = intersect(&(*CONSTANT_3),&(v91_2));
    drop(v91_2);
    let v91_9: Space = if has_head(&(v91_8)) { singleton(&[]) } else { Space::new() };
    drop(v91_8);
    let v91_12: Space = if (v91_9).is_empty() { Space::new() } else {
      let v96_10: Space = unwrap(&(v90_9),&(v90_16_head));
      let mut v96_11 = Space::new();
      let mut v96_11_cursor = (v96_10).read_zipper();
      for v96_11_byte in v96_11_cursor.child_mask().iter() {
        v96_11_cursor.descend_to_byte(v96_11_byte);
        let v96_11_tail = v96_11_cursor.make_map();
        v96_11_cursor.ascend(1);
        let v96_11_head = Path::from_slice(&[v96_11_byte]);
        let v97_2: Space = singleton(&(v96_11_head));
        let v97_3: Space = intersect(&(*CONSTANT_3),&(v97_2));
        let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
        drop(v97_3);
        let v97_5: Space = subtract(&(*CONSTANT_2),&(v97_4));
        drop(v97_4);
        let v97_7: Space = if (v97_5).is_empty() { Space::new() } else {
          let v98_6: Space = routine_21(c, &(v96_11_head), &(*p0), &(v96_11_tail));
          compose(&(v97_5),&(v98_6))
        };
        drop(v97_5);
        let v97_8: Space = intersect(&(*CONSTANT_3),&(v97_2));
        drop(v97_2);
        let v97_9: Space = if has_head(&(v97_8)) { singleton(&[]) } else { Space::new() };
        drop(v97_8);
        let v97_11: Space = if (v97_9).is_empty() { Space::new() } else {
          let v99_10: Space = routine_22(c, &(v96_11_head), &(*p0), &(v96_11_tail));
          compose(&(v97_9),&(v99_10))
        };
        drop(v97_9);
        let v97_12: Space = unite(&(v97_7),&(v97_11));
        v96_11.join_into((v97_12).clone());
      }
      drop(v96_11_cursor);
      drop(v96_10);
      compose(&(v91_9),&(v96_11))
    };
    drop(v91_9);
    let v91_13: Space = unite(&(v91_7),&(v91_12));
    v90_16.join_into((v91_13).clone());
  }
  drop(v90_16_cursor);
  drop(v90_9);
  (v90_16).clone()
}

fn routine_11(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v100_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v100_10: Space = unwrap(&(v100_8),&(*CONSTANT_5));
  drop(v100_8);
  let v100_11: Space = unwrap(&(v100_10),&(*p0));
  drop(v100_10);
  let mut v100_15 = Space::new();
  let mut v100_15_cursor = (*s0).read_zipper();
  for v100_15_byte in v100_15_cursor.child_mask().iter() {
    v100_15_cursor.descend_to_byte(v100_15_byte);
    let v100_15_tail = v100_15_cursor.make_map();
    v100_15_cursor.ascend(1);
    let v100_15_head = Path::from_slice(&[v100_15_byte]);
    let v101_2: Space = singleton(&(v100_15_head));
    let v101_3: Space = intersect(&(*CONSTANT_3),&(v101_2));
    let v101_4: Space = if has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
    drop(v101_3);
    let v101_5: Space = subtract(&(*CONSTANT_2),&(v101_4));
    drop(v101_4);
    let v101_8: Space = if (v101_5).is_empty() { Space::new() } else {
      let v102_6: Path = concat_path(&(*p0),&(v100_15_head));
      let v102_7: Space = routine_11(c, &(v102_6), &(*p1), &(v100_15_tail), &(*s1));
      drop(v102_6);
      compose(&(v101_5),&(v102_7))
    };
    drop(v101_5);
    let v101_9: Space = intersect(&(*CONSTANT_3),&(v101_2));
    drop(v101_2);
    let v101_10: Space = if has_head(&(v101_9)) { singleton(&[]) } else { Space::new() };
    drop(v101_9);
    let v101_13: Space = if (v101_10).is_empty() { Space::new() } else {
      let v103_11: Space = unwrap(&(v100_11),&(v100_15_head));
      let mut v103_12 = Space::new();
      let mut v103_12_cursor = (v103_11).read_zipper();
      for v103_12_byte in v103_12_cursor.child_mask().iter() {
        v103_12_cursor.descend_to_byte(v103_12_byte);
        let v103_12_tail = v103_12_cursor.make_map();
        v103_12_cursor.ascend(1);
        let v103_12_head = Path::from_slice(&[v103_12_byte]);
        let v104_2: Space = singleton(&(v103_12_head));
        let v104_3: Space = intersect(&(*CONSTANT_3),&(v104_2));
        let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
        drop(v104_3);
        let v104_5: Space = subtract(&(*CONSTANT_2),&(v104_4));
        drop(v104_4);
        let v104_7: Space = if (v104_5).is_empty() { Space::new() } else {
          let v105_6: Space = routine_21(c, &(v103_12_head), &(*p1), &(v103_12_tail));
          compose(&(v104_5),&(v105_6))
        };
        drop(v104_5);
        let v104_8: Space = intersect(&(*CONSTANT_3),&(v104_2));
        drop(v104_2);
        let v104_9: Space = if has_head(&(v104_8)) { singleton(&[]) } else { Space::new() };
        drop(v104_8);
        let v104_11: Space = if (v104_9).is_empty() { Space::new() } else {
          let v106_10: Space = routine_22(c, &(v103_12_head), &(*p1), &(v103_12_tail));
          compose(&(v104_9),&(v106_10))
        };
        drop(v104_9);
        let v104_12: Space = unite(&(v104_7),&(v104_11));
        v103_12.join_into((v104_12).clone());
      }
      drop(v103_12_cursor);
      drop(v103_11);
      compose(&(v101_10),&(v103_12))
    };
    drop(v101_10);
    let v101_14: Space = unite(&(v101_8),&(v101_13));
    v100_15.join_into((v101_14).clone());
  }
  drop(v100_15_cursor);
  drop(v100_11);
  (v100_15).clone()
}

fn routine_12(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v107_5: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v107_7: Space = unwrap(&(v107_5),&(*CONSTANT_5));
  drop(v107_5);
  let v107_8: Space = unwrap(&(v107_7),&(*p0));
  drop(v107_7);
  let mut v107_15 = Space::new();
  let mut v107_15_cursor = (v107_8).read_zipper();
  for v107_15_byte in v107_15_cursor.child_mask().iter() {
    v107_15_cursor.descend_to_byte(v107_15_byte);
    let v107_15_tail = v107_15_cursor.make_map();
    v107_15_cursor.ascend(1);
    let v107_15_head = Path::from_slice(&[v107_15_byte]);
    let v108_2: Space = singleton(&(v107_15_head));
    let v108_3: Space = intersect(&(*CONSTANT_3),&(v108_2));
    let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
    drop(v108_3);
    let v108_5: Space = subtract(&(*CONSTANT_2),&(v108_4));
    drop(v108_4);
    let v108_7: Space = if (v108_5).is_empty() { Space::new() } else {
      let mut v109_6 = Space::new();
      let mut v109_6_cursor = (v107_15_tail).read_zipper();
      for v109_6_byte in v109_6_cursor.child_mask().iter() {
        v109_6_cursor.descend_to_byte(v109_6_byte);
        let v109_6_tail = v109_6_cursor.make_map();
        v109_6_cursor.ascend(1);
        let v109_6_head = Path::from_slice(&[v109_6_byte]);
        let v110_2: Space = singleton(&(v109_6_head));
        let v110_3: Space = intersect(&(*CONSTANT_3),&(v110_2));
        let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
        drop(v110_3);
        let v110_5: Space = subtract(&(*CONSTANT_2),&(v110_4));
        drop(v110_4);
        let v110_8: Space = if (v110_5).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v107_15_head),&(v109_6_head));
          let v111_7: Space = routine_21(c, &(v111_6), &(*p1), &(v109_6_tail));
          compose(&(v110_5),&(v111_7))
        };
        drop(v110_5);
        let v110_9: Space = intersect(&(*CONSTANT_3),&(v110_2));
        drop(v110_2);
        let v110_10: Space = if has_head(&(v110_9)) { singleton(&[]) } else { Space::new() };
        drop(v110_9);
        let v110_12: Space = if (v110_10).is_empty() { Space::new() } else {
          let v112_6: Path = concat_path(&(v107_15_head),&(v109_6_head));
          let v112_11: Space = routine_22(c, &(v112_6), &(*p1), &(v109_6_tail));
          drop(v112_6);
          compose(&(v110_10),&(v112_11))
        };
        drop(v110_10);
        let v110_13: Space = unite(&(v110_8),&(v110_12));
        v109_6.join_into((v110_13).clone());
      }
      drop(v109_6_cursor);
      compose(&(v108_5),&(v109_6))
    };
    drop(v108_5);
    let v108_8: Space = intersect(&(*CONSTANT_3),&(v108_2));
    drop(v108_2);
    let v108_9: Space = if has_head(&(v108_8)) { singleton(&[]) } else { Space::new() };
    drop(v108_8);
    let v108_10: Space = compose(&(v108_9),&(v107_15_tail));
    drop(v108_9);
    let v108_11: Space = wrap(&(v108_10),&(v107_15_head));
    drop(v108_10);
    let v108_12: Space = wrap(&(v108_11),&(*p1));
    drop(v108_11);
    let v108_13: Space = unite(&(v108_7),&(v108_12));
    drop(v108_12);
    v107_15.join_into((v108_13).clone());
  }
  drop(v107_15_cursor);
  drop(v107_8);
  (v107_15).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v113_9 = Space::new();
  let mut v113_9_cursor = (*s0).read_zipper();
  for v113_9_byte in v113_9_cursor.child_mask().iter() {
    v113_9_cursor.descend_to_byte(v113_9_byte);
    let v113_9_tail = v113_9_cursor.make_map();
    v113_9_cursor.ascend(1);
    let v113_9_head = Path::from_slice(&[v113_9_byte]);
    let v114_2: Space = singleton(&(v113_9_head));
    let v114_3: Space = intersect(&(*CONSTANT_3),&(v114_2));
    let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
    drop(v114_3);
    let v114_5: Space = subtract(&(*CONSTANT_2),&(v114_4));
    drop(v114_4);
    let v114_8: Space = if (v114_5).is_empty() { Space::new() } else {
      let v115_6: Path = concat_path(&(*p0),&(v113_9_head));
      let v115_7: Space = routine_13(c, &(v115_6), &(v113_9_tail), &(*s1));
      compose(&(v114_5),&(v115_7))
    };
    drop(v114_5);
    let v114_9: Space = intersect(&(*CONSTANT_3),&(v114_2));
    drop(v114_2);
    let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
    drop(v114_9);
    let v114_12: Space = if (v114_10).is_empty() { Space::new() } else {
      let v116_6: Path = concat_path(&(*p0),&(v113_9_head));
      let mut v116_11 = Space::new();
      let mut v116_11_cursor = (v113_9_tail).read_zipper();
      for v116_11_byte in v116_11_cursor.child_mask().iter() {
        v116_11_cursor.descend_to_byte(v116_11_byte);
        let v116_11_tail = v116_11_cursor.make_map();
        v116_11_cursor.ascend(1);
        let v116_11_head = Path::from_slice(&[v116_11_byte]);
        let v117_2: Space = singleton(&(v116_11_head));
        let v117_3: Space = intersect(&(*CONSTANT_3),&(v117_2));
        let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
        drop(v117_3);
        let v117_5: Space = subtract(&(*CONSTANT_2),&(v117_4));
        drop(v117_4);
        let v117_7: Space = if (v117_5).is_empty() { Space::new() } else {
          let v118_6: Space = routine_15(c, &(v116_11_head), &(v116_6), &(v116_11_tail), &(*s1));
          compose(&(v117_5),&(v118_6))
        };
        drop(v117_5);
        let v117_8: Space = intersect(&(*CONSTANT_3),&(v117_2));
        drop(v117_2);
        let v117_9: Space = if has_head(&(v117_8)) { singleton(&[]) } else { Space::new() };
        drop(v117_8);
        let v117_11: Space = if (v117_9).is_empty() { Space::new() } else {
          let v119_10: Space = routine_16(c, &(v116_11_head), &(v116_6), &(v116_11_tail), &(*s1));
          compose(&(v117_9),&(v119_10))
        };
        drop(v117_9);
        let v117_12: Space = unite(&(v117_7),&(v117_11));
        v116_11.join_into((v117_12).clone());
      }
      drop(v116_11_cursor);
      drop(v116_6);
      compose(&(v114_10),&(v116_11))
    };
    drop(v114_10);
    let v114_13: Space = unite(&(v114_8),&(v114_12));
    v113_9.join_into((v114_13).clone());
  }
  drop(v113_9_cursor);
  (v113_9).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v120_7: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v120_9: Space = unwrap(&(v120_7),&(*CONSTANT_5));
  drop(v120_7);
  let mut v120_16 = Space::new();
  let mut v120_16_cursor = (*s0).read_zipper();
  for v120_16_byte in v120_16_cursor.child_mask().iter() {
    v120_16_cursor.descend_to_byte(v120_16_byte);
    let v120_16_tail = v120_16_cursor.make_map();
    v120_16_cursor.ascend(1);
    let v120_16_head = Path::from_slice(&[v120_16_byte]);
    let v121_2: Space = singleton(&(v120_16_head));
    let v121_3: Space = intersect(&(*CONSTANT_3),&(v121_2));
    let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
    drop(v121_3);
    let v121_5: Space = subtract(&(*CONSTANT_2),&(v121_4));
    drop(v121_4);
    let v121_7: Space = if (v121_5).is_empty() { Space::new() } else {
      let mut v122_6 = Space::new();
      let mut v122_6_cursor = (v120_16_tail).read_zipper();
      for v122_6_byte in v122_6_cursor.child_mask().iter() {
        v122_6_cursor.descend_to_byte(v122_6_byte);
        let v122_6_tail = v122_6_cursor.make_map();
        v122_6_cursor.ascend(1);
        let v122_6_head = Path::from_slice(&[v122_6_byte]);
        let v123_2: Space = singleton(&(v122_6_head));
        let v123_3: Space = intersect(&(*CONSTANT_3),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_2),&(v123_4));
        drop(v123_4);
        let v123_8: Space = if (v123_5).is_empty() { Space::new() } else {
          let v124_6: Path = concat_path(&(v120_16_head),&(v122_6_head));
          let v124_7: Space = routine_15(c, &(v124_6), &(*p0), &(v122_6_tail), &(*s1));
          compose(&(v123_5),&(v124_7))
        };
        drop(v123_5);
        let v123_9: Space = intersect(&(*CONSTANT_3),&(v123_2));
        drop(v123_2);
        let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
        drop(v123_9);
        let v123_12: Space = if (v123_10).is_empty() { Space::new() } else {
          let v125_6: Path = concat_path(&(v120_16_head),&(v122_6_head));
          let v125_11: Space = routine_16(c, &(v125_6), &(*p0), &(v122_6_tail), &(*s1));
          drop(v125_6);
          compose(&(v123_10),&(v125_11))
        };
        drop(v123_10);
        let v123_13: Space = unite(&(v123_8),&(v123_12));
        v122_6.join_into((v123_13).clone());
      }
      drop(v122_6_cursor);
      compose(&(v121_5),&(v122_6))
    };
    drop(v121_5);
    let v121_8: Space = intersect(&(*CONSTANT_3),&(v121_2));
    drop(v121_2);
    let v121_9: Space = if has_head(&(v121_8)) { singleton(&[]) } else { Space::new() };
    drop(v121_8);
    let v121_12: Space = if (v121_9).is_empty() { Space::new() } else {
      let v126_10: Space = unwrap(&(v120_9),&(v120_16_head));
      let mut v126_11 = Space::new();
      let mut v126_11_cursor = (v126_10).read_zipper();
      for v126_11_byte in v126_11_cursor.child_mask().iter() {
        v126_11_cursor.descend_to_byte(v126_11_byte);
        let v126_11_tail = v126_11_cursor.make_map();
        v126_11_cursor.ascend(1);
        let v126_11_head = Path::from_slice(&[v126_11_byte]);
        let v127_2: Space = singleton(&(v126_11_head));
        let v127_3: Space = intersect(&(*CONSTANT_3),&(v127_2));
        let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
        drop(v127_3);
        let v127_5: Space = subtract(&(*CONSTANT_2),&(v127_4));
        drop(v127_4);
        let v127_7: Space = if (v127_5).is_empty() { Space::new() } else {
          let v128_6: Space = routine_23(c, &(v126_11_head), &(*p0), &(v126_11_tail));
          compose(&(v127_5),&(v128_6))
        };
        drop(v127_5);
        let v127_8: Space = intersect(&(*CONSTANT_3),&(v127_2));
        drop(v127_2);
        let v127_9: Space = if has_head(&(v127_8)) { singleton(&[]) } else { Space::new() };
        drop(v127_8);
        let v127_11: Space = if (v127_9).is_empty() { Space::new() } else {
          let v129_10: Space = routine_24(c, &(v126_11_head), &(*p0), &(v126_11_tail));
          compose(&(v127_9),&(v129_10))
        };
        drop(v127_9);
        let v127_12: Space = unite(&(v127_7),&(v127_11));
        v126_11.join_into((v127_12).clone());
      }
      drop(v126_11_cursor);
      drop(v126_10);
      compose(&(v121_9),&(v126_11))
    };
    drop(v121_9);
    let v121_13: Space = unite(&(v121_7),&(v121_12));
    v120_16.join_into((v121_13).clone());
  }
  drop(v120_16_cursor);
  drop(v120_9);
  (v120_16).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v130_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v130_10: Space = unwrap(&(v130_8),&(*CONSTANT_5));
  drop(v130_8);
  let v130_11: Space = unwrap(&(v130_10),&(*p0));
  drop(v130_10);
  let mut v130_15 = Space::new();
  let mut v130_15_cursor = (*s0).read_zipper();
  for v130_15_byte in v130_15_cursor.child_mask().iter() {
    v130_15_cursor.descend_to_byte(v130_15_byte);
    let v130_15_tail = v130_15_cursor.make_map();
    v130_15_cursor.ascend(1);
    let v130_15_head = Path::from_slice(&[v130_15_byte]);
    let v131_2: Space = singleton(&(v130_15_head));
    let v131_3: Space = intersect(&(*CONSTANT_3),&(v131_2));
    let v131_4: Space = if has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
    drop(v131_3);
    let v131_5: Space = subtract(&(*CONSTANT_2),&(v131_4));
    drop(v131_4);
    let v131_8: Space = if (v131_5).is_empty() { Space::new() } else {
      let v132_6: Path = concat_path(&(*p0),&(v130_15_head));
      let v132_7: Space = routine_15(c, &(v132_6), &(*p1), &(v130_15_tail), &(*s1));
      drop(v132_6);
      compose(&(v131_5),&(v132_7))
    };
    drop(v131_5);
    let v131_9: Space = intersect(&(*CONSTANT_3),&(v131_2));
    drop(v131_2);
    let v131_10: Space = if has_head(&(v131_9)) { singleton(&[]) } else { Space::new() };
    drop(v131_9);
    let v131_13: Space = if (v131_10).is_empty() { Space::new() } else {
      let v133_11: Space = unwrap(&(v130_11),&(v130_15_head));
      let mut v133_12 = Space::new();
      let mut v133_12_cursor = (v133_11).read_zipper();
      for v133_12_byte in v133_12_cursor.child_mask().iter() {
        v133_12_cursor.descend_to_byte(v133_12_byte);
        let v133_12_tail = v133_12_cursor.make_map();
        v133_12_cursor.ascend(1);
        let v133_12_head = Path::from_slice(&[v133_12_byte]);
        let v134_2: Space = singleton(&(v133_12_head));
        let v134_3: Space = intersect(&(*CONSTANT_3),&(v134_2));
        let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
        drop(v134_3);
        let v134_5: Space = subtract(&(*CONSTANT_2),&(v134_4));
        drop(v134_4);
        let v134_7: Space = if (v134_5).is_empty() { Space::new() } else {
          let v135_6: Space = routine_23(c, &(v133_12_head), &(*p1), &(v133_12_tail));
          compose(&(v134_5),&(v135_6))
        };
        drop(v134_5);
        let v134_8: Space = intersect(&(*CONSTANT_3),&(v134_2));
        drop(v134_2);
        let v134_9: Space = if has_head(&(v134_8)) { singleton(&[]) } else { Space::new() };
        drop(v134_8);
        let v134_11: Space = if (v134_9).is_empty() { Space::new() } else {
          let v136_10: Space = routine_24(c, &(v133_12_head), &(*p1), &(v133_12_tail));
          compose(&(v134_9),&(v136_10))
        };
        drop(v134_9);
        let v134_12: Space = unite(&(v134_7),&(v134_11));
        v133_12.join_into((v134_12).clone());
      }
      drop(v133_12_cursor);
      drop(v133_11);
      compose(&(v131_10),&(v133_12))
    };
    drop(v131_10);
    let v131_14: Space = unite(&(v131_8),&(v131_13));
    v130_15.join_into((v131_14).clone());
  }
  drop(v130_15_cursor);
  drop(v130_11);
  (v130_15).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v137_5: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v137_7: Space = unwrap(&(v137_5),&(*CONSTANT_5));
  drop(v137_5);
  let v137_8: Space = unwrap(&(v137_7),&(*p0));
  drop(v137_7);
  let mut v137_15 = Space::new();
  let mut v137_15_cursor = (v137_8).read_zipper();
  for v137_15_byte in v137_15_cursor.child_mask().iter() {
    v137_15_cursor.descend_to_byte(v137_15_byte);
    let v137_15_tail = v137_15_cursor.make_map();
    v137_15_cursor.ascend(1);
    let v137_15_head = Path::from_slice(&[v137_15_byte]);
    let v138_2: Space = singleton(&(v137_15_head));
    let v138_3: Space = intersect(&(*CONSTANT_3),&(v138_2));
    let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
    drop(v138_3);
    let v138_5: Space = subtract(&(*CONSTANT_2),&(v138_4));
    drop(v138_4);
    let v138_7: Space = if (v138_5).is_empty() { Space::new() } else {
      let mut v139_6 = Space::new();
      let mut v139_6_cursor = (v137_15_tail).read_zipper();
      for v139_6_byte in v139_6_cursor.child_mask().iter() {
        v139_6_cursor.descend_to_byte(v139_6_byte);
        let v139_6_tail = v139_6_cursor.make_map();
        v139_6_cursor.ascend(1);
        let v139_6_head = Path::from_slice(&[v139_6_byte]);
        let v140_2: Space = singleton(&(v139_6_head));
        let v140_3: Space = intersect(&(*CONSTANT_3),&(v140_2));
        let v140_4: Space = if has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
        drop(v140_3);
        let v140_5: Space = subtract(&(*CONSTANT_2),&(v140_4));
        drop(v140_4);
        let v140_8: Space = if (v140_5).is_empty() { Space::new() } else {
          let v141_6: Path = concat_path(&(v137_15_head),&(v139_6_head));
          let v141_7: Space = routine_23(c, &(v141_6), &(*p1), &(v139_6_tail));
          compose(&(v140_5),&(v141_7))
        };
        drop(v140_5);
        let v140_9: Space = intersect(&(*CONSTANT_3),&(v140_2));
        drop(v140_2);
        let v140_10: Space = if has_head(&(v140_9)) { singleton(&[]) } else { Space::new() };
        drop(v140_9);
        let v140_12: Space = if (v140_10).is_empty() { Space::new() } else {
          let v142_6: Path = concat_path(&(v137_15_head),&(v139_6_head));
          let v142_11: Space = routine_24(c, &(v142_6), &(*p1), &(v139_6_tail));
          drop(v142_6);
          compose(&(v140_10),&(v142_11))
        };
        drop(v140_10);
        let v140_13: Space = unite(&(v140_8),&(v140_12));
        v139_6.join_into((v140_13).clone());
      }
      drop(v139_6_cursor);
      compose(&(v138_5),&(v139_6))
    };
    drop(v138_5);
    let v138_8: Space = intersect(&(*CONSTANT_3),&(v138_2));
    drop(v138_2);
    let v138_9: Space = if has_head(&(v138_8)) { singleton(&[]) } else { Space::new() };
    drop(v138_8);
    let v138_10: Space = compose(&(v138_9),&(v137_15_tail));
    drop(v138_9);
    let v138_11: Space = wrap(&(v138_10),&(v137_15_head));
    drop(v138_10);
    let v138_12: Space = wrap(&(v138_11),&(*p1));
    drop(v138_11);
    let v138_13: Space = unite(&(v138_7),&(v138_12));
    drop(v138_12);
    v137_15.join_into((v138_13).clone());
  }
  drop(v137_15_cursor);
  drop(v137_8);
  (v137_15).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v143_9 = Space::new();
  let mut v143_9_cursor = (*s0).read_zipper();
  for v143_9_byte in v143_9_cursor.child_mask().iter() {
    v143_9_cursor.descend_to_byte(v143_9_byte);
    let v143_9_tail = v143_9_cursor.make_map();
    v143_9_cursor.ascend(1);
    let v143_9_head = Path::from_slice(&[v143_9_byte]);
    let v144_2: Space = singleton(&(v143_9_head));
    let v144_3: Space = intersect(&(*CONSTANT_3),&(v144_2));
    let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
    drop(v144_3);
    let v144_5: Space = subtract(&(*CONSTANT_2),&(v144_4));
    drop(v144_4);
    let v144_8: Space = if (v144_5).is_empty() { Space::new() } else {
      let v145_6: Path = concat_path(&(*p0),&(v143_9_head));
      let v145_7: Space = routine_17(c, &(v145_6), &(v143_9_tail), &(*s1));
      compose(&(v144_5),&(v145_7))
    };
    drop(v144_5);
    let v144_9: Space = intersect(&(*CONSTANT_3),&(v144_2));
    drop(v144_2);
    let v144_10: Space = if has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
    drop(v144_9);
    let v144_12: Space = if (v144_10).is_empty() { Space::new() } else {
      let v146_6: Path = concat_path(&(*p0),&(v143_9_head));
      let mut v146_11 = Space::new();
      let mut v146_11_cursor = (v143_9_tail).read_zipper();
      for v146_11_byte in v146_11_cursor.child_mask().iter() {
        v146_11_cursor.descend_to_byte(v146_11_byte);
        let v146_11_tail = v146_11_cursor.make_map();
        v146_11_cursor.ascend(1);
        let v146_11_head = Path::from_slice(&[v146_11_byte]);
        let v147_2: Space = singleton(&(v146_11_head));
        let v147_3: Space = intersect(&(*CONSTANT_3),&(v147_2));
        let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
        drop(v147_3);
        let v147_5: Space = subtract(&(*CONSTANT_2),&(v147_4));
        drop(v147_4);
        let v147_7: Space = if (v147_5).is_empty() { Space::new() } else {
          let v148_6: Space = routine_19(c, &(v146_11_head), &(v146_6), &(v146_11_tail), &(*s1));
          compose(&(v147_5),&(v148_6))
        };
        drop(v147_5);
        let v147_8: Space = intersect(&(*CONSTANT_3),&(v147_2));
        drop(v147_2);
        let v147_9: Space = if has_head(&(v147_8)) { singleton(&[]) } else { Space::new() };
        drop(v147_8);
        let v147_11: Space = if (v147_9).is_empty() { Space::new() } else {
          let v149_10: Space = routine_20(c, &(v146_11_head), &(v146_6), &(v146_11_tail), &(*s1));
          compose(&(v147_9),&(v149_10))
        };
        drop(v147_9);
        let v147_12: Space = unite(&(v147_7),&(v147_11));
        v146_11.join_into((v147_12).clone());
      }
      drop(v146_11_cursor);
      drop(v146_6);
      compose(&(v144_10),&(v146_11))
    };
    drop(v144_10);
    let v144_13: Space = unite(&(v144_8),&(v144_12));
    v143_9.join_into((v144_13).clone());
  }
  drop(v143_9_cursor);
  (v143_9).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v150_7: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v150_9: Space = unwrap(&(v150_7),&(*CONSTANT_5));
  drop(v150_7);
  let mut v150_16 = Space::new();
  let mut v150_16_cursor = (*s0).read_zipper();
  for v150_16_byte in v150_16_cursor.child_mask().iter() {
    v150_16_cursor.descend_to_byte(v150_16_byte);
    let v150_16_tail = v150_16_cursor.make_map();
    v150_16_cursor.ascend(1);
    let v150_16_head = Path::from_slice(&[v150_16_byte]);
    let v151_2: Space = singleton(&(v150_16_head));
    let v151_3: Space = intersect(&(*CONSTANT_3),&(v151_2));
    let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
    drop(v151_3);
    let v151_5: Space = subtract(&(*CONSTANT_2),&(v151_4));
    drop(v151_4);
    let v151_7: Space = if (v151_5).is_empty() { Space::new() } else {
      let mut v152_6 = Space::new();
      let mut v152_6_cursor = (v150_16_tail).read_zipper();
      for v152_6_byte in v152_6_cursor.child_mask().iter() {
        v152_6_cursor.descend_to_byte(v152_6_byte);
        let v152_6_tail = v152_6_cursor.make_map();
        v152_6_cursor.ascend(1);
        let v152_6_head = Path::from_slice(&[v152_6_byte]);
        let v153_2: Space = singleton(&(v152_6_head));
        let v153_3: Space = intersect(&(*CONSTANT_3),&(v153_2));
        let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
        drop(v153_3);
        let v153_5: Space = subtract(&(*CONSTANT_2),&(v153_4));
        drop(v153_4);
        let v153_8: Space = if (v153_5).is_empty() { Space::new() } else {
          let v154_6: Path = concat_path(&(v150_16_head),&(v152_6_head));
          let v154_7: Space = routine_19(c, &(v154_6), &(*p0), &(v152_6_tail), &(*s1));
          compose(&(v153_5),&(v154_7))
        };
        drop(v153_5);
        let v153_9: Space = intersect(&(*CONSTANT_3),&(v153_2));
        drop(v153_2);
        let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
        drop(v153_9);
        let v153_12: Space = if (v153_10).is_empty() { Space::new() } else {
          let v155_6: Path = concat_path(&(v150_16_head),&(v152_6_head));
          let v155_11: Space = routine_20(c, &(v155_6), &(*p0), &(v152_6_tail), &(*s1));
          drop(v155_6);
          compose(&(v153_10),&(v155_11))
        };
        drop(v153_10);
        let v153_13: Space = unite(&(v153_8),&(v153_12));
        v152_6.join_into((v153_13).clone());
      }
      drop(v152_6_cursor);
      compose(&(v151_5),&(v152_6))
    };
    drop(v151_5);
    let v151_8: Space = intersect(&(*CONSTANT_3),&(v151_2));
    drop(v151_2);
    let v151_9: Space = if has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
    drop(v151_8);
    let v151_12: Space = if (v151_9).is_empty() { Space::new() } else {
      let v156_10: Space = unwrap(&(v150_9),&(v150_16_head));
      let mut v156_11 = Space::new();
      let mut v156_11_cursor = (v156_10).read_zipper();
      for v156_11_byte in v156_11_cursor.child_mask().iter() {
        v156_11_cursor.descend_to_byte(v156_11_byte);
        let v156_11_tail = v156_11_cursor.make_map();
        v156_11_cursor.ascend(1);
        let v156_11_head = Path::from_slice(&[v156_11_byte]);
        let v157_2: Space = singleton(&(v156_11_head));
        let v157_3: Space = intersect(&(*CONSTANT_3),&(v157_2));
        let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = subtract(&(*CONSTANT_2),&(v157_4));
        drop(v157_4);
        let v157_7: Space = if (v157_5).is_empty() { Space::new() } else {
          let v158_6: Space = routine_25(c, &(v156_11_head), &(*p0), &(v156_11_tail));
          compose(&(v157_5),&(v158_6))
        };
        drop(v157_5);
        let v157_8: Space = intersect(&(*CONSTANT_3),&(v157_2));
        drop(v157_2);
        let v157_9: Space = if has_head(&(v157_8)) { singleton(&[]) } else { Space::new() };
        drop(v157_8);
        let v157_11: Space = if (v157_9).is_empty() { Space::new() } else {
          let v159_10: Space = routine_26(c, &(v156_11_head), &(*p0), &(v156_11_tail));
          compose(&(v157_9),&(v159_10))
        };
        drop(v157_9);
        let v157_12: Space = unite(&(v157_7),&(v157_11));
        v156_11.join_into((v157_12).clone());
      }
      drop(v156_11_cursor);
      drop(v156_10);
      compose(&(v151_9),&(v156_11))
    };
    drop(v151_9);
    let v151_13: Space = unite(&(v151_7),&(v151_12));
    v150_16.join_into((v151_13).clone());
  }
  drop(v150_16_cursor);
  drop(v150_9);
  (v150_16).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v160_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v160_10: Space = unwrap(&(v160_8),&(*CONSTANT_5));
  drop(v160_8);
  let v160_11: Space = unwrap(&(v160_10),&(*p0));
  drop(v160_10);
  let mut v160_15 = Space::new();
  let mut v160_15_cursor = (*s0).read_zipper();
  for v160_15_byte in v160_15_cursor.child_mask().iter() {
    v160_15_cursor.descend_to_byte(v160_15_byte);
    let v160_15_tail = v160_15_cursor.make_map();
    v160_15_cursor.ascend(1);
    let v160_15_head = Path::from_slice(&[v160_15_byte]);
    let v161_2: Space = singleton(&(v160_15_head));
    let v161_3: Space = intersect(&(*CONSTANT_3),&(v161_2));
    let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
    drop(v161_3);
    let v161_5: Space = subtract(&(*CONSTANT_2),&(v161_4));
    drop(v161_4);
    let v161_8: Space = if (v161_5).is_empty() { Space::new() } else {
      let v162_6: Path = concat_path(&(*p0),&(v160_15_head));
      let v162_7: Space = routine_19(c, &(v162_6), &(*p1), &(v160_15_tail), &(*s1));
      drop(v162_6);
      compose(&(v161_5),&(v162_7))
    };
    drop(v161_5);
    let v161_9: Space = intersect(&(*CONSTANT_3),&(v161_2));
    drop(v161_2);
    let v161_10: Space = if has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
    drop(v161_9);
    let v161_13: Space = if (v161_10).is_empty() { Space::new() } else {
      let v163_11: Space = unwrap(&(v160_11),&(v160_15_head));
      let mut v163_12 = Space::new();
      let mut v163_12_cursor = (v163_11).read_zipper();
      for v163_12_byte in v163_12_cursor.child_mask().iter() {
        v163_12_cursor.descend_to_byte(v163_12_byte);
        let v163_12_tail = v163_12_cursor.make_map();
        v163_12_cursor.ascend(1);
        let v163_12_head = Path::from_slice(&[v163_12_byte]);
        let v164_2: Space = singleton(&(v163_12_head));
        let v164_3: Space = intersect(&(*CONSTANT_3),&(v164_2));
        let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
        drop(v164_3);
        let v164_5: Space = subtract(&(*CONSTANT_2),&(v164_4));
        drop(v164_4);
        let v164_7: Space = if (v164_5).is_empty() { Space::new() } else {
          let v165_6: Space = routine_25(c, &(v163_12_head), &(*p1), &(v163_12_tail));
          compose(&(v164_5),&(v165_6))
        };
        drop(v164_5);
        let v164_8: Space = intersect(&(*CONSTANT_3),&(v164_2));
        drop(v164_2);
        let v164_9: Space = if has_head(&(v164_8)) { singleton(&[]) } else { Space::new() };
        drop(v164_8);
        let v164_11: Space = if (v164_9).is_empty() { Space::new() } else {
          let v166_10: Space = routine_26(c, &(v163_12_head), &(*p1), &(v163_12_tail));
          compose(&(v164_9),&(v166_10))
        };
        drop(v164_9);
        let v164_12: Space = unite(&(v164_7),&(v164_11));
        v163_12.join_into((v164_12).clone());
      }
      drop(v163_12_cursor);
      drop(v163_11);
      compose(&(v161_10),&(v163_12))
    };
    drop(v161_10);
    let v161_14: Space = unite(&(v161_8),&(v161_13));
    v160_15.join_into((v161_14).clone());
  }
  drop(v160_15_cursor);
  drop(v160_11);
  (v160_15).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v167_5: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v167_7: Space = unwrap(&(v167_5),&(*CONSTANT_5));
  drop(v167_5);
  let v167_8: Space = unwrap(&(v167_7),&(*p0));
  drop(v167_7);
  let mut v167_15 = Space::new();
  let mut v167_15_cursor = (v167_8).read_zipper();
  for v167_15_byte in v167_15_cursor.child_mask().iter() {
    v167_15_cursor.descend_to_byte(v167_15_byte);
    let v167_15_tail = v167_15_cursor.make_map();
    v167_15_cursor.ascend(1);
    let v167_15_head = Path::from_slice(&[v167_15_byte]);
    let v168_2: Space = singleton(&(v167_15_head));
    let v168_3: Space = intersect(&(*CONSTANT_3),&(v168_2));
    let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
    drop(v168_3);
    let v168_5: Space = subtract(&(*CONSTANT_2),&(v168_4));
    drop(v168_4);
    let v168_7: Space = if (v168_5).is_empty() { Space::new() } else {
      let mut v169_6 = Space::new();
      let mut v169_6_cursor = (v167_15_tail).read_zipper();
      for v169_6_byte in v169_6_cursor.child_mask().iter() {
        v169_6_cursor.descend_to_byte(v169_6_byte);
        let v169_6_tail = v169_6_cursor.make_map();
        v169_6_cursor.ascend(1);
        let v169_6_head = Path::from_slice(&[v169_6_byte]);
        let v170_2: Space = singleton(&(v169_6_head));
        let v170_3: Space = intersect(&(*CONSTANT_3),&(v170_2));
        let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
        drop(v170_3);
        let v170_5: Space = subtract(&(*CONSTANT_2),&(v170_4));
        drop(v170_4);
        let v170_8: Space = if (v170_5).is_empty() { Space::new() } else {
          let v171_6: Path = concat_path(&(v167_15_head),&(v169_6_head));
          let v171_7: Space = routine_25(c, &(v171_6), &(*p1), &(v169_6_tail));
          compose(&(v170_5),&(v171_7))
        };
        drop(v170_5);
        let v170_9: Space = intersect(&(*CONSTANT_3),&(v170_2));
        drop(v170_2);
        let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
        drop(v170_9);
        let v170_12: Space = if (v170_10).is_empty() { Space::new() } else {
          let v172_6: Path = concat_path(&(v167_15_head),&(v169_6_head));
          let v172_11: Space = routine_26(c, &(v172_6), &(*p1), &(v169_6_tail));
          drop(v172_6);
          compose(&(v170_10),&(v172_11))
        };
        drop(v170_10);
        let v170_13: Space = unite(&(v170_8),&(v170_12));
        v169_6.join_into((v170_13).clone());
      }
      drop(v169_6_cursor);
      compose(&(v168_5),&(v169_6))
    };
    drop(v168_5);
    let v168_8: Space = intersect(&(*CONSTANT_3),&(v168_2));
    drop(v168_2);
    let v168_9: Space = if has_head(&(v168_8)) { singleton(&[]) } else { Space::new() };
    drop(v168_8);
    let v168_10: Space = compose(&(v168_9),&(v167_15_tail));
    drop(v168_9);
    let v168_11: Space = wrap(&(v168_10),&(v167_15_head));
    drop(v168_10);
    let v168_12: Space = wrap(&(v168_11),&(*p1));
    drop(v168_11);
    let v168_13: Space = unite(&(v168_7),&(v168_12));
    drop(v168_12);
    v167_15.join_into((v168_13).clone());
  }
  drop(v167_15_cursor);
  drop(v167_8);
  (v167_15).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v173_6 = Space::new();
  let mut v173_6_cursor = (*s0).read_zipper();
  for v173_6_byte in v173_6_cursor.child_mask().iter() {
    v173_6_cursor.descend_to_byte(v173_6_byte);
    let v173_6_tail = v173_6_cursor.make_map();
    v173_6_cursor.ascend(1);
    let v173_6_head = Path::from_slice(&[v173_6_byte]);
    let v174_2: Space = singleton(&(v173_6_head));
    let v174_3: Space = intersect(&(*CONSTANT_3),&(v174_2));
    let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
    drop(v174_3);
    let v174_5: Space = subtract(&(*CONSTANT_2),&(v174_4));
    drop(v174_4);
    let v174_8: Space = if (v174_5).is_empty() { Space::new() } else {
      let v175_6: Path = concat_path(&(*p0),&(v173_6_head));
      let v175_7: Space = routine_21(c, &(v175_6), &(*p1), &(v173_6_tail));
      compose(&(v174_5),&(v175_7))
    };
    drop(v174_5);
    let v174_9: Space = intersect(&(*CONSTANT_3),&(v174_2));
    drop(v174_2);
    let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
    drop(v174_9);
    let v174_11: Space = compose(&(v174_10),&(v173_6_tail));
    drop(v174_10);
    let v176_6: Path = concat_path(&(*p0),&(v173_6_head));
    let v174_12: Space = wrap(&(v174_11),&(v176_6));
    drop(v174_11);
    let v174_13: Space = wrap(&(v174_12),&(*p1));
    drop(v174_12);
    let v174_14: Space = unite(&(v174_8),&(v174_13));
    drop(v174_13);
    v173_6.join_into((v174_14).clone());
  }
  drop(v173_6_cursor);
  (v173_6).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v177_3: Space = wrap(&(*s0),&(*p0));
  let v177_4: Space = wrap(&(v177_3),&(*p1));
  drop(v177_3);
  (v177_4).clone()
}

fn routine_23(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v178_6 = Space::new();
  let mut v178_6_cursor = (*s0).read_zipper();
  for v178_6_byte in v178_6_cursor.child_mask().iter() {
    v178_6_cursor.descend_to_byte(v178_6_byte);
    let v178_6_tail = v178_6_cursor.make_map();
    v178_6_cursor.ascend(1);
    let v178_6_head = Path::from_slice(&[v178_6_byte]);
    let v179_2: Space = singleton(&(v178_6_head));
    let v179_3: Space = intersect(&(*CONSTANT_3),&(v179_2));
    let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
    drop(v179_3);
    let v179_5: Space = subtract(&(*CONSTANT_2),&(v179_4));
    drop(v179_4);
    let v179_8: Space = if (v179_5).is_empty() { Space::new() } else {
      let v180_6: Path = concat_path(&(*p0),&(v178_6_head));
      let v180_7: Space = routine_23(c, &(v180_6), &(*p1), &(v178_6_tail));
      compose(&(v179_5),&(v180_7))
    };
    drop(v179_5);
    let v179_9: Space = intersect(&(*CONSTANT_3),&(v179_2));
    drop(v179_2);
    let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
    drop(v179_9);
    let v179_11: Space = compose(&(v179_10),&(v178_6_tail));
    drop(v179_10);
    let v181_6: Path = concat_path(&(*p0),&(v178_6_head));
    let v179_12: Space = wrap(&(v179_11),&(v181_6));
    drop(v179_11);
    let v179_13: Space = wrap(&(v179_12),&(*p1));
    drop(v179_12);
    let v179_14: Space = unite(&(v179_8),&(v179_13));
    drop(v179_13);
    v178_6.join_into((v179_14).clone());
  }
  drop(v178_6_cursor);
  (v178_6).clone()
}

fn routine_24(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v182_3: Space = wrap(&(*s0),&(*p0));
  let v182_4: Space = wrap(&(v182_3),&(*p1));
  drop(v182_3);
  (v182_4).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v183_6 = Space::new();
  let mut v183_6_cursor = (*s0).read_zipper();
  for v183_6_byte in v183_6_cursor.child_mask().iter() {
    v183_6_cursor.descend_to_byte(v183_6_byte);
    let v183_6_tail = v183_6_cursor.make_map();
    v183_6_cursor.ascend(1);
    let v183_6_head = Path::from_slice(&[v183_6_byte]);
    let v184_2: Space = singleton(&(v183_6_head));
    let v184_3: Space = intersect(&(*CONSTANT_3),&(v184_2));
    let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
    drop(v184_3);
    let v184_5: Space = subtract(&(*CONSTANT_2),&(v184_4));
    drop(v184_4);
    let v184_8: Space = if (v184_5).is_empty() { Space::new() } else {
      let v185_6: Path = concat_path(&(*p0),&(v183_6_head));
      let v185_7: Space = routine_25(c, &(v185_6), &(*p1), &(v183_6_tail));
      compose(&(v184_5),&(v185_7))
    };
    drop(v184_5);
    let v184_9: Space = intersect(&(*CONSTANT_3),&(v184_2));
    drop(v184_2);
    let v184_10: Space = if has_head(&(v184_9)) { singleton(&[]) } else { Space::new() };
    drop(v184_9);
    let v184_11: Space = compose(&(v184_10),&(v183_6_tail));
    drop(v184_10);
    let v186_6: Path = concat_path(&(*p0),&(v183_6_head));
    let v184_12: Space = wrap(&(v184_11),&(v186_6));
    drop(v184_11);
    let v184_13: Space = wrap(&(v184_12),&(*p1));
    drop(v184_12);
    let v184_14: Space = unite(&(v184_8),&(v184_13));
    drop(v184_13);
    v183_6.join_into((v184_14).clone());
  }
  drop(v183_6_cursor);
  (v183_6).clone()
}

fn routine_26(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v187_3: Space = wrap(&(*s0),&(*p0));
  let v187_4: Space = wrap(&(v187_3),&(*p1));
  drop(v187_3);
  (v187_4).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
