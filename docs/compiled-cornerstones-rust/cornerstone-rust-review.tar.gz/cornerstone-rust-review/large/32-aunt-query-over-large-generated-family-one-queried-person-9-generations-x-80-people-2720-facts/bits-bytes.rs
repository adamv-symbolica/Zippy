#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,1,0,0,1,0,0,1,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,0,0,0,1,0,0,1,0,0,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1,0,0,1,0,0,1,0,0,0,1,1]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>) -> Space {
  let mut v0_5 = Space::new();
  let mut v0_5_cursor = (*s1.expect("unbound native input")).read_zipper();
  for v0_5_byte in v0_5_cursor.child_mask().iter() {
    v0_5_cursor.descend_to_byte(v0_5_byte);
    let v0_5_tail = v0_5_cursor.make_map();
    v0_5_cursor.ascend(1);
    let v0_5_head = Path::from_slice(&[v0_5_byte]);
    let v1_2: Space = singleton(&(v0_5_head));
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let v2_6: Space = routine_1(c, &(v0_5_head), &(v0_5_tail), &(*s0.expect("unbound native input")));
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let v3_10: Space = routine_2(c, &(v0_5_head), &(v0_5_tail), &(*s0.expect("unbound native input")));
      compose(&(v1_9),&(v3_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_5.join_into((v1_12).clone());
  }
  drop(v0_5_cursor);
  let v0_7: Space = wrap(&(v0_5),&(*CONSTANT_2));
  (v0_7).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v4_12 = Space::new();
  let mut v4_12_cursor = (*s0).read_zipper();
  for v4_12_byte in v4_12_cursor.child_mask().iter() {
    v4_12_cursor.descend_to_byte(v4_12_byte);
    let v4_12_tail = v4_12_cursor.make_map();
    v4_12_cursor.ascend(1);
    let v4_12_head = Path::from_slice(&[v4_12_byte]);
    let v5_2: Space = singleton(&(v4_12_head));
    let v5_3: Space = intersect(&(*CONSTANT_1),&(v5_2));
    let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
    drop(v5_3);
    let v5_5: Space = subtract(&(*CONSTANT_0),&(v5_4));
    drop(v5_4);
    let v5_8: Space = if (v5_5).is_empty() { Space::new() } else {
      let v6_6: Path = concat_path(&(*p0),&(v4_12_head));
      let mut v6_7 = Space::new();
      let mut v6_7_cursor = (v4_12_tail).read_zipper();
      for v6_7_byte in v6_7_cursor.child_mask().iter() {
        v6_7_cursor.descend_to_byte(v6_7_byte);
        let v6_7_tail = v6_7_cursor.make_map();
        v6_7_cursor.ascend(1);
        let v6_7_head = Path::from_slice(&[v6_7_byte]);
        let v7_2: Space = singleton(&(v6_7_head));
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v6_6),&(v6_7_head));
          let v8_7: Space = routine_3(c, &(v8_6), &(v6_7_tail), &(*s1));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v6_6),&(v6_7_head));
          let v9_11: Space = routine_4(c, &(v9_6), &(v6_7_tail), &(*s1));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_7.join_into((v7_13).clone());
      }
      drop(v6_7_cursor);
      compose(&(v5_5),&(v6_7))
    };
    drop(v5_5);
    let v5_9: Space = intersect(&(*CONSTANT_1),&(v5_2));
    drop(v5_2);
    let v5_10: Space = if has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
    drop(v5_9);
    let v5_12: Space = if (v5_10).is_empty() { Space::new() } else {
      let v10_6: Path = concat_path(&(*p0),&(v4_12_head));
      let mut v10_11 = Space::new();
      let mut v10_11_cursor = (v4_12_tail).read_zipper();
      for v10_11_byte in v10_11_cursor.child_mask().iter() {
        v10_11_cursor.descend_to_byte(v10_11_byte);
        let v10_11_tail = v10_11_cursor.make_map();
        v10_11_cursor.ascend(1);
        let v10_11_head = Path::from_slice(&[v10_11_byte]);
        let v11_2: Space = singleton(&(v10_11_head));
        let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
        let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
        drop(v11_3);
        let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
        drop(v11_4);
        let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
          let v12_6: Path = concat_path(&(v10_6),&(v10_11_head));
          let v12_7: Space = routine_3(c, &(v12_6), &(v10_11_tail), &(*s1));
          compose(&(v11_5),&(v12_7))
        };
        drop(v11_5);
        let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
        drop(v11_2);
        let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
        drop(v11_9);
        let v11_12: Space = if (v11_10).is_empty() { Space::new() } else {
          let v13_6: Path = concat_path(&(v10_6),&(v10_11_head));
          let v13_11: Space = routine_5(c, &(v13_6), &(v10_11_tail), &(*s1));
          drop(v13_6);
          compose(&(v11_10),&(v13_11))
        };
        drop(v11_10);
        let v11_13: Space = unite(&(v11_8),&(v11_12));
        v10_11.join_into((v11_13).clone());
      }
      drop(v10_11_cursor);
      drop(v10_6);
      compose(&(v5_10),&(v10_11))
    };
    drop(v5_10);
    let v5_13: Space = unite(&(v5_8),&(v5_12));
    v4_12.join_into((v5_13).clone());
  }
  drop(v4_12_cursor);
  (v4_12).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v14_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v14_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v14_10: Space = unwrap(&(v14_9),&(*p0));
  let v14_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v14_22 = Space::new();
  let mut v14_22_cursor = (*s0).read_zipper();
  for v14_22_byte in v14_22_cursor.child_mask().iter() {
    v14_22_cursor.descend_to_byte(v14_22_byte);
    let v14_22_tail = v14_22_cursor.make_map();
    v14_22_cursor.ascend(1);
    let v14_22_head = Path::from_slice(&[v14_22_byte]);
    let v15_2: Space = singleton(&(v14_22_head));
    let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
    let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
    drop(v15_3);
    let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
    drop(v15_4);
    let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v14_22_head));
      let mut v16_7 = Space::new();
      let mut v16_7_cursor = (v14_22_tail).read_zipper();
      for v16_7_byte in v16_7_cursor.child_mask().iter() {
        v16_7_cursor.descend_to_byte(v16_7_byte);
        let v16_7_tail = v16_7_cursor.make_map();
        v16_7_cursor.ascend(1);
        let v16_7_head = Path::from_slice(&[v16_7_byte]);
        let v17_2: Space = singleton(&(v16_7_head));
        let v17_3: Space = intersect(&(*CONSTANT_1),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
        drop(v17_4);
        let v17_8: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v16_6),&(v16_7_head));
          let v18_7: Space = routine_3(c, &(v18_6), &(v16_7_tail), &(*s1));
          compose(&(v17_5),&(v18_7))
        };
        drop(v17_5);
        let v17_9: Space = intersect(&(*CONSTANT_1),&(v17_2));
        drop(v17_2);
        let v17_10: Space = if has_head(&(v17_9)) { singleton(&[]) } else { Space::new() };
        drop(v17_9);
        let v17_12: Space = if (v17_10).is_empty() { Space::new() } else {
          let v19_6: Path = concat_path(&(v16_6),&(v16_7_head));
          let v19_11: Space = routine_4(c, &(v19_6), &(v16_7_tail), &(*s1));
          drop(v19_6);
          compose(&(v17_10),&(v19_11))
        };
        drop(v17_10);
        let v17_13: Space = unite(&(v17_8),&(v17_12));
        v16_7.join_into((v17_13).clone());
      }
      drop(v16_7_cursor);
      compose(&(v15_5),&(v16_7))
    };
    drop(v15_5);
    let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
    drop(v15_2);
    let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
    drop(v15_9);
    let v15_18: Space = if (v15_10).is_empty() { Space::new() } else {
      let v20_11: Space = unwrap(&(v14_10),&(v14_22_head));
      let v20_12: Space = restrict_to(&(v14_9),&(v20_11));
      let mut v20_13 = Space::new();
      let mut v20_13_cursor = (v20_12).read_zipper();
      for v20_13_byte in v20_13_cursor.child_mask().iter() {
        v20_13_cursor.descend_to_byte(v20_13_byte);
        let v20_13_tail = v20_13_cursor.make_map();
        v20_13_cursor.ascend(1);
        let v20_13_head = Path::from_slice(&[v20_13_byte]);
        let v21_2: Space = singleton(&(v20_13_head));
        let v21_3: Space = intersect(&(*CONSTANT_1),&(v21_2));
        let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
        drop(v21_3);
        let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
        drop(v21_4);
        let v21_7: Space = if (v21_5).is_empty() { Space::new() } else {
          let v22_6: Space = routine_6(c, &(v20_13_head), &(v20_13_tail));
          compose(&(v21_5),&(v22_6))
        };
        drop(v21_5);
        let v21_8: Space = intersect(&(*CONSTANT_1),&(v21_2));
        drop(v21_2);
        let v21_9: Space = if has_head(&(v21_8)) { singleton(&[]) } else { Space::new() };
        drop(v21_8);
        let v21_11: Space = if (v21_9).is_empty() { Space::new() } else {
          let v23_10: Space = routine_7(c, &(v20_13_head), &(v20_13_tail));
          compose(&(v21_9),&(v23_10))
        };
        drop(v21_9);
        let v21_12: Space = unite(&(v21_7),&(v21_11));
        v20_13.join_into((v21_12).clone());
      }
      drop(v20_13_cursor);
      drop(v20_12);
      let v20_14: Space = restrict_to(&(v14_7),&(v20_13));
      let mut v20_15 = Space::new();
      let mut v20_15_cursor = (v20_14).read_zipper();
      for v20_15_byte in v20_15_cursor.child_mask().iter() {
        v20_15_cursor.descend_to_byte(v20_15_byte);
        let v20_15_tail = v20_15_cursor.make_map();
        v20_15_cursor.ascend(1);
        let v20_15_head = Path::from_slice(&[v20_15_byte]);
        let v24_2: Space = singleton(&(v20_15_head));
        let v24_3: Space = intersect(&(*CONSTANT_1),&(v24_2));
        let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
        drop(v24_3);
        let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
        drop(v24_4);
        let v24_7: Space = if (v24_5).is_empty() { Space::new() } else {
          let v25_6: Space = routine_8(c, &(v20_15_head), &(v20_15_tail));
          compose(&(v24_5),&(v25_6))
        };
        drop(v24_5);
        let v24_8: Space = intersect(&(*CONSTANT_1),&(v24_2));
        drop(v24_2);
        let v24_9: Space = if has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
        drop(v24_8);
        let v24_11: Space = if (v24_9).is_empty() { Space::new() } else {
          let v26_10: Space = routine_9(c, &(v20_15_head), &(v20_15_tail));
          compose(&(v24_9),&(v26_10))
        };
        drop(v24_9);
        let v24_12: Space = unite(&(v24_7),&(v24_11));
        v20_15.join_into((v24_12).clone());
      }
      drop(v20_15_cursor);
      let v20_16: Space = subtract(&(v20_15),&(v20_11));
      drop(v20_11);
      let v20_17: Space = intersect(&(v20_16),&(v14_12));
      compose(&(v15_10),&(v20_17))
    };
    drop(v15_10);
    let v27_6: Path = concat_path(&(*p0),&(v14_22_head));
    let v15_19: Space = wrap(&(v15_18),&(v27_6));
    let v15_20: Space = unite(&(v15_8),&(v15_19));
    v14_22.join_into((v15_20).clone());
  }
  drop(v14_22_cursor);
  drop(v14_7);
  drop(v14_9);
  drop(v14_10);
  drop(v14_12);
  (v14_22).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v28_12 = Space::new();
  let mut v28_12_cursor = (*s0).read_zipper();
  for v28_12_byte in v28_12_cursor.child_mask().iter() {
    v28_12_cursor.descend_to_byte(v28_12_byte);
    let v28_12_tail = v28_12_cursor.make_map();
    v28_12_cursor.ascend(1);
    let v28_12_head = Path::from_slice(&[v28_12_byte]);
    let v29_2: Space = singleton(&(v28_12_head));
    let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
    let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
    drop(v29_3);
    let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
    drop(v29_4);
    let v29_8: Space = if (v29_5).is_empty() { Space::new() } else {
      let v30_6: Path = concat_path(&(*p0),&(v28_12_head));
      let mut v30_7 = Space::new();
      let mut v30_7_cursor = (v28_12_tail).read_zipper();
      for v30_7_byte in v30_7_cursor.child_mask().iter() {
        v30_7_cursor.descend_to_byte(v30_7_byte);
        let v30_7_tail = v30_7_cursor.make_map();
        v30_7_cursor.ascend(1);
        let v30_7_head = Path::from_slice(&[v30_7_byte]);
        let v31_2: Space = singleton(&(v30_7_head));
        let v31_3: Space = intersect(&(*CONSTANT_1),&(v31_2));
        let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
        drop(v31_3);
        let v31_5: Space = subtract(&(*CONSTANT_0),&(v31_4));
        drop(v31_4);
        let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
          let v32_6: Path = concat_path(&(v30_6),&(v30_7_head));
          let v32_7: Space = routine_10(c, &(v32_6), &(v30_7_tail), &(*s1));
          compose(&(v31_5),&(v32_7))
        };
        drop(v31_5);
        let v31_9: Space = intersect(&(*CONSTANT_1),&(v31_2));
        drop(v31_2);
        let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
        drop(v31_9);
        let v31_12: Space = if (v31_10).is_empty() { Space::new() } else {
          let v33_6: Path = concat_path(&(v30_6),&(v30_7_head));
          let v33_11: Space = routine_11(c, &(v33_6), &(v30_7_tail), &(*s1));
          drop(v33_6);
          compose(&(v31_10),&(v33_11))
        };
        drop(v31_10);
        let v31_13: Space = unite(&(v31_8),&(v31_12));
        v30_7.join_into((v31_13).clone());
      }
      drop(v30_7_cursor);
      compose(&(v29_5),&(v30_7))
    };
    drop(v29_5);
    let v29_9: Space = intersect(&(*CONSTANT_1),&(v29_2));
    drop(v29_2);
    let v29_10: Space = if has_head(&(v29_9)) { singleton(&[]) } else { Space::new() };
    drop(v29_9);
    let v29_12: Space = if (v29_10).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&(v28_12_head));
      let mut v34_11 = Space::new();
      let mut v34_11_cursor = (v28_12_tail).read_zipper();
      for v34_11_byte in v34_11_cursor.child_mask().iter() {
        v34_11_cursor.descend_to_byte(v34_11_byte);
        let v34_11_tail = v34_11_cursor.make_map();
        v34_11_cursor.ascend(1);
        let v34_11_head = Path::from_slice(&[v34_11_byte]);
        let v35_2: Space = singleton(&(v34_11_head));
        let v35_3: Space = intersect(&(*CONSTANT_1),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_0),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (v35_5).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let v36_7: Space = routine_10(c, &(v36_6), &(v34_11_tail), &(*s1));
          compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = intersect(&(*CONSTANT_1),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (v35_10).is_empty() { Space::new() } else {
          let v37_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let v37_11: Space = routine_5(c, &(v37_6), &(v34_11_tail), &(*s1));
          drop(v37_6);
          compose(&(v35_10),&(v37_11))
        };
        drop(v35_10);
        let v35_13: Space = unite(&(v35_8),&(v35_12));
        v34_11.join_into((v35_13).clone());
      }
      drop(v34_11_cursor);
      drop(v34_6);
      compose(&(v29_10),&(v34_11))
    };
    drop(v29_10);
    let v29_13: Space = unite(&(v29_8),&(v29_12));
    v28_12.join_into((v29_13).clone());
  }
  drop(v28_12_cursor);
  (v28_12).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v38_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v38_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v38_10: Space = unwrap(&(v38_9),&(*p0));
  let v38_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v38_22 = Space::new();
  let mut v38_22_cursor = (*s0).read_zipper();
  for v38_22_byte in v38_22_cursor.child_mask().iter() {
    v38_22_cursor.descend_to_byte(v38_22_byte);
    let v38_22_tail = v38_22_cursor.make_map();
    v38_22_cursor.ascend(1);
    let v38_22_head = Path::from_slice(&[v38_22_byte]);
    let v39_2: Space = singleton(&(v38_22_head));
    let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
    let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
    drop(v39_3);
    let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
    drop(v39_4);
    let v39_8: Space = if (v39_5).is_empty() { Space::new() } else {
      let v40_6: Path = concat_path(&(*p0),&(v38_22_head));
      let mut v40_7 = Space::new();
      let mut v40_7_cursor = (v38_22_tail).read_zipper();
      for v40_7_byte in v40_7_cursor.child_mask().iter() {
        v40_7_cursor.descend_to_byte(v40_7_byte);
        let v40_7_tail = v40_7_cursor.make_map();
        v40_7_cursor.ascend(1);
        let v40_7_head = Path::from_slice(&[v40_7_byte]);
        let v41_2: Space = singleton(&(v40_7_head));
        let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
        let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
        drop(v41_3);
        let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
        drop(v41_4);
        let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
          let v42_6: Path = concat_path(&(v40_6),&(v40_7_head));
          let v42_7: Space = routine_10(c, &(v42_6), &(v40_7_tail), &(*s1));
          compose(&(v41_5),&(v42_7))
        };
        drop(v41_5);
        let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
        drop(v41_2);
        let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
        drop(v41_9);
        let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
          let v43_6: Path = concat_path(&(v40_6),&(v40_7_head));
          let v43_11: Space = routine_11(c, &(v43_6), &(v40_7_tail), &(*s1));
          drop(v43_6);
          compose(&(v41_10),&(v43_11))
        };
        drop(v41_10);
        let v41_13: Space = unite(&(v41_8),&(v41_12));
        v40_7.join_into((v41_13).clone());
      }
      drop(v40_7_cursor);
      compose(&(v39_5),&(v40_7))
    };
    drop(v39_5);
    let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
    drop(v39_2);
    let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
    drop(v39_9);
    let v39_18: Space = if (v39_10).is_empty() { Space::new() } else {
      let v44_11: Space = unwrap(&(v38_10),&(v38_22_head));
      let v44_12: Space = restrict_to(&(v38_9),&(v44_11));
      let mut v44_13 = Space::new();
      let mut v44_13_cursor = (v44_12).read_zipper();
      for v44_13_byte in v44_13_cursor.child_mask().iter() {
        v44_13_cursor.descend_to_byte(v44_13_byte);
        let v44_13_tail = v44_13_cursor.make_map();
        v44_13_cursor.ascend(1);
        let v44_13_head = Path::from_slice(&[v44_13_byte]);
        let v45_2: Space = singleton(&(v44_13_head));
        let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
        let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
        drop(v45_3);
        let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
        drop(v45_4);
        let v45_7: Space = if (v45_5).is_empty() { Space::new() } else {
          let v46_6: Space = routine_6(c, &(v44_13_head), &(v44_13_tail));
          compose(&(v45_5),&(v46_6))
        };
        drop(v45_5);
        let v45_8: Space = intersect(&(*CONSTANT_1),&(v45_2));
        drop(v45_2);
        let v45_9: Space = if has_head(&(v45_8)) { singleton(&[]) } else { Space::new() };
        drop(v45_8);
        let v45_11: Space = if (v45_9).is_empty() { Space::new() } else {
          let v47_10: Space = routine_7(c, &(v44_13_head), &(v44_13_tail));
          compose(&(v45_9),&(v47_10))
        };
        drop(v45_9);
        let v45_12: Space = unite(&(v45_7),&(v45_11));
        v44_13.join_into((v45_12).clone());
      }
      drop(v44_13_cursor);
      drop(v44_12);
      let v44_14: Space = restrict_to(&(v38_7),&(v44_13));
      let mut v44_15 = Space::new();
      let mut v44_15_cursor = (v44_14).read_zipper();
      for v44_15_byte in v44_15_cursor.child_mask().iter() {
        v44_15_cursor.descend_to_byte(v44_15_byte);
        let v44_15_tail = v44_15_cursor.make_map();
        v44_15_cursor.ascend(1);
        let v44_15_head = Path::from_slice(&[v44_15_byte]);
        let v48_2: Space = singleton(&(v44_15_head));
        let v48_3: Space = intersect(&(*CONSTANT_1),&(v48_2));
        let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
        drop(v48_3);
        let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
        drop(v48_4);
        let v48_7: Space = if (v48_5).is_empty() { Space::new() } else {
          let v49_6: Space = routine_8(c, &(v44_15_head), &(v44_15_tail));
          compose(&(v48_5),&(v49_6))
        };
        drop(v48_5);
        let v48_8: Space = intersect(&(*CONSTANT_1),&(v48_2));
        drop(v48_2);
        let v48_9: Space = if has_head(&(v48_8)) { singleton(&[]) } else { Space::new() };
        drop(v48_8);
        let v48_11: Space = if (v48_9).is_empty() { Space::new() } else {
          let v50_10: Space = routine_9(c, &(v44_15_head), &(v44_15_tail));
          compose(&(v48_9),&(v50_10))
        };
        drop(v48_9);
        let v48_12: Space = unite(&(v48_7),&(v48_11));
        v44_15.join_into((v48_12).clone());
      }
      drop(v44_15_cursor);
      let v44_16: Space = subtract(&(v44_15),&(v44_11));
      drop(v44_11);
      let v44_17: Space = intersect(&(v44_16),&(v38_12));
      compose(&(v39_10),&(v44_17))
    };
    drop(v39_10);
    let v51_6: Path = concat_path(&(*p0),&(v38_22_head));
    let v39_19: Space = wrap(&(v39_18),&(v51_6));
    let v39_20: Space = unite(&(v39_8),&(v39_19));
    v38_22.join_into((v39_20).clone());
  }
  drop(v38_22_cursor);
  drop(v38_7);
  drop(v38_9);
  drop(v38_10);
  drop(v38_12);
  (v38_22).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v52_4: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v52_6: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v52_7: Space = unwrap(&(v52_6),&(*p0));
  let v52_8: Space = restrict_to(&(v52_6),&(v52_7));
  drop(v52_6);
  let mut v52_18 = Space::new();
  let mut v52_18_cursor = (v52_8).read_zipper();
  for v52_18_byte in v52_18_cursor.child_mask().iter() {
    v52_18_cursor.descend_to_byte(v52_18_byte);
    let v52_18_tail = v52_18_cursor.make_map();
    v52_18_cursor.ascend(1);
    let v52_18_head = Path::from_slice(&[v52_18_byte]);
    let v53_2: Space = singleton(&(v52_18_head));
    let v53_3: Space = intersect(&(*CONSTANT_1),&(v53_2));
    let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
    drop(v53_3);
    let v53_5: Space = subtract(&(*CONSTANT_0),&(v53_4));
    drop(v53_4);
    let v53_7: Space = if (v53_5).is_empty() { Space::new() } else {
      let mut v54_6 = Space::new();
      let mut v54_6_cursor = (v52_18_tail).read_zipper();
      for v54_6_byte in v54_6_cursor.child_mask().iter() {
        v54_6_cursor.descend_to_byte(v54_6_byte);
        let v54_6_tail = v54_6_cursor.make_map();
        v54_6_cursor.ascend(1);
        let v54_6_head = Path::from_slice(&[v54_6_byte]);
        let v55_2: Space = singleton(&(v54_6_head));
        let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
        let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
        drop(v55_3);
        let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
        drop(v55_4);
        let v55_8: Space = if (v55_5).is_empty() { Space::new() } else {
          let v56_6: Path = concat_path(&(v52_18_head),&(v54_6_head));
          let v56_7: Space = routine_12(c, &(v56_6), &(v54_6_tail));
          compose(&(v55_5),&(v56_7))
        };
        drop(v55_5);
        let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
        drop(v55_2);
        let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
        drop(v55_9);
        let v55_12: Space = if (v55_10).is_empty() { Space::new() } else {
          let v57_6: Path = concat_path(&(v52_18_head),&(v54_6_head));
          let v57_11: Space = routine_13(c, &(v57_6), &(v54_6_tail));
          drop(v57_6);
          compose(&(v55_10),&(v57_11))
        };
        drop(v55_10);
        let v55_13: Space = unite(&(v55_8),&(v55_12));
        v54_6.join_into((v55_13).clone());
      }
      drop(v54_6_cursor);
      compose(&(v53_5),&(v54_6))
    };
    drop(v53_5);
    let v53_8: Space = intersect(&(*CONSTANT_1),&(v53_2));
    drop(v53_2);
    let v53_9: Space = if has_head(&(v53_8)) { singleton(&[]) } else { Space::new() };
    drop(v53_8);
    let v53_11: Space = if (v53_9).is_empty() { Space::new() } else {
      let mut v58_10 = Space::new();
      let mut v58_10_cursor = (v52_18_tail).read_zipper();
      for v58_10_byte in v58_10_cursor.child_mask().iter() {
        v58_10_cursor.descend_to_byte(v58_10_byte);
        let v58_10_tail = v58_10_cursor.make_map();
        v58_10_cursor.ascend(1);
        let v58_10_head = Path::from_slice(&[v58_10_byte]);
        let v59_2: Space = singleton(&(v58_10_head));
        let v59_3: Space = intersect(&(*CONSTANT_1),&(v59_2));
        let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
        drop(v59_3);
        let v59_5: Space = subtract(&(*CONSTANT_0),&(v59_4));
        drop(v59_4);
        let v59_8: Space = if (v59_5).is_empty() { Space::new() } else {
          let v60_6: Path = concat_path(&(v52_18_head),&(v58_10_head));
          let v60_7: Space = routine_12(c, &(v60_6), &(v58_10_tail));
          compose(&(v59_5),&(v60_7))
        };
        drop(v59_5);
        let v59_9: Space = intersect(&(*CONSTANT_1),&(v59_2));
        drop(v59_2);
        let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
        drop(v59_9);
        let v59_12: Space = if (v59_10).is_empty() { Space::new() } else {
          let v61_6: Path = concat_path(&(v52_18_head),&(v58_10_head));
          let v61_11: Space = routine_14(c, &(v61_6), &(v58_10_tail));
          drop(v61_6);
          compose(&(v59_10),&(v61_11))
        };
        drop(v59_10);
        let v59_13: Space = unite(&(v59_8),&(v59_12));
        v58_10.join_into((v59_13).clone());
      }
      drop(v58_10_cursor);
      compose(&(v53_9),&(v58_10))
    };
    drop(v53_9);
    let v53_12: Space = unite(&(v53_7),&(v53_11));
    v52_18.join_into((v53_12).clone());
  }
  drop(v52_18_cursor);
  drop(v52_8);
  let v52_19: Space = restrict_to(&(v52_4),&(v52_18));
  drop(v52_4);
  let mut v52_29 = Space::new();
  let mut v52_29_cursor = (v52_19).read_zipper();
  for v52_29_byte in v52_29_cursor.child_mask().iter() {
    v52_29_cursor.descend_to_byte(v52_29_byte);
    let v52_29_tail = v52_29_cursor.make_map();
    v52_29_cursor.ascend(1);
    let v52_29_head = Path::from_slice(&[v52_29_byte]);
    let v62_2: Space = singleton(&(v52_29_head));
    let v62_3: Space = intersect(&(*CONSTANT_1),&(v62_2));
    let v62_4: Space = if has_head(&(v62_3)) { singleton(&[]) } else { Space::new() };
    drop(v62_3);
    let v62_5: Space = subtract(&(*CONSTANT_0),&(v62_4));
    drop(v62_4);
    let v62_7: Space = if (v62_5).is_empty() { Space::new() } else {
      let mut v63_6 = Space::new();
      let mut v63_6_cursor = (v52_29_tail).read_zipper();
      for v63_6_byte in v63_6_cursor.child_mask().iter() {
        v63_6_cursor.descend_to_byte(v63_6_byte);
        let v63_6_tail = v63_6_cursor.make_map();
        v63_6_cursor.ascend(1);
        let v63_6_head = Path::from_slice(&[v63_6_byte]);
        let v64_2: Space = singleton(&(v63_6_head));
        let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
        let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
        drop(v64_3);
        let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
        drop(v64_4);
        let v64_8: Space = if (v64_5).is_empty() { Space::new() } else {
          let v65_6: Path = concat_path(&(v52_29_head),&(v63_6_head));
          let v65_7: Space = routine_15(c, &(v65_6), &(v63_6_tail));
          compose(&(v64_5),&(v65_7))
        };
        drop(v64_5);
        let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
        drop(v64_2);
        let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
        drop(v64_9);
        let v64_12: Space = if (v64_10).is_empty() { Space::new() } else {
          let v66_6: Path = concat_path(&(v52_29_head),&(v63_6_head));
          let v66_11: Space = routine_16(c, &(v66_6), &(v63_6_tail));
          drop(v66_6);
          compose(&(v64_10),&(v66_11))
        };
        drop(v64_10);
        let v64_13: Space = unite(&(v64_8),&(v64_12));
        v63_6.join_into((v64_13).clone());
      }
      drop(v63_6_cursor);
      compose(&(v62_5),&(v63_6))
    };
    drop(v62_5);
    let v62_8: Space = intersect(&(*CONSTANT_1),&(v62_2));
    drop(v62_2);
    let v62_9: Space = if has_head(&(v62_8)) { singleton(&[]) } else { Space::new() };
    drop(v62_8);
    let v62_11: Space = if (v62_9).is_empty() { Space::new() } else {
      let mut v67_10 = Space::new();
      let mut v67_10_cursor = (v52_29_tail).read_zipper();
      for v67_10_byte in v67_10_cursor.child_mask().iter() {
        v67_10_cursor.descend_to_byte(v67_10_byte);
        let v67_10_tail = v67_10_cursor.make_map();
        v67_10_cursor.ascend(1);
        let v67_10_head = Path::from_slice(&[v67_10_byte]);
        let v68_2: Space = singleton(&(v67_10_head));
        let v68_3: Space = intersect(&(*CONSTANT_1),&(v68_2));
        let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
        drop(v68_3);
        let v68_5: Space = subtract(&(*CONSTANT_0),&(v68_4));
        drop(v68_4);
        let v68_8: Space = if (v68_5).is_empty() { Space::new() } else {
          let v69_6: Path = concat_path(&(v52_29_head),&(v67_10_head));
          let v69_7: Space = routine_15(c, &(v69_6), &(v67_10_tail));
          compose(&(v68_5),&(v69_7))
        };
        drop(v68_5);
        let v68_9: Space = intersect(&(*CONSTANT_1),&(v68_2));
        drop(v68_2);
        let v68_10: Space = if has_head(&(v68_9)) { singleton(&[]) } else { Space::new() };
        drop(v68_9);
        let v68_12: Space = if (v68_10).is_empty() { Space::new() } else {
          let v70_6: Path = concat_path(&(v52_29_head),&(v67_10_head));
          let v70_11: Space = routine_17(c, &(v70_6), &(v67_10_tail));
          drop(v70_6);
          compose(&(v68_10),&(v70_11))
        };
        drop(v68_10);
        let v68_13: Space = unite(&(v68_8),&(v68_12));
        v67_10.join_into((v68_13).clone());
      }
      drop(v67_10_cursor);
      compose(&(v62_9),&(v67_10))
    };
    drop(v62_9);
    let v62_12: Space = unite(&(v62_7),&(v62_11));
    v52_29.join_into((v62_12).clone());
  }
  drop(v52_29_cursor);
  let v52_30: Space = subtract(&(v52_29),&(v52_7));
  drop(v52_7);
  let v52_32: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let v52_33: Space = intersect(&(v52_30),&(v52_32));
  drop(v52_32);
  let v52_34: Space = wrap(&(v52_33),&(*p0));
  (v52_34).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v71_11 = Space::new();
  let mut v71_11_cursor = (*s0).read_zipper();
  for v71_11_byte in v71_11_cursor.child_mask().iter() {
    v71_11_cursor.descend_to_byte(v71_11_byte);
    let v71_11_tail = v71_11_cursor.make_map();
    v71_11_cursor.ascend(1);
    let v71_11_head = Path::from_slice(&[v71_11_byte]);
    let v72_2: Space = singleton(&(v71_11_head));
    let v72_3: Space = intersect(&(*CONSTANT_1),&(v72_2));
    let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
    drop(v72_3);
    let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
    drop(v72_4);
    let v72_8: Space = if (v72_5).is_empty() { Space::new() } else {
      let v73_6: Path = concat_path(&(*p0),&(v71_11_head));
      let mut v73_7 = Space::new();
      let mut v73_7_cursor = (v71_11_tail).read_zipper();
      for v73_7_byte in v73_7_cursor.child_mask().iter() {
        v73_7_cursor.descend_to_byte(v73_7_byte);
        let v73_7_tail = v73_7_cursor.make_map();
        v73_7_cursor.ascend(1);
        let v73_7_head = Path::from_slice(&[v73_7_byte]);
        let v74_2: Space = singleton(&(v73_7_head));
        let v74_3: Space = intersect(&(*CONSTANT_1),&(v74_2));
        let v74_4: Space = if has_head(&(v74_3)) { singleton(&[]) } else { Space::new() };
        drop(v74_3);
        let v74_5: Space = subtract(&(*CONSTANT_0),&(v74_4));
        drop(v74_4);
        let v74_8: Space = if (v74_5).is_empty() { Space::new() } else {
          let v75_6: Path = concat_path(&(v73_6),&(v73_7_head));
          let v75_7: Space = routine_18(c, &(v75_6), &(v73_7_tail));
          compose(&(v74_5),&(v75_7))
        };
        drop(v74_5);
        let v74_9: Space = intersect(&(*CONSTANT_1),&(v74_2));
        drop(v74_2);
        let v74_10: Space = if has_head(&(v74_9)) { singleton(&[]) } else { Space::new() };
        drop(v74_9);
        let v74_12: Space = if (v74_10).is_empty() { Space::new() } else {
          let v76_6: Path = concat_path(&(v73_6),&(v73_7_head));
          let v76_11: Space = routine_19(c, &(v76_6), &(v73_7_tail));
          drop(v76_6);
          compose(&(v74_10),&(v76_11))
        };
        drop(v74_10);
        let v74_13: Space = unite(&(v74_8),&(v74_12));
        v73_7.join_into((v74_13).clone());
      }
      drop(v73_7_cursor);
      compose(&(v72_5),&(v73_7))
    };
    drop(v72_5);
    let v72_9: Space = intersect(&(*CONSTANT_1),&(v72_2));
    drop(v72_2);
    let v72_10: Space = if has_head(&(v72_9)) { singleton(&[]) } else { Space::new() };
    drop(v72_9);
    let v72_12: Space = if (v72_10).is_empty() { Space::new() } else {
      let v77_6: Path = concat_path(&(*p0),&(v71_11_head));
      let mut v77_11 = Space::new();
      let mut v77_11_cursor = (v71_11_tail).read_zipper();
      for v77_11_byte in v77_11_cursor.child_mask().iter() {
        v77_11_cursor.descend_to_byte(v77_11_byte);
        let v77_11_tail = v77_11_cursor.make_map();
        v77_11_cursor.ascend(1);
        let v77_11_head = Path::from_slice(&[v77_11_byte]);
        let v78_2: Space = singleton(&(v77_11_head));
        let v78_3: Space = intersect(&(*CONSTANT_1),&(v78_2));
        let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
        drop(v78_3);
        let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
        drop(v78_4);
        let v78_8: Space = if (v78_5).is_empty() { Space::new() } else {
          let v79_6: Path = concat_path(&(v77_6),&(v77_11_head));
          let v79_7: Space = routine_18(c, &(v79_6), &(v77_11_tail));
          compose(&(v78_5),&(v79_7))
        };
        drop(v78_5);
        let v78_9: Space = intersect(&(*CONSTANT_1),&(v78_2));
        drop(v78_2);
        let v78_10: Space = if has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
        drop(v78_9);
        let v78_12: Space = if (v78_10).is_empty() { Space::new() } else {
          let v80_6: Path = concat_path(&(v77_6),&(v77_11_head));
          let v80_11: Space = routine_14(c, &(v80_6), &(v77_11_tail));
          drop(v80_6);
          compose(&(v78_10),&(v80_11))
        };
        drop(v78_10);
        let v78_13: Space = unite(&(v78_8),&(v78_12));
        v77_11.join_into((v78_13).clone());
      }
      drop(v77_11_cursor);
      drop(v77_6);
      compose(&(v72_10),&(v77_11))
    };
    drop(v72_10);
    let v72_13: Space = unite(&(v72_8),&(v72_12));
    v71_11.join_into((v72_13).clone());
  }
  drop(v71_11_cursor);
  (v71_11).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v81_8 = Space::new();
  let mut v81_8_cursor = (*s0).read_zipper();
  for v81_8_byte in v81_8_cursor.child_mask().iter() {
    v81_8_cursor.descend_to_byte(v81_8_byte);
    let v81_8_tail = v81_8_cursor.make_map();
    v81_8_cursor.ascend(1);
    let v81_8_head = Path::from_slice(&[v81_8_byte]);
    let v82_2: Space = singleton(&(v81_8_head));
    let v82_3: Space = intersect(&(*CONSTANT_1),&(v82_2));
    let v82_4: Space = if has_head(&(v82_3)) { singleton(&[]) } else { Space::new() };
    drop(v82_3);
    let v82_5: Space = subtract(&(*CONSTANT_0),&(v82_4));
    drop(v82_4);
    let v82_8: Space = if (v82_5).is_empty() { Space::new() } else {
      let v83_6: Path = concat_path(&(*p0),&(v81_8_head));
      let mut v83_7 = Space::new();
      let mut v83_7_cursor = (v81_8_tail).read_zipper();
      for v83_7_byte in v83_7_cursor.child_mask().iter() {
        v83_7_cursor.descend_to_byte(v83_7_byte);
        let v83_7_tail = v83_7_cursor.make_map();
        v83_7_cursor.ascend(1);
        let v83_7_head = Path::from_slice(&[v83_7_byte]);
        let v84_2: Space = singleton(&(v83_7_head));
        let v84_3: Space = intersect(&(*CONSTANT_1),&(v84_2));
        let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
        drop(v84_3);
        let v84_5: Space = subtract(&(*CONSTANT_0),&(v84_4));
        drop(v84_4);
        let v84_8: Space = if (v84_5).is_empty() { Space::new() } else {
          let v85_6: Path = concat_path(&(v83_6),&(v83_7_head));
          let v85_7: Space = routine_18(c, &(v85_6), &(v83_7_tail));
          compose(&(v84_5),&(v85_7))
        };
        drop(v84_5);
        let v84_9: Space = intersect(&(*CONSTANT_1),&(v84_2));
        drop(v84_2);
        let v84_10: Space = if has_head(&(v84_9)) { singleton(&[]) } else { Space::new() };
        drop(v84_9);
        let v84_12: Space = if (v84_10).is_empty() { Space::new() } else {
          let v86_6: Path = concat_path(&(v83_6),&(v83_7_head));
          let v86_11: Space = routine_19(c, &(v86_6), &(v83_7_tail));
          drop(v86_6);
          compose(&(v84_10),&(v86_11))
        };
        drop(v84_10);
        let v84_13: Space = unite(&(v84_8),&(v84_12));
        v83_7.join_into((v84_13).clone());
      }
      drop(v83_7_cursor);
      drop(v83_6);
      compose(&(v82_5),&(v83_7))
    };
    drop(v82_5);
    let v82_9: Space = intersect(&(*CONSTANT_1),&(v82_2));
    drop(v82_2);
    let v82_10: Space = if has_head(&(v82_9)) { singleton(&[]) } else { Space::new() };
    drop(v82_9);
    let v82_11: Space = compose(&(v82_10),&(v81_8_tail));
    drop(v82_10);
    let v82_12: Space = unite(&(v82_8),&(v82_11));
    drop(v82_11);
    v81_8.join_into((v82_12).clone());
  }
  drop(v81_8_cursor);
  (v81_8).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v87_11 = Space::new();
  let mut v87_11_cursor = (*s0).read_zipper();
  for v87_11_byte in v87_11_cursor.child_mask().iter() {
    v87_11_cursor.descend_to_byte(v87_11_byte);
    let v87_11_tail = v87_11_cursor.make_map();
    v87_11_cursor.ascend(1);
    let v87_11_head = Path::from_slice(&[v87_11_byte]);
    let v88_2: Space = singleton(&(v87_11_head));
    let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
    let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
    drop(v88_3);
    let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
    drop(v88_4);
    let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
      let v89_6: Path = concat_path(&(*p0),&(v87_11_head));
      let mut v89_7 = Space::new();
      let mut v89_7_cursor = (v87_11_tail).read_zipper();
      for v89_7_byte in v89_7_cursor.child_mask().iter() {
        v89_7_cursor.descend_to_byte(v89_7_byte);
        let v89_7_tail = v89_7_cursor.make_map();
        v89_7_cursor.ascend(1);
        let v89_7_head = Path::from_slice(&[v89_7_byte]);
        let v90_2: Space = singleton(&(v89_7_head));
        let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
        let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
        drop(v90_3);
        let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
        drop(v90_4);
        let v90_8: Space = if (v90_5).is_empty() { Space::new() } else {
          let v91_6: Path = concat_path(&(v89_6),&(v89_7_head));
          let v91_7: Space = routine_20(c, &(v91_6), &(v89_7_tail));
          compose(&(v90_5),&(v91_7))
        };
        drop(v90_5);
        let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
        drop(v90_2);
        let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
        drop(v90_9);
        let v90_12: Space = if (v90_10).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v89_6),&(v89_7_head));
          let v92_11: Space = routine_21(c, &(v92_6), &(v89_7_tail));
          drop(v92_6);
          compose(&(v90_10),&(v92_11))
        };
        drop(v90_10);
        let v90_13: Space = unite(&(v90_8),&(v90_12));
        v89_7.join_into((v90_13).clone());
      }
      drop(v89_7_cursor);
      compose(&(v88_5),&(v89_7))
    };
    drop(v88_5);
    let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
    drop(v88_2);
    let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
    drop(v88_9);
    let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
      let v93_6: Path = concat_path(&(*p0),&(v87_11_head));
      let mut v93_11 = Space::new();
      let mut v93_11_cursor = (v87_11_tail).read_zipper();
      for v93_11_byte in v93_11_cursor.child_mask().iter() {
        v93_11_cursor.descend_to_byte(v93_11_byte);
        let v93_11_tail = v93_11_cursor.make_map();
        v93_11_cursor.ascend(1);
        let v93_11_head = Path::from_slice(&[v93_11_byte]);
        let v94_2: Space = singleton(&(v93_11_head));
        let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
        let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
        drop(v94_3);
        let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
        drop(v94_4);
        let v94_8: Space = if (v94_5).is_empty() { Space::new() } else {
          let v95_6: Path = concat_path(&(v93_6),&(v93_11_head));
          let v95_7: Space = routine_20(c, &(v95_6), &(v93_11_tail));
          compose(&(v94_5),&(v95_7))
        };
        drop(v94_5);
        let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
        drop(v94_2);
        let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
        drop(v94_9);
        let v94_12: Space = if (v94_10).is_empty() { Space::new() } else {
          let v96_6: Path = concat_path(&(v93_6),&(v93_11_head));
          let v96_11: Space = routine_17(c, &(v96_6), &(v93_11_tail));
          drop(v96_6);
          compose(&(v94_10),&(v96_11))
        };
        drop(v94_10);
        let v94_13: Space = unite(&(v94_8),&(v94_12));
        v93_11.join_into((v94_13).clone());
      }
      drop(v93_11_cursor);
      drop(v93_6);
      compose(&(v88_10),&(v93_11))
    };
    drop(v88_10);
    let v88_13: Space = unite(&(v88_8),&(v88_12));
    v87_11.join_into((v88_13).clone());
  }
  drop(v87_11_cursor);
  (v87_11).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v97_8 = Space::new();
  let mut v97_8_cursor = (*s0).read_zipper();
  for v97_8_byte in v97_8_cursor.child_mask().iter() {
    v97_8_cursor.descend_to_byte(v97_8_byte);
    let v97_8_tail = v97_8_cursor.make_map();
    v97_8_cursor.ascend(1);
    let v97_8_head = Path::from_slice(&[v97_8_byte]);
    let v98_2: Space = singleton(&(v97_8_head));
    let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
    let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
    drop(v98_3);
    let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
    drop(v98_4);
    let v98_8: Space = if (v98_5).is_empty() { Space::new() } else {
      let v99_6: Path = concat_path(&(*p0),&(v97_8_head));
      let mut v99_7 = Space::new();
      let mut v99_7_cursor = (v97_8_tail).read_zipper();
      for v99_7_byte in v99_7_cursor.child_mask().iter() {
        v99_7_cursor.descend_to_byte(v99_7_byte);
        let v99_7_tail = v99_7_cursor.make_map();
        v99_7_cursor.ascend(1);
        let v99_7_head = Path::from_slice(&[v99_7_byte]);
        let v100_2: Space = singleton(&(v99_7_head));
        let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
        let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
        drop(v100_3);
        let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
        drop(v100_4);
        let v100_8: Space = if (v100_5).is_empty() { Space::new() } else {
          let v101_6: Path = concat_path(&(v99_6),&(v99_7_head));
          let v101_7: Space = routine_20(c, &(v101_6), &(v99_7_tail));
          compose(&(v100_5),&(v101_7))
        };
        drop(v100_5);
        let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
        drop(v100_2);
        let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
        drop(v100_9);
        let v100_12: Space = if (v100_10).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v99_6),&(v99_7_head));
          let v102_11: Space = routine_21(c, &(v102_6), &(v99_7_tail));
          drop(v102_6);
          compose(&(v100_10),&(v102_11))
        };
        drop(v100_10);
        let v100_13: Space = unite(&(v100_8),&(v100_12));
        v99_7.join_into((v100_13).clone());
      }
      drop(v99_7_cursor);
      drop(v99_6);
      compose(&(v98_5),&(v99_7))
    };
    drop(v98_5);
    let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
    drop(v98_2);
    let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
    drop(v98_9);
    let v98_11: Space = compose(&(v98_10),&(v97_8_tail));
    drop(v98_10);
    let v98_12: Space = unite(&(v98_8),&(v98_11));
    drop(v98_11);
    v97_8.join_into((v98_12).clone());
  }
  drop(v97_8_cursor);
  (v97_8).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v103_12 = Space::new();
  let mut v103_12_cursor = (*s0).read_zipper();
  for v103_12_byte in v103_12_cursor.child_mask().iter() {
    v103_12_cursor.descend_to_byte(v103_12_byte);
    let v103_12_tail = v103_12_cursor.make_map();
    v103_12_cursor.ascend(1);
    let v103_12_head = Path::from_slice(&[v103_12_byte]);
    let v104_2: Space = singleton(&(v103_12_head));
    let v104_3: Space = intersect(&(*CONSTANT_1),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_8: Space = if (v104_5).is_empty() { Space::new() } else {
      let v105_6: Path = concat_path(&(*p0),&(v103_12_head));
      let mut v105_7 = Space::new();
      let mut v105_7_cursor = (v103_12_tail).read_zipper();
      for v105_7_byte in v105_7_cursor.child_mask().iter() {
        v105_7_cursor.descend_to_byte(v105_7_byte);
        let v105_7_tail = v105_7_cursor.make_map();
        v105_7_cursor.ascend(1);
        let v105_7_head = Path::from_slice(&[v105_7_byte]);
        let v106_2: Space = singleton(&(v105_7_head));
        let v106_3: Space = intersect(&(*CONSTANT_1),&(v106_2));
        let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
        drop(v106_4);
        let v106_8: Space = if (v106_5).is_empty() { Space::new() } else {
          let v107_6: Path = concat_path(&(v105_6),&(v105_7_head));
          let v107_7: Space = routine_22(c, &(v107_6), &(v105_7_tail), &(*s1));
          compose(&(v106_5),&(v107_7))
        };
        drop(v106_5);
        let v106_9: Space = intersect(&(*CONSTANT_1),&(v106_2));
        drop(v106_2);
        let v106_10: Space = if has_head(&(v106_9)) { singleton(&[]) } else { Space::new() };
        drop(v106_9);
        let v106_12: Space = if (v106_10).is_empty() { Space::new() } else {
          let v108_6: Path = concat_path(&(v105_6),&(v105_7_head));
          let v108_11: Space = routine_23(c, &(v108_6), &(v105_7_tail), &(*s1));
          drop(v108_6);
          compose(&(v106_10),&(v108_11))
        };
        drop(v106_10);
        let v106_13: Space = unite(&(v106_8),&(v106_12));
        v105_7.join_into((v106_13).clone());
      }
      drop(v105_7_cursor);
      compose(&(v104_5),&(v105_7))
    };
    drop(v104_5);
    let v104_9: Space = intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
    drop(v104_9);
    let v104_12: Space = if (v104_10).is_empty() { Space::new() } else {
      let v109_6: Path = concat_path(&(*p0),&(v103_12_head));
      let mut v109_11 = Space::new();
      let mut v109_11_cursor = (v103_12_tail).read_zipper();
      for v109_11_byte in v109_11_cursor.child_mask().iter() {
        v109_11_cursor.descend_to_byte(v109_11_byte);
        let v109_11_tail = v109_11_cursor.make_map();
        v109_11_cursor.ascend(1);
        let v109_11_head = Path::from_slice(&[v109_11_byte]);
        let v110_2: Space = singleton(&(v109_11_head));
        let v110_3: Space = intersect(&(*CONSTANT_1),&(v110_2));
        let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
        drop(v110_3);
        let v110_5: Space = subtract(&(*CONSTANT_0),&(v110_4));
        drop(v110_4);
        let v110_8: Space = if (v110_5).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v109_6),&(v109_11_head));
          let v111_7: Space = routine_22(c, &(v111_6), &(v109_11_tail), &(*s1));
          compose(&(v110_5),&(v111_7))
        };
        drop(v110_5);
        let v110_9: Space = intersect(&(*CONSTANT_1),&(v110_2));
        drop(v110_2);
        let v110_10: Space = if has_head(&(v110_9)) { singleton(&[]) } else { Space::new() };
        drop(v110_9);
        let v110_12: Space = if (v110_10).is_empty() { Space::new() } else {
          let v112_6: Path = concat_path(&(v109_6),&(v109_11_head));
          let v112_11: Space = routine_5(c, &(v112_6), &(v109_11_tail), &(*s1));
          drop(v112_6);
          compose(&(v110_10),&(v112_11))
        };
        drop(v110_10);
        let v110_13: Space = unite(&(v110_8),&(v110_12));
        v109_11.join_into((v110_13).clone());
      }
      drop(v109_11_cursor);
      drop(v109_6);
      compose(&(v104_10),&(v109_11))
    };
    drop(v104_10);
    let v104_13: Space = unite(&(v104_8),&(v104_12));
    v103_12.join_into((v104_13).clone());
  }
  drop(v103_12_cursor);
  (v103_12).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v113_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v113_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v113_10: Space = unwrap(&(v113_9),&(*p0));
  let v113_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v113_22 = Space::new();
  let mut v113_22_cursor = (*s0).read_zipper();
  for v113_22_byte in v113_22_cursor.child_mask().iter() {
    v113_22_cursor.descend_to_byte(v113_22_byte);
    let v113_22_tail = v113_22_cursor.make_map();
    v113_22_cursor.ascend(1);
    let v113_22_head = Path::from_slice(&[v113_22_byte]);
    let v114_2: Space = singleton(&(v113_22_head));
    let v114_3: Space = intersect(&(*CONSTANT_1),&(v114_2));
    let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
    drop(v114_3);
    let v114_5: Space = subtract(&(*CONSTANT_0),&(v114_4));
    drop(v114_4);
    let v114_8: Space = if (v114_5).is_empty() { Space::new() } else {
      let v115_6: Path = concat_path(&(*p0),&(v113_22_head));
      let mut v115_7 = Space::new();
      let mut v115_7_cursor = (v113_22_tail).read_zipper();
      for v115_7_byte in v115_7_cursor.child_mask().iter() {
        v115_7_cursor.descend_to_byte(v115_7_byte);
        let v115_7_tail = v115_7_cursor.make_map();
        v115_7_cursor.ascend(1);
        let v115_7_head = Path::from_slice(&[v115_7_byte]);
        let v116_2: Space = singleton(&(v115_7_head));
        let v116_3: Space = intersect(&(*CONSTANT_1),&(v116_2));
        let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
        drop(v116_3);
        let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
        drop(v116_4);
        let v116_8: Space = if (v116_5).is_empty() { Space::new() } else {
          let v117_6: Path = concat_path(&(v115_6),&(v115_7_head));
          let v117_7: Space = routine_22(c, &(v117_6), &(v115_7_tail), &(*s1));
          compose(&(v116_5),&(v117_7))
        };
        drop(v116_5);
        let v116_9: Space = intersect(&(*CONSTANT_1),&(v116_2));
        drop(v116_2);
        let v116_10: Space = if has_head(&(v116_9)) { singleton(&[]) } else { Space::new() };
        drop(v116_9);
        let v116_12: Space = if (v116_10).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v115_6),&(v115_7_head));
          let v118_11: Space = routine_23(c, &(v118_6), &(v115_7_tail), &(*s1));
          drop(v118_6);
          compose(&(v116_10),&(v118_11))
        };
        drop(v116_10);
        let v116_13: Space = unite(&(v116_8),&(v116_12));
        v115_7.join_into((v116_13).clone());
      }
      drop(v115_7_cursor);
      compose(&(v114_5),&(v115_7))
    };
    drop(v114_5);
    let v114_9: Space = intersect(&(*CONSTANT_1),&(v114_2));
    drop(v114_2);
    let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
    drop(v114_9);
    let v114_18: Space = if (v114_10).is_empty() { Space::new() } else {
      let v119_11: Space = unwrap(&(v113_10),&(v113_22_head));
      let v119_12: Space = restrict_to(&(v113_9),&(v119_11));
      let mut v119_13 = Space::new();
      let mut v119_13_cursor = (v119_12).read_zipper();
      for v119_13_byte in v119_13_cursor.child_mask().iter() {
        v119_13_cursor.descend_to_byte(v119_13_byte);
        let v119_13_tail = v119_13_cursor.make_map();
        v119_13_cursor.ascend(1);
        let v119_13_head = Path::from_slice(&[v119_13_byte]);
        let v120_2: Space = singleton(&(v119_13_head));
        let v120_3: Space = intersect(&(*CONSTANT_1),&(v120_2));
        let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
        drop(v120_3);
        let v120_5: Space = subtract(&(*CONSTANT_0),&(v120_4));
        drop(v120_4);
        let v120_7: Space = if (v120_5).is_empty() { Space::new() } else {
          let v121_6: Space = routine_6(c, &(v119_13_head), &(v119_13_tail));
          compose(&(v120_5),&(v121_6))
        };
        drop(v120_5);
        let v120_8: Space = intersect(&(*CONSTANT_1),&(v120_2));
        drop(v120_2);
        let v120_9: Space = if has_head(&(v120_8)) { singleton(&[]) } else { Space::new() };
        drop(v120_8);
        let v120_11: Space = if (v120_9).is_empty() { Space::new() } else {
          let v122_10: Space = routine_7(c, &(v119_13_head), &(v119_13_tail));
          compose(&(v120_9),&(v122_10))
        };
        drop(v120_9);
        let v120_12: Space = unite(&(v120_7),&(v120_11));
        v119_13.join_into((v120_12).clone());
      }
      drop(v119_13_cursor);
      drop(v119_12);
      let v119_14: Space = restrict_to(&(v113_7),&(v119_13));
      let mut v119_15 = Space::new();
      let mut v119_15_cursor = (v119_14).read_zipper();
      for v119_15_byte in v119_15_cursor.child_mask().iter() {
        v119_15_cursor.descend_to_byte(v119_15_byte);
        let v119_15_tail = v119_15_cursor.make_map();
        v119_15_cursor.ascend(1);
        let v119_15_head = Path::from_slice(&[v119_15_byte]);
        let v123_2: Space = singleton(&(v119_15_head));
        let v123_3: Space = intersect(&(*CONSTANT_1),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
        drop(v123_4);
        let v123_7: Space = if (v123_5).is_empty() { Space::new() } else {
          let v124_6: Space = routine_8(c, &(v119_15_head), &(v119_15_tail));
          compose(&(v123_5),&(v124_6))
        };
        drop(v123_5);
        let v123_8: Space = intersect(&(*CONSTANT_1),&(v123_2));
        drop(v123_2);
        let v123_9: Space = if has_head(&(v123_8)) { singleton(&[]) } else { Space::new() };
        drop(v123_8);
        let v123_11: Space = if (v123_9).is_empty() { Space::new() } else {
          let v125_10: Space = routine_9(c, &(v119_15_head), &(v119_15_tail));
          compose(&(v123_9),&(v125_10))
        };
        drop(v123_9);
        let v123_12: Space = unite(&(v123_7),&(v123_11));
        v119_15.join_into((v123_12).clone());
      }
      drop(v119_15_cursor);
      let v119_16: Space = subtract(&(v119_15),&(v119_11));
      drop(v119_11);
      let v119_17: Space = intersect(&(v119_16),&(v113_12));
      compose(&(v114_10),&(v119_17))
    };
    drop(v114_10);
    let v126_6: Path = concat_path(&(*p0),&(v113_22_head));
    let v114_19: Space = wrap(&(v114_18),&(v126_6));
    let v114_20: Space = unite(&(v114_8),&(v114_19));
    v113_22.join_into((v114_20).clone());
  }
  drop(v113_22_cursor);
  drop(v113_7);
  drop(v113_9);
  drop(v113_10);
  drop(v113_12);
  (v113_22).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v127_11 = Space::new();
  let mut v127_11_cursor = (*s0).read_zipper();
  for v127_11_byte in v127_11_cursor.child_mask().iter() {
    v127_11_cursor.descend_to_byte(v127_11_byte);
    let v127_11_tail = v127_11_cursor.make_map();
    v127_11_cursor.ascend(1);
    let v127_11_head = Path::from_slice(&[v127_11_byte]);
    let v128_2: Space = singleton(&(v127_11_head));
    let v128_3: Space = intersect(&(*CONSTANT_1),&(v128_2));
    let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
    drop(v128_3);
    let v128_5: Space = subtract(&(*CONSTANT_0),&(v128_4));
    drop(v128_4);
    let v128_8: Space = if (v128_5).is_empty() { Space::new() } else {
      let v129_6: Path = concat_path(&(*p0),&(v127_11_head));
      let mut v129_7 = Space::new();
      let mut v129_7_cursor = (v127_11_tail).read_zipper();
      for v129_7_byte in v129_7_cursor.child_mask().iter() {
        v129_7_cursor.descend_to_byte(v129_7_byte);
        let v129_7_tail = v129_7_cursor.make_map();
        v129_7_cursor.ascend(1);
        let v129_7_head = Path::from_slice(&[v129_7_byte]);
        let v130_2: Space = singleton(&(v129_7_head));
        let v130_3: Space = intersect(&(*CONSTANT_1),&(v130_2));
        let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
        drop(v130_3);
        let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
        drop(v130_4);
        let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
          let v131_6: Path = concat_path(&(v129_6),&(v129_7_head));
          let v131_7: Space = routine_24(c, &(v131_6), &(v129_7_tail));
          compose(&(v130_5),&(v131_7))
        };
        drop(v130_5);
        let v130_9: Space = intersect(&(*CONSTANT_1),&(v130_2));
        drop(v130_2);
        let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
        drop(v130_9);
        let v130_12: Space = if (v130_10).is_empty() { Space::new() } else {
          let v132_6: Path = concat_path(&(v129_6),&(v129_7_head));
          let v132_11: Space = routine_25(c, &(v132_6), &(v129_7_tail));
          drop(v132_6);
          compose(&(v130_10),&(v132_11))
        };
        drop(v130_10);
        let v130_13: Space = unite(&(v130_8),&(v130_12));
        v129_7.join_into((v130_13).clone());
      }
      drop(v129_7_cursor);
      compose(&(v128_5),&(v129_7))
    };
    drop(v128_5);
    let v128_9: Space = intersect(&(*CONSTANT_1),&(v128_2));
    drop(v128_2);
    let v128_10: Space = if has_head(&(v128_9)) { singleton(&[]) } else { Space::new() };
    drop(v128_9);
    let v128_12: Space = if (v128_10).is_empty() { Space::new() } else {
      let v133_6: Path = concat_path(&(*p0),&(v127_11_head));
      let mut v133_11 = Space::new();
      let mut v133_11_cursor = (v127_11_tail).read_zipper();
      for v133_11_byte in v133_11_cursor.child_mask().iter() {
        v133_11_cursor.descend_to_byte(v133_11_byte);
        let v133_11_tail = v133_11_cursor.make_map();
        v133_11_cursor.ascend(1);
        let v133_11_head = Path::from_slice(&[v133_11_byte]);
        let v134_2: Space = singleton(&(v133_11_head));
        let v134_3: Space = intersect(&(*CONSTANT_1),&(v134_2));
        let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
        drop(v134_3);
        let v134_5: Space = subtract(&(*CONSTANT_0),&(v134_4));
        drop(v134_4);
        let v134_8: Space = if (v134_5).is_empty() { Space::new() } else {
          let v135_6: Path = concat_path(&(v133_6),&(v133_11_head));
          let v135_7: Space = routine_24(c, &(v135_6), &(v133_11_tail));
          compose(&(v134_5),&(v135_7))
        };
        drop(v134_5);
        let v134_9: Space = intersect(&(*CONSTANT_1),&(v134_2));
        drop(v134_2);
        let v134_10: Space = if has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
        drop(v134_9);
        let v134_12: Space = if (v134_10).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v133_6),&(v133_11_head));
          let v136_11: Space = routine_14(c, &(v136_6), &(v133_11_tail));
          drop(v136_6);
          compose(&(v134_10),&(v136_11))
        };
        drop(v134_10);
        let v134_13: Space = unite(&(v134_8),&(v134_12));
        v133_11.join_into((v134_13).clone());
      }
      drop(v133_11_cursor);
      drop(v133_6);
      compose(&(v128_10),&(v133_11))
    };
    drop(v128_10);
    let v128_13: Space = unite(&(v128_8),&(v128_12));
    v127_11.join_into((v128_13).clone());
  }
  drop(v127_11_cursor);
  (v127_11).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v137_8 = Space::new();
  let mut v137_8_cursor = (*s0).read_zipper();
  for v137_8_byte in v137_8_cursor.child_mask().iter() {
    v137_8_cursor.descend_to_byte(v137_8_byte);
    let v137_8_tail = v137_8_cursor.make_map();
    v137_8_cursor.ascend(1);
    let v137_8_head = Path::from_slice(&[v137_8_byte]);
    let v138_2: Space = singleton(&(v137_8_head));
    let v138_3: Space = intersect(&(*CONSTANT_1),&(v138_2));
    let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
    drop(v138_3);
    let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
    drop(v138_4);
    let v138_8: Space = if (v138_5).is_empty() { Space::new() } else {
      let v139_6: Path = concat_path(&(*p0),&(v137_8_head));
      let mut v139_7 = Space::new();
      let mut v139_7_cursor = (v137_8_tail).read_zipper();
      for v139_7_byte in v139_7_cursor.child_mask().iter() {
        v139_7_cursor.descend_to_byte(v139_7_byte);
        let v139_7_tail = v139_7_cursor.make_map();
        v139_7_cursor.ascend(1);
        let v139_7_head = Path::from_slice(&[v139_7_byte]);
        let v140_2: Space = singleton(&(v139_7_head));
        let v140_3: Space = intersect(&(*CONSTANT_1),&(v140_2));
        let v140_4: Space = if has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
        drop(v140_3);
        let v140_5: Space = subtract(&(*CONSTANT_0),&(v140_4));
        drop(v140_4);
        let v140_8: Space = if (v140_5).is_empty() { Space::new() } else {
          let v141_6: Path = concat_path(&(v139_6),&(v139_7_head));
          let v141_7: Space = routine_24(c, &(v141_6), &(v139_7_tail));
          compose(&(v140_5),&(v141_7))
        };
        drop(v140_5);
        let v140_9: Space = intersect(&(*CONSTANT_1),&(v140_2));
        drop(v140_2);
        let v140_10: Space = if has_head(&(v140_9)) { singleton(&[]) } else { Space::new() };
        drop(v140_9);
        let v140_12: Space = if (v140_10).is_empty() { Space::new() } else {
          let v142_6: Path = concat_path(&(v139_6),&(v139_7_head));
          let v142_11: Space = routine_25(c, &(v142_6), &(v139_7_tail));
          drop(v142_6);
          compose(&(v140_10),&(v142_11))
        };
        drop(v140_10);
        let v140_13: Space = unite(&(v140_8),&(v140_12));
        v139_7.join_into((v140_13).clone());
      }
      drop(v139_7_cursor);
      drop(v139_6);
      compose(&(v138_5),&(v139_7))
    };
    drop(v138_5);
    let v138_9: Space = intersect(&(*CONSTANT_1),&(v138_2));
    drop(v138_2);
    let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
    drop(v138_9);
    let v138_11: Space = compose(&(v138_10),&(v137_8_tail));
    drop(v138_10);
    let v138_12: Space = unite(&(v138_8),&(v138_11));
    drop(v138_11);
    v137_8.join_into((v138_12).clone());
  }
  drop(v137_8_cursor);
  (v137_8).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v144_11 = Space::new();
  let mut v144_11_cursor = (*s0).read_zipper();
  for v144_11_byte in v144_11_cursor.child_mask().iter() {
    v144_11_cursor.descend_to_byte(v144_11_byte);
    let v144_11_tail = v144_11_cursor.make_map();
    v144_11_cursor.ascend(1);
    let v144_11_head = Path::from_slice(&[v144_11_byte]);
    let v145_2: Space = singleton(&(v144_11_head));
    let v145_3: Space = intersect(&(*CONSTANT_1),&(v145_2));
    let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
    drop(v145_3);
    let v145_5: Space = subtract(&(*CONSTANT_0),&(v145_4));
    drop(v145_4);
    let v145_8: Space = if (v145_5).is_empty() { Space::new() } else {
      let v146_6: Path = concat_path(&(*p0),&(v144_11_head));
      let mut v146_7 = Space::new();
      let mut v146_7_cursor = (v144_11_tail).read_zipper();
      for v146_7_byte in v146_7_cursor.child_mask().iter() {
        v146_7_cursor.descend_to_byte(v146_7_byte);
        let v146_7_tail = v146_7_cursor.make_map();
        v146_7_cursor.ascend(1);
        let v146_7_head = Path::from_slice(&[v146_7_byte]);
        let v147_2: Space = singleton(&(v146_7_head));
        let v147_3: Space = intersect(&(*CONSTANT_1),&(v147_2));
        let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
        drop(v147_3);
        let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
        drop(v147_4);
        let v147_8: Space = if (v147_5).is_empty() { Space::new() } else {
          let v148_6: Path = concat_path(&(v146_6),&(v146_7_head));
          let v148_7: Space = routine_26(c, &(v148_6), &(v146_7_tail));
          compose(&(v147_5),&(v148_7))
        };
        drop(v147_5);
        let v147_9: Space = intersect(&(*CONSTANT_1),&(v147_2));
        drop(v147_2);
        let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
        drop(v147_9);
        let v147_12: Space = if (v147_10).is_empty() { Space::new() } else {
          let v149_6: Path = concat_path(&(v146_6),&(v146_7_head));
          let v149_11: Space = routine_27(c, &(v149_6), &(v146_7_tail));
          drop(v149_6);
          compose(&(v147_10),&(v149_11))
        };
        drop(v147_10);
        let v147_13: Space = unite(&(v147_8),&(v147_12));
        v146_7.join_into((v147_13).clone());
      }
      drop(v146_7_cursor);
      compose(&(v145_5),&(v146_7))
    };
    drop(v145_5);
    let v145_9: Space = intersect(&(*CONSTANT_1),&(v145_2));
    drop(v145_2);
    let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
    drop(v145_9);
    let v145_12: Space = if (v145_10).is_empty() { Space::new() } else {
      let v150_6: Path = concat_path(&(*p0),&(v144_11_head));
      let mut v150_11 = Space::new();
      let mut v150_11_cursor = (v144_11_tail).read_zipper();
      for v150_11_byte in v150_11_cursor.child_mask().iter() {
        v150_11_cursor.descend_to_byte(v150_11_byte);
        let v150_11_tail = v150_11_cursor.make_map();
        v150_11_cursor.ascend(1);
        let v150_11_head = Path::from_slice(&[v150_11_byte]);
        let v151_2: Space = singleton(&(v150_11_head));
        let v151_3: Space = intersect(&(*CONSTANT_1),&(v151_2));
        let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
        drop(v151_3);
        let v151_5: Space = subtract(&(*CONSTANT_0),&(v151_4));
        drop(v151_4);
        let v151_8: Space = if (v151_5).is_empty() { Space::new() } else {
          let v152_6: Path = concat_path(&(v150_6),&(v150_11_head));
          let v152_7: Space = routine_26(c, &(v152_6), &(v150_11_tail));
          compose(&(v151_5),&(v152_7))
        };
        drop(v151_5);
        let v151_9: Space = intersect(&(*CONSTANT_1),&(v151_2));
        drop(v151_2);
        let v151_10: Space = if has_head(&(v151_9)) { singleton(&[]) } else { Space::new() };
        drop(v151_9);
        let v151_12: Space = if (v151_10).is_empty() { Space::new() } else {
          let v153_6: Path = concat_path(&(v150_6),&(v150_11_head));
          let v153_11: Space = routine_17(c, &(v153_6), &(v150_11_tail));
          drop(v153_6);
          compose(&(v151_10),&(v153_11))
        };
        drop(v151_10);
        let v151_13: Space = unite(&(v151_8),&(v151_12));
        v150_11.join_into((v151_13).clone());
      }
      drop(v150_11_cursor);
      drop(v150_6);
      compose(&(v145_10),&(v150_11))
    };
    drop(v145_10);
    let v145_13: Space = unite(&(v145_8),&(v145_12));
    v144_11.join_into((v145_13).clone());
  }
  drop(v144_11_cursor);
  (v144_11).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v154_8 = Space::new();
  let mut v154_8_cursor = (*s0).read_zipper();
  for v154_8_byte in v154_8_cursor.child_mask().iter() {
    v154_8_cursor.descend_to_byte(v154_8_byte);
    let v154_8_tail = v154_8_cursor.make_map();
    v154_8_cursor.ascend(1);
    let v154_8_head = Path::from_slice(&[v154_8_byte]);
    let v155_2: Space = singleton(&(v154_8_head));
    let v155_3: Space = intersect(&(*CONSTANT_1),&(v155_2));
    let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
    drop(v155_3);
    let v155_5: Space = subtract(&(*CONSTANT_0),&(v155_4));
    drop(v155_4);
    let v155_8: Space = if (v155_5).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&(v154_8_head));
      let mut v156_7 = Space::new();
      let mut v156_7_cursor = (v154_8_tail).read_zipper();
      for v156_7_byte in v156_7_cursor.child_mask().iter() {
        v156_7_cursor.descend_to_byte(v156_7_byte);
        let v156_7_tail = v156_7_cursor.make_map();
        v156_7_cursor.ascend(1);
        let v156_7_head = Path::from_slice(&[v156_7_byte]);
        let v157_2: Space = singleton(&(v156_7_head));
        let v157_3: Space = intersect(&(*CONSTANT_1),&(v157_2));
        let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = subtract(&(*CONSTANT_0),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&(v156_7_head));
          let v158_7: Space = routine_26(c, &(v158_6), &(v156_7_tail));
          compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = intersect(&(*CONSTANT_1),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
          let v159_6: Path = concat_path(&(v156_6),&(v156_7_head));
          let v159_11: Space = routine_27(c, &(v159_6), &(v156_7_tail));
          drop(v159_6);
          compose(&(v157_10),&(v159_11))
        };
        drop(v157_10);
        let v157_13: Space = unite(&(v157_8),&(v157_12));
        v156_7.join_into((v157_13).clone());
      }
      drop(v156_7_cursor);
      drop(v156_6);
      compose(&(v155_5),&(v156_7))
    };
    drop(v155_5);
    let v155_9: Space = intersect(&(*CONSTANT_1),&(v155_2));
    drop(v155_2);
    let v155_10: Space = if has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
    drop(v155_9);
    let v155_11: Space = compose(&(v155_10),&(v154_8_tail));
    drop(v155_10);
    let v155_12: Space = unite(&(v155_8),&(v155_11));
    drop(v155_11);
    v154_8.join_into((v155_12).clone());
  }
  drop(v154_8_cursor);
  (v154_8).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v161_11 = Space::new();
  let mut v161_11_cursor = (*s0).read_zipper();
  for v161_11_byte in v161_11_cursor.child_mask().iter() {
    v161_11_cursor.descend_to_byte(v161_11_byte);
    let v161_11_tail = v161_11_cursor.make_map();
    v161_11_cursor.ascend(1);
    let v161_11_head = Path::from_slice(&[v161_11_byte]);
    let v162_2: Space = singleton(&(v161_11_head));
    let v162_3: Space = intersect(&(*CONSTANT_1),&(v162_2));
    let v162_4: Space = if has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
    drop(v162_3);
    let v162_5: Space = subtract(&(*CONSTANT_0),&(v162_4));
    drop(v162_4);
    let v162_8: Space = if (v162_5).is_empty() { Space::new() } else {
      let v163_6: Path = concat_path(&(*p0),&(v161_11_head));
      let mut v163_7 = Space::new();
      let mut v163_7_cursor = (v161_11_tail).read_zipper();
      for v163_7_byte in v163_7_cursor.child_mask().iter() {
        v163_7_cursor.descend_to_byte(v163_7_byte);
        let v163_7_tail = v163_7_cursor.make_map();
        v163_7_cursor.ascend(1);
        let v163_7_head = Path::from_slice(&[v163_7_byte]);
        let v164_2: Space = singleton(&(v163_7_head));
        let v164_3: Space = intersect(&(*CONSTANT_1),&(v164_2));
        let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
        drop(v164_3);
        let v164_5: Space = subtract(&(*CONSTANT_0),&(v164_4));
        drop(v164_4);
        let v164_8: Space = if (v164_5).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v163_6),&(v163_7_head));
          let v165_7: Space = routine_28(c, &(v165_6), &(v163_7_tail));
          compose(&(v164_5),&(v165_7))
        };
        drop(v164_5);
        let v164_9: Space = intersect(&(*CONSTANT_1),&(v164_2));
        drop(v164_2);
        let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
        drop(v164_9);
        let v164_12: Space = if (v164_10).is_empty() { Space::new() } else {
          let v166_6: Path = concat_path(&(v163_6),&(v163_7_head));
          let v166_11: Space = routine_29(c, &(v166_6), &(v163_7_tail));
          drop(v166_6);
          compose(&(v164_10),&(v166_11))
        };
        drop(v164_10);
        let v164_13: Space = unite(&(v164_8),&(v164_12));
        v163_7.join_into((v164_13).clone());
      }
      drop(v163_7_cursor);
      compose(&(v162_5),&(v163_7))
    };
    drop(v162_5);
    let v162_9: Space = intersect(&(*CONSTANT_1),&(v162_2));
    drop(v162_2);
    let v162_10: Space = if has_head(&(v162_9)) { singleton(&[]) } else { Space::new() };
    drop(v162_9);
    let v162_12: Space = if (v162_10).is_empty() { Space::new() } else {
      let v167_6: Path = concat_path(&(*p0),&(v161_11_head));
      let mut v167_11 = Space::new();
      let mut v167_11_cursor = (v161_11_tail).read_zipper();
      for v167_11_byte in v167_11_cursor.child_mask().iter() {
        v167_11_cursor.descend_to_byte(v167_11_byte);
        let v167_11_tail = v167_11_cursor.make_map();
        v167_11_cursor.ascend(1);
        let v167_11_head = Path::from_slice(&[v167_11_byte]);
        let v168_2: Space = singleton(&(v167_11_head));
        let v168_3: Space = intersect(&(*CONSTANT_1),&(v168_2));
        let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
        drop(v168_3);
        let v168_5: Space = subtract(&(*CONSTANT_0),&(v168_4));
        drop(v168_4);
        let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
          let v169_6: Path = concat_path(&(v167_6),&(v167_11_head));
          let v169_7: Space = routine_28(c, &(v169_6), &(v167_11_tail));
          compose(&(v168_5),&(v169_7))
        };
        drop(v168_5);
        let v168_9: Space = intersect(&(*CONSTANT_1),&(v168_2));
        drop(v168_2);
        let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
        drop(v168_9);
        let v168_12: Space = if (v168_10).is_empty() { Space::new() } else {
          let v170_6: Path = concat_path(&(v167_6),&(v167_11_head));
          let v170_11: Space = routine_14(c, &(v170_6), &(v167_11_tail));
          drop(v170_6);
          compose(&(v168_10),&(v170_11))
        };
        drop(v168_10);
        let v168_13: Space = unite(&(v168_8),&(v168_12));
        v167_11.join_into((v168_13).clone());
      }
      drop(v167_11_cursor);
      drop(v167_6);
      compose(&(v162_10),&(v167_11))
    };
    drop(v162_10);
    let v162_13: Space = unite(&(v162_8),&(v162_12));
    v161_11.join_into((v162_13).clone());
  }
  drop(v161_11_cursor);
  (v161_11).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v171_8 = Space::new();
  let mut v171_8_cursor = (*s0).read_zipper();
  for v171_8_byte in v171_8_cursor.child_mask().iter() {
    v171_8_cursor.descend_to_byte(v171_8_byte);
    let v171_8_tail = v171_8_cursor.make_map();
    v171_8_cursor.ascend(1);
    let v171_8_head = Path::from_slice(&[v171_8_byte]);
    let v172_2: Space = singleton(&(v171_8_head));
    let v172_3: Space = intersect(&(*CONSTANT_1),&(v172_2));
    let v172_4: Space = if has_head(&(v172_3)) { singleton(&[]) } else { Space::new() };
    drop(v172_3);
    let v172_5: Space = subtract(&(*CONSTANT_0),&(v172_4));
    drop(v172_4);
    let v172_8: Space = if (v172_5).is_empty() { Space::new() } else {
      let v173_6: Path = concat_path(&(*p0),&(v171_8_head));
      let mut v173_7 = Space::new();
      let mut v173_7_cursor = (v171_8_tail).read_zipper();
      for v173_7_byte in v173_7_cursor.child_mask().iter() {
        v173_7_cursor.descend_to_byte(v173_7_byte);
        let v173_7_tail = v173_7_cursor.make_map();
        v173_7_cursor.ascend(1);
        let v173_7_head = Path::from_slice(&[v173_7_byte]);
        let v174_2: Space = singleton(&(v173_7_head));
        let v174_3: Space = intersect(&(*CONSTANT_1),&(v174_2));
        let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
        drop(v174_3);
        let v174_5: Space = subtract(&(*CONSTANT_0),&(v174_4));
        drop(v174_4);
        let v174_8: Space = if (v174_5).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v173_6),&(v173_7_head));
          let v175_7: Space = routine_28(c, &(v175_6), &(v173_7_tail));
          compose(&(v174_5),&(v175_7))
        };
        drop(v174_5);
        let v174_9: Space = intersect(&(*CONSTANT_1),&(v174_2));
        drop(v174_2);
        let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
        drop(v174_9);
        let v174_12: Space = if (v174_10).is_empty() { Space::new() } else {
          let v176_6: Path = concat_path(&(v173_6),&(v173_7_head));
          let v176_11: Space = routine_29(c, &(v176_6), &(v173_7_tail));
          drop(v176_6);
          compose(&(v174_10),&(v176_11))
        };
        drop(v174_10);
        let v174_13: Space = unite(&(v174_8),&(v174_12));
        v173_7.join_into((v174_13).clone());
      }
      drop(v173_7_cursor);
      drop(v173_6);
      compose(&(v172_5),&(v173_7))
    };
    drop(v172_5);
    let v172_9: Space = intersect(&(*CONSTANT_1),&(v172_2));
    drop(v172_2);
    let v172_10: Space = if has_head(&(v172_9)) { singleton(&[]) } else { Space::new() };
    drop(v172_9);
    let v172_11: Space = compose(&(v172_10),&(v171_8_tail));
    drop(v172_10);
    let v172_12: Space = unite(&(v172_8),&(v172_11));
    drop(v172_11);
    v171_8.join_into((v172_12).clone());
  }
  drop(v171_8_cursor);
  (v171_8).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v177_11 = Space::new();
  let mut v177_11_cursor = (*s0).read_zipper();
  for v177_11_byte in v177_11_cursor.child_mask().iter() {
    v177_11_cursor.descend_to_byte(v177_11_byte);
    let v177_11_tail = v177_11_cursor.make_map();
    v177_11_cursor.ascend(1);
    let v177_11_head = Path::from_slice(&[v177_11_byte]);
    let v178_2: Space = singleton(&(v177_11_head));
    let v178_3: Space = intersect(&(*CONSTANT_1),&(v178_2));
    let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
    drop(v178_3);
    let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
    drop(v178_4);
    let v178_8: Space = if (v178_5).is_empty() { Space::new() } else {
      let v179_6: Path = concat_path(&(*p0),&(v177_11_head));
      let mut v179_7 = Space::new();
      let mut v179_7_cursor = (v177_11_tail).read_zipper();
      for v179_7_byte in v179_7_cursor.child_mask().iter() {
        v179_7_cursor.descend_to_byte(v179_7_byte);
        let v179_7_tail = v179_7_cursor.make_map();
        v179_7_cursor.ascend(1);
        let v179_7_head = Path::from_slice(&[v179_7_byte]);
        let v180_2: Space = singleton(&(v179_7_head));
        let v180_3: Space = intersect(&(*CONSTANT_1),&(v180_2));
        let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
        drop(v180_3);
        let v180_5: Space = subtract(&(*CONSTANT_0),&(v180_4));
        drop(v180_4);
        let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v181_7: Space = routine_30(c, &(v181_6), &(v179_7_tail));
          compose(&(v180_5),&(v181_7))
        };
        drop(v180_5);
        let v180_9: Space = intersect(&(*CONSTANT_1),&(v180_2));
        drop(v180_2);
        let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
        drop(v180_9);
        let v180_12: Space = if (v180_10).is_empty() { Space::new() } else {
          let v182_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v182_11: Space = routine_31(c, &(v182_6), &(v179_7_tail));
          drop(v182_6);
          compose(&(v180_10),&(v182_11))
        };
        drop(v180_10);
        let v180_13: Space = unite(&(v180_8),&(v180_12));
        v179_7.join_into((v180_13).clone());
      }
      drop(v179_7_cursor);
      compose(&(v178_5),&(v179_7))
    };
    drop(v178_5);
    let v178_9: Space = intersect(&(*CONSTANT_1),&(v178_2));
    drop(v178_2);
    let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
    drop(v178_9);
    let v178_12: Space = if (v178_10).is_empty() { Space::new() } else {
      let v183_6: Path = concat_path(&(*p0),&(v177_11_head));
      let mut v183_11 = Space::new();
      let mut v183_11_cursor = (v177_11_tail).read_zipper();
      for v183_11_byte in v183_11_cursor.child_mask().iter() {
        v183_11_cursor.descend_to_byte(v183_11_byte);
        let v183_11_tail = v183_11_cursor.make_map();
        v183_11_cursor.ascend(1);
        let v183_11_head = Path::from_slice(&[v183_11_byte]);
        let v184_2: Space = singleton(&(v183_11_head));
        let v184_3: Space = intersect(&(*CONSTANT_1),&(v184_2));
        let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
        drop(v184_3);
        let v184_5: Space = subtract(&(*CONSTANT_0),&(v184_4));
        drop(v184_4);
        let v184_8: Space = if (v184_5).is_empty() { Space::new() } else {
          let v185_6: Path = concat_path(&(v183_6),&(v183_11_head));
          let v185_7: Space = routine_30(c, &(v185_6), &(v183_11_tail));
          compose(&(v184_5),&(v185_7))
        };
        drop(v184_5);
        let v184_9: Space = intersect(&(*CONSTANT_1),&(v184_2));
        drop(v184_2);
        let v184_10: Space = if has_head(&(v184_9)) { singleton(&[]) } else { Space::new() };
        drop(v184_9);
        let v184_12: Space = if (v184_10).is_empty() { Space::new() } else {
          let v186_6: Path = concat_path(&(v183_6),&(v183_11_head));
          let v186_11: Space = routine_17(c, &(v186_6), &(v183_11_tail));
          drop(v186_6);
          compose(&(v184_10),&(v186_11))
        };
        drop(v184_10);
        let v184_13: Space = unite(&(v184_8),&(v184_12));
        v183_11.join_into((v184_13).clone());
      }
      drop(v183_11_cursor);
      drop(v183_6);
      compose(&(v178_10),&(v183_11))
    };
    drop(v178_10);
    let v178_13: Space = unite(&(v178_8),&(v178_12));
    v177_11.join_into((v178_13).clone());
  }
  drop(v177_11_cursor);
  (v177_11).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v187_8 = Space::new();
  let mut v187_8_cursor = (*s0).read_zipper();
  for v187_8_byte in v187_8_cursor.child_mask().iter() {
    v187_8_cursor.descend_to_byte(v187_8_byte);
    let v187_8_tail = v187_8_cursor.make_map();
    v187_8_cursor.ascend(1);
    let v187_8_head = Path::from_slice(&[v187_8_byte]);
    let v188_2: Space = singleton(&(v187_8_head));
    let v188_3: Space = intersect(&(*CONSTANT_1),&(v188_2));
    let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
    drop(v188_3);
    let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
    drop(v188_4);
    let v188_8: Space = if (v188_5).is_empty() { Space::new() } else {
      let v189_6: Path = concat_path(&(*p0),&(v187_8_head));
      let mut v189_7 = Space::new();
      let mut v189_7_cursor = (v187_8_tail).read_zipper();
      for v189_7_byte in v189_7_cursor.child_mask().iter() {
        v189_7_cursor.descend_to_byte(v189_7_byte);
        let v189_7_tail = v189_7_cursor.make_map();
        v189_7_cursor.ascend(1);
        let v189_7_head = Path::from_slice(&[v189_7_byte]);
        let v190_2: Space = singleton(&(v189_7_head));
        let v190_3: Space = intersect(&(*CONSTANT_1),&(v190_2));
        let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
        drop(v190_3);
        let v190_5: Space = subtract(&(*CONSTANT_0),&(v190_4));
        drop(v190_4);
        let v190_8: Space = if (v190_5).is_empty() { Space::new() } else {
          let v191_6: Path = concat_path(&(v189_6),&(v189_7_head));
          let v191_7: Space = routine_30(c, &(v191_6), &(v189_7_tail));
          compose(&(v190_5),&(v191_7))
        };
        drop(v190_5);
        let v190_9: Space = intersect(&(*CONSTANT_1),&(v190_2));
        drop(v190_2);
        let v190_10: Space = if has_head(&(v190_9)) { singleton(&[]) } else { Space::new() };
        drop(v190_9);
        let v190_12: Space = if (v190_10).is_empty() { Space::new() } else {
          let v192_6: Path = concat_path(&(v189_6),&(v189_7_head));
          let v192_11: Space = routine_31(c, &(v192_6), &(v189_7_tail));
          drop(v192_6);
          compose(&(v190_10),&(v192_11))
        };
        drop(v190_10);
        let v190_13: Space = unite(&(v190_8),&(v190_12));
        v189_7.join_into((v190_13).clone());
      }
      drop(v189_7_cursor);
      drop(v189_6);
      compose(&(v188_5),&(v189_7))
    };
    drop(v188_5);
    let v188_9: Space = intersect(&(*CONSTANT_1),&(v188_2));
    drop(v188_2);
    let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
    drop(v188_9);
    let v188_11: Space = compose(&(v188_10),&(v187_8_tail));
    drop(v188_10);
    let v188_12: Space = unite(&(v188_8),&(v188_11));
    drop(v188_11);
    v187_8.join_into((v188_12).clone());
  }
  drop(v187_8_cursor);
  (v187_8).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v193_12 = Space::new();
  let mut v193_12_cursor = (*s0).read_zipper();
  for v193_12_byte in v193_12_cursor.child_mask().iter() {
    v193_12_cursor.descend_to_byte(v193_12_byte);
    let v193_12_tail = v193_12_cursor.make_map();
    v193_12_cursor.ascend(1);
    let v193_12_head = Path::from_slice(&[v193_12_byte]);
    let v194_2: Space = singleton(&(v193_12_head));
    let v194_3: Space = intersect(&(*CONSTANT_1),&(v194_2));
    let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
    drop(v194_3);
    let v194_5: Space = subtract(&(*CONSTANT_0),&(v194_4));
    drop(v194_4);
    let v194_8: Space = if (v194_5).is_empty() { Space::new() } else {
      let v195_6: Path = concat_path(&(*p0),&(v193_12_head));
      let mut v195_7 = Space::new();
      let mut v195_7_cursor = (v193_12_tail).read_zipper();
      for v195_7_byte in v195_7_cursor.child_mask().iter() {
        v195_7_cursor.descend_to_byte(v195_7_byte);
        let v195_7_tail = v195_7_cursor.make_map();
        v195_7_cursor.ascend(1);
        let v195_7_head = Path::from_slice(&[v195_7_byte]);
        let v196_2: Space = singleton(&(v195_7_head));
        let v196_3: Space = intersect(&(*CONSTANT_1),&(v196_2));
        let v196_4: Space = if has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
        drop(v196_3);
        let v196_5: Space = subtract(&(*CONSTANT_0),&(v196_4));
        drop(v196_4);
        let v196_8: Space = if (v196_5).is_empty() { Space::new() } else {
          let v197_6: Path = concat_path(&(v195_6),&(v195_7_head));
          let v197_7: Space = routine_32(c, &(v197_6), &(v195_7_tail), &(*s1));
          compose(&(v196_5),&(v197_7))
        };
        drop(v196_5);
        let v196_9: Space = intersect(&(*CONSTANT_1),&(v196_2));
        drop(v196_2);
        let v196_10: Space = if has_head(&(v196_9)) { singleton(&[]) } else { Space::new() };
        drop(v196_9);
        let v196_12: Space = if (v196_10).is_empty() { Space::new() } else {
          let v198_6: Path = concat_path(&(v195_6),&(v195_7_head));
          let v198_11: Space = routine_33(c, &(v198_6), &(v195_7_tail), &(*s1));
          drop(v198_6);
          compose(&(v196_10),&(v198_11))
        };
        drop(v196_10);
        let v196_13: Space = unite(&(v196_8),&(v196_12));
        v195_7.join_into((v196_13).clone());
      }
      drop(v195_7_cursor);
      compose(&(v194_5),&(v195_7))
    };
    drop(v194_5);
    let v194_9: Space = intersect(&(*CONSTANT_1),&(v194_2));
    drop(v194_2);
    let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
    drop(v194_9);
    let v194_12: Space = if (v194_10).is_empty() { Space::new() } else {
      let v199_6: Path = concat_path(&(*p0),&(v193_12_head));
      let mut v199_11 = Space::new();
      let mut v199_11_cursor = (v193_12_tail).read_zipper();
      for v199_11_byte in v199_11_cursor.child_mask().iter() {
        v199_11_cursor.descend_to_byte(v199_11_byte);
        let v199_11_tail = v199_11_cursor.make_map();
        v199_11_cursor.ascend(1);
        let v199_11_head = Path::from_slice(&[v199_11_byte]);
        let v200_2: Space = singleton(&(v199_11_head));
        let v200_3: Space = intersect(&(*CONSTANT_1),&(v200_2));
        let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
        drop(v200_3);
        let v200_5: Space = subtract(&(*CONSTANT_0),&(v200_4));
        drop(v200_4);
        let v200_8: Space = if (v200_5).is_empty() { Space::new() } else {
          let v201_6: Path = concat_path(&(v199_6),&(v199_11_head));
          let v201_7: Space = routine_32(c, &(v201_6), &(v199_11_tail), &(*s1));
          compose(&(v200_5),&(v201_7))
        };
        drop(v200_5);
        let v200_9: Space = intersect(&(*CONSTANT_1),&(v200_2));
        drop(v200_2);
        let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
        drop(v200_9);
        let v200_12: Space = if (v200_10).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v199_6),&(v199_11_head));
          let v202_11: Space = routine_5(c, &(v202_6), &(v199_11_tail), &(*s1));
          drop(v202_6);
          compose(&(v200_10),&(v202_11))
        };
        drop(v200_10);
        let v200_13: Space = unite(&(v200_8),&(v200_12));
        v199_11.join_into((v200_13).clone());
      }
      drop(v199_11_cursor);
      drop(v199_6);
      compose(&(v194_10),&(v199_11))
    };
    drop(v194_10);
    let v194_13: Space = unite(&(v194_8),&(v194_12));
    v193_12.join_into((v194_13).clone());
  }
  drop(v193_12_cursor);
  (v193_12).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v203_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v203_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v203_10: Space = unwrap(&(v203_9),&(*p0));
  let v203_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v203_22 = Space::new();
  let mut v203_22_cursor = (*s0).read_zipper();
  for v203_22_byte in v203_22_cursor.child_mask().iter() {
    v203_22_cursor.descend_to_byte(v203_22_byte);
    let v203_22_tail = v203_22_cursor.make_map();
    v203_22_cursor.ascend(1);
    let v203_22_head = Path::from_slice(&[v203_22_byte]);
    let v204_2: Space = singleton(&(v203_22_head));
    let v204_3: Space = intersect(&(*CONSTANT_1),&(v204_2));
    let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
    drop(v204_3);
    let v204_5: Space = subtract(&(*CONSTANT_0),&(v204_4));
    drop(v204_4);
    let v204_8: Space = if (v204_5).is_empty() { Space::new() } else {
      let v205_6: Path = concat_path(&(*p0),&(v203_22_head));
      let mut v205_7 = Space::new();
      let mut v205_7_cursor = (v203_22_tail).read_zipper();
      for v205_7_byte in v205_7_cursor.child_mask().iter() {
        v205_7_cursor.descend_to_byte(v205_7_byte);
        let v205_7_tail = v205_7_cursor.make_map();
        v205_7_cursor.ascend(1);
        let v205_7_head = Path::from_slice(&[v205_7_byte]);
        let v206_2: Space = singleton(&(v205_7_head));
        let v206_3: Space = intersect(&(*CONSTANT_1),&(v206_2));
        let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
        drop(v206_3);
        let v206_5: Space = subtract(&(*CONSTANT_0),&(v206_4));
        drop(v206_4);
        let v206_8: Space = if (v206_5).is_empty() { Space::new() } else {
          let v207_6: Path = concat_path(&(v205_6),&(v205_7_head));
          let v207_7: Space = routine_32(c, &(v207_6), &(v205_7_tail), &(*s1));
          compose(&(v206_5),&(v207_7))
        };
        drop(v206_5);
        let v206_9: Space = intersect(&(*CONSTANT_1),&(v206_2));
        drop(v206_2);
        let v206_10: Space = if has_head(&(v206_9)) { singleton(&[]) } else { Space::new() };
        drop(v206_9);
        let v206_12: Space = if (v206_10).is_empty() { Space::new() } else {
          let v208_6: Path = concat_path(&(v205_6),&(v205_7_head));
          let v208_11: Space = routine_33(c, &(v208_6), &(v205_7_tail), &(*s1));
          drop(v208_6);
          compose(&(v206_10),&(v208_11))
        };
        drop(v206_10);
        let v206_13: Space = unite(&(v206_8),&(v206_12));
        v205_7.join_into((v206_13).clone());
      }
      drop(v205_7_cursor);
      compose(&(v204_5),&(v205_7))
    };
    drop(v204_5);
    let v204_9: Space = intersect(&(*CONSTANT_1),&(v204_2));
    drop(v204_2);
    let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
    drop(v204_9);
    let v204_18: Space = if (v204_10).is_empty() { Space::new() } else {
      let v209_11: Space = unwrap(&(v203_10),&(v203_22_head));
      let v209_12: Space = restrict_to(&(v203_9),&(v209_11));
      let mut v209_13 = Space::new();
      let mut v209_13_cursor = (v209_12).read_zipper();
      for v209_13_byte in v209_13_cursor.child_mask().iter() {
        v209_13_cursor.descend_to_byte(v209_13_byte);
        let v209_13_tail = v209_13_cursor.make_map();
        v209_13_cursor.ascend(1);
        let v209_13_head = Path::from_slice(&[v209_13_byte]);
        let v210_2: Space = singleton(&(v209_13_head));
        let v210_3: Space = intersect(&(*CONSTANT_1),&(v210_2));
        let v210_4: Space = if has_head(&(v210_3)) { singleton(&[]) } else { Space::new() };
        drop(v210_3);
        let v210_5: Space = subtract(&(*CONSTANT_0),&(v210_4));
        drop(v210_4);
        let v210_7: Space = if (v210_5).is_empty() { Space::new() } else {
          let v211_6: Space = routine_6(c, &(v209_13_head), &(v209_13_tail));
          compose(&(v210_5),&(v211_6))
        };
        drop(v210_5);
        let v210_8: Space = intersect(&(*CONSTANT_1),&(v210_2));
        drop(v210_2);
        let v210_9: Space = if has_head(&(v210_8)) { singleton(&[]) } else { Space::new() };
        drop(v210_8);
        let v210_11: Space = if (v210_9).is_empty() { Space::new() } else {
          let v212_10: Space = routine_7(c, &(v209_13_head), &(v209_13_tail));
          compose(&(v210_9),&(v212_10))
        };
        drop(v210_9);
        let v210_12: Space = unite(&(v210_7),&(v210_11));
        v209_13.join_into((v210_12).clone());
      }
      drop(v209_13_cursor);
      drop(v209_12);
      let v209_14: Space = restrict_to(&(v203_7),&(v209_13));
      let mut v209_15 = Space::new();
      let mut v209_15_cursor = (v209_14).read_zipper();
      for v209_15_byte in v209_15_cursor.child_mask().iter() {
        v209_15_cursor.descend_to_byte(v209_15_byte);
        let v209_15_tail = v209_15_cursor.make_map();
        v209_15_cursor.ascend(1);
        let v209_15_head = Path::from_slice(&[v209_15_byte]);
        let v213_2: Space = singleton(&(v209_15_head));
        let v213_3: Space = intersect(&(*CONSTANT_1),&(v213_2));
        let v213_4: Space = if has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
        drop(v213_3);
        let v213_5: Space = subtract(&(*CONSTANT_0),&(v213_4));
        drop(v213_4);
        let v213_7: Space = if (v213_5).is_empty() { Space::new() } else {
          let v214_6: Space = routine_8(c, &(v209_15_head), &(v209_15_tail));
          compose(&(v213_5),&(v214_6))
        };
        drop(v213_5);
        let v213_8: Space = intersect(&(*CONSTANT_1),&(v213_2));
        drop(v213_2);
        let v213_9: Space = if has_head(&(v213_8)) { singleton(&[]) } else { Space::new() };
        drop(v213_8);
        let v213_11: Space = if (v213_9).is_empty() { Space::new() } else {
          let v215_10: Space = routine_9(c, &(v209_15_head), &(v209_15_tail));
          compose(&(v213_9),&(v215_10))
        };
        drop(v213_9);
        let v213_12: Space = unite(&(v213_7),&(v213_11));
        v209_15.join_into((v213_12).clone());
      }
      drop(v209_15_cursor);
      let v209_16: Space = subtract(&(v209_15),&(v209_11));
      drop(v209_11);
      let v209_17: Space = intersect(&(v209_16),&(v203_12));
      compose(&(v204_10),&(v209_17))
    };
    drop(v204_10);
    let v216_6: Path = concat_path(&(*p0),&(v203_22_head));
    let v204_19: Space = wrap(&(v204_18),&(v216_6));
    let v204_20: Space = unite(&(v204_8),&(v204_19));
    v203_22.join_into((v204_20).clone());
  }
  drop(v203_22_cursor);
  drop(v203_7);
  drop(v203_9);
  drop(v203_10);
  drop(v203_12);
  (v203_22).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v217_11 = Space::new();
  let mut v217_11_cursor = (*s0).read_zipper();
  for v217_11_byte in v217_11_cursor.child_mask().iter() {
    v217_11_cursor.descend_to_byte(v217_11_byte);
    let v217_11_tail = v217_11_cursor.make_map();
    v217_11_cursor.ascend(1);
    let v217_11_head = Path::from_slice(&[v217_11_byte]);
    let v218_2: Space = singleton(&(v217_11_head));
    let v218_3: Space = intersect(&(*CONSTANT_1),&(v218_2));
    let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
    drop(v218_3);
    let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
    drop(v218_4);
    let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
      let v219_6: Path = concat_path(&(*p0),&(v217_11_head));
      let mut v219_7 = Space::new();
      let mut v219_7_cursor = (v217_11_tail).read_zipper();
      for v219_7_byte in v219_7_cursor.child_mask().iter() {
        v219_7_cursor.descend_to_byte(v219_7_byte);
        let v219_7_tail = v219_7_cursor.make_map();
        v219_7_cursor.ascend(1);
        let v219_7_head = Path::from_slice(&[v219_7_byte]);
        let v220_2: Space = singleton(&(v219_7_head));
        let v220_3: Space = intersect(&(*CONSTANT_1),&(v220_2));
        let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
        drop(v220_3);
        let v220_5: Space = subtract(&(*CONSTANT_0),&(v220_4));
        drop(v220_4);
        let v220_8: Space = if (v220_5).is_empty() { Space::new() } else {
          let v221_6: Path = concat_path(&(v219_6),&(v219_7_head));
          let v221_7: Space = routine_34(c, &(v221_6), &(v219_7_tail));
          compose(&(v220_5),&(v221_7))
        };
        drop(v220_5);
        let v220_9: Space = intersect(&(*CONSTANT_1),&(v220_2));
        drop(v220_2);
        let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
        drop(v220_9);
        let v220_12: Space = if (v220_10).is_empty() { Space::new() } else {
          let v222_6: Path = concat_path(&(v219_6),&(v219_7_head));
          let v222_11: Space = routine_35(c, &(v222_6), &(v219_7_tail));
          drop(v222_6);
          compose(&(v220_10),&(v222_11))
        };
        drop(v220_10);
        let v220_13: Space = unite(&(v220_8),&(v220_12));
        v219_7.join_into((v220_13).clone());
      }
      drop(v219_7_cursor);
      compose(&(v218_5),&(v219_7))
    };
    drop(v218_5);
    let v218_9: Space = intersect(&(*CONSTANT_1),&(v218_2));
    drop(v218_2);
    let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
    drop(v218_9);
    let v218_12: Space = if (v218_10).is_empty() { Space::new() } else {
      let v223_6: Path = concat_path(&(*p0),&(v217_11_head));
      let mut v223_11 = Space::new();
      let mut v223_11_cursor = (v217_11_tail).read_zipper();
      for v223_11_byte in v223_11_cursor.child_mask().iter() {
        v223_11_cursor.descend_to_byte(v223_11_byte);
        let v223_11_tail = v223_11_cursor.make_map();
        v223_11_cursor.ascend(1);
        let v223_11_head = Path::from_slice(&[v223_11_byte]);
        let v224_2: Space = singleton(&(v223_11_head));
        let v224_3: Space = intersect(&(*CONSTANT_1),&(v224_2));
        let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
        drop(v224_3);
        let v224_5: Space = subtract(&(*CONSTANT_0),&(v224_4));
        drop(v224_4);
        let v224_8: Space = if (v224_5).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v223_6),&(v223_11_head));
          let v225_7: Space = routine_34(c, &(v225_6), &(v223_11_tail));
          compose(&(v224_5),&(v225_7))
        };
        drop(v224_5);
        let v224_9: Space = intersect(&(*CONSTANT_1),&(v224_2));
        drop(v224_2);
        let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
        drop(v224_9);
        let v224_12: Space = if (v224_10).is_empty() { Space::new() } else {
          let v226_6: Path = concat_path(&(v223_6),&(v223_11_head));
          let v226_11: Space = routine_14(c, &(v226_6), &(v223_11_tail));
          drop(v226_6);
          compose(&(v224_10),&(v226_11))
        };
        drop(v224_10);
        let v224_13: Space = unite(&(v224_8),&(v224_12));
        v223_11.join_into((v224_13).clone());
      }
      drop(v223_11_cursor);
      drop(v223_6);
      compose(&(v218_10),&(v223_11))
    };
    drop(v218_10);
    let v218_13: Space = unite(&(v218_8),&(v218_12));
    v217_11.join_into((v218_13).clone());
  }
  drop(v217_11_cursor);
  (v217_11).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v227_8 = Space::new();
  let mut v227_8_cursor = (*s0).read_zipper();
  for v227_8_byte in v227_8_cursor.child_mask().iter() {
    v227_8_cursor.descend_to_byte(v227_8_byte);
    let v227_8_tail = v227_8_cursor.make_map();
    v227_8_cursor.ascend(1);
    let v227_8_head = Path::from_slice(&[v227_8_byte]);
    let v228_2: Space = singleton(&(v227_8_head));
    let v228_3: Space = intersect(&(*CONSTANT_1),&(v228_2));
    let v228_4: Space = if has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
    drop(v228_3);
    let v228_5: Space = subtract(&(*CONSTANT_0),&(v228_4));
    drop(v228_4);
    let v228_8: Space = if (v228_5).is_empty() { Space::new() } else {
      let v229_6: Path = concat_path(&(*p0),&(v227_8_head));
      let mut v229_7 = Space::new();
      let mut v229_7_cursor = (v227_8_tail).read_zipper();
      for v229_7_byte in v229_7_cursor.child_mask().iter() {
        v229_7_cursor.descend_to_byte(v229_7_byte);
        let v229_7_tail = v229_7_cursor.make_map();
        v229_7_cursor.ascend(1);
        let v229_7_head = Path::from_slice(&[v229_7_byte]);
        let v230_2: Space = singleton(&(v229_7_head));
        let v230_3: Space = intersect(&(*CONSTANT_1),&(v230_2));
        let v230_4: Space = if has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
        drop(v230_3);
        let v230_5: Space = subtract(&(*CONSTANT_0),&(v230_4));
        drop(v230_4);
        let v230_8: Space = if (v230_5).is_empty() { Space::new() } else {
          let v231_6: Path = concat_path(&(v229_6),&(v229_7_head));
          let v231_7: Space = routine_34(c, &(v231_6), &(v229_7_tail));
          compose(&(v230_5),&(v231_7))
        };
        drop(v230_5);
        let v230_9: Space = intersect(&(*CONSTANT_1),&(v230_2));
        drop(v230_2);
        let v230_10: Space = if has_head(&(v230_9)) { singleton(&[]) } else { Space::new() };
        drop(v230_9);
        let v230_12: Space = if (v230_10).is_empty() { Space::new() } else {
          let v232_6: Path = concat_path(&(v229_6),&(v229_7_head));
          let v232_11: Space = routine_35(c, &(v232_6), &(v229_7_tail));
          drop(v232_6);
          compose(&(v230_10),&(v232_11))
        };
        drop(v230_10);
        let v230_13: Space = unite(&(v230_8),&(v230_12));
        v229_7.join_into((v230_13).clone());
      }
      drop(v229_7_cursor);
      drop(v229_6);
      compose(&(v228_5),&(v229_7))
    };
    drop(v228_5);
    let v228_9: Space = intersect(&(*CONSTANT_1),&(v228_2));
    drop(v228_2);
    let v228_10: Space = if has_head(&(v228_9)) { singleton(&[]) } else { Space::new() };
    drop(v228_9);
    let v228_11: Space = compose(&(v228_10),&(v227_8_tail));
    drop(v228_10);
    let v228_12: Space = unite(&(v228_8),&(v228_11));
    drop(v228_11);
    v227_8.join_into((v228_12).clone());
  }
  drop(v227_8_cursor);
  (v227_8).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v233_11 = Space::new();
  let mut v233_11_cursor = (*s0).read_zipper();
  for v233_11_byte in v233_11_cursor.child_mask().iter() {
    v233_11_cursor.descend_to_byte(v233_11_byte);
    let v233_11_tail = v233_11_cursor.make_map();
    v233_11_cursor.ascend(1);
    let v233_11_head = Path::from_slice(&[v233_11_byte]);
    let v234_2: Space = singleton(&(v233_11_head));
    let v234_3: Space = intersect(&(*CONSTANT_1),&(v234_2));
    let v234_4: Space = if has_head(&(v234_3)) { singleton(&[]) } else { Space::new() };
    drop(v234_3);
    let v234_5: Space = subtract(&(*CONSTANT_0),&(v234_4));
    drop(v234_4);
    let v234_8: Space = if (v234_5).is_empty() { Space::new() } else {
      let v235_6: Path = concat_path(&(*p0),&(v233_11_head));
      let mut v235_7 = Space::new();
      let mut v235_7_cursor = (v233_11_tail).read_zipper();
      for v235_7_byte in v235_7_cursor.child_mask().iter() {
        v235_7_cursor.descend_to_byte(v235_7_byte);
        let v235_7_tail = v235_7_cursor.make_map();
        v235_7_cursor.ascend(1);
        let v235_7_head = Path::from_slice(&[v235_7_byte]);
        let v236_2: Space = singleton(&(v235_7_head));
        let v236_3: Space = intersect(&(*CONSTANT_1),&(v236_2));
        let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
        drop(v236_3);
        let v236_5: Space = subtract(&(*CONSTANT_0),&(v236_4));
        drop(v236_4);
        let v236_8: Space = if (v236_5).is_empty() { Space::new() } else {
          let v237_6: Path = concat_path(&(v235_6),&(v235_7_head));
          let v237_7: Space = routine_36(c, &(v237_6), &(v235_7_tail));
          compose(&(v236_5),&(v237_7))
        };
        drop(v236_5);
        let v236_9: Space = intersect(&(*CONSTANT_1),&(v236_2));
        drop(v236_2);
        let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
        drop(v236_9);
        let v236_12: Space = if (v236_10).is_empty() { Space::new() } else {
          let v238_6: Path = concat_path(&(v235_6),&(v235_7_head));
          let v238_11: Space = routine_37(c, &(v238_6), &(v235_7_tail));
          drop(v238_6);
          compose(&(v236_10),&(v238_11))
        };
        drop(v236_10);
        let v236_13: Space = unite(&(v236_8),&(v236_12));
        v235_7.join_into((v236_13).clone());
      }
      drop(v235_7_cursor);
      compose(&(v234_5),&(v235_7))
    };
    drop(v234_5);
    let v234_9: Space = intersect(&(*CONSTANT_1),&(v234_2));
    drop(v234_2);
    let v234_10: Space = if has_head(&(v234_9)) { singleton(&[]) } else { Space::new() };
    drop(v234_9);
    let v234_12: Space = if (v234_10).is_empty() { Space::new() } else {
      let v239_6: Path = concat_path(&(*p0),&(v233_11_head));
      let mut v239_11 = Space::new();
      let mut v239_11_cursor = (v233_11_tail).read_zipper();
      for v239_11_byte in v239_11_cursor.child_mask().iter() {
        v239_11_cursor.descend_to_byte(v239_11_byte);
        let v239_11_tail = v239_11_cursor.make_map();
        v239_11_cursor.ascend(1);
        let v239_11_head = Path::from_slice(&[v239_11_byte]);
        let v240_2: Space = singleton(&(v239_11_head));
        let v240_3: Space = intersect(&(*CONSTANT_1),&(v240_2));
        let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
        drop(v240_3);
        let v240_5: Space = subtract(&(*CONSTANT_0),&(v240_4));
        drop(v240_4);
        let v240_8: Space = if (v240_5).is_empty() { Space::new() } else {
          let v241_6: Path = concat_path(&(v239_6),&(v239_11_head));
          let v241_7: Space = routine_36(c, &(v241_6), &(v239_11_tail));
          compose(&(v240_5),&(v241_7))
        };
        drop(v240_5);
        let v240_9: Space = intersect(&(*CONSTANT_1),&(v240_2));
        drop(v240_2);
        let v240_10: Space = if has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
        drop(v240_9);
        let v240_12: Space = if (v240_10).is_empty() { Space::new() } else {
          let v242_6: Path = concat_path(&(v239_6),&(v239_11_head));
          let v242_11: Space = routine_17(c, &(v242_6), &(v239_11_tail));
          drop(v242_6);
          compose(&(v240_10),&(v242_11))
        };
        drop(v240_10);
        let v240_13: Space = unite(&(v240_8),&(v240_12));
        v239_11.join_into((v240_13).clone());
      }
      drop(v239_11_cursor);
      drop(v239_6);
      compose(&(v234_10),&(v239_11))
    };
    drop(v234_10);
    let v234_13: Space = unite(&(v234_8),&(v234_12));
    v233_11.join_into((v234_13).clone());
  }
  drop(v233_11_cursor);
  (v233_11).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v243_8 = Space::new();
  let mut v243_8_cursor = (*s0).read_zipper();
  for v243_8_byte in v243_8_cursor.child_mask().iter() {
    v243_8_cursor.descend_to_byte(v243_8_byte);
    let v243_8_tail = v243_8_cursor.make_map();
    v243_8_cursor.ascend(1);
    let v243_8_head = Path::from_slice(&[v243_8_byte]);
    let v244_2: Space = singleton(&(v243_8_head));
    let v244_3: Space = intersect(&(*CONSTANT_1),&(v244_2));
    let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
    drop(v244_3);
    let v244_5: Space = subtract(&(*CONSTANT_0),&(v244_4));
    drop(v244_4);
    let v244_8: Space = if (v244_5).is_empty() { Space::new() } else {
      let v245_6: Path = concat_path(&(*p0),&(v243_8_head));
      let mut v245_7 = Space::new();
      let mut v245_7_cursor = (v243_8_tail).read_zipper();
      for v245_7_byte in v245_7_cursor.child_mask().iter() {
        v245_7_cursor.descend_to_byte(v245_7_byte);
        let v245_7_tail = v245_7_cursor.make_map();
        v245_7_cursor.ascend(1);
        let v245_7_head = Path::from_slice(&[v245_7_byte]);
        let v246_2: Space = singleton(&(v245_7_head));
        let v246_3: Space = intersect(&(*CONSTANT_1),&(v246_2));
        let v246_4: Space = if has_head(&(v246_3)) { singleton(&[]) } else { Space::new() };
        drop(v246_3);
        let v246_5: Space = subtract(&(*CONSTANT_0),&(v246_4));
        drop(v246_4);
        let v246_8: Space = if (v246_5).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v245_6),&(v245_7_head));
          let v247_7: Space = routine_36(c, &(v247_6), &(v245_7_tail));
          compose(&(v246_5),&(v247_7))
        };
        drop(v246_5);
        let v246_9: Space = intersect(&(*CONSTANT_1),&(v246_2));
        drop(v246_2);
        let v246_10: Space = if has_head(&(v246_9)) { singleton(&[]) } else { Space::new() };
        drop(v246_9);
        let v246_12: Space = if (v246_10).is_empty() { Space::new() } else {
          let v248_6: Path = concat_path(&(v245_6),&(v245_7_head));
          let v248_11: Space = routine_37(c, &(v248_6), &(v245_7_tail));
          drop(v248_6);
          compose(&(v246_10),&(v248_11))
        };
        drop(v246_10);
        let v246_13: Space = unite(&(v246_8),&(v246_12));
        v245_7.join_into((v246_13).clone());
      }
      drop(v245_7_cursor);
      drop(v245_6);
      compose(&(v244_5),&(v245_7))
    };
    drop(v244_5);
    let v244_9: Space = intersect(&(*CONSTANT_1),&(v244_2));
    drop(v244_2);
    let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
    drop(v244_9);
    let v244_11: Space = compose(&(v244_10),&(v243_8_tail));
    drop(v244_10);
    let v244_12: Space = unite(&(v244_8),&(v244_11));
    drop(v244_11);
    v243_8.join_into((v244_12).clone());
  }
  drop(v243_8_cursor);
  (v243_8).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v249_11 = Space::new();
  let mut v249_11_cursor = (*s0).read_zipper();
  for v249_11_byte in v249_11_cursor.child_mask().iter() {
    v249_11_cursor.descend_to_byte(v249_11_byte);
    let v249_11_tail = v249_11_cursor.make_map();
    v249_11_cursor.ascend(1);
    let v249_11_head = Path::from_slice(&[v249_11_byte]);
    let v250_2: Space = singleton(&(v249_11_head));
    let v250_3: Space = intersect(&(*CONSTANT_1),&(v250_2));
    let v250_4: Space = if has_head(&(v250_3)) { singleton(&[]) } else { Space::new() };
    drop(v250_3);
    let v250_5: Space = subtract(&(*CONSTANT_0),&(v250_4));
    drop(v250_4);
    let v250_8: Space = if (v250_5).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&(v249_11_head));
      let mut v251_7 = Space::new();
      let mut v251_7_cursor = (v249_11_tail).read_zipper();
      for v251_7_byte in v251_7_cursor.child_mask().iter() {
        v251_7_cursor.descend_to_byte(v251_7_byte);
        let v251_7_tail = v251_7_cursor.make_map();
        v251_7_cursor.ascend(1);
        let v251_7_head = Path::from_slice(&[v251_7_byte]);
        let v252_2: Space = singleton(&(v251_7_head));
        let v252_3: Space = intersect(&(*CONSTANT_1),&(v252_2));
        let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = subtract(&(*CONSTANT_0),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (v252_5).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&(v251_7_head));
          let v253_7: Space = routine_38(c, &(v253_6), &(v251_7_tail));
          compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = intersect(&(*CONSTANT_1),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_12: Space = if (v252_10).is_empty() { Space::new() } else {
          let v254_6: Path = concat_path(&(v251_6),&(v251_7_head));
          let v254_11: Space = routine_39(c, &(v254_6), &(v251_7_tail));
          drop(v254_6);
          compose(&(v252_10),&(v254_11))
        };
        drop(v252_10);
        let v252_13: Space = unite(&(v252_8),&(v252_12));
        v251_7.join_into((v252_13).clone());
      }
      drop(v251_7_cursor);
      compose(&(v250_5),&(v251_7))
    };
    drop(v250_5);
    let v250_9: Space = intersect(&(*CONSTANT_1),&(v250_2));
    drop(v250_2);
    let v250_10: Space = if has_head(&(v250_9)) { singleton(&[]) } else { Space::new() };
    drop(v250_9);
    let v250_12: Space = if (v250_10).is_empty() { Space::new() } else {
      let v255_6: Path = concat_path(&(*p0),&(v249_11_head));
      let mut v255_11 = Space::new();
      let mut v255_11_cursor = (v249_11_tail).read_zipper();
      for v255_11_byte in v255_11_cursor.child_mask().iter() {
        v255_11_cursor.descend_to_byte(v255_11_byte);
        let v255_11_tail = v255_11_cursor.make_map();
        v255_11_cursor.ascend(1);
        let v255_11_head = Path::from_slice(&[v255_11_byte]);
        let v256_2: Space = singleton(&(v255_11_head));
        let v256_3: Space = intersect(&(*CONSTANT_1),&(v256_2));
        let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
        drop(v256_3);
        let v256_5: Space = subtract(&(*CONSTANT_0),&(v256_4));
        drop(v256_4);
        let v256_8: Space = if (v256_5).is_empty() { Space::new() } else {
          let v257_6: Path = concat_path(&(v255_6),&(v255_11_head));
          let v257_7: Space = routine_38(c, &(v257_6), &(v255_11_tail));
          compose(&(v256_5),&(v257_7))
        };
        drop(v256_5);
        let v256_9: Space = intersect(&(*CONSTANT_1),&(v256_2));
        drop(v256_2);
        let v256_10: Space = if has_head(&(v256_9)) { singleton(&[]) } else { Space::new() };
        drop(v256_9);
        let v256_12: Space = if (v256_10).is_empty() { Space::new() } else {
          let v258_6: Path = concat_path(&(v255_6),&(v255_11_head));
          let v258_11: Space = routine_14(c, &(v258_6), &(v255_11_tail));
          drop(v258_6);
          compose(&(v256_10),&(v258_11))
        };
        drop(v256_10);
        let v256_13: Space = unite(&(v256_8),&(v256_12));
        v255_11.join_into((v256_13).clone());
      }
      drop(v255_11_cursor);
      drop(v255_6);
      compose(&(v250_10),&(v255_11))
    };
    drop(v250_10);
    let v250_13: Space = unite(&(v250_8),&(v250_12));
    v249_11.join_into((v250_13).clone());
  }
  drop(v249_11_cursor);
  (v249_11).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v259_8 = Space::new();
  let mut v259_8_cursor = (*s0).read_zipper();
  for v259_8_byte in v259_8_cursor.child_mask().iter() {
    v259_8_cursor.descend_to_byte(v259_8_byte);
    let v259_8_tail = v259_8_cursor.make_map();
    v259_8_cursor.ascend(1);
    let v259_8_head = Path::from_slice(&[v259_8_byte]);
    let v260_2: Space = singleton(&(v259_8_head));
    let v260_3: Space = intersect(&(*CONSTANT_1),&(v260_2));
    let v260_4: Space = if has_head(&(v260_3)) { singleton(&[]) } else { Space::new() };
    drop(v260_3);
    let v260_5: Space = subtract(&(*CONSTANT_0),&(v260_4));
    drop(v260_4);
    let v260_8: Space = if (v260_5).is_empty() { Space::new() } else {
      let v261_6: Path = concat_path(&(*p0),&(v259_8_head));
      let mut v261_7 = Space::new();
      let mut v261_7_cursor = (v259_8_tail).read_zipper();
      for v261_7_byte in v261_7_cursor.child_mask().iter() {
        v261_7_cursor.descend_to_byte(v261_7_byte);
        let v261_7_tail = v261_7_cursor.make_map();
        v261_7_cursor.ascend(1);
        let v261_7_head = Path::from_slice(&[v261_7_byte]);
        let v262_2: Space = singleton(&(v261_7_head));
        let v262_3: Space = intersect(&(*CONSTANT_1),&(v262_2));
        let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
        drop(v262_3);
        let v262_5: Space = subtract(&(*CONSTANT_0),&(v262_4));
        drop(v262_4);
        let v262_8: Space = if (v262_5).is_empty() { Space::new() } else {
          let v263_6: Path = concat_path(&(v261_6),&(v261_7_head));
          let v263_7: Space = routine_38(c, &(v263_6), &(v261_7_tail));
          compose(&(v262_5),&(v263_7))
        };
        drop(v262_5);
        let v262_9: Space = intersect(&(*CONSTANT_1),&(v262_2));
        drop(v262_2);
        let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
        drop(v262_9);
        let v262_12: Space = if (v262_10).is_empty() { Space::new() } else {
          let v264_6: Path = concat_path(&(v261_6),&(v261_7_head));
          let v264_11: Space = routine_39(c, &(v264_6), &(v261_7_tail));
          drop(v264_6);
          compose(&(v262_10),&(v264_11))
        };
        drop(v262_10);
        let v262_13: Space = unite(&(v262_8),&(v262_12));
        v261_7.join_into((v262_13).clone());
      }
      drop(v261_7_cursor);
      drop(v261_6);
      compose(&(v260_5),&(v261_7))
    };
    drop(v260_5);
    let v260_9: Space = intersect(&(*CONSTANT_1),&(v260_2));
    drop(v260_2);
    let v260_10: Space = if has_head(&(v260_9)) { singleton(&[]) } else { Space::new() };
    drop(v260_9);
    let v260_11: Space = compose(&(v260_10),&(v259_8_tail));
    drop(v260_10);
    let v260_12: Space = unite(&(v260_8),&(v260_11));
    drop(v260_11);
    v259_8.join_into((v260_12).clone());
  }
  drop(v259_8_cursor);
  (v259_8).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v265_11 = Space::new();
  let mut v265_11_cursor = (*s0).read_zipper();
  for v265_11_byte in v265_11_cursor.child_mask().iter() {
    v265_11_cursor.descend_to_byte(v265_11_byte);
    let v265_11_tail = v265_11_cursor.make_map();
    v265_11_cursor.ascend(1);
    let v265_11_head = Path::from_slice(&[v265_11_byte]);
    let v266_2: Space = singleton(&(v265_11_head));
    let v266_3: Space = intersect(&(*CONSTANT_1),&(v266_2));
    let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
    drop(v266_3);
    let v266_5: Space = subtract(&(*CONSTANT_0),&(v266_4));
    drop(v266_4);
    let v266_8: Space = if (v266_5).is_empty() { Space::new() } else {
      let v267_6: Path = concat_path(&(*p0),&(v265_11_head));
      let mut v267_7 = Space::new();
      let mut v267_7_cursor = (v265_11_tail).read_zipper();
      for v267_7_byte in v267_7_cursor.child_mask().iter() {
        v267_7_cursor.descend_to_byte(v267_7_byte);
        let v267_7_tail = v267_7_cursor.make_map();
        v267_7_cursor.ascend(1);
        let v267_7_head = Path::from_slice(&[v267_7_byte]);
        let v268_2: Space = singleton(&(v267_7_head));
        let v268_3: Space = intersect(&(*CONSTANT_1),&(v268_2));
        let v268_4: Space = if has_head(&(v268_3)) { singleton(&[]) } else { Space::new() };
        drop(v268_3);
        let v268_5: Space = subtract(&(*CONSTANT_0),&(v268_4));
        drop(v268_4);
        let v268_8: Space = if (v268_5).is_empty() { Space::new() } else {
          let v269_6: Path = concat_path(&(v267_6),&(v267_7_head));
          let v269_7: Space = routine_40(c, &(v269_6), &(v267_7_tail));
          compose(&(v268_5),&(v269_7))
        };
        drop(v268_5);
        let v268_9: Space = intersect(&(*CONSTANT_1),&(v268_2));
        drop(v268_2);
        let v268_10: Space = if has_head(&(v268_9)) { singleton(&[]) } else { Space::new() };
        drop(v268_9);
        let v268_12: Space = if (v268_10).is_empty() { Space::new() } else {
          let v270_6: Path = concat_path(&(v267_6),&(v267_7_head));
          let v270_11: Space = routine_41(c, &(v270_6), &(v267_7_tail));
          drop(v270_6);
          compose(&(v268_10),&(v270_11))
        };
        drop(v268_10);
        let v268_13: Space = unite(&(v268_8),&(v268_12));
        v267_7.join_into((v268_13).clone());
      }
      drop(v267_7_cursor);
      compose(&(v266_5),&(v267_7))
    };
    drop(v266_5);
    let v266_9: Space = intersect(&(*CONSTANT_1),&(v266_2));
    drop(v266_2);
    let v266_10: Space = if has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
    drop(v266_9);
    let v266_12: Space = if (v266_10).is_empty() { Space::new() } else {
      let v271_6: Path = concat_path(&(*p0),&(v265_11_head));
      let mut v271_11 = Space::new();
      let mut v271_11_cursor = (v265_11_tail).read_zipper();
      for v271_11_byte in v271_11_cursor.child_mask().iter() {
        v271_11_cursor.descend_to_byte(v271_11_byte);
        let v271_11_tail = v271_11_cursor.make_map();
        v271_11_cursor.ascend(1);
        let v271_11_head = Path::from_slice(&[v271_11_byte]);
        let v272_2: Space = singleton(&(v271_11_head));
        let v272_3: Space = intersect(&(*CONSTANT_1),&(v272_2));
        let v272_4: Space = if has_head(&(v272_3)) { singleton(&[]) } else { Space::new() };
        drop(v272_3);
        let v272_5: Space = subtract(&(*CONSTANT_0),&(v272_4));
        drop(v272_4);
        let v272_8: Space = if (v272_5).is_empty() { Space::new() } else {
          let v273_6: Path = concat_path(&(v271_6),&(v271_11_head));
          let v273_7: Space = routine_40(c, &(v273_6), &(v271_11_tail));
          compose(&(v272_5),&(v273_7))
        };
        drop(v272_5);
        let v272_9: Space = intersect(&(*CONSTANT_1),&(v272_2));
        drop(v272_2);
        let v272_10: Space = if has_head(&(v272_9)) { singleton(&[]) } else { Space::new() };
        drop(v272_9);
        let v272_12: Space = if (v272_10).is_empty() { Space::new() } else {
          let v274_6: Path = concat_path(&(v271_6),&(v271_11_head));
          let v274_11: Space = routine_17(c, &(v274_6), &(v271_11_tail));
          drop(v274_6);
          compose(&(v272_10),&(v274_11))
        };
        drop(v272_10);
        let v272_13: Space = unite(&(v272_8),&(v272_12));
        v271_11.join_into((v272_13).clone());
      }
      drop(v271_11_cursor);
      drop(v271_6);
      compose(&(v266_10),&(v271_11))
    };
    drop(v266_10);
    let v266_13: Space = unite(&(v266_8),&(v266_12));
    v265_11.join_into((v266_13).clone());
  }
  drop(v265_11_cursor);
  (v265_11).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v275_8 = Space::new();
  let mut v275_8_cursor = (*s0).read_zipper();
  for v275_8_byte in v275_8_cursor.child_mask().iter() {
    v275_8_cursor.descend_to_byte(v275_8_byte);
    let v275_8_tail = v275_8_cursor.make_map();
    v275_8_cursor.ascend(1);
    let v275_8_head = Path::from_slice(&[v275_8_byte]);
    let v276_2: Space = singleton(&(v275_8_head));
    let v276_3: Space = intersect(&(*CONSTANT_1),&(v276_2));
    let v276_4: Space = if has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
    drop(v276_3);
    let v276_5: Space = subtract(&(*CONSTANT_0),&(v276_4));
    drop(v276_4);
    let v276_8: Space = if (v276_5).is_empty() { Space::new() } else {
      let v277_6: Path = concat_path(&(*p0),&(v275_8_head));
      let mut v277_7 = Space::new();
      let mut v277_7_cursor = (v275_8_tail).read_zipper();
      for v277_7_byte in v277_7_cursor.child_mask().iter() {
        v277_7_cursor.descend_to_byte(v277_7_byte);
        let v277_7_tail = v277_7_cursor.make_map();
        v277_7_cursor.ascend(1);
        let v277_7_head = Path::from_slice(&[v277_7_byte]);
        let v278_2: Space = singleton(&(v277_7_head));
        let v278_3: Space = intersect(&(*CONSTANT_1),&(v278_2));
        let v278_4: Space = if has_head(&(v278_3)) { singleton(&[]) } else { Space::new() };
        drop(v278_3);
        let v278_5: Space = subtract(&(*CONSTANT_0),&(v278_4));
        drop(v278_4);
        let v278_8: Space = if (v278_5).is_empty() { Space::new() } else {
          let v279_6: Path = concat_path(&(v277_6),&(v277_7_head));
          let v279_7: Space = routine_40(c, &(v279_6), &(v277_7_tail));
          compose(&(v278_5),&(v279_7))
        };
        drop(v278_5);
        let v278_9: Space = intersect(&(*CONSTANT_1),&(v278_2));
        drop(v278_2);
        let v278_10: Space = if has_head(&(v278_9)) { singleton(&[]) } else { Space::new() };
        drop(v278_9);
        let v278_12: Space = if (v278_10).is_empty() { Space::new() } else {
          let v280_6: Path = concat_path(&(v277_6),&(v277_7_head));
          let v280_11: Space = routine_41(c, &(v280_6), &(v277_7_tail));
          drop(v280_6);
          compose(&(v278_10),&(v280_11))
        };
        drop(v278_10);
        let v278_13: Space = unite(&(v278_8),&(v278_12));
        v277_7.join_into((v278_13).clone());
      }
      drop(v277_7_cursor);
      drop(v277_6);
      compose(&(v276_5),&(v277_7))
    };
    drop(v276_5);
    let v276_9: Space = intersect(&(*CONSTANT_1),&(v276_2));
    drop(v276_2);
    let v276_10: Space = if has_head(&(v276_9)) { singleton(&[]) } else { Space::new() };
    drop(v276_9);
    let v276_11: Space = compose(&(v276_10),&(v275_8_tail));
    drop(v276_10);
    let v276_12: Space = unite(&(v276_8),&(v276_11));
    drop(v276_11);
    v275_8.join_into((v276_12).clone());
  }
  drop(v275_8_cursor);
  (v275_8).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v281_12 = Space::new();
  let mut v281_12_cursor = (*s0).read_zipper();
  for v281_12_byte in v281_12_cursor.child_mask().iter() {
    v281_12_cursor.descend_to_byte(v281_12_byte);
    let v281_12_tail = v281_12_cursor.make_map();
    v281_12_cursor.ascend(1);
    let v281_12_head = Path::from_slice(&[v281_12_byte]);
    let v282_2: Space = singleton(&(v281_12_head));
    let v282_3: Space = intersect(&(*CONSTANT_1),&(v282_2));
    let v282_4: Space = if has_head(&(v282_3)) { singleton(&[]) } else { Space::new() };
    drop(v282_3);
    let v282_5: Space = subtract(&(*CONSTANT_0),&(v282_4));
    drop(v282_4);
    let v282_8: Space = if (v282_5).is_empty() { Space::new() } else {
      let v283_6: Path = concat_path(&(*p0),&(v281_12_head));
      let mut v283_7 = Space::new();
      let mut v283_7_cursor = (v281_12_tail).read_zipper();
      for v283_7_byte in v283_7_cursor.child_mask().iter() {
        v283_7_cursor.descend_to_byte(v283_7_byte);
        let v283_7_tail = v283_7_cursor.make_map();
        v283_7_cursor.ascend(1);
        let v283_7_head = Path::from_slice(&[v283_7_byte]);
        let v284_2: Space = singleton(&(v283_7_head));
        let v284_3: Space = intersect(&(*CONSTANT_1),&(v284_2));
        let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
        drop(v284_3);
        let v284_5: Space = subtract(&(*CONSTANT_0),&(v284_4));
        drop(v284_4);
        let v284_8: Space = if (v284_5).is_empty() { Space::new() } else {
          let v285_6: Path = concat_path(&(v283_6),&(v283_7_head));
          let v285_7: Space = routine_42(c, &(v285_6), &(v283_7_tail), &(*s1));
          compose(&(v284_5),&(v285_7))
        };
        drop(v284_5);
        let v284_9: Space = intersect(&(*CONSTANT_1),&(v284_2));
        drop(v284_2);
        let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
        drop(v284_9);
        let v284_12: Space = if (v284_10).is_empty() { Space::new() } else {
          let v286_6: Path = concat_path(&(v283_6),&(v283_7_head));
          let v286_11: Space = routine_43(c, &(v286_6), &(v283_7_tail), &(*s1));
          drop(v286_6);
          compose(&(v284_10),&(v286_11))
        };
        drop(v284_10);
        let v284_13: Space = unite(&(v284_8),&(v284_12));
        v283_7.join_into((v284_13).clone());
      }
      drop(v283_7_cursor);
      compose(&(v282_5),&(v283_7))
    };
    drop(v282_5);
    let v282_9: Space = intersect(&(*CONSTANT_1),&(v282_2));
    drop(v282_2);
    let v282_10: Space = if has_head(&(v282_9)) { singleton(&[]) } else { Space::new() };
    drop(v282_9);
    let v282_12: Space = if (v282_10).is_empty() { Space::new() } else {
      let v287_6: Path = concat_path(&(*p0),&(v281_12_head));
      let mut v287_11 = Space::new();
      let mut v287_11_cursor = (v281_12_tail).read_zipper();
      for v287_11_byte in v287_11_cursor.child_mask().iter() {
        v287_11_cursor.descend_to_byte(v287_11_byte);
        let v287_11_tail = v287_11_cursor.make_map();
        v287_11_cursor.ascend(1);
        let v287_11_head = Path::from_slice(&[v287_11_byte]);
        let v288_2: Space = singleton(&(v287_11_head));
        let v288_3: Space = intersect(&(*CONSTANT_1),&(v288_2));
        let v288_4: Space = if has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
        drop(v288_3);
        let v288_5: Space = subtract(&(*CONSTANT_0),&(v288_4));
        drop(v288_4);
        let v288_8: Space = if (v288_5).is_empty() { Space::new() } else {
          let v289_6: Path = concat_path(&(v287_6),&(v287_11_head));
          let v289_7: Space = routine_42(c, &(v289_6), &(v287_11_tail), &(*s1));
          compose(&(v288_5),&(v289_7))
        };
        drop(v288_5);
        let v288_9: Space = intersect(&(*CONSTANT_1),&(v288_2));
        drop(v288_2);
        let v288_10: Space = if has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
        drop(v288_9);
        let v288_12: Space = if (v288_10).is_empty() { Space::new() } else {
          let v290_6: Path = concat_path(&(v287_6),&(v287_11_head));
          let v290_11: Space = routine_5(c, &(v290_6), &(v287_11_tail), &(*s1));
          drop(v290_6);
          compose(&(v288_10),&(v290_11))
        };
        drop(v288_10);
        let v288_13: Space = unite(&(v288_8),&(v288_12));
        v287_11.join_into((v288_13).clone());
      }
      drop(v287_11_cursor);
      drop(v287_6);
      compose(&(v282_10),&(v287_11))
    };
    drop(v282_10);
    let v282_13: Space = unite(&(v282_8),&(v282_12));
    v281_12.join_into((v282_13).clone());
  }
  drop(v281_12_cursor);
  (v281_12).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v291_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v291_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v291_10: Space = unwrap(&(v291_9),&(*p0));
  let v291_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v291_22 = Space::new();
  let mut v291_22_cursor = (*s0).read_zipper();
  for v291_22_byte in v291_22_cursor.child_mask().iter() {
    v291_22_cursor.descend_to_byte(v291_22_byte);
    let v291_22_tail = v291_22_cursor.make_map();
    v291_22_cursor.ascend(1);
    let v291_22_head = Path::from_slice(&[v291_22_byte]);
    let v292_2: Space = singleton(&(v291_22_head));
    let v292_3: Space = intersect(&(*CONSTANT_1),&(v292_2));
    let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
    drop(v292_3);
    let v292_5: Space = subtract(&(*CONSTANT_0),&(v292_4));
    drop(v292_4);
    let v292_8: Space = if (v292_5).is_empty() { Space::new() } else {
      let v293_6: Path = concat_path(&(*p0),&(v291_22_head));
      let mut v293_7 = Space::new();
      let mut v293_7_cursor = (v291_22_tail).read_zipper();
      for v293_7_byte in v293_7_cursor.child_mask().iter() {
        v293_7_cursor.descend_to_byte(v293_7_byte);
        let v293_7_tail = v293_7_cursor.make_map();
        v293_7_cursor.ascend(1);
        let v293_7_head = Path::from_slice(&[v293_7_byte]);
        let v294_2: Space = singleton(&(v293_7_head));
        let v294_3: Space = intersect(&(*CONSTANT_1),&(v294_2));
        let v294_4: Space = if has_head(&(v294_3)) { singleton(&[]) } else { Space::new() };
        drop(v294_3);
        let v294_5: Space = subtract(&(*CONSTANT_0),&(v294_4));
        drop(v294_4);
        let v294_8: Space = if (v294_5).is_empty() { Space::new() } else {
          let v295_6: Path = concat_path(&(v293_6),&(v293_7_head));
          let v295_7: Space = routine_42(c, &(v295_6), &(v293_7_tail), &(*s1));
          compose(&(v294_5),&(v295_7))
        };
        drop(v294_5);
        let v294_9: Space = intersect(&(*CONSTANT_1),&(v294_2));
        drop(v294_2);
        let v294_10: Space = if has_head(&(v294_9)) { singleton(&[]) } else { Space::new() };
        drop(v294_9);
        let v294_12: Space = if (v294_10).is_empty() { Space::new() } else {
          let v296_6: Path = concat_path(&(v293_6),&(v293_7_head));
          let v296_11: Space = routine_43(c, &(v296_6), &(v293_7_tail), &(*s1));
          drop(v296_6);
          compose(&(v294_10),&(v296_11))
        };
        drop(v294_10);
        let v294_13: Space = unite(&(v294_8),&(v294_12));
        v293_7.join_into((v294_13).clone());
      }
      drop(v293_7_cursor);
      compose(&(v292_5),&(v293_7))
    };
    drop(v292_5);
    let v292_9: Space = intersect(&(*CONSTANT_1),&(v292_2));
    drop(v292_2);
    let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
    drop(v292_9);
    let v292_18: Space = if (v292_10).is_empty() { Space::new() } else {
      let v297_11: Space = unwrap(&(v291_10),&(v291_22_head));
      let v297_12: Space = restrict_to(&(v291_9),&(v297_11));
      let mut v297_13 = Space::new();
      let mut v297_13_cursor = (v297_12).read_zipper();
      for v297_13_byte in v297_13_cursor.child_mask().iter() {
        v297_13_cursor.descend_to_byte(v297_13_byte);
        let v297_13_tail = v297_13_cursor.make_map();
        v297_13_cursor.ascend(1);
        let v297_13_head = Path::from_slice(&[v297_13_byte]);
        let v298_2: Space = singleton(&(v297_13_head));
        let v298_3: Space = intersect(&(*CONSTANT_1),&(v298_2));
        let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
        drop(v298_3);
        let v298_5: Space = subtract(&(*CONSTANT_0),&(v298_4));
        drop(v298_4);
        let v298_7: Space = if (v298_5).is_empty() { Space::new() } else {
          let v299_6: Space = routine_6(c, &(v297_13_head), &(v297_13_tail));
          compose(&(v298_5),&(v299_6))
        };
        drop(v298_5);
        let v298_8: Space = intersect(&(*CONSTANT_1),&(v298_2));
        drop(v298_2);
        let v298_9: Space = if has_head(&(v298_8)) { singleton(&[]) } else { Space::new() };
        drop(v298_8);
        let v298_11: Space = if (v298_9).is_empty() { Space::new() } else {
          let v300_10: Space = routine_7(c, &(v297_13_head), &(v297_13_tail));
          compose(&(v298_9),&(v300_10))
        };
        drop(v298_9);
        let v298_12: Space = unite(&(v298_7),&(v298_11));
        v297_13.join_into((v298_12).clone());
      }
      drop(v297_13_cursor);
      drop(v297_12);
      let v297_14: Space = restrict_to(&(v291_7),&(v297_13));
      let mut v297_15 = Space::new();
      let mut v297_15_cursor = (v297_14).read_zipper();
      for v297_15_byte in v297_15_cursor.child_mask().iter() {
        v297_15_cursor.descend_to_byte(v297_15_byte);
        let v297_15_tail = v297_15_cursor.make_map();
        v297_15_cursor.ascend(1);
        let v297_15_head = Path::from_slice(&[v297_15_byte]);
        let v301_2: Space = singleton(&(v297_15_head));
        let v301_3: Space = intersect(&(*CONSTANT_1),&(v301_2));
        let v301_4: Space = if has_head(&(v301_3)) { singleton(&[]) } else { Space::new() };
        drop(v301_3);
        let v301_5: Space = subtract(&(*CONSTANT_0),&(v301_4));
        drop(v301_4);
        let v301_7: Space = if (v301_5).is_empty() { Space::new() } else {
          let v302_6: Space = routine_8(c, &(v297_15_head), &(v297_15_tail));
          compose(&(v301_5),&(v302_6))
        };
        drop(v301_5);
        let v301_8: Space = intersect(&(*CONSTANT_1),&(v301_2));
        drop(v301_2);
        let v301_9: Space = if has_head(&(v301_8)) { singleton(&[]) } else { Space::new() };
        drop(v301_8);
        let v301_11: Space = if (v301_9).is_empty() { Space::new() } else {
          let v303_10: Space = routine_9(c, &(v297_15_head), &(v297_15_tail));
          compose(&(v301_9),&(v303_10))
        };
        drop(v301_9);
        let v301_12: Space = unite(&(v301_7),&(v301_11));
        v297_15.join_into((v301_12).clone());
      }
      drop(v297_15_cursor);
      let v297_16: Space = subtract(&(v297_15),&(v297_11));
      drop(v297_11);
      let v297_17: Space = intersect(&(v297_16),&(v291_12));
      compose(&(v292_10),&(v297_17))
    };
    drop(v292_10);
    let v304_6: Path = concat_path(&(*p0),&(v291_22_head));
    let v292_19: Space = wrap(&(v292_18),&(v304_6));
    let v292_20: Space = unite(&(v292_8),&(v292_19));
    v291_22.join_into((v292_20).clone());
  }
  drop(v291_22_cursor);
  drop(v291_7);
  drop(v291_9);
  drop(v291_10);
  drop(v291_12);
  (v291_22).clone()
}

fn routine_34(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v305_11 = Space::new();
  let mut v305_11_cursor = (*s0).read_zipper();
  for v305_11_byte in v305_11_cursor.child_mask().iter() {
    v305_11_cursor.descend_to_byte(v305_11_byte);
    let v305_11_tail = v305_11_cursor.make_map();
    v305_11_cursor.ascend(1);
    let v305_11_head = Path::from_slice(&[v305_11_byte]);
    let v306_2: Space = singleton(&(v305_11_head));
    let v306_3: Space = intersect(&(*CONSTANT_1),&(v306_2));
    let v306_4: Space = if has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
    drop(v306_3);
    let v306_5: Space = subtract(&(*CONSTANT_0),&(v306_4));
    drop(v306_4);
    let v306_8: Space = if (v306_5).is_empty() { Space::new() } else {
      let v307_6: Path = concat_path(&(*p0),&(v305_11_head));
      let mut v307_7 = Space::new();
      let mut v307_7_cursor = (v305_11_tail).read_zipper();
      for v307_7_byte in v307_7_cursor.child_mask().iter() {
        v307_7_cursor.descend_to_byte(v307_7_byte);
        let v307_7_tail = v307_7_cursor.make_map();
        v307_7_cursor.ascend(1);
        let v307_7_head = Path::from_slice(&[v307_7_byte]);
        let v308_2: Space = singleton(&(v307_7_head));
        let v308_3: Space = intersect(&(*CONSTANT_1),&(v308_2));
        let v308_4: Space = if has_head(&(v308_3)) { singleton(&[]) } else { Space::new() };
        drop(v308_3);
        let v308_5: Space = subtract(&(*CONSTANT_0),&(v308_4));
        drop(v308_4);
        let v308_8: Space = if (v308_5).is_empty() { Space::new() } else {
          let v309_6: Path = concat_path(&(v307_6),&(v307_7_head));
          let v309_7: Space = routine_44(c, &(v309_6), &(v307_7_tail));
          compose(&(v308_5),&(v309_7))
        };
        drop(v308_5);
        let v308_9: Space = intersect(&(*CONSTANT_1),&(v308_2));
        drop(v308_2);
        let v308_10: Space = if has_head(&(v308_9)) { singleton(&[]) } else { Space::new() };
        drop(v308_9);
        let v308_12: Space = if (v308_10).is_empty() { Space::new() } else {
          let v310_6: Path = concat_path(&(v307_6),&(v307_7_head));
          let v310_11: Space = routine_45(c, &(v310_6), &(v307_7_tail));
          drop(v310_6);
          compose(&(v308_10),&(v310_11))
        };
        drop(v308_10);
        let v308_13: Space = unite(&(v308_8),&(v308_12));
        v307_7.join_into((v308_13).clone());
      }
      drop(v307_7_cursor);
      compose(&(v306_5),&(v307_7))
    };
    drop(v306_5);
    let v306_9: Space = intersect(&(*CONSTANT_1),&(v306_2));
    drop(v306_2);
    let v306_10: Space = if has_head(&(v306_9)) { singleton(&[]) } else { Space::new() };
    drop(v306_9);
    let v306_12: Space = if (v306_10).is_empty() { Space::new() } else {
      let v311_6: Path = concat_path(&(*p0),&(v305_11_head));
      let mut v311_11 = Space::new();
      let mut v311_11_cursor = (v305_11_tail).read_zipper();
      for v311_11_byte in v311_11_cursor.child_mask().iter() {
        v311_11_cursor.descend_to_byte(v311_11_byte);
        let v311_11_tail = v311_11_cursor.make_map();
        v311_11_cursor.ascend(1);
        let v311_11_head = Path::from_slice(&[v311_11_byte]);
        let v312_2: Space = singleton(&(v311_11_head));
        let v312_3: Space = intersect(&(*CONSTANT_1),&(v312_2));
        let v312_4: Space = if has_head(&(v312_3)) { singleton(&[]) } else { Space::new() };
        drop(v312_3);
        let v312_5: Space = subtract(&(*CONSTANT_0),&(v312_4));
        drop(v312_4);
        let v312_8: Space = if (v312_5).is_empty() { Space::new() } else {
          let v313_6: Path = concat_path(&(v311_6),&(v311_11_head));
          let v313_7: Space = routine_44(c, &(v313_6), &(v311_11_tail));
          compose(&(v312_5),&(v313_7))
        };
        drop(v312_5);
        let v312_9: Space = intersect(&(*CONSTANT_1),&(v312_2));
        drop(v312_2);
        let v312_10: Space = if has_head(&(v312_9)) { singleton(&[]) } else { Space::new() };
        drop(v312_9);
        let v312_12: Space = if (v312_10).is_empty() { Space::new() } else {
          let v314_6: Path = concat_path(&(v311_6),&(v311_11_head));
          let v314_11: Space = routine_14(c, &(v314_6), &(v311_11_tail));
          drop(v314_6);
          compose(&(v312_10),&(v314_11))
        };
        drop(v312_10);
        let v312_13: Space = unite(&(v312_8),&(v312_12));
        v311_11.join_into((v312_13).clone());
      }
      drop(v311_11_cursor);
      drop(v311_6);
      compose(&(v306_10),&(v311_11))
    };
    drop(v306_10);
    let v306_13: Space = unite(&(v306_8),&(v306_12));
    v305_11.join_into((v306_13).clone());
  }
  drop(v305_11_cursor);
  (v305_11).clone()
}

fn routine_35(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v315_8 = Space::new();
  let mut v315_8_cursor = (*s0).read_zipper();
  for v315_8_byte in v315_8_cursor.child_mask().iter() {
    v315_8_cursor.descend_to_byte(v315_8_byte);
    let v315_8_tail = v315_8_cursor.make_map();
    v315_8_cursor.ascend(1);
    let v315_8_head = Path::from_slice(&[v315_8_byte]);
    let v316_2: Space = singleton(&(v315_8_head));
    let v316_3: Space = intersect(&(*CONSTANT_1),&(v316_2));
    let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
    drop(v316_3);
    let v316_5: Space = subtract(&(*CONSTANT_0),&(v316_4));
    drop(v316_4);
    let v316_8: Space = if (v316_5).is_empty() { Space::new() } else {
      let v317_6: Path = concat_path(&(*p0),&(v315_8_head));
      let mut v317_7 = Space::new();
      let mut v317_7_cursor = (v315_8_tail).read_zipper();
      for v317_7_byte in v317_7_cursor.child_mask().iter() {
        v317_7_cursor.descend_to_byte(v317_7_byte);
        let v317_7_tail = v317_7_cursor.make_map();
        v317_7_cursor.ascend(1);
        let v317_7_head = Path::from_slice(&[v317_7_byte]);
        let v318_2: Space = singleton(&(v317_7_head));
        let v318_3: Space = intersect(&(*CONSTANT_1),&(v318_2));
        let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
        drop(v318_3);
        let v318_5: Space = subtract(&(*CONSTANT_0),&(v318_4));
        drop(v318_4);
        let v318_8: Space = if (v318_5).is_empty() { Space::new() } else {
          let v319_6: Path = concat_path(&(v317_6),&(v317_7_head));
          let v319_7: Space = routine_44(c, &(v319_6), &(v317_7_tail));
          compose(&(v318_5),&(v319_7))
        };
        drop(v318_5);
        let v318_9: Space = intersect(&(*CONSTANT_1),&(v318_2));
        drop(v318_2);
        let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
        drop(v318_9);
        let v318_12: Space = if (v318_10).is_empty() { Space::new() } else {
          let v320_6: Path = concat_path(&(v317_6),&(v317_7_head));
          let v320_11: Space = routine_45(c, &(v320_6), &(v317_7_tail));
          drop(v320_6);
          compose(&(v318_10),&(v320_11))
        };
        drop(v318_10);
        let v318_13: Space = unite(&(v318_8),&(v318_12));
        v317_7.join_into((v318_13).clone());
      }
      drop(v317_7_cursor);
      drop(v317_6);
      compose(&(v316_5),&(v317_7))
    };
    drop(v316_5);
    let v316_9: Space = intersect(&(*CONSTANT_1),&(v316_2));
    drop(v316_2);
    let v316_10: Space = if has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
    drop(v316_9);
    let v316_11: Space = compose(&(v316_10),&(v315_8_tail));
    drop(v316_10);
    let v316_12: Space = unite(&(v316_8),&(v316_11));
    drop(v316_11);
    v315_8.join_into((v316_12).clone());
  }
  drop(v315_8_cursor);
  (v315_8).clone()
}

fn routine_36(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v321_11 = Space::new();
  let mut v321_11_cursor = (*s0).read_zipper();
  for v321_11_byte in v321_11_cursor.child_mask().iter() {
    v321_11_cursor.descend_to_byte(v321_11_byte);
    let v321_11_tail = v321_11_cursor.make_map();
    v321_11_cursor.ascend(1);
    let v321_11_head = Path::from_slice(&[v321_11_byte]);
    let v322_2: Space = singleton(&(v321_11_head));
    let v322_3: Space = intersect(&(*CONSTANT_1),&(v322_2));
    let v322_4: Space = if has_head(&(v322_3)) { singleton(&[]) } else { Space::new() };
    drop(v322_3);
    let v322_5: Space = subtract(&(*CONSTANT_0),&(v322_4));
    drop(v322_4);
    let v322_8: Space = if (v322_5).is_empty() { Space::new() } else {
      let v323_6: Path = concat_path(&(*p0),&(v321_11_head));
      let mut v323_7 = Space::new();
      let mut v323_7_cursor = (v321_11_tail).read_zipper();
      for v323_7_byte in v323_7_cursor.child_mask().iter() {
        v323_7_cursor.descend_to_byte(v323_7_byte);
        let v323_7_tail = v323_7_cursor.make_map();
        v323_7_cursor.ascend(1);
        let v323_7_head = Path::from_slice(&[v323_7_byte]);
        let v324_2: Space = singleton(&(v323_7_head));
        let v324_3: Space = intersect(&(*CONSTANT_1),&(v324_2));
        let v324_4: Space = if has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
        drop(v324_3);
        let v324_5: Space = subtract(&(*CONSTANT_0),&(v324_4));
        drop(v324_4);
        let v324_8: Space = if (v324_5).is_empty() { Space::new() } else {
          let v325_6: Path = concat_path(&(v323_6),&(v323_7_head));
          let v325_7: Space = routine_46(c, &(v325_6), &(v323_7_tail));
          compose(&(v324_5),&(v325_7))
        };
        drop(v324_5);
        let v324_9: Space = intersect(&(*CONSTANT_1),&(v324_2));
        drop(v324_2);
        let v324_10: Space = if has_head(&(v324_9)) { singleton(&[]) } else { Space::new() };
        drop(v324_9);
        let v324_12: Space = if (v324_10).is_empty() { Space::new() } else {
          let v326_6: Path = concat_path(&(v323_6),&(v323_7_head));
          let v326_11: Space = routine_47(c, &(v326_6), &(v323_7_tail));
          drop(v326_6);
          compose(&(v324_10),&(v326_11))
        };
        drop(v324_10);
        let v324_13: Space = unite(&(v324_8),&(v324_12));
        v323_7.join_into((v324_13).clone());
      }
      drop(v323_7_cursor);
      compose(&(v322_5),&(v323_7))
    };
    drop(v322_5);
    let v322_9: Space = intersect(&(*CONSTANT_1),&(v322_2));
    drop(v322_2);
    let v322_10: Space = if has_head(&(v322_9)) { singleton(&[]) } else { Space::new() };
    drop(v322_9);
    let v322_12: Space = if (v322_10).is_empty() { Space::new() } else {
      let v327_6: Path = concat_path(&(*p0),&(v321_11_head));
      let mut v327_11 = Space::new();
      let mut v327_11_cursor = (v321_11_tail).read_zipper();
      for v327_11_byte in v327_11_cursor.child_mask().iter() {
        v327_11_cursor.descend_to_byte(v327_11_byte);
        let v327_11_tail = v327_11_cursor.make_map();
        v327_11_cursor.ascend(1);
        let v327_11_head = Path::from_slice(&[v327_11_byte]);
        let v328_2: Space = singleton(&(v327_11_head));
        let v328_3: Space = intersect(&(*CONSTANT_1),&(v328_2));
        let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
        drop(v328_3);
        let v328_5: Space = subtract(&(*CONSTANT_0),&(v328_4));
        drop(v328_4);
        let v328_8: Space = if (v328_5).is_empty() { Space::new() } else {
          let v329_6: Path = concat_path(&(v327_6),&(v327_11_head));
          let v329_7: Space = routine_46(c, &(v329_6), &(v327_11_tail));
          compose(&(v328_5),&(v329_7))
        };
        drop(v328_5);
        let v328_9: Space = intersect(&(*CONSTANT_1),&(v328_2));
        drop(v328_2);
        let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
        drop(v328_9);
        let v328_12: Space = if (v328_10).is_empty() { Space::new() } else {
          let v330_6: Path = concat_path(&(v327_6),&(v327_11_head));
          let v330_11: Space = routine_17(c, &(v330_6), &(v327_11_tail));
          drop(v330_6);
          compose(&(v328_10),&(v330_11))
        };
        drop(v328_10);
        let v328_13: Space = unite(&(v328_8),&(v328_12));
        v327_11.join_into((v328_13).clone());
      }
      drop(v327_11_cursor);
      drop(v327_6);
      compose(&(v322_10),&(v327_11))
    };
    drop(v322_10);
    let v322_13: Space = unite(&(v322_8),&(v322_12));
    v321_11.join_into((v322_13).clone());
  }
  drop(v321_11_cursor);
  (v321_11).clone()
}

fn routine_37(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v331_8 = Space::new();
  let mut v331_8_cursor = (*s0).read_zipper();
  for v331_8_byte in v331_8_cursor.child_mask().iter() {
    v331_8_cursor.descend_to_byte(v331_8_byte);
    let v331_8_tail = v331_8_cursor.make_map();
    v331_8_cursor.ascend(1);
    let v331_8_head = Path::from_slice(&[v331_8_byte]);
    let v332_2: Space = singleton(&(v331_8_head));
    let v332_3: Space = intersect(&(*CONSTANT_1),&(v332_2));
    let v332_4: Space = if has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
    drop(v332_3);
    let v332_5: Space = subtract(&(*CONSTANT_0),&(v332_4));
    drop(v332_4);
    let v332_8: Space = if (v332_5).is_empty() { Space::new() } else {
      let v333_6: Path = concat_path(&(*p0),&(v331_8_head));
      let mut v333_7 = Space::new();
      let mut v333_7_cursor = (v331_8_tail).read_zipper();
      for v333_7_byte in v333_7_cursor.child_mask().iter() {
        v333_7_cursor.descend_to_byte(v333_7_byte);
        let v333_7_tail = v333_7_cursor.make_map();
        v333_7_cursor.ascend(1);
        let v333_7_head = Path::from_slice(&[v333_7_byte]);
        let v334_2: Space = singleton(&(v333_7_head));
        let v334_3: Space = intersect(&(*CONSTANT_1),&(v334_2));
        let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
        drop(v334_3);
        let v334_5: Space = subtract(&(*CONSTANT_0),&(v334_4));
        drop(v334_4);
        let v334_8: Space = if (v334_5).is_empty() { Space::new() } else {
          let v335_6: Path = concat_path(&(v333_6),&(v333_7_head));
          let v335_7: Space = routine_46(c, &(v335_6), &(v333_7_tail));
          compose(&(v334_5),&(v335_7))
        };
        drop(v334_5);
        let v334_9: Space = intersect(&(*CONSTANT_1),&(v334_2));
        drop(v334_2);
        let v334_10: Space = if has_head(&(v334_9)) { singleton(&[]) } else { Space::new() };
        drop(v334_9);
        let v334_12: Space = if (v334_10).is_empty() { Space::new() } else {
          let v336_6: Path = concat_path(&(v333_6),&(v333_7_head));
          let v336_11: Space = routine_47(c, &(v336_6), &(v333_7_tail));
          drop(v336_6);
          compose(&(v334_10),&(v336_11))
        };
        drop(v334_10);
        let v334_13: Space = unite(&(v334_8),&(v334_12));
        v333_7.join_into((v334_13).clone());
      }
      drop(v333_7_cursor);
      drop(v333_6);
      compose(&(v332_5),&(v333_7))
    };
    drop(v332_5);
    let v332_9: Space = intersect(&(*CONSTANT_1),&(v332_2));
    drop(v332_2);
    let v332_10: Space = if has_head(&(v332_9)) { singleton(&[]) } else { Space::new() };
    drop(v332_9);
    let v332_11: Space = compose(&(v332_10),&(v331_8_tail));
    drop(v332_10);
    let v332_12: Space = unite(&(v332_8),&(v332_11));
    drop(v332_11);
    v331_8.join_into((v332_12).clone());
  }
  drop(v331_8_cursor);
  (v331_8).clone()
}

fn routine_38(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v337_11 = Space::new();
  let mut v337_11_cursor = (*s0).read_zipper();
  for v337_11_byte in v337_11_cursor.child_mask().iter() {
    v337_11_cursor.descend_to_byte(v337_11_byte);
    let v337_11_tail = v337_11_cursor.make_map();
    v337_11_cursor.ascend(1);
    let v337_11_head = Path::from_slice(&[v337_11_byte]);
    let v338_2: Space = singleton(&(v337_11_head));
    let v338_3: Space = intersect(&(*CONSTANT_1),&(v338_2));
    let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
    drop(v338_3);
    let v338_5: Space = subtract(&(*CONSTANT_0),&(v338_4));
    drop(v338_4);
    let v338_8: Space = if (v338_5).is_empty() { Space::new() } else {
      let v339_6: Path = concat_path(&(*p0),&(v337_11_head));
      let mut v339_7 = Space::new();
      let mut v339_7_cursor = (v337_11_tail).read_zipper();
      for v339_7_byte in v339_7_cursor.child_mask().iter() {
        v339_7_cursor.descend_to_byte(v339_7_byte);
        let v339_7_tail = v339_7_cursor.make_map();
        v339_7_cursor.ascend(1);
        let v339_7_head = Path::from_slice(&[v339_7_byte]);
        let v340_2: Space = singleton(&(v339_7_head));
        let v340_3: Space = intersect(&(*CONSTANT_1),&(v340_2));
        let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
        drop(v340_3);
        let v340_5: Space = subtract(&(*CONSTANT_0),&(v340_4));
        drop(v340_4);
        let v340_8: Space = if (v340_5).is_empty() { Space::new() } else {
          let v341_6: Path = concat_path(&(v339_6),&(v339_7_head));
          let v341_7: Space = routine_48(c, &(v341_6), &(v339_7_tail));
          compose(&(v340_5),&(v341_7))
        };
        drop(v340_5);
        let v340_9: Space = intersect(&(*CONSTANT_1),&(v340_2));
        drop(v340_2);
        let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
        drop(v340_9);
        let v340_12: Space = if (v340_10).is_empty() { Space::new() } else {
          let v342_6: Path = concat_path(&(v339_6),&(v339_7_head));
          let v342_11: Space = routine_49(c, &(v342_6), &(v339_7_tail));
          drop(v342_6);
          compose(&(v340_10),&(v342_11))
        };
        drop(v340_10);
        let v340_13: Space = unite(&(v340_8),&(v340_12));
        v339_7.join_into((v340_13).clone());
      }
      drop(v339_7_cursor);
      compose(&(v338_5),&(v339_7))
    };
    drop(v338_5);
    let v338_9: Space = intersect(&(*CONSTANT_1),&(v338_2));
    drop(v338_2);
    let v338_10: Space = if has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
    drop(v338_9);
    let v338_12: Space = if (v338_10).is_empty() { Space::new() } else {
      let v343_6: Path = concat_path(&(*p0),&(v337_11_head));
      let mut v343_11 = Space::new();
      let mut v343_11_cursor = (v337_11_tail).read_zipper();
      for v343_11_byte in v343_11_cursor.child_mask().iter() {
        v343_11_cursor.descend_to_byte(v343_11_byte);
        let v343_11_tail = v343_11_cursor.make_map();
        v343_11_cursor.ascend(1);
        let v343_11_head = Path::from_slice(&[v343_11_byte]);
        let v344_2: Space = singleton(&(v343_11_head));
        let v344_3: Space = intersect(&(*CONSTANT_1),&(v344_2));
        let v344_4: Space = if has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
        drop(v344_3);
        let v344_5: Space = subtract(&(*CONSTANT_0),&(v344_4));
        drop(v344_4);
        let v344_8: Space = if (v344_5).is_empty() { Space::new() } else {
          let v345_6: Path = concat_path(&(v343_6),&(v343_11_head));
          let v345_7: Space = routine_48(c, &(v345_6), &(v343_11_tail));
          compose(&(v344_5),&(v345_7))
        };
        drop(v344_5);
        let v344_9: Space = intersect(&(*CONSTANT_1),&(v344_2));
        drop(v344_2);
        let v344_10: Space = if has_head(&(v344_9)) { singleton(&[]) } else { Space::new() };
        drop(v344_9);
        let v344_12: Space = if (v344_10).is_empty() { Space::new() } else {
          let v346_6: Path = concat_path(&(v343_6),&(v343_11_head));
          let v346_11: Space = routine_14(c, &(v346_6), &(v343_11_tail));
          drop(v346_6);
          compose(&(v344_10),&(v346_11))
        };
        drop(v344_10);
        let v344_13: Space = unite(&(v344_8),&(v344_12));
        v343_11.join_into((v344_13).clone());
      }
      drop(v343_11_cursor);
      drop(v343_6);
      compose(&(v338_10),&(v343_11))
    };
    drop(v338_10);
    let v338_13: Space = unite(&(v338_8),&(v338_12));
    v337_11.join_into((v338_13).clone());
  }
  drop(v337_11_cursor);
  (v337_11).clone()
}

fn routine_39(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v347_8 = Space::new();
  let mut v347_8_cursor = (*s0).read_zipper();
  for v347_8_byte in v347_8_cursor.child_mask().iter() {
    v347_8_cursor.descend_to_byte(v347_8_byte);
    let v347_8_tail = v347_8_cursor.make_map();
    v347_8_cursor.ascend(1);
    let v347_8_head = Path::from_slice(&[v347_8_byte]);
    let v348_2: Space = singleton(&(v347_8_head));
    let v348_3: Space = intersect(&(*CONSTANT_1),&(v348_2));
    let v348_4: Space = if has_head(&(v348_3)) { singleton(&[]) } else { Space::new() };
    drop(v348_3);
    let v348_5: Space = subtract(&(*CONSTANT_0),&(v348_4));
    drop(v348_4);
    let v348_8: Space = if (v348_5).is_empty() { Space::new() } else {
      let v349_6: Path = concat_path(&(*p0),&(v347_8_head));
      let mut v349_7 = Space::new();
      let mut v349_7_cursor = (v347_8_tail).read_zipper();
      for v349_7_byte in v349_7_cursor.child_mask().iter() {
        v349_7_cursor.descend_to_byte(v349_7_byte);
        let v349_7_tail = v349_7_cursor.make_map();
        v349_7_cursor.ascend(1);
        let v349_7_head = Path::from_slice(&[v349_7_byte]);
        let v350_2: Space = singleton(&(v349_7_head));
        let v350_3: Space = intersect(&(*CONSTANT_1),&(v350_2));
        let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
        drop(v350_3);
        let v350_5: Space = subtract(&(*CONSTANT_0),&(v350_4));
        drop(v350_4);
        let v350_8: Space = if (v350_5).is_empty() { Space::new() } else {
          let v351_6: Path = concat_path(&(v349_6),&(v349_7_head));
          let v351_7: Space = routine_48(c, &(v351_6), &(v349_7_tail));
          compose(&(v350_5),&(v351_7))
        };
        drop(v350_5);
        let v350_9: Space = intersect(&(*CONSTANT_1),&(v350_2));
        drop(v350_2);
        let v350_10: Space = if has_head(&(v350_9)) { singleton(&[]) } else { Space::new() };
        drop(v350_9);
        let v350_12: Space = if (v350_10).is_empty() { Space::new() } else {
          let v352_6: Path = concat_path(&(v349_6),&(v349_7_head));
          let v352_11: Space = routine_49(c, &(v352_6), &(v349_7_tail));
          drop(v352_6);
          compose(&(v350_10),&(v352_11))
        };
        drop(v350_10);
        let v350_13: Space = unite(&(v350_8),&(v350_12));
        v349_7.join_into((v350_13).clone());
      }
      drop(v349_7_cursor);
      drop(v349_6);
      compose(&(v348_5),&(v349_7))
    };
    drop(v348_5);
    let v348_9: Space = intersect(&(*CONSTANT_1),&(v348_2));
    drop(v348_2);
    let v348_10: Space = if has_head(&(v348_9)) { singleton(&[]) } else { Space::new() };
    drop(v348_9);
    let v348_11: Space = compose(&(v348_10),&(v347_8_tail));
    drop(v348_10);
    let v348_12: Space = unite(&(v348_8),&(v348_11));
    drop(v348_11);
    v347_8.join_into((v348_12).clone());
  }
  drop(v347_8_cursor);
  (v347_8).clone()
}

fn routine_40(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v353_11 = Space::new();
  let mut v353_11_cursor = (*s0).read_zipper();
  for v353_11_byte in v353_11_cursor.child_mask().iter() {
    v353_11_cursor.descend_to_byte(v353_11_byte);
    let v353_11_tail = v353_11_cursor.make_map();
    v353_11_cursor.ascend(1);
    let v353_11_head = Path::from_slice(&[v353_11_byte]);
    let v354_2: Space = singleton(&(v353_11_head));
    let v354_3: Space = intersect(&(*CONSTANT_1),&(v354_2));
    let v354_4: Space = if has_head(&(v354_3)) { singleton(&[]) } else { Space::new() };
    drop(v354_3);
    let v354_5: Space = subtract(&(*CONSTANT_0),&(v354_4));
    drop(v354_4);
    let v354_8: Space = if (v354_5).is_empty() { Space::new() } else {
      let v355_6: Path = concat_path(&(*p0),&(v353_11_head));
      let mut v355_7 = Space::new();
      let mut v355_7_cursor = (v353_11_tail).read_zipper();
      for v355_7_byte in v355_7_cursor.child_mask().iter() {
        v355_7_cursor.descend_to_byte(v355_7_byte);
        let v355_7_tail = v355_7_cursor.make_map();
        v355_7_cursor.ascend(1);
        let v355_7_head = Path::from_slice(&[v355_7_byte]);
        let v356_2: Space = singleton(&(v355_7_head));
        let v356_3: Space = intersect(&(*CONSTANT_1),&(v356_2));
        let v356_4: Space = if has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
        drop(v356_3);
        let v356_5: Space = subtract(&(*CONSTANT_0),&(v356_4));
        drop(v356_4);
        let v356_8: Space = if (v356_5).is_empty() { Space::new() } else {
          let v357_6: Path = concat_path(&(v355_6),&(v355_7_head));
          let v357_7: Space = routine_50(c, &(v357_6), &(v355_7_tail));
          compose(&(v356_5),&(v357_7))
        };
        drop(v356_5);
        let v356_9: Space = intersect(&(*CONSTANT_1),&(v356_2));
        drop(v356_2);
        let v356_10: Space = if has_head(&(v356_9)) { singleton(&[]) } else { Space::new() };
        drop(v356_9);
        let v356_12: Space = if (v356_10).is_empty() { Space::new() } else {
          let v358_6: Path = concat_path(&(v355_6),&(v355_7_head));
          let v358_11: Space = routine_51(c, &(v358_6), &(v355_7_tail));
          drop(v358_6);
          compose(&(v356_10),&(v358_11))
        };
        drop(v356_10);
        let v356_13: Space = unite(&(v356_8),&(v356_12));
        v355_7.join_into((v356_13).clone());
      }
      drop(v355_7_cursor);
      compose(&(v354_5),&(v355_7))
    };
    drop(v354_5);
    let v354_9: Space = intersect(&(*CONSTANT_1),&(v354_2));
    drop(v354_2);
    let v354_10: Space = if has_head(&(v354_9)) { singleton(&[]) } else { Space::new() };
    drop(v354_9);
    let v354_12: Space = if (v354_10).is_empty() { Space::new() } else {
      let v359_6: Path = concat_path(&(*p0),&(v353_11_head));
      let mut v359_11 = Space::new();
      let mut v359_11_cursor = (v353_11_tail).read_zipper();
      for v359_11_byte in v359_11_cursor.child_mask().iter() {
        v359_11_cursor.descend_to_byte(v359_11_byte);
        let v359_11_tail = v359_11_cursor.make_map();
        v359_11_cursor.ascend(1);
        let v359_11_head = Path::from_slice(&[v359_11_byte]);
        let v360_2: Space = singleton(&(v359_11_head));
        let v360_3: Space = intersect(&(*CONSTANT_1),&(v360_2));
        let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
        drop(v360_3);
        let v360_5: Space = subtract(&(*CONSTANT_0),&(v360_4));
        drop(v360_4);
        let v360_8: Space = if (v360_5).is_empty() { Space::new() } else {
          let v361_6: Path = concat_path(&(v359_6),&(v359_11_head));
          let v361_7: Space = routine_50(c, &(v361_6), &(v359_11_tail));
          compose(&(v360_5),&(v361_7))
        };
        drop(v360_5);
        let v360_9: Space = intersect(&(*CONSTANT_1),&(v360_2));
        drop(v360_2);
        let v360_10: Space = if has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
        drop(v360_9);
        let v360_12: Space = if (v360_10).is_empty() { Space::new() } else {
          let v362_6: Path = concat_path(&(v359_6),&(v359_11_head));
          let v362_11: Space = routine_17(c, &(v362_6), &(v359_11_tail));
          drop(v362_6);
          compose(&(v360_10),&(v362_11))
        };
        drop(v360_10);
        let v360_13: Space = unite(&(v360_8),&(v360_12));
        v359_11.join_into((v360_13).clone());
      }
      drop(v359_11_cursor);
      drop(v359_6);
      compose(&(v354_10),&(v359_11))
    };
    drop(v354_10);
    let v354_13: Space = unite(&(v354_8),&(v354_12));
    v353_11.join_into((v354_13).clone());
  }
  drop(v353_11_cursor);
  (v353_11).clone()
}

fn routine_41(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v363_8 = Space::new();
  let mut v363_8_cursor = (*s0).read_zipper();
  for v363_8_byte in v363_8_cursor.child_mask().iter() {
    v363_8_cursor.descend_to_byte(v363_8_byte);
    let v363_8_tail = v363_8_cursor.make_map();
    v363_8_cursor.ascend(1);
    let v363_8_head = Path::from_slice(&[v363_8_byte]);
    let v364_2: Space = singleton(&(v363_8_head));
    let v364_3: Space = intersect(&(*CONSTANT_1),&(v364_2));
    let v364_4: Space = if has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
    drop(v364_3);
    let v364_5: Space = subtract(&(*CONSTANT_0),&(v364_4));
    drop(v364_4);
    let v364_8: Space = if (v364_5).is_empty() { Space::new() } else {
      let v365_6: Path = concat_path(&(*p0),&(v363_8_head));
      let mut v365_7 = Space::new();
      let mut v365_7_cursor = (v363_8_tail).read_zipper();
      for v365_7_byte in v365_7_cursor.child_mask().iter() {
        v365_7_cursor.descend_to_byte(v365_7_byte);
        let v365_7_tail = v365_7_cursor.make_map();
        v365_7_cursor.ascend(1);
        let v365_7_head = Path::from_slice(&[v365_7_byte]);
        let v366_2: Space = singleton(&(v365_7_head));
        let v366_3: Space = intersect(&(*CONSTANT_1),&(v366_2));
        let v366_4: Space = if has_head(&(v366_3)) { singleton(&[]) } else { Space::new() };
        drop(v366_3);
        let v366_5: Space = subtract(&(*CONSTANT_0),&(v366_4));
        drop(v366_4);
        let v366_8: Space = if (v366_5).is_empty() { Space::new() } else {
          let v367_6: Path = concat_path(&(v365_6),&(v365_7_head));
          let v367_7: Space = routine_50(c, &(v367_6), &(v365_7_tail));
          compose(&(v366_5),&(v367_7))
        };
        drop(v366_5);
        let v366_9: Space = intersect(&(*CONSTANT_1),&(v366_2));
        drop(v366_2);
        let v366_10: Space = if has_head(&(v366_9)) { singleton(&[]) } else { Space::new() };
        drop(v366_9);
        let v366_12: Space = if (v366_10).is_empty() { Space::new() } else {
          let v368_6: Path = concat_path(&(v365_6),&(v365_7_head));
          let v368_11: Space = routine_51(c, &(v368_6), &(v365_7_tail));
          drop(v368_6);
          compose(&(v366_10),&(v368_11))
        };
        drop(v366_10);
        let v366_13: Space = unite(&(v366_8),&(v366_12));
        v365_7.join_into((v366_13).clone());
      }
      drop(v365_7_cursor);
      drop(v365_6);
      compose(&(v364_5),&(v365_7))
    };
    drop(v364_5);
    let v364_9: Space = intersect(&(*CONSTANT_1),&(v364_2));
    drop(v364_2);
    let v364_10: Space = if has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
    drop(v364_9);
    let v364_11: Space = compose(&(v364_10),&(v363_8_tail));
    drop(v364_10);
    let v364_12: Space = unite(&(v364_8),&(v364_11));
    drop(v364_11);
    v363_8.join_into((v364_12).clone());
  }
  drop(v363_8_cursor);
  (v363_8).clone()
}

fn routine_42(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v369_12 = Space::new();
  let mut v369_12_cursor = (*s0).read_zipper();
  for v369_12_byte in v369_12_cursor.child_mask().iter() {
    v369_12_cursor.descend_to_byte(v369_12_byte);
    let v369_12_tail = v369_12_cursor.make_map();
    v369_12_cursor.ascend(1);
    let v369_12_head = Path::from_slice(&[v369_12_byte]);
    let v370_2: Space = singleton(&(v369_12_head));
    let v370_3: Space = intersect(&(*CONSTANT_1),&(v370_2));
    let v370_4: Space = if has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
    drop(v370_3);
    let v370_5: Space = subtract(&(*CONSTANT_0),&(v370_4));
    drop(v370_4);
    let v370_8: Space = if (v370_5).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&(v369_12_head));
      let mut v371_7 = Space::new();
      let mut v371_7_cursor = (v369_12_tail).read_zipper();
      for v371_7_byte in v371_7_cursor.child_mask().iter() {
        v371_7_cursor.descend_to_byte(v371_7_byte);
        let v371_7_tail = v371_7_cursor.make_map();
        v371_7_cursor.ascend(1);
        let v371_7_head = Path::from_slice(&[v371_7_byte]);
        let v372_2: Space = singleton(&(v371_7_head));
        let v372_3: Space = intersect(&(*CONSTANT_1),&(v372_2));
        let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
        drop(v372_3);
        let v372_5: Space = subtract(&(*CONSTANT_0),&(v372_4));
        drop(v372_4);
        let v372_8: Space = if (v372_5).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v371_6),&(v371_7_head));
          let v373_7: Space = routine_52(c, &(v373_6), &(v371_7_tail), &(*s1));
          compose(&(v372_5),&(v373_7))
        };
        drop(v372_5);
        let v372_9: Space = intersect(&(*CONSTANT_1),&(v372_2));
        drop(v372_2);
        let v372_10: Space = if has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
        drop(v372_9);
        let v372_12: Space = if (v372_10).is_empty() { Space::new() } else {
          let v374_6: Path = concat_path(&(v371_6),&(v371_7_head));
          let v374_11: Space = routine_53(c, &(v374_6), &(v371_7_tail), &(*s1));
          drop(v374_6);
          compose(&(v372_10),&(v374_11))
        };
        drop(v372_10);
        let v372_13: Space = unite(&(v372_8),&(v372_12));
        v371_7.join_into((v372_13).clone());
      }
      drop(v371_7_cursor);
      compose(&(v370_5),&(v371_7))
    };
    drop(v370_5);
    let v370_9: Space = intersect(&(*CONSTANT_1),&(v370_2));
    drop(v370_2);
    let v370_10: Space = if has_head(&(v370_9)) { singleton(&[]) } else { Space::new() };
    drop(v370_9);
    let v370_12: Space = if (v370_10).is_empty() { Space::new() } else {
      let v375_6: Path = concat_path(&(*p0),&(v369_12_head));
      let mut v375_11 = Space::new();
      let mut v375_11_cursor = (v369_12_tail).read_zipper();
      for v375_11_byte in v375_11_cursor.child_mask().iter() {
        v375_11_cursor.descend_to_byte(v375_11_byte);
        let v375_11_tail = v375_11_cursor.make_map();
        v375_11_cursor.ascend(1);
        let v375_11_head = Path::from_slice(&[v375_11_byte]);
        let v376_2: Space = singleton(&(v375_11_head));
        let v376_3: Space = intersect(&(*CONSTANT_1),&(v376_2));
        let v376_4: Space = if has_head(&(v376_3)) { singleton(&[]) } else { Space::new() };
        drop(v376_3);
        let v376_5: Space = subtract(&(*CONSTANT_0),&(v376_4));
        drop(v376_4);
        let v376_8: Space = if (v376_5).is_empty() { Space::new() } else {
          let v377_6: Path = concat_path(&(v375_6),&(v375_11_head));
          let v377_7: Space = routine_52(c, &(v377_6), &(v375_11_tail), &(*s1));
          compose(&(v376_5),&(v377_7))
        };
        drop(v376_5);
        let v376_9: Space = intersect(&(*CONSTANT_1),&(v376_2));
        drop(v376_2);
        let v376_10: Space = if has_head(&(v376_9)) { singleton(&[]) } else { Space::new() };
        drop(v376_9);
        let v376_12: Space = if (v376_10).is_empty() { Space::new() } else {
          let v378_6: Path = concat_path(&(v375_6),&(v375_11_head));
          let v378_11: Space = routine_5(c, &(v378_6), &(v375_11_tail), &(*s1));
          drop(v378_6);
          compose(&(v376_10),&(v378_11))
        };
        drop(v376_10);
        let v376_13: Space = unite(&(v376_8),&(v376_12));
        v375_11.join_into((v376_13).clone());
      }
      drop(v375_11_cursor);
      drop(v375_6);
      compose(&(v370_10),&(v375_11))
    };
    drop(v370_10);
    let v370_13: Space = unite(&(v370_8),&(v370_12));
    v369_12.join_into((v370_13).clone());
  }
  drop(v369_12_cursor);
  (v369_12).clone()
}

fn routine_43(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v379_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v379_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v379_10: Space = unwrap(&(v379_9),&(*p0));
  let v379_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v379_22 = Space::new();
  let mut v379_22_cursor = (*s0).read_zipper();
  for v379_22_byte in v379_22_cursor.child_mask().iter() {
    v379_22_cursor.descend_to_byte(v379_22_byte);
    let v379_22_tail = v379_22_cursor.make_map();
    v379_22_cursor.ascend(1);
    let v379_22_head = Path::from_slice(&[v379_22_byte]);
    let v380_2: Space = singleton(&(v379_22_head));
    let v380_3: Space = intersect(&(*CONSTANT_1),&(v380_2));
    let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
    drop(v380_3);
    let v380_5: Space = subtract(&(*CONSTANT_0),&(v380_4));
    drop(v380_4);
    let v380_8: Space = if (v380_5).is_empty() { Space::new() } else {
      let v381_6: Path = concat_path(&(*p0),&(v379_22_head));
      let mut v381_7 = Space::new();
      let mut v381_7_cursor = (v379_22_tail).read_zipper();
      for v381_7_byte in v381_7_cursor.child_mask().iter() {
        v381_7_cursor.descend_to_byte(v381_7_byte);
        let v381_7_tail = v381_7_cursor.make_map();
        v381_7_cursor.ascend(1);
        let v381_7_head = Path::from_slice(&[v381_7_byte]);
        let v382_2: Space = singleton(&(v381_7_head));
        let v382_3: Space = intersect(&(*CONSTANT_1),&(v382_2));
        let v382_4: Space = if has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
        drop(v382_3);
        let v382_5: Space = subtract(&(*CONSTANT_0),&(v382_4));
        drop(v382_4);
        let v382_8: Space = if (v382_5).is_empty() { Space::new() } else {
          let v383_6: Path = concat_path(&(v381_6),&(v381_7_head));
          let v383_7: Space = routine_52(c, &(v383_6), &(v381_7_tail), &(*s1));
          compose(&(v382_5),&(v383_7))
        };
        drop(v382_5);
        let v382_9: Space = intersect(&(*CONSTANT_1),&(v382_2));
        drop(v382_2);
        let v382_10: Space = if has_head(&(v382_9)) { singleton(&[]) } else { Space::new() };
        drop(v382_9);
        let v382_12: Space = if (v382_10).is_empty() { Space::new() } else {
          let v384_6: Path = concat_path(&(v381_6),&(v381_7_head));
          let v384_11: Space = routine_53(c, &(v384_6), &(v381_7_tail), &(*s1));
          drop(v384_6);
          compose(&(v382_10),&(v384_11))
        };
        drop(v382_10);
        let v382_13: Space = unite(&(v382_8),&(v382_12));
        v381_7.join_into((v382_13).clone());
      }
      drop(v381_7_cursor);
      compose(&(v380_5),&(v381_7))
    };
    drop(v380_5);
    let v380_9: Space = intersect(&(*CONSTANT_1),&(v380_2));
    drop(v380_2);
    let v380_10: Space = if has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
    drop(v380_9);
    let v380_18: Space = if (v380_10).is_empty() { Space::new() } else {
      let v385_11: Space = unwrap(&(v379_10),&(v379_22_head));
      let v385_12: Space = restrict_to(&(v379_9),&(v385_11));
      let mut v385_13 = Space::new();
      let mut v385_13_cursor = (v385_12).read_zipper();
      for v385_13_byte in v385_13_cursor.child_mask().iter() {
        v385_13_cursor.descend_to_byte(v385_13_byte);
        let v385_13_tail = v385_13_cursor.make_map();
        v385_13_cursor.ascend(1);
        let v385_13_head = Path::from_slice(&[v385_13_byte]);
        let v386_2: Space = singleton(&(v385_13_head));
        let v386_3: Space = intersect(&(*CONSTANT_1),&(v386_2));
        let v386_4: Space = if has_head(&(v386_3)) { singleton(&[]) } else { Space::new() };
        drop(v386_3);
        let v386_5: Space = subtract(&(*CONSTANT_0),&(v386_4));
        drop(v386_4);
        let v386_7: Space = if (v386_5).is_empty() { Space::new() } else {
          let v387_6: Space = routine_6(c, &(v385_13_head), &(v385_13_tail));
          compose(&(v386_5),&(v387_6))
        };
        drop(v386_5);
        let v386_8: Space = intersect(&(*CONSTANT_1),&(v386_2));
        drop(v386_2);
        let v386_9: Space = if has_head(&(v386_8)) { singleton(&[]) } else { Space::new() };
        drop(v386_8);
        let v386_11: Space = if (v386_9).is_empty() { Space::new() } else {
          let v388_10: Space = routine_7(c, &(v385_13_head), &(v385_13_tail));
          compose(&(v386_9),&(v388_10))
        };
        drop(v386_9);
        let v386_12: Space = unite(&(v386_7),&(v386_11));
        v385_13.join_into((v386_12).clone());
      }
      drop(v385_13_cursor);
      drop(v385_12);
      let v385_14: Space = restrict_to(&(v379_7),&(v385_13));
      let mut v385_15 = Space::new();
      let mut v385_15_cursor = (v385_14).read_zipper();
      for v385_15_byte in v385_15_cursor.child_mask().iter() {
        v385_15_cursor.descend_to_byte(v385_15_byte);
        let v385_15_tail = v385_15_cursor.make_map();
        v385_15_cursor.ascend(1);
        let v385_15_head = Path::from_slice(&[v385_15_byte]);
        let v389_2: Space = singleton(&(v385_15_head));
        let v389_3: Space = intersect(&(*CONSTANT_1),&(v389_2));
        let v389_4: Space = if has_head(&(v389_3)) { singleton(&[]) } else { Space::new() };
        drop(v389_3);
        let v389_5: Space = subtract(&(*CONSTANT_0),&(v389_4));
        drop(v389_4);
        let v389_7: Space = if (v389_5).is_empty() { Space::new() } else {
          let v390_6: Space = routine_8(c, &(v385_15_head), &(v385_15_tail));
          compose(&(v389_5),&(v390_6))
        };
        drop(v389_5);
        let v389_8: Space = intersect(&(*CONSTANT_1),&(v389_2));
        drop(v389_2);
        let v389_9: Space = if has_head(&(v389_8)) { singleton(&[]) } else { Space::new() };
        drop(v389_8);
        let v389_11: Space = if (v389_9).is_empty() { Space::new() } else {
          let v391_10: Space = routine_9(c, &(v385_15_head), &(v385_15_tail));
          compose(&(v389_9),&(v391_10))
        };
        drop(v389_9);
        let v389_12: Space = unite(&(v389_7),&(v389_11));
        v385_15.join_into((v389_12).clone());
      }
      drop(v385_15_cursor);
      let v385_16: Space = subtract(&(v385_15),&(v385_11));
      drop(v385_11);
      let v385_17: Space = intersect(&(v385_16),&(v379_12));
      compose(&(v380_10),&(v385_17))
    };
    drop(v380_10);
    let v392_6: Path = concat_path(&(*p0),&(v379_22_head));
    let v380_19: Space = wrap(&(v380_18),&(v392_6));
    let v380_20: Space = unite(&(v380_8),&(v380_19));
    v379_22.join_into((v380_20).clone());
  }
  drop(v379_22_cursor);
  drop(v379_7);
  drop(v379_9);
  drop(v379_10);
  drop(v379_12);
  (v379_22).clone()
}

fn routine_44(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v393_11 = Space::new();
  let mut v393_11_cursor = (*s0).read_zipper();
  for v393_11_byte in v393_11_cursor.child_mask().iter() {
    v393_11_cursor.descend_to_byte(v393_11_byte);
    let v393_11_tail = v393_11_cursor.make_map();
    v393_11_cursor.ascend(1);
    let v393_11_head = Path::from_slice(&[v393_11_byte]);
    let v394_2: Space = singleton(&(v393_11_head));
    let v394_3: Space = intersect(&(*CONSTANT_1),&(v394_2));
    let v394_4: Space = if has_head(&(v394_3)) { singleton(&[]) } else { Space::new() };
    drop(v394_3);
    let v394_5: Space = subtract(&(*CONSTANT_0),&(v394_4));
    drop(v394_4);
    let v394_8: Space = if (v394_5).is_empty() { Space::new() } else {
      let v395_6: Path = concat_path(&(*p0),&(v393_11_head));
      let mut v395_7 = Space::new();
      let mut v395_7_cursor = (v393_11_tail).read_zipper();
      for v395_7_byte in v395_7_cursor.child_mask().iter() {
        v395_7_cursor.descend_to_byte(v395_7_byte);
        let v395_7_tail = v395_7_cursor.make_map();
        v395_7_cursor.ascend(1);
        let v395_7_head = Path::from_slice(&[v395_7_byte]);
        let v396_2: Space = singleton(&(v395_7_head));
        let v396_3: Space = intersect(&(*CONSTANT_1),&(v396_2));
        let v396_4: Space = if has_head(&(v396_3)) { singleton(&[]) } else { Space::new() };
        drop(v396_3);
        let v396_5: Space = subtract(&(*CONSTANT_0),&(v396_4));
        drop(v396_4);
        let v396_8: Space = if (v396_5).is_empty() { Space::new() } else {
          let v397_6: Path = concat_path(&(v395_6),&(v395_7_head));
          let v397_7: Space = routine_54(c, &(v397_6), &(v395_7_tail));
          compose(&(v396_5),&(v397_7))
        };
        drop(v396_5);
        let v396_9: Space = intersect(&(*CONSTANT_1),&(v396_2));
        drop(v396_2);
        let v396_10: Space = if has_head(&(v396_9)) { singleton(&[]) } else { Space::new() };
        drop(v396_9);
        let v396_12: Space = if (v396_10).is_empty() { Space::new() } else {
          let v398_6: Path = concat_path(&(v395_6),&(v395_7_head));
          let v398_11: Space = routine_55(c, &(v398_6), &(v395_7_tail));
          drop(v398_6);
          compose(&(v396_10),&(v398_11))
        };
        drop(v396_10);
        let v396_13: Space = unite(&(v396_8),&(v396_12));
        v395_7.join_into((v396_13).clone());
      }
      drop(v395_7_cursor);
      compose(&(v394_5),&(v395_7))
    };
    drop(v394_5);
    let v394_9: Space = intersect(&(*CONSTANT_1),&(v394_2));
    drop(v394_2);
    let v394_10: Space = if has_head(&(v394_9)) { singleton(&[]) } else { Space::new() };
    drop(v394_9);
    let v394_12: Space = if (v394_10).is_empty() { Space::new() } else {
      let v399_6: Path = concat_path(&(*p0),&(v393_11_head));
      let mut v399_11 = Space::new();
      let mut v399_11_cursor = (v393_11_tail).read_zipper();
      for v399_11_byte in v399_11_cursor.child_mask().iter() {
        v399_11_cursor.descend_to_byte(v399_11_byte);
        let v399_11_tail = v399_11_cursor.make_map();
        v399_11_cursor.ascend(1);
        let v399_11_head = Path::from_slice(&[v399_11_byte]);
        let v400_2: Space = singleton(&(v399_11_head));
        let v400_3: Space = intersect(&(*CONSTANT_1),&(v400_2));
        let v400_4: Space = if has_head(&(v400_3)) { singleton(&[]) } else { Space::new() };
        drop(v400_3);
        let v400_5: Space = subtract(&(*CONSTANT_0),&(v400_4));
        drop(v400_4);
        let v400_8: Space = if (v400_5).is_empty() { Space::new() } else {
          let v401_6: Path = concat_path(&(v399_6),&(v399_11_head));
          let v401_7: Space = routine_54(c, &(v401_6), &(v399_11_tail));
          compose(&(v400_5),&(v401_7))
        };
        drop(v400_5);
        let v400_9: Space = intersect(&(*CONSTANT_1),&(v400_2));
        drop(v400_2);
        let v400_10: Space = if has_head(&(v400_9)) { singleton(&[]) } else { Space::new() };
        drop(v400_9);
        let v400_12: Space = if (v400_10).is_empty() { Space::new() } else {
          let v402_6: Path = concat_path(&(v399_6),&(v399_11_head));
          let v402_11: Space = routine_14(c, &(v402_6), &(v399_11_tail));
          drop(v402_6);
          compose(&(v400_10),&(v402_11))
        };
        drop(v400_10);
        let v400_13: Space = unite(&(v400_8),&(v400_12));
        v399_11.join_into((v400_13).clone());
      }
      drop(v399_11_cursor);
      drop(v399_6);
      compose(&(v394_10),&(v399_11))
    };
    drop(v394_10);
    let v394_13: Space = unite(&(v394_8),&(v394_12));
    v393_11.join_into((v394_13).clone());
  }
  drop(v393_11_cursor);
  (v393_11).clone()
}

fn routine_45(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v403_8 = Space::new();
  let mut v403_8_cursor = (*s0).read_zipper();
  for v403_8_byte in v403_8_cursor.child_mask().iter() {
    v403_8_cursor.descend_to_byte(v403_8_byte);
    let v403_8_tail = v403_8_cursor.make_map();
    v403_8_cursor.ascend(1);
    let v403_8_head = Path::from_slice(&[v403_8_byte]);
    let v404_2: Space = singleton(&(v403_8_head));
    let v404_3: Space = intersect(&(*CONSTANT_1),&(v404_2));
    let v404_4: Space = if has_head(&(v404_3)) { singleton(&[]) } else { Space::new() };
    drop(v404_3);
    let v404_5: Space = subtract(&(*CONSTANT_0),&(v404_4));
    drop(v404_4);
    let v404_8: Space = if (v404_5).is_empty() { Space::new() } else {
      let v405_6: Path = concat_path(&(*p0),&(v403_8_head));
      let mut v405_7 = Space::new();
      let mut v405_7_cursor = (v403_8_tail).read_zipper();
      for v405_7_byte in v405_7_cursor.child_mask().iter() {
        v405_7_cursor.descend_to_byte(v405_7_byte);
        let v405_7_tail = v405_7_cursor.make_map();
        v405_7_cursor.ascend(1);
        let v405_7_head = Path::from_slice(&[v405_7_byte]);
        let v406_2: Space = singleton(&(v405_7_head));
        let v406_3: Space = intersect(&(*CONSTANT_1),&(v406_2));
        let v406_4: Space = if has_head(&(v406_3)) { singleton(&[]) } else { Space::new() };
        drop(v406_3);
        let v406_5: Space = subtract(&(*CONSTANT_0),&(v406_4));
        drop(v406_4);
        let v406_8: Space = if (v406_5).is_empty() { Space::new() } else {
          let v407_6: Path = concat_path(&(v405_6),&(v405_7_head));
          let v407_7: Space = routine_54(c, &(v407_6), &(v405_7_tail));
          compose(&(v406_5),&(v407_7))
        };
        drop(v406_5);
        let v406_9: Space = intersect(&(*CONSTANT_1),&(v406_2));
        drop(v406_2);
        let v406_10: Space = if has_head(&(v406_9)) { singleton(&[]) } else { Space::new() };
        drop(v406_9);
        let v406_12: Space = if (v406_10).is_empty() { Space::new() } else {
          let v408_6: Path = concat_path(&(v405_6),&(v405_7_head));
          let v408_11: Space = routine_55(c, &(v408_6), &(v405_7_tail));
          drop(v408_6);
          compose(&(v406_10),&(v408_11))
        };
        drop(v406_10);
        let v406_13: Space = unite(&(v406_8),&(v406_12));
        v405_7.join_into((v406_13).clone());
      }
      drop(v405_7_cursor);
      drop(v405_6);
      compose(&(v404_5),&(v405_7))
    };
    drop(v404_5);
    let v404_9: Space = intersect(&(*CONSTANT_1),&(v404_2));
    drop(v404_2);
    let v404_10: Space = if has_head(&(v404_9)) { singleton(&[]) } else { Space::new() };
    drop(v404_9);
    let v404_11: Space = compose(&(v404_10),&(v403_8_tail));
    drop(v404_10);
    let v404_12: Space = unite(&(v404_8),&(v404_11));
    drop(v404_11);
    v403_8.join_into((v404_12).clone());
  }
  drop(v403_8_cursor);
  (v403_8).clone()
}

fn routine_46(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v409_11 = Space::new();
  let mut v409_11_cursor = (*s0).read_zipper();
  for v409_11_byte in v409_11_cursor.child_mask().iter() {
    v409_11_cursor.descend_to_byte(v409_11_byte);
    let v409_11_tail = v409_11_cursor.make_map();
    v409_11_cursor.ascend(1);
    let v409_11_head = Path::from_slice(&[v409_11_byte]);
    let v410_2: Space = singleton(&(v409_11_head));
    let v410_3: Space = intersect(&(*CONSTANT_1),&(v410_2));
    let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
    drop(v410_3);
    let v410_5: Space = subtract(&(*CONSTANT_0),&(v410_4));
    drop(v410_4);
    let v410_8: Space = if (v410_5).is_empty() { Space::new() } else {
      let v411_6: Path = concat_path(&(*p0),&(v409_11_head));
      let mut v411_7 = Space::new();
      let mut v411_7_cursor = (v409_11_tail).read_zipper();
      for v411_7_byte in v411_7_cursor.child_mask().iter() {
        v411_7_cursor.descend_to_byte(v411_7_byte);
        let v411_7_tail = v411_7_cursor.make_map();
        v411_7_cursor.ascend(1);
        let v411_7_head = Path::from_slice(&[v411_7_byte]);
        let v412_2: Space = singleton(&(v411_7_head));
        let v412_3: Space = intersect(&(*CONSTANT_1),&(v412_2));
        let v412_4: Space = if has_head(&(v412_3)) { singleton(&[]) } else { Space::new() };
        drop(v412_3);
        let v412_5: Space = subtract(&(*CONSTANT_0),&(v412_4));
        drop(v412_4);
        let v412_8: Space = if (v412_5).is_empty() { Space::new() } else {
          let v413_6: Path = concat_path(&(v411_6),&(v411_7_head));
          let v413_7: Space = routine_56(c, &(v413_6), &(v411_7_tail));
          compose(&(v412_5),&(v413_7))
        };
        drop(v412_5);
        let v412_9: Space = intersect(&(*CONSTANT_1),&(v412_2));
        drop(v412_2);
        let v412_10: Space = if has_head(&(v412_9)) { singleton(&[]) } else { Space::new() };
        drop(v412_9);
        let v412_12: Space = if (v412_10).is_empty() { Space::new() } else {
          let v414_6: Path = concat_path(&(v411_6),&(v411_7_head));
          let v414_11: Space = routine_57(c, &(v414_6), &(v411_7_tail));
          drop(v414_6);
          compose(&(v412_10),&(v414_11))
        };
        drop(v412_10);
        let v412_13: Space = unite(&(v412_8),&(v412_12));
        v411_7.join_into((v412_13).clone());
      }
      drop(v411_7_cursor);
      compose(&(v410_5),&(v411_7))
    };
    drop(v410_5);
    let v410_9: Space = intersect(&(*CONSTANT_1),&(v410_2));
    drop(v410_2);
    let v410_10: Space = if has_head(&(v410_9)) { singleton(&[]) } else { Space::new() };
    drop(v410_9);
    let v410_12: Space = if (v410_10).is_empty() { Space::new() } else {
      let v415_6: Path = concat_path(&(*p0),&(v409_11_head));
      let mut v415_11 = Space::new();
      let mut v415_11_cursor = (v409_11_tail).read_zipper();
      for v415_11_byte in v415_11_cursor.child_mask().iter() {
        v415_11_cursor.descend_to_byte(v415_11_byte);
        let v415_11_tail = v415_11_cursor.make_map();
        v415_11_cursor.ascend(1);
        let v415_11_head = Path::from_slice(&[v415_11_byte]);
        let v416_2: Space = singleton(&(v415_11_head));
        let v416_3: Space = intersect(&(*CONSTANT_1),&(v416_2));
        let v416_4: Space = if has_head(&(v416_3)) { singleton(&[]) } else { Space::new() };
        drop(v416_3);
        let v416_5: Space = subtract(&(*CONSTANT_0),&(v416_4));
        drop(v416_4);
        let v416_8: Space = if (v416_5).is_empty() { Space::new() } else {
          let v417_6: Path = concat_path(&(v415_6),&(v415_11_head));
          let v417_7: Space = routine_56(c, &(v417_6), &(v415_11_tail));
          compose(&(v416_5),&(v417_7))
        };
        drop(v416_5);
        let v416_9: Space = intersect(&(*CONSTANT_1),&(v416_2));
        drop(v416_2);
        let v416_10: Space = if has_head(&(v416_9)) { singleton(&[]) } else { Space::new() };
        drop(v416_9);
        let v416_12: Space = if (v416_10).is_empty() { Space::new() } else {
          let v418_6: Path = concat_path(&(v415_6),&(v415_11_head));
          let v418_11: Space = routine_17(c, &(v418_6), &(v415_11_tail));
          drop(v418_6);
          compose(&(v416_10),&(v418_11))
        };
        drop(v416_10);
        let v416_13: Space = unite(&(v416_8),&(v416_12));
        v415_11.join_into((v416_13).clone());
      }
      drop(v415_11_cursor);
      drop(v415_6);
      compose(&(v410_10),&(v415_11))
    };
    drop(v410_10);
    let v410_13: Space = unite(&(v410_8),&(v410_12));
    v409_11.join_into((v410_13).clone());
  }
  drop(v409_11_cursor);
  (v409_11).clone()
}

fn routine_47(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v419_8 = Space::new();
  let mut v419_8_cursor = (*s0).read_zipper();
  for v419_8_byte in v419_8_cursor.child_mask().iter() {
    v419_8_cursor.descend_to_byte(v419_8_byte);
    let v419_8_tail = v419_8_cursor.make_map();
    v419_8_cursor.ascend(1);
    let v419_8_head = Path::from_slice(&[v419_8_byte]);
    let v420_2: Space = singleton(&(v419_8_head));
    let v420_3: Space = intersect(&(*CONSTANT_1),&(v420_2));
    let v420_4: Space = if has_head(&(v420_3)) { singleton(&[]) } else { Space::new() };
    drop(v420_3);
    let v420_5: Space = subtract(&(*CONSTANT_0),&(v420_4));
    drop(v420_4);
    let v420_8: Space = if (v420_5).is_empty() { Space::new() } else {
      let v421_6: Path = concat_path(&(*p0),&(v419_8_head));
      let mut v421_7 = Space::new();
      let mut v421_7_cursor = (v419_8_tail).read_zipper();
      for v421_7_byte in v421_7_cursor.child_mask().iter() {
        v421_7_cursor.descend_to_byte(v421_7_byte);
        let v421_7_tail = v421_7_cursor.make_map();
        v421_7_cursor.ascend(1);
        let v421_7_head = Path::from_slice(&[v421_7_byte]);
        let v422_2: Space = singleton(&(v421_7_head));
        let v422_3: Space = intersect(&(*CONSTANT_1),&(v422_2));
        let v422_4: Space = if has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
        drop(v422_3);
        let v422_5: Space = subtract(&(*CONSTANT_0),&(v422_4));
        drop(v422_4);
        let v422_8: Space = if (v422_5).is_empty() { Space::new() } else {
          let v423_6: Path = concat_path(&(v421_6),&(v421_7_head));
          let v423_7: Space = routine_56(c, &(v423_6), &(v421_7_tail));
          compose(&(v422_5),&(v423_7))
        };
        drop(v422_5);
        let v422_9: Space = intersect(&(*CONSTANT_1),&(v422_2));
        drop(v422_2);
        let v422_10: Space = if has_head(&(v422_9)) { singleton(&[]) } else { Space::new() };
        drop(v422_9);
        let v422_12: Space = if (v422_10).is_empty() { Space::new() } else {
          let v424_6: Path = concat_path(&(v421_6),&(v421_7_head));
          let v424_11: Space = routine_57(c, &(v424_6), &(v421_7_tail));
          drop(v424_6);
          compose(&(v422_10),&(v424_11))
        };
        drop(v422_10);
        let v422_13: Space = unite(&(v422_8),&(v422_12));
        v421_7.join_into((v422_13).clone());
      }
      drop(v421_7_cursor);
      drop(v421_6);
      compose(&(v420_5),&(v421_7))
    };
    drop(v420_5);
    let v420_9: Space = intersect(&(*CONSTANT_1),&(v420_2));
    drop(v420_2);
    let v420_10: Space = if has_head(&(v420_9)) { singleton(&[]) } else { Space::new() };
    drop(v420_9);
    let v420_11: Space = compose(&(v420_10),&(v419_8_tail));
    drop(v420_10);
    let v420_12: Space = unite(&(v420_8),&(v420_11));
    drop(v420_11);
    v419_8.join_into((v420_12).clone());
  }
  drop(v419_8_cursor);
  (v419_8).clone()
}

fn routine_48(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v425_11 = Space::new();
  let mut v425_11_cursor = (*s0).read_zipper();
  for v425_11_byte in v425_11_cursor.child_mask().iter() {
    v425_11_cursor.descend_to_byte(v425_11_byte);
    let v425_11_tail = v425_11_cursor.make_map();
    v425_11_cursor.ascend(1);
    let v425_11_head = Path::from_slice(&[v425_11_byte]);
    let v426_2: Space = singleton(&(v425_11_head));
    let v426_3: Space = intersect(&(*CONSTANT_1),&(v426_2));
    let v426_4: Space = if has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
    drop(v426_3);
    let v426_5: Space = subtract(&(*CONSTANT_0),&(v426_4));
    drop(v426_4);
    let v426_8: Space = if (v426_5).is_empty() { Space::new() } else {
      let v427_6: Path = concat_path(&(*p0),&(v425_11_head));
      let mut v427_7 = Space::new();
      let mut v427_7_cursor = (v425_11_tail).read_zipper();
      for v427_7_byte in v427_7_cursor.child_mask().iter() {
        v427_7_cursor.descend_to_byte(v427_7_byte);
        let v427_7_tail = v427_7_cursor.make_map();
        v427_7_cursor.ascend(1);
        let v427_7_head = Path::from_slice(&[v427_7_byte]);
        let v428_2: Space = singleton(&(v427_7_head));
        let v428_3: Space = intersect(&(*CONSTANT_1),&(v428_2));
        let v428_4: Space = if has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
        drop(v428_3);
        let v428_5: Space = subtract(&(*CONSTANT_0),&(v428_4));
        drop(v428_4);
        let v428_8: Space = if (v428_5).is_empty() { Space::new() } else {
          let v429_6: Path = concat_path(&(v427_6),&(v427_7_head));
          let v429_7: Space = routine_58(c, &(v429_6), &(v427_7_tail));
          compose(&(v428_5),&(v429_7))
        };
        drop(v428_5);
        let v428_9: Space = intersect(&(*CONSTANT_1),&(v428_2));
        drop(v428_2);
        let v428_10: Space = if has_head(&(v428_9)) { singleton(&[]) } else { Space::new() };
        drop(v428_9);
        let v428_12: Space = if (v428_10).is_empty() { Space::new() } else {
          let v430_6: Path = concat_path(&(v427_6),&(v427_7_head));
          let v430_11: Space = routine_59(c, &(v430_6), &(v427_7_tail));
          drop(v430_6);
          compose(&(v428_10),&(v430_11))
        };
        drop(v428_10);
        let v428_13: Space = unite(&(v428_8),&(v428_12));
        v427_7.join_into((v428_13).clone());
      }
      drop(v427_7_cursor);
      compose(&(v426_5),&(v427_7))
    };
    drop(v426_5);
    let v426_9: Space = intersect(&(*CONSTANT_1),&(v426_2));
    drop(v426_2);
    let v426_10: Space = if has_head(&(v426_9)) { singleton(&[]) } else { Space::new() };
    drop(v426_9);
    let v426_12: Space = if (v426_10).is_empty() { Space::new() } else {
      let v431_6: Path = concat_path(&(*p0),&(v425_11_head));
      let mut v431_11 = Space::new();
      let mut v431_11_cursor = (v425_11_tail).read_zipper();
      for v431_11_byte in v431_11_cursor.child_mask().iter() {
        v431_11_cursor.descend_to_byte(v431_11_byte);
        let v431_11_tail = v431_11_cursor.make_map();
        v431_11_cursor.ascend(1);
        let v431_11_head = Path::from_slice(&[v431_11_byte]);
        let v432_2: Space = singleton(&(v431_11_head));
        let v432_3: Space = intersect(&(*CONSTANT_1),&(v432_2));
        let v432_4: Space = if has_head(&(v432_3)) { singleton(&[]) } else { Space::new() };
        drop(v432_3);
        let v432_5: Space = subtract(&(*CONSTANT_0),&(v432_4));
        drop(v432_4);
        let v432_8: Space = if (v432_5).is_empty() { Space::new() } else {
          let v433_6: Path = concat_path(&(v431_6),&(v431_11_head));
          let v433_7: Space = routine_58(c, &(v433_6), &(v431_11_tail));
          compose(&(v432_5),&(v433_7))
        };
        drop(v432_5);
        let v432_9: Space = intersect(&(*CONSTANT_1),&(v432_2));
        drop(v432_2);
        let v432_10: Space = if has_head(&(v432_9)) { singleton(&[]) } else { Space::new() };
        drop(v432_9);
        let v432_12: Space = if (v432_10).is_empty() { Space::new() } else {
          let v434_6: Path = concat_path(&(v431_6),&(v431_11_head));
          let v434_11: Space = routine_14(c, &(v434_6), &(v431_11_tail));
          drop(v434_6);
          compose(&(v432_10),&(v434_11))
        };
        drop(v432_10);
        let v432_13: Space = unite(&(v432_8),&(v432_12));
        v431_11.join_into((v432_13).clone());
      }
      drop(v431_11_cursor);
      drop(v431_6);
      compose(&(v426_10),&(v431_11))
    };
    drop(v426_10);
    let v426_13: Space = unite(&(v426_8),&(v426_12));
    v425_11.join_into((v426_13).clone());
  }
  drop(v425_11_cursor);
  (v425_11).clone()
}

fn routine_49(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v435_8 = Space::new();
  let mut v435_8_cursor = (*s0).read_zipper();
  for v435_8_byte in v435_8_cursor.child_mask().iter() {
    v435_8_cursor.descend_to_byte(v435_8_byte);
    let v435_8_tail = v435_8_cursor.make_map();
    v435_8_cursor.ascend(1);
    let v435_8_head = Path::from_slice(&[v435_8_byte]);
    let v436_2: Space = singleton(&(v435_8_head));
    let v436_3: Space = intersect(&(*CONSTANT_1),&(v436_2));
    let v436_4: Space = if has_head(&(v436_3)) { singleton(&[]) } else { Space::new() };
    drop(v436_3);
    let v436_5: Space = subtract(&(*CONSTANT_0),&(v436_4));
    drop(v436_4);
    let v436_8: Space = if (v436_5).is_empty() { Space::new() } else {
      let v437_6: Path = concat_path(&(*p0),&(v435_8_head));
      let mut v437_7 = Space::new();
      let mut v437_7_cursor = (v435_8_tail).read_zipper();
      for v437_7_byte in v437_7_cursor.child_mask().iter() {
        v437_7_cursor.descend_to_byte(v437_7_byte);
        let v437_7_tail = v437_7_cursor.make_map();
        v437_7_cursor.ascend(1);
        let v437_7_head = Path::from_slice(&[v437_7_byte]);
        let v438_2: Space = singleton(&(v437_7_head));
        let v438_3: Space = intersect(&(*CONSTANT_1),&(v438_2));
        let v438_4: Space = if has_head(&(v438_3)) { singleton(&[]) } else { Space::new() };
        drop(v438_3);
        let v438_5: Space = subtract(&(*CONSTANT_0),&(v438_4));
        drop(v438_4);
        let v438_8: Space = if (v438_5).is_empty() { Space::new() } else {
          let v439_6: Path = concat_path(&(v437_6),&(v437_7_head));
          let v439_7: Space = routine_58(c, &(v439_6), &(v437_7_tail));
          compose(&(v438_5),&(v439_7))
        };
        drop(v438_5);
        let v438_9: Space = intersect(&(*CONSTANT_1),&(v438_2));
        drop(v438_2);
        let v438_10: Space = if has_head(&(v438_9)) { singleton(&[]) } else { Space::new() };
        drop(v438_9);
        let v438_12: Space = if (v438_10).is_empty() { Space::new() } else {
          let v440_6: Path = concat_path(&(v437_6),&(v437_7_head));
          let v440_11: Space = routine_59(c, &(v440_6), &(v437_7_tail));
          drop(v440_6);
          compose(&(v438_10),&(v440_11))
        };
        drop(v438_10);
        let v438_13: Space = unite(&(v438_8),&(v438_12));
        v437_7.join_into((v438_13).clone());
      }
      drop(v437_7_cursor);
      drop(v437_6);
      compose(&(v436_5),&(v437_7))
    };
    drop(v436_5);
    let v436_9: Space = intersect(&(*CONSTANT_1),&(v436_2));
    drop(v436_2);
    let v436_10: Space = if has_head(&(v436_9)) { singleton(&[]) } else { Space::new() };
    drop(v436_9);
    let v436_11: Space = compose(&(v436_10),&(v435_8_tail));
    drop(v436_10);
    let v436_12: Space = unite(&(v436_8),&(v436_11));
    drop(v436_11);
    v435_8.join_into((v436_12).clone());
  }
  drop(v435_8_cursor);
  (v435_8).clone()
}

fn routine_50(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v441_11 = Space::new();
  let mut v441_11_cursor = (*s0).read_zipper();
  for v441_11_byte in v441_11_cursor.child_mask().iter() {
    v441_11_cursor.descend_to_byte(v441_11_byte);
    let v441_11_tail = v441_11_cursor.make_map();
    v441_11_cursor.ascend(1);
    let v441_11_head = Path::from_slice(&[v441_11_byte]);
    let v442_2: Space = singleton(&(v441_11_head));
    let v442_3: Space = intersect(&(*CONSTANT_1),&(v442_2));
    let v442_4: Space = if has_head(&(v442_3)) { singleton(&[]) } else { Space::new() };
    drop(v442_3);
    let v442_5: Space = subtract(&(*CONSTANT_0),&(v442_4));
    drop(v442_4);
    let v442_8: Space = if (v442_5).is_empty() { Space::new() } else {
      let v443_6: Path = concat_path(&(*p0),&(v441_11_head));
      let mut v443_7 = Space::new();
      let mut v443_7_cursor = (v441_11_tail).read_zipper();
      for v443_7_byte in v443_7_cursor.child_mask().iter() {
        v443_7_cursor.descend_to_byte(v443_7_byte);
        let v443_7_tail = v443_7_cursor.make_map();
        v443_7_cursor.ascend(1);
        let v443_7_head = Path::from_slice(&[v443_7_byte]);
        let v444_2: Space = singleton(&(v443_7_head));
        let v444_3: Space = intersect(&(*CONSTANT_1),&(v444_2));
        let v444_4: Space = if has_head(&(v444_3)) { singleton(&[]) } else { Space::new() };
        drop(v444_3);
        let v444_5: Space = subtract(&(*CONSTANT_0),&(v444_4));
        drop(v444_4);
        let v444_8: Space = if (v444_5).is_empty() { Space::new() } else {
          let v445_6: Path = concat_path(&(v443_6),&(v443_7_head));
          let v445_7: Space = routine_60(c, &(v445_6), &(v443_7_tail));
          compose(&(v444_5),&(v445_7))
        };
        drop(v444_5);
        let v444_9: Space = intersect(&(*CONSTANT_1),&(v444_2));
        drop(v444_2);
        let v444_10: Space = if has_head(&(v444_9)) { singleton(&[]) } else { Space::new() };
        drop(v444_9);
        let v444_12: Space = if (v444_10).is_empty() { Space::new() } else {
          let v446_6: Path = concat_path(&(v443_6),&(v443_7_head));
          let v446_11: Space = routine_61(c, &(v446_6), &(v443_7_tail));
          drop(v446_6);
          compose(&(v444_10),&(v446_11))
        };
        drop(v444_10);
        let v444_13: Space = unite(&(v444_8),&(v444_12));
        v443_7.join_into((v444_13).clone());
      }
      drop(v443_7_cursor);
      compose(&(v442_5),&(v443_7))
    };
    drop(v442_5);
    let v442_9: Space = intersect(&(*CONSTANT_1),&(v442_2));
    drop(v442_2);
    let v442_10: Space = if has_head(&(v442_9)) { singleton(&[]) } else { Space::new() };
    drop(v442_9);
    let v442_12: Space = if (v442_10).is_empty() { Space::new() } else {
      let v447_6: Path = concat_path(&(*p0),&(v441_11_head));
      let mut v447_11 = Space::new();
      let mut v447_11_cursor = (v441_11_tail).read_zipper();
      for v447_11_byte in v447_11_cursor.child_mask().iter() {
        v447_11_cursor.descend_to_byte(v447_11_byte);
        let v447_11_tail = v447_11_cursor.make_map();
        v447_11_cursor.ascend(1);
        let v447_11_head = Path::from_slice(&[v447_11_byte]);
        let v448_2: Space = singleton(&(v447_11_head));
        let v448_3: Space = intersect(&(*CONSTANT_1),&(v448_2));
        let v448_4: Space = if has_head(&(v448_3)) { singleton(&[]) } else { Space::new() };
        drop(v448_3);
        let v448_5: Space = subtract(&(*CONSTANT_0),&(v448_4));
        drop(v448_4);
        let v448_8: Space = if (v448_5).is_empty() { Space::new() } else {
          let v449_6: Path = concat_path(&(v447_6),&(v447_11_head));
          let v449_7: Space = routine_60(c, &(v449_6), &(v447_11_tail));
          compose(&(v448_5),&(v449_7))
        };
        drop(v448_5);
        let v448_9: Space = intersect(&(*CONSTANT_1),&(v448_2));
        drop(v448_2);
        let v448_10: Space = if has_head(&(v448_9)) { singleton(&[]) } else { Space::new() };
        drop(v448_9);
        let v448_12: Space = if (v448_10).is_empty() { Space::new() } else {
          let v450_6: Path = concat_path(&(v447_6),&(v447_11_head));
          let v450_11: Space = routine_17(c, &(v450_6), &(v447_11_tail));
          drop(v450_6);
          compose(&(v448_10),&(v450_11))
        };
        drop(v448_10);
        let v448_13: Space = unite(&(v448_8),&(v448_12));
        v447_11.join_into((v448_13).clone());
      }
      drop(v447_11_cursor);
      drop(v447_6);
      compose(&(v442_10),&(v447_11))
    };
    drop(v442_10);
    let v442_13: Space = unite(&(v442_8),&(v442_12));
    v441_11.join_into((v442_13).clone());
  }
  drop(v441_11_cursor);
  (v441_11).clone()
}

fn routine_51(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v451_8 = Space::new();
  let mut v451_8_cursor = (*s0).read_zipper();
  for v451_8_byte in v451_8_cursor.child_mask().iter() {
    v451_8_cursor.descend_to_byte(v451_8_byte);
    let v451_8_tail = v451_8_cursor.make_map();
    v451_8_cursor.ascend(1);
    let v451_8_head = Path::from_slice(&[v451_8_byte]);
    let v452_2: Space = singleton(&(v451_8_head));
    let v452_3: Space = intersect(&(*CONSTANT_1),&(v452_2));
    let v452_4: Space = if has_head(&(v452_3)) { singleton(&[]) } else { Space::new() };
    drop(v452_3);
    let v452_5: Space = subtract(&(*CONSTANT_0),&(v452_4));
    drop(v452_4);
    let v452_8: Space = if (v452_5).is_empty() { Space::new() } else {
      let v453_6: Path = concat_path(&(*p0),&(v451_8_head));
      let mut v453_7 = Space::new();
      let mut v453_7_cursor = (v451_8_tail).read_zipper();
      for v453_7_byte in v453_7_cursor.child_mask().iter() {
        v453_7_cursor.descend_to_byte(v453_7_byte);
        let v453_7_tail = v453_7_cursor.make_map();
        v453_7_cursor.ascend(1);
        let v453_7_head = Path::from_slice(&[v453_7_byte]);
        let v454_2: Space = singleton(&(v453_7_head));
        let v454_3: Space = intersect(&(*CONSTANT_1),&(v454_2));
        let v454_4: Space = if has_head(&(v454_3)) { singleton(&[]) } else { Space::new() };
        drop(v454_3);
        let v454_5: Space = subtract(&(*CONSTANT_0),&(v454_4));
        drop(v454_4);
        let v454_8: Space = if (v454_5).is_empty() { Space::new() } else {
          let v455_6: Path = concat_path(&(v453_6),&(v453_7_head));
          let v455_7: Space = routine_60(c, &(v455_6), &(v453_7_tail));
          compose(&(v454_5),&(v455_7))
        };
        drop(v454_5);
        let v454_9: Space = intersect(&(*CONSTANT_1),&(v454_2));
        drop(v454_2);
        let v454_10: Space = if has_head(&(v454_9)) { singleton(&[]) } else { Space::new() };
        drop(v454_9);
        let v454_12: Space = if (v454_10).is_empty() { Space::new() } else {
          let v456_6: Path = concat_path(&(v453_6),&(v453_7_head));
          let v456_11: Space = routine_61(c, &(v456_6), &(v453_7_tail));
          drop(v456_6);
          compose(&(v454_10),&(v456_11))
        };
        drop(v454_10);
        let v454_13: Space = unite(&(v454_8),&(v454_12));
        v453_7.join_into((v454_13).clone());
      }
      drop(v453_7_cursor);
      drop(v453_6);
      compose(&(v452_5),&(v453_7))
    };
    drop(v452_5);
    let v452_9: Space = intersect(&(*CONSTANT_1),&(v452_2));
    drop(v452_2);
    let v452_10: Space = if has_head(&(v452_9)) { singleton(&[]) } else { Space::new() };
    drop(v452_9);
    let v452_11: Space = compose(&(v452_10),&(v451_8_tail));
    drop(v452_10);
    let v452_12: Space = unite(&(v452_8),&(v452_11));
    drop(v452_11);
    v451_8.join_into((v452_12).clone());
  }
  drop(v451_8_cursor);
  (v451_8).clone()
}

fn routine_52(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v457_7 = Space::new();
  let mut v457_7_cursor = (*s0).read_zipper();
  for v457_7_byte in v457_7_cursor.child_mask().iter() {
    v457_7_cursor.descend_to_byte(v457_7_byte);
    let v457_7_tail = v457_7_cursor.make_map();
    v457_7_cursor.ascend(1);
    let v457_7_head = Path::from_slice(&[v457_7_byte]);
    let v458_2: Space = singleton(&(v457_7_head));
    let v458_3: Space = intersect(&(*CONSTANT_1),&(v458_2));
    let v458_4: Space = if has_head(&(v458_3)) { singleton(&[]) } else { Space::new() };
    drop(v458_3);
    let v458_5: Space = subtract(&(*CONSTANT_0),&(v458_4));
    drop(v458_4);
    let mut v458_6 = Space::new();
    let mut v458_6_cursor = (v457_7_tail).read_zipper();
    for v458_6_byte in v458_6_cursor.child_mask().iter() {
      v458_6_cursor.descend_to_byte(v458_6_byte);
      let v458_6_tail = v458_6_cursor.make_map();
      v458_6_cursor.ascend(1);
      let v458_6_head = Path::from_slice(&[v458_6_byte]);
      let v459_2: Space = Space::new();
      v458_6.join_into((v459_2).clone());
    }
    drop(v458_6_cursor);
    let v458_7: Space = compose(&(v458_5),&(v458_6));
    drop(v458_5);
    drop(v458_6);
    let v458_8: Space = intersect(&(*CONSTANT_1),&(v458_2));
    drop(v458_2);
    let v458_9: Space = if has_head(&(v458_8)) { singleton(&[]) } else { Space::new() };
    drop(v458_8);
    let v458_12: Space = if (v458_9).is_empty() { Space::new() } else {
      let v460_10: Path = concat_path(&(*p0),&(v457_7_head));
      let mut v460_11 = Space::new();
      let mut v460_11_cursor = (v457_7_tail).read_zipper();
      for v460_11_byte in v460_11_cursor.child_mask().iter() {
        v460_11_cursor.descend_to_byte(v460_11_byte);
        let v460_11_tail = v460_11_cursor.make_map();
        v460_11_cursor.ascend(1);
        let v460_11_head = Path::from_slice(&[v460_11_byte]);
        let v461_2: Space = singleton(&(v460_11_head));
        let v461_3: Space = intersect(&(*CONSTANT_1),&(v461_2));
        drop(v461_2);
        let v461_4: Space = if has_head(&(v461_3)) { singleton(&[]) } else { Space::new() };
        drop(v461_3);
        let v461_7: Space = if (v461_4).is_empty() { Space::new() } else {
          let v462_5: Path = concat_path(&(v460_10),&(v460_11_head));
          let v462_6: Space = routine_5(c, &(v462_5), &(v460_11_tail), &(*s1));
          drop(v462_5);
          compose(&(v461_4),&(v462_6))
        };
        drop(v461_4);
        v460_11.join_into((v461_7).clone());
      }
      drop(v460_11_cursor);
      drop(v460_10);
      compose(&(v458_9),&(v460_11))
    };
    drop(v458_9);
    let v458_13: Space = unite(&(v458_7),&(v458_12));
    drop(v458_7);
    v457_7.join_into((v458_13).clone());
  }
  drop(v457_7_cursor);
  (v457_7).clone()
}

fn routine_53(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v463_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v463_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v463_10: Space = unwrap(&(v463_9),&(*p0));
  let v463_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v463_19 = Space::new();
  let mut v463_19_cursor = (*s0).read_zipper();
  for v463_19_byte in v463_19_cursor.child_mask().iter() {
    v463_19_cursor.descend_to_byte(v463_19_byte);
    let v463_19_tail = v463_19_cursor.make_map();
    v463_19_cursor.ascend(1);
    let v463_19_head = Path::from_slice(&[v463_19_byte]);
    let v464_2: Space = singleton(&(v463_19_head));
    let v464_3: Space = intersect(&(*CONSTANT_1),&(v464_2));
    let v464_4: Space = if has_head(&(v464_3)) { singleton(&[]) } else { Space::new() };
    drop(v464_3);
    let v464_5: Space = subtract(&(*CONSTANT_0),&(v464_4));
    drop(v464_4);
    let mut v464_6 = Space::new();
    let mut v464_6_cursor = (v463_19_tail).read_zipper();
    for v464_6_byte in v464_6_cursor.child_mask().iter() {
      v464_6_cursor.descend_to_byte(v464_6_byte);
      let v464_6_tail = v464_6_cursor.make_map();
      v464_6_cursor.ascend(1);
      let v464_6_head = Path::from_slice(&[v464_6_byte]);
      let v465_2: Space = Space::new();
      v464_6.join_into((v465_2).clone());
    }
    drop(v464_6_cursor);
    let v464_7: Space = compose(&(v464_5),&(v464_6));
    drop(v464_5);
    drop(v464_6);
    let v464_8: Space = intersect(&(*CONSTANT_1),&(v464_2));
    drop(v464_2);
    let v464_9: Space = if has_head(&(v464_8)) { singleton(&[]) } else { Space::new() };
    drop(v464_8);
    let v464_17: Space = if (v464_9).is_empty() { Space::new() } else {
      let v466_10: Space = unwrap(&(v463_10),&(v463_19_head));
      let v466_11: Space = restrict_to(&(v463_9),&(v466_10));
      let mut v466_12 = Space::new();
      let mut v466_12_cursor = (v466_11).read_zipper();
      for v466_12_byte in v466_12_cursor.child_mask().iter() {
        v466_12_cursor.descend_to_byte(v466_12_byte);
        let v466_12_tail = v466_12_cursor.make_map();
        v466_12_cursor.ascend(1);
        let v466_12_head = Path::from_slice(&[v466_12_byte]);
        let v467_2: Space = singleton(&(v466_12_head));
        let v467_3: Space = intersect(&(*CONSTANT_1),&(v467_2));
        let v467_4: Space = if has_head(&(v467_3)) { singleton(&[]) } else { Space::new() };
        drop(v467_3);
        let v467_5: Space = subtract(&(*CONSTANT_0),&(v467_4));
        drop(v467_4);
        let v467_7: Space = if (v467_5).is_empty() { Space::new() } else {
          let v468_6: Space = routine_6(c, &(v466_12_head), &(v466_12_tail));
          compose(&(v467_5),&(v468_6))
        };
        drop(v467_5);
        let v467_8: Space = intersect(&(*CONSTANT_1),&(v467_2));
        drop(v467_2);
        let v467_9: Space = if has_head(&(v467_8)) { singleton(&[]) } else { Space::new() };
        drop(v467_8);
        let v467_11: Space = if (v467_9).is_empty() { Space::new() } else {
          let v469_10: Space = routine_7(c, &(v466_12_head), &(v466_12_tail));
          compose(&(v467_9),&(v469_10))
        };
        drop(v467_9);
        let v467_12: Space = unite(&(v467_7),&(v467_11));
        v466_12.join_into((v467_12).clone());
      }
      drop(v466_12_cursor);
      drop(v466_11);
      let v466_13: Space = restrict_to(&(v463_7),&(v466_12));
      let mut v466_14 = Space::new();
      let mut v466_14_cursor = (v466_13).read_zipper();
      for v466_14_byte in v466_14_cursor.child_mask().iter() {
        v466_14_cursor.descend_to_byte(v466_14_byte);
        let v466_14_tail = v466_14_cursor.make_map();
        v466_14_cursor.ascend(1);
        let v466_14_head = Path::from_slice(&[v466_14_byte]);
        let v470_2: Space = singleton(&(v466_14_head));
        let v470_3: Space = intersect(&(*CONSTANT_1),&(v470_2));
        let v470_4: Space = if has_head(&(v470_3)) { singleton(&[]) } else { Space::new() };
        drop(v470_3);
        let v470_5: Space = subtract(&(*CONSTANT_0),&(v470_4));
        drop(v470_4);
        let v470_7: Space = if (v470_5).is_empty() { Space::new() } else {
          let v471_6: Space = routine_8(c, &(v466_14_head), &(v466_14_tail));
          compose(&(v470_5),&(v471_6))
        };
        drop(v470_5);
        let v470_8: Space = intersect(&(*CONSTANT_1),&(v470_2));
        drop(v470_2);
        let v470_9: Space = if has_head(&(v470_8)) { singleton(&[]) } else { Space::new() };
        drop(v470_8);
        let v470_11: Space = if (v470_9).is_empty() { Space::new() } else {
          let v472_10: Space = routine_9(c, &(v466_14_head), &(v466_14_tail));
          compose(&(v470_9),&(v472_10))
        };
        drop(v470_9);
        let v470_12: Space = unite(&(v470_7),&(v470_11));
        v466_14.join_into((v470_12).clone());
      }
      drop(v466_14_cursor);
      let v466_15: Space = subtract(&(v466_14),&(v466_10));
      drop(v466_10);
      let v466_16: Space = intersect(&(v466_15),&(v463_12));
      compose(&(v464_9),&(v466_16))
    };
    drop(v464_9);
    let v464_18: Path = concat_path(&(*p0),&(v463_19_head));
    let v464_19: Space = wrap(&(v464_17),&(v464_18));
    drop(v464_18);
    let v464_20: Space = unite(&(v464_7),&(v464_19));
    drop(v464_7);
    v463_19.join_into((v464_20).clone());
  }
  drop(v463_19_cursor);
  drop(v463_7);
  drop(v463_9);
  drop(v463_10);
  drop(v463_12);
  (v463_19).clone()
}

fn routine_54(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v473_11 = Space::new();
  let mut v473_11_cursor = (*s0).read_zipper();
  for v473_11_byte in v473_11_cursor.child_mask().iter() {
    v473_11_cursor.descend_to_byte(v473_11_byte);
    let v473_11_tail = v473_11_cursor.make_map();
    v473_11_cursor.ascend(1);
    let v473_11_head = Path::from_slice(&[v473_11_byte]);
    let v474_2: Space = singleton(&(v473_11_head));
    let v474_3: Space = intersect(&(*CONSTANT_1),&(v474_2));
    let v474_4: Space = if has_head(&(v474_3)) { singleton(&[]) } else { Space::new() };
    drop(v474_3);
    let v474_5: Space = subtract(&(*CONSTANT_0),&(v474_4));
    drop(v474_4);
    let v474_8: Space = if (v474_5).is_empty() { Space::new() } else {
      let v475_6: Path = concat_path(&(*p0),&(v473_11_head));
      let mut v475_7 = Space::new();
      let mut v475_7_cursor = (v473_11_tail).read_zipper();
      for v475_7_byte in v475_7_cursor.child_mask().iter() {
        v475_7_cursor.descend_to_byte(v475_7_byte);
        let v475_7_tail = v475_7_cursor.make_map();
        v475_7_cursor.ascend(1);
        let v475_7_head = Path::from_slice(&[v475_7_byte]);
        let v476_2: Space = singleton(&(v475_7_head));
        let v476_3: Space = intersect(&(*CONSTANT_1),&(v476_2));
        let v476_4: Space = if has_head(&(v476_3)) { singleton(&[]) } else { Space::new() };
        drop(v476_3);
        let v476_5: Space = subtract(&(*CONSTANT_0),&(v476_4));
        drop(v476_4);
        let v476_8: Space = if (v476_5).is_empty() { Space::new() } else {
          let v477_6: Path = concat_path(&(v475_6),&(v475_7_head));
          let v477_7: Space = routine_62(c, &(v477_6), &(v475_7_tail));
          compose(&(v476_5),&(v477_7))
        };
        drop(v476_5);
        let v476_9: Space = intersect(&(*CONSTANT_1),&(v476_2));
        drop(v476_2);
        let v476_10: Space = if has_head(&(v476_9)) { singleton(&[]) } else { Space::new() };
        drop(v476_9);
        let v476_12: Space = if (v476_10).is_empty() { Space::new() } else {
          let v478_6: Path = concat_path(&(v475_6),&(v475_7_head));
          let v478_11: Space = routine_63(c, &(v478_6), &(v475_7_tail));
          drop(v478_6);
          compose(&(v476_10),&(v478_11))
        };
        drop(v476_10);
        let v476_13: Space = unite(&(v476_8),&(v476_12));
        v475_7.join_into((v476_13).clone());
      }
      drop(v475_7_cursor);
      compose(&(v474_5),&(v475_7))
    };
    drop(v474_5);
    let v474_9: Space = intersect(&(*CONSTANT_1),&(v474_2));
    drop(v474_2);
    let v474_10: Space = if has_head(&(v474_9)) { singleton(&[]) } else { Space::new() };
    drop(v474_9);
    let v474_12: Space = if (v474_10).is_empty() { Space::new() } else {
      let v479_6: Path = concat_path(&(*p0),&(v473_11_head));
      let mut v479_11 = Space::new();
      let mut v479_11_cursor = (v473_11_tail).read_zipper();
      for v479_11_byte in v479_11_cursor.child_mask().iter() {
        v479_11_cursor.descend_to_byte(v479_11_byte);
        let v479_11_tail = v479_11_cursor.make_map();
        v479_11_cursor.ascend(1);
        let v479_11_head = Path::from_slice(&[v479_11_byte]);
        let v480_2: Space = singleton(&(v479_11_head));
        let v480_3: Space = intersect(&(*CONSTANT_1),&(v480_2));
        let v480_4: Space = if has_head(&(v480_3)) { singleton(&[]) } else { Space::new() };
        drop(v480_3);
        let v480_5: Space = subtract(&(*CONSTANT_0),&(v480_4));
        drop(v480_4);
        let v480_8: Space = if (v480_5).is_empty() { Space::new() } else {
          let v481_6: Path = concat_path(&(v479_6),&(v479_11_head));
          let v481_7: Space = routine_62(c, &(v481_6), &(v479_11_tail));
          compose(&(v480_5),&(v481_7))
        };
        drop(v480_5);
        let v480_9: Space = intersect(&(*CONSTANT_1),&(v480_2));
        drop(v480_2);
        let v480_10: Space = if has_head(&(v480_9)) { singleton(&[]) } else { Space::new() };
        drop(v480_9);
        let v480_12: Space = if (v480_10).is_empty() { Space::new() } else {
          let v482_6: Path = concat_path(&(v479_6),&(v479_11_head));
          let v482_11: Space = routine_14(c, &(v482_6), &(v479_11_tail));
          drop(v482_6);
          compose(&(v480_10),&(v482_11))
        };
        drop(v480_10);
        let v480_13: Space = unite(&(v480_8),&(v480_12));
        v479_11.join_into((v480_13).clone());
      }
      drop(v479_11_cursor);
      drop(v479_6);
      compose(&(v474_10),&(v479_11))
    };
    drop(v474_10);
    let v474_13: Space = unite(&(v474_8),&(v474_12));
    v473_11.join_into((v474_13).clone());
  }
  drop(v473_11_cursor);
  (v473_11).clone()
}

fn routine_55(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v483_8 = Space::new();
  let mut v483_8_cursor = (*s0).read_zipper();
  for v483_8_byte in v483_8_cursor.child_mask().iter() {
    v483_8_cursor.descend_to_byte(v483_8_byte);
    let v483_8_tail = v483_8_cursor.make_map();
    v483_8_cursor.ascend(1);
    let v483_8_head = Path::from_slice(&[v483_8_byte]);
    let v484_2: Space = singleton(&(v483_8_head));
    let v484_3: Space = intersect(&(*CONSTANT_1),&(v484_2));
    let v484_4: Space = if has_head(&(v484_3)) { singleton(&[]) } else { Space::new() };
    drop(v484_3);
    let v484_5: Space = subtract(&(*CONSTANT_0),&(v484_4));
    drop(v484_4);
    let v484_8: Space = if (v484_5).is_empty() { Space::new() } else {
      let v485_6: Path = concat_path(&(*p0),&(v483_8_head));
      let mut v485_7 = Space::new();
      let mut v485_7_cursor = (v483_8_tail).read_zipper();
      for v485_7_byte in v485_7_cursor.child_mask().iter() {
        v485_7_cursor.descend_to_byte(v485_7_byte);
        let v485_7_tail = v485_7_cursor.make_map();
        v485_7_cursor.ascend(1);
        let v485_7_head = Path::from_slice(&[v485_7_byte]);
        let v486_2: Space = singleton(&(v485_7_head));
        let v486_3: Space = intersect(&(*CONSTANT_1),&(v486_2));
        let v486_4: Space = if has_head(&(v486_3)) { singleton(&[]) } else { Space::new() };
        drop(v486_3);
        let v486_5: Space = subtract(&(*CONSTANT_0),&(v486_4));
        drop(v486_4);
        let v486_8: Space = if (v486_5).is_empty() { Space::new() } else {
          let v487_6: Path = concat_path(&(v485_6),&(v485_7_head));
          let v487_7: Space = routine_62(c, &(v487_6), &(v485_7_tail));
          compose(&(v486_5),&(v487_7))
        };
        drop(v486_5);
        let v486_9: Space = intersect(&(*CONSTANT_1),&(v486_2));
        drop(v486_2);
        let v486_10: Space = if has_head(&(v486_9)) { singleton(&[]) } else { Space::new() };
        drop(v486_9);
        let v486_12: Space = if (v486_10).is_empty() { Space::new() } else {
          let v488_6: Path = concat_path(&(v485_6),&(v485_7_head));
          let v488_11: Space = routine_63(c, &(v488_6), &(v485_7_tail));
          drop(v488_6);
          compose(&(v486_10),&(v488_11))
        };
        drop(v486_10);
        let v486_13: Space = unite(&(v486_8),&(v486_12));
        v485_7.join_into((v486_13).clone());
      }
      drop(v485_7_cursor);
      drop(v485_6);
      compose(&(v484_5),&(v485_7))
    };
    drop(v484_5);
    let v484_9: Space = intersect(&(*CONSTANT_1),&(v484_2));
    drop(v484_2);
    let v484_10: Space = if has_head(&(v484_9)) { singleton(&[]) } else { Space::new() };
    drop(v484_9);
    let v484_11: Space = compose(&(v484_10),&(v483_8_tail));
    drop(v484_10);
    let v484_12: Space = unite(&(v484_8),&(v484_11));
    drop(v484_11);
    v483_8.join_into((v484_12).clone());
  }
  drop(v483_8_cursor);
  (v483_8).clone()
}

fn routine_56(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v489_11 = Space::new();
  let mut v489_11_cursor = (*s0).read_zipper();
  for v489_11_byte in v489_11_cursor.child_mask().iter() {
    v489_11_cursor.descend_to_byte(v489_11_byte);
    let v489_11_tail = v489_11_cursor.make_map();
    v489_11_cursor.ascend(1);
    let v489_11_head = Path::from_slice(&[v489_11_byte]);
    let v490_2: Space = singleton(&(v489_11_head));
    let v490_3: Space = intersect(&(*CONSTANT_1),&(v490_2));
    let v490_4: Space = if has_head(&(v490_3)) { singleton(&[]) } else { Space::new() };
    drop(v490_3);
    let v490_5: Space = subtract(&(*CONSTANT_0),&(v490_4));
    drop(v490_4);
    let v490_8: Space = if (v490_5).is_empty() { Space::new() } else {
      let v491_6: Path = concat_path(&(*p0),&(v489_11_head));
      let mut v491_7 = Space::new();
      let mut v491_7_cursor = (v489_11_tail).read_zipper();
      for v491_7_byte in v491_7_cursor.child_mask().iter() {
        v491_7_cursor.descend_to_byte(v491_7_byte);
        let v491_7_tail = v491_7_cursor.make_map();
        v491_7_cursor.ascend(1);
        let v491_7_head = Path::from_slice(&[v491_7_byte]);
        let v492_2: Space = singleton(&(v491_7_head));
        let v492_3: Space = intersect(&(*CONSTANT_1),&(v492_2));
        let v492_4: Space = if has_head(&(v492_3)) { singleton(&[]) } else { Space::new() };
        drop(v492_3);
        let v492_5: Space = subtract(&(*CONSTANT_0),&(v492_4));
        drop(v492_4);
        let v492_8: Space = if (v492_5).is_empty() { Space::new() } else {
          let v493_6: Path = concat_path(&(v491_6),&(v491_7_head));
          let v493_7: Space = routine_64(c, &(v493_6), &(v491_7_tail));
          compose(&(v492_5),&(v493_7))
        };
        drop(v492_5);
        let v492_9: Space = intersect(&(*CONSTANT_1),&(v492_2));
        drop(v492_2);
        let v492_10: Space = if has_head(&(v492_9)) { singleton(&[]) } else { Space::new() };
        drop(v492_9);
        let v492_12: Space = if (v492_10).is_empty() { Space::new() } else {
          let v494_6: Path = concat_path(&(v491_6),&(v491_7_head));
          let v494_11: Space = routine_65(c, &(v494_6), &(v491_7_tail));
          drop(v494_6);
          compose(&(v492_10),&(v494_11))
        };
        drop(v492_10);
        let v492_13: Space = unite(&(v492_8),&(v492_12));
        v491_7.join_into((v492_13).clone());
      }
      drop(v491_7_cursor);
      compose(&(v490_5),&(v491_7))
    };
    drop(v490_5);
    let v490_9: Space = intersect(&(*CONSTANT_1),&(v490_2));
    drop(v490_2);
    let v490_10: Space = if has_head(&(v490_9)) { singleton(&[]) } else { Space::new() };
    drop(v490_9);
    let v490_12: Space = if (v490_10).is_empty() { Space::new() } else {
      let v495_6: Path = concat_path(&(*p0),&(v489_11_head));
      let mut v495_11 = Space::new();
      let mut v495_11_cursor = (v489_11_tail).read_zipper();
      for v495_11_byte in v495_11_cursor.child_mask().iter() {
        v495_11_cursor.descend_to_byte(v495_11_byte);
        let v495_11_tail = v495_11_cursor.make_map();
        v495_11_cursor.ascend(1);
        let v495_11_head = Path::from_slice(&[v495_11_byte]);
        let v496_2: Space = singleton(&(v495_11_head));
        let v496_3: Space = intersect(&(*CONSTANT_1),&(v496_2));
        let v496_4: Space = if has_head(&(v496_3)) { singleton(&[]) } else { Space::new() };
        drop(v496_3);
        let v496_5: Space = subtract(&(*CONSTANT_0),&(v496_4));
        drop(v496_4);
        let v496_8: Space = if (v496_5).is_empty() { Space::new() } else {
          let v497_6: Path = concat_path(&(v495_6),&(v495_11_head));
          let v497_7: Space = routine_64(c, &(v497_6), &(v495_11_tail));
          compose(&(v496_5),&(v497_7))
        };
        drop(v496_5);
        let v496_9: Space = intersect(&(*CONSTANT_1),&(v496_2));
        drop(v496_2);
        let v496_10: Space = if has_head(&(v496_9)) { singleton(&[]) } else { Space::new() };
        drop(v496_9);
        let v496_12: Space = if (v496_10).is_empty() { Space::new() } else {
          let v498_6: Path = concat_path(&(v495_6),&(v495_11_head));
          let v498_11: Space = routine_17(c, &(v498_6), &(v495_11_tail));
          drop(v498_6);
          compose(&(v496_10),&(v498_11))
        };
        drop(v496_10);
        let v496_13: Space = unite(&(v496_8),&(v496_12));
        v495_11.join_into((v496_13).clone());
      }
      drop(v495_11_cursor);
      drop(v495_6);
      compose(&(v490_10),&(v495_11))
    };
    drop(v490_10);
    let v490_13: Space = unite(&(v490_8),&(v490_12));
    v489_11.join_into((v490_13).clone());
  }
  drop(v489_11_cursor);
  (v489_11).clone()
}

fn routine_57(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v499_8 = Space::new();
  let mut v499_8_cursor = (*s0).read_zipper();
  for v499_8_byte in v499_8_cursor.child_mask().iter() {
    v499_8_cursor.descend_to_byte(v499_8_byte);
    let v499_8_tail = v499_8_cursor.make_map();
    v499_8_cursor.ascend(1);
    let v499_8_head = Path::from_slice(&[v499_8_byte]);
    let v500_2: Space = singleton(&(v499_8_head));
    let v500_3: Space = intersect(&(*CONSTANT_1),&(v500_2));
    let v500_4: Space = if has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
    drop(v500_3);
    let v500_5: Space = subtract(&(*CONSTANT_0),&(v500_4));
    drop(v500_4);
    let v500_8: Space = if (v500_5).is_empty() { Space::new() } else {
      let v501_6: Path = concat_path(&(*p0),&(v499_8_head));
      let mut v501_7 = Space::new();
      let mut v501_7_cursor = (v499_8_tail).read_zipper();
      for v501_7_byte in v501_7_cursor.child_mask().iter() {
        v501_7_cursor.descend_to_byte(v501_7_byte);
        let v501_7_tail = v501_7_cursor.make_map();
        v501_7_cursor.ascend(1);
        let v501_7_head = Path::from_slice(&[v501_7_byte]);
        let v502_2: Space = singleton(&(v501_7_head));
        let v502_3: Space = intersect(&(*CONSTANT_1),&(v502_2));
        let v502_4: Space = if has_head(&(v502_3)) { singleton(&[]) } else { Space::new() };
        drop(v502_3);
        let v502_5: Space = subtract(&(*CONSTANT_0),&(v502_4));
        drop(v502_4);
        let v502_8: Space = if (v502_5).is_empty() { Space::new() } else {
          let v503_6: Path = concat_path(&(v501_6),&(v501_7_head));
          let v503_7: Space = routine_64(c, &(v503_6), &(v501_7_tail));
          compose(&(v502_5),&(v503_7))
        };
        drop(v502_5);
        let v502_9: Space = intersect(&(*CONSTANT_1),&(v502_2));
        drop(v502_2);
        let v502_10: Space = if has_head(&(v502_9)) { singleton(&[]) } else { Space::new() };
        drop(v502_9);
        let v502_12: Space = if (v502_10).is_empty() { Space::new() } else {
          let v504_6: Path = concat_path(&(v501_6),&(v501_7_head));
          let v504_11: Space = routine_65(c, &(v504_6), &(v501_7_tail));
          drop(v504_6);
          compose(&(v502_10),&(v504_11))
        };
        drop(v502_10);
        let v502_13: Space = unite(&(v502_8),&(v502_12));
        v501_7.join_into((v502_13).clone());
      }
      drop(v501_7_cursor);
      drop(v501_6);
      compose(&(v500_5),&(v501_7))
    };
    drop(v500_5);
    let v500_9: Space = intersect(&(*CONSTANT_1),&(v500_2));
    drop(v500_2);
    let v500_10: Space = if has_head(&(v500_9)) { singleton(&[]) } else { Space::new() };
    drop(v500_9);
    let v500_11: Space = compose(&(v500_10),&(v499_8_tail));
    drop(v500_10);
    let v500_12: Space = unite(&(v500_8),&(v500_11));
    drop(v500_11);
    v499_8.join_into((v500_12).clone());
  }
  drop(v499_8_cursor);
  (v499_8).clone()
}

fn routine_58(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v505_11 = Space::new();
  let mut v505_11_cursor = (*s0).read_zipper();
  for v505_11_byte in v505_11_cursor.child_mask().iter() {
    v505_11_cursor.descend_to_byte(v505_11_byte);
    let v505_11_tail = v505_11_cursor.make_map();
    v505_11_cursor.ascend(1);
    let v505_11_head = Path::from_slice(&[v505_11_byte]);
    let v506_2: Space = singleton(&(v505_11_head));
    let v506_3: Space = intersect(&(*CONSTANT_1),&(v506_2));
    let v506_4: Space = if has_head(&(v506_3)) { singleton(&[]) } else { Space::new() };
    drop(v506_3);
    let v506_5: Space = subtract(&(*CONSTANT_0),&(v506_4));
    drop(v506_4);
    let v506_8: Space = if (v506_5).is_empty() { Space::new() } else {
      let v507_6: Path = concat_path(&(*p0),&(v505_11_head));
      let mut v507_7 = Space::new();
      let mut v507_7_cursor = (v505_11_tail).read_zipper();
      for v507_7_byte in v507_7_cursor.child_mask().iter() {
        v507_7_cursor.descend_to_byte(v507_7_byte);
        let v507_7_tail = v507_7_cursor.make_map();
        v507_7_cursor.ascend(1);
        let v507_7_head = Path::from_slice(&[v507_7_byte]);
        let v508_2: Space = singleton(&(v507_7_head));
        let v508_3: Space = intersect(&(*CONSTANT_1),&(v508_2));
        let v508_4: Space = if has_head(&(v508_3)) { singleton(&[]) } else { Space::new() };
        drop(v508_3);
        let v508_5: Space = subtract(&(*CONSTANT_0),&(v508_4));
        drop(v508_4);
        let v508_8: Space = if (v508_5).is_empty() { Space::new() } else {
          let v509_6: Path = concat_path(&(v507_6),&(v507_7_head));
          let v509_7: Space = routine_66(c, &(v509_6), &(v507_7_tail));
          compose(&(v508_5),&(v509_7))
        };
        drop(v508_5);
        let v508_9: Space = intersect(&(*CONSTANT_1),&(v508_2));
        drop(v508_2);
        let v508_10: Space = if has_head(&(v508_9)) { singleton(&[]) } else { Space::new() };
        drop(v508_9);
        let v508_12: Space = if (v508_10).is_empty() { Space::new() } else {
          let v510_6: Path = concat_path(&(v507_6),&(v507_7_head));
          let v510_11: Space = routine_67(c, &(v510_6), &(v507_7_tail));
          drop(v510_6);
          compose(&(v508_10),&(v510_11))
        };
        drop(v508_10);
        let v508_13: Space = unite(&(v508_8),&(v508_12));
        v507_7.join_into((v508_13).clone());
      }
      drop(v507_7_cursor);
      compose(&(v506_5),&(v507_7))
    };
    drop(v506_5);
    let v506_9: Space = intersect(&(*CONSTANT_1),&(v506_2));
    drop(v506_2);
    let v506_10: Space = if has_head(&(v506_9)) { singleton(&[]) } else { Space::new() };
    drop(v506_9);
    let v506_12: Space = if (v506_10).is_empty() { Space::new() } else {
      let v511_6: Path = concat_path(&(*p0),&(v505_11_head));
      let mut v511_11 = Space::new();
      let mut v511_11_cursor = (v505_11_tail).read_zipper();
      for v511_11_byte in v511_11_cursor.child_mask().iter() {
        v511_11_cursor.descend_to_byte(v511_11_byte);
        let v511_11_tail = v511_11_cursor.make_map();
        v511_11_cursor.ascend(1);
        let v511_11_head = Path::from_slice(&[v511_11_byte]);
        let v512_2: Space = singleton(&(v511_11_head));
        let v512_3: Space = intersect(&(*CONSTANT_1),&(v512_2));
        let v512_4: Space = if has_head(&(v512_3)) { singleton(&[]) } else { Space::new() };
        drop(v512_3);
        let v512_5: Space = subtract(&(*CONSTANT_0),&(v512_4));
        drop(v512_4);
        let v512_8: Space = if (v512_5).is_empty() { Space::new() } else {
          let v513_6: Path = concat_path(&(v511_6),&(v511_11_head));
          let v513_7: Space = routine_66(c, &(v513_6), &(v511_11_tail));
          compose(&(v512_5),&(v513_7))
        };
        drop(v512_5);
        let v512_9: Space = intersect(&(*CONSTANT_1),&(v512_2));
        drop(v512_2);
        let v512_10: Space = if has_head(&(v512_9)) { singleton(&[]) } else { Space::new() };
        drop(v512_9);
        let v512_12: Space = if (v512_10).is_empty() { Space::new() } else {
          let v514_6: Path = concat_path(&(v511_6),&(v511_11_head));
          let v514_11: Space = routine_14(c, &(v514_6), &(v511_11_tail));
          drop(v514_6);
          compose(&(v512_10),&(v514_11))
        };
        drop(v512_10);
        let v512_13: Space = unite(&(v512_8),&(v512_12));
        v511_11.join_into((v512_13).clone());
      }
      drop(v511_11_cursor);
      drop(v511_6);
      compose(&(v506_10),&(v511_11))
    };
    drop(v506_10);
    let v506_13: Space = unite(&(v506_8),&(v506_12));
    v505_11.join_into((v506_13).clone());
  }
  drop(v505_11_cursor);
  (v505_11).clone()
}

fn routine_59(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v515_8 = Space::new();
  let mut v515_8_cursor = (*s0).read_zipper();
  for v515_8_byte in v515_8_cursor.child_mask().iter() {
    v515_8_cursor.descend_to_byte(v515_8_byte);
    let v515_8_tail = v515_8_cursor.make_map();
    v515_8_cursor.ascend(1);
    let v515_8_head = Path::from_slice(&[v515_8_byte]);
    let v516_2: Space = singleton(&(v515_8_head));
    let v516_3: Space = intersect(&(*CONSTANT_1),&(v516_2));
    let v516_4: Space = if has_head(&(v516_3)) { singleton(&[]) } else { Space::new() };
    drop(v516_3);
    let v516_5: Space = subtract(&(*CONSTANT_0),&(v516_4));
    drop(v516_4);
    let v516_8: Space = if (v516_5).is_empty() { Space::new() } else {
      let v517_6: Path = concat_path(&(*p0),&(v515_8_head));
      let mut v517_7 = Space::new();
      let mut v517_7_cursor = (v515_8_tail).read_zipper();
      for v517_7_byte in v517_7_cursor.child_mask().iter() {
        v517_7_cursor.descend_to_byte(v517_7_byte);
        let v517_7_tail = v517_7_cursor.make_map();
        v517_7_cursor.ascend(1);
        let v517_7_head = Path::from_slice(&[v517_7_byte]);
        let v518_2: Space = singleton(&(v517_7_head));
        let v518_3: Space = intersect(&(*CONSTANT_1),&(v518_2));
        let v518_4: Space = if has_head(&(v518_3)) { singleton(&[]) } else { Space::new() };
        drop(v518_3);
        let v518_5: Space = subtract(&(*CONSTANT_0),&(v518_4));
        drop(v518_4);
        let v518_8: Space = if (v518_5).is_empty() { Space::new() } else {
          let v519_6: Path = concat_path(&(v517_6),&(v517_7_head));
          let v519_7: Space = routine_66(c, &(v519_6), &(v517_7_tail));
          compose(&(v518_5),&(v519_7))
        };
        drop(v518_5);
        let v518_9: Space = intersect(&(*CONSTANT_1),&(v518_2));
        drop(v518_2);
        let v518_10: Space = if has_head(&(v518_9)) { singleton(&[]) } else { Space::new() };
        drop(v518_9);
        let v518_12: Space = if (v518_10).is_empty() { Space::new() } else {
          let v520_6: Path = concat_path(&(v517_6),&(v517_7_head));
          let v520_11: Space = routine_67(c, &(v520_6), &(v517_7_tail));
          drop(v520_6);
          compose(&(v518_10),&(v520_11))
        };
        drop(v518_10);
        let v518_13: Space = unite(&(v518_8),&(v518_12));
        v517_7.join_into((v518_13).clone());
      }
      drop(v517_7_cursor);
      drop(v517_6);
      compose(&(v516_5),&(v517_7))
    };
    drop(v516_5);
    let v516_9: Space = intersect(&(*CONSTANT_1),&(v516_2));
    drop(v516_2);
    let v516_10: Space = if has_head(&(v516_9)) { singleton(&[]) } else { Space::new() };
    drop(v516_9);
    let v516_11: Space = compose(&(v516_10),&(v515_8_tail));
    drop(v516_10);
    let v516_12: Space = unite(&(v516_8),&(v516_11));
    drop(v516_11);
    v515_8.join_into((v516_12).clone());
  }
  drop(v515_8_cursor);
  (v515_8).clone()
}

fn routine_60(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v521_11 = Space::new();
  let mut v521_11_cursor = (*s0).read_zipper();
  for v521_11_byte in v521_11_cursor.child_mask().iter() {
    v521_11_cursor.descend_to_byte(v521_11_byte);
    let v521_11_tail = v521_11_cursor.make_map();
    v521_11_cursor.ascend(1);
    let v521_11_head = Path::from_slice(&[v521_11_byte]);
    let v522_2: Space = singleton(&(v521_11_head));
    let v522_3: Space = intersect(&(*CONSTANT_1),&(v522_2));
    let v522_4: Space = if has_head(&(v522_3)) { singleton(&[]) } else { Space::new() };
    drop(v522_3);
    let v522_5: Space = subtract(&(*CONSTANT_0),&(v522_4));
    drop(v522_4);
    let v522_8: Space = if (v522_5).is_empty() { Space::new() } else {
      let v523_6: Path = concat_path(&(*p0),&(v521_11_head));
      let mut v523_7 = Space::new();
      let mut v523_7_cursor = (v521_11_tail).read_zipper();
      for v523_7_byte in v523_7_cursor.child_mask().iter() {
        v523_7_cursor.descend_to_byte(v523_7_byte);
        let v523_7_tail = v523_7_cursor.make_map();
        v523_7_cursor.ascend(1);
        let v523_7_head = Path::from_slice(&[v523_7_byte]);
        let v524_2: Space = singleton(&(v523_7_head));
        let v524_3: Space = intersect(&(*CONSTANT_1),&(v524_2));
        let v524_4: Space = if has_head(&(v524_3)) { singleton(&[]) } else { Space::new() };
        drop(v524_3);
        let v524_5: Space = subtract(&(*CONSTANT_0),&(v524_4));
        drop(v524_4);
        let v524_8: Space = if (v524_5).is_empty() { Space::new() } else {
          let v525_6: Path = concat_path(&(v523_6),&(v523_7_head));
          let v525_7: Space = routine_68(c, &(v525_6), &(v523_7_tail));
          compose(&(v524_5),&(v525_7))
        };
        drop(v524_5);
        let v524_9: Space = intersect(&(*CONSTANT_1),&(v524_2));
        drop(v524_2);
        let v524_10: Space = if has_head(&(v524_9)) { singleton(&[]) } else { Space::new() };
        drop(v524_9);
        let v524_12: Space = if (v524_10).is_empty() { Space::new() } else {
          let v526_6: Path = concat_path(&(v523_6),&(v523_7_head));
          let v526_11: Space = routine_69(c, &(v526_6), &(v523_7_tail));
          drop(v526_6);
          compose(&(v524_10),&(v526_11))
        };
        drop(v524_10);
        let v524_13: Space = unite(&(v524_8),&(v524_12));
        v523_7.join_into((v524_13).clone());
      }
      drop(v523_7_cursor);
      compose(&(v522_5),&(v523_7))
    };
    drop(v522_5);
    let v522_9: Space = intersect(&(*CONSTANT_1),&(v522_2));
    drop(v522_2);
    let v522_10: Space = if has_head(&(v522_9)) { singleton(&[]) } else { Space::new() };
    drop(v522_9);
    let v522_12: Space = if (v522_10).is_empty() { Space::new() } else {
      let v527_6: Path = concat_path(&(*p0),&(v521_11_head));
      let mut v527_11 = Space::new();
      let mut v527_11_cursor = (v521_11_tail).read_zipper();
      for v527_11_byte in v527_11_cursor.child_mask().iter() {
        v527_11_cursor.descend_to_byte(v527_11_byte);
        let v527_11_tail = v527_11_cursor.make_map();
        v527_11_cursor.ascend(1);
        let v527_11_head = Path::from_slice(&[v527_11_byte]);
        let v528_2: Space = singleton(&(v527_11_head));
        let v528_3: Space = intersect(&(*CONSTANT_1),&(v528_2));
        let v528_4: Space = if has_head(&(v528_3)) { singleton(&[]) } else { Space::new() };
        drop(v528_3);
        let v528_5: Space = subtract(&(*CONSTANT_0),&(v528_4));
        drop(v528_4);
        let v528_8: Space = if (v528_5).is_empty() { Space::new() } else {
          let v529_6: Path = concat_path(&(v527_6),&(v527_11_head));
          let v529_7: Space = routine_68(c, &(v529_6), &(v527_11_tail));
          compose(&(v528_5),&(v529_7))
        };
        drop(v528_5);
        let v528_9: Space = intersect(&(*CONSTANT_1),&(v528_2));
        drop(v528_2);
        let v528_10: Space = if has_head(&(v528_9)) { singleton(&[]) } else { Space::new() };
        drop(v528_9);
        let v528_12: Space = if (v528_10).is_empty() { Space::new() } else {
          let v530_6: Path = concat_path(&(v527_6),&(v527_11_head));
          let v530_11: Space = routine_17(c, &(v530_6), &(v527_11_tail));
          drop(v530_6);
          compose(&(v528_10),&(v530_11))
        };
        drop(v528_10);
        let v528_13: Space = unite(&(v528_8),&(v528_12));
        v527_11.join_into((v528_13).clone());
      }
      drop(v527_11_cursor);
      drop(v527_6);
      compose(&(v522_10),&(v527_11))
    };
    drop(v522_10);
    let v522_13: Space = unite(&(v522_8),&(v522_12));
    v521_11.join_into((v522_13).clone());
  }
  drop(v521_11_cursor);
  (v521_11).clone()
}

fn routine_61(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v531_8 = Space::new();
  let mut v531_8_cursor = (*s0).read_zipper();
  for v531_8_byte in v531_8_cursor.child_mask().iter() {
    v531_8_cursor.descend_to_byte(v531_8_byte);
    let v531_8_tail = v531_8_cursor.make_map();
    v531_8_cursor.ascend(1);
    let v531_8_head = Path::from_slice(&[v531_8_byte]);
    let v532_2: Space = singleton(&(v531_8_head));
    let v532_3: Space = intersect(&(*CONSTANT_1),&(v532_2));
    let v532_4: Space = if has_head(&(v532_3)) { singleton(&[]) } else { Space::new() };
    drop(v532_3);
    let v532_5: Space = subtract(&(*CONSTANT_0),&(v532_4));
    drop(v532_4);
    let v532_8: Space = if (v532_5).is_empty() { Space::new() } else {
      let v533_6: Path = concat_path(&(*p0),&(v531_8_head));
      let mut v533_7 = Space::new();
      let mut v533_7_cursor = (v531_8_tail).read_zipper();
      for v533_7_byte in v533_7_cursor.child_mask().iter() {
        v533_7_cursor.descend_to_byte(v533_7_byte);
        let v533_7_tail = v533_7_cursor.make_map();
        v533_7_cursor.ascend(1);
        let v533_7_head = Path::from_slice(&[v533_7_byte]);
        let v534_2: Space = singleton(&(v533_7_head));
        let v534_3: Space = intersect(&(*CONSTANT_1),&(v534_2));
        let v534_4: Space = if has_head(&(v534_3)) { singleton(&[]) } else { Space::new() };
        drop(v534_3);
        let v534_5: Space = subtract(&(*CONSTANT_0),&(v534_4));
        drop(v534_4);
        let v534_8: Space = if (v534_5).is_empty() { Space::new() } else {
          let v535_6: Path = concat_path(&(v533_6),&(v533_7_head));
          let v535_7: Space = routine_68(c, &(v535_6), &(v533_7_tail));
          compose(&(v534_5),&(v535_7))
        };
        drop(v534_5);
        let v534_9: Space = intersect(&(*CONSTANT_1),&(v534_2));
        drop(v534_2);
        let v534_10: Space = if has_head(&(v534_9)) { singleton(&[]) } else { Space::new() };
        drop(v534_9);
        let v534_12: Space = if (v534_10).is_empty() { Space::new() } else {
          let v536_6: Path = concat_path(&(v533_6),&(v533_7_head));
          let v536_11: Space = routine_69(c, &(v536_6), &(v533_7_tail));
          drop(v536_6);
          compose(&(v534_10),&(v536_11))
        };
        drop(v534_10);
        let v534_13: Space = unite(&(v534_8),&(v534_12));
        v533_7.join_into((v534_13).clone());
      }
      drop(v533_7_cursor);
      drop(v533_6);
      compose(&(v532_5),&(v533_7))
    };
    drop(v532_5);
    let v532_9: Space = intersect(&(*CONSTANT_1),&(v532_2));
    drop(v532_2);
    let v532_10: Space = if has_head(&(v532_9)) { singleton(&[]) } else { Space::new() };
    drop(v532_9);
    let v532_11: Space = compose(&(v532_10),&(v531_8_tail));
    drop(v532_10);
    let v532_12: Space = unite(&(v532_8),&(v532_11));
    drop(v532_11);
    v531_8.join_into((v532_12).clone());
  }
  drop(v531_8_cursor);
  (v531_8).clone()
}

fn routine_62(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v537_11 = Space::new();
  let mut v537_11_cursor = (*s0).read_zipper();
  for v537_11_byte in v537_11_cursor.child_mask().iter() {
    v537_11_cursor.descend_to_byte(v537_11_byte);
    let v537_11_tail = v537_11_cursor.make_map();
    v537_11_cursor.ascend(1);
    let v537_11_head = Path::from_slice(&[v537_11_byte]);
    let v538_2: Space = singleton(&(v537_11_head));
    let v538_3: Space = intersect(&(*CONSTANT_1),&(v538_2));
    let v538_4: Space = if has_head(&(v538_3)) { singleton(&[]) } else { Space::new() };
    drop(v538_3);
    let v538_5: Space = subtract(&(*CONSTANT_0),&(v538_4));
    drop(v538_4);
    let v538_8: Space = if (v538_5).is_empty() { Space::new() } else {
      let v539_6: Path = concat_path(&(*p0),&(v537_11_head));
      let mut v539_7 = Space::new();
      let mut v539_7_cursor = (v537_11_tail).read_zipper();
      for v539_7_byte in v539_7_cursor.child_mask().iter() {
        v539_7_cursor.descend_to_byte(v539_7_byte);
        let v539_7_tail = v539_7_cursor.make_map();
        v539_7_cursor.ascend(1);
        let v539_7_head = Path::from_slice(&[v539_7_byte]);
        let v540_2: Space = singleton(&(v539_7_head));
        let v540_3: Space = intersect(&(*CONSTANT_1),&(v540_2));
        let v540_4: Space = if has_head(&(v540_3)) { singleton(&[]) } else { Space::new() };
        drop(v540_3);
        let v540_5: Space = subtract(&(*CONSTANT_0),&(v540_4));
        drop(v540_4);
        let v540_8: Space = if (v540_5).is_empty() { Space::new() } else {
          let v541_6: Path = concat_path(&(v539_6),&(v539_7_head));
          let v541_7: Space = routine_70(c, &(v541_6), &(v539_7_tail));
          compose(&(v540_5),&(v541_7))
        };
        drop(v540_5);
        let v540_9: Space = intersect(&(*CONSTANT_1),&(v540_2));
        drop(v540_2);
        let v540_10: Space = if has_head(&(v540_9)) { singleton(&[]) } else { Space::new() };
        drop(v540_9);
        let v540_12: Space = if (v540_10).is_empty() { Space::new() } else {
          let v542_6: Path = concat_path(&(v539_6),&(v539_7_head));
          let v542_11: Space = routine_71(c, &(v542_6), &(v539_7_tail));
          drop(v542_6);
          compose(&(v540_10),&(v542_11))
        };
        drop(v540_10);
        let v540_13: Space = unite(&(v540_8),&(v540_12));
        v539_7.join_into((v540_13).clone());
      }
      drop(v539_7_cursor);
      compose(&(v538_5),&(v539_7))
    };
    drop(v538_5);
    let v538_9: Space = intersect(&(*CONSTANT_1),&(v538_2));
    drop(v538_2);
    let v538_10: Space = if has_head(&(v538_9)) { singleton(&[]) } else { Space::new() };
    drop(v538_9);
    let v538_12: Space = if (v538_10).is_empty() { Space::new() } else {
      let v543_6: Path = concat_path(&(*p0),&(v537_11_head));
      let mut v543_11 = Space::new();
      let mut v543_11_cursor = (v537_11_tail).read_zipper();
      for v543_11_byte in v543_11_cursor.child_mask().iter() {
        v543_11_cursor.descend_to_byte(v543_11_byte);
        let v543_11_tail = v543_11_cursor.make_map();
        v543_11_cursor.ascend(1);
        let v543_11_head = Path::from_slice(&[v543_11_byte]);
        let v544_2: Space = singleton(&(v543_11_head));
        let v544_3: Space = intersect(&(*CONSTANT_1),&(v544_2));
        let v544_4: Space = if has_head(&(v544_3)) { singleton(&[]) } else { Space::new() };
        drop(v544_3);
        let v544_5: Space = subtract(&(*CONSTANT_0),&(v544_4));
        drop(v544_4);
        let v544_8: Space = if (v544_5).is_empty() { Space::new() } else {
          let v545_6: Path = concat_path(&(v543_6),&(v543_11_head));
          let v545_7: Space = routine_70(c, &(v545_6), &(v543_11_tail));
          compose(&(v544_5),&(v545_7))
        };
        drop(v544_5);
        let v544_9: Space = intersect(&(*CONSTANT_1),&(v544_2));
        drop(v544_2);
        let v544_10: Space = if has_head(&(v544_9)) { singleton(&[]) } else { Space::new() };
        drop(v544_9);
        let v544_12: Space = if (v544_10).is_empty() { Space::new() } else {
          let v546_6: Path = concat_path(&(v543_6),&(v543_11_head));
          let v546_11: Space = routine_14(c, &(v546_6), &(v543_11_tail));
          drop(v546_6);
          compose(&(v544_10),&(v546_11))
        };
        drop(v544_10);
        let v544_13: Space = unite(&(v544_8),&(v544_12));
        v543_11.join_into((v544_13).clone());
      }
      drop(v543_11_cursor);
      drop(v543_6);
      compose(&(v538_10),&(v543_11))
    };
    drop(v538_10);
    let v538_13: Space = unite(&(v538_8),&(v538_12));
    v537_11.join_into((v538_13).clone());
  }
  drop(v537_11_cursor);
  (v537_11).clone()
}

fn routine_63(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v547_8 = Space::new();
  let mut v547_8_cursor = (*s0).read_zipper();
  for v547_8_byte in v547_8_cursor.child_mask().iter() {
    v547_8_cursor.descend_to_byte(v547_8_byte);
    let v547_8_tail = v547_8_cursor.make_map();
    v547_8_cursor.ascend(1);
    let v547_8_head = Path::from_slice(&[v547_8_byte]);
    let v548_2: Space = singleton(&(v547_8_head));
    let v548_3: Space = intersect(&(*CONSTANT_1),&(v548_2));
    let v548_4: Space = if has_head(&(v548_3)) { singleton(&[]) } else { Space::new() };
    drop(v548_3);
    let v548_5: Space = subtract(&(*CONSTANT_0),&(v548_4));
    drop(v548_4);
    let v548_8: Space = if (v548_5).is_empty() { Space::new() } else {
      let v549_6: Path = concat_path(&(*p0),&(v547_8_head));
      let mut v549_7 = Space::new();
      let mut v549_7_cursor = (v547_8_tail).read_zipper();
      for v549_7_byte in v549_7_cursor.child_mask().iter() {
        v549_7_cursor.descend_to_byte(v549_7_byte);
        let v549_7_tail = v549_7_cursor.make_map();
        v549_7_cursor.ascend(1);
        let v549_7_head = Path::from_slice(&[v549_7_byte]);
        let v550_2: Space = singleton(&(v549_7_head));
        let v550_3: Space = intersect(&(*CONSTANT_1),&(v550_2));
        let v550_4: Space = if has_head(&(v550_3)) { singleton(&[]) } else { Space::new() };
        drop(v550_3);
        let v550_5: Space = subtract(&(*CONSTANT_0),&(v550_4));
        drop(v550_4);
        let v550_8: Space = if (v550_5).is_empty() { Space::new() } else {
          let v551_6: Path = concat_path(&(v549_6),&(v549_7_head));
          let v551_7: Space = routine_70(c, &(v551_6), &(v549_7_tail));
          compose(&(v550_5),&(v551_7))
        };
        drop(v550_5);
        let v550_9: Space = intersect(&(*CONSTANT_1),&(v550_2));
        drop(v550_2);
        let v550_10: Space = if has_head(&(v550_9)) { singleton(&[]) } else { Space::new() };
        drop(v550_9);
        let v550_12: Space = if (v550_10).is_empty() { Space::new() } else {
          let v552_6: Path = concat_path(&(v549_6),&(v549_7_head));
          let v552_11: Space = routine_71(c, &(v552_6), &(v549_7_tail));
          drop(v552_6);
          compose(&(v550_10),&(v552_11))
        };
        drop(v550_10);
        let v550_13: Space = unite(&(v550_8),&(v550_12));
        v549_7.join_into((v550_13).clone());
      }
      drop(v549_7_cursor);
      drop(v549_6);
      compose(&(v548_5),&(v549_7))
    };
    drop(v548_5);
    let v548_9: Space = intersect(&(*CONSTANT_1),&(v548_2));
    drop(v548_2);
    let v548_10: Space = if has_head(&(v548_9)) { singleton(&[]) } else { Space::new() };
    drop(v548_9);
    let v548_11: Space = compose(&(v548_10),&(v547_8_tail));
    drop(v548_10);
    let v548_12: Space = unite(&(v548_8),&(v548_11));
    drop(v548_11);
    v547_8.join_into((v548_12).clone());
  }
  drop(v547_8_cursor);
  (v547_8).clone()
}

fn routine_64(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v553_11 = Space::new();
  let mut v553_11_cursor = (*s0).read_zipper();
  for v553_11_byte in v553_11_cursor.child_mask().iter() {
    v553_11_cursor.descend_to_byte(v553_11_byte);
    let v553_11_tail = v553_11_cursor.make_map();
    v553_11_cursor.ascend(1);
    let v553_11_head = Path::from_slice(&[v553_11_byte]);
    let v554_2: Space = singleton(&(v553_11_head));
    let v554_3: Space = intersect(&(*CONSTANT_1),&(v554_2));
    let v554_4: Space = if has_head(&(v554_3)) { singleton(&[]) } else { Space::new() };
    drop(v554_3);
    let v554_5: Space = subtract(&(*CONSTANT_0),&(v554_4));
    drop(v554_4);
    let v554_8: Space = if (v554_5).is_empty() { Space::new() } else {
      let v555_6: Path = concat_path(&(*p0),&(v553_11_head));
      let mut v555_7 = Space::new();
      let mut v555_7_cursor = (v553_11_tail).read_zipper();
      for v555_7_byte in v555_7_cursor.child_mask().iter() {
        v555_7_cursor.descend_to_byte(v555_7_byte);
        let v555_7_tail = v555_7_cursor.make_map();
        v555_7_cursor.ascend(1);
        let v555_7_head = Path::from_slice(&[v555_7_byte]);
        let v556_2: Space = singleton(&(v555_7_head));
        let v556_3: Space = intersect(&(*CONSTANT_1),&(v556_2));
        let v556_4: Space = if has_head(&(v556_3)) { singleton(&[]) } else { Space::new() };
        drop(v556_3);
        let v556_5: Space = subtract(&(*CONSTANT_0),&(v556_4));
        drop(v556_4);
        let v556_8: Space = if (v556_5).is_empty() { Space::new() } else {
          let v557_6: Path = concat_path(&(v555_6),&(v555_7_head));
          let v557_7: Space = routine_72(c, &(v557_6), &(v555_7_tail));
          compose(&(v556_5),&(v557_7))
        };
        drop(v556_5);
        let v556_9: Space = intersect(&(*CONSTANT_1),&(v556_2));
        drop(v556_2);
        let v556_10: Space = if has_head(&(v556_9)) { singleton(&[]) } else { Space::new() };
        drop(v556_9);
        let v556_12: Space = if (v556_10).is_empty() { Space::new() } else {
          let v558_6: Path = concat_path(&(v555_6),&(v555_7_head));
          let v558_11: Space = routine_73(c, &(v558_6), &(v555_7_tail));
          drop(v558_6);
          compose(&(v556_10),&(v558_11))
        };
        drop(v556_10);
        let v556_13: Space = unite(&(v556_8),&(v556_12));
        v555_7.join_into((v556_13).clone());
      }
      drop(v555_7_cursor);
      compose(&(v554_5),&(v555_7))
    };
    drop(v554_5);
    let v554_9: Space = intersect(&(*CONSTANT_1),&(v554_2));
    drop(v554_2);
    let v554_10: Space = if has_head(&(v554_9)) { singleton(&[]) } else { Space::new() };
    drop(v554_9);
    let v554_12: Space = if (v554_10).is_empty() { Space::new() } else {
      let v559_6: Path = concat_path(&(*p0),&(v553_11_head));
      let mut v559_11 = Space::new();
      let mut v559_11_cursor = (v553_11_tail).read_zipper();
      for v559_11_byte in v559_11_cursor.child_mask().iter() {
        v559_11_cursor.descend_to_byte(v559_11_byte);
        let v559_11_tail = v559_11_cursor.make_map();
        v559_11_cursor.ascend(1);
        let v559_11_head = Path::from_slice(&[v559_11_byte]);
        let v560_2: Space = singleton(&(v559_11_head));
        let v560_3: Space = intersect(&(*CONSTANT_1),&(v560_2));
        let v560_4: Space = if has_head(&(v560_3)) { singleton(&[]) } else { Space::new() };
        drop(v560_3);
        let v560_5: Space = subtract(&(*CONSTANT_0),&(v560_4));
        drop(v560_4);
        let v560_8: Space = if (v560_5).is_empty() { Space::new() } else {
          let v561_6: Path = concat_path(&(v559_6),&(v559_11_head));
          let v561_7: Space = routine_72(c, &(v561_6), &(v559_11_tail));
          compose(&(v560_5),&(v561_7))
        };
        drop(v560_5);
        let v560_9: Space = intersect(&(*CONSTANT_1),&(v560_2));
        drop(v560_2);
        let v560_10: Space = if has_head(&(v560_9)) { singleton(&[]) } else { Space::new() };
        drop(v560_9);
        let v560_12: Space = if (v560_10).is_empty() { Space::new() } else {
          let v562_6: Path = concat_path(&(v559_6),&(v559_11_head));
          let v562_11: Space = routine_17(c, &(v562_6), &(v559_11_tail));
          drop(v562_6);
          compose(&(v560_10),&(v562_11))
        };
        drop(v560_10);
        let v560_13: Space = unite(&(v560_8),&(v560_12));
        v559_11.join_into((v560_13).clone());
      }
      drop(v559_11_cursor);
      drop(v559_6);
      compose(&(v554_10),&(v559_11))
    };
    drop(v554_10);
    let v554_13: Space = unite(&(v554_8),&(v554_12));
    v553_11.join_into((v554_13).clone());
  }
  drop(v553_11_cursor);
  (v553_11).clone()
}

fn routine_65(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v563_8 = Space::new();
  let mut v563_8_cursor = (*s0).read_zipper();
  for v563_8_byte in v563_8_cursor.child_mask().iter() {
    v563_8_cursor.descend_to_byte(v563_8_byte);
    let v563_8_tail = v563_8_cursor.make_map();
    v563_8_cursor.ascend(1);
    let v563_8_head = Path::from_slice(&[v563_8_byte]);
    let v564_2: Space = singleton(&(v563_8_head));
    let v564_3: Space = intersect(&(*CONSTANT_1),&(v564_2));
    let v564_4: Space = if has_head(&(v564_3)) { singleton(&[]) } else { Space::new() };
    drop(v564_3);
    let v564_5: Space = subtract(&(*CONSTANT_0),&(v564_4));
    drop(v564_4);
    let v564_8: Space = if (v564_5).is_empty() { Space::new() } else {
      let v565_6: Path = concat_path(&(*p0),&(v563_8_head));
      let mut v565_7 = Space::new();
      let mut v565_7_cursor = (v563_8_tail).read_zipper();
      for v565_7_byte in v565_7_cursor.child_mask().iter() {
        v565_7_cursor.descend_to_byte(v565_7_byte);
        let v565_7_tail = v565_7_cursor.make_map();
        v565_7_cursor.ascend(1);
        let v565_7_head = Path::from_slice(&[v565_7_byte]);
        let v566_2: Space = singleton(&(v565_7_head));
        let v566_3: Space = intersect(&(*CONSTANT_1),&(v566_2));
        let v566_4: Space = if has_head(&(v566_3)) { singleton(&[]) } else { Space::new() };
        drop(v566_3);
        let v566_5: Space = subtract(&(*CONSTANT_0),&(v566_4));
        drop(v566_4);
        let v566_8: Space = if (v566_5).is_empty() { Space::new() } else {
          let v567_6: Path = concat_path(&(v565_6),&(v565_7_head));
          let v567_7: Space = routine_72(c, &(v567_6), &(v565_7_tail));
          compose(&(v566_5),&(v567_7))
        };
        drop(v566_5);
        let v566_9: Space = intersect(&(*CONSTANT_1),&(v566_2));
        drop(v566_2);
        let v566_10: Space = if has_head(&(v566_9)) { singleton(&[]) } else { Space::new() };
        drop(v566_9);
        let v566_12: Space = if (v566_10).is_empty() { Space::new() } else {
          let v568_6: Path = concat_path(&(v565_6),&(v565_7_head));
          let v568_11: Space = routine_73(c, &(v568_6), &(v565_7_tail));
          drop(v568_6);
          compose(&(v566_10),&(v568_11))
        };
        drop(v566_10);
        let v566_13: Space = unite(&(v566_8),&(v566_12));
        v565_7.join_into((v566_13).clone());
      }
      drop(v565_7_cursor);
      drop(v565_6);
      compose(&(v564_5),&(v565_7))
    };
    drop(v564_5);
    let v564_9: Space = intersect(&(*CONSTANT_1),&(v564_2));
    drop(v564_2);
    let v564_10: Space = if has_head(&(v564_9)) { singleton(&[]) } else { Space::new() };
    drop(v564_9);
    let v564_11: Space = compose(&(v564_10),&(v563_8_tail));
    drop(v564_10);
    let v564_12: Space = unite(&(v564_8),&(v564_11));
    drop(v564_11);
    v563_8.join_into((v564_12).clone());
  }
  drop(v563_8_cursor);
  (v563_8).clone()
}

fn routine_66(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v569_6 = Space::new();
  let mut v569_6_cursor = (*s0).read_zipper();
  for v569_6_byte in v569_6_cursor.child_mask().iter() {
    v569_6_cursor.descend_to_byte(v569_6_byte);
    let v569_6_tail = v569_6_cursor.make_map();
    v569_6_cursor.ascend(1);
    let v569_6_head = Path::from_slice(&[v569_6_byte]);
    let v570_2: Space = singleton(&(v569_6_head));
    let v570_3: Space = intersect(&(*CONSTANT_1),&(v570_2));
    let v570_4: Space = if has_head(&(v570_3)) { singleton(&[]) } else { Space::new() };
    drop(v570_3);
    let v570_5: Space = subtract(&(*CONSTANT_0),&(v570_4));
    drop(v570_4);
    let mut v570_6 = Space::new();
    let mut v570_6_cursor = (v569_6_tail).read_zipper();
    for v570_6_byte in v570_6_cursor.child_mask().iter() {
      v570_6_cursor.descend_to_byte(v570_6_byte);
      let v570_6_tail = v570_6_cursor.make_map();
      v570_6_cursor.ascend(1);
      let v570_6_head = Path::from_slice(&[v570_6_byte]);
      let v571_2: Space = Space::new();
      v570_6.join_into((v571_2).clone());
    }
    drop(v570_6_cursor);
    let v570_7: Space = compose(&(v570_5),&(v570_6));
    drop(v570_5);
    drop(v570_6);
    let v570_8: Space = intersect(&(*CONSTANT_1),&(v570_2));
    drop(v570_2);
    let v570_9: Space = if has_head(&(v570_8)) { singleton(&[]) } else { Space::new() };
    drop(v570_8);
    let v570_12: Space = if (v570_9).is_empty() { Space::new() } else {
      let v572_10: Path = concat_path(&(*p0),&(v569_6_head));
      let mut v572_11 = Space::new();
      let mut v572_11_cursor = (v569_6_tail).read_zipper();
      for v572_11_byte in v572_11_cursor.child_mask().iter() {
        v572_11_cursor.descend_to_byte(v572_11_byte);
        let v572_11_tail = v572_11_cursor.make_map();
        v572_11_cursor.ascend(1);
        let v572_11_head = Path::from_slice(&[v572_11_byte]);
        let v573_2: Space = singleton(&(v572_11_head));
        let v573_3: Space = intersect(&(*CONSTANT_1),&(v573_2));
        drop(v573_2);
        let v573_4: Space = if has_head(&(v573_3)) { singleton(&[]) } else { Space::new() };
        drop(v573_3);
        let v573_7: Space = if (v573_4).is_empty() { Space::new() } else {
          let v574_5: Path = concat_path(&(v572_10),&(v572_11_head));
          let v574_6: Space = routine_14(c, &(v574_5), &(v572_11_tail));
          drop(v574_5);
          compose(&(v573_4),&(v574_6))
        };
        drop(v573_4);
        v572_11.join_into((v573_7).clone());
      }
      drop(v572_11_cursor);
      drop(v572_10);
      compose(&(v570_9),&(v572_11))
    };
    drop(v570_9);
    let v570_13: Space = unite(&(v570_7),&(v570_12));
    drop(v570_7);
    v569_6.join_into((v570_13).clone());
  }
  drop(v569_6_cursor);
  (v569_6).clone()
}

fn routine_67(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v575_5 = Space::new();
  let mut v575_5_cursor = (*s0).read_zipper();
  for v575_5_byte in v575_5_cursor.child_mask().iter() {
    v575_5_cursor.descend_to_byte(v575_5_byte);
    let v575_5_tail = v575_5_cursor.make_map();
    v575_5_cursor.ascend(1);
    let v575_5_head = Path::from_slice(&[v575_5_byte]);
    let v576_2: Space = singleton(&(v575_5_head));
    let v576_3: Space = intersect(&(*CONSTANT_1),&(v576_2));
    let v576_4: Space = if has_head(&(v576_3)) { singleton(&[]) } else { Space::new() };
    drop(v576_3);
    let v576_5: Space = subtract(&(*CONSTANT_0),&(v576_4));
    drop(v576_4);
    let mut v576_6 = Space::new();
    let mut v576_6_cursor = (v575_5_tail).read_zipper();
    for v576_6_byte in v576_6_cursor.child_mask().iter() {
      v576_6_cursor.descend_to_byte(v576_6_byte);
      let v576_6_tail = v576_6_cursor.make_map();
      v576_6_cursor.ascend(1);
      let v576_6_head = Path::from_slice(&[v576_6_byte]);
      let v577_2: Space = Space::new();
      v576_6.join_into((v577_2).clone());
    }
    drop(v576_6_cursor);
    let v576_7: Space = compose(&(v576_5),&(v576_6));
    drop(v576_5);
    drop(v576_6);
    let v576_8: Space = intersect(&(*CONSTANT_1),&(v576_2));
    drop(v576_2);
    let v576_9: Space = if has_head(&(v576_8)) { singleton(&[]) } else { Space::new() };
    drop(v576_8);
    let v576_10: Space = compose(&(v576_9),&(v575_5_tail));
    drop(v576_9);
    let v576_11: Space = unite(&(v576_7),&(v576_10));
    drop(v576_7);
    drop(v576_10);
    v575_5.join_into((v576_11).clone());
  }
  drop(v575_5_cursor);
  (v575_5).clone()
}

fn routine_68(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v578_6 = Space::new();
  let mut v578_6_cursor = (*s0).read_zipper();
  for v578_6_byte in v578_6_cursor.child_mask().iter() {
    v578_6_cursor.descend_to_byte(v578_6_byte);
    let v578_6_tail = v578_6_cursor.make_map();
    v578_6_cursor.ascend(1);
    let v578_6_head = Path::from_slice(&[v578_6_byte]);
    let v579_2: Space = singleton(&(v578_6_head));
    let v579_3: Space = intersect(&(*CONSTANT_1),&(v579_2));
    let v579_4: Space = if has_head(&(v579_3)) { singleton(&[]) } else { Space::new() };
    drop(v579_3);
    let v579_5: Space = subtract(&(*CONSTANT_0),&(v579_4));
    drop(v579_4);
    let mut v579_6 = Space::new();
    let mut v579_6_cursor = (v578_6_tail).read_zipper();
    for v579_6_byte in v579_6_cursor.child_mask().iter() {
      v579_6_cursor.descend_to_byte(v579_6_byte);
      let v579_6_tail = v579_6_cursor.make_map();
      v579_6_cursor.ascend(1);
      let v579_6_head = Path::from_slice(&[v579_6_byte]);
      let v580_2: Space = Space::new();
      v579_6.join_into((v580_2).clone());
    }
    drop(v579_6_cursor);
    let v579_7: Space = compose(&(v579_5),&(v579_6));
    drop(v579_5);
    drop(v579_6);
    let v579_8: Space = intersect(&(*CONSTANT_1),&(v579_2));
    drop(v579_2);
    let v579_9: Space = if has_head(&(v579_8)) { singleton(&[]) } else { Space::new() };
    drop(v579_8);
    let v579_12: Space = if (v579_9).is_empty() { Space::new() } else {
      let v581_10: Path = concat_path(&(*p0),&(v578_6_head));
      let mut v581_11 = Space::new();
      let mut v581_11_cursor = (v578_6_tail).read_zipper();
      for v581_11_byte in v581_11_cursor.child_mask().iter() {
        v581_11_cursor.descend_to_byte(v581_11_byte);
        let v581_11_tail = v581_11_cursor.make_map();
        v581_11_cursor.ascend(1);
        let v581_11_head = Path::from_slice(&[v581_11_byte]);
        let v582_2: Space = singleton(&(v581_11_head));
        let v582_3: Space = intersect(&(*CONSTANT_1),&(v582_2));
        drop(v582_2);
        let v582_4: Space = if has_head(&(v582_3)) { singleton(&[]) } else { Space::new() };
        drop(v582_3);
        let v582_7: Space = if (v582_4).is_empty() { Space::new() } else {
          let v583_5: Path = concat_path(&(v581_10),&(v581_11_head));
          let v583_6: Space = routine_17(c, &(v583_5), &(v581_11_tail));
          drop(v583_5);
          compose(&(v582_4),&(v583_6))
        };
        drop(v582_4);
        v581_11.join_into((v582_7).clone());
      }
      drop(v581_11_cursor);
      drop(v581_10);
      compose(&(v579_9),&(v581_11))
    };
    drop(v579_9);
    let v579_13: Space = unite(&(v579_7),&(v579_12));
    drop(v579_7);
    v578_6.join_into((v579_13).clone());
  }
  drop(v578_6_cursor);
  (v578_6).clone()
}

fn routine_69(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v584_5 = Space::new();
  let mut v584_5_cursor = (*s0).read_zipper();
  for v584_5_byte in v584_5_cursor.child_mask().iter() {
    v584_5_cursor.descend_to_byte(v584_5_byte);
    let v584_5_tail = v584_5_cursor.make_map();
    v584_5_cursor.ascend(1);
    let v584_5_head = Path::from_slice(&[v584_5_byte]);
    let v585_2: Space = singleton(&(v584_5_head));
    let v585_3: Space = intersect(&(*CONSTANT_1),&(v585_2));
    let v585_4: Space = if has_head(&(v585_3)) { singleton(&[]) } else { Space::new() };
    drop(v585_3);
    let v585_5: Space = subtract(&(*CONSTANT_0),&(v585_4));
    drop(v585_4);
    let mut v585_6 = Space::new();
    let mut v585_6_cursor = (v584_5_tail).read_zipper();
    for v585_6_byte in v585_6_cursor.child_mask().iter() {
      v585_6_cursor.descend_to_byte(v585_6_byte);
      let v585_6_tail = v585_6_cursor.make_map();
      v585_6_cursor.ascend(1);
      let v585_6_head = Path::from_slice(&[v585_6_byte]);
      let v586_2: Space = Space::new();
      v585_6.join_into((v586_2).clone());
    }
    drop(v585_6_cursor);
    let v585_7: Space = compose(&(v585_5),&(v585_6));
    drop(v585_5);
    drop(v585_6);
    let v585_8: Space = intersect(&(*CONSTANT_1),&(v585_2));
    drop(v585_2);
    let v585_9: Space = if has_head(&(v585_8)) { singleton(&[]) } else { Space::new() };
    drop(v585_8);
    let v585_10: Space = compose(&(v585_9),&(v584_5_tail));
    drop(v585_9);
    let v585_11: Space = unite(&(v585_7),&(v585_10));
    drop(v585_7);
    drop(v585_10);
    v584_5.join_into((v585_11).clone());
  }
  drop(v584_5_cursor);
  (v584_5).clone()
}

fn routine_70(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v587_2 = Space::new();
  let mut v587_2_cursor = (*s0).read_zipper();
  for v587_2_byte in v587_2_cursor.child_mask().iter() {
    v587_2_cursor.descend_to_byte(v587_2_byte);
    let v587_2_tail = v587_2_cursor.make_map();
    v587_2_cursor.ascend(1);
    let v587_2_head = Path::from_slice(&[v587_2_byte]);
    let v588_2: Space = Space::new();
    v587_2.join_into((v588_2).clone());
  }
  drop(v587_2_cursor);
  (v587_2).clone()
}

fn routine_71(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v589_3 = Space::new();
  let mut v589_3_cursor = (*s0).read_zipper();
  for v589_3_byte in v589_3_cursor.child_mask().iter() {
    v589_3_cursor.descend_to_byte(v589_3_byte);
    let v589_3_tail = v589_3_cursor.make_map();
    v589_3_cursor.ascend(1);
    let v589_3_head = Path::from_slice(&[v589_3_byte]);
    let v590_2: Space = singleton(&(v589_3_head));
    let v590_3: Space = intersect(&(*CONSTANT_1),&(v590_2));
    drop(v590_2);
    let v590_4: Space = if has_head(&(v590_3)) { singleton(&[]) } else { Space::new() };
    drop(v590_3);
    let v590_5: Space = compose(&(v590_4),&(v589_3_tail));
    drop(v590_4);
    v589_3.join_into((v590_5).clone());
  }
  drop(v589_3_cursor);
  (v589_3).clone()
}

fn routine_72(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v591_2 = Space::new();
  let mut v591_2_cursor = (*s0).read_zipper();
  for v591_2_byte in v591_2_cursor.child_mask().iter() {
    v591_2_cursor.descend_to_byte(v591_2_byte);
    let v591_2_tail = v591_2_cursor.make_map();
    v591_2_cursor.ascend(1);
    let v591_2_head = Path::from_slice(&[v591_2_byte]);
    let v592_2: Space = Space::new();
    v591_2.join_into((v592_2).clone());
  }
  drop(v591_2_cursor);
  (v591_2).clone()
}

fn routine_73(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v593_3 = Space::new();
  let mut v593_3_cursor = (*s0).read_zipper();
  for v593_3_byte in v593_3_cursor.child_mask().iter() {
    v593_3_cursor.descend_to_byte(v593_3_byte);
    let v593_3_tail = v593_3_cursor.make_map();
    v593_3_cursor.ascend(1);
    let v593_3_head = Path::from_slice(&[v593_3_byte]);
    let v594_2: Space = singleton(&(v593_3_head));
    let v594_3: Space = intersect(&(*CONSTANT_1),&(v594_2));
    drop(v594_2);
    let v594_4: Space = if has_head(&(v594_3)) { singleton(&[]) } else { Space::new() };
    drop(v594_3);
    let v594_5: Space = compose(&(v594_4),&(v593_3_tail));
    drop(v594_4);
    v593_3.join_into((v594_5).clone());
  }
  drop(v593_3_cursor);
  (v593_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
