#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,0,1,0,0,0,1,0,1,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let mut v0_12 = Space::new();
  let mut v0_12_cursor = (v0_2).read_zipper();
  for v0_12_byte in v0_12_cursor.child_mask().iter() {
    v0_12_cursor.descend_to_byte(v0_12_byte);
    let v0_12_tail = v0_12_cursor.make_map();
    v0_12_cursor.ascend(1);
    let v0_12_head = Path::from_slice(&[v0_12_byte]);
    let v1_2: Space = singleton(&(v0_12_head));
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_12_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        let v2_6_tail = v2_6_cursor.make_map();
        v2_6_cursor.ascend(1);
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_12_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail), &(*s0.expect("unbound native input")));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_12_head),&(v2_6_head));
          let v5_11: Space = routine_2(c, &(v5_6), &(v2_6_tail), &(*s0.expect("unbound native input")));
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_cursor = (v0_12_tail).read_zipper();
      for v6_10_byte in v6_10_cursor.child_mask().iter() {
        v6_10_cursor.descend_to_byte(v6_10_byte);
        let v6_10_tail = v6_10_cursor.make_map();
        v6_10_cursor.ascend(1);
        let v6_10_head = Path::from_slice(&[v6_10_byte]);
        let v7_2: Space = singleton(&(v6_10_head));
        let v7_3: Space = intersect(&(*CONSTANT_2),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_1),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_12_head),&(v6_10_head));
          let v8_7: Space = routine_1(c, &(v8_6), &(v6_10_tail), &(*s0.expect("unbound native input")));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_2),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v0_12_head),&(v6_10_head));
          let v9_11: Space = routine_3(c, &(v9_6), &(v6_10_tail), &(*s0.expect("unbound native input")));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_10.join_into((v7_13).clone());
      }
      drop(v6_10_cursor);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_12.join_into((v1_12).clone());
  }
  drop(v0_12_cursor);
  drop(v0_2);
  let v0_14: Space = wrap(&(v0_12),&(*CONSTANT_3));
  (v0_14).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v10_12 = Space::new();
  let mut v10_12_cursor = (*s0).read_zipper();
  for v10_12_byte in v10_12_cursor.child_mask().iter() {
    v10_12_cursor.descend_to_byte(v10_12_byte);
    let v10_12_tail = v10_12_cursor.make_map();
    v10_12_cursor.ascend(1);
    let v10_12_head = Path::from_slice(&[v10_12_byte]);
    let v11_2: Space = singleton(&(v10_12_head));
    let v11_3: Space = intersect(&(*CONSTANT_2),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_1),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&(v10_12_head));
      let mut v12_7 = Space::new();
      let mut v12_7_cursor = (v10_12_tail).read_zipper();
      for v12_7_byte in v12_7_cursor.child_mask().iter() {
        v12_7_cursor.descend_to_byte(v12_7_byte);
        let v12_7_tail = v12_7_cursor.make_map();
        v12_7_cursor.ascend(1);
        let v12_7_head = Path::from_slice(&[v12_7_byte]);
        let v13_2: Space = singleton(&(v12_7_head));
        let v13_3: Space = intersect(&(*CONSTANT_2),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_1),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let v14_7: Space = routine_4(c, &(v14_6), &(v12_7_tail), &(*s1));
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_2),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
          let v15_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let v15_11: Space = routine_5(c, &(v15_6), &(v12_7_tail), &(*s1));
          drop(v15_6);
          compose(&(v13_10),&(v15_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        v12_7.join_into((v13_13).clone());
      }
      drop(v12_7_cursor);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_2),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_12: Space = if (v11_10).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v10_12_head));
      let mut v16_11 = Space::new();
      let mut v16_11_cursor = (v10_12_tail).read_zipper();
      for v16_11_byte in v16_11_cursor.child_mask().iter() {
        v16_11_cursor.descend_to_byte(v16_11_byte);
        let v16_11_tail = v16_11_cursor.make_map();
        v16_11_cursor.ascend(1);
        let v16_11_head = Path::from_slice(&[v16_11_byte]);
        let v17_2: Space = singleton(&(v16_11_head));
        let v17_3: Space = intersect(&(*CONSTANT_2),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_1),&(v17_4));
        drop(v17_4);
        let v17_8: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v16_6),&(v16_11_head));
          let v18_7: Space = routine_4(c, &(v18_6), &(v16_11_tail), &(*s1));
          compose(&(v17_5),&(v18_7))
        };
        drop(v17_5);
        let v17_9: Space = intersect(&(*CONSTANT_2),&(v17_2));
        drop(v17_2);
        let v17_10: Space = if has_head(&(v17_9)) { singleton(&[]) } else { Space::new() };
        drop(v17_9);
        let v17_12: Space = if (v17_10).is_empty() { Space::new() } else {
          let v19_6: Path = concat_path(&(v16_6),&(v16_11_head));
          let v19_11: Space = routine_3(c, &(v19_6), &(v16_11_tail), &(*s1));
          drop(v19_6);
          compose(&(v17_10),&(v19_11))
        };
        drop(v17_10);
        let v17_13: Space = unite(&(v17_8),&(v17_12));
        v16_11.join_into((v17_13).clone());
      }
      drop(v16_11_cursor);
      drop(v16_6);
      compose(&(v11_10),&(v16_11))
    };
    drop(v11_10);
    let v11_13: Space = unite(&(v11_8),&(v11_12));
    v10_12.join_into((v11_13).clone());
  }
  drop(v10_12_cursor);
  (v10_12).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v20_12 = Space::new();
  let mut v20_12_cursor = (*s0).read_zipper();
  for v20_12_byte in v20_12_cursor.child_mask().iter() {
    v20_12_cursor.descend_to_byte(v20_12_byte);
    let v20_12_tail = v20_12_cursor.make_map();
    v20_12_cursor.ascend(1);
    let v20_12_head = Path::from_slice(&[v20_12_byte]);
    let v21_2: Space = singleton(&(v20_12_head));
    let v21_3: Space = intersect(&(*CONSTANT_2),&(v21_2));
    let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
    drop(v21_3);
    let v21_5: Space = subtract(&(*CONSTANT_1),&(v21_4));
    drop(v21_4);
    let v21_8: Space = if (v21_5).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&(v20_12_head));
      let mut v22_7 = Space::new();
      let mut v22_7_cursor = (v20_12_tail).read_zipper();
      for v22_7_byte in v22_7_cursor.child_mask().iter() {
        v22_7_cursor.descend_to_byte(v22_7_byte);
        let v22_7_tail = v22_7_cursor.make_map();
        v22_7_cursor.ascend(1);
        let v22_7_head = Path::from_slice(&[v22_7_byte]);
        let v23_2: Space = singleton(&(v22_7_head));
        let v23_3: Space = intersect(&(*CONSTANT_2),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_1),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&(v22_7_head));
          let v24_7: Space = routine_4(c, &(v24_6), &(v22_7_tail), &(*s1));
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_2),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_12: Space = if (v23_10).is_empty() { Space::new() } else {
          let v25_6: Path = concat_path(&(v22_6),&(v22_7_head));
          let v25_11: Space = routine_5(c, &(v25_6), &(v22_7_tail), &(*s1));
          drop(v25_6);
          compose(&(v23_10),&(v25_11))
        };
        drop(v23_10);
        let v23_13: Space = unite(&(v23_8),&(v23_12));
        v22_7.join_into((v23_13).clone());
      }
      drop(v22_7_cursor);
      compose(&(v21_5),&(v22_7))
    };
    drop(v21_5);
    let v21_9: Space = intersect(&(*CONSTANT_2),&(v21_2));
    drop(v21_2);
    let v21_10: Space = if has_head(&(v21_9)) { singleton(&[]) } else { Space::new() };
    drop(v21_9);
    let v21_12: Space = if (v21_10).is_empty() { Space::new() } else {
      let v26_6: Path = concat_path(&(*p0),&(v20_12_head));
      let mut v26_11 = Space::new();
      let mut v26_11_cursor = (v20_12_tail).read_zipper();
      for v26_11_byte in v26_11_cursor.child_mask().iter() {
        v26_11_cursor.descend_to_byte(v26_11_byte);
        let v26_11_tail = v26_11_cursor.make_map();
        v26_11_cursor.ascend(1);
        let v26_11_head = Path::from_slice(&[v26_11_byte]);
        let v27_2: Space = singleton(&(v26_11_head));
        let v27_3: Space = intersect(&(*CONSTANT_2),&(v27_2));
        let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
        drop(v27_3);
        let v27_5: Space = subtract(&(*CONSTANT_1),&(v27_4));
        drop(v27_4);
        let v27_7: Space = if (v27_5).is_empty() { Space::new() } else {
          let v28_6: Space = routine_6(c, &(v26_11_head), &(v26_6), &(v26_11_tail), &(*s1));
          compose(&(v27_5),&(v28_6))
        };
        drop(v27_5);
        let v27_8: Space = intersect(&(*CONSTANT_2),&(v27_2));
        drop(v27_2);
        let v27_9: Space = if has_head(&(v27_8)) { singleton(&[]) } else { Space::new() };
        drop(v27_8);
        let v27_11: Space = if (v27_9).is_empty() { Space::new() } else {
          let v29_10: Space = routine_7(c, &(v26_11_head), &(v26_6), &(v26_11_tail), &(*s1));
          compose(&(v27_9),&(v29_10))
        };
        drop(v27_9);
        let v27_12: Space = unite(&(v27_7),&(v27_11));
        v26_11.join_into((v27_12).clone());
      }
      drop(v26_11_cursor);
      drop(v26_6);
      compose(&(v21_10),&(v26_11))
    };
    drop(v21_10);
    let v21_13: Space = unite(&(v21_8),&(v21_12));
    v20_12.join_into((v21_13).clone());
  }
  drop(v20_12_cursor);
  (v20_12).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v30_12 = Space::new();
  let mut v30_12_cursor = (*s0).read_zipper();
  for v30_12_byte in v30_12_cursor.child_mask().iter() {
    v30_12_cursor.descend_to_byte(v30_12_byte);
    let v30_12_tail = v30_12_cursor.make_map();
    v30_12_cursor.ascend(1);
    let v30_12_head = Path::from_slice(&[v30_12_byte]);
    let v31_2: Space = singleton(&(v30_12_head));
    let v31_3: Space = intersect(&(*CONSTANT_2),&(v31_2));
    let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
    drop(v31_3);
    let v31_5: Space = subtract(&(*CONSTANT_1),&(v31_4));
    drop(v31_4);
    let v31_7: Space = if (v31_5).is_empty() { Space::new() } else {
      let mut v32_6 = Space::new();
      let mut v32_6_cursor = (v30_12_tail).read_zipper();
      for v32_6_byte in v32_6_cursor.child_mask().iter() {
        v32_6_cursor.descend_to_byte(v32_6_byte);
        let v32_6_tail = v32_6_cursor.make_map();
        v32_6_cursor.ascend(1);
        let v32_6_head = Path::from_slice(&[v32_6_byte]);
        let v33_2: Space = singleton(&(v32_6_head));
        let v33_3: Space = intersect(&(*CONSTANT_2),&(v33_2));
        let v33_4: Space = if has_head(&(v33_3)) { singleton(&[]) } else { Space::new() };
        drop(v33_3);
        let v33_5: Space = subtract(&(*CONSTANT_1),&(v33_4));
        drop(v33_4);
        let v33_8: Space = if (v33_5).is_empty() { Space::new() } else {
          let v34_6: Path = concat_path(&(v30_12_head),&(v32_6_head));
          let v34_7: Space = routine_8(c, &(v34_6), &(*p0), &(v32_6_tail), &(*s1));
          compose(&(v33_5),&(v34_7))
        };
        drop(v33_5);
        let v33_9: Space = intersect(&(*CONSTANT_2),&(v33_2));
        drop(v33_2);
        let v33_10: Space = if has_head(&(v33_9)) { singleton(&[]) } else { Space::new() };
        drop(v33_9);
        let v33_12: Space = if (v33_10).is_empty() { Space::new() } else {
          let v35_6: Path = concat_path(&(v30_12_head),&(v32_6_head));
          let v35_11: Space = routine_9(c, &(v35_6), &(*p0), &(v32_6_tail), &(*s1));
          drop(v35_6);
          compose(&(v33_10),&(v35_11))
        };
        drop(v33_10);
        let v33_13: Space = unite(&(v33_8),&(v33_12));
        v32_6.join_into((v33_13).clone());
      }
      drop(v32_6_cursor);
      compose(&(v31_5),&(v32_6))
    };
    drop(v31_5);
    let v31_8: Space = intersect(&(*CONSTANT_2),&(v31_2));
    drop(v31_2);
    let v31_9: Space = if has_head(&(v31_8)) { singleton(&[]) } else { Space::new() };
    drop(v31_8);
    let v31_11: Space = if (v31_9).is_empty() { Space::new() } else {
      let mut v36_10 = Space::new();
      let mut v36_10_cursor = (v30_12_tail).read_zipper();
      for v36_10_byte in v36_10_cursor.child_mask().iter() {
        v36_10_cursor.descend_to_byte(v36_10_byte);
        let v36_10_tail = v36_10_cursor.make_map();
        v36_10_cursor.ascend(1);
        let v36_10_head = Path::from_slice(&[v36_10_byte]);
        let v37_2: Space = singleton(&(v36_10_head));
        let v37_3: Space = intersect(&(*CONSTANT_2),&(v37_2));
        let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
        drop(v37_3);
        let v37_5: Space = subtract(&(*CONSTANT_1),&(v37_4));
        drop(v37_4);
        let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
          let v38_6: Path = concat_path(&(v30_12_head),&(v36_10_head));
          let v38_7: Space = routine_8(c, &(v38_6), &(*p0), &(v36_10_tail), &(*s1));
          compose(&(v37_5),&(v38_7))
        };
        drop(v37_5);
        let v37_9: Space = intersect(&(*CONSTANT_2),&(v37_2));
        drop(v37_2);
        let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
        drop(v37_9);
        let v37_12: Space = if (v37_10).is_empty() { Space::new() } else {
          let v39_6: Path = concat_path(&(v30_12_head),&(v36_10_head));
          let v39_11: Space = routine_10(c, &(v39_6), &(*p0), &(v36_10_tail), &(*s1));
          drop(v39_6);
          compose(&(v37_10),&(v39_11))
        };
        drop(v37_10);
        let v37_13: Space = unite(&(v37_8),&(v37_12));
        v36_10.join_into((v37_13).clone());
      }
      drop(v36_10_cursor);
      compose(&(v31_9),&(v36_10))
    };
    drop(v31_9);
    let v31_12: Space = unite(&(v31_7),&(v31_11));
    v30_12.join_into((v31_12).clone());
  }
  drop(v30_12_cursor);
  (v30_12).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v40_12 = Space::new();
  let mut v40_12_cursor = (*s0).read_zipper();
  for v40_12_byte in v40_12_cursor.child_mask().iter() {
    v40_12_cursor.descend_to_byte(v40_12_byte);
    let v40_12_tail = v40_12_cursor.make_map();
    v40_12_cursor.ascend(1);
    let v40_12_head = Path::from_slice(&[v40_12_byte]);
    let v41_2: Space = singleton(&(v40_12_head));
    let v41_3: Space = intersect(&(*CONSTANT_2),&(v41_2));
    let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
    drop(v41_3);
    let v41_5: Space = subtract(&(*CONSTANT_1),&(v41_4));
    drop(v41_4);
    let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
      let v42_6: Path = concat_path(&(*p0),&(v40_12_head));
      let mut v42_7 = Space::new();
      let mut v42_7_cursor = (v40_12_tail).read_zipper();
      for v42_7_byte in v42_7_cursor.child_mask().iter() {
        v42_7_cursor.descend_to_byte(v42_7_byte);
        let v42_7_tail = v42_7_cursor.make_map();
        v42_7_cursor.ascend(1);
        let v42_7_head = Path::from_slice(&[v42_7_byte]);
        let v43_2: Space = singleton(&(v42_7_head));
        let v43_3: Space = intersect(&(*CONSTANT_2),&(v43_2));
        let v43_4: Space = if has_head(&(v43_3)) { singleton(&[]) } else { Space::new() };
        drop(v43_3);
        let v43_5: Space = subtract(&(*CONSTANT_1),&(v43_4));
        drop(v43_4);
        let v43_8: Space = if (v43_5).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v42_6),&(v42_7_head));
          let v44_7: Space = routine_11(c, &(v44_6), &(v42_7_tail), &(*s1));
          compose(&(v43_5),&(v44_7))
        };
        drop(v43_5);
        let v43_9: Space = intersect(&(*CONSTANT_2),&(v43_2));
        drop(v43_2);
        let v43_10: Space = if has_head(&(v43_9)) { singleton(&[]) } else { Space::new() };
        drop(v43_9);
        let v43_12: Space = if (v43_10).is_empty() { Space::new() } else {
          let v45_6: Path = concat_path(&(v42_6),&(v42_7_head));
          let v45_11: Space = routine_12(c, &(v45_6), &(v42_7_tail), &(*s1));
          drop(v45_6);
          compose(&(v43_10),&(v45_11))
        };
        drop(v43_10);
        let v43_13: Space = unite(&(v43_8),&(v43_12));
        v42_7.join_into((v43_13).clone());
      }
      drop(v42_7_cursor);
      compose(&(v41_5),&(v42_7))
    };
    drop(v41_5);
    let v41_9: Space = intersect(&(*CONSTANT_2),&(v41_2));
    drop(v41_2);
    let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
    drop(v41_9);
    let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&(v40_12_head));
      let mut v46_11 = Space::new();
      let mut v46_11_cursor = (v40_12_tail).read_zipper();
      for v46_11_byte in v46_11_cursor.child_mask().iter() {
        v46_11_cursor.descend_to_byte(v46_11_byte);
        let v46_11_tail = v46_11_cursor.make_map();
        v46_11_cursor.ascend(1);
        let v46_11_head = Path::from_slice(&[v46_11_byte]);
        let v47_2: Space = singleton(&(v46_11_head));
        let v47_3: Space = intersect(&(*CONSTANT_2),&(v47_2));
        let v47_4: Space = if has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = subtract(&(*CONSTANT_1),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (v47_5).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&(v46_11_head));
          let v48_7: Space = routine_11(c, &(v48_6), &(v46_11_tail), &(*s1));
          compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = intersect(&(*CONSTANT_2),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (v47_10).is_empty() { Space::new() } else {
          let v49_6: Path = concat_path(&(v46_6),&(v46_11_head));
          let v49_11: Space = routine_3(c, &(v49_6), &(v46_11_tail), &(*s1));
          drop(v49_6);
          compose(&(v47_10),&(v49_11))
        };
        drop(v47_10);
        let v47_13: Space = unite(&(v47_8),&(v47_12));
        v46_11.join_into((v47_13).clone());
      }
      drop(v46_11_cursor);
      drop(v46_6);
      compose(&(v41_10),&(v46_11))
    };
    drop(v41_10);
    let v41_13: Space = unite(&(v41_8),&(v41_12));
    v40_12.join_into((v41_13).clone());
  }
  drop(v40_12_cursor);
  (v40_12).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v50_12 = Space::new();
  let mut v50_12_cursor = (*s0).read_zipper();
  for v50_12_byte in v50_12_cursor.child_mask().iter() {
    v50_12_cursor.descend_to_byte(v50_12_byte);
    let v50_12_tail = v50_12_cursor.make_map();
    v50_12_cursor.ascend(1);
    let v50_12_head = Path::from_slice(&[v50_12_byte]);
    let v51_2: Space = singleton(&(v50_12_head));
    let v51_3: Space = intersect(&(*CONSTANT_2),&(v51_2));
    let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
    drop(v51_3);
    let v51_5: Space = subtract(&(*CONSTANT_1),&(v51_4));
    drop(v51_4);
    let v51_8: Space = if (v51_5).is_empty() { Space::new() } else {
      let v52_6: Path = concat_path(&(*p0),&(v50_12_head));
      let mut v52_7 = Space::new();
      let mut v52_7_cursor = (v50_12_tail).read_zipper();
      for v52_7_byte in v52_7_cursor.child_mask().iter() {
        v52_7_cursor.descend_to_byte(v52_7_byte);
        let v52_7_tail = v52_7_cursor.make_map();
        v52_7_cursor.ascend(1);
        let v52_7_head = Path::from_slice(&[v52_7_byte]);
        let v53_2: Space = singleton(&(v52_7_head));
        let v53_3: Space = intersect(&(*CONSTANT_2),&(v53_2));
        let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
        drop(v53_3);
        let v53_5: Space = subtract(&(*CONSTANT_1),&(v53_4));
        drop(v53_4);
        let v53_8: Space = if (v53_5).is_empty() { Space::new() } else {
          let v54_6: Path = concat_path(&(v52_6),&(v52_7_head));
          let v54_7: Space = routine_11(c, &(v54_6), &(v52_7_tail), &(*s1));
          compose(&(v53_5),&(v54_7))
        };
        drop(v53_5);
        let v53_9: Space = intersect(&(*CONSTANT_2),&(v53_2));
        drop(v53_2);
        let v53_10: Space = if has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
        drop(v53_9);
        let v53_12: Space = if (v53_10).is_empty() { Space::new() } else {
          let v55_6: Path = concat_path(&(v52_6),&(v52_7_head));
          let v55_11: Space = routine_12(c, &(v55_6), &(v52_7_tail), &(*s1));
          drop(v55_6);
          compose(&(v53_10),&(v55_11))
        };
        drop(v53_10);
        let v53_13: Space = unite(&(v53_8),&(v53_12));
        v52_7.join_into((v53_13).clone());
      }
      drop(v52_7_cursor);
      compose(&(v51_5),&(v52_7))
    };
    drop(v51_5);
    let v51_9: Space = intersect(&(*CONSTANT_2),&(v51_2));
    drop(v51_2);
    let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
    drop(v51_9);
    let v51_12: Space = if (v51_10).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&(v50_12_head));
      let mut v56_11 = Space::new();
      let mut v56_11_cursor = (v50_12_tail).read_zipper();
      for v56_11_byte in v56_11_cursor.child_mask().iter() {
        v56_11_cursor.descend_to_byte(v56_11_byte);
        let v56_11_tail = v56_11_cursor.make_map();
        v56_11_cursor.ascend(1);
        let v56_11_head = Path::from_slice(&[v56_11_byte]);
        let v57_2: Space = singleton(&(v56_11_head));
        let v57_3: Space = intersect(&(*CONSTANT_2),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_1),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (v57_5).is_empty() { Space::new() } else {
          let v58_6: Space = routine_6(c, &(v56_11_head), &(v56_6), &(v56_11_tail), &(*s1));
          compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = intersect(&(*CONSTANT_2),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (v57_9).is_empty() { Space::new() } else {
          let v59_10: Space = routine_7(c, &(v56_11_head), &(v56_6), &(v56_11_tail), &(*s1));
          compose(&(v57_9),&(v59_10))
        };
        drop(v57_9);
        let v57_12: Space = unite(&(v57_7),&(v57_11));
        v56_11.join_into((v57_12).clone());
      }
      drop(v56_11_cursor);
      drop(v56_6);
      compose(&(v51_10),&(v56_11))
    };
    drop(v51_10);
    let v51_13: Space = unite(&(v51_8),&(v51_12));
    v50_12.join_into((v51_13).clone());
  }
  drop(v50_12_cursor);
  (v50_12).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v60_13 = Space::new();
  let mut v60_13_cursor = (*s0).read_zipper();
  for v60_13_byte in v60_13_cursor.child_mask().iter() {
    v60_13_cursor.descend_to_byte(v60_13_byte);
    let v60_13_tail = v60_13_cursor.make_map();
    v60_13_cursor.ascend(1);
    let v60_13_head = Path::from_slice(&[v60_13_byte]);
    let v61_2: Space = singleton(&(v60_13_head));
    let v61_3: Space = intersect(&(*CONSTANT_2),&(v61_2));
    let v61_4: Space = if has_head(&(v61_3)) { singleton(&[]) } else { Space::new() };
    drop(v61_3);
    let v61_5: Space = subtract(&(*CONSTANT_1),&(v61_4));
    drop(v61_4);
    let v61_8: Space = if (v61_5).is_empty() { Space::new() } else {
      let v62_6: Path = concat_path(&(*p0),&(v60_13_head));
      let mut v62_7 = Space::new();
      let mut v62_7_cursor = (v60_13_tail).read_zipper();
      for v62_7_byte in v62_7_cursor.child_mask().iter() {
        v62_7_cursor.descend_to_byte(v62_7_byte);
        let v62_7_tail = v62_7_cursor.make_map();
        v62_7_cursor.ascend(1);
        let v62_7_head = Path::from_slice(&[v62_7_byte]);
        let v63_2: Space = singleton(&(v62_7_head));
        let v63_3: Space = intersect(&(*CONSTANT_2),&(v63_2));
        let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
        drop(v63_3);
        let v63_5: Space = subtract(&(*CONSTANT_1),&(v63_4));
        drop(v63_4);
        let v63_8: Space = if (v63_5).is_empty() { Space::new() } else {
          let v64_6: Path = concat_path(&(v62_6),&(v62_7_head));
          let v64_7: Space = routine_13(c, &(v64_6), &(*p1), &(v62_7_tail), &(*s1));
          compose(&(v63_5),&(v64_7))
        };
        drop(v63_5);
        let v63_9: Space = intersect(&(*CONSTANT_2),&(v63_2));
        drop(v63_2);
        let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
        drop(v63_9);
        let v63_12: Space = if (v63_10).is_empty() { Space::new() } else {
          let v65_6: Path = concat_path(&(v62_6),&(v62_7_head));
          let v65_11: Space = routine_14(c, &(v65_6), &(*p1), &(v62_7_tail), &(*s1));
          drop(v65_6);
          compose(&(v63_10),&(v65_11))
        };
        drop(v63_10);
        let v63_13: Space = unite(&(v63_8),&(v63_12));
        v62_7.join_into((v63_13).clone());
      }
      drop(v62_7_cursor);
      compose(&(v61_5),&(v62_7))
    };
    drop(v61_5);
    let v61_9: Space = intersect(&(*CONSTANT_2),&(v61_2));
    drop(v61_2);
    let v61_10: Space = if has_head(&(v61_9)) { singleton(&[]) } else { Space::new() };
    drop(v61_9);
    let v61_12: Space = if (v61_10).is_empty() { Space::new() } else {
      let v66_6: Path = concat_path(&(*p0),&(v60_13_head));
      let mut v66_11 = Space::new();
      let mut v66_11_cursor = (v60_13_tail).read_zipper();
      for v66_11_byte in v66_11_cursor.child_mask().iter() {
        v66_11_cursor.descend_to_byte(v66_11_byte);
        let v66_11_tail = v66_11_cursor.make_map();
        v66_11_cursor.ascend(1);
        let v66_11_head = Path::from_slice(&[v66_11_byte]);
        let v67_2: Space = singleton(&(v66_11_head));
        let v67_3: Space = intersect(&(*CONSTANT_2),&(v67_2));
        let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
        drop(v67_3);
        let v67_5: Space = subtract(&(*CONSTANT_1),&(v67_4));
        drop(v67_4);
        let v67_8: Space = if (v67_5).is_empty() { Space::new() } else {
          let v68_6: Path = concat_path(&(v66_6),&(v66_11_head));
          let v68_7: Space = routine_13(c, &(v68_6), &(*p1), &(v66_11_tail), &(*s1));
          compose(&(v67_5),&(v68_7))
        };
        drop(v67_5);
        let v67_9: Space = intersect(&(*CONSTANT_2),&(v67_2));
        drop(v67_2);
        let v67_10: Space = if has_head(&(v67_9)) { singleton(&[]) } else { Space::new() };
        drop(v67_9);
        let v67_12: Space = if (v67_10).is_empty() { Space::new() } else {
          let v69_6: Path = concat_path(&(v66_6),&(v66_11_head));
          let v69_11: Space = routine_10(c, &(v69_6), &(*p1), &(v66_11_tail), &(*s1));
          drop(v69_6);
          compose(&(v67_10),&(v69_11))
        };
        drop(v67_10);
        let v67_13: Space = unite(&(v67_8),&(v67_12));
        v66_11.join_into((v67_13).clone());
      }
      drop(v66_11_cursor);
      drop(v66_6);
      compose(&(v61_10),&(v66_11))
    };
    drop(v61_10);
    let v61_13: Space = unite(&(v61_8),&(v61_12));
    v60_13.join_into((v61_13).clone());
  }
  drop(v60_13_cursor);
  (v60_13).clone()
}

fn routine_7(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v70_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v70_9: Space = unwrap(&(v70_8),&(*p0));
  drop(v70_8);
  let mut v70_16 = Space::new();
  let mut v70_16_cursor = (*s0).read_zipper();
  for v70_16_byte in v70_16_cursor.child_mask().iter() {
    v70_16_cursor.descend_to_byte(v70_16_byte);
    let v70_16_tail = v70_16_cursor.make_map();
    v70_16_cursor.ascend(1);
    let v70_16_head = Path::from_slice(&[v70_16_byte]);
    let v71_2: Space = singleton(&(v70_16_head));
    let v71_3: Space = intersect(&(*CONSTANT_2),&(v71_2));
    let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
    drop(v71_3);
    let v71_5: Space = subtract(&(*CONSTANT_1),&(v71_4));
    drop(v71_4);
    let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
      let v72_6: Path = concat_path(&(*p0),&(v70_16_head));
      let mut v72_7 = Space::new();
      let mut v72_7_cursor = (v70_16_tail).read_zipper();
      for v72_7_byte in v72_7_cursor.child_mask().iter() {
        v72_7_cursor.descend_to_byte(v72_7_byte);
        let v72_7_tail = v72_7_cursor.make_map();
        v72_7_cursor.ascend(1);
        let v72_7_head = Path::from_slice(&[v72_7_byte]);
        let v73_2: Space = singleton(&(v72_7_head));
        let v73_3: Space = intersect(&(*CONSTANT_2),&(v73_2));
        let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
        drop(v73_3);
        let v73_5: Space = subtract(&(*CONSTANT_1),&(v73_4));
        drop(v73_4);
        let v73_8: Space = if (v73_5).is_empty() { Space::new() } else {
          let v74_6: Path = concat_path(&(v72_6),&(v72_7_head));
          let v74_7: Space = routine_13(c, &(v74_6), &(*p1), &(v72_7_tail), &(*s1));
          compose(&(v73_5),&(v74_7))
        };
        drop(v73_5);
        let v73_9: Space = intersect(&(*CONSTANT_2),&(v73_2));
        drop(v73_2);
        let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
        drop(v73_9);
        let v73_12: Space = if (v73_10).is_empty() { Space::new() } else {
          let v75_6: Path = concat_path(&(v72_6),&(v72_7_head));
          let v75_11: Space = routine_14(c, &(v75_6), &(*p1), &(v72_7_tail), &(*s1));
          drop(v75_6);
          compose(&(v73_10),&(v75_11))
        };
        drop(v73_10);
        let v73_13: Space = unite(&(v73_8),&(v73_12));
        v72_7.join_into((v73_13).clone());
      }
      drop(v72_7_cursor);
      drop(v72_6);
      compose(&(v71_5),&(v72_7))
    };
    drop(v71_5);
    let v71_9: Space = intersect(&(*CONSTANT_2),&(v71_2));
    drop(v71_2);
    let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
    drop(v71_9);
    let v71_13: Space = if (v71_10).is_empty() { Space::new() } else {
      let v76_11: Space = unwrap(&(v70_9),&(v70_16_head));
      let mut v76_12 = Space::new();
      let mut v76_12_cursor = (v76_11).read_zipper();
      for v76_12_byte in v76_12_cursor.child_mask().iter() {
        v76_12_cursor.descend_to_byte(v76_12_byte);
        let v76_12_tail = v76_12_cursor.make_map();
        v76_12_cursor.ascend(1);
        let v76_12_head = Path::from_slice(&[v76_12_byte]);
        let v77_2: Space = singleton(&(v76_12_head));
        let v77_3: Space = intersect(&(*CONSTANT_2),&(v77_2));
        let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
        drop(v77_3);
        let v77_5: Space = subtract(&(*CONSTANT_1),&(v77_4));
        drop(v77_4);
        let v77_7: Space = if (v77_5).is_empty() { Space::new() } else {
          let v78_6: Space = routine_15(c, &(v76_12_head), &(*p1), &(v76_12_tail));
          compose(&(v77_5),&(v78_6))
        };
        drop(v77_5);
        let v77_8: Space = intersect(&(*CONSTANT_2),&(v77_2));
        drop(v77_2);
        let v77_9: Space = if has_head(&(v77_8)) { singleton(&[]) } else { Space::new() };
        drop(v77_8);
        let v77_11: Space = if (v77_9).is_empty() { Space::new() } else {
          let v79_10: Space = routine_16(c, &(v76_12_head), &(*p1), &(v76_12_tail));
          compose(&(v77_9),&(v79_10))
        };
        drop(v77_9);
        let v77_12: Space = unite(&(v77_7),&(v77_11));
        v76_12.join_into((v77_12).clone());
      }
      drop(v76_12_cursor);
      drop(v76_11);
      compose(&(v71_10),&(v76_12))
    };
    drop(v71_10);
    let v71_14: Space = unite(&(v71_8),&(v71_13));
    v70_16.join_into((v71_14).clone());
  }
  drop(v70_16_cursor);
  drop(v70_9);
  (v70_16).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v80_13 = Space::new();
  let mut v80_13_cursor = (*s0).read_zipper();
  for v80_13_byte in v80_13_cursor.child_mask().iter() {
    v80_13_cursor.descend_to_byte(v80_13_byte);
    let v80_13_tail = v80_13_cursor.make_map();
    v80_13_cursor.ascend(1);
    let v80_13_head = Path::from_slice(&[v80_13_byte]);
    let v81_2: Space = singleton(&(v80_13_head));
    let v81_3: Space = intersect(&(*CONSTANT_2),&(v81_2));
    let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
    drop(v81_3);
    let v81_5: Space = subtract(&(*CONSTANT_1),&(v81_4));
    drop(v81_4);
    let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
      let v82_6: Path = concat_path(&(*p0),&(v80_13_head));
      let mut v82_7 = Space::new();
      let mut v82_7_cursor = (v80_13_tail).read_zipper();
      for v82_7_byte in v82_7_cursor.child_mask().iter() {
        v82_7_cursor.descend_to_byte(v82_7_byte);
        let v82_7_tail = v82_7_cursor.make_map();
        v82_7_cursor.ascend(1);
        let v82_7_head = Path::from_slice(&[v82_7_byte]);
        let v83_2: Space = singleton(&(v82_7_head));
        let v83_3: Space = intersect(&(*CONSTANT_2),&(v83_2));
        let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
        drop(v83_3);
        let v83_5: Space = subtract(&(*CONSTANT_1),&(v83_4));
        drop(v83_4);
        let v83_8: Space = if (v83_5).is_empty() { Space::new() } else {
          let v84_6: Path = concat_path(&(v82_6),&(v82_7_head));
          let v84_7: Space = routine_17(c, &(v84_6), &(*p1), &(v82_7_tail), &(*s1));
          compose(&(v83_5),&(v84_7))
        };
        drop(v83_5);
        let v83_9: Space = intersect(&(*CONSTANT_2),&(v83_2));
        drop(v83_2);
        let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
        drop(v83_9);
        let v83_12: Space = if (v83_10).is_empty() { Space::new() } else {
          let v85_6: Path = concat_path(&(v82_6),&(v82_7_head));
          let v85_11: Space = routine_18(c, &(v85_6), &(*p1), &(v82_7_tail), &(*s1));
          drop(v85_6);
          compose(&(v83_10),&(v85_11))
        };
        drop(v83_10);
        let v83_13: Space = unite(&(v83_8),&(v83_12));
        v82_7.join_into((v83_13).clone());
      }
      drop(v82_7_cursor);
      compose(&(v81_5),&(v82_7))
    };
    drop(v81_5);
    let v81_9: Space = intersect(&(*CONSTANT_2),&(v81_2));
    drop(v81_2);
    let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
    drop(v81_9);
    let v81_12: Space = if (v81_10).is_empty() { Space::new() } else {
      let v86_6: Path = concat_path(&(*p0),&(v80_13_head));
      let mut v86_11 = Space::new();
      let mut v86_11_cursor = (v80_13_tail).read_zipper();
      for v86_11_byte in v86_11_cursor.child_mask().iter() {
        v86_11_cursor.descend_to_byte(v86_11_byte);
        let v86_11_tail = v86_11_cursor.make_map();
        v86_11_cursor.ascend(1);
        let v86_11_head = Path::from_slice(&[v86_11_byte]);
        let v87_2: Space = singleton(&(v86_11_head));
        let v87_3: Space = intersect(&(*CONSTANT_2),&(v87_2));
        let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
        drop(v87_3);
        let v87_5: Space = subtract(&(*CONSTANT_1),&(v87_4));
        drop(v87_4);
        let v87_8: Space = if (v87_5).is_empty() { Space::new() } else {
          let v88_6: Path = concat_path(&(v86_6),&(v86_11_head));
          let v88_7: Space = routine_17(c, &(v88_6), &(*p1), &(v86_11_tail), &(*s1));
          compose(&(v87_5),&(v88_7))
        };
        drop(v87_5);
        let v87_9: Space = intersect(&(*CONSTANT_2),&(v87_2));
        drop(v87_2);
        let v87_10: Space = if has_head(&(v87_9)) { singleton(&[]) } else { Space::new() };
        drop(v87_9);
        let v87_12: Space = if (v87_10).is_empty() { Space::new() } else {
          let v89_6: Path = concat_path(&(v86_6),&(v86_11_head));
          let v89_11: Space = routine_10(c, &(v89_6), &(*p1), &(v86_11_tail), &(*s1));
          drop(v89_6);
          compose(&(v87_10),&(v89_11))
        };
        drop(v87_10);
        let v87_13: Space = unite(&(v87_8),&(v87_12));
        v86_11.join_into((v87_13).clone());
      }
      drop(v86_11_cursor);
      drop(v86_6);
      compose(&(v81_10),&(v86_11))
    };
    drop(v81_10);
    let v81_13: Space = unite(&(v81_8),&(v81_12));
    v80_13.join_into((v81_13).clone());
  }
  drop(v80_13_cursor);
  (v80_13).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v90_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v90_9: Space = unwrap(&(v90_8),&(*p0));
  drop(v90_8);
  let mut v90_16 = Space::new();
  let mut v90_16_cursor = (*s0).read_zipper();
  for v90_16_byte in v90_16_cursor.child_mask().iter() {
    v90_16_cursor.descend_to_byte(v90_16_byte);
    let v90_16_tail = v90_16_cursor.make_map();
    v90_16_cursor.ascend(1);
    let v90_16_head = Path::from_slice(&[v90_16_byte]);
    let v91_2: Space = singleton(&(v90_16_head));
    let v91_3: Space = intersect(&(*CONSTANT_2),&(v91_2));
    let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
    drop(v91_3);
    let v91_5: Space = subtract(&(*CONSTANT_1),&(v91_4));
    drop(v91_4);
    let v91_8: Space = if (v91_5).is_empty() { Space::new() } else {
      let v92_6: Path = concat_path(&(*p0),&(v90_16_head));
      let mut v92_7 = Space::new();
      let mut v92_7_cursor = (v90_16_tail).read_zipper();
      for v92_7_byte in v92_7_cursor.child_mask().iter() {
        v92_7_cursor.descend_to_byte(v92_7_byte);
        let v92_7_tail = v92_7_cursor.make_map();
        v92_7_cursor.ascend(1);
        let v92_7_head = Path::from_slice(&[v92_7_byte]);
        let v93_2: Space = singleton(&(v92_7_head));
        let v93_3: Space = intersect(&(*CONSTANT_2),&(v93_2));
        let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
        drop(v93_3);
        let v93_5: Space = subtract(&(*CONSTANT_1),&(v93_4));
        drop(v93_4);
        let v93_8: Space = if (v93_5).is_empty() { Space::new() } else {
          let v94_6: Path = concat_path(&(v92_6),&(v92_7_head));
          let v94_7: Space = routine_17(c, &(v94_6), &(*p1), &(v92_7_tail), &(*s1));
          compose(&(v93_5),&(v94_7))
        };
        drop(v93_5);
        let v93_9: Space = intersect(&(*CONSTANT_2),&(v93_2));
        drop(v93_2);
        let v93_10: Space = if has_head(&(v93_9)) { singleton(&[]) } else { Space::new() };
        drop(v93_9);
        let v93_12: Space = if (v93_10).is_empty() { Space::new() } else {
          let v95_6: Path = concat_path(&(v92_6),&(v92_7_head));
          let v95_11: Space = routine_18(c, &(v95_6), &(*p1), &(v92_7_tail), &(*s1));
          drop(v95_6);
          compose(&(v93_10),&(v95_11))
        };
        drop(v93_10);
        let v93_13: Space = unite(&(v93_8),&(v93_12));
        v92_7.join_into((v93_13).clone());
      }
      drop(v92_7_cursor);
      drop(v92_6);
      compose(&(v91_5),&(v92_7))
    };
    drop(v91_5);
    let v91_9: Space = intersect(&(*CONSTANT_2),&(v91_2));
    drop(v91_2);
    let v91_10: Space = if has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
    drop(v91_9);
    let v91_13: Space = if (v91_10).is_empty() { Space::new() } else {
      let v96_11: Space = unwrap(&(v90_9),&(v90_16_head));
      let mut v96_12 = Space::new();
      let mut v96_12_cursor = (v96_11).read_zipper();
      for v96_12_byte in v96_12_cursor.child_mask().iter() {
        v96_12_cursor.descend_to_byte(v96_12_byte);
        let v96_12_tail = v96_12_cursor.make_map();
        v96_12_cursor.ascend(1);
        let v96_12_head = Path::from_slice(&[v96_12_byte]);
        let v97_2: Space = singleton(&(v96_12_head));
        let v97_3: Space = intersect(&(*CONSTANT_2),&(v97_2));
        let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
        drop(v97_3);
        let v97_5: Space = subtract(&(*CONSTANT_1),&(v97_4));
        drop(v97_4);
        let v97_7: Space = if (v97_5).is_empty() { Space::new() } else {
          let v98_6: Space = routine_15(c, &(v96_12_head), &(*p1), &(v96_12_tail));
          compose(&(v97_5),&(v98_6))
        };
        drop(v97_5);
        let v97_8: Space = intersect(&(*CONSTANT_2),&(v97_2));
        drop(v97_2);
        let v97_9: Space = if has_head(&(v97_8)) { singleton(&[]) } else { Space::new() };
        drop(v97_8);
        let v97_11: Space = if (v97_9).is_empty() { Space::new() } else {
          let v99_10: Space = routine_16(c, &(v96_12_head), &(*p1), &(v96_12_tail));
          compose(&(v97_9),&(v99_10))
        };
        drop(v97_9);
        let v97_12: Space = unite(&(v97_7),&(v97_11));
        v96_12.join_into((v97_12).clone());
      }
      drop(v96_12_cursor);
      drop(v96_11);
      compose(&(v91_10),&(v96_12))
    };
    drop(v91_10);
    let v91_14: Space = unite(&(v91_8),&(v91_13));
    v90_16.join_into((v91_14).clone());
  }
  drop(v90_16_cursor);
  drop(v90_9);
  (v90_16).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v100_5: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v100_6: Space = unwrap(&(v100_5),&(*p0));
  drop(v100_5);
  let mut v100_16 = Space::new();
  let mut v100_16_cursor = (v100_6).read_zipper();
  for v100_16_byte in v100_16_cursor.child_mask().iter() {
    v100_16_cursor.descend_to_byte(v100_16_byte);
    let v100_16_tail = v100_16_cursor.make_map();
    v100_16_cursor.ascend(1);
    let v100_16_head = Path::from_slice(&[v100_16_byte]);
    let v101_2: Space = singleton(&(v100_16_head));
    let v101_3: Space = intersect(&(*CONSTANT_2),&(v101_2));
    let v101_4: Space = if has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
    drop(v101_3);
    let v101_5: Space = subtract(&(*CONSTANT_1),&(v101_4));
    drop(v101_4);
    let v101_7: Space = if (v101_5).is_empty() { Space::new() } else {
      let mut v102_6 = Space::new();
      let mut v102_6_cursor = (v100_16_tail).read_zipper();
      for v102_6_byte in v102_6_cursor.child_mask().iter() {
        v102_6_cursor.descend_to_byte(v102_6_byte);
        let v102_6_tail = v102_6_cursor.make_map();
        v102_6_cursor.ascend(1);
        let v102_6_head = Path::from_slice(&[v102_6_byte]);
        let v103_2: Space = singleton(&(v102_6_head));
        let v103_3: Space = intersect(&(*CONSTANT_2),&(v103_2));
        let v103_4: Space = if has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
        drop(v103_3);
        let v103_5: Space = subtract(&(*CONSTANT_1),&(v103_4));
        drop(v103_4);
        let v103_8: Space = if (v103_5).is_empty() { Space::new() } else {
          let v104_6: Path = concat_path(&(v100_16_head),&(v102_6_head));
          let v104_7: Space = routine_19(c, &(v104_6), &(*p1), &(v102_6_tail));
          compose(&(v103_5),&(v104_7))
        };
        drop(v103_5);
        let v103_9: Space = intersect(&(*CONSTANT_2),&(v103_2));
        drop(v103_2);
        let v103_10: Space = if has_head(&(v103_9)) { singleton(&[]) } else { Space::new() };
        drop(v103_9);
        let v103_12: Space = if (v103_10).is_empty() { Space::new() } else {
          let v105_6: Path = concat_path(&(v100_16_head),&(v102_6_head));
          let v105_11: Space = routine_20(c, &(v105_6), &(*p1), &(v102_6_tail));
          drop(v105_6);
          compose(&(v103_10),&(v105_11))
        };
        drop(v103_10);
        let v103_13: Space = unite(&(v103_8),&(v103_12));
        v102_6.join_into((v103_13).clone());
      }
      drop(v102_6_cursor);
      compose(&(v101_5),&(v102_6))
    };
    drop(v101_5);
    let v101_8: Space = intersect(&(*CONSTANT_2),&(v101_2));
    drop(v101_2);
    let v101_9: Space = if has_head(&(v101_8)) { singleton(&[]) } else { Space::new() };
    drop(v101_8);
    let v101_11: Space = if (v101_9).is_empty() { Space::new() } else {
      let mut v106_10 = Space::new();
      let mut v106_10_cursor = (v100_16_tail).read_zipper();
      for v106_10_byte in v106_10_cursor.child_mask().iter() {
        v106_10_cursor.descend_to_byte(v106_10_byte);
        let v106_10_tail = v106_10_cursor.make_map();
        v106_10_cursor.ascend(1);
        let v106_10_head = Path::from_slice(&[v106_10_byte]);
        let v107_2: Space = singleton(&(v106_10_head));
        let v107_3: Space = intersect(&(*CONSTANT_2),&(v107_2));
        let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
        drop(v107_3);
        let v107_5: Space = subtract(&(*CONSTANT_1),&(v107_4));
        drop(v107_4);
        let v107_8: Space = if (v107_5).is_empty() { Space::new() } else {
          let v108_6: Path = concat_path(&(v100_16_head),&(v106_10_head));
          let v108_7: Space = routine_19(c, &(v108_6), &(*p1), &(v106_10_tail));
          compose(&(v107_5),&(v108_7))
        };
        drop(v107_5);
        let v107_9: Space = intersect(&(*CONSTANT_2),&(v107_2));
        drop(v107_2);
        let v107_10: Space = if has_head(&(v107_9)) { singleton(&[]) } else { Space::new() };
        drop(v107_9);
        let v107_12: Space = if (v107_10).is_empty() { Space::new() } else {
          let v109_6: Path = concat_path(&(v100_16_head),&(v106_10_head));
          let v109_11: Space = routine_21(c, &(v109_6), &(*p1), &(v106_10_tail));
          drop(v109_6);
          compose(&(v107_10),&(v109_11))
        };
        drop(v107_10);
        let v107_13: Space = unite(&(v107_8),&(v107_12));
        v106_10.join_into((v107_13).clone());
      }
      drop(v106_10_cursor);
      compose(&(v101_9),&(v106_10))
    };
    drop(v101_9);
    let v101_12: Space = unite(&(v101_7),&(v101_11));
    v100_16.join_into((v101_12).clone());
  }
  drop(v100_16_cursor);
  drop(v100_6);
  (v100_16).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v110_12 = Space::new();
  let mut v110_12_cursor = (*s0).read_zipper();
  for v110_12_byte in v110_12_cursor.child_mask().iter() {
    v110_12_cursor.descend_to_byte(v110_12_byte);
    let v110_12_tail = v110_12_cursor.make_map();
    v110_12_cursor.ascend(1);
    let v110_12_head = Path::from_slice(&[v110_12_byte]);
    let v111_2: Space = singleton(&(v110_12_head));
    let v111_3: Space = intersect(&(*CONSTANT_2),&(v111_2));
    let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = subtract(&(*CONSTANT_1),&(v111_4));
    drop(v111_4);
    let v111_8: Space = if (v111_5).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&(v110_12_head));
      let mut v112_7 = Space::new();
      let mut v112_7_cursor = (v110_12_tail).read_zipper();
      for v112_7_byte in v112_7_cursor.child_mask().iter() {
        v112_7_cursor.descend_to_byte(v112_7_byte);
        let v112_7_tail = v112_7_cursor.make_map();
        v112_7_cursor.ascend(1);
        let v112_7_head = Path::from_slice(&[v112_7_byte]);
        let v113_2: Space = singleton(&(v112_7_head));
        let v113_3: Space = intersect(&(*CONSTANT_2),&(v113_2));
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = subtract(&(*CONSTANT_1),&(v113_4));
        drop(v113_4);
        let v113_8: Space = if (v113_5).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v112_6),&(v112_7_head));
          let v114_7: Space = routine_22(c, &(v114_6), &(v112_7_tail), &(*s1));
          compose(&(v113_5),&(v114_7))
        };
        drop(v113_5);
        let v113_9: Space = intersect(&(*CONSTANT_2),&(v113_2));
        drop(v113_2);
        let v113_10: Space = if has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
        drop(v113_9);
        let v113_12: Space = if (v113_10).is_empty() { Space::new() } else {
          let v115_6: Path = concat_path(&(v112_6),&(v112_7_head));
          let v115_11: Space = routine_23(c, &(v115_6), &(v112_7_tail), &(*s1));
          drop(v115_6);
          compose(&(v113_10),&(v115_11))
        };
        drop(v113_10);
        let v113_13: Space = unite(&(v113_8),&(v113_12));
        v112_7.join_into((v113_13).clone());
      }
      drop(v112_7_cursor);
      compose(&(v111_5),&(v112_7))
    };
    drop(v111_5);
    let v111_9: Space = intersect(&(*CONSTANT_2),&(v111_2));
    drop(v111_2);
    let v111_10: Space = if has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
    drop(v111_9);
    let v111_12: Space = if (v111_10).is_empty() { Space::new() } else {
      let v116_6: Path = concat_path(&(*p0),&(v110_12_head));
      let mut v116_11 = Space::new();
      let mut v116_11_cursor = (v110_12_tail).read_zipper();
      for v116_11_byte in v116_11_cursor.child_mask().iter() {
        v116_11_cursor.descend_to_byte(v116_11_byte);
        let v116_11_tail = v116_11_cursor.make_map();
        v116_11_cursor.ascend(1);
        let v116_11_head = Path::from_slice(&[v116_11_byte]);
        let v117_2: Space = singleton(&(v116_11_head));
        let v117_3: Space = intersect(&(*CONSTANT_2),&(v117_2));
        let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
        drop(v117_3);
        let v117_5: Space = subtract(&(*CONSTANT_1),&(v117_4));
        drop(v117_4);
        let v117_8: Space = if (v117_5).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v116_6),&(v116_11_head));
          let v118_7: Space = routine_22(c, &(v118_6), &(v116_11_tail), &(*s1));
          compose(&(v117_5),&(v118_7))
        };
        drop(v117_5);
        let v117_9: Space = intersect(&(*CONSTANT_2),&(v117_2));
        drop(v117_2);
        let v117_10: Space = if has_head(&(v117_9)) { singleton(&[]) } else { Space::new() };
        drop(v117_9);
        let v117_12: Space = if (v117_10).is_empty() { Space::new() } else {
          let v119_6: Path = concat_path(&(v116_6),&(v116_11_head));
          let v119_11: Space = routine_3(c, &(v119_6), &(v116_11_tail), &(*s1));
          drop(v119_6);
          compose(&(v117_10),&(v119_11))
        };
        drop(v117_10);
        let v117_13: Space = unite(&(v117_8),&(v117_12));
        v116_11.join_into((v117_13).clone());
      }
      drop(v116_11_cursor);
      drop(v116_6);
      compose(&(v111_10),&(v116_11))
    };
    drop(v111_10);
    let v111_13: Space = unite(&(v111_8),&(v111_12));
    v110_12.join_into((v111_13).clone());
  }
  drop(v110_12_cursor);
  (v110_12).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v120_12 = Space::new();
  let mut v120_12_cursor = (*s0).read_zipper();
  for v120_12_byte in v120_12_cursor.child_mask().iter() {
    v120_12_cursor.descend_to_byte(v120_12_byte);
    let v120_12_tail = v120_12_cursor.make_map();
    v120_12_cursor.ascend(1);
    let v120_12_head = Path::from_slice(&[v120_12_byte]);
    let v121_2: Space = singleton(&(v120_12_head));
    let v121_3: Space = intersect(&(*CONSTANT_2),&(v121_2));
    let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
    drop(v121_3);
    let v121_5: Space = subtract(&(*CONSTANT_1),&(v121_4));
    drop(v121_4);
    let v121_8: Space = if (v121_5).is_empty() { Space::new() } else {
      let v122_6: Path = concat_path(&(*p0),&(v120_12_head));
      let mut v122_7 = Space::new();
      let mut v122_7_cursor = (v120_12_tail).read_zipper();
      for v122_7_byte in v122_7_cursor.child_mask().iter() {
        v122_7_cursor.descend_to_byte(v122_7_byte);
        let v122_7_tail = v122_7_cursor.make_map();
        v122_7_cursor.ascend(1);
        let v122_7_head = Path::from_slice(&[v122_7_byte]);
        let v123_2: Space = singleton(&(v122_7_head));
        let v123_3: Space = intersect(&(*CONSTANT_2),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_1),&(v123_4));
        drop(v123_4);
        let v123_8: Space = if (v123_5).is_empty() { Space::new() } else {
          let v124_6: Path = concat_path(&(v122_6),&(v122_7_head));
          let v124_7: Space = routine_22(c, &(v124_6), &(v122_7_tail), &(*s1));
          compose(&(v123_5),&(v124_7))
        };
        drop(v123_5);
        let v123_9: Space = intersect(&(*CONSTANT_2),&(v123_2));
        drop(v123_2);
        let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
        drop(v123_9);
        let v123_12: Space = if (v123_10).is_empty() { Space::new() } else {
          let v125_6: Path = concat_path(&(v122_6),&(v122_7_head));
          let v125_11: Space = routine_23(c, &(v125_6), &(v122_7_tail), &(*s1));
          drop(v125_6);
          compose(&(v123_10),&(v125_11))
        };
        drop(v123_10);
        let v123_13: Space = unite(&(v123_8),&(v123_12));
        v122_7.join_into((v123_13).clone());
      }
      drop(v122_7_cursor);
      compose(&(v121_5),&(v122_7))
    };
    drop(v121_5);
    let v121_9: Space = intersect(&(*CONSTANT_2),&(v121_2));
    drop(v121_2);
    let v121_10: Space = if has_head(&(v121_9)) { singleton(&[]) } else { Space::new() };
    drop(v121_9);
    let v121_12: Space = if (v121_10).is_empty() { Space::new() } else {
      let v126_6: Path = concat_path(&(*p0),&(v120_12_head));
      let mut v126_11 = Space::new();
      let mut v126_11_cursor = (v120_12_tail).read_zipper();
      for v126_11_byte in v126_11_cursor.child_mask().iter() {
        v126_11_cursor.descend_to_byte(v126_11_byte);
        let v126_11_tail = v126_11_cursor.make_map();
        v126_11_cursor.ascend(1);
        let v126_11_head = Path::from_slice(&[v126_11_byte]);
        let v127_2: Space = singleton(&(v126_11_head));
        let v127_3: Space = intersect(&(*CONSTANT_2),&(v127_2));
        let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
        drop(v127_3);
        let v127_5: Space = subtract(&(*CONSTANT_1),&(v127_4));
        drop(v127_4);
        let v127_7: Space = if (v127_5).is_empty() { Space::new() } else {
          let v128_6: Space = routine_6(c, &(v126_11_head), &(v126_6), &(v126_11_tail), &(*s1));
          compose(&(v127_5),&(v128_6))
        };
        drop(v127_5);
        let v127_8: Space = intersect(&(*CONSTANT_2),&(v127_2));
        drop(v127_2);
        let v127_9: Space = if has_head(&(v127_8)) { singleton(&[]) } else { Space::new() };
        drop(v127_8);
        let v127_11: Space = if (v127_9).is_empty() { Space::new() } else {
          let v129_10: Space = routine_7(c, &(v126_11_head), &(v126_6), &(v126_11_tail), &(*s1));
          compose(&(v127_9),&(v129_10))
        };
        drop(v127_9);
        let v127_12: Space = unite(&(v127_7),&(v127_11));
        v126_11.join_into((v127_12).clone());
      }
      drop(v126_11_cursor);
      drop(v126_6);
      compose(&(v121_10),&(v126_11))
    };
    drop(v121_10);
    let v121_13: Space = unite(&(v121_8),&(v121_12));
    v120_12.join_into((v121_13).clone());
  }
  drop(v120_12_cursor);
  (v120_12).clone()
}

fn routine_13(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v130_13 = Space::new();
  let mut v130_13_cursor = (*s0).read_zipper();
  for v130_13_byte in v130_13_cursor.child_mask().iter() {
    v130_13_cursor.descend_to_byte(v130_13_byte);
    let v130_13_tail = v130_13_cursor.make_map();
    v130_13_cursor.ascend(1);
    let v130_13_head = Path::from_slice(&[v130_13_byte]);
    let v131_2: Space = singleton(&(v130_13_head));
    let v131_3: Space = intersect(&(*CONSTANT_2),&(v131_2));
    let v131_4: Space = if has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
    drop(v131_3);
    let v131_5: Space = subtract(&(*CONSTANT_1),&(v131_4));
    drop(v131_4);
    let v131_8: Space = if (v131_5).is_empty() { Space::new() } else {
      let v132_6: Path = concat_path(&(*p0),&(v130_13_head));
      let mut v132_7 = Space::new();
      let mut v132_7_cursor = (v130_13_tail).read_zipper();
      for v132_7_byte in v132_7_cursor.child_mask().iter() {
        v132_7_cursor.descend_to_byte(v132_7_byte);
        let v132_7_tail = v132_7_cursor.make_map();
        v132_7_cursor.ascend(1);
        let v132_7_head = Path::from_slice(&[v132_7_byte]);
        let v133_2: Space = singleton(&(v132_7_head));
        let v133_3: Space = intersect(&(*CONSTANT_2),&(v133_2));
        let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
        drop(v133_3);
        let v133_5: Space = subtract(&(*CONSTANT_1),&(v133_4));
        drop(v133_4);
        let v133_8: Space = if (v133_5).is_empty() { Space::new() } else {
          let v134_6: Path = concat_path(&(v132_6),&(v132_7_head));
          let v134_7: Space = routine_24(c, &(v134_6), &(*p1), &(v132_7_tail), &(*s1));
          compose(&(v133_5),&(v134_7))
        };
        drop(v133_5);
        let v133_9: Space = intersect(&(*CONSTANT_2),&(v133_2));
        drop(v133_2);
        let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
        drop(v133_9);
        let v133_12: Space = if (v133_10).is_empty() { Space::new() } else {
          let v135_6: Path = concat_path(&(v132_6),&(v132_7_head));
          let v135_11: Space = routine_25(c, &(v135_6), &(*p1), &(v132_7_tail), &(*s1));
          drop(v135_6);
          compose(&(v133_10),&(v135_11))
        };
        drop(v133_10);
        let v133_13: Space = unite(&(v133_8),&(v133_12));
        v132_7.join_into((v133_13).clone());
      }
      drop(v132_7_cursor);
      compose(&(v131_5),&(v132_7))
    };
    drop(v131_5);
    let v131_9: Space = intersect(&(*CONSTANT_2),&(v131_2));
    drop(v131_2);
    let v131_10: Space = if has_head(&(v131_9)) { singleton(&[]) } else { Space::new() };
    drop(v131_9);
    let v131_12: Space = if (v131_10).is_empty() { Space::new() } else {
      let v136_6: Path = concat_path(&(*p0),&(v130_13_head));
      let mut v136_11 = Space::new();
      let mut v136_11_cursor = (v130_13_tail).read_zipper();
      for v136_11_byte in v136_11_cursor.child_mask().iter() {
        v136_11_cursor.descend_to_byte(v136_11_byte);
        let v136_11_tail = v136_11_cursor.make_map();
        v136_11_cursor.ascend(1);
        let v136_11_head = Path::from_slice(&[v136_11_byte]);
        let v137_2: Space = singleton(&(v136_11_head));
        let v137_3: Space = intersect(&(*CONSTANT_2),&(v137_2));
        let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
        drop(v137_3);
        let v137_5: Space = subtract(&(*CONSTANT_1),&(v137_4));
        drop(v137_4);
        let v137_8: Space = if (v137_5).is_empty() { Space::new() } else {
          let v138_6: Path = concat_path(&(v136_6),&(v136_11_head));
          let v138_7: Space = routine_24(c, &(v138_6), &(*p1), &(v136_11_tail), &(*s1));
          compose(&(v137_5),&(v138_7))
        };
        drop(v137_5);
        let v137_9: Space = intersect(&(*CONSTANT_2),&(v137_2));
        drop(v137_2);
        let v137_10: Space = if has_head(&(v137_9)) { singleton(&[]) } else { Space::new() };
        drop(v137_9);
        let v137_12: Space = if (v137_10).is_empty() { Space::new() } else {
          let v139_6: Path = concat_path(&(v136_6),&(v136_11_head));
          let v139_11: Space = routine_10(c, &(v139_6), &(*p1), &(v136_11_tail), &(*s1));
          drop(v139_6);
          compose(&(v137_10),&(v139_11))
        };
        drop(v137_10);
        let v137_13: Space = unite(&(v137_8),&(v137_12));
        v136_11.join_into((v137_13).clone());
      }
      drop(v136_11_cursor);
      drop(v136_6);
      compose(&(v131_10),&(v136_11))
    };
    drop(v131_10);
    let v131_13: Space = unite(&(v131_8),&(v131_12));
    v130_13.join_into((v131_13).clone());
  }
  drop(v130_13_cursor);
  (v130_13).clone()
}

fn routine_14(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v140_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v140_9: Space = unwrap(&(v140_8),&(*p0));
  drop(v140_8);
  let mut v140_16 = Space::new();
  let mut v140_16_cursor = (*s0).read_zipper();
  for v140_16_byte in v140_16_cursor.child_mask().iter() {
    v140_16_cursor.descend_to_byte(v140_16_byte);
    let v140_16_tail = v140_16_cursor.make_map();
    v140_16_cursor.ascend(1);
    let v140_16_head = Path::from_slice(&[v140_16_byte]);
    let v141_2: Space = singleton(&(v140_16_head));
    let v141_3: Space = intersect(&(*CONSTANT_2),&(v141_2));
    let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
    drop(v141_3);
    let v141_5: Space = subtract(&(*CONSTANT_1),&(v141_4));
    drop(v141_4);
    let v141_8: Space = if (v141_5).is_empty() { Space::new() } else {
      let v142_6: Path = concat_path(&(*p0),&(v140_16_head));
      let mut v142_7 = Space::new();
      let mut v142_7_cursor = (v140_16_tail).read_zipper();
      for v142_7_byte in v142_7_cursor.child_mask().iter() {
        v142_7_cursor.descend_to_byte(v142_7_byte);
        let v142_7_tail = v142_7_cursor.make_map();
        v142_7_cursor.ascend(1);
        let v142_7_head = Path::from_slice(&[v142_7_byte]);
        let v143_2: Space = singleton(&(v142_7_head));
        let v143_3: Space = intersect(&(*CONSTANT_2),&(v143_2));
        let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
        drop(v143_3);
        let v143_5: Space = subtract(&(*CONSTANT_1),&(v143_4));
        drop(v143_4);
        let v143_8: Space = if (v143_5).is_empty() { Space::new() } else {
          let v144_6: Path = concat_path(&(v142_6),&(v142_7_head));
          let v144_7: Space = routine_24(c, &(v144_6), &(*p1), &(v142_7_tail), &(*s1));
          compose(&(v143_5),&(v144_7))
        };
        drop(v143_5);
        let v143_9: Space = intersect(&(*CONSTANT_2),&(v143_2));
        drop(v143_2);
        let v143_10: Space = if has_head(&(v143_9)) { singleton(&[]) } else { Space::new() };
        drop(v143_9);
        let v143_12: Space = if (v143_10).is_empty() { Space::new() } else {
          let v145_6: Path = concat_path(&(v142_6),&(v142_7_head));
          let v145_11: Space = routine_25(c, &(v145_6), &(*p1), &(v142_7_tail), &(*s1));
          drop(v145_6);
          compose(&(v143_10),&(v145_11))
        };
        drop(v143_10);
        let v143_13: Space = unite(&(v143_8),&(v143_12));
        v142_7.join_into((v143_13).clone());
      }
      drop(v142_7_cursor);
      drop(v142_6);
      compose(&(v141_5),&(v142_7))
    };
    drop(v141_5);
    let v141_9: Space = intersect(&(*CONSTANT_2),&(v141_2));
    drop(v141_2);
    let v141_10: Space = if has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
    drop(v141_9);
    let v141_13: Space = if (v141_10).is_empty() { Space::new() } else {
      let v146_11: Space = unwrap(&(v140_9),&(v140_16_head));
      let mut v146_12 = Space::new();
      let mut v146_12_cursor = (v146_11).read_zipper();
      for v146_12_byte in v146_12_cursor.child_mask().iter() {
        v146_12_cursor.descend_to_byte(v146_12_byte);
        let v146_12_tail = v146_12_cursor.make_map();
        v146_12_cursor.ascend(1);
        let v146_12_head = Path::from_slice(&[v146_12_byte]);
        let v147_2: Space = singleton(&(v146_12_head));
        let v147_3: Space = intersect(&(*CONSTANT_2),&(v147_2));
        let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
        drop(v147_3);
        let v147_5: Space = subtract(&(*CONSTANT_1),&(v147_4));
        drop(v147_4);
        let v147_7: Space = if (v147_5).is_empty() { Space::new() } else {
          let v148_6: Space = routine_15(c, &(v146_12_head), &(*p1), &(v146_12_tail));
          compose(&(v147_5),&(v148_6))
        };
        drop(v147_5);
        let v147_8: Space = intersect(&(*CONSTANT_2),&(v147_2));
        drop(v147_2);
        let v147_9: Space = if has_head(&(v147_8)) { singleton(&[]) } else { Space::new() };
        drop(v147_8);
        let v147_11: Space = if (v147_9).is_empty() { Space::new() } else {
          let v149_10: Space = routine_16(c, &(v146_12_head), &(*p1), &(v146_12_tail));
          compose(&(v147_9),&(v149_10))
        };
        drop(v147_9);
        let v147_12: Space = unite(&(v147_7),&(v147_11));
        v146_12.join_into((v147_12).clone());
      }
      drop(v146_12_cursor);
      drop(v146_11);
      compose(&(v141_10),&(v146_12))
    };
    drop(v141_10);
    let v141_14: Space = unite(&(v141_8),&(v141_13));
    v140_16.join_into((v141_14).clone());
  }
  drop(v140_16_cursor);
  drop(v140_9);
  (v140_16).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v150_12 = Space::new();
  let mut v150_12_cursor = (*s0).read_zipper();
  for v150_12_byte in v150_12_cursor.child_mask().iter() {
    v150_12_cursor.descend_to_byte(v150_12_byte);
    let v150_12_tail = v150_12_cursor.make_map();
    v150_12_cursor.ascend(1);
    let v150_12_head = Path::from_slice(&[v150_12_byte]);
    let v151_2: Space = singleton(&(v150_12_head));
    let v151_3: Space = intersect(&(*CONSTANT_2),&(v151_2));
    let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
    drop(v151_3);
    let v151_5: Space = subtract(&(*CONSTANT_1),&(v151_4));
    drop(v151_4);
    let v151_8: Space = if (v151_5).is_empty() { Space::new() } else {
      let v152_6: Path = concat_path(&(*p0),&(v150_12_head));
      let mut v152_7 = Space::new();
      let mut v152_7_cursor = (v150_12_tail).read_zipper();
      for v152_7_byte in v152_7_cursor.child_mask().iter() {
        v152_7_cursor.descend_to_byte(v152_7_byte);
        let v152_7_tail = v152_7_cursor.make_map();
        v152_7_cursor.ascend(1);
        let v152_7_head = Path::from_slice(&[v152_7_byte]);
        let v153_2: Space = singleton(&(v152_7_head));
        let v153_3: Space = intersect(&(*CONSTANT_2),&(v153_2));
        let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
        drop(v153_3);
        let v153_5: Space = subtract(&(*CONSTANT_1),&(v153_4));
        drop(v153_4);
        let v153_8: Space = if (v153_5).is_empty() { Space::new() } else {
          let v154_6: Path = concat_path(&(v152_6),&(v152_7_head));
          let v154_7: Space = routine_26(c, &(v154_6), &(*p1), &(v152_7_tail));
          compose(&(v153_5),&(v154_7))
        };
        drop(v153_5);
        let v153_9: Space = intersect(&(*CONSTANT_2),&(v153_2));
        drop(v153_2);
        let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
        drop(v153_9);
        let v153_12: Space = if (v153_10).is_empty() { Space::new() } else {
          let v155_6: Path = concat_path(&(v152_6),&(v152_7_head));
          let v155_11: Space = routine_27(c, &(v155_6), &(*p1), &(v152_7_tail));
          drop(v155_6);
          compose(&(v153_10),&(v155_11))
        };
        drop(v153_10);
        let v153_13: Space = unite(&(v153_8),&(v153_12));
        v152_7.join_into((v153_13).clone());
      }
      drop(v152_7_cursor);
      compose(&(v151_5),&(v152_7))
    };
    drop(v151_5);
    let v151_9: Space = intersect(&(*CONSTANT_2),&(v151_2));
    drop(v151_2);
    let v151_10: Space = if has_head(&(v151_9)) { singleton(&[]) } else { Space::new() };
    drop(v151_9);
    let v151_12: Space = if (v151_10).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&(v150_12_head));
      let mut v156_11 = Space::new();
      let mut v156_11_cursor = (v150_12_tail).read_zipper();
      for v156_11_byte in v156_11_cursor.child_mask().iter() {
        v156_11_cursor.descend_to_byte(v156_11_byte);
        let v156_11_tail = v156_11_cursor.make_map();
        v156_11_cursor.ascend(1);
        let v156_11_head = Path::from_slice(&[v156_11_byte]);
        let v157_2: Space = singleton(&(v156_11_head));
        let v157_3: Space = intersect(&(*CONSTANT_2),&(v157_2));
        let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = subtract(&(*CONSTANT_1),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&(v156_11_head));
          let v158_7: Space = routine_26(c, &(v158_6), &(*p1), &(v156_11_tail));
          compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = intersect(&(*CONSTANT_2),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
          let v159_6: Path = concat_path(&(v156_6),&(v156_11_head));
          let v159_11: Space = routine_21(c, &(v159_6), &(*p1), &(v156_11_tail));
          drop(v159_6);
          compose(&(v157_10),&(v159_11))
        };
        drop(v157_10);
        let v157_13: Space = unite(&(v157_8),&(v157_12));
        v156_11.join_into((v157_13).clone());
      }
      drop(v156_11_cursor);
      drop(v156_6);
      compose(&(v151_10),&(v156_11))
    };
    drop(v151_10);
    let v151_13: Space = unite(&(v151_8),&(v151_12));
    v150_12.join_into((v151_13).clone());
  }
  drop(v150_12_cursor);
  (v150_12).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v160_9 = Space::new();
  let mut v160_9_cursor = (*s0).read_zipper();
  for v160_9_byte in v160_9_cursor.child_mask().iter() {
    v160_9_cursor.descend_to_byte(v160_9_byte);
    let v160_9_tail = v160_9_cursor.make_map();
    v160_9_cursor.ascend(1);
    let v160_9_head = Path::from_slice(&[v160_9_byte]);
    let v161_2: Space = singleton(&(v160_9_head));
    let v161_3: Space = intersect(&(*CONSTANT_2),&(v161_2));
    let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
    drop(v161_3);
    let v161_5: Space = subtract(&(*CONSTANT_1),&(v161_4));
    drop(v161_4);
    let v161_8: Space = if (v161_5).is_empty() { Space::new() } else {
      let v162_6: Path = concat_path(&(*p0),&(v160_9_head));
      let mut v162_7 = Space::new();
      let mut v162_7_cursor = (v160_9_tail).read_zipper();
      for v162_7_byte in v162_7_cursor.child_mask().iter() {
        v162_7_cursor.descend_to_byte(v162_7_byte);
        let v162_7_tail = v162_7_cursor.make_map();
        v162_7_cursor.ascend(1);
        let v162_7_head = Path::from_slice(&[v162_7_byte]);
        let v163_2: Space = singleton(&(v162_7_head));
        let v163_3: Space = intersect(&(*CONSTANT_2),&(v163_2));
        let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
        drop(v163_3);
        let v163_5: Space = subtract(&(*CONSTANT_1),&(v163_4));
        drop(v163_4);
        let v163_8: Space = if (v163_5).is_empty() { Space::new() } else {
          let v164_6: Path = concat_path(&(v162_6),&(v162_7_head));
          let v164_7: Space = routine_26(c, &(v164_6), &(*p1), &(v162_7_tail));
          compose(&(v163_5),&(v164_7))
        };
        drop(v163_5);
        let v163_9: Space = intersect(&(*CONSTANT_2),&(v163_2));
        drop(v163_2);
        let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
        drop(v163_9);
        let v163_12: Space = if (v163_10).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v162_6),&(v162_7_head));
          let v165_11: Space = routine_27(c, &(v165_6), &(*p1), &(v162_7_tail));
          drop(v165_6);
          compose(&(v163_10),&(v165_11))
        };
        drop(v163_10);
        let v163_13: Space = unite(&(v163_8),&(v163_12));
        v162_7.join_into((v163_13).clone());
      }
      drop(v162_7_cursor);
      compose(&(v161_5),&(v162_7))
    };
    drop(v161_5);
    let v161_9: Space = intersect(&(*CONSTANT_2),&(v161_2));
    drop(v161_2);
    let v161_10: Space = if has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
    drop(v161_9);
    let v161_11: Space = compose(&(v161_10),&(v160_9_tail));
    drop(v161_10);
    let v166_6: Path = concat_path(&(*p0),&(v160_9_head));
    let v161_12: Space = wrap(&(v161_11),&(v166_6));
    drop(v161_11);
    let v161_13: Space = wrap(&(v161_12),&(*p1));
    drop(v161_12);
    let v161_14: Space = unite(&(v161_8),&(v161_13));
    drop(v161_13);
    v160_9.join_into((v161_14).clone());
  }
  drop(v160_9_cursor);
  (v160_9).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v167_13 = Space::new();
  let mut v167_13_cursor = (*s0).read_zipper();
  for v167_13_byte in v167_13_cursor.child_mask().iter() {
    v167_13_cursor.descend_to_byte(v167_13_byte);
    let v167_13_tail = v167_13_cursor.make_map();
    v167_13_cursor.ascend(1);
    let v167_13_head = Path::from_slice(&[v167_13_byte]);
    let v168_2: Space = singleton(&(v167_13_head));
    let v168_3: Space = intersect(&(*CONSTANT_2),&(v168_2));
    let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
    drop(v168_3);
    let v168_5: Space = subtract(&(*CONSTANT_1),&(v168_4));
    drop(v168_4);
    let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
      let v169_6: Path = concat_path(&(*p0),&(v167_13_head));
      let mut v169_7 = Space::new();
      let mut v169_7_cursor = (v167_13_tail).read_zipper();
      for v169_7_byte in v169_7_cursor.child_mask().iter() {
        v169_7_cursor.descend_to_byte(v169_7_byte);
        let v169_7_tail = v169_7_cursor.make_map();
        v169_7_cursor.ascend(1);
        let v169_7_head = Path::from_slice(&[v169_7_byte]);
        let v170_2: Space = singleton(&(v169_7_head));
        let v170_3: Space = intersect(&(*CONSTANT_2),&(v170_2));
        let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
        drop(v170_3);
        let v170_5: Space = subtract(&(*CONSTANT_1),&(v170_4));
        drop(v170_4);
        let v170_8: Space = if (v170_5).is_empty() { Space::new() } else {
          let v171_6: Path = concat_path(&(v169_6),&(v169_7_head));
          let v171_7: Space = routine_28(c, &(v171_6), &(*p1), &(v169_7_tail), &(*s1));
          compose(&(v170_5),&(v171_7))
        };
        drop(v170_5);
        let v170_9: Space = intersect(&(*CONSTANT_2),&(v170_2));
        drop(v170_2);
        let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
        drop(v170_9);
        let v170_12: Space = if (v170_10).is_empty() { Space::new() } else {
          let v172_6: Path = concat_path(&(v169_6),&(v169_7_head));
          let v172_11: Space = routine_29(c, &(v172_6), &(*p1), &(v169_7_tail), &(*s1));
          drop(v172_6);
          compose(&(v170_10),&(v172_11))
        };
        drop(v170_10);
        let v170_13: Space = unite(&(v170_8),&(v170_12));
        v169_7.join_into((v170_13).clone());
      }
      drop(v169_7_cursor);
      compose(&(v168_5),&(v169_7))
    };
    drop(v168_5);
    let v168_9: Space = intersect(&(*CONSTANT_2),&(v168_2));
    drop(v168_2);
    let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
    drop(v168_9);
    let v168_12: Space = if (v168_10).is_empty() { Space::new() } else {
      let v173_6: Path = concat_path(&(*p0),&(v167_13_head));
      let mut v173_11 = Space::new();
      let mut v173_11_cursor = (v167_13_tail).read_zipper();
      for v173_11_byte in v173_11_cursor.child_mask().iter() {
        v173_11_cursor.descend_to_byte(v173_11_byte);
        let v173_11_tail = v173_11_cursor.make_map();
        v173_11_cursor.ascend(1);
        let v173_11_head = Path::from_slice(&[v173_11_byte]);
        let v174_2: Space = singleton(&(v173_11_head));
        let v174_3: Space = intersect(&(*CONSTANT_2),&(v174_2));
        let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
        drop(v174_3);
        let v174_5: Space = subtract(&(*CONSTANT_1),&(v174_4));
        drop(v174_4);
        let v174_8: Space = if (v174_5).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v173_6),&(v173_11_head));
          let v175_7: Space = routine_28(c, &(v175_6), &(*p1), &(v173_11_tail), &(*s1));
          compose(&(v174_5),&(v175_7))
        };
        drop(v174_5);
        let v174_9: Space = intersect(&(*CONSTANT_2),&(v174_2));
        drop(v174_2);
        let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
        drop(v174_9);
        let v174_12: Space = if (v174_10).is_empty() { Space::new() } else {
          let v176_6: Path = concat_path(&(v173_6),&(v173_11_head));
          let v176_11: Space = routine_10(c, &(v176_6), &(*p1), &(v173_11_tail), &(*s1));
          drop(v176_6);
          compose(&(v174_10),&(v176_11))
        };
        drop(v174_10);
        let v174_13: Space = unite(&(v174_8),&(v174_12));
        v173_11.join_into((v174_13).clone());
      }
      drop(v173_11_cursor);
      drop(v173_6);
      compose(&(v168_10),&(v173_11))
    };
    drop(v168_10);
    let v168_13: Space = unite(&(v168_8),&(v168_12));
    v167_13.join_into((v168_13).clone());
  }
  drop(v167_13_cursor);
  (v167_13).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v177_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v177_9: Space = unwrap(&(v177_8),&(*p0));
  drop(v177_8);
  let mut v177_16 = Space::new();
  let mut v177_16_cursor = (*s0).read_zipper();
  for v177_16_byte in v177_16_cursor.child_mask().iter() {
    v177_16_cursor.descend_to_byte(v177_16_byte);
    let v177_16_tail = v177_16_cursor.make_map();
    v177_16_cursor.ascend(1);
    let v177_16_head = Path::from_slice(&[v177_16_byte]);
    let v178_2: Space = singleton(&(v177_16_head));
    let v178_3: Space = intersect(&(*CONSTANT_2),&(v178_2));
    let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
    drop(v178_3);
    let v178_5: Space = subtract(&(*CONSTANT_1),&(v178_4));
    drop(v178_4);
    let v178_8: Space = if (v178_5).is_empty() { Space::new() } else {
      let v179_6: Path = concat_path(&(*p0),&(v177_16_head));
      let mut v179_7 = Space::new();
      let mut v179_7_cursor = (v177_16_tail).read_zipper();
      for v179_7_byte in v179_7_cursor.child_mask().iter() {
        v179_7_cursor.descend_to_byte(v179_7_byte);
        let v179_7_tail = v179_7_cursor.make_map();
        v179_7_cursor.ascend(1);
        let v179_7_head = Path::from_slice(&[v179_7_byte]);
        let v180_2: Space = singleton(&(v179_7_head));
        let v180_3: Space = intersect(&(*CONSTANT_2),&(v180_2));
        let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
        drop(v180_3);
        let v180_5: Space = subtract(&(*CONSTANT_1),&(v180_4));
        drop(v180_4);
        let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v181_7: Space = routine_28(c, &(v181_6), &(*p1), &(v179_7_tail), &(*s1));
          compose(&(v180_5),&(v181_7))
        };
        drop(v180_5);
        let v180_9: Space = intersect(&(*CONSTANT_2),&(v180_2));
        drop(v180_2);
        let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
        drop(v180_9);
        let v180_12: Space = if (v180_10).is_empty() { Space::new() } else {
          let v182_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v182_11: Space = routine_29(c, &(v182_6), &(*p1), &(v179_7_tail), &(*s1));
          drop(v182_6);
          compose(&(v180_10),&(v182_11))
        };
        drop(v180_10);
        let v180_13: Space = unite(&(v180_8),&(v180_12));
        v179_7.join_into((v180_13).clone());
      }
      drop(v179_7_cursor);
      drop(v179_6);
      compose(&(v178_5),&(v179_7))
    };
    drop(v178_5);
    let v178_9: Space = intersect(&(*CONSTANT_2),&(v178_2));
    drop(v178_2);
    let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
    drop(v178_9);
    let v178_13: Space = if (v178_10).is_empty() { Space::new() } else {
      let v183_11: Space = unwrap(&(v177_9),&(v177_16_head));
      let mut v183_12 = Space::new();
      let mut v183_12_cursor = (v183_11).read_zipper();
      for v183_12_byte in v183_12_cursor.child_mask().iter() {
        v183_12_cursor.descend_to_byte(v183_12_byte);
        let v183_12_tail = v183_12_cursor.make_map();
        v183_12_cursor.ascend(1);
        let v183_12_head = Path::from_slice(&[v183_12_byte]);
        let v184_2: Space = singleton(&(v183_12_head));
        let v184_3: Space = intersect(&(*CONSTANT_2),&(v184_2));
        let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
        drop(v184_3);
        let v184_5: Space = subtract(&(*CONSTANT_1),&(v184_4));
        drop(v184_4);
        let v184_7: Space = if (v184_5).is_empty() { Space::new() } else {
          let v185_6: Space = routine_15(c, &(v183_12_head), &(*p1), &(v183_12_tail));
          compose(&(v184_5),&(v185_6))
        };
        drop(v184_5);
        let v184_8: Space = intersect(&(*CONSTANT_2),&(v184_2));
        drop(v184_2);
        let v184_9: Space = if has_head(&(v184_8)) { singleton(&[]) } else { Space::new() };
        drop(v184_8);
        let v184_11: Space = if (v184_9).is_empty() { Space::new() } else {
          let v186_10: Space = routine_16(c, &(v183_12_head), &(*p1), &(v183_12_tail));
          compose(&(v184_9),&(v186_10))
        };
        drop(v184_9);
        let v184_12: Space = unite(&(v184_7),&(v184_11));
        v183_12.join_into((v184_12).clone());
      }
      drop(v183_12_cursor);
      drop(v183_11);
      compose(&(v178_10),&(v183_12))
    };
    drop(v178_10);
    let v178_14: Space = unite(&(v178_8),&(v178_13));
    v177_16.join_into((v178_14).clone());
  }
  drop(v177_16_cursor);
  drop(v177_9);
  (v177_16).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v187_12 = Space::new();
  let mut v187_12_cursor = (*s0).read_zipper();
  for v187_12_byte in v187_12_cursor.child_mask().iter() {
    v187_12_cursor.descend_to_byte(v187_12_byte);
    let v187_12_tail = v187_12_cursor.make_map();
    v187_12_cursor.ascend(1);
    let v187_12_head = Path::from_slice(&[v187_12_byte]);
    let v188_2: Space = singleton(&(v187_12_head));
    let v188_3: Space = intersect(&(*CONSTANT_2),&(v188_2));
    let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
    drop(v188_3);
    let v188_5: Space = subtract(&(*CONSTANT_1),&(v188_4));
    drop(v188_4);
    let v188_8: Space = if (v188_5).is_empty() { Space::new() } else {
      let v189_6: Path = concat_path(&(*p0),&(v187_12_head));
      let mut v189_7 = Space::new();
      let mut v189_7_cursor = (v187_12_tail).read_zipper();
      for v189_7_byte in v189_7_cursor.child_mask().iter() {
        v189_7_cursor.descend_to_byte(v189_7_byte);
        let v189_7_tail = v189_7_cursor.make_map();
        v189_7_cursor.ascend(1);
        let v189_7_head = Path::from_slice(&[v189_7_byte]);
        let v190_2: Space = singleton(&(v189_7_head));
        let v190_3: Space = intersect(&(*CONSTANT_2),&(v190_2));
        let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
        drop(v190_3);
        let v190_5: Space = subtract(&(*CONSTANT_1),&(v190_4));
        drop(v190_4);
        let v190_8: Space = if (v190_5).is_empty() { Space::new() } else {
          let v191_6: Path = concat_path(&(v189_6),&(v189_7_head));
          let v191_7: Space = routine_30(c, &(v191_6), &(*p1), &(v189_7_tail));
          compose(&(v190_5),&(v191_7))
        };
        drop(v190_5);
        let v190_9: Space = intersect(&(*CONSTANT_2),&(v190_2));
        drop(v190_2);
        let v190_10: Space = if has_head(&(v190_9)) { singleton(&[]) } else { Space::new() };
        drop(v190_9);
        let v190_12: Space = if (v190_10).is_empty() { Space::new() } else {
          let v192_6: Path = concat_path(&(v189_6),&(v189_7_head));
          let v192_11: Space = routine_31(c, &(v192_6), &(*p1), &(v189_7_tail));
          drop(v192_6);
          compose(&(v190_10),&(v192_11))
        };
        drop(v190_10);
        let v190_13: Space = unite(&(v190_8),&(v190_12));
        v189_7.join_into((v190_13).clone());
      }
      drop(v189_7_cursor);
      compose(&(v188_5),&(v189_7))
    };
    drop(v188_5);
    let v188_9: Space = intersect(&(*CONSTANT_2),&(v188_2));
    drop(v188_2);
    let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
    drop(v188_9);
    let v188_12: Space = if (v188_10).is_empty() { Space::new() } else {
      let v193_6: Path = concat_path(&(*p0),&(v187_12_head));
      let mut v193_11 = Space::new();
      let mut v193_11_cursor = (v187_12_tail).read_zipper();
      for v193_11_byte in v193_11_cursor.child_mask().iter() {
        v193_11_cursor.descend_to_byte(v193_11_byte);
        let v193_11_tail = v193_11_cursor.make_map();
        v193_11_cursor.ascend(1);
        let v193_11_head = Path::from_slice(&[v193_11_byte]);
        let v194_2: Space = singleton(&(v193_11_head));
        let v194_3: Space = intersect(&(*CONSTANT_2),&(v194_2));
        let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
        drop(v194_3);
        let v194_5: Space = subtract(&(*CONSTANT_1),&(v194_4));
        drop(v194_4);
        let v194_8: Space = if (v194_5).is_empty() { Space::new() } else {
          let v195_6: Path = concat_path(&(v193_6),&(v193_11_head));
          let v195_7: Space = routine_30(c, &(v195_6), &(*p1), &(v193_11_tail));
          compose(&(v194_5),&(v195_7))
        };
        drop(v194_5);
        let v194_9: Space = intersect(&(*CONSTANT_2),&(v194_2));
        drop(v194_2);
        let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
        drop(v194_9);
        let v194_12: Space = if (v194_10).is_empty() { Space::new() } else {
          let v196_6: Path = concat_path(&(v193_6),&(v193_11_head));
          let v196_11: Space = routine_21(c, &(v196_6), &(*p1), &(v193_11_tail));
          drop(v196_6);
          compose(&(v194_10),&(v196_11))
        };
        drop(v194_10);
        let v194_13: Space = unite(&(v194_8),&(v194_12));
        v193_11.join_into((v194_13).clone());
      }
      drop(v193_11_cursor);
      drop(v193_6);
      compose(&(v188_10),&(v193_11))
    };
    drop(v188_10);
    let v188_13: Space = unite(&(v188_8),&(v188_12));
    v187_12.join_into((v188_13).clone());
  }
  drop(v187_12_cursor);
  (v187_12).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v197_9 = Space::new();
  let mut v197_9_cursor = (*s0).read_zipper();
  for v197_9_byte in v197_9_cursor.child_mask().iter() {
    v197_9_cursor.descend_to_byte(v197_9_byte);
    let v197_9_tail = v197_9_cursor.make_map();
    v197_9_cursor.ascend(1);
    let v197_9_head = Path::from_slice(&[v197_9_byte]);
    let v198_2: Space = singleton(&(v197_9_head));
    let v198_3: Space = intersect(&(*CONSTANT_2),&(v198_2));
    let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
    drop(v198_3);
    let v198_5: Space = subtract(&(*CONSTANT_1),&(v198_4));
    drop(v198_4);
    let v198_8: Space = if (v198_5).is_empty() { Space::new() } else {
      let v199_6: Path = concat_path(&(*p0),&(v197_9_head));
      let mut v199_7 = Space::new();
      let mut v199_7_cursor = (v197_9_tail).read_zipper();
      for v199_7_byte in v199_7_cursor.child_mask().iter() {
        v199_7_cursor.descend_to_byte(v199_7_byte);
        let v199_7_tail = v199_7_cursor.make_map();
        v199_7_cursor.ascend(1);
        let v199_7_head = Path::from_slice(&[v199_7_byte]);
        let v200_2: Space = singleton(&(v199_7_head));
        let v200_3: Space = intersect(&(*CONSTANT_2),&(v200_2));
        let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
        drop(v200_3);
        let v200_5: Space = subtract(&(*CONSTANT_1),&(v200_4));
        drop(v200_4);
        let v200_8: Space = if (v200_5).is_empty() { Space::new() } else {
          let v201_6: Path = concat_path(&(v199_6),&(v199_7_head));
          let v201_7: Space = routine_30(c, &(v201_6), &(*p1), &(v199_7_tail));
          compose(&(v200_5),&(v201_7))
        };
        drop(v200_5);
        let v200_9: Space = intersect(&(*CONSTANT_2),&(v200_2));
        drop(v200_2);
        let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
        drop(v200_9);
        let v200_12: Space = if (v200_10).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v199_6),&(v199_7_head));
          let v202_11: Space = routine_31(c, &(v202_6), &(*p1), &(v199_7_tail));
          drop(v202_6);
          compose(&(v200_10),&(v202_11))
        };
        drop(v200_10);
        let v200_13: Space = unite(&(v200_8),&(v200_12));
        v199_7.join_into((v200_13).clone());
      }
      drop(v199_7_cursor);
      compose(&(v198_5),&(v199_7))
    };
    drop(v198_5);
    let v198_9: Space = intersect(&(*CONSTANT_2),&(v198_2));
    drop(v198_2);
    let v198_10: Space = if has_head(&(v198_9)) { singleton(&[]) } else { Space::new() };
    drop(v198_9);
    let v198_11: Space = compose(&(v198_10),&(v197_9_tail));
    drop(v198_10);
    let v203_6: Path = concat_path(&(*p0),&(v197_9_head));
    let v198_12: Space = wrap(&(v198_11),&(v203_6));
    drop(v198_11);
    let v198_13: Space = wrap(&(v198_12),&(*p1));
    drop(v198_12);
    let v198_14: Space = unite(&(v198_8),&(v198_13));
    drop(v198_13);
    v197_9.join_into((v198_14).clone());
  }
  drop(v197_9_cursor);
  (v197_9).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v204_3: Space = wrap(&(*s0),&(*p0));
  let v204_4: Space = wrap(&(v204_3),&(*p1));
  drop(v204_3);
  (v204_4).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v205_12 = Space::new();
  let mut v205_12_cursor = (*s0).read_zipper();
  for v205_12_byte in v205_12_cursor.child_mask().iter() {
    v205_12_cursor.descend_to_byte(v205_12_byte);
    let v205_12_tail = v205_12_cursor.make_map();
    v205_12_cursor.ascend(1);
    let v205_12_head = Path::from_slice(&[v205_12_byte]);
    let v206_2: Space = singleton(&(v205_12_head));
    let v206_3: Space = intersect(&(*CONSTANT_2),&(v206_2));
    let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
    drop(v206_3);
    let v206_5: Space = subtract(&(*CONSTANT_1),&(v206_4));
    drop(v206_4);
    let v206_8: Space = if (v206_5).is_empty() { Space::new() } else {
      let v207_6: Path = concat_path(&(*p0),&(v205_12_head));
      let mut v207_7 = Space::new();
      let mut v207_7_cursor = (v205_12_tail).read_zipper();
      for v207_7_byte in v207_7_cursor.child_mask().iter() {
        v207_7_cursor.descend_to_byte(v207_7_byte);
        let v207_7_tail = v207_7_cursor.make_map();
        v207_7_cursor.ascend(1);
        let v207_7_head = Path::from_slice(&[v207_7_byte]);
        let v208_2: Space = singleton(&(v207_7_head));
        let v208_3: Space = intersect(&(*CONSTANT_2),&(v208_2));
        let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
        drop(v208_3);
        let v208_5: Space = subtract(&(*CONSTANT_1),&(v208_4));
        drop(v208_4);
        let v208_8: Space = if (v208_5).is_empty() { Space::new() } else {
          let v209_6: Path = concat_path(&(v207_6),&(v207_7_head));
          let v209_7: Space = routine_32(c, &(v209_6), &(v207_7_tail), &(*s1));
          compose(&(v208_5),&(v209_7))
        };
        drop(v208_5);
        let v208_9: Space = intersect(&(*CONSTANT_2),&(v208_2));
        drop(v208_2);
        let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
        drop(v208_9);
        let v208_12: Space = if (v208_10).is_empty() { Space::new() } else {
          let v210_6: Path = concat_path(&(v207_6),&(v207_7_head));
          let v210_11: Space = routine_33(c, &(v210_6), &(v207_7_tail), &(*s1));
          drop(v210_6);
          compose(&(v208_10),&(v210_11))
        };
        drop(v208_10);
        let v208_13: Space = unite(&(v208_8),&(v208_12));
        v207_7.join_into((v208_13).clone());
      }
      drop(v207_7_cursor);
      compose(&(v206_5),&(v207_7))
    };
    drop(v206_5);
    let v206_9: Space = intersect(&(*CONSTANT_2),&(v206_2));
    drop(v206_2);
    let v206_10: Space = if has_head(&(v206_9)) { singleton(&[]) } else { Space::new() };
    drop(v206_9);
    let v206_12: Space = if (v206_10).is_empty() { Space::new() } else {
      let v211_6: Path = concat_path(&(*p0),&(v205_12_head));
      let mut v211_11 = Space::new();
      let mut v211_11_cursor = (v205_12_tail).read_zipper();
      for v211_11_byte in v211_11_cursor.child_mask().iter() {
        v211_11_cursor.descend_to_byte(v211_11_byte);
        let v211_11_tail = v211_11_cursor.make_map();
        v211_11_cursor.ascend(1);
        let v211_11_head = Path::from_slice(&[v211_11_byte]);
        let v212_2: Space = singleton(&(v211_11_head));
        let v212_3: Space = intersect(&(*CONSTANT_2),&(v212_2));
        let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
        drop(v212_3);
        let v212_5: Space = subtract(&(*CONSTANT_1),&(v212_4));
        drop(v212_4);
        let v212_8: Space = if (v212_5).is_empty() { Space::new() } else {
          let v213_6: Path = concat_path(&(v211_6),&(v211_11_head));
          let v213_7: Space = routine_32(c, &(v213_6), &(v211_11_tail), &(*s1));
          compose(&(v212_5),&(v213_7))
        };
        drop(v212_5);
        let v212_9: Space = intersect(&(*CONSTANT_2),&(v212_2));
        drop(v212_2);
        let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
        drop(v212_9);
        let v212_12: Space = if (v212_10).is_empty() { Space::new() } else {
          let v214_6: Path = concat_path(&(v211_6),&(v211_11_head));
          let v214_11: Space = routine_3(c, &(v214_6), &(v211_11_tail), &(*s1));
          drop(v214_6);
          compose(&(v212_10),&(v214_11))
        };
        drop(v212_10);
        let v212_13: Space = unite(&(v212_8),&(v212_12));
        v211_11.join_into((v212_13).clone());
      }
      drop(v211_11_cursor);
      drop(v211_6);
      compose(&(v206_10),&(v211_11))
    };
    drop(v206_10);
    let v206_13: Space = unite(&(v206_8),&(v206_12));
    v205_12.join_into((v206_13).clone());
  }
  drop(v205_12_cursor);
  (v205_12).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v215_12 = Space::new();
  let mut v215_12_cursor = (*s0).read_zipper();
  for v215_12_byte in v215_12_cursor.child_mask().iter() {
    v215_12_cursor.descend_to_byte(v215_12_byte);
    let v215_12_tail = v215_12_cursor.make_map();
    v215_12_cursor.ascend(1);
    let v215_12_head = Path::from_slice(&[v215_12_byte]);
    let v216_2: Space = singleton(&(v215_12_head));
    let v216_3: Space = intersect(&(*CONSTANT_2),&(v216_2));
    let v216_4: Space = if has_head(&(v216_3)) { singleton(&[]) } else { Space::new() };
    drop(v216_3);
    let v216_5: Space = subtract(&(*CONSTANT_1),&(v216_4));
    drop(v216_4);
    let v216_8: Space = if (v216_5).is_empty() { Space::new() } else {
      let v217_6: Path = concat_path(&(*p0),&(v215_12_head));
      let mut v217_7 = Space::new();
      let mut v217_7_cursor = (v215_12_tail).read_zipper();
      for v217_7_byte in v217_7_cursor.child_mask().iter() {
        v217_7_cursor.descend_to_byte(v217_7_byte);
        let v217_7_tail = v217_7_cursor.make_map();
        v217_7_cursor.ascend(1);
        let v217_7_head = Path::from_slice(&[v217_7_byte]);
        let v218_2: Space = singleton(&(v217_7_head));
        let v218_3: Space = intersect(&(*CONSTANT_2),&(v218_2));
        let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
        drop(v218_3);
        let v218_5: Space = subtract(&(*CONSTANT_1),&(v218_4));
        drop(v218_4);
        let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
          let v219_6: Path = concat_path(&(v217_6),&(v217_7_head));
          let v219_7: Space = routine_32(c, &(v219_6), &(v217_7_tail), &(*s1));
          compose(&(v218_5),&(v219_7))
        };
        drop(v218_5);
        let v218_9: Space = intersect(&(*CONSTANT_2),&(v218_2));
        drop(v218_2);
        let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
        drop(v218_9);
        let v218_12: Space = if (v218_10).is_empty() { Space::new() } else {
          let v220_6: Path = concat_path(&(v217_6),&(v217_7_head));
          let v220_11: Space = routine_33(c, &(v220_6), &(v217_7_tail), &(*s1));
          drop(v220_6);
          compose(&(v218_10),&(v220_11))
        };
        drop(v218_10);
        let v218_13: Space = unite(&(v218_8),&(v218_12));
        v217_7.join_into((v218_13).clone());
      }
      drop(v217_7_cursor);
      compose(&(v216_5),&(v217_7))
    };
    drop(v216_5);
    let v216_9: Space = intersect(&(*CONSTANT_2),&(v216_2));
    drop(v216_2);
    let v216_10: Space = if has_head(&(v216_9)) { singleton(&[]) } else { Space::new() };
    drop(v216_9);
    let v216_12: Space = if (v216_10).is_empty() { Space::new() } else {
      let v221_6: Path = concat_path(&(*p0),&(v215_12_head));
      let mut v221_11 = Space::new();
      let mut v221_11_cursor = (v215_12_tail).read_zipper();
      for v221_11_byte in v221_11_cursor.child_mask().iter() {
        v221_11_cursor.descend_to_byte(v221_11_byte);
        let v221_11_tail = v221_11_cursor.make_map();
        v221_11_cursor.ascend(1);
        let v221_11_head = Path::from_slice(&[v221_11_byte]);
        let v222_2: Space = singleton(&(v221_11_head));
        let v222_3: Space = intersect(&(*CONSTANT_2),&(v222_2));
        let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
        drop(v222_3);
        let v222_5: Space = subtract(&(*CONSTANT_1),&(v222_4));
        drop(v222_4);
        let v222_7: Space = if (v222_5).is_empty() { Space::new() } else {
          let v223_6: Space = routine_6(c, &(v221_11_head), &(v221_6), &(v221_11_tail), &(*s1));
          compose(&(v222_5),&(v223_6))
        };
        drop(v222_5);
        let v222_8: Space = intersect(&(*CONSTANT_2),&(v222_2));
        drop(v222_2);
        let v222_9: Space = if has_head(&(v222_8)) { singleton(&[]) } else { Space::new() };
        drop(v222_8);
        let v222_11: Space = if (v222_9).is_empty() { Space::new() } else {
          let v224_10: Space = routine_7(c, &(v221_11_head), &(v221_6), &(v221_11_tail), &(*s1));
          compose(&(v222_9),&(v224_10))
        };
        drop(v222_9);
        let v222_12: Space = unite(&(v222_7),&(v222_11));
        v221_11.join_into((v222_12).clone());
      }
      drop(v221_11_cursor);
      drop(v221_6);
      compose(&(v216_10),&(v221_11))
    };
    drop(v216_10);
    let v216_13: Space = unite(&(v216_8),&(v216_12));
    v215_12.join_into((v216_13).clone());
  }
  drop(v215_12_cursor);
  (v215_12).clone()
}

fn routine_24(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v225_13 = Space::new();
  let mut v225_13_cursor = (*s0).read_zipper();
  for v225_13_byte in v225_13_cursor.child_mask().iter() {
    v225_13_cursor.descend_to_byte(v225_13_byte);
    let v225_13_tail = v225_13_cursor.make_map();
    v225_13_cursor.ascend(1);
    let v225_13_head = Path::from_slice(&[v225_13_byte]);
    let v226_2: Space = singleton(&(v225_13_head));
    let v226_3: Space = intersect(&(*CONSTANT_2),&(v226_2));
    let v226_4: Space = if has_head(&(v226_3)) { singleton(&[]) } else { Space::new() };
    drop(v226_3);
    let v226_5: Space = subtract(&(*CONSTANT_1),&(v226_4));
    drop(v226_4);
    let v226_8: Space = if (v226_5).is_empty() { Space::new() } else {
      let v227_6: Path = concat_path(&(*p0),&(v225_13_head));
      let mut v227_7 = Space::new();
      let mut v227_7_cursor = (v225_13_tail).read_zipper();
      for v227_7_byte in v227_7_cursor.child_mask().iter() {
        v227_7_cursor.descend_to_byte(v227_7_byte);
        let v227_7_tail = v227_7_cursor.make_map();
        v227_7_cursor.ascend(1);
        let v227_7_head = Path::from_slice(&[v227_7_byte]);
        let v228_2: Space = singleton(&(v227_7_head));
        let v228_3: Space = intersect(&(*CONSTANT_2),&(v228_2));
        let v228_4: Space = if has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
        drop(v228_3);
        let v228_5: Space = subtract(&(*CONSTANT_1),&(v228_4));
        drop(v228_4);
        let v228_8: Space = if (v228_5).is_empty() { Space::new() } else {
          let v229_6: Path = concat_path(&(v227_6),&(v227_7_head));
          let v229_7: Space = routine_34(c, &(v229_6), &(*p1), &(v227_7_tail), &(*s1));
          compose(&(v228_5),&(v229_7))
        };
        drop(v228_5);
        let v228_9: Space = intersect(&(*CONSTANT_2),&(v228_2));
        drop(v228_2);
        let v228_10: Space = if has_head(&(v228_9)) { singleton(&[]) } else { Space::new() };
        drop(v228_9);
        let v228_12: Space = if (v228_10).is_empty() { Space::new() } else {
          let v230_6: Path = concat_path(&(v227_6),&(v227_7_head));
          let v230_11: Space = routine_35(c, &(v230_6), &(*p1), &(v227_7_tail), &(*s1));
          drop(v230_6);
          compose(&(v228_10),&(v230_11))
        };
        drop(v228_10);
        let v228_13: Space = unite(&(v228_8),&(v228_12));
        v227_7.join_into((v228_13).clone());
      }
      drop(v227_7_cursor);
      compose(&(v226_5),&(v227_7))
    };
    drop(v226_5);
    let v226_9: Space = intersect(&(*CONSTANT_2),&(v226_2));
    drop(v226_2);
    let v226_10: Space = if has_head(&(v226_9)) { singleton(&[]) } else { Space::new() };
    drop(v226_9);
    let v226_12: Space = if (v226_10).is_empty() { Space::new() } else {
      let v231_6: Path = concat_path(&(*p0),&(v225_13_head));
      let mut v231_11 = Space::new();
      let mut v231_11_cursor = (v225_13_tail).read_zipper();
      for v231_11_byte in v231_11_cursor.child_mask().iter() {
        v231_11_cursor.descend_to_byte(v231_11_byte);
        let v231_11_tail = v231_11_cursor.make_map();
        v231_11_cursor.ascend(1);
        let v231_11_head = Path::from_slice(&[v231_11_byte]);
        let v232_2: Space = singleton(&(v231_11_head));
        let v232_3: Space = intersect(&(*CONSTANT_2),&(v232_2));
        let v232_4: Space = if has_head(&(v232_3)) { singleton(&[]) } else { Space::new() };
        drop(v232_3);
        let v232_5: Space = subtract(&(*CONSTANT_1),&(v232_4));
        drop(v232_4);
        let v232_8: Space = if (v232_5).is_empty() { Space::new() } else {
          let v233_6: Path = concat_path(&(v231_6),&(v231_11_head));
          let v233_7: Space = routine_34(c, &(v233_6), &(*p1), &(v231_11_tail), &(*s1));
          compose(&(v232_5),&(v233_7))
        };
        drop(v232_5);
        let v232_9: Space = intersect(&(*CONSTANT_2),&(v232_2));
        drop(v232_2);
        let v232_10: Space = if has_head(&(v232_9)) { singleton(&[]) } else { Space::new() };
        drop(v232_9);
        let v232_12: Space = if (v232_10).is_empty() { Space::new() } else {
          let v234_6: Path = concat_path(&(v231_6),&(v231_11_head));
          let v234_11: Space = routine_10(c, &(v234_6), &(*p1), &(v231_11_tail), &(*s1));
          drop(v234_6);
          compose(&(v232_10),&(v234_11))
        };
        drop(v232_10);
        let v232_13: Space = unite(&(v232_8),&(v232_12));
        v231_11.join_into((v232_13).clone());
      }
      drop(v231_11_cursor);
      drop(v231_6);
      compose(&(v226_10),&(v231_11))
    };
    drop(v226_10);
    let v226_13: Space = unite(&(v226_8),&(v226_12));
    v225_13.join_into((v226_13).clone());
  }
  drop(v225_13_cursor);
  (v225_13).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v235_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v235_9: Space = unwrap(&(v235_8),&(*p0));
  drop(v235_8);
  let mut v235_16 = Space::new();
  let mut v235_16_cursor = (*s0).read_zipper();
  for v235_16_byte in v235_16_cursor.child_mask().iter() {
    v235_16_cursor.descend_to_byte(v235_16_byte);
    let v235_16_tail = v235_16_cursor.make_map();
    v235_16_cursor.ascend(1);
    let v235_16_head = Path::from_slice(&[v235_16_byte]);
    let v236_2: Space = singleton(&(v235_16_head));
    let v236_3: Space = intersect(&(*CONSTANT_2),&(v236_2));
    let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
    drop(v236_3);
    let v236_5: Space = subtract(&(*CONSTANT_1),&(v236_4));
    drop(v236_4);
    let v236_8: Space = if (v236_5).is_empty() { Space::new() } else {
      let v237_6: Path = concat_path(&(*p0),&(v235_16_head));
      let mut v237_7 = Space::new();
      let mut v237_7_cursor = (v235_16_tail).read_zipper();
      for v237_7_byte in v237_7_cursor.child_mask().iter() {
        v237_7_cursor.descend_to_byte(v237_7_byte);
        let v237_7_tail = v237_7_cursor.make_map();
        v237_7_cursor.ascend(1);
        let v237_7_head = Path::from_slice(&[v237_7_byte]);
        let v238_2: Space = singleton(&(v237_7_head));
        let v238_3: Space = intersect(&(*CONSTANT_2),&(v238_2));
        let v238_4: Space = if has_head(&(v238_3)) { singleton(&[]) } else { Space::new() };
        drop(v238_3);
        let v238_5: Space = subtract(&(*CONSTANT_1),&(v238_4));
        drop(v238_4);
        let v238_8: Space = if (v238_5).is_empty() { Space::new() } else {
          let v239_6: Path = concat_path(&(v237_6),&(v237_7_head));
          let v239_7: Space = routine_34(c, &(v239_6), &(*p1), &(v237_7_tail), &(*s1));
          compose(&(v238_5),&(v239_7))
        };
        drop(v238_5);
        let v238_9: Space = intersect(&(*CONSTANT_2),&(v238_2));
        drop(v238_2);
        let v238_10: Space = if has_head(&(v238_9)) { singleton(&[]) } else { Space::new() };
        drop(v238_9);
        let v238_12: Space = if (v238_10).is_empty() { Space::new() } else {
          let v240_6: Path = concat_path(&(v237_6),&(v237_7_head));
          let v240_11: Space = routine_35(c, &(v240_6), &(*p1), &(v237_7_tail), &(*s1));
          drop(v240_6);
          compose(&(v238_10),&(v240_11))
        };
        drop(v238_10);
        let v238_13: Space = unite(&(v238_8),&(v238_12));
        v237_7.join_into((v238_13).clone());
      }
      drop(v237_7_cursor);
      drop(v237_6);
      compose(&(v236_5),&(v237_7))
    };
    drop(v236_5);
    let v236_9: Space = intersect(&(*CONSTANT_2),&(v236_2));
    drop(v236_2);
    let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
    drop(v236_9);
    let v236_13: Space = if (v236_10).is_empty() { Space::new() } else {
      let v241_11: Space = unwrap(&(v235_9),&(v235_16_head));
      let mut v241_12 = Space::new();
      let mut v241_12_cursor = (v241_11).read_zipper();
      for v241_12_byte in v241_12_cursor.child_mask().iter() {
        v241_12_cursor.descend_to_byte(v241_12_byte);
        let v241_12_tail = v241_12_cursor.make_map();
        v241_12_cursor.ascend(1);
        let v241_12_head = Path::from_slice(&[v241_12_byte]);
        let v242_2: Space = singleton(&(v241_12_head));
        let v242_3: Space = intersect(&(*CONSTANT_2),&(v242_2));
        let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = subtract(&(*CONSTANT_1),&(v242_4));
        drop(v242_4);
        let v242_7: Space = if (v242_5).is_empty() { Space::new() } else {
          let v243_6: Space = routine_15(c, &(v241_12_head), &(*p1), &(v241_12_tail));
          compose(&(v242_5),&(v243_6))
        };
        drop(v242_5);
        let v242_8: Space = intersect(&(*CONSTANT_2),&(v242_2));
        drop(v242_2);
        let v242_9: Space = if has_head(&(v242_8)) { singleton(&[]) } else { Space::new() };
        drop(v242_8);
        let v242_11: Space = if (v242_9).is_empty() { Space::new() } else {
          let v244_10: Space = routine_16(c, &(v241_12_head), &(*p1), &(v241_12_tail));
          compose(&(v242_9),&(v244_10))
        };
        drop(v242_9);
        let v242_12: Space = unite(&(v242_7),&(v242_11));
        v241_12.join_into((v242_12).clone());
      }
      drop(v241_12_cursor);
      drop(v241_11);
      compose(&(v236_10),&(v241_12))
    };
    drop(v236_10);
    let v236_14: Space = unite(&(v236_8),&(v236_13));
    v235_16.join_into((v236_14).clone());
  }
  drop(v235_16_cursor);
  drop(v235_9);
  (v235_16).clone()
}

fn routine_26(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v245_12 = Space::new();
  let mut v245_12_cursor = (*s0).read_zipper();
  for v245_12_byte in v245_12_cursor.child_mask().iter() {
    v245_12_cursor.descend_to_byte(v245_12_byte);
    let v245_12_tail = v245_12_cursor.make_map();
    v245_12_cursor.ascend(1);
    let v245_12_head = Path::from_slice(&[v245_12_byte]);
    let v246_2: Space = singleton(&(v245_12_head));
    let v246_3: Space = intersect(&(*CONSTANT_2),&(v246_2));
    let v246_4: Space = if has_head(&(v246_3)) { singleton(&[]) } else { Space::new() };
    drop(v246_3);
    let v246_5: Space = subtract(&(*CONSTANT_1),&(v246_4));
    drop(v246_4);
    let v246_8: Space = if (v246_5).is_empty() { Space::new() } else {
      let v247_6: Path = concat_path(&(*p0),&(v245_12_head));
      let mut v247_7 = Space::new();
      let mut v247_7_cursor = (v245_12_tail).read_zipper();
      for v247_7_byte in v247_7_cursor.child_mask().iter() {
        v247_7_cursor.descend_to_byte(v247_7_byte);
        let v247_7_tail = v247_7_cursor.make_map();
        v247_7_cursor.ascend(1);
        let v247_7_head = Path::from_slice(&[v247_7_byte]);
        let v248_2: Space = singleton(&(v247_7_head));
        let v248_3: Space = intersect(&(*CONSTANT_2),&(v248_2));
        let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
        drop(v248_3);
        let v248_5: Space = subtract(&(*CONSTANT_1),&(v248_4));
        drop(v248_4);
        let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
          let v249_6: Path = concat_path(&(v247_6),&(v247_7_head));
          let v249_7: Space = routine_36(c, &(v249_6), &(*p1), &(v247_7_tail));
          compose(&(v248_5),&(v249_7))
        };
        drop(v248_5);
        let v248_9: Space = intersect(&(*CONSTANT_2),&(v248_2));
        drop(v248_2);
        let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
        drop(v248_9);
        let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
          let v250_6: Path = concat_path(&(v247_6),&(v247_7_head));
          let v250_11: Space = routine_37(c, &(v250_6), &(*p1), &(v247_7_tail));
          drop(v250_6);
          compose(&(v248_10),&(v250_11))
        };
        drop(v248_10);
        let v248_13: Space = unite(&(v248_8),&(v248_12));
        v247_7.join_into((v248_13).clone());
      }
      drop(v247_7_cursor);
      compose(&(v246_5),&(v247_7))
    };
    drop(v246_5);
    let v246_9: Space = intersect(&(*CONSTANT_2),&(v246_2));
    drop(v246_2);
    let v246_10: Space = if has_head(&(v246_9)) { singleton(&[]) } else { Space::new() };
    drop(v246_9);
    let v246_12: Space = if (v246_10).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&(v245_12_head));
      let mut v251_11 = Space::new();
      let mut v251_11_cursor = (v245_12_tail).read_zipper();
      for v251_11_byte in v251_11_cursor.child_mask().iter() {
        v251_11_cursor.descend_to_byte(v251_11_byte);
        let v251_11_tail = v251_11_cursor.make_map();
        v251_11_cursor.ascend(1);
        let v251_11_head = Path::from_slice(&[v251_11_byte]);
        let v252_2: Space = singleton(&(v251_11_head));
        let v252_3: Space = intersect(&(*CONSTANT_2),&(v252_2));
        let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = subtract(&(*CONSTANT_1),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (v252_5).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&(v251_11_head));
          let v253_7: Space = routine_36(c, &(v253_6), &(*p1), &(v251_11_tail));
          compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = intersect(&(*CONSTANT_2),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_12: Space = if (v252_10).is_empty() { Space::new() } else {
          let v254_6: Path = concat_path(&(v251_6),&(v251_11_head));
          let v254_11: Space = routine_21(c, &(v254_6), &(*p1), &(v251_11_tail));
          drop(v254_6);
          compose(&(v252_10),&(v254_11))
        };
        drop(v252_10);
        let v252_13: Space = unite(&(v252_8),&(v252_12));
        v251_11.join_into((v252_13).clone());
      }
      drop(v251_11_cursor);
      drop(v251_6);
      compose(&(v246_10),&(v251_11))
    };
    drop(v246_10);
    let v246_13: Space = unite(&(v246_8),&(v246_12));
    v245_12.join_into((v246_13).clone());
  }
  drop(v245_12_cursor);
  (v245_12).clone()
}

fn routine_27(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v255_9 = Space::new();
  let mut v255_9_cursor = (*s0).read_zipper();
  for v255_9_byte in v255_9_cursor.child_mask().iter() {
    v255_9_cursor.descend_to_byte(v255_9_byte);
    let v255_9_tail = v255_9_cursor.make_map();
    v255_9_cursor.ascend(1);
    let v255_9_head = Path::from_slice(&[v255_9_byte]);
    let v256_2: Space = singleton(&(v255_9_head));
    let v256_3: Space = intersect(&(*CONSTANT_2),&(v256_2));
    let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
    drop(v256_3);
    let v256_5: Space = subtract(&(*CONSTANT_1),&(v256_4));
    drop(v256_4);
    let v256_8: Space = if (v256_5).is_empty() { Space::new() } else {
      let v257_6: Path = concat_path(&(*p0),&(v255_9_head));
      let mut v257_7 = Space::new();
      let mut v257_7_cursor = (v255_9_tail).read_zipper();
      for v257_7_byte in v257_7_cursor.child_mask().iter() {
        v257_7_cursor.descend_to_byte(v257_7_byte);
        let v257_7_tail = v257_7_cursor.make_map();
        v257_7_cursor.ascend(1);
        let v257_7_head = Path::from_slice(&[v257_7_byte]);
        let v258_2: Space = singleton(&(v257_7_head));
        let v258_3: Space = intersect(&(*CONSTANT_2),&(v258_2));
        let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
        drop(v258_3);
        let v258_5: Space = subtract(&(*CONSTANT_1),&(v258_4));
        drop(v258_4);
        let v258_8: Space = if (v258_5).is_empty() { Space::new() } else {
          let v259_6: Path = concat_path(&(v257_6),&(v257_7_head));
          let v259_7: Space = routine_36(c, &(v259_6), &(*p1), &(v257_7_tail));
          compose(&(v258_5),&(v259_7))
        };
        drop(v258_5);
        let v258_9: Space = intersect(&(*CONSTANT_2),&(v258_2));
        drop(v258_2);
        let v258_10: Space = if has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
        drop(v258_9);
        let v258_12: Space = if (v258_10).is_empty() { Space::new() } else {
          let v260_6: Path = concat_path(&(v257_6),&(v257_7_head));
          let v260_11: Space = routine_37(c, &(v260_6), &(*p1), &(v257_7_tail));
          drop(v260_6);
          compose(&(v258_10),&(v260_11))
        };
        drop(v258_10);
        let v258_13: Space = unite(&(v258_8),&(v258_12));
        v257_7.join_into((v258_13).clone());
      }
      drop(v257_7_cursor);
      compose(&(v256_5),&(v257_7))
    };
    drop(v256_5);
    let v256_9: Space = intersect(&(*CONSTANT_2),&(v256_2));
    drop(v256_2);
    let v256_10: Space = if has_head(&(v256_9)) { singleton(&[]) } else { Space::new() };
    drop(v256_9);
    let v256_11: Space = compose(&(v256_10),&(v255_9_tail));
    drop(v256_10);
    let v261_6: Path = concat_path(&(*p0),&(v255_9_head));
    let v256_12: Space = wrap(&(v256_11),&(v261_6));
    drop(v256_11);
    let v256_13: Space = wrap(&(v256_12),&(*p1));
    drop(v256_12);
    let v256_14: Space = unite(&(v256_8),&(v256_13));
    drop(v256_13);
    v255_9.join_into((v256_14).clone());
  }
  drop(v255_9_cursor);
  (v255_9).clone()
}

fn routine_28(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v262_13 = Space::new();
  let mut v262_13_cursor = (*s0).read_zipper();
  for v262_13_byte in v262_13_cursor.child_mask().iter() {
    v262_13_cursor.descend_to_byte(v262_13_byte);
    let v262_13_tail = v262_13_cursor.make_map();
    v262_13_cursor.ascend(1);
    let v262_13_head = Path::from_slice(&[v262_13_byte]);
    let v263_2: Space = singleton(&(v262_13_head));
    let v263_3: Space = intersect(&(*CONSTANT_2),&(v263_2));
    let v263_4: Space = if has_head(&(v263_3)) { singleton(&[]) } else { Space::new() };
    drop(v263_3);
    let v263_5: Space = subtract(&(*CONSTANT_1),&(v263_4));
    drop(v263_4);
    let v263_8: Space = if (v263_5).is_empty() { Space::new() } else {
      let v264_6: Path = concat_path(&(*p0),&(v262_13_head));
      let mut v264_7 = Space::new();
      let mut v264_7_cursor = (v262_13_tail).read_zipper();
      for v264_7_byte in v264_7_cursor.child_mask().iter() {
        v264_7_cursor.descend_to_byte(v264_7_byte);
        let v264_7_tail = v264_7_cursor.make_map();
        v264_7_cursor.ascend(1);
        let v264_7_head = Path::from_slice(&[v264_7_byte]);
        let v265_2: Space = singleton(&(v264_7_head));
        let v265_3: Space = intersect(&(*CONSTANT_2),&(v265_2));
        let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
        drop(v265_3);
        let v265_5: Space = subtract(&(*CONSTANT_1),&(v265_4));
        drop(v265_4);
        let v265_8: Space = if (v265_5).is_empty() { Space::new() } else {
          let v266_6: Path = concat_path(&(v264_6),&(v264_7_head));
          let v266_7: Space = routine_38(c, &(v266_6), &(*p1), &(v264_7_tail), &(*s1));
          compose(&(v265_5),&(v266_7))
        };
        drop(v265_5);
        let v265_9: Space = intersect(&(*CONSTANT_2),&(v265_2));
        drop(v265_2);
        let v265_10: Space = if has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
        drop(v265_9);
        let v265_12: Space = if (v265_10).is_empty() { Space::new() } else {
          let v267_6: Path = concat_path(&(v264_6),&(v264_7_head));
          let v267_11: Space = routine_39(c, &(v267_6), &(*p1), &(v264_7_tail), &(*s1));
          drop(v267_6);
          compose(&(v265_10),&(v267_11))
        };
        drop(v265_10);
        let v265_13: Space = unite(&(v265_8),&(v265_12));
        v264_7.join_into((v265_13).clone());
      }
      drop(v264_7_cursor);
      compose(&(v263_5),&(v264_7))
    };
    drop(v263_5);
    let v263_9: Space = intersect(&(*CONSTANT_2),&(v263_2));
    drop(v263_2);
    let v263_10: Space = if has_head(&(v263_9)) { singleton(&[]) } else { Space::new() };
    drop(v263_9);
    let v263_12: Space = if (v263_10).is_empty() { Space::new() } else {
      let v268_6: Path = concat_path(&(*p0),&(v262_13_head));
      let mut v268_11 = Space::new();
      let mut v268_11_cursor = (v262_13_tail).read_zipper();
      for v268_11_byte in v268_11_cursor.child_mask().iter() {
        v268_11_cursor.descend_to_byte(v268_11_byte);
        let v268_11_tail = v268_11_cursor.make_map();
        v268_11_cursor.ascend(1);
        let v268_11_head = Path::from_slice(&[v268_11_byte]);
        let v269_2: Space = singleton(&(v268_11_head));
        let v269_3: Space = intersect(&(*CONSTANT_2),&(v269_2));
        let v269_4: Space = if has_head(&(v269_3)) { singleton(&[]) } else { Space::new() };
        drop(v269_3);
        let v269_5: Space = subtract(&(*CONSTANT_1),&(v269_4));
        drop(v269_4);
        let v269_8: Space = if (v269_5).is_empty() { Space::new() } else {
          let v270_6: Path = concat_path(&(v268_6),&(v268_11_head));
          let v270_7: Space = routine_38(c, &(v270_6), &(*p1), &(v268_11_tail), &(*s1));
          compose(&(v269_5),&(v270_7))
        };
        drop(v269_5);
        let v269_9: Space = intersect(&(*CONSTANT_2),&(v269_2));
        drop(v269_2);
        let v269_10: Space = if has_head(&(v269_9)) { singleton(&[]) } else { Space::new() };
        drop(v269_9);
        let v269_12: Space = if (v269_10).is_empty() { Space::new() } else {
          let v271_6: Path = concat_path(&(v268_6),&(v268_11_head));
          let v271_11: Space = routine_10(c, &(v271_6), &(*p1), &(v268_11_tail), &(*s1));
          drop(v271_6);
          compose(&(v269_10),&(v271_11))
        };
        drop(v269_10);
        let v269_13: Space = unite(&(v269_8),&(v269_12));
        v268_11.join_into((v269_13).clone());
      }
      drop(v268_11_cursor);
      drop(v268_6);
      compose(&(v263_10),&(v268_11))
    };
    drop(v263_10);
    let v263_13: Space = unite(&(v263_8),&(v263_12));
    v262_13.join_into((v263_13).clone());
  }
  drop(v262_13_cursor);
  (v262_13).clone()
}

fn routine_29(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v272_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v272_9: Space = unwrap(&(v272_8),&(*p0));
  drop(v272_8);
  let mut v272_16 = Space::new();
  let mut v272_16_cursor = (*s0).read_zipper();
  for v272_16_byte in v272_16_cursor.child_mask().iter() {
    v272_16_cursor.descend_to_byte(v272_16_byte);
    let v272_16_tail = v272_16_cursor.make_map();
    v272_16_cursor.ascend(1);
    let v272_16_head = Path::from_slice(&[v272_16_byte]);
    let v273_2: Space = singleton(&(v272_16_head));
    let v273_3: Space = intersect(&(*CONSTANT_2),&(v273_2));
    let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
    drop(v273_3);
    let v273_5: Space = subtract(&(*CONSTANT_1),&(v273_4));
    drop(v273_4);
    let v273_8: Space = if (v273_5).is_empty() { Space::new() } else {
      let v274_6: Path = concat_path(&(*p0),&(v272_16_head));
      let mut v274_7 = Space::new();
      let mut v274_7_cursor = (v272_16_tail).read_zipper();
      for v274_7_byte in v274_7_cursor.child_mask().iter() {
        v274_7_cursor.descend_to_byte(v274_7_byte);
        let v274_7_tail = v274_7_cursor.make_map();
        v274_7_cursor.ascend(1);
        let v274_7_head = Path::from_slice(&[v274_7_byte]);
        let v275_2: Space = singleton(&(v274_7_head));
        let v275_3: Space = intersect(&(*CONSTANT_2),&(v275_2));
        let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
        drop(v275_3);
        let v275_5: Space = subtract(&(*CONSTANT_1),&(v275_4));
        drop(v275_4);
        let v275_8: Space = if (v275_5).is_empty() { Space::new() } else {
          let v276_6: Path = concat_path(&(v274_6),&(v274_7_head));
          let v276_7: Space = routine_38(c, &(v276_6), &(*p1), &(v274_7_tail), &(*s1));
          compose(&(v275_5),&(v276_7))
        };
        drop(v275_5);
        let v275_9: Space = intersect(&(*CONSTANT_2),&(v275_2));
        drop(v275_2);
        let v275_10: Space = if has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
        drop(v275_9);
        let v275_12: Space = if (v275_10).is_empty() { Space::new() } else {
          let v277_6: Path = concat_path(&(v274_6),&(v274_7_head));
          let v277_11: Space = routine_39(c, &(v277_6), &(*p1), &(v274_7_tail), &(*s1));
          drop(v277_6);
          compose(&(v275_10),&(v277_11))
        };
        drop(v275_10);
        let v275_13: Space = unite(&(v275_8),&(v275_12));
        v274_7.join_into((v275_13).clone());
      }
      drop(v274_7_cursor);
      drop(v274_6);
      compose(&(v273_5),&(v274_7))
    };
    drop(v273_5);
    let v273_9: Space = intersect(&(*CONSTANT_2),&(v273_2));
    drop(v273_2);
    let v273_10: Space = if has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
    drop(v273_9);
    let v273_13: Space = if (v273_10).is_empty() { Space::new() } else {
      let v278_11: Space = unwrap(&(v272_9),&(v272_16_head));
      let mut v278_12 = Space::new();
      let mut v278_12_cursor = (v278_11).read_zipper();
      for v278_12_byte in v278_12_cursor.child_mask().iter() {
        v278_12_cursor.descend_to_byte(v278_12_byte);
        let v278_12_tail = v278_12_cursor.make_map();
        v278_12_cursor.ascend(1);
        let v278_12_head = Path::from_slice(&[v278_12_byte]);
        let v279_2: Space = singleton(&(v278_12_head));
        let v279_3: Space = intersect(&(*CONSTANT_2),&(v279_2));
        let v279_4: Space = if has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
        drop(v279_3);
        let v279_5: Space = subtract(&(*CONSTANT_1),&(v279_4));
        drop(v279_4);
        let v279_7: Space = if (v279_5).is_empty() { Space::new() } else {
          let v280_6: Space = routine_15(c, &(v278_12_head), &(*p1), &(v278_12_tail));
          compose(&(v279_5),&(v280_6))
        };
        drop(v279_5);
        let v279_8: Space = intersect(&(*CONSTANT_2),&(v279_2));
        drop(v279_2);
        let v279_9: Space = if has_head(&(v279_8)) { singleton(&[]) } else { Space::new() };
        drop(v279_8);
        let v279_11: Space = if (v279_9).is_empty() { Space::new() } else {
          let v281_10: Space = routine_16(c, &(v278_12_head), &(*p1), &(v278_12_tail));
          compose(&(v279_9),&(v281_10))
        };
        drop(v279_9);
        let v279_12: Space = unite(&(v279_7),&(v279_11));
        v278_12.join_into((v279_12).clone());
      }
      drop(v278_12_cursor);
      drop(v278_11);
      compose(&(v273_10),&(v278_12))
    };
    drop(v273_10);
    let v273_14: Space = unite(&(v273_8),&(v273_13));
    v272_16.join_into((v273_14).clone());
  }
  drop(v272_16_cursor);
  drop(v272_9);
  (v272_16).clone()
}

fn routine_30(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v282_12 = Space::new();
  let mut v282_12_cursor = (*s0).read_zipper();
  for v282_12_byte in v282_12_cursor.child_mask().iter() {
    v282_12_cursor.descend_to_byte(v282_12_byte);
    let v282_12_tail = v282_12_cursor.make_map();
    v282_12_cursor.ascend(1);
    let v282_12_head = Path::from_slice(&[v282_12_byte]);
    let v283_2: Space = singleton(&(v282_12_head));
    let v283_3: Space = intersect(&(*CONSTANT_2),&(v283_2));
    let v283_4: Space = if has_head(&(v283_3)) { singleton(&[]) } else { Space::new() };
    drop(v283_3);
    let v283_5: Space = subtract(&(*CONSTANT_1),&(v283_4));
    drop(v283_4);
    let v283_8: Space = if (v283_5).is_empty() { Space::new() } else {
      let v284_6: Path = concat_path(&(*p0),&(v282_12_head));
      let mut v284_7 = Space::new();
      let mut v284_7_cursor = (v282_12_tail).read_zipper();
      for v284_7_byte in v284_7_cursor.child_mask().iter() {
        v284_7_cursor.descend_to_byte(v284_7_byte);
        let v284_7_tail = v284_7_cursor.make_map();
        v284_7_cursor.ascend(1);
        let v284_7_head = Path::from_slice(&[v284_7_byte]);
        let v285_2: Space = singleton(&(v284_7_head));
        let v285_3: Space = intersect(&(*CONSTANT_2),&(v285_2));
        let v285_4: Space = if has_head(&(v285_3)) { singleton(&[]) } else { Space::new() };
        drop(v285_3);
        let v285_5: Space = subtract(&(*CONSTANT_1),&(v285_4));
        drop(v285_4);
        let v285_8: Space = if (v285_5).is_empty() { Space::new() } else {
          let v286_6: Path = concat_path(&(v284_6),&(v284_7_head));
          let v286_7: Space = routine_40(c, &(v286_6), &(*p1), &(v284_7_tail));
          compose(&(v285_5),&(v286_7))
        };
        drop(v285_5);
        let v285_9: Space = intersect(&(*CONSTANT_2),&(v285_2));
        drop(v285_2);
        let v285_10: Space = if has_head(&(v285_9)) { singleton(&[]) } else { Space::new() };
        drop(v285_9);
        let v285_12: Space = if (v285_10).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v284_6),&(v284_7_head));
          let v287_11: Space = routine_41(c, &(v287_6), &(*p1), &(v284_7_tail));
          drop(v287_6);
          compose(&(v285_10),&(v287_11))
        };
        drop(v285_10);
        let v285_13: Space = unite(&(v285_8),&(v285_12));
        v284_7.join_into((v285_13).clone());
      }
      drop(v284_7_cursor);
      compose(&(v283_5),&(v284_7))
    };
    drop(v283_5);
    let v283_9: Space = intersect(&(*CONSTANT_2),&(v283_2));
    drop(v283_2);
    let v283_10: Space = if has_head(&(v283_9)) { singleton(&[]) } else { Space::new() };
    drop(v283_9);
    let v283_12: Space = if (v283_10).is_empty() { Space::new() } else {
      let v288_6: Path = concat_path(&(*p0),&(v282_12_head));
      let mut v288_11 = Space::new();
      let mut v288_11_cursor = (v282_12_tail).read_zipper();
      for v288_11_byte in v288_11_cursor.child_mask().iter() {
        v288_11_cursor.descend_to_byte(v288_11_byte);
        let v288_11_tail = v288_11_cursor.make_map();
        v288_11_cursor.ascend(1);
        let v288_11_head = Path::from_slice(&[v288_11_byte]);
        let v289_2: Space = singleton(&(v288_11_head));
        let v289_3: Space = intersect(&(*CONSTANT_2),&(v289_2));
        let v289_4: Space = if has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
        drop(v289_3);
        let v289_5: Space = subtract(&(*CONSTANT_1),&(v289_4));
        drop(v289_4);
        let v289_8: Space = if (v289_5).is_empty() { Space::new() } else {
          let v290_6: Path = concat_path(&(v288_6),&(v288_11_head));
          let v290_7: Space = routine_40(c, &(v290_6), &(*p1), &(v288_11_tail));
          compose(&(v289_5),&(v290_7))
        };
        drop(v289_5);
        let v289_9: Space = intersect(&(*CONSTANT_2),&(v289_2));
        drop(v289_2);
        let v289_10: Space = if has_head(&(v289_9)) { singleton(&[]) } else { Space::new() };
        drop(v289_9);
        let v289_12: Space = if (v289_10).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v288_6),&(v288_11_head));
          let v291_11: Space = routine_21(c, &(v291_6), &(*p1), &(v288_11_tail));
          drop(v291_6);
          compose(&(v289_10),&(v291_11))
        };
        drop(v289_10);
        let v289_13: Space = unite(&(v289_8),&(v289_12));
        v288_11.join_into((v289_13).clone());
      }
      drop(v288_11_cursor);
      drop(v288_6);
      compose(&(v283_10),&(v288_11))
    };
    drop(v283_10);
    let v283_13: Space = unite(&(v283_8),&(v283_12));
    v282_12.join_into((v283_13).clone());
  }
  drop(v282_12_cursor);
  (v282_12).clone()
}

fn routine_31(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v292_9 = Space::new();
  let mut v292_9_cursor = (*s0).read_zipper();
  for v292_9_byte in v292_9_cursor.child_mask().iter() {
    v292_9_cursor.descend_to_byte(v292_9_byte);
    let v292_9_tail = v292_9_cursor.make_map();
    v292_9_cursor.ascend(1);
    let v292_9_head = Path::from_slice(&[v292_9_byte]);
    let v293_2: Space = singleton(&(v292_9_head));
    let v293_3: Space = intersect(&(*CONSTANT_2),&(v293_2));
    let v293_4: Space = if has_head(&(v293_3)) { singleton(&[]) } else { Space::new() };
    drop(v293_3);
    let v293_5: Space = subtract(&(*CONSTANT_1),&(v293_4));
    drop(v293_4);
    let v293_8: Space = if (v293_5).is_empty() { Space::new() } else {
      let v294_6: Path = concat_path(&(*p0),&(v292_9_head));
      let mut v294_7 = Space::new();
      let mut v294_7_cursor = (v292_9_tail).read_zipper();
      for v294_7_byte in v294_7_cursor.child_mask().iter() {
        v294_7_cursor.descend_to_byte(v294_7_byte);
        let v294_7_tail = v294_7_cursor.make_map();
        v294_7_cursor.ascend(1);
        let v294_7_head = Path::from_slice(&[v294_7_byte]);
        let v295_2: Space = singleton(&(v294_7_head));
        let v295_3: Space = intersect(&(*CONSTANT_2),&(v295_2));
        let v295_4: Space = if has_head(&(v295_3)) { singleton(&[]) } else { Space::new() };
        drop(v295_3);
        let v295_5: Space = subtract(&(*CONSTANT_1),&(v295_4));
        drop(v295_4);
        let v295_8: Space = if (v295_5).is_empty() { Space::new() } else {
          let v296_6: Path = concat_path(&(v294_6),&(v294_7_head));
          let v296_7: Space = routine_40(c, &(v296_6), &(*p1), &(v294_7_tail));
          compose(&(v295_5),&(v296_7))
        };
        drop(v295_5);
        let v295_9: Space = intersect(&(*CONSTANT_2),&(v295_2));
        drop(v295_2);
        let v295_10: Space = if has_head(&(v295_9)) { singleton(&[]) } else { Space::new() };
        drop(v295_9);
        let v295_12: Space = if (v295_10).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v294_6),&(v294_7_head));
          let v297_11: Space = routine_41(c, &(v297_6), &(*p1), &(v294_7_tail));
          drop(v297_6);
          compose(&(v295_10),&(v297_11))
        };
        drop(v295_10);
        let v295_13: Space = unite(&(v295_8),&(v295_12));
        v294_7.join_into((v295_13).clone());
      }
      drop(v294_7_cursor);
      compose(&(v293_5),&(v294_7))
    };
    drop(v293_5);
    let v293_9: Space = intersect(&(*CONSTANT_2),&(v293_2));
    drop(v293_2);
    let v293_10: Space = if has_head(&(v293_9)) { singleton(&[]) } else { Space::new() };
    drop(v293_9);
    let v293_11: Space = compose(&(v293_10),&(v292_9_tail));
    drop(v293_10);
    let v298_6: Path = concat_path(&(*p0),&(v292_9_head));
    let v293_12: Space = wrap(&(v293_11),&(v298_6));
    drop(v293_11);
    let v293_13: Space = wrap(&(v293_12),&(*p1));
    drop(v293_12);
    let v293_14: Space = unite(&(v293_8),&(v293_13));
    drop(v293_13);
    v292_9.join_into((v293_14).clone());
  }
  drop(v292_9_cursor);
  (v292_9).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v299_12 = Space::new();
  let mut v299_12_cursor = (*s0).read_zipper();
  for v299_12_byte in v299_12_cursor.child_mask().iter() {
    v299_12_cursor.descend_to_byte(v299_12_byte);
    let v299_12_tail = v299_12_cursor.make_map();
    v299_12_cursor.ascend(1);
    let v299_12_head = Path::from_slice(&[v299_12_byte]);
    let v300_2: Space = singleton(&(v299_12_head));
    let v300_3: Space = intersect(&(*CONSTANT_2),&(v300_2));
    let v300_4: Space = if has_head(&(v300_3)) { singleton(&[]) } else { Space::new() };
    drop(v300_3);
    let v300_5: Space = subtract(&(*CONSTANT_1),&(v300_4));
    drop(v300_4);
    let v300_8: Space = if (v300_5).is_empty() { Space::new() } else {
      let v301_6: Path = concat_path(&(*p0),&(v299_12_head));
      let mut v301_7 = Space::new();
      let mut v301_7_cursor = (v299_12_tail).read_zipper();
      for v301_7_byte in v301_7_cursor.child_mask().iter() {
        v301_7_cursor.descend_to_byte(v301_7_byte);
        let v301_7_tail = v301_7_cursor.make_map();
        v301_7_cursor.ascend(1);
        let v301_7_head = Path::from_slice(&[v301_7_byte]);
        let v302_2: Space = singleton(&(v301_7_head));
        let v302_3: Space = intersect(&(*CONSTANT_2),&(v302_2));
        let v302_4: Space = if has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
        drop(v302_3);
        let v302_5: Space = subtract(&(*CONSTANT_1),&(v302_4));
        drop(v302_4);
        let v302_8: Space = if (v302_5).is_empty() { Space::new() } else {
          let v303_6: Path = concat_path(&(v301_6),&(v301_7_head));
          let v303_7: Space = routine_42(c, &(v303_6), &(v301_7_tail), &(*s1));
          compose(&(v302_5),&(v303_7))
        };
        drop(v302_5);
        let v302_9: Space = intersect(&(*CONSTANT_2),&(v302_2));
        drop(v302_2);
        let v302_10: Space = if has_head(&(v302_9)) { singleton(&[]) } else { Space::new() };
        drop(v302_9);
        let v302_12: Space = if (v302_10).is_empty() { Space::new() } else {
          let v304_6: Path = concat_path(&(v301_6),&(v301_7_head));
          let v304_11: Space = routine_43(c, &(v304_6), &(v301_7_tail), &(*s1));
          drop(v304_6);
          compose(&(v302_10),&(v304_11))
        };
        drop(v302_10);
        let v302_13: Space = unite(&(v302_8),&(v302_12));
        v301_7.join_into((v302_13).clone());
      }
      drop(v301_7_cursor);
      compose(&(v300_5),&(v301_7))
    };
    drop(v300_5);
    let v300_9: Space = intersect(&(*CONSTANT_2),&(v300_2));
    drop(v300_2);
    let v300_10: Space = if has_head(&(v300_9)) { singleton(&[]) } else { Space::new() };
    drop(v300_9);
    let v300_12: Space = if (v300_10).is_empty() { Space::new() } else {
      let v305_6: Path = concat_path(&(*p0),&(v299_12_head));
      let mut v305_11 = Space::new();
      let mut v305_11_cursor = (v299_12_tail).read_zipper();
      for v305_11_byte in v305_11_cursor.child_mask().iter() {
        v305_11_cursor.descend_to_byte(v305_11_byte);
        let v305_11_tail = v305_11_cursor.make_map();
        v305_11_cursor.ascend(1);
        let v305_11_head = Path::from_slice(&[v305_11_byte]);
        let v306_2: Space = singleton(&(v305_11_head));
        let v306_3: Space = intersect(&(*CONSTANT_2),&(v306_2));
        let v306_4: Space = if has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
        drop(v306_3);
        let v306_5: Space = subtract(&(*CONSTANT_1),&(v306_4));
        drop(v306_4);
        let v306_8: Space = if (v306_5).is_empty() { Space::new() } else {
          let v307_6: Path = concat_path(&(v305_6),&(v305_11_head));
          let v307_7: Space = routine_42(c, &(v307_6), &(v305_11_tail), &(*s1));
          compose(&(v306_5),&(v307_7))
        };
        drop(v306_5);
        let v306_9: Space = intersect(&(*CONSTANT_2),&(v306_2));
        drop(v306_2);
        let v306_10: Space = if has_head(&(v306_9)) { singleton(&[]) } else { Space::new() };
        drop(v306_9);
        let v306_12: Space = if (v306_10).is_empty() { Space::new() } else {
          let v308_6: Path = concat_path(&(v305_6),&(v305_11_head));
          let v308_11: Space = routine_3(c, &(v308_6), &(v305_11_tail), &(*s1));
          drop(v308_6);
          compose(&(v306_10),&(v308_11))
        };
        drop(v306_10);
        let v306_13: Space = unite(&(v306_8),&(v306_12));
        v305_11.join_into((v306_13).clone());
      }
      drop(v305_11_cursor);
      drop(v305_6);
      compose(&(v300_10),&(v305_11))
    };
    drop(v300_10);
    let v300_13: Space = unite(&(v300_8),&(v300_12));
    v299_12.join_into((v300_13).clone());
  }
  drop(v299_12_cursor);
  (v299_12).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v309_12 = Space::new();
  let mut v309_12_cursor = (*s0).read_zipper();
  for v309_12_byte in v309_12_cursor.child_mask().iter() {
    v309_12_cursor.descend_to_byte(v309_12_byte);
    let v309_12_tail = v309_12_cursor.make_map();
    v309_12_cursor.ascend(1);
    let v309_12_head = Path::from_slice(&[v309_12_byte]);
    let v310_2: Space = singleton(&(v309_12_head));
    let v310_3: Space = intersect(&(*CONSTANT_2),&(v310_2));
    let v310_4: Space = if has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
    drop(v310_3);
    let v310_5: Space = subtract(&(*CONSTANT_1),&(v310_4));
    drop(v310_4);
    let v310_8: Space = if (v310_5).is_empty() { Space::new() } else {
      let v311_6: Path = concat_path(&(*p0),&(v309_12_head));
      let mut v311_7 = Space::new();
      let mut v311_7_cursor = (v309_12_tail).read_zipper();
      for v311_7_byte in v311_7_cursor.child_mask().iter() {
        v311_7_cursor.descend_to_byte(v311_7_byte);
        let v311_7_tail = v311_7_cursor.make_map();
        v311_7_cursor.ascend(1);
        let v311_7_head = Path::from_slice(&[v311_7_byte]);
        let v312_2: Space = singleton(&(v311_7_head));
        let v312_3: Space = intersect(&(*CONSTANT_2),&(v312_2));
        let v312_4: Space = if has_head(&(v312_3)) { singleton(&[]) } else { Space::new() };
        drop(v312_3);
        let v312_5: Space = subtract(&(*CONSTANT_1),&(v312_4));
        drop(v312_4);
        let v312_8: Space = if (v312_5).is_empty() { Space::new() } else {
          let v313_6: Path = concat_path(&(v311_6),&(v311_7_head));
          let v313_7: Space = routine_42(c, &(v313_6), &(v311_7_tail), &(*s1));
          compose(&(v312_5),&(v313_7))
        };
        drop(v312_5);
        let v312_9: Space = intersect(&(*CONSTANT_2),&(v312_2));
        drop(v312_2);
        let v312_10: Space = if has_head(&(v312_9)) { singleton(&[]) } else { Space::new() };
        drop(v312_9);
        let v312_12: Space = if (v312_10).is_empty() { Space::new() } else {
          let v314_6: Path = concat_path(&(v311_6),&(v311_7_head));
          let v314_11: Space = routine_43(c, &(v314_6), &(v311_7_tail), &(*s1));
          drop(v314_6);
          compose(&(v312_10),&(v314_11))
        };
        drop(v312_10);
        let v312_13: Space = unite(&(v312_8),&(v312_12));
        v311_7.join_into((v312_13).clone());
      }
      drop(v311_7_cursor);
      compose(&(v310_5),&(v311_7))
    };
    drop(v310_5);
    let v310_9: Space = intersect(&(*CONSTANT_2),&(v310_2));
    drop(v310_2);
    let v310_10: Space = if has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
    drop(v310_9);
    let v310_12: Space = if (v310_10).is_empty() { Space::new() } else {
      let v315_6: Path = concat_path(&(*p0),&(v309_12_head));
      let mut v315_11 = Space::new();
      let mut v315_11_cursor = (v309_12_tail).read_zipper();
      for v315_11_byte in v315_11_cursor.child_mask().iter() {
        v315_11_cursor.descend_to_byte(v315_11_byte);
        let v315_11_tail = v315_11_cursor.make_map();
        v315_11_cursor.ascend(1);
        let v315_11_head = Path::from_slice(&[v315_11_byte]);
        let v316_2: Space = singleton(&(v315_11_head));
        let v316_3: Space = intersect(&(*CONSTANT_2),&(v316_2));
        let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
        drop(v316_3);
        let v316_5: Space = subtract(&(*CONSTANT_1),&(v316_4));
        drop(v316_4);
        let v316_7: Space = if (v316_5).is_empty() { Space::new() } else {
          let v317_6: Space = routine_6(c, &(v315_11_head), &(v315_6), &(v315_11_tail), &(*s1));
          compose(&(v316_5),&(v317_6))
        };
        drop(v316_5);
        let v316_8: Space = intersect(&(*CONSTANT_2),&(v316_2));
        drop(v316_2);
        let v316_9: Space = if has_head(&(v316_8)) { singleton(&[]) } else { Space::new() };
        drop(v316_8);
        let v316_11: Space = if (v316_9).is_empty() { Space::new() } else {
          let v318_10: Space = routine_7(c, &(v315_11_head), &(v315_6), &(v315_11_tail), &(*s1));
          compose(&(v316_9),&(v318_10))
        };
        drop(v316_9);
        let v316_12: Space = unite(&(v316_7),&(v316_11));
        v315_11.join_into((v316_12).clone());
      }
      drop(v315_11_cursor);
      drop(v315_6);
      compose(&(v310_10),&(v315_11))
    };
    drop(v310_10);
    let v310_13: Space = unite(&(v310_8),&(v310_12));
    v309_12.join_into((v310_13).clone());
  }
  drop(v309_12_cursor);
  (v309_12).clone()
}

fn routine_34(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v319_13 = Space::new();
  let mut v319_13_cursor = (*s0).read_zipper();
  for v319_13_byte in v319_13_cursor.child_mask().iter() {
    v319_13_cursor.descend_to_byte(v319_13_byte);
    let v319_13_tail = v319_13_cursor.make_map();
    v319_13_cursor.ascend(1);
    let v319_13_head = Path::from_slice(&[v319_13_byte]);
    let v320_2: Space = singleton(&(v319_13_head));
    let v320_3: Space = intersect(&(*CONSTANT_2),&(v320_2));
    let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
    drop(v320_3);
    let v320_5: Space = subtract(&(*CONSTANT_1),&(v320_4));
    drop(v320_4);
    let v320_8: Space = if (v320_5).is_empty() { Space::new() } else {
      let v321_6: Path = concat_path(&(*p0),&(v319_13_head));
      let mut v321_7 = Space::new();
      let mut v321_7_cursor = (v319_13_tail).read_zipper();
      for v321_7_byte in v321_7_cursor.child_mask().iter() {
        v321_7_cursor.descend_to_byte(v321_7_byte);
        let v321_7_tail = v321_7_cursor.make_map();
        v321_7_cursor.ascend(1);
        let v321_7_head = Path::from_slice(&[v321_7_byte]);
        let v322_2: Space = singleton(&(v321_7_head));
        let v322_3: Space = intersect(&(*CONSTANT_2),&(v322_2));
        let v322_4: Space = if has_head(&(v322_3)) { singleton(&[]) } else { Space::new() };
        drop(v322_3);
        let v322_5: Space = subtract(&(*CONSTANT_1),&(v322_4));
        drop(v322_4);
        let v322_8: Space = if (v322_5).is_empty() { Space::new() } else {
          let v323_6: Path = concat_path(&(v321_6),&(v321_7_head));
          let v323_7: Space = routine_44(c, &(v323_6), &(*p1), &(v321_7_tail), &(*s1));
          compose(&(v322_5),&(v323_7))
        };
        drop(v322_5);
        let v322_9: Space = intersect(&(*CONSTANT_2),&(v322_2));
        drop(v322_2);
        let v322_10: Space = if has_head(&(v322_9)) { singleton(&[]) } else { Space::new() };
        drop(v322_9);
        let v322_12: Space = if (v322_10).is_empty() { Space::new() } else {
          let v324_6: Path = concat_path(&(v321_6),&(v321_7_head));
          let v324_11: Space = routine_45(c, &(v324_6), &(*p1), &(v321_7_tail), &(*s1));
          drop(v324_6);
          compose(&(v322_10),&(v324_11))
        };
        drop(v322_10);
        let v322_13: Space = unite(&(v322_8),&(v322_12));
        v321_7.join_into((v322_13).clone());
      }
      drop(v321_7_cursor);
      compose(&(v320_5),&(v321_7))
    };
    drop(v320_5);
    let v320_9: Space = intersect(&(*CONSTANT_2),&(v320_2));
    drop(v320_2);
    let v320_10: Space = if has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
    drop(v320_9);
    let v320_12: Space = if (v320_10).is_empty() { Space::new() } else {
      let v325_6: Path = concat_path(&(*p0),&(v319_13_head));
      let mut v325_11 = Space::new();
      let mut v325_11_cursor = (v319_13_tail).read_zipper();
      for v325_11_byte in v325_11_cursor.child_mask().iter() {
        v325_11_cursor.descend_to_byte(v325_11_byte);
        let v325_11_tail = v325_11_cursor.make_map();
        v325_11_cursor.ascend(1);
        let v325_11_head = Path::from_slice(&[v325_11_byte]);
        let v326_2: Space = singleton(&(v325_11_head));
        let v326_3: Space = intersect(&(*CONSTANT_2),&(v326_2));
        let v326_4: Space = if has_head(&(v326_3)) { singleton(&[]) } else { Space::new() };
        drop(v326_3);
        let v326_5: Space = subtract(&(*CONSTANT_1),&(v326_4));
        drop(v326_4);
        let v326_8: Space = if (v326_5).is_empty() { Space::new() } else {
          let v327_6: Path = concat_path(&(v325_6),&(v325_11_head));
          let v327_7: Space = routine_44(c, &(v327_6), &(*p1), &(v325_11_tail), &(*s1));
          compose(&(v326_5),&(v327_7))
        };
        drop(v326_5);
        let v326_9: Space = intersect(&(*CONSTANT_2),&(v326_2));
        drop(v326_2);
        let v326_10: Space = if has_head(&(v326_9)) { singleton(&[]) } else { Space::new() };
        drop(v326_9);
        let v326_12: Space = if (v326_10).is_empty() { Space::new() } else {
          let v328_6: Path = concat_path(&(v325_6),&(v325_11_head));
          let v328_11: Space = routine_10(c, &(v328_6), &(*p1), &(v325_11_tail), &(*s1));
          drop(v328_6);
          compose(&(v326_10),&(v328_11))
        };
        drop(v326_10);
        let v326_13: Space = unite(&(v326_8),&(v326_12));
        v325_11.join_into((v326_13).clone());
      }
      drop(v325_11_cursor);
      drop(v325_6);
      compose(&(v320_10),&(v325_11))
    };
    drop(v320_10);
    let v320_13: Space = unite(&(v320_8),&(v320_12));
    v319_13.join_into((v320_13).clone());
  }
  drop(v319_13_cursor);
  (v319_13).clone()
}

fn routine_35(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v329_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v329_9: Space = unwrap(&(v329_8),&(*p0));
  drop(v329_8);
  let mut v329_16 = Space::new();
  let mut v329_16_cursor = (*s0).read_zipper();
  for v329_16_byte in v329_16_cursor.child_mask().iter() {
    v329_16_cursor.descend_to_byte(v329_16_byte);
    let v329_16_tail = v329_16_cursor.make_map();
    v329_16_cursor.ascend(1);
    let v329_16_head = Path::from_slice(&[v329_16_byte]);
    let v330_2: Space = singleton(&(v329_16_head));
    let v330_3: Space = intersect(&(*CONSTANT_2),&(v330_2));
    let v330_4: Space = if has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
    drop(v330_3);
    let v330_5: Space = subtract(&(*CONSTANT_1),&(v330_4));
    drop(v330_4);
    let v330_8: Space = if (v330_5).is_empty() { Space::new() } else {
      let v331_6: Path = concat_path(&(*p0),&(v329_16_head));
      let mut v331_7 = Space::new();
      let mut v331_7_cursor = (v329_16_tail).read_zipper();
      for v331_7_byte in v331_7_cursor.child_mask().iter() {
        v331_7_cursor.descend_to_byte(v331_7_byte);
        let v331_7_tail = v331_7_cursor.make_map();
        v331_7_cursor.ascend(1);
        let v331_7_head = Path::from_slice(&[v331_7_byte]);
        let v332_2: Space = singleton(&(v331_7_head));
        let v332_3: Space = intersect(&(*CONSTANT_2),&(v332_2));
        let v332_4: Space = if has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
        drop(v332_3);
        let v332_5: Space = subtract(&(*CONSTANT_1),&(v332_4));
        drop(v332_4);
        let v332_8: Space = if (v332_5).is_empty() { Space::new() } else {
          let v333_6: Path = concat_path(&(v331_6),&(v331_7_head));
          let v333_7: Space = routine_44(c, &(v333_6), &(*p1), &(v331_7_tail), &(*s1));
          compose(&(v332_5),&(v333_7))
        };
        drop(v332_5);
        let v332_9: Space = intersect(&(*CONSTANT_2),&(v332_2));
        drop(v332_2);
        let v332_10: Space = if has_head(&(v332_9)) { singleton(&[]) } else { Space::new() };
        drop(v332_9);
        let v332_12: Space = if (v332_10).is_empty() { Space::new() } else {
          let v334_6: Path = concat_path(&(v331_6),&(v331_7_head));
          let v334_11: Space = routine_45(c, &(v334_6), &(*p1), &(v331_7_tail), &(*s1));
          drop(v334_6);
          compose(&(v332_10),&(v334_11))
        };
        drop(v332_10);
        let v332_13: Space = unite(&(v332_8),&(v332_12));
        v331_7.join_into((v332_13).clone());
      }
      drop(v331_7_cursor);
      drop(v331_6);
      compose(&(v330_5),&(v331_7))
    };
    drop(v330_5);
    let v330_9: Space = intersect(&(*CONSTANT_2),&(v330_2));
    drop(v330_2);
    let v330_10: Space = if has_head(&(v330_9)) { singleton(&[]) } else { Space::new() };
    drop(v330_9);
    let v330_13: Space = if (v330_10).is_empty() { Space::new() } else {
      let v335_11: Space = unwrap(&(v329_9),&(v329_16_head));
      let mut v335_12 = Space::new();
      let mut v335_12_cursor = (v335_11).read_zipper();
      for v335_12_byte in v335_12_cursor.child_mask().iter() {
        v335_12_cursor.descend_to_byte(v335_12_byte);
        let v335_12_tail = v335_12_cursor.make_map();
        v335_12_cursor.ascend(1);
        let v335_12_head = Path::from_slice(&[v335_12_byte]);
        let v336_2: Space = singleton(&(v335_12_head));
        let v336_3: Space = intersect(&(*CONSTANT_2),&(v336_2));
        let v336_4: Space = if has_head(&(v336_3)) { singleton(&[]) } else { Space::new() };
        drop(v336_3);
        let v336_5: Space = subtract(&(*CONSTANT_1),&(v336_4));
        drop(v336_4);
        let v336_7: Space = if (v336_5).is_empty() { Space::new() } else {
          let v337_6: Space = routine_15(c, &(v335_12_head), &(*p1), &(v335_12_tail));
          compose(&(v336_5),&(v337_6))
        };
        drop(v336_5);
        let v336_8: Space = intersect(&(*CONSTANT_2),&(v336_2));
        drop(v336_2);
        let v336_9: Space = if has_head(&(v336_8)) { singleton(&[]) } else { Space::new() };
        drop(v336_8);
        let v336_11: Space = if (v336_9).is_empty() { Space::new() } else {
          let v338_10: Space = routine_16(c, &(v335_12_head), &(*p1), &(v335_12_tail));
          compose(&(v336_9),&(v338_10))
        };
        drop(v336_9);
        let v336_12: Space = unite(&(v336_7),&(v336_11));
        v335_12.join_into((v336_12).clone());
      }
      drop(v335_12_cursor);
      drop(v335_11);
      compose(&(v330_10),&(v335_12))
    };
    drop(v330_10);
    let v330_14: Space = unite(&(v330_8),&(v330_13));
    v329_16.join_into((v330_14).clone());
  }
  drop(v329_16_cursor);
  drop(v329_9);
  (v329_16).clone()
}

fn routine_36(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v339_12 = Space::new();
  let mut v339_12_cursor = (*s0).read_zipper();
  for v339_12_byte in v339_12_cursor.child_mask().iter() {
    v339_12_cursor.descend_to_byte(v339_12_byte);
    let v339_12_tail = v339_12_cursor.make_map();
    v339_12_cursor.ascend(1);
    let v339_12_head = Path::from_slice(&[v339_12_byte]);
    let v340_2: Space = singleton(&(v339_12_head));
    let v340_3: Space = intersect(&(*CONSTANT_2),&(v340_2));
    let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
    drop(v340_3);
    let v340_5: Space = subtract(&(*CONSTANT_1),&(v340_4));
    drop(v340_4);
    let v340_8: Space = if (v340_5).is_empty() { Space::new() } else {
      let v341_6: Path = concat_path(&(*p0),&(v339_12_head));
      let mut v341_7 = Space::new();
      let mut v341_7_cursor = (v339_12_tail).read_zipper();
      for v341_7_byte in v341_7_cursor.child_mask().iter() {
        v341_7_cursor.descend_to_byte(v341_7_byte);
        let v341_7_tail = v341_7_cursor.make_map();
        v341_7_cursor.ascend(1);
        let v341_7_head = Path::from_slice(&[v341_7_byte]);
        let v342_2: Space = singleton(&(v341_7_head));
        let v342_3: Space = intersect(&(*CONSTANT_2),&(v342_2));
        let v342_4: Space = if has_head(&(v342_3)) { singleton(&[]) } else { Space::new() };
        drop(v342_3);
        let v342_5: Space = subtract(&(*CONSTANT_1),&(v342_4));
        drop(v342_4);
        let v342_8: Space = if (v342_5).is_empty() { Space::new() } else {
          let v343_6: Path = concat_path(&(v341_6),&(v341_7_head));
          let v343_7: Space = routine_46(c, &(v343_6), &(*p1), &(v341_7_tail));
          compose(&(v342_5),&(v343_7))
        };
        drop(v342_5);
        let v342_9: Space = intersect(&(*CONSTANT_2),&(v342_2));
        drop(v342_2);
        let v342_10: Space = if has_head(&(v342_9)) { singleton(&[]) } else { Space::new() };
        drop(v342_9);
        let v342_12: Space = if (v342_10).is_empty() { Space::new() } else {
          let v344_6: Path = concat_path(&(v341_6),&(v341_7_head));
          let v344_11: Space = routine_47(c, &(v344_6), &(*p1), &(v341_7_tail));
          drop(v344_6);
          compose(&(v342_10),&(v344_11))
        };
        drop(v342_10);
        let v342_13: Space = unite(&(v342_8),&(v342_12));
        v341_7.join_into((v342_13).clone());
      }
      drop(v341_7_cursor);
      compose(&(v340_5),&(v341_7))
    };
    drop(v340_5);
    let v340_9: Space = intersect(&(*CONSTANT_2),&(v340_2));
    drop(v340_2);
    let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
    drop(v340_9);
    let v340_12: Space = if (v340_10).is_empty() { Space::new() } else {
      let v345_6: Path = concat_path(&(*p0),&(v339_12_head));
      let mut v345_11 = Space::new();
      let mut v345_11_cursor = (v339_12_tail).read_zipper();
      for v345_11_byte in v345_11_cursor.child_mask().iter() {
        v345_11_cursor.descend_to_byte(v345_11_byte);
        let v345_11_tail = v345_11_cursor.make_map();
        v345_11_cursor.ascend(1);
        let v345_11_head = Path::from_slice(&[v345_11_byte]);
        let v346_2: Space = singleton(&(v345_11_head));
        let v346_3: Space = intersect(&(*CONSTANT_2),&(v346_2));
        let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
        drop(v346_3);
        let v346_5: Space = subtract(&(*CONSTANT_1),&(v346_4));
        drop(v346_4);
        let v346_8: Space = if (v346_5).is_empty() { Space::new() } else {
          let v347_6: Path = concat_path(&(v345_6),&(v345_11_head));
          let v347_7: Space = routine_46(c, &(v347_6), &(*p1), &(v345_11_tail));
          compose(&(v346_5),&(v347_7))
        };
        drop(v346_5);
        let v346_9: Space = intersect(&(*CONSTANT_2),&(v346_2));
        drop(v346_2);
        let v346_10: Space = if has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
        drop(v346_9);
        let v346_12: Space = if (v346_10).is_empty() { Space::new() } else {
          let v348_6: Path = concat_path(&(v345_6),&(v345_11_head));
          let v348_11: Space = routine_21(c, &(v348_6), &(*p1), &(v345_11_tail));
          drop(v348_6);
          compose(&(v346_10),&(v348_11))
        };
        drop(v346_10);
        let v346_13: Space = unite(&(v346_8),&(v346_12));
        v345_11.join_into((v346_13).clone());
      }
      drop(v345_11_cursor);
      drop(v345_6);
      compose(&(v340_10),&(v345_11))
    };
    drop(v340_10);
    let v340_13: Space = unite(&(v340_8),&(v340_12));
    v339_12.join_into((v340_13).clone());
  }
  drop(v339_12_cursor);
  (v339_12).clone()
}

fn routine_37(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v349_9 = Space::new();
  let mut v349_9_cursor = (*s0).read_zipper();
  for v349_9_byte in v349_9_cursor.child_mask().iter() {
    v349_9_cursor.descend_to_byte(v349_9_byte);
    let v349_9_tail = v349_9_cursor.make_map();
    v349_9_cursor.ascend(1);
    let v349_9_head = Path::from_slice(&[v349_9_byte]);
    let v350_2: Space = singleton(&(v349_9_head));
    let v350_3: Space = intersect(&(*CONSTANT_2),&(v350_2));
    let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
    drop(v350_3);
    let v350_5: Space = subtract(&(*CONSTANT_1),&(v350_4));
    drop(v350_4);
    let v350_8: Space = if (v350_5).is_empty() { Space::new() } else {
      let v351_6: Path = concat_path(&(*p0),&(v349_9_head));
      let mut v351_7 = Space::new();
      let mut v351_7_cursor = (v349_9_tail).read_zipper();
      for v351_7_byte in v351_7_cursor.child_mask().iter() {
        v351_7_cursor.descend_to_byte(v351_7_byte);
        let v351_7_tail = v351_7_cursor.make_map();
        v351_7_cursor.ascend(1);
        let v351_7_head = Path::from_slice(&[v351_7_byte]);
        let v352_2: Space = singleton(&(v351_7_head));
        let v352_3: Space = intersect(&(*CONSTANT_2),&(v352_2));
        let v352_4: Space = if has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
        drop(v352_3);
        let v352_5: Space = subtract(&(*CONSTANT_1),&(v352_4));
        drop(v352_4);
        let v352_8: Space = if (v352_5).is_empty() { Space::new() } else {
          let v353_6: Path = concat_path(&(v351_6),&(v351_7_head));
          let v353_7: Space = routine_46(c, &(v353_6), &(*p1), &(v351_7_tail));
          compose(&(v352_5),&(v353_7))
        };
        drop(v352_5);
        let v352_9: Space = intersect(&(*CONSTANT_2),&(v352_2));
        drop(v352_2);
        let v352_10: Space = if has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
        drop(v352_9);
        let v352_12: Space = if (v352_10).is_empty() { Space::new() } else {
          let v354_6: Path = concat_path(&(v351_6),&(v351_7_head));
          let v354_11: Space = routine_47(c, &(v354_6), &(*p1), &(v351_7_tail));
          drop(v354_6);
          compose(&(v352_10),&(v354_11))
        };
        drop(v352_10);
        let v352_13: Space = unite(&(v352_8),&(v352_12));
        v351_7.join_into((v352_13).clone());
      }
      drop(v351_7_cursor);
      compose(&(v350_5),&(v351_7))
    };
    drop(v350_5);
    let v350_9: Space = intersect(&(*CONSTANT_2),&(v350_2));
    drop(v350_2);
    let v350_10: Space = if has_head(&(v350_9)) { singleton(&[]) } else { Space::new() };
    drop(v350_9);
    let v350_11: Space = compose(&(v350_10),&(v349_9_tail));
    drop(v350_10);
    let v355_6: Path = concat_path(&(*p0),&(v349_9_head));
    let v350_12: Space = wrap(&(v350_11),&(v355_6));
    drop(v350_11);
    let v350_13: Space = wrap(&(v350_12),&(*p1));
    drop(v350_12);
    let v350_14: Space = unite(&(v350_8),&(v350_13));
    drop(v350_13);
    v349_9.join_into((v350_14).clone());
  }
  drop(v349_9_cursor);
  (v349_9).clone()
}

fn routine_38(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v356_13 = Space::new();
  let mut v356_13_cursor = (*s0).read_zipper();
  for v356_13_byte in v356_13_cursor.child_mask().iter() {
    v356_13_cursor.descend_to_byte(v356_13_byte);
    let v356_13_tail = v356_13_cursor.make_map();
    v356_13_cursor.ascend(1);
    let v356_13_head = Path::from_slice(&[v356_13_byte]);
    let v357_2: Space = singleton(&(v356_13_head));
    let v357_3: Space = intersect(&(*CONSTANT_2),&(v357_2));
    let v357_4: Space = if has_head(&(v357_3)) { singleton(&[]) } else { Space::new() };
    drop(v357_3);
    let v357_5: Space = subtract(&(*CONSTANT_1),&(v357_4));
    drop(v357_4);
    let v357_8: Space = if (v357_5).is_empty() { Space::new() } else {
      let v358_6: Path = concat_path(&(*p0),&(v356_13_head));
      let mut v358_7 = Space::new();
      let mut v358_7_cursor = (v356_13_tail).read_zipper();
      for v358_7_byte in v358_7_cursor.child_mask().iter() {
        v358_7_cursor.descend_to_byte(v358_7_byte);
        let v358_7_tail = v358_7_cursor.make_map();
        v358_7_cursor.ascend(1);
        let v358_7_head = Path::from_slice(&[v358_7_byte]);
        let v359_2: Space = singleton(&(v358_7_head));
        let v359_3: Space = intersect(&(*CONSTANT_2),&(v359_2));
        let v359_4: Space = if has_head(&(v359_3)) { singleton(&[]) } else { Space::new() };
        drop(v359_3);
        let v359_5: Space = subtract(&(*CONSTANT_1),&(v359_4));
        drop(v359_4);
        let v359_8: Space = if (v359_5).is_empty() { Space::new() } else {
          let v360_6: Path = concat_path(&(v358_6),&(v358_7_head));
          let v360_7: Space = routine_48(c, &(v360_6), &(*p1), &(v358_7_tail), &(*s1));
          compose(&(v359_5),&(v360_7))
        };
        drop(v359_5);
        let v359_9: Space = intersect(&(*CONSTANT_2),&(v359_2));
        drop(v359_2);
        let v359_10: Space = if has_head(&(v359_9)) { singleton(&[]) } else { Space::new() };
        drop(v359_9);
        let v359_12: Space = if (v359_10).is_empty() { Space::new() } else {
          let v361_6: Path = concat_path(&(v358_6),&(v358_7_head));
          let v361_11: Space = routine_49(c, &(v361_6), &(*p1), &(v358_7_tail), &(*s1));
          drop(v361_6);
          compose(&(v359_10),&(v361_11))
        };
        drop(v359_10);
        let v359_13: Space = unite(&(v359_8),&(v359_12));
        v358_7.join_into((v359_13).clone());
      }
      drop(v358_7_cursor);
      compose(&(v357_5),&(v358_7))
    };
    drop(v357_5);
    let v357_9: Space = intersect(&(*CONSTANT_2),&(v357_2));
    drop(v357_2);
    let v357_10: Space = if has_head(&(v357_9)) { singleton(&[]) } else { Space::new() };
    drop(v357_9);
    let v357_12: Space = if (v357_10).is_empty() { Space::new() } else {
      let v362_6: Path = concat_path(&(*p0),&(v356_13_head));
      let mut v362_11 = Space::new();
      let mut v362_11_cursor = (v356_13_tail).read_zipper();
      for v362_11_byte in v362_11_cursor.child_mask().iter() {
        v362_11_cursor.descend_to_byte(v362_11_byte);
        let v362_11_tail = v362_11_cursor.make_map();
        v362_11_cursor.ascend(1);
        let v362_11_head = Path::from_slice(&[v362_11_byte]);
        let v363_2: Space = singleton(&(v362_11_head));
        let v363_3: Space = intersect(&(*CONSTANT_2),&(v363_2));
        let v363_4: Space = if has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
        drop(v363_3);
        let v363_5: Space = subtract(&(*CONSTANT_1),&(v363_4));
        drop(v363_4);
        let v363_8: Space = if (v363_5).is_empty() { Space::new() } else {
          let v364_6: Path = concat_path(&(v362_6),&(v362_11_head));
          let v364_7: Space = routine_48(c, &(v364_6), &(*p1), &(v362_11_tail), &(*s1));
          compose(&(v363_5),&(v364_7))
        };
        drop(v363_5);
        let v363_9: Space = intersect(&(*CONSTANT_2),&(v363_2));
        drop(v363_2);
        let v363_10: Space = if has_head(&(v363_9)) { singleton(&[]) } else { Space::new() };
        drop(v363_9);
        let v363_12: Space = if (v363_10).is_empty() { Space::new() } else {
          let v365_6: Path = concat_path(&(v362_6),&(v362_11_head));
          let v365_11: Space = routine_10(c, &(v365_6), &(*p1), &(v362_11_tail), &(*s1));
          drop(v365_6);
          compose(&(v363_10),&(v365_11))
        };
        drop(v363_10);
        let v363_13: Space = unite(&(v363_8),&(v363_12));
        v362_11.join_into((v363_13).clone());
      }
      drop(v362_11_cursor);
      drop(v362_6);
      compose(&(v357_10),&(v362_11))
    };
    drop(v357_10);
    let v357_13: Space = unite(&(v357_8),&(v357_12));
    v356_13.join_into((v357_13).clone());
  }
  drop(v356_13_cursor);
  (v356_13).clone()
}

fn routine_39(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v366_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v366_9: Space = unwrap(&(v366_8),&(*p0));
  drop(v366_8);
  let mut v366_16 = Space::new();
  let mut v366_16_cursor = (*s0).read_zipper();
  for v366_16_byte in v366_16_cursor.child_mask().iter() {
    v366_16_cursor.descend_to_byte(v366_16_byte);
    let v366_16_tail = v366_16_cursor.make_map();
    v366_16_cursor.ascend(1);
    let v366_16_head = Path::from_slice(&[v366_16_byte]);
    let v367_2: Space = singleton(&(v366_16_head));
    let v367_3: Space = intersect(&(*CONSTANT_2),&(v367_2));
    let v367_4: Space = if has_head(&(v367_3)) { singleton(&[]) } else { Space::new() };
    drop(v367_3);
    let v367_5: Space = subtract(&(*CONSTANT_1),&(v367_4));
    drop(v367_4);
    let v367_8: Space = if (v367_5).is_empty() { Space::new() } else {
      let v368_6: Path = concat_path(&(*p0),&(v366_16_head));
      let mut v368_7 = Space::new();
      let mut v368_7_cursor = (v366_16_tail).read_zipper();
      for v368_7_byte in v368_7_cursor.child_mask().iter() {
        v368_7_cursor.descend_to_byte(v368_7_byte);
        let v368_7_tail = v368_7_cursor.make_map();
        v368_7_cursor.ascend(1);
        let v368_7_head = Path::from_slice(&[v368_7_byte]);
        let v369_2: Space = singleton(&(v368_7_head));
        let v369_3: Space = intersect(&(*CONSTANT_2),&(v369_2));
        let v369_4: Space = if has_head(&(v369_3)) { singleton(&[]) } else { Space::new() };
        drop(v369_3);
        let v369_5: Space = subtract(&(*CONSTANT_1),&(v369_4));
        drop(v369_4);
        let v369_8: Space = if (v369_5).is_empty() { Space::new() } else {
          let v370_6: Path = concat_path(&(v368_6),&(v368_7_head));
          let v370_7: Space = routine_48(c, &(v370_6), &(*p1), &(v368_7_tail), &(*s1));
          compose(&(v369_5),&(v370_7))
        };
        drop(v369_5);
        let v369_9: Space = intersect(&(*CONSTANT_2),&(v369_2));
        drop(v369_2);
        let v369_10: Space = if has_head(&(v369_9)) { singleton(&[]) } else { Space::new() };
        drop(v369_9);
        let v369_12: Space = if (v369_10).is_empty() { Space::new() } else {
          let v371_6: Path = concat_path(&(v368_6),&(v368_7_head));
          let v371_11: Space = routine_49(c, &(v371_6), &(*p1), &(v368_7_tail), &(*s1));
          drop(v371_6);
          compose(&(v369_10),&(v371_11))
        };
        drop(v369_10);
        let v369_13: Space = unite(&(v369_8),&(v369_12));
        v368_7.join_into((v369_13).clone());
      }
      drop(v368_7_cursor);
      drop(v368_6);
      compose(&(v367_5),&(v368_7))
    };
    drop(v367_5);
    let v367_9: Space = intersect(&(*CONSTANT_2),&(v367_2));
    drop(v367_2);
    let v367_10: Space = if has_head(&(v367_9)) { singleton(&[]) } else { Space::new() };
    drop(v367_9);
    let v367_13: Space = if (v367_10).is_empty() { Space::new() } else {
      let v372_11: Space = unwrap(&(v366_9),&(v366_16_head));
      let mut v372_12 = Space::new();
      let mut v372_12_cursor = (v372_11).read_zipper();
      for v372_12_byte in v372_12_cursor.child_mask().iter() {
        v372_12_cursor.descend_to_byte(v372_12_byte);
        let v372_12_tail = v372_12_cursor.make_map();
        v372_12_cursor.ascend(1);
        let v372_12_head = Path::from_slice(&[v372_12_byte]);
        let v373_2: Space = singleton(&(v372_12_head));
        let v373_3: Space = intersect(&(*CONSTANT_2),&(v373_2));
        let v373_4: Space = if has_head(&(v373_3)) { singleton(&[]) } else { Space::new() };
        drop(v373_3);
        let v373_5: Space = subtract(&(*CONSTANT_1),&(v373_4));
        drop(v373_4);
        let v373_7: Space = if (v373_5).is_empty() { Space::new() } else {
          let v374_6: Space = routine_15(c, &(v372_12_head), &(*p1), &(v372_12_tail));
          compose(&(v373_5),&(v374_6))
        };
        drop(v373_5);
        let v373_8: Space = intersect(&(*CONSTANT_2),&(v373_2));
        drop(v373_2);
        let v373_9: Space = if has_head(&(v373_8)) { singleton(&[]) } else { Space::new() };
        drop(v373_8);
        let v373_11: Space = if (v373_9).is_empty() { Space::new() } else {
          let v375_10: Space = routine_16(c, &(v372_12_head), &(*p1), &(v372_12_tail));
          compose(&(v373_9),&(v375_10))
        };
        drop(v373_9);
        let v373_12: Space = unite(&(v373_7),&(v373_11));
        v372_12.join_into((v373_12).clone());
      }
      drop(v372_12_cursor);
      drop(v372_11);
      compose(&(v367_10),&(v372_12))
    };
    drop(v367_10);
    let v367_14: Space = unite(&(v367_8),&(v367_13));
    v366_16.join_into((v367_14).clone());
  }
  drop(v366_16_cursor);
  drop(v366_9);
  (v366_16).clone()
}

fn routine_40(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v376_12 = Space::new();
  let mut v376_12_cursor = (*s0).read_zipper();
  for v376_12_byte in v376_12_cursor.child_mask().iter() {
    v376_12_cursor.descend_to_byte(v376_12_byte);
    let v376_12_tail = v376_12_cursor.make_map();
    v376_12_cursor.ascend(1);
    let v376_12_head = Path::from_slice(&[v376_12_byte]);
    let v377_2: Space = singleton(&(v376_12_head));
    let v377_3: Space = intersect(&(*CONSTANT_2),&(v377_2));
    let v377_4: Space = if has_head(&(v377_3)) { singleton(&[]) } else { Space::new() };
    drop(v377_3);
    let v377_5: Space = subtract(&(*CONSTANT_1),&(v377_4));
    drop(v377_4);
    let v377_8: Space = if (v377_5).is_empty() { Space::new() } else {
      let v378_6: Path = concat_path(&(*p0),&(v376_12_head));
      let mut v378_7 = Space::new();
      let mut v378_7_cursor = (v376_12_tail).read_zipper();
      for v378_7_byte in v378_7_cursor.child_mask().iter() {
        v378_7_cursor.descend_to_byte(v378_7_byte);
        let v378_7_tail = v378_7_cursor.make_map();
        v378_7_cursor.ascend(1);
        let v378_7_head = Path::from_slice(&[v378_7_byte]);
        let v379_2: Space = singleton(&(v378_7_head));
        let v379_3: Space = intersect(&(*CONSTANT_2),&(v379_2));
        let v379_4: Space = if has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
        drop(v379_3);
        let v379_5: Space = subtract(&(*CONSTANT_1),&(v379_4));
        drop(v379_4);
        let v379_8: Space = if (v379_5).is_empty() { Space::new() } else {
          let v380_6: Path = concat_path(&(v378_6),&(v378_7_head));
          let v380_7: Space = routine_50(c, &(v380_6), &(*p1), &(v378_7_tail));
          compose(&(v379_5),&(v380_7))
        };
        drop(v379_5);
        let v379_9: Space = intersect(&(*CONSTANT_2),&(v379_2));
        drop(v379_2);
        let v379_10: Space = if has_head(&(v379_9)) { singleton(&[]) } else { Space::new() };
        drop(v379_9);
        let v379_12: Space = if (v379_10).is_empty() { Space::new() } else {
          let v381_6: Path = concat_path(&(v378_6),&(v378_7_head));
          let v381_11: Space = routine_51(c, &(v381_6), &(*p1), &(v378_7_tail));
          drop(v381_6);
          compose(&(v379_10),&(v381_11))
        };
        drop(v379_10);
        let v379_13: Space = unite(&(v379_8),&(v379_12));
        v378_7.join_into((v379_13).clone());
      }
      drop(v378_7_cursor);
      compose(&(v377_5),&(v378_7))
    };
    drop(v377_5);
    let v377_9: Space = intersect(&(*CONSTANT_2),&(v377_2));
    drop(v377_2);
    let v377_10: Space = if has_head(&(v377_9)) { singleton(&[]) } else { Space::new() };
    drop(v377_9);
    let v377_12: Space = if (v377_10).is_empty() { Space::new() } else {
      let v382_6: Path = concat_path(&(*p0),&(v376_12_head));
      let mut v382_11 = Space::new();
      let mut v382_11_cursor = (v376_12_tail).read_zipper();
      for v382_11_byte in v382_11_cursor.child_mask().iter() {
        v382_11_cursor.descend_to_byte(v382_11_byte);
        let v382_11_tail = v382_11_cursor.make_map();
        v382_11_cursor.ascend(1);
        let v382_11_head = Path::from_slice(&[v382_11_byte]);
        let v383_2: Space = singleton(&(v382_11_head));
        let v383_3: Space = intersect(&(*CONSTANT_2),&(v383_2));
        let v383_4: Space = if has_head(&(v383_3)) { singleton(&[]) } else { Space::new() };
        drop(v383_3);
        let v383_5: Space = subtract(&(*CONSTANT_1),&(v383_4));
        drop(v383_4);
        let v383_8: Space = if (v383_5).is_empty() { Space::new() } else {
          let v384_6: Path = concat_path(&(v382_6),&(v382_11_head));
          let v384_7: Space = routine_50(c, &(v384_6), &(*p1), &(v382_11_tail));
          compose(&(v383_5),&(v384_7))
        };
        drop(v383_5);
        let v383_9: Space = intersect(&(*CONSTANT_2),&(v383_2));
        drop(v383_2);
        let v383_10: Space = if has_head(&(v383_9)) { singleton(&[]) } else { Space::new() };
        drop(v383_9);
        let v383_12: Space = if (v383_10).is_empty() { Space::new() } else {
          let v385_6: Path = concat_path(&(v382_6),&(v382_11_head));
          let v385_11: Space = routine_21(c, &(v385_6), &(*p1), &(v382_11_tail));
          drop(v385_6);
          compose(&(v383_10),&(v385_11))
        };
        drop(v383_10);
        let v383_13: Space = unite(&(v383_8),&(v383_12));
        v382_11.join_into((v383_13).clone());
      }
      drop(v382_11_cursor);
      drop(v382_6);
      compose(&(v377_10),&(v382_11))
    };
    drop(v377_10);
    let v377_13: Space = unite(&(v377_8),&(v377_12));
    v376_12.join_into((v377_13).clone());
  }
  drop(v376_12_cursor);
  (v376_12).clone()
}

fn routine_41(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v386_9 = Space::new();
  let mut v386_9_cursor = (*s0).read_zipper();
  for v386_9_byte in v386_9_cursor.child_mask().iter() {
    v386_9_cursor.descend_to_byte(v386_9_byte);
    let v386_9_tail = v386_9_cursor.make_map();
    v386_9_cursor.ascend(1);
    let v386_9_head = Path::from_slice(&[v386_9_byte]);
    let v387_2: Space = singleton(&(v386_9_head));
    let v387_3: Space = intersect(&(*CONSTANT_2),&(v387_2));
    let v387_4: Space = if has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
    drop(v387_3);
    let v387_5: Space = subtract(&(*CONSTANT_1),&(v387_4));
    drop(v387_4);
    let v387_8: Space = if (v387_5).is_empty() { Space::new() } else {
      let v388_6: Path = concat_path(&(*p0),&(v386_9_head));
      let mut v388_7 = Space::new();
      let mut v388_7_cursor = (v386_9_tail).read_zipper();
      for v388_7_byte in v388_7_cursor.child_mask().iter() {
        v388_7_cursor.descend_to_byte(v388_7_byte);
        let v388_7_tail = v388_7_cursor.make_map();
        v388_7_cursor.ascend(1);
        let v388_7_head = Path::from_slice(&[v388_7_byte]);
        let v389_2: Space = singleton(&(v388_7_head));
        let v389_3: Space = intersect(&(*CONSTANT_2),&(v389_2));
        let v389_4: Space = if has_head(&(v389_3)) { singleton(&[]) } else { Space::new() };
        drop(v389_3);
        let v389_5: Space = subtract(&(*CONSTANT_1),&(v389_4));
        drop(v389_4);
        let v389_8: Space = if (v389_5).is_empty() { Space::new() } else {
          let v390_6: Path = concat_path(&(v388_6),&(v388_7_head));
          let v390_7: Space = routine_50(c, &(v390_6), &(*p1), &(v388_7_tail));
          compose(&(v389_5),&(v390_7))
        };
        drop(v389_5);
        let v389_9: Space = intersect(&(*CONSTANT_2),&(v389_2));
        drop(v389_2);
        let v389_10: Space = if has_head(&(v389_9)) { singleton(&[]) } else { Space::new() };
        drop(v389_9);
        let v389_12: Space = if (v389_10).is_empty() { Space::new() } else {
          let v391_6: Path = concat_path(&(v388_6),&(v388_7_head));
          let v391_11: Space = routine_51(c, &(v391_6), &(*p1), &(v388_7_tail));
          drop(v391_6);
          compose(&(v389_10),&(v391_11))
        };
        drop(v389_10);
        let v389_13: Space = unite(&(v389_8),&(v389_12));
        v388_7.join_into((v389_13).clone());
      }
      drop(v388_7_cursor);
      compose(&(v387_5),&(v388_7))
    };
    drop(v387_5);
    let v387_9: Space = intersect(&(*CONSTANT_2),&(v387_2));
    drop(v387_2);
    let v387_10: Space = if has_head(&(v387_9)) { singleton(&[]) } else { Space::new() };
    drop(v387_9);
    let v387_11: Space = compose(&(v387_10),&(v386_9_tail));
    drop(v387_10);
    let v392_6: Path = concat_path(&(*p0),&(v386_9_head));
    let v387_12: Space = wrap(&(v387_11),&(v392_6));
    drop(v387_11);
    let v387_13: Space = wrap(&(v387_12),&(*p1));
    drop(v387_12);
    let v387_14: Space = unite(&(v387_8),&(v387_13));
    drop(v387_13);
    v386_9.join_into((v387_14).clone());
  }
  drop(v386_9_cursor);
  (v386_9).clone()
}

fn routine_42(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v393_3 = Space::new();
  let mut v393_3_cursor = (*s0).read_zipper();
  for v393_3_byte in v393_3_cursor.child_mask().iter() {
    v393_3_cursor.descend_to_byte(v393_3_byte);
    let v393_3_tail = v393_3_cursor.make_map();
    v393_3_cursor.ascend(1);
    let v393_3_head = Path::from_slice(&[v393_3_byte]);
    let v394_2: Space = Space::new();
    v393_3.join_into((v394_2).clone());
  }
  drop(v393_3_cursor);
  (v393_3).clone()
}

fn routine_43(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v395_7 = Space::new();
  let mut v395_7_cursor = (*s0).read_zipper();
  for v395_7_byte in v395_7_cursor.child_mask().iter() {
    v395_7_cursor.descend_to_byte(v395_7_byte);
    let v395_7_tail = v395_7_cursor.make_map();
    v395_7_cursor.ascend(1);
    let v395_7_head = Path::from_slice(&[v395_7_byte]);
    let v396_2: Space = singleton(&(v395_7_head));
    let v396_3: Space = intersect(&(*CONSTANT_2),&(v396_2));
    drop(v396_2);
    let v396_4: Space = if has_head(&(v396_3)) { singleton(&[]) } else { Space::new() };
    drop(v396_3);
    let v396_7: Space = if (v396_4).is_empty() { Space::new() } else {
      let v397_5: Path = concat_path(&(*p0),&(v395_7_head));
      let mut v397_6 = Space::new();
      let mut v397_6_cursor = (v395_7_tail).read_zipper();
      for v397_6_byte in v397_6_cursor.child_mask().iter() {
        v397_6_cursor.descend_to_byte(v397_6_byte);
        let v397_6_tail = v397_6_cursor.make_map();
        v397_6_cursor.ascend(1);
        let v397_6_head = Path::from_slice(&[v397_6_byte]);
        let v398_2: Space = singleton(&(v397_6_head));
        let v398_3: Space = intersect(&(*CONSTANT_2),&(v398_2));
        let v398_4: Space = if has_head(&(v398_3)) { singleton(&[]) } else { Space::new() };
        drop(v398_3);
        let v398_5: Space = subtract(&(*CONSTANT_1),&(v398_4));
        drop(v398_4);
        let v398_7: Space = if (v398_5).is_empty() { Space::new() } else {
          let v399_6: Space = routine_6(c, &(v397_6_head), &(v397_5), &(v397_6_tail), &(*s1));
          compose(&(v398_5),&(v399_6))
        };
        drop(v398_5);
        let v398_8: Space = intersect(&(*CONSTANT_2),&(v398_2));
        drop(v398_2);
        let v398_9: Space = if has_head(&(v398_8)) { singleton(&[]) } else { Space::new() };
        drop(v398_8);
        let v398_11: Space = if (v398_9).is_empty() { Space::new() } else {
          let v400_10: Space = routine_7(c, &(v397_6_head), &(v397_5), &(v397_6_tail), &(*s1));
          compose(&(v398_9),&(v400_10))
        };
        drop(v398_9);
        let v398_12: Space = unite(&(v398_7),&(v398_11));
        v397_6.join_into((v398_12).clone());
      }
      drop(v397_6_cursor);
      drop(v397_5);
      compose(&(v396_4),&(v397_6))
    };
    drop(v396_4);
    v395_7.join_into((v396_7).clone());
  }
  drop(v395_7_cursor);
  (v395_7).clone()
}

fn routine_44(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v401_13 = Space::new();
  let mut v401_13_cursor = (*s0).read_zipper();
  for v401_13_byte in v401_13_cursor.child_mask().iter() {
    v401_13_cursor.descend_to_byte(v401_13_byte);
    let v401_13_tail = v401_13_cursor.make_map();
    v401_13_cursor.ascend(1);
    let v401_13_head = Path::from_slice(&[v401_13_byte]);
    let v402_2: Space = singleton(&(v401_13_head));
    let v402_3: Space = intersect(&(*CONSTANT_2),&(v402_2));
    let v402_4: Space = if has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
    drop(v402_3);
    let v402_5: Space = subtract(&(*CONSTANT_1),&(v402_4));
    drop(v402_4);
    let v402_8: Space = if (v402_5).is_empty() { Space::new() } else {
      let v403_6: Path = concat_path(&(*p0),&(v401_13_head));
      let mut v403_7 = Space::new();
      let mut v403_7_cursor = (v401_13_tail).read_zipper();
      for v403_7_byte in v403_7_cursor.child_mask().iter() {
        v403_7_cursor.descend_to_byte(v403_7_byte);
        let v403_7_tail = v403_7_cursor.make_map();
        v403_7_cursor.ascend(1);
        let v403_7_head = Path::from_slice(&[v403_7_byte]);
        let v404_2: Space = singleton(&(v403_7_head));
        let v404_3: Space = intersect(&(*CONSTANT_2),&(v404_2));
        let v404_4: Space = if has_head(&(v404_3)) { singleton(&[]) } else { Space::new() };
        drop(v404_3);
        let v404_5: Space = subtract(&(*CONSTANT_1),&(v404_4));
        drop(v404_4);
        let v404_8: Space = if (v404_5).is_empty() { Space::new() } else {
          let v405_6: Path = concat_path(&(v403_6),&(v403_7_head));
          let v405_7: Space = routine_52(c, &(v405_6), &(*p1), &(v403_7_tail), &(*s1));
          compose(&(v404_5),&(v405_7))
        };
        drop(v404_5);
        let v404_9: Space = intersect(&(*CONSTANT_2),&(v404_2));
        drop(v404_2);
        let v404_10: Space = if has_head(&(v404_9)) { singleton(&[]) } else { Space::new() };
        drop(v404_9);
        let v404_12: Space = if (v404_10).is_empty() { Space::new() } else {
          let v406_6: Path = concat_path(&(v403_6),&(v403_7_head));
          let v406_11: Space = routine_53(c, &(v406_6), &(*p1), &(v403_7_tail), &(*s1));
          drop(v406_6);
          compose(&(v404_10),&(v406_11))
        };
        drop(v404_10);
        let v404_13: Space = unite(&(v404_8),&(v404_12));
        v403_7.join_into((v404_13).clone());
      }
      drop(v403_7_cursor);
      compose(&(v402_5),&(v403_7))
    };
    drop(v402_5);
    let v402_9: Space = intersect(&(*CONSTANT_2),&(v402_2));
    drop(v402_2);
    let v402_10: Space = if has_head(&(v402_9)) { singleton(&[]) } else { Space::new() };
    drop(v402_9);
    let v402_12: Space = if (v402_10).is_empty() { Space::new() } else {
      let v407_6: Path = concat_path(&(*p0),&(v401_13_head));
      let mut v407_11 = Space::new();
      let mut v407_11_cursor = (v401_13_tail).read_zipper();
      for v407_11_byte in v407_11_cursor.child_mask().iter() {
        v407_11_cursor.descend_to_byte(v407_11_byte);
        let v407_11_tail = v407_11_cursor.make_map();
        v407_11_cursor.ascend(1);
        let v407_11_head = Path::from_slice(&[v407_11_byte]);
        let v408_2: Space = singleton(&(v407_11_head));
        let v408_3: Space = intersect(&(*CONSTANT_2),&(v408_2));
        let v408_4: Space = if has_head(&(v408_3)) { singleton(&[]) } else { Space::new() };
        drop(v408_3);
        let v408_5: Space = subtract(&(*CONSTANT_1),&(v408_4));
        drop(v408_4);
        let v408_8: Space = if (v408_5).is_empty() { Space::new() } else {
          let v409_6: Path = concat_path(&(v407_6),&(v407_11_head));
          let v409_7: Space = routine_52(c, &(v409_6), &(*p1), &(v407_11_tail), &(*s1));
          compose(&(v408_5),&(v409_7))
        };
        drop(v408_5);
        let v408_9: Space = intersect(&(*CONSTANT_2),&(v408_2));
        drop(v408_2);
        let v408_10: Space = if has_head(&(v408_9)) { singleton(&[]) } else { Space::new() };
        drop(v408_9);
        let v408_12: Space = if (v408_10).is_empty() { Space::new() } else {
          let v410_6: Path = concat_path(&(v407_6),&(v407_11_head));
          let v410_11: Space = routine_10(c, &(v410_6), &(*p1), &(v407_11_tail), &(*s1));
          drop(v410_6);
          compose(&(v408_10),&(v410_11))
        };
        drop(v408_10);
        let v408_13: Space = unite(&(v408_8),&(v408_12));
        v407_11.join_into((v408_13).clone());
      }
      drop(v407_11_cursor);
      drop(v407_6);
      compose(&(v402_10),&(v407_11))
    };
    drop(v402_10);
    let v402_13: Space = unite(&(v402_8),&(v402_12));
    v401_13.join_into((v402_13).clone());
  }
  drop(v401_13_cursor);
  (v401_13).clone()
}

fn routine_45(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v411_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v411_9: Space = unwrap(&(v411_8),&(*p0));
  drop(v411_8);
  let mut v411_16 = Space::new();
  let mut v411_16_cursor = (*s0).read_zipper();
  for v411_16_byte in v411_16_cursor.child_mask().iter() {
    v411_16_cursor.descend_to_byte(v411_16_byte);
    let v411_16_tail = v411_16_cursor.make_map();
    v411_16_cursor.ascend(1);
    let v411_16_head = Path::from_slice(&[v411_16_byte]);
    let v412_2: Space = singleton(&(v411_16_head));
    let v412_3: Space = intersect(&(*CONSTANT_2),&(v412_2));
    let v412_4: Space = if has_head(&(v412_3)) { singleton(&[]) } else { Space::new() };
    drop(v412_3);
    let v412_5: Space = subtract(&(*CONSTANT_1),&(v412_4));
    drop(v412_4);
    let v412_8: Space = if (v412_5).is_empty() { Space::new() } else {
      let v413_6: Path = concat_path(&(*p0),&(v411_16_head));
      let mut v413_7 = Space::new();
      let mut v413_7_cursor = (v411_16_tail).read_zipper();
      for v413_7_byte in v413_7_cursor.child_mask().iter() {
        v413_7_cursor.descend_to_byte(v413_7_byte);
        let v413_7_tail = v413_7_cursor.make_map();
        v413_7_cursor.ascend(1);
        let v413_7_head = Path::from_slice(&[v413_7_byte]);
        let v414_2: Space = singleton(&(v413_7_head));
        let v414_3: Space = intersect(&(*CONSTANT_2),&(v414_2));
        let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
        drop(v414_3);
        let v414_5: Space = subtract(&(*CONSTANT_1),&(v414_4));
        drop(v414_4);
        let v414_8: Space = if (v414_5).is_empty() { Space::new() } else {
          let v415_6: Path = concat_path(&(v413_6),&(v413_7_head));
          let v415_7: Space = routine_52(c, &(v415_6), &(*p1), &(v413_7_tail), &(*s1));
          compose(&(v414_5),&(v415_7))
        };
        drop(v414_5);
        let v414_9: Space = intersect(&(*CONSTANT_2),&(v414_2));
        drop(v414_2);
        let v414_10: Space = if has_head(&(v414_9)) { singleton(&[]) } else { Space::new() };
        drop(v414_9);
        let v414_12: Space = if (v414_10).is_empty() { Space::new() } else {
          let v416_6: Path = concat_path(&(v413_6),&(v413_7_head));
          let v416_11: Space = routine_53(c, &(v416_6), &(*p1), &(v413_7_tail), &(*s1));
          drop(v416_6);
          compose(&(v414_10),&(v416_11))
        };
        drop(v414_10);
        let v414_13: Space = unite(&(v414_8),&(v414_12));
        v413_7.join_into((v414_13).clone());
      }
      drop(v413_7_cursor);
      drop(v413_6);
      compose(&(v412_5),&(v413_7))
    };
    drop(v412_5);
    let v412_9: Space = intersect(&(*CONSTANT_2),&(v412_2));
    drop(v412_2);
    let v412_10: Space = if has_head(&(v412_9)) { singleton(&[]) } else { Space::new() };
    drop(v412_9);
    let v412_13: Space = if (v412_10).is_empty() { Space::new() } else {
      let v417_11: Space = unwrap(&(v411_9),&(v411_16_head));
      let mut v417_12 = Space::new();
      let mut v417_12_cursor = (v417_11).read_zipper();
      for v417_12_byte in v417_12_cursor.child_mask().iter() {
        v417_12_cursor.descend_to_byte(v417_12_byte);
        let v417_12_tail = v417_12_cursor.make_map();
        v417_12_cursor.ascend(1);
        let v417_12_head = Path::from_slice(&[v417_12_byte]);
        let v418_2: Space = singleton(&(v417_12_head));
        let v418_3: Space = intersect(&(*CONSTANT_2),&(v418_2));
        let v418_4: Space = if has_head(&(v418_3)) { singleton(&[]) } else { Space::new() };
        drop(v418_3);
        let v418_5: Space = subtract(&(*CONSTANT_1),&(v418_4));
        drop(v418_4);
        let v418_7: Space = if (v418_5).is_empty() { Space::new() } else {
          let v419_6: Space = routine_15(c, &(v417_12_head), &(*p1), &(v417_12_tail));
          compose(&(v418_5),&(v419_6))
        };
        drop(v418_5);
        let v418_8: Space = intersect(&(*CONSTANT_2),&(v418_2));
        drop(v418_2);
        let v418_9: Space = if has_head(&(v418_8)) { singleton(&[]) } else { Space::new() };
        drop(v418_8);
        let v418_11: Space = if (v418_9).is_empty() { Space::new() } else {
          let v420_10: Space = routine_16(c, &(v417_12_head), &(*p1), &(v417_12_tail));
          compose(&(v418_9),&(v420_10))
        };
        drop(v418_9);
        let v418_12: Space = unite(&(v418_7),&(v418_11));
        v417_12.join_into((v418_12).clone());
      }
      drop(v417_12_cursor);
      drop(v417_11);
      compose(&(v412_10),&(v417_12))
    };
    drop(v412_10);
    let v412_14: Space = unite(&(v412_8),&(v412_13));
    v411_16.join_into((v412_14).clone());
  }
  drop(v411_16_cursor);
  drop(v411_9);
  (v411_16).clone()
}

fn routine_46(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v421_12 = Space::new();
  let mut v421_12_cursor = (*s0).read_zipper();
  for v421_12_byte in v421_12_cursor.child_mask().iter() {
    v421_12_cursor.descend_to_byte(v421_12_byte);
    let v421_12_tail = v421_12_cursor.make_map();
    v421_12_cursor.ascend(1);
    let v421_12_head = Path::from_slice(&[v421_12_byte]);
    let v422_2: Space = singleton(&(v421_12_head));
    let v422_3: Space = intersect(&(*CONSTANT_2),&(v422_2));
    let v422_4: Space = if has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
    drop(v422_3);
    let v422_5: Space = subtract(&(*CONSTANT_1),&(v422_4));
    drop(v422_4);
    let v422_8: Space = if (v422_5).is_empty() { Space::new() } else {
      let v423_6: Path = concat_path(&(*p0),&(v421_12_head));
      let mut v423_7 = Space::new();
      let mut v423_7_cursor = (v421_12_tail).read_zipper();
      for v423_7_byte in v423_7_cursor.child_mask().iter() {
        v423_7_cursor.descend_to_byte(v423_7_byte);
        let v423_7_tail = v423_7_cursor.make_map();
        v423_7_cursor.ascend(1);
        let v423_7_head = Path::from_slice(&[v423_7_byte]);
        let v424_2: Space = singleton(&(v423_7_head));
        let v424_3: Space = intersect(&(*CONSTANT_2),&(v424_2));
        let v424_4: Space = if has_head(&(v424_3)) { singleton(&[]) } else { Space::new() };
        drop(v424_3);
        let v424_5: Space = subtract(&(*CONSTANT_1),&(v424_4));
        drop(v424_4);
        let v424_8: Space = if (v424_5).is_empty() { Space::new() } else {
          let v425_6: Path = concat_path(&(v423_6),&(v423_7_head));
          let v425_7: Space = routine_54(c, &(v425_6), &(*p1), &(v423_7_tail));
          compose(&(v424_5),&(v425_7))
        };
        drop(v424_5);
        let v424_9: Space = intersect(&(*CONSTANT_2),&(v424_2));
        drop(v424_2);
        let v424_10: Space = if has_head(&(v424_9)) { singleton(&[]) } else { Space::new() };
        drop(v424_9);
        let v424_12: Space = if (v424_10).is_empty() { Space::new() } else {
          let v426_6: Path = concat_path(&(v423_6),&(v423_7_head));
          let v426_11: Space = routine_55(c, &(v426_6), &(*p1), &(v423_7_tail));
          drop(v426_6);
          compose(&(v424_10),&(v426_11))
        };
        drop(v424_10);
        let v424_13: Space = unite(&(v424_8),&(v424_12));
        v423_7.join_into((v424_13).clone());
      }
      drop(v423_7_cursor);
      compose(&(v422_5),&(v423_7))
    };
    drop(v422_5);
    let v422_9: Space = intersect(&(*CONSTANT_2),&(v422_2));
    drop(v422_2);
    let v422_10: Space = if has_head(&(v422_9)) { singleton(&[]) } else { Space::new() };
    drop(v422_9);
    let v422_12: Space = if (v422_10).is_empty() { Space::new() } else {
      let v427_6: Path = concat_path(&(*p0),&(v421_12_head));
      let mut v427_11 = Space::new();
      let mut v427_11_cursor = (v421_12_tail).read_zipper();
      for v427_11_byte in v427_11_cursor.child_mask().iter() {
        v427_11_cursor.descend_to_byte(v427_11_byte);
        let v427_11_tail = v427_11_cursor.make_map();
        v427_11_cursor.ascend(1);
        let v427_11_head = Path::from_slice(&[v427_11_byte]);
        let v428_2: Space = singleton(&(v427_11_head));
        let v428_3: Space = intersect(&(*CONSTANT_2),&(v428_2));
        let v428_4: Space = if has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
        drop(v428_3);
        let v428_5: Space = subtract(&(*CONSTANT_1),&(v428_4));
        drop(v428_4);
        let v428_8: Space = if (v428_5).is_empty() { Space::new() } else {
          let v429_6: Path = concat_path(&(v427_6),&(v427_11_head));
          let v429_7: Space = routine_54(c, &(v429_6), &(*p1), &(v427_11_tail));
          compose(&(v428_5),&(v429_7))
        };
        drop(v428_5);
        let v428_9: Space = intersect(&(*CONSTANT_2),&(v428_2));
        drop(v428_2);
        let v428_10: Space = if has_head(&(v428_9)) { singleton(&[]) } else { Space::new() };
        drop(v428_9);
        let v428_12: Space = if (v428_10).is_empty() { Space::new() } else {
          let v430_6: Path = concat_path(&(v427_6),&(v427_11_head));
          let v430_11: Space = routine_21(c, &(v430_6), &(*p1), &(v427_11_tail));
          drop(v430_6);
          compose(&(v428_10),&(v430_11))
        };
        drop(v428_10);
        let v428_13: Space = unite(&(v428_8),&(v428_12));
        v427_11.join_into((v428_13).clone());
      }
      drop(v427_11_cursor);
      drop(v427_6);
      compose(&(v422_10),&(v427_11))
    };
    drop(v422_10);
    let v422_13: Space = unite(&(v422_8),&(v422_12));
    v421_12.join_into((v422_13).clone());
  }
  drop(v421_12_cursor);
  (v421_12).clone()
}

fn routine_47(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v431_9 = Space::new();
  let mut v431_9_cursor = (*s0).read_zipper();
  for v431_9_byte in v431_9_cursor.child_mask().iter() {
    v431_9_cursor.descend_to_byte(v431_9_byte);
    let v431_9_tail = v431_9_cursor.make_map();
    v431_9_cursor.ascend(1);
    let v431_9_head = Path::from_slice(&[v431_9_byte]);
    let v432_2: Space = singleton(&(v431_9_head));
    let v432_3: Space = intersect(&(*CONSTANT_2),&(v432_2));
    let v432_4: Space = if has_head(&(v432_3)) { singleton(&[]) } else { Space::new() };
    drop(v432_3);
    let v432_5: Space = subtract(&(*CONSTANT_1),&(v432_4));
    drop(v432_4);
    let v432_8: Space = if (v432_5).is_empty() { Space::new() } else {
      let v433_6: Path = concat_path(&(*p0),&(v431_9_head));
      let mut v433_7 = Space::new();
      let mut v433_7_cursor = (v431_9_tail).read_zipper();
      for v433_7_byte in v433_7_cursor.child_mask().iter() {
        v433_7_cursor.descend_to_byte(v433_7_byte);
        let v433_7_tail = v433_7_cursor.make_map();
        v433_7_cursor.ascend(1);
        let v433_7_head = Path::from_slice(&[v433_7_byte]);
        let v434_2: Space = singleton(&(v433_7_head));
        let v434_3: Space = intersect(&(*CONSTANT_2),&(v434_2));
        let v434_4: Space = if has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
        drop(v434_3);
        let v434_5: Space = subtract(&(*CONSTANT_1),&(v434_4));
        drop(v434_4);
        let v434_8: Space = if (v434_5).is_empty() { Space::new() } else {
          let v435_6: Path = concat_path(&(v433_6),&(v433_7_head));
          let v435_7: Space = routine_54(c, &(v435_6), &(*p1), &(v433_7_tail));
          compose(&(v434_5),&(v435_7))
        };
        drop(v434_5);
        let v434_9: Space = intersect(&(*CONSTANT_2),&(v434_2));
        drop(v434_2);
        let v434_10: Space = if has_head(&(v434_9)) { singleton(&[]) } else { Space::new() };
        drop(v434_9);
        let v434_12: Space = if (v434_10).is_empty() { Space::new() } else {
          let v436_6: Path = concat_path(&(v433_6),&(v433_7_head));
          let v436_11: Space = routine_55(c, &(v436_6), &(*p1), &(v433_7_tail));
          drop(v436_6);
          compose(&(v434_10),&(v436_11))
        };
        drop(v434_10);
        let v434_13: Space = unite(&(v434_8),&(v434_12));
        v433_7.join_into((v434_13).clone());
      }
      drop(v433_7_cursor);
      compose(&(v432_5),&(v433_7))
    };
    drop(v432_5);
    let v432_9: Space = intersect(&(*CONSTANT_2),&(v432_2));
    drop(v432_2);
    let v432_10: Space = if has_head(&(v432_9)) { singleton(&[]) } else { Space::new() };
    drop(v432_9);
    let v432_11: Space = compose(&(v432_10),&(v431_9_tail));
    drop(v432_10);
    let v437_6: Path = concat_path(&(*p0),&(v431_9_head));
    let v432_12: Space = wrap(&(v432_11),&(v437_6));
    drop(v432_11);
    let v432_13: Space = wrap(&(v432_12),&(*p1));
    drop(v432_12);
    let v432_14: Space = unite(&(v432_8),&(v432_13));
    drop(v432_13);
    v431_9.join_into((v432_14).clone());
  }
  drop(v431_9_cursor);
  (v431_9).clone()
}

fn routine_48(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v438_13 = Space::new();
  let mut v438_13_cursor = (*s0).read_zipper();
  for v438_13_byte in v438_13_cursor.child_mask().iter() {
    v438_13_cursor.descend_to_byte(v438_13_byte);
    let v438_13_tail = v438_13_cursor.make_map();
    v438_13_cursor.ascend(1);
    let v438_13_head = Path::from_slice(&[v438_13_byte]);
    let v439_2: Space = singleton(&(v438_13_head));
    let v439_3: Space = intersect(&(*CONSTANT_2),&(v439_2));
    let v439_4: Space = if has_head(&(v439_3)) { singleton(&[]) } else { Space::new() };
    drop(v439_3);
    let v439_5: Space = subtract(&(*CONSTANT_1),&(v439_4));
    drop(v439_4);
    let v439_8: Space = if (v439_5).is_empty() { Space::new() } else {
      let v440_6: Path = concat_path(&(*p0),&(v438_13_head));
      let mut v440_7 = Space::new();
      let mut v440_7_cursor = (v438_13_tail).read_zipper();
      for v440_7_byte in v440_7_cursor.child_mask().iter() {
        v440_7_cursor.descend_to_byte(v440_7_byte);
        let v440_7_tail = v440_7_cursor.make_map();
        v440_7_cursor.ascend(1);
        let v440_7_head = Path::from_slice(&[v440_7_byte]);
        let v441_2: Space = singleton(&(v440_7_head));
        let v441_3: Space = intersect(&(*CONSTANT_2),&(v441_2));
        let v441_4: Space = if has_head(&(v441_3)) { singleton(&[]) } else { Space::new() };
        drop(v441_3);
        let v441_5: Space = subtract(&(*CONSTANT_1),&(v441_4));
        drop(v441_4);
        let v441_8: Space = if (v441_5).is_empty() { Space::new() } else {
          let v442_6: Path = concat_path(&(v440_6),&(v440_7_head));
          let v442_7: Space = routine_56(c, &(v442_6), &(*p1), &(v440_7_tail), &(*s1));
          compose(&(v441_5),&(v442_7))
        };
        drop(v441_5);
        let v441_9: Space = intersect(&(*CONSTANT_2),&(v441_2));
        drop(v441_2);
        let v441_10: Space = if has_head(&(v441_9)) { singleton(&[]) } else { Space::new() };
        drop(v441_9);
        let v441_12: Space = if (v441_10).is_empty() { Space::new() } else {
          let v443_6: Path = concat_path(&(v440_6),&(v440_7_head));
          let v443_11: Space = routine_57(c, &(v443_6), &(*p1), &(v440_7_tail), &(*s1));
          drop(v443_6);
          compose(&(v441_10),&(v443_11))
        };
        drop(v441_10);
        let v441_13: Space = unite(&(v441_8),&(v441_12));
        v440_7.join_into((v441_13).clone());
      }
      drop(v440_7_cursor);
      compose(&(v439_5),&(v440_7))
    };
    drop(v439_5);
    let v439_9: Space = intersect(&(*CONSTANT_2),&(v439_2));
    drop(v439_2);
    let v439_10: Space = if has_head(&(v439_9)) { singleton(&[]) } else { Space::new() };
    drop(v439_9);
    let v439_12: Space = if (v439_10).is_empty() { Space::new() } else {
      let v444_6: Path = concat_path(&(*p0),&(v438_13_head));
      let mut v444_11 = Space::new();
      let mut v444_11_cursor = (v438_13_tail).read_zipper();
      for v444_11_byte in v444_11_cursor.child_mask().iter() {
        v444_11_cursor.descend_to_byte(v444_11_byte);
        let v444_11_tail = v444_11_cursor.make_map();
        v444_11_cursor.ascend(1);
        let v444_11_head = Path::from_slice(&[v444_11_byte]);
        let v445_2: Space = singleton(&(v444_11_head));
        let v445_3: Space = intersect(&(*CONSTANT_2),&(v445_2));
        let v445_4: Space = if has_head(&(v445_3)) { singleton(&[]) } else { Space::new() };
        drop(v445_3);
        let v445_5: Space = subtract(&(*CONSTANT_1),&(v445_4));
        drop(v445_4);
        let v445_8: Space = if (v445_5).is_empty() { Space::new() } else {
          let v446_6: Path = concat_path(&(v444_6),&(v444_11_head));
          let v446_7: Space = routine_56(c, &(v446_6), &(*p1), &(v444_11_tail), &(*s1));
          compose(&(v445_5),&(v446_7))
        };
        drop(v445_5);
        let v445_9: Space = intersect(&(*CONSTANT_2),&(v445_2));
        drop(v445_2);
        let v445_10: Space = if has_head(&(v445_9)) { singleton(&[]) } else { Space::new() };
        drop(v445_9);
        let v445_12: Space = if (v445_10).is_empty() { Space::new() } else {
          let v447_6: Path = concat_path(&(v444_6),&(v444_11_head));
          let v447_11: Space = routine_10(c, &(v447_6), &(*p1), &(v444_11_tail), &(*s1));
          drop(v447_6);
          compose(&(v445_10),&(v447_11))
        };
        drop(v445_10);
        let v445_13: Space = unite(&(v445_8),&(v445_12));
        v444_11.join_into((v445_13).clone());
      }
      drop(v444_11_cursor);
      drop(v444_6);
      compose(&(v439_10),&(v444_11))
    };
    drop(v439_10);
    let v439_13: Space = unite(&(v439_8),&(v439_12));
    v438_13.join_into((v439_13).clone());
  }
  drop(v438_13_cursor);
  (v438_13).clone()
}

fn routine_49(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v448_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v448_9: Space = unwrap(&(v448_8),&(*p0));
  drop(v448_8);
  let mut v448_16 = Space::new();
  let mut v448_16_cursor = (*s0).read_zipper();
  for v448_16_byte in v448_16_cursor.child_mask().iter() {
    v448_16_cursor.descend_to_byte(v448_16_byte);
    let v448_16_tail = v448_16_cursor.make_map();
    v448_16_cursor.ascend(1);
    let v448_16_head = Path::from_slice(&[v448_16_byte]);
    let v449_2: Space = singleton(&(v448_16_head));
    let v449_3: Space = intersect(&(*CONSTANT_2),&(v449_2));
    let v449_4: Space = if has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
    drop(v449_3);
    let v449_5: Space = subtract(&(*CONSTANT_1),&(v449_4));
    drop(v449_4);
    let v449_8: Space = if (v449_5).is_empty() { Space::new() } else {
      let v450_6: Path = concat_path(&(*p0),&(v448_16_head));
      let mut v450_7 = Space::new();
      let mut v450_7_cursor = (v448_16_tail).read_zipper();
      for v450_7_byte in v450_7_cursor.child_mask().iter() {
        v450_7_cursor.descend_to_byte(v450_7_byte);
        let v450_7_tail = v450_7_cursor.make_map();
        v450_7_cursor.ascend(1);
        let v450_7_head = Path::from_slice(&[v450_7_byte]);
        let v451_2: Space = singleton(&(v450_7_head));
        let v451_3: Space = intersect(&(*CONSTANT_2),&(v451_2));
        let v451_4: Space = if has_head(&(v451_3)) { singleton(&[]) } else { Space::new() };
        drop(v451_3);
        let v451_5: Space = subtract(&(*CONSTANT_1),&(v451_4));
        drop(v451_4);
        let v451_8: Space = if (v451_5).is_empty() { Space::new() } else {
          let v452_6: Path = concat_path(&(v450_6),&(v450_7_head));
          let v452_7: Space = routine_56(c, &(v452_6), &(*p1), &(v450_7_tail), &(*s1));
          compose(&(v451_5),&(v452_7))
        };
        drop(v451_5);
        let v451_9: Space = intersect(&(*CONSTANT_2),&(v451_2));
        drop(v451_2);
        let v451_10: Space = if has_head(&(v451_9)) { singleton(&[]) } else { Space::new() };
        drop(v451_9);
        let v451_12: Space = if (v451_10).is_empty() { Space::new() } else {
          let v453_6: Path = concat_path(&(v450_6),&(v450_7_head));
          let v453_11: Space = routine_57(c, &(v453_6), &(*p1), &(v450_7_tail), &(*s1));
          drop(v453_6);
          compose(&(v451_10),&(v453_11))
        };
        drop(v451_10);
        let v451_13: Space = unite(&(v451_8),&(v451_12));
        v450_7.join_into((v451_13).clone());
      }
      drop(v450_7_cursor);
      drop(v450_6);
      compose(&(v449_5),&(v450_7))
    };
    drop(v449_5);
    let v449_9: Space = intersect(&(*CONSTANT_2),&(v449_2));
    drop(v449_2);
    let v449_10: Space = if has_head(&(v449_9)) { singleton(&[]) } else { Space::new() };
    drop(v449_9);
    let v449_13: Space = if (v449_10).is_empty() { Space::new() } else {
      let v454_11: Space = unwrap(&(v448_9),&(v448_16_head));
      let mut v454_12 = Space::new();
      let mut v454_12_cursor = (v454_11).read_zipper();
      for v454_12_byte in v454_12_cursor.child_mask().iter() {
        v454_12_cursor.descend_to_byte(v454_12_byte);
        let v454_12_tail = v454_12_cursor.make_map();
        v454_12_cursor.ascend(1);
        let v454_12_head = Path::from_slice(&[v454_12_byte]);
        let v455_2: Space = singleton(&(v454_12_head));
        let v455_3: Space = intersect(&(*CONSTANT_2),&(v455_2));
        let v455_4: Space = if has_head(&(v455_3)) { singleton(&[]) } else { Space::new() };
        drop(v455_3);
        let v455_5: Space = subtract(&(*CONSTANT_1),&(v455_4));
        drop(v455_4);
        let v455_7: Space = if (v455_5).is_empty() { Space::new() } else {
          let v456_6: Space = routine_15(c, &(v454_12_head), &(*p1), &(v454_12_tail));
          compose(&(v455_5),&(v456_6))
        };
        drop(v455_5);
        let v455_8: Space = intersect(&(*CONSTANT_2),&(v455_2));
        drop(v455_2);
        let v455_9: Space = if has_head(&(v455_8)) { singleton(&[]) } else { Space::new() };
        drop(v455_8);
        let v455_11: Space = if (v455_9).is_empty() { Space::new() } else {
          let v457_10: Space = routine_16(c, &(v454_12_head), &(*p1), &(v454_12_tail));
          compose(&(v455_9),&(v457_10))
        };
        drop(v455_9);
        let v455_12: Space = unite(&(v455_7),&(v455_11));
        v454_12.join_into((v455_12).clone());
      }
      drop(v454_12_cursor);
      drop(v454_11);
      compose(&(v449_10),&(v454_12))
    };
    drop(v449_10);
    let v449_14: Space = unite(&(v449_8),&(v449_13));
    v448_16.join_into((v449_14).clone());
  }
  drop(v448_16_cursor);
  drop(v448_9);
  (v448_16).clone()
}

fn routine_50(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v458_12 = Space::new();
  let mut v458_12_cursor = (*s0).read_zipper();
  for v458_12_byte in v458_12_cursor.child_mask().iter() {
    v458_12_cursor.descend_to_byte(v458_12_byte);
    let v458_12_tail = v458_12_cursor.make_map();
    v458_12_cursor.ascend(1);
    let v458_12_head = Path::from_slice(&[v458_12_byte]);
    let v459_2: Space = singleton(&(v458_12_head));
    let v459_3: Space = intersect(&(*CONSTANT_2),&(v459_2));
    let v459_4: Space = if has_head(&(v459_3)) { singleton(&[]) } else { Space::new() };
    drop(v459_3);
    let v459_5: Space = subtract(&(*CONSTANT_1),&(v459_4));
    drop(v459_4);
    let v459_8: Space = if (v459_5).is_empty() { Space::new() } else {
      let v460_6: Path = concat_path(&(*p0),&(v458_12_head));
      let mut v460_7 = Space::new();
      let mut v460_7_cursor = (v458_12_tail).read_zipper();
      for v460_7_byte in v460_7_cursor.child_mask().iter() {
        v460_7_cursor.descend_to_byte(v460_7_byte);
        let v460_7_tail = v460_7_cursor.make_map();
        v460_7_cursor.ascend(1);
        let v460_7_head = Path::from_slice(&[v460_7_byte]);
        let v461_2: Space = singleton(&(v460_7_head));
        let v461_3: Space = intersect(&(*CONSTANT_2),&(v461_2));
        let v461_4: Space = if has_head(&(v461_3)) { singleton(&[]) } else { Space::new() };
        drop(v461_3);
        let v461_5: Space = subtract(&(*CONSTANT_1),&(v461_4));
        drop(v461_4);
        let v461_8: Space = if (v461_5).is_empty() { Space::new() } else {
          let v462_6: Path = concat_path(&(v460_6),&(v460_7_head));
          let v462_7: Space = routine_58(c, &(v462_6), &(*p1), &(v460_7_tail));
          compose(&(v461_5),&(v462_7))
        };
        drop(v461_5);
        let v461_9: Space = intersect(&(*CONSTANT_2),&(v461_2));
        drop(v461_2);
        let v461_10: Space = if has_head(&(v461_9)) { singleton(&[]) } else { Space::new() };
        drop(v461_9);
        let v461_12: Space = if (v461_10).is_empty() { Space::new() } else {
          let v463_6: Path = concat_path(&(v460_6),&(v460_7_head));
          let v463_11: Space = routine_59(c, &(v463_6), &(*p1), &(v460_7_tail));
          drop(v463_6);
          compose(&(v461_10),&(v463_11))
        };
        drop(v461_10);
        let v461_13: Space = unite(&(v461_8),&(v461_12));
        v460_7.join_into((v461_13).clone());
      }
      drop(v460_7_cursor);
      compose(&(v459_5),&(v460_7))
    };
    drop(v459_5);
    let v459_9: Space = intersect(&(*CONSTANT_2),&(v459_2));
    drop(v459_2);
    let v459_10: Space = if has_head(&(v459_9)) { singleton(&[]) } else { Space::new() };
    drop(v459_9);
    let v459_12: Space = if (v459_10).is_empty() { Space::new() } else {
      let v464_6: Path = concat_path(&(*p0),&(v458_12_head));
      let mut v464_11 = Space::new();
      let mut v464_11_cursor = (v458_12_tail).read_zipper();
      for v464_11_byte in v464_11_cursor.child_mask().iter() {
        v464_11_cursor.descend_to_byte(v464_11_byte);
        let v464_11_tail = v464_11_cursor.make_map();
        v464_11_cursor.ascend(1);
        let v464_11_head = Path::from_slice(&[v464_11_byte]);
        let v465_2: Space = singleton(&(v464_11_head));
        let v465_3: Space = intersect(&(*CONSTANT_2),&(v465_2));
        let v465_4: Space = if has_head(&(v465_3)) { singleton(&[]) } else { Space::new() };
        drop(v465_3);
        let v465_5: Space = subtract(&(*CONSTANT_1),&(v465_4));
        drop(v465_4);
        let v465_8: Space = if (v465_5).is_empty() { Space::new() } else {
          let v466_6: Path = concat_path(&(v464_6),&(v464_11_head));
          let v466_7: Space = routine_58(c, &(v466_6), &(*p1), &(v464_11_tail));
          compose(&(v465_5),&(v466_7))
        };
        drop(v465_5);
        let v465_9: Space = intersect(&(*CONSTANT_2),&(v465_2));
        drop(v465_2);
        let v465_10: Space = if has_head(&(v465_9)) { singleton(&[]) } else { Space::new() };
        drop(v465_9);
        let v465_12: Space = if (v465_10).is_empty() { Space::new() } else {
          let v467_6: Path = concat_path(&(v464_6),&(v464_11_head));
          let v467_11: Space = routine_21(c, &(v467_6), &(*p1), &(v464_11_tail));
          drop(v467_6);
          compose(&(v465_10),&(v467_11))
        };
        drop(v465_10);
        let v465_13: Space = unite(&(v465_8),&(v465_12));
        v464_11.join_into((v465_13).clone());
      }
      drop(v464_11_cursor);
      drop(v464_6);
      compose(&(v459_10),&(v464_11))
    };
    drop(v459_10);
    let v459_13: Space = unite(&(v459_8),&(v459_12));
    v458_12.join_into((v459_13).clone());
  }
  drop(v458_12_cursor);
  (v458_12).clone()
}

fn routine_51(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v468_9 = Space::new();
  let mut v468_9_cursor = (*s0).read_zipper();
  for v468_9_byte in v468_9_cursor.child_mask().iter() {
    v468_9_cursor.descend_to_byte(v468_9_byte);
    let v468_9_tail = v468_9_cursor.make_map();
    v468_9_cursor.ascend(1);
    let v468_9_head = Path::from_slice(&[v468_9_byte]);
    let v469_2: Space = singleton(&(v468_9_head));
    let v469_3: Space = intersect(&(*CONSTANT_2),&(v469_2));
    let v469_4: Space = if has_head(&(v469_3)) { singleton(&[]) } else { Space::new() };
    drop(v469_3);
    let v469_5: Space = subtract(&(*CONSTANT_1),&(v469_4));
    drop(v469_4);
    let v469_8: Space = if (v469_5).is_empty() { Space::new() } else {
      let v470_6: Path = concat_path(&(*p0),&(v468_9_head));
      let mut v470_7 = Space::new();
      let mut v470_7_cursor = (v468_9_tail).read_zipper();
      for v470_7_byte in v470_7_cursor.child_mask().iter() {
        v470_7_cursor.descend_to_byte(v470_7_byte);
        let v470_7_tail = v470_7_cursor.make_map();
        v470_7_cursor.ascend(1);
        let v470_7_head = Path::from_slice(&[v470_7_byte]);
        let v471_2: Space = singleton(&(v470_7_head));
        let v471_3: Space = intersect(&(*CONSTANT_2),&(v471_2));
        let v471_4: Space = if has_head(&(v471_3)) { singleton(&[]) } else { Space::new() };
        drop(v471_3);
        let v471_5: Space = subtract(&(*CONSTANT_1),&(v471_4));
        drop(v471_4);
        let v471_8: Space = if (v471_5).is_empty() { Space::new() } else {
          let v472_6: Path = concat_path(&(v470_6),&(v470_7_head));
          let v472_7: Space = routine_58(c, &(v472_6), &(*p1), &(v470_7_tail));
          compose(&(v471_5),&(v472_7))
        };
        drop(v471_5);
        let v471_9: Space = intersect(&(*CONSTANT_2),&(v471_2));
        drop(v471_2);
        let v471_10: Space = if has_head(&(v471_9)) { singleton(&[]) } else { Space::new() };
        drop(v471_9);
        let v471_12: Space = if (v471_10).is_empty() { Space::new() } else {
          let v473_6: Path = concat_path(&(v470_6),&(v470_7_head));
          let v473_11: Space = routine_59(c, &(v473_6), &(*p1), &(v470_7_tail));
          drop(v473_6);
          compose(&(v471_10),&(v473_11))
        };
        drop(v471_10);
        let v471_13: Space = unite(&(v471_8),&(v471_12));
        v470_7.join_into((v471_13).clone());
      }
      drop(v470_7_cursor);
      compose(&(v469_5),&(v470_7))
    };
    drop(v469_5);
    let v469_9: Space = intersect(&(*CONSTANT_2),&(v469_2));
    drop(v469_2);
    let v469_10: Space = if has_head(&(v469_9)) { singleton(&[]) } else { Space::new() };
    drop(v469_9);
    let v469_11: Space = compose(&(v469_10),&(v468_9_tail));
    drop(v469_10);
    let v474_6: Path = concat_path(&(*p0),&(v468_9_head));
    let v469_12: Space = wrap(&(v469_11),&(v474_6));
    drop(v469_11);
    let v469_13: Space = wrap(&(v469_12),&(*p1));
    drop(v469_12);
    let v469_14: Space = unite(&(v469_8),&(v469_13));
    drop(v469_13);
    v468_9.join_into((v469_14).clone());
  }
  drop(v468_9_cursor);
  (v468_9).clone()
}

fn routine_52(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v475_8 = Space::new();
  let mut v475_8_cursor = (*s0).read_zipper();
  for v475_8_byte in v475_8_cursor.child_mask().iter() {
    v475_8_cursor.descend_to_byte(v475_8_byte);
    let v475_8_tail = v475_8_cursor.make_map();
    v475_8_cursor.ascend(1);
    let v475_8_head = Path::from_slice(&[v475_8_byte]);
    let v476_2: Space = singleton(&(v475_8_head));
    let v476_3: Space = intersect(&(*CONSTANT_2),&(v476_2));
    let v476_4: Space = if has_head(&(v476_3)) { singleton(&[]) } else { Space::new() };
    drop(v476_3);
    let v476_5: Space = subtract(&(*CONSTANT_1),&(v476_4));
    drop(v476_4);
    let mut v476_6 = Space::new();
    let mut v476_6_cursor = (v475_8_tail).read_zipper();
    for v476_6_byte in v476_6_cursor.child_mask().iter() {
      v476_6_cursor.descend_to_byte(v476_6_byte);
      let v476_6_tail = v476_6_cursor.make_map();
      v476_6_cursor.ascend(1);
      let v476_6_head = Path::from_slice(&[v476_6_byte]);
      let v477_2: Space = Space::new();
      v476_6.join_into((v477_2).clone());
    }
    drop(v476_6_cursor);
    let v476_7: Space = compose(&(v476_5),&(v476_6));
    drop(v476_5);
    drop(v476_6);
    let v476_8: Space = intersect(&(*CONSTANT_2),&(v476_2));
    drop(v476_2);
    let v476_9: Space = if has_head(&(v476_8)) { singleton(&[]) } else { Space::new() };
    drop(v476_8);
    let v476_12: Space = if (v476_9).is_empty() { Space::new() } else {
      let v478_10: Path = concat_path(&(*p0),&(v475_8_head));
      let mut v478_11 = Space::new();
      let mut v478_11_cursor = (v475_8_tail).read_zipper();
      for v478_11_byte in v478_11_cursor.child_mask().iter() {
        v478_11_cursor.descend_to_byte(v478_11_byte);
        let v478_11_tail = v478_11_cursor.make_map();
        v478_11_cursor.ascend(1);
        let v478_11_head = Path::from_slice(&[v478_11_byte]);
        let v479_2: Space = singleton(&(v478_11_head));
        let v479_3: Space = intersect(&(*CONSTANT_2),&(v479_2));
        drop(v479_2);
        let v479_4: Space = if has_head(&(v479_3)) { singleton(&[]) } else { Space::new() };
        drop(v479_3);
        let v479_7: Space = if (v479_4).is_empty() { Space::new() } else {
          let v480_5: Path = concat_path(&(v478_10),&(v478_11_head));
          let v480_6: Space = routine_10(c, &(v480_5), &(*p1), &(v478_11_tail), &(*s1));
          drop(v480_5);
          compose(&(v479_4),&(v480_6))
        };
        drop(v479_4);
        v478_11.join_into((v479_7).clone());
      }
      drop(v478_11_cursor);
      drop(v478_10);
      compose(&(v476_9),&(v478_11))
    };
    drop(v476_9);
    let v476_13: Space = unite(&(v476_7),&(v476_12));
    drop(v476_7);
    v475_8.join_into((v476_13).clone());
  }
  drop(v475_8_cursor);
  (v475_8).clone()
}

fn routine_53(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v481_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v481_9: Space = unwrap(&(v481_8),&(*p0));
  drop(v481_8);
  let mut v481_13 = Space::new();
  let mut v481_13_cursor = (*s0).read_zipper();
  for v481_13_byte in v481_13_cursor.child_mask().iter() {
    v481_13_cursor.descend_to_byte(v481_13_byte);
    let v481_13_tail = v481_13_cursor.make_map();
    v481_13_cursor.ascend(1);
    let v481_13_head = Path::from_slice(&[v481_13_byte]);
    let v482_2: Space = singleton(&(v481_13_head));
    let v482_3: Space = intersect(&(*CONSTANT_2),&(v482_2));
    let v482_4: Space = if has_head(&(v482_3)) { singleton(&[]) } else { Space::new() };
    drop(v482_3);
    let v482_5: Space = subtract(&(*CONSTANT_1),&(v482_4));
    drop(v482_4);
    let mut v482_6 = Space::new();
    let mut v482_6_cursor = (v481_13_tail).read_zipper();
    for v482_6_byte in v482_6_cursor.child_mask().iter() {
      v482_6_cursor.descend_to_byte(v482_6_byte);
      let v482_6_tail = v482_6_cursor.make_map();
      v482_6_cursor.ascend(1);
      let v482_6_head = Path::from_slice(&[v482_6_byte]);
      let v483_2: Space = Space::new();
      v482_6.join_into((v483_2).clone());
    }
    drop(v482_6_cursor);
    let v482_7: Space = compose(&(v482_5),&(v482_6));
    drop(v482_5);
    drop(v482_6);
    let v482_8: Space = intersect(&(*CONSTANT_2),&(v482_2));
    drop(v482_2);
    let v482_9: Space = if has_head(&(v482_8)) { singleton(&[]) } else { Space::new() };
    drop(v482_8);
    let v482_12: Space = if (v482_9).is_empty() { Space::new() } else {
      let v484_10: Space = unwrap(&(v481_9),&(v481_13_head));
      let mut v484_11 = Space::new();
      let mut v484_11_cursor = (v484_10).read_zipper();
      for v484_11_byte in v484_11_cursor.child_mask().iter() {
        v484_11_cursor.descend_to_byte(v484_11_byte);
        let v484_11_tail = v484_11_cursor.make_map();
        v484_11_cursor.ascend(1);
        let v484_11_head = Path::from_slice(&[v484_11_byte]);
        let v485_2: Space = singleton(&(v484_11_head));
        let v485_3: Space = intersect(&(*CONSTANT_2),&(v485_2));
        let v485_4: Space = if has_head(&(v485_3)) { singleton(&[]) } else { Space::new() };
        drop(v485_3);
        let v485_5: Space = subtract(&(*CONSTANT_1),&(v485_4));
        drop(v485_4);
        let v485_7: Space = if (v485_5).is_empty() { Space::new() } else {
          let v486_6: Space = routine_15(c, &(v484_11_head), &(*p1), &(v484_11_tail));
          compose(&(v485_5),&(v486_6))
        };
        drop(v485_5);
        let v485_8: Space = intersect(&(*CONSTANT_2),&(v485_2));
        drop(v485_2);
        let v485_9: Space = if has_head(&(v485_8)) { singleton(&[]) } else { Space::new() };
        drop(v485_8);
        let v485_11: Space = if (v485_9).is_empty() { Space::new() } else {
          let v487_10: Space = routine_16(c, &(v484_11_head), &(*p1), &(v484_11_tail));
          compose(&(v485_9),&(v487_10))
        };
        drop(v485_9);
        let v485_12: Space = unite(&(v485_7),&(v485_11));
        v484_11.join_into((v485_12).clone());
      }
      drop(v484_11_cursor);
      drop(v484_10);
      compose(&(v482_9),&(v484_11))
    };
    drop(v482_9);
    let v482_13: Space = unite(&(v482_7),&(v482_12));
    drop(v482_7);
    v481_13.join_into((v482_13).clone());
  }
  drop(v481_13_cursor);
  drop(v481_9);
  (v481_13).clone()
}

fn routine_54(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v488_12 = Space::new();
  let mut v488_12_cursor = (*s0).read_zipper();
  for v488_12_byte in v488_12_cursor.child_mask().iter() {
    v488_12_cursor.descend_to_byte(v488_12_byte);
    let v488_12_tail = v488_12_cursor.make_map();
    v488_12_cursor.ascend(1);
    let v488_12_head = Path::from_slice(&[v488_12_byte]);
    let v489_2: Space = singleton(&(v488_12_head));
    let v489_3: Space = intersect(&(*CONSTANT_2),&(v489_2));
    let v489_4: Space = if has_head(&(v489_3)) { singleton(&[]) } else { Space::new() };
    drop(v489_3);
    let v489_5: Space = subtract(&(*CONSTANT_1),&(v489_4));
    drop(v489_4);
    let v489_8: Space = if (v489_5).is_empty() { Space::new() } else {
      let v490_6: Path = concat_path(&(*p0),&(v488_12_head));
      let mut v490_7 = Space::new();
      let mut v490_7_cursor = (v488_12_tail).read_zipper();
      for v490_7_byte in v490_7_cursor.child_mask().iter() {
        v490_7_cursor.descend_to_byte(v490_7_byte);
        let v490_7_tail = v490_7_cursor.make_map();
        v490_7_cursor.ascend(1);
        let v490_7_head = Path::from_slice(&[v490_7_byte]);
        let v491_2: Space = singleton(&(v490_7_head));
        let v491_3: Space = intersect(&(*CONSTANT_2),&(v491_2));
        let v491_4: Space = if has_head(&(v491_3)) { singleton(&[]) } else { Space::new() };
        drop(v491_3);
        let v491_5: Space = subtract(&(*CONSTANT_1),&(v491_4));
        drop(v491_4);
        let v491_8: Space = if (v491_5).is_empty() { Space::new() } else {
          let v492_6: Path = concat_path(&(v490_6),&(v490_7_head));
          let v492_7: Space = routine_60(c, &(v492_6), &(*p1), &(v490_7_tail));
          compose(&(v491_5),&(v492_7))
        };
        drop(v491_5);
        let v491_9: Space = intersect(&(*CONSTANT_2),&(v491_2));
        drop(v491_2);
        let v491_10: Space = if has_head(&(v491_9)) { singleton(&[]) } else { Space::new() };
        drop(v491_9);
        let v491_12: Space = if (v491_10).is_empty() { Space::new() } else {
          let v493_6: Path = concat_path(&(v490_6),&(v490_7_head));
          let v493_11: Space = routine_61(c, &(v493_6), &(*p1), &(v490_7_tail));
          drop(v493_6);
          compose(&(v491_10),&(v493_11))
        };
        drop(v491_10);
        let v491_13: Space = unite(&(v491_8),&(v491_12));
        v490_7.join_into((v491_13).clone());
      }
      drop(v490_7_cursor);
      compose(&(v489_5),&(v490_7))
    };
    drop(v489_5);
    let v489_9: Space = intersect(&(*CONSTANT_2),&(v489_2));
    drop(v489_2);
    let v489_10: Space = if has_head(&(v489_9)) { singleton(&[]) } else { Space::new() };
    drop(v489_9);
    let v489_12: Space = if (v489_10).is_empty() { Space::new() } else {
      let v494_6: Path = concat_path(&(*p0),&(v488_12_head));
      let mut v494_11 = Space::new();
      let mut v494_11_cursor = (v488_12_tail).read_zipper();
      for v494_11_byte in v494_11_cursor.child_mask().iter() {
        v494_11_cursor.descend_to_byte(v494_11_byte);
        let v494_11_tail = v494_11_cursor.make_map();
        v494_11_cursor.ascend(1);
        let v494_11_head = Path::from_slice(&[v494_11_byte]);
        let v495_2: Space = singleton(&(v494_11_head));
        let v495_3: Space = intersect(&(*CONSTANT_2),&(v495_2));
        let v495_4: Space = if has_head(&(v495_3)) { singleton(&[]) } else { Space::new() };
        drop(v495_3);
        let v495_5: Space = subtract(&(*CONSTANT_1),&(v495_4));
        drop(v495_4);
        let v495_8: Space = if (v495_5).is_empty() { Space::new() } else {
          let v496_6: Path = concat_path(&(v494_6),&(v494_11_head));
          let v496_7: Space = routine_60(c, &(v496_6), &(*p1), &(v494_11_tail));
          compose(&(v495_5),&(v496_7))
        };
        drop(v495_5);
        let v495_9: Space = intersect(&(*CONSTANT_2),&(v495_2));
        drop(v495_2);
        let v495_10: Space = if has_head(&(v495_9)) { singleton(&[]) } else { Space::new() };
        drop(v495_9);
        let v495_12: Space = if (v495_10).is_empty() { Space::new() } else {
          let v497_6: Path = concat_path(&(v494_6),&(v494_11_head));
          let v497_11: Space = routine_21(c, &(v497_6), &(*p1), &(v494_11_tail));
          drop(v497_6);
          compose(&(v495_10),&(v497_11))
        };
        drop(v495_10);
        let v495_13: Space = unite(&(v495_8),&(v495_12));
        v494_11.join_into((v495_13).clone());
      }
      drop(v494_11_cursor);
      drop(v494_6);
      compose(&(v489_10),&(v494_11))
    };
    drop(v489_10);
    let v489_13: Space = unite(&(v489_8),&(v489_12));
    v488_12.join_into((v489_13).clone());
  }
  drop(v488_12_cursor);
  (v488_12).clone()
}

fn routine_55(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v498_9 = Space::new();
  let mut v498_9_cursor = (*s0).read_zipper();
  for v498_9_byte in v498_9_cursor.child_mask().iter() {
    v498_9_cursor.descend_to_byte(v498_9_byte);
    let v498_9_tail = v498_9_cursor.make_map();
    v498_9_cursor.ascend(1);
    let v498_9_head = Path::from_slice(&[v498_9_byte]);
    let v499_2: Space = singleton(&(v498_9_head));
    let v499_3: Space = intersect(&(*CONSTANT_2),&(v499_2));
    let v499_4: Space = if has_head(&(v499_3)) { singleton(&[]) } else { Space::new() };
    drop(v499_3);
    let v499_5: Space = subtract(&(*CONSTANT_1),&(v499_4));
    drop(v499_4);
    let v499_8: Space = if (v499_5).is_empty() { Space::new() } else {
      let v500_6: Path = concat_path(&(*p0),&(v498_9_head));
      let mut v500_7 = Space::new();
      let mut v500_7_cursor = (v498_9_tail).read_zipper();
      for v500_7_byte in v500_7_cursor.child_mask().iter() {
        v500_7_cursor.descend_to_byte(v500_7_byte);
        let v500_7_tail = v500_7_cursor.make_map();
        v500_7_cursor.ascend(1);
        let v500_7_head = Path::from_slice(&[v500_7_byte]);
        let v501_2: Space = singleton(&(v500_7_head));
        let v501_3: Space = intersect(&(*CONSTANT_2),&(v501_2));
        let v501_4: Space = if has_head(&(v501_3)) { singleton(&[]) } else { Space::new() };
        drop(v501_3);
        let v501_5: Space = subtract(&(*CONSTANT_1),&(v501_4));
        drop(v501_4);
        let v501_8: Space = if (v501_5).is_empty() { Space::new() } else {
          let v502_6: Path = concat_path(&(v500_6),&(v500_7_head));
          let v502_7: Space = routine_60(c, &(v502_6), &(*p1), &(v500_7_tail));
          compose(&(v501_5),&(v502_7))
        };
        drop(v501_5);
        let v501_9: Space = intersect(&(*CONSTANT_2),&(v501_2));
        drop(v501_2);
        let v501_10: Space = if has_head(&(v501_9)) { singleton(&[]) } else { Space::new() };
        drop(v501_9);
        let v501_12: Space = if (v501_10).is_empty() { Space::new() } else {
          let v503_6: Path = concat_path(&(v500_6),&(v500_7_head));
          let v503_11: Space = routine_61(c, &(v503_6), &(*p1), &(v500_7_tail));
          drop(v503_6);
          compose(&(v501_10),&(v503_11))
        };
        drop(v501_10);
        let v501_13: Space = unite(&(v501_8),&(v501_12));
        v500_7.join_into((v501_13).clone());
      }
      drop(v500_7_cursor);
      compose(&(v499_5),&(v500_7))
    };
    drop(v499_5);
    let v499_9: Space = intersect(&(*CONSTANT_2),&(v499_2));
    drop(v499_2);
    let v499_10: Space = if has_head(&(v499_9)) { singleton(&[]) } else { Space::new() };
    drop(v499_9);
    let v499_11: Space = compose(&(v499_10),&(v498_9_tail));
    drop(v499_10);
    let v504_6: Path = concat_path(&(*p0),&(v498_9_head));
    let v499_12: Space = wrap(&(v499_11),&(v504_6));
    drop(v499_11);
    let v499_13: Space = wrap(&(v499_12),&(*p1));
    drop(v499_12);
    let v499_14: Space = unite(&(v499_8),&(v499_13));
    drop(v499_13);
    v498_9.join_into((v499_14).clone());
  }
  drop(v498_9_cursor);
  (v498_9).clone()
}

fn routine_56(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v505_4 = Space::new();
  let mut v505_4_cursor = (*s0).read_zipper();
  for v505_4_byte in v505_4_cursor.child_mask().iter() {
    v505_4_cursor.descend_to_byte(v505_4_byte);
    let v505_4_tail = v505_4_cursor.make_map();
    v505_4_cursor.ascend(1);
    let v505_4_head = Path::from_slice(&[v505_4_byte]);
    let v506_2: Space = Space::new();
    v505_4.join_into((v506_2).clone());
  }
  drop(v505_4_cursor);
  (v505_4).clone()
}

fn routine_57(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v507_6: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v507_7: Space = unwrap(&(v507_6),&(*p0));
  drop(v507_6);
  let mut v507_11 = Space::new();
  let mut v507_11_cursor = (*s0).read_zipper();
  for v507_11_byte in v507_11_cursor.child_mask().iter() {
    v507_11_cursor.descend_to_byte(v507_11_byte);
    let v507_11_tail = v507_11_cursor.make_map();
    v507_11_cursor.ascend(1);
    let v507_11_head = Path::from_slice(&[v507_11_byte]);
    let v508_2: Space = singleton(&(v507_11_head));
    let v508_3: Space = intersect(&(*CONSTANT_2),&(v508_2));
    drop(v508_2);
    let v508_4: Space = if has_head(&(v508_3)) { singleton(&[]) } else { Space::new() };
    drop(v508_3);
    let v508_7: Space = if (v508_4).is_empty() { Space::new() } else {
      let v509_5: Space = unwrap(&(v507_7),&(v507_11_head));
      let mut v509_6 = Space::new();
      let mut v509_6_cursor = (v509_5).read_zipper();
      for v509_6_byte in v509_6_cursor.child_mask().iter() {
        v509_6_cursor.descend_to_byte(v509_6_byte);
        let v509_6_tail = v509_6_cursor.make_map();
        v509_6_cursor.ascend(1);
        let v509_6_head = Path::from_slice(&[v509_6_byte]);
        let v510_2: Space = singleton(&(v509_6_head));
        let v510_3: Space = intersect(&(*CONSTANT_2),&(v510_2));
        let v510_4: Space = if has_head(&(v510_3)) { singleton(&[]) } else { Space::new() };
        drop(v510_3);
        let v510_5: Space = subtract(&(*CONSTANT_1),&(v510_4));
        drop(v510_4);
        let v510_7: Space = if (v510_5).is_empty() { Space::new() } else {
          let v511_6: Space = routine_15(c, &(v509_6_head), &(*p1), &(v509_6_tail));
          compose(&(v510_5),&(v511_6))
        };
        drop(v510_5);
        let v510_8: Space = intersect(&(*CONSTANT_2),&(v510_2));
        drop(v510_2);
        let v510_9: Space = if has_head(&(v510_8)) { singleton(&[]) } else { Space::new() };
        drop(v510_8);
        let v510_11: Space = if (v510_9).is_empty() { Space::new() } else {
          let v512_10: Space = routine_16(c, &(v509_6_head), &(*p1), &(v509_6_tail));
          compose(&(v510_9),&(v512_10))
        };
        drop(v510_9);
        let v510_12: Space = unite(&(v510_7),&(v510_11));
        v509_6.join_into((v510_12).clone());
      }
      drop(v509_6_cursor);
      drop(v509_5);
      compose(&(v508_4),&(v509_6))
    };
    drop(v508_4);
    v507_11.join_into((v508_7).clone());
  }
  drop(v507_11_cursor);
  drop(v507_7);
  (v507_11).clone()
}

fn routine_58(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v513_12 = Space::new();
  let mut v513_12_cursor = (*s0).read_zipper();
  for v513_12_byte in v513_12_cursor.child_mask().iter() {
    v513_12_cursor.descend_to_byte(v513_12_byte);
    let v513_12_tail = v513_12_cursor.make_map();
    v513_12_cursor.ascend(1);
    let v513_12_head = Path::from_slice(&[v513_12_byte]);
    let v514_2: Space = singleton(&(v513_12_head));
    let v514_3: Space = intersect(&(*CONSTANT_2),&(v514_2));
    let v514_4: Space = if has_head(&(v514_3)) { singleton(&[]) } else { Space::new() };
    drop(v514_3);
    let v514_5: Space = subtract(&(*CONSTANT_1),&(v514_4));
    drop(v514_4);
    let v514_8: Space = if (v514_5).is_empty() { Space::new() } else {
      let v515_6: Path = concat_path(&(*p0),&(v513_12_head));
      let mut v515_7 = Space::new();
      let mut v515_7_cursor = (v513_12_tail).read_zipper();
      for v515_7_byte in v515_7_cursor.child_mask().iter() {
        v515_7_cursor.descend_to_byte(v515_7_byte);
        let v515_7_tail = v515_7_cursor.make_map();
        v515_7_cursor.ascend(1);
        let v515_7_head = Path::from_slice(&[v515_7_byte]);
        let v516_2: Space = singleton(&(v515_7_head));
        let v516_3: Space = intersect(&(*CONSTANT_2),&(v516_2));
        let v516_4: Space = if has_head(&(v516_3)) { singleton(&[]) } else { Space::new() };
        drop(v516_3);
        let v516_5: Space = subtract(&(*CONSTANT_1),&(v516_4));
        drop(v516_4);
        let v516_8: Space = if (v516_5).is_empty() { Space::new() } else {
          let v517_6: Path = concat_path(&(v515_6),&(v515_7_head));
          let v517_7: Space = routine_62(c, &(v517_6), &(*p1), &(v515_7_tail));
          compose(&(v516_5),&(v517_7))
        };
        drop(v516_5);
        let v516_9: Space = intersect(&(*CONSTANT_2),&(v516_2));
        drop(v516_2);
        let v516_10: Space = if has_head(&(v516_9)) { singleton(&[]) } else { Space::new() };
        drop(v516_9);
        let v516_12: Space = if (v516_10).is_empty() { Space::new() } else {
          let v518_6: Path = concat_path(&(v515_6),&(v515_7_head));
          let v518_11: Space = routine_63(c, &(v518_6), &(*p1), &(v515_7_tail));
          drop(v518_6);
          compose(&(v516_10),&(v518_11))
        };
        drop(v516_10);
        let v516_13: Space = unite(&(v516_8),&(v516_12));
        v515_7.join_into((v516_13).clone());
      }
      drop(v515_7_cursor);
      compose(&(v514_5),&(v515_7))
    };
    drop(v514_5);
    let v514_9: Space = intersect(&(*CONSTANT_2),&(v514_2));
    drop(v514_2);
    let v514_10: Space = if has_head(&(v514_9)) { singleton(&[]) } else { Space::new() };
    drop(v514_9);
    let v514_12: Space = if (v514_10).is_empty() { Space::new() } else {
      let v519_6: Path = concat_path(&(*p0),&(v513_12_head));
      let mut v519_11 = Space::new();
      let mut v519_11_cursor = (v513_12_tail).read_zipper();
      for v519_11_byte in v519_11_cursor.child_mask().iter() {
        v519_11_cursor.descend_to_byte(v519_11_byte);
        let v519_11_tail = v519_11_cursor.make_map();
        v519_11_cursor.ascend(1);
        let v519_11_head = Path::from_slice(&[v519_11_byte]);
        let v520_2: Space = singleton(&(v519_11_head));
        let v520_3: Space = intersect(&(*CONSTANT_2),&(v520_2));
        let v520_4: Space = if has_head(&(v520_3)) { singleton(&[]) } else { Space::new() };
        drop(v520_3);
        let v520_5: Space = subtract(&(*CONSTANT_1),&(v520_4));
        drop(v520_4);
        let v520_8: Space = if (v520_5).is_empty() { Space::new() } else {
          let v521_6: Path = concat_path(&(v519_6),&(v519_11_head));
          let v521_7: Space = routine_62(c, &(v521_6), &(*p1), &(v519_11_tail));
          compose(&(v520_5),&(v521_7))
        };
        drop(v520_5);
        let v520_9: Space = intersect(&(*CONSTANT_2),&(v520_2));
        drop(v520_2);
        let v520_10: Space = if has_head(&(v520_9)) { singleton(&[]) } else { Space::new() };
        drop(v520_9);
        let v520_12: Space = if (v520_10).is_empty() { Space::new() } else {
          let v522_6: Path = concat_path(&(v519_6),&(v519_11_head));
          let v522_11: Space = routine_21(c, &(v522_6), &(*p1), &(v519_11_tail));
          drop(v522_6);
          compose(&(v520_10),&(v522_11))
        };
        drop(v520_10);
        let v520_13: Space = unite(&(v520_8),&(v520_12));
        v519_11.join_into((v520_13).clone());
      }
      drop(v519_11_cursor);
      drop(v519_6);
      compose(&(v514_10),&(v519_11))
    };
    drop(v514_10);
    let v514_13: Space = unite(&(v514_8),&(v514_12));
    v513_12.join_into((v514_13).clone());
  }
  drop(v513_12_cursor);
  (v513_12).clone()
}

fn routine_59(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v523_9 = Space::new();
  let mut v523_9_cursor = (*s0).read_zipper();
  for v523_9_byte in v523_9_cursor.child_mask().iter() {
    v523_9_cursor.descend_to_byte(v523_9_byte);
    let v523_9_tail = v523_9_cursor.make_map();
    v523_9_cursor.ascend(1);
    let v523_9_head = Path::from_slice(&[v523_9_byte]);
    let v524_2: Space = singleton(&(v523_9_head));
    let v524_3: Space = intersect(&(*CONSTANT_2),&(v524_2));
    let v524_4: Space = if has_head(&(v524_3)) { singleton(&[]) } else { Space::new() };
    drop(v524_3);
    let v524_5: Space = subtract(&(*CONSTANT_1),&(v524_4));
    drop(v524_4);
    let v524_8: Space = if (v524_5).is_empty() { Space::new() } else {
      let v525_6: Path = concat_path(&(*p0),&(v523_9_head));
      let mut v525_7 = Space::new();
      let mut v525_7_cursor = (v523_9_tail).read_zipper();
      for v525_7_byte in v525_7_cursor.child_mask().iter() {
        v525_7_cursor.descend_to_byte(v525_7_byte);
        let v525_7_tail = v525_7_cursor.make_map();
        v525_7_cursor.ascend(1);
        let v525_7_head = Path::from_slice(&[v525_7_byte]);
        let v526_2: Space = singleton(&(v525_7_head));
        let v526_3: Space = intersect(&(*CONSTANT_2),&(v526_2));
        let v526_4: Space = if has_head(&(v526_3)) { singleton(&[]) } else { Space::new() };
        drop(v526_3);
        let v526_5: Space = subtract(&(*CONSTANT_1),&(v526_4));
        drop(v526_4);
        let v526_8: Space = if (v526_5).is_empty() { Space::new() } else {
          let v527_6: Path = concat_path(&(v525_6),&(v525_7_head));
          let v527_7: Space = routine_62(c, &(v527_6), &(*p1), &(v525_7_tail));
          compose(&(v526_5),&(v527_7))
        };
        drop(v526_5);
        let v526_9: Space = intersect(&(*CONSTANT_2),&(v526_2));
        drop(v526_2);
        let v526_10: Space = if has_head(&(v526_9)) { singleton(&[]) } else { Space::new() };
        drop(v526_9);
        let v526_12: Space = if (v526_10).is_empty() { Space::new() } else {
          let v528_6: Path = concat_path(&(v525_6),&(v525_7_head));
          let v528_11: Space = routine_63(c, &(v528_6), &(*p1), &(v525_7_tail));
          drop(v528_6);
          compose(&(v526_10),&(v528_11))
        };
        drop(v526_10);
        let v526_13: Space = unite(&(v526_8),&(v526_12));
        v525_7.join_into((v526_13).clone());
      }
      drop(v525_7_cursor);
      compose(&(v524_5),&(v525_7))
    };
    drop(v524_5);
    let v524_9: Space = intersect(&(*CONSTANT_2),&(v524_2));
    drop(v524_2);
    let v524_10: Space = if has_head(&(v524_9)) { singleton(&[]) } else { Space::new() };
    drop(v524_9);
    let v524_11: Space = compose(&(v524_10),&(v523_9_tail));
    drop(v524_10);
    let v529_6: Path = concat_path(&(*p0),&(v523_9_head));
    let v524_12: Space = wrap(&(v524_11),&(v529_6));
    drop(v524_11);
    let v524_13: Space = wrap(&(v524_12),&(*p1));
    drop(v524_12);
    let v524_14: Space = unite(&(v524_8),&(v524_13));
    drop(v524_13);
    v523_9.join_into((v524_14).clone());
  }
  drop(v523_9_cursor);
  (v523_9).clone()
}

fn routine_60(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v530_7 = Space::new();
  let mut v530_7_cursor = (*s0).read_zipper();
  for v530_7_byte in v530_7_cursor.child_mask().iter() {
    v530_7_cursor.descend_to_byte(v530_7_byte);
    let v530_7_tail = v530_7_cursor.make_map();
    v530_7_cursor.ascend(1);
    let v530_7_head = Path::from_slice(&[v530_7_byte]);
    let v531_2: Space = singleton(&(v530_7_head));
    let v531_3: Space = intersect(&(*CONSTANT_2),&(v531_2));
    let v531_4: Space = if has_head(&(v531_3)) { singleton(&[]) } else { Space::new() };
    drop(v531_3);
    let v531_5: Space = subtract(&(*CONSTANT_1),&(v531_4));
    drop(v531_4);
    let mut v531_6 = Space::new();
    let mut v531_6_cursor = (v530_7_tail).read_zipper();
    for v531_6_byte in v531_6_cursor.child_mask().iter() {
      v531_6_cursor.descend_to_byte(v531_6_byte);
      let v531_6_tail = v531_6_cursor.make_map();
      v531_6_cursor.ascend(1);
      let v531_6_head = Path::from_slice(&[v531_6_byte]);
      let v532_2: Space = Space::new();
      v531_6.join_into((v532_2).clone());
    }
    drop(v531_6_cursor);
    let v531_7: Space = compose(&(v531_5),&(v531_6));
    drop(v531_5);
    drop(v531_6);
    let v531_8: Space = intersect(&(*CONSTANT_2),&(v531_2));
    drop(v531_2);
    let v531_9: Space = if has_head(&(v531_8)) { singleton(&[]) } else { Space::new() };
    drop(v531_8);
    let v531_12: Space = if (v531_9).is_empty() { Space::new() } else {
      let v533_10: Path = concat_path(&(*p0),&(v530_7_head));
      let mut v533_11 = Space::new();
      let mut v533_11_cursor = (v530_7_tail).read_zipper();
      for v533_11_byte in v533_11_cursor.child_mask().iter() {
        v533_11_cursor.descend_to_byte(v533_11_byte);
        let v533_11_tail = v533_11_cursor.make_map();
        v533_11_cursor.ascend(1);
        let v533_11_head = Path::from_slice(&[v533_11_byte]);
        let v534_2: Space = singleton(&(v533_11_head));
        let v534_3: Space = intersect(&(*CONSTANT_2),&(v534_2));
        drop(v534_2);
        let v534_4: Space = if has_head(&(v534_3)) { singleton(&[]) } else { Space::new() };
        drop(v534_3);
        let v534_7: Space = if (v534_4).is_empty() { Space::new() } else {
          let v535_5: Path = concat_path(&(v533_10),&(v533_11_head));
          let v535_6: Space = routine_21(c, &(v535_5), &(*p1), &(v533_11_tail));
          drop(v535_5);
          compose(&(v534_4),&(v535_6))
        };
        drop(v534_4);
        v533_11.join_into((v534_7).clone());
      }
      drop(v533_11_cursor);
      drop(v533_10);
      compose(&(v531_9),&(v533_11))
    };
    drop(v531_9);
    let v531_13: Space = unite(&(v531_7),&(v531_12));
    drop(v531_7);
    v530_7.join_into((v531_13).clone());
  }
  drop(v530_7_cursor);
  (v530_7).clone()
}

fn routine_61(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v536_6 = Space::new();
  let mut v536_6_cursor = (*s0).read_zipper();
  for v536_6_byte in v536_6_cursor.child_mask().iter() {
    v536_6_cursor.descend_to_byte(v536_6_byte);
    let v536_6_tail = v536_6_cursor.make_map();
    v536_6_cursor.ascend(1);
    let v536_6_head = Path::from_slice(&[v536_6_byte]);
    let v537_2: Space = singleton(&(v536_6_head));
    let v537_3: Space = intersect(&(*CONSTANT_2),&(v537_2));
    let v537_4: Space = if has_head(&(v537_3)) { singleton(&[]) } else { Space::new() };
    drop(v537_3);
    let v537_5: Space = subtract(&(*CONSTANT_1),&(v537_4));
    drop(v537_4);
    let mut v537_6 = Space::new();
    let mut v537_6_cursor = (v536_6_tail).read_zipper();
    for v537_6_byte in v537_6_cursor.child_mask().iter() {
      v537_6_cursor.descend_to_byte(v537_6_byte);
      let v537_6_tail = v537_6_cursor.make_map();
      v537_6_cursor.ascend(1);
      let v537_6_head = Path::from_slice(&[v537_6_byte]);
      let v538_2: Space = Space::new();
      v537_6.join_into((v538_2).clone());
    }
    drop(v537_6_cursor);
    let v537_7: Space = compose(&(v537_5),&(v537_6));
    drop(v537_5);
    drop(v537_6);
    let v537_8: Space = intersect(&(*CONSTANT_2),&(v537_2));
    drop(v537_2);
    let v537_9: Space = if has_head(&(v537_8)) { singleton(&[]) } else { Space::new() };
    drop(v537_8);
    let v537_10: Space = compose(&(v537_9),&(v536_6_tail));
    drop(v537_9);
    let v537_11: Path = concat_path(&(*p0),&(v536_6_head));
    let v537_12: Space = wrap(&(v537_10),&(v537_11));
    drop(v537_10);
    drop(v537_11);
    let v537_13: Space = wrap(&(v537_12),&(*p1));
    drop(v537_12);
    let v537_14: Space = unite(&(v537_7),&(v537_13));
    drop(v537_7);
    drop(v537_13);
    v536_6.join_into((v537_14).clone());
  }
  drop(v536_6_cursor);
  (v536_6).clone()
}

fn routine_62(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v539_3 = Space::new();
  let mut v539_3_cursor = (*s0).read_zipper();
  for v539_3_byte in v539_3_cursor.child_mask().iter() {
    v539_3_cursor.descend_to_byte(v539_3_byte);
    let v539_3_tail = v539_3_cursor.make_map();
    v539_3_cursor.ascend(1);
    let v539_3_head = Path::from_slice(&[v539_3_byte]);
    let v540_2: Space = Space::new();
    v539_3.join_into((v540_2).clone());
  }
  drop(v539_3_cursor);
  (v539_3).clone()
}

fn routine_63(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v541_4 = Space::new();
  let mut v541_4_cursor = (*s0).read_zipper();
  for v541_4_byte in v541_4_cursor.child_mask().iter() {
    v541_4_cursor.descend_to_byte(v541_4_byte);
    let v541_4_tail = v541_4_cursor.make_map();
    v541_4_cursor.ascend(1);
    let v541_4_head = Path::from_slice(&[v541_4_byte]);
    let v542_2: Space = singleton(&(v541_4_head));
    let v542_3: Space = intersect(&(*CONSTANT_2),&(v542_2));
    drop(v542_2);
    let v542_4: Space = if has_head(&(v542_3)) { singleton(&[]) } else { Space::new() };
    drop(v542_3);
    let v542_5: Space = compose(&(v542_4),&(v541_4_tail));
    drop(v542_4);
    let v542_6: Path = concat_path(&(*p0),&(v541_4_head));
    let v542_7: Space = wrap(&(v542_5),&(v542_6));
    drop(v542_5);
    drop(v542_6);
    v541_4.join_into((v542_7).clone());
  }
  drop(v541_4_cursor);
  let v541_5: Space = wrap(&(v541_4),&(*p1));
  drop(v541_4);
  (v541_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
