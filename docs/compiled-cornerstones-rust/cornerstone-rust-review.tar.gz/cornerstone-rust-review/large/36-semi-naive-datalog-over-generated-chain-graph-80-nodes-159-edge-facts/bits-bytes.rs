#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,0,1,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,0,1,0,1,0,1,1]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,0,1,0,0,1,0,1,1]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,0,1,0,1,1,0,1,0,1,0,0,1,0,1,1]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,0,1,0,1,0,1,1,0,1,0,1,0,0,1,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let mut v0_12 = Space::new();
  let mut v0_12_cursor = (v0_2).read_zipper();
  for v0_12_byte in v0_12_cursor.child_mask().iter() {
    v0_12_cursor.descend_to_byte(v0_12_byte);
    let v0_12_tail = v0_12_cursor.make_map();
    v0_12_cursor.ascend(1);
    let v0_12_head = Path::from_slice(&[v0_12_byte]);
    let v1_2: Space = singleton(&(v0_12_head));
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_12_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        let v2_6_tail = v2_6_cursor.make_map();
        v2_6_cursor.ascend(1);
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_12_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_12_head),&(v2_6_head));
          let v5_11: Space = routine_2(c, &(v5_6), &(v2_6_tail));
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_cursor = (v0_12_tail).read_zipper();
      for v6_10_byte in v6_10_cursor.child_mask().iter() {
        v6_10_cursor.descend_to_byte(v6_10_byte);
        let v6_10_tail = v6_10_cursor.make_map();
        v6_10_cursor.ascend(1);
        let v6_10_head = Path::from_slice(&[v6_10_byte]);
        let v7_2: Space = singleton(&(v6_10_head));
        let v7_3: Space = intersect(&(*CONSTANT_2),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_1),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_12_head),&(v6_10_head));
          let v8_7: Space = routine_1(c, &(v8_6), &(v6_10_tail));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_2),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v0_12_head),&(v6_10_head));
          let v9_11: Space = routine_3(c, &(v9_6), &(v6_10_tail));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_10.join_into((v7_13).clone());
      }
      drop(v6_10_cursor);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_12.join_into((v1_12).clone());
  }
  drop(v0_12_cursor);
  drop(v0_2);
  let v0_14: Space = wrap(&(v0_12),&(*CONSTANT_3));
  let v0_16: Space = wrap(&(*s0.expect("unbound native input")),&(*CONSTANT_4));
  let v0_17: Space = unite(&(v0_14),&(v0_16));
  drop(v0_16);
  let mut v0_57: Space = (v0_17).clone();
  loop {
    let v10_1: Space = unwrap(&(v0_57),&(*CONSTANT_3));
    let v10_2: Space = unwrap(&(v10_1),&(*CONSTANT_5));
    let mut v10_3 = Space::new();
    let mut v10_3_cursor = (v10_2).read_zipper();
    for v10_3_byte in v10_3_cursor.child_mask().iter() {
      v10_3_cursor.descend_to_byte(v10_3_byte);
      let v10_3_tail = v10_3_cursor.make_map();
      v10_3_cursor.ascend(1);
      let v10_3_head = Path::from_slice(&[v10_3_byte]);
      let v11_2: Space = singleton(&(v10_3_head));
      let v11_3: Space = intersect(&(*CONSTANT_2),&(v11_2));
      let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
      drop(v11_3);
      let v11_5: Space = subtract(&(*CONSTANT_1),&(v11_4));
      drop(v11_4);
      let v11_7: Space = if (v11_5).is_empty() { Space::new() } else {
        let mut v12_6 = Space::new();
        let mut v12_6_cursor = (v10_3_tail).read_zipper();
        for v12_6_byte in v12_6_cursor.child_mask().iter() {
          v12_6_cursor.descend_to_byte(v12_6_byte);
          let v12_6_tail = v12_6_cursor.make_map();
          v12_6_cursor.ascend(1);
          let v12_6_head = Path::from_slice(&[v12_6_byte]);
          let v13_2: Space = singleton(&(v12_6_head));
          let v13_3: Space = intersect(&(*CONSTANT_2),&(v13_2));
          let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
          drop(v13_3);
          let v13_5: Space = subtract(&(*CONSTANT_1),&(v13_4));
          drop(v13_4);
          let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
            let v14_6: Path = concat_path(&(v10_3_head),&(v12_6_head));
            let v14_7: Space = routine_4(c, &(v14_6), &(v12_6_tail), &(v0_57));
            compose(&(v13_5),&(v14_7))
          };
          drop(v13_5);
          let v13_9: Space = intersect(&(*CONSTANT_2),&(v13_2));
          drop(v13_2);
          let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
          drop(v13_9);
          let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
            let v15_6: Path = concat_path(&(v10_3_head),&(v12_6_head));
            let v15_11: Space = routine_5(c, &(v15_6), &(v12_6_tail), &(v0_57));
            drop(v15_6);
            compose(&(v13_10),&(v15_11))
          };
          drop(v13_10);
          let v13_13: Space = unite(&(v13_8),&(v13_12));
          v12_6.join_into((v13_13).clone());
        }
        drop(v12_6_cursor);
        compose(&(v11_5),&(v12_6))
      };
      drop(v11_5);
      let v11_8: Space = intersect(&(*CONSTANT_2),&(v11_2));
      drop(v11_2);
      let v11_9: Space = if has_head(&(v11_8)) { singleton(&[]) } else { Space::new() };
      drop(v11_8);
      let v11_11: Space = if (v11_9).is_empty() { Space::new() } else {
        let mut v16_10 = Space::new();
        let mut v16_10_cursor = (v10_3_tail).read_zipper();
        for v16_10_byte in v16_10_cursor.child_mask().iter() {
          v16_10_cursor.descend_to_byte(v16_10_byte);
          let v16_10_tail = v16_10_cursor.make_map();
          v16_10_cursor.ascend(1);
          let v16_10_head = Path::from_slice(&[v16_10_byte]);
          let v17_2: Space = singleton(&(v16_10_head));
          let v17_3: Space = intersect(&(*CONSTANT_2),&(v17_2));
          let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
          drop(v17_3);
          let v17_5: Space = subtract(&(*CONSTANT_1),&(v17_4));
          drop(v17_4);
          let v17_8: Space = if (v17_5).is_empty() { Space::new() } else {
            let v18_6: Path = concat_path(&(v10_3_head),&(v16_10_head));
            let v18_7: Space = routine_4(c, &(v18_6), &(v16_10_tail), &(v0_57));
            compose(&(v17_5),&(v18_7))
          };
          drop(v17_5);
          let v17_9: Space = intersect(&(*CONSTANT_2),&(v17_2));
          drop(v17_2);
          let v17_10: Space = if has_head(&(v17_9)) { singleton(&[]) } else { Space::new() };
          drop(v17_9);
          let v17_12: Space = if (v17_10).is_empty() { Space::new() } else {
            let v19_6: Path = concat_path(&(v10_3_head),&(v16_10_head));
            let v19_11: Space = routine_6(c, &(v19_6), &(v16_10_tail), &(v0_57));
            drop(v19_6);
            compose(&(v17_10),&(v19_11))
          };
          drop(v17_10);
          let v17_13: Space = unite(&(v17_8),&(v17_12));
          v16_10.join_into((v17_13).clone());
        }
        drop(v16_10_cursor);
        compose(&(v11_9),&(v16_10))
      };
      drop(v11_9);
      let v11_12: Space = unite(&(v11_7),&(v11_11));
      v10_3.join_into((v11_12).clone());
    }
    drop(v10_3_cursor);
    let mut v10_4 = Space::new();
    let mut v10_4_cursor = (v10_2).read_zipper();
    for v10_4_byte in v10_4_cursor.child_mask().iter() {
      v10_4_cursor.descend_to_byte(v10_4_byte);
      let v10_4_tail = v10_4_cursor.make_map();
      v10_4_cursor.ascend(1);
      let v10_4_head = Path::from_slice(&[v10_4_byte]);
      let v20_2: Space = singleton(&(v10_4_head));
      let v20_3: Space = intersect(&(*CONSTANT_2),&(v20_2));
      let v20_4: Space = if has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
      drop(v20_3);
      let v20_5: Space = subtract(&(*CONSTANT_1),&(v20_4));
      drop(v20_4);
      let v20_7: Space = if (v20_5).is_empty() { Space::new() } else {
        let mut v21_6 = Space::new();
        let mut v21_6_cursor = (v10_4_tail).read_zipper();
        for v21_6_byte in v21_6_cursor.child_mask().iter() {
          v21_6_cursor.descend_to_byte(v21_6_byte);
          let v21_6_tail = v21_6_cursor.make_map();
          v21_6_cursor.ascend(1);
          let v21_6_head = Path::from_slice(&[v21_6_byte]);
          let v22_2: Space = singleton(&(v21_6_head));
          let v22_3: Space = intersect(&(*CONSTANT_2),&(v22_2));
          let v22_4: Space = if has_head(&(v22_3)) { singleton(&[]) } else { Space::new() };
          drop(v22_3);
          let v22_5: Space = subtract(&(*CONSTANT_1),&(v22_4));
          drop(v22_4);
          let v22_8: Space = if (v22_5).is_empty() { Space::new() } else {
            let v23_6: Path = concat_path(&(v10_4_head),&(v21_6_head));
            let v23_7: Space = routine_7(c, &(v23_6), &(v21_6_tail), &(v0_57));
            compose(&(v22_5),&(v23_7))
          };
          drop(v22_5);
          let v22_9: Space = intersect(&(*CONSTANT_2),&(v22_2));
          drop(v22_2);
          let v22_10: Space = if has_head(&(v22_9)) { singleton(&[]) } else { Space::new() };
          drop(v22_9);
          let v22_12: Space = if (v22_10).is_empty() { Space::new() } else {
            let v24_6: Path = concat_path(&(v10_4_head),&(v21_6_head));
            let v24_11: Space = routine_8(c, &(v24_6), &(v21_6_tail), &(v0_57));
            drop(v24_6);
            compose(&(v22_10),&(v24_11))
          };
          drop(v22_10);
          let v22_13: Space = unite(&(v22_8),&(v22_12));
          v21_6.join_into((v22_13).clone());
        }
        drop(v21_6_cursor);
        compose(&(v20_5),&(v21_6))
      };
      drop(v20_5);
      let v20_8: Space = intersect(&(*CONSTANT_2),&(v20_2));
      drop(v20_2);
      let v20_9: Space = if has_head(&(v20_8)) { singleton(&[]) } else { Space::new() };
      drop(v20_8);
      let v20_11: Space = if (v20_9).is_empty() { Space::new() } else {
        let mut v25_10 = Space::new();
        let mut v25_10_cursor = (v10_4_tail).read_zipper();
        for v25_10_byte in v25_10_cursor.child_mask().iter() {
          v25_10_cursor.descend_to_byte(v25_10_byte);
          let v25_10_tail = v25_10_cursor.make_map();
          v25_10_cursor.ascend(1);
          let v25_10_head = Path::from_slice(&[v25_10_byte]);
          let v26_2: Space = singleton(&(v25_10_head));
          let v26_3: Space = intersect(&(*CONSTANT_2),&(v26_2));
          let v26_4: Space = if has_head(&(v26_3)) { singleton(&[]) } else { Space::new() };
          drop(v26_3);
          let v26_5: Space = subtract(&(*CONSTANT_1),&(v26_4));
          drop(v26_4);
          let v26_8: Space = if (v26_5).is_empty() { Space::new() } else {
            let v27_6: Path = concat_path(&(v10_4_head),&(v25_10_head));
            let v27_7: Space = routine_7(c, &(v27_6), &(v25_10_tail), &(v0_57));
            compose(&(v26_5),&(v27_7))
          };
          drop(v26_5);
          let v26_9: Space = intersect(&(*CONSTANT_2),&(v26_2));
          drop(v26_2);
          let v26_10: Space = if has_head(&(v26_9)) { singleton(&[]) } else { Space::new() };
          drop(v26_9);
          let v26_12: Space = if (v26_10).is_empty() { Space::new() } else {
            let v28_6: Path = concat_path(&(v10_4_head),&(v25_10_head));
            let v28_11: Space = routine_9(c, &(v28_6), &(v25_10_tail), &(v0_57));
            drop(v28_6);
            compose(&(v26_10),&(v28_11))
          };
          drop(v26_10);
          let v26_13: Space = unite(&(v26_8),&(v26_12));
          v25_10.join_into((v26_13).clone());
        }
        drop(v25_10_cursor);
        compose(&(v20_9),&(v25_10))
      };
      drop(v20_9);
      let v20_12: Space = unite(&(v20_7),&(v20_11));
      v10_4.join_into((v20_12).clone());
    }
    drop(v10_4_cursor);
    drop(v10_2);
    let v10_5: Space = unite(&(v10_3),&(v10_4));
    let v10_6: Space = unwrap(&(v0_57),&(*CONSTANT_4));
    let v10_7: Space = unwrap(&(v10_6),&(*CONSTANT_5));
    let mut v10_8 = Space::new();
    let mut v10_8_cursor = (v10_7).read_zipper();
    for v10_8_byte in v10_8_cursor.child_mask().iter() {
      v10_8_cursor.descend_to_byte(v10_8_byte);
      let v10_8_tail = v10_8_cursor.make_map();
      v10_8_cursor.ascend(1);
      let v10_8_head = Path::from_slice(&[v10_8_byte]);
      let v29_2: Space = singleton(&(v10_8_head));
      let v29_3: Space = intersect(&(*CONSTANT_2),&(v29_2));
      let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
      drop(v29_3);
      let v29_5: Space = subtract(&(*CONSTANT_1),&(v29_4));
      drop(v29_4);
      let v29_7: Space = if (v29_5).is_empty() { Space::new() } else {
        let mut v30_6 = Space::new();
        let mut v30_6_cursor = (v10_8_tail).read_zipper();
        for v30_6_byte in v30_6_cursor.child_mask().iter() {
          v30_6_cursor.descend_to_byte(v30_6_byte);
          let v30_6_tail = v30_6_cursor.make_map();
          v30_6_cursor.ascend(1);
          let v30_6_head = Path::from_slice(&[v30_6_byte]);
          let v31_2: Space = singleton(&(v30_6_head));
          let v31_3: Space = intersect(&(*CONSTANT_2),&(v31_2));
          let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
          drop(v31_3);
          let v31_5: Space = subtract(&(*CONSTANT_1),&(v31_4));
          drop(v31_4);
          let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
            let v32_6: Path = concat_path(&(v10_8_head),&(v30_6_head));
            let v32_7: Space = routine_10(c, &(v32_6), &(v30_6_tail), &(v0_57));
            compose(&(v31_5),&(v32_7))
          };
          drop(v31_5);
          let v31_9: Space = intersect(&(*CONSTANT_2),&(v31_2));
          drop(v31_2);
          let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
          drop(v31_9);
          let v31_12: Space = if (v31_10).is_empty() { Space::new() } else {
            let v33_6: Path = concat_path(&(v10_8_head),&(v30_6_head));
            let v33_11: Space = routine_11(c, &(v33_6), &(v30_6_tail), &(v0_57));
            drop(v33_6);
            compose(&(v31_10),&(v33_11))
          };
          drop(v31_10);
          let v31_13: Space = unite(&(v31_8),&(v31_12));
          v30_6.join_into((v31_13).clone());
        }
        drop(v30_6_cursor);
        compose(&(v29_5),&(v30_6))
      };
      drop(v29_5);
      let v29_8: Space = intersect(&(*CONSTANT_2),&(v29_2));
      drop(v29_2);
      let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
      drop(v29_8);
      let v29_11: Space = if (v29_9).is_empty() { Space::new() } else {
        let mut v34_10 = Space::new();
        let mut v34_10_cursor = (v10_8_tail).read_zipper();
        for v34_10_byte in v34_10_cursor.child_mask().iter() {
          v34_10_cursor.descend_to_byte(v34_10_byte);
          let v34_10_tail = v34_10_cursor.make_map();
          v34_10_cursor.ascend(1);
          let v34_10_head = Path::from_slice(&[v34_10_byte]);
          let v35_2: Space = singleton(&(v34_10_head));
          let v35_3: Space = intersect(&(*CONSTANT_2),&(v35_2));
          let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
          drop(v35_3);
          let v35_5: Space = subtract(&(*CONSTANT_1),&(v35_4));
          drop(v35_4);
          let v35_8: Space = if (v35_5).is_empty() { Space::new() } else {
            let v36_6: Path = concat_path(&(v10_8_head),&(v34_10_head));
            let v36_7: Space = routine_10(c, &(v36_6), &(v34_10_tail), &(v0_57));
            compose(&(v35_5),&(v36_7))
          };
          drop(v35_5);
          let v35_9: Space = intersect(&(*CONSTANT_2),&(v35_2));
          drop(v35_2);
          let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
          drop(v35_9);
          let v35_12: Space = if (v35_10).is_empty() { Space::new() } else {
            let v37_6: Path = concat_path(&(v10_8_head),&(v34_10_head));
            let v37_11: Space = routine_12(c, &(v37_6), &(v34_10_tail), &(v0_57));
            drop(v37_6);
            compose(&(v35_10),&(v37_11))
          };
          drop(v35_10);
          let v35_13: Space = unite(&(v35_8),&(v35_12));
          v34_10.join_into((v35_13).clone());
        }
        drop(v34_10_cursor);
        compose(&(v29_9),&(v34_10))
      };
      drop(v29_9);
      let v29_12: Space = unite(&(v29_7),&(v29_11));
      v10_8.join_into((v29_12).clone());
    }
    drop(v10_8_cursor);
    drop(v10_7);
    let v10_9: Space = unite(&(v10_5),&(v10_8));
    let v10_10: Space = unwrap(&(v10_6),&(*CONSTANT_0));
    let mut v10_11 = Space::new();
    let mut v10_11_cursor = (v10_10).read_zipper();
    for v10_11_byte in v10_11_cursor.child_mask().iter() {
      v10_11_cursor.descend_to_byte(v10_11_byte);
      let v10_11_tail = v10_11_cursor.make_map();
      v10_11_cursor.ascend(1);
      let v10_11_head = Path::from_slice(&[v10_11_byte]);
      let v38_2: Space = singleton(&(v10_11_head));
      let v38_3: Space = intersect(&(*CONSTANT_2),&(v38_2));
      let v38_4: Space = if has_head(&(v38_3)) { singleton(&[]) } else { Space::new() };
      drop(v38_3);
      let v38_5: Space = subtract(&(*CONSTANT_1),&(v38_4));
      drop(v38_4);
      let v38_7: Space = if (v38_5).is_empty() { Space::new() } else {
        let mut v39_6 = Space::new();
        let mut v39_6_cursor = (v10_11_tail).read_zipper();
        for v39_6_byte in v39_6_cursor.child_mask().iter() {
          v39_6_cursor.descend_to_byte(v39_6_byte);
          let v39_6_tail = v39_6_cursor.make_map();
          v39_6_cursor.ascend(1);
          let v39_6_head = Path::from_slice(&[v39_6_byte]);
          let v40_2: Space = singleton(&(v39_6_head));
          let v40_3: Space = intersect(&(*CONSTANT_2),&(v40_2));
          let v40_4: Space = if has_head(&(v40_3)) { singleton(&[]) } else { Space::new() };
          drop(v40_3);
          let v40_5: Space = subtract(&(*CONSTANT_1),&(v40_4));
          drop(v40_4);
          let v40_8: Space = if (v40_5).is_empty() { Space::new() } else {
            let v41_6: Path = concat_path(&(v10_11_head),&(v39_6_head));
            let v41_7: Space = routine_13(c, &(v41_6), &(v39_6_tail));
            compose(&(v40_5),&(v41_7))
          };
          drop(v40_5);
          let v40_9: Space = intersect(&(*CONSTANT_2),&(v40_2));
          drop(v40_2);
          let v40_10: Space = if has_head(&(v40_9)) { singleton(&[]) } else { Space::new() };
          drop(v40_9);
          let v40_12: Space = if (v40_10).is_empty() { Space::new() } else {
            let v42_6: Path = concat_path(&(v10_11_head),&(v39_6_head));
            let v42_11: Space = routine_14(c, &(v42_6), &(v39_6_tail));
            drop(v42_6);
            compose(&(v40_10),&(v42_11))
          };
          drop(v40_10);
          let v40_13: Space = unite(&(v40_8),&(v40_12));
          v39_6.join_into((v40_13).clone());
        }
        drop(v39_6_cursor);
        compose(&(v38_5),&(v39_6))
      };
      drop(v38_5);
      let v38_8: Space = intersect(&(*CONSTANT_2),&(v38_2));
      drop(v38_2);
      let v38_9: Space = if has_head(&(v38_8)) { singleton(&[]) } else { Space::new() };
      drop(v38_8);
      let v38_11: Space = if (v38_9).is_empty() { Space::new() } else {
        let mut v43_10 = Space::new();
        let mut v43_10_cursor = (v10_11_tail).read_zipper();
        for v43_10_byte in v43_10_cursor.child_mask().iter() {
          v43_10_cursor.descend_to_byte(v43_10_byte);
          let v43_10_tail = v43_10_cursor.make_map();
          v43_10_cursor.ascend(1);
          let v43_10_head = Path::from_slice(&[v43_10_byte]);
          let v44_2: Space = singleton(&(v43_10_head));
          let v44_3: Space = intersect(&(*CONSTANT_2),&(v44_2));
          let v44_4: Space = if has_head(&(v44_3)) { singleton(&[]) } else { Space::new() };
          drop(v44_3);
          let v44_5: Space = subtract(&(*CONSTANT_1),&(v44_4));
          drop(v44_4);
          let v44_8: Space = if (v44_5).is_empty() { Space::new() } else {
            let v45_6: Path = concat_path(&(v10_11_head),&(v43_10_head));
            let v45_7: Space = routine_13(c, &(v45_6), &(v43_10_tail));
            compose(&(v44_5),&(v45_7))
          };
          drop(v44_5);
          let v44_9: Space = intersect(&(*CONSTANT_2),&(v44_2));
          drop(v44_2);
          let v44_10: Space = if has_head(&(v44_9)) { singleton(&[]) } else { Space::new() };
          drop(v44_9);
          let v44_12: Space = if (v44_10).is_empty() { Space::new() } else {
            let v46_6: Path = concat_path(&(v10_11_head),&(v43_10_head));
            let v46_11: Space = routine_15(c, &(v46_6), &(v43_10_tail));
            drop(v46_6);
            compose(&(v44_10),&(v46_11))
          };
          drop(v44_10);
          let v44_13: Space = unite(&(v44_8),&(v44_12));
          v43_10.join_into((v44_13).clone());
        }
        drop(v43_10_cursor);
        compose(&(v38_9),&(v43_10))
      };
      drop(v38_9);
      let v38_12: Space = unite(&(v38_7),&(v38_11));
      v10_11.join_into((v38_12).clone());
    }
    drop(v10_11_cursor);
    drop(v10_10);
    let v10_12: Space = unite(&(v10_9),&(v10_11));
    let v10_13: Space = unwrap(&(v0_57),&(*CONSTANT_6));
    let v10_14: Space = subtract(&(v10_12),&(v10_13));
    drop(v10_13);
    let v10_15: Space = unwrap(&(v0_57),&(*CONSTANT_7));
    let v10_16: Space = subtract(&(v10_14),&(v10_15));
    drop(v10_15);
    let v10_17: Space = wrap(&(v10_16),&(*CONSTANT_6));
    let v10_18: Space = unite(&(v10_1),&(v10_6));
    drop(v10_1);
    drop(v10_6);
    let v10_19: Space = wrap(&(v10_18),&(*CONSTANT_4));
    drop(v10_18);
    let v10_20: Space = unite(&(v10_17),&(v10_19));
    drop(v10_19);
    let v10_21: Space = unite(&(v10_20),&(v0_57));
    let v0_57_next = unite(&v0_57,&(v10_21));
    if equal(&v0_57_next,&v0_57) { break; }
    v0_57 = v0_57_next;
  }
  let v0_58: Space = unwrap(&(v0_57),&(*CONSTANT_7));
  (v0_58).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v47_11 = Space::new();
  let mut v47_11_cursor = (*s0).read_zipper();
  for v47_11_byte in v47_11_cursor.child_mask().iter() {
    v47_11_cursor.descend_to_byte(v47_11_byte);
    let v47_11_tail = v47_11_cursor.make_map();
    v47_11_cursor.ascend(1);
    let v47_11_head = Path::from_slice(&[v47_11_byte]);
    let v48_2: Space = singleton(&(v47_11_head));
    let v48_3: Space = intersect(&(*CONSTANT_2),&(v48_2));
    let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
    drop(v48_3);
    let v48_5: Space = subtract(&(*CONSTANT_1),&(v48_4));
    drop(v48_4);
    let v48_8: Space = if (v48_5).is_empty() { Space::new() } else {
      let v49_6: Path = concat_path(&(*p0),&(v47_11_head));
      let mut v49_7 = Space::new();
      let mut v49_7_cursor = (v47_11_tail).read_zipper();
      for v49_7_byte in v49_7_cursor.child_mask().iter() {
        v49_7_cursor.descend_to_byte(v49_7_byte);
        let v49_7_tail = v49_7_cursor.make_map();
        v49_7_cursor.ascend(1);
        let v49_7_head = Path::from_slice(&[v49_7_byte]);
        let v50_2: Space = singleton(&(v49_7_head));
        let v50_3: Space = intersect(&(*CONSTANT_2),&(v50_2));
        let v50_4: Space = if has_head(&(v50_3)) { singleton(&[]) } else { Space::new() };
        drop(v50_3);
        let v50_5: Space = subtract(&(*CONSTANT_1),&(v50_4));
        drop(v50_4);
        let v50_8: Space = if (v50_5).is_empty() { Space::new() } else {
          let v51_6: Path = concat_path(&(v49_6),&(v49_7_head));
          let v51_7: Space = routine_16(c, &(v51_6), &(v49_7_tail));
          compose(&(v50_5),&(v51_7))
        };
        drop(v50_5);
        let v50_9: Space = intersect(&(*CONSTANT_2),&(v50_2));
        drop(v50_2);
        let v50_10: Space = if has_head(&(v50_9)) { singleton(&[]) } else { Space::new() };
        drop(v50_9);
        let v50_12: Space = if (v50_10).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v49_6),&(v49_7_head));
          let v52_11: Space = routine_17(c, &(v52_6), &(v49_7_tail));
          drop(v52_6);
          compose(&(v50_10),&(v52_11))
        };
        drop(v50_10);
        let v50_13: Space = unite(&(v50_8),&(v50_12));
        v49_7.join_into((v50_13).clone());
      }
      drop(v49_7_cursor);
      compose(&(v48_5),&(v49_7))
    };
    drop(v48_5);
    let v48_9: Space = intersect(&(*CONSTANT_2),&(v48_2));
    drop(v48_2);
    let v48_10: Space = if has_head(&(v48_9)) { singleton(&[]) } else { Space::new() };
    drop(v48_9);
    let v48_12: Space = if (v48_10).is_empty() { Space::new() } else {
      let v53_6: Path = concat_path(&(*p0),&(v47_11_head));
      let mut v53_11 = Space::new();
      let mut v53_11_cursor = (v47_11_tail).read_zipper();
      for v53_11_byte in v53_11_cursor.child_mask().iter() {
        v53_11_cursor.descend_to_byte(v53_11_byte);
        let v53_11_tail = v53_11_cursor.make_map();
        v53_11_cursor.ascend(1);
        let v53_11_head = Path::from_slice(&[v53_11_byte]);
        let v54_2: Space = singleton(&(v53_11_head));
        let v54_3: Space = intersect(&(*CONSTANT_2),&(v54_2));
        let v54_4: Space = if has_head(&(v54_3)) { singleton(&[]) } else { Space::new() };
        drop(v54_3);
        let v54_5: Space = subtract(&(*CONSTANT_1),&(v54_4));
        drop(v54_4);
        let v54_8: Space = if (v54_5).is_empty() { Space::new() } else {
          let v55_6: Path = concat_path(&(v53_6),&(v53_11_head));
          let v55_7: Space = routine_16(c, &(v55_6), &(v53_11_tail));
          compose(&(v54_5),&(v55_7))
        };
        drop(v54_5);
        let v54_9: Space = intersect(&(*CONSTANT_2),&(v54_2));
        drop(v54_2);
        let v54_10: Space = if has_head(&(v54_9)) { singleton(&[]) } else { Space::new() };
        drop(v54_9);
        let v54_12: Space = if (v54_10).is_empty() { Space::new() } else {
          let v56_6: Path = concat_path(&(v53_6),&(v53_11_head));
          let v56_11: Space = routine_3(c, &(v56_6), &(v53_11_tail));
          drop(v56_6);
          compose(&(v54_10),&(v56_11))
        };
        drop(v54_10);
        let v54_13: Space = unite(&(v54_8),&(v54_12));
        v53_11.join_into((v54_13).clone());
      }
      drop(v53_11_cursor);
      drop(v53_6);
      compose(&(v48_10),&(v53_11))
    };
    drop(v48_10);
    let v48_13: Space = unite(&(v48_8),&(v48_12));
    v47_11.join_into((v48_13).clone());
  }
  drop(v47_11_cursor);
  (v47_11).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v57_11 = Space::new();
  let mut v57_11_cursor = (*s0).read_zipper();
  for v57_11_byte in v57_11_cursor.child_mask().iter() {
    v57_11_cursor.descend_to_byte(v57_11_byte);
    let v57_11_tail = v57_11_cursor.make_map();
    v57_11_cursor.ascend(1);
    let v57_11_head = Path::from_slice(&[v57_11_byte]);
    let v58_2: Space = singleton(&(v57_11_head));
    let v58_3: Space = intersect(&(*CONSTANT_2),&(v58_2));
    let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
    drop(v58_3);
    let v58_5: Space = subtract(&(*CONSTANT_1),&(v58_4));
    drop(v58_4);
    let v58_8: Space = if (v58_5).is_empty() { Space::new() } else {
      let v59_6: Path = concat_path(&(*p0),&(v57_11_head));
      let mut v59_7 = Space::new();
      let mut v59_7_cursor = (v57_11_tail).read_zipper();
      for v59_7_byte in v59_7_cursor.child_mask().iter() {
        v59_7_cursor.descend_to_byte(v59_7_byte);
        let v59_7_tail = v59_7_cursor.make_map();
        v59_7_cursor.ascend(1);
        let v59_7_head = Path::from_slice(&[v59_7_byte]);
        let v60_2: Space = singleton(&(v59_7_head));
        let v60_3: Space = intersect(&(*CONSTANT_2),&(v60_2));
        let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
        drop(v60_3);
        let v60_5: Space = subtract(&(*CONSTANT_1),&(v60_4));
        drop(v60_4);
        let v60_8: Space = if (v60_5).is_empty() { Space::new() } else {
          let v61_6: Path = concat_path(&(v59_6),&(v59_7_head));
          let v61_7: Space = routine_16(c, &(v61_6), &(v59_7_tail));
          compose(&(v60_5),&(v61_7))
        };
        drop(v60_5);
        let v60_9: Space = intersect(&(*CONSTANT_2),&(v60_2));
        drop(v60_2);
        let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
        drop(v60_9);
        let v60_12: Space = if (v60_10).is_empty() { Space::new() } else {
          let v62_6: Path = concat_path(&(v59_6),&(v59_7_head));
          let v62_11: Space = routine_17(c, &(v62_6), &(v59_7_tail));
          drop(v62_6);
          compose(&(v60_10),&(v62_11))
        };
        drop(v60_10);
        let v60_13: Space = unite(&(v60_8),&(v60_12));
        v59_7.join_into((v60_13).clone());
      }
      drop(v59_7_cursor);
      compose(&(v58_5),&(v59_7))
    };
    drop(v58_5);
    let v58_9: Space = intersect(&(*CONSTANT_2),&(v58_2));
    drop(v58_2);
    let v58_10: Space = if has_head(&(v58_9)) { singleton(&[]) } else { Space::new() };
    drop(v58_9);
    let v58_12: Space = if (v58_10).is_empty() { Space::new() } else {
      let v63_6: Path = concat_path(&(*p0),&(v57_11_head));
      let mut v63_11 = Space::new();
      let mut v63_11_cursor = (v57_11_tail).read_zipper();
      for v63_11_byte in v63_11_cursor.child_mask().iter() {
        v63_11_cursor.descend_to_byte(v63_11_byte);
        let v63_11_tail = v63_11_cursor.make_map();
        v63_11_cursor.ascend(1);
        let v63_11_head = Path::from_slice(&[v63_11_byte]);
        let v64_2: Space = singleton(&(v63_11_head));
        let v64_3: Space = intersect(&(*CONSTANT_2),&(v64_2));
        let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
        drop(v64_3);
        let v64_5: Space = subtract(&(*CONSTANT_1),&(v64_4));
        drop(v64_4);
        let v64_7: Space = if (v64_5).is_empty() { Space::new() } else {
          let v65_6: Space = routine_18(c, &(v63_11_head), &(v63_6), &(v63_11_tail));
          compose(&(v64_5),&(v65_6))
        };
        drop(v64_5);
        let v64_8: Space = intersect(&(*CONSTANT_2),&(v64_2));
        drop(v64_2);
        let v64_9: Space = if has_head(&(v64_8)) { singleton(&[]) } else { Space::new() };
        drop(v64_8);
        let v64_11: Space = if (v64_9).is_empty() { Space::new() } else {
          let v66_10: Space = routine_19(c, &(v63_11_head), &(v63_6), &(v63_11_tail));
          compose(&(v64_9),&(v66_10))
        };
        drop(v64_9);
        let v64_12: Space = unite(&(v64_7),&(v64_11));
        v63_11.join_into((v64_12).clone());
      }
      drop(v63_11_cursor);
      drop(v63_6);
      compose(&(v58_10),&(v63_11))
    };
    drop(v58_10);
    let v58_13: Space = unite(&(v58_8),&(v58_12));
    v57_11.join_into((v58_13).clone());
  }
  drop(v57_11_cursor);
  (v57_11).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v67_11 = Space::new();
  let mut v67_11_cursor = (*s0).read_zipper();
  for v67_11_byte in v67_11_cursor.child_mask().iter() {
    v67_11_cursor.descend_to_byte(v67_11_byte);
    let v67_11_tail = v67_11_cursor.make_map();
    v67_11_cursor.ascend(1);
    let v67_11_head = Path::from_slice(&[v67_11_byte]);
    let v68_2: Space = singleton(&(v67_11_head));
    let v68_3: Space = intersect(&(*CONSTANT_2),&(v68_2));
    let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
    drop(v68_3);
    let v68_5: Space = subtract(&(*CONSTANT_1),&(v68_4));
    drop(v68_4);
    let v68_7: Space = if (v68_5).is_empty() { Space::new() } else {
      let mut v69_6 = Space::new();
      let mut v69_6_cursor = (v67_11_tail).read_zipper();
      for v69_6_byte in v69_6_cursor.child_mask().iter() {
        v69_6_cursor.descend_to_byte(v69_6_byte);
        let v69_6_tail = v69_6_cursor.make_map();
        v69_6_cursor.ascend(1);
        let v69_6_head = Path::from_slice(&[v69_6_byte]);
        let v70_2: Space = singleton(&(v69_6_head));
        let v70_3: Space = intersect(&(*CONSTANT_2),&(v70_2));
        let v70_4: Space = if has_head(&(v70_3)) { singleton(&[]) } else { Space::new() };
        drop(v70_3);
        let v70_5: Space = subtract(&(*CONSTANT_1),&(v70_4));
        drop(v70_4);
        let v70_8: Space = if (v70_5).is_empty() { Space::new() } else {
          let v71_6: Path = concat_path(&(v67_11_head),&(v69_6_head));
          let v71_7: Space = routine_20(c, &(v71_6), &(*p0), &(v69_6_tail));
          compose(&(v70_5),&(v71_7))
        };
        drop(v70_5);
        let v70_9: Space = intersect(&(*CONSTANT_2),&(v70_2));
        drop(v70_2);
        let v70_10: Space = if has_head(&(v70_9)) { singleton(&[]) } else { Space::new() };
        drop(v70_9);
        let v70_12: Space = if (v70_10).is_empty() { Space::new() } else {
          let v72_6: Path = concat_path(&(v67_11_head),&(v69_6_head));
          let v72_11: Space = routine_21(c, &(v72_6), &(*p0), &(v69_6_tail));
          drop(v72_6);
          compose(&(v70_10),&(v72_11))
        };
        drop(v70_10);
        let v70_13: Space = unite(&(v70_8),&(v70_12));
        v69_6.join_into((v70_13).clone());
      }
      drop(v69_6_cursor);
      compose(&(v68_5),&(v69_6))
    };
    drop(v68_5);
    let v68_8: Space = intersect(&(*CONSTANT_2),&(v68_2));
    drop(v68_2);
    let v68_9: Space = if has_head(&(v68_8)) { singleton(&[]) } else { Space::new() };
    drop(v68_8);
    let v68_11: Space = if (v68_9).is_empty() { Space::new() } else {
      let mut v73_10 = Space::new();
      let mut v73_10_cursor = (v67_11_tail).read_zipper();
      for v73_10_byte in v73_10_cursor.child_mask().iter() {
        v73_10_cursor.descend_to_byte(v73_10_byte);
        let v73_10_tail = v73_10_cursor.make_map();
        v73_10_cursor.ascend(1);
        let v73_10_head = Path::from_slice(&[v73_10_byte]);
        let v74_2: Space = singleton(&(v73_10_head));
        let v74_3: Space = intersect(&(*CONSTANT_2),&(v74_2));
        let v74_4: Space = if has_head(&(v74_3)) { singleton(&[]) } else { Space::new() };
        drop(v74_3);
        let v74_5: Space = subtract(&(*CONSTANT_1),&(v74_4));
        drop(v74_4);
        let v74_8: Space = if (v74_5).is_empty() { Space::new() } else {
          let v75_6: Path = concat_path(&(v67_11_head),&(v73_10_head));
          let v75_7: Space = routine_20(c, &(v75_6), &(*p0), &(v73_10_tail));
          compose(&(v74_5),&(v75_7))
        };
        drop(v74_5);
        let v74_9: Space = intersect(&(*CONSTANT_2),&(v74_2));
        drop(v74_2);
        let v74_10: Space = if has_head(&(v74_9)) { singleton(&[]) } else { Space::new() };
        drop(v74_9);
        let v74_12: Space = if (v74_10).is_empty() { Space::new() } else {
          let v76_6: Path = concat_path(&(v67_11_head),&(v73_10_head));
          let v76_11: Space = routine_22(c, &(v76_6), &(*p0), &(v73_10_tail));
          drop(v76_6);
          compose(&(v74_10),&(v76_11))
        };
        drop(v74_10);
        let v74_13: Space = unite(&(v74_8),&(v74_12));
        v73_10.join_into((v74_13).clone());
      }
      drop(v73_10_cursor);
      compose(&(v68_9),&(v73_10))
    };
    drop(v68_9);
    let v68_12: Space = unite(&(v68_7),&(v68_11));
    v67_11.join_into((v68_12).clone());
  }
  drop(v67_11_cursor);
  (v67_11).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v77_12 = Space::new();
  let mut v77_12_cursor = (*s0).read_zipper();
  for v77_12_byte in v77_12_cursor.child_mask().iter() {
    v77_12_cursor.descend_to_byte(v77_12_byte);
    let v77_12_tail = v77_12_cursor.make_map();
    v77_12_cursor.ascend(1);
    let v77_12_head = Path::from_slice(&[v77_12_byte]);
    let v78_2: Space = singleton(&(v77_12_head));
    let v78_3: Space = intersect(&(*CONSTANT_2),&(v78_2));
    let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
    drop(v78_3);
    let v78_5: Space = subtract(&(*CONSTANT_1),&(v78_4));
    drop(v78_4);
    let v78_8: Space = if (v78_5).is_empty() { Space::new() } else {
      let v79_6: Path = concat_path(&(*p0),&(v77_12_head));
      let mut v79_7 = Space::new();
      let mut v79_7_cursor = (v77_12_tail).read_zipper();
      for v79_7_byte in v79_7_cursor.child_mask().iter() {
        v79_7_cursor.descend_to_byte(v79_7_byte);
        let v79_7_tail = v79_7_cursor.make_map();
        v79_7_cursor.ascend(1);
        let v79_7_head = Path::from_slice(&[v79_7_byte]);
        let v80_2: Space = singleton(&(v79_7_head));
        let v80_3: Space = intersect(&(*CONSTANT_2),&(v80_2));
        let v80_4: Space = if has_head(&(v80_3)) { singleton(&[]) } else { Space::new() };
        drop(v80_3);
        let v80_5: Space = subtract(&(*CONSTANT_1),&(v80_4));
        drop(v80_4);
        let v80_8: Space = if (v80_5).is_empty() { Space::new() } else {
          let v81_6: Path = concat_path(&(v79_6),&(v79_7_head));
          let v81_7: Space = routine_23(c, &(v81_6), &(v79_7_tail), &(*s1));
          compose(&(v80_5),&(v81_7))
        };
        drop(v80_5);
        let v80_9: Space = intersect(&(*CONSTANT_2),&(v80_2));
        drop(v80_2);
        let v80_10: Space = if has_head(&(v80_9)) { singleton(&[]) } else { Space::new() };
        drop(v80_9);
        let v80_12: Space = if (v80_10).is_empty() { Space::new() } else {
          let v82_6: Path = concat_path(&(v79_6),&(v79_7_head));
          let v82_11: Space = routine_24(c, &(v82_6), &(v79_7_tail), &(*s1));
          drop(v82_6);
          compose(&(v80_10),&(v82_11))
        };
        drop(v80_10);
        let v80_13: Space = unite(&(v80_8),&(v80_12));
        v79_7.join_into((v80_13).clone());
      }
      drop(v79_7_cursor);
      compose(&(v78_5),&(v79_7))
    };
    drop(v78_5);
    let v78_9: Space = intersect(&(*CONSTANT_2),&(v78_2));
    drop(v78_2);
    let v78_10: Space = if has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
    drop(v78_9);
    let v78_12: Space = if (v78_10).is_empty() { Space::new() } else {
      let v83_6: Path = concat_path(&(*p0),&(v77_12_head));
      let mut v83_11 = Space::new();
      let mut v83_11_cursor = (v77_12_tail).read_zipper();
      for v83_11_byte in v83_11_cursor.child_mask().iter() {
        v83_11_cursor.descend_to_byte(v83_11_byte);
        let v83_11_tail = v83_11_cursor.make_map();
        v83_11_cursor.ascend(1);
        let v83_11_head = Path::from_slice(&[v83_11_byte]);
        let v84_2: Space = singleton(&(v83_11_head));
        let v84_3: Space = intersect(&(*CONSTANT_2),&(v84_2));
        let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
        drop(v84_3);
        let v84_5: Space = subtract(&(*CONSTANT_1),&(v84_4));
        drop(v84_4);
        let v84_8: Space = if (v84_5).is_empty() { Space::new() } else {
          let v85_6: Path = concat_path(&(v83_6),&(v83_11_head));
          let v85_7: Space = routine_23(c, &(v85_6), &(v83_11_tail), &(*s1));
          compose(&(v84_5),&(v85_7))
        };
        drop(v84_5);
        let v84_9: Space = intersect(&(*CONSTANT_2),&(v84_2));
        drop(v84_2);
        let v84_10: Space = if has_head(&(v84_9)) { singleton(&[]) } else { Space::new() };
        drop(v84_9);
        let v84_12: Space = if (v84_10).is_empty() { Space::new() } else {
          let v86_6: Path = concat_path(&(v83_6),&(v83_11_head));
          let v86_11: Space = routine_6(c, &(v86_6), &(v83_11_tail), &(*s1));
          drop(v86_6);
          compose(&(v84_10),&(v86_11))
        };
        drop(v84_10);
        let v84_13: Space = unite(&(v84_8),&(v84_12));
        v83_11.join_into((v84_13).clone());
      }
      drop(v83_11_cursor);
      drop(v83_6);
      compose(&(v78_10),&(v83_11))
    };
    drop(v78_10);
    let v78_13: Space = unite(&(v78_8),&(v78_12));
    v77_12.join_into((v78_13).clone());
  }
  drop(v77_12_cursor);
  (v77_12).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v87_12 = Space::new();
  let mut v87_12_cursor = (*s0).read_zipper();
  for v87_12_byte in v87_12_cursor.child_mask().iter() {
    v87_12_cursor.descend_to_byte(v87_12_byte);
    let v87_12_tail = v87_12_cursor.make_map();
    v87_12_cursor.ascend(1);
    let v87_12_head = Path::from_slice(&[v87_12_byte]);
    let v88_2: Space = singleton(&(v87_12_head));
    let v88_3: Space = intersect(&(*CONSTANT_2),&(v88_2));
    let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
    drop(v88_3);
    let v88_5: Space = subtract(&(*CONSTANT_1),&(v88_4));
    drop(v88_4);
    let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
      let v89_6: Path = concat_path(&(*p0),&(v87_12_head));
      let mut v89_7 = Space::new();
      let mut v89_7_cursor = (v87_12_tail).read_zipper();
      for v89_7_byte in v89_7_cursor.child_mask().iter() {
        v89_7_cursor.descend_to_byte(v89_7_byte);
        let v89_7_tail = v89_7_cursor.make_map();
        v89_7_cursor.ascend(1);
        let v89_7_head = Path::from_slice(&[v89_7_byte]);
        let v90_2: Space = singleton(&(v89_7_head));
        let v90_3: Space = intersect(&(*CONSTANT_2),&(v90_2));
        let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
        drop(v90_3);
        let v90_5: Space = subtract(&(*CONSTANT_1),&(v90_4));
        drop(v90_4);
        let v90_8: Space = if (v90_5).is_empty() { Space::new() } else {
          let v91_6: Path = concat_path(&(v89_6),&(v89_7_head));
          let v91_7: Space = routine_23(c, &(v91_6), &(v89_7_tail), &(*s1));
          compose(&(v90_5),&(v91_7))
        };
        drop(v90_5);
        let v90_9: Space = intersect(&(*CONSTANT_2),&(v90_2));
        drop(v90_2);
        let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
        drop(v90_9);
        let v90_12: Space = if (v90_10).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v89_6),&(v89_7_head));
          let v92_11: Space = routine_24(c, &(v92_6), &(v89_7_tail), &(*s1));
          drop(v92_6);
          compose(&(v90_10),&(v92_11))
        };
        drop(v90_10);
        let v90_13: Space = unite(&(v90_8),&(v90_12));
        v89_7.join_into((v90_13).clone());
      }
      drop(v89_7_cursor);
      compose(&(v88_5),&(v89_7))
    };
    drop(v88_5);
    let v88_9: Space = intersect(&(*CONSTANT_2),&(v88_2));
    drop(v88_2);
    let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
    drop(v88_9);
    let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
      let v93_6: Path = concat_path(&(*p0),&(v87_12_head));
      let mut v93_11 = Space::new();
      let mut v93_11_cursor = (v87_12_tail).read_zipper();
      for v93_11_byte in v93_11_cursor.child_mask().iter() {
        v93_11_cursor.descend_to_byte(v93_11_byte);
        let v93_11_tail = v93_11_cursor.make_map();
        v93_11_cursor.ascend(1);
        let v93_11_head = Path::from_slice(&[v93_11_byte]);
        let v94_2: Space = singleton(&(v93_11_head));
        let v94_3: Space = intersect(&(*CONSTANT_2),&(v94_2));
        let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
        drop(v94_3);
        let v94_5: Space = subtract(&(*CONSTANT_1),&(v94_4));
        drop(v94_4);
        let v94_7: Space = if (v94_5).is_empty() { Space::new() } else {
          let v95_6: Space = routine_25(c, &(v93_11_head), &(v93_6), &(v93_11_tail), &(*s1));
          compose(&(v94_5),&(v95_6))
        };
        drop(v94_5);
        let v94_8: Space = intersect(&(*CONSTANT_2),&(v94_2));
        drop(v94_2);
        let v94_9: Space = if has_head(&(v94_8)) { singleton(&[]) } else { Space::new() };
        drop(v94_8);
        let v94_11: Space = if (v94_9).is_empty() { Space::new() } else {
          let v96_10: Space = routine_26(c, &(v93_11_head), &(v93_6), &(v93_11_tail), &(*s1));
          compose(&(v94_9),&(v96_10))
        };
        drop(v94_9);
        let v94_12: Space = unite(&(v94_7),&(v94_11));
        v93_11.join_into((v94_12).clone());
      }
      drop(v93_11_cursor);
      drop(v93_6);
      compose(&(v88_10),&(v93_11))
    };
    drop(v88_10);
    let v88_13: Space = unite(&(v88_8),&(v88_12));
    v87_12.join_into((v88_13).clone());
  }
  drop(v87_12_cursor);
  (v87_12).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v97_12 = Space::new();
  let mut v97_12_cursor = (*s0).read_zipper();
  for v97_12_byte in v97_12_cursor.child_mask().iter() {
    v97_12_cursor.descend_to_byte(v97_12_byte);
    let v97_12_tail = v97_12_cursor.make_map();
    v97_12_cursor.ascend(1);
    let v97_12_head = Path::from_slice(&[v97_12_byte]);
    let v98_2: Space = singleton(&(v97_12_head));
    let v98_3: Space = intersect(&(*CONSTANT_2),&(v98_2));
    let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
    drop(v98_3);
    let v98_5: Space = subtract(&(*CONSTANT_1),&(v98_4));
    drop(v98_4);
    let v98_7: Space = if (v98_5).is_empty() { Space::new() } else {
      let mut v99_6 = Space::new();
      let mut v99_6_cursor = (v97_12_tail).read_zipper();
      for v99_6_byte in v99_6_cursor.child_mask().iter() {
        v99_6_cursor.descend_to_byte(v99_6_byte);
        let v99_6_tail = v99_6_cursor.make_map();
        v99_6_cursor.ascend(1);
        let v99_6_head = Path::from_slice(&[v99_6_byte]);
        let v100_2: Space = singleton(&(v99_6_head));
        let v100_3: Space = intersect(&(*CONSTANT_2),&(v100_2));
        let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
        drop(v100_3);
        let v100_5: Space = subtract(&(*CONSTANT_1),&(v100_4));
        drop(v100_4);
        let v100_8: Space = if (v100_5).is_empty() { Space::new() } else {
          let v101_6: Path = concat_path(&(v97_12_head),&(v99_6_head));
          let v101_7: Space = routine_27(c, &(v101_6), &(*p0), &(v99_6_tail), &(*s1));
          compose(&(v100_5),&(v101_7))
        };
        drop(v100_5);
        let v100_9: Space = intersect(&(*CONSTANT_2),&(v100_2));
        drop(v100_2);
        let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
        drop(v100_9);
        let v100_12: Space = if (v100_10).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v97_12_head),&(v99_6_head));
          let v102_11: Space = routine_28(c, &(v102_6), &(*p0), &(v99_6_tail), &(*s1));
          drop(v102_6);
          compose(&(v100_10),&(v102_11))
        };
        drop(v100_10);
        let v100_13: Space = unite(&(v100_8),&(v100_12));
        v99_6.join_into((v100_13).clone());
      }
      drop(v99_6_cursor);
      compose(&(v98_5),&(v99_6))
    };
    drop(v98_5);
    let v98_8: Space = intersect(&(*CONSTANT_2),&(v98_2));
    drop(v98_2);
    let v98_9: Space = if has_head(&(v98_8)) { singleton(&[]) } else { Space::new() };
    drop(v98_8);
    let v98_11: Space = if (v98_9).is_empty() { Space::new() } else {
      let mut v103_10 = Space::new();
      let mut v103_10_cursor = (v97_12_tail).read_zipper();
      for v103_10_byte in v103_10_cursor.child_mask().iter() {
        v103_10_cursor.descend_to_byte(v103_10_byte);
        let v103_10_tail = v103_10_cursor.make_map();
        v103_10_cursor.ascend(1);
        let v103_10_head = Path::from_slice(&[v103_10_byte]);
        let v104_2: Space = singleton(&(v103_10_head));
        let v104_3: Space = intersect(&(*CONSTANT_2),&(v104_2));
        let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
        drop(v104_3);
        let v104_5: Space = subtract(&(*CONSTANT_1),&(v104_4));
        drop(v104_4);
        let v104_8: Space = if (v104_5).is_empty() { Space::new() } else {
          let v105_6: Path = concat_path(&(v97_12_head),&(v103_10_head));
          let v105_7: Space = routine_27(c, &(v105_6), &(*p0), &(v103_10_tail), &(*s1));
          compose(&(v104_5),&(v105_7))
        };
        drop(v104_5);
        let v104_9: Space = intersect(&(*CONSTANT_2),&(v104_2));
        drop(v104_2);
        let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
        drop(v104_9);
        let v104_12: Space = if (v104_10).is_empty() { Space::new() } else {
          let v106_6: Path = concat_path(&(v97_12_head),&(v103_10_head));
          let v106_11: Space = routine_29(c, &(v106_6), &(*p0), &(v103_10_tail), &(*s1));
          drop(v106_6);
          compose(&(v104_10),&(v106_11))
        };
        drop(v104_10);
        let v104_13: Space = unite(&(v104_8),&(v104_12));
        v103_10.join_into((v104_13).clone());
      }
      drop(v103_10_cursor);
      compose(&(v98_9),&(v103_10))
    };
    drop(v98_9);
    let v98_12: Space = unite(&(v98_7),&(v98_11));
    v97_12.join_into((v98_12).clone());
  }
  drop(v97_12_cursor);
  (v97_12).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v107_12 = Space::new();
  let mut v107_12_cursor = (*s0).read_zipper();
  for v107_12_byte in v107_12_cursor.child_mask().iter() {
    v107_12_cursor.descend_to_byte(v107_12_byte);
    let v107_12_tail = v107_12_cursor.make_map();
    v107_12_cursor.ascend(1);
    let v107_12_head = Path::from_slice(&[v107_12_byte]);
    let v108_2: Space = singleton(&(v107_12_head));
    let v108_3: Space = intersect(&(*CONSTANT_2),&(v108_2));
    let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
    drop(v108_3);
    let v108_5: Space = subtract(&(*CONSTANT_1),&(v108_4));
    drop(v108_4);
    let v108_8: Space = if (v108_5).is_empty() { Space::new() } else {
      let v109_6: Path = concat_path(&(*p0),&(v107_12_head));
      let mut v109_7 = Space::new();
      let mut v109_7_cursor = (v107_12_tail).read_zipper();
      for v109_7_byte in v109_7_cursor.child_mask().iter() {
        v109_7_cursor.descend_to_byte(v109_7_byte);
        let v109_7_tail = v109_7_cursor.make_map();
        v109_7_cursor.ascend(1);
        let v109_7_head = Path::from_slice(&[v109_7_byte]);
        let v110_2: Space = singleton(&(v109_7_head));
        let v110_3: Space = intersect(&(*CONSTANT_2),&(v110_2));
        let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
        drop(v110_3);
        let v110_5: Space = subtract(&(*CONSTANT_1),&(v110_4));
        drop(v110_4);
        let v110_8: Space = if (v110_5).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v109_6),&(v109_7_head));
          let v111_7: Space = routine_30(c, &(v111_6), &(v109_7_tail), &(*s1));
          compose(&(v110_5),&(v111_7))
        };
        drop(v110_5);
        let v110_9: Space = intersect(&(*CONSTANT_2),&(v110_2));
        drop(v110_2);
        let v110_10: Space = if has_head(&(v110_9)) { singleton(&[]) } else { Space::new() };
        drop(v110_9);
        let v110_12: Space = if (v110_10).is_empty() { Space::new() } else {
          let v112_6: Path = concat_path(&(v109_6),&(v109_7_head));
          let v112_11: Space = routine_31(c, &(v112_6), &(v109_7_tail), &(*s1));
          drop(v112_6);
          compose(&(v110_10),&(v112_11))
        };
        drop(v110_10);
        let v110_13: Space = unite(&(v110_8),&(v110_12));
        v109_7.join_into((v110_13).clone());
      }
      drop(v109_7_cursor);
      compose(&(v108_5),&(v109_7))
    };
    drop(v108_5);
    let v108_9: Space = intersect(&(*CONSTANT_2),&(v108_2));
    drop(v108_2);
    let v108_10: Space = if has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
    drop(v108_9);
    let v108_12: Space = if (v108_10).is_empty() { Space::new() } else {
      let v113_6: Path = concat_path(&(*p0),&(v107_12_head));
      let mut v113_11 = Space::new();
      let mut v113_11_cursor = (v107_12_tail).read_zipper();
      for v113_11_byte in v113_11_cursor.child_mask().iter() {
        v113_11_cursor.descend_to_byte(v113_11_byte);
        let v113_11_tail = v113_11_cursor.make_map();
        v113_11_cursor.ascend(1);
        let v113_11_head = Path::from_slice(&[v113_11_byte]);
        let v114_2: Space = singleton(&(v113_11_head));
        let v114_3: Space = intersect(&(*CONSTANT_2),&(v114_2));
        let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
        drop(v114_3);
        let v114_5: Space = subtract(&(*CONSTANT_1),&(v114_4));
        drop(v114_4);
        let v114_8: Space = if (v114_5).is_empty() { Space::new() } else {
          let v115_6: Path = concat_path(&(v113_6),&(v113_11_head));
          let v115_7: Space = routine_30(c, &(v115_6), &(v113_11_tail), &(*s1));
          compose(&(v114_5),&(v115_7))
        };
        drop(v114_5);
        let v114_9: Space = intersect(&(*CONSTANT_2),&(v114_2));
        drop(v114_2);
        let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
        drop(v114_9);
        let v114_12: Space = if (v114_10).is_empty() { Space::new() } else {
          let v116_6: Path = concat_path(&(v113_6),&(v113_11_head));
          let v116_11: Space = routine_9(c, &(v116_6), &(v113_11_tail), &(*s1));
          drop(v116_6);
          compose(&(v114_10),&(v116_11))
        };
        drop(v114_10);
        let v114_13: Space = unite(&(v114_8),&(v114_12));
        v113_11.join_into((v114_13).clone());
      }
      drop(v113_11_cursor);
      drop(v113_6);
      compose(&(v108_10),&(v113_11))
    };
    drop(v108_10);
    let v108_13: Space = unite(&(v108_8),&(v108_12));
    v107_12.join_into((v108_13).clone());
  }
  drop(v107_12_cursor);
  (v107_12).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v117_12 = Space::new();
  let mut v117_12_cursor = (*s0).read_zipper();
  for v117_12_byte in v117_12_cursor.child_mask().iter() {
    v117_12_cursor.descend_to_byte(v117_12_byte);
    let v117_12_tail = v117_12_cursor.make_map();
    v117_12_cursor.ascend(1);
    let v117_12_head = Path::from_slice(&[v117_12_byte]);
    let v118_2: Space = singleton(&(v117_12_head));
    let v118_3: Space = intersect(&(*CONSTANT_2),&(v118_2));
    let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
    drop(v118_3);
    let v118_5: Space = subtract(&(*CONSTANT_1),&(v118_4));
    drop(v118_4);
    let v118_8: Space = if (v118_5).is_empty() { Space::new() } else {
      let v119_6: Path = concat_path(&(*p0),&(v117_12_head));
      let mut v119_7 = Space::new();
      let mut v119_7_cursor = (v117_12_tail).read_zipper();
      for v119_7_byte in v119_7_cursor.child_mask().iter() {
        v119_7_cursor.descend_to_byte(v119_7_byte);
        let v119_7_tail = v119_7_cursor.make_map();
        v119_7_cursor.ascend(1);
        let v119_7_head = Path::from_slice(&[v119_7_byte]);
        let v120_2: Space = singleton(&(v119_7_head));
        let v120_3: Space = intersect(&(*CONSTANT_2),&(v120_2));
        let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
        drop(v120_3);
        let v120_5: Space = subtract(&(*CONSTANT_1),&(v120_4));
        drop(v120_4);
        let v120_8: Space = if (v120_5).is_empty() { Space::new() } else {
          let v121_6: Path = concat_path(&(v119_6),&(v119_7_head));
          let v121_7: Space = routine_30(c, &(v121_6), &(v119_7_tail), &(*s1));
          compose(&(v120_5),&(v121_7))
        };
        drop(v120_5);
        let v120_9: Space = intersect(&(*CONSTANT_2),&(v120_2));
        drop(v120_2);
        let v120_10: Space = if has_head(&(v120_9)) { singleton(&[]) } else { Space::new() };
        drop(v120_9);
        let v120_12: Space = if (v120_10).is_empty() { Space::new() } else {
          let v122_6: Path = concat_path(&(v119_6),&(v119_7_head));
          let v122_11: Space = routine_31(c, &(v122_6), &(v119_7_tail), &(*s1));
          drop(v122_6);
          compose(&(v120_10),&(v122_11))
        };
        drop(v120_10);
        let v120_13: Space = unite(&(v120_8),&(v120_12));
        v119_7.join_into((v120_13).clone());
      }
      drop(v119_7_cursor);
      compose(&(v118_5),&(v119_7))
    };
    drop(v118_5);
    let v118_9: Space = intersect(&(*CONSTANT_2),&(v118_2));
    drop(v118_2);
    let v118_10: Space = if has_head(&(v118_9)) { singleton(&[]) } else { Space::new() };
    drop(v118_9);
    let v118_12: Space = if (v118_10).is_empty() { Space::new() } else {
      let v123_6: Path = concat_path(&(*p0),&(v117_12_head));
      let mut v123_11 = Space::new();
      let mut v123_11_cursor = (v117_12_tail).read_zipper();
      for v123_11_byte in v123_11_cursor.child_mask().iter() {
        v123_11_cursor.descend_to_byte(v123_11_byte);
        let v123_11_tail = v123_11_cursor.make_map();
        v123_11_cursor.ascend(1);
        let v123_11_head = Path::from_slice(&[v123_11_byte]);
        let v124_2: Space = singleton(&(v123_11_head));
        let v124_3: Space = intersect(&(*CONSTANT_2),&(v124_2));
        let v124_4: Space = if has_head(&(v124_3)) { singleton(&[]) } else { Space::new() };
        drop(v124_3);
        let v124_5: Space = subtract(&(*CONSTANT_1),&(v124_4));
        drop(v124_4);
        let v124_7: Space = if (v124_5).is_empty() { Space::new() } else {
          let v125_6: Space = routine_32(c, &(v123_11_head), &(v123_6), &(v123_11_tail), &(*s1));
          compose(&(v124_5),&(v125_6))
        };
        drop(v124_5);
        let v124_8: Space = intersect(&(*CONSTANT_2),&(v124_2));
        drop(v124_2);
        let v124_9: Space = if has_head(&(v124_8)) { singleton(&[]) } else { Space::new() };
        drop(v124_8);
        let v124_11: Space = if (v124_9).is_empty() { Space::new() } else {
          let v126_10: Space = routine_33(c, &(v123_11_head), &(v123_6), &(v123_11_tail), &(*s1));
          compose(&(v124_9),&(v126_10))
        };
        drop(v124_9);
        let v124_12: Space = unite(&(v124_7),&(v124_11));
        v123_11.join_into((v124_12).clone());
      }
      drop(v123_11_cursor);
      drop(v123_6);
      compose(&(v118_10),&(v123_11))
    };
    drop(v118_10);
    let v118_13: Space = unite(&(v118_8),&(v118_12));
    v117_12.join_into((v118_13).clone());
  }
  drop(v117_12_cursor);
  (v117_12).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v127_12 = Space::new();
  let mut v127_12_cursor = (*s0).read_zipper();
  for v127_12_byte in v127_12_cursor.child_mask().iter() {
    v127_12_cursor.descend_to_byte(v127_12_byte);
    let v127_12_tail = v127_12_cursor.make_map();
    v127_12_cursor.ascend(1);
    let v127_12_head = Path::from_slice(&[v127_12_byte]);
    let v128_2: Space = singleton(&(v127_12_head));
    let v128_3: Space = intersect(&(*CONSTANT_2),&(v128_2));
    let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
    drop(v128_3);
    let v128_5: Space = subtract(&(*CONSTANT_1),&(v128_4));
    drop(v128_4);
    let v128_7: Space = if (v128_5).is_empty() { Space::new() } else {
      let mut v129_6 = Space::new();
      let mut v129_6_cursor = (v127_12_tail).read_zipper();
      for v129_6_byte in v129_6_cursor.child_mask().iter() {
        v129_6_cursor.descend_to_byte(v129_6_byte);
        let v129_6_tail = v129_6_cursor.make_map();
        v129_6_cursor.ascend(1);
        let v129_6_head = Path::from_slice(&[v129_6_byte]);
        let v130_2: Space = singleton(&(v129_6_head));
        let v130_3: Space = intersect(&(*CONSTANT_2),&(v130_2));
        let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
        drop(v130_3);
        let v130_5: Space = subtract(&(*CONSTANT_1),&(v130_4));
        drop(v130_4);
        let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
          let v131_6: Path = concat_path(&(v127_12_head),&(v129_6_head));
          let v131_7: Space = routine_34(c, &(v131_6), &(*p0), &(v129_6_tail), &(*s1));
          compose(&(v130_5),&(v131_7))
        };
        drop(v130_5);
        let v130_9: Space = intersect(&(*CONSTANT_2),&(v130_2));
        drop(v130_2);
        let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
        drop(v130_9);
        let v130_12: Space = if (v130_10).is_empty() { Space::new() } else {
          let v132_6: Path = concat_path(&(v127_12_head),&(v129_6_head));
          let v132_11: Space = routine_35(c, &(v132_6), &(*p0), &(v129_6_tail), &(*s1));
          drop(v132_6);
          compose(&(v130_10),&(v132_11))
        };
        drop(v130_10);
        let v130_13: Space = unite(&(v130_8),&(v130_12));
        v129_6.join_into((v130_13).clone());
      }
      drop(v129_6_cursor);
      compose(&(v128_5),&(v129_6))
    };
    drop(v128_5);
    let v128_8: Space = intersect(&(*CONSTANT_2),&(v128_2));
    drop(v128_2);
    let v128_9: Space = if has_head(&(v128_8)) { singleton(&[]) } else { Space::new() };
    drop(v128_8);
    let v128_11: Space = if (v128_9).is_empty() { Space::new() } else {
      let mut v133_10 = Space::new();
      let mut v133_10_cursor = (v127_12_tail).read_zipper();
      for v133_10_byte in v133_10_cursor.child_mask().iter() {
        v133_10_cursor.descend_to_byte(v133_10_byte);
        let v133_10_tail = v133_10_cursor.make_map();
        v133_10_cursor.ascend(1);
        let v133_10_head = Path::from_slice(&[v133_10_byte]);
        let v134_2: Space = singleton(&(v133_10_head));
        let v134_3: Space = intersect(&(*CONSTANT_2),&(v134_2));
        let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
        drop(v134_3);
        let v134_5: Space = subtract(&(*CONSTANT_1),&(v134_4));
        drop(v134_4);
        let v134_8: Space = if (v134_5).is_empty() { Space::new() } else {
          let v135_6: Path = concat_path(&(v127_12_head),&(v133_10_head));
          let v135_7: Space = routine_34(c, &(v135_6), &(*p0), &(v133_10_tail), &(*s1));
          compose(&(v134_5),&(v135_7))
        };
        drop(v134_5);
        let v134_9: Space = intersect(&(*CONSTANT_2),&(v134_2));
        drop(v134_2);
        let v134_10: Space = if has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
        drop(v134_9);
        let v134_12: Space = if (v134_10).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v127_12_head),&(v133_10_head));
          let v136_11: Space = routine_36(c, &(v136_6), &(*p0), &(v133_10_tail), &(*s1));
          drop(v136_6);
          compose(&(v134_10),&(v136_11))
        };
        drop(v134_10);
        let v134_13: Space = unite(&(v134_8),&(v134_12));
        v133_10.join_into((v134_13).clone());
      }
      drop(v133_10_cursor);
      compose(&(v128_9),&(v133_10))
    };
    drop(v128_9);
    let v128_12: Space = unite(&(v128_7),&(v128_11));
    v127_12.join_into((v128_12).clone());
  }
  drop(v127_12_cursor);
  (v127_12).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v137_12 = Space::new();
  let mut v137_12_cursor = (*s0).read_zipper();
  for v137_12_byte in v137_12_cursor.child_mask().iter() {
    v137_12_cursor.descend_to_byte(v137_12_byte);
    let v137_12_tail = v137_12_cursor.make_map();
    v137_12_cursor.ascend(1);
    let v137_12_head = Path::from_slice(&[v137_12_byte]);
    let v138_2: Space = singleton(&(v137_12_head));
    let v138_3: Space = intersect(&(*CONSTANT_2),&(v138_2));
    let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
    drop(v138_3);
    let v138_5: Space = subtract(&(*CONSTANT_1),&(v138_4));
    drop(v138_4);
    let v138_8: Space = if (v138_5).is_empty() { Space::new() } else {
      let v139_6: Path = concat_path(&(*p0),&(v137_12_head));
      let mut v139_7 = Space::new();
      let mut v139_7_cursor = (v137_12_tail).read_zipper();
      for v139_7_byte in v139_7_cursor.child_mask().iter() {
        v139_7_cursor.descend_to_byte(v139_7_byte);
        let v139_7_tail = v139_7_cursor.make_map();
        v139_7_cursor.ascend(1);
        let v139_7_head = Path::from_slice(&[v139_7_byte]);
        let v140_2: Space = singleton(&(v139_7_head));
        let v140_3: Space = intersect(&(*CONSTANT_2),&(v140_2));
        let v140_4: Space = if has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
        drop(v140_3);
        let v140_5: Space = subtract(&(*CONSTANT_1),&(v140_4));
        drop(v140_4);
        let v140_8: Space = if (v140_5).is_empty() { Space::new() } else {
          let v141_6: Path = concat_path(&(v139_6),&(v139_7_head));
          let v141_7: Space = routine_37(c, &(v141_6), &(v139_7_tail), &(*s1));
          compose(&(v140_5),&(v141_7))
        };
        drop(v140_5);
        let v140_9: Space = intersect(&(*CONSTANT_2),&(v140_2));
        drop(v140_2);
        let v140_10: Space = if has_head(&(v140_9)) { singleton(&[]) } else { Space::new() };
        drop(v140_9);
        let v140_12: Space = if (v140_10).is_empty() { Space::new() } else {
          let v142_6: Path = concat_path(&(v139_6),&(v139_7_head));
          let v142_11: Space = routine_38(c, &(v142_6), &(v139_7_tail), &(*s1));
          drop(v142_6);
          compose(&(v140_10),&(v142_11))
        };
        drop(v140_10);
        let v140_13: Space = unite(&(v140_8),&(v140_12));
        v139_7.join_into((v140_13).clone());
      }
      drop(v139_7_cursor);
      compose(&(v138_5),&(v139_7))
    };
    drop(v138_5);
    let v138_9: Space = intersect(&(*CONSTANT_2),&(v138_2));
    drop(v138_2);
    let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
    drop(v138_9);
    let v138_12: Space = if (v138_10).is_empty() { Space::new() } else {
      let v143_6: Path = concat_path(&(*p0),&(v137_12_head));
      let mut v143_11 = Space::new();
      let mut v143_11_cursor = (v137_12_tail).read_zipper();
      for v143_11_byte in v143_11_cursor.child_mask().iter() {
        v143_11_cursor.descend_to_byte(v143_11_byte);
        let v143_11_tail = v143_11_cursor.make_map();
        v143_11_cursor.ascend(1);
        let v143_11_head = Path::from_slice(&[v143_11_byte]);
        let v144_2: Space = singleton(&(v143_11_head));
        let v144_3: Space = intersect(&(*CONSTANT_2),&(v144_2));
        let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
        drop(v144_3);
        let v144_5: Space = subtract(&(*CONSTANT_1),&(v144_4));
        drop(v144_4);
        let v144_8: Space = if (v144_5).is_empty() { Space::new() } else {
          let v145_6: Path = concat_path(&(v143_6),&(v143_11_head));
          let v145_7: Space = routine_37(c, &(v145_6), &(v143_11_tail), &(*s1));
          compose(&(v144_5),&(v145_7))
        };
        drop(v144_5);
        let v144_9: Space = intersect(&(*CONSTANT_2),&(v144_2));
        drop(v144_2);
        let v144_10: Space = if has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
        drop(v144_9);
        let v144_12: Space = if (v144_10).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v143_6),&(v143_11_head));
          let v146_11: Space = routine_12(c, &(v146_6), &(v143_11_tail), &(*s1));
          drop(v146_6);
          compose(&(v144_10),&(v146_11))
        };
        drop(v144_10);
        let v144_13: Space = unite(&(v144_8),&(v144_12));
        v143_11.join_into((v144_13).clone());
      }
      drop(v143_11_cursor);
      drop(v143_6);
      compose(&(v138_10),&(v143_11))
    };
    drop(v138_10);
    let v138_13: Space = unite(&(v138_8),&(v138_12));
    v137_12.join_into((v138_13).clone());
  }
  drop(v137_12_cursor);
  (v137_12).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v147_12 = Space::new();
  let mut v147_12_cursor = (*s0).read_zipper();
  for v147_12_byte in v147_12_cursor.child_mask().iter() {
    v147_12_cursor.descend_to_byte(v147_12_byte);
    let v147_12_tail = v147_12_cursor.make_map();
    v147_12_cursor.ascend(1);
    let v147_12_head = Path::from_slice(&[v147_12_byte]);
    let v148_2: Space = singleton(&(v147_12_head));
    let v148_3: Space = intersect(&(*CONSTANT_2),&(v148_2));
    let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
    drop(v148_3);
    let v148_5: Space = subtract(&(*CONSTANT_1),&(v148_4));
    drop(v148_4);
    let v148_8: Space = if (v148_5).is_empty() { Space::new() } else {
      let v149_6: Path = concat_path(&(*p0),&(v147_12_head));
      let mut v149_7 = Space::new();
      let mut v149_7_cursor = (v147_12_tail).read_zipper();
      for v149_7_byte in v149_7_cursor.child_mask().iter() {
        v149_7_cursor.descend_to_byte(v149_7_byte);
        let v149_7_tail = v149_7_cursor.make_map();
        v149_7_cursor.ascend(1);
        let v149_7_head = Path::from_slice(&[v149_7_byte]);
        let v150_2: Space = singleton(&(v149_7_head));
        let v150_3: Space = intersect(&(*CONSTANT_2),&(v150_2));
        let v150_4: Space = if has_head(&(v150_3)) { singleton(&[]) } else { Space::new() };
        drop(v150_3);
        let v150_5: Space = subtract(&(*CONSTANT_1),&(v150_4));
        drop(v150_4);
        let v150_8: Space = if (v150_5).is_empty() { Space::new() } else {
          let v151_6: Path = concat_path(&(v149_6),&(v149_7_head));
          let v151_7: Space = routine_37(c, &(v151_6), &(v149_7_tail), &(*s1));
          compose(&(v150_5),&(v151_7))
        };
        drop(v150_5);
        let v150_9: Space = intersect(&(*CONSTANT_2),&(v150_2));
        drop(v150_2);
        let v150_10: Space = if has_head(&(v150_9)) { singleton(&[]) } else { Space::new() };
        drop(v150_9);
        let v150_12: Space = if (v150_10).is_empty() { Space::new() } else {
          let v152_6: Path = concat_path(&(v149_6),&(v149_7_head));
          let v152_11: Space = routine_38(c, &(v152_6), &(v149_7_tail), &(*s1));
          drop(v152_6);
          compose(&(v150_10),&(v152_11))
        };
        drop(v150_10);
        let v150_13: Space = unite(&(v150_8),&(v150_12));
        v149_7.join_into((v150_13).clone());
      }
      drop(v149_7_cursor);
      compose(&(v148_5),&(v149_7))
    };
    drop(v148_5);
    let v148_9: Space = intersect(&(*CONSTANT_2),&(v148_2));
    drop(v148_2);
    let v148_10: Space = if has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
    drop(v148_9);
    let v148_12: Space = if (v148_10).is_empty() { Space::new() } else {
      let v153_6: Path = concat_path(&(*p0),&(v147_12_head));
      let mut v153_11 = Space::new();
      let mut v153_11_cursor = (v147_12_tail).read_zipper();
      for v153_11_byte in v153_11_cursor.child_mask().iter() {
        v153_11_cursor.descend_to_byte(v153_11_byte);
        let v153_11_tail = v153_11_cursor.make_map();
        v153_11_cursor.ascend(1);
        let v153_11_head = Path::from_slice(&[v153_11_byte]);
        let v154_2: Space = singleton(&(v153_11_head));
        let v154_3: Space = intersect(&(*CONSTANT_2),&(v154_2));
        let v154_4: Space = if has_head(&(v154_3)) { singleton(&[]) } else { Space::new() };
        drop(v154_3);
        let v154_5: Space = subtract(&(*CONSTANT_1),&(v154_4));
        drop(v154_4);
        let v154_7: Space = if (v154_5).is_empty() { Space::new() } else {
          let v155_6: Space = routine_39(c, &(v153_11_head), &(v153_6), &(v153_11_tail), &(*s1));
          compose(&(v154_5),&(v155_6))
        };
        drop(v154_5);
        let v154_8: Space = intersect(&(*CONSTANT_2),&(v154_2));
        drop(v154_2);
        let v154_9: Space = if has_head(&(v154_8)) { singleton(&[]) } else { Space::new() };
        drop(v154_8);
        let v154_11: Space = if (v154_9).is_empty() { Space::new() } else {
          let v156_10: Space = routine_40(c, &(v153_11_head), &(v153_6), &(v153_11_tail), &(*s1));
          compose(&(v154_9),&(v156_10))
        };
        drop(v154_9);
        let v154_12: Space = unite(&(v154_7),&(v154_11));
        v153_11.join_into((v154_12).clone());
      }
      drop(v153_11_cursor);
      drop(v153_6);
      compose(&(v148_10),&(v153_11))
    };
    drop(v148_10);
    let v148_13: Space = unite(&(v148_8),&(v148_12));
    v147_12.join_into((v148_13).clone());
  }
  drop(v147_12_cursor);
  (v147_12).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v157_12 = Space::new();
  let mut v157_12_cursor = (*s0).read_zipper();
  for v157_12_byte in v157_12_cursor.child_mask().iter() {
    v157_12_cursor.descend_to_byte(v157_12_byte);
    let v157_12_tail = v157_12_cursor.make_map();
    v157_12_cursor.ascend(1);
    let v157_12_head = Path::from_slice(&[v157_12_byte]);
    let v158_2: Space = singleton(&(v157_12_head));
    let v158_3: Space = intersect(&(*CONSTANT_2),&(v158_2));
    let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
    drop(v158_3);
    let v158_5: Space = subtract(&(*CONSTANT_1),&(v158_4));
    drop(v158_4);
    let v158_7: Space = if (v158_5).is_empty() { Space::new() } else {
      let mut v159_6 = Space::new();
      let mut v159_6_cursor = (v157_12_tail).read_zipper();
      for v159_6_byte in v159_6_cursor.child_mask().iter() {
        v159_6_cursor.descend_to_byte(v159_6_byte);
        let v159_6_tail = v159_6_cursor.make_map();
        v159_6_cursor.ascend(1);
        let v159_6_head = Path::from_slice(&[v159_6_byte]);
        let v160_2: Space = singleton(&(v159_6_head));
        let v160_3: Space = intersect(&(*CONSTANT_2),&(v160_2));
        let v160_4: Space = if has_head(&(v160_3)) { singleton(&[]) } else { Space::new() };
        drop(v160_3);
        let v160_5: Space = subtract(&(*CONSTANT_1),&(v160_4));
        drop(v160_4);
        let v160_8: Space = if (v160_5).is_empty() { Space::new() } else {
          let v161_6: Path = concat_path(&(v157_12_head),&(v159_6_head));
          let v161_7: Space = routine_41(c, &(v161_6), &(*p0), &(v159_6_tail), &(*s1));
          compose(&(v160_5),&(v161_7))
        };
        drop(v160_5);
        let v160_9: Space = intersect(&(*CONSTANT_2),&(v160_2));
        drop(v160_2);
        let v160_10: Space = if has_head(&(v160_9)) { singleton(&[]) } else { Space::new() };
        drop(v160_9);
        let v160_12: Space = if (v160_10).is_empty() { Space::new() } else {
          let v162_6: Path = concat_path(&(v157_12_head),&(v159_6_head));
          let v162_11: Space = routine_42(c, &(v162_6), &(*p0), &(v159_6_tail), &(*s1));
          drop(v162_6);
          compose(&(v160_10),&(v162_11))
        };
        drop(v160_10);
        let v160_13: Space = unite(&(v160_8),&(v160_12));
        v159_6.join_into((v160_13).clone());
      }
      drop(v159_6_cursor);
      compose(&(v158_5),&(v159_6))
    };
    drop(v158_5);
    let v158_8: Space = intersect(&(*CONSTANT_2),&(v158_2));
    drop(v158_2);
    let v158_9: Space = if has_head(&(v158_8)) { singleton(&[]) } else { Space::new() };
    drop(v158_8);
    let v158_11: Space = if (v158_9).is_empty() { Space::new() } else {
      let mut v163_10 = Space::new();
      let mut v163_10_cursor = (v157_12_tail).read_zipper();
      for v163_10_byte in v163_10_cursor.child_mask().iter() {
        v163_10_cursor.descend_to_byte(v163_10_byte);
        let v163_10_tail = v163_10_cursor.make_map();
        v163_10_cursor.ascend(1);
        let v163_10_head = Path::from_slice(&[v163_10_byte]);
        let v164_2: Space = singleton(&(v163_10_head));
        let v164_3: Space = intersect(&(*CONSTANT_2),&(v164_2));
        let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
        drop(v164_3);
        let v164_5: Space = subtract(&(*CONSTANT_1),&(v164_4));
        drop(v164_4);
        let v164_8: Space = if (v164_5).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v157_12_head),&(v163_10_head));
          let v165_7: Space = routine_41(c, &(v165_6), &(*p0), &(v163_10_tail), &(*s1));
          compose(&(v164_5),&(v165_7))
        };
        drop(v164_5);
        let v164_9: Space = intersect(&(*CONSTANT_2),&(v164_2));
        drop(v164_2);
        let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
        drop(v164_9);
        let v164_12: Space = if (v164_10).is_empty() { Space::new() } else {
          let v166_6: Path = concat_path(&(v157_12_head),&(v163_10_head));
          let v166_11: Space = routine_43(c, &(v166_6), &(*p0), &(v163_10_tail), &(*s1));
          drop(v166_6);
          compose(&(v164_10),&(v166_11))
        };
        drop(v164_10);
        let v164_13: Space = unite(&(v164_8),&(v164_12));
        v163_10.join_into((v164_13).clone());
      }
      drop(v163_10_cursor);
      compose(&(v158_9),&(v163_10))
    };
    drop(v158_9);
    let v158_12: Space = unite(&(v158_7),&(v158_11));
    v157_12.join_into((v158_12).clone());
  }
  drop(v157_12_cursor);
  (v157_12).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v167_11 = Space::new();
  let mut v167_11_cursor = (*s0).read_zipper();
  for v167_11_byte in v167_11_cursor.child_mask().iter() {
    v167_11_cursor.descend_to_byte(v167_11_byte);
    let v167_11_tail = v167_11_cursor.make_map();
    v167_11_cursor.ascend(1);
    let v167_11_head = Path::from_slice(&[v167_11_byte]);
    let v168_2: Space = singleton(&(v167_11_head));
    let v168_3: Space = intersect(&(*CONSTANT_2),&(v168_2));
    let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
    drop(v168_3);
    let v168_5: Space = subtract(&(*CONSTANT_1),&(v168_4));
    drop(v168_4);
    let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
      let v169_6: Path = concat_path(&(*p0),&(v167_11_head));
      let mut v169_7 = Space::new();
      let mut v169_7_cursor = (v167_11_tail).read_zipper();
      for v169_7_byte in v169_7_cursor.child_mask().iter() {
        v169_7_cursor.descend_to_byte(v169_7_byte);
        let v169_7_tail = v169_7_cursor.make_map();
        v169_7_cursor.ascend(1);
        let v169_7_head = Path::from_slice(&[v169_7_byte]);
        let v170_2: Space = singleton(&(v169_7_head));
        let v170_3: Space = intersect(&(*CONSTANT_2),&(v170_2));
        let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
        drop(v170_3);
        let v170_5: Space = subtract(&(*CONSTANT_1),&(v170_4));
        drop(v170_4);
        let v170_8: Space = if (v170_5).is_empty() { Space::new() } else {
          let v171_6: Path = concat_path(&(v169_6),&(v169_7_head));
          let v171_7: Space = routine_44(c, &(v171_6), &(v169_7_tail));
          compose(&(v170_5),&(v171_7))
        };
        drop(v170_5);
        let v170_9: Space = intersect(&(*CONSTANT_2),&(v170_2));
        drop(v170_2);
        let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
        drop(v170_9);
        let v170_12: Space = if (v170_10).is_empty() { Space::new() } else {
          let v172_6: Path = concat_path(&(v169_6),&(v169_7_head));
          let v172_11: Space = routine_45(c, &(v172_6), &(v169_7_tail));
          drop(v172_6);
          compose(&(v170_10),&(v172_11))
        };
        drop(v170_10);
        let v170_13: Space = unite(&(v170_8),&(v170_12));
        v169_7.join_into((v170_13).clone());
      }
      drop(v169_7_cursor);
      compose(&(v168_5),&(v169_7))
    };
    drop(v168_5);
    let v168_9: Space = intersect(&(*CONSTANT_2),&(v168_2));
    drop(v168_2);
    let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
    drop(v168_9);
    let v168_12: Space = if (v168_10).is_empty() { Space::new() } else {
      let v173_6: Path = concat_path(&(*p0),&(v167_11_head));
      let mut v173_11 = Space::new();
      let mut v173_11_cursor = (v167_11_tail).read_zipper();
      for v173_11_byte in v173_11_cursor.child_mask().iter() {
        v173_11_cursor.descend_to_byte(v173_11_byte);
        let v173_11_tail = v173_11_cursor.make_map();
        v173_11_cursor.ascend(1);
        let v173_11_head = Path::from_slice(&[v173_11_byte]);
        let v174_2: Space = singleton(&(v173_11_head));
        let v174_3: Space = intersect(&(*CONSTANT_2),&(v174_2));
        let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
        drop(v174_3);
        let v174_5: Space = subtract(&(*CONSTANT_1),&(v174_4));
        drop(v174_4);
        let v174_8: Space = if (v174_5).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v173_6),&(v173_11_head));
          let v175_7: Space = routine_44(c, &(v175_6), &(v173_11_tail));
          compose(&(v174_5),&(v175_7))
        };
        drop(v174_5);
        let v174_9: Space = intersect(&(*CONSTANT_2),&(v174_2));
        drop(v174_2);
        let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
        drop(v174_9);
        let v174_12: Space = if (v174_10).is_empty() { Space::new() } else {
          let v176_6: Path = concat_path(&(v173_6),&(v173_11_head));
          let v176_11: Space = routine_15(c, &(v176_6), &(v173_11_tail));
          drop(v176_6);
          compose(&(v174_10),&(v176_11))
        };
        drop(v174_10);
        let v174_13: Space = unite(&(v174_8),&(v174_12));
        v173_11.join_into((v174_13).clone());
      }
      drop(v173_11_cursor);
      drop(v173_6);
      compose(&(v168_10),&(v173_11))
    };
    drop(v168_10);
    let v168_13: Space = unite(&(v168_8),&(v168_12));
    v167_11.join_into((v168_13).clone());
  }
  drop(v167_11_cursor);
  (v167_11).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v177_11 = Space::new();
  let mut v177_11_cursor = (*s0).read_zipper();
  for v177_11_byte in v177_11_cursor.child_mask().iter() {
    v177_11_cursor.descend_to_byte(v177_11_byte);
    let v177_11_tail = v177_11_cursor.make_map();
    v177_11_cursor.ascend(1);
    let v177_11_head = Path::from_slice(&[v177_11_byte]);
    let v178_2: Space = singleton(&(v177_11_head));
    let v178_3: Space = intersect(&(*CONSTANT_2),&(v178_2));
    let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
    drop(v178_3);
    let v178_5: Space = subtract(&(*CONSTANT_1),&(v178_4));
    drop(v178_4);
    let v178_8: Space = if (v178_5).is_empty() { Space::new() } else {
      let v179_6: Path = concat_path(&(*p0),&(v177_11_head));
      let mut v179_7 = Space::new();
      let mut v179_7_cursor = (v177_11_tail).read_zipper();
      for v179_7_byte in v179_7_cursor.child_mask().iter() {
        v179_7_cursor.descend_to_byte(v179_7_byte);
        let v179_7_tail = v179_7_cursor.make_map();
        v179_7_cursor.ascend(1);
        let v179_7_head = Path::from_slice(&[v179_7_byte]);
        let v180_2: Space = singleton(&(v179_7_head));
        let v180_3: Space = intersect(&(*CONSTANT_2),&(v180_2));
        let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
        drop(v180_3);
        let v180_5: Space = subtract(&(*CONSTANT_1),&(v180_4));
        drop(v180_4);
        let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v181_7: Space = routine_44(c, &(v181_6), &(v179_7_tail));
          compose(&(v180_5),&(v181_7))
        };
        drop(v180_5);
        let v180_9: Space = intersect(&(*CONSTANT_2),&(v180_2));
        drop(v180_2);
        let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
        drop(v180_9);
        let v180_12: Space = if (v180_10).is_empty() { Space::new() } else {
          let v182_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v182_11: Space = routine_45(c, &(v182_6), &(v179_7_tail));
          drop(v182_6);
          compose(&(v180_10),&(v182_11))
        };
        drop(v180_10);
        let v180_13: Space = unite(&(v180_8),&(v180_12));
        v179_7.join_into((v180_13).clone());
      }
      drop(v179_7_cursor);
      compose(&(v178_5),&(v179_7))
    };
    drop(v178_5);
    let v178_9: Space = intersect(&(*CONSTANT_2),&(v178_2));
    drop(v178_2);
    let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
    drop(v178_9);
    let v178_12: Space = if (v178_10).is_empty() { Space::new() } else {
      let v183_6: Path = concat_path(&(*p0),&(v177_11_head));
      let mut v183_11 = Space::new();
      let mut v183_11_cursor = (v177_11_tail).read_zipper();
      for v183_11_byte in v183_11_cursor.child_mask().iter() {
        v183_11_cursor.descend_to_byte(v183_11_byte);
        let v183_11_tail = v183_11_cursor.make_map();
        v183_11_cursor.ascend(1);
        let v183_11_head = Path::from_slice(&[v183_11_byte]);
        let v184_2: Space = singleton(&(v183_11_head));
        let v184_3: Space = intersect(&(*CONSTANT_2),&(v184_2));
        let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
        drop(v184_3);
        let v184_5: Space = subtract(&(*CONSTANT_1),&(v184_4));
        drop(v184_4);
        let v184_7: Space = if (v184_5).is_empty() { Space::new() } else {
          let v185_6: Space = routine_46(c, &(v183_11_head), &(v183_6), &(v183_11_tail));
          compose(&(v184_5),&(v185_6))
        };
        drop(v184_5);
        let v184_8: Space = intersect(&(*CONSTANT_2),&(v184_2));
        drop(v184_2);
        let v184_9: Space = if has_head(&(v184_8)) { singleton(&[]) } else { Space::new() };
        drop(v184_8);
        let v184_11: Space = if (v184_9).is_empty() { Space::new() } else {
          let v186_10: Space = routine_47(c, &(v183_11_head), &(v183_6), &(v183_11_tail));
          compose(&(v184_9),&(v186_10))
        };
        drop(v184_9);
        let v184_12: Space = unite(&(v184_7),&(v184_11));
        v183_11.join_into((v184_12).clone());
      }
      drop(v183_11_cursor);
      drop(v183_6);
      compose(&(v178_10),&(v183_11))
    };
    drop(v178_10);
    let v178_13: Space = unite(&(v178_8),&(v178_12));
    v177_11.join_into((v178_13).clone());
  }
  drop(v177_11_cursor);
  (v177_11).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v187_11 = Space::new();
  let mut v187_11_cursor = (*s0).read_zipper();
  for v187_11_byte in v187_11_cursor.child_mask().iter() {
    v187_11_cursor.descend_to_byte(v187_11_byte);
    let v187_11_tail = v187_11_cursor.make_map();
    v187_11_cursor.ascend(1);
    let v187_11_head = Path::from_slice(&[v187_11_byte]);
    let v188_2: Space = singleton(&(v187_11_head));
    let v188_3: Space = intersect(&(*CONSTANT_2),&(v188_2));
    let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
    drop(v188_3);
    let v188_5: Space = subtract(&(*CONSTANT_1),&(v188_4));
    drop(v188_4);
    let v188_7: Space = if (v188_5).is_empty() { Space::new() } else {
      let mut v189_6 = Space::new();
      let mut v189_6_cursor = (v187_11_tail).read_zipper();
      for v189_6_byte in v189_6_cursor.child_mask().iter() {
        v189_6_cursor.descend_to_byte(v189_6_byte);
        let v189_6_tail = v189_6_cursor.make_map();
        v189_6_cursor.ascend(1);
        let v189_6_head = Path::from_slice(&[v189_6_byte]);
        let v190_2: Space = singleton(&(v189_6_head));
        let v190_3: Space = intersect(&(*CONSTANT_2),&(v190_2));
        let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
        drop(v190_3);
        let v190_5: Space = subtract(&(*CONSTANT_1),&(v190_4));
        drop(v190_4);
        let v190_8: Space = if (v190_5).is_empty() { Space::new() } else {
          let v191_6: Path = concat_path(&(v187_11_head),&(v189_6_head));
          let v191_7: Space = routine_48(c, &(v191_6), &(*p0), &(v189_6_tail));
          compose(&(v190_5),&(v191_7))
        };
        drop(v190_5);
        let v190_9: Space = intersect(&(*CONSTANT_2),&(v190_2));
        drop(v190_2);
        let v190_10: Space = if has_head(&(v190_9)) { singleton(&[]) } else { Space::new() };
        drop(v190_9);
        let v190_12: Space = if (v190_10).is_empty() { Space::new() } else {
          let v192_6: Path = concat_path(&(v187_11_head),&(v189_6_head));
          let v192_11: Space = routine_49(c, &(v192_6), &(*p0), &(v189_6_tail));
          drop(v192_6);
          compose(&(v190_10),&(v192_11))
        };
        drop(v190_10);
        let v190_13: Space = unite(&(v190_8),&(v190_12));
        v189_6.join_into((v190_13).clone());
      }
      drop(v189_6_cursor);
      compose(&(v188_5),&(v189_6))
    };
    drop(v188_5);
    let v188_8: Space = intersect(&(*CONSTANT_2),&(v188_2));
    drop(v188_2);
    let v188_9: Space = if has_head(&(v188_8)) { singleton(&[]) } else { Space::new() };
    drop(v188_8);
    let v188_11: Space = if (v188_9).is_empty() { Space::new() } else {
      let mut v193_10 = Space::new();
      let mut v193_10_cursor = (v187_11_tail).read_zipper();
      for v193_10_byte in v193_10_cursor.child_mask().iter() {
        v193_10_cursor.descend_to_byte(v193_10_byte);
        let v193_10_tail = v193_10_cursor.make_map();
        v193_10_cursor.ascend(1);
        let v193_10_head = Path::from_slice(&[v193_10_byte]);
        let v194_2: Space = singleton(&(v193_10_head));
        let v194_3: Space = intersect(&(*CONSTANT_2),&(v194_2));
        let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
        drop(v194_3);
        let v194_5: Space = subtract(&(*CONSTANT_1),&(v194_4));
        drop(v194_4);
        let v194_8: Space = if (v194_5).is_empty() { Space::new() } else {
          let v195_6: Path = concat_path(&(v187_11_head),&(v193_10_head));
          let v195_7: Space = routine_48(c, &(v195_6), &(*p0), &(v193_10_tail));
          compose(&(v194_5),&(v195_7))
        };
        drop(v194_5);
        let v194_9: Space = intersect(&(*CONSTANT_2),&(v194_2));
        drop(v194_2);
        let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
        drop(v194_9);
        let v194_12: Space = if (v194_10).is_empty() { Space::new() } else {
          let v196_6: Path = concat_path(&(v187_11_head),&(v193_10_head));
          let v196_11: Space = routine_50(c, &(v196_6), &(*p0), &(v193_10_tail));
          drop(v196_6);
          compose(&(v194_10),&(v196_11))
        };
        drop(v194_10);
        let v194_13: Space = unite(&(v194_8),&(v194_12));
        v193_10.join_into((v194_13).clone());
      }
      drop(v193_10_cursor);
      compose(&(v188_9),&(v193_10))
    };
    drop(v188_9);
    let v188_12: Space = unite(&(v188_7),&(v188_11));
    v187_11.join_into((v188_12).clone());
  }
  drop(v187_11_cursor);
  (v187_11).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v197_11 = Space::new();
  let mut v197_11_cursor = (*s0).read_zipper();
  for v197_11_byte in v197_11_cursor.child_mask().iter() {
    v197_11_cursor.descend_to_byte(v197_11_byte);
    let v197_11_tail = v197_11_cursor.make_map();
    v197_11_cursor.ascend(1);
    let v197_11_head = Path::from_slice(&[v197_11_byte]);
    let v198_2: Space = singleton(&(v197_11_head));
    let v198_3: Space = intersect(&(*CONSTANT_2),&(v198_2));
    let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
    drop(v198_3);
    let v198_5: Space = subtract(&(*CONSTANT_1),&(v198_4));
    drop(v198_4);
    let v198_8: Space = if (v198_5).is_empty() { Space::new() } else {
      let v199_6: Path = concat_path(&(*p0),&(v197_11_head));
      let mut v199_7 = Space::new();
      let mut v199_7_cursor = (v197_11_tail).read_zipper();
      for v199_7_byte in v199_7_cursor.child_mask().iter() {
        v199_7_cursor.descend_to_byte(v199_7_byte);
        let v199_7_tail = v199_7_cursor.make_map();
        v199_7_cursor.ascend(1);
        let v199_7_head = Path::from_slice(&[v199_7_byte]);
        let v200_2: Space = singleton(&(v199_7_head));
        let v200_3: Space = intersect(&(*CONSTANT_2),&(v200_2));
        let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
        drop(v200_3);
        let v200_5: Space = subtract(&(*CONSTANT_1),&(v200_4));
        drop(v200_4);
        let v200_8: Space = if (v200_5).is_empty() { Space::new() } else {
          let v201_6: Path = concat_path(&(v199_6),&(v199_7_head));
          let v201_7: Space = routine_51(c, &(v201_6), &(v199_7_tail));
          compose(&(v200_5),&(v201_7))
        };
        drop(v200_5);
        let v200_9: Space = intersect(&(*CONSTANT_2),&(v200_2));
        drop(v200_2);
        let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
        drop(v200_9);
        let v200_12: Space = if (v200_10).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v199_6),&(v199_7_head));
          let v202_11: Space = routine_52(c, &(v202_6), &(v199_7_tail));
          drop(v202_6);
          compose(&(v200_10),&(v202_11))
        };
        drop(v200_10);
        let v200_13: Space = unite(&(v200_8),&(v200_12));
        v199_7.join_into((v200_13).clone());
      }
      drop(v199_7_cursor);
      compose(&(v198_5),&(v199_7))
    };
    drop(v198_5);
    let v198_9: Space = intersect(&(*CONSTANT_2),&(v198_2));
    drop(v198_2);
    let v198_10: Space = if has_head(&(v198_9)) { singleton(&[]) } else { Space::new() };
    drop(v198_9);
    let v198_12: Space = if (v198_10).is_empty() { Space::new() } else {
      let v203_6: Path = concat_path(&(*p0),&(v197_11_head));
      let mut v203_11 = Space::new();
      let mut v203_11_cursor = (v197_11_tail).read_zipper();
      for v203_11_byte in v203_11_cursor.child_mask().iter() {
        v203_11_cursor.descend_to_byte(v203_11_byte);
        let v203_11_tail = v203_11_cursor.make_map();
        v203_11_cursor.ascend(1);
        let v203_11_head = Path::from_slice(&[v203_11_byte]);
        let v204_2: Space = singleton(&(v203_11_head));
        let v204_3: Space = intersect(&(*CONSTANT_2),&(v204_2));
        let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
        drop(v204_3);
        let v204_5: Space = subtract(&(*CONSTANT_1),&(v204_4));
        drop(v204_4);
        let v204_8: Space = if (v204_5).is_empty() { Space::new() } else {
          let v205_6: Path = concat_path(&(v203_6),&(v203_11_head));
          let v205_7: Space = routine_51(c, &(v205_6), &(v203_11_tail));
          compose(&(v204_5),&(v205_7))
        };
        drop(v204_5);
        let v204_9: Space = intersect(&(*CONSTANT_2),&(v204_2));
        drop(v204_2);
        let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
        drop(v204_9);
        let v204_12: Space = if (v204_10).is_empty() { Space::new() } else {
          let v206_6: Path = concat_path(&(v203_6),&(v203_11_head));
          let v206_11: Space = routine_3(c, &(v206_6), &(v203_11_tail));
          drop(v206_6);
          compose(&(v204_10),&(v206_11))
        };
        drop(v204_10);
        let v204_13: Space = unite(&(v204_8),&(v204_12));
        v203_11.join_into((v204_13).clone());
      }
      drop(v203_11_cursor);
      drop(v203_6);
      compose(&(v198_10),&(v203_11))
    };
    drop(v198_10);
    let v198_13: Space = unite(&(v198_8),&(v198_12));
    v197_11.join_into((v198_13).clone());
  }
  drop(v197_11_cursor);
  (v197_11).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v207_11 = Space::new();
  let mut v207_11_cursor = (*s0).read_zipper();
  for v207_11_byte in v207_11_cursor.child_mask().iter() {
    v207_11_cursor.descend_to_byte(v207_11_byte);
    let v207_11_tail = v207_11_cursor.make_map();
    v207_11_cursor.ascend(1);
    let v207_11_head = Path::from_slice(&[v207_11_byte]);
    let v208_2: Space = singleton(&(v207_11_head));
    let v208_3: Space = intersect(&(*CONSTANT_2),&(v208_2));
    let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
    drop(v208_3);
    let v208_5: Space = subtract(&(*CONSTANT_1),&(v208_4));
    drop(v208_4);
    let v208_8: Space = if (v208_5).is_empty() { Space::new() } else {
      let v209_6: Path = concat_path(&(*p0),&(v207_11_head));
      let mut v209_7 = Space::new();
      let mut v209_7_cursor = (v207_11_tail).read_zipper();
      for v209_7_byte in v209_7_cursor.child_mask().iter() {
        v209_7_cursor.descend_to_byte(v209_7_byte);
        let v209_7_tail = v209_7_cursor.make_map();
        v209_7_cursor.ascend(1);
        let v209_7_head = Path::from_slice(&[v209_7_byte]);
        let v210_2: Space = singleton(&(v209_7_head));
        let v210_3: Space = intersect(&(*CONSTANT_2),&(v210_2));
        let v210_4: Space = if has_head(&(v210_3)) { singleton(&[]) } else { Space::new() };
        drop(v210_3);
        let v210_5: Space = subtract(&(*CONSTANT_1),&(v210_4));
        drop(v210_4);
        let v210_8: Space = if (v210_5).is_empty() { Space::new() } else {
          let v211_6: Path = concat_path(&(v209_6),&(v209_7_head));
          let v211_7: Space = routine_51(c, &(v211_6), &(v209_7_tail));
          compose(&(v210_5),&(v211_7))
        };
        drop(v210_5);
        let v210_9: Space = intersect(&(*CONSTANT_2),&(v210_2));
        drop(v210_2);
        let v210_10: Space = if has_head(&(v210_9)) { singleton(&[]) } else { Space::new() };
        drop(v210_9);
        let v210_12: Space = if (v210_10).is_empty() { Space::new() } else {
          let v212_6: Path = concat_path(&(v209_6),&(v209_7_head));
          let v212_11: Space = routine_52(c, &(v212_6), &(v209_7_tail));
          drop(v212_6);
          compose(&(v210_10),&(v212_11))
        };
        drop(v210_10);
        let v210_13: Space = unite(&(v210_8),&(v210_12));
        v209_7.join_into((v210_13).clone());
      }
      drop(v209_7_cursor);
      compose(&(v208_5),&(v209_7))
    };
    drop(v208_5);
    let v208_9: Space = intersect(&(*CONSTANT_2),&(v208_2));
    drop(v208_2);
    let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
    drop(v208_9);
    let v208_12: Space = if (v208_10).is_empty() { Space::new() } else {
      let v213_6: Path = concat_path(&(*p0),&(v207_11_head));
      let mut v213_11 = Space::new();
      let mut v213_11_cursor = (v207_11_tail).read_zipper();
      for v213_11_byte in v213_11_cursor.child_mask().iter() {
        v213_11_cursor.descend_to_byte(v213_11_byte);
        let v213_11_tail = v213_11_cursor.make_map();
        v213_11_cursor.ascend(1);
        let v213_11_head = Path::from_slice(&[v213_11_byte]);
        let v214_2: Space = singleton(&(v213_11_head));
        let v214_3: Space = intersect(&(*CONSTANT_2),&(v214_2));
        let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
        drop(v214_3);
        let v214_5: Space = subtract(&(*CONSTANT_1),&(v214_4));
        drop(v214_4);
        let v214_7: Space = if (v214_5).is_empty() { Space::new() } else {
          let v215_6: Space = routine_18(c, &(v213_11_head), &(v213_6), &(v213_11_tail));
          compose(&(v214_5),&(v215_6))
        };
        drop(v214_5);
        let v214_8: Space = intersect(&(*CONSTANT_2),&(v214_2));
        drop(v214_2);
        let v214_9: Space = if has_head(&(v214_8)) { singleton(&[]) } else { Space::new() };
        drop(v214_8);
        let v214_11: Space = if (v214_9).is_empty() { Space::new() } else {
          let v216_10: Space = routine_19(c, &(v213_11_head), &(v213_6), &(v213_11_tail));
          compose(&(v214_9),&(v216_10))
        };
        drop(v214_9);
        let v214_12: Space = unite(&(v214_7),&(v214_11));
        v213_11.join_into((v214_12).clone());
      }
      drop(v213_11_cursor);
      drop(v213_6);
      compose(&(v208_10),&(v213_11))
    };
    drop(v208_10);
    let v208_13: Space = unite(&(v208_8),&(v208_12));
    v207_11.join_into((v208_13).clone());
  }
  drop(v207_11_cursor);
  (v207_11).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v217_12 = Space::new();
  let mut v217_12_cursor = (*s0).read_zipper();
  for v217_12_byte in v217_12_cursor.child_mask().iter() {
    v217_12_cursor.descend_to_byte(v217_12_byte);
    let v217_12_tail = v217_12_cursor.make_map();
    v217_12_cursor.ascend(1);
    let v217_12_head = Path::from_slice(&[v217_12_byte]);
    let v218_2: Space = singleton(&(v217_12_head));
    let v218_3: Space = intersect(&(*CONSTANT_2),&(v218_2));
    let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
    drop(v218_3);
    let v218_5: Space = subtract(&(*CONSTANT_1),&(v218_4));
    drop(v218_4);
    let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
      let v219_6: Path = concat_path(&(*p0),&(v217_12_head));
      let mut v219_7 = Space::new();
      let mut v219_7_cursor = (v217_12_tail).read_zipper();
      for v219_7_byte in v219_7_cursor.child_mask().iter() {
        v219_7_cursor.descend_to_byte(v219_7_byte);
        let v219_7_tail = v219_7_cursor.make_map();
        v219_7_cursor.ascend(1);
        let v219_7_head = Path::from_slice(&[v219_7_byte]);
        let v220_2: Space = singleton(&(v219_7_head));
        let v220_3: Space = intersect(&(*CONSTANT_2),&(v220_2));
        let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
        drop(v220_3);
        let v220_5: Space = subtract(&(*CONSTANT_1),&(v220_4));
        drop(v220_4);
        let v220_8: Space = if (v220_5).is_empty() { Space::new() } else {
          let v221_6: Path = concat_path(&(v219_6),&(v219_7_head));
          let v221_7: Space = routine_53(c, &(v221_6), &(*p1), &(v219_7_tail));
          compose(&(v220_5),&(v221_7))
        };
        drop(v220_5);
        let v220_9: Space = intersect(&(*CONSTANT_2),&(v220_2));
        drop(v220_2);
        let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
        drop(v220_9);
        let v220_12: Space = if (v220_10).is_empty() { Space::new() } else {
          let v222_6: Path = concat_path(&(v219_6),&(v219_7_head));
          let v222_11: Space = routine_54(c, &(v222_6), &(*p1), &(v219_7_tail));
          drop(v222_6);
          compose(&(v220_10),&(v222_11))
        };
        drop(v220_10);
        let v220_13: Space = unite(&(v220_8),&(v220_12));
        v219_7.join_into((v220_13).clone());
      }
      drop(v219_7_cursor);
      compose(&(v218_5),&(v219_7))
    };
    drop(v218_5);
    let v218_9: Space = intersect(&(*CONSTANT_2),&(v218_2));
    drop(v218_2);
    let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
    drop(v218_9);
    let v218_12: Space = if (v218_10).is_empty() { Space::new() } else {
      let v223_6: Path = concat_path(&(*p0),&(v217_12_head));
      let mut v223_11 = Space::new();
      let mut v223_11_cursor = (v217_12_tail).read_zipper();
      for v223_11_byte in v223_11_cursor.child_mask().iter() {
        v223_11_cursor.descend_to_byte(v223_11_byte);
        let v223_11_tail = v223_11_cursor.make_map();
        v223_11_cursor.ascend(1);
        let v223_11_head = Path::from_slice(&[v223_11_byte]);
        let v224_2: Space = singleton(&(v223_11_head));
        let v224_3: Space = intersect(&(*CONSTANT_2),&(v224_2));
        let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
        drop(v224_3);
        let v224_5: Space = subtract(&(*CONSTANT_1),&(v224_4));
        drop(v224_4);
        let v224_8: Space = if (v224_5).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v223_6),&(v223_11_head));
          let v225_7: Space = routine_53(c, &(v225_6), &(*p1), &(v223_11_tail));
          compose(&(v224_5),&(v225_7))
        };
        drop(v224_5);
        let v224_9: Space = intersect(&(*CONSTANT_2),&(v224_2));
        drop(v224_2);
        let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
        drop(v224_9);
        let v224_12: Space = if (v224_10).is_empty() { Space::new() } else {
          let v226_6: Path = concat_path(&(v223_6),&(v223_11_head));
          let v226_11: Space = routine_22(c, &(v226_6), &(*p1), &(v223_11_tail));
          drop(v226_6);
          compose(&(v224_10),&(v226_11))
        };
        drop(v224_10);
        let v224_13: Space = unite(&(v224_8),&(v224_12));
        v223_11.join_into((v224_13).clone());
      }
      drop(v223_11_cursor);
      drop(v223_6);
      compose(&(v218_10),&(v223_11))
    };
    drop(v218_10);
    let v218_13: Space = unite(&(v218_8),&(v218_12));
    v217_12.join_into((v218_13).clone());
  }
  drop(v217_12_cursor);
  (v217_12).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v227_10 = Space::new();
  let mut v227_10_cursor = (*s0).read_zipper();
  for v227_10_byte in v227_10_cursor.child_mask().iter() {
    v227_10_cursor.descend_to_byte(v227_10_byte);
    let v227_10_tail = v227_10_cursor.make_map();
    v227_10_cursor.ascend(1);
    let v227_10_head = Path::from_slice(&[v227_10_byte]);
    let v228_2: Space = singleton(&(v227_10_head));
    let v228_3: Space = intersect(&(*CONSTANT_2),&(v228_2));
    let v228_4: Space = if has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
    drop(v228_3);
    let v228_5: Space = compose(&(v228_4),&(v227_10_tail));
    drop(v228_4);
    let v229_6: Path = concat_path(&(*p0),&(v227_10_head));
    let v228_7: Space = wrap(&(v228_5),&(v229_6));
    drop(v228_5);
    let v228_8: Space = wrap(&(v228_7),&(*p1));
    drop(v228_7);
    let v228_9: Space = wrap(&(v228_8),&(*CONSTANT_5));
    drop(v228_8);
    let v228_10: Space = intersect(&(*CONSTANT_2),&(v228_2));
    drop(v228_2);
    let v228_11: Space = if has_head(&(v228_10)) { singleton(&[]) } else { Space::new() };
    drop(v228_10);
    let v228_12: Space = subtract(&(*CONSTANT_1),&(v228_11));
    drop(v228_11);
    let v228_14: Space = if (v228_12).is_empty() { Space::new() } else {
      let mut v230_13 = Space::new();
      let mut v230_13_cursor = (v227_10_tail).read_zipper();
      for v230_13_byte in v230_13_cursor.child_mask().iter() {
        v230_13_cursor.descend_to_byte(v230_13_byte);
        let v230_13_tail = v230_13_cursor.make_map();
        v230_13_cursor.ascend(1);
        let v230_13_head = Path::from_slice(&[v230_13_byte]);
        let v231_2: Space = singleton(&(v230_13_head));
        let v231_3: Space = intersect(&(*CONSTANT_2),&(v231_2));
        let v231_4: Space = if has_head(&(v231_3)) { singleton(&[]) } else { Space::new() };
        drop(v231_3);
        let v231_5: Space = subtract(&(*CONSTANT_1),&(v231_4));
        drop(v231_4);
        let v231_8: Space = if (v231_5).is_empty() { Space::new() } else {
          let v232_6: Path = concat_path(&(v229_6),&(v230_13_head));
          let v232_7: Space = routine_53(c, &(v232_6), &(*p1), &(v230_13_tail));
          compose(&(v231_5),&(v232_7))
        };
        drop(v231_5);
        let v231_9: Space = intersect(&(*CONSTANT_2),&(v231_2));
        drop(v231_2);
        let v231_10: Space = if has_head(&(v231_9)) { singleton(&[]) } else { Space::new() };
        drop(v231_9);
        let v231_12: Space = if (v231_10).is_empty() { Space::new() } else {
          let v233_6: Path = concat_path(&(v229_6),&(v230_13_head));
          let v233_11: Space = routine_54(c, &(v233_6), &(*p1), &(v230_13_tail));
          drop(v233_6);
          compose(&(v231_10),&(v233_11))
        };
        drop(v231_10);
        let v231_13: Space = unite(&(v231_8),&(v231_12));
        v230_13.join_into((v231_13).clone());
      }
      drop(v230_13_cursor);
      compose(&(v228_12),&(v230_13))
    };
    drop(v228_12);
    let v228_15: Space = unite(&(v228_9),&(v228_14));
    drop(v228_9);
    v227_10.join_into((v228_15).clone());
  }
  drop(v227_10_cursor);
  (v227_10).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v234_12 = Space::new();
  let mut v234_12_cursor = (*s0).read_zipper();
  for v234_12_byte in v234_12_cursor.child_mask().iter() {
    v234_12_cursor.descend_to_byte(v234_12_byte);
    let v234_12_tail = v234_12_cursor.make_map();
    v234_12_cursor.ascend(1);
    let v234_12_head = Path::from_slice(&[v234_12_byte]);
    let v235_2: Space = singleton(&(v234_12_head));
    let v235_3: Space = intersect(&(*CONSTANT_2),&(v235_2));
    let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
    drop(v235_3);
    let v235_5: Space = subtract(&(*CONSTANT_1),&(v235_4));
    drop(v235_4);
    let v235_8: Space = if (v235_5).is_empty() { Space::new() } else {
      let v236_6: Path = concat_path(&(*p0),&(v234_12_head));
      let mut v236_7 = Space::new();
      let mut v236_7_cursor = (v234_12_tail).read_zipper();
      for v236_7_byte in v236_7_cursor.child_mask().iter() {
        v236_7_cursor.descend_to_byte(v236_7_byte);
        let v236_7_tail = v236_7_cursor.make_map();
        v236_7_cursor.ascend(1);
        let v236_7_head = Path::from_slice(&[v236_7_byte]);
        let v237_2: Space = singleton(&(v236_7_head));
        let v237_3: Space = intersect(&(*CONSTANT_2),&(v237_2));
        let v237_4: Space = if has_head(&(v237_3)) { singleton(&[]) } else { Space::new() };
        drop(v237_3);
        let v237_5: Space = subtract(&(*CONSTANT_1),&(v237_4));
        drop(v237_4);
        let v237_8: Space = if (v237_5).is_empty() { Space::new() } else {
          let v238_6: Path = concat_path(&(v236_6),&(v236_7_head));
          let v238_7: Space = routine_55(c, &(v238_6), &(*p1), &(v236_7_tail));
          compose(&(v237_5),&(v238_7))
        };
        drop(v237_5);
        let v237_9: Space = intersect(&(*CONSTANT_2),&(v237_2));
        drop(v237_2);
        let v237_10: Space = if has_head(&(v237_9)) { singleton(&[]) } else { Space::new() };
        drop(v237_9);
        let v237_12: Space = if (v237_10).is_empty() { Space::new() } else {
          let v239_6: Path = concat_path(&(v236_6),&(v236_7_head));
          let v239_11: Space = routine_56(c, &(v239_6), &(*p1), &(v236_7_tail));
          drop(v239_6);
          compose(&(v237_10),&(v239_11))
        };
        drop(v237_10);
        let v237_13: Space = unite(&(v237_8),&(v237_12));
        v236_7.join_into((v237_13).clone());
      }
      drop(v236_7_cursor);
      compose(&(v235_5),&(v236_7))
    };
    drop(v235_5);
    let v235_9: Space = intersect(&(*CONSTANT_2),&(v235_2));
    drop(v235_2);
    let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
    drop(v235_9);
    let v235_12: Space = if (v235_10).is_empty() { Space::new() } else {
      let v240_6: Path = concat_path(&(*p0),&(v234_12_head));
      let mut v240_11 = Space::new();
      let mut v240_11_cursor = (v234_12_tail).read_zipper();
      for v240_11_byte in v240_11_cursor.child_mask().iter() {
        v240_11_cursor.descend_to_byte(v240_11_byte);
        let v240_11_tail = v240_11_cursor.make_map();
        v240_11_cursor.ascend(1);
        let v240_11_head = Path::from_slice(&[v240_11_byte]);
        let v241_2: Space = singleton(&(v240_11_head));
        let v241_3: Space = intersect(&(*CONSTANT_2),&(v241_2));
        let v241_4: Space = if has_head(&(v241_3)) { singleton(&[]) } else { Space::new() };
        drop(v241_3);
        let v241_5: Space = subtract(&(*CONSTANT_1),&(v241_4));
        drop(v241_4);
        let v241_8: Space = if (v241_5).is_empty() { Space::new() } else {
          let v242_6: Path = concat_path(&(v240_6),&(v240_11_head));
          let v242_7: Space = routine_55(c, &(v242_6), &(*p1), &(v240_11_tail));
          compose(&(v241_5),&(v242_7))
        };
        drop(v241_5);
        let v241_9: Space = intersect(&(*CONSTANT_2),&(v241_2));
        drop(v241_2);
        let v241_10: Space = if has_head(&(v241_9)) { singleton(&[]) } else { Space::new() };
        drop(v241_9);
        let v241_12: Space = if (v241_10).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v240_6),&(v240_11_head));
          let v243_11: Space = routine_22(c, &(v243_6), &(*p1), &(v240_11_tail));
          drop(v243_6);
          compose(&(v241_10),&(v243_11))
        };
        drop(v241_10);
        let v241_13: Space = unite(&(v241_8),&(v241_12));
        v240_11.join_into((v241_13).clone());
      }
      drop(v240_11_cursor);
      drop(v240_6);
      compose(&(v235_10),&(v240_11))
    };
    drop(v235_10);
    let v235_13: Space = unite(&(v235_8),&(v235_12));
    v234_12.join_into((v235_13).clone());
  }
  drop(v234_12_cursor);
  (v234_12).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v244_10 = Space::new();
  let mut v244_10_cursor = (*s0).read_zipper();
  for v244_10_byte in v244_10_cursor.child_mask().iter() {
    v244_10_cursor.descend_to_byte(v244_10_byte);
    let v244_10_tail = v244_10_cursor.make_map();
    v244_10_cursor.ascend(1);
    let v244_10_head = Path::from_slice(&[v244_10_byte]);
    let v245_2: Space = singleton(&(v244_10_head));
    let v245_3: Space = intersect(&(*CONSTANT_2),&(v245_2));
    let v245_4: Space = if has_head(&(v245_3)) { singleton(&[]) } else { Space::new() };
    drop(v245_3);
    let v245_5: Space = compose(&(v245_4),&(v244_10_tail));
    drop(v245_4);
    let v246_6: Path = concat_path(&(*p0),&(v244_10_head));
    let v245_7: Space = wrap(&(v245_5),&(v246_6));
    drop(v245_5);
    let v245_8: Space = wrap(&(v245_7),&(*p1));
    drop(v245_7);
    let v245_9: Space = wrap(&(v245_8),&(*CONSTANT_5));
    drop(v245_8);
    let v245_10: Space = intersect(&(*CONSTANT_2),&(v245_2));
    drop(v245_2);
    let v245_11: Space = if has_head(&(v245_10)) { singleton(&[]) } else { Space::new() };
    drop(v245_10);
    let v245_12: Space = subtract(&(*CONSTANT_1),&(v245_11));
    drop(v245_11);
    let v245_14: Space = if (v245_12).is_empty() { Space::new() } else {
      let mut v247_13 = Space::new();
      let mut v247_13_cursor = (v244_10_tail).read_zipper();
      for v247_13_byte in v247_13_cursor.child_mask().iter() {
        v247_13_cursor.descend_to_byte(v247_13_byte);
        let v247_13_tail = v247_13_cursor.make_map();
        v247_13_cursor.ascend(1);
        let v247_13_head = Path::from_slice(&[v247_13_byte]);
        let v248_2: Space = singleton(&(v247_13_head));
        let v248_3: Space = intersect(&(*CONSTANT_2),&(v248_2));
        let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
        drop(v248_3);
        let v248_5: Space = subtract(&(*CONSTANT_1),&(v248_4));
        drop(v248_4);
        let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
          let v249_6: Path = concat_path(&(v246_6),&(v247_13_head));
          let v249_7: Space = routine_55(c, &(v249_6), &(*p1), &(v247_13_tail));
          compose(&(v248_5),&(v249_7))
        };
        drop(v248_5);
        let v248_9: Space = intersect(&(*CONSTANT_2),&(v248_2));
        drop(v248_2);
        let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
        drop(v248_9);
        let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
          let v250_6: Path = concat_path(&(v246_6),&(v247_13_head));
          let v250_11: Space = routine_56(c, &(v250_6), &(*p1), &(v247_13_tail));
          drop(v250_6);
          compose(&(v248_10),&(v250_11))
        };
        drop(v248_10);
        let v248_13: Space = unite(&(v248_8),&(v248_12));
        v247_13.join_into((v248_13).clone());
      }
      drop(v247_13_cursor);
      compose(&(v245_12),&(v247_13))
    };
    drop(v245_12);
    let v245_15: Space = unite(&(v245_9),&(v245_14));
    drop(v245_9);
    v244_10.join_into((v245_15).clone());
  }
  drop(v244_10_cursor);
  (v244_10).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v251_3: Space = wrap(&(*s0),&(*p0));
  let v251_4: Space = wrap(&(v251_3),&(*p1));
  drop(v251_3);
  let v251_6: Space = wrap(&(v251_4),&(*CONSTANT_5));
  drop(v251_4);
  (v251_6).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v252_12 = Space::new();
  let mut v252_12_cursor = (*s0).read_zipper();
  for v252_12_byte in v252_12_cursor.child_mask().iter() {
    v252_12_cursor.descend_to_byte(v252_12_byte);
    let v252_12_tail = v252_12_cursor.make_map();
    v252_12_cursor.ascend(1);
    let v252_12_head = Path::from_slice(&[v252_12_byte]);
    let v253_2: Space = singleton(&(v252_12_head));
    let v253_3: Space = intersect(&(*CONSTANT_2),&(v253_2));
    let v253_4: Space = if has_head(&(v253_3)) { singleton(&[]) } else { Space::new() };
    drop(v253_3);
    let v253_5: Space = subtract(&(*CONSTANT_1),&(v253_4));
    drop(v253_4);
    let v253_8: Space = if (v253_5).is_empty() { Space::new() } else {
      let v254_6: Path = concat_path(&(*p0),&(v252_12_head));
      let mut v254_7 = Space::new();
      let mut v254_7_cursor = (v252_12_tail).read_zipper();
      for v254_7_byte in v254_7_cursor.child_mask().iter() {
        v254_7_cursor.descend_to_byte(v254_7_byte);
        let v254_7_tail = v254_7_cursor.make_map();
        v254_7_cursor.ascend(1);
        let v254_7_head = Path::from_slice(&[v254_7_byte]);
        let v255_2: Space = singleton(&(v254_7_head));
        let v255_3: Space = intersect(&(*CONSTANT_2),&(v255_2));
        let v255_4: Space = if has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
        drop(v255_3);
        let v255_5: Space = subtract(&(*CONSTANT_1),&(v255_4));
        drop(v255_4);
        let v255_8: Space = if (v255_5).is_empty() { Space::new() } else {
          let v256_6: Path = concat_path(&(v254_6),&(v254_7_head));
          let v256_7: Space = routine_57(c, &(v256_6), &(v254_7_tail), &(*s1));
          compose(&(v255_5),&(v256_7))
        };
        drop(v255_5);
        let v255_9: Space = intersect(&(*CONSTANT_2),&(v255_2));
        drop(v255_2);
        let v255_10: Space = if has_head(&(v255_9)) { singleton(&[]) } else { Space::new() };
        drop(v255_9);
        let v255_12: Space = if (v255_10).is_empty() { Space::new() } else {
          let v257_6: Path = concat_path(&(v254_6),&(v254_7_head));
          let v257_11: Space = routine_58(c, &(v257_6), &(v254_7_tail), &(*s1));
          drop(v257_6);
          compose(&(v255_10),&(v257_11))
        };
        drop(v255_10);
        let v255_13: Space = unite(&(v255_8),&(v255_12));
        v254_7.join_into((v255_13).clone());
      }
      drop(v254_7_cursor);
      compose(&(v253_5),&(v254_7))
    };
    drop(v253_5);
    let v253_9: Space = intersect(&(*CONSTANT_2),&(v253_2));
    drop(v253_2);
    let v253_10: Space = if has_head(&(v253_9)) { singleton(&[]) } else { Space::new() };
    drop(v253_9);
    let v253_12: Space = if (v253_10).is_empty() { Space::new() } else {
      let v258_6: Path = concat_path(&(*p0),&(v252_12_head));
      let mut v258_11 = Space::new();
      let mut v258_11_cursor = (v252_12_tail).read_zipper();
      for v258_11_byte in v258_11_cursor.child_mask().iter() {
        v258_11_cursor.descend_to_byte(v258_11_byte);
        let v258_11_tail = v258_11_cursor.make_map();
        v258_11_cursor.ascend(1);
        let v258_11_head = Path::from_slice(&[v258_11_byte]);
        let v259_2: Space = singleton(&(v258_11_head));
        let v259_3: Space = intersect(&(*CONSTANT_2),&(v259_2));
        let v259_4: Space = if has_head(&(v259_3)) { singleton(&[]) } else { Space::new() };
        drop(v259_3);
        let v259_5: Space = subtract(&(*CONSTANT_1),&(v259_4));
        drop(v259_4);
        let v259_8: Space = if (v259_5).is_empty() { Space::new() } else {
          let v260_6: Path = concat_path(&(v258_6),&(v258_11_head));
          let v260_7: Space = routine_57(c, &(v260_6), &(v258_11_tail), &(*s1));
          compose(&(v259_5),&(v260_7))
        };
        drop(v259_5);
        let v259_9: Space = intersect(&(*CONSTANT_2),&(v259_2));
        drop(v259_2);
        let v259_10: Space = if has_head(&(v259_9)) { singleton(&[]) } else { Space::new() };
        drop(v259_9);
        let v259_12: Space = if (v259_10).is_empty() { Space::new() } else {
          let v261_6: Path = concat_path(&(v258_6),&(v258_11_head));
          let v261_11: Space = routine_6(c, &(v261_6), &(v258_11_tail), &(*s1));
          drop(v261_6);
          compose(&(v259_10),&(v261_11))
        };
        drop(v259_10);
        let v259_13: Space = unite(&(v259_8),&(v259_12));
        v258_11.join_into((v259_13).clone());
      }
      drop(v258_11_cursor);
      drop(v258_6);
      compose(&(v253_10),&(v258_11))
    };
    drop(v253_10);
    let v253_13: Space = unite(&(v253_8),&(v253_12));
    v252_12.join_into((v253_13).clone());
  }
  drop(v252_12_cursor);
  (v252_12).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v262_12 = Space::new();
  let mut v262_12_cursor = (*s0).read_zipper();
  for v262_12_byte in v262_12_cursor.child_mask().iter() {
    v262_12_cursor.descend_to_byte(v262_12_byte);
    let v262_12_tail = v262_12_cursor.make_map();
    v262_12_cursor.ascend(1);
    let v262_12_head = Path::from_slice(&[v262_12_byte]);
    let v263_2: Space = singleton(&(v262_12_head));
    let v263_3: Space = intersect(&(*CONSTANT_2),&(v263_2));
    let v263_4: Space = if has_head(&(v263_3)) { singleton(&[]) } else { Space::new() };
    drop(v263_3);
    let v263_5: Space = subtract(&(*CONSTANT_1),&(v263_4));
    drop(v263_4);
    let v263_8: Space = if (v263_5).is_empty() { Space::new() } else {
      let v264_6: Path = concat_path(&(*p0),&(v262_12_head));
      let mut v264_7 = Space::new();
      let mut v264_7_cursor = (v262_12_tail).read_zipper();
      for v264_7_byte in v264_7_cursor.child_mask().iter() {
        v264_7_cursor.descend_to_byte(v264_7_byte);
        let v264_7_tail = v264_7_cursor.make_map();
        v264_7_cursor.ascend(1);
        let v264_7_head = Path::from_slice(&[v264_7_byte]);
        let v265_2: Space = singleton(&(v264_7_head));
        let v265_3: Space = intersect(&(*CONSTANT_2),&(v265_2));
        let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
        drop(v265_3);
        let v265_5: Space = subtract(&(*CONSTANT_1),&(v265_4));
        drop(v265_4);
        let v265_8: Space = if (v265_5).is_empty() { Space::new() } else {
          let v266_6: Path = concat_path(&(v264_6),&(v264_7_head));
          let v266_7: Space = routine_57(c, &(v266_6), &(v264_7_tail), &(*s1));
          compose(&(v265_5),&(v266_7))
        };
        drop(v265_5);
        let v265_9: Space = intersect(&(*CONSTANT_2),&(v265_2));
        drop(v265_2);
        let v265_10: Space = if has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
        drop(v265_9);
        let v265_12: Space = if (v265_10).is_empty() { Space::new() } else {
          let v267_6: Path = concat_path(&(v264_6),&(v264_7_head));
          let v267_11: Space = routine_58(c, &(v267_6), &(v264_7_tail), &(*s1));
          drop(v267_6);
          compose(&(v265_10),&(v267_11))
        };
        drop(v265_10);
        let v265_13: Space = unite(&(v265_8),&(v265_12));
        v264_7.join_into((v265_13).clone());
      }
      drop(v264_7_cursor);
      compose(&(v263_5),&(v264_7))
    };
    drop(v263_5);
    let v263_9: Space = intersect(&(*CONSTANT_2),&(v263_2));
    drop(v263_2);
    let v263_10: Space = if has_head(&(v263_9)) { singleton(&[]) } else { Space::new() };
    drop(v263_9);
    let v263_12: Space = if (v263_10).is_empty() { Space::new() } else {
      let v268_6: Path = concat_path(&(*p0),&(v262_12_head));
      let mut v268_11 = Space::new();
      let mut v268_11_cursor = (v262_12_tail).read_zipper();
      for v268_11_byte in v268_11_cursor.child_mask().iter() {
        v268_11_cursor.descend_to_byte(v268_11_byte);
        let v268_11_tail = v268_11_cursor.make_map();
        v268_11_cursor.ascend(1);
        let v268_11_head = Path::from_slice(&[v268_11_byte]);
        let v269_2: Space = singleton(&(v268_11_head));
        let v269_3: Space = intersect(&(*CONSTANT_2),&(v269_2));
        let v269_4: Space = if has_head(&(v269_3)) { singleton(&[]) } else { Space::new() };
        drop(v269_3);
        let v269_5: Space = subtract(&(*CONSTANT_1),&(v269_4));
        drop(v269_4);
        let v269_7: Space = if (v269_5).is_empty() { Space::new() } else {
          let v270_6: Space = routine_25(c, &(v268_11_head), &(v268_6), &(v268_11_tail), &(*s1));
          compose(&(v269_5),&(v270_6))
        };
        drop(v269_5);
        let v269_8: Space = intersect(&(*CONSTANT_2),&(v269_2));
        drop(v269_2);
        let v269_9: Space = if has_head(&(v269_8)) { singleton(&[]) } else { Space::new() };
        drop(v269_8);
        let v269_11: Space = if (v269_9).is_empty() { Space::new() } else {
          let v271_10: Space = routine_26(c, &(v268_11_head), &(v268_6), &(v268_11_tail), &(*s1));
          compose(&(v269_9),&(v271_10))
        };
        drop(v269_9);
        let v269_12: Space = unite(&(v269_7),&(v269_11));
        v268_11.join_into((v269_12).clone());
      }
      drop(v268_11_cursor);
      drop(v268_6);
      compose(&(v263_10),&(v268_11))
    };
    drop(v263_10);
    let v263_13: Space = unite(&(v263_8),&(v263_12));
    v262_12.join_into((v263_13).clone());
  }
  drop(v262_12_cursor);
  (v262_12).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v272_13 = Space::new();
  let mut v272_13_cursor = (*s0).read_zipper();
  for v272_13_byte in v272_13_cursor.child_mask().iter() {
    v272_13_cursor.descend_to_byte(v272_13_byte);
    let v272_13_tail = v272_13_cursor.make_map();
    v272_13_cursor.ascend(1);
    let v272_13_head = Path::from_slice(&[v272_13_byte]);
    let v273_2: Space = singleton(&(v272_13_head));
    let v273_3: Space = intersect(&(*CONSTANT_2),&(v273_2));
    let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
    drop(v273_3);
    let v273_5: Space = subtract(&(*CONSTANT_1),&(v273_4));
    drop(v273_4);
    let v273_8: Space = if (v273_5).is_empty() { Space::new() } else {
      let v274_6: Path = concat_path(&(*p0),&(v272_13_head));
      let mut v274_7 = Space::new();
      let mut v274_7_cursor = (v272_13_tail).read_zipper();
      for v274_7_byte in v274_7_cursor.child_mask().iter() {
        v274_7_cursor.descend_to_byte(v274_7_byte);
        let v274_7_tail = v274_7_cursor.make_map();
        v274_7_cursor.ascend(1);
        let v274_7_head = Path::from_slice(&[v274_7_byte]);
        let v275_2: Space = singleton(&(v274_7_head));
        let v275_3: Space = intersect(&(*CONSTANT_2),&(v275_2));
        let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
        drop(v275_3);
        let v275_5: Space = subtract(&(*CONSTANT_1),&(v275_4));
        drop(v275_4);
        let v275_8: Space = if (v275_5).is_empty() { Space::new() } else {
          let v276_6: Path = concat_path(&(v274_6),&(v274_7_head));
          let v276_7: Space = routine_59(c, &(v276_6), &(*p1), &(v274_7_tail), &(*s1));
          compose(&(v275_5),&(v276_7))
        };
        drop(v275_5);
        let v275_9: Space = intersect(&(*CONSTANT_2),&(v275_2));
        drop(v275_2);
        let v275_10: Space = if has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
        drop(v275_9);
        let v275_12: Space = if (v275_10).is_empty() { Space::new() } else {
          let v277_6: Path = concat_path(&(v274_6),&(v274_7_head));
          let v277_11: Space = routine_60(c, &(v277_6), &(*p1), &(v274_7_tail), &(*s1));
          drop(v277_6);
          compose(&(v275_10),&(v277_11))
        };
        drop(v275_10);
        let v275_13: Space = unite(&(v275_8),&(v275_12));
        v274_7.join_into((v275_13).clone());
      }
      drop(v274_7_cursor);
      compose(&(v273_5),&(v274_7))
    };
    drop(v273_5);
    let v273_9: Space = intersect(&(*CONSTANT_2),&(v273_2));
    drop(v273_2);
    let v273_10: Space = if has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
    drop(v273_9);
    let v273_12: Space = if (v273_10).is_empty() { Space::new() } else {
      let v278_6: Path = concat_path(&(*p0),&(v272_13_head));
      let mut v278_11 = Space::new();
      let mut v278_11_cursor = (v272_13_tail).read_zipper();
      for v278_11_byte in v278_11_cursor.child_mask().iter() {
        v278_11_cursor.descend_to_byte(v278_11_byte);
        let v278_11_tail = v278_11_cursor.make_map();
        v278_11_cursor.ascend(1);
        let v278_11_head = Path::from_slice(&[v278_11_byte]);
        let v279_2: Space = singleton(&(v278_11_head));
        let v279_3: Space = intersect(&(*CONSTANT_2),&(v279_2));
        let v279_4: Space = if has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
        drop(v279_3);
        let v279_5: Space = subtract(&(*CONSTANT_1),&(v279_4));
        drop(v279_4);
        let v279_8: Space = if (v279_5).is_empty() { Space::new() } else {
          let v280_6: Path = concat_path(&(v278_6),&(v278_11_head));
          let v280_7: Space = routine_59(c, &(v280_6), &(*p1), &(v278_11_tail), &(*s1));
          compose(&(v279_5),&(v280_7))
        };
        drop(v279_5);
        let v279_9: Space = intersect(&(*CONSTANT_2),&(v279_2));
        drop(v279_2);
        let v279_10: Space = if has_head(&(v279_9)) { singleton(&[]) } else { Space::new() };
        drop(v279_9);
        let v279_12: Space = if (v279_10).is_empty() { Space::new() } else {
          let v281_6: Path = concat_path(&(v278_6),&(v278_11_head));
          let v281_11: Space = routine_29(c, &(v281_6), &(*p1), &(v278_11_tail), &(*s1));
          drop(v281_6);
          compose(&(v279_10),&(v281_11))
        };
        drop(v279_10);
        let v279_13: Space = unite(&(v279_8),&(v279_12));
        v278_11.join_into((v279_13).clone());
      }
      drop(v278_11_cursor);
      drop(v278_6);
      compose(&(v273_10),&(v278_11))
    };
    drop(v273_10);
    let v273_13: Space = unite(&(v273_8),&(v273_12));
    v272_13.join_into((v273_13).clone());
  }
  drop(v272_13_cursor);
  (v272_13).clone()
}

fn routine_26(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v282_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v282_10: Space = unwrap(&(v282_8),&(*CONSTANT_5));
  drop(v282_8);
  let v282_11: Space = unwrap(&(v282_10),&(*p0));
  drop(v282_10);
  let mut v282_18 = Space::new();
  let mut v282_18_cursor = (*s0).read_zipper();
  for v282_18_byte in v282_18_cursor.child_mask().iter() {
    v282_18_cursor.descend_to_byte(v282_18_byte);
    let v282_18_tail = v282_18_cursor.make_map();
    v282_18_cursor.ascend(1);
    let v282_18_head = Path::from_slice(&[v282_18_byte]);
    let v283_2: Space = singleton(&(v282_18_head));
    let v283_3: Space = intersect(&(*CONSTANT_2),&(v283_2));
    let v283_4: Space = if has_head(&(v283_3)) { singleton(&[]) } else { Space::new() };
    drop(v283_3);
    let v283_5: Space = subtract(&(*CONSTANT_1),&(v283_4));
    drop(v283_4);
    let v283_8: Space = if (v283_5).is_empty() { Space::new() } else {
      let v284_6: Path = concat_path(&(*p0),&(v282_18_head));
      let mut v284_7 = Space::new();
      let mut v284_7_cursor = (v282_18_tail).read_zipper();
      for v284_7_byte in v284_7_cursor.child_mask().iter() {
        v284_7_cursor.descend_to_byte(v284_7_byte);
        let v284_7_tail = v284_7_cursor.make_map();
        v284_7_cursor.ascend(1);
        let v284_7_head = Path::from_slice(&[v284_7_byte]);
        let v285_2: Space = singleton(&(v284_7_head));
        let v285_3: Space = intersect(&(*CONSTANT_2),&(v285_2));
        let v285_4: Space = if has_head(&(v285_3)) { singleton(&[]) } else { Space::new() };
        drop(v285_3);
        let v285_5: Space = subtract(&(*CONSTANT_1),&(v285_4));
        drop(v285_4);
        let v285_8: Space = if (v285_5).is_empty() { Space::new() } else {
          let v286_6: Path = concat_path(&(v284_6),&(v284_7_head));
          let v286_7: Space = routine_59(c, &(v286_6), &(*p1), &(v284_7_tail), &(*s1));
          compose(&(v285_5),&(v286_7))
        };
        drop(v285_5);
        let v285_9: Space = intersect(&(*CONSTANT_2),&(v285_2));
        drop(v285_2);
        let v285_10: Space = if has_head(&(v285_9)) { singleton(&[]) } else { Space::new() };
        drop(v285_9);
        let v285_12: Space = if (v285_10).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v284_6),&(v284_7_head));
          let v287_11: Space = routine_60(c, &(v287_6), &(*p1), &(v284_7_tail), &(*s1));
          drop(v287_6);
          compose(&(v285_10),&(v287_11))
        };
        drop(v285_10);
        let v285_13: Space = unite(&(v285_8),&(v285_12));
        v284_7.join_into((v285_13).clone());
      }
      drop(v284_7_cursor);
      drop(v284_6);
      compose(&(v283_5),&(v284_7))
    };
    drop(v283_5);
    let v283_9: Space = intersect(&(*CONSTANT_2),&(v283_2));
    drop(v283_2);
    let v283_10: Space = if has_head(&(v283_9)) { singleton(&[]) } else { Space::new() };
    drop(v283_9);
    let v283_13: Space = if (v283_10).is_empty() { Space::new() } else {
      let v288_11: Space = unwrap(&(v282_11),&(v282_18_head));
      let mut v288_12 = Space::new();
      let mut v288_12_cursor = (v288_11).read_zipper();
      for v288_12_byte in v288_12_cursor.child_mask().iter() {
        v288_12_cursor.descend_to_byte(v288_12_byte);
        let v288_12_tail = v288_12_cursor.make_map();
        v288_12_cursor.ascend(1);
        let v288_12_head = Path::from_slice(&[v288_12_byte]);
        let v289_2: Space = singleton(&(v288_12_head));
        let v289_3: Space = intersect(&(*CONSTANT_2),&(v289_2));
        let v289_4: Space = if has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
        drop(v289_3);
        let v289_5: Space = subtract(&(*CONSTANT_1),&(v289_4));
        drop(v289_4);
        let v289_7: Space = if (v289_5).is_empty() { Space::new() } else {
          let v290_6: Space = routine_61(c, &(v288_12_head), &(*p1), &(v288_12_tail));
          compose(&(v289_5),&(v290_6))
        };
        drop(v289_5);
        let v289_8: Space = intersect(&(*CONSTANT_2),&(v289_2));
        drop(v289_2);
        let v289_9: Space = if has_head(&(v289_8)) { singleton(&[]) } else { Space::new() };
        drop(v289_8);
        let v289_11: Space = if (v289_9).is_empty() { Space::new() } else {
          let v291_10: Space = routine_62(c, &(v288_12_head), &(*p1), &(v288_12_tail));
          compose(&(v289_9),&(v291_10))
        };
        drop(v289_9);
        let v289_12: Space = unite(&(v289_7),&(v289_11));
        v288_12.join_into((v289_12).clone());
      }
      drop(v288_12_cursor);
      drop(v288_11);
      compose(&(v283_10),&(v288_12))
    };
    drop(v283_10);
    let v283_14: Space = unite(&(v283_8),&(v283_13));
    v282_18.join_into((v283_14).clone());
  }
  drop(v282_18_cursor);
  drop(v282_11);
  (v282_18).clone()
}

fn routine_27(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v292_13 = Space::new();
  let mut v292_13_cursor = (*s0).read_zipper();
  for v292_13_byte in v292_13_cursor.child_mask().iter() {
    v292_13_cursor.descend_to_byte(v292_13_byte);
    let v292_13_tail = v292_13_cursor.make_map();
    v292_13_cursor.ascend(1);
    let v292_13_head = Path::from_slice(&[v292_13_byte]);
    let v293_2: Space = singleton(&(v292_13_head));
    let v293_3: Space = intersect(&(*CONSTANT_2),&(v293_2));
    let v293_4: Space = if has_head(&(v293_3)) { singleton(&[]) } else { Space::new() };
    drop(v293_3);
    let v293_5: Space = subtract(&(*CONSTANT_1),&(v293_4));
    drop(v293_4);
    let v293_8: Space = if (v293_5).is_empty() { Space::new() } else {
      let v294_6: Path = concat_path(&(*p0),&(v292_13_head));
      let mut v294_7 = Space::new();
      let mut v294_7_cursor = (v292_13_tail).read_zipper();
      for v294_7_byte in v294_7_cursor.child_mask().iter() {
        v294_7_cursor.descend_to_byte(v294_7_byte);
        let v294_7_tail = v294_7_cursor.make_map();
        v294_7_cursor.ascend(1);
        let v294_7_head = Path::from_slice(&[v294_7_byte]);
        let v295_2: Space = singleton(&(v294_7_head));
        let v295_3: Space = intersect(&(*CONSTANT_2),&(v295_2));
        let v295_4: Space = if has_head(&(v295_3)) { singleton(&[]) } else { Space::new() };
        drop(v295_3);
        let v295_5: Space = subtract(&(*CONSTANT_1),&(v295_4));
        drop(v295_4);
        let v295_8: Space = if (v295_5).is_empty() { Space::new() } else {
          let v296_6: Path = concat_path(&(v294_6),&(v294_7_head));
          let v296_7: Space = routine_63(c, &(v296_6), &(*p1), &(v294_7_tail), &(*s1));
          compose(&(v295_5),&(v296_7))
        };
        drop(v295_5);
        let v295_9: Space = intersect(&(*CONSTANT_2),&(v295_2));
        drop(v295_2);
        let v295_10: Space = if has_head(&(v295_9)) { singleton(&[]) } else { Space::new() };
        drop(v295_9);
        let v295_12: Space = if (v295_10).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v294_6),&(v294_7_head));
          let v297_11: Space = routine_64(c, &(v297_6), &(*p1), &(v294_7_tail), &(*s1));
          drop(v297_6);
          compose(&(v295_10),&(v297_11))
        };
        drop(v295_10);
        let v295_13: Space = unite(&(v295_8),&(v295_12));
        v294_7.join_into((v295_13).clone());
      }
      drop(v294_7_cursor);
      compose(&(v293_5),&(v294_7))
    };
    drop(v293_5);
    let v293_9: Space = intersect(&(*CONSTANT_2),&(v293_2));
    drop(v293_2);
    let v293_10: Space = if has_head(&(v293_9)) { singleton(&[]) } else { Space::new() };
    drop(v293_9);
    let v293_12: Space = if (v293_10).is_empty() { Space::new() } else {
      let v298_6: Path = concat_path(&(*p0),&(v292_13_head));
      let mut v298_11 = Space::new();
      let mut v298_11_cursor = (v292_13_tail).read_zipper();
      for v298_11_byte in v298_11_cursor.child_mask().iter() {
        v298_11_cursor.descend_to_byte(v298_11_byte);
        let v298_11_tail = v298_11_cursor.make_map();
        v298_11_cursor.ascend(1);
        let v298_11_head = Path::from_slice(&[v298_11_byte]);
        let v299_2: Space = singleton(&(v298_11_head));
        let v299_3: Space = intersect(&(*CONSTANT_2),&(v299_2));
        let v299_4: Space = if has_head(&(v299_3)) { singleton(&[]) } else { Space::new() };
        drop(v299_3);
        let v299_5: Space = subtract(&(*CONSTANT_1),&(v299_4));
        drop(v299_4);
        let v299_8: Space = if (v299_5).is_empty() { Space::new() } else {
          let v300_6: Path = concat_path(&(v298_6),&(v298_11_head));
          let v300_7: Space = routine_63(c, &(v300_6), &(*p1), &(v298_11_tail), &(*s1));
          compose(&(v299_5),&(v300_7))
        };
        drop(v299_5);
        let v299_9: Space = intersect(&(*CONSTANT_2),&(v299_2));
        drop(v299_2);
        let v299_10: Space = if has_head(&(v299_9)) { singleton(&[]) } else { Space::new() };
        drop(v299_9);
        let v299_12: Space = if (v299_10).is_empty() { Space::new() } else {
          let v301_6: Path = concat_path(&(v298_6),&(v298_11_head));
          let v301_11: Space = routine_29(c, &(v301_6), &(*p1), &(v298_11_tail), &(*s1));
          drop(v301_6);
          compose(&(v299_10),&(v301_11))
        };
        drop(v299_10);
        let v299_13: Space = unite(&(v299_8),&(v299_12));
        v298_11.join_into((v299_13).clone());
      }
      drop(v298_11_cursor);
      drop(v298_6);
      compose(&(v293_10),&(v298_11))
    };
    drop(v293_10);
    let v293_13: Space = unite(&(v293_8),&(v293_12));
    v292_13.join_into((v293_13).clone());
  }
  drop(v292_13_cursor);
  (v292_13).clone()
}

fn routine_28(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v302_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v302_10: Space = unwrap(&(v302_8),&(*CONSTANT_5));
  drop(v302_8);
  let v302_11: Space = unwrap(&(v302_10),&(*p0));
  drop(v302_10);
  let mut v302_18 = Space::new();
  let mut v302_18_cursor = (*s0).read_zipper();
  for v302_18_byte in v302_18_cursor.child_mask().iter() {
    v302_18_cursor.descend_to_byte(v302_18_byte);
    let v302_18_tail = v302_18_cursor.make_map();
    v302_18_cursor.ascend(1);
    let v302_18_head = Path::from_slice(&[v302_18_byte]);
    let v303_2: Space = singleton(&(v302_18_head));
    let v303_3: Space = intersect(&(*CONSTANT_2),&(v303_2));
    let v303_4: Space = if has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
    drop(v303_3);
    let v303_5: Space = subtract(&(*CONSTANT_1),&(v303_4));
    drop(v303_4);
    let v303_8: Space = if (v303_5).is_empty() { Space::new() } else {
      let v304_6: Path = concat_path(&(*p0),&(v302_18_head));
      let mut v304_7 = Space::new();
      let mut v304_7_cursor = (v302_18_tail).read_zipper();
      for v304_7_byte in v304_7_cursor.child_mask().iter() {
        v304_7_cursor.descend_to_byte(v304_7_byte);
        let v304_7_tail = v304_7_cursor.make_map();
        v304_7_cursor.ascend(1);
        let v304_7_head = Path::from_slice(&[v304_7_byte]);
        let v305_2: Space = singleton(&(v304_7_head));
        let v305_3: Space = intersect(&(*CONSTANT_2),&(v305_2));
        let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
        drop(v305_3);
        let v305_5: Space = subtract(&(*CONSTANT_1),&(v305_4));
        drop(v305_4);
        let v305_8: Space = if (v305_5).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v304_6),&(v304_7_head));
          let v306_7: Space = routine_63(c, &(v306_6), &(*p1), &(v304_7_tail), &(*s1));
          compose(&(v305_5),&(v306_7))
        };
        drop(v305_5);
        let v305_9: Space = intersect(&(*CONSTANT_2),&(v305_2));
        drop(v305_2);
        let v305_10: Space = if has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
        drop(v305_9);
        let v305_12: Space = if (v305_10).is_empty() { Space::new() } else {
          let v307_6: Path = concat_path(&(v304_6),&(v304_7_head));
          let v307_11: Space = routine_64(c, &(v307_6), &(*p1), &(v304_7_tail), &(*s1));
          drop(v307_6);
          compose(&(v305_10),&(v307_11))
        };
        drop(v305_10);
        let v305_13: Space = unite(&(v305_8),&(v305_12));
        v304_7.join_into((v305_13).clone());
      }
      drop(v304_7_cursor);
      drop(v304_6);
      compose(&(v303_5),&(v304_7))
    };
    drop(v303_5);
    let v303_9: Space = intersect(&(*CONSTANT_2),&(v303_2));
    drop(v303_2);
    let v303_10: Space = if has_head(&(v303_9)) { singleton(&[]) } else { Space::new() };
    drop(v303_9);
    let v303_13: Space = if (v303_10).is_empty() { Space::new() } else {
      let v308_11: Space = unwrap(&(v302_11),&(v302_18_head));
      let mut v308_12 = Space::new();
      let mut v308_12_cursor = (v308_11).read_zipper();
      for v308_12_byte in v308_12_cursor.child_mask().iter() {
        v308_12_cursor.descend_to_byte(v308_12_byte);
        let v308_12_tail = v308_12_cursor.make_map();
        v308_12_cursor.ascend(1);
        let v308_12_head = Path::from_slice(&[v308_12_byte]);
        let v309_2: Space = singleton(&(v308_12_head));
        let v309_3: Space = intersect(&(*CONSTANT_2),&(v309_2));
        let v309_4: Space = if has_head(&(v309_3)) { singleton(&[]) } else { Space::new() };
        drop(v309_3);
        let v309_5: Space = subtract(&(*CONSTANT_1),&(v309_4));
        drop(v309_4);
        let v309_7: Space = if (v309_5).is_empty() { Space::new() } else {
          let v310_6: Space = routine_61(c, &(v308_12_head), &(*p1), &(v308_12_tail));
          compose(&(v309_5),&(v310_6))
        };
        drop(v309_5);
        let v309_8: Space = intersect(&(*CONSTANT_2),&(v309_2));
        drop(v309_2);
        let v309_9: Space = if has_head(&(v309_8)) { singleton(&[]) } else { Space::new() };
        drop(v309_8);
        let v309_11: Space = if (v309_9).is_empty() { Space::new() } else {
          let v311_10: Space = routine_62(c, &(v308_12_head), &(*p1), &(v308_12_tail));
          compose(&(v309_9),&(v311_10))
        };
        drop(v309_9);
        let v309_12: Space = unite(&(v309_7),&(v309_11));
        v308_12.join_into((v309_12).clone());
      }
      drop(v308_12_cursor);
      drop(v308_11);
      compose(&(v303_10),&(v308_12))
    };
    drop(v303_10);
    let v303_14: Space = unite(&(v303_8),&(v303_13));
    v302_18.join_into((v303_14).clone());
  }
  drop(v302_18_cursor);
  drop(v302_11);
  (v302_18).clone()
}

fn routine_29(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v312_5: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v312_7: Space = unwrap(&(v312_5),&(*CONSTANT_5));
  drop(v312_5);
  let v312_8: Space = unwrap(&(v312_7),&(*p0));
  drop(v312_7);
  let mut v312_18 = Space::new();
  let mut v312_18_cursor = (v312_8).read_zipper();
  for v312_18_byte in v312_18_cursor.child_mask().iter() {
    v312_18_cursor.descend_to_byte(v312_18_byte);
    let v312_18_tail = v312_18_cursor.make_map();
    v312_18_cursor.ascend(1);
    let v312_18_head = Path::from_slice(&[v312_18_byte]);
    let v313_2: Space = singleton(&(v312_18_head));
    let v313_3: Space = intersect(&(*CONSTANT_2),&(v313_2));
    let v313_4: Space = if has_head(&(v313_3)) { singleton(&[]) } else { Space::new() };
    drop(v313_3);
    let v313_5: Space = subtract(&(*CONSTANT_1),&(v313_4));
    drop(v313_4);
    let v313_7: Space = if (v313_5).is_empty() { Space::new() } else {
      let mut v314_6 = Space::new();
      let mut v314_6_cursor = (v312_18_tail).read_zipper();
      for v314_6_byte in v314_6_cursor.child_mask().iter() {
        v314_6_cursor.descend_to_byte(v314_6_byte);
        let v314_6_tail = v314_6_cursor.make_map();
        v314_6_cursor.ascend(1);
        let v314_6_head = Path::from_slice(&[v314_6_byte]);
        let v315_2: Space = singleton(&(v314_6_head));
        let v315_3: Space = intersect(&(*CONSTANT_2),&(v315_2));
        let v315_4: Space = if has_head(&(v315_3)) { singleton(&[]) } else { Space::new() };
        drop(v315_3);
        let v315_5: Space = subtract(&(*CONSTANT_1),&(v315_4));
        drop(v315_4);
        let v315_8: Space = if (v315_5).is_empty() { Space::new() } else {
          let v316_6: Path = concat_path(&(v312_18_head),&(v314_6_head));
          let v316_7: Space = routine_65(c, &(v316_6), &(*p1), &(v314_6_tail));
          compose(&(v315_5),&(v316_7))
        };
        drop(v315_5);
        let v315_9: Space = intersect(&(*CONSTANT_2),&(v315_2));
        drop(v315_2);
        let v315_10: Space = if has_head(&(v315_9)) { singleton(&[]) } else { Space::new() };
        drop(v315_9);
        let v315_12: Space = if (v315_10).is_empty() { Space::new() } else {
          let v317_6: Path = concat_path(&(v312_18_head),&(v314_6_head));
          let v317_11: Space = routine_66(c, &(v317_6), &(*p1), &(v314_6_tail));
          drop(v317_6);
          compose(&(v315_10),&(v317_11))
        };
        drop(v315_10);
        let v315_13: Space = unite(&(v315_8),&(v315_12));
        v314_6.join_into((v315_13).clone());
      }
      drop(v314_6_cursor);
      compose(&(v313_5),&(v314_6))
    };
    drop(v313_5);
    let v313_8: Space = intersect(&(*CONSTANT_2),&(v313_2));
    drop(v313_2);
    let v313_9: Space = if has_head(&(v313_8)) { singleton(&[]) } else { Space::new() };
    drop(v313_8);
    let v313_11: Space = if (v313_9).is_empty() { Space::new() } else {
      let mut v318_10 = Space::new();
      let mut v318_10_cursor = (v312_18_tail).read_zipper();
      for v318_10_byte in v318_10_cursor.child_mask().iter() {
        v318_10_cursor.descend_to_byte(v318_10_byte);
        let v318_10_tail = v318_10_cursor.make_map();
        v318_10_cursor.ascend(1);
        let v318_10_head = Path::from_slice(&[v318_10_byte]);
        let v319_2: Space = singleton(&(v318_10_head));
        let v319_3: Space = intersect(&(*CONSTANT_2),&(v319_2));
        let v319_4: Space = if has_head(&(v319_3)) { singleton(&[]) } else { Space::new() };
        drop(v319_3);
        let v319_5: Space = subtract(&(*CONSTANT_1),&(v319_4));
        drop(v319_4);
        let v319_8: Space = if (v319_5).is_empty() { Space::new() } else {
          let v320_6: Path = concat_path(&(v312_18_head),&(v318_10_head));
          let v320_7: Space = routine_65(c, &(v320_6), &(*p1), &(v318_10_tail));
          compose(&(v319_5),&(v320_7))
        };
        drop(v319_5);
        let v319_9: Space = intersect(&(*CONSTANT_2),&(v319_2));
        drop(v319_2);
        let v319_10: Space = if has_head(&(v319_9)) { singleton(&[]) } else { Space::new() };
        drop(v319_9);
        let v319_12: Space = if (v319_10).is_empty() { Space::new() } else {
          let v321_6: Path = concat_path(&(v312_18_head),&(v318_10_head));
          let v321_11: Space = routine_67(c, &(v321_6), &(*p1), &(v318_10_tail));
          drop(v321_6);
          compose(&(v319_10),&(v321_11))
        };
        drop(v319_10);
        let v319_13: Space = unite(&(v319_8),&(v319_12));
        v318_10.join_into((v319_13).clone());
      }
      drop(v318_10_cursor);
      compose(&(v313_9),&(v318_10))
    };
    drop(v313_9);
    let v313_12: Space = unite(&(v313_7),&(v313_11));
    v312_18.join_into((v313_12).clone());
  }
  drop(v312_18_cursor);
  drop(v312_8);
  (v312_18).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v322_12 = Space::new();
  let mut v322_12_cursor = (*s0).read_zipper();
  for v322_12_byte in v322_12_cursor.child_mask().iter() {
    v322_12_cursor.descend_to_byte(v322_12_byte);
    let v322_12_tail = v322_12_cursor.make_map();
    v322_12_cursor.ascend(1);
    let v322_12_head = Path::from_slice(&[v322_12_byte]);
    let v323_2: Space = singleton(&(v322_12_head));
    let v323_3: Space = intersect(&(*CONSTANT_2),&(v323_2));
    let v323_4: Space = if has_head(&(v323_3)) { singleton(&[]) } else { Space::new() };
    drop(v323_3);
    let v323_5: Space = subtract(&(*CONSTANT_1),&(v323_4));
    drop(v323_4);
    let v323_8: Space = if (v323_5).is_empty() { Space::new() } else {
      let v324_6: Path = concat_path(&(*p0),&(v322_12_head));
      let mut v324_7 = Space::new();
      let mut v324_7_cursor = (v322_12_tail).read_zipper();
      for v324_7_byte in v324_7_cursor.child_mask().iter() {
        v324_7_cursor.descend_to_byte(v324_7_byte);
        let v324_7_tail = v324_7_cursor.make_map();
        v324_7_cursor.ascend(1);
        let v324_7_head = Path::from_slice(&[v324_7_byte]);
        let v325_2: Space = singleton(&(v324_7_head));
        let v325_3: Space = intersect(&(*CONSTANT_2),&(v325_2));
        let v325_4: Space = if has_head(&(v325_3)) { singleton(&[]) } else { Space::new() };
        drop(v325_3);
        let v325_5: Space = subtract(&(*CONSTANT_1),&(v325_4));
        drop(v325_4);
        let v325_8: Space = if (v325_5).is_empty() { Space::new() } else {
          let v326_6: Path = concat_path(&(v324_6),&(v324_7_head));
          let v326_7: Space = routine_68(c, &(v326_6), &(v324_7_tail), &(*s1));
          compose(&(v325_5),&(v326_7))
        };
        drop(v325_5);
        let v325_9: Space = intersect(&(*CONSTANT_2),&(v325_2));
        drop(v325_2);
        let v325_10: Space = if has_head(&(v325_9)) { singleton(&[]) } else { Space::new() };
        drop(v325_9);
        let v325_12: Space = if (v325_10).is_empty() { Space::new() } else {
          let v327_6: Path = concat_path(&(v324_6),&(v324_7_head));
          let v327_11: Space = routine_69(c, &(v327_6), &(v324_7_tail), &(*s1));
          drop(v327_6);
          compose(&(v325_10),&(v327_11))
        };
        drop(v325_10);
        let v325_13: Space = unite(&(v325_8),&(v325_12));
        v324_7.join_into((v325_13).clone());
      }
      drop(v324_7_cursor);
      compose(&(v323_5),&(v324_7))
    };
    drop(v323_5);
    let v323_9: Space = intersect(&(*CONSTANT_2),&(v323_2));
    drop(v323_2);
    let v323_10: Space = if has_head(&(v323_9)) { singleton(&[]) } else { Space::new() };
    drop(v323_9);
    let v323_12: Space = if (v323_10).is_empty() { Space::new() } else {
      let v328_6: Path = concat_path(&(*p0),&(v322_12_head));
      let mut v328_11 = Space::new();
      let mut v328_11_cursor = (v322_12_tail).read_zipper();
      for v328_11_byte in v328_11_cursor.child_mask().iter() {
        v328_11_cursor.descend_to_byte(v328_11_byte);
        let v328_11_tail = v328_11_cursor.make_map();
        v328_11_cursor.ascend(1);
        let v328_11_head = Path::from_slice(&[v328_11_byte]);
        let v329_2: Space = singleton(&(v328_11_head));
        let v329_3: Space = intersect(&(*CONSTANT_2),&(v329_2));
        let v329_4: Space = if has_head(&(v329_3)) { singleton(&[]) } else { Space::new() };
        drop(v329_3);
        let v329_5: Space = subtract(&(*CONSTANT_1),&(v329_4));
        drop(v329_4);
        let v329_8: Space = if (v329_5).is_empty() { Space::new() } else {
          let v330_6: Path = concat_path(&(v328_6),&(v328_11_head));
          let v330_7: Space = routine_68(c, &(v330_6), &(v328_11_tail), &(*s1));
          compose(&(v329_5),&(v330_7))
        };
        drop(v329_5);
        let v329_9: Space = intersect(&(*CONSTANT_2),&(v329_2));
        drop(v329_2);
        let v329_10: Space = if has_head(&(v329_9)) { singleton(&[]) } else { Space::new() };
        drop(v329_9);
        let v329_12: Space = if (v329_10).is_empty() { Space::new() } else {
          let v331_6: Path = concat_path(&(v328_6),&(v328_11_head));
          let v331_11: Space = routine_9(c, &(v331_6), &(v328_11_tail), &(*s1));
          drop(v331_6);
          compose(&(v329_10),&(v331_11))
        };
        drop(v329_10);
        let v329_13: Space = unite(&(v329_8),&(v329_12));
        v328_11.join_into((v329_13).clone());
      }
      drop(v328_11_cursor);
      drop(v328_6);
      compose(&(v323_10),&(v328_11))
    };
    drop(v323_10);
    let v323_13: Space = unite(&(v323_8),&(v323_12));
    v322_12.join_into((v323_13).clone());
  }
  drop(v322_12_cursor);
  (v322_12).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v332_12 = Space::new();
  let mut v332_12_cursor = (*s0).read_zipper();
  for v332_12_byte in v332_12_cursor.child_mask().iter() {
    v332_12_cursor.descend_to_byte(v332_12_byte);
    let v332_12_tail = v332_12_cursor.make_map();
    v332_12_cursor.ascend(1);
    let v332_12_head = Path::from_slice(&[v332_12_byte]);
    let v333_2: Space = singleton(&(v332_12_head));
    let v333_3: Space = intersect(&(*CONSTANT_2),&(v333_2));
    let v333_4: Space = if has_head(&(v333_3)) { singleton(&[]) } else { Space::new() };
    drop(v333_3);
    let v333_5: Space = subtract(&(*CONSTANT_1),&(v333_4));
    drop(v333_4);
    let v333_8: Space = if (v333_5).is_empty() { Space::new() } else {
      let v334_6: Path = concat_path(&(*p0),&(v332_12_head));
      let mut v334_7 = Space::new();
      let mut v334_7_cursor = (v332_12_tail).read_zipper();
      for v334_7_byte in v334_7_cursor.child_mask().iter() {
        v334_7_cursor.descend_to_byte(v334_7_byte);
        let v334_7_tail = v334_7_cursor.make_map();
        v334_7_cursor.ascend(1);
        let v334_7_head = Path::from_slice(&[v334_7_byte]);
        let v335_2: Space = singleton(&(v334_7_head));
        let v335_3: Space = intersect(&(*CONSTANT_2),&(v335_2));
        let v335_4: Space = if has_head(&(v335_3)) { singleton(&[]) } else { Space::new() };
        drop(v335_3);
        let v335_5: Space = subtract(&(*CONSTANT_1),&(v335_4));
        drop(v335_4);
        let v335_8: Space = if (v335_5).is_empty() { Space::new() } else {
          let v336_6: Path = concat_path(&(v334_6),&(v334_7_head));
          let v336_7: Space = routine_68(c, &(v336_6), &(v334_7_tail), &(*s1));
          compose(&(v335_5),&(v336_7))
        };
        drop(v335_5);
        let v335_9: Space = intersect(&(*CONSTANT_2),&(v335_2));
        drop(v335_2);
        let v335_10: Space = if has_head(&(v335_9)) { singleton(&[]) } else { Space::new() };
        drop(v335_9);
        let v335_12: Space = if (v335_10).is_empty() { Space::new() } else {
          let v337_6: Path = concat_path(&(v334_6),&(v334_7_head));
          let v337_11: Space = routine_69(c, &(v337_6), &(v334_7_tail), &(*s1));
          drop(v337_6);
          compose(&(v335_10),&(v337_11))
        };
        drop(v335_10);
        let v335_13: Space = unite(&(v335_8),&(v335_12));
        v334_7.join_into((v335_13).clone());
      }
      drop(v334_7_cursor);
      compose(&(v333_5),&(v334_7))
    };
    drop(v333_5);
    let v333_9: Space = intersect(&(*CONSTANT_2),&(v333_2));
    drop(v333_2);
    let v333_10: Space = if has_head(&(v333_9)) { singleton(&[]) } else { Space::new() };
    drop(v333_9);
    let v333_12: Space = if (v333_10).is_empty() { Space::new() } else {
      let v338_6: Path = concat_path(&(*p0),&(v332_12_head));
      let mut v338_11 = Space::new();
      let mut v338_11_cursor = (v332_12_tail).read_zipper();
      for v338_11_byte in v338_11_cursor.child_mask().iter() {
        v338_11_cursor.descend_to_byte(v338_11_byte);
        let v338_11_tail = v338_11_cursor.make_map();
        v338_11_cursor.ascend(1);
        let v338_11_head = Path::from_slice(&[v338_11_byte]);
        let v339_2: Space = singleton(&(v338_11_head));
        let v339_3: Space = intersect(&(*CONSTANT_2),&(v339_2));
        let v339_4: Space = if has_head(&(v339_3)) { singleton(&[]) } else { Space::new() };
        drop(v339_3);
        let v339_5: Space = subtract(&(*CONSTANT_1),&(v339_4));
        drop(v339_4);
        let v339_7: Space = if (v339_5).is_empty() { Space::new() } else {
          let v340_6: Space = routine_32(c, &(v338_11_head), &(v338_6), &(v338_11_tail), &(*s1));
          compose(&(v339_5),&(v340_6))
        };
        drop(v339_5);
        let v339_8: Space = intersect(&(*CONSTANT_2),&(v339_2));
        drop(v339_2);
        let v339_9: Space = if has_head(&(v339_8)) { singleton(&[]) } else { Space::new() };
        drop(v339_8);
        let v339_11: Space = if (v339_9).is_empty() { Space::new() } else {
          let v341_10: Space = routine_33(c, &(v338_11_head), &(v338_6), &(v338_11_tail), &(*s1));
          compose(&(v339_9),&(v341_10))
        };
        drop(v339_9);
        let v339_12: Space = unite(&(v339_7),&(v339_11));
        v338_11.join_into((v339_12).clone());
      }
      drop(v338_11_cursor);
      drop(v338_6);
      compose(&(v333_10),&(v338_11))
    };
    drop(v333_10);
    let v333_13: Space = unite(&(v333_8),&(v333_12));
    v332_12.join_into((v333_13).clone());
  }
  drop(v332_12_cursor);
  (v332_12).clone()
}

fn routine_32(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v342_13 = Space::new();
  let mut v342_13_cursor = (*s0).read_zipper();
  for v342_13_byte in v342_13_cursor.child_mask().iter() {
    v342_13_cursor.descend_to_byte(v342_13_byte);
    let v342_13_tail = v342_13_cursor.make_map();
    v342_13_cursor.ascend(1);
    let v342_13_head = Path::from_slice(&[v342_13_byte]);
    let v343_2: Space = singleton(&(v342_13_head));
    let v343_3: Space = intersect(&(*CONSTANT_2),&(v343_2));
    let v343_4: Space = if has_head(&(v343_3)) { singleton(&[]) } else { Space::new() };
    drop(v343_3);
    let v343_5: Space = subtract(&(*CONSTANT_1),&(v343_4));
    drop(v343_4);
    let v343_8: Space = if (v343_5).is_empty() { Space::new() } else {
      let v344_6: Path = concat_path(&(*p0),&(v342_13_head));
      let mut v344_7 = Space::new();
      let mut v344_7_cursor = (v342_13_tail).read_zipper();
      for v344_7_byte in v344_7_cursor.child_mask().iter() {
        v344_7_cursor.descend_to_byte(v344_7_byte);
        let v344_7_tail = v344_7_cursor.make_map();
        v344_7_cursor.ascend(1);
        let v344_7_head = Path::from_slice(&[v344_7_byte]);
        let v345_2: Space = singleton(&(v344_7_head));
        let v345_3: Space = intersect(&(*CONSTANT_2),&(v345_2));
        let v345_4: Space = if has_head(&(v345_3)) { singleton(&[]) } else { Space::new() };
        drop(v345_3);
        let v345_5: Space = subtract(&(*CONSTANT_1),&(v345_4));
        drop(v345_4);
        let v345_8: Space = if (v345_5).is_empty() { Space::new() } else {
          let v346_6: Path = concat_path(&(v344_6),&(v344_7_head));
          let v346_7: Space = routine_70(c, &(v346_6), &(*p1), &(v344_7_tail), &(*s1));
          compose(&(v345_5),&(v346_7))
        };
        drop(v345_5);
        let v345_9: Space = intersect(&(*CONSTANT_2),&(v345_2));
        drop(v345_2);
        let v345_10: Space = if has_head(&(v345_9)) { singleton(&[]) } else { Space::new() };
        drop(v345_9);
        let v345_12: Space = if (v345_10).is_empty() { Space::new() } else {
          let v347_6: Path = concat_path(&(v344_6),&(v344_7_head));
          let v347_11: Space = routine_71(c, &(v347_6), &(*p1), &(v344_7_tail), &(*s1));
          drop(v347_6);
          compose(&(v345_10),&(v347_11))
        };
        drop(v345_10);
        let v345_13: Space = unite(&(v345_8),&(v345_12));
        v344_7.join_into((v345_13).clone());
      }
      drop(v344_7_cursor);
      compose(&(v343_5),&(v344_7))
    };
    drop(v343_5);
    let v343_9: Space = intersect(&(*CONSTANT_2),&(v343_2));
    drop(v343_2);
    let v343_10: Space = if has_head(&(v343_9)) { singleton(&[]) } else { Space::new() };
    drop(v343_9);
    let v343_12: Space = if (v343_10).is_empty() { Space::new() } else {
      let v348_6: Path = concat_path(&(*p0),&(v342_13_head));
      let mut v348_11 = Space::new();
      let mut v348_11_cursor = (v342_13_tail).read_zipper();
      for v348_11_byte in v348_11_cursor.child_mask().iter() {
        v348_11_cursor.descend_to_byte(v348_11_byte);
        let v348_11_tail = v348_11_cursor.make_map();
        v348_11_cursor.ascend(1);
        let v348_11_head = Path::from_slice(&[v348_11_byte]);
        let v349_2: Space = singleton(&(v348_11_head));
        let v349_3: Space = intersect(&(*CONSTANT_2),&(v349_2));
        let v349_4: Space = if has_head(&(v349_3)) { singleton(&[]) } else { Space::new() };
        drop(v349_3);
        let v349_5: Space = subtract(&(*CONSTANT_1),&(v349_4));
        drop(v349_4);
        let v349_8: Space = if (v349_5).is_empty() { Space::new() } else {
          let v350_6: Path = concat_path(&(v348_6),&(v348_11_head));
          let v350_7: Space = routine_70(c, &(v350_6), &(*p1), &(v348_11_tail), &(*s1));
          compose(&(v349_5),&(v350_7))
        };
        drop(v349_5);
        let v349_9: Space = intersect(&(*CONSTANT_2),&(v349_2));
        drop(v349_2);
        let v349_10: Space = if has_head(&(v349_9)) { singleton(&[]) } else { Space::new() };
        drop(v349_9);
        let v349_12: Space = if (v349_10).is_empty() { Space::new() } else {
          let v351_6: Path = concat_path(&(v348_6),&(v348_11_head));
          let v351_11: Space = routine_36(c, &(v351_6), &(*p1), &(v348_11_tail), &(*s1));
          drop(v351_6);
          compose(&(v349_10),&(v351_11))
        };
        drop(v349_10);
        let v349_13: Space = unite(&(v349_8),&(v349_12));
        v348_11.join_into((v349_13).clone());
      }
      drop(v348_11_cursor);
      drop(v348_6);
      compose(&(v343_10),&(v348_11))
    };
    drop(v343_10);
    let v343_13: Space = unite(&(v343_8),&(v343_12));
    v342_13.join_into((v343_13).clone());
  }
  drop(v342_13_cursor);
  (v342_13).clone()
}

fn routine_33(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v352_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v352_10: Space = unwrap(&(v352_8),&(*CONSTANT_5));
  drop(v352_8);
  let v352_11: Space = unwrap(&(v352_10),&(*p0));
  drop(v352_10);
  let mut v352_18 = Space::new();
  let mut v352_18_cursor = (*s0).read_zipper();
  for v352_18_byte in v352_18_cursor.child_mask().iter() {
    v352_18_cursor.descend_to_byte(v352_18_byte);
    let v352_18_tail = v352_18_cursor.make_map();
    v352_18_cursor.ascend(1);
    let v352_18_head = Path::from_slice(&[v352_18_byte]);
    let v353_2: Space = singleton(&(v352_18_head));
    let v353_3: Space = intersect(&(*CONSTANT_2),&(v353_2));
    let v353_4: Space = if has_head(&(v353_3)) { singleton(&[]) } else { Space::new() };
    drop(v353_3);
    let v353_5: Space = subtract(&(*CONSTANT_1),&(v353_4));
    drop(v353_4);
    let v353_8: Space = if (v353_5).is_empty() { Space::new() } else {
      let v354_6: Path = concat_path(&(*p0),&(v352_18_head));
      let mut v354_7 = Space::new();
      let mut v354_7_cursor = (v352_18_tail).read_zipper();
      for v354_7_byte in v354_7_cursor.child_mask().iter() {
        v354_7_cursor.descend_to_byte(v354_7_byte);
        let v354_7_tail = v354_7_cursor.make_map();
        v354_7_cursor.ascend(1);
        let v354_7_head = Path::from_slice(&[v354_7_byte]);
        let v355_2: Space = singleton(&(v354_7_head));
        let v355_3: Space = intersect(&(*CONSTANT_2),&(v355_2));
        let v355_4: Space = if has_head(&(v355_3)) { singleton(&[]) } else { Space::new() };
        drop(v355_3);
        let v355_5: Space = subtract(&(*CONSTANT_1),&(v355_4));
        drop(v355_4);
        let v355_8: Space = if (v355_5).is_empty() { Space::new() } else {
          let v356_6: Path = concat_path(&(v354_6),&(v354_7_head));
          let v356_7: Space = routine_70(c, &(v356_6), &(*p1), &(v354_7_tail), &(*s1));
          compose(&(v355_5),&(v356_7))
        };
        drop(v355_5);
        let v355_9: Space = intersect(&(*CONSTANT_2),&(v355_2));
        drop(v355_2);
        let v355_10: Space = if has_head(&(v355_9)) { singleton(&[]) } else { Space::new() };
        drop(v355_9);
        let v355_12: Space = if (v355_10).is_empty() { Space::new() } else {
          let v357_6: Path = concat_path(&(v354_6),&(v354_7_head));
          let v357_11: Space = routine_71(c, &(v357_6), &(*p1), &(v354_7_tail), &(*s1));
          drop(v357_6);
          compose(&(v355_10),&(v357_11))
        };
        drop(v355_10);
        let v355_13: Space = unite(&(v355_8),&(v355_12));
        v354_7.join_into((v355_13).clone());
      }
      drop(v354_7_cursor);
      drop(v354_6);
      compose(&(v353_5),&(v354_7))
    };
    drop(v353_5);
    let v353_9: Space = intersect(&(*CONSTANT_2),&(v353_2));
    drop(v353_2);
    let v353_10: Space = if has_head(&(v353_9)) { singleton(&[]) } else { Space::new() };
    drop(v353_9);
    let v353_13: Space = if (v353_10).is_empty() { Space::new() } else {
      let v358_11: Space = unwrap(&(v352_11),&(v352_18_head));
      let mut v358_12 = Space::new();
      let mut v358_12_cursor = (v358_11).read_zipper();
      for v358_12_byte in v358_12_cursor.child_mask().iter() {
        v358_12_cursor.descend_to_byte(v358_12_byte);
        let v358_12_tail = v358_12_cursor.make_map();
        v358_12_cursor.ascend(1);
        let v358_12_head = Path::from_slice(&[v358_12_byte]);
        let v359_2: Space = singleton(&(v358_12_head));
        let v359_3: Space = intersect(&(*CONSTANT_2),&(v359_2));
        let v359_4: Space = if has_head(&(v359_3)) { singleton(&[]) } else { Space::new() };
        drop(v359_3);
        let v359_5: Space = subtract(&(*CONSTANT_1),&(v359_4));
        drop(v359_4);
        let v359_7: Space = if (v359_5).is_empty() { Space::new() } else {
          let v360_6: Space = routine_72(c, &(v358_12_head), &(*p1), &(v358_12_tail));
          compose(&(v359_5),&(v360_6))
        };
        drop(v359_5);
        let v359_8: Space = intersect(&(*CONSTANT_2),&(v359_2));
        drop(v359_2);
        let v359_9: Space = if has_head(&(v359_8)) { singleton(&[]) } else { Space::new() };
        drop(v359_8);
        let v359_11: Space = if (v359_9).is_empty() { Space::new() } else {
          let v361_10: Space = routine_73(c, &(v358_12_head), &(*p1), &(v358_12_tail));
          compose(&(v359_9),&(v361_10))
        };
        drop(v359_9);
        let v359_12: Space = unite(&(v359_7),&(v359_11));
        v358_12.join_into((v359_12).clone());
      }
      drop(v358_12_cursor);
      drop(v358_11);
      compose(&(v353_10),&(v358_12))
    };
    drop(v353_10);
    let v353_14: Space = unite(&(v353_8),&(v353_13));
    v352_18.join_into((v353_14).clone());
  }
  drop(v352_18_cursor);
  drop(v352_11);
  (v352_18).clone()
}

fn routine_34(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v362_13 = Space::new();
  let mut v362_13_cursor = (*s0).read_zipper();
  for v362_13_byte in v362_13_cursor.child_mask().iter() {
    v362_13_cursor.descend_to_byte(v362_13_byte);
    let v362_13_tail = v362_13_cursor.make_map();
    v362_13_cursor.ascend(1);
    let v362_13_head = Path::from_slice(&[v362_13_byte]);
    let v363_2: Space = singleton(&(v362_13_head));
    let v363_3: Space = intersect(&(*CONSTANT_2),&(v363_2));
    let v363_4: Space = if has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
    drop(v363_3);
    let v363_5: Space = subtract(&(*CONSTANT_1),&(v363_4));
    drop(v363_4);
    let v363_8: Space = if (v363_5).is_empty() { Space::new() } else {
      let v364_6: Path = concat_path(&(*p0),&(v362_13_head));
      let mut v364_7 = Space::new();
      let mut v364_7_cursor = (v362_13_tail).read_zipper();
      for v364_7_byte in v364_7_cursor.child_mask().iter() {
        v364_7_cursor.descend_to_byte(v364_7_byte);
        let v364_7_tail = v364_7_cursor.make_map();
        v364_7_cursor.ascend(1);
        let v364_7_head = Path::from_slice(&[v364_7_byte]);
        let v365_2: Space = singleton(&(v364_7_head));
        let v365_3: Space = intersect(&(*CONSTANT_2),&(v365_2));
        let v365_4: Space = if has_head(&(v365_3)) { singleton(&[]) } else { Space::new() };
        drop(v365_3);
        let v365_5: Space = subtract(&(*CONSTANT_1),&(v365_4));
        drop(v365_4);
        let v365_8: Space = if (v365_5).is_empty() { Space::new() } else {
          let v366_6: Path = concat_path(&(v364_6),&(v364_7_head));
          let v366_7: Space = routine_74(c, &(v366_6), &(*p1), &(v364_7_tail), &(*s1));
          compose(&(v365_5),&(v366_7))
        };
        drop(v365_5);
        let v365_9: Space = intersect(&(*CONSTANT_2),&(v365_2));
        drop(v365_2);
        let v365_10: Space = if has_head(&(v365_9)) { singleton(&[]) } else { Space::new() };
        drop(v365_9);
        let v365_12: Space = if (v365_10).is_empty() { Space::new() } else {
          let v367_6: Path = concat_path(&(v364_6),&(v364_7_head));
          let v367_11: Space = routine_75(c, &(v367_6), &(*p1), &(v364_7_tail), &(*s1));
          drop(v367_6);
          compose(&(v365_10),&(v367_11))
        };
        drop(v365_10);
        let v365_13: Space = unite(&(v365_8),&(v365_12));
        v364_7.join_into((v365_13).clone());
      }
      drop(v364_7_cursor);
      compose(&(v363_5),&(v364_7))
    };
    drop(v363_5);
    let v363_9: Space = intersect(&(*CONSTANT_2),&(v363_2));
    drop(v363_2);
    let v363_10: Space = if has_head(&(v363_9)) { singleton(&[]) } else { Space::new() };
    drop(v363_9);
    let v363_12: Space = if (v363_10).is_empty() { Space::new() } else {
      let v368_6: Path = concat_path(&(*p0),&(v362_13_head));
      let mut v368_11 = Space::new();
      let mut v368_11_cursor = (v362_13_tail).read_zipper();
      for v368_11_byte in v368_11_cursor.child_mask().iter() {
        v368_11_cursor.descend_to_byte(v368_11_byte);
        let v368_11_tail = v368_11_cursor.make_map();
        v368_11_cursor.ascend(1);
        let v368_11_head = Path::from_slice(&[v368_11_byte]);
        let v369_2: Space = singleton(&(v368_11_head));
        let v369_3: Space = intersect(&(*CONSTANT_2),&(v369_2));
        let v369_4: Space = if has_head(&(v369_3)) { singleton(&[]) } else { Space::new() };
        drop(v369_3);
        let v369_5: Space = subtract(&(*CONSTANT_1),&(v369_4));
        drop(v369_4);
        let v369_8: Space = if (v369_5).is_empty() { Space::new() } else {
          let v370_6: Path = concat_path(&(v368_6),&(v368_11_head));
          let v370_7: Space = routine_74(c, &(v370_6), &(*p1), &(v368_11_tail), &(*s1));
          compose(&(v369_5),&(v370_7))
        };
        drop(v369_5);
        let v369_9: Space = intersect(&(*CONSTANT_2),&(v369_2));
        drop(v369_2);
        let v369_10: Space = if has_head(&(v369_9)) { singleton(&[]) } else { Space::new() };
        drop(v369_9);
        let v369_12: Space = if (v369_10).is_empty() { Space::new() } else {
          let v371_6: Path = concat_path(&(v368_6),&(v368_11_head));
          let v371_11: Space = routine_36(c, &(v371_6), &(*p1), &(v368_11_tail), &(*s1));
          drop(v371_6);
          compose(&(v369_10),&(v371_11))
        };
        drop(v369_10);
        let v369_13: Space = unite(&(v369_8),&(v369_12));
        v368_11.join_into((v369_13).clone());
      }
      drop(v368_11_cursor);
      drop(v368_6);
      compose(&(v363_10),&(v368_11))
    };
    drop(v363_10);
    let v363_13: Space = unite(&(v363_8),&(v363_12));
    v362_13.join_into((v363_13).clone());
  }
  drop(v362_13_cursor);
  (v362_13).clone()
}

fn routine_35(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v372_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v372_10: Space = unwrap(&(v372_8),&(*CONSTANT_5));
  drop(v372_8);
  let v372_11: Space = unwrap(&(v372_10),&(*p0));
  drop(v372_10);
  let mut v372_18 = Space::new();
  let mut v372_18_cursor = (*s0).read_zipper();
  for v372_18_byte in v372_18_cursor.child_mask().iter() {
    v372_18_cursor.descend_to_byte(v372_18_byte);
    let v372_18_tail = v372_18_cursor.make_map();
    v372_18_cursor.ascend(1);
    let v372_18_head = Path::from_slice(&[v372_18_byte]);
    let v373_2: Space = singleton(&(v372_18_head));
    let v373_3: Space = intersect(&(*CONSTANT_2),&(v373_2));
    let v373_4: Space = if has_head(&(v373_3)) { singleton(&[]) } else { Space::new() };
    drop(v373_3);
    let v373_5: Space = subtract(&(*CONSTANT_1),&(v373_4));
    drop(v373_4);
    let v373_8: Space = if (v373_5).is_empty() { Space::new() } else {
      let v374_6: Path = concat_path(&(*p0),&(v372_18_head));
      let mut v374_7 = Space::new();
      let mut v374_7_cursor = (v372_18_tail).read_zipper();
      for v374_7_byte in v374_7_cursor.child_mask().iter() {
        v374_7_cursor.descend_to_byte(v374_7_byte);
        let v374_7_tail = v374_7_cursor.make_map();
        v374_7_cursor.ascend(1);
        let v374_7_head = Path::from_slice(&[v374_7_byte]);
        let v375_2: Space = singleton(&(v374_7_head));
        let v375_3: Space = intersect(&(*CONSTANT_2),&(v375_2));
        let v375_4: Space = if has_head(&(v375_3)) { singleton(&[]) } else { Space::new() };
        drop(v375_3);
        let v375_5: Space = subtract(&(*CONSTANT_1),&(v375_4));
        drop(v375_4);
        let v375_8: Space = if (v375_5).is_empty() { Space::new() } else {
          let v376_6: Path = concat_path(&(v374_6),&(v374_7_head));
          let v376_7: Space = routine_74(c, &(v376_6), &(*p1), &(v374_7_tail), &(*s1));
          compose(&(v375_5),&(v376_7))
        };
        drop(v375_5);
        let v375_9: Space = intersect(&(*CONSTANT_2),&(v375_2));
        drop(v375_2);
        let v375_10: Space = if has_head(&(v375_9)) { singleton(&[]) } else { Space::new() };
        drop(v375_9);
        let v375_12: Space = if (v375_10).is_empty() { Space::new() } else {
          let v377_6: Path = concat_path(&(v374_6),&(v374_7_head));
          let v377_11: Space = routine_75(c, &(v377_6), &(*p1), &(v374_7_tail), &(*s1));
          drop(v377_6);
          compose(&(v375_10),&(v377_11))
        };
        drop(v375_10);
        let v375_13: Space = unite(&(v375_8),&(v375_12));
        v374_7.join_into((v375_13).clone());
      }
      drop(v374_7_cursor);
      drop(v374_6);
      compose(&(v373_5),&(v374_7))
    };
    drop(v373_5);
    let v373_9: Space = intersect(&(*CONSTANT_2),&(v373_2));
    drop(v373_2);
    let v373_10: Space = if has_head(&(v373_9)) { singleton(&[]) } else { Space::new() };
    drop(v373_9);
    let v373_13: Space = if (v373_10).is_empty() { Space::new() } else {
      let v378_11: Space = unwrap(&(v372_11),&(v372_18_head));
      let mut v378_12 = Space::new();
      let mut v378_12_cursor = (v378_11).read_zipper();
      for v378_12_byte in v378_12_cursor.child_mask().iter() {
        v378_12_cursor.descend_to_byte(v378_12_byte);
        let v378_12_tail = v378_12_cursor.make_map();
        v378_12_cursor.ascend(1);
        let v378_12_head = Path::from_slice(&[v378_12_byte]);
        let v379_2: Space = singleton(&(v378_12_head));
        let v379_3: Space = intersect(&(*CONSTANT_2),&(v379_2));
        let v379_4: Space = if has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
        drop(v379_3);
        let v379_5: Space = subtract(&(*CONSTANT_1),&(v379_4));
        drop(v379_4);
        let v379_7: Space = if (v379_5).is_empty() { Space::new() } else {
          let v380_6: Space = routine_72(c, &(v378_12_head), &(*p1), &(v378_12_tail));
          compose(&(v379_5),&(v380_6))
        };
        drop(v379_5);
        let v379_8: Space = intersect(&(*CONSTANT_2),&(v379_2));
        drop(v379_2);
        let v379_9: Space = if has_head(&(v379_8)) { singleton(&[]) } else { Space::new() };
        drop(v379_8);
        let v379_11: Space = if (v379_9).is_empty() { Space::new() } else {
          let v381_10: Space = routine_73(c, &(v378_12_head), &(*p1), &(v378_12_tail));
          compose(&(v379_9),&(v381_10))
        };
        drop(v379_9);
        let v379_12: Space = unite(&(v379_7),&(v379_11));
        v378_12.join_into((v379_12).clone());
      }
      drop(v378_12_cursor);
      drop(v378_11);
      compose(&(v373_10),&(v378_12))
    };
    drop(v373_10);
    let v373_14: Space = unite(&(v373_8),&(v373_13));
    v372_18.join_into((v373_14).clone());
  }
  drop(v372_18_cursor);
  drop(v372_11);
  (v372_18).clone()
}

fn routine_36(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v382_5: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v382_7: Space = unwrap(&(v382_5),&(*CONSTANT_5));
  drop(v382_5);
  let v382_8: Space = unwrap(&(v382_7),&(*p0));
  drop(v382_7);
  let mut v382_18 = Space::new();
  let mut v382_18_cursor = (v382_8).read_zipper();
  for v382_18_byte in v382_18_cursor.child_mask().iter() {
    v382_18_cursor.descend_to_byte(v382_18_byte);
    let v382_18_tail = v382_18_cursor.make_map();
    v382_18_cursor.ascend(1);
    let v382_18_head = Path::from_slice(&[v382_18_byte]);
    let v383_2: Space = singleton(&(v382_18_head));
    let v383_3: Space = intersect(&(*CONSTANT_2),&(v383_2));
    let v383_4: Space = if has_head(&(v383_3)) { singleton(&[]) } else { Space::new() };
    drop(v383_3);
    let v383_5: Space = subtract(&(*CONSTANT_1),&(v383_4));
    drop(v383_4);
    let v383_7: Space = if (v383_5).is_empty() { Space::new() } else {
      let mut v384_6 = Space::new();
      let mut v384_6_cursor = (v382_18_tail).read_zipper();
      for v384_6_byte in v384_6_cursor.child_mask().iter() {
        v384_6_cursor.descend_to_byte(v384_6_byte);
        let v384_6_tail = v384_6_cursor.make_map();
        v384_6_cursor.ascend(1);
        let v384_6_head = Path::from_slice(&[v384_6_byte]);
        let v385_2: Space = singleton(&(v384_6_head));
        let v385_3: Space = intersect(&(*CONSTANT_2),&(v385_2));
        let v385_4: Space = if has_head(&(v385_3)) { singleton(&[]) } else { Space::new() };
        drop(v385_3);
        let v385_5: Space = subtract(&(*CONSTANT_1),&(v385_4));
        drop(v385_4);
        let v385_8: Space = if (v385_5).is_empty() { Space::new() } else {
          let v386_6: Path = concat_path(&(v382_18_head),&(v384_6_head));
          let v386_7: Space = routine_76(c, &(v386_6), &(*p1), &(v384_6_tail));
          compose(&(v385_5),&(v386_7))
        };
        drop(v385_5);
        let v385_9: Space = intersect(&(*CONSTANT_2),&(v385_2));
        drop(v385_2);
        let v385_10: Space = if has_head(&(v385_9)) { singleton(&[]) } else { Space::new() };
        drop(v385_9);
        let v385_12: Space = if (v385_10).is_empty() { Space::new() } else {
          let v387_6: Path = concat_path(&(v382_18_head),&(v384_6_head));
          let v387_11: Space = routine_77(c, &(v387_6), &(*p1), &(v384_6_tail));
          drop(v387_6);
          compose(&(v385_10),&(v387_11))
        };
        drop(v385_10);
        let v385_13: Space = unite(&(v385_8),&(v385_12));
        v384_6.join_into((v385_13).clone());
      }
      drop(v384_6_cursor);
      compose(&(v383_5),&(v384_6))
    };
    drop(v383_5);
    let v383_8: Space = intersect(&(*CONSTANT_2),&(v383_2));
    drop(v383_2);
    let v383_9: Space = if has_head(&(v383_8)) { singleton(&[]) } else { Space::new() };
    drop(v383_8);
    let v383_11: Space = if (v383_9).is_empty() { Space::new() } else {
      let mut v388_10 = Space::new();
      let mut v388_10_cursor = (v382_18_tail).read_zipper();
      for v388_10_byte in v388_10_cursor.child_mask().iter() {
        v388_10_cursor.descend_to_byte(v388_10_byte);
        let v388_10_tail = v388_10_cursor.make_map();
        v388_10_cursor.ascend(1);
        let v388_10_head = Path::from_slice(&[v388_10_byte]);
        let v389_2: Space = singleton(&(v388_10_head));
        let v389_3: Space = intersect(&(*CONSTANT_2),&(v389_2));
        let v389_4: Space = if has_head(&(v389_3)) { singleton(&[]) } else { Space::new() };
        drop(v389_3);
        let v389_5: Space = subtract(&(*CONSTANT_1),&(v389_4));
        drop(v389_4);
        let v389_8: Space = if (v389_5).is_empty() { Space::new() } else {
          let v390_6: Path = concat_path(&(v382_18_head),&(v388_10_head));
          let v390_7: Space = routine_76(c, &(v390_6), &(*p1), &(v388_10_tail));
          compose(&(v389_5),&(v390_7))
        };
        drop(v389_5);
        let v389_9: Space = intersect(&(*CONSTANT_2),&(v389_2));
        drop(v389_2);
        let v389_10: Space = if has_head(&(v389_9)) { singleton(&[]) } else { Space::new() };
        drop(v389_9);
        let v389_12: Space = if (v389_10).is_empty() { Space::new() } else {
          let v391_6: Path = concat_path(&(v382_18_head),&(v388_10_head));
          let v391_11: Space = routine_78(c, &(v391_6), &(*p1), &(v388_10_tail));
          drop(v391_6);
          compose(&(v389_10),&(v391_11))
        };
        drop(v389_10);
        let v389_13: Space = unite(&(v389_8),&(v389_12));
        v388_10.join_into((v389_13).clone());
      }
      drop(v388_10_cursor);
      compose(&(v383_9),&(v388_10))
    };
    drop(v383_9);
    let v383_12: Space = unite(&(v383_7),&(v383_11));
    v382_18.join_into((v383_12).clone());
  }
  drop(v382_18_cursor);
  drop(v382_8);
  (v382_18).clone()
}

fn routine_37(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v392_12 = Space::new();
  let mut v392_12_cursor = (*s0).read_zipper();
  for v392_12_byte in v392_12_cursor.child_mask().iter() {
    v392_12_cursor.descend_to_byte(v392_12_byte);
    let v392_12_tail = v392_12_cursor.make_map();
    v392_12_cursor.ascend(1);
    let v392_12_head = Path::from_slice(&[v392_12_byte]);
    let v393_2: Space = singleton(&(v392_12_head));
    let v393_3: Space = intersect(&(*CONSTANT_2),&(v393_2));
    let v393_4: Space = if has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
    drop(v393_3);
    let v393_5: Space = subtract(&(*CONSTANT_1),&(v393_4));
    drop(v393_4);
    let v393_8: Space = if (v393_5).is_empty() { Space::new() } else {
      let v394_6: Path = concat_path(&(*p0),&(v392_12_head));
      let mut v394_7 = Space::new();
      let mut v394_7_cursor = (v392_12_tail).read_zipper();
      for v394_7_byte in v394_7_cursor.child_mask().iter() {
        v394_7_cursor.descend_to_byte(v394_7_byte);
        let v394_7_tail = v394_7_cursor.make_map();
        v394_7_cursor.ascend(1);
        let v394_7_head = Path::from_slice(&[v394_7_byte]);
        let v395_2: Space = singleton(&(v394_7_head));
        let v395_3: Space = intersect(&(*CONSTANT_2),&(v395_2));
        let v395_4: Space = if has_head(&(v395_3)) { singleton(&[]) } else { Space::new() };
        drop(v395_3);
        let v395_5: Space = subtract(&(*CONSTANT_1),&(v395_4));
        drop(v395_4);
        let v395_8: Space = if (v395_5).is_empty() { Space::new() } else {
          let v396_6: Path = concat_path(&(v394_6),&(v394_7_head));
          let v396_7: Space = routine_79(c, &(v396_6), &(v394_7_tail), &(*s1));
          compose(&(v395_5),&(v396_7))
        };
        drop(v395_5);
        let v395_9: Space = intersect(&(*CONSTANT_2),&(v395_2));
        drop(v395_2);
        let v395_10: Space = if has_head(&(v395_9)) { singleton(&[]) } else { Space::new() };
        drop(v395_9);
        let v395_12: Space = if (v395_10).is_empty() { Space::new() } else {
          let v397_6: Path = concat_path(&(v394_6),&(v394_7_head));
          let v397_11: Space = routine_80(c, &(v397_6), &(v394_7_tail), &(*s1));
          drop(v397_6);
          compose(&(v395_10),&(v397_11))
        };
        drop(v395_10);
        let v395_13: Space = unite(&(v395_8),&(v395_12));
        v394_7.join_into((v395_13).clone());
      }
      drop(v394_7_cursor);
      compose(&(v393_5),&(v394_7))
    };
    drop(v393_5);
    let v393_9: Space = intersect(&(*CONSTANT_2),&(v393_2));
    drop(v393_2);
    let v393_10: Space = if has_head(&(v393_9)) { singleton(&[]) } else { Space::new() };
    drop(v393_9);
    let v393_12: Space = if (v393_10).is_empty() { Space::new() } else {
      let v398_6: Path = concat_path(&(*p0),&(v392_12_head));
      let mut v398_11 = Space::new();
      let mut v398_11_cursor = (v392_12_tail).read_zipper();
      for v398_11_byte in v398_11_cursor.child_mask().iter() {
        v398_11_cursor.descend_to_byte(v398_11_byte);
        let v398_11_tail = v398_11_cursor.make_map();
        v398_11_cursor.ascend(1);
        let v398_11_head = Path::from_slice(&[v398_11_byte]);
        let v399_2: Space = singleton(&(v398_11_head));
        let v399_3: Space = intersect(&(*CONSTANT_2),&(v399_2));
        let v399_4: Space = if has_head(&(v399_3)) { singleton(&[]) } else { Space::new() };
        drop(v399_3);
        let v399_5: Space = subtract(&(*CONSTANT_1),&(v399_4));
        drop(v399_4);
        let v399_8: Space = if (v399_5).is_empty() { Space::new() } else {
          let v400_6: Path = concat_path(&(v398_6),&(v398_11_head));
          let v400_7: Space = routine_79(c, &(v400_6), &(v398_11_tail), &(*s1));
          compose(&(v399_5),&(v400_7))
        };
        drop(v399_5);
        let v399_9: Space = intersect(&(*CONSTANT_2),&(v399_2));
        drop(v399_2);
        let v399_10: Space = if has_head(&(v399_9)) { singleton(&[]) } else { Space::new() };
        drop(v399_9);
        let v399_12: Space = if (v399_10).is_empty() { Space::new() } else {
          let v401_6: Path = concat_path(&(v398_6),&(v398_11_head));
          let v401_11: Space = routine_12(c, &(v401_6), &(v398_11_tail), &(*s1));
          drop(v401_6);
          compose(&(v399_10),&(v401_11))
        };
        drop(v399_10);
        let v399_13: Space = unite(&(v399_8),&(v399_12));
        v398_11.join_into((v399_13).clone());
      }
      drop(v398_11_cursor);
      drop(v398_6);
      compose(&(v393_10),&(v398_11))
    };
    drop(v393_10);
    let v393_13: Space = unite(&(v393_8),&(v393_12));
    v392_12.join_into((v393_13).clone());
  }
  drop(v392_12_cursor);
  (v392_12).clone()
}

fn routine_38(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v402_12 = Space::new();
  let mut v402_12_cursor = (*s0).read_zipper();
  for v402_12_byte in v402_12_cursor.child_mask().iter() {
    v402_12_cursor.descend_to_byte(v402_12_byte);
    let v402_12_tail = v402_12_cursor.make_map();
    v402_12_cursor.ascend(1);
    let v402_12_head = Path::from_slice(&[v402_12_byte]);
    let v403_2: Space = singleton(&(v402_12_head));
    let v403_3: Space = intersect(&(*CONSTANT_2),&(v403_2));
    let v403_4: Space = if has_head(&(v403_3)) { singleton(&[]) } else { Space::new() };
    drop(v403_3);
    let v403_5: Space = subtract(&(*CONSTANT_1),&(v403_4));
    drop(v403_4);
    let v403_8: Space = if (v403_5).is_empty() { Space::new() } else {
      let v404_6: Path = concat_path(&(*p0),&(v402_12_head));
      let mut v404_7 = Space::new();
      let mut v404_7_cursor = (v402_12_tail).read_zipper();
      for v404_7_byte in v404_7_cursor.child_mask().iter() {
        v404_7_cursor.descend_to_byte(v404_7_byte);
        let v404_7_tail = v404_7_cursor.make_map();
        v404_7_cursor.ascend(1);
        let v404_7_head = Path::from_slice(&[v404_7_byte]);
        let v405_2: Space = singleton(&(v404_7_head));
        let v405_3: Space = intersect(&(*CONSTANT_2),&(v405_2));
        let v405_4: Space = if has_head(&(v405_3)) { singleton(&[]) } else { Space::new() };
        drop(v405_3);
        let v405_5: Space = subtract(&(*CONSTANT_1),&(v405_4));
        drop(v405_4);
        let v405_8: Space = if (v405_5).is_empty() { Space::new() } else {
          let v406_6: Path = concat_path(&(v404_6),&(v404_7_head));
          let v406_7: Space = routine_79(c, &(v406_6), &(v404_7_tail), &(*s1));
          compose(&(v405_5),&(v406_7))
        };
        drop(v405_5);
        let v405_9: Space = intersect(&(*CONSTANT_2),&(v405_2));
        drop(v405_2);
        let v405_10: Space = if has_head(&(v405_9)) { singleton(&[]) } else { Space::new() };
        drop(v405_9);
        let v405_12: Space = if (v405_10).is_empty() { Space::new() } else {
          let v407_6: Path = concat_path(&(v404_6),&(v404_7_head));
          let v407_11: Space = routine_80(c, &(v407_6), &(v404_7_tail), &(*s1));
          drop(v407_6);
          compose(&(v405_10),&(v407_11))
        };
        drop(v405_10);
        let v405_13: Space = unite(&(v405_8),&(v405_12));
        v404_7.join_into((v405_13).clone());
      }
      drop(v404_7_cursor);
      compose(&(v403_5),&(v404_7))
    };
    drop(v403_5);
    let v403_9: Space = intersect(&(*CONSTANT_2),&(v403_2));
    drop(v403_2);
    let v403_10: Space = if has_head(&(v403_9)) { singleton(&[]) } else { Space::new() };
    drop(v403_9);
    let v403_12: Space = if (v403_10).is_empty() { Space::new() } else {
      let v408_6: Path = concat_path(&(*p0),&(v402_12_head));
      let mut v408_11 = Space::new();
      let mut v408_11_cursor = (v402_12_tail).read_zipper();
      for v408_11_byte in v408_11_cursor.child_mask().iter() {
        v408_11_cursor.descend_to_byte(v408_11_byte);
        let v408_11_tail = v408_11_cursor.make_map();
        v408_11_cursor.ascend(1);
        let v408_11_head = Path::from_slice(&[v408_11_byte]);
        let v409_2: Space = singleton(&(v408_11_head));
        let v409_3: Space = intersect(&(*CONSTANT_2),&(v409_2));
        let v409_4: Space = if has_head(&(v409_3)) { singleton(&[]) } else { Space::new() };
        drop(v409_3);
        let v409_5: Space = subtract(&(*CONSTANT_1),&(v409_4));
        drop(v409_4);
        let v409_7: Space = if (v409_5).is_empty() { Space::new() } else {
          let v410_6: Space = routine_39(c, &(v408_11_head), &(v408_6), &(v408_11_tail), &(*s1));
          compose(&(v409_5),&(v410_6))
        };
        drop(v409_5);
        let v409_8: Space = intersect(&(*CONSTANT_2),&(v409_2));
        drop(v409_2);
        let v409_9: Space = if has_head(&(v409_8)) { singleton(&[]) } else { Space::new() };
        drop(v409_8);
        let v409_11: Space = if (v409_9).is_empty() { Space::new() } else {
          let v411_10: Space = routine_40(c, &(v408_11_head), &(v408_6), &(v408_11_tail), &(*s1));
          compose(&(v409_9),&(v411_10))
        };
        drop(v409_9);
        let v409_12: Space = unite(&(v409_7),&(v409_11));
        v408_11.join_into((v409_12).clone());
      }
      drop(v408_11_cursor);
      drop(v408_6);
      compose(&(v403_10),&(v408_11))
    };
    drop(v403_10);
    let v403_13: Space = unite(&(v403_8),&(v403_12));
    v402_12.join_into((v403_13).clone());
  }
  drop(v402_12_cursor);
  (v402_12).clone()
}

fn routine_39(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v412_13 = Space::new();
  let mut v412_13_cursor = (*s0).read_zipper();
  for v412_13_byte in v412_13_cursor.child_mask().iter() {
    v412_13_cursor.descend_to_byte(v412_13_byte);
    let v412_13_tail = v412_13_cursor.make_map();
    v412_13_cursor.ascend(1);
    let v412_13_head = Path::from_slice(&[v412_13_byte]);
    let v413_2: Space = singleton(&(v412_13_head));
    let v413_3: Space = intersect(&(*CONSTANT_2),&(v413_2));
    let v413_4: Space = if has_head(&(v413_3)) { singleton(&[]) } else { Space::new() };
    drop(v413_3);
    let v413_5: Space = subtract(&(*CONSTANT_1),&(v413_4));
    drop(v413_4);
    let v413_8: Space = if (v413_5).is_empty() { Space::new() } else {
      let v414_6: Path = concat_path(&(*p0),&(v412_13_head));
      let mut v414_7 = Space::new();
      let mut v414_7_cursor = (v412_13_tail).read_zipper();
      for v414_7_byte in v414_7_cursor.child_mask().iter() {
        v414_7_cursor.descend_to_byte(v414_7_byte);
        let v414_7_tail = v414_7_cursor.make_map();
        v414_7_cursor.ascend(1);
        let v414_7_head = Path::from_slice(&[v414_7_byte]);
        let v415_2: Space = singleton(&(v414_7_head));
        let v415_3: Space = intersect(&(*CONSTANT_2),&(v415_2));
        let v415_4: Space = if has_head(&(v415_3)) { singleton(&[]) } else { Space::new() };
        drop(v415_3);
        let v415_5: Space = subtract(&(*CONSTANT_1),&(v415_4));
        drop(v415_4);
        let v415_8: Space = if (v415_5).is_empty() { Space::new() } else {
          let v416_6: Path = concat_path(&(v414_6),&(v414_7_head));
          let v416_7: Space = routine_81(c, &(v416_6), &(*p1), &(v414_7_tail), &(*s1));
          compose(&(v415_5),&(v416_7))
        };
        drop(v415_5);
        let v415_9: Space = intersect(&(*CONSTANT_2),&(v415_2));
        drop(v415_2);
        let v415_10: Space = if has_head(&(v415_9)) { singleton(&[]) } else { Space::new() };
        drop(v415_9);
        let v415_12: Space = if (v415_10).is_empty() { Space::new() } else {
          let v417_6: Path = concat_path(&(v414_6),&(v414_7_head));
          let v417_11: Space = routine_82(c, &(v417_6), &(*p1), &(v414_7_tail), &(*s1));
          drop(v417_6);
          compose(&(v415_10),&(v417_11))
        };
        drop(v415_10);
        let v415_13: Space = unite(&(v415_8),&(v415_12));
        v414_7.join_into((v415_13).clone());
      }
      drop(v414_7_cursor);
      compose(&(v413_5),&(v414_7))
    };
    drop(v413_5);
    let v413_9: Space = intersect(&(*CONSTANT_2),&(v413_2));
    drop(v413_2);
    let v413_10: Space = if has_head(&(v413_9)) { singleton(&[]) } else { Space::new() };
    drop(v413_9);
    let v413_12: Space = if (v413_10).is_empty() { Space::new() } else {
      let v418_6: Path = concat_path(&(*p0),&(v412_13_head));
      let mut v418_11 = Space::new();
      let mut v418_11_cursor = (v412_13_tail).read_zipper();
      for v418_11_byte in v418_11_cursor.child_mask().iter() {
        v418_11_cursor.descend_to_byte(v418_11_byte);
        let v418_11_tail = v418_11_cursor.make_map();
        v418_11_cursor.ascend(1);
        let v418_11_head = Path::from_slice(&[v418_11_byte]);
        let v419_2: Space = singleton(&(v418_11_head));
        let v419_3: Space = intersect(&(*CONSTANT_2),&(v419_2));
        let v419_4: Space = if has_head(&(v419_3)) { singleton(&[]) } else { Space::new() };
        drop(v419_3);
        let v419_5: Space = subtract(&(*CONSTANT_1),&(v419_4));
        drop(v419_4);
        let v419_8: Space = if (v419_5).is_empty() { Space::new() } else {
          let v420_6: Path = concat_path(&(v418_6),&(v418_11_head));
          let v420_7: Space = routine_81(c, &(v420_6), &(*p1), &(v418_11_tail), &(*s1));
          compose(&(v419_5),&(v420_7))
        };
        drop(v419_5);
        let v419_9: Space = intersect(&(*CONSTANT_2),&(v419_2));
        drop(v419_2);
        let v419_10: Space = if has_head(&(v419_9)) { singleton(&[]) } else { Space::new() };
        drop(v419_9);
        let v419_12: Space = if (v419_10).is_empty() { Space::new() } else {
          let v421_6: Path = concat_path(&(v418_6),&(v418_11_head));
          let v421_11: Space = routine_43(c, &(v421_6), &(*p1), &(v418_11_tail), &(*s1));
          drop(v421_6);
          compose(&(v419_10),&(v421_11))
        };
        drop(v419_10);
        let v419_13: Space = unite(&(v419_8),&(v419_12));
        v418_11.join_into((v419_13).clone());
      }
      drop(v418_11_cursor);
      drop(v418_6);
      compose(&(v413_10),&(v418_11))
    };
    drop(v413_10);
    let v413_13: Space = unite(&(v413_8),&(v413_12));
    v412_13.join_into((v413_13).clone());
  }
  drop(v412_13_cursor);
  (v412_13).clone()
}

fn routine_40(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v422_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v422_10: Space = unwrap(&(v422_8),&(*CONSTANT_5));
  drop(v422_8);
  let v422_11: Space = unwrap(&(v422_10),&(*p0));
  drop(v422_10);
  let mut v422_18 = Space::new();
  let mut v422_18_cursor = (*s0).read_zipper();
  for v422_18_byte in v422_18_cursor.child_mask().iter() {
    v422_18_cursor.descend_to_byte(v422_18_byte);
    let v422_18_tail = v422_18_cursor.make_map();
    v422_18_cursor.ascend(1);
    let v422_18_head = Path::from_slice(&[v422_18_byte]);
    let v423_2: Space = singleton(&(v422_18_head));
    let v423_3: Space = intersect(&(*CONSTANT_2),&(v423_2));
    let v423_4: Space = if has_head(&(v423_3)) { singleton(&[]) } else { Space::new() };
    drop(v423_3);
    let v423_5: Space = subtract(&(*CONSTANT_1),&(v423_4));
    drop(v423_4);
    let v423_8: Space = if (v423_5).is_empty() { Space::new() } else {
      let v424_6: Path = concat_path(&(*p0),&(v422_18_head));
      let mut v424_7 = Space::new();
      let mut v424_7_cursor = (v422_18_tail).read_zipper();
      for v424_7_byte in v424_7_cursor.child_mask().iter() {
        v424_7_cursor.descend_to_byte(v424_7_byte);
        let v424_7_tail = v424_7_cursor.make_map();
        v424_7_cursor.ascend(1);
        let v424_7_head = Path::from_slice(&[v424_7_byte]);
        let v425_2: Space = singleton(&(v424_7_head));
        let v425_3: Space = intersect(&(*CONSTANT_2),&(v425_2));
        let v425_4: Space = if has_head(&(v425_3)) { singleton(&[]) } else { Space::new() };
        drop(v425_3);
        let v425_5: Space = subtract(&(*CONSTANT_1),&(v425_4));
        drop(v425_4);
        let v425_8: Space = if (v425_5).is_empty() { Space::new() } else {
          let v426_6: Path = concat_path(&(v424_6),&(v424_7_head));
          let v426_7: Space = routine_81(c, &(v426_6), &(*p1), &(v424_7_tail), &(*s1));
          compose(&(v425_5),&(v426_7))
        };
        drop(v425_5);
        let v425_9: Space = intersect(&(*CONSTANT_2),&(v425_2));
        drop(v425_2);
        let v425_10: Space = if has_head(&(v425_9)) { singleton(&[]) } else { Space::new() };
        drop(v425_9);
        let v425_12: Space = if (v425_10).is_empty() { Space::new() } else {
          let v427_6: Path = concat_path(&(v424_6),&(v424_7_head));
          let v427_11: Space = routine_82(c, &(v427_6), &(*p1), &(v424_7_tail), &(*s1));
          drop(v427_6);
          compose(&(v425_10),&(v427_11))
        };
        drop(v425_10);
        let v425_13: Space = unite(&(v425_8),&(v425_12));
        v424_7.join_into((v425_13).clone());
      }
      drop(v424_7_cursor);
      drop(v424_6);
      compose(&(v423_5),&(v424_7))
    };
    drop(v423_5);
    let v423_9: Space = intersect(&(*CONSTANT_2),&(v423_2));
    drop(v423_2);
    let v423_10: Space = if has_head(&(v423_9)) { singleton(&[]) } else { Space::new() };
    drop(v423_9);
    let v423_13: Space = if (v423_10).is_empty() { Space::new() } else {
      let v428_11: Space = unwrap(&(v422_11),&(v422_18_head));
      let mut v428_12 = Space::new();
      let mut v428_12_cursor = (v428_11).read_zipper();
      for v428_12_byte in v428_12_cursor.child_mask().iter() {
        v428_12_cursor.descend_to_byte(v428_12_byte);
        let v428_12_tail = v428_12_cursor.make_map();
        v428_12_cursor.ascend(1);
        let v428_12_head = Path::from_slice(&[v428_12_byte]);
        let v429_2: Space = singleton(&(v428_12_head));
        let v429_3: Space = intersect(&(*CONSTANT_2),&(v429_2));
        let v429_4: Space = if has_head(&(v429_3)) { singleton(&[]) } else { Space::new() };
        drop(v429_3);
        let v429_5: Space = subtract(&(*CONSTANT_1),&(v429_4));
        drop(v429_4);
        let v429_7: Space = if (v429_5).is_empty() { Space::new() } else {
          let v430_6: Space = routine_83(c, &(v428_12_head), &(*p1), &(v428_12_tail));
          compose(&(v429_5),&(v430_6))
        };
        drop(v429_5);
        let v429_8: Space = intersect(&(*CONSTANT_2),&(v429_2));
        drop(v429_2);
        let v429_9: Space = if has_head(&(v429_8)) { singleton(&[]) } else { Space::new() };
        drop(v429_8);
        let v429_11: Space = if (v429_9).is_empty() { Space::new() } else {
          let v431_10: Space = routine_84(c, &(v428_12_head), &(*p1), &(v428_12_tail));
          compose(&(v429_9),&(v431_10))
        };
        drop(v429_9);
        let v429_12: Space = unite(&(v429_7),&(v429_11));
        v428_12.join_into((v429_12).clone());
      }
      drop(v428_12_cursor);
      drop(v428_11);
      compose(&(v423_10),&(v428_12))
    };
    drop(v423_10);
    let v423_14: Space = unite(&(v423_8),&(v423_13));
    v422_18.join_into((v423_14).clone());
  }
  drop(v422_18_cursor);
  drop(v422_11);
  (v422_18).clone()
}

fn routine_41(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v432_13 = Space::new();
  let mut v432_13_cursor = (*s0).read_zipper();
  for v432_13_byte in v432_13_cursor.child_mask().iter() {
    v432_13_cursor.descend_to_byte(v432_13_byte);
    let v432_13_tail = v432_13_cursor.make_map();
    v432_13_cursor.ascend(1);
    let v432_13_head = Path::from_slice(&[v432_13_byte]);
    let v433_2: Space = singleton(&(v432_13_head));
    let v433_3: Space = intersect(&(*CONSTANT_2),&(v433_2));
    let v433_4: Space = if has_head(&(v433_3)) { singleton(&[]) } else { Space::new() };
    drop(v433_3);
    let v433_5: Space = subtract(&(*CONSTANT_1),&(v433_4));
    drop(v433_4);
    let v433_8: Space = if (v433_5).is_empty() { Space::new() } else {
      let v434_6: Path = concat_path(&(*p0),&(v432_13_head));
      let mut v434_7 = Space::new();
      let mut v434_7_cursor = (v432_13_tail).read_zipper();
      for v434_7_byte in v434_7_cursor.child_mask().iter() {
        v434_7_cursor.descend_to_byte(v434_7_byte);
        let v434_7_tail = v434_7_cursor.make_map();
        v434_7_cursor.ascend(1);
        let v434_7_head = Path::from_slice(&[v434_7_byte]);
        let v435_2: Space = singleton(&(v434_7_head));
        let v435_3: Space = intersect(&(*CONSTANT_2),&(v435_2));
        let v435_4: Space = if has_head(&(v435_3)) { singleton(&[]) } else { Space::new() };
        drop(v435_3);
        let v435_5: Space = subtract(&(*CONSTANT_1),&(v435_4));
        drop(v435_4);
        let v435_8: Space = if (v435_5).is_empty() { Space::new() } else {
          let v436_6: Path = concat_path(&(v434_6),&(v434_7_head));
          let v436_7: Space = routine_85(c, &(v436_6), &(*p1), &(v434_7_tail), &(*s1));
          compose(&(v435_5),&(v436_7))
        };
        drop(v435_5);
        let v435_9: Space = intersect(&(*CONSTANT_2),&(v435_2));
        drop(v435_2);
        let v435_10: Space = if has_head(&(v435_9)) { singleton(&[]) } else { Space::new() };
        drop(v435_9);
        let v435_12: Space = if (v435_10).is_empty() { Space::new() } else {
          let v437_6: Path = concat_path(&(v434_6),&(v434_7_head));
          let v437_11: Space = routine_86(c, &(v437_6), &(*p1), &(v434_7_tail), &(*s1));
          drop(v437_6);
          compose(&(v435_10),&(v437_11))
        };
        drop(v435_10);
        let v435_13: Space = unite(&(v435_8),&(v435_12));
        v434_7.join_into((v435_13).clone());
      }
      drop(v434_7_cursor);
      compose(&(v433_5),&(v434_7))
    };
    drop(v433_5);
    let v433_9: Space = intersect(&(*CONSTANT_2),&(v433_2));
    drop(v433_2);
    let v433_10: Space = if has_head(&(v433_9)) { singleton(&[]) } else { Space::new() };
    drop(v433_9);
    let v433_12: Space = if (v433_10).is_empty() { Space::new() } else {
      let v438_6: Path = concat_path(&(*p0),&(v432_13_head));
      let mut v438_11 = Space::new();
      let mut v438_11_cursor = (v432_13_tail).read_zipper();
      for v438_11_byte in v438_11_cursor.child_mask().iter() {
        v438_11_cursor.descend_to_byte(v438_11_byte);
        let v438_11_tail = v438_11_cursor.make_map();
        v438_11_cursor.ascend(1);
        let v438_11_head = Path::from_slice(&[v438_11_byte]);
        let v439_2: Space = singleton(&(v438_11_head));
        let v439_3: Space = intersect(&(*CONSTANT_2),&(v439_2));
        let v439_4: Space = if has_head(&(v439_3)) { singleton(&[]) } else { Space::new() };
        drop(v439_3);
        let v439_5: Space = subtract(&(*CONSTANT_1),&(v439_4));
        drop(v439_4);
        let v439_8: Space = if (v439_5).is_empty() { Space::new() } else {
          let v440_6: Path = concat_path(&(v438_6),&(v438_11_head));
          let v440_7: Space = routine_85(c, &(v440_6), &(*p1), &(v438_11_tail), &(*s1));
          compose(&(v439_5),&(v440_7))
        };
        drop(v439_5);
        let v439_9: Space = intersect(&(*CONSTANT_2),&(v439_2));
        drop(v439_2);
        let v439_10: Space = if has_head(&(v439_9)) { singleton(&[]) } else { Space::new() };
        drop(v439_9);
        let v439_12: Space = if (v439_10).is_empty() { Space::new() } else {
          let v441_6: Path = concat_path(&(v438_6),&(v438_11_head));
          let v441_11: Space = routine_43(c, &(v441_6), &(*p1), &(v438_11_tail), &(*s1));
          drop(v441_6);
          compose(&(v439_10),&(v441_11))
        };
        drop(v439_10);
        let v439_13: Space = unite(&(v439_8),&(v439_12));
        v438_11.join_into((v439_13).clone());
      }
      drop(v438_11_cursor);
      drop(v438_6);
      compose(&(v433_10),&(v438_11))
    };
    drop(v433_10);
    let v433_13: Space = unite(&(v433_8),&(v433_12));
    v432_13.join_into((v433_13).clone());
  }
  drop(v432_13_cursor);
  (v432_13).clone()
}

fn routine_42(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v442_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v442_10: Space = unwrap(&(v442_8),&(*CONSTANT_5));
  drop(v442_8);
  let v442_11: Space = unwrap(&(v442_10),&(*p0));
  drop(v442_10);
  let mut v442_18 = Space::new();
  let mut v442_18_cursor = (*s0).read_zipper();
  for v442_18_byte in v442_18_cursor.child_mask().iter() {
    v442_18_cursor.descend_to_byte(v442_18_byte);
    let v442_18_tail = v442_18_cursor.make_map();
    v442_18_cursor.ascend(1);
    let v442_18_head = Path::from_slice(&[v442_18_byte]);
    let v443_2: Space = singleton(&(v442_18_head));
    let v443_3: Space = intersect(&(*CONSTANT_2),&(v443_2));
    let v443_4: Space = if has_head(&(v443_3)) { singleton(&[]) } else { Space::new() };
    drop(v443_3);
    let v443_5: Space = subtract(&(*CONSTANT_1),&(v443_4));
    drop(v443_4);
    let v443_8: Space = if (v443_5).is_empty() { Space::new() } else {
      let v444_6: Path = concat_path(&(*p0),&(v442_18_head));
      let mut v444_7 = Space::new();
      let mut v444_7_cursor = (v442_18_tail).read_zipper();
      for v444_7_byte in v444_7_cursor.child_mask().iter() {
        v444_7_cursor.descend_to_byte(v444_7_byte);
        let v444_7_tail = v444_7_cursor.make_map();
        v444_7_cursor.ascend(1);
        let v444_7_head = Path::from_slice(&[v444_7_byte]);
        let v445_2: Space = singleton(&(v444_7_head));
        let v445_3: Space = intersect(&(*CONSTANT_2),&(v445_2));
        let v445_4: Space = if has_head(&(v445_3)) { singleton(&[]) } else { Space::new() };
        drop(v445_3);
        let v445_5: Space = subtract(&(*CONSTANT_1),&(v445_4));
        drop(v445_4);
        let v445_8: Space = if (v445_5).is_empty() { Space::new() } else {
          let v446_6: Path = concat_path(&(v444_6),&(v444_7_head));
          let v446_7: Space = routine_85(c, &(v446_6), &(*p1), &(v444_7_tail), &(*s1));
          compose(&(v445_5),&(v446_7))
        };
        drop(v445_5);
        let v445_9: Space = intersect(&(*CONSTANT_2),&(v445_2));
        drop(v445_2);
        let v445_10: Space = if has_head(&(v445_9)) { singleton(&[]) } else { Space::new() };
        drop(v445_9);
        let v445_12: Space = if (v445_10).is_empty() { Space::new() } else {
          let v447_6: Path = concat_path(&(v444_6),&(v444_7_head));
          let v447_11: Space = routine_86(c, &(v447_6), &(*p1), &(v444_7_tail), &(*s1));
          drop(v447_6);
          compose(&(v445_10),&(v447_11))
        };
        drop(v445_10);
        let v445_13: Space = unite(&(v445_8),&(v445_12));
        v444_7.join_into((v445_13).clone());
      }
      drop(v444_7_cursor);
      drop(v444_6);
      compose(&(v443_5),&(v444_7))
    };
    drop(v443_5);
    let v443_9: Space = intersect(&(*CONSTANT_2),&(v443_2));
    drop(v443_2);
    let v443_10: Space = if has_head(&(v443_9)) { singleton(&[]) } else { Space::new() };
    drop(v443_9);
    let v443_13: Space = if (v443_10).is_empty() { Space::new() } else {
      let v448_11: Space = unwrap(&(v442_11),&(v442_18_head));
      let mut v448_12 = Space::new();
      let mut v448_12_cursor = (v448_11).read_zipper();
      for v448_12_byte in v448_12_cursor.child_mask().iter() {
        v448_12_cursor.descend_to_byte(v448_12_byte);
        let v448_12_tail = v448_12_cursor.make_map();
        v448_12_cursor.ascend(1);
        let v448_12_head = Path::from_slice(&[v448_12_byte]);
        let v449_2: Space = singleton(&(v448_12_head));
        let v449_3: Space = intersect(&(*CONSTANT_2),&(v449_2));
        let v449_4: Space = if has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
        drop(v449_3);
        let v449_5: Space = subtract(&(*CONSTANT_1),&(v449_4));
        drop(v449_4);
        let v449_7: Space = if (v449_5).is_empty() { Space::new() } else {
          let v450_6: Space = routine_83(c, &(v448_12_head), &(*p1), &(v448_12_tail));
          compose(&(v449_5),&(v450_6))
        };
        drop(v449_5);
        let v449_8: Space = intersect(&(*CONSTANT_2),&(v449_2));
        drop(v449_2);
        let v449_9: Space = if has_head(&(v449_8)) { singleton(&[]) } else { Space::new() };
        drop(v449_8);
        let v449_11: Space = if (v449_9).is_empty() { Space::new() } else {
          let v451_10: Space = routine_84(c, &(v448_12_head), &(*p1), &(v448_12_tail));
          compose(&(v449_9),&(v451_10))
        };
        drop(v449_9);
        let v449_12: Space = unite(&(v449_7),&(v449_11));
        v448_12.join_into((v449_12).clone());
      }
      drop(v448_12_cursor);
      drop(v448_11);
      compose(&(v443_10),&(v448_12))
    };
    drop(v443_10);
    let v443_14: Space = unite(&(v443_8),&(v443_13));
    v442_18.join_into((v443_14).clone());
  }
  drop(v442_18_cursor);
  drop(v442_11);
  (v442_18).clone()
}

fn routine_43(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v452_5: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v452_7: Space = unwrap(&(v452_5),&(*CONSTANT_5));
  drop(v452_5);
  let v452_8: Space = unwrap(&(v452_7),&(*p0));
  drop(v452_7);
  let mut v452_18 = Space::new();
  let mut v452_18_cursor = (v452_8).read_zipper();
  for v452_18_byte in v452_18_cursor.child_mask().iter() {
    v452_18_cursor.descend_to_byte(v452_18_byte);
    let v452_18_tail = v452_18_cursor.make_map();
    v452_18_cursor.ascend(1);
    let v452_18_head = Path::from_slice(&[v452_18_byte]);
    let v453_2: Space = singleton(&(v452_18_head));
    let v453_3: Space = intersect(&(*CONSTANT_2),&(v453_2));
    let v453_4: Space = if has_head(&(v453_3)) { singleton(&[]) } else { Space::new() };
    drop(v453_3);
    let v453_5: Space = subtract(&(*CONSTANT_1),&(v453_4));
    drop(v453_4);
    let v453_7: Space = if (v453_5).is_empty() { Space::new() } else {
      let mut v454_6 = Space::new();
      let mut v454_6_cursor = (v452_18_tail).read_zipper();
      for v454_6_byte in v454_6_cursor.child_mask().iter() {
        v454_6_cursor.descend_to_byte(v454_6_byte);
        let v454_6_tail = v454_6_cursor.make_map();
        v454_6_cursor.ascend(1);
        let v454_6_head = Path::from_slice(&[v454_6_byte]);
        let v455_2: Space = singleton(&(v454_6_head));
        let v455_3: Space = intersect(&(*CONSTANT_2),&(v455_2));
        let v455_4: Space = if has_head(&(v455_3)) { singleton(&[]) } else { Space::new() };
        drop(v455_3);
        let v455_5: Space = subtract(&(*CONSTANT_1),&(v455_4));
        drop(v455_4);
        let v455_8: Space = if (v455_5).is_empty() { Space::new() } else {
          let v456_6: Path = concat_path(&(v452_18_head),&(v454_6_head));
          let v456_7: Space = routine_87(c, &(v456_6), &(*p1), &(v454_6_tail));
          compose(&(v455_5),&(v456_7))
        };
        drop(v455_5);
        let v455_9: Space = intersect(&(*CONSTANT_2),&(v455_2));
        drop(v455_2);
        let v455_10: Space = if has_head(&(v455_9)) { singleton(&[]) } else { Space::new() };
        drop(v455_9);
        let v455_12: Space = if (v455_10).is_empty() { Space::new() } else {
          let v457_6: Path = concat_path(&(v452_18_head),&(v454_6_head));
          let v457_11: Space = routine_88(c, &(v457_6), &(*p1), &(v454_6_tail));
          drop(v457_6);
          compose(&(v455_10),&(v457_11))
        };
        drop(v455_10);
        let v455_13: Space = unite(&(v455_8),&(v455_12));
        v454_6.join_into((v455_13).clone());
      }
      drop(v454_6_cursor);
      compose(&(v453_5),&(v454_6))
    };
    drop(v453_5);
    let v453_8: Space = intersect(&(*CONSTANT_2),&(v453_2));
    drop(v453_2);
    let v453_9: Space = if has_head(&(v453_8)) { singleton(&[]) } else { Space::new() };
    drop(v453_8);
    let v453_11: Space = if (v453_9).is_empty() { Space::new() } else {
      let mut v458_10 = Space::new();
      let mut v458_10_cursor = (v452_18_tail).read_zipper();
      for v458_10_byte in v458_10_cursor.child_mask().iter() {
        v458_10_cursor.descend_to_byte(v458_10_byte);
        let v458_10_tail = v458_10_cursor.make_map();
        v458_10_cursor.ascend(1);
        let v458_10_head = Path::from_slice(&[v458_10_byte]);
        let v459_2: Space = singleton(&(v458_10_head));
        let v459_3: Space = intersect(&(*CONSTANT_2),&(v459_2));
        let v459_4: Space = if has_head(&(v459_3)) { singleton(&[]) } else { Space::new() };
        drop(v459_3);
        let v459_5: Space = subtract(&(*CONSTANT_1),&(v459_4));
        drop(v459_4);
        let v459_8: Space = if (v459_5).is_empty() { Space::new() } else {
          let v460_6: Path = concat_path(&(v452_18_head),&(v458_10_head));
          let v460_7: Space = routine_87(c, &(v460_6), &(*p1), &(v458_10_tail));
          compose(&(v459_5),&(v460_7))
        };
        drop(v459_5);
        let v459_9: Space = intersect(&(*CONSTANT_2),&(v459_2));
        drop(v459_2);
        let v459_10: Space = if has_head(&(v459_9)) { singleton(&[]) } else { Space::new() };
        drop(v459_9);
        let v459_12: Space = if (v459_10).is_empty() { Space::new() } else {
          let v461_6: Path = concat_path(&(v452_18_head),&(v458_10_head));
          let v461_11: Space = routine_89(c, &(v461_6), &(*p1), &(v458_10_tail));
          drop(v461_6);
          compose(&(v459_10),&(v461_11))
        };
        drop(v459_10);
        let v459_13: Space = unite(&(v459_8),&(v459_12));
        v458_10.join_into((v459_13).clone());
      }
      drop(v458_10_cursor);
      compose(&(v453_9),&(v458_10))
    };
    drop(v453_9);
    let v453_12: Space = unite(&(v453_7),&(v453_11));
    v452_18.join_into((v453_12).clone());
  }
  drop(v452_18_cursor);
  drop(v452_8);
  (v452_18).clone()
}

fn routine_44(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v462_11 = Space::new();
  let mut v462_11_cursor = (*s0).read_zipper();
  for v462_11_byte in v462_11_cursor.child_mask().iter() {
    v462_11_cursor.descend_to_byte(v462_11_byte);
    let v462_11_tail = v462_11_cursor.make_map();
    v462_11_cursor.ascend(1);
    let v462_11_head = Path::from_slice(&[v462_11_byte]);
    let v463_2: Space = singleton(&(v462_11_head));
    let v463_3: Space = intersect(&(*CONSTANT_2),&(v463_2));
    let v463_4: Space = if has_head(&(v463_3)) { singleton(&[]) } else { Space::new() };
    drop(v463_3);
    let v463_5: Space = subtract(&(*CONSTANT_1),&(v463_4));
    drop(v463_4);
    let v463_8: Space = if (v463_5).is_empty() { Space::new() } else {
      let v464_6: Path = concat_path(&(*p0),&(v462_11_head));
      let mut v464_7 = Space::new();
      let mut v464_7_cursor = (v462_11_tail).read_zipper();
      for v464_7_byte in v464_7_cursor.child_mask().iter() {
        v464_7_cursor.descend_to_byte(v464_7_byte);
        let v464_7_tail = v464_7_cursor.make_map();
        v464_7_cursor.ascend(1);
        let v464_7_head = Path::from_slice(&[v464_7_byte]);
        let v465_2: Space = singleton(&(v464_7_head));
        let v465_3: Space = intersect(&(*CONSTANT_2),&(v465_2));
        let v465_4: Space = if has_head(&(v465_3)) { singleton(&[]) } else { Space::new() };
        drop(v465_3);
        let v465_5: Space = subtract(&(*CONSTANT_1),&(v465_4));
        drop(v465_4);
        let v465_8: Space = if (v465_5).is_empty() { Space::new() } else {
          let v466_6: Path = concat_path(&(v464_6),&(v464_7_head));
          let v466_7: Space = routine_90(c, &(v466_6), &(v464_7_tail));
          compose(&(v465_5),&(v466_7))
        };
        drop(v465_5);
        let v465_9: Space = intersect(&(*CONSTANT_2),&(v465_2));
        drop(v465_2);
        let v465_10: Space = if has_head(&(v465_9)) { singleton(&[]) } else { Space::new() };
        drop(v465_9);
        let v465_12: Space = if (v465_10).is_empty() { Space::new() } else {
          let v467_6: Path = concat_path(&(v464_6),&(v464_7_head));
          let v467_11: Space = routine_91(c, &(v467_6), &(v464_7_tail));
          drop(v467_6);
          compose(&(v465_10),&(v467_11))
        };
        drop(v465_10);
        let v465_13: Space = unite(&(v465_8),&(v465_12));
        v464_7.join_into((v465_13).clone());
      }
      drop(v464_7_cursor);
      compose(&(v463_5),&(v464_7))
    };
    drop(v463_5);
    let v463_9: Space = intersect(&(*CONSTANT_2),&(v463_2));
    drop(v463_2);
    let v463_10: Space = if has_head(&(v463_9)) { singleton(&[]) } else { Space::new() };
    drop(v463_9);
    let v463_12: Space = if (v463_10).is_empty() { Space::new() } else {
      let v468_6: Path = concat_path(&(*p0),&(v462_11_head));
      let mut v468_11 = Space::new();
      let mut v468_11_cursor = (v462_11_tail).read_zipper();
      for v468_11_byte in v468_11_cursor.child_mask().iter() {
        v468_11_cursor.descend_to_byte(v468_11_byte);
        let v468_11_tail = v468_11_cursor.make_map();
        v468_11_cursor.ascend(1);
        let v468_11_head = Path::from_slice(&[v468_11_byte]);
        let v469_2: Space = singleton(&(v468_11_head));
        let v469_3: Space = intersect(&(*CONSTANT_2),&(v469_2));
        let v469_4: Space = if has_head(&(v469_3)) { singleton(&[]) } else { Space::new() };
        drop(v469_3);
        let v469_5: Space = subtract(&(*CONSTANT_1),&(v469_4));
        drop(v469_4);
        let v469_8: Space = if (v469_5).is_empty() { Space::new() } else {
          let v470_6: Path = concat_path(&(v468_6),&(v468_11_head));
          let v470_7: Space = routine_90(c, &(v470_6), &(v468_11_tail));
          compose(&(v469_5),&(v470_7))
        };
        drop(v469_5);
        let v469_9: Space = intersect(&(*CONSTANT_2),&(v469_2));
        drop(v469_2);
        let v469_10: Space = if has_head(&(v469_9)) { singleton(&[]) } else { Space::new() };
        drop(v469_9);
        let v469_12: Space = if (v469_10).is_empty() { Space::new() } else {
          let v471_6: Path = concat_path(&(v468_6),&(v468_11_head));
          let v471_11: Space = routine_15(c, &(v471_6), &(v468_11_tail));
          drop(v471_6);
          compose(&(v469_10),&(v471_11))
        };
        drop(v469_10);
        let v469_13: Space = unite(&(v469_8),&(v469_12));
        v468_11.join_into((v469_13).clone());
      }
      drop(v468_11_cursor);
      drop(v468_6);
      compose(&(v463_10),&(v468_11))
    };
    drop(v463_10);
    let v463_13: Space = unite(&(v463_8),&(v463_12));
    v462_11.join_into((v463_13).clone());
  }
  drop(v462_11_cursor);
  (v462_11).clone()
}

fn routine_45(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v472_11 = Space::new();
  let mut v472_11_cursor = (*s0).read_zipper();
  for v472_11_byte in v472_11_cursor.child_mask().iter() {
    v472_11_cursor.descend_to_byte(v472_11_byte);
    let v472_11_tail = v472_11_cursor.make_map();
    v472_11_cursor.ascend(1);
    let v472_11_head = Path::from_slice(&[v472_11_byte]);
    let v473_2: Space = singleton(&(v472_11_head));
    let v473_3: Space = intersect(&(*CONSTANT_2),&(v473_2));
    let v473_4: Space = if has_head(&(v473_3)) { singleton(&[]) } else { Space::new() };
    drop(v473_3);
    let v473_5: Space = subtract(&(*CONSTANT_1),&(v473_4));
    drop(v473_4);
    let v473_8: Space = if (v473_5).is_empty() { Space::new() } else {
      let v474_6: Path = concat_path(&(*p0),&(v472_11_head));
      let mut v474_7 = Space::new();
      let mut v474_7_cursor = (v472_11_tail).read_zipper();
      for v474_7_byte in v474_7_cursor.child_mask().iter() {
        v474_7_cursor.descend_to_byte(v474_7_byte);
        let v474_7_tail = v474_7_cursor.make_map();
        v474_7_cursor.ascend(1);
        let v474_7_head = Path::from_slice(&[v474_7_byte]);
        let v475_2: Space = singleton(&(v474_7_head));
        let v475_3: Space = intersect(&(*CONSTANT_2),&(v475_2));
        let v475_4: Space = if has_head(&(v475_3)) { singleton(&[]) } else { Space::new() };
        drop(v475_3);
        let v475_5: Space = subtract(&(*CONSTANT_1),&(v475_4));
        drop(v475_4);
        let v475_8: Space = if (v475_5).is_empty() { Space::new() } else {
          let v476_6: Path = concat_path(&(v474_6),&(v474_7_head));
          let v476_7: Space = routine_90(c, &(v476_6), &(v474_7_tail));
          compose(&(v475_5),&(v476_7))
        };
        drop(v475_5);
        let v475_9: Space = intersect(&(*CONSTANT_2),&(v475_2));
        drop(v475_2);
        let v475_10: Space = if has_head(&(v475_9)) { singleton(&[]) } else { Space::new() };
        drop(v475_9);
        let v475_12: Space = if (v475_10).is_empty() { Space::new() } else {
          let v477_6: Path = concat_path(&(v474_6),&(v474_7_head));
          let v477_11: Space = routine_91(c, &(v477_6), &(v474_7_tail));
          drop(v477_6);
          compose(&(v475_10),&(v477_11))
        };
        drop(v475_10);
        let v475_13: Space = unite(&(v475_8),&(v475_12));
        v474_7.join_into((v475_13).clone());
      }
      drop(v474_7_cursor);
      compose(&(v473_5),&(v474_7))
    };
    drop(v473_5);
    let v473_9: Space = intersect(&(*CONSTANT_2),&(v473_2));
    drop(v473_2);
    let v473_10: Space = if has_head(&(v473_9)) { singleton(&[]) } else { Space::new() };
    drop(v473_9);
    let v473_12: Space = if (v473_10).is_empty() { Space::new() } else {
      let v478_6: Path = concat_path(&(*p0),&(v472_11_head));
      let mut v478_11 = Space::new();
      let mut v478_11_cursor = (v472_11_tail).read_zipper();
      for v478_11_byte in v478_11_cursor.child_mask().iter() {
        v478_11_cursor.descend_to_byte(v478_11_byte);
        let v478_11_tail = v478_11_cursor.make_map();
        v478_11_cursor.ascend(1);
        let v478_11_head = Path::from_slice(&[v478_11_byte]);
        let v479_2: Space = singleton(&(v478_11_head));
        let v479_3: Space = intersect(&(*CONSTANT_2),&(v479_2));
        let v479_4: Space = if has_head(&(v479_3)) { singleton(&[]) } else { Space::new() };
        drop(v479_3);
        let v479_5: Space = subtract(&(*CONSTANT_1),&(v479_4));
        drop(v479_4);
        let v479_7: Space = if (v479_5).is_empty() { Space::new() } else {
          let v480_6: Space = routine_46(c, &(v478_11_head), &(v478_6), &(v478_11_tail));
          compose(&(v479_5),&(v480_6))
        };
        drop(v479_5);
        let v479_8: Space = intersect(&(*CONSTANT_2),&(v479_2));
        drop(v479_2);
        let v479_9: Space = if has_head(&(v479_8)) { singleton(&[]) } else { Space::new() };
        drop(v479_8);
        let v479_11: Space = if (v479_9).is_empty() { Space::new() } else {
          let v481_10: Space = routine_47(c, &(v478_11_head), &(v478_6), &(v478_11_tail));
          compose(&(v479_9),&(v481_10))
        };
        drop(v479_9);
        let v479_12: Space = unite(&(v479_7),&(v479_11));
        v478_11.join_into((v479_12).clone());
      }
      drop(v478_11_cursor);
      drop(v478_6);
      compose(&(v473_10),&(v478_11))
    };
    drop(v473_10);
    let v473_13: Space = unite(&(v473_8),&(v473_12));
    v472_11.join_into((v473_13).clone());
  }
  drop(v472_11_cursor);
  (v472_11).clone()
}

fn routine_46(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v482_12 = Space::new();
  let mut v482_12_cursor = (*s0).read_zipper();
  for v482_12_byte in v482_12_cursor.child_mask().iter() {
    v482_12_cursor.descend_to_byte(v482_12_byte);
    let v482_12_tail = v482_12_cursor.make_map();
    v482_12_cursor.ascend(1);
    let v482_12_head = Path::from_slice(&[v482_12_byte]);
    let v483_2: Space = singleton(&(v482_12_head));
    let v483_3: Space = intersect(&(*CONSTANT_2),&(v483_2));
    let v483_4: Space = if has_head(&(v483_3)) { singleton(&[]) } else { Space::new() };
    drop(v483_3);
    let v483_5: Space = subtract(&(*CONSTANT_1),&(v483_4));
    drop(v483_4);
    let v483_8: Space = if (v483_5).is_empty() { Space::new() } else {
      let v484_6: Path = concat_path(&(*p0),&(v482_12_head));
      let mut v484_7 = Space::new();
      let mut v484_7_cursor = (v482_12_tail).read_zipper();
      for v484_7_byte in v484_7_cursor.child_mask().iter() {
        v484_7_cursor.descend_to_byte(v484_7_byte);
        let v484_7_tail = v484_7_cursor.make_map();
        v484_7_cursor.ascend(1);
        let v484_7_head = Path::from_slice(&[v484_7_byte]);
        let v485_2: Space = singleton(&(v484_7_head));
        let v485_3: Space = intersect(&(*CONSTANT_2),&(v485_2));
        let v485_4: Space = if has_head(&(v485_3)) { singleton(&[]) } else { Space::new() };
        drop(v485_3);
        let v485_5: Space = subtract(&(*CONSTANT_1),&(v485_4));
        drop(v485_4);
        let v485_8: Space = if (v485_5).is_empty() { Space::new() } else {
          let v486_6: Path = concat_path(&(v484_6),&(v484_7_head));
          let v486_7: Space = routine_92(c, &(v486_6), &(*p1), &(v484_7_tail));
          compose(&(v485_5),&(v486_7))
        };
        drop(v485_5);
        let v485_9: Space = intersect(&(*CONSTANT_2),&(v485_2));
        drop(v485_2);
        let v485_10: Space = if has_head(&(v485_9)) { singleton(&[]) } else { Space::new() };
        drop(v485_9);
        let v485_12: Space = if (v485_10).is_empty() { Space::new() } else {
          let v487_6: Path = concat_path(&(v484_6),&(v484_7_head));
          let v487_11: Space = routine_93(c, &(v487_6), &(*p1), &(v484_7_tail));
          drop(v487_6);
          compose(&(v485_10),&(v487_11))
        };
        drop(v485_10);
        let v485_13: Space = unite(&(v485_8),&(v485_12));
        v484_7.join_into((v485_13).clone());
      }
      drop(v484_7_cursor);
      compose(&(v483_5),&(v484_7))
    };
    drop(v483_5);
    let v483_9: Space = intersect(&(*CONSTANT_2),&(v483_2));
    drop(v483_2);
    let v483_10: Space = if has_head(&(v483_9)) { singleton(&[]) } else { Space::new() };
    drop(v483_9);
    let v483_12: Space = if (v483_10).is_empty() { Space::new() } else {
      let v488_6: Path = concat_path(&(*p0),&(v482_12_head));
      let mut v488_11 = Space::new();
      let mut v488_11_cursor = (v482_12_tail).read_zipper();
      for v488_11_byte in v488_11_cursor.child_mask().iter() {
        v488_11_cursor.descend_to_byte(v488_11_byte);
        let v488_11_tail = v488_11_cursor.make_map();
        v488_11_cursor.ascend(1);
        let v488_11_head = Path::from_slice(&[v488_11_byte]);
        let v489_2: Space = singleton(&(v488_11_head));
        let v489_3: Space = intersect(&(*CONSTANT_2),&(v489_2));
        let v489_4: Space = if has_head(&(v489_3)) { singleton(&[]) } else { Space::new() };
        drop(v489_3);
        let v489_5: Space = subtract(&(*CONSTANT_1),&(v489_4));
        drop(v489_4);
        let v489_8: Space = if (v489_5).is_empty() { Space::new() } else {
          let v490_6: Path = concat_path(&(v488_6),&(v488_11_head));
          let v490_7: Space = routine_92(c, &(v490_6), &(*p1), &(v488_11_tail));
          compose(&(v489_5),&(v490_7))
        };
        drop(v489_5);
        let v489_9: Space = intersect(&(*CONSTANT_2),&(v489_2));
        drop(v489_2);
        let v489_10: Space = if has_head(&(v489_9)) { singleton(&[]) } else { Space::new() };
        drop(v489_9);
        let v489_12: Space = if (v489_10).is_empty() { Space::new() } else {
          let v491_6: Path = concat_path(&(v488_6),&(v488_11_head));
          let v491_11: Space = routine_50(c, &(v491_6), &(*p1), &(v488_11_tail));
          drop(v491_6);
          compose(&(v489_10),&(v491_11))
        };
        drop(v489_10);
        let v489_13: Space = unite(&(v489_8),&(v489_12));
        v488_11.join_into((v489_13).clone());
      }
      drop(v488_11_cursor);
      drop(v488_6);
      compose(&(v483_10),&(v488_11))
    };
    drop(v483_10);
    let v483_13: Space = unite(&(v483_8),&(v483_12));
    v482_12.join_into((v483_13).clone());
  }
  drop(v482_12_cursor);
  (v482_12).clone()
}

fn routine_47(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v492_9 = Space::new();
  let mut v492_9_cursor = (*s0).read_zipper();
  for v492_9_byte in v492_9_cursor.child_mask().iter() {
    v492_9_cursor.descend_to_byte(v492_9_byte);
    let v492_9_tail = v492_9_cursor.make_map();
    v492_9_cursor.ascend(1);
    let v492_9_head = Path::from_slice(&[v492_9_byte]);
    let v493_2: Space = singleton(&(v492_9_head));
    let v493_3: Space = intersect(&(*CONSTANT_2),&(v493_2));
    let v493_4: Space = if has_head(&(v493_3)) { singleton(&[]) } else { Space::new() };
    drop(v493_3);
    let v493_5: Space = subtract(&(*CONSTANT_1),&(v493_4));
    drop(v493_4);
    let v493_8: Space = if (v493_5).is_empty() { Space::new() } else {
      let v494_6: Path = concat_path(&(*p0),&(v492_9_head));
      let mut v494_7 = Space::new();
      let mut v494_7_cursor = (v492_9_tail).read_zipper();
      for v494_7_byte in v494_7_cursor.child_mask().iter() {
        v494_7_cursor.descend_to_byte(v494_7_byte);
        let v494_7_tail = v494_7_cursor.make_map();
        v494_7_cursor.ascend(1);
        let v494_7_head = Path::from_slice(&[v494_7_byte]);
        let v495_2: Space = singleton(&(v494_7_head));
        let v495_3: Space = intersect(&(*CONSTANT_2),&(v495_2));
        let v495_4: Space = if has_head(&(v495_3)) { singleton(&[]) } else { Space::new() };
        drop(v495_3);
        let v495_5: Space = subtract(&(*CONSTANT_1),&(v495_4));
        drop(v495_4);
        let v495_8: Space = if (v495_5).is_empty() { Space::new() } else {
          let v496_6: Path = concat_path(&(v494_6),&(v494_7_head));
          let v496_7: Space = routine_92(c, &(v496_6), &(*p1), &(v494_7_tail));
          compose(&(v495_5),&(v496_7))
        };
        drop(v495_5);
        let v495_9: Space = intersect(&(*CONSTANT_2),&(v495_2));
        drop(v495_2);
        let v495_10: Space = if has_head(&(v495_9)) { singleton(&[]) } else { Space::new() };
        drop(v495_9);
        let v495_12: Space = if (v495_10).is_empty() { Space::new() } else {
          let v497_6: Path = concat_path(&(v494_6),&(v494_7_head));
          let v497_11: Space = routine_93(c, &(v497_6), &(*p1), &(v494_7_tail));
          drop(v497_6);
          compose(&(v495_10),&(v497_11))
        };
        drop(v495_10);
        let v495_13: Space = unite(&(v495_8),&(v495_12));
        v494_7.join_into((v495_13).clone());
      }
      drop(v494_7_cursor);
      compose(&(v493_5),&(v494_7))
    };
    drop(v493_5);
    let v493_9: Space = intersect(&(*CONSTANT_2),&(v493_2));
    drop(v493_2);
    let v493_10: Space = if has_head(&(v493_9)) { singleton(&[]) } else { Space::new() };
    drop(v493_9);
    let v493_11: Space = compose(&(v493_10),&(v492_9_tail));
    drop(v493_10);
    let v498_6: Path = concat_path(&(*p0),&(v492_9_head));
    let v493_12: Space = wrap(&(v493_11),&(v498_6));
    drop(v493_11);
    let v493_13: Space = wrap(&(v493_12),&(*p1));
    drop(v493_12);
    let v493_14: Space = unite(&(v493_8),&(v493_13));
    drop(v493_13);
    v492_9.join_into((v493_14).clone());
  }
  drop(v492_9_cursor);
  (v492_9).clone()
}

fn routine_48(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v499_12 = Space::new();
  let mut v499_12_cursor = (*s0).read_zipper();
  for v499_12_byte in v499_12_cursor.child_mask().iter() {
    v499_12_cursor.descend_to_byte(v499_12_byte);
    let v499_12_tail = v499_12_cursor.make_map();
    v499_12_cursor.ascend(1);
    let v499_12_head = Path::from_slice(&[v499_12_byte]);
    let v500_2: Space = singleton(&(v499_12_head));
    let v500_3: Space = intersect(&(*CONSTANT_2),&(v500_2));
    let v500_4: Space = if has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
    drop(v500_3);
    let v500_5: Space = subtract(&(*CONSTANT_1),&(v500_4));
    drop(v500_4);
    let v500_8: Space = if (v500_5).is_empty() { Space::new() } else {
      let v501_6: Path = concat_path(&(*p0),&(v499_12_head));
      let mut v501_7 = Space::new();
      let mut v501_7_cursor = (v499_12_tail).read_zipper();
      for v501_7_byte in v501_7_cursor.child_mask().iter() {
        v501_7_cursor.descend_to_byte(v501_7_byte);
        let v501_7_tail = v501_7_cursor.make_map();
        v501_7_cursor.ascend(1);
        let v501_7_head = Path::from_slice(&[v501_7_byte]);
        let v502_2: Space = singleton(&(v501_7_head));
        let v502_3: Space = intersect(&(*CONSTANT_2),&(v502_2));
        let v502_4: Space = if has_head(&(v502_3)) { singleton(&[]) } else { Space::new() };
        drop(v502_3);
        let v502_5: Space = subtract(&(*CONSTANT_1),&(v502_4));
        drop(v502_4);
        let v502_8: Space = if (v502_5).is_empty() { Space::new() } else {
          let v503_6: Path = concat_path(&(v501_6),&(v501_7_head));
          let v503_7: Space = routine_94(c, &(v503_6), &(*p1), &(v501_7_tail));
          compose(&(v502_5),&(v503_7))
        };
        drop(v502_5);
        let v502_9: Space = intersect(&(*CONSTANT_2),&(v502_2));
        drop(v502_2);
        let v502_10: Space = if has_head(&(v502_9)) { singleton(&[]) } else { Space::new() };
        drop(v502_9);
        let v502_12: Space = if (v502_10).is_empty() { Space::new() } else {
          let v504_6: Path = concat_path(&(v501_6),&(v501_7_head));
          let v504_11: Space = routine_95(c, &(v504_6), &(*p1), &(v501_7_tail));
          drop(v504_6);
          compose(&(v502_10),&(v504_11))
        };
        drop(v502_10);
        let v502_13: Space = unite(&(v502_8),&(v502_12));
        v501_7.join_into((v502_13).clone());
      }
      drop(v501_7_cursor);
      compose(&(v500_5),&(v501_7))
    };
    drop(v500_5);
    let v500_9: Space = intersect(&(*CONSTANT_2),&(v500_2));
    drop(v500_2);
    let v500_10: Space = if has_head(&(v500_9)) { singleton(&[]) } else { Space::new() };
    drop(v500_9);
    let v500_12: Space = if (v500_10).is_empty() { Space::new() } else {
      let v505_6: Path = concat_path(&(*p0),&(v499_12_head));
      let mut v505_11 = Space::new();
      let mut v505_11_cursor = (v499_12_tail).read_zipper();
      for v505_11_byte in v505_11_cursor.child_mask().iter() {
        v505_11_cursor.descend_to_byte(v505_11_byte);
        let v505_11_tail = v505_11_cursor.make_map();
        v505_11_cursor.ascend(1);
        let v505_11_head = Path::from_slice(&[v505_11_byte]);
        let v506_2: Space = singleton(&(v505_11_head));
        let v506_3: Space = intersect(&(*CONSTANT_2),&(v506_2));
        let v506_4: Space = if has_head(&(v506_3)) { singleton(&[]) } else { Space::new() };
        drop(v506_3);
        let v506_5: Space = subtract(&(*CONSTANT_1),&(v506_4));
        drop(v506_4);
        let v506_8: Space = if (v506_5).is_empty() { Space::new() } else {
          let v507_6: Path = concat_path(&(v505_6),&(v505_11_head));
          let v507_7: Space = routine_94(c, &(v507_6), &(*p1), &(v505_11_tail));
          compose(&(v506_5),&(v507_7))
        };
        drop(v506_5);
        let v506_9: Space = intersect(&(*CONSTANT_2),&(v506_2));
        drop(v506_2);
        let v506_10: Space = if has_head(&(v506_9)) { singleton(&[]) } else { Space::new() };
        drop(v506_9);
        let v506_12: Space = if (v506_10).is_empty() { Space::new() } else {
          let v508_6: Path = concat_path(&(v505_6),&(v505_11_head));
          let v508_11: Space = routine_50(c, &(v508_6), &(*p1), &(v505_11_tail));
          drop(v508_6);
          compose(&(v506_10),&(v508_11))
        };
        drop(v506_10);
        let v506_13: Space = unite(&(v506_8),&(v506_12));
        v505_11.join_into((v506_13).clone());
      }
      drop(v505_11_cursor);
      drop(v505_6);
      compose(&(v500_10),&(v505_11))
    };
    drop(v500_10);
    let v500_13: Space = unite(&(v500_8),&(v500_12));
    v499_12.join_into((v500_13).clone());
  }
  drop(v499_12_cursor);
  (v499_12).clone()
}

fn routine_49(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v509_9 = Space::new();
  let mut v509_9_cursor = (*s0).read_zipper();
  for v509_9_byte in v509_9_cursor.child_mask().iter() {
    v509_9_cursor.descend_to_byte(v509_9_byte);
    let v509_9_tail = v509_9_cursor.make_map();
    v509_9_cursor.ascend(1);
    let v509_9_head = Path::from_slice(&[v509_9_byte]);
    let v510_2: Space = singleton(&(v509_9_head));
    let v510_3: Space = intersect(&(*CONSTANT_2),&(v510_2));
    let v510_4: Space = if has_head(&(v510_3)) { singleton(&[]) } else { Space::new() };
    drop(v510_3);
    let v510_5: Space = subtract(&(*CONSTANT_1),&(v510_4));
    drop(v510_4);
    let v510_8: Space = if (v510_5).is_empty() { Space::new() } else {
      let v511_6: Path = concat_path(&(*p0),&(v509_9_head));
      let mut v511_7 = Space::new();
      let mut v511_7_cursor = (v509_9_tail).read_zipper();
      for v511_7_byte in v511_7_cursor.child_mask().iter() {
        v511_7_cursor.descend_to_byte(v511_7_byte);
        let v511_7_tail = v511_7_cursor.make_map();
        v511_7_cursor.ascend(1);
        let v511_7_head = Path::from_slice(&[v511_7_byte]);
        let v512_2: Space = singleton(&(v511_7_head));
        let v512_3: Space = intersect(&(*CONSTANT_2),&(v512_2));
        let v512_4: Space = if has_head(&(v512_3)) { singleton(&[]) } else { Space::new() };
        drop(v512_3);
        let v512_5: Space = subtract(&(*CONSTANT_1),&(v512_4));
        drop(v512_4);
        let v512_8: Space = if (v512_5).is_empty() { Space::new() } else {
          let v513_6: Path = concat_path(&(v511_6),&(v511_7_head));
          let v513_7: Space = routine_94(c, &(v513_6), &(*p1), &(v511_7_tail));
          compose(&(v512_5),&(v513_7))
        };
        drop(v512_5);
        let v512_9: Space = intersect(&(*CONSTANT_2),&(v512_2));
        drop(v512_2);
        let v512_10: Space = if has_head(&(v512_9)) { singleton(&[]) } else { Space::new() };
        drop(v512_9);
        let v512_12: Space = if (v512_10).is_empty() { Space::new() } else {
          let v514_6: Path = concat_path(&(v511_6),&(v511_7_head));
          let v514_11: Space = routine_95(c, &(v514_6), &(*p1), &(v511_7_tail));
          drop(v514_6);
          compose(&(v512_10),&(v514_11))
        };
        drop(v512_10);
        let v512_13: Space = unite(&(v512_8),&(v512_12));
        v511_7.join_into((v512_13).clone());
      }
      drop(v511_7_cursor);
      compose(&(v510_5),&(v511_7))
    };
    drop(v510_5);
    let v510_9: Space = intersect(&(*CONSTANT_2),&(v510_2));
    drop(v510_2);
    let v510_10: Space = if has_head(&(v510_9)) { singleton(&[]) } else { Space::new() };
    drop(v510_9);
    let v510_11: Space = compose(&(v510_10),&(v509_9_tail));
    drop(v510_10);
    let v515_6: Path = concat_path(&(*p0),&(v509_9_head));
    let v510_12: Space = wrap(&(v510_11),&(v515_6));
    drop(v510_11);
    let v510_13: Space = wrap(&(v510_12),&(*p1));
    drop(v510_12);
    let v510_14: Space = unite(&(v510_8),&(v510_13));
    drop(v510_13);
    v509_9.join_into((v510_14).clone());
  }
  drop(v509_9_cursor);
  (v509_9).clone()
}

fn routine_50(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v516_3: Space = wrap(&(*s0),&(*p0));
  let v516_4: Space = wrap(&(v516_3),&(*p1));
  drop(v516_3);
  (v516_4).clone()
}

fn routine_51(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v517_11 = Space::new();
  let mut v517_11_cursor = (*s0).read_zipper();
  for v517_11_byte in v517_11_cursor.child_mask().iter() {
    v517_11_cursor.descend_to_byte(v517_11_byte);
    let v517_11_tail = v517_11_cursor.make_map();
    v517_11_cursor.ascend(1);
    let v517_11_head = Path::from_slice(&[v517_11_byte]);
    let v518_2: Space = singleton(&(v517_11_head));
    let v518_3: Space = intersect(&(*CONSTANT_2),&(v518_2));
    let v518_4: Space = if has_head(&(v518_3)) { singleton(&[]) } else { Space::new() };
    drop(v518_3);
    let v518_5: Space = subtract(&(*CONSTANT_1),&(v518_4));
    drop(v518_4);
    let v518_8: Space = if (v518_5).is_empty() { Space::new() } else {
      let v519_6: Path = concat_path(&(*p0),&(v517_11_head));
      let mut v519_7 = Space::new();
      let mut v519_7_cursor = (v517_11_tail).read_zipper();
      for v519_7_byte in v519_7_cursor.child_mask().iter() {
        v519_7_cursor.descend_to_byte(v519_7_byte);
        let v519_7_tail = v519_7_cursor.make_map();
        v519_7_cursor.ascend(1);
        let v519_7_head = Path::from_slice(&[v519_7_byte]);
        let v520_2: Space = singleton(&(v519_7_head));
        let v520_3: Space = intersect(&(*CONSTANT_2),&(v520_2));
        let v520_4: Space = if has_head(&(v520_3)) { singleton(&[]) } else { Space::new() };
        drop(v520_3);
        let v520_5: Space = subtract(&(*CONSTANT_1),&(v520_4));
        drop(v520_4);
        let v520_8: Space = if (v520_5).is_empty() { Space::new() } else {
          let v521_6: Path = concat_path(&(v519_6),&(v519_7_head));
          let v521_7: Space = routine_96(c, &(v521_6), &(v519_7_tail));
          compose(&(v520_5),&(v521_7))
        };
        drop(v520_5);
        let v520_9: Space = intersect(&(*CONSTANT_2),&(v520_2));
        drop(v520_2);
        let v520_10: Space = if has_head(&(v520_9)) { singleton(&[]) } else { Space::new() };
        drop(v520_9);
        let v520_12: Space = if (v520_10).is_empty() { Space::new() } else {
          let v522_6: Path = concat_path(&(v519_6),&(v519_7_head));
          let v522_11: Space = routine_97(c, &(v522_6), &(v519_7_tail));
          drop(v522_6);
          compose(&(v520_10),&(v522_11))
        };
        drop(v520_10);
        let v520_13: Space = unite(&(v520_8),&(v520_12));
        v519_7.join_into((v520_13).clone());
      }
      drop(v519_7_cursor);
      compose(&(v518_5),&(v519_7))
    };
    drop(v518_5);
    let v518_9: Space = intersect(&(*CONSTANT_2),&(v518_2));
    drop(v518_2);
    let v518_10: Space = if has_head(&(v518_9)) { singleton(&[]) } else { Space::new() };
    drop(v518_9);
    let v518_12: Space = if (v518_10).is_empty() { Space::new() } else {
      let v523_6: Path = concat_path(&(*p0),&(v517_11_head));
      let mut v523_11 = Space::new();
      let mut v523_11_cursor = (v517_11_tail).read_zipper();
      for v523_11_byte in v523_11_cursor.child_mask().iter() {
        v523_11_cursor.descend_to_byte(v523_11_byte);
        let v523_11_tail = v523_11_cursor.make_map();
        v523_11_cursor.ascend(1);
        let v523_11_head = Path::from_slice(&[v523_11_byte]);
        let v524_2: Space = singleton(&(v523_11_head));
        let v524_3: Space = intersect(&(*CONSTANT_2),&(v524_2));
        let v524_4: Space = if has_head(&(v524_3)) { singleton(&[]) } else { Space::new() };
        drop(v524_3);
        let v524_5: Space = subtract(&(*CONSTANT_1),&(v524_4));
        drop(v524_4);
        let v524_8: Space = if (v524_5).is_empty() { Space::new() } else {
          let v525_6: Path = concat_path(&(v523_6),&(v523_11_head));
          let v525_7: Space = routine_96(c, &(v525_6), &(v523_11_tail));
          compose(&(v524_5),&(v525_7))
        };
        drop(v524_5);
        let v524_9: Space = intersect(&(*CONSTANT_2),&(v524_2));
        drop(v524_2);
        let v524_10: Space = if has_head(&(v524_9)) { singleton(&[]) } else { Space::new() };
        drop(v524_9);
        let v524_12: Space = if (v524_10).is_empty() { Space::new() } else {
          let v526_6: Path = concat_path(&(v523_6),&(v523_11_head));
          let v526_11: Space = routine_3(c, &(v526_6), &(v523_11_tail));
          drop(v526_6);
          compose(&(v524_10),&(v526_11))
        };
        drop(v524_10);
        let v524_13: Space = unite(&(v524_8),&(v524_12));
        v523_11.join_into((v524_13).clone());
      }
      drop(v523_11_cursor);
      drop(v523_6);
      compose(&(v518_10),&(v523_11))
    };
    drop(v518_10);
    let v518_13: Space = unite(&(v518_8),&(v518_12));
    v517_11.join_into((v518_13).clone());
  }
  drop(v517_11_cursor);
  (v517_11).clone()
}

fn routine_52(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v527_11 = Space::new();
  let mut v527_11_cursor = (*s0).read_zipper();
  for v527_11_byte in v527_11_cursor.child_mask().iter() {
    v527_11_cursor.descend_to_byte(v527_11_byte);
    let v527_11_tail = v527_11_cursor.make_map();
    v527_11_cursor.ascend(1);
    let v527_11_head = Path::from_slice(&[v527_11_byte]);
    let v528_2: Space = singleton(&(v527_11_head));
    let v528_3: Space = intersect(&(*CONSTANT_2),&(v528_2));
    let v528_4: Space = if has_head(&(v528_3)) { singleton(&[]) } else { Space::new() };
    drop(v528_3);
    let v528_5: Space = subtract(&(*CONSTANT_1),&(v528_4));
    drop(v528_4);
    let v528_8: Space = if (v528_5).is_empty() { Space::new() } else {
      let v529_6: Path = concat_path(&(*p0),&(v527_11_head));
      let mut v529_7 = Space::new();
      let mut v529_7_cursor = (v527_11_tail).read_zipper();
      for v529_7_byte in v529_7_cursor.child_mask().iter() {
        v529_7_cursor.descend_to_byte(v529_7_byte);
        let v529_7_tail = v529_7_cursor.make_map();
        v529_7_cursor.ascend(1);
        let v529_7_head = Path::from_slice(&[v529_7_byte]);
        let v530_2: Space = singleton(&(v529_7_head));
        let v530_3: Space = intersect(&(*CONSTANT_2),&(v530_2));
        let v530_4: Space = if has_head(&(v530_3)) { singleton(&[]) } else { Space::new() };
        drop(v530_3);
        let v530_5: Space = subtract(&(*CONSTANT_1),&(v530_4));
        drop(v530_4);
        let v530_8: Space = if (v530_5).is_empty() { Space::new() } else {
          let v531_6: Path = concat_path(&(v529_6),&(v529_7_head));
          let v531_7: Space = routine_96(c, &(v531_6), &(v529_7_tail));
          compose(&(v530_5),&(v531_7))
        };
        drop(v530_5);
        let v530_9: Space = intersect(&(*CONSTANT_2),&(v530_2));
        drop(v530_2);
        let v530_10: Space = if has_head(&(v530_9)) { singleton(&[]) } else { Space::new() };
        drop(v530_9);
        let v530_12: Space = if (v530_10).is_empty() { Space::new() } else {
          let v532_6: Path = concat_path(&(v529_6),&(v529_7_head));
          let v532_11: Space = routine_97(c, &(v532_6), &(v529_7_tail));
          drop(v532_6);
          compose(&(v530_10),&(v532_11))
        };
        drop(v530_10);
        let v530_13: Space = unite(&(v530_8),&(v530_12));
        v529_7.join_into((v530_13).clone());
      }
      drop(v529_7_cursor);
      compose(&(v528_5),&(v529_7))
    };
    drop(v528_5);
    let v528_9: Space = intersect(&(*CONSTANT_2),&(v528_2));
    drop(v528_2);
    let v528_10: Space = if has_head(&(v528_9)) { singleton(&[]) } else { Space::new() };
    drop(v528_9);
    let v528_12: Space = if (v528_10).is_empty() { Space::new() } else {
      let v533_6: Path = concat_path(&(*p0),&(v527_11_head));
      let mut v533_11 = Space::new();
      let mut v533_11_cursor = (v527_11_tail).read_zipper();
      for v533_11_byte in v533_11_cursor.child_mask().iter() {
        v533_11_cursor.descend_to_byte(v533_11_byte);
        let v533_11_tail = v533_11_cursor.make_map();
        v533_11_cursor.ascend(1);
        let v533_11_head = Path::from_slice(&[v533_11_byte]);
        let v534_2: Space = singleton(&(v533_11_head));
        let v534_3: Space = intersect(&(*CONSTANT_2),&(v534_2));
        let v534_4: Space = if has_head(&(v534_3)) { singleton(&[]) } else { Space::new() };
        drop(v534_3);
        let v534_5: Space = subtract(&(*CONSTANT_1),&(v534_4));
        drop(v534_4);
        let v534_7: Space = if (v534_5).is_empty() { Space::new() } else {
          let v535_6: Space = routine_18(c, &(v533_11_head), &(v533_6), &(v533_11_tail));
          compose(&(v534_5),&(v535_6))
        };
        drop(v534_5);
        let v534_8: Space = intersect(&(*CONSTANT_2),&(v534_2));
        drop(v534_2);
        let v534_9: Space = if has_head(&(v534_8)) { singleton(&[]) } else { Space::new() };
        drop(v534_8);
        let v534_11: Space = if (v534_9).is_empty() { Space::new() } else {
          let v536_10: Space = routine_19(c, &(v533_11_head), &(v533_6), &(v533_11_tail));
          compose(&(v534_9),&(v536_10))
        };
        drop(v534_9);
        let v534_12: Space = unite(&(v534_7),&(v534_11));
        v533_11.join_into((v534_12).clone());
      }
      drop(v533_11_cursor);
      drop(v533_6);
      compose(&(v528_10),&(v533_11))
    };
    drop(v528_10);
    let v528_13: Space = unite(&(v528_8),&(v528_12));
    v527_11.join_into((v528_13).clone());
  }
  drop(v527_11_cursor);
  (v527_11).clone()
}

fn routine_53(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v537_12 = Space::new();
  let mut v537_12_cursor = (*s0).read_zipper();
  for v537_12_byte in v537_12_cursor.child_mask().iter() {
    v537_12_cursor.descend_to_byte(v537_12_byte);
    let v537_12_tail = v537_12_cursor.make_map();
    v537_12_cursor.ascend(1);
    let v537_12_head = Path::from_slice(&[v537_12_byte]);
    let v538_2: Space = singleton(&(v537_12_head));
    let v538_3: Space = intersect(&(*CONSTANT_2),&(v538_2));
    let v538_4: Space = if has_head(&(v538_3)) { singleton(&[]) } else { Space::new() };
    drop(v538_3);
    let v538_5: Space = subtract(&(*CONSTANT_1),&(v538_4));
    drop(v538_4);
    let v538_8: Space = if (v538_5).is_empty() { Space::new() } else {
      let v539_6: Path = concat_path(&(*p0),&(v537_12_head));
      let mut v539_7 = Space::new();
      let mut v539_7_cursor = (v537_12_tail).read_zipper();
      for v539_7_byte in v539_7_cursor.child_mask().iter() {
        v539_7_cursor.descend_to_byte(v539_7_byte);
        let v539_7_tail = v539_7_cursor.make_map();
        v539_7_cursor.ascend(1);
        let v539_7_head = Path::from_slice(&[v539_7_byte]);
        let v540_2: Space = singleton(&(v539_7_head));
        let v540_3: Space = intersect(&(*CONSTANT_2),&(v540_2));
        let v540_4: Space = if has_head(&(v540_3)) { singleton(&[]) } else { Space::new() };
        drop(v540_3);
        let v540_5: Space = subtract(&(*CONSTANT_1),&(v540_4));
        drop(v540_4);
        let v540_8: Space = if (v540_5).is_empty() { Space::new() } else {
          let v541_6: Path = concat_path(&(v539_6),&(v539_7_head));
          let v541_7: Space = routine_98(c, &(v541_6), &(*p1), &(v539_7_tail));
          compose(&(v540_5),&(v541_7))
        };
        drop(v540_5);
        let v540_9: Space = intersect(&(*CONSTANT_2),&(v540_2));
        drop(v540_2);
        let v540_10: Space = if has_head(&(v540_9)) { singleton(&[]) } else { Space::new() };
        drop(v540_9);
        let v540_12: Space = if (v540_10).is_empty() { Space::new() } else {
          let v542_6: Path = concat_path(&(v539_6),&(v539_7_head));
          let v542_11: Space = routine_99(c, &(v542_6), &(*p1), &(v539_7_tail));
          drop(v542_6);
          compose(&(v540_10),&(v542_11))
        };
        drop(v540_10);
        let v540_13: Space = unite(&(v540_8),&(v540_12));
        v539_7.join_into((v540_13).clone());
      }
      drop(v539_7_cursor);
      compose(&(v538_5),&(v539_7))
    };
    drop(v538_5);
    let v538_9: Space = intersect(&(*CONSTANT_2),&(v538_2));
    drop(v538_2);
    let v538_10: Space = if has_head(&(v538_9)) { singleton(&[]) } else { Space::new() };
    drop(v538_9);
    let v538_12: Space = if (v538_10).is_empty() { Space::new() } else {
      let v543_6: Path = concat_path(&(*p0),&(v537_12_head));
      let mut v543_11 = Space::new();
      let mut v543_11_cursor = (v537_12_tail).read_zipper();
      for v543_11_byte in v543_11_cursor.child_mask().iter() {
        v543_11_cursor.descend_to_byte(v543_11_byte);
        let v543_11_tail = v543_11_cursor.make_map();
        v543_11_cursor.ascend(1);
        let v543_11_head = Path::from_slice(&[v543_11_byte]);
        let v544_2: Space = singleton(&(v543_11_head));
        let v544_3: Space = intersect(&(*CONSTANT_2),&(v544_2));
        let v544_4: Space = if has_head(&(v544_3)) { singleton(&[]) } else { Space::new() };
        drop(v544_3);
        let v544_5: Space = subtract(&(*CONSTANT_1),&(v544_4));
        drop(v544_4);
        let v544_8: Space = if (v544_5).is_empty() { Space::new() } else {
          let v545_6: Path = concat_path(&(v543_6),&(v543_11_head));
          let v545_7: Space = routine_98(c, &(v545_6), &(*p1), &(v543_11_tail));
          compose(&(v544_5),&(v545_7))
        };
        drop(v544_5);
        let v544_9: Space = intersect(&(*CONSTANT_2),&(v544_2));
        drop(v544_2);
        let v544_10: Space = if has_head(&(v544_9)) { singleton(&[]) } else { Space::new() };
        drop(v544_9);
        let v544_12: Space = if (v544_10).is_empty() { Space::new() } else {
          let v546_6: Path = concat_path(&(v543_6),&(v543_11_head));
          let v546_11: Space = routine_22(c, &(v546_6), &(*p1), &(v543_11_tail));
          drop(v546_6);
          compose(&(v544_10),&(v546_11))
        };
        drop(v544_10);
        let v544_13: Space = unite(&(v544_8),&(v544_12));
        v543_11.join_into((v544_13).clone());
      }
      drop(v543_11_cursor);
      drop(v543_6);
      compose(&(v538_10),&(v543_11))
    };
    drop(v538_10);
    let v538_13: Space = unite(&(v538_8),&(v538_12));
    v537_12.join_into((v538_13).clone());
  }
  drop(v537_12_cursor);
  (v537_12).clone()
}

fn routine_54(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v547_10 = Space::new();
  let mut v547_10_cursor = (*s0).read_zipper();
  for v547_10_byte in v547_10_cursor.child_mask().iter() {
    v547_10_cursor.descend_to_byte(v547_10_byte);
    let v547_10_tail = v547_10_cursor.make_map();
    v547_10_cursor.ascend(1);
    let v547_10_head = Path::from_slice(&[v547_10_byte]);
    let v548_2: Space = singleton(&(v547_10_head));
    let v548_3: Space = intersect(&(*CONSTANT_2),&(v548_2));
    let v548_4: Space = if has_head(&(v548_3)) { singleton(&[]) } else { Space::new() };
    drop(v548_3);
    let v548_5: Space = compose(&(v548_4),&(v547_10_tail));
    drop(v548_4);
    let v549_6: Path = concat_path(&(*p0),&(v547_10_head));
    let v548_7: Space = wrap(&(v548_5),&(v549_6));
    drop(v548_5);
    let v548_8: Space = wrap(&(v548_7),&(*p1));
    drop(v548_7);
    let v548_9: Space = wrap(&(v548_8),&(*CONSTANT_5));
    drop(v548_8);
    let v548_10: Space = intersect(&(*CONSTANT_2),&(v548_2));
    drop(v548_2);
    let v548_11: Space = if has_head(&(v548_10)) { singleton(&[]) } else { Space::new() };
    drop(v548_10);
    let v548_12: Space = subtract(&(*CONSTANT_1),&(v548_11));
    drop(v548_11);
    let v548_14: Space = if (v548_12).is_empty() { Space::new() } else {
      let mut v550_13 = Space::new();
      let mut v550_13_cursor = (v547_10_tail).read_zipper();
      for v550_13_byte in v550_13_cursor.child_mask().iter() {
        v550_13_cursor.descend_to_byte(v550_13_byte);
        let v550_13_tail = v550_13_cursor.make_map();
        v550_13_cursor.ascend(1);
        let v550_13_head = Path::from_slice(&[v550_13_byte]);
        let v551_2: Space = singleton(&(v550_13_head));
        let v551_3: Space = intersect(&(*CONSTANT_2),&(v551_2));
        let v551_4: Space = if has_head(&(v551_3)) { singleton(&[]) } else { Space::new() };
        drop(v551_3);
        let v551_5: Space = subtract(&(*CONSTANT_1),&(v551_4));
        drop(v551_4);
        let v551_8: Space = if (v551_5).is_empty() { Space::new() } else {
          let v552_6: Path = concat_path(&(v549_6),&(v550_13_head));
          let v552_7: Space = routine_98(c, &(v552_6), &(*p1), &(v550_13_tail));
          compose(&(v551_5),&(v552_7))
        };
        drop(v551_5);
        let v551_9: Space = intersect(&(*CONSTANT_2),&(v551_2));
        drop(v551_2);
        let v551_10: Space = if has_head(&(v551_9)) { singleton(&[]) } else { Space::new() };
        drop(v551_9);
        let v551_12: Space = if (v551_10).is_empty() { Space::new() } else {
          let v553_6: Path = concat_path(&(v549_6),&(v550_13_head));
          let v553_11: Space = routine_99(c, &(v553_6), &(*p1), &(v550_13_tail));
          drop(v553_6);
          compose(&(v551_10),&(v553_11))
        };
        drop(v551_10);
        let v551_13: Space = unite(&(v551_8),&(v551_12));
        v550_13.join_into((v551_13).clone());
      }
      drop(v550_13_cursor);
      compose(&(v548_12),&(v550_13))
    };
    drop(v548_12);
    let v548_15: Space = unite(&(v548_9),&(v548_14));
    drop(v548_9);
    v547_10.join_into((v548_15).clone());
  }
  drop(v547_10_cursor);
  (v547_10).clone()
}

fn routine_55(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v554_12 = Space::new();
  let mut v554_12_cursor = (*s0).read_zipper();
  for v554_12_byte in v554_12_cursor.child_mask().iter() {
    v554_12_cursor.descend_to_byte(v554_12_byte);
    let v554_12_tail = v554_12_cursor.make_map();
    v554_12_cursor.ascend(1);
    let v554_12_head = Path::from_slice(&[v554_12_byte]);
    let v555_2: Space = singleton(&(v554_12_head));
    let v555_3: Space = intersect(&(*CONSTANT_2),&(v555_2));
    let v555_4: Space = if has_head(&(v555_3)) { singleton(&[]) } else { Space::new() };
    drop(v555_3);
    let v555_5: Space = subtract(&(*CONSTANT_1),&(v555_4));
    drop(v555_4);
    let v555_8: Space = if (v555_5).is_empty() { Space::new() } else {
      let v556_6: Path = concat_path(&(*p0),&(v554_12_head));
      let mut v556_7 = Space::new();
      let mut v556_7_cursor = (v554_12_tail).read_zipper();
      for v556_7_byte in v556_7_cursor.child_mask().iter() {
        v556_7_cursor.descend_to_byte(v556_7_byte);
        let v556_7_tail = v556_7_cursor.make_map();
        v556_7_cursor.ascend(1);
        let v556_7_head = Path::from_slice(&[v556_7_byte]);
        let v557_2: Space = singleton(&(v556_7_head));
        let v557_3: Space = intersect(&(*CONSTANT_2),&(v557_2));
        let v557_4: Space = if has_head(&(v557_3)) { singleton(&[]) } else { Space::new() };
        drop(v557_3);
        let v557_5: Space = subtract(&(*CONSTANT_1),&(v557_4));
        drop(v557_4);
        let v557_8: Space = if (v557_5).is_empty() { Space::new() } else {
          let v558_6: Path = concat_path(&(v556_6),&(v556_7_head));
          let v558_7: Space = routine_100(c, &(v558_6), &(*p1), &(v556_7_tail));
          compose(&(v557_5),&(v558_7))
        };
        drop(v557_5);
        let v557_9: Space = intersect(&(*CONSTANT_2),&(v557_2));
        drop(v557_2);
        let v557_10: Space = if has_head(&(v557_9)) { singleton(&[]) } else { Space::new() };
        drop(v557_9);
        let v557_12: Space = if (v557_10).is_empty() { Space::new() } else {
          let v559_6: Path = concat_path(&(v556_6),&(v556_7_head));
          let v559_11: Space = routine_101(c, &(v559_6), &(*p1), &(v556_7_tail));
          drop(v559_6);
          compose(&(v557_10),&(v559_11))
        };
        drop(v557_10);
        let v557_13: Space = unite(&(v557_8),&(v557_12));
        v556_7.join_into((v557_13).clone());
      }
      drop(v556_7_cursor);
      compose(&(v555_5),&(v556_7))
    };
    drop(v555_5);
    let v555_9: Space = intersect(&(*CONSTANT_2),&(v555_2));
    drop(v555_2);
    let v555_10: Space = if has_head(&(v555_9)) { singleton(&[]) } else { Space::new() };
    drop(v555_9);
    let v555_12: Space = if (v555_10).is_empty() { Space::new() } else {
      let v560_6: Path = concat_path(&(*p0),&(v554_12_head));
      let mut v560_11 = Space::new();
      let mut v560_11_cursor = (v554_12_tail).read_zipper();
      for v560_11_byte in v560_11_cursor.child_mask().iter() {
        v560_11_cursor.descend_to_byte(v560_11_byte);
        let v560_11_tail = v560_11_cursor.make_map();
        v560_11_cursor.ascend(1);
        let v560_11_head = Path::from_slice(&[v560_11_byte]);
        let v561_2: Space = singleton(&(v560_11_head));
        let v561_3: Space = intersect(&(*CONSTANT_2),&(v561_2));
        let v561_4: Space = if has_head(&(v561_3)) { singleton(&[]) } else { Space::new() };
        drop(v561_3);
        let v561_5: Space = subtract(&(*CONSTANT_1),&(v561_4));
        drop(v561_4);
        let v561_8: Space = if (v561_5).is_empty() { Space::new() } else {
          let v562_6: Path = concat_path(&(v560_6),&(v560_11_head));
          let v562_7: Space = routine_100(c, &(v562_6), &(*p1), &(v560_11_tail));
          compose(&(v561_5),&(v562_7))
        };
        drop(v561_5);
        let v561_9: Space = intersect(&(*CONSTANT_2),&(v561_2));
        drop(v561_2);
        let v561_10: Space = if has_head(&(v561_9)) { singleton(&[]) } else { Space::new() };
        drop(v561_9);
        let v561_12: Space = if (v561_10).is_empty() { Space::new() } else {
          let v563_6: Path = concat_path(&(v560_6),&(v560_11_head));
          let v563_11: Space = routine_22(c, &(v563_6), &(*p1), &(v560_11_tail));
          drop(v563_6);
          compose(&(v561_10),&(v563_11))
        };
        drop(v561_10);
        let v561_13: Space = unite(&(v561_8),&(v561_12));
        v560_11.join_into((v561_13).clone());
      }
      drop(v560_11_cursor);
      drop(v560_6);
      compose(&(v555_10),&(v560_11))
    };
    drop(v555_10);
    let v555_13: Space = unite(&(v555_8),&(v555_12));
    v554_12.join_into((v555_13).clone());
  }
  drop(v554_12_cursor);
  (v554_12).clone()
}

fn routine_56(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v564_10 = Space::new();
  let mut v564_10_cursor = (*s0).read_zipper();
  for v564_10_byte in v564_10_cursor.child_mask().iter() {
    v564_10_cursor.descend_to_byte(v564_10_byte);
    let v564_10_tail = v564_10_cursor.make_map();
    v564_10_cursor.ascend(1);
    let v564_10_head = Path::from_slice(&[v564_10_byte]);
    let v565_2: Space = singleton(&(v564_10_head));
    let v565_3: Space = intersect(&(*CONSTANT_2),&(v565_2));
    let v565_4: Space = if has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
    drop(v565_3);
    let v565_5: Space = compose(&(v565_4),&(v564_10_tail));
    drop(v565_4);
    let v566_6: Path = concat_path(&(*p0),&(v564_10_head));
    let v565_7: Space = wrap(&(v565_5),&(v566_6));
    drop(v565_5);
    let v565_8: Space = wrap(&(v565_7),&(*p1));
    drop(v565_7);
    let v565_9: Space = wrap(&(v565_8),&(*CONSTANT_5));
    drop(v565_8);
    let v565_10: Space = intersect(&(*CONSTANT_2),&(v565_2));
    drop(v565_2);
    let v565_11: Space = if has_head(&(v565_10)) { singleton(&[]) } else { Space::new() };
    drop(v565_10);
    let v565_12: Space = subtract(&(*CONSTANT_1),&(v565_11));
    drop(v565_11);
    let v565_14: Space = if (v565_12).is_empty() { Space::new() } else {
      let mut v567_13 = Space::new();
      let mut v567_13_cursor = (v564_10_tail).read_zipper();
      for v567_13_byte in v567_13_cursor.child_mask().iter() {
        v567_13_cursor.descend_to_byte(v567_13_byte);
        let v567_13_tail = v567_13_cursor.make_map();
        v567_13_cursor.ascend(1);
        let v567_13_head = Path::from_slice(&[v567_13_byte]);
        let v568_2: Space = singleton(&(v567_13_head));
        let v568_3: Space = intersect(&(*CONSTANT_2),&(v568_2));
        let v568_4: Space = if has_head(&(v568_3)) { singleton(&[]) } else { Space::new() };
        drop(v568_3);
        let v568_5: Space = subtract(&(*CONSTANT_1),&(v568_4));
        drop(v568_4);
        let v568_8: Space = if (v568_5).is_empty() { Space::new() } else {
          let v569_6: Path = concat_path(&(v566_6),&(v567_13_head));
          let v569_7: Space = routine_100(c, &(v569_6), &(*p1), &(v567_13_tail));
          compose(&(v568_5),&(v569_7))
        };
        drop(v568_5);
        let v568_9: Space = intersect(&(*CONSTANT_2),&(v568_2));
        drop(v568_2);
        let v568_10: Space = if has_head(&(v568_9)) { singleton(&[]) } else { Space::new() };
        drop(v568_9);
        let v568_12: Space = if (v568_10).is_empty() { Space::new() } else {
          let v570_6: Path = concat_path(&(v566_6),&(v567_13_head));
          let v570_11: Space = routine_101(c, &(v570_6), &(*p1), &(v567_13_tail));
          drop(v570_6);
          compose(&(v568_10),&(v570_11))
        };
        drop(v568_10);
        let v568_13: Space = unite(&(v568_8),&(v568_12));
        v567_13.join_into((v568_13).clone());
      }
      drop(v567_13_cursor);
      compose(&(v565_12),&(v567_13))
    };
    drop(v565_12);
    let v565_15: Space = unite(&(v565_9),&(v565_14));
    drop(v565_9);
    v564_10.join_into((v565_15).clone());
  }
  drop(v564_10_cursor);
  (v564_10).clone()
}

fn routine_57(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v571_12 = Space::new();
  let mut v571_12_cursor = (*s0).read_zipper();
  for v571_12_byte in v571_12_cursor.child_mask().iter() {
    v571_12_cursor.descend_to_byte(v571_12_byte);
    let v571_12_tail = v571_12_cursor.make_map();
    v571_12_cursor.ascend(1);
    let v571_12_head = Path::from_slice(&[v571_12_byte]);
    let v572_2: Space = singleton(&(v571_12_head));
    let v572_3: Space = intersect(&(*CONSTANT_2),&(v572_2));
    let v572_4: Space = if has_head(&(v572_3)) { singleton(&[]) } else { Space::new() };
    drop(v572_3);
    let v572_5: Space = subtract(&(*CONSTANT_1),&(v572_4));
    drop(v572_4);
    let v572_8: Space = if (v572_5).is_empty() { Space::new() } else {
      let v573_6: Path = concat_path(&(*p0),&(v571_12_head));
      let mut v573_7 = Space::new();
      let mut v573_7_cursor = (v571_12_tail).read_zipper();
      for v573_7_byte in v573_7_cursor.child_mask().iter() {
        v573_7_cursor.descend_to_byte(v573_7_byte);
        let v573_7_tail = v573_7_cursor.make_map();
        v573_7_cursor.ascend(1);
        let v573_7_head = Path::from_slice(&[v573_7_byte]);
        let v574_2: Space = singleton(&(v573_7_head));
        let v574_3: Space = intersect(&(*CONSTANT_2),&(v574_2));
        let v574_4: Space = if has_head(&(v574_3)) { singleton(&[]) } else { Space::new() };
        drop(v574_3);
        let v574_5: Space = subtract(&(*CONSTANT_1),&(v574_4));
        drop(v574_4);
        let v574_8: Space = if (v574_5).is_empty() { Space::new() } else {
          let v575_6: Path = concat_path(&(v573_6),&(v573_7_head));
          let v575_7: Space = routine_102(c, &(v575_6), &(v573_7_tail), &(*s1));
          compose(&(v574_5),&(v575_7))
        };
        drop(v574_5);
        let v574_9: Space = intersect(&(*CONSTANT_2),&(v574_2));
        drop(v574_2);
        let v574_10: Space = if has_head(&(v574_9)) { singleton(&[]) } else { Space::new() };
        drop(v574_9);
        let v574_12: Space = if (v574_10).is_empty() { Space::new() } else {
          let v576_6: Path = concat_path(&(v573_6),&(v573_7_head));
          let v576_11: Space = routine_103(c, &(v576_6), &(v573_7_tail), &(*s1));
          drop(v576_6);
          compose(&(v574_10),&(v576_11))
        };
        drop(v574_10);
        let v574_13: Space = unite(&(v574_8),&(v574_12));
        v573_7.join_into((v574_13).clone());
      }
      drop(v573_7_cursor);
      compose(&(v572_5),&(v573_7))
    };
    drop(v572_5);
    let v572_9: Space = intersect(&(*CONSTANT_2),&(v572_2));
    drop(v572_2);
    let v572_10: Space = if has_head(&(v572_9)) { singleton(&[]) } else { Space::new() };
    drop(v572_9);
    let v572_12: Space = if (v572_10).is_empty() { Space::new() } else {
      let v577_6: Path = concat_path(&(*p0),&(v571_12_head));
      let mut v577_11 = Space::new();
      let mut v577_11_cursor = (v571_12_tail).read_zipper();
      for v577_11_byte in v577_11_cursor.child_mask().iter() {
        v577_11_cursor.descend_to_byte(v577_11_byte);
        let v577_11_tail = v577_11_cursor.make_map();
        v577_11_cursor.ascend(1);
        let v577_11_head = Path::from_slice(&[v577_11_byte]);
        let v578_2: Space = singleton(&(v577_11_head));
        let v578_3: Space = intersect(&(*CONSTANT_2),&(v578_2));
        let v578_4: Space = if has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
        drop(v578_3);
        let v578_5: Space = subtract(&(*CONSTANT_1),&(v578_4));
        drop(v578_4);
        let v578_8: Space = if (v578_5).is_empty() { Space::new() } else {
          let v579_6: Path = concat_path(&(v577_6),&(v577_11_head));
          let v579_7: Space = routine_102(c, &(v579_6), &(v577_11_tail), &(*s1));
          compose(&(v578_5),&(v579_7))
        };
        drop(v578_5);
        let v578_9: Space = intersect(&(*CONSTANT_2),&(v578_2));
        drop(v578_2);
        let v578_10: Space = if has_head(&(v578_9)) { singleton(&[]) } else { Space::new() };
        drop(v578_9);
        let v578_12: Space = if (v578_10).is_empty() { Space::new() } else {
          let v580_6: Path = concat_path(&(v577_6),&(v577_11_head));
          let v580_11: Space = routine_6(c, &(v580_6), &(v577_11_tail), &(*s1));
          drop(v580_6);
          compose(&(v578_10),&(v580_11))
        };
        drop(v578_10);
        let v578_13: Space = unite(&(v578_8),&(v578_12));
        v577_11.join_into((v578_13).clone());
      }
      drop(v577_11_cursor);
      drop(v577_6);
      compose(&(v572_10),&(v577_11))
    };
    drop(v572_10);
    let v572_13: Space = unite(&(v572_8),&(v572_12));
    v571_12.join_into((v572_13).clone());
  }
  drop(v571_12_cursor);
  (v571_12).clone()
}

fn routine_58(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v581_12 = Space::new();
  let mut v581_12_cursor = (*s0).read_zipper();
  for v581_12_byte in v581_12_cursor.child_mask().iter() {
    v581_12_cursor.descend_to_byte(v581_12_byte);
    let v581_12_tail = v581_12_cursor.make_map();
    v581_12_cursor.ascend(1);
    let v581_12_head = Path::from_slice(&[v581_12_byte]);
    let v582_2: Space = singleton(&(v581_12_head));
    let v582_3: Space = intersect(&(*CONSTANT_2),&(v582_2));
    let v582_4: Space = if has_head(&(v582_3)) { singleton(&[]) } else { Space::new() };
    drop(v582_3);
    let v582_5: Space = subtract(&(*CONSTANT_1),&(v582_4));
    drop(v582_4);
    let v582_8: Space = if (v582_5).is_empty() { Space::new() } else {
      let v583_6: Path = concat_path(&(*p0),&(v581_12_head));
      let mut v583_7 = Space::new();
      let mut v583_7_cursor = (v581_12_tail).read_zipper();
      for v583_7_byte in v583_7_cursor.child_mask().iter() {
        v583_7_cursor.descend_to_byte(v583_7_byte);
        let v583_7_tail = v583_7_cursor.make_map();
        v583_7_cursor.ascend(1);
        let v583_7_head = Path::from_slice(&[v583_7_byte]);
        let v584_2: Space = singleton(&(v583_7_head));
        let v584_3: Space = intersect(&(*CONSTANT_2),&(v584_2));
        let v584_4: Space = if has_head(&(v584_3)) { singleton(&[]) } else { Space::new() };
        drop(v584_3);
        let v584_5: Space = subtract(&(*CONSTANT_1),&(v584_4));
        drop(v584_4);
        let v584_8: Space = if (v584_5).is_empty() { Space::new() } else {
          let v585_6: Path = concat_path(&(v583_6),&(v583_7_head));
          let v585_7: Space = routine_102(c, &(v585_6), &(v583_7_tail), &(*s1));
          compose(&(v584_5),&(v585_7))
        };
        drop(v584_5);
        let v584_9: Space = intersect(&(*CONSTANT_2),&(v584_2));
        drop(v584_2);
        let v584_10: Space = if has_head(&(v584_9)) { singleton(&[]) } else { Space::new() };
        drop(v584_9);
        let v584_12: Space = if (v584_10).is_empty() { Space::new() } else {
          let v586_6: Path = concat_path(&(v583_6),&(v583_7_head));
          let v586_11: Space = routine_103(c, &(v586_6), &(v583_7_tail), &(*s1));
          drop(v586_6);
          compose(&(v584_10),&(v586_11))
        };
        drop(v584_10);
        let v584_13: Space = unite(&(v584_8),&(v584_12));
        v583_7.join_into((v584_13).clone());
      }
      drop(v583_7_cursor);
      compose(&(v582_5),&(v583_7))
    };
    drop(v582_5);
    let v582_9: Space = intersect(&(*CONSTANT_2),&(v582_2));
    drop(v582_2);
    let v582_10: Space = if has_head(&(v582_9)) { singleton(&[]) } else { Space::new() };
    drop(v582_9);
    let v582_12: Space = if (v582_10).is_empty() { Space::new() } else {
      let v587_6: Path = concat_path(&(*p0),&(v581_12_head));
      let mut v587_11 = Space::new();
      let mut v587_11_cursor = (v581_12_tail).read_zipper();
      for v587_11_byte in v587_11_cursor.child_mask().iter() {
        v587_11_cursor.descend_to_byte(v587_11_byte);
        let v587_11_tail = v587_11_cursor.make_map();
        v587_11_cursor.ascend(1);
        let v587_11_head = Path::from_slice(&[v587_11_byte]);
        let v588_2: Space = singleton(&(v587_11_head));
        let v588_3: Space = intersect(&(*CONSTANT_2),&(v588_2));
        let v588_4: Space = if has_head(&(v588_3)) { singleton(&[]) } else { Space::new() };
        drop(v588_3);
        let v588_5: Space = subtract(&(*CONSTANT_1),&(v588_4));
        drop(v588_4);
        let v588_7: Space = if (v588_5).is_empty() { Space::new() } else {
          let v589_6: Space = routine_25(c, &(v587_11_head), &(v587_6), &(v587_11_tail), &(*s1));
          compose(&(v588_5),&(v589_6))
        };
        drop(v588_5);
        let v588_8: Space = intersect(&(*CONSTANT_2),&(v588_2));
        drop(v588_2);
        let v588_9: Space = if has_head(&(v588_8)) { singleton(&[]) } else { Space::new() };
        drop(v588_8);
        let v588_11: Space = if (v588_9).is_empty() { Space::new() } else {
          let v590_10: Space = routine_26(c, &(v587_11_head), &(v587_6), &(v587_11_tail), &(*s1));
          compose(&(v588_9),&(v590_10))
        };
        drop(v588_9);
        let v588_12: Space = unite(&(v588_7),&(v588_11));
        v587_11.join_into((v588_12).clone());
      }
      drop(v587_11_cursor);
      drop(v587_6);
      compose(&(v582_10),&(v587_11))
    };
    drop(v582_10);
    let v582_13: Space = unite(&(v582_8),&(v582_12));
    v581_12.join_into((v582_13).clone());
  }
  drop(v581_12_cursor);
  (v581_12).clone()
}

fn routine_59(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v591_13 = Space::new();
  let mut v591_13_cursor = (*s0).read_zipper();
  for v591_13_byte in v591_13_cursor.child_mask().iter() {
    v591_13_cursor.descend_to_byte(v591_13_byte);
    let v591_13_tail = v591_13_cursor.make_map();
    v591_13_cursor.ascend(1);
    let v591_13_head = Path::from_slice(&[v591_13_byte]);
    let v592_2: Space = singleton(&(v591_13_head));
    let v592_3: Space = intersect(&(*CONSTANT_2),&(v592_2));
    let v592_4: Space = if has_head(&(v592_3)) { singleton(&[]) } else { Space::new() };
    drop(v592_3);
    let v592_5: Space = subtract(&(*CONSTANT_1),&(v592_4));
    drop(v592_4);
    let v592_8: Space = if (v592_5).is_empty() { Space::new() } else {
      let v593_6: Path = concat_path(&(*p0),&(v591_13_head));
      let mut v593_7 = Space::new();
      let mut v593_7_cursor = (v591_13_tail).read_zipper();
      for v593_7_byte in v593_7_cursor.child_mask().iter() {
        v593_7_cursor.descend_to_byte(v593_7_byte);
        let v593_7_tail = v593_7_cursor.make_map();
        v593_7_cursor.ascend(1);
        let v593_7_head = Path::from_slice(&[v593_7_byte]);
        let v594_2: Space = singleton(&(v593_7_head));
        let v594_3: Space = intersect(&(*CONSTANT_2),&(v594_2));
        let v594_4: Space = if has_head(&(v594_3)) { singleton(&[]) } else { Space::new() };
        drop(v594_3);
        let v594_5: Space = subtract(&(*CONSTANT_1),&(v594_4));
        drop(v594_4);
        let v594_8: Space = if (v594_5).is_empty() { Space::new() } else {
          let v595_6: Path = concat_path(&(v593_6),&(v593_7_head));
          let v595_7: Space = routine_104(c, &(v595_6), &(*p1), &(v593_7_tail), &(*s1));
          compose(&(v594_5),&(v595_7))
        };
        drop(v594_5);
        let v594_9: Space = intersect(&(*CONSTANT_2),&(v594_2));
        drop(v594_2);
        let v594_10: Space = if has_head(&(v594_9)) { singleton(&[]) } else { Space::new() };
        drop(v594_9);
        let v594_12: Space = if (v594_10).is_empty() { Space::new() } else {
          let v596_6: Path = concat_path(&(v593_6),&(v593_7_head));
          let v596_11: Space = routine_105(c, &(v596_6), &(*p1), &(v593_7_tail), &(*s1));
          drop(v596_6);
          compose(&(v594_10),&(v596_11))
        };
        drop(v594_10);
        let v594_13: Space = unite(&(v594_8),&(v594_12));
        v593_7.join_into((v594_13).clone());
      }
      drop(v593_7_cursor);
      compose(&(v592_5),&(v593_7))
    };
    drop(v592_5);
    let v592_9: Space = intersect(&(*CONSTANT_2),&(v592_2));
    drop(v592_2);
    let v592_10: Space = if has_head(&(v592_9)) { singleton(&[]) } else { Space::new() };
    drop(v592_9);
    let v592_12: Space = if (v592_10).is_empty() { Space::new() } else {
      let v597_6: Path = concat_path(&(*p0),&(v591_13_head));
      let mut v597_11 = Space::new();
      let mut v597_11_cursor = (v591_13_tail).read_zipper();
      for v597_11_byte in v597_11_cursor.child_mask().iter() {
        v597_11_cursor.descend_to_byte(v597_11_byte);
        let v597_11_tail = v597_11_cursor.make_map();
        v597_11_cursor.ascend(1);
        let v597_11_head = Path::from_slice(&[v597_11_byte]);
        let v598_2: Space = singleton(&(v597_11_head));
        let v598_3: Space = intersect(&(*CONSTANT_2),&(v598_2));
        let v598_4: Space = if has_head(&(v598_3)) { singleton(&[]) } else { Space::new() };
        drop(v598_3);
        let v598_5: Space = subtract(&(*CONSTANT_1),&(v598_4));
        drop(v598_4);
        let v598_8: Space = if (v598_5).is_empty() { Space::new() } else {
          let v599_6: Path = concat_path(&(v597_6),&(v597_11_head));
          let v599_7: Space = routine_104(c, &(v599_6), &(*p1), &(v597_11_tail), &(*s1));
          compose(&(v598_5),&(v599_7))
        };
        drop(v598_5);
        let v598_9: Space = intersect(&(*CONSTANT_2),&(v598_2));
        drop(v598_2);
        let v598_10: Space = if has_head(&(v598_9)) { singleton(&[]) } else { Space::new() };
        drop(v598_9);
        let v598_12: Space = if (v598_10).is_empty() { Space::new() } else {
          let v600_6: Path = concat_path(&(v597_6),&(v597_11_head));
          let v600_11: Space = routine_29(c, &(v600_6), &(*p1), &(v597_11_tail), &(*s1));
          drop(v600_6);
          compose(&(v598_10),&(v600_11))
        };
        drop(v598_10);
        let v598_13: Space = unite(&(v598_8),&(v598_12));
        v597_11.join_into((v598_13).clone());
      }
      drop(v597_11_cursor);
      drop(v597_6);
      compose(&(v592_10),&(v597_11))
    };
    drop(v592_10);
    let v592_13: Space = unite(&(v592_8),&(v592_12));
    v591_13.join_into((v592_13).clone());
  }
  drop(v591_13_cursor);
  (v591_13).clone()
}

fn routine_60(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v601_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v601_10: Space = unwrap(&(v601_8),&(*CONSTANT_5));
  drop(v601_8);
  let v601_11: Space = unwrap(&(v601_10),&(*p0));
  drop(v601_10);
  let mut v601_18 = Space::new();
  let mut v601_18_cursor = (*s0).read_zipper();
  for v601_18_byte in v601_18_cursor.child_mask().iter() {
    v601_18_cursor.descend_to_byte(v601_18_byte);
    let v601_18_tail = v601_18_cursor.make_map();
    v601_18_cursor.ascend(1);
    let v601_18_head = Path::from_slice(&[v601_18_byte]);
    let v602_2: Space = singleton(&(v601_18_head));
    let v602_3: Space = intersect(&(*CONSTANT_2),&(v602_2));
    let v602_4: Space = if has_head(&(v602_3)) { singleton(&[]) } else { Space::new() };
    drop(v602_3);
    let v602_5: Space = subtract(&(*CONSTANT_1),&(v602_4));
    drop(v602_4);
    let v602_8: Space = if (v602_5).is_empty() { Space::new() } else {
      let v603_6: Path = concat_path(&(*p0),&(v601_18_head));
      let mut v603_7 = Space::new();
      let mut v603_7_cursor = (v601_18_tail).read_zipper();
      for v603_7_byte in v603_7_cursor.child_mask().iter() {
        v603_7_cursor.descend_to_byte(v603_7_byte);
        let v603_7_tail = v603_7_cursor.make_map();
        v603_7_cursor.ascend(1);
        let v603_7_head = Path::from_slice(&[v603_7_byte]);
        let v604_2: Space = singleton(&(v603_7_head));
        let v604_3: Space = intersect(&(*CONSTANT_2),&(v604_2));
        let v604_4: Space = if has_head(&(v604_3)) { singleton(&[]) } else { Space::new() };
        drop(v604_3);
        let v604_5: Space = subtract(&(*CONSTANT_1),&(v604_4));
        drop(v604_4);
        let v604_8: Space = if (v604_5).is_empty() { Space::new() } else {
          let v605_6: Path = concat_path(&(v603_6),&(v603_7_head));
          let v605_7: Space = routine_104(c, &(v605_6), &(*p1), &(v603_7_tail), &(*s1));
          compose(&(v604_5),&(v605_7))
        };
        drop(v604_5);
        let v604_9: Space = intersect(&(*CONSTANT_2),&(v604_2));
        drop(v604_2);
        let v604_10: Space = if has_head(&(v604_9)) { singleton(&[]) } else { Space::new() };
        drop(v604_9);
        let v604_12: Space = if (v604_10).is_empty() { Space::new() } else {
          let v606_6: Path = concat_path(&(v603_6),&(v603_7_head));
          let v606_11: Space = routine_105(c, &(v606_6), &(*p1), &(v603_7_tail), &(*s1));
          drop(v606_6);
          compose(&(v604_10),&(v606_11))
        };
        drop(v604_10);
        let v604_13: Space = unite(&(v604_8),&(v604_12));
        v603_7.join_into((v604_13).clone());
      }
      drop(v603_7_cursor);
      drop(v603_6);
      compose(&(v602_5),&(v603_7))
    };
    drop(v602_5);
    let v602_9: Space = intersect(&(*CONSTANT_2),&(v602_2));
    drop(v602_2);
    let v602_10: Space = if has_head(&(v602_9)) { singleton(&[]) } else { Space::new() };
    drop(v602_9);
    let v602_13: Space = if (v602_10).is_empty() { Space::new() } else {
      let v607_11: Space = unwrap(&(v601_11),&(v601_18_head));
      let mut v607_12 = Space::new();
      let mut v607_12_cursor = (v607_11).read_zipper();
      for v607_12_byte in v607_12_cursor.child_mask().iter() {
        v607_12_cursor.descend_to_byte(v607_12_byte);
        let v607_12_tail = v607_12_cursor.make_map();
        v607_12_cursor.ascend(1);
        let v607_12_head = Path::from_slice(&[v607_12_byte]);
        let v608_2: Space = singleton(&(v607_12_head));
        let v608_3: Space = intersect(&(*CONSTANT_2),&(v608_2));
        let v608_4: Space = if has_head(&(v608_3)) { singleton(&[]) } else { Space::new() };
        drop(v608_3);
        let v608_5: Space = subtract(&(*CONSTANT_1),&(v608_4));
        drop(v608_4);
        let v608_7: Space = if (v608_5).is_empty() { Space::new() } else {
          let v609_6: Space = routine_61(c, &(v607_12_head), &(*p1), &(v607_12_tail));
          compose(&(v608_5),&(v609_6))
        };
        drop(v608_5);
        let v608_8: Space = intersect(&(*CONSTANT_2),&(v608_2));
        drop(v608_2);
        let v608_9: Space = if has_head(&(v608_8)) { singleton(&[]) } else { Space::new() };
        drop(v608_8);
        let v608_11: Space = if (v608_9).is_empty() { Space::new() } else {
          let v610_10: Space = routine_62(c, &(v607_12_head), &(*p1), &(v607_12_tail));
          compose(&(v608_9),&(v610_10))
        };
        drop(v608_9);
        let v608_12: Space = unite(&(v608_7),&(v608_11));
        v607_12.join_into((v608_12).clone());
      }
      drop(v607_12_cursor);
      drop(v607_11);
      compose(&(v602_10),&(v607_12))
    };
    drop(v602_10);
    let v602_14: Space = unite(&(v602_8),&(v602_13));
    v601_18.join_into((v602_14).clone());
  }
  drop(v601_18_cursor);
  drop(v601_11);
  (v601_18).clone()
}

fn routine_61(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v611_12 = Space::new();
  let mut v611_12_cursor = (*s0).read_zipper();
  for v611_12_byte in v611_12_cursor.child_mask().iter() {
    v611_12_cursor.descend_to_byte(v611_12_byte);
    let v611_12_tail = v611_12_cursor.make_map();
    v611_12_cursor.ascend(1);
    let v611_12_head = Path::from_slice(&[v611_12_byte]);
    let v612_2: Space = singleton(&(v611_12_head));
    let v612_3: Space = intersect(&(*CONSTANT_2),&(v612_2));
    let v612_4: Space = if has_head(&(v612_3)) { singleton(&[]) } else { Space::new() };
    drop(v612_3);
    let v612_5: Space = subtract(&(*CONSTANT_1),&(v612_4));
    drop(v612_4);
    let v612_8: Space = if (v612_5).is_empty() { Space::new() } else {
      let v613_6: Path = concat_path(&(*p0),&(v611_12_head));
      let mut v613_7 = Space::new();
      let mut v613_7_cursor = (v611_12_tail).read_zipper();
      for v613_7_byte in v613_7_cursor.child_mask().iter() {
        v613_7_cursor.descend_to_byte(v613_7_byte);
        let v613_7_tail = v613_7_cursor.make_map();
        v613_7_cursor.ascend(1);
        let v613_7_head = Path::from_slice(&[v613_7_byte]);
        let v614_2: Space = singleton(&(v613_7_head));
        let v614_3: Space = intersect(&(*CONSTANT_2),&(v614_2));
        let v614_4: Space = if has_head(&(v614_3)) { singleton(&[]) } else { Space::new() };
        drop(v614_3);
        let v614_5: Space = subtract(&(*CONSTANT_1),&(v614_4));
        drop(v614_4);
        let v614_8: Space = if (v614_5).is_empty() { Space::new() } else {
          let v615_6: Path = concat_path(&(v613_6),&(v613_7_head));
          let v615_7: Space = routine_106(c, &(v615_6), &(*p1), &(v613_7_tail));
          compose(&(v614_5),&(v615_7))
        };
        drop(v614_5);
        let v614_9: Space = intersect(&(*CONSTANT_2),&(v614_2));
        drop(v614_2);
        let v614_10: Space = if has_head(&(v614_9)) { singleton(&[]) } else { Space::new() };
        drop(v614_9);
        let v614_12: Space = if (v614_10).is_empty() { Space::new() } else {
          let v616_6: Path = concat_path(&(v613_6),&(v613_7_head));
          let v616_11: Space = routine_107(c, &(v616_6), &(*p1), &(v613_7_tail));
          drop(v616_6);
          compose(&(v614_10),&(v616_11))
        };
        drop(v614_10);
        let v614_13: Space = unite(&(v614_8),&(v614_12));
        v613_7.join_into((v614_13).clone());
      }
      drop(v613_7_cursor);
      compose(&(v612_5),&(v613_7))
    };
    drop(v612_5);
    let v612_9: Space = intersect(&(*CONSTANT_2),&(v612_2));
    drop(v612_2);
    let v612_10: Space = if has_head(&(v612_9)) { singleton(&[]) } else { Space::new() };
    drop(v612_9);
    let v612_12: Space = if (v612_10).is_empty() { Space::new() } else {
      let v617_6: Path = concat_path(&(*p0),&(v611_12_head));
      let mut v617_11 = Space::new();
      let mut v617_11_cursor = (v611_12_tail).read_zipper();
      for v617_11_byte in v617_11_cursor.child_mask().iter() {
        v617_11_cursor.descend_to_byte(v617_11_byte);
        let v617_11_tail = v617_11_cursor.make_map();
        v617_11_cursor.ascend(1);
        let v617_11_head = Path::from_slice(&[v617_11_byte]);
        let v618_2: Space = singleton(&(v617_11_head));
        let v618_3: Space = intersect(&(*CONSTANT_2),&(v618_2));
        let v618_4: Space = if has_head(&(v618_3)) { singleton(&[]) } else { Space::new() };
        drop(v618_3);
        let v618_5: Space = subtract(&(*CONSTANT_1),&(v618_4));
        drop(v618_4);
        let v618_8: Space = if (v618_5).is_empty() { Space::new() } else {
          let v619_6: Path = concat_path(&(v617_6),&(v617_11_head));
          let v619_7: Space = routine_106(c, &(v619_6), &(*p1), &(v617_11_tail));
          compose(&(v618_5),&(v619_7))
        };
        drop(v618_5);
        let v618_9: Space = intersect(&(*CONSTANT_2),&(v618_2));
        drop(v618_2);
        let v618_10: Space = if has_head(&(v618_9)) { singleton(&[]) } else { Space::new() };
        drop(v618_9);
        let v618_12: Space = if (v618_10).is_empty() { Space::new() } else {
          let v620_6: Path = concat_path(&(v617_6),&(v617_11_head));
          let v620_11: Space = routine_67(c, &(v620_6), &(*p1), &(v617_11_tail));
          drop(v620_6);
          compose(&(v618_10),&(v620_11))
        };
        drop(v618_10);
        let v618_13: Space = unite(&(v618_8),&(v618_12));
        v617_11.join_into((v618_13).clone());
      }
      drop(v617_11_cursor);
      drop(v617_6);
      compose(&(v612_10),&(v617_11))
    };
    drop(v612_10);
    let v612_13: Space = unite(&(v612_8),&(v612_12));
    v611_12.join_into((v612_13).clone());
  }
  drop(v611_12_cursor);
  (v611_12).clone()
}

fn routine_62(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v621_9 = Space::new();
  let mut v621_9_cursor = (*s0).read_zipper();
  for v621_9_byte in v621_9_cursor.child_mask().iter() {
    v621_9_cursor.descend_to_byte(v621_9_byte);
    let v621_9_tail = v621_9_cursor.make_map();
    v621_9_cursor.ascend(1);
    let v621_9_head = Path::from_slice(&[v621_9_byte]);
    let v622_2: Space = singleton(&(v621_9_head));
    let v622_3: Space = intersect(&(*CONSTANT_2),&(v622_2));
    let v622_4: Space = if has_head(&(v622_3)) { singleton(&[]) } else { Space::new() };
    drop(v622_3);
    let v622_5: Space = subtract(&(*CONSTANT_1),&(v622_4));
    drop(v622_4);
    let v622_8: Space = if (v622_5).is_empty() { Space::new() } else {
      let v623_6: Path = concat_path(&(*p0),&(v621_9_head));
      let mut v623_7 = Space::new();
      let mut v623_7_cursor = (v621_9_tail).read_zipper();
      for v623_7_byte in v623_7_cursor.child_mask().iter() {
        v623_7_cursor.descend_to_byte(v623_7_byte);
        let v623_7_tail = v623_7_cursor.make_map();
        v623_7_cursor.ascend(1);
        let v623_7_head = Path::from_slice(&[v623_7_byte]);
        let v624_2: Space = singleton(&(v623_7_head));
        let v624_3: Space = intersect(&(*CONSTANT_2),&(v624_2));
        let v624_4: Space = if has_head(&(v624_3)) { singleton(&[]) } else { Space::new() };
        drop(v624_3);
        let v624_5: Space = subtract(&(*CONSTANT_1),&(v624_4));
        drop(v624_4);
        let v624_8: Space = if (v624_5).is_empty() { Space::new() } else {
          let v625_6: Path = concat_path(&(v623_6),&(v623_7_head));
          let v625_7: Space = routine_106(c, &(v625_6), &(*p1), &(v623_7_tail));
          compose(&(v624_5),&(v625_7))
        };
        drop(v624_5);
        let v624_9: Space = intersect(&(*CONSTANT_2),&(v624_2));
        drop(v624_2);
        let v624_10: Space = if has_head(&(v624_9)) { singleton(&[]) } else { Space::new() };
        drop(v624_9);
        let v624_12: Space = if (v624_10).is_empty() { Space::new() } else {
          let v626_6: Path = concat_path(&(v623_6),&(v623_7_head));
          let v626_11: Space = routine_107(c, &(v626_6), &(*p1), &(v623_7_tail));
          drop(v626_6);
          compose(&(v624_10),&(v626_11))
        };
        drop(v624_10);
        let v624_13: Space = unite(&(v624_8),&(v624_12));
        v623_7.join_into((v624_13).clone());
      }
      drop(v623_7_cursor);
      compose(&(v622_5),&(v623_7))
    };
    drop(v622_5);
    let v622_9: Space = intersect(&(*CONSTANT_2),&(v622_2));
    drop(v622_2);
    let v622_10: Space = if has_head(&(v622_9)) { singleton(&[]) } else { Space::new() };
    drop(v622_9);
    let v622_11: Space = compose(&(v622_10),&(v621_9_tail));
    drop(v622_10);
    let v627_6: Path = concat_path(&(*p0),&(v621_9_head));
    let v622_12: Space = wrap(&(v622_11),&(v627_6));
    drop(v622_11);
    let v622_13: Space = wrap(&(v622_12),&(*p1));
    drop(v622_12);
    let v622_14: Space = unite(&(v622_8),&(v622_13));
    drop(v622_13);
    v621_9.join_into((v622_14).clone());
  }
  drop(v621_9_cursor);
  (v621_9).clone()
}

fn routine_63(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v628_13 = Space::new();
  let mut v628_13_cursor = (*s0).read_zipper();
  for v628_13_byte in v628_13_cursor.child_mask().iter() {
    v628_13_cursor.descend_to_byte(v628_13_byte);
    let v628_13_tail = v628_13_cursor.make_map();
    v628_13_cursor.ascend(1);
    let v628_13_head = Path::from_slice(&[v628_13_byte]);
    let v629_2: Space = singleton(&(v628_13_head));
    let v629_3: Space = intersect(&(*CONSTANT_2),&(v629_2));
    let v629_4: Space = if has_head(&(v629_3)) { singleton(&[]) } else { Space::new() };
    drop(v629_3);
    let v629_5: Space = subtract(&(*CONSTANT_1),&(v629_4));
    drop(v629_4);
    let v629_8: Space = if (v629_5).is_empty() { Space::new() } else {
      let v630_6: Path = concat_path(&(*p0),&(v628_13_head));
      let mut v630_7 = Space::new();
      let mut v630_7_cursor = (v628_13_tail).read_zipper();
      for v630_7_byte in v630_7_cursor.child_mask().iter() {
        v630_7_cursor.descend_to_byte(v630_7_byte);
        let v630_7_tail = v630_7_cursor.make_map();
        v630_7_cursor.ascend(1);
        let v630_7_head = Path::from_slice(&[v630_7_byte]);
        let v631_2: Space = singleton(&(v630_7_head));
        let v631_3: Space = intersect(&(*CONSTANT_2),&(v631_2));
        let v631_4: Space = if has_head(&(v631_3)) { singleton(&[]) } else { Space::new() };
        drop(v631_3);
        let v631_5: Space = subtract(&(*CONSTANT_1),&(v631_4));
        drop(v631_4);
        let v631_8: Space = if (v631_5).is_empty() { Space::new() } else {
          let v632_6: Path = concat_path(&(v630_6),&(v630_7_head));
          let v632_7: Space = routine_108(c, &(v632_6), &(*p1), &(v630_7_tail), &(*s1));
          compose(&(v631_5),&(v632_7))
        };
        drop(v631_5);
        let v631_9: Space = intersect(&(*CONSTANT_2),&(v631_2));
        drop(v631_2);
        let v631_10: Space = if has_head(&(v631_9)) { singleton(&[]) } else { Space::new() };
        drop(v631_9);
        let v631_12: Space = if (v631_10).is_empty() { Space::new() } else {
          let v633_6: Path = concat_path(&(v630_6),&(v630_7_head));
          let v633_11: Space = routine_109(c, &(v633_6), &(*p1), &(v630_7_tail), &(*s1));
          drop(v633_6);
          compose(&(v631_10),&(v633_11))
        };
        drop(v631_10);
        let v631_13: Space = unite(&(v631_8),&(v631_12));
        v630_7.join_into((v631_13).clone());
      }
      drop(v630_7_cursor);
      compose(&(v629_5),&(v630_7))
    };
    drop(v629_5);
    let v629_9: Space = intersect(&(*CONSTANT_2),&(v629_2));
    drop(v629_2);
    let v629_10: Space = if has_head(&(v629_9)) { singleton(&[]) } else { Space::new() };
    drop(v629_9);
    let v629_12: Space = if (v629_10).is_empty() { Space::new() } else {
      let v634_6: Path = concat_path(&(*p0),&(v628_13_head));
      let mut v634_11 = Space::new();
      let mut v634_11_cursor = (v628_13_tail).read_zipper();
      for v634_11_byte in v634_11_cursor.child_mask().iter() {
        v634_11_cursor.descend_to_byte(v634_11_byte);
        let v634_11_tail = v634_11_cursor.make_map();
        v634_11_cursor.ascend(1);
        let v634_11_head = Path::from_slice(&[v634_11_byte]);
        let v635_2: Space = singleton(&(v634_11_head));
        let v635_3: Space = intersect(&(*CONSTANT_2),&(v635_2));
        let v635_4: Space = if has_head(&(v635_3)) { singleton(&[]) } else { Space::new() };
        drop(v635_3);
        let v635_5: Space = subtract(&(*CONSTANT_1),&(v635_4));
        drop(v635_4);
        let v635_8: Space = if (v635_5).is_empty() { Space::new() } else {
          let v636_6: Path = concat_path(&(v634_6),&(v634_11_head));
          let v636_7: Space = routine_108(c, &(v636_6), &(*p1), &(v634_11_tail), &(*s1));
          compose(&(v635_5),&(v636_7))
        };
        drop(v635_5);
        let v635_9: Space = intersect(&(*CONSTANT_2),&(v635_2));
        drop(v635_2);
        let v635_10: Space = if has_head(&(v635_9)) { singleton(&[]) } else { Space::new() };
        drop(v635_9);
        let v635_12: Space = if (v635_10).is_empty() { Space::new() } else {
          let v637_6: Path = concat_path(&(v634_6),&(v634_11_head));
          let v637_11: Space = routine_29(c, &(v637_6), &(*p1), &(v634_11_tail), &(*s1));
          drop(v637_6);
          compose(&(v635_10),&(v637_11))
        };
        drop(v635_10);
        let v635_13: Space = unite(&(v635_8),&(v635_12));
        v634_11.join_into((v635_13).clone());
      }
      drop(v634_11_cursor);
      drop(v634_6);
      compose(&(v629_10),&(v634_11))
    };
    drop(v629_10);
    let v629_13: Space = unite(&(v629_8),&(v629_12));
    v628_13.join_into((v629_13).clone());
  }
  drop(v628_13_cursor);
  (v628_13).clone()
}

fn routine_64(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v638_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v638_10: Space = unwrap(&(v638_8),&(*CONSTANT_5));
  drop(v638_8);
  let v638_11: Space = unwrap(&(v638_10),&(*p0));
  drop(v638_10);
  let mut v638_18 = Space::new();
  let mut v638_18_cursor = (*s0).read_zipper();
  for v638_18_byte in v638_18_cursor.child_mask().iter() {
    v638_18_cursor.descend_to_byte(v638_18_byte);
    let v638_18_tail = v638_18_cursor.make_map();
    v638_18_cursor.ascend(1);
    let v638_18_head = Path::from_slice(&[v638_18_byte]);
    let v639_2: Space = singleton(&(v638_18_head));
    let v639_3: Space = intersect(&(*CONSTANT_2),&(v639_2));
    let v639_4: Space = if has_head(&(v639_3)) { singleton(&[]) } else { Space::new() };
    drop(v639_3);
    let v639_5: Space = subtract(&(*CONSTANT_1),&(v639_4));
    drop(v639_4);
    let v639_8: Space = if (v639_5).is_empty() { Space::new() } else {
      let v640_6: Path = concat_path(&(*p0),&(v638_18_head));
      let mut v640_7 = Space::new();
      let mut v640_7_cursor = (v638_18_tail).read_zipper();
      for v640_7_byte in v640_7_cursor.child_mask().iter() {
        v640_7_cursor.descend_to_byte(v640_7_byte);
        let v640_7_tail = v640_7_cursor.make_map();
        v640_7_cursor.ascend(1);
        let v640_7_head = Path::from_slice(&[v640_7_byte]);
        let v641_2: Space = singleton(&(v640_7_head));
        let v641_3: Space = intersect(&(*CONSTANT_2),&(v641_2));
        let v641_4: Space = if has_head(&(v641_3)) { singleton(&[]) } else { Space::new() };
        drop(v641_3);
        let v641_5: Space = subtract(&(*CONSTANT_1),&(v641_4));
        drop(v641_4);
        let v641_8: Space = if (v641_5).is_empty() { Space::new() } else {
          let v642_6: Path = concat_path(&(v640_6),&(v640_7_head));
          let v642_7: Space = routine_108(c, &(v642_6), &(*p1), &(v640_7_tail), &(*s1));
          compose(&(v641_5),&(v642_7))
        };
        drop(v641_5);
        let v641_9: Space = intersect(&(*CONSTANT_2),&(v641_2));
        drop(v641_2);
        let v641_10: Space = if has_head(&(v641_9)) { singleton(&[]) } else { Space::new() };
        drop(v641_9);
        let v641_12: Space = if (v641_10).is_empty() { Space::new() } else {
          let v643_6: Path = concat_path(&(v640_6),&(v640_7_head));
          let v643_11: Space = routine_109(c, &(v643_6), &(*p1), &(v640_7_tail), &(*s1));
          drop(v643_6);
          compose(&(v641_10),&(v643_11))
        };
        drop(v641_10);
        let v641_13: Space = unite(&(v641_8),&(v641_12));
        v640_7.join_into((v641_13).clone());
      }
      drop(v640_7_cursor);
      drop(v640_6);
      compose(&(v639_5),&(v640_7))
    };
    drop(v639_5);
    let v639_9: Space = intersect(&(*CONSTANT_2),&(v639_2));
    drop(v639_2);
    let v639_10: Space = if has_head(&(v639_9)) { singleton(&[]) } else { Space::new() };
    drop(v639_9);
    let v639_13: Space = if (v639_10).is_empty() { Space::new() } else {
      let v644_11: Space = unwrap(&(v638_11),&(v638_18_head));
      let mut v644_12 = Space::new();
      let mut v644_12_cursor = (v644_11).read_zipper();
      for v644_12_byte in v644_12_cursor.child_mask().iter() {
        v644_12_cursor.descend_to_byte(v644_12_byte);
        let v644_12_tail = v644_12_cursor.make_map();
        v644_12_cursor.ascend(1);
        let v644_12_head = Path::from_slice(&[v644_12_byte]);
        let v645_2: Space = singleton(&(v644_12_head));
        let v645_3: Space = intersect(&(*CONSTANT_2),&(v645_2));
        let v645_4: Space = if has_head(&(v645_3)) { singleton(&[]) } else { Space::new() };
        drop(v645_3);
        let v645_5: Space = subtract(&(*CONSTANT_1),&(v645_4));
        drop(v645_4);
        let v645_7: Space = if (v645_5).is_empty() { Space::new() } else {
          let v646_6: Space = routine_61(c, &(v644_12_head), &(*p1), &(v644_12_tail));
          compose(&(v645_5),&(v646_6))
        };
        drop(v645_5);
        let v645_8: Space = intersect(&(*CONSTANT_2),&(v645_2));
        drop(v645_2);
        let v645_9: Space = if has_head(&(v645_8)) { singleton(&[]) } else { Space::new() };
        drop(v645_8);
        let v645_11: Space = if (v645_9).is_empty() { Space::new() } else {
          let v647_10: Space = routine_62(c, &(v644_12_head), &(*p1), &(v644_12_tail));
          compose(&(v645_9),&(v647_10))
        };
        drop(v645_9);
        let v645_12: Space = unite(&(v645_7),&(v645_11));
        v644_12.join_into((v645_12).clone());
      }
      drop(v644_12_cursor);
      drop(v644_11);
      compose(&(v639_10),&(v644_12))
    };
    drop(v639_10);
    let v639_14: Space = unite(&(v639_8),&(v639_13));
    v638_18.join_into((v639_14).clone());
  }
  drop(v638_18_cursor);
  drop(v638_11);
  (v638_18).clone()
}

fn routine_65(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v648_12 = Space::new();
  let mut v648_12_cursor = (*s0).read_zipper();
  for v648_12_byte in v648_12_cursor.child_mask().iter() {
    v648_12_cursor.descend_to_byte(v648_12_byte);
    let v648_12_tail = v648_12_cursor.make_map();
    v648_12_cursor.ascend(1);
    let v648_12_head = Path::from_slice(&[v648_12_byte]);
    let v649_2: Space = singleton(&(v648_12_head));
    let v649_3: Space = intersect(&(*CONSTANT_2),&(v649_2));
    let v649_4: Space = if has_head(&(v649_3)) { singleton(&[]) } else { Space::new() };
    drop(v649_3);
    let v649_5: Space = subtract(&(*CONSTANT_1),&(v649_4));
    drop(v649_4);
    let v649_8: Space = if (v649_5).is_empty() { Space::new() } else {
      let v650_6: Path = concat_path(&(*p0),&(v648_12_head));
      let mut v650_7 = Space::new();
      let mut v650_7_cursor = (v648_12_tail).read_zipper();
      for v650_7_byte in v650_7_cursor.child_mask().iter() {
        v650_7_cursor.descend_to_byte(v650_7_byte);
        let v650_7_tail = v650_7_cursor.make_map();
        v650_7_cursor.ascend(1);
        let v650_7_head = Path::from_slice(&[v650_7_byte]);
        let v651_2: Space = singleton(&(v650_7_head));
        let v651_3: Space = intersect(&(*CONSTANT_2),&(v651_2));
        let v651_4: Space = if has_head(&(v651_3)) { singleton(&[]) } else { Space::new() };
        drop(v651_3);
        let v651_5: Space = subtract(&(*CONSTANT_1),&(v651_4));
        drop(v651_4);
        let v651_8: Space = if (v651_5).is_empty() { Space::new() } else {
          let v652_6: Path = concat_path(&(v650_6),&(v650_7_head));
          let v652_7: Space = routine_110(c, &(v652_6), &(*p1), &(v650_7_tail));
          compose(&(v651_5),&(v652_7))
        };
        drop(v651_5);
        let v651_9: Space = intersect(&(*CONSTANT_2),&(v651_2));
        drop(v651_2);
        let v651_10: Space = if has_head(&(v651_9)) { singleton(&[]) } else { Space::new() };
        drop(v651_9);
        let v651_12: Space = if (v651_10).is_empty() { Space::new() } else {
          let v653_6: Path = concat_path(&(v650_6),&(v650_7_head));
          let v653_11: Space = routine_111(c, &(v653_6), &(*p1), &(v650_7_tail));
          drop(v653_6);
          compose(&(v651_10),&(v653_11))
        };
        drop(v651_10);
        let v651_13: Space = unite(&(v651_8),&(v651_12));
        v650_7.join_into((v651_13).clone());
      }
      drop(v650_7_cursor);
      compose(&(v649_5),&(v650_7))
    };
    drop(v649_5);
    let v649_9: Space = intersect(&(*CONSTANT_2),&(v649_2));
    drop(v649_2);
    let v649_10: Space = if has_head(&(v649_9)) { singleton(&[]) } else { Space::new() };
    drop(v649_9);
    let v649_12: Space = if (v649_10).is_empty() { Space::new() } else {
      let v654_6: Path = concat_path(&(*p0),&(v648_12_head));
      let mut v654_11 = Space::new();
      let mut v654_11_cursor = (v648_12_tail).read_zipper();
      for v654_11_byte in v654_11_cursor.child_mask().iter() {
        v654_11_cursor.descend_to_byte(v654_11_byte);
        let v654_11_tail = v654_11_cursor.make_map();
        v654_11_cursor.ascend(1);
        let v654_11_head = Path::from_slice(&[v654_11_byte]);
        let v655_2: Space = singleton(&(v654_11_head));
        let v655_3: Space = intersect(&(*CONSTANT_2),&(v655_2));
        let v655_4: Space = if has_head(&(v655_3)) { singleton(&[]) } else { Space::new() };
        drop(v655_3);
        let v655_5: Space = subtract(&(*CONSTANT_1),&(v655_4));
        drop(v655_4);
        let v655_8: Space = if (v655_5).is_empty() { Space::new() } else {
          let v656_6: Path = concat_path(&(v654_6),&(v654_11_head));
          let v656_7: Space = routine_110(c, &(v656_6), &(*p1), &(v654_11_tail));
          compose(&(v655_5),&(v656_7))
        };
        drop(v655_5);
        let v655_9: Space = intersect(&(*CONSTANT_2),&(v655_2));
        drop(v655_2);
        let v655_10: Space = if has_head(&(v655_9)) { singleton(&[]) } else { Space::new() };
        drop(v655_9);
        let v655_12: Space = if (v655_10).is_empty() { Space::new() } else {
          let v657_6: Path = concat_path(&(v654_6),&(v654_11_head));
          let v657_11: Space = routine_67(c, &(v657_6), &(*p1), &(v654_11_tail));
          drop(v657_6);
          compose(&(v655_10),&(v657_11))
        };
        drop(v655_10);
        let v655_13: Space = unite(&(v655_8),&(v655_12));
        v654_11.join_into((v655_13).clone());
      }
      drop(v654_11_cursor);
      drop(v654_6);
      compose(&(v649_10),&(v654_11))
    };
    drop(v649_10);
    let v649_13: Space = unite(&(v649_8),&(v649_12));
    v648_12.join_into((v649_13).clone());
  }
  drop(v648_12_cursor);
  (v648_12).clone()
}

fn routine_66(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v658_9 = Space::new();
  let mut v658_9_cursor = (*s0).read_zipper();
  for v658_9_byte in v658_9_cursor.child_mask().iter() {
    v658_9_cursor.descend_to_byte(v658_9_byte);
    let v658_9_tail = v658_9_cursor.make_map();
    v658_9_cursor.ascend(1);
    let v658_9_head = Path::from_slice(&[v658_9_byte]);
    let v659_2: Space = singleton(&(v658_9_head));
    let v659_3: Space = intersect(&(*CONSTANT_2),&(v659_2));
    let v659_4: Space = if has_head(&(v659_3)) { singleton(&[]) } else { Space::new() };
    drop(v659_3);
    let v659_5: Space = subtract(&(*CONSTANT_1),&(v659_4));
    drop(v659_4);
    let v659_8: Space = if (v659_5).is_empty() { Space::new() } else {
      let v660_6: Path = concat_path(&(*p0),&(v658_9_head));
      let mut v660_7 = Space::new();
      let mut v660_7_cursor = (v658_9_tail).read_zipper();
      for v660_7_byte in v660_7_cursor.child_mask().iter() {
        v660_7_cursor.descend_to_byte(v660_7_byte);
        let v660_7_tail = v660_7_cursor.make_map();
        v660_7_cursor.ascend(1);
        let v660_7_head = Path::from_slice(&[v660_7_byte]);
        let v661_2: Space = singleton(&(v660_7_head));
        let v661_3: Space = intersect(&(*CONSTANT_2),&(v661_2));
        let v661_4: Space = if has_head(&(v661_3)) { singleton(&[]) } else { Space::new() };
        drop(v661_3);
        let v661_5: Space = subtract(&(*CONSTANT_1),&(v661_4));
        drop(v661_4);
        let v661_8: Space = if (v661_5).is_empty() { Space::new() } else {
          let v662_6: Path = concat_path(&(v660_6),&(v660_7_head));
          let v662_7: Space = routine_110(c, &(v662_6), &(*p1), &(v660_7_tail));
          compose(&(v661_5),&(v662_7))
        };
        drop(v661_5);
        let v661_9: Space = intersect(&(*CONSTANT_2),&(v661_2));
        drop(v661_2);
        let v661_10: Space = if has_head(&(v661_9)) { singleton(&[]) } else { Space::new() };
        drop(v661_9);
        let v661_12: Space = if (v661_10).is_empty() { Space::new() } else {
          let v663_6: Path = concat_path(&(v660_6),&(v660_7_head));
          let v663_11: Space = routine_111(c, &(v663_6), &(*p1), &(v660_7_tail));
          drop(v663_6);
          compose(&(v661_10),&(v663_11))
        };
        drop(v661_10);
        let v661_13: Space = unite(&(v661_8),&(v661_12));
        v660_7.join_into((v661_13).clone());
      }
      drop(v660_7_cursor);
      compose(&(v659_5),&(v660_7))
    };
    drop(v659_5);
    let v659_9: Space = intersect(&(*CONSTANT_2),&(v659_2));
    drop(v659_2);
    let v659_10: Space = if has_head(&(v659_9)) { singleton(&[]) } else { Space::new() };
    drop(v659_9);
    let v659_11: Space = compose(&(v659_10),&(v658_9_tail));
    drop(v659_10);
    let v664_6: Path = concat_path(&(*p0),&(v658_9_head));
    let v659_12: Space = wrap(&(v659_11),&(v664_6));
    drop(v659_11);
    let v659_13: Space = wrap(&(v659_12),&(*p1));
    drop(v659_12);
    let v659_14: Space = unite(&(v659_8),&(v659_13));
    drop(v659_13);
    v658_9.join_into((v659_14).clone());
  }
  drop(v658_9_cursor);
  (v658_9).clone()
}

fn routine_67(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v665_3: Space = wrap(&(*s0),&(*p0));
  let v665_4: Space = wrap(&(v665_3),&(*p1));
  drop(v665_3);
  (v665_4).clone()
}

fn routine_68(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v666_12 = Space::new();
  let mut v666_12_cursor = (*s0).read_zipper();
  for v666_12_byte in v666_12_cursor.child_mask().iter() {
    v666_12_cursor.descend_to_byte(v666_12_byte);
    let v666_12_tail = v666_12_cursor.make_map();
    v666_12_cursor.ascend(1);
    let v666_12_head = Path::from_slice(&[v666_12_byte]);
    let v667_2: Space = singleton(&(v666_12_head));
    let v667_3: Space = intersect(&(*CONSTANT_2),&(v667_2));
    let v667_4: Space = if has_head(&(v667_3)) { singleton(&[]) } else { Space::new() };
    drop(v667_3);
    let v667_5: Space = subtract(&(*CONSTANT_1),&(v667_4));
    drop(v667_4);
    let v667_8: Space = if (v667_5).is_empty() { Space::new() } else {
      let v668_6: Path = concat_path(&(*p0),&(v666_12_head));
      let mut v668_7 = Space::new();
      let mut v668_7_cursor = (v666_12_tail).read_zipper();
      for v668_7_byte in v668_7_cursor.child_mask().iter() {
        v668_7_cursor.descend_to_byte(v668_7_byte);
        let v668_7_tail = v668_7_cursor.make_map();
        v668_7_cursor.ascend(1);
        let v668_7_head = Path::from_slice(&[v668_7_byte]);
        let v669_2: Space = singleton(&(v668_7_head));
        let v669_3: Space = intersect(&(*CONSTANT_2),&(v669_2));
        let v669_4: Space = if has_head(&(v669_3)) { singleton(&[]) } else { Space::new() };
        drop(v669_3);
        let v669_5: Space = subtract(&(*CONSTANT_1),&(v669_4));
        drop(v669_4);
        let v669_8: Space = if (v669_5).is_empty() { Space::new() } else {
          let v670_6: Path = concat_path(&(v668_6),&(v668_7_head));
          let v670_7: Space = routine_112(c, &(v670_6), &(v668_7_tail), &(*s1));
          compose(&(v669_5),&(v670_7))
        };
        drop(v669_5);
        let v669_9: Space = intersect(&(*CONSTANT_2),&(v669_2));
        drop(v669_2);
        let v669_10: Space = if has_head(&(v669_9)) { singleton(&[]) } else { Space::new() };
        drop(v669_9);
        let v669_12: Space = if (v669_10).is_empty() { Space::new() } else {
          let v671_6: Path = concat_path(&(v668_6),&(v668_7_head));
          let v671_11: Space = routine_113(c, &(v671_6), &(v668_7_tail), &(*s1));
          drop(v671_6);
          compose(&(v669_10),&(v671_11))
        };
        drop(v669_10);
        let v669_13: Space = unite(&(v669_8),&(v669_12));
        v668_7.join_into((v669_13).clone());
      }
      drop(v668_7_cursor);
      compose(&(v667_5),&(v668_7))
    };
    drop(v667_5);
    let v667_9: Space = intersect(&(*CONSTANT_2),&(v667_2));
    drop(v667_2);
    let v667_10: Space = if has_head(&(v667_9)) { singleton(&[]) } else { Space::new() };
    drop(v667_9);
    let v667_12: Space = if (v667_10).is_empty() { Space::new() } else {
      let v672_6: Path = concat_path(&(*p0),&(v666_12_head));
      let mut v672_11 = Space::new();
      let mut v672_11_cursor = (v666_12_tail).read_zipper();
      for v672_11_byte in v672_11_cursor.child_mask().iter() {
        v672_11_cursor.descend_to_byte(v672_11_byte);
        let v672_11_tail = v672_11_cursor.make_map();
        v672_11_cursor.ascend(1);
        let v672_11_head = Path::from_slice(&[v672_11_byte]);
        let v673_2: Space = singleton(&(v672_11_head));
        let v673_3: Space = intersect(&(*CONSTANT_2),&(v673_2));
        let v673_4: Space = if has_head(&(v673_3)) { singleton(&[]) } else { Space::new() };
        drop(v673_3);
        let v673_5: Space = subtract(&(*CONSTANT_1),&(v673_4));
        drop(v673_4);
        let v673_8: Space = if (v673_5).is_empty() { Space::new() } else {
          let v674_6: Path = concat_path(&(v672_6),&(v672_11_head));
          let v674_7: Space = routine_112(c, &(v674_6), &(v672_11_tail), &(*s1));
          compose(&(v673_5),&(v674_7))
        };
        drop(v673_5);
        let v673_9: Space = intersect(&(*CONSTANT_2),&(v673_2));
        drop(v673_2);
        let v673_10: Space = if has_head(&(v673_9)) { singleton(&[]) } else { Space::new() };
        drop(v673_9);
        let v673_12: Space = if (v673_10).is_empty() { Space::new() } else {
          let v675_6: Path = concat_path(&(v672_6),&(v672_11_head));
          let v675_11: Space = routine_9(c, &(v675_6), &(v672_11_tail), &(*s1));
          drop(v675_6);
          compose(&(v673_10),&(v675_11))
        };
        drop(v673_10);
        let v673_13: Space = unite(&(v673_8),&(v673_12));
        v672_11.join_into((v673_13).clone());
      }
      drop(v672_11_cursor);
      drop(v672_6);
      compose(&(v667_10),&(v672_11))
    };
    drop(v667_10);
    let v667_13: Space = unite(&(v667_8),&(v667_12));
    v666_12.join_into((v667_13).clone());
  }
  drop(v666_12_cursor);
  (v666_12).clone()
}

fn routine_69(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v676_12 = Space::new();
  let mut v676_12_cursor = (*s0).read_zipper();
  for v676_12_byte in v676_12_cursor.child_mask().iter() {
    v676_12_cursor.descend_to_byte(v676_12_byte);
    let v676_12_tail = v676_12_cursor.make_map();
    v676_12_cursor.ascend(1);
    let v676_12_head = Path::from_slice(&[v676_12_byte]);
    let v677_2: Space = singleton(&(v676_12_head));
    let v677_3: Space = intersect(&(*CONSTANT_2),&(v677_2));
    let v677_4: Space = if has_head(&(v677_3)) { singleton(&[]) } else { Space::new() };
    drop(v677_3);
    let v677_5: Space = subtract(&(*CONSTANT_1),&(v677_4));
    drop(v677_4);
    let v677_8: Space = if (v677_5).is_empty() { Space::new() } else {
      let v678_6: Path = concat_path(&(*p0),&(v676_12_head));
      let mut v678_7 = Space::new();
      let mut v678_7_cursor = (v676_12_tail).read_zipper();
      for v678_7_byte in v678_7_cursor.child_mask().iter() {
        v678_7_cursor.descend_to_byte(v678_7_byte);
        let v678_7_tail = v678_7_cursor.make_map();
        v678_7_cursor.ascend(1);
        let v678_7_head = Path::from_slice(&[v678_7_byte]);
        let v679_2: Space = singleton(&(v678_7_head));
        let v679_3: Space = intersect(&(*CONSTANT_2),&(v679_2));
        let v679_4: Space = if has_head(&(v679_3)) { singleton(&[]) } else { Space::new() };
        drop(v679_3);
        let v679_5: Space = subtract(&(*CONSTANT_1),&(v679_4));
        drop(v679_4);
        let v679_8: Space = if (v679_5).is_empty() { Space::new() } else {
          let v680_6: Path = concat_path(&(v678_6),&(v678_7_head));
          let v680_7: Space = routine_112(c, &(v680_6), &(v678_7_tail), &(*s1));
          compose(&(v679_5),&(v680_7))
        };
        drop(v679_5);
        let v679_9: Space = intersect(&(*CONSTANT_2),&(v679_2));
        drop(v679_2);
        let v679_10: Space = if has_head(&(v679_9)) { singleton(&[]) } else { Space::new() };
        drop(v679_9);
        let v679_12: Space = if (v679_10).is_empty() { Space::new() } else {
          let v681_6: Path = concat_path(&(v678_6),&(v678_7_head));
          let v681_11: Space = routine_113(c, &(v681_6), &(v678_7_tail), &(*s1));
          drop(v681_6);
          compose(&(v679_10),&(v681_11))
        };
        drop(v679_10);
        let v679_13: Space = unite(&(v679_8),&(v679_12));
        v678_7.join_into((v679_13).clone());
      }
      drop(v678_7_cursor);
      compose(&(v677_5),&(v678_7))
    };
    drop(v677_5);
    let v677_9: Space = intersect(&(*CONSTANT_2),&(v677_2));
    drop(v677_2);
    let v677_10: Space = if has_head(&(v677_9)) { singleton(&[]) } else { Space::new() };
    drop(v677_9);
    let v677_12: Space = if (v677_10).is_empty() { Space::new() } else {
      let v682_6: Path = concat_path(&(*p0),&(v676_12_head));
      let mut v682_11 = Space::new();
      let mut v682_11_cursor = (v676_12_tail).read_zipper();
      for v682_11_byte in v682_11_cursor.child_mask().iter() {
        v682_11_cursor.descend_to_byte(v682_11_byte);
        let v682_11_tail = v682_11_cursor.make_map();
        v682_11_cursor.ascend(1);
        let v682_11_head = Path::from_slice(&[v682_11_byte]);
        let v683_2: Space = singleton(&(v682_11_head));
        let v683_3: Space = intersect(&(*CONSTANT_2),&(v683_2));
        let v683_4: Space = if has_head(&(v683_3)) { singleton(&[]) } else { Space::new() };
        drop(v683_3);
        let v683_5: Space = subtract(&(*CONSTANT_1),&(v683_4));
        drop(v683_4);
        let v683_7: Space = if (v683_5).is_empty() { Space::new() } else {
          let v684_6: Space = routine_32(c, &(v682_11_head), &(v682_6), &(v682_11_tail), &(*s1));
          compose(&(v683_5),&(v684_6))
        };
        drop(v683_5);
        let v683_8: Space = intersect(&(*CONSTANT_2),&(v683_2));
        drop(v683_2);
        let v683_9: Space = if has_head(&(v683_8)) { singleton(&[]) } else { Space::new() };
        drop(v683_8);
        let v683_11: Space = if (v683_9).is_empty() { Space::new() } else {
          let v685_10: Space = routine_33(c, &(v682_11_head), &(v682_6), &(v682_11_tail), &(*s1));
          compose(&(v683_9),&(v685_10))
        };
        drop(v683_9);
        let v683_12: Space = unite(&(v683_7),&(v683_11));
        v682_11.join_into((v683_12).clone());
      }
      drop(v682_11_cursor);
      drop(v682_6);
      compose(&(v677_10),&(v682_11))
    };
    drop(v677_10);
    let v677_13: Space = unite(&(v677_8),&(v677_12));
    v676_12.join_into((v677_13).clone());
  }
  drop(v676_12_cursor);
  (v676_12).clone()
}

fn routine_70(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v686_13 = Space::new();
  let mut v686_13_cursor = (*s0).read_zipper();
  for v686_13_byte in v686_13_cursor.child_mask().iter() {
    v686_13_cursor.descend_to_byte(v686_13_byte);
    let v686_13_tail = v686_13_cursor.make_map();
    v686_13_cursor.ascend(1);
    let v686_13_head = Path::from_slice(&[v686_13_byte]);
    let v687_2: Space = singleton(&(v686_13_head));
    let v687_3: Space = intersect(&(*CONSTANT_2),&(v687_2));
    let v687_4: Space = if has_head(&(v687_3)) { singleton(&[]) } else { Space::new() };
    drop(v687_3);
    let v687_5: Space = subtract(&(*CONSTANT_1),&(v687_4));
    drop(v687_4);
    let v687_8: Space = if (v687_5).is_empty() { Space::new() } else {
      let v688_6: Path = concat_path(&(*p0),&(v686_13_head));
      let mut v688_7 = Space::new();
      let mut v688_7_cursor = (v686_13_tail).read_zipper();
      for v688_7_byte in v688_7_cursor.child_mask().iter() {
        v688_7_cursor.descend_to_byte(v688_7_byte);
        let v688_7_tail = v688_7_cursor.make_map();
        v688_7_cursor.ascend(1);
        let v688_7_head = Path::from_slice(&[v688_7_byte]);
        let v689_2: Space = singleton(&(v688_7_head));
        let v689_3: Space = intersect(&(*CONSTANT_2),&(v689_2));
        let v689_4: Space = if has_head(&(v689_3)) { singleton(&[]) } else { Space::new() };
        drop(v689_3);
        let v689_5: Space = subtract(&(*CONSTANT_1),&(v689_4));
        drop(v689_4);
        let v689_8: Space = if (v689_5).is_empty() { Space::new() } else {
          let v690_6: Path = concat_path(&(v688_6),&(v688_7_head));
          let v690_7: Space = routine_114(c, &(v690_6), &(*p1), &(v688_7_tail), &(*s1));
          compose(&(v689_5),&(v690_7))
        };
        drop(v689_5);
        let v689_9: Space = intersect(&(*CONSTANT_2),&(v689_2));
        drop(v689_2);
        let v689_10: Space = if has_head(&(v689_9)) { singleton(&[]) } else { Space::new() };
        drop(v689_9);
        let v689_12: Space = if (v689_10).is_empty() { Space::new() } else {
          let v691_6: Path = concat_path(&(v688_6),&(v688_7_head));
          let v691_11: Space = routine_115(c, &(v691_6), &(*p1), &(v688_7_tail), &(*s1));
          drop(v691_6);
          compose(&(v689_10),&(v691_11))
        };
        drop(v689_10);
        let v689_13: Space = unite(&(v689_8),&(v689_12));
        v688_7.join_into((v689_13).clone());
      }
      drop(v688_7_cursor);
      compose(&(v687_5),&(v688_7))
    };
    drop(v687_5);
    let v687_9: Space = intersect(&(*CONSTANT_2),&(v687_2));
    drop(v687_2);
    let v687_10: Space = if has_head(&(v687_9)) { singleton(&[]) } else { Space::new() };
    drop(v687_9);
    let v687_12: Space = if (v687_10).is_empty() { Space::new() } else {
      let v692_6: Path = concat_path(&(*p0),&(v686_13_head));
      let mut v692_11 = Space::new();
      let mut v692_11_cursor = (v686_13_tail).read_zipper();
      for v692_11_byte in v692_11_cursor.child_mask().iter() {
        v692_11_cursor.descend_to_byte(v692_11_byte);
        let v692_11_tail = v692_11_cursor.make_map();
        v692_11_cursor.ascend(1);
        let v692_11_head = Path::from_slice(&[v692_11_byte]);
        let v693_2: Space = singleton(&(v692_11_head));
        let v693_3: Space = intersect(&(*CONSTANT_2),&(v693_2));
        let v693_4: Space = if has_head(&(v693_3)) { singleton(&[]) } else { Space::new() };
        drop(v693_3);
        let v693_5: Space = subtract(&(*CONSTANT_1),&(v693_4));
        drop(v693_4);
        let v693_8: Space = if (v693_5).is_empty() { Space::new() } else {
          let v694_6: Path = concat_path(&(v692_6),&(v692_11_head));
          let v694_7: Space = routine_114(c, &(v694_6), &(*p1), &(v692_11_tail), &(*s1));
          compose(&(v693_5),&(v694_7))
        };
        drop(v693_5);
        let v693_9: Space = intersect(&(*CONSTANT_2),&(v693_2));
        drop(v693_2);
        let v693_10: Space = if has_head(&(v693_9)) { singleton(&[]) } else { Space::new() };
        drop(v693_9);
        let v693_12: Space = if (v693_10).is_empty() { Space::new() } else {
          let v695_6: Path = concat_path(&(v692_6),&(v692_11_head));
          let v695_11: Space = routine_36(c, &(v695_6), &(*p1), &(v692_11_tail), &(*s1));
          drop(v695_6);
          compose(&(v693_10),&(v695_11))
        };
        drop(v693_10);
        let v693_13: Space = unite(&(v693_8),&(v693_12));
        v692_11.join_into((v693_13).clone());
      }
      drop(v692_11_cursor);
      drop(v692_6);
      compose(&(v687_10),&(v692_11))
    };
    drop(v687_10);
    let v687_13: Space = unite(&(v687_8),&(v687_12));
    v686_13.join_into((v687_13).clone());
  }
  drop(v686_13_cursor);
  (v686_13).clone()
}

fn routine_71(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v696_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v696_10: Space = unwrap(&(v696_8),&(*CONSTANT_5));
  drop(v696_8);
  let v696_11: Space = unwrap(&(v696_10),&(*p0));
  drop(v696_10);
  let mut v696_18 = Space::new();
  let mut v696_18_cursor = (*s0).read_zipper();
  for v696_18_byte in v696_18_cursor.child_mask().iter() {
    v696_18_cursor.descend_to_byte(v696_18_byte);
    let v696_18_tail = v696_18_cursor.make_map();
    v696_18_cursor.ascend(1);
    let v696_18_head = Path::from_slice(&[v696_18_byte]);
    let v697_2: Space = singleton(&(v696_18_head));
    let v697_3: Space = intersect(&(*CONSTANT_2),&(v697_2));
    let v697_4: Space = if has_head(&(v697_3)) { singleton(&[]) } else { Space::new() };
    drop(v697_3);
    let v697_5: Space = subtract(&(*CONSTANT_1),&(v697_4));
    drop(v697_4);
    let v697_8: Space = if (v697_5).is_empty() { Space::new() } else {
      let v698_6: Path = concat_path(&(*p0),&(v696_18_head));
      let mut v698_7 = Space::new();
      let mut v698_7_cursor = (v696_18_tail).read_zipper();
      for v698_7_byte in v698_7_cursor.child_mask().iter() {
        v698_7_cursor.descend_to_byte(v698_7_byte);
        let v698_7_tail = v698_7_cursor.make_map();
        v698_7_cursor.ascend(1);
        let v698_7_head = Path::from_slice(&[v698_7_byte]);
        let v699_2: Space = singleton(&(v698_7_head));
        let v699_3: Space = intersect(&(*CONSTANT_2),&(v699_2));
        let v699_4: Space = if has_head(&(v699_3)) { singleton(&[]) } else { Space::new() };
        drop(v699_3);
        let v699_5: Space = subtract(&(*CONSTANT_1),&(v699_4));
        drop(v699_4);
        let v699_8: Space = if (v699_5).is_empty() { Space::new() } else {
          let v700_6: Path = concat_path(&(v698_6),&(v698_7_head));
          let v700_7: Space = routine_114(c, &(v700_6), &(*p1), &(v698_7_tail), &(*s1));
          compose(&(v699_5),&(v700_7))
        };
        drop(v699_5);
        let v699_9: Space = intersect(&(*CONSTANT_2),&(v699_2));
        drop(v699_2);
        let v699_10: Space = if has_head(&(v699_9)) { singleton(&[]) } else { Space::new() };
        drop(v699_9);
        let v699_12: Space = if (v699_10).is_empty() { Space::new() } else {
          let v701_6: Path = concat_path(&(v698_6),&(v698_7_head));
          let v701_11: Space = routine_115(c, &(v701_6), &(*p1), &(v698_7_tail), &(*s1));
          drop(v701_6);
          compose(&(v699_10),&(v701_11))
        };
        drop(v699_10);
        let v699_13: Space = unite(&(v699_8),&(v699_12));
        v698_7.join_into((v699_13).clone());
      }
      drop(v698_7_cursor);
      drop(v698_6);
      compose(&(v697_5),&(v698_7))
    };
    drop(v697_5);
    let v697_9: Space = intersect(&(*CONSTANT_2),&(v697_2));
    drop(v697_2);
    let v697_10: Space = if has_head(&(v697_9)) { singleton(&[]) } else { Space::new() };
    drop(v697_9);
    let v697_13: Space = if (v697_10).is_empty() { Space::new() } else {
      let v702_11: Space = unwrap(&(v696_11),&(v696_18_head));
      let mut v702_12 = Space::new();
      let mut v702_12_cursor = (v702_11).read_zipper();
      for v702_12_byte in v702_12_cursor.child_mask().iter() {
        v702_12_cursor.descend_to_byte(v702_12_byte);
        let v702_12_tail = v702_12_cursor.make_map();
        v702_12_cursor.ascend(1);
        let v702_12_head = Path::from_slice(&[v702_12_byte]);
        let v703_2: Space = singleton(&(v702_12_head));
        let v703_3: Space = intersect(&(*CONSTANT_2),&(v703_2));
        let v703_4: Space = if has_head(&(v703_3)) { singleton(&[]) } else { Space::new() };
        drop(v703_3);
        let v703_5: Space = subtract(&(*CONSTANT_1),&(v703_4));
        drop(v703_4);
        let v703_7: Space = if (v703_5).is_empty() { Space::new() } else {
          let v704_6: Space = routine_72(c, &(v702_12_head), &(*p1), &(v702_12_tail));
          compose(&(v703_5),&(v704_6))
        };
        drop(v703_5);
        let v703_8: Space = intersect(&(*CONSTANT_2),&(v703_2));
        drop(v703_2);
        let v703_9: Space = if has_head(&(v703_8)) { singleton(&[]) } else { Space::new() };
        drop(v703_8);
        let v703_11: Space = if (v703_9).is_empty() { Space::new() } else {
          let v705_10: Space = routine_73(c, &(v702_12_head), &(*p1), &(v702_12_tail));
          compose(&(v703_9),&(v705_10))
        };
        drop(v703_9);
        let v703_12: Space = unite(&(v703_7),&(v703_11));
        v702_12.join_into((v703_12).clone());
      }
      drop(v702_12_cursor);
      drop(v702_11);
      compose(&(v697_10),&(v702_12))
    };
    drop(v697_10);
    let v697_14: Space = unite(&(v697_8),&(v697_13));
    v696_18.join_into((v697_14).clone());
  }
  drop(v696_18_cursor);
  drop(v696_11);
  (v696_18).clone()
}

fn routine_72(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v706_12 = Space::new();
  let mut v706_12_cursor = (*s0).read_zipper();
  for v706_12_byte in v706_12_cursor.child_mask().iter() {
    v706_12_cursor.descend_to_byte(v706_12_byte);
    let v706_12_tail = v706_12_cursor.make_map();
    v706_12_cursor.ascend(1);
    let v706_12_head = Path::from_slice(&[v706_12_byte]);
    let v707_2: Space = singleton(&(v706_12_head));
    let v707_3: Space = intersect(&(*CONSTANT_2),&(v707_2));
    let v707_4: Space = if has_head(&(v707_3)) { singleton(&[]) } else { Space::new() };
    drop(v707_3);
    let v707_5: Space = subtract(&(*CONSTANT_1),&(v707_4));
    drop(v707_4);
    let v707_8: Space = if (v707_5).is_empty() { Space::new() } else {
      let v708_6: Path = concat_path(&(*p0),&(v706_12_head));
      let mut v708_7 = Space::new();
      let mut v708_7_cursor = (v706_12_tail).read_zipper();
      for v708_7_byte in v708_7_cursor.child_mask().iter() {
        v708_7_cursor.descend_to_byte(v708_7_byte);
        let v708_7_tail = v708_7_cursor.make_map();
        v708_7_cursor.ascend(1);
        let v708_7_head = Path::from_slice(&[v708_7_byte]);
        let v709_2: Space = singleton(&(v708_7_head));
        let v709_3: Space = intersect(&(*CONSTANT_2),&(v709_2));
        let v709_4: Space = if has_head(&(v709_3)) { singleton(&[]) } else { Space::new() };
        drop(v709_3);
        let v709_5: Space = subtract(&(*CONSTANT_1),&(v709_4));
        drop(v709_4);
        let v709_8: Space = if (v709_5).is_empty() { Space::new() } else {
          let v710_6: Path = concat_path(&(v708_6),&(v708_7_head));
          let v710_7: Space = routine_116(c, &(v710_6), &(*p1), &(v708_7_tail));
          compose(&(v709_5),&(v710_7))
        };
        drop(v709_5);
        let v709_9: Space = intersect(&(*CONSTANT_2),&(v709_2));
        drop(v709_2);
        let v709_10: Space = if has_head(&(v709_9)) { singleton(&[]) } else { Space::new() };
        drop(v709_9);
        let v709_12: Space = if (v709_10).is_empty() { Space::new() } else {
          let v711_6: Path = concat_path(&(v708_6),&(v708_7_head));
          let v711_11: Space = routine_117(c, &(v711_6), &(*p1), &(v708_7_tail));
          drop(v711_6);
          compose(&(v709_10),&(v711_11))
        };
        drop(v709_10);
        let v709_13: Space = unite(&(v709_8),&(v709_12));
        v708_7.join_into((v709_13).clone());
      }
      drop(v708_7_cursor);
      compose(&(v707_5),&(v708_7))
    };
    drop(v707_5);
    let v707_9: Space = intersect(&(*CONSTANT_2),&(v707_2));
    drop(v707_2);
    let v707_10: Space = if has_head(&(v707_9)) { singleton(&[]) } else { Space::new() };
    drop(v707_9);
    let v707_12: Space = if (v707_10).is_empty() { Space::new() } else {
      let v712_6: Path = concat_path(&(*p0),&(v706_12_head));
      let mut v712_11 = Space::new();
      let mut v712_11_cursor = (v706_12_tail).read_zipper();
      for v712_11_byte in v712_11_cursor.child_mask().iter() {
        v712_11_cursor.descend_to_byte(v712_11_byte);
        let v712_11_tail = v712_11_cursor.make_map();
        v712_11_cursor.ascend(1);
        let v712_11_head = Path::from_slice(&[v712_11_byte]);
        let v713_2: Space = singleton(&(v712_11_head));
        let v713_3: Space = intersect(&(*CONSTANT_2),&(v713_2));
        let v713_4: Space = if has_head(&(v713_3)) { singleton(&[]) } else { Space::new() };
        drop(v713_3);
        let v713_5: Space = subtract(&(*CONSTANT_1),&(v713_4));
        drop(v713_4);
        let v713_8: Space = if (v713_5).is_empty() { Space::new() } else {
          let v714_6: Path = concat_path(&(v712_6),&(v712_11_head));
          let v714_7: Space = routine_116(c, &(v714_6), &(*p1), &(v712_11_tail));
          compose(&(v713_5),&(v714_7))
        };
        drop(v713_5);
        let v713_9: Space = intersect(&(*CONSTANT_2),&(v713_2));
        drop(v713_2);
        let v713_10: Space = if has_head(&(v713_9)) { singleton(&[]) } else { Space::new() };
        drop(v713_9);
        let v713_12: Space = if (v713_10).is_empty() { Space::new() } else {
          let v715_6: Path = concat_path(&(v712_6),&(v712_11_head));
          let v715_11: Space = routine_78(c, &(v715_6), &(*p1), &(v712_11_tail));
          drop(v715_6);
          compose(&(v713_10),&(v715_11))
        };
        drop(v713_10);
        let v713_13: Space = unite(&(v713_8),&(v713_12));
        v712_11.join_into((v713_13).clone());
      }
      drop(v712_11_cursor);
      drop(v712_6);
      compose(&(v707_10),&(v712_11))
    };
    drop(v707_10);
    let v707_13: Space = unite(&(v707_8),&(v707_12));
    v706_12.join_into((v707_13).clone());
  }
  drop(v706_12_cursor);
  (v706_12).clone()
}

fn routine_73(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v716_9 = Space::new();
  let mut v716_9_cursor = (*s0).read_zipper();
  for v716_9_byte in v716_9_cursor.child_mask().iter() {
    v716_9_cursor.descend_to_byte(v716_9_byte);
    let v716_9_tail = v716_9_cursor.make_map();
    v716_9_cursor.ascend(1);
    let v716_9_head = Path::from_slice(&[v716_9_byte]);
    let v717_2: Space = singleton(&(v716_9_head));
    let v717_3: Space = intersect(&(*CONSTANT_2),&(v717_2));
    let v717_4: Space = if has_head(&(v717_3)) { singleton(&[]) } else { Space::new() };
    drop(v717_3);
    let v717_5: Space = subtract(&(*CONSTANT_1),&(v717_4));
    drop(v717_4);
    let v717_8: Space = if (v717_5).is_empty() { Space::new() } else {
      let v718_6: Path = concat_path(&(*p0),&(v716_9_head));
      let mut v718_7 = Space::new();
      let mut v718_7_cursor = (v716_9_tail).read_zipper();
      for v718_7_byte in v718_7_cursor.child_mask().iter() {
        v718_7_cursor.descend_to_byte(v718_7_byte);
        let v718_7_tail = v718_7_cursor.make_map();
        v718_7_cursor.ascend(1);
        let v718_7_head = Path::from_slice(&[v718_7_byte]);
        let v719_2: Space = singleton(&(v718_7_head));
        let v719_3: Space = intersect(&(*CONSTANT_2),&(v719_2));
        let v719_4: Space = if has_head(&(v719_3)) { singleton(&[]) } else { Space::new() };
        drop(v719_3);
        let v719_5: Space = subtract(&(*CONSTANT_1),&(v719_4));
        drop(v719_4);
        let v719_8: Space = if (v719_5).is_empty() { Space::new() } else {
          let v720_6: Path = concat_path(&(v718_6),&(v718_7_head));
          let v720_7: Space = routine_116(c, &(v720_6), &(*p1), &(v718_7_tail));
          compose(&(v719_5),&(v720_7))
        };
        drop(v719_5);
        let v719_9: Space = intersect(&(*CONSTANT_2),&(v719_2));
        drop(v719_2);
        let v719_10: Space = if has_head(&(v719_9)) { singleton(&[]) } else { Space::new() };
        drop(v719_9);
        let v719_12: Space = if (v719_10).is_empty() { Space::new() } else {
          let v721_6: Path = concat_path(&(v718_6),&(v718_7_head));
          let v721_11: Space = routine_117(c, &(v721_6), &(*p1), &(v718_7_tail));
          drop(v721_6);
          compose(&(v719_10),&(v721_11))
        };
        drop(v719_10);
        let v719_13: Space = unite(&(v719_8),&(v719_12));
        v718_7.join_into((v719_13).clone());
      }
      drop(v718_7_cursor);
      compose(&(v717_5),&(v718_7))
    };
    drop(v717_5);
    let v717_9: Space = intersect(&(*CONSTANT_2),&(v717_2));
    drop(v717_2);
    let v717_10: Space = if has_head(&(v717_9)) { singleton(&[]) } else { Space::new() };
    drop(v717_9);
    let v717_11: Space = compose(&(v717_10),&(v716_9_tail));
    drop(v717_10);
    let v722_6: Path = concat_path(&(*p0),&(v716_9_head));
    let v717_12: Space = wrap(&(v717_11),&(v722_6));
    drop(v717_11);
    let v717_13: Space = wrap(&(v717_12),&(*p1));
    drop(v717_12);
    let v717_14: Space = unite(&(v717_8),&(v717_13));
    drop(v717_13);
    v716_9.join_into((v717_14).clone());
  }
  drop(v716_9_cursor);
  (v716_9).clone()
}

fn routine_74(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v723_13 = Space::new();
  let mut v723_13_cursor = (*s0).read_zipper();
  for v723_13_byte in v723_13_cursor.child_mask().iter() {
    v723_13_cursor.descend_to_byte(v723_13_byte);
    let v723_13_tail = v723_13_cursor.make_map();
    v723_13_cursor.ascend(1);
    let v723_13_head = Path::from_slice(&[v723_13_byte]);
    let v724_2: Space = singleton(&(v723_13_head));
    let v724_3: Space = intersect(&(*CONSTANT_2),&(v724_2));
    let v724_4: Space = if has_head(&(v724_3)) { singleton(&[]) } else { Space::new() };
    drop(v724_3);
    let v724_5: Space = subtract(&(*CONSTANT_1),&(v724_4));
    drop(v724_4);
    let v724_8: Space = if (v724_5).is_empty() { Space::new() } else {
      let v725_6: Path = concat_path(&(*p0),&(v723_13_head));
      let mut v725_7 = Space::new();
      let mut v725_7_cursor = (v723_13_tail).read_zipper();
      for v725_7_byte in v725_7_cursor.child_mask().iter() {
        v725_7_cursor.descend_to_byte(v725_7_byte);
        let v725_7_tail = v725_7_cursor.make_map();
        v725_7_cursor.ascend(1);
        let v725_7_head = Path::from_slice(&[v725_7_byte]);
        let v726_2: Space = singleton(&(v725_7_head));
        let v726_3: Space = intersect(&(*CONSTANT_2),&(v726_2));
        let v726_4: Space = if has_head(&(v726_3)) { singleton(&[]) } else { Space::new() };
        drop(v726_3);
        let v726_5: Space = subtract(&(*CONSTANT_1),&(v726_4));
        drop(v726_4);
        let v726_8: Space = if (v726_5).is_empty() { Space::new() } else {
          let v727_6: Path = concat_path(&(v725_6),&(v725_7_head));
          let v727_7: Space = routine_118(c, &(v727_6), &(*p1), &(v725_7_tail), &(*s1));
          compose(&(v726_5),&(v727_7))
        };
        drop(v726_5);
        let v726_9: Space = intersect(&(*CONSTANT_2),&(v726_2));
        drop(v726_2);
        let v726_10: Space = if has_head(&(v726_9)) { singleton(&[]) } else { Space::new() };
        drop(v726_9);
        let v726_12: Space = if (v726_10).is_empty() { Space::new() } else {
          let v728_6: Path = concat_path(&(v725_6),&(v725_7_head));
          let v728_11: Space = routine_119(c, &(v728_6), &(*p1), &(v725_7_tail), &(*s1));
          drop(v728_6);
          compose(&(v726_10),&(v728_11))
        };
        drop(v726_10);
        let v726_13: Space = unite(&(v726_8),&(v726_12));
        v725_7.join_into((v726_13).clone());
      }
      drop(v725_7_cursor);
      compose(&(v724_5),&(v725_7))
    };
    drop(v724_5);
    let v724_9: Space = intersect(&(*CONSTANT_2),&(v724_2));
    drop(v724_2);
    let v724_10: Space = if has_head(&(v724_9)) { singleton(&[]) } else { Space::new() };
    drop(v724_9);
    let v724_12: Space = if (v724_10).is_empty() { Space::new() } else {
      let v729_6: Path = concat_path(&(*p0),&(v723_13_head));
      let mut v729_11 = Space::new();
      let mut v729_11_cursor = (v723_13_tail).read_zipper();
      for v729_11_byte in v729_11_cursor.child_mask().iter() {
        v729_11_cursor.descend_to_byte(v729_11_byte);
        let v729_11_tail = v729_11_cursor.make_map();
        v729_11_cursor.ascend(1);
        let v729_11_head = Path::from_slice(&[v729_11_byte]);
        let v730_2: Space = singleton(&(v729_11_head));
        let v730_3: Space = intersect(&(*CONSTANT_2),&(v730_2));
        let v730_4: Space = if has_head(&(v730_3)) { singleton(&[]) } else { Space::new() };
        drop(v730_3);
        let v730_5: Space = subtract(&(*CONSTANT_1),&(v730_4));
        drop(v730_4);
        let v730_8: Space = if (v730_5).is_empty() { Space::new() } else {
          let v731_6: Path = concat_path(&(v729_6),&(v729_11_head));
          let v731_7: Space = routine_118(c, &(v731_6), &(*p1), &(v729_11_tail), &(*s1));
          compose(&(v730_5),&(v731_7))
        };
        drop(v730_5);
        let v730_9: Space = intersect(&(*CONSTANT_2),&(v730_2));
        drop(v730_2);
        let v730_10: Space = if has_head(&(v730_9)) { singleton(&[]) } else { Space::new() };
        drop(v730_9);
        let v730_12: Space = if (v730_10).is_empty() { Space::new() } else {
          let v732_6: Path = concat_path(&(v729_6),&(v729_11_head));
          let v732_11: Space = routine_36(c, &(v732_6), &(*p1), &(v729_11_tail), &(*s1));
          drop(v732_6);
          compose(&(v730_10),&(v732_11))
        };
        drop(v730_10);
        let v730_13: Space = unite(&(v730_8),&(v730_12));
        v729_11.join_into((v730_13).clone());
      }
      drop(v729_11_cursor);
      drop(v729_6);
      compose(&(v724_10),&(v729_11))
    };
    drop(v724_10);
    let v724_13: Space = unite(&(v724_8),&(v724_12));
    v723_13.join_into((v724_13).clone());
  }
  drop(v723_13_cursor);
  (v723_13).clone()
}

fn routine_75(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v733_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v733_10: Space = unwrap(&(v733_8),&(*CONSTANT_5));
  drop(v733_8);
  let v733_11: Space = unwrap(&(v733_10),&(*p0));
  drop(v733_10);
  let mut v733_18 = Space::new();
  let mut v733_18_cursor = (*s0).read_zipper();
  for v733_18_byte in v733_18_cursor.child_mask().iter() {
    v733_18_cursor.descend_to_byte(v733_18_byte);
    let v733_18_tail = v733_18_cursor.make_map();
    v733_18_cursor.ascend(1);
    let v733_18_head = Path::from_slice(&[v733_18_byte]);
    let v734_2: Space = singleton(&(v733_18_head));
    let v734_3: Space = intersect(&(*CONSTANT_2),&(v734_2));
    let v734_4: Space = if has_head(&(v734_3)) { singleton(&[]) } else { Space::new() };
    drop(v734_3);
    let v734_5: Space = subtract(&(*CONSTANT_1),&(v734_4));
    drop(v734_4);
    let v734_8: Space = if (v734_5).is_empty() { Space::new() } else {
      let v735_6: Path = concat_path(&(*p0),&(v733_18_head));
      let mut v735_7 = Space::new();
      let mut v735_7_cursor = (v733_18_tail).read_zipper();
      for v735_7_byte in v735_7_cursor.child_mask().iter() {
        v735_7_cursor.descend_to_byte(v735_7_byte);
        let v735_7_tail = v735_7_cursor.make_map();
        v735_7_cursor.ascend(1);
        let v735_7_head = Path::from_slice(&[v735_7_byte]);
        let v736_2: Space = singleton(&(v735_7_head));
        let v736_3: Space = intersect(&(*CONSTANT_2),&(v736_2));
        let v736_4: Space = if has_head(&(v736_3)) { singleton(&[]) } else { Space::new() };
        drop(v736_3);
        let v736_5: Space = subtract(&(*CONSTANT_1),&(v736_4));
        drop(v736_4);
        let v736_8: Space = if (v736_5).is_empty() { Space::new() } else {
          let v737_6: Path = concat_path(&(v735_6),&(v735_7_head));
          let v737_7: Space = routine_118(c, &(v737_6), &(*p1), &(v735_7_tail), &(*s1));
          compose(&(v736_5),&(v737_7))
        };
        drop(v736_5);
        let v736_9: Space = intersect(&(*CONSTANT_2),&(v736_2));
        drop(v736_2);
        let v736_10: Space = if has_head(&(v736_9)) { singleton(&[]) } else { Space::new() };
        drop(v736_9);
        let v736_12: Space = if (v736_10).is_empty() { Space::new() } else {
          let v738_6: Path = concat_path(&(v735_6),&(v735_7_head));
          let v738_11: Space = routine_119(c, &(v738_6), &(*p1), &(v735_7_tail), &(*s1));
          drop(v738_6);
          compose(&(v736_10),&(v738_11))
        };
        drop(v736_10);
        let v736_13: Space = unite(&(v736_8),&(v736_12));
        v735_7.join_into((v736_13).clone());
      }
      drop(v735_7_cursor);
      drop(v735_6);
      compose(&(v734_5),&(v735_7))
    };
    drop(v734_5);
    let v734_9: Space = intersect(&(*CONSTANT_2),&(v734_2));
    drop(v734_2);
    let v734_10: Space = if has_head(&(v734_9)) { singleton(&[]) } else { Space::new() };
    drop(v734_9);
    let v734_13: Space = if (v734_10).is_empty() { Space::new() } else {
      let v739_11: Space = unwrap(&(v733_11),&(v733_18_head));
      let mut v739_12 = Space::new();
      let mut v739_12_cursor = (v739_11).read_zipper();
      for v739_12_byte in v739_12_cursor.child_mask().iter() {
        v739_12_cursor.descend_to_byte(v739_12_byte);
        let v739_12_tail = v739_12_cursor.make_map();
        v739_12_cursor.ascend(1);
        let v739_12_head = Path::from_slice(&[v739_12_byte]);
        let v740_2: Space = singleton(&(v739_12_head));
        let v740_3: Space = intersect(&(*CONSTANT_2),&(v740_2));
        let v740_4: Space = if has_head(&(v740_3)) { singleton(&[]) } else { Space::new() };
        drop(v740_3);
        let v740_5: Space = subtract(&(*CONSTANT_1),&(v740_4));
        drop(v740_4);
        let v740_7: Space = if (v740_5).is_empty() { Space::new() } else {
          let v741_6: Space = routine_72(c, &(v739_12_head), &(*p1), &(v739_12_tail));
          compose(&(v740_5),&(v741_6))
        };
        drop(v740_5);
        let v740_8: Space = intersect(&(*CONSTANT_2),&(v740_2));
        drop(v740_2);
        let v740_9: Space = if has_head(&(v740_8)) { singleton(&[]) } else { Space::new() };
        drop(v740_8);
        let v740_11: Space = if (v740_9).is_empty() { Space::new() } else {
          let v742_10: Space = routine_73(c, &(v739_12_head), &(*p1), &(v739_12_tail));
          compose(&(v740_9),&(v742_10))
        };
        drop(v740_9);
        let v740_12: Space = unite(&(v740_7),&(v740_11));
        v739_12.join_into((v740_12).clone());
      }
      drop(v739_12_cursor);
      drop(v739_11);
      compose(&(v734_10),&(v739_12))
    };
    drop(v734_10);
    let v734_14: Space = unite(&(v734_8),&(v734_13));
    v733_18.join_into((v734_14).clone());
  }
  drop(v733_18_cursor);
  drop(v733_11);
  (v733_18).clone()
}

fn routine_76(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v743_12 = Space::new();
  let mut v743_12_cursor = (*s0).read_zipper();
  for v743_12_byte in v743_12_cursor.child_mask().iter() {
    v743_12_cursor.descend_to_byte(v743_12_byte);
    let v743_12_tail = v743_12_cursor.make_map();
    v743_12_cursor.ascend(1);
    let v743_12_head = Path::from_slice(&[v743_12_byte]);
    let v744_2: Space = singleton(&(v743_12_head));
    let v744_3: Space = intersect(&(*CONSTANT_2),&(v744_2));
    let v744_4: Space = if has_head(&(v744_3)) { singleton(&[]) } else { Space::new() };
    drop(v744_3);
    let v744_5: Space = subtract(&(*CONSTANT_1),&(v744_4));
    drop(v744_4);
    let v744_8: Space = if (v744_5).is_empty() { Space::new() } else {
      let v745_6: Path = concat_path(&(*p0),&(v743_12_head));
      let mut v745_7 = Space::new();
      let mut v745_7_cursor = (v743_12_tail).read_zipper();
      for v745_7_byte in v745_7_cursor.child_mask().iter() {
        v745_7_cursor.descend_to_byte(v745_7_byte);
        let v745_7_tail = v745_7_cursor.make_map();
        v745_7_cursor.ascend(1);
        let v745_7_head = Path::from_slice(&[v745_7_byte]);
        let v746_2: Space = singleton(&(v745_7_head));
        let v746_3: Space = intersect(&(*CONSTANT_2),&(v746_2));
        let v746_4: Space = if has_head(&(v746_3)) { singleton(&[]) } else { Space::new() };
        drop(v746_3);
        let v746_5: Space = subtract(&(*CONSTANT_1),&(v746_4));
        drop(v746_4);
        let v746_8: Space = if (v746_5).is_empty() { Space::new() } else {
          let v747_6: Path = concat_path(&(v745_6),&(v745_7_head));
          let v747_7: Space = routine_120(c, &(v747_6), &(*p1), &(v745_7_tail));
          compose(&(v746_5),&(v747_7))
        };
        drop(v746_5);
        let v746_9: Space = intersect(&(*CONSTANT_2),&(v746_2));
        drop(v746_2);
        let v746_10: Space = if has_head(&(v746_9)) { singleton(&[]) } else { Space::new() };
        drop(v746_9);
        let v746_12: Space = if (v746_10).is_empty() { Space::new() } else {
          let v748_6: Path = concat_path(&(v745_6),&(v745_7_head));
          let v748_11: Space = routine_121(c, &(v748_6), &(*p1), &(v745_7_tail));
          drop(v748_6);
          compose(&(v746_10),&(v748_11))
        };
        drop(v746_10);
        let v746_13: Space = unite(&(v746_8),&(v746_12));
        v745_7.join_into((v746_13).clone());
      }
      drop(v745_7_cursor);
      compose(&(v744_5),&(v745_7))
    };
    drop(v744_5);
    let v744_9: Space = intersect(&(*CONSTANT_2),&(v744_2));
    drop(v744_2);
    let v744_10: Space = if has_head(&(v744_9)) { singleton(&[]) } else { Space::new() };
    drop(v744_9);
    let v744_12: Space = if (v744_10).is_empty() { Space::new() } else {
      let v749_6: Path = concat_path(&(*p0),&(v743_12_head));
      let mut v749_11 = Space::new();
      let mut v749_11_cursor = (v743_12_tail).read_zipper();
      for v749_11_byte in v749_11_cursor.child_mask().iter() {
        v749_11_cursor.descend_to_byte(v749_11_byte);
        let v749_11_tail = v749_11_cursor.make_map();
        v749_11_cursor.ascend(1);
        let v749_11_head = Path::from_slice(&[v749_11_byte]);
        let v750_2: Space = singleton(&(v749_11_head));
        let v750_3: Space = intersect(&(*CONSTANT_2),&(v750_2));
        let v750_4: Space = if has_head(&(v750_3)) { singleton(&[]) } else { Space::new() };
        drop(v750_3);
        let v750_5: Space = subtract(&(*CONSTANT_1),&(v750_4));
        drop(v750_4);
        let v750_8: Space = if (v750_5).is_empty() { Space::new() } else {
          let v751_6: Path = concat_path(&(v749_6),&(v749_11_head));
          let v751_7: Space = routine_120(c, &(v751_6), &(*p1), &(v749_11_tail));
          compose(&(v750_5),&(v751_7))
        };
        drop(v750_5);
        let v750_9: Space = intersect(&(*CONSTANT_2),&(v750_2));
        drop(v750_2);
        let v750_10: Space = if has_head(&(v750_9)) { singleton(&[]) } else { Space::new() };
        drop(v750_9);
        let v750_12: Space = if (v750_10).is_empty() { Space::new() } else {
          let v752_6: Path = concat_path(&(v749_6),&(v749_11_head));
          let v752_11: Space = routine_78(c, &(v752_6), &(*p1), &(v749_11_tail));
          drop(v752_6);
          compose(&(v750_10),&(v752_11))
        };
        drop(v750_10);
        let v750_13: Space = unite(&(v750_8),&(v750_12));
        v749_11.join_into((v750_13).clone());
      }
      drop(v749_11_cursor);
      drop(v749_6);
      compose(&(v744_10),&(v749_11))
    };
    drop(v744_10);
    let v744_13: Space = unite(&(v744_8),&(v744_12));
    v743_12.join_into((v744_13).clone());
  }
  drop(v743_12_cursor);
  (v743_12).clone()
}

fn routine_77(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v753_9 = Space::new();
  let mut v753_9_cursor = (*s0).read_zipper();
  for v753_9_byte in v753_9_cursor.child_mask().iter() {
    v753_9_cursor.descend_to_byte(v753_9_byte);
    let v753_9_tail = v753_9_cursor.make_map();
    v753_9_cursor.ascend(1);
    let v753_9_head = Path::from_slice(&[v753_9_byte]);
    let v754_2: Space = singleton(&(v753_9_head));
    let v754_3: Space = intersect(&(*CONSTANT_2),&(v754_2));
    let v754_4: Space = if has_head(&(v754_3)) { singleton(&[]) } else { Space::new() };
    drop(v754_3);
    let v754_5: Space = subtract(&(*CONSTANT_1),&(v754_4));
    drop(v754_4);
    let v754_8: Space = if (v754_5).is_empty() { Space::new() } else {
      let v755_6: Path = concat_path(&(*p0),&(v753_9_head));
      let mut v755_7 = Space::new();
      let mut v755_7_cursor = (v753_9_tail).read_zipper();
      for v755_7_byte in v755_7_cursor.child_mask().iter() {
        v755_7_cursor.descend_to_byte(v755_7_byte);
        let v755_7_tail = v755_7_cursor.make_map();
        v755_7_cursor.ascend(1);
        let v755_7_head = Path::from_slice(&[v755_7_byte]);
        let v756_2: Space = singleton(&(v755_7_head));
        let v756_3: Space = intersect(&(*CONSTANT_2),&(v756_2));
        let v756_4: Space = if has_head(&(v756_3)) { singleton(&[]) } else { Space::new() };
        drop(v756_3);
        let v756_5: Space = subtract(&(*CONSTANT_1),&(v756_4));
        drop(v756_4);
        let v756_8: Space = if (v756_5).is_empty() { Space::new() } else {
          let v757_6: Path = concat_path(&(v755_6),&(v755_7_head));
          let v757_7: Space = routine_120(c, &(v757_6), &(*p1), &(v755_7_tail));
          compose(&(v756_5),&(v757_7))
        };
        drop(v756_5);
        let v756_9: Space = intersect(&(*CONSTANT_2),&(v756_2));
        drop(v756_2);
        let v756_10: Space = if has_head(&(v756_9)) { singleton(&[]) } else { Space::new() };
        drop(v756_9);
        let v756_12: Space = if (v756_10).is_empty() { Space::new() } else {
          let v758_6: Path = concat_path(&(v755_6),&(v755_7_head));
          let v758_11: Space = routine_121(c, &(v758_6), &(*p1), &(v755_7_tail));
          drop(v758_6);
          compose(&(v756_10),&(v758_11))
        };
        drop(v756_10);
        let v756_13: Space = unite(&(v756_8),&(v756_12));
        v755_7.join_into((v756_13).clone());
      }
      drop(v755_7_cursor);
      compose(&(v754_5),&(v755_7))
    };
    drop(v754_5);
    let v754_9: Space = intersect(&(*CONSTANT_2),&(v754_2));
    drop(v754_2);
    let v754_10: Space = if has_head(&(v754_9)) { singleton(&[]) } else { Space::new() };
    drop(v754_9);
    let v754_11: Space = compose(&(v754_10),&(v753_9_tail));
    drop(v754_10);
    let v759_6: Path = concat_path(&(*p0),&(v753_9_head));
    let v754_12: Space = wrap(&(v754_11),&(v759_6));
    drop(v754_11);
    let v754_13: Space = wrap(&(v754_12),&(*p1));
    drop(v754_12);
    let v754_14: Space = unite(&(v754_8),&(v754_13));
    drop(v754_13);
    v753_9.join_into((v754_14).clone());
  }
  drop(v753_9_cursor);
  (v753_9).clone()
}

fn routine_78(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v760_3: Space = wrap(&(*s0),&(*p0));
  let v760_4: Space = wrap(&(v760_3),&(*p1));
  drop(v760_3);
  (v760_4).clone()
}

fn routine_79(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v761_12 = Space::new();
  let mut v761_12_cursor = (*s0).read_zipper();
  for v761_12_byte in v761_12_cursor.child_mask().iter() {
    v761_12_cursor.descend_to_byte(v761_12_byte);
    let v761_12_tail = v761_12_cursor.make_map();
    v761_12_cursor.ascend(1);
    let v761_12_head = Path::from_slice(&[v761_12_byte]);
    let v762_2: Space = singleton(&(v761_12_head));
    let v762_3: Space = intersect(&(*CONSTANT_2),&(v762_2));
    let v762_4: Space = if has_head(&(v762_3)) { singleton(&[]) } else { Space::new() };
    drop(v762_3);
    let v762_5: Space = subtract(&(*CONSTANT_1),&(v762_4));
    drop(v762_4);
    let v762_8: Space = if (v762_5).is_empty() { Space::new() } else {
      let v763_6: Path = concat_path(&(*p0),&(v761_12_head));
      let mut v763_7 = Space::new();
      let mut v763_7_cursor = (v761_12_tail).read_zipper();
      for v763_7_byte in v763_7_cursor.child_mask().iter() {
        v763_7_cursor.descend_to_byte(v763_7_byte);
        let v763_7_tail = v763_7_cursor.make_map();
        v763_7_cursor.ascend(1);
        let v763_7_head = Path::from_slice(&[v763_7_byte]);
        let v764_2: Space = singleton(&(v763_7_head));
        let v764_3: Space = intersect(&(*CONSTANT_2),&(v764_2));
        let v764_4: Space = if has_head(&(v764_3)) { singleton(&[]) } else { Space::new() };
        drop(v764_3);
        let v764_5: Space = subtract(&(*CONSTANT_1),&(v764_4));
        drop(v764_4);
        let v764_8: Space = if (v764_5).is_empty() { Space::new() } else {
          let v765_6: Path = concat_path(&(v763_6),&(v763_7_head));
          let v765_7: Space = routine_122(c, &(v765_6), &(v763_7_tail), &(*s1));
          compose(&(v764_5),&(v765_7))
        };
        drop(v764_5);
        let v764_9: Space = intersect(&(*CONSTANT_2),&(v764_2));
        drop(v764_2);
        let v764_10: Space = if has_head(&(v764_9)) { singleton(&[]) } else { Space::new() };
        drop(v764_9);
        let v764_12: Space = if (v764_10).is_empty() { Space::new() } else {
          let v766_6: Path = concat_path(&(v763_6),&(v763_7_head));
          let v766_11: Space = routine_123(c, &(v766_6), &(v763_7_tail), &(*s1));
          drop(v766_6);
          compose(&(v764_10),&(v766_11))
        };
        drop(v764_10);
        let v764_13: Space = unite(&(v764_8),&(v764_12));
        v763_7.join_into((v764_13).clone());
      }
      drop(v763_7_cursor);
      compose(&(v762_5),&(v763_7))
    };
    drop(v762_5);
    let v762_9: Space = intersect(&(*CONSTANT_2),&(v762_2));
    drop(v762_2);
    let v762_10: Space = if has_head(&(v762_9)) { singleton(&[]) } else { Space::new() };
    drop(v762_9);
    let v762_12: Space = if (v762_10).is_empty() { Space::new() } else {
      let v767_6: Path = concat_path(&(*p0),&(v761_12_head));
      let mut v767_11 = Space::new();
      let mut v767_11_cursor = (v761_12_tail).read_zipper();
      for v767_11_byte in v767_11_cursor.child_mask().iter() {
        v767_11_cursor.descend_to_byte(v767_11_byte);
        let v767_11_tail = v767_11_cursor.make_map();
        v767_11_cursor.ascend(1);
        let v767_11_head = Path::from_slice(&[v767_11_byte]);
        let v768_2: Space = singleton(&(v767_11_head));
        let v768_3: Space = intersect(&(*CONSTANT_2),&(v768_2));
        let v768_4: Space = if has_head(&(v768_3)) { singleton(&[]) } else { Space::new() };
        drop(v768_3);
        let v768_5: Space = subtract(&(*CONSTANT_1),&(v768_4));
        drop(v768_4);
        let v768_8: Space = if (v768_5).is_empty() { Space::new() } else {
          let v769_6: Path = concat_path(&(v767_6),&(v767_11_head));
          let v769_7: Space = routine_122(c, &(v769_6), &(v767_11_tail), &(*s1));
          compose(&(v768_5),&(v769_7))
        };
        drop(v768_5);
        let v768_9: Space = intersect(&(*CONSTANT_2),&(v768_2));
        drop(v768_2);
        let v768_10: Space = if has_head(&(v768_9)) { singleton(&[]) } else { Space::new() };
        drop(v768_9);
        let v768_12: Space = if (v768_10).is_empty() { Space::new() } else {
          let v770_6: Path = concat_path(&(v767_6),&(v767_11_head));
          let v770_11: Space = routine_12(c, &(v770_6), &(v767_11_tail), &(*s1));
          drop(v770_6);
          compose(&(v768_10),&(v770_11))
        };
        drop(v768_10);
        let v768_13: Space = unite(&(v768_8),&(v768_12));
        v767_11.join_into((v768_13).clone());
      }
      drop(v767_11_cursor);
      drop(v767_6);
      compose(&(v762_10),&(v767_11))
    };
    drop(v762_10);
    let v762_13: Space = unite(&(v762_8),&(v762_12));
    v761_12.join_into((v762_13).clone());
  }
  drop(v761_12_cursor);
  (v761_12).clone()
}

fn routine_80(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v771_12 = Space::new();
  let mut v771_12_cursor = (*s0).read_zipper();
  for v771_12_byte in v771_12_cursor.child_mask().iter() {
    v771_12_cursor.descend_to_byte(v771_12_byte);
    let v771_12_tail = v771_12_cursor.make_map();
    v771_12_cursor.ascend(1);
    let v771_12_head = Path::from_slice(&[v771_12_byte]);
    let v772_2: Space = singleton(&(v771_12_head));
    let v772_3: Space = intersect(&(*CONSTANT_2),&(v772_2));
    let v772_4: Space = if has_head(&(v772_3)) { singleton(&[]) } else { Space::new() };
    drop(v772_3);
    let v772_5: Space = subtract(&(*CONSTANT_1),&(v772_4));
    drop(v772_4);
    let v772_8: Space = if (v772_5).is_empty() { Space::new() } else {
      let v773_6: Path = concat_path(&(*p0),&(v771_12_head));
      let mut v773_7 = Space::new();
      let mut v773_7_cursor = (v771_12_tail).read_zipper();
      for v773_7_byte in v773_7_cursor.child_mask().iter() {
        v773_7_cursor.descend_to_byte(v773_7_byte);
        let v773_7_tail = v773_7_cursor.make_map();
        v773_7_cursor.ascend(1);
        let v773_7_head = Path::from_slice(&[v773_7_byte]);
        let v774_2: Space = singleton(&(v773_7_head));
        let v774_3: Space = intersect(&(*CONSTANT_2),&(v774_2));
        let v774_4: Space = if has_head(&(v774_3)) { singleton(&[]) } else { Space::new() };
        drop(v774_3);
        let v774_5: Space = subtract(&(*CONSTANT_1),&(v774_4));
        drop(v774_4);
        let v774_8: Space = if (v774_5).is_empty() { Space::new() } else {
          let v775_6: Path = concat_path(&(v773_6),&(v773_7_head));
          let v775_7: Space = routine_122(c, &(v775_6), &(v773_7_tail), &(*s1));
          compose(&(v774_5),&(v775_7))
        };
        drop(v774_5);
        let v774_9: Space = intersect(&(*CONSTANT_2),&(v774_2));
        drop(v774_2);
        let v774_10: Space = if has_head(&(v774_9)) { singleton(&[]) } else { Space::new() };
        drop(v774_9);
        let v774_12: Space = if (v774_10).is_empty() { Space::new() } else {
          let v776_6: Path = concat_path(&(v773_6),&(v773_7_head));
          let v776_11: Space = routine_123(c, &(v776_6), &(v773_7_tail), &(*s1));
          drop(v776_6);
          compose(&(v774_10),&(v776_11))
        };
        drop(v774_10);
        let v774_13: Space = unite(&(v774_8),&(v774_12));
        v773_7.join_into((v774_13).clone());
      }
      drop(v773_7_cursor);
      compose(&(v772_5),&(v773_7))
    };
    drop(v772_5);
    let v772_9: Space = intersect(&(*CONSTANT_2),&(v772_2));
    drop(v772_2);
    let v772_10: Space = if has_head(&(v772_9)) { singleton(&[]) } else { Space::new() };
    drop(v772_9);
    let v772_12: Space = if (v772_10).is_empty() { Space::new() } else {
      let v777_6: Path = concat_path(&(*p0),&(v771_12_head));
      let mut v777_11 = Space::new();
      let mut v777_11_cursor = (v771_12_tail).read_zipper();
      for v777_11_byte in v777_11_cursor.child_mask().iter() {
        v777_11_cursor.descend_to_byte(v777_11_byte);
        let v777_11_tail = v777_11_cursor.make_map();
        v777_11_cursor.ascend(1);
        let v777_11_head = Path::from_slice(&[v777_11_byte]);
        let v778_2: Space = singleton(&(v777_11_head));
        let v778_3: Space = intersect(&(*CONSTANT_2),&(v778_2));
        let v778_4: Space = if has_head(&(v778_3)) { singleton(&[]) } else { Space::new() };
        drop(v778_3);
        let v778_5: Space = subtract(&(*CONSTANT_1),&(v778_4));
        drop(v778_4);
        let v778_7: Space = if (v778_5).is_empty() { Space::new() } else {
          let v779_6: Space = routine_39(c, &(v777_11_head), &(v777_6), &(v777_11_tail), &(*s1));
          compose(&(v778_5),&(v779_6))
        };
        drop(v778_5);
        let v778_8: Space = intersect(&(*CONSTANT_2),&(v778_2));
        drop(v778_2);
        let v778_9: Space = if has_head(&(v778_8)) { singleton(&[]) } else { Space::new() };
        drop(v778_8);
        let v778_11: Space = if (v778_9).is_empty() { Space::new() } else {
          let v780_10: Space = routine_40(c, &(v777_11_head), &(v777_6), &(v777_11_tail), &(*s1));
          compose(&(v778_9),&(v780_10))
        };
        drop(v778_9);
        let v778_12: Space = unite(&(v778_7),&(v778_11));
        v777_11.join_into((v778_12).clone());
      }
      drop(v777_11_cursor);
      drop(v777_6);
      compose(&(v772_10),&(v777_11))
    };
    drop(v772_10);
    let v772_13: Space = unite(&(v772_8),&(v772_12));
    v771_12.join_into((v772_13).clone());
  }
  drop(v771_12_cursor);
  (v771_12).clone()
}

fn routine_81(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v781_13 = Space::new();
  let mut v781_13_cursor = (*s0).read_zipper();
  for v781_13_byte in v781_13_cursor.child_mask().iter() {
    v781_13_cursor.descend_to_byte(v781_13_byte);
    let v781_13_tail = v781_13_cursor.make_map();
    v781_13_cursor.ascend(1);
    let v781_13_head = Path::from_slice(&[v781_13_byte]);
    let v782_2: Space = singleton(&(v781_13_head));
    let v782_3: Space = intersect(&(*CONSTANT_2),&(v782_2));
    let v782_4: Space = if has_head(&(v782_3)) { singleton(&[]) } else { Space::new() };
    drop(v782_3);
    let v782_5: Space = subtract(&(*CONSTANT_1),&(v782_4));
    drop(v782_4);
    let v782_8: Space = if (v782_5).is_empty() { Space::new() } else {
      let v783_6: Path = concat_path(&(*p0),&(v781_13_head));
      let mut v783_7 = Space::new();
      let mut v783_7_cursor = (v781_13_tail).read_zipper();
      for v783_7_byte in v783_7_cursor.child_mask().iter() {
        v783_7_cursor.descend_to_byte(v783_7_byte);
        let v783_7_tail = v783_7_cursor.make_map();
        v783_7_cursor.ascend(1);
        let v783_7_head = Path::from_slice(&[v783_7_byte]);
        let v784_2: Space = singleton(&(v783_7_head));
        let v784_3: Space = intersect(&(*CONSTANT_2),&(v784_2));
        let v784_4: Space = if has_head(&(v784_3)) { singleton(&[]) } else { Space::new() };
        drop(v784_3);
        let v784_5: Space = subtract(&(*CONSTANT_1),&(v784_4));
        drop(v784_4);
        let v784_8: Space = if (v784_5).is_empty() { Space::new() } else {
          let v785_6: Path = concat_path(&(v783_6),&(v783_7_head));
          let v785_7: Space = routine_124(c, &(v785_6), &(*p1), &(v783_7_tail), &(*s1));
          compose(&(v784_5),&(v785_7))
        };
        drop(v784_5);
        let v784_9: Space = intersect(&(*CONSTANT_2),&(v784_2));
        drop(v784_2);
        let v784_10: Space = if has_head(&(v784_9)) { singleton(&[]) } else { Space::new() };
        drop(v784_9);
        let v784_12: Space = if (v784_10).is_empty() { Space::new() } else {
          let v786_6: Path = concat_path(&(v783_6),&(v783_7_head));
          let v786_11: Space = routine_125(c, &(v786_6), &(*p1), &(v783_7_tail), &(*s1));
          drop(v786_6);
          compose(&(v784_10),&(v786_11))
        };
        drop(v784_10);
        let v784_13: Space = unite(&(v784_8),&(v784_12));
        v783_7.join_into((v784_13).clone());
      }
      drop(v783_7_cursor);
      compose(&(v782_5),&(v783_7))
    };
    drop(v782_5);
    let v782_9: Space = intersect(&(*CONSTANT_2),&(v782_2));
    drop(v782_2);
    let v782_10: Space = if has_head(&(v782_9)) { singleton(&[]) } else { Space::new() };
    drop(v782_9);
    let v782_12: Space = if (v782_10).is_empty() { Space::new() } else {
      let v787_6: Path = concat_path(&(*p0),&(v781_13_head));
      let mut v787_11 = Space::new();
      let mut v787_11_cursor = (v781_13_tail).read_zipper();
      for v787_11_byte in v787_11_cursor.child_mask().iter() {
        v787_11_cursor.descend_to_byte(v787_11_byte);
        let v787_11_tail = v787_11_cursor.make_map();
        v787_11_cursor.ascend(1);
        let v787_11_head = Path::from_slice(&[v787_11_byte]);
        let v788_2: Space = singleton(&(v787_11_head));
        let v788_3: Space = intersect(&(*CONSTANT_2),&(v788_2));
        let v788_4: Space = if has_head(&(v788_3)) { singleton(&[]) } else { Space::new() };
        drop(v788_3);
        let v788_5: Space = subtract(&(*CONSTANT_1),&(v788_4));
        drop(v788_4);
        let v788_8: Space = if (v788_5).is_empty() { Space::new() } else {
          let v789_6: Path = concat_path(&(v787_6),&(v787_11_head));
          let v789_7: Space = routine_124(c, &(v789_6), &(*p1), &(v787_11_tail), &(*s1));
          compose(&(v788_5),&(v789_7))
        };
        drop(v788_5);
        let v788_9: Space = intersect(&(*CONSTANT_2),&(v788_2));
        drop(v788_2);
        let v788_10: Space = if has_head(&(v788_9)) { singleton(&[]) } else { Space::new() };
        drop(v788_9);
        let v788_12: Space = if (v788_10).is_empty() { Space::new() } else {
          let v790_6: Path = concat_path(&(v787_6),&(v787_11_head));
          let v790_11: Space = routine_43(c, &(v790_6), &(*p1), &(v787_11_tail), &(*s1));
          drop(v790_6);
          compose(&(v788_10),&(v790_11))
        };
        drop(v788_10);
        let v788_13: Space = unite(&(v788_8),&(v788_12));
        v787_11.join_into((v788_13).clone());
      }
      drop(v787_11_cursor);
      drop(v787_6);
      compose(&(v782_10),&(v787_11))
    };
    drop(v782_10);
    let v782_13: Space = unite(&(v782_8),&(v782_12));
    v781_13.join_into((v782_13).clone());
  }
  drop(v781_13_cursor);
  (v781_13).clone()
}

fn routine_82(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v791_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v791_10: Space = unwrap(&(v791_8),&(*CONSTANT_5));
  drop(v791_8);
  let v791_11: Space = unwrap(&(v791_10),&(*p0));
  drop(v791_10);
  let mut v791_18 = Space::new();
  let mut v791_18_cursor = (*s0).read_zipper();
  for v791_18_byte in v791_18_cursor.child_mask().iter() {
    v791_18_cursor.descend_to_byte(v791_18_byte);
    let v791_18_tail = v791_18_cursor.make_map();
    v791_18_cursor.ascend(1);
    let v791_18_head = Path::from_slice(&[v791_18_byte]);
    let v792_2: Space = singleton(&(v791_18_head));
    let v792_3: Space = intersect(&(*CONSTANT_2),&(v792_2));
    let v792_4: Space = if has_head(&(v792_3)) { singleton(&[]) } else { Space::new() };
    drop(v792_3);
    let v792_5: Space = subtract(&(*CONSTANT_1),&(v792_4));
    drop(v792_4);
    let v792_8: Space = if (v792_5).is_empty() { Space::new() } else {
      let v793_6: Path = concat_path(&(*p0),&(v791_18_head));
      let mut v793_7 = Space::new();
      let mut v793_7_cursor = (v791_18_tail).read_zipper();
      for v793_7_byte in v793_7_cursor.child_mask().iter() {
        v793_7_cursor.descend_to_byte(v793_7_byte);
        let v793_7_tail = v793_7_cursor.make_map();
        v793_7_cursor.ascend(1);
        let v793_7_head = Path::from_slice(&[v793_7_byte]);
        let v794_2: Space = singleton(&(v793_7_head));
        let v794_3: Space = intersect(&(*CONSTANT_2),&(v794_2));
        let v794_4: Space = if has_head(&(v794_3)) { singleton(&[]) } else { Space::new() };
        drop(v794_3);
        let v794_5: Space = subtract(&(*CONSTANT_1),&(v794_4));
        drop(v794_4);
        let v794_8: Space = if (v794_5).is_empty() { Space::new() } else {
          let v795_6: Path = concat_path(&(v793_6),&(v793_7_head));
          let v795_7: Space = routine_124(c, &(v795_6), &(*p1), &(v793_7_tail), &(*s1));
          compose(&(v794_5),&(v795_7))
        };
        drop(v794_5);
        let v794_9: Space = intersect(&(*CONSTANT_2),&(v794_2));
        drop(v794_2);
        let v794_10: Space = if has_head(&(v794_9)) { singleton(&[]) } else { Space::new() };
        drop(v794_9);
        let v794_12: Space = if (v794_10).is_empty() { Space::new() } else {
          let v796_6: Path = concat_path(&(v793_6),&(v793_7_head));
          let v796_11: Space = routine_125(c, &(v796_6), &(*p1), &(v793_7_tail), &(*s1));
          drop(v796_6);
          compose(&(v794_10),&(v796_11))
        };
        drop(v794_10);
        let v794_13: Space = unite(&(v794_8),&(v794_12));
        v793_7.join_into((v794_13).clone());
      }
      drop(v793_7_cursor);
      drop(v793_6);
      compose(&(v792_5),&(v793_7))
    };
    drop(v792_5);
    let v792_9: Space = intersect(&(*CONSTANT_2),&(v792_2));
    drop(v792_2);
    let v792_10: Space = if has_head(&(v792_9)) { singleton(&[]) } else { Space::new() };
    drop(v792_9);
    let v792_13: Space = if (v792_10).is_empty() { Space::new() } else {
      let v797_11: Space = unwrap(&(v791_11),&(v791_18_head));
      let mut v797_12 = Space::new();
      let mut v797_12_cursor = (v797_11).read_zipper();
      for v797_12_byte in v797_12_cursor.child_mask().iter() {
        v797_12_cursor.descend_to_byte(v797_12_byte);
        let v797_12_tail = v797_12_cursor.make_map();
        v797_12_cursor.ascend(1);
        let v797_12_head = Path::from_slice(&[v797_12_byte]);
        let v798_2: Space = singleton(&(v797_12_head));
        let v798_3: Space = intersect(&(*CONSTANT_2),&(v798_2));
        let v798_4: Space = if has_head(&(v798_3)) { singleton(&[]) } else { Space::new() };
        drop(v798_3);
        let v798_5: Space = subtract(&(*CONSTANT_1),&(v798_4));
        drop(v798_4);
        let v798_7: Space = if (v798_5).is_empty() { Space::new() } else {
          let v799_6: Space = routine_83(c, &(v797_12_head), &(*p1), &(v797_12_tail));
          compose(&(v798_5),&(v799_6))
        };
        drop(v798_5);
        let v798_8: Space = intersect(&(*CONSTANT_2),&(v798_2));
        drop(v798_2);
        let v798_9: Space = if has_head(&(v798_8)) { singleton(&[]) } else { Space::new() };
        drop(v798_8);
        let v798_11: Space = if (v798_9).is_empty() { Space::new() } else {
          let v800_10: Space = routine_84(c, &(v797_12_head), &(*p1), &(v797_12_tail));
          compose(&(v798_9),&(v800_10))
        };
        drop(v798_9);
        let v798_12: Space = unite(&(v798_7),&(v798_11));
        v797_12.join_into((v798_12).clone());
      }
      drop(v797_12_cursor);
      drop(v797_11);
      compose(&(v792_10),&(v797_12))
    };
    drop(v792_10);
    let v792_14: Space = unite(&(v792_8),&(v792_13));
    v791_18.join_into((v792_14).clone());
  }
  drop(v791_18_cursor);
  drop(v791_11);
  (v791_18).clone()
}

fn routine_83(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v801_12 = Space::new();
  let mut v801_12_cursor = (*s0).read_zipper();
  for v801_12_byte in v801_12_cursor.child_mask().iter() {
    v801_12_cursor.descend_to_byte(v801_12_byte);
    let v801_12_tail = v801_12_cursor.make_map();
    v801_12_cursor.ascend(1);
    let v801_12_head = Path::from_slice(&[v801_12_byte]);
    let v802_2: Space = singleton(&(v801_12_head));
    let v802_3: Space = intersect(&(*CONSTANT_2),&(v802_2));
    let v802_4: Space = if has_head(&(v802_3)) { singleton(&[]) } else { Space::new() };
    drop(v802_3);
    let v802_5: Space = subtract(&(*CONSTANT_1),&(v802_4));
    drop(v802_4);
    let v802_8: Space = if (v802_5).is_empty() { Space::new() } else {
      let v803_6: Path = concat_path(&(*p0),&(v801_12_head));
      let mut v803_7 = Space::new();
      let mut v803_7_cursor = (v801_12_tail).read_zipper();
      for v803_7_byte in v803_7_cursor.child_mask().iter() {
        v803_7_cursor.descend_to_byte(v803_7_byte);
        let v803_7_tail = v803_7_cursor.make_map();
        v803_7_cursor.ascend(1);
        let v803_7_head = Path::from_slice(&[v803_7_byte]);
        let v804_2: Space = singleton(&(v803_7_head));
        let v804_3: Space = intersect(&(*CONSTANT_2),&(v804_2));
        let v804_4: Space = if has_head(&(v804_3)) { singleton(&[]) } else { Space::new() };
        drop(v804_3);
        let v804_5: Space = subtract(&(*CONSTANT_1),&(v804_4));
        drop(v804_4);
        let v804_8: Space = if (v804_5).is_empty() { Space::new() } else {
          let v805_6: Path = concat_path(&(v803_6),&(v803_7_head));
          let v805_7: Space = routine_126(c, &(v805_6), &(*p1), &(v803_7_tail));
          compose(&(v804_5),&(v805_7))
        };
        drop(v804_5);
        let v804_9: Space = intersect(&(*CONSTANT_2),&(v804_2));
        drop(v804_2);
        let v804_10: Space = if has_head(&(v804_9)) { singleton(&[]) } else { Space::new() };
        drop(v804_9);
        let v804_12: Space = if (v804_10).is_empty() { Space::new() } else {
          let v806_6: Path = concat_path(&(v803_6),&(v803_7_head));
          let v806_11: Space = routine_127(c, &(v806_6), &(*p1), &(v803_7_tail));
          drop(v806_6);
          compose(&(v804_10),&(v806_11))
        };
        drop(v804_10);
        let v804_13: Space = unite(&(v804_8),&(v804_12));
        v803_7.join_into((v804_13).clone());
      }
      drop(v803_7_cursor);
      compose(&(v802_5),&(v803_7))
    };
    drop(v802_5);
    let v802_9: Space = intersect(&(*CONSTANT_2),&(v802_2));
    drop(v802_2);
    let v802_10: Space = if has_head(&(v802_9)) { singleton(&[]) } else { Space::new() };
    drop(v802_9);
    let v802_12: Space = if (v802_10).is_empty() { Space::new() } else {
      let v807_6: Path = concat_path(&(*p0),&(v801_12_head));
      let mut v807_11 = Space::new();
      let mut v807_11_cursor = (v801_12_tail).read_zipper();
      for v807_11_byte in v807_11_cursor.child_mask().iter() {
        v807_11_cursor.descend_to_byte(v807_11_byte);
        let v807_11_tail = v807_11_cursor.make_map();
        v807_11_cursor.ascend(1);
        let v807_11_head = Path::from_slice(&[v807_11_byte]);
        let v808_2: Space = singleton(&(v807_11_head));
        let v808_3: Space = intersect(&(*CONSTANT_2),&(v808_2));
        let v808_4: Space = if has_head(&(v808_3)) { singleton(&[]) } else { Space::new() };
        drop(v808_3);
        let v808_5: Space = subtract(&(*CONSTANT_1),&(v808_4));
        drop(v808_4);
        let v808_8: Space = if (v808_5).is_empty() { Space::new() } else {
          let v809_6: Path = concat_path(&(v807_6),&(v807_11_head));
          let v809_7: Space = routine_126(c, &(v809_6), &(*p1), &(v807_11_tail));
          compose(&(v808_5),&(v809_7))
        };
        drop(v808_5);
        let v808_9: Space = intersect(&(*CONSTANT_2),&(v808_2));
        drop(v808_2);
        let v808_10: Space = if has_head(&(v808_9)) { singleton(&[]) } else { Space::new() };
        drop(v808_9);
        let v808_12: Space = if (v808_10).is_empty() { Space::new() } else {
          let v810_6: Path = concat_path(&(v807_6),&(v807_11_head));
          let v810_11: Space = routine_89(c, &(v810_6), &(*p1), &(v807_11_tail));
          drop(v810_6);
          compose(&(v808_10),&(v810_11))
        };
        drop(v808_10);
        let v808_13: Space = unite(&(v808_8),&(v808_12));
        v807_11.join_into((v808_13).clone());
      }
      drop(v807_11_cursor);
      drop(v807_6);
      compose(&(v802_10),&(v807_11))
    };
    drop(v802_10);
    let v802_13: Space = unite(&(v802_8),&(v802_12));
    v801_12.join_into((v802_13).clone());
  }
  drop(v801_12_cursor);
  (v801_12).clone()
}

fn routine_84(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v811_9 = Space::new();
  let mut v811_9_cursor = (*s0).read_zipper();
  for v811_9_byte in v811_9_cursor.child_mask().iter() {
    v811_9_cursor.descend_to_byte(v811_9_byte);
    let v811_9_tail = v811_9_cursor.make_map();
    v811_9_cursor.ascend(1);
    let v811_9_head = Path::from_slice(&[v811_9_byte]);
    let v812_2: Space = singleton(&(v811_9_head));
    let v812_3: Space = intersect(&(*CONSTANT_2),&(v812_2));
    let v812_4: Space = if has_head(&(v812_3)) { singleton(&[]) } else { Space::new() };
    drop(v812_3);
    let v812_5: Space = subtract(&(*CONSTANT_1),&(v812_4));
    drop(v812_4);
    let v812_8: Space = if (v812_5).is_empty() { Space::new() } else {
      let v813_6: Path = concat_path(&(*p0),&(v811_9_head));
      let mut v813_7 = Space::new();
      let mut v813_7_cursor = (v811_9_tail).read_zipper();
      for v813_7_byte in v813_7_cursor.child_mask().iter() {
        v813_7_cursor.descend_to_byte(v813_7_byte);
        let v813_7_tail = v813_7_cursor.make_map();
        v813_7_cursor.ascend(1);
        let v813_7_head = Path::from_slice(&[v813_7_byte]);
        let v814_2: Space = singleton(&(v813_7_head));
        let v814_3: Space = intersect(&(*CONSTANT_2),&(v814_2));
        let v814_4: Space = if has_head(&(v814_3)) { singleton(&[]) } else { Space::new() };
        drop(v814_3);
        let v814_5: Space = subtract(&(*CONSTANT_1),&(v814_4));
        drop(v814_4);
        let v814_8: Space = if (v814_5).is_empty() { Space::new() } else {
          let v815_6: Path = concat_path(&(v813_6),&(v813_7_head));
          let v815_7: Space = routine_126(c, &(v815_6), &(*p1), &(v813_7_tail));
          compose(&(v814_5),&(v815_7))
        };
        drop(v814_5);
        let v814_9: Space = intersect(&(*CONSTANT_2),&(v814_2));
        drop(v814_2);
        let v814_10: Space = if has_head(&(v814_9)) { singleton(&[]) } else { Space::new() };
        drop(v814_9);
        let v814_12: Space = if (v814_10).is_empty() { Space::new() } else {
          let v816_6: Path = concat_path(&(v813_6),&(v813_7_head));
          let v816_11: Space = routine_127(c, &(v816_6), &(*p1), &(v813_7_tail));
          drop(v816_6);
          compose(&(v814_10),&(v816_11))
        };
        drop(v814_10);
        let v814_13: Space = unite(&(v814_8),&(v814_12));
        v813_7.join_into((v814_13).clone());
      }
      drop(v813_7_cursor);
      compose(&(v812_5),&(v813_7))
    };
    drop(v812_5);
    let v812_9: Space = intersect(&(*CONSTANT_2),&(v812_2));
    drop(v812_2);
    let v812_10: Space = if has_head(&(v812_9)) { singleton(&[]) } else { Space::new() };
    drop(v812_9);
    let v812_11: Space = compose(&(v812_10),&(v811_9_tail));
    drop(v812_10);
    let v817_6: Path = concat_path(&(*p0),&(v811_9_head));
    let v812_12: Space = wrap(&(v812_11),&(v817_6));
    drop(v812_11);
    let v812_13: Space = wrap(&(v812_12),&(*p1));
    drop(v812_12);
    let v812_14: Space = unite(&(v812_8),&(v812_13));
    drop(v812_13);
    v811_9.join_into((v812_14).clone());
  }
  drop(v811_9_cursor);
  (v811_9).clone()
}

fn routine_85(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v818_13 = Space::new();
  let mut v818_13_cursor = (*s0).read_zipper();
  for v818_13_byte in v818_13_cursor.child_mask().iter() {
    v818_13_cursor.descend_to_byte(v818_13_byte);
    let v818_13_tail = v818_13_cursor.make_map();
    v818_13_cursor.ascend(1);
    let v818_13_head = Path::from_slice(&[v818_13_byte]);
    let v819_2: Space = singleton(&(v818_13_head));
    let v819_3: Space = intersect(&(*CONSTANT_2),&(v819_2));
    let v819_4: Space = if has_head(&(v819_3)) { singleton(&[]) } else { Space::new() };
    drop(v819_3);
    let v819_5: Space = subtract(&(*CONSTANT_1),&(v819_4));
    drop(v819_4);
    let v819_8: Space = if (v819_5).is_empty() { Space::new() } else {
      let v820_6: Path = concat_path(&(*p0),&(v818_13_head));
      let mut v820_7 = Space::new();
      let mut v820_7_cursor = (v818_13_tail).read_zipper();
      for v820_7_byte in v820_7_cursor.child_mask().iter() {
        v820_7_cursor.descend_to_byte(v820_7_byte);
        let v820_7_tail = v820_7_cursor.make_map();
        v820_7_cursor.ascend(1);
        let v820_7_head = Path::from_slice(&[v820_7_byte]);
        let v821_2: Space = singleton(&(v820_7_head));
        let v821_3: Space = intersect(&(*CONSTANT_2),&(v821_2));
        let v821_4: Space = if has_head(&(v821_3)) { singleton(&[]) } else { Space::new() };
        drop(v821_3);
        let v821_5: Space = subtract(&(*CONSTANT_1),&(v821_4));
        drop(v821_4);
        let v821_8: Space = if (v821_5).is_empty() { Space::new() } else {
          let v822_6: Path = concat_path(&(v820_6),&(v820_7_head));
          let v822_7: Space = routine_128(c, &(v822_6), &(*p1), &(v820_7_tail), &(*s1));
          compose(&(v821_5),&(v822_7))
        };
        drop(v821_5);
        let v821_9: Space = intersect(&(*CONSTANT_2),&(v821_2));
        drop(v821_2);
        let v821_10: Space = if has_head(&(v821_9)) { singleton(&[]) } else { Space::new() };
        drop(v821_9);
        let v821_12: Space = if (v821_10).is_empty() { Space::new() } else {
          let v823_6: Path = concat_path(&(v820_6),&(v820_7_head));
          let v823_11: Space = routine_129(c, &(v823_6), &(*p1), &(v820_7_tail), &(*s1));
          drop(v823_6);
          compose(&(v821_10),&(v823_11))
        };
        drop(v821_10);
        let v821_13: Space = unite(&(v821_8),&(v821_12));
        v820_7.join_into((v821_13).clone());
      }
      drop(v820_7_cursor);
      compose(&(v819_5),&(v820_7))
    };
    drop(v819_5);
    let v819_9: Space = intersect(&(*CONSTANT_2),&(v819_2));
    drop(v819_2);
    let v819_10: Space = if has_head(&(v819_9)) { singleton(&[]) } else { Space::new() };
    drop(v819_9);
    let v819_12: Space = if (v819_10).is_empty() { Space::new() } else {
      let v824_6: Path = concat_path(&(*p0),&(v818_13_head));
      let mut v824_11 = Space::new();
      let mut v824_11_cursor = (v818_13_tail).read_zipper();
      for v824_11_byte in v824_11_cursor.child_mask().iter() {
        v824_11_cursor.descend_to_byte(v824_11_byte);
        let v824_11_tail = v824_11_cursor.make_map();
        v824_11_cursor.ascend(1);
        let v824_11_head = Path::from_slice(&[v824_11_byte]);
        let v825_2: Space = singleton(&(v824_11_head));
        let v825_3: Space = intersect(&(*CONSTANT_2),&(v825_2));
        let v825_4: Space = if has_head(&(v825_3)) { singleton(&[]) } else { Space::new() };
        drop(v825_3);
        let v825_5: Space = subtract(&(*CONSTANT_1),&(v825_4));
        drop(v825_4);
        let v825_8: Space = if (v825_5).is_empty() { Space::new() } else {
          let v826_6: Path = concat_path(&(v824_6),&(v824_11_head));
          let v826_7: Space = routine_128(c, &(v826_6), &(*p1), &(v824_11_tail), &(*s1));
          compose(&(v825_5),&(v826_7))
        };
        drop(v825_5);
        let v825_9: Space = intersect(&(*CONSTANT_2),&(v825_2));
        drop(v825_2);
        let v825_10: Space = if has_head(&(v825_9)) { singleton(&[]) } else { Space::new() };
        drop(v825_9);
        let v825_12: Space = if (v825_10).is_empty() { Space::new() } else {
          let v827_6: Path = concat_path(&(v824_6),&(v824_11_head));
          let v827_11: Space = routine_43(c, &(v827_6), &(*p1), &(v824_11_tail), &(*s1));
          drop(v827_6);
          compose(&(v825_10),&(v827_11))
        };
        drop(v825_10);
        let v825_13: Space = unite(&(v825_8),&(v825_12));
        v824_11.join_into((v825_13).clone());
      }
      drop(v824_11_cursor);
      drop(v824_6);
      compose(&(v819_10),&(v824_11))
    };
    drop(v819_10);
    let v819_13: Space = unite(&(v819_8),&(v819_12));
    v818_13.join_into((v819_13).clone());
  }
  drop(v818_13_cursor);
  (v818_13).clone()
}

fn routine_86(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v828_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v828_10: Space = unwrap(&(v828_8),&(*CONSTANT_5));
  drop(v828_8);
  let v828_11: Space = unwrap(&(v828_10),&(*p0));
  drop(v828_10);
  let mut v828_18 = Space::new();
  let mut v828_18_cursor = (*s0).read_zipper();
  for v828_18_byte in v828_18_cursor.child_mask().iter() {
    v828_18_cursor.descend_to_byte(v828_18_byte);
    let v828_18_tail = v828_18_cursor.make_map();
    v828_18_cursor.ascend(1);
    let v828_18_head = Path::from_slice(&[v828_18_byte]);
    let v829_2: Space = singleton(&(v828_18_head));
    let v829_3: Space = intersect(&(*CONSTANT_2),&(v829_2));
    let v829_4: Space = if has_head(&(v829_3)) { singleton(&[]) } else { Space::new() };
    drop(v829_3);
    let v829_5: Space = subtract(&(*CONSTANT_1),&(v829_4));
    drop(v829_4);
    let v829_8: Space = if (v829_5).is_empty() { Space::new() } else {
      let v830_6: Path = concat_path(&(*p0),&(v828_18_head));
      let mut v830_7 = Space::new();
      let mut v830_7_cursor = (v828_18_tail).read_zipper();
      for v830_7_byte in v830_7_cursor.child_mask().iter() {
        v830_7_cursor.descend_to_byte(v830_7_byte);
        let v830_7_tail = v830_7_cursor.make_map();
        v830_7_cursor.ascend(1);
        let v830_7_head = Path::from_slice(&[v830_7_byte]);
        let v831_2: Space = singleton(&(v830_7_head));
        let v831_3: Space = intersect(&(*CONSTANT_2),&(v831_2));
        let v831_4: Space = if has_head(&(v831_3)) { singleton(&[]) } else { Space::new() };
        drop(v831_3);
        let v831_5: Space = subtract(&(*CONSTANT_1),&(v831_4));
        drop(v831_4);
        let v831_8: Space = if (v831_5).is_empty() { Space::new() } else {
          let v832_6: Path = concat_path(&(v830_6),&(v830_7_head));
          let v832_7: Space = routine_128(c, &(v832_6), &(*p1), &(v830_7_tail), &(*s1));
          compose(&(v831_5),&(v832_7))
        };
        drop(v831_5);
        let v831_9: Space = intersect(&(*CONSTANT_2),&(v831_2));
        drop(v831_2);
        let v831_10: Space = if has_head(&(v831_9)) { singleton(&[]) } else { Space::new() };
        drop(v831_9);
        let v831_12: Space = if (v831_10).is_empty() { Space::new() } else {
          let v833_6: Path = concat_path(&(v830_6),&(v830_7_head));
          let v833_11: Space = routine_129(c, &(v833_6), &(*p1), &(v830_7_tail), &(*s1));
          drop(v833_6);
          compose(&(v831_10),&(v833_11))
        };
        drop(v831_10);
        let v831_13: Space = unite(&(v831_8),&(v831_12));
        v830_7.join_into((v831_13).clone());
      }
      drop(v830_7_cursor);
      drop(v830_6);
      compose(&(v829_5),&(v830_7))
    };
    drop(v829_5);
    let v829_9: Space = intersect(&(*CONSTANT_2),&(v829_2));
    drop(v829_2);
    let v829_10: Space = if has_head(&(v829_9)) { singleton(&[]) } else { Space::new() };
    drop(v829_9);
    let v829_13: Space = if (v829_10).is_empty() { Space::new() } else {
      let v834_11: Space = unwrap(&(v828_11),&(v828_18_head));
      let mut v834_12 = Space::new();
      let mut v834_12_cursor = (v834_11).read_zipper();
      for v834_12_byte in v834_12_cursor.child_mask().iter() {
        v834_12_cursor.descend_to_byte(v834_12_byte);
        let v834_12_tail = v834_12_cursor.make_map();
        v834_12_cursor.ascend(1);
        let v834_12_head = Path::from_slice(&[v834_12_byte]);
        let v835_2: Space = singleton(&(v834_12_head));
        let v835_3: Space = intersect(&(*CONSTANT_2),&(v835_2));
        let v835_4: Space = if has_head(&(v835_3)) { singleton(&[]) } else { Space::new() };
        drop(v835_3);
        let v835_5: Space = subtract(&(*CONSTANT_1),&(v835_4));
        drop(v835_4);
        let v835_7: Space = if (v835_5).is_empty() { Space::new() } else {
          let v836_6: Space = routine_83(c, &(v834_12_head), &(*p1), &(v834_12_tail));
          compose(&(v835_5),&(v836_6))
        };
        drop(v835_5);
        let v835_8: Space = intersect(&(*CONSTANT_2),&(v835_2));
        drop(v835_2);
        let v835_9: Space = if has_head(&(v835_8)) { singleton(&[]) } else { Space::new() };
        drop(v835_8);
        let v835_11: Space = if (v835_9).is_empty() { Space::new() } else {
          let v837_10: Space = routine_84(c, &(v834_12_head), &(*p1), &(v834_12_tail));
          compose(&(v835_9),&(v837_10))
        };
        drop(v835_9);
        let v835_12: Space = unite(&(v835_7),&(v835_11));
        v834_12.join_into((v835_12).clone());
      }
      drop(v834_12_cursor);
      drop(v834_11);
      compose(&(v829_10),&(v834_12))
    };
    drop(v829_10);
    let v829_14: Space = unite(&(v829_8),&(v829_13));
    v828_18.join_into((v829_14).clone());
  }
  drop(v828_18_cursor);
  drop(v828_11);
  (v828_18).clone()
}

fn routine_87(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v838_12 = Space::new();
  let mut v838_12_cursor = (*s0).read_zipper();
  for v838_12_byte in v838_12_cursor.child_mask().iter() {
    v838_12_cursor.descend_to_byte(v838_12_byte);
    let v838_12_tail = v838_12_cursor.make_map();
    v838_12_cursor.ascend(1);
    let v838_12_head = Path::from_slice(&[v838_12_byte]);
    let v839_2: Space = singleton(&(v838_12_head));
    let v839_3: Space = intersect(&(*CONSTANT_2),&(v839_2));
    let v839_4: Space = if has_head(&(v839_3)) { singleton(&[]) } else { Space::new() };
    drop(v839_3);
    let v839_5: Space = subtract(&(*CONSTANT_1),&(v839_4));
    drop(v839_4);
    let v839_8: Space = if (v839_5).is_empty() { Space::new() } else {
      let v840_6: Path = concat_path(&(*p0),&(v838_12_head));
      let mut v840_7 = Space::new();
      let mut v840_7_cursor = (v838_12_tail).read_zipper();
      for v840_7_byte in v840_7_cursor.child_mask().iter() {
        v840_7_cursor.descend_to_byte(v840_7_byte);
        let v840_7_tail = v840_7_cursor.make_map();
        v840_7_cursor.ascend(1);
        let v840_7_head = Path::from_slice(&[v840_7_byte]);
        let v841_2: Space = singleton(&(v840_7_head));
        let v841_3: Space = intersect(&(*CONSTANT_2),&(v841_2));
        let v841_4: Space = if has_head(&(v841_3)) { singleton(&[]) } else { Space::new() };
        drop(v841_3);
        let v841_5: Space = subtract(&(*CONSTANT_1),&(v841_4));
        drop(v841_4);
        let v841_8: Space = if (v841_5).is_empty() { Space::new() } else {
          let v842_6: Path = concat_path(&(v840_6),&(v840_7_head));
          let v842_7: Space = routine_130(c, &(v842_6), &(*p1), &(v840_7_tail));
          compose(&(v841_5),&(v842_7))
        };
        drop(v841_5);
        let v841_9: Space = intersect(&(*CONSTANT_2),&(v841_2));
        drop(v841_2);
        let v841_10: Space = if has_head(&(v841_9)) { singleton(&[]) } else { Space::new() };
        drop(v841_9);
        let v841_12: Space = if (v841_10).is_empty() { Space::new() } else {
          let v843_6: Path = concat_path(&(v840_6),&(v840_7_head));
          let v843_11: Space = routine_131(c, &(v843_6), &(*p1), &(v840_7_tail));
          drop(v843_6);
          compose(&(v841_10),&(v843_11))
        };
        drop(v841_10);
        let v841_13: Space = unite(&(v841_8),&(v841_12));
        v840_7.join_into((v841_13).clone());
      }
      drop(v840_7_cursor);
      compose(&(v839_5),&(v840_7))
    };
    drop(v839_5);
    let v839_9: Space = intersect(&(*CONSTANT_2),&(v839_2));
    drop(v839_2);
    let v839_10: Space = if has_head(&(v839_9)) { singleton(&[]) } else { Space::new() };
    drop(v839_9);
    let v839_12: Space = if (v839_10).is_empty() { Space::new() } else {
      let v844_6: Path = concat_path(&(*p0),&(v838_12_head));
      let mut v844_11 = Space::new();
      let mut v844_11_cursor = (v838_12_tail).read_zipper();
      for v844_11_byte in v844_11_cursor.child_mask().iter() {
        v844_11_cursor.descend_to_byte(v844_11_byte);
        let v844_11_tail = v844_11_cursor.make_map();
        v844_11_cursor.ascend(1);
        let v844_11_head = Path::from_slice(&[v844_11_byte]);
        let v845_2: Space = singleton(&(v844_11_head));
        let v845_3: Space = intersect(&(*CONSTANT_2),&(v845_2));
        let v845_4: Space = if has_head(&(v845_3)) { singleton(&[]) } else { Space::new() };
        drop(v845_3);
        let v845_5: Space = subtract(&(*CONSTANT_1),&(v845_4));
        drop(v845_4);
        let v845_8: Space = if (v845_5).is_empty() { Space::new() } else {
          let v846_6: Path = concat_path(&(v844_6),&(v844_11_head));
          let v846_7: Space = routine_130(c, &(v846_6), &(*p1), &(v844_11_tail));
          compose(&(v845_5),&(v846_7))
        };
        drop(v845_5);
        let v845_9: Space = intersect(&(*CONSTANT_2),&(v845_2));
        drop(v845_2);
        let v845_10: Space = if has_head(&(v845_9)) { singleton(&[]) } else { Space::new() };
        drop(v845_9);
        let v845_12: Space = if (v845_10).is_empty() { Space::new() } else {
          let v847_6: Path = concat_path(&(v844_6),&(v844_11_head));
          let v847_11: Space = routine_89(c, &(v847_6), &(*p1), &(v844_11_tail));
          drop(v847_6);
          compose(&(v845_10),&(v847_11))
        };
        drop(v845_10);
        let v845_13: Space = unite(&(v845_8),&(v845_12));
        v844_11.join_into((v845_13).clone());
      }
      drop(v844_11_cursor);
      drop(v844_6);
      compose(&(v839_10),&(v844_11))
    };
    drop(v839_10);
    let v839_13: Space = unite(&(v839_8),&(v839_12));
    v838_12.join_into((v839_13).clone());
  }
  drop(v838_12_cursor);
  (v838_12).clone()
}

fn routine_88(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v848_9 = Space::new();
  let mut v848_9_cursor = (*s0).read_zipper();
  for v848_9_byte in v848_9_cursor.child_mask().iter() {
    v848_9_cursor.descend_to_byte(v848_9_byte);
    let v848_9_tail = v848_9_cursor.make_map();
    v848_9_cursor.ascend(1);
    let v848_9_head = Path::from_slice(&[v848_9_byte]);
    let v849_2: Space = singleton(&(v848_9_head));
    let v849_3: Space = intersect(&(*CONSTANT_2),&(v849_2));
    let v849_4: Space = if has_head(&(v849_3)) { singleton(&[]) } else { Space::new() };
    drop(v849_3);
    let v849_5: Space = subtract(&(*CONSTANT_1),&(v849_4));
    drop(v849_4);
    let v849_8: Space = if (v849_5).is_empty() { Space::new() } else {
      let v850_6: Path = concat_path(&(*p0),&(v848_9_head));
      let mut v850_7 = Space::new();
      let mut v850_7_cursor = (v848_9_tail).read_zipper();
      for v850_7_byte in v850_7_cursor.child_mask().iter() {
        v850_7_cursor.descend_to_byte(v850_7_byte);
        let v850_7_tail = v850_7_cursor.make_map();
        v850_7_cursor.ascend(1);
        let v850_7_head = Path::from_slice(&[v850_7_byte]);
        let v851_2: Space = singleton(&(v850_7_head));
        let v851_3: Space = intersect(&(*CONSTANT_2),&(v851_2));
        let v851_4: Space = if has_head(&(v851_3)) { singleton(&[]) } else { Space::new() };
        drop(v851_3);
        let v851_5: Space = subtract(&(*CONSTANT_1),&(v851_4));
        drop(v851_4);
        let v851_8: Space = if (v851_5).is_empty() { Space::new() } else {
          let v852_6: Path = concat_path(&(v850_6),&(v850_7_head));
          let v852_7: Space = routine_130(c, &(v852_6), &(*p1), &(v850_7_tail));
          compose(&(v851_5),&(v852_7))
        };
        drop(v851_5);
        let v851_9: Space = intersect(&(*CONSTANT_2),&(v851_2));
        drop(v851_2);
        let v851_10: Space = if has_head(&(v851_9)) { singleton(&[]) } else { Space::new() };
        drop(v851_9);
        let v851_12: Space = if (v851_10).is_empty() { Space::new() } else {
          let v853_6: Path = concat_path(&(v850_6),&(v850_7_head));
          let v853_11: Space = routine_131(c, &(v853_6), &(*p1), &(v850_7_tail));
          drop(v853_6);
          compose(&(v851_10),&(v853_11))
        };
        drop(v851_10);
        let v851_13: Space = unite(&(v851_8),&(v851_12));
        v850_7.join_into((v851_13).clone());
      }
      drop(v850_7_cursor);
      compose(&(v849_5),&(v850_7))
    };
    drop(v849_5);
    let v849_9: Space = intersect(&(*CONSTANT_2),&(v849_2));
    drop(v849_2);
    let v849_10: Space = if has_head(&(v849_9)) { singleton(&[]) } else { Space::new() };
    drop(v849_9);
    let v849_11: Space = compose(&(v849_10),&(v848_9_tail));
    drop(v849_10);
    let v854_6: Path = concat_path(&(*p0),&(v848_9_head));
    let v849_12: Space = wrap(&(v849_11),&(v854_6));
    drop(v849_11);
    let v849_13: Space = wrap(&(v849_12),&(*p1));
    drop(v849_12);
    let v849_14: Space = unite(&(v849_8),&(v849_13));
    drop(v849_13);
    v848_9.join_into((v849_14).clone());
  }
  drop(v848_9_cursor);
  (v848_9).clone()
}

fn routine_89(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v855_3: Space = wrap(&(*s0),&(*p0));
  let v855_4: Space = wrap(&(v855_3),&(*p1));
  drop(v855_3);
  (v855_4).clone()
}

fn routine_90(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v856_11 = Space::new();
  let mut v856_11_cursor = (*s0).read_zipper();
  for v856_11_byte in v856_11_cursor.child_mask().iter() {
    v856_11_cursor.descend_to_byte(v856_11_byte);
    let v856_11_tail = v856_11_cursor.make_map();
    v856_11_cursor.ascend(1);
    let v856_11_head = Path::from_slice(&[v856_11_byte]);
    let v857_2: Space = singleton(&(v856_11_head));
    let v857_3: Space = intersect(&(*CONSTANT_2),&(v857_2));
    let v857_4: Space = if has_head(&(v857_3)) { singleton(&[]) } else { Space::new() };
    drop(v857_3);
    let v857_5: Space = subtract(&(*CONSTANT_1),&(v857_4));
    drop(v857_4);
    let v857_8: Space = if (v857_5).is_empty() { Space::new() } else {
      let v858_6: Path = concat_path(&(*p0),&(v856_11_head));
      let mut v858_7 = Space::new();
      let mut v858_7_cursor = (v856_11_tail).read_zipper();
      for v858_7_byte in v858_7_cursor.child_mask().iter() {
        v858_7_cursor.descend_to_byte(v858_7_byte);
        let v858_7_tail = v858_7_cursor.make_map();
        v858_7_cursor.ascend(1);
        let v858_7_head = Path::from_slice(&[v858_7_byte]);
        let v859_2: Space = singleton(&(v858_7_head));
        let v859_3: Space = intersect(&(*CONSTANT_2),&(v859_2));
        let v859_4: Space = if has_head(&(v859_3)) { singleton(&[]) } else { Space::new() };
        drop(v859_3);
        let v859_5: Space = subtract(&(*CONSTANT_1),&(v859_4));
        drop(v859_4);
        let v859_8: Space = if (v859_5).is_empty() { Space::new() } else {
          let v860_6: Path = concat_path(&(v858_6),&(v858_7_head));
          let v860_7: Space = routine_132(c, &(v860_6), &(v858_7_tail));
          compose(&(v859_5),&(v860_7))
        };
        drop(v859_5);
        let v859_9: Space = intersect(&(*CONSTANT_2),&(v859_2));
        drop(v859_2);
        let v859_10: Space = if has_head(&(v859_9)) { singleton(&[]) } else { Space::new() };
        drop(v859_9);
        let v859_12: Space = if (v859_10).is_empty() { Space::new() } else {
          let v861_6: Path = concat_path(&(v858_6),&(v858_7_head));
          let v861_11: Space = routine_133(c, &(v861_6), &(v858_7_tail));
          drop(v861_6);
          compose(&(v859_10),&(v861_11))
        };
        drop(v859_10);
        let v859_13: Space = unite(&(v859_8),&(v859_12));
        v858_7.join_into((v859_13).clone());
      }
      drop(v858_7_cursor);
      compose(&(v857_5),&(v858_7))
    };
    drop(v857_5);
    let v857_9: Space = intersect(&(*CONSTANT_2),&(v857_2));
    drop(v857_2);
    let v857_10: Space = if has_head(&(v857_9)) { singleton(&[]) } else { Space::new() };
    drop(v857_9);
    let v857_12: Space = if (v857_10).is_empty() { Space::new() } else {
      let v862_6: Path = concat_path(&(*p0),&(v856_11_head));
      let mut v862_11 = Space::new();
      let mut v862_11_cursor = (v856_11_tail).read_zipper();
      for v862_11_byte in v862_11_cursor.child_mask().iter() {
        v862_11_cursor.descend_to_byte(v862_11_byte);
        let v862_11_tail = v862_11_cursor.make_map();
        v862_11_cursor.ascend(1);
        let v862_11_head = Path::from_slice(&[v862_11_byte]);
        let v863_2: Space = singleton(&(v862_11_head));
        let v863_3: Space = intersect(&(*CONSTANT_2),&(v863_2));
        let v863_4: Space = if has_head(&(v863_3)) { singleton(&[]) } else { Space::new() };
        drop(v863_3);
        let v863_5: Space = subtract(&(*CONSTANT_1),&(v863_4));
        drop(v863_4);
        let v863_8: Space = if (v863_5).is_empty() { Space::new() } else {
          let v864_6: Path = concat_path(&(v862_6),&(v862_11_head));
          let v864_7: Space = routine_132(c, &(v864_6), &(v862_11_tail));
          compose(&(v863_5),&(v864_7))
        };
        drop(v863_5);
        let v863_9: Space = intersect(&(*CONSTANT_2),&(v863_2));
        drop(v863_2);
        let v863_10: Space = if has_head(&(v863_9)) { singleton(&[]) } else { Space::new() };
        drop(v863_9);
        let v863_12: Space = if (v863_10).is_empty() { Space::new() } else {
          let v865_6: Path = concat_path(&(v862_6),&(v862_11_head));
          let v865_11: Space = routine_15(c, &(v865_6), &(v862_11_tail));
          drop(v865_6);
          compose(&(v863_10),&(v865_11))
        };
        drop(v863_10);
        let v863_13: Space = unite(&(v863_8),&(v863_12));
        v862_11.join_into((v863_13).clone());
      }
      drop(v862_11_cursor);
      drop(v862_6);
      compose(&(v857_10),&(v862_11))
    };
    drop(v857_10);
    let v857_13: Space = unite(&(v857_8),&(v857_12));
    v856_11.join_into((v857_13).clone());
  }
  drop(v856_11_cursor);
  (v856_11).clone()
}

fn routine_91(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v866_11 = Space::new();
  let mut v866_11_cursor = (*s0).read_zipper();
  for v866_11_byte in v866_11_cursor.child_mask().iter() {
    v866_11_cursor.descend_to_byte(v866_11_byte);
    let v866_11_tail = v866_11_cursor.make_map();
    v866_11_cursor.ascend(1);
    let v866_11_head = Path::from_slice(&[v866_11_byte]);
    let v867_2: Space = singleton(&(v866_11_head));
    let v867_3: Space = intersect(&(*CONSTANT_2),&(v867_2));
    let v867_4: Space = if has_head(&(v867_3)) { singleton(&[]) } else { Space::new() };
    drop(v867_3);
    let v867_5: Space = subtract(&(*CONSTANT_1),&(v867_4));
    drop(v867_4);
    let v867_8: Space = if (v867_5).is_empty() { Space::new() } else {
      let v868_6: Path = concat_path(&(*p0),&(v866_11_head));
      let mut v868_7 = Space::new();
      let mut v868_7_cursor = (v866_11_tail).read_zipper();
      for v868_7_byte in v868_7_cursor.child_mask().iter() {
        v868_7_cursor.descend_to_byte(v868_7_byte);
        let v868_7_tail = v868_7_cursor.make_map();
        v868_7_cursor.ascend(1);
        let v868_7_head = Path::from_slice(&[v868_7_byte]);
        let v869_2: Space = singleton(&(v868_7_head));
        let v869_3: Space = intersect(&(*CONSTANT_2),&(v869_2));
        let v869_4: Space = if has_head(&(v869_3)) { singleton(&[]) } else { Space::new() };
        drop(v869_3);
        let v869_5: Space = subtract(&(*CONSTANT_1),&(v869_4));
        drop(v869_4);
        let v869_8: Space = if (v869_5).is_empty() { Space::new() } else {
          let v870_6: Path = concat_path(&(v868_6),&(v868_7_head));
          let v870_7: Space = routine_132(c, &(v870_6), &(v868_7_tail));
          compose(&(v869_5),&(v870_7))
        };
        drop(v869_5);
        let v869_9: Space = intersect(&(*CONSTANT_2),&(v869_2));
        drop(v869_2);
        let v869_10: Space = if has_head(&(v869_9)) { singleton(&[]) } else { Space::new() };
        drop(v869_9);
        let v869_12: Space = if (v869_10).is_empty() { Space::new() } else {
          let v871_6: Path = concat_path(&(v868_6),&(v868_7_head));
          let v871_11: Space = routine_133(c, &(v871_6), &(v868_7_tail));
          drop(v871_6);
          compose(&(v869_10),&(v871_11))
        };
        drop(v869_10);
        let v869_13: Space = unite(&(v869_8),&(v869_12));
        v868_7.join_into((v869_13).clone());
      }
      drop(v868_7_cursor);
      compose(&(v867_5),&(v868_7))
    };
    drop(v867_5);
    let v867_9: Space = intersect(&(*CONSTANT_2),&(v867_2));
    drop(v867_2);
    let v867_10: Space = if has_head(&(v867_9)) { singleton(&[]) } else { Space::new() };
    drop(v867_9);
    let v867_12: Space = if (v867_10).is_empty() { Space::new() } else {
      let v872_6: Path = concat_path(&(*p0),&(v866_11_head));
      let mut v872_11 = Space::new();
      let mut v872_11_cursor = (v866_11_tail).read_zipper();
      for v872_11_byte in v872_11_cursor.child_mask().iter() {
        v872_11_cursor.descend_to_byte(v872_11_byte);
        let v872_11_tail = v872_11_cursor.make_map();
        v872_11_cursor.ascend(1);
        let v872_11_head = Path::from_slice(&[v872_11_byte]);
        let v873_2: Space = singleton(&(v872_11_head));
        let v873_3: Space = intersect(&(*CONSTANT_2),&(v873_2));
        let v873_4: Space = if has_head(&(v873_3)) { singleton(&[]) } else { Space::new() };
        drop(v873_3);
        let v873_5: Space = subtract(&(*CONSTANT_1),&(v873_4));
        drop(v873_4);
        let v873_7: Space = if (v873_5).is_empty() { Space::new() } else {
          let v874_6: Space = routine_46(c, &(v872_11_head), &(v872_6), &(v872_11_tail));
          compose(&(v873_5),&(v874_6))
        };
        drop(v873_5);
        let v873_8: Space = intersect(&(*CONSTANT_2),&(v873_2));
        drop(v873_2);
        let v873_9: Space = if has_head(&(v873_8)) { singleton(&[]) } else { Space::new() };
        drop(v873_8);
        let v873_11: Space = if (v873_9).is_empty() { Space::new() } else {
          let v875_10: Space = routine_47(c, &(v872_11_head), &(v872_6), &(v872_11_tail));
          compose(&(v873_9),&(v875_10))
        };
        drop(v873_9);
        let v873_12: Space = unite(&(v873_7),&(v873_11));
        v872_11.join_into((v873_12).clone());
      }
      drop(v872_11_cursor);
      drop(v872_6);
      compose(&(v867_10),&(v872_11))
    };
    drop(v867_10);
    let v867_13: Space = unite(&(v867_8),&(v867_12));
    v866_11.join_into((v867_13).clone());
  }
  drop(v866_11_cursor);
  (v866_11).clone()
}

fn routine_92(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v876_12 = Space::new();
  let mut v876_12_cursor = (*s0).read_zipper();
  for v876_12_byte in v876_12_cursor.child_mask().iter() {
    v876_12_cursor.descend_to_byte(v876_12_byte);
    let v876_12_tail = v876_12_cursor.make_map();
    v876_12_cursor.ascend(1);
    let v876_12_head = Path::from_slice(&[v876_12_byte]);
    let v877_2: Space = singleton(&(v876_12_head));
    let v877_3: Space = intersect(&(*CONSTANT_2),&(v877_2));
    let v877_4: Space = if has_head(&(v877_3)) { singleton(&[]) } else { Space::new() };
    drop(v877_3);
    let v877_5: Space = subtract(&(*CONSTANT_1),&(v877_4));
    drop(v877_4);
    let v877_8: Space = if (v877_5).is_empty() { Space::new() } else {
      let v878_6: Path = concat_path(&(*p0),&(v876_12_head));
      let mut v878_7 = Space::new();
      let mut v878_7_cursor = (v876_12_tail).read_zipper();
      for v878_7_byte in v878_7_cursor.child_mask().iter() {
        v878_7_cursor.descend_to_byte(v878_7_byte);
        let v878_7_tail = v878_7_cursor.make_map();
        v878_7_cursor.ascend(1);
        let v878_7_head = Path::from_slice(&[v878_7_byte]);
        let v879_2: Space = singleton(&(v878_7_head));
        let v879_3: Space = intersect(&(*CONSTANT_2),&(v879_2));
        let v879_4: Space = if has_head(&(v879_3)) { singleton(&[]) } else { Space::new() };
        drop(v879_3);
        let v879_5: Space = subtract(&(*CONSTANT_1),&(v879_4));
        drop(v879_4);
        let v879_8: Space = if (v879_5).is_empty() { Space::new() } else {
          let v880_6: Path = concat_path(&(v878_6),&(v878_7_head));
          let v880_7: Space = routine_134(c, &(v880_6), &(*p1), &(v878_7_tail));
          compose(&(v879_5),&(v880_7))
        };
        drop(v879_5);
        let v879_9: Space = intersect(&(*CONSTANT_2),&(v879_2));
        drop(v879_2);
        let v879_10: Space = if has_head(&(v879_9)) { singleton(&[]) } else { Space::new() };
        drop(v879_9);
        let v879_12: Space = if (v879_10).is_empty() { Space::new() } else {
          let v881_6: Path = concat_path(&(v878_6),&(v878_7_head));
          let v881_11: Space = routine_135(c, &(v881_6), &(*p1), &(v878_7_tail));
          drop(v881_6);
          compose(&(v879_10),&(v881_11))
        };
        drop(v879_10);
        let v879_13: Space = unite(&(v879_8),&(v879_12));
        v878_7.join_into((v879_13).clone());
      }
      drop(v878_7_cursor);
      compose(&(v877_5),&(v878_7))
    };
    drop(v877_5);
    let v877_9: Space = intersect(&(*CONSTANT_2),&(v877_2));
    drop(v877_2);
    let v877_10: Space = if has_head(&(v877_9)) { singleton(&[]) } else { Space::new() };
    drop(v877_9);
    let v877_12: Space = if (v877_10).is_empty() { Space::new() } else {
      let v882_6: Path = concat_path(&(*p0),&(v876_12_head));
      let mut v882_11 = Space::new();
      let mut v882_11_cursor = (v876_12_tail).read_zipper();
      for v882_11_byte in v882_11_cursor.child_mask().iter() {
        v882_11_cursor.descend_to_byte(v882_11_byte);
        let v882_11_tail = v882_11_cursor.make_map();
        v882_11_cursor.ascend(1);
        let v882_11_head = Path::from_slice(&[v882_11_byte]);
        let v883_2: Space = singleton(&(v882_11_head));
        let v883_3: Space = intersect(&(*CONSTANT_2),&(v883_2));
        let v883_4: Space = if has_head(&(v883_3)) { singleton(&[]) } else { Space::new() };
        drop(v883_3);
        let v883_5: Space = subtract(&(*CONSTANT_1),&(v883_4));
        drop(v883_4);
        let v883_8: Space = if (v883_5).is_empty() { Space::new() } else {
          let v884_6: Path = concat_path(&(v882_6),&(v882_11_head));
          let v884_7: Space = routine_134(c, &(v884_6), &(*p1), &(v882_11_tail));
          compose(&(v883_5),&(v884_7))
        };
        drop(v883_5);
        let v883_9: Space = intersect(&(*CONSTANT_2),&(v883_2));
        drop(v883_2);
        let v883_10: Space = if has_head(&(v883_9)) { singleton(&[]) } else { Space::new() };
        drop(v883_9);
        let v883_12: Space = if (v883_10).is_empty() { Space::new() } else {
          let v885_6: Path = concat_path(&(v882_6),&(v882_11_head));
          let v885_11: Space = routine_50(c, &(v885_6), &(*p1), &(v882_11_tail));
          drop(v885_6);
          compose(&(v883_10),&(v885_11))
        };
        drop(v883_10);
        let v883_13: Space = unite(&(v883_8),&(v883_12));
        v882_11.join_into((v883_13).clone());
      }
      drop(v882_11_cursor);
      drop(v882_6);
      compose(&(v877_10),&(v882_11))
    };
    drop(v877_10);
    let v877_13: Space = unite(&(v877_8),&(v877_12));
    v876_12.join_into((v877_13).clone());
  }
  drop(v876_12_cursor);
  (v876_12).clone()
}

fn routine_93(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v886_9 = Space::new();
  let mut v886_9_cursor = (*s0).read_zipper();
  for v886_9_byte in v886_9_cursor.child_mask().iter() {
    v886_9_cursor.descend_to_byte(v886_9_byte);
    let v886_9_tail = v886_9_cursor.make_map();
    v886_9_cursor.ascend(1);
    let v886_9_head = Path::from_slice(&[v886_9_byte]);
    let v887_2: Space = singleton(&(v886_9_head));
    let v887_3: Space = intersect(&(*CONSTANT_2),&(v887_2));
    let v887_4: Space = if has_head(&(v887_3)) { singleton(&[]) } else { Space::new() };
    drop(v887_3);
    let v887_5: Space = subtract(&(*CONSTANT_1),&(v887_4));
    drop(v887_4);
    let v887_8: Space = if (v887_5).is_empty() { Space::new() } else {
      let v888_6: Path = concat_path(&(*p0),&(v886_9_head));
      let mut v888_7 = Space::new();
      let mut v888_7_cursor = (v886_9_tail).read_zipper();
      for v888_7_byte in v888_7_cursor.child_mask().iter() {
        v888_7_cursor.descend_to_byte(v888_7_byte);
        let v888_7_tail = v888_7_cursor.make_map();
        v888_7_cursor.ascend(1);
        let v888_7_head = Path::from_slice(&[v888_7_byte]);
        let v889_2: Space = singleton(&(v888_7_head));
        let v889_3: Space = intersect(&(*CONSTANT_2),&(v889_2));
        let v889_4: Space = if has_head(&(v889_3)) { singleton(&[]) } else { Space::new() };
        drop(v889_3);
        let v889_5: Space = subtract(&(*CONSTANT_1),&(v889_4));
        drop(v889_4);
        let v889_8: Space = if (v889_5).is_empty() { Space::new() } else {
          let v890_6: Path = concat_path(&(v888_6),&(v888_7_head));
          let v890_7: Space = routine_134(c, &(v890_6), &(*p1), &(v888_7_tail));
          compose(&(v889_5),&(v890_7))
        };
        drop(v889_5);
        let v889_9: Space = intersect(&(*CONSTANT_2),&(v889_2));
        drop(v889_2);
        let v889_10: Space = if has_head(&(v889_9)) { singleton(&[]) } else { Space::new() };
        drop(v889_9);
        let v889_12: Space = if (v889_10).is_empty() { Space::new() } else {
          let v891_6: Path = concat_path(&(v888_6),&(v888_7_head));
          let v891_11: Space = routine_135(c, &(v891_6), &(*p1), &(v888_7_tail));
          drop(v891_6);
          compose(&(v889_10),&(v891_11))
        };
        drop(v889_10);
        let v889_13: Space = unite(&(v889_8),&(v889_12));
        v888_7.join_into((v889_13).clone());
      }
      drop(v888_7_cursor);
      compose(&(v887_5),&(v888_7))
    };
    drop(v887_5);
    let v887_9: Space = intersect(&(*CONSTANT_2),&(v887_2));
    drop(v887_2);
    let v887_10: Space = if has_head(&(v887_9)) { singleton(&[]) } else { Space::new() };
    drop(v887_9);
    let v887_11: Space = compose(&(v887_10),&(v886_9_tail));
    drop(v887_10);
    let v892_6: Path = concat_path(&(*p0),&(v886_9_head));
    let v887_12: Space = wrap(&(v887_11),&(v892_6));
    drop(v887_11);
    let v887_13: Space = wrap(&(v887_12),&(*p1));
    drop(v887_12);
    let v887_14: Space = unite(&(v887_8),&(v887_13));
    drop(v887_13);
    v886_9.join_into((v887_14).clone());
  }
  drop(v886_9_cursor);
  (v886_9).clone()
}

fn routine_94(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v893_12 = Space::new();
  let mut v893_12_cursor = (*s0).read_zipper();
  for v893_12_byte in v893_12_cursor.child_mask().iter() {
    v893_12_cursor.descend_to_byte(v893_12_byte);
    let v893_12_tail = v893_12_cursor.make_map();
    v893_12_cursor.ascend(1);
    let v893_12_head = Path::from_slice(&[v893_12_byte]);
    let v894_2: Space = singleton(&(v893_12_head));
    let v894_3: Space = intersect(&(*CONSTANT_2),&(v894_2));
    let v894_4: Space = if has_head(&(v894_3)) { singleton(&[]) } else { Space::new() };
    drop(v894_3);
    let v894_5: Space = subtract(&(*CONSTANT_1),&(v894_4));
    drop(v894_4);
    let v894_8: Space = if (v894_5).is_empty() { Space::new() } else {
      let v895_6: Path = concat_path(&(*p0),&(v893_12_head));
      let mut v895_7 = Space::new();
      let mut v895_7_cursor = (v893_12_tail).read_zipper();
      for v895_7_byte in v895_7_cursor.child_mask().iter() {
        v895_7_cursor.descend_to_byte(v895_7_byte);
        let v895_7_tail = v895_7_cursor.make_map();
        v895_7_cursor.ascend(1);
        let v895_7_head = Path::from_slice(&[v895_7_byte]);
        let v896_2: Space = singleton(&(v895_7_head));
        let v896_3: Space = intersect(&(*CONSTANT_2),&(v896_2));
        let v896_4: Space = if has_head(&(v896_3)) { singleton(&[]) } else { Space::new() };
        drop(v896_3);
        let v896_5: Space = subtract(&(*CONSTANT_1),&(v896_4));
        drop(v896_4);
        let v896_8: Space = if (v896_5).is_empty() { Space::new() } else {
          let v897_6: Path = concat_path(&(v895_6),&(v895_7_head));
          let v897_7: Space = routine_136(c, &(v897_6), &(*p1), &(v895_7_tail));
          compose(&(v896_5),&(v897_7))
        };
        drop(v896_5);
        let v896_9: Space = intersect(&(*CONSTANT_2),&(v896_2));
        drop(v896_2);
        let v896_10: Space = if has_head(&(v896_9)) { singleton(&[]) } else { Space::new() };
        drop(v896_9);
        let v896_12: Space = if (v896_10).is_empty() { Space::new() } else {
          let v898_6: Path = concat_path(&(v895_6),&(v895_7_head));
          let v898_11: Space = routine_137(c, &(v898_6), &(*p1), &(v895_7_tail));
          drop(v898_6);
          compose(&(v896_10),&(v898_11))
        };
        drop(v896_10);
        let v896_13: Space = unite(&(v896_8),&(v896_12));
        v895_7.join_into((v896_13).clone());
      }
      drop(v895_7_cursor);
      compose(&(v894_5),&(v895_7))
    };
    drop(v894_5);
    let v894_9: Space = intersect(&(*CONSTANT_2),&(v894_2));
    drop(v894_2);
    let v894_10: Space = if has_head(&(v894_9)) { singleton(&[]) } else { Space::new() };
    drop(v894_9);
    let v894_12: Space = if (v894_10).is_empty() { Space::new() } else {
      let v899_6: Path = concat_path(&(*p0),&(v893_12_head));
      let mut v899_11 = Space::new();
      let mut v899_11_cursor = (v893_12_tail).read_zipper();
      for v899_11_byte in v899_11_cursor.child_mask().iter() {
        v899_11_cursor.descend_to_byte(v899_11_byte);
        let v899_11_tail = v899_11_cursor.make_map();
        v899_11_cursor.ascend(1);
        let v899_11_head = Path::from_slice(&[v899_11_byte]);
        let v900_2: Space = singleton(&(v899_11_head));
        let v900_3: Space = intersect(&(*CONSTANT_2),&(v900_2));
        let v900_4: Space = if has_head(&(v900_3)) { singleton(&[]) } else { Space::new() };
        drop(v900_3);
        let v900_5: Space = subtract(&(*CONSTANT_1),&(v900_4));
        drop(v900_4);
        let v900_8: Space = if (v900_5).is_empty() { Space::new() } else {
          let v901_6: Path = concat_path(&(v899_6),&(v899_11_head));
          let v901_7: Space = routine_136(c, &(v901_6), &(*p1), &(v899_11_tail));
          compose(&(v900_5),&(v901_7))
        };
        drop(v900_5);
        let v900_9: Space = intersect(&(*CONSTANT_2),&(v900_2));
        drop(v900_2);
        let v900_10: Space = if has_head(&(v900_9)) { singleton(&[]) } else { Space::new() };
        drop(v900_9);
        let v900_12: Space = if (v900_10).is_empty() { Space::new() } else {
          let v902_6: Path = concat_path(&(v899_6),&(v899_11_head));
          let v902_11: Space = routine_50(c, &(v902_6), &(*p1), &(v899_11_tail));
          drop(v902_6);
          compose(&(v900_10),&(v902_11))
        };
        drop(v900_10);
        let v900_13: Space = unite(&(v900_8),&(v900_12));
        v899_11.join_into((v900_13).clone());
      }
      drop(v899_11_cursor);
      drop(v899_6);
      compose(&(v894_10),&(v899_11))
    };
    drop(v894_10);
    let v894_13: Space = unite(&(v894_8),&(v894_12));
    v893_12.join_into((v894_13).clone());
  }
  drop(v893_12_cursor);
  (v893_12).clone()
}

fn routine_95(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v903_9 = Space::new();
  let mut v903_9_cursor = (*s0).read_zipper();
  for v903_9_byte in v903_9_cursor.child_mask().iter() {
    v903_9_cursor.descend_to_byte(v903_9_byte);
    let v903_9_tail = v903_9_cursor.make_map();
    v903_9_cursor.ascend(1);
    let v903_9_head = Path::from_slice(&[v903_9_byte]);
    let v904_2: Space = singleton(&(v903_9_head));
    let v904_3: Space = intersect(&(*CONSTANT_2),&(v904_2));
    let v904_4: Space = if has_head(&(v904_3)) { singleton(&[]) } else { Space::new() };
    drop(v904_3);
    let v904_5: Space = subtract(&(*CONSTANT_1),&(v904_4));
    drop(v904_4);
    let v904_8: Space = if (v904_5).is_empty() { Space::new() } else {
      let v905_6: Path = concat_path(&(*p0),&(v903_9_head));
      let mut v905_7 = Space::new();
      let mut v905_7_cursor = (v903_9_tail).read_zipper();
      for v905_7_byte in v905_7_cursor.child_mask().iter() {
        v905_7_cursor.descend_to_byte(v905_7_byte);
        let v905_7_tail = v905_7_cursor.make_map();
        v905_7_cursor.ascend(1);
        let v905_7_head = Path::from_slice(&[v905_7_byte]);
        let v906_2: Space = singleton(&(v905_7_head));
        let v906_3: Space = intersect(&(*CONSTANT_2),&(v906_2));
        let v906_4: Space = if has_head(&(v906_3)) { singleton(&[]) } else { Space::new() };
        drop(v906_3);
        let v906_5: Space = subtract(&(*CONSTANT_1),&(v906_4));
        drop(v906_4);
        let v906_8: Space = if (v906_5).is_empty() { Space::new() } else {
          let v907_6: Path = concat_path(&(v905_6),&(v905_7_head));
          let v907_7: Space = routine_136(c, &(v907_6), &(*p1), &(v905_7_tail));
          compose(&(v906_5),&(v907_7))
        };
        drop(v906_5);
        let v906_9: Space = intersect(&(*CONSTANT_2),&(v906_2));
        drop(v906_2);
        let v906_10: Space = if has_head(&(v906_9)) { singleton(&[]) } else { Space::new() };
        drop(v906_9);
        let v906_12: Space = if (v906_10).is_empty() { Space::new() } else {
          let v908_6: Path = concat_path(&(v905_6),&(v905_7_head));
          let v908_11: Space = routine_137(c, &(v908_6), &(*p1), &(v905_7_tail));
          drop(v908_6);
          compose(&(v906_10),&(v908_11))
        };
        drop(v906_10);
        let v906_13: Space = unite(&(v906_8),&(v906_12));
        v905_7.join_into((v906_13).clone());
      }
      drop(v905_7_cursor);
      compose(&(v904_5),&(v905_7))
    };
    drop(v904_5);
    let v904_9: Space = intersect(&(*CONSTANT_2),&(v904_2));
    drop(v904_2);
    let v904_10: Space = if has_head(&(v904_9)) { singleton(&[]) } else { Space::new() };
    drop(v904_9);
    let v904_11: Space = compose(&(v904_10),&(v903_9_tail));
    drop(v904_10);
    let v909_6: Path = concat_path(&(*p0),&(v903_9_head));
    let v904_12: Space = wrap(&(v904_11),&(v909_6));
    drop(v904_11);
    let v904_13: Space = wrap(&(v904_12),&(*p1));
    drop(v904_12);
    let v904_14: Space = unite(&(v904_8),&(v904_13));
    drop(v904_13);
    v903_9.join_into((v904_14).clone());
  }
  drop(v903_9_cursor);
  (v903_9).clone()
}

fn routine_96(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v910_6 = Space::new();
  let mut v910_6_cursor = (*s0).read_zipper();
  for v910_6_byte in v910_6_cursor.child_mask().iter() {
    v910_6_cursor.descend_to_byte(v910_6_byte);
    let v910_6_tail = v910_6_cursor.make_map();
    v910_6_cursor.ascend(1);
    let v910_6_head = Path::from_slice(&[v910_6_byte]);
    let v911_2: Space = singleton(&(v910_6_head));
    let v911_3: Space = intersect(&(*CONSTANT_2),&(v911_2));
    let v911_4: Space = if has_head(&(v911_3)) { singleton(&[]) } else { Space::new() };
    drop(v911_3);
    let v911_5: Space = subtract(&(*CONSTANT_1),&(v911_4));
    drop(v911_4);
    let mut v911_6 = Space::new();
    let mut v911_6_cursor = (v910_6_tail).read_zipper();
    for v911_6_byte in v911_6_cursor.child_mask().iter() {
      v911_6_cursor.descend_to_byte(v911_6_byte);
      let v911_6_tail = v911_6_cursor.make_map();
      v911_6_cursor.ascend(1);
      let v911_6_head = Path::from_slice(&[v911_6_byte]);
      let v912_2: Space = Space::new();
      v911_6.join_into((v912_2).clone());
    }
    drop(v911_6_cursor);
    let v911_7: Space = compose(&(v911_5),&(v911_6));
    drop(v911_5);
    drop(v911_6);
    let v911_8: Space = intersect(&(*CONSTANT_2),&(v911_2));
    drop(v911_2);
    let v911_9: Space = if has_head(&(v911_8)) { singleton(&[]) } else { Space::new() };
    drop(v911_8);
    let v911_12: Space = if (v911_9).is_empty() { Space::new() } else {
      let v913_10: Path = concat_path(&(*p0),&(v910_6_head));
      let mut v913_11 = Space::new();
      let mut v913_11_cursor = (v910_6_tail).read_zipper();
      for v913_11_byte in v913_11_cursor.child_mask().iter() {
        v913_11_cursor.descend_to_byte(v913_11_byte);
        let v913_11_tail = v913_11_cursor.make_map();
        v913_11_cursor.ascend(1);
        let v913_11_head = Path::from_slice(&[v913_11_byte]);
        let v914_2: Space = singleton(&(v913_11_head));
        let v914_3: Space = intersect(&(*CONSTANT_2),&(v914_2));
        drop(v914_2);
        let v914_4: Space = if has_head(&(v914_3)) { singleton(&[]) } else { Space::new() };
        drop(v914_3);
        let v914_7: Space = if (v914_4).is_empty() { Space::new() } else {
          let v915_5: Path = concat_path(&(v913_10),&(v913_11_head));
          let v915_6: Space = routine_3(c, &(v915_5), &(v913_11_tail));
          drop(v915_5);
          compose(&(v914_4),&(v915_6))
        };
        drop(v914_4);
        v913_11.join_into((v914_7).clone());
      }
      drop(v913_11_cursor);
      drop(v913_10);
      compose(&(v911_9),&(v913_11))
    };
    drop(v911_9);
    let v911_13: Space = unite(&(v911_7),&(v911_12));
    drop(v911_7);
    v910_6.join_into((v911_13).clone());
  }
  drop(v910_6_cursor);
  (v910_6).clone()
}

fn routine_97(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v916_8 = Space::new();
  let mut v916_8_cursor = (*s0).read_zipper();
  for v916_8_byte in v916_8_cursor.child_mask().iter() {
    v916_8_cursor.descend_to_byte(v916_8_byte);
    let v916_8_tail = v916_8_cursor.make_map();
    v916_8_cursor.ascend(1);
    let v916_8_head = Path::from_slice(&[v916_8_byte]);
    let v917_2: Space = singleton(&(v916_8_head));
    let v917_3: Space = intersect(&(*CONSTANT_2),&(v917_2));
    let v917_4: Space = if has_head(&(v917_3)) { singleton(&[]) } else { Space::new() };
    drop(v917_3);
    let v917_5: Space = subtract(&(*CONSTANT_1),&(v917_4));
    drop(v917_4);
    let mut v917_6 = Space::new();
    let mut v917_6_cursor = (v916_8_tail).read_zipper();
    for v917_6_byte in v917_6_cursor.child_mask().iter() {
      v917_6_cursor.descend_to_byte(v917_6_byte);
      let v917_6_tail = v917_6_cursor.make_map();
      v917_6_cursor.ascend(1);
      let v917_6_head = Path::from_slice(&[v917_6_byte]);
      let v918_2: Space = Space::new();
      v917_6.join_into((v918_2).clone());
    }
    drop(v917_6_cursor);
    let v917_7: Space = compose(&(v917_5),&(v917_6));
    drop(v917_5);
    drop(v917_6);
    let v917_8: Space = intersect(&(*CONSTANT_2),&(v917_2));
    drop(v917_2);
    let v917_9: Space = if has_head(&(v917_8)) { singleton(&[]) } else { Space::new() };
    drop(v917_8);
    let v917_12: Space = if (v917_9).is_empty() { Space::new() } else {
      let v919_10: Path = concat_path(&(*p0),&(v916_8_head));
      let mut v919_11 = Space::new();
      let mut v919_11_cursor = (v916_8_tail).read_zipper();
      for v919_11_byte in v919_11_cursor.child_mask().iter() {
        v919_11_cursor.descend_to_byte(v919_11_byte);
        let v919_11_tail = v919_11_cursor.make_map();
        v919_11_cursor.ascend(1);
        let v919_11_head = Path::from_slice(&[v919_11_byte]);
        let v920_2: Space = singleton(&(v919_11_head));
        let v920_3: Space = intersect(&(*CONSTANT_2),&(v920_2));
        let v920_4: Space = if has_head(&(v920_3)) { singleton(&[]) } else { Space::new() };
        drop(v920_3);
        let v920_5: Space = subtract(&(*CONSTANT_1),&(v920_4));
        drop(v920_4);
        let v920_7: Space = if (v920_5).is_empty() { Space::new() } else {
          let v921_6: Space = routine_18(c, &(v919_11_head), &(v919_10), &(v919_11_tail));
          compose(&(v920_5),&(v921_6))
        };
        drop(v920_5);
        let v920_8: Space = intersect(&(*CONSTANT_2),&(v920_2));
        drop(v920_2);
        let v920_9: Space = if has_head(&(v920_8)) { singleton(&[]) } else { Space::new() };
        drop(v920_8);
        let v920_11: Space = if (v920_9).is_empty() { Space::new() } else {
          let v922_10: Space = routine_19(c, &(v919_11_head), &(v919_10), &(v919_11_tail));
          compose(&(v920_9),&(v922_10))
        };
        drop(v920_9);
        let v920_12: Space = unite(&(v920_7),&(v920_11));
        v919_11.join_into((v920_12).clone());
      }
      drop(v919_11_cursor);
      drop(v919_10);
      compose(&(v917_9),&(v919_11))
    };
    drop(v917_9);
    let v917_13: Space = unite(&(v917_7),&(v917_12));
    drop(v917_7);
    v916_8.join_into((v917_13).clone());
  }
  drop(v916_8_cursor);
  (v916_8).clone()
}

fn routine_98(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v923_12 = Space::new();
  let mut v923_12_cursor = (*s0).read_zipper();
  for v923_12_byte in v923_12_cursor.child_mask().iter() {
    v923_12_cursor.descend_to_byte(v923_12_byte);
    let v923_12_tail = v923_12_cursor.make_map();
    v923_12_cursor.ascend(1);
    let v923_12_head = Path::from_slice(&[v923_12_byte]);
    let v924_2: Space = singleton(&(v923_12_head));
    let v924_3: Space = intersect(&(*CONSTANT_2),&(v924_2));
    let v924_4: Space = if has_head(&(v924_3)) { singleton(&[]) } else { Space::new() };
    drop(v924_3);
    let v924_5: Space = subtract(&(*CONSTANT_1),&(v924_4));
    drop(v924_4);
    let v924_8: Space = if (v924_5).is_empty() { Space::new() } else {
      let v925_6: Path = concat_path(&(*p0),&(v923_12_head));
      let mut v925_7 = Space::new();
      let mut v925_7_cursor = (v923_12_tail).read_zipper();
      for v925_7_byte in v925_7_cursor.child_mask().iter() {
        v925_7_cursor.descend_to_byte(v925_7_byte);
        let v925_7_tail = v925_7_cursor.make_map();
        v925_7_cursor.ascend(1);
        let v925_7_head = Path::from_slice(&[v925_7_byte]);
        let v926_2: Space = singleton(&(v925_7_head));
        let v926_3: Space = intersect(&(*CONSTANT_2),&(v926_2));
        let v926_4: Space = if has_head(&(v926_3)) { singleton(&[]) } else { Space::new() };
        drop(v926_3);
        let v926_5: Space = subtract(&(*CONSTANT_1),&(v926_4));
        drop(v926_4);
        let v926_8: Space = if (v926_5).is_empty() { Space::new() } else {
          let v927_6: Path = concat_path(&(v925_6),&(v925_7_head));
          let v927_7: Space = routine_138(c, &(v927_6), &(*p1), &(v925_7_tail));
          compose(&(v926_5),&(v927_7))
        };
        drop(v926_5);
        let v926_9: Space = intersect(&(*CONSTANT_2),&(v926_2));
        drop(v926_2);
        let v926_10: Space = if has_head(&(v926_9)) { singleton(&[]) } else { Space::new() };
        drop(v926_9);
        let v926_12: Space = if (v926_10).is_empty() { Space::new() } else {
          let v928_6: Path = concat_path(&(v925_6),&(v925_7_head));
          let v928_11: Space = routine_139(c, &(v928_6), &(*p1), &(v925_7_tail));
          drop(v928_6);
          compose(&(v926_10),&(v928_11))
        };
        drop(v926_10);
        let v926_13: Space = unite(&(v926_8),&(v926_12));
        v925_7.join_into((v926_13).clone());
      }
      drop(v925_7_cursor);
      compose(&(v924_5),&(v925_7))
    };
    drop(v924_5);
    let v924_9: Space = intersect(&(*CONSTANT_2),&(v924_2));
    drop(v924_2);
    let v924_10: Space = if has_head(&(v924_9)) { singleton(&[]) } else { Space::new() };
    drop(v924_9);
    let v924_12: Space = if (v924_10).is_empty() { Space::new() } else {
      let v929_6: Path = concat_path(&(*p0),&(v923_12_head));
      let mut v929_11 = Space::new();
      let mut v929_11_cursor = (v923_12_tail).read_zipper();
      for v929_11_byte in v929_11_cursor.child_mask().iter() {
        v929_11_cursor.descend_to_byte(v929_11_byte);
        let v929_11_tail = v929_11_cursor.make_map();
        v929_11_cursor.ascend(1);
        let v929_11_head = Path::from_slice(&[v929_11_byte]);
        let v930_2: Space = singleton(&(v929_11_head));
        let v930_3: Space = intersect(&(*CONSTANT_2),&(v930_2));
        let v930_4: Space = if has_head(&(v930_3)) { singleton(&[]) } else { Space::new() };
        drop(v930_3);
        let v930_5: Space = subtract(&(*CONSTANT_1),&(v930_4));
        drop(v930_4);
        let v930_8: Space = if (v930_5).is_empty() { Space::new() } else {
          let v931_6: Path = concat_path(&(v929_6),&(v929_11_head));
          let v931_7: Space = routine_138(c, &(v931_6), &(*p1), &(v929_11_tail));
          compose(&(v930_5),&(v931_7))
        };
        drop(v930_5);
        let v930_9: Space = intersect(&(*CONSTANT_2),&(v930_2));
        drop(v930_2);
        let v930_10: Space = if has_head(&(v930_9)) { singleton(&[]) } else { Space::new() };
        drop(v930_9);
        let v930_12: Space = if (v930_10).is_empty() { Space::new() } else {
          let v932_6: Path = concat_path(&(v929_6),&(v929_11_head));
          let v932_11: Space = routine_22(c, &(v932_6), &(*p1), &(v929_11_tail));
          drop(v932_6);
          compose(&(v930_10),&(v932_11))
        };
        drop(v930_10);
        let v930_13: Space = unite(&(v930_8),&(v930_12));
        v929_11.join_into((v930_13).clone());
      }
      drop(v929_11_cursor);
      drop(v929_6);
      compose(&(v924_10),&(v929_11))
    };
    drop(v924_10);
    let v924_13: Space = unite(&(v924_8),&(v924_12));
    v923_12.join_into((v924_13).clone());
  }
  drop(v923_12_cursor);
  (v923_12).clone()
}

fn routine_99(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v933_10 = Space::new();
  let mut v933_10_cursor = (*s0).read_zipper();
  for v933_10_byte in v933_10_cursor.child_mask().iter() {
    v933_10_cursor.descend_to_byte(v933_10_byte);
    let v933_10_tail = v933_10_cursor.make_map();
    v933_10_cursor.ascend(1);
    let v933_10_head = Path::from_slice(&[v933_10_byte]);
    let v934_2: Space = singleton(&(v933_10_head));
    let v934_3: Space = intersect(&(*CONSTANT_2),&(v934_2));
    let v934_4: Space = if has_head(&(v934_3)) { singleton(&[]) } else { Space::new() };
    drop(v934_3);
    let v934_5: Space = compose(&(v934_4),&(v933_10_tail));
    drop(v934_4);
    let v935_6: Path = concat_path(&(*p0),&(v933_10_head));
    let v934_7: Space = wrap(&(v934_5),&(v935_6));
    drop(v934_5);
    let v934_8: Space = wrap(&(v934_7),&(*p1));
    drop(v934_7);
    let v934_9: Space = wrap(&(v934_8),&(*CONSTANT_5));
    drop(v934_8);
    let v934_10: Space = intersect(&(*CONSTANT_2),&(v934_2));
    drop(v934_2);
    let v934_11: Space = if has_head(&(v934_10)) { singleton(&[]) } else { Space::new() };
    drop(v934_10);
    let v934_12: Space = subtract(&(*CONSTANT_1),&(v934_11));
    drop(v934_11);
    let v934_14: Space = if (v934_12).is_empty() { Space::new() } else {
      let mut v936_13 = Space::new();
      let mut v936_13_cursor = (v933_10_tail).read_zipper();
      for v936_13_byte in v936_13_cursor.child_mask().iter() {
        v936_13_cursor.descend_to_byte(v936_13_byte);
        let v936_13_tail = v936_13_cursor.make_map();
        v936_13_cursor.ascend(1);
        let v936_13_head = Path::from_slice(&[v936_13_byte]);
        let v937_2: Space = singleton(&(v936_13_head));
        let v937_3: Space = intersect(&(*CONSTANT_2),&(v937_2));
        let v937_4: Space = if has_head(&(v937_3)) { singleton(&[]) } else { Space::new() };
        drop(v937_3);
        let v937_5: Space = subtract(&(*CONSTANT_1),&(v937_4));
        drop(v937_4);
        let v937_8: Space = if (v937_5).is_empty() { Space::new() } else {
          let v938_6: Path = concat_path(&(v935_6),&(v936_13_head));
          let v938_7: Space = routine_138(c, &(v938_6), &(*p1), &(v936_13_tail));
          compose(&(v937_5),&(v938_7))
        };
        drop(v937_5);
        let v937_9: Space = intersect(&(*CONSTANT_2),&(v937_2));
        drop(v937_2);
        let v937_10: Space = if has_head(&(v937_9)) { singleton(&[]) } else { Space::new() };
        drop(v937_9);
        let v937_12: Space = if (v937_10).is_empty() { Space::new() } else {
          let v939_6: Path = concat_path(&(v935_6),&(v936_13_head));
          let v939_11: Space = routine_139(c, &(v939_6), &(*p1), &(v936_13_tail));
          drop(v939_6);
          compose(&(v937_10),&(v939_11))
        };
        drop(v937_10);
        let v937_13: Space = unite(&(v937_8),&(v937_12));
        v936_13.join_into((v937_13).clone());
      }
      drop(v936_13_cursor);
      compose(&(v934_12),&(v936_13))
    };
    drop(v934_12);
    let v934_15: Space = unite(&(v934_9),&(v934_14));
    drop(v934_9);
    v933_10.join_into((v934_15).clone());
  }
  drop(v933_10_cursor);
  (v933_10).clone()
}

fn routine_100(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v940_12 = Space::new();
  let mut v940_12_cursor = (*s0).read_zipper();
  for v940_12_byte in v940_12_cursor.child_mask().iter() {
    v940_12_cursor.descend_to_byte(v940_12_byte);
    let v940_12_tail = v940_12_cursor.make_map();
    v940_12_cursor.ascend(1);
    let v940_12_head = Path::from_slice(&[v940_12_byte]);
    let v941_2: Space = singleton(&(v940_12_head));
    let v941_3: Space = intersect(&(*CONSTANT_2),&(v941_2));
    let v941_4: Space = if has_head(&(v941_3)) { singleton(&[]) } else { Space::new() };
    drop(v941_3);
    let v941_5: Space = subtract(&(*CONSTANT_1),&(v941_4));
    drop(v941_4);
    let v941_8: Space = if (v941_5).is_empty() { Space::new() } else {
      let v942_6: Path = concat_path(&(*p0),&(v940_12_head));
      let mut v942_7 = Space::new();
      let mut v942_7_cursor = (v940_12_tail).read_zipper();
      for v942_7_byte in v942_7_cursor.child_mask().iter() {
        v942_7_cursor.descend_to_byte(v942_7_byte);
        let v942_7_tail = v942_7_cursor.make_map();
        v942_7_cursor.ascend(1);
        let v942_7_head = Path::from_slice(&[v942_7_byte]);
        let v943_2: Space = singleton(&(v942_7_head));
        let v943_3: Space = intersect(&(*CONSTANT_2),&(v943_2));
        let v943_4: Space = if has_head(&(v943_3)) { singleton(&[]) } else { Space::new() };
        drop(v943_3);
        let v943_5: Space = subtract(&(*CONSTANT_1),&(v943_4));
        drop(v943_4);
        let v943_8: Space = if (v943_5).is_empty() { Space::new() } else {
          let v944_6: Path = concat_path(&(v942_6),&(v942_7_head));
          let v944_7: Space = routine_140(c, &(v944_6), &(*p1), &(v942_7_tail));
          compose(&(v943_5),&(v944_7))
        };
        drop(v943_5);
        let v943_9: Space = intersect(&(*CONSTANT_2),&(v943_2));
        drop(v943_2);
        let v943_10: Space = if has_head(&(v943_9)) { singleton(&[]) } else { Space::new() };
        drop(v943_9);
        let v943_12: Space = if (v943_10).is_empty() { Space::new() } else {
          let v945_6: Path = concat_path(&(v942_6),&(v942_7_head));
          let v945_11: Space = routine_141(c, &(v945_6), &(*p1), &(v942_7_tail));
          drop(v945_6);
          compose(&(v943_10),&(v945_11))
        };
        drop(v943_10);
        let v943_13: Space = unite(&(v943_8),&(v943_12));
        v942_7.join_into((v943_13).clone());
      }
      drop(v942_7_cursor);
      compose(&(v941_5),&(v942_7))
    };
    drop(v941_5);
    let v941_9: Space = intersect(&(*CONSTANT_2),&(v941_2));
    drop(v941_2);
    let v941_10: Space = if has_head(&(v941_9)) { singleton(&[]) } else { Space::new() };
    drop(v941_9);
    let v941_12: Space = if (v941_10).is_empty() { Space::new() } else {
      let v946_6: Path = concat_path(&(*p0),&(v940_12_head));
      let mut v946_11 = Space::new();
      let mut v946_11_cursor = (v940_12_tail).read_zipper();
      for v946_11_byte in v946_11_cursor.child_mask().iter() {
        v946_11_cursor.descend_to_byte(v946_11_byte);
        let v946_11_tail = v946_11_cursor.make_map();
        v946_11_cursor.ascend(1);
        let v946_11_head = Path::from_slice(&[v946_11_byte]);
        let v947_2: Space = singleton(&(v946_11_head));
        let v947_3: Space = intersect(&(*CONSTANT_2),&(v947_2));
        let v947_4: Space = if has_head(&(v947_3)) { singleton(&[]) } else { Space::new() };
        drop(v947_3);
        let v947_5: Space = subtract(&(*CONSTANT_1),&(v947_4));
        drop(v947_4);
        let v947_8: Space = if (v947_5).is_empty() { Space::new() } else {
          let v948_6: Path = concat_path(&(v946_6),&(v946_11_head));
          let v948_7: Space = routine_140(c, &(v948_6), &(*p1), &(v946_11_tail));
          compose(&(v947_5),&(v948_7))
        };
        drop(v947_5);
        let v947_9: Space = intersect(&(*CONSTANT_2),&(v947_2));
        drop(v947_2);
        let v947_10: Space = if has_head(&(v947_9)) { singleton(&[]) } else { Space::new() };
        drop(v947_9);
        let v947_12: Space = if (v947_10).is_empty() { Space::new() } else {
          let v949_6: Path = concat_path(&(v946_6),&(v946_11_head));
          let v949_11: Space = routine_22(c, &(v949_6), &(*p1), &(v946_11_tail));
          drop(v949_6);
          compose(&(v947_10),&(v949_11))
        };
        drop(v947_10);
        let v947_13: Space = unite(&(v947_8),&(v947_12));
        v946_11.join_into((v947_13).clone());
      }
      drop(v946_11_cursor);
      drop(v946_6);
      compose(&(v941_10),&(v946_11))
    };
    drop(v941_10);
    let v941_13: Space = unite(&(v941_8),&(v941_12));
    v940_12.join_into((v941_13).clone());
  }
  drop(v940_12_cursor);
  (v940_12).clone()
}

fn routine_101(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v950_10 = Space::new();
  let mut v950_10_cursor = (*s0).read_zipper();
  for v950_10_byte in v950_10_cursor.child_mask().iter() {
    v950_10_cursor.descend_to_byte(v950_10_byte);
    let v950_10_tail = v950_10_cursor.make_map();
    v950_10_cursor.ascend(1);
    let v950_10_head = Path::from_slice(&[v950_10_byte]);
    let v951_2: Space = singleton(&(v950_10_head));
    let v951_3: Space = intersect(&(*CONSTANT_2),&(v951_2));
    let v951_4: Space = if has_head(&(v951_3)) { singleton(&[]) } else { Space::new() };
    drop(v951_3);
    let v951_5: Space = compose(&(v951_4),&(v950_10_tail));
    drop(v951_4);
    let v952_6: Path = concat_path(&(*p0),&(v950_10_head));
    let v951_7: Space = wrap(&(v951_5),&(v952_6));
    drop(v951_5);
    let v951_8: Space = wrap(&(v951_7),&(*p1));
    drop(v951_7);
    let v951_9: Space = wrap(&(v951_8),&(*CONSTANT_5));
    drop(v951_8);
    let v951_10: Space = intersect(&(*CONSTANT_2),&(v951_2));
    drop(v951_2);
    let v951_11: Space = if has_head(&(v951_10)) { singleton(&[]) } else { Space::new() };
    drop(v951_10);
    let v951_12: Space = subtract(&(*CONSTANT_1),&(v951_11));
    drop(v951_11);
    let v951_14: Space = if (v951_12).is_empty() { Space::new() } else {
      let mut v953_13 = Space::new();
      let mut v953_13_cursor = (v950_10_tail).read_zipper();
      for v953_13_byte in v953_13_cursor.child_mask().iter() {
        v953_13_cursor.descend_to_byte(v953_13_byte);
        let v953_13_tail = v953_13_cursor.make_map();
        v953_13_cursor.ascend(1);
        let v953_13_head = Path::from_slice(&[v953_13_byte]);
        let v954_2: Space = singleton(&(v953_13_head));
        let v954_3: Space = intersect(&(*CONSTANT_2),&(v954_2));
        let v954_4: Space = if has_head(&(v954_3)) { singleton(&[]) } else { Space::new() };
        drop(v954_3);
        let v954_5: Space = subtract(&(*CONSTANT_1),&(v954_4));
        drop(v954_4);
        let v954_8: Space = if (v954_5).is_empty() { Space::new() } else {
          let v955_6: Path = concat_path(&(v952_6),&(v953_13_head));
          let v955_7: Space = routine_140(c, &(v955_6), &(*p1), &(v953_13_tail));
          compose(&(v954_5),&(v955_7))
        };
        drop(v954_5);
        let v954_9: Space = intersect(&(*CONSTANT_2),&(v954_2));
        drop(v954_2);
        let v954_10: Space = if has_head(&(v954_9)) { singleton(&[]) } else { Space::new() };
        drop(v954_9);
        let v954_12: Space = if (v954_10).is_empty() { Space::new() } else {
          let v956_6: Path = concat_path(&(v952_6),&(v953_13_head));
          let v956_11: Space = routine_141(c, &(v956_6), &(*p1), &(v953_13_tail));
          drop(v956_6);
          compose(&(v954_10),&(v956_11))
        };
        drop(v954_10);
        let v954_13: Space = unite(&(v954_8),&(v954_12));
        v953_13.join_into((v954_13).clone());
      }
      drop(v953_13_cursor);
      compose(&(v951_12),&(v953_13))
    };
    drop(v951_12);
    let v951_15: Space = unite(&(v951_9),&(v951_14));
    drop(v951_9);
    v950_10.join_into((v951_15).clone());
  }
  drop(v950_10_cursor);
  (v950_10).clone()
}

fn routine_102(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v957_7 = Space::new();
  let mut v957_7_cursor = (*s0).read_zipper();
  for v957_7_byte in v957_7_cursor.child_mask().iter() {
    v957_7_cursor.descend_to_byte(v957_7_byte);
    let v957_7_tail = v957_7_cursor.make_map();
    v957_7_cursor.ascend(1);
    let v957_7_head = Path::from_slice(&[v957_7_byte]);
    let v958_2: Space = singleton(&(v957_7_head));
    let v958_3: Space = intersect(&(*CONSTANT_2),&(v958_2));
    let v958_4: Space = if has_head(&(v958_3)) { singleton(&[]) } else { Space::new() };
    drop(v958_3);
    let v958_5: Space = subtract(&(*CONSTANT_1),&(v958_4));
    drop(v958_4);
    let mut v958_6 = Space::new();
    let mut v958_6_cursor = (v957_7_tail).read_zipper();
    for v958_6_byte in v958_6_cursor.child_mask().iter() {
      v958_6_cursor.descend_to_byte(v958_6_byte);
      let v958_6_tail = v958_6_cursor.make_map();
      v958_6_cursor.ascend(1);
      let v958_6_head = Path::from_slice(&[v958_6_byte]);
      let v959_2: Space = Space::new();
      v958_6.join_into((v959_2).clone());
    }
    drop(v958_6_cursor);
    let v958_7: Space = compose(&(v958_5),&(v958_6));
    drop(v958_5);
    drop(v958_6);
    let v958_8: Space = intersect(&(*CONSTANT_2),&(v958_2));
    drop(v958_2);
    let v958_9: Space = if has_head(&(v958_8)) { singleton(&[]) } else { Space::new() };
    drop(v958_8);
    let v958_12: Space = if (v958_9).is_empty() { Space::new() } else {
      let v960_10: Path = concat_path(&(*p0),&(v957_7_head));
      let mut v960_11 = Space::new();
      let mut v960_11_cursor = (v957_7_tail).read_zipper();
      for v960_11_byte in v960_11_cursor.child_mask().iter() {
        v960_11_cursor.descend_to_byte(v960_11_byte);
        let v960_11_tail = v960_11_cursor.make_map();
        v960_11_cursor.ascend(1);
        let v960_11_head = Path::from_slice(&[v960_11_byte]);
        let v961_2: Space = singleton(&(v960_11_head));
        let v961_3: Space = intersect(&(*CONSTANT_2),&(v961_2));
        drop(v961_2);
        let v961_4: Space = if has_head(&(v961_3)) { singleton(&[]) } else { Space::new() };
        drop(v961_3);
        let v961_7: Space = if (v961_4).is_empty() { Space::new() } else {
          let v962_5: Path = concat_path(&(v960_10),&(v960_11_head));
          let v962_6: Space = routine_6(c, &(v962_5), &(v960_11_tail), &(*s1));
          drop(v962_5);
          compose(&(v961_4),&(v962_6))
        };
        drop(v961_4);
        v960_11.join_into((v961_7).clone());
      }
      drop(v960_11_cursor);
      drop(v960_10);
      compose(&(v958_9),&(v960_11))
    };
    drop(v958_9);
    let v958_13: Space = unite(&(v958_7),&(v958_12));
    drop(v958_7);
    v957_7.join_into((v958_13).clone());
  }
  drop(v957_7_cursor);
  (v957_7).clone()
}

fn routine_103(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v963_9 = Space::new();
  let mut v963_9_cursor = (*s0).read_zipper();
  for v963_9_byte in v963_9_cursor.child_mask().iter() {
    v963_9_cursor.descend_to_byte(v963_9_byte);
    let v963_9_tail = v963_9_cursor.make_map();
    v963_9_cursor.ascend(1);
    let v963_9_head = Path::from_slice(&[v963_9_byte]);
    let v964_2: Space = singleton(&(v963_9_head));
    let v964_3: Space = intersect(&(*CONSTANT_2),&(v964_2));
    let v964_4: Space = if has_head(&(v964_3)) { singleton(&[]) } else { Space::new() };
    drop(v964_3);
    let v964_5: Space = subtract(&(*CONSTANT_1),&(v964_4));
    drop(v964_4);
    let mut v964_6 = Space::new();
    let mut v964_6_cursor = (v963_9_tail).read_zipper();
    for v964_6_byte in v964_6_cursor.child_mask().iter() {
      v964_6_cursor.descend_to_byte(v964_6_byte);
      let v964_6_tail = v964_6_cursor.make_map();
      v964_6_cursor.ascend(1);
      let v964_6_head = Path::from_slice(&[v964_6_byte]);
      let v965_2: Space = Space::new();
      v964_6.join_into((v965_2).clone());
    }
    drop(v964_6_cursor);
    let v964_7: Space = compose(&(v964_5),&(v964_6));
    drop(v964_5);
    drop(v964_6);
    let v964_8: Space = intersect(&(*CONSTANT_2),&(v964_2));
    drop(v964_2);
    let v964_9: Space = if has_head(&(v964_8)) { singleton(&[]) } else { Space::new() };
    drop(v964_8);
    let v964_12: Space = if (v964_9).is_empty() { Space::new() } else {
      let v966_10: Path = concat_path(&(*p0),&(v963_9_head));
      let mut v966_11 = Space::new();
      let mut v966_11_cursor = (v963_9_tail).read_zipper();
      for v966_11_byte in v966_11_cursor.child_mask().iter() {
        v966_11_cursor.descend_to_byte(v966_11_byte);
        let v966_11_tail = v966_11_cursor.make_map();
        v966_11_cursor.ascend(1);
        let v966_11_head = Path::from_slice(&[v966_11_byte]);
        let v967_2: Space = singleton(&(v966_11_head));
        let v967_3: Space = intersect(&(*CONSTANT_2),&(v967_2));
        let v967_4: Space = if has_head(&(v967_3)) { singleton(&[]) } else { Space::new() };
        drop(v967_3);
        let v967_5: Space = subtract(&(*CONSTANT_1),&(v967_4));
        drop(v967_4);
        let v967_7: Space = if (v967_5).is_empty() { Space::new() } else {
          let v968_6: Space = routine_25(c, &(v966_11_head), &(v966_10), &(v966_11_tail), &(*s1));
          compose(&(v967_5),&(v968_6))
        };
        drop(v967_5);
        let v967_8: Space = intersect(&(*CONSTANT_2),&(v967_2));
        drop(v967_2);
        let v967_9: Space = if has_head(&(v967_8)) { singleton(&[]) } else { Space::new() };
        drop(v967_8);
        let v967_11: Space = if (v967_9).is_empty() { Space::new() } else {
          let v969_10: Space = routine_26(c, &(v966_11_head), &(v966_10), &(v966_11_tail), &(*s1));
          compose(&(v967_9),&(v969_10))
        };
        drop(v967_9);
        let v967_12: Space = unite(&(v967_7),&(v967_11));
        v966_11.join_into((v967_12).clone());
      }
      drop(v966_11_cursor);
      drop(v966_10);
      compose(&(v964_9),&(v966_11))
    };
    drop(v964_9);
    let v964_13: Space = unite(&(v964_7),&(v964_12));
    drop(v964_7);
    v963_9.join_into((v964_13).clone());
  }
  drop(v963_9_cursor);
  (v963_9).clone()
}

fn routine_104(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v970_13 = Space::new();
  let mut v970_13_cursor = (*s0).read_zipper();
  for v970_13_byte in v970_13_cursor.child_mask().iter() {
    v970_13_cursor.descend_to_byte(v970_13_byte);
    let v970_13_tail = v970_13_cursor.make_map();
    v970_13_cursor.ascend(1);
    let v970_13_head = Path::from_slice(&[v970_13_byte]);
    let v971_2: Space = singleton(&(v970_13_head));
    let v971_3: Space = intersect(&(*CONSTANT_2),&(v971_2));
    let v971_4: Space = if has_head(&(v971_3)) { singleton(&[]) } else { Space::new() };
    drop(v971_3);
    let v971_5: Space = subtract(&(*CONSTANT_1),&(v971_4));
    drop(v971_4);
    let v971_8: Space = if (v971_5).is_empty() { Space::new() } else {
      let v972_6: Path = concat_path(&(*p0),&(v970_13_head));
      let mut v972_7 = Space::new();
      let mut v972_7_cursor = (v970_13_tail).read_zipper();
      for v972_7_byte in v972_7_cursor.child_mask().iter() {
        v972_7_cursor.descend_to_byte(v972_7_byte);
        let v972_7_tail = v972_7_cursor.make_map();
        v972_7_cursor.ascend(1);
        let v972_7_head = Path::from_slice(&[v972_7_byte]);
        let v973_2: Space = singleton(&(v972_7_head));
        let v973_3: Space = intersect(&(*CONSTANT_2),&(v973_2));
        let v973_4: Space = if has_head(&(v973_3)) { singleton(&[]) } else { Space::new() };
        drop(v973_3);
        let v973_5: Space = subtract(&(*CONSTANT_1),&(v973_4));
        drop(v973_4);
        let v973_8: Space = if (v973_5).is_empty() { Space::new() } else {
          let v974_6: Path = concat_path(&(v972_6),&(v972_7_head));
          let v974_7: Space = routine_142(c, &(v974_6), &(*p1), &(v972_7_tail), &(*s1));
          compose(&(v973_5),&(v974_7))
        };
        drop(v973_5);
        let v973_9: Space = intersect(&(*CONSTANT_2),&(v973_2));
        drop(v973_2);
        let v973_10: Space = if has_head(&(v973_9)) { singleton(&[]) } else { Space::new() };
        drop(v973_9);
        let v973_12: Space = if (v973_10).is_empty() { Space::new() } else {
          let v975_6: Path = concat_path(&(v972_6),&(v972_7_head));
          let v975_11: Space = routine_143(c, &(v975_6), &(*p1), &(v972_7_tail), &(*s1));
          drop(v975_6);
          compose(&(v973_10),&(v975_11))
        };
        drop(v973_10);
        let v973_13: Space = unite(&(v973_8),&(v973_12));
        v972_7.join_into((v973_13).clone());
      }
      drop(v972_7_cursor);
      compose(&(v971_5),&(v972_7))
    };
    drop(v971_5);
    let v971_9: Space = intersect(&(*CONSTANT_2),&(v971_2));
    drop(v971_2);
    let v971_10: Space = if has_head(&(v971_9)) { singleton(&[]) } else { Space::new() };
    drop(v971_9);
    let v971_12: Space = if (v971_10).is_empty() { Space::new() } else {
      let v976_6: Path = concat_path(&(*p0),&(v970_13_head));
      let mut v976_11 = Space::new();
      let mut v976_11_cursor = (v970_13_tail).read_zipper();
      for v976_11_byte in v976_11_cursor.child_mask().iter() {
        v976_11_cursor.descend_to_byte(v976_11_byte);
        let v976_11_tail = v976_11_cursor.make_map();
        v976_11_cursor.ascend(1);
        let v976_11_head = Path::from_slice(&[v976_11_byte]);
        let v977_2: Space = singleton(&(v976_11_head));
        let v977_3: Space = intersect(&(*CONSTANT_2),&(v977_2));
        let v977_4: Space = if has_head(&(v977_3)) { singleton(&[]) } else { Space::new() };
        drop(v977_3);
        let v977_5: Space = subtract(&(*CONSTANT_1),&(v977_4));
        drop(v977_4);
        let v977_8: Space = if (v977_5).is_empty() { Space::new() } else {
          let v978_6: Path = concat_path(&(v976_6),&(v976_11_head));
          let v978_7: Space = routine_142(c, &(v978_6), &(*p1), &(v976_11_tail), &(*s1));
          compose(&(v977_5),&(v978_7))
        };
        drop(v977_5);
        let v977_9: Space = intersect(&(*CONSTANT_2),&(v977_2));
        drop(v977_2);
        let v977_10: Space = if has_head(&(v977_9)) { singleton(&[]) } else { Space::new() };
        drop(v977_9);
        let v977_12: Space = if (v977_10).is_empty() { Space::new() } else {
          let v979_6: Path = concat_path(&(v976_6),&(v976_11_head));
          let v979_11: Space = routine_29(c, &(v979_6), &(*p1), &(v976_11_tail), &(*s1));
          drop(v979_6);
          compose(&(v977_10),&(v979_11))
        };
        drop(v977_10);
        let v977_13: Space = unite(&(v977_8),&(v977_12));
        v976_11.join_into((v977_13).clone());
      }
      drop(v976_11_cursor);
      drop(v976_6);
      compose(&(v971_10),&(v976_11))
    };
    drop(v971_10);
    let v971_13: Space = unite(&(v971_8),&(v971_12));
    v970_13.join_into((v971_13).clone());
  }
  drop(v970_13_cursor);
  (v970_13).clone()
}

fn routine_105(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v980_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v980_10: Space = unwrap(&(v980_8),&(*CONSTANT_5));
  drop(v980_8);
  let v980_11: Space = unwrap(&(v980_10),&(*p0));
  drop(v980_10);
  let mut v980_18 = Space::new();
  let mut v980_18_cursor = (*s0).read_zipper();
  for v980_18_byte in v980_18_cursor.child_mask().iter() {
    v980_18_cursor.descend_to_byte(v980_18_byte);
    let v980_18_tail = v980_18_cursor.make_map();
    v980_18_cursor.ascend(1);
    let v980_18_head = Path::from_slice(&[v980_18_byte]);
    let v981_2: Space = singleton(&(v980_18_head));
    let v981_3: Space = intersect(&(*CONSTANT_2),&(v981_2));
    let v981_4: Space = if has_head(&(v981_3)) { singleton(&[]) } else { Space::new() };
    drop(v981_3);
    let v981_5: Space = subtract(&(*CONSTANT_1),&(v981_4));
    drop(v981_4);
    let v981_8: Space = if (v981_5).is_empty() { Space::new() } else {
      let v982_6: Path = concat_path(&(*p0),&(v980_18_head));
      let mut v982_7 = Space::new();
      let mut v982_7_cursor = (v980_18_tail).read_zipper();
      for v982_7_byte in v982_7_cursor.child_mask().iter() {
        v982_7_cursor.descend_to_byte(v982_7_byte);
        let v982_7_tail = v982_7_cursor.make_map();
        v982_7_cursor.ascend(1);
        let v982_7_head = Path::from_slice(&[v982_7_byte]);
        let v983_2: Space = singleton(&(v982_7_head));
        let v983_3: Space = intersect(&(*CONSTANT_2),&(v983_2));
        let v983_4: Space = if has_head(&(v983_3)) { singleton(&[]) } else { Space::new() };
        drop(v983_3);
        let v983_5: Space = subtract(&(*CONSTANT_1),&(v983_4));
        drop(v983_4);
        let v983_8: Space = if (v983_5).is_empty() { Space::new() } else {
          let v984_6: Path = concat_path(&(v982_6),&(v982_7_head));
          let v984_7: Space = routine_142(c, &(v984_6), &(*p1), &(v982_7_tail), &(*s1));
          compose(&(v983_5),&(v984_7))
        };
        drop(v983_5);
        let v983_9: Space = intersect(&(*CONSTANT_2),&(v983_2));
        drop(v983_2);
        let v983_10: Space = if has_head(&(v983_9)) { singleton(&[]) } else { Space::new() };
        drop(v983_9);
        let v983_12: Space = if (v983_10).is_empty() { Space::new() } else {
          let v985_6: Path = concat_path(&(v982_6),&(v982_7_head));
          let v985_11: Space = routine_143(c, &(v985_6), &(*p1), &(v982_7_tail), &(*s1));
          drop(v985_6);
          compose(&(v983_10),&(v985_11))
        };
        drop(v983_10);
        let v983_13: Space = unite(&(v983_8),&(v983_12));
        v982_7.join_into((v983_13).clone());
      }
      drop(v982_7_cursor);
      drop(v982_6);
      compose(&(v981_5),&(v982_7))
    };
    drop(v981_5);
    let v981_9: Space = intersect(&(*CONSTANT_2),&(v981_2));
    drop(v981_2);
    let v981_10: Space = if has_head(&(v981_9)) { singleton(&[]) } else { Space::new() };
    drop(v981_9);
    let v981_13: Space = if (v981_10).is_empty() { Space::new() } else {
      let v986_11: Space = unwrap(&(v980_11),&(v980_18_head));
      let mut v986_12 = Space::new();
      let mut v986_12_cursor = (v986_11).read_zipper();
      for v986_12_byte in v986_12_cursor.child_mask().iter() {
        v986_12_cursor.descend_to_byte(v986_12_byte);
        let v986_12_tail = v986_12_cursor.make_map();
        v986_12_cursor.ascend(1);
        let v986_12_head = Path::from_slice(&[v986_12_byte]);
        let v987_2: Space = singleton(&(v986_12_head));
        let v987_3: Space = intersect(&(*CONSTANT_2),&(v987_2));
        let v987_4: Space = if has_head(&(v987_3)) { singleton(&[]) } else { Space::new() };
        drop(v987_3);
        let v987_5: Space = subtract(&(*CONSTANT_1),&(v987_4));
        drop(v987_4);
        let v987_7: Space = if (v987_5).is_empty() { Space::new() } else {
          let v988_6: Space = routine_61(c, &(v986_12_head), &(*p1), &(v986_12_tail));
          compose(&(v987_5),&(v988_6))
        };
        drop(v987_5);
        let v987_8: Space = intersect(&(*CONSTANT_2),&(v987_2));
        drop(v987_2);
        let v987_9: Space = if has_head(&(v987_8)) { singleton(&[]) } else { Space::new() };
        drop(v987_8);
        let v987_11: Space = if (v987_9).is_empty() { Space::new() } else {
          let v989_10: Space = routine_62(c, &(v986_12_head), &(*p1), &(v986_12_tail));
          compose(&(v987_9),&(v989_10))
        };
        drop(v987_9);
        let v987_12: Space = unite(&(v987_7),&(v987_11));
        v986_12.join_into((v987_12).clone());
      }
      drop(v986_12_cursor);
      drop(v986_11);
      compose(&(v981_10),&(v986_12))
    };
    drop(v981_10);
    let v981_14: Space = unite(&(v981_8),&(v981_13));
    v980_18.join_into((v981_14).clone());
  }
  drop(v980_18_cursor);
  drop(v980_11);
  (v980_18).clone()
}

fn routine_106(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v990_12 = Space::new();
  let mut v990_12_cursor = (*s0).read_zipper();
  for v990_12_byte in v990_12_cursor.child_mask().iter() {
    v990_12_cursor.descend_to_byte(v990_12_byte);
    let v990_12_tail = v990_12_cursor.make_map();
    v990_12_cursor.ascend(1);
    let v990_12_head = Path::from_slice(&[v990_12_byte]);
    let v991_2: Space = singleton(&(v990_12_head));
    let v991_3: Space = intersect(&(*CONSTANT_2),&(v991_2));
    let v991_4: Space = if has_head(&(v991_3)) { singleton(&[]) } else { Space::new() };
    drop(v991_3);
    let v991_5: Space = subtract(&(*CONSTANT_1),&(v991_4));
    drop(v991_4);
    let v991_8: Space = if (v991_5).is_empty() { Space::new() } else {
      let v992_6: Path = concat_path(&(*p0),&(v990_12_head));
      let mut v992_7 = Space::new();
      let mut v992_7_cursor = (v990_12_tail).read_zipper();
      for v992_7_byte in v992_7_cursor.child_mask().iter() {
        v992_7_cursor.descend_to_byte(v992_7_byte);
        let v992_7_tail = v992_7_cursor.make_map();
        v992_7_cursor.ascend(1);
        let v992_7_head = Path::from_slice(&[v992_7_byte]);
        let v993_2: Space = singleton(&(v992_7_head));
        let v993_3: Space = intersect(&(*CONSTANT_2),&(v993_2));
        let v993_4: Space = if has_head(&(v993_3)) { singleton(&[]) } else { Space::new() };
        drop(v993_3);
        let v993_5: Space = subtract(&(*CONSTANT_1),&(v993_4));
        drop(v993_4);
        let v993_8: Space = if (v993_5).is_empty() { Space::new() } else {
          let v994_6: Path = concat_path(&(v992_6),&(v992_7_head));
          let v994_7: Space = routine_144(c, &(v994_6), &(*p1), &(v992_7_tail));
          compose(&(v993_5),&(v994_7))
        };
        drop(v993_5);
        let v993_9: Space = intersect(&(*CONSTANT_2),&(v993_2));
        drop(v993_2);
        let v993_10: Space = if has_head(&(v993_9)) { singleton(&[]) } else { Space::new() };
        drop(v993_9);
        let v993_12: Space = if (v993_10).is_empty() { Space::new() } else {
          let v995_6: Path = concat_path(&(v992_6),&(v992_7_head));
          let v995_11: Space = routine_145(c, &(v995_6), &(*p1), &(v992_7_tail));
          drop(v995_6);
          compose(&(v993_10),&(v995_11))
        };
        drop(v993_10);
        let v993_13: Space = unite(&(v993_8),&(v993_12));
        v992_7.join_into((v993_13).clone());
      }
      drop(v992_7_cursor);
      compose(&(v991_5),&(v992_7))
    };
    drop(v991_5);
    let v991_9: Space = intersect(&(*CONSTANT_2),&(v991_2));
    drop(v991_2);
    let v991_10: Space = if has_head(&(v991_9)) { singleton(&[]) } else { Space::new() };
    drop(v991_9);
    let v991_12: Space = if (v991_10).is_empty() { Space::new() } else {
      let v996_6: Path = concat_path(&(*p0),&(v990_12_head));
      let mut v996_11 = Space::new();
      let mut v996_11_cursor = (v990_12_tail).read_zipper();
      for v996_11_byte in v996_11_cursor.child_mask().iter() {
        v996_11_cursor.descend_to_byte(v996_11_byte);
        let v996_11_tail = v996_11_cursor.make_map();
        v996_11_cursor.ascend(1);
        let v996_11_head = Path::from_slice(&[v996_11_byte]);
        let v997_2: Space = singleton(&(v996_11_head));
        let v997_3: Space = intersect(&(*CONSTANT_2),&(v997_2));
        let v997_4: Space = if has_head(&(v997_3)) { singleton(&[]) } else { Space::new() };
        drop(v997_3);
        let v997_5: Space = subtract(&(*CONSTANT_1),&(v997_4));
        drop(v997_4);
        let v997_8: Space = if (v997_5).is_empty() { Space::new() } else {
          let v998_6: Path = concat_path(&(v996_6),&(v996_11_head));
          let v998_7: Space = routine_144(c, &(v998_6), &(*p1), &(v996_11_tail));
          compose(&(v997_5),&(v998_7))
        };
        drop(v997_5);
        let v997_9: Space = intersect(&(*CONSTANT_2),&(v997_2));
        drop(v997_2);
        let v997_10: Space = if has_head(&(v997_9)) { singleton(&[]) } else { Space::new() };
        drop(v997_9);
        let v997_12: Space = if (v997_10).is_empty() { Space::new() } else {
          let v999_6: Path = concat_path(&(v996_6),&(v996_11_head));
          let v999_11: Space = routine_67(c, &(v999_6), &(*p1), &(v996_11_tail));
          drop(v999_6);
          compose(&(v997_10),&(v999_11))
        };
        drop(v997_10);
        let v997_13: Space = unite(&(v997_8),&(v997_12));
        v996_11.join_into((v997_13).clone());
      }
      drop(v996_11_cursor);
      drop(v996_6);
      compose(&(v991_10),&(v996_11))
    };
    drop(v991_10);
    let v991_13: Space = unite(&(v991_8),&(v991_12));
    v990_12.join_into((v991_13).clone());
  }
  drop(v990_12_cursor);
  (v990_12).clone()
}

fn routine_107(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1000_9 = Space::new();
  let mut v1000_9_cursor = (*s0).read_zipper();
  for v1000_9_byte in v1000_9_cursor.child_mask().iter() {
    v1000_9_cursor.descend_to_byte(v1000_9_byte);
    let v1000_9_tail = v1000_9_cursor.make_map();
    v1000_9_cursor.ascend(1);
    let v1000_9_head = Path::from_slice(&[v1000_9_byte]);
    let v1001_2: Space = singleton(&(v1000_9_head));
    let v1001_3: Space = intersect(&(*CONSTANT_2),&(v1001_2));
    let v1001_4: Space = if has_head(&(v1001_3)) { singleton(&[]) } else { Space::new() };
    drop(v1001_3);
    let v1001_5: Space = subtract(&(*CONSTANT_1),&(v1001_4));
    drop(v1001_4);
    let v1001_8: Space = if (v1001_5).is_empty() { Space::new() } else {
      let v1002_6: Path = concat_path(&(*p0),&(v1000_9_head));
      let mut v1002_7 = Space::new();
      let mut v1002_7_cursor = (v1000_9_tail).read_zipper();
      for v1002_7_byte in v1002_7_cursor.child_mask().iter() {
        v1002_7_cursor.descend_to_byte(v1002_7_byte);
        let v1002_7_tail = v1002_7_cursor.make_map();
        v1002_7_cursor.ascend(1);
        let v1002_7_head = Path::from_slice(&[v1002_7_byte]);
        let v1003_2: Space = singleton(&(v1002_7_head));
        let v1003_3: Space = intersect(&(*CONSTANT_2),&(v1003_2));
        let v1003_4: Space = if has_head(&(v1003_3)) { singleton(&[]) } else { Space::new() };
        drop(v1003_3);
        let v1003_5: Space = subtract(&(*CONSTANT_1),&(v1003_4));
        drop(v1003_4);
        let v1003_8: Space = if (v1003_5).is_empty() { Space::new() } else {
          let v1004_6: Path = concat_path(&(v1002_6),&(v1002_7_head));
          let v1004_7: Space = routine_144(c, &(v1004_6), &(*p1), &(v1002_7_tail));
          compose(&(v1003_5),&(v1004_7))
        };
        drop(v1003_5);
        let v1003_9: Space = intersect(&(*CONSTANT_2),&(v1003_2));
        drop(v1003_2);
        let v1003_10: Space = if has_head(&(v1003_9)) { singleton(&[]) } else { Space::new() };
        drop(v1003_9);
        let v1003_12: Space = if (v1003_10).is_empty() { Space::new() } else {
          let v1005_6: Path = concat_path(&(v1002_6),&(v1002_7_head));
          let v1005_11: Space = routine_145(c, &(v1005_6), &(*p1), &(v1002_7_tail));
          drop(v1005_6);
          compose(&(v1003_10),&(v1005_11))
        };
        drop(v1003_10);
        let v1003_13: Space = unite(&(v1003_8),&(v1003_12));
        v1002_7.join_into((v1003_13).clone());
      }
      drop(v1002_7_cursor);
      compose(&(v1001_5),&(v1002_7))
    };
    drop(v1001_5);
    let v1001_9: Space = intersect(&(*CONSTANT_2),&(v1001_2));
    drop(v1001_2);
    let v1001_10: Space = if has_head(&(v1001_9)) { singleton(&[]) } else { Space::new() };
    drop(v1001_9);
    let v1001_11: Space = compose(&(v1001_10),&(v1000_9_tail));
    drop(v1001_10);
    let v1006_6: Path = concat_path(&(*p0),&(v1000_9_head));
    let v1001_12: Space = wrap(&(v1001_11),&(v1006_6));
    drop(v1001_11);
    let v1001_13: Space = wrap(&(v1001_12),&(*p1));
    drop(v1001_12);
    let v1001_14: Space = unite(&(v1001_8),&(v1001_13));
    drop(v1001_13);
    v1000_9.join_into((v1001_14).clone());
  }
  drop(v1000_9_cursor);
  (v1000_9).clone()
}

fn routine_108(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1007_13 = Space::new();
  let mut v1007_13_cursor = (*s0).read_zipper();
  for v1007_13_byte in v1007_13_cursor.child_mask().iter() {
    v1007_13_cursor.descend_to_byte(v1007_13_byte);
    let v1007_13_tail = v1007_13_cursor.make_map();
    v1007_13_cursor.ascend(1);
    let v1007_13_head = Path::from_slice(&[v1007_13_byte]);
    let v1008_2: Space = singleton(&(v1007_13_head));
    let v1008_3: Space = intersect(&(*CONSTANT_2),&(v1008_2));
    let v1008_4: Space = if has_head(&(v1008_3)) { singleton(&[]) } else { Space::new() };
    drop(v1008_3);
    let v1008_5: Space = subtract(&(*CONSTANT_1),&(v1008_4));
    drop(v1008_4);
    let v1008_8: Space = if (v1008_5).is_empty() { Space::new() } else {
      let v1009_6: Path = concat_path(&(*p0),&(v1007_13_head));
      let mut v1009_7 = Space::new();
      let mut v1009_7_cursor = (v1007_13_tail).read_zipper();
      for v1009_7_byte in v1009_7_cursor.child_mask().iter() {
        v1009_7_cursor.descend_to_byte(v1009_7_byte);
        let v1009_7_tail = v1009_7_cursor.make_map();
        v1009_7_cursor.ascend(1);
        let v1009_7_head = Path::from_slice(&[v1009_7_byte]);
        let v1010_2: Space = singleton(&(v1009_7_head));
        let v1010_3: Space = intersect(&(*CONSTANT_2),&(v1010_2));
        let v1010_4: Space = if has_head(&(v1010_3)) { singleton(&[]) } else { Space::new() };
        drop(v1010_3);
        let v1010_5: Space = subtract(&(*CONSTANT_1),&(v1010_4));
        drop(v1010_4);
        let v1010_8: Space = if (v1010_5).is_empty() { Space::new() } else {
          let v1011_6: Path = concat_path(&(v1009_6),&(v1009_7_head));
          let v1011_7: Space = routine_146(c, &(v1011_6), &(*p1), &(v1009_7_tail), &(*s1));
          compose(&(v1010_5),&(v1011_7))
        };
        drop(v1010_5);
        let v1010_9: Space = intersect(&(*CONSTANT_2),&(v1010_2));
        drop(v1010_2);
        let v1010_10: Space = if has_head(&(v1010_9)) { singleton(&[]) } else { Space::new() };
        drop(v1010_9);
        let v1010_12: Space = if (v1010_10).is_empty() { Space::new() } else {
          let v1012_6: Path = concat_path(&(v1009_6),&(v1009_7_head));
          let v1012_11: Space = routine_147(c, &(v1012_6), &(*p1), &(v1009_7_tail), &(*s1));
          drop(v1012_6);
          compose(&(v1010_10),&(v1012_11))
        };
        drop(v1010_10);
        let v1010_13: Space = unite(&(v1010_8),&(v1010_12));
        v1009_7.join_into((v1010_13).clone());
      }
      drop(v1009_7_cursor);
      compose(&(v1008_5),&(v1009_7))
    };
    drop(v1008_5);
    let v1008_9: Space = intersect(&(*CONSTANT_2),&(v1008_2));
    drop(v1008_2);
    let v1008_10: Space = if has_head(&(v1008_9)) { singleton(&[]) } else { Space::new() };
    drop(v1008_9);
    let v1008_12: Space = if (v1008_10).is_empty() { Space::new() } else {
      let v1013_6: Path = concat_path(&(*p0),&(v1007_13_head));
      let mut v1013_11 = Space::new();
      let mut v1013_11_cursor = (v1007_13_tail).read_zipper();
      for v1013_11_byte in v1013_11_cursor.child_mask().iter() {
        v1013_11_cursor.descend_to_byte(v1013_11_byte);
        let v1013_11_tail = v1013_11_cursor.make_map();
        v1013_11_cursor.ascend(1);
        let v1013_11_head = Path::from_slice(&[v1013_11_byte]);
        let v1014_2: Space = singleton(&(v1013_11_head));
        let v1014_3: Space = intersect(&(*CONSTANT_2),&(v1014_2));
        let v1014_4: Space = if has_head(&(v1014_3)) { singleton(&[]) } else { Space::new() };
        drop(v1014_3);
        let v1014_5: Space = subtract(&(*CONSTANT_1),&(v1014_4));
        drop(v1014_4);
        let v1014_8: Space = if (v1014_5).is_empty() { Space::new() } else {
          let v1015_6: Path = concat_path(&(v1013_6),&(v1013_11_head));
          let v1015_7: Space = routine_146(c, &(v1015_6), &(*p1), &(v1013_11_tail), &(*s1));
          compose(&(v1014_5),&(v1015_7))
        };
        drop(v1014_5);
        let v1014_9: Space = intersect(&(*CONSTANT_2),&(v1014_2));
        drop(v1014_2);
        let v1014_10: Space = if has_head(&(v1014_9)) { singleton(&[]) } else { Space::new() };
        drop(v1014_9);
        let v1014_12: Space = if (v1014_10).is_empty() { Space::new() } else {
          let v1016_6: Path = concat_path(&(v1013_6),&(v1013_11_head));
          let v1016_11: Space = routine_29(c, &(v1016_6), &(*p1), &(v1013_11_tail), &(*s1));
          drop(v1016_6);
          compose(&(v1014_10),&(v1016_11))
        };
        drop(v1014_10);
        let v1014_13: Space = unite(&(v1014_8),&(v1014_12));
        v1013_11.join_into((v1014_13).clone());
      }
      drop(v1013_11_cursor);
      drop(v1013_6);
      compose(&(v1008_10),&(v1013_11))
    };
    drop(v1008_10);
    let v1008_13: Space = unite(&(v1008_8),&(v1008_12));
    v1007_13.join_into((v1008_13).clone());
  }
  drop(v1007_13_cursor);
  (v1007_13).clone()
}

fn routine_109(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1017_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v1017_10: Space = unwrap(&(v1017_8),&(*CONSTANT_5));
  drop(v1017_8);
  let v1017_11: Space = unwrap(&(v1017_10),&(*p0));
  drop(v1017_10);
  let mut v1017_18 = Space::new();
  let mut v1017_18_cursor = (*s0).read_zipper();
  for v1017_18_byte in v1017_18_cursor.child_mask().iter() {
    v1017_18_cursor.descend_to_byte(v1017_18_byte);
    let v1017_18_tail = v1017_18_cursor.make_map();
    v1017_18_cursor.ascend(1);
    let v1017_18_head = Path::from_slice(&[v1017_18_byte]);
    let v1018_2: Space = singleton(&(v1017_18_head));
    let v1018_3: Space = intersect(&(*CONSTANT_2),&(v1018_2));
    let v1018_4: Space = if has_head(&(v1018_3)) { singleton(&[]) } else { Space::new() };
    drop(v1018_3);
    let v1018_5: Space = subtract(&(*CONSTANT_1),&(v1018_4));
    drop(v1018_4);
    let v1018_8: Space = if (v1018_5).is_empty() { Space::new() } else {
      let v1019_6: Path = concat_path(&(*p0),&(v1017_18_head));
      let mut v1019_7 = Space::new();
      let mut v1019_7_cursor = (v1017_18_tail).read_zipper();
      for v1019_7_byte in v1019_7_cursor.child_mask().iter() {
        v1019_7_cursor.descend_to_byte(v1019_7_byte);
        let v1019_7_tail = v1019_7_cursor.make_map();
        v1019_7_cursor.ascend(1);
        let v1019_7_head = Path::from_slice(&[v1019_7_byte]);
        let v1020_2: Space = singleton(&(v1019_7_head));
        let v1020_3: Space = intersect(&(*CONSTANT_2),&(v1020_2));
        let v1020_4: Space = if has_head(&(v1020_3)) { singleton(&[]) } else { Space::new() };
        drop(v1020_3);
        let v1020_5: Space = subtract(&(*CONSTANT_1),&(v1020_4));
        drop(v1020_4);
        let v1020_8: Space = if (v1020_5).is_empty() { Space::new() } else {
          let v1021_6: Path = concat_path(&(v1019_6),&(v1019_7_head));
          let v1021_7: Space = routine_146(c, &(v1021_6), &(*p1), &(v1019_7_tail), &(*s1));
          compose(&(v1020_5),&(v1021_7))
        };
        drop(v1020_5);
        let v1020_9: Space = intersect(&(*CONSTANT_2),&(v1020_2));
        drop(v1020_2);
        let v1020_10: Space = if has_head(&(v1020_9)) { singleton(&[]) } else { Space::new() };
        drop(v1020_9);
        let v1020_12: Space = if (v1020_10).is_empty() { Space::new() } else {
          let v1022_6: Path = concat_path(&(v1019_6),&(v1019_7_head));
          let v1022_11: Space = routine_147(c, &(v1022_6), &(*p1), &(v1019_7_tail), &(*s1));
          drop(v1022_6);
          compose(&(v1020_10),&(v1022_11))
        };
        drop(v1020_10);
        let v1020_13: Space = unite(&(v1020_8),&(v1020_12));
        v1019_7.join_into((v1020_13).clone());
      }
      drop(v1019_7_cursor);
      drop(v1019_6);
      compose(&(v1018_5),&(v1019_7))
    };
    drop(v1018_5);
    let v1018_9: Space = intersect(&(*CONSTANT_2),&(v1018_2));
    drop(v1018_2);
    let v1018_10: Space = if has_head(&(v1018_9)) { singleton(&[]) } else { Space::new() };
    drop(v1018_9);
    let v1018_13: Space = if (v1018_10).is_empty() { Space::new() } else {
      let v1023_11: Space = unwrap(&(v1017_11),&(v1017_18_head));
      let mut v1023_12 = Space::new();
      let mut v1023_12_cursor = (v1023_11).read_zipper();
      for v1023_12_byte in v1023_12_cursor.child_mask().iter() {
        v1023_12_cursor.descend_to_byte(v1023_12_byte);
        let v1023_12_tail = v1023_12_cursor.make_map();
        v1023_12_cursor.ascend(1);
        let v1023_12_head = Path::from_slice(&[v1023_12_byte]);
        let v1024_2: Space = singleton(&(v1023_12_head));
        let v1024_3: Space = intersect(&(*CONSTANT_2),&(v1024_2));
        let v1024_4: Space = if has_head(&(v1024_3)) { singleton(&[]) } else { Space::new() };
        drop(v1024_3);
        let v1024_5: Space = subtract(&(*CONSTANT_1),&(v1024_4));
        drop(v1024_4);
        let v1024_7: Space = if (v1024_5).is_empty() { Space::new() } else {
          let v1025_6: Space = routine_61(c, &(v1023_12_head), &(*p1), &(v1023_12_tail));
          compose(&(v1024_5),&(v1025_6))
        };
        drop(v1024_5);
        let v1024_8: Space = intersect(&(*CONSTANT_2),&(v1024_2));
        drop(v1024_2);
        let v1024_9: Space = if has_head(&(v1024_8)) { singleton(&[]) } else { Space::new() };
        drop(v1024_8);
        let v1024_11: Space = if (v1024_9).is_empty() { Space::new() } else {
          let v1026_10: Space = routine_62(c, &(v1023_12_head), &(*p1), &(v1023_12_tail));
          compose(&(v1024_9),&(v1026_10))
        };
        drop(v1024_9);
        let v1024_12: Space = unite(&(v1024_7),&(v1024_11));
        v1023_12.join_into((v1024_12).clone());
      }
      drop(v1023_12_cursor);
      drop(v1023_11);
      compose(&(v1018_10),&(v1023_12))
    };
    drop(v1018_10);
    let v1018_14: Space = unite(&(v1018_8),&(v1018_13));
    v1017_18.join_into((v1018_14).clone());
  }
  drop(v1017_18_cursor);
  drop(v1017_11);
  (v1017_18).clone()
}

fn routine_110(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1027_12 = Space::new();
  let mut v1027_12_cursor = (*s0).read_zipper();
  for v1027_12_byte in v1027_12_cursor.child_mask().iter() {
    v1027_12_cursor.descend_to_byte(v1027_12_byte);
    let v1027_12_tail = v1027_12_cursor.make_map();
    v1027_12_cursor.ascend(1);
    let v1027_12_head = Path::from_slice(&[v1027_12_byte]);
    let v1028_2: Space = singleton(&(v1027_12_head));
    let v1028_3: Space = intersect(&(*CONSTANT_2),&(v1028_2));
    let v1028_4: Space = if has_head(&(v1028_3)) { singleton(&[]) } else { Space::new() };
    drop(v1028_3);
    let v1028_5: Space = subtract(&(*CONSTANT_1),&(v1028_4));
    drop(v1028_4);
    let v1028_8: Space = if (v1028_5).is_empty() { Space::new() } else {
      let v1029_6: Path = concat_path(&(*p0),&(v1027_12_head));
      let mut v1029_7 = Space::new();
      let mut v1029_7_cursor = (v1027_12_tail).read_zipper();
      for v1029_7_byte in v1029_7_cursor.child_mask().iter() {
        v1029_7_cursor.descend_to_byte(v1029_7_byte);
        let v1029_7_tail = v1029_7_cursor.make_map();
        v1029_7_cursor.ascend(1);
        let v1029_7_head = Path::from_slice(&[v1029_7_byte]);
        let v1030_2: Space = singleton(&(v1029_7_head));
        let v1030_3: Space = intersect(&(*CONSTANT_2),&(v1030_2));
        let v1030_4: Space = if has_head(&(v1030_3)) { singleton(&[]) } else { Space::new() };
        drop(v1030_3);
        let v1030_5: Space = subtract(&(*CONSTANT_1),&(v1030_4));
        drop(v1030_4);
        let v1030_8: Space = if (v1030_5).is_empty() { Space::new() } else {
          let v1031_6: Path = concat_path(&(v1029_6),&(v1029_7_head));
          let v1031_7: Space = routine_148(c, &(v1031_6), &(*p1), &(v1029_7_tail));
          compose(&(v1030_5),&(v1031_7))
        };
        drop(v1030_5);
        let v1030_9: Space = intersect(&(*CONSTANT_2),&(v1030_2));
        drop(v1030_2);
        let v1030_10: Space = if has_head(&(v1030_9)) { singleton(&[]) } else { Space::new() };
        drop(v1030_9);
        let v1030_12: Space = if (v1030_10).is_empty() { Space::new() } else {
          let v1032_6: Path = concat_path(&(v1029_6),&(v1029_7_head));
          let v1032_11: Space = routine_149(c, &(v1032_6), &(*p1), &(v1029_7_tail));
          drop(v1032_6);
          compose(&(v1030_10),&(v1032_11))
        };
        drop(v1030_10);
        let v1030_13: Space = unite(&(v1030_8),&(v1030_12));
        v1029_7.join_into((v1030_13).clone());
      }
      drop(v1029_7_cursor);
      compose(&(v1028_5),&(v1029_7))
    };
    drop(v1028_5);
    let v1028_9: Space = intersect(&(*CONSTANT_2),&(v1028_2));
    drop(v1028_2);
    let v1028_10: Space = if has_head(&(v1028_9)) { singleton(&[]) } else { Space::new() };
    drop(v1028_9);
    let v1028_12: Space = if (v1028_10).is_empty() { Space::new() } else {
      let v1033_6: Path = concat_path(&(*p0),&(v1027_12_head));
      let mut v1033_11 = Space::new();
      let mut v1033_11_cursor = (v1027_12_tail).read_zipper();
      for v1033_11_byte in v1033_11_cursor.child_mask().iter() {
        v1033_11_cursor.descend_to_byte(v1033_11_byte);
        let v1033_11_tail = v1033_11_cursor.make_map();
        v1033_11_cursor.ascend(1);
        let v1033_11_head = Path::from_slice(&[v1033_11_byte]);
        let v1034_2: Space = singleton(&(v1033_11_head));
        let v1034_3: Space = intersect(&(*CONSTANT_2),&(v1034_2));
        let v1034_4: Space = if has_head(&(v1034_3)) { singleton(&[]) } else { Space::new() };
        drop(v1034_3);
        let v1034_5: Space = subtract(&(*CONSTANT_1),&(v1034_4));
        drop(v1034_4);
        let v1034_8: Space = if (v1034_5).is_empty() { Space::new() } else {
          let v1035_6: Path = concat_path(&(v1033_6),&(v1033_11_head));
          let v1035_7: Space = routine_148(c, &(v1035_6), &(*p1), &(v1033_11_tail));
          compose(&(v1034_5),&(v1035_7))
        };
        drop(v1034_5);
        let v1034_9: Space = intersect(&(*CONSTANT_2),&(v1034_2));
        drop(v1034_2);
        let v1034_10: Space = if has_head(&(v1034_9)) { singleton(&[]) } else { Space::new() };
        drop(v1034_9);
        let v1034_12: Space = if (v1034_10).is_empty() { Space::new() } else {
          let v1036_6: Path = concat_path(&(v1033_6),&(v1033_11_head));
          let v1036_11: Space = routine_67(c, &(v1036_6), &(*p1), &(v1033_11_tail));
          drop(v1036_6);
          compose(&(v1034_10),&(v1036_11))
        };
        drop(v1034_10);
        let v1034_13: Space = unite(&(v1034_8),&(v1034_12));
        v1033_11.join_into((v1034_13).clone());
      }
      drop(v1033_11_cursor);
      drop(v1033_6);
      compose(&(v1028_10),&(v1033_11))
    };
    drop(v1028_10);
    let v1028_13: Space = unite(&(v1028_8),&(v1028_12));
    v1027_12.join_into((v1028_13).clone());
  }
  drop(v1027_12_cursor);
  (v1027_12).clone()
}

fn routine_111(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1037_9 = Space::new();
  let mut v1037_9_cursor = (*s0).read_zipper();
  for v1037_9_byte in v1037_9_cursor.child_mask().iter() {
    v1037_9_cursor.descend_to_byte(v1037_9_byte);
    let v1037_9_tail = v1037_9_cursor.make_map();
    v1037_9_cursor.ascend(1);
    let v1037_9_head = Path::from_slice(&[v1037_9_byte]);
    let v1038_2: Space = singleton(&(v1037_9_head));
    let v1038_3: Space = intersect(&(*CONSTANT_2),&(v1038_2));
    let v1038_4: Space = if has_head(&(v1038_3)) { singleton(&[]) } else { Space::new() };
    drop(v1038_3);
    let v1038_5: Space = subtract(&(*CONSTANT_1),&(v1038_4));
    drop(v1038_4);
    let v1038_8: Space = if (v1038_5).is_empty() { Space::new() } else {
      let v1039_6: Path = concat_path(&(*p0),&(v1037_9_head));
      let mut v1039_7 = Space::new();
      let mut v1039_7_cursor = (v1037_9_tail).read_zipper();
      for v1039_7_byte in v1039_7_cursor.child_mask().iter() {
        v1039_7_cursor.descend_to_byte(v1039_7_byte);
        let v1039_7_tail = v1039_7_cursor.make_map();
        v1039_7_cursor.ascend(1);
        let v1039_7_head = Path::from_slice(&[v1039_7_byte]);
        let v1040_2: Space = singleton(&(v1039_7_head));
        let v1040_3: Space = intersect(&(*CONSTANT_2),&(v1040_2));
        let v1040_4: Space = if has_head(&(v1040_3)) { singleton(&[]) } else { Space::new() };
        drop(v1040_3);
        let v1040_5: Space = subtract(&(*CONSTANT_1),&(v1040_4));
        drop(v1040_4);
        let v1040_8: Space = if (v1040_5).is_empty() { Space::new() } else {
          let v1041_6: Path = concat_path(&(v1039_6),&(v1039_7_head));
          let v1041_7: Space = routine_148(c, &(v1041_6), &(*p1), &(v1039_7_tail));
          compose(&(v1040_5),&(v1041_7))
        };
        drop(v1040_5);
        let v1040_9: Space = intersect(&(*CONSTANT_2),&(v1040_2));
        drop(v1040_2);
        let v1040_10: Space = if has_head(&(v1040_9)) { singleton(&[]) } else { Space::new() };
        drop(v1040_9);
        let v1040_12: Space = if (v1040_10).is_empty() { Space::new() } else {
          let v1042_6: Path = concat_path(&(v1039_6),&(v1039_7_head));
          let v1042_11: Space = routine_149(c, &(v1042_6), &(*p1), &(v1039_7_tail));
          drop(v1042_6);
          compose(&(v1040_10),&(v1042_11))
        };
        drop(v1040_10);
        let v1040_13: Space = unite(&(v1040_8),&(v1040_12));
        v1039_7.join_into((v1040_13).clone());
      }
      drop(v1039_7_cursor);
      compose(&(v1038_5),&(v1039_7))
    };
    drop(v1038_5);
    let v1038_9: Space = intersect(&(*CONSTANT_2),&(v1038_2));
    drop(v1038_2);
    let v1038_10: Space = if has_head(&(v1038_9)) { singleton(&[]) } else { Space::new() };
    drop(v1038_9);
    let v1038_11: Space = compose(&(v1038_10),&(v1037_9_tail));
    drop(v1038_10);
    let v1043_6: Path = concat_path(&(*p0),&(v1037_9_head));
    let v1038_12: Space = wrap(&(v1038_11),&(v1043_6));
    drop(v1038_11);
    let v1038_13: Space = wrap(&(v1038_12),&(*p1));
    drop(v1038_12);
    let v1038_14: Space = unite(&(v1038_8),&(v1038_13));
    drop(v1038_13);
    v1037_9.join_into((v1038_14).clone());
  }
  drop(v1037_9_cursor);
  (v1037_9).clone()
}

fn routine_112(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1044_7 = Space::new();
  let mut v1044_7_cursor = (*s0).read_zipper();
  for v1044_7_byte in v1044_7_cursor.child_mask().iter() {
    v1044_7_cursor.descend_to_byte(v1044_7_byte);
    let v1044_7_tail = v1044_7_cursor.make_map();
    v1044_7_cursor.ascend(1);
    let v1044_7_head = Path::from_slice(&[v1044_7_byte]);
    let v1045_2: Space = singleton(&(v1044_7_head));
    let v1045_3: Space = intersect(&(*CONSTANT_2),&(v1045_2));
    let v1045_4: Space = if has_head(&(v1045_3)) { singleton(&[]) } else { Space::new() };
    drop(v1045_3);
    let v1045_5: Space = subtract(&(*CONSTANT_1),&(v1045_4));
    drop(v1045_4);
    let mut v1045_6 = Space::new();
    let mut v1045_6_cursor = (v1044_7_tail).read_zipper();
    for v1045_6_byte in v1045_6_cursor.child_mask().iter() {
      v1045_6_cursor.descend_to_byte(v1045_6_byte);
      let v1045_6_tail = v1045_6_cursor.make_map();
      v1045_6_cursor.ascend(1);
      let v1045_6_head = Path::from_slice(&[v1045_6_byte]);
      let v1046_2: Space = Space::new();
      v1045_6.join_into((v1046_2).clone());
    }
    drop(v1045_6_cursor);
    let v1045_7: Space = compose(&(v1045_5),&(v1045_6));
    drop(v1045_5);
    drop(v1045_6);
    let v1045_8: Space = intersect(&(*CONSTANT_2),&(v1045_2));
    drop(v1045_2);
    let v1045_9: Space = if has_head(&(v1045_8)) { singleton(&[]) } else { Space::new() };
    drop(v1045_8);
    let v1045_12: Space = if (v1045_9).is_empty() { Space::new() } else {
      let v1047_10: Path = concat_path(&(*p0),&(v1044_7_head));
      let mut v1047_11 = Space::new();
      let mut v1047_11_cursor = (v1044_7_tail).read_zipper();
      for v1047_11_byte in v1047_11_cursor.child_mask().iter() {
        v1047_11_cursor.descend_to_byte(v1047_11_byte);
        let v1047_11_tail = v1047_11_cursor.make_map();
        v1047_11_cursor.ascend(1);
        let v1047_11_head = Path::from_slice(&[v1047_11_byte]);
        let v1048_2: Space = singleton(&(v1047_11_head));
        let v1048_3: Space = intersect(&(*CONSTANT_2),&(v1048_2));
        drop(v1048_2);
        let v1048_4: Space = if has_head(&(v1048_3)) { singleton(&[]) } else { Space::new() };
        drop(v1048_3);
        let v1048_7: Space = if (v1048_4).is_empty() { Space::new() } else {
          let v1049_5: Path = concat_path(&(v1047_10),&(v1047_11_head));
          let v1049_6: Space = routine_9(c, &(v1049_5), &(v1047_11_tail), &(*s1));
          drop(v1049_5);
          compose(&(v1048_4),&(v1049_6))
        };
        drop(v1048_4);
        v1047_11.join_into((v1048_7).clone());
      }
      drop(v1047_11_cursor);
      drop(v1047_10);
      compose(&(v1045_9),&(v1047_11))
    };
    drop(v1045_9);
    let v1045_13: Space = unite(&(v1045_7),&(v1045_12));
    drop(v1045_7);
    v1044_7.join_into((v1045_13).clone());
  }
  drop(v1044_7_cursor);
  (v1044_7).clone()
}

fn routine_113(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1050_9 = Space::new();
  let mut v1050_9_cursor = (*s0).read_zipper();
  for v1050_9_byte in v1050_9_cursor.child_mask().iter() {
    v1050_9_cursor.descend_to_byte(v1050_9_byte);
    let v1050_9_tail = v1050_9_cursor.make_map();
    v1050_9_cursor.ascend(1);
    let v1050_9_head = Path::from_slice(&[v1050_9_byte]);
    let v1051_2: Space = singleton(&(v1050_9_head));
    let v1051_3: Space = intersect(&(*CONSTANT_2),&(v1051_2));
    let v1051_4: Space = if has_head(&(v1051_3)) { singleton(&[]) } else { Space::new() };
    drop(v1051_3);
    let v1051_5: Space = subtract(&(*CONSTANT_1),&(v1051_4));
    drop(v1051_4);
    let mut v1051_6 = Space::new();
    let mut v1051_6_cursor = (v1050_9_tail).read_zipper();
    for v1051_6_byte in v1051_6_cursor.child_mask().iter() {
      v1051_6_cursor.descend_to_byte(v1051_6_byte);
      let v1051_6_tail = v1051_6_cursor.make_map();
      v1051_6_cursor.ascend(1);
      let v1051_6_head = Path::from_slice(&[v1051_6_byte]);
      let v1052_2: Space = Space::new();
      v1051_6.join_into((v1052_2).clone());
    }
    drop(v1051_6_cursor);
    let v1051_7: Space = compose(&(v1051_5),&(v1051_6));
    drop(v1051_5);
    drop(v1051_6);
    let v1051_8: Space = intersect(&(*CONSTANT_2),&(v1051_2));
    drop(v1051_2);
    let v1051_9: Space = if has_head(&(v1051_8)) { singleton(&[]) } else { Space::new() };
    drop(v1051_8);
    let v1051_12: Space = if (v1051_9).is_empty() { Space::new() } else {
      let v1053_10: Path = concat_path(&(*p0),&(v1050_9_head));
      let mut v1053_11 = Space::new();
      let mut v1053_11_cursor = (v1050_9_tail).read_zipper();
      for v1053_11_byte in v1053_11_cursor.child_mask().iter() {
        v1053_11_cursor.descend_to_byte(v1053_11_byte);
        let v1053_11_tail = v1053_11_cursor.make_map();
        v1053_11_cursor.ascend(1);
        let v1053_11_head = Path::from_slice(&[v1053_11_byte]);
        let v1054_2: Space = singleton(&(v1053_11_head));
        let v1054_3: Space = intersect(&(*CONSTANT_2),&(v1054_2));
        let v1054_4: Space = if has_head(&(v1054_3)) { singleton(&[]) } else { Space::new() };
        drop(v1054_3);
        let v1054_5: Space = subtract(&(*CONSTANT_1),&(v1054_4));
        drop(v1054_4);
        let v1054_7: Space = if (v1054_5).is_empty() { Space::new() } else {
          let v1055_6: Space = routine_32(c, &(v1053_11_head), &(v1053_10), &(v1053_11_tail), &(*s1));
          compose(&(v1054_5),&(v1055_6))
        };
        drop(v1054_5);
        let v1054_8: Space = intersect(&(*CONSTANT_2),&(v1054_2));
        drop(v1054_2);
        let v1054_9: Space = if has_head(&(v1054_8)) { singleton(&[]) } else { Space::new() };
        drop(v1054_8);
        let v1054_11: Space = if (v1054_9).is_empty() { Space::new() } else {
          let v1056_10: Space = routine_33(c, &(v1053_11_head), &(v1053_10), &(v1053_11_tail), &(*s1));
          compose(&(v1054_9),&(v1056_10))
        };
        drop(v1054_9);
        let v1054_12: Space = unite(&(v1054_7),&(v1054_11));
        v1053_11.join_into((v1054_12).clone());
      }
      drop(v1053_11_cursor);
      drop(v1053_10);
      compose(&(v1051_9),&(v1053_11))
    };
    drop(v1051_9);
    let v1051_13: Space = unite(&(v1051_7),&(v1051_12));
    drop(v1051_7);
    v1050_9.join_into((v1051_13).clone());
  }
  drop(v1050_9_cursor);
  (v1050_9).clone()
}

fn routine_114(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1057_13 = Space::new();
  let mut v1057_13_cursor = (*s0).read_zipper();
  for v1057_13_byte in v1057_13_cursor.child_mask().iter() {
    v1057_13_cursor.descend_to_byte(v1057_13_byte);
    let v1057_13_tail = v1057_13_cursor.make_map();
    v1057_13_cursor.ascend(1);
    let v1057_13_head = Path::from_slice(&[v1057_13_byte]);
    let v1058_2: Space = singleton(&(v1057_13_head));
    let v1058_3: Space = intersect(&(*CONSTANT_2),&(v1058_2));
    let v1058_4: Space = if has_head(&(v1058_3)) { singleton(&[]) } else { Space::new() };
    drop(v1058_3);
    let v1058_5: Space = subtract(&(*CONSTANT_1),&(v1058_4));
    drop(v1058_4);
    let v1058_8: Space = if (v1058_5).is_empty() { Space::new() } else {
      let v1059_6: Path = concat_path(&(*p0),&(v1057_13_head));
      let mut v1059_7 = Space::new();
      let mut v1059_7_cursor = (v1057_13_tail).read_zipper();
      for v1059_7_byte in v1059_7_cursor.child_mask().iter() {
        v1059_7_cursor.descend_to_byte(v1059_7_byte);
        let v1059_7_tail = v1059_7_cursor.make_map();
        v1059_7_cursor.ascend(1);
        let v1059_7_head = Path::from_slice(&[v1059_7_byte]);
        let v1060_2: Space = singleton(&(v1059_7_head));
        let v1060_3: Space = intersect(&(*CONSTANT_2),&(v1060_2));
        let v1060_4: Space = if has_head(&(v1060_3)) { singleton(&[]) } else { Space::new() };
        drop(v1060_3);
        let v1060_5: Space = subtract(&(*CONSTANT_1),&(v1060_4));
        drop(v1060_4);
        let v1060_8: Space = if (v1060_5).is_empty() { Space::new() } else {
          let v1061_6: Path = concat_path(&(v1059_6),&(v1059_7_head));
          let v1061_7: Space = routine_150(c, &(v1061_6), &(*p1), &(v1059_7_tail), &(*s1));
          compose(&(v1060_5),&(v1061_7))
        };
        drop(v1060_5);
        let v1060_9: Space = intersect(&(*CONSTANT_2),&(v1060_2));
        drop(v1060_2);
        let v1060_10: Space = if has_head(&(v1060_9)) { singleton(&[]) } else { Space::new() };
        drop(v1060_9);
        let v1060_12: Space = if (v1060_10).is_empty() { Space::new() } else {
          let v1062_6: Path = concat_path(&(v1059_6),&(v1059_7_head));
          let v1062_11: Space = routine_151(c, &(v1062_6), &(*p1), &(v1059_7_tail), &(*s1));
          drop(v1062_6);
          compose(&(v1060_10),&(v1062_11))
        };
        drop(v1060_10);
        let v1060_13: Space = unite(&(v1060_8),&(v1060_12));
        v1059_7.join_into((v1060_13).clone());
      }
      drop(v1059_7_cursor);
      compose(&(v1058_5),&(v1059_7))
    };
    drop(v1058_5);
    let v1058_9: Space = intersect(&(*CONSTANT_2),&(v1058_2));
    drop(v1058_2);
    let v1058_10: Space = if has_head(&(v1058_9)) { singleton(&[]) } else { Space::new() };
    drop(v1058_9);
    let v1058_12: Space = if (v1058_10).is_empty() { Space::new() } else {
      let v1063_6: Path = concat_path(&(*p0),&(v1057_13_head));
      let mut v1063_11 = Space::new();
      let mut v1063_11_cursor = (v1057_13_tail).read_zipper();
      for v1063_11_byte in v1063_11_cursor.child_mask().iter() {
        v1063_11_cursor.descend_to_byte(v1063_11_byte);
        let v1063_11_tail = v1063_11_cursor.make_map();
        v1063_11_cursor.ascend(1);
        let v1063_11_head = Path::from_slice(&[v1063_11_byte]);
        let v1064_2: Space = singleton(&(v1063_11_head));
        let v1064_3: Space = intersect(&(*CONSTANT_2),&(v1064_2));
        let v1064_4: Space = if has_head(&(v1064_3)) { singleton(&[]) } else { Space::new() };
        drop(v1064_3);
        let v1064_5: Space = subtract(&(*CONSTANT_1),&(v1064_4));
        drop(v1064_4);
        let v1064_8: Space = if (v1064_5).is_empty() { Space::new() } else {
          let v1065_6: Path = concat_path(&(v1063_6),&(v1063_11_head));
          let v1065_7: Space = routine_150(c, &(v1065_6), &(*p1), &(v1063_11_tail), &(*s1));
          compose(&(v1064_5),&(v1065_7))
        };
        drop(v1064_5);
        let v1064_9: Space = intersect(&(*CONSTANT_2),&(v1064_2));
        drop(v1064_2);
        let v1064_10: Space = if has_head(&(v1064_9)) { singleton(&[]) } else { Space::new() };
        drop(v1064_9);
        let v1064_12: Space = if (v1064_10).is_empty() { Space::new() } else {
          let v1066_6: Path = concat_path(&(v1063_6),&(v1063_11_head));
          let v1066_11: Space = routine_36(c, &(v1066_6), &(*p1), &(v1063_11_tail), &(*s1));
          drop(v1066_6);
          compose(&(v1064_10),&(v1066_11))
        };
        drop(v1064_10);
        let v1064_13: Space = unite(&(v1064_8),&(v1064_12));
        v1063_11.join_into((v1064_13).clone());
      }
      drop(v1063_11_cursor);
      drop(v1063_6);
      compose(&(v1058_10),&(v1063_11))
    };
    drop(v1058_10);
    let v1058_13: Space = unite(&(v1058_8),&(v1058_12));
    v1057_13.join_into((v1058_13).clone());
  }
  drop(v1057_13_cursor);
  (v1057_13).clone()
}

fn routine_115(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1067_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v1067_10: Space = unwrap(&(v1067_8),&(*CONSTANT_5));
  drop(v1067_8);
  let v1067_11: Space = unwrap(&(v1067_10),&(*p0));
  drop(v1067_10);
  let mut v1067_18 = Space::new();
  let mut v1067_18_cursor = (*s0).read_zipper();
  for v1067_18_byte in v1067_18_cursor.child_mask().iter() {
    v1067_18_cursor.descend_to_byte(v1067_18_byte);
    let v1067_18_tail = v1067_18_cursor.make_map();
    v1067_18_cursor.ascend(1);
    let v1067_18_head = Path::from_slice(&[v1067_18_byte]);
    let v1068_2: Space = singleton(&(v1067_18_head));
    let v1068_3: Space = intersect(&(*CONSTANT_2),&(v1068_2));
    let v1068_4: Space = if has_head(&(v1068_3)) { singleton(&[]) } else { Space::new() };
    drop(v1068_3);
    let v1068_5: Space = subtract(&(*CONSTANT_1),&(v1068_4));
    drop(v1068_4);
    let v1068_8: Space = if (v1068_5).is_empty() { Space::new() } else {
      let v1069_6: Path = concat_path(&(*p0),&(v1067_18_head));
      let mut v1069_7 = Space::new();
      let mut v1069_7_cursor = (v1067_18_tail).read_zipper();
      for v1069_7_byte in v1069_7_cursor.child_mask().iter() {
        v1069_7_cursor.descend_to_byte(v1069_7_byte);
        let v1069_7_tail = v1069_7_cursor.make_map();
        v1069_7_cursor.ascend(1);
        let v1069_7_head = Path::from_slice(&[v1069_7_byte]);
        let v1070_2: Space = singleton(&(v1069_7_head));
        let v1070_3: Space = intersect(&(*CONSTANT_2),&(v1070_2));
        let v1070_4: Space = if has_head(&(v1070_3)) { singleton(&[]) } else { Space::new() };
        drop(v1070_3);
        let v1070_5: Space = subtract(&(*CONSTANT_1),&(v1070_4));
        drop(v1070_4);
        let v1070_8: Space = if (v1070_5).is_empty() { Space::new() } else {
          let v1071_6: Path = concat_path(&(v1069_6),&(v1069_7_head));
          let v1071_7: Space = routine_150(c, &(v1071_6), &(*p1), &(v1069_7_tail), &(*s1));
          compose(&(v1070_5),&(v1071_7))
        };
        drop(v1070_5);
        let v1070_9: Space = intersect(&(*CONSTANT_2),&(v1070_2));
        drop(v1070_2);
        let v1070_10: Space = if has_head(&(v1070_9)) { singleton(&[]) } else { Space::new() };
        drop(v1070_9);
        let v1070_12: Space = if (v1070_10).is_empty() { Space::new() } else {
          let v1072_6: Path = concat_path(&(v1069_6),&(v1069_7_head));
          let v1072_11: Space = routine_151(c, &(v1072_6), &(*p1), &(v1069_7_tail), &(*s1));
          drop(v1072_6);
          compose(&(v1070_10),&(v1072_11))
        };
        drop(v1070_10);
        let v1070_13: Space = unite(&(v1070_8),&(v1070_12));
        v1069_7.join_into((v1070_13).clone());
      }
      drop(v1069_7_cursor);
      drop(v1069_6);
      compose(&(v1068_5),&(v1069_7))
    };
    drop(v1068_5);
    let v1068_9: Space = intersect(&(*CONSTANT_2),&(v1068_2));
    drop(v1068_2);
    let v1068_10: Space = if has_head(&(v1068_9)) { singleton(&[]) } else { Space::new() };
    drop(v1068_9);
    let v1068_13: Space = if (v1068_10).is_empty() { Space::new() } else {
      let v1073_11: Space = unwrap(&(v1067_11),&(v1067_18_head));
      let mut v1073_12 = Space::new();
      let mut v1073_12_cursor = (v1073_11).read_zipper();
      for v1073_12_byte in v1073_12_cursor.child_mask().iter() {
        v1073_12_cursor.descend_to_byte(v1073_12_byte);
        let v1073_12_tail = v1073_12_cursor.make_map();
        v1073_12_cursor.ascend(1);
        let v1073_12_head = Path::from_slice(&[v1073_12_byte]);
        let v1074_2: Space = singleton(&(v1073_12_head));
        let v1074_3: Space = intersect(&(*CONSTANT_2),&(v1074_2));
        let v1074_4: Space = if has_head(&(v1074_3)) { singleton(&[]) } else { Space::new() };
        drop(v1074_3);
        let v1074_5: Space = subtract(&(*CONSTANT_1),&(v1074_4));
        drop(v1074_4);
        let v1074_7: Space = if (v1074_5).is_empty() { Space::new() } else {
          let v1075_6: Space = routine_72(c, &(v1073_12_head), &(*p1), &(v1073_12_tail));
          compose(&(v1074_5),&(v1075_6))
        };
        drop(v1074_5);
        let v1074_8: Space = intersect(&(*CONSTANT_2),&(v1074_2));
        drop(v1074_2);
        let v1074_9: Space = if has_head(&(v1074_8)) { singleton(&[]) } else { Space::new() };
        drop(v1074_8);
        let v1074_11: Space = if (v1074_9).is_empty() { Space::new() } else {
          let v1076_10: Space = routine_73(c, &(v1073_12_head), &(*p1), &(v1073_12_tail));
          compose(&(v1074_9),&(v1076_10))
        };
        drop(v1074_9);
        let v1074_12: Space = unite(&(v1074_7),&(v1074_11));
        v1073_12.join_into((v1074_12).clone());
      }
      drop(v1073_12_cursor);
      drop(v1073_11);
      compose(&(v1068_10),&(v1073_12))
    };
    drop(v1068_10);
    let v1068_14: Space = unite(&(v1068_8),&(v1068_13));
    v1067_18.join_into((v1068_14).clone());
  }
  drop(v1067_18_cursor);
  drop(v1067_11);
  (v1067_18).clone()
}

fn routine_116(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1077_12 = Space::new();
  let mut v1077_12_cursor = (*s0).read_zipper();
  for v1077_12_byte in v1077_12_cursor.child_mask().iter() {
    v1077_12_cursor.descend_to_byte(v1077_12_byte);
    let v1077_12_tail = v1077_12_cursor.make_map();
    v1077_12_cursor.ascend(1);
    let v1077_12_head = Path::from_slice(&[v1077_12_byte]);
    let v1078_2: Space = singleton(&(v1077_12_head));
    let v1078_3: Space = intersect(&(*CONSTANT_2),&(v1078_2));
    let v1078_4: Space = if has_head(&(v1078_3)) { singleton(&[]) } else { Space::new() };
    drop(v1078_3);
    let v1078_5: Space = subtract(&(*CONSTANT_1),&(v1078_4));
    drop(v1078_4);
    let v1078_8: Space = if (v1078_5).is_empty() { Space::new() } else {
      let v1079_6: Path = concat_path(&(*p0),&(v1077_12_head));
      let mut v1079_7 = Space::new();
      let mut v1079_7_cursor = (v1077_12_tail).read_zipper();
      for v1079_7_byte in v1079_7_cursor.child_mask().iter() {
        v1079_7_cursor.descend_to_byte(v1079_7_byte);
        let v1079_7_tail = v1079_7_cursor.make_map();
        v1079_7_cursor.ascend(1);
        let v1079_7_head = Path::from_slice(&[v1079_7_byte]);
        let v1080_2: Space = singleton(&(v1079_7_head));
        let v1080_3: Space = intersect(&(*CONSTANT_2),&(v1080_2));
        let v1080_4: Space = if has_head(&(v1080_3)) { singleton(&[]) } else { Space::new() };
        drop(v1080_3);
        let v1080_5: Space = subtract(&(*CONSTANT_1),&(v1080_4));
        drop(v1080_4);
        let v1080_8: Space = if (v1080_5).is_empty() { Space::new() } else {
          let v1081_6: Path = concat_path(&(v1079_6),&(v1079_7_head));
          let v1081_7: Space = routine_152(c, &(v1081_6), &(*p1), &(v1079_7_tail));
          compose(&(v1080_5),&(v1081_7))
        };
        drop(v1080_5);
        let v1080_9: Space = intersect(&(*CONSTANT_2),&(v1080_2));
        drop(v1080_2);
        let v1080_10: Space = if has_head(&(v1080_9)) { singleton(&[]) } else { Space::new() };
        drop(v1080_9);
        let v1080_12: Space = if (v1080_10).is_empty() { Space::new() } else {
          let v1082_6: Path = concat_path(&(v1079_6),&(v1079_7_head));
          let v1082_11: Space = routine_153(c, &(v1082_6), &(*p1), &(v1079_7_tail));
          drop(v1082_6);
          compose(&(v1080_10),&(v1082_11))
        };
        drop(v1080_10);
        let v1080_13: Space = unite(&(v1080_8),&(v1080_12));
        v1079_7.join_into((v1080_13).clone());
      }
      drop(v1079_7_cursor);
      compose(&(v1078_5),&(v1079_7))
    };
    drop(v1078_5);
    let v1078_9: Space = intersect(&(*CONSTANT_2),&(v1078_2));
    drop(v1078_2);
    let v1078_10: Space = if has_head(&(v1078_9)) { singleton(&[]) } else { Space::new() };
    drop(v1078_9);
    let v1078_12: Space = if (v1078_10).is_empty() { Space::new() } else {
      let v1083_6: Path = concat_path(&(*p0),&(v1077_12_head));
      let mut v1083_11 = Space::new();
      let mut v1083_11_cursor = (v1077_12_tail).read_zipper();
      for v1083_11_byte in v1083_11_cursor.child_mask().iter() {
        v1083_11_cursor.descend_to_byte(v1083_11_byte);
        let v1083_11_tail = v1083_11_cursor.make_map();
        v1083_11_cursor.ascend(1);
        let v1083_11_head = Path::from_slice(&[v1083_11_byte]);
        let v1084_2: Space = singleton(&(v1083_11_head));
        let v1084_3: Space = intersect(&(*CONSTANT_2),&(v1084_2));
        let v1084_4: Space = if has_head(&(v1084_3)) { singleton(&[]) } else { Space::new() };
        drop(v1084_3);
        let v1084_5: Space = subtract(&(*CONSTANT_1),&(v1084_4));
        drop(v1084_4);
        let v1084_8: Space = if (v1084_5).is_empty() { Space::new() } else {
          let v1085_6: Path = concat_path(&(v1083_6),&(v1083_11_head));
          let v1085_7: Space = routine_152(c, &(v1085_6), &(*p1), &(v1083_11_tail));
          compose(&(v1084_5),&(v1085_7))
        };
        drop(v1084_5);
        let v1084_9: Space = intersect(&(*CONSTANT_2),&(v1084_2));
        drop(v1084_2);
        let v1084_10: Space = if has_head(&(v1084_9)) { singleton(&[]) } else { Space::new() };
        drop(v1084_9);
        let v1084_12: Space = if (v1084_10).is_empty() { Space::new() } else {
          let v1086_6: Path = concat_path(&(v1083_6),&(v1083_11_head));
          let v1086_11: Space = routine_78(c, &(v1086_6), &(*p1), &(v1083_11_tail));
          drop(v1086_6);
          compose(&(v1084_10),&(v1086_11))
        };
        drop(v1084_10);
        let v1084_13: Space = unite(&(v1084_8),&(v1084_12));
        v1083_11.join_into((v1084_13).clone());
      }
      drop(v1083_11_cursor);
      drop(v1083_6);
      compose(&(v1078_10),&(v1083_11))
    };
    drop(v1078_10);
    let v1078_13: Space = unite(&(v1078_8),&(v1078_12));
    v1077_12.join_into((v1078_13).clone());
  }
  drop(v1077_12_cursor);
  (v1077_12).clone()
}

fn routine_117(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1087_9 = Space::new();
  let mut v1087_9_cursor = (*s0).read_zipper();
  for v1087_9_byte in v1087_9_cursor.child_mask().iter() {
    v1087_9_cursor.descend_to_byte(v1087_9_byte);
    let v1087_9_tail = v1087_9_cursor.make_map();
    v1087_9_cursor.ascend(1);
    let v1087_9_head = Path::from_slice(&[v1087_9_byte]);
    let v1088_2: Space = singleton(&(v1087_9_head));
    let v1088_3: Space = intersect(&(*CONSTANT_2),&(v1088_2));
    let v1088_4: Space = if has_head(&(v1088_3)) { singleton(&[]) } else { Space::new() };
    drop(v1088_3);
    let v1088_5: Space = subtract(&(*CONSTANT_1),&(v1088_4));
    drop(v1088_4);
    let v1088_8: Space = if (v1088_5).is_empty() { Space::new() } else {
      let v1089_6: Path = concat_path(&(*p0),&(v1087_9_head));
      let mut v1089_7 = Space::new();
      let mut v1089_7_cursor = (v1087_9_tail).read_zipper();
      for v1089_7_byte in v1089_7_cursor.child_mask().iter() {
        v1089_7_cursor.descend_to_byte(v1089_7_byte);
        let v1089_7_tail = v1089_7_cursor.make_map();
        v1089_7_cursor.ascend(1);
        let v1089_7_head = Path::from_slice(&[v1089_7_byte]);
        let v1090_2: Space = singleton(&(v1089_7_head));
        let v1090_3: Space = intersect(&(*CONSTANT_2),&(v1090_2));
        let v1090_4: Space = if has_head(&(v1090_3)) { singleton(&[]) } else { Space::new() };
        drop(v1090_3);
        let v1090_5: Space = subtract(&(*CONSTANT_1),&(v1090_4));
        drop(v1090_4);
        let v1090_8: Space = if (v1090_5).is_empty() { Space::new() } else {
          let v1091_6: Path = concat_path(&(v1089_6),&(v1089_7_head));
          let v1091_7: Space = routine_152(c, &(v1091_6), &(*p1), &(v1089_7_tail));
          compose(&(v1090_5),&(v1091_7))
        };
        drop(v1090_5);
        let v1090_9: Space = intersect(&(*CONSTANT_2),&(v1090_2));
        drop(v1090_2);
        let v1090_10: Space = if has_head(&(v1090_9)) { singleton(&[]) } else { Space::new() };
        drop(v1090_9);
        let v1090_12: Space = if (v1090_10).is_empty() { Space::new() } else {
          let v1092_6: Path = concat_path(&(v1089_6),&(v1089_7_head));
          let v1092_11: Space = routine_153(c, &(v1092_6), &(*p1), &(v1089_7_tail));
          drop(v1092_6);
          compose(&(v1090_10),&(v1092_11))
        };
        drop(v1090_10);
        let v1090_13: Space = unite(&(v1090_8),&(v1090_12));
        v1089_7.join_into((v1090_13).clone());
      }
      drop(v1089_7_cursor);
      compose(&(v1088_5),&(v1089_7))
    };
    drop(v1088_5);
    let v1088_9: Space = intersect(&(*CONSTANT_2),&(v1088_2));
    drop(v1088_2);
    let v1088_10: Space = if has_head(&(v1088_9)) { singleton(&[]) } else { Space::new() };
    drop(v1088_9);
    let v1088_11: Space = compose(&(v1088_10),&(v1087_9_tail));
    drop(v1088_10);
    let v1093_6: Path = concat_path(&(*p0),&(v1087_9_head));
    let v1088_12: Space = wrap(&(v1088_11),&(v1093_6));
    drop(v1088_11);
    let v1088_13: Space = wrap(&(v1088_12),&(*p1));
    drop(v1088_12);
    let v1088_14: Space = unite(&(v1088_8),&(v1088_13));
    drop(v1088_13);
    v1087_9.join_into((v1088_14).clone());
  }
  drop(v1087_9_cursor);
  (v1087_9).clone()
}

fn routine_118(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1094_13 = Space::new();
  let mut v1094_13_cursor = (*s0).read_zipper();
  for v1094_13_byte in v1094_13_cursor.child_mask().iter() {
    v1094_13_cursor.descend_to_byte(v1094_13_byte);
    let v1094_13_tail = v1094_13_cursor.make_map();
    v1094_13_cursor.ascend(1);
    let v1094_13_head = Path::from_slice(&[v1094_13_byte]);
    let v1095_2: Space = singleton(&(v1094_13_head));
    let v1095_3: Space = intersect(&(*CONSTANT_2),&(v1095_2));
    let v1095_4: Space = if has_head(&(v1095_3)) { singleton(&[]) } else { Space::new() };
    drop(v1095_3);
    let v1095_5: Space = subtract(&(*CONSTANT_1),&(v1095_4));
    drop(v1095_4);
    let v1095_8: Space = if (v1095_5).is_empty() { Space::new() } else {
      let v1096_6: Path = concat_path(&(*p0),&(v1094_13_head));
      let mut v1096_7 = Space::new();
      let mut v1096_7_cursor = (v1094_13_tail).read_zipper();
      for v1096_7_byte in v1096_7_cursor.child_mask().iter() {
        v1096_7_cursor.descend_to_byte(v1096_7_byte);
        let v1096_7_tail = v1096_7_cursor.make_map();
        v1096_7_cursor.ascend(1);
        let v1096_7_head = Path::from_slice(&[v1096_7_byte]);
        let v1097_2: Space = singleton(&(v1096_7_head));
        let v1097_3: Space = intersect(&(*CONSTANT_2),&(v1097_2));
        let v1097_4: Space = if has_head(&(v1097_3)) { singleton(&[]) } else { Space::new() };
        drop(v1097_3);
        let v1097_5: Space = subtract(&(*CONSTANT_1),&(v1097_4));
        drop(v1097_4);
        let v1097_8: Space = if (v1097_5).is_empty() { Space::new() } else {
          let v1098_6: Path = concat_path(&(v1096_6),&(v1096_7_head));
          let v1098_7: Space = routine_154(c, &(v1098_6), &(*p1), &(v1096_7_tail), &(*s1));
          compose(&(v1097_5),&(v1098_7))
        };
        drop(v1097_5);
        let v1097_9: Space = intersect(&(*CONSTANT_2),&(v1097_2));
        drop(v1097_2);
        let v1097_10: Space = if has_head(&(v1097_9)) { singleton(&[]) } else { Space::new() };
        drop(v1097_9);
        let v1097_12: Space = if (v1097_10).is_empty() { Space::new() } else {
          let v1099_6: Path = concat_path(&(v1096_6),&(v1096_7_head));
          let v1099_11: Space = routine_155(c, &(v1099_6), &(*p1), &(v1096_7_tail), &(*s1));
          drop(v1099_6);
          compose(&(v1097_10),&(v1099_11))
        };
        drop(v1097_10);
        let v1097_13: Space = unite(&(v1097_8),&(v1097_12));
        v1096_7.join_into((v1097_13).clone());
      }
      drop(v1096_7_cursor);
      compose(&(v1095_5),&(v1096_7))
    };
    drop(v1095_5);
    let v1095_9: Space = intersect(&(*CONSTANT_2),&(v1095_2));
    drop(v1095_2);
    let v1095_10: Space = if has_head(&(v1095_9)) { singleton(&[]) } else { Space::new() };
    drop(v1095_9);
    let v1095_12: Space = if (v1095_10).is_empty() { Space::new() } else {
      let v1100_6: Path = concat_path(&(*p0),&(v1094_13_head));
      let mut v1100_11 = Space::new();
      let mut v1100_11_cursor = (v1094_13_tail).read_zipper();
      for v1100_11_byte in v1100_11_cursor.child_mask().iter() {
        v1100_11_cursor.descend_to_byte(v1100_11_byte);
        let v1100_11_tail = v1100_11_cursor.make_map();
        v1100_11_cursor.ascend(1);
        let v1100_11_head = Path::from_slice(&[v1100_11_byte]);
        let v1101_2: Space = singleton(&(v1100_11_head));
        let v1101_3: Space = intersect(&(*CONSTANT_2),&(v1101_2));
        let v1101_4: Space = if has_head(&(v1101_3)) { singleton(&[]) } else { Space::new() };
        drop(v1101_3);
        let v1101_5: Space = subtract(&(*CONSTANT_1),&(v1101_4));
        drop(v1101_4);
        let v1101_8: Space = if (v1101_5).is_empty() { Space::new() } else {
          let v1102_6: Path = concat_path(&(v1100_6),&(v1100_11_head));
          let v1102_7: Space = routine_154(c, &(v1102_6), &(*p1), &(v1100_11_tail), &(*s1));
          compose(&(v1101_5),&(v1102_7))
        };
        drop(v1101_5);
        let v1101_9: Space = intersect(&(*CONSTANT_2),&(v1101_2));
        drop(v1101_2);
        let v1101_10: Space = if has_head(&(v1101_9)) { singleton(&[]) } else { Space::new() };
        drop(v1101_9);
        let v1101_12: Space = if (v1101_10).is_empty() { Space::new() } else {
          let v1103_6: Path = concat_path(&(v1100_6),&(v1100_11_head));
          let v1103_11: Space = routine_36(c, &(v1103_6), &(*p1), &(v1100_11_tail), &(*s1));
          drop(v1103_6);
          compose(&(v1101_10),&(v1103_11))
        };
        drop(v1101_10);
        let v1101_13: Space = unite(&(v1101_8),&(v1101_12));
        v1100_11.join_into((v1101_13).clone());
      }
      drop(v1100_11_cursor);
      drop(v1100_6);
      compose(&(v1095_10),&(v1100_11))
    };
    drop(v1095_10);
    let v1095_13: Space = unite(&(v1095_8),&(v1095_12));
    v1094_13.join_into((v1095_13).clone());
  }
  drop(v1094_13_cursor);
  (v1094_13).clone()
}

fn routine_119(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1104_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v1104_10: Space = unwrap(&(v1104_8),&(*CONSTANT_5));
  drop(v1104_8);
  let v1104_11: Space = unwrap(&(v1104_10),&(*p0));
  drop(v1104_10);
  let mut v1104_18 = Space::new();
  let mut v1104_18_cursor = (*s0).read_zipper();
  for v1104_18_byte in v1104_18_cursor.child_mask().iter() {
    v1104_18_cursor.descend_to_byte(v1104_18_byte);
    let v1104_18_tail = v1104_18_cursor.make_map();
    v1104_18_cursor.ascend(1);
    let v1104_18_head = Path::from_slice(&[v1104_18_byte]);
    let v1105_2: Space = singleton(&(v1104_18_head));
    let v1105_3: Space = intersect(&(*CONSTANT_2),&(v1105_2));
    let v1105_4: Space = if has_head(&(v1105_3)) { singleton(&[]) } else { Space::new() };
    drop(v1105_3);
    let v1105_5: Space = subtract(&(*CONSTANT_1),&(v1105_4));
    drop(v1105_4);
    let v1105_8: Space = if (v1105_5).is_empty() { Space::new() } else {
      let v1106_6: Path = concat_path(&(*p0),&(v1104_18_head));
      let mut v1106_7 = Space::new();
      let mut v1106_7_cursor = (v1104_18_tail).read_zipper();
      for v1106_7_byte in v1106_7_cursor.child_mask().iter() {
        v1106_7_cursor.descend_to_byte(v1106_7_byte);
        let v1106_7_tail = v1106_7_cursor.make_map();
        v1106_7_cursor.ascend(1);
        let v1106_7_head = Path::from_slice(&[v1106_7_byte]);
        let v1107_2: Space = singleton(&(v1106_7_head));
        let v1107_3: Space = intersect(&(*CONSTANT_2),&(v1107_2));
        let v1107_4: Space = if has_head(&(v1107_3)) { singleton(&[]) } else { Space::new() };
        drop(v1107_3);
        let v1107_5: Space = subtract(&(*CONSTANT_1),&(v1107_4));
        drop(v1107_4);
        let v1107_8: Space = if (v1107_5).is_empty() { Space::new() } else {
          let v1108_6: Path = concat_path(&(v1106_6),&(v1106_7_head));
          let v1108_7: Space = routine_154(c, &(v1108_6), &(*p1), &(v1106_7_tail), &(*s1));
          compose(&(v1107_5),&(v1108_7))
        };
        drop(v1107_5);
        let v1107_9: Space = intersect(&(*CONSTANT_2),&(v1107_2));
        drop(v1107_2);
        let v1107_10: Space = if has_head(&(v1107_9)) { singleton(&[]) } else { Space::new() };
        drop(v1107_9);
        let v1107_12: Space = if (v1107_10).is_empty() { Space::new() } else {
          let v1109_6: Path = concat_path(&(v1106_6),&(v1106_7_head));
          let v1109_11: Space = routine_155(c, &(v1109_6), &(*p1), &(v1106_7_tail), &(*s1));
          drop(v1109_6);
          compose(&(v1107_10),&(v1109_11))
        };
        drop(v1107_10);
        let v1107_13: Space = unite(&(v1107_8),&(v1107_12));
        v1106_7.join_into((v1107_13).clone());
      }
      drop(v1106_7_cursor);
      drop(v1106_6);
      compose(&(v1105_5),&(v1106_7))
    };
    drop(v1105_5);
    let v1105_9: Space = intersect(&(*CONSTANT_2),&(v1105_2));
    drop(v1105_2);
    let v1105_10: Space = if has_head(&(v1105_9)) { singleton(&[]) } else { Space::new() };
    drop(v1105_9);
    let v1105_13: Space = if (v1105_10).is_empty() { Space::new() } else {
      let v1110_11: Space = unwrap(&(v1104_11),&(v1104_18_head));
      let mut v1110_12 = Space::new();
      let mut v1110_12_cursor = (v1110_11).read_zipper();
      for v1110_12_byte in v1110_12_cursor.child_mask().iter() {
        v1110_12_cursor.descend_to_byte(v1110_12_byte);
        let v1110_12_tail = v1110_12_cursor.make_map();
        v1110_12_cursor.ascend(1);
        let v1110_12_head = Path::from_slice(&[v1110_12_byte]);
        let v1111_2: Space = singleton(&(v1110_12_head));
        let v1111_3: Space = intersect(&(*CONSTANT_2),&(v1111_2));
        let v1111_4: Space = if has_head(&(v1111_3)) { singleton(&[]) } else { Space::new() };
        drop(v1111_3);
        let v1111_5: Space = subtract(&(*CONSTANT_1),&(v1111_4));
        drop(v1111_4);
        let v1111_7: Space = if (v1111_5).is_empty() { Space::new() } else {
          let v1112_6: Space = routine_72(c, &(v1110_12_head), &(*p1), &(v1110_12_tail));
          compose(&(v1111_5),&(v1112_6))
        };
        drop(v1111_5);
        let v1111_8: Space = intersect(&(*CONSTANT_2),&(v1111_2));
        drop(v1111_2);
        let v1111_9: Space = if has_head(&(v1111_8)) { singleton(&[]) } else { Space::new() };
        drop(v1111_8);
        let v1111_11: Space = if (v1111_9).is_empty() { Space::new() } else {
          let v1113_10: Space = routine_73(c, &(v1110_12_head), &(*p1), &(v1110_12_tail));
          compose(&(v1111_9),&(v1113_10))
        };
        drop(v1111_9);
        let v1111_12: Space = unite(&(v1111_7),&(v1111_11));
        v1110_12.join_into((v1111_12).clone());
      }
      drop(v1110_12_cursor);
      drop(v1110_11);
      compose(&(v1105_10),&(v1110_12))
    };
    drop(v1105_10);
    let v1105_14: Space = unite(&(v1105_8),&(v1105_13));
    v1104_18.join_into((v1105_14).clone());
  }
  drop(v1104_18_cursor);
  drop(v1104_11);
  (v1104_18).clone()
}

fn routine_120(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1114_12 = Space::new();
  let mut v1114_12_cursor = (*s0).read_zipper();
  for v1114_12_byte in v1114_12_cursor.child_mask().iter() {
    v1114_12_cursor.descend_to_byte(v1114_12_byte);
    let v1114_12_tail = v1114_12_cursor.make_map();
    v1114_12_cursor.ascend(1);
    let v1114_12_head = Path::from_slice(&[v1114_12_byte]);
    let v1115_2: Space = singleton(&(v1114_12_head));
    let v1115_3: Space = intersect(&(*CONSTANT_2),&(v1115_2));
    let v1115_4: Space = if has_head(&(v1115_3)) { singleton(&[]) } else { Space::new() };
    drop(v1115_3);
    let v1115_5: Space = subtract(&(*CONSTANT_1),&(v1115_4));
    drop(v1115_4);
    let v1115_8: Space = if (v1115_5).is_empty() { Space::new() } else {
      let v1116_6: Path = concat_path(&(*p0),&(v1114_12_head));
      let mut v1116_7 = Space::new();
      let mut v1116_7_cursor = (v1114_12_tail).read_zipper();
      for v1116_7_byte in v1116_7_cursor.child_mask().iter() {
        v1116_7_cursor.descend_to_byte(v1116_7_byte);
        let v1116_7_tail = v1116_7_cursor.make_map();
        v1116_7_cursor.ascend(1);
        let v1116_7_head = Path::from_slice(&[v1116_7_byte]);
        let v1117_2: Space = singleton(&(v1116_7_head));
        let v1117_3: Space = intersect(&(*CONSTANT_2),&(v1117_2));
        let v1117_4: Space = if has_head(&(v1117_3)) { singleton(&[]) } else { Space::new() };
        drop(v1117_3);
        let v1117_5: Space = subtract(&(*CONSTANT_1),&(v1117_4));
        drop(v1117_4);
        let v1117_8: Space = if (v1117_5).is_empty() { Space::new() } else {
          let v1118_6: Path = concat_path(&(v1116_6),&(v1116_7_head));
          let v1118_7: Space = routine_156(c, &(v1118_6), &(*p1), &(v1116_7_tail));
          compose(&(v1117_5),&(v1118_7))
        };
        drop(v1117_5);
        let v1117_9: Space = intersect(&(*CONSTANT_2),&(v1117_2));
        drop(v1117_2);
        let v1117_10: Space = if has_head(&(v1117_9)) { singleton(&[]) } else { Space::new() };
        drop(v1117_9);
        let v1117_12: Space = if (v1117_10).is_empty() { Space::new() } else {
          let v1119_6: Path = concat_path(&(v1116_6),&(v1116_7_head));
          let v1119_11: Space = routine_157(c, &(v1119_6), &(*p1), &(v1116_7_tail));
          drop(v1119_6);
          compose(&(v1117_10),&(v1119_11))
        };
        drop(v1117_10);
        let v1117_13: Space = unite(&(v1117_8),&(v1117_12));
        v1116_7.join_into((v1117_13).clone());
      }
      drop(v1116_7_cursor);
      compose(&(v1115_5),&(v1116_7))
    };
    drop(v1115_5);
    let v1115_9: Space = intersect(&(*CONSTANT_2),&(v1115_2));
    drop(v1115_2);
    let v1115_10: Space = if has_head(&(v1115_9)) { singleton(&[]) } else { Space::new() };
    drop(v1115_9);
    let v1115_12: Space = if (v1115_10).is_empty() { Space::new() } else {
      let v1120_6: Path = concat_path(&(*p0),&(v1114_12_head));
      let mut v1120_11 = Space::new();
      let mut v1120_11_cursor = (v1114_12_tail).read_zipper();
      for v1120_11_byte in v1120_11_cursor.child_mask().iter() {
        v1120_11_cursor.descend_to_byte(v1120_11_byte);
        let v1120_11_tail = v1120_11_cursor.make_map();
        v1120_11_cursor.ascend(1);
        let v1120_11_head = Path::from_slice(&[v1120_11_byte]);
        let v1121_2: Space = singleton(&(v1120_11_head));
        let v1121_3: Space = intersect(&(*CONSTANT_2),&(v1121_2));
        let v1121_4: Space = if has_head(&(v1121_3)) { singleton(&[]) } else { Space::new() };
        drop(v1121_3);
        let v1121_5: Space = subtract(&(*CONSTANT_1),&(v1121_4));
        drop(v1121_4);
        let v1121_8: Space = if (v1121_5).is_empty() { Space::new() } else {
          let v1122_6: Path = concat_path(&(v1120_6),&(v1120_11_head));
          let v1122_7: Space = routine_156(c, &(v1122_6), &(*p1), &(v1120_11_tail));
          compose(&(v1121_5),&(v1122_7))
        };
        drop(v1121_5);
        let v1121_9: Space = intersect(&(*CONSTANT_2),&(v1121_2));
        drop(v1121_2);
        let v1121_10: Space = if has_head(&(v1121_9)) { singleton(&[]) } else { Space::new() };
        drop(v1121_9);
        let v1121_12: Space = if (v1121_10).is_empty() { Space::new() } else {
          let v1123_6: Path = concat_path(&(v1120_6),&(v1120_11_head));
          let v1123_11: Space = routine_78(c, &(v1123_6), &(*p1), &(v1120_11_tail));
          drop(v1123_6);
          compose(&(v1121_10),&(v1123_11))
        };
        drop(v1121_10);
        let v1121_13: Space = unite(&(v1121_8),&(v1121_12));
        v1120_11.join_into((v1121_13).clone());
      }
      drop(v1120_11_cursor);
      drop(v1120_6);
      compose(&(v1115_10),&(v1120_11))
    };
    drop(v1115_10);
    let v1115_13: Space = unite(&(v1115_8),&(v1115_12));
    v1114_12.join_into((v1115_13).clone());
  }
  drop(v1114_12_cursor);
  (v1114_12).clone()
}

fn routine_121(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1124_9 = Space::new();
  let mut v1124_9_cursor = (*s0).read_zipper();
  for v1124_9_byte in v1124_9_cursor.child_mask().iter() {
    v1124_9_cursor.descend_to_byte(v1124_9_byte);
    let v1124_9_tail = v1124_9_cursor.make_map();
    v1124_9_cursor.ascend(1);
    let v1124_9_head = Path::from_slice(&[v1124_9_byte]);
    let v1125_2: Space = singleton(&(v1124_9_head));
    let v1125_3: Space = intersect(&(*CONSTANT_2),&(v1125_2));
    let v1125_4: Space = if has_head(&(v1125_3)) { singleton(&[]) } else { Space::new() };
    drop(v1125_3);
    let v1125_5: Space = subtract(&(*CONSTANT_1),&(v1125_4));
    drop(v1125_4);
    let v1125_8: Space = if (v1125_5).is_empty() { Space::new() } else {
      let v1126_6: Path = concat_path(&(*p0),&(v1124_9_head));
      let mut v1126_7 = Space::new();
      let mut v1126_7_cursor = (v1124_9_tail).read_zipper();
      for v1126_7_byte in v1126_7_cursor.child_mask().iter() {
        v1126_7_cursor.descend_to_byte(v1126_7_byte);
        let v1126_7_tail = v1126_7_cursor.make_map();
        v1126_7_cursor.ascend(1);
        let v1126_7_head = Path::from_slice(&[v1126_7_byte]);
        let v1127_2: Space = singleton(&(v1126_7_head));
        let v1127_3: Space = intersect(&(*CONSTANT_2),&(v1127_2));
        let v1127_4: Space = if has_head(&(v1127_3)) { singleton(&[]) } else { Space::new() };
        drop(v1127_3);
        let v1127_5: Space = subtract(&(*CONSTANT_1),&(v1127_4));
        drop(v1127_4);
        let v1127_8: Space = if (v1127_5).is_empty() { Space::new() } else {
          let v1128_6: Path = concat_path(&(v1126_6),&(v1126_7_head));
          let v1128_7: Space = routine_156(c, &(v1128_6), &(*p1), &(v1126_7_tail));
          compose(&(v1127_5),&(v1128_7))
        };
        drop(v1127_5);
        let v1127_9: Space = intersect(&(*CONSTANT_2),&(v1127_2));
        drop(v1127_2);
        let v1127_10: Space = if has_head(&(v1127_9)) { singleton(&[]) } else { Space::new() };
        drop(v1127_9);
        let v1127_12: Space = if (v1127_10).is_empty() { Space::new() } else {
          let v1129_6: Path = concat_path(&(v1126_6),&(v1126_7_head));
          let v1129_11: Space = routine_157(c, &(v1129_6), &(*p1), &(v1126_7_tail));
          drop(v1129_6);
          compose(&(v1127_10),&(v1129_11))
        };
        drop(v1127_10);
        let v1127_13: Space = unite(&(v1127_8),&(v1127_12));
        v1126_7.join_into((v1127_13).clone());
      }
      drop(v1126_7_cursor);
      compose(&(v1125_5),&(v1126_7))
    };
    drop(v1125_5);
    let v1125_9: Space = intersect(&(*CONSTANT_2),&(v1125_2));
    drop(v1125_2);
    let v1125_10: Space = if has_head(&(v1125_9)) { singleton(&[]) } else { Space::new() };
    drop(v1125_9);
    let v1125_11: Space = compose(&(v1125_10),&(v1124_9_tail));
    drop(v1125_10);
    let v1130_6: Path = concat_path(&(*p0),&(v1124_9_head));
    let v1125_12: Space = wrap(&(v1125_11),&(v1130_6));
    drop(v1125_11);
    let v1125_13: Space = wrap(&(v1125_12),&(*p1));
    drop(v1125_12);
    let v1125_14: Space = unite(&(v1125_8),&(v1125_13));
    drop(v1125_13);
    v1124_9.join_into((v1125_14).clone());
  }
  drop(v1124_9_cursor);
  (v1124_9).clone()
}

fn routine_122(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1131_7 = Space::new();
  let mut v1131_7_cursor = (*s0).read_zipper();
  for v1131_7_byte in v1131_7_cursor.child_mask().iter() {
    v1131_7_cursor.descend_to_byte(v1131_7_byte);
    let v1131_7_tail = v1131_7_cursor.make_map();
    v1131_7_cursor.ascend(1);
    let v1131_7_head = Path::from_slice(&[v1131_7_byte]);
    let v1132_2: Space = singleton(&(v1131_7_head));
    let v1132_3: Space = intersect(&(*CONSTANT_2),&(v1132_2));
    let v1132_4: Space = if has_head(&(v1132_3)) { singleton(&[]) } else { Space::new() };
    drop(v1132_3);
    let v1132_5: Space = subtract(&(*CONSTANT_1),&(v1132_4));
    drop(v1132_4);
    let mut v1132_6 = Space::new();
    let mut v1132_6_cursor = (v1131_7_tail).read_zipper();
    for v1132_6_byte in v1132_6_cursor.child_mask().iter() {
      v1132_6_cursor.descend_to_byte(v1132_6_byte);
      let v1132_6_tail = v1132_6_cursor.make_map();
      v1132_6_cursor.ascend(1);
      let v1132_6_head = Path::from_slice(&[v1132_6_byte]);
      let v1133_2: Space = Space::new();
      v1132_6.join_into((v1133_2).clone());
    }
    drop(v1132_6_cursor);
    let v1132_7: Space = compose(&(v1132_5),&(v1132_6));
    drop(v1132_5);
    drop(v1132_6);
    let v1132_8: Space = intersect(&(*CONSTANT_2),&(v1132_2));
    drop(v1132_2);
    let v1132_9: Space = if has_head(&(v1132_8)) { singleton(&[]) } else { Space::new() };
    drop(v1132_8);
    let v1132_12: Space = if (v1132_9).is_empty() { Space::new() } else {
      let v1134_10: Path = concat_path(&(*p0),&(v1131_7_head));
      let mut v1134_11 = Space::new();
      let mut v1134_11_cursor = (v1131_7_tail).read_zipper();
      for v1134_11_byte in v1134_11_cursor.child_mask().iter() {
        v1134_11_cursor.descend_to_byte(v1134_11_byte);
        let v1134_11_tail = v1134_11_cursor.make_map();
        v1134_11_cursor.ascend(1);
        let v1134_11_head = Path::from_slice(&[v1134_11_byte]);
        let v1135_2: Space = singleton(&(v1134_11_head));
        let v1135_3: Space = intersect(&(*CONSTANT_2),&(v1135_2));
        drop(v1135_2);
        let v1135_4: Space = if has_head(&(v1135_3)) { singleton(&[]) } else { Space::new() };
        drop(v1135_3);
        let v1135_7: Space = if (v1135_4).is_empty() { Space::new() } else {
          let v1136_5: Path = concat_path(&(v1134_10),&(v1134_11_head));
          let v1136_6: Space = routine_12(c, &(v1136_5), &(v1134_11_tail), &(*s1));
          drop(v1136_5);
          compose(&(v1135_4),&(v1136_6))
        };
        drop(v1135_4);
        v1134_11.join_into((v1135_7).clone());
      }
      drop(v1134_11_cursor);
      drop(v1134_10);
      compose(&(v1132_9),&(v1134_11))
    };
    drop(v1132_9);
    let v1132_13: Space = unite(&(v1132_7),&(v1132_12));
    drop(v1132_7);
    v1131_7.join_into((v1132_13).clone());
  }
  drop(v1131_7_cursor);
  (v1131_7).clone()
}

fn routine_123(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1137_9 = Space::new();
  let mut v1137_9_cursor = (*s0).read_zipper();
  for v1137_9_byte in v1137_9_cursor.child_mask().iter() {
    v1137_9_cursor.descend_to_byte(v1137_9_byte);
    let v1137_9_tail = v1137_9_cursor.make_map();
    v1137_9_cursor.ascend(1);
    let v1137_9_head = Path::from_slice(&[v1137_9_byte]);
    let v1138_2: Space = singleton(&(v1137_9_head));
    let v1138_3: Space = intersect(&(*CONSTANT_2),&(v1138_2));
    let v1138_4: Space = if has_head(&(v1138_3)) { singleton(&[]) } else { Space::new() };
    drop(v1138_3);
    let v1138_5: Space = subtract(&(*CONSTANT_1),&(v1138_4));
    drop(v1138_4);
    let mut v1138_6 = Space::new();
    let mut v1138_6_cursor = (v1137_9_tail).read_zipper();
    for v1138_6_byte in v1138_6_cursor.child_mask().iter() {
      v1138_6_cursor.descend_to_byte(v1138_6_byte);
      let v1138_6_tail = v1138_6_cursor.make_map();
      v1138_6_cursor.ascend(1);
      let v1138_6_head = Path::from_slice(&[v1138_6_byte]);
      let v1139_2: Space = Space::new();
      v1138_6.join_into((v1139_2).clone());
    }
    drop(v1138_6_cursor);
    let v1138_7: Space = compose(&(v1138_5),&(v1138_6));
    drop(v1138_5);
    drop(v1138_6);
    let v1138_8: Space = intersect(&(*CONSTANT_2),&(v1138_2));
    drop(v1138_2);
    let v1138_9: Space = if has_head(&(v1138_8)) { singleton(&[]) } else { Space::new() };
    drop(v1138_8);
    let v1138_12: Space = if (v1138_9).is_empty() { Space::new() } else {
      let v1140_10: Path = concat_path(&(*p0),&(v1137_9_head));
      let mut v1140_11 = Space::new();
      let mut v1140_11_cursor = (v1137_9_tail).read_zipper();
      for v1140_11_byte in v1140_11_cursor.child_mask().iter() {
        v1140_11_cursor.descend_to_byte(v1140_11_byte);
        let v1140_11_tail = v1140_11_cursor.make_map();
        v1140_11_cursor.ascend(1);
        let v1140_11_head = Path::from_slice(&[v1140_11_byte]);
        let v1141_2: Space = singleton(&(v1140_11_head));
        let v1141_3: Space = intersect(&(*CONSTANT_2),&(v1141_2));
        let v1141_4: Space = if has_head(&(v1141_3)) { singleton(&[]) } else { Space::new() };
        drop(v1141_3);
        let v1141_5: Space = subtract(&(*CONSTANT_1),&(v1141_4));
        drop(v1141_4);
        let v1141_7: Space = if (v1141_5).is_empty() { Space::new() } else {
          let v1142_6: Space = routine_39(c, &(v1140_11_head), &(v1140_10), &(v1140_11_tail), &(*s1));
          compose(&(v1141_5),&(v1142_6))
        };
        drop(v1141_5);
        let v1141_8: Space = intersect(&(*CONSTANT_2),&(v1141_2));
        drop(v1141_2);
        let v1141_9: Space = if has_head(&(v1141_8)) { singleton(&[]) } else { Space::new() };
        drop(v1141_8);
        let v1141_11: Space = if (v1141_9).is_empty() { Space::new() } else {
          let v1143_10: Space = routine_40(c, &(v1140_11_head), &(v1140_10), &(v1140_11_tail), &(*s1));
          compose(&(v1141_9),&(v1143_10))
        };
        drop(v1141_9);
        let v1141_12: Space = unite(&(v1141_7),&(v1141_11));
        v1140_11.join_into((v1141_12).clone());
      }
      drop(v1140_11_cursor);
      drop(v1140_10);
      compose(&(v1138_9),&(v1140_11))
    };
    drop(v1138_9);
    let v1138_13: Space = unite(&(v1138_7),&(v1138_12));
    drop(v1138_7);
    v1137_9.join_into((v1138_13).clone());
  }
  drop(v1137_9_cursor);
  (v1137_9).clone()
}

fn routine_124(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1144_13 = Space::new();
  let mut v1144_13_cursor = (*s0).read_zipper();
  for v1144_13_byte in v1144_13_cursor.child_mask().iter() {
    v1144_13_cursor.descend_to_byte(v1144_13_byte);
    let v1144_13_tail = v1144_13_cursor.make_map();
    v1144_13_cursor.ascend(1);
    let v1144_13_head = Path::from_slice(&[v1144_13_byte]);
    let v1145_2: Space = singleton(&(v1144_13_head));
    let v1145_3: Space = intersect(&(*CONSTANT_2),&(v1145_2));
    let v1145_4: Space = if has_head(&(v1145_3)) { singleton(&[]) } else { Space::new() };
    drop(v1145_3);
    let v1145_5: Space = subtract(&(*CONSTANT_1),&(v1145_4));
    drop(v1145_4);
    let v1145_8: Space = if (v1145_5).is_empty() { Space::new() } else {
      let v1146_6: Path = concat_path(&(*p0),&(v1144_13_head));
      let mut v1146_7 = Space::new();
      let mut v1146_7_cursor = (v1144_13_tail).read_zipper();
      for v1146_7_byte in v1146_7_cursor.child_mask().iter() {
        v1146_7_cursor.descend_to_byte(v1146_7_byte);
        let v1146_7_tail = v1146_7_cursor.make_map();
        v1146_7_cursor.ascend(1);
        let v1146_7_head = Path::from_slice(&[v1146_7_byte]);
        let v1147_2: Space = singleton(&(v1146_7_head));
        let v1147_3: Space = intersect(&(*CONSTANT_2),&(v1147_2));
        let v1147_4: Space = if has_head(&(v1147_3)) { singleton(&[]) } else { Space::new() };
        drop(v1147_3);
        let v1147_5: Space = subtract(&(*CONSTANT_1),&(v1147_4));
        drop(v1147_4);
        let v1147_8: Space = if (v1147_5).is_empty() { Space::new() } else {
          let v1148_6: Path = concat_path(&(v1146_6),&(v1146_7_head));
          let v1148_7: Space = routine_158(c, &(v1148_6), &(*p1), &(v1146_7_tail), &(*s1));
          compose(&(v1147_5),&(v1148_7))
        };
        drop(v1147_5);
        let v1147_9: Space = intersect(&(*CONSTANT_2),&(v1147_2));
        drop(v1147_2);
        let v1147_10: Space = if has_head(&(v1147_9)) { singleton(&[]) } else { Space::new() };
        drop(v1147_9);
        let v1147_12: Space = if (v1147_10).is_empty() { Space::new() } else {
          let v1149_6: Path = concat_path(&(v1146_6),&(v1146_7_head));
          let v1149_11: Space = routine_159(c, &(v1149_6), &(*p1), &(v1146_7_tail), &(*s1));
          drop(v1149_6);
          compose(&(v1147_10),&(v1149_11))
        };
        drop(v1147_10);
        let v1147_13: Space = unite(&(v1147_8),&(v1147_12));
        v1146_7.join_into((v1147_13).clone());
      }
      drop(v1146_7_cursor);
      compose(&(v1145_5),&(v1146_7))
    };
    drop(v1145_5);
    let v1145_9: Space = intersect(&(*CONSTANT_2),&(v1145_2));
    drop(v1145_2);
    let v1145_10: Space = if has_head(&(v1145_9)) { singleton(&[]) } else { Space::new() };
    drop(v1145_9);
    let v1145_12: Space = if (v1145_10).is_empty() { Space::new() } else {
      let v1150_6: Path = concat_path(&(*p0),&(v1144_13_head));
      let mut v1150_11 = Space::new();
      let mut v1150_11_cursor = (v1144_13_tail).read_zipper();
      for v1150_11_byte in v1150_11_cursor.child_mask().iter() {
        v1150_11_cursor.descend_to_byte(v1150_11_byte);
        let v1150_11_tail = v1150_11_cursor.make_map();
        v1150_11_cursor.ascend(1);
        let v1150_11_head = Path::from_slice(&[v1150_11_byte]);
        let v1151_2: Space = singleton(&(v1150_11_head));
        let v1151_3: Space = intersect(&(*CONSTANT_2),&(v1151_2));
        let v1151_4: Space = if has_head(&(v1151_3)) { singleton(&[]) } else { Space::new() };
        drop(v1151_3);
        let v1151_5: Space = subtract(&(*CONSTANT_1),&(v1151_4));
        drop(v1151_4);
        let v1151_8: Space = if (v1151_5).is_empty() { Space::new() } else {
          let v1152_6: Path = concat_path(&(v1150_6),&(v1150_11_head));
          let v1152_7: Space = routine_158(c, &(v1152_6), &(*p1), &(v1150_11_tail), &(*s1));
          compose(&(v1151_5),&(v1152_7))
        };
        drop(v1151_5);
        let v1151_9: Space = intersect(&(*CONSTANT_2),&(v1151_2));
        drop(v1151_2);
        let v1151_10: Space = if has_head(&(v1151_9)) { singleton(&[]) } else { Space::new() };
        drop(v1151_9);
        let v1151_12: Space = if (v1151_10).is_empty() { Space::new() } else {
          let v1153_6: Path = concat_path(&(v1150_6),&(v1150_11_head));
          let v1153_11: Space = routine_43(c, &(v1153_6), &(*p1), &(v1150_11_tail), &(*s1));
          drop(v1153_6);
          compose(&(v1151_10),&(v1153_11))
        };
        drop(v1151_10);
        let v1151_13: Space = unite(&(v1151_8),&(v1151_12));
        v1150_11.join_into((v1151_13).clone());
      }
      drop(v1150_11_cursor);
      drop(v1150_6);
      compose(&(v1145_10),&(v1150_11))
    };
    drop(v1145_10);
    let v1145_13: Space = unite(&(v1145_8),&(v1145_12));
    v1144_13.join_into((v1145_13).clone());
  }
  drop(v1144_13_cursor);
  (v1144_13).clone()
}

fn routine_125(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1154_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v1154_10: Space = unwrap(&(v1154_8),&(*CONSTANT_5));
  drop(v1154_8);
  let v1154_11: Space = unwrap(&(v1154_10),&(*p0));
  drop(v1154_10);
  let mut v1154_18 = Space::new();
  let mut v1154_18_cursor = (*s0).read_zipper();
  for v1154_18_byte in v1154_18_cursor.child_mask().iter() {
    v1154_18_cursor.descend_to_byte(v1154_18_byte);
    let v1154_18_tail = v1154_18_cursor.make_map();
    v1154_18_cursor.ascend(1);
    let v1154_18_head = Path::from_slice(&[v1154_18_byte]);
    let v1155_2: Space = singleton(&(v1154_18_head));
    let v1155_3: Space = intersect(&(*CONSTANT_2),&(v1155_2));
    let v1155_4: Space = if has_head(&(v1155_3)) { singleton(&[]) } else { Space::new() };
    drop(v1155_3);
    let v1155_5: Space = subtract(&(*CONSTANT_1),&(v1155_4));
    drop(v1155_4);
    let v1155_8: Space = if (v1155_5).is_empty() { Space::new() } else {
      let v1156_6: Path = concat_path(&(*p0),&(v1154_18_head));
      let mut v1156_7 = Space::new();
      let mut v1156_7_cursor = (v1154_18_tail).read_zipper();
      for v1156_7_byte in v1156_7_cursor.child_mask().iter() {
        v1156_7_cursor.descend_to_byte(v1156_7_byte);
        let v1156_7_tail = v1156_7_cursor.make_map();
        v1156_7_cursor.ascend(1);
        let v1156_7_head = Path::from_slice(&[v1156_7_byte]);
        let v1157_2: Space = singleton(&(v1156_7_head));
        let v1157_3: Space = intersect(&(*CONSTANT_2),&(v1157_2));
        let v1157_4: Space = if has_head(&(v1157_3)) { singleton(&[]) } else { Space::new() };
        drop(v1157_3);
        let v1157_5: Space = subtract(&(*CONSTANT_1),&(v1157_4));
        drop(v1157_4);
        let v1157_8: Space = if (v1157_5).is_empty() { Space::new() } else {
          let v1158_6: Path = concat_path(&(v1156_6),&(v1156_7_head));
          let v1158_7: Space = routine_158(c, &(v1158_6), &(*p1), &(v1156_7_tail), &(*s1));
          compose(&(v1157_5),&(v1158_7))
        };
        drop(v1157_5);
        let v1157_9: Space = intersect(&(*CONSTANT_2),&(v1157_2));
        drop(v1157_2);
        let v1157_10: Space = if has_head(&(v1157_9)) { singleton(&[]) } else { Space::new() };
        drop(v1157_9);
        let v1157_12: Space = if (v1157_10).is_empty() { Space::new() } else {
          let v1159_6: Path = concat_path(&(v1156_6),&(v1156_7_head));
          let v1159_11: Space = routine_159(c, &(v1159_6), &(*p1), &(v1156_7_tail), &(*s1));
          drop(v1159_6);
          compose(&(v1157_10),&(v1159_11))
        };
        drop(v1157_10);
        let v1157_13: Space = unite(&(v1157_8),&(v1157_12));
        v1156_7.join_into((v1157_13).clone());
      }
      drop(v1156_7_cursor);
      drop(v1156_6);
      compose(&(v1155_5),&(v1156_7))
    };
    drop(v1155_5);
    let v1155_9: Space = intersect(&(*CONSTANT_2),&(v1155_2));
    drop(v1155_2);
    let v1155_10: Space = if has_head(&(v1155_9)) { singleton(&[]) } else { Space::new() };
    drop(v1155_9);
    let v1155_13: Space = if (v1155_10).is_empty() { Space::new() } else {
      let v1160_11: Space = unwrap(&(v1154_11),&(v1154_18_head));
      let mut v1160_12 = Space::new();
      let mut v1160_12_cursor = (v1160_11).read_zipper();
      for v1160_12_byte in v1160_12_cursor.child_mask().iter() {
        v1160_12_cursor.descend_to_byte(v1160_12_byte);
        let v1160_12_tail = v1160_12_cursor.make_map();
        v1160_12_cursor.ascend(1);
        let v1160_12_head = Path::from_slice(&[v1160_12_byte]);
        let v1161_2: Space = singleton(&(v1160_12_head));
        let v1161_3: Space = intersect(&(*CONSTANT_2),&(v1161_2));
        let v1161_4: Space = if has_head(&(v1161_3)) { singleton(&[]) } else { Space::new() };
        drop(v1161_3);
        let v1161_5: Space = subtract(&(*CONSTANT_1),&(v1161_4));
        drop(v1161_4);
        let v1161_7: Space = if (v1161_5).is_empty() { Space::new() } else {
          let v1162_6: Space = routine_83(c, &(v1160_12_head), &(*p1), &(v1160_12_tail));
          compose(&(v1161_5),&(v1162_6))
        };
        drop(v1161_5);
        let v1161_8: Space = intersect(&(*CONSTANT_2),&(v1161_2));
        drop(v1161_2);
        let v1161_9: Space = if has_head(&(v1161_8)) { singleton(&[]) } else { Space::new() };
        drop(v1161_8);
        let v1161_11: Space = if (v1161_9).is_empty() { Space::new() } else {
          let v1163_10: Space = routine_84(c, &(v1160_12_head), &(*p1), &(v1160_12_tail));
          compose(&(v1161_9),&(v1163_10))
        };
        drop(v1161_9);
        let v1161_12: Space = unite(&(v1161_7),&(v1161_11));
        v1160_12.join_into((v1161_12).clone());
      }
      drop(v1160_12_cursor);
      drop(v1160_11);
      compose(&(v1155_10),&(v1160_12))
    };
    drop(v1155_10);
    let v1155_14: Space = unite(&(v1155_8),&(v1155_13));
    v1154_18.join_into((v1155_14).clone());
  }
  drop(v1154_18_cursor);
  drop(v1154_11);
  (v1154_18).clone()
}

fn routine_126(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1164_12 = Space::new();
  let mut v1164_12_cursor = (*s0).read_zipper();
  for v1164_12_byte in v1164_12_cursor.child_mask().iter() {
    v1164_12_cursor.descend_to_byte(v1164_12_byte);
    let v1164_12_tail = v1164_12_cursor.make_map();
    v1164_12_cursor.ascend(1);
    let v1164_12_head = Path::from_slice(&[v1164_12_byte]);
    let v1165_2: Space = singleton(&(v1164_12_head));
    let v1165_3: Space = intersect(&(*CONSTANT_2),&(v1165_2));
    let v1165_4: Space = if has_head(&(v1165_3)) { singleton(&[]) } else { Space::new() };
    drop(v1165_3);
    let v1165_5: Space = subtract(&(*CONSTANT_1),&(v1165_4));
    drop(v1165_4);
    let v1165_8: Space = if (v1165_5).is_empty() { Space::new() } else {
      let v1166_6: Path = concat_path(&(*p0),&(v1164_12_head));
      let mut v1166_7 = Space::new();
      let mut v1166_7_cursor = (v1164_12_tail).read_zipper();
      for v1166_7_byte in v1166_7_cursor.child_mask().iter() {
        v1166_7_cursor.descend_to_byte(v1166_7_byte);
        let v1166_7_tail = v1166_7_cursor.make_map();
        v1166_7_cursor.ascend(1);
        let v1166_7_head = Path::from_slice(&[v1166_7_byte]);
        let v1167_2: Space = singleton(&(v1166_7_head));
        let v1167_3: Space = intersect(&(*CONSTANT_2),&(v1167_2));
        let v1167_4: Space = if has_head(&(v1167_3)) { singleton(&[]) } else { Space::new() };
        drop(v1167_3);
        let v1167_5: Space = subtract(&(*CONSTANT_1),&(v1167_4));
        drop(v1167_4);
        let v1167_8: Space = if (v1167_5).is_empty() { Space::new() } else {
          let v1168_6: Path = concat_path(&(v1166_6),&(v1166_7_head));
          let v1168_7: Space = routine_160(c, &(v1168_6), &(*p1), &(v1166_7_tail));
          compose(&(v1167_5),&(v1168_7))
        };
        drop(v1167_5);
        let v1167_9: Space = intersect(&(*CONSTANT_2),&(v1167_2));
        drop(v1167_2);
        let v1167_10: Space = if has_head(&(v1167_9)) { singleton(&[]) } else { Space::new() };
        drop(v1167_9);
        let v1167_12: Space = if (v1167_10).is_empty() { Space::new() } else {
          let v1169_6: Path = concat_path(&(v1166_6),&(v1166_7_head));
          let v1169_11: Space = routine_161(c, &(v1169_6), &(*p1), &(v1166_7_tail));
          drop(v1169_6);
          compose(&(v1167_10),&(v1169_11))
        };
        drop(v1167_10);
        let v1167_13: Space = unite(&(v1167_8),&(v1167_12));
        v1166_7.join_into((v1167_13).clone());
      }
      drop(v1166_7_cursor);
      compose(&(v1165_5),&(v1166_7))
    };
    drop(v1165_5);
    let v1165_9: Space = intersect(&(*CONSTANT_2),&(v1165_2));
    drop(v1165_2);
    let v1165_10: Space = if has_head(&(v1165_9)) { singleton(&[]) } else { Space::new() };
    drop(v1165_9);
    let v1165_12: Space = if (v1165_10).is_empty() { Space::new() } else {
      let v1170_6: Path = concat_path(&(*p0),&(v1164_12_head));
      let mut v1170_11 = Space::new();
      let mut v1170_11_cursor = (v1164_12_tail).read_zipper();
      for v1170_11_byte in v1170_11_cursor.child_mask().iter() {
        v1170_11_cursor.descend_to_byte(v1170_11_byte);
        let v1170_11_tail = v1170_11_cursor.make_map();
        v1170_11_cursor.ascend(1);
        let v1170_11_head = Path::from_slice(&[v1170_11_byte]);
        let v1171_2: Space = singleton(&(v1170_11_head));
        let v1171_3: Space = intersect(&(*CONSTANT_2),&(v1171_2));
        let v1171_4: Space = if has_head(&(v1171_3)) { singleton(&[]) } else { Space::new() };
        drop(v1171_3);
        let v1171_5: Space = subtract(&(*CONSTANT_1),&(v1171_4));
        drop(v1171_4);
        let v1171_8: Space = if (v1171_5).is_empty() { Space::new() } else {
          let v1172_6: Path = concat_path(&(v1170_6),&(v1170_11_head));
          let v1172_7: Space = routine_160(c, &(v1172_6), &(*p1), &(v1170_11_tail));
          compose(&(v1171_5),&(v1172_7))
        };
        drop(v1171_5);
        let v1171_9: Space = intersect(&(*CONSTANT_2),&(v1171_2));
        drop(v1171_2);
        let v1171_10: Space = if has_head(&(v1171_9)) { singleton(&[]) } else { Space::new() };
        drop(v1171_9);
        let v1171_12: Space = if (v1171_10).is_empty() { Space::new() } else {
          let v1173_6: Path = concat_path(&(v1170_6),&(v1170_11_head));
          let v1173_11: Space = routine_89(c, &(v1173_6), &(*p1), &(v1170_11_tail));
          drop(v1173_6);
          compose(&(v1171_10),&(v1173_11))
        };
        drop(v1171_10);
        let v1171_13: Space = unite(&(v1171_8),&(v1171_12));
        v1170_11.join_into((v1171_13).clone());
      }
      drop(v1170_11_cursor);
      drop(v1170_6);
      compose(&(v1165_10),&(v1170_11))
    };
    drop(v1165_10);
    let v1165_13: Space = unite(&(v1165_8),&(v1165_12));
    v1164_12.join_into((v1165_13).clone());
  }
  drop(v1164_12_cursor);
  (v1164_12).clone()
}

fn routine_127(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1174_9 = Space::new();
  let mut v1174_9_cursor = (*s0).read_zipper();
  for v1174_9_byte in v1174_9_cursor.child_mask().iter() {
    v1174_9_cursor.descend_to_byte(v1174_9_byte);
    let v1174_9_tail = v1174_9_cursor.make_map();
    v1174_9_cursor.ascend(1);
    let v1174_9_head = Path::from_slice(&[v1174_9_byte]);
    let v1175_2: Space = singleton(&(v1174_9_head));
    let v1175_3: Space = intersect(&(*CONSTANT_2),&(v1175_2));
    let v1175_4: Space = if has_head(&(v1175_3)) { singleton(&[]) } else { Space::new() };
    drop(v1175_3);
    let v1175_5: Space = subtract(&(*CONSTANT_1),&(v1175_4));
    drop(v1175_4);
    let v1175_8: Space = if (v1175_5).is_empty() { Space::new() } else {
      let v1176_6: Path = concat_path(&(*p0),&(v1174_9_head));
      let mut v1176_7 = Space::new();
      let mut v1176_7_cursor = (v1174_9_tail).read_zipper();
      for v1176_7_byte in v1176_7_cursor.child_mask().iter() {
        v1176_7_cursor.descend_to_byte(v1176_7_byte);
        let v1176_7_tail = v1176_7_cursor.make_map();
        v1176_7_cursor.ascend(1);
        let v1176_7_head = Path::from_slice(&[v1176_7_byte]);
        let v1177_2: Space = singleton(&(v1176_7_head));
        let v1177_3: Space = intersect(&(*CONSTANT_2),&(v1177_2));
        let v1177_4: Space = if has_head(&(v1177_3)) { singleton(&[]) } else { Space::new() };
        drop(v1177_3);
        let v1177_5: Space = subtract(&(*CONSTANT_1),&(v1177_4));
        drop(v1177_4);
        let v1177_8: Space = if (v1177_5).is_empty() { Space::new() } else {
          let v1178_6: Path = concat_path(&(v1176_6),&(v1176_7_head));
          let v1178_7: Space = routine_160(c, &(v1178_6), &(*p1), &(v1176_7_tail));
          compose(&(v1177_5),&(v1178_7))
        };
        drop(v1177_5);
        let v1177_9: Space = intersect(&(*CONSTANT_2),&(v1177_2));
        drop(v1177_2);
        let v1177_10: Space = if has_head(&(v1177_9)) { singleton(&[]) } else { Space::new() };
        drop(v1177_9);
        let v1177_12: Space = if (v1177_10).is_empty() { Space::new() } else {
          let v1179_6: Path = concat_path(&(v1176_6),&(v1176_7_head));
          let v1179_11: Space = routine_161(c, &(v1179_6), &(*p1), &(v1176_7_tail));
          drop(v1179_6);
          compose(&(v1177_10),&(v1179_11))
        };
        drop(v1177_10);
        let v1177_13: Space = unite(&(v1177_8),&(v1177_12));
        v1176_7.join_into((v1177_13).clone());
      }
      drop(v1176_7_cursor);
      compose(&(v1175_5),&(v1176_7))
    };
    drop(v1175_5);
    let v1175_9: Space = intersect(&(*CONSTANT_2),&(v1175_2));
    drop(v1175_2);
    let v1175_10: Space = if has_head(&(v1175_9)) { singleton(&[]) } else { Space::new() };
    drop(v1175_9);
    let v1175_11: Space = compose(&(v1175_10),&(v1174_9_tail));
    drop(v1175_10);
    let v1180_6: Path = concat_path(&(*p0),&(v1174_9_head));
    let v1175_12: Space = wrap(&(v1175_11),&(v1180_6));
    drop(v1175_11);
    let v1175_13: Space = wrap(&(v1175_12),&(*p1));
    drop(v1175_12);
    let v1175_14: Space = unite(&(v1175_8),&(v1175_13));
    drop(v1175_13);
    v1174_9.join_into((v1175_14).clone());
  }
  drop(v1174_9_cursor);
  (v1174_9).clone()
}

fn routine_128(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1181_13 = Space::new();
  let mut v1181_13_cursor = (*s0).read_zipper();
  for v1181_13_byte in v1181_13_cursor.child_mask().iter() {
    v1181_13_cursor.descend_to_byte(v1181_13_byte);
    let v1181_13_tail = v1181_13_cursor.make_map();
    v1181_13_cursor.ascend(1);
    let v1181_13_head = Path::from_slice(&[v1181_13_byte]);
    let v1182_2: Space = singleton(&(v1181_13_head));
    let v1182_3: Space = intersect(&(*CONSTANT_2),&(v1182_2));
    let v1182_4: Space = if has_head(&(v1182_3)) { singleton(&[]) } else { Space::new() };
    drop(v1182_3);
    let v1182_5: Space = subtract(&(*CONSTANT_1),&(v1182_4));
    drop(v1182_4);
    let v1182_8: Space = if (v1182_5).is_empty() { Space::new() } else {
      let v1183_6: Path = concat_path(&(*p0),&(v1181_13_head));
      let mut v1183_7 = Space::new();
      let mut v1183_7_cursor = (v1181_13_tail).read_zipper();
      for v1183_7_byte in v1183_7_cursor.child_mask().iter() {
        v1183_7_cursor.descend_to_byte(v1183_7_byte);
        let v1183_7_tail = v1183_7_cursor.make_map();
        v1183_7_cursor.ascend(1);
        let v1183_7_head = Path::from_slice(&[v1183_7_byte]);
        let v1184_2: Space = singleton(&(v1183_7_head));
        let v1184_3: Space = intersect(&(*CONSTANT_2),&(v1184_2));
        let v1184_4: Space = if has_head(&(v1184_3)) { singleton(&[]) } else { Space::new() };
        drop(v1184_3);
        let v1184_5: Space = subtract(&(*CONSTANT_1),&(v1184_4));
        drop(v1184_4);
        let v1184_8: Space = if (v1184_5).is_empty() { Space::new() } else {
          let v1185_6: Path = concat_path(&(v1183_6),&(v1183_7_head));
          let v1185_7: Space = routine_162(c, &(v1185_6), &(*p1), &(v1183_7_tail), &(*s1));
          compose(&(v1184_5),&(v1185_7))
        };
        drop(v1184_5);
        let v1184_9: Space = intersect(&(*CONSTANT_2),&(v1184_2));
        drop(v1184_2);
        let v1184_10: Space = if has_head(&(v1184_9)) { singleton(&[]) } else { Space::new() };
        drop(v1184_9);
        let v1184_12: Space = if (v1184_10).is_empty() { Space::new() } else {
          let v1186_6: Path = concat_path(&(v1183_6),&(v1183_7_head));
          let v1186_11: Space = routine_163(c, &(v1186_6), &(*p1), &(v1183_7_tail), &(*s1));
          drop(v1186_6);
          compose(&(v1184_10),&(v1186_11))
        };
        drop(v1184_10);
        let v1184_13: Space = unite(&(v1184_8),&(v1184_12));
        v1183_7.join_into((v1184_13).clone());
      }
      drop(v1183_7_cursor);
      compose(&(v1182_5),&(v1183_7))
    };
    drop(v1182_5);
    let v1182_9: Space = intersect(&(*CONSTANT_2),&(v1182_2));
    drop(v1182_2);
    let v1182_10: Space = if has_head(&(v1182_9)) { singleton(&[]) } else { Space::new() };
    drop(v1182_9);
    let v1182_12: Space = if (v1182_10).is_empty() { Space::new() } else {
      let v1187_6: Path = concat_path(&(*p0),&(v1181_13_head));
      let mut v1187_11 = Space::new();
      let mut v1187_11_cursor = (v1181_13_tail).read_zipper();
      for v1187_11_byte in v1187_11_cursor.child_mask().iter() {
        v1187_11_cursor.descend_to_byte(v1187_11_byte);
        let v1187_11_tail = v1187_11_cursor.make_map();
        v1187_11_cursor.ascend(1);
        let v1187_11_head = Path::from_slice(&[v1187_11_byte]);
        let v1188_2: Space = singleton(&(v1187_11_head));
        let v1188_3: Space = intersect(&(*CONSTANT_2),&(v1188_2));
        let v1188_4: Space = if has_head(&(v1188_3)) { singleton(&[]) } else { Space::new() };
        drop(v1188_3);
        let v1188_5: Space = subtract(&(*CONSTANT_1),&(v1188_4));
        drop(v1188_4);
        let v1188_8: Space = if (v1188_5).is_empty() { Space::new() } else {
          let v1189_6: Path = concat_path(&(v1187_6),&(v1187_11_head));
          let v1189_7: Space = routine_162(c, &(v1189_6), &(*p1), &(v1187_11_tail), &(*s1));
          compose(&(v1188_5),&(v1189_7))
        };
        drop(v1188_5);
        let v1188_9: Space = intersect(&(*CONSTANT_2),&(v1188_2));
        drop(v1188_2);
        let v1188_10: Space = if has_head(&(v1188_9)) { singleton(&[]) } else { Space::new() };
        drop(v1188_9);
        let v1188_12: Space = if (v1188_10).is_empty() { Space::new() } else {
          let v1190_6: Path = concat_path(&(v1187_6),&(v1187_11_head));
          let v1190_11: Space = routine_43(c, &(v1190_6), &(*p1), &(v1187_11_tail), &(*s1));
          drop(v1190_6);
          compose(&(v1188_10),&(v1190_11))
        };
        drop(v1188_10);
        let v1188_13: Space = unite(&(v1188_8),&(v1188_12));
        v1187_11.join_into((v1188_13).clone());
      }
      drop(v1187_11_cursor);
      drop(v1187_6);
      compose(&(v1182_10),&(v1187_11))
    };
    drop(v1182_10);
    let v1182_13: Space = unite(&(v1182_8),&(v1182_12));
    v1181_13.join_into((v1182_13).clone());
  }
  drop(v1181_13_cursor);
  (v1181_13).clone()
}

fn routine_129(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1191_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v1191_10: Space = unwrap(&(v1191_8),&(*CONSTANT_5));
  drop(v1191_8);
  let v1191_11: Space = unwrap(&(v1191_10),&(*p0));
  drop(v1191_10);
  let mut v1191_18 = Space::new();
  let mut v1191_18_cursor = (*s0).read_zipper();
  for v1191_18_byte in v1191_18_cursor.child_mask().iter() {
    v1191_18_cursor.descend_to_byte(v1191_18_byte);
    let v1191_18_tail = v1191_18_cursor.make_map();
    v1191_18_cursor.ascend(1);
    let v1191_18_head = Path::from_slice(&[v1191_18_byte]);
    let v1192_2: Space = singleton(&(v1191_18_head));
    let v1192_3: Space = intersect(&(*CONSTANT_2),&(v1192_2));
    let v1192_4: Space = if has_head(&(v1192_3)) { singleton(&[]) } else { Space::new() };
    drop(v1192_3);
    let v1192_5: Space = subtract(&(*CONSTANT_1),&(v1192_4));
    drop(v1192_4);
    let v1192_8: Space = if (v1192_5).is_empty() { Space::new() } else {
      let v1193_6: Path = concat_path(&(*p0),&(v1191_18_head));
      let mut v1193_7 = Space::new();
      let mut v1193_7_cursor = (v1191_18_tail).read_zipper();
      for v1193_7_byte in v1193_7_cursor.child_mask().iter() {
        v1193_7_cursor.descend_to_byte(v1193_7_byte);
        let v1193_7_tail = v1193_7_cursor.make_map();
        v1193_7_cursor.ascend(1);
        let v1193_7_head = Path::from_slice(&[v1193_7_byte]);
        let v1194_2: Space = singleton(&(v1193_7_head));
        let v1194_3: Space = intersect(&(*CONSTANT_2),&(v1194_2));
        let v1194_4: Space = if has_head(&(v1194_3)) { singleton(&[]) } else { Space::new() };
        drop(v1194_3);
        let v1194_5: Space = subtract(&(*CONSTANT_1),&(v1194_4));
        drop(v1194_4);
        let v1194_8: Space = if (v1194_5).is_empty() { Space::new() } else {
          let v1195_6: Path = concat_path(&(v1193_6),&(v1193_7_head));
          let v1195_7: Space = routine_162(c, &(v1195_6), &(*p1), &(v1193_7_tail), &(*s1));
          compose(&(v1194_5),&(v1195_7))
        };
        drop(v1194_5);
        let v1194_9: Space = intersect(&(*CONSTANT_2),&(v1194_2));
        drop(v1194_2);
        let v1194_10: Space = if has_head(&(v1194_9)) { singleton(&[]) } else { Space::new() };
        drop(v1194_9);
        let v1194_12: Space = if (v1194_10).is_empty() { Space::new() } else {
          let v1196_6: Path = concat_path(&(v1193_6),&(v1193_7_head));
          let v1196_11: Space = routine_163(c, &(v1196_6), &(*p1), &(v1193_7_tail), &(*s1));
          drop(v1196_6);
          compose(&(v1194_10),&(v1196_11))
        };
        drop(v1194_10);
        let v1194_13: Space = unite(&(v1194_8),&(v1194_12));
        v1193_7.join_into((v1194_13).clone());
      }
      drop(v1193_7_cursor);
      drop(v1193_6);
      compose(&(v1192_5),&(v1193_7))
    };
    drop(v1192_5);
    let v1192_9: Space = intersect(&(*CONSTANT_2),&(v1192_2));
    drop(v1192_2);
    let v1192_10: Space = if has_head(&(v1192_9)) { singleton(&[]) } else { Space::new() };
    drop(v1192_9);
    let v1192_13: Space = if (v1192_10).is_empty() { Space::new() } else {
      let v1197_11: Space = unwrap(&(v1191_11),&(v1191_18_head));
      let mut v1197_12 = Space::new();
      let mut v1197_12_cursor = (v1197_11).read_zipper();
      for v1197_12_byte in v1197_12_cursor.child_mask().iter() {
        v1197_12_cursor.descend_to_byte(v1197_12_byte);
        let v1197_12_tail = v1197_12_cursor.make_map();
        v1197_12_cursor.ascend(1);
        let v1197_12_head = Path::from_slice(&[v1197_12_byte]);
        let v1198_2: Space = singleton(&(v1197_12_head));
        let v1198_3: Space = intersect(&(*CONSTANT_2),&(v1198_2));
        let v1198_4: Space = if has_head(&(v1198_3)) { singleton(&[]) } else { Space::new() };
        drop(v1198_3);
        let v1198_5: Space = subtract(&(*CONSTANT_1),&(v1198_4));
        drop(v1198_4);
        let v1198_7: Space = if (v1198_5).is_empty() { Space::new() } else {
          let v1199_6: Space = routine_83(c, &(v1197_12_head), &(*p1), &(v1197_12_tail));
          compose(&(v1198_5),&(v1199_6))
        };
        drop(v1198_5);
        let v1198_8: Space = intersect(&(*CONSTANT_2),&(v1198_2));
        drop(v1198_2);
        let v1198_9: Space = if has_head(&(v1198_8)) { singleton(&[]) } else { Space::new() };
        drop(v1198_8);
        let v1198_11: Space = if (v1198_9).is_empty() { Space::new() } else {
          let v1200_10: Space = routine_84(c, &(v1197_12_head), &(*p1), &(v1197_12_tail));
          compose(&(v1198_9),&(v1200_10))
        };
        drop(v1198_9);
        let v1198_12: Space = unite(&(v1198_7),&(v1198_11));
        v1197_12.join_into((v1198_12).clone());
      }
      drop(v1197_12_cursor);
      drop(v1197_11);
      compose(&(v1192_10),&(v1197_12))
    };
    drop(v1192_10);
    let v1192_14: Space = unite(&(v1192_8),&(v1192_13));
    v1191_18.join_into((v1192_14).clone());
  }
  drop(v1191_18_cursor);
  drop(v1191_11);
  (v1191_18).clone()
}

fn routine_130(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1201_12 = Space::new();
  let mut v1201_12_cursor = (*s0).read_zipper();
  for v1201_12_byte in v1201_12_cursor.child_mask().iter() {
    v1201_12_cursor.descend_to_byte(v1201_12_byte);
    let v1201_12_tail = v1201_12_cursor.make_map();
    v1201_12_cursor.ascend(1);
    let v1201_12_head = Path::from_slice(&[v1201_12_byte]);
    let v1202_2: Space = singleton(&(v1201_12_head));
    let v1202_3: Space = intersect(&(*CONSTANT_2),&(v1202_2));
    let v1202_4: Space = if has_head(&(v1202_3)) { singleton(&[]) } else { Space::new() };
    drop(v1202_3);
    let v1202_5: Space = subtract(&(*CONSTANT_1),&(v1202_4));
    drop(v1202_4);
    let v1202_8: Space = if (v1202_5).is_empty() { Space::new() } else {
      let v1203_6: Path = concat_path(&(*p0),&(v1201_12_head));
      let mut v1203_7 = Space::new();
      let mut v1203_7_cursor = (v1201_12_tail).read_zipper();
      for v1203_7_byte in v1203_7_cursor.child_mask().iter() {
        v1203_7_cursor.descend_to_byte(v1203_7_byte);
        let v1203_7_tail = v1203_7_cursor.make_map();
        v1203_7_cursor.ascend(1);
        let v1203_7_head = Path::from_slice(&[v1203_7_byte]);
        let v1204_2: Space = singleton(&(v1203_7_head));
        let v1204_3: Space = intersect(&(*CONSTANT_2),&(v1204_2));
        let v1204_4: Space = if has_head(&(v1204_3)) { singleton(&[]) } else { Space::new() };
        drop(v1204_3);
        let v1204_5: Space = subtract(&(*CONSTANT_1),&(v1204_4));
        drop(v1204_4);
        let v1204_8: Space = if (v1204_5).is_empty() { Space::new() } else {
          let v1205_6: Path = concat_path(&(v1203_6),&(v1203_7_head));
          let v1205_7: Space = routine_164(c, &(v1205_6), &(*p1), &(v1203_7_tail));
          compose(&(v1204_5),&(v1205_7))
        };
        drop(v1204_5);
        let v1204_9: Space = intersect(&(*CONSTANT_2),&(v1204_2));
        drop(v1204_2);
        let v1204_10: Space = if has_head(&(v1204_9)) { singleton(&[]) } else { Space::new() };
        drop(v1204_9);
        let v1204_12: Space = if (v1204_10).is_empty() { Space::new() } else {
          let v1206_6: Path = concat_path(&(v1203_6),&(v1203_7_head));
          let v1206_11: Space = routine_165(c, &(v1206_6), &(*p1), &(v1203_7_tail));
          drop(v1206_6);
          compose(&(v1204_10),&(v1206_11))
        };
        drop(v1204_10);
        let v1204_13: Space = unite(&(v1204_8),&(v1204_12));
        v1203_7.join_into((v1204_13).clone());
      }
      drop(v1203_7_cursor);
      compose(&(v1202_5),&(v1203_7))
    };
    drop(v1202_5);
    let v1202_9: Space = intersect(&(*CONSTANT_2),&(v1202_2));
    drop(v1202_2);
    let v1202_10: Space = if has_head(&(v1202_9)) { singleton(&[]) } else { Space::new() };
    drop(v1202_9);
    let v1202_12: Space = if (v1202_10).is_empty() { Space::new() } else {
      let v1207_6: Path = concat_path(&(*p0),&(v1201_12_head));
      let mut v1207_11 = Space::new();
      let mut v1207_11_cursor = (v1201_12_tail).read_zipper();
      for v1207_11_byte in v1207_11_cursor.child_mask().iter() {
        v1207_11_cursor.descend_to_byte(v1207_11_byte);
        let v1207_11_tail = v1207_11_cursor.make_map();
        v1207_11_cursor.ascend(1);
        let v1207_11_head = Path::from_slice(&[v1207_11_byte]);
        let v1208_2: Space = singleton(&(v1207_11_head));
        let v1208_3: Space = intersect(&(*CONSTANT_2),&(v1208_2));
        let v1208_4: Space = if has_head(&(v1208_3)) { singleton(&[]) } else { Space::new() };
        drop(v1208_3);
        let v1208_5: Space = subtract(&(*CONSTANT_1),&(v1208_4));
        drop(v1208_4);
        let v1208_8: Space = if (v1208_5).is_empty() { Space::new() } else {
          let v1209_6: Path = concat_path(&(v1207_6),&(v1207_11_head));
          let v1209_7: Space = routine_164(c, &(v1209_6), &(*p1), &(v1207_11_tail));
          compose(&(v1208_5),&(v1209_7))
        };
        drop(v1208_5);
        let v1208_9: Space = intersect(&(*CONSTANT_2),&(v1208_2));
        drop(v1208_2);
        let v1208_10: Space = if has_head(&(v1208_9)) { singleton(&[]) } else { Space::new() };
        drop(v1208_9);
        let v1208_12: Space = if (v1208_10).is_empty() { Space::new() } else {
          let v1210_6: Path = concat_path(&(v1207_6),&(v1207_11_head));
          let v1210_11: Space = routine_89(c, &(v1210_6), &(*p1), &(v1207_11_tail));
          drop(v1210_6);
          compose(&(v1208_10),&(v1210_11))
        };
        drop(v1208_10);
        let v1208_13: Space = unite(&(v1208_8),&(v1208_12));
        v1207_11.join_into((v1208_13).clone());
      }
      drop(v1207_11_cursor);
      drop(v1207_6);
      compose(&(v1202_10),&(v1207_11))
    };
    drop(v1202_10);
    let v1202_13: Space = unite(&(v1202_8),&(v1202_12));
    v1201_12.join_into((v1202_13).clone());
  }
  drop(v1201_12_cursor);
  (v1201_12).clone()
}

fn routine_131(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1211_9 = Space::new();
  let mut v1211_9_cursor = (*s0).read_zipper();
  for v1211_9_byte in v1211_9_cursor.child_mask().iter() {
    v1211_9_cursor.descend_to_byte(v1211_9_byte);
    let v1211_9_tail = v1211_9_cursor.make_map();
    v1211_9_cursor.ascend(1);
    let v1211_9_head = Path::from_slice(&[v1211_9_byte]);
    let v1212_2: Space = singleton(&(v1211_9_head));
    let v1212_3: Space = intersect(&(*CONSTANT_2),&(v1212_2));
    let v1212_4: Space = if has_head(&(v1212_3)) { singleton(&[]) } else { Space::new() };
    drop(v1212_3);
    let v1212_5: Space = subtract(&(*CONSTANT_1),&(v1212_4));
    drop(v1212_4);
    let v1212_8: Space = if (v1212_5).is_empty() { Space::new() } else {
      let v1213_6: Path = concat_path(&(*p0),&(v1211_9_head));
      let mut v1213_7 = Space::new();
      let mut v1213_7_cursor = (v1211_9_tail).read_zipper();
      for v1213_7_byte in v1213_7_cursor.child_mask().iter() {
        v1213_7_cursor.descend_to_byte(v1213_7_byte);
        let v1213_7_tail = v1213_7_cursor.make_map();
        v1213_7_cursor.ascend(1);
        let v1213_7_head = Path::from_slice(&[v1213_7_byte]);
        let v1214_2: Space = singleton(&(v1213_7_head));
        let v1214_3: Space = intersect(&(*CONSTANT_2),&(v1214_2));
        let v1214_4: Space = if has_head(&(v1214_3)) { singleton(&[]) } else { Space::new() };
        drop(v1214_3);
        let v1214_5: Space = subtract(&(*CONSTANT_1),&(v1214_4));
        drop(v1214_4);
        let v1214_8: Space = if (v1214_5).is_empty() { Space::new() } else {
          let v1215_6: Path = concat_path(&(v1213_6),&(v1213_7_head));
          let v1215_7: Space = routine_164(c, &(v1215_6), &(*p1), &(v1213_7_tail));
          compose(&(v1214_5),&(v1215_7))
        };
        drop(v1214_5);
        let v1214_9: Space = intersect(&(*CONSTANT_2),&(v1214_2));
        drop(v1214_2);
        let v1214_10: Space = if has_head(&(v1214_9)) { singleton(&[]) } else { Space::new() };
        drop(v1214_9);
        let v1214_12: Space = if (v1214_10).is_empty() { Space::new() } else {
          let v1216_6: Path = concat_path(&(v1213_6),&(v1213_7_head));
          let v1216_11: Space = routine_165(c, &(v1216_6), &(*p1), &(v1213_7_tail));
          drop(v1216_6);
          compose(&(v1214_10),&(v1216_11))
        };
        drop(v1214_10);
        let v1214_13: Space = unite(&(v1214_8),&(v1214_12));
        v1213_7.join_into((v1214_13).clone());
      }
      drop(v1213_7_cursor);
      compose(&(v1212_5),&(v1213_7))
    };
    drop(v1212_5);
    let v1212_9: Space = intersect(&(*CONSTANT_2),&(v1212_2));
    drop(v1212_2);
    let v1212_10: Space = if has_head(&(v1212_9)) { singleton(&[]) } else { Space::new() };
    drop(v1212_9);
    let v1212_11: Space = compose(&(v1212_10),&(v1211_9_tail));
    drop(v1212_10);
    let v1217_6: Path = concat_path(&(*p0),&(v1211_9_head));
    let v1212_12: Space = wrap(&(v1212_11),&(v1217_6));
    drop(v1212_11);
    let v1212_13: Space = wrap(&(v1212_12),&(*p1));
    drop(v1212_12);
    let v1212_14: Space = unite(&(v1212_8),&(v1212_13));
    drop(v1212_13);
    v1211_9.join_into((v1212_14).clone());
  }
  drop(v1211_9_cursor);
  (v1211_9).clone()
}

fn routine_132(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v1218_6 = Space::new();
  let mut v1218_6_cursor = (*s0).read_zipper();
  for v1218_6_byte in v1218_6_cursor.child_mask().iter() {
    v1218_6_cursor.descend_to_byte(v1218_6_byte);
    let v1218_6_tail = v1218_6_cursor.make_map();
    v1218_6_cursor.ascend(1);
    let v1218_6_head = Path::from_slice(&[v1218_6_byte]);
    let v1219_2: Space = singleton(&(v1218_6_head));
    let v1219_3: Space = intersect(&(*CONSTANT_2),&(v1219_2));
    let v1219_4: Space = if has_head(&(v1219_3)) { singleton(&[]) } else { Space::new() };
    drop(v1219_3);
    let v1219_5: Space = subtract(&(*CONSTANT_1),&(v1219_4));
    drop(v1219_4);
    let mut v1219_6 = Space::new();
    let mut v1219_6_cursor = (v1218_6_tail).read_zipper();
    for v1219_6_byte in v1219_6_cursor.child_mask().iter() {
      v1219_6_cursor.descend_to_byte(v1219_6_byte);
      let v1219_6_tail = v1219_6_cursor.make_map();
      v1219_6_cursor.ascend(1);
      let v1219_6_head = Path::from_slice(&[v1219_6_byte]);
      let v1220_2: Space = Space::new();
      v1219_6.join_into((v1220_2).clone());
    }
    drop(v1219_6_cursor);
    let v1219_7: Space = compose(&(v1219_5),&(v1219_6));
    drop(v1219_5);
    drop(v1219_6);
    let v1219_8: Space = intersect(&(*CONSTANT_2),&(v1219_2));
    drop(v1219_2);
    let v1219_9: Space = if has_head(&(v1219_8)) { singleton(&[]) } else { Space::new() };
    drop(v1219_8);
    let v1219_12: Space = if (v1219_9).is_empty() { Space::new() } else {
      let v1221_10: Path = concat_path(&(*p0),&(v1218_6_head));
      let mut v1221_11 = Space::new();
      let mut v1221_11_cursor = (v1218_6_tail).read_zipper();
      for v1221_11_byte in v1221_11_cursor.child_mask().iter() {
        v1221_11_cursor.descend_to_byte(v1221_11_byte);
        let v1221_11_tail = v1221_11_cursor.make_map();
        v1221_11_cursor.ascend(1);
        let v1221_11_head = Path::from_slice(&[v1221_11_byte]);
        let v1222_2: Space = singleton(&(v1221_11_head));
        let v1222_3: Space = intersect(&(*CONSTANT_2),&(v1222_2));
        drop(v1222_2);
        let v1222_4: Space = if has_head(&(v1222_3)) { singleton(&[]) } else { Space::new() };
        drop(v1222_3);
        let v1222_7: Space = if (v1222_4).is_empty() { Space::new() } else {
          let v1223_5: Path = concat_path(&(v1221_10),&(v1221_11_head));
          let v1223_6: Space = routine_15(c, &(v1223_5), &(v1221_11_tail));
          drop(v1223_5);
          compose(&(v1222_4),&(v1223_6))
        };
        drop(v1222_4);
        v1221_11.join_into((v1222_7).clone());
      }
      drop(v1221_11_cursor);
      drop(v1221_10);
      compose(&(v1219_9),&(v1221_11))
    };
    drop(v1219_9);
    let v1219_13: Space = unite(&(v1219_7),&(v1219_12));
    drop(v1219_7);
    v1218_6.join_into((v1219_13).clone());
  }
  drop(v1218_6_cursor);
  (v1218_6).clone()
}

fn routine_133(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v1224_8 = Space::new();
  let mut v1224_8_cursor = (*s0).read_zipper();
  for v1224_8_byte in v1224_8_cursor.child_mask().iter() {
    v1224_8_cursor.descend_to_byte(v1224_8_byte);
    let v1224_8_tail = v1224_8_cursor.make_map();
    v1224_8_cursor.ascend(1);
    let v1224_8_head = Path::from_slice(&[v1224_8_byte]);
    let v1225_2: Space = singleton(&(v1224_8_head));
    let v1225_3: Space = intersect(&(*CONSTANT_2),&(v1225_2));
    let v1225_4: Space = if has_head(&(v1225_3)) { singleton(&[]) } else { Space::new() };
    drop(v1225_3);
    let v1225_5: Space = subtract(&(*CONSTANT_1),&(v1225_4));
    drop(v1225_4);
    let mut v1225_6 = Space::new();
    let mut v1225_6_cursor = (v1224_8_tail).read_zipper();
    for v1225_6_byte in v1225_6_cursor.child_mask().iter() {
      v1225_6_cursor.descend_to_byte(v1225_6_byte);
      let v1225_6_tail = v1225_6_cursor.make_map();
      v1225_6_cursor.ascend(1);
      let v1225_6_head = Path::from_slice(&[v1225_6_byte]);
      let v1226_2: Space = Space::new();
      v1225_6.join_into((v1226_2).clone());
    }
    drop(v1225_6_cursor);
    let v1225_7: Space = compose(&(v1225_5),&(v1225_6));
    drop(v1225_5);
    drop(v1225_6);
    let v1225_8: Space = intersect(&(*CONSTANT_2),&(v1225_2));
    drop(v1225_2);
    let v1225_9: Space = if has_head(&(v1225_8)) { singleton(&[]) } else { Space::new() };
    drop(v1225_8);
    let v1225_12: Space = if (v1225_9).is_empty() { Space::new() } else {
      let v1227_10: Path = concat_path(&(*p0),&(v1224_8_head));
      let mut v1227_11 = Space::new();
      let mut v1227_11_cursor = (v1224_8_tail).read_zipper();
      for v1227_11_byte in v1227_11_cursor.child_mask().iter() {
        v1227_11_cursor.descend_to_byte(v1227_11_byte);
        let v1227_11_tail = v1227_11_cursor.make_map();
        v1227_11_cursor.ascend(1);
        let v1227_11_head = Path::from_slice(&[v1227_11_byte]);
        let v1228_2: Space = singleton(&(v1227_11_head));
        let v1228_3: Space = intersect(&(*CONSTANT_2),&(v1228_2));
        let v1228_4: Space = if has_head(&(v1228_3)) { singleton(&[]) } else { Space::new() };
        drop(v1228_3);
        let v1228_5: Space = subtract(&(*CONSTANT_1),&(v1228_4));
        drop(v1228_4);
        let v1228_7: Space = if (v1228_5).is_empty() { Space::new() } else {
          let v1229_6: Space = routine_46(c, &(v1227_11_head), &(v1227_10), &(v1227_11_tail));
          compose(&(v1228_5),&(v1229_6))
        };
        drop(v1228_5);
        let v1228_8: Space = intersect(&(*CONSTANT_2),&(v1228_2));
        drop(v1228_2);
        let v1228_9: Space = if has_head(&(v1228_8)) { singleton(&[]) } else { Space::new() };
        drop(v1228_8);
        let v1228_11: Space = if (v1228_9).is_empty() { Space::new() } else {
          let v1230_10: Space = routine_47(c, &(v1227_11_head), &(v1227_10), &(v1227_11_tail));
          compose(&(v1228_9),&(v1230_10))
        };
        drop(v1228_9);
        let v1228_12: Space = unite(&(v1228_7),&(v1228_11));
        v1227_11.join_into((v1228_12).clone());
      }
      drop(v1227_11_cursor);
      drop(v1227_10);
      compose(&(v1225_9),&(v1227_11))
    };
    drop(v1225_9);
    let v1225_13: Space = unite(&(v1225_7),&(v1225_12));
    drop(v1225_7);
    v1224_8.join_into((v1225_13).clone());
  }
  drop(v1224_8_cursor);
  (v1224_8).clone()
}

fn routine_134(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1231_12 = Space::new();
  let mut v1231_12_cursor = (*s0).read_zipper();
  for v1231_12_byte in v1231_12_cursor.child_mask().iter() {
    v1231_12_cursor.descend_to_byte(v1231_12_byte);
    let v1231_12_tail = v1231_12_cursor.make_map();
    v1231_12_cursor.ascend(1);
    let v1231_12_head = Path::from_slice(&[v1231_12_byte]);
    let v1232_2: Space = singleton(&(v1231_12_head));
    let v1232_3: Space = intersect(&(*CONSTANT_2),&(v1232_2));
    let v1232_4: Space = if has_head(&(v1232_3)) { singleton(&[]) } else { Space::new() };
    drop(v1232_3);
    let v1232_5: Space = subtract(&(*CONSTANT_1),&(v1232_4));
    drop(v1232_4);
    let v1232_8: Space = if (v1232_5).is_empty() { Space::new() } else {
      let v1233_6: Path = concat_path(&(*p0),&(v1231_12_head));
      let mut v1233_7 = Space::new();
      let mut v1233_7_cursor = (v1231_12_tail).read_zipper();
      for v1233_7_byte in v1233_7_cursor.child_mask().iter() {
        v1233_7_cursor.descend_to_byte(v1233_7_byte);
        let v1233_7_tail = v1233_7_cursor.make_map();
        v1233_7_cursor.ascend(1);
        let v1233_7_head = Path::from_slice(&[v1233_7_byte]);
        let v1234_2: Space = singleton(&(v1233_7_head));
        let v1234_3: Space = intersect(&(*CONSTANT_2),&(v1234_2));
        let v1234_4: Space = if has_head(&(v1234_3)) { singleton(&[]) } else { Space::new() };
        drop(v1234_3);
        let v1234_5: Space = subtract(&(*CONSTANT_1),&(v1234_4));
        drop(v1234_4);
        let v1234_8: Space = if (v1234_5).is_empty() { Space::new() } else {
          let v1235_6: Path = concat_path(&(v1233_6),&(v1233_7_head));
          let v1235_7: Space = routine_166(c, &(v1235_6), &(*p1), &(v1233_7_tail));
          compose(&(v1234_5),&(v1235_7))
        };
        drop(v1234_5);
        let v1234_9: Space = intersect(&(*CONSTANT_2),&(v1234_2));
        drop(v1234_2);
        let v1234_10: Space = if has_head(&(v1234_9)) { singleton(&[]) } else { Space::new() };
        drop(v1234_9);
        let v1234_12: Space = if (v1234_10).is_empty() { Space::new() } else {
          let v1236_6: Path = concat_path(&(v1233_6),&(v1233_7_head));
          let v1236_11: Space = routine_167(c, &(v1236_6), &(*p1), &(v1233_7_tail));
          drop(v1236_6);
          compose(&(v1234_10),&(v1236_11))
        };
        drop(v1234_10);
        let v1234_13: Space = unite(&(v1234_8),&(v1234_12));
        v1233_7.join_into((v1234_13).clone());
      }
      drop(v1233_7_cursor);
      compose(&(v1232_5),&(v1233_7))
    };
    drop(v1232_5);
    let v1232_9: Space = intersect(&(*CONSTANT_2),&(v1232_2));
    drop(v1232_2);
    let v1232_10: Space = if has_head(&(v1232_9)) { singleton(&[]) } else { Space::new() };
    drop(v1232_9);
    let v1232_12: Space = if (v1232_10).is_empty() { Space::new() } else {
      let v1237_6: Path = concat_path(&(*p0),&(v1231_12_head));
      let mut v1237_11 = Space::new();
      let mut v1237_11_cursor = (v1231_12_tail).read_zipper();
      for v1237_11_byte in v1237_11_cursor.child_mask().iter() {
        v1237_11_cursor.descend_to_byte(v1237_11_byte);
        let v1237_11_tail = v1237_11_cursor.make_map();
        v1237_11_cursor.ascend(1);
        let v1237_11_head = Path::from_slice(&[v1237_11_byte]);
        let v1238_2: Space = singleton(&(v1237_11_head));
        let v1238_3: Space = intersect(&(*CONSTANT_2),&(v1238_2));
        let v1238_4: Space = if has_head(&(v1238_3)) { singleton(&[]) } else { Space::new() };
        drop(v1238_3);
        let v1238_5: Space = subtract(&(*CONSTANT_1),&(v1238_4));
        drop(v1238_4);
        let v1238_8: Space = if (v1238_5).is_empty() { Space::new() } else {
          let v1239_6: Path = concat_path(&(v1237_6),&(v1237_11_head));
          let v1239_7: Space = routine_166(c, &(v1239_6), &(*p1), &(v1237_11_tail));
          compose(&(v1238_5),&(v1239_7))
        };
        drop(v1238_5);
        let v1238_9: Space = intersect(&(*CONSTANT_2),&(v1238_2));
        drop(v1238_2);
        let v1238_10: Space = if has_head(&(v1238_9)) { singleton(&[]) } else { Space::new() };
        drop(v1238_9);
        let v1238_12: Space = if (v1238_10).is_empty() { Space::new() } else {
          let v1240_6: Path = concat_path(&(v1237_6),&(v1237_11_head));
          let v1240_11: Space = routine_50(c, &(v1240_6), &(*p1), &(v1237_11_tail));
          drop(v1240_6);
          compose(&(v1238_10),&(v1240_11))
        };
        drop(v1238_10);
        let v1238_13: Space = unite(&(v1238_8),&(v1238_12));
        v1237_11.join_into((v1238_13).clone());
      }
      drop(v1237_11_cursor);
      drop(v1237_6);
      compose(&(v1232_10),&(v1237_11))
    };
    drop(v1232_10);
    let v1232_13: Space = unite(&(v1232_8),&(v1232_12));
    v1231_12.join_into((v1232_13).clone());
  }
  drop(v1231_12_cursor);
  (v1231_12).clone()
}

fn routine_135(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1241_9 = Space::new();
  let mut v1241_9_cursor = (*s0).read_zipper();
  for v1241_9_byte in v1241_9_cursor.child_mask().iter() {
    v1241_9_cursor.descend_to_byte(v1241_9_byte);
    let v1241_9_tail = v1241_9_cursor.make_map();
    v1241_9_cursor.ascend(1);
    let v1241_9_head = Path::from_slice(&[v1241_9_byte]);
    let v1242_2: Space = singleton(&(v1241_9_head));
    let v1242_3: Space = intersect(&(*CONSTANT_2),&(v1242_2));
    let v1242_4: Space = if has_head(&(v1242_3)) { singleton(&[]) } else { Space::new() };
    drop(v1242_3);
    let v1242_5: Space = subtract(&(*CONSTANT_1),&(v1242_4));
    drop(v1242_4);
    let v1242_8: Space = if (v1242_5).is_empty() { Space::new() } else {
      let v1243_6: Path = concat_path(&(*p0),&(v1241_9_head));
      let mut v1243_7 = Space::new();
      let mut v1243_7_cursor = (v1241_9_tail).read_zipper();
      for v1243_7_byte in v1243_7_cursor.child_mask().iter() {
        v1243_7_cursor.descend_to_byte(v1243_7_byte);
        let v1243_7_tail = v1243_7_cursor.make_map();
        v1243_7_cursor.ascend(1);
        let v1243_7_head = Path::from_slice(&[v1243_7_byte]);
        let v1244_2: Space = singleton(&(v1243_7_head));
        let v1244_3: Space = intersect(&(*CONSTANT_2),&(v1244_2));
        let v1244_4: Space = if has_head(&(v1244_3)) { singleton(&[]) } else { Space::new() };
        drop(v1244_3);
        let v1244_5: Space = subtract(&(*CONSTANT_1),&(v1244_4));
        drop(v1244_4);
        let v1244_8: Space = if (v1244_5).is_empty() { Space::new() } else {
          let v1245_6: Path = concat_path(&(v1243_6),&(v1243_7_head));
          let v1245_7: Space = routine_166(c, &(v1245_6), &(*p1), &(v1243_7_tail));
          compose(&(v1244_5),&(v1245_7))
        };
        drop(v1244_5);
        let v1244_9: Space = intersect(&(*CONSTANT_2),&(v1244_2));
        drop(v1244_2);
        let v1244_10: Space = if has_head(&(v1244_9)) { singleton(&[]) } else { Space::new() };
        drop(v1244_9);
        let v1244_12: Space = if (v1244_10).is_empty() { Space::new() } else {
          let v1246_6: Path = concat_path(&(v1243_6),&(v1243_7_head));
          let v1246_11: Space = routine_167(c, &(v1246_6), &(*p1), &(v1243_7_tail));
          drop(v1246_6);
          compose(&(v1244_10),&(v1246_11))
        };
        drop(v1244_10);
        let v1244_13: Space = unite(&(v1244_8),&(v1244_12));
        v1243_7.join_into((v1244_13).clone());
      }
      drop(v1243_7_cursor);
      compose(&(v1242_5),&(v1243_7))
    };
    drop(v1242_5);
    let v1242_9: Space = intersect(&(*CONSTANT_2),&(v1242_2));
    drop(v1242_2);
    let v1242_10: Space = if has_head(&(v1242_9)) { singleton(&[]) } else { Space::new() };
    drop(v1242_9);
    let v1242_11: Space = compose(&(v1242_10),&(v1241_9_tail));
    drop(v1242_10);
    let v1247_6: Path = concat_path(&(*p0),&(v1241_9_head));
    let v1242_12: Space = wrap(&(v1242_11),&(v1247_6));
    drop(v1242_11);
    let v1242_13: Space = wrap(&(v1242_12),&(*p1));
    drop(v1242_12);
    let v1242_14: Space = unite(&(v1242_8),&(v1242_13));
    drop(v1242_13);
    v1241_9.join_into((v1242_14).clone());
  }
  drop(v1241_9_cursor);
  (v1241_9).clone()
}

fn routine_136(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1248_12 = Space::new();
  let mut v1248_12_cursor = (*s0).read_zipper();
  for v1248_12_byte in v1248_12_cursor.child_mask().iter() {
    v1248_12_cursor.descend_to_byte(v1248_12_byte);
    let v1248_12_tail = v1248_12_cursor.make_map();
    v1248_12_cursor.ascend(1);
    let v1248_12_head = Path::from_slice(&[v1248_12_byte]);
    let v1249_2: Space = singleton(&(v1248_12_head));
    let v1249_3: Space = intersect(&(*CONSTANT_2),&(v1249_2));
    let v1249_4: Space = if has_head(&(v1249_3)) { singleton(&[]) } else { Space::new() };
    drop(v1249_3);
    let v1249_5: Space = subtract(&(*CONSTANT_1),&(v1249_4));
    drop(v1249_4);
    let v1249_8: Space = if (v1249_5).is_empty() { Space::new() } else {
      let v1250_6: Path = concat_path(&(*p0),&(v1248_12_head));
      let mut v1250_7 = Space::new();
      let mut v1250_7_cursor = (v1248_12_tail).read_zipper();
      for v1250_7_byte in v1250_7_cursor.child_mask().iter() {
        v1250_7_cursor.descend_to_byte(v1250_7_byte);
        let v1250_7_tail = v1250_7_cursor.make_map();
        v1250_7_cursor.ascend(1);
        let v1250_7_head = Path::from_slice(&[v1250_7_byte]);
        let v1251_2: Space = singleton(&(v1250_7_head));
        let v1251_3: Space = intersect(&(*CONSTANT_2),&(v1251_2));
        let v1251_4: Space = if has_head(&(v1251_3)) { singleton(&[]) } else { Space::new() };
        drop(v1251_3);
        let v1251_5: Space = subtract(&(*CONSTANT_1),&(v1251_4));
        drop(v1251_4);
        let v1251_8: Space = if (v1251_5).is_empty() { Space::new() } else {
          let v1252_6: Path = concat_path(&(v1250_6),&(v1250_7_head));
          let v1252_7: Space = routine_168(c, &(v1252_6), &(*p1), &(v1250_7_tail));
          compose(&(v1251_5),&(v1252_7))
        };
        drop(v1251_5);
        let v1251_9: Space = intersect(&(*CONSTANT_2),&(v1251_2));
        drop(v1251_2);
        let v1251_10: Space = if has_head(&(v1251_9)) { singleton(&[]) } else { Space::new() };
        drop(v1251_9);
        let v1251_12: Space = if (v1251_10).is_empty() { Space::new() } else {
          let v1253_6: Path = concat_path(&(v1250_6),&(v1250_7_head));
          let v1253_11: Space = routine_169(c, &(v1253_6), &(*p1), &(v1250_7_tail));
          drop(v1253_6);
          compose(&(v1251_10),&(v1253_11))
        };
        drop(v1251_10);
        let v1251_13: Space = unite(&(v1251_8),&(v1251_12));
        v1250_7.join_into((v1251_13).clone());
      }
      drop(v1250_7_cursor);
      compose(&(v1249_5),&(v1250_7))
    };
    drop(v1249_5);
    let v1249_9: Space = intersect(&(*CONSTANT_2),&(v1249_2));
    drop(v1249_2);
    let v1249_10: Space = if has_head(&(v1249_9)) { singleton(&[]) } else { Space::new() };
    drop(v1249_9);
    let v1249_12: Space = if (v1249_10).is_empty() { Space::new() } else {
      let v1254_6: Path = concat_path(&(*p0),&(v1248_12_head));
      let mut v1254_11 = Space::new();
      let mut v1254_11_cursor = (v1248_12_tail).read_zipper();
      for v1254_11_byte in v1254_11_cursor.child_mask().iter() {
        v1254_11_cursor.descend_to_byte(v1254_11_byte);
        let v1254_11_tail = v1254_11_cursor.make_map();
        v1254_11_cursor.ascend(1);
        let v1254_11_head = Path::from_slice(&[v1254_11_byte]);
        let v1255_2: Space = singleton(&(v1254_11_head));
        let v1255_3: Space = intersect(&(*CONSTANT_2),&(v1255_2));
        let v1255_4: Space = if has_head(&(v1255_3)) { singleton(&[]) } else { Space::new() };
        drop(v1255_3);
        let v1255_5: Space = subtract(&(*CONSTANT_1),&(v1255_4));
        drop(v1255_4);
        let v1255_8: Space = if (v1255_5).is_empty() { Space::new() } else {
          let v1256_6: Path = concat_path(&(v1254_6),&(v1254_11_head));
          let v1256_7: Space = routine_168(c, &(v1256_6), &(*p1), &(v1254_11_tail));
          compose(&(v1255_5),&(v1256_7))
        };
        drop(v1255_5);
        let v1255_9: Space = intersect(&(*CONSTANT_2),&(v1255_2));
        drop(v1255_2);
        let v1255_10: Space = if has_head(&(v1255_9)) { singleton(&[]) } else { Space::new() };
        drop(v1255_9);
        let v1255_12: Space = if (v1255_10).is_empty() { Space::new() } else {
          let v1257_6: Path = concat_path(&(v1254_6),&(v1254_11_head));
          let v1257_11: Space = routine_50(c, &(v1257_6), &(*p1), &(v1254_11_tail));
          drop(v1257_6);
          compose(&(v1255_10),&(v1257_11))
        };
        drop(v1255_10);
        let v1255_13: Space = unite(&(v1255_8),&(v1255_12));
        v1254_11.join_into((v1255_13).clone());
      }
      drop(v1254_11_cursor);
      drop(v1254_6);
      compose(&(v1249_10),&(v1254_11))
    };
    drop(v1249_10);
    let v1249_13: Space = unite(&(v1249_8),&(v1249_12));
    v1248_12.join_into((v1249_13).clone());
  }
  drop(v1248_12_cursor);
  (v1248_12).clone()
}

fn routine_137(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1258_9 = Space::new();
  let mut v1258_9_cursor = (*s0).read_zipper();
  for v1258_9_byte in v1258_9_cursor.child_mask().iter() {
    v1258_9_cursor.descend_to_byte(v1258_9_byte);
    let v1258_9_tail = v1258_9_cursor.make_map();
    v1258_9_cursor.ascend(1);
    let v1258_9_head = Path::from_slice(&[v1258_9_byte]);
    let v1259_2: Space = singleton(&(v1258_9_head));
    let v1259_3: Space = intersect(&(*CONSTANT_2),&(v1259_2));
    let v1259_4: Space = if has_head(&(v1259_3)) { singleton(&[]) } else { Space::new() };
    drop(v1259_3);
    let v1259_5: Space = subtract(&(*CONSTANT_1),&(v1259_4));
    drop(v1259_4);
    let v1259_8: Space = if (v1259_5).is_empty() { Space::new() } else {
      let v1260_6: Path = concat_path(&(*p0),&(v1258_9_head));
      let mut v1260_7 = Space::new();
      let mut v1260_7_cursor = (v1258_9_tail).read_zipper();
      for v1260_7_byte in v1260_7_cursor.child_mask().iter() {
        v1260_7_cursor.descend_to_byte(v1260_7_byte);
        let v1260_7_tail = v1260_7_cursor.make_map();
        v1260_7_cursor.ascend(1);
        let v1260_7_head = Path::from_slice(&[v1260_7_byte]);
        let v1261_2: Space = singleton(&(v1260_7_head));
        let v1261_3: Space = intersect(&(*CONSTANT_2),&(v1261_2));
        let v1261_4: Space = if has_head(&(v1261_3)) { singleton(&[]) } else { Space::new() };
        drop(v1261_3);
        let v1261_5: Space = subtract(&(*CONSTANT_1),&(v1261_4));
        drop(v1261_4);
        let v1261_8: Space = if (v1261_5).is_empty() { Space::new() } else {
          let v1262_6: Path = concat_path(&(v1260_6),&(v1260_7_head));
          let v1262_7: Space = routine_168(c, &(v1262_6), &(*p1), &(v1260_7_tail));
          compose(&(v1261_5),&(v1262_7))
        };
        drop(v1261_5);
        let v1261_9: Space = intersect(&(*CONSTANT_2),&(v1261_2));
        drop(v1261_2);
        let v1261_10: Space = if has_head(&(v1261_9)) { singleton(&[]) } else { Space::new() };
        drop(v1261_9);
        let v1261_12: Space = if (v1261_10).is_empty() { Space::new() } else {
          let v1263_6: Path = concat_path(&(v1260_6),&(v1260_7_head));
          let v1263_11: Space = routine_169(c, &(v1263_6), &(*p1), &(v1260_7_tail));
          drop(v1263_6);
          compose(&(v1261_10),&(v1263_11))
        };
        drop(v1261_10);
        let v1261_13: Space = unite(&(v1261_8),&(v1261_12));
        v1260_7.join_into((v1261_13).clone());
      }
      drop(v1260_7_cursor);
      compose(&(v1259_5),&(v1260_7))
    };
    drop(v1259_5);
    let v1259_9: Space = intersect(&(*CONSTANT_2),&(v1259_2));
    drop(v1259_2);
    let v1259_10: Space = if has_head(&(v1259_9)) { singleton(&[]) } else { Space::new() };
    drop(v1259_9);
    let v1259_11: Space = compose(&(v1259_10),&(v1258_9_tail));
    drop(v1259_10);
    let v1264_6: Path = concat_path(&(*p0),&(v1258_9_head));
    let v1259_12: Space = wrap(&(v1259_11),&(v1264_6));
    drop(v1259_11);
    let v1259_13: Space = wrap(&(v1259_12),&(*p1));
    drop(v1259_12);
    let v1259_14: Space = unite(&(v1259_8),&(v1259_13));
    drop(v1259_13);
    v1258_9.join_into((v1259_14).clone());
  }
  drop(v1258_9_cursor);
  (v1258_9).clone()
}

fn routine_138(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1265_12 = Space::new();
  let mut v1265_12_cursor = (*s0).read_zipper();
  for v1265_12_byte in v1265_12_cursor.child_mask().iter() {
    v1265_12_cursor.descend_to_byte(v1265_12_byte);
    let v1265_12_tail = v1265_12_cursor.make_map();
    v1265_12_cursor.ascend(1);
    let v1265_12_head = Path::from_slice(&[v1265_12_byte]);
    let v1266_2: Space = singleton(&(v1265_12_head));
    let v1266_3: Space = intersect(&(*CONSTANT_2),&(v1266_2));
    let v1266_4: Space = if has_head(&(v1266_3)) { singleton(&[]) } else { Space::new() };
    drop(v1266_3);
    let v1266_5: Space = subtract(&(*CONSTANT_1),&(v1266_4));
    drop(v1266_4);
    let v1266_8: Space = if (v1266_5).is_empty() { Space::new() } else {
      let v1267_6: Path = concat_path(&(*p0),&(v1265_12_head));
      let mut v1267_7 = Space::new();
      let mut v1267_7_cursor = (v1265_12_tail).read_zipper();
      for v1267_7_byte in v1267_7_cursor.child_mask().iter() {
        v1267_7_cursor.descend_to_byte(v1267_7_byte);
        let v1267_7_tail = v1267_7_cursor.make_map();
        v1267_7_cursor.ascend(1);
        let v1267_7_head = Path::from_slice(&[v1267_7_byte]);
        let v1268_2: Space = singleton(&(v1267_7_head));
        let v1268_3: Space = intersect(&(*CONSTANT_2),&(v1268_2));
        let v1268_4: Space = if has_head(&(v1268_3)) { singleton(&[]) } else { Space::new() };
        drop(v1268_3);
        let v1268_5: Space = subtract(&(*CONSTANT_1),&(v1268_4));
        drop(v1268_4);
        let v1268_8: Space = if (v1268_5).is_empty() { Space::new() } else {
          let v1269_6: Path = concat_path(&(v1267_6),&(v1267_7_head));
          let v1269_7: Space = routine_170(c, &(v1269_6), &(*p1), &(v1267_7_tail));
          compose(&(v1268_5),&(v1269_7))
        };
        drop(v1268_5);
        let v1268_9: Space = intersect(&(*CONSTANT_2),&(v1268_2));
        drop(v1268_2);
        let v1268_10: Space = if has_head(&(v1268_9)) { singleton(&[]) } else { Space::new() };
        drop(v1268_9);
        let v1268_12: Space = if (v1268_10).is_empty() { Space::new() } else {
          let v1270_6: Path = concat_path(&(v1267_6),&(v1267_7_head));
          let v1270_11: Space = routine_171(c, &(v1270_6), &(*p1), &(v1267_7_tail));
          drop(v1270_6);
          compose(&(v1268_10),&(v1270_11))
        };
        drop(v1268_10);
        let v1268_13: Space = unite(&(v1268_8),&(v1268_12));
        v1267_7.join_into((v1268_13).clone());
      }
      drop(v1267_7_cursor);
      compose(&(v1266_5),&(v1267_7))
    };
    drop(v1266_5);
    let v1266_9: Space = intersect(&(*CONSTANT_2),&(v1266_2));
    drop(v1266_2);
    let v1266_10: Space = if has_head(&(v1266_9)) { singleton(&[]) } else { Space::new() };
    drop(v1266_9);
    let v1266_12: Space = if (v1266_10).is_empty() { Space::new() } else {
      let v1271_6: Path = concat_path(&(*p0),&(v1265_12_head));
      let mut v1271_11 = Space::new();
      let mut v1271_11_cursor = (v1265_12_tail).read_zipper();
      for v1271_11_byte in v1271_11_cursor.child_mask().iter() {
        v1271_11_cursor.descend_to_byte(v1271_11_byte);
        let v1271_11_tail = v1271_11_cursor.make_map();
        v1271_11_cursor.ascend(1);
        let v1271_11_head = Path::from_slice(&[v1271_11_byte]);
        let v1272_2: Space = singleton(&(v1271_11_head));
        let v1272_3: Space = intersect(&(*CONSTANT_2),&(v1272_2));
        let v1272_4: Space = if has_head(&(v1272_3)) { singleton(&[]) } else { Space::new() };
        drop(v1272_3);
        let v1272_5: Space = subtract(&(*CONSTANT_1),&(v1272_4));
        drop(v1272_4);
        let v1272_8: Space = if (v1272_5).is_empty() { Space::new() } else {
          let v1273_6: Path = concat_path(&(v1271_6),&(v1271_11_head));
          let v1273_7: Space = routine_170(c, &(v1273_6), &(*p1), &(v1271_11_tail));
          compose(&(v1272_5),&(v1273_7))
        };
        drop(v1272_5);
        let v1272_9: Space = intersect(&(*CONSTANT_2),&(v1272_2));
        drop(v1272_2);
        let v1272_10: Space = if has_head(&(v1272_9)) { singleton(&[]) } else { Space::new() };
        drop(v1272_9);
        let v1272_12: Space = if (v1272_10).is_empty() { Space::new() } else {
          let v1274_6: Path = concat_path(&(v1271_6),&(v1271_11_head));
          let v1274_11: Space = routine_22(c, &(v1274_6), &(*p1), &(v1271_11_tail));
          drop(v1274_6);
          compose(&(v1272_10),&(v1274_11))
        };
        drop(v1272_10);
        let v1272_13: Space = unite(&(v1272_8),&(v1272_12));
        v1271_11.join_into((v1272_13).clone());
      }
      drop(v1271_11_cursor);
      drop(v1271_6);
      compose(&(v1266_10),&(v1271_11))
    };
    drop(v1266_10);
    let v1266_13: Space = unite(&(v1266_8),&(v1266_12));
    v1265_12.join_into((v1266_13).clone());
  }
  drop(v1265_12_cursor);
  (v1265_12).clone()
}

fn routine_139(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1275_10 = Space::new();
  let mut v1275_10_cursor = (*s0).read_zipper();
  for v1275_10_byte in v1275_10_cursor.child_mask().iter() {
    v1275_10_cursor.descend_to_byte(v1275_10_byte);
    let v1275_10_tail = v1275_10_cursor.make_map();
    v1275_10_cursor.ascend(1);
    let v1275_10_head = Path::from_slice(&[v1275_10_byte]);
    let v1276_2: Space = singleton(&(v1275_10_head));
    let v1276_3: Space = intersect(&(*CONSTANT_2),&(v1276_2));
    let v1276_4: Space = if has_head(&(v1276_3)) { singleton(&[]) } else { Space::new() };
    drop(v1276_3);
    let v1276_5: Space = compose(&(v1276_4),&(v1275_10_tail));
    drop(v1276_4);
    let v1277_6: Path = concat_path(&(*p0),&(v1275_10_head));
    let v1276_7: Space = wrap(&(v1276_5),&(v1277_6));
    drop(v1276_5);
    let v1276_8: Space = wrap(&(v1276_7),&(*p1));
    drop(v1276_7);
    let v1276_9: Space = wrap(&(v1276_8),&(*CONSTANT_5));
    drop(v1276_8);
    let v1276_10: Space = intersect(&(*CONSTANT_2),&(v1276_2));
    drop(v1276_2);
    let v1276_11: Space = if has_head(&(v1276_10)) { singleton(&[]) } else { Space::new() };
    drop(v1276_10);
    let v1276_12: Space = subtract(&(*CONSTANT_1),&(v1276_11));
    drop(v1276_11);
    let v1276_14: Space = if (v1276_12).is_empty() { Space::new() } else {
      let mut v1278_13 = Space::new();
      let mut v1278_13_cursor = (v1275_10_tail).read_zipper();
      for v1278_13_byte in v1278_13_cursor.child_mask().iter() {
        v1278_13_cursor.descend_to_byte(v1278_13_byte);
        let v1278_13_tail = v1278_13_cursor.make_map();
        v1278_13_cursor.ascend(1);
        let v1278_13_head = Path::from_slice(&[v1278_13_byte]);
        let v1279_2: Space = singleton(&(v1278_13_head));
        let v1279_3: Space = intersect(&(*CONSTANT_2),&(v1279_2));
        let v1279_4: Space = if has_head(&(v1279_3)) { singleton(&[]) } else { Space::new() };
        drop(v1279_3);
        let v1279_5: Space = subtract(&(*CONSTANT_1),&(v1279_4));
        drop(v1279_4);
        let v1279_8: Space = if (v1279_5).is_empty() { Space::new() } else {
          let v1280_6: Path = concat_path(&(v1277_6),&(v1278_13_head));
          let v1280_7: Space = routine_170(c, &(v1280_6), &(*p1), &(v1278_13_tail));
          compose(&(v1279_5),&(v1280_7))
        };
        drop(v1279_5);
        let v1279_9: Space = intersect(&(*CONSTANT_2),&(v1279_2));
        drop(v1279_2);
        let v1279_10: Space = if has_head(&(v1279_9)) { singleton(&[]) } else { Space::new() };
        drop(v1279_9);
        let v1279_12: Space = if (v1279_10).is_empty() { Space::new() } else {
          let v1281_6: Path = concat_path(&(v1277_6),&(v1278_13_head));
          let v1281_11: Space = routine_171(c, &(v1281_6), &(*p1), &(v1278_13_tail));
          drop(v1281_6);
          compose(&(v1279_10),&(v1281_11))
        };
        drop(v1279_10);
        let v1279_13: Space = unite(&(v1279_8),&(v1279_12));
        v1278_13.join_into((v1279_13).clone());
      }
      drop(v1278_13_cursor);
      compose(&(v1276_12),&(v1278_13))
    };
    drop(v1276_12);
    let v1276_15: Space = unite(&(v1276_9),&(v1276_14));
    drop(v1276_9);
    v1275_10.join_into((v1276_15).clone());
  }
  drop(v1275_10_cursor);
  (v1275_10).clone()
}

fn routine_140(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1282_7 = Space::new();
  let mut v1282_7_cursor = (*s0).read_zipper();
  for v1282_7_byte in v1282_7_cursor.child_mask().iter() {
    v1282_7_cursor.descend_to_byte(v1282_7_byte);
    let v1282_7_tail = v1282_7_cursor.make_map();
    v1282_7_cursor.ascend(1);
    let v1282_7_head = Path::from_slice(&[v1282_7_byte]);
    let v1283_2: Space = singleton(&(v1282_7_head));
    let v1283_3: Space = intersect(&(*CONSTANT_2),&(v1283_2));
    let v1283_4: Space = if has_head(&(v1283_3)) { singleton(&[]) } else { Space::new() };
    drop(v1283_3);
    let v1283_5: Space = subtract(&(*CONSTANT_1),&(v1283_4));
    drop(v1283_4);
    let mut v1283_6 = Space::new();
    let mut v1283_6_cursor = (v1282_7_tail).read_zipper();
    for v1283_6_byte in v1283_6_cursor.child_mask().iter() {
      v1283_6_cursor.descend_to_byte(v1283_6_byte);
      let v1283_6_tail = v1283_6_cursor.make_map();
      v1283_6_cursor.ascend(1);
      let v1283_6_head = Path::from_slice(&[v1283_6_byte]);
      let v1284_2: Space = Space::new();
      v1283_6.join_into((v1284_2).clone());
    }
    drop(v1283_6_cursor);
    let v1283_7: Space = compose(&(v1283_5),&(v1283_6));
    drop(v1283_5);
    drop(v1283_6);
    let v1283_8: Space = intersect(&(*CONSTANT_2),&(v1283_2));
    drop(v1283_2);
    let v1283_9: Space = if has_head(&(v1283_8)) { singleton(&[]) } else { Space::new() };
    drop(v1283_8);
    let v1283_12: Space = if (v1283_9).is_empty() { Space::new() } else {
      let v1285_10: Path = concat_path(&(*p0),&(v1282_7_head));
      let mut v1285_11 = Space::new();
      let mut v1285_11_cursor = (v1282_7_tail).read_zipper();
      for v1285_11_byte in v1285_11_cursor.child_mask().iter() {
        v1285_11_cursor.descend_to_byte(v1285_11_byte);
        let v1285_11_tail = v1285_11_cursor.make_map();
        v1285_11_cursor.ascend(1);
        let v1285_11_head = Path::from_slice(&[v1285_11_byte]);
        let v1286_2: Space = singleton(&(v1285_11_head));
        let v1286_3: Space = intersect(&(*CONSTANT_2),&(v1286_2));
        drop(v1286_2);
        let v1286_4: Space = if has_head(&(v1286_3)) { singleton(&[]) } else { Space::new() };
        drop(v1286_3);
        let v1286_7: Space = if (v1286_4).is_empty() { Space::new() } else {
          let v1287_5: Path = concat_path(&(v1285_10),&(v1285_11_head));
          let v1287_6: Space = routine_22(c, &(v1287_5), &(*p1), &(v1285_11_tail));
          drop(v1287_5);
          compose(&(v1286_4),&(v1287_6))
        };
        drop(v1286_4);
        v1285_11.join_into((v1286_7).clone());
      }
      drop(v1285_11_cursor);
      drop(v1285_10);
      compose(&(v1283_9),&(v1285_11))
    };
    drop(v1283_9);
    let v1283_13: Space = unite(&(v1283_7),&(v1283_12));
    drop(v1283_7);
    v1282_7.join_into((v1283_13).clone());
  }
  drop(v1282_7_cursor);
  (v1282_7).clone()
}

fn routine_141(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1288_7 = Space::new();
  let mut v1288_7_cursor = (*s0).read_zipper();
  for v1288_7_byte in v1288_7_cursor.child_mask().iter() {
    v1288_7_cursor.descend_to_byte(v1288_7_byte);
    let v1288_7_tail = v1288_7_cursor.make_map();
    v1288_7_cursor.ascend(1);
    let v1288_7_head = Path::from_slice(&[v1288_7_byte]);
    let v1289_2: Space = singleton(&(v1288_7_head));
    let v1289_3: Space = intersect(&(*CONSTANT_2),&(v1289_2));
    let v1289_4: Space = if has_head(&(v1289_3)) { singleton(&[]) } else { Space::new() };
    drop(v1289_3);
    let v1289_5: Space = compose(&(v1289_4),&(v1288_7_tail));
    drop(v1289_4);
    let v1289_6: Path = concat_path(&(*p0),&(v1288_7_head));
    let v1289_7: Space = wrap(&(v1289_5),&(v1289_6));
    drop(v1289_5);
    drop(v1289_6);
    let v1289_8: Space = wrap(&(v1289_7),&(*p1));
    drop(v1289_7);
    let v1289_9: Space = wrap(&(v1289_8),&(*CONSTANT_5));
    drop(v1289_8);
    let v1289_10: Space = intersect(&(*CONSTANT_2),&(v1289_2));
    drop(v1289_2);
    let v1289_11: Space = if has_head(&(v1289_10)) { singleton(&[]) } else { Space::new() };
    drop(v1289_10);
    let v1289_12: Space = subtract(&(*CONSTANT_1),&(v1289_11));
    drop(v1289_11);
    let mut v1289_13 = Space::new();
    let mut v1289_13_cursor = (v1288_7_tail).read_zipper();
    for v1289_13_byte in v1289_13_cursor.child_mask().iter() {
      v1289_13_cursor.descend_to_byte(v1289_13_byte);
      let v1289_13_tail = v1289_13_cursor.make_map();
      v1289_13_cursor.ascend(1);
      let v1289_13_head = Path::from_slice(&[v1289_13_byte]);
      let v1290_2: Space = Space::new();
      v1289_13.join_into((v1290_2).clone());
    }
    drop(v1289_13_cursor);
    let v1289_14: Space = compose(&(v1289_12),&(v1289_13));
    drop(v1289_12);
    drop(v1289_13);
    let v1289_15: Space = unite(&(v1289_9),&(v1289_14));
    drop(v1289_9);
    drop(v1289_14);
    v1288_7.join_into((v1289_15).clone());
  }
  drop(v1288_7_cursor);
  (v1288_7).clone()
}

fn routine_142(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1291_13 = Space::new();
  let mut v1291_13_cursor = (*s0).read_zipper();
  for v1291_13_byte in v1291_13_cursor.child_mask().iter() {
    v1291_13_cursor.descend_to_byte(v1291_13_byte);
    let v1291_13_tail = v1291_13_cursor.make_map();
    v1291_13_cursor.ascend(1);
    let v1291_13_head = Path::from_slice(&[v1291_13_byte]);
    let v1292_2: Space = singleton(&(v1291_13_head));
    let v1292_3: Space = intersect(&(*CONSTANT_2),&(v1292_2));
    let v1292_4: Space = if has_head(&(v1292_3)) { singleton(&[]) } else { Space::new() };
    drop(v1292_3);
    let v1292_5: Space = subtract(&(*CONSTANT_1),&(v1292_4));
    drop(v1292_4);
    let v1292_8: Space = if (v1292_5).is_empty() { Space::new() } else {
      let v1293_6: Path = concat_path(&(*p0),&(v1291_13_head));
      let mut v1293_7 = Space::new();
      let mut v1293_7_cursor = (v1291_13_tail).read_zipper();
      for v1293_7_byte in v1293_7_cursor.child_mask().iter() {
        v1293_7_cursor.descend_to_byte(v1293_7_byte);
        let v1293_7_tail = v1293_7_cursor.make_map();
        v1293_7_cursor.ascend(1);
        let v1293_7_head = Path::from_slice(&[v1293_7_byte]);
        let v1294_2: Space = singleton(&(v1293_7_head));
        let v1294_3: Space = intersect(&(*CONSTANT_2),&(v1294_2));
        let v1294_4: Space = if has_head(&(v1294_3)) { singleton(&[]) } else { Space::new() };
        drop(v1294_3);
        let v1294_5: Space = subtract(&(*CONSTANT_1),&(v1294_4));
        drop(v1294_4);
        let v1294_8: Space = if (v1294_5).is_empty() { Space::new() } else {
          let v1295_6: Path = concat_path(&(v1293_6),&(v1293_7_head));
          let v1295_7: Space = routine_172(c, &(v1295_6), &(*p1), &(v1293_7_tail), &(*s1));
          compose(&(v1294_5),&(v1295_7))
        };
        drop(v1294_5);
        let v1294_9: Space = intersect(&(*CONSTANT_2),&(v1294_2));
        drop(v1294_2);
        let v1294_10: Space = if has_head(&(v1294_9)) { singleton(&[]) } else { Space::new() };
        drop(v1294_9);
        let v1294_12: Space = if (v1294_10).is_empty() { Space::new() } else {
          let v1296_6: Path = concat_path(&(v1293_6),&(v1293_7_head));
          let v1296_11: Space = routine_173(c, &(v1296_6), &(*p1), &(v1293_7_tail), &(*s1));
          drop(v1296_6);
          compose(&(v1294_10),&(v1296_11))
        };
        drop(v1294_10);
        let v1294_13: Space = unite(&(v1294_8),&(v1294_12));
        v1293_7.join_into((v1294_13).clone());
      }
      drop(v1293_7_cursor);
      compose(&(v1292_5),&(v1293_7))
    };
    drop(v1292_5);
    let v1292_9: Space = intersect(&(*CONSTANT_2),&(v1292_2));
    drop(v1292_2);
    let v1292_10: Space = if has_head(&(v1292_9)) { singleton(&[]) } else { Space::new() };
    drop(v1292_9);
    let v1292_12: Space = if (v1292_10).is_empty() { Space::new() } else {
      let v1297_6: Path = concat_path(&(*p0),&(v1291_13_head));
      let mut v1297_11 = Space::new();
      let mut v1297_11_cursor = (v1291_13_tail).read_zipper();
      for v1297_11_byte in v1297_11_cursor.child_mask().iter() {
        v1297_11_cursor.descend_to_byte(v1297_11_byte);
        let v1297_11_tail = v1297_11_cursor.make_map();
        v1297_11_cursor.ascend(1);
        let v1297_11_head = Path::from_slice(&[v1297_11_byte]);
        let v1298_2: Space = singleton(&(v1297_11_head));
        let v1298_3: Space = intersect(&(*CONSTANT_2),&(v1298_2));
        let v1298_4: Space = if has_head(&(v1298_3)) { singleton(&[]) } else { Space::new() };
        drop(v1298_3);
        let v1298_5: Space = subtract(&(*CONSTANT_1),&(v1298_4));
        drop(v1298_4);
        let v1298_8: Space = if (v1298_5).is_empty() { Space::new() } else {
          let v1299_6: Path = concat_path(&(v1297_6),&(v1297_11_head));
          let v1299_7: Space = routine_172(c, &(v1299_6), &(*p1), &(v1297_11_tail), &(*s1));
          compose(&(v1298_5),&(v1299_7))
        };
        drop(v1298_5);
        let v1298_9: Space = intersect(&(*CONSTANT_2),&(v1298_2));
        drop(v1298_2);
        let v1298_10: Space = if has_head(&(v1298_9)) { singleton(&[]) } else { Space::new() };
        drop(v1298_9);
        let v1298_12: Space = if (v1298_10).is_empty() { Space::new() } else {
          let v1300_6: Path = concat_path(&(v1297_6),&(v1297_11_head));
          let v1300_11: Space = routine_29(c, &(v1300_6), &(*p1), &(v1297_11_tail), &(*s1));
          drop(v1300_6);
          compose(&(v1298_10),&(v1300_11))
        };
        drop(v1298_10);
        let v1298_13: Space = unite(&(v1298_8),&(v1298_12));
        v1297_11.join_into((v1298_13).clone());
      }
      drop(v1297_11_cursor);
      drop(v1297_6);
      compose(&(v1292_10),&(v1297_11))
    };
    drop(v1292_10);
    let v1292_13: Space = unite(&(v1292_8),&(v1292_12));
    v1291_13.join_into((v1292_13).clone());
  }
  drop(v1291_13_cursor);
  (v1291_13).clone()
}

fn routine_143(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1301_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v1301_10: Space = unwrap(&(v1301_8),&(*CONSTANT_5));
  drop(v1301_8);
  let v1301_11: Space = unwrap(&(v1301_10),&(*p0));
  drop(v1301_10);
  let mut v1301_18 = Space::new();
  let mut v1301_18_cursor = (*s0).read_zipper();
  for v1301_18_byte in v1301_18_cursor.child_mask().iter() {
    v1301_18_cursor.descend_to_byte(v1301_18_byte);
    let v1301_18_tail = v1301_18_cursor.make_map();
    v1301_18_cursor.ascend(1);
    let v1301_18_head = Path::from_slice(&[v1301_18_byte]);
    let v1302_2: Space = singleton(&(v1301_18_head));
    let v1302_3: Space = intersect(&(*CONSTANT_2),&(v1302_2));
    let v1302_4: Space = if has_head(&(v1302_3)) { singleton(&[]) } else { Space::new() };
    drop(v1302_3);
    let v1302_5: Space = subtract(&(*CONSTANT_1),&(v1302_4));
    drop(v1302_4);
    let v1302_8: Space = if (v1302_5).is_empty() { Space::new() } else {
      let v1303_6: Path = concat_path(&(*p0),&(v1301_18_head));
      let mut v1303_7 = Space::new();
      let mut v1303_7_cursor = (v1301_18_tail).read_zipper();
      for v1303_7_byte in v1303_7_cursor.child_mask().iter() {
        v1303_7_cursor.descend_to_byte(v1303_7_byte);
        let v1303_7_tail = v1303_7_cursor.make_map();
        v1303_7_cursor.ascend(1);
        let v1303_7_head = Path::from_slice(&[v1303_7_byte]);
        let v1304_2: Space = singleton(&(v1303_7_head));
        let v1304_3: Space = intersect(&(*CONSTANT_2),&(v1304_2));
        let v1304_4: Space = if has_head(&(v1304_3)) { singleton(&[]) } else { Space::new() };
        drop(v1304_3);
        let v1304_5: Space = subtract(&(*CONSTANT_1),&(v1304_4));
        drop(v1304_4);
        let v1304_8: Space = if (v1304_5).is_empty() { Space::new() } else {
          let v1305_6: Path = concat_path(&(v1303_6),&(v1303_7_head));
          let v1305_7: Space = routine_172(c, &(v1305_6), &(*p1), &(v1303_7_tail), &(*s1));
          compose(&(v1304_5),&(v1305_7))
        };
        drop(v1304_5);
        let v1304_9: Space = intersect(&(*CONSTANT_2),&(v1304_2));
        drop(v1304_2);
        let v1304_10: Space = if has_head(&(v1304_9)) { singleton(&[]) } else { Space::new() };
        drop(v1304_9);
        let v1304_12: Space = if (v1304_10).is_empty() { Space::new() } else {
          let v1306_6: Path = concat_path(&(v1303_6),&(v1303_7_head));
          let v1306_11: Space = routine_173(c, &(v1306_6), &(*p1), &(v1303_7_tail), &(*s1));
          drop(v1306_6);
          compose(&(v1304_10),&(v1306_11))
        };
        drop(v1304_10);
        let v1304_13: Space = unite(&(v1304_8),&(v1304_12));
        v1303_7.join_into((v1304_13).clone());
      }
      drop(v1303_7_cursor);
      drop(v1303_6);
      compose(&(v1302_5),&(v1303_7))
    };
    drop(v1302_5);
    let v1302_9: Space = intersect(&(*CONSTANT_2),&(v1302_2));
    drop(v1302_2);
    let v1302_10: Space = if has_head(&(v1302_9)) { singleton(&[]) } else { Space::new() };
    drop(v1302_9);
    let v1302_13: Space = if (v1302_10).is_empty() { Space::new() } else {
      let v1307_11: Space = unwrap(&(v1301_11),&(v1301_18_head));
      let mut v1307_12 = Space::new();
      let mut v1307_12_cursor = (v1307_11).read_zipper();
      for v1307_12_byte in v1307_12_cursor.child_mask().iter() {
        v1307_12_cursor.descend_to_byte(v1307_12_byte);
        let v1307_12_tail = v1307_12_cursor.make_map();
        v1307_12_cursor.ascend(1);
        let v1307_12_head = Path::from_slice(&[v1307_12_byte]);
        let v1308_2: Space = singleton(&(v1307_12_head));
        let v1308_3: Space = intersect(&(*CONSTANT_2),&(v1308_2));
        let v1308_4: Space = if has_head(&(v1308_3)) { singleton(&[]) } else { Space::new() };
        drop(v1308_3);
        let v1308_5: Space = subtract(&(*CONSTANT_1),&(v1308_4));
        drop(v1308_4);
        let v1308_7: Space = if (v1308_5).is_empty() { Space::new() } else {
          let v1309_6: Space = routine_61(c, &(v1307_12_head), &(*p1), &(v1307_12_tail));
          compose(&(v1308_5),&(v1309_6))
        };
        drop(v1308_5);
        let v1308_8: Space = intersect(&(*CONSTANT_2),&(v1308_2));
        drop(v1308_2);
        let v1308_9: Space = if has_head(&(v1308_8)) { singleton(&[]) } else { Space::new() };
        drop(v1308_8);
        let v1308_11: Space = if (v1308_9).is_empty() { Space::new() } else {
          let v1310_10: Space = routine_62(c, &(v1307_12_head), &(*p1), &(v1307_12_tail));
          compose(&(v1308_9),&(v1310_10))
        };
        drop(v1308_9);
        let v1308_12: Space = unite(&(v1308_7),&(v1308_11));
        v1307_12.join_into((v1308_12).clone());
      }
      drop(v1307_12_cursor);
      drop(v1307_11);
      compose(&(v1302_10),&(v1307_12))
    };
    drop(v1302_10);
    let v1302_14: Space = unite(&(v1302_8),&(v1302_13));
    v1301_18.join_into((v1302_14).clone());
  }
  drop(v1301_18_cursor);
  drop(v1301_11);
  (v1301_18).clone()
}

fn routine_144(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1311_12 = Space::new();
  let mut v1311_12_cursor = (*s0).read_zipper();
  for v1311_12_byte in v1311_12_cursor.child_mask().iter() {
    v1311_12_cursor.descend_to_byte(v1311_12_byte);
    let v1311_12_tail = v1311_12_cursor.make_map();
    v1311_12_cursor.ascend(1);
    let v1311_12_head = Path::from_slice(&[v1311_12_byte]);
    let v1312_2: Space = singleton(&(v1311_12_head));
    let v1312_3: Space = intersect(&(*CONSTANT_2),&(v1312_2));
    let v1312_4: Space = if has_head(&(v1312_3)) { singleton(&[]) } else { Space::new() };
    drop(v1312_3);
    let v1312_5: Space = subtract(&(*CONSTANT_1),&(v1312_4));
    drop(v1312_4);
    let v1312_8: Space = if (v1312_5).is_empty() { Space::new() } else {
      let v1313_6: Path = concat_path(&(*p0),&(v1311_12_head));
      let mut v1313_7 = Space::new();
      let mut v1313_7_cursor = (v1311_12_tail).read_zipper();
      for v1313_7_byte in v1313_7_cursor.child_mask().iter() {
        v1313_7_cursor.descend_to_byte(v1313_7_byte);
        let v1313_7_tail = v1313_7_cursor.make_map();
        v1313_7_cursor.ascend(1);
        let v1313_7_head = Path::from_slice(&[v1313_7_byte]);
        let v1314_2: Space = singleton(&(v1313_7_head));
        let v1314_3: Space = intersect(&(*CONSTANT_2),&(v1314_2));
        let v1314_4: Space = if has_head(&(v1314_3)) { singleton(&[]) } else { Space::new() };
        drop(v1314_3);
        let v1314_5: Space = subtract(&(*CONSTANT_1),&(v1314_4));
        drop(v1314_4);
        let v1314_8: Space = if (v1314_5).is_empty() { Space::new() } else {
          let v1315_6: Path = concat_path(&(v1313_6),&(v1313_7_head));
          let v1315_7: Space = routine_174(c, &(v1315_6), &(*p1), &(v1313_7_tail));
          compose(&(v1314_5),&(v1315_7))
        };
        drop(v1314_5);
        let v1314_9: Space = intersect(&(*CONSTANT_2),&(v1314_2));
        drop(v1314_2);
        let v1314_10: Space = if has_head(&(v1314_9)) { singleton(&[]) } else { Space::new() };
        drop(v1314_9);
        let v1314_12: Space = if (v1314_10).is_empty() { Space::new() } else {
          let v1316_6: Path = concat_path(&(v1313_6),&(v1313_7_head));
          let v1316_11: Space = routine_175(c, &(v1316_6), &(*p1), &(v1313_7_tail));
          drop(v1316_6);
          compose(&(v1314_10),&(v1316_11))
        };
        drop(v1314_10);
        let v1314_13: Space = unite(&(v1314_8),&(v1314_12));
        v1313_7.join_into((v1314_13).clone());
      }
      drop(v1313_7_cursor);
      compose(&(v1312_5),&(v1313_7))
    };
    drop(v1312_5);
    let v1312_9: Space = intersect(&(*CONSTANT_2),&(v1312_2));
    drop(v1312_2);
    let v1312_10: Space = if has_head(&(v1312_9)) { singleton(&[]) } else { Space::new() };
    drop(v1312_9);
    let v1312_12: Space = if (v1312_10).is_empty() { Space::new() } else {
      let v1317_6: Path = concat_path(&(*p0),&(v1311_12_head));
      let mut v1317_11 = Space::new();
      let mut v1317_11_cursor = (v1311_12_tail).read_zipper();
      for v1317_11_byte in v1317_11_cursor.child_mask().iter() {
        v1317_11_cursor.descend_to_byte(v1317_11_byte);
        let v1317_11_tail = v1317_11_cursor.make_map();
        v1317_11_cursor.ascend(1);
        let v1317_11_head = Path::from_slice(&[v1317_11_byte]);
        let v1318_2: Space = singleton(&(v1317_11_head));
        let v1318_3: Space = intersect(&(*CONSTANT_2),&(v1318_2));
        let v1318_4: Space = if has_head(&(v1318_3)) { singleton(&[]) } else { Space::new() };
        drop(v1318_3);
        let v1318_5: Space = subtract(&(*CONSTANT_1),&(v1318_4));
        drop(v1318_4);
        let v1318_8: Space = if (v1318_5).is_empty() { Space::new() } else {
          let v1319_6: Path = concat_path(&(v1317_6),&(v1317_11_head));
          let v1319_7: Space = routine_174(c, &(v1319_6), &(*p1), &(v1317_11_tail));
          compose(&(v1318_5),&(v1319_7))
        };
        drop(v1318_5);
        let v1318_9: Space = intersect(&(*CONSTANT_2),&(v1318_2));
        drop(v1318_2);
        let v1318_10: Space = if has_head(&(v1318_9)) { singleton(&[]) } else { Space::new() };
        drop(v1318_9);
        let v1318_12: Space = if (v1318_10).is_empty() { Space::new() } else {
          let v1320_6: Path = concat_path(&(v1317_6),&(v1317_11_head));
          let v1320_11: Space = routine_67(c, &(v1320_6), &(*p1), &(v1317_11_tail));
          drop(v1320_6);
          compose(&(v1318_10),&(v1320_11))
        };
        drop(v1318_10);
        let v1318_13: Space = unite(&(v1318_8),&(v1318_12));
        v1317_11.join_into((v1318_13).clone());
      }
      drop(v1317_11_cursor);
      drop(v1317_6);
      compose(&(v1312_10),&(v1317_11))
    };
    drop(v1312_10);
    let v1312_13: Space = unite(&(v1312_8),&(v1312_12));
    v1311_12.join_into((v1312_13).clone());
  }
  drop(v1311_12_cursor);
  (v1311_12).clone()
}

fn routine_145(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1321_9 = Space::new();
  let mut v1321_9_cursor = (*s0).read_zipper();
  for v1321_9_byte in v1321_9_cursor.child_mask().iter() {
    v1321_9_cursor.descend_to_byte(v1321_9_byte);
    let v1321_9_tail = v1321_9_cursor.make_map();
    v1321_9_cursor.ascend(1);
    let v1321_9_head = Path::from_slice(&[v1321_9_byte]);
    let v1322_2: Space = singleton(&(v1321_9_head));
    let v1322_3: Space = intersect(&(*CONSTANT_2),&(v1322_2));
    let v1322_4: Space = if has_head(&(v1322_3)) { singleton(&[]) } else { Space::new() };
    drop(v1322_3);
    let v1322_5: Space = subtract(&(*CONSTANT_1),&(v1322_4));
    drop(v1322_4);
    let v1322_8: Space = if (v1322_5).is_empty() { Space::new() } else {
      let v1323_6: Path = concat_path(&(*p0),&(v1321_9_head));
      let mut v1323_7 = Space::new();
      let mut v1323_7_cursor = (v1321_9_tail).read_zipper();
      for v1323_7_byte in v1323_7_cursor.child_mask().iter() {
        v1323_7_cursor.descend_to_byte(v1323_7_byte);
        let v1323_7_tail = v1323_7_cursor.make_map();
        v1323_7_cursor.ascend(1);
        let v1323_7_head = Path::from_slice(&[v1323_7_byte]);
        let v1324_2: Space = singleton(&(v1323_7_head));
        let v1324_3: Space = intersect(&(*CONSTANT_2),&(v1324_2));
        let v1324_4: Space = if has_head(&(v1324_3)) { singleton(&[]) } else { Space::new() };
        drop(v1324_3);
        let v1324_5: Space = subtract(&(*CONSTANT_1),&(v1324_4));
        drop(v1324_4);
        let v1324_8: Space = if (v1324_5).is_empty() { Space::new() } else {
          let v1325_6: Path = concat_path(&(v1323_6),&(v1323_7_head));
          let v1325_7: Space = routine_174(c, &(v1325_6), &(*p1), &(v1323_7_tail));
          compose(&(v1324_5),&(v1325_7))
        };
        drop(v1324_5);
        let v1324_9: Space = intersect(&(*CONSTANT_2),&(v1324_2));
        drop(v1324_2);
        let v1324_10: Space = if has_head(&(v1324_9)) { singleton(&[]) } else { Space::new() };
        drop(v1324_9);
        let v1324_12: Space = if (v1324_10).is_empty() { Space::new() } else {
          let v1326_6: Path = concat_path(&(v1323_6),&(v1323_7_head));
          let v1326_11: Space = routine_175(c, &(v1326_6), &(*p1), &(v1323_7_tail));
          drop(v1326_6);
          compose(&(v1324_10),&(v1326_11))
        };
        drop(v1324_10);
        let v1324_13: Space = unite(&(v1324_8),&(v1324_12));
        v1323_7.join_into((v1324_13).clone());
      }
      drop(v1323_7_cursor);
      compose(&(v1322_5),&(v1323_7))
    };
    drop(v1322_5);
    let v1322_9: Space = intersect(&(*CONSTANT_2),&(v1322_2));
    drop(v1322_2);
    let v1322_10: Space = if has_head(&(v1322_9)) { singleton(&[]) } else { Space::new() };
    drop(v1322_9);
    let v1322_11: Space = compose(&(v1322_10),&(v1321_9_tail));
    drop(v1322_10);
    let v1327_6: Path = concat_path(&(*p0),&(v1321_9_head));
    let v1322_12: Space = wrap(&(v1322_11),&(v1327_6));
    drop(v1322_11);
    let v1322_13: Space = wrap(&(v1322_12),&(*p1));
    drop(v1322_12);
    let v1322_14: Space = unite(&(v1322_8),&(v1322_13));
    drop(v1322_13);
    v1321_9.join_into((v1322_14).clone());
  }
  drop(v1321_9_cursor);
  (v1321_9).clone()
}

fn routine_146(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1328_8 = Space::new();
  let mut v1328_8_cursor = (*s0).read_zipper();
  for v1328_8_byte in v1328_8_cursor.child_mask().iter() {
    v1328_8_cursor.descend_to_byte(v1328_8_byte);
    let v1328_8_tail = v1328_8_cursor.make_map();
    v1328_8_cursor.ascend(1);
    let v1328_8_head = Path::from_slice(&[v1328_8_byte]);
    let v1329_2: Space = singleton(&(v1328_8_head));
    let v1329_3: Space = intersect(&(*CONSTANT_2),&(v1329_2));
    let v1329_4: Space = if has_head(&(v1329_3)) { singleton(&[]) } else { Space::new() };
    drop(v1329_3);
    let v1329_5: Space = subtract(&(*CONSTANT_1),&(v1329_4));
    drop(v1329_4);
    let mut v1329_6 = Space::new();
    let mut v1329_6_cursor = (v1328_8_tail).read_zipper();
    for v1329_6_byte in v1329_6_cursor.child_mask().iter() {
      v1329_6_cursor.descend_to_byte(v1329_6_byte);
      let v1329_6_tail = v1329_6_cursor.make_map();
      v1329_6_cursor.ascend(1);
      let v1329_6_head = Path::from_slice(&[v1329_6_byte]);
      let v1330_2: Space = Space::new();
      v1329_6.join_into((v1330_2).clone());
    }
    drop(v1329_6_cursor);
    let v1329_7: Space = compose(&(v1329_5),&(v1329_6));
    drop(v1329_5);
    drop(v1329_6);
    let v1329_8: Space = intersect(&(*CONSTANT_2),&(v1329_2));
    drop(v1329_2);
    let v1329_9: Space = if has_head(&(v1329_8)) { singleton(&[]) } else { Space::new() };
    drop(v1329_8);
    let v1329_12: Space = if (v1329_9).is_empty() { Space::new() } else {
      let v1331_10: Path = concat_path(&(*p0),&(v1328_8_head));
      let mut v1331_11 = Space::new();
      let mut v1331_11_cursor = (v1328_8_tail).read_zipper();
      for v1331_11_byte in v1331_11_cursor.child_mask().iter() {
        v1331_11_cursor.descend_to_byte(v1331_11_byte);
        let v1331_11_tail = v1331_11_cursor.make_map();
        v1331_11_cursor.ascend(1);
        let v1331_11_head = Path::from_slice(&[v1331_11_byte]);
        let v1332_2: Space = singleton(&(v1331_11_head));
        let v1332_3: Space = intersect(&(*CONSTANT_2),&(v1332_2));
        drop(v1332_2);
        let v1332_4: Space = if has_head(&(v1332_3)) { singleton(&[]) } else { Space::new() };
        drop(v1332_3);
        let v1332_7: Space = if (v1332_4).is_empty() { Space::new() } else {
          let v1333_5: Path = concat_path(&(v1331_10),&(v1331_11_head));
          let v1333_6: Space = routine_29(c, &(v1333_5), &(*p1), &(v1331_11_tail), &(*s1));
          drop(v1333_5);
          compose(&(v1332_4),&(v1333_6))
        };
        drop(v1332_4);
        v1331_11.join_into((v1332_7).clone());
      }
      drop(v1331_11_cursor);
      drop(v1331_10);
      compose(&(v1329_9),&(v1331_11))
    };
    drop(v1329_9);
    let v1329_13: Space = unite(&(v1329_7),&(v1329_12));
    drop(v1329_7);
    v1328_8.join_into((v1329_13).clone());
  }
  drop(v1328_8_cursor);
  (v1328_8).clone()
}

fn routine_147(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1334_8: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v1334_10: Space = unwrap(&(v1334_8),&(*CONSTANT_5));
  drop(v1334_8);
  let v1334_11: Space = unwrap(&(v1334_10),&(*p0));
  drop(v1334_10);
  let mut v1334_15 = Space::new();
  let mut v1334_15_cursor = (*s0).read_zipper();
  for v1334_15_byte in v1334_15_cursor.child_mask().iter() {
    v1334_15_cursor.descend_to_byte(v1334_15_byte);
    let v1334_15_tail = v1334_15_cursor.make_map();
    v1334_15_cursor.ascend(1);
    let v1334_15_head = Path::from_slice(&[v1334_15_byte]);
    let v1335_2: Space = singleton(&(v1334_15_head));
    let v1335_3: Space = intersect(&(*CONSTANT_2),&(v1335_2));
    let v1335_4: Space = if has_head(&(v1335_3)) { singleton(&[]) } else { Space::new() };
    drop(v1335_3);
    let v1335_5: Space = subtract(&(*CONSTANT_1),&(v1335_4));
    drop(v1335_4);
    let mut v1335_6 = Space::new();
    let mut v1335_6_cursor = (v1334_15_tail).read_zipper();
    for v1335_6_byte in v1335_6_cursor.child_mask().iter() {
      v1335_6_cursor.descend_to_byte(v1335_6_byte);
      let v1335_6_tail = v1335_6_cursor.make_map();
      v1335_6_cursor.ascend(1);
      let v1335_6_head = Path::from_slice(&[v1335_6_byte]);
      let v1336_2: Space = Space::new();
      v1335_6.join_into((v1336_2).clone());
    }
    drop(v1335_6_cursor);
    let v1335_7: Space = compose(&(v1335_5),&(v1335_6));
    drop(v1335_5);
    drop(v1335_6);
    let v1335_8: Space = intersect(&(*CONSTANT_2),&(v1335_2));
    drop(v1335_2);
    let v1335_9: Space = if has_head(&(v1335_8)) { singleton(&[]) } else { Space::new() };
    drop(v1335_8);
    let v1335_12: Space = if (v1335_9).is_empty() { Space::new() } else {
      let v1337_10: Space = unwrap(&(v1334_11),&(v1334_15_head));
      let mut v1337_11 = Space::new();
      let mut v1337_11_cursor = (v1337_10).read_zipper();
      for v1337_11_byte in v1337_11_cursor.child_mask().iter() {
        v1337_11_cursor.descend_to_byte(v1337_11_byte);
        let v1337_11_tail = v1337_11_cursor.make_map();
        v1337_11_cursor.ascend(1);
        let v1337_11_head = Path::from_slice(&[v1337_11_byte]);
        let v1338_2: Space = singleton(&(v1337_11_head));
        let v1338_3: Space = intersect(&(*CONSTANT_2),&(v1338_2));
        let v1338_4: Space = if has_head(&(v1338_3)) { singleton(&[]) } else { Space::new() };
        drop(v1338_3);
        let v1338_5: Space = subtract(&(*CONSTANT_1),&(v1338_4));
        drop(v1338_4);
        let v1338_7: Space = if (v1338_5).is_empty() { Space::new() } else {
          let v1339_6: Space = routine_61(c, &(v1337_11_head), &(*p1), &(v1337_11_tail));
          compose(&(v1338_5),&(v1339_6))
        };
        drop(v1338_5);
        let v1338_8: Space = intersect(&(*CONSTANT_2),&(v1338_2));
        drop(v1338_2);
        let v1338_9: Space = if has_head(&(v1338_8)) { singleton(&[]) } else { Space::new() };
        drop(v1338_8);
        let v1338_11: Space = if (v1338_9).is_empty() { Space::new() } else {
          let v1340_10: Space = routine_62(c, &(v1337_11_head), &(*p1), &(v1337_11_tail));
          compose(&(v1338_9),&(v1340_10))
        };
        drop(v1338_9);
        let v1338_12: Space = unite(&(v1338_7),&(v1338_11));
        v1337_11.join_into((v1338_12).clone());
      }
      drop(v1337_11_cursor);
      drop(v1337_10);
      compose(&(v1335_9),&(v1337_11))
    };
    drop(v1335_9);
    let v1335_13: Space = unite(&(v1335_7),&(v1335_12));
    drop(v1335_7);
    v1334_15.join_into((v1335_13).clone());
  }
  drop(v1334_15_cursor);
  drop(v1334_11);
  (v1334_15).clone()
}

fn routine_148(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1341_12 = Space::new();
  let mut v1341_12_cursor = (*s0).read_zipper();
  for v1341_12_byte in v1341_12_cursor.child_mask().iter() {
    v1341_12_cursor.descend_to_byte(v1341_12_byte);
    let v1341_12_tail = v1341_12_cursor.make_map();
    v1341_12_cursor.ascend(1);
    let v1341_12_head = Path::from_slice(&[v1341_12_byte]);
    let v1342_2: Space = singleton(&(v1341_12_head));
    let v1342_3: Space = intersect(&(*CONSTANT_2),&(v1342_2));
    let v1342_4: Space = if has_head(&(v1342_3)) { singleton(&[]) } else { Space::new() };
    drop(v1342_3);
    let v1342_5: Space = subtract(&(*CONSTANT_1),&(v1342_4));
    drop(v1342_4);
    let v1342_8: Space = if (v1342_5).is_empty() { Space::new() } else {
      let v1343_6: Path = concat_path(&(*p0),&(v1341_12_head));
      let mut v1343_7 = Space::new();
      let mut v1343_7_cursor = (v1341_12_tail).read_zipper();
      for v1343_7_byte in v1343_7_cursor.child_mask().iter() {
        v1343_7_cursor.descend_to_byte(v1343_7_byte);
        let v1343_7_tail = v1343_7_cursor.make_map();
        v1343_7_cursor.ascend(1);
        let v1343_7_head = Path::from_slice(&[v1343_7_byte]);
        let v1344_2: Space = singleton(&(v1343_7_head));
        let v1344_3: Space = intersect(&(*CONSTANT_2),&(v1344_2));
        let v1344_4: Space = if has_head(&(v1344_3)) { singleton(&[]) } else { Space::new() };
        drop(v1344_3);
        let v1344_5: Space = subtract(&(*CONSTANT_1),&(v1344_4));
        drop(v1344_4);
        let v1344_8: Space = if (v1344_5).is_empty() { Space::new() } else {
          let v1345_6: Path = concat_path(&(v1343_6),&(v1343_7_head));
          let v1345_7: Space = routine_176(c, &(v1345_6), &(*p1), &(v1343_7_tail));
          compose(&(v1344_5),&(v1345_7))
        };
        drop(v1344_5);
        let v1344_9: Space = intersect(&(*CONSTANT_2),&(v1344_2));
        drop(v1344_2);
        let v1344_10: Space = if has_head(&(v1344_9)) { singleton(&[]) } else { Space::new() };
        drop(v1344_9);
        let v1344_12: Space = if (v1344_10).is_empty() { Space::new() } else {
          let v1346_6: Path = concat_path(&(v1343_6),&(v1343_7_head));
          let v1346_11: Space = routine_177(c, &(v1346_6), &(*p1), &(v1343_7_tail));
          drop(v1346_6);
          compose(&(v1344_10),&(v1346_11))
        };
        drop(v1344_10);
        let v1344_13: Space = unite(&(v1344_8),&(v1344_12));
        v1343_7.join_into((v1344_13).clone());
      }
      drop(v1343_7_cursor);
      compose(&(v1342_5),&(v1343_7))
    };
    drop(v1342_5);
    let v1342_9: Space = intersect(&(*CONSTANT_2),&(v1342_2));
    drop(v1342_2);
    let v1342_10: Space = if has_head(&(v1342_9)) { singleton(&[]) } else { Space::new() };
    drop(v1342_9);
    let v1342_12: Space = if (v1342_10).is_empty() { Space::new() } else {
      let v1347_6: Path = concat_path(&(*p0),&(v1341_12_head));
      let mut v1347_11 = Space::new();
      let mut v1347_11_cursor = (v1341_12_tail).read_zipper();
      for v1347_11_byte in v1347_11_cursor.child_mask().iter() {
        v1347_11_cursor.descend_to_byte(v1347_11_byte);
        let v1347_11_tail = v1347_11_cursor.make_map();
        v1347_11_cursor.ascend(1);
        let v1347_11_head = Path::from_slice(&[v1347_11_byte]);
        let v1348_2: Space = singleton(&(v1347_11_head));
        let v1348_3: Space = intersect(&(*CONSTANT_2),&(v1348_2));
        let v1348_4: Space = if has_head(&(v1348_3)) { singleton(&[]) } else { Space::new() };
        drop(v1348_3);
        let v1348_5: Space = subtract(&(*CONSTANT_1),&(v1348_4));
        drop(v1348_4);
        let v1348_8: Space = if (v1348_5).is_empty() { Space::new() } else {
          let v1349_6: Path = concat_path(&(v1347_6),&(v1347_11_head));
          let v1349_7: Space = routine_176(c, &(v1349_6), &(*p1), &(v1347_11_tail));
          compose(&(v1348_5),&(v1349_7))
        };
        drop(v1348_5);
        let v1348_9: Space = intersect(&(*CONSTANT_2),&(v1348_2));
        drop(v1348_2);
        let v1348_10: Space = if has_head(&(v1348_9)) { singleton(&[]) } else { Space::new() };
        drop(v1348_9);
        let v1348_12: Space = if (v1348_10).is_empty() { Space::new() } else {
          let v1350_6: Path = concat_path(&(v1347_6),&(v1347_11_head));
          let v1350_11: Space = routine_67(c, &(v1350_6), &(*p1), &(v1347_11_tail));
          drop(v1350_6);
          compose(&(v1348_10),&(v1350_11))
        };
        drop(v1348_10);
        let v1348_13: Space = unite(&(v1348_8),&(v1348_12));
        v1347_11.join_into((v1348_13).clone());
      }
      drop(v1347_11_cursor);
      drop(v1347_6);
      compose(&(v1342_10),&(v1347_11))
    };
    drop(v1342_10);
    let v1342_13: Space = unite(&(v1342_8),&(v1342_12));
    v1341_12.join_into((v1342_13).clone());
  }
  drop(v1341_12_cursor);
  (v1341_12).clone()
}

fn routine_149(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1351_9 = Space::new();
  let mut v1351_9_cursor = (*s0).read_zipper();
  for v1351_9_byte in v1351_9_cursor.child_mask().iter() {
    v1351_9_cursor.descend_to_byte(v1351_9_byte);
    let v1351_9_tail = v1351_9_cursor.make_map();
    v1351_9_cursor.ascend(1);
    let v1351_9_head = Path::from_slice(&[v1351_9_byte]);
    let v1352_2: Space = singleton(&(v1351_9_head));
    let v1352_3: Space = intersect(&(*CONSTANT_2),&(v1352_2));
    let v1352_4: Space = if has_head(&(v1352_3)) { singleton(&[]) } else { Space::new() };
    drop(v1352_3);
    let v1352_5: Space = subtract(&(*CONSTANT_1),&(v1352_4));
    drop(v1352_4);
    let v1352_8: Space = if (v1352_5).is_empty() { Space::new() } else {
      let v1353_6: Path = concat_path(&(*p0),&(v1351_9_head));
      let mut v1353_7 = Space::new();
      let mut v1353_7_cursor = (v1351_9_tail).read_zipper();
      for v1353_7_byte in v1353_7_cursor.child_mask().iter() {
        v1353_7_cursor.descend_to_byte(v1353_7_byte);
        let v1353_7_tail = v1353_7_cursor.make_map();
        v1353_7_cursor.ascend(1);
        let v1353_7_head = Path::from_slice(&[v1353_7_byte]);
        let v1354_2: Space = singleton(&(v1353_7_head));
        let v1354_3: Space = intersect(&(*CONSTANT_2),&(v1354_2));
        let v1354_4: Space = if has_head(&(v1354_3)) { singleton(&[]) } else { Space::new() };
        drop(v1354_3);
        let v1354_5: Space = subtract(&(*CONSTANT_1),&(v1354_4));
        drop(v1354_4);
        let v1354_8: Space = if (v1354_5).is_empty() { Space::new() } else {
          let v1355_6: Path = concat_path(&(v1353_6),&(v1353_7_head));
          let v1355_7: Space = routine_176(c, &(v1355_6), &(*p1), &(v1353_7_tail));
          compose(&(v1354_5),&(v1355_7))
        };
        drop(v1354_5);
        let v1354_9: Space = intersect(&(*CONSTANT_2),&(v1354_2));
        drop(v1354_2);
        let v1354_10: Space = if has_head(&(v1354_9)) { singleton(&[]) } else { Space::new() };
        drop(v1354_9);
        let v1354_12: Space = if (v1354_10).is_empty() { Space::new() } else {
          let v1356_6: Path = concat_path(&(v1353_6),&(v1353_7_head));
          let v1356_11: Space = routine_177(c, &(v1356_6), &(*p1), &(v1353_7_tail));
          drop(v1356_6);
          compose(&(v1354_10),&(v1356_11))
        };
        drop(v1354_10);
        let v1354_13: Space = unite(&(v1354_8),&(v1354_12));
        v1353_7.join_into((v1354_13).clone());
      }
      drop(v1353_7_cursor);
      compose(&(v1352_5),&(v1353_7))
    };
    drop(v1352_5);
    let v1352_9: Space = intersect(&(*CONSTANT_2),&(v1352_2));
    drop(v1352_2);
    let v1352_10: Space = if has_head(&(v1352_9)) { singleton(&[]) } else { Space::new() };
    drop(v1352_9);
    let v1352_11: Space = compose(&(v1352_10),&(v1351_9_tail));
    drop(v1352_10);
    let v1357_6: Path = concat_path(&(*p0),&(v1351_9_head));
    let v1352_12: Space = wrap(&(v1352_11),&(v1357_6));
    drop(v1352_11);
    let v1352_13: Space = wrap(&(v1352_12),&(*p1));
    drop(v1352_12);
    let v1352_14: Space = unite(&(v1352_8),&(v1352_13));
    drop(v1352_13);
    v1351_9.join_into((v1352_14).clone());
  }
  drop(v1351_9_cursor);
  (v1351_9).clone()
}

fn routine_150(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1358_13 = Space::new();
  let mut v1358_13_cursor = (*s0).read_zipper();
  for v1358_13_byte in v1358_13_cursor.child_mask().iter() {
    v1358_13_cursor.descend_to_byte(v1358_13_byte);
    let v1358_13_tail = v1358_13_cursor.make_map();
    v1358_13_cursor.ascend(1);
    let v1358_13_head = Path::from_slice(&[v1358_13_byte]);
    let v1359_2: Space = singleton(&(v1358_13_head));
    let v1359_3: Space = intersect(&(*CONSTANT_2),&(v1359_2));
    let v1359_4: Space = if has_head(&(v1359_3)) { singleton(&[]) } else { Space::new() };
    drop(v1359_3);
    let v1359_5: Space = subtract(&(*CONSTANT_1),&(v1359_4));
    drop(v1359_4);
    let v1359_8: Space = if (v1359_5).is_empty() { Space::new() } else {
      let v1360_6: Path = concat_path(&(*p0),&(v1358_13_head));
      let mut v1360_7 = Space::new();
      let mut v1360_7_cursor = (v1358_13_tail).read_zipper();
      for v1360_7_byte in v1360_7_cursor.child_mask().iter() {
        v1360_7_cursor.descend_to_byte(v1360_7_byte);
        let v1360_7_tail = v1360_7_cursor.make_map();
        v1360_7_cursor.ascend(1);
        let v1360_7_head = Path::from_slice(&[v1360_7_byte]);
        let v1361_2: Space = singleton(&(v1360_7_head));
        let v1361_3: Space = intersect(&(*CONSTANT_2),&(v1361_2));
        let v1361_4: Space = if has_head(&(v1361_3)) { singleton(&[]) } else { Space::new() };
        drop(v1361_3);
        let v1361_5: Space = subtract(&(*CONSTANT_1),&(v1361_4));
        drop(v1361_4);
        let v1361_8: Space = if (v1361_5).is_empty() { Space::new() } else {
          let v1362_6: Path = concat_path(&(v1360_6),&(v1360_7_head));
          let v1362_7: Space = routine_178(c, &(v1362_6), &(*p1), &(v1360_7_tail), &(*s1));
          compose(&(v1361_5),&(v1362_7))
        };
        drop(v1361_5);
        let v1361_9: Space = intersect(&(*CONSTANT_2),&(v1361_2));
        drop(v1361_2);
        let v1361_10: Space = if has_head(&(v1361_9)) { singleton(&[]) } else { Space::new() };
        drop(v1361_9);
        let v1361_12: Space = if (v1361_10).is_empty() { Space::new() } else {
          let v1363_6: Path = concat_path(&(v1360_6),&(v1360_7_head));
          let v1363_11: Space = routine_179(c, &(v1363_6), &(*p1), &(v1360_7_tail), &(*s1));
          drop(v1363_6);
          compose(&(v1361_10),&(v1363_11))
        };
        drop(v1361_10);
        let v1361_13: Space = unite(&(v1361_8),&(v1361_12));
        v1360_7.join_into((v1361_13).clone());
      }
      drop(v1360_7_cursor);
      compose(&(v1359_5),&(v1360_7))
    };
    drop(v1359_5);
    let v1359_9: Space = intersect(&(*CONSTANT_2),&(v1359_2));
    drop(v1359_2);
    let v1359_10: Space = if has_head(&(v1359_9)) { singleton(&[]) } else { Space::new() };
    drop(v1359_9);
    let v1359_12: Space = if (v1359_10).is_empty() { Space::new() } else {
      let v1364_6: Path = concat_path(&(*p0),&(v1358_13_head));
      let mut v1364_11 = Space::new();
      let mut v1364_11_cursor = (v1358_13_tail).read_zipper();
      for v1364_11_byte in v1364_11_cursor.child_mask().iter() {
        v1364_11_cursor.descend_to_byte(v1364_11_byte);
        let v1364_11_tail = v1364_11_cursor.make_map();
        v1364_11_cursor.ascend(1);
        let v1364_11_head = Path::from_slice(&[v1364_11_byte]);
        let v1365_2: Space = singleton(&(v1364_11_head));
        let v1365_3: Space = intersect(&(*CONSTANT_2),&(v1365_2));
        let v1365_4: Space = if has_head(&(v1365_3)) { singleton(&[]) } else { Space::new() };
        drop(v1365_3);
        let v1365_5: Space = subtract(&(*CONSTANT_1),&(v1365_4));
        drop(v1365_4);
        let v1365_8: Space = if (v1365_5).is_empty() { Space::new() } else {
          let v1366_6: Path = concat_path(&(v1364_6),&(v1364_11_head));
          let v1366_7: Space = routine_178(c, &(v1366_6), &(*p1), &(v1364_11_tail), &(*s1));
          compose(&(v1365_5),&(v1366_7))
        };
        drop(v1365_5);
        let v1365_9: Space = intersect(&(*CONSTANT_2),&(v1365_2));
        drop(v1365_2);
        let v1365_10: Space = if has_head(&(v1365_9)) { singleton(&[]) } else { Space::new() };
        drop(v1365_9);
        let v1365_12: Space = if (v1365_10).is_empty() { Space::new() } else {
          let v1367_6: Path = concat_path(&(v1364_6),&(v1364_11_head));
          let v1367_11: Space = routine_36(c, &(v1367_6), &(*p1), &(v1364_11_tail), &(*s1));
          drop(v1367_6);
          compose(&(v1365_10),&(v1367_11))
        };
        drop(v1365_10);
        let v1365_13: Space = unite(&(v1365_8),&(v1365_12));
        v1364_11.join_into((v1365_13).clone());
      }
      drop(v1364_11_cursor);
      drop(v1364_6);
      compose(&(v1359_10),&(v1364_11))
    };
    drop(v1359_10);
    let v1359_13: Space = unite(&(v1359_8),&(v1359_12));
    v1358_13.join_into((v1359_13).clone());
  }
  drop(v1358_13_cursor);
  (v1358_13).clone()
}

fn routine_151(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1368_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v1368_10: Space = unwrap(&(v1368_8),&(*CONSTANT_5));
  drop(v1368_8);
  let v1368_11: Space = unwrap(&(v1368_10),&(*p0));
  drop(v1368_10);
  let mut v1368_18 = Space::new();
  let mut v1368_18_cursor = (*s0).read_zipper();
  for v1368_18_byte in v1368_18_cursor.child_mask().iter() {
    v1368_18_cursor.descend_to_byte(v1368_18_byte);
    let v1368_18_tail = v1368_18_cursor.make_map();
    v1368_18_cursor.ascend(1);
    let v1368_18_head = Path::from_slice(&[v1368_18_byte]);
    let v1369_2: Space = singleton(&(v1368_18_head));
    let v1369_3: Space = intersect(&(*CONSTANT_2),&(v1369_2));
    let v1369_4: Space = if has_head(&(v1369_3)) { singleton(&[]) } else { Space::new() };
    drop(v1369_3);
    let v1369_5: Space = subtract(&(*CONSTANT_1),&(v1369_4));
    drop(v1369_4);
    let v1369_8: Space = if (v1369_5).is_empty() { Space::new() } else {
      let v1370_6: Path = concat_path(&(*p0),&(v1368_18_head));
      let mut v1370_7 = Space::new();
      let mut v1370_7_cursor = (v1368_18_tail).read_zipper();
      for v1370_7_byte in v1370_7_cursor.child_mask().iter() {
        v1370_7_cursor.descend_to_byte(v1370_7_byte);
        let v1370_7_tail = v1370_7_cursor.make_map();
        v1370_7_cursor.ascend(1);
        let v1370_7_head = Path::from_slice(&[v1370_7_byte]);
        let v1371_2: Space = singleton(&(v1370_7_head));
        let v1371_3: Space = intersect(&(*CONSTANT_2),&(v1371_2));
        let v1371_4: Space = if has_head(&(v1371_3)) { singleton(&[]) } else { Space::new() };
        drop(v1371_3);
        let v1371_5: Space = subtract(&(*CONSTANT_1),&(v1371_4));
        drop(v1371_4);
        let v1371_8: Space = if (v1371_5).is_empty() { Space::new() } else {
          let v1372_6: Path = concat_path(&(v1370_6),&(v1370_7_head));
          let v1372_7: Space = routine_178(c, &(v1372_6), &(*p1), &(v1370_7_tail), &(*s1));
          compose(&(v1371_5),&(v1372_7))
        };
        drop(v1371_5);
        let v1371_9: Space = intersect(&(*CONSTANT_2),&(v1371_2));
        drop(v1371_2);
        let v1371_10: Space = if has_head(&(v1371_9)) { singleton(&[]) } else { Space::new() };
        drop(v1371_9);
        let v1371_12: Space = if (v1371_10).is_empty() { Space::new() } else {
          let v1373_6: Path = concat_path(&(v1370_6),&(v1370_7_head));
          let v1373_11: Space = routine_179(c, &(v1373_6), &(*p1), &(v1370_7_tail), &(*s1));
          drop(v1373_6);
          compose(&(v1371_10),&(v1373_11))
        };
        drop(v1371_10);
        let v1371_13: Space = unite(&(v1371_8),&(v1371_12));
        v1370_7.join_into((v1371_13).clone());
      }
      drop(v1370_7_cursor);
      drop(v1370_6);
      compose(&(v1369_5),&(v1370_7))
    };
    drop(v1369_5);
    let v1369_9: Space = intersect(&(*CONSTANT_2),&(v1369_2));
    drop(v1369_2);
    let v1369_10: Space = if has_head(&(v1369_9)) { singleton(&[]) } else { Space::new() };
    drop(v1369_9);
    let v1369_13: Space = if (v1369_10).is_empty() { Space::new() } else {
      let v1374_11: Space = unwrap(&(v1368_11),&(v1368_18_head));
      let mut v1374_12 = Space::new();
      let mut v1374_12_cursor = (v1374_11).read_zipper();
      for v1374_12_byte in v1374_12_cursor.child_mask().iter() {
        v1374_12_cursor.descend_to_byte(v1374_12_byte);
        let v1374_12_tail = v1374_12_cursor.make_map();
        v1374_12_cursor.ascend(1);
        let v1374_12_head = Path::from_slice(&[v1374_12_byte]);
        let v1375_2: Space = singleton(&(v1374_12_head));
        let v1375_3: Space = intersect(&(*CONSTANT_2),&(v1375_2));
        let v1375_4: Space = if has_head(&(v1375_3)) { singleton(&[]) } else { Space::new() };
        drop(v1375_3);
        let v1375_5: Space = subtract(&(*CONSTANT_1),&(v1375_4));
        drop(v1375_4);
        let v1375_7: Space = if (v1375_5).is_empty() { Space::new() } else {
          let v1376_6: Space = routine_72(c, &(v1374_12_head), &(*p1), &(v1374_12_tail));
          compose(&(v1375_5),&(v1376_6))
        };
        drop(v1375_5);
        let v1375_8: Space = intersect(&(*CONSTANT_2),&(v1375_2));
        drop(v1375_2);
        let v1375_9: Space = if has_head(&(v1375_8)) { singleton(&[]) } else { Space::new() };
        drop(v1375_8);
        let v1375_11: Space = if (v1375_9).is_empty() { Space::new() } else {
          let v1377_10: Space = routine_73(c, &(v1374_12_head), &(*p1), &(v1374_12_tail));
          compose(&(v1375_9),&(v1377_10))
        };
        drop(v1375_9);
        let v1375_12: Space = unite(&(v1375_7),&(v1375_11));
        v1374_12.join_into((v1375_12).clone());
      }
      drop(v1374_12_cursor);
      drop(v1374_11);
      compose(&(v1369_10),&(v1374_12))
    };
    drop(v1369_10);
    let v1369_14: Space = unite(&(v1369_8),&(v1369_13));
    v1368_18.join_into((v1369_14).clone());
  }
  drop(v1368_18_cursor);
  drop(v1368_11);
  (v1368_18).clone()
}

fn routine_152(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1378_12 = Space::new();
  let mut v1378_12_cursor = (*s0).read_zipper();
  for v1378_12_byte in v1378_12_cursor.child_mask().iter() {
    v1378_12_cursor.descend_to_byte(v1378_12_byte);
    let v1378_12_tail = v1378_12_cursor.make_map();
    v1378_12_cursor.ascend(1);
    let v1378_12_head = Path::from_slice(&[v1378_12_byte]);
    let v1379_2: Space = singleton(&(v1378_12_head));
    let v1379_3: Space = intersect(&(*CONSTANT_2),&(v1379_2));
    let v1379_4: Space = if has_head(&(v1379_3)) { singleton(&[]) } else { Space::new() };
    drop(v1379_3);
    let v1379_5: Space = subtract(&(*CONSTANT_1),&(v1379_4));
    drop(v1379_4);
    let v1379_8: Space = if (v1379_5).is_empty() { Space::new() } else {
      let v1380_6: Path = concat_path(&(*p0),&(v1378_12_head));
      let mut v1380_7 = Space::new();
      let mut v1380_7_cursor = (v1378_12_tail).read_zipper();
      for v1380_7_byte in v1380_7_cursor.child_mask().iter() {
        v1380_7_cursor.descend_to_byte(v1380_7_byte);
        let v1380_7_tail = v1380_7_cursor.make_map();
        v1380_7_cursor.ascend(1);
        let v1380_7_head = Path::from_slice(&[v1380_7_byte]);
        let v1381_2: Space = singleton(&(v1380_7_head));
        let v1381_3: Space = intersect(&(*CONSTANT_2),&(v1381_2));
        let v1381_4: Space = if has_head(&(v1381_3)) { singleton(&[]) } else { Space::new() };
        drop(v1381_3);
        let v1381_5: Space = subtract(&(*CONSTANT_1),&(v1381_4));
        drop(v1381_4);
        let v1381_8: Space = if (v1381_5).is_empty() { Space::new() } else {
          let v1382_6: Path = concat_path(&(v1380_6),&(v1380_7_head));
          let v1382_7: Space = routine_180(c, &(v1382_6), &(*p1), &(v1380_7_tail));
          compose(&(v1381_5),&(v1382_7))
        };
        drop(v1381_5);
        let v1381_9: Space = intersect(&(*CONSTANT_2),&(v1381_2));
        drop(v1381_2);
        let v1381_10: Space = if has_head(&(v1381_9)) { singleton(&[]) } else { Space::new() };
        drop(v1381_9);
        let v1381_12: Space = if (v1381_10).is_empty() { Space::new() } else {
          let v1383_6: Path = concat_path(&(v1380_6),&(v1380_7_head));
          let v1383_11: Space = routine_181(c, &(v1383_6), &(*p1), &(v1380_7_tail));
          drop(v1383_6);
          compose(&(v1381_10),&(v1383_11))
        };
        drop(v1381_10);
        let v1381_13: Space = unite(&(v1381_8),&(v1381_12));
        v1380_7.join_into((v1381_13).clone());
      }
      drop(v1380_7_cursor);
      compose(&(v1379_5),&(v1380_7))
    };
    drop(v1379_5);
    let v1379_9: Space = intersect(&(*CONSTANT_2),&(v1379_2));
    drop(v1379_2);
    let v1379_10: Space = if has_head(&(v1379_9)) { singleton(&[]) } else { Space::new() };
    drop(v1379_9);
    let v1379_12: Space = if (v1379_10).is_empty() { Space::new() } else {
      let v1384_6: Path = concat_path(&(*p0),&(v1378_12_head));
      let mut v1384_11 = Space::new();
      let mut v1384_11_cursor = (v1378_12_tail).read_zipper();
      for v1384_11_byte in v1384_11_cursor.child_mask().iter() {
        v1384_11_cursor.descend_to_byte(v1384_11_byte);
        let v1384_11_tail = v1384_11_cursor.make_map();
        v1384_11_cursor.ascend(1);
        let v1384_11_head = Path::from_slice(&[v1384_11_byte]);
        let v1385_2: Space = singleton(&(v1384_11_head));
        let v1385_3: Space = intersect(&(*CONSTANT_2),&(v1385_2));
        let v1385_4: Space = if has_head(&(v1385_3)) { singleton(&[]) } else { Space::new() };
        drop(v1385_3);
        let v1385_5: Space = subtract(&(*CONSTANT_1),&(v1385_4));
        drop(v1385_4);
        let v1385_8: Space = if (v1385_5).is_empty() { Space::new() } else {
          let v1386_6: Path = concat_path(&(v1384_6),&(v1384_11_head));
          let v1386_7: Space = routine_180(c, &(v1386_6), &(*p1), &(v1384_11_tail));
          compose(&(v1385_5),&(v1386_7))
        };
        drop(v1385_5);
        let v1385_9: Space = intersect(&(*CONSTANT_2),&(v1385_2));
        drop(v1385_2);
        let v1385_10: Space = if has_head(&(v1385_9)) { singleton(&[]) } else { Space::new() };
        drop(v1385_9);
        let v1385_12: Space = if (v1385_10).is_empty() { Space::new() } else {
          let v1387_6: Path = concat_path(&(v1384_6),&(v1384_11_head));
          let v1387_11: Space = routine_78(c, &(v1387_6), &(*p1), &(v1384_11_tail));
          drop(v1387_6);
          compose(&(v1385_10),&(v1387_11))
        };
        drop(v1385_10);
        let v1385_13: Space = unite(&(v1385_8),&(v1385_12));
        v1384_11.join_into((v1385_13).clone());
      }
      drop(v1384_11_cursor);
      drop(v1384_6);
      compose(&(v1379_10),&(v1384_11))
    };
    drop(v1379_10);
    let v1379_13: Space = unite(&(v1379_8),&(v1379_12));
    v1378_12.join_into((v1379_13).clone());
  }
  drop(v1378_12_cursor);
  (v1378_12).clone()
}

fn routine_153(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1388_9 = Space::new();
  let mut v1388_9_cursor = (*s0).read_zipper();
  for v1388_9_byte in v1388_9_cursor.child_mask().iter() {
    v1388_9_cursor.descend_to_byte(v1388_9_byte);
    let v1388_9_tail = v1388_9_cursor.make_map();
    v1388_9_cursor.ascend(1);
    let v1388_9_head = Path::from_slice(&[v1388_9_byte]);
    let v1389_2: Space = singleton(&(v1388_9_head));
    let v1389_3: Space = intersect(&(*CONSTANT_2),&(v1389_2));
    let v1389_4: Space = if has_head(&(v1389_3)) { singleton(&[]) } else { Space::new() };
    drop(v1389_3);
    let v1389_5: Space = subtract(&(*CONSTANT_1),&(v1389_4));
    drop(v1389_4);
    let v1389_8: Space = if (v1389_5).is_empty() { Space::new() } else {
      let v1390_6: Path = concat_path(&(*p0),&(v1388_9_head));
      let mut v1390_7 = Space::new();
      let mut v1390_7_cursor = (v1388_9_tail).read_zipper();
      for v1390_7_byte in v1390_7_cursor.child_mask().iter() {
        v1390_7_cursor.descend_to_byte(v1390_7_byte);
        let v1390_7_tail = v1390_7_cursor.make_map();
        v1390_7_cursor.ascend(1);
        let v1390_7_head = Path::from_slice(&[v1390_7_byte]);
        let v1391_2: Space = singleton(&(v1390_7_head));
        let v1391_3: Space = intersect(&(*CONSTANT_2),&(v1391_2));
        let v1391_4: Space = if has_head(&(v1391_3)) { singleton(&[]) } else { Space::new() };
        drop(v1391_3);
        let v1391_5: Space = subtract(&(*CONSTANT_1),&(v1391_4));
        drop(v1391_4);
        let v1391_8: Space = if (v1391_5).is_empty() { Space::new() } else {
          let v1392_6: Path = concat_path(&(v1390_6),&(v1390_7_head));
          let v1392_7: Space = routine_180(c, &(v1392_6), &(*p1), &(v1390_7_tail));
          compose(&(v1391_5),&(v1392_7))
        };
        drop(v1391_5);
        let v1391_9: Space = intersect(&(*CONSTANT_2),&(v1391_2));
        drop(v1391_2);
        let v1391_10: Space = if has_head(&(v1391_9)) { singleton(&[]) } else { Space::new() };
        drop(v1391_9);
        let v1391_12: Space = if (v1391_10).is_empty() { Space::new() } else {
          let v1393_6: Path = concat_path(&(v1390_6),&(v1390_7_head));
          let v1393_11: Space = routine_181(c, &(v1393_6), &(*p1), &(v1390_7_tail));
          drop(v1393_6);
          compose(&(v1391_10),&(v1393_11))
        };
        drop(v1391_10);
        let v1391_13: Space = unite(&(v1391_8),&(v1391_12));
        v1390_7.join_into((v1391_13).clone());
      }
      drop(v1390_7_cursor);
      compose(&(v1389_5),&(v1390_7))
    };
    drop(v1389_5);
    let v1389_9: Space = intersect(&(*CONSTANT_2),&(v1389_2));
    drop(v1389_2);
    let v1389_10: Space = if has_head(&(v1389_9)) { singleton(&[]) } else { Space::new() };
    drop(v1389_9);
    let v1389_11: Space = compose(&(v1389_10),&(v1388_9_tail));
    drop(v1389_10);
    let v1394_6: Path = concat_path(&(*p0),&(v1388_9_head));
    let v1389_12: Space = wrap(&(v1389_11),&(v1394_6));
    drop(v1389_11);
    let v1389_13: Space = wrap(&(v1389_12),&(*p1));
    drop(v1389_12);
    let v1389_14: Space = unite(&(v1389_8),&(v1389_13));
    drop(v1389_13);
    v1388_9.join_into((v1389_14).clone());
  }
  drop(v1388_9_cursor);
  (v1388_9).clone()
}

fn routine_154(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1395_8 = Space::new();
  let mut v1395_8_cursor = (*s0).read_zipper();
  for v1395_8_byte in v1395_8_cursor.child_mask().iter() {
    v1395_8_cursor.descend_to_byte(v1395_8_byte);
    let v1395_8_tail = v1395_8_cursor.make_map();
    v1395_8_cursor.ascend(1);
    let v1395_8_head = Path::from_slice(&[v1395_8_byte]);
    let v1396_2: Space = singleton(&(v1395_8_head));
    let v1396_3: Space = intersect(&(*CONSTANT_2),&(v1396_2));
    let v1396_4: Space = if has_head(&(v1396_3)) { singleton(&[]) } else { Space::new() };
    drop(v1396_3);
    let v1396_5: Space = subtract(&(*CONSTANT_1),&(v1396_4));
    drop(v1396_4);
    let mut v1396_6 = Space::new();
    let mut v1396_6_cursor = (v1395_8_tail).read_zipper();
    for v1396_6_byte in v1396_6_cursor.child_mask().iter() {
      v1396_6_cursor.descend_to_byte(v1396_6_byte);
      let v1396_6_tail = v1396_6_cursor.make_map();
      v1396_6_cursor.ascend(1);
      let v1396_6_head = Path::from_slice(&[v1396_6_byte]);
      let v1397_2: Space = Space::new();
      v1396_6.join_into((v1397_2).clone());
    }
    drop(v1396_6_cursor);
    let v1396_7: Space = compose(&(v1396_5),&(v1396_6));
    drop(v1396_5);
    drop(v1396_6);
    let v1396_8: Space = intersect(&(*CONSTANT_2),&(v1396_2));
    drop(v1396_2);
    let v1396_9: Space = if has_head(&(v1396_8)) { singleton(&[]) } else { Space::new() };
    drop(v1396_8);
    let v1396_12: Space = if (v1396_9).is_empty() { Space::new() } else {
      let v1398_10: Path = concat_path(&(*p0),&(v1395_8_head));
      let mut v1398_11 = Space::new();
      let mut v1398_11_cursor = (v1395_8_tail).read_zipper();
      for v1398_11_byte in v1398_11_cursor.child_mask().iter() {
        v1398_11_cursor.descend_to_byte(v1398_11_byte);
        let v1398_11_tail = v1398_11_cursor.make_map();
        v1398_11_cursor.ascend(1);
        let v1398_11_head = Path::from_slice(&[v1398_11_byte]);
        let v1399_2: Space = singleton(&(v1398_11_head));
        let v1399_3: Space = intersect(&(*CONSTANT_2),&(v1399_2));
        drop(v1399_2);
        let v1399_4: Space = if has_head(&(v1399_3)) { singleton(&[]) } else { Space::new() };
        drop(v1399_3);
        let v1399_7: Space = if (v1399_4).is_empty() { Space::new() } else {
          let v1400_5: Path = concat_path(&(v1398_10),&(v1398_11_head));
          let v1400_6: Space = routine_36(c, &(v1400_5), &(*p1), &(v1398_11_tail), &(*s1));
          drop(v1400_5);
          compose(&(v1399_4),&(v1400_6))
        };
        drop(v1399_4);
        v1398_11.join_into((v1399_7).clone());
      }
      drop(v1398_11_cursor);
      drop(v1398_10);
      compose(&(v1396_9),&(v1398_11))
    };
    drop(v1396_9);
    let v1396_13: Space = unite(&(v1396_7),&(v1396_12));
    drop(v1396_7);
    v1395_8.join_into((v1396_13).clone());
  }
  drop(v1395_8_cursor);
  (v1395_8).clone()
}

fn routine_155(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1401_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v1401_10: Space = unwrap(&(v1401_8),&(*CONSTANT_5));
  drop(v1401_8);
  let v1401_11: Space = unwrap(&(v1401_10),&(*p0));
  drop(v1401_10);
  let mut v1401_15 = Space::new();
  let mut v1401_15_cursor = (*s0).read_zipper();
  for v1401_15_byte in v1401_15_cursor.child_mask().iter() {
    v1401_15_cursor.descend_to_byte(v1401_15_byte);
    let v1401_15_tail = v1401_15_cursor.make_map();
    v1401_15_cursor.ascend(1);
    let v1401_15_head = Path::from_slice(&[v1401_15_byte]);
    let v1402_2: Space = singleton(&(v1401_15_head));
    let v1402_3: Space = intersect(&(*CONSTANT_2),&(v1402_2));
    let v1402_4: Space = if has_head(&(v1402_3)) { singleton(&[]) } else { Space::new() };
    drop(v1402_3);
    let v1402_5: Space = subtract(&(*CONSTANT_1),&(v1402_4));
    drop(v1402_4);
    let mut v1402_6 = Space::new();
    let mut v1402_6_cursor = (v1401_15_tail).read_zipper();
    for v1402_6_byte in v1402_6_cursor.child_mask().iter() {
      v1402_6_cursor.descend_to_byte(v1402_6_byte);
      let v1402_6_tail = v1402_6_cursor.make_map();
      v1402_6_cursor.ascend(1);
      let v1402_6_head = Path::from_slice(&[v1402_6_byte]);
      let v1403_2: Space = Space::new();
      v1402_6.join_into((v1403_2).clone());
    }
    drop(v1402_6_cursor);
    let v1402_7: Space = compose(&(v1402_5),&(v1402_6));
    drop(v1402_5);
    drop(v1402_6);
    let v1402_8: Space = intersect(&(*CONSTANT_2),&(v1402_2));
    drop(v1402_2);
    let v1402_9: Space = if has_head(&(v1402_8)) { singleton(&[]) } else { Space::new() };
    drop(v1402_8);
    let v1402_12: Space = if (v1402_9).is_empty() { Space::new() } else {
      let v1404_10: Space = unwrap(&(v1401_11),&(v1401_15_head));
      let mut v1404_11 = Space::new();
      let mut v1404_11_cursor = (v1404_10).read_zipper();
      for v1404_11_byte in v1404_11_cursor.child_mask().iter() {
        v1404_11_cursor.descend_to_byte(v1404_11_byte);
        let v1404_11_tail = v1404_11_cursor.make_map();
        v1404_11_cursor.ascend(1);
        let v1404_11_head = Path::from_slice(&[v1404_11_byte]);
        let v1405_2: Space = singleton(&(v1404_11_head));
        let v1405_3: Space = intersect(&(*CONSTANT_2),&(v1405_2));
        let v1405_4: Space = if has_head(&(v1405_3)) { singleton(&[]) } else { Space::new() };
        drop(v1405_3);
        let v1405_5: Space = subtract(&(*CONSTANT_1),&(v1405_4));
        drop(v1405_4);
        let v1405_7: Space = if (v1405_5).is_empty() { Space::new() } else {
          let v1406_6: Space = routine_72(c, &(v1404_11_head), &(*p1), &(v1404_11_tail));
          compose(&(v1405_5),&(v1406_6))
        };
        drop(v1405_5);
        let v1405_8: Space = intersect(&(*CONSTANT_2),&(v1405_2));
        drop(v1405_2);
        let v1405_9: Space = if has_head(&(v1405_8)) { singleton(&[]) } else { Space::new() };
        drop(v1405_8);
        let v1405_11: Space = if (v1405_9).is_empty() { Space::new() } else {
          let v1407_10: Space = routine_73(c, &(v1404_11_head), &(*p1), &(v1404_11_tail));
          compose(&(v1405_9),&(v1407_10))
        };
        drop(v1405_9);
        let v1405_12: Space = unite(&(v1405_7),&(v1405_11));
        v1404_11.join_into((v1405_12).clone());
      }
      drop(v1404_11_cursor);
      drop(v1404_10);
      compose(&(v1402_9),&(v1404_11))
    };
    drop(v1402_9);
    let v1402_13: Space = unite(&(v1402_7),&(v1402_12));
    drop(v1402_7);
    v1401_15.join_into((v1402_13).clone());
  }
  drop(v1401_15_cursor);
  drop(v1401_11);
  (v1401_15).clone()
}

fn routine_156(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1408_12 = Space::new();
  let mut v1408_12_cursor = (*s0).read_zipper();
  for v1408_12_byte in v1408_12_cursor.child_mask().iter() {
    v1408_12_cursor.descend_to_byte(v1408_12_byte);
    let v1408_12_tail = v1408_12_cursor.make_map();
    v1408_12_cursor.ascend(1);
    let v1408_12_head = Path::from_slice(&[v1408_12_byte]);
    let v1409_2: Space = singleton(&(v1408_12_head));
    let v1409_3: Space = intersect(&(*CONSTANT_2),&(v1409_2));
    let v1409_4: Space = if has_head(&(v1409_3)) { singleton(&[]) } else { Space::new() };
    drop(v1409_3);
    let v1409_5: Space = subtract(&(*CONSTANT_1),&(v1409_4));
    drop(v1409_4);
    let v1409_8: Space = if (v1409_5).is_empty() { Space::new() } else {
      let v1410_6: Path = concat_path(&(*p0),&(v1408_12_head));
      let mut v1410_7 = Space::new();
      let mut v1410_7_cursor = (v1408_12_tail).read_zipper();
      for v1410_7_byte in v1410_7_cursor.child_mask().iter() {
        v1410_7_cursor.descend_to_byte(v1410_7_byte);
        let v1410_7_tail = v1410_7_cursor.make_map();
        v1410_7_cursor.ascend(1);
        let v1410_7_head = Path::from_slice(&[v1410_7_byte]);
        let v1411_2: Space = singleton(&(v1410_7_head));
        let v1411_3: Space = intersect(&(*CONSTANT_2),&(v1411_2));
        let v1411_4: Space = if has_head(&(v1411_3)) { singleton(&[]) } else { Space::new() };
        drop(v1411_3);
        let v1411_5: Space = subtract(&(*CONSTANT_1),&(v1411_4));
        drop(v1411_4);
        let v1411_8: Space = if (v1411_5).is_empty() { Space::new() } else {
          let v1412_6: Path = concat_path(&(v1410_6),&(v1410_7_head));
          let v1412_7: Space = routine_182(c, &(v1412_6), &(*p1), &(v1410_7_tail));
          compose(&(v1411_5),&(v1412_7))
        };
        drop(v1411_5);
        let v1411_9: Space = intersect(&(*CONSTANT_2),&(v1411_2));
        drop(v1411_2);
        let v1411_10: Space = if has_head(&(v1411_9)) { singleton(&[]) } else { Space::new() };
        drop(v1411_9);
        let v1411_12: Space = if (v1411_10).is_empty() { Space::new() } else {
          let v1413_6: Path = concat_path(&(v1410_6),&(v1410_7_head));
          let v1413_11: Space = routine_183(c, &(v1413_6), &(*p1), &(v1410_7_tail));
          drop(v1413_6);
          compose(&(v1411_10),&(v1413_11))
        };
        drop(v1411_10);
        let v1411_13: Space = unite(&(v1411_8),&(v1411_12));
        v1410_7.join_into((v1411_13).clone());
      }
      drop(v1410_7_cursor);
      compose(&(v1409_5),&(v1410_7))
    };
    drop(v1409_5);
    let v1409_9: Space = intersect(&(*CONSTANT_2),&(v1409_2));
    drop(v1409_2);
    let v1409_10: Space = if has_head(&(v1409_9)) { singleton(&[]) } else { Space::new() };
    drop(v1409_9);
    let v1409_12: Space = if (v1409_10).is_empty() { Space::new() } else {
      let v1414_6: Path = concat_path(&(*p0),&(v1408_12_head));
      let mut v1414_11 = Space::new();
      let mut v1414_11_cursor = (v1408_12_tail).read_zipper();
      for v1414_11_byte in v1414_11_cursor.child_mask().iter() {
        v1414_11_cursor.descend_to_byte(v1414_11_byte);
        let v1414_11_tail = v1414_11_cursor.make_map();
        v1414_11_cursor.ascend(1);
        let v1414_11_head = Path::from_slice(&[v1414_11_byte]);
        let v1415_2: Space = singleton(&(v1414_11_head));
        let v1415_3: Space = intersect(&(*CONSTANT_2),&(v1415_2));
        let v1415_4: Space = if has_head(&(v1415_3)) { singleton(&[]) } else { Space::new() };
        drop(v1415_3);
        let v1415_5: Space = subtract(&(*CONSTANT_1),&(v1415_4));
        drop(v1415_4);
        let v1415_8: Space = if (v1415_5).is_empty() { Space::new() } else {
          let v1416_6: Path = concat_path(&(v1414_6),&(v1414_11_head));
          let v1416_7: Space = routine_182(c, &(v1416_6), &(*p1), &(v1414_11_tail));
          compose(&(v1415_5),&(v1416_7))
        };
        drop(v1415_5);
        let v1415_9: Space = intersect(&(*CONSTANT_2),&(v1415_2));
        drop(v1415_2);
        let v1415_10: Space = if has_head(&(v1415_9)) { singleton(&[]) } else { Space::new() };
        drop(v1415_9);
        let v1415_12: Space = if (v1415_10).is_empty() { Space::new() } else {
          let v1417_6: Path = concat_path(&(v1414_6),&(v1414_11_head));
          let v1417_11: Space = routine_78(c, &(v1417_6), &(*p1), &(v1414_11_tail));
          drop(v1417_6);
          compose(&(v1415_10),&(v1417_11))
        };
        drop(v1415_10);
        let v1415_13: Space = unite(&(v1415_8),&(v1415_12));
        v1414_11.join_into((v1415_13).clone());
      }
      drop(v1414_11_cursor);
      drop(v1414_6);
      compose(&(v1409_10),&(v1414_11))
    };
    drop(v1409_10);
    let v1409_13: Space = unite(&(v1409_8),&(v1409_12));
    v1408_12.join_into((v1409_13).clone());
  }
  drop(v1408_12_cursor);
  (v1408_12).clone()
}

fn routine_157(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1418_9 = Space::new();
  let mut v1418_9_cursor = (*s0).read_zipper();
  for v1418_9_byte in v1418_9_cursor.child_mask().iter() {
    v1418_9_cursor.descend_to_byte(v1418_9_byte);
    let v1418_9_tail = v1418_9_cursor.make_map();
    v1418_9_cursor.ascend(1);
    let v1418_9_head = Path::from_slice(&[v1418_9_byte]);
    let v1419_2: Space = singleton(&(v1418_9_head));
    let v1419_3: Space = intersect(&(*CONSTANT_2),&(v1419_2));
    let v1419_4: Space = if has_head(&(v1419_3)) { singleton(&[]) } else { Space::new() };
    drop(v1419_3);
    let v1419_5: Space = subtract(&(*CONSTANT_1),&(v1419_4));
    drop(v1419_4);
    let v1419_8: Space = if (v1419_5).is_empty() { Space::new() } else {
      let v1420_6: Path = concat_path(&(*p0),&(v1418_9_head));
      let mut v1420_7 = Space::new();
      let mut v1420_7_cursor = (v1418_9_tail).read_zipper();
      for v1420_7_byte in v1420_7_cursor.child_mask().iter() {
        v1420_7_cursor.descend_to_byte(v1420_7_byte);
        let v1420_7_tail = v1420_7_cursor.make_map();
        v1420_7_cursor.ascend(1);
        let v1420_7_head = Path::from_slice(&[v1420_7_byte]);
        let v1421_2: Space = singleton(&(v1420_7_head));
        let v1421_3: Space = intersect(&(*CONSTANT_2),&(v1421_2));
        let v1421_4: Space = if has_head(&(v1421_3)) { singleton(&[]) } else { Space::new() };
        drop(v1421_3);
        let v1421_5: Space = subtract(&(*CONSTANT_1),&(v1421_4));
        drop(v1421_4);
        let v1421_8: Space = if (v1421_5).is_empty() { Space::new() } else {
          let v1422_6: Path = concat_path(&(v1420_6),&(v1420_7_head));
          let v1422_7: Space = routine_182(c, &(v1422_6), &(*p1), &(v1420_7_tail));
          compose(&(v1421_5),&(v1422_7))
        };
        drop(v1421_5);
        let v1421_9: Space = intersect(&(*CONSTANT_2),&(v1421_2));
        drop(v1421_2);
        let v1421_10: Space = if has_head(&(v1421_9)) { singleton(&[]) } else { Space::new() };
        drop(v1421_9);
        let v1421_12: Space = if (v1421_10).is_empty() { Space::new() } else {
          let v1423_6: Path = concat_path(&(v1420_6),&(v1420_7_head));
          let v1423_11: Space = routine_183(c, &(v1423_6), &(*p1), &(v1420_7_tail));
          drop(v1423_6);
          compose(&(v1421_10),&(v1423_11))
        };
        drop(v1421_10);
        let v1421_13: Space = unite(&(v1421_8),&(v1421_12));
        v1420_7.join_into((v1421_13).clone());
      }
      drop(v1420_7_cursor);
      compose(&(v1419_5),&(v1420_7))
    };
    drop(v1419_5);
    let v1419_9: Space = intersect(&(*CONSTANT_2),&(v1419_2));
    drop(v1419_2);
    let v1419_10: Space = if has_head(&(v1419_9)) { singleton(&[]) } else { Space::new() };
    drop(v1419_9);
    let v1419_11: Space = compose(&(v1419_10),&(v1418_9_tail));
    drop(v1419_10);
    let v1424_6: Path = concat_path(&(*p0),&(v1418_9_head));
    let v1419_12: Space = wrap(&(v1419_11),&(v1424_6));
    drop(v1419_11);
    let v1419_13: Space = wrap(&(v1419_12),&(*p1));
    drop(v1419_12);
    let v1419_14: Space = unite(&(v1419_8),&(v1419_13));
    drop(v1419_13);
    v1418_9.join_into((v1419_14).clone());
  }
  drop(v1418_9_cursor);
  (v1418_9).clone()
}

fn routine_158(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1425_13 = Space::new();
  let mut v1425_13_cursor = (*s0).read_zipper();
  for v1425_13_byte in v1425_13_cursor.child_mask().iter() {
    v1425_13_cursor.descend_to_byte(v1425_13_byte);
    let v1425_13_tail = v1425_13_cursor.make_map();
    v1425_13_cursor.ascend(1);
    let v1425_13_head = Path::from_slice(&[v1425_13_byte]);
    let v1426_2: Space = singleton(&(v1425_13_head));
    let v1426_3: Space = intersect(&(*CONSTANT_2),&(v1426_2));
    let v1426_4: Space = if has_head(&(v1426_3)) { singleton(&[]) } else { Space::new() };
    drop(v1426_3);
    let v1426_5: Space = subtract(&(*CONSTANT_1),&(v1426_4));
    drop(v1426_4);
    let v1426_8: Space = if (v1426_5).is_empty() { Space::new() } else {
      let v1427_6: Path = concat_path(&(*p0),&(v1425_13_head));
      let mut v1427_7 = Space::new();
      let mut v1427_7_cursor = (v1425_13_tail).read_zipper();
      for v1427_7_byte in v1427_7_cursor.child_mask().iter() {
        v1427_7_cursor.descend_to_byte(v1427_7_byte);
        let v1427_7_tail = v1427_7_cursor.make_map();
        v1427_7_cursor.ascend(1);
        let v1427_7_head = Path::from_slice(&[v1427_7_byte]);
        let v1428_2: Space = singleton(&(v1427_7_head));
        let v1428_3: Space = intersect(&(*CONSTANT_2),&(v1428_2));
        let v1428_4: Space = if has_head(&(v1428_3)) { singleton(&[]) } else { Space::new() };
        drop(v1428_3);
        let v1428_5: Space = subtract(&(*CONSTANT_1),&(v1428_4));
        drop(v1428_4);
        let v1428_8: Space = if (v1428_5).is_empty() { Space::new() } else {
          let v1429_6: Path = concat_path(&(v1427_6),&(v1427_7_head));
          let v1429_7: Space = routine_184(c, &(v1429_6), &(*p1), &(v1427_7_tail), &(*s1));
          compose(&(v1428_5),&(v1429_7))
        };
        drop(v1428_5);
        let v1428_9: Space = intersect(&(*CONSTANT_2),&(v1428_2));
        drop(v1428_2);
        let v1428_10: Space = if has_head(&(v1428_9)) { singleton(&[]) } else { Space::new() };
        drop(v1428_9);
        let v1428_12: Space = if (v1428_10).is_empty() { Space::new() } else {
          let v1430_6: Path = concat_path(&(v1427_6),&(v1427_7_head));
          let v1430_11: Space = routine_185(c, &(v1430_6), &(*p1), &(v1427_7_tail), &(*s1));
          drop(v1430_6);
          compose(&(v1428_10),&(v1430_11))
        };
        drop(v1428_10);
        let v1428_13: Space = unite(&(v1428_8),&(v1428_12));
        v1427_7.join_into((v1428_13).clone());
      }
      drop(v1427_7_cursor);
      compose(&(v1426_5),&(v1427_7))
    };
    drop(v1426_5);
    let v1426_9: Space = intersect(&(*CONSTANT_2),&(v1426_2));
    drop(v1426_2);
    let v1426_10: Space = if has_head(&(v1426_9)) { singleton(&[]) } else { Space::new() };
    drop(v1426_9);
    let v1426_12: Space = if (v1426_10).is_empty() { Space::new() } else {
      let v1431_6: Path = concat_path(&(*p0),&(v1425_13_head));
      let mut v1431_11 = Space::new();
      let mut v1431_11_cursor = (v1425_13_tail).read_zipper();
      for v1431_11_byte in v1431_11_cursor.child_mask().iter() {
        v1431_11_cursor.descend_to_byte(v1431_11_byte);
        let v1431_11_tail = v1431_11_cursor.make_map();
        v1431_11_cursor.ascend(1);
        let v1431_11_head = Path::from_slice(&[v1431_11_byte]);
        let v1432_2: Space = singleton(&(v1431_11_head));
        let v1432_3: Space = intersect(&(*CONSTANT_2),&(v1432_2));
        let v1432_4: Space = if has_head(&(v1432_3)) { singleton(&[]) } else { Space::new() };
        drop(v1432_3);
        let v1432_5: Space = subtract(&(*CONSTANT_1),&(v1432_4));
        drop(v1432_4);
        let v1432_8: Space = if (v1432_5).is_empty() { Space::new() } else {
          let v1433_6: Path = concat_path(&(v1431_6),&(v1431_11_head));
          let v1433_7: Space = routine_184(c, &(v1433_6), &(*p1), &(v1431_11_tail), &(*s1));
          compose(&(v1432_5),&(v1433_7))
        };
        drop(v1432_5);
        let v1432_9: Space = intersect(&(*CONSTANT_2),&(v1432_2));
        drop(v1432_2);
        let v1432_10: Space = if has_head(&(v1432_9)) { singleton(&[]) } else { Space::new() };
        drop(v1432_9);
        let v1432_12: Space = if (v1432_10).is_empty() { Space::new() } else {
          let v1434_6: Path = concat_path(&(v1431_6),&(v1431_11_head));
          let v1434_11: Space = routine_43(c, &(v1434_6), &(*p1), &(v1431_11_tail), &(*s1));
          drop(v1434_6);
          compose(&(v1432_10),&(v1434_11))
        };
        drop(v1432_10);
        let v1432_13: Space = unite(&(v1432_8),&(v1432_12));
        v1431_11.join_into((v1432_13).clone());
      }
      drop(v1431_11_cursor);
      drop(v1431_6);
      compose(&(v1426_10),&(v1431_11))
    };
    drop(v1426_10);
    let v1426_13: Space = unite(&(v1426_8),&(v1426_12));
    v1425_13.join_into((v1426_13).clone());
  }
  drop(v1425_13_cursor);
  (v1425_13).clone()
}

fn routine_159(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1435_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v1435_10: Space = unwrap(&(v1435_8),&(*CONSTANT_5));
  drop(v1435_8);
  let v1435_11: Space = unwrap(&(v1435_10),&(*p0));
  drop(v1435_10);
  let mut v1435_18 = Space::new();
  let mut v1435_18_cursor = (*s0).read_zipper();
  for v1435_18_byte in v1435_18_cursor.child_mask().iter() {
    v1435_18_cursor.descend_to_byte(v1435_18_byte);
    let v1435_18_tail = v1435_18_cursor.make_map();
    v1435_18_cursor.ascend(1);
    let v1435_18_head = Path::from_slice(&[v1435_18_byte]);
    let v1436_2: Space = singleton(&(v1435_18_head));
    let v1436_3: Space = intersect(&(*CONSTANT_2),&(v1436_2));
    let v1436_4: Space = if has_head(&(v1436_3)) { singleton(&[]) } else { Space::new() };
    drop(v1436_3);
    let v1436_5: Space = subtract(&(*CONSTANT_1),&(v1436_4));
    drop(v1436_4);
    let v1436_8: Space = if (v1436_5).is_empty() { Space::new() } else {
      let v1437_6: Path = concat_path(&(*p0),&(v1435_18_head));
      let mut v1437_7 = Space::new();
      let mut v1437_7_cursor = (v1435_18_tail).read_zipper();
      for v1437_7_byte in v1437_7_cursor.child_mask().iter() {
        v1437_7_cursor.descend_to_byte(v1437_7_byte);
        let v1437_7_tail = v1437_7_cursor.make_map();
        v1437_7_cursor.ascend(1);
        let v1437_7_head = Path::from_slice(&[v1437_7_byte]);
        let v1438_2: Space = singleton(&(v1437_7_head));
        let v1438_3: Space = intersect(&(*CONSTANT_2),&(v1438_2));
        let v1438_4: Space = if has_head(&(v1438_3)) { singleton(&[]) } else { Space::new() };
        drop(v1438_3);
        let v1438_5: Space = subtract(&(*CONSTANT_1),&(v1438_4));
        drop(v1438_4);
        let v1438_8: Space = if (v1438_5).is_empty() { Space::new() } else {
          let v1439_6: Path = concat_path(&(v1437_6),&(v1437_7_head));
          let v1439_7: Space = routine_184(c, &(v1439_6), &(*p1), &(v1437_7_tail), &(*s1));
          compose(&(v1438_5),&(v1439_7))
        };
        drop(v1438_5);
        let v1438_9: Space = intersect(&(*CONSTANT_2),&(v1438_2));
        drop(v1438_2);
        let v1438_10: Space = if has_head(&(v1438_9)) { singleton(&[]) } else { Space::new() };
        drop(v1438_9);
        let v1438_12: Space = if (v1438_10).is_empty() { Space::new() } else {
          let v1440_6: Path = concat_path(&(v1437_6),&(v1437_7_head));
          let v1440_11: Space = routine_185(c, &(v1440_6), &(*p1), &(v1437_7_tail), &(*s1));
          drop(v1440_6);
          compose(&(v1438_10),&(v1440_11))
        };
        drop(v1438_10);
        let v1438_13: Space = unite(&(v1438_8),&(v1438_12));
        v1437_7.join_into((v1438_13).clone());
      }
      drop(v1437_7_cursor);
      drop(v1437_6);
      compose(&(v1436_5),&(v1437_7))
    };
    drop(v1436_5);
    let v1436_9: Space = intersect(&(*CONSTANT_2),&(v1436_2));
    drop(v1436_2);
    let v1436_10: Space = if has_head(&(v1436_9)) { singleton(&[]) } else { Space::new() };
    drop(v1436_9);
    let v1436_13: Space = if (v1436_10).is_empty() { Space::new() } else {
      let v1441_11: Space = unwrap(&(v1435_11),&(v1435_18_head));
      let mut v1441_12 = Space::new();
      let mut v1441_12_cursor = (v1441_11).read_zipper();
      for v1441_12_byte in v1441_12_cursor.child_mask().iter() {
        v1441_12_cursor.descend_to_byte(v1441_12_byte);
        let v1441_12_tail = v1441_12_cursor.make_map();
        v1441_12_cursor.ascend(1);
        let v1441_12_head = Path::from_slice(&[v1441_12_byte]);
        let v1442_2: Space = singleton(&(v1441_12_head));
        let v1442_3: Space = intersect(&(*CONSTANT_2),&(v1442_2));
        let v1442_4: Space = if has_head(&(v1442_3)) { singleton(&[]) } else { Space::new() };
        drop(v1442_3);
        let v1442_5: Space = subtract(&(*CONSTANT_1),&(v1442_4));
        drop(v1442_4);
        let v1442_7: Space = if (v1442_5).is_empty() { Space::new() } else {
          let v1443_6: Space = routine_83(c, &(v1441_12_head), &(*p1), &(v1441_12_tail));
          compose(&(v1442_5),&(v1443_6))
        };
        drop(v1442_5);
        let v1442_8: Space = intersect(&(*CONSTANT_2),&(v1442_2));
        drop(v1442_2);
        let v1442_9: Space = if has_head(&(v1442_8)) { singleton(&[]) } else { Space::new() };
        drop(v1442_8);
        let v1442_11: Space = if (v1442_9).is_empty() { Space::new() } else {
          let v1444_10: Space = routine_84(c, &(v1441_12_head), &(*p1), &(v1441_12_tail));
          compose(&(v1442_9),&(v1444_10))
        };
        drop(v1442_9);
        let v1442_12: Space = unite(&(v1442_7),&(v1442_11));
        v1441_12.join_into((v1442_12).clone());
      }
      drop(v1441_12_cursor);
      drop(v1441_11);
      compose(&(v1436_10),&(v1441_12))
    };
    drop(v1436_10);
    let v1436_14: Space = unite(&(v1436_8),&(v1436_13));
    v1435_18.join_into((v1436_14).clone());
  }
  drop(v1435_18_cursor);
  drop(v1435_11);
  (v1435_18).clone()
}

fn routine_160(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1445_12 = Space::new();
  let mut v1445_12_cursor = (*s0).read_zipper();
  for v1445_12_byte in v1445_12_cursor.child_mask().iter() {
    v1445_12_cursor.descend_to_byte(v1445_12_byte);
    let v1445_12_tail = v1445_12_cursor.make_map();
    v1445_12_cursor.ascend(1);
    let v1445_12_head = Path::from_slice(&[v1445_12_byte]);
    let v1446_2: Space = singleton(&(v1445_12_head));
    let v1446_3: Space = intersect(&(*CONSTANT_2),&(v1446_2));
    let v1446_4: Space = if has_head(&(v1446_3)) { singleton(&[]) } else { Space::new() };
    drop(v1446_3);
    let v1446_5: Space = subtract(&(*CONSTANT_1),&(v1446_4));
    drop(v1446_4);
    let v1446_8: Space = if (v1446_5).is_empty() { Space::new() } else {
      let v1447_6: Path = concat_path(&(*p0),&(v1445_12_head));
      let mut v1447_7 = Space::new();
      let mut v1447_7_cursor = (v1445_12_tail).read_zipper();
      for v1447_7_byte in v1447_7_cursor.child_mask().iter() {
        v1447_7_cursor.descend_to_byte(v1447_7_byte);
        let v1447_7_tail = v1447_7_cursor.make_map();
        v1447_7_cursor.ascend(1);
        let v1447_7_head = Path::from_slice(&[v1447_7_byte]);
        let v1448_2: Space = singleton(&(v1447_7_head));
        let v1448_3: Space = intersect(&(*CONSTANT_2),&(v1448_2));
        let v1448_4: Space = if has_head(&(v1448_3)) { singleton(&[]) } else { Space::new() };
        drop(v1448_3);
        let v1448_5: Space = subtract(&(*CONSTANT_1),&(v1448_4));
        drop(v1448_4);
        let v1448_8: Space = if (v1448_5).is_empty() { Space::new() } else {
          let v1449_6: Path = concat_path(&(v1447_6),&(v1447_7_head));
          let v1449_7: Space = routine_186(c, &(v1449_6), &(*p1), &(v1447_7_tail));
          compose(&(v1448_5),&(v1449_7))
        };
        drop(v1448_5);
        let v1448_9: Space = intersect(&(*CONSTANT_2),&(v1448_2));
        drop(v1448_2);
        let v1448_10: Space = if has_head(&(v1448_9)) { singleton(&[]) } else { Space::new() };
        drop(v1448_9);
        let v1448_12: Space = if (v1448_10).is_empty() { Space::new() } else {
          let v1450_6: Path = concat_path(&(v1447_6),&(v1447_7_head));
          let v1450_11: Space = routine_187(c, &(v1450_6), &(*p1), &(v1447_7_tail));
          drop(v1450_6);
          compose(&(v1448_10),&(v1450_11))
        };
        drop(v1448_10);
        let v1448_13: Space = unite(&(v1448_8),&(v1448_12));
        v1447_7.join_into((v1448_13).clone());
      }
      drop(v1447_7_cursor);
      compose(&(v1446_5),&(v1447_7))
    };
    drop(v1446_5);
    let v1446_9: Space = intersect(&(*CONSTANT_2),&(v1446_2));
    drop(v1446_2);
    let v1446_10: Space = if has_head(&(v1446_9)) { singleton(&[]) } else { Space::new() };
    drop(v1446_9);
    let v1446_12: Space = if (v1446_10).is_empty() { Space::new() } else {
      let v1451_6: Path = concat_path(&(*p0),&(v1445_12_head));
      let mut v1451_11 = Space::new();
      let mut v1451_11_cursor = (v1445_12_tail).read_zipper();
      for v1451_11_byte in v1451_11_cursor.child_mask().iter() {
        v1451_11_cursor.descend_to_byte(v1451_11_byte);
        let v1451_11_tail = v1451_11_cursor.make_map();
        v1451_11_cursor.ascend(1);
        let v1451_11_head = Path::from_slice(&[v1451_11_byte]);
        let v1452_2: Space = singleton(&(v1451_11_head));
        let v1452_3: Space = intersect(&(*CONSTANT_2),&(v1452_2));
        let v1452_4: Space = if has_head(&(v1452_3)) { singleton(&[]) } else { Space::new() };
        drop(v1452_3);
        let v1452_5: Space = subtract(&(*CONSTANT_1),&(v1452_4));
        drop(v1452_4);
        let v1452_8: Space = if (v1452_5).is_empty() { Space::new() } else {
          let v1453_6: Path = concat_path(&(v1451_6),&(v1451_11_head));
          let v1453_7: Space = routine_186(c, &(v1453_6), &(*p1), &(v1451_11_tail));
          compose(&(v1452_5),&(v1453_7))
        };
        drop(v1452_5);
        let v1452_9: Space = intersect(&(*CONSTANT_2),&(v1452_2));
        drop(v1452_2);
        let v1452_10: Space = if has_head(&(v1452_9)) { singleton(&[]) } else { Space::new() };
        drop(v1452_9);
        let v1452_12: Space = if (v1452_10).is_empty() { Space::new() } else {
          let v1454_6: Path = concat_path(&(v1451_6),&(v1451_11_head));
          let v1454_11: Space = routine_89(c, &(v1454_6), &(*p1), &(v1451_11_tail));
          drop(v1454_6);
          compose(&(v1452_10),&(v1454_11))
        };
        drop(v1452_10);
        let v1452_13: Space = unite(&(v1452_8),&(v1452_12));
        v1451_11.join_into((v1452_13).clone());
      }
      drop(v1451_11_cursor);
      drop(v1451_6);
      compose(&(v1446_10),&(v1451_11))
    };
    drop(v1446_10);
    let v1446_13: Space = unite(&(v1446_8),&(v1446_12));
    v1445_12.join_into((v1446_13).clone());
  }
  drop(v1445_12_cursor);
  (v1445_12).clone()
}

fn routine_161(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1455_9 = Space::new();
  let mut v1455_9_cursor = (*s0).read_zipper();
  for v1455_9_byte in v1455_9_cursor.child_mask().iter() {
    v1455_9_cursor.descend_to_byte(v1455_9_byte);
    let v1455_9_tail = v1455_9_cursor.make_map();
    v1455_9_cursor.ascend(1);
    let v1455_9_head = Path::from_slice(&[v1455_9_byte]);
    let v1456_2: Space = singleton(&(v1455_9_head));
    let v1456_3: Space = intersect(&(*CONSTANT_2),&(v1456_2));
    let v1456_4: Space = if has_head(&(v1456_3)) { singleton(&[]) } else { Space::new() };
    drop(v1456_3);
    let v1456_5: Space = subtract(&(*CONSTANT_1),&(v1456_4));
    drop(v1456_4);
    let v1456_8: Space = if (v1456_5).is_empty() { Space::new() } else {
      let v1457_6: Path = concat_path(&(*p0),&(v1455_9_head));
      let mut v1457_7 = Space::new();
      let mut v1457_7_cursor = (v1455_9_tail).read_zipper();
      for v1457_7_byte in v1457_7_cursor.child_mask().iter() {
        v1457_7_cursor.descend_to_byte(v1457_7_byte);
        let v1457_7_tail = v1457_7_cursor.make_map();
        v1457_7_cursor.ascend(1);
        let v1457_7_head = Path::from_slice(&[v1457_7_byte]);
        let v1458_2: Space = singleton(&(v1457_7_head));
        let v1458_3: Space = intersect(&(*CONSTANT_2),&(v1458_2));
        let v1458_4: Space = if has_head(&(v1458_3)) { singleton(&[]) } else { Space::new() };
        drop(v1458_3);
        let v1458_5: Space = subtract(&(*CONSTANT_1),&(v1458_4));
        drop(v1458_4);
        let v1458_8: Space = if (v1458_5).is_empty() { Space::new() } else {
          let v1459_6: Path = concat_path(&(v1457_6),&(v1457_7_head));
          let v1459_7: Space = routine_186(c, &(v1459_6), &(*p1), &(v1457_7_tail));
          compose(&(v1458_5),&(v1459_7))
        };
        drop(v1458_5);
        let v1458_9: Space = intersect(&(*CONSTANT_2),&(v1458_2));
        drop(v1458_2);
        let v1458_10: Space = if has_head(&(v1458_9)) { singleton(&[]) } else { Space::new() };
        drop(v1458_9);
        let v1458_12: Space = if (v1458_10).is_empty() { Space::new() } else {
          let v1460_6: Path = concat_path(&(v1457_6),&(v1457_7_head));
          let v1460_11: Space = routine_187(c, &(v1460_6), &(*p1), &(v1457_7_tail));
          drop(v1460_6);
          compose(&(v1458_10),&(v1460_11))
        };
        drop(v1458_10);
        let v1458_13: Space = unite(&(v1458_8),&(v1458_12));
        v1457_7.join_into((v1458_13).clone());
      }
      drop(v1457_7_cursor);
      compose(&(v1456_5),&(v1457_7))
    };
    drop(v1456_5);
    let v1456_9: Space = intersect(&(*CONSTANT_2),&(v1456_2));
    drop(v1456_2);
    let v1456_10: Space = if has_head(&(v1456_9)) { singleton(&[]) } else { Space::new() };
    drop(v1456_9);
    let v1456_11: Space = compose(&(v1456_10),&(v1455_9_tail));
    drop(v1456_10);
    let v1461_6: Path = concat_path(&(*p0),&(v1455_9_head));
    let v1456_12: Space = wrap(&(v1456_11),&(v1461_6));
    drop(v1456_11);
    let v1456_13: Space = wrap(&(v1456_12),&(*p1));
    drop(v1456_12);
    let v1456_14: Space = unite(&(v1456_8),&(v1456_13));
    drop(v1456_13);
    v1455_9.join_into((v1456_14).clone());
  }
  drop(v1455_9_cursor);
  (v1455_9).clone()
}

fn routine_162(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1462_8 = Space::new();
  let mut v1462_8_cursor = (*s0).read_zipper();
  for v1462_8_byte in v1462_8_cursor.child_mask().iter() {
    v1462_8_cursor.descend_to_byte(v1462_8_byte);
    let v1462_8_tail = v1462_8_cursor.make_map();
    v1462_8_cursor.ascend(1);
    let v1462_8_head = Path::from_slice(&[v1462_8_byte]);
    let v1463_2: Space = singleton(&(v1462_8_head));
    let v1463_3: Space = intersect(&(*CONSTANT_2),&(v1463_2));
    let v1463_4: Space = if has_head(&(v1463_3)) { singleton(&[]) } else { Space::new() };
    drop(v1463_3);
    let v1463_5: Space = subtract(&(*CONSTANT_1),&(v1463_4));
    drop(v1463_4);
    let mut v1463_6 = Space::new();
    let mut v1463_6_cursor = (v1462_8_tail).read_zipper();
    for v1463_6_byte in v1463_6_cursor.child_mask().iter() {
      v1463_6_cursor.descend_to_byte(v1463_6_byte);
      let v1463_6_tail = v1463_6_cursor.make_map();
      v1463_6_cursor.ascend(1);
      let v1463_6_head = Path::from_slice(&[v1463_6_byte]);
      let v1464_2: Space = Space::new();
      v1463_6.join_into((v1464_2).clone());
    }
    drop(v1463_6_cursor);
    let v1463_7: Space = compose(&(v1463_5),&(v1463_6));
    drop(v1463_5);
    drop(v1463_6);
    let v1463_8: Space = intersect(&(*CONSTANT_2),&(v1463_2));
    drop(v1463_2);
    let v1463_9: Space = if has_head(&(v1463_8)) { singleton(&[]) } else { Space::new() };
    drop(v1463_8);
    let v1463_12: Space = if (v1463_9).is_empty() { Space::new() } else {
      let v1465_10: Path = concat_path(&(*p0),&(v1462_8_head));
      let mut v1465_11 = Space::new();
      let mut v1465_11_cursor = (v1462_8_tail).read_zipper();
      for v1465_11_byte in v1465_11_cursor.child_mask().iter() {
        v1465_11_cursor.descend_to_byte(v1465_11_byte);
        let v1465_11_tail = v1465_11_cursor.make_map();
        v1465_11_cursor.ascend(1);
        let v1465_11_head = Path::from_slice(&[v1465_11_byte]);
        let v1466_2: Space = singleton(&(v1465_11_head));
        let v1466_3: Space = intersect(&(*CONSTANT_2),&(v1466_2));
        drop(v1466_2);
        let v1466_4: Space = if has_head(&(v1466_3)) { singleton(&[]) } else { Space::new() };
        drop(v1466_3);
        let v1466_7: Space = if (v1466_4).is_empty() { Space::new() } else {
          let v1467_5: Path = concat_path(&(v1465_10),&(v1465_11_head));
          let v1467_6: Space = routine_43(c, &(v1467_5), &(*p1), &(v1465_11_tail), &(*s1));
          drop(v1467_5);
          compose(&(v1466_4),&(v1467_6))
        };
        drop(v1466_4);
        v1465_11.join_into((v1466_7).clone());
      }
      drop(v1465_11_cursor);
      drop(v1465_10);
      compose(&(v1463_9),&(v1465_11))
    };
    drop(v1463_9);
    let v1463_13: Space = unite(&(v1463_7),&(v1463_12));
    drop(v1463_7);
    v1462_8.join_into((v1463_13).clone());
  }
  drop(v1462_8_cursor);
  (v1462_8).clone()
}

fn routine_163(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1468_8: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v1468_10: Space = unwrap(&(v1468_8),&(*CONSTANT_5));
  drop(v1468_8);
  let v1468_11: Space = unwrap(&(v1468_10),&(*p0));
  drop(v1468_10);
  let mut v1468_15 = Space::new();
  let mut v1468_15_cursor = (*s0).read_zipper();
  for v1468_15_byte in v1468_15_cursor.child_mask().iter() {
    v1468_15_cursor.descend_to_byte(v1468_15_byte);
    let v1468_15_tail = v1468_15_cursor.make_map();
    v1468_15_cursor.ascend(1);
    let v1468_15_head = Path::from_slice(&[v1468_15_byte]);
    let v1469_2: Space = singleton(&(v1468_15_head));
    let v1469_3: Space = intersect(&(*CONSTANT_2),&(v1469_2));
    let v1469_4: Space = if has_head(&(v1469_3)) { singleton(&[]) } else { Space::new() };
    drop(v1469_3);
    let v1469_5: Space = subtract(&(*CONSTANT_1),&(v1469_4));
    drop(v1469_4);
    let mut v1469_6 = Space::new();
    let mut v1469_6_cursor = (v1468_15_tail).read_zipper();
    for v1469_6_byte in v1469_6_cursor.child_mask().iter() {
      v1469_6_cursor.descend_to_byte(v1469_6_byte);
      let v1469_6_tail = v1469_6_cursor.make_map();
      v1469_6_cursor.ascend(1);
      let v1469_6_head = Path::from_slice(&[v1469_6_byte]);
      let v1470_2: Space = Space::new();
      v1469_6.join_into((v1470_2).clone());
    }
    drop(v1469_6_cursor);
    let v1469_7: Space = compose(&(v1469_5),&(v1469_6));
    drop(v1469_5);
    drop(v1469_6);
    let v1469_8: Space = intersect(&(*CONSTANT_2),&(v1469_2));
    drop(v1469_2);
    let v1469_9: Space = if has_head(&(v1469_8)) { singleton(&[]) } else { Space::new() };
    drop(v1469_8);
    let v1469_12: Space = if (v1469_9).is_empty() { Space::new() } else {
      let v1471_10: Space = unwrap(&(v1468_11),&(v1468_15_head));
      let mut v1471_11 = Space::new();
      let mut v1471_11_cursor = (v1471_10).read_zipper();
      for v1471_11_byte in v1471_11_cursor.child_mask().iter() {
        v1471_11_cursor.descend_to_byte(v1471_11_byte);
        let v1471_11_tail = v1471_11_cursor.make_map();
        v1471_11_cursor.ascend(1);
        let v1471_11_head = Path::from_slice(&[v1471_11_byte]);
        let v1472_2: Space = singleton(&(v1471_11_head));
        let v1472_3: Space = intersect(&(*CONSTANT_2),&(v1472_2));
        let v1472_4: Space = if has_head(&(v1472_3)) { singleton(&[]) } else { Space::new() };
        drop(v1472_3);
        let v1472_5: Space = subtract(&(*CONSTANT_1),&(v1472_4));
        drop(v1472_4);
        let v1472_7: Space = if (v1472_5).is_empty() { Space::new() } else {
          let v1473_6: Space = routine_83(c, &(v1471_11_head), &(*p1), &(v1471_11_tail));
          compose(&(v1472_5),&(v1473_6))
        };
        drop(v1472_5);
        let v1472_8: Space = intersect(&(*CONSTANT_2),&(v1472_2));
        drop(v1472_2);
        let v1472_9: Space = if has_head(&(v1472_8)) { singleton(&[]) } else { Space::new() };
        drop(v1472_8);
        let v1472_11: Space = if (v1472_9).is_empty() { Space::new() } else {
          let v1474_10: Space = routine_84(c, &(v1471_11_head), &(*p1), &(v1471_11_tail));
          compose(&(v1472_9),&(v1474_10))
        };
        drop(v1472_9);
        let v1472_12: Space = unite(&(v1472_7),&(v1472_11));
        v1471_11.join_into((v1472_12).clone());
      }
      drop(v1471_11_cursor);
      drop(v1471_10);
      compose(&(v1469_9),&(v1471_11))
    };
    drop(v1469_9);
    let v1469_13: Space = unite(&(v1469_7),&(v1469_12));
    drop(v1469_7);
    v1468_15.join_into((v1469_13).clone());
  }
  drop(v1468_15_cursor);
  drop(v1468_11);
  (v1468_15).clone()
}

fn routine_164(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1475_12 = Space::new();
  let mut v1475_12_cursor = (*s0).read_zipper();
  for v1475_12_byte in v1475_12_cursor.child_mask().iter() {
    v1475_12_cursor.descend_to_byte(v1475_12_byte);
    let v1475_12_tail = v1475_12_cursor.make_map();
    v1475_12_cursor.ascend(1);
    let v1475_12_head = Path::from_slice(&[v1475_12_byte]);
    let v1476_2: Space = singleton(&(v1475_12_head));
    let v1476_3: Space = intersect(&(*CONSTANT_2),&(v1476_2));
    let v1476_4: Space = if has_head(&(v1476_3)) { singleton(&[]) } else { Space::new() };
    drop(v1476_3);
    let v1476_5: Space = subtract(&(*CONSTANT_1),&(v1476_4));
    drop(v1476_4);
    let v1476_8: Space = if (v1476_5).is_empty() { Space::new() } else {
      let v1477_6: Path = concat_path(&(*p0),&(v1475_12_head));
      let mut v1477_7 = Space::new();
      let mut v1477_7_cursor = (v1475_12_tail).read_zipper();
      for v1477_7_byte in v1477_7_cursor.child_mask().iter() {
        v1477_7_cursor.descend_to_byte(v1477_7_byte);
        let v1477_7_tail = v1477_7_cursor.make_map();
        v1477_7_cursor.ascend(1);
        let v1477_7_head = Path::from_slice(&[v1477_7_byte]);
        let v1478_2: Space = singleton(&(v1477_7_head));
        let v1478_3: Space = intersect(&(*CONSTANT_2),&(v1478_2));
        let v1478_4: Space = if has_head(&(v1478_3)) { singleton(&[]) } else { Space::new() };
        drop(v1478_3);
        let v1478_5: Space = subtract(&(*CONSTANT_1),&(v1478_4));
        drop(v1478_4);
        let v1478_8: Space = if (v1478_5).is_empty() { Space::new() } else {
          let v1479_6: Path = concat_path(&(v1477_6),&(v1477_7_head));
          let v1479_7: Space = routine_188(c, &(v1479_6), &(*p1), &(v1477_7_tail));
          compose(&(v1478_5),&(v1479_7))
        };
        drop(v1478_5);
        let v1478_9: Space = intersect(&(*CONSTANT_2),&(v1478_2));
        drop(v1478_2);
        let v1478_10: Space = if has_head(&(v1478_9)) { singleton(&[]) } else { Space::new() };
        drop(v1478_9);
        let v1478_12: Space = if (v1478_10).is_empty() { Space::new() } else {
          let v1480_6: Path = concat_path(&(v1477_6),&(v1477_7_head));
          let v1480_11: Space = routine_189(c, &(v1480_6), &(*p1), &(v1477_7_tail));
          drop(v1480_6);
          compose(&(v1478_10),&(v1480_11))
        };
        drop(v1478_10);
        let v1478_13: Space = unite(&(v1478_8),&(v1478_12));
        v1477_7.join_into((v1478_13).clone());
      }
      drop(v1477_7_cursor);
      compose(&(v1476_5),&(v1477_7))
    };
    drop(v1476_5);
    let v1476_9: Space = intersect(&(*CONSTANT_2),&(v1476_2));
    drop(v1476_2);
    let v1476_10: Space = if has_head(&(v1476_9)) { singleton(&[]) } else { Space::new() };
    drop(v1476_9);
    let v1476_12: Space = if (v1476_10).is_empty() { Space::new() } else {
      let v1481_6: Path = concat_path(&(*p0),&(v1475_12_head));
      let mut v1481_11 = Space::new();
      let mut v1481_11_cursor = (v1475_12_tail).read_zipper();
      for v1481_11_byte in v1481_11_cursor.child_mask().iter() {
        v1481_11_cursor.descend_to_byte(v1481_11_byte);
        let v1481_11_tail = v1481_11_cursor.make_map();
        v1481_11_cursor.ascend(1);
        let v1481_11_head = Path::from_slice(&[v1481_11_byte]);
        let v1482_2: Space = singleton(&(v1481_11_head));
        let v1482_3: Space = intersect(&(*CONSTANT_2),&(v1482_2));
        let v1482_4: Space = if has_head(&(v1482_3)) { singleton(&[]) } else { Space::new() };
        drop(v1482_3);
        let v1482_5: Space = subtract(&(*CONSTANT_1),&(v1482_4));
        drop(v1482_4);
        let v1482_8: Space = if (v1482_5).is_empty() { Space::new() } else {
          let v1483_6: Path = concat_path(&(v1481_6),&(v1481_11_head));
          let v1483_7: Space = routine_188(c, &(v1483_6), &(*p1), &(v1481_11_tail));
          compose(&(v1482_5),&(v1483_7))
        };
        drop(v1482_5);
        let v1482_9: Space = intersect(&(*CONSTANT_2),&(v1482_2));
        drop(v1482_2);
        let v1482_10: Space = if has_head(&(v1482_9)) { singleton(&[]) } else { Space::new() };
        drop(v1482_9);
        let v1482_12: Space = if (v1482_10).is_empty() { Space::new() } else {
          let v1484_6: Path = concat_path(&(v1481_6),&(v1481_11_head));
          let v1484_11: Space = routine_89(c, &(v1484_6), &(*p1), &(v1481_11_tail));
          drop(v1484_6);
          compose(&(v1482_10),&(v1484_11))
        };
        drop(v1482_10);
        let v1482_13: Space = unite(&(v1482_8),&(v1482_12));
        v1481_11.join_into((v1482_13).clone());
      }
      drop(v1481_11_cursor);
      drop(v1481_6);
      compose(&(v1476_10),&(v1481_11))
    };
    drop(v1476_10);
    let v1476_13: Space = unite(&(v1476_8),&(v1476_12));
    v1475_12.join_into((v1476_13).clone());
  }
  drop(v1475_12_cursor);
  (v1475_12).clone()
}

fn routine_165(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1485_9 = Space::new();
  let mut v1485_9_cursor = (*s0).read_zipper();
  for v1485_9_byte in v1485_9_cursor.child_mask().iter() {
    v1485_9_cursor.descend_to_byte(v1485_9_byte);
    let v1485_9_tail = v1485_9_cursor.make_map();
    v1485_9_cursor.ascend(1);
    let v1485_9_head = Path::from_slice(&[v1485_9_byte]);
    let v1486_2: Space = singleton(&(v1485_9_head));
    let v1486_3: Space = intersect(&(*CONSTANT_2),&(v1486_2));
    let v1486_4: Space = if has_head(&(v1486_3)) { singleton(&[]) } else { Space::new() };
    drop(v1486_3);
    let v1486_5: Space = subtract(&(*CONSTANT_1),&(v1486_4));
    drop(v1486_4);
    let v1486_8: Space = if (v1486_5).is_empty() { Space::new() } else {
      let v1487_6: Path = concat_path(&(*p0),&(v1485_9_head));
      let mut v1487_7 = Space::new();
      let mut v1487_7_cursor = (v1485_9_tail).read_zipper();
      for v1487_7_byte in v1487_7_cursor.child_mask().iter() {
        v1487_7_cursor.descend_to_byte(v1487_7_byte);
        let v1487_7_tail = v1487_7_cursor.make_map();
        v1487_7_cursor.ascend(1);
        let v1487_7_head = Path::from_slice(&[v1487_7_byte]);
        let v1488_2: Space = singleton(&(v1487_7_head));
        let v1488_3: Space = intersect(&(*CONSTANT_2),&(v1488_2));
        let v1488_4: Space = if has_head(&(v1488_3)) { singleton(&[]) } else { Space::new() };
        drop(v1488_3);
        let v1488_5: Space = subtract(&(*CONSTANT_1),&(v1488_4));
        drop(v1488_4);
        let v1488_8: Space = if (v1488_5).is_empty() { Space::new() } else {
          let v1489_6: Path = concat_path(&(v1487_6),&(v1487_7_head));
          let v1489_7: Space = routine_188(c, &(v1489_6), &(*p1), &(v1487_7_tail));
          compose(&(v1488_5),&(v1489_7))
        };
        drop(v1488_5);
        let v1488_9: Space = intersect(&(*CONSTANT_2),&(v1488_2));
        drop(v1488_2);
        let v1488_10: Space = if has_head(&(v1488_9)) { singleton(&[]) } else { Space::new() };
        drop(v1488_9);
        let v1488_12: Space = if (v1488_10).is_empty() { Space::new() } else {
          let v1490_6: Path = concat_path(&(v1487_6),&(v1487_7_head));
          let v1490_11: Space = routine_189(c, &(v1490_6), &(*p1), &(v1487_7_tail));
          drop(v1490_6);
          compose(&(v1488_10),&(v1490_11))
        };
        drop(v1488_10);
        let v1488_13: Space = unite(&(v1488_8),&(v1488_12));
        v1487_7.join_into((v1488_13).clone());
      }
      drop(v1487_7_cursor);
      compose(&(v1486_5),&(v1487_7))
    };
    drop(v1486_5);
    let v1486_9: Space = intersect(&(*CONSTANT_2),&(v1486_2));
    drop(v1486_2);
    let v1486_10: Space = if has_head(&(v1486_9)) { singleton(&[]) } else { Space::new() };
    drop(v1486_9);
    let v1486_11: Space = compose(&(v1486_10),&(v1485_9_tail));
    drop(v1486_10);
    let v1491_6: Path = concat_path(&(*p0),&(v1485_9_head));
    let v1486_12: Space = wrap(&(v1486_11),&(v1491_6));
    drop(v1486_11);
    let v1486_13: Space = wrap(&(v1486_12),&(*p1));
    drop(v1486_12);
    let v1486_14: Space = unite(&(v1486_8),&(v1486_13));
    drop(v1486_13);
    v1485_9.join_into((v1486_14).clone());
  }
  drop(v1485_9_cursor);
  (v1485_9).clone()
}

fn routine_166(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1492_12 = Space::new();
  let mut v1492_12_cursor = (*s0).read_zipper();
  for v1492_12_byte in v1492_12_cursor.child_mask().iter() {
    v1492_12_cursor.descend_to_byte(v1492_12_byte);
    let v1492_12_tail = v1492_12_cursor.make_map();
    v1492_12_cursor.ascend(1);
    let v1492_12_head = Path::from_slice(&[v1492_12_byte]);
    let v1493_2: Space = singleton(&(v1492_12_head));
    let v1493_3: Space = intersect(&(*CONSTANT_2),&(v1493_2));
    let v1493_4: Space = if has_head(&(v1493_3)) { singleton(&[]) } else { Space::new() };
    drop(v1493_3);
    let v1493_5: Space = subtract(&(*CONSTANT_1),&(v1493_4));
    drop(v1493_4);
    let v1493_8: Space = if (v1493_5).is_empty() { Space::new() } else {
      let v1494_6: Path = concat_path(&(*p0),&(v1492_12_head));
      let mut v1494_7 = Space::new();
      let mut v1494_7_cursor = (v1492_12_tail).read_zipper();
      for v1494_7_byte in v1494_7_cursor.child_mask().iter() {
        v1494_7_cursor.descend_to_byte(v1494_7_byte);
        let v1494_7_tail = v1494_7_cursor.make_map();
        v1494_7_cursor.ascend(1);
        let v1494_7_head = Path::from_slice(&[v1494_7_byte]);
        let v1495_2: Space = singleton(&(v1494_7_head));
        let v1495_3: Space = intersect(&(*CONSTANT_2),&(v1495_2));
        let v1495_4: Space = if has_head(&(v1495_3)) { singleton(&[]) } else { Space::new() };
        drop(v1495_3);
        let v1495_5: Space = subtract(&(*CONSTANT_1),&(v1495_4));
        drop(v1495_4);
        let v1495_8: Space = if (v1495_5).is_empty() { Space::new() } else {
          let v1496_6: Path = concat_path(&(v1494_6),&(v1494_7_head));
          let v1496_7: Space = routine_190(c, &(v1496_6), &(*p1), &(v1494_7_tail));
          compose(&(v1495_5),&(v1496_7))
        };
        drop(v1495_5);
        let v1495_9: Space = intersect(&(*CONSTANT_2),&(v1495_2));
        drop(v1495_2);
        let v1495_10: Space = if has_head(&(v1495_9)) { singleton(&[]) } else { Space::new() };
        drop(v1495_9);
        let v1495_12: Space = if (v1495_10).is_empty() { Space::new() } else {
          let v1497_6: Path = concat_path(&(v1494_6),&(v1494_7_head));
          let v1497_11: Space = routine_191(c, &(v1497_6), &(*p1), &(v1494_7_tail));
          drop(v1497_6);
          compose(&(v1495_10),&(v1497_11))
        };
        drop(v1495_10);
        let v1495_13: Space = unite(&(v1495_8),&(v1495_12));
        v1494_7.join_into((v1495_13).clone());
      }
      drop(v1494_7_cursor);
      compose(&(v1493_5),&(v1494_7))
    };
    drop(v1493_5);
    let v1493_9: Space = intersect(&(*CONSTANT_2),&(v1493_2));
    drop(v1493_2);
    let v1493_10: Space = if has_head(&(v1493_9)) { singleton(&[]) } else { Space::new() };
    drop(v1493_9);
    let v1493_12: Space = if (v1493_10).is_empty() { Space::new() } else {
      let v1498_6: Path = concat_path(&(*p0),&(v1492_12_head));
      let mut v1498_11 = Space::new();
      let mut v1498_11_cursor = (v1492_12_tail).read_zipper();
      for v1498_11_byte in v1498_11_cursor.child_mask().iter() {
        v1498_11_cursor.descend_to_byte(v1498_11_byte);
        let v1498_11_tail = v1498_11_cursor.make_map();
        v1498_11_cursor.ascend(1);
        let v1498_11_head = Path::from_slice(&[v1498_11_byte]);
        let v1499_2: Space = singleton(&(v1498_11_head));
        let v1499_3: Space = intersect(&(*CONSTANT_2),&(v1499_2));
        let v1499_4: Space = if has_head(&(v1499_3)) { singleton(&[]) } else { Space::new() };
        drop(v1499_3);
        let v1499_5: Space = subtract(&(*CONSTANT_1),&(v1499_4));
        drop(v1499_4);
        let v1499_8: Space = if (v1499_5).is_empty() { Space::new() } else {
          let v1500_6: Path = concat_path(&(v1498_6),&(v1498_11_head));
          let v1500_7: Space = routine_190(c, &(v1500_6), &(*p1), &(v1498_11_tail));
          compose(&(v1499_5),&(v1500_7))
        };
        drop(v1499_5);
        let v1499_9: Space = intersect(&(*CONSTANT_2),&(v1499_2));
        drop(v1499_2);
        let v1499_10: Space = if has_head(&(v1499_9)) { singleton(&[]) } else { Space::new() };
        drop(v1499_9);
        let v1499_12: Space = if (v1499_10).is_empty() { Space::new() } else {
          let v1501_6: Path = concat_path(&(v1498_6),&(v1498_11_head));
          let v1501_11: Space = routine_50(c, &(v1501_6), &(*p1), &(v1498_11_tail));
          drop(v1501_6);
          compose(&(v1499_10),&(v1501_11))
        };
        drop(v1499_10);
        let v1499_13: Space = unite(&(v1499_8),&(v1499_12));
        v1498_11.join_into((v1499_13).clone());
      }
      drop(v1498_11_cursor);
      drop(v1498_6);
      compose(&(v1493_10),&(v1498_11))
    };
    drop(v1493_10);
    let v1493_13: Space = unite(&(v1493_8),&(v1493_12));
    v1492_12.join_into((v1493_13).clone());
  }
  drop(v1492_12_cursor);
  (v1492_12).clone()
}

fn routine_167(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1502_9 = Space::new();
  let mut v1502_9_cursor = (*s0).read_zipper();
  for v1502_9_byte in v1502_9_cursor.child_mask().iter() {
    v1502_9_cursor.descend_to_byte(v1502_9_byte);
    let v1502_9_tail = v1502_9_cursor.make_map();
    v1502_9_cursor.ascend(1);
    let v1502_9_head = Path::from_slice(&[v1502_9_byte]);
    let v1503_2: Space = singleton(&(v1502_9_head));
    let v1503_3: Space = intersect(&(*CONSTANT_2),&(v1503_2));
    let v1503_4: Space = if has_head(&(v1503_3)) { singleton(&[]) } else { Space::new() };
    drop(v1503_3);
    let v1503_5: Space = subtract(&(*CONSTANT_1),&(v1503_4));
    drop(v1503_4);
    let v1503_8: Space = if (v1503_5).is_empty() { Space::new() } else {
      let v1504_6: Path = concat_path(&(*p0),&(v1502_9_head));
      let mut v1504_7 = Space::new();
      let mut v1504_7_cursor = (v1502_9_tail).read_zipper();
      for v1504_7_byte in v1504_7_cursor.child_mask().iter() {
        v1504_7_cursor.descend_to_byte(v1504_7_byte);
        let v1504_7_tail = v1504_7_cursor.make_map();
        v1504_7_cursor.ascend(1);
        let v1504_7_head = Path::from_slice(&[v1504_7_byte]);
        let v1505_2: Space = singleton(&(v1504_7_head));
        let v1505_3: Space = intersect(&(*CONSTANT_2),&(v1505_2));
        let v1505_4: Space = if has_head(&(v1505_3)) { singleton(&[]) } else { Space::new() };
        drop(v1505_3);
        let v1505_5: Space = subtract(&(*CONSTANT_1),&(v1505_4));
        drop(v1505_4);
        let v1505_8: Space = if (v1505_5).is_empty() { Space::new() } else {
          let v1506_6: Path = concat_path(&(v1504_6),&(v1504_7_head));
          let v1506_7: Space = routine_190(c, &(v1506_6), &(*p1), &(v1504_7_tail));
          compose(&(v1505_5),&(v1506_7))
        };
        drop(v1505_5);
        let v1505_9: Space = intersect(&(*CONSTANT_2),&(v1505_2));
        drop(v1505_2);
        let v1505_10: Space = if has_head(&(v1505_9)) { singleton(&[]) } else { Space::new() };
        drop(v1505_9);
        let v1505_12: Space = if (v1505_10).is_empty() { Space::new() } else {
          let v1507_6: Path = concat_path(&(v1504_6),&(v1504_7_head));
          let v1507_11: Space = routine_191(c, &(v1507_6), &(*p1), &(v1504_7_tail));
          drop(v1507_6);
          compose(&(v1505_10),&(v1507_11))
        };
        drop(v1505_10);
        let v1505_13: Space = unite(&(v1505_8),&(v1505_12));
        v1504_7.join_into((v1505_13).clone());
      }
      drop(v1504_7_cursor);
      compose(&(v1503_5),&(v1504_7))
    };
    drop(v1503_5);
    let v1503_9: Space = intersect(&(*CONSTANT_2),&(v1503_2));
    drop(v1503_2);
    let v1503_10: Space = if has_head(&(v1503_9)) { singleton(&[]) } else { Space::new() };
    drop(v1503_9);
    let v1503_11: Space = compose(&(v1503_10),&(v1502_9_tail));
    drop(v1503_10);
    let v1508_6: Path = concat_path(&(*p0),&(v1502_9_head));
    let v1503_12: Space = wrap(&(v1503_11),&(v1508_6));
    drop(v1503_11);
    let v1503_13: Space = wrap(&(v1503_12),&(*p1));
    drop(v1503_12);
    let v1503_14: Space = unite(&(v1503_8),&(v1503_13));
    drop(v1503_13);
    v1502_9.join_into((v1503_14).clone());
  }
  drop(v1502_9_cursor);
  (v1502_9).clone()
}

fn routine_168(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1509_7 = Space::new();
  let mut v1509_7_cursor = (*s0).read_zipper();
  for v1509_7_byte in v1509_7_cursor.child_mask().iter() {
    v1509_7_cursor.descend_to_byte(v1509_7_byte);
    let v1509_7_tail = v1509_7_cursor.make_map();
    v1509_7_cursor.ascend(1);
    let v1509_7_head = Path::from_slice(&[v1509_7_byte]);
    let v1510_2: Space = singleton(&(v1509_7_head));
    let v1510_3: Space = intersect(&(*CONSTANT_2),&(v1510_2));
    let v1510_4: Space = if has_head(&(v1510_3)) { singleton(&[]) } else { Space::new() };
    drop(v1510_3);
    let v1510_5: Space = subtract(&(*CONSTANT_1),&(v1510_4));
    drop(v1510_4);
    let mut v1510_6 = Space::new();
    let mut v1510_6_cursor = (v1509_7_tail).read_zipper();
    for v1510_6_byte in v1510_6_cursor.child_mask().iter() {
      v1510_6_cursor.descend_to_byte(v1510_6_byte);
      let v1510_6_tail = v1510_6_cursor.make_map();
      v1510_6_cursor.ascend(1);
      let v1510_6_head = Path::from_slice(&[v1510_6_byte]);
      let v1511_2: Space = Space::new();
      v1510_6.join_into((v1511_2).clone());
    }
    drop(v1510_6_cursor);
    let v1510_7: Space = compose(&(v1510_5),&(v1510_6));
    drop(v1510_5);
    drop(v1510_6);
    let v1510_8: Space = intersect(&(*CONSTANT_2),&(v1510_2));
    drop(v1510_2);
    let v1510_9: Space = if has_head(&(v1510_8)) { singleton(&[]) } else { Space::new() };
    drop(v1510_8);
    let v1510_12: Space = if (v1510_9).is_empty() { Space::new() } else {
      let v1512_10: Path = concat_path(&(*p0),&(v1509_7_head));
      let mut v1512_11 = Space::new();
      let mut v1512_11_cursor = (v1509_7_tail).read_zipper();
      for v1512_11_byte in v1512_11_cursor.child_mask().iter() {
        v1512_11_cursor.descend_to_byte(v1512_11_byte);
        let v1512_11_tail = v1512_11_cursor.make_map();
        v1512_11_cursor.ascend(1);
        let v1512_11_head = Path::from_slice(&[v1512_11_byte]);
        let v1513_2: Space = singleton(&(v1512_11_head));
        let v1513_3: Space = intersect(&(*CONSTANT_2),&(v1513_2));
        drop(v1513_2);
        let v1513_4: Space = if has_head(&(v1513_3)) { singleton(&[]) } else { Space::new() };
        drop(v1513_3);
        let v1513_7: Space = if (v1513_4).is_empty() { Space::new() } else {
          let v1514_5: Path = concat_path(&(v1512_10),&(v1512_11_head));
          let v1514_6: Space = routine_50(c, &(v1514_5), &(*p1), &(v1512_11_tail));
          drop(v1514_5);
          compose(&(v1513_4),&(v1514_6))
        };
        drop(v1513_4);
        v1512_11.join_into((v1513_7).clone());
      }
      drop(v1512_11_cursor);
      drop(v1512_10);
      compose(&(v1510_9),&(v1512_11))
    };
    drop(v1510_9);
    let v1510_13: Space = unite(&(v1510_7),&(v1510_12));
    drop(v1510_7);
    v1509_7.join_into((v1510_13).clone());
  }
  drop(v1509_7_cursor);
  (v1509_7).clone()
}

fn routine_169(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1515_6 = Space::new();
  let mut v1515_6_cursor = (*s0).read_zipper();
  for v1515_6_byte in v1515_6_cursor.child_mask().iter() {
    v1515_6_cursor.descend_to_byte(v1515_6_byte);
    let v1515_6_tail = v1515_6_cursor.make_map();
    v1515_6_cursor.ascend(1);
    let v1515_6_head = Path::from_slice(&[v1515_6_byte]);
    let v1516_2: Space = singleton(&(v1515_6_head));
    let v1516_3: Space = intersect(&(*CONSTANT_2),&(v1516_2));
    let v1516_4: Space = if has_head(&(v1516_3)) { singleton(&[]) } else { Space::new() };
    drop(v1516_3);
    let v1516_5: Space = subtract(&(*CONSTANT_1),&(v1516_4));
    drop(v1516_4);
    let mut v1516_6 = Space::new();
    let mut v1516_6_cursor = (v1515_6_tail).read_zipper();
    for v1516_6_byte in v1516_6_cursor.child_mask().iter() {
      v1516_6_cursor.descend_to_byte(v1516_6_byte);
      let v1516_6_tail = v1516_6_cursor.make_map();
      v1516_6_cursor.ascend(1);
      let v1516_6_head = Path::from_slice(&[v1516_6_byte]);
      let v1517_2: Space = Space::new();
      v1516_6.join_into((v1517_2).clone());
    }
    drop(v1516_6_cursor);
    let v1516_7: Space = compose(&(v1516_5),&(v1516_6));
    drop(v1516_5);
    drop(v1516_6);
    let v1516_8: Space = intersect(&(*CONSTANT_2),&(v1516_2));
    drop(v1516_2);
    let v1516_9: Space = if has_head(&(v1516_8)) { singleton(&[]) } else { Space::new() };
    drop(v1516_8);
    let v1516_10: Space = compose(&(v1516_9),&(v1515_6_tail));
    drop(v1516_9);
    let v1516_11: Path = concat_path(&(*p0),&(v1515_6_head));
    let v1516_12: Space = wrap(&(v1516_10),&(v1516_11));
    drop(v1516_10);
    drop(v1516_11);
    let v1516_13: Space = wrap(&(v1516_12),&(*p1));
    drop(v1516_12);
    let v1516_14: Space = unite(&(v1516_7),&(v1516_13));
    drop(v1516_7);
    drop(v1516_13);
    v1515_6.join_into((v1516_14).clone());
  }
  drop(v1515_6_cursor);
  (v1515_6).clone()
}

fn routine_170(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1518_3 = Space::new();
  let mut v1518_3_cursor = (*s0).read_zipper();
  for v1518_3_byte in v1518_3_cursor.child_mask().iter() {
    v1518_3_cursor.descend_to_byte(v1518_3_byte);
    let v1518_3_tail = v1518_3_cursor.make_map();
    v1518_3_cursor.ascend(1);
    let v1518_3_head = Path::from_slice(&[v1518_3_byte]);
    let v1519_2: Space = Space::new();
    v1518_3.join_into((v1519_2).clone());
  }
  drop(v1518_3_cursor);
  (v1518_3).clone()
}

fn routine_171(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1520_4 = Space::new();
  let mut v1520_4_cursor = (*s0).read_zipper();
  for v1520_4_byte in v1520_4_cursor.child_mask().iter() {
    v1520_4_cursor.descend_to_byte(v1520_4_byte);
    let v1520_4_tail = v1520_4_cursor.make_map();
    v1520_4_cursor.ascend(1);
    let v1520_4_head = Path::from_slice(&[v1520_4_byte]);
    let v1521_2: Space = singleton(&(v1520_4_head));
    let v1521_3: Space = intersect(&(*CONSTANT_2),&(v1521_2));
    drop(v1521_2);
    let v1521_4: Space = if has_head(&(v1521_3)) { singleton(&[]) } else { Space::new() };
    drop(v1521_3);
    let v1521_5: Space = compose(&(v1521_4),&(v1520_4_tail));
    drop(v1521_4);
    let v1521_6: Path = concat_path(&(*p0),&(v1520_4_head));
    let v1521_7: Space = wrap(&(v1521_5),&(v1521_6));
    drop(v1521_5);
    drop(v1521_6);
    v1520_4.join_into((v1521_7).clone());
  }
  drop(v1520_4_cursor);
  let v1520_5: Space = wrap(&(v1520_4),&(*p1));
  drop(v1520_4);
  let v1520_7: Space = wrap(&(v1520_5),&(*CONSTANT_5));
  drop(v1520_5);
  (v1520_7).clone()
}

fn routine_172(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1522_4 = Space::new();
  let mut v1522_4_cursor = (*s0).read_zipper();
  for v1522_4_byte in v1522_4_cursor.child_mask().iter() {
    v1522_4_cursor.descend_to_byte(v1522_4_byte);
    let v1522_4_tail = v1522_4_cursor.make_map();
    v1522_4_cursor.ascend(1);
    let v1522_4_head = Path::from_slice(&[v1522_4_byte]);
    let v1523_2: Space = Space::new();
    v1522_4.join_into((v1523_2).clone());
  }
  drop(v1522_4_cursor);
  (v1522_4).clone()
}

fn routine_173(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1524_6: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v1524_8: Space = unwrap(&(v1524_6),&(*CONSTANT_5));
  drop(v1524_6);
  let v1524_9: Space = unwrap(&(v1524_8),&(*p0));
  drop(v1524_8);
  let mut v1524_13 = Space::new();
  let mut v1524_13_cursor = (*s0).read_zipper();
  for v1524_13_byte in v1524_13_cursor.child_mask().iter() {
    v1524_13_cursor.descend_to_byte(v1524_13_byte);
    let v1524_13_tail = v1524_13_cursor.make_map();
    v1524_13_cursor.ascend(1);
    let v1524_13_head = Path::from_slice(&[v1524_13_byte]);
    let v1525_2: Space = singleton(&(v1524_13_head));
    let v1525_3: Space = intersect(&(*CONSTANT_2),&(v1525_2));
    drop(v1525_2);
    let v1525_4: Space = if has_head(&(v1525_3)) { singleton(&[]) } else { Space::new() };
    drop(v1525_3);
    let v1525_7: Space = if (v1525_4).is_empty() { Space::new() } else {
      let v1526_5: Space = unwrap(&(v1524_9),&(v1524_13_head));
      let mut v1526_6 = Space::new();
      let mut v1526_6_cursor = (v1526_5).read_zipper();
      for v1526_6_byte in v1526_6_cursor.child_mask().iter() {
        v1526_6_cursor.descend_to_byte(v1526_6_byte);
        let v1526_6_tail = v1526_6_cursor.make_map();
        v1526_6_cursor.ascend(1);
        let v1526_6_head = Path::from_slice(&[v1526_6_byte]);
        let v1527_2: Space = singleton(&(v1526_6_head));
        let v1527_3: Space = intersect(&(*CONSTANT_2),&(v1527_2));
        let v1527_4: Space = if has_head(&(v1527_3)) { singleton(&[]) } else { Space::new() };
        drop(v1527_3);
        let v1527_5: Space = subtract(&(*CONSTANT_1),&(v1527_4));
        drop(v1527_4);
        let v1527_7: Space = if (v1527_5).is_empty() { Space::new() } else {
          let v1528_6: Space = routine_61(c, &(v1526_6_head), &(*p1), &(v1526_6_tail));
          compose(&(v1527_5),&(v1528_6))
        };
        drop(v1527_5);
        let v1527_8: Space = intersect(&(*CONSTANT_2),&(v1527_2));
        drop(v1527_2);
        let v1527_9: Space = if has_head(&(v1527_8)) { singleton(&[]) } else { Space::new() };
        drop(v1527_8);
        let v1527_11: Space = if (v1527_9).is_empty() { Space::new() } else {
          let v1529_10: Space = routine_62(c, &(v1526_6_head), &(*p1), &(v1526_6_tail));
          compose(&(v1527_9),&(v1529_10))
        };
        drop(v1527_9);
        let v1527_12: Space = unite(&(v1527_7),&(v1527_11));
        v1526_6.join_into((v1527_12).clone());
      }
      drop(v1526_6_cursor);
      drop(v1526_5);
      compose(&(v1525_4),&(v1526_6))
    };
    drop(v1525_4);
    v1524_13.join_into((v1525_7).clone());
  }
  drop(v1524_13_cursor);
  drop(v1524_9);
  (v1524_13).clone()
}

fn routine_174(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1530_12 = Space::new();
  let mut v1530_12_cursor = (*s0).read_zipper();
  for v1530_12_byte in v1530_12_cursor.child_mask().iter() {
    v1530_12_cursor.descend_to_byte(v1530_12_byte);
    let v1530_12_tail = v1530_12_cursor.make_map();
    v1530_12_cursor.ascend(1);
    let v1530_12_head = Path::from_slice(&[v1530_12_byte]);
    let v1531_2: Space = singleton(&(v1530_12_head));
    let v1531_3: Space = intersect(&(*CONSTANT_2),&(v1531_2));
    let v1531_4: Space = if has_head(&(v1531_3)) { singleton(&[]) } else { Space::new() };
    drop(v1531_3);
    let v1531_5: Space = subtract(&(*CONSTANT_1),&(v1531_4));
    drop(v1531_4);
    let v1531_8: Space = if (v1531_5).is_empty() { Space::new() } else {
      let v1532_6: Path = concat_path(&(*p0),&(v1530_12_head));
      let mut v1532_7 = Space::new();
      let mut v1532_7_cursor = (v1530_12_tail).read_zipper();
      for v1532_7_byte in v1532_7_cursor.child_mask().iter() {
        v1532_7_cursor.descend_to_byte(v1532_7_byte);
        let v1532_7_tail = v1532_7_cursor.make_map();
        v1532_7_cursor.ascend(1);
        let v1532_7_head = Path::from_slice(&[v1532_7_byte]);
        let v1533_2: Space = singleton(&(v1532_7_head));
        let v1533_3: Space = intersect(&(*CONSTANT_2),&(v1533_2));
        let v1533_4: Space = if has_head(&(v1533_3)) { singleton(&[]) } else { Space::new() };
        drop(v1533_3);
        let v1533_5: Space = subtract(&(*CONSTANT_1),&(v1533_4));
        drop(v1533_4);
        let v1533_8: Space = if (v1533_5).is_empty() { Space::new() } else {
          let v1534_6: Path = concat_path(&(v1532_6),&(v1532_7_head));
          let v1534_7: Space = routine_192(c, &(v1534_6), &(*p1), &(v1532_7_tail));
          compose(&(v1533_5),&(v1534_7))
        };
        drop(v1533_5);
        let v1533_9: Space = intersect(&(*CONSTANT_2),&(v1533_2));
        drop(v1533_2);
        let v1533_10: Space = if has_head(&(v1533_9)) { singleton(&[]) } else { Space::new() };
        drop(v1533_9);
        let v1533_12: Space = if (v1533_10).is_empty() { Space::new() } else {
          let v1535_6: Path = concat_path(&(v1532_6),&(v1532_7_head));
          let v1535_11: Space = routine_193(c, &(v1535_6), &(*p1), &(v1532_7_tail));
          drop(v1535_6);
          compose(&(v1533_10),&(v1535_11))
        };
        drop(v1533_10);
        let v1533_13: Space = unite(&(v1533_8),&(v1533_12));
        v1532_7.join_into((v1533_13).clone());
      }
      drop(v1532_7_cursor);
      compose(&(v1531_5),&(v1532_7))
    };
    drop(v1531_5);
    let v1531_9: Space = intersect(&(*CONSTANT_2),&(v1531_2));
    drop(v1531_2);
    let v1531_10: Space = if has_head(&(v1531_9)) { singleton(&[]) } else { Space::new() };
    drop(v1531_9);
    let v1531_12: Space = if (v1531_10).is_empty() { Space::new() } else {
      let v1536_6: Path = concat_path(&(*p0),&(v1530_12_head));
      let mut v1536_11 = Space::new();
      let mut v1536_11_cursor = (v1530_12_tail).read_zipper();
      for v1536_11_byte in v1536_11_cursor.child_mask().iter() {
        v1536_11_cursor.descend_to_byte(v1536_11_byte);
        let v1536_11_tail = v1536_11_cursor.make_map();
        v1536_11_cursor.ascend(1);
        let v1536_11_head = Path::from_slice(&[v1536_11_byte]);
        let v1537_2: Space = singleton(&(v1536_11_head));
        let v1537_3: Space = intersect(&(*CONSTANT_2),&(v1537_2));
        let v1537_4: Space = if has_head(&(v1537_3)) { singleton(&[]) } else { Space::new() };
        drop(v1537_3);
        let v1537_5: Space = subtract(&(*CONSTANT_1),&(v1537_4));
        drop(v1537_4);
        let v1537_8: Space = if (v1537_5).is_empty() { Space::new() } else {
          let v1538_6: Path = concat_path(&(v1536_6),&(v1536_11_head));
          let v1538_7: Space = routine_192(c, &(v1538_6), &(*p1), &(v1536_11_tail));
          compose(&(v1537_5),&(v1538_7))
        };
        drop(v1537_5);
        let v1537_9: Space = intersect(&(*CONSTANT_2),&(v1537_2));
        drop(v1537_2);
        let v1537_10: Space = if has_head(&(v1537_9)) { singleton(&[]) } else { Space::new() };
        drop(v1537_9);
        let v1537_12: Space = if (v1537_10).is_empty() { Space::new() } else {
          let v1539_6: Path = concat_path(&(v1536_6),&(v1536_11_head));
          let v1539_11: Space = routine_67(c, &(v1539_6), &(*p1), &(v1536_11_tail));
          drop(v1539_6);
          compose(&(v1537_10),&(v1539_11))
        };
        drop(v1537_10);
        let v1537_13: Space = unite(&(v1537_8),&(v1537_12));
        v1536_11.join_into((v1537_13).clone());
      }
      drop(v1536_11_cursor);
      drop(v1536_6);
      compose(&(v1531_10),&(v1536_11))
    };
    drop(v1531_10);
    let v1531_13: Space = unite(&(v1531_8),&(v1531_12));
    v1530_12.join_into((v1531_13).clone());
  }
  drop(v1530_12_cursor);
  (v1530_12).clone()
}

fn routine_175(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1540_9 = Space::new();
  let mut v1540_9_cursor = (*s0).read_zipper();
  for v1540_9_byte in v1540_9_cursor.child_mask().iter() {
    v1540_9_cursor.descend_to_byte(v1540_9_byte);
    let v1540_9_tail = v1540_9_cursor.make_map();
    v1540_9_cursor.ascend(1);
    let v1540_9_head = Path::from_slice(&[v1540_9_byte]);
    let v1541_2: Space = singleton(&(v1540_9_head));
    let v1541_3: Space = intersect(&(*CONSTANT_2),&(v1541_2));
    let v1541_4: Space = if has_head(&(v1541_3)) { singleton(&[]) } else { Space::new() };
    drop(v1541_3);
    let v1541_5: Space = subtract(&(*CONSTANT_1),&(v1541_4));
    drop(v1541_4);
    let v1541_8: Space = if (v1541_5).is_empty() { Space::new() } else {
      let v1542_6: Path = concat_path(&(*p0),&(v1540_9_head));
      let mut v1542_7 = Space::new();
      let mut v1542_7_cursor = (v1540_9_tail).read_zipper();
      for v1542_7_byte in v1542_7_cursor.child_mask().iter() {
        v1542_7_cursor.descend_to_byte(v1542_7_byte);
        let v1542_7_tail = v1542_7_cursor.make_map();
        v1542_7_cursor.ascend(1);
        let v1542_7_head = Path::from_slice(&[v1542_7_byte]);
        let v1543_2: Space = singleton(&(v1542_7_head));
        let v1543_3: Space = intersect(&(*CONSTANT_2),&(v1543_2));
        let v1543_4: Space = if has_head(&(v1543_3)) { singleton(&[]) } else { Space::new() };
        drop(v1543_3);
        let v1543_5: Space = subtract(&(*CONSTANT_1),&(v1543_4));
        drop(v1543_4);
        let v1543_8: Space = if (v1543_5).is_empty() { Space::new() } else {
          let v1544_6: Path = concat_path(&(v1542_6),&(v1542_7_head));
          let v1544_7: Space = routine_192(c, &(v1544_6), &(*p1), &(v1542_7_tail));
          compose(&(v1543_5),&(v1544_7))
        };
        drop(v1543_5);
        let v1543_9: Space = intersect(&(*CONSTANT_2),&(v1543_2));
        drop(v1543_2);
        let v1543_10: Space = if has_head(&(v1543_9)) { singleton(&[]) } else { Space::new() };
        drop(v1543_9);
        let v1543_12: Space = if (v1543_10).is_empty() { Space::new() } else {
          let v1545_6: Path = concat_path(&(v1542_6),&(v1542_7_head));
          let v1545_11: Space = routine_193(c, &(v1545_6), &(*p1), &(v1542_7_tail));
          drop(v1545_6);
          compose(&(v1543_10),&(v1545_11))
        };
        drop(v1543_10);
        let v1543_13: Space = unite(&(v1543_8),&(v1543_12));
        v1542_7.join_into((v1543_13).clone());
      }
      drop(v1542_7_cursor);
      compose(&(v1541_5),&(v1542_7))
    };
    drop(v1541_5);
    let v1541_9: Space = intersect(&(*CONSTANT_2),&(v1541_2));
    drop(v1541_2);
    let v1541_10: Space = if has_head(&(v1541_9)) { singleton(&[]) } else { Space::new() };
    drop(v1541_9);
    let v1541_11: Space = compose(&(v1541_10),&(v1540_9_tail));
    drop(v1541_10);
    let v1546_6: Path = concat_path(&(*p0),&(v1540_9_head));
    let v1541_12: Space = wrap(&(v1541_11),&(v1546_6));
    drop(v1541_11);
    let v1541_13: Space = wrap(&(v1541_12),&(*p1));
    drop(v1541_12);
    let v1541_14: Space = unite(&(v1541_8),&(v1541_13));
    drop(v1541_13);
    v1540_9.join_into((v1541_14).clone());
  }
  drop(v1540_9_cursor);
  (v1540_9).clone()
}

fn routine_176(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1547_7 = Space::new();
  let mut v1547_7_cursor = (*s0).read_zipper();
  for v1547_7_byte in v1547_7_cursor.child_mask().iter() {
    v1547_7_cursor.descend_to_byte(v1547_7_byte);
    let v1547_7_tail = v1547_7_cursor.make_map();
    v1547_7_cursor.ascend(1);
    let v1547_7_head = Path::from_slice(&[v1547_7_byte]);
    let v1548_2: Space = singleton(&(v1547_7_head));
    let v1548_3: Space = intersect(&(*CONSTANT_2),&(v1548_2));
    let v1548_4: Space = if has_head(&(v1548_3)) { singleton(&[]) } else { Space::new() };
    drop(v1548_3);
    let v1548_5: Space = subtract(&(*CONSTANT_1),&(v1548_4));
    drop(v1548_4);
    let mut v1548_6 = Space::new();
    let mut v1548_6_cursor = (v1547_7_tail).read_zipper();
    for v1548_6_byte in v1548_6_cursor.child_mask().iter() {
      v1548_6_cursor.descend_to_byte(v1548_6_byte);
      let v1548_6_tail = v1548_6_cursor.make_map();
      v1548_6_cursor.ascend(1);
      let v1548_6_head = Path::from_slice(&[v1548_6_byte]);
      let v1549_2: Space = Space::new();
      v1548_6.join_into((v1549_2).clone());
    }
    drop(v1548_6_cursor);
    let v1548_7: Space = compose(&(v1548_5),&(v1548_6));
    drop(v1548_5);
    drop(v1548_6);
    let v1548_8: Space = intersect(&(*CONSTANT_2),&(v1548_2));
    drop(v1548_2);
    let v1548_9: Space = if has_head(&(v1548_8)) { singleton(&[]) } else { Space::new() };
    drop(v1548_8);
    let v1548_12: Space = if (v1548_9).is_empty() { Space::new() } else {
      let v1550_10: Path = concat_path(&(*p0),&(v1547_7_head));
      let mut v1550_11 = Space::new();
      let mut v1550_11_cursor = (v1547_7_tail).read_zipper();
      for v1550_11_byte in v1550_11_cursor.child_mask().iter() {
        v1550_11_cursor.descend_to_byte(v1550_11_byte);
        let v1550_11_tail = v1550_11_cursor.make_map();
        v1550_11_cursor.ascend(1);
        let v1550_11_head = Path::from_slice(&[v1550_11_byte]);
        let v1551_2: Space = singleton(&(v1550_11_head));
        let v1551_3: Space = intersect(&(*CONSTANT_2),&(v1551_2));
        drop(v1551_2);
        let v1551_4: Space = if has_head(&(v1551_3)) { singleton(&[]) } else { Space::new() };
        drop(v1551_3);
        let v1551_7: Space = if (v1551_4).is_empty() { Space::new() } else {
          let v1552_5: Path = concat_path(&(v1550_10),&(v1550_11_head));
          let v1552_6: Space = routine_67(c, &(v1552_5), &(*p1), &(v1550_11_tail));
          drop(v1552_5);
          compose(&(v1551_4),&(v1552_6))
        };
        drop(v1551_4);
        v1550_11.join_into((v1551_7).clone());
      }
      drop(v1550_11_cursor);
      drop(v1550_10);
      compose(&(v1548_9),&(v1550_11))
    };
    drop(v1548_9);
    let v1548_13: Space = unite(&(v1548_7),&(v1548_12));
    drop(v1548_7);
    v1547_7.join_into((v1548_13).clone());
  }
  drop(v1547_7_cursor);
  (v1547_7).clone()
}

fn routine_177(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1553_6 = Space::new();
  let mut v1553_6_cursor = (*s0).read_zipper();
  for v1553_6_byte in v1553_6_cursor.child_mask().iter() {
    v1553_6_cursor.descend_to_byte(v1553_6_byte);
    let v1553_6_tail = v1553_6_cursor.make_map();
    v1553_6_cursor.ascend(1);
    let v1553_6_head = Path::from_slice(&[v1553_6_byte]);
    let v1554_2: Space = singleton(&(v1553_6_head));
    let v1554_3: Space = intersect(&(*CONSTANT_2),&(v1554_2));
    let v1554_4: Space = if has_head(&(v1554_3)) { singleton(&[]) } else { Space::new() };
    drop(v1554_3);
    let v1554_5: Space = subtract(&(*CONSTANT_1),&(v1554_4));
    drop(v1554_4);
    let mut v1554_6 = Space::new();
    let mut v1554_6_cursor = (v1553_6_tail).read_zipper();
    for v1554_6_byte in v1554_6_cursor.child_mask().iter() {
      v1554_6_cursor.descend_to_byte(v1554_6_byte);
      let v1554_6_tail = v1554_6_cursor.make_map();
      v1554_6_cursor.ascend(1);
      let v1554_6_head = Path::from_slice(&[v1554_6_byte]);
      let v1555_2: Space = Space::new();
      v1554_6.join_into((v1555_2).clone());
    }
    drop(v1554_6_cursor);
    let v1554_7: Space = compose(&(v1554_5),&(v1554_6));
    drop(v1554_5);
    drop(v1554_6);
    let v1554_8: Space = intersect(&(*CONSTANT_2),&(v1554_2));
    drop(v1554_2);
    let v1554_9: Space = if has_head(&(v1554_8)) { singleton(&[]) } else { Space::new() };
    drop(v1554_8);
    let v1554_10: Space = compose(&(v1554_9),&(v1553_6_tail));
    drop(v1554_9);
    let v1554_11: Path = concat_path(&(*p0),&(v1553_6_head));
    let v1554_12: Space = wrap(&(v1554_10),&(v1554_11));
    drop(v1554_10);
    drop(v1554_11);
    let v1554_13: Space = wrap(&(v1554_12),&(*p1));
    drop(v1554_12);
    let v1554_14: Space = unite(&(v1554_7),&(v1554_13));
    drop(v1554_7);
    drop(v1554_13);
    v1553_6.join_into((v1554_14).clone());
  }
  drop(v1553_6_cursor);
  (v1553_6).clone()
}

fn routine_178(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1556_4 = Space::new();
  let mut v1556_4_cursor = (*s0).read_zipper();
  for v1556_4_byte in v1556_4_cursor.child_mask().iter() {
    v1556_4_cursor.descend_to_byte(v1556_4_byte);
    let v1556_4_tail = v1556_4_cursor.make_map();
    v1556_4_cursor.ascend(1);
    let v1556_4_head = Path::from_slice(&[v1556_4_byte]);
    let v1557_2: Space = Space::new();
    v1556_4.join_into((v1557_2).clone());
  }
  drop(v1556_4_cursor);
  (v1556_4).clone()
}

fn routine_179(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1558_6: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v1558_8: Space = unwrap(&(v1558_6),&(*CONSTANT_5));
  drop(v1558_6);
  let v1558_9: Space = unwrap(&(v1558_8),&(*p0));
  drop(v1558_8);
  let mut v1558_13 = Space::new();
  let mut v1558_13_cursor = (*s0).read_zipper();
  for v1558_13_byte in v1558_13_cursor.child_mask().iter() {
    v1558_13_cursor.descend_to_byte(v1558_13_byte);
    let v1558_13_tail = v1558_13_cursor.make_map();
    v1558_13_cursor.ascend(1);
    let v1558_13_head = Path::from_slice(&[v1558_13_byte]);
    let v1559_2: Space = singleton(&(v1558_13_head));
    let v1559_3: Space = intersect(&(*CONSTANT_2),&(v1559_2));
    drop(v1559_2);
    let v1559_4: Space = if has_head(&(v1559_3)) { singleton(&[]) } else { Space::new() };
    drop(v1559_3);
    let v1559_7: Space = if (v1559_4).is_empty() { Space::new() } else {
      let v1560_5: Space = unwrap(&(v1558_9),&(v1558_13_head));
      let mut v1560_6 = Space::new();
      let mut v1560_6_cursor = (v1560_5).read_zipper();
      for v1560_6_byte in v1560_6_cursor.child_mask().iter() {
        v1560_6_cursor.descend_to_byte(v1560_6_byte);
        let v1560_6_tail = v1560_6_cursor.make_map();
        v1560_6_cursor.ascend(1);
        let v1560_6_head = Path::from_slice(&[v1560_6_byte]);
        let v1561_2: Space = singleton(&(v1560_6_head));
        let v1561_3: Space = intersect(&(*CONSTANT_2),&(v1561_2));
        let v1561_4: Space = if has_head(&(v1561_3)) { singleton(&[]) } else { Space::new() };
        drop(v1561_3);
        let v1561_5: Space = subtract(&(*CONSTANT_1),&(v1561_4));
        drop(v1561_4);
        let v1561_7: Space = if (v1561_5).is_empty() { Space::new() } else {
          let v1562_6: Space = routine_72(c, &(v1560_6_head), &(*p1), &(v1560_6_tail));
          compose(&(v1561_5),&(v1562_6))
        };
        drop(v1561_5);
        let v1561_8: Space = intersect(&(*CONSTANT_2),&(v1561_2));
        drop(v1561_2);
        let v1561_9: Space = if has_head(&(v1561_8)) { singleton(&[]) } else { Space::new() };
        drop(v1561_8);
        let v1561_11: Space = if (v1561_9).is_empty() { Space::new() } else {
          let v1563_10: Space = routine_73(c, &(v1560_6_head), &(*p1), &(v1560_6_tail));
          compose(&(v1561_9),&(v1563_10))
        };
        drop(v1561_9);
        let v1561_12: Space = unite(&(v1561_7),&(v1561_11));
        v1560_6.join_into((v1561_12).clone());
      }
      drop(v1560_6_cursor);
      drop(v1560_5);
      compose(&(v1559_4),&(v1560_6))
    };
    drop(v1559_4);
    v1558_13.join_into((v1559_7).clone());
  }
  drop(v1558_13_cursor);
  drop(v1558_9);
  (v1558_13).clone()
}

fn routine_180(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1564_12 = Space::new();
  let mut v1564_12_cursor = (*s0).read_zipper();
  for v1564_12_byte in v1564_12_cursor.child_mask().iter() {
    v1564_12_cursor.descend_to_byte(v1564_12_byte);
    let v1564_12_tail = v1564_12_cursor.make_map();
    v1564_12_cursor.ascend(1);
    let v1564_12_head = Path::from_slice(&[v1564_12_byte]);
    let v1565_2: Space = singleton(&(v1564_12_head));
    let v1565_3: Space = intersect(&(*CONSTANT_2),&(v1565_2));
    let v1565_4: Space = if has_head(&(v1565_3)) { singleton(&[]) } else { Space::new() };
    drop(v1565_3);
    let v1565_5: Space = subtract(&(*CONSTANT_1),&(v1565_4));
    drop(v1565_4);
    let v1565_8: Space = if (v1565_5).is_empty() { Space::new() } else {
      let v1566_6: Path = concat_path(&(*p0),&(v1564_12_head));
      let mut v1566_7 = Space::new();
      let mut v1566_7_cursor = (v1564_12_tail).read_zipper();
      for v1566_7_byte in v1566_7_cursor.child_mask().iter() {
        v1566_7_cursor.descend_to_byte(v1566_7_byte);
        let v1566_7_tail = v1566_7_cursor.make_map();
        v1566_7_cursor.ascend(1);
        let v1566_7_head = Path::from_slice(&[v1566_7_byte]);
        let v1567_2: Space = singleton(&(v1566_7_head));
        let v1567_3: Space = intersect(&(*CONSTANT_2),&(v1567_2));
        let v1567_4: Space = if has_head(&(v1567_3)) { singleton(&[]) } else { Space::new() };
        drop(v1567_3);
        let v1567_5: Space = subtract(&(*CONSTANT_1),&(v1567_4));
        drop(v1567_4);
        let v1567_8: Space = if (v1567_5).is_empty() { Space::new() } else {
          let v1568_6: Path = concat_path(&(v1566_6),&(v1566_7_head));
          let v1568_7: Space = routine_194(c, &(v1568_6), &(*p1), &(v1566_7_tail));
          compose(&(v1567_5),&(v1568_7))
        };
        drop(v1567_5);
        let v1567_9: Space = intersect(&(*CONSTANT_2),&(v1567_2));
        drop(v1567_2);
        let v1567_10: Space = if has_head(&(v1567_9)) { singleton(&[]) } else { Space::new() };
        drop(v1567_9);
        let v1567_12: Space = if (v1567_10).is_empty() { Space::new() } else {
          let v1569_6: Path = concat_path(&(v1566_6),&(v1566_7_head));
          let v1569_11: Space = routine_195(c, &(v1569_6), &(*p1), &(v1566_7_tail));
          drop(v1569_6);
          compose(&(v1567_10),&(v1569_11))
        };
        drop(v1567_10);
        let v1567_13: Space = unite(&(v1567_8),&(v1567_12));
        v1566_7.join_into((v1567_13).clone());
      }
      drop(v1566_7_cursor);
      compose(&(v1565_5),&(v1566_7))
    };
    drop(v1565_5);
    let v1565_9: Space = intersect(&(*CONSTANT_2),&(v1565_2));
    drop(v1565_2);
    let v1565_10: Space = if has_head(&(v1565_9)) { singleton(&[]) } else { Space::new() };
    drop(v1565_9);
    let v1565_12: Space = if (v1565_10).is_empty() { Space::new() } else {
      let v1570_6: Path = concat_path(&(*p0),&(v1564_12_head));
      let mut v1570_11 = Space::new();
      let mut v1570_11_cursor = (v1564_12_tail).read_zipper();
      for v1570_11_byte in v1570_11_cursor.child_mask().iter() {
        v1570_11_cursor.descend_to_byte(v1570_11_byte);
        let v1570_11_tail = v1570_11_cursor.make_map();
        v1570_11_cursor.ascend(1);
        let v1570_11_head = Path::from_slice(&[v1570_11_byte]);
        let v1571_2: Space = singleton(&(v1570_11_head));
        let v1571_3: Space = intersect(&(*CONSTANT_2),&(v1571_2));
        let v1571_4: Space = if has_head(&(v1571_3)) { singleton(&[]) } else { Space::new() };
        drop(v1571_3);
        let v1571_5: Space = subtract(&(*CONSTANT_1),&(v1571_4));
        drop(v1571_4);
        let v1571_8: Space = if (v1571_5).is_empty() { Space::new() } else {
          let v1572_6: Path = concat_path(&(v1570_6),&(v1570_11_head));
          let v1572_7: Space = routine_194(c, &(v1572_6), &(*p1), &(v1570_11_tail));
          compose(&(v1571_5),&(v1572_7))
        };
        drop(v1571_5);
        let v1571_9: Space = intersect(&(*CONSTANT_2),&(v1571_2));
        drop(v1571_2);
        let v1571_10: Space = if has_head(&(v1571_9)) { singleton(&[]) } else { Space::new() };
        drop(v1571_9);
        let v1571_12: Space = if (v1571_10).is_empty() { Space::new() } else {
          let v1573_6: Path = concat_path(&(v1570_6),&(v1570_11_head));
          let v1573_11: Space = routine_78(c, &(v1573_6), &(*p1), &(v1570_11_tail));
          drop(v1573_6);
          compose(&(v1571_10),&(v1573_11))
        };
        drop(v1571_10);
        let v1571_13: Space = unite(&(v1571_8),&(v1571_12));
        v1570_11.join_into((v1571_13).clone());
      }
      drop(v1570_11_cursor);
      drop(v1570_6);
      compose(&(v1565_10),&(v1570_11))
    };
    drop(v1565_10);
    let v1565_13: Space = unite(&(v1565_8),&(v1565_12));
    v1564_12.join_into((v1565_13).clone());
  }
  drop(v1564_12_cursor);
  (v1564_12).clone()
}

fn routine_181(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1574_9 = Space::new();
  let mut v1574_9_cursor = (*s0).read_zipper();
  for v1574_9_byte in v1574_9_cursor.child_mask().iter() {
    v1574_9_cursor.descend_to_byte(v1574_9_byte);
    let v1574_9_tail = v1574_9_cursor.make_map();
    v1574_9_cursor.ascend(1);
    let v1574_9_head = Path::from_slice(&[v1574_9_byte]);
    let v1575_2: Space = singleton(&(v1574_9_head));
    let v1575_3: Space = intersect(&(*CONSTANT_2),&(v1575_2));
    let v1575_4: Space = if has_head(&(v1575_3)) { singleton(&[]) } else { Space::new() };
    drop(v1575_3);
    let v1575_5: Space = subtract(&(*CONSTANT_1),&(v1575_4));
    drop(v1575_4);
    let v1575_8: Space = if (v1575_5).is_empty() { Space::new() } else {
      let v1576_6: Path = concat_path(&(*p0),&(v1574_9_head));
      let mut v1576_7 = Space::new();
      let mut v1576_7_cursor = (v1574_9_tail).read_zipper();
      for v1576_7_byte in v1576_7_cursor.child_mask().iter() {
        v1576_7_cursor.descend_to_byte(v1576_7_byte);
        let v1576_7_tail = v1576_7_cursor.make_map();
        v1576_7_cursor.ascend(1);
        let v1576_7_head = Path::from_slice(&[v1576_7_byte]);
        let v1577_2: Space = singleton(&(v1576_7_head));
        let v1577_3: Space = intersect(&(*CONSTANT_2),&(v1577_2));
        let v1577_4: Space = if has_head(&(v1577_3)) { singleton(&[]) } else { Space::new() };
        drop(v1577_3);
        let v1577_5: Space = subtract(&(*CONSTANT_1),&(v1577_4));
        drop(v1577_4);
        let v1577_8: Space = if (v1577_5).is_empty() { Space::new() } else {
          let v1578_6: Path = concat_path(&(v1576_6),&(v1576_7_head));
          let v1578_7: Space = routine_194(c, &(v1578_6), &(*p1), &(v1576_7_tail));
          compose(&(v1577_5),&(v1578_7))
        };
        drop(v1577_5);
        let v1577_9: Space = intersect(&(*CONSTANT_2),&(v1577_2));
        drop(v1577_2);
        let v1577_10: Space = if has_head(&(v1577_9)) { singleton(&[]) } else { Space::new() };
        drop(v1577_9);
        let v1577_12: Space = if (v1577_10).is_empty() { Space::new() } else {
          let v1579_6: Path = concat_path(&(v1576_6),&(v1576_7_head));
          let v1579_11: Space = routine_195(c, &(v1579_6), &(*p1), &(v1576_7_tail));
          drop(v1579_6);
          compose(&(v1577_10),&(v1579_11))
        };
        drop(v1577_10);
        let v1577_13: Space = unite(&(v1577_8),&(v1577_12));
        v1576_7.join_into((v1577_13).clone());
      }
      drop(v1576_7_cursor);
      compose(&(v1575_5),&(v1576_7))
    };
    drop(v1575_5);
    let v1575_9: Space = intersect(&(*CONSTANT_2),&(v1575_2));
    drop(v1575_2);
    let v1575_10: Space = if has_head(&(v1575_9)) { singleton(&[]) } else { Space::new() };
    drop(v1575_9);
    let v1575_11: Space = compose(&(v1575_10),&(v1574_9_tail));
    drop(v1575_10);
    let v1580_6: Path = concat_path(&(*p0),&(v1574_9_head));
    let v1575_12: Space = wrap(&(v1575_11),&(v1580_6));
    drop(v1575_11);
    let v1575_13: Space = wrap(&(v1575_12),&(*p1));
    drop(v1575_12);
    let v1575_14: Space = unite(&(v1575_8),&(v1575_13));
    drop(v1575_13);
    v1574_9.join_into((v1575_14).clone());
  }
  drop(v1574_9_cursor);
  (v1574_9).clone()
}

fn routine_182(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1581_7 = Space::new();
  let mut v1581_7_cursor = (*s0).read_zipper();
  for v1581_7_byte in v1581_7_cursor.child_mask().iter() {
    v1581_7_cursor.descend_to_byte(v1581_7_byte);
    let v1581_7_tail = v1581_7_cursor.make_map();
    v1581_7_cursor.ascend(1);
    let v1581_7_head = Path::from_slice(&[v1581_7_byte]);
    let v1582_2: Space = singleton(&(v1581_7_head));
    let v1582_3: Space = intersect(&(*CONSTANT_2),&(v1582_2));
    let v1582_4: Space = if has_head(&(v1582_3)) { singleton(&[]) } else { Space::new() };
    drop(v1582_3);
    let v1582_5: Space = subtract(&(*CONSTANT_1),&(v1582_4));
    drop(v1582_4);
    let mut v1582_6 = Space::new();
    let mut v1582_6_cursor = (v1581_7_tail).read_zipper();
    for v1582_6_byte in v1582_6_cursor.child_mask().iter() {
      v1582_6_cursor.descend_to_byte(v1582_6_byte);
      let v1582_6_tail = v1582_6_cursor.make_map();
      v1582_6_cursor.ascend(1);
      let v1582_6_head = Path::from_slice(&[v1582_6_byte]);
      let v1583_2: Space = Space::new();
      v1582_6.join_into((v1583_2).clone());
    }
    drop(v1582_6_cursor);
    let v1582_7: Space = compose(&(v1582_5),&(v1582_6));
    drop(v1582_5);
    drop(v1582_6);
    let v1582_8: Space = intersect(&(*CONSTANT_2),&(v1582_2));
    drop(v1582_2);
    let v1582_9: Space = if has_head(&(v1582_8)) { singleton(&[]) } else { Space::new() };
    drop(v1582_8);
    let v1582_12: Space = if (v1582_9).is_empty() { Space::new() } else {
      let v1584_10: Path = concat_path(&(*p0),&(v1581_7_head));
      let mut v1584_11 = Space::new();
      let mut v1584_11_cursor = (v1581_7_tail).read_zipper();
      for v1584_11_byte in v1584_11_cursor.child_mask().iter() {
        v1584_11_cursor.descend_to_byte(v1584_11_byte);
        let v1584_11_tail = v1584_11_cursor.make_map();
        v1584_11_cursor.ascend(1);
        let v1584_11_head = Path::from_slice(&[v1584_11_byte]);
        let v1585_2: Space = singleton(&(v1584_11_head));
        let v1585_3: Space = intersect(&(*CONSTANT_2),&(v1585_2));
        drop(v1585_2);
        let v1585_4: Space = if has_head(&(v1585_3)) { singleton(&[]) } else { Space::new() };
        drop(v1585_3);
        let v1585_7: Space = if (v1585_4).is_empty() { Space::new() } else {
          let v1586_5: Path = concat_path(&(v1584_10),&(v1584_11_head));
          let v1586_6: Space = routine_78(c, &(v1586_5), &(*p1), &(v1584_11_tail));
          drop(v1586_5);
          compose(&(v1585_4),&(v1586_6))
        };
        drop(v1585_4);
        v1584_11.join_into((v1585_7).clone());
      }
      drop(v1584_11_cursor);
      drop(v1584_10);
      compose(&(v1582_9),&(v1584_11))
    };
    drop(v1582_9);
    let v1582_13: Space = unite(&(v1582_7),&(v1582_12));
    drop(v1582_7);
    v1581_7.join_into((v1582_13).clone());
  }
  drop(v1581_7_cursor);
  (v1581_7).clone()
}

fn routine_183(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1587_6 = Space::new();
  let mut v1587_6_cursor = (*s0).read_zipper();
  for v1587_6_byte in v1587_6_cursor.child_mask().iter() {
    v1587_6_cursor.descend_to_byte(v1587_6_byte);
    let v1587_6_tail = v1587_6_cursor.make_map();
    v1587_6_cursor.ascend(1);
    let v1587_6_head = Path::from_slice(&[v1587_6_byte]);
    let v1588_2: Space = singleton(&(v1587_6_head));
    let v1588_3: Space = intersect(&(*CONSTANT_2),&(v1588_2));
    let v1588_4: Space = if has_head(&(v1588_3)) { singleton(&[]) } else { Space::new() };
    drop(v1588_3);
    let v1588_5: Space = subtract(&(*CONSTANT_1),&(v1588_4));
    drop(v1588_4);
    let mut v1588_6 = Space::new();
    let mut v1588_6_cursor = (v1587_6_tail).read_zipper();
    for v1588_6_byte in v1588_6_cursor.child_mask().iter() {
      v1588_6_cursor.descend_to_byte(v1588_6_byte);
      let v1588_6_tail = v1588_6_cursor.make_map();
      v1588_6_cursor.ascend(1);
      let v1588_6_head = Path::from_slice(&[v1588_6_byte]);
      let v1589_2: Space = Space::new();
      v1588_6.join_into((v1589_2).clone());
    }
    drop(v1588_6_cursor);
    let v1588_7: Space = compose(&(v1588_5),&(v1588_6));
    drop(v1588_5);
    drop(v1588_6);
    let v1588_8: Space = intersect(&(*CONSTANT_2),&(v1588_2));
    drop(v1588_2);
    let v1588_9: Space = if has_head(&(v1588_8)) { singleton(&[]) } else { Space::new() };
    drop(v1588_8);
    let v1588_10: Space = compose(&(v1588_9),&(v1587_6_tail));
    drop(v1588_9);
    let v1588_11: Path = concat_path(&(*p0),&(v1587_6_head));
    let v1588_12: Space = wrap(&(v1588_10),&(v1588_11));
    drop(v1588_10);
    drop(v1588_11);
    let v1588_13: Space = wrap(&(v1588_12),&(*p1));
    drop(v1588_12);
    let v1588_14: Space = unite(&(v1588_7),&(v1588_13));
    drop(v1588_7);
    drop(v1588_13);
    v1587_6.join_into((v1588_14).clone());
  }
  drop(v1587_6_cursor);
  (v1587_6).clone()
}

fn routine_184(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v1590_4 = Space::new();
  let mut v1590_4_cursor = (*s0).read_zipper();
  for v1590_4_byte in v1590_4_cursor.child_mask().iter() {
    v1590_4_cursor.descend_to_byte(v1590_4_byte);
    let v1590_4_tail = v1590_4_cursor.make_map();
    v1590_4_cursor.ascend(1);
    let v1590_4_head = Path::from_slice(&[v1590_4_byte]);
    let v1591_2: Space = Space::new();
    v1590_4.join_into((v1591_2).clone());
  }
  drop(v1590_4_cursor);
  (v1590_4).clone()
}

fn routine_185(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v1592_6: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v1592_8: Space = unwrap(&(v1592_6),&(*CONSTANT_5));
  drop(v1592_6);
  let v1592_9: Space = unwrap(&(v1592_8),&(*p0));
  drop(v1592_8);
  let mut v1592_13 = Space::new();
  let mut v1592_13_cursor = (*s0).read_zipper();
  for v1592_13_byte in v1592_13_cursor.child_mask().iter() {
    v1592_13_cursor.descend_to_byte(v1592_13_byte);
    let v1592_13_tail = v1592_13_cursor.make_map();
    v1592_13_cursor.ascend(1);
    let v1592_13_head = Path::from_slice(&[v1592_13_byte]);
    let v1593_2: Space = singleton(&(v1592_13_head));
    let v1593_3: Space = intersect(&(*CONSTANT_2),&(v1593_2));
    drop(v1593_2);
    let v1593_4: Space = if has_head(&(v1593_3)) { singleton(&[]) } else { Space::new() };
    drop(v1593_3);
    let v1593_7: Space = if (v1593_4).is_empty() { Space::new() } else {
      let v1594_5: Space = unwrap(&(v1592_9),&(v1592_13_head));
      let mut v1594_6 = Space::new();
      let mut v1594_6_cursor = (v1594_5).read_zipper();
      for v1594_6_byte in v1594_6_cursor.child_mask().iter() {
        v1594_6_cursor.descend_to_byte(v1594_6_byte);
        let v1594_6_tail = v1594_6_cursor.make_map();
        v1594_6_cursor.ascend(1);
        let v1594_6_head = Path::from_slice(&[v1594_6_byte]);
        let v1595_2: Space = singleton(&(v1594_6_head));
        let v1595_3: Space = intersect(&(*CONSTANT_2),&(v1595_2));
        let v1595_4: Space = if has_head(&(v1595_3)) { singleton(&[]) } else { Space::new() };
        drop(v1595_3);
        let v1595_5: Space = subtract(&(*CONSTANT_1),&(v1595_4));
        drop(v1595_4);
        let v1595_7: Space = if (v1595_5).is_empty() { Space::new() } else {
          let v1596_6: Space = routine_83(c, &(v1594_6_head), &(*p1), &(v1594_6_tail));
          compose(&(v1595_5),&(v1596_6))
        };
        drop(v1595_5);
        let v1595_8: Space = intersect(&(*CONSTANT_2),&(v1595_2));
        drop(v1595_2);
        let v1595_9: Space = if has_head(&(v1595_8)) { singleton(&[]) } else { Space::new() };
        drop(v1595_8);
        let v1595_11: Space = if (v1595_9).is_empty() { Space::new() } else {
          let v1597_10: Space = routine_84(c, &(v1594_6_head), &(*p1), &(v1594_6_tail));
          compose(&(v1595_9),&(v1597_10))
        };
        drop(v1595_9);
        let v1595_12: Space = unite(&(v1595_7),&(v1595_11));
        v1594_6.join_into((v1595_12).clone());
      }
      drop(v1594_6_cursor);
      drop(v1594_5);
      compose(&(v1593_4),&(v1594_6))
    };
    drop(v1593_4);
    v1592_13.join_into((v1593_7).clone());
  }
  drop(v1592_13_cursor);
  drop(v1592_9);
  (v1592_13).clone()
}

fn routine_186(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1598_12 = Space::new();
  let mut v1598_12_cursor = (*s0).read_zipper();
  for v1598_12_byte in v1598_12_cursor.child_mask().iter() {
    v1598_12_cursor.descend_to_byte(v1598_12_byte);
    let v1598_12_tail = v1598_12_cursor.make_map();
    v1598_12_cursor.ascend(1);
    let v1598_12_head = Path::from_slice(&[v1598_12_byte]);
    let v1599_2: Space = singleton(&(v1598_12_head));
    let v1599_3: Space = intersect(&(*CONSTANT_2),&(v1599_2));
    let v1599_4: Space = if has_head(&(v1599_3)) { singleton(&[]) } else { Space::new() };
    drop(v1599_3);
    let v1599_5: Space = subtract(&(*CONSTANT_1),&(v1599_4));
    drop(v1599_4);
    let v1599_8: Space = if (v1599_5).is_empty() { Space::new() } else {
      let v1600_6: Path = concat_path(&(*p0),&(v1598_12_head));
      let mut v1600_7 = Space::new();
      let mut v1600_7_cursor = (v1598_12_tail).read_zipper();
      for v1600_7_byte in v1600_7_cursor.child_mask().iter() {
        v1600_7_cursor.descend_to_byte(v1600_7_byte);
        let v1600_7_tail = v1600_7_cursor.make_map();
        v1600_7_cursor.ascend(1);
        let v1600_7_head = Path::from_slice(&[v1600_7_byte]);
        let v1601_2: Space = singleton(&(v1600_7_head));
        let v1601_3: Space = intersect(&(*CONSTANT_2),&(v1601_2));
        let v1601_4: Space = if has_head(&(v1601_3)) { singleton(&[]) } else { Space::new() };
        drop(v1601_3);
        let v1601_5: Space = subtract(&(*CONSTANT_1),&(v1601_4));
        drop(v1601_4);
        let v1601_8: Space = if (v1601_5).is_empty() { Space::new() } else {
          let v1602_6: Path = concat_path(&(v1600_6),&(v1600_7_head));
          let v1602_7: Space = routine_196(c, &(v1602_6), &(*p1), &(v1600_7_tail));
          compose(&(v1601_5),&(v1602_7))
        };
        drop(v1601_5);
        let v1601_9: Space = intersect(&(*CONSTANT_2),&(v1601_2));
        drop(v1601_2);
        let v1601_10: Space = if has_head(&(v1601_9)) { singleton(&[]) } else { Space::new() };
        drop(v1601_9);
        let v1601_12: Space = if (v1601_10).is_empty() { Space::new() } else {
          let v1603_6: Path = concat_path(&(v1600_6),&(v1600_7_head));
          let v1603_11: Space = routine_197(c, &(v1603_6), &(*p1), &(v1600_7_tail));
          drop(v1603_6);
          compose(&(v1601_10),&(v1603_11))
        };
        drop(v1601_10);
        let v1601_13: Space = unite(&(v1601_8),&(v1601_12));
        v1600_7.join_into((v1601_13).clone());
      }
      drop(v1600_7_cursor);
      compose(&(v1599_5),&(v1600_7))
    };
    drop(v1599_5);
    let v1599_9: Space = intersect(&(*CONSTANT_2),&(v1599_2));
    drop(v1599_2);
    let v1599_10: Space = if has_head(&(v1599_9)) { singleton(&[]) } else { Space::new() };
    drop(v1599_9);
    let v1599_12: Space = if (v1599_10).is_empty() { Space::new() } else {
      let v1604_6: Path = concat_path(&(*p0),&(v1598_12_head));
      let mut v1604_11 = Space::new();
      let mut v1604_11_cursor = (v1598_12_tail).read_zipper();
      for v1604_11_byte in v1604_11_cursor.child_mask().iter() {
        v1604_11_cursor.descend_to_byte(v1604_11_byte);
        let v1604_11_tail = v1604_11_cursor.make_map();
        v1604_11_cursor.ascend(1);
        let v1604_11_head = Path::from_slice(&[v1604_11_byte]);
        let v1605_2: Space = singleton(&(v1604_11_head));
        let v1605_3: Space = intersect(&(*CONSTANT_2),&(v1605_2));
        let v1605_4: Space = if has_head(&(v1605_3)) { singleton(&[]) } else { Space::new() };
        drop(v1605_3);
        let v1605_5: Space = subtract(&(*CONSTANT_1),&(v1605_4));
        drop(v1605_4);
        let v1605_8: Space = if (v1605_5).is_empty() { Space::new() } else {
          let v1606_6: Path = concat_path(&(v1604_6),&(v1604_11_head));
          let v1606_7: Space = routine_196(c, &(v1606_6), &(*p1), &(v1604_11_tail));
          compose(&(v1605_5),&(v1606_7))
        };
        drop(v1605_5);
        let v1605_9: Space = intersect(&(*CONSTANT_2),&(v1605_2));
        drop(v1605_2);
        let v1605_10: Space = if has_head(&(v1605_9)) { singleton(&[]) } else { Space::new() };
        drop(v1605_9);
        let v1605_12: Space = if (v1605_10).is_empty() { Space::new() } else {
          let v1607_6: Path = concat_path(&(v1604_6),&(v1604_11_head));
          let v1607_11: Space = routine_89(c, &(v1607_6), &(*p1), &(v1604_11_tail));
          drop(v1607_6);
          compose(&(v1605_10),&(v1607_11))
        };
        drop(v1605_10);
        let v1605_13: Space = unite(&(v1605_8),&(v1605_12));
        v1604_11.join_into((v1605_13).clone());
      }
      drop(v1604_11_cursor);
      drop(v1604_6);
      compose(&(v1599_10),&(v1604_11))
    };
    drop(v1599_10);
    let v1599_13: Space = unite(&(v1599_8),&(v1599_12));
    v1598_12.join_into((v1599_13).clone());
  }
  drop(v1598_12_cursor);
  (v1598_12).clone()
}

fn routine_187(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1608_9 = Space::new();
  let mut v1608_9_cursor = (*s0).read_zipper();
  for v1608_9_byte in v1608_9_cursor.child_mask().iter() {
    v1608_9_cursor.descend_to_byte(v1608_9_byte);
    let v1608_9_tail = v1608_9_cursor.make_map();
    v1608_9_cursor.ascend(1);
    let v1608_9_head = Path::from_slice(&[v1608_9_byte]);
    let v1609_2: Space = singleton(&(v1608_9_head));
    let v1609_3: Space = intersect(&(*CONSTANT_2),&(v1609_2));
    let v1609_4: Space = if has_head(&(v1609_3)) { singleton(&[]) } else { Space::new() };
    drop(v1609_3);
    let v1609_5: Space = subtract(&(*CONSTANT_1),&(v1609_4));
    drop(v1609_4);
    let v1609_8: Space = if (v1609_5).is_empty() { Space::new() } else {
      let v1610_6: Path = concat_path(&(*p0),&(v1608_9_head));
      let mut v1610_7 = Space::new();
      let mut v1610_7_cursor = (v1608_9_tail).read_zipper();
      for v1610_7_byte in v1610_7_cursor.child_mask().iter() {
        v1610_7_cursor.descend_to_byte(v1610_7_byte);
        let v1610_7_tail = v1610_7_cursor.make_map();
        v1610_7_cursor.ascend(1);
        let v1610_7_head = Path::from_slice(&[v1610_7_byte]);
        let v1611_2: Space = singleton(&(v1610_7_head));
        let v1611_3: Space = intersect(&(*CONSTANT_2),&(v1611_2));
        let v1611_4: Space = if has_head(&(v1611_3)) { singleton(&[]) } else { Space::new() };
        drop(v1611_3);
        let v1611_5: Space = subtract(&(*CONSTANT_1),&(v1611_4));
        drop(v1611_4);
        let v1611_8: Space = if (v1611_5).is_empty() { Space::new() } else {
          let v1612_6: Path = concat_path(&(v1610_6),&(v1610_7_head));
          let v1612_7: Space = routine_196(c, &(v1612_6), &(*p1), &(v1610_7_tail));
          compose(&(v1611_5),&(v1612_7))
        };
        drop(v1611_5);
        let v1611_9: Space = intersect(&(*CONSTANT_2),&(v1611_2));
        drop(v1611_2);
        let v1611_10: Space = if has_head(&(v1611_9)) { singleton(&[]) } else { Space::new() };
        drop(v1611_9);
        let v1611_12: Space = if (v1611_10).is_empty() { Space::new() } else {
          let v1613_6: Path = concat_path(&(v1610_6),&(v1610_7_head));
          let v1613_11: Space = routine_197(c, &(v1613_6), &(*p1), &(v1610_7_tail));
          drop(v1613_6);
          compose(&(v1611_10),&(v1613_11))
        };
        drop(v1611_10);
        let v1611_13: Space = unite(&(v1611_8),&(v1611_12));
        v1610_7.join_into((v1611_13).clone());
      }
      drop(v1610_7_cursor);
      compose(&(v1609_5),&(v1610_7))
    };
    drop(v1609_5);
    let v1609_9: Space = intersect(&(*CONSTANT_2),&(v1609_2));
    drop(v1609_2);
    let v1609_10: Space = if has_head(&(v1609_9)) { singleton(&[]) } else { Space::new() };
    drop(v1609_9);
    let v1609_11: Space = compose(&(v1609_10),&(v1608_9_tail));
    drop(v1609_10);
    let v1614_6: Path = concat_path(&(*p0),&(v1608_9_head));
    let v1609_12: Space = wrap(&(v1609_11),&(v1614_6));
    drop(v1609_11);
    let v1609_13: Space = wrap(&(v1609_12),&(*p1));
    drop(v1609_12);
    let v1609_14: Space = unite(&(v1609_8),&(v1609_13));
    drop(v1609_13);
    v1608_9.join_into((v1609_14).clone());
  }
  drop(v1608_9_cursor);
  (v1608_9).clone()
}

fn routine_188(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1615_7 = Space::new();
  let mut v1615_7_cursor = (*s0).read_zipper();
  for v1615_7_byte in v1615_7_cursor.child_mask().iter() {
    v1615_7_cursor.descend_to_byte(v1615_7_byte);
    let v1615_7_tail = v1615_7_cursor.make_map();
    v1615_7_cursor.ascend(1);
    let v1615_7_head = Path::from_slice(&[v1615_7_byte]);
    let v1616_2: Space = singleton(&(v1615_7_head));
    let v1616_3: Space = intersect(&(*CONSTANT_2),&(v1616_2));
    let v1616_4: Space = if has_head(&(v1616_3)) { singleton(&[]) } else { Space::new() };
    drop(v1616_3);
    let v1616_5: Space = subtract(&(*CONSTANT_1),&(v1616_4));
    drop(v1616_4);
    let mut v1616_6 = Space::new();
    let mut v1616_6_cursor = (v1615_7_tail).read_zipper();
    for v1616_6_byte in v1616_6_cursor.child_mask().iter() {
      v1616_6_cursor.descend_to_byte(v1616_6_byte);
      let v1616_6_tail = v1616_6_cursor.make_map();
      v1616_6_cursor.ascend(1);
      let v1616_6_head = Path::from_slice(&[v1616_6_byte]);
      let v1617_2: Space = Space::new();
      v1616_6.join_into((v1617_2).clone());
    }
    drop(v1616_6_cursor);
    let v1616_7: Space = compose(&(v1616_5),&(v1616_6));
    drop(v1616_5);
    drop(v1616_6);
    let v1616_8: Space = intersect(&(*CONSTANT_2),&(v1616_2));
    drop(v1616_2);
    let v1616_9: Space = if has_head(&(v1616_8)) { singleton(&[]) } else { Space::new() };
    drop(v1616_8);
    let v1616_12: Space = if (v1616_9).is_empty() { Space::new() } else {
      let v1618_10: Path = concat_path(&(*p0),&(v1615_7_head));
      let mut v1618_11 = Space::new();
      let mut v1618_11_cursor = (v1615_7_tail).read_zipper();
      for v1618_11_byte in v1618_11_cursor.child_mask().iter() {
        v1618_11_cursor.descend_to_byte(v1618_11_byte);
        let v1618_11_tail = v1618_11_cursor.make_map();
        v1618_11_cursor.ascend(1);
        let v1618_11_head = Path::from_slice(&[v1618_11_byte]);
        let v1619_2: Space = singleton(&(v1618_11_head));
        let v1619_3: Space = intersect(&(*CONSTANT_2),&(v1619_2));
        drop(v1619_2);
        let v1619_4: Space = if has_head(&(v1619_3)) { singleton(&[]) } else { Space::new() };
        drop(v1619_3);
        let v1619_7: Space = if (v1619_4).is_empty() { Space::new() } else {
          let v1620_5: Path = concat_path(&(v1618_10),&(v1618_11_head));
          let v1620_6: Space = routine_89(c, &(v1620_5), &(*p1), &(v1618_11_tail));
          drop(v1620_5);
          compose(&(v1619_4),&(v1620_6))
        };
        drop(v1619_4);
        v1618_11.join_into((v1619_7).clone());
      }
      drop(v1618_11_cursor);
      drop(v1618_10);
      compose(&(v1616_9),&(v1618_11))
    };
    drop(v1616_9);
    let v1616_13: Space = unite(&(v1616_7),&(v1616_12));
    drop(v1616_7);
    v1615_7.join_into((v1616_13).clone());
  }
  drop(v1615_7_cursor);
  (v1615_7).clone()
}

fn routine_189(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1621_6 = Space::new();
  let mut v1621_6_cursor = (*s0).read_zipper();
  for v1621_6_byte in v1621_6_cursor.child_mask().iter() {
    v1621_6_cursor.descend_to_byte(v1621_6_byte);
    let v1621_6_tail = v1621_6_cursor.make_map();
    v1621_6_cursor.ascend(1);
    let v1621_6_head = Path::from_slice(&[v1621_6_byte]);
    let v1622_2: Space = singleton(&(v1621_6_head));
    let v1622_3: Space = intersect(&(*CONSTANT_2),&(v1622_2));
    let v1622_4: Space = if has_head(&(v1622_3)) { singleton(&[]) } else { Space::new() };
    drop(v1622_3);
    let v1622_5: Space = subtract(&(*CONSTANT_1),&(v1622_4));
    drop(v1622_4);
    let mut v1622_6 = Space::new();
    let mut v1622_6_cursor = (v1621_6_tail).read_zipper();
    for v1622_6_byte in v1622_6_cursor.child_mask().iter() {
      v1622_6_cursor.descend_to_byte(v1622_6_byte);
      let v1622_6_tail = v1622_6_cursor.make_map();
      v1622_6_cursor.ascend(1);
      let v1622_6_head = Path::from_slice(&[v1622_6_byte]);
      let v1623_2: Space = Space::new();
      v1622_6.join_into((v1623_2).clone());
    }
    drop(v1622_6_cursor);
    let v1622_7: Space = compose(&(v1622_5),&(v1622_6));
    drop(v1622_5);
    drop(v1622_6);
    let v1622_8: Space = intersect(&(*CONSTANT_2),&(v1622_2));
    drop(v1622_2);
    let v1622_9: Space = if has_head(&(v1622_8)) { singleton(&[]) } else { Space::new() };
    drop(v1622_8);
    let v1622_10: Space = compose(&(v1622_9),&(v1621_6_tail));
    drop(v1622_9);
    let v1622_11: Path = concat_path(&(*p0),&(v1621_6_head));
    let v1622_12: Space = wrap(&(v1622_10),&(v1622_11));
    drop(v1622_10);
    drop(v1622_11);
    let v1622_13: Space = wrap(&(v1622_12),&(*p1));
    drop(v1622_12);
    let v1622_14: Space = unite(&(v1622_7),&(v1622_13));
    drop(v1622_7);
    drop(v1622_13);
    v1621_6.join_into((v1622_14).clone());
  }
  drop(v1621_6_cursor);
  (v1621_6).clone()
}

fn routine_190(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1624_3 = Space::new();
  let mut v1624_3_cursor = (*s0).read_zipper();
  for v1624_3_byte in v1624_3_cursor.child_mask().iter() {
    v1624_3_cursor.descend_to_byte(v1624_3_byte);
    let v1624_3_tail = v1624_3_cursor.make_map();
    v1624_3_cursor.ascend(1);
    let v1624_3_head = Path::from_slice(&[v1624_3_byte]);
    let v1625_2: Space = Space::new();
    v1624_3.join_into((v1625_2).clone());
  }
  drop(v1624_3_cursor);
  (v1624_3).clone()
}

fn routine_191(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1626_4 = Space::new();
  let mut v1626_4_cursor = (*s0).read_zipper();
  for v1626_4_byte in v1626_4_cursor.child_mask().iter() {
    v1626_4_cursor.descend_to_byte(v1626_4_byte);
    let v1626_4_tail = v1626_4_cursor.make_map();
    v1626_4_cursor.ascend(1);
    let v1626_4_head = Path::from_slice(&[v1626_4_byte]);
    let v1627_2: Space = singleton(&(v1626_4_head));
    let v1627_3: Space = intersect(&(*CONSTANT_2),&(v1627_2));
    drop(v1627_2);
    let v1627_4: Space = if has_head(&(v1627_3)) { singleton(&[]) } else { Space::new() };
    drop(v1627_3);
    let v1627_5: Space = compose(&(v1627_4),&(v1626_4_tail));
    drop(v1627_4);
    let v1627_6: Path = concat_path(&(*p0),&(v1626_4_head));
    let v1627_7: Space = wrap(&(v1627_5),&(v1627_6));
    drop(v1627_5);
    drop(v1627_6);
    v1626_4.join_into((v1627_7).clone());
  }
  drop(v1626_4_cursor);
  let v1626_5: Space = wrap(&(v1626_4),&(*p1));
  drop(v1626_4);
  (v1626_5).clone()
}

fn routine_192(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1628_3 = Space::new();
  let mut v1628_3_cursor = (*s0).read_zipper();
  for v1628_3_byte in v1628_3_cursor.child_mask().iter() {
    v1628_3_cursor.descend_to_byte(v1628_3_byte);
    let v1628_3_tail = v1628_3_cursor.make_map();
    v1628_3_cursor.ascend(1);
    let v1628_3_head = Path::from_slice(&[v1628_3_byte]);
    let v1629_2: Space = Space::new();
    v1628_3.join_into((v1629_2).clone());
  }
  drop(v1628_3_cursor);
  (v1628_3).clone()
}

fn routine_193(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1630_4 = Space::new();
  let mut v1630_4_cursor = (*s0).read_zipper();
  for v1630_4_byte in v1630_4_cursor.child_mask().iter() {
    v1630_4_cursor.descend_to_byte(v1630_4_byte);
    let v1630_4_tail = v1630_4_cursor.make_map();
    v1630_4_cursor.ascend(1);
    let v1630_4_head = Path::from_slice(&[v1630_4_byte]);
    let v1631_2: Space = singleton(&(v1630_4_head));
    let v1631_3: Space = intersect(&(*CONSTANT_2),&(v1631_2));
    drop(v1631_2);
    let v1631_4: Space = if has_head(&(v1631_3)) { singleton(&[]) } else { Space::new() };
    drop(v1631_3);
    let v1631_5: Space = compose(&(v1631_4),&(v1630_4_tail));
    drop(v1631_4);
    let v1631_6: Path = concat_path(&(*p0),&(v1630_4_head));
    let v1631_7: Space = wrap(&(v1631_5),&(v1631_6));
    drop(v1631_5);
    drop(v1631_6);
    v1630_4.join_into((v1631_7).clone());
  }
  drop(v1630_4_cursor);
  let v1630_5: Space = wrap(&(v1630_4),&(*p1));
  drop(v1630_4);
  (v1630_5).clone()
}

fn routine_194(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1632_3 = Space::new();
  let mut v1632_3_cursor = (*s0).read_zipper();
  for v1632_3_byte in v1632_3_cursor.child_mask().iter() {
    v1632_3_cursor.descend_to_byte(v1632_3_byte);
    let v1632_3_tail = v1632_3_cursor.make_map();
    v1632_3_cursor.ascend(1);
    let v1632_3_head = Path::from_slice(&[v1632_3_byte]);
    let v1633_2: Space = Space::new();
    v1632_3.join_into((v1633_2).clone());
  }
  drop(v1632_3_cursor);
  (v1632_3).clone()
}

fn routine_195(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1634_4 = Space::new();
  let mut v1634_4_cursor = (*s0).read_zipper();
  for v1634_4_byte in v1634_4_cursor.child_mask().iter() {
    v1634_4_cursor.descend_to_byte(v1634_4_byte);
    let v1634_4_tail = v1634_4_cursor.make_map();
    v1634_4_cursor.ascend(1);
    let v1634_4_head = Path::from_slice(&[v1634_4_byte]);
    let v1635_2: Space = singleton(&(v1634_4_head));
    let v1635_3: Space = intersect(&(*CONSTANT_2),&(v1635_2));
    drop(v1635_2);
    let v1635_4: Space = if has_head(&(v1635_3)) { singleton(&[]) } else { Space::new() };
    drop(v1635_3);
    let v1635_5: Space = compose(&(v1635_4),&(v1634_4_tail));
    drop(v1635_4);
    let v1635_6: Path = concat_path(&(*p0),&(v1634_4_head));
    let v1635_7: Space = wrap(&(v1635_5),&(v1635_6));
    drop(v1635_5);
    drop(v1635_6);
    v1634_4.join_into((v1635_7).clone());
  }
  drop(v1634_4_cursor);
  let v1634_5: Space = wrap(&(v1634_4),&(*p1));
  drop(v1634_4);
  (v1634_5).clone()
}

fn routine_196(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1636_3 = Space::new();
  let mut v1636_3_cursor = (*s0).read_zipper();
  for v1636_3_byte in v1636_3_cursor.child_mask().iter() {
    v1636_3_cursor.descend_to_byte(v1636_3_byte);
    let v1636_3_tail = v1636_3_cursor.make_map();
    v1636_3_cursor.ascend(1);
    let v1636_3_head = Path::from_slice(&[v1636_3_byte]);
    let v1637_2: Space = Space::new();
    v1636_3.join_into((v1637_2).clone());
  }
  drop(v1636_3_cursor);
  (v1636_3).clone()
}

fn routine_197(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1638_4 = Space::new();
  let mut v1638_4_cursor = (*s0).read_zipper();
  for v1638_4_byte in v1638_4_cursor.child_mask().iter() {
    v1638_4_cursor.descend_to_byte(v1638_4_byte);
    let v1638_4_tail = v1638_4_cursor.make_map();
    v1638_4_cursor.ascend(1);
    let v1638_4_head = Path::from_slice(&[v1638_4_byte]);
    let v1639_2: Space = singleton(&(v1638_4_head));
    let v1639_3: Space = intersect(&(*CONSTANT_2),&(v1639_2));
    drop(v1639_2);
    let v1639_4: Space = if has_head(&(v1639_3)) { singleton(&[]) } else { Space::new() };
    drop(v1639_3);
    let v1639_5: Space = compose(&(v1639_4),&(v1638_4_tail));
    drop(v1639_4);
    let v1639_6: Path = concat_path(&(*p0),&(v1638_4_head));
    let v1639_7: Space = wrap(&(v1639_5),&(v1639_6));
    drop(v1639_5);
    drop(v1639_6);
    v1638_4.join_into((v1639_7).clone());
  }
  drop(v1638_4_cursor);
  let v1638_5: Space = wrap(&(v1638_4),&(*p1));
  drop(v1638_4);
  (v1638_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
