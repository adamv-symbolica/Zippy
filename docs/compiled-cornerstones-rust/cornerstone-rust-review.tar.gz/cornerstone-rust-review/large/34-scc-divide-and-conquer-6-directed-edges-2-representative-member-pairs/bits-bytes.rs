#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 8 0 1 1 1 0 0 1 1 6 1 1 1 0 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 6 1 1 0 0 1 1"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 5 1 0 0 1 1 3 1 1 1"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 0 1 1"));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 10 0 0 0 1 1 1 0 0 1 1 8 0 0 1 1 1 0 1 1 7 0 1 1 0 0 1 1 5 0 1 1 1 1 8 1 0 1 1 0 0 1 1 5 1 1 0 1 1"));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &Path,capture_1: &Space,capture_2: &Space,capture_3: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v273_5: Space = singleton(&(*capture_0));
  let mut v273_15: Space = (v273_5).clone();
  loop {
    let v274_1: Space = intersect(&(v273_15),&(*capture_3));
    let v274_2: Space = restrict_to(&(*capture_1),&(v274_1));
    drop(v274_1);
    let mut v274_3 = Space::new();
    let mut v274_3_cursor = (v274_2).read_zipper();
    for v274_3_byte in v274_3_cursor.child_mask().iter() {
      v274_3_cursor.descend_to_byte(v274_3_byte);
      let v274_3_tail = v274_3_cursor.make_map();
      v274_3_cursor.ascend(1);
      let v274_3_head = Path::from_slice(&[v274_3_byte]);
      let v275_2: Space = singleton(&(v274_3_head));
      let v275_3: Space = intersect(&(*CONSTANT_9),&(v275_2));
      let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
      drop(v275_3);
      let v275_5: Space = subtract(&(*CONSTANT_0),&(v275_4));
      drop(v275_4);
      let v275_7: Space = if (v275_5).is_empty() { Space::new() } else {
        let mut v276_6 = Space::new();
        let mut v276_6_cursor = (v274_3_tail).read_zipper();
        for v276_6_byte in v276_6_cursor.child_mask().iter() {
          v276_6_cursor.descend_to_byte(v276_6_byte);
          let v276_6_tail = v276_6_cursor.make_map();
          v276_6_cursor.ascend(1);
          let v276_6_head = Path::from_slice(&[v276_6_byte]);
          let v277_2: Space = singleton(&(v276_6_head));
          let v277_3: Space = intersect(&(*CONSTANT_9),&(v277_2));
          let v277_4: Space = if has_head(&(v277_3)) { singleton(&[]) } else { Space::new() };
          drop(v277_3);
          let v277_5: Space = subtract(&(*CONSTANT_0),&(v277_4));
          drop(v277_4);
          let v277_8: Space = if (v277_5).is_empty() { Space::new() } else {
            let v278_6: Path = concat_path(&(v274_3_head),&(v276_6_head));
            let v278_7: Space = routine_49(c, &(v278_6), &(v276_6_tail));
            compose(&(v277_5),&(v278_7))
          };
          drop(v277_5);
          let v277_9: Space = intersect(&(*CONSTANT_9),&(v277_2));
          drop(v277_2);
          let v277_10: Space = if has_head(&(v277_9)) { singleton(&[]) } else { Space::new() };
          drop(v277_9);
          let v277_12: Space = if (v277_10).is_empty() { Space::new() } else {
            let v279_6: Path = concat_path(&(v274_3_head),&(v276_6_head));
            let v279_11: Space = routine_50(c, &(v279_6), &(v276_6_tail));
            drop(v279_6);
            compose(&(v277_10),&(v279_11))
          };
          drop(v277_10);
          let v277_13: Space = unite(&(v277_8),&(v277_12));
          v276_6.join_into((v277_13).clone());
        }
        drop(v276_6_cursor);
        compose(&(v275_5),&(v276_6))
      };
      drop(v275_5);
      let v275_8: Space = intersect(&(*CONSTANT_9),&(v275_2));
      drop(v275_2);
      let v275_9: Space = if has_head(&(v275_8)) { singleton(&[]) } else { Space::new() };
      drop(v275_8);
      let v275_11: Space = if (v275_9).is_empty() { Space::new() } else {
        let mut v280_10 = Space::new();
        let mut v280_10_cursor = (v274_3_tail).read_zipper();
        for v280_10_byte in v280_10_cursor.child_mask().iter() {
          v280_10_cursor.descend_to_byte(v280_10_byte);
          let v280_10_tail = v280_10_cursor.make_map();
          v280_10_cursor.ascend(1);
          let v280_10_head = Path::from_slice(&[v280_10_byte]);
          let v281_2: Space = singleton(&(v280_10_head));
          let v281_3: Space = intersect(&(*CONSTANT_9),&(v281_2));
          let v281_4: Space = if has_head(&(v281_3)) { singleton(&[]) } else { Space::new() };
          drop(v281_3);
          let v281_5: Space = subtract(&(*CONSTANT_0),&(v281_4));
          drop(v281_4);
          let v281_8: Space = if (v281_5).is_empty() { Space::new() } else {
            let v282_6: Path = concat_path(&(v274_3_head),&(v280_10_head));
            let v282_7: Space = routine_49(c, &(v282_6), &(v280_10_tail));
            compose(&(v281_5),&(v282_7))
          };
          drop(v281_5);
          let v281_9: Space = intersect(&(*CONSTANT_9),&(v281_2));
          drop(v281_2);
          let v281_10: Space = if has_head(&(v281_9)) { singleton(&[]) } else { Space::new() };
          drop(v281_9);
          let v281_12: Space = if (v281_10).is_empty() { Space::new() } else {
            let v283_6: Path = concat_path(&(v274_3_head),&(v280_10_head));
            let v283_11: Space = routine_51(c, &(v283_6), &(v280_10_tail));
            drop(v283_6);
            compose(&(v281_10),&(v283_11))
          };
          drop(v281_10);
          let v281_13: Space = unite(&(v281_8),&(v281_12));
          v280_10.join_into((v281_13).clone());
        }
        drop(v280_10_cursor);
        compose(&(v275_9),&(v280_10))
      };
      drop(v275_9);
      let v275_12: Space = unite(&(v275_7),&(v275_11));
      v274_3.join_into((v275_12).clone());
    }
    drop(v274_3_cursor);
    drop(v274_2);
    let v274_4: Space = unite(&(v274_3),&(v273_15));
    let v274_5: Space = intersect(&(v274_4),&(*capture_3));
    let v273_15_next = unite(&v273_15,&(v274_5));
    if equal(&v273_15_next,&v273_15) { break; }
    v273_15 = v273_15_next;
  }
  let mut v273_25: Space = (v273_5).clone();
  loop {
    let v284_1: Space = intersect(&(v273_25),&(*capture_3));
    let v284_2: Space = restrict_to(&(*capture_2),&(v284_1));
    drop(v284_1);
    let mut v284_3 = Space::new();
    let mut v284_3_cursor = (v284_2).read_zipper();
    for v284_3_byte in v284_3_cursor.child_mask().iter() {
      v284_3_cursor.descend_to_byte(v284_3_byte);
      let v284_3_tail = v284_3_cursor.make_map();
      v284_3_cursor.ascend(1);
      let v284_3_head = Path::from_slice(&[v284_3_byte]);
      let v285_2: Space = singleton(&(v284_3_head));
      let v285_3: Space = intersect(&(*CONSTANT_9),&(v285_2));
      let v285_4: Space = if has_head(&(v285_3)) { singleton(&[]) } else { Space::new() };
      drop(v285_3);
      let v285_5: Space = subtract(&(*CONSTANT_0),&(v285_4));
      drop(v285_4);
      let v285_7: Space = if (v285_5).is_empty() { Space::new() } else {
        let mut v286_6 = Space::new();
        let mut v286_6_cursor = (v284_3_tail).read_zipper();
        for v286_6_byte in v286_6_cursor.child_mask().iter() {
          v286_6_cursor.descend_to_byte(v286_6_byte);
          let v286_6_tail = v286_6_cursor.make_map();
          v286_6_cursor.ascend(1);
          let v286_6_head = Path::from_slice(&[v286_6_byte]);
          let v287_2: Space = singleton(&(v286_6_head));
          let v287_3: Space = intersect(&(*CONSTANT_9),&(v287_2));
          let v287_4: Space = if has_head(&(v287_3)) { singleton(&[]) } else { Space::new() };
          drop(v287_3);
          let v287_5: Space = subtract(&(*CONSTANT_0),&(v287_4));
          drop(v287_4);
          let v287_8: Space = if (v287_5).is_empty() { Space::new() } else {
            let v288_6: Path = concat_path(&(v284_3_head),&(v286_6_head));
            let v288_7: Space = routine_49(c, &(v288_6), &(v286_6_tail));
            compose(&(v287_5),&(v288_7))
          };
          drop(v287_5);
          let v287_9: Space = intersect(&(*CONSTANT_9),&(v287_2));
          drop(v287_2);
          let v287_10: Space = if has_head(&(v287_9)) { singleton(&[]) } else { Space::new() };
          drop(v287_9);
          let v287_12: Space = if (v287_10).is_empty() { Space::new() } else {
            let v289_6: Path = concat_path(&(v284_3_head),&(v286_6_head));
            let v289_11: Space = routine_50(c, &(v289_6), &(v286_6_tail));
            drop(v289_6);
            compose(&(v287_10),&(v289_11))
          };
          drop(v287_10);
          let v287_13: Space = unite(&(v287_8),&(v287_12));
          v286_6.join_into((v287_13).clone());
        }
        drop(v286_6_cursor);
        compose(&(v285_5),&(v286_6))
      };
      drop(v285_5);
      let v285_8: Space = intersect(&(*CONSTANT_9),&(v285_2));
      drop(v285_2);
      let v285_9: Space = if has_head(&(v285_8)) { singleton(&[]) } else { Space::new() };
      drop(v285_8);
      let v285_11: Space = if (v285_9).is_empty() { Space::new() } else {
        let mut v290_10 = Space::new();
        let mut v290_10_cursor = (v284_3_tail).read_zipper();
        for v290_10_byte in v290_10_cursor.child_mask().iter() {
          v290_10_cursor.descend_to_byte(v290_10_byte);
          let v290_10_tail = v290_10_cursor.make_map();
          v290_10_cursor.ascend(1);
          let v290_10_head = Path::from_slice(&[v290_10_byte]);
          let v291_2: Space = singleton(&(v290_10_head));
          let v291_3: Space = intersect(&(*CONSTANT_9),&(v291_2));
          let v291_4: Space = if has_head(&(v291_3)) { singleton(&[]) } else { Space::new() };
          drop(v291_3);
          let v291_5: Space = subtract(&(*CONSTANT_0),&(v291_4));
          drop(v291_4);
          let v291_8: Space = if (v291_5).is_empty() { Space::new() } else {
            let v292_6: Path = concat_path(&(v284_3_head),&(v290_10_head));
            let v292_7: Space = routine_49(c, &(v292_6), &(v290_10_tail));
            compose(&(v291_5),&(v292_7))
          };
          drop(v291_5);
          let v291_9: Space = intersect(&(*CONSTANT_9),&(v291_2));
          drop(v291_2);
          let v291_10: Space = if has_head(&(v291_9)) { singleton(&[]) } else { Space::new() };
          drop(v291_9);
          let v291_12: Space = if (v291_10).is_empty() { Space::new() } else {
            let v293_6: Path = concat_path(&(v284_3_head),&(v290_10_head));
            let v293_11: Space = routine_51(c, &(v293_6), &(v290_10_tail));
            drop(v293_6);
            compose(&(v291_10),&(v293_11))
          };
          drop(v291_10);
          let v291_13: Space = unite(&(v291_8),&(v291_12));
          v290_10.join_into((v291_13).clone());
        }
        drop(v290_10_cursor);
        compose(&(v285_9),&(v290_10))
      };
      drop(v285_9);
      let v285_12: Space = unite(&(v285_7),&(v285_11));
      v284_3.join_into((v285_12).clone());
    }
    drop(v284_3_cursor);
    drop(v284_2);
    let v284_4: Space = unite(&(v284_3),&(v273_25));
    let v284_5: Space = intersect(&(v284_4),&(*capture_3));
    let v273_25_next = unite(&v273_25,&(v284_5));
    if equal(&v273_25_next,&v273_25) { break; }
    v273_25 = v273_25_next;
  }
  let v273_26: Space = intersect(&(v273_15),&(v273_25));
  let v273_27: Space = subtract(&(v273_26),&(v273_5));
  let v273_28: Space = wrap(&(v273_27),&(*capture_0));
  let mut v273_38: Space = (v273_5).clone();
  loop {
    let v294_1: Space = intersect(&(v273_38),&(*capture_3));
    let v294_2: Space = restrict_to(&(*capture_2),&(v294_1));
    drop(v294_1);
    let mut v294_3 = Space::new();
    let mut v294_3_cursor = (v294_2).read_zipper();
    for v294_3_byte in v294_3_cursor.child_mask().iter() {
      v294_3_cursor.descend_to_byte(v294_3_byte);
      let v294_3_tail = v294_3_cursor.make_map();
      v294_3_cursor.ascend(1);
      let v294_3_head = Path::from_slice(&[v294_3_byte]);
      let v295_2: Space = singleton(&(v294_3_head));
      let v295_3: Space = intersect(&(*CONSTANT_9),&(v295_2));
      let v295_4: Space = if has_head(&(v295_3)) { singleton(&[]) } else { Space::new() };
      drop(v295_3);
      let v295_5: Space = subtract(&(*CONSTANT_0),&(v295_4));
      drop(v295_4);
      let v295_7: Space = if (v295_5).is_empty() { Space::new() } else {
        let mut v296_6 = Space::new();
        let mut v296_6_cursor = (v294_3_tail).read_zipper();
        for v296_6_byte in v296_6_cursor.child_mask().iter() {
          v296_6_cursor.descend_to_byte(v296_6_byte);
          let v296_6_tail = v296_6_cursor.make_map();
          v296_6_cursor.ascend(1);
          let v296_6_head = Path::from_slice(&[v296_6_byte]);
          let v297_2: Space = singleton(&(v296_6_head));
          let v297_3: Space = intersect(&(*CONSTANT_9),&(v297_2));
          let v297_4: Space = if has_head(&(v297_3)) { singleton(&[]) } else { Space::new() };
          drop(v297_3);
          let v297_5: Space = subtract(&(*CONSTANT_0),&(v297_4));
          drop(v297_4);
          let v297_8: Space = if (v297_5).is_empty() { Space::new() } else {
            let v298_6: Path = concat_path(&(v294_3_head),&(v296_6_head));
            let v298_7: Space = routine_49(c, &(v298_6), &(v296_6_tail));
            compose(&(v297_5),&(v298_7))
          };
          drop(v297_5);
          let v297_9: Space = intersect(&(*CONSTANT_9),&(v297_2));
          drop(v297_2);
          let v297_10: Space = if has_head(&(v297_9)) { singleton(&[]) } else { Space::new() };
          drop(v297_9);
          let v297_12: Space = if (v297_10).is_empty() { Space::new() } else {
            let v299_6: Path = concat_path(&(v294_3_head),&(v296_6_head));
            let v299_11: Space = routine_50(c, &(v299_6), &(v296_6_tail));
            drop(v299_6);
            compose(&(v297_10),&(v299_11))
          };
          drop(v297_10);
          let v297_13: Space = unite(&(v297_8),&(v297_12));
          v296_6.join_into((v297_13).clone());
        }
        drop(v296_6_cursor);
        compose(&(v295_5),&(v296_6))
      };
      drop(v295_5);
      let v295_8: Space = intersect(&(*CONSTANT_9),&(v295_2));
      drop(v295_2);
      let v295_9: Space = if has_head(&(v295_8)) { singleton(&[]) } else { Space::new() };
      drop(v295_8);
      let v295_11: Space = if (v295_9).is_empty() { Space::new() } else {
        let mut v300_10 = Space::new();
        let mut v300_10_cursor = (v294_3_tail).read_zipper();
        for v300_10_byte in v300_10_cursor.child_mask().iter() {
          v300_10_cursor.descend_to_byte(v300_10_byte);
          let v300_10_tail = v300_10_cursor.make_map();
          v300_10_cursor.ascend(1);
          let v300_10_head = Path::from_slice(&[v300_10_byte]);
          let v301_2: Space = singleton(&(v300_10_head));
          let v301_3: Space = intersect(&(*CONSTANT_9),&(v301_2));
          let v301_4: Space = if has_head(&(v301_3)) { singleton(&[]) } else { Space::new() };
          drop(v301_3);
          let v301_5: Space = subtract(&(*CONSTANT_0),&(v301_4));
          drop(v301_4);
          let v301_8: Space = if (v301_5).is_empty() { Space::new() } else {
            let v302_6: Path = concat_path(&(v294_3_head),&(v300_10_head));
            let v302_7: Space = routine_49(c, &(v302_6), &(v300_10_tail));
            compose(&(v301_5),&(v302_7))
          };
          drop(v301_5);
          let v301_9: Space = intersect(&(*CONSTANT_9),&(v301_2));
          drop(v301_2);
          let v301_10: Space = if has_head(&(v301_9)) { singleton(&[]) } else { Space::new() };
          drop(v301_9);
          let v301_12: Space = if (v301_10).is_empty() { Space::new() } else {
            let v303_6: Path = concat_path(&(v294_3_head),&(v300_10_head));
            let v303_11: Space = routine_51(c, &(v303_6), &(v300_10_tail));
            drop(v303_6);
            compose(&(v301_10),&(v303_11))
          };
          drop(v301_10);
          let v301_13: Space = unite(&(v301_8),&(v301_12));
          v300_10.join_into((v301_13).clone());
        }
        drop(v300_10_cursor);
        compose(&(v295_9),&(v300_10))
      };
      drop(v295_9);
      let v295_12: Space = unite(&(v295_7),&(v295_11));
      v294_3.join_into((v295_12).clone());
    }
    drop(v294_3_cursor);
    drop(v294_2);
    let v294_4: Space = unite(&(v294_3),&(v273_38));
    let v294_5: Space = intersect(&(v294_4),&(*capture_3));
    let v273_38_next = unite(&v273_38,&(v294_5));
    if equal(&v273_38_next,&v273_38) { break; }
    v273_38 = v273_38_next;
  }
  let v273_39: Space = subtract(&(*capture_3),&(v273_38));
  let mut v273_49: Space = (v273_5).clone();
  loop {
    let v304_1: Space = intersect(&(v273_49),&(*capture_3));
    let v304_2: Space = restrict_to(&(*capture_1),&(v304_1));
    drop(v304_1);
    let mut v304_3 = Space::new();
    let mut v304_3_cursor = (v304_2).read_zipper();
    for v304_3_byte in v304_3_cursor.child_mask().iter() {
      v304_3_cursor.descend_to_byte(v304_3_byte);
      let v304_3_tail = v304_3_cursor.make_map();
      v304_3_cursor.ascend(1);
      let v304_3_head = Path::from_slice(&[v304_3_byte]);
      let v305_2: Space = singleton(&(v304_3_head));
      let v305_3: Space = intersect(&(*CONSTANT_9),&(v305_2));
      let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
      drop(v305_3);
      let v305_5: Space = subtract(&(*CONSTANT_0),&(v305_4));
      drop(v305_4);
      let v305_7: Space = if (v305_5).is_empty() { Space::new() } else {
        let mut v306_6 = Space::new();
        let mut v306_6_cursor = (v304_3_tail).read_zipper();
        for v306_6_byte in v306_6_cursor.child_mask().iter() {
          v306_6_cursor.descend_to_byte(v306_6_byte);
          let v306_6_tail = v306_6_cursor.make_map();
          v306_6_cursor.ascend(1);
          let v306_6_head = Path::from_slice(&[v306_6_byte]);
          let v307_2: Space = singleton(&(v306_6_head));
          let v307_3: Space = intersect(&(*CONSTANT_9),&(v307_2));
          let v307_4: Space = if has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
          drop(v307_3);
          let v307_5: Space = subtract(&(*CONSTANT_0),&(v307_4));
          drop(v307_4);
          let v307_8: Space = if (v307_5).is_empty() { Space::new() } else {
            let v308_6: Path = concat_path(&(v304_3_head),&(v306_6_head));
            let v308_7: Space = routine_49(c, &(v308_6), &(v306_6_tail));
            compose(&(v307_5),&(v308_7))
          };
          drop(v307_5);
          let v307_9: Space = intersect(&(*CONSTANT_9),&(v307_2));
          drop(v307_2);
          let v307_10: Space = if has_head(&(v307_9)) { singleton(&[]) } else { Space::new() };
          drop(v307_9);
          let v307_12: Space = if (v307_10).is_empty() { Space::new() } else {
            let v309_6: Path = concat_path(&(v304_3_head),&(v306_6_head));
            let v309_11: Space = routine_50(c, &(v309_6), &(v306_6_tail));
            drop(v309_6);
            compose(&(v307_10),&(v309_11))
          };
          drop(v307_10);
          let v307_13: Space = unite(&(v307_8),&(v307_12));
          v306_6.join_into((v307_13).clone());
        }
        drop(v306_6_cursor);
        compose(&(v305_5),&(v306_6))
      };
      drop(v305_5);
      let v305_8: Space = intersect(&(*CONSTANT_9),&(v305_2));
      drop(v305_2);
      let v305_9: Space = if has_head(&(v305_8)) { singleton(&[]) } else { Space::new() };
      drop(v305_8);
      let v305_11: Space = if (v305_9).is_empty() { Space::new() } else {
        let mut v310_10 = Space::new();
        let mut v310_10_cursor = (v304_3_tail).read_zipper();
        for v310_10_byte in v310_10_cursor.child_mask().iter() {
          v310_10_cursor.descend_to_byte(v310_10_byte);
          let v310_10_tail = v310_10_cursor.make_map();
          v310_10_cursor.ascend(1);
          let v310_10_head = Path::from_slice(&[v310_10_byte]);
          let v311_2: Space = singleton(&(v310_10_head));
          let v311_3: Space = intersect(&(*CONSTANT_9),&(v311_2));
          let v311_4: Space = if has_head(&(v311_3)) { singleton(&[]) } else { Space::new() };
          drop(v311_3);
          let v311_5: Space = subtract(&(*CONSTANT_0),&(v311_4));
          drop(v311_4);
          let v311_8: Space = if (v311_5).is_empty() { Space::new() } else {
            let v312_6: Path = concat_path(&(v304_3_head),&(v310_10_head));
            let v312_7: Space = routine_49(c, &(v312_6), &(v310_10_tail));
            compose(&(v311_5),&(v312_7))
          };
          drop(v311_5);
          let v311_9: Space = intersect(&(*CONSTANT_9),&(v311_2));
          drop(v311_2);
          let v311_10: Space = if has_head(&(v311_9)) { singleton(&[]) } else { Space::new() };
          drop(v311_9);
          let v311_12: Space = if (v311_10).is_empty() { Space::new() } else {
            let v313_6: Path = concat_path(&(v304_3_head),&(v310_10_head));
            let v313_11: Space = routine_51(c, &(v313_6), &(v310_10_tail));
            drop(v313_6);
            compose(&(v311_10),&(v313_11))
          };
          drop(v311_10);
          let v311_13: Space = unite(&(v311_8),&(v311_12));
          v310_10.join_into((v311_13).clone());
        }
        drop(v310_10_cursor);
        compose(&(v305_9),&(v310_10))
      };
      drop(v305_9);
      let v305_12: Space = unite(&(v305_7),&(v305_11));
      v304_3.join_into((v305_12).clone());
    }
    drop(v304_3_cursor);
    drop(v304_2);
    let v304_4: Space = unite(&(v304_3),&(v273_49));
    let v304_5: Space = intersect(&(v304_4),&(*capture_3));
    let v273_49_next = unite(&v273_49,&(v304_5));
    if equal(&v273_49_next,&v273_49) { break; }
    v273_49 = v273_49_next;
  }
  let v273_50: Space = subtract(&(v273_39),&(v273_49));
  let v273_51: Space = routine_10(c, &(v273_50));
  let mut v273_91 = Space::new();
  let mut v273_91_cursor = (v273_51).read_zipper();
  for v273_91_byte in v273_91_cursor.child_mask().iter() {
    v273_91_cursor.descend_to_byte(v273_91_byte);
    let v273_91_tail = v273_91_cursor.make_map();
    v273_91_cursor.ascend(1);
    let v273_91_head = Path::from_slice(&[v273_91_byte]);
    let v314_2: Space = singleton(&(v273_91_head));
    let v314_3: Space = intersect(&(*CONSTANT_9),&(v314_2));
    let v314_4: Space = if has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
    drop(v314_3);
    let v314_5: Space = subtract(&(*CONSTANT_0),&(v314_4));
    drop(v314_4);
    let v314_11: Space = if (v314_5).is_empty() { Space::new() } else {
      let mut v315_6: Space = (v273_5).clone();
      loop {
        let v316_1: Space = intersect(&(v315_6),&(*capture_3));
        let v316_2: Space = restrict_to(&(*capture_2),&(v316_1));
        drop(v316_1);
        let mut v316_3 = Space::new();
        let mut v316_3_cursor = (v316_2).read_zipper();
        for v316_3_byte in v316_3_cursor.child_mask().iter() {
          v316_3_cursor.descend_to_byte(v316_3_byte);
          let v316_3_tail = v316_3_cursor.make_map();
          v316_3_cursor.ascend(1);
          let v316_3_head = Path::from_slice(&[v316_3_byte]);
          let v317_2: Space = singleton(&(v316_3_head));
          let v317_3: Space = intersect(&(*CONSTANT_9),&(v317_2));
          let v317_4: Space = if has_head(&(v317_3)) { singleton(&[]) } else { Space::new() };
          drop(v317_3);
          let v317_5: Space = subtract(&(*CONSTANT_0),&(v317_4));
          drop(v317_4);
          let v317_7: Space = if (v317_5).is_empty() { Space::new() } else {
            let mut v318_6 = Space::new();
            let mut v318_6_cursor = (v316_3_tail).read_zipper();
            for v318_6_byte in v318_6_cursor.child_mask().iter() {
              v318_6_cursor.descend_to_byte(v318_6_byte);
              let v318_6_tail = v318_6_cursor.make_map();
              v318_6_cursor.ascend(1);
              let v318_6_head = Path::from_slice(&[v318_6_byte]);
              let v319_2: Space = singleton(&(v318_6_head));
              let v319_3: Space = intersect(&(*CONSTANT_9),&(v319_2));
              let v319_4: Space = if has_head(&(v319_3)) { singleton(&[]) } else { Space::new() };
              drop(v319_3);
              let v319_5: Space = subtract(&(*CONSTANT_0),&(v319_4));
              drop(v319_4);
              let v319_8: Space = if (v319_5).is_empty() { Space::new() } else {
                let v320_6: Path = concat_path(&(v316_3_head),&(v318_6_head));
                let v320_7: Space = routine_49(c, &(v320_6), &(v318_6_tail));
                compose(&(v319_5),&(v320_7))
              };
              drop(v319_5);
              let v319_9: Space = intersect(&(*CONSTANT_9),&(v319_2));
              drop(v319_2);
              let v319_10: Space = if has_head(&(v319_9)) { singleton(&[]) } else { Space::new() };
              drop(v319_9);
              let v319_12: Space = if (v319_10).is_empty() { Space::new() } else {
                let v321_6: Path = concat_path(&(v316_3_head),&(v318_6_head));
                let v321_11: Space = routine_50(c, &(v321_6), &(v318_6_tail));
                drop(v321_6);
                compose(&(v319_10),&(v321_11))
              };
              drop(v319_10);
              let v319_13: Space = unite(&(v319_8),&(v319_12));
              v318_6.join_into((v319_13).clone());
            }
            drop(v318_6_cursor);
            compose(&(v317_5),&(v318_6))
          };
          drop(v317_5);
          let v317_8: Space = intersect(&(*CONSTANT_9),&(v317_2));
          drop(v317_2);
          let v317_9: Space = if has_head(&(v317_8)) { singleton(&[]) } else { Space::new() };
          drop(v317_8);
          let v317_11: Space = if (v317_9).is_empty() { Space::new() } else {
            let mut v322_10 = Space::new();
            let mut v322_10_cursor = (v316_3_tail).read_zipper();
            for v322_10_byte in v322_10_cursor.child_mask().iter() {
              v322_10_cursor.descend_to_byte(v322_10_byte);
              let v322_10_tail = v322_10_cursor.make_map();
              v322_10_cursor.ascend(1);
              let v322_10_head = Path::from_slice(&[v322_10_byte]);
              let v323_2: Space = singleton(&(v322_10_head));
              let v323_3: Space = intersect(&(*CONSTANT_9),&(v323_2));
              let v323_4: Space = if has_head(&(v323_3)) { singleton(&[]) } else { Space::new() };
              drop(v323_3);
              let v323_5: Space = subtract(&(*CONSTANT_0),&(v323_4));
              drop(v323_4);
              let v323_8: Space = if (v323_5).is_empty() { Space::new() } else {
                let v324_6: Path = concat_path(&(v316_3_head),&(v322_10_head));
                let v324_7: Space = routine_49(c, &(v324_6), &(v322_10_tail));
                compose(&(v323_5),&(v324_7))
              };
              drop(v323_5);
              let v323_9: Space = intersect(&(*CONSTANT_9),&(v323_2));
              drop(v323_2);
              let v323_10: Space = if has_head(&(v323_9)) { singleton(&[]) } else { Space::new() };
              drop(v323_9);
              let v323_12: Space = if (v323_10).is_empty() { Space::new() } else {
                let v325_6: Path = concat_path(&(v316_3_head),&(v322_10_head));
                let v325_11: Space = routine_51(c, &(v325_6), &(v322_10_tail));
                drop(v325_6);
                compose(&(v323_10),&(v325_11))
              };
              drop(v323_10);
              let v323_13: Space = unite(&(v323_8),&(v323_12));
              v322_10.join_into((v323_13).clone());
            }
            drop(v322_10_cursor);
            compose(&(v317_9),&(v322_10))
          };
          drop(v317_9);
          let v317_12: Space = unite(&(v317_7),&(v317_11));
          v316_3.join_into((v317_12).clone());
        }
        drop(v316_3_cursor);
        drop(v316_2);
        let v316_4: Space = unite(&(v316_3),&(v315_6));
        let v316_5: Space = intersect(&(v316_4),&(*capture_3));
        let v315_6_next = unite(&v315_6,&(v316_5));
        if equal(&v315_6_next,&v315_6) { break; }
        v315_6 = v315_6_next;
      }
      let v315_7: Space = subtract(&(*capture_3),&(v315_6));
      let mut v315_8: Space = (v273_5).clone();
      loop {
        let v326_1: Space = intersect(&(v315_8),&(*capture_3));
        let v326_2: Space = restrict_to(&(*capture_1),&(v326_1));
        drop(v326_1);
        let mut v326_3 = Space::new();
        let mut v326_3_cursor = (v326_2).read_zipper();
        for v326_3_byte in v326_3_cursor.child_mask().iter() {
          v326_3_cursor.descend_to_byte(v326_3_byte);
          let v326_3_tail = v326_3_cursor.make_map();
          v326_3_cursor.ascend(1);
          let v326_3_head = Path::from_slice(&[v326_3_byte]);
          let v327_2: Space = singleton(&(v326_3_head));
          let v327_3: Space = intersect(&(*CONSTANT_9),&(v327_2));
          let v327_4: Space = if has_head(&(v327_3)) { singleton(&[]) } else { Space::new() };
          drop(v327_3);
          let v327_5: Space = subtract(&(*CONSTANT_0),&(v327_4));
          drop(v327_4);
          let v327_7: Space = if (v327_5).is_empty() { Space::new() } else {
            let mut v328_6 = Space::new();
            let mut v328_6_cursor = (v326_3_tail).read_zipper();
            for v328_6_byte in v328_6_cursor.child_mask().iter() {
              v328_6_cursor.descend_to_byte(v328_6_byte);
              let v328_6_tail = v328_6_cursor.make_map();
              v328_6_cursor.ascend(1);
              let v328_6_head = Path::from_slice(&[v328_6_byte]);
              let v329_2: Space = singleton(&(v328_6_head));
              let v329_3: Space = intersect(&(*CONSTANT_9),&(v329_2));
              let v329_4: Space = if has_head(&(v329_3)) { singleton(&[]) } else { Space::new() };
              drop(v329_3);
              let v329_5: Space = subtract(&(*CONSTANT_0),&(v329_4));
              drop(v329_4);
              let v329_8: Space = if (v329_5).is_empty() { Space::new() } else {
                let v330_6: Path = concat_path(&(v326_3_head),&(v328_6_head));
                let v330_7: Space = routine_49(c, &(v330_6), &(v328_6_tail));
                compose(&(v329_5),&(v330_7))
              };
              drop(v329_5);
              let v329_9: Space = intersect(&(*CONSTANT_9),&(v329_2));
              drop(v329_2);
              let v329_10: Space = if has_head(&(v329_9)) { singleton(&[]) } else { Space::new() };
              drop(v329_9);
              let v329_12: Space = if (v329_10).is_empty() { Space::new() } else {
                let v331_6: Path = concat_path(&(v326_3_head),&(v328_6_head));
                let v331_11: Space = routine_50(c, &(v331_6), &(v328_6_tail));
                drop(v331_6);
                compose(&(v329_10),&(v331_11))
              };
              drop(v329_10);
              let v329_13: Space = unite(&(v329_8),&(v329_12));
              v328_6.join_into((v329_13).clone());
            }
            drop(v328_6_cursor);
            compose(&(v327_5),&(v328_6))
          };
          drop(v327_5);
          let v327_8: Space = intersect(&(*CONSTANT_9),&(v327_2));
          drop(v327_2);
          let v327_9: Space = if has_head(&(v327_8)) { singleton(&[]) } else { Space::new() };
          drop(v327_8);
          let v327_11: Space = if (v327_9).is_empty() { Space::new() } else {
            let mut v332_10 = Space::new();
            let mut v332_10_cursor = (v326_3_tail).read_zipper();
            for v332_10_byte in v332_10_cursor.child_mask().iter() {
              v332_10_cursor.descend_to_byte(v332_10_byte);
              let v332_10_tail = v332_10_cursor.make_map();
              v332_10_cursor.ascend(1);
              let v332_10_head = Path::from_slice(&[v332_10_byte]);
              let v333_2: Space = singleton(&(v332_10_head));
              let v333_3: Space = intersect(&(*CONSTANT_9),&(v333_2));
              let v333_4: Space = if has_head(&(v333_3)) { singleton(&[]) } else { Space::new() };
              drop(v333_3);
              let v333_5: Space = subtract(&(*CONSTANT_0),&(v333_4));
              drop(v333_4);
              let v333_8: Space = if (v333_5).is_empty() { Space::new() } else {
                let v334_6: Path = concat_path(&(v326_3_head),&(v332_10_head));
                let v334_7: Space = routine_49(c, &(v334_6), &(v332_10_tail));
                compose(&(v333_5),&(v334_7))
              };
              drop(v333_5);
              let v333_9: Space = intersect(&(*CONSTANT_9),&(v333_2));
              drop(v333_2);
              let v333_10: Space = if has_head(&(v333_9)) { singleton(&[]) } else { Space::new() };
              drop(v333_9);
              let v333_12: Space = if (v333_10).is_empty() { Space::new() } else {
                let v335_6: Path = concat_path(&(v326_3_head),&(v332_10_head));
                let v335_11: Space = routine_51(c, &(v335_6), &(v332_10_tail));
                drop(v335_6);
                compose(&(v333_10),&(v335_11))
              };
              drop(v333_10);
              let v333_13: Space = unite(&(v333_8),&(v333_12));
              v332_10.join_into((v333_13).clone());
            }
            drop(v332_10_cursor);
            compose(&(v327_9),&(v332_10))
          };
          drop(v327_9);
          let v327_12: Space = unite(&(v327_7),&(v327_11));
          v326_3.join_into((v327_12).clone());
        }
        drop(v326_3_cursor);
        drop(v326_2);
        let v326_4: Space = unite(&(v326_3),&(v315_8));
        let v326_5: Space = intersect(&(v326_4),&(*capture_3));
        let v315_8_next = unite(&v315_8,&(v326_5));
        if equal(&v315_8_next,&v315_8) { break; }
        v315_8 = v315_8_next;
      }
      let v315_9: Space = subtract(&(v315_7),&(v315_8));
      let v315_10: Space = routine_14(c, &(v273_91_head), &(v273_91_tail), &(*capture_1), &(*capture_2), &(v315_9));
      compose(&(v314_5),&(v315_10))
    };
    drop(v314_5);
    let v314_12: Space = intersect(&(*CONSTANT_9),&(v314_2));
    drop(v314_2);
    let v314_13: Space = if has_head(&(v314_12)) { singleton(&[]) } else { Space::new() };
    drop(v314_12);
    let v314_19: Space = if (v314_13).is_empty() { Space::new() } else {
      let mut v336_14: Space = (v273_5).clone();
      loop {
        let v337_1: Space = intersect(&(v336_14),&(*capture_3));
        let v337_2: Space = restrict_to(&(*capture_2),&(v337_1));
        drop(v337_1);
        let mut v337_3 = Space::new();
        let mut v337_3_cursor = (v337_2).read_zipper();
        for v337_3_byte in v337_3_cursor.child_mask().iter() {
          v337_3_cursor.descend_to_byte(v337_3_byte);
          let v337_3_tail = v337_3_cursor.make_map();
          v337_3_cursor.ascend(1);
          let v337_3_head = Path::from_slice(&[v337_3_byte]);
          let v338_2: Space = singleton(&(v337_3_head));
          let v338_3: Space = intersect(&(*CONSTANT_9),&(v338_2));
          let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
          drop(v338_3);
          let v338_5: Space = subtract(&(*CONSTANT_0),&(v338_4));
          drop(v338_4);
          let v338_7: Space = if (v338_5).is_empty() { Space::new() } else {
            let mut v339_6 = Space::new();
            let mut v339_6_cursor = (v337_3_tail).read_zipper();
            for v339_6_byte in v339_6_cursor.child_mask().iter() {
              v339_6_cursor.descend_to_byte(v339_6_byte);
              let v339_6_tail = v339_6_cursor.make_map();
              v339_6_cursor.ascend(1);
              let v339_6_head = Path::from_slice(&[v339_6_byte]);
              let v340_2: Space = singleton(&(v339_6_head));
              let v340_3: Space = intersect(&(*CONSTANT_9),&(v340_2));
              let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
              drop(v340_3);
              let v340_5: Space = subtract(&(*CONSTANT_0),&(v340_4));
              drop(v340_4);
              let v340_8: Space = if (v340_5).is_empty() { Space::new() } else {
                let v341_6: Path = concat_path(&(v337_3_head),&(v339_6_head));
                let v341_7: Space = routine_49(c, &(v341_6), &(v339_6_tail));
                compose(&(v340_5),&(v341_7))
              };
              drop(v340_5);
              let v340_9: Space = intersect(&(*CONSTANT_9),&(v340_2));
              drop(v340_2);
              let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
              drop(v340_9);
              let v340_12: Space = if (v340_10).is_empty() { Space::new() } else {
                let v342_6: Path = concat_path(&(v337_3_head),&(v339_6_head));
                let v342_11: Space = routine_50(c, &(v342_6), &(v339_6_tail));
                drop(v342_6);
                compose(&(v340_10),&(v342_11))
              };
              drop(v340_10);
              let v340_13: Space = unite(&(v340_8),&(v340_12));
              v339_6.join_into((v340_13).clone());
            }
            drop(v339_6_cursor);
            compose(&(v338_5),&(v339_6))
          };
          drop(v338_5);
          let v338_8: Space = intersect(&(*CONSTANT_9),&(v338_2));
          drop(v338_2);
          let v338_9: Space = if has_head(&(v338_8)) { singleton(&[]) } else { Space::new() };
          drop(v338_8);
          let v338_11: Space = if (v338_9).is_empty() { Space::new() } else {
            let mut v343_10 = Space::new();
            let mut v343_10_cursor = (v337_3_tail).read_zipper();
            for v343_10_byte in v343_10_cursor.child_mask().iter() {
              v343_10_cursor.descend_to_byte(v343_10_byte);
              let v343_10_tail = v343_10_cursor.make_map();
              v343_10_cursor.ascend(1);
              let v343_10_head = Path::from_slice(&[v343_10_byte]);
              let v344_2: Space = singleton(&(v343_10_head));
              let v344_3: Space = intersect(&(*CONSTANT_9),&(v344_2));
              let v344_4: Space = if has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
              drop(v344_3);
              let v344_5: Space = subtract(&(*CONSTANT_0),&(v344_4));
              drop(v344_4);
              let v344_8: Space = if (v344_5).is_empty() { Space::new() } else {
                let v345_6: Path = concat_path(&(v337_3_head),&(v343_10_head));
                let v345_7: Space = routine_49(c, &(v345_6), &(v343_10_tail));
                compose(&(v344_5),&(v345_7))
              };
              drop(v344_5);
              let v344_9: Space = intersect(&(*CONSTANT_9),&(v344_2));
              drop(v344_2);
              let v344_10: Space = if has_head(&(v344_9)) { singleton(&[]) } else { Space::new() };
              drop(v344_9);
              let v344_12: Space = if (v344_10).is_empty() { Space::new() } else {
                let v346_6: Path = concat_path(&(v337_3_head),&(v343_10_head));
                let v346_11: Space = routine_51(c, &(v346_6), &(v343_10_tail));
                drop(v346_6);
                compose(&(v344_10),&(v346_11))
              };
              drop(v344_10);
              let v344_13: Space = unite(&(v344_8),&(v344_12));
              v343_10.join_into((v344_13).clone());
            }
            drop(v343_10_cursor);
            compose(&(v338_9),&(v343_10))
          };
          drop(v338_9);
          let v338_12: Space = unite(&(v338_7),&(v338_11));
          v337_3.join_into((v338_12).clone());
        }
        drop(v337_3_cursor);
        drop(v337_2);
        let v337_4: Space = unite(&(v337_3),&(v336_14));
        let v337_5: Space = intersect(&(v337_4),&(*capture_3));
        let v336_14_next = unite(&v336_14,&(v337_5));
        if equal(&v336_14_next,&v336_14) { break; }
        v336_14 = v336_14_next;
      }
      let v336_15: Space = subtract(&(*capture_3),&(v336_14));
      let mut v336_16: Space = (v273_5).clone();
      loop {
        let v347_1: Space = intersect(&(v336_16),&(*capture_3));
        let v347_2: Space = restrict_to(&(*capture_1),&(v347_1));
        drop(v347_1);
        let mut v347_3 = Space::new();
        let mut v347_3_cursor = (v347_2).read_zipper();
        for v347_3_byte in v347_3_cursor.child_mask().iter() {
          v347_3_cursor.descend_to_byte(v347_3_byte);
          let v347_3_tail = v347_3_cursor.make_map();
          v347_3_cursor.ascend(1);
          let v347_3_head = Path::from_slice(&[v347_3_byte]);
          let v348_2: Space = singleton(&(v347_3_head));
          let v348_3: Space = intersect(&(*CONSTANT_9),&(v348_2));
          let v348_4: Space = if has_head(&(v348_3)) { singleton(&[]) } else { Space::new() };
          drop(v348_3);
          let v348_5: Space = subtract(&(*CONSTANT_0),&(v348_4));
          drop(v348_4);
          let v348_7: Space = if (v348_5).is_empty() { Space::new() } else {
            let mut v349_6 = Space::new();
            let mut v349_6_cursor = (v347_3_tail).read_zipper();
            for v349_6_byte in v349_6_cursor.child_mask().iter() {
              v349_6_cursor.descend_to_byte(v349_6_byte);
              let v349_6_tail = v349_6_cursor.make_map();
              v349_6_cursor.ascend(1);
              let v349_6_head = Path::from_slice(&[v349_6_byte]);
              let v350_2: Space = singleton(&(v349_6_head));
              let v350_3: Space = intersect(&(*CONSTANT_9),&(v350_2));
              let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
              drop(v350_3);
              let v350_5: Space = subtract(&(*CONSTANT_0),&(v350_4));
              drop(v350_4);
              let v350_8: Space = if (v350_5).is_empty() { Space::new() } else {
                let v351_6: Path = concat_path(&(v347_3_head),&(v349_6_head));
                let v351_7: Space = routine_49(c, &(v351_6), &(v349_6_tail));
                compose(&(v350_5),&(v351_7))
              };
              drop(v350_5);
              let v350_9: Space = intersect(&(*CONSTANT_9),&(v350_2));
              drop(v350_2);
              let v350_10: Space = if has_head(&(v350_9)) { singleton(&[]) } else { Space::new() };
              drop(v350_9);
              let v350_12: Space = if (v350_10).is_empty() { Space::new() } else {
                let v352_6: Path = concat_path(&(v347_3_head),&(v349_6_head));
                let v352_11: Space = routine_50(c, &(v352_6), &(v349_6_tail));
                drop(v352_6);
                compose(&(v350_10),&(v352_11))
              };
              drop(v350_10);
              let v350_13: Space = unite(&(v350_8),&(v350_12));
              v349_6.join_into((v350_13).clone());
            }
            drop(v349_6_cursor);
            compose(&(v348_5),&(v349_6))
          };
          drop(v348_5);
          let v348_8: Space = intersect(&(*CONSTANT_9),&(v348_2));
          drop(v348_2);
          let v348_9: Space = if has_head(&(v348_8)) { singleton(&[]) } else { Space::new() };
          drop(v348_8);
          let v348_11: Space = if (v348_9).is_empty() { Space::new() } else {
            let mut v353_10 = Space::new();
            let mut v353_10_cursor = (v347_3_tail).read_zipper();
            for v353_10_byte in v353_10_cursor.child_mask().iter() {
              v353_10_cursor.descend_to_byte(v353_10_byte);
              let v353_10_tail = v353_10_cursor.make_map();
              v353_10_cursor.ascend(1);
              let v353_10_head = Path::from_slice(&[v353_10_byte]);
              let v354_2: Space = singleton(&(v353_10_head));
              let v354_3: Space = intersect(&(*CONSTANT_9),&(v354_2));
              let v354_4: Space = if has_head(&(v354_3)) { singleton(&[]) } else { Space::new() };
              drop(v354_3);
              let v354_5: Space = subtract(&(*CONSTANT_0),&(v354_4));
              drop(v354_4);
              let v354_8: Space = if (v354_5).is_empty() { Space::new() } else {
                let v355_6: Path = concat_path(&(v347_3_head),&(v353_10_head));
                let v355_7: Space = routine_49(c, &(v355_6), &(v353_10_tail));
                compose(&(v354_5),&(v355_7))
              };
              drop(v354_5);
              let v354_9: Space = intersect(&(*CONSTANT_9),&(v354_2));
              drop(v354_2);
              let v354_10: Space = if has_head(&(v354_9)) { singleton(&[]) } else { Space::new() };
              drop(v354_9);
              let v354_12: Space = if (v354_10).is_empty() { Space::new() } else {
                let v356_6: Path = concat_path(&(v347_3_head),&(v353_10_head));
                let v356_11: Space = routine_51(c, &(v356_6), &(v353_10_tail));
                drop(v356_6);
                compose(&(v354_10),&(v356_11))
              };
              drop(v354_10);
              let v354_13: Space = unite(&(v354_8),&(v354_12));
              v353_10.join_into((v354_13).clone());
            }
            drop(v353_10_cursor);
            compose(&(v348_9),&(v353_10))
          };
          drop(v348_9);
          let v348_12: Space = unite(&(v348_7),&(v348_11));
          v347_3.join_into((v348_12).clone());
        }
        drop(v347_3_cursor);
        drop(v347_2);
        let v347_4: Space = unite(&(v347_3),&(v336_16));
        let v347_5: Space = intersect(&(v347_4),&(*capture_3));
        let v336_16_next = unite(&v336_16,&(v347_5));
        if equal(&v336_16_next,&v336_16) { break; }
        v336_16 = v336_16_next;
      }
      let v336_17: Space = subtract(&(v336_15),&(v336_16));
      let v336_18: Space = routine_15(c, &(v273_91_head), &(v273_91_tail), &(*capture_1), &(*capture_2), &(v336_17));
      compose(&(v314_13),&(v336_18))
    };
    drop(v314_13);
    let v314_20: Space = unite(&(v314_11),&(v314_19));
    v273_91.join_into((v314_20).clone());
  }
  drop(v273_91_cursor);

((v273_15).clone(),(v273_25).clone(),(v273_26).clone(),(v273_27).clone(),(v273_28).clone(),(v273_38).clone(),(v273_39).clone(),(v273_49).clone(),(v273_5).clone(),(v273_50).clone(),(v273_51).clone(),(v273_91).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &Space,capture_1: &Space,capture_2: &Space,capture_3: &Space,capture_4: &Space,capture_5: &Space) -> (Space,Space,Space,Space,Space,Space,) {
  let v273_92: Space = unite(&((*capture_3)),&((*capture_5)));
  let mut v273_102: Space = ((*capture_4)).clone();
  loop {
    let v357_1: Space = intersect(&(v273_102),&(*capture_2));
    let v357_2: Space = restrict_to(&(*capture_1),&(v357_1));
    drop(v357_1);
    let mut v357_3 = Space::new();
    let mut v357_3_cursor = (v357_2).read_zipper();
    for v357_3_byte in v357_3_cursor.child_mask().iter() {
      v357_3_cursor.descend_to_byte(v357_3_byte);
      let v357_3_tail = v357_3_cursor.make_map();
      v357_3_cursor.ascend(1);
      let v357_3_head = Path::from_slice(&[v357_3_byte]);
      let v358_2: Space = singleton(&(v357_3_head));
      let v358_3: Space = intersect(&(*CONSTANT_9),&(v358_2));
      let v358_4: Space = if has_head(&(v358_3)) { singleton(&[]) } else { Space::new() };
      drop(v358_3);
      let v358_5: Space = subtract(&(*CONSTANT_0),&(v358_4));
      drop(v358_4);
      let v358_7: Space = if (v358_5).is_empty() { Space::new() } else {
        let mut v359_6 = Space::new();
        let mut v359_6_cursor = (v357_3_tail).read_zipper();
        for v359_6_byte in v359_6_cursor.child_mask().iter() {
          v359_6_cursor.descend_to_byte(v359_6_byte);
          let v359_6_tail = v359_6_cursor.make_map();
          v359_6_cursor.ascend(1);
          let v359_6_head = Path::from_slice(&[v359_6_byte]);
          let v360_2: Space = singleton(&(v359_6_head));
          let v360_3: Space = intersect(&(*CONSTANT_9),&(v360_2));
          let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
          drop(v360_3);
          let v360_5: Space = subtract(&(*CONSTANT_0),&(v360_4));
          drop(v360_4);
          let v360_8: Space = if (v360_5).is_empty() { Space::new() } else {
            let v361_6: Path = concat_path(&(v357_3_head),&(v359_6_head));
            let v361_7: Space = routine_49(c, &(v361_6), &(v359_6_tail));
            compose(&(v360_5),&(v361_7))
          };
          drop(v360_5);
          let v360_9: Space = intersect(&(*CONSTANT_9),&(v360_2));
          drop(v360_2);
          let v360_10: Space = if has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
          drop(v360_9);
          let v360_12: Space = if (v360_10).is_empty() { Space::new() } else {
            let v362_6: Path = concat_path(&(v357_3_head),&(v359_6_head));
            let v362_11: Space = routine_50(c, &(v362_6), &(v359_6_tail));
            drop(v362_6);
            compose(&(v360_10),&(v362_11))
          };
          drop(v360_10);
          let v360_13: Space = unite(&(v360_8),&(v360_12));
          v359_6.join_into((v360_13).clone());
        }
        drop(v359_6_cursor);
        compose(&(v358_5),&(v359_6))
      };
      drop(v358_5);
      let v358_8: Space = intersect(&(*CONSTANT_9),&(v358_2));
      drop(v358_2);
      let v358_9: Space = if has_head(&(v358_8)) { singleton(&[]) } else { Space::new() };
      drop(v358_8);
      let v358_11: Space = if (v358_9).is_empty() { Space::new() } else {
        let mut v363_10 = Space::new();
        let mut v363_10_cursor = (v357_3_tail).read_zipper();
        for v363_10_byte in v363_10_cursor.child_mask().iter() {
          v363_10_cursor.descend_to_byte(v363_10_byte);
          let v363_10_tail = v363_10_cursor.make_map();
          v363_10_cursor.ascend(1);
          let v363_10_head = Path::from_slice(&[v363_10_byte]);
          let v364_2: Space = singleton(&(v363_10_head));
          let v364_3: Space = intersect(&(*CONSTANT_9),&(v364_2));
          let v364_4: Space = if has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
          drop(v364_3);
          let v364_5: Space = subtract(&(*CONSTANT_0),&(v364_4));
          drop(v364_4);
          let v364_8: Space = if (v364_5).is_empty() { Space::new() } else {
            let v365_6: Path = concat_path(&(v357_3_head),&(v363_10_head));
            let v365_7: Space = routine_49(c, &(v365_6), &(v363_10_tail));
            compose(&(v364_5),&(v365_7))
          };
          drop(v364_5);
          let v364_9: Space = intersect(&(*CONSTANT_9),&(v364_2));
          drop(v364_2);
          let v364_10: Space = if has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
          drop(v364_9);
          let v364_12: Space = if (v364_10).is_empty() { Space::new() } else {
            let v366_6: Path = concat_path(&(v357_3_head),&(v363_10_head));
            let v366_11: Space = routine_51(c, &(v366_6), &(v363_10_tail));
            drop(v366_6);
            compose(&(v364_10),&(v366_11))
          };
          drop(v364_10);
          let v364_13: Space = unite(&(v364_8),&(v364_12));
          v363_10.join_into((v364_13).clone());
        }
        drop(v363_10_cursor);
        compose(&(v358_9),&(v363_10))
      };
      drop(v358_9);
      let v358_12: Space = unite(&(v358_7),&(v358_11));
      v357_3.join_into((v358_12).clone());
    }
    drop(v357_3_cursor);
    drop(v357_2);
    let v357_4: Space = unite(&(v357_3),&(v273_102));
    let v357_5: Space = intersect(&(v357_4),&(*capture_2));
    let v273_102_next = unite(&v273_102,&(v357_5));
    if equal(&v273_102_next,&v273_102) { break; }
    v273_102 = v273_102_next;
  }
  let mut v273_112: Space = ((*capture_4)).clone();
  loop {
    let v367_1: Space = intersect(&(v273_112),&(*capture_2));
    let v367_2: Space = restrict_to(&(*capture_0),&(v367_1));
    drop(v367_1);
    let mut v367_3 = Space::new();
    let mut v367_3_cursor = (v367_2).read_zipper();
    for v367_3_byte in v367_3_cursor.child_mask().iter() {
      v367_3_cursor.descend_to_byte(v367_3_byte);
      let v367_3_tail = v367_3_cursor.make_map();
      v367_3_cursor.ascend(1);
      let v367_3_head = Path::from_slice(&[v367_3_byte]);
      let v368_2: Space = singleton(&(v367_3_head));
      let v368_3: Space = intersect(&(*CONSTANT_9),&(v368_2));
      let v368_4: Space = if has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
      drop(v368_3);
      let v368_5: Space = subtract(&(*CONSTANT_0),&(v368_4));
      drop(v368_4);
      let v368_7: Space = if (v368_5).is_empty() { Space::new() } else {
        let mut v369_6 = Space::new();
        let mut v369_6_cursor = (v367_3_tail).read_zipper();
        for v369_6_byte in v369_6_cursor.child_mask().iter() {
          v369_6_cursor.descend_to_byte(v369_6_byte);
          let v369_6_tail = v369_6_cursor.make_map();
          v369_6_cursor.ascend(1);
          let v369_6_head = Path::from_slice(&[v369_6_byte]);
          let v370_2: Space = singleton(&(v369_6_head));
          let v370_3: Space = intersect(&(*CONSTANT_9),&(v370_2));
          let v370_4: Space = if has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
          drop(v370_3);
          let v370_5: Space = subtract(&(*CONSTANT_0),&(v370_4));
          drop(v370_4);
          let v370_8: Space = if (v370_5).is_empty() { Space::new() } else {
            let v371_6: Path = concat_path(&(v367_3_head),&(v369_6_head));
            let v371_7: Space = routine_49(c, &(v371_6), &(v369_6_tail));
            compose(&(v370_5),&(v371_7))
          };
          drop(v370_5);
          let v370_9: Space = intersect(&(*CONSTANT_9),&(v370_2));
          drop(v370_2);
          let v370_10: Space = if has_head(&(v370_9)) { singleton(&[]) } else { Space::new() };
          drop(v370_9);
          let v370_12: Space = if (v370_10).is_empty() { Space::new() } else {
            let v372_6: Path = concat_path(&(v367_3_head),&(v369_6_head));
            let v372_11: Space = routine_50(c, &(v372_6), &(v369_6_tail));
            drop(v372_6);
            compose(&(v370_10),&(v372_11))
          };
          drop(v370_10);
          let v370_13: Space = unite(&(v370_8),&(v370_12));
          v369_6.join_into((v370_13).clone());
        }
        drop(v369_6_cursor);
        compose(&(v368_5),&(v369_6))
      };
      drop(v368_5);
      let v368_8: Space = intersect(&(*CONSTANT_9),&(v368_2));
      drop(v368_2);
      let v368_9: Space = if has_head(&(v368_8)) { singleton(&[]) } else { Space::new() };
      drop(v368_8);
      let v368_11: Space = if (v368_9).is_empty() { Space::new() } else {
        let mut v373_10 = Space::new();
        let mut v373_10_cursor = (v367_3_tail).read_zipper();
        for v373_10_byte in v373_10_cursor.child_mask().iter() {
          v373_10_cursor.descend_to_byte(v373_10_byte);
          let v373_10_tail = v373_10_cursor.make_map();
          v373_10_cursor.ascend(1);
          let v373_10_head = Path::from_slice(&[v373_10_byte]);
          let v374_2: Space = singleton(&(v373_10_head));
          let v374_3: Space = intersect(&(*CONSTANT_9),&(v374_2));
          let v374_4: Space = if has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
          drop(v374_3);
          let v374_5: Space = subtract(&(*CONSTANT_0),&(v374_4));
          drop(v374_4);
          let v374_8: Space = if (v374_5).is_empty() { Space::new() } else {
            let v375_6: Path = concat_path(&(v367_3_head),&(v373_10_head));
            let v375_7: Space = routine_49(c, &(v375_6), &(v373_10_tail));
            compose(&(v374_5),&(v375_7))
          };
          drop(v374_5);
          let v374_9: Space = intersect(&(*CONSTANT_9),&(v374_2));
          drop(v374_2);
          let v374_10: Space = if has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
          drop(v374_9);
          let v374_12: Space = if (v374_10).is_empty() { Space::new() } else {
            let v376_6: Path = concat_path(&(v367_3_head),&(v373_10_head));
            let v376_11: Space = routine_51(c, &(v376_6), &(v373_10_tail));
            drop(v376_6);
            compose(&(v374_10),&(v376_11))
          };
          drop(v374_10);
          let v374_13: Space = unite(&(v374_8),&(v374_12));
          v373_10.join_into((v374_13).clone());
        }
        drop(v373_10_cursor);
        compose(&(v368_9),&(v373_10))
      };
      drop(v368_9);
      let v368_12: Space = unite(&(v368_7),&(v368_11));
      v367_3.join_into((v368_12).clone());
    }
    drop(v367_3_cursor);
    drop(v367_2);
    let v367_4: Space = unite(&(v367_3),&(v273_112));
    let v367_5: Space = intersect(&(v367_4),&(*capture_2));
    let v273_112_next = unite(&v273_112,&(v367_5));
    if equal(&v273_112_next,&v273_112) { break; }
    v273_112 = v273_112_next;
  }
  let v273_113: Space = subtract(&(v273_102),&(v273_112));
  let v273_114: Space = routine_10(c, &(v273_113));
  let mut v273_154 = Space::new();
  let mut v273_154_cursor = (v273_114).read_zipper();
  for v273_154_byte in v273_154_cursor.child_mask().iter() {
    v273_154_cursor.descend_to_byte(v273_154_byte);
    let v273_154_tail = v273_154_cursor.make_map();
    v273_154_cursor.ascend(1);
    let v273_154_head = Path::from_slice(&[v273_154_byte]);
    let v377_2: Space = singleton(&(v273_154_head));
    let v377_3: Space = intersect(&(*CONSTANT_9),&(v377_2));
    let v377_4: Space = if has_head(&(v377_3)) { singleton(&[]) } else { Space::new() };
    drop(v377_3);
    let v377_5: Space = subtract(&(*CONSTANT_0),&(v377_4));
    drop(v377_4);
    let v377_10: Space = if (v377_5).is_empty() { Space::new() } else {
      let mut v378_6: Space = ((*capture_4)).clone();
      loop {
        let v379_1: Space = intersect(&(v378_6),&(*capture_2));
        let v379_2: Space = restrict_to(&(*capture_1),&(v379_1));
        drop(v379_1);
        let mut v379_3 = Space::new();
        let mut v379_3_cursor = (v379_2).read_zipper();
        for v379_3_byte in v379_3_cursor.child_mask().iter() {
          v379_3_cursor.descend_to_byte(v379_3_byte);
          let v379_3_tail = v379_3_cursor.make_map();
          v379_3_cursor.ascend(1);
          let v379_3_head = Path::from_slice(&[v379_3_byte]);
          let v380_2: Space = singleton(&(v379_3_head));
          let v380_3: Space = intersect(&(*CONSTANT_9),&(v380_2));
          let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
          drop(v380_3);
          let v380_5: Space = subtract(&(*CONSTANT_0),&(v380_4));
          drop(v380_4);
          let v380_7: Space = if (v380_5).is_empty() { Space::new() } else {
            let mut v381_6 = Space::new();
            let mut v381_6_cursor = (v379_3_tail).read_zipper();
            for v381_6_byte in v381_6_cursor.child_mask().iter() {
              v381_6_cursor.descend_to_byte(v381_6_byte);
              let v381_6_tail = v381_6_cursor.make_map();
              v381_6_cursor.ascend(1);
              let v381_6_head = Path::from_slice(&[v381_6_byte]);
              let v382_2: Space = singleton(&(v381_6_head));
              let v382_3: Space = intersect(&(*CONSTANT_9),&(v382_2));
              let v382_4: Space = if has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
              drop(v382_3);
              let v382_5: Space = subtract(&(*CONSTANT_0),&(v382_4));
              drop(v382_4);
              let v382_8: Space = if (v382_5).is_empty() { Space::new() } else {
                let v383_6: Path = concat_path(&(v379_3_head),&(v381_6_head));
                let v383_7: Space = routine_49(c, &(v383_6), &(v381_6_tail));
                compose(&(v382_5),&(v383_7))
              };
              drop(v382_5);
              let v382_9: Space = intersect(&(*CONSTANT_9),&(v382_2));
              drop(v382_2);
              let v382_10: Space = if has_head(&(v382_9)) { singleton(&[]) } else { Space::new() };
              drop(v382_9);
              let v382_12: Space = if (v382_10).is_empty() { Space::new() } else {
                let v384_6: Path = concat_path(&(v379_3_head),&(v381_6_head));
                let v384_11: Space = routine_50(c, &(v384_6), &(v381_6_tail));
                drop(v384_6);
                compose(&(v382_10),&(v384_11))
              };
              drop(v382_10);
              let v382_13: Space = unite(&(v382_8),&(v382_12));
              v381_6.join_into((v382_13).clone());
            }
            drop(v381_6_cursor);
            compose(&(v380_5),&(v381_6))
          };
          drop(v380_5);
          let v380_8: Space = intersect(&(*CONSTANT_9),&(v380_2));
          drop(v380_2);
          let v380_9: Space = if has_head(&(v380_8)) { singleton(&[]) } else { Space::new() };
          drop(v380_8);
          let v380_11: Space = if (v380_9).is_empty() { Space::new() } else {
            let mut v385_10 = Space::new();
            let mut v385_10_cursor = (v379_3_tail).read_zipper();
            for v385_10_byte in v385_10_cursor.child_mask().iter() {
              v385_10_cursor.descend_to_byte(v385_10_byte);
              let v385_10_tail = v385_10_cursor.make_map();
              v385_10_cursor.ascend(1);
              let v385_10_head = Path::from_slice(&[v385_10_byte]);
              let v386_2: Space = singleton(&(v385_10_head));
              let v386_3: Space = intersect(&(*CONSTANT_9),&(v386_2));
              let v386_4: Space = if has_head(&(v386_3)) { singleton(&[]) } else { Space::new() };
              drop(v386_3);
              let v386_5: Space = subtract(&(*CONSTANT_0),&(v386_4));
              drop(v386_4);
              let v386_8: Space = if (v386_5).is_empty() { Space::new() } else {
                let v387_6: Path = concat_path(&(v379_3_head),&(v385_10_head));
                let v387_7: Space = routine_49(c, &(v387_6), &(v385_10_tail));
                compose(&(v386_5),&(v387_7))
              };
              drop(v386_5);
              let v386_9: Space = intersect(&(*CONSTANT_9),&(v386_2));
              drop(v386_2);
              let v386_10: Space = if has_head(&(v386_9)) { singleton(&[]) } else { Space::new() };
              drop(v386_9);
              let v386_12: Space = if (v386_10).is_empty() { Space::new() } else {
                let v388_6: Path = concat_path(&(v379_3_head),&(v385_10_head));
                let v388_11: Space = routine_51(c, &(v388_6), &(v385_10_tail));
                drop(v388_6);
                compose(&(v386_10),&(v388_11))
              };
              drop(v386_10);
              let v386_13: Space = unite(&(v386_8),&(v386_12));
              v385_10.join_into((v386_13).clone());
            }
            drop(v385_10_cursor);
            compose(&(v380_9),&(v385_10))
          };
          drop(v380_9);
          let v380_12: Space = unite(&(v380_7),&(v380_11));
          v379_3.join_into((v380_12).clone());
        }
        drop(v379_3_cursor);
        drop(v379_2);
        let v379_4: Space = unite(&(v379_3),&(v378_6));
        let v379_5: Space = intersect(&(v379_4),&(*capture_2));
        let v378_6_next = unite(&v378_6,&(v379_5));
        if equal(&v378_6_next,&v378_6) { break; }
        v378_6 = v378_6_next;
      }
      let mut v378_7: Space = ((*capture_4)).clone();
      loop {
        let v389_1: Space = intersect(&(v378_7),&(*capture_2));
        let v389_2: Space = restrict_to(&(*capture_0),&(v389_1));
        drop(v389_1);
        let mut v389_3 = Space::new();
        let mut v389_3_cursor = (v389_2).read_zipper();
        for v389_3_byte in v389_3_cursor.child_mask().iter() {
          v389_3_cursor.descend_to_byte(v389_3_byte);
          let v389_3_tail = v389_3_cursor.make_map();
          v389_3_cursor.ascend(1);
          let v389_3_head = Path::from_slice(&[v389_3_byte]);
          let v390_2: Space = singleton(&(v389_3_head));
          let v390_3: Space = intersect(&(*CONSTANT_9),&(v390_2));
          let v390_4: Space = if has_head(&(v390_3)) { singleton(&[]) } else { Space::new() };
          drop(v390_3);
          let v390_5: Space = subtract(&(*CONSTANT_0),&(v390_4));
          drop(v390_4);
          let v390_7: Space = if (v390_5).is_empty() { Space::new() } else {
            let mut v391_6 = Space::new();
            let mut v391_6_cursor = (v389_3_tail).read_zipper();
            for v391_6_byte in v391_6_cursor.child_mask().iter() {
              v391_6_cursor.descend_to_byte(v391_6_byte);
              let v391_6_tail = v391_6_cursor.make_map();
              v391_6_cursor.ascend(1);
              let v391_6_head = Path::from_slice(&[v391_6_byte]);
              let v392_2: Space = singleton(&(v391_6_head));
              let v392_3: Space = intersect(&(*CONSTANT_9),&(v392_2));
              let v392_4: Space = if has_head(&(v392_3)) { singleton(&[]) } else { Space::new() };
              drop(v392_3);
              let v392_5: Space = subtract(&(*CONSTANT_0),&(v392_4));
              drop(v392_4);
              let v392_8: Space = if (v392_5).is_empty() { Space::new() } else {
                let v393_6: Path = concat_path(&(v389_3_head),&(v391_6_head));
                let v393_7: Space = routine_49(c, &(v393_6), &(v391_6_tail));
                compose(&(v392_5),&(v393_7))
              };
              drop(v392_5);
              let v392_9: Space = intersect(&(*CONSTANT_9),&(v392_2));
              drop(v392_2);
              let v392_10: Space = if has_head(&(v392_9)) { singleton(&[]) } else { Space::new() };
              drop(v392_9);
              let v392_12: Space = if (v392_10).is_empty() { Space::new() } else {
                let v394_6: Path = concat_path(&(v389_3_head),&(v391_6_head));
                let v394_11: Space = routine_50(c, &(v394_6), &(v391_6_tail));
                drop(v394_6);
                compose(&(v392_10),&(v394_11))
              };
              drop(v392_10);
              let v392_13: Space = unite(&(v392_8),&(v392_12));
              v391_6.join_into((v392_13).clone());
            }
            drop(v391_6_cursor);
            compose(&(v390_5),&(v391_6))
          };
          drop(v390_5);
          let v390_8: Space = intersect(&(*CONSTANT_9),&(v390_2));
          drop(v390_2);
          let v390_9: Space = if has_head(&(v390_8)) { singleton(&[]) } else { Space::new() };
          drop(v390_8);
          let v390_11: Space = if (v390_9).is_empty() { Space::new() } else {
            let mut v395_10 = Space::new();
            let mut v395_10_cursor = (v389_3_tail).read_zipper();
            for v395_10_byte in v395_10_cursor.child_mask().iter() {
              v395_10_cursor.descend_to_byte(v395_10_byte);
              let v395_10_tail = v395_10_cursor.make_map();
              v395_10_cursor.ascend(1);
              let v395_10_head = Path::from_slice(&[v395_10_byte]);
              let v396_2: Space = singleton(&(v395_10_head));
              let v396_3: Space = intersect(&(*CONSTANT_9),&(v396_2));
              let v396_4: Space = if has_head(&(v396_3)) { singleton(&[]) } else { Space::new() };
              drop(v396_3);
              let v396_5: Space = subtract(&(*CONSTANT_0),&(v396_4));
              drop(v396_4);
              let v396_8: Space = if (v396_5).is_empty() { Space::new() } else {
                let v397_6: Path = concat_path(&(v389_3_head),&(v395_10_head));
                let v397_7: Space = routine_49(c, &(v397_6), &(v395_10_tail));
                compose(&(v396_5),&(v397_7))
              };
              drop(v396_5);
              let v396_9: Space = intersect(&(*CONSTANT_9),&(v396_2));
              drop(v396_2);
              let v396_10: Space = if has_head(&(v396_9)) { singleton(&[]) } else { Space::new() };
              drop(v396_9);
              let v396_12: Space = if (v396_10).is_empty() { Space::new() } else {
                let v398_6: Path = concat_path(&(v389_3_head),&(v395_10_head));
                let v398_11: Space = routine_51(c, &(v398_6), &(v395_10_tail));
                drop(v398_6);
                compose(&(v396_10),&(v398_11))
              };
              drop(v396_10);
              let v396_13: Space = unite(&(v396_8),&(v396_12));
              v395_10.join_into((v396_13).clone());
            }
            drop(v395_10_cursor);
            compose(&(v390_9),&(v395_10))
          };
          drop(v390_9);
          let v390_12: Space = unite(&(v390_7),&(v390_11));
          v389_3.join_into((v390_12).clone());
        }
        drop(v389_3_cursor);
        drop(v389_2);
        let v389_4: Space = unite(&(v389_3),&(v378_7));
        let v389_5: Space = intersect(&(v389_4),&(*capture_2));
        let v378_7_next = unite(&v378_7,&(v389_5));
        if equal(&v378_7_next,&v378_7) { break; }
        v378_7 = v378_7_next;
      }
      let v378_8: Space = subtract(&(v378_6),&(v378_7));
      let v378_9: Space = routine_14(c, &(v273_154_head), &(v273_154_tail), &(*capture_0), &(*capture_1), &(v378_8));
      compose(&(v377_5),&(v378_9))
    };
    drop(v377_5);
    let v377_11: Space = intersect(&(*CONSTANT_9),&(v377_2));
    drop(v377_2);
    let v377_12: Space = if has_head(&(v377_11)) { singleton(&[]) } else { Space::new() };
    drop(v377_11);
    let v377_17: Space = if (v377_12).is_empty() { Space::new() } else {
      let mut v399_13: Space = ((*capture_4)).clone();
      loop {
        let v400_1: Space = intersect(&(v399_13),&(*capture_2));
        let v400_2: Space = restrict_to(&(*capture_1),&(v400_1));
        drop(v400_1);
        let mut v400_3 = Space::new();
        let mut v400_3_cursor = (v400_2).read_zipper();
        for v400_3_byte in v400_3_cursor.child_mask().iter() {
          v400_3_cursor.descend_to_byte(v400_3_byte);
          let v400_3_tail = v400_3_cursor.make_map();
          v400_3_cursor.ascend(1);
          let v400_3_head = Path::from_slice(&[v400_3_byte]);
          let v401_2: Space = singleton(&(v400_3_head));
          let v401_3: Space = intersect(&(*CONSTANT_9),&(v401_2));
          let v401_4: Space = if has_head(&(v401_3)) { singleton(&[]) } else { Space::new() };
          drop(v401_3);
          let v401_5: Space = subtract(&(*CONSTANT_0),&(v401_4));
          drop(v401_4);
          let v401_7: Space = if (v401_5).is_empty() { Space::new() } else {
            let mut v402_6 = Space::new();
            let mut v402_6_cursor = (v400_3_tail).read_zipper();
            for v402_6_byte in v402_6_cursor.child_mask().iter() {
              v402_6_cursor.descend_to_byte(v402_6_byte);
              let v402_6_tail = v402_6_cursor.make_map();
              v402_6_cursor.ascend(1);
              let v402_6_head = Path::from_slice(&[v402_6_byte]);
              let v403_2: Space = singleton(&(v402_6_head));
              let v403_3: Space = intersect(&(*CONSTANT_9),&(v403_2));
              let v403_4: Space = if has_head(&(v403_3)) { singleton(&[]) } else { Space::new() };
              drop(v403_3);
              let v403_5: Space = subtract(&(*CONSTANT_0),&(v403_4));
              drop(v403_4);
              let v403_8: Space = if (v403_5).is_empty() { Space::new() } else {
                let v404_6: Path = concat_path(&(v400_3_head),&(v402_6_head));
                let v404_7: Space = routine_49(c, &(v404_6), &(v402_6_tail));
                compose(&(v403_5),&(v404_7))
              };
              drop(v403_5);
              let v403_9: Space = intersect(&(*CONSTANT_9),&(v403_2));
              drop(v403_2);
              let v403_10: Space = if has_head(&(v403_9)) { singleton(&[]) } else { Space::new() };
              drop(v403_9);
              let v403_12: Space = if (v403_10).is_empty() { Space::new() } else {
                let v405_6: Path = concat_path(&(v400_3_head),&(v402_6_head));
                let v405_11: Space = routine_50(c, &(v405_6), &(v402_6_tail));
                drop(v405_6);
                compose(&(v403_10),&(v405_11))
              };
              drop(v403_10);
              let v403_13: Space = unite(&(v403_8),&(v403_12));
              v402_6.join_into((v403_13).clone());
            }
            drop(v402_6_cursor);
            compose(&(v401_5),&(v402_6))
          };
          drop(v401_5);
          let v401_8: Space = intersect(&(*CONSTANT_9),&(v401_2));
          drop(v401_2);
          let v401_9: Space = if has_head(&(v401_8)) { singleton(&[]) } else { Space::new() };
          drop(v401_8);
          let v401_11: Space = if (v401_9).is_empty() { Space::new() } else {
            let mut v406_10 = Space::new();
            let mut v406_10_cursor = (v400_3_tail).read_zipper();
            for v406_10_byte in v406_10_cursor.child_mask().iter() {
              v406_10_cursor.descend_to_byte(v406_10_byte);
              let v406_10_tail = v406_10_cursor.make_map();
              v406_10_cursor.ascend(1);
              let v406_10_head = Path::from_slice(&[v406_10_byte]);
              let v407_2: Space = singleton(&(v406_10_head));
              let v407_3: Space = intersect(&(*CONSTANT_9),&(v407_2));
              let v407_4: Space = if has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
              drop(v407_3);
              let v407_5: Space = subtract(&(*CONSTANT_0),&(v407_4));
              drop(v407_4);
              let v407_8: Space = if (v407_5).is_empty() { Space::new() } else {
                let v408_6: Path = concat_path(&(v400_3_head),&(v406_10_head));
                let v408_7: Space = routine_49(c, &(v408_6), &(v406_10_tail));
                compose(&(v407_5),&(v408_7))
              };
              drop(v407_5);
              let v407_9: Space = intersect(&(*CONSTANT_9),&(v407_2));
              drop(v407_2);
              let v407_10: Space = if has_head(&(v407_9)) { singleton(&[]) } else { Space::new() };
              drop(v407_9);
              let v407_12: Space = if (v407_10).is_empty() { Space::new() } else {
                let v409_6: Path = concat_path(&(v400_3_head),&(v406_10_head));
                let v409_11: Space = routine_51(c, &(v409_6), &(v406_10_tail));
                drop(v409_6);
                compose(&(v407_10),&(v409_11))
              };
              drop(v407_10);
              let v407_13: Space = unite(&(v407_8),&(v407_12));
              v406_10.join_into((v407_13).clone());
            }
            drop(v406_10_cursor);
            compose(&(v401_9),&(v406_10))
          };
          drop(v401_9);
          let v401_12: Space = unite(&(v401_7),&(v401_11));
          v400_3.join_into((v401_12).clone());
        }
        drop(v400_3_cursor);
        drop(v400_2);
        let v400_4: Space = unite(&(v400_3),&(v399_13));
        let v400_5: Space = intersect(&(v400_4),&(*capture_2));
        let v399_13_next = unite(&v399_13,&(v400_5));
        if equal(&v399_13_next,&v399_13) { break; }
        v399_13 = v399_13_next;
      }
      let mut v399_14: Space = ((*capture_4)).clone();
      loop {
        let v410_1: Space = intersect(&(v399_14),&(*capture_2));
        let v410_2: Space = restrict_to(&(*capture_0),&(v410_1));
        drop(v410_1);
        let mut v410_3 = Space::new();
        let mut v410_3_cursor = (v410_2).read_zipper();
        for v410_3_byte in v410_3_cursor.child_mask().iter() {
          v410_3_cursor.descend_to_byte(v410_3_byte);
          let v410_3_tail = v410_3_cursor.make_map();
          v410_3_cursor.ascend(1);
          let v410_3_head = Path::from_slice(&[v410_3_byte]);
          let v411_2: Space = singleton(&(v410_3_head));
          let v411_3: Space = intersect(&(*CONSTANT_9),&(v411_2));
          let v411_4: Space = if has_head(&(v411_3)) { singleton(&[]) } else { Space::new() };
          drop(v411_3);
          let v411_5: Space = subtract(&(*CONSTANT_0),&(v411_4));
          drop(v411_4);
          let v411_7: Space = if (v411_5).is_empty() { Space::new() } else {
            let mut v412_6 = Space::new();
            let mut v412_6_cursor = (v410_3_tail).read_zipper();
            for v412_6_byte in v412_6_cursor.child_mask().iter() {
              v412_6_cursor.descend_to_byte(v412_6_byte);
              let v412_6_tail = v412_6_cursor.make_map();
              v412_6_cursor.ascend(1);
              let v412_6_head = Path::from_slice(&[v412_6_byte]);
              let v413_2: Space = singleton(&(v412_6_head));
              let v413_3: Space = intersect(&(*CONSTANT_9),&(v413_2));
              let v413_4: Space = if has_head(&(v413_3)) { singleton(&[]) } else { Space::new() };
              drop(v413_3);
              let v413_5: Space = subtract(&(*CONSTANT_0),&(v413_4));
              drop(v413_4);
              let v413_8: Space = if (v413_5).is_empty() { Space::new() } else {
                let v414_6: Path = concat_path(&(v410_3_head),&(v412_6_head));
                let v414_7: Space = routine_49(c, &(v414_6), &(v412_6_tail));
                compose(&(v413_5),&(v414_7))
              };
              drop(v413_5);
              let v413_9: Space = intersect(&(*CONSTANT_9),&(v413_2));
              drop(v413_2);
              let v413_10: Space = if has_head(&(v413_9)) { singleton(&[]) } else { Space::new() };
              drop(v413_9);
              let v413_12: Space = if (v413_10).is_empty() { Space::new() } else {
                let v415_6: Path = concat_path(&(v410_3_head),&(v412_6_head));
                let v415_11: Space = routine_50(c, &(v415_6), &(v412_6_tail));
                drop(v415_6);
                compose(&(v413_10),&(v415_11))
              };
              drop(v413_10);
              let v413_13: Space = unite(&(v413_8),&(v413_12));
              v412_6.join_into((v413_13).clone());
            }
            drop(v412_6_cursor);
            compose(&(v411_5),&(v412_6))
          };
          drop(v411_5);
          let v411_8: Space = intersect(&(*CONSTANT_9),&(v411_2));
          drop(v411_2);
          let v411_9: Space = if has_head(&(v411_8)) { singleton(&[]) } else { Space::new() };
          drop(v411_8);
          let v411_11: Space = if (v411_9).is_empty() { Space::new() } else {
            let mut v416_10 = Space::new();
            let mut v416_10_cursor = (v410_3_tail).read_zipper();
            for v416_10_byte in v416_10_cursor.child_mask().iter() {
              v416_10_cursor.descend_to_byte(v416_10_byte);
              let v416_10_tail = v416_10_cursor.make_map();
              v416_10_cursor.ascend(1);
              let v416_10_head = Path::from_slice(&[v416_10_byte]);
              let v417_2: Space = singleton(&(v416_10_head));
              let v417_3: Space = intersect(&(*CONSTANT_9),&(v417_2));
              let v417_4: Space = if has_head(&(v417_3)) { singleton(&[]) } else { Space::new() };
              drop(v417_3);
              let v417_5: Space = subtract(&(*CONSTANT_0),&(v417_4));
              drop(v417_4);
              let v417_8: Space = if (v417_5).is_empty() { Space::new() } else {
                let v418_6: Path = concat_path(&(v410_3_head),&(v416_10_head));
                let v418_7: Space = routine_49(c, &(v418_6), &(v416_10_tail));
                compose(&(v417_5),&(v418_7))
              };
              drop(v417_5);
              let v417_9: Space = intersect(&(*CONSTANT_9),&(v417_2));
              drop(v417_2);
              let v417_10: Space = if has_head(&(v417_9)) { singleton(&[]) } else { Space::new() };
              drop(v417_9);
              let v417_12: Space = if (v417_10).is_empty() { Space::new() } else {
                let v419_6: Path = concat_path(&(v410_3_head),&(v416_10_head));
                let v419_11: Space = routine_51(c, &(v419_6), &(v416_10_tail));
                drop(v419_6);
                compose(&(v417_10),&(v419_11))
              };
              drop(v417_10);
              let v417_13: Space = unite(&(v417_8),&(v417_12));
              v416_10.join_into((v417_13).clone());
            }
            drop(v416_10_cursor);
            compose(&(v411_9),&(v416_10))
          };
          drop(v411_9);
          let v411_12: Space = unite(&(v411_7),&(v411_11));
          v410_3.join_into((v411_12).clone());
        }
        drop(v410_3_cursor);
        drop(v410_2);
        let v410_4: Space = unite(&(v410_3),&(v399_14));
        let v410_5: Space = intersect(&(v410_4),&(*capture_2));
        let v399_14_next = unite(&v399_14,&(v410_5));
        if equal(&v399_14_next,&v399_14) { break; }
        v399_14 = v399_14_next;
      }
      let v399_15: Space = subtract(&(v399_13),&(v399_14));
      let v399_16: Space = routine_15(c, &(v273_154_head), &(v273_154_tail), &(*capture_0), &(*capture_1), &(v399_15));
      compose(&(v377_12),&(v399_16))
    };
    drop(v377_12);
    let v377_18: Space = unite(&(v377_10),&(v377_17));
    v273_154.join_into((v377_18).clone());
  }
  drop(v273_154_cursor);

((v273_102).clone(),(v273_112).clone(),(v273_113).clone(),(v273_114).clone(),(v273_154).clone(),(v273_92).clone(),)
}

#[inline(never)]
fn native_block_2(c: &mut Context,capture_0: &Space,capture_1: &Space,capture_2: &Space,capture_3: &Space,capture_4: &Space,capture_5: &Space) -> (Space,Space,Space,Space,Space,Space,) {
  let v273_155: Space = unite(&((*capture_5)),&((*capture_3)));
  let mut v273_165: Space = ((*capture_4)).clone();
  loop {
    let v420_1: Space = intersect(&(v273_165),&(*capture_2));
    let v420_2: Space = restrict_to(&(*capture_0),&(v420_1));
    drop(v420_1);
    let mut v420_3 = Space::new();
    let mut v420_3_cursor = (v420_2).read_zipper();
    for v420_3_byte in v420_3_cursor.child_mask().iter() {
      v420_3_cursor.descend_to_byte(v420_3_byte);
      let v420_3_tail = v420_3_cursor.make_map();
      v420_3_cursor.ascend(1);
      let v420_3_head = Path::from_slice(&[v420_3_byte]);
      let v421_2: Space = singleton(&(v420_3_head));
      let v421_3: Space = intersect(&(*CONSTANT_9),&(v421_2));
      let v421_4: Space = if has_head(&(v421_3)) { singleton(&[]) } else { Space::new() };
      drop(v421_3);
      let v421_5: Space = subtract(&(*CONSTANT_0),&(v421_4));
      drop(v421_4);
      let v421_7: Space = if (v421_5).is_empty() { Space::new() } else {
        let mut v422_6 = Space::new();
        let mut v422_6_cursor = (v420_3_tail).read_zipper();
        for v422_6_byte in v422_6_cursor.child_mask().iter() {
          v422_6_cursor.descend_to_byte(v422_6_byte);
          let v422_6_tail = v422_6_cursor.make_map();
          v422_6_cursor.ascend(1);
          let v422_6_head = Path::from_slice(&[v422_6_byte]);
          let v423_2: Space = singleton(&(v422_6_head));
          let v423_3: Space = intersect(&(*CONSTANT_9),&(v423_2));
          let v423_4: Space = if has_head(&(v423_3)) { singleton(&[]) } else { Space::new() };
          drop(v423_3);
          let v423_5: Space = subtract(&(*CONSTANT_0),&(v423_4));
          drop(v423_4);
          let v423_8: Space = if (v423_5).is_empty() { Space::new() } else {
            let v424_6: Path = concat_path(&(v420_3_head),&(v422_6_head));
            let v424_7: Space = routine_49(c, &(v424_6), &(v422_6_tail));
            compose(&(v423_5),&(v424_7))
          };
          drop(v423_5);
          let v423_9: Space = intersect(&(*CONSTANT_9),&(v423_2));
          drop(v423_2);
          let v423_10: Space = if has_head(&(v423_9)) { singleton(&[]) } else { Space::new() };
          drop(v423_9);
          let v423_12: Space = if (v423_10).is_empty() { Space::new() } else {
            let v425_6: Path = concat_path(&(v420_3_head),&(v422_6_head));
            let v425_11: Space = routine_50(c, &(v425_6), &(v422_6_tail));
            drop(v425_6);
            compose(&(v423_10),&(v425_11))
          };
          drop(v423_10);
          let v423_13: Space = unite(&(v423_8),&(v423_12));
          v422_6.join_into((v423_13).clone());
        }
        drop(v422_6_cursor);
        compose(&(v421_5),&(v422_6))
      };
      drop(v421_5);
      let v421_8: Space = intersect(&(*CONSTANT_9),&(v421_2));
      drop(v421_2);
      let v421_9: Space = if has_head(&(v421_8)) { singleton(&[]) } else { Space::new() };
      drop(v421_8);
      let v421_11: Space = if (v421_9).is_empty() { Space::new() } else {
        let mut v426_10 = Space::new();
        let mut v426_10_cursor = (v420_3_tail).read_zipper();
        for v426_10_byte in v426_10_cursor.child_mask().iter() {
          v426_10_cursor.descend_to_byte(v426_10_byte);
          let v426_10_tail = v426_10_cursor.make_map();
          v426_10_cursor.ascend(1);
          let v426_10_head = Path::from_slice(&[v426_10_byte]);
          let v427_2: Space = singleton(&(v426_10_head));
          let v427_3: Space = intersect(&(*CONSTANT_9),&(v427_2));
          let v427_4: Space = if has_head(&(v427_3)) { singleton(&[]) } else { Space::new() };
          drop(v427_3);
          let v427_5: Space = subtract(&(*CONSTANT_0),&(v427_4));
          drop(v427_4);
          let v427_8: Space = if (v427_5).is_empty() { Space::new() } else {
            let v428_6: Path = concat_path(&(v420_3_head),&(v426_10_head));
            let v428_7: Space = routine_49(c, &(v428_6), &(v426_10_tail));
            compose(&(v427_5),&(v428_7))
          };
          drop(v427_5);
          let v427_9: Space = intersect(&(*CONSTANT_9),&(v427_2));
          drop(v427_2);
          let v427_10: Space = if has_head(&(v427_9)) { singleton(&[]) } else { Space::new() };
          drop(v427_9);
          let v427_12: Space = if (v427_10).is_empty() { Space::new() } else {
            let v429_6: Path = concat_path(&(v420_3_head),&(v426_10_head));
            let v429_11: Space = routine_51(c, &(v429_6), &(v426_10_tail));
            drop(v429_6);
            compose(&(v427_10),&(v429_11))
          };
          drop(v427_10);
          let v427_13: Space = unite(&(v427_8),&(v427_12));
          v426_10.join_into((v427_13).clone());
        }
        drop(v426_10_cursor);
        compose(&(v421_9),&(v426_10))
      };
      drop(v421_9);
      let v421_12: Space = unite(&(v421_7),&(v421_11));
      v420_3.join_into((v421_12).clone());
    }
    drop(v420_3_cursor);
    drop(v420_2);
    let v420_4: Space = unite(&(v420_3),&(v273_165));
    let v420_5: Space = intersect(&(v420_4),&(*capture_2));
    let v273_165_next = unite(&v273_165,&(v420_5));
    if equal(&v273_165_next,&v273_165) { break; }
    v273_165 = v273_165_next;
  }
  let mut v273_175: Space = ((*capture_4)).clone();
  loop {
    let v430_1: Space = intersect(&(v273_175),&(*capture_2));
    let v430_2: Space = restrict_to(&(*capture_1),&(v430_1));
    drop(v430_1);
    let mut v430_3 = Space::new();
    let mut v430_3_cursor = (v430_2).read_zipper();
    for v430_3_byte in v430_3_cursor.child_mask().iter() {
      v430_3_cursor.descend_to_byte(v430_3_byte);
      let v430_3_tail = v430_3_cursor.make_map();
      v430_3_cursor.ascend(1);
      let v430_3_head = Path::from_slice(&[v430_3_byte]);
      let v431_2: Space = singleton(&(v430_3_head));
      let v431_3: Space = intersect(&(*CONSTANT_9),&(v431_2));
      let v431_4: Space = if has_head(&(v431_3)) { singleton(&[]) } else { Space::new() };
      drop(v431_3);
      let v431_5: Space = subtract(&(*CONSTANT_0),&(v431_4));
      drop(v431_4);
      let v431_7: Space = if (v431_5).is_empty() { Space::new() } else {
        let mut v432_6 = Space::new();
        let mut v432_6_cursor = (v430_3_tail).read_zipper();
        for v432_6_byte in v432_6_cursor.child_mask().iter() {
          v432_6_cursor.descend_to_byte(v432_6_byte);
          let v432_6_tail = v432_6_cursor.make_map();
          v432_6_cursor.ascend(1);
          let v432_6_head = Path::from_slice(&[v432_6_byte]);
          let v433_2: Space = singleton(&(v432_6_head));
          let v433_3: Space = intersect(&(*CONSTANT_9),&(v433_2));
          let v433_4: Space = if has_head(&(v433_3)) { singleton(&[]) } else { Space::new() };
          drop(v433_3);
          let v433_5: Space = subtract(&(*CONSTANT_0),&(v433_4));
          drop(v433_4);
          let v433_8: Space = if (v433_5).is_empty() { Space::new() } else {
            let v434_6: Path = concat_path(&(v430_3_head),&(v432_6_head));
            let v434_7: Space = routine_49(c, &(v434_6), &(v432_6_tail));
            compose(&(v433_5),&(v434_7))
          };
          drop(v433_5);
          let v433_9: Space = intersect(&(*CONSTANT_9),&(v433_2));
          drop(v433_2);
          let v433_10: Space = if has_head(&(v433_9)) { singleton(&[]) } else { Space::new() };
          drop(v433_9);
          let v433_12: Space = if (v433_10).is_empty() { Space::new() } else {
            let v435_6: Path = concat_path(&(v430_3_head),&(v432_6_head));
            let v435_11: Space = routine_50(c, &(v435_6), &(v432_6_tail));
            drop(v435_6);
            compose(&(v433_10),&(v435_11))
          };
          drop(v433_10);
          let v433_13: Space = unite(&(v433_8),&(v433_12));
          v432_6.join_into((v433_13).clone());
        }
        drop(v432_6_cursor);
        compose(&(v431_5),&(v432_6))
      };
      drop(v431_5);
      let v431_8: Space = intersect(&(*CONSTANT_9),&(v431_2));
      drop(v431_2);
      let v431_9: Space = if has_head(&(v431_8)) { singleton(&[]) } else { Space::new() };
      drop(v431_8);
      let v431_11: Space = if (v431_9).is_empty() { Space::new() } else {
        let mut v436_10 = Space::new();
        let mut v436_10_cursor = (v430_3_tail).read_zipper();
        for v436_10_byte in v436_10_cursor.child_mask().iter() {
          v436_10_cursor.descend_to_byte(v436_10_byte);
          let v436_10_tail = v436_10_cursor.make_map();
          v436_10_cursor.ascend(1);
          let v436_10_head = Path::from_slice(&[v436_10_byte]);
          let v437_2: Space = singleton(&(v436_10_head));
          let v437_3: Space = intersect(&(*CONSTANT_9),&(v437_2));
          let v437_4: Space = if has_head(&(v437_3)) { singleton(&[]) } else { Space::new() };
          drop(v437_3);
          let v437_5: Space = subtract(&(*CONSTANT_0),&(v437_4));
          drop(v437_4);
          let v437_8: Space = if (v437_5).is_empty() { Space::new() } else {
            let v438_6: Path = concat_path(&(v430_3_head),&(v436_10_head));
            let v438_7: Space = routine_49(c, &(v438_6), &(v436_10_tail));
            compose(&(v437_5),&(v438_7))
          };
          drop(v437_5);
          let v437_9: Space = intersect(&(*CONSTANT_9),&(v437_2));
          drop(v437_2);
          let v437_10: Space = if has_head(&(v437_9)) { singleton(&[]) } else { Space::new() };
          drop(v437_9);
          let v437_12: Space = if (v437_10).is_empty() { Space::new() } else {
            let v439_6: Path = concat_path(&(v430_3_head),&(v436_10_head));
            let v439_11: Space = routine_51(c, &(v439_6), &(v436_10_tail));
            drop(v439_6);
            compose(&(v437_10),&(v439_11))
          };
          drop(v437_10);
          let v437_13: Space = unite(&(v437_8),&(v437_12));
          v436_10.join_into((v437_13).clone());
        }
        drop(v436_10_cursor);
        compose(&(v431_9),&(v436_10))
      };
      drop(v431_9);
      let v431_12: Space = unite(&(v431_7),&(v431_11));
      v430_3.join_into((v431_12).clone());
    }
    drop(v430_3_cursor);
    drop(v430_2);
    let v430_4: Space = unite(&(v430_3),&(v273_175));
    let v430_5: Space = intersect(&(v430_4),&(*capture_2));
    let v273_175_next = unite(&v273_175,&(v430_5));
    if equal(&v273_175_next,&v273_175) { break; }
    v273_175 = v273_175_next;
  }
  let v273_176: Space = subtract(&(v273_165),&(v273_175));
  let v273_177: Space = routine_10(c, &(v273_176));
  let mut v273_217 = Space::new();
  let mut v273_217_cursor = (v273_177).read_zipper();
  for v273_217_byte in v273_217_cursor.child_mask().iter() {
    v273_217_cursor.descend_to_byte(v273_217_byte);
    let v273_217_tail = v273_217_cursor.make_map();
    v273_217_cursor.ascend(1);
    let v273_217_head = Path::from_slice(&[v273_217_byte]);
    let v440_2: Space = singleton(&(v273_217_head));
    let v440_3: Space = intersect(&(*CONSTANT_9),&(v440_2));
    let v440_4: Space = if has_head(&(v440_3)) { singleton(&[]) } else { Space::new() };
    drop(v440_3);
    let v440_5: Space = subtract(&(*CONSTANT_0),&(v440_4));
    drop(v440_4);
    let v440_10: Space = if (v440_5).is_empty() { Space::new() } else {
      let mut v441_6: Space = ((*capture_4)).clone();
      loop {
        let v442_1: Space = intersect(&(v441_6),&(*capture_2));
        let v442_2: Space = restrict_to(&(*capture_0),&(v442_1));
        drop(v442_1);
        let mut v442_3 = Space::new();
        let mut v442_3_cursor = (v442_2).read_zipper();
        for v442_3_byte in v442_3_cursor.child_mask().iter() {
          v442_3_cursor.descend_to_byte(v442_3_byte);
          let v442_3_tail = v442_3_cursor.make_map();
          v442_3_cursor.ascend(1);
          let v442_3_head = Path::from_slice(&[v442_3_byte]);
          let v443_2: Space = singleton(&(v442_3_head));
          let v443_3: Space = intersect(&(*CONSTANT_9),&(v443_2));
          let v443_4: Space = if has_head(&(v443_3)) { singleton(&[]) } else { Space::new() };
          drop(v443_3);
          let v443_5: Space = subtract(&(*CONSTANT_0),&(v443_4));
          drop(v443_4);
          let v443_7: Space = if (v443_5).is_empty() { Space::new() } else {
            let mut v444_6 = Space::new();
            let mut v444_6_cursor = (v442_3_tail).read_zipper();
            for v444_6_byte in v444_6_cursor.child_mask().iter() {
              v444_6_cursor.descend_to_byte(v444_6_byte);
              let v444_6_tail = v444_6_cursor.make_map();
              v444_6_cursor.ascend(1);
              let v444_6_head = Path::from_slice(&[v444_6_byte]);
              let v445_2: Space = singleton(&(v444_6_head));
              let v445_3: Space = intersect(&(*CONSTANT_9),&(v445_2));
              let v445_4: Space = if has_head(&(v445_3)) { singleton(&[]) } else { Space::new() };
              drop(v445_3);
              let v445_5: Space = subtract(&(*CONSTANT_0),&(v445_4));
              drop(v445_4);
              let v445_8: Space = if (v445_5).is_empty() { Space::new() } else {
                let v446_6: Path = concat_path(&(v442_3_head),&(v444_6_head));
                let v446_7: Space = routine_49(c, &(v446_6), &(v444_6_tail));
                compose(&(v445_5),&(v446_7))
              };
              drop(v445_5);
              let v445_9: Space = intersect(&(*CONSTANT_9),&(v445_2));
              drop(v445_2);
              let v445_10: Space = if has_head(&(v445_9)) { singleton(&[]) } else { Space::new() };
              drop(v445_9);
              let v445_12: Space = if (v445_10).is_empty() { Space::new() } else {
                let v447_6: Path = concat_path(&(v442_3_head),&(v444_6_head));
                let v447_11: Space = routine_50(c, &(v447_6), &(v444_6_tail));
                drop(v447_6);
                compose(&(v445_10),&(v447_11))
              };
              drop(v445_10);
              let v445_13: Space = unite(&(v445_8),&(v445_12));
              v444_6.join_into((v445_13).clone());
            }
            drop(v444_6_cursor);
            compose(&(v443_5),&(v444_6))
          };
          drop(v443_5);
          let v443_8: Space = intersect(&(*CONSTANT_9),&(v443_2));
          drop(v443_2);
          let v443_9: Space = if has_head(&(v443_8)) { singleton(&[]) } else { Space::new() };
          drop(v443_8);
          let v443_11: Space = if (v443_9).is_empty() { Space::new() } else {
            let mut v448_10 = Space::new();
            let mut v448_10_cursor = (v442_3_tail).read_zipper();
            for v448_10_byte in v448_10_cursor.child_mask().iter() {
              v448_10_cursor.descend_to_byte(v448_10_byte);
              let v448_10_tail = v448_10_cursor.make_map();
              v448_10_cursor.ascend(1);
              let v448_10_head = Path::from_slice(&[v448_10_byte]);
              let v449_2: Space = singleton(&(v448_10_head));
              let v449_3: Space = intersect(&(*CONSTANT_9),&(v449_2));
              let v449_4: Space = if has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
              drop(v449_3);
              let v449_5: Space = subtract(&(*CONSTANT_0),&(v449_4));
              drop(v449_4);
              let v449_8: Space = if (v449_5).is_empty() { Space::new() } else {
                let v450_6: Path = concat_path(&(v442_3_head),&(v448_10_head));
                let v450_7: Space = routine_49(c, &(v450_6), &(v448_10_tail));
                compose(&(v449_5),&(v450_7))
              };
              drop(v449_5);
              let v449_9: Space = intersect(&(*CONSTANT_9),&(v449_2));
              drop(v449_2);
              let v449_10: Space = if has_head(&(v449_9)) { singleton(&[]) } else { Space::new() };
              drop(v449_9);
              let v449_12: Space = if (v449_10).is_empty() { Space::new() } else {
                let v451_6: Path = concat_path(&(v442_3_head),&(v448_10_head));
                let v451_11: Space = routine_51(c, &(v451_6), &(v448_10_tail));
                drop(v451_6);
                compose(&(v449_10),&(v451_11))
              };
              drop(v449_10);
              let v449_13: Space = unite(&(v449_8),&(v449_12));
              v448_10.join_into((v449_13).clone());
            }
            drop(v448_10_cursor);
            compose(&(v443_9),&(v448_10))
          };
          drop(v443_9);
          let v443_12: Space = unite(&(v443_7),&(v443_11));
          v442_3.join_into((v443_12).clone());
        }
        drop(v442_3_cursor);
        drop(v442_2);
        let v442_4: Space = unite(&(v442_3),&(v441_6));
        let v442_5: Space = intersect(&(v442_4),&(*capture_2));
        let v441_6_next = unite(&v441_6,&(v442_5));
        if equal(&v441_6_next,&v441_6) { break; }
        v441_6 = v441_6_next;
      }
      let mut v441_7: Space = ((*capture_4)).clone();
      loop {
        let v452_1: Space = intersect(&(v441_7),&(*capture_2));
        let v452_2: Space = restrict_to(&(*capture_1),&(v452_1));
        drop(v452_1);
        let mut v452_3 = Space::new();
        let mut v452_3_cursor = (v452_2).read_zipper();
        for v452_3_byte in v452_3_cursor.child_mask().iter() {
          v452_3_cursor.descend_to_byte(v452_3_byte);
          let v452_3_tail = v452_3_cursor.make_map();
          v452_3_cursor.ascend(1);
          let v452_3_head = Path::from_slice(&[v452_3_byte]);
          let v453_2: Space = singleton(&(v452_3_head));
          let v453_3: Space = intersect(&(*CONSTANT_9),&(v453_2));
          let v453_4: Space = if has_head(&(v453_3)) { singleton(&[]) } else { Space::new() };
          drop(v453_3);
          let v453_5: Space = subtract(&(*CONSTANT_0),&(v453_4));
          drop(v453_4);
          let v453_7: Space = if (v453_5).is_empty() { Space::new() } else {
            let mut v454_6 = Space::new();
            let mut v454_6_cursor = (v452_3_tail).read_zipper();
            for v454_6_byte in v454_6_cursor.child_mask().iter() {
              v454_6_cursor.descend_to_byte(v454_6_byte);
              let v454_6_tail = v454_6_cursor.make_map();
              v454_6_cursor.ascend(1);
              let v454_6_head = Path::from_slice(&[v454_6_byte]);
              let v455_2: Space = singleton(&(v454_6_head));
              let v455_3: Space = intersect(&(*CONSTANT_9),&(v455_2));
              let v455_4: Space = if has_head(&(v455_3)) { singleton(&[]) } else { Space::new() };
              drop(v455_3);
              let v455_5: Space = subtract(&(*CONSTANT_0),&(v455_4));
              drop(v455_4);
              let v455_8: Space = if (v455_5).is_empty() { Space::new() } else {
                let v456_6: Path = concat_path(&(v452_3_head),&(v454_6_head));
                let v456_7: Space = routine_49(c, &(v456_6), &(v454_6_tail));
                compose(&(v455_5),&(v456_7))
              };
              drop(v455_5);
              let v455_9: Space = intersect(&(*CONSTANT_9),&(v455_2));
              drop(v455_2);
              let v455_10: Space = if has_head(&(v455_9)) { singleton(&[]) } else { Space::new() };
              drop(v455_9);
              let v455_12: Space = if (v455_10).is_empty() { Space::new() } else {
                let v457_6: Path = concat_path(&(v452_3_head),&(v454_6_head));
                let v457_11: Space = routine_50(c, &(v457_6), &(v454_6_tail));
                drop(v457_6);
                compose(&(v455_10),&(v457_11))
              };
              drop(v455_10);
              let v455_13: Space = unite(&(v455_8),&(v455_12));
              v454_6.join_into((v455_13).clone());
            }
            drop(v454_6_cursor);
            compose(&(v453_5),&(v454_6))
          };
          drop(v453_5);
          let v453_8: Space = intersect(&(*CONSTANT_9),&(v453_2));
          drop(v453_2);
          let v453_9: Space = if has_head(&(v453_8)) { singleton(&[]) } else { Space::new() };
          drop(v453_8);
          let v453_11: Space = if (v453_9).is_empty() { Space::new() } else {
            let mut v458_10 = Space::new();
            let mut v458_10_cursor = (v452_3_tail).read_zipper();
            for v458_10_byte in v458_10_cursor.child_mask().iter() {
              v458_10_cursor.descend_to_byte(v458_10_byte);
              let v458_10_tail = v458_10_cursor.make_map();
              v458_10_cursor.ascend(1);
              let v458_10_head = Path::from_slice(&[v458_10_byte]);
              let v459_2: Space = singleton(&(v458_10_head));
              let v459_3: Space = intersect(&(*CONSTANT_9),&(v459_2));
              let v459_4: Space = if has_head(&(v459_3)) { singleton(&[]) } else { Space::new() };
              drop(v459_3);
              let v459_5: Space = subtract(&(*CONSTANT_0),&(v459_4));
              drop(v459_4);
              let v459_8: Space = if (v459_5).is_empty() { Space::new() } else {
                let v460_6: Path = concat_path(&(v452_3_head),&(v458_10_head));
                let v460_7: Space = routine_49(c, &(v460_6), &(v458_10_tail));
                compose(&(v459_5),&(v460_7))
              };
              drop(v459_5);
              let v459_9: Space = intersect(&(*CONSTANT_9),&(v459_2));
              drop(v459_2);
              let v459_10: Space = if has_head(&(v459_9)) { singleton(&[]) } else { Space::new() };
              drop(v459_9);
              let v459_12: Space = if (v459_10).is_empty() { Space::new() } else {
                let v461_6: Path = concat_path(&(v452_3_head),&(v458_10_head));
                let v461_11: Space = routine_51(c, &(v461_6), &(v458_10_tail));
                drop(v461_6);
                compose(&(v459_10),&(v461_11))
              };
              drop(v459_10);
              let v459_13: Space = unite(&(v459_8),&(v459_12));
              v458_10.join_into((v459_13).clone());
            }
            drop(v458_10_cursor);
            compose(&(v453_9),&(v458_10))
          };
          drop(v453_9);
          let v453_12: Space = unite(&(v453_7),&(v453_11));
          v452_3.join_into((v453_12).clone());
        }
        drop(v452_3_cursor);
        drop(v452_2);
        let v452_4: Space = unite(&(v452_3),&(v441_7));
        let v452_5: Space = intersect(&(v452_4),&(*capture_2));
        let v441_7_next = unite(&v441_7,&(v452_5));
        if equal(&v441_7_next,&v441_7) { break; }
        v441_7 = v441_7_next;
      }
      let v441_8: Space = subtract(&(v441_6),&(v441_7));
      let v441_9: Space = routine_14(c, &(v273_217_head), &(v273_217_tail), &(*capture_0), &(*capture_1), &(v441_8));
      compose(&(v440_5),&(v441_9))
    };
    drop(v440_5);
    let v440_11: Space = intersect(&(*CONSTANT_9),&(v440_2));
    drop(v440_2);
    let v440_12: Space = if has_head(&(v440_11)) { singleton(&[]) } else { Space::new() };
    drop(v440_11);
    let v440_17: Space = if (v440_12).is_empty() { Space::new() } else {
      let mut v462_13: Space = ((*capture_4)).clone();
      loop {
        let v463_1: Space = intersect(&(v462_13),&(*capture_2));
        let v463_2: Space = restrict_to(&(*capture_0),&(v463_1));
        drop(v463_1);
        let mut v463_3 = Space::new();
        let mut v463_3_cursor = (v463_2).read_zipper();
        for v463_3_byte in v463_3_cursor.child_mask().iter() {
          v463_3_cursor.descend_to_byte(v463_3_byte);
          let v463_3_tail = v463_3_cursor.make_map();
          v463_3_cursor.ascend(1);
          let v463_3_head = Path::from_slice(&[v463_3_byte]);
          let v464_2: Space = singleton(&(v463_3_head));
          let v464_3: Space = intersect(&(*CONSTANT_9),&(v464_2));
          let v464_4: Space = if has_head(&(v464_3)) { singleton(&[]) } else { Space::new() };
          drop(v464_3);
          let v464_5: Space = subtract(&(*CONSTANT_0),&(v464_4));
          drop(v464_4);
          let v464_7: Space = if (v464_5).is_empty() { Space::new() } else {
            let mut v465_6 = Space::new();
            let mut v465_6_cursor = (v463_3_tail).read_zipper();
            for v465_6_byte in v465_6_cursor.child_mask().iter() {
              v465_6_cursor.descend_to_byte(v465_6_byte);
              let v465_6_tail = v465_6_cursor.make_map();
              v465_6_cursor.ascend(1);
              let v465_6_head = Path::from_slice(&[v465_6_byte]);
              let v466_2: Space = singleton(&(v465_6_head));
              let v466_3: Space = intersect(&(*CONSTANT_9),&(v466_2));
              let v466_4: Space = if has_head(&(v466_3)) { singleton(&[]) } else { Space::new() };
              drop(v466_3);
              let v466_5: Space = subtract(&(*CONSTANT_0),&(v466_4));
              drop(v466_4);
              let v466_8: Space = if (v466_5).is_empty() { Space::new() } else {
                let v467_6: Path = concat_path(&(v463_3_head),&(v465_6_head));
                let v467_7: Space = routine_49(c, &(v467_6), &(v465_6_tail));
                compose(&(v466_5),&(v467_7))
              };
              drop(v466_5);
              let v466_9: Space = intersect(&(*CONSTANT_9),&(v466_2));
              drop(v466_2);
              let v466_10: Space = if has_head(&(v466_9)) { singleton(&[]) } else { Space::new() };
              drop(v466_9);
              let v466_12: Space = if (v466_10).is_empty() { Space::new() } else {
                let v468_6: Path = concat_path(&(v463_3_head),&(v465_6_head));
                let v468_11: Space = routine_50(c, &(v468_6), &(v465_6_tail));
                drop(v468_6);
                compose(&(v466_10),&(v468_11))
              };
              drop(v466_10);
              let v466_13: Space = unite(&(v466_8),&(v466_12));
              v465_6.join_into((v466_13).clone());
            }
            drop(v465_6_cursor);
            compose(&(v464_5),&(v465_6))
          };
          drop(v464_5);
          let v464_8: Space = intersect(&(*CONSTANT_9),&(v464_2));
          drop(v464_2);
          let v464_9: Space = if has_head(&(v464_8)) { singleton(&[]) } else { Space::new() };
          drop(v464_8);
          let v464_11: Space = if (v464_9).is_empty() { Space::new() } else {
            let mut v469_10 = Space::new();
            let mut v469_10_cursor = (v463_3_tail).read_zipper();
            for v469_10_byte in v469_10_cursor.child_mask().iter() {
              v469_10_cursor.descend_to_byte(v469_10_byte);
              let v469_10_tail = v469_10_cursor.make_map();
              v469_10_cursor.ascend(1);
              let v469_10_head = Path::from_slice(&[v469_10_byte]);
              let v470_2: Space = singleton(&(v469_10_head));
              let v470_3: Space = intersect(&(*CONSTANT_9),&(v470_2));
              let v470_4: Space = if has_head(&(v470_3)) { singleton(&[]) } else { Space::new() };
              drop(v470_3);
              let v470_5: Space = subtract(&(*CONSTANT_0),&(v470_4));
              drop(v470_4);
              let v470_8: Space = if (v470_5).is_empty() { Space::new() } else {
                let v471_6: Path = concat_path(&(v463_3_head),&(v469_10_head));
                let v471_7: Space = routine_49(c, &(v471_6), &(v469_10_tail));
                compose(&(v470_5),&(v471_7))
              };
              drop(v470_5);
              let v470_9: Space = intersect(&(*CONSTANT_9),&(v470_2));
              drop(v470_2);
              let v470_10: Space = if has_head(&(v470_9)) { singleton(&[]) } else { Space::new() };
              drop(v470_9);
              let v470_12: Space = if (v470_10).is_empty() { Space::new() } else {
                let v472_6: Path = concat_path(&(v463_3_head),&(v469_10_head));
                let v472_11: Space = routine_51(c, &(v472_6), &(v469_10_tail));
                drop(v472_6);
                compose(&(v470_10),&(v472_11))
              };
              drop(v470_10);
              let v470_13: Space = unite(&(v470_8),&(v470_12));
              v469_10.join_into((v470_13).clone());
            }
            drop(v469_10_cursor);
            compose(&(v464_9),&(v469_10))
          };
          drop(v464_9);
          let v464_12: Space = unite(&(v464_7),&(v464_11));
          v463_3.join_into((v464_12).clone());
        }
        drop(v463_3_cursor);
        drop(v463_2);
        let v463_4: Space = unite(&(v463_3),&(v462_13));
        let v463_5: Space = intersect(&(v463_4),&(*capture_2));
        let v462_13_next = unite(&v462_13,&(v463_5));
        if equal(&v462_13_next,&v462_13) { break; }
        v462_13 = v462_13_next;
      }
      let mut v462_14: Space = ((*capture_4)).clone();
      loop {
        let v473_1: Space = intersect(&(v462_14),&(*capture_2));
        let v473_2: Space = restrict_to(&(*capture_1),&(v473_1));
        drop(v473_1);
        let mut v473_3 = Space::new();
        let mut v473_3_cursor = (v473_2).read_zipper();
        for v473_3_byte in v473_3_cursor.child_mask().iter() {
          v473_3_cursor.descend_to_byte(v473_3_byte);
          let v473_3_tail = v473_3_cursor.make_map();
          v473_3_cursor.ascend(1);
          let v473_3_head = Path::from_slice(&[v473_3_byte]);
          let v474_2: Space = singleton(&(v473_3_head));
          let v474_3: Space = intersect(&(*CONSTANT_9),&(v474_2));
          let v474_4: Space = if has_head(&(v474_3)) { singleton(&[]) } else { Space::new() };
          drop(v474_3);
          let v474_5: Space = subtract(&(*CONSTANT_0),&(v474_4));
          drop(v474_4);
          let v474_7: Space = if (v474_5).is_empty() { Space::new() } else {
            let mut v475_6 = Space::new();
            let mut v475_6_cursor = (v473_3_tail).read_zipper();
            for v475_6_byte in v475_6_cursor.child_mask().iter() {
              v475_6_cursor.descend_to_byte(v475_6_byte);
              let v475_6_tail = v475_6_cursor.make_map();
              v475_6_cursor.ascend(1);
              let v475_6_head = Path::from_slice(&[v475_6_byte]);
              let v476_2: Space = singleton(&(v475_6_head));
              let v476_3: Space = intersect(&(*CONSTANT_9),&(v476_2));
              let v476_4: Space = if has_head(&(v476_3)) { singleton(&[]) } else { Space::new() };
              drop(v476_3);
              let v476_5: Space = subtract(&(*CONSTANT_0),&(v476_4));
              drop(v476_4);
              let v476_8: Space = if (v476_5).is_empty() { Space::new() } else {
                let v477_6: Path = concat_path(&(v473_3_head),&(v475_6_head));
                let v477_7: Space = routine_49(c, &(v477_6), &(v475_6_tail));
                compose(&(v476_5),&(v477_7))
              };
              drop(v476_5);
              let v476_9: Space = intersect(&(*CONSTANT_9),&(v476_2));
              drop(v476_2);
              let v476_10: Space = if has_head(&(v476_9)) { singleton(&[]) } else { Space::new() };
              drop(v476_9);
              let v476_12: Space = if (v476_10).is_empty() { Space::new() } else {
                let v478_6: Path = concat_path(&(v473_3_head),&(v475_6_head));
                let v478_11: Space = routine_50(c, &(v478_6), &(v475_6_tail));
                drop(v478_6);
                compose(&(v476_10),&(v478_11))
              };
              drop(v476_10);
              let v476_13: Space = unite(&(v476_8),&(v476_12));
              v475_6.join_into((v476_13).clone());
            }
            drop(v475_6_cursor);
            compose(&(v474_5),&(v475_6))
          };
          drop(v474_5);
          let v474_8: Space = intersect(&(*CONSTANT_9),&(v474_2));
          drop(v474_2);
          let v474_9: Space = if has_head(&(v474_8)) { singleton(&[]) } else { Space::new() };
          drop(v474_8);
          let v474_11: Space = if (v474_9).is_empty() { Space::new() } else {
            let mut v479_10 = Space::new();
            let mut v479_10_cursor = (v473_3_tail).read_zipper();
            for v479_10_byte in v479_10_cursor.child_mask().iter() {
              v479_10_cursor.descend_to_byte(v479_10_byte);
              let v479_10_tail = v479_10_cursor.make_map();
              v479_10_cursor.ascend(1);
              let v479_10_head = Path::from_slice(&[v479_10_byte]);
              let v480_2: Space = singleton(&(v479_10_head));
              let v480_3: Space = intersect(&(*CONSTANT_9),&(v480_2));
              let v480_4: Space = if has_head(&(v480_3)) { singleton(&[]) } else { Space::new() };
              drop(v480_3);
              let v480_5: Space = subtract(&(*CONSTANT_0),&(v480_4));
              drop(v480_4);
              let v480_8: Space = if (v480_5).is_empty() { Space::new() } else {
                let v481_6: Path = concat_path(&(v473_3_head),&(v479_10_head));
                let v481_7: Space = routine_49(c, &(v481_6), &(v479_10_tail));
                compose(&(v480_5),&(v481_7))
              };
              drop(v480_5);
              let v480_9: Space = intersect(&(*CONSTANT_9),&(v480_2));
              drop(v480_2);
              let v480_10: Space = if has_head(&(v480_9)) { singleton(&[]) } else { Space::new() };
              drop(v480_9);
              let v480_12: Space = if (v480_10).is_empty() { Space::new() } else {
                let v482_6: Path = concat_path(&(v473_3_head),&(v479_10_head));
                let v482_11: Space = routine_51(c, &(v482_6), &(v479_10_tail));
                drop(v482_6);
                compose(&(v480_10),&(v482_11))
              };
              drop(v480_10);
              let v480_13: Space = unite(&(v480_8),&(v480_12));
              v479_10.join_into((v480_13).clone());
            }
            drop(v479_10_cursor);
            compose(&(v474_9),&(v479_10))
          };
          drop(v474_9);
          let v474_12: Space = unite(&(v474_7),&(v474_11));
          v473_3.join_into((v474_12).clone());
        }
        drop(v473_3_cursor);
        drop(v473_2);
        let v473_4: Space = unite(&(v473_3),&(v462_14));
        let v473_5: Space = intersect(&(v473_4),&(*capture_2));
        let v462_14_next = unite(&v462_14,&(v473_5));
        if equal(&v462_14_next,&v462_14) { break; }
        v462_14 = v462_14_next;
      }
      let v462_15: Space = subtract(&(v462_13),&(v462_14));
      let v462_16: Space = routine_15(c, &(v273_217_head), &(v273_217_tail), &(*capture_0), &(*capture_1), &(v462_15));
      compose(&(v440_12),&(v462_16))
    };
    drop(v440_12);
    let v440_18: Space = unite(&(v440_10),&(v440_17));
    v273_217.join_into((v440_18).clone());
  }
  drop(v273_217_cursor);

((v273_155).clone(),(v273_165).clone(),(v273_175).clone(),(v273_176).clone(),(v273_177).clone(),(v273_217).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_18: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v1_17: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v2_4: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
      let v2_7: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4));
      let v2_8: Space = unite(&(v2_4),&(v2_7));
      let v2_11: Space = routine_2(c, &(*CONSTANT_5), &(*CONSTANT_6));
      let v2_12: Space = unite(&(v2_8),&(v2_11));
      let v2_15: Space = routine_3(c, &(*CONSTANT_7), &(*CONSTANT_8));
      let v2_16: Space = unite(&(v2_12),&(v2_15));
      compose(&(*CONSTANT_0),&(v2_16))
    };
    compose(&(*CONSTANT_0),&(v1_17))
  };
  let v0_33: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v3_32: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v4_22: Space = routine_4(c, &(*CONSTANT_1), &(*CONSTANT_2));
      let v4_24: Space = routine_4(c, &(*CONSTANT_3), &(*CONSTANT_4));
      let v4_25: Space = unite(&(v4_22),&(v4_24));
      let v4_27: Space = routine_5(c, &(*CONSTANT_5), &(*CONSTANT_6));
      let v4_28: Space = unite(&(v4_25),&(v4_27));
      let v4_30: Space = routine_6(c, &(*CONSTANT_7), &(*CONSTANT_8));
      let v4_31: Space = unite(&(v4_28),&(v4_30));
      compose(&(*CONSTANT_0),&(v4_31))
    };
    compose(&(*CONSTANT_0),&(v3_32))
  };
  let mut v0_43 = Space::new();
  let mut v0_43_cursor = (v0_33).read_zipper();
  for v0_43_byte in v0_43_cursor.child_mask().iter() {
    v0_43_cursor.descend_to_byte(v0_43_byte);
    let v0_43_tail = v0_43_cursor.make_map();
    v0_43_cursor.ascend(1);
    let v0_43_head = Path::from_slice(&[v0_43_byte]);
    let v5_2: Space = singleton(&(v0_43_head));
    let v5_3: Space = intersect(&(*CONSTANT_9),&(v5_2));
    let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
    drop(v5_3);
    let v5_5: Space = subtract(&(*CONSTANT_0),&(v5_4));
    drop(v5_4);
    let v5_7: Space = if (v5_5).is_empty() { Space::new() } else {
      let mut v6_6 = Space::new();
      let mut v6_6_cursor = (v0_43_tail).read_zipper();
      for v6_6_byte in v6_6_cursor.child_mask().iter() {
        v6_6_cursor.descend_to_byte(v6_6_byte);
        let v6_6_tail = v6_6_cursor.make_map();
        v6_6_cursor.ascend(1);
        let v6_6_head = Path::from_slice(&[v6_6_byte]);
        let v7_2: Space = singleton(&(v6_6_head));
        let v7_3: Space = intersect(&(*CONSTANT_9),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_43_head),&(v6_6_head));
          let v8_7: Space = routine_7(c, &(v8_6), &(v6_6_tail));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_9),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v0_43_head),&(v6_6_head));
          let v9_11: Space = routine_8(c, &(v9_6), &(v6_6_tail));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_6.join_into((v7_13).clone());
      }
      drop(v6_6_cursor);
      compose(&(v5_5),&(v6_6))
    };
    drop(v5_5);
    let v5_8: Space = intersect(&(*CONSTANT_9),&(v5_2));
    drop(v5_2);
    let v5_9: Space = if has_head(&(v5_8)) { singleton(&[]) } else { Space::new() };
    drop(v5_8);
    let v5_11: Space = if (v5_9).is_empty() { Space::new() } else {
      let mut v10_10 = Space::new();
      let mut v10_10_cursor = (v0_43_tail).read_zipper();
      for v10_10_byte in v10_10_cursor.child_mask().iter() {
        v10_10_cursor.descend_to_byte(v10_10_byte);
        let v10_10_tail = v10_10_cursor.make_map();
        v10_10_cursor.ascend(1);
        let v10_10_head = Path::from_slice(&[v10_10_byte]);
        let v11_2: Space = singleton(&(v10_10_head));
        let v11_3: Space = intersect(&(*CONSTANT_9),&(v11_2));
        let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
        drop(v11_3);
        let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
        drop(v11_4);
        let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
          let v12_6: Path = concat_path(&(v0_43_head),&(v10_10_head));
          let v12_7: Space = routine_7(c, &(v12_6), &(v10_10_tail));
          compose(&(v11_5),&(v12_7))
        };
        drop(v11_5);
        let v11_9: Space = intersect(&(*CONSTANT_9),&(v11_2));
        drop(v11_2);
        let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
        drop(v11_9);
        let v11_12: Space = if (v11_10).is_empty() { Space::new() } else {
          let v13_6: Path = concat_path(&(v0_43_head),&(v10_10_head));
          let v13_11: Space = routine_9(c, &(v13_6), &(v10_10_tail));
          drop(v13_6);
          compose(&(v11_10),&(v13_11))
        };
        drop(v11_10);
        let v11_13: Space = unite(&(v11_8),&(v11_12));
        v10_10.join_into((v11_13).clone());
      }
      drop(v10_10_cursor);
      compose(&(v5_9),&(v10_10))
    };
    drop(v5_9);
    let v5_12: Space = unite(&(v5_7),&(v5_11));
    v0_43.join_into((v5_12).clone());
  }
  drop(v0_43_cursor);
  let v0_44: Space = unite(&(v0_18),&(v0_43));
  let v0_45: Space = routine_10(c, &(v0_44));
  let mut v0_105 = Space::new();
  let mut v0_105_cursor = (v0_45).read_zipper();
  for v0_105_byte in v0_105_cursor.child_mask().iter() {
    v0_105_cursor.descend_to_byte(v0_105_byte);
    let v0_105_tail = v0_105_cursor.make_map();
    v0_105_cursor.ascend(1);
    let v0_105_head = Path::from_slice(&[v0_105_byte]);
    let v14_2: Space = singleton(&(v0_105_head));
    let v14_3: Space = intersect(&(*CONSTANT_9),&(v14_2));
    let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
    drop(v14_3);
    let v14_5: Space = subtract(&(*CONSTANT_0),&(v14_4));
    drop(v14_4);
    let v14_36: Space = if (v14_5).is_empty() { Space::new() } else {
      let v15_14: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v16_13: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v17_6: Space = routine_11(c, &(*CONSTANT_1), &(*CONSTANT_2));
          let v17_7: Space = routine_11(c, &(*CONSTANT_3), &(*CONSTANT_4));
          let v17_8: Space = unite(&(v17_6),&(v17_7));
          let v17_9: Space = routine_12(c, &(*CONSTANT_5), &(*CONSTANT_6));
          let v17_10: Space = unite(&(v17_8),&(v17_9));
          let v17_11: Space = routine_13(c, &(*CONSTANT_7), &(*CONSTANT_8));
          let v17_12: Space = unite(&(v17_10),&(v17_11));
          compose(&(*CONSTANT_0),&(v17_12))
        };
        compose(&(*CONSTANT_0),&(v16_13))
      };
      let v15_23: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v18_22: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v19_15: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
          let v19_16: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4));
          let v19_17: Space = unite(&(v19_15),&(v19_16));
          let v19_18: Space = routine_2(c, &(*CONSTANT_5), &(*CONSTANT_6));
          let v19_19: Space = unite(&(v19_17),&(v19_18));
          let v19_20: Space = routine_3(c, &(*CONSTANT_7), &(*CONSTANT_8));
          let v19_21: Space = unite(&(v19_19),&(v19_20));
          compose(&(*CONSTANT_0),&(v19_21))
        };
        compose(&(*CONSTANT_0),&(v18_22))
      };
      let v15_32: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v20_31: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v21_24: Space = routine_4(c, &(*CONSTANT_1), &(*CONSTANT_2));
          let v21_25: Space = routine_4(c, &(*CONSTANT_3), &(*CONSTANT_4));
          let v21_26: Space = unite(&(v21_24),&(v21_25));
          let v21_27: Space = routine_5(c, &(*CONSTANT_5), &(*CONSTANT_6));
          let v21_28: Space = unite(&(v21_26),&(v21_27));
          let v21_29: Space = routine_6(c, &(*CONSTANT_7), &(*CONSTANT_8));
          let v21_30: Space = unite(&(v21_28),&(v21_29));
          compose(&(*CONSTANT_0),&(v21_30))
        };
        compose(&(*CONSTANT_0),&(v20_31))
      };
      let mut v15_33 = Space::new();
      let mut v15_33_cursor = (v15_32).read_zipper();
      for v15_33_byte in v15_33_cursor.child_mask().iter() {
        v15_33_cursor.descend_to_byte(v15_33_byte);
        let v15_33_tail = v15_33_cursor.make_map();
        v15_33_cursor.ascend(1);
        let v15_33_head = Path::from_slice(&[v15_33_byte]);
        let v22_2: Space = singleton(&(v15_33_head));
        let v22_3: Space = intersect(&(*CONSTANT_9),&(v22_2));
        let v22_4: Space = if has_head(&(v22_3)) { singleton(&[]) } else { Space::new() };
        drop(v22_3);
        let v22_5: Space = subtract(&(*CONSTANT_0),&(v22_4));
        drop(v22_4);
        let v22_7: Space = if (v22_5).is_empty() { Space::new() } else {
          let mut v23_6 = Space::new();
          let mut v23_6_cursor = (v15_33_tail).read_zipper();
          for v23_6_byte in v23_6_cursor.child_mask().iter() {
            v23_6_cursor.descend_to_byte(v23_6_byte);
            let v23_6_tail = v23_6_cursor.make_map();
            v23_6_cursor.ascend(1);
            let v23_6_head = Path::from_slice(&[v23_6_byte]);
            let v24_2: Space = singleton(&(v23_6_head));
            let v24_3: Space = intersect(&(*CONSTANT_9),&(v24_2));
            let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
            drop(v24_3);
            let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
            drop(v24_4);
            let v24_8: Space = if (v24_5).is_empty() { Space::new() } else {
              let v25_6: Path = concat_path(&(v15_33_head),&(v23_6_head));
              let v25_7: Space = routine_7(c, &(v25_6), &(v23_6_tail));
              compose(&(v24_5),&(v25_7))
            };
            drop(v24_5);
            let v24_9: Space = intersect(&(*CONSTANT_9),&(v24_2));
            drop(v24_2);
            let v24_10: Space = if has_head(&(v24_9)) { singleton(&[]) } else { Space::new() };
            drop(v24_9);
            let v24_12: Space = if (v24_10).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v15_33_head),&(v23_6_head));
              let v26_11: Space = routine_8(c, &(v26_6), &(v23_6_tail));
              drop(v26_6);
              compose(&(v24_10),&(v26_11))
            };
            drop(v24_10);
            let v24_13: Space = unite(&(v24_8),&(v24_12));
            v23_6.join_into((v24_13).clone());
          }
          drop(v23_6_cursor);
          compose(&(v22_5),&(v23_6))
        };
        drop(v22_5);
        let v22_8: Space = intersect(&(*CONSTANT_9),&(v22_2));
        drop(v22_2);
        let v22_9: Space = if has_head(&(v22_8)) { singleton(&[]) } else { Space::new() };
        drop(v22_8);
        let v22_11: Space = if (v22_9).is_empty() { Space::new() } else {
          let mut v27_10 = Space::new();
          let mut v27_10_cursor = (v15_33_tail).read_zipper();
          for v27_10_byte in v27_10_cursor.child_mask().iter() {
            v27_10_cursor.descend_to_byte(v27_10_byte);
            let v27_10_tail = v27_10_cursor.make_map();
            v27_10_cursor.ascend(1);
            let v27_10_head = Path::from_slice(&[v27_10_byte]);
            let v28_2: Space = singleton(&(v27_10_head));
            let v28_3: Space = intersect(&(*CONSTANT_9),&(v28_2));
            let v28_4: Space = if has_head(&(v28_3)) { singleton(&[]) } else { Space::new() };
            drop(v28_3);
            let v28_5: Space = subtract(&(*CONSTANT_0),&(v28_4));
            drop(v28_4);
            let v28_8: Space = if (v28_5).is_empty() { Space::new() } else {
              let v29_6: Path = concat_path(&(v15_33_head),&(v27_10_head));
              let v29_7: Space = routine_7(c, &(v29_6), &(v27_10_tail));
              compose(&(v28_5),&(v29_7))
            };
            drop(v28_5);
            let v28_9: Space = intersect(&(*CONSTANT_9),&(v28_2));
            drop(v28_2);
            let v28_10: Space = if has_head(&(v28_9)) { singleton(&[]) } else { Space::new() };
            drop(v28_9);
            let v28_12: Space = if (v28_10).is_empty() { Space::new() } else {
              let v30_6: Path = concat_path(&(v15_33_head),&(v27_10_head));
              let v30_11: Space = routine_9(c, &(v30_6), &(v27_10_tail));
              drop(v30_6);
              compose(&(v28_10),&(v30_11))
            };
            drop(v28_10);
            let v28_13: Space = unite(&(v28_8),&(v28_12));
            v27_10.join_into((v28_13).clone());
          }
          drop(v27_10_cursor);
          compose(&(v22_9),&(v27_10))
        };
        drop(v22_9);
        let v22_12: Space = unite(&(v22_7),&(v22_11));
        v15_33.join_into((v22_12).clone());
      }
      drop(v15_33_cursor);
      let v15_34: Space = unite(&(v15_23),&(v15_33));
      let v15_35: Space = routine_14(c, &(v0_105_head), &(v0_105_tail), &(v15_14), &(*CONSTANT_10), &(v15_34));
      compose(&(v14_5),&(v15_35))
    };
    drop(v14_5);
    let v14_37: Space = intersect(&(*CONSTANT_9),&(v14_2));
    drop(v14_2);
    let v14_38: Space = if has_head(&(v14_37)) { singleton(&[]) } else { Space::new() };
    drop(v14_37);
    let v14_69: Space = if (v14_38).is_empty() { Space::new() } else {
      let v31_47: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v32_46: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v33_39: Space = routine_11(c, &(*CONSTANT_1), &(*CONSTANT_2));
          let v33_40: Space = routine_11(c, &(*CONSTANT_3), &(*CONSTANT_4));
          let v33_41: Space = unite(&(v33_39),&(v33_40));
          let v33_42: Space = routine_12(c, &(*CONSTANT_5), &(*CONSTANT_6));
          let v33_43: Space = unite(&(v33_41),&(v33_42));
          let v33_44: Space = routine_13(c, &(*CONSTANT_7), &(*CONSTANT_8));
          let v33_45: Space = unite(&(v33_43),&(v33_44));
          compose(&(*CONSTANT_0),&(v33_45))
        };
        compose(&(*CONSTANT_0),&(v32_46))
      };
      let v31_56: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v34_55: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v35_48: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
          let v35_49: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4));
          let v35_50: Space = unite(&(v35_48),&(v35_49));
          let v35_51: Space = routine_2(c, &(*CONSTANT_5), &(*CONSTANT_6));
          let v35_52: Space = unite(&(v35_50),&(v35_51));
          let v35_53: Space = routine_3(c, &(*CONSTANT_7), &(*CONSTANT_8));
          let v35_54: Space = unite(&(v35_52),&(v35_53));
          compose(&(*CONSTANT_0),&(v35_54))
        };
        compose(&(*CONSTANT_0),&(v34_55))
      };
      let v31_65: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v36_64: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v37_57: Space = routine_4(c, &(*CONSTANT_1), &(*CONSTANT_2));
          let v37_58: Space = routine_4(c, &(*CONSTANT_3), &(*CONSTANT_4));
          let v37_59: Space = unite(&(v37_57),&(v37_58));
          let v37_60: Space = routine_5(c, &(*CONSTANT_5), &(*CONSTANT_6));
          let v37_61: Space = unite(&(v37_59),&(v37_60));
          let v37_62: Space = routine_6(c, &(*CONSTANT_7), &(*CONSTANT_8));
          let v37_63: Space = unite(&(v37_61),&(v37_62));
          compose(&(*CONSTANT_0),&(v37_63))
        };
        compose(&(*CONSTANT_0),&(v36_64))
      };
      let mut v31_66 = Space::new();
      let mut v31_66_cursor = (v31_65).read_zipper();
      for v31_66_byte in v31_66_cursor.child_mask().iter() {
        v31_66_cursor.descend_to_byte(v31_66_byte);
        let v31_66_tail = v31_66_cursor.make_map();
        v31_66_cursor.ascend(1);
        let v31_66_head = Path::from_slice(&[v31_66_byte]);
        let v38_2: Space = singleton(&(v31_66_head));
        let v38_3: Space = intersect(&(*CONSTANT_9),&(v38_2));
        let v38_4: Space = if has_head(&(v38_3)) { singleton(&[]) } else { Space::new() };
        drop(v38_3);
        let v38_5: Space = subtract(&(*CONSTANT_0),&(v38_4));
        drop(v38_4);
        let v38_7: Space = if (v38_5).is_empty() { Space::new() } else {
          let mut v39_6 = Space::new();
          let mut v39_6_cursor = (v31_66_tail).read_zipper();
          for v39_6_byte in v39_6_cursor.child_mask().iter() {
            v39_6_cursor.descend_to_byte(v39_6_byte);
            let v39_6_tail = v39_6_cursor.make_map();
            v39_6_cursor.ascend(1);
            let v39_6_head = Path::from_slice(&[v39_6_byte]);
            let v40_2: Space = singleton(&(v39_6_head));
            let v40_3: Space = intersect(&(*CONSTANT_9),&(v40_2));
            let v40_4: Space = if has_head(&(v40_3)) { singleton(&[]) } else { Space::new() };
            drop(v40_3);
            let v40_5: Space = subtract(&(*CONSTANT_0),&(v40_4));
            drop(v40_4);
            let v40_8: Space = if (v40_5).is_empty() { Space::new() } else {
              let v41_6: Path = concat_path(&(v31_66_head),&(v39_6_head));
              let v41_7: Space = routine_7(c, &(v41_6), &(v39_6_tail));
              compose(&(v40_5),&(v41_7))
            };
            drop(v40_5);
            let v40_9: Space = intersect(&(*CONSTANT_9),&(v40_2));
            drop(v40_2);
            let v40_10: Space = if has_head(&(v40_9)) { singleton(&[]) } else { Space::new() };
            drop(v40_9);
            let v40_12: Space = if (v40_10).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v31_66_head),&(v39_6_head));
              let v42_11: Space = routine_8(c, &(v42_6), &(v39_6_tail));
              drop(v42_6);
              compose(&(v40_10),&(v42_11))
            };
            drop(v40_10);
            let v40_13: Space = unite(&(v40_8),&(v40_12));
            v39_6.join_into((v40_13).clone());
          }
          drop(v39_6_cursor);
          compose(&(v38_5),&(v39_6))
        };
        drop(v38_5);
        let v38_8: Space = intersect(&(*CONSTANT_9),&(v38_2));
        drop(v38_2);
        let v38_9: Space = if has_head(&(v38_8)) { singleton(&[]) } else { Space::new() };
        drop(v38_8);
        let v38_11: Space = if (v38_9).is_empty() { Space::new() } else {
          let mut v43_10 = Space::new();
          let mut v43_10_cursor = (v31_66_tail).read_zipper();
          for v43_10_byte in v43_10_cursor.child_mask().iter() {
            v43_10_cursor.descend_to_byte(v43_10_byte);
            let v43_10_tail = v43_10_cursor.make_map();
            v43_10_cursor.ascend(1);
            let v43_10_head = Path::from_slice(&[v43_10_byte]);
            let v44_2: Space = singleton(&(v43_10_head));
            let v44_3: Space = intersect(&(*CONSTANT_9),&(v44_2));
            let v44_4: Space = if has_head(&(v44_3)) { singleton(&[]) } else { Space::new() };
            drop(v44_3);
            let v44_5: Space = subtract(&(*CONSTANT_0),&(v44_4));
            drop(v44_4);
            let v44_8: Space = if (v44_5).is_empty() { Space::new() } else {
              let v45_6: Path = concat_path(&(v31_66_head),&(v43_10_head));
              let v45_7: Space = routine_7(c, &(v45_6), &(v43_10_tail));
              compose(&(v44_5),&(v45_7))
            };
            drop(v44_5);
            let v44_9: Space = intersect(&(*CONSTANT_9),&(v44_2));
            drop(v44_2);
            let v44_10: Space = if has_head(&(v44_9)) { singleton(&[]) } else { Space::new() };
            drop(v44_9);
            let v44_12: Space = if (v44_10).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v31_66_head),&(v43_10_head));
              let v46_11: Space = routine_9(c, &(v46_6), &(v43_10_tail));
              drop(v46_6);
              compose(&(v44_10),&(v46_11))
            };
            drop(v44_10);
            let v44_13: Space = unite(&(v44_8),&(v44_12));
            v43_10.join_into((v44_13).clone());
          }
          drop(v43_10_cursor);
          compose(&(v38_9),&(v43_10))
        };
        drop(v38_9);
        let v38_12: Space = unite(&(v38_7),&(v38_11));
        v31_66.join_into((v38_12).clone());
      }
      drop(v31_66_cursor);
      let v31_67: Space = unite(&(v31_56),&(v31_66));
      let v31_68: Space = routine_15(c, &(v0_105_head), &(v0_105_tail), &(v31_47), &(*CONSTANT_10), &(v31_67));
      compose(&(v14_38),&(v31_68))
    };
    drop(v14_38);
    let v14_70: Space = unite(&(v14_36),&(v14_69));
    v0_105.join_into((v14_70).clone());
  }
  drop(v0_105_cursor);
  (v0_105).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v47_11 = Space::new();
  let mut v47_11_cursor = (*s0).read_zipper();
  for v47_11_byte in v47_11_cursor.child_mask().iter() {
    v47_11_cursor.descend_to_byte(v47_11_byte);
    let v47_11_tail = v47_11_cursor.make_map();
    v47_11_cursor.ascend(1);
    let v47_11_head = Path::from_slice(&[v47_11_byte]);
    let v48_2: Space = singleton(&(v47_11_head));
    let v48_3: Space = intersect(&(*CONSTANT_9),&(v48_2));
    let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
    drop(v48_3);
    let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
    drop(v48_4);
    let v48_8: Space = if (v48_5).is_empty() { Space::new() } else {
      let v49_6: Path = concat_path(&(*p0),&(v47_11_head));
      let mut v49_7 = Space::new();
      let mut v49_7_cursor = (v47_11_tail).read_zipper();
      for v49_7_byte in v49_7_cursor.child_mask().iter() {
        v49_7_cursor.descend_to_byte(v49_7_byte);
        let v49_7_tail = v49_7_cursor.make_map();
        v49_7_cursor.ascend(1);
        let v49_7_head = Path::from_slice(&[v49_7_byte]);
        let v50_2: Space = singleton(&(v49_7_head));
        let v50_3: Space = intersect(&(*CONSTANT_9),&(v50_2));
        let v50_4: Space = if has_head(&(v50_3)) { singleton(&[]) } else { Space::new() };
        drop(v50_3);
        let v50_5: Space = subtract(&(*CONSTANT_0),&(v50_4));
        drop(v50_4);
        let v50_8: Space = if (v50_5).is_empty() { Space::new() } else {
          let v51_6: Path = concat_path(&(v49_6),&(v49_7_head));
          let v51_7: Space = routine_16(c, &(v51_6), &(v49_7_tail));
          compose(&(v50_5),&(v51_7))
        };
        drop(v50_5);
        let v50_9: Space = intersect(&(*CONSTANT_9),&(v50_2));
        drop(v50_2);
        let v50_10: Space = if has_head(&(v50_9)) { singleton(&[]) } else { Space::new() };
        drop(v50_9);
        let v50_12: Space = if (v50_10).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v49_6),&(v49_7_head));
          let v52_11: Space = routine_17(c, &(v52_6), &(v49_7_tail));
          drop(v52_6);
          compose(&(v50_10),&(v52_11))
        };
        drop(v50_10);
        let v50_13: Space = unite(&(v50_8),&(v50_12));
        v49_7.join_into((v50_13).clone());
      }
      drop(v49_7_cursor);
      compose(&(v48_5),&(v49_7))
    };
    drop(v48_5);
    let v48_9: Space = intersect(&(*CONSTANT_9),&(v48_2));
    drop(v48_2);
    let v48_10: Space = if has_head(&(v48_9)) { singleton(&[]) } else { Space::new() };
    drop(v48_9);
    let v48_12: Space = if (v48_10).is_empty() { Space::new() } else {
      let v53_6: Path = concat_path(&(*p0),&(v47_11_head));
      let mut v53_11 = Space::new();
      let mut v53_11_cursor = (v47_11_tail).read_zipper();
      for v53_11_byte in v53_11_cursor.child_mask().iter() {
        v53_11_cursor.descend_to_byte(v53_11_byte);
        let v53_11_tail = v53_11_cursor.make_map();
        v53_11_cursor.ascend(1);
        let v53_11_head = Path::from_slice(&[v53_11_byte]);
        let v54_2: Space = singleton(&(v53_11_head));
        let v54_3: Space = intersect(&(*CONSTANT_9),&(v54_2));
        let v54_4: Space = if has_head(&(v54_3)) { singleton(&[]) } else { Space::new() };
        drop(v54_3);
        let v54_5: Space = subtract(&(*CONSTANT_0),&(v54_4));
        drop(v54_4);
        let v54_8: Space = if (v54_5).is_empty() { Space::new() } else {
          let v55_6: Path = concat_path(&(v53_6),&(v53_11_head));
          let v55_7: Space = routine_16(c, &(v55_6), &(v53_11_tail));
          compose(&(v54_5),&(v55_7))
        };
        drop(v54_5);
        let v54_9: Space = intersect(&(*CONSTANT_9),&(v54_2));
        drop(v54_2);
        let v54_10: Space = if has_head(&(v54_9)) { singleton(&[]) } else { Space::new() };
        drop(v54_9);
        let v54_12: Space = if (v54_10).is_empty() { Space::new() } else {
          let v56_6: Path = concat_path(&(v53_6),&(v53_11_head));
          let v56_11: Space = routine_3(c, &(v56_6), &(v53_11_tail));
          drop(v56_6);
          compose(&(v54_10),&(v56_11))
        };
        drop(v54_10);
        let v54_13: Space = unite(&(v54_8),&(v54_12));
        v53_11.join_into((v54_13).clone());
      }
      drop(v53_11_cursor);
      drop(v53_6);
      compose(&(v48_10),&(v53_11))
    };
    drop(v48_10);
    let v48_13: Space = unite(&(v48_8),&(v48_12));
    v47_11.join_into((v48_13).clone());
  }
  drop(v47_11_cursor);
  (v47_11).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v57_8 = Space::new();
  let mut v57_8_cursor = (*s0).read_zipper();
  for v57_8_byte in v57_8_cursor.child_mask().iter() {
    v57_8_cursor.descend_to_byte(v57_8_byte);
    let v57_8_tail = v57_8_cursor.make_map();
    v57_8_cursor.ascend(1);
    let v57_8_head = Path::from_slice(&[v57_8_byte]);
    let v58_2: Space = singleton(&(v57_8_head));
    let v58_3: Space = intersect(&(*CONSTANT_9),&(v58_2));
    let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
    drop(v58_3);
    let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
    drop(v58_4);
    let v58_8: Space = if (v58_5).is_empty() { Space::new() } else {
      let v59_6: Path = concat_path(&(*p0),&(v57_8_head));
      let mut v59_7 = Space::new();
      let mut v59_7_cursor = (v57_8_tail).read_zipper();
      for v59_7_byte in v59_7_cursor.child_mask().iter() {
        v59_7_cursor.descend_to_byte(v59_7_byte);
        let v59_7_tail = v59_7_cursor.make_map();
        v59_7_cursor.ascend(1);
        let v59_7_head = Path::from_slice(&[v59_7_byte]);
        let v60_2: Space = singleton(&(v59_7_head));
        let v60_3: Space = intersect(&(*CONSTANT_9),&(v60_2));
        let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
        drop(v60_3);
        let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
        drop(v60_4);
        let v60_8: Space = if (v60_5).is_empty() { Space::new() } else {
          let v61_6: Path = concat_path(&(v59_6),&(v59_7_head));
          let v61_7: Space = routine_16(c, &(v61_6), &(v59_7_tail));
          compose(&(v60_5),&(v61_7))
        };
        drop(v60_5);
        let v60_9: Space = intersect(&(*CONSTANT_9),&(v60_2));
        drop(v60_2);
        let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
        drop(v60_9);
        let v60_12: Space = if (v60_10).is_empty() { Space::new() } else {
          let v62_6: Path = concat_path(&(v59_6),&(v59_7_head));
          let v62_11: Space = routine_17(c, &(v62_6), &(v59_7_tail));
          drop(v62_6);
          compose(&(v60_10),&(v62_11))
        };
        drop(v60_10);
        let v60_13: Space = unite(&(v60_8),&(v60_12));
        v59_7.join_into((v60_13).clone());
      }
      drop(v59_7_cursor);
      compose(&(v58_5),&(v59_7))
    };
    drop(v58_5);
    let v58_9: Space = intersect(&(*CONSTANT_9),&(v58_2));
    drop(v58_2);
    let v58_10: Space = if has_head(&(v58_9)) { singleton(&[]) } else { Space::new() };
    drop(v58_9);
    let v58_12: Space = if (v58_10).is_empty() { Space::new() } else {
      let v63_6: Path = concat_path(&(*p0),&(v57_8_head));
      let v63_11: Space = singleton(&(v63_6));
      drop(v63_6);
      compose(&(v58_10),&(v63_11))
    };
    drop(v58_10);
    let v58_13: Space = unite(&(v58_8),&(v58_12));
    drop(v58_12);
    v57_8.join_into((v58_13).clone());
  }
  drop(v57_8_cursor);
  (v57_8).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v64_2: Space = singleton(&(*p0));
  (v64_2).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v65_11 = Space::new();
  let mut v65_11_cursor = (*s0).read_zipper();
  for v65_11_byte in v65_11_cursor.child_mask().iter() {
    v65_11_cursor.descend_to_byte(v65_11_byte);
    let v65_11_tail = v65_11_cursor.make_map();
    v65_11_cursor.ascend(1);
    let v65_11_head = Path::from_slice(&[v65_11_byte]);
    let v66_2: Space = singleton(&(v65_11_head));
    let v66_3: Space = intersect(&(*CONSTANT_9),&(v66_2));
    let v66_4: Space = if has_head(&(v66_3)) { singleton(&[]) } else { Space::new() };
    drop(v66_3);
    let v66_5: Space = subtract(&(*CONSTANT_0),&(v66_4));
    drop(v66_4);
    let v66_8: Space = if (v66_5).is_empty() { Space::new() } else {
      let v67_6: Path = concat_path(&(*p0),&(v65_11_head));
      let mut v67_7 = Space::new();
      let mut v67_7_cursor = (v65_11_tail).read_zipper();
      for v67_7_byte in v67_7_cursor.child_mask().iter() {
        v67_7_cursor.descend_to_byte(v67_7_byte);
        let v67_7_tail = v67_7_cursor.make_map();
        v67_7_cursor.ascend(1);
        let v67_7_head = Path::from_slice(&[v67_7_byte]);
        let v68_2: Space = singleton(&(v67_7_head));
        let v68_3: Space = intersect(&(*CONSTANT_9),&(v68_2));
        let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
        drop(v68_3);
        let v68_5: Space = subtract(&(*CONSTANT_0),&(v68_4));
        drop(v68_4);
        let v68_8: Space = if (v68_5).is_empty() { Space::new() } else {
          let v69_6: Path = concat_path(&(v67_6),&(v67_7_head));
          let v69_7: Space = routine_18(c, &(v69_6), &(v67_7_tail));
          compose(&(v68_5),&(v69_7))
        };
        drop(v68_5);
        let v68_9: Space = intersect(&(*CONSTANT_9),&(v68_2));
        drop(v68_2);
        let v68_10: Space = if has_head(&(v68_9)) { singleton(&[]) } else { Space::new() };
        drop(v68_9);
        let v68_12: Space = if (v68_10).is_empty() { Space::new() } else {
          let v70_6: Path = concat_path(&(v67_6),&(v67_7_head));
          let v70_11: Space = routine_19(c, &(v70_6), &(v67_7_tail));
          drop(v70_6);
          compose(&(v68_10),&(v70_11))
        };
        drop(v68_10);
        let v68_13: Space = unite(&(v68_8),&(v68_12));
        v67_7.join_into((v68_13).clone());
      }
      drop(v67_7_cursor);
      compose(&(v66_5),&(v67_7))
    };
    drop(v66_5);
    let v66_9: Space = intersect(&(*CONSTANT_9),&(v66_2));
    drop(v66_2);
    let v66_10: Space = if has_head(&(v66_9)) { singleton(&[]) } else { Space::new() };
    drop(v66_9);
    let v66_12: Space = if (v66_10).is_empty() { Space::new() } else {
      let v71_6: Path = concat_path(&(*p0),&(v65_11_head));
      let mut v71_11 = Space::new();
      let mut v71_11_cursor = (v65_11_tail).read_zipper();
      for v71_11_byte in v71_11_cursor.child_mask().iter() {
        v71_11_cursor.descend_to_byte(v71_11_byte);
        let v71_11_tail = v71_11_cursor.make_map();
        v71_11_cursor.ascend(1);
        let v71_11_head = Path::from_slice(&[v71_11_byte]);
        let v72_2: Space = singleton(&(v71_11_head));
        let v72_3: Space = intersect(&(*CONSTANT_9),&(v72_2));
        let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
        drop(v72_3);
        let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
        drop(v72_4);
        let v72_8: Space = if (v72_5).is_empty() { Space::new() } else {
          let v73_6: Path = concat_path(&(v71_6),&(v71_11_head));
          let v73_7: Space = routine_18(c, &(v73_6), &(v71_11_tail));
          compose(&(v72_5),&(v73_7))
        };
        drop(v72_5);
        let v72_9: Space = intersect(&(*CONSTANT_9),&(v72_2));
        drop(v72_2);
        let v72_10: Space = if has_head(&(v72_9)) { singleton(&[]) } else { Space::new() };
        drop(v72_9);
        let v72_12: Space = if (v72_10).is_empty() { Space::new() } else {
          let v74_6: Path = concat_path(&(v71_6),&(v71_11_head));
          let v74_11: Space = routine_6(c, &(v74_6), &(v71_11_tail));
          drop(v74_6);
          compose(&(v72_10),&(v74_11))
        };
        drop(v72_10);
        let v72_13: Space = unite(&(v72_8),&(v72_12));
        v71_11.join_into((v72_13).clone());
      }
      drop(v71_11_cursor);
      drop(v71_6);
      compose(&(v66_10),&(v71_11))
    };
    drop(v66_10);
    let v66_13: Space = unite(&(v66_8),&(v66_12));
    v65_11.join_into((v66_13).clone());
  }
  drop(v65_11_cursor);
  (v65_11).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v75_11 = Space::new();
  let mut v75_11_cursor = (*s0).read_zipper();
  for v75_11_byte in v75_11_cursor.child_mask().iter() {
    v75_11_cursor.descend_to_byte(v75_11_byte);
    let v75_11_tail = v75_11_cursor.make_map();
    v75_11_cursor.ascend(1);
    let v75_11_head = Path::from_slice(&[v75_11_byte]);
    let v76_2: Space = singleton(&(v75_11_head));
    let v76_3: Space = intersect(&(*CONSTANT_9),&(v76_2));
    let v76_4: Space = if has_head(&(v76_3)) { singleton(&[]) } else { Space::new() };
    drop(v76_3);
    let v76_5: Space = subtract(&(*CONSTANT_0),&(v76_4));
    drop(v76_4);
    let v76_8: Space = if (v76_5).is_empty() { Space::new() } else {
      let v77_6: Path = concat_path(&(*p0),&(v75_11_head));
      let mut v77_7 = Space::new();
      let mut v77_7_cursor = (v75_11_tail).read_zipper();
      for v77_7_byte in v77_7_cursor.child_mask().iter() {
        v77_7_cursor.descend_to_byte(v77_7_byte);
        let v77_7_tail = v77_7_cursor.make_map();
        v77_7_cursor.ascend(1);
        let v77_7_head = Path::from_slice(&[v77_7_byte]);
        let v78_2: Space = singleton(&(v77_7_head));
        let v78_3: Space = intersect(&(*CONSTANT_9),&(v78_2));
        let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
        drop(v78_3);
        let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
        drop(v78_4);
        let v78_8: Space = if (v78_5).is_empty() { Space::new() } else {
          let v79_6: Path = concat_path(&(v77_6),&(v77_7_head));
          let v79_7: Space = routine_18(c, &(v79_6), &(v77_7_tail));
          compose(&(v78_5),&(v79_7))
        };
        drop(v78_5);
        let v78_9: Space = intersect(&(*CONSTANT_9),&(v78_2));
        drop(v78_2);
        let v78_10: Space = if has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
        drop(v78_9);
        let v78_12: Space = if (v78_10).is_empty() { Space::new() } else {
          let v80_6: Path = concat_path(&(v77_6),&(v77_7_head));
          let v80_11: Space = routine_19(c, &(v80_6), &(v77_7_tail));
          drop(v80_6);
          compose(&(v78_10),&(v80_11))
        };
        drop(v78_10);
        let v78_13: Space = unite(&(v78_8),&(v78_12));
        v77_7.join_into((v78_13).clone());
      }
      drop(v77_7_cursor);
      compose(&(v76_5),&(v77_7))
    };
    drop(v76_5);
    let v76_9: Space = intersect(&(*CONSTANT_9),&(v76_2));
    drop(v76_2);
    let v76_10: Space = if has_head(&(v76_9)) { singleton(&[]) } else { Space::new() };
    drop(v76_9);
    let v76_12: Space = if (v76_10).is_empty() { Space::new() } else {
      let v81_6: Path = concat_path(&(*p0),&(v75_11_head));
      let mut v81_11 = Space::new();
      let mut v81_11_cursor = (v75_11_tail).read_zipper();
      for v81_11_byte in v81_11_cursor.child_mask().iter() {
        v81_11_cursor.descend_to_byte(v81_11_byte);
        let v81_11_tail = v81_11_cursor.make_map();
        v81_11_cursor.ascend(1);
        let v81_11_head = Path::from_slice(&[v81_11_byte]);
        let v82_2: Space = singleton(&(v81_11_head));
        let v82_3: Space = intersect(&(*CONSTANT_9),&(v82_2));
        let v82_4: Space = if has_head(&(v82_3)) { singleton(&[]) } else { Space::new() };
        drop(v82_3);
        let v82_5: Space = subtract(&(*CONSTANT_0),&(v82_4));
        drop(v82_4);
        let v82_7: Space = if (v82_5).is_empty() { Space::new() } else {
          let v83_6: Space = routine_20(c, &(v81_11_head), &(v81_6), &(v81_11_tail));
          compose(&(v82_5),&(v83_6))
        };
        drop(v82_5);
        let v82_8: Space = intersect(&(*CONSTANT_9),&(v82_2));
        drop(v82_2);
        let v82_9: Space = if has_head(&(v82_8)) { singleton(&[]) } else { Space::new() };
        drop(v82_8);
        let v82_11: Space = if (v82_9).is_empty() { Space::new() } else {
          let v84_10: Space = routine_21(c, &(v81_11_head), &(v81_6), &(v81_11_tail));
          compose(&(v82_9),&(v84_10))
        };
        drop(v82_9);
        let v82_12: Space = unite(&(v82_7),&(v82_11));
        v81_11.join_into((v82_12).clone());
      }
      drop(v81_11_cursor);
      drop(v81_6);
      compose(&(v76_10),&(v81_11))
    };
    drop(v76_10);
    let v76_13: Space = unite(&(v76_8),&(v76_12));
    v75_11.join_into((v76_13).clone());
  }
  drop(v75_11_cursor);
  (v75_11).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v85_11 = Space::new();
  let mut v85_11_cursor = (*s0).read_zipper();
  for v85_11_byte in v85_11_cursor.child_mask().iter() {
    v85_11_cursor.descend_to_byte(v85_11_byte);
    let v85_11_tail = v85_11_cursor.make_map();
    v85_11_cursor.ascend(1);
    let v85_11_head = Path::from_slice(&[v85_11_byte]);
    let v86_2: Space = singleton(&(v85_11_head));
    let v86_3: Space = intersect(&(*CONSTANT_9),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (v86_5).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_cursor = (v85_11_tail).read_zipper();
      for v87_6_byte in v87_6_cursor.child_mask().iter() {
        v87_6_cursor.descend_to_byte(v87_6_byte);
        let v87_6_tail = v87_6_cursor.make_map();
        v87_6_cursor.ascend(1);
        let v87_6_head = Path::from_slice(&[v87_6_byte]);
        let v88_2: Space = singleton(&(v87_6_head));
        let v88_3: Space = intersect(&(*CONSTANT_9),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
          let v89_6: Path = concat_path(&(v85_11_head),&(v87_6_head));
          let v89_7: Space = routine_22(c, &(v89_6), &(*p0), &(v87_6_tail));
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_9),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
          let v90_6: Path = concat_path(&(v85_11_head),&(v87_6_head));
          let v90_11: Space = routine_23(c, &(v90_6), &(*p0), &(v87_6_tail));
          drop(v90_6);
          compose(&(v88_10),&(v90_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        v87_6.join_into((v88_13).clone());
      }
      drop(v87_6_cursor);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_9),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (v86_9).is_empty() { Space::new() } else {
      let mut v91_10 = Space::new();
      let mut v91_10_cursor = (v85_11_tail).read_zipper();
      for v91_10_byte in v91_10_cursor.child_mask().iter() {
        v91_10_cursor.descend_to_byte(v91_10_byte);
        let v91_10_tail = v91_10_cursor.make_map();
        v91_10_cursor.ascend(1);
        let v91_10_head = Path::from_slice(&[v91_10_byte]);
        let v92_2: Space = singleton(&(v91_10_head));
        let v92_3: Space = intersect(&(*CONSTANT_9),&(v92_2));
        let v92_4: Space = if has_head(&(v92_3)) { singleton(&[]) } else { Space::new() };
        drop(v92_3);
        let v92_5: Space = subtract(&(*CONSTANT_0),&(v92_4));
        drop(v92_4);
        let v92_8: Space = if (v92_5).is_empty() { Space::new() } else {
          let v93_6: Path = concat_path(&(v85_11_head),&(v91_10_head));
          let v93_7: Space = routine_22(c, &(v93_6), &(*p0), &(v91_10_tail));
          compose(&(v92_5),&(v93_7))
        };
        drop(v92_5);
        let v92_9: Space = intersect(&(*CONSTANT_9),&(v92_2));
        drop(v92_2);
        let v92_10: Space = if has_head(&(v92_9)) { singleton(&[]) } else { Space::new() };
        drop(v92_9);
        let v92_12: Space = if (v92_10).is_empty() { Space::new() } else {
          let v94_6: Path = concat_path(&(v85_11_head),&(v91_10_head));
          let v94_11: Space = routine_24(c, &(v94_6), &(*p0), &(v91_10_tail));
          drop(v94_6);
          compose(&(v92_10),&(v94_11))
        };
        drop(v92_10);
        let v92_13: Space = unite(&(v92_8),&(v92_12));
        v91_10.join_into((v92_13).clone());
      }
      drop(v91_10_cursor);
      compose(&(v86_9),&(v91_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    v85_11.join_into((v86_12).clone());
  }
  drop(v85_11_cursor);
  (v85_11).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v95_11 = Space::new();
  let mut v95_11_cursor = (*s0).read_zipper();
  for v95_11_byte in v95_11_cursor.child_mask().iter() {
    v95_11_cursor.descend_to_byte(v95_11_byte);
    let v95_11_tail = v95_11_cursor.make_map();
    v95_11_cursor.ascend(1);
    let v95_11_head = Path::from_slice(&[v95_11_byte]);
    let v96_2: Space = singleton(&(v95_11_head));
    let v96_3: Space = intersect(&(*CONSTANT_9),&(v96_2));
    let v96_4: Space = if has_head(&(v96_3)) { singleton(&[]) } else { Space::new() };
    drop(v96_3);
    let v96_5: Space = subtract(&(*CONSTANT_0),&(v96_4));
    drop(v96_4);
    let v96_8: Space = if (v96_5).is_empty() { Space::new() } else {
      let v97_6: Path = concat_path(&(*p0),&(v95_11_head));
      let mut v97_7 = Space::new();
      let mut v97_7_cursor = (v95_11_tail).read_zipper();
      for v97_7_byte in v97_7_cursor.child_mask().iter() {
        v97_7_cursor.descend_to_byte(v97_7_byte);
        let v97_7_tail = v97_7_cursor.make_map();
        v97_7_cursor.ascend(1);
        let v97_7_head = Path::from_slice(&[v97_7_byte]);
        let v98_2: Space = singleton(&(v97_7_head));
        let v98_3: Space = intersect(&(*CONSTANT_9),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (v98_5).is_empty() { Space::new() } else {
          let v99_6: Path = concat_path(&(v97_6),&(v97_7_head));
          let v99_7: Space = routine_25(c, &(v99_6), &(v97_7_tail));
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_9),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_12: Space = if (v98_10).is_empty() { Space::new() } else {
          let v100_6: Path = concat_path(&(v97_6),&(v97_7_head));
          let v100_11: Space = routine_26(c, &(v100_6), &(v97_7_tail));
          drop(v100_6);
          compose(&(v98_10),&(v100_11))
        };
        drop(v98_10);
        let v98_13: Space = unite(&(v98_8),&(v98_12));
        v97_7.join_into((v98_13).clone());
      }
      drop(v97_7_cursor);
      compose(&(v96_5),&(v97_7))
    };
    drop(v96_5);
    let v96_9: Space = intersect(&(*CONSTANT_9),&(v96_2));
    drop(v96_2);
    let v96_10: Space = if has_head(&(v96_9)) { singleton(&[]) } else { Space::new() };
    drop(v96_9);
    let v96_12: Space = if (v96_10).is_empty() { Space::new() } else {
      let v101_6: Path = concat_path(&(*p0),&(v95_11_head));
      let mut v101_11 = Space::new();
      let mut v101_11_cursor = (v95_11_tail).read_zipper();
      for v101_11_byte in v101_11_cursor.child_mask().iter() {
        v101_11_cursor.descend_to_byte(v101_11_byte);
        let v101_11_tail = v101_11_cursor.make_map();
        v101_11_cursor.ascend(1);
        let v101_11_head = Path::from_slice(&[v101_11_byte]);
        let v102_2: Space = singleton(&(v101_11_head));
        let v102_3: Space = intersect(&(*CONSTANT_9),&(v102_2));
        let v102_4: Space = if has_head(&(v102_3)) { singleton(&[]) } else { Space::new() };
        drop(v102_3);
        let v102_5: Space = subtract(&(*CONSTANT_0),&(v102_4));
        drop(v102_4);
        let v102_8: Space = if (v102_5).is_empty() { Space::new() } else {
          let v103_6: Path = concat_path(&(v101_6),&(v101_11_head));
          let v103_7: Space = routine_25(c, &(v103_6), &(v101_11_tail));
          compose(&(v102_5),&(v103_7))
        };
        drop(v102_5);
        let v102_9: Space = intersect(&(*CONSTANT_9),&(v102_2));
        drop(v102_2);
        let v102_10: Space = if has_head(&(v102_9)) { singleton(&[]) } else { Space::new() };
        drop(v102_9);
        let v102_12: Space = if (v102_10).is_empty() { Space::new() } else {
          let v104_6: Path = concat_path(&(v101_6),&(v101_11_head));
          let v104_11: Space = routine_9(c, &(v104_6), &(v101_11_tail));
          drop(v104_6);
          compose(&(v102_10),&(v104_11))
        };
        drop(v102_10);
        let v102_13: Space = unite(&(v102_8),&(v102_12));
        v101_11.join_into((v102_13).clone());
      }
      drop(v101_11_cursor);
      drop(v101_6);
      compose(&(v96_10),&(v101_11))
    };
    drop(v96_10);
    let v96_13: Space = unite(&(v96_8),&(v96_12));
    v95_11.join_into((v96_13).clone());
  }
  drop(v95_11_cursor);
  (v95_11).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v105_8 = Space::new();
  let mut v105_8_cursor = (*s0).read_zipper();
  for v105_8_byte in v105_8_cursor.child_mask().iter() {
    v105_8_cursor.descend_to_byte(v105_8_byte);
    let v105_8_tail = v105_8_cursor.make_map();
    v105_8_cursor.ascend(1);
    let v105_8_head = Path::from_slice(&[v105_8_byte]);
    let v106_2: Space = singleton(&(v105_8_head));
    let v106_3: Space = intersect(&(*CONSTANT_9),&(v106_2));
    let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
    drop(v106_3);
    let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
    drop(v106_4);
    let v106_8: Space = if (v106_5).is_empty() { Space::new() } else {
      let v107_6: Path = concat_path(&(*p0),&(v105_8_head));
      let mut v107_7 = Space::new();
      let mut v107_7_cursor = (v105_8_tail).read_zipper();
      for v107_7_byte in v107_7_cursor.child_mask().iter() {
        v107_7_cursor.descend_to_byte(v107_7_byte);
        let v107_7_tail = v107_7_cursor.make_map();
        v107_7_cursor.ascend(1);
        let v107_7_head = Path::from_slice(&[v107_7_byte]);
        let v108_2: Space = singleton(&(v107_7_head));
        let v108_3: Space = intersect(&(*CONSTANT_9),&(v108_2));
        let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
        drop(v108_3);
        let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
        drop(v108_4);
        let v108_8: Space = if (v108_5).is_empty() { Space::new() } else {
          let v109_6: Path = concat_path(&(v107_6),&(v107_7_head));
          let v109_7: Space = routine_25(c, &(v109_6), &(v107_7_tail));
          compose(&(v108_5),&(v109_7))
        };
        drop(v108_5);
        let v108_9: Space = intersect(&(*CONSTANT_9),&(v108_2));
        drop(v108_2);
        let v108_10: Space = if has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
        drop(v108_9);
        let v108_12: Space = if (v108_10).is_empty() { Space::new() } else {
          let v110_6: Path = concat_path(&(v107_6),&(v107_7_head));
          let v110_11: Space = routine_26(c, &(v110_6), &(v107_7_tail));
          drop(v110_6);
          compose(&(v108_10),&(v110_11))
        };
        drop(v108_10);
        let v108_13: Space = unite(&(v108_8),&(v108_12));
        v107_7.join_into((v108_13).clone());
      }
      drop(v107_7_cursor);
      compose(&(v106_5),&(v107_7))
    };
    drop(v106_5);
    let v106_9: Space = intersect(&(*CONSTANT_9),&(v106_2));
    drop(v106_2);
    let v106_10: Space = if has_head(&(v106_9)) { singleton(&[]) } else { Space::new() };
    drop(v106_9);
    let v106_12: Space = if (v106_10).is_empty() { Space::new() } else {
      let v111_6: Path = concat_path(&(*p0),&(v105_8_head));
      let v111_11: Space = singleton(&(v111_6));
      drop(v111_6);
      compose(&(v106_10),&(v111_11))
    };
    drop(v106_10);
    let v106_13: Space = unite(&(v106_8),&(v106_12));
    drop(v106_12);
    v105_8.join_into((v106_13).clone());
  }
  drop(v105_8_cursor);
  (v105_8).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v112_2: Space = singleton(&(*p0));
  (v112_2).clone()
}

fn routine_10(c: &mut Context, s0: &Space) -> Space {
  let v113_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v113_2: Space = first_matching(&(*s0),&(*CONSTANT_0),false);
  let v113_3: Space = unite(&(v113_1),&(v113_2));
  drop(v113_1);
  drop(v113_2);
  let v113_6: Space = if (v113_3).is_empty() { Space::new() } else {
    let v114_4: Space = routine_27(c, &(*s0));
    let v114_5: Space = subtract(&(*s0),&(v114_4));
    compose(&(v113_3),&(v114_5))
  };
  drop(v113_3);
  let v113_7: Space = subtract(&(*s0),&(v113_6));
  (v113_7).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v115_11 = Space::new();
  let mut v115_11_cursor = (*s0).read_zipper();
  for v115_11_byte in v115_11_cursor.child_mask().iter() {
    v115_11_cursor.descend_to_byte(v115_11_byte);
    let v115_11_tail = v115_11_cursor.make_map();
    v115_11_cursor.ascend(1);
    let v115_11_head = Path::from_slice(&[v115_11_byte]);
    let v116_2: Space = singleton(&(v115_11_head));
    let v116_3: Space = intersect(&(*CONSTANT_9),&(v116_2));
    let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
    drop(v116_3);
    let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
    drop(v116_4);
    let v116_8: Space = if (v116_5).is_empty() { Space::new() } else {
      let v117_6: Path = concat_path(&(*p0),&(v115_11_head));
      let mut v117_7 = Space::new();
      let mut v117_7_cursor = (v115_11_tail).read_zipper();
      for v117_7_byte in v117_7_cursor.child_mask().iter() {
        v117_7_cursor.descend_to_byte(v117_7_byte);
        let v117_7_tail = v117_7_cursor.make_map();
        v117_7_cursor.ascend(1);
        let v117_7_head = Path::from_slice(&[v117_7_byte]);
        let v118_2: Space = singleton(&(v117_7_head));
        let v118_3: Space = intersect(&(*CONSTANT_9),&(v118_2));
        let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
        drop(v118_3);
        let v118_5: Space = subtract(&(*CONSTANT_0),&(v118_4));
        drop(v118_4);
        let v118_8: Space = if (v118_5).is_empty() { Space::new() } else {
          let v119_6: Path = concat_path(&(v117_6),&(v117_7_head));
          let v119_7: Space = routine_28(c, &(v119_6), &(v117_7_tail));
          compose(&(v118_5),&(v119_7))
        };
        drop(v118_5);
        let v118_9: Space = intersect(&(*CONSTANT_9),&(v118_2));
        drop(v118_2);
        let v118_10: Space = if has_head(&(v118_9)) { singleton(&[]) } else { Space::new() };
        drop(v118_9);
        let v118_12: Space = if (v118_10).is_empty() { Space::new() } else {
          let v120_6: Path = concat_path(&(v117_6),&(v117_7_head));
          let v120_11: Space = routine_29(c, &(v120_6), &(v117_7_tail));
          drop(v120_6);
          compose(&(v118_10),&(v120_11))
        };
        drop(v118_10);
        let v118_13: Space = unite(&(v118_8),&(v118_12));
        v117_7.join_into((v118_13).clone());
      }
      drop(v117_7_cursor);
      compose(&(v116_5),&(v117_7))
    };
    drop(v116_5);
    let v116_9: Space = intersect(&(*CONSTANT_9),&(v116_2));
    drop(v116_2);
    let v116_10: Space = if has_head(&(v116_9)) { singleton(&[]) } else { Space::new() };
    drop(v116_9);
    let v116_12: Space = if (v116_10).is_empty() { Space::new() } else {
      let v121_6: Path = concat_path(&(*p0),&(v115_11_head));
      let mut v121_11 = Space::new();
      let mut v121_11_cursor = (v115_11_tail).read_zipper();
      for v121_11_byte in v121_11_cursor.child_mask().iter() {
        v121_11_cursor.descend_to_byte(v121_11_byte);
        let v121_11_tail = v121_11_cursor.make_map();
        v121_11_cursor.ascend(1);
        let v121_11_head = Path::from_slice(&[v121_11_byte]);
        let v122_2: Space = singleton(&(v121_11_head));
        let v122_3: Space = intersect(&(*CONSTANT_9),&(v122_2));
        let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
        drop(v122_3);
        let v122_5: Space = subtract(&(*CONSTANT_0),&(v122_4));
        drop(v122_4);
        let v122_8: Space = if (v122_5).is_empty() { Space::new() } else {
          let v123_6: Path = concat_path(&(v121_6),&(v121_11_head));
          let v123_7: Space = routine_28(c, &(v123_6), &(v121_11_tail));
          compose(&(v122_5),&(v123_7))
        };
        drop(v122_5);
        let v122_9: Space = intersect(&(*CONSTANT_9),&(v122_2));
        drop(v122_2);
        let v122_10: Space = if has_head(&(v122_9)) { singleton(&[]) } else { Space::new() };
        drop(v122_9);
        let v122_12: Space = if (v122_10).is_empty() { Space::new() } else {
          let v124_6: Path = concat_path(&(v121_6),&(v121_11_head));
          let v124_11: Space = routine_13(c, &(v124_6), &(v121_11_tail));
          drop(v124_6);
          compose(&(v122_10),&(v124_11))
        };
        drop(v122_10);
        let v122_13: Space = unite(&(v122_8),&(v122_12));
        v121_11.join_into((v122_13).clone());
      }
      drop(v121_11_cursor);
      drop(v121_6);
      compose(&(v116_10),&(v121_11))
    };
    drop(v116_10);
    let v116_13: Space = unite(&(v116_8),&(v116_12));
    v115_11.join_into((v116_13).clone());
  }
  drop(v115_11_cursor);
  (v115_11).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v125_11 = Space::new();
  let mut v125_11_cursor = (*s0).read_zipper();
  for v125_11_byte in v125_11_cursor.child_mask().iter() {
    v125_11_cursor.descend_to_byte(v125_11_byte);
    let v125_11_tail = v125_11_cursor.make_map();
    v125_11_cursor.ascend(1);
    let v125_11_head = Path::from_slice(&[v125_11_byte]);
    let v126_2: Space = singleton(&(v125_11_head));
    let v126_3: Space = intersect(&(*CONSTANT_9),&(v126_2));
    let v126_4: Space = if has_head(&(v126_3)) { singleton(&[]) } else { Space::new() };
    drop(v126_3);
    let v126_5: Space = subtract(&(*CONSTANT_0),&(v126_4));
    drop(v126_4);
    let v126_8: Space = if (v126_5).is_empty() { Space::new() } else {
      let v127_6: Path = concat_path(&(*p0),&(v125_11_head));
      let mut v127_7 = Space::new();
      let mut v127_7_cursor = (v125_11_tail).read_zipper();
      for v127_7_byte in v127_7_cursor.child_mask().iter() {
        v127_7_cursor.descend_to_byte(v127_7_byte);
        let v127_7_tail = v127_7_cursor.make_map();
        v127_7_cursor.ascend(1);
        let v127_7_head = Path::from_slice(&[v127_7_byte]);
        let v128_2: Space = singleton(&(v127_7_head));
        let v128_3: Space = intersect(&(*CONSTANT_9),&(v128_2));
        let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
        drop(v128_3);
        let v128_5: Space = subtract(&(*CONSTANT_0),&(v128_4));
        drop(v128_4);
        let v128_8: Space = if (v128_5).is_empty() { Space::new() } else {
          let v129_6: Path = concat_path(&(v127_6),&(v127_7_head));
          let v129_7: Space = routine_28(c, &(v129_6), &(v127_7_tail));
          compose(&(v128_5),&(v129_7))
        };
        drop(v128_5);
        let v128_9: Space = intersect(&(*CONSTANT_9),&(v128_2));
        drop(v128_2);
        let v128_10: Space = if has_head(&(v128_9)) { singleton(&[]) } else { Space::new() };
        drop(v128_9);
        let v128_12: Space = if (v128_10).is_empty() { Space::new() } else {
          let v130_6: Path = concat_path(&(v127_6),&(v127_7_head));
          let v130_11: Space = routine_29(c, &(v130_6), &(v127_7_tail));
          drop(v130_6);
          compose(&(v128_10),&(v130_11))
        };
        drop(v128_10);
        let v128_13: Space = unite(&(v128_8),&(v128_12));
        v127_7.join_into((v128_13).clone());
      }
      drop(v127_7_cursor);
      compose(&(v126_5),&(v127_7))
    };
    drop(v126_5);
    let v126_9: Space = intersect(&(*CONSTANT_9),&(v126_2));
    drop(v126_2);
    let v126_10: Space = if has_head(&(v126_9)) { singleton(&[]) } else { Space::new() };
    drop(v126_9);
    let v126_12: Space = if (v126_10).is_empty() { Space::new() } else {
      let v131_6: Path = concat_path(&(*p0),&(v125_11_head));
      let mut v131_11 = Space::new();
      let mut v131_11_cursor = (v125_11_tail).read_zipper();
      for v131_11_byte in v131_11_cursor.child_mask().iter() {
        v131_11_cursor.descend_to_byte(v131_11_byte);
        let v131_11_tail = v131_11_cursor.make_map();
        v131_11_cursor.ascend(1);
        let v131_11_head = Path::from_slice(&[v131_11_byte]);
        let v132_2: Space = singleton(&(v131_11_head));
        let v132_3: Space = intersect(&(*CONSTANT_9),&(v132_2));
        let v132_4: Space = if has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
        drop(v132_3);
        let v132_5: Space = subtract(&(*CONSTANT_0),&(v132_4));
        drop(v132_4);
        let v132_7: Space = if (v132_5).is_empty() { Space::new() } else {
          let v133_6: Space = routine_30(c, &(v131_11_head), &(v131_6), &(v131_11_tail));
          compose(&(v132_5),&(v133_6))
        };
        drop(v132_5);
        let v132_8: Space = intersect(&(*CONSTANT_9),&(v132_2));
        drop(v132_2);
        let v132_9: Space = if has_head(&(v132_8)) { singleton(&[]) } else { Space::new() };
        drop(v132_8);
        let v132_11: Space = if (v132_9).is_empty() { Space::new() } else {
          let v134_10: Space = routine_31(c, &(v131_11_head), &(v131_6), &(v131_11_tail));
          compose(&(v132_9),&(v134_10))
        };
        drop(v132_9);
        let v132_12: Space = unite(&(v132_7),&(v132_11));
        v131_11.join_into((v132_12).clone());
      }
      drop(v131_11_cursor);
      drop(v131_6);
      compose(&(v126_10),&(v131_11))
    };
    drop(v126_10);
    let v126_13: Space = unite(&(v126_8),&(v126_12));
    v125_11.join_into((v126_13).clone());
  }
  drop(v125_11_cursor);
  (v125_11).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v135_11 = Space::new();
  let mut v135_11_cursor = (*s0).read_zipper();
  for v135_11_byte in v135_11_cursor.child_mask().iter() {
    v135_11_cursor.descend_to_byte(v135_11_byte);
    let v135_11_tail = v135_11_cursor.make_map();
    v135_11_cursor.ascend(1);
    let v135_11_head = Path::from_slice(&[v135_11_byte]);
    let v136_2: Space = singleton(&(v135_11_head));
    let v136_3: Space = intersect(&(*CONSTANT_9),&(v136_2));
    let v136_4: Space = if has_head(&(v136_3)) { singleton(&[]) } else { Space::new() };
    drop(v136_3);
    let v136_5: Space = subtract(&(*CONSTANT_0),&(v136_4));
    drop(v136_4);
    let v136_7: Space = if (v136_5).is_empty() { Space::new() } else {
      let mut v137_6 = Space::new();
      let mut v137_6_cursor = (v135_11_tail).read_zipper();
      for v137_6_byte in v137_6_cursor.child_mask().iter() {
        v137_6_cursor.descend_to_byte(v137_6_byte);
        let v137_6_tail = v137_6_cursor.make_map();
        v137_6_cursor.ascend(1);
        let v137_6_head = Path::from_slice(&[v137_6_byte]);
        let v138_2: Space = singleton(&(v137_6_head));
        let v138_3: Space = intersect(&(*CONSTANT_9),&(v138_2));
        let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
        drop(v138_3);
        let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
        drop(v138_4);
        let v138_8: Space = if (v138_5).is_empty() { Space::new() } else {
          let v139_6: Path = concat_path(&(v135_11_head),&(v137_6_head));
          let v139_7: Space = routine_32(c, &(v139_6), &(*p0), &(v137_6_tail));
          compose(&(v138_5),&(v139_7))
        };
        drop(v138_5);
        let v138_9: Space = intersect(&(*CONSTANT_9),&(v138_2));
        drop(v138_2);
        let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
        drop(v138_9);
        let v138_12: Space = if (v138_10).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v135_11_head),&(v137_6_head));
          let v140_11: Space = routine_33(c, &(v140_6), &(*p0), &(v137_6_tail));
          drop(v140_6);
          compose(&(v138_10),&(v140_11))
        };
        drop(v138_10);
        let v138_13: Space = unite(&(v138_8),&(v138_12));
        v137_6.join_into((v138_13).clone());
      }
      drop(v137_6_cursor);
      compose(&(v136_5),&(v137_6))
    };
    drop(v136_5);
    let v136_8: Space = intersect(&(*CONSTANT_9),&(v136_2));
    drop(v136_2);
    let v136_9: Space = if has_head(&(v136_8)) { singleton(&[]) } else { Space::new() };
    drop(v136_8);
    let v136_11: Space = if (v136_9).is_empty() { Space::new() } else {
      let mut v141_10 = Space::new();
      let mut v141_10_cursor = (v135_11_tail).read_zipper();
      for v141_10_byte in v141_10_cursor.child_mask().iter() {
        v141_10_cursor.descend_to_byte(v141_10_byte);
        let v141_10_tail = v141_10_cursor.make_map();
        v141_10_cursor.ascend(1);
        let v141_10_head = Path::from_slice(&[v141_10_byte]);
        let v142_2: Space = singleton(&(v141_10_head));
        let v142_3: Space = intersect(&(*CONSTANT_9),&(v142_2));
        let v142_4: Space = if has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
        drop(v142_3);
        let v142_5: Space = subtract(&(*CONSTANT_0),&(v142_4));
        drop(v142_4);
        let v142_8: Space = if (v142_5).is_empty() { Space::new() } else {
          let v143_6: Path = concat_path(&(v135_11_head),&(v141_10_head));
          let v143_7: Space = routine_32(c, &(v143_6), &(*p0), &(v141_10_tail));
          compose(&(v142_5),&(v143_7))
        };
        drop(v142_5);
        let v142_9: Space = intersect(&(*CONSTANT_9),&(v142_2));
        drop(v142_2);
        let v142_10: Space = if has_head(&(v142_9)) { singleton(&[]) } else { Space::new() };
        drop(v142_9);
        let v142_12: Space = if (v142_10).is_empty() { Space::new() } else {
          let v144_6: Path = concat_path(&(v135_11_head),&(v141_10_head));
          let v144_11: Space = routine_34(c, &(v144_6), &(*p0), &(v141_10_tail));
          drop(v144_6);
          compose(&(v142_10),&(v144_11))
        };
        drop(v142_10);
        let v142_13: Space = unite(&(v142_8),&(v142_12));
        v141_10.join_into((v142_13).clone());
      }
      drop(v141_10_cursor);
      compose(&(v136_9),&(v141_10))
    };
    drop(v136_9);
    let v136_12: Space = unite(&(v136_7),&(v136_11));
    v135_11.join_into((v136_12).clone());
  }
  drop(v135_11_cursor);
  (v135_11).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v145_14 = Space::new();
  let mut v145_14_cursor = (*s0).read_zipper();
  for v145_14_byte in v145_14_cursor.child_mask().iter() {
    v145_14_cursor.descend_to_byte(v145_14_byte);
    let v145_14_tail = v145_14_cursor.make_map();
    v145_14_cursor.ascend(1);
    let v145_14_head = Path::from_slice(&[v145_14_byte]);
    let v146_2: Space = singleton(&(v145_14_head));
    let v146_3: Space = intersect(&(*CONSTANT_9),&(v146_2));
    let v146_4: Space = if has_head(&(v146_3)) { singleton(&[]) } else { Space::new() };
    drop(v146_3);
    let v146_5: Space = subtract(&(*CONSTANT_0),&(v146_4));
    drop(v146_4);
    let v146_8: Space = if (v146_5).is_empty() { Space::new() } else {
      let v147_6: Path = concat_path(&(*p0),&(v145_14_head));
      let mut v147_7 = Space::new();
      let mut v147_7_cursor = (v145_14_tail).read_zipper();
      for v147_7_byte in v147_7_cursor.child_mask().iter() {
        v147_7_cursor.descend_to_byte(v147_7_byte);
        let v147_7_tail = v147_7_cursor.make_map();
        v147_7_cursor.ascend(1);
        let v147_7_head = Path::from_slice(&[v147_7_byte]);
        let v148_2: Space = singleton(&(v147_7_head));
        let v148_3: Space = intersect(&(*CONSTANT_9),&(v148_2));
        let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
        drop(v148_3);
        let v148_5: Space = subtract(&(*CONSTANT_0),&(v148_4));
        drop(v148_4);
        let v148_8: Space = if (v148_5).is_empty() { Space::new() } else {
          let v149_6: Path = concat_path(&(v147_6),&(v147_7_head));
          let v149_7: Space = routine_35(c, &(v149_6), &(v147_7_tail), &(*s1), &(*s2), &(*s3));
          compose(&(v148_5),&(v149_7))
        };
        drop(v148_5);
        let v148_9: Space = intersect(&(*CONSTANT_9),&(v148_2));
        drop(v148_2);
        let v148_10: Space = if has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
        drop(v148_9);
        let v148_12: Space = if (v148_10).is_empty() { Space::new() } else {
          let v150_6: Path = concat_path(&(v147_6),&(v147_7_head));
          let v150_11: Space = routine_36(c, &(v150_6), &(v147_7_tail), &(*s1), &(*s2), &(*s3));
          drop(v150_6);
          compose(&(v148_10),&(v150_11))
        };
        drop(v148_10);
        let v148_13: Space = unite(&(v148_8),&(v148_12));
        v147_7.join_into((v148_13).clone());
      }
      drop(v147_7_cursor);
      compose(&(v146_5),&(v147_7))
    };
    drop(v146_5);
    let v146_9: Space = intersect(&(*CONSTANT_9),&(v146_2));
    drop(v146_2);
    let v146_10: Space = if has_head(&(v146_9)) { singleton(&[]) } else { Space::new() };
    drop(v146_9);
    let v146_12: Space = if (v146_10).is_empty() { Space::new() } else {
      let v151_6: Path = concat_path(&(*p0),&(v145_14_head));
      let mut v151_11 = Space::new();
      let mut v151_11_cursor = (v145_14_tail).read_zipper();
      for v151_11_byte in v151_11_cursor.child_mask().iter() {
        v151_11_cursor.descend_to_byte(v151_11_byte);
        let v151_11_tail = v151_11_cursor.make_map();
        v151_11_cursor.ascend(1);
        let v151_11_head = Path::from_slice(&[v151_11_byte]);
        let v152_2: Space = singleton(&(v151_11_head));
        let v152_3: Space = intersect(&(*CONSTANT_9),&(v152_2));
        let v152_4: Space = if has_head(&(v152_3)) { singleton(&[]) } else { Space::new() };
        drop(v152_3);
        let v152_5: Space = subtract(&(*CONSTANT_0),&(v152_4));
        drop(v152_4);
        let v152_8: Space = if (v152_5).is_empty() { Space::new() } else {
          let v153_6: Path = concat_path(&(v151_6),&(v151_11_head));
          let v153_7: Space = routine_35(c, &(v153_6), &(v151_11_tail), &(*s1), &(*s2), &(*s3));
          compose(&(v152_5),&(v153_7))
        };
        drop(v152_5);
        let v152_9: Space = intersect(&(*CONSTANT_9),&(v152_2));
        drop(v152_2);
        let v152_10: Space = if has_head(&(v152_9)) { singleton(&[]) } else { Space::new() };
        drop(v152_9);
        let v152_12: Space = if (v152_10).is_empty() { Space::new() } else {
          let v154_6: Path = concat_path(&(v151_6),&(v151_11_head));
          let v154_11: Space = routine_37(c, &(v154_6), &(v151_11_tail), &(*s1), &(*s2), &(*s3));
          drop(v154_6);
          compose(&(v152_10),&(v154_11))
        };
        drop(v152_10);
        let v152_13: Space = unite(&(v152_8),&(v152_12));
        v151_11.join_into((v152_13).clone());
      }
      drop(v151_11_cursor);
      drop(v151_6);
      compose(&(v146_10),&(v151_11))
    };
    drop(v146_10);
    let v146_13: Space = unite(&(v146_8),&(v146_12));
    v145_14.join_into((v146_13).clone());
  }
  drop(v145_14_cursor);
  (v145_14).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v155_11 = Space::new();
  let mut v155_11_cursor = (*s0).read_zipper();
  for v155_11_byte in v155_11_cursor.child_mask().iter() {
    v155_11_cursor.descend_to_byte(v155_11_byte);
    let v155_11_tail = v155_11_cursor.make_map();
    v155_11_cursor.ascend(1);
    let v155_11_head = Path::from_slice(&[v155_11_byte]);
    let v156_2: Space = singleton(&(v155_11_head));
    let v156_3: Space = intersect(&(*CONSTANT_9),&(v156_2));
    let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
    drop(v156_3);
    let v156_5: Space = subtract(&(*CONSTANT_0),&(v156_4));
    drop(v156_4);
    let v156_8: Space = if (v156_5).is_empty() { Space::new() } else {
      let v157_6: Path = concat_path(&(*p0),&(v155_11_head));
      let mut v157_7 = Space::new();
      let mut v157_7_cursor = (v155_11_tail).read_zipper();
      for v157_7_byte in v157_7_cursor.child_mask().iter() {
        v157_7_cursor.descend_to_byte(v157_7_byte);
        let v157_7_tail = v157_7_cursor.make_map();
        v157_7_cursor.ascend(1);
        let v157_7_head = Path::from_slice(&[v157_7_byte]);
        let v158_2: Space = singleton(&(v157_7_head));
        let v158_3: Space = intersect(&(*CONSTANT_9),&(v158_2));
        let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
        drop(v158_3);
        let v158_5: Space = subtract(&(*CONSTANT_0),&(v158_4));
        drop(v158_4);
        let v158_8: Space = if (v158_5).is_empty() { Space::new() } else {
          let v159_6: Path = concat_path(&(v157_6),&(v157_7_head));
          let v159_7: Space = routine_35(c, &(v159_6), &(v157_7_tail), &(*s1), &(*s2), &(*s3));
          compose(&(v158_5),&(v159_7))
        };
        drop(v158_5);
        let v158_9: Space = intersect(&(*CONSTANT_9),&(v158_2));
        drop(v158_2);
        let v158_10: Space = if has_head(&(v158_9)) { singleton(&[]) } else { Space::new() };
        drop(v158_9);
        let v158_12: Space = if (v158_10).is_empty() { Space::new() } else {
          let v160_6: Path = concat_path(&(v157_6),&(v157_7_head));
          let v160_11: Space = routine_36(c, &(v160_6), &(v157_7_tail), &(*s1), &(*s2), &(*s3));
          drop(v160_6);
          compose(&(v158_10),&(v160_11))
        };
        drop(v158_10);
        let v158_13: Space = unite(&(v158_8),&(v158_12));
        v157_7.join_into((v158_13).clone());
      }
      drop(v157_7_cursor);
      compose(&(v156_5),&(v157_7))
    };
    drop(v156_5);
    let v156_9: Space = intersect(&(*CONSTANT_9),&(v156_2));
    drop(v156_2);
    let v156_10: Space = if has_head(&(v156_9)) { singleton(&[]) } else { Space::new() };
    drop(v156_9);
    let v156_27: Space = if (v156_10).is_empty() { Space::new() } else {
      let v161_6: Path = concat_path(&(*p0),&(v155_11_head));
      let v161_11: Space = singleton(&(v161_6));
      let v161_12: Space = routine_38(c, &(*s1), &(*s3), &(v161_11));
      let v161_13: Space = routine_38(c, &(*s2), &(*s3), &(v161_11));
      let v161_14: Space = intersect(&(v161_12),&(v161_13));
      let v161_15: Space = subtract(&(v161_14),&(v161_11));
      drop(v161_11);
      let v161_16: Space = wrap(&(v161_15),&(v161_6));
      drop(v161_6);
      let v161_17: Space = subtract(&(*s3),&(v161_13));
      let v161_18: Space = subtract(&(v161_17),&(v161_12));
      let v161_19: Space = routine_39(c, &(*s2), &(*s1), &(v161_18));
      let v161_20: Space = unite(&(v161_16),&(v161_19));
      let v161_21: Space = subtract(&(v161_12),&(v161_13));
      let v161_22: Space = routine_39(c, &(*s2), &(*s1), &(v161_21));
      let v161_23: Space = unite(&(v161_20),&(v161_22));
      let v161_24: Space = subtract(&(v161_13),&(v161_12));
      let v161_25: Space = routine_39(c, &(*s2), &(*s1), &(v161_24));
      let v161_26: Space = unite(&(v161_23),&(v161_25));
      compose(&(v156_10),&(v161_26))
    };
    drop(v156_10);
    let v156_28: Space = unite(&(v156_8),&(v156_27));
    v155_11.join_into((v156_28).clone());
  }
  drop(v155_11_cursor);
  (v155_11).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v162_2 = Space::new();
  let mut v162_2_cursor = (*s0).read_zipper();
  for v162_2_byte in v162_2_cursor.child_mask().iter() {
    v162_2_cursor.descend_to_byte(v162_2_byte);
    let v162_2_tail = v162_2_cursor.make_map();
    v162_2_cursor.ascend(1);
    let v162_2_head = Path::from_slice(&[v162_2_byte]);
    let v163_2: Space = Space::new();
    v162_2.join_into((v163_2).clone());
  }
  drop(v162_2_cursor);
  (v162_2).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v164_3 = Space::new();
  let mut v164_3_cursor = (*s0).read_zipper();
  for v164_3_byte in v164_3_cursor.child_mask().iter() {
    v164_3_cursor.descend_to_byte(v164_3_byte);
    let v164_3_tail = v164_3_cursor.make_map();
    v164_3_cursor.ascend(1);
    let v164_3_head = Path::from_slice(&[v164_3_byte]);
    let v165_2: Space = singleton(&(v164_3_head));
    let v165_3: Space = intersect(&(*CONSTANT_9),&(v165_2));
    drop(v165_2);
    let v165_4: Space = if has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
    drop(v165_3);
    let v165_7: Space = if (v165_4).is_empty() { Space::new() } else {
      let v166_5: Path = concat_path(&(*p0),&(v164_3_head));
      let v166_6: Space = singleton(&(v166_5));
      drop(v166_5);
      compose(&(v165_4),&(v166_6))
    };
    drop(v165_4);
    v164_3.join_into((v165_7).clone());
  }
  drop(v164_3_cursor);
  (v164_3).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v167_2 = Space::new();
  let mut v167_2_cursor = (*s0).read_zipper();
  for v167_2_byte in v167_2_cursor.child_mask().iter() {
    v167_2_cursor.descend_to_byte(v167_2_byte);
    let v167_2_tail = v167_2_cursor.make_map();
    v167_2_cursor.ascend(1);
    let v167_2_head = Path::from_slice(&[v167_2_byte]);
    let v168_2: Space = Space::new();
    v167_2.join_into((v168_2).clone());
  }
  drop(v167_2_cursor);
  (v167_2).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v169_6 = Space::new();
  let mut v169_6_cursor = (*s0).read_zipper();
  for v169_6_byte in v169_6_cursor.child_mask().iter() {
    v169_6_cursor.descend_to_byte(v169_6_byte);
    let v169_6_tail = v169_6_cursor.make_map();
    v169_6_cursor.ascend(1);
    let v169_6_head = Path::from_slice(&[v169_6_byte]);
    let v170_2: Space = singleton(&(v169_6_head));
    let v170_3: Space = intersect(&(*CONSTANT_9),&(v170_2));
    drop(v170_2);
    let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
    drop(v170_3);
    let v170_7: Space = if (v170_4).is_empty() { Space::new() } else {
      let v171_5: Path = concat_path(&(*p0),&(v169_6_head));
      let mut v171_6 = Space::new();
      let mut v171_6_cursor = (v169_6_tail).read_zipper();
      for v171_6_byte in v171_6_cursor.child_mask().iter() {
        v171_6_cursor.descend_to_byte(v171_6_byte);
        let v171_6_tail = v171_6_cursor.make_map();
        v171_6_cursor.ascend(1);
        let v171_6_head = Path::from_slice(&[v171_6_byte]);
        let v172_2: Space = singleton(&(v171_6_head));
        let v172_3: Space = intersect(&(*CONSTANT_9),&(v172_2));
        let v172_4: Space = if has_head(&(v172_3)) { singleton(&[]) } else { Space::new() };
        drop(v172_3);
        let v172_5: Space = subtract(&(*CONSTANT_0),&(v172_4));
        drop(v172_4);
        let v172_7: Space = if (v172_5).is_empty() { Space::new() } else {
          let v173_6: Space = routine_20(c, &(v171_6_head), &(v171_5), &(v171_6_tail));
          compose(&(v172_5),&(v173_6))
        };
        drop(v172_5);
        let v172_8: Space = intersect(&(*CONSTANT_9),&(v172_2));
        drop(v172_2);
        let v172_9: Space = if has_head(&(v172_8)) { singleton(&[]) } else { Space::new() };
        drop(v172_8);
        let v172_11: Space = if (v172_9).is_empty() { Space::new() } else {
          let v174_10: Space = routine_21(c, &(v171_6_head), &(v171_5), &(v171_6_tail));
          compose(&(v172_9),&(v174_10))
        };
        drop(v172_9);
        let v172_12: Space = unite(&(v172_7),&(v172_11));
        v171_6.join_into((v172_12).clone());
      }
      drop(v171_6_cursor);
      drop(v171_5);
      compose(&(v170_4),&(v171_6))
    };
    drop(v170_4);
    v169_6.join_into((v170_7).clone());
  }
  drop(v169_6_cursor);
  (v169_6).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v175_12 = Space::new();
  let mut v175_12_cursor = (*s0).read_zipper();
  for v175_12_byte in v175_12_cursor.child_mask().iter() {
    v175_12_cursor.descend_to_byte(v175_12_byte);
    let v175_12_tail = v175_12_cursor.make_map();
    v175_12_cursor.ascend(1);
    let v175_12_head = Path::from_slice(&[v175_12_byte]);
    let v176_2: Space = singleton(&(v175_12_head));
    let v176_3: Space = intersect(&(*CONSTANT_9),&(v176_2));
    let v176_4: Space = if has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
    drop(v176_3);
    let v176_5: Space = subtract(&(*CONSTANT_0),&(v176_4));
    drop(v176_4);
    let v176_8: Space = if (v176_5).is_empty() { Space::new() } else {
      let v177_6: Path = concat_path(&(*p0),&(v175_12_head));
      let mut v177_7 = Space::new();
      let mut v177_7_cursor = (v175_12_tail).read_zipper();
      for v177_7_byte in v177_7_cursor.child_mask().iter() {
        v177_7_cursor.descend_to_byte(v177_7_byte);
        let v177_7_tail = v177_7_cursor.make_map();
        v177_7_cursor.ascend(1);
        let v177_7_head = Path::from_slice(&[v177_7_byte]);
        let v178_2: Space = singleton(&(v177_7_head));
        let v178_3: Space = intersect(&(*CONSTANT_9),&(v178_2));
        let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
        drop(v178_3);
        let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
        drop(v178_4);
        let v178_8: Space = if (v178_5).is_empty() { Space::new() } else {
          let v179_6: Path = concat_path(&(v177_6),&(v177_7_head));
          let v179_7: Space = routine_40(c, &(v179_6), &(*p1), &(v177_7_tail));
          compose(&(v178_5),&(v179_7))
        };
        drop(v178_5);
        let v178_9: Space = intersect(&(*CONSTANT_9),&(v178_2));
        drop(v178_2);
        let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
        drop(v178_9);
        let v178_12: Space = if (v178_10).is_empty() { Space::new() } else {
          let v180_6: Path = concat_path(&(v177_6),&(v177_7_head));
          let v180_11: Space = routine_41(c, &(v180_6), &(*p1), &(v177_7_tail));
          drop(v180_6);
          compose(&(v178_10),&(v180_11))
        };
        drop(v178_10);
        let v178_13: Space = unite(&(v178_8),&(v178_12));
        v177_7.join_into((v178_13).clone());
      }
      drop(v177_7_cursor);
      compose(&(v176_5),&(v177_7))
    };
    drop(v176_5);
    let v176_9: Space = intersect(&(*CONSTANT_9),&(v176_2));
    drop(v176_2);
    let v176_10: Space = if has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
    drop(v176_9);
    let v176_12: Space = if (v176_10).is_empty() { Space::new() } else {
      let v181_6: Path = concat_path(&(*p0),&(v175_12_head));
      let mut v181_11 = Space::new();
      let mut v181_11_cursor = (v175_12_tail).read_zipper();
      for v181_11_byte in v181_11_cursor.child_mask().iter() {
        v181_11_cursor.descend_to_byte(v181_11_byte);
        let v181_11_tail = v181_11_cursor.make_map();
        v181_11_cursor.ascend(1);
        let v181_11_head = Path::from_slice(&[v181_11_byte]);
        let v182_2: Space = singleton(&(v181_11_head));
        let v182_3: Space = intersect(&(*CONSTANT_9),&(v182_2));
        let v182_4: Space = if has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
        drop(v182_3);
        let v182_5: Space = subtract(&(*CONSTANT_0),&(v182_4));
        drop(v182_4);
        let v182_8: Space = if (v182_5).is_empty() { Space::new() } else {
          let v183_6: Path = concat_path(&(v181_6),&(v181_11_head));
          let v183_7: Space = routine_40(c, &(v183_6), &(*p1), &(v181_11_tail));
          compose(&(v182_5),&(v183_7))
        };
        drop(v182_5);
        let v182_9: Space = intersect(&(*CONSTANT_9),&(v182_2));
        drop(v182_2);
        let v182_10: Space = if has_head(&(v182_9)) { singleton(&[]) } else { Space::new() };
        drop(v182_9);
        let v182_12: Space = if (v182_10).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v181_6),&(v181_11_head));
          let v184_11: Space = routine_24(c, &(v184_6), &(*p1), &(v181_11_tail));
          drop(v184_6);
          compose(&(v182_10),&(v184_11))
        };
        drop(v182_10);
        let v182_13: Space = unite(&(v182_8),&(v182_12));
        v181_11.join_into((v182_13).clone());
      }
      drop(v181_11_cursor);
      drop(v181_6);
      compose(&(v176_10),&(v181_11))
    };
    drop(v176_10);
    let v176_13: Space = unite(&(v176_8),&(v176_12));
    v175_12.join_into((v176_13).clone());
  }
  drop(v175_12_cursor);
  (v175_12).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v185_9 = Space::new();
  let mut v185_9_cursor = (*s0).read_zipper();
  for v185_9_byte in v185_9_cursor.child_mask().iter() {
    v185_9_cursor.descend_to_byte(v185_9_byte);
    let v185_9_tail = v185_9_cursor.make_map();
    v185_9_cursor.ascend(1);
    let v185_9_head = Path::from_slice(&[v185_9_byte]);
    let v186_2: Space = singleton(&(v185_9_head));
    let v186_3: Space = intersect(&(*CONSTANT_9),&(v186_2));
    let v186_4: Space = if has_head(&(v186_3)) { singleton(&[]) } else { Space::new() };
    drop(v186_3);
    let v186_5: Space = subtract(&(*CONSTANT_0),&(v186_4));
    drop(v186_4);
    let v186_8: Space = if (v186_5).is_empty() { Space::new() } else {
      let v187_6: Path = concat_path(&(*p0),&(v185_9_head));
      let mut v187_7 = Space::new();
      let mut v187_7_cursor = (v185_9_tail).read_zipper();
      for v187_7_byte in v187_7_cursor.child_mask().iter() {
        v187_7_cursor.descend_to_byte(v187_7_byte);
        let v187_7_tail = v187_7_cursor.make_map();
        v187_7_cursor.ascend(1);
        let v187_7_head = Path::from_slice(&[v187_7_byte]);
        let v188_2: Space = singleton(&(v187_7_head));
        let v188_3: Space = intersect(&(*CONSTANT_9),&(v188_2));
        let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
        drop(v188_3);
        let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
        drop(v188_4);
        let v188_8: Space = if (v188_5).is_empty() { Space::new() } else {
          let v189_6: Path = concat_path(&(v187_6),&(v187_7_head));
          let v189_7: Space = routine_40(c, &(v189_6), &(*p1), &(v187_7_tail));
          compose(&(v188_5),&(v189_7))
        };
        drop(v188_5);
        let v188_9: Space = intersect(&(*CONSTANT_9),&(v188_2));
        drop(v188_2);
        let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
        drop(v188_9);
        let v188_12: Space = if (v188_10).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v187_6),&(v187_7_head));
          let v190_11: Space = routine_41(c, &(v190_6), &(*p1), &(v187_7_tail));
          drop(v190_6);
          compose(&(v188_10),&(v190_11))
        };
        drop(v188_10);
        let v188_13: Space = unite(&(v188_8),&(v188_12));
        v187_7.join_into((v188_13).clone());
      }
      drop(v187_7_cursor);
      compose(&(v186_5),&(v187_7))
    };
    drop(v186_5);
    let v186_9: Space = intersect(&(*CONSTANT_9),&(v186_2));
    drop(v186_2);
    let v186_10: Space = if has_head(&(v186_9)) { singleton(&[]) } else { Space::new() };
    drop(v186_9);
    let v186_13: Space = if (v186_10).is_empty() { Space::new() } else {
      let v191_6: Path = concat_path(&(*p0),&(v185_9_head));
      let v191_11: Path = concat_path(&(v191_6),&(*p1));
      drop(v191_6);
      let v191_12: Space = singleton(&(v191_11));
      drop(v191_11);
      compose(&(v186_10),&(v191_12))
    };
    drop(v186_10);
    let v186_14: Space = unite(&(v186_8),&(v186_13));
    drop(v186_13);
    v185_9.join_into((v186_14).clone());
  }
  drop(v185_9_cursor);
  (v185_9).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v192_12 = Space::new();
  let mut v192_12_cursor = (*s0).read_zipper();
  for v192_12_byte in v192_12_cursor.child_mask().iter() {
    v192_12_cursor.descend_to_byte(v192_12_byte);
    let v192_12_tail = v192_12_cursor.make_map();
    v192_12_cursor.ascend(1);
    let v192_12_head = Path::from_slice(&[v192_12_byte]);
    let v193_2: Space = singleton(&(v192_12_head));
    let v193_3: Space = intersect(&(*CONSTANT_9),&(v193_2));
    let v193_4: Space = if has_head(&(v193_3)) { singleton(&[]) } else { Space::new() };
    drop(v193_3);
    let v193_5: Space = subtract(&(*CONSTANT_0),&(v193_4));
    drop(v193_4);
    let v193_8: Space = if (v193_5).is_empty() { Space::new() } else {
      let v194_6: Path = concat_path(&(*p0),&(v192_12_head));
      let mut v194_7 = Space::new();
      let mut v194_7_cursor = (v192_12_tail).read_zipper();
      for v194_7_byte in v194_7_cursor.child_mask().iter() {
        v194_7_cursor.descend_to_byte(v194_7_byte);
        let v194_7_tail = v194_7_cursor.make_map();
        v194_7_cursor.ascend(1);
        let v194_7_head = Path::from_slice(&[v194_7_byte]);
        let v195_2: Space = singleton(&(v194_7_head));
        let v195_3: Space = intersect(&(*CONSTANT_9),&(v195_2));
        let v195_4: Space = if has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
        drop(v195_3);
        let v195_5: Space = subtract(&(*CONSTANT_0),&(v195_4));
        drop(v195_4);
        let v195_8: Space = if (v195_5).is_empty() { Space::new() } else {
          let v196_6: Path = concat_path(&(v194_6),&(v194_7_head));
          let v196_7: Space = routine_42(c, &(v196_6), &(*p1), &(v194_7_tail));
          compose(&(v195_5),&(v196_7))
        };
        drop(v195_5);
        let v195_9: Space = intersect(&(*CONSTANT_9),&(v195_2));
        drop(v195_2);
        let v195_10: Space = if has_head(&(v195_9)) { singleton(&[]) } else { Space::new() };
        drop(v195_9);
        let v195_12: Space = if (v195_10).is_empty() { Space::new() } else {
          let v197_6: Path = concat_path(&(v194_6),&(v194_7_head));
          let v197_11: Space = routine_43(c, &(v197_6), &(*p1), &(v194_7_tail));
          drop(v197_6);
          compose(&(v195_10),&(v197_11))
        };
        drop(v195_10);
        let v195_13: Space = unite(&(v195_8),&(v195_12));
        v194_7.join_into((v195_13).clone());
      }
      drop(v194_7_cursor);
      compose(&(v193_5),&(v194_7))
    };
    drop(v193_5);
    let v193_9: Space = intersect(&(*CONSTANT_9),&(v193_2));
    drop(v193_2);
    let v193_10: Space = if has_head(&(v193_9)) { singleton(&[]) } else { Space::new() };
    drop(v193_9);
    let v193_12: Space = if (v193_10).is_empty() { Space::new() } else {
      let v198_6: Path = concat_path(&(*p0),&(v192_12_head));
      let mut v198_11 = Space::new();
      let mut v198_11_cursor = (v192_12_tail).read_zipper();
      for v198_11_byte in v198_11_cursor.child_mask().iter() {
        v198_11_cursor.descend_to_byte(v198_11_byte);
        let v198_11_tail = v198_11_cursor.make_map();
        v198_11_cursor.ascend(1);
        let v198_11_head = Path::from_slice(&[v198_11_byte]);
        let v199_2: Space = singleton(&(v198_11_head));
        let v199_3: Space = intersect(&(*CONSTANT_9),&(v199_2));
        let v199_4: Space = if has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
        drop(v199_3);
        let v199_5: Space = subtract(&(*CONSTANT_0),&(v199_4));
        drop(v199_4);
        let v199_8: Space = if (v199_5).is_empty() { Space::new() } else {
          let v200_6: Path = concat_path(&(v198_6),&(v198_11_head));
          let v200_7: Space = routine_42(c, &(v200_6), &(*p1), &(v198_11_tail));
          compose(&(v199_5),&(v200_7))
        };
        drop(v199_5);
        let v199_9: Space = intersect(&(*CONSTANT_9),&(v199_2));
        drop(v199_2);
        let v199_10: Space = if has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
        drop(v199_9);
        let v199_12: Space = if (v199_10).is_empty() { Space::new() } else {
          let v201_6: Path = concat_path(&(v198_6),&(v198_11_head));
          let v201_11: Space = routine_24(c, &(v201_6), &(*p1), &(v198_11_tail));
          drop(v201_6);
          compose(&(v199_10),&(v201_11))
        };
        drop(v199_10);
        let v199_13: Space = unite(&(v199_8),&(v199_12));
        v198_11.join_into((v199_13).clone());
      }
      drop(v198_11_cursor);
      drop(v198_6);
      compose(&(v193_10),&(v198_11))
    };
    drop(v193_10);
    let v193_13: Space = unite(&(v193_8),&(v193_12));
    v192_12.join_into((v193_13).clone());
  }
  drop(v192_12_cursor);
  (v192_12).clone()
}

fn routine_23(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v202_9 = Space::new();
  let mut v202_9_cursor = (*s0).read_zipper();
  for v202_9_byte in v202_9_cursor.child_mask().iter() {
    v202_9_cursor.descend_to_byte(v202_9_byte);
    let v202_9_tail = v202_9_cursor.make_map();
    v202_9_cursor.ascend(1);
    let v202_9_head = Path::from_slice(&[v202_9_byte]);
    let v203_2: Space = singleton(&(v202_9_head));
    let v203_3: Space = intersect(&(*CONSTANT_9),&(v203_2));
    let v203_4: Space = if has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
    drop(v203_3);
    let v203_5: Space = subtract(&(*CONSTANT_0),&(v203_4));
    drop(v203_4);
    let v203_8: Space = if (v203_5).is_empty() { Space::new() } else {
      let v204_6: Path = concat_path(&(*p0),&(v202_9_head));
      let mut v204_7 = Space::new();
      let mut v204_7_cursor = (v202_9_tail).read_zipper();
      for v204_7_byte in v204_7_cursor.child_mask().iter() {
        v204_7_cursor.descend_to_byte(v204_7_byte);
        let v204_7_tail = v204_7_cursor.make_map();
        v204_7_cursor.ascend(1);
        let v204_7_head = Path::from_slice(&[v204_7_byte]);
        let v205_2: Space = singleton(&(v204_7_head));
        let v205_3: Space = intersect(&(*CONSTANT_9),&(v205_2));
        let v205_4: Space = if has_head(&(v205_3)) { singleton(&[]) } else { Space::new() };
        drop(v205_3);
        let v205_5: Space = subtract(&(*CONSTANT_0),&(v205_4));
        drop(v205_4);
        let v205_8: Space = if (v205_5).is_empty() { Space::new() } else {
          let v206_6: Path = concat_path(&(v204_6),&(v204_7_head));
          let v206_7: Space = routine_42(c, &(v206_6), &(*p1), &(v204_7_tail));
          compose(&(v205_5),&(v206_7))
        };
        drop(v205_5);
        let v205_9: Space = intersect(&(*CONSTANT_9),&(v205_2));
        drop(v205_2);
        let v205_10: Space = if has_head(&(v205_9)) { singleton(&[]) } else { Space::new() };
        drop(v205_9);
        let v205_12: Space = if (v205_10).is_empty() { Space::new() } else {
          let v207_6: Path = concat_path(&(v204_6),&(v204_7_head));
          let v207_11: Space = routine_43(c, &(v207_6), &(*p1), &(v204_7_tail));
          drop(v207_6);
          compose(&(v205_10),&(v207_11))
        };
        drop(v205_10);
        let v205_13: Space = unite(&(v205_8),&(v205_12));
        v204_7.join_into((v205_13).clone());
      }
      drop(v204_7_cursor);
      compose(&(v203_5),&(v204_7))
    };
    drop(v203_5);
    let v203_9: Space = intersect(&(*CONSTANT_9),&(v203_2));
    drop(v203_2);
    let v203_10: Space = if has_head(&(v203_9)) { singleton(&[]) } else { Space::new() };
    drop(v203_9);
    let v203_13: Space = if (v203_10).is_empty() { Space::new() } else {
      let v208_6: Path = concat_path(&(*p0),&(v202_9_head));
      let v208_11: Path = concat_path(&(v208_6),&(*p1));
      drop(v208_6);
      let v208_12: Space = singleton(&(v208_11));
      drop(v208_11);
      compose(&(v203_10),&(v208_12))
    };
    drop(v203_10);
    let v203_14: Space = unite(&(v203_8),&(v203_13));
    drop(v203_13);
    v202_9.join_into((v203_14).clone());
  }
  drop(v202_9_cursor);
  (v202_9).clone()
}

fn routine_24(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v209_3: Path = concat_path(&(*p0),&(*p1));
  let v209_4: Space = singleton(&(v209_3));
  drop(v209_3);
  (v209_4).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v210_2 = Space::new();
  let mut v210_2_cursor = (*s0).read_zipper();
  for v210_2_byte in v210_2_cursor.child_mask().iter() {
    v210_2_cursor.descend_to_byte(v210_2_byte);
    let v210_2_tail = v210_2_cursor.make_map();
    v210_2_cursor.ascend(1);
    let v210_2_head = Path::from_slice(&[v210_2_byte]);
    let v211_2: Space = Space::new();
    v210_2.join_into((v211_2).clone());
  }
  drop(v210_2_cursor);
  (v210_2).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v212_3 = Space::new();
  let mut v212_3_cursor = (*s0).read_zipper();
  for v212_3_byte in v212_3_cursor.child_mask().iter() {
    v212_3_cursor.descend_to_byte(v212_3_byte);
    let v212_3_tail = v212_3_cursor.make_map();
    v212_3_cursor.ascend(1);
    let v212_3_head = Path::from_slice(&[v212_3_byte]);
    let v213_2: Space = singleton(&(v212_3_head));
    let v213_3: Space = intersect(&(*CONSTANT_9),&(v213_2));
    drop(v213_2);
    let v213_4: Space = if has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
    drop(v213_3);
    let v213_7: Space = if (v213_4).is_empty() { Space::new() } else {
      let v214_5: Path = concat_path(&(*p0),&(v212_3_head));
      let v214_6: Space = singleton(&(v214_5));
      drop(v214_5);
      compose(&(v213_4),&(v214_6))
    };
    drop(v213_4);
    v212_3.join_into((v213_7).clone());
  }
  drop(v212_3_cursor);
  (v212_3).clone()
}

fn routine_27(c: &mut Context, s0: &Space) -> Space {
  let v215_2: Space = first_matching(&(*s0),&(*CONSTANT_0),false);
  let v215_3: Space = intersect(&(*CONSTANT_0),&(v215_2));
  let v215_4: Space = if has_head(&(v215_2)) { singleton(&[]) } else { Space::new() };
  let v215_5: Space = unite(&(v215_3),&(v215_4));
  drop(v215_3);
  let v215_7: Space = compose(&(v215_5),&(*CONSTANT_0));
  drop(v215_5);
  let v215_9: Space = subtract(&(*CONSTANT_0),&(v215_2));
  drop(v215_2);
  let v215_10: Space = subtract(&(v215_9),&(v215_4));
  drop(v215_4);
  drop(v215_9);
  let v215_18: Space = if (v215_10).is_empty() { Space::new() } else {
    let v216_11: Space = first_fibonacci(&(*s0),6,5,true);
    let v216_12: Space = first_matching(&(v216_11),&(*CONSTANT_0),false);
    let v216_15: Space = if (v216_12).is_empty() { Space::new() } else {
      let v217_14: Space = routine_44(c, &(*CONSTANT_11), &(*s0));
      compose(&(v216_12),&(v217_14))
    };
    drop(v216_12);
    let mut v216_16 = Space::new();
    let mut v216_16_cursor = (v216_11).read_zipper();
    for v216_16_byte in v216_16_cursor.child_mask().iter() {
      v216_16_cursor.descend_to_byte(v216_16_byte);
      let v216_16_tail = v216_16_cursor.make_map();
      v216_16_cursor.ascend(1);
      let v216_16_head = Path::from_slice(&[v216_16_byte]);
      let mut v218_2 = Space::new();
      let v218_2_arg_0: &Path = &(v216_16_head);
      let v218_2_arg_1: &Space = &(v216_16_tail);
      let v218_2_arg_2: &Space = &(*s0);
      let mut v218_2_cursor = v218_2_arg_1.read_zipper();
      let mut v218_2_more = v218_2_cursor.is_val() || v218_2_cursor.to_next_val();
      while v218_2_more {
        let v218_2_path = concat_path(v218_2_arg_0,v218_2_cursor.path());
        let v218_2_rest = v218_2_cursor.make_map();
        let v219_3: Space = unwrap(&(*v218_2_arg_2),&(v218_2_path));
        let v219_4: Space = routine_27(c, &(v219_3));
        drop(v219_3);
        let v219_5: Space = wrap(&(v219_4),&(v218_2_path));
        v218_2.join_into((v219_5).clone());
        v218_2_more = v218_2_cursor.to_next_val();
      }
      drop(v218_2_cursor);
      v216_16.join_into((v218_2).clone());
    }
    drop(v216_16_cursor);
    drop(v216_11);
    let v216_17: Space = unite(&(v216_15),&(v216_16));
    compose(&(v215_10),&(v216_17))
  };
  drop(v215_10);
  let v215_19: Space = unite(&(v215_7),&(v215_18));
  drop(v215_7);
  (v215_19).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v220_2 = Space::new();
  let mut v220_2_cursor = (*s0).read_zipper();
  for v220_2_byte in v220_2_cursor.child_mask().iter() {
    v220_2_cursor.descend_to_byte(v220_2_byte);
    let v220_2_tail = v220_2_cursor.make_map();
    v220_2_cursor.ascend(1);
    let v220_2_head = Path::from_slice(&[v220_2_byte]);
    let v221_2: Space = Space::new();
    v220_2.join_into((v221_2).clone());
  }
  drop(v220_2_cursor);
  (v220_2).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v222_6 = Space::new();
  let mut v222_6_cursor = (*s0).read_zipper();
  for v222_6_byte in v222_6_cursor.child_mask().iter() {
    v222_6_cursor.descend_to_byte(v222_6_byte);
    let v222_6_tail = v222_6_cursor.make_map();
    v222_6_cursor.ascend(1);
    let v222_6_head = Path::from_slice(&[v222_6_byte]);
    let v223_2: Space = singleton(&(v222_6_head));
    let v223_3: Space = intersect(&(*CONSTANT_9),&(v223_2));
    drop(v223_2);
    let v223_4: Space = if has_head(&(v223_3)) { singleton(&[]) } else { Space::new() };
    drop(v223_3);
    let v223_7: Space = if (v223_4).is_empty() { Space::new() } else {
      let v224_5: Path = concat_path(&(*p0),&(v222_6_head));
      let mut v224_6 = Space::new();
      let mut v224_6_cursor = (v222_6_tail).read_zipper();
      for v224_6_byte in v224_6_cursor.child_mask().iter() {
        v224_6_cursor.descend_to_byte(v224_6_byte);
        let v224_6_tail = v224_6_cursor.make_map();
        v224_6_cursor.ascend(1);
        let v224_6_head = Path::from_slice(&[v224_6_byte]);
        let v225_2: Space = singleton(&(v224_6_head));
        let v225_3: Space = intersect(&(*CONSTANT_9),&(v225_2));
        let v225_4: Space = if has_head(&(v225_3)) { singleton(&[]) } else { Space::new() };
        drop(v225_3);
        let v225_5: Space = subtract(&(*CONSTANT_0),&(v225_4));
        drop(v225_4);
        let v225_7: Space = if (v225_5).is_empty() { Space::new() } else {
          let v226_6: Space = routine_30(c, &(v224_6_head), &(v224_5), &(v224_6_tail));
          compose(&(v225_5),&(v226_6))
        };
        drop(v225_5);
        let v225_8: Space = intersect(&(*CONSTANT_9),&(v225_2));
        drop(v225_2);
        let v225_9: Space = if has_head(&(v225_8)) { singleton(&[]) } else { Space::new() };
        drop(v225_8);
        let v225_11: Space = if (v225_9).is_empty() { Space::new() } else {
          let v227_10: Space = routine_31(c, &(v224_6_head), &(v224_5), &(v224_6_tail));
          compose(&(v225_9),&(v227_10))
        };
        drop(v225_9);
        let v225_12: Space = unite(&(v225_7),&(v225_11));
        v224_6.join_into((v225_12).clone());
      }
      drop(v224_6_cursor);
      drop(v224_5);
      compose(&(v223_4),&(v224_6))
    };
    drop(v223_4);
    v222_6.join_into((v223_7).clone());
  }
  drop(v222_6_cursor);
  (v222_6).clone()
}

fn routine_30(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v228_12 = Space::new();
  let mut v228_12_cursor = (*s0).read_zipper();
  for v228_12_byte in v228_12_cursor.child_mask().iter() {
    v228_12_cursor.descend_to_byte(v228_12_byte);
    let v228_12_tail = v228_12_cursor.make_map();
    v228_12_cursor.ascend(1);
    let v228_12_head = Path::from_slice(&[v228_12_byte]);
    let v229_2: Space = singleton(&(v228_12_head));
    let v229_3: Space = intersect(&(*CONSTANT_9),&(v229_2));
    let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
    drop(v229_3);
    let v229_5: Space = subtract(&(*CONSTANT_0),&(v229_4));
    drop(v229_4);
    let v229_8: Space = if (v229_5).is_empty() { Space::new() } else {
      let v230_6: Path = concat_path(&(*p0),&(v228_12_head));
      let mut v230_7 = Space::new();
      let mut v230_7_cursor = (v228_12_tail).read_zipper();
      for v230_7_byte in v230_7_cursor.child_mask().iter() {
        v230_7_cursor.descend_to_byte(v230_7_byte);
        let v230_7_tail = v230_7_cursor.make_map();
        v230_7_cursor.ascend(1);
        let v230_7_head = Path::from_slice(&[v230_7_byte]);
        let v231_2: Space = singleton(&(v230_7_head));
        let v231_3: Space = intersect(&(*CONSTANT_9),&(v231_2));
        let v231_4: Space = if has_head(&(v231_3)) { singleton(&[]) } else { Space::new() };
        drop(v231_3);
        let v231_5: Space = subtract(&(*CONSTANT_0),&(v231_4));
        drop(v231_4);
        let v231_8: Space = if (v231_5).is_empty() { Space::new() } else {
          let v232_6: Path = concat_path(&(v230_6),&(v230_7_head));
          let v232_7: Space = routine_45(c, &(v232_6), &(*p1), &(v230_7_tail));
          compose(&(v231_5),&(v232_7))
        };
        drop(v231_5);
        let v231_9: Space = intersect(&(*CONSTANT_9),&(v231_2));
        drop(v231_2);
        let v231_10: Space = if has_head(&(v231_9)) { singleton(&[]) } else { Space::new() };
        drop(v231_9);
        let v231_12: Space = if (v231_10).is_empty() { Space::new() } else {
          let v233_6: Path = concat_path(&(v230_6),&(v230_7_head));
          let v233_11: Space = routine_46(c, &(v233_6), &(*p1), &(v230_7_tail));
          drop(v233_6);
          compose(&(v231_10),&(v233_11))
        };
        drop(v231_10);
        let v231_13: Space = unite(&(v231_8),&(v231_12));
        v230_7.join_into((v231_13).clone());
      }
      drop(v230_7_cursor);
      compose(&(v229_5),&(v230_7))
    };
    drop(v229_5);
    let v229_9: Space = intersect(&(*CONSTANT_9),&(v229_2));
    drop(v229_2);
    let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
    drop(v229_9);
    let v229_12: Space = if (v229_10).is_empty() { Space::new() } else {
      let v234_6: Path = concat_path(&(*p0),&(v228_12_head));
      let mut v234_11 = Space::new();
      let mut v234_11_cursor = (v228_12_tail).read_zipper();
      for v234_11_byte in v234_11_cursor.child_mask().iter() {
        v234_11_cursor.descend_to_byte(v234_11_byte);
        let v234_11_tail = v234_11_cursor.make_map();
        v234_11_cursor.ascend(1);
        let v234_11_head = Path::from_slice(&[v234_11_byte]);
        let v235_2: Space = singleton(&(v234_11_head));
        let v235_3: Space = intersect(&(*CONSTANT_9),&(v235_2));
        let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
        drop(v235_3);
        let v235_5: Space = subtract(&(*CONSTANT_0),&(v235_4));
        drop(v235_4);
        let v235_8: Space = if (v235_5).is_empty() { Space::new() } else {
          let v236_6: Path = concat_path(&(v234_6),&(v234_11_head));
          let v236_7: Space = routine_45(c, &(v236_6), &(*p1), &(v234_11_tail));
          compose(&(v235_5),&(v236_7))
        };
        drop(v235_5);
        let v235_9: Space = intersect(&(*CONSTANT_9),&(v235_2));
        drop(v235_2);
        let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
        drop(v235_9);
        let v235_12: Space = if (v235_10).is_empty() { Space::new() } else {
          let v237_6: Path = concat_path(&(v234_6),&(v234_11_head));
          let v237_11: Space = routine_34(c, &(v237_6), &(*p1), &(v234_11_tail));
          drop(v237_6);
          compose(&(v235_10),&(v237_11))
        };
        drop(v235_10);
        let v235_13: Space = unite(&(v235_8),&(v235_12));
        v234_11.join_into((v235_13).clone());
      }
      drop(v234_11_cursor);
      drop(v234_6);
      compose(&(v229_10),&(v234_11))
    };
    drop(v229_10);
    let v229_13: Space = unite(&(v229_8),&(v229_12));
    v228_12.join_into((v229_13).clone());
  }
  drop(v228_12_cursor);
  (v228_12).clone()
}

fn routine_31(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v238_9 = Space::new();
  let mut v238_9_cursor = (*s0).read_zipper();
  for v238_9_byte in v238_9_cursor.child_mask().iter() {
    v238_9_cursor.descend_to_byte(v238_9_byte);
    let v238_9_tail = v238_9_cursor.make_map();
    v238_9_cursor.ascend(1);
    let v238_9_head = Path::from_slice(&[v238_9_byte]);
    let v239_2: Space = singleton(&(v238_9_head));
    let v239_3: Space = intersect(&(*CONSTANT_9),&(v239_2));
    let v239_4: Space = if has_head(&(v239_3)) { singleton(&[]) } else { Space::new() };
    drop(v239_3);
    let v239_5: Space = subtract(&(*CONSTANT_0),&(v239_4));
    drop(v239_4);
    let v239_8: Space = if (v239_5).is_empty() { Space::new() } else {
      let v240_6: Path = concat_path(&(*p0),&(v238_9_head));
      let mut v240_7 = Space::new();
      let mut v240_7_cursor = (v238_9_tail).read_zipper();
      for v240_7_byte in v240_7_cursor.child_mask().iter() {
        v240_7_cursor.descend_to_byte(v240_7_byte);
        let v240_7_tail = v240_7_cursor.make_map();
        v240_7_cursor.ascend(1);
        let v240_7_head = Path::from_slice(&[v240_7_byte]);
        let v241_2: Space = singleton(&(v240_7_head));
        let v241_3: Space = intersect(&(*CONSTANT_9),&(v241_2));
        let v241_4: Space = if has_head(&(v241_3)) { singleton(&[]) } else { Space::new() };
        drop(v241_3);
        let v241_5: Space = subtract(&(*CONSTANT_0),&(v241_4));
        drop(v241_4);
        let v241_8: Space = if (v241_5).is_empty() { Space::new() } else {
          let v242_6: Path = concat_path(&(v240_6),&(v240_7_head));
          let v242_7: Space = routine_45(c, &(v242_6), &(*p1), &(v240_7_tail));
          compose(&(v241_5),&(v242_7))
        };
        drop(v241_5);
        let v241_9: Space = intersect(&(*CONSTANT_9),&(v241_2));
        drop(v241_2);
        let v241_10: Space = if has_head(&(v241_9)) { singleton(&[]) } else { Space::new() };
        drop(v241_9);
        let v241_12: Space = if (v241_10).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v240_6),&(v240_7_head));
          let v243_11: Space = routine_46(c, &(v243_6), &(*p1), &(v240_7_tail));
          drop(v243_6);
          compose(&(v241_10),&(v243_11))
        };
        drop(v241_10);
        let v241_13: Space = unite(&(v241_8),&(v241_12));
        v240_7.join_into((v241_13).clone());
      }
      drop(v240_7_cursor);
      compose(&(v239_5),&(v240_7))
    };
    drop(v239_5);
    let v239_9: Space = intersect(&(*CONSTANT_9),&(v239_2));
    drop(v239_2);
    let v239_10: Space = if has_head(&(v239_9)) { singleton(&[]) } else { Space::new() };
    drop(v239_9);
    let v239_13: Space = if (v239_10).is_empty() { Space::new() } else {
      let v244_6: Path = concat_path(&(*p0),&(v238_9_head));
      let v244_11: Path = concat_path(&(v244_6),&(*p1));
      drop(v244_6);
      let v244_12: Space = singleton(&(v244_11));
      drop(v244_11);
      compose(&(v239_10),&(v244_12))
    };
    drop(v239_10);
    let v239_14: Space = unite(&(v239_8),&(v239_13));
    drop(v239_13);
    v238_9.join_into((v239_14).clone());
  }
  drop(v238_9_cursor);
  (v238_9).clone()
}

fn routine_32(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v245_12 = Space::new();
  let mut v245_12_cursor = (*s0).read_zipper();
  for v245_12_byte in v245_12_cursor.child_mask().iter() {
    v245_12_cursor.descend_to_byte(v245_12_byte);
    let v245_12_tail = v245_12_cursor.make_map();
    v245_12_cursor.ascend(1);
    let v245_12_head = Path::from_slice(&[v245_12_byte]);
    let v246_2: Space = singleton(&(v245_12_head));
    let v246_3: Space = intersect(&(*CONSTANT_9),&(v246_2));
    let v246_4: Space = if has_head(&(v246_3)) { singleton(&[]) } else { Space::new() };
    drop(v246_3);
    let v246_5: Space = subtract(&(*CONSTANT_0),&(v246_4));
    drop(v246_4);
    let v246_8: Space = if (v246_5).is_empty() { Space::new() } else {
      let v247_6: Path = concat_path(&(*p0),&(v245_12_head));
      let mut v247_7 = Space::new();
      let mut v247_7_cursor = (v245_12_tail).read_zipper();
      for v247_7_byte in v247_7_cursor.child_mask().iter() {
        v247_7_cursor.descend_to_byte(v247_7_byte);
        let v247_7_tail = v247_7_cursor.make_map();
        v247_7_cursor.ascend(1);
        let v247_7_head = Path::from_slice(&[v247_7_byte]);
        let v248_2: Space = singleton(&(v247_7_head));
        let v248_3: Space = intersect(&(*CONSTANT_9),&(v248_2));
        let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
        drop(v248_3);
        let v248_5: Space = subtract(&(*CONSTANT_0),&(v248_4));
        drop(v248_4);
        let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
          let v249_6: Path = concat_path(&(v247_6),&(v247_7_head));
          let v249_7: Space = routine_47(c, &(v249_6), &(*p1), &(v247_7_tail));
          compose(&(v248_5),&(v249_7))
        };
        drop(v248_5);
        let v248_9: Space = intersect(&(*CONSTANT_9),&(v248_2));
        drop(v248_2);
        let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
        drop(v248_9);
        let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
          let v250_6: Path = concat_path(&(v247_6),&(v247_7_head));
          let v250_11: Space = routine_48(c, &(v250_6), &(*p1), &(v247_7_tail));
          drop(v250_6);
          compose(&(v248_10),&(v250_11))
        };
        drop(v248_10);
        let v248_13: Space = unite(&(v248_8),&(v248_12));
        v247_7.join_into((v248_13).clone());
      }
      drop(v247_7_cursor);
      compose(&(v246_5),&(v247_7))
    };
    drop(v246_5);
    let v246_9: Space = intersect(&(*CONSTANT_9),&(v246_2));
    drop(v246_2);
    let v246_10: Space = if has_head(&(v246_9)) { singleton(&[]) } else { Space::new() };
    drop(v246_9);
    let v246_12: Space = if (v246_10).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&(v245_12_head));
      let mut v251_11 = Space::new();
      let mut v251_11_cursor = (v245_12_tail).read_zipper();
      for v251_11_byte in v251_11_cursor.child_mask().iter() {
        v251_11_cursor.descend_to_byte(v251_11_byte);
        let v251_11_tail = v251_11_cursor.make_map();
        v251_11_cursor.ascend(1);
        let v251_11_head = Path::from_slice(&[v251_11_byte]);
        let v252_2: Space = singleton(&(v251_11_head));
        let v252_3: Space = intersect(&(*CONSTANT_9),&(v252_2));
        let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = subtract(&(*CONSTANT_0),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (v252_5).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&(v251_11_head));
          let v253_7: Space = routine_47(c, &(v253_6), &(*p1), &(v251_11_tail));
          compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = intersect(&(*CONSTANT_9),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_12: Space = if (v252_10).is_empty() { Space::new() } else {
          let v254_6: Path = concat_path(&(v251_6),&(v251_11_head));
          let v254_11: Space = routine_34(c, &(v254_6), &(*p1), &(v251_11_tail));
          drop(v254_6);
          compose(&(v252_10),&(v254_11))
        };
        drop(v252_10);
        let v252_13: Space = unite(&(v252_8),&(v252_12));
        v251_11.join_into((v252_13).clone());
      }
      drop(v251_11_cursor);
      drop(v251_6);
      compose(&(v246_10),&(v251_11))
    };
    drop(v246_10);
    let v246_13: Space = unite(&(v246_8),&(v246_12));
    v245_12.join_into((v246_13).clone());
  }
  drop(v245_12_cursor);
  (v245_12).clone()
}

fn routine_33(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v255_9 = Space::new();
  let mut v255_9_cursor = (*s0).read_zipper();
  for v255_9_byte in v255_9_cursor.child_mask().iter() {
    v255_9_cursor.descend_to_byte(v255_9_byte);
    let v255_9_tail = v255_9_cursor.make_map();
    v255_9_cursor.ascend(1);
    let v255_9_head = Path::from_slice(&[v255_9_byte]);
    let v256_2: Space = singleton(&(v255_9_head));
    let v256_3: Space = intersect(&(*CONSTANT_9),&(v256_2));
    let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
    drop(v256_3);
    let v256_5: Space = subtract(&(*CONSTANT_0),&(v256_4));
    drop(v256_4);
    let v256_8: Space = if (v256_5).is_empty() { Space::new() } else {
      let v257_6: Path = concat_path(&(*p0),&(v255_9_head));
      let mut v257_7 = Space::new();
      let mut v257_7_cursor = (v255_9_tail).read_zipper();
      for v257_7_byte in v257_7_cursor.child_mask().iter() {
        v257_7_cursor.descend_to_byte(v257_7_byte);
        let v257_7_tail = v257_7_cursor.make_map();
        v257_7_cursor.ascend(1);
        let v257_7_head = Path::from_slice(&[v257_7_byte]);
        let v258_2: Space = singleton(&(v257_7_head));
        let v258_3: Space = intersect(&(*CONSTANT_9),&(v258_2));
        let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
        drop(v258_3);
        let v258_5: Space = subtract(&(*CONSTANT_0),&(v258_4));
        drop(v258_4);
        let v258_8: Space = if (v258_5).is_empty() { Space::new() } else {
          let v259_6: Path = concat_path(&(v257_6),&(v257_7_head));
          let v259_7: Space = routine_47(c, &(v259_6), &(*p1), &(v257_7_tail));
          compose(&(v258_5),&(v259_7))
        };
        drop(v258_5);
        let v258_9: Space = intersect(&(*CONSTANT_9),&(v258_2));
        drop(v258_2);
        let v258_10: Space = if has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
        drop(v258_9);
        let v258_12: Space = if (v258_10).is_empty() { Space::new() } else {
          let v260_6: Path = concat_path(&(v257_6),&(v257_7_head));
          let v260_11: Space = routine_48(c, &(v260_6), &(*p1), &(v257_7_tail));
          drop(v260_6);
          compose(&(v258_10),&(v260_11))
        };
        drop(v258_10);
        let v258_13: Space = unite(&(v258_8),&(v258_12));
        v257_7.join_into((v258_13).clone());
      }
      drop(v257_7_cursor);
      compose(&(v256_5),&(v257_7))
    };
    drop(v256_5);
    let v256_9: Space = intersect(&(*CONSTANT_9),&(v256_2));
    drop(v256_2);
    let v256_10: Space = if has_head(&(v256_9)) { singleton(&[]) } else { Space::new() };
    drop(v256_9);
    let v256_13: Space = if (v256_10).is_empty() { Space::new() } else {
      let v261_6: Path = concat_path(&(*p0),&(v255_9_head));
      let v261_11: Path = concat_path(&(v261_6),&(*p1));
      drop(v261_6);
      let v261_12: Space = singleton(&(v261_11));
      drop(v261_11);
      compose(&(v256_10),&(v261_12))
    };
    drop(v256_10);
    let v256_14: Space = unite(&(v256_8),&(v256_13));
    drop(v256_13);
    v255_9.join_into((v256_14).clone());
  }
  drop(v255_9_cursor);
  (v255_9).clone()
}

fn routine_34(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v262_3: Path = concat_path(&(*p0),&(*p1));
  let v262_4: Space = singleton(&(v262_3));
  drop(v262_3);
  (v262_4).clone()
}

fn routine_35(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v263_9 = Space::new();
  let mut v263_9_cursor = (*s0).read_zipper();
  for v263_9_byte in v263_9_cursor.child_mask().iter() {
    v263_9_cursor.descend_to_byte(v263_9_byte);
    let v263_9_tail = v263_9_cursor.make_map();
    v263_9_cursor.ascend(1);
    let v263_9_head = Path::from_slice(&[v263_9_byte]);
    let v264_2: Space = singleton(&(v263_9_head));
    let v264_3: Space = intersect(&(*CONSTANT_9),&(v264_2));
    let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
    drop(v264_3);
    let v264_5: Space = subtract(&(*CONSTANT_0),&(v264_4));
    drop(v264_4);
    let mut v264_6 = Space::new();
    let mut v264_6_cursor = (v263_9_tail).read_zipper();
    for v264_6_byte in v264_6_cursor.child_mask().iter() {
      v264_6_cursor.descend_to_byte(v264_6_byte);
      let v264_6_tail = v264_6_cursor.make_map();
      v264_6_cursor.ascend(1);
      let v264_6_head = Path::from_slice(&[v264_6_byte]);
      let v265_2: Space = Space::new();
      v264_6.join_into((v265_2).clone());
    }
    drop(v264_6_cursor);
    let v264_7: Space = compose(&(v264_5),&(v264_6));
    drop(v264_5);
    drop(v264_6);
    let v264_8: Space = intersect(&(*CONSTANT_9),&(v264_2));
    drop(v264_2);
    let v264_9: Space = if has_head(&(v264_8)) { singleton(&[]) } else { Space::new() };
    drop(v264_8);
    let v264_12: Space = if (v264_9).is_empty() { Space::new() } else {
      let v266_10: Path = concat_path(&(*p0),&(v263_9_head));
      let mut v266_11 = Space::new();
      let mut v266_11_cursor = (v263_9_tail).read_zipper();
      for v266_11_byte in v266_11_cursor.child_mask().iter() {
        v266_11_cursor.descend_to_byte(v266_11_byte);
        let v266_11_tail = v266_11_cursor.make_map();
        v266_11_cursor.ascend(1);
        let v266_11_head = Path::from_slice(&[v266_11_byte]);
        let v267_2: Space = singleton(&(v266_11_head));
        let v267_3: Space = intersect(&(*CONSTANT_9),&(v267_2));
        drop(v267_2);
        let v267_4: Space = if has_head(&(v267_3)) { singleton(&[]) } else { Space::new() };
        drop(v267_3);
        let v267_7: Space = if (v267_4).is_empty() { Space::new() } else {
          let v268_5: Path = concat_path(&(v266_10),&(v266_11_head));
          let v268_6: Space = routine_37(c, &(v268_5), &(v266_11_tail), &(*s1), &(*s2), &(*s3));
          drop(v268_5);
          compose(&(v267_4),&(v268_6))
        };
        drop(v267_4);
        v266_11.join_into((v267_7).clone());
      }
      drop(v266_11_cursor);
      drop(v266_10);
      compose(&(v264_9),&(v266_11))
    };
    drop(v264_9);
    let v264_13: Space = unite(&(v264_7),&(v264_12));
    drop(v264_7);
    v263_9.join_into((v264_13).clone());
  }
  drop(v263_9_cursor);
  (v263_9).clone()
}

fn routine_36(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v269_8 = Space::new();
  let mut v269_8_cursor = (*s0).read_zipper();
  for v269_8_byte in v269_8_cursor.child_mask().iter() {
    v269_8_cursor.descend_to_byte(v269_8_byte);
    let v269_8_tail = v269_8_cursor.make_map();
    v269_8_cursor.ascend(1);
    let v269_8_head = Path::from_slice(&[v269_8_byte]);
    let v270_2: Space = singleton(&(v269_8_head));
    let v270_3: Space = intersect(&(*CONSTANT_9),&(v270_2));
    let v270_4: Space = if has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
    drop(v270_3);
    let v270_5: Space = subtract(&(*CONSTANT_0),&(v270_4));
    drop(v270_4);
    let mut v270_6 = Space::new();
    let mut v270_6_cursor = (v269_8_tail).read_zipper();
    for v270_6_byte in v270_6_cursor.child_mask().iter() {
      v270_6_cursor.descend_to_byte(v270_6_byte);
      let v270_6_tail = v270_6_cursor.make_map();
      v270_6_cursor.ascend(1);
      let v270_6_head = Path::from_slice(&[v270_6_byte]);
      let v271_2: Space = Space::new();
      v270_6.join_into((v271_2).clone());
    }
    drop(v270_6_cursor);
    let v270_7: Space = compose(&(v270_5),&(v270_6));
    drop(v270_5);
    drop(v270_6);
    let v270_8: Space = intersect(&(*CONSTANT_9),&(v270_2));
    drop(v270_2);
    let v270_9: Space = if has_head(&(v270_8)) { singleton(&[]) } else { Space::new() };
    drop(v270_8);
    let v270_27: Space = if (v270_9).is_empty() { Space::new() } else {
      let v272_10: Path = concat_path(&(*p0),&(v269_8_head));
      let v272_11: Space = singleton(&(v272_10));
      let v272_12: Space = routine_38(c, &(*s1), &(*s3), &(v272_11));
      let v272_13: Space = routine_38(c, &(*s2), &(*s3), &(v272_11));
      let v272_14: Space = intersect(&(v272_12),&(v272_13));
      let v272_15: Space = subtract(&(v272_14),&(v272_11));
      drop(v272_11);
      let v272_16: Space = wrap(&(v272_15),&(v272_10));
      drop(v272_10);
      let v272_17: Space = subtract(&(*s3),&(v272_13));
      let v272_18: Space = subtract(&(v272_17),&(v272_12));
      let v272_19: Space = routine_39(c, &(*s2), &(*s1), &(v272_18));
      let v272_20: Space = unite(&(v272_16),&(v272_19));
      let v272_21: Space = subtract(&(v272_12),&(v272_13));
      let v272_22: Space = routine_39(c, &(*s2), &(*s1), &(v272_21));
      let v272_23: Space = unite(&(v272_20),&(v272_22));
      let v272_24: Space = subtract(&(v272_13),&(v272_12));
      let v272_25: Space = routine_39(c, &(*s2), &(*s1), &(v272_24));
      let v272_26: Space = unite(&(v272_23),&(v272_25));
      compose(&(v270_9),&(v272_26))
    };
    drop(v270_9);
    let v270_28: Space = unite(&(v270_7),&(v270_27));
    drop(v270_7);
    v269_8.join_into((v270_28).clone());
  }
  drop(v269_8_cursor);
  (v269_8).clone()
}

fn routine_37(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let (v273_15,v273_25,v273_26,v273_27,v273_28,v273_38,v273_39,v273_49,v273_5,v273_50,v273_51,v273_91,) = native_block_0(c, p0, s1, s2, s3);
  let (v273_102,v273_112,v273_113,v273_114,v273_154,v273_92,) = native_block_1(c, s1, s2, s3, &v273_28, &v273_5, &v273_91);
  let (v273_155,v273_165,v273_175,v273_176,v273_177,v273_217,) = native_block_2(c, s1, s2, s3, &v273_154, &v273_5, &v273_92);
  drop(v273_5);
  let v273_218: Space = unite(&(v273_155),&(v273_217));
  (v273_218).clone()
}

fn routine_38(c: &mut Context, s0: &Space, s1: &Space, s2: &Space) -> Space {
  let v483_3: Space = intersect(&(*s1),&(*s2));
  let v483_4: Space = restrict_to(&(*s0),&(v483_3));
  drop(v483_3);
  let mut v483_14 = Space::new();
  let mut v483_14_cursor = (v483_4).read_zipper();
  for v483_14_byte in v483_14_cursor.child_mask().iter() {
    v483_14_cursor.descend_to_byte(v483_14_byte);
    let v483_14_tail = v483_14_cursor.make_map();
    v483_14_cursor.ascend(1);
    let v483_14_head = Path::from_slice(&[v483_14_byte]);
    let v484_2: Space = singleton(&(v483_14_head));
    let v484_3: Space = intersect(&(*CONSTANT_9),&(v484_2));
    let v484_4: Space = if has_head(&(v484_3)) { singleton(&[]) } else { Space::new() };
    drop(v484_3);
    let v484_5: Space = subtract(&(*CONSTANT_0),&(v484_4));
    drop(v484_4);
    let v484_7: Space = if (v484_5).is_empty() { Space::new() } else {
      let mut v485_6 = Space::new();
      let mut v485_6_cursor = (v483_14_tail).read_zipper();
      for v485_6_byte in v485_6_cursor.child_mask().iter() {
        v485_6_cursor.descend_to_byte(v485_6_byte);
        let v485_6_tail = v485_6_cursor.make_map();
        v485_6_cursor.ascend(1);
        let v485_6_head = Path::from_slice(&[v485_6_byte]);
        let v486_2: Space = singleton(&(v485_6_head));
        let v486_3: Space = intersect(&(*CONSTANT_9),&(v486_2));
        let v486_4: Space = if has_head(&(v486_3)) { singleton(&[]) } else { Space::new() };
        drop(v486_3);
        let v486_5: Space = subtract(&(*CONSTANT_0),&(v486_4));
        drop(v486_4);
        let v486_8: Space = if (v486_5).is_empty() { Space::new() } else {
          let v487_6: Path = concat_path(&(v483_14_head),&(v485_6_head));
          let v487_7: Space = routine_49(c, &(v487_6), &(v485_6_tail));
          compose(&(v486_5),&(v487_7))
        };
        drop(v486_5);
        let v486_9: Space = intersect(&(*CONSTANT_9),&(v486_2));
        drop(v486_2);
        let v486_10: Space = if has_head(&(v486_9)) { singleton(&[]) } else { Space::new() };
        drop(v486_9);
        let v486_12: Space = if (v486_10).is_empty() { Space::new() } else {
          let v488_6: Path = concat_path(&(v483_14_head),&(v485_6_head));
          let v488_11: Space = routine_50(c, &(v488_6), &(v485_6_tail));
          drop(v488_6);
          compose(&(v486_10),&(v488_11))
        };
        drop(v486_10);
        let v486_13: Space = unite(&(v486_8),&(v486_12));
        v485_6.join_into((v486_13).clone());
      }
      drop(v485_6_cursor);
      compose(&(v484_5),&(v485_6))
    };
    drop(v484_5);
    let v484_8: Space = intersect(&(*CONSTANT_9),&(v484_2));
    drop(v484_2);
    let v484_9: Space = if has_head(&(v484_8)) { singleton(&[]) } else { Space::new() };
    drop(v484_8);
    let v484_11: Space = if (v484_9).is_empty() { Space::new() } else {
      let mut v489_10 = Space::new();
      let mut v489_10_cursor = (v483_14_tail).read_zipper();
      for v489_10_byte in v489_10_cursor.child_mask().iter() {
        v489_10_cursor.descend_to_byte(v489_10_byte);
        let v489_10_tail = v489_10_cursor.make_map();
        v489_10_cursor.ascend(1);
        let v489_10_head = Path::from_slice(&[v489_10_byte]);
        let v490_2: Space = singleton(&(v489_10_head));
        let v490_3: Space = intersect(&(*CONSTANT_9),&(v490_2));
        let v490_4: Space = if has_head(&(v490_3)) { singleton(&[]) } else { Space::new() };
        drop(v490_3);
        let v490_5: Space = subtract(&(*CONSTANT_0),&(v490_4));
        drop(v490_4);
        let v490_8: Space = if (v490_5).is_empty() { Space::new() } else {
          let v491_6: Path = concat_path(&(v483_14_head),&(v489_10_head));
          let v491_7: Space = routine_49(c, &(v491_6), &(v489_10_tail));
          compose(&(v490_5),&(v491_7))
        };
        drop(v490_5);
        let v490_9: Space = intersect(&(*CONSTANT_9),&(v490_2));
        drop(v490_2);
        let v490_10: Space = if has_head(&(v490_9)) { singleton(&[]) } else { Space::new() };
        drop(v490_9);
        let v490_12: Space = if (v490_10).is_empty() { Space::new() } else {
          let v492_6: Path = concat_path(&(v483_14_head),&(v489_10_head));
          let v492_11: Space = routine_51(c, &(v492_6), &(v489_10_tail));
          drop(v492_6);
          compose(&(v490_10),&(v492_11))
        };
        drop(v490_10);
        let v490_13: Space = unite(&(v490_8),&(v490_12));
        v489_10.join_into((v490_13).clone());
      }
      drop(v489_10_cursor);
      compose(&(v484_9),&(v489_10))
    };
    drop(v484_9);
    let v484_12: Space = unite(&(v484_7),&(v484_11));
    v483_14.join_into((v484_12).clone());
  }
  drop(v483_14_cursor);
  drop(v483_4);
  let v483_15: Space = unite(&(v483_14),&(*s2));
  let v483_16: Space = intersect(&(v483_15),&(*s1));
  let mut v483_26: Space = (v483_16).clone();
  loop {
    let v493_1: Space = intersect(&(v483_26),&(*s1));
    let v493_2: Space = restrict_to(&(*s0),&(v493_1));
    drop(v493_1);
    let mut v493_3 = Space::new();
    let mut v493_3_cursor = (v493_2).read_zipper();
    for v493_3_byte in v493_3_cursor.child_mask().iter() {
      v493_3_cursor.descend_to_byte(v493_3_byte);
      let v493_3_tail = v493_3_cursor.make_map();
      v493_3_cursor.ascend(1);
      let v493_3_head = Path::from_slice(&[v493_3_byte]);
      let v494_2: Space = singleton(&(v493_3_head));
      let v494_3: Space = intersect(&(*CONSTANT_9),&(v494_2));
      let v494_4: Space = if has_head(&(v494_3)) { singleton(&[]) } else { Space::new() };
      drop(v494_3);
      let v494_5: Space = subtract(&(*CONSTANT_0),&(v494_4));
      drop(v494_4);
      let v494_7: Space = if (v494_5).is_empty() { Space::new() } else {
        let mut v495_6 = Space::new();
        let mut v495_6_cursor = (v493_3_tail).read_zipper();
        for v495_6_byte in v495_6_cursor.child_mask().iter() {
          v495_6_cursor.descend_to_byte(v495_6_byte);
          let v495_6_tail = v495_6_cursor.make_map();
          v495_6_cursor.ascend(1);
          let v495_6_head = Path::from_slice(&[v495_6_byte]);
          let v496_2: Space = singleton(&(v495_6_head));
          let v496_3: Space = intersect(&(*CONSTANT_9),&(v496_2));
          let v496_4: Space = if has_head(&(v496_3)) { singleton(&[]) } else { Space::new() };
          drop(v496_3);
          let v496_5: Space = subtract(&(*CONSTANT_0),&(v496_4));
          drop(v496_4);
          let v496_8: Space = if (v496_5).is_empty() { Space::new() } else {
            let v497_6: Path = concat_path(&(v493_3_head),&(v495_6_head));
            let v497_7: Space = routine_49(c, &(v497_6), &(v495_6_tail));
            compose(&(v496_5),&(v497_7))
          };
          drop(v496_5);
          let v496_9: Space = intersect(&(*CONSTANT_9),&(v496_2));
          drop(v496_2);
          let v496_10: Space = if has_head(&(v496_9)) { singleton(&[]) } else { Space::new() };
          drop(v496_9);
          let v496_12: Space = if (v496_10).is_empty() { Space::new() } else {
            let v498_6: Path = concat_path(&(v493_3_head),&(v495_6_head));
            let v498_11: Space = routine_50(c, &(v498_6), &(v495_6_tail));
            drop(v498_6);
            compose(&(v496_10),&(v498_11))
          };
          drop(v496_10);
          let v496_13: Space = unite(&(v496_8),&(v496_12));
          v495_6.join_into((v496_13).clone());
        }
        drop(v495_6_cursor);
        compose(&(v494_5),&(v495_6))
      };
      drop(v494_5);
      let v494_8: Space = intersect(&(*CONSTANT_9),&(v494_2));
      drop(v494_2);
      let v494_9: Space = if has_head(&(v494_8)) { singleton(&[]) } else { Space::new() };
      drop(v494_8);
      let v494_11: Space = if (v494_9).is_empty() { Space::new() } else {
        let mut v499_10 = Space::new();
        let mut v499_10_cursor = (v493_3_tail).read_zipper();
        for v499_10_byte in v499_10_cursor.child_mask().iter() {
          v499_10_cursor.descend_to_byte(v499_10_byte);
          let v499_10_tail = v499_10_cursor.make_map();
          v499_10_cursor.ascend(1);
          let v499_10_head = Path::from_slice(&[v499_10_byte]);
          let v500_2: Space = singleton(&(v499_10_head));
          let v500_3: Space = intersect(&(*CONSTANT_9),&(v500_2));
          let v500_4: Space = if has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
          drop(v500_3);
          let v500_5: Space = subtract(&(*CONSTANT_0),&(v500_4));
          drop(v500_4);
          let v500_8: Space = if (v500_5).is_empty() { Space::new() } else {
            let v501_6: Path = concat_path(&(v493_3_head),&(v499_10_head));
            let v501_7: Space = routine_49(c, &(v501_6), &(v499_10_tail));
            compose(&(v500_5),&(v501_7))
          };
          drop(v500_5);
          let v500_9: Space = intersect(&(*CONSTANT_9),&(v500_2));
          drop(v500_2);
          let v500_10: Space = if has_head(&(v500_9)) { singleton(&[]) } else { Space::new() };
          drop(v500_9);
          let v500_12: Space = if (v500_10).is_empty() { Space::new() } else {
            let v502_6: Path = concat_path(&(v493_3_head),&(v499_10_head));
            let v502_11: Space = routine_51(c, &(v502_6), &(v499_10_tail));
            drop(v502_6);
            compose(&(v500_10),&(v502_11))
          };
          drop(v500_10);
          let v500_13: Space = unite(&(v500_8),&(v500_12));
          v499_10.join_into((v500_13).clone());
        }
        drop(v499_10_cursor);
        compose(&(v494_9),&(v499_10))
      };
      drop(v494_9);
      let v494_12: Space = unite(&(v494_7),&(v494_11));
      v493_3.join_into((v494_12).clone());
    }
    drop(v493_3_cursor);
    drop(v493_2);
    let v493_4: Space = unite(&(v493_3),&(v483_26));
    let v493_5: Space = intersect(&(v493_4),&(*s1));
    let v483_26_next = unite(&v483_26,&(v493_5));
    if equal(&v483_26_next,&v483_26) { break; }
    v483_26 = v483_26_next;
  }
  let v483_27: Space = unite(&(*s2),&(v483_26));
  (v483_27).clone()
}

fn routine_39(c: &mut Context, s0: &Space, s1: &Space, s2: &Space) -> Space {
  let v503_3: Space = routine_52(c, &(*s2));
  let v503_4: Space = subtract(&(*s2),&(v503_3));
  let mut v503_14 = Space::new();
  let mut v503_14_cursor = (v503_4).read_zipper();
  for v503_14_byte in v503_14_cursor.child_mask().iter() {
    v503_14_cursor.descend_to_byte(v503_14_byte);
    let v503_14_tail = v503_14_cursor.make_map();
    v503_14_cursor.ascend(1);
    let v503_14_head = Path::from_slice(&[v503_14_byte]);
    let v504_2: Space = singleton(&(v503_14_head));
    let v504_3: Space = intersect(&(*CONSTANT_9),&(v504_2));
    let v504_4: Space = if has_head(&(v504_3)) { singleton(&[]) } else { Space::new() };
    drop(v504_3);
    let v504_5: Space = subtract(&(*CONSTANT_0),&(v504_4));
    drop(v504_4);
    let v504_7: Space = if (v504_5).is_empty() { Space::new() } else {
      let mut v505_6 = Space::new();
      let mut v505_6_cursor = (v503_14_tail).read_zipper();
      for v505_6_byte in v505_6_cursor.child_mask().iter() {
        v505_6_cursor.descend_to_byte(v505_6_byte);
        let v505_6_tail = v505_6_cursor.make_map();
        v505_6_cursor.ascend(1);
        let v505_6_head = Path::from_slice(&[v505_6_byte]);
        let v506_2: Space = singleton(&(v505_6_head));
        let v506_3: Space = intersect(&(*CONSTANT_9),&(v506_2));
        let v506_4: Space = if has_head(&(v506_3)) { singleton(&[]) } else { Space::new() };
        drop(v506_3);
        let v506_5: Space = subtract(&(*CONSTANT_0),&(v506_4));
        drop(v506_4);
        let v506_8: Space = if (v506_5).is_empty() { Space::new() } else {
          let v507_6: Path = concat_path(&(v503_14_head),&(v505_6_head));
          let v507_7: Space = routine_53(c, &(v507_6), &(v505_6_tail), &(*s1), &(*s0), &(*s2));
          compose(&(v506_5),&(v507_7))
        };
        drop(v506_5);
        let v506_9: Space = intersect(&(*CONSTANT_9),&(v506_2));
        drop(v506_2);
        let v506_10: Space = if has_head(&(v506_9)) { singleton(&[]) } else { Space::new() };
        drop(v506_9);
        let v506_12: Space = if (v506_10).is_empty() { Space::new() } else {
          let v508_6: Path = concat_path(&(v503_14_head),&(v505_6_head));
          let v508_11: Space = routine_54(c, &(v508_6), &(v505_6_tail), &(*s1), &(*s0), &(*s2));
          drop(v508_6);
          compose(&(v506_10),&(v508_11))
        };
        drop(v506_10);
        let v506_13: Space = unite(&(v506_8),&(v506_12));
        v505_6.join_into((v506_13).clone());
      }
      drop(v505_6_cursor);
      compose(&(v504_5),&(v505_6))
    };
    drop(v504_5);
    let v504_8: Space = intersect(&(*CONSTANT_9),&(v504_2));
    drop(v504_2);
    let v504_9: Space = if has_head(&(v504_8)) { singleton(&[]) } else { Space::new() };
    drop(v504_8);
    let v504_11: Space = if (v504_9).is_empty() { Space::new() } else {
      let mut v509_10 = Space::new();
      let mut v509_10_cursor = (v503_14_tail).read_zipper();
      for v509_10_byte in v509_10_cursor.child_mask().iter() {
        v509_10_cursor.descend_to_byte(v509_10_byte);
        let v509_10_tail = v509_10_cursor.make_map();
        v509_10_cursor.ascend(1);
        let v509_10_head = Path::from_slice(&[v509_10_byte]);
        let v510_2: Space = singleton(&(v509_10_head));
        let v510_3: Space = intersect(&(*CONSTANT_9),&(v510_2));
        let v510_4: Space = if has_head(&(v510_3)) { singleton(&[]) } else { Space::new() };
        drop(v510_3);
        let v510_5: Space = subtract(&(*CONSTANT_0),&(v510_4));
        drop(v510_4);
        let v510_8: Space = if (v510_5).is_empty() { Space::new() } else {
          let v511_6: Path = concat_path(&(v503_14_head),&(v509_10_head));
          let v511_7: Space = routine_53(c, &(v511_6), &(v509_10_tail), &(*s1), &(*s0), &(*s2));
          compose(&(v510_5),&(v511_7))
        };
        drop(v510_5);
        let v510_9: Space = intersect(&(*CONSTANT_9),&(v510_2));
        drop(v510_2);
        let v510_10: Space = if has_head(&(v510_9)) { singleton(&[]) } else { Space::new() };
        drop(v510_9);
        let v510_12: Space = if (v510_10).is_empty() { Space::new() } else {
          let v512_6: Path = concat_path(&(v503_14_head),&(v509_10_head));
          let v512_11: Space = routine_37(c, &(v512_6), &(v509_10_tail), &(*s1), &(*s0), &(*s2));
          drop(v512_6);
          compose(&(v510_10),&(v512_11))
        };
        drop(v510_10);
        let v510_13: Space = unite(&(v510_8),&(v510_12));
        v509_10.join_into((v510_13).clone());
      }
      drop(v509_10_cursor);
      compose(&(v504_9),&(v509_10))
    };
    drop(v504_9);
    let v504_12: Space = unite(&(v504_7),&(v504_11));
    v503_14.join_into((v504_12).clone());
  }
  drop(v503_14_cursor);
  (v503_14).clone()
}

fn routine_40(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v513_7 = Space::new();
  let mut v513_7_cursor = (*s0).read_zipper();
  for v513_7_byte in v513_7_cursor.child_mask().iter() {
    v513_7_cursor.descend_to_byte(v513_7_byte);
    let v513_7_tail = v513_7_cursor.make_map();
    v513_7_cursor.ascend(1);
    let v513_7_head = Path::from_slice(&[v513_7_byte]);
    let v514_2: Space = singleton(&(v513_7_head));
    let v514_3: Space = intersect(&(*CONSTANT_9),&(v514_2));
    let v514_4: Space = if has_head(&(v514_3)) { singleton(&[]) } else { Space::new() };
    drop(v514_3);
    let v514_5: Space = subtract(&(*CONSTANT_0),&(v514_4));
    drop(v514_4);
    let mut v514_6 = Space::new();
    let mut v514_6_cursor = (v513_7_tail).read_zipper();
    for v514_6_byte in v514_6_cursor.child_mask().iter() {
      v514_6_cursor.descend_to_byte(v514_6_byte);
      let v514_6_tail = v514_6_cursor.make_map();
      v514_6_cursor.ascend(1);
      let v514_6_head = Path::from_slice(&[v514_6_byte]);
      let v515_2: Space = Space::new();
      v514_6.join_into((v515_2).clone());
    }
    drop(v514_6_cursor);
    let v514_7: Space = compose(&(v514_5),&(v514_6));
    drop(v514_5);
    drop(v514_6);
    let v514_8: Space = intersect(&(*CONSTANT_9),&(v514_2));
    drop(v514_2);
    let v514_9: Space = if has_head(&(v514_8)) { singleton(&[]) } else { Space::new() };
    drop(v514_8);
    let v514_12: Space = if (v514_9).is_empty() { Space::new() } else {
      let v516_10: Path = concat_path(&(*p0),&(v513_7_head));
      let mut v516_11 = Space::new();
      let mut v516_11_cursor = (v513_7_tail).read_zipper();
      for v516_11_byte in v516_11_cursor.child_mask().iter() {
        v516_11_cursor.descend_to_byte(v516_11_byte);
        let v516_11_tail = v516_11_cursor.make_map();
        v516_11_cursor.ascend(1);
        let v516_11_head = Path::from_slice(&[v516_11_byte]);
        let v517_2: Space = singleton(&(v516_11_head));
        let v517_3: Space = intersect(&(*CONSTANT_9),&(v517_2));
        drop(v517_2);
        let v517_4: Space = if has_head(&(v517_3)) { singleton(&[]) } else { Space::new() };
        drop(v517_3);
        let v517_7: Space = if (v517_4).is_empty() { Space::new() } else {
          let v518_5: Path = concat_path(&(v516_10),&(v516_11_head));
          let v518_6: Space = routine_24(c, &(v518_5), &(*p1), &(v516_11_tail));
          drop(v518_5);
          compose(&(v517_4),&(v518_6))
        };
        drop(v517_4);
        v516_11.join_into((v517_7).clone());
      }
      drop(v516_11_cursor);
      drop(v516_10);
      compose(&(v514_9),&(v516_11))
    };
    drop(v514_9);
    let v514_13: Space = unite(&(v514_7),&(v514_12));
    drop(v514_7);
    v513_7.join_into((v514_13).clone());
  }
  drop(v513_7_cursor);
  (v513_7).clone()
}

fn routine_41(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v519_6 = Space::new();
  let mut v519_6_cursor = (*s0).read_zipper();
  for v519_6_byte in v519_6_cursor.child_mask().iter() {
    v519_6_cursor.descend_to_byte(v519_6_byte);
    let v519_6_tail = v519_6_cursor.make_map();
    v519_6_cursor.ascend(1);
    let v519_6_head = Path::from_slice(&[v519_6_byte]);
    let v520_2: Space = singleton(&(v519_6_head));
    let v520_3: Space = intersect(&(*CONSTANT_9),&(v520_2));
    let v520_4: Space = if has_head(&(v520_3)) { singleton(&[]) } else { Space::new() };
    drop(v520_3);
    let v520_5: Space = subtract(&(*CONSTANT_0),&(v520_4));
    drop(v520_4);
    let mut v520_6 = Space::new();
    let mut v520_6_cursor = (v519_6_tail).read_zipper();
    for v520_6_byte in v520_6_cursor.child_mask().iter() {
      v520_6_cursor.descend_to_byte(v520_6_byte);
      let v520_6_tail = v520_6_cursor.make_map();
      v520_6_cursor.ascend(1);
      let v520_6_head = Path::from_slice(&[v520_6_byte]);
      let v521_2: Space = Space::new();
      v520_6.join_into((v521_2).clone());
    }
    drop(v520_6_cursor);
    let v520_7: Space = compose(&(v520_5),&(v520_6));
    drop(v520_5);
    drop(v520_6);
    let v520_8: Space = intersect(&(*CONSTANT_9),&(v520_2));
    drop(v520_2);
    let v520_9: Space = if has_head(&(v520_8)) { singleton(&[]) } else { Space::new() };
    drop(v520_8);
    let v520_13: Space = if (v520_9).is_empty() { Space::new() } else {
      let v522_10: Path = concat_path(&(*p0),&(v519_6_head));
      let v522_11: Path = concat_path(&(v522_10),&(*p1));
      drop(v522_10);
      let v522_12: Space = singleton(&(v522_11));
      drop(v522_11);
      compose(&(v520_9),&(v522_12))
    };
    drop(v520_9);
    let v520_14: Space = unite(&(v520_7),&(v520_13));
    drop(v520_7);
    drop(v520_13);
    v519_6.join_into((v520_14).clone());
  }
  drop(v519_6_cursor);
  (v519_6).clone()
}

fn routine_42(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v523_3 = Space::new();
  let mut v523_3_cursor = (*s0).read_zipper();
  for v523_3_byte in v523_3_cursor.child_mask().iter() {
    v523_3_cursor.descend_to_byte(v523_3_byte);
    let v523_3_tail = v523_3_cursor.make_map();
    v523_3_cursor.ascend(1);
    let v523_3_head = Path::from_slice(&[v523_3_byte]);
    let v524_2: Space = Space::new();
    v523_3.join_into((v524_2).clone());
  }
  drop(v523_3_cursor);
  (v523_3).clone()
}

fn routine_43(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v525_4 = Space::new();
  let mut v525_4_cursor = (*s0).read_zipper();
  for v525_4_byte in v525_4_cursor.child_mask().iter() {
    v525_4_cursor.descend_to_byte(v525_4_byte);
    let v525_4_tail = v525_4_cursor.make_map();
    v525_4_cursor.ascend(1);
    let v525_4_head = Path::from_slice(&[v525_4_byte]);
    let v526_2: Space = singleton(&(v525_4_head));
    let v526_3: Space = intersect(&(*CONSTANT_9),&(v526_2));
    drop(v526_2);
    let v526_4: Space = if has_head(&(v526_3)) { singleton(&[]) } else { Space::new() };
    drop(v526_3);
    let v526_8: Space = if (v526_4).is_empty() { Space::new() } else {
      let v527_5: Path = concat_path(&(*p0),&(v525_4_head));
      let v527_6: Path = concat_path(&(v527_5),&(*p1));
      drop(v527_5);
      let v527_7: Space = singleton(&(v527_6));
      drop(v527_6);
      compose(&(v526_4),&(v527_7))
    };
    drop(v526_4);
    v525_4.join_into((v526_8).clone());
  }
  drop(v525_4_cursor);
  (v525_4).clone()
}

fn routine_44(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v528_3: Space = unwrap(&(*s0),&(*p0));
  let v528_4: Space = first_matching(&(v528_3),&(*CONSTANT_0),false);
  let v528_5: Space = intersect(&(*CONSTANT_0),&(v528_4));
  let v528_6: Space = if has_head(&(v528_4)) { singleton(&[]) } else { Space::new() };
  let v528_7: Space = unite(&(v528_5),&(v528_6));
  drop(v528_5);
  let v528_9: Space = compose(&(v528_7),&(*CONSTANT_0));
  drop(v528_7);
  let v528_11: Space = subtract(&(*CONSTANT_0),&(v528_4));
  drop(v528_4);
  let v528_12: Space = subtract(&(v528_11),&(v528_6));
  drop(v528_6);
  drop(v528_11);
  let v528_16: Space = if (v528_12).is_empty() { Space::new() } else {
    let v529_14: Space = first_fibonacci(&(v528_3),6,5,true);
    let mut v529_15 = Space::new();
    let v529_15_arg_0: &Path = &(*CONSTANT_11);
    let v529_15_arg_1: &Space = &(v529_14);
    let v529_15_arg_2: &Space = &(v528_3);
    let mut v529_15_cursor = v529_15_arg_1.read_zipper();
    let mut v529_15_more = v529_15_cursor.is_val() || v529_15_cursor.to_next_val();
    while v529_15_more {
      let v529_15_path = concat_path(v529_15_arg_0,v529_15_cursor.path());
      let v529_15_rest = v529_15_cursor.make_map();
      let v530_3: Space = routine_44(c, &(v529_15_path), &(*v529_15_arg_2));
      v529_15.join_into((v530_3).clone());
      v529_15_more = v529_15_cursor.to_next_val();
    }
    drop(v529_15_cursor);
    drop(v529_14);
    compose(&(v528_12),&(v529_15))
  };
  drop(v528_12);
  let v528_17: Space = unite(&(v528_9),&(v528_16));
  drop(v528_9);
  let v528_18: Space = wrap(&(v528_17),&(*p0));
  (v528_18).clone()
}

fn routine_45(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v531_7 = Space::new();
  let mut v531_7_cursor = (*s0).read_zipper();
  for v531_7_byte in v531_7_cursor.child_mask().iter() {
    v531_7_cursor.descend_to_byte(v531_7_byte);
    let v531_7_tail = v531_7_cursor.make_map();
    v531_7_cursor.ascend(1);
    let v531_7_head = Path::from_slice(&[v531_7_byte]);
    let v532_2: Space = singleton(&(v531_7_head));
    let v532_3: Space = intersect(&(*CONSTANT_9),&(v532_2));
    let v532_4: Space = if has_head(&(v532_3)) { singleton(&[]) } else { Space::new() };
    drop(v532_3);
    let v532_5: Space = subtract(&(*CONSTANT_0),&(v532_4));
    drop(v532_4);
    let mut v532_6 = Space::new();
    let mut v532_6_cursor = (v531_7_tail).read_zipper();
    for v532_6_byte in v532_6_cursor.child_mask().iter() {
      v532_6_cursor.descend_to_byte(v532_6_byte);
      let v532_6_tail = v532_6_cursor.make_map();
      v532_6_cursor.ascend(1);
      let v532_6_head = Path::from_slice(&[v532_6_byte]);
      let v533_2: Space = Space::new();
      v532_6.join_into((v533_2).clone());
    }
    drop(v532_6_cursor);
    let v532_7: Space = compose(&(v532_5),&(v532_6));
    drop(v532_5);
    drop(v532_6);
    let v532_8: Space = intersect(&(*CONSTANT_9),&(v532_2));
    drop(v532_2);
    let v532_9: Space = if has_head(&(v532_8)) { singleton(&[]) } else { Space::new() };
    drop(v532_8);
    let v532_12: Space = if (v532_9).is_empty() { Space::new() } else {
      let v534_10: Path = concat_path(&(*p0),&(v531_7_head));
      let mut v534_11 = Space::new();
      let mut v534_11_cursor = (v531_7_tail).read_zipper();
      for v534_11_byte in v534_11_cursor.child_mask().iter() {
        v534_11_cursor.descend_to_byte(v534_11_byte);
        let v534_11_tail = v534_11_cursor.make_map();
        v534_11_cursor.ascend(1);
        let v534_11_head = Path::from_slice(&[v534_11_byte]);
        let v535_2: Space = singleton(&(v534_11_head));
        let v535_3: Space = intersect(&(*CONSTANT_9),&(v535_2));
        drop(v535_2);
        let v535_4: Space = if has_head(&(v535_3)) { singleton(&[]) } else { Space::new() };
        drop(v535_3);
        let v535_7: Space = if (v535_4).is_empty() { Space::new() } else {
          let v536_5: Path = concat_path(&(v534_10),&(v534_11_head));
          let v536_6: Space = routine_34(c, &(v536_5), &(*p1), &(v534_11_tail));
          drop(v536_5);
          compose(&(v535_4),&(v536_6))
        };
        drop(v535_4);
        v534_11.join_into((v535_7).clone());
      }
      drop(v534_11_cursor);
      drop(v534_10);
      compose(&(v532_9),&(v534_11))
    };
    drop(v532_9);
    let v532_13: Space = unite(&(v532_7),&(v532_12));
    drop(v532_7);
    v531_7.join_into((v532_13).clone());
  }
  drop(v531_7_cursor);
  (v531_7).clone()
}

fn routine_46(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v537_6 = Space::new();
  let mut v537_6_cursor = (*s0).read_zipper();
  for v537_6_byte in v537_6_cursor.child_mask().iter() {
    v537_6_cursor.descend_to_byte(v537_6_byte);
    let v537_6_tail = v537_6_cursor.make_map();
    v537_6_cursor.ascend(1);
    let v537_6_head = Path::from_slice(&[v537_6_byte]);
    let v538_2: Space = singleton(&(v537_6_head));
    let v538_3: Space = intersect(&(*CONSTANT_9),&(v538_2));
    let v538_4: Space = if has_head(&(v538_3)) { singleton(&[]) } else { Space::new() };
    drop(v538_3);
    let v538_5: Space = subtract(&(*CONSTANT_0),&(v538_4));
    drop(v538_4);
    let mut v538_6 = Space::new();
    let mut v538_6_cursor = (v537_6_tail).read_zipper();
    for v538_6_byte in v538_6_cursor.child_mask().iter() {
      v538_6_cursor.descend_to_byte(v538_6_byte);
      let v538_6_tail = v538_6_cursor.make_map();
      v538_6_cursor.ascend(1);
      let v538_6_head = Path::from_slice(&[v538_6_byte]);
      let v539_2: Space = Space::new();
      v538_6.join_into((v539_2).clone());
    }
    drop(v538_6_cursor);
    let v538_7: Space = compose(&(v538_5),&(v538_6));
    drop(v538_5);
    drop(v538_6);
    let v538_8: Space = intersect(&(*CONSTANT_9),&(v538_2));
    drop(v538_2);
    let v538_9: Space = if has_head(&(v538_8)) { singleton(&[]) } else { Space::new() };
    drop(v538_8);
    let v538_13: Space = if (v538_9).is_empty() { Space::new() } else {
      let v540_10: Path = concat_path(&(*p0),&(v537_6_head));
      let v540_11: Path = concat_path(&(v540_10),&(*p1));
      drop(v540_10);
      let v540_12: Space = singleton(&(v540_11));
      drop(v540_11);
      compose(&(v538_9),&(v540_12))
    };
    drop(v538_9);
    let v538_14: Space = unite(&(v538_7),&(v538_13));
    drop(v538_7);
    drop(v538_13);
    v537_6.join_into((v538_14).clone());
  }
  drop(v537_6_cursor);
  (v537_6).clone()
}

fn routine_47(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v541_3 = Space::new();
  let mut v541_3_cursor = (*s0).read_zipper();
  for v541_3_byte in v541_3_cursor.child_mask().iter() {
    v541_3_cursor.descend_to_byte(v541_3_byte);
    let v541_3_tail = v541_3_cursor.make_map();
    v541_3_cursor.ascend(1);
    let v541_3_head = Path::from_slice(&[v541_3_byte]);
    let v542_2: Space = Space::new();
    v541_3.join_into((v542_2).clone());
  }
  drop(v541_3_cursor);
  (v541_3).clone()
}

fn routine_48(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v543_4 = Space::new();
  let mut v543_4_cursor = (*s0).read_zipper();
  for v543_4_byte in v543_4_cursor.child_mask().iter() {
    v543_4_cursor.descend_to_byte(v543_4_byte);
    let v543_4_tail = v543_4_cursor.make_map();
    v543_4_cursor.ascend(1);
    let v543_4_head = Path::from_slice(&[v543_4_byte]);
    let v544_2: Space = singleton(&(v543_4_head));
    let v544_3: Space = intersect(&(*CONSTANT_9),&(v544_2));
    drop(v544_2);
    let v544_4: Space = if has_head(&(v544_3)) { singleton(&[]) } else { Space::new() };
    drop(v544_3);
    let v544_8: Space = if (v544_4).is_empty() { Space::new() } else {
      let v545_5: Path = concat_path(&(*p0),&(v543_4_head));
      let v545_6: Path = concat_path(&(v545_5),&(*p1));
      drop(v545_5);
      let v545_7: Space = singleton(&(v545_6));
      drop(v545_6);
      compose(&(v544_4),&(v545_7))
    };
    drop(v544_4);
    v543_4.join_into((v544_8).clone());
  }
  drop(v543_4_cursor);
  (v543_4).clone()
}

fn routine_49(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v546_11 = Space::new();
  let mut v546_11_cursor = (*s0).read_zipper();
  for v546_11_byte in v546_11_cursor.child_mask().iter() {
    v546_11_cursor.descend_to_byte(v546_11_byte);
    let v546_11_tail = v546_11_cursor.make_map();
    v546_11_cursor.ascend(1);
    let v546_11_head = Path::from_slice(&[v546_11_byte]);
    let v547_2: Space = singleton(&(v546_11_head));
    let v547_3: Space = intersect(&(*CONSTANT_9),&(v547_2));
    let v547_4: Space = if has_head(&(v547_3)) { singleton(&[]) } else { Space::new() };
    drop(v547_3);
    let v547_5: Space = subtract(&(*CONSTANT_0),&(v547_4));
    drop(v547_4);
    let v547_8: Space = if (v547_5).is_empty() { Space::new() } else {
      let v548_6: Path = concat_path(&(*p0),&(v546_11_head));
      let mut v548_7 = Space::new();
      let mut v548_7_cursor = (v546_11_tail).read_zipper();
      for v548_7_byte in v548_7_cursor.child_mask().iter() {
        v548_7_cursor.descend_to_byte(v548_7_byte);
        let v548_7_tail = v548_7_cursor.make_map();
        v548_7_cursor.ascend(1);
        let v548_7_head = Path::from_slice(&[v548_7_byte]);
        let v549_2: Space = singleton(&(v548_7_head));
        let v549_3: Space = intersect(&(*CONSTANT_9),&(v549_2));
        let v549_4: Space = if has_head(&(v549_3)) { singleton(&[]) } else { Space::new() };
        drop(v549_3);
        let v549_5: Space = subtract(&(*CONSTANT_0),&(v549_4));
        drop(v549_4);
        let v549_8: Space = if (v549_5).is_empty() { Space::new() } else {
          let v550_6: Path = concat_path(&(v548_6),&(v548_7_head));
          let v550_7: Space = routine_55(c, &(v550_6), &(v548_7_tail));
          compose(&(v549_5),&(v550_7))
        };
        drop(v549_5);
        let v549_9: Space = intersect(&(*CONSTANT_9),&(v549_2));
        drop(v549_2);
        let v549_10: Space = if has_head(&(v549_9)) { singleton(&[]) } else { Space::new() };
        drop(v549_9);
        let v549_12: Space = if (v549_10).is_empty() { Space::new() } else {
          let v551_6: Path = concat_path(&(v548_6),&(v548_7_head));
          let v551_11: Space = routine_56(c, &(v551_6), &(v548_7_tail));
          drop(v551_6);
          compose(&(v549_10),&(v551_11))
        };
        drop(v549_10);
        let v549_13: Space = unite(&(v549_8),&(v549_12));
        v548_7.join_into((v549_13).clone());
      }
      drop(v548_7_cursor);
      compose(&(v547_5),&(v548_7))
    };
    drop(v547_5);
    let v547_9: Space = intersect(&(*CONSTANT_9),&(v547_2));
    drop(v547_2);
    let v547_10: Space = if has_head(&(v547_9)) { singleton(&[]) } else { Space::new() };
    drop(v547_9);
    let v547_12: Space = if (v547_10).is_empty() { Space::new() } else {
      let v552_6: Path = concat_path(&(*p0),&(v546_11_head));
      let mut v552_11 = Space::new();
      let mut v552_11_cursor = (v546_11_tail).read_zipper();
      for v552_11_byte in v552_11_cursor.child_mask().iter() {
        v552_11_cursor.descend_to_byte(v552_11_byte);
        let v552_11_tail = v552_11_cursor.make_map();
        v552_11_cursor.ascend(1);
        let v552_11_head = Path::from_slice(&[v552_11_byte]);
        let v553_2: Space = singleton(&(v552_11_head));
        let v553_3: Space = intersect(&(*CONSTANT_9),&(v553_2));
        let v553_4: Space = if has_head(&(v553_3)) { singleton(&[]) } else { Space::new() };
        drop(v553_3);
        let v553_5: Space = subtract(&(*CONSTANT_0),&(v553_4));
        drop(v553_4);
        let v553_8: Space = if (v553_5).is_empty() { Space::new() } else {
          let v554_6: Path = concat_path(&(v552_6),&(v552_11_head));
          let v554_7: Space = routine_55(c, &(v554_6), &(v552_11_tail));
          compose(&(v553_5),&(v554_7))
        };
        drop(v553_5);
        let v553_9: Space = intersect(&(*CONSTANT_9),&(v553_2));
        drop(v553_2);
        let v553_10: Space = if has_head(&(v553_9)) { singleton(&[]) } else { Space::new() };
        drop(v553_9);
        let v553_12: Space = if (v553_10).is_empty() { Space::new() } else {
          let v555_6: Path = concat_path(&(v552_6),&(v552_11_head));
          let v555_11: Space = routine_51(c, &(v555_6), &(v552_11_tail));
          drop(v555_6);
          compose(&(v553_10),&(v555_11))
        };
        drop(v553_10);
        let v553_13: Space = unite(&(v553_8),&(v553_12));
        v552_11.join_into((v553_13).clone());
      }
      drop(v552_11_cursor);
      drop(v552_6);
      compose(&(v547_10),&(v552_11))
    };
    drop(v547_10);
    let v547_13: Space = unite(&(v547_8),&(v547_12));
    v546_11.join_into((v547_13).clone());
  }
  drop(v546_11_cursor);
  (v546_11).clone()
}

fn routine_50(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v556_8 = Space::new();
  let mut v556_8_cursor = (*s0).read_zipper();
  for v556_8_byte in v556_8_cursor.child_mask().iter() {
    v556_8_cursor.descend_to_byte(v556_8_byte);
    let v556_8_tail = v556_8_cursor.make_map();
    v556_8_cursor.ascend(1);
    let v556_8_head = Path::from_slice(&[v556_8_byte]);
    let v557_2: Space = singleton(&(v556_8_head));
    let v557_3: Space = intersect(&(*CONSTANT_9),&(v557_2));
    let v557_4: Space = if has_head(&(v557_3)) { singleton(&[]) } else { Space::new() };
    drop(v557_3);
    let v557_5: Space = subtract(&(*CONSTANT_0),&(v557_4));
    drop(v557_4);
    let v557_8: Space = if (v557_5).is_empty() { Space::new() } else {
      let v558_6: Path = concat_path(&(*p0),&(v556_8_head));
      let mut v558_7 = Space::new();
      let mut v558_7_cursor = (v556_8_tail).read_zipper();
      for v558_7_byte in v558_7_cursor.child_mask().iter() {
        v558_7_cursor.descend_to_byte(v558_7_byte);
        let v558_7_tail = v558_7_cursor.make_map();
        v558_7_cursor.ascend(1);
        let v558_7_head = Path::from_slice(&[v558_7_byte]);
        let v559_2: Space = singleton(&(v558_7_head));
        let v559_3: Space = intersect(&(*CONSTANT_9),&(v559_2));
        let v559_4: Space = if has_head(&(v559_3)) { singleton(&[]) } else { Space::new() };
        drop(v559_3);
        let v559_5: Space = subtract(&(*CONSTANT_0),&(v559_4));
        drop(v559_4);
        let v559_8: Space = if (v559_5).is_empty() { Space::new() } else {
          let v560_6: Path = concat_path(&(v558_6),&(v558_7_head));
          let v560_7: Space = routine_55(c, &(v560_6), &(v558_7_tail));
          compose(&(v559_5),&(v560_7))
        };
        drop(v559_5);
        let v559_9: Space = intersect(&(*CONSTANT_9),&(v559_2));
        drop(v559_2);
        let v559_10: Space = if has_head(&(v559_9)) { singleton(&[]) } else { Space::new() };
        drop(v559_9);
        let v559_12: Space = if (v559_10).is_empty() { Space::new() } else {
          let v561_6: Path = concat_path(&(v558_6),&(v558_7_head));
          let v561_11: Space = routine_56(c, &(v561_6), &(v558_7_tail));
          drop(v561_6);
          compose(&(v559_10),&(v561_11))
        };
        drop(v559_10);
        let v559_13: Space = unite(&(v559_8),&(v559_12));
        v558_7.join_into((v559_13).clone());
      }
      drop(v558_7_cursor);
      drop(v558_6);
      compose(&(v557_5),&(v558_7))
    };
    drop(v557_5);
    let v557_9: Space = intersect(&(*CONSTANT_9),&(v557_2));
    drop(v557_2);
    let v557_10: Space = if has_head(&(v557_9)) { singleton(&[]) } else { Space::new() };
    drop(v557_9);
    let v557_11: Space = compose(&(v557_10),&(v556_8_tail));
    drop(v557_10);
    let v557_12: Space = unite(&(v557_8),&(v557_11));
    drop(v557_11);
    v556_8.join_into((v557_12).clone());
  }
  drop(v556_8_cursor);
  (v556_8).clone()
}

fn routine_51(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_52(c: &mut Context, s0: &Space) -> Space {
  let v563_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v563_2: Space = first_matching(&(*s0),&(*CONSTANT_0),false);
  let v563_3: Space = unite(&(v563_1),&(v563_2));
  drop(v563_1);
  let v563_19: Space = if (v563_3).is_empty() { Space::new() } else {
    let v564_5: Space = intersect(&(*CONSTANT_0),&(v563_2));
    let v564_6: Space = if has_head(&(v563_2)) { singleton(&[]) } else { Space::new() };
    let v564_7: Space = unite(&(v564_5),&(v564_6));
    drop(v564_5);
    let v564_9: Space = compose(&(v564_7),&(*CONSTANT_0));
    drop(v564_7);
    let v564_10: Space = subtract(&(*s0),&(v564_9));
    drop(v564_9);
    let v564_12: Space = subtract(&(*CONSTANT_0),&(v563_2));
    let v564_13: Space = subtract(&(v564_12),&(v564_6));
    drop(v564_6);
    drop(v564_12);
    let v564_17: Space = if (v564_13).is_empty() { Space::new() } else {
      let v565_15: Space = first_fibonacci(&(*s0),6,5,true);
      let mut v565_16 = Space::new();
      let v565_16_arg_0: &Path = &(*CONSTANT_11);
      let v565_16_arg_1: &Space = &(v565_15);
      let v565_16_arg_2: &Space = &(*s0);
      let mut v565_16_cursor = v565_16_arg_1.read_zipper();
      let mut v565_16_more = v565_16_cursor.is_val() || v565_16_cursor.to_next_val();
      while v565_16_more {
        let v565_16_path = concat_path(v565_16_arg_0,v565_16_cursor.path());
        let v565_16_rest = v565_16_cursor.make_map();
        let v566_3: Space = unwrap(&(*v565_16_arg_2),&(v565_16_path));
        let v566_4: Space = routine_27(c, &(v566_3));
        drop(v566_3);
        let v566_5: Space = wrap(&(v566_4),&(v565_16_path));
        v565_16.join_into((v566_5).clone());
        v565_16_more = v565_16_cursor.to_next_val();
      }
      drop(v565_16_cursor);
      drop(v565_15);
      compose(&(v564_13),&(v565_16))
    };
    drop(v564_13);
    let v564_18: Space = subtract(&(v564_10),&(v564_17));
    drop(v564_10);
    compose(&(v563_3),&(v564_18))
  };
  drop(v563_3);
  (v563_19).clone()
}

fn routine_53(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v567_14 = Space::new();
  let mut v567_14_cursor = (*s0).read_zipper();
  for v567_14_byte in v567_14_cursor.child_mask().iter() {
    v567_14_cursor.descend_to_byte(v567_14_byte);
    let v567_14_tail = v567_14_cursor.make_map();
    v567_14_cursor.ascend(1);
    let v567_14_head = Path::from_slice(&[v567_14_byte]);
    let v568_2: Space = singleton(&(v567_14_head));
    let v568_3: Space = intersect(&(*CONSTANT_9),&(v568_2));
    let v568_4: Space = if has_head(&(v568_3)) { singleton(&[]) } else { Space::new() };
    drop(v568_3);
    let v568_5: Space = subtract(&(*CONSTANT_0),&(v568_4));
    drop(v568_4);
    let v568_8: Space = if (v568_5).is_empty() { Space::new() } else {
      let v569_6: Path = concat_path(&(*p0),&(v567_14_head));
      let mut v569_7 = Space::new();
      let mut v569_7_cursor = (v567_14_tail).read_zipper();
      for v569_7_byte in v569_7_cursor.child_mask().iter() {
        v569_7_cursor.descend_to_byte(v569_7_byte);
        let v569_7_tail = v569_7_cursor.make_map();
        v569_7_cursor.ascend(1);
        let v569_7_head = Path::from_slice(&[v569_7_byte]);
        let v570_2: Space = singleton(&(v569_7_head));
        let v570_3: Space = intersect(&(*CONSTANT_9),&(v570_2));
        let v570_4: Space = if has_head(&(v570_3)) { singleton(&[]) } else { Space::new() };
        drop(v570_3);
        let v570_5: Space = subtract(&(*CONSTANT_0),&(v570_4));
        drop(v570_4);
        let v570_8: Space = if (v570_5).is_empty() { Space::new() } else {
          let v571_6: Path = concat_path(&(v569_6),&(v569_7_head));
          let v571_7: Space = routine_57(c, &(v571_6), &(v569_7_tail), &(*s1), &(*s2), &(*s3));
          compose(&(v570_5),&(v571_7))
        };
        drop(v570_5);
        let v570_9: Space = intersect(&(*CONSTANT_9),&(v570_2));
        drop(v570_2);
        let v570_10: Space = if has_head(&(v570_9)) { singleton(&[]) } else { Space::new() };
        drop(v570_9);
        let v570_12: Space = if (v570_10).is_empty() { Space::new() } else {
          let v572_6: Path = concat_path(&(v569_6),&(v569_7_head));
          let v572_11: Space = routine_58(c, &(v572_6), &(v569_7_tail), &(*s1), &(*s2), &(*s3));
          drop(v572_6);
          compose(&(v570_10),&(v572_11))
        };
        drop(v570_10);
        let v570_13: Space = unite(&(v570_8),&(v570_12));
        v569_7.join_into((v570_13).clone());
      }
      drop(v569_7_cursor);
      compose(&(v568_5),&(v569_7))
    };
    drop(v568_5);
    let v568_9: Space = intersect(&(*CONSTANT_9),&(v568_2));
    drop(v568_2);
    let v568_10: Space = if has_head(&(v568_9)) { singleton(&[]) } else { Space::new() };
    drop(v568_9);
    let v568_12: Space = if (v568_10).is_empty() { Space::new() } else {
      let v573_6: Path = concat_path(&(*p0),&(v567_14_head));
      let mut v573_11 = Space::new();
      let mut v573_11_cursor = (v567_14_tail).read_zipper();
      for v573_11_byte in v573_11_cursor.child_mask().iter() {
        v573_11_cursor.descend_to_byte(v573_11_byte);
        let v573_11_tail = v573_11_cursor.make_map();
        v573_11_cursor.ascend(1);
        let v573_11_head = Path::from_slice(&[v573_11_byte]);
        let v574_2: Space = singleton(&(v573_11_head));
        let v574_3: Space = intersect(&(*CONSTANT_9),&(v574_2));
        let v574_4: Space = if has_head(&(v574_3)) { singleton(&[]) } else { Space::new() };
        drop(v574_3);
        let v574_5: Space = subtract(&(*CONSTANT_0),&(v574_4));
        drop(v574_4);
        let v574_8: Space = if (v574_5).is_empty() { Space::new() } else {
          let v575_6: Path = concat_path(&(v573_6),&(v573_11_head));
          let v575_7: Space = routine_57(c, &(v575_6), &(v573_11_tail), &(*s1), &(*s2), &(*s3));
          compose(&(v574_5),&(v575_7))
        };
        drop(v574_5);
        let v574_9: Space = intersect(&(*CONSTANT_9),&(v574_2));
        drop(v574_2);
        let v574_10: Space = if has_head(&(v574_9)) { singleton(&[]) } else { Space::new() };
        drop(v574_9);
        let v574_12: Space = if (v574_10).is_empty() { Space::new() } else {
          let v576_6: Path = concat_path(&(v573_6),&(v573_11_head));
          let v576_11: Space = routine_37(c, &(v576_6), &(v573_11_tail), &(*s1), &(*s2), &(*s3));
          drop(v576_6);
          compose(&(v574_10),&(v576_11))
        };
        drop(v574_10);
        let v574_13: Space = unite(&(v574_8),&(v574_12));
        v573_11.join_into((v574_13).clone());
      }
      drop(v573_11_cursor);
      drop(v573_6);
      compose(&(v568_10),&(v573_11))
    };
    drop(v568_10);
    let v568_13: Space = unite(&(v568_8),&(v568_12));
    v567_14.join_into((v568_13).clone());
  }
  drop(v567_14_cursor);
  (v567_14).clone()
}

fn routine_54(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v577_11 = Space::new();
  let mut v577_11_cursor = (*s0).read_zipper();
  for v577_11_byte in v577_11_cursor.child_mask().iter() {
    v577_11_cursor.descend_to_byte(v577_11_byte);
    let v577_11_tail = v577_11_cursor.make_map();
    v577_11_cursor.ascend(1);
    let v577_11_head = Path::from_slice(&[v577_11_byte]);
    let v578_2: Space = singleton(&(v577_11_head));
    let v578_3: Space = intersect(&(*CONSTANT_9),&(v578_2));
    let v578_4: Space = if has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
    drop(v578_3);
    let v578_5: Space = subtract(&(*CONSTANT_0),&(v578_4));
    drop(v578_4);
    let v578_8: Space = if (v578_5).is_empty() { Space::new() } else {
      let v579_6: Path = concat_path(&(*p0),&(v577_11_head));
      let mut v579_7 = Space::new();
      let mut v579_7_cursor = (v577_11_tail).read_zipper();
      for v579_7_byte in v579_7_cursor.child_mask().iter() {
        v579_7_cursor.descend_to_byte(v579_7_byte);
        let v579_7_tail = v579_7_cursor.make_map();
        v579_7_cursor.ascend(1);
        let v579_7_head = Path::from_slice(&[v579_7_byte]);
        let v580_2: Space = singleton(&(v579_7_head));
        let v580_3: Space = intersect(&(*CONSTANT_9),&(v580_2));
        let v580_4: Space = if has_head(&(v580_3)) { singleton(&[]) } else { Space::new() };
        drop(v580_3);
        let v580_5: Space = subtract(&(*CONSTANT_0),&(v580_4));
        drop(v580_4);
        let v580_8: Space = if (v580_5).is_empty() { Space::new() } else {
          let v581_6: Path = concat_path(&(v579_6),&(v579_7_head));
          let v581_7: Space = routine_57(c, &(v581_6), &(v579_7_tail), &(*s1), &(*s2), &(*s3));
          compose(&(v580_5),&(v581_7))
        };
        drop(v580_5);
        let v580_9: Space = intersect(&(*CONSTANT_9),&(v580_2));
        drop(v580_2);
        let v580_10: Space = if has_head(&(v580_9)) { singleton(&[]) } else { Space::new() };
        drop(v580_9);
        let v580_12: Space = if (v580_10).is_empty() { Space::new() } else {
          let v582_6: Path = concat_path(&(v579_6),&(v579_7_head));
          let v582_11: Space = routine_58(c, &(v582_6), &(v579_7_tail), &(*s1), &(*s2), &(*s3));
          drop(v582_6);
          compose(&(v580_10),&(v582_11))
        };
        drop(v580_10);
        let v580_13: Space = unite(&(v580_8),&(v580_12));
        v579_7.join_into((v580_13).clone());
      }
      drop(v579_7_cursor);
      compose(&(v578_5),&(v579_7))
    };
    drop(v578_5);
    let v578_9: Space = intersect(&(*CONSTANT_9),&(v578_2));
    drop(v578_2);
    let v578_10: Space = if has_head(&(v578_9)) { singleton(&[]) } else { Space::new() };
    drop(v578_9);
    let v578_27: Space = if (v578_10).is_empty() { Space::new() } else {
      let v583_6: Path = concat_path(&(*p0),&(v577_11_head));
      let v583_11: Space = singleton(&(v583_6));
      let v583_12: Space = routine_38(c, &(*s1), &(*s3), &(v583_11));
      let v583_13: Space = routine_38(c, &(*s2), &(*s3), &(v583_11));
      let v583_14: Space = intersect(&(v583_12),&(v583_13));
      let v583_15: Space = subtract(&(v583_14),&(v583_11));
      drop(v583_11);
      let v583_16: Space = wrap(&(v583_15),&(v583_6));
      drop(v583_6);
      let v583_17: Space = subtract(&(*s3),&(v583_13));
      let v583_18: Space = subtract(&(v583_17),&(v583_12));
      let v583_19: Space = routine_39(c, &(*s2), &(*s1), &(v583_18));
      let v583_20: Space = unite(&(v583_16),&(v583_19));
      let v583_21: Space = subtract(&(v583_12),&(v583_13));
      let v583_22: Space = routine_39(c, &(*s2), &(*s1), &(v583_21));
      let v583_23: Space = unite(&(v583_20),&(v583_22));
      let v583_24: Space = subtract(&(v583_13),&(v583_12));
      let v583_25: Space = routine_39(c, &(*s2), &(*s1), &(v583_24));
      let v583_26: Space = unite(&(v583_23),&(v583_25));
      compose(&(v578_10),&(v583_26))
    };
    drop(v578_10);
    let v578_28: Space = unite(&(v578_8),&(v578_27));
    v577_11.join_into((v578_28).clone());
  }
  drop(v577_11_cursor);
  (v577_11).clone()
}

fn routine_55(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v584_2 = Space::new();
  let mut v584_2_cursor = (*s0).read_zipper();
  for v584_2_byte in v584_2_cursor.child_mask().iter() {
    v584_2_cursor.descend_to_byte(v584_2_byte);
    let v584_2_tail = v584_2_cursor.make_map();
    v584_2_cursor.ascend(1);
    let v584_2_head = Path::from_slice(&[v584_2_byte]);
    let v585_2: Space = Space::new();
    v584_2.join_into((v585_2).clone());
  }
  drop(v584_2_cursor);
  (v584_2).clone()
}

fn routine_56(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v586_3 = Space::new();
  let mut v586_3_cursor = (*s0).read_zipper();
  for v586_3_byte in v586_3_cursor.child_mask().iter() {
    v586_3_cursor.descend_to_byte(v586_3_byte);
    let v586_3_tail = v586_3_cursor.make_map();
    v586_3_cursor.ascend(1);
    let v586_3_head = Path::from_slice(&[v586_3_byte]);
    let v587_2: Space = singleton(&(v586_3_head));
    let v587_3: Space = intersect(&(*CONSTANT_9),&(v587_2));
    drop(v587_2);
    let v587_4: Space = if has_head(&(v587_3)) { singleton(&[]) } else { Space::new() };
    drop(v587_3);
    let v587_5: Space = compose(&(v587_4),&(v586_3_tail));
    drop(v587_4);
    v586_3.join_into((v587_5).clone());
  }
  drop(v586_3_cursor);
  (v586_3).clone()
}

fn routine_57(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v588_5 = Space::new();
  let mut v588_5_cursor = (*s0).read_zipper();
  for v588_5_byte in v588_5_cursor.child_mask().iter() {
    v588_5_cursor.descend_to_byte(v588_5_byte);
    let v588_5_tail = v588_5_cursor.make_map();
    v588_5_cursor.ascend(1);
    let v588_5_head = Path::from_slice(&[v588_5_byte]);
    let v589_2: Space = Space::new();
    v588_5.join_into((v589_2).clone());
  }
  drop(v588_5_cursor);
  (v588_5).clone()
}

fn routine_58(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v590_6 = Space::new();
  let mut v590_6_cursor = (*s0).read_zipper();
  for v590_6_byte in v590_6_cursor.child_mask().iter() {
    v590_6_cursor.descend_to_byte(v590_6_byte);
    let v590_6_tail = v590_6_cursor.make_map();
    v590_6_cursor.ascend(1);
    let v590_6_head = Path::from_slice(&[v590_6_byte]);
    let v591_2: Space = singleton(&(v590_6_head));
    let v591_3: Space = intersect(&(*CONSTANT_9),&(v591_2));
    drop(v591_2);
    let v591_4: Space = if has_head(&(v591_3)) { singleton(&[]) } else { Space::new() };
    drop(v591_3);
    let v591_22: Space = if (v591_4).is_empty() { Space::new() } else {
      let v592_5: Path = concat_path(&(*p0),&(v590_6_head));
      let v592_6: Space = singleton(&(v592_5));
      let v592_7: Space = routine_38(c, &(*s1), &(*s3), &(v592_6));
      let v592_8: Space = routine_38(c, &(*s2), &(*s3), &(v592_6));
      let v592_9: Space = intersect(&(v592_7),&(v592_8));
      let v592_10: Space = subtract(&(v592_9),&(v592_6));
      drop(v592_6);
      let v592_11: Space = wrap(&(v592_10),&(v592_5));
      drop(v592_5);
      let v592_12: Space = subtract(&(*s3),&(v592_8));
      let v592_13: Space = subtract(&(v592_12),&(v592_7));
      let v592_14: Space = routine_39(c, &(*s2), &(*s1), &(v592_13));
      let v592_15: Space = unite(&(v592_11),&(v592_14));
      let v592_16: Space = subtract(&(v592_7),&(v592_8));
      let v592_17: Space = routine_39(c, &(*s2), &(*s1), &(v592_16));
      let v592_18: Space = unite(&(v592_15),&(v592_17));
      let v592_19: Space = subtract(&(v592_8),&(v592_7));
      let v592_20: Space = routine_39(c, &(*s2), &(*s1), &(v592_19));
      let v592_21: Space = unite(&(v592_18),&(v592_20));
      compose(&(v591_4),&(v592_21))
    };
    drop(v591_4);
    v590_6.join_into((v591_22).clone());
  }
  drop(v590_6_cursor);
  (v590_6).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
