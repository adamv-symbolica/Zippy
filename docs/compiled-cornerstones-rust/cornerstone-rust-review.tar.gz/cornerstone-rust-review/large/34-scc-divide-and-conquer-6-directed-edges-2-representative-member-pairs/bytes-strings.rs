#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[97,0]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 2 98 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[98,0]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 2 97 0 2 99 0"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[99,0]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 2 100 0"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[100,0]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 2 99 0"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[101,0]));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 2 102 0"));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 97 0 98 0 4 98 0 97 0 4 98 0 99 0 4 99 0 100 0 4 100 0 99 0 4 101 0 102 0"));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &Path,capture_1: &Space,capture_2: &Space,capture_3: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v59_5: Space = singleton(&(*capture_0));
  let mut v59_12: Space = (v59_5).clone();
  loop {
    let v60_1: Space = intersect(&(v59_12),&(*capture_3));
    let v60_2: Space = restrict_to(&(*capture_1),&(v60_1));
    drop(v60_1);
    let mut v60_3 = Space::new();
    let mut v60_3_cursor = (v60_2).read_zipper();
    for v60_3_byte in v60_3_cursor.child_mask().iter() {
      v60_3_cursor.descend_to_byte(v60_3_byte);
      let v60_3_tail = v60_3_cursor.make_map();
      v60_3_cursor.ascend(1);
      let v60_3_head = Path::from_slice(&[v60_3_byte]);
      let v61_2: Space = singleton(&(v60_3_head));
      let v61_3: Space = intersect(&(*CONSTANT_11),&(v61_2));
      let v61_4: Space = if has_head(&(v61_3)) { singleton(&[]) } else { Space::new() };
      drop(v61_3);
      let v61_5: Space = subtract(&(*CONSTANT_0),&(v61_4));
      drop(v61_4);
      let v61_7: Space = if (v61_5).is_empty() { Space::new() } else {
        let mut v62_6 = Space::new();
        let mut v62_6_cursor = (v60_3_tail).read_zipper();
        for v62_6_byte in v62_6_cursor.child_mask().iter() {
          v62_6_cursor.descend_to_byte(v62_6_byte);
          let v62_6_tail = v62_6_cursor.make_map();
          v62_6_cursor.ascend(1);
          let v62_6_head = Path::from_slice(&[v62_6_byte]);
          let v63_2: Space = singleton(&(v62_6_head));
          let v63_3: Space = intersect(&(*CONSTANT_11),&(v63_2));
          let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
          drop(v63_3);
          let v63_5: Space = subtract(&(*CONSTANT_0),&(v63_4));
          drop(v63_4);
          let v63_8: Space = if (v63_5).is_empty() { Space::new() } else {
            let v64_6: Path = concat_path(&(v60_3_head),&(v62_6_head));
            let v64_7: Space = routine_14(c, &(v64_6), &(v62_6_tail));
            compose(&(v63_5),&(v64_7))
          };
          drop(v63_5);
          let v63_9: Space = intersect(&(*CONSTANT_11),&(v63_2));
          drop(v63_2);
          let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
          drop(v63_9);
          let v63_12: Space = if (v63_10).is_empty() { Space::new() } else {
            let v65_6: Path = concat_path(&(v60_3_head),&(v62_6_head));
            let v65_11: Space = routine_15(c, &(v65_6), &(v62_6_tail));
            drop(v65_6);
            compose(&(v63_10),&(v65_11))
          };
          drop(v63_10);
          let v63_13: Space = unite(&(v63_8),&(v63_12));
          v62_6.join_into((v63_13).clone());
        }
        drop(v62_6_cursor);
        compose(&(v61_5),&(v62_6))
      };
      drop(v61_5);
      let v61_8: Space = intersect(&(*CONSTANT_11),&(v61_2));
      drop(v61_2);
      let v61_9: Space = if has_head(&(v61_8)) { singleton(&[]) } else { Space::new() };
      drop(v61_8);
      let v61_10: Space = compose(&(v61_9),&(v60_3_tail));
      drop(v61_9);
      let v61_11: Space = unite(&(v61_7),&(v61_10));
      drop(v61_10);
      v60_3.join_into((v61_11).clone());
    }
    drop(v60_3_cursor);
    drop(v60_2);
    let v60_4: Space = unite(&(v60_3),&(v59_12));
    let v60_5: Space = intersect(&(v60_4),&(*capture_3));
    let v59_12_next = unite(&v59_12,&(v60_5));
    if equal(&v59_12_next,&v59_12) { break; }
    v59_12 = v59_12_next;
  }
  let mut v59_19: Space = (v59_5).clone();
  loop {
    let v66_1: Space = intersect(&(v59_19),&(*capture_3));
    let v66_2: Space = restrict_to(&(*capture_2),&(v66_1));
    drop(v66_1);
    let mut v66_3 = Space::new();
    let mut v66_3_cursor = (v66_2).read_zipper();
    for v66_3_byte in v66_3_cursor.child_mask().iter() {
      v66_3_cursor.descend_to_byte(v66_3_byte);
      let v66_3_tail = v66_3_cursor.make_map();
      v66_3_cursor.ascend(1);
      let v66_3_head = Path::from_slice(&[v66_3_byte]);
      let v67_2: Space = singleton(&(v66_3_head));
      let v67_3: Space = intersect(&(*CONSTANT_11),&(v67_2));
      let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
      drop(v67_3);
      let v67_5: Space = subtract(&(*CONSTANT_0),&(v67_4));
      drop(v67_4);
      let v67_7: Space = if (v67_5).is_empty() { Space::new() } else {
        let mut v68_6 = Space::new();
        let mut v68_6_cursor = (v66_3_tail).read_zipper();
        for v68_6_byte in v68_6_cursor.child_mask().iter() {
          v68_6_cursor.descend_to_byte(v68_6_byte);
          let v68_6_tail = v68_6_cursor.make_map();
          v68_6_cursor.ascend(1);
          let v68_6_head = Path::from_slice(&[v68_6_byte]);
          let v69_2: Space = singleton(&(v68_6_head));
          let v69_3: Space = intersect(&(*CONSTANT_11),&(v69_2));
          let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
          drop(v69_3);
          let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
          drop(v69_4);
          let v69_8: Space = if (v69_5).is_empty() { Space::new() } else {
            let v70_6: Path = concat_path(&(v66_3_head),&(v68_6_head));
            let v70_7: Space = routine_14(c, &(v70_6), &(v68_6_tail));
            compose(&(v69_5),&(v70_7))
          };
          drop(v69_5);
          let v69_9: Space = intersect(&(*CONSTANT_11),&(v69_2));
          drop(v69_2);
          let v69_10: Space = if has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
          drop(v69_9);
          let v69_12: Space = if (v69_10).is_empty() { Space::new() } else {
            let v71_6: Path = concat_path(&(v66_3_head),&(v68_6_head));
            let v71_11: Space = routine_15(c, &(v71_6), &(v68_6_tail));
            drop(v71_6);
            compose(&(v69_10),&(v71_11))
          };
          drop(v69_10);
          let v69_13: Space = unite(&(v69_8),&(v69_12));
          v68_6.join_into((v69_13).clone());
        }
        drop(v68_6_cursor);
        compose(&(v67_5),&(v68_6))
      };
      drop(v67_5);
      let v67_8: Space = intersect(&(*CONSTANT_11),&(v67_2));
      drop(v67_2);
      let v67_9: Space = if has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
      drop(v67_8);
      let v67_10: Space = compose(&(v67_9),&(v66_3_tail));
      drop(v67_9);
      let v67_11: Space = unite(&(v67_7),&(v67_10));
      drop(v67_10);
      v66_3.join_into((v67_11).clone());
    }
    drop(v66_3_cursor);
    drop(v66_2);
    let v66_4: Space = unite(&(v66_3),&(v59_19));
    let v66_5: Space = intersect(&(v66_4),&(*capture_3));
    let v59_19_next = unite(&v59_19,&(v66_5));
    if equal(&v59_19_next,&v59_19) { break; }
    v59_19 = v59_19_next;
  }
  let v59_20: Space = intersect(&(v59_12),&(v59_19));
  let v59_21: Space = subtract(&(v59_20),&(v59_5));
  let v59_22: Space = wrap(&(v59_21),&(*capture_0));
  let mut v59_29: Space = (v59_5).clone();
  loop {
    let v72_1: Space = intersect(&(v59_29),&(*capture_3));
    let v72_2: Space = restrict_to(&(*capture_2),&(v72_1));
    drop(v72_1);
    let mut v72_3 = Space::new();
    let mut v72_3_cursor = (v72_2).read_zipper();
    for v72_3_byte in v72_3_cursor.child_mask().iter() {
      v72_3_cursor.descend_to_byte(v72_3_byte);
      let v72_3_tail = v72_3_cursor.make_map();
      v72_3_cursor.ascend(1);
      let v72_3_head = Path::from_slice(&[v72_3_byte]);
      let v73_2: Space = singleton(&(v72_3_head));
      let v73_3: Space = intersect(&(*CONSTANT_11),&(v73_2));
      let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
      drop(v73_3);
      let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
      drop(v73_4);
      let v73_7: Space = if (v73_5).is_empty() { Space::new() } else {
        let mut v74_6 = Space::new();
        let mut v74_6_cursor = (v72_3_tail).read_zipper();
        for v74_6_byte in v74_6_cursor.child_mask().iter() {
          v74_6_cursor.descend_to_byte(v74_6_byte);
          let v74_6_tail = v74_6_cursor.make_map();
          v74_6_cursor.ascend(1);
          let v74_6_head = Path::from_slice(&[v74_6_byte]);
          let v75_2: Space = singleton(&(v74_6_head));
          let v75_3: Space = intersect(&(*CONSTANT_11),&(v75_2));
          let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
          drop(v75_3);
          let v75_5: Space = subtract(&(*CONSTANT_0),&(v75_4));
          drop(v75_4);
          let v75_8: Space = if (v75_5).is_empty() { Space::new() } else {
            let v76_6: Path = concat_path(&(v72_3_head),&(v74_6_head));
            let v76_7: Space = routine_14(c, &(v76_6), &(v74_6_tail));
            compose(&(v75_5),&(v76_7))
          };
          drop(v75_5);
          let v75_9: Space = intersect(&(*CONSTANT_11),&(v75_2));
          drop(v75_2);
          let v75_10: Space = if has_head(&(v75_9)) { singleton(&[]) } else { Space::new() };
          drop(v75_9);
          let v75_12: Space = if (v75_10).is_empty() { Space::new() } else {
            let v77_6: Path = concat_path(&(v72_3_head),&(v74_6_head));
            let v77_11: Space = routine_15(c, &(v77_6), &(v74_6_tail));
            drop(v77_6);
            compose(&(v75_10),&(v77_11))
          };
          drop(v75_10);
          let v75_13: Space = unite(&(v75_8),&(v75_12));
          v74_6.join_into((v75_13).clone());
        }
        drop(v74_6_cursor);
        compose(&(v73_5),&(v74_6))
      };
      drop(v73_5);
      let v73_8: Space = intersect(&(*CONSTANT_11),&(v73_2));
      drop(v73_2);
      let v73_9: Space = if has_head(&(v73_8)) { singleton(&[]) } else { Space::new() };
      drop(v73_8);
      let v73_10: Space = compose(&(v73_9),&(v72_3_tail));
      drop(v73_9);
      let v73_11: Space = unite(&(v73_7),&(v73_10));
      drop(v73_10);
      v72_3.join_into((v73_11).clone());
    }
    drop(v72_3_cursor);
    drop(v72_2);
    let v72_4: Space = unite(&(v72_3),&(v59_29));
    let v72_5: Space = intersect(&(v72_4),&(*capture_3));
    let v59_29_next = unite(&v59_29,&(v72_5));
    if equal(&v59_29_next,&v59_29) { break; }
    v59_29 = v59_29_next;
  }
  let v59_30: Space = subtract(&(*capture_3),&(v59_29));
  let mut v59_37: Space = (v59_5).clone();
  loop {
    let v78_1: Space = intersect(&(v59_37),&(*capture_3));
    let v78_2: Space = restrict_to(&(*capture_1),&(v78_1));
    drop(v78_1);
    let mut v78_3 = Space::new();
    let mut v78_3_cursor = (v78_2).read_zipper();
    for v78_3_byte in v78_3_cursor.child_mask().iter() {
      v78_3_cursor.descend_to_byte(v78_3_byte);
      let v78_3_tail = v78_3_cursor.make_map();
      v78_3_cursor.ascend(1);
      let v78_3_head = Path::from_slice(&[v78_3_byte]);
      let v79_2: Space = singleton(&(v78_3_head));
      let v79_3: Space = intersect(&(*CONSTANT_11),&(v79_2));
      let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
      drop(v79_3);
      let v79_5: Space = subtract(&(*CONSTANT_0),&(v79_4));
      drop(v79_4);
      let v79_7: Space = if (v79_5).is_empty() { Space::new() } else {
        let mut v80_6 = Space::new();
        let mut v80_6_cursor = (v78_3_tail).read_zipper();
        for v80_6_byte in v80_6_cursor.child_mask().iter() {
          v80_6_cursor.descend_to_byte(v80_6_byte);
          let v80_6_tail = v80_6_cursor.make_map();
          v80_6_cursor.ascend(1);
          let v80_6_head = Path::from_slice(&[v80_6_byte]);
          let v81_2: Space = singleton(&(v80_6_head));
          let v81_3: Space = intersect(&(*CONSTANT_11),&(v81_2));
          let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
          drop(v81_3);
          let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
          drop(v81_4);
          let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
            let v82_6: Path = concat_path(&(v78_3_head),&(v80_6_head));
            let v82_7: Space = routine_14(c, &(v82_6), &(v80_6_tail));
            compose(&(v81_5),&(v82_7))
          };
          drop(v81_5);
          let v81_9: Space = intersect(&(*CONSTANT_11),&(v81_2));
          drop(v81_2);
          let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
          drop(v81_9);
          let v81_12: Space = if (v81_10).is_empty() { Space::new() } else {
            let v83_6: Path = concat_path(&(v78_3_head),&(v80_6_head));
            let v83_11: Space = routine_15(c, &(v83_6), &(v80_6_tail));
            drop(v83_6);
            compose(&(v81_10),&(v83_11))
          };
          drop(v81_10);
          let v81_13: Space = unite(&(v81_8),&(v81_12));
          v80_6.join_into((v81_13).clone());
        }
        drop(v80_6_cursor);
        compose(&(v79_5),&(v80_6))
      };
      drop(v79_5);
      let v79_8: Space = intersect(&(*CONSTANT_11),&(v79_2));
      drop(v79_2);
      let v79_9: Space = if has_head(&(v79_8)) { singleton(&[]) } else { Space::new() };
      drop(v79_8);
      let v79_10: Space = compose(&(v79_9),&(v78_3_tail));
      drop(v79_9);
      let v79_11: Space = unite(&(v79_7),&(v79_10));
      drop(v79_10);
      v78_3.join_into((v79_11).clone());
    }
    drop(v78_3_cursor);
    drop(v78_2);
    let v78_4: Space = unite(&(v78_3),&(v59_37));
    let v78_5: Space = intersect(&(v78_4),&(*capture_3));
    let v59_37_next = unite(&v59_37,&(v78_5));
    if equal(&v59_37_next,&v59_37) { break; }
    v59_37 = v59_37_next;
  }
  let v59_38: Space = subtract(&(v59_30),&(v59_37));
  let v59_39: Space = range(&(v59_38),0,1);
  let mut v59_67 = Space::new();
  let mut v59_67_cursor = (v59_39).read_zipper();
  for v59_67_byte in v59_67_cursor.child_mask().iter() {
    v59_67_cursor.descend_to_byte(v59_67_byte);
    let v59_67_tail = v59_67_cursor.make_map();
    v59_67_cursor.ascend(1);
    let v59_67_head = Path::from_slice(&[v59_67_byte]);
    let v84_2: Space = singleton(&(v59_67_head));
    let v84_3: Space = intersect(&(*CONSTANT_11),&(v84_2));
    let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
    drop(v84_3);
    let v84_5: Space = subtract(&(*CONSTANT_0),&(v84_4));
    drop(v84_4);
    let v84_11: Space = if (v84_5).is_empty() { Space::new() } else {
      let mut v85_6: Space = (v59_5).clone();
      loop {
        let v86_1: Space = intersect(&(v85_6),&(*capture_3));
        let v86_2: Space = restrict_to(&(*capture_2),&(v86_1));
        drop(v86_1);
        let mut v86_3 = Space::new();
        let mut v86_3_cursor = (v86_2).read_zipper();
        for v86_3_byte in v86_3_cursor.child_mask().iter() {
          v86_3_cursor.descend_to_byte(v86_3_byte);
          let v86_3_tail = v86_3_cursor.make_map();
          v86_3_cursor.ascend(1);
          let v86_3_head = Path::from_slice(&[v86_3_byte]);
          let v87_2: Space = singleton(&(v86_3_head));
          let v87_3: Space = intersect(&(*CONSTANT_11),&(v87_2));
          let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
          drop(v87_3);
          let v87_5: Space = subtract(&(*CONSTANT_0),&(v87_4));
          drop(v87_4);
          let v87_7: Space = if (v87_5).is_empty() { Space::new() } else {
            let mut v88_6 = Space::new();
            let mut v88_6_cursor = (v86_3_tail).read_zipper();
            for v88_6_byte in v88_6_cursor.child_mask().iter() {
              v88_6_cursor.descend_to_byte(v88_6_byte);
              let v88_6_tail = v88_6_cursor.make_map();
              v88_6_cursor.ascend(1);
              let v88_6_head = Path::from_slice(&[v88_6_byte]);
              let v89_2: Space = singleton(&(v88_6_head));
              let v89_3: Space = intersect(&(*CONSTANT_11),&(v89_2));
              let v89_4: Space = if has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
              drop(v89_3);
              let v89_5: Space = subtract(&(*CONSTANT_0),&(v89_4));
              drop(v89_4);
              let v89_8: Space = if (v89_5).is_empty() { Space::new() } else {
                let v90_6: Path = concat_path(&(v86_3_head),&(v88_6_head));
                let v90_7: Space = routine_14(c, &(v90_6), &(v88_6_tail));
                compose(&(v89_5),&(v90_7))
              };
              drop(v89_5);
              let v89_9: Space = intersect(&(*CONSTANT_11),&(v89_2));
              drop(v89_2);
              let v89_10: Space = if has_head(&(v89_9)) { singleton(&[]) } else { Space::new() };
              drop(v89_9);
              let v89_12: Space = if (v89_10).is_empty() { Space::new() } else {
                let v91_6: Path = concat_path(&(v86_3_head),&(v88_6_head));
                let v91_11: Space = routine_15(c, &(v91_6), &(v88_6_tail));
                drop(v91_6);
                compose(&(v89_10),&(v91_11))
              };
              drop(v89_10);
              let v89_13: Space = unite(&(v89_8),&(v89_12));
              v88_6.join_into((v89_13).clone());
            }
            drop(v88_6_cursor);
            compose(&(v87_5),&(v88_6))
          };
          drop(v87_5);
          let v87_8: Space = intersect(&(*CONSTANT_11),&(v87_2));
          drop(v87_2);
          let v87_9: Space = if has_head(&(v87_8)) { singleton(&[]) } else { Space::new() };
          drop(v87_8);
          let v87_10: Space = compose(&(v87_9),&(v86_3_tail));
          drop(v87_9);
          let v87_11: Space = unite(&(v87_7),&(v87_10));
          drop(v87_10);
          v86_3.join_into((v87_11).clone());
        }
        drop(v86_3_cursor);
        drop(v86_2);
        let v86_4: Space = unite(&(v86_3),&(v85_6));
        let v86_5: Space = intersect(&(v86_4),&(*capture_3));
        let v85_6_next = unite(&v85_6,&(v86_5));
        if equal(&v85_6_next,&v85_6) { break; }
        v85_6 = v85_6_next;
      }
      let v85_7: Space = subtract(&(*capture_3),&(v85_6));
      let mut v85_8: Space = (v59_5).clone();
      loop {
        let v92_1: Space = intersect(&(v85_8),&(*capture_3));
        let v92_2: Space = restrict_to(&(*capture_1),&(v92_1));
        drop(v92_1);
        let mut v92_3 = Space::new();
        let mut v92_3_cursor = (v92_2).read_zipper();
        for v92_3_byte in v92_3_cursor.child_mask().iter() {
          v92_3_cursor.descend_to_byte(v92_3_byte);
          let v92_3_tail = v92_3_cursor.make_map();
          v92_3_cursor.ascend(1);
          let v92_3_head = Path::from_slice(&[v92_3_byte]);
          let v93_2: Space = singleton(&(v92_3_head));
          let v93_3: Space = intersect(&(*CONSTANT_11),&(v93_2));
          let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
          drop(v93_3);
          let v93_5: Space = subtract(&(*CONSTANT_0),&(v93_4));
          drop(v93_4);
          let v93_7: Space = if (v93_5).is_empty() { Space::new() } else {
            let mut v94_6 = Space::new();
            let mut v94_6_cursor = (v92_3_tail).read_zipper();
            for v94_6_byte in v94_6_cursor.child_mask().iter() {
              v94_6_cursor.descend_to_byte(v94_6_byte);
              let v94_6_tail = v94_6_cursor.make_map();
              v94_6_cursor.ascend(1);
              let v94_6_head = Path::from_slice(&[v94_6_byte]);
              let v95_2: Space = singleton(&(v94_6_head));
              let v95_3: Space = intersect(&(*CONSTANT_11),&(v95_2));
              let v95_4: Space = if has_head(&(v95_3)) { singleton(&[]) } else { Space::new() };
              drop(v95_3);
              let v95_5: Space = subtract(&(*CONSTANT_0),&(v95_4));
              drop(v95_4);
              let v95_8: Space = if (v95_5).is_empty() { Space::new() } else {
                let v96_6: Path = concat_path(&(v92_3_head),&(v94_6_head));
                let v96_7: Space = routine_14(c, &(v96_6), &(v94_6_tail));
                compose(&(v95_5),&(v96_7))
              };
              drop(v95_5);
              let v95_9: Space = intersect(&(*CONSTANT_11),&(v95_2));
              drop(v95_2);
              let v95_10: Space = if has_head(&(v95_9)) { singleton(&[]) } else { Space::new() };
              drop(v95_9);
              let v95_12: Space = if (v95_10).is_empty() { Space::new() } else {
                let v97_6: Path = concat_path(&(v92_3_head),&(v94_6_head));
                let v97_11: Space = routine_15(c, &(v97_6), &(v94_6_tail));
                drop(v97_6);
                compose(&(v95_10),&(v97_11))
              };
              drop(v95_10);
              let v95_13: Space = unite(&(v95_8),&(v95_12));
              v94_6.join_into((v95_13).clone());
            }
            drop(v94_6_cursor);
            compose(&(v93_5),&(v94_6))
          };
          drop(v93_5);
          let v93_8: Space = intersect(&(*CONSTANT_11),&(v93_2));
          drop(v93_2);
          let v93_9: Space = if has_head(&(v93_8)) { singleton(&[]) } else { Space::new() };
          drop(v93_8);
          let v93_10: Space = compose(&(v93_9),&(v92_3_tail));
          drop(v93_9);
          let v93_11: Space = unite(&(v93_7),&(v93_10));
          drop(v93_10);
          v92_3.join_into((v93_11).clone());
        }
        drop(v92_3_cursor);
        drop(v92_2);
        let v92_4: Space = unite(&(v92_3),&(v85_8));
        let v92_5: Space = intersect(&(v92_4),&(*capture_3));
        let v85_8_next = unite(&v85_8,&(v92_5));
        if equal(&v85_8_next,&v85_8) { break; }
        v85_8 = v85_8_next;
      }
      let v85_9: Space = subtract(&(v85_7),&(v85_8));
      let v85_10: Space = routine_6(c, &(v59_67_head), &(v59_67_tail), &(*capture_1), &(*capture_2), &(v85_9));
      compose(&(v84_5),&(v85_10))
    };
    drop(v84_5);
    let v84_12: Space = intersect(&(*CONSTANT_11),&(v84_2));
    drop(v84_2);
    let v84_13: Space = if has_head(&(v84_12)) { singleton(&[]) } else { Space::new() };
    drop(v84_12);
    let v84_19: Space = if (v84_13).is_empty() { Space::new() } else {
      let mut v98_14: Space = (v59_5).clone();
      loop {
        let v99_1: Space = intersect(&(v98_14),&(*capture_3));
        let v99_2: Space = restrict_to(&(*capture_2),&(v99_1));
        drop(v99_1);
        let mut v99_3 = Space::new();
        let mut v99_3_cursor = (v99_2).read_zipper();
        for v99_3_byte in v99_3_cursor.child_mask().iter() {
          v99_3_cursor.descend_to_byte(v99_3_byte);
          let v99_3_tail = v99_3_cursor.make_map();
          v99_3_cursor.ascend(1);
          let v99_3_head = Path::from_slice(&[v99_3_byte]);
          let v100_2: Space = singleton(&(v99_3_head));
          let v100_3: Space = intersect(&(*CONSTANT_11),&(v100_2));
          let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
          drop(v100_3);
          let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
          drop(v100_4);
          let v100_7: Space = if (v100_5).is_empty() { Space::new() } else {
            let mut v101_6 = Space::new();
            let mut v101_6_cursor = (v99_3_tail).read_zipper();
            for v101_6_byte in v101_6_cursor.child_mask().iter() {
              v101_6_cursor.descend_to_byte(v101_6_byte);
              let v101_6_tail = v101_6_cursor.make_map();
              v101_6_cursor.ascend(1);
              let v101_6_head = Path::from_slice(&[v101_6_byte]);
              let v102_2: Space = singleton(&(v101_6_head));
              let v102_3: Space = intersect(&(*CONSTANT_11),&(v102_2));
              let v102_4: Space = if has_head(&(v102_3)) { singleton(&[]) } else { Space::new() };
              drop(v102_3);
              let v102_5: Space = subtract(&(*CONSTANT_0),&(v102_4));
              drop(v102_4);
              let v102_8: Space = if (v102_5).is_empty() { Space::new() } else {
                let v103_6: Path = concat_path(&(v99_3_head),&(v101_6_head));
                let v103_7: Space = routine_14(c, &(v103_6), &(v101_6_tail));
                compose(&(v102_5),&(v103_7))
              };
              drop(v102_5);
              let v102_9: Space = intersect(&(*CONSTANT_11),&(v102_2));
              drop(v102_2);
              let v102_10: Space = if has_head(&(v102_9)) { singleton(&[]) } else { Space::new() };
              drop(v102_9);
              let v102_12: Space = if (v102_10).is_empty() { Space::new() } else {
                let v104_6: Path = concat_path(&(v99_3_head),&(v101_6_head));
                let v104_11: Space = routine_15(c, &(v104_6), &(v101_6_tail));
                drop(v104_6);
                compose(&(v102_10),&(v104_11))
              };
              drop(v102_10);
              let v102_13: Space = unite(&(v102_8),&(v102_12));
              v101_6.join_into((v102_13).clone());
            }
            drop(v101_6_cursor);
            compose(&(v100_5),&(v101_6))
          };
          drop(v100_5);
          let v100_8: Space = intersect(&(*CONSTANT_11),&(v100_2));
          drop(v100_2);
          let v100_9: Space = if has_head(&(v100_8)) { singleton(&[]) } else { Space::new() };
          drop(v100_8);
          let v100_10: Space = compose(&(v100_9),&(v99_3_tail));
          drop(v100_9);
          let v100_11: Space = unite(&(v100_7),&(v100_10));
          drop(v100_10);
          v99_3.join_into((v100_11).clone());
        }
        drop(v99_3_cursor);
        drop(v99_2);
        let v99_4: Space = unite(&(v99_3),&(v98_14));
        let v99_5: Space = intersect(&(v99_4),&(*capture_3));
        let v98_14_next = unite(&v98_14,&(v99_5));
        if equal(&v98_14_next,&v98_14) { break; }
        v98_14 = v98_14_next;
      }
      let v98_15: Space = subtract(&(*capture_3),&(v98_14));
      let mut v98_16: Space = (v59_5).clone();
      loop {
        let v105_1: Space = intersect(&(v98_16),&(*capture_3));
        let v105_2: Space = restrict_to(&(*capture_1),&(v105_1));
        drop(v105_1);
        let mut v105_3 = Space::new();
        let mut v105_3_cursor = (v105_2).read_zipper();
        for v105_3_byte in v105_3_cursor.child_mask().iter() {
          v105_3_cursor.descend_to_byte(v105_3_byte);
          let v105_3_tail = v105_3_cursor.make_map();
          v105_3_cursor.ascend(1);
          let v105_3_head = Path::from_slice(&[v105_3_byte]);
          let v106_2: Space = singleton(&(v105_3_head));
          let v106_3: Space = intersect(&(*CONSTANT_11),&(v106_2));
          let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
          drop(v106_3);
          let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
          drop(v106_4);
          let v106_7: Space = if (v106_5).is_empty() { Space::new() } else {
            let mut v107_6 = Space::new();
            let mut v107_6_cursor = (v105_3_tail).read_zipper();
            for v107_6_byte in v107_6_cursor.child_mask().iter() {
              v107_6_cursor.descend_to_byte(v107_6_byte);
              let v107_6_tail = v107_6_cursor.make_map();
              v107_6_cursor.ascend(1);
              let v107_6_head = Path::from_slice(&[v107_6_byte]);
              let v108_2: Space = singleton(&(v107_6_head));
              let v108_3: Space = intersect(&(*CONSTANT_11),&(v108_2));
              let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
              drop(v108_3);
              let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
              drop(v108_4);
              let v108_8: Space = if (v108_5).is_empty() { Space::new() } else {
                let v109_6: Path = concat_path(&(v105_3_head),&(v107_6_head));
                let v109_7: Space = routine_14(c, &(v109_6), &(v107_6_tail));
                compose(&(v108_5),&(v109_7))
              };
              drop(v108_5);
              let v108_9: Space = intersect(&(*CONSTANT_11),&(v108_2));
              drop(v108_2);
              let v108_10: Space = if has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
              drop(v108_9);
              let v108_12: Space = if (v108_10).is_empty() { Space::new() } else {
                let v110_6: Path = concat_path(&(v105_3_head),&(v107_6_head));
                let v110_11: Space = routine_15(c, &(v110_6), &(v107_6_tail));
                drop(v110_6);
                compose(&(v108_10),&(v110_11))
              };
              drop(v108_10);
              let v108_13: Space = unite(&(v108_8),&(v108_12));
              v107_6.join_into((v108_13).clone());
            }
            drop(v107_6_cursor);
            compose(&(v106_5),&(v107_6))
          };
          drop(v106_5);
          let v106_8: Space = intersect(&(*CONSTANT_11),&(v106_2));
          drop(v106_2);
          let v106_9: Space = if has_head(&(v106_8)) { singleton(&[]) } else { Space::new() };
          drop(v106_8);
          let v106_10: Space = compose(&(v106_9),&(v105_3_tail));
          drop(v106_9);
          let v106_11: Space = unite(&(v106_7),&(v106_10));
          drop(v106_10);
          v105_3.join_into((v106_11).clone());
        }
        drop(v105_3_cursor);
        drop(v105_2);
        let v105_4: Space = unite(&(v105_3),&(v98_16));
        let v105_5: Space = intersect(&(v105_4),&(*capture_3));
        let v98_16_next = unite(&v98_16,&(v105_5));
        if equal(&v98_16_next,&v98_16) { break; }
        v98_16 = v98_16_next;
      }
      let v98_17: Space = subtract(&(v98_15),&(v98_16));
      let v98_18: Space = routine_7(c, &(v59_67_head), &(v59_67_tail), &(*capture_1), &(*capture_2), &(v98_17));
      compose(&(v84_13),&(v98_18))
    };
    drop(v84_13);
    let v84_20: Space = unite(&(v84_11),&(v84_19));
    v59_67.join_into((v84_20).clone());
  }
  drop(v59_67_cursor);
  let v59_68: Space = unite(&(v59_22),&(v59_67));
  let mut v59_75: Space = (v59_5).clone();
  loop {
    let v111_1: Space = intersect(&(v59_75),&(*capture_3));
    let v111_2: Space = restrict_to(&(*capture_2),&(v111_1));
    drop(v111_1);
    let mut v111_3 = Space::new();
    let mut v111_3_cursor = (v111_2).read_zipper();
    for v111_3_byte in v111_3_cursor.child_mask().iter() {
      v111_3_cursor.descend_to_byte(v111_3_byte);
      let v111_3_tail = v111_3_cursor.make_map();
      v111_3_cursor.ascend(1);
      let v111_3_head = Path::from_slice(&[v111_3_byte]);
      let v112_2: Space = singleton(&(v111_3_head));
      let v112_3: Space = intersect(&(*CONSTANT_11),&(v112_2));
      let v112_4: Space = if has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
      drop(v112_3);
      let v112_5: Space = subtract(&(*CONSTANT_0),&(v112_4));
      drop(v112_4);
      let v112_7: Space = if (v112_5).is_empty() { Space::new() } else {
        let mut v113_6 = Space::new();
        let mut v113_6_cursor = (v111_3_tail).read_zipper();
        for v113_6_byte in v113_6_cursor.child_mask().iter() {
          v113_6_cursor.descend_to_byte(v113_6_byte);
          let v113_6_tail = v113_6_cursor.make_map();
          v113_6_cursor.ascend(1);
          let v113_6_head = Path::from_slice(&[v113_6_byte]);
          let v114_2: Space = singleton(&(v113_6_head));
          let v114_3: Space = intersect(&(*CONSTANT_11),&(v114_2));
          let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
          drop(v114_3);
          let v114_5: Space = subtract(&(*CONSTANT_0),&(v114_4));
          drop(v114_4);
          let v114_8: Space = if (v114_5).is_empty() { Space::new() } else {
            let v115_6: Path = concat_path(&(v111_3_head),&(v113_6_head));
            let v115_7: Space = routine_14(c, &(v115_6), &(v113_6_tail));
            compose(&(v114_5),&(v115_7))
          };
          drop(v114_5);
          let v114_9: Space = intersect(&(*CONSTANT_11),&(v114_2));
          drop(v114_2);
          let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
          drop(v114_9);
          let v114_12: Space = if (v114_10).is_empty() { Space::new() } else {
            let v116_6: Path = concat_path(&(v111_3_head),&(v113_6_head));
            let v116_11: Space = routine_15(c, &(v116_6), &(v113_6_tail));
            drop(v116_6);
            compose(&(v114_10),&(v116_11))
          };
          drop(v114_10);
          let v114_13: Space = unite(&(v114_8),&(v114_12));
          v113_6.join_into((v114_13).clone());
        }
        drop(v113_6_cursor);
        compose(&(v112_5),&(v113_6))
      };
      drop(v112_5);
      let v112_8: Space = intersect(&(*CONSTANT_11),&(v112_2));
      drop(v112_2);
      let v112_9: Space = if has_head(&(v112_8)) { singleton(&[]) } else { Space::new() };
      drop(v112_8);
      let v112_10: Space = compose(&(v112_9),&(v111_3_tail));
      drop(v112_9);
      let v112_11: Space = unite(&(v112_7),&(v112_10));
      drop(v112_10);
      v111_3.join_into((v112_11).clone());
    }
    drop(v111_3_cursor);
    drop(v111_2);
    let v111_4: Space = unite(&(v111_3),&(v59_75));
    let v111_5: Space = intersect(&(v111_4),&(*capture_3));
    let v59_75_next = unite(&v59_75,&(v111_5));
    if equal(&v59_75_next,&v59_75) { break; }
    v59_75 = v59_75_next;
  }

((v59_12).clone(),(v59_19).clone(),(v59_20).clone(),(v59_21).clone(),(v59_22).clone(),(v59_29).clone(),(v59_30).clone(),(v59_37).clone(),(v59_38).clone(),(v59_39).clone(),(v59_5).clone(),(v59_67).clone(),(v59_68).clone(),(v59_75).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &Space,capture_1: &Space,capture_2: &Space,capture_3: &Space,capture_4: &Space,capture_5: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let mut v59_82: Space = ((*capture_3)).clone();
  loop {
    let v117_1: Space = intersect(&(v59_82),&(*capture_2));
    let v117_2: Space = restrict_to(&(*capture_0),&(v117_1));
    drop(v117_1);
    let mut v117_3 = Space::new();
    let mut v117_3_cursor = (v117_2).read_zipper();
    for v117_3_byte in v117_3_cursor.child_mask().iter() {
      v117_3_cursor.descend_to_byte(v117_3_byte);
      let v117_3_tail = v117_3_cursor.make_map();
      v117_3_cursor.ascend(1);
      let v117_3_head = Path::from_slice(&[v117_3_byte]);
      let v118_2: Space = singleton(&(v117_3_head));
      let v118_3: Space = intersect(&(*CONSTANT_11),&(v118_2));
      let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
      drop(v118_3);
      let v118_5: Space = subtract(&(*CONSTANT_0),&(v118_4));
      drop(v118_4);
      let v118_7: Space = if (v118_5).is_empty() { Space::new() } else {
        let mut v119_6 = Space::new();
        let mut v119_6_cursor = (v117_3_tail).read_zipper();
        for v119_6_byte in v119_6_cursor.child_mask().iter() {
          v119_6_cursor.descend_to_byte(v119_6_byte);
          let v119_6_tail = v119_6_cursor.make_map();
          v119_6_cursor.ascend(1);
          let v119_6_head = Path::from_slice(&[v119_6_byte]);
          let v120_2: Space = singleton(&(v119_6_head));
          let v120_3: Space = intersect(&(*CONSTANT_11),&(v120_2));
          let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
          drop(v120_3);
          let v120_5: Space = subtract(&(*CONSTANT_0),&(v120_4));
          drop(v120_4);
          let v120_8: Space = if (v120_5).is_empty() { Space::new() } else {
            let v121_6: Path = concat_path(&(v117_3_head),&(v119_6_head));
            let v121_7: Space = routine_14(c, &(v121_6), &(v119_6_tail));
            compose(&(v120_5),&(v121_7))
          };
          drop(v120_5);
          let v120_9: Space = intersect(&(*CONSTANT_11),&(v120_2));
          drop(v120_2);
          let v120_10: Space = if has_head(&(v120_9)) { singleton(&[]) } else { Space::new() };
          drop(v120_9);
          let v120_12: Space = if (v120_10).is_empty() { Space::new() } else {
            let v122_6: Path = concat_path(&(v117_3_head),&(v119_6_head));
            let v122_11: Space = routine_15(c, &(v122_6), &(v119_6_tail));
            drop(v122_6);
            compose(&(v120_10),&(v122_11))
          };
          drop(v120_10);
          let v120_13: Space = unite(&(v120_8),&(v120_12));
          v119_6.join_into((v120_13).clone());
        }
        drop(v119_6_cursor);
        compose(&(v118_5),&(v119_6))
      };
      drop(v118_5);
      let v118_8: Space = intersect(&(*CONSTANT_11),&(v118_2));
      drop(v118_2);
      let v118_9: Space = if has_head(&(v118_8)) { singleton(&[]) } else { Space::new() };
      drop(v118_8);
      let v118_10: Space = compose(&(v118_9),&(v117_3_tail));
      drop(v118_9);
      let v118_11: Space = unite(&(v118_7),&(v118_10));
      drop(v118_10);
      v117_3.join_into((v118_11).clone());
    }
    drop(v117_3_cursor);
    drop(v117_2);
    let v117_4: Space = unite(&(v117_3),&(v59_82));
    let v117_5: Space = intersect(&(v117_4),&(*capture_2));
    let v59_82_next = unite(&v59_82,&(v117_5));
    if equal(&v59_82_next,&v59_82) { break; }
    v59_82 = v59_82_next;
  }
  let v59_83: Space = subtract(&((*capture_5)),&(v59_82));
  let v59_84: Space = range(&(v59_83),0,1);
  let mut v59_112 = Space::new();
  let mut v59_112_cursor = (v59_84).read_zipper();
  for v59_112_byte in v59_112_cursor.child_mask().iter() {
    v59_112_cursor.descend_to_byte(v59_112_byte);
    let v59_112_tail = v59_112_cursor.make_map();
    v59_112_cursor.ascend(1);
    let v59_112_head = Path::from_slice(&[v59_112_byte]);
    let v123_2: Space = singleton(&(v59_112_head));
    let v123_3: Space = intersect(&(*CONSTANT_11),&(v123_2));
    let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
    drop(v123_3);
    let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
    drop(v123_4);
    let v123_10: Space = if (v123_5).is_empty() { Space::new() } else {
      let mut v124_6: Space = ((*capture_3)).clone();
      loop {
        let v125_1: Space = intersect(&(v124_6),&(*capture_2));
        let v125_2: Space = restrict_to(&(*capture_1),&(v125_1));
        drop(v125_1);
        let mut v125_3 = Space::new();
        let mut v125_3_cursor = (v125_2).read_zipper();
        for v125_3_byte in v125_3_cursor.child_mask().iter() {
          v125_3_cursor.descend_to_byte(v125_3_byte);
          let v125_3_tail = v125_3_cursor.make_map();
          v125_3_cursor.ascend(1);
          let v125_3_head = Path::from_slice(&[v125_3_byte]);
          let v126_2: Space = singleton(&(v125_3_head));
          let v126_3: Space = intersect(&(*CONSTANT_11),&(v126_2));
          let v126_4: Space = if has_head(&(v126_3)) { singleton(&[]) } else { Space::new() };
          drop(v126_3);
          let v126_5: Space = subtract(&(*CONSTANT_0),&(v126_4));
          drop(v126_4);
          let v126_7: Space = if (v126_5).is_empty() { Space::new() } else {
            let mut v127_6 = Space::new();
            let mut v127_6_cursor = (v125_3_tail).read_zipper();
            for v127_6_byte in v127_6_cursor.child_mask().iter() {
              v127_6_cursor.descend_to_byte(v127_6_byte);
              let v127_6_tail = v127_6_cursor.make_map();
              v127_6_cursor.ascend(1);
              let v127_6_head = Path::from_slice(&[v127_6_byte]);
              let v128_2: Space = singleton(&(v127_6_head));
              let v128_3: Space = intersect(&(*CONSTANT_11),&(v128_2));
              let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
              drop(v128_3);
              let v128_5: Space = subtract(&(*CONSTANT_0),&(v128_4));
              drop(v128_4);
              let v128_8: Space = if (v128_5).is_empty() { Space::new() } else {
                let v129_6: Path = concat_path(&(v125_3_head),&(v127_6_head));
                let v129_7: Space = routine_14(c, &(v129_6), &(v127_6_tail));
                compose(&(v128_5),&(v129_7))
              };
              drop(v128_5);
              let v128_9: Space = intersect(&(*CONSTANT_11),&(v128_2));
              drop(v128_2);
              let v128_10: Space = if has_head(&(v128_9)) { singleton(&[]) } else { Space::new() };
              drop(v128_9);
              let v128_12: Space = if (v128_10).is_empty() { Space::new() } else {
                let v130_6: Path = concat_path(&(v125_3_head),&(v127_6_head));
                let v130_11: Space = routine_15(c, &(v130_6), &(v127_6_tail));
                drop(v130_6);
                compose(&(v128_10),&(v130_11))
              };
              drop(v128_10);
              let v128_13: Space = unite(&(v128_8),&(v128_12));
              v127_6.join_into((v128_13).clone());
            }
            drop(v127_6_cursor);
            compose(&(v126_5),&(v127_6))
          };
          drop(v126_5);
          let v126_8: Space = intersect(&(*CONSTANT_11),&(v126_2));
          drop(v126_2);
          let v126_9: Space = if has_head(&(v126_8)) { singleton(&[]) } else { Space::new() };
          drop(v126_8);
          let v126_10: Space = compose(&(v126_9),&(v125_3_tail));
          drop(v126_9);
          let v126_11: Space = unite(&(v126_7),&(v126_10));
          drop(v126_10);
          v125_3.join_into((v126_11).clone());
        }
        drop(v125_3_cursor);
        drop(v125_2);
        let v125_4: Space = unite(&(v125_3),&(v124_6));
        let v125_5: Space = intersect(&(v125_4),&(*capture_2));
        let v124_6_next = unite(&v124_6,&(v125_5));
        if equal(&v124_6_next,&v124_6) { break; }
        v124_6 = v124_6_next;
      }
      let mut v124_7: Space = ((*capture_3)).clone();
      loop {
        let v131_1: Space = intersect(&(v124_7),&(*capture_2));
        let v131_2: Space = restrict_to(&(*capture_0),&(v131_1));
        drop(v131_1);
        let mut v131_3 = Space::new();
        let mut v131_3_cursor = (v131_2).read_zipper();
        for v131_3_byte in v131_3_cursor.child_mask().iter() {
          v131_3_cursor.descend_to_byte(v131_3_byte);
          let v131_3_tail = v131_3_cursor.make_map();
          v131_3_cursor.ascend(1);
          let v131_3_head = Path::from_slice(&[v131_3_byte]);
          let v132_2: Space = singleton(&(v131_3_head));
          let v132_3: Space = intersect(&(*CONSTANT_11),&(v132_2));
          let v132_4: Space = if has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
          drop(v132_3);
          let v132_5: Space = subtract(&(*CONSTANT_0),&(v132_4));
          drop(v132_4);
          let v132_7: Space = if (v132_5).is_empty() { Space::new() } else {
            let mut v133_6 = Space::new();
            let mut v133_6_cursor = (v131_3_tail).read_zipper();
            for v133_6_byte in v133_6_cursor.child_mask().iter() {
              v133_6_cursor.descend_to_byte(v133_6_byte);
              let v133_6_tail = v133_6_cursor.make_map();
              v133_6_cursor.ascend(1);
              let v133_6_head = Path::from_slice(&[v133_6_byte]);
              let v134_2: Space = singleton(&(v133_6_head));
              let v134_3: Space = intersect(&(*CONSTANT_11),&(v134_2));
              let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
              drop(v134_3);
              let v134_5: Space = subtract(&(*CONSTANT_0),&(v134_4));
              drop(v134_4);
              let v134_8: Space = if (v134_5).is_empty() { Space::new() } else {
                let v135_6: Path = concat_path(&(v131_3_head),&(v133_6_head));
                let v135_7: Space = routine_14(c, &(v135_6), &(v133_6_tail));
                compose(&(v134_5),&(v135_7))
              };
              drop(v134_5);
              let v134_9: Space = intersect(&(*CONSTANT_11),&(v134_2));
              drop(v134_2);
              let v134_10: Space = if has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
              drop(v134_9);
              let v134_12: Space = if (v134_10).is_empty() { Space::new() } else {
                let v136_6: Path = concat_path(&(v131_3_head),&(v133_6_head));
                let v136_11: Space = routine_15(c, &(v136_6), &(v133_6_tail));
                drop(v136_6);
                compose(&(v134_10),&(v136_11))
              };
              drop(v134_10);
              let v134_13: Space = unite(&(v134_8),&(v134_12));
              v133_6.join_into((v134_13).clone());
            }
            drop(v133_6_cursor);
            compose(&(v132_5),&(v133_6))
          };
          drop(v132_5);
          let v132_8: Space = intersect(&(*CONSTANT_11),&(v132_2));
          drop(v132_2);
          let v132_9: Space = if has_head(&(v132_8)) { singleton(&[]) } else { Space::new() };
          drop(v132_8);
          let v132_10: Space = compose(&(v132_9),&(v131_3_tail));
          drop(v132_9);
          let v132_11: Space = unite(&(v132_7),&(v132_10));
          drop(v132_10);
          v131_3.join_into((v132_11).clone());
        }
        drop(v131_3_cursor);
        drop(v131_2);
        let v131_4: Space = unite(&(v131_3),&(v124_7));
        let v131_5: Space = intersect(&(v131_4),&(*capture_2));
        let v124_7_next = unite(&v124_7,&(v131_5));
        if equal(&v124_7_next,&v124_7) { break; }
        v124_7 = v124_7_next;
      }
      let v124_8: Space = subtract(&(v124_6),&(v124_7));
      let v124_9: Space = routine_6(c, &(v59_112_head), &(v59_112_tail), &(*capture_0), &(*capture_1), &(v124_8));
      compose(&(v123_5),&(v124_9))
    };
    drop(v123_5);
    let v123_11: Space = intersect(&(*CONSTANT_11),&(v123_2));
    drop(v123_2);
    let v123_12: Space = if has_head(&(v123_11)) { singleton(&[]) } else { Space::new() };
    drop(v123_11);
    let v123_17: Space = if (v123_12).is_empty() { Space::new() } else {
      let mut v137_13: Space = ((*capture_3)).clone();
      loop {
        let v138_1: Space = intersect(&(v137_13),&(*capture_2));
        let v138_2: Space = restrict_to(&(*capture_1),&(v138_1));
        drop(v138_1);
        let mut v138_3 = Space::new();
        let mut v138_3_cursor = (v138_2).read_zipper();
        for v138_3_byte in v138_3_cursor.child_mask().iter() {
          v138_3_cursor.descend_to_byte(v138_3_byte);
          let v138_3_tail = v138_3_cursor.make_map();
          v138_3_cursor.ascend(1);
          let v138_3_head = Path::from_slice(&[v138_3_byte]);
          let v139_2: Space = singleton(&(v138_3_head));
          let v139_3: Space = intersect(&(*CONSTANT_11),&(v139_2));
          let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
          drop(v139_3);
          let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
          drop(v139_4);
          let v139_7: Space = if (v139_5).is_empty() { Space::new() } else {
            let mut v140_6 = Space::new();
            let mut v140_6_cursor = (v138_3_tail).read_zipper();
            for v140_6_byte in v140_6_cursor.child_mask().iter() {
              v140_6_cursor.descend_to_byte(v140_6_byte);
              let v140_6_tail = v140_6_cursor.make_map();
              v140_6_cursor.ascend(1);
              let v140_6_head = Path::from_slice(&[v140_6_byte]);
              let v141_2: Space = singleton(&(v140_6_head));
              let v141_3: Space = intersect(&(*CONSTANT_11),&(v141_2));
              let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
              drop(v141_3);
              let v141_5: Space = subtract(&(*CONSTANT_0),&(v141_4));
              drop(v141_4);
              let v141_8: Space = if (v141_5).is_empty() { Space::new() } else {
                let v142_6: Path = concat_path(&(v138_3_head),&(v140_6_head));
                let v142_7: Space = routine_14(c, &(v142_6), &(v140_6_tail));
                compose(&(v141_5),&(v142_7))
              };
              drop(v141_5);
              let v141_9: Space = intersect(&(*CONSTANT_11),&(v141_2));
              drop(v141_2);
              let v141_10: Space = if has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
              drop(v141_9);
              let v141_12: Space = if (v141_10).is_empty() { Space::new() } else {
                let v143_6: Path = concat_path(&(v138_3_head),&(v140_6_head));
                let v143_11: Space = routine_15(c, &(v143_6), &(v140_6_tail));
                drop(v143_6);
                compose(&(v141_10),&(v143_11))
              };
              drop(v141_10);
              let v141_13: Space = unite(&(v141_8),&(v141_12));
              v140_6.join_into((v141_13).clone());
            }
            drop(v140_6_cursor);
            compose(&(v139_5),&(v140_6))
          };
          drop(v139_5);
          let v139_8: Space = intersect(&(*CONSTANT_11),&(v139_2));
          drop(v139_2);
          let v139_9: Space = if has_head(&(v139_8)) { singleton(&[]) } else { Space::new() };
          drop(v139_8);
          let v139_10: Space = compose(&(v139_9),&(v138_3_tail));
          drop(v139_9);
          let v139_11: Space = unite(&(v139_7),&(v139_10));
          drop(v139_10);
          v138_3.join_into((v139_11).clone());
        }
        drop(v138_3_cursor);
        drop(v138_2);
        let v138_4: Space = unite(&(v138_3),&(v137_13));
        let v138_5: Space = intersect(&(v138_4),&(*capture_2));
        let v137_13_next = unite(&v137_13,&(v138_5));
        if equal(&v137_13_next,&v137_13) { break; }
        v137_13 = v137_13_next;
      }
      let mut v137_14: Space = ((*capture_3)).clone();
      loop {
        let v144_1: Space = intersect(&(v137_14),&(*capture_2));
        let v144_2: Space = restrict_to(&(*capture_0),&(v144_1));
        drop(v144_1);
        let mut v144_3 = Space::new();
        let mut v144_3_cursor = (v144_2).read_zipper();
        for v144_3_byte in v144_3_cursor.child_mask().iter() {
          v144_3_cursor.descend_to_byte(v144_3_byte);
          let v144_3_tail = v144_3_cursor.make_map();
          v144_3_cursor.ascend(1);
          let v144_3_head = Path::from_slice(&[v144_3_byte]);
          let v145_2: Space = singleton(&(v144_3_head));
          let v145_3: Space = intersect(&(*CONSTANT_11),&(v145_2));
          let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
          drop(v145_3);
          let v145_5: Space = subtract(&(*CONSTANT_0),&(v145_4));
          drop(v145_4);
          let v145_7: Space = if (v145_5).is_empty() { Space::new() } else {
            let mut v146_6 = Space::new();
            let mut v146_6_cursor = (v144_3_tail).read_zipper();
            for v146_6_byte in v146_6_cursor.child_mask().iter() {
              v146_6_cursor.descend_to_byte(v146_6_byte);
              let v146_6_tail = v146_6_cursor.make_map();
              v146_6_cursor.ascend(1);
              let v146_6_head = Path::from_slice(&[v146_6_byte]);
              let v147_2: Space = singleton(&(v146_6_head));
              let v147_3: Space = intersect(&(*CONSTANT_11),&(v147_2));
              let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
              drop(v147_3);
              let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
              drop(v147_4);
              let v147_8: Space = if (v147_5).is_empty() { Space::new() } else {
                let v148_6: Path = concat_path(&(v144_3_head),&(v146_6_head));
                let v148_7: Space = routine_14(c, &(v148_6), &(v146_6_tail));
                compose(&(v147_5),&(v148_7))
              };
              drop(v147_5);
              let v147_9: Space = intersect(&(*CONSTANT_11),&(v147_2));
              drop(v147_2);
              let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
              drop(v147_9);
              let v147_12: Space = if (v147_10).is_empty() { Space::new() } else {
                let v149_6: Path = concat_path(&(v144_3_head),&(v146_6_head));
                let v149_11: Space = routine_15(c, &(v149_6), &(v146_6_tail));
                drop(v149_6);
                compose(&(v147_10),&(v149_11))
              };
              drop(v147_10);
              let v147_13: Space = unite(&(v147_8),&(v147_12));
              v146_6.join_into((v147_13).clone());
            }
            drop(v146_6_cursor);
            compose(&(v145_5),&(v146_6))
          };
          drop(v145_5);
          let v145_8: Space = intersect(&(*CONSTANT_11),&(v145_2));
          drop(v145_2);
          let v145_9: Space = if has_head(&(v145_8)) { singleton(&[]) } else { Space::new() };
          drop(v145_8);
          let v145_10: Space = compose(&(v145_9),&(v144_3_tail));
          drop(v145_9);
          let v145_11: Space = unite(&(v145_7),&(v145_10));
          drop(v145_10);
          v144_3.join_into((v145_11).clone());
        }
        drop(v144_3_cursor);
        drop(v144_2);
        let v144_4: Space = unite(&(v144_3),&(v137_14));
        let v144_5: Space = intersect(&(v144_4),&(*capture_2));
        let v137_14_next = unite(&v137_14,&(v144_5));
        if equal(&v137_14_next,&v137_14) { break; }
        v137_14 = v137_14_next;
      }
      let v137_15: Space = subtract(&(v137_13),&(v137_14));
      let v137_16: Space = routine_7(c, &(v59_112_head), &(v59_112_tail), &(*capture_0), &(*capture_1), &(v137_15));
      compose(&(v123_12),&(v137_16))
    };
    drop(v123_12);
    let v123_18: Space = unite(&(v123_10),&(v123_17));
    v59_112.join_into((v123_18).clone());
  }
  drop(v59_112_cursor);
  let v59_113: Space = unite(&((*capture_4)),&(v59_112));
  let mut v59_120: Space = ((*capture_3)).clone();
  loop {
    let v150_1: Space = intersect(&(v59_120),&(*capture_2));
    let v150_2: Space = restrict_to(&(*capture_0),&(v150_1));
    drop(v150_1);
    let mut v150_3 = Space::new();
    let mut v150_3_cursor = (v150_2).read_zipper();
    for v150_3_byte in v150_3_cursor.child_mask().iter() {
      v150_3_cursor.descend_to_byte(v150_3_byte);
      let v150_3_tail = v150_3_cursor.make_map();
      v150_3_cursor.ascend(1);
      let v150_3_head = Path::from_slice(&[v150_3_byte]);
      let v151_2: Space = singleton(&(v150_3_head));
      let v151_3: Space = intersect(&(*CONSTANT_11),&(v151_2));
      let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
      drop(v151_3);
      let v151_5: Space = subtract(&(*CONSTANT_0),&(v151_4));
      drop(v151_4);
      let v151_7: Space = if (v151_5).is_empty() { Space::new() } else {
        let mut v152_6 = Space::new();
        let mut v152_6_cursor = (v150_3_tail).read_zipper();
        for v152_6_byte in v152_6_cursor.child_mask().iter() {
          v152_6_cursor.descend_to_byte(v152_6_byte);
          let v152_6_tail = v152_6_cursor.make_map();
          v152_6_cursor.ascend(1);
          let v152_6_head = Path::from_slice(&[v152_6_byte]);
          let v153_2: Space = singleton(&(v152_6_head));
          let v153_3: Space = intersect(&(*CONSTANT_11),&(v153_2));
          let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
          drop(v153_3);
          let v153_5: Space = subtract(&(*CONSTANT_0),&(v153_4));
          drop(v153_4);
          let v153_8: Space = if (v153_5).is_empty() { Space::new() } else {
            let v154_6: Path = concat_path(&(v150_3_head),&(v152_6_head));
            let v154_7: Space = routine_14(c, &(v154_6), &(v152_6_tail));
            compose(&(v153_5),&(v154_7))
          };
          drop(v153_5);
          let v153_9: Space = intersect(&(*CONSTANT_11),&(v153_2));
          drop(v153_2);
          let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
          drop(v153_9);
          let v153_12: Space = if (v153_10).is_empty() { Space::new() } else {
            let v155_6: Path = concat_path(&(v150_3_head),&(v152_6_head));
            let v155_11: Space = routine_15(c, &(v155_6), &(v152_6_tail));
            drop(v155_6);
            compose(&(v153_10),&(v155_11))
          };
          drop(v153_10);
          let v153_13: Space = unite(&(v153_8),&(v153_12));
          v152_6.join_into((v153_13).clone());
        }
        drop(v152_6_cursor);
        compose(&(v151_5),&(v152_6))
      };
      drop(v151_5);
      let v151_8: Space = intersect(&(*CONSTANT_11),&(v151_2));
      drop(v151_2);
      let v151_9: Space = if has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
      drop(v151_8);
      let v151_10: Space = compose(&(v151_9),&(v150_3_tail));
      drop(v151_9);
      let v151_11: Space = unite(&(v151_7),&(v151_10));
      drop(v151_10);
      v150_3.join_into((v151_11).clone());
    }
    drop(v150_3_cursor);
    drop(v150_2);
    let v150_4: Space = unite(&(v150_3),&(v59_120));
    let v150_5: Space = intersect(&(v150_4),&(*capture_2));
    let v59_120_next = unite(&v59_120,&(v150_5));
    if equal(&v59_120_next,&v59_120) { break; }
    v59_120 = v59_120_next;
  }
  let mut v59_127: Space = ((*capture_3)).clone();
  loop {
    let v156_1: Space = intersect(&(v59_127),&(*capture_2));
    let v156_2: Space = restrict_to(&(*capture_1),&(v156_1));
    drop(v156_1);
    let mut v156_3 = Space::new();
    let mut v156_3_cursor = (v156_2).read_zipper();
    for v156_3_byte in v156_3_cursor.child_mask().iter() {
      v156_3_cursor.descend_to_byte(v156_3_byte);
      let v156_3_tail = v156_3_cursor.make_map();
      v156_3_cursor.ascend(1);
      let v156_3_head = Path::from_slice(&[v156_3_byte]);
      let v157_2: Space = singleton(&(v156_3_head));
      let v157_3: Space = intersect(&(*CONSTANT_11),&(v157_2));
      let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
      drop(v157_3);
      let v157_5: Space = subtract(&(*CONSTANT_0),&(v157_4));
      drop(v157_4);
      let v157_7: Space = if (v157_5).is_empty() { Space::new() } else {
        let mut v158_6 = Space::new();
        let mut v158_6_cursor = (v156_3_tail).read_zipper();
        for v158_6_byte in v158_6_cursor.child_mask().iter() {
          v158_6_cursor.descend_to_byte(v158_6_byte);
          let v158_6_tail = v158_6_cursor.make_map();
          v158_6_cursor.ascend(1);
          let v158_6_head = Path::from_slice(&[v158_6_byte]);
          let v159_2: Space = singleton(&(v158_6_head));
          let v159_3: Space = intersect(&(*CONSTANT_11),&(v159_2));
          let v159_4: Space = if has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
          drop(v159_3);
          let v159_5: Space = subtract(&(*CONSTANT_0),&(v159_4));
          drop(v159_4);
          let v159_8: Space = if (v159_5).is_empty() { Space::new() } else {
            let v160_6: Path = concat_path(&(v156_3_head),&(v158_6_head));
            let v160_7: Space = routine_14(c, &(v160_6), &(v158_6_tail));
            compose(&(v159_5),&(v160_7))
          };
          drop(v159_5);
          let v159_9: Space = intersect(&(*CONSTANT_11),&(v159_2));
          drop(v159_2);
          let v159_10: Space = if has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
          drop(v159_9);
          let v159_12: Space = if (v159_10).is_empty() { Space::new() } else {
            let v161_6: Path = concat_path(&(v156_3_head),&(v158_6_head));
            let v161_11: Space = routine_15(c, &(v161_6), &(v158_6_tail));
            drop(v161_6);
            compose(&(v159_10),&(v161_11))
          };
          drop(v159_10);
          let v159_13: Space = unite(&(v159_8),&(v159_12));
          v158_6.join_into((v159_13).clone());
        }
        drop(v158_6_cursor);
        compose(&(v157_5),&(v158_6))
      };
      drop(v157_5);
      let v157_8: Space = intersect(&(*CONSTANT_11),&(v157_2));
      drop(v157_2);
      let v157_9: Space = if has_head(&(v157_8)) { singleton(&[]) } else { Space::new() };
      drop(v157_8);
      let v157_10: Space = compose(&(v157_9),&(v156_3_tail));
      drop(v157_9);
      let v157_11: Space = unite(&(v157_7),&(v157_10));
      drop(v157_10);
      v156_3.join_into((v157_11).clone());
    }
    drop(v156_3_cursor);
    drop(v156_2);
    let v156_4: Space = unite(&(v156_3),&(v59_127));
    let v156_5: Space = intersect(&(v156_4),&(*capture_2));
    let v59_127_next = unite(&v59_127,&(v156_5));
    if equal(&v59_127_next,&v59_127) { break; }
    v59_127 = v59_127_next;
  }
  let v59_128: Space = subtract(&(v59_120),&(v59_127));
  let v59_129: Space = range(&(v59_128),0,1);
  let mut v59_157 = Space::new();
  let mut v59_157_cursor = (v59_129).read_zipper();
  for v59_157_byte in v59_157_cursor.child_mask().iter() {
    v59_157_cursor.descend_to_byte(v59_157_byte);
    let v59_157_tail = v59_157_cursor.make_map();
    v59_157_cursor.ascend(1);
    let v59_157_head = Path::from_slice(&[v59_157_byte]);
    let v162_2: Space = singleton(&(v59_157_head));
    let v162_3: Space = intersect(&(*CONSTANT_11),&(v162_2));
    let v162_4: Space = if has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
    drop(v162_3);
    let v162_5: Space = subtract(&(*CONSTANT_0),&(v162_4));
    drop(v162_4);
    let v162_10: Space = if (v162_5).is_empty() { Space::new() } else {
      let mut v163_6: Space = ((*capture_3)).clone();
      loop {
        let v164_1: Space = intersect(&(v163_6),&(*capture_2));
        let v164_2: Space = restrict_to(&(*capture_0),&(v164_1));
        drop(v164_1);
        let mut v164_3 = Space::new();
        let mut v164_3_cursor = (v164_2).read_zipper();
        for v164_3_byte in v164_3_cursor.child_mask().iter() {
          v164_3_cursor.descend_to_byte(v164_3_byte);
          let v164_3_tail = v164_3_cursor.make_map();
          v164_3_cursor.ascend(1);
          let v164_3_head = Path::from_slice(&[v164_3_byte]);
          let v165_2: Space = singleton(&(v164_3_head));
          let v165_3: Space = intersect(&(*CONSTANT_11),&(v165_2));
          let v165_4: Space = if has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
          drop(v165_3);
          let v165_5: Space = subtract(&(*CONSTANT_0),&(v165_4));
          drop(v165_4);
          let v165_7: Space = if (v165_5).is_empty() { Space::new() } else {
            let mut v166_6 = Space::new();
            let mut v166_6_cursor = (v164_3_tail).read_zipper();
            for v166_6_byte in v166_6_cursor.child_mask().iter() {
              v166_6_cursor.descend_to_byte(v166_6_byte);
              let v166_6_tail = v166_6_cursor.make_map();
              v166_6_cursor.ascend(1);
              let v166_6_head = Path::from_slice(&[v166_6_byte]);
              let v167_2: Space = singleton(&(v166_6_head));
              let v167_3: Space = intersect(&(*CONSTANT_11),&(v167_2));
              let v167_4: Space = if has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
              drop(v167_3);
              let v167_5: Space = subtract(&(*CONSTANT_0),&(v167_4));
              drop(v167_4);
              let v167_8: Space = if (v167_5).is_empty() { Space::new() } else {
                let v168_6: Path = concat_path(&(v164_3_head),&(v166_6_head));
                let v168_7: Space = routine_14(c, &(v168_6), &(v166_6_tail));
                compose(&(v167_5),&(v168_7))
              };
              drop(v167_5);
              let v167_9: Space = intersect(&(*CONSTANT_11),&(v167_2));
              drop(v167_2);
              let v167_10: Space = if has_head(&(v167_9)) { singleton(&[]) } else { Space::new() };
              drop(v167_9);
              let v167_12: Space = if (v167_10).is_empty() { Space::new() } else {
                let v169_6: Path = concat_path(&(v164_3_head),&(v166_6_head));
                let v169_11: Space = routine_15(c, &(v169_6), &(v166_6_tail));
                drop(v169_6);
                compose(&(v167_10),&(v169_11))
              };
              drop(v167_10);
              let v167_13: Space = unite(&(v167_8),&(v167_12));
              v166_6.join_into((v167_13).clone());
            }
            drop(v166_6_cursor);
            compose(&(v165_5),&(v166_6))
          };
          drop(v165_5);
          let v165_8: Space = intersect(&(*CONSTANT_11),&(v165_2));
          drop(v165_2);
          let v165_9: Space = if has_head(&(v165_8)) { singleton(&[]) } else { Space::new() };
          drop(v165_8);
          let v165_10: Space = compose(&(v165_9),&(v164_3_tail));
          drop(v165_9);
          let v165_11: Space = unite(&(v165_7),&(v165_10));
          drop(v165_10);
          v164_3.join_into((v165_11).clone());
        }
        drop(v164_3_cursor);
        drop(v164_2);
        let v164_4: Space = unite(&(v164_3),&(v163_6));
        let v164_5: Space = intersect(&(v164_4),&(*capture_2));
        let v163_6_next = unite(&v163_6,&(v164_5));
        if equal(&v163_6_next,&v163_6) { break; }
        v163_6 = v163_6_next;
      }
      let mut v163_7: Space = ((*capture_3)).clone();
      loop {
        let v170_1: Space = intersect(&(v163_7),&(*capture_2));
        let v170_2: Space = restrict_to(&(*capture_1),&(v170_1));
        drop(v170_1);
        let mut v170_3 = Space::new();
        let mut v170_3_cursor = (v170_2).read_zipper();
        for v170_3_byte in v170_3_cursor.child_mask().iter() {
          v170_3_cursor.descend_to_byte(v170_3_byte);
          let v170_3_tail = v170_3_cursor.make_map();
          v170_3_cursor.ascend(1);
          let v170_3_head = Path::from_slice(&[v170_3_byte]);
          let v171_2: Space = singleton(&(v170_3_head));
          let v171_3: Space = intersect(&(*CONSTANT_11),&(v171_2));
          let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
          drop(v171_3);
          let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
          drop(v171_4);
          let v171_7: Space = if (v171_5).is_empty() { Space::new() } else {
            let mut v172_6 = Space::new();
            let mut v172_6_cursor = (v170_3_tail).read_zipper();
            for v172_6_byte in v172_6_cursor.child_mask().iter() {
              v172_6_cursor.descend_to_byte(v172_6_byte);
              let v172_6_tail = v172_6_cursor.make_map();
              v172_6_cursor.ascend(1);
              let v172_6_head = Path::from_slice(&[v172_6_byte]);
              let v173_2: Space = singleton(&(v172_6_head));
              let v173_3: Space = intersect(&(*CONSTANT_11),&(v173_2));
              let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
              drop(v173_3);
              let v173_5: Space = subtract(&(*CONSTANT_0),&(v173_4));
              drop(v173_4);
              let v173_8: Space = if (v173_5).is_empty() { Space::new() } else {
                let v174_6: Path = concat_path(&(v170_3_head),&(v172_6_head));
                let v174_7: Space = routine_14(c, &(v174_6), &(v172_6_tail));
                compose(&(v173_5),&(v174_7))
              };
              drop(v173_5);
              let v173_9: Space = intersect(&(*CONSTANT_11),&(v173_2));
              drop(v173_2);
              let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
              drop(v173_9);
              let v173_12: Space = if (v173_10).is_empty() { Space::new() } else {
                let v175_6: Path = concat_path(&(v170_3_head),&(v172_6_head));
                let v175_11: Space = routine_15(c, &(v175_6), &(v172_6_tail));
                drop(v175_6);
                compose(&(v173_10),&(v175_11))
              };
              drop(v173_10);
              let v173_13: Space = unite(&(v173_8),&(v173_12));
              v172_6.join_into((v173_13).clone());
            }
            drop(v172_6_cursor);
            compose(&(v171_5),&(v172_6))
          };
          drop(v171_5);
          let v171_8: Space = intersect(&(*CONSTANT_11),&(v171_2));
          drop(v171_2);
          let v171_9: Space = if has_head(&(v171_8)) { singleton(&[]) } else { Space::new() };
          drop(v171_8);
          let v171_10: Space = compose(&(v171_9),&(v170_3_tail));
          drop(v171_9);
          let v171_11: Space = unite(&(v171_7),&(v171_10));
          drop(v171_10);
          v170_3.join_into((v171_11).clone());
        }
        drop(v170_3_cursor);
        drop(v170_2);
        let v170_4: Space = unite(&(v170_3),&(v163_7));
        let v170_5: Space = intersect(&(v170_4),&(*capture_2));
        let v163_7_next = unite(&v163_7,&(v170_5));
        if equal(&v163_7_next,&v163_7) { break; }
        v163_7 = v163_7_next;
      }
      let v163_8: Space = subtract(&(v163_6),&(v163_7));
      let v163_9: Space = routine_6(c, &(v59_157_head), &(v59_157_tail), &(*capture_0), &(*capture_1), &(v163_8));
      compose(&(v162_5),&(v163_9))
    };
    drop(v162_5);
    let v162_11: Space = intersect(&(*CONSTANT_11),&(v162_2));
    drop(v162_2);
    let v162_12: Space = if has_head(&(v162_11)) { singleton(&[]) } else { Space::new() };
    drop(v162_11);
    let v162_17: Space = if (v162_12).is_empty() { Space::new() } else {
      let mut v176_13: Space = ((*capture_3)).clone();
      loop {
        let v177_1: Space = intersect(&(v176_13),&(*capture_2));
        let v177_2: Space = restrict_to(&(*capture_0),&(v177_1));
        drop(v177_1);
        let mut v177_3 = Space::new();
        let mut v177_3_cursor = (v177_2).read_zipper();
        for v177_3_byte in v177_3_cursor.child_mask().iter() {
          v177_3_cursor.descend_to_byte(v177_3_byte);
          let v177_3_tail = v177_3_cursor.make_map();
          v177_3_cursor.ascend(1);
          let v177_3_head = Path::from_slice(&[v177_3_byte]);
          let v178_2: Space = singleton(&(v177_3_head));
          let v178_3: Space = intersect(&(*CONSTANT_11),&(v178_2));
          let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
          drop(v178_3);
          let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
          drop(v178_4);
          let v178_7: Space = if (v178_5).is_empty() { Space::new() } else {
            let mut v179_6 = Space::new();
            let mut v179_6_cursor = (v177_3_tail).read_zipper();
            for v179_6_byte in v179_6_cursor.child_mask().iter() {
              v179_6_cursor.descend_to_byte(v179_6_byte);
              let v179_6_tail = v179_6_cursor.make_map();
              v179_6_cursor.ascend(1);
              let v179_6_head = Path::from_slice(&[v179_6_byte]);
              let v180_2: Space = singleton(&(v179_6_head));
              let v180_3: Space = intersect(&(*CONSTANT_11),&(v180_2));
              let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
              drop(v180_3);
              let v180_5: Space = subtract(&(*CONSTANT_0),&(v180_4));
              drop(v180_4);
              let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
                let v181_6: Path = concat_path(&(v177_3_head),&(v179_6_head));
                let v181_7: Space = routine_14(c, &(v181_6), &(v179_6_tail));
                compose(&(v180_5),&(v181_7))
              };
              drop(v180_5);
              let v180_9: Space = intersect(&(*CONSTANT_11),&(v180_2));
              drop(v180_2);
              let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
              drop(v180_9);
              let v180_12: Space = if (v180_10).is_empty() { Space::new() } else {
                let v182_6: Path = concat_path(&(v177_3_head),&(v179_6_head));
                let v182_11: Space = routine_15(c, &(v182_6), &(v179_6_tail));
                drop(v182_6);
                compose(&(v180_10),&(v182_11))
              };
              drop(v180_10);
              let v180_13: Space = unite(&(v180_8),&(v180_12));
              v179_6.join_into((v180_13).clone());
            }
            drop(v179_6_cursor);
            compose(&(v178_5),&(v179_6))
          };
          drop(v178_5);
          let v178_8: Space = intersect(&(*CONSTANT_11),&(v178_2));
          drop(v178_2);
          let v178_9: Space = if has_head(&(v178_8)) { singleton(&[]) } else { Space::new() };
          drop(v178_8);
          let v178_10: Space = compose(&(v178_9),&(v177_3_tail));
          drop(v178_9);
          let v178_11: Space = unite(&(v178_7),&(v178_10));
          drop(v178_10);
          v177_3.join_into((v178_11).clone());
        }
        drop(v177_3_cursor);
        drop(v177_2);
        let v177_4: Space = unite(&(v177_3),&(v176_13));
        let v177_5: Space = intersect(&(v177_4),&(*capture_2));
        let v176_13_next = unite(&v176_13,&(v177_5));
        if equal(&v176_13_next,&v176_13) { break; }
        v176_13 = v176_13_next;
      }
      let mut v176_14: Space = ((*capture_3)).clone();
      loop {
        let v183_1: Space = intersect(&(v176_14),&(*capture_2));
        let v183_2: Space = restrict_to(&(*capture_1),&(v183_1));
        drop(v183_1);
        let mut v183_3 = Space::new();
        let mut v183_3_cursor = (v183_2).read_zipper();
        for v183_3_byte in v183_3_cursor.child_mask().iter() {
          v183_3_cursor.descend_to_byte(v183_3_byte);
          let v183_3_tail = v183_3_cursor.make_map();
          v183_3_cursor.ascend(1);
          let v183_3_head = Path::from_slice(&[v183_3_byte]);
          let v184_2: Space = singleton(&(v183_3_head));
          let v184_3: Space = intersect(&(*CONSTANT_11),&(v184_2));
          let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
          drop(v184_3);
          let v184_5: Space = subtract(&(*CONSTANT_0),&(v184_4));
          drop(v184_4);
          let v184_7: Space = if (v184_5).is_empty() { Space::new() } else {
            let mut v185_6 = Space::new();
            let mut v185_6_cursor = (v183_3_tail).read_zipper();
            for v185_6_byte in v185_6_cursor.child_mask().iter() {
              v185_6_cursor.descend_to_byte(v185_6_byte);
              let v185_6_tail = v185_6_cursor.make_map();
              v185_6_cursor.ascend(1);
              let v185_6_head = Path::from_slice(&[v185_6_byte]);
              let v186_2: Space = singleton(&(v185_6_head));
              let v186_3: Space = intersect(&(*CONSTANT_11),&(v186_2));
              let v186_4: Space = if has_head(&(v186_3)) { singleton(&[]) } else { Space::new() };
              drop(v186_3);
              let v186_5: Space = subtract(&(*CONSTANT_0),&(v186_4));
              drop(v186_4);
              let v186_8: Space = if (v186_5).is_empty() { Space::new() } else {
                let v187_6: Path = concat_path(&(v183_3_head),&(v185_6_head));
                let v187_7: Space = routine_14(c, &(v187_6), &(v185_6_tail));
                compose(&(v186_5),&(v187_7))
              };
              drop(v186_5);
              let v186_9: Space = intersect(&(*CONSTANT_11),&(v186_2));
              drop(v186_2);
              let v186_10: Space = if has_head(&(v186_9)) { singleton(&[]) } else { Space::new() };
              drop(v186_9);
              let v186_12: Space = if (v186_10).is_empty() { Space::new() } else {
                let v188_6: Path = concat_path(&(v183_3_head),&(v185_6_head));
                let v188_11: Space = routine_15(c, &(v188_6), &(v185_6_tail));
                drop(v188_6);
                compose(&(v186_10),&(v188_11))
              };
              drop(v186_10);
              let v186_13: Space = unite(&(v186_8),&(v186_12));
              v185_6.join_into((v186_13).clone());
            }
            drop(v185_6_cursor);
            compose(&(v184_5),&(v185_6))
          };
          drop(v184_5);
          let v184_8: Space = intersect(&(*CONSTANT_11),&(v184_2));
          drop(v184_2);
          let v184_9: Space = if has_head(&(v184_8)) { singleton(&[]) } else { Space::new() };
          drop(v184_8);
          let v184_10: Space = compose(&(v184_9),&(v183_3_tail));
          drop(v184_9);
          let v184_11: Space = unite(&(v184_7),&(v184_10));
          drop(v184_10);
          v183_3.join_into((v184_11).clone());
        }
        drop(v183_3_cursor);
        drop(v183_2);
        let v183_4: Space = unite(&(v183_3),&(v176_14));
        let v183_5: Space = intersect(&(v183_4),&(*capture_2));
        let v176_14_next = unite(&v176_14,&(v183_5));
        if equal(&v176_14_next,&v176_14) { break; }
        v176_14 = v176_14_next;
      }
      let v176_15: Space = subtract(&(v176_13),&(v176_14));
      let v176_16: Space = routine_7(c, &(v59_157_head), &(v59_157_tail), &(*capture_0), &(*capture_1), &(v176_15));
      compose(&(v162_12),&(v176_16))
    };
    drop(v162_12);
    let v162_18: Space = unite(&(v162_10),&(v162_17));
    v59_157.join_into((v162_18).clone());
  }
  drop(v59_157_cursor);

((v59_112).clone(),(v59_113).clone(),(v59_120).clone(),(v59_127).clone(),(v59_128).clone(),(v59_129).clone(),(v59_157).clone(),(v59_82).clone(),(v59_83).clone(),(v59_84).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_22: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v1_21: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v2_4: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
      let v2_7: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4));
      let v2_8: Space = unite(&(v2_4),&(v2_7));
      let v2_11: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_6));
      let v2_12: Space = unite(&(v2_8),&(v2_11));
      let v2_15: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_8));
      let v2_16: Space = unite(&(v2_12),&(v2_15));
      let v2_19: Space = routine_1(c, &(*CONSTANT_9), &(*CONSTANT_10));
      let v2_20: Space = unite(&(v2_16),&(v2_19));
      compose(&(*CONSTANT_0),&(v2_20))
    };
    compose(&(*CONSTANT_0),&(v1_21))
  };
  let v0_40: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v3_39: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v4_26: Space = routine_2(c, &(*CONSTANT_1), &(*CONSTANT_2));
      let v4_28: Space = routine_2(c, &(*CONSTANT_3), &(*CONSTANT_4));
      let v4_29: Space = unite(&(v4_26),&(v4_28));
      let v4_31: Space = routine_2(c, &(*CONSTANT_5), &(*CONSTANT_6));
      let v4_32: Space = unite(&(v4_29),&(v4_31));
      let v4_34: Space = routine_2(c, &(*CONSTANT_7), &(*CONSTANT_8));
      let v4_35: Space = unite(&(v4_32),&(v4_34));
      let v4_37: Space = routine_2(c, &(*CONSTANT_9), &(*CONSTANT_10));
      let v4_38: Space = unite(&(v4_35),&(v4_37));
      compose(&(*CONSTANT_0),&(v4_38))
    };
    compose(&(*CONSTANT_0),&(v3_39))
  };
  let mut v0_47 = Space::new();
  let mut v0_47_cursor = (v0_40).read_zipper();
  for v0_47_byte in v0_47_cursor.child_mask().iter() {
    v0_47_cursor.descend_to_byte(v0_47_byte);
    let v0_47_tail = v0_47_cursor.make_map();
    v0_47_cursor.ascend(1);
    let v0_47_head = Path::from_slice(&[v0_47_byte]);
    let v5_2: Space = singleton(&(v0_47_head));
    let v5_3: Space = intersect(&(*CONSTANT_11),&(v5_2));
    let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
    drop(v5_3);
    let v5_5: Space = subtract(&(*CONSTANT_0),&(v5_4));
    drop(v5_4);
    let v5_7: Space = if (v5_5).is_empty() { Space::new() } else {
      let mut v6_6 = Space::new();
      let mut v6_6_cursor = (v0_47_tail).read_zipper();
      for v6_6_byte in v6_6_cursor.child_mask().iter() {
        v6_6_cursor.descend_to_byte(v6_6_byte);
        let v6_6_tail = v6_6_cursor.make_map();
        v6_6_cursor.ascend(1);
        let v6_6_head = Path::from_slice(&[v6_6_byte]);
        let v7_2: Space = singleton(&(v6_6_head));
        let v7_3: Space = intersect(&(*CONSTANT_11),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_47_head),&(v6_6_head));
          let v8_7: Space = routine_3(c, &(v8_6), &(v6_6_tail));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_11),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v0_47_head),&(v6_6_head));
          let v9_11: Space = routine_4(c, &(v9_6), &(v6_6_tail));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_6.join_into((v7_13).clone());
      }
      drop(v6_6_cursor);
      compose(&(v5_5),&(v6_6))
    };
    drop(v5_5);
    let v5_8: Space = intersect(&(*CONSTANT_11),&(v5_2));
    let v5_9: Space = if has_head(&(v5_8)) { singleton(&[]) } else { Space::new() };
    drop(v5_8);
    let v5_10: Space = compose(&(v5_9),&(v5_2));
    drop(v5_2);
    drop(v5_9);
    let v5_11: Space = unite(&(v5_7),&(v5_10));
    drop(v5_10);
    v0_47.join_into((v5_11).clone());
  }
  drop(v0_47_cursor);
  let v0_48: Space = unite(&(v0_22),&(v0_47));
  let v0_49: Space = range(&(v0_48),0,1);
  let mut v0_109 = Space::new();
  let mut v0_109_cursor = (v0_49).read_zipper();
  for v0_109_byte in v0_109_cursor.child_mask().iter() {
    v0_109_cursor.descend_to_byte(v0_109_byte);
    let v0_109_tail = v0_109_cursor.make_map();
    v0_109_cursor.ascend(1);
    let v0_109_head = Path::from_slice(&[v0_109_byte]);
    let v10_2: Space = singleton(&(v0_109_head));
    let v10_3: Space = intersect(&(*CONSTANT_11),&(v10_2));
    let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
    drop(v10_3);
    let v10_5: Space = subtract(&(*CONSTANT_0),&(v10_4));
    drop(v10_4);
    let v10_42: Space = if (v10_5).is_empty() { Space::new() } else {
      let v11_16: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v12_15: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v13_6: Space = routine_5(c, &(*CONSTANT_1), &(*CONSTANT_2));
          let v13_7: Space = routine_5(c, &(*CONSTANT_3), &(*CONSTANT_4));
          let v13_8: Space = unite(&(v13_6),&(v13_7));
          let v13_9: Space = routine_5(c, &(*CONSTANT_5), &(*CONSTANT_6));
          let v13_10: Space = unite(&(v13_8),&(v13_9));
          let v13_11: Space = routine_5(c, &(*CONSTANT_7), &(*CONSTANT_8));
          let v13_12: Space = unite(&(v13_10),&(v13_11));
          let v13_13: Space = routine_5(c, &(*CONSTANT_9), &(*CONSTANT_10));
          let v13_14: Space = unite(&(v13_12),&(v13_13));
          compose(&(*CONSTANT_0),&(v13_14))
        };
        compose(&(*CONSTANT_0),&(v12_15))
      };
      let v11_27: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v14_26: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v15_17: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
          let v15_18: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4));
          let v15_19: Space = unite(&(v15_17),&(v15_18));
          let v15_20: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_6));
          let v15_21: Space = unite(&(v15_19),&(v15_20));
          let v15_22: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_8));
          let v15_23: Space = unite(&(v15_21),&(v15_22));
          let v15_24: Space = routine_1(c, &(*CONSTANT_9), &(*CONSTANT_10));
          let v15_25: Space = unite(&(v15_23),&(v15_24));
          compose(&(*CONSTANT_0),&(v15_25))
        };
        compose(&(*CONSTANT_0),&(v14_26))
      };
      let v11_38: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v16_37: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v17_28: Space = routine_2(c, &(*CONSTANT_1), &(*CONSTANT_2));
          let v17_29: Space = routine_2(c, &(*CONSTANT_3), &(*CONSTANT_4));
          let v17_30: Space = unite(&(v17_28),&(v17_29));
          let v17_31: Space = routine_2(c, &(*CONSTANT_5), &(*CONSTANT_6));
          let v17_32: Space = unite(&(v17_30),&(v17_31));
          let v17_33: Space = routine_2(c, &(*CONSTANT_7), &(*CONSTANT_8));
          let v17_34: Space = unite(&(v17_32),&(v17_33));
          let v17_35: Space = routine_2(c, &(*CONSTANT_9), &(*CONSTANT_10));
          let v17_36: Space = unite(&(v17_34),&(v17_35));
          compose(&(*CONSTANT_0),&(v17_36))
        };
        compose(&(*CONSTANT_0),&(v16_37))
      };
      let mut v11_39 = Space::new();
      let mut v11_39_cursor = (v11_38).read_zipper();
      for v11_39_byte in v11_39_cursor.child_mask().iter() {
        v11_39_cursor.descend_to_byte(v11_39_byte);
        let v11_39_tail = v11_39_cursor.make_map();
        v11_39_cursor.ascend(1);
        let v11_39_head = Path::from_slice(&[v11_39_byte]);
        let v18_2: Space = singleton(&(v11_39_head));
        let v18_3: Space = intersect(&(*CONSTANT_11),&(v18_2));
        let v18_4: Space = if has_head(&(v18_3)) { singleton(&[]) } else { Space::new() };
        drop(v18_3);
        let v18_5: Space = subtract(&(*CONSTANT_0),&(v18_4));
        drop(v18_4);
        let v18_7: Space = if (v18_5).is_empty() { Space::new() } else {
          let mut v19_6 = Space::new();
          let mut v19_6_cursor = (v11_39_tail).read_zipper();
          for v19_6_byte in v19_6_cursor.child_mask().iter() {
            v19_6_cursor.descend_to_byte(v19_6_byte);
            let v19_6_tail = v19_6_cursor.make_map();
            v19_6_cursor.ascend(1);
            let v19_6_head = Path::from_slice(&[v19_6_byte]);
            let v20_2: Space = singleton(&(v19_6_head));
            let v20_3: Space = intersect(&(*CONSTANT_11),&(v20_2));
            let v20_4: Space = if has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
            drop(v20_3);
            let v20_5: Space = subtract(&(*CONSTANT_0),&(v20_4));
            drop(v20_4);
            let v20_8: Space = if (v20_5).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v11_39_head),&(v19_6_head));
              let v21_7: Space = routine_3(c, &(v21_6), &(v19_6_tail));
              compose(&(v20_5),&(v21_7))
            };
            drop(v20_5);
            let v20_9: Space = intersect(&(*CONSTANT_11),&(v20_2));
            drop(v20_2);
            let v20_10: Space = if has_head(&(v20_9)) { singleton(&[]) } else { Space::new() };
            drop(v20_9);
            let v20_12: Space = if (v20_10).is_empty() { Space::new() } else {
              let v22_6: Path = concat_path(&(v11_39_head),&(v19_6_head));
              let v22_11: Space = routine_4(c, &(v22_6), &(v19_6_tail));
              drop(v22_6);
              compose(&(v20_10),&(v22_11))
            };
            drop(v20_10);
            let v20_13: Space = unite(&(v20_8),&(v20_12));
            v19_6.join_into((v20_13).clone());
          }
          drop(v19_6_cursor);
          compose(&(v18_5),&(v19_6))
        };
        drop(v18_5);
        let v18_8: Space = intersect(&(*CONSTANT_11),&(v18_2));
        let v18_9: Space = if has_head(&(v18_8)) { singleton(&[]) } else { Space::new() };
        drop(v18_8);
        let v18_10: Space = compose(&(v18_9),&(v18_2));
        drop(v18_2);
        drop(v18_9);
        let v18_11: Space = unite(&(v18_7),&(v18_10));
        drop(v18_10);
        v11_39.join_into((v18_11).clone());
      }
      drop(v11_39_cursor);
      let v11_40: Space = unite(&(v11_27),&(v11_39));
      let v11_41: Space = routine_6(c, &(v0_109_head), &(v0_109_tail), &(v11_16), &(*CONSTANT_12), &(v11_40));
      compose(&(v10_5),&(v11_41))
    };
    drop(v10_5);
    let v10_43: Space = intersect(&(*CONSTANT_11),&(v10_2));
    drop(v10_2);
    let v10_44: Space = if has_head(&(v10_43)) { singleton(&[]) } else { Space::new() };
    drop(v10_43);
    let v10_81: Space = if (v10_44).is_empty() { Space::new() } else {
      let v23_55: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v24_54: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v25_45: Space = routine_5(c, &(*CONSTANT_1), &(*CONSTANT_2));
          let v25_46: Space = routine_5(c, &(*CONSTANT_3), &(*CONSTANT_4));
          let v25_47: Space = unite(&(v25_45),&(v25_46));
          let v25_48: Space = routine_5(c, &(*CONSTANT_5), &(*CONSTANT_6));
          let v25_49: Space = unite(&(v25_47),&(v25_48));
          let v25_50: Space = routine_5(c, &(*CONSTANT_7), &(*CONSTANT_8));
          let v25_51: Space = unite(&(v25_49),&(v25_50));
          let v25_52: Space = routine_5(c, &(*CONSTANT_9), &(*CONSTANT_10));
          let v25_53: Space = unite(&(v25_51),&(v25_52));
          compose(&(*CONSTANT_0),&(v25_53))
        };
        compose(&(*CONSTANT_0),&(v24_54))
      };
      let v23_66: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v26_65: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v27_56: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
          let v27_57: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4));
          let v27_58: Space = unite(&(v27_56),&(v27_57));
          let v27_59: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_6));
          let v27_60: Space = unite(&(v27_58),&(v27_59));
          let v27_61: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_8));
          let v27_62: Space = unite(&(v27_60),&(v27_61));
          let v27_63: Space = routine_1(c, &(*CONSTANT_9), &(*CONSTANT_10));
          let v27_64: Space = unite(&(v27_62),&(v27_63));
          compose(&(*CONSTANT_0),&(v27_64))
        };
        compose(&(*CONSTANT_0),&(v26_65))
      };
      let v23_77: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v28_76: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v29_67: Space = routine_2(c, &(*CONSTANT_1), &(*CONSTANT_2));
          let v29_68: Space = routine_2(c, &(*CONSTANT_3), &(*CONSTANT_4));
          let v29_69: Space = unite(&(v29_67),&(v29_68));
          let v29_70: Space = routine_2(c, &(*CONSTANT_5), &(*CONSTANT_6));
          let v29_71: Space = unite(&(v29_69),&(v29_70));
          let v29_72: Space = routine_2(c, &(*CONSTANT_7), &(*CONSTANT_8));
          let v29_73: Space = unite(&(v29_71),&(v29_72));
          let v29_74: Space = routine_2(c, &(*CONSTANT_9), &(*CONSTANT_10));
          let v29_75: Space = unite(&(v29_73),&(v29_74));
          compose(&(*CONSTANT_0),&(v29_75))
        };
        compose(&(*CONSTANT_0),&(v28_76))
      };
      let mut v23_78 = Space::new();
      let mut v23_78_cursor = (v23_77).read_zipper();
      for v23_78_byte in v23_78_cursor.child_mask().iter() {
        v23_78_cursor.descend_to_byte(v23_78_byte);
        let v23_78_tail = v23_78_cursor.make_map();
        v23_78_cursor.ascend(1);
        let v23_78_head = Path::from_slice(&[v23_78_byte]);
        let v30_2: Space = singleton(&(v23_78_head));
        let v30_3: Space = intersect(&(*CONSTANT_11),&(v30_2));
        let v30_4: Space = if has_head(&(v30_3)) { singleton(&[]) } else { Space::new() };
        drop(v30_3);
        let v30_5: Space = subtract(&(*CONSTANT_0),&(v30_4));
        drop(v30_4);
        let v30_7: Space = if (v30_5).is_empty() { Space::new() } else {
          let mut v31_6 = Space::new();
          let mut v31_6_cursor = (v23_78_tail).read_zipper();
          for v31_6_byte in v31_6_cursor.child_mask().iter() {
            v31_6_cursor.descend_to_byte(v31_6_byte);
            let v31_6_tail = v31_6_cursor.make_map();
            v31_6_cursor.ascend(1);
            let v31_6_head = Path::from_slice(&[v31_6_byte]);
            let v32_2: Space = singleton(&(v31_6_head));
            let v32_3: Space = intersect(&(*CONSTANT_11),&(v32_2));
            let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_8: Space = if (v32_5).is_empty() { Space::new() } else {
              let v33_6: Path = concat_path(&(v23_78_head),&(v31_6_head));
              let v33_7: Space = routine_3(c, &(v33_6), &(v31_6_tail));
              compose(&(v32_5),&(v33_7))
            };
            drop(v32_5);
            let v32_9: Space = intersect(&(*CONSTANT_11),&(v32_2));
            drop(v32_2);
            let v32_10: Space = if has_head(&(v32_9)) { singleton(&[]) } else { Space::new() };
            drop(v32_9);
            let v32_12: Space = if (v32_10).is_empty() { Space::new() } else {
              let v34_6: Path = concat_path(&(v23_78_head),&(v31_6_head));
              let v34_11: Space = routine_4(c, &(v34_6), &(v31_6_tail));
              drop(v34_6);
              compose(&(v32_10),&(v34_11))
            };
            drop(v32_10);
            let v32_13: Space = unite(&(v32_8),&(v32_12));
            v31_6.join_into((v32_13).clone());
          }
          drop(v31_6_cursor);
          compose(&(v30_5),&(v31_6))
        };
        drop(v30_5);
        let v30_8: Space = intersect(&(*CONSTANT_11),&(v30_2));
        let v30_9: Space = if has_head(&(v30_8)) { singleton(&[]) } else { Space::new() };
        drop(v30_8);
        let v30_10: Space = compose(&(v30_9),&(v30_2));
        drop(v30_2);
        drop(v30_9);
        let v30_11: Space = unite(&(v30_7),&(v30_10));
        drop(v30_10);
        v23_78.join_into((v30_11).clone());
      }
      drop(v23_78_cursor);
      let v23_79: Space = unite(&(v23_66),&(v23_78));
      let v23_80: Space = routine_7(c, &(v0_109_head), &(v0_109_tail), &(v23_55), &(*CONSTANT_12), &(v23_79));
      compose(&(v10_44),&(v23_80))
    };
    drop(v10_44);
    let v10_82: Space = unite(&(v10_42),&(v10_81));
    v0_109.join_into((v10_82).clone());
  }
  drop(v0_109_cursor);
  (v0_109).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v35_2: Space = singleton(&(*p0));
  (v35_2).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v36_8 = Space::new();
  let mut v36_8_cursor = (*s0).read_zipper();
  for v36_8_byte in v36_8_cursor.child_mask().iter() {
    v36_8_cursor.descend_to_byte(v36_8_byte);
    let v36_8_tail = v36_8_cursor.make_map();
    v36_8_cursor.ascend(1);
    let v36_8_head = Path::from_slice(&[v36_8_byte]);
    let v37_2: Space = singleton(&(v36_8_head));
    let v37_3: Space = intersect(&(*CONSTANT_11),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_7: Space = if (v37_5).is_empty() { Space::new() } else {
      let mut v38_6 = Space::new();
      let mut v38_6_cursor = (v36_8_tail).read_zipper();
      for v38_6_byte in v38_6_cursor.child_mask().iter() {
        v38_6_cursor.descend_to_byte(v38_6_byte);
        let v38_6_tail = v38_6_cursor.make_map();
        v38_6_cursor.ascend(1);
        let v38_6_head = Path::from_slice(&[v38_6_byte]);
        let v39_2: Space = singleton(&(v38_6_head));
        let v39_3: Space = intersect(&(*CONSTANT_11),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (v39_5).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v36_8_head),&(v38_6_head));
          let v40_7: Space = routine_8(c, &(v40_6), &(*p0), &(v38_6_tail));
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_11),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (v39_10).is_empty() { Space::new() } else {
          let v41_6: Path = concat_path(&(v36_8_head),&(v38_6_head));
          let v41_11: Space = routine_9(c, &(v41_6), &(*p0), &(v38_6_tail));
          drop(v41_6);
          compose(&(v39_10),&(v41_11))
        };
        drop(v39_10);
        let v39_13: Space = unite(&(v39_8),&(v39_12));
        v38_6.join_into((v39_13).clone());
      }
      drop(v38_6_cursor);
      compose(&(v37_5),&(v38_6))
    };
    drop(v37_5);
    let v37_8: Space = intersect(&(*CONSTANT_11),&(v37_2));
    drop(v37_2);
    let v37_9: Space = if has_head(&(v37_8)) { singleton(&[]) } else { Space::new() };
    drop(v37_8);
    let v37_12: Space = if (v37_9).is_empty() { Space::new() } else {
      let v42_10: Path = concat_path(&(v36_8_head),&(*p0));
      let v42_11: Space = singleton(&(v42_10));
      drop(v42_10);
      compose(&(v37_9),&(v42_11))
    };
    drop(v37_9);
    let v37_13: Space = unite(&(v37_7),&(v37_12));
    drop(v37_12);
    v36_8.join_into((v37_13).clone());
  }
  drop(v36_8_cursor);
  (v36_8).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v43_5 = Space::new();
  let mut v43_5_cursor = (*s0).read_zipper();
  for v43_5_byte in v43_5_cursor.child_mask().iter() {
    v43_5_cursor.descend_to_byte(v43_5_byte);
    let v43_5_tail = v43_5_cursor.make_map();
    v43_5_cursor.ascend(1);
    let v43_5_head = Path::from_slice(&[v43_5_byte]);
    let v44_2: Space = singleton(&(v43_5_head));
    let v44_3: Space = intersect(&(*CONSTANT_11),&(v44_2));
    let v44_4: Space = if has_head(&(v44_3)) { singleton(&[]) } else { Space::new() };
    drop(v44_3);
    let v44_5: Space = subtract(&(*CONSTANT_0),&(v44_4));
    drop(v44_4);
    let v44_8: Space = if (v44_5).is_empty() { Space::new() } else {
      let v45_6: Path = concat_path(&(*p0),&(v43_5_head));
      let v45_7: Space = routine_3(c, &(v45_6), &(v43_5_tail));
      compose(&(v44_5),&(v45_7))
    };
    drop(v44_5);
    let v44_9: Space = intersect(&(*CONSTANT_11),&(v44_2));
    drop(v44_2);
    let v44_10: Space = if has_head(&(v44_9)) { singleton(&[]) } else { Space::new() };
    drop(v44_9);
    let v44_12: Space = if (v44_10).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&(v43_5_head));
      let v46_11: Space = singleton(&(v46_6));
      drop(v46_6);
      compose(&(v44_10),&(v46_11))
    };
    drop(v44_10);
    let v44_13: Space = unite(&(v44_8),&(v44_12));
    drop(v44_12);
    v43_5.join_into((v44_13).clone());
  }
  drop(v43_5_cursor);
  (v43_5).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v47_2: Space = singleton(&(*p0));
  (v47_2).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v48_8 = Space::new();
  let mut v48_8_cursor = (*s0).read_zipper();
  for v48_8_byte in v48_8_cursor.child_mask().iter() {
    v48_8_cursor.descend_to_byte(v48_8_byte);
    let v48_8_tail = v48_8_cursor.make_map();
    v48_8_cursor.ascend(1);
    let v48_8_head = Path::from_slice(&[v48_8_byte]);
    let v49_2: Space = singleton(&(v48_8_head));
    let v49_3: Space = intersect(&(*CONSTANT_11),&(v49_2));
    let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
    drop(v49_3);
    let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
    drop(v49_4);
    let v49_7: Space = if (v49_5).is_empty() { Space::new() } else {
      let mut v50_6 = Space::new();
      let mut v50_6_cursor = (v48_8_tail).read_zipper();
      for v50_6_byte in v50_6_cursor.child_mask().iter() {
        v50_6_cursor.descend_to_byte(v50_6_byte);
        let v50_6_tail = v50_6_cursor.make_map();
        v50_6_cursor.ascend(1);
        let v50_6_head = Path::from_slice(&[v50_6_byte]);
        let v51_2: Space = singleton(&(v50_6_head));
        let v51_3: Space = intersect(&(*CONSTANT_11),&(v51_2));
        let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
        drop(v51_3);
        let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
        drop(v51_4);
        let v51_8: Space = if (v51_5).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v48_8_head),&(v50_6_head));
          let v52_7: Space = routine_10(c, &(v52_6), &(*p0), &(v50_6_tail));
          compose(&(v51_5),&(v52_7))
        };
        drop(v51_5);
        let v51_9: Space = intersect(&(*CONSTANT_11),&(v51_2));
        drop(v51_2);
        let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
        drop(v51_9);
        let v51_12: Space = if (v51_10).is_empty() { Space::new() } else {
          let v53_6: Path = concat_path(&(v48_8_head),&(v50_6_head));
          let v53_11: Space = routine_11(c, &(v53_6), &(*p0), &(v50_6_tail));
          drop(v53_6);
          compose(&(v51_10),&(v53_11))
        };
        drop(v51_10);
        let v51_13: Space = unite(&(v51_8),&(v51_12));
        v50_6.join_into((v51_13).clone());
      }
      drop(v50_6_cursor);
      compose(&(v49_5),&(v50_6))
    };
    drop(v49_5);
    let v49_8: Space = intersect(&(*CONSTANT_11),&(v49_2));
    drop(v49_2);
    let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
    drop(v49_8);
    let v49_12: Space = if (v49_9).is_empty() { Space::new() } else {
      let v54_10: Path = concat_path(&(v48_8_head),&(*p0));
      let v54_11: Space = singleton(&(v54_10));
      drop(v54_10);
      compose(&(v49_9),&(v54_11))
    };
    drop(v49_9);
    let v49_13: Space = unite(&(v49_7),&(v49_12));
    drop(v49_12);
    v48_8.join_into((v49_13).clone());
  }
  drop(v48_8_cursor);
  (v48_8).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v55_8 = Space::new();
  let mut v55_8_cursor = (*s0).read_zipper();
  for v55_8_byte in v55_8_cursor.child_mask().iter() {
    v55_8_cursor.descend_to_byte(v55_8_byte);
    let v55_8_tail = v55_8_cursor.make_map();
    v55_8_cursor.ascend(1);
    let v55_8_head = Path::from_slice(&[v55_8_byte]);
    let v56_2: Space = singleton(&(v55_8_head));
    let v56_3: Space = intersect(&(*CONSTANT_11),&(v56_2));
    let v56_4: Space = if has_head(&(v56_3)) { singleton(&[]) } else { Space::new() };
    drop(v56_3);
    let v56_5: Space = subtract(&(*CONSTANT_0),&(v56_4));
    drop(v56_4);
    let v56_8: Space = if (v56_5).is_empty() { Space::new() } else {
      let v57_6: Path = concat_path(&(*p0),&(v55_8_head));
      let v57_7: Space = routine_6(c, &(v57_6), &(v55_8_tail), &(*s1), &(*s2), &(*s3));
      compose(&(v56_5),&(v57_7))
    };
    drop(v56_5);
    let v56_9: Space = intersect(&(*CONSTANT_11),&(v56_2));
    drop(v56_2);
    let v56_10: Space = if has_head(&(v56_9)) { singleton(&[]) } else { Space::new() };
    drop(v56_9);
    let v56_27: Space = if (v56_10).is_empty() { Space::new() } else {
      let v58_6: Path = concat_path(&(*p0),&(v55_8_head));
      let v58_11: Space = singleton(&(v58_6));
      let v58_12: Space = routine_12(c, &(*s1), &(*s3), &(v58_11));
      let v58_13: Space = routine_12(c, &(*s2), &(*s3), &(v58_11));
      let v58_14: Space = intersect(&(v58_12),&(v58_13));
      let v58_15: Space = subtract(&(v58_14),&(v58_11));
      drop(v58_11);
      let v58_16: Space = wrap(&(v58_15),&(v58_6));
      drop(v58_6);
      let v58_17: Space = subtract(&(*s3),&(v58_13));
      let v58_18: Space = subtract(&(v58_17),&(v58_12));
      let v58_19: Space = routine_13(c, &(*s2), &(*s1), &(v58_18));
      let v58_20: Space = unite(&(v58_16),&(v58_19));
      let v58_21: Space = subtract(&(v58_12),&(v58_13));
      let v58_22: Space = routine_13(c, &(*s2), &(*s1), &(v58_21));
      let v58_23: Space = unite(&(v58_20),&(v58_22));
      let v58_24: Space = subtract(&(v58_13),&(v58_12));
      let v58_25: Space = routine_13(c, &(*s2), &(*s1), &(v58_24));
      let v58_26: Space = unite(&(v58_23),&(v58_25));
      compose(&(v56_10),&(v58_26))
    };
    drop(v56_10);
    let v56_28: Space = unite(&(v56_8),&(v56_27));
    v55_8.join_into((v56_28).clone());
  }
  drop(v55_8_cursor);
  (v55_8).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let (v59_12,v59_19,v59_20,v59_21,v59_22,v59_29,v59_30,v59_37,v59_38,v59_39,v59_5,v59_67,v59_68,v59_75,) = native_block_0(c, p0, s1, s2, s3);
  let (v59_112,v59_113,v59_120,v59_127,v59_128,v59_129,v59_157,v59_82,v59_83,v59_84,) = native_block_1(c, s1, s2, s3, &v59_5, &v59_68, &v59_75);
  drop(v59_5);
  let v59_158: Space = unite(&(v59_113),&(v59_157));
  (v59_158).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v189_6 = Space::new();
  let mut v189_6_cursor = (*s0).read_zipper();
  for v189_6_byte in v189_6_cursor.child_mask().iter() {
    v189_6_cursor.descend_to_byte(v189_6_byte);
    let v189_6_tail = v189_6_cursor.make_map();
    v189_6_cursor.ascend(1);
    let v189_6_head = Path::from_slice(&[v189_6_byte]);
    let v190_2: Space = singleton(&(v189_6_head));
    let v190_3: Space = intersect(&(*CONSTANT_11),&(v190_2));
    let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
    drop(v190_3);
    let v190_5: Space = subtract(&(*CONSTANT_0),&(v190_4));
    drop(v190_4);
    let v190_8: Space = if (v190_5).is_empty() { Space::new() } else {
      let v191_6: Path = concat_path(&(*p0),&(v189_6_head));
      let v191_7: Space = routine_8(c, &(v191_6), &(*p1), &(v189_6_tail));
      compose(&(v190_5),&(v191_7))
    };
    drop(v190_5);
    let v190_9: Space = intersect(&(*CONSTANT_11),&(v190_2));
    drop(v190_2);
    let v190_10: Space = if has_head(&(v190_9)) { singleton(&[]) } else { Space::new() };
    drop(v190_9);
    let v190_13: Space = if (v190_10).is_empty() { Space::new() } else {
      let v192_6: Path = concat_path(&(*p0),&(v189_6_head));
      let v192_11: Path = concat_path(&(v192_6),&(*p1));
      drop(v192_6);
      let v192_12: Space = singleton(&(v192_11));
      drop(v192_11);
      compose(&(v190_10),&(v192_12))
    };
    drop(v190_10);
    let v190_14: Space = unite(&(v190_8),&(v190_13));
    drop(v190_13);
    v189_6.join_into((v190_14).clone());
  }
  drop(v189_6_cursor);
  (v189_6).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v193_3: Path = concat_path(&(*p0),&(*p1));
  let v193_4: Space = singleton(&(v193_3));
  drop(v193_3);
  (v193_4).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v194_6 = Space::new();
  let mut v194_6_cursor = (*s0).read_zipper();
  for v194_6_byte in v194_6_cursor.child_mask().iter() {
    v194_6_cursor.descend_to_byte(v194_6_byte);
    let v194_6_tail = v194_6_cursor.make_map();
    v194_6_cursor.ascend(1);
    let v194_6_head = Path::from_slice(&[v194_6_byte]);
    let v195_2: Space = singleton(&(v194_6_head));
    let v195_3: Space = intersect(&(*CONSTANT_11),&(v195_2));
    let v195_4: Space = if has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
    drop(v195_3);
    let v195_5: Space = subtract(&(*CONSTANT_0),&(v195_4));
    drop(v195_4);
    let v195_8: Space = if (v195_5).is_empty() { Space::new() } else {
      let v196_6: Path = concat_path(&(*p0),&(v194_6_head));
      let v196_7: Space = routine_10(c, &(v196_6), &(*p1), &(v194_6_tail));
      compose(&(v195_5),&(v196_7))
    };
    drop(v195_5);
    let v195_9: Space = intersect(&(*CONSTANT_11),&(v195_2));
    drop(v195_2);
    let v195_10: Space = if has_head(&(v195_9)) { singleton(&[]) } else { Space::new() };
    drop(v195_9);
    let v195_13: Space = if (v195_10).is_empty() { Space::new() } else {
      let v197_6: Path = concat_path(&(*p0),&(v194_6_head));
      let v197_11: Path = concat_path(&(v197_6),&(*p1));
      drop(v197_6);
      let v197_12: Space = singleton(&(v197_11));
      drop(v197_11);
      compose(&(v195_10),&(v197_12))
    };
    drop(v195_10);
    let v195_14: Space = unite(&(v195_8),&(v195_13));
    drop(v195_13);
    v194_6.join_into((v195_14).clone());
  }
  drop(v194_6_cursor);
  (v194_6).clone()
}

fn routine_11(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v198_3: Path = concat_path(&(*p0),&(*p1));
  let v198_4: Space = singleton(&(v198_3));
  drop(v198_3);
  (v198_4).clone()
}

fn routine_12(c: &mut Context, s0: &Space, s1: &Space, s2: &Space) -> Space {
  let v199_3: Space = intersect(&(*s1),&(*s2));
  let v199_4: Space = restrict_to(&(*s0),&(v199_3));
  drop(v199_3);
  let mut v199_11 = Space::new();
  let mut v199_11_cursor = (v199_4).read_zipper();
  for v199_11_byte in v199_11_cursor.child_mask().iter() {
    v199_11_cursor.descend_to_byte(v199_11_byte);
    let v199_11_tail = v199_11_cursor.make_map();
    v199_11_cursor.ascend(1);
    let v199_11_head = Path::from_slice(&[v199_11_byte]);
    let v200_2: Space = singleton(&(v199_11_head));
    let v200_3: Space = intersect(&(*CONSTANT_11),&(v200_2));
    let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
    drop(v200_3);
    let v200_5: Space = subtract(&(*CONSTANT_0),&(v200_4));
    drop(v200_4);
    let v200_7: Space = if (v200_5).is_empty() { Space::new() } else {
      let mut v201_6 = Space::new();
      let mut v201_6_cursor = (v199_11_tail).read_zipper();
      for v201_6_byte in v201_6_cursor.child_mask().iter() {
        v201_6_cursor.descend_to_byte(v201_6_byte);
        let v201_6_tail = v201_6_cursor.make_map();
        v201_6_cursor.ascend(1);
        let v201_6_head = Path::from_slice(&[v201_6_byte]);
        let v202_2: Space = singleton(&(v201_6_head));
        let v202_3: Space = intersect(&(*CONSTANT_11),&(v202_2));
        let v202_4: Space = if has_head(&(v202_3)) { singleton(&[]) } else { Space::new() };
        drop(v202_3);
        let v202_5: Space = subtract(&(*CONSTANT_0),&(v202_4));
        drop(v202_4);
        let v202_8: Space = if (v202_5).is_empty() { Space::new() } else {
          let v203_6: Path = concat_path(&(v199_11_head),&(v201_6_head));
          let v203_7: Space = routine_14(c, &(v203_6), &(v201_6_tail));
          compose(&(v202_5),&(v203_7))
        };
        drop(v202_5);
        let v202_9: Space = intersect(&(*CONSTANT_11),&(v202_2));
        drop(v202_2);
        let v202_10: Space = if has_head(&(v202_9)) { singleton(&[]) } else { Space::new() };
        drop(v202_9);
        let v202_12: Space = if (v202_10).is_empty() { Space::new() } else {
          let v204_6: Path = concat_path(&(v199_11_head),&(v201_6_head));
          let v204_11: Space = routine_15(c, &(v204_6), &(v201_6_tail));
          drop(v204_6);
          compose(&(v202_10),&(v204_11))
        };
        drop(v202_10);
        let v202_13: Space = unite(&(v202_8),&(v202_12));
        v201_6.join_into((v202_13).clone());
      }
      drop(v201_6_cursor);
      compose(&(v200_5),&(v201_6))
    };
    drop(v200_5);
    let v200_8: Space = intersect(&(*CONSTANT_11),&(v200_2));
    drop(v200_2);
    let v200_9: Space = if has_head(&(v200_8)) { singleton(&[]) } else { Space::new() };
    drop(v200_8);
    let v200_10: Space = compose(&(v200_9),&(v199_11_tail));
    drop(v200_9);
    let v200_11: Space = unite(&(v200_7),&(v200_10));
    drop(v200_10);
    v199_11.join_into((v200_11).clone());
  }
  drop(v199_11_cursor);
  drop(v199_4);
  let v199_12: Space = unite(&(v199_11),&(*s2));
  let v199_13: Space = intersect(&(v199_12),&(*s1));
  let mut v199_20: Space = (v199_13).clone();
  loop {
    let v205_1: Space = intersect(&(v199_20),&(*s1));
    let v205_2: Space = restrict_to(&(*s0),&(v205_1));
    drop(v205_1);
    let mut v205_3 = Space::new();
    let mut v205_3_cursor = (v205_2).read_zipper();
    for v205_3_byte in v205_3_cursor.child_mask().iter() {
      v205_3_cursor.descend_to_byte(v205_3_byte);
      let v205_3_tail = v205_3_cursor.make_map();
      v205_3_cursor.ascend(1);
      let v205_3_head = Path::from_slice(&[v205_3_byte]);
      let v206_2: Space = singleton(&(v205_3_head));
      let v206_3: Space = intersect(&(*CONSTANT_11),&(v206_2));
      let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
      drop(v206_3);
      let v206_5: Space = subtract(&(*CONSTANT_0),&(v206_4));
      drop(v206_4);
      let v206_7: Space = if (v206_5).is_empty() { Space::new() } else {
        let mut v207_6 = Space::new();
        let mut v207_6_cursor = (v205_3_tail).read_zipper();
        for v207_6_byte in v207_6_cursor.child_mask().iter() {
          v207_6_cursor.descend_to_byte(v207_6_byte);
          let v207_6_tail = v207_6_cursor.make_map();
          v207_6_cursor.ascend(1);
          let v207_6_head = Path::from_slice(&[v207_6_byte]);
          let v208_2: Space = singleton(&(v207_6_head));
          let v208_3: Space = intersect(&(*CONSTANT_11),&(v208_2));
          let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
          drop(v208_3);
          let v208_5: Space = subtract(&(*CONSTANT_0),&(v208_4));
          drop(v208_4);
          let v208_8: Space = if (v208_5).is_empty() { Space::new() } else {
            let v209_6: Path = concat_path(&(v205_3_head),&(v207_6_head));
            let v209_7: Space = routine_14(c, &(v209_6), &(v207_6_tail));
            compose(&(v208_5),&(v209_7))
          };
          drop(v208_5);
          let v208_9: Space = intersect(&(*CONSTANT_11),&(v208_2));
          drop(v208_2);
          let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
          drop(v208_9);
          let v208_12: Space = if (v208_10).is_empty() { Space::new() } else {
            let v210_6: Path = concat_path(&(v205_3_head),&(v207_6_head));
            let v210_11: Space = routine_15(c, &(v210_6), &(v207_6_tail));
            drop(v210_6);
            compose(&(v208_10),&(v210_11))
          };
          drop(v208_10);
          let v208_13: Space = unite(&(v208_8),&(v208_12));
          v207_6.join_into((v208_13).clone());
        }
        drop(v207_6_cursor);
        compose(&(v206_5),&(v207_6))
      };
      drop(v206_5);
      let v206_8: Space = intersect(&(*CONSTANT_11),&(v206_2));
      drop(v206_2);
      let v206_9: Space = if has_head(&(v206_8)) { singleton(&[]) } else { Space::new() };
      drop(v206_8);
      let v206_10: Space = compose(&(v206_9),&(v205_3_tail));
      drop(v206_9);
      let v206_11: Space = unite(&(v206_7),&(v206_10));
      drop(v206_10);
      v205_3.join_into((v206_11).clone());
    }
    drop(v205_3_cursor);
    drop(v205_2);
    let v205_4: Space = unite(&(v205_3),&(v199_20));
    let v205_5: Space = intersect(&(v205_4),&(*s1));
    let v199_20_next = unite(&v199_20,&(v205_5));
    if equal(&v199_20_next,&v199_20) { break; }
    v199_20 = v199_20_next;
  }
  let v199_21: Space = unite(&(*s2),&(v199_20));
  (v199_21).clone()
}

fn routine_13(c: &mut Context, s0: &Space, s1: &Space, s2: &Space) -> Space {
  let v211_3: Space = range(&(*s2),0,1);
  let mut v211_10 = Space::new();
  let mut v211_10_cursor = (v211_3).read_zipper();
  for v211_10_byte in v211_10_cursor.child_mask().iter() {
    v211_10_cursor.descend_to_byte(v211_10_byte);
    let v211_10_tail = v211_10_cursor.make_map();
    v211_10_cursor.ascend(1);
    let v211_10_head = Path::from_slice(&[v211_10_byte]);
    let v212_2: Space = singleton(&(v211_10_head));
    let v212_3: Space = intersect(&(*CONSTANT_11),&(v212_2));
    let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
    drop(v212_3);
    let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
    drop(v212_4);
    let v212_7: Space = if (v212_5).is_empty() { Space::new() } else {
      let mut v213_6 = Space::new();
      let mut v213_6_cursor = (v211_10_tail).read_zipper();
      for v213_6_byte in v213_6_cursor.child_mask().iter() {
        v213_6_cursor.descend_to_byte(v213_6_byte);
        let v213_6_tail = v213_6_cursor.make_map();
        v213_6_cursor.ascend(1);
        let v213_6_head = Path::from_slice(&[v213_6_byte]);
        let v214_2: Space = singleton(&(v213_6_head));
        let v214_3: Space = intersect(&(*CONSTANT_11),&(v214_2));
        let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
        drop(v214_3);
        let v214_5: Space = subtract(&(*CONSTANT_0),&(v214_4));
        drop(v214_4);
        let v214_8: Space = if (v214_5).is_empty() { Space::new() } else {
          let v215_6: Path = concat_path(&(v211_10_head),&(v213_6_head));
          let v215_7: Space = routine_6(c, &(v215_6), &(v213_6_tail), &(*s1), &(*s0), &(*s2));
          compose(&(v214_5),&(v215_7))
        };
        drop(v214_5);
        let v214_9: Space = intersect(&(*CONSTANT_11),&(v214_2));
        drop(v214_2);
        let v214_10: Space = if has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
        drop(v214_9);
        let v214_12: Space = if (v214_10).is_empty() { Space::new() } else {
          let v216_6: Path = concat_path(&(v211_10_head),&(v213_6_head));
          let v216_11: Space = routine_7(c, &(v216_6), &(v213_6_tail), &(*s1), &(*s0), &(*s2));
          drop(v216_6);
          compose(&(v214_10),&(v216_11))
        };
        drop(v214_10);
        let v214_13: Space = unite(&(v214_8),&(v214_12));
        v213_6.join_into((v214_13).clone());
      }
      drop(v213_6_cursor);
      compose(&(v212_5),&(v213_6))
    };
    drop(v212_5);
    let v212_8: Space = intersect(&(*CONSTANT_11),&(v212_2));
    let v212_9: Space = if has_head(&(v212_8)) { singleton(&[]) } else { Space::new() };
    drop(v212_8);
    let v212_25: Space = if (v212_9).is_empty() { Space::new() } else {
      let v217_10: Space = routine_12(c, &(*s1), &(*s2), &(v212_2));
      let v217_11: Space = routine_12(c, &(*s0), &(*s2), &(v212_2));
      let v217_12: Space = intersect(&(v217_10),&(v217_11));
      let v217_13: Space = subtract(&(v217_12),&(v212_2));
      let v217_14: Space = wrap(&(v217_13),&(v211_10_head));
      let v217_15: Space = subtract(&(*s2),&(v217_11));
      let v217_16: Space = subtract(&(v217_15),&(v217_10));
      let v217_17: Space = routine_13(c, &(*s0), &(*s1), &(v217_16));
      let v217_18: Space = unite(&(v217_14),&(v217_17));
      let v217_19: Space = subtract(&(v217_10),&(v217_11));
      let v217_20: Space = routine_13(c, &(*s0), &(*s1), &(v217_19));
      let v217_21: Space = unite(&(v217_18),&(v217_20));
      let v217_22: Space = subtract(&(v217_11),&(v217_10));
      let v217_23: Space = routine_13(c, &(*s0), &(*s1), &(v217_22));
      let v217_24: Space = unite(&(v217_21),&(v217_23));
      compose(&(v212_9),&(v217_24))
    };
    drop(v212_9);
    let v212_26: Space = unite(&(v212_7),&(v212_25));
    v211_10.join_into((v212_26).clone());
  }
  drop(v211_10_cursor);
  drop(v211_3);
  (v211_10).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v218_5 = Space::new();
  let mut v218_5_cursor = (*s0).read_zipper();
  for v218_5_byte in v218_5_cursor.child_mask().iter() {
    v218_5_cursor.descend_to_byte(v218_5_byte);
    let v218_5_tail = v218_5_cursor.make_map();
    v218_5_cursor.ascend(1);
    let v218_5_head = Path::from_slice(&[v218_5_byte]);
    let v219_2: Space = singleton(&(v218_5_head));
    let v219_3: Space = intersect(&(*CONSTANT_11),&(v219_2));
    let v219_4: Space = if has_head(&(v219_3)) { singleton(&[]) } else { Space::new() };
    drop(v219_3);
    let v219_5: Space = subtract(&(*CONSTANT_0),&(v219_4));
    drop(v219_4);
    let v219_8: Space = if (v219_5).is_empty() { Space::new() } else {
      let v220_6: Path = concat_path(&(*p0),&(v218_5_head));
      let v220_7: Space = routine_14(c, &(v220_6), &(v218_5_tail));
      drop(v220_6);
      compose(&(v219_5),&(v220_7))
    };
    drop(v219_5);
    let v219_9: Space = intersect(&(*CONSTANT_11),&(v219_2));
    drop(v219_2);
    let v219_10: Space = if has_head(&(v219_9)) { singleton(&[]) } else { Space::new() };
    drop(v219_9);
    let v219_11: Space = compose(&(v219_10),&(v218_5_tail));
    drop(v219_10);
    let v219_12: Space = unite(&(v219_8),&(v219_11));
    drop(v219_11);
    v218_5.join_into((v219_12).clone());
  }
  drop(v218_5_cursor);
  (v218_5).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
