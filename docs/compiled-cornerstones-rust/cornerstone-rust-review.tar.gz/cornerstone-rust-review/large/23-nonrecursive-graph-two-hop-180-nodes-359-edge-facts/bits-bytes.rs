#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1,0,0,0,1,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let mut v0_12 = Space::new();
  let mut v0_12_cursor = (v0_2).read_zipper();
  for v0_12_byte in v0_12_cursor.child_mask().iter() {
    v0_12_cursor.descend_to_byte(v0_12_byte);
    let v0_12_tail = v0_12_cursor.make_map();
    v0_12_cursor.ascend(1);
    let v0_12_head = Path::from_slice(&[v0_12_byte]);
    let v1_2: Space = singleton(&(v0_12_head));
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_12_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        let v2_6_tail = v2_6_cursor.make_map();
        v2_6_cursor.ascend(1);
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_12_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail), &(*s0.expect("unbound native input")));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_12_head),&(v2_6_head));
          let v5_11: Space = routine_2(c, &(v5_6), &(v2_6_tail), &(*s0.expect("unbound native input")));
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_cursor = (v0_12_tail).read_zipper();
      for v6_10_byte in v6_10_cursor.child_mask().iter() {
        v6_10_cursor.descend_to_byte(v6_10_byte);
        let v6_10_tail = v6_10_cursor.make_map();
        v6_10_cursor.ascend(1);
        let v6_10_head = Path::from_slice(&[v6_10_byte]);
        let v7_2: Space = singleton(&(v6_10_head));
        let v7_3: Space = intersect(&(*CONSTANT_2),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_1),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_12_head),&(v6_10_head));
          let v8_7: Space = routine_1(c, &(v8_6), &(v6_10_tail), &(*s0.expect("unbound native input")));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_2),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v0_12_head),&(v6_10_head));
          let v9_11: Space = routine_3(c, &(v9_6), &(v6_10_tail), &(*s0.expect("unbound native input")));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_10.join_into((v7_13).clone());
      }
      drop(v6_10_cursor);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_12.join_into((v1_12).clone());
  }
  drop(v0_12_cursor);
  drop(v0_2);
  let v0_14: Space = wrap(&(v0_12),&(*CONSTANT_3));
  (v0_14).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v10_12 = Space::new();
  let mut v10_12_cursor = (*s0).read_zipper();
  for v10_12_byte in v10_12_cursor.child_mask().iter() {
    v10_12_cursor.descend_to_byte(v10_12_byte);
    let v10_12_tail = v10_12_cursor.make_map();
    v10_12_cursor.ascend(1);
    let v10_12_head = Path::from_slice(&[v10_12_byte]);
    let v11_2: Space = singleton(&(v10_12_head));
    let v11_3: Space = intersect(&(*CONSTANT_2),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_1),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&(v10_12_head));
      let mut v12_7 = Space::new();
      let mut v12_7_cursor = (v10_12_tail).read_zipper();
      for v12_7_byte in v12_7_cursor.child_mask().iter() {
        v12_7_cursor.descend_to_byte(v12_7_byte);
        let v12_7_tail = v12_7_cursor.make_map();
        v12_7_cursor.ascend(1);
        let v12_7_head = Path::from_slice(&[v12_7_byte]);
        let v13_2: Space = singleton(&(v12_7_head));
        let v13_3: Space = intersect(&(*CONSTANT_2),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_1),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let v14_7: Space = routine_4(c, &(v14_6), &(v12_7_tail), &(*s1));
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_2),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
          let v15_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let v15_11: Space = routine_5(c, &(v15_6), &(v12_7_tail), &(*s1));
          drop(v15_6);
          compose(&(v13_10),&(v15_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        v12_7.join_into((v13_13).clone());
      }
      drop(v12_7_cursor);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_2),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_12: Space = if (v11_10).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v10_12_head));
      let mut v16_11 = Space::new();
      let mut v16_11_cursor = (v10_12_tail).read_zipper();
      for v16_11_byte in v16_11_cursor.child_mask().iter() {
        v16_11_cursor.descend_to_byte(v16_11_byte);
        let v16_11_tail = v16_11_cursor.make_map();
        v16_11_cursor.ascend(1);
        let v16_11_head = Path::from_slice(&[v16_11_byte]);
        let v17_2: Space = singleton(&(v16_11_head));
        let v17_3: Space = intersect(&(*CONSTANT_2),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_1),&(v17_4));
        drop(v17_4);
        let v17_8: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v16_6),&(v16_11_head));
          let v18_7: Space = routine_4(c, &(v18_6), &(v16_11_tail), &(*s1));
          compose(&(v17_5),&(v18_7))
        };
        drop(v17_5);
        let v17_9: Space = intersect(&(*CONSTANT_2),&(v17_2));
        drop(v17_2);
        let v17_10: Space = if has_head(&(v17_9)) { singleton(&[]) } else { Space::new() };
        drop(v17_9);
        let v17_12: Space = if (v17_10).is_empty() { Space::new() } else {
          let v19_6: Path = concat_path(&(v16_6),&(v16_11_head));
          let v19_11: Space = routine_3(c, &(v19_6), &(v16_11_tail), &(*s1));
          drop(v19_6);
          compose(&(v17_10),&(v19_11))
        };
        drop(v17_10);
        let v17_13: Space = unite(&(v17_8),&(v17_12));
        v16_11.join_into((v17_13).clone());
      }
      drop(v16_11_cursor);
      drop(v16_6);
      compose(&(v11_10),&(v16_11))
    };
    drop(v11_10);
    let v11_13: Space = unite(&(v11_8),&(v11_12));
    v10_12.join_into((v11_13).clone());
  }
  drop(v10_12_cursor);
  (v10_12).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v20_12 = Space::new();
  let mut v20_12_cursor = (*s0).read_zipper();
  for v20_12_byte in v20_12_cursor.child_mask().iter() {
    v20_12_cursor.descend_to_byte(v20_12_byte);
    let v20_12_tail = v20_12_cursor.make_map();
    v20_12_cursor.ascend(1);
    let v20_12_head = Path::from_slice(&[v20_12_byte]);
    let v21_2: Space = singleton(&(v20_12_head));
    let v21_3: Space = intersect(&(*CONSTANT_2),&(v21_2));
    let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
    drop(v21_3);
    let v21_5: Space = subtract(&(*CONSTANT_1),&(v21_4));
    drop(v21_4);
    let v21_8: Space = if (v21_5).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&(v20_12_head));
      let mut v22_7 = Space::new();
      let mut v22_7_cursor = (v20_12_tail).read_zipper();
      for v22_7_byte in v22_7_cursor.child_mask().iter() {
        v22_7_cursor.descend_to_byte(v22_7_byte);
        let v22_7_tail = v22_7_cursor.make_map();
        v22_7_cursor.ascend(1);
        let v22_7_head = Path::from_slice(&[v22_7_byte]);
        let v23_2: Space = singleton(&(v22_7_head));
        let v23_3: Space = intersect(&(*CONSTANT_2),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_1),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&(v22_7_head));
          let v24_7: Space = routine_4(c, &(v24_6), &(v22_7_tail), &(*s1));
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_2),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_12: Space = if (v23_10).is_empty() { Space::new() } else {
          let v25_6: Path = concat_path(&(v22_6),&(v22_7_head));
          let v25_11: Space = routine_5(c, &(v25_6), &(v22_7_tail), &(*s1));
          drop(v25_6);
          compose(&(v23_10),&(v25_11))
        };
        drop(v23_10);
        let v23_13: Space = unite(&(v23_8),&(v23_12));
        v22_7.join_into((v23_13).clone());
      }
      drop(v22_7_cursor);
      compose(&(v21_5),&(v22_7))
    };
    drop(v21_5);
    let v21_9: Space = intersect(&(*CONSTANT_2),&(v21_2));
    drop(v21_2);
    let v21_10: Space = if has_head(&(v21_9)) { singleton(&[]) } else { Space::new() };
    drop(v21_9);
    let v21_12: Space = if (v21_10).is_empty() { Space::new() } else {
      let v26_6: Path = concat_path(&(*p0),&(v20_12_head));
      let mut v26_11 = Space::new();
      let mut v26_11_cursor = (v20_12_tail).read_zipper();
      for v26_11_byte in v26_11_cursor.child_mask().iter() {
        v26_11_cursor.descend_to_byte(v26_11_byte);
        let v26_11_tail = v26_11_cursor.make_map();
        v26_11_cursor.ascend(1);
        let v26_11_head = Path::from_slice(&[v26_11_byte]);
        let v27_2: Space = singleton(&(v26_11_head));
        let v27_3: Space = intersect(&(*CONSTANT_2),&(v27_2));
        let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
        drop(v27_3);
        let v27_5: Space = subtract(&(*CONSTANT_1),&(v27_4));
        drop(v27_4);
        let v27_7: Space = if (v27_5).is_empty() { Space::new() } else {
          let v28_6: Space = routine_6(c, &(v26_11_head), &(v26_6), &(v26_11_tail), &(*s1));
          compose(&(v27_5),&(v28_6))
        };
        drop(v27_5);
        let v27_8: Space = intersect(&(*CONSTANT_2),&(v27_2));
        drop(v27_2);
        let v27_9: Space = if has_head(&(v27_8)) { singleton(&[]) } else { Space::new() };
        drop(v27_8);
        let v27_11: Space = if (v27_9).is_empty() { Space::new() } else {
          let v29_10: Space = routine_7(c, &(v26_11_head), &(v26_6), &(v26_11_tail), &(*s1));
          compose(&(v27_9),&(v29_10))
        };
        drop(v27_9);
        let v27_12: Space = unite(&(v27_7),&(v27_11));
        v26_11.join_into((v27_12).clone());
      }
      drop(v26_11_cursor);
      drop(v26_6);
      compose(&(v21_10),&(v26_11))
    };
    drop(v21_10);
    let v21_13: Space = unite(&(v21_8),&(v21_12));
    v20_12.join_into((v21_13).clone());
  }
  drop(v20_12_cursor);
  (v20_12).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v30_12 = Space::new();
  let mut v30_12_cursor = (*s0).read_zipper();
  for v30_12_byte in v30_12_cursor.child_mask().iter() {
    v30_12_cursor.descend_to_byte(v30_12_byte);
    let v30_12_tail = v30_12_cursor.make_map();
    v30_12_cursor.ascend(1);
    let v30_12_head = Path::from_slice(&[v30_12_byte]);
    let v31_2: Space = singleton(&(v30_12_head));
    let v31_3: Space = intersect(&(*CONSTANT_2),&(v31_2));
    let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
    drop(v31_3);
    let v31_5: Space = subtract(&(*CONSTANT_1),&(v31_4));
    drop(v31_4);
    let v31_7: Space = if (v31_5).is_empty() { Space::new() } else {
      let mut v32_6 = Space::new();
      let mut v32_6_cursor = (v30_12_tail).read_zipper();
      for v32_6_byte in v32_6_cursor.child_mask().iter() {
        v32_6_cursor.descend_to_byte(v32_6_byte);
        let v32_6_tail = v32_6_cursor.make_map();
        v32_6_cursor.ascend(1);
        let v32_6_head = Path::from_slice(&[v32_6_byte]);
        let v33_2: Space = singleton(&(v32_6_head));
        let v33_3: Space = intersect(&(*CONSTANT_2),&(v33_2));
        let v33_4: Space = if has_head(&(v33_3)) { singleton(&[]) } else { Space::new() };
        drop(v33_3);
        let v33_5: Space = subtract(&(*CONSTANT_1),&(v33_4));
        drop(v33_4);
        let v33_8: Space = if (v33_5).is_empty() { Space::new() } else {
          let v34_6: Path = concat_path(&(v30_12_head),&(v32_6_head));
          let v34_7: Space = routine_8(c, &(v34_6), &(*p0), &(v32_6_tail), &(*s1));
          compose(&(v33_5),&(v34_7))
        };
        drop(v33_5);
        let v33_9: Space = intersect(&(*CONSTANT_2),&(v33_2));
        drop(v33_2);
        let v33_10: Space = if has_head(&(v33_9)) { singleton(&[]) } else { Space::new() };
        drop(v33_9);
        let v33_12: Space = if (v33_10).is_empty() { Space::new() } else {
          let v35_6: Path = concat_path(&(v30_12_head),&(v32_6_head));
          let v35_11: Space = routine_9(c, &(v35_6), &(*p0), &(v32_6_tail), &(*s1));
          drop(v35_6);
          compose(&(v33_10),&(v35_11))
        };
        drop(v33_10);
        let v33_13: Space = unite(&(v33_8),&(v33_12));
        v32_6.join_into((v33_13).clone());
      }
      drop(v32_6_cursor);
      compose(&(v31_5),&(v32_6))
    };
    drop(v31_5);
    let v31_8: Space = intersect(&(*CONSTANT_2),&(v31_2));
    drop(v31_2);
    let v31_9: Space = if has_head(&(v31_8)) { singleton(&[]) } else { Space::new() };
    drop(v31_8);
    let v31_11: Space = if (v31_9).is_empty() { Space::new() } else {
      let mut v36_10 = Space::new();
      let mut v36_10_cursor = (v30_12_tail).read_zipper();
      for v36_10_byte in v36_10_cursor.child_mask().iter() {
        v36_10_cursor.descend_to_byte(v36_10_byte);
        let v36_10_tail = v36_10_cursor.make_map();
        v36_10_cursor.ascend(1);
        let v36_10_head = Path::from_slice(&[v36_10_byte]);
        let v37_2: Space = singleton(&(v36_10_head));
        let v37_3: Space = intersect(&(*CONSTANT_2),&(v37_2));
        let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
        drop(v37_3);
        let v37_5: Space = subtract(&(*CONSTANT_1),&(v37_4));
        drop(v37_4);
        let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
          let v38_6: Path = concat_path(&(v30_12_head),&(v36_10_head));
          let v38_7: Space = routine_8(c, &(v38_6), &(*p0), &(v36_10_tail), &(*s1));
          compose(&(v37_5),&(v38_7))
        };
        drop(v37_5);
        let v37_9: Space = intersect(&(*CONSTANT_2),&(v37_2));
        drop(v37_2);
        let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
        drop(v37_9);
        let v37_12: Space = if (v37_10).is_empty() { Space::new() } else {
          let v39_6: Path = concat_path(&(v30_12_head),&(v36_10_head));
          let v39_11: Space = routine_10(c, &(v39_6), &(*p0), &(v36_10_tail), &(*s1));
          drop(v39_6);
          compose(&(v37_10),&(v39_11))
        };
        drop(v37_10);
        let v37_13: Space = unite(&(v37_8),&(v37_12));
        v36_10.join_into((v37_13).clone());
      }
      drop(v36_10_cursor);
      compose(&(v31_9),&(v36_10))
    };
    drop(v31_9);
    let v31_12: Space = unite(&(v31_7),&(v31_11));
    v30_12.join_into((v31_12).clone());
  }
  drop(v30_12_cursor);
  (v30_12).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v40_12 = Space::new();
  let mut v40_12_cursor = (*s0).read_zipper();
  for v40_12_byte in v40_12_cursor.child_mask().iter() {
    v40_12_cursor.descend_to_byte(v40_12_byte);
    let v40_12_tail = v40_12_cursor.make_map();
    v40_12_cursor.ascend(1);
    let v40_12_head = Path::from_slice(&[v40_12_byte]);
    let v41_2: Space = singleton(&(v40_12_head));
    let v41_3: Space = intersect(&(*CONSTANT_2),&(v41_2));
    let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
    drop(v41_3);
    let v41_5: Space = subtract(&(*CONSTANT_1),&(v41_4));
    drop(v41_4);
    let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
      let v42_6: Path = concat_path(&(*p0),&(v40_12_head));
      let mut v42_7 = Space::new();
      let mut v42_7_cursor = (v40_12_tail).read_zipper();
      for v42_7_byte in v42_7_cursor.child_mask().iter() {
        v42_7_cursor.descend_to_byte(v42_7_byte);
        let v42_7_tail = v42_7_cursor.make_map();
        v42_7_cursor.ascend(1);
        let v42_7_head = Path::from_slice(&[v42_7_byte]);
        let v43_2: Space = singleton(&(v42_7_head));
        let v43_3: Space = intersect(&(*CONSTANT_2),&(v43_2));
        let v43_4: Space = if has_head(&(v43_3)) { singleton(&[]) } else { Space::new() };
        drop(v43_3);
        let v43_5: Space = subtract(&(*CONSTANT_1),&(v43_4));
        drop(v43_4);
        let v43_8: Space = if (v43_5).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v42_6),&(v42_7_head));
          let v44_7: Space = routine_11(c, &(v44_6), &(v42_7_tail), &(*s1));
          compose(&(v43_5),&(v44_7))
        };
        drop(v43_5);
        let v43_9: Space = intersect(&(*CONSTANT_2),&(v43_2));
        drop(v43_2);
        let v43_10: Space = if has_head(&(v43_9)) { singleton(&[]) } else { Space::new() };
        drop(v43_9);
        let v43_12: Space = if (v43_10).is_empty() { Space::new() } else {
          let v45_6: Path = concat_path(&(v42_6),&(v42_7_head));
          let v45_11: Space = routine_12(c, &(v45_6), &(v42_7_tail), &(*s1));
          drop(v45_6);
          compose(&(v43_10),&(v45_11))
        };
        drop(v43_10);
        let v43_13: Space = unite(&(v43_8),&(v43_12));
        v42_7.join_into((v43_13).clone());
      }
      drop(v42_7_cursor);
      compose(&(v41_5),&(v42_7))
    };
    drop(v41_5);
    let v41_9: Space = intersect(&(*CONSTANT_2),&(v41_2));
    drop(v41_2);
    let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
    drop(v41_9);
    let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&(v40_12_head));
      let mut v46_11 = Space::new();
      let mut v46_11_cursor = (v40_12_tail).read_zipper();
      for v46_11_byte in v46_11_cursor.child_mask().iter() {
        v46_11_cursor.descend_to_byte(v46_11_byte);
        let v46_11_tail = v46_11_cursor.make_map();
        v46_11_cursor.ascend(1);
        let v46_11_head = Path::from_slice(&[v46_11_byte]);
        let v47_2: Space = singleton(&(v46_11_head));
        let v47_3: Space = intersect(&(*CONSTANT_2),&(v47_2));
        let v47_4: Space = if has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = subtract(&(*CONSTANT_1),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (v47_5).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&(v46_11_head));
          let v48_7: Space = routine_11(c, &(v48_6), &(v46_11_tail), &(*s1));
          compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = intersect(&(*CONSTANT_2),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (v47_10).is_empty() { Space::new() } else {
          let v49_6: Path = concat_path(&(v46_6),&(v46_11_head));
          let v49_11: Space = routine_3(c, &(v49_6), &(v46_11_tail), &(*s1));
          drop(v49_6);
          compose(&(v47_10),&(v49_11))
        };
        drop(v47_10);
        let v47_13: Space = unite(&(v47_8),&(v47_12));
        v46_11.join_into((v47_13).clone());
      }
      drop(v46_11_cursor);
      drop(v46_6);
      compose(&(v41_10),&(v46_11))
    };
    drop(v41_10);
    let v41_13: Space = unite(&(v41_8),&(v41_12));
    v40_12.join_into((v41_13).clone());
  }
  drop(v40_12_cursor);
  (v40_12).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v50_12 = Space::new();
  let mut v50_12_cursor = (*s0).read_zipper();
  for v50_12_byte in v50_12_cursor.child_mask().iter() {
    v50_12_cursor.descend_to_byte(v50_12_byte);
    let v50_12_tail = v50_12_cursor.make_map();
    v50_12_cursor.ascend(1);
    let v50_12_head = Path::from_slice(&[v50_12_byte]);
    let v51_2: Space = singleton(&(v50_12_head));
    let v51_3: Space = intersect(&(*CONSTANT_2),&(v51_2));
    let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
    drop(v51_3);
    let v51_5: Space = subtract(&(*CONSTANT_1),&(v51_4));
    drop(v51_4);
    let v51_8: Space = if (v51_5).is_empty() { Space::new() } else {
      let v52_6: Path = concat_path(&(*p0),&(v50_12_head));
      let mut v52_7 = Space::new();
      let mut v52_7_cursor = (v50_12_tail).read_zipper();
      for v52_7_byte in v52_7_cursor.child_mask().iter() {
        v52_7_cursor.descend_to_byte(v52_7_byte);
        let v52_7_tail = v52_7_cursor.make_map();
        v52_7_cursor.ascend(1);
        let v52_7_head = Path::from_slice(&[v52_7_byte]);
        let v53_2: Space = singleton(&(v52_7_head));
        let v53_3: Space = intersect(&(*CONSTANT_2),&(v53_2));
        let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
        drop(v53_3);
        let v53_5: Space = subtract(&(*CONSTANT_1),&(v53_4));
        drop(v53_4);
        let v53_8: Space = if (v53_5).is_empty() { Space::new() } else {
          let v54_6: Path = concat_path(&(v52_6),&(v52_7_head));
          let v54_7: Space = routine_11(c, &(v54_6), &(v52_7_tail), &(*s1));
          compose(&(v53_5),&(v54_7))
        };
        drop(v53_5);
        let v53_9: Space = intersect(&(*CONSTANT_2),&(v53_2));
        drop(v53_2);
        let v53_10: Space = if has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
        drop(v53_9);
        let v53_12: Space = if (v53_10).is_empty() { Space::new() } else {
          let v55_6: Path = concat_path(&(v52_6),&(v52_7_head));
          let v55_11: Space = routine_12(c, &(v55_6), &(v52_7_tail), &(*s1));
          drop(v55_6);
          compose(&(v53_10),&(v55_11))
        };
        drop(v53_10);
        let v53_13: Space = unite(&(v53_8),&(v53_12));
        v52_7.join_into((v53_13).clone());
      }
      drop(v52_7_cursor);
      compose(&(v51_5),&(v52_7))
    };
    drop(v51_5);
    let v51_9: Space = intersect(&(*CONSTANT_2),&(v51_2));
    drop(v51_2);
    let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
    drop(v51_9);
    let v51_12: Space = if (v51_10).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&(v50_12_head));
      let mut v56_11 = Space::new();
      let mut v56_11_cursor = (v50_12_tail).read_zipper();
      for v56_11_byte in v56_11_cursor.child_mask().iter() {
        v56_11_cursor.descend_to_byte(v56_11_byte);
        let v56_11_tail = v56_11_cursor.make_map();
        v56_11_cursor.ascend(1);
        let v56_11_head = Path::from_slice(&[v56_11_byte]);
        let v57_2: Space = singleton(&(v56_11_head));
        let v57_3: Space = intersect(&(*CONSTANT_2),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_1),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (v57_5).is_empty() { Space::new() } else {
          let v58_6: Space = routine_6(c, &(v56_11_head), &(v56_6), &(v56_11_tail), &(*s1));
          compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = intersect(&(*CONSTANT_2),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (v57_9).is_empty() { Space::new() } else {
          let v59_10: Space = routine_7(c, &(v56_11_head), &(v56_6), &(v56_11_tail), &(*s1));
          compose(&(v57_9),&(v59_10))
        };
        drop(v57_9);
        let v57_12: Space = unite(&(v57_7),&(v57_11));
        v56_11.join_into((v57_12).clone());
      }
      drop(v56_11_cursor);
      drop(v56_6);
      compose(&(v51_10),&(v56_11))
    };
    drop(v51_10);
    let v51_13: Space = unite(&(v51_8),&(v51_12));
    v50_12.join_into((v51_13).clone());
  }
  drop(v50_12_cursor);
  (v50_12).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v60_13 = Space::new();
  let mut v60_13_cursor = (*s0).read_zipper();
  for v60_13_byte in v60_13_cursor.child_mask().iter() {
    v60_13_cursor.descend_to_byte(v60_13_byte);
    let v60_13_tail = v60_13_cursor.make_map();
    v60_13_cursor.ascend(1);
    let v60_13_head = Path::from_slice(&[v60_13_byte]);
    let v61_2: Space = singleton(&(v60_13_head));
    let v61_3: Space = intersect(&(*CONSTANT_2),&(v61_2));
    let v61_4: Space = if has_head(&(v61_3)) { singleton(&[]) } else { Space::new() };
    drop(v61_3);
    let v61_5: Space = subtract(&(*CONSTANT_1),&(v61_4));
    drop(v61_4);
    let v61_8: Space = if (v61_5).is_empty() { Space::new() } else {
      let v62_6: Path = concat_path(&(*p0),&(v60_13_head));
      let mut v62_7 = Space::new();
      let mut v62_7_cursor = (v60_13_tail).read_zipper();
      for v62_7_byte in v62_7_cursor.child_mask().iter() {
        v62_7_cursor.descend_to_byte(v62_7_byte);
        let v62_7_tail = v62_7_cursor.make_map();
        v62_7_cursor.ascend(1);
        let v62_7_head = Path::from_slice(&[v62_7_byte]);
        let v63_2: Space = singleton(&(v62_7_head));
        let v63_3: Space = intersect(&(*CONSTANT_2),&(v63_2));
        let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
        drop(v63_3);
        let v63_5: Space = subtract(&(*CONSTANT_1),&(v63_4));
        drop(v63_4);
        let v63_8: Space = if (v63_5).is_empty() { Space::new() } else {
          let v64_6: Path = concat_path(&(v62_6),&(v62_7_head));
          let v64_7: Space = routine_13(c, &(v64_6), &(*p1), &(v62_7_tail), &(*s1));
          compose(&(v63_5),&(v64_7))
        };
        drop(v63_5);
        let v63_9: Space = intersect(&(*CONSTANT_2),&(v63_2));
        drop(v63_2);
        let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
        drop(v63_9);
        let v63_12: Space = if (v63_10).is_empty() { Space::new() } else {
          let v65_6: Path = concat_path(&(v62_6),&(v62_7_head));
          let v65_11: Space = routine_14(c, &(v65_6), &(*p1), &(v62_7_tail), &(*s1));
          drop(v65_6);
          compose(&(v63_10),&(v65_11))
        };
        drop(v63_10);
        let v63_13: Space = unite(&(v63_8),&(v63_12));
        v62_7.join_into((v63_13).clone());
      }
      drop(v62_7_cursor);
      compose(&(v61_5),&(v62_7))
    };
    drop(v61_5);
    let v61_9: Space = intersect(&(*CONSTANT_2),&(v61_2));
    drop(v61_2);
    let v61_10: Space = if has_head(&(v61_9)) { singleton(&[]) } else { Space::new() };
    drop(v61_9);
    let v61_12: Space = if (v61_10).is_empty() { Space::new() } else {
      let v66_6: Path = concat_path(&(*p0),&(v60_13_head));
      let mut v66_11 = Space::new();
      let mut v66_11_cursor = (v60_13_tail).read_zipper();
      for v66_11_byte in v66_11_cursor.child_mask().iter() {
        v66_11_cursor.descend_to_byte(v66_11_byte);
        let v66_11_tail = v66_11_cursor.make_map();
        v66_11_cursor.ascend(1);
        let v66_11_head = Path::from_slice(&[v66_11_byte]);
        let v67_2: Space = singleton(&(v66_11_head));
        let v67_3: Space = intersect(&(*CONSTANT_2),&(v67_2));
        let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
        drop(v67_3);
        let v67_5: Space = subtract(&(*CONSTANT_1),&(v67_4));
        drop(v67_4);
        let v67_8: Space = if (v67_5).is_empty() { Space::new() } else {
          let v68_6: Path = concat_path(&(v66_6),&(v66_11_head));
          let v68_7: Space = routine_13(c, &(v68_6), &(*p1), &(v66_11_tail), &(*s1));
          compose(&(v67_5),&(v68_7))
        };
        drop(v67_5);
        let v67_9: Space = intersect(&(*CONSTANT_2),&(v67_2));
        drop(v67_2);
        let v67_10: Space = if has_head(&(v67_9)) { singleton(&[]) } else { Space::new() };
        drop(v67_9);
        let v67_12: Space = if (v67_10).is_empty() { Space::new() } else {
          let v69_6: Path = concat_path(&(v66_6),&(v66_11_head));
          let v69_11: Space = routine_10(c, &(v69_6), &(*p1), &(v66_11_tail), &(*s1));
          drop(v69_6);
          compose(&(v67_10),&(v69_11))
        };
        drop(v67_10);
        let v67_13: Space = unite(&(v67_8),&(v67_12));
        v66_11.join_into((v67_13).clone());
      }
      drop(v66_11_cursor);
      drop(v66_6);
      compose(&(v61_10),&(v66_11))
    };
    drop(v61_10);
    let v61_13: Space = unite(&(v61_8),&(v61_12));
    v60_13.join_into((v61_13).clone());
  }
  drop(v60_13_cursor);
  (v60_13).clone()
}

fn routine_7(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v70_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v70_9: Space = unwrap(&(v70_8),&(*p0));
  drop(v70_8);
  let mut v70_16 = Space::new();
  let mut v70_16_cursor = (*s0).read_zipper();
  for v70_16_byte in v70_16_cursor.child_mask().iter() {
    v70_16_cursor.descend_to_byte(v70_16_byte);
    let v70_16_tail = v70_16_cursor.make_map();
    v70_16_cursor.ascend(1);
    let v70_16_head = Path::from_slice(&[v70_16_byte]);
    let v71_2: Space = singleton(&(v70_16_head));
    let v71_3: Space = intersect(&(*CONSTANT_2),&(v71_2));
    let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
    drop(v71_3);
    let v71_5: Space = subtract(&(*CONSTANT_1),&(v71_4));
    drop(v71_4);
    let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
      let v72_6: Path = concat_path(&(*p0),&(v70_16_head));
      let mut v72_7 = Space::new();
      let mut v72_7_cursor = (v70_16_tail).read_zipper();
      for v72_7_byte in v72_7_cursor.child_mask().iter() {
        v72_7_cursor.descend_to_byte(v72_7_byte);
        let v72_7_tail = v72_7_cursor.make_map();
        v72_7_cursor.ascend(1);
        let v72_7_head = Path::from_slice(&[v72_7_byte]);
        let v73_2: Space = singleton(&(v72_7_head));
        let v73_3: Space = intersect(&(*CONSTANT_2),&(v73_2));
        let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
        drop(v73_3);
        let v73_5: Space = subtract(&(*CONSTANT_1),&(v73_4));
        drop(v73_4);
        let v73_8: Space = if (v73_5).is_empty() { Space::new() } else {
          let v74_6: Path = concat_path(&(v72_6),&(v72_7_head));
          let v74_7: Space = routine_13(c, &(v74_6), &(*p1), &(v72_7_tail), &(*s1));
          compose(&(v73_5),&(v74_7))
        };
        drop(v73_5);
        let v73_9: Space = intersect(&(*CONSTANT_2),&(v73_2));
        drop(v73_2);
        let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
        drop(v73_9);
        let v73_12: Space = if (v73_10).is_empty() { Space::new() } else {
          let v75_6: Path = concat_path(&(v72_6),&(v72_7_head));
          let v75_11: Space = routine_14(c, &(v75_6), &(*p1), &(v72_7_tail), &(*s1));
          drop(v75_6);
          compose(&(v73_10),&(v75_11))
        };
        drop(v73_10);
        let v73_13: Space = unite(&(v73_8),&(v73_12));
        v72_7.join_into((v73_13).clone());
      }
      drop(v72_7_cursor);
      drop(v72_6);
      compose(&(v71_5),&(v72_7))
    };
    drop(v71_5);
    let v71_9: Space = intersect(&(*CONSTANT_2),&(v71_2));
    drop(v71_2);
    let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
    drop(v71_9);
    let v71_13: Space = if (v71_10).is_empty() { Space::new() } else {
      let v76_11: Space = unwrap(&(v70_9),&(v70_16_head));
      let mut v76_12 = Space::new();
      let mut v76_12_cursor = (v76_11).read_zipper();
      for v76_12_byte in v76_12_cursor.child_mask().iter() {
        v76_12_cursor.descend_to_byte(v76_12_byte);
        let v76_12_tail = v76_12_cursor.make_map();
        v76_12_cursor.ascend(1);
        let v76_12_head = Path::from_slice(&[v76_12_byte]);
        let v77_2: Space = singleton(&(v76_12_head));
        let v77_3: Space = intersect(&(*CONSTANT_2),&(v77_2));
        let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
        drop(v77_3);
        let v77_5: Space = subtract(&(*CONSTANT_1),&(v77_4));
        drop(v77_4);
        let v77_7: Space = if (v77_5).is_empty() { Space::new() } else {
          let v78_6: Space = routine_15(c, &(v76_12_head), &(*p1), &(v76_12_tail));
          compose(&(v77_5),&(v78_6))
        };
        drop(v77_5);
        let v77_8: Space = intersect(&(*CONSTANT_2),&(v77_2));
        drop(v77_2);
        let v77_9: Space = if has_head(&(v77_8)) { singleton(&[]) } else { Space::new() };
        drop(v77_8);
        let v77_11: Space = if (v77_9).is_empty() { Space::new() } else {
          let v79_10: Space = routine_16(c, &(v76_12_head), &(*p1), &(v76_12_tail));
          compose(&(v77_9),&(v79_10))
        };
        drop(v77_9);
        let v77_12: Space = unite(&(v77_7),&(v77_11));
        v76_12.join_into((v77_12).clone());
      }
      drop(v76_12_cursor);
      drop(v76_11);
      compose(&(v71_10),&(v76_12))
    };
    drop(v71_10);
    let v71_14: Space = unite(&(v71_8),&(v71_13));
    v70_16.join_into((v71_14).clone());
  }
  drop(v70_16_cursor);
  drop(v70_9);
  (v70_16).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v80_13 = Space::new();
  let mut v80_13_cursor = (*s0).read_zipper();
  for v80_13_byte in v80_13_cursor.child_mask().iter() {
    v80_13_cursor.descend_to_byte(v80_13_byte);
    let v80_13_tail = v80_13_cursor.make_map();
    v80_13_cursor.ascend(1);
    let v80_13_head = Path::from_slice(&[v80_13_byte]);
    let v81_2: Space = singleton(&(v80_13_head));
    let v81_3: Space = intersect(&(*CONSTANT_2),&(v81_2));
    let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
    drop(v81_3);
    let v81_5: Space = subtract(&(*CONSTANT_1),&(v81_4));
    drop(v81_4);
    let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
      let v82_6: Path = concat_path(&(*p0),&(v80_13_head));
      let mut v82_7 = Space::new();
      let mut v82_7_cursor = (v80_13_tail).read_zipper();
      for v82_7_byte in v82_7_cursor.child_mask().iter() {
        v82_7_cursor.descend_to_byte(v82_7_byte);
        let v82_7_tail = v82_7_cursor.make_map();
        v82_7_cursor.ascend(1);
        let v82_7_head = Path::from_slice(&[v82_7_byte]);
        let v83_2: Space = singleton(&(v82_7_head));
        let v83_3: Space = intersect(&(*CONSTANT_2),&(v83_2));
        let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
        drop(v83_3);
        let v83_5: Space = subtract(&(*CONSTANT_1),&(v83_4));
        drop(v83_4);
        let v83_8: Space = if (v83_5).is_empty() { Space::new() } else {
          let v84_6: Path = concat_path(&(v82_6),&(v82_7_head));
          let v84_7: Space = routine_17(c, &(v84_6), &(*p1), &(v82_7_tail), &(*s1));
          compose(&(v83_5),&(v84_7))
        };
        drop(v83_5);
        let v83_9: Space = intersect(&(*CONSTANT_2),&(v83_2));
        drop(v83_2);
        let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
        drop(v83_9);
        let v83_12: Space = if (v83_10).is_empty() { Space::new() } else {
          let v85_6: Path = concat_path(&(v82_6),&(v82_7_head));
          let v85_11: Space = routine_18(c, &(v85_6), &(*p1), &(v82_7_tail), &(*s1));
          drop(v85_6);
          compose(&(v83_10),&(v85_11))
        };
        drop(v83_10);
        let v83_13: Space = unite(&(v83_8),&(v83_12));
        v82_7.join_into((v83_13).clone());
      }
      drop(v82_7_cursor);
      compose(&(v81_5),&(v82_7))
    };
    drop(v81_5);
    let v81_9: Space = intersect(&(*CONSTANT_2),&(v81_2));
    drop(v81_2);
    let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
    drop(v81_9);
    let v81_12: Space = if (v81_10).is_empty() { Space::new() } else {
      let v86_6: Path = concat_path(&(*p0),&(v80_13_head));
      let mut v86_11 = Space::new();
      let mut v86_11_cursor = (v80_13_tail).read_zipper();
      for v86_11_byte in v86_11_cursor.child_mask().iter() {
        v86_11_cursor.descend_to_byte(v86_11_byte);
        let v86_11_tail = v86_11_cursor.make_map();
        v86_11_cursor.ascend(1);
        let v86_11_head = Path::from_slice(&[v86_11_byte]);
        let v87_2: Space = singleton(&(v86_11_head));
        let v87_3: Space = intersect(&(*CONSTANT_2),&(v87_2));
        let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
        drop(v87_3);
        let v87_5: Space = subtract(&(*CONSTANT_1),&(v87_4));
        drop(v87_4);
        let v87_8: Space = if (v87_5).is_empty() { Space::new() } else {
          let v88_6: Path = concat_path(&(v86_6),&(v86_11_head));
          let v88_7: Space = routine_17(c, &(v88_6), &(*p1), &(v86_11_tail), &(*s1));
          compose(&(v87_5),&(v88_7))
        };
        drop(v87_5);
        let v87_9: Space = intersect(&(*CONSTANT_2),&(v87_2));
        drop(v87_2);
        let v87_10: Space = if has_head(&(v87_9)) { singleton(&[]) } else { Space::new() };
        drop(v87_9);
        let v87_12: Space = if (v87_10).is_empty() { Space::new() } else {
          let v89_6: Path = concat_path(&(v86_6),&(v86_11_head));
          let v89_11: Space = routine_10(c, &(v89_6), &(*p1), &(v86_11_tail), &(*s1));
          drop(v89_6);
          compose(&(v87_10),&(v89_11))
        };
        drop(v87_10);
        let v87_13: Space = unite(&(v87_8),&(v87_12));
        v86_11.join_into((v87_13).clone());
      }
      drop(v86_11_cursor);
      drop(v86_6);
      compose(&(v81_10),&(v86_11))
    };
    drop(v81_10);
    let v81_13: Space = unite(&(v81_8),&(v81_12));
    v80_13.join_into((v81_13).clone());
  }
  drop(v80_13_cursor);
  (v80_13).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v90_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v90_9: Space = unwrap(&(v90_8),&(*p0));
  drop(v90_8);
  let mut v90_16 = Space::new();
  let mut v90_16_cursor = (*s0).read_zipper();
  for v90_16_byte in v90_16_cursor.child_mask().iter() {
    v90_16_cursor.descend_to_byte(v90_16_byte);
    let v90_16_tail = v90_16_cursor.make_map();
    v90_16_cursor.ascend(1);
    let v90_16_head = Path::from_slice(&[v90_16_byte]);
    let v91_2: Space = singleton(&(v90_16_head));
    let v91_3: Space = intersect(&(*CONSTANT_2),&(v91_2));
    let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
    drop(v91_3);
    let v91_5: Space = subtract(&(*CONSTANT_1),&(v91_4));
    drop(v91_4);
    let v91_8: Space = if (v91_5).is_empty() { Space::new() } else {
      let v92_6: Path = concat_path(&(*p0),&(v90_16_head));
      let mut v92_7 = Space::new();
      let mut v92_7_cursor = (v90_16_tail).read_zipper();
      for v92_7_byte in v92_7_cursor.child_mask().iter() {
        v92_7_cursor.descend_to_byte(v92_7_byte);
        let v92_7_tail = v92_7_cursor.make_map();
        v92_7_cursor.ascend(1);
        let v92_7_head = Path::from_slice(&[v92_7_byte]);
        let v93_2: Space = singleton(&(v92_7_head));
        let v93_3: Space = intersect(&(*CONSTANT_2),&(v93_2));
        let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
        drop(v93_3);
        let v93_5: Space = subtract(&(*CONSTANT_1),&(v93_4));
        drop(v93_4);
        let v93_8: Space = if (v93_5).is_empty() { Space::new() } else {
          let v94_6: Path = concat_path(&(v92_6),&(v92_7_head));
          let v94_7: Space = routine_17(c, &(v94_6), &(*p1), &(v92_7_tail), &(*s1));
          compose(&(v93_5),&(v94_7))
        };
        drop(v93_5);
        let v93_9: Space = intersect(&(*CONSTANT_2),&(v93_2));
        drop(v93_2);
        let v93_10: Space = if has_head(&(v93_9)) { singleton(&[]) } else { Space::new() };
        drop(v93_9);
        let v93_12: Space = if (v93_10).is_empty() { Space::new() } else {
          let v95_6: Path = concat_path(&(v92_6),&(v92_7_head));
          let v95_11: Space = routine_18(c, &(v95_6), &(*p1), &(v92_7_tail), &(*s1));
          drop(v95_6);
          compose(&(v93_10),&(v95_11))
        };
        drop(v93_10);
        let v93_13: Space = unite(&(v93_8),&(v93_12));
        v92_7.join_into((v93_13).clone());
      }
      drop(v92_7_cursor);
      drop(v92_6);
      compose(&(v91_5),&(v92_7))
    };
    drop(v91_5);
    let v91_9: Space = intersect(&(*CONSTANT_2),&(v91_2));
    drop(v91_2);
    let v91_10: Space = if has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
    drop(v91_9);
    let v91_13: Space = if (v91_10).is_empty() { Space::new() } else {
      let v96_11: Space = unwrap(&(v90_9),&(v90_16_head));
      let mut v96_12 = Space::new();
      let mut v96_12_cursor = (v96_11).read_zipper();
      for v96_12_byte in v96_12_cursor.child_mask().iter() {
        v96_12_cursor.descend_to_byte(v96_12_byte);
        let v96_12_tail = v96_12_cursor.make_map();
        v96_12_cursor.ascend(1);
        let v96_12_head = Path::from_slice(&[v96_12_byte]);
        let v97_2: Space = singleton(&(v96_12_head));
        let v97_3: Space = intersect(&(*CONSTANT_2),&(v97_2));
        let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
        drop(v97_3);
        let v97_5: Space = subtract(&(*CONSTANT_1),&(v97_4));
        drop(v97_4);
        let v97_7: Space = if (v97_5).is_empty() { Space::new() } else {
          let v98_6: Space = routine_15(c, &(v96_12_head), &(*p1), &(v96_12_tail));
          compose(&(v97_5),&(v98_6))
        };
        drop(v97_5);
        let v97_8: Space = intersect(&(*CONSTANT_2),&(v97_2));
        drop(v97_2);
        let v97_9: Space = if has_head(&(v97_8)) { singleton(&[]) } else { Space::new() };
        drop(v97_8);
        let v97_11: Space = if (v97_9).is_empty() { Space::new() } else {
          let v99_10: Space = routine_16(c, &(v96_12_head), &(*p1), &(v96_12_tail));
          compose(&(v97_9),&(v99_10))
        };
        drop(v97_9);
        let v97_12: Space = unite(&(v97_7),&(v97_11));
        v96_12.join_into((v97_12).clone());
      }
      drop(v96_12_cursor);
      drop(v96_11);
      compose(&(v91_10),&(v96_12))
    };
    drop(v91_10);
    let v91_14: Space = unite(&(v91_8),&(v91_13));
    v90_16.join_into((v91_14).clone());
  }
  drop(v90_16_cursor);
  drop(v90_9);
  (v90_16).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v100_5: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v100_6: Space = unwrap(&(v100_5),&(*p0));
  drop(v100_5);
  let mut v100_16 = Space::new();
  let mut v100_16_cursor = (v100_6).read_zipper();
  for v100_16_byte in v100_16_cursor.child_mask().iter() {
    v100_16_cursor.descend_to_byte(v100_16_byte);
    let v100_16_tail = v100_16_cursor.make_map();
    v100_16_cursor.ascend(1);
    let v100_16_head = Path::from_slice(&[v100_16_byte]);
    let v101_2: Space = singleton(&(v100_16_head));
    let v101_3: Space = intersect(&(*CONSTANT_2),&(v101_2));
    let v101_4: Space = if has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
    drop(v101_3);
    let v101_5: Space = subtract(&(*CONSTANT_1),&(v101_4));
    drop(v101_4);
    let v101_7: Space = if (v101_5).is_empty() { Space::new() } else {
      let mut v102_6 = Space::new();
      let mut v102_6_cursor = (v100_16_tail).read_zipper();
      for v102_6_byte in v102_6_cursor.child_mask().iter() {
        v102_6_cursor.descend_to_byte(v102_6_byte);
        let v102_6_tail = v102_6_cursor.make_map();
        v102_6_cursor.ascend(1);
        let v102_6_head = Path::from_slice(&[v102_6_byte]);
        let v103_2: Space = singleton(&(v102_6_head));
        let v103_3: Space = intersect(&(*CONSTANT_2),&(v103_2));
        let v103_4: Space = if has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
        drop(v103_3);
        let v103_5: Space = subtract(&(*CONSTANT_1),&(v103_4));
        drop(v103_4);
        let v103_8: Space = if (v103_5).is_empty() { Space::new() } else {
          let v104_6: Path = concat_path(&(v100_16_head),&(v102_6_head));
          let v104_7: Space = routine_19(c, &(v104_6), &(*p1), &(v102_6_tail));
          compose(&(v103_5),&(v104_7))
        };
        drop(v103_5);
        let v103_9: Space = intersect(&(*CONSTANT_2),&(v103_2));
        drop(v103_2);
        let v103_10: Space = if has_head(&(v103_9)) { singleton(&[]) } else { Space::new() };
        drop(v103_9);
        let v103_12: Space = if (v103_10).is_empty() { Space::new() } else {
          let v105_6: Path = concat_path(&(v100_16_head),&(v102_6_head));
          let v105_11: Space = routine_20(c, &(v105_6), &(*p1), &(v102_6_tail));
          drop(v105_6);
          compose(&(v103_10),&(v105_11))
        };
        drop(v103_10);
        let v103_13: Space = unite(&(v103_8),&(v103_12));
        v102_6.join_into((v103_13).clone());
      }
      drop(v102_6_cursor);
      compose(&(v101_5),&(v102_6))
    };
    drop(v101_5);
    let v101_8: Space = intersect(&(*CONSTANT_2),&(v101_2));
    drop(v101_2);
    let v101_9: Space = if has_head(&(v101_8)) { singleton(&[]) } else { Space::new() };
    drop(v101_8);
    let v101_11: Space = if (v101_9).is_empty() { Space::new() } else {
      let mut v106_10 = Space::new();
      let mut v106_10_cursor = (v100_16_tail).read_zipper();
      for v106_10_byte in v106_10_cursor.child_mask().iter() {
        v106_10_cursor.descend_to_byte(v106_10_byte);
        let v106_10_tail = v106_10_cursor.make_map();
        v106_10_cursor.ascend(1);
        let v106_10_head = Path::from_slice(&[v106_10_byte]);
        let v107_2: Space = singleton(&(v106_10_head));
        let v107_3: Space = intersect(&(*CONSTANT_2),&(v107_2));
        let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
        drop(v107_3);
        let v107_5: Space = subtract(&(*CONSTANT_1),&(v107_4));
        drop(v107_4);
        let v107_8: Space = if (v107_5).is_empty() { Space::new() } else {
          let v108_6: Path = concat_path(&(v100_16_head),&(v106_10_head));
          let v108_7: Space = routine_19(c, &(v108_6), &(*p1), &(v106_10_tail));
          compose(&(v107_5),&(v108_7))
        };
        drop(v107_5);
        let v107_9: Space = intersect(&(*CONSTANT_2),&(v107_2));
        drop(v107_2);
        let v107_10: Space = if has_head(&(v107_9)) { singleton(&[]) } else { Space::new() };
        drop(v107_9);
        let v107_12: Space = if (v107_10).is_empty() { Space::new() } else {
          let v109_6: Path = concat_path(&(v100_16_head),&(v106_10_head));
          let v109_11: Space = routine_21(c, &(v109_6), &(*p1), &(v106_10_tail));
          drop(v109_6);
          compose(&(v107_10),&(v109_11))
        };
        drop(v107_10);
        let v107_13: Space = unite(&(v107_8),&(v107_12));
        v106_10.join_into((v107_13).clone());
      }
      drop(v106_10_cursor);
      compose(&(v101_9),&(v106_10))
    };
    drop(v101_9);
    let v101_12: Space = unite(&(v101_7),&(v101_11));
    v100_16.join_into((v101_12).clone());
  }
  drop(v100_16_cursor);
  drop(v100_6);
  (v100_16).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v110_12 = Space::new();
  let mut v110_12_cursor = (*s0).read_zipper();
  for v110_12_byte in v110_12_cursor.child_mask().iter() {
    v110_12_cursor.descend_to_byte(v110_12_byte);
    let v110_12_tail = v110_12_cursor.make_map();
    v110_12_cursor.ascend(1);
    let v110_12_head = Path::from_slice(&[v110_12_byte]);
    let v111_2: Space = singleton(&(v110_12_head));
    let v111_3: Space = intersect(&(*CONSTANT_2),&(v111_2));
    let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = subtract(&(*CONSTANT_1),&(v111_4));
    drop(v111_4);
    let v111_8: Space = if (v111_5).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&(v110_12_head));
      let mut v112_7 = Space::new();
      let mut v112_7_cursor = (v110_12_tail).read_zipper();
      for v112_7_byte in v112_7_cursor.child_mask().iter() {
        v112_7_cursor.descend_to_byte(v112_7_byte);
        let v112_7_tail = v112_7_cursor.make_map();
        v112_7_cursor.ascend(1);
        let v112_7_head = Path::from_slice(&[v112_7_byte]);
        let v113_2: Space = singleton(&(v112_7_head));
        let v113_3: Space = intersect(&(*CONSTANT_2),&(v113_2));
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = subtract(&(*CONSTANT_1),&(v113_4));
        drop(v113_4);
        let v113_8: Space = if (v113_5).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v112_6),&(v112_7_head));
          let v114_7: Space = routine_22(c, &(v114_6), &(v112_7_tail), &(*s1));
          compose(&(v113_5),&(v114_7))
        };
        drop(v113_5);
        let v113_9: Space = intersect(&(*CONSTANT_2),&(v113_2));
        drop(v113_2);
        let v113_10: Space = if has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
        drop(v113_9);
        let v113_12: Space = if (v113_10).is_empty() { Space::new() } else {
          let v115_6: Path = concat_path(&(v112_6),&(v112_7_head));
          let v115_11: Space = routine_23(c, &(v115_6), &(v112_7_tail), &(*s1));
          drop(v115_6);
          compose(&(v113_10),&(v115_11))
        };
        drop(v113_10);
        let v113_13: Space = unite(&(v113_8),&(v113_12));
        v112_7.join_into((v113_13).clone());
      }
      drop(v112_7_cursor);
      compose(&(v111_5),&(v112_7))
    };
    drop(v111_5);
    let v111_9: Space = intersect(&(*CONSTANT_2),&(v111_2));
    drop(v111_2);
    let v111_10: Space = if has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
    drop(v111_9);
    let v111_12: Space = if (v111_10).is_empty() { Space::new() } else {
      let v116_6: Path = concat_path(&(*p0),&(v110_12_head));
      let mut v116_11 = Space::new();
      let mut v116_11_cursor = (v110_12_tail).read_zipper();
      for v116_11_byte in v116_11_cursor.child_mask().iter() {
        v116_11_cursor.descend_to_byte(v116_11_byte);
        let v116_11_tail = v116_11_cursor.make_map();
        v116_11_cursor.ascend(1);
        let v116_11_head = Path::from_slice(&[v116_11_byte]);
        let v117_2: Space = singleton(&(v116_11_head));
        let v117_3: Space = intersect(&(*CONSTANT_2),&(v117_2));
        let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
        drop(v117_3);
        let v117_5: Space = subtract(&(*CONSTANT_1),&(v117_4));
        drop(v117_4);
        let v117_8: Space = if (v117_5).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v116_6),&(v116_11_head));
          let v118_7: Space = routine_22(c, &(v118_6), &(v116_11_tail), &(*s1));
          compose(&(v117_5),&(v118_7))
        };
        drop(v117_5);
        let v117_9: Space = intersect(&(*CONSTANT_2),&(v117_2));
        drop(v117_2);
        let v117_10: Space = if has_head(&(v117_9)) { singleton(&[]) } else { Space::new() };
        drop(v117_9);
        let v117_12: Space = if (v117_10).is_empty() { Space::new() } else {
          let v119_6: Path = concat_path(&(v116_6),&(v116_11_head));
          let v119_11: Space = routine_3(c, &(v119_6), &(v116_11_tail), &(*s1));
          drop(v119_6);
          compose(&(v117_10),&(v119_11))
        };
        drop(v117_10);
        let v117_13: Space = unite(&(v117_8),&(v117_12));
        v116_11.join_into((v117_13).clone());
      }
      drop(v116_11_cursor);
      drop(v116_6);
      compose(&(v111_10),&(v116_11))
    };
    drop(v111_10);
    let v111_13: Space = unite(&(v111_8),&(v111_12));
    v110_12.join_into((v111_13).clone());
  }
  drop(v110_12_cursor);
  (v110_12).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v120_12 = Space::new();
  let mut v120_12_cursor = (*s0).read_zipper();
  for v120_12_byte in v120_12_cursor.child_mask().iter() {
    v120_12_cursor.descend_to_byte(v120_12_byte);
    let v120_12_tail = v120_12_cursor.make_map();
    v120_12_cursor.ascend(1);
    let v120_12_head = Path::from_slice(&[v120_12_byte]);
    let v121_2: Space = singleton(&(v120_12_head));
    let v121_3: Space = intersect(&(*CONSTANT_2),&(v121_2));
    let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
    drop(v121_3);
    let v121_5: Space = subtract(&(*CONSTANT_1),&(v121_4));
    drop(v121_4);
    let v121_8: Space = if (v121_5).is_empty() { Space::new() } else {
      let v122_6: Path = concat_path(&(*p0),&(v120_12_head));
      let mut v122_7 = Space::new();
      let mut v122_7_cursor = (v120_12_tail).read_zipper();
      for v122_7_byte in v122_7_cursor.child_mask().iter() {
        v122_7_cursor.descend_to_byte(v122_7_byte);
        let v122_7_tail = v122_7_cursor.make_map();
        v122_7_cursor.ascend(1);
        let v122_7_head = Path::from_slice(&[v122_7_byte]);
        let v123_2: Space = singleton(&(v122_7_head));
        let v123_3: Space = intersect(&(*CONSTANT_2),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_1),&(v123_4));
        drop(v123_4);
        let v123_8: Space = if (v123_5).is_empty() { Space::new() } else {
          let v124_6: Path = concat_path(&(v122_6),&(v122_7_head));
          let v124_7: Space = routine_22(c, &(v124_6), &(v122_7_tail), &(*s1));
          compose(&(v123_5),&(v124_7))
        };
        drop(v123_5);
        let v123_9: Space = intersect(&(*CONSTANT_2),&(v123_2));
        drop(v123_2);
        let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
        drop(v123_9);
        let v123_12: Space = if (v123_10).is_empty() { Space::new() } else {
          let v125_6: Path = concat_path(&(v122_6),&(v122_7_head));
          let v125_11: Space = routine_23(c, &(v125_6), &(v122_7_tail), &(*s1));
          drop(v125_6);
          compose(&(v123_10),&(v125_11))
        };
        drop(v123_10);
        let v123_13: Space = unite(&(v123_8),&(v123_12));
        v122_7.join_into((v123_13).clone());
      }
      drop(v122_7_cursor);
      compose(&(v121_5),&(v122_7))
    };
    drop(v121_5);
    let v121_9: Space = intersect(&(*CONSTANT_2),&(v121_2));
    drop(v121_2);
    let v121_10: Space = if has_head(&(v121_9)) { singleton(&[]) } else { Space::new() };
    drop(v121_9);
    let v121_12: Space = if (v121_10).is_empty() { Space::new() } else {
      let v126_6: Path = concat_path(&(*p0),&(v120_12_head));
      let mut v126_11 = Space::new();
      let mut v126_11_cursor = (v120_12_tail).read_zipper();
      for v126_11_byte in v126_11_cursor.child_mask().iter() {
        v126_11_cursor.descend_to_byte(v126_11_byte);
        let v126_11_tail = v126_11_cursor.make_map();
        v126_11_cursor.ascend(1);
        let v126_11_head = Path::from_slice(&[v126_11_byte]);
        let v127_2: Space = singleton(&(v126_11_head));
        let v127_3: Space = intersect(&(*CONSTANT_2),&(v127_2));
        let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
        drop(v127_3);
        let v127_5: Space = subtract(&(*CONSTANT_1),&(v127_4));
        drop(v127_4);
        let v127_7: Space = if (v127_5).is_empty() { Space::new() } else {
          let v128_6: Space = routine_6(c, &(v126_11_head), &(v126_6), &(v126_11_tail), &(*s1));
          compose(&(v127_5),&(v128_6))
        };
        drop(v127_5);
        let v127_8: Space = intersect(&(*CONSTANT_2),&(v127_2));
        drop(v127_2);
        let v127_9: Space = if has_head(&(v127_8)) { singleton(&[]) } else { Space::new() };
        drop(v127_8);
        let v127_11: Space = if (v127_9).is_empty() { Space::new() } else {
          let v129_10: Space = routine_7(c, &(v126_11_head), &(v126_6), &(v126_11_tail), &(*s1));
          compose(&(v127_9),&(v129_10))
        };
        drop(v127_9);
        let v127_12: Space = unite(&(v127_7),&(v127_11));
        v126_11.join_into((v127_12).clone());
      }
      drop(v126_11_cursor);
      drop(v126_6);
      compose(&(v121_10),&(v126_11))
    };
    drop(v121_10);
    let v121_13: Space = unite(&(v121_8),&(v121_12));
    v120_12.join_into((v121_13).clone());
  }
  drop(v120_12_cursor);
  (v120_12).clone()
}

fn routine_13(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v130_13 = Space::new();
  let mut v130_13_cursor = (*s0).read_zipper();
  for v130_13_byte in v130_13_cursor.child_mask().iter() {
    v130_13_cursor.descend_to_byte(v130_13_byte);
    let v130_13_tail = v130_13_cursor.make_map();
    v130_13_cursor.ascend(1);
    let v130_13_head = Path::from_slice(&[v130_13_byte]);
    let v131_2: Space = singleton(&(v130_13_head));
    let v131_3: Space = intersect(&(*CONSTANT_2),&(v131_2));
    let v131_4: Space = if has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
    drop(v131_3);
    let v131_5: Space = subtract(&(*CONSTANT_1),&(v131_4));
    drop(v131_4);
    let v131_8: Space = if (v131_5).is_empty() { Space::new() } else {
      let v132_6: Path = concat_path(&(*p0),&(v130_13_head));
      let mut v132_7 = Space::new();
      let mut v132_7_cursor = (v130_13_tail).read_zipper();
      for v132_7_byte in v132_7_cursor.child_mask().iter() {
        v132_7_cursor.descend_to_byte(v132_7_byte);
        let v132_7_tail = v132_7_cursor.make_map();
        v132_7_cursor.ascend(1);
        let v132_7_head = Path::from_slice(&[v132_7_byte]);
        let v133_2: Space = singleton(&(v132_7_head));
        let v133_3: Space = intersect(&(*CONSTANT_2),&(v133_2));
        let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
        drop(v133_3);
        let v133_5: Space = subtract(&(*CONSTANT_1),&(v133_4));
        drop(v133_4);
        let v133_8: Space = if (v133_5).is_empty() { Space::new() } else {
          let v134_6: Path = concat_path(&(v132_6),&(v132_7_head));
          let v134_7: Space = routine_24(c, &(v134_6), &(*p1), &(v132_7_tail), &(*s1));
          compose(&(v133_5),&(v134_7))
        };
        drop(v133_5);
        let v133_9: Space = intersect(&(*CONSTANT_2),&(v133_2));
        drop(v133_2);
        let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
        drop(v133_9);
        let v133_12: Space = if (v133_10).is_empty() { Space::new() } else {
          let v135_6: Path = concat_path(&(v132_6),&(v132_7_head));
          let v135_11: Space = routine_25(c, &(v135_6), &(*p1), &(v132_7_tail), &(*s1));
          drop(v135_6);
          compose(&(v133_10),&(v135_11))
        };
        drop(v133_10);
        let v133_13: Space = unite(&(v133_8),&(v133_12));
        v132_7.join_into((v133_13).clone());
      }
      drop(v132_7_cursor);
      compose(&(v131_5),&(v132_7))
    };
    drop(v131_5);
    let v131_9: Space = intersect(&(*CONSTANT_2),&(v131_2));
    drop(v131_2);
    let v131_10: Space = if has_head(&(v131_9)) { singleton(&[]) } else { Space::new() };
    drop(v131_9);
    let v131_12: Space = if (v131_10).is_empty() { Space::new() } else {
      let v136_6: Path = concat_path(&(*p0),&(v130_13_head));
      let mut v136_11 = Space::new();
      let mut v136_11_cursor = (v130_13_tail).read_zipper();
      for v136_11_byte in v136_11_cursor.child_mask().iter() {
        v136_11_cursor.descend_to_byte(v136_11_byte);
        let v136_11_tail = v136_11_cursor.make_map();
        v136_11_cursor.ascend(1);
        let v136_11_head = Path::from_slice(&[v136_11_byte]);
        let v137_2: Space = singleton(&(v136_11_head));
        let v137_3: Space = intersect(&(*CONSTANT_2),&(v137_2));
        let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
        drop(v137_3);
        let v137_5: Space = subtract(&(*CONSTANT_1),&(v137_4));
        drop(v137_4);
        let v137_8: Space = if (v137_5).is_empty() { Space::new() } else {
          let v138_6: Path = concat_path(&(v136_6),&(v136_11_head));
          let v138_7: Space = routine_24(c, &(v138_6), &(*p1), &(v136_11_tail), &(*s1));
          compose(&(v137_5),&(v138_7))
        };
        drop(v137_5);
        let v137_9: Space = intersect(&(*CONSTANT_2),&(v137_2));
        drop(v137_2);
        let v137_10: Space = if has_head(&(v137_9)) { singleton(&[]) } else { Space::new() };
        drop(v137_9);
        let v137_12: Space = if (v137_10).is_empty() { Space::new() } else {
          let v139_6: Path = concat_path(&(v136_6),&(v136_11_head));
          let v139_11: Space = routine_10(c, &(v139_6), &(*p1), &(v136_11_tail), &(*s1));
          drop(v139_6);
          compose(&(v137_10),&(v139_11))
        };
        drop(v137_10);
        let v137_13: Space = unite(&(v137_8),&(v137_12));
        v136_11.join_into((v137_13).clone());
      }
      drop(v136_11_cursor);
      drop(v136_6);
      compose(&(v131_10),&(v136_11))
    };
    drop(v131_10);
    let v131_13: Space = unite(&(v131_8),&(v131_12));
    v130_13.join_into((v131_13).clone());
  }
  drop(v130_13_cursor);
  (v130_13).clone()
}

fn routine_14(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v140_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v140_9: Space = unwrap(&(v140_8),&(*p0));
  drop(v140_8);
  let mut v140_16 = Space::new();
  let mut v140_16_cursor = (*s0).read_zipper();
  for v140_16_byte in v140_16_cursor.child_mask().iter() {
    v140_16_cursor.descend_to_byte(v140_16_byte);
    let v140_16_tail = v140_16_cursor.make_map();
    v140_16_cursor.ascend(1);
    let v140_16_head = Path::from_slice(&[v140_16_byte]);
    let v141_2: Space = singleton(&(v140_16_head));
    let v141_3: Space = intersect(&(*CONSTANT_2),&(v141_2));
    let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
    drop(v141_3);
    let v141_5: Space = subtract(&(*CONSTANT_1),&(v141_4));
    drop(v141_4);
    let v141_8: Space = if (v141_5).is_empty() { Space::new() } else {
      let v142_6: Path = concat_path(&(*p0),&(v140_16_head));
      let mut v142_7 = Space::new();
      let mut v142_7_cursor = (v140_16_tail).read_zipper();
      for v142_7_byte in v142_7_cursor.child_mask().iter() {
        v142_7_cursor.descend_to_byte(v142_7_byte);
        let v142_7_tail = v142_7_cursor.make_map();
        v142_7_cursor.ascend(1);
        let v142_7_head = Path::from_slice(&[v142_7_byte]);
        let v143_2: Space = singleton(&(v142_7_head));
        let v143_3: Space = intersect(&(*CONSTANT_2),&(v143_2));
        let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
        drop(v143_3);
        let v143_5: Space = subtract(&(*CONSTANT_1),&(v143_4));
        drop(v143_4);
        let v143_8: Space = if (v143_5).is_empty() { Space::new() } else {
          let v144_6: Path = concat_path(&(v142_6),&(v142_7_head));
          let v144_7: Space = routine_24(c, &(v144_6), &(*p1), &(v142_7_tail), &(*s1));
          compose(&(v143_5),&(v144_7))
        };
        drop(v143_5);
        let v143_9: Space = intersect(&(*CONSTANT_2),&(v143_2));
        drop(v143_2);
        let v143_10: Space = if has_head(&(v143_9)) { singleton(&[]) } else { Space::new() };
        drop(v143_9);
        let v143_12: Space = if (v143_10).is_empty() { Space::new() } else {
          let v145_6: Path = concat_path(&(v142_6),&(v142_7_head));
          let v145_11: Space = routine_25(c, &(v145_6), &(*p1), &(v142_7_tail), &(*s1));
          drop(v145_6);
          compose(&(v143_10),&(v145_11))
        };
        drop(v143_10);
        let v143_13: Space = unite(&(v143_8),&(v143_12));
        v142_7.join_into((v143_13).clone());
      }
      drop(v142_7_cursor);
      drop(v142_6);
      compose(&(v141_5),&(v142_7))
    };
    drop(v141_5);
    let v141_9: Space = intersect(&(*CONSTANT_2),&(v141_2));
    drop(v141_2);
    let v141_10: Space = if has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
    drop(v141_9);
    let v141_13: Space = if (v141_10).is_empty() { Space::new() } else {
      let v146_11: Space = unwrap(&(v140_9),&(v140_16_head));
      let mut v146_12 = Space::new();
      let mut v146_12_cursor = (v146_11).read_zipper();
      for v146_12_byte in v146_12_cursor.child_mask().iter() {
        v146_12_cursor.descend_to_byte(v146_12_byte);
        let v146_12_tail = v146_12_cursor.make_map();
        v146_12_cursor.ascend(1);
        let v146_12_head = Path::from_slice(&[v146_12_byte]);
        let v147_2: Space = singleton(&(v146_12_head));
        let v147_3: Space = intersect(&(*CONSTANT_2),&(v147_2));
        let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
        drop(v147_3);
        let v147_5: Space = subtract(&(*CONSTANT_1),&(v147_4));
        drop(v147_4);
        let v147_7: Space = if (v147_5).is_empty() { Space::new() } else {
          let v148_6: Space = routine_15(c, &(v146_12_head), &(*p1), &(v146_12_tail));
          compose(&(v147_5),&(v148_6))
        };
        drop(v147_5);
        let v147_8: Space = intersect(&(*CONSTANT_2),&(v147_2));
        drop(v147_2);
        let v147_9: Space = if has_head(&(v147_8)) { singleton(&[]) } else { Space::new() };
        drop(v147_8);
        let v147_11: Space = if (v147_9).is_empty() { Space::new() } else {
          let v149_10: Space = routine_16(c, &(v146_12_head), &(*p1), &(v146_12_tail));
          compose(&(v147_9),&(v149_10))
        };
        drop(v147_9);
        let v147_12: Space = unite(&(v147_7),&(v147_11));
        v146_12.join_into((v147_12).clone());
      }
      drop(v146_12_cursor);
      drop(v146_11);
      compose(&(v141_10),&(v146_12))
    };
    drop(v141_10);
    let v141_14: Space = unite(&(v141_8),&(v141_13));
    v140_16.join_into((v141_14).clone());
  }
  drop(v140_16_cursor);
  drop(v140_9);
  (v140_16).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v150_12 = Space::new();
  let mut v150_12_cursor = (*s0).read_zipper();
  for v150_12_byte in v150_12_cursor.child_mask().iter() {
    v150_12_cursor.descend_to_byte(v150_12_byte);
    let v150_12_tail = v150_12_cursor.make_map();
    v150_12_cursor.ascend(1);
    let v150_12_head = Path::from_slice(&[v150_12_byte]);
    let v151_2: Space = singleton(&(v150_12_head));
    let v151_3: Space = intersect(&(*CONSTANT_2),&(v151_2));
    let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
    drop(v151_3);
    let v151_5: Space = subtract(&(*CONSTANT_1),&(v151_4));
    drop(v151_4);
    let v151_8: Space = if (v151_5).is_empty() { Space::new() } else {
      let v152_6: Path = concat_path(&(*p0),&(v150_12_head));
      let mut v152_7 = Space::new();
      let mut v152_7_cursor = (v150_12_tail).read_zipper();
      for v152_7_byte in v152_7_cursor.child_mask().iter() {
        v152_7_cursor.descend_to_byte(v152_7_byte);
        let v152_7_tail = v152_7_cursor.make_map();
        v152_7_cursor.ascend(1);
        let v152_7_head = Path::from_slice(&[v152_7_byte]);
        let v153_2: Space = singleton(&(v152_7_head));
        let v153_3: Space = intersect(&(*CONSTANT_2),&(v153_2));
        let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
        drop(v153_3);
        let v153_5: Space = subtract(&(*CONSTANT_1),&(v153_4));
        drop(v153_4);
        let v153_8: Space = if (v153_5).is_empty() { Space::new() } else {
          let v154_6: Path = concat_path(&(v152_6),&(v152_7_head));
          let v154_7: Space = routine_26(c, &(v154_6), &(*p1), &(v152_7_tail));
          compose(&(v153_5),&(v154_7))
        };
        drop(v153_5);
        let v153_9: Space = intersect(&(*CONSTANT_2),&(v153_2));
        drop(v153_2);
        let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
        drop(v153_9);
        let v153_12: Space = if (v153_10).is_empty() { Space::new() } else {
          let v155_6: Path = concat_path(&(v152_6),&(v152_7_head));
          let v155_11: Space = routine_27(c, &(v155_6), &(*p1), &(v152_7_tail));
          drop(v155_6);
          compose(&(v153_10),&(v155_11))
        };
        drop(v153_10);
        let v153_13: Space = unite(&(v153_8),&(v153_12));
        v152_7.join_into((v153_13).clone());
      }
      drop(v152_7_cursor);
      compose(&(v151_5),&(v152_7))
    };
    drop(v151_5);
    let v151_9: Space = intersect(&(*CONSTANT_2),&(v151_2));
    drop(v151_2);
    let v151_10: Space = if has_head(&(v151_9)) { singleton(&[]) } else { Space::new() };
    drop(v151_9);
    let v151_12: Space = if (v151_10).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&(v150_12_head));
      let mut v156_11 = Space::new();
      let mut v156_11_cursor = (v150_12_tail).read_zipper();
      for v156_11_byte in v156_11_cursor.child_mask().iter() {
        v156_11_cursor.descend_to_byte(v156_11_byte);
        let v156_11_tail = v156_11_cursor.make_map();
        v156_11_cursor.ascend(1);
        let v156_11_head = Path::from_slice(&[v156_11_byte]);
        let v157_2: Space = singleton(&(v156_11_head));
        let v157_3: Space = intersect(&(*CONSTANT_2),&(v157_2));
        let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = subtract(&(*CONSTANT_1),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&(v156_11_head));
          let v158_7: Space = routine_26(c, &(v158_6), &(*p1), &(v156_11_tail));
          compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = intersect(&(*CONSTANT_2),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
          let v159_6: Path = concat_path(&(v156_6),&(v156_11_head));
          let v159_11: Space = routine_21(c, &(v159_6), &(*p1), &(v156_11_tail));
          drop(v159_6);
          compose(&(v157_10),&(v159_11))
        };
        drop(v157_10);
        let v157_13: Space = unite(&(v157_8),&(v157_12));
        v156_11.join_into((v157_13).clone());
      }
      drop(v156_11_cursor);
      drop(v156_6);
      compose(&(v151_10),&(v156_11))
    };
    drop(v151_10);
    let v151_13: Space = unite(&(v151_8),&(v151_12));
    v150_12.join_into((v151_13).clone());
  }
  drop(v150_12_cursor);
  (v150_12).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v160_9 = Space::new();
  let mut v160_9_cursor = (*s0).read_zipper();
  for v160_9_byte in v160_9_cursor.child_mask().iter() {
    v160_9_cursor.descend_to_byte(v160_9_byte);
    let v160_9_tail = v160_9_cursor.make_map();
    v160_9_cursor.ascend(1);
    let v160_9_head = Path::from_slice(&[v160_9_byte]);
    let v161_2: Space = singleton(&(v160_9_head));
    let v161_3: Space = intersect(&(*CONSTANT_2),&(v161_2));
    let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
    drop(v161_3);
    let v161_5: Space = subtract(&(*CONSTANT_1),&(v161_4));
    drop(v161_4);
    let v161_8: Space = if (v161_5).is_empty() { Space::new() } else {
      let v162_6: Path = concat_path(&(*p0),&(v160_9_head));
      let mut v162_7 = Space::new();
      let mut v162_7_cursor = (v160_9_tail).read_zipper();
      for v162_7_byte in v162_7_cursor.child_mask().iter() {
        v162_7_cursor.descend_to_byte(v162_7_byte);
        let v162_7_tail = v162_7_cursor.make_map();
        v162_7_cursor.ascend(1);
        let v162_7_head = Path::from_slice(&[v162_7_byte]);
        let v163_2: Space = singleton(&(v162_7_head));
        let v163_3: Space = intersect(&(*CONSTANT_2),&(v163_2));
        let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
        drop(v163_3);
        let v163_5: Space = subtract(&(*CONSTANT_1),&(v163_4));
        drop(v163_4);
        let v163_8: Space = if (v163_5).is_empty() { Space::new() } else {
          let v164_6: Path = concat_path(&(v162_6),&(v162_7_head));
          let v164_7: Space = routine_26(c, &(v164_6), &(*p1), &(v162_7_tail));
          compose(&(v163_5),&(v164_7))
        };
        drop(v163_5);
        let v163_9: Space = intersect(&(*CONSTANT_2),&(v163_2));
        drop(v163_2);
        let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
        drop(v163_9);
        let v163_12: Space = if (v163_10).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v162_6),&(v162_7_head));
          let v165_11: Space = routine_27(c, &(v165_6), &(*p1), &(v162_7_tail));
          drop(v165_6);
          compose(&(v163_10),&(v165_11))
        };
        drop(v163_10);
        let v163_13: Space = unite(&(v163_8),&(v163_12));
        v162_7.join_into((v163_13).clone());
      }
      drop(v162_7_cursor);
      compose(&(v161_5),&(v162_7))
    };
    drop(v161_5);
    let v161_9: Space = intersect(&(*CONSTANT_2),&(v161_2));
    drop(v161_2);
    let v161_10: Space = if has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
    drop(v161_9);
    let v161_11: Space = compose(&(v161_10),&(v160_9_tail));
    drop(v161_10);
    let v166_6: Path = concat_path(&(*p0),&(v160_9_head));
    let v161_12: Space = wrap(&(v161_11),&(v166_6));
    drop(v161_11);
    let v161_13: Space = wrap(&(v161_12),&(*p1));
    drop(v161_12);
    let v161_14: Space = unite(&(v161_8),&(v161_13));
    drop(v161_13);
    v160_9.join_into((v161_14).clone());
  }
  drop(v160_9_cursor);
  (v160_9).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v167_13 = Space::new();
  let mut v167_13_cursor = (*s0).read_zipper();
  for v167_13_byte in v167_13_cursor.child_mask().iter() {
    v167_13_cursor.descend_to_byte(v167_13_byte);
    let v167_13_tail = v167_13_cursor.make_map();
    v167_13_cursor.ascend(1);
    let v167_13_head = Path::from_slice(&[v167_13_byte]);
    let v168_2: Space = singleton(&(v167_13_head));
    let v168_3: Space = intersect(&(*CONSTANT_2),&(v168_2));
    let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
    drop(v168_3);
    let v168_5: Space = subtract(&(*CONSTANT_1),&(v168_4));
    drop(v168_4);
    let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
      let v169_6: Path = concat_path(&(*p0),&(v167_13_head));
      let mut v169_7 = Space::new();
      let mut v169_7_cursor = (v167_13_tail).read_zipper();
      for v169_7_byte in v169_7_cursor.child_mask().iter() {
        v169_7_cursor.descend_to_byte(v169_7_byte);
        let v169_7_tail = v169_7_cursor.make_map();
        v169_7_cursor.ascend(1);
        let v169_7_head = Path::from_slice(&[v169_7_byte]);
        let v170_2: Space = singleton(&(v169_7_head));
        let v170_3: Space = intersect(&(*CONSTANT_2),&(v170_2));
        let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
        drop(v170_3);
        let v170_5: Space = subtract(&(*CONSTANT_1),&(v170_4));
        drop(v170_4);
        let v170_8: Space = if (v170_5).is_empty() { Space::new() } else {
          let v171_6: Path = concat_path(&(v169_6),&(v169_7_head));
          let v171_7: Space = routine_28(c, &(v171_6), &(*p1), &(v169_7_tail), &(*s1));
          compose(&(v170_5),&(v171_7))
        };
        drop(v170_5);
        let v170_9: Space = intersect(&(*CONSTANT_2),&(v170_2));
        drop(v170_2);
        let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
        drop(v170_9);
        let v170_12: Space = if (v170_10).is_empty() { Space::new() } else {
          let v172_6: Path = concat_path(&(v169_6),&(v169_7_head));
          let v172_11: Space = routine_29(c, &(v172_6), &(*p1), &(v169_7_tail), &(*s1));
          drop(v172_6);
          compose(&(v170_10),&(v172_11))
        };
        drop(v170_10);
        let v170_13: Space = unite(&(v170_8),&(v170_12));
        v169_7.join_into((v170_13).clone());
      }
      drop(v169_7_cursor);
      compose(&(v168_5),&(v169_7))
    };
    drop(v168_5);
    let v168_9: Space = intersect(&(*CONSTANT_2),&(v168_2));
    drop(v168_2);
    let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
    drop(v168_9);
    let v168_12: Space = if (v168_10).is_empty() { Space::new() } else {
      let v173_6: Path = concat_path(&(*p0),&(v167_13_head));
      let mut v173_11 = Space::new();
      let mut v173_11_cursor = (v167_13_tail).read_zipper();
      for v173_11_byte in v173_11_cursor.child_mask().iter() {
        v173_11_cursor.descend_to_byte(v173_11_byte);
        let v173_11_tail = v173_11_cursor.make_map();
        v173_11_cursor.ascend(1);
        let v173_11_head = Path::from_slice(&[v173_11_byte]);
        let v174_2: Space = singleton(&(v173_11_head));
        let v174_3: Space = intersect(&(*CONSTANT_2),&(v174_2));
        let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
        drop(v174_3);
        let v174_5: Space = subtract(&(*CONSTANT_1),&(v174_4));
        drop(v174_4);
        let v174_8: Space = if (v174_5).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v173_6),&(v173_11_head));
          let v175_7: Space = routine_28(c, &(v175_6), &(*p1), &(v173_11_tail), &(*s1));
          compose(&(v174_5),&(v175_7))
        };
        drop(v174_5);
        let v174_9: Space = intersect(&(*CONSTANT_2),&(v174_2));
        drop(v174_2);
        let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
        drop(v174_9);
        let v174_12: Space = if (v174_10).is_empty() { Space::new() } else {
          let v176_6: Path = concat_path(&(v173_6),&(v173_11_head));
          let v176_11: Space = routine_10(c, &(v176_6), &(*p1), &(v173_11_tail), &(*s1));
          drop(v176_6);
          compose(&(v174_10),&(v176_11))
        };
        drop(v174_10);
        let v174_13: Space = unite(&(v174_8),&(v174_12));
        v173_11.join_into((v174_13).clone());
      }
      drop(v173_11_cursor);
      drop(v173_6);
      compose(&(v168_10),&(v173_11))
    };
    drop(v168_10);
    let v168_13: Space = unite(&(v168_8),&(v168_12));
    v167_13.join_into((v168_13).clone());
  }
  drop(v167_13_cursor);
  (v167_13).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v177_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v177_9: Space = unwrap(&(v177_8),&(*p0));
  drop(v177_8);
  let mut v177_16 = Space::new();
  let mut v177_16_cursor = (*s0).read_zipper();
  for v177_16_byte in v177_16_cursor.child_mask().iter() {
    v177_16_cursor.descend_to_byte(v177_16_byte);
    let v177_16_tail = v177_16_cursor.make_map();
    v177_16_cursor.ascend(1);
    let v177_16_head = Path::from_slice(&[v177_16_byte]);
    let v178_2: Space = singleton(&(v177_16_head));
    let v178_3: Space = intersect(&(*CONSTANT_2),&(v178_2));
    let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
    drop(v178_3);
    let v178_5: Space = subtract(&(*CONSTANT_1),&(v178_4));
    drop(v178_4);
    let v178_8: Space = if (v178_5).is_empty() { Space::new() } else {
      let v179_6: Path = concat_path(&(*p0),&(v177_16_head));
      let mut v179_7 = Space::new();
      let mut v179_7_cursor = (v177_16_tail).read_zipper();
      for v179_7_byte in v179_7_cursor.child_mask().iter() {
        v179_7_cursor.descend_to_byte(v179_7_byte);
        let v179_7_tail = v179_7_cursor.make_map();
        v179_7_cursor.ascend(1);
        let v179_7_head = Path::from_slice(&[v179_7_byte]);
        let v180_2: Space = singleton(&(v179_7_head));
        let v180_3: Space = intersect(&(*CONSTANT_2),&(v180_2));
        let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
        drop(v180_3);
        let v180_5: Space = subtract(&(*CONSTANT_1),&(v180_4));
        drop(v180_4);
        let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v181_7: Space = routine_28(c, &(v181_6), &(*p1), &(v179_7_tail), &(*s1));
          compose(&(v180_5),&(v181_7))
        };
        drop(v180_5);
        let v180_9: Space = intersect(&(*CONSTANT_2),&(v180_2));
        drop(v180_2);
        let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
        drop(v180_9);
        let v180_12: Space = if (v180_10).is_empty() { Space::new() } else {
          let v182_6: Path = concat_path(&(v179_6),&(v179_7_head));
          let v182_11: Space = routine_29(c, &(v182_6), &(*p1), &(v179_7_tail), &(*s1));
          drop(v182_6);
          compose(&(v180_10),&(v182_11))
        };
        drop(v180_10);
        let v180_13: Space = unite(&(v180_8),&(v180_12));
        v179_7.join_into((v180_13).clone());
      }
      drop(v179_7_cursor);
      drop(v179_6);
      compose(&(v178_5),&(v179_7))
    };
    drop(v178_5);
    let v178_9: Space = intersect(&(*CONSTANT_2),&(v178_2));
    drop(v178_2);
    let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
    drop(v178_9);
    let v178_13: Space = if (v178_10).is_empty() { Space::new() } else {
      let v183_11: Space = unwrap(&(v177_9),&(v177_16_head));
      let mut v183_12 = Space::new();
      let mut v183_12_cursor = (v183_11).read_zipper();
      for v183_12_byte in v183_12_cursor.child_mask().iter() {
        v183_12_cursor.descend_to_byte(v183_12_byte);
        let v183_12_tail = v183_12_cursor.make_map();
        v183_12_cursor.ascend(1);
        let v183_12_head = Path::from_slice(&[v183_12_byte]);
        let v184_2: Space = singleton(&(v183_12_head));
        let v184_3: Space = intersect(&(*CONSTANT_2),&(v184_2));
        let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
        drop(v184_3);
        let v184_5: Space = subtract(&(*CONSTANT_1),&(v184_4));
        drop(v184_4);
        let v184_7: Space = if (v184_5).is_empty() { Space::new() } else {
          let v185_6: Space = routine_15(c, &(v183_12_head), &(*p1), &(v183_12_tail));
          compose(&(v184_5),&(v185_6))
        };
        drop(v184_5);
        let v184_8: Space = intersect(&(*CONSTANT_2),&(v184_2));
        drop(v184_2);
        let v184_9: Space = if has_head(&(v184_8)) { singleton(&[]) } else { Space::new() };
        drop(v184_8);
        let v184_11: Space = if (v184_9).is_empty() { Space::new() } else {
          let v186_10: Space = routine_16(c, &(v183_12_head), &(*p1), &(v183_12_tail));
          compose(&(v184_9),&(v186_10))
        };
        drop(v184_9);
        let v184_12: Space = unite(&(v184_7),&(v184_11));
        v183_12.join_into((v184_12).clone());
      }
      drop(v183_12_cursor);
      drop(v183_11);
      compose(&(v178_10),&(v183_12))
    };
    drop(v178_10);
    let v178_14: Space = unite(&(v178_8),&(v178_13));
    v177_16.join_into((v178_14).clone());
  }
  drop(v177_16_cursor);
  drop(v177_9);
  (v177_16).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v187_12 = Space::new();
  let mut v187_12_cursor = (*s0).read_zipper();
  for v187_12_byte in v187_12_cursor.child_mask().iter() {
    v187_12_cursor.descend_to_byte(v187_12_byte);
    let v187_12_tail = v187_12_cursor.make_map();
    v187_12_cursor.ascend(1);
    let v187_12_head = Path::from_slice(&[v187_12_byte]);
    let v188_2: Space = singleton(&(v187_12_head));
    let v188_3: Space = intersect(&(*CONSTANT_2),&(v188_2));
    let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
    drop(v188_3);
    let v188_5: Space = subtract(&(*CONSTANT_1),&(v188_4));
    drop(v188_4);
    let v188_8: Space = if (v188_5).is_empty() { Space::new() } else {
      let v189_6: Path = concat_path(&(*p0),&(v187_12_head));
      let mut v189_7 = Space::new();
      let mut v189_7_cursor = (v187_12_tail).read_zipper();
      for v189_7_byte in v189_7_cursor.child_mask().iter() {
        v189_7_cursor.descend_to_byte(v189_7_byte);
        let v189_7_tail = v189_7_cursor.make_map();
        v189_7_cursor.ascend(1);
        let v189_7_head = Path::from_slice(&[v189_7_byte]);
        let v190_2: Space = singleton(&(v189_7_head));
        let v190_3: Space = intersect(&(*CONSTANT_2),&(v190_2));
        let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
        drop(v190_3);
        let v190_5: Space = subtract(&(*CONSTANT_1),&(v190_4));
        drop(v190_4);
        let v190_8: Space = if (v190_5).is_empty() { Space::new() } else {
          let v191_6: Path = concat_path(&(v189_6),&(v189_7_head));
          let v191_7: Space = routine_30(c, &(v191_6), &(*p1), &(v189_7_tail));
          compose(&(v190_5),&(v191_7))
        };
        drop(v190_5);
        let v190_9: Space = intersect(&(*CONSTANT_2),&(v190_2));
        drop(v190_2);
        let v190_10: Space = if has_head(&(v190_9)) { singleton(&[]) } else { Space::new() };
        drop(v190_9);
        let v190_12: Space = if (v190_10).is_empty() { Space::new() } else {
          let v192_6: Path = concat_path(&(v189_6),&(v189_7_head));
          let v192_11: Space = routine_31(c, &(v192_6), &(*p1), &(v189_7_tail));
          drop(v192_6);
          compose(&(v190_10),&(v192_11))
        };
        drop(v190_10);
        let v190_13: Space = unite(&(v190_8),&(v190_12));
        v189_7.join_into((v190_13).clone());
      }
      drop(v189_7_cursor);
      compose(&(v188_5),&(v189_7))
    };
    drop(v188_5);
    let v188_9: Space = intersect(&(*CONSTANT_2),&(v188_2));
    drop(v188_2);
    let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
    drop(v188_9);
    let v188_12: Space = if (v188_10).is_empty() { Space::new() } else {
      let v193_6: Path = concat_path(&(*p0),&(v187_12_head));
      let mut v193_11 = Space::new();
      let mut v193_11_cursor = (v187_12_tail).read_zipper();
      for v193_11_byte in v193_11_cursor.child_mask().iter() {
        v193_11_cursor.descend_to_byte(v193_11_byte);
        let v193_11_tail = v193_11_cursor.make_map();
        v193_11_cursor.ascend(1);
        let v193_11_head = Path::from_slice(&[v193_11_byte]);
        let v194_2: Space = singleton(&(v193_11_head));
        let v194_3: Space = intersect(&(*CONSTANT_2),&(v194_2));
        let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
        drop(v194_3);
        let v194_5: Space = subtract(&(*CONSTANT_1),&(v194_4));
        drop(v194_4);
        let v194_8: Space = if (v194_5).is_empty() { Space::new() } else {
          let v195_6: Path = concat_path(&(v193_6),&(v193_11_head));
          let v195_7: Space = routine_30(c, &(v195_6), &(*p1), &(v193_11_tail));
          compose(&(v194_5),&(v195_7))
        };
        drop(v194_5);
        let v194_9: Space = intersect(&(*CONSTANT_2),&(v194_2));
        drop(v194_2);
        let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
        drop(v194_9);
        let v194_12: Space = if (v194_10).is_empty() { Space::new() } else {
          let v196_6: Path = concat_path(&(v193_6),&(v193_11_head));
          let v196_11: Space = routine_21(c, &(v196_6), &(*p1), &(v193_11_tail));
          drop(v196_6);
          compose(&(v194_10),&(v196_11))
        };
        drop(v194_10);
        let v194_13: Space = unite(&(v194_8),&(v194_12));
        v193_11.join_into((v194_13).clone());
      }
      drop(v193_11_cursor);
      drop(v193_6);
      compose(&(v188_10),&(v193_11))
    };
    drop(v188_10);
    let v188_13: Space = unite(&(v188_8),&(v188_12));
    v187_12.join_into((v188_13).clone());
  }
  drop(v187_12_cursor);
  (v187_12).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v197_9 = Space::new();
  let mut v197_9_cursor = (*s0).read_zipper();
  for v197_9_byte in v197_9_cursor.child_mask().iter() {
    v197_9_cursor.descend_to_byte(v197_9_byte);
    let v197_9_tail = v197_9_cursor.make_map();
    v197_9_cursor.ascend(1);
    let v197_9_head = Path::from_slice(&[v197_9_byte]);
    let v198_2: Space = singleton(&(v197_9_head));
    let v198_3: Space = intersect(&(*CONSTANT_2),&(v198_2));
    let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
    drop(v198_3);
    let v198_5: Space = subtract(&(*CONSTANT_1),&(v198_4));
    drop(v198_4);
    let v198_8: Space = if (v198_5).is_empty() { Space::new() } else {
      let v199_6: Path = concat_path(&(*p0),&(v197_9_head));
      let mut v199_7 = Space::new();
      let mut v199_7_cursor = (v197_9_tail).read_zipper();
      for v199_7_byte in v199_7_cursor.child_mask().iter() {
        v199_7_cursor.descend_to_byte(v199_7_byte);
        let v199_7_tail = v199_7_cursor.make_map();
        v199_7_cursor.ascend(1);
        let v199_7_head = Path::from_slice(&[v199_7_byte]);
        let v200_2: Space = singleton(&(v199_7_head));
        let v200_3: Space = intersect(&(*CONSTANT_2),&(v200_2));
        let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
        drop(v200_3);
        let v200_5: Space = subtract(&(*CONSTANT_1),&(v200_4));
        drop(v200_4);
        let v200_8: Space = if (v200_5).is_empty() { Space::new() } else {
          let v201_6: Path = concat_path(&(v199_6),&(v199_7_head));
          let v201_7: Space = routine_30(c, &(v201_6), &(*p1), &(v199_7_tail));
          compose(&(v200_5),&(v201_7))
        };
        drop(v200_5);
        let v200_9: Space = intersect(&(*CONSTANT_2),&(v200_2));
        drop(v200_2);
        let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
        drop(v200_9);
        let v200_12: Space = if (v200_10).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v199_6),&(v199_7_head));
          let v202_11: Space = routine_31(c, &(v202_6), &(*p1), &(v199_7_tail));
          drop(v202_6);
          compose(&(v200_10),&(v202_11))
        };
        drop(v200_10);
        let v200_13: Space = unite(&(v200_8),&(v200_12));
        v199_7.join_into((v200_13).clone());
      }
      drop(v199_7_cursor);
      compose(&(v198_5),&(v199_7))
    };
    drop(v198_5);
    let v198_9: Space = intersect(&(*CONSTANT_2),&(v198_2));
    drop(v198_2);
    let v198_10: Space = if has_head(&(v198_9)) { singleton(&[]) } else { Space::new() };
    drop(v198_9);
    let v198_11: Space = compose(&(v198_10),&(v197_9_tail));
    drop(v198_10);
    let v203_6: Path = concat_path(&(*p0),&(v197_9_head));
    let v198_12: Space = wrap(&(v198_11),&(v203_6));
    drop(v198_11);
    let v198_13: Space = wrap(&(v198_12),&(*p1));
    drop(v198_12);
    let v198_14: Space = unite(&(v198_8),&(v198_13));
    drop(v198_13);
    v197_9.join_into((v198_14).clone());
  }
  drop(v197_9_cursor);
  (v197_9).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v204_3: Space = wrap(&(*s0),&(*p0));
  let v204_4: Space = wrap(&(v204_3),&(*p1));
  drop(v204_3);
  (v204_4).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v205_12 = Space::new();
  let mut v205_12_cursor = (*s0).read_zipper();
  for v205_12_byte in v205_12_cursor.child_mask().iter() {
    v205_12_cursor.descend_to_byte(v205_12_byte);
    let v205_12_tail = v205_12_cursor.make_map();
    v205_12_cursor.ascend(1);
    let v205_12_head = Path::from_slice(&[v205_12_byte]);
    let v206_2: Space = singleton(&(v205_12_head));
    let v206_3: Space = intersect(&(*CONSTANT_2),&(v206_2));
    let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
    drop(v206_3);
    let v206_5: Space = subtract(&(*CONSTANT_1),&(v206_4));
    drop(v206_4);
    let v206_8: Space = if (v206_5).is_empty() { Space::new() } else {
      let v207_6: Path = concat_path(&(*p0),&(v205_12_head));
      let mut v207_7 = Space::new();
      let mut v207_7_cursor = (v205_12_tail).read_zipper();
      for v207_7_byte in v207_7_cursor.child_mask().iter() {
        v207_7_cursor.descend_to_byte(v207_7_byte);
        let v207_7_tail = v207_7_cursor.make_map();
        v207_7_cursor.ascend(1);
        let v207_7_head = Path::from_slice(&[v207_7_byte]);
        let v208_2: Space = singleton(&(v207_7_head));
        let v208_3: Space = intersect(&(*CONSTANT_2),&(v208_2));
        let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
        drop(v208_3);
        let v208_5: Space = subtract(&(*CONSTANT_1),&(v208_4));
        drop(v208_4);
        let v208_8: Space = if (v208_5).is_empty() { Space::new() } else {
          let v209_6: Path = concat_path(&(v207_6),&(v207_7_head));
          let v209_7: Space = routine_32(c, &(v209_6), &(v207_7_tail), &(*s1));
          compose(&(v208_5),&(v209_7))
        };
        drop(v208_5);
        let v208_9: Space = intersect(&(*CONSTANT_2),&(v208_2));
        drop(v208_2);
        let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
        drop(v208_9);
        let v208_12: Space = if (v208_10).is_empty() { Space::new() } else {
          let v210_6: Path = concat_path(&(v207_6),&(v207_7_head));
          let v210_11: Space = routine_33(c, &(v210_6), &(v207_7_tail), &(*s1));
          drop(v210_6);
          compose(&(v208_10),&(v210_11))
        };
        drop(v208_10);
        let v208_13: Space = unite(&(v208_8),&(v208_12));
        v207_7.join_into((v208_13).clone());
      }
      drop(v207_7_cursor);
      compose(&(v206_5),&(v207_7))
    };
    drop(v206_5);
    let v206_9: Space = intersect(&(*CONSTANT_2),&(v206_2));
    drop(v206_2);
    let v206_10: Space = if has_head(&(v206_9)) { singleton(&[]) } else { Space::new() };
    drop(v206_9);
    let v206_12: Space = if (v206_10).is_empty() { Space::new() } else {
      let v211_6: Path = concat_path(&(*p0),&(v205_12_head));
      let mut v211_11 = Space::new();
      let mut v211_11_cursor = (v205_12_tail).read_zipper();
      for v211_11_byte in v211_11_cursor.child_mask().iter() {
        v211_11_cursor.descend_to_byte(v211_11_byte);
        let v211_11_tail = v211_11_cursor.make_map();
        v211_11_cursor.ascend(1);
        let v211_11_head = Path::from_slice(&[v211_11_byte]);
        let v212_2: Space = singleton(&(v211_11_head));
        let v212_3: Space = intersect(&(*CONSTANT_2),&(v212_2));
        let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
        drop(v212_3);
        let v212_5: Space = subtract(&(*CONSTANT_1),&(v212_4));
        drop(v212_4);
        let v212_8: Space = if (v212_5).is_empty() { Space::new() } else {
          let v213_6: Path = concat_path(&(v211_6),&(v211_11_head));
          let v213_7: Space = routine_32(c, &(v213_6), &(v211_11_tail), &(*s1));
          compose(&(v212_5),&(v213_7))
        };
        drop(v212_5);
        let v212_9: Space = intersect(&(*CONSTANT_2),&(v212_2));
        drop(v212_2);
        let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
        drop(v212_9);
        let v212_12: Space = if (v212_10).is_empty() { Space::new() } else {
          let v214_6: Path = concat_path(&(v211_6),&(v211_11_head));
          let v214_11: Space = routine_3(c, &(v214_6), &(v211_11_tail), &(*s1));
          drop(v214_6);
          compose(&(v212_10),&(v214_11))
        };
        drop(v212_10);
        let v212_13: Space = unite(&(v212_8),&(v212_12));
        v211_11.join_into((v212_13).clone());
      }
      drop(v211_11_cursor);
      drop(v211_6);
      compose(&(v206_10),&(v211_11))
    };
    drop(v206_10);
    let v206_13: Space = unite(&(v206_8),&(v206_12));
    v205_12.join_into((v206_13).clone());
  }
  drop(v205_12_cursor);
  (v205_12).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v215_12 = Space::new();
  let mut v215_12_cursor = (*s0).read_zipper();
  for v215_12_byte in v215_12_cursor.child_mask().iter() {
    v215_12_cursor.descend_to_byte(v215_12_byte);
    let v215_12_tail = v215_12_cursor.make_map();
    v215_12_cursor.ascend(1);
    let v215_12_head = Path::from_slice(&[v215_12_byte]);
    let v216_2: Space = singleton(&(v215_12_head));
    let v216_3: Space = intersect(&(*CONSTANT_2),&(v216_2));
    let v216_4: Space = if has_head(&(v216_3)) { singleton(&[]) } else { Space::new() };
    drop(v216_3);
    let v216_5: Space = subtract(&(*CONSTANT_1),&(v216_4));
    drop(v216_4);
    let v216_8: Space = if (v216_5).is_empty() { Space::new() } else {
      let v217_6: Path = concat_path(&(*p0),&(v215_12_head));
      let mut v217_7 = Space::new();
      let mut v217_7_cursor = (v215_12_tail).read_zipper();
      for v217_7_byte in v217_7_cursor.child_mask().iter() {
        v217_7_cursor.descend_to_byte(v217_7_byte);
        let v217_7_tail = v217_7_cursor.make_map();
        v217_7_cursor.ascend(1);
        let v217_7_head = Path::from_slice(&[v217_7_byte]);
        let v218_2: Space = singleton(&(v217_7_head));
        let v218_3: Space = intersect(&(*CONSTANT_2),&(v218_2));
        let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
        drop(v218_3);
        let v218_5: Space = subtract(&(*CONSTANT_1),&(v218_4));
        drop(v218_4);
        let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
          let v219_6: Path = concat_path(&(v217_6),&(v217_7_head));
          let v219_7: Space = routine_32(c, &(v219_6), &(v217_7_tail), &(*s1));
          compose(&(v218_5),&(v219_7))
        };
        drop(v218_5);
        let v218_9: Space = intersect(&(*CONSTANT_2),&(v218_2));
        drop(v218_2);
        let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
        drop(v218_9);
        let v218_12: Space = if (v218_10).is_empty() { Space::new() } else {
          let v220_6: Path = concat_path(&(v217_6),&(v217_7_head));
          let v220_11: Space = routine_33(c, &(v220_6), &(v217_7_tail), &(*s1));
          drop(v220_6);
          compose(&(v218_10),&(v220_11))
        };
        drop(v218_10);
        let v218_13: Space = unite(&(v218_8),&(v218_12));
        v217_7.join_into((v218_13).clone());
      }
      drop(v217_7_cursor);
      compose(&(v216_5),&(v217_7))
    };
    drop(v216_5);
    let v216_9: Space = intersect(&(*CONSTANT_2),&(v216_2));
    drop(v216_2);
    let v216_10: Space = if has_head(&(v216_9)) { singleton(&[]) } else { Space::new() };
    drop(v216_9);
    let v216_12: Space = if (v216_10).is_empty() { Space::new() } else {
      let v221_6: Path = concat_path(&(*p0),&(v215_12_head));
      let mut v221_11 = Space::new();
      let mut v221_11_cursor = (v215_12_tail).read_zipper();
      for v221_11_byte in v221_11_cursor.child_mask().iter() {
        v221_11_cursor.descend_to_byte(v221_11_byte);
        let v221_11_tail = v221_11_cursor.make_map();
        v221_11_cursor.ascend(1);
        let v221_11_head = Path::from_slice(&[v221_11_byte]);
        let v222_2: Space = singleton(&(v221_11_head));
        let v222_3: Space = intersect(&(*CONSTANT_2),&(v222_2));
        let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
        drop(v222_3);
        let v222_5: Space = subtract(&(*CONSTANT_1),&(v222_4));
        drop(v222_4);
        let v222_7: Space = if (v222_5).is_empty() { Space::new() } else {
          let v223_6: Space = routine_6(c, &(v221_11_head), &(v221_6), &(v221_11_tail), &(*s1));
          compose(&(v222_5),&(v223_6))
        };
        drop(v222_5);
        let v222_8: Space = intersect(&(*CONSTANT_2),&(v222_2));
        drop(v222_2);
        let v222_9: Space = if has_head(&(v222_8)) { singleton(&[]) } else { Space::new() };
        drop(v222_8);
        let v222_11: Space = if (v222_9).is_empty() { Space::new() } else {
          let v224_10: Space = routine_7(c, &(v221_11_head), &(v221_6), &(v221_11_tail), &(*s1));
          compose(&(v222_9),&(v224_10))
        };
        drop(v222_9);
        let v222_12: Space = unite(&(v222_7),&(v222_11));
        v221_11.join_into((v222_12).clone());
      }
      drop(v221_11_cursor);
      drop(v221_6);
      compose(&(v216_10),&(v221_11))
    };
    drop(v216_10);
    let v216_13: Space = unite(&(v216_8),&(v216_12));
    v215_12.join_into((v216_13).clone());
  }
  drop(v215_12_cursor);
  (v215_12).clone()
}

fn routine_24(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v225_13 = Space::new();
  let mut v225_13_cursor = (*s0).read_zipper();
  for v225_13_byte in v225_13_cursor.child_mask().iter() {
    v225_13_cursor.descend_to_byte(v225_13_byte);
    let v225_13_tail = v225_13_cursor.make_map();
    v225_13_cursor.ascend(1);
    let v225_13_head = Path::from_slice(&[v225_13_byte]);
    let v226_2: Space = singleton(&(v225_13_head));
    let v226_3: Space = intersect(&(*CONSTANT_2),&(v226_2));
    let v226_4: Space = if has_head(&(v226_3)) { singleton(&[]) } else { Space::new() };
    drop(v226_3);
    let v226_5: Space = subtract(&(*CONSTANT_1),&(v226_4));
    drop(v226_4);
    let v226_8: Space = if (v226_5).is_empty() { Space::new() } else {
      let v227_6: Path = concat_path(&(*p0),&(v225_13_head));
      let mut v227_7 = Space::new();
      let mut v227_7_cursor = (v225_13_tail).read_zipper();
      for v227_7_byte in v227_7_cursor.child_mask().iter() {
        v227_7_cursor.descend_to_byte(v227_7_byte);
        let v227_7_tail = v227_7_cursor.make_map();
        v227_7_cursor.ascend(1);
        let v227_7_head = Path::from_slice(&[v227_7_byte]);
        let v228_2: Space = singleton(&(v227_7_head));
        let v228_3: Space = intersect(&(*CONSTANT_2),&(v228_2));
        let v228_4: Space = if has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
        drop(v228_3);
        let v228_5: Space = subtract(&(*CONSTANT_1),&(v228_4));
        drop(v228_4);
        let v228_8: Space = if (v228_5).is_empty() { Space::new() } else {
          let v229_6: Path = concat_path(&(v227_6),&(v227_7_head));
          let v229_7: Space = routine_34(c, &(v229_6), &(*p1), &(v227_7_tail), &(*s1));
          compose(&(v228_5),&(v229_7))
        };
        drop(v228_5);
        let v228_9: Space = intersect(&(*CONSTANT_2),&(v228_2));
        drop(v228_2);
        let v228_10: Space = if has_head(&(v228_9)) { singleton(&[]) } else { Space::new() };
        drop(v228_9);
        let v228_12: Space = if (v228_10).is_empty() { Space::new() } else {
          let v230_6: Path = concat_path(&(v227_6),&(v227_7_head));
          let v230_11: Space = routine_35(c, &(v230_6), &(*p1), &(v227_7_tail), &(*s1));
          drop(v230_6);
          compose(&(v228_10),&(v230_11))
        };
        drop(v228_10);
        let v228_13: Space = unite(&(v228_8),&(v228_12));
        v227_7.join_into((v228_13).clone());
      }
      drop(v227_7_cursor);
      compose(&(v226_5),&(v227_7))
    };
    drop(v226_5);
    let v226_9: Space = intersect(&(*CONSTANT_2),&(v226_2));
    drop(v226_2);
    let v226_10: Space = if has_head(&(v226_9)) { singleton(&[]) } else { Space::new() };
    drop(v226_9);
    let v226_12: Space = if (v226_10).is_empty() { Space::new() } else {
      let v231_6: Path = concat_path(&(*p0),&(v225_13_head));
      let mut v231_11 = Space::new();
      let mut v231_11_cursor = (v225_13_tail).read_zipper();
      for v231_11_byte in v231_11_cursor.child_mask().iter() {
        v231_11_cursor.descend_to_byte(v231_11_byte);
        let v231_11_tail = v231_11_cursor.make_map();
        v231_11_cursor.ascend(1);
        let v231_11_head = Path::from_slice(&[v231_11_byte]);
        let v232_2: Space = singleton(&(v231_11_head));
        let v232_3: Space = intersect(&(*CONSTANT_2),&(v232_2));
        let v232_4: Space = if has_head(&(v232_3)) { singleton(&[]) } else { Space::new() };
        drop(v232_3);
        let v232_5: Space = subtract(&(*CONSTANT_1),&(v232_4));
        drop(v232_4);
        let v232_8: Space = if (v232_5).is_empty() { Space::new() } else {
          let v233_6: Path = concat_path(&(v231_6),&(v231_11_head));
          let v233_7: Space = routine_34(c, &(v233_6), &(*p1), &(v231_11_tail), &(*s1));
          compose(&(v232_5),&(v233_7))
        };
        drop(v232_5);
        let v232_9: Space = intersect(&(*CONSTANT_2),&(v232_2));
        drop(v232_2);
        let v232_10: Space = if has_head(&(v232_9)) { singleton(&[]) } else { Space::new() };
        drop(v232_9);
        let v232_12: Space = if (v232_10).is_empty() { Space::new() } else {
          let v234_6: Path = concat_path(&(v231_6),&(v231_11_head));
          let v234_11: Space = routine_10(c, &(v234_6), &(*p1), &(v231_11_tail), &(*s1));
          drop(v234_6);
          compose(&(v232_10),&(v234_11))
        };
        drop(v232_10);
        let v232_13: Space = unite(&(v232_8),&(v232_12));
        v231_11.join_into((v232_13).clone());
      }
      drop(v231_11_cursor);
      drop(v231_6);
      compose(&(v226_10),&(v231_11))
    };
    drop(v226_10);
    let v226_13: Space = unite(&(v226_8),&(v226_12));
    v225_13.join_into((v226_13).clone());
  }
  drop(v225_13_cursor);
  (v225_13).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v235_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v235_9: Space = unwrap(&(v235_8),&(*p0));
  drop(v235_8);
  let mut v235_16 = Space::new();
  let mut v235_16_cursor = (*s0).read_zipper();
  for v235_16_byte in v235_16_cursor.child_mask().iter() {
    v235_16_cursor.descend_to_byte(v235_16_byte);
    let v235_16_tail = v235_16_cursor.make_map();
    v235_16_cursor.ascend(1);
    let v235_16_head = Path::from_slice(&[v235_16_byte]);
    let v236_2: Space = singleton(&(v235_16_head));
    let v236_3: Space = intersect(&(*CONSTANT_2),&(v236_2));
    let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
    drop(v236_3);
    let v236_5: Space = subtract(&(*CONSTANT_1),&(v236_4));
    drop(v236_4);
    let v236_8: Space = if (v236_5).is_empty() { Space::new() } else {
      let v237_6: Path = concat_path(&(*p0),&(v235_16_head));
      let mut v237_7 = Space::new();
      let mut v237_7_cursor = (v235_16_tail).read_zipper();
      for v237_7_byte in v237_7_cursor.child_mask().iter() {
        v237_7_cursor.descend_to_byte(v237_7_byte);
        let v237_7_tail = v237_7_cursor.make_map();
        v237_7_cursor.ascend(1);
        let v237_7_head = Path::from_slice(&[v237_7_byte]);
        let v238_2: Space = singleton(&(v237_7_head));
        let v238_3: Space = intersect(&(*CONSTANT_2),&(v238_2));
        let v238_4: Space = if has_head(&(v238_3)) { singleton(&[]) } else { Space::new() };
        drop(v238_3);
        let v238_5: Space = subtract(&(*CONSTANT_1),&(v238_4));
        drop(v238_4);
        let v238_8: Space = if (v238_5).is_empty() { Space::new() } else {
          let v239_6: Path = concat_path(&(v237_6),&(v237_7_head));
          let v239_7: Space = routine_34(c, &(v239_6), &(*p1), &(v237_7_tail), &(*s1));
          compose(&(v238_5),&(v239_7))
        };
        drop(v238_5);
        let v238_9: Space = intersect(&(*CONSTANT_2),&(v238_2));
        drop(v238_2);
        let v238_10: Space = if has_head(&(v238_9)) { singleton(&[]) } else { Space::new() };
        drop(v238_9);
        let v238_12: Space = if (v238_10).is_empty() { Space::new() } else {
          let v240_6: Path = concat_path(&(v237_6),&(v237_7_head));
          let v240_11: Space = routine_35(c, &(v240_6), &(*p1), &(v237_7_tail), &(*s1));
          drop(v240_6);
          compose(&(v238_10),&(v240_11))
        };
        drop(v238_10);
        let v238_13: Space = unite(&(v238_8),&(v238_12));
        v237_7.join_into((v238_13).clone());
      }
      drop(v237_7_cursor);
      drop(v237_6);
      compose(&(v236_5),&(v237_7))
    };
    drop(v236_5);
    let v236_9: Space = intersect(&(*CONSTANT_2),&(v236_2));
    drop(v236_2);
    let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
    drop(v236_9);
    let v236_13: Space = if (v236_10).is_empty() { Space::new() } else {
      let v241_11: Space = unwrap(&(v235_9),&(v235_16_head));
      let mut v241_12 = Space::new();
      let mut v241_12_cursor = (v241_11).read_zipper();
      for v241_12_byte in v241_12_cursor.child_mask().iter() {
        v241_12_cursor.descend_to_byte(v241_12_byte);
        let v241_12_tail = v241_12_cursor.make_map();
        v241_12_cursor.ascend(1);
        let v241_12_head = Path::from_slice(&[v241_12_byte]);
        let v242_2: Space = singleton(&(v241_12_head));
        let v242_3: Space = intersect(&(*CONSTANT_2),&(v242_2));
        let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = subtract(&(*CONSTANT_1),&(v242_4));
        drop(v242_4);
        let v242_7: Space = if (v242_5).is_empty() { Space::new() } else {
          let v243_6: Space = routine_15(c, &(v241_12_head), &(*p1), &(v241_12_tail));
          compose(&(v242_5),&(v243_6))
        };
        drop(v242_5);
        let v242_8: Space = intersect(&(*CONSTANT_2),&(v242_2));
        drop(v242_2);
        let v242_9: Space = if has_head(&(v242_8)) { singleton(&[]) } else { Space::new() };
        drop(v242_8);
        let v242_11: Space = if (v242_9).is_empty() { Space::new() } else {
          let v244_10: Space = routine_16(c, &(v241_12_head), &(*p1), &(v241_12_tail));
          compose(&(v242_9),&(v244_10))
        };
        drop(v242_9);
        let v242_12: Space = unite(&(v242_7),&(v242_11));
        v241_12.join_into((v242_12).clone());
      }
      drop(v241_12_cursor);
      drop(v241_11);
      compose(&(v236_10),&(v241_12))
    };
    drop(v236_10);
    let v236_14: Space = unite(&(v236_8),&(v236_13));
    v235_16.join_into((v236_14).clone());
  }
  drop(v235_16_cursor);
  drop(v235_9);
  (v235_16).clone()
}

fn routine_26(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v245_12 = Space::new();
  let mut v245_12_cursor = (*s0).read_zipper();
  for v245_12_byte in v245_12_cursor.child_mask().iter() {
    v245_12_cursor.descend_to_byte(v245_12_byte);
    let v245_12_tail = v245_12_cursor.make_map();
    v245_12_cursor.ascend(1);
    let v245_12_head = Path::from_slice(&[v245_12_byte]);
    let v246_2: Space = singleton(&(v245_12_head));
    let v246_3: Space = intersect(&(*CONSTANT_2),&(v246_2));
    let v246_4: Space = if has_head(&(v246_3)) { singleton(&[]) } else { Space::new() };
    drop(v246_3);
    let v246_5: Space = subtract(&(*CONSTANT_1),&(v246_4));
    drop(v246_4);
    let v246_8: Space = if (v246_5).is_empty() { Space::new() } else {
      let v247_6: Path = concat_path(&(*p0),&(v245_12_head));
      let mut v247_7 = Space::new();
      let mut v247_7_cursor = (v245_12_tail).read_zipper();
      for v247_7_byte in v247_7_cursor.child_mask().iter() {
        v247_7_cursor.descend_to_byte(v247_7_byte);
        let v247_7_tail = v247_7_cursor.make_map();
        v247_7_cursor.ascend(1);
        let v247_7_head = Path::from_slice(&[v247_7_byte]);
        let v248_2: Space = singleton(&(v247_7_head));
        let v248_3: Space = intersect(&(*CONSTANT_2),&(v248_2));
        let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
        drop(v248_3);
        let v248_5: Space = subtract(&(*CONSTANT_1),&(v248_4));
        drop(v248_4);
        let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
          let v249_6: Path = concat_path(&(v247_6),&(v247_7_head));
          let v249_7: Space = routine_36(c, &(v249_6), &(*p1), &(v247_7_tail));
          compose(&(v248_5),&(v249_7))
        };
        drop(v248_5);
        let v248_9: Space = intersect(&(*CONSTANT_2),&(v248_2));
        drop(v248_2);
        let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
        drop(v248_9);
        let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
          let v250_6: Path = concat_path(&(v247_6),&(v247_7_head));
          let v250_11: Space = routine_37(c, &(v250_6), &(*p1), &(v247_7_tail));
          drop(v250_6);
          compose(&(v248_10),&(v250_11))
        };
        drop(v248_10);
        let v248_13: Space = unite(&(v248_8),&(v248_12));
        v247_7.join_into((v248_13).clone());
      }
      drop(v247_7_cursor);
      compose(&(v246_5),&(v247_7))
    };
    drop(v246_5);
    let v246_9: Space = intersect(&(*CONSTANT_2),&(v246_2));
    drop(v246_2);
    let v246_10: Space = if has_head(&(v246_9)) { singleton(&[]) } else { Space::new() };
    drop(v246_9);
    let v246_12: Space = if (v246_10).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&(v245_12_head));
      let mut v251_11 = Space::new();
      let mut v251_11_cursor = (v245_12_tail).read_zipper();
      for v251_11_byte in v251_11_cursor.child_mask().iter() {
        v251_11_cursor.descend_to_byte(v251_11_byte);
        let v251_11_tail = v251_11_cursor.make_map();
        v251_11_cursor.ascend(1);
        let v251_11_head = Path::from_slice(&[v251_11_byte]);
        let v252_2: Space = singleton(&(v251_11_head));
        let v252_3: Space = intersect(&(*CONSTANT_2),&(v252_2));
        let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = subtract(&(*CONSTANT_1),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (v252_5).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&(v251_11_head));
          let v253_7: Space = routine_36(c, &(v253_6), &(*p1), &(v251_11_tail));
          compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = intersect(&(*CONSTANT_2),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_12: Space = if (v252_10).is_empty() { Space::new() } else {
          let v254_6: Path = concat_path(&(v251_6),&(v251_11_head));
          let v254_11: Space = routine_21(c, &(v254_6), &(*p1), &(v251_11_tail));
          drop(v254_6);
          compose(&(v252_10),&(v254_11))
        };
        drop(v252_10);
        let v252_13: Space = unite(&(v252_8),&(v252_12));
        v251_11.join_into((v252_13).clone());
      }
      drop(v251_11_cursor);
      drop(v251_6);
      compose(&(v246_10),&(v251_11))
    };
    drop(v246_10);
    let v246_13: Space = unite(&(v246_8),&(v246_12));
    v245_12.join_into((v246_13).clone());
  }
  drop(v245_12_cursor);
  (v245_12).clone()
}

fn routine_27(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v255_9 = Space::new();
  let mut v255_9_cursor = (*s0).read_zipper();
  for v255_9_byte in v255_9_cursor.child_mask().iter() {
    v255_9_cursor.descend_to_byte(v255_9_byte);
    let v255_9_tail = v255_9_cursor.make_map();
    v255_9_cursor.ascend(1);
    let v255_9_head = Path::from_slice(&[v255_9_byte]);
    let v256_2: Space = singleton(&(v255_9_head));
    let v256_3: Space = intersect(&(*CONSTANT_2),&(v256_2));
    let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
    drop(v256_3);
    let v256_5: Space = subtract(&(*CONSTANT_1),&(v256_4));
    drop(v256_4);
    let v256_8: Space = if (v256_5).is_empty() { Space::new() } else {
      let v257_6: Path = concat_path(&(*p0),&(v255_9_head));
      let mut v257_7 = Space::new();
      let mut v257_7_cursor = (v255_9_tail).read_zipper();
      for v257_7_byte in v257_7_cursor.child_mask().iter() {
        v257_7_cursor.descend_to_byte(v257_7_byte);
        let v257_7_tail = v257_7_cursor.make_map();
        v257_7_cursor.ascend(1);
        let v257_7_head = Path::from_slice(&[v257_7_byte]);
        let v258_2: Space = singleton(&(v257_7_head));
        let v258_3: Space = intersect(&(*CONSTANT_2),&(v258_2));
        let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
        drop(v258_3);
        let v258_5: Space = subtract(&(*CONSTANT_1),&(v258_4));
        drop(v258_4);
        let v258_8: Space = if (v258_5).is_empty() { Space::new() } else {
          let v259_6: Path = concat_path(&(v257_6),&(v257_7_head));
          let v259_7: Space = routine_36(c, &(v259_6), &(*p1), &(v257_7_tail));
          compose(&(v258_5),&(v259_7))
        };
        drop(v258_5);
        let v258_9: Space = intersect(&(*CONSTANT_2),&(v258_2));
        drop(v258_2);
        let v258_10: Space = if has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
        drop(v258_9);
        let v258_12: Space = if (v258_10).is_empty() { Space::new() } else {
          let v260_6: Path = concat_path(&(v257_6),&(v257_7_head));
          let v260_11: Space = routine_37(c, &(v260_6), &(*p1), &(v257_7_tail));
          drop(v260_6);
          compose(&(v258_10),&(v260_11))
        };
        drop(v258_10);
        let v258_13: Space = unite(&(v258_8),&(v258_12));
        v257_7.join_into((v258_13).clone());
      }
      drop(v257_7_cursor);
      compose(&(v256_5),&(v257_7))
    };
    drop(v256_5);
    let v256_9: Space = intersect(&(*CONSTANT_2),&(v256_2));
    drop(v256_2);
    let v256_10: Space = if has_head(&(v256_9)) { singleton(&[]) } else { Space::new() };
    drop(v256_9);
    let v256_11: Space = compose(&(v256_10),&(v255_9_tail));
    drop(v256_10);
    let v261_6: Path = concat_path(&(*p0),&(v255_9_head));
    let v256_12: Space = wrap(&(v256_11),&(v261_6));
    drop(v256_11);
    let v256_13: Space = wrap(&(v256_12),&(*p1));
    drop(v256_12);
    let v256_14: Space = unite(&(v256_8),&(v256_13));
    drop(v256_13);
    v255_9.join_into((v256_14).clone());
  }
  drop(v255_9_cursor);
  (v255_9).clone()
}

fn routine_28(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v262_13 = Space::new();
  let mut v262_13_cursor = (*s0).read_zipper();
  for v262_13_byte in v262_13_cursor.child_mask().iter() {
    v262_13_cursor.descend_to_byte(v262_13_byte);
    let v262_13_tail = v262_13_cursor.make_map();
    v262_13_cursor.ascend(1);
    let v262_13_head = Path::from_slice(&[v262_13_byte]);
    let v263_2: Space = singleton(&(v262_13_head));
    let v263_3: Space = intersect(&(*CONSTANT_2),&(v263_2));
    let v263_4: Space = if has_head(&(v263_3)) { singleton(&[]) } else { Space::new() };
    drop(v263_3);
    let v263_5: Space = subtract(&(*CONSTANT_1),&(v263_4));
    drop(v263_4);
    let v263_8: Space = if (v263_5).is_empty() { Space::new() } else {
      let v264_6: Path = concat_path(&(*p0),&(v262_13_head));
      let mut v264_7 = Space::new();
      let mut v264_7_cursor = (v262_13_tail).read_zipper();
      for v264_7_byte in v264_7_cursor.child_mask().iter() {
        v264_7_cursor.descend_to_byte(v264_7_byte);
        let v264_7_tail = v264_7_cursor.make_map();
        v264_7_cursor.ascend(1);
        let v264_7_head = Path::from_slice(&[v264_7_byte]);
        let v265_2: Space = singleton(&(v264_7_head));
        let v265_3: Space = intersect(&(*CONSTANT_2),&(v265_2));
        let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
        drop(v265_3);
        let v265_5: Space = subtract(&(*CONSTANT_1),&(v265_4));
        drop(v265_4);
        let v265_8: Space = if (v265_5).is_empty() { Space::new() } else {
          let v266_6: Path = concat_path(&(v264_6),&(v264_7_head));
          let v266_7: Space = routine_38(c, &(v266_6), &(*p1), &(v264_7_tail), &(*s1));
          compose(&(v265_5),&(v266_7))
        };
        drop(v265_5);
        let v265_9: Space = intersect(&(*CONSTANT_2),&(v265_2));
        drop(v265_2);
        let v265_10: Space = if has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
        drop(v265_9);
        let v265_12: Space = if (v265_10).is_empty() { Space::new() } else {
          let v267_6: Path = concat_path(&(v264_6),&(v264_7_head));
          let v267_11: Space = routine_39(c, &(v267_6), &(*p1), &(v264_7_tail), &(*s1));
          drop(v267_6);
          compose(&(v265_10),&(v267_11))
        };
        drop(v265_10);
        let v265_13: Space = unite(&(v265_8),&(v265_12));
        v264_7.join_into((v265_13).clone());
      }
      drop(v264_7_cursor);
      compose(&(v263_5),&(v264_7))
    };
    drop(v263_5);
    let v263_9: Space = intersect(&(*CONSTANT_2),&(v263_2));
    drop(v263_2);
    let v263_10: Space = if has_head(&(v263_9)) { singleton(&[]) } else { Space::new() };
    drop(v263_9);
    let v263_12: Space = if (v263_10).is_empty() { Space::new() } else {
      let v268_6: Path = concat_path(&(*p0),&(v262_13_head));
      let mut v268_11 = Space::new();
      let mut v268_11_cursor = (v262_13_tail).read_zipper();
      for v268_11_byte in v268_11_cursor.child_mask().iter() {
        v268_11_cursor.descend_to_byte(v268_11_byte);
        let v268_11_tail = v268_11_cursor.make_map();
        v268_11_cursor.ascend(1);
        let v268_11_head = Path::from_slice(&[v268_11_byte]);
        let v269_2: Space = singleton(&(v268_11_head));
        let v269_3: Space = intersect(&(*CONSTANT_2),&(v269_2));
        let v269_4: Space = if has_head(&(v269_3)) { singleton(&[]) } else { Space::new() };
        drop(v269_3);
        let v269_5: Space = subtract(&(*CONSTANT_1),&(v269_4));
        drop(v269_4);
        let v269_8: Space = if (v269_5).is_empty() { Space::new() } else {
          let v270_6: Path = concat_path(&(v268_6),&(v268_11_head));
          let v270_7: Space = routine_38(c, &(v270_6), &(*p1), &(v268_11_tail), &(*s1));
          compose(&(v269_5),&(v270_7))
        };
        drop(v269_5);
        let v269_9: Space = intersect(&(*CONSTANT_2),&(v269_2));
        drop(v269_2);
        let v269_10: Space = if has_head(&(v269_9)) { singleton(&[]) } else { Space::new() };
        drop(v269_9);
        let v269_12: Space = if (v269_10).is_empty() { Space::new() } else {
          let v271_6: Path = concat_path(&(v268_6),&(v268_11_head));
          let v271_11: Space = routine_10(c, &(v271_6), &(*p1), &(v268_11_tail), &(*s1));
          drop(v271_6);
          compose(&(v269_10),&(v271_11))
        };
        drop(v269_10);
        let v269_13: Space = unite(&(v269_8),&(v269_12));
        v268_11.join_into((v269_13).clone());
      }
      drop(v268_11_cursor);
      drop(v268_6);
      compose(&(v263_10),&(v268_11))
    };
    drop(v263_10);
    let v263_13: Space = unite(&(v263_8),&(v263_12));
    v262_13.join_into((v263_13).clone());
  }
  drop(v262_13_cursor);
  (v262_13).clone()
}

fn routine_29(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v272_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v272_9: Space = unwrap(&(v272_8),&(*p0));
  drop(v272_8);
  let mut v272_16 = Space::new();
  let mut v272_16_cursor = (*s0).read_zipper();
  for v272_16_byte in v272_16_cursor.child_mask().iter() {
    v272_16_cursor.descend_to_byte(v272_16_byte);
    let v272_16_tail = v272_16_cursor.make_map();
    v272_16_cursor.ascend(1);
    let v272_16_head = Path::from_slice(&[v272_16_byte]);
    let v273_2: Space = singleton(&(v272_16_head));
    let v273_3: Space = intersect(&(*CONSTANT_2),&(v273_2));
    let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
    drop(v273_3);
    let v273_5: Space = subtract(&(*CONSTANT_1),&(v273_4));
    drop(v273_4);
    let v273_8: Space = if (v273_5).is_empty() { Space::new() } else {
      let v274_6: Path = concat_path(&(*p0),&(v272_16_head));
      let mut v274_7 = Space::new();
      let mut v274_7_cursor = (v272_16_tail).read_zipper();
      for v274_7_byte in v274_7_cursor.child_mask().iter() {
        v274_7_cursor.descend_to_byte(v274_7_byte);
        let v274_7_tail = v274_7_cursor.make_map();
        v274_7_cursor.ascend(1);
        let v274_7_head = Path::from_slice(&[v274_7_byte]);
        let v275_2: Space = singleton(&(v274_7_head));
        let v275_3: Space = intersect(&(*CONSTANT_2),&(v275_2));
        let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
        drop(v275_3);
        let v275_5: Space = subtract(&(*CONSTANT_1),&(v275_4));
        drop(v275_4);
        let v275_8: Space = if (v275_5).is_empty() { Space::new() } else {
          let v276_6: Path = concat_path(&(v274_6),&(v274_7_head));
          let v276_7: Space = routine_38(c, &(v276_6), &(*p1), &(v274_7_tail), &(*s1));
          compose(&(v275_5),&(v276_7))
        };
        drop(v275_5);
        let v275_9: Space = intersect(&(*CONSTANT_2),&(v275_2));
        drop(v275_2);
        let v275_10: Space = if has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
        drop(v275_9);
        let v275_12: Space = if (v275_10).is_empty() { Space::new() } else {
          let v277_6: Path = concat_path(&(v274_6),&(v274_7_head));
          let v277_11: Space = routine_39(c, &(v277_6), &(*p1), &(v274_7_tail), &(*s1));
          drop(v277_6);
          compose(&(v275_10),&(v277_11))
        };
        drop(v275_10);
        let v275_13: Space = unite(&(v275_8),&(v275_12));
        v274_7.join_into((v275_13).clone());
      }
      drop(v274_7_cursor);
      drop(v274_6);
      compose(&(v273_5),&(v274_7))
    };
    drop(v273_5);
    let v273_9: Space = intersect(&(*CONSTANT_2),&(v273_2));
    drop(v273_2);
    let v273_10: Space = if has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
    drop(v273_9);
    let v273_13: Space = if (v273_10).is_empty() { Space::new() } else {
      let v278_11: Space = unwrap(&(v272_9),&(v272_16_head));
      let mut v278_12 = Space::new();
      let mut v278_12_cursor = (v278_11).read_zipper();
      for v278_12_byte in v278_12_cursor.child_mask().iter() {
        v278_12_cursor.descend_to_byte(v278_12_byte);
        let v278_12_tail = v278_12_cursor.make_map();
        v278_12_cursor.ascend(1);
        let v278_12_head = Path::from_slice(&[v278_12_byte]);
        let v279_2: Space = singleton(&(v278_12_head));
        let v279_3: Space = intersect(&(*CONSTANT_2),&(v279_2));
        let v279_4: Space = if has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
        drop(v279_3);
        let v279_5: Space = subtract(&(*CONSTANT_1),&(v279_4));
        drop(v279_4);
        let v279_7: Space = if (v279_5).is_empty() { Space::new() } else {
          let v280_6: Space = routine_15(c, &(v278_12_head), &(*p1), &(v278_12_tail));
          compose(&(v279_5),&(v280_6))
        };
        drop(v279_5);
        let v279_8: Space = intersect(&(*CONSTANT_2),&(v279_2));
        drop(v279_2);
        let v279_9: Space = if has_head(&(v279_8)) { singleton(&[]) } else { Space::new() };
        drop(v279_8);
        let v279_11: Space = if (v279_9).is_empty() { Space::new() } else {
          let v281_10: Space = routine_16(c, &(v278_12_head), &(*p1), &(v278_12_tail));
          compose(&(v279_9),&(v281_10))
        };
        drop(v279_9);
        let v279_12: Space = unite(&(v279_7),&(v279_11));
        v278_12.join_into((v279_12).clone());
      }
      drop(v278_12_cursor);
      drop(v278_11);
      compose(&(v273_10),&(v278_12))
    };
    drop(v273_10);
    let v273_14: Space = unite(&(v273_8),&(v273_13));
    v272_16.join_into((v273_14).clone());
  }
  drop(v272_16_cursor);
  drop(v272_9);
  (v272_16).clone()
}

fn routine_30(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v282_12 = Space::new();
  let mut v282_12_cursor = (*s0).read_zipper();
  for v282_12_byte in v282_12_cursor.child_mask().iter() {
    v282_12_cursor.descend_to_byte(v282_12_byte);
    let v282_12_tail = v282_12_cursor.make_map();
    v282_12_cursor.ascend(1);
    let v282_12_head = Path::from_slice(&[v282_12_byte]);
    let v283_2: Space = singleton(&(v282_12_head));
    let v283_3: Space = intersect(&(*CONSTANT_2),&(v283_2));
    let v283_4: Space = if has_head(&(v283_3)) { singleton(&[]) } else { Space::new() };
    drop(v283_3);
    let v283_5: Space = subtract(&(*CONSTANT_1),&(v283_4));
    drop(v283_4);
    let v283_8: Space = if (v283_5).is_empty() { Space::new() } else {
      let v284_6: Path = concat_path(&(*p0),&(v282_12_head));
      let mut v284_7 = Space::new();
      let mut v284_7_cursor = (v282_12_tail).read_zipper();
      for v284_7_byte in v284_7_cursor.child_mask().iter() {
        v284_7_cursor.descend_to_byte(v284_7_byte);
        let v284_7_tail = v284_7_cursor.make_map();
        v284_7_cursor.ascend(1);
        let v284_7_head = Path::from_slice(&[v284_7_byte]);
        let v285_2: Space = singleton(&(v284_7_head));
        let v285_3: Space = intersect(&(*CONSTANT_2),&(v285_2));
        let v285_4: Space = if has_head(&(v285_3)) { singleton(&[]) } else { Space::new() };
        drop(v285_3);
        let v285_5: Space = subtract(&(*CONSTANT_1),&(v285_4));
        drop(v285_4);
        let v285_8: Space = if (v285_5).is_empty() { Space::new() } else {
          let v286_6: Path = concat_path(&(v284_6),&(v284_7_head));
          let v286_7: Space = routine_40(c, &(v286_6), &(*p1), &(v284_7_tail));
          compose(&(v285_5),&(v286_7))
        };
        drop(v285_5);
        let v285_9: Space = intersect(&(*CONSTANT_2),&(v285_2));
        drop(v285_2);
        let v285_10: Space = if has_head(&(v285_9)) { singleton(&[]) } else { Space::new() };
        drop(v285_9);
        let v285_12: Space = if (v285_10).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v284_6),&(v284_7_head));
          let v287_11: Space = routine_41(c, &(v287_6), &(*p1), &(v284_7_tail));
          drop(v287_6);
          compose(&(v285_10),&(v287_11))
        };
        drop(v285_10);
        let v285_13: Space = unite(&(v285_8),&(v285_12));
        v284_7.join_into((v285_13).clone());
      }
      drop(v284_7_cursor);
      compose(&(v283_5),&(v284_7))
    };
    drop(v283_5);
    let v283_9: Space = intersect(&(*CONSTANT_2),&(v283_2));
    drop(v283_2);
    let v283_10: Space = if has_head(&(v283_9)) { singleton(&[]) } else { Space::new() };
    drop(v283_9);
    let v283_12: Space = if (v283_10).is_empty() { Space::new() } else {
      let v288_6: Path = concat_path(&(*p0),&(v282_12_head));
      let mut v288_11 = Space::new();
      let mut v288_11_cursor = (v282_12_tail).read_zipper();
      for v288_11_byte in v288_11_cursor.child_mask().iter() {
        v288_11_cursor.descend_to_byte(v288_11_byte);
        let v288_11_tail = v288_11_cursor.make_map();
        v288_11_cursor.ascend(1);
        let v288_11_head = Path::from_slice(&[v288_11_byte]);
        let v289_2: Space = singleton(&(v288_11_head));
        let v289_3: Space = intersect(&(*CONSTANT_2),&(v289_2));
        let v289_4: Space = if has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
        drop(v289_3);
        let v289_5: Space = subtract(&(*CONSTANT_1),&(v289_4));
        drop(v289_4);
        let v289_8: Space = if (v289_5).is_empty() { Space::new() } else {
          let v290_6: Path = concat_path(&(v288_6),&(v288_11_head));
          let v290_7: Space = routine_40(c, &(v290_6), &(*p1), &(v288_11_tail));
          compose(&(v289_5),&(v290_7))
        };
        drop(v289_5);
        let v289_9: Space = intersect(&(*CONSTANT_2),&(v289_2));
        drop(v289_2);
        let v289_10: Space = if has_head(&(v289_9)) { singleton(&[]) } else { Space::new() };
        drop(v289_9);
        let v289_12: Space = if (v289_10).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v288_6),&(v288_11_head));
          let v291_11: Space = routine_21(c, &(v291_6), &(*p1), &(v288_11_tail));
          drop(v291_6);
          compose(&(v289_10),&(v291_11))
        };
        drop(v289_10);
        let v289_13: Space = unite(&(v289_8),&(v289_12));
        v288_11.join_into((v289_13).clone());
      }
      drop(v288_11_cursor);
      drop(v288_6);
      compose(&(v283_10),&(v288_11))
    };
    drop(v283_10);
    let v283_13: Space = unite(&(v283_8),&(v283_12));
    v282_12.join_into((v283_13).clone());
  }
  drop(v282_12_cursor);
  (v282_12).clone()
}

fn routine_31(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v292_9 = Space::new();
  let mut v292_9_cursor = (*s0).read_zipper();
  for v292_9_byte in v292_9_cursor.child_mask().iter() {
    v292_9_cursor.descend_to_byte(v292_9_byte);
    let v292_9_tail = v292_9_cursor.make_map();
    v292_9_cursor.ascend(1);
    let v292_9_head = Path::from_slice(&[v292_9_byte]);
    let v293_2: Space = singleton(&(v292_9_head));
    let v293_3: Space = intersect(&(*CONSTANT_2),&(v293_2));
    let v293_4: Space = if has_head(&(v293_3)) { singleton(&[]) } else { Space::new() };
    drop(v293_3);
    let v293_5: Space = subtract(&(*CONSTANT_1),&(v293_4));
    drop(v293_4);
    let v293_8: Space = if (v293_5).is_empty() { Space::new() } else {
      let v294_6: Path = concat_path(&(*p0),&(v292_9_head));
      let mut v294_7 = Space::new();
      let mut v294_7_cursor = (v292_9_tail).read_zipper();
      for v294_7_byte in v294_7_cursor.child_mask().iter() {
        v294_7_cursor.descend_to_byte(v294_7_byte);
        let v294_7_tail = v294_7_cursor.make_map();
        v294_7_cursor.ascend(1);
        let v294_7_head = Path::from_slice(&[v294_7_byte]);
        let v295_2: Space = singleton(&(v294_7_head));
        let v295_3: Space = intersect(&(*CONSTANT_2),&(v295_2));
        let v295_4: Space = if has_head(&(v295_3)) { singleton(&[]) } else { Space::new() };
        drop(v295_3);
        let v295_5: Space = subtract(&(*CONSTANT_1),&(v295_4));
        drop(v295_4);
        let v295_8: Space = if (v295_5).is_empty() { Space::new() } else {
          let v296_6: Path = concat_path(&(v294_6),&(v294_7_head));
          let v296_7: Space = routine_40(c, &(v296_6), &(*p1), &(v294_7_tail));
          compose(&(v295_5),&(v296_7))
        };
        drop(v295_5);
        let v295_9: Space = intersect(&(*CONSTANT_2),&(v295_2));
        drop(v295_2);
        let v295_10: Space = if has_head(&(v295_9)) { singleton(&[]) } else { Space::new() };
        drop(v295_9);
        let v295_12: Space = if (v295_10).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v294_6),&(v294_7_head));
          let v297_11: Space = routine_41(c, &(v297_6), &(*p1), &(v294_7_tail));
          drop(v297_6);
          compose(&(v295_10),&(v297_11))
        };
        drop(v295_10);
        let v295_13: Space = unite(&(v295_8),&(v295_12));
        v294_7.join_into((v295_13).clone());
      }
      drop(v294_7_cursor);
      compose(&(v293_5),&(v294_7))
    };
    drop(v293_5);
    let v293_9: Space = intersect(&(*CONSTANT_2),&(v293_2));
    drop(v293_2);
    let v293_10: Space = if has_head(&(v293_9)) { singleton(&[]) } else { Space::new() };
    drop(v293_9);
    let v293_11: Space = compose(&(v293_10),&(v292_9_tail));
    drop(v293_10);
    let v298_6: Path = concat_path(&(*p0),&(v292_9_head));
    let v293_12: Space = wrap(&(v293_11),&(v298_6));
    drop(v293_11);
    let v293_13: Space = wrap(&(v293_12),&(*p1));
    drop(v293_12);
    let v293_14: Space = unite(&(v293_8),&(v293_13));
    drop(v293_13);
    v292_9.join_into((v293_14).clone());
  }
  drop(v292_9_cursor);
  (v292_9).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v299_7 = Space::new();
  let mut v299_7_cursor = (*s0).read_zipper();
  for v299_7_byte in v299_7_cursor.child_mask().iter() {
    v299_7_cursor.descend_to_byte(v299_7_byte);
    let v299_7_tail = v299_7_cursor.make_map();
    v299_7_cursor.ascend(1);
    let v299_7_head = Path::from_slice(&[v299_7_byte]);
    let v300_2: Space = singleton(&(v299_7_head));
    let v300_3: Space = intersect(&(*CONSTANT_2),&(v300_2));
    let v300_4: Space = if has_head(&(v300_3)) { singleton(&[]) } else { Space::new() };
    drop(v300_3);
    let v300_5: Space = subtract(&(*CONSTANT_1),&(v300_4));
    drop(v300_4);
    let mut v300_6 = Space::new();
    let mut v300_6_cursor = (v299_7_tail).read_zipper();
    for v300_6_byte in v300_6_cursor.child_mask().iter() {
      v300_6_cursor.descend_to_byte(v300_6_byte);
      let v300_6_tail = v300_6_cursor.make_map();
      v300_6_cursor.ascend(1);
      let v300_6_head = Path::from_slice(&[v300_6_byte]);
      let v301_2: Space = Space::new();
      v300_6.join_into((v301_2).clone());
    }
    drop(v300_6_cursor);
    let v300_7: Space = compose(&(v300_5),&(v300_6));
    drop(v300_5);
    drop(v300_6);
    let v300_8: Space = intersect(&(*CONSTANT_2),&(v300_2));
    drop(v300_2);
    let v300_9: Space = if has_head(&(v300_8)) { singleton(&[]) } else { Space::new() };
    drop(v300_8);
    let v300_12: Space = if (v300_9).is_empty() { Space::new() } else {
      let v302_10: Path = concat_path(&(*p0),&(v299_7_head));
      let mut v302_11 = Space::new();
      let mut v302_11_cursor = (v299_7_tail).read_zipper();
      for v302_11_byte in v302_11_cursor.child_mask().iter() {
        v302_11_cursor.descend_to_byte(v302_11_byte);
        let v302_11_tail = v302_11_cursor.make_map();
        v302_11_cursor.ascend(1);
        let v302_11_head = Path::from_slice(&[v302_11_byte]);
        let v303_2: Space = singleton(&(v302_11_head));
        let v303_3: Space = intersect(&(*CONSTANT_2),&(v303_2));
        drop(v303_2);
        let v303_4: Space = if has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
        drop(v303_3);
        let v303_7: Space = if (v303_4).is_empty() { Space::new() } else {
          let v304_5: Path = concat_path(&(v302_10),&(v302_11_head));
          let v304_6: Space = routine_3(c, &(v304_5), &(v302_11_tail), &(*s1));
          drop(v304_5);
          compose(&(v303_4),&(v304_6))
        };
        drop(v303_4);
        v302_11.join_into((v303_7).clone());
      }
      drop(v302_11_cursor);
      drop(v302_10);
      compose(&(v300_9),&(v302_11))
    };
    drop(v300_9);
    let v300_13: Space = unite(&(v300_7),&(v300_12));
    drop(v300_7);
    v299_7.join_into((v300_13).clone());
  }
  drop(v299_7_cursor);
  (v299_7).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v305_9 = Space::new();
  let mut v305_9_cursor = (*s0).read_zipper();
  for v305_9_byte in v305_9_cursor.child_mask().iter() {
    v305_9_cursor.descend_to_byte(v305_9_byte);
    let v305_9_tail = v305_9_cursor.make_map();
    v305_9_cursor.ascend(1);
    let v305_9_head = Path::from_slice(&[v305_9_byte]);
    let v306_2: Space = singleton(&(v305_9_head));
    let v306_3: Space = intersect(&(*CONSTANT_2),&(v306_2));
    let v306_4: Space = if has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
    drop(v306_3);
    let v306_5: Space = subtract(&(*CONSTANT_1),&(v306_4));
    drop(v306_4);
    let mut v306_6 = Space::new();
    let mut v306_6_cursor = (v305_9_tail).read_zipper();
    for v306_6_byte in v306_6_cursor.child_mask().iter() {
      v306_6_cursor.descend_to_byte(v306_6_byte);
      let v306_6_tail = v306_6_cursor.make_map();
      v306_6_cursor.ascend(1);
      let v306_6_head = Path::from_slice(&[v306_6_byte]);
      let v307_2: Space = Space::new();
      v306_6.join_into((v307_2).clone());
    }
    drop(v306_6_cursor);
    let v306_7: Space = compose(&(v306_5),&(v306_6));
    drop(v306_5);
    drop(v306_6);
    let v306_8: Space = intersect(&(*CONSTANT_2),&(v306_2));
    drop(v306_2);
    let v306_9: Space = if has_head(&(v306_8)) { singleton(&[]) } else { Space::new() };
    drop(v306_8);
    let v306_12: Space = if (v306_9).is_empty() { Space::new() } else {
      let v308_10: Path = concat_path(&(*p0),&(v305_9_head));
      let mut v308_11 = Space::new();
      let mut v308_11_cursor = (v305_9_tail).read_zipper();
      for v308_11_byte in v308_11_cursor.child_mask().iter() {
        v308_11_cursor.descend_to_byte(v308_11_byte);
        let v308_11_tail = v308_11_cursor.make_map();
        v308_11_cursor.ascend(1);
        let v308_11_head = Path::from_slice(&[v308_11_byte]);
        let v309_2: Space = singleton(&(v308_11_head));
        let v309_3: Space = intersect(&(*CONSTANT_2),&(v309_2));
        let v309_4: Space = if has_head(&(v309_3)) { singleton(&[]) } else { Space::new() };
        drop(v309_3);
        let v309_5: Space = subtract(&(*CONSTANT_1),&(v309_4));
        drop(v309_4);
        let v309_7: Space = if (v309_5).is_empty() { Space::new() } else {
          let v310_6: Space = routine_6(c, &(v308_11_head), &(v308_10), &(v308_11_tail), &(*s1));
          compose(&(v309_5),&(v310_6))
        };
        drop(v309_5);
        let v309_8: Space = intersect(&(*CONSTANT_2),&(v309_2));
        drop(v309_2);
        let v309_9: Space = if has_head(&(v309_8)) { singleton(&[]) } else { Space::new() };
        drop(v309_8);
        let v309_11: Space = if (v309_9).is_empty() { Space::new() } else {
          let v311_10: Space = routine_7(c, &(v308_11_head), &(v308_10), &(v308_11_tail), &(*s1));
          compose(&(v309_9),&(v311_10))
        };
        drop(v309_9);
        let v309_12: Space = unite(&(v309_7),&(v309_11));
        v308_11.join_into((v309_12).clone());
      }
      drop(v308_11_cursor);
      drop(v308_10);
      compose(&(v306_9),&(v308_11))
    };
    drop(v306_9);
    let v306_13: Space = unite(&(v306_7),&(v306_12));
    drop(v306_7);
    v305_9.join_into((v306_13).clone());
  }
  drop(v305_9_cursor);
  (v305_9).clone()
}

fn routine_34(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v312_13 = Space::new();
  let mut v312_13_cursor = (*s0).read_zipper();
  for v312_13_byte in v312_13_cursor.child_mask().iter() {
    v312_13_cursor.descend_to_byte(v312_13_byte);
    let v312_13_tail = v312_13_cursor.make_map();
    v312_13_cursor.ascend(1);
    let v312_13_head = Path::from_slice(&[v312_13_byte]);
    let v313_2: Space = singleton(&(v312_13_head));
    let v313_3: Space = intersect(&(*CONSTANT_2),&(v313_2));
    let v313_4: Space = if has_head(&(v313_3)) { singleton(&[]) } else { Space::new() };
    drop(v313_3);
    let v313_5: Space = subtract(&(*CONSTANT_1),&(v313_4));
    drop(v313_4);
    let v313_8: Space = if (v313_5).is_empty() { Space::new() } else {
      let v314_6: Path = concat_path(&(*p0),&(v312_13_head));
      let mut v314_7 = Space::new();
      let mut v314_7_cursor = (v312_13_tail).read_zipper();
      for v314_7_byte in v314_7_cursor.child_mask().iter() {
        v314_7_cursor.descend_to_byte(v314_7_byte);
        let v314_7_tail = v314_7_cursor.make_map();
        v314_7_cursor.ascend(1);
        let v314_7_head = Path::from_slice(&[v314_7_byte]);
        let v315_2: Space = singleton(&(v314_7_head));
        let v315_3: Space = intersect(&(*CONSTANT_2),&(v315_2));
        let v315_4: Space = if has_head(&(v315_3)) { singleton(&[]) } else { Space::new() };
        drop(v315_3);
        let v315_5: Space = subtract(&(*CONSTANT_1),&(v315_4));
        drop(v315_4);
        let v315_8: Space = if (v315_5).is_empty() { Space::new() } else {
          let v316_6: Path = concat_path(&(v314_6),&(v314_7_head));
          let v316_7: Space = routine_42(c, &(v316_6), &(*p1), &(v314_7_tail), &(*s1));
          compose(&(v315_5),&(v316_7))
        };
        drop(v315_5);
        let v315_9: Space = intersect(&(*CONSTANT_2),&(v315_2));
        drop(v315_2);
        let v315_10: Space = if has_head(&(v315_9)) { singleton(&[]) } else { Space::new() };
        drop(v315_9);
        let v315_12: Space = if (v315_10).is_empty() { Space::new() } else {
          let v317_6: Path = concat_path(&(v314_6),&(v314_7_head));
          let v317_11: Space = routine_43(c, &(v317_6), &(*p1), &(v314_7_tail), &(*s1));
          drop(v317_6);
          compose(&(v315_10),&(v317_11))
        };
        drop(v315_10);
        let v315_13: Space = unite(&(v315_8),&(v315_12));
        v314_7.join_into((v315_13).clone());
      }
      drop(v314_7_cursor);
      compose(&(v313_5),&(v314_7))
    };
    drop(v313_5);
    let v313_9: Space = intersect(&(*CONSTANT_2),&(v313_2));
    drop(v313_2);
    let v313_10: Space = if has_head(&(v313_9)) { singleton(&[]) } else { Space::new() };
    drop(v313_9);
    let v313_12: Space = if (v313_10).is_empty() { Space::new() } else {
      let v318_6: Path = concat_path(&(*p0),&(v312_13_head));
      let mut v318_11 = Space::new();
      let mut v318_11_cursor = (v312_13_tail).read_zipper();
      for v318_11_byte in v318_11_cursor.child_mask().iter() {
        v318_11_cursor.descend_to_byte(v318_11_byte);
        let v318_11_tail = v318_11_cursor.make_map();
        v318_11_cursor.ascend(1);
        let v318_11_head = Path::from_slice(&[v318_11_byte]);
        let v319_2: Space = singleton(&(v318_11_head));
        let v319_3: Space = intersect(&(*CONSTANT_2),&(v319_2));
        let v319_4: Space = if has_head(&(v319_3)) { singleton(&[]) } else { Space::new() };
        drop(v319_3);
        let v319_5: Space = subtract(&(*CONSTANT_1),&(v319_4));
        drop(v319_4);
        let v319_8: Space = if (v319_5).is_empty() { Space::new() } else {
          let v320_6: Path = concat_path(&(v318_6),&(v318_11_head));
          let v320_7: Space = routine_42(c, &(v320_6), &(*p1), &(v318_11_tail), &(*s1));
          compose(&(v319_5),&(v320_7))
        };
        drop(v319_5);
        let v319_9: Space = intersect(&(*CONSTANT_2),&(v319_2));
        drop(v319_2);
        let v319_10: Space = if has_head(&(v319_9)) { singleton(&[]) } else { Space::new() };
        drop(v319_9);
        let v319_12: Space = if (v319_10).is_empty() { Space::new() } else {
          let v321_6: Path = concat_path(&(v318_6),&(v318_11_head));
          let v321_11: Space = routine_10(c, &(v321_6), &(*p1), &(v318_11_tail), &(*s1));
          drop(v321_6);
          compose(&(v319_10),&(v321_11))
        };
        drop(v319_10);
        let v319_13: Space = unite(&(v319_8),&(v319_12));
        v318_11.join_into((v319_13).clone());
      }
      drop(v318_11_cursor);
      drop(v318_6);
      compose(&(v313_10),&(v318_11))
    };
    drop(v313_10);
    let v313_13: Space = unite(&(v313_8),&(v313_12));
    v312_13.join_into((v313_13).clone());
  }
  drop(v312_13_cursor);
  (v312_13).clone()
}

fn routine_35(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v322_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v322_9: Space = unwrap(&(v322_8),&(*p0));
  drop(v322_8);
  let mut v322_16 = Space::new();
  let mut v322_16_cursor = (*s0).read_zipper();
  for v322_16_byte in v322_16_cursor.child_mask().iter() {
    v322_16_cursor.descend_to_byte(v322_16_byte);
    let v322_16_tail = v322_16_cursor.make_map();
    v322_16_cursor.ascend(1);
    let v322_16_head = Path::from_slice(&[v322_16_byte]);
    let v323_2: Space = singleton(&(v322_16_head));
    let v323_3: Space = intersect(&(*CONSTANT_2),&(v323_2));
    let v323_4: Space = if has_head(&(v323_3)) { singleton(&[]) } else { Space::new() };
    drop(v323_3);
    let v323_5: Space = subtract(&(*CONSTANT_1),&(v323_4));
    drop(v323_4);
    let v323_8: Space = if (v323_5).is_empty() { Space::new() } else {
      let v324_6: Path = concat_path(&(*p0),&(v322_16_head));
      let mut v324_7 = Space::new();
      let mut v324_7_cursor = (v322_16_tail).read_zipper();
      for v324_7_byte in v324_7_cursor.child_mask().iter() {
        v324_7_cursor.descend_to_byte(v324_7_byte);
        let v324_7_tail = v324_7_cursor.make_map();
        v324_7_cursor.ascend(1);
        let v324_7_head = Path::from_slice(&[v324_7_byte]);
        let v325_2: Space = singleton(&(v324_7_head));
        let v325_3: Space = intersect(&(*CONSTANT_2),&(v325_2));
        let v325_4: Space = if has_head(&(v325_3)) { singleton(&[]) } else { Space::new() };
        drop(v325_3);
        let v325_5: Space = subtract(&(*CONSTANT_1),&(v325_4));
        drop(v325_4);
        let v325_8: Space = if (v325_5).is_empty() { Space::new() } else {
          let v326_6: Path = concat_path(&(v324_6),&(v324_7_head));
          let v326_7: Space = routine_42(c, &(v326_6), &(*p1), &(v324_7_tail), &(*s1));
          compose(&(v325_5),&(v326_7))
        };
        drop(v325_5);
        let v325_9: Space = intersect(&(*CONSTANT_2),&(v325_2));
        drop(v325_2);
        let v325_10: Space = if has_head(&(v325_9)) { singleton(&[]) } else { Space::new() };
        drop(v325_9);
        let v325_12: Space = if (v325_10).is_empty() { Space::new() } else {
          let v327_6: Path = concat_path(&(v324_6),&(v324_7_head));
          let v327_11: Space = routine_43(c, &(v327_6), &(*p1), &(v324_7_tail), &(*s1));
          drop(v327_6);
          compose(&(v325_10),&(v327_11))
        };
        drop(v325_10);
        let v325_13: Space = unite(&(v325_8),&(v325_12));
        v324_7.join_into((v325_13).clone());
      }
      drop(v324_7_cursor);
      drop(v324_6);
      compose(&(v323_5),&(v324_7))
    };
    drop(v323_5);
    let v323_9: Space = intersect(&(*CONSTANT_2),&(v323_2));
    drop(v323_2);
    let v323_10: Space = if has_head(&(v323_9)) { singleton(&[]) } else { Space::new() };
    drop(v323_9);
    let v323_13: Space = if (v323_10).is_empty() { Space::new() } else {
      let v328_11: Space = unwrap(&(v322_9),&(v322_16_head));
      let mut v328_12 = Space::new();
      let mut v328_12_cursor = (v328_11).read_zipper();
      for v328_12_byte in v328_12_cursor.child_mask().iter() {
        v328_12_cursor.descend_to_byte(v328_12_byte);
        let v328_12_tail = v328_12_cursor.make_map();
        v328_12_cursor.ascend(1);
        let v328_12_head = Path::from_slice(&[v328_12_byte]);
        let v329_2: Space = singleton(&(v328_12_head));
        let v329_3: Space = intersect(&(*CONSTANT_2),&(v329_2));
        let v329_4: Space = if has_head(&(v329_3)) { singleton(&[]) } else { Space::new() };
        drop(v329_3);
        let v329_5: Space = subtract(&(*CONSTANT_1),&(v329_4));
        drop(v329_4);
        let v329_7: Space = if (v329_5).is_empty() { Space::new() } else {
          let v330_6: Space = routine_15(c, &(v328_12_head), &(*p1), &(v328_12_tail));
          compose(&(v329_5),&(v330_6))
        };
        drop(v329_5);
        let v329_8: Space = intersect(&(*CONSTANT_2),&(v329_2));
        drop(v329_2);
        let v329_9: Space = if has_head(&(v329_8)) { singleton(&[]) } else { Space::new() };
        drop(v329_8);
        let v329_11: Space = if (v329_9).is_empty() { Space::new() } else {
          let v331_10: Space = routine_16(c, &(v328_12_head), &(*p1), &(v328_12_tail));
          compose(&(v329_9),&(v331_10))
        };
        drop(v329_9);
        let v329_12: Space = unite(&(v329_7),&(v329_11));
        v328_12.join_into((v329_12).clone());
      }
      drop(v328_12_cursor);
      drop(v328_11);
      compose(&(v323_10),&(v328_12))
    };
    drop(v323_10);
    let v323_14: Space = unite(&(v323_8),&(v323_13));
    v322_16.join_into((v323_14).clone());
  }
  drop(v322_16_cursor);
  drop(v322_9);
  (v322_16).clone()
}

fn routine_36(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v332_12 = Space::new();
  let mut v332_12_cursor = (*s0).read_zipper();
  for v332_12_byte in v332_12_cursor.child_mask().iter() {
    v332_12_cursor.descend_to_byte(v332_12_byte);
    let v332_12_tail = v332_12_cursor.make_map();
    v332_12_cursor.ascend(1);
    let v332_12_head = Path::from_slice(&[v332_12_byte]);
    let v333_2: Space = singleton(&(v332_12_head));
    let v333_3: Space = intersect(&(*CONSTANT_2),&(v333_2));
    let v333_4: Space = if has_head(&(v333_3)) { singleton(&[]) } else { Space::new() };
    drop(v333_3);
    let v333_5: Space = subtract(&(*CONSTANT_1),&(v333_4));
    drop(v333_4);
    let v333_8: Space = if (v333_5).is_empty() { Space::new() } else {
      let v334_6: Path = concat_path(&(*p0),&(v332_12_head));
      let mut v334_7 = Space::new();
      let mut v334_7_cursor = (v332_12_tail).read_zipper();
      for v334_7_byte in v334_7_cursor.child_mask().iter() {
        v334_7_cursor.descend_to_byte(v334_7_byte);
        let v334_7_tail = v334_7_cursor.make_map();
        v334_7_cursor.ascend(1);
        let v334_7_head = Path::from_slice(&[v334_7_byte]);
        let v335_2: Space = singleton(&(v334_7_head));
        let v335_3: Space = intersect(&(*CONSTANT_2),&(v335_2));
        let v335_4: Space = if has_head(&(v335_3)) { singleton(&[]) } else { Space::new() };
        drop(v335_3);
        let v335_5: Space = subtract(&(*CONSTANT_1),&(v335_4));
        drop(v335_4);
        let v335_8: Space = if (v335_5).is_empty() { Space::new() } else {
          let v336_6: Path = concat_path(&(v334_6),&(v334_7_head));
          let v336_7: Space = routine_44(c, &(v336_6), &(*p1), &(v334_7_tail));
          compose(&(v335_5),&(v336_7))
        };
        drop(v335_5);
        let v335_9: Space = intersect(&(*CONSTANT_2),&(v335_2));
        drop(v335_2);
        let v335_10: Space = if has_head(&(v335_9)) { singleton(&[]) } else { Space::new() };
        drop(v335_9);
        let v335_12: Space = if (v335_10).is_empty() { Space::new() } else {
          let v337_6: Path = concat_path(&(v334_6),&(v334_7_head));
          let v337_11: Space = routine_45(c, &(v337_6), &(*p1), &(v334_7_tail));
          drop(v337_6);
          compose(&(v335_10),&(v337_11))
        };
        drop(v335_10);
        let v335_13: Space = unite(&(v335_8),&(v335_12));
        v334_7.join_into((v335_13).clone());
      }
      drop(v334_7_cursor);
      compose(&(v333_5),&(v334_7))
    };
    drop(v333_5);
    let v333_9: Space = intersect(&(*CONSTANT_2),&(v333_2));
    drop(v333_2);
    let v333_10: Space = if has_head(&(v333_9)) { singleton(&[]) } else { Space::new() };
    drop(v333_9);
    let v333_12: Space = if (v333_10).is_empty() { Space::new() } else {
      let v338_6: Path = concat_path(&(*p0),&(v332_12_head));
      let mut v338_11 = Space::new();
      let mut v338_11_cursor = (v332_12_tail).read_zipper();
      for v338_11_byte in v338_11_cursor.child_mask().iter() {
        v338_11_cursor.descend_to_byte(v338_11_byte);
        let v338_11_tail = v338_11_cursor.make_map();
        v338_11_cursor.ascend(1);
        let v338_11_head = Path::from_slice(&[v338_11_byte]);
        let v339_2: Space = singleton(&(v338_11_head));
        let v339_3: Space = intersect(&(*CONSTANT_2),&(v339_2));
        let v339_4: Space = if has_head(&(v339_3)) { singleton(&[]) } else { Space::new() };
        drop(v339_3);
        let v339_5: Space = subtract(&(*CONSTANT_1),&(v339_4));
        drop(v339_4);
        let v339_8: Space = if (v339_5).is_empty() { Space::new() } else {
          let v340_6: Path = concat_path(&(v338_6),&(v338_11_head));
          let v340_7: Space = routine_44(c, &(v340_6), &(*p1), &(v338_11_tail));
          compose(&(v339_5),&(v340_7))
        };
        drop(v339_5);
        let v339_9: Space = intersect(&(*CONSTANT_2),&(v339_2));
        drop(v339_2);
        let v339_10: Space = if has_head(&(v339_9)) { singleton(&[]) } else { Space::new() };
        drop(v339_9);
        let v339_12: Space = if (v339_10).is_empty() { Space::new() } else {
          let v341_6: Path = concat_path(&(v338_6),&(v338_11_head));
          let v341_11: Space = routine_21(c, &(v341_6), &(*p1), &(v338_11_tail));
          drop(v341_6);
          compose(&(v339_10),&(v341_11))
        };
        drop(v339_10);
        let v339_13: Space = unite(&(v339_8),&(v339_12));
        v338_11.join_into((v339_13).clone());
      }
      drop(v338_11_cursor);
      drop(v338_6);
      compose(&(v333_10),&(v338_11))
    };
    drop(v333_10);
    let v333_13: Space = unite(&(v333_8),&(v333_12));
    v332_12.join_into((v333_13).clone());
  }
  drop(v332_12_cursor);
  (v332_12).clone()
}

fn routine_37(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v342_9 = Space::new();
  let mut v342_9_cursor = (*s0).read_zipper();
  for v342_9_byte in v342_9_cursor.child_mask().iter() {
    v342_9_cursor.descend_to_byte(v342_9_byte);
    let v342_9_tail = v342_9_cursor.make_map();
    v342_9_cursor.ascend(1);
    let v342_9_head = Path::from_slice(&[v342_9_byte]);
    let v343_2: Space = singleton(&(v342_9_head));
    let v343_3: Space = intersect(&(*CONSTANT_2),&(v343_2));
    let v343_4: Space = if has_head(&(v343_3)) { singleton(&[]) } else { Space::new() };
    drop(v343_3);
    let v343_5: Space = subtract(&(*CONSTANT_1),&(v343_4));
    drop(v343_4);
    let v343_8: Space = if (v343_5).is_empty() { Space::new() } else {
      let v344_6: Path = concat_path(&(*p0),&(v342_9_head));
      let mut v344_7 = Space::new();
      let mut v344_7_cursor = (v342_9_tail).read_zipper();
      for v344_7_byte in v344_7_cursor.child_mask().iter() {
        v344_7_cursor.descend_to_byte(v344_7_byte);
        let v344_7_tail = v344_7_cursor.make_map();
        v344_7_cursor.ascend(1);
        let v344_7_head = Path::from_slice(&[v344_7_byte]);
        let v345_2: Space = singleton(&(v344_7_head));
        let v345_3: Space = intersect(&(*CONSTANT_2),&(v345_2));
        let v345_4: Space = if has_head(&(v345_3)) { singleton(&[]) } else { Space::new() };
        drop(v345_3);
        let v345_5: Space = subtract(&(*CONSTANT_1),&(v345_4));
        drop(v345_4);
        let v345_8: Space = if (v345_5).is_empty() { Space::new() } else {
          let v346_6: Path = concat_path(&(v344_6),&(v344_7_head));
          let v346_7: Space = routine_44(c, &(v346_6), &(*p1), &(v344_7_tail));
          compose(&(v345_5),&(v346_7))
        };
        drop(v345_5);
        let v345_9: Space = intersect(&(*CONSTANT_2),&(v345_2));
        drop(v345_2);
        let v345_10: Space = if has_head(&(v345_9)) { singleton(&[]) } else { Space::new() };
        drop(v345_9);
        let v345_12: Space = if (v345_10).is_empty() { Space::new() } else {
          let v347_6: Path = concat_path(&(v344_6),&(v344_7_head));
          let v347_11: Space = routine_45(c, &(v347_6), &(*p1), &(v344_7_tail));
          drop(v347_6);
          compose(&(v345_10),&(v347_11))
        };
        drop(v345_10);
        let v345_13: Space = unite(&(v345_8),&(v345_12));
        v344_7.join_into((v345_13).clone());
      }
      drop(v344_7_cursor);
      compose(&(v343_5),&(v344_7))
    };
    drop(v343_5);
    let v343_9: Space = intersect(&(*CONSTANT_2),&(v343_2));
    drop(v343_2);
    let v343_10: Space = if has_head(&(v343_9)) { singleton(&[]) } else { Space::new() };
    drop(v343_9);
    let v343_11: Space = compose(&(v343_10),&(v342_9_tail));
    drop(v343_10);
    let v348_6: Path = concat_path(&(*p0),&(v342_9_head));
    let v343_12: Space = wrap(&(v343_11),&(v348_6));
    drop(v343_11);
    let v343_13: Space = wrap(&(v343_12),&(*p1));
    drop(v343_12);
    let v343_14: Space = unite(&(v343_8),&(v343_13));
    drop(v343_13);
    v342_9.join_into((v343_14).clone());
  }
  drop(v342_9_cursor);
  (v342_9).clone()
}

fn routine_38(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v349_13 = Space::new();
  let mut v349_13_cursor = (*s0).read_zipper();
  for v349_13_byte in v349_13_cursor.child_mask().iter() {
    v349_13_cursor.descend_to_byte(v349_13_byte);
    let v349_13_tail = v349_13_cursor.make_map();
    v349_13_cursor.ascend(1);
    let v349_13_head = Path::from_slice(&[v349_13_byte]);
    let v350_2: Space = singleton(&(v349_13_head));
    let v350_3: Space = intersect(&(*CONSTANT_2),&(v350_2));
    let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
    drop(v350_3);
    let v350_5: Space = subtract(&(*CONSTANT_1),&(v350_4));
    drop(v350_4);
    let v350_8: Space = if (v350_5).is_empty() { Space::new() } else {
      let v351_6: Path = concat_path(&(*p0),&(v349_13_head));
      let mut v351_7 = Space::new();
      let mut v351_7_cursor = (v349_13_tail).read_zipper();
      for v351_7_byte in v351_7_cursor.child_mask().iter() {
        v351_7_cursor.descend_to_byte(v351_7_byte);
        let v351_7_tail = v351_7_cursor.make_map();
        v351_7_cursor.ascend(1);
        let v351_7_head = Path::from_slice(&[v351_7_byte]);
        let v352_2: Space = singleton(&(v351_7_head));
        let v352_3: Space = intersect(&(*CONSTANT_2),&(v352_2));
        let v352_4: Space = if has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
        drop(v352_3);
        let v352_5: Space = subtract(&(*CONSTANT_1),&(v352_4));
        drop(v352_4);
        let v352_8: Space = if (v352_5).is_empty() { Space::new() } else {
          let v353_6: Path = concat_path(&(v351_6),&(v351_7_head));
          let v353_7: Space = routine_46(c, &(v353_6), &(*p1), &(v351_7_tail), &(*s1));
          compose(&(v352_5),&(v353_7))
        };
        drop(v352_5);
        let v352_9: Space = intersect(&(*CONSTANT_2),&(v352_2));
        drop(v352_2);
        let v352_10: Space = if has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
        drop(v352_9);
        let v352_12: Space = if (v352_10).is_empty() { Space::new() } else {
          let v354_6: Path = concat_path(&(v351_6),&(v351_7_head));
          let v354_11: Space = routine_47(c, &(v354_6), &(*p1), &(v351_7_tail), &(*s1));
          drop(v354_6);
          compose(&(v352_10),&(v354_11))
        };
        drop(v352_10);
        let v352_13: Space = unite(&(v352_8),&(v352_12));
        v351_7.join_into((v352_13).clone());
      }
      drop(v351_7_cursor);
      compose(&(v350_5),&(v351_7))
    };
    drop(v350_5);
    let v350_9: Space = intersect(&(*CONSTANT_2),&(v350_2));
    drop(v350_2);
    let v350_10: Space = if has_head(&(v350_9)) { singleton(&[]) } else { Space::new() };
    drop(v350_9);
    let v350_12: Space = if (v350_10).is_empty() { Space::new() } else {
      let v355_6: Path = concat_path(&(*p0),&(v349_13_head));
      let mut v355_11 = Space::new();
      let mut v355_11_cursor = (v349_13_tail).read_zipper();
      for v355_11_byte in v355_11_cursor.child_mask().iter() {
        v355_11_cursor.descend_to_byte(v355_11_byte);
        let v355_11_tail = v355_11_cursor.make_map();
        v355_11_cursor.ascend(1);
        let v355_11_head = Path::from_slice(&[v355_11_byte]);
        let v356_2: Space = singleton(&(v355_11_head));
        let v356_3: Space = intersect(&(*CONSTANT_2),&(v356_2));
        let v356_4: Space = if has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
        drop(v356_3);
        let v356_5: Space = subtract(&(*CONSTANT_1),&(v356_4));
        drop(v356_4);
        let v356_8: Space = if (v356_5).is_empty() { Space::new() } else {
          let v357_6: Path = concat_path(&(v355_6),&(v355_11_head));
          let v357_7: Space = routine_46(c, &(v357_6), &(*p1), &(v355_11_tail), &(*s1));
          compose(&(v356_5),&(v357_7))
        };
        drop(v356_5);
        let v356_9: Space = intersect(&(*CONSTANT_2),&(v356_2));
        drop(v356_2);
        let v356_10: Space = if has_head(&(v356_9)) { singleton(&[]) } else { Space::new() };
        drop(v356_9);
        let v356_12: Space = if (v356_10).is_empty() { Space::new() } else {
          let v358_6: Path = concat_path(&(v355_6),&(v355_11_head));
          let v358_11: Space = routine_10(c, &(v358_6), &(*p1), &(v355_11_tail), &(*s1));
          drop(v358_6);
          compose(&(v356_10),&(v358_11))
        };
        drop(v356_10);
        let v356_13: Space = unite(&(v356_8),&(v356_12));
        v355_11.join_into((v356_13).clone());
      }
      drop(v355_11_cursor);
      drop(v355_6);
      compose(&(v350_10),&(v355_11))
    };
    drop(v350_10);
    let v350_13: Space = unite(&(v350_8),&(v350_12));
    v349_13.join_into((v350_13).clone());
  }
  drop(v349_13_cursor);
  (v349_13).clone()
}

fn routine_39(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v359_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v359_9: Space = unwrap(&(v359_8),&(*p0));
  drop(v359_8);
  let mut v359_16 = Space::new();
  let mut v359_16_cursor = (*s0).read_zipper();
  for v359_16_byte in v359_16_cursor.child_mask().iter() {
    v359_16_cursor.descend_to_byte(v359_16_byte);
    let v359_16_tail = v359_16_cursor.make_map();
    v359_16_cursor.ascend(1);
    let v359_16_head = Path::from_slice(&[v359_16_byte]);
    let v360_2: Space = singleton(&(v359_16_head));
    let v360_3: Space = intersect(&(*CONSTANT_2),&(v360_2));
    let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
    drop(v360_3);
    let v360_5: Space = subtract(&(*CONSTANT_1),&(v360_4));
    drop(v360_4);
    let v360_8: Space = if (v360_5).is_empty() { Space::new() } else {
      let v361_6: Path = concat_path(&(*p0),&(v359_16_head));
      let mut v361_7 = Space::new();
      let mut v361_7_cursor = (v359_16_tail).read_zipper();
      for v361_7_byte in v361_7_cursor.child_mask().iter() {
        v361_7_cursor.descend_to_byte(v361_7_byte);
        let v361_7_tail = v361_7_cursor.make_map();
        v361_7_cursor.ascend(1);
        let v361_7_head = Path::from_slice(&[v361_7_byte]);
        let v362_2: Space = singleton(&(v361_7_head));
        let v362_3: Space = intersect(&(*CONSTANT_2),&(v362_2));
        let v362_4: Space = if has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
        drop(v362_3);
        let v362_5: Space = subtract(&(*CONSTANT_1),&(v362_4));
        drop(v362_4);
        let v362_8: Space = if (v362_5).is_empty() { Space::new() } else {
          let v363_6: Path = concat_path(&(v361_6),&(v361_7_head));
          let v363_7: Space = routine_46(c, &(v363_6), &(*p1), &(v361_7_tail), &(*s1));
          compose(&(v362_5),&(v363_7))
        };
        drop(v362_5);
        let v362_9: Space = intersect(&(*CONSTANT_2),&(v362_2));
        drop(v362_2);
        let v362_10: Space = if has_head(&(v362_9)) { singleton(&[]) } else { Space::new() };
        drop(v362_9);
        let v362_12: Space = if (v362_10).is_empty() { Space::new() } else {
          let v364_6: Path = concat_path(&(v361_6),&(v361_7_head));
          let v364_11: Space = routine_47(c, &(v364_6), &(*p1), &(v361_7_tail), &(*s1));
          drop(v364_6);
          compose(&(v362_10),&(v364_11))
        };
        drop(v362_10);
        let v362_13: Space = unite(&(v362_8),&(v362_12));
        v361_7.join_into((v362_13).clone());
      }
      drop(v361_7_cursor);
      drop(v361_6);
      compose(&(v360_5),&(v361_7))
    };
    drop(v360_5);
    let v360_9: Space = intersect(&(*CONSTANT_2),&(v360_2));
    drop(v360_2);
    let v360_10: Space = if has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
    drop(v360_9);
    let v360_13: Space = if (v360_10).is_empty() { Space::new() } else {
      let v365_11: Space = unwrap(&(v359_9),&(v359_16_head));
      let mut v365_12 = Space::new();
      let mut v365_12_cursor = (v365_11).read_zipper();
      for v365_12_byte in v365_12_cursor.child_mask().iter() {
        v365_12_cursor.descend_to_byte(v365_12_byte);
        let v365_12_tail = v365_12_cursor.make_map();
        v365_12_cursor.ascend(1);
        let v365_12_head = Path::from_slice(&[v365_12_byte]);
        let v366_2: Space = singleton(&(v365_12_head));
        let v366_3: Space = intersect(&(*CONSTANT_2),&(v366_2));
        let v366_4: Space = if has_head(&(v366_3)) { singleton(&[]) } else { Space::new() };
        drop(v366_3);
        let v366_5: Space = subtract(&(*CONSTANT_1),&(v366_4));
        drop(v366_4);
        let v366_7: Space = if (v366_5).is_empty() { Space::new() } else {
          let v367_6: Space = routine_15(c, &(v365_12_head), &(*p1), &(v365_12_tail));
          compose(&(v366_5),&(v367_6))
        };
        drop(v366_5);
        let v366_8: Space = intersect(&(*CONSTANT_2),&(v366_2));
        drop(v366_2);
        let v366_9: Space = if has_head(&(v366_8)) { singleton(&[]) } else { Space::new() };
        drop(v366_8);
        let v366_11: Space = if (v366_9).is_empty() { Space::new() } else {
          let v368_10: Space = routine_16(c, &(v365_12_head), &(*p1), &(v365_12_tail));
          compose(&(v366_9),&(v368_10))
        };
        drop(v366_9);
        let v366_12: Space = unite(&(v366_7),&(v366_11));
        v365_12.join_into((v366_12).clone());
      }
      drop(v365_12_cursor);
      drop(v365_11);
      compose(&(v360_10),&(v365_12))
    };
    drop(v360_10);
    let v360_14: Space = unite(&(v360_8),&(v360_13));
    v359_16.join_into((v360_14).clone());
  }
  drop(v359_16_cursor);
  drop(v359_9);
  (v359_16).clone()
}

fn routine_40(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v369_12 = Space::new();
  let mut v369_12_cursor = (*s0).read_zipper();
  for v369_12_byte in v369_12_cursor.child_mask().iter() {
    v369_12_cursor.descend_to_byte(v369_12_byte);
    let v369_12_tail = v369_12_cursor.make_map();
    v369_12_cursor.ascend(1);
    let v369_12_head = Path::from_slice(&[v369_12_byte]);
    let v370_2: Space = singleton(&(v369_12_head));
    let v370_3: Space = intersect(&(*CONSTANT_2),&(v370_2));
    let v370_4: Space = if has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
    drop(v370_3);
    let v370_5: Space = subtract(&(*CONSTANT_1),&(v370_4));
    drop(v370_4);
    let v370_8: Space = if (v370_5).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&(v369_12_head));
      let mut v371_7 = Space::new();
      let mut v371_7_cursor = (v369_12_tail).read_zipper();
      for v371_7_byte in v371_7_cursor.child_mask().iter() {
        v371_7_cursor.descend_to_byte(v371_7_byte);
        let v371_7_tail = v371_7_cursor.make_map();
        v371_7_cursor.ascend(1);
        let v371_7_head = Path::from_slice(&[v371_7_byte]);
        let v372_2: Space = singleton(&(v371_7_head));
        let v372_3: Space = intersect(&(*CONSTANT_2),&(v372_2));
        let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
        drop(v372_3);
        let v372_5: Space = subtract(&(*CONSTANT_1),&(v372_4));
        drop(v372_4);
        let v372_8: Space = if (v372_5).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v371_6),&(v371_7_head));
          let v373_7: Space = routine_48(c, &(v373_6), &(*p1), &(v371_7_tail));
          compose(&(v372_5),&(v373_7))
        };
        drop(v372_5);
        let v372_9: Space = intersect(&(*CONSTANT_2),&(v372_2));
        drop(v372_2);
        let v372_10: Space = if has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
        drop(v372_9);
        let v372_12: Space = if (v372_10).is_empty() { Space::new() } else {
          let v374_6: Path = concat_path(&(v371_6),&(v371_7_head));
          let v374_11: Space = routine_49(c, &(v374_6), &(*p1), &(v371_7_tail));
          drop(v374_6);
          compose(&(v372_10),&(v374_11))
        };
        drop(v372_10);
        let v372_13: Space = unite(&(v372_8),&(v372_12));
        v371_7.join_into((v372_13).clone());
      }
      drop(v371_7_cursor);
      compose(&(v370_5),&(v371_7))
    };
    drop(v370_5);
    let v370_9: Space = intersect(&(*CONSTANT_2),&(v370_2));
    drop(v370_2);
    let v370_10: Space = if has_head(&(v370_9)) { singleton(&[]) } else { Space::new() };
    drop(v370_9);
    let v370_12: Space = if (v370_10).is_empty() { Space::new() } else {
      let v375_6: Path = concat_path(&(*p0),&(v369_12_head));
      let mut v375_11 = Space::new();
      let mut v375_11_cursor = (v369_12_tail).read_zipper();
      for v375_11_byte in v375_11_cursor.child_mask().iter() {
        v375_11_cursor.descend_to_byte(v375_11_byte);
        let v375_11_tail = v375_11_cursor.make_map();
        v375_11_cursor.ascend(1);
        let v375_11_head = Path::from_slice(&[v375_11_byte]);
        let v376_2: Space = singleton(&(v375_11_head));
        let v376_3: Space = intersect(&(*CONSTANT_2),&(v376_2));
        let v376_4: Space = if has_head(&(v376_3)) { singleton(&[]) } else { Space::new() };
        drop(v376_3);
        let v376_5: Space = subtract(&(*CONSTANT_1),&(v376_4));
        drop(v376_4);
        let v376_8: Space = if (v376_5).is_empty() { Space::new() } else {
          let v377_6: Path = concat_path(&(v375_6),&(v375_11_head));
          let v377_7: Space = routine_48(c, &(v377_6), &(*p1), &(v375_11_tail));
          compose(&(v376_5),&(v377_7))
        };
        drop(v376_5);
        let v376_9: Space = intersect(&(*CONSTANT_2),&(v376_2));
        drop(v376_2);
        let v376_10: Space = if has_head(&(v376_9)) { singleton(&[]) } else { Space::new() };
        drop(v376_9);
        let v376_12: Space = if (v376_10).is_empty() { Space::new() } else {
          let v378_6: Path = concat_path(&(v375_6),&(v375_11_head));
          let v378_11: Space = routine_21(c, &(v378_6), &(*p1), &(v375_11_tail));
          drop(v378_6);
          compose(&(v376_10),&(v378_11))
        };
        drop(v376_10);
        let v376_13: Space = unite(&(v376_8),&(v376_12));
        v375_11.join_into((v376_13).clone());
      }
      drop(v375_11_cursor);
      drop(v375_6);
      compose(&(v370_10),&(v375_11))
    };
    drop(v370_10);
    let v370_13: Space = unite(&(v370_8),&(v370_12));
    v369_12.join_into((v370_13).clone());
  }
  drop(v369_12_cursor);
  (v369_12).clone()
}

fn routine_41(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v379_9 = Space::new();
  let mut v379_9_cursor = (*s0).read_zipper();
  for v379_9_byte in v379_9_cursor.child_mask().iter() {
    v379_9_cursor.descend_to_byte(v379_9_byte);
    let v379_9_tail = v379_9_cursor.make_map();
    v379_9_cursor.ascend(1);
    let v379_9_head = Path::from_slice(&[v379_9_byte]);
    let v380_2: Space = singleton(&(v379_9_head));
    let v380_3: Space = intersect(&(*CONSTANT_2),&(v380_2));
    let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
    drop(v380_3);
    let v380_5: Space = subtract(&(*CONSTANT_1),&(v380_4));
    drop(v380_4);
    let v380_8: Space = if (v380_5).is_empty() { Space::new() } else {
      let v381_6: Path = concat_path(&(*p0),&(v379_9_head));
      let mut v381_7 = Space::new();
      let mut v381_7_cursor = (v379_9_tail).read_zipper();
      for v381_7_byte in v381_7_cursor.child_mask().iter() {
        v381_7_cursor.descend_to_byte(v381_7_byte);
        let v381_7_tail = v381_7_cursor.make_map();
        v381_7_cursor.ascend(1);
        let v381_7_head = Path::from_slice(&[v381_7_byte]);
        let v382_2: Space = singleton(&(v381_7_head));
        let v382_3: Space = intersect(&(*CONSTANT_2),&(v382_2));
        let v382_4: Space = if has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
        drop(v382_3);
        let v382_5: Space = subtract(&(*CONSTANT_1),&(v382_4));
        drop(v382_4);
        let v382_8: Space = if (v382_5).is_empty() { Space::new() } else {
          let v383_6: Path = concat_path(&(v381_6),&(v381_7_head));
          let v383_7: Space = routine_48(c, &(v383_6), &(*p1), &(v381_7_tail));
          compose(&(v382_5),&(v383_7))
        };
        drop(v382_5);
        let v382_9: Space = intersect(&(*CONSTANT_2),&(v382_2));
        drop(v382_2);
        let v382_10: Space = if has_head(&(v382_9)) { singleton(&[]) } else { Space::new() };
        drop(v382_9);
        let v382_12: Space = if (v382_10).is_empty() { Space::new() } else {
          let v384_6: Path = concat_path(&(v381_6),&(v381_7_head));
          let v384_11: Space = routine_49(c, &(v384_6), &(*p1), &(v381_7_tail));
          drop(v384_6);
          compose(&(v382_10),&(v384_11))
        };
        drop(v382_10);
        let v382_13: Space = unite(&(v382_8),&(v382_12));
        v381_7.join_into((v382_13).clone());
      }
      drop(v381_7_cursor);
      compose(&(v380_5),&(v381_7))
    };
    drop(v380_5);
    let v380_9: Space = intersect(&(*CONSTANT_2),&(v380_2));
    drop(v380_2);
    let v380_10: Space = if has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
    drop(v380_9);
    let v380_11: Space = compose(&(v380_10),&(v379_9_tail));
    drop(v380_10);
    let v385_6: Path = concat_path(&(*p0),&(v379_9_head));
    let v380_12: Space = wrap(&(v380_11),&(v385_6));
    drop(v380_11);
    let v380_13: Space = wrap(&(v380_12),&(*p1));
    drop(v380_12);
    let v380_14: Space = unite(&(v380_8),&(v380_13));
    drop(v380_13);
    v379_9.join_into((v380_14).clone());
  }
  drop(v379_9_cursor);
  (v379_9).clone()
}

fn routine_42(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v386_13 = Space::new();
  let mut v386_13_cursor = (*s0).read_zipper();
  for v386_13_byte in v386_13_cursor.child_mask().iter() {
    v386_13_cursor.descend_to_byte(v386_13_byte);
    let v386_13_tail = v386_13_cursor.make_map();
    v386_13_cursor.ascend(1);
    let v386_13_head = Path::from_slice(&[v386_13_byte]);
    let v387_2: Space = singleton(&(v386_13_head));
    let v387_3: Space = intersect(&(*CONSTANT_2),&(v387_2));
    let v387_4: Space = if has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
    drop(v387_3);
    let v387_5: Space = subtract(&(*CONSTANT_1),&(v387_4));
    drop(v387_4);
    let v387_8: Space = if (v387_5).is_empty() { Space::new() } else {
      let v388_6: Path = concat_path(&(*p0),&(v386_13_head));
      let mut v388_7 = Space::new();
      let mut v388_7_cursor = (v386_13_tail).read_zipper();
      for v388_7_byte in v388_7_cursor.child_mask().iter() {
        v388_7_cursor.descend_to_byte(v388_7_byte);
        let v388_7_tail = v388_7_cursor.make_map();
        v388_7_cursor.ascend(1);
        let v388_7_head = Path::from_slice(&[v388_7_byte]);
        let v389_2: Space = singleton(&(v388_7_head));
        let v389_3: Space = intersect(&(*CONSTANT_2),&(v389_2));
        let v389_4: Space = if has_head(&(v389_3)) { singleton(&[]) } else { Space::new() };
        drop(v389_3);
        let v389_5: Space = subtract(&(*CONSTANT_1),&(v389_4));
        drop(v389_4);
        let v389_8: Space = if (v389_5).is_empty() { Space::new() } else {
          let v390_6: Path = concat_path(&(v388_6),&(v388_7_head));
          let v390_7: Space = routine_50(c, &(v390_6), &(*p1), &(v388_7_tail), &(*s1));
          compose(&(v389_5),&(v390_7))
        };
        drop(v389_5);
        let v389_9: Space = intersect(&(*CONSTANT_2),&(v389_2));
        drop(v389_2);
        let v389_10: Space = if has_head(&(v389_9)) { singleton(&[]) } else { Space::new() };
        drop(v389_9);
        let v389_12: Space = if (v389_10).is_empty() { Space::new() } else {
          let v391_6: Path = concat_path(&(v388_6),&(v388_7_head));
          let v391_11: Space = routine_51(c, &(v391_6), &(*p1), &(v388_7_tail), &(*s1));
          drop(v391_6);
          compose(&(v389_10),&(v391_11))
        };
        drop(v389_10);
        let v389_13: Space = unite(&(v389_8),&(v389_12));
        v388_7.join_into((v389_13).clone());
      }
      drop(v388_7_cursor);
      compose(&(v387_5),&(v388_7))
    };
    drop(v387_5);
    let v387_9: Space = intersect(&(*CONSTANT_2),&(v387_2));
    drop(v387_2);
    let v387_10: Space = if has_head(&(v387_9)) { singleton(&[]) } else { Space::new() };
    drop(v387_9);
    let v387_12: Space = if (v387_10).is_empty() { Space::new() } else {
      let v392_6: Path = concat_path(&(*p0),&(v386_13_head));
      let mut v392_11 = Space::new();
      let mut v392_11_cursor = (v386_13_tail).read_zipper();
      for v392_11_byte in v392_11_cursor.child_mask().iter() {
        v392_11_cursor.descend_to_byte(v392_11_byte);
        let v392_11_tail = v392_11_cursor.make_map();
        v392_11_cursor.ascend(1);
        let v392_11_head = Path::from_slice(&[v392_11_byte]);
        let v393_2: Space = singleton(&(v392_11_head));
        let v393_3: Space = intersect(&(*CONSTANT_2),&(v393_2));
        let v393_4: Space = if has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
        drop(v393_3);
        let v393_5: Space = subtract(&(*CONSTANT_1),&(v393_4));
        drop(v393_4);
        let v393_8: Space = if (v393_5).is_empty() { Space::new() } else {
          let v394_6: Path = concat_path(&(v392_6),&(v392_11_head));
          let v394_7: Space = routine_50(c, &(v394_6), &(*p1), &(v392_11_tail), &(*s1));
          compose(&(v393_5),&(v394_7))
        };
        drop(v393_5);
        let v393_9: Space = intersect(&(*CONSTANT_2),&(v393_2));
        drop(v393_2);
        let v393_10: Space = if has_head(&(v393_9)) { singleton(&[]) } else { Space::new() };
        drop(v393_9);
        let v393_12: Space = if (v393_10).is_empty() { Space::new() } else {
          let v395_6: Path = concat_path(&(v392_6),&(v392_11_head));
          let v395_11: Space = routine_10(c, &(v395_6), &(*p1), &(v392_11_tail), &(*s1));
          drop(v395_6);
          compose(&(v393_10),&(v395_11))
        };
        drop(v393_10);
        let v393_13: Space = unite(&(v393_8),&(v393_12));
        v392_11.join_into((v393_13).clone());
      }
      drop(v392_11_cursor);
      drop(v392_6);
      compose(&(v387_10),&(v392_11))
    };
    drop(v387_10);
    let v387_13: Space = unite(&(v387_8),&(v387_12));
    v386_13.join_into((v387_13).clone());
  }
  drop(v386_13_cursor);
  (v386_13).clone()
}

fn routine_43(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v396_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v396_9: Space = unwrap(&(v396_8),&(*p0));
  drop(v396_8);
  let mut v396_16 = Space::new();
  let mut v396_16_cursor = (*s0).read_zipper();
  for v396_16_byte in v396_16_cursor.child_mask().iter() {
    v396_16_cursor.descend_to_byte(v396_16_byte);
    let v396_16_tail = v396_16_cursor.make_map();
    v396_16_cursor.ascend(1);
    let v396_16_head = Path::from_slice(&[v396_16_byte]);
    let v397_2: Space = singleton(&(v396_16_head));
    let v397_3: Space = intersect(&(*CONSTANT_2),&(v397_2));
    let v397_4: Space = if has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
    drop(v397_3);
    let v397_5: Space = subtract(&(*CONSTANT_1),&(v397_4));
    drop(v397_4);
    let v397_8: Space = if (v397_5).is_empty() { Space::new() } else {
      let v398_6: Path = concat_path(&(*p0),&(v396_16_head));
      let mut v398_7 = Space::new();
      let mut v398_7_cursor = (v396_16_tail).read_zipper();
      for v398_7_byte in v398_7_cursor.child_mask().iter() {
        v398_7_cursor.descend_to_byte(v398_7_byte);
        let v398_7_tail = v398_7_cursor.make_map();
        v398_7_cursor.ascend(1);
        let v398_7_head = Path::from_slice(&[v398_7_byte]);
        let v399_2: Space = singleton(&(v398_7_head));
        let v399_3: Space = intersect(&(*CONSTANT_2),&(v399_2));
        let v399_4: Space = if has_head(&(v399_3)) { singleton(&[]) } else { Space::new() };
        drop(v399_3);
        let v399_5: Space = subtract(&(*CONSTANT_1),&(v399_4));
        drop(v399_4);
        let v399_8: Space = if (v399_5).is_empty() { Space::new() } else {
          let v400_6: Path = concat_path(&(v398_6),&(v398_7_head));
          let v400_7: Space = routine_50(c, &(v400_6), &(*p1), &(v398_7_tail), &(*s1));
          compose(&(v399_5),&(v400_7))
        };
        drop(v399_5);
        let v399_9: Space = intersect(&(*CONSTANT_2),&(v399_2));
        drop(v399_2);
        let v399_10: Space = if has_head(&(v399_9)) { singleton(&[]) } else { Space::new() };
        drop(v399_9);
        let v399_12: Space = if (v399_10).is_empty() { Space::new() } else {
          let v401_6: Path = concat_path(&(v398_6),&(v398_7_head));
          let v401_11: Space = routine_51(c, &(v401_6), &(*p1), &(v398_7_tail), &(*s1));
          drop(v401_6);
          compose(&(v399_10),&(v401_11))
        };
        drop(v399_10);
        let v399_13: Space = unite(&(v399_8),&(v399_12));
        v398_7.join_into((v399_13).clone());
      }
      drop(v398_7_cursor);
      drop(v398_6);
      compose(&(v397_5),&(v398_7))
    };
    drop(v397_5);
    let v397_9: Space = intersect(&(*CONSTANT_2),&(v397_2));
    drop(v397_2);
    let v397_10: Space = if has_head(&(v397_9)) { singleton(&[]) } else { Space::new() };
    drop(v397_9);
    let v397_13: Space = if (v397_10).is_empty() { Space::new() } else {
      let v402_11: Space = unwrap(&(v396_9),&(v396_16_head));
      let mut v402_12 = Space::new();
      let mut v402_12_cursor = (v402_11).read_zipper();
      for v402_12_byte in v402_12_cursor.child_mask().iter() {
        v402_12_cursor.descend_to_byte(v402_12_byte);
        let v402_12_tail = v402_12_cursor.make_map();
        v402_12_cursor.ascend(1);
        let v402_12_head = Path::from_slice(&[v402_12_byte]);
        let v403_2: Space = singleton(&(v402_12_head));
        let v403_3: Space = intersect(&(*CONSTANT_2),&(v403_2));
        let v403_4: Space = if has_head(&(v403_3)) { singleton(&[]) } else { Space::new() };
        drop(v403_3);
        let v403_5: Space = subtract(&(*CONSTANT_1),&(v403_4));
        drop(v403_4);
        let v403_7: Space = if (v403_5).is_empty() { Space::new() } else {
          let v404_6: Space = routine_15(c, &(v402_12_head), &(*p1), &(v402_12_tail));
          compose(&(v403_5),&(v404_6))
        };
        drop(v403_5);
        let v403_8: Space = intersect(&(*CONSTANT_2),&(v403_2));
        drop(v403_2);
        let v403_9: Space = if has_head(&(v403_8)) { singleton(&[]) } else { Space::new() };
        drop(v403_8);
        let v403_11: Space = if (v403_9).is_empty() { Space::new() } else {
          let v405_10: Space = routine_16(c, &(v402_12_head), &(*p1), &(v402_12_tail));
          compose(&(v403_9),&(v405_10))
        };
        drop(v403_9);
        let v403_12: Space = unite(&(v403_7),&(v403_11));
        v402_12.join_into((v403_12).clone());
      }
      drop(v402_12_cursor);
      drop(v402_11);
      compose(&(v397_10),&(v402_12))
    };
    drop(v397_10);
    let v397_14: Space = unite(&(v397_8),&(v397_13));
    v396_16.join_into((v397_14).clone());
  }
  drop(v396_16_cursor);
  drop(v396_9);
  (v396_16).clone()
}

fn routine_44(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v406_12 = Space::new();
  let mut v406_12_cursor = (*s0).read_zipper();
  for v406_12_byte in v406_12_cursor.child_mask().iter() {
    v406_12_cursor.descend_to_byte(v406_12_byte);
    let v406_12_tail = v406_12_cursor.make_map();
    v406_12_cursor.ascend(1);
    let v406_12_head = Path::from_slice(&[v406_12_byte]);
    let v407_2: Space = singleton(&(v406_12_head));
    let v407_3: Space = intersect(&(*CONSTANT_2),&(v407_2));
    let v407_4: Space = if has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
    drop(v407_3);
    let v407_5: Space = subtract(&(*CONSTANT_1),&(v407_4));
    drop(v407_4);
    let v407_8: Space = if (v407_5).is_empty() { Space::new() } else {
      let v408_6: Path = concat_path(&(*p0),&(v406_12_head));
      let mut v408_7 = Space::new();
      let mut v408_7_cursor = (v406_12_tail).read_zipper();
      for v408_7_byte in v408_7_cursor.child_mask().iter() {
        v408_7_cursor.descend_to_byte(v408_7_byte);
        let v408_7_tail = v408_7_cursor.make_map();
        v408_7_cursor.ascend(1);
        let v408_7_head = Path::from_slice(&[v408_7_byte]);
        let v409_2: Space = singleton(&(v408_7_head));
        let v409_3: Space = intersect(&(*CONSTANT_2),&(v409_2));
        let v409_4: Space = if has_head(&(v409_3)) { singleton(&[]) } else { Space::new() };
        drop(v409_3);
        let v409_5: Space = subtract(&(*CONSTANT_1),&(v409_4));
        drop(v409_4);
        let v409_8: Space = if (v409_5).is_empty() { Space::new() } else {
          let v410_6: Path = concat_path(&(v408_6),&(v408_7_head));
          let v410_7: Space = routine_52(c, &(v410_6), &(*p1), &(v408_7_tail));
          compose(&(v409_5),&(v410_7))
        };
        drop(v409_5);
        let v409_9: Space = intersect(&(*CONSTANT_2),&(v409_2));
        drop(v409_2);
        let v409_10: Space = if has_head(&(v409_9)) { singleton(&[]) } else { Space::new() };
        drop(v409_9);
        let v409_12: Space = if (v409_10).is_empty() { Space::new() } else {
          let v411_6: Path = concat_path(&(v408_6),&(v408_7_head));
          let v411_11: Space = routine_53(c, &(v411_6), &(*p1), &(v408_7_tail));
          drop(v411_6);
          compose(&(v409_10),&(v411_11))
        };
        drop(v409_10);
        let v409_13: Space = unite(&(v409_8),&(v409_12));
        v408_7.join_into((v409_13).clone());
      }
      drop(v408_7_cursor);
      compose(&(v407_5),&(v408_7))
    };
    drop(v407_5);
    let v407_9: Space = intersect(&(*CONSTANT_2),&(v407_2));
    drop(v407_2);
    let v407_10: Space = if has_head(&(v407_9)) { singleton(&[]) } else { Space::new() };
    drop(v407_9);
    let v407_12: Space = if (v407_10).is_empty() { Space::new() } else {
      let v412_6: Path = concat_path(&(*p0),&(v406_12_head));
      let mut v412_11 = Space::new();
      let mut v412_11_cursor = (v406_12_tail).read_zipper();
      for v412_11_byte in v412_11_cursor.child_mask().iter() {
        v412_11_cursor.descend_to_byte(v412_11_byte);
        let v412_11_tail = v412_11_cursor.make_map();
        v412_11_cursor.ascend(1);
        let v412_11_head = Path::from_slice(&[v412_11_byte]);
        let v413_2: Space = singleton(&(v412_11_head));
        let v413_3: Space = intersect(&(*CONSTANT_2),&(v413_2));
        let v413_4: Space = if has_head(&(v413_3)) { singleton(&[]) } else { Space::new() };
        drop(v413_3);
        let v413_5: Space = subtract(&(*CONSTANT_1),&(v413_4));
        drop(v413_4);
        let v413_8: Space = if (v413_5).is_empty() { Space::new() } else {
          let v414_6: Path = concat_path(&(v412_6),&(v412_11_head));
          let v414_7: Space = routine_52(c, &(v414_6), &(*p1), &(v412_11_tail));
          compose(&(v413_5),&(v414_7))
        };
        drop(v413_5);
        let v413_9: Space = intersect(&(*CONSTANT_2),&(v413_2));
        drop(v413_2);
        let v413_10: Space = if has_head(&(v413_9)) { singleton(&[]) } else { Space::new() };
        drop(v413_9);
        let v413_12: Space = if (v413_10).is_empty() { Space::new() } else {
          let v415_6: Path = concat_path(&(v412_6),&(v412_11_head));
          let v415_11: Space = routine_21(c, &(v415_6), &(*p1), &(v412_11_tail));
          drop(v415_6);
          compose(&(v413_10),&(v415_11))
        };
        drop(v413_10);
        let v413_13: Space = unite(&(v413_8),&(v413_12));
        v412_11.join_into((v413_13).clone());
      }
      drop(v412_11_cursor);
      drop(v412_6);
      compose(&(v407_10),&(v412_11))
    };
    drop(v407_10);
    let v407_13: Space = unite(&(v407_8),&(v407_12));
    v406_12.join_into((v407_13).clone());
  }
  drop(v406_12_cursor);
  (v406_12).clone()
}

fn routine_45(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v416_9 = Space::new();
  let mut v416_9_cursor = (*s0).read_zipper();
  for v416_9_byte in v416_9_cursor.child_mask().iter() {
    v416_9_cursor.descend_to_byte(v416_9_byte);
    let v416_9_tail = v416_9_cursor.make_map();
    v416_9_cursor.ascend(1);
    let v416_9_head = Path::from_slice(&[v416_9_byte]);
    let v417_2: Space = singleton(&(v416_9_head));
    let v417_3: Space = intersect(&(*CONSTANT_2),&(v417_2));
    let v417_4: Space = if has_head(&(v417_3)) { singleton(&[]) } else { Space::new() };
    drop(v417_3);
    let v417_5: Space = subtract(&(*CONSTANT_1),&(v417_4));
    drop(v417_4);
    let v417_8: Space = if (v417_5).is_empty() { Space::new() } else {
      let v418_6: Path = concat_path(&(*p0),&(v416_9_head));
      let mut v418_7 = Space::new();
      let mut v418_7_cursor = (v416_9_tail).read_zipper();
      for v418_7_byte in v418_7_cursor.child_mask().iter() {
        v418_7_cursor.descend_to_byte(v418_7_byte);
        let v418_7_tail = v418_7_cursor.make_map();
        v418_7_cursor.ascend(1);
        let v418_7_head = Path::from_slice(&[v418_7_byte]);
        let v419_2: Space = singleton(&(v418_7_head));
        let v419_3: Space = intersect(&(*CONSTANT_2),&(v419_2));
        let v419_4: Space = if has_head(&(v419_3)) { singleton(&[]) } else { Space::new() };
        drop(v419_3);
        let v419_5: Space = subtract(&(*CONSTANT_1),&(v419_4));
        drop(v419_4);
        let v419_8: Space = if (v419_5).is_empty() { Space::new() } else {
          let v420_6: Path = concat_path(&(v418_6),&(v418_7_head));
          let v420_7: Space = routine_52(c, &(v420_6), &(*p1), &(v418_7_tail));
          compose(&(v419_5),&(v420_7))
        };
        drop(v419_5);
        let v419_9: Space = intersect(&(*CONSTANT_2),&(v419_2));
        drop(v419_2);
        let v419_10: Space = if has_head(&(v419_9)) { singleton(&[]) } else { Space::new() };
        drop(v419_9);
        let v419_12: Space = if (v419_10).is_empty() { Space::new() } else {
          let v421_6: Path = concat_path(&(v418_6),&(v418_7_head));
          let v421_11: Space = routine_53(c, &(v421_6), &(*p1), &(v418_7_tail));
          drop(v421_6);
          compose(&(v419_10),&(v421_11))
        };
        drop(v419_10);
        let v419_13: Space = unite(&(v419_8),&(v419_12));
        v418_7.join_into((v419_13).clone());
      }
      drop(v418_7_cursor);
      compose(&(v417_5),&(v418_7))
    };
    drop(v417_5);
    let v417_9: Space = intersect(&(*CONSTANT_2),&(v417_2));
    drop(v417_2);
    let v417_10: Space = if has_head(&(v417_9)) { singleton(&[]) } else { Space::new() };
    drop(v417_9);
    let v417_11: Space = compose(&(v417_10),&(v416_9_tail));
    drop(v417_10);
    let v422_6: Path = concat_path(&(*p0),&(v416_9_head));
    let v417_12: Space = wrap(&(v417_11),&(v422_6));
    drop(v417_11);
    let v417_13: Space = wrap(&(v417_12),&(*p1));
    drop(v417_12);
    let v417_14: Space = unite(&(v417_8),&(v417_13));
    drop(v417_13);
    v416_9.join_into((v417_14).clone());
  }
  drop(v416_9_cursor);
  (v416_9).clone()
}

fn routine_46(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v423_8 = Space::new();
  let mut v423_8_cursor = (*s0).read_zipper();
  for v423_8_byte in v423_8_cursor.child_mask().iter() {
    v423_8_cursor.descend_to_byte(v423_8_byte);
    let v423_8_tail = v423_8_cursor.make_map();
    v423_8_cursor.ascend(1);
    let v423_8_head = Path::from_slice(&[v423_8_byte]);
    let v424_2: Space = singleton(&(v423_8_head));
    let v424_3: Space = intersect(&(*CONSTANT_2),&(v424_2));
    let v424_4: Space = if has_head(&(v424_3)) { singleton(&[]) } else { Space::new() };
    drop(v424_3);
    let v424_5: Space = subtract(&(*CONSTANT_1),&(v424_4));
    drop(v424_4);
    let mut v424_6 = Space::new();
    let mut v424_6_cursor = (v423_8_tail).read_zipper();
    for v424_6_byte in v424_6_cursor.child_mask().iter() {
      v424_6_cursor.descend_to_byte(v424_6_byte);
      let v424_6_tail = v424_6_cursor.make_map();
      v424_6_cursor.ascend(1);
      let v424_6_head = Path::from_slice(&[v424_6_byte]);
      let v425_2: Space = Space::new();
      v424_6.join_into((v425_2).clone());
    }
    drop(v424_6_cursor);
    let v424_7: Space = compose(&(v424_5),&(v424_6));
    drop(v424_5);
    drop(v424_6);
    let v424_8: Space = intersect(&(*CONSTANT_2),&(v424_2));
    drop(v424_2);
    let v424_9: Space = if has_head(&(v424_8)) { singleton(&[]) } else { Space::new() };
    drop(v424_8);
    let v424_12: Space = if (v424_9).is_empty() { Space::new() } else {
      let v426_10: Path = concat_path(&(*p0),&(v423_8_head));
      let mut v426_11 = Space::new();
      let mut v426_11_cursor = (v423_8_tail).read_zipper();
      for v426_11_byte in v426_11_cursor.child_mask().iter() {
        v426_11_cursor.descend_to_byte(v426_11_byte);
        let v426_11_tail = v426_11_cursor.make_map();
        v426_11_cursor.ascend(1);
        let v426_11_head = Path::from_slice(&[v426_11_byte]);
        let v427_2: Space = singleton(&(v426_11_head));
        let v427_3: Space = intersect(&(*CONSTANT_2),&(v427_2));
        drop(v427_2);
        let v427_4: Space = if has_head(&(v427_3)) { singleton(&[]) } else { Space::new() };
        drop(v427_3);
        let v427_7: Space = if (v427_4).is_empty() { Space::new() } else {
          let v428_5: Path = concat_path(&(v426_10),&(v426_11_head));
          let v428_6: Space = routine_10(c, &(v428_5), &(*p1), &(v426_11_tail), &(*s1));
          drop(v428_5);
          compose(&(v427_4),&(v428_6))
        };
        drop(v427_4);
        v426_11.join_into((v427_7).clone());
      }
      drop(v426_11_cursor);
      drop(v426_10);
      compose(&(v424_9),&(v426_11))
    };
    drop(v424_9);
    let v424_13: Space = unite(&(v424_7),&(v424_12));
    drop(v424_7);
    v423_8.join_into((v424_13).clone());
  }
  drop(v423_8_cursor);
  (v423_8).clone()
}

fn routine_47(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v429_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v429_9: Space = unwrap(&(v429_8),&(*p0));
  drop(v429_8);
  let mut v429_13 = Space::new();
  let mut v429_13_cursor = (*s0).read_zipper();
  for v429_13_byte in v429_13_cursor.child_mask().iter() {
    v429_13_cursor.descend_to_byte(v429_13_byte);
    let v429_13_tail = v429_13_cursor.make_map();
    v429_13_cursor.ascend(1);
    let v429_13_head = Path::from_slice(&[v429_13_byte]);
    let v430_2: Space = singleton(&(v429_13_head));
    let v430_3: Space = intersect(&(*CONSTANT_2),&(v430_2));
    let v430_4: Space = if has_head(&(v430_3)) { singleton(&[]) } else { Space::new() };
    drop(v430_3);
    let v430_5: Space = subtract(&(*CONSTANT_1),&(v430_4));
    drop(v430_4);
    let mut v430_6 = Space::new();
    let mut v430_6_cursor = (v429_13_tail).read_zipper();
    for v430_6_byte in v430_6_cursor.child_mask().iter() {
      v430_6_cursor.descend_to_byte(v430_6_byte);
      let v430_6_tail = v430_6_cursor.make_map();
      v430_6_cursor.ascend(1);
      let v430_6_head = Path::from_slice(&[v430_6_byte]);
      let v431_2: Space = Space::new();
      v430_6.join_into((v431_2).clone());
    }
    drop(v430_6_cursor);
    let v430_7: Space = compose(&(v430_5),&(v430_6));
    drop(v430_5);
    drop(v430_6);
    let v430_8: Space = intersect(&(*CONSTANT_2),&(v430_2));
    drop(v430_2);
    let v430_9: Space = if has_head(&(v430_8)) { singleton(&[]) } else { Space::new() };
    drop(v430_8);
    let v430_12: Space = if (v430_9).is_empty() { Space::new() } else {
      let v432_10: Space = unwrap(&(v429_9),&(v429_13_head));
      let mut v432_11 = Space::new();
      let mut v432_11_cursor = (v432_10).read_zipper();
      for v432_11_byte in v432_11_cursor.child_mask().iter() {
        v432_11_cursor.descend_to_byte(v432_11_byte);
        let v432_11_tail = v432_11_cursor.make_map();
        v432_11_cursor.ascend(1);
        let v432_11_head = Path::from_slice(&[v432_11_byte]);
        let v433_2: Space = singleton(&(v432_11_head));
        let v433_3: Space = intersect(&(*CONSTANT_2),&(v433_2));
        let v433_4: Space = if has_head(&(v433_3)) { singleton(&[]) } else { Space::new() };
        drop(v433_3);
        let v433_5: Space = subtract(&(*CONSTANT_1),&(v433_4));
        drop(v433_4);
        let v433_7: Space = if (v433_5).is_empty() { Space::new() } else {
          let v434_6: Space = routine_15(c, &(v432_11_head), &(*p1), &(v432_11_tail));
          compose(&(v433_5),&(v434_6))
        };
        drop(v433_5);
        let v433_8: Space = intersect(&(*CONSTANT_2),&(v433_2));
        drop(v433_2);
        let v433_9: Space = if has_head(&(v433_8)) { singleton(&[]) } else { Space::new() };
        drop(v433_8);
        let v433_11: Space = if (v433_9).is_empty() { Space::new() } else {
          let v435_10: Space = routine_16(c, &(v432_11_head), &(*p1), &(v432_11_tail));
          compose(&(v433_9),&(v435_10))
        };
        drop(v433_9);
        let v433_12: Space = unite(&(v433_7),&(v433_11));
        v432_11.join_into((v433_12).clone());
      }
      drop(v432_11_cursor);
      drop(v432_10);
      compose(&(v430_9),&(v432_11))
    };
    drop(v430_9);
    let v430_13: Space = unite(&(v430_7),&(v430_12));
    drop(v430_7);
    v429_13.join_into((v430_13).clone());
  }
  drop(v429_13_cursor);
  drop(v429_9);
  (v429_13).clone()
}

fn routine_48(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v436_12 = Space::new();
  let mut v436_12_cursor = (*s0).read_zipper();
  for v436_12_byte in v436_12_cursor.child_mask().iter() {
    v436_12_cursor.descend_to_byte(v436_12_byte);
    let v436_12_tail = v436_12_cursor.make_map();
    v436_12_cursor.ascend(1);
    let v436_12_head = Path::from_slice(&[v436_12_byte]);
    let v437_2: Space = singleton(&(v436_12_head));
    let v437_3: Space = intersect(&(*CONSTANT_2),&(v437_2));
    let v437_4: Space = if has_head(&(v437_3)) { singleton(&[]) } else { Space::new() };
    drop(v437_3);
    let v437_5: Space = subtract(&(*CONSTANT_1),&(v437_4));
    drop(v437_4);
    let v437_8: Space = if (v437_5).is_empty() { Space::new() } else {
      let v438_6: Path = concat_path(&(*p0),&(v436_12_head));
      let mut v438_7 = Space::new();
      let mut v438_7_cursor = (v436_12_tail).read_zipper();
      for v438_7_byte in v438_7_cursor.child_mask().iter() {
        v438_7_cursor.descend_to_byte(v438_7_byte);
        let v438_7_tail = v438_7_cursor.make_map();
        v438_7_cursor.ascend(1);
        let v438_7_head = Path::from_slice(&[v438_7_byte]);
        let v439_2: Space = singleton(&(v438_7_head));
        let v439_3: Space = intersect(&(*CONSTANT_2),&(v439_2));
        let v439_4: Space = if has_head(&(v439_3)) { singleton(&[]) } else { Space::new() };
        drop(v439_3);
        let v439_5: Space = subtract(&(*CONSTANT_1),&(v439_4));
        drop(v439_4);
        let v439_8: Space = if (v439_5).is_empty() { Space::new() } else {
          let v440_6: Path = concat_path(&(v438_6),&(v438_7_head));
          let v440_7: Space = routine_54(c, &(v440_6), &(*p1), &(v438_7_tail));
          compose(&(v439_5),&(v440_7))
        };
        drop(v439_5);
        let v439_9: Space = intersect(&(*CONSTANT_2),&(v439_2));
        drop(v439_2);
        let v439_10: Space = if has_head(&(v439_9)) { singleton(&[]) } else { Space::new() };
        drop(v439_9);
        let v439_12: Space = if (v439_10).is_empty() { Space::new() } else {
          let v441_6: Path = concat_path(&(v438_6),&(v438_7_head));
          let v441_11: Space = routine_55(c, &(v441_6), &(*p1), &(v438_7_tail));
          drop(v441_6);
          compose(&(v439_10),&(v441_11))
        };
        drop(v439_10);
        let v439_13: Space = unite(&(v439_8),&(v439_12));
        v438_7.join_into((v439_13).clone());
      }
      drop(v438_7_cursor);
      compose(&(v437_5),&(v438_7))
    };
    drop(v437_5);
    let v437_9: Space = intersect(&(*CONSTANT_2),&(v437_2));
    drop(v437_2);
    let v437_10: Space = if has_head(&(v437_9)) { singleton(&[]) } else { Space::new() };
    drop(v437_9);
    let v437_12: Space = if (v437_10).is_empty() { Space::new() } else {
      let v442_6: Path = concat_path(&(*p0),&(v436_12_head));
      let mut v442_11 = Space::new();
      let mut v442_11_cursor = (v436_12_tail).read_zipper();
      for v442_11_byte in v442_11_cursor.child_mask().iter() {
        v442_11_cursor.descend_to_byte(v442_11_byte);
        let v442_11_tail = v442_11_cursor.make_map();
        v442_11_cursor.ascend(1);
        let v442_11_head = Path::from_slice(&[v442_11_byte]);
        let v443_2: Space = singleton(&(v442_11_head));
        let v443_3: Space = intersect(&(*CONSTANT_2),&(v443_2));
        let v443_4: Space = if has_head(&(v443_3)) { singleton(&[]) } else { Space::new() };
        drop(v443_3);
        let v443_5: Space = subtract(&(*CONSTANT_1),&(v443_4));
        drop(v443_4);
        let v443_8: Space = if (v443_5).is_empty() { Space::new() } else {
          let v444_6: Path = concat_path(&(v442_6),&(v442_11_head));
          let v444_7: Space = routine_54(c, &(v444_6), &(*p1), &(v442_11_tail));
          compose(&(v443_5),&(v444_7))
        };
        drop(v443_5);
        let v443_9: Space = intersect(&(*CONSTANT_2),&(v443_2));
        drop(v443_2);
        let v443_10: Space = if has_head(&(v443_9)) { singleton(&[]) } else { Space::new() };
        drop(v443_9);
        let v443_12: Space = if (v443_10).is_empty() { Space::new() } else {
          let v445_6: Path = concat_path(&(v442_6),&(v442_11_head));
          let v445_11: Space = routine_21(c, &(v445_6), &(*p1), &(v442_11_tail));
          drop(v445_6);
          compose(&(v443_10),&(v445_11))
        };
        drop(v443_10);
        let v443_13: Space = unite(&(v443_8),&(v443_12));
        v442_11.join_into((v443_13).clone());
      }
      drop(v442_11_cursor);
      drop(v442_6);
      compose(&(v437_10),&(v442_11))
    };
    drop(v437_10);
    let v437_13: Space = unite(&(v437_8),&(v437_12));
    v436_12.join_into((v437_13).clone());
  }
  drop(v436_12_cursor);
  (v436_12).clone()
}

fn routine_49(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v446_9 = Space::new();
  let mut v446_9_cursor = (*s0).read_zipper();
  for v446_9_byte in v446_9_cursor.child_mask().iter() {
    v446_9_cursor.descend_to_byte(v446_9_byte);
    let v446_9_tail = v446_9_cursor.make_map();
    v446_9_cursor.ascend(1);
    let v446_9_head = Path::from_slice(&[v446_9_byte]);
    let v447_2: Space = singleton(&(v446_9_head));
    let v447_3: Space = intersect(&(*CONSTANT_2),&(v447_2));
    let v447_4: Space = if has_head(&(v447_3)) { singleton(&[]) } else { Space::new() };
    drop(v447_3);
    let v447_5: Space = subtract(&(*CONSTANT_1),&(v447_4));
    drop(v447_4);
    let v447_8: Space = if (v447_5).is_empty() { Space::new() } else {
      let v448_6: Path = concat_path(&(*p0),&(v446_9_head));
      let mut v448_7 = Space::new();
      let mut v448_7_cursor = (v446_9_tail).read_zipper();
      for v448_7_byte in v448_7_cursor.child_mask().iter() {
        v448_7_cursor.descend_to_byte(v448_7_byte);
        let v448_7_tail = v448_7_cursor.make_map();
        v448_7_cursor.ascend(1);
        let v448_7_head = Path::from_slice(&[v448_7_byte]);
        let v449_2: Space = singleton(&(v448_7_head));
        let v449_3: Space = intersect(&(*CONSTANT_2),&(v449_2));
        let v449_4: Space = if has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
        drop(v449_3);
        let v449_5: Space = subtract(&(*CONSTANT_1),&(v449_4));
        drop(v449_4);
        let v449_8: Space = if (v449_5).is_empty() { Space::new() } else {
          let v450_6: Path = concat_path(&(v448_6),&(v448_7_head));
          let v450_7: Space = routine_54(c, &(v450_6), &(*p1), &(v448_7_tail));
          compose(&(v449_5),&(v450_7))
        };
        drop(v449_5);
        let v449_9: Space = intersect(&(*CONSTANT_2),&(v449_2));
        drop(v449_2);
        let v449_10: Space = if has_head(&(v449_9)) { singleton(&[]) } else { Space::new() };
        drop(v449_9);
        let v449_12: Space = if (v449_10).is_empty() { Space::new() } else {
          let v451_6: Path = concat_path(&(v448_6),&(v448_7_head));
          let v451_11: Space = routine_55(c, &(v451_6), &(*p1), &(v448_7_tail));
          drop(v451_6);
          compose(&(v449_10),&(v451_11))
        };
        drop(v449_10);
        let v449_13: Space = unite(&(v449_8),&(v449_12));
        v448_7.join_into((v449_13).clone());
      }
      drop(v448_7_cursor);
      compose(&(v447_5),&(v448_7))
    };
    drop(v447_5);
    let v447_9: Space = intersect(&(*CONSTANT_2),&(v447_2));
    drop(v447_2);
    let v447_10: Space = if has_head(&(v447_9)) { singleton(&[]) } else { Space::new() };
    drop(v447_9);
    let v447_11: Space = compose(&(v447_10),&(v446_9_tail));
    drop(v447_10);
    let v452_6: Path = concat_path(&(*p0),&(v446_9_head));
    let v447_12: Space = wrap(&(v447_11),&(v452_6));
    drop(v447_11);
    let v447_13: Space = wrap(&(v447_12),&(*p1));
    drop(v447_12);
    let v447_14: Space = unite(&(v447_8),&(v447_13));
    drop(v447_13);
    v446_9.join_into((v447_14).clone());
  }
  drop(v446_9_cursor);
  (v446_9).clone()
}

fn routine_50(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v453_4 = Space::new();
  let mut v453_4_cursor = (*s0).read_zipper();
  for v453_4_byte in v453_4_cursor.child_mask().iter() {
    v453_4_cursor.descend_to_byte(v453_4_byte);
    let v453_4_tail = v453_4_cursor.make_map();
    v453_4_cursor.ascend(1);
    let v453_4_head = Path::from_slice(&[v453_4_byte]);
    let v454_2: Space = Space::new();
    v453_4.join_into((v454_2).clone());
  }
  drop(v453_4_cursor);
  (v453_4).clone()
}

fn routine_51(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v455_6: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v455_7: Space = unwrap(&(v455_6),&(*p0));
  drop(v455_6);
  let mut v455_11 = Space::new();
  let mut v455_11_cursor = (*s0).read_zipper();
  for v455_11_byte in v455_11_cursor.child_mask().iter() {
    v455_11_cursor.descend_to_byte(v455_11_byte);
    let v455_11_tail = v455_11_cursor.make_map();
    v455_11_cursor.ascend(1);
    let v455_11_head = Path::from_slice(&[v455_11_byte]);
    let v456_2: Space = singleton(&(v455_11_head));
    let v456_3: Space = intersect(&(*CONSTANT_2),&(v456_2));
    drop(v456_2);
    let v456_4: Space = if has_head(&(v456_3)) { singleton(&[]) } else { Space::new() };
    drop(v456_3);
    let v456_7: Space = if (v456_4).is_empty() { Space::new() } else {
      let v457_5: Space = unwrap(&(v455_7),&(v455_11_head));
      let mut v457_6 = Space::new();
      let mut v457_6_cursor = (v457_5).read_zipper();
      for v457_6_byte in v457_6_cursor.child_mask().iter() {
        v457_6_cursor.descend_to_byte(v457_6_byte);
        let v457_6_tail = v457_6_cursor.make_map();
        v457_6_cursor.ascend(1);
        let v457_6_head = Path::from_slice(&[v457_6_byte]);
        let v458_2: Space = singleton(&(v457_6_head));
        let v458_3: Space = intersect(&(*CONSTANT_2),&(v458_2));
        let v458_4: Space = if has_head(&(v458_3)) { singleton(&[]) } else { Space::new() };
        drop(v458_3);
        let v458_5: Space = subtract(&(*CONSTANT_1),&(v458_4));
        drop(v458_4);
        let v458_7: Space = if (v458_5).is_empty() { Space::new() } else {
          let v459_6: Space = routine_15(c, &(v457_6_head), &(*p1), &(v457_6_tail));
          compose(&(v458_5),&(v459_6))
        };
        drop(v458_5);
        let v458_8: Space = intersect(&(*CONSTANT_2),&(v458_2));
        drop(v458_2);
        let v458_9: Space = if has_head(&(v458_8)) { singleton(&[]) } else { Space::new() };
        drop(v458_8);
        let v458_11: Space = if (v458_9).is_empty() { Space::new() } else {
          let v460_10: Space = routine_16(c, &(v457_6_head), &(*p1), &(v457_6_tail));
          compose(&(v458_9),&(v460_10))
        };
        drop(v458_9);
        let v458_12: Space = unite(&(v458_7),&(v458_11));
        v457_6.join_into((v458_12).clone());
      }
      drop(v457_6_cursor);
      drop(v457_5);
      compose(&(v456_4),&(v457_6))
    };
    drop(v456_4);
    v455_11.join_into((v456_7).clone());
  }
  drop(v455_11_cursor);
  drop(v455_7);
  (v455_11).clone()
}

fn routine_52(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v461_12 = Space::new();
  let mut v461_12_cursor = (*s0).read_zipper();
  for v461_12_byte in v461_12_cursor.child_mask().iter() {
    v461_12_cursor.descend_to_byte(v461_12_byte);
    let v461_12_tail = v461_12_cursor.make_map();
    v461_12_cursor.ascend(1);
    let v461_12_head = Path::from_slice(&[v461_12_byte]);
    let v462_2: Space = singleton(&(v461_12_head));
    let v462_3: Space = intersect(&(*CONSTANT_2),&(v462_2));
    let v462_4: Space = if has_head(&(v462_3)) { singleton(&[]) } else { Space::new() };
    drop(v462_3);
    let v462_5: Space = subtract(&(*CONSTANT_1),&(v462_4));
    drop(v462_4);
    let v462_8: Space = if (v462_5).is_empty() { Space::new() } else {
      let v463_6: Path = concat_path(&(*p0),&(v461_12_head));
      let mut v463_7 = Space::new();
      let mut v463_7_cursor = (v461_12_tail).read_zipper();
      for v463_7_byte in v463_7_cursor.child_mask().iter() {
        v463_7_cursor.descend_to_byte(v463_7_byte);
        let v463_7_tail = v463_7_cursor.make_map();
        v463_7_cursor.ascend(1);
        let v463_7_head = Path::from_slice(&[v463_7_byte]);
        let v464_2: Space = singleton(&(v463_7_head));
        let v464_3: Space = intersect(&(*CONSTANT_2),&(v464_2));
        let v464_4: Space = if has_head(&(v464_3)) { singleton(&[]) } else { Space::new() };
        drop(v464_3);
        let v464_5: Space = subtract(&(*CONSTANT_1),&(v464_4));
        drop(v464_4);
        let v464_8: Space = if (v464_5).is_empty() { Space::new() } else {
          let v465_6: Path = concat_path(&(v463_6),&(v463_7_head));
          let v465_7: Space = routine_56(c, &(v465_6), &(*p1), &(v463_7_tail));
          compose(&(v464_5),&(v465_7))
        };
        drop(v464_5);
        let v464_9: Space = intersect(&(*CONSTANT_2),&(v464_2));
        drop(v464_2);
        let v464_10: Space = if has_head(&(v464_9)) { singleton(&[]) } else { Space::new() };
        drop(v464_9);
        let v464_12: Space = if (v464_10).is_empty() { Space::new() } else {
          let v466_6: Path = concat_path(&(v463_6),&(v463_7_head));
          let v466_11: Space = routine_57(c, &(v466_6), &(*p1), &(v463_7_tail));
          drop(v466_6);
          compose(&(v464_10),&(v466_11))
        };
        drop(v464_10);
        let v464_13: Space = unite(&(v464_8),&(v464_12));
        v463_7.join_into((v464_13).clone());
      }
      drop(v463_7_cursor);
      compose(&(v462_5),&(v463_7))
    };
    drop(v462_5);
    let v462_9: Space = intersect(&(*CONSTANT_2),&(v462_2));
    drop(v462_2);
    let v462_10: Space = if has_head(&(v462_9)) { singleton(&[]) } else { Space::new() };
    drop(v462_9);
    let v462_12: Space = if (v462_10).is_empty() { Space::new() } else {
      let v467_6: Path = concat_path(&(*p0),&(v461_12_head));
      let mut v467_11 = Space::new();
      let mut v467_11_cursor = (v461_12_tail).read_zipper();
      for v467_11_byte in v467_11_cursor.child_mask().iter() {
        v467_11_cursor.descend_to_byte(v467_11_byte);
        let v467_11_tail = v467_11_cursor.make_map();
        v467_11_cursor.ascend(1);
        let v467_11_head = Path::from_slice(&[v467_11_byte]);
        let v468_2: Space = singleton(&(v467_11_head));
        let v468_3: Space = intersect(&(*CONSTANT_2),&(v468_2));
        let v468_4: Space = if has_head(&(v468_3)) { singleton(&[]) } else { Space::new() };
        drop(v468_3);
        let v468_5: Space = subtract(&(*CONSTANT_1),&(v468_4));
        drop(v468_4);
        let v468_8: Space = if (v468_5).is_empty() { Space::new() } else {
          let v469_6: Path = concat_path(&(v467_6),&(v467_11_head));
          let v469_7: Space = routine_56(c, &(v469_6), &(*p1), &(v467_11_tail));
          compose(&(v468_5),&(v469_7))
        };
        drop(v468_5);
        let v468_9: Space = intersect(&(*CONSTANT_2),&(v468_2));
        drop(v468_2);
        let v468_10: Space = if has_head(&(v468_9)) { singleton(&[]) } else { Space::new() };
        drop(v468_9);
        let v468_12: Space = if (v468_10).is_empty() { Space::new() } else {
          let v470_6: Path = concat_path(&(v467_6),&(v467_11_head));
          let v470_11: Space = routine_21(c, &(v470_6), &(*p1), &(v467_11_tail));
          drop(v470_6);
          compose(&(v468_10),&(v470_11))
        };
        drop(v468_10);
        let v468_13: Space = unite(&(v468_8),&(v468_12));
        v467_11.join_into((v468_13).clone());
      }
      drop(v467_11_cursor);
      drop(v467_6);
      compose(&(v462_10),&(v467_11))
    };
    drop(v462_10);
    let v462_13: Space = unite(&(v462_8),&(v462_12));
    v461_12.join_into((v462_13).clone());
  }
  drop(v461_12_cursor);
  (v461_12).clone()
}

fn routine_53(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v471_9 = Space::new();
  let mut v471_9_cursor = (*s0).read_zipper();
  for v471_9_byte in v471_9_cursor.child_mask().iter() {
    v471_9_cursor.descend_to_byte(v471_9_byte);
    let v471_9_tail = v471_9_cursor.make_map();
    v471_9_cursor.ascend(1);
    let v471_9_head = Path::from_slice(&[v471_9_byte]);
    let v472_2: Space = singleton(&(v471_9_head));
    let v472_3: Space = intersect(&(*CONSTANT_2),&(v472_2));
    let v472_4: Space = if has_head(&(v472_3)) { singleton(&[]) } else { Space::new() };
    drop(v472_3);
    let v472_5: Space = subtract(&(*CONSTANT_1),&(v472_4));
    drop(v472_4);
    let v472_8: Space = if (v472_5).is_empty() { Space::new() } else {
      let v473_6: Path = concat_path(&(*p0),&(v471_9_head));
      let mut v473_7 = Space::new();
      let mut v473_7_cursor = (v471_9_tail).read_zipper();
      for v473_7_byte in v473_7_cursor.child_mask().iter() {
        v473_7_cursor.descend_to_byte(v473_7_byte);
        let v473_7_tail = v473_7_cursor.make_map();
        v473_7_cursor.ascend(1);
        let v473_7_head = Path::from_slice(&[v473_7_byte]);
        let v474_2: Space = singleton(&(v473_7_head));
        let v474_3: Space = intersect(&(*CONSTANT_2),&(v474_2));
        let v474_4: Space = if has_head(&(v474_3)) { singleton(&[]) } else { Space::new() };
        drop(v474_3);
        let v474_5: Space = subtract(&(*CONSTANT_1),&(v474_4));
        drop(v474_4);
        let v474_8: Space = if (v474_5).is_empty() { Space::new() } else {
          let v475_6: Path = concat_path(&(v473_6),&(v473_7_head));
          let v475_7: Space = routine_56(c, &(v475_6), &(*p1), &(v473_7_tail));
          compose(&(v474_5),&(v475_7))
        };
        drop(v474_5);
        let v474_9: Space = intersect(&(*CONSTANT_2),&(v474_2));
        drop(v474_2);
        let v474_10: Space = if has_head(&(v474_9)) { singleton(&[]) } else { Space::new() };
        drop(v474_9);
        let v474_12: Space = if (v474_10).is_empty() { Space::new() } else {
          let v476_6: Path = concat_path(&(v473_6),&(v473_7_head));
          let v476_11: Space = routine_57(c, &(v476_6), &(*p1), &(v473_7_tail));
          drop(v476_6);
          compose(&(v474_10),&(v476_11))
        };
        drop(v474_10);
        let v474_13: Space = unite(&(v474_8),&(v474_12));
        v473_7.join_into((v474_13).clone());
      }
      drop(v473_7_cursor);
      compose(&(v472_5),&(v473_7))
    };
    drop(v472_5);
    let v472_9: Space = intersect(&(*CONSTANT_2),&(v472_2));
    drop(v472_2);
    let v472_10: Space = if has_head(&(v472_9)) { singleton(&[]) } else { Space::new() };
    drop(v472_9);
    let v472_11: Space = compose(&(v472_10),&(v471_9_tail));
    drop(v472_10);
    let v477_6: Path = concat_path(&(*p0),&(v471_9_head));
    let v472_12: Space = wrap(&(v472_11),&(v477_6));
    drop(v472_11);
    let v472_13: Space = wrap(&(v472_12),&(*p1));
    drop(v472_12);
    let v472_14: Space = unite(&(v472_8),&(v472_13));
    drop(v472_13);
    v471_9.join_into((v472_14).clone());
  }
  drop(v471_9_cursor);
  (v471_9).clone()
}

fn routine_54(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v478_7 = Space::new();
  let mut v478_7_cursor = (*s0).read_zipper();
  for v478_7_byte in v478_7_cursor.child_mask().iter() {
    v478_7_cursor.descend_to_byte(v478_7_byte);
    let v478_7_tail = v478_7_cursor.make_map();
    v478_7_cursor.ascend(1);
    let v478_7_head = Path::from_slice(&[v478_7_byte]);
    let v479_2: Space = singleton(&(v478_7_head));
    let v479_3: Space = intersect(&(*CONSTANT_2),&(v479_2));
    let v479_4: Space = if has_head(&(v479_3)) { singleton(&[]) } else { Space::new() };
    drop(v479_3);
    let v479_5: Space = subtract(&(*CONSTANT_1),&(v479_4));
    drop(v479_4);
    let mut v479_6 = Space::new();
    let mut v479_6_cursor = (v478_7_tail).read_zipper();
    for v479_6_byte in v479_6_cursor.child_mask().iter() {
      v479_6_cursor.descend_to_byte(v479_6_byte);
      let v479_6_tail = v479_6_cursor.make_map();
      v479_6_cursor.ascend(1);
      let v479_6_head = Path::from_slice(&[v479_6_byte]);
      let v480_2: Space = Space::new();
      v479_6.join_into((v480_2).clone());
    }
    drop(v479_6_cursor);
    let v479_7: Space = compose(&(v479_5),&(v479_6));
    drop(v479_5);
    drop(v479_6);
    let v479_8: Space = intersect(&(*CONSTANT_2),&(v479_2));
    drop(v479_2);
    let v479_9: Space = if has_head(&(v479_8)) { singleton(&[]) } else { Space::new() };
    drop(v479_8);
    let v479_12: Space = if (v479_9).is_empty() { Space::new() } else {
      let v481_10: Path = concat_path(&(*p0),&(v478_7_head));
      let mut v481_11 = Space::new();
      let mut v481_11_cursor = (v478_7_tail).read_zipper();
      for v481_11_byte in v481_11_cursor.child_mask().iter() {
        v481_11_cursor.descend_to_byte(v481_11_byte);
        let v481_11_tail = v481_11_cursor.make_map();
        v481_11_cursor.ascend(1);
        let v481_11_head = Path::from_slice(&[v481_11_byte]);
        let v482_2: Space = singleton(&(v481_11_head));
        let v482_3: Space = intersect(&(*CONSTANT_2),&(v482_2));
        drop(v482_2);
        let v482_4: Space = if has_head(&(v482_3)) { singleton(&[]) } else { Space::new() };
        drop(v482_3);
        let v482_7: Space = if (v482_4).is_empty() { Space::new() } else {
          let v483_5: Path = concat_path(&(v481_10),&(v481_11_head));
          let v483_6: Space = routine_21(c, &(v483_5), &(*p1), &(v481_11_tail));
          drop(v483_5);
          compose(&(v482_4),&(v483_6))
        };
        drop(v482_4);
        v481_11.join_into((v482_7).clone());
      }
      drop(v481_11_cursor);
      drop(v481_10);
      compose(&(v479_9),&(v481_11))
    };
    drop(v479_9);
    let v479_13: Space = unite(&(v479_7),&(v479_12));
    drop(v479_7);
    v478_7.join_into((v479_13).clone());
  }
  drop(v478_7_cursor);
  (v478_7).clone()
}

fn routine_55(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v484_6 = Space::new();
  let mut v484_6_cursor = (*s0).read_zipper();
  for v484_6_byte in v484_6_cursor.child_mask().iter() {
    v484_6_cursor.descend_to_byte(v484_6_byte);
    let v484_6_tail = v484_6_cursor.make_map();
    v484_6_cursor.ascend(1);
    let v484_6_head = Path::from_slice(&[v484_6_byte]);
    let v485_2: Space = singleton(&(v484_6_head));
    let v485_3: Space = intersect(&(*CONSTANT_2),&(v485_2));
    let v485_4: Space = if has_head(&(v485_3)) { singleton(&[]) } else { Space::new() };
    drop(v485_3);
    let v485_5: Space = subtract(&(*CONSTANT_1),&(v485_4));
    drop(v485_4);
    let mut v485_6 = Space::new();
    let mut v485_6_cursor = (v484_6_tail).read_zipper();
    for v485_6_byte in v485_6_cursor.child_mask().iter() {
      v485_6_cursor.descend_to_byte(v485_6_byte);
      let v485_6_tail = v485_6_cursor.make_map();
      v485_6_cursor.ascend(1);
      let v485_6_head = Path::from_slice(&[v485_6_byte]);
      let v486_2: Space = Space::new();
      v485_6.join_into((v486_2).clone());
    }
    drop(v485_6_cursor);
    let v485_7: Space = compose(&(v485_5),&(v485_6));
    drop(v485_5);
    drop(v485_6);
    let v485_8: Space = intersect(&(*CONSTANT_2),&(v485_2));
    drop(v485_2);
    let v485_9: Space = if has_head(&(v485_8)) { singleton(&[]) } else { Space::new() };
    drop(v485_8);
    let v485_10: Space = compose(&(v485_9),&(v484_6_tail));
    drop(v485_9);
    let v485_11: Path = concat_path(&(*p0),&(v484_6_head));
    let v485_12: Space = wrap(&(v485_10),&(v485_11));
    drop(v485_10);
    drop(v485_11);
    let v485_13: Space = wrap(&(v485_12),&(*p1));
    drop(v485_12);
    let v485_14: Space = unite(&(v485_7),&(v485_13));
    drop(v485_7);
    drop(v485_13);
    v484_6.join_into((v485_14).clone());
  }
  drop(v484_6_cursor);
  (v484_6).clone()
}

fn routine_56(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v487_3 = Space::new();
  let mut v487_3_cursor = (*s0).read_zipper();
  for v487_3_byte in v487_3_cursor.child_mask().iter() {
    v487_3_cursor.descend_to_byte(v487_3_byte);
    let v487_3_tail = v487_3_cursor.make_map();
    v487_3_cursor.ascend(1);
    let v487_3_head = Path::from_slice(&[v487_3_byte]);
    let v488_2: Space = Space::new();
    v487_3.join_into((v488_2).clone());
  }
  drop(v487_3_cursor);
  (v487_3).clone()
}

fn routine_57(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v489_4 = Space::new();
  let mut v489_4_cursor = (*s0).read_zipper();
  for v489_4_byte in v489_4_cursor.child_mask().iter() {
    v489_4_cursor.descend_to_byte(v489_4_byte);
    let v489_4_tail = v489_4_cursor.make_map();
    v489_4_cursor.ascend(1);
    let v489_4_head = Path::from_slice(&[v489_4_byte]);
    let v490_2: Space = singleton(&(v489_4_head));
    let v490_3: Space = intersect(&(*CONSTANT_2),&(v490_2));
    drop(v490_2);
    let v490_4: Space = if has_head(&(v490_3)) { singleton(&[]) } else { Space::new() };
    drop(v490_3);
    let v490_5: Space = compose(&(v490_4),&(v489_4_tail));
    drop(v490_4);
    let v490_6: Path = concat_path(&(*p0),&(v489_4_head));
    let v490_7: Space = wrap(&(v490_5),&(v490_6));
    drop(v490_5);
    drop(v490_6);
    v489_4.join_into((v490_7).clone());
  }
  drop(v489_4_cursor);
  let v489_5: Space = wrap(&(v489_4),&(*p1));
  drop(v489_4);
  (v489_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
