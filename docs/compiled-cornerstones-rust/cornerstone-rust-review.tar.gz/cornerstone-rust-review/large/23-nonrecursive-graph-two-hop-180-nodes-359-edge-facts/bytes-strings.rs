#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[101,100,103,101,0]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84,119,111,72,111,112,0]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let mut v0_12 = Space::new();
  let mut v0_12_cursor = (v0_2).read_zipper();
  for v0_12_byte in v0_12_cursor.child_mask().iter() {
    v0_12_cursor.descend_to_byte(v0_12_byte);
    let v0_12_tail = v0_12_cursor.make_map();
    v0_12_cursor.ascend(1);
    let v0_12_head = Path::from_slice(&[v0_12_byte]);
    let v1_2: Space = singleton(&(v0_12_head));
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_12_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        let v2_6_tail = v2_6_cursor.make_map();
        v2_6_cursor.ascend(1);
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_12_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail), &(*s0.expect("unbound native input")));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_12_head),&(v2_6_head));
          let v5_11: Space = routine_2(c, &(v5_6), &(v2_6_tail), &(*s0.expect("unbound native input")));
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_cursor = (v0_12_tail).read_zipper();
      for v6_10_byte in v6_10_cursor.child_mask().iter() {
        v6_10_cursor.descend_to_byte(v6_10_byte);
        let v6_10_tail = v6_10_cursor.make_map();
        v6_10_cursor.ascend(1);
        let v6_10_head = Path::from_slice(&[v6_10_byte]);
        let v7_2: Space = singleton(&(v6_10_head));
        let v7_3: Space = intersect(&(*CONSTANT_2),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_1),&(v7_4));
        drop(v7_4);
        let v7_7: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Space = routine_3(c, &(v6_10_head), &(v0_12_head), &(v6_10_tail), &(*s0.expect("unbound native input")));
          compose(&(v7_5),&(v8_6))
        };
        drop(v7_5);
        let v7_8: Space = intersect(&(*CONSTANT_2),&(v7_2));
        drop(v7_2);
        let v7_9: Space = if has_head(&(v7_8)) { singleton(&[]) } else { Space::new() };
        drop(v7_8);
        let v7_11: Space = if (v7_9).is_empty() { Space::new() } else {
          let v9_10: Space = routine_4(c, &(v6_10_head), &(v0_12_head), &(v6_10_tail), &(*s0.expect("unbound native input")));
          compose(&(v7_9),&(v9_10))
        };
        drop(v7_9);
        let v7_12: Space = unite(&(v7_7),&(v7_11));
        v6_10.join_into((v7_12).clone());
      }
      drop(v6_10_cursor);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_12.join_into((v1_12).clone());
  }
  drop(v0_12_cursor);
  drop(v0_2);
  let v0_14: Space = wrap(&(v0_12),&(*CONSTANT_3));
  (v0_14).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v10_9 = Space::new();
  let mut v10_9_cursor = (*s0).read_zipper();
  for v10_9_byte in v10_9_cursor.child_mask().iter() {
    v10_9_cursor.descend_to_byte(v10_9_byte);
    let v10_9_tail = v10_9_cursor.make_map();
    v10_9_cursor.ascend(1);
    let v10_9_head = Path::from_slice(&[v10_9_byte]);
    let v11_2: Space = singleton(&(v10_9_head));
    let v11_3: Space = intersect(&(*CONSTANT_2),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_1),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&(v10_9_head));
      let v12_7: Space = routine_1(c, &(v12_6), &(v10_9_tail), &(*s1));
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_2),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_12: Space = if (v11_10).is_empty() { Space::new() } else {
      let v13_6: Path = concat_path(&(*p0),&(v10_9_head));
      let mut v13_11 = Space::new();
      let mut v13_11_cursor = (v10_9_tail).read_zipper();
      for v13_11_byte in v13_11_cursor.child_mask().iter() {
        v13_11_cursor.descend_to_byte(v13_11_byte);
        let v13_11_tail = v13_11_cursor.make_map();
        v13_11_cursor.ascend(1);
        let v13_11_head = Path::from_slice(&[v13_11_byte]);
        let v14_2: Space = singleton(&(v13_11_head));
        let v14_3: Space = intersect(&(*CONSTANT_2),&(v14_2));
        let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
        drop(v14_3);
        let v14_5: Space = subtract(&(*CONSTANT_1),&(v14_4));
        drop(v14_4);
        let v14_7: Space = if (v14_5).is_empty() { Space::new() } else {
          let v15_6: Space = routine_3(c, &(v13_11_head), &(v13_6), &(v13_11_tail), &(*s1));
          compose(&(v14_5),&(v15_6))
        };
        drop(v14_5);
        let v14_8: Space = intersect(&(*CONSTANT_2),&(v14_2));
        drop(v14_2);
        let v14_9: Space = if has_head(&(v14_8)) { singleton(&[]) } else { Space::new() };
        drop(v14_8);
        let v14_11: Space = if (v14_9).is_empty() { Space::new() } else {
          let v16_10: Space = routine_4(c, &(v13_11_head), &(v13_6), &(v13_11_tail), &(*s1));
          compose(&(v14_9),&(v16_10))
        };
        drop(v14_9);
        let v14_12: Space = unite(&(v14_7),&(v14_11));
        v13_11.join_into((v14_12).clone());
      }
      drop(v13_11_cursor);
      drop(v13_6);
      compose(&(v11_10),&(v13_11))
    };
    drop(v11_10);
    let v11_13: Space = unite(&(v11_8),&(v11_12));
    v10_9.join_into((v11_13).clone());
  }
  drop(v10_9_cursor);
  (v10_9).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v17_7: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let mut v17_14 = Space::new();
  let mut v17_14_cursor = (*s0).read_zipper();
  for v17_14_byte in v17_14_cursor.child_mask().iter() {
    v17_14_cursor.descend_to_byte(v17_14_byte);
    let v17_14_tail = v17_14_cursor.make_map();
    v17_14_cursor.ascend(1);
    let v17_14_head = Path::from_slice(&[v17_14_byte]);
    let v18_2: Space = singleton(&(v17_14_head));
    let v18_3: Space = intersect(&(*CONSTANT_2),&(v18_2));
    let v18_4: Space = if has_head(&(v18_3)) { singleton(&[]) } else { Space::new() };
    drop(v18_3);
    let v18_5: Space = subtract(&(*CONSTANT_1),&(v18_4));
    drop(v18_4);
    let v18_7: Space = if (v18_5).is_empty() { Space::new() } else {
      let mut v19_6 = Space::new();
      let mut v19_6_cursor = (v17_14_tail).read_zipper();
      for v19_6_byte in v19_6_cursor.child_mask().iter() {
        v19_6_cursor.descend_to_byte(v19_6_byte);
        let v19_6_tail = v19_6_cursor.make_map();
        v19_6_cursor.ascend(1);
        let v19_6_head = Path::from_slice(&[v19_6_byte]);
        let v20_2: Space = singleton(&(v19_6_head));
        let v20_3: Space = intersect(&(*CONSTANT_2),&(v20_2));
        let v20_4: Space = if has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
        drop(v20_3);
        let v20_5: Space = subtract(&(*CONSTANT_1),&(v20_4));
        drop(v20_4);
        let v20_8: Space = if (v20_5).is_empty() { Space::new() } else {
          let v21_6: Path = concat_path(&(v17_14_head),&(v19_6_head));
          let v21_7: Space = routine_3(c, &(v21_6), &(*p0), &(v19_6_tail), &(*s1));
          compose(&(v20_5),&(v21_7))
        };
        drop(v20_5);
        let v20_9: Space = intersect(&(*CONSTANT_2),&(v20_2));
        drop(v20_2);
        let v20_10: Space = if has_head(&(v20_9)) { singleton(&[]) } else { Space::new() };
        drop(v20_9);
        let v20_12: Space = if (v20_10).is_empty() { Space::new() } else {
          let v22_6: Path = concat_path(&(v17_14_head),&(v19_6_head));
          let v22_11: Space = routine_4(c, &(v22_6), &(*p0), &(v19_6_tail), &(*s1));
          drop(v22_6);
          compose(&(v20_10),&(v22_11))
        };
        drop(v20_10);
        let v20_13: Space = unite(&(v20_8),&(v20_12));
        v19_6.join_into((v20_13).clone());
      }
      drop(v19_6_cursor);
      compose(&(v18_5),&(v19_6))
    };
    drop(v18_5);
    let v18_8: Space = intersect(&(*CONSTANT_2),&(v18_2));
    drop(v18_2);
    let v18_9: Space = if has_head(&(v18_8)) { singleton(&[]) } else { Space::new() };
    drop(v18_8);
    let v18_12: Space = if (v18_9).is_empty() { Space::new() } else {
      let v23_10: Space = unwrap(&(v17_7),&(v17_14_head));
      let mut v23_11 = Space::new();
      let mut v23_11_cursor = (v23_10).read_zipper();
      for v23_11_byte in v23_11_cursor.child_mask().iter() {
        v23_11_cursor.descend_to_byte(v23_11_byte);
        let v23_11_tail = v23_11_cursor.make_map();
        v23_11_cursor.ascend(1);
        let v23_11_head = Path::from_slice(&[v23_11_byte]);
        let v24_2: Space = singleton(&(v23_11_head));
        let v24_3: Space = intersect(&(*CONSTANT_2),&(v24_2));
        let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
        drop(v24_3);
        let v24_5: Space = subtract(&(*CONSTANT_1),&(v24_4));
        drop(v24_4);
        let v24_7: Space = if (v24_5).is_empty() { Space::new() } else {
          let v25_6: Space = routine_5(c, &(v23_11_head), &(*p0), &(v23_11_tail));
          compose(&(v24_5),&(v25_6))
        };
        drop(v24_5);
        let v24_8: Space = intersect(&(*CONSTANT_2),&(v24_2));
        drop(v24_2);
        let v24_9: Space = if has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
        drop(v24_8);
        let v24_11: Space = if (v24_9).is_empty() { Space::new() } else {
          let v26_10: Space = routine_6(c, &(v23_11_head), &(*p0), &(v23_11_tail));
          compose(&(v24_9),&(v26_10))
        };
        drop(v24_9);
        let v24_12: Space = unite(&(v24_7),&(v24_11));
        v23_11.join_into((v24_12).clone());
      }
      drop(v23_11_cursor);
      drop(v23_10);
      compose(&(v18_9),&(v23_11))
    };
    drop(v18_9);
    let v18_13: Space = unite(&(v18_7),&(v18_12));
    v17_14.join_into((v18_13).clone());
  }
  drop(v17_14_cursor);
  drop(v17_7);
  (v17_14).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v27_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v27_9: Space = unwrap(&(v27_8),&(*p0));
  drop(v27_8);
  let mut v27_13 = Space::new();
  let mut v27_13_cursor = (*s0).read_zipper();
  for v27_13_byte in v27_13_cursor.child_mask().iter() {
    v27_13_cursor.descend_to_byte(v27_13_byte);
    let v27_13_tail = v27_13_cursor.make_map();
    v27_13_cursor.ascend(1);
    let v27_13_head = Path::from_slice(&[v27_13_byte]);
    let v28_2: Space = singleton(&(v27_13_head));
    let v28_3: Space = intersect(&(*CONSTANT_2),&(v28_2));
    let v28_4: Space = if has_head(&(v28_3)) { singleton(&[]) } else { Space::new() };
    drop(v28_3);
    let v28_5: Space = subtract(&(*CONSTANT_1),&(v28_4));
    drop(v28_4);
    let v28_8: Space = if (v28_5).is_empty() { Space::new() } else {
      let v29_6: Path = concat_path(&(*p0),&(v27_13_head));
      let v29_7: Space = routine_3(c, &(v29_6), &(*p1), &(v27_13_tail), &(*s1));
      drop(v29_6);
      compose(&(v28_5),&(v29_7))
    };
    drop(v28_5);
    let v28_9: Space = intersect(&(*CONSTANT_2),&(v28_2));
    drop(v28_2);
    let v28_10: Space = if has_head(&(v28_9)) { singleton(&[]) } else { Space::new() };
    drop(v28_9);
    let v28_13: Space = if (v28_10).is_empty() { Space::new() } else {
      let v30_11: Space = unwrap(&(v27_9),&(v27_13_head));
      let mut v30_12 = Space::new();
      let mut v30_12_cursor = (v30_11).read_zipper();
      for v30_12_byte in v30_12_cursor.child_mask().iter() {
        v30_12_cursor.descend_to_byte(v30_12_byte);
        let v30_12_tail = v30_12_cursor.make_map();
        v30_12_cursor.ascend(1);
        let v30_12_head = Path::from_slice(&[v30_12_byte]);
        let v31_2: Space = singleton(&(v30_12_head));
        let v31_3: Space = intersect(&(*CONSTANT_2),&(v31_2));
        let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
        drop(v31_3);
        let v31_5: Space = subtract(&(*CONSTANT_1),&(v31_4));
        drop(v31_4);
        let v31_7: Space = if (v31_5).is_empty() { Space::new() } else {
          let v32_6: Space = routine_5(c, &(v30_12_head), &(*p1), &(v30_12_tail));
          compose(&(v31_5),&(v32_6))
        };
        drop(v31_5);
        let v31_8: Space = intersect(&(*CONSTANT_2),&(v31_2));
        drop(v31_2);
        let v31_9: Space = if has_head(&(v31_8)) { singleton(&[]) } else { Space::new() };
        drop(v31_8);
        let v31_11: Space = if (v31_9).is_empty() { Space::new() } else {
          let v33_10: Space = routine_6(c, &(v30_12_head), &(*p1), &(v30_12_tail));
          compose(&(v31_9),&(v33_10))
        };
        drop(v31_9);
        let v31_12: Space = unite(&(v31_7),&(v31_11));
        v30_12.join_into((v31_12).clone());
      }
      drop(v30_12_cursor);
      drop(v30_11);
      compose(&(v28_10),&(v30_12))
    };
    drop(v28_10);
    let v28_14: Space = unite(&(v28_8),&(v28_13));
    v27_13.join_into((v28_14).clone());
  }
  drop(v27_13_cursor);
  drop(v27_9);
  (v27_13).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v34_5: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v34_6: Space = unwrap(&(v34_5),&(*p0));
  drop(v34_5);
  let mut v34_13 = Space::new();
  let mut v34_13_cursor = (v34_6).read_zipper();
  for v34_13_byte in v34_13_cursor.child_mask().iter() {
    v34_13_cursor.descend_to_byte(v34_13_byte);
    let v34_13_tail = v34_13_cursor.make_map();
    v34_13_cursor.ascend(1);
    let v34_13_head = Path::from_slice(&[v34_13_byte]);
    let v35_2: Space = singleton(&(v34_13_head));
    let v35_3: Space = intersect(&(*CONSTANT_2),&(v35_2));
    let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
    drop(v35_3);
    let v35_5: Space = subtract(&(*CONSTANT_1),&(v35_4));
    drop(v35_4);
    let v35_7: Space = if (v35_5).is_empty() { Space::new() } else {
      let mut v36_6 = Space::new();
      let mut v36_6_cursor = (v34_13_tail).read_zipper();
      for v36_6_byte in v36_6_cursor.child_mask().iter() {
        v36_6_cursor.descend_to_byte(v36_6_byte);
        let v36_6_tail = v36_6_cursor.make_map();
        v36_6_cursor.ascend(1);
        let v36_6_head = Path::from_slice(&[v36_6_byte]);
        let v37_2: Space = singleton(&(v36_6_head));
        let v37_3: Space = intersect(&(*CONSTANT_2),&(v37_2));
        let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
        drop(v37_3);
        let v37_5: Space = subtract(&(*CONSTANT_1),&(v37_4));
        drop(v37_4);
        let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
          let v38_6: Path = concat_path(&(v34_13_head),&(v36_6_head));
          let v38_7: Space = routine_5(c, &(v38_6), &(*p1), &(v36_6_tail));
          compose(&(v37_5),&(v38_7))
        };
        drop(v37_5);
        let v37_9: Space = intersect(&(*CONSTANT_2),&(v37_2));
        drop(v37_2);
        let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
        drop(v37_9);
        let v37_12: Space = if (v37_10).is_empty() { Space::new() } else {
          let v39_6: Path = concat_path(&(v34_13_head),&(v36_6_head));
          let v39_11: Space = routine_6(c, &(v39_6), &(*p1), &(v36_6_tail));
          drop(v39_6);
          compose(&(v37_10),&(v39_11))
        };
        drop(v37_10);
        let v37_13: Space = unite(&(v37_8),&(v37_12));
        v36_6.join_into((v37_13).clone());
      }
      drop(v36_6_cursor);
      compose(&(v35_5),&(v36_6))
    };
    drop(v35_5);
    let v35_8: Space = intersect(&(*CONSTANT_2),&(v35_2));
    drop(v35_2);
    let v35_9: Space = if has_head(&(v35_8)) { singleton(&[]) } else { Space::new() };
    drop(v35_8);
    let v35_10: Space = compose(&(v35_9),&(v34_13_tail));
    drop(v35_9);
    let v35_11: Space = wrap(&(v35_10),&(v34_13_head));
    drop(v35_10);
    let v35_12: Space = wrap(&(v35_11),&(*p1));
    drop(v35_11);
    let v35_13: Space = unite(&(v35_7),&(v35_12));
    drop(v35_12);
    v34_13.join_into((v35_13).clone());
  }
  drop(v34_13_cursor);
  drop(v34_6);
  (v34_13).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v40_6 = Space::new();
  let mut v40_6_cursor = (*s0).read_zipper();
  for v40_6_byte in v40_6_cursor.child_mask().iter() {
    v40_6_cursor.descend_to_byte(v40_6_byte);
    let v40_6_tail = v40_6_cursor.make_map();
    v40_6_cursor.ascend(1);
    let v40_6_head = Path::from_slice(&[v40_6_byte]);
    let v41_2: Space = singleton(&(v40_6_head));
    let v41_3: Space = intersect(&(*CONSTANT_2),&(v41_2));
    let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
    drop(v41_3);
    let v41_5: Space = subtract(&(*CONSTANT_1),&(v41_4));
    drop(v41_4);
    let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
      let v42_6: Path = concat_path(&(*p0),&(v40_6_head));
      let v42_7: Space = routine_5(c, &(v42_6), &(*p1), &(v40_6_tail));
      compose(&(v41_5),&(v42_7))
    };
    drop(v41_5);
    let v41_9: Space = intersect(&(*CONSTANT_2),&(v41_2));
    drop(v41_2);
    let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
    drop(v41_9);
    let v41_11: Space = compose(&(v41_10),&(v40_6_tail));
    drop(v41_10);
    let v43_6: Path = concat_path(&(*p0),&(v40_6_head));
    let v41_12: Space = wrap(&(v41_11),&(v43_6));
    drop(v41_11);
    let v41_13: Space = wrap(&(v41_12),&(*p1));
    drop(v41_12);
    let v41_14: Space = unite(&(v41_8),&(v41_13));
    drop(v41_13);
    v40_6.join_into((v41_14).clone());
  }
  drop(v40_6_cursor);
  (v40_6).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v44_3: Space = wrap(&(*s0),&(*p0));
  let v44_4: Space = wrap(&(v44_3),&(*p1));
  drop(v44_3);
  (v44_4).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
