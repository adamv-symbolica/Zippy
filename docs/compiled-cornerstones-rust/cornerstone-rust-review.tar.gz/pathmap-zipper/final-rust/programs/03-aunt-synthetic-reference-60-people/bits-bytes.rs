#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,0,1,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,0,1,0,0,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>) -> Space {
  let mut v0_11 = Space::new();
  let mut v0_11_cursor = (*s1.expect("unbound native input")).read_zipper();
  for v0_11_byte in v0_11_cursor.child_mask().iter() {
    v0_11_cursor.descend_to_byte(v0_11_byte);
    {
    let v0_11_tail = v0_11_cursor.fork_read_zipper();
    let v0_11_head = Path::from_slice(&[v0_11_byte]);
    let v1_2: Space = singleton(&(v0_11_head));
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_11_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        {
        let v2_6_tail = v2_6_cursor.fork_read_zipper();
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_1),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_11_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail).make_space(), &(*s0.expect("unbound native input")));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_1),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_11_head),&(v2_6_head));
          let v5_11: Space = routine_2(c, &(v5_6), &(v2_6_tail).make_space(), &(*s0.expect("unbound native input")));
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
        }
        v2_6_cursor.ascend(1);
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_cursor = (v0_11_tail).read_zipper();
      for v6_10_byte in v6_10_cursor.child_mask().iter() {
        v6_10_cursor.descend_to_byte(v6_10_byte);
        {
        let v6_10_tail = v6_10_cursor.fork_read_zipper();
        let v6_10_head = Path::from_slice(&[v6_10_byte]);
        let v7_2: Space = singleton(&(v6_10_head));
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_11_head),&(v6_10_head));
          let v8_7: Space = routine_1(c, &(v8_6), &(v6_10_tail).make_space(), &(*s0.expect("unbound native input")));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v0_11_head),&(v6_10_head));
          let v9_11: Space = routine_3(c, &(v9_6), &(v6_10_tail).make_space(), &(*s0.expect("unbound native input")));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_10.join_into((v7_13).clone());
        }
        v6_10_cursor.ascend(1);
      }
      drop(v6_10_cursor);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_11.join_into((v1_12).clone());
    }
    v0_11_cursor.ascend(1);
  }
  drop(v0_11_cursor);
  let v0_13: Space = wrap(&(v0_11),&(*CONSTANT_2));
  (v0_13).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v10_21: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v10_22: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v10_23: Space = unwrap(&(v10_22),&(*p0));
  let v10_24: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v10_34 = Space::new();
  let mut v10_34_cursor = (*s0).read_zipper();
  for v10_34_byte in v10_34_cursor.child_mask().iter() {
    v10_34_cursor.descend_to_byte(v10_34_byte);
    {
    let v10_34_tail = v10_34_cursor.fork_read_zipper();
    let v10_34_head = Path::from_slice(&[v10_34_byte]);
    let v11_2: Space = singleton(&(v10_34_head));
    let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&(v10_34_head));
      let mut v12_7 = Space::new();
      let mut v12_7_cursor = (v10_34_tail).read_zipper();
      for v12_7_byte in v12_7_cursor.child_mask().iter() {
        v12_7_cursor.descend_to_byte(v12_7_byte);
        {
        let v12_7_tail = v12_7_cursor.fork_read_zipper();
        let v12_7_head = Path::from_slice(&[v12_7_byte]);
        let v13_2: Space = singleton(&(v12_7_head));
        let v13_3: Space = intersect(&(*CONSTANT_1),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let mut v14_7 = Space::new();
          let mut v14_7_cursor = (v12_7_tail).read_zipper();
          for v14_7_byte in v14_7_cursor.child_mask().iter() {
            v14_7_cursor.descend_to_byte(v14_7_byte);
            {
            let v14_7_tail = v14_7_cursor.fork_read_zipper();
            let v14_7_head = Path::from_slice(&[v14_7_byte]);
            let v15_2: Space = singleton(&(v14_7_head));
            let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v16_7: Space = routine_4(c, &(v16_6), &(v14_7_tail).make_space(), &(*s1));
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (v15_10).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v17_11: Space = routine_5(c, &(v17_6), &(v14_7_tail).make_space(), &(*s1));
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            v14_7.join_into((v15_13).clone());
            }
            v14_7_cursor.ascend(1);
          }
          drop(v14_7_cursor);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_1),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let mut v18_11 = Space::new();
          let mut v18_11_cursor = (v12_7_tail).read_zipper();
          for v18_11_byte in v18_11_cursor.child_mask().iter() {
            v18_11_cursor.descend_to_byte(v18_11_byte);
            {
            let v18_11_tail = v18_11_cursor.fork_read_zipper();
            let v18_11_head = Path::from_slice(&[v18_11_byte]);
            let v19_2: Space = singleton(&(v18_11_head));
            let v19_3: Space = intersect(&(*CONSTANT_1),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (v19_5).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v18_6),&(v18_11_head));
              let v20_7: Space = routine_4(c, &(v20_6), &(v18_11_tail).make_space(), &(*s1));
              compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = intersect(&(*CONSTANT_1),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v19_12: Space = if (v19_10).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v18_6),&(v18_11_head));
              let v21_11: Space = routine_3(c, &(v21_6), &(v18_11_tail).make_space(), &(*s1));
              drop(v21_6);
              compose(&(v19_10),&(v21_11))
            };
            drop(v19_10);
            let v19_13: Space = unite(&(v19_8),&(v19_12));
            v18_11.join_into((v19_13).clone());
            }
            v18_11_cursor.ascend(1);
          }
          drop(v18_11_cursor);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        v12_7.join_into((v13_13).clone());
        }
        v12_7_cursor.ascend(1);
      }
      drop(v12_7_cursor);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_13: Space = if (v11_10).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&(v10_34_head));
      let v22_11: Space = unwrap(&(v10_23),&(v10_34_head));
      let mut v22_12 = Space::new();
      let mut v22_12_cursor = (v10_34_tail).read_zipper();
      for v22_12_byte in v22_12_cursor.child_mask().iter() {
        v22_12_cursor.descend_to_byte(v22_12_byte);
        {
        let v22_12_tail = v22_12_cursor.fork_read_zipper();
        let v22_12_head = Path::from_slice(&[v22_12_byte]);
        let v23_2: Space = singleton(&(v22_12_head));
        let v23_3: Space = intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&(v22_12_head));
          let mut v24_7 = Space::new();
          let mut v24_7_cursor = (v22_12_tail).read_zipper();
          for v24_7_byte in v24_7_cursor.child_mask().iter() {
            v24_7_cursor.descend_to_byte(v24_7_byte);
            {
            let v24_7_tail = v24_7_cursor.fork_read_zipper();
            let v24_7_head = Path::from_slice(&[v24_7_byte]);
            let v25_2: Space = singleton(&(v24_7_head));
            let v25_3: Space = intersect(&(*CONSTANT_1),&(v25_2));
            let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
            drop(v25_3);
            let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
            drop(v25_4);
            let v25_8: Space = if (v25_5).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v24_6),&(v24_7_head));
              let v26_7: Space = routine_4(c, &(v26_6), &(v24_7_tail).make_space(), &(*s1));
              compose(&(v25_5),&(v26_7))
            };
            drop(v25_5);
            let v25_9: Space = intersect(&(*CONSTANT_1),&(v25_2));
            drop(v25_2);
            let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
            drop(v25_9);
            let v25_12: Space = if (v25_10).is_empty() { Space::new() } else {
              let v27_6: Path = concat_path(&(v24_6),&(v24_7_head));
              let v27_11: Space = routine_5(c, &(v27_6), &(v24_7_tail).make_space(), &(*s1));
              drop(v27_6);
              compose(&(v25_10),&(v27_11))
            };
            drop(v25_10);
            let v25_13: Space = unite(&(v25_8),&(v25_12));
            v24_7.join_into((v25_13).clone());
            }
            v24_7_cursor.ascend(1);
          }
          drop(v24_7_cursor);
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_18: Space = if (v23_10).is_empty() { Space::new() } else {
          let v28_11: Space = unwrap(&(v22_11),&(v22_12_head));
          let v28_12: Space = restrict_to(&(v10_22),&(v28_11));
          let mut v28_13 = Space::new();
          let mut v28_13_cursor = (v28_12).read_zipper();
          for v28_13_byte in v28_13_cursor.child_mask().iter() {
            v28_13_cursor.descend_to_byte(v28_13_byte);
            {
            let v28_13_tail = v28_13_cursor.fork_read_zipper();
            let v28_13_head = Path::from_slice(&[v28_13_byte]);
            let v29_2: Space = singleton(&(v28_13_head));
            let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
            let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
            drop(v29_3);
            let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
            drop(v29_4);
            let v29_7: Space = if (v29_5).is_empty() { Space::new() } else {
              let v30_6: Space = routine_6(c, &(v28_13_head), &(v28_13_tail).make_space());
              compose(&(v29_5),&(v30_6))
            };
            drop(v29_5);
            let v29_8: Space = intersect(&(*CONSTANT_1),&(v29_2));
            drop(v29_2);
            let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
            drop(v29_8);
            let v29_11: Space = if (v29_9).is_empty() { Space::new() } else {
              let v31_10: Space = routine_7(c, &(v28_13_head), &(v28_13_tail).make_space());
              compose(&(v29_9),&(v31_10))
            };
            drop(v29_9);
            let v29_12: Space = unite(&(v29_7),&(v29_11));
            v28_13.join_into((v29_12).clone());
            }
            v28_13_cursor.ascend(1);
          }
          drop(v28_13_cursor);
          drop(v28_12);
          let v28_14: Space = restrict_to(&(v10_21),&(v28_13));
          let mut v28_15 = Space::new();
          let mut v28_15_cursor = (v28_14).read_zipper();
          for v28_15_byte in v28_15_cursor.child_mask().iter() {
            v28_15_cursor.descend_to_byte(v28_15_byte);
            {
            let v28_15_tail = v28_15_cursor.fork_read_zipper();
            let v28_15_head = Path::from_slice(&[v28_15_byte]);
            let v32_2: Space = singleton(&(v28_15_head));
            let v32_3: Space = intersect(&(*CONSTANT_1),&(v32_2));
            let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_7: Space = if (v32_5).is_empty() { Space::new() } else {
              let v33_6: Space = routine_8(c, &(v28_15_head), &(v28_15_tail).make_space());
              compose(&(v32_5),&(v33_6))
            };
            drop(v32_5);
            let v32_8: Space = intersect(&(*CONSTANT_1),&(v32_2));
            drop(v32_2);
            let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
            drop(v32_8);
            let v32_11: Space = if (v32_9).is_empty() { Space::new() } else {
              let v34_10: Space = routine_9(c, &(v28_15_head), &(v28_15_tail).make_space());
              compose(&(v32_9),&(v34_10))
            };
            drop(v32_9);
            let v32_12: Space = unite(&(v32_7),&(v32_11));
            v28_15.join_into((v32_12).clone());
            }
            v28_15_cursor.ascend(1);
          }
          drop(v28_15_cursor);
          let v28_16: Space = subtract(&(v28_15),&(v28_11));
          drop(v28_11);
          let v28_17: Space = intersect(&(v28_16),&(v10_24));
          compose(&(v23_10),&(v28_17))
        };
        drop(v23_10);
        let v35_6: Path = concat_path(&(v22_6),&(v22_12_head));
        let v23_19: Space = wrap(&(v23_18),&(v35_6));
        let v23_20: Space = unite(&(v23_8),&(v23_19));
        v22_12.join_into((v23_20).clone());
        }
        v22_12_cursor.ascend(1);
      }
      drop(v22_12_cursor);
      drop(v22_6);
      drop(v22_11);
      compose(&(v11_10),&(v22_12))
    };
    drop(v11_10);
    let v11_14: Space = unite(&(v11_8),&(v11_13));
    v10_34.join_into((v11_14).clone());
    }
    v10_34_cursor.ascend(1);
  }
  drop(v10_34_cursor);
  drop(v10_21);
  drop(v10_22);
  drop(v10_23);
  drop(v10_24);
  (v10_34).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v36_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v36_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v36_10: Space = unwrap(&(v36_9),&(*p0));
  let v36_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v36_40 = Space::new();
  let mut v36_40_cursor = (*s0).read_zipper();
  for v36_40_byte in v36_40_cursor.child_mask().iter() {
    v36_40_cursor.descend_to_byte(v36_40_byte);
    {
    let v36_40_tail = v36_40_cursor.fork_read_zipper();
    let v36_40_head = Path::from_slice(&[v36_40_byte]);
    let v37_2: Space = singleton(&(v36_40_head));
    let v37_3: Space = intersect(&(*CONSTANT_1),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
      let v38_6: Path = concat_path(&(*p0),&(v36_40_head));
      let mut v38_7 = Space::new();
      let mut v38_7_cursor = (v36_40_tail).read_zipper();
      for v38_7_byte in v38_7_cursor.child_mask().iter() {
        v38_7_cursor.descend_to_byte(v38_7_byte);
        {
        let v38_7_tail = v38_7_cursor.fork_read_zipper();
        let v38_7_head = Path::from_slice(&[v38_7_byte]);
        let v39_2: Space = singleton(&(v38_7_head));
        let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (v39_5).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v38_6),&(v38_7_head));
          let mut v40_7 = Space::new();
          let mut v40_7_cursor = (v38_7_tail).read_zipper();
          for v40_7_byte in v40_7_cursor.child_mask().iter() {
            v40_7_cursor.descend_to_byte(v40_7_byte);
            {
            let v40_7_tail = v40_7_cursor.fork_read_zipper();
            let v40_7_head = Path::from_slice(&[v40_7_byte]);
            let v41_2: Space = singleton(&(v40_7_head));
            let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
            drop(v41_4);
            let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v40_6),&(v40_7_head));
              let v42_7: Space = routine_4(c, &(v42_6), &(v40_7_tail).make_space(), &(*s1));
              compose(&(v41_5),&(v42_7))
            };
            drop(v41_5);
            let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
            drop(v41_2);
            let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
            drop(v41_9);
            let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v40_6),&(v40_7_head));
              let v43_11: Space = routine_5(c, &(v43_6), &(v40_7_tail).make_space(), &(*s1));
              drop(v43_6);
              compose(&(v41_10),&(v43_11))
            };
            drop(v41_10);
            let v41_13: Space = unite(&(v41_8),&(v41_12));
            v40_7.join_into((v41_13).clone());
            }
            v40_7_cursor.ascend(1);
          }
          drop(v40_7_cursor);
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (v39_10).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v38_6),&(v38_7_head));
          let mut v44_11 = Space::new();
          let mut v44_11_cursor = (v38_7_tail).read_zipper();
          for v44_11_byte in v44_11_cursor.child_mask().iter() {
            v44_11_cursor.descend_to_byte(v44_11_byte);
            {
            let v44_11_tail = v44_11_cursor.fork_read_zipper();
            let v44_11_head = Path::from_slice(&[v44_11_byte]);
            let v45_2: Space = singleton(&(v44_11_head));
            let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
            let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_8: Space = if (v45_5).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v44_6),&(v44_11_head));
              let v46_7: Space = routine_4(c, &(v46_6), &(v44_11_tail).make_space(), &(*s1));
              compose(&(v45_5),&(v46_7))
            };
            drop(v45_5);
            let v45_9: Space = intersect(&(*CONSTANT_1),&(v45_2));
            drop(v45_2);
            let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
            drop(v45_9);
            let v45_12: Space = if (v45_10).is_empty() { Space::new() } else {
              let v47_6: Path = concat_path(&(v44_6),&(v44_11_head));
              let v47_11: Space = routine_3(c, &(v47_6), &(v44_11_tail).make_space(), &(*s1));
              drop(v47_6);
              compose(&(v45_10),&(v47_11))
            };
            drop(v45_10);
            let v45_13: Space = unite(&(v45_8),&(v45_12));
            v44_11.join_into((v45_13).clone());
            }
            v44_11_cursor.ascend(1);
          }
          drop(v44_11_cursor);
          drop(v44_6);
          compose(&(v39_10),&(v44_11))
        };
        drop(v39_10);
        let v39_13: Space = unite(&(v39_8),&(v39_12));
        v38_7.join_into((v39_13).clone());
        }
        v38_7_cursor.ascend(1);
      }
      drop(v38_7_cursor);
      compose(&(v37_5),&(v38_7))
    };
    drop(v37_5);
    let v37_9: Space = intersect(&(*CONSTANT_1),&(v37_2));
    drop(v37_2);
    let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
    drop(v37_9);
    let v37_18: Space = if (v37_10).is_empty() { Space::new() } else {
      let v48_11: Space = unwrap(&(v36_10),&(v36_40_head));
      let v48_12: Space = restrict_to(&(v36_9),&(v48_11));
      let mut v48_13 = Space::new();
      let mut v48_13_cursor = (v48_12).read_zipper();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_byte(v48_13_byte);
        {
        let v48_13_tail = v48_13_cursor.fork_read_zipper();
        let v48_13_head = Path::from_slice(&[v48_13_byte]);
        let v49_2: Space = singleton(&(v48_13_head));
        let v49_3: Space = intersect(&(*CONSTANT_1),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (v49_5).is_empty() { Space::new() } else {
          let mut v50_6 = Space::new();
          let mut v50_6_cursor = (v48_13_tail).read_zipper();
          for v50_6_byte in v50_6_cursor.child_mask().iter() {
            v50_6_cursor.descend_to_byte(v50_6_byte);
            {
            let v50_6_tail = v50_6_cursor.fork_read_zipper();
            let v50_6_head = Path::from_slice(&[v50_6_byte]);
            let v51_2: Space = singleton(&(v50_6_head));
            let v51_3: Space = intersect(&(*CONSTANT_1),&(v51_2));
            let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
            drop(v51_3);
            let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
            drop(v51_4);
            let v51_8: Space = if (v51_5).is_empty() { Space::new() } else {
              let v52_6: Path = concat_path(&(v48_13_head),&(v50_6_head));
              let v52_7: Space = routine_10(c, &(v52_6), &(v50_6_tail).make_space());
              compose(&(v51_5),&(v52_7))
            };
            drop(v51_5);
            let v51_9: Space = intersect(&(*CONSTANT_1),&(v51_2));
            drop(v51_2);
            let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
            drop(v51_9);
            let v51_12: Space = if (v51_10).is_empty() { Space::new() } else {
              let v53_6: Path = concat_path(&(v48_13_head),&(v50_6_head));
              let v53_11: Space = routine_11(c, &(v53_6), &(v50_6_tail).make_space());
              drop(v53_6);
              compose(&(v51_10),&(v53_11))
            };
            drop(v51_10);
            let v51_13: Space = unite(&(v51_8),&(v51_12));
            v50_6.join_into((v51_13).clone());
            }
            v50_6_cursor.ascend(1);
          }
          drop(v50_6_cursor);
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_1),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (v49_9).is_empty() { Space::new() } else {
          let mut v54_10 = Space::new();
          let mut v54_10_cursor = (v48_13_tail).read_zipper();
          for v54_10_byte in v54_10_cursor.child_mask().iter() {
            v54_10_cursor.descend_to_byte(v54_10_byte);
            {
            let v54_10_tail = v54_10_cursor.fork_read_zipper();
            let v54_10_head = Path::from_slice(&[v54_10_byte]);
            let v55_2: Space = singleton(&(v54_10_head));
            let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
            let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
            drop(v55_3);
            let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
            drop(v55_4);
            let v55_8: Space = if (v55_5).is_empty() { Space::new() } else {
              let v56_6: Path = concat_path(&(v48_13_head),&(v54_10_head));
              let v56_7: Space = routine_10(c, &(v56_6), &(v54_10_tail).make_space());
              compose(&(v55_5),&(v56_7))
            };
            drop(v55_5);
            let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
            drop(v55_2);
            let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
            drop(v55_9);
            let v55_12: Space = if (v55_10).is_empty() { Space::new() } else {
              let v57_6: Path = concat_path(&(v48_13_head),&(v54_10_head));
              let v57_11: Space = routine_12(c, &(v57_6), &(v54_10_tail).make_space());
              drop(v57_6);
              compose(&(v55_10),&(v57_11))
            };
            drop(v55_10);
            let v55_13: Space = unite(&(v55_8),&(v55_12));
            v54_10.join_into((v55_13).clone());
            }
            v54_10_cursor.ascend(1);
          }
          drop(v54_10_cursor);
          compose(&(v49_9),&(v54_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        v48_13.join_into((v49_12).clone());
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_12);
      let v48_14: Space = restrict_to(&(v36_7),&(v48_13));
      let mut v48_15 = Space::new();
      let mut v48_15_cursor = (v48_14).read_zipper();
      for v48_15_byte in v48_15_cursor.child_mask().iter() {
        v48_15_cursor.descend_to_byte(v48_15_byte);
        {
        let v48_15_tail = v48_15_cursor.fork_read_zipper();
        let v48_15_head = Path::from_slice(&[v48_15_byte]);
        let v58_2: Space = singleton(&(v48_15_head));
        let v58_3: Space = intersect(&(*CONSTANT_1),&(v58_2));
        let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (v58_5).is_empty() { Space::new() } else {
          let mut v59_6 = Space::new();
          let mut v59_6_cursor = (v48_15_tail).read_zipper();
          for v59_6_byte in v59_6_cursor.child_mask().iter() {
            v59_6_cursor.descend_to_byte(v59_6_byte);
            {
            let v59_6_tail = v59_6_cursor.fork_read_zipper();
            let v59_6_head = Path::from_slice(&[v59_6_byte]);
            let v60_2: Space = singleton(&(v59_6_head));
            let v60_3: Space = intersect(&(*CONSTANT_1),&(v60_2));
            let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (v60_5).is_empty() { Space::new() } else {
              let v61_6: Path = concat_path(&(v48_15_head),&(v59_6_head));
              let v61_7: Space = routine_13(c, &(v61_6), &(v59_6_tail).make_space());
              compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = intersect(&(*CONSTANT_1),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (v60_10).is_empty() { Space::new() } else {
              let v62_6: Path = concat_path(&(v48_15_head),&(v59_6_head));
              let v62_11: Space = routine_14(c, &(v62_6), &(v59_6_tail).make_space());
              drop(v62_6);
              compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = unite(&(v60_8),&(v60_12));
            v59_6.join_into((v60_13).clone());
            }
            v59_6_cursor.ascend(1);
          }
          drop(v59_6_cursor);
          compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = intersect(&(*CONSTANT_1),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (v58_9).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_cursor = (v48_15_tail).read_zipper();
          for v63_10_byte in v63_10_cursor.child_mask().iter() {
            v63_10_cursor.descend_to_byte(v63_10_byte);
            {
            let v63_10_tail = v63_10_cursor.fork_read_zipper();
            let v63_10_head = Path::from_slice(&[v63_10_byte]);
            let v64_2: Space = singleton(&(v63_10_head));
            let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
            let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_8: Space = if (v64_5).is_empty() { Space::new() } else {
              let v65_6: Path = concat_path(&(v48_15_head),&(v63_10_head));
              let v65_7: Space = routine_13(c, &(v65_6), &(v63_10_tail).make_space());
              compose(&(v64_5),&(v65_7))
            };
            drop(v64_5);
            let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
            drop(v64_2);
            let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
            drop(v64_9);
            let v64_12: Space = if (v64_10).is_empty() { Space::new() } else {
              let v66_6: Path = concat_path(&(v48_15_head),&(v63_10_head));
              let v66_11: Space = routine_15(c, &(v66_6), &(v63_10_tail).make_space());
              drop(v66_6);
              compose(&(v64_10),&(v66_11))
            };
            drop(v64_10);
            let v64_13: Space = unite(&(v64_8),&(v64_12));
            v63_10.join_into((v64_13).clone());
            }
            v63_10_cursor.ascend(1);
          }
          drop(v63_10_cursor);
          compose(&(v58_9),&(v63_10))
        };
        drop(v58_9);
        let v58_12: Space = unite(&(v58_7),&(v58_11));
        v48_15.join_into((v58_12).clone());
        }
        v48_15_cursor.ascend(1);
      }
      drop(v48_15_cursor);
      let v48_16: Space = subtract(&(v48_15),&(v48_11));
      drop(v48_11);
      let v48_17: Space = intersect(&(v48_16),&(v36_12));
      compose(&(v37_10),&(v48_17))
    };
    drop(v37_10);
    let v67_6: Path = concat_path(&(*p0),&(v36_40_head));
    let v37_19: Space = wrap(&(v37_18),&(v67_6));
    let v37_20: Space = unite(&(v37_8),&(v37_19));
    v36_40.join_into((v37_20).clone());
    }
    v36_40_cursor.ascend(1);
  }
  drop(v36_40_cursor);
  drop(v36_7);
  drop(v36_9);
  drop(v36_10);
  drop(v36_12);
  (v36_40).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v68_4: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v68_6: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v68_7: Space = unwrap(&(v68_6),&(*p0));
  let v68_8: Space = restrict_to(&(v68_6),&(v68_7));
  drop(v68_6);
  let mut v68_27 = Space::new();
  let mut v68_27_cursor = (v68_8).read_zipper();
  for v68_27_byte in v68_27_cursor.child_mask().iter() {
    v68_27_cursor.descend_to_byte(v68_27_byte);
    {
    let v68_27_tail = v68_27_cursor.fork_read_zipper();
    let v68_27_head = Path::from_slice(&[v68_27_byte]);
    let v69_2: Space = singleton(&(v68_27_head));
    let v69_3: Space = intersect(&(*CONSTANT_1),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (v69_5).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_cursor = (v68_27_tail).read_zipper();
      for v70_6_byte in v70_6_cursor.child_mask().iter() {
        v70_6_cursor.descend_to_byte(v70_6_byte);
        {
        let v70_6_tail = v70_6_cursor.fork_read_zipper();
        let v70_6_head = Path::from_slice(&[v70_6_byte]);
        let v71_2: Space = singleton(&(v70_6_head));
        let v71_3: Space = intersect(&(*CONSTANT_1),&(v71_2));
        let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
          let v72_6: Path = concat_path(&(v68_27_head),&(v70_6_head));
          let mut v72_7 = Space::new();
          let mut v72_7_cursor = (v70_6_tail).read_zipper();
          for v72_7_byte in v72_7_cursor.child_mask().iter() {
            v72_7_cursor.descend_to_byte(v72_7_byte);
            {
            let v72_7_tail = v72_7_cursor.fork_read_zipper();
            let v72_7_head = Path::from_slice(&[v72_7_byte]);
            let v73_2: Space = singleton(&(v72_7_head));
            let v73_3: Space = intersect(&(*CONSTANT_1),&(v73_2));
            let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (v73_5).is_empty() { Space::new() } else {
              let v74_6: Path = concat_path(&(v72_6),&(v72_7_head));
              let v74_7: Space = routine_16(c, &(v74_6), &(v72_7_tail).make_space());
              compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = intersect(&(*CONSTANT_1),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (v73_10).is_empty() { Space::new() } else {
              let v75_6: Path = concat_path(&(v72_6),&(v72_7_head));
              let v75_11: Space = routine_17(c, &(v75_6), &(v72_7_tail).make_space());
              drop(v75_6);
              compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = unite(&(v73_8),&(v73_12));
            v72_7.join_into((v73_13).clone());
            }
            v72_7_cursor.ascend(1);
          }
          drop(v72_7_cursor);
          compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = intersect(&(*CONSTANT_1),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (v71_10).is_empty() { Space::new() } else {
          let v76_6: Path = concat_path(&(v68_27_head),&(v70_6_head));
          let mut v76_11 = Space::new();
          let mut v76_11_cursor = (v70_6_tail).read_zipper();
          for v76_11_byte in v76_11_cursor.child_mask().iter() {
            v76_11_cursor.descend_to_byte(v76_11_byte);
            {
            let v76_11_tail = v76_11_cursor.fork_read_zipper();
            let v76_11_head = Path::from_slice(&[v76_11_byte]);
            let v77_2: Space = singleton(&(v76_11_head));
            let v77_3: Space = intersect(&(*CONSTANT_1),&(v77_2));
            let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
            drop(v77_3);
            let v77_5: Space = subtract(&(*CONSTANT_0),&(v77_4));
            drop(v77_4);
            let v77_8: Space = if (v77_5).is_empty() { Space::new() } else {
              let v78_6: Path = concat_path(&(v76_6),&(v76_11_head));
              let v78_7: Space = routine_16(c, &(v78_6), &(v76_11_tail).make_space());
              compose(&(v77_5),&(v78_7))
            };
            drop(v77_5);
            let v77_9: Space = intersect(&(*CONSTANT_1),&(v77_2));
            drop(v77_2);
            let v77_10: Space = if has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
            drop(v77_9);
            let v77_12: Space = if (v77_10).is_empty() { Space::new() } else {
              let v79_6: Path = concat_path(&(v76_6),&(v76_11_head));
              let v79_11: Space = routine_12(c, &(v79_6), &(v76_11_tail).make_space());
              drop(v79_6);
              compose(&(v77_10),&(v79_11))
            };
            drop(v77_10);
            let v77_13: Space = unite(&(v77_8),&(v77_12));
            v76_11.join_into((v77_13).clone());
            }
            v76_11_cursor.ascend(1);
          }
          drop(v76_11_cursor);
          drop(v76_6);
          compose(&(v71_10),&(v76_11))
        };
        drop(v71_10);
        let v71_13: Space = unite(&(v71_8),&(v71_12));
        v70_6.join_into((v71_13).clone());
        }
        v70_6_cursor.ascend(1);
      }
      drop(v70_6_cursor);
      compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = intersect(&(*CONSTANT_1),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (v69_9).is_empty() { Space::new() } else {
      let mut v80_10 = Space::new();
      let mut v80_10_cursor = (v68_27_tail).read_zipper();
      for v80_10_byte in v80_10_cursor.child_mask().iter() {
        v80_10_cursor.descend_to_byte(v80_10_byte);
        {
        let v80_10_tail = v80_10_cursor.fork_read_zipper();
        let v80_10_head = Path::from_slice(&[v80_10_byte]);
        let v81_2: Space = singleton(&(v80_10_head));
        let v81_3: Space = intersect(&(*CONSTANT_1),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
          let v82_6: Path = concat_path(&(v68_27_head),&(v80_10_head));
          let mut v82_7 = Space::new();
          let mut v82_7_cursor = (v80_10_tail).read_zipper();
          for v82_7_byte in v82_7_cursor.child_mask().iter() {
            v82_7_cursor.descend_to_byte(v82_7_byte);
            {
            let v82_7_tail = v82_7_cursor.fork_read_zipper();
            let v82_7_head = Path::from_slice(&[v82_7_byte]);
            let v83_2: Space = singleton(&(v82_7_head));
            let v83_3: Space = intersect(&(*CONSTANT_1),&(v83_2));
            let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
            drop(v83_4);
            let v83_8: Space = if (v83_5).is_empty() { Space::new() } else {
              let v84_6: Path = concat_path(&(v82_6),&(v82_7_head));
              let v84_7: Space = routine_16(c, &(v84_6), &(v82_7_tail).make_space());
              compose(&(v83_5),&(v84_7))
            };
            drop(v83_5);
            let v83_9: Space = intersect(&(*CONSTANT_1),&(v83_2));
            drop(v83_2);
            let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
            drop(v83_9);
            let v83_12: Space = if (v83_10).is_empty() { Space::new() } else {
              let v85_6: Path = concat_path(&(v82_6),&(v82_7_head));
              let v85_11: Space = routine_17(c, &(v85_6), &(v82_7_tail).make_space());
              drop(v85_6);
              compose(&(v83_10),&(v85_11))
            };
            drop(v83_10);
            let v83_13: Space = unite(&(v83_8),&(v83_12));
            v82_7.join_into((v83_13).clone());
            }
            v82_7_cursor.ascend(1);
          }
          drop(v82_7_cursor);
          drop(v82_6);
          compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = intersect(&(*CONSTANT_1),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_11: Space = compose(&(v81_10),&(v80_10_tail));
        drop(v81_10);
        let v81_12: Space = unite(&(v81_8),&(v81_11));
        drop(v81_11);
        v80_10.join_into((v81_12).clone());
        }
        v80_10_cursor.ascend(1);
      }
      drop(v80_10_cursor);
      compose(&(v69_9),&(v80_10))
    };
    drop(v69_9);
    let v69_12: Space = unite(&(v69_7),&(v69_11));
    v68_27.join_into((v69_12).clone());
    }
    v68_27_cursor.ascend(1);
  }
  drop(v68_27_cursor);
  drop(v68_8);
  let v68_28: Space = restrict_to(&(v68_4),&(v68_27));
  drop(v68_4);
  let mut v68_47 = Space::new();
  let mut v68_47_cursor = (v68_28).read_zipper();
  for v68_47_byte in v68_47_cursor.child_mask().iter() {
    v68_47_cursor.descend_to_byte(v68_47_byte);
    {
    let v68_47_tail = v68_47_cursor.fork_read_zipper();
    let v68_47_head = Path::from_slice(&[v68_47_byte]);
    let v86_2: Space = singleton(&(v68_47_head));
    let v86_3: Space = intersect(&(*CONSTANT_1),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (v86_5).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_cursor = (v68_47_tail).read_zipper();
      for v87_6_byte in v87_6_cursor.child_mask().iter() {
        v87_6_cursor.descend_to_byte(v87_6_byte);
        {
        let v87_6_tail = v87_6_cursor.fork_read_zipper();
        let v87_6_head = Path::from_slice(&[v87_6_byte]);
        let v88_2: Space = singleton(&(v87_6_head));
        let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
          let v89_6: Path = concat_path(&(v68_47_head),&(v87_6_head));
          let mut v89_7 = Space::new();
          let mut v89_7_cursor = (v87_6_tail).read_zipper();
          for v89_7_byte in v89_7_cursor.child_mask().iter() {
            v89_7_cursor.descend_to_byte(v89_7_byte);
            {
            let v89_7_tail = v89_7_cursor.fork_read_zipper();
            let v89_7_head = Path::from_slice(&[v89_7_byte]);
            let v90_2: Space = singleton(&(v89_7_head));
            let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
            let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
            drop(v90_3);
            let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
            drop(v90_4);
            let v90_8: Space = if (v90_5).is_empty() { Space::new() } else {
              let v91_6: Path = concat_path(&(v89_6),&(v89_7_head));
              let v91_7: Space = routine_18(c, &(v91_6), &(v89_7_tail).make_space());
              compose(&(v90_5),&(v91_7))
            };
            drop(v90_5);
            let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
            drop(v90_2);
            let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
            drop(v90_9);
            let v90_12: Space = if (v90_10).is_empty() { Space::new() } else {
              let v92_6: Path = concat_path(&(v89_6),&(v89_7_head));
              let v92_11: Space = routine_19(c, &(v92_6), &(v89_7_tail).make_space());
              drop(v92_6);
              compose(&(v90_10),&(v92_11))
            };
            drop(v90_10);
            let v90_13: Space = unite(&(v90_8),&(v90_12));
            v89_7.join_into((v90_13).clone());
            }
            v89_7_cursor.ascend(1);
          }
          drop(v89_7_cursor);
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
          let v93_6: Path = concat_path(&(v68_47_head),&(v87_6_head));
          let mut v93_11 = Space::new();
          let mut v93_11_cursor = (v87_6_tail).read_zipper();
          for v93_11_byte in v93_11_cursor.child_mask().iter() {
            v93_11_cursor.descend_to_byte(v93_11_byte);
            {
            let v93_11_tail = v93_11_cursor.fork_read_zipper();
            let v93_11_head = Path::from_slice(&[v93_11_byte]);
            let v94_2: Space = singleton(&(v93_11_head));
            let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
            let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_8: Space = if (v94_5).is_empty() { Space::new() } else {
              let v95_6: Path = concat_path(&(v93_6),&(v93_11_head));
              let v95_7: Space = routine_18(c, &(v95_6), &(v93_11_tail).make_space());
              compose(&(v94_5),&(v95_7))
            };
            drop(v94_5);
            let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
            drop(v94_2);
            let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
            drop(v94_9);
            let v94_12: Space = if (v94_10).is_empty() { Space::new() } else {
              let v96_6: Path = concat_path(&(v93_6),&(v93_11_head));
              let v96_11: Space = routine_15(c, &(v96_6), &(v93_11_tail).make_space());
              drop(v96_6);
              compose(&(v94_10),&(v96_11))
            };
            drop(v94_10);
            let v94_13: Space = unite(&(v94_8),&(v94_12));
            v93_11.join_into((v94_13).clone());
            }
            v93_11_cursor.ascend(1);
          }
          drop(v93_11_cursor);
          drop(v93_6);
          compose(&(v88_10),&(v93_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        v87_6.join_into((v88_13).clone());
        }
        v87_6_cursor.ascend(1);
      }
      drop(v87_6_cursor);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_1),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (v86_9).is_empty() { Space::new() } else {
      let mut v97_10 = Space::new();
      let mut v97_10_cursor = (v68_47_tail).read_zipper();
      for v97_10_byte in v97_10_cursor.child_mask().iter() {
        v97_10_cursor.descend_to_byte(v97_10_byte);
        {
        let v97_10_tail = v97_10_cursor.fork_read_zipper();
        let v97_10_head = Path::from_slice(&[v97_10_byte]);
        let v98_2: Space = singleton(&(v97_10_head));
        let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (v98_5).is_empty() { Space::new() } else {
          let v99_6: Path = concat_path(&(v68_47_head),&(v97_10_head));
          let mut v99_7 = Space::new();
          let mut v99_7_cursor = (v97_10_tail).read_zipper();
          for v99_7_byte in v99_7_cursor.child_mask().iter() {
            v99_7_cursor.descend_to_byte(v99_7_byte);
            {
            let v99_7_tail = v99_7_cursor.fork_read_zipper();
            let v99_7_head = Path::from_slice(&[v99_7_byte]);
            let v100_2: Space = singleton(&(v99_7_head));
            let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
            let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (v100_5).is_empty() { Space::new() } else {
              let v101_6: Path = concat_path(&(v99_6),&(v99_7_head));
              let v101_7: Space = routine_18(c, &(v101_6), &(v99_7_tail).make_space());
              compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (v100_10).is_empty() { Space::new() } else {
              let v102_6: Path = concat_path(&(v99_6),&(v99_7_head));
              let v102_11: Space = routine_19(c, &(v102_6), &(v99_7_tail).make_space());
              drop(v102_6);
              compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = unite(&(v100_8),&(v100_12));
            v99_7.join_into((v100_13).clone());
            }
            v99_7_cursor.ascend(1);
          }
          drop(v99_7_cursor);
          drop(v99_6);
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_11: Space = compose(&(v98_10),&(v97_10_tail));
        drop(v98_10);
        let v98_12: Space = unite(&(v98_8),&(v98_11));
        drop(v98_11);
        v97_10.join_into((v98_12).clone());
        }
        v97_10_cursor.ascend(1);
      }
      drop(v97_10_cursor);
      compose(&(v86_9),&(v97_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    v68_47.join_into((v86_12).clone());
    }
    v68_47_cursor.ascend(1);
  }
  drop(v68_47_cursor);
  let v68_48: Space = subtract(&(v68_47),&(v68_7));
  drop(v68_7);
  let v68_50: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let v68_51: Space = intersect(&(v68_48),&(v68_50));
  drop(v68_50);
  let v68_52: Space = wrap(&(v68_51),&(*p0));
  (v68_52).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v103_21: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v103_22: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v103_23: Space = unwrap(&(v103_22),&(*p0));
  let v103_24: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v103_34 = Space::new();
  let mut v103_34_cursor = (*s0).read_zipper();
  for v103_34_byte in v103_34_cursor.child_mask().iter() {
    v103_34_cursor.descend_to_byte(v103_34_byte);
    {
    let v103_34_tail = v103_34_cursor.fork_read_zipper();
    let v103_34_head = Path::from_slice(&[v103_34_byte]);
    let v104_2: Space = singleton(&(v103_34_head));
    let v104_3: Space = intersect(&(*CONSTANT_1),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_8: Space = if (v104_5).is_empty() { Space::new() } else {
      let v105_6: Path = concat_path(&(*p0),&(v103_34_head));
      let mut v105_7 = Space::new();
      let mut v105_7_cursor = (v103_34_tail).read_zipper();
      for v105_7_byte in v105_7_cursor.child_mask().iter() {
        v105_7_cursor.descend_to_byte(v105_7_byte);
        {
        let v105_7_tail = v105_7_cursor.fork_read_zipper();
        let v105_7_head = Path::from_slice(&[v105_7_byte]);
        let v106_2: Space = singleton(&(v105_7_head));
        let v106_3: Space = intersect(&(*CONSTANT_1),&(v106_2));
        let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
        drop(v106_4);
        let v106_8: Space = if (v106_5).is_empty() { Space::new() } else {
          let v107_6: Path = concat_path(&(v105_6),&(v105_7_head));
          let mut v107_7 = Space::new();
          let mut v107_7_cursor = (v105_7_tail).read_zipper();
          for v107_7_byte in v107_7_cursor.child_mask().iter() {
            v107_7_cursor.descend_to_byte(v107_7_byte);
            {
            let v107_7_tail = v107_7_cursor.fork_read_zipper();
            let v107_7_head = Path::from_slice(&[v107_7_byte]);
            let v108_2: Space = singleton(&(v107_7_head));
            let v108_3: Space = intersect(&(*CONSTANT_1),&(v108_2));
            let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
            drop(v108_3);
            let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
            drop(v108_4);
            let v108_8: Space = if (v108_5).is_empty() { Space::new() } else {
              let v109_6: Path = concat_path(&(v107_6),&(v107_7_head));
              let v109_7: Space = routine_20(c, &(v109_6), &(v107_7_tail).make_space(), &(*s1));
              compose(&(v108_5),&(v109_7))
            };
            drop(v108_5);
            let v108_9: Space = intersect(&(*CONSTANT_1),&(v108_2));
            drop(v108_2);
            let v108_10: Space = if has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
            drop(v108_9);
            let v108_12: Space = if (v108_10).is_empty() { Space::new() } else {
              let v110_6: Path = concat_path(&(v107_6),&(v107_7_head));
              let v110_11: Space = routine_21(c, &(v110_6), &(v107_7_tail).make_space(), &(*s1));
              drop(v110_6);
              compose(&(v108_10),&(v110_11))
            };
            drop(v108_10);
            let v108_13: Space = unite(&(v108_8),&(v108_12));
            v107_7.join_into((v108_13).clone());
            }
            v107_7_cursor.ascend(1);
          }
          drop(v107_7_cursor);
          compose(&(v106_5),&(v107_7))
        };
        drop(v106_5);
        let v106_9: Space = intersect(&(*CONSTANT_1),&(v106_2));
        drop(v106_2);
        let v106_10: Space = if has_head(&(v106_9)) { singleton(&[]) } else { Space::new() };
        drop(v106_9);
        let v106_12: Space = if (v106_10).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v105_6),&(v105_7_head));
          let mut v111_11 = Space::new();
          let mut v111_11_cursor = (v105_7_tail).read_zipper();
          for v111_11_byte in v111_11_cursor.child_mask().iter() {
            v111_11_cursor.descend_to_byte(v111_11_byte);
            {
            let v111_11_tail = v111_11_cursor.fork_read_zipper();
            let v111_11_head = Path::from_slice(&[v111_11_byte]);
            let v112_2: Space = singleton(&(v111_11_head));
            let v112_3: Space = intersect(&(*CONSTANT_1),&(v112_2));
            let v112_4: Space = if has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
            drop(v112_3);
            let v112_5: Space = subtract(&(*CONSTANT_0),&(v112_4));
            drop(v112_4);
            let v112_8: Space = if (v112_5).is_empty() { Space::new() } else {
              let v113_6: Path = concat_path(&(v111_6),&(v111_11_head));
              let v113_7: Space = routine_20(c, &(v113_6), &(v111_11_tail).make_space(), &(*s1));
              compose(&(v112_5),&(v113_7))
            };
            drop(v112_5);
            let v112_9: Space = intersect(&(*CONSTANT_1),&(v112_2));
            drop(v112_2);
            let v112_10: Space = if has_head(&(v112_9)) { singleton(&[]) } else { Space::new() };
            drop(v112_9);
            let v112_12: Space = if (v112_10).is_empty() { Space::new() } else {
              let v114_6: Path = concat_path(&(v111_6),&(v111_11_head));
              let v114_11: Space = routine_3(c, &(v114_6), &(v111_11_tail).make_space(), &(*s1));
              drop(v114_6);
              compose(&(v112_10),&(v114_11))
            };
            drop(v112_10);
            let v112_13: Space = unite(&(v112_8),&(v112_12));
            v111_11.join_into((v112_13).clone());
            }
            v111_11_cursor.ascend(1);
          }
          drop(v111_11_cursor);
          drop(v111_6);
          compose(&(v106_10),&(v111_11))
        };
        drop(v106_10);
        let v106_13: Space = unite(&(v106_8),&(v106_12));
        v105_7.join_into((v106_13).clone());
        }
        v105_7_cursor.ascend(1);
      }
      drop(v105_7_cursor);
      compose(&(v104_5),&(v105_7))
    };
    drop(v104_5);
    let v104_9: Space = intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
    drop(v104_9);
    let v104_13: Space = if (v104_10).is_empty() { Space::new() } else {
      let v115_6: Path = concat_path(&(*p0),&(v103_34_head));
      let v115_11: Space = unwrap(&(v103_23),&(v103_34_head));
      let mut v115_12 = Space::new();
      let mut v115_12_cursor = (v103_34_tail).read_zipper();
      for v115_12_byte in v115_12_cursor.child_mask().iter() {
        v115_12_cursor.descend_to_byte(v115_12_byte);
        {
        let v115_12_tail = v115_12_cursor.fork_read_zipper();
        let v115_12_head = Path::from_slice(&[v115_12_byte]);
        let v116_2: Space = singleton(&(v115_12_head));
        let v116_3: Space = intersect(&(*CONSTANT_1),&(v116_2));
        let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
        drop(v116_3);
        let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
        drop(v116_4);
        let v116_8: Space = if (v116_5).is_empty() { Space::new() } else {
          let v117_6: Path = concat_path(&(v115_6),&(v115_12_head));
          let mut v117_7 = Space::new();
          let mut v117_7_cursor = (v115_12_tail).read_zipper();
          for v117_7_byte in v117_7_cursor.child_mask().iter() {
            v117_7_cursor.descend_to_byte(v117_7_byte);
            {
            let v117_7_tail = v117_7_cursor.fork_read_zipper();
            let v117_7_head = Path::from_slice(&[v117_7_byte]);
            let v118_2: Space = singleton(&(v117_7_head));
            let v118_3: Space = intersect(&(*CONSTANT_1),&(v118_2));
            let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
            drop(v118_3);
            let v118_5: Space = subtract(&(*CONSTANT_0),&(v118_4));
            drop(v118_4);
            let v118_8: Space = if (v118_5).is_empty() { Space::new() } else {
              let v119_6: Path = concat_path(&(v117_6),&(v117_7_head));
              let v119_7: Space = routine_20(c, &(v119_6), &(v117_7_tail).make_space(), &(*s1));
              compose(&(v118_5),&(v119_7))
            };
            drop(v118_5);
            let v118_9: Space = intersect(&(*CONSTANT_1),&(v118_2));
            drop(v118_2);
            let v118_10: Space = if has_head(&(v118_9)) { singleton(&[]) } else { Space::new() };
            drop(v118_9);
            let v118_12: Space = if (v118_10).is_empty() { Space::new() } else {
              let v120_6: Path = concat_path(&(v117_6),&(v117_7_head));
              let v120_11: Space = routine_21(c, &(v120_6), &(v117_7_tail).make_space(), &(*s1));
              drop(v120_6);
              compose(&(v118_10),&(v120_11))
            };
            drop(v118_10);
            let v118_13: Space = unite(&(v118_8),&(v118_12));
            v117_7.join_into((v118_13).clone());
            }
            v117_7_cursor.ascend(1);
          }
          drop(v117_7_cursor);
          compose(&(v116_5),&(v117_7))
        };
        drop(v116_5);
        let v116_9: Space = intersect(&(*CONSTANT_1),&(v116_2));
        drop(v116_2);
        let v116_10: Space = if has_head(&(v116_9)) { singleton(&[]) } else { Space::new() };
        drop(v116_9);
        let v116_18: Space = if (v116_10).is_empty() { Space::new() } else {
          let v121_11: Space = unwrap(&(v115_11),&(v115_12_head));
          let v121_12: Space = restrict_to(&(v103_22),&(v121_11));
          let mut v121_13 = Space::new();
          let mut v121_13_cursor = (v121_12).read_zipper();
          for v121_13_byte in v121_13_cursor.child_mask().iter() {
            v121_13_cursor.descend_to_byte(v121_13_byte);
            {
            let v121_13_tail = v121_13_cursor.fork_read_zipper();
            let v121_13_head = Path::from_slice(&[v121_13_byte]);
            let v122_2: Space = singleton(&(v121_13_head));
            let v122_3: Space = intersect(&(*CONSTANT_1),&(v122_2));
            let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
            drop(v122_3);
            let v122_5: Space = subtract(&(*CONSTANT_0),&(v122_4));
            drop(v122_4);
            let v122_7: Space = if (v122_5).is_empty() { Space::new() } else {
              let v123_6: Space = routine_6(c, &(v121_13_head), &(v121_13_tail).make_space());
              compose(&(v122_5),&(v123_6))
            };
            drop(v122_5);
            let v122_8: Space = intersect(&(*CONSTANT_1),&(v122_2));
            drop(v122_2);
            let v122_9: Space = if has_head(&(v122_8)) { singleton(&[]) } else { Space::new() };
            drop(v122_8);
            let v122_11: Space = if (v122_9).is_empty() { Space::new() } else {
              let v124_10: Space = routine_7(c, &(v121_13_head), &(v121_13_tail).make_space());
              compose(&(v122_9),&(v124_10))
            };
            drop(v122_9);
            let v122_12: Space = unite(&(v122_7),&(v122_11));
            v121_13.join_into((v122_12).clone());
            }
            v121_13_cursor.ascend(1);
          }
          drop(v121_13_cursor);
          drop(v121_12);
          let v121_14: Space = restrict_to(&(v103_21),&(v121_13));
          let mut v121_15 = Space::new();
          let mut v121_15_cursor = (v121_14).read_zipper();
          for v121_15_byte in v121_15_cursor.child_mask().iter() {
            v121_15_cursor.descend_to_byte(v121_15_byte);
            {
            let v121_15_tail = v121_15_cursor.fork_read_zipper();
            let v121_15_head = Path::from_slice(&[v121_15_byte]);
            let v125_2: Space = singleton(&(v121_15_head));
            let v125_3: Space = intersect(&(*CONSTANT_1),&(v125_2));
            let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = subtract(&(*CONSTANT_0),&(v125_4));
            drop(v125_4);
            let v125_7: Space = if (v125_5).is_empty() { Space::new() } else {
              let v126_6: Space = routine_8(c, &(v121_15_head), &(v121_15_tail).make_space());
              compose(&(v125_5),&(v126_6))
            };
            drop(v125_5);
            let v125_8: Space = intersect(&(*CONSTANT_1),&(v125_2));
            drop(v125_2);
            let v125_9: Space = if has_head(&(v125_8)) { singleton(&[]) } else { Space::new() };
            drop(v125_8);
            let v125_11: Space = if (v125_9).is_empty() { Space::new() } else {
              let v127_10: Space = routine_9(c, &(v121_15_head), &(v121_15_tail).make_space());
              compose(&(v125_9),&(v127_10))
            };
            drop(v125_9);
            let v125_12: Space = unite(&(v125_7),&(v125_11));
            v121_15.join_into((v125_12).clone());
            }
            v121_15_cursor.ascend(1);
          }
          drop(v121_15_cursor);
          let v121_16: Space = subtract(&(v121_15),&(v121_11));
          drop(v121_11);
          let v121_17: Space = intersect(&(v121_16),&(v103_24));
          compose(&(v116_10),&(v121_17))
        };
        drop(v116_10);
        let v128_6: Path = concat_path(&(v115_6),&(v115_12_head));
        let v116_19: Space = wrap(&(v116_18),&(v128_6));
        let v116_20: Space = unite(&(v116_8),&(v116_19));
        v115_12.join_into((v116_20).clone());
        }
        v115_12_cursor.ascend(1);
      }
      drop(v115_12_cursor);
      drop(v115_6);
      drop(v115_11);
      compose(&(v104_10),&(v115_12))
    };
    drop(v104_10);
    let v104_14: Space = unite(&(v104_8),&(v104_13));
    v103_34.join_into((v104_14).clone());
    }
    v103_34_cursor.ascend(1);
  }
  drop(v103_34_cursor);
  drop(v103_21);
  drop(v103_22);
  drop(v103_23);
  drop(v103_24);
  (v103_34).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v129_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v129_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v129_10: Space = unwrap(&(v129_9),&(*p0));
  let v129_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v129_40 = Space::new();
  let mut v129_40_cursor = (*s0).read_zipper();
  for v129_40_byte in v129_40_cursor.child_mask().iter() {
    v129_40_cursor.descend_to_byte(v129_40_byte);
    {
    let v129_40_tail = v129_40_cursor.fork_read_zipper();
    let v129_40_head = Path::from_slice(&[v129_40_byte]);
    let v130_2: Space = singleton(&(v129_40_head));
    let v130_3: Space = intersect(&(*CONSTANT_1),&(v130_2));
    let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
    drop(v130_3);
    let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
    drop(v130_4);
    let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
      let v131_6: Path = concat_path(&(*p0),&(v129_40_head));
      let mut v131_7 = Space::new();
      let mut v131_7_cursor = (v129_40_tail).read_zipper();
      for v131_7_byte in v131_7_cursor.child_mask().iter() {
        v131_7_cursor.descend_to_byte(v131_7_byte);
        {
        let v131_7_tail = v131_7_cursor.fork_read_zipper();
        let v131_7_head = Path::from_slice(&[v131_7_byte]);
        let v132_2: Space = singleton(&(v131_7_head));
        let v132_3: Space = intersect(&(*CONSTANT_1),&(v132_2));
        let v132_4: Space = if has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
        drop(v132_3);
        let v132_5: Space = subtract(&(*CONSTANT_0),&(v132_4));
        drop(v132_4);
        let v132_8: Space = if (v132_5).is_empty() { Space::new() } else {
          let v133_6: Path = concat_path(&(v131_6),&(v131_7_head));
          let mut v133_7 = Space::new();
          let mut v133_7_cursor = (v131_7_tail).read_zipper();
          for v133_7_byte in v133_7_cursor.child_mask().iter() {
            v133_7_cursor.descend_to_byte(v133_7_byte);
            {
            let v133_7_tail = v133_7_cursor.fork_read_zipper();
            let v133_7_head = Path::from_slice(&[v133_7_byte]);
            let v134_2: Space = singleton(&(v133_7_head));
            let v134_3: Space = intersect(&(*CONSTANT_1),&(v134_2));
            let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
            drop(v134_3);
            let v134_5: Space = subtract(&(*CONSTANT_0),&(v134_4));
            drop(v134_4);
            let v134_8: Space = if (v134_5).is_empty() { Space::new() } else {
              let v135_6: Path = concat_path(&(v133_6),&(v133_7_head));
              let v135_7: Space = routine_20(c, &(v135_6), &(v133_7_tail).make_space(), &(*s1));
              compose(&(v134_5),&(v135_7))
            };
            drop(v134_5);
            let v134_9: Space = intersect(&(*CONSTANT_1),&(v134_2));
            drop(v134_2);
            let v134_10: Space = if has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
            drop(v134_9);
            let v134_12: Space = if (v134_10).is_empty() { Space::new() } else {
              let v136_6: Path = concat_path(&(v133_6),&(v133_7_head));
              let v136_11: Space = routine_21(c, &(v136_6), &(v133_7_tail).make_space(), &(*s1));
              drop(v136_6);
              compose(&(v134_10),&(v136_11))
            };
            drop(v134_10);
            let v134_13: Space = unite(&(v134_8),&(v134_12));
            v133_7.join_into((v134_13).clone());
            }
            v133_7_cursor.ascend(1);
          }
          drop(v133_7_cursor);
          compose(&(v132_5),&(v133_7))
        };
        drop(v132_5);
        let v132_9: Space = intersect(&(*CONSTANT_1),&(v132_2));
        drop(v132_2);
        let v132_10: Space = if has_head(&(v132_9)) { singleton(&[]) } else { Space::new() };
        drop(v132_9);
        let v132_12: Space = if (v132_10).is_empty() { Space::new() } else {
          let v137_6: Path = concat_path(&(v131_6),&(v131_7_head));
          let mut v137_11 = Space::new();
          let mut v137_11_cursor = (v131_7_tail).read_zipper();
          for v137_11_byte in v137_11_cursor.child_mask().iter() {
            v137_11_cursor.descend_to_byte(v137_11_byte);
            {
            let v137_11_tail = v137_11_cursor.fork_read_zipper();
            let v137_11_head = Path::from_slice(&[v137_11_byte]);
            let v138_2: Space = singleton(&(v137_11_head));
            let v138_3: Space = intersect(&(*CONSTANT_1),&(v138_2));
            let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
            drop(v138_3);
            let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
            drop(v138_4);
            let v138_8: Space = if (v138_5).is_empty() { Space::new() } else {
              let v139_6: Path = concat_path(&(v137_6),&(v137_11_head));
              let v139_7: Space = routine_20(c, &(v139_6), &(v137_11_tail).make_space(), &(*s1));
              compose(&(v138_5),&(v139_7))
            };
            drop(v138_5);
            let v138_9: Space = intersect(&(*CONSTANT_1),&(v138_2));
            drop(v138_2);
            let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
            drop(v138_9);
            let v138_12: Space = if (v138_10).is_empty() { Space::new() } else {
              let v140_6: Path = concat_path(&(v137_6),&(v137_11_head));
              let v140_11: Space = routine_3(c, &(v140_6), &(v137_11_tail).make_space(), &(*s1));
              drop(v140_6);
              compose(&(v138_10),&(v140_11))
            };
            drop(v138_10);
            let v138_13: Space = unite(&(v138_8),&(v138_12));
            v137_11.join_into((v138_13).clone());
            }
            v137_11_cursor.ascend(1);
          }
          drop(v137_11_cursor);
          drop(v137_6);
          compose(&(v132_10),&(v137_11))
        };
        drop(v132_10);
        let v132_13: Space = unite(&(v132_8),&(v132_12));
        v131_7.join_into((v132_13).clone());
        }
        v131_7_cursor.ascend(1);
      }
      drop(v131_7_cursor);
      compose(&(v130_5),&(v131_7))
    };
    drop(v130_5);
    let v130_9: Space = intersect(&(*CONSTANT_1),&(v130_2));
    drop(v130_2);
    let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
    drop(v130_9);
    let v130_18: Space = if (v130_10).is_empty() { Space::new() } else {
      let v141_11: Space = unwrap(&(v129_10),&(v129_40_head));
      let v141_12: Space = restrict_to(&(v129_9),&(v141_11));
      let mut v141_13 = Space::new();
      let mut v141_13_cursor = (v141_12).read_zipper();
      for v141_13_byte in v141_13_cursor.child_mask().iter() {
        v141_13_cursor.descend_to_byte(v141_13_byte);
        {
        let v141_13_tail = v141_13_cursor.fork_read_zipper();
        let v141_13_head = Path::from_slice(&[v141_13_byte]);
        let v142_2: Space = singleton(&(v141_13_head));
        let v142_3: Space = intersect(&(*CONSTANT_1),&(v142_2));
        let v142_4: Space = if has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
        drop(v142_3);
        let v142_5: Space = subtract(&(*CONSTANT_0),&(v142_4));
        drop(v142_4);
        let v142_7: Space = if (v142_5).is_empty() { Space::new() } else {
          let mut v143_6 = Space::new();
          let mut v143_6_cursor = (v141_13_tail).read_zipper();
          for v143_6_byte in v143_6_cursor.child_mask().iter() {
            v143_6_cursor.descend_to_byte(v143_6_byte);
            {
            let v143_6_tail = v143_6_cursor.fork_read_zipper();
            let v143_6_head = Path::from_slice(&[v143_6_byte]);
            let v144_2: Space = singleton(&(v143_6_head));
            let v144_3: Space = intersect(&(*CONSTANT_1),&(v144_2));
            let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
            drop(v144_3);
            let v144_5: Space = subtract(&(*CONSTANT_0),&(v144_4));
            drop(v144_4);
            let v144_8: Space = if (v144_5).is_empty() { Space::new() } else {
              let v145_6: Path = concat_path(&(v141_13_head),&(v143_6_head));
              let v145_7: Space = routine_10(c, &(v145_6), &(v143_6_tail).make_space());
              compose(&(v144_5),&(v145_7))
            };
            drop(v144_5);
            let v144_9: Space = intersect(&(*CONSTANT_1),&(v144_2));
            drop(v144_2);
            let v144_10: Space = if has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
            drop(v144_9);
            let v144_12: Space = if (v144_10).is_empty() { Space::new() } else {
              let v146_6: Path = concat_path(&(v141_13_head),&(v143_6_head));
              let v146_11: Space = routine_11(c, &(v146_6), &(v143_6_tail).make_space());
              drop(v146_6);
              compose(&(v144_10),&(v146_11))
            };
            drop(v144_10);
            let v144_13: Space = unite(&(v144_8),&(v144_12));
            v143_6.join_into((v144_13).clone());
            }
            v143_6_cursor.ascend(1);
          }
          drop(v143_6_cursor);
          compose(&(v142_5),&(v143_6))
        };
        drop(v142_5);
        let v142_8: Space = intersect(&(*CONSTANT_1),&(v142_2));
        drop(v142_2);
        let v142_9: Space = if has_head(&(v142_8)) { singleton(&[]) } else { Space::new() };
        drop(v142_8);
        let v142_11: Space = if (v142_9).is_empty() { Space::new() } else {
          let mut v147_10 = Space::new();
          let mut v147_10_cursor = (v141_13_tail).read_zipper();
          for v147_10_byte in v147_10_cursor.child_mask().iter() {
            v147_10_cursor.descend_to_byte(v147_10_byte);
            {
            let v147_10_tail = v147_10_cursor.fork_read_zipper();
            let v147_10_head = Path::from_slice(&[v147_10_byte]);
            let v148_2: Space = singleton(&(v147_10_head));
            let v148_3: Space = intersect(&(*CONSTANT_1),&(v148_2));
            let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
            drop(v148_3);
            let v148_5: Space = subtract(&(*CONSTANT_0),&(v148_4));
            drop(v148_4);
            let v148_8: Space = if (v148_5).is_empty() { Space::new() } else {
              let v149_6: Path = concat_path(&(v141_13_head),&(v147_10_head));
              let v149_7: Space = routine_10(c, &(v149_6), &(v147_10_tail).make_space());
              compose(&(v148_5),&(v149_7))
            };
            drop(v148_5);
            let v148_9: Space = intersect(&(*CONSTANT_1),&(v148_2));
            drop(v148_2);
            let v148_10: Space = if has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
            drop(v148_9);
            let v148_12: Space = if (v148_10).is_empty() { Space::new() } else {
              let v150_6: Path = concat_path(&(v141_13_head),&(v147_10_head));
              let v150_11: Space = routine_12(c, &(v150_6), &(v147_10_tail).make_space());
              drop(v150_6);
              compose(&(v148_10),&(v150_11))
            };
            drop(v148_10);
            let v148_13: Space = unite(&(v148_8),&(v148_12));
            v147_10.join_into((v148_13).clone());
            }
            v147_10_cursor.ascend(1);
          }
          drop(v147_10_cursor);
          compose(&(v142_9),&(v147_10))
        };
        drop(v142_9);
        let v142_12: Space = unite(&(v142_7),&(v142_11));
        v141_13.join_into((v142_12).clone());
        }
        v141_13_cursor.ascend(1);
      }
      drop(v141_13_cursor);
      drop(v141_12);
      let v141_14: Space = restrict_to(&(v129_7),&(v141_13));
      let mut v141_15 = Space::new();
      let mut v141_15_cursor = (v141_14).read_zipper();
      for v141_15_byte in v141_15_cursor.child_mask().iter() {
        v141_15_cursor.descend_to_byte(v141_15_byte);
        {
        let v141_15_tail = v141_15_cursor.fork_read_zipper();
        let v141_15_head = Path::from_slice(&[v141_15_byte]);
        let v151_2: Space = singleton(&(v141_15_head));
        let v151_3: Space = intersect(&(*CONSTANT_1),&(v151_2));
        let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
        drop(v151_3);
        let v151_5: Space = subtract(&(*CONSTANT_0),&(v151_4));
        drop(v151_4);
        let v151_7: Space = if (v151_5).is_empty() { Space::new() } else {
          let mut v152_6 = Space::new();
          let mut v152_6_cursor = (v141_15_tail).read_zipper();
          for v152_6_byte in v152_6_cursor.child_mask().iter() {
            v152_6_cursor.descend_to_byte(v152_6_byte);
            {
            let v152_6_tail = v152_6_cursor.fork_read_zipper();
            let v152_6_head = Path::from_slice(&[v152_6_byte]);
            let v153_2: Space = singleton(&(v152_6_head));
            let v153_3: Space = intersect(&(*CONSTANT_1),&(v153_2));
            let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
            drop(v153_3);
            let v153_5: Space = subtract(&(*CONSTANT_0),&(v153_4));
            drop(v153_4);
            let v153_8: Space = if (v153_5).is_empty() { Space::new() } else {
              let v154_6: Path = concat_path(&(v141_15_head),&(v152_6_head));
              let v154_7: Space = routine_13(c, &(v154_6), &(v152_6_tail).make_space());
              compose(&(v153_5),&(v154_7))
            };
            drop(v153_5);
            let v153_9: Space = intersect(&(*CONSTANT_1),&(v153_2));
            drop(v153_2);
            let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
            drop(v153_9);
            let v153_12: Space = if (v153_10).is_empty() { Space::new() } else {
              let v155_6: Path = concat_path(&(v141_15_head),&(v152_6_head));
              let v155_11: Space = routine_14(c, &(v155_6), &(v152_6_tail).make_space());
              drop(v155_6);
              compose(&(v153_10),&(v155_11))
            };
            drop(v153_10);
            let v153_13: Space = unite(&(v153_8),&(v153_12));
            v152_6.join_into((v153_13).clone());
            }
            v152_6_cursor.ascend(1);
          }
          drop(v152_6_cursor);
          compose(&(v151_5),&(v152_6))
        };
        drop(v151_5);
        let v151_8: Space = intersect(&(*CONSTANT_1),&(v151_2));
        drop(v151_2);
        let v151_9: Space = if has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
        drop(v151_8);
        let v151_11: Space = if (v151_9).is_empty() { Space::new() } else {
          let mut v156_10 = Space::new();
          let mut v156_10_cursor = (v141_15_tail).read_zipper();
          for v156_10_byte in v156_10_cursor.child_mask().iter() {
            v156_10_cursor.descend_to_byte(v156_10_byte);
            {
            let v156_10_tail = v156_10_cursor.fork_read_zipper();
            let v156_10_head = Path::from_slice(&[v156_10_byte]);
            let v157_2: Space = singleton(&(v156_10_head));
            let v157_3: Space = intersect(&(*CONSTANT_1),&(v157_2));
            let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
            drop(v157_3);
            let v157_5: Space = subtract(&(*CONSTANT_0),&(v157_4));
            drop(v157_4);
            let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
              let v158_6: Path = concat_path(&(v141_15_head),&(v156_10_head));
              let v158_7: Space = routine_13(c, &(v158_6), &(v156_10_tail).make_space());
              compose(&(v157_5),&(v158_7))
            };
            drop(v157_5);
            let v157_9: Space = intersect(&(*CONSTANT_1),&(v157_2));
            drop(v157_2);
            let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
            drop(v157_9);
            let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
              let v159_6: Path = concat_path(&(v141_15_head),&(v156_10_head));
              let v159_11: Space = routine_15(c, &(v159_6), &(v156_10_tail).make_space());
              drop(v159_6);
              compose(&(v157_10),&(v159_11))
            };
            drop(v157_10);
            let v157_13: Space = unite(&(v157_8),&(v157_12));
            v156_10.join_into((v157_13).clone());
            }
            v156_10_cursor.ascend(1);
          }
          drop(v156_10_cursor);
          compose(&(v151_9),&(v156_10))
        };
        drop(v151_9);
        let v151_12: Space = unite(&(v151_7),&(v151_11));
        v141_15.join_into((v151_12).clone());
        }
        v141_15_cursor.ascend(1);
      }
      drop(v141_15_cursor);
      let v141_16: Space = subtract(&(v141_15),&(v141_11));
      drop(v141_11);
      let v141_17: Space = intersect(&(v141_16),&(v129_12));
      compose(&(v130_10),&(v141_17))
    };
    drop(v130_10);
    let v160_6: Path = concat_path(&(*p0),&(v129_40_head));
    let v130_19: Space = wrap(&(v130_18),&(v160_6));
    let v130_20: Space = unite(&(v130_8),&(v130_19));
    v129_40.join_into((v130_20).clone());
    }
    v129_40_cursor.ascend(1);
  }
  drop(v129_40_cursor);
  drop(v129_7);
  drop(v129_9);
  drop(v129_10);
  drop(v129_12);
  (v129_40).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v161_20 = Space::new();
  let mut v161_20_cursor = (*s0).read_zipper();
  for v161_20_byte in v161_20_cursor.child_mask().iter() {
    v161_20_cursor.descend_to_byte(v161_20_byte);
    {
    let v161_20_tail = v161_20_cursor.fork_read_zipper();
    let v161_20_head = Path::from_slice(&[v161_20_byte]);
    let v162_2: Space = singleton(&(v161_20_head));
    let v162_3: Space = intersect(&(*CONSTANT_1),&(v162_2));
    let v162_4: Space = if has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
    drop(v162_3);
    let v162_5: Space = subtract(&(*CONSTANT_0),&(v162_4));
    drop(v162_4);
    let v162_8: Space = if (v162_5).is_empty() { Space::new() } else {
      let v163_6: Path = concat_path(&(*p0),&(v161_20_head));
      let mut v163_7 = Space::new();
      let mut v163_7_cursor = (v161_20_tail).read_zipper();
      for v163_7_byte in v163_7_cursor.child_mask().iter() {
        v163_7_cursor.descend_to_byte(v163_7_byte);
        {
        let v163_7_tail = v163_7_cursor.fork_read_zipper();
        let v163_7_head = Path::from_slice(&[v163_7_byte]);
        let v164_2: Space = singleton(&(v163_7_head));
        let v164_3: Space = intersect(&(*CONSTANT_1),&(v164_2));
        let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
        drop(v164_3);
        let v164_5: Space = subtract(&(*CONSTANT_0),&(v164_4));
        drop(v164_4);
        let v164_8: Space = if (v164_5).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v163_6),&(v163_7_head));
          let mut v165_7 = Space::new();
          let mut v165_7_cursor = (v163_7_tail).read_zipper();
          for v165_7_byte in v165_7_cursor.child_mask().iter() {
            v165_7_cursor.descend_to_byte(v165_7_byte);
            {
            let v165_7_tail = v165_7_cursor.fork_read_zipper();
            let v165_7_head = Path::from_slice(&[v165_7_byte]);
            let v166_2: Space = singleton(&(v165_7_head));
            let v166_3: Space = intersect(&(*CONSTANT_1),&(v166_2));
            let v166_4: Space = if has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
            drop(v166_3);
            let v166_5: Space = subtract(&(*CONSTANT_0),&(v166_4));
            drop(v166_4);
            let v166_8: Space = if (v166_5).is_empty() { Space::new() } else {
              let v167_6: Path = concat_path(&(v165_6),&(v165_7_head));
              let v167_7: Space = routine_22(c, &(v167_6), &(v165_7_tail).make_space());
              compose(&(v166_5),&(v167_7))
            };
            drop(v166_5);
            let v166_9: Space = intersect(&(*CONSTANT_1),&(v166_2));
            drop(v166_2);
            let v166_10: Space = if has_head(&(v166_9)) { singleton(&[]) } else { Space::new() };
            drop(v166_9);
            let v166_12: Space = if (v166_10).is_empty() { Space::new() } else {
              let v168_6: Path = concat_path(&(v165_6),&(v165_7_head));
              let v168_11: Space = routine_23(c, &(v168_6), &(v165_7_tail).make_space());
              drop(v168_6);
              compose(&(v166_10),&(v168_11))
            };
            drop(v166_10);
            let v166_13: Space = unite(&(v166_8),&(v166_12));
            v165_7.join_into((v166_13).clone());
            }
            v165_7_cursor.ascend(1);
          }
          drop(v165_7_cursor);
          compose(&(v164_5),&(v165_7))
        };
        drop(v164_5);
        let v164_9: Space = intersect(&(*CONSTANT_1),&(v164_2));
        drop(v164_2);
        let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
        drop(v164_9);
        let v164_12: Space = if (v164_10).is_empty() { Space::new() } else {
          let v169_6: Path = concat_path(&(v163_6),&(v163_7_head));
          let mut v169_11 = Space::new();
          let mut v169_11_cursor = (v163_7_tail).read_zipper();
          for v169_11_byte in v169_11_cursor.child_mask().iter() {
            v169_11_cursor.descend_to_byte(v169_11_byte);
            {
            let v169_11_tail = v169_11_cursor.fork_read_zipper();
            let v169_11_head = Path::from_slice(&[v169_11_byte]);
            let v170_2: Space = singleton(&(v169_11_head));
            let v170_3: Space = intersect(&(*CONSTANT_1),&(v170_2));
            let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
            drop(v170_3);
            let v170_5: Space = subtract(&(*CONSTANT_0),&(v170_4));
            drop(v170_4);
            let v170_8: Space = if (v170_5).is_empty() { Space::new() } else {
              let v171_6: Path = concat_path(&(v169_6),&(v169_11_head));
              let v171_7: Space = routine_22(c, &(v171_6), &(v169_11_tail).make_space());
              compose(&(v170_5),&(v171_7))
            };
            drop(v170_5);
            let v170_9: Space = intersect(&(*CONSTANT_1),&(v170_2));
            drop(v170_2);
            let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
            drop(v170_9);
            let v170_12: Space = if (v170_10).is_empty() { Space::new() } else {
              let v172_6: Path = concat_path(&(v169_6),&(v169_11_head));
              let v172_11: Space = routine_12(c, &(v172_6), &(v169_11_tail).make_space());
              drop(v172_6);
              compose(&(v170_10),&(v172_11))
            };
            drop(v170_10);
            let v170_13: Space = unite(&(v170_8),&(v170_12));
            v169_11.join_into((v170_13).clone());
            }
            v169_11_cursor.ascend(1);
          }
          drop(v169_11_cursor);
          drop(v169_6);
          compose(&(v164_10),&(v169_11))
        };
        drop(v164_10);
        let v164_13: Space = unite(&(v164_8),&(v164_12));
        v163_7.join_into((v164_13).clone());
        }
        v163_7_cursor.ascend(1);
      }
      drop(v163_7_cursor);
      compose(&(v162_5),&(v163_7))
    };
    drop(v162_5);
    let v162_9: Space = intersect(&(*CONSTANT_1),&(v162_2));
    drop(v162_2);
    let v162_10: Space = if has_head(&(v162_9)) { singleton(&[]) } else { Space::new() };
    drop(v162_9);
    let v162_12: Space = if (v162_10).is_empty() { Space::new() } else {
      let v173_6: Path = concat_path(&(*p0),&(v161_20_head));
      let mut v173_11 = Space::new();
      let mut v173_11_cursor = (v161_20_tail).read_zipper();
      for v173_11_byte in v173_11_cursor.child_mask().iter() {
        v173_11_cursor.descend_to_byte(v173_11_byte);
        {
        let v173_11_tail = v173_11_cursor.fork_read_zipper();
        let v173_11_head = Path::from_slice(&[v173_11_byte]);
        let v174_2: Space = singleton(&(v173_11_head));
        let v174_3: Space = intersect(&(*CONSTANT_1),&(v174_2));
        let v174_4: Space = if has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
        drop(v174_3);
        let v174_5: Space = subtract(&(*CONSTANT_0),&(v174_4));
        drop(v174_4);
        let v174_8: Space = if (v174_5).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v173_6),&(v173_11_head));
          let mut v175_7 = Space::new();
          let mut v175_7_cursor = (v173_11_tail).read_zipper();
          for v175_7_byte in v175_7_cursor.child_mask().iter() {
            v175_7_cursor.descend_to_byte(v175_7_byte);
            {
            let v175_7_tail = v175_7_cursor.fork_read_zipper();
            let v175_7_head = Path::from_slice(&[v175_7_byte]);
            let v176_2: Space = singleton(&(v175_7_head));
            let v176_3: Space = intersect(&(*CONSTANT_1),&(v176_2));
            let v176_4: Space = if has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
            drop(v176_3);
            let v176_5: Space = subtract(&(*CONSTANT_0),&(v176_4));
            drop(v176_4);
            let v176_8: Space = if (v176_5).is_empty() { Space::new() } else {
              let v177_6: Path = concat_path(&(v175_6),&(v175_7_head));
              let v177_7: Space = routine_22(c, &(v177_6), &(v175_7_tail).make_space());
              compose(&(v176_5),&(v177_7))
            };
            drop(v176_5);
            let v176_9: Space = intersect(&(*CONSTANT_1),&(v176_2));
            drop(v176_2);
            let v176_10: Space = if has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
            drop(v176_9);
            let v176_12: Space = if (v176_10).is_empty() { Space::new() } else {
              let v178_6: Path = concat_path(&(v175_6),&(v175_7_head));
              let v178_11: Space = routine_23(c, &(v178_6), &(v175_7_tail).make_space());
              drop(v178_6);
              compose(&(v176_10),&(v178_11))
            };
            drop(v176_10);
            let v176_13: Space = unite(&(v176_8),&(v176_12));
            v175_7.join_into((v176_13).clone());
            }
            v175_7_cursor.ascend(1);
          }
          drop(v175_7_cursor);
          drop(v175_6);
          compose(&(v174_5),&(v175_7))
        };
        drop(v174_5);
        let v174_9: Space = intersect(&(*CONSTANT_1),&(v174_2));
        drop(v174_2);
        let v174_10: Space = if has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
        drop(v174_9);
        let v174_11: Space = compose(&(v174_10),&(v173_11_tail));
        drop(v174_10);
        let v174_12: Space = unite(&(v174_8),&(v174_11));
        drop(v174_11);
        v173_11.join_into((v174_12).clone());
        }
        v173_11_cursor.ascend(1);
      }
      drop(v173_11_cursor);
      drop(v173_6);
      compose(&(v162_10),&(v173_11))
    };
    drop(v162_10);
    let v162_13: Space = unite(&(v162_8),&(v162_12));
    v161_20.join_into((v162_13).clone());
    }
    v161_20_cursor.ascend(1);
  }
  drop(v161_20_cursor);
  (v161_20).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v179_14 = Space::new();
  let mut v179_14_cursor = (*s0).read_zipper();
  for v179_14_byte in v179_14_cursor.child_mask().iter() {
    v179_14_cursor.descend_to_byte(v179_14_byte);
    {
    let v179_14_tail = v179_14_cursor.fork_read_zipper();
    let v179_14_head = Path::from_slice(&[v179_14_byte]);
    let v180_2: Space = singleton(&(v179_14_head));
    let v180_3: Space = intersect(&(*CONSTANT_1),&(v180_2));
    let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
    drop(v180_3);
    let v180_5: Space = subtract(&(*CONSTANT_0),&(v180_4));
    drop(v180_4);
    let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
      let v181_6: Path = concat_path(&(*p0),&(v179_14_head));
      let mut v181_7 = Space::new();
      let mut v181_7_cursor = (v179_14_tail).read_zipper();
      for v181_7_byte in v181_7_cursor.child_mask().iter() {
        v181_7_cursor.descend_to_byte(v181_7_byte);
        {
        let v181_7_tail = v181_7_cursor.fork_read_zipper();
        let v181_7_head = Path::from_slice(&[v181_7_byte]);
        let v182_2: Space = singleton(&(v181_7_head));
        let v182_3: Space = intersect(&(*CONSTANT_1),&(v182_2));
        let v182_4: Space = if has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
        drop(v182_3);
        let v182_5: Space = subtract(&(*CONSTANT_0),&(v182_4));
        drop(v182_4);
        let v182_8: Space = if (v182_5).is_empty() { Space::new() } else {
          let v183_6: Path = concat_path(&(v181_6),&(v181_7_head));
          let mut v183_7 = Space::new();
          let mut v183_7_cursor = (v181_7_tail).read_zipper();
          for v183_7_byte in v183_7_cursor.child_mask().iter() {
            v183_7_cursor.descend_to_byte(v183_7_byte);
            {
            let v183_7_tail = v183_7_cursor.fork_read_zipper();
            let v183_7_head = Path::from_slice(&[v183_7_byte]);
            let v184_2: Space = singleton(&(v183_7_head));
            let v184_3: Space = intersect(&(*CONSTANT_1),&(v184_2));
            let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
            drop(v184_3);
            let v184_5: Space = subtract(&(*CONSTANT_0),&(v184_4));
            drop(v184_4);
            let v184_8: Space = if (v184_5).is_empty() { Space::new() } else {
              let v185_6: Path = concat_path(&(v183_6),&(v183_7_head));
              let v185_7: Space = routine_22(c, &(v185_6), &(v183_7_tail).make_space());
              compose(&(v184_5),&(v185_7))
            };
            drop(v184_5);
            let v184_9: Space = intersect(&(*CONSTANT_1),&(v184_2));
            drop(v184_2);
            let v184_10: Space = if has_head(&(v184_9)) { singleton(&[]) } else { Space::new() };
            drop(v184_9);
            let v184_12: Space = if (v184_10).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v183_6),&(v183_7_head));
              let v186_11: Space = routine_23(c, &(v186_6), &(v183_7_tail).make_space());
              drop(v186_6);
              compose(&(v184_10),&(v186_11))
            };
            drop(v184_10);
            let v184_13: Space = unite(&(v184_8),&(v184_12));
            v183_7.join_into((v184_13).clone());
            }
            v183_7_cursor.ascend(1);
          }
          drop(v183_7_cursor);
          compose(&(v182_5),&(v183_7))
        };
        drop(v182_5);
        let v182_9: Space = intersect(&(*CONSTANT_1),&(v182_2));
        drop(v182_2);
        let v182_10: Space = if has_head(&(v182_9)) { singleton(&[]) } else { Space::new() };
        drop(v182_9);
        let v182_12: Space = if (v182_10).is_empty() { Space::new() } else {
          let v187_6: Path = concat_path(&(v181_6),&(v181_7_head));
          let mut v187_11 = Space::new();
          let mut v187_11_cursor = (v181_7_tail).read_zipper();
          for v187_11_byte in v187_11_cursor.child_mask().iter() {
            v187_11_cursor.descend_to_byte(v187_11_byte);
            {
            let v187_11_tail = v187_11_cursor.fork_read_zipper();
            let v187_11_head = Path::from_slice(&[v187_11_byte]);
            let v188_2: Space = singleton(&(v187_11_head));
            let v188_3: Space = intersect(&(*CONSTANT_1),&(v188_2));
            let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
            drop(v188_3);
            let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
            drop(v188_4);
            let v188_8: Space = if (v188_5).is_empty() { Space::new() } else {
              let v189_6: Path = concat_path(&(v187_6),&(v187_11_head));
              let v189_7: Space = routine_22(c, &(v189_6), &(v187_11_tail).make_space());
              compose(&(v188_5),&(v189_7))
            };
            drop(v188_5);
            let v188_9: Space = intersect(&(*CONSTANT_1),&(v188_2));
            drop(v188_2);
            let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
            drop(v188_9);
            let v188_12: Space = if (v188_10).is_empty() { Space::new() } else {
              let v190_6: Path = concat_path(&(v187_6),&(v187_11_head));
              let v190_11: Space = routine_12(c, &(v190_6), &(v187_11_tail).make_space());
              drop(v190_6);
              compose(&(v188_10),&(v190_11))
            };
            drop(v188_10);
            let v188_13: Space = unite(&(v188_8),&(v188_12));
            v187_11.join_into((v188_13).clone());
            }
            v187_11_cursor.ascend(1);
          }
          drop(v187_11_cursor);
          drop(v187_6);
          compose(&(v182_10),&(v187_11))
        };
        drop(v182_10);
        let v182_13: Space = unite(&(v182_8),&(v182_12));
        v181_7.join_into((v182_13).clone());
        }
        v181_7_cursor.ascend(1);
      }
      drop(v181_7_cursor);
      drop(v181_6);
      compose(&(v180_5),&(v181_7))
    };
    drop(v180_5);
    let v180_9: Space = intersect(&(*CONSTANT_1),&(v180_2));
    drop(v180_2);
    let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
    drop(v180_9);
    let v180_11: Space = compose(&(v180_10),&(v179_14_tail));
    drop(v180_10);
    let v180_12: Space = unite(&(v180_8),&(v180_11));
    drop(v180_11);
    v179_14.join_into((v180_12).clone());
    }
    v179_14_cursor.ascend(1);
  }
  drop(v179_14_cursor);
  (v179_14).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v191_20 = Space::new();
  let mut v191_20_cursor = (*s0).read_zipper();
  for v191_20_byte in v191_20_cursor.child_mask().iter() {
    v191_20_cursor.descend_to_byte(v191_20_byte);
    {
    let v191_20_tail = v191_20_cursor.fork_read_zipper();
    let v191_20_head = Path::from_slice(&[v191_20_byte]);
    let v192_2: Space = singleton(&(v191_20_head));
    let v192_3: Space = intersect(&(*CONSTANT_1),&(v192_2));
    let v192_4: Space = if has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
    drop(v192_3);
    let v192_5: Space = subtract(&(*CONSTANT_0),&(v192_4));
    drop(v192_4);
    let v192_8: Space = if (v192_5).is_empty() { Space::new() } else {
      let v193_6: Path = concat_path(&(*p0),&(v191_20_head));
      let mut v193_7 = Space::new();
      let mut v193_7_cursor = (v191_20_tail).read_zipper();
      for v193_7_byte in v193_7_cursor.child_mask().iter() {
        v193_7_cursor.descend_to_byte(v193_7_byte);
        {
        let v193_7_tail = v193_7_cursor.fork_read_zipper();
        let v193_7_head = Path::from_slice(&[v193_7_byte]);
        let v194_2: Space = singleton(&(v193_7_head));
        let v194_3: Space = intersect(&(*CONSTANT_1),&(v194_2));
        let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
        drop(v194_3);
        let v194_5: Space = subtract(&(*CONSTANT_0),&(v194_4));
        drop(v194_4);
        let v194_8: Space = if (v194_5).is_empty() { Space::new() } else {
          let v195_6: Path = concat_path(&(v193_6),&(v193_7_head));
          let mut v195_7 = Space::new();
          let mut v195_7_cursor = (v193_7_tail).read_zipper();
          for v195_7_byte in v195_7_cursor.child_mask().iter() {
            v195_7_cursor.descend_to_byte(v195_7_byte);
            {
            let v195_7_tail = v195_7_cursor.fork_read_zipper();
            let v195_7_head = Path::from_slice(&[v195_7_byte]);
            let v196_2: Space = singleton(&(v195_7_head));
            let v196_3: Space = intersect(&(*CONSTANT_1),&(v196_2));
            let v196_4: Space = if has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
            drop(v196_3);
            let v196_5: Space = subtract(&(*CONSTANT_0),&(v196_4));
            drop(v196_4);
            let v196_8: Space = if (v196_5).is_empty() { Space::new() } else {
              let v197_6: Path = concat_path(&(v195_6),&(v195_7_head));
              let v197_7: Space = routine_24(c, &(v197_6), &(v195_7_tail).make_space());
              compose(&(v196_5),&(v197_7))
            };
            drop(v196_5);
            let v196_9: Space = intersect(&(*CONSTANT_1),&(v196_2));
            drop(v196_2);
            let v196_10: Space = if has_head(&(v196_9)) { singleton(&[]) } else { Space::new() };
            drop(v196_9);
            let v196_12: Space = if (v196_10).is_empty() { Space::new() } else {
              let v198_6: Path = concat_path(&(v195_6),&(v195_7_head));
              let v198_11: Space = routine_25(c, &(v198_6), &(v195_7_tail).make_space());
              drop(v198_6);
              compose(&(v196_10),&(v198_11))
            };
            drop(v196_10);
            let v196_13: Space = unite(&(v196_8),&(v196_12));
            v195_7.join_into((v196_13).clone());
            }
            v195_7_cursor.ascend(1);
          }
          drop(v195_7_cursor);
          compose(&(v194_5),&(v195_7))
        };
        drop(v194_5);
        let v194_9: Space = intersect(&(*CONSTANT_1),&(v194_2));
        drop(v194_2);
        let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
        drop(v194_9);
        let v194_12: Space = if (v194_10).is_empty() { Space::new() } else {
          let v199_6: Path = concat_path(&(v193_6),&(v193_7_head));
          let mut v199_11 = Space::new();
          let mut v199_11_cursor = (v193_7_tail).read_zipper();
          for v199_11_byte in v199_11_cursor.child_mask().iter() {
            v199_11_cursor.descend_to_byte(v199_11_byte);
            {
            let v199_11_tail = v199_11_cursor.fork_read_zipper();
            let v199_11_head = Path::from_slice(&[v199_11_byte]);
            let v200_2: Space = singleton(&(v199_11_head));
            let v200_3: Space = intersect(&(*CONSTANT_1),&(v200_2));
            let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
            drop(v200_3);
            let v200_5: Space = subtract(&(*CONSTANT_0),&(v200_4));
            drop(v200_4);
            let v200_8: Space = if (v200_5).is_empty() { Space::new() } else {
              let v201_6: Path = concat_path(&(v199_6),&(v199_11_head));
              let v201_7: Space = routine_24(c, &(v201_6), &(v199_11_tail).make_space());
              compose(&(v200_5),&(v201_7))
            };
            drop(v200_5);
            let v200_9: Space = intersect(&(*CONSTANT_1),&(v200_2));
            drop(v200_2);
            let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
            drop(v200_9);
            let v200_12: Space = if (v200_10).is_empty() { Space::new() } else {
              let v202_6: Path = concat_path(&(v199_6),&(v199_11_head));
              let v202_11: Space = routine_15(c, &(v202_6), &(v199_11_tail).make_space());
              drop(v202_6);
              compose(&(v200_10),&(v202_11))
            };
            drop(v200_10);
            let v200_13: Space = unite(&(v200_8),&(v200_12));
            v199_11.join_into((v200_13).clone());
            }
            v199_11_cursor.ascend(1);
          }
          drop(v199_11_cursor);
          drop(v199_6);
          compose(&(v194_10),&(v199_11))
        };
        drop(v194_10);
        let v194_13: Space = unite(&(v194_8),&(v194_12));
        v193_7.join_into((v194_13).clone());
        }
        v193_7_cursor.ascend(1);
      }
      drop(v193_7_cursor);
      compose(&(v192_5),&(v193_7))
    };
    drop(v192_5);
    let v192_9: Space = intersect(&(*CONSTANT_1),&(v192_2));
    drop(v192_2);
    let v192_10: Space = if has_head(&(v192_9)) { singleton(&[]) } else { Space::new() };
    drop(v192_9);
    let v192_12: Space = if (v192_10).is_empty() { Space::new() } else {
      let v203_6: Path = concat_path(&(*p0),&(v191_20_head));
      let mut v203_11 = Space::new();
      let mut v203_11_cursor = (v191_20_tail).read_zipper();
      for v203_11_byte in v203_11_cursor.child_mask().iter() {
        v203_11_cursor.descend_to_byte(v203_11_byte);
        {
        let v203_11_tail = v203_11_cursor.fork_read_zipper();
        let v203_11_head = Path::from_slice(&[v203_11_byte]);
        let v204_2: Space = singleton(&(v203_11_head));
        let v204_3: Space = intersect(&(*CONSTANT_1),&(v204_2));
        let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
        drop(v204_3);
        let v204_5: Space = subtract(&(*CONSTANT_0),&(v204_4));
        drop(v204_4);
        let v204_8: Space = if (v204_5).is_empty() { Space::new() } else {
          let v205_6: Path = concat_path(&(v203_6),&(v203_11_head));
          let mut v205_7 = Space::new();
          let mut v205_7_cursor = (v203_11_tail).read_zipper();
          for v205_7_byte in v205_7_cursor.child_mask().iter() {
            v205_7_cursor.descend_to_byte(v205_7_byte);
            {
            let v205_7_tail = v205_7_cursor.fork_read_zipper();
            let v205_7_head = Path::from_slice(&[v205_7_byte]);
            let v206_2: Space = singleton(&(v205_7_head));
            let v206_3: Space = intersect(&(*CONSTANT_1),&(v206_2));
            let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
            drop(v206_3);
            let v206_5: Space = subtract(&(*CONSTANT_0),&(v206_4));
            drop(v206_4);
            let v206_8: Space = if (v206_5).is_empty() { Space::new() } else {
              let v207_6: Path = concat_path(&(v205_6),&(v205_7_head));
              let v207_7: Space = routine_24(c, &(v207_6), &(v205_7_tail).make_space());
              compose(&(v206_5),&(v207_7))
            };
            drop(v206_5);
            let v206_9: Space = intersect(&(*CONSTANT_1),&(v206_2));
            drop(v206_2);
            let v206_10: Space = if has_head(&(v206_9)) { singleton(&[]) } else { Space::new() };
            drop(v206_9);
            let v206_12: Space = if (v206_10).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v205_6),&(v205_7_head));
              let v208_11: Space = routine_25(c, &(v208_6), &(v205_7_tail).make_space());
              drop(v208_6);
              compose(&(v206_10),&(v208_11))
            };
            drop(v206_10);
            let v206_13: Space = unite(&(v206_8),&(v206_12));
            v205_7.join_into((v206_13).clone());
            }
            v205_7_cursor.ascend(1);
          }
          drop(v205_7_cursor);
          drop(v205_6);
          compose(&(v204_5),&(v205_7))
        };
        drop(v204_5);
        let v204_9: Space = intersect(&(*CONSTANT_1),&(v204_2));
        drop(v204_2);
        let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
        drop(v204_9);
        let v204_11: Space = compose(&(v204_10),&(v203_11_tail));
        drop(v204_10);
        let v204_12: Space = unite(&(v204_8),&(v204_11));
        drop(v204_11);
        v203_11.join_into((v204_12).clone());
        }
        v203_11_cursor.ascend(1);
      }
      drop(v203_11_cursor);
      drop(v203_6);
      compose(&(v192_10),&(v203_11))
    };
    drop(v192_10);
    let v192_13: Space = unite(&(v192_8),&(v192_12));
    v191_20.join_into((v192_13).clone());
    }
    v191_20_cursor.ascend(1);
  }
  drop(v191_20_cursor);
  (v191_20).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v209_14 = Space::new();
  let mut v209_14_cursor = (*s0).read_zipper();
  for v209_14_byte in v209_14_cursor.child_mask().iter() {
    v209_14_cursor.descend_to_byte(v209_14_byte);
    {
    let v209_14_tail = v209_14_cursor.fork_read_zipper();
    let v209_14_head = Path::from_slice(&[v209_14_byte]);
    let v210_2: Space = singleton(&(v209_14_head));
    let v210_3: Space = intersect(&(*CONSTANT_1),&(v210_2));
    let v210_4: Space = if has_head(&(v210_3)) { singleton(&[]) } else { Space::new() };
    drop(v210_3);
    let v210_5: Space = subtract(&(*CONSTANT_0),&(v210_4));
    drop(v210_4);
    let v210_8: Space = if (v210_5).is_empty() { Space::new() } else {
      let v211_6: Path = concat_path(&(*p0),&(v209_14_head));
      let mut v211_7 = Space::new();
      let mut v211_7_cursor = (v209_14_tail).read_zipper();
      for v211_7_byte in v211_7_cursor.child_mask().iter() {
        v211_7_cursor.descend_to_byte(v211_7_byte);
        {
        let v211_7_tail = v211_7_cursor.fork_read_zipper();
        let v211_7_head = Path::from_slice(&[v211_7_byte]);
        let v212_2: Space = singleton(&(v211_7_head));
        let v212_3: Space = intersect(&(*CONSTANT_1),&(v212_2));
        let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
        drop(v212_3);
        let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
        drop(v212_4);
        let v212_8: Space = if (v212_5).is_empty() { Space::new() } else {
          let v213_6: Path = concat_path(&(v211_6),&(v211_7_head));
          let mut v213_7 = Space::new();
          let mut v213_7_cursor = (v211_7_tail).read_zipper();
          for v213_7_byte in v213_7_cursor.child_mask().iter() {
            v213_7_cursor.descend_to_byte(v213_7_byte);
            {
            let v213_7_tail = v213_7_cursor.fork_read_zipper();
            let v213_7_head = Path::from_slice(&[v213_7_byte]);
            let v214_2: Space = singleton(&(v213_7_head));
            let v214_3: Space = intersect(&(*CONSTANT_1),&(v214_2));
            let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
            drop(v214_3);
            let v214_5: Space = subtract(&(*CONSTANT_0),&(v214_4));
            drop(v214_4);
            let v214_8: Space = if (v214_5).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v213_6),&(v213_7_head));
              let v215_7: Space = routine_24(c, &(v215_6), &(v213_7_tail).make_space());
              compose(&(v214_5),&(v215_7))
            };
            drop(v214_5);
            let v214_9: Space = intersect(&(*CONSTANT_1),&(v214_2));
            drop(v214_2);
            let v214_10: Space = if has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
            drop(v214_9);
            let v214_12: Space = if (v214_10).is_empty() { Space::new() } else {
              let v216_6: Path = concat_path(&(v213_6),&(v213_7_head));
              let v216_11: Space = routine_25(c, &(v216_6), &(v213_7_tail).make_space());
              drop(v216_6);
              compose(&(v214_10),&(v216_11))
            };
            drop(v214_10);
            let v214_13: Space = unite(&(v214_8),&(v214_12));
            v213_7.join_into((v214_13).clone());
            }
            v213_7_cursor.ascend(1);
          }
          drop(v213_7_cursor);
          compose(&(v212_5),&(v213_7))
        };
        drop(v212_5);
        let v212_9: Space = intersect(&(*CONSTANT_1),&(v212_2));
        drop(v212_2);
        let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
        drop(v212_9);
        let v212_12: Space = if (v212_10).is_empty() { Space::new() } else {
          let v217_6: Path = concat_path(&(v211_6),&(v211_7_head));
          let mut v217_11 = Space::new();
          let mut v217_11_cursor = (v211_7_tail).read_zipper();
          for v217_11_byte in v217_11_cursor.child_mask().iter() {
            v217_11_cursor.descend_to_byte(v217_11_byte);
            {
            let v217_11_tail = v217_11_cursor.fork_read_zipper();
            let v217_11_head = Path::from_slice(&[v217_11_byte]);
            let v218_2: Space = singleton(&(v217_11_head));
            let v218_3: Space = intersect(&(*CONSTANT_1),&(v218_2));
            let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
            drop(v218_3);
            let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
            drop(v218_4);
            let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
              let v219_6: Path = concat_path(&(v217_6),&(v217_11_head));
              let v219_7: Space = routine_24(c, &(v219_6), &(v217_11_tail).make_space());
              compose(&(v218_5),&(v219_7))
            };
            drop(v218_5);
            let v218_9: Space = intersect(&(*CONSTANT_1),&(v218_2));
            drop(v218_2);
            let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
            drop(v218_9);
            let v218_12: Space = if (v218_10).is_empty() { Space::new() } else {
              let v220_6: Path = concat_path(&(v217_6),&(v217_11_head));
              let v220_11: Space = routine_15(c, &(v220_6), &(v217_11_tail).make_space());
              drop(v220_6);
              compose(&(v218_10),&(v220_11))
            };
            drop(v218_10);
            let v218_13: Space = unite(&(v218_8),&(v218_12));
            v217_11.join_into((v218_13).clone());
            }
            v217_11_cursor.ascend(1);
          }
          drop(v217_11_cursor);
          drop(v217_6);
          compose(&(v212_10),&(v217_11))
        };
        drop(v212_10);
        let v212_13: Space = unite(&(v212_8),&(v212_12));
        v211_7.join_into((v212_13).clone());
        }
        v211_7_cursor.ascend(1);
      }
      drop(v211_7_cursor);
      drop(v211_6);
      compose(&(v210_5),&(v211_7))
    };
    drop(v210_5);
    let v210_9: Space = intersect(&(*CONSTANT_1),&(v210_2));
    drop(v210_2);
    let v210_10: Space = if has_head(&(v210_9)) { singleton(&[]) } else { Space::new() };
    drop(v210_9);
    let v210_11: Space = compose(&(v210_10),&(v209_14_tail));
    drop(v210_10);
    let v210_12: Space = unite(&(v210_8),&(v210_11));
    drop(v210_11);
    v209_14.join_into((v210_12).clone());
    }
    v209_14_cursor.ascend(1);
  }
  drop(v209_14_cursor);
  (v209_14).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v221_20 = Space::new();
  let mut v221_20_cursor = (*s0).read_zipper();
  for v221_20_byte in v221_20_cursor.child_mask().iter() {
    v221_20_cursor.descend_to_byte(v221_20_byte);
    {
    let v221_20_tail = v221_20_cursor.fork_read_zipper();
    let v221_20_head = Path::from_slice(&[v221_20_byte]);
    let v222_2: Space = singleton(&(v221_20_head));
    let v222_3: Space = intersect(&(*CONSTANT_1),&(v222_2));
    let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
    drop(v222_3);
    let v222_5: Space = subtract(&(*CONSTANT_0),&(v222_4));
    drop(v222_4);
    let v222_8: Space = if (v222_5).is_empty() { Space::new() } else {
      let v223_6: Path = concat_path(&(*p0),&(v221_20_head));
      let mut v223_7 = Space::new();
      let mut v223_7_cursor = (v221_20_tail).read_zipper();
      for v223_7_byte in v223_7_cursor.child_mask().iter() {
        v223_7_cursor.descend_to_byte(v223_7_byte);
        {
        let v223_7_tail = v223_7_cursor.fork_read_zipper();
        let v223_7_head = Path::from_slice(&[v223_7_byte]);
        let v224_2: Space = singleton(&(v223_7_head));
        let v224_3: Space = intersect(&(*CONSTANT_1),&(v224_2));
        let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
        drop(v224_3);
        let v224_5: Space = subtract(&(*CONSTANT_0),&(v224_4));
        drop(v224_4);
        let v224_8: Space = if (v224_5).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v223_6),&(v223_7_head));
          let mut v225_7 = Space::new();
          let mut v225_7_cursor = (v223_7_tail).read_zipper();
          for v225_7_byte in v225_7_cursor.child_mask().iter() {
            v225_7_cursor.descend_to_byte(v225_7_byte);
            {
            let v225_7_tail = v225_7_cursor.fork_read_zipper();
            let v225_7_head = Path::from_slice(&[v225_7_byte]);
            let v226_2: Space = singleton(&(v225_7_head));
            let v226_3: Space = intersect(&(*CONSTANT_1),&(v226_2));
            let v226_4: Space = if has_head(&(v226_3)) { singleton(&[]) } else { Space::new() };
            drop(v226_3);
            let v226_5: Space = subtract(&(*CONSTANT_0),&(v226_4));
            drop(v226_4);
            let v226_8: Space = if (v226_5).is_empty() { Space::new() } else {
              let v227_6: Path = concat_path(&(v225_6),&(v225_7_head));
              let v227_7: Space = routine_26(c, &(v227_6), &(v225_7_tail).make_space());
              compose(&(v226_5),&(v227_7))
            };
            drop(v226_5);
            let v226_9: Space = intersect(&(*CONSTANT_1),&(v226_2));
            drop(v226_2);
            let v226_10: Space = if has_head(&(v226_9)) { singleton(&[]) } else { Space::new() };
            drop(v226_9);
            let v226_12: Space = if (v226_10).is_empty() { Space::new() } else {
              let v228_6: Path = concat_path(&(v225_6),&(v225_7_head));
              let v228_11: Space = routine_27(c, &(v228_6), &(v225_7_tail).make_space());
              drop(v228_6);
              compose(&(v226_10),&(v228_11))
            };
            drop(v226_10);
            let v226_13: Space = unite(&(v226_8),&(v226_12));
            v225_7.join_into((v226_13).clone());
            }
            v225_7_cursor.ascend(1);
          }
          drop(v225_7_cursor);
          compose(&(v224_5),&(v225_7))
        };
        drop(v224_5);
        let v224_9: Space = intersect(&(*CONSTANT_1),&(v224_2));
        drop(v224_2);
        let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
        drop(v224_9);
        let v224_12: Space = if (v224_10).is_empty() { Space::new() } else {
          let v229_6: Path = concat_path(&(v223_6),&(v223_7_head));
          let mut v229_11 = Space::new();
          let mut v229_11_cursor = (v223_7_tail).read_zipper();
          for v229_11_byte in v229_11_cursor.child_mask().iter() {
            v229_11_cursor.descend_to_byte(v229_11_byte);
            {
            let v229_11_tail = v229_11_cursor.fork_read_zipper();
            let v229_11_head = Path::from_slice(&[v229_11_byte]);
            let v230_2: Space = singleton(&(v229_11_head));
            let v230_3: Space = intersect(&(*CONSTANT_1),&(v230_2));
            let v230_4: Space = if has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
            drop(v230_3);
            let v230_5: Space = subtract(&(*CONSTANT_0),&(v230_4));
            drop(v230_4);
            let v230_8: Space = if (v230_5).is_empty() { Space::new() } else {
              let v231_6: Path = concat_path(&(v229_6),&(v229_11_head));
              let v231_7: Space = routine_26(c, &(v231_6), &(v229_11_tail).make_space());
              compose(&(v230_5),&(v231_7))
            };
            drop(v230_5);
            let v230_9: Space = intersect(&(*CONSTANT_1),&(v230_2));
            drop(v230_2);
            let v230_10: Space = if has_head(&(v230_9)) { singleton(&[]) } else { Space::new() };
            drop(v230_9);
            let v230_12: Space = if (v230_10).is_empty() { Space::new() } else {
              let v232_6: Path = concat_path(&(v229_6),&(v229_11_head));
              let v232_11: Space = routine_12(c, &(v232_6), &(v229_11_tail).make_space());
              drop(v232_6);
              compose(&(v230_10),&(v232_11))
            };
            drop(v230_10);
            let v230_13: Space = unite(&(v230_8),&(v230_12));
            v229_11.join_into((v230_13).clone());
            }
            v229_11_cursor.ascend(1);
          }
          drop(v229_11_cursor);
          drop(v229_6);
          compose(&(v224_10),&(v229_11))
        };
        drop(v224_10);
        let v224_13: Space = unite(&(v224_8),&(v224_12));
        v223_7.join_into((v224_13).clone());
        }
        v223_7_cursor.ascend(1);
      }
      drop(v223_7_cursor);
      compose(&(v222_5),&(v223_7))
    };
    drop(v222_5);
    let v222_9: Space = intersect(&(*CONSTANT_1),&(v222_2));
    drop(v222_2);
    let v222_10: Space = if has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
    drop(v222_9);
    let v222_12: Space = if (v222_10).is_empty() { Space::new() } else {
      let v233_6: Path = concat_path(&(*p0),&(v221_20_head));
      let mut v233_11 = Space::new();
      let mut v233_11_cursor = (v221_20_tail).read_zipper();
      for v233_11_byte in v233_11_cursor.child_mask().iter() {
        v233_11_cursor.descend_to_byte(v233_11_byte);
        {
        let v233_11_tail = v233_11_cursor.fork_read_zipper();
        let v233_11_head = Path::from_slice(&[v233_11_byte]);
        let v234_2: Space = singleton(&(v233_11_head));
        let v234_3: Space = intersect(&(*CONSTANT_1),&(v234_2));
        let v234_4: Space = if has_head(&(v234_3)) { singleton(&[]) } else { Space::new() };
        drop(v234_3);
        let v234_5: Space = subtract(&(*CONSTANT_0),&(v234_4));
        drop(v234_4);
        let v234_8: Space = if (v234_5).is_empty() { Space::new() } else {
          let v235_6: Path = concat_path(&(v233_6),&(v233_11_head));
          let mut v235_7 = Space::new();
          let mut v235_7_cursor = (v233_11_tail).read_zipper();
          for v235_7_byte in v235_7_cursor.child_mask().iter() {
            v235_7_cursor.descend_to_byte(v235_7_byte);
            {
            let v235_7_tail = v235_7_cursor.fork_read_zipper();
            let v235_7_head = Path::from_slice(&[v235_7_byte]);
            let v236_2: Space = singleton(&(v235_7_head));
            let v236_3: Space = intersect(&(*CONSTANT_1),&(v236_2));
            let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
            drop(v236_3);
            let v236_5: Space = subtract(&(*CONSTANT_0),&(v236_4));
            drop(v236_4);
            let v236_8: Space = if (v236_5).is_empty() { Space::new() } else {
              let v237_6: Path = concat_path(&(v235_6),&(v235_7_head));
              let v237_7: Space = routine_26(c, &(v237_6), &(v235_7_tail).make_space());
              compose(&(v236_5),&(v237_7))
            };
            drop(v236_5);
            let v236_9: Space = intersect(&(*CONSTANT_1),&(v236_2));
            drop(v236_2);
            let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
            drop(v236_9);
            let v236_12: Space = if (v236_10).is_empty() { Space::new() } else {
              let v238_6: Path = concat_path(&(v235_6),&(v235_7_head));
              let v238_11: Space = routine_27(c, &(v238_6), &(v235_7_tail).make_space());
              drop(v238_6);
              compose(&(v236_10),&(v238_11))
            };
            drop(v236_10);
            let v236_13: Space = unite(&(v236_8),&(v236_12));
            v235_7.join_into((v236_13).clone());
            }
            v235_7_cursor.ascend(1);
          }
          drop(v235_7_cursor);
          drop(v235_6);
          compose(&(v234_5),&(v235_7))
        };
        drop(v234_5);
        let v234_9: Space = intersect(&(*CONSTANT_1),&(v234_2));
        drop(v234_2);
        let v234_10: Space = if has_head(&(v234_9)) { singleton(&[]) } else { Space::new() };
        drop(v234_9);
        let v234_11: Space = compose(&(v234_10),&(v233_11_tail));
        drop(v234_10);
        let v234_12: Space = unite(&(v234_8),&(v234_11));
        drop(v234_11);
        v233_11.join_into((v234_12).clone());
        }
        v233_11_cursor.ascend(1);
      }
      drop(v233_11_cursor);
      drop(v233_6);
      compose(&(v222_10),&(v233_11))
    };
    drop(v222_10);
    let v222_13: Space = unite(&(v222_8),&(v222_12));
    v221_20.join_into((v222_13).clone());
    }
    v221_20_cursor.ascend(1);
  }
  drop(v221_20_cursor);
  (v221_20).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v239_14 = Space::new();
  let mut v239_14_cursor = (*s0).read_zipper();
  for v239_14_byte in v239_14_cursor.child_mask().iter() {
    v239_14_cursor.descend_to_byte(v239_14_byte);
    {
    let v239_14_tail = v239_14_cursor.fork_read_zipper();
    let v239_14_head = Path::from_slice(&[v239_14_byte]);
    let v240_2: Space = singleton(&(v239_14_head));
    let v240_3: Space = intersect(&(*CONSTANT_1),&(v240_2));
    let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
    drop(v240_3);
    let v240_5: Space = subtract(&(*CONSTANT_0),&(v240_4));
    drop(v240_4);
    let v240_8: Space = if (v240_5).is_empty() { Space::new() } else {
      let v241_6: Path = concat_path(&(*p0),&(v239_14_head));
      let mut v241_7 = Space::new();
      let mut v241_7_cursor = (v239_14_tail).read_zipper();
      for v241_7_byte in v241_7_cursor.child_mask().iter() {
        v241_7_cursor.descend_to_byte(v241_7_byte);
        {
        let v241_7_tail = v241_7_cursor.fork_read_zipper();
        let v241_7_head = Path::from_slice(&[v241_7_byte]);
        let v242_2: Space = singleton(&(v241_7_head));
        let v242_3: Space = intersect(&(*CONSTANT_1),&(v242_2));
        let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = subtract(&(*CONSTANT_0),&(v242_4));
        drop(v242_4);
        let v242_8: Space = if (v242_5).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v241_6),&(v241_7_head));
          let mut v243_7 = Space::new();
          let mut v243_7_cursor = (v241_7_tail).read_zipper();
          for v243_7_byte in v243_7_cursor.child_mask().iter() {
            v243_7_cursor.descend_to_byte(v243_7_byte);
            {
            let v243_7_tail = v243_7_cursor.fork_read_zipper();
            let v243_7_head = Path::from_slice(&[v243_7_byte]);
            let v244_2: Space = singleton(&(v243_7_head));
            let v244_3: Space = intersect(&(*CONSTANT_1),&(v244_2));
            let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = subtract(&(*CONSTANT_0),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (v244_5).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&(v243_7_head));
              let v245_7: Space = routine_26(c, &(v245_6), &(v243_7_tail).make_space());
              compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = intersect(&(*CONSTANT_1),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (v244_10).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&(v243_7_head));
              let v246_11: Space = routine_27(c, &(v246_6), &(v243_7_tail).make_space());
              drop(v246_6);
              compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = unite(&(v244_8),&(v244_12));
            v243_7.join_into((v244_13).clone());
            }
            v243_7_cursor.ascend(1);
          }
          drop(v243_7_cursor);
          compose(&(v242_5),&(v243_7))
        };
        drop(v242_5);
        let v242_9: Space = intersect(&(*CONSTANT_1),&(v242_2));
        drop(v242_2);
        let v242_10: Space = if has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
        drop(v242_9);
        let v242_12: Space = if (v242_10).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v241_6),&(v241_7_head));
          let mut v247_11 = Space::new();
          let mut v247_11_cursor = (v241_7_tail).read_zipper();
          for v247_11_byte in v247_11_cursor.child_mask().iter() {
            v247_11_cursor.descend_to_byte(v247_11_byte);
            {
            let v247_11_tail = v247_11_cursor.fork_read_zipper();
            let v247_11_head = Path::from_slice(&[v247_11_byte]);
            let v248_2: Space = singleton(&(v247_11_head));
            let v248_3: Space = intersect(&(*CONSTANT_1),&(v248_2));
            let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = subtract(&(*CONSTANT_0),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&(v247_11_head));
              let v249_7: Space = routine_26(c, &(v249_6), &(v247_11_tail).make_space());
              compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = intersect(&(*CONSTANT_1),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&(v247_11_head));
              let v250_11: Space = routine_12(c, &(v250_6), &(v247_11_tail).make_space());
              drop(v250_6);
              compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = unite(&(v248_8),&(v248_12));
            v247_11.join_into((v248_13).clone());
            }
            v247_11_cursor.ascend(1);
          }
          drop(v247_11_cursor);
          drop(v247_6);
          compose(&(v242_10),&(v247_11))
        };
        drop(v242_10);
        let v242_13: Space = unite(&(v242_8),&(v242_12));
        v241_7.join_into((v242_13).clone());
        }
        v241_7_cursor.ascend(1);
      }
      drop(v241_7_cursor);
      drop(v241_6);
      compose(&(v240_5),&(v241_7))
    };
    drop(v240_5);
    let v240_9: Space = intersect(&(*CONSTANT_1),&(v240_2));
    drop(v240_2);
    let v240_10: Space = if has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
    drop(v240_9);
    let v240_11: Space = compose(&(v240_10),&(v239_14_tail));
    drop(v240_10);
    let v240_12: Space = unite(&(v240_8),&(v240_11));
    drop(v240_11);
    v239_14.join_into((v240_12).clone());
    }
    v239_14_cursor.ascend(1);
  }
  drop(v239_14_cursor);
  (v239_14).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v252_20 = Space::new();
  let mut v252_20_cursor = (*s0).read_zipper();
  for v252_20_byte in v252_20_cursor.child_mask().iter() {
    v252_20_cursor.descend_to_byte(v252_20_byte);
    {
    let v252_20_tail = v252_20_cursor.fork_read_zipper();
    let v252_20_head = Path::from_slice(&[v252_20_byte]);
    let v253_2: Space = singleton(&(v252_20_head));
    let v253_3: Space = intersect(&(*CONSTANT_1),&(v253_2));
    let v253_4: Space = if has_head(&(v253_3)) { singleton(&[]) } else { Space::new() };
    drop(v253_3);
    let v253_5: Space = subtract(&(*CONSTANT_0),&(v253_4));
    drop(v253_4);
    let v253_8: Space = if (v253_5).is_empty() { Space::new() } else {
      let v254_6: Path = concat_path(&(*p0),&(v252_20_head));
      let mut v254_7 = Space::new();
      let mut v254_7_cursor = (v252_20_tail).read_zipper();
      for v254_7_byte in v254_7_cursor.child_mask().iter() {
        v254_7_cursor.descend_to_byte(v254_7_byte);
        {
        let v254_7_tail = v254_7_cursor.fork_read_zipper();
        let v254_7_head = Path::from_slice(&[v254_7_byte]);
        let v255_2: Space = singleton(&(v254_7_head));
        let v255_3: Space = intersect(&(*CONSTANT_1),&(v255_2));
        let v255_4: Space = if has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
        drop(v255_3);
        let v255_5: Space = subtract(&(*CONSTANT_0),&(v255_4));
        drop(v255_4);
        let v255_8: Space = if (v255_5).is_empty() { Space::new() } else {
          let v256_6: Path = concat_path(&(v254_6),&(v254_7_head));
          let mut v256_7 = Space::new();
          let mut v256_7_cursor = (v254_7_tail).read_zipper();
          for v256_7_byte in v256_7_cursor.child_mask().iter() {
            v256_7_cursor.descend_to_byte(v256_7_byte);
            {
            let v256_7_tail = v256_7_cursor.fork_read_zipper();
            let v256_7_head = Path::from_slice(&[v256_7_byte]);
            let v257_2: Space = singleton(&(v256_7_head));
            let v257_3: Space = intersect(&(*CONSTANT_1),&(v257_2));
            let v257_4: Space = if has_head(&(v257_3)) { singleton(&[]) } else { Space::new() };
            drop(v257_3);
            let v257_5: Space = subtract(&(*CONSTANT_0),&(v257_4));
            drop(v257_4);
            let v257_8: Space = if (v257_5).is_empty() { Space::new() } else {
              let v258_6: Path = concat_path(&(v256_6),&(v256_7_head));
              let v258_7: Space = routine_28(c, &(v258_6), &(v256_7_tail).make_space());
              compose(&(v257_5),&(v258_7))
            };
            drop(v257_5);
            let v257_9: Space = intersect(&(*CONSTANT_1),&(v257_2));
            drop(v257_2);
            let v257_10: Space = if has_head(&(v257_9)) { singleton(&[]) } else { Space::new() };
            drop(v257_9);
            let v257_12: Space = if (v257_10).is_empty() { Space::new() } else {
              let v259_6: Path = concat_path(&(v256_6),&(v256_7_head));
              let v259_11: Space = routine_29(c, &(v259_6), &(v256_7_tail).make_space());
              drop(v259_6);
              compose(&(v257_10),&(v259_11))
            };
            drop(v257_10);
            let v257_13: Space = unite(&(v257_8),&(v257_12));
            v256_7.join_into((v257_13).clone());
            }
            v256_7_cursor.ascend(1);
          }
          drop(v256_7_cursor);
          compose(&(v255_5),&(v256_7))
        };
        drop(v255_5);
        let v255_9: Space = intersect(&(*CONSTANT_1),&(v255_2));
        drop(v255_2);
        let v255_10: Space = if has_head(&(v255_9)) { singleton(&[]) } else { Space::new() };
        drop(v255_9);
        let v255_12: Space = if (v255_10).is_empty() { Space::new() } else {
          let v260_6: Path = concat_path(&(v254_6),&(v254_7_head));
          let mut v260_11 = Space::new();
          let mut v260_11_cursor = (v254_7_tail).read_zipper();
          for v260_11_byte in v260_11_cursor.child_mask().iter() {
            v260_11_cursor.descend_to_byte(v260_11_byte);
            {
            let v260_11_tail = v260_11_cursor.fork_read_zipper();
            let v260_11_head = Path::from_slice(&[v260_11_byte]);
            let v261_2: Space = singleton(&(v260_11_head));
            let v261_3: Space = intersect(&(*CONSTANT_1),&(v261_2));
            let v261_4: Space = if has_head(&(v261_3)) { singleton(&[]) } else { Space::new() };
            drop(v261_3);
            let v261_5: Space = subtract(&(*CONSTANT_0),&(v261_4));
            drop(v261_4);
            let v261_8: Space = if (v261_5).is_empty() { Space::new() } else {
              let v262_6: Path = concat_path(&(v260_6),&(v260_11_head));
              let v262_7: Space = routine_28(c, &(v262_6), &(v260_11_tail).make_space());
              compose(&(v261_5),&(v262_7))
            };
            drop(v261_5);
            let v261_9: Space = intersect(&(*CONSTANT_1),&(v261_2));
            drop(v261_2);
            let v261_10: Space = if has_head(&(v261_9)) { singleton(&[]) } else { Space::new() };
            drop(v261_9);
            let v261_12: Space = if (v261_10).is_empty() { Space::new() } else {
              let v263_6: Path = concat_path(&(v260_6),&(v260_11_head));
              let v263_11: Space = routine_15(c, &(v263_6), &(v260_11_tail).make_space());
              drop(v263_6);
              compose(&(v261_10),&(v263_11))
            };
            drop(v261_10);
            let v261_13: Space = unite(&(v261_8),&(v261_12));
            v260_11.join_into((v261_13).clone());
            }
            v260_11_cursor.ascend(1);
          }
          drop(v260_11_cursor);
          drop(v260_6);
          compose(&(v255_10),&(v260_11))
        };
        drop(v255_10);
        let v255_13: Space = unite(&(v255_8),&(v255_12));
        v254_7.join_into((v255_13).clone());
        }
        v254_7_cursor.ascend(1);
      }
      drop(v254_7_cursor);
      compose(&(v253_5),&(v254_7))
    };
    drop(v253_5);
    let v253_9: Space = intersect(&(*CONSTANT_1),&(v253_2));
    drop(v253_2);
    let v253_10: Space = if has_head(&(v253_9)) { singleton(&[]) } else { Space::new() };
    drop(v253_9);
    let v253_12: Space = if (v253_10).is_empty() { Space::new() } else {
      let v264_6: Path = concat_path(&(*p0),&(v252_20_head));
      let mut v264_11 = Space::new();
      let mut v264_11_cursor = (v252_20_tail).read_zipper();
      for v264_11_byte in v264_11_cursor.child_mask().iter() {
        v264_11_cursor.descend_to_byte(v264_11_byte);
        {
        let v264_11_tail = v264_11_cursor.fork_read_zipper();
        let v264_11_head = Path::from_slice(&[v264_11_byte]);
        let v265_2: Space = singleton(&(v264_11_head));
        let v265_3: Space = intersect(&(*CONSTANT_1),&(v265_2));
        let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
        drop(v265_3);
        let v265_5: Space = subtract(&(*CONSTANT_0),&(v265_4));
        drop(v265_4);
        let v265_8: Space = if (v265_5).is_empty() { Space::new() } else {
          let v266_6: Path = concat_path(&(v264_6),&(v264_11_head));
          let mut v266_7 = Space::new();
          let mut v266_7_cursor = (v264_11_tail).read_zipper();
          for v266_7_byte in v266_7_cursor.child_mask().iter() {
            v266_7_cursor.descend_to_byte(v266_7_byte);
            {
            let v266_7_tail = v266_7_cursor.fork_read_zipper();
            let v266_7_head = Path::from_slice(&[v266_7_byte]);
            let v267_2: Space = singleton(&(v266_7_head));
            let v267_3: Space = intersect(&(*CONSTANT_1),&(v267_2));
            let v267_4: Space = if has_head(&(v267_3)) { singleton(&[]) } else { Space::new() };
            drop(v267_3);
            let v267_5: Space = subtract(&(*CONSTANT_0),&(v267_4));
            drop(v267_4);
            let v267_8: Space = if (v267_5).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v266_6),&(v266_7_head));
              let v268_7: Space = routine_28(c, &(v268_6), &(v266_7_tail).make_space());
              compose(&(v267_5),&(v268_7))
            };
            drop(v267_5);
            let v267_9: Space = intersect(&(*CONSTANT_1),&(v267_2));
            drop(v267_2);
            let v267_10: Space = if has_head(&(v267_9)) { singleton(&[]) } else { Space::new() };
            drop(v267_9);
            let v267_12: Space = if (v267_10).is_empty() { Space::new() } else {
              let v269_6: Path = concat_path(&(v266_6),&(v266_7_head));
              let v269_11: Space = routine_29(c, &(v269_6), &(v266_7_tail).make_space());
              drop(v269_6);
              compose(&(v267_10),&(v269_11))
            };
            drop(v267_10);
            let v267_13: Space = unite(&(v267_8),&(v267_12));
            v266_7.join_into((v267_13).clone());
            }
            v266_7_cursor.ascend(1);
          }
          drop(v266_7_cursor);
          drop(v266_6);
          compose(&(v265_5),&(v266_7))
        };
        drop(v265_5);
        let v265_9: Space = intersect(&(*CONSTANT_1),&(v265_2));
        drop(v265_2);
        let v265_10: Space = if has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
        drop(v265_9);
        let v265_11: Space = compose(&(v265_10),&(v264_11_tail));
        drop(v265_10);
        let v265_12: Space = unite(&(v265_8),&(v265_11));
        drop(v265_11);
        v264_11.join_into((v265_12).clone());
        }
        v264_11_cursor.ascend(1);
      }
      drop(v264_11_cursor);
      drop(v264_6);
      compose(&(v253_10),&(v264_11))
    };
    drop(v253_10);
    let v253_13: Space = unite(&(v253_8),&(v253_12));
    v252_20.join_into((v253_13).clone());
    }
    v252_20_cursor.ascend(1);
  }
  drop(v252_20_cursor);
  (v252_20).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v270_14 = Space::new();
  let mut v270_14_cursor = (*s0).read_zipper();
  for v270_14_byte in v270_14_cursor.child_mask().iter() {
    v270_14_cursor.descend_to_byte(v270_14_byte);
    {
    let v270_14_tail = v270_14_cursor.fork_read_zipper();
    let v270_14_head = Path::from_slice(&[v270_14_byte]);
    let v271_2: Space = singleton(&(v270_14_head));
    let v271_3: Space = intersect(&(*CONSTANT_1),&(v271_2));
    let v271_4: Space = if has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
    drop(v271_3);
    let v271_5: Space = subtract(&(*CONSTANT_0),&(v271_4));
    drop(v271_4);
    let v271_8: Space = if (v271_5).is_empty() { Space::new() } else {
      let v272_6: Path = concat_path(&(*p0),&(v270_14_head));
      let mut v272_7 = Space::new();
      let mut v272_7_cursor = (v270_14_tail).read_zipper();
      for v272_7_byte in v272_7_cursor.child_mask().iter() {
        v272_7_cursor.descend_to_byte(v272_7_byte);
        {
        let v272_7_tail = v272_7_cursor.fork_read_zipper();
        let v272_7_head = Path::from_slice(&[v272_7_byte]);
        let v273_2: Space = singleton(&(v272_7_head));
        let v273_3: Space = intersect(&(*CONSTANT_1),&(v273_2));
        let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
        drop(v273_3);
        let v273_5: Space = subtract(&(*CONSTANT_0),&(v273_4));
        drop(v273_4);
        let v273_8: Space = if (v273_5).is_empty() { Space::new() } else {
          let v274_6: Path = concat_path(&(v272_6),&(v272_7_head));
          let mut v274_7 = Space::new();
          let mut v274_7_cursor = (v272_7_tail).read_zipper();
          for v274_7_byte in v274_7_cursor.child_mask().iter() {
            v274_7_cursor.descend_to_byte(v274_7_byte);
            {
            let v274_7_tail = v274_7_cursor.fork_read_zipper();
            let v274_7_head = Path::from_slice(&[v274_7_byte]);
            let v275_2: Space = singleton(&(v274_7_head));
            let v275_3: Space = intersect(&(*CONSTANT_1),&(v275_2));
            let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
            drop(v275_3);
            let v275_5: Space = subtract(&(*CONSTANT_0),&(v275_4));
            drop(v275_4);
            let v275_8: Space = if (v275_5).is_empty() { Space::new() } else {
              let v276_6: Path = concat_path(&(v274_6),&(v274_7_head));
              let v276_7: Space = routine_28(c, &(v276_6), &(v274_7_tail).make_space());
              compose(&(v275_5),&(v276_7))
            };
            drop(v275_5);
            let v275_9: Space = intersect(&(*CONSTANT_1),&(v275_2));
            drop(v275_2);
            let v275_10: Space = if has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
            drop(v275_9);
            let v275_12: Space = if (v275_10).is_empty() { Space::new() } else {
              let v277_6: Path = concat_path(&(v274_6),&(v274_7_head));
              let v277_11: Space = routine_29(c, &(v277_6), &(v274_7_tail).make_space());
              drop(v277_6);
              compose(&(v275_10),&(v277_11))
            };
            drop(v275_10);
            let v275_13: Space = unite(&(v275_8),&(v275_12));
            v274_7.join_into((v275_13).clone());
            }
            v274_7_cursor.ascend(1);
          }
          drop(v274_7_cursor);
          compose(&(v273_5),&(v274_7))
        };
        drop(v273_5);
        let v273_9: Space = intersect(&(*CONSTANT_1),&(v273_2));
        drop(v273_2);
        let v273_10: Space = if has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
        drop(v273_9);
        let v273_12: Space = if (v273_10).is_empty() { Space::new() } else {
          let v278_6: Path = concat_path(&(v272_6),&(v272_7_head));
          let mut v278_11 = Space::new();
          let mut v278_11_cursor = (v272_7_tail).read_zipper();
          for v278_11_byte in v278_11_cursor.child_mask().iter() {
            v278_11_cursor.descend_to_byte(v278_11_byte);
            {
            let v278_11_tail = v278_11_cursor.fork_read_zipper();
            let v278_11_head = Path::from_slice(&[v278_11_byte]);
            let v279_2: Space = singleton(&(v278_11_head));
            let v279_3: Space = intersect(&(*CONSTANT_1),&(v279_2));
            let v279_4: Space = if has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
            drop(v279_3);
            let v279_5: Space = subtract(&(*CONSTANT_0),&(v279_4));
            drop(v279_4);
            let v279_8: Space = if (v279_5).is_empty() { Space::new() } else {
              let v280_6: Path = concat_path(&(v278_6),&(v278_11_head));
              let v280_7: Space = routine_28(c, &(v280_6), &(v278_11_tail).make_space());
              compose(&(v279_5),&(v280_7))
            };
            drop(v279_5);
            let v279_9: Space = intersect(&(*CONSTANT_1),&(v279_2));
            drop(v279_2);
            let v279_10: Space = if has_head(&(v279_9)) { singleton(&[]) } else { Space::new() };
            drop(v279_9);
            let v279_12: Space = if (v279_10).is_empty() { Space::new() } else {
              let v281_6: Path = concat_path(&(v278_6),&(v278_11_head));
              let v281_11: Space = routine_15(c, &(v281_6), &(v278_11_tail).make_space());
              drop(v281_6);
              compose(&(v279_10),&(v281_11))
            };
            drop(v279_10);
            let v279_13: Space = unite(&(v279_8),&(v279_12));
            v278_11.join_into((v279_13).clone());
            }
            v278_11_cursor.ascend(1);
          }
          drop(v278_11_cursor);
          drop(v278_6);
          compose(&(v273_10),&(v278_11))
        };
        drop(v273_10);
        let v273_13: Space = unite(&(v273_8),&(v273_12));
        v272_7.join_into((v273_13).clone());
        }
        v272_7_cursor.ascend(1);
      }
      drop(v272_7_cursor);
      drop(v272_6);
      compose(&(v271_5),&(v272_7))
    };
    drop(v271_5);
    let v271_9: Space = intersect(&(*CONSTANT_1),&(v271_2));
    drop(v271_2);
    let v271_10: Space = if has_head(&(v271_9)) { singleton(&[]) } else { Space::new() };
    drop(v271_9);
    let v271_11: Space = compose(&(v271_10),&(v270_14_tail));
    drop(v271_10);
    let v271_12: Space = unite(&(v271_8),&(v271_11));
    drop(v271_11);
    v270_14.join_into((v271_12).clone());
    }
    v270_14_cursor.ascend(1);
  }
  drop(v270_14_cursor);
  (v270_14).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v283_20 = Space::new();
  let mut v283_20_cursor = (*s0).read_zipper();
  for v283_20_byte in v283_20_cursor.child_mask().iter() {
    v283_20_cursor.descend_to_byte(v283_20_byte);
    {
    let v283_20_tail = v283_20_cursor.fork_read_zipper();
    let v283_20_head = Path::from_slice(&[v283_20_byte]);
    let v284_2: Space = singleton(&(v283_20_head));
    let v284_3: Space = intersect(&(*CONSTANT_1),&(v284_2));
    let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = subtract(&(*CONSTANT_0),&(v284_4));
    drop(v284_4);
    let v284_8: Space = if (v284_5).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&(v283_20_head));
      let mut v285_7 = Space::new();
      let mut v285_7_cursor = (v283_20_tail).read_zipper();
      for v285_7_byte in v285_7_cursor.child_mask().iter() {
        v285_7_cursor.descend_to_byte(v285_7_byte);
        {
        let v285_7_tail = v285_7_cursor.fork_read_zipper();
        let v285_7_head = Path::from_slice(&[v285_7_byte]);
        let v286_2: Space = singleton(&(v285_7_head));
        let v286_3: Space = intersect(&(*CONSTANT_1),&(v286_2));
        let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = subtract(&(*CONSTANT_0),&(v286_4));
        drop(v286_4);
        let v286_8: Space = if (v286_5).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v285_6),&(v285_7_head));
          let mut v287_7 = Space::new();
          let mut v287_7_cursor = (v285_7_tail).read_zipper();
          for v287_7_byte in v287_7_cursor.child_mask().iter() {
            v287_7_cursor.descend_to_byte(v287_7_byte);
            {
            let v287_7_tail = v287_7_cursor.fork_read_zipper();
            let v287_7_head = Path::from_slice(&[v287_7_byte]);
            let v288_2: Space = singleton(&(v287_7_head));
            let v288_3: Space = intersect(&(*CONSTANT_1),&(v288_2));
            let v288_4: Space = if has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = subtract(&(*CONSTANT_0),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (v288_5).is_empty() { Space::new() } else {
              let v289_6: Path = concat_path(&(v287_6),&(v287_7_head));
              let v289_7: Space = routine_30(c, &(v289_6), &(v287_7_tail).make_space());
              compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = intersect(&(*CONSTANT_1),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (v288_10).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v287_6),&(v287_7_head));
              let v290_11: Space = routine_31(c, &(v290_6), &(v287_7_tail).make_space());
              drop(v290_6);
              compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = unite(&(v288_8),&(v288_12));
            v287_7.join_into((v288_13).clone());
            }
            v287_7_cursor.ascend(1);
          }
          drop(v287_7_cursor);
          compose(&(v286_5),&(v287_7))
        };
        drop(v286_5);
        let v286_9: Space = intersect(&(*CONSTANT_1),&(v286_2));
        drop(v286_2);
        let v286_10: Space = if has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
        drop(v286_9);
        let v286_12: Space = if (v286_10).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v285_6),&(v285_7_head));
          let mut v291_11 = Space::new();
          let mut v291_11_cursor = (v285_7_tail).read_zipper();
          for v291_11_byte in v291_11_cursor.child_mask().iter() {
            v291_11_cursor.descend_to_byte(v291_11_byte);
            {
            let v291_11_tail = v291_11_cursor.fork_read_zipper();
            let v291_11_head = Path::from_slice(&[v291_11_byte]);
            let v292_2: Space = singleton(&(v291_11_head));
            let v292_3: Space = intersect(&(*CONSTANT_1),&(v292_2));
            let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
            drop(v292_3);
            let v292_5: Space = subtract(&(*CONSTANT_0),&(v292_4));
            drop(v292_4);
            let v292_8: Space = if (v292_5).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v291_6),&(v291_11_head));
              let v293_7: Space = routine_30(c, &(v293_6), &(v291_11_tail).make_space());
              compose(&(v292_5),&(v293_7))
            };
            drop(v292_5);
            let v292_9: Space = intersect(&(*CONSTANT_1),&(v292_2));
            drop(v292_2);
            let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
            drop(v292_9);
            let v292_12: Space = if (v292_10).is_empty() { Space::new() } else {
              let v294_6: Path = concat_path(&(v291_6),&(v291_11_head));
              let v294_11: Space = routine_12(c, &(v294_6), &(v291_11_tail).make_space());
              drop(v294_6);
              compose(&(v292_10),&(v294_11))
            };
            drop(v292_10);
            let v292_13: Space = unite(&(v292_8),&(v292_12));
            v291_11.join_into((v292_13).clone());
            }
            v291_11_cursor.ascend(1);
          }
          drop(v291_11_cursor);
          drop(v291_6);
          compose(&(v286_10),&(v291_11))
        };
        drop(v286_10);
        let v286_13: Space = unite(&(v286_8),&(v286_12));
        v285_7.join_into((v286_13).clone());
        }
        v285_7_cursor.ascend(1);
      }
      drop(v285_7_cursor);
      compose(&(v284_5),&(v285_7))
    };
    drop(v284_5);
    let v284_9: Space = intersect(&(*CONSTANT_1),&(v284_2));
    drop(v284_2);
    let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
    drop(v284_9);
    let v284_12: Space = if (v284_10).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&(v283_20_head));
      let mut v295_11 = Space::new();
      let mut v295_11_cursor = (v283_20_tail).read_zipper();
      for v295_11_byte in v295_11_cursor.child_mask().iter() {
        v295_11_cursor.descend_to_byte(v295_11_byte);
        {
        let v295_11_tail = v295_11_cursor.fork_read_zipper();
        let v295_11_head = Path::from_slice(&[v295_11_byte]);
        let v296_2: Space = singleton(&(v295_11_head));
        let v296_3: Space = intersect(&(*CONSTANT_1),&(v296_2));
        let v296_4: Space = if has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = subtract(&(*CONSTANT_0),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (v296_5).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&(v295_11_head));
          let mut v297_7 = Space::new();
          let mut v297_7_cursor = (v295_11_tail).read_zipper();
          for v297_7_byte in v297_7_cursor.child_mask().iter() {
            v297_7_cursor.descend_to_byte(v297_7_byte);
            {
            let v297_7_tail = v297_7_cursor.fork_read_zipper();
            let v297_7_head = Path::from_slice(&[v297_7_byte]);
            let v298_2: Space = singleton(&(v297_7_head));
            let v298_3: Space = intersect(&(*CONSTANT_1),&(v298_2));
            let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = subtract(&(*CONSTANT_0),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (v298_5).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&(v297_7_head));
              let v299_7: Space = routine_30(c, &(v299_6), &(v297_7_tail).make_space());
              compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = intersect(&(*CONSTANT_1),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (v298_10).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&(v297_7_head));
              let v300_11: Space = routine_31(c, &(v300_6), &(v297_7_tail).make_space());
              drop(v300_6);
              compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = unite(&(v298_8),&(v298_12));
            v297_7.join_into((v298_13).clone());
            }
            v297_7_cursor.ascend(1);
          }
          drop(v297_7_cursor);
          drop(v297_6);
          compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = intersect(&(*CONSTANT_1),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_11: Space = compose(&(v296_10),&(v295_11_tail));
        drop(v296_10);
        let v296_12: Space = unite(&(v296_8),&(v296_11));
        drop(v296_11);
        v295_11.join_into((v296_12).clone());
        }
        v295_11_cursor.ascend(1);
      }
      drop(v295_11_cursor);
      drop(v295_6);
      compose(&(v284_10),&(v295_11))
    };
    drop(v284_10);
    let v284_13: Space = unite(&(v284_8),&(v284_12));
    v283_20.join_into((v284_13).clone());
    }
    v283_20_cursor.ascend(1);
  }
  drop(v283_20_cursor);
  (v283_20).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v301_14 = Space::new();
  let mut v301_14_cursor = (*s0).read_zipper();
  for v301_14_byte in v301_14_cursor.child_mask().iter() {
    v301_14_cursor.descend_to_byte(v301_14_byte);
    {
    let v301_14_tail = v301_14_cursor.fork_read_zipper();
    let v301_14_head = Path::from_slice(&[v301_14_byte]);
    let v302_2: Space = singleton(&(v301_14_head));
    let v302_3: Space = intersect(&(*CONSTANT_1),&(v302_2));
    let v302_4: Space = if has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
    drop(v302_3);
    let v302_5: Space = subtract(&(*CONSTANT_0),&(v302_4));
    drop(v302_4);
    let v302_8: Space = if (v302_5).is_empty() { Space::new() } else {
      let v303_6: Path = concat_path(&(*p0),&(v301_14_head));
      let mut v303_7 = Space::new();
      let mut v303_7_cursor = (v301_14_tail).read_zipper();
      for v303_7_byte in v303_7_cursor.child_mask().iter() {
        v303_7_cursor.descend_to_byte(v303_7_byte);
        {
        let v303_7_tail = v303_7_cursor.fork_read_zipper();
        let v303_7_head = Path::from_slice(&[v303_7_byte]);
        let v304_2: Space = singleton(&(v303_7_head));
        let v304_3: Space = intersect(&(*CONSTANT_1),&(v304_2));
        let v304_4: Space = if has_head(&(v304_3)) { singleton(&[]) } else { Space::new() };
        drop(v304_3);
        let v304_5: Space = subtract(&(*CONSTANT_0),&(v304_4));
        drop(v304_4);
        let v304_8: Space = if (v304_5).is_empty() { Space::new() } else {
          let v305_6: Path = concat_path(&(v303_6),&(v303_7_head));
          let mut v305_7 = Space::new();
          let mut v305_7_cursor = (v303_7_tail).read_zipper();
          for v305_7_byte in v305_7_cursor.child_mask().iter() {
            v305_7_cursor.descend_to_byte(v305_7_byte);
            {
            let v305_7_tail = v305_7_cursor.fork_read_zipper();
            let v305_7_head = Path::from_slice(&[v305_7_byte]);
            let v306_2: Space = singleton(&(v305_7_head));
            let v306_3: Space = intersect(&(*CONSTANT_1),&(v306_2));
            let v306_4: Space = if has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
            drop(v306_3);
            let v306_5: Space = subtract(&(*CONSTANT_0),&(v306_4));
            drop(v306_4);
            let v306_8: Space = if (v306_5).is_empty() { Space::new() } else {
              let v307_6: Path = concat_path(&(v305_6),&(v305_7_head));
              let v307_7: Space = routine_30(c, &(v307_6), &(v305_7_tail).make_space());
              compose(&(v306_5),&(v307_7))
            };
            drop(v306_5);
            let v306_9: Space = intersect(&(*CONSTANT_1),&(v306_2));
            drop(v306_2);
            let v306_10: Space = if has_head(&(v306_9)) { singleton(&[]) } else { Space::new() };
            drop(v306_9);
            let v306_12: Space = if (v306_10).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v305_6),&(v305_7_head));
              let v308_11: Space = routine_31(c, &(v308_6), &(v305_7_tail).make_space());
              drop(v308_6);
              compose(&(v306_10),&(v308_11))
            };
            drop(v306_10);
            let v306_13: Space = unite(&(v306_8),&(v306_12));
            v305_7.join_into((v306_13).clone());
            }
            v305_7_cursor.ascend(1);
          }
          drop(v305_7_cursor);
          compose(&(v304_5),&(v305_7))
        };
        drop(v304_5);
        let v304_9: Space = intersect(&(*CONSTANT_1),&(v304_2));
        drop(v304_2);
        let v304_10: Space = if has_head(&(v304_9)) { singleton(&[]) } else { Space::new() };
        drop(v304_9);
        let v304_12: Space = if (v304_10).is_empty() { Space::new() } else {
          let v309_6: Path = concat_path(&(v303_6),&(v303_7_head));
          let mut v309_11 = Space::new();
          let mut v309_11_cursor = (v303_7_tail).read_zipper();
          for v309_11_byte in v309_11_cursor.child_mask().iter() {
            v309_11_cursor.descend_to_byte(v309_11_byte);
            {
            let v309_11_tail = v309_11_cursor.fork_read_zipper();
            let v309_11_head = Path::from_slice(&[v309_11_byte]);
            let v310_2: Space = singleton(&(v309_11_head));
            let v310_3: Space = intersect(&(*CONSTANT_1),&(v310_2));
            let v310_4: Space = if has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
            drop(v310_3);
            let v310_5: Space = subtract(&(*CONSTANT_0),&(v310_4));
            drop(v310_4);
            let v310_8: Space = if (v310_5).is_empty() { Space::new() } else {
              let v311_6: Path = concat_path(&(v309_6),&(v309_11_head));
              let v311_7: Space = routine_30(c, &(v311_6), &(v309_11_tail).make_space());
              compose(&(v310_5),&(v311_7))
            };
            drop(v310_5);
            let v310_9: Space = intersect(&(*CONSTANT_1),&(v310_2));
            drop(v310_2);
            let v310_10: Space = if has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
            drop(v310_9);
            let v310_12: Space = if (v310_10).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v309_6),&(v309_11_head));
              let v312_11: Space = routine_12(c, &(v312_6), &(v309_11_tail).make_space());
              drop(v312_6);
              compose(&(v310_10),&(v312_11))
            };
            drop(v310_10);
            let v310_13: Space = unite(&(v310_8),&(v310_12));
            v309_11.join_into((v310_13).clone());
            }
            v309_11_cursor.ascend(1);
          }
          drop(v309_11_cursor);
          drop(v309_6);
          compose(&(v304_10),&(v309_11))
        };
        drop(v304_10);
        let v304_13: Space = unite(&(v304_8),&(v304_12));
        v303_7.join_into((v304_13).clone());
        }
        v303_7_cursor.ascend(1);
      }
      drop(v303_7_cursor);
      drop(v303_6);
      compose(&(v302_5),&(v303_7))
    };
    drop(v302_5);
    let v302_9: Space = intersect(&(*CONSTANT_1),&(v302_2));
    drop(v302_2);
    let v302_10: Space = if has_head(&(v302_9)) { singleton(&[]) } else { Space::new() };
    drop(v302_9);
    let v302_11: Space = compose(&(v302_10),&(v301_14_tail));
    drop(v302_10);
    let v302_12: Space = unite(&(v302_8),&(v302_11));
    drop(v302_11);
    v301_14.join_into((v302_12).clone());
    }
    v301_14_cursor.ascend(1);
  }
  drop(v301_14_cursor);
  (v301_14).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v313_20 = Space::new();
  let mut v313_20_cursor = (*s0).read_zipper();
  for v313_20_byte in v313_20_cursor.child_mask().iter() {
    v313_20_cursor.descend_to_byte(v313_20_byte);
    {
    let v313_20_tail = v313_20_cursor.fork_read_zipper();
    let v313_20_head = Path::from_slice(&[v313_20_byte]);
    let v314_2: Space = singleton(&(v313_20_head));
    let v314_3: Space = intersect(&(*CONSTANT_1),&(v314_2));
    let v314_4: Space = if has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
    drop(v314_3);
    let v314_5: Space = subtract(&(*CONSTANT_0),&(v314_4));
    drop(v314_4);
    let v314_8: Space = if (v314_5).is_empty() { Space::new() } else {
      let v315_6: Path = concat_path(&(*p0),&(v313_20_head));
      let mut v315_7 = Space::new();
      let mut v315_7_cursor = (v313_20_tail).read_zipper();
      for v315_7_byte in v315_7_cursor.child_mask().iter() {
        v315_7_cursor.descend_to_byte(v315_7_byte);
        {
        let v315_7_tail = v315_7_cursor.fork_read_zipper();
        let v315_7_head = Path::from_slice(&[v315_7_byte]);
        let v316_2: Space = singleton(&(v315_7_head));
        let v316_3: Space = intersect(&(*CONSTANT_1),&(v316_2));
        let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
        drop(v316_3);
        let v316_5: Space = subtract(&(*CONSTANT_0),&(v316_4));
        drop(v316_4);
        let v316_8: Space = if (v316_5).is_empty() { Space::new() } else {
          let v317_6: Path = concat_path(&(v315_6),&(v315_7_head));
          let mut v317_7 = Space::new();
          let mut v317_7_cursor = (v315_7_tail).read_zipper();
          for v317_7_byte in v317_7_cursor.child_mask().iter() {
            v317_7_cursor.descend_to_byte(v317_7_byte);
            {
            let v317_7_tail = v317_7_cursor.fork_read_zipper();
            let v317_7_head = Path::from_slice(&[v317_7_byte]);
            let v318_2: Space = singleton(&(v317_7_head));
            let v318_3: Space = intersect(&(*CONSTANT_1),&(v318_2));
            let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
            drop(v318_3);
            let v318_5: Space = subtract(&(*CONSTANT_0),&(v318_4));
            drop(v318_4);
            let v318_8: Space = if (v318_5).is_empty() { Space::new() } else {
              let v319_6: Path = concat_path(&(v317_6),&(v317_7_head));
              let v319_7: Space = routine_32(c, &(v319_6), &(v317_7_tail).make_space());
              compose(&(v318_5),&(v319_7))
            };
            drop(v318_5);
            let v318_9: Space = intersect(&(*CONSTANT_1),&(v318_2));
            drop(v318_2);
            let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
            drop(v318_9);
            let v318_12: Space = if (v318_10).is_empty() { Space::new() } else {
              let v320_6: Path = concat_path(&(v317_6),&(v317_7_head));
              let v320_11: Space = routine_33(c, &(v320_6), &(v317_7_tail).make_space());
              drop(v320_6);
              compose(&(v318_10),&(v320_11))
            };
            drop(v318_10);
            let v318_13: Space = unite(&(v318_8),&(v318_12));
            v317_7.join_into((v318_13).clone());
            }
            v317_7_cursor.ascend(1);
          }
          drop(v317_7_cursor);
          compose(&(v316_5),&(v317_7))
        };
        drop(v316_5);
        let v316_9: Space = intersect(&(*CONSTANT_1),&(v316_2));
        drop(v316_2);
        let v316_10: Space = if has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
        drop(v316_9);
        let v316_12: Space = if (v316_10).is_empty() { Space::new() } else {
          let v321_6: Path = concat_path(&(v315_6),&(v315_7_head));
          let mut v321_11 = Space::new();
          let mut v321_11_cursor = (v315_7_tail).read_zipper();
          for v321_11_byte in v321_11_cursor.child_mask().iter() {
            v321_11_cursor.descend_to_byte(v321_11_byte);
            {
            let v321_11_tail = v321_11_cursor.fork_read_zipper();
            let v321_11_head = Path::from_slice(&[v321_11_byte]);
            let v322_2: Space = singleton(&(v321_11_head));
            let v322_3: Space = intersect(&(*CONSTANT_1),&(v322_2));
            let v322_4: Space = if has_head(&(v322_3)) { singleton(&[]) } else { Space::new() };
            drop(v322_3);
            let v322_5: Space = subtract(&(*CONSTANT_0),&(v322_4));
            drop(v322_4);
            let v322_8: Space = if (v322_5).is_empty() { Space::new() } else {
              let v323_6: Path = concat_path(&(v321_6),&(v321_11_head));
              let v323_7: Space = routine_32(c, &(v323_6), &(v321_11_tail).make_space());
              compose(&(v322_5),&(v323_7))
            };
            drop(v322_5);
            let v322_9: Space = intersect(&(*CONSTANT_1),&(v322_2));
            drop(v322_2);
            let v322_10: Space = if has_head(&(v322_9)) { singleton(&[]) } else { Space::new() };
            drop(v322_9);
            let v322_12: Space = if (v322_10).is_empty() { Space::new() } else {
              let v324_6: Path = concat_path(&(v321_6),&(v321_11_head));
              let v324_11: Space = routine_15(c, &(v324_6), &(v321_11_tail).make_space());
              drop(v324_6);
              compose(&(v322_10),&(v324_11))
            };
            drop(v322_10);
            let v322_13: Space = unite(&(v322_8),&(v322_12));
            v321_11.join_into((v322_13).clone());
            }
            v321_11_cursor.ascend(1);
          }
          drop(v321_11_cursor);
          drop(v321_6);
          compose(&(v316_10),&(v321_11))
        };
        drop(v316_10);
        let v316_13: Space = unite(&(v316_8),&(v316_12));
        v315_7.join_into((v316_13).clone());
        }
        v315_7_cursor.ascend(1);
      }
      drop(v315_7_cursor);
      compose(&(v314_5),&(v315_7))
    };
    drop(v314_5);
    let v314_9: Space = intersect(&(*CONSTANT_1),&(v314_2));
    drop(v314_2);
    let v314_10: Space = if has_head(&(v314_9)) { singleton(&[]) } else { Space::new() };
    drop(v314_9);
    let v314_12: Space = if (v314_10).is_empty() { Space::new() } else {
      let v325_6: Path = concat_path(&(*p0),&(v313_20_head));
      let mut v325_11 = Space::new();
      let mut v325_11_cursor = (v313_20_tail).read_zipper();
      for v325_11_byte in v325_11_cursor.child_mask().iter() {
        v325_11_cursor.descend_to_byte(v325_11_byte);
        {
        let v325_11_tail = v325_11_cursor.fork_read_zipper();
        let v325_11_head = Path::from_slice(&[v325_11_byte]);
        let v326_2: Space = singleton(&(v325_11_head));
        let v326_3: Space = intersect(&(*CONSTANT_1),&(v326_2));
        let v326_4: Space = if has_head(&(v326_3)) { singleton(&[]) } else { Space::new() };
        drop(v326_3);
        let v326_5: Space = subtract(&(*CONSTANT_0),&(v326_4));
        drop(v326_4);
        let v326_8: Space = if (v326_5).is_empty() { Space::new() } else {
          let v327_6: Path = concat_path(&(v325_6),&(v325_11_head));
          let mut v327_7 = Space::new();
          let mut v327_7_cursor = (v325_11_tail).read_zipper();
          for v327_7_byte in v327_7_cursor.child_mask().iter() {
            v327_7_cursor.descend_to_byte(v327_7_byte);
            {
            let v327_7_tail = v327_7_cursor.fork_read_zipper();
            let v327_7_head = Path::from_slice(&[v327_7_byte]);
            let v328_2: Space = singleton(&(v327_7_head));
            let v328_3: Space = intersect(&(*CONSTANT_1),&(v328_2));
            let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
            drop(v328_3);
            let v328_5: Space = subtract(&(*CONSTANT_0),&(v328_4));
            drop(v328_4);
            let v328_8: Space = if (v328_5).is_empty() { Space::new() } else {
              let v329_6: Path = concat_path(&(v327_6),&(v327_7_head));
              let v329_7: Space = routine_32(c, &(v329_6), &(v327_7_tail).make_space());
              compose(&(v328_5),&(v329_7))
            };
            drop(v328_5);
            let v328_9: Space = intersect(&(*CONSTANT_1),&(v328_2));
            drop(v328_2);
            let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
            drop(v328_9);
            let v328_12: Space = if (v328_10).is_empty() { Space::new() } else {
              let v330_6: Path = concat_path(&(v327_6),&(v327_7_head));
              let v330_11: Space = routine_33(c, &(v330_6), &(v327_7_tail).make_space());
              drop(v330_6);
              compose(&(v328_10),&(v330_11))
            };
            drop(v328_10);
            let v328_13: Space = unite(&(v328_8),&(v328_12));
            v327_7.join_into((v328_13).clone());
            }
            v327_7_cursor.ascend(1);
          }
          drop(v327_7_cursor);
          drop(v327_6);
          compose(&(v326_5),&(v327_7))
        };
        drop(v326_5);
        let v326_9: Space = intersect(&(*CONSTANT_1),&(v326_2));
        drop(v326_2);
        let v326_10: Space = if has_head(&(v326_9)) { singleton(&[]) } else { Space::new() };
        drop(v326_9);
        let v326_11: Space = compose(&(v326_10),&(v325_11_tail));
        drop(v326_10);
        let v326_12: Space = unite(&(v326_8),&(v326_11));
        drop(v326_11);
        v325_11.join_into((v326_12).clone());
        }
        v325_11_cursor.ascend(1);
      }
      drop(v325_11_cursor);
      drop(v325_6);
      compose(&(v314_10),&(v325_11))
    };
    drop(v314_10);
    let v314_13: Space = unite(&(v314_8),&(v314_12));
    v313_20.join_into((v314_13).clone());
    }
    v313_20_cursor.ascend(1);
  }
  drop(v313_20_cursor);
  (v313_20).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v331_14 = Space::new();
  let mut v331_14_cursor = (*s0).read_zipper();
  for v331_14_byte in v331_14_cursor.child_mask().iter() {
    v331_14_cursor.descend_to_byte(v331_14_byte);
    {
    let v331_14_tail = v331_14_cursor.fork_read_zipper();
    let v331_14_head = Path::from_slice(&[v331_14_byte]);
    let v332_2: Space = singleton(&(v331_14_head));
    let v332_3: Space = intersect(&(*CONSTANT_1),&(v332_2));
    let v332_4: Space = if has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
    drop(v332_3);
    let v332_5: Space = subtract(&(*CONSTANT_0),&(v332_4));
    drop(v332_4);
    let v332_8: Space = if (v332_5).is_empty() { Space::new() } else {
      let v333_6: Path = concat_path(&(*p0),&(v331_14_head));
      let mut v333_7 = Space::new();
      let mut v333_7_cursor = (v331_14_tail).read_zipper();
      for v333_7_byte in v333_7_cursor.child_mask().iter() {
        v333_7_cursor.descend_to_byte(v333_7_byte);
        {
        let v333_7_tail = v333_7_cursor.fork_read_zipper();
        let v333_7_head = Path::from_slice(&[v333_7_byte]);
        let v334_2: Space = singleton(&(v333_7_head));
        let v334_3: Space = intersect(&(*CONSTANT_1),&(v334_2));
        let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
        drop(v334_3);
        let v334_5: Space = subtract(&(*CONSTANT_0),&(v334_4));
        drop(v334_4);
        let v334_8: Space = if (v334_5).is_empty() { Space::new() } else {
          let v335_6: Path = concat_path(&(v333_6),&(v333_7_head));
          let mut v335_7 = Space::new();
          let mut v335_7_cursor = (v333_7_tail).read_zipper();
          for v335_7_byte in v335_7_cursor.child_mask().iter() {
            v335_7_cursor.descend_to_byte(v335_7_byte);
            {
            let v335_7_tail = v335_7_cursor.fork_read_zipper();
            let v335_7_head = Path::from_slice(&[v335_7_byte]);
            let v336_2: Space = singleton(&(v335_7_head));
            let v336_3: Space = intersect(&(*CONSTANT_1),&(v336_2));
            let v336_4: Space = if has_head(&(v336_3)) { singleton(&[]) } else { Space::new() };
            drop(v336_3);
            let v336_5: Space = subtract(&(*CONSTANT_0),&(v336_4));
            drop(v336_4);
            let v336_8: Space = if (v336_5).is_empty() { Space::new() } else {
              let v337_6: Path = concat_path(&(v335_6),&(v335_7_head));
              let v337_7: Space = routine_32(c, &(v337_6), &(v335_7_tail).make_space());
              compose(&(v336_5),&(v337_7))
            };
            drop(v336_5);
            let v336_9: Space = intersect(&(*CONSTANT_1),&(v336_2));
            drop(v336_2);
            let v336_10: Space = if has_head(&(v336_9)) { singleton(&[]) } else { Space::new() };
            drop(v336_9);
            let v336_12: Space = if (v336_10).is_empty() { Space::new() } else {
              let v338_6: Path = concat_path(&(v335_6),&(v335_7_head));
              let v338_11: Space = routine_33(c, &(v338_6), &(v335_7_tail).make_space());
              drop(v338_6);
              compose(&(v336_10),&(v338_11))
            };
            drop(v336_10);
            let v336_13: Space = unite(&(v336_8),&(v336_12));
            v335_7.join_into((v336_13).clone());
            }
            v335_7_cursor.ascend(1);
          }
          drop(v335_7_cursor);
          compose(&(v334_5),&(v335_7))
        };
        drop(v334_5);
        let v334_9: Space = intersect(&(*CONSTANT_1),&(v334_2));
        drop(v334_2);
        let v334_10: Space = if has_head(&(v334_9)) { singleton(&[]) } else { Space::new() };
        drop(v334_9);
        let v334_12: Space = if (v334_10).is_empty() { Space::new() } else {
          let v339_6: Path = concat_path(&(v333_6),&(v333_7_head));
          let mut v339_11 = Space::new();
          let mut v339_11_cursor = (v333_7_tail).read_zipper();
          for v339_11_byte in v339_11_cursor.child_mask().iter() {
            v339_11_cursor.descend_to_byte(v339_11_byte);
            {
            let v339_11_tail = v339_11_cursor.fork_read_zipper();
            let v339_11_head = Path::from_slice(&[v339_11_byte]);
            let v340_2: Space = singleton(&(v339_11_head));
            let v340_3: Space = intersect(&(*CONSTANT_1),&(v340_2));
            let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
            drop(v340_3);
            let v340_5: Space = subtract(&(*CONSTANT_0),&(v340_4));
            drop(v340_4);
            let v340_8: Space = if (v340_5).is_empty() { Space::new() } else {
              let v341_6: Path = concat_path(&(v339_6),&(v339_11_head));
              let v341_7: Space = routine_32(c, &(v341_6), &(v339_11_tail).make_space());
              compose(&(v340_5),&(v341_7))
            };
            drop(v340_5);
            let v340_9: Space = intersect(&(*CONSTANT_1),&(v340_2));
            drop(v340_2);
            let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
            drop(v340_9);
            let v340_12: Space = if (v340_10).is_empty() { Space::new() } else {
              let v342_6: Path = concat_path(&(v339_6),&(v339_11_head));
              let v342_11: Space = routine_15(c, &(v342_6), &(v339_11_tail).make_space());
              drop(v342_6);
              compose(&(v340_10),&(v342_11))
            };
            drop(v340_10);
            let v340_13: Space = unite(&(v340_8),&(v340_12));
            v339_11.join_into((v340_13).clone());
            }
            v339_11_cursor.ascend(1);
          }
          drop(v339_11_cursor);
          drop(v339_6);
          compose(&(v334_10),&(v339_11))
        };
        drop(v334_10);
        let v334_13: Space = unite(&(v334_8),&(v334_12));
        v333_7.join_into((v334_13).clone());
        }
        v333_7_cursor.ascend(1);
      }
      drop(v333_7_cursor);
      drop(v333_6);
      compose(&(v332_5),&(v333_7))
    };
    drop(v332_5);
    let v332_9: Space = intersect(&(*CONSTANT_1),&(v332_2));
    drop(v332_2);
    let v332_10: Space = if has_head(&(v332_9)) { singleton(&[]) } else { Space::new() };
    drop(v332_9);
    let v332_11: Space = compose(&(v332_10),&(v331_14_tail));
    drop(v332_10);
    let v332_12: Space = unite(&(v332_8),&(v332_11));
    drop(v332_11);
    v331_14.join_into((v332_12).clone());
    }
    v331_14_cursor.ascend(1);
  }
  drop(v331_14_cursor);
  (v331_14).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v343_10: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v343_11: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v343_12: Space = unwrap(&(v343_11),&(*p0));
  let v343_13: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v343_20 = Space::new();
  let mut v343_20_cursor = (*s0).read_zipper();
  for v343_20_byte in v343_20_cursor.child_mask().iter() {
    v343_20_cursor.descend_to_byte(v343_20_byte);
    {
    let v343_20_tail = v343_20_cursor.fork_read_zipper();
    let v343_20_head = Path::from_slice(&[v343_20_byte]);
    let v344_2: Space = singleton(&(v343_20_head));
    let v344_3: Space = intersect(&(*CONSTANT_1),&(v344_2));
    let v344_4: Space = if has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
    drop(v344_3);
    let v344_5: Space = subtract(&(*CONSTANT_0),&(v344_4));
    drop(v344_4);
    let mut v344_6 = Space::new();
    let mut v344_6_cursor = (v343_20_tail).read_zipper();
    for v344_6_byte in v344_6_cursor.child_mask().iter() {
      v344_6_cursor.descend_to_byte(v344_6_byte);
      {
      let v344_6_tail = v344_6_cursor.fork_read_zipper();
      let v344_6_head = Path::from_slice(&[v344_6_byte]);
      let v345_2: Space = Space::new();
      v344_6.join_into((v345_2).clone());
      }
      v344_6_cursor.ascend(1);
    }
    drop(v344_6_cursor);
    let v344_7: Space = compose(&(v344_5),&(v344_6));
    drop(v344_5);
    drop(v344_6);
    let v344_8: Space = intersect(&(*CONSTANT_1),&(v344_2));
    drop(v344_2);
    let v344_9: Space = if has_head(&(v344_8)) { singleton(&[]) } else { Space::new() };
    drop(v344_8);
    let v344_13: Space = if (v344_9).is_empty() { Space::new() } else {
      let v346_10: Space = unwrap(&(v343_12),&(v343_20_head));
      let v346_11: Path = concat_path(&(*p0),&(v343_20_head));
      let mut v346_12 = Space::new();
      let mut v346_12_cursor = (v343_20_tail).read_zipper();
      for v346_12_byte in v346_12_cursor.child_mask().iter() {
        v346_12_cursor.descend_to_byte(v346_12_byte);
        {
        let v346_12_tail = v346_12_cursor.fork_read_zipper();
        let v346_12_head = Path::from_slice(&[v346_12_byte]);
        let v347_2: Space = singleton(&(v346_12_head));
        let v347_3: Space = intersect(&(*CONSTANT_1),&(v347_2));
        drop(v347_2);
        let v347_4: Space = if has_head(&(v347_3)) { singleton(&[]) } else { Space::new() };
        drop(v347_3);
        let v347_12: Space = if (v347_4).is_empty() { Space::new() } else {
          let v348_5: Space = unwrap(&(v346_10),&(v346_12_head));
          let v348_6: Space = restrict_to(&(v343_11),&(v348_5));
          let mut v348_7 = Space::new();
          let mut v348_7_cursor = (v348_6).read_zipper();
          for v348_7_byte in v348_7_cursor.child_mask().iter() {
            v348_7_cursor.descend_to_byte(v348_7_byte);
            {
            let v348_7_tail = v348_7_cursor.fork_read_zipper();
            let v348_7_head = Path::from_slice(&[v348_7_byte]);
            let v349_2: Space = singleton(&(v348_7_head));
            let v349_3: Space = intersect(&(*CONSTANT_1),&(v349_2));
            let v349_4: Space = if has_head(&(v349_3)) { singleton(&[]) } else { Space::new() };
            drop(v349_3);
            let v349_5: Space = subtract(&(*CONSTANT_0),&(v349_4));
            drop(v349_4);
            let v349_7: Space = if (v349_5).is_empty() { Space::new() } else {
              let v350_6: Space = routine_6(c, &(v348_7_head), &(v348_7_tail).make_space());
              compose(&(v349_5),&(v350_6))
            };
            drop(v349_5);
            let v349_8: Space = intersect(&(*CONSTANT_1),&(v349_2));
            drop(v349_2);
            let v349_9: Space = if has_head(&(v349_8)) { singleton(&[]) } else { Space::new() };
            drop(v349_8);
            let v349_11: Space = if (v349_9).is_empty() { Space::new() } else {
              let v351_10: Space = routine_7(c, &(v348_7_head), &(v348_7_tail).make_space());
              compose(&(v349_9),&(v351_10))
            };
            drop(v349_9);
            let v349_12: Space = unite(&(v349_7),&(v349_11));
            v348_7.join_into((v349_12).clone());
            }
            v348_7_cursor.ascend(1);
          }
          drop(v348_7_cursor);
          drop(v348_6);
          let v348_8: Space = restrict_to(&(v343_10),&(v348_7));
          let mut v348_9 = Space::new();
          let mut v348_9_cursor = (v348_8).read_zipper();
          for v348_9_byte in v348_9_cursor.child_mask().iter() {
            v348_9_cursor.descend_to_byte(v348_9_byte);
            {
            let v348_9_tail = v348_9_cursor.fork_read_zipper();
            let v348_9_head = Path::from_slice(&[v348_9_byte]);
            let v352_2: Space = singleton(&(v348_9_head));
            let v352_3: Space = intersect(&(*CONSTANT_1),&(v352_2));
            let v352_4: Space = if has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
            drop(v352_3);
            let v352_5: Space = subtract(&(*CONSTANT_0),&(v352_4));
            drop(v352_4);
            let v352_7: Space = if (v352_5).is_empty() { Space::new() } else {
              let v353_6: Space = routine_8(c, &(v348_9_head), &(v348_9_tail).make_space());
              compose(&(v352_5),&(v353_6))
            };
            drop(v352_5);
            let v352_8: Space = intersect(&(*CONSTANT_1),&(v352_2));
            drop(v352_2);
            let v352_9: Space = if has_head(&(v352_8)) { singleton(&[]) } else { Space::new() };
            drop(v352_8);
            let v352_11: Space = if (v352_9).is_empty() { Space::new() } else {
              let v354_10: Space = routine_9(c, &(v348_9_head), &(v348_9_tail).make_space());
              compose(&(v352_9),&(v354_10))
            };
            drop(v352_9);
            let v352_12: Space = unite(&(v352_7),&(v352_11));
            v348_9.join_into((v352_12).clone());
            }
            v348_9_cursor.ascend(1);
          }
          drop(v348_9_cursor);
          let v348_10: Space = subtract(&(v348_9),&(v348_5));
          drop(v348_5);
          let v348_11: Space = intersect(&(v348_10),&(v343_13));
          compose(&(v347_4),&(v348_11))
        };
        drop(v347_4);
        let v347_13: Path = concat_path(&(v346_11),&(v346_12_head));
        let v347_14: Space = wrap(&(v347_12),&(v347_13));
        drop(v347_13);
        v346_12.join_into((v347_14).clone());
        }
        v346_12_cursor.ascend(1);
      }
      drop(v346_12_cursor);
      drop(v346_10);
      drop(v346_11);
      compose(&(v344_9),&(v346_12))
    };
    drop(v344_9);
    let v344_14: Space = unite(&(v344_7),&(v344_13));
    drop(v344_7);
    v343_20.join_into((v344_14).clone());
    }
    v343_20_cursor.ascend(1);
  }
  drop(v343_20_cursor);
  drop(v343_10);
  drop(v343_11);
  drop(v343_12);
  drop(v343_13);
  (v343_20).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v355_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v355_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v355_10: Space = unwrap(&(v355_9),&(*p0));
  let v355_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v355_31 = Space::new();
  let mut v355_31_cursor = (*s0).read_zipper();
  for v355_31_byte in v355_31_cursor.child_mask().iter() {
    v355_31_cursor.descend_to_byte(v355_31_byte);
    {
    let v355_31_tail = v355_31_cursor.fork_read_zipper();
    let v355_31_head = Path::from_slice(&[v355_31_byte]);
    let v356_2: Space = singleton(&(v355_31_head));
    let v356_3: Space = intersect(&(*CONSTANT_1),&(v356_2));
    let v356_4: Space = if has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
    drop(v356_3);
    let v356_5: Space = subtract(&(*CONSTANT_0),&(v356_4));
    drop(v356_4);
    let mut v356_6 = Space::new();
    let mut v356_6_cursor = (v355_31_tail).read_zipper();
    for v356_6_byte in v356_6_cursor.child_mask().iter() {
      v356_6_cursor.descend_to_byte(v356_6_byte);
      {
      let v356_6_tail = v356_6_cursor.fork_read_zipper();
      let v356_6_head = Path::from_slice(&[v356_6_byte]);
      let v357_2: Space = Space::new();
      v356_6.join_into((v357_2).clone());
      }
      v356_6_cursor.ascend(1);
    }
    drop(v356_6_cursor);
    let v356_7: Space = compose(&(v356_5),&(v356_6));
    drop(v356_5);
    drop(v356_6);
    let v356_8: Space = intersect(&(*CONSTANT_1),&(v356_2));
    drop(v356_2);
    let v356_9: Space = if has_head(&(v356_8)) { singleton(&[]) } else { Space::new() };
    drop(v356_8);
    let v356_17: Space = if (v356_9).is_empty() { Space::new() } else {
      let v358_10: Space = unwrap(&(v355_10),&(v355_31_head));
      let v358_11: Space = restrict_to(&(v355_9),&(v358_10));
      let mut v358_12 = Space::new();
      let mut v358_12_cursor = (v358_11).read_zipper();
      for v358_12_byte in v358_12_cursor.child_mask().iter() {
        v358_12_cursor.descend_to_byte(v358_12_byte);
        {
        let v358_12_tail = v358_12_cursor.fork_read_zipper();
        let v358_12_head = Path::from_slice(&[v358_12_byte]);
        let v359_2: Space = singleton(&(v358_12_head));
        let v359_3: Space = intersect(&(*CONSTANT_1),&(v359_2));
        let v359_4: Space = if has_head(&(v359_3)) { singleton(&[]) } else { Space::new() };
        drop(v359_3);
        let v359_5: Space = subtract(&(*CONSTANT_0),&(v359_4));
        drop(v359_4);
        let v359_7: Space = if (v359_5).is_empty() { Space::new() } else {
          let mut v360_6 = Space::new();
          let mut v360_6_cursor = (v358_12_tail).read_zipper();
          for v360_6_byte in v360_6_cursor.child_mask().iter() {
            v360_6_cursor.descend_to_byte(v360_6_byte);
            {
            let v360_6_tail = v360_6_cursor.fork_read_zipper();
            let v360_6_head = Path::from_slice(&[v360_6_byte]);
            let v361_2: Space = singleton(&(v360_6_head));
            let v361_3: Space = intersect(&(*CONSTANT_1),&(v361_2));
            let v361_4: Space = if has_head(&(v361_3)) { singleton(&[]) } else { Space::new() };
            drop(v361_3);
            let v361_5: Space = subtract(&(*CONSTANT_0),&(v361_4));
            drop(v361_4);
            let v361_8: Space = if (v361_5).is_empty() { Space::new() } else {
              let v362_6: Path = concat_path(&(v358_12_head),&(v360_6_head));
              let v362_7: Space = routine_10(c, &(v362_6), &(v360_6_tail).make_space());
              compose(&(v361_5),&(v362_7))
            };
            drop(v361_5);
            let v361_9: Space = intersect(&(*CONSTANT_1),&(v361_2));
            drop(v361_2);
            let v361_10: Space = if has_head(&(v361_9)) { singleton(&[]) } else { Space::new() };
            drop(v361_9);
            let v361_12: Space = if (v361_10).is_empty() { Space::new() } else {
              let v363_6: Path = concat_path(&(v358_12_head),&(v360_6_head));
              let v363_11: Space = routine_11(c, &(v363_6), &(v360_6_tail).make_space());
              drop(v363_6);
              compose(&(v361_10),&(v363_11))
            };
            drop(v361_10);
            let v361_13: Space = unite(&(v361_8),&(v361_12));
            v360_6.join_into((v361_13).clone());
            }
            v360_6_cursor.ascend(1);
          }
          drop(v360_6_cursor);
          compose(&(v359_5),&(v360_6))
        };
        drop(v359_5);
        let v359_8: Space = intersect(&(*CONSTANT_1),&(v359_2));
        drop(v359_2);
        let v359_9: Space = if has_head(&(v359_8)) { singleton(&[]) } else { Space::new() };
        drop(v359_8);
        let v359_11: Space = if (v359_9).is_empty() { Space::new() } else {
          let mut v364_10 = Space::new();
          let mut v364_10_cursor = (v358_12_tail).read_zipper();
          for v364_10_byte in v364_10_cursor.child_mask().iter() {
            v364_10_cursor.descend_to_byte(v364_10_byte);
            {
            let v364_10_tail = v364_10_cursor.fork_read_zipper();
            let v364_10_head = Path::from_slice(&[v364_10_byte]);
            let v365_2: Space = singleton(&(v364_10_head));
            let v365_3: Space = intersect(&(*CONSTANT_1),&(v365_2));
            let v365_4: Space = if has_head(&(v365_3)) { singleton(&[]) } else { Space::new() };
            drop(v365_3);
            let v365_5: Space = subtract(&(*CONSTANT_0),&(v365_4));
            drop(v365_4);
            let v365_8: Space = if (v365_5).is_empty() { Space::new() } else {
              let v366_6: Path = concat_path(&(v358_12_head),&(v364_10_head));
              let v366_7: Space = routine_10(c, &(v366_6), &(v364_10_tail).make_space());
              compose(&(v365_5),&(v366_7))
            };
            drop(v365_5);
            let v365_9: Space = intersect(&(*CONSTANT_1),&(v365_2));
            drop(v365_2);
            let v365_10: Space = if has_head(&(v365_9)) { singleton(&[]) } else { Space::new() };
            drop(v365_9);
            let v365_12: Space = if (v365_10).is_empty() { Space::new() } else {
              let v367_6: Path = concat_path(&(v358_12_head),&(v364_10_head));
              let v367_11: Space = routine_12(c, &(v367_6), &(v364_10_tail).make_space());
              drop(v367_6);
              compose(&(v365_10),&(v367_11))
            };
            drop(v365_10);
            let v365_13: Space = unite(&(v365_8),&(v365_12));
            v364_10.join_into((v365_13).clone());
            }
            v364_10_cursor.ascend(1);
          }
          drop(v364_10_cursor);
          compose(&(v359_9),&(v364_10))
        };
        drop(v359_9);
        let v359_12: Space = unite(&(v359_7),&(v359_11));
        v358_12.join_into((v359_12).clone());
        }
        v358_12_cursor.ascend(1);
      }
      drop(v358_12_cursor);
      drop(v358_11);
      let v358_13: Space = restrict_to(&(v355_7),&(v358_12));
      let mut v358_14 = Space::new();
      let mut v358_14_cursor = (v358_13).read_zipper();
      for v358_14_byte in v358_14_cursor.child_mask().iter() {
        v358_14_cursor.descend_to_byte(v358_14_byte);
        {
        let v358_14_tail = v358_14_cursor.fork_read_zipper();
        let v358_14_head = Path::from_slice(&[v358_14_byte]);
        let v368_2: Space = singleton(&(v358_14_head));
        let v368_3: Space = intersect(&(*CONSTANT_1),&(v368_2));
        let v368_4: Space = if has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
        drop(v368_3);
        let v368_5: Space = subtract(&(*CONSTANT_0),&(v368_4));
        drop(v368_4);
        let v368_7: Space = if (v368_5).is_empty() { Space::new() } else {
          let mut v369_6 = Space::new();
          let mut v369_6_cursor = (v358_14_tail).read_zipper();
          for v369_6_byte in v369_6_cursor.child_mask().iter() {
            v369_6_cursor.descend_to_byte(v369_6_byte);
            {
            let v369_6_tail = v369_6_cursor.fork_read_zipper();
            let v369_6_head = Path::from_slice(&[v369_6_byte]);
            let v370_2: Space = singleton(&(v369_6_head));
            let v370_3: Space = intersect(&(*CONSTANT_1),&(v370_2));
            let v370_4: Space = if has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
            drop(v370_3);
            let v370_5: Space = subtract(&(*CONSTANT_0),&(v370_4));
            drop(v370_4);
            let v370_8: Space = if (v370_5).is_empty() { Space::new() } else {
              let v371_6: Path = concat_path(&(v358_14_head),&(v369_6_head));
              let v371_7: Space = routine_13(c, &(v371_6), &(v369_6_tail).make_space());
              compose(&(v370_5),&(v371_7))
            };
            drop(v370_5);
            let v370_9: Space = intersect(&(*CONSTANT_1),&(v370_2));
            drop(v370_2);
            let v370_10: Space = if has_head(&(v370_9)) { singleton(&[]) } else { Space::new() };
            drop(v370_9);
            let v370_12: Space = if (v370_10).is_empty() { Space::new() } else {
              let v372_6: Path = concat_path(&(v358_14_head),&(v369_6_head));
              let v372_11: Space = routine_14(c, &(v372_6), &(v369_6_tail).make_space());
              drop(v372_6);
              compose(&(v370_10),&(v372_11))
            };
            drop(v370_10);
            let v370_13: Space = unite(&(v370_8),&(v370_12));
            v369_6.join_into((v370_13).clone());
            }
            v369_6_cursor.ascend(1);
          }
          drop(v369_6_cursor);
          compose(&(v368_5),&(v369_6))
        };
        drop(v368_5);
        let v368_8: Space = intersect(&(*CONSTANT_1),&(v368_2));
        drop(v368_2);
        let v368_9: Space = if has_head(&(v368_8)) { singleton(&[]) } else { Space::new() };
        drop(v368_8);
        let v368_11: Space = if (v368_9).is_empty() { Space::new() } else {
          let mut v373_10 = Space::new();
          let mut v373_10_cursor = (v358_14_tail).read_zipper();
          for v373_10_byte in v373_10_cursor.child_mask().iter() {
            v373_10_cursor.descend_to_byte(v373_10_byte);
            {
            let v373_10_tail = v373_10_cursor.fork_read_zipper();
            let v373_10_head = Path::from_slice(&[v373_10_byte]);
            let v374_2: Space = singleton(&(v373_10_head));
            let v374_3: Space = intersect(&(*CONSTANT_1),&(v374_2));
            let v374_4: Space = if has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
            drop(v374_3);
            let v374_5: Space = subtract(&(*CONSTANT_0),&(v374_4));
            drop(v374_4);
            let v374_8: Space = if (v374_5).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v358_14_head),&(v373_10_head));
              let v375_7: Space = routine_13(c, &(v375_6), &(v373_10_tail).make_space());
              compose(&(v374_5),&(v375_7))
            };
            drop(v374_5);
            let v374_9: Space = intersect(&(*CONSTANT_1),&(v374_2));
            drop(v374_2);
            let v374_10: Space = if has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
            drop(v374_9);
            let v374_12: Space = if (v374_10).is_empty() { Space::new() } else {
              let v376_6: Path = concat_path(&(v358_14_head),&(v373_10_head));
              let v376_11: Space = routine_15(c, &(v376_6), &(v373_10_tail).make_space());
              drop(v376_6);
              compose(&(v374_10),&(v376_11))
            };
            drop(v374_10);
            let v374_13: Space = unite(&(v374_8),&(v374_12));
            v373_10.join_into((v374_13).clone());
            }
            v373_10_cursor.ascend(1);
          }
          drop(v373_10_cursor);
          compose(&(v368_9),&(v373_10))
        };
        drop(v368_9);
        let v368_12: Space = unite(&(v368_7),&(v368_11));
        v358_14.join_into((v368_12).clone());
        }
        v358_14_cursor.ascend(1);
      }
      drop(v358_14_cursor);
      let v358_15: Space = subtract(&(v358_14),&(v358_10));
      drop(v358_10);
      let v358_16: Space = intersect(&(v358_15),&(v355_12));
      compose(&(v356_9),&(v358_16))
    };
    drop(v356_9);
    let v356_18: Path = concat_path(&(*p0),&(v355_31_head));
    let v356_19: Space = wrap(&(v356_17),&(v356_18));
    drop(v356_18);
    let v356_20: Space = unite(&(v356_7),&(v356_19));
    drop(v356_7);
    v355_31.join_into((v356_20).clone());
    }
    v355_31_cursor.ascend(1);
  }
  drop(v355_31_cursor);
  drop(v355_7);
  drop(v355_9);
  drop(v355_10);
  drop(v355_12);
  (v355_31).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v377_20 = Space::new();
  let mut v377_20_cursor = (*s0).read_zipper();
  for v377_20_byte in v377_20_cursor.child_mask().iter() {
    v377_20_cursor.descend_to_byte(v377_20_byte);
    {
    let v377_20_tail = v377_20_cursor.fork_read_zipper();
    let v377_20_head = Path::from_slice(&[v377_20_byte]);
    let v378_2: Space = singleton(&(v377_20_head));
    let v378_3: Space = intersect(&(*CONSTANT_1),&(v378_2));
    let v378_4: Space = if has_head(&(v378_3)) { singleton(&[]) } else { Space::new() };
    drop(v378_3);
    let v378_5: Space = subtract(&(*CONSTANT_0),&(v378_4));
    drop(v378_4);
    let v378_8: Space = if (v378_5).is_empty() { Space::new() } else {
      let v379_6: Path = concat_path(&(*p0),&(v377_20_head));
      let mut v379_7 = Space::new();
      let mut v379_7_cursor = (v377_20_tail).read_zipper();
      for v379_7_byte in v379_7_cursor.child_mask().iter() {
        v379_7_cursor.descend_to_byte(v379_7_byte);
        {
        let v379_7_tail = v379_7_cursor.fork_read_zipper();
        let v379_7_head = Path::from_slice(&[v379_7_byte]);
        let v380_2: Space = singleton(&(v379_7_head));
        let v380_3: Space = intersect(&(*CONSTANT_1),&(v380_2));
        let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
        drop(v380_3);
        let v380_5: Space = subtract(&(*CONSTANT_0),&(v380_4));
        drop(v380_4);
        let v380_8: Space = if (v380_5).is_empty() { Space::new() } else {
          let v381_6: Path = concat_path(&(v379_6),&(v379_7_head));
          let mut v381_7 = Space::new();
          let mut v381_7_cursor = (v379_7_tail).read_zipper();
          for v381_7_byte in v381_7_cursor.child_mask().iter() {
            v381_7_cursor.descend_to_byte(v381_7_byte);
            {
            let v381_7_tail = v381_7_cursor.fork_read_zipper();
            let v381_7_head = Path::from_slice(&[v381_7_byte]);
            let v382_2: Space = singleton(&(v381_7_head));
            let v382_3: Space = intersect(&(*CONSTANT_1),&(v382_2));
            let v382_4: Space = if has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
            drop(v382_3);
            let v382_5: Space = subtract(&(*CONSTANT_0),&(v382_4));
            drop(v382_4);
            let v382_8: Space = if (v382_5).is_empty() { Space::new() } else {
              let v383_6: Path = concat_path(&(v381_6),&(v381_7_head));
              let v383_7: Space = routine_34(c, &(v383_6), &(v381_7_tail).make_space());
              compose(&(v382_5),&(v383_7))
            };
            drop(v382_5);
            let v382_9: Space = intersect(&(*CONSTANT_1),&(v382_2));
            drop(v382_2);
            let v382_10: Space = if has_head(&(v382_9)) { singleton(&[]) } else { Space::new() };
            drop(v382_9);
            let v382_12: Space = if (v382_10).is_empty() { Space::new() } else {
              let v384_6: Path = concat_path(&(v381_6),&(v381_7_head));
              let v384_11: Space = routine_35(c, &(v384_6), &(v381_7_tail).make_space());
              drop(v384_6);
              compose(&(v382_10),&(v384_11))
            };
            drop(v382_10);
            let v382_13: Space = unite(&(v382_8),&(v382_12));
            v381_7.join_into((v382_13).clone());
            }
            v381_7_cursor.ascend(1);
          }
          drop(v381_7_cursor);
          compose(&(v380_5),&(v381_7))
        };
        drop(v380_5);
        let v380_9: Space = intersect(&(*CONSTANT_1),&(v380_2));
        drop(v380_2);
        let v380_10: Space = if has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
        drop(v380_9);
        let v380_12: Space = if (v380_10).is_empty() { Space::new() } else {
          let v385_6: Path = concat_path(&(v379_6),&(v379_7_head));
          let mut v385_11 = Space::new();
          let mut v385_11_cursor = (v379_7_tail).read_zipper();
          for v385_11_byte in v385_11_cursor.child_mask().iter() {
            v385_11_cursor.descend_to_byte(v385_11_byte);
            {
            let v385_11_tail = v385_11_cursor.fork_read_zipper();
            let v385_11_head = Path::from_slice(&[v385_11_byte]);
            let v386_2: Space = singleton(&(v385_11_head));
            let v386_3: Space = intersect(&(*CONSTANT_1),&(v386_2));
            let v386_4: Space = if has_head(&(v386_3)) { singleton(&[]) } else { Space::new() };
            drop(v386_3);
            let v386_5: Space = subtract(&(*CONSTANT_0),&(v386_4));
            drop(v386_4);
            let v386_8: Space = if (v386_5).is_empty() { Space::new() } else {
              let v387_6: Path = concat_path(&(v385_6),&(v385_11_head));
              let v387_7: Space = routine_34(c, &(v387_6), &(v385_11_tail).make_space());
              compose(&(v386_5),&(v387_7))
            };
            drop(v386_5);
            let v386_9: Space = intersect(&(*CONSTANT_1),&(v386_2));
            drop(v386_2);
            let v386_10: Space = if has_head(&(v386_9)) { singleton(&[]) } else { Space::new() };
            drop(v386_9);
            let v386_12: Space = if (v386_10).is_empty() { Space::new() } else {
              let v388_6: Path = concat_path(&(v385_6),&(v385_11_head));
              let v388_11: Space = routine_12(c, &(v388_6), &(v385_11_tail).make_space());
              drop(v388_6);
              compose(&(v386_10),&(v388_11))
            };
            drop(v386_10);
            let v386_13: Space = unite(&(v386_8),&(v386_12));
            v385_11.join_into((v386_13).clone());
            }
            v385_11_cursor.ascend(1);
          }
          drop(v385_11_cursor);
          drop(v385_6);
          compose(&(v380_10),&(v385_11))
        };
        drop(v380_10);
        let v380_13: Space = unite(&(v380_8),&(v380_12));
        v379_7.join_into((v380_13).clone());
        }
        v379_7_cursor.ascend(1);
      }
      drop(v379_7_cursor);
      compose(&(v378_5),&(v379_7))
    };
    drop(v378_5);
    let v378_9: Space = intersect(&(*CONSTANT_1),&(v378_2));
    drop(v378_2);
    let v378_10: Space = if has_head(&(v378_9)) { singleton(&[]) } else { Space::new() };
    drop(v378_9);
    let v378_12: Space = if (v378_10).is_empty() { Space::new() } else {
      let v389_6: Path = concat_path(&(*p0),&(v377_20_head));
      let mut v389_11 = Space::new();
      let mut v389_11_cursor = (v377_20_tail).read_zipper();
      for v389_11_byte in v389_11_cursor.child_mask().iter() {
        v389_11_cursor.descend_to_byte(v389_11_byte);
        {
        let v389_11_tail = v389_11_cursor.fork_read_zipper();
        let v389_11_head = Path::from_slice(&[v389_11_byte]);
        let v390_2: Space = singleton(&(v389_11_head));
        let v390_3: Space = intersect(&(*CONSTANT_1),&(v390_2));
        let v390_4: Space = if has_head(&(v390_3)) { singleton(&[]) } else { Space::new() };
        drop(v390_3);
        let v390_5: Space = subtract(&(*CONSTANT_0),&(v390_4));
        drop(v390_4);
        let v390_8: Space = if (v390_5).is_empty() { Space::new() } else {
          let v391_6: Path = concat_path(&(v389_6),&(v389_11_head));
          let mut v391_7 = Space::new();
          let mut v391_7_cursor = (v389_11_tail).read_zipper();
          for v391_7_byte in v391_7_cursor.child_mask().iter() {
            v391_7_cursor.descend_to_byte(v391_7_byte);
            {
            let v391_7_tail = v391_7_cursor.fork_read_zipper();
            let v391_7_head = Path::from_slice(&[v391_7_byte]);
            let v392_2: Space = singleton(&(v391_7_head));
            let v392_3: Space = intersect(&(*CONSTANT_1),&(v392_2));
            let v392_4: Space = if has_head(&(v392_3)) { singleton(&[]) } else { Space::new() };
            drop(v392_3);
            let v392_5: Space = subtract(&(*CONSTANT_0),&(v392_4));
            drop(v392_4);
            let v392_8: Space = if (v392_5).is_empty() { Space::new() } else {
              let v393_6: Path = concat_path(&(v391_6),&(v391_7_head));
              let v393_7: Space = routine_34(c, &(v393_6), &(v391_7_tail).make_space());
              compose(&(v392_5),&(v393_7))
            };
            drop(v392_5);
            let v392_9: Space = intersect(&(*CONSTANT_1),&(v392_2));
            drop(v392_2);
            let v392_10: Space = if has_head(&(v392_9)) { singleton(&[]) } else { Space::new() };
            drop(v392_9);
            let v392_12: Space = if (v392_10).is_empty() { Space::new() } else {
              let v394_6: Path = concat_path(&(v391_6),&(v391_7_head));
              let v394_11: Space = routine_35(c, &(v394_6), &(v391_7_tail).make_space());
              drop(v394_6);
              compose(&(v392_10),&(v394_11))
            };
            drop(v392_10);
            let v392_13: Space = unite(&(v392_8),&(v392_12));
            v391_7.join_into((v392_13).clone());
            }
            v391_7_cursor.ascend(1);
          }
          drop(v391_7_cursor);
          drop(v391_6);
          compose(&(v390_5),&(v391_7))
        };
        drop(v390_5);
        let v390_9: Space = intersect(&(*CONSTANT_1),&(v390_2));
        drop(v390_2);
        let v390_10: Space = if has_head(&(v390_9)) { singleton(&[]) } else { Space::new() };
        drop(v390_9);
        let v390_11: Space = compose(&(v390_10),&(v389_11_tail));
        drop(v390_10);
        let v390_12: Space = unite(&(v390_8),&(v390_11));
        drop(v390_11);
        v389_11.join_into((v390_12).clone());
        }
        v389_11_cursor.ascend(1);
      }
      drop(v389_11_cursor);
      drop(v389_6);
      compose(&(v378_10),&(v389_11))
    };
    drop(v378_10);
    let v378_13: Space = unite(&(v378_8),&(v378_12));
    v377_20.join_into((v378_13).clone());
    }
    v377_20_cursor.ascend(1);
  }
  drop(v377_20_cursor);
  (v377_20).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v395_14 = Space::new();
  let mut v395_14_cursor = (*s0).read_zipper();
  for v395_14_byte in v395_14_cursor.child_mask().iter() {
    v395_14_cursor.descend_to_byte(v395_14_byte);
    {
    let v395_14_tail = v395_14_cursor.fork_read_zipper();
    let v395_14_head = Path::from_slice(&[v395_14_byte]);
    let v396_2: Space = singleton(&(v395_14_head));
    let v396_3: Space = intersect(&(*CONSTANT_1),&(v396_2));
    let v396_4: Space = if has_head(&(v396_3)) { singleton(&[]) } else { Space::new() };
    drop(v396_3);
    let v396_5: Space = subtract(&(*CONSTANT_0),&(v396_4));
    drop(v396_4);
    let v396_8: Space = if (v396_5).is_empty() { Space::new() } else {
      let v397_6: Path = concat_path(&(*p0),&(v395_14_head));
      let mut v397_7 = Space::new();
      let mut v397_7_cursor = (v395_14_tail).read_zipper();
      for v397_7_byte in v397_7_cursor.child_mask().iter() {
        v397_7_cursor.descend_to_byte(v397_7_byte);
        {
        let v397_7_tail = v397_7_cursor.fork_read_zipper();
        let v397_7_head = Path::from_slice(&[v397_7_byte]);
        let v398_2: Space = singleton(&(v397_7_head));
        let v398_3: Space = intersect(&(*CONSTANT_1),&(v398_2));
        let v398_4: Space = if has_head(&(v398_3)) { singleton(&[]) } else { Space::new() };
        drop(v398_3);
        let v398_5: Space = subtract(&(*CONSTANT_0),&(v398_4));
        drop(v398_4);
        let v398_8: Space = if (v398_5).is_empty() { Space::new() } else {
          let v399_6: Path = concat_path(&(v397_6),&(v397_7_head));
          let mut v399_7 = Space::new();
          let mut v399_7_cursor = (v397_7_tail).read_zipper();
          for v399_7_byte in v399_7_cursor.child_mask().iter() {
            v399_7_cursor.descend_to_byte(v399_7_byte);
            {
            let v399_7_tail = v399_7_cursor.fork_read_zipper();
            let v399_7_head = Path::from_slice(&[v399_7_byte]);
            let v400_2: Space = singleton(&(v399_7_head));
            let v400_3: Space = intersect(&(*CONSTANT_1),&(v400_2));
            let v400_4: Space = if has_head(&(v400_3)) { singleton(&[]) } else { Space::new() };
            drop(v400_3);
            let v400_5: Space = subtract(&(*CONSTANT_0),&(v400_4));
            drop(v400_4);
            let v400_8: Space = if (v400_5).is_empty() { Space::new() } else {
              let v401_6: Path = concat_path(&(v399_6),&(v399_7_head));
              let v401_7: Space = routine_34(c, &(v401_6), &(v399_7_tail).make_space());
              compose(&(v400_5),&(v401_7))
            };
            drop(v400_5);
            let v400_9: Space = intersect(&(*CONSTANT_1),&(v400_2));
            drop(v400_2);
            let v400_10: Space = if has_head(&(v400_9)) { singleton(&[]) } else { Space::new() };
            drop(v400_9);
            let v400_12: Space = if (v400_10).is_empty() { Space::new() } else {
              let v402_6: Path = concat_path(&(v399_6),&(v399_7_head));
              let v402_11: Space = routine_35(c, &(v402_6), &(v399_7_tail).make_space());
              drop(v402_6);
              compose(&(v400_10),&(v402_11))
            };
            drop(v400_10);
            let v400_13: Space = unite(&(v400_8),&(v400_12));
            v399_7.join_into((v400_13).clone());
            }
            v399_7_cursor.ascend(1);
          }
          drop(v399_7_cursor);
          compose(&(v398_5),&(v399_7))
        };
        drop(v398_5);
        let v398_9: Space = intersect(&(*CONSTANT_1),&(v398_2));
        drop(v398_2);
        let v398_10: Space = if has_head(&(v398_9)) { singleton(&[]) } else { Space::new() };
        drop(v398_9);
        let v398_12: Space = if (v398_10).is_empty() { Space::new() } else {
          let v403_6: Path = concat_path(&(v397_6),&(v397_7_head));
          let mut v403_11 = Space::new();
          let mut v403_11_cursor = (v397_7_tail).read_zipper();
          for v403_11_byte in v403_11_cursor.child_mask().iter() {
            v403_11_cursor.descend_to_byte(v403_11_byte);
            {
            let v403_11_tail = v403_11_cursor.fork_read_zipper();
            let v403_11_head = Path::from_slice(&[v403_11_byte]);
            let v404_2: Space = singleton(&(v403_11_head));
            let v404_3: Space = intersect(&(*CONSTANT_1),&(v404_2));
            let v404_4: Space = if has_head(&(v404_3)) { singleton(&[]) } else { Space::new() };
            drop(v404_3);
            let v404_5: Space = subtract(&(*CONSTANT_0),&(v404_4));
            drop(v404_4);
            let v404_8: Space = if (v404_5).is_empty() { Space::new() } else {
              let v405_6: Path = concat_path(&(v403_6),&(v403_11_head));
              let v405_7: Space = routine_34(c, &(v405_6), &(v403_11_tail).make_space());
              compose(&(v404_5),&(v405_7))
            };
            drop(v404_5);
            let v404_9: Space = intersect(&(*CONSTANT_1),&(v404_2));
            drop(v404_2);
            let v404_10: Space = if has_head(&(v404_9)) { singleton(&[]) } else { Space::new() };
            drop(v404_9);
            let v404_12: Space = if (v404_10).is_empty() { Space::new() } else {
              let v406_6: Path = concat_path(&(v403_6),&(v403_11_head));
              let v406_11: Space = routine_12(c, &(v406_6), &(v403_11_tail).make_space());
              drop(v406_6);
              compose(&(v404_10),&(v406_11))
            };
            drop(v404_10);
            let v404_13: Space = unite(&(v404_8),&(v404_12));
            v403_11.join_into((v404_13).clone());
            }
            v403_11_cursor.ascend(1);
          }
          drop(v403_11_cursor);
          drop(v403_6);
          compose(&(v398_10),&(v403_11))
        };
        drop(v398_10);
        let v398_13: Space = unite(&(v398_8),&(v398_12));
        v397_7.join_into((v398_13).clone());
        }
        v397_7_cursor.ascend(1);
      }
      drop(v397_7_cursor);
      drop(v397_6);
      compose(&(v396_5),&(v397_7))
    };
    drop(v396_5);
    let v396_9: Space = intersect(&(*CONSTANT_1),&(v396_2));
    drop(v396_2);
    let v396_10: Space = if has_head(&(v396_9)) { singleton(&[]) } else { Space::new() };
    drop(v396_9);
    let v396_11: Space = compose(&(v396_10),&(v395_14_tail));
    drop(v396_10);
    let v396_12: Space = unite(&(v396_8),&(v396_11));
    drop(v396_11);
    v395_14.join_into((v396_12).clone());
    }
    v395_14_cursor.ascend(1);
  }
  drop(v395_14_cursor);
  (v395_14).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v407_20 = Space::new();
  let mut v407_20_cursor = (*s0).read_zipper();
  for v407_20_byte in v407_20_cursor.child_mask().iter() {
    v407_20_cursor.descend_to_byte(v407_20_byte);
    {
    let v407_20_tail = v407_20_cursor.fork_read_zipper();
    let v407_20_head = Path::from_slice(&[v407_20_byte]);
    let v408_2: Space = singleton(&(v407_20_head));
    let v408_3: Space = intersect(&(*CONSTANT_1),&(v408_2));
    let v408_4: Space = if has_head(&(v408_3)) { singleton(&[]) } else { Space::new() };
    drop(v408_3);
    let v408_5: Space = subtract(&(*CONSTANT_0),&(v408_4));
    drop(v408_4);
    let v408_8: Space = if (v408_5).is_empty() { Space::new() } else {
      let v409_6: Path = concat_path(&(*p0),&(v407_20_head));
      let mut v409_7 = Space::new();
      let mut v409_7_cursor = (v407_20_tail).read_zipper();
      for v409_7_byte in v409_7_cursor.child_mask().iter() {
        v409_7_cursor.descend_to_byte(v409_7_byte);
        {
        let v409_7_tail = v409_7_cursor.fork_read_zipper();
        let v409_7_head = Path::from_slice(&[v409_7_byte]);
        let v410_2: Space = singleton(&(v409_7_head));
        let v410_3: Space = intersect(&(*CONSTANT_1),&(v410_2));
        let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
        drop(v410_3);
        let v410_5: Space = subtract(&(*CONSTANT_0),&(v410_4));
        drop(v410_4);
        let v410_8: Space = if (v410_5).is_empty() { Space::new() } else {
          let v411_6: Path = concat_path(&(v409_6),&(v409_7_head));
          let mut v411_7 = Space::new();
          let mut v411_7_cursor = (v409_7_tail).read_zipper();
          for v411_7_byte in v411_7_cursor.child_mask().iter() {
            v411_7_cursor.descend_to_byte(v411_7_byte);
            {
            let v411_7_tail = v411_7_cursor.fork_read_zipper();
            let v411_7_head = Path::from_slice(&[v411_7_byte]);
            let v412_2: Space = singleton(&(v411_7_head));
            let v412_3: Space = intersect(&(*CONSTANT_1),&(v412_2));
            let v412_4: Space = if has_head(&(v412_3)) { singleton(&[]) } else { Space::new() };
            drop(v412_3);
            let v412_5: Space = subtract(&(*CONSTANT_0),&(v412_4));
            drop(v412_4);
            let v412_8: Space = if (v412_5).is_empty() { Space::new() } else {
              let v413_6: Path = concat_path(&(v411_6),&(v411_7_head));
              let v413_7: Space = routine_36(c, &(v413_6), &(v411_7_tail).make_space());
              compose(&(v412_5),&(v413_7))
            };
            drop(v412_5);
            let v412_9: Space = intersect(&(*CONSTANT_1),&(v412_2));
            drop(v412_2);
            let v412_10: Space = if has_head(&(v412_9)) { singleton(&[]) } else { Space::new() };
            drop(v412_9);
            let v412_12: Space = if (v412_10).is_empty() { Space::new() } else {
              let v414_6: Path = concat_path(&(v411_6),&(v411_7_head));
              let v414_11: Space = routine_37(c, &(v414_6), &(v411_7_tail).make_space());
              drop(v414_6);
              compose(&(v412_10),&(v414_11))
            };
            drop(v412_10);
            let v412_13: Space = unite(&(v412_8),&(v412_12));
            v411_7.join_into((v412_13).clone());
            }
            v411_7_cursor.ascend(1);
          }
          drop(v411_7_cursor);
          compose(&(v410_5),&(v411_7))
        };
        drop(v410_5);
        let v410_9: Space = intersect(&(*CONSTANT_1),&(v410_2));
        drop(v410_2);
        let v410_10: Space = if has_head(&(v410_9)) { singleton(&[]) } else { Space::new() };
        drop(v410_9);
        let v410_12: Space = if (v410_10).is_empty() { Space::new() } else {
          let v415_6: Path = concat_path(&(v409_6),&(v409_7_head));
          let mut v415_11 = Space::new();
          let mut v415_11_cursor = (v409_7_tail).read_zipper();
          for v415_11_byte in v415_11_cursor.child_mask().iter() {
            v415_11_cursor.descend_to_byte(v415_11_byte);
            {
            let v415_11_tail = v415_11_cursor.fork_read_zipper();
            let v415_11_head = Path::from_slice(&[v415_11_byte]);
            let v416_2: Space = singleton(&(v415_11_head));
            let v416_3: Space = intersect(&(*CONSTANT_1),&(v416_2));
            let v416_4: Space = if has_head(&(v416_3)) { singleton(&[]) } else { Space::new() };
            drop(v416_3);
            let v416_5: Space = subtract(&(*CONSTANT_0),&(v416_4));
            drop(v416_4);
            let v416_8: Space = if (v416_5).is_empty() { Space::new() } else {
              let v417_6: Path = concat_path(&(v415_6),&(v415_11_head));
              let v417_7: Space = routine_36(c, &(v417_6), &(v415_11_tail).make_space());
              compose(&(v416_5),&(v417_7))
            };
            drop(v416_5);
            let v416_9: Space = intersect(&(*CONSTANT_1),&(v416_2));
            drop(v416_2);
            let v416_10: Space = if has_head(&(v416_9)) { singleton(&[]) } else { Space::new() };
            drop(v416_9);
            let v416_12: Space = if (v416_10).is_empty() { Space::new() } else {
              let v418_6: Path = concat_path(&(v415_6),&(v415_11_head));
              let v418_11: Space = routine_15(c, &(v418_6), &(v415_11_tail).make_space());
              drop(v418_6);
              compose(&(v416_10),&(v418_11))
            };
            drop(v416_10);
            let v416_13: Space = unite(&(v416_8),&(v416_12));
            v415_11.join_into((v416_13).clone());
            }
            v415_11_cursor.ascend(1);
          }
          drop(v415_11_cursor);
          drop(v415_6);
          compose(&(v410_10),&(v415_11))
        };
        drop(v410_10);
        let v410_13: Space = unite(&(v410_8),&(v410_12));
        v409_7.join_into((v410_13).clone());
        }
        v409_7_cursor.ascend(1);
      }
      drop(v409_7_cursor);
      compose(&(v408_5),&(v409_7))
    };
    drop(v408_5);
    let v408_9: Space = intersect(&(*CONSTANT_1),&(v408_2));
    drop(v408_2);
    let v408_10: Space = if has_head(&(v408_9)) { singleton(&[]) } else { Space::new() };
    drop(v408_9);
    let v408_12: Space = if (v408_10).is_empty() { Space::new() } else {
      let v419_6: Path = concat_path(&(*p0),&(v407_20_head));
      let mut v419_11 = Space::new();
      let mut v419_11_cursor = (v407_20_tail).read_zipper();
      for v419_11_byte in v419_11_cursor.child_mask().iter() {
        v419_11_cursor.descend_to_byte(v419_11_byte);
        {
        let v419_11_tail = v419_11_cursor.fork_read_zipper();
        let v419_11_head = Path::from_slice(&[v419_11_byte]);
        let v420_2: Space = singleton(&(v419_11_head));
        let v420_3: Space = intersect(&(*CONSTANT_1),&(v420_2));
        let v420_4: Space = if has_head(&(v420_3)) { singleton(&[]) } else { Space::new() };
        drop(v420_3);
        let v420_5: Space = subtract(&(*CONSTANT_0),&(v420_4));
        drop(v420_4);
        let v420_8: Space = if (v420_5).is_empty() { Space::new() } else {
          let v421_6: Path = concat_path(&(v419_6),&(v419_11_head));
          let mut v421_7 = Space::new();
          let mut v421_7_cursor = (v419_11_tail).read_zipper();
          for v421_7_byte in v421_7_cursor.child_mask().iter() {
            v421_7_cursor.descend_to_byte(v421_7_byte);
            {
            let v421_7_tail = v421_7_cursor.fork_read_zipper();
            let v421_7_head = Path::from_slice(&[v421_7_byte]);
            let v422_2: Space = singleton(&(v421_7_head));
            let v422_3: Space = intersect(&(*CONSTANT_1),&(v422_2));
            let v422_4: Space = if has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
            drop(v422_3);
            let v422_5: Space = subtract(&(*CONSTANT_0),&(v422_4));
            drop(v422_4);
            let v422_8: Space = if (v422_5).is_empty() { Space::new() } else {
              let v423_6: Path = concat_path(&(v421_6),&(v421_7_head));
              let v423_7: Space = routine_36(c, &(v423_6), &(v421_7_tail).make_space());
              compose(&(v422_5),&(v423_7))
            };
            drop(v422_5);
            let v422_9: Space = intersect(&(*CONSTANT_1),&(v422_2));
            drop(v422_2);
            let v422_10: Space = if has_head(&(v422_9)) { singleton(&[]) } else { Space::new() };
            drop(v422_9);
            let v422_12: Space = if (v422_10).is_empty() { Space::new() } else {
              let v424_6: Path = concat_path(&(v421_6),&(v421_7_head));
              let v424_11: Space = routine_37(c, &(v424_6), &(v421_7_tail).make_space());
              drop(v424_6);
              compose(&(v422_10),&(v424_11))
            };
            drop(v422_10);
            let v422_13: Space = unite(&(v422_8),&(v422_12));
            v421_7.join_into((v422_13).clone());
            }
            v421_7_cursor.ascend(1);
          }
          drop(v421_7_cursor);
          drop(v421_6);
          compose(&(v420_5),&(v421_7))
        };
        drop(v420_5);
        let v420_9: Space = intersect(&(*CONSTANT_1),&(v420_2));
        drop(v420_2);
        let v420_10: Space = if has_head(&(v420_9)) { singleton(&[]) } else { Space::new() };
        drop(v420_9);
        let v420_11: Space = compose(&(v420_10),&(v419_11_tail));
        drop(v420_10);
        let v420_12: Space = unite(&(v420_8),&(v420_11));
        drop(v420_11);
        v419_11.join_into((v420_12).clone());
        }
        v419_11_cursor.ascend(1);
      }
      drop(v419_11_cursor);
      drop(v419_6);
      compose(&(v408_10),&(v419_11))
    };
    drop(v408_10);
    let v408_13: Space = unite(&(v408_8),&(v408_12));
    v407_20.join_into((v408_13).clone());
    }
    v407_20_cursor.ascend(1);
  }
  drop(v407_20_cursor);
  (v407_20).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v425_14 = Space::new();
  let mut v425_14_cursor = (*s0).read_zipper();
  for v425_14_byte in v425_14_cursor.child_mask().iter() {
    v425_14_cursor.descend_to_byte(v425_14_byte);
    {
    let v425_14_tail = v425_14_cursor.fork_read_zipper();
    let v425_14_head = Path::from_slice(&[v425_14_byte]);
    let v426_2: Space = singleton(&(v425_14_head));
    let v426_3: Space = intersect(&(*CONSTANT_1),&(v426_2));
    let v426_4: Space = if has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
    drop(v426_3);
    let v426_5: Space = subtract(&(*CONSTANT_0),&(v426_4));
    drop(v426_4);
    let v426_8: Space = if (v426_5).is_empty() { Space::new() } else {
      let v427_6: Path = concat_path(&(*p0),&(v425_14_head));
      let mut v427_7 = Space::new();
      let mut v427_7_cursor = (v425_14_tail).read_zipper();
      for v427_7_byte in v427_7_cursor.child_mask().iter() {
        v427_7_cursor.descend_to_byte(v427_7_byte);
        {
        let v427_7_tail = v427_7_cursor.fork_read_zipper();
        let v427_7_head = Path::from_slice(&[v427_7_byte]);
        let v428_2: Space = singleton(&(v427_7_head));
        let v428_3: Space = intersect(&(*CONSTANT_1),&(v428_2));
        let v428_4: Space = if has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
        drop(v428_3);
        let v428_5: Space = subtract(&(*CONSTANT_0),&(v428_4));
        drop(v428_4);
        let v428_8: Space = if (v428_5).is_empty() { Space::new() } else {
          let v429_6: Path = concat_path(&(v427_6),&(v427_7_head));
          let mut v429_7 = Space::new();
          let mut v429_7_cursor = (v427_7_tail).read_zipper();
          for v429_7_byte in v429_7_cursor.child_mask().iter() {
            v429_7_cursor.descend_to_byte(v429_7_byte);
            {
            let v429_7_tail = v429_7_cursor.fork_read_zipper();
            let v429_7_head = Path::from_slice(&[v429_7_byte]);
            let v430_2: Space = singleton(&(v429_7_head));
            let v430_3: Space = intersect(&(*CONSTANT_1),&(v430_2));
            let v430_4: Space = if has_head(&(v430_3)) { singleton(&[]) } else { Space::new() };
            drop(v430_3);
            let v430_5: Space = subtract(&(*CONSTANT_0),&(v430_4));
            drop(v430_4);
            let v430_8: Space = if (v430_5).is_empty() { Space::new() } else {
              let v431_6: Path = concat_path(&(v429_6),&(v429_7_head));
              let v431_7: Space = routine_36(c, &(v431_6), &(v429_7_tail).make_space());
              compose(&(v430_5),&(v431_7))
            };
            drop(v430_5);
            let v430_9: Space = intersect(&(*CONSTANT_1),&(v430_2));
            drop(v430_2);
            let v430_10: Space = if has_head(&(v430_9)) { singleton(&[]) } else { Space::new() };
            drop(v430_9);
            let v430_12: Space = if (v430_10).is_empty() { Space::new() } else {
              let v432_6: Path = concat_path(&(v429_6),&(v429_7_head));
              let v432_11: Space = routine_37(c, &(v432_6), &(v429_7_tail).make_space());
              drop(v432_6);
              compose(&(v430_10),&(v432_11))
            };
            drop(v430_10);
            let v430_13: Space = unite(&(v430_8),&(v430_12));
            v429_7.join_into((v430_13).clone());
            }
            v429_7_cursor.ascend(1);
          }
          drop(v429_7_cursor);
          compose(&(v428_5),&(v429_7))
        };
        drop(v428_5);
        let v428_9: Space = intersect(&(*CONSTANT_1),&(v428_2));
        drop(v428_2);
        let v428_10: Space = if has_head(&(v428_9)) { singleton(&[]) } else { Space::new() };
        drop(v428_9);
        let v428_12: Space = if (v428_10).is_empty() { Space::new() } else {
          let v433_6: Path = concat_path(&(v427_6),&(v427_7_head));
          let mut v433_11 = Space::new();
          let mut v433_11_cursor = (v427_7_tail).read_zipper();
          for v433_11_byte in v433_11_cursor.child_mask().iter() {
            v433_11_cursor.descend_to_byte(v433_11_byte);
            {
            let v433_11_tail = v433_11_cursor.fork_read_zipper();
            let v433_11_head = Path::from_slice(&[v433_11_byte]);
            let v434_2: Space = singleton(&(v433_11_head));
            let v434_3: Space = intersect(&(*CONSTANT_1),&(v434_2));
            let v434_4: Space = if has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
            drop(v434_3);
            let v434_5: Space = subtract(&(*CONSTANT_0),&(v434_4));
            drop(v434_4);
            let v434_8: Space = if (v434_5).is_empty() { Space::new() } else {
              let v435_6: Path = concat_path(&(v433_6),&(v433_11_head));
              let v435_7: Space = routine_36(c, &(v435_6), &(v433_11_tail).make_space());
              compose(&(v434_5),&(v435_7))
            };
            drop(v434_5);
            let v434_9: Space = intersect(&(*CONSTANT_1),&(v434_2));
            drop(v434_2);
            let v434_10: Space = if has_head(&(v434_9)) { singleton(&[]) } else { Space::new() };
            drop(v434_9);
            let v434_12: Space = if (v434_10).is_empty() { Space::new() } else {
              let v436_6: Path = concat_path(&(v433_6),&(v433_11_head));
              let v436_11: Space = routine_15(c, &(v436_6), &(v433_11_tail).make_space());
              drop(v436_6);
              compose(&(v434_10),&(v436_11))
            };
            drop(v434_10);
            let v434_13: Space = unite(&(v434_8),&(v434_12));
            v433_11.join_into((v434_13).clone());
            }
            v433_11_cursor.ascend(1);
          }
          drop(v433_11_cursor);
          drop(v433_6);
          compose(&(v428_10),&(v433_11))
        };
        drop(v428_10);
        let v428_13: Space = unite(&(v428_8),&(v428_12));
        v427_7.join_into((v428_13).clone());
        }
        v427_7_cursor.ascend(1);
      }
      drop(v427_7_cursor);
      drop(v427_6);
      compose(&(v426_5),&(v427_7))
    };
    drop(v426_5);
    let v426_9: Space = intersect(&(*CONSTANT_1),&(v426_2));
    drop(v426_2);
    let v426_10: Space = if has_head(&(v426_9)) { singleton(&[]) } else { Space::new() };
    drop(v426_9);
    let v426_11: Space = compose(&(v426_10),&(v425_14_tail));
    drop(v426_10);
    let v426_12: Space = unite(&(v426_8),&(v426_11));
    drop(v426_11);
    v425_14.join_into((v426_12).clone());
    }
    v425_14_cursor.ascend(1);
  }
  drop(v425_14_cursor);
  (v425_14).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v437_20 = Space::new();
  let mut v437_20_cursor = (*s0).read_zipper();
  for v437_20_byte in v437_20_cursor.child_mask().iter() {
    v437_20_cursor.descend_to_byte(v437_20_byte);
    {
    let v437_20_tail = v437_20_cursor.fork_read_zipper();
    let v437_20_head = Path::from_slice(&[v437_20_byte]);
    let v438_2: Space = singleton(&(v437_20_head));
    let v438_3: Space = intersect(&(*CONSTANT_1),&(v438_2));
    let v438_4: Space = if has_head(&(v438_3)) { singleton(&[]) } else { Space::new() };
    drop(v438_3);
    let v438_5: Space = subtract(&(*CONSTANT_0),&(v438_4));
    drop(v438_4);
    let v438_8: Space = if (v438_5).is_empty() { Space::new() } else {
      let v439_6: Path = concat_path(&(*p0),&(v437_20_head));
      let mut v439_7 = Space::new();
      let mut v439_7_cursor = (v437_20_tail).read_zipper();
      for v439_7_byte in v439_7_cursor.child_mask().iter() {
        v439_7_cursor.descend_to_byte(v439_7_byte);
        {
        let v439_7_tail = v439_7_cursor.fork_read_zipper();
        let v439_7_head = Path::from_slice(&[v439_7_byte]);
        let v440_2: Space = singleton(&(v439_7_head));
        let v440_3: Space = intersect(&(*CONSTANT_1),&(v440_2));
        let v440_4: Space = if has_head(&(v440_3)) { singleton(&[]) } else { Space::new() };
        drop(v440_3);
        let v440_5: Space = subtract(&(*CONSTANT_0),&(v440_4));
        drop(v440_4);
        let v440_8: Space = if (v440_5).is_empty() { Space::new() } else {
          let v441_6: Path = concat_path(&(v439_6),&(v439_7_head));
          let mut v441_7 = Space::new();
          let mut v441_7_cursor = (v439_7_tail).read_zipper();
          for v441_7_byte in v441_7_cursor.child_mask().iter() {
            v441_7_cursor.descend_to_byte(v441_7_byte);
            {
            let v441_7_tail = v441_7_cursor.fork_read_zipper();
            let v441_7_head = Path::from_slice(&[v441_7_byte]);
            let v442_2: Space = singleton(&(v441_7_head));
            let v442_3: Space = intersect(&(*CONSTANT_1),&(v442_2));
            let v442_4: Space = if has_head(&(v442_3)) { singleton(&[]) } else { Space::new() };
            drop(v442_3);
            let v442_5: Space = subtract(&(*CONSTANT_0),&(v442_4));
            drop(v442_4);
            let v442_8: Space = if (v442_5).is_empty() { Space::new() } else {
              let v443_6: Path = concat_path(&(v441_6),&(v441_7_head));
              let v443_7: Space = routine_38(c, &(v443_6), &(v441_7_tail).make_space());
              compose(&(v442_5),&(v443_7))
            };
            drop(v442_5);
            let v442_9: Space = intersect(&(*CONSTANT_1),&(v442_2));
            drop(v442_2);
            let v442_10: Space = if has_head(&(v442_9)) { singleton(&[]) } else { Space::new() };
            drop(v442_9);
            let v442_12: Space = if (v442_10).is_empty() { Space::new() } else {
              let v444_6: Path = concat_path(&(v441_6),&(v441_7_head));
              let v444_11: Space = routine_39(c, &(v444_6), &(v441_7_tail).make_space());
              drop(v444_6);
              compose(&(v442_10),&(v444_11))
            };
            drop(v442_10);
            let v442_13: Space = unite(&(v442_8),&(v442_12));
            v441_7.join_into((v442_13).clone());
            }
            v441_7_cursor.ascend(1);
          }
          drop(v441_7_cursor);
          compose(&(v440_5),&(v441_7))
        };
        drop(v440_5);
        let v440_9: Space = intersect(&(*CONSTANT_1),&(v440_2));
        drop(v440_2);
        let v440_10: Space = if has_head(&(v440_9)) { singleton(&[]) } else { Space::new() };
        drop(v440_9);
        let v440_12: Space = if (v440_10).is_empty() { Space::new() } else {
          let v445_6: Path = concat_path(&(v439_6),&(v439_7_head));
          let mut v445_11 = Space::new();
          let mut v445_11_cursor = (v439_7_tail).read_zipper();
          for v445_11_byte in v445_11_cursor.child_mask().iter() {
            v445_11_cursor.descend_to_byte(v445_11_byte);
            {
            let v445_11_tail = v445_11_cursor.fork_read_zipper();
            let v445_11_head = Path::from_slice(&[v445_11_byte]);
            let v446_2: Space = singleton(&(v445_11_head));
            let v446_3: Space = intersect(&(*CONSTANT_1),&(v446_2));
            let v446_4: Space = if has_head(&(v446_3)) { singleton(&[]) } else { Space::new() };
            drop(v446_3);
            let v446_5: Space = subtract(&(*CONSTANT_0),&(v446_4));
            drop(v446_4);
            let v446_8: Space = if (v446_5).is_empty() { Space::new() } else {
              let v447_6: Path = concat_path(&(v445_6),&(v445_11_head));
              let v447_7: Space = routine_38(c, &(v447_6), &(v445_11_tail).make_space());
              compose(&(v446_5),&(v447_7))
            };
            drop(v446_5);
            let v446_9: Space = intersect(&(*CONSTANT_1),&(v446_2));
            drop(v446_2);
            let v446_10: Space = if has_head(&(v446_9)) { singleton(&[]) } else { Space::new() };
            drop(v446_9);
            let v446_12: Space = if (v446_10).is_empty() { Space::new() } else {
              let v448_6: Path = concat_path(&(v445_6),&(v445_11_head));
              let v448_11: Space = routine_12(c, &(v448_6), &(v445_11_tail).make_space());
              drop(v448_6);
              compose(&(v446_10),&(v448_11))
            };
            drop(v446_10);
            let v446_13: Space = unite(&(v446_8),&(v446_12));
            v445_11.join_into((v446_13).clone());
            }
            v445_11_cursor.ascend(1);
          }
          drop(v445_11_cursor);
          drop(v445_6);
          compose(&(v440_10),&(v445_11))
        };
        drop(v440_10);
        let v440_13: Space = unite(&(v440_8),&(v440_12));
        v439_7.join_into((v440_13).clone());
        }
        v439_7_cursor.ascend(1);
      }
      drop(v439_7_cursor);
      compose(&(v438_5),&(v439_7))
    };
    drop(v438_5);
    let v438_9: Space = intersect(&(*CONSTANT_1),&(v438_2));
    drop(v438_2);
    let v438_10: Space = if has_head(&(v438_9)) { singleton(&[]) } else { Space::new() };
    drop(v438_9);
    let v438_12: Space = if (v438_10).is_empty() { Space::new() } else {
      let v449_6: Path = concat_path(&(*p0),&(v437_20_head));
      let mut v449_11 = Space::new();
      let mut v449_11_cursor = (v437_20_tail).read_zipper();
      for v449_11_byte in v449_11_cursor.child_mask().iter() {
        v449_11_cursor.descend_to_byte(v449_11_byte);
        {
        let v449_11_tail = v449_11_cursor.fork_read_zipper();
        let v449_11_head = Path::from_slice(&[v449_11_byte]);
        let v450_2: Space = singleton(&(v449_11_head));
        let v450_3: Space = intersect(&(*CONSTANT_1),&(v450_2));
        let v450_4: Space = if has_head(&(v450_3)) { singleton(&[]) } else { Space::new() };
        drop(v450_3);
        let v450_5: Space = subtract(&(*CONSTANT_0),&(v450_4));
        drop(v450_4);
        let v450_8: Space = if (v450_5).is_empty() { Space::new() } else {
          let v451_6: Path = concat_path(&(v449_6),&(v449_11_head));
          let mut v451_7 = Space::new();
          let mut v451_7_cursor = (v449_11_tail).read_zipper();
          for v451_7_byte in v451_7_cursor.child_mask().iter() {
            v451_7_cursor.descend_to_byte(v451_7_byte);
            {
            let v451_7_tail = v451_7_cursor.fork_read_zipper();
            let v451_7_head = Path::from_slice(&[v451_7_byte]);
            let v452_2: Space = singleton(&(v451_7_head));
            let v452_3: Space = intersect(&(*CONSTANT_1),&(v452_2));
            let v452_4: Space = if has_head(&(v452_3)) { singleton(&[]) } else { Space::new() };
            drop(v452_3);
            let v452_5: Space = subtract(&(*CONSTANT_0),&(v452_4));
            drop(v452_4);
            let v452_8: Space = if (v452_5).is_empty() { Space::new() } else {
              let v453_6: Path = concat_path(&(v451_6),&(v451_7_head));
              let v453_7: Space = routine_38(c, &(v453_6), &(v451_7_tail).make_space());
              compose(&(v452_5),&(v453_7))
            };
            drop(v452_5);
            let v452_9: Space = intersect(&(*CONSTANT_1),&(v452_2));
            drop(v452_2);
            let v452_10: Space = if has_head(&(v452_9)) { singleton(&[]) } else { Space::new() };
            drop(v452_9);
            let v452_12: Space = if (v452_10).is_empty() { Space::new() } else {
              let v454_6: Path = concat_path(&(v451_6),&(v451_7_head));
              let v454_11: Space = routine_39(c, &(v454_6), &(v451_7_tail).make_space());
              drop(v454_6);
              compose(&(v452_10),&(v454_11))
            };
            drop(v452_10);
            let v452_13: Space = unite(&(v452_8),&(v452_12));
            v451_7.join_into((v452_13).clone());
            }
            v451_7_cursor.ascend(1);
          }
          drop(v451_7_cursor);
          drop(v451_6);
          compose(&(v450_5),&(v451_7))
        };
        drop(v450_5);
        let v450_9: Space = intersect(&(*CONSTANT_1),&(v450_2));
        drop(v450_2);
        let v450_10: Space = if has_head(&(v450_9)) { singleton(&[]) } else { Space::new() };
        drop(v450_9);
        let v450_11: Space = compose(&(v450_10),&(v449_11_tail));
        drop(v450_10);
        let v450_12: Space = unite(&(v450_8),&(v450_11));
        drop(v450_11);
        v449_11.join_into((v450_12).clone());
        }
        v449_11_cursor.ascend(1);
      }
      drop(v449_11_cursor);
      drop(v449_6);
      compose(&(v438_10),&(v449_11))
    };
    drop(v438_10);
    let v438_13: Space = unite(&(v438_8),&(v438_12));
    v437_20.join_into((v438_13).clone());
    }
    v437_20_cursor.ascend(1);
  }
  drop(v437_20_cursor);
  (v437_20).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v455_14 = Space::new();
  let mut v455_14_cursor = (*s0).read_zipper();
  for v455_14_byte in v455_14_cursor.child_mask().iter() {
    v455_14_cursor.descend_to_byte(v455_14_byte);
    {
    let v455_14_tail = v455_14_cursor.fork_read_zipper();
    let v455_14_head = Path::from_slice(&[v455_14_byte]);
    let v456_2: Space = singleton(&(v455_14_head));
    let v456_3: Space = intersect(&(*CONSTANT_1),&(v456_2));
    let v456_4: Space = if has_head(&(v456_3)) { singleton(&[]) } else { Space::new() };
    drop(v456_3);
    let v456_5: Space = subtract(&(*CONSTANT_0),&(v456_4));
    drop(v456_4);
    let v456_8: Space = if (v456_5).is_empty() { Space::new() } else {
      let v457_6: Path = concat_path(&(*p0),&(v455_14_head));
      let mut v457_7 = Space::new();
      let mut v457_7_cursor = (v455_14_tail).read_zipper();
      for v457_7_byte in v457_7_cursor.child_mask().iter() {
        v457_7_cursor.descend_to_byte(v457_7_byte);
        {
        let v457_7_tail = v457_7_cursor.fork_read_zipper();
        let v457_7_head = Path::from_slice(&[v457_7_byte]);
        let v458_2: Space = singleton(&(v457_7_head));
        let v458_3: Space = intersect(&(*CONSTANT_1),&(v458_2));
        let v458_4: Space = if has_head(&(v458_3)) { singleton(&[]) } else { Space::new() };
        drop(v458_3);
        let v458_5: Space = subtract(&(*CONSTANT_0),&(v458_4));
        drop(v458_4);
        let v458_8: Space = if (v458_5).is_empty() { Space::new() } else {
          let v459_6: Path = concat_path(&(v457_6),&(v457_7_head));
          let mut v459_7 = Space::new();
          let mut v459_7_cursor = (v457_7_tail).read_zipper();
          for v459_7_byte in v459_7_cursor.child_mask().iter() {
            v459_7_cursor.descend_to_byte(v459_7_byte);
            {
            let v459_7_tail = v459_7_cursor.fork_read_zipper();
            let v459_7_head = Path::from_slice(&[v459_7_byte]);
            let v460_2: Space = singleton(&(v459_7_head));
            let v460_3: Space = intersect(&(*CONSTANT_1),&(v460_2));
            let v460_4: Space = if has_head(&(v460_3)) { singleton(&[]) } else { Space::new() };
            drop(v460_3);
            let v460_5: Space = subtract(&(*CONSTANT_0),&(v460_4));
            drop(v460_4);
            let v460_8: Space = if (v460_5).is_empty() { Space::new() } else {
              let v461_6: Path = concat_path(&(v459_6),&(v459_7_head));
              let v461_7: Space = routine_38(c, &(v461_6), &(v459_7_tail).make_space());
              compose(&(v460_5),&(v461_7))
            };
            drop(v460_5);
            let v460_9: Space = intersect(&(*CONSTANT_1),&(v460_2));
            drop(v460_2);
            let v460_10: Space = if has_head(&(v460_9)) { singleton(&[]) } else { Space::new() };
            drop(v460_9);
            let v460_12: Space = if (v460_10).is_empty() { Space::new() } else {
              let v462_6: Path = concat_path(&(v459_6),&(v459_7_head));
              let v462_11: Space = routine_39(c, &(v462_6), &(v459_7_tail).make_space());
              drop(v462_6);
              compose(&(v460_10),&(v462_11))
            };
            drop(v460_10);
            let v460_13: Space = unite(&(v460_8),&(v460_12));
            v459_7.join_into((v460_13).clone());
            }
            v459_7_cursor.ascend(1);
          }
          drop(v459_7_cursor);
          compose(&(v458_5),&(v459_7))
        };
        drop(v458_5);
        let v458_9: Space = intersect(&(*CONSTANT_1),&(v458_2));
        drop(v458_2);
        let v458_10: Space = if has_head(&(v458_9)) { singleton(&[]) } else { Space::new() };
        drop(v458_9);
        let v458_12: Space = if (v458_10).is_empty() { Space::new() } else {
          let v463_6: Path = concat_path(&(v457_6),&(v457_7_head));
          let mut v463_11 = Space::new();
          let mut v463_11_cursor = (v457_7_tail).read_zipper();
          for v463_11_byte in v463_11_cursor.child_mask().iter() {
            v463_11_cursor.descend_to_byte(v463_11_byte);
            {
            let v463_11_tail = v463_11_cursor.fork_read_zipper();
            let v463_11_head = Path::from_slice(&[v463_11_byte]);
            let v464_2: Space = singleton(&(v463_11_head));
            let v464_3: Space = intersect(&(*CONSTANT_1),&(v464_2));
            let v464_4: Space = if has_head(&(v464_3)) { singleton(&[]) } else { Space::new() };
            drop(v464_3);
            let v464_5: Space = subtract(&(*CONSTANT_0),&(v464_4));
            drop(v464_4);
            let v464_8: Space = if (v464_5).is_empty() { Space::new() } else {
              let v465_6: Path = concat_path(&(v463_6),&(v463_11_head));
              let v465_7: Space = routine_38(c, &(v465_6), &(v463_11_tail).make_space());
              compose(&(v464_5),&(v465_7))
            };
            drop(v464_5);
            let v464_9: Space = intersect(&(*CONSTANT_1),&(v464_2));
            drop(v464_2);
            let v464_10: Space = if has_head(&(v464_9)) { singleton(&[]) } else { Space::new() };
            drop(v464_9);
            let v464_12: Space = if (v464_10).is_empty() { Space::new() } else {
              let v466_6: Path = concat_path(&(v463_6),&(v463_11_head));
              let v466_11: Space = routine_12(c, &(v466_6), &(v463_11_tail).make_space());
              drop(v466_6);
              compose(&(v464_10),&(v466_11))
            };
            drop(v464_10);
            let v464_13: Space = unite(&(v464_8),&(v464_12));
            v463_11.join_into((v464_13).clone());
            }
            v463_11_cursor.ascend(1);
          }
          drop(v463_11_cursor);
          drop(v463_6);
          compose(&(v458_10),&(v463_11))
        };
        drop(v458_10);
        let v458_13: Space = unite(&(v458_8),&(v458_12));
        v457_7.join_into((v458_13).clone());
        }
        v457_7_cursor.ascend(1);
      }
      drop(v457_7_cursor);
      drop(v457_6);
      compose(&(v456_5),&(v457_7))
    };
    drop(v456_5);
    let v456_9: Space = intersect(&(*CONSTANT_1),&(v456_2));
    drop(v456_2);
    let v456_10: Space = if has_head(&(v456_9)) { singleton(&[]) } else { Space::new() };
    drop(v456_9);
    let v456_11: Space = compose(&(v456_10),&(v455_14_tail));
    drop(v456_10);
    let v456_12: Space = unite(&(v456_8),&(v456_11));
    drop(v456_11);
    v455_14.join_into((v456_12).clone());
    }
    v455_14_cursor.ascend(1);
  }
  drop(v455_14_cursor);
  (v455_14).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v467_20 = Space::new();
  let mut v467_20_cursor = (*s0).read_zipper();
  for v467_20_byte in v467_20_cursor.child_mask().iter() {
    v467_20_cursor.descend_to_byte(v467_20_byte);
    {
    let v467_20_tail = v467_20_cursor.fork_read_zipper();
    let v467_20_head = Path::from_slice(&[v467_20_byte]);
    let v468_2: Space = singleton(&(v467_20_head));
    let v468_3: Space = intersect(&(*CONSTANT_1),&(v468_2));
    let v468_4: Space = if has_head(&(v468_3)) { singleton(&[]) } else { Space::new() };
    drop(v468_3);
    let v468_5: Space = subtract(&(*CONSTANT_0),&(v468_4));
    drop(v468_4);
    let v468_8: Space = if (v468_5).is_empty() { Space::new() } else {
      let v469_6: Path = concat_path(&(*p0),&(v467_20_head));
      let mut v469_7 = Space::new();
      let mut v469_7_cursor = (v467_20_tail).read_zipper();
      for v469_7_byte in v469_7_cursor.child_mask().iter() {
        v469_7_cursor.descend_to_byte(v469_7_byte);
        {
        let v469_7_tail = v469_7_cursor.fork_read_zipper();
        let v469_7_head = Path::from_slice(&[v469_7_byte]);
        let v470_2: Space = singleton(&(v469_7_head));
        let v470_3: Space = intersect(&(*CONSTANT_1),&(v470_2));
        let v470_4: Space = if has_head(&(v470_3)) { singleton(&[]) } else { Space::new() };
        drop(v470_3);
        let v470_5: Space = subtract(&(*CONSTANT_0),&(v470_4));
        drop(v470_4);
        let v470_8: Space = if (v470_5).is_empty() { Space::new() } else {
          let v471_6: Path = concat_path(&(v469_6),&(v469_7_head));
          let mut v471_7 = Space::new();
          let mut v471_7_cursor = (v469_7_tail).read_zipper();
          for v471_7_byte in v471_7_cursor.child_mask().iter() {
            v471_7_cursor.descend_to_byte(v471_7_byte);
            {
            let v471_7_tail = v471_7_cursor.fork_read_zipper();
            let v471_7_head = Path::from_slice(&[v471_7_byte]);
            let v472_2: Space = singleton(&(v471_7_head));
            let v472_3: Space = intersect(&(*CONSTANT_1),&(v472_2));
            let v472_4: Space = if has_head(&(v472_3)) { singleton(&[]) } else { Space::new() };
            drop(v472_3);
            let v472_5: Space = subtract(&(*CONSTANT_0),&(v472_4));
            drop(v472_4);
            let v472_8: Space = if (v472_5).is_empty() { Space::new() } else {
              let v473_6: Path = concat_path(&(v471_6),&(v471_7_head));
              let v473_7: Space = routine_40(c, &(v473_6), &(v471_7_tail).make_space());
              compose(&(v472_5),&(v473_7))
            };
            drop(v472_5);
            let v472_9: Space = intersect(&(*CONSTANT_1),&(v472_2));
            drop(v472_2);
            let v472_10: Space = if has_head(&(v472_9)) { singleton(&[]) } else { Space::new() };
            drop(v472_9);
            let v472_12: Space = if (v472_10).is_empty() { Space::new() } else {
              let v474_6: Path = concat_path(&(v471_6),&(v471_7_head));
              let v474_11: Space = routine_41(c, &(v474_6), &(v471_7_tail).make_space());
              drop(v474_6);
              compose(&(v472_10),&(v474_11))
            };
            drop(v472_10);
            let v472_13: Space = unite(&(v472_8),&(v472_12));
            v471_7.join_into((v472_13).clone());
            }
            v471_7_cursor.ascend(1);
          }
          drop(v471_7_cursor);
          compose(&(v470_5),&(v471_7))
        };
        drop(v470_5);
        let v470_9: Space = intersect(&(*CONSTANT_1),&(v470_2));
        drop(v470_2);
        let v470_10: Space = if has_head(&(v470_9)) { singleton(&[]) } else { Space::new() };
        drop(v470_9);
        let v470_12: Space = if (v470_10).is_empty() { Space::new() } else {
          let v475_6: Path = concat_path(&(v469_6),&(v469_7_head));
          let mut v475_11 = Space::new();
          let mut v475_11_cursor = (v469_7_tail).read_zipper();
          for v475_11_byte in v475_11_cursor.child_mask().iter() {
            v475_11_cursor.descend_to_byte(v475_11_byte);
            {
            let v475_11_tail = v475_11_cursor.fork_read_zipper();
            let v475_11_head = Path::from_slice(&[v475_11_byte]);
            let v476_2: Space = singleton(&(v475_11_head));
            let v476_3: Space = intersect(&(*CONSTANT_1),&(v476_2));
            let v476_4: Space = if has_head(&(v476_3)) { singleton(&[]) } else { Space::new() };
            drop(v476_3);
            let v476_5: Space = subtract(&(*CONSTANT_0),&(v476_4));
            drop(v476_4);
            let v476_8: Space = if (v476_5).is_empty() { Space::new() } else {
              let v477_6: Path = concat_path(&(v475_6),&(v475_11_head));
              let v477_7: Space = routine_40(c, &(v477_6), &(v475_11_tail).make_space());
              compose(&(v476_5),&(v477_7))
            };
            drop(v476_5);
            let v476_9: Space = intersect(&(*CONSTANT_1),&(v476_2));
            drop(v476_2);
            let v476_10: Space = if has_head(&(v476_9)) { singleton(&[]) } else { Space::new() };
            drop(v476_9);
            let v476_12: Space = if (v476_10).is_empty() { Space::new() } else {
              let v478_6: Path = concat_path(&(v475_6),&(v475_11_head));
              let v478_11: Space = routine_15(c, &(v478_6), &(v475_11_tail).make_space());
              drop(v478_6);
              compose(&(v476_10),&(v478_11))
            };
            drop(v476_10);
            let v476_13: Space = unite(&(v476_8),&(v476_12));
            v475_11.join_into((v476_13).clone());
            }
            v475_11_cursor.ascend(1);
          }
          drop(v475_11_cursor);
          drop(v475_6);
          compose(&(v470_10),&(v475_11))
        };
        drop(v470_10);
        let v470_13: Space = unite(&(v470_8),&(v470_12));
        v469_7.join_into((v470_13).clone());
        }
        v469_7_cursor.ascend(1);
      }
      drop(v469_7_cursor);
      compose(&(v468_5),&(v469_7))
    };
    drop(v468_5);
    let v468_9: Space = intersect(&(*CONSTANT_1),&(v468_2));
    drop(v468_2);
    let v468_10: Space = if has_head(&(v468_9)) { singleton(&[]) } else { Space::new() };
    drop(v468_9);
    let v468_12: Space = if (v468_10).is_empty() { Space::new() } else {
      let v479_6: Path = concat_path(&(*p0),&(v467_20_head));
      let mut v479_11 = Space::new();
      let mut v479_11_cursor = (v467_20_tail).read_zipper();
      for v479_11_byte in v479_11_cursor.child_mask().iter() {
        v479_11_cursor.descend_to_byte(v479_11_byte);
        {
        let v479_11_tail = v479_11_cursor.fork_read_zipper();
        let v479_11_head = Path::from_slice(&[v479_11_byte]);
        let v480_2: Space = singleton(&(v479_11_head));
        let v480_3: Space = intersect(&(*CONSTANT_1),&(v480_2));
        let v480_4: Space = if has_head(&(v480_3)) { singleton(&[]) } else { Space::new() };
        drop(v480_3);
        let v480_5: Space = subtract(&(*CONSTANT_0),&(v480_4));
        drop(v480_4);
        let v480_8: Space = if (v480_5).is_empty() { Space::new() } else {
          let v481_6: Path = concat_path(&(v479_6),&(v479_11_head));
          let mut v481_7 = Space::new();
          let mut v481_7_cursor = (v479_11_tail).read_zipper();
          for v481_7_byte in v481_7_cursor.child_mask().iter() {
            v481_7_cursor.descend_to_byte(v481_7_byte);
            {
            let v481_7_tail = v481_7_cursor.fork_read_zipper();
            let v481_7_head = Path::from_slice(&[v481_7_byte]);
            let v482_2: Space = singleton(&(v481_7_head));
            let v482_3: Space = intersect(&(*CONSTANT_1),&(v482_2));
            let v482_4: Space = if has_head(&(v482_3)) { singleton(&[]) } else { Space::new() };
            drop(v482_3);
            let v482_5: Space = subtract(&(*CONSTANT_0),&(v482_4));
            drop(v482_4);
            let v482_8: Space = if (v482_5).is_empty() { Space::new() } else {
              let v483_6: Path = concat_path(&(v481_6),&(v481_7_head));
              let v483_7: Space = routine_40(c, &(v483_6), &(v481_7_tail).make_space());
              compose(&(v482_5),&(v483_7))
            };
            drop(v482_5);
            let v482_9: Space = intersect(&(*CONSTANT_1),&(v482_2));
            drop(v482_2);
            let v482_10: Space = if has_head(&(v482_9)) { singleton(&[]) } else { Space::new() };
            drop(v482_9);
            let v482_12: Space = if (v482_10).is_empty() { Space::new() } else {
              let v484_6: Path = concat_path(&(v481_6),&(v481_7_head));
              let v484_11: Space = routine_41(c, &(v484_6), &(v481_7_tail).make_space());
              drop(v484_6);
              compose(&(v482_10),&(v484_11))
            };
            drop(v482_10);
            let v482_13: Space = unite(&(v482_8),&(v482_12));
            v481_7.join_into((v482_13).clone());
            }
            v481_7_cursor.ascend(1);
          }
          drop(v481_7_cursor);
          drop(v481_6);
          compose(&(v480_5),&(v481_7))
        };
        drop(v480_5);
        let v480_9: Space = intersect(&(*CONSTANT_1),&(v480_2));
        drop(v480_2);
        let v480_10: Space = if has_head(&(v480_9)) { singleton(&[]) } else { Space::new() };
        drop(v480_9);
        let v480_11: Space = compose(&(v480_10),&(v479_11_tail));
        drop(v480_10);
        let v480_12: Space = unite(&(v480_8),&(v480_11));
        drop(v480_11);
        v479_11.join_into((v480_12).clone());
        }
        v479_11_cursor.ascend(1);
      }
      drop(v479_11_cursor);
      drop(v479_6);
      compose(&(v468_10),&(v479_11))
    };
    drop(v468_10);
    let v468_13: Space = unite(&(v468_8),&(v468_12));
    v467_20.join_into((v468_13).clone());
    }
    v467_20_cursor.ascend(1);
  }
  drop(v467_20_cursor);
  (v467_20).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v485_14 = Space::new();
  let mut v485_14_cursor = (*s0).read_zipper();
  for v485_14_byte in v485_14_cursor.child_mask().iter() {
    v485_14_cursor.descend_to_byte(v485_14_byte);
    {
    let v485_14_tail = v485_14_cursor.fork_read_zipper();
    let v485_14_head = Path::from_slice(&[v485_14_byte]);
    let v486_2: Space = singleton(&(v485_14_head));
    let v486_3: Space = intersect(&(*CONSTANT_1),&(v486_2));
    let v486_4: Space = if has_head(&(v486_3)) { singleton(&[]) } else { Space::new() };
    drop(v486_3);
    let v486_5: Space = subtract(&(*CONSTANT_0),&(v486_4));
    drop(v486_4);
    let v486_8: Space = if (v486_5).is_empty() { Space::new() } else {
      let v487_6: Path = concat_path(&(*p0),&(v485_14_head));
      let mut v487_7 = Space::new();
      let mut v487_7_cursor = (v485_14_tail).read_zipper();
      for v487_7_byte in v487_7_cursor.child_mask().iter() {
        v487_7_cursor.descend_to_byte(v487_7_byte);
        {
        let v487_7_tail = v487_7_cursor.fork_read_zipper();
        let v487_7_head = Path::from_slice(&[v487_7_byte]);
        let v488_2: Space = singleton(&(v487_7_head));
        let v488_3: Space = intersect(&(*CONSTANT_1),&(v488_2));
        let v488_4: Space = if has_head(&(v488_3)) { singleton(&[]) } else { Space::new() };
        drop(v488_3);
        let v488_5: Space = subtract(&(*CONSTANT_0),&(v488_4));
        drop(v488_4);
        let v488_8: Space = if (v488_5).is_empty() { Space::new() } else {
          let v489_6: Path = concat_path(&(v487_6),&(v487_7_head));
          let mut v489_7 = Space::new();
          let mut v489_7_cursor = (v487_7_tail).read_zipper();
          for v489_7_byte in v489_7_cursor.child_mask().iter() {
            v489_7_cursor.descend_to_byte(v489_7_byte);
            {
            let v489_7_tail = v489_7_cursor.fork_read_zipper();
            let v489_7_head = Path::from_slice(&[v489_7_byte]);
            let v490_2: Space = singleton(&(v489_7_head));
            let v490_3: Space = intersect(&(*CONSTANT_1),&(v490_2));
            let v490_4: Space = if has_head(&(v490_3)) { singleton(&[]) } else { Space::new() };
            drop(v490_3);
            let v490_5: Space = subtract(&(*CONSTANT_0),&(v490_4));
            drop(v490_4);
            let v490_8: Space = if (v490_5).is_empty() { Space::new() } else {
              let v491_6: Path = concat_path(&(v489_6),&(v489_7_head));
              let v491_7: Space = routine_40(c, &(v491_6), &(v489_7_tail).make_space());
              compose(&(v490_5),&(v491_7))
            };
            drop(v490_5);
            let v490_9: Space = intersect(&(*CONSTANT_1),&(v490_2));
            drop(v490_2);
            let v490_10: Space = if has_head(&(v490_9)) { singleton(&[]) } else { Space::new() };
            drop(v490_9);
            let v490_12: Space = if (v490_10).is_empty() { Space::new() } else {
              let v492_6: Path = concat_path(&(v489_6),&(v489_7_head));
              let v492_11: Space = routine_41(c, &(v492_6), &(v489_7_tail).make_space());
              drop(v492_6);
              compose(&(v490_10),&(v492_11))
            };
            drop(v490_10);
            let v490_13: Space = unite(&(v490_8),&(v490_12));
            v489_7.join_into((v490_13).clone());
            }
            v489_7_cursor.ascend(1);
          }
          drop(v489_7_cursor);
          compose(&(v488_5),&(v489_7))
        };
        drop(v488_5);
        let v488_9: Space = intersect(&(*CONSTANT_1),&(v488_2));
        drop(v488_2);
        let v488_10: Space = if has_head(&(v488_9)) { singleton(&[]) } else { Space::new() };
        drop(v488_9);
        let v488_12: Space = if (v488_10).is_empty() { Space::new() } else {
          let v493_6: Path = concat_path(&(v487_6),&(v487_7_head));
          let mut v493_11 = Space::new();
          let mut v493_11_cursor = (v487_7_tail).read_zipper();
          for v493_11_byte in v493_11_cursor.child_mask().iter() {
            v493_11_cursor.descend_to_byte(v493_11_byte);
            {
            let v493_11_tail = v493_11_cursor.fork_read_zipper();
            let v493_11_head = Path::from_slice(&[v493_11_byte]);
            let v494_2: Space = singleton(&(v493_11_head));
            let v494_3: Space = intersect(&(*CONSTANT_1),&(v494_2));
            let v494_4: Space = if has_head(&(v494_3)) { singleton(&[]) } else { Space::new() };
            drop(v494_3);
            let v494_5: Space = subtract(&(*CONSTANT_0),&(v494_4));
            drop(v494_4);
            let v494_8: Space = if (v494_5).is_empty() { Space::new() } else {
              let v495_6: Path = concat_path(&(v493_6),&(v493_11_head));
              let v495_7: Space = routine_40(c, &(v495_6), &(v493_11_tail).make_space());
              compose(&(v494_5),&(v495_7))
            };
            drop(v494_5);
            let v494_9: Space = intersect(&(*CONSTANT_1),&(v494_2));
            drop(v494_2);
            let v494_10: Space = if has_head(&(v494_9)) { singleton(&[]) } else { Space::new() };
            drop(v494_9);
            let v494_12: Space = if (v494_10).is_empty() { Space::new() } else {
              let v496_6: Path = concat_path(&(v493_6),&(v493_11_head));
              let v496_11: Space = routine_15(c, &(v496_6), &(v493_11_tail).make_space());
              drop(v496_6);
              compose(&(v494_10),&(v496_11))
            };
            drop(v494_10);
            let v494_13: Space = unite(&(v494_8),&(v494_12));
            v493_11.join_into((v494_13).clone());
            }
            v493_11_cursor.ascend(1);
          }
          drop(v493_11_cursor);
          drop(v493_6);
          compose(&(v488_10),&(v493_11))
        };
        drop(v488_10);
        let v488_13: Space = unite(&(v488_8),&(v488_12));
        v487_7.join_into((v488_13).clone());
        }
        v487_7_cursor.ascend(1);
      }
      drop(v487_7_cursor);
      drop(v487_6);
      compose(&(v486_5),&(v487_7))
    };
    drop(v486_5);
    let v486_9: Space = intersect(&(*CONSTANT_1),&(v486_2));
    drop(v486_2);
    let v486_10: Space = if has_head(&(v486_9)) { singleton(&[]) } else { Space::new() };
    drop(v486_9);
    let v486_11: Space = compose(&(v486_10),&(v485_14_tail));
    drop(v486_10);
    let v486_12: Space = unite(&(v486_8),&(v486_11));
    drop(v486_11);
    v485_14.join_into((v486_12).clone());
    }
    v485_14_cursor.ascend(1);
  }
  drop(v485_14_cursor);
  (v485_14).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v497_20 = Space::new();
  let mut v497_20_cursor = (*s0).read_zipper();
  for v497_20_byte in v497_20_cursor.child_mask().iter() {
    v497_20_cursor.descend_to_byte(v497_20_byte);
    {
    let v497_20_tail = v497_20_cursor.fork_read_zipper();
    let v497_20_head = Path::from_slice(&[v497_20_byte]);
    let v498_2: Space = singleton(&(v497_20_head));
    let v498_3: Space = intersect(&(*CONSTANT_1),&(v498_2));
    let v498_4: Space = if has_head(&(v498_3)) { singleton(&[]) } else { Space::new() };
    drop(v498_3);
    let v498_5: Space = subtract(&(*CONSTANT_0),&(v498_4));
    drop(v498_4);
    let v498_8: Space = if (v498_5).is_empty() { Space::new() } else {
      let v499_6: Path = concat_path(&(*p0),&(v497_20_head));
      let mut v499_7 = Space::new();
      let mut v499_7_cursor = (v497_20_tail).read_zipper();
      for v499_7_byte in v499_7_cursor.child_mask().iter() {
        v499_7_cursor.descend_to_byte(v499_7_byte);
        {
        let v499_7_tail = v499_7_cursor.fork_read_zipper();
        let v499_7_head = Path::from_slice(&[v499_7_byte]);
        let v500_2: Space = singleton(&(v499_7_head));
        let v500_3: Space = intersect(&(*CONSTANT_1),&(v500_2));
        let v500_4: Space = if has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
        drop(v500_3);
        let v500_5: Space = subtract(&(*CONSTANT_0),&(v500_4));
        drop(v500_4);
        let v500_8: Space = if (v500_5).is_empty() { Space::new() } else {
          let v501_6: Path = concat_path(&(v499_6),&(v499_7_head));
          let mut v501_7 = Space::new();
          let mut v501_7_cursor = (v499_7_tail).read_zipper();
          for v501_7_byte in v501_7_cursor.child_mask().iter() {
            v501_7_cursor.descend_to_byte(v501_7_byte);
            {
            let v501_7_tail = v501_7_cursor.fork_read_zipper();
            let v501_7_head = Path::from_slice(&[v501_7_byte]);
            let v502_2: Space = singleton(&(v501_7_head));
            let v502_3: Space = intersect(&(*CONSTANT_1),&(v502_2));
            let v502_4: Space = if has_head(&(v502_3)) { singleton(&[]) } else { Space::new() };
            drop(v502_3);
            let v502_5: Space = subtract(&(*CONSTANT_0),&(v502_4));
            drop(v502_4);
            let v502_8: Space = if (v502_5).is_empty() { Space::new() } else {
              let v503_6: Path = concat_path(&(v501_6),&(v501_7_head));
              let v503_7: Space = routine_42(c, &(v503_6), &(v501_7_tail).make_space());
              compose(&(v502_5),&(v503_7))
            };
            drop(v502_5);
            let v502_9: Space = intersect(&(*CONSTANT_1),&(v502_2));
            drop(v502_2);
            let v502_10: Space = if has_head(&(v502_9)) { singleton(&[]) } else { Space::new() };
            drop(v502_9);
            let v502_12: Space = if (v502_10).is_empty() { Space::new() } else {
              let v504_6: Path = concat_path(&(v501_6),&(v501_7_head));
              let v504_11: Space = routine_43(c, &(v504_6), &(v501_7_tail).make_space());
              drop(v504_6);
              compose(&(v502_10),&(v504_11))
            };
            drop(v502_10);
            let v502_13: Space = unite(&(v502_8),&(v502_12));
            v501_7.join_into((v502_13).clone());
            }
            v501_7_cursor.ascend(1);
          }
          drop(v501_7_cursor);
          compose(&(v500_5),&(v501_7))
        };
        drop(v500_5);
        let v500_9: Space = intersect(&(*CONSTANT_1),&(v500_2));
        drop(v500_2);
        let v500_10: Space = if has_head(&(v500_9)) { singleton(&[]) } else { Space::new() };
        drop(v500_9);
        let v500_12: Space = if (v500_10).is_empty() { Space::new() } else {
          let v505_6: Path = concat_path(&(v499_6),&(v499_7_head));
          let mut v505_11 = Space::new();
          let mut v505_11_cursor = (v499_7_tail).read_zipper();
          for v505_11_byte in v505_11_cursor.child_mask().iter() {
            v505_11_cursor.descend_to_byte(v505_11_byte);
            {
            let v505_11_tail = v505_11_cursor.fork_read_zipper();
            let v505_11_head = Path::from_slice(&[v505_11_byte]);
            let v506_2: Space = singleton(&(v505_11_head));
            let v506_3: Space = intersect(&(*CONSTANT_1),&(v506_2));
            let v506_4: Space = if has_head(&(v506_3)) { singleton(&[]) } else { Space::new() };
            drop(v506_3);
            let v506_5: Space = subtract(&(*CONSTANT_0),&(v506_4));
            drop(v506_4);
            let v506_8: Space = if (v506_5).is_empty() { Space::new() } else {
              let v507_6: Path = concat_path(&(v505_6),&(v505_11_head));
              let v507_7: Space = routine_42(c, &(v507_6), &(v505_11_tail).make_space());
              compose(&(v506_5),&(v507_7))
            };
            drop(v506_5);
            let v506_9: Space = intersect(&(*CONSTANT_1),&(v506_2));
            drop(v506_2);
            let v506_10: Space = if has_head(&(v506_9)) { singleton(&[]) } else { Space::new() };
            drop(v506_9);
            let v506_12: Space = if (v506_10).is_empty() { Space::new() } else {
              let v508_6: Path = concat_path(&(v505_6),&(v505_11_head));
              let v508_11: Space = routine_12(c, &(v508_6), &(v505_11_tail).make_space());
              drop(v508_6);
              compose(&(v506_10),&(v508_11))
            };
            drop(v506_10);
            let v506_13: Space = unite(&(v506_8),&(v506_12));
            v505_11.join_into((v506_13).clone());
            }
            v505_11_cursor.ascend(1);
          }
          drop(v505_11_cursor);
          drop(v505_6);
          compose(&(v500_10),&(v505_11))
        };
        drop(v500_10);
        let v500_13: Space = unite(&(v500_8),&(v500_12));
        v499_7.join_into((v500_13).clone());
        }
        v499_7_cursor.ascend(1);
      }
      drop(v499_7_cursor);
      compose(&(v498_5),&(v499_7))
    };
    drop(v498_5);
    let v498_9: Space = intersect(&(*CONSTANT_1),&(v498_2));
    drop(v498_2);
    let v498_10: Space = if has_head(&(v498_9)) { singleton(&[]) } else { Space::new() };
    drop(v498_9);
    let v498_12: Space = if (v498_10).is_empty() { Space::new() } else {
      let v509_6: Path = concat_path(&(*p0),&(v497_20_head));
      let mut v509_11 = Space::new();
      let mut v509_11_cursor = (v497_20_tail).read_zipper();
      for v509_11_byte in v509_11_cursor.child_mask().iter() {
        v509_11_cursor.descend_to_byte(v509_11_byte);
        {
        let v509_11_tail = v509_11_cursor.fork_read_zipper();
        let v509_11_head = Path::from_slice(&[v509_11_byte]);
        let v510_2: Space = singleton(&(v509_11_head));
        let v510_3: Space = intersect(&(*CONSTANT_1),&(v510_2));
        let v510_4: Space = if has_head(&(v510_3)) { singleton(&[]) } else { Space::new() };
        drop(v510_3);
        let v510_5: Space = subtract(&(*CONSTANT_0),&(v510_4));
        drop(v510_4);
        let v510_8: Space = if (v510_5).is_empty() { Space::new() } else {
          let v511_6: Path = concat_path(&(v509_6),&(v509_11_head));
          let mut v511_7 = Space::new();
          let mut v511_7_cursor = (v509_11_tail).read_zipper();
          for v511_7_byte in v511_7_cursor.child_mask().iter() {
            v511_7_cursor.descend_to_byte(v511_7_byte);
            {
            let v511_7_tail = v511_7_cursor.fork_read_zipper();
            let v511_7_head = Path::from_slice(&[v511_7_byte]);
            let v512_2: Space = singleton(&(v511_7_head));
            let v512_3: Space = intersect(&(*CONSTANT_1),&(v512_2));
            let v512_4: Space = if has_head(&(v512_3)) { singleton(&[]) } else { Space::new() };
            drop(v512_3);
            let v512_5: Space = subtract(&(*CONSTANT_0),&(v512_4));
            drop(v512_4);
            let v512_8: Space = if (v512_5).is_empty() { Space::new() } else {
              let v513_6: Path = concat_path(&(v511_6),&(v511_7_head));
              let v513_7: Space = routine_42(c, &(v513_6), &(v511_7_tail).make_space());
              compose(&(v512_5),&(v513_7))
            };
            drop(v512_5);
            let v512_9: Space = intersect(&(*CONSTANT_1),&(v512_2));
            drop(v512_2);
            let v512_10: Space = if has_head(&(v512_9)) { singleton(&[]) } else { Space::new() };
            drop(v512_9);
            let v512_12: Space = if (v512_10).is_empty() { Space::new() } else {
              let v514_6: Path = concat_path(&(v511_6),&(v511_7_head));
              let v514_11: Space = routine_43(c, &(v514_6), &(v511_7_tail).make_space());
              drop(v514_6);
              compose(&(v512_10),&(v514_11))
            };
            drop(v512_10);
            let v512_13: Space = unite(&(v512_8),&(v512_12));
            v511_7.join_into((v512_13).clone());
            }
            v511_7_cursor.ascend(1);
          }
          drop(v511_7_cursor);
          drop(v511_6);
          compose(&(v510_5),&(v511_7))
        };
        drop(v510_5);
        let v510_9: Space = intersect(&(*CONSTANT_1),&(v510_2));
        drop(v510_2);
        let v510_10: Space = if has_head(&(v510_9)) { singleton(&[]) } else { Space::new() };
        drop(v510_9);
        let v510_11: Space = compose(&(v510_10),&(v509_11_tail));
        drop(v510_10);
        let v510_12: Space = unite(&(v510_8),&(v510_11));
        drop(v510_11);
        v509_11.join_into((v510_12).clone());
        }
        v509_11_cursor.ascend(1);
      }
      drop(v509_11_cursor);
      drop(v509_6);
      compose(&(v498_10),&(v509_11))
    };
    drop(v498_10);
    let v498_13: Space = unite(&(v498_8),&(v498_12));
    v497_20.join_into((v498_13).clone());
    }
    v497_20_cursor.ascend(1);
  }
  drop(v497_20_cursor);
  (v497_20).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v515_14 = Space::new();
  let mut v515_14_cursor = (*s0).read_zipper();
  for v515_14_byte in v515_14_cursor.child_mask().iter() {
    v515_14_cursor.descend_to_byte(v515_14_byte);
    {
    let v515_14_tail = v515_14_cursor.fork_read_zipper();
    let v515_14_head = Path::from_slice(&[v515_14_byte]);
    let v516_2: Space = singleton(&(v515_14_head));
    let v516_3: Space = intersect(&(*CONSTANT_1),&(v516_2));
    let v516_4: Space = if has_head(&(v516_3)) { singleton(&[]) } else { Space::new() };
    drop(v516_3);
    let v516_5: Space = subtract(&(*CONSTANT_0),&(v516_4));
    drop(v516_4);
    let v516_8: Space = if (v516_5).is_empty() { Space::new() } else {
      let v517_6: Path = concat_path(&(*p0),&(v515_14_head));
      let mut v517_7 = Space::new();
      let mut v517_7_cursor = (v515_14_tail).read_zipper();
      for v517_7_byte in v517_7_cursor.child_mask().iter() {
        v517_7_cursor.descend_to_byte(v517_7_byte);
        {
        let v517_7_tail = v517_7_cursor.fork_read_zipper();
        let v517_7_head = Path::from_slice(&[v517_7_byte]);
        let v518_2: Space = singleton(&(v517_7_head));
        let v518_3: Space = intersect(&(*CONSTANT_1),&(v518_2));
        let v518_4: Space = if has_head(&(v518_3)) { singleton(&[]) } else { Space::new() };
        drop(v518_3);
        let v518_5: Space = subtract(&(*CONSTANT_0),&(v518_4));
        drop(v518_4);
        let v518_8: Space = if (v518_5).is_empty() { Space::new() } else {
          let v519_6: Path = concat_path(&(v517_6),&(v517_7_head));
          let mut v519_7 = Space::new();
          let mut v519_7_cursor = (v517_7_tail).read_zipper();
          for v519_7_byte in v519_7_cursor.child_mask().iter() {
            v519_7_cursor.descend_to_byte(v519_7_byte);
            {
            let v519_7_tail = v519_7_cursor.fork_read_zipper();
            let v519_7_head = Path::from_slice(&[v519_7_byte]);
            let v520_2: Space = singleton(&(v519_7_head));
            let v520_3: Space = intersect(&(*CONSTANT_1),&(v520_2));
            let v520_4: Space = if has_head(&(v520_3)) { singleton(&[]) } else { Space::new() };
            drop(v520_3);
            let v520_5: Space = subtract(&(*CONSTANT_0),&(v520_4));
            drop(v520_4);
            let v520_8: Space = if (v520_5).is_empty() { Space::new() } else {
              let v521_6: Path = concat_path(&(v519_6),&(v519_7_head));
              let v521_7: Space = routine_42(c, &(v521_6), &(v519_7_tail).make_space());
              compose(&(v520_5),&(v521_7))
            };
            drop(v520_5);
            let v520_9: Space = intersect(&(*CONSTANT_1),&(v520_2));
            drop(v520_2);
            let v520_10: Space = if has_head(&(v520_9)) { singleton(&[]) } else { Space::new() };
            drop(v520_9);
            let v520_12: Space = if (v520_10).is_empty() { Space::new() } else {
              let v522_6: Path = concat_path(&(v519_6),&(v519_7_head));
              let v522_11: Space = routine_43(c, &(v522_6), &(v519_7_tail).make_space());
              drop(v522_6);
              compose(&(v520_10),&(v522_11))
            };
            drop(v520_10);
            let v520_13: Space = unite(&(v520_8),&(v520_12));
            v519_7.join_into((v520_13).clone());
            }
            v519_7_cursor.ascend(1);
          }
          drop(v519_7_cursor);
          compose(&(v518_5),&(v519_7))
        };
        drop(v518_5);
        let v518_9: Space = intersect(&(*CONSTANT_1),&(v518_2));
        drop(v518_2);
        let v518_10: Space = if has_head(&(v518_9)) { singleton(&[]) } else { Space::new() };
        drop(v518_9);
        let v518_12: Space = if (v518_10).is_empty() { Space::new() } else {
          let v523_6: Path = concat_path(&(v517_6),&(v517_7_head));
          let mut v523_11 = Space::new();
          let mut v523_11_cursor = (v517_7_tail).read_zipper();
          for v523_11_byte in v523_11_cursor.child_mask().iter() {
            v523_11_cursor.descend_to_byte(v523_11_byte);
            {
            let v523_11_tail = v523_11_cursor.fork_read_zipper();
            let v523_11_head = Path::from_slice(&[v523_11_byte]);
            let v524_2: Space = singleton(&(v523_11_head));
            let v524_3: Space = intersect(&(*CONSTANT_1),&(v524_2));
            let v524_4: Space = if has_head(&(v524_3)) { singleton(&[]) } else { Space::new() };
            drop(v524_3);
            let v524_5: Space = subtract(&(*CONSTANT_0),&(v524_4));
            drop(v524_4);
            let v524_8: Space = if (v524_5).is_empty() { Space::new() } else {
              let v525_6: Path = concat_path(&(v523_6),&(v523_11_head));
              let v525_7: Space = routine_42(c, &(v525_6), &(v523_11_tail).make_space());
              compose(&(v524_5),&(v525_7))
            };
            drop(v524_5);
            let v524_9: Space = intersect(&(*CONSTANT_1),&(v524_2));
            drop(v524_2);
            let v524_10: Space = if has_head(&(v524_9)) { singleton(&[]) } else { Space::new() };
            drop(v524_9);
            let v524_12: Space = if (v524_10).is_empty() { Space::new() } else {
              let v526_6: Path = concat_path(&(v523_6),&(v523_11_head));
              let v526_11: Space = routine_12(c, &(v526_6), &(v523_11_tail).make_space());
              drop(v526_6);
              compose(&(v524_10),&(v526_11))
            };
            drop(v524_10);
            let v524_13: Space = unite(&(v524_8),&(v524_12));
            v523_11.join_into((v524_13).clone());
            }
            v523_11_cursor.ascend(1);
          }
          drop(v523_11_cursor);
          drop(v523_6);
          compose(&(v518_10),&(v523_11))
        };
        drop(v518_10);
        let v518_13: Space = unite(&(v518_8),&(v518_12));
        v517_7.join_into((v518_13).clone());
        }
        v517_7_cursor.ascend(1);
      }
      drop(v517_7_cursor);
      drop(v517_6);
      compose(&(v516_5),&(v517_7))
    };
    drop(v516_5);
    let v516_9: Space = intersect(&(*CONSTANT_1),&(v516_2));
    drop(v516_2);
    let v516_10: Space = if has_head(&(v516_9)) { singleton(&[]) } else { Space::new() };
    drop(v516_9);
    let v516_11: Space = compose(&(v516_10),&(v515_14_tail));
    drop(v516_10);
    let v516_12: Space = unite(&(v516_8),&(v516_11));
    drop(v516_11);
    v515_14.join_into((v516_12).clone());
    }
    v515_14_cursor.ascend(1);
  }
  drop(v515_14_cursor);
  (v515_14).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v527_20 = Space::new();
  let mut v527_20_cursor = (*s0).read_zipper();
  for v527_20_byte in v527_20_cursor.child_mask().iter() {
    v527_20_cursor.descend_to_byte(v527_20_byte);
    {
    let v527_20_tail = v527_20_cursor.fork_read_zipper();
    let v527_20_head = Path::from_slice(&[v527_20_byte]);
    let v528_2: Space = singleton(&(v527_20_head));
    let v528_3: Space = intersect(&(*CONSTANT_1),&(v528_2));
    let v528_4: Space = if has_head(&(v528_3)) { singleton(&[]) } else { Space::new() };
    drop(v528_3);
    let v528_5: Space = subtract(&(*CONSTANT_0),&(v528_4));
    drop(v528_4);
    let v528_8: Space = if (v528_5).is_empty() { Space::new() } else {
      let v529_6: Path = concat_path(&(*p0),&(v527_20_head));
      let mut v529_7 = Space::new();
      let mut v529_7_cursor = (v527_20_tail).read_zipper();
      for v529_7_byte in v529_7_cursor.child_mask().iter() {
        v529_7_cursor.descend_to_byte(v529_7_byte);
        {
        let v529_7_tail = v529_7_cursor.fork_read_zipper();
        let v529_7_head = Path::from_slice(&[v529_7_byte]);
        let v530_2: Space = singleton(&(v529_7_head));
        let v530_3: Space = intersect(&(*CONSTANT_1),&(v530_2));
        let v530_4: Space = if has_head(&(v530_3)) { singleton(&[]) } else { Space::new() };
        drop(v530_3);
        let v530_5: Space = subtract(&(*CONSTANT_0),&(v530_4));
        drop(v530_4);
        let v530_8: Space = if (v530_5).is_empty() { Space::new() } else {
          let v531_6: Path = concat_path(&(v529_6),&(v529_7_head));
          let mut v531_7 = Space::new();
          let mut v531_7_cursor = (v529_7_tail).read_zipper();
          for v531_7_byte in v531_7_cursor.child_mask().iter() {
            v531_7_cursor.descend_to_byte(v531_7_byte);
            {
            let v531_7_tail = v531_7_cursor.fork_read_zipper();
            let v531_7_head = Path::from_slice(&[v531_7_byte]);
            let v532_2: Space = singleton(&(v531_7_head));
            let v532_3: Space = intersect(&(*CONSTANT_1),&(v532_2));
            let v532_4: Space = if has_head(&(v532_3)) { singleton(&[]) } else { Space::new() };
            drop(v532_3);
            let v532_5: Space = subtract(&(*CONSTANT_0),&(v532_4));
            drop(v532_4);
            let v532_8: Space = if (v532_5).is_empty() { Space::new() } else {
              let v533_6: Path = concat_path(&(v531_6),&(v531_7_head));
              let v533_7: Space = routine_44(c, &(v533_6), &(v531_7_tail).make_space());
              compose(&(v532_5),&(v533_7))
            };
            drop(v532_5);
            let v532_9: Space = intersect(&(*CONSTANT_1),&(v532_2));
            drop(v532_2);
            let v532_10: Space = if has_head(&(v532_9)) { singleton(&[]) } else { Space::new() };
            drop(v532_9);
            let v532_12: Space = if (v532_10).is_empty() { Space::new() } else {
              let v534_6: Path = concat_path(&(v531_6),&(v531_7_head));
              let v534_11: Space = routine_45(c, &(v534_6), &(v531_7_tail).make_space());
              drop(v534_6);
              compose(&(v532_10),&(v534_11))
            };
            drop(v532_10);
            let v532_13: Space = unite(&(v532_8),&(v532_12));
            v531_7.join_into((v532_13).clone());
            }
            v531_7_cursor.ascend(1);
          }
          drop(v531_7_cursor);
          compose(&(v530_5),&(v531_7))
        };
        drop(v530_5);
        let v530_9: Space = intersect(&(*CONSTANT_1),&(v530_2));
        drop(v530_2);
        let v530_10: Space = if has_head(&(v530_9)) { singleton(&[]) } else { Space::new() };
        drop(v530_9);
        let v530_12: Space = if (v530_10).is_empty() { Space::new() } else {
          let v535_6: Path = concat_path(&(v529_6),&(v529_7_head));
          let mut v535_11 = Space::new();
          let mut v535_11_cursor = (v529_7_tail).read_zipper();
          for v535_11_byte in v535_11_cursor.child_mask().iter() {
            v535_11_cursor.descend_to_byte(v535_11_byte);
            {
            let v535_11_tail = v535_11_cursor.fork_read_zipper();
            let v535_11_head = Path::from_slice(&[v535_11_byte]);
            let v536_2: Space = singleton(&(v535_11_head));
            let v536_3: Space = intersect(&(*CONSTANT_1),&(v536_2));
            let v536_4: Space = if has_head(&(v536_3)) { singleton(&[]) } else { Space::new() };
            drop(v536_3);
            let v536_5: Space = subtract(&(*CONSTANT_0),&(v536_4));
            drop(v536_4);
            let v536_8: Space = if (v536_5).is_empty() { Space::new() } else {
              let v537_6: Path = concat_path(&(v535_6),&(v535_11_head));
              let v537_7: Space = routine_44(c, &(v537_6), &(v535_11_tail).make_space());
              compose(&(v536_5),&(v537_7))
            };
            drop(v536_5);
            let v536_9: Space = intersect(&(*CONSTANT_1),&(v536_2));
            drop(v536_2);
            let v536_10: Space = if has_head(&(v536_9)) { singleton(&[]) } else { Space::new() };
            drop(v536_9);
            let v536_12: Space = if (v536_10).is_empty() { Space::new() } else {
              let v538_6: Path = concat_path(&(v535_6),&(v535_11_head));
              let v538_11: Space = routine_15(c, &(v538_6), &(v535_11_tail).make_space());
              drop(v538_6);
              compose(&(v536_10),&(v538_11))
            };
            drop(v536_10);
            let v536_13: Space = unite(&(v536_8),&(v536_12));
            v535_11.join_into((v536_13).clone());
            }
            v535_11_cursor.ascend(1);
          }
          drop(v535_11_cursor);
          drop(v535_6);
          compose(&(v530_10),&(v535_11))
        };
        drop(v530_10);
        let v530_13: Space = unite(&(v530_8),&(v530_12));
        v529_7.join_into((v530_13).clone());
        }
        v529_7_cursor.ascend(1);
      }
      drop(v529_7_cursor);
      compose(&(v528_5),&(v529_7))
    };
    drop(v528_5);
    let v528_9: Space = intersect(&(*CONSTANT_1),&(v528_2));
    drop(v528_2);
    let v528_10: Space = if has_head(&(v528_9)) { singleton(&[]) } else { Space::new() };
    drop(v528_9);
    let v528_12: Space = if (v528_10).is_empty() { Space::new() } else {
      let v539_6: Path = concat_path(&(*p0),&(v527_20_head));
      let mut v539_11 = Space::new();
      let mut v539_11_cursor = (v527_20_tail).read_zipper();
      for v539_11_byte in v539_11_cursor.child_mask().iter() {
        v539_11_cursor.descend_to_byte(v539_11_byte);
        {
        let v539_11_tail = v539_11_cursor.fork_read_zipper();
        let v539_11_head = Path::from_slice(&[v539_11_byte]);
        let v540_2: Space = singleton(&(v539_11_head));
        let v540_3: Space = intersect(&(*CONSTANT_1),&(v540_2));
        let v540_4: Space = if has_head(&(v540_3)) { singleton(&[]) } else { Space::new() };
        drop(v540_3);
        let v540_5: Space = subtract(&(*CONSTANT_0),&(v540_4));
        drop(v540_4);
        let v540_8: Space = if (v540_5).is_empty() { Space::new() } else {
          let v541_6: Path = concat_path(&(v539_6),&(v539_11_head));
          let mut v541_7 = Space::new();
          let mut v541_7_cursor = (v539_11_tail).read_zipper();
          for v541_7_byte in v541_7_cursor.child_mask().iter() {
            v541_7_cursor.descend_to_byte(v541_7_byte);
            {
            let v541_7_tail = v541_7_cursor.fork_read_zipper();
            let v541_7_head = Path::from_slice(&[v541_7_byte]);
            let v542_2: Space = singleton(&(v541_7_head));
            let v542_3: Space = intersect(&(*CONSTANT_1),&(v542_2));
            let v542_4: Space = if has_head(&(v542_3)) { singleton(&[]) } else { Space::new() };
            drop(v542_3);
            let v542_5: Space = subtract(&(*CONSTANT_0),&(v542_4));
            drop(v542_4);
            let v542_8: Space = if (v542_5).is_empty() { Space::new() } else {
              let v543_6: Path = concat_path(&(v541_6),&(v541_7_head));
              let v543_7: Space = routine_44(c, &(v543_6), &(v541_7_tail).make_space());
              compose(&(v542_5),&(v543_7))
            };
            drop(v542_5);
            let v542_9: Space = intersect(&(*CONSTANT_1),&(v542_2));
            drop(v542_2);
            let v542_10: Space = if has_head(&(v542_9)) { singleton(&[]) } else { Space::new() };
            drop(v542_9);
            let v542_12: Space = if (v542_10).is_empty() { Space::new() } else {
              let v544_6: Path = concat_path(&(v541_6),&(v541_7_head));
              let v544_11: Space = routine_45(c, &(v544_6), &(v541_7_tail).make_space());
              drop(v544_6);
              compose(&(v542_10),&(v544_11))
            };
            drop(v542_10);
            let v542_13: Space = unite(&(v542_8),&(v542_12));
            v541_7.join_into((v542_13).clone());
            }
            v541_7_cursor.ascend(1);
          }
          drop(v541_7_cursor);
          drop(v541_6);
          compose(&(v540_5),&(v541_7))
        };
        drop(v540_5);
        let v540_9: Space = intersect(&(*CONSTANT_1),&(v540_2));
        drop(v540_2);
        let v540_10: Space = if has_head(&(v540_9)) { singleton(&[]) } else { Space::new() };
        drop(v540_9);
        let v540_11: Space = compose(&(v540_10),&(v539_11_tail));
        drop(v540_10);
        let v540_12: Space = unite(&(v540_8),&(v540_11));
        drop(v540_11);
        v539_11.join_into((v540_12).clone());
        }
        v539_11_cursor.ascend(1);
      }
      drop(v539_11_cursor);
      drop(v539_6);
      compose(&(v528_10),&(v539_11))
    };
    drop(v528_10);
    let v528_13: Space = unite(&(v528_8),&(v528_12));
    v527_20.join_into((v528_13).clone());
    }
    v527_20_cursor.ascend(1);
  }
  drop(v527_20_cursor);
  (v527_20).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v545_14 = Space::new();
  let mut v545_14_cursor = (*s0).read_zipper();
  for v545_14_byte in v545_14_cursor.child_mask().iter() {
    v545_14_cursor.descend_to_byte(v545_14_byte);
    {
    let v545_14_tail = v545_14_cursor.fork_read_zipper();
    let v545_14_head = Path::from_slice(&[v545_14_byte]);
    let v546_2: Space = singleton(&(v545_14_head));
    let v546_3: Space = intersect(&(*CONSTANT_1),&(v546_2));
    let v546_4: Space = if has_head(&(v546_3)) { singleton(&[]) } else { Space::new() };
    drop(v546_3);
    let v546_5: Space = subtract(&(*CONSTANT_0),&(v546_4));
    drop(v546_4);
    let v546_8: Space = if (v546_5).is_empty() { Space::new() } else {
      let v547_6: Path = concat_path(&(*p0),&(v545_14_head));
      let mut v547_7 = Space::new();
      let mut v547_7_cursor = (v545_14_tail).read_zipper();
      for v547_7_byte in v547_7_cursor.child_mask().iter() {
        v547_7_cursor.descend_to_byte(v547_7_byte);
        {
        let v547_7_tail = v547_7_cursor.fork_read_zipper();
        let v547_7_head = Path::from_slice(&[v547_7_byte]);
        let v548_2: Space = singleton(&(v547_7_head));
        let v548_3: Space = intersect(&(*CONSTANT_1),&(v548_2));
        let v548_4: Space = if has_head(&(v548_3)) { singleton(&[]) } else { Space::new() };
        drop(v548_3);
        let v548_5: Space = subtract(&(*CONSTANT_0),&(v548_4));
        drop(v548_4);
        let v548_8: Space = if (v548_5).is_empty() { Space::new() } else {
          let v549_6: Path = concat_path(&(v547_6),&(v547_7_head));
          let mut v549_7 = Space::new();
          let mut v549_7_cursor = (v547_7_tail).read_zipper();
          for v549_7_byte in v549_7_cursor.child_mask().iter() {
            v549_7_cursor.descend_to_byte(v549_7_byte);
            {
            let v549_7_tail = v549_7_cursor.fork_read_zipper();
            let v549_7_head = Path::from_slice(&[v549_7_byte]);
            let v550_2: Space = singleton(&(v549_7_head));
            let v550_3: Space = intersect(&(*CONSTANT_1),&(v550_2));
            let v550_4: Space = if has_head(&(v550_3)) { singleton(&[]) } else { Space::new() };
            drop(v550_3);
            let v550_5: Space = subtract(&(*CONSTANT_0),&(v550_4));
            drop(v550_4);
            let v550_8: Space = if (v550_5).is_empty() { Space::new() } else {
              let v551_6: Path = concat_path(&(v549_6),&(v549_7_head));
              let v551_7: Space = routine_44(c, &(v551_6), &(v549_7_tail).make_space());
              compose(&(v550_5),&(v551_7))
            };
            drop(v550_5);
            let v550_9: Space = intersect(&(*CONSTANT_1),&(v550_2));
            drop(v550_2);
            let v550_10: Space = if has_head(&(v550_9)) { singleton(&[]) } else { Space::new() };
            drop(v550_9);
            let v550_12: Space = if (v550_10).is_empty() { Space::new() } else {
              let v552_6: Path = concat_path(&(v549_6),&(v549_7_head));
              let v552_11: Space = routine_45(c, &(v552_6), &(v549_7_tail).make_space());
              drop(v552_6);
              compose(&(v550_10),&(v552_11))
            };
            drop(v550_10);
            let v550_13: Space = unite(&(v550_8),&(v550_12));
            v549_7.join_into((v550_13).clone());
            }
            v549_7_cursor.ascend(1);
          }
          drop(v549_7_cursor);
          compose(&(v548_5),&(v549_7))
        };
        drop(v548_5);
        let v548_9: Space = intersect(&(*CONSTANT_1),&(v548_2));
        drop(v548_2);
        let v548_10: Space = if has_head(&(v548_9)) { singleton(&[]) } else { Space::new() };
        drop(v548_9);
        let v548_12: Space = if (v548_10).is_empty() { Space::new() } else {
          let v553_6: Path = concat_path(&(v547_6),&(v547_7_head));
          let mut v553_11 = Space::new();
          let mut v553_11_cursor = (v547_7_tail).read_zipper();
          for v553_11_byte in v553_11_cursor.child_mask().iter() {
            v553_11_cursor.descend_to_byte(v553_11_byte);
            {
            let v553_11_tail = v553_11_cursor.fork_read_zipper();
            let v553_11_head = Path::from_slice(&[v553_11_byte]);
            let v554_2: Space = singleton(&(v553_11_head));
            let v554_3: Space = intersect(&(*CONSTANT_1),&(v554_2));
            let v554_4: Space = if has_head(&(v554_3)) { singleton(&[]) } else { Space::new() };
            drop(v554_3);
            let v554_5: Space = subtract(&(*CONSTANT_0),&(v554_4));
            drop(v554_4);
            let v554_8: Space = if (v554_5).is_empty() { Space::new() } else {
              let v555_6: Path = concat_path(&(v553_6),&(v553_11_head));
              let v555_7: Space = routine_44(c, &(v555_6), &(v553_11_tail).make_space());
              compose(&(v554_5),&(v555_7))
            };
            drop(v554_5);
            let v554_9: Space = intersect(&(*CONSTANT_1),&(v554_2));
            drop(v554_2);
            let v554_10: Space = if has_head(&(v554_9)) { singleton(&[]) } else { Space::new() };
            drop(v554_9);
            let v554_12: Space = if (v554_10).is_empty() { Space::new() } else {
              let v556_6: Path = concat_path(&(v553_6),&(v553_11_head));
              let v556_11: Space = routine_15(c, &(v556_6), &(v553_11_tail).make_space());
              drop(v556_6);
              compose(&(v554_10),&(v556_11))
            };
            drop(v554_10);
            let v554_13: Space = unite(&(v554_8),&(v554_12));
            v553_11.join_into((v554_13).clone());
            }
            v553_11_cursor.ascend(1);
          }
          drop(v553_11_cursor);
          drop(v553_6);
          compose(&(v548_10),&(v553_11))
        };
        drop(v548_10);
        let v548_13: Space = unite(&(v548_8),&(v548_12));
        v547_7.join_into((v548_13).clone());
        }
        v547_7_cursor.ascend(1);
      }
      drop(v547_7_cursor);
      drop(v547_6);
      compose(&(v546_5),&(v547_7))
    };
    drop(v546_5);
    let v546_9: Space = intersect(&(*CONSTANT_1),&(v546_2));
    drop(v546_2);
    let v546_10: Space = if has_head(&(v546_9)) { singleton(&[]) } else { Space::new() };
    drop(v546_9);
    let v546_11: Space = compose(&(v546_10),&(v545_14_tail));
    drop(v546_10);
    let v546_12: Space = unite(&(v546_8),&(v546_11));
    drop(v546_11);
    v545_14.join_into((v546_12).clone());
    }
    v545_14_cursor.ascend(1);
  }
  drop(v545_14_cursor);
  (v545_14).clone()
}

fn routine_34(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v557_12 = Space::new();
  let mut v557_12_cursor = (*s0).read_zipper();
  for v557_12_byte in v557_12_cursor.child_mask().iter() {
    v557_12_cursor.descend_to_byte(v557_12_byte);
    {
    let v557_12_tail = v557_12_cursor.fork_read_zipper();
    let v557_12_head = Path::from_slice(&[v557_12_byte]);
    let v558_2: Space = singleton(&(v557_12_head));
    let v558_3: Space = intersect(&(*CONSTANT_1),&(v558_2));
    let v558_4: Space = if has_head(&(v558_3)) { singleton(&[]) } else { Space::new() };
    drop(v558_3);
    let v558_5: Space = subtract(&(*CONSTANT_0),&(v558_4));
    drop(v558_4);
    let v558_8: Space = if (v558_5).is_empty() { Space::new() } else {
      let v559_6: Path = concat_path(&(*p0),&(v557_12_head));
      let mut v559_7 = Space::new();
      let mut v559_7_cursor = (v557_12_tail).read_zipper();
      for v559_7_byte in v559_7_cursor.child_mask().iter() {
        v559_7_cursor.descend_to_byte(v559_7_byte);
        {
        let v559_7_tail = v559_7_cursor.fork_read_zipper();
        let v559_7_head = Path::from_slice(&[v559_7_byte]);
        let v560_2: Space = singleton(&(v559_7_head));
        let v560_3: Space = intersect(&(*CONSTANT_1),&(v560_2));
        let v560_4: Space = if has_head(&(v560_3)) { singleton(&[]) } else { Space::new() };
        drop(v560_3);
        let v560_5: Space = subtract(&(*CONSTANT_0),&(v560_4));
        drop(v560_4);
        let mut v560_6 = Space::new();
        let mut v560_6_cursor = (v559_7_tail).read_zipper();
        for v560_6_byte in v560_6_cursor.child_mask().iter() {
          v560_6_cursor.descend_to_byte(v560_6_byte);
          {
          let v560_6_tail = v560_6_cursor.fork_read_zipper();
          let v560_6_head = Path::from_slice(&[v560_6_byte]);
          let v561_2: Space = Space::new();
          v560_6.join_into((v561_2).clone());
          }
          v560_6_cursor.ascend(1);
        }
        drop(v560_6_cursor);
        let v560_7: Space = compose(&(v560_5),&(v560_6));
        drop(v560_5);
        drop(v560_6);
        let v560_8: Space = intersect(&(*CONSTANT_1),&(v560_2));
        drop(v560_2);
        let v560_9: Space = if has_head(&(v560_8)) { singleton(&[]) } else { Space::new() };
        drop(v560_8);
        let v560_12: Space = if (v560_9).is_empty() { Space::new() } else {
          let v562_10: Path = concat_path(&(v559_6),&(v559_7_head));
          let mut v562_11 = Space::new();
          let mut v562_11_cursor = (v559_7_tail).read_zipper();
          for v562_11_byte in v562_11_cursor.child_mask().iter() {
            v562_11_cursor.descend_to_byte(v562_11_byte);
            {
            let v562_11_tail = v562_11_cursor.fork_read_zipper();
            let v562_11_head = Path::from_slice(&[v562_11_byte]);
            let v563_2: Space = singleton(&(v562_11_head));
            let v563_3: Space = intersect(&(*CONSTANT_1),&(v563_2));
            drop(v563_2);
            let v563_4: Space = if has_head(&(v563_3)) { singleton(&[]) } else { Space::new() };
            drop(v563_3);
            let v563_7: Space = if (v563_4).is_empty() { Space::new() } else {
              let v564_5: Path = concat_path(&(v562_10),&(v562_11_head));
              let v564_6: Space = routine_12(c, &(v564_5), &(v562_11_tail).make_space());
              drop(v564_5);
              compose(&(v563_4),&(v564_6))
            };
            drop(v563_4);
            v562_11.join_into((v563_7).clone());
            }
            v562_11_cursor.ascend(1);
          }
          drop(v562_11_cursor);
          drop(v562_10);
          compose(&(v560_9),&(v562_11))
        };
        drop(v560_9);
        let v560_13: Space = unite(&(v560_7),&(v560_12));
        drop(v560_7);
        v559_7.join_into((v560_13).clone());
        }
        v559_7_cursor.ascend(1);
      }
      drop(v559_7_cursor);
      drop(v559_6);
      compose(&(v558_5),&(v559_7))
    };
    drop(v558_5);
    let v558_9: Space = intersect(&(*CONSTANT_1),&(v558_2));
    drop(v558_2);
    let v558_10: Space = if has_head(&(v558_9)) { singleton(&[]) } else { Space::new() };
    drop(v558_9);
    let mut v558_11 = Space::new();
    let mut v558_11_cursor = (v557_12_tail).read_zipper();
    for v558_11_byte in v558_11_cursor.child_mask().iter() {
      v558_11_cursor.descend_to_byte(v558_11_byte);
      {
      let v558_11_tail = v558_11_cursor.fork_read_zipper();
      let v558_11_head = Path::from_slice(&[v558_11_byte]);
      let v565_2: Space = singleton(&(v558_11_head));
      let v565_3: Space = intersect(&(*CONSTANT_1),&(v565_2));
      let v565_4: Space = if has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
      drop(v565_3);
      let v565_5: Space = subtract(&(*CONSTANT_0),&(v565_4));
      drop(v565_4);
      let mut v565_6 = Space::new();
      let mut v565_6_cursor = (v558_11_tail).read_zipper();
      for v565_6_byte in v565_6_cursor.child_mask().iter() {
        v565_6_cursor.descend_to_byte(v565_6_byte);
        {
        let v565_6_tail = v565_6_cursor.fork_read_zipper();
        let v565_6_head = Path::from_slice(&[v565_6_byte]);
        let v566_2: Space = Space::new();
        v565_6.join_into((v566_2).clone());
        }
        v565_6_cursor.ascend(1);
      }
      drop(v565_6_cursor);
      let v565_7: Space = compose(&(v565_5),&(v565_6));
      drop(v565_5);
      drop(v565_6);
      let v565_8: Space = intersect(&(*CONSTANT_1),&(v565_2));
      drop(v565_2);
      let v565_9: Space = if has_head(&(v565_8)) { singleton(&[]) } else { Space::new() };
      drop(v565_8);
      let v565_10: Space = compose(&(v565_9),&(v558_11_tail));
      drop(v565_9);
      let v565_11: Space = unite(&(v565_7),&(v565_10));
      drop(v565_7);
      drop(v565_10);
      v558_11.join_into((v565_11).clone());
      }
      v558_11_cursor.ascend(1);
    }
    drop(v558_11_cursor);
    let v558_12: Space = compose(&(v558_10),&(v558_11));
    drop(v558_10);
    drop(v558_11);
    let v558_13: Space = unite(&(v558_8),&(v558_12));
    drop(v558_12);
    v557_12.join_into((v558_13).clone());
    }
    v557_12_cursor.ascend(1);
  }
  drop(v557_12_cursor);
  (v557_12).clone()
}

fn routine_35(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v567_9 = Space::new();
  let mut v567_9_cursor = (*s0).read_zipper();
  for v567_9_byte in v567_9_cursor.child_mask().iter() {
    v567_9_cursor.descend_to_byte(v567_9_byte);
    {
    let v567_9_tail = v567_9_cursor.fork_read_zipper();
    let v567_9_head = Path::from_slice(&[v567_9_byte]);
    let v568_2: Space = singleton(&(v567_9_head));
    let v568_3: Space = intersect(&(*CONSTANT_1),&(v568_2));
    let v568_4: Space = if has_head(&(v568_3)) { singleton(&[]) } else { Space::new() };
    drop(v568_3);
    let v568_5: Space = subtract(&(*CONSTANT_0),&(v568_4));
    drop(v568_4);
    let v568_8: Space = if (v568_5).is_empty() { Space::new() } else {
      let v569_6: Path = concat_path(&(*p0),&(v567_9_head));
      let mut v569_7 = Space::new();
      let mut v569_7_cursor = (v567_9_tail).read_zipper();
      for v569_7_byte in v569_7_cursor.child_mask().iter() {
        v569_7_cursor.descend_to_byte(v569_7_byte);
        {
        let v569_7_tail = v569_7_cursor.fork_read_zipper();
        let v569_7_head = Path::from_slice(&[v569_7_byte]);
        let v570_2: Space = singleton(&(v569_7_head));
        let v570_3: Space = intersect(&(*CONSTANT_1),&(v570_2));
        let v570_4: Space = if has_head(&(v570_3)) { singleton(&[]) } else { Space::new() };
        drop(v570_3);
        let v570_5: Space = subtract(&(*CONSTANT_0),&(v570_4));
        drop(v570_4);
        let mut v570_6 = Space::new();
        let mut v570_6_cursor = (v569_7_tail).read_zipper();
        for v570_6_byte in v570_6_cursor.child_mask().iter() {
          v570_6_cursor.descend_to_byte(v570_6_byte);
          {
          let v570_6_tail = v570_6_cursor.fork_read_zipper();
          let v570_6_head = Path::from_slice(&[v570_6_byte]);
          let v571_2: Space = Space::new();
          v570_6.join_into((v571_2).clone());
          }
          v570_6_cursor.ascend(1);
        }
        drop(v570_6_cursor);
        let v570_7: Space = compose(&(v570_5),&(v570_6));
        drop(v570_5);
        drop(v570_6);
        let v570_8: Space = intersect(&(*CONSTANT_1),&(v570_2));
        drop(v570_2);
        let v570_9: Space = if has_head(&(v570_8)) { singleton(&[]) } else { Space::new() };
        drop(v570_8);
        let v570_12: Space = if (v570_9).is_empty() { Space::new() } else {
          let v572_10: Path = concat_path(&(v569_6),&(v569_7_head));
          let mut v572_11 = Space::new();
          let mut v572_11_cursor = (v569_7_tail).read_zipper();
          for v572_11_byte in v572_11_cursor.child_mask().iter() {
            v572_11_cursor.descend_to_byte(v572_11_byte);
            {
            let v572_11_tail = v572_11_cursor.fork_read_zipper();
            let v572_11_head = Path::from_slice(&[v572_11_byte]);
            let v573_2: Space = singleton(&(v572_11_head));
            let v573_3: Space = intersect(&(*CONSTANT_1),&(v573_2));
            drop(v573_2);
            let v573_4: Space = if has_head(&(v573_3)) { singleton(&[]) } else { Space::new() };
            drop(v573_3);
            let v573_7: Space = if (v573_4).is_empty() { Space::new() } else {
              let v574_5: Path = concat_path(&(v572_10),&(v572_11_head));
              let v574_6: Space = routine_12(c, &(v574_5), &(v572_11_tail).make_space());
              drop(v574_5);
              compose(&(v573_4),&(v574_6))
            };
            drop(v573_4);
            v572_11.join_into((v573_7).clone());
            }
            v572_11_cursor.ascend(1);
          }
          drop(v572_11_cursor);
          drop(v572_10);
          compose(&(v570_9),&(v572_11))
        };
        drop(v570_9);
        let v570_13: Space = unite(&(v570_7),&(v570_12));
        drop(v570_7);
        v569_7.join_into((v570_13).clone());
        }
        v569_7_cursor.ascend(1);
      }
      drop(v569_7_cursor);
      drop(v569_6);
      compose(&(v568_5),&(v569_7))
    };
    drop(v568_5);
    let v568_9: Space = intersect(&(*CONSTANT_1),&(v568_2));
    drop(v568_2);
    let v568_10: Space = if has_head(&(v568_9)) { singleton(&[]) } else { Space::new() };
    drop(v568_9);
    let v568_11: Space = compose(&(v568_10),&(v567_9_tail));
    drop(v568_10);
    let v568_12: Space = unite(&(v568_8),&(v568_11));
    drop(v568_11);
    v567_9.join_into((v568_12).clone());
    }
    v567_9_cursor.ascend(1);
  }
  drop(v567_9_cursor);
  (v567_9).clone()
}

fn routine_36(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v575_12 = Space::new();
  let mut v575_12_cursor = (*s0).read_zipper();
  for v575_12_byte in v575_12_cursor.child_mask().iter() {
    v575_12_cursor.descend_to_byte(v575_12_byte);
    {
    let v575_12_tail = v575_12_cursor.fork_read_zipper();
    let v575_12_head = Path::from_slice(&[v575_12_byte]);
    let v576_2: Space = singleton(&(v575_12_head));
    let v576_3: Space = intersect(&(*CONSTANT_1),&(v576_2));
    let v576_4: Space = if has_head(&(v576_3)) { singleton(&[]) } else { Space::new() };
    drop(v576_3);
    let v576_5: Space = subtract(&(*CONSTANT_0),&(v576_4));
    drop(v576_4);
    let v576_8: Space = if (v576_5).is_empty() { Space::new() } else {
      let v577_6: Path = concat_path(&(*p0),&(v575_12_head));
      let mut v577_7 = Space::new();
      let mut v577_7_cursor = (v575_12_tail).read_zipper();
      for v577_7_byte in v577_7_cursor.child_mask().iter() {
        v577_7_cursor.descend_to_byte(v577_7_byte);
        {
        let v577_7_tail = v577_7_cursor.fork_read_zipper();
        let v577_7_head = Path::from_slice(&[v577_7_byte]);
        let v578_2: Space = singleton(&(v577_7_head));
        let v578_3: Space = intersect(&(*CONSTANT_1),&(v578_2));
        let v578_4: Space = if has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
        drop(v578_3);
        let v578_5: Space = subtract(&(*CONSTANT_0),&(v578_4));
        drop(v578_4);
        let mut v578_6 = Space::new();
        let mut v578_6_cursor = (v577_7_tail).read_zipper();
        for v578_6_byte in v578_6_cursor.child_mask().iter() {
          v578_6_cursor.descend_to_byte(v578_6_byte);
          {
          let v578_6_tail = v578_6_cursor.fork_read_zipper();
          let v578_6_head = Path::from_slice(&[v578_6_byte]);
          let v579_2: Space = Space::new();
          v578_6.join_into((v579_2).clone());
          }
          v578_6_cursor.ascend(1);
        }
        drop(v578_6_cursor);
        let v578_7: Space = compose(&(v578_5),&(v578_6));
        drop(v578_5);
        drop(v578_6);
        let v578_8: Space = intersect(&(*CONSTANT_1),&(v578_2));
        drop(v578_2);
        let v578_9: Space = if has_head(&(v578_8)) { singleton(&[]) } else { Space::new() };
        drop(v578_8);
        let v578_12: Space = if (v578_9).is_empty() { Space::new() } else {
          let v580_10: Path = concat_path(&(v577_6),&(v577_7_head));
          let mut v580_11 = Space::new();
          let mut v580_11_cursor = (v577_7_tail).read_zipper();
          for v580_11_byte in v580_11_cursor.child_mask().iter() {
            v580_11_cursor.descend_to_byte(v580_11_byte);
            {
            let v580_11_tail = v580_11_cursor.fork_read_zipper();
            let v580_11_head = Path::from_slice(&[v580_11_byte]);
            let v581_2: Space = singleton(&(v580_11_head));
            let v581_3: Space = intersect(&(*CONSTANT_1),&(v581_2));
            drop(v581_2);
            let v581_4: Space = if has_head(&(v581_3)) { singleton(&[]) } else { Space::new() };
            drop(v581_3);
            let v581_7: Space = if (v581_4).is_empty() { Space::new() } else {
              let v582_5: Path = concat_path(&(v580_10),&(v580_11_head));
              let v582_6: Space = routine_15(c, &(v582_5), &(v580_11_tail).make_space());
              drop(v582_5);
              compose(&(v581_4),&(v582_6))
            };
            drop(v581_4);
            v580_11.join_into((v581_7).clone());
            }
            v580_11_cursor.ascend(1);
          }
          drop(v580_11_cursor);
          drop(v580_10);
          compose(&(v578_9),&(v580_11))
        };
        drop(v578_9);
        let v578_13: Space = unite(&(v578_7),&(v578_12));
        drop(v578_7);
        v577_7.join_into((v578_13).clone());
        }
        v577_7_cursor.ascend(1);
      }
      drop(v577_7_cursor);
      drop(v577_6);
      compose(&(v576_5),&(v577_7))
    };
    drop(v576_5);
    let v576_9: Space = intersect(&(*CONSTANT_1),&(v576_2));
    drop(v576_2);
    let v576_10: Space = if has_head(&(v576_9)) { singleton(&[]) } else { Space::new() };
    drop(v576_9);
    let mut v576_11 = Space::new();
    let mut v576_11_cursor = (v575_12_tail).read_zipper();
    for v576_11_byte in v576_11_cursor.child_mask().iter() {
      v576_11_cursor.descend_to_byte(v576_11_byte);
      {
      let v576_11_tail = v576_11_cursor.fork_read_zipper();
      let v576_11_head = Path::from_slice(&[v576_11_byte]);
      let v583_2: Space = singleton(&(v576_11_head));
      let v583_3: Space = intersect(&(*CONSTANT_1),&(v583_2));
      let v583_4: Space = if has_head(&(v583_3)) { singleton(&[]) } else { Space::new() };
      drop(v583_3);
      let v583_5: Space = subtract(&(*CONSTANT_0),&(v583_4));
      drop(v583_4);
      let mut v583_6 = Space::new();
      let mut v583_6_cursor = (v576_11_tail).read_zipper();
      for v583_6_byte in v583_6_cursor.child_mask().iter() {
        v583_6_cursor.descend_to_byte(v583_6_byte);
        {
        let v583_6_tail = v583_6_cursor.fork_read_zipper();
        let v583_6_head = Path::from_slice(&[v583_6_byte]);
        let v584_2: Space = Space::new();
        v583_6.join_into((v584_2).clone());
        }
        v583_6_cursor.ascend(1);
      }
      drop(v583_6_cursor);
      let v583_7: Space = compose(&(v583_5),&(v583_6));
      drop(v583_5);
      drop(v583_6);
      let v583_8: Space = intersect(&(*CONSTANT_1),&(v583_2));
      drop(v583_2);
      let v583_9: Space = if has_head(&(v583_8)) { singleton(&[]) } else { Space::new() };
      drop(v583_8);
      let v583_10: Space = compose(&(v583_9),&(v576_11_tail));
      drop(v583_9);
      let v583_11: Space = unite(&(v583_7),&(v583_10));
      drop(v583_7);
      drop(v583_10);
      v576_11.join_into((v583_11).clone());
      }
      v576_11_cursor.ascend(1);
    }
    drop(v576_11_cursor);
    let v576_12: Space = compose(&(v576_10),&(v576_11));
    drop(v576_10);
    drop(v576_11);
    let v576_13: Space = unite(&(v576_8),&(v576_12));
    drop(v576_12);
    v575_12.join_into((v576_13).clone());
    }
    v575_12_cursor.ascend(1);
  }
  drop(v575_12_cursor);
  (v575_12).clone()
}

fn routine_37(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v585_9 = Space::new();
  let mut v585_9_cursor = (*s0).read_zipper();
  for v585_9_byte in v585_9_cursor.child_mask().iter() {
    v585_9_cursor.descend_to_byte(v585_9_byte);
    {
    let v585_9_tail = v585_9_cursor.fork_read_zipper();
    let v585_9_head = Path::from_slice(&[v585_9_byte]);
    let v586_2: Space = singleton(&(v585_9_head));
    let v586_3: Space = intersect(&(*CONSTANT_1),&(v586_2));
    let v586_4: Space = if has_head(&(v586_3)) { singleton(&[]) } else { Space::new() };
    drop(v586_3);
    let v586_5: Space = subtract(&(*CONSTANT_0),&(v586_4));
    drop(v586_4);
    let v586_8: Space = if (v586_5).is_empty() { Space::new() } else {
      let v587_6: Path = concat_path(&(*p0),&(v585_9_head));
      let mut v587_7 = Space::new();
      let mut v587_7_cursor = (v585_9_tail).read_zipper();
      for v587_7_byte in v587_7_cursor.child_mask().iter() {
        v587_7_cursor.descend_to_byte(v587_7_byte);
        {
        let v587_7_tail = v587_7_cursor.fork_read_zipper();
        let v587_7_head = Path::from_slice(&[v587_7_byte]);
        let v588_2: Space = singleton(&(v587_7_head));
        let v588_3: Space = intersect(&(*CONSTANT_1),&(v588_2));
        let v588_4: Space = if has_head(&(v588_3)) { singleton(&[]) } else { Space::new() };
        drop(v588_3);
        let v588_5: Space = subtract(&(*CONSTANT_0),&(v588_4));
        drop(v588_4);
        let mut v588_6 = Space::new();
        let mut v588_6_cursor = (v587_7_tail).read_zipper();
        for v588_6_byte in v588_6_cursor.child_mask().iter() {
          v588_6_cursor.descend_to_byte(v588_6_byte);
          {
          let v588_6_tail = v588_6_cursor.fork_read_zipper();
          let v588_6_head = Path::from_slice(&[v588_6_byte]);
          let v589_2: Space = Space::new();
          v588_6.join_into((v589_2).clone());
          }
          v588_6_cursor.ascend(1);
        }
        drop(v588_6_cursor);
        let v588_7: Space = compose(&(v588_5),&(v588_6));
        drop(v588_5);
        drop(v588_6);
        let v588_8: Space = intersect(&(*CONSTANT_1),&(v588_2));
        drop(v588_2);
        let v588_9: Space = if has_head(&(v588_8)) { singleton(&[]) } else { Space::new() };
        drop(v588_8);
        let v588_12: Space = if (v588_9).is_empty() { Space::new() } else {
          let v590_10: Path = concat_path(&(v587_6),&(v587_7_head));
          let mut v590_11 = Space::new();
          let mut v590_11_cursor = (v587_7_tail).read_zipper();
          for v590_11_byte in v590_11_cursor.child_mask().iter() {
            v590_11_cursor.descend_to_byte(v590_11_byte);
            {
            let v590_11_tail = v590_11_cursor.fork_read_zipper();
            let v590_11_head = Path::from_slice(&[v590_11_byte]);
            let v591_2: Space = singleton(&(v590_11_head));
            let v591_3: Space = intersect(&(*CONSTANT_1),&(v591_2));
            drop(v591_2);
            let v591_4: Space = if has_head(&(v591_3)) { singleton(&[]) } else { Space::new() };
            drop(v591_3);
            let v591_7: Space = if (v591_4).is_empty() { Space::new() } else {
              let v592_5: Path = concat_path(&(v590_10),&(v590_11_head));
              let v592_6: Space = routine_15(c, &(v592_5), &(v590_11_tail).make_space());
              drop(v592_5);
              compose(&(v591_4),&(v592_6))
            };
            drop(v591_4);
            v590_11.join_into((v591_7).clone());
            }
            v590_11_cursor.ascend(1);
          }
          drop(v590_11_cursor);
          drop(v590_10);
          compose(&(v588_9),&(v590_11))
        };
        drop(v588_9);
        let v588_13: Space = unite(&(v588_7),&(v588_12));
        drop(v588_7);
        v587_7.join_into((v588_13).clone());
        }
        v587_7_cursor.ascend(1);
      }
      drop(v587_7_cursor);
      drop(v587_6);
      compose(&(v586_5),&(v587_7))
    };
    drop(v586_5);
    let v586_9: Space = intersect(&(*CONSTANT_1),&(v586_2));
    drop(v586_2);
    let v586_10: Space = if has_head(&(v586_9)) { singleton(&[]) } else { Space::new() };
    drop(v586_9);
    let v586_11: Space = compose(&(v586_10),&(v585_9_tail));
    drop(v586_10);
    let v586_12: Space = unite(&(v586_8),&(v586_11));
    drop(v586_11);
    v585_9.join_into((v586_12).clone());
    }
    v585_9_cursor.ascend(1);
  }
  drop(v585_9_cursor);
  (v585_9).clone()
}

fn routine_38(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v593_6 = Space::new();
  let mut v593_6_cursor = (*s0).read_zipper();
  for v593_6_byte in v593_6_cursor.child_mask().iter() {
    v593_6_cursor.descend_to_byte(v593_6_byte);
    {
    let v593_6_tail = v593_6_cursor.fork_read_zipper();
    let v593_6_head = Path::from_slice(&[v593_6_byte]);
    let v594_2: Space = singleton(&(v593_6_head));
    let v594_3: Space = intersect(&(*CONSTANT_1),&(v594_2));
    let v594_4: Space = if has_head(&(v594_3)) { singleton(&[]) } else { Space::new() };
    drop(v594_3);
    let v594_5: Space = subtract(&(*CONSTANT_0),&(v594_4));
    drop(v594_4);
    let mut v594_6 = Space::new();
    let mut v594_6_cursor = (v593_6_tail).read_zipper();
    for v594_6_byte in v594_6_cursor.child_mask().iter() {
      v594_6_cursor.descend_to_byte(v594_6_byte);
      {
      let v594_6_tail = v594_6_cursor.fork_read_zipper();
      let v594_6_head = Path::from_slice(&[v594_6_byte]);
      let v595_2: Space = Space::new();
      v594_6.join_into((v595_2).clone());
      }
      v594_6_cursor.ascend(1);
    }
    drop(v594_6_cursor);
    let v594_7: Space = compose(&(v594_5),&(v594_6));
    drop(v594_5);
    drop(v594_6);
    let v594_8: Space = intersect(&(*CONSTANT_1),&(v594_2));
    drop(v594_2);
    let v594_9: Space = if has_head(&(v594_8)) { singleton(&[]) } else { Space::new() };
    drop(v594_8);
    let mut v594_10 = Space::new();
    let mut v594_10_cursor = (v593_6_tail).read_zipper();
    for v594_10_byte in v594_10_cursor.child_mask().iter() {
      v594_10_cursor.descend_to_byte(v594_10_byte);
      {
      let v594_10_tail = v594_10_cursor.fork_read_zipper();
      let v594_10_head = Path::from_slice(&[v594_10_byte]);
      let v596_2: Space = singleton(&(v594_10_head));
      let v596_3: Space = intersect(&(*CONSTANT_1),&(v596_2));
      drop(v596_2);
      let v596_4: Space = if has_head(&(v596_3)) { singleton(&[]) } else { Space::new() };
      drop(v596_3);
      let v596_5: Space = compose(&(v596_4),&(v594_10_tail));
      drop(v596_4);
      v594_10.join_into((v596_5).clone());
      }
      v594_10_cursor.ascend(1);
    }
    drop(v594_10_cursor);
    let v594_11: Space = compose(&(v594_9),&(v594_10));
    drop(v594_9);
    drop(v594_10);
    let v594_12: Space = unite(&(v594_7),&(v594_11));
    drop(v594_7);
    drop(v594_11);
    v593_6.join_into((v594_12).clone());
    }
    v593_6_cursor.ascend(1);
  }
  drop(v593_6_cursor);
  (v593_6).clone()
}

fn routine_39(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v597_5 = Space::new();
  let mut v597_5_cursor = (*s0).read_zipper();
  for v597_5_byte in v597_5_cursor.child_mask().iter() {
    v597_5_cursor.descend_to_byte(v597_5_byte);
    {
    let v597_5_tail = v597_5_cursor.fork_read_zipper();
    let v597_5_head = Path::from_slice(&[v597_5_byte]);
    let v598_2: Space = singleton(&(v597_5_head));
    let v598_3: Space = intersect(&(*CONSTANT_1),&(v598_2));
    let v598_4: Space = if has_head(&(v598_3)) { singleton(&[]) } else { Space::new() };
    drop(v598_3);
    let v598_5: Space = subtract(&(*CONSTANT_0),&(v598_4));
    drop(v598_4);
    let mut v598_6 = Space::new();
    let mut v598_6_cursor = (v597_5_tail).read_zipper();
    for v598_6_byte in v598_6_cursor.child_mask().iter() {
      v598_6_cursor.descend_to_byte(v598_6_byte);
      {
      let v598_6_tail = v598_6_cursor.fork_read_zipper();
      let v598_6_head = Path::from_slice(&[v598_6_byte]);
      let v599_2: Space = Space::new();
      v598_6.join_into((v599_2).clone());
      }
      v598_6_cursor.ascend(1);
    }
    drop(v598_6_cursor);
    let v598_7: Space = compose(&(v598_5),&(v598_6));
    drop(v598_5);
    drop(v598_6);
    let v598_8: Space = intersect(&(*CONSTANT_1),&(v598_2));
    drop(v598_2);
    let v598_9: Space = if has_head(&(v598_8)) { singleton(&[]) } else { Space::new() };
    drop(v598_8);
    let v598_10: Space = compose(&(v598_9),&(v597_5_tail));
    drop(v598_9);
    let v598_11: Space = unite(&(v598_7),&(v598_10));
    drop(v598_7);
    drop(v598_10);
    v597_5.join_into((v598_11).clone());
    }
    v597_5_cursor.ascend(1);
  }
  drop(v597_5_cursor);
  (v597_5).clone()
}

fn routine_40(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v600_6 = Space::new();
  let mut v600_6_cursor = (*s0).read_zipper();
  for v600_6_byte in v600_6_cursor.child_mask().iter() {
    v600_6_cursor.descend_to_byte(v600_6_byte);
    {
    let v600_6_tail = v600_6_cursor.fork_read_zipper();
    let v600_6_head = Path::from_slice(&[v600_6_byte]);
    let v601_2: Space = singleton(&(v600_6_head));
    let v601_3: Space = intersect(&(*CONSTANT_1),&(v601_2));
    let v601_4: Space = if has_head(&(v601_3)) { singleton(&[]) } else { Space::new() };
    drop(v601_3);
    let v601_5: Space = subtract(&(*CONSTANT_0),&(v601_4));
    drop(v601_4);
    let mut v601_6 = Space::new();
    let mut v601_6_cursor = (v600_6_tail).read_zipper();
    for v601_6_byte in v601_6_cursor.child_mask().iter() {
      v601_6_cursor.descend_to_byte(v601_6_byte);
      {
      let v601_6_tail = v601_6_cursor.fork_read_zipper();
      let v601_6_head = Path::from_slice(&[v601_6_byte]);
      let v602_2: Space = Space::new();
      v601_6.join_into((v602_2).clone());
      }
      v601_6_cursor.ascend(1);
    }
    drop(v601_6_cursor);
    let v601_7: Space = compose(&(v601_5),&(v601_6));
    drop(v601_5);
    drop(v601_6);
    let v601_8: Space = intersect(&(*CONSTANT_1),&(v601_2));
    drop(v601_2);
    let v601_9: Space = if has_head(&(v601_8)) { singleton(&[]) } else { Space::new() };
    drop(v601_8);
    let mut v601_10 = Space::new();
    let mut v601_10_cursor = (v600_6_tail).read_zipper();
    for v601_10_byte in v601_10_cursor.child_mask().iter() {
      v601_10_cursor.descend_to_byte(v601_10_byte);
      {
      let v601_10_tail = v601_10_cursor.fork_read_zipper();
      let v601_10_head = Path::from_slice(&[v601_10_byte]);
      let v603_2: Space = singleton(&(v601_10_head));
      let v603_3: Space = intersect(&(*CONSTANT_1),&(v603_2));
      drop(v603_2);
      let v603_4: Space = if has_head(&(v603_3)) { singleton(&[]) } else { Space::new() };
      drop(v603_3);
      let v603_5: Space = compose(&(v603_4),&(v601_10_tail));
      drop(v603_4);
      v601_10.join_into((v603_5).clone());
      }
      v601_10_cursor.ascend(1);
    }
    drop(v601_10_cursor);
    let v601_11: Space = compose(&(v601_9),&(v601_10));
    drop(v601_9);
    drop(v601_10);
    let v601_12: Space = unite(&(v601_7),&(v601_11));
    drop(v601_7);
    drop(v601_11);
    v600_6.join_into((v601_12).clone());
    }
    v600_6_cursor.ascend(1);
  }
  drop(v600_6_cursor);
  (v600_6).clone()
}

fn routine_41(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v604_5 = Space::new();
  let mut v604_5_cursor = (*s0).read_zipper();
  for v604_5_byte in v604_5_cursor.child_mask().iter() {
    v604_5_cursor.descend_to_byte(v604_5_byte);
    {
    let v604_5_tail = v604_5_cursor.fork_read_zipper();
    let v604_5_head = Path::from_slice(&[v604_5_byte]);
    let v605_2: Space = singleton(&(v604_5_head));
    let v605_3: Space = intersect(&(*CONSTANT_1),&(v605_2));
    let v605_4: Space = if has_head(&(v605_3)) { singleton(&[]) } else { Space::new() };
    drop(v605_3);
    let v605_5: Space = subtract(&(*CONSTANT_0),&(v605_4));
    drop(v605_4);
    let mut v605_6 = Space::new();
    let mut v605_6_cursor = (v604_5_tail).read_zipper();
    for v605_6_byte in v605_6_cursor.child_mask().iter() {
      v605_6_cursor.descend_to_byte(v605_6_byte);
      {
      let v605_6_tail = v605_6_cursor.fork_read_zipper();
      let v605_6_head = Path::from_slice(&[v605_6_byte]);
      let v606_2: Space = Space::new();
      v605_6.join_into((v606_2).clone());
      }
      v605_6_cursor.ascend(1);
    }
    drop(v605_6_cursor);
    let v605_7: Space = compose(&(v605_5),&(v605_6));
    drop(v605_5);
    drop(v605_6);
    let v605_8: Space = intersect(&(*CONSTANT_1),&(v605_2));
    drop(v605_2);
    let v605_9: Space = if has_head(&(v605_8)) { singleton(&[]) } else { Space::new() };
    drop(v605_8);
    let v605_10: Space = compose(&(v605_9),&(v604_5_tail));
    drop(v605_9);
    let v605_11: Space = unite(&(v605_7),&(v605_10));
    drop(v605_7);
    drop(v605_10);
    v604_5.join_into((v605_11).clone());
    }
    v604_5_cursor.ascend(1);
  }
  drop(v604_5_cursor);
  (v604_5).clone()
}

fn routine_42(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v607_2 = Space::new();
  let mut v607_2_cursor = (*s0).read_zipper();
  for v607_2_byte in v607_2_cursor.child_mask().iter() {
    v607_2_cursor.descend_to_byte(v607_2_byte);
    {
    let v607_2_tail = v607_2_cursor.fork_read_zipper();
    let v607_2_head = Path::from_slice(&[v607_2_byte]);
    let v608_2: Space = Space::new();
    v607_2.join_into((v608_2).clone());
    }
    v607_2_cursor.ascend(1);
  }
  drop(v607_2_cursor);
  (v607_2).clone()
}

fn routine_43(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v609_3 = Space::new();
  let mut v609_3_cursor = (*s0).read_zipper();
  for v609_3_byte in v609_3_cursor.child_mask().iter() {
    v609_3_cursor.descend_to_byte(v609_3_byte);
    {
    let v609_3_tail = v609_3_cursor.fork_read_zipper();
    let v609_3_head = Path::from_slice(&[v609_3_byte]);
    let v610_2: Space = singleton(&(v609_3_head));
    let v610_3: Space = intersect(&(*CONSTANT_1),&(v610_2));
    drop(v610_2);
    let v610_4: Space = if has_head(&(v610_3)) { singleton(&[]) } else { Space::new() };
    drop(v610_3);
    let v610_5: Space = compose(&(v610_4),&(v609_3_tail));
    drop(v610_4);
    v609_3.join_into((v610_5).clone());
    }
    v609_3_cursor.ascend(1);
  }
  drop(v609_3_cursor);
  (v609_3).clone()
}

fn routine_44(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v611_2 = Space::new();
  let mut v611_2_cursor = (*s0).read_zipper();
  for v611_2_byte in v611_2_cursor.child_mask().iter() {
    v611_2_cursor.descend_to_byte(v611_2_byte);
    {
    let v611_2_tail = v611_2_cursor.fork_read_zipper();
    let v611_2_head = Path::from_slice(&[v611_2_byte]);
    let v612_2: Space = Space::new();
    v611_2.join_into((v612_2).clone());
    }
    v611_2_cursor.ascend(1);
  }
  drop(v611_2_cursor);
  (v611_2).clone()
}

fn routine_45(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v613_3 = Space::new();
  let mut v613_3_cursor = (*s0).read_zipper();
  for v613_3_byte in v613_3_cursor.child_mask().iter() {
    v613_3_cursor.descend_to_byte(v613_3_byte);
    {
    let v613_3_tail = v613_3_cursor.fork_read_zipper();
    let v613_3_head = Path::from_slice(&[v613_3_byte]);
    let v614_2: Space = singleton(&(v613_3_head));
    let v614_3: Space = intersect(&(*CONSTANT_1),&(v614_2));
    drop(v614_2);
    let v614_4: Space = if has_head(&(v614_3)) { singleton(&[]) } else { Space::new() };
    drop(v614_3);
    let v614_5: Space = compose(&(v614_4),&(v613_3_tail));
    drop(v614_4);
    v613_3.join_into((v614_5).clone());
    }
    v613_3_cursor.ascend(1);
  }
  drop(v613_3_cursor);
  (v613_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
