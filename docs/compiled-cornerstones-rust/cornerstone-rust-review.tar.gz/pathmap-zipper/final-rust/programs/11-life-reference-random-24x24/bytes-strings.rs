#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[48]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 49 48 0 4 0 49 49 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[49]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("53 4 0 49 51 0 4 0 49 52 0 4 0 50 48 0 5 48 0 49 50 0 5 48 0 49 56 0 5 48 0 50 51 0 4 48 0 54 0 4 48 0 57 0 5 49 0 49 49 0 5 49 0 49 50 0 5 49 0 50 51 0 4 49 0 51 0 4 49 0 53 0 5 50 0 49 54 0 5 50 0 49 57 0 4 50 0 50 0 5 51 0 49 52 0 5 51 0 50 48 0 5 51 0 50 49 0 4 51 0 57 0 4 52 0 48 0 5 52 0 49 56 0 4 52 0 54 0 4 52 0 56 0 4 52 0 57 0 4 53 0 49 0 5 53 0 49 54 0 5 53 0 49 55 0 5 53 0 49 57 0 5 53 0 50 48 0 4 53 0 51 0 4 53 0 53 0 4 53 0 54 0 4 54 0 48 0 5 55 0 49 50 0 5 55 0 49 54 0 5 55 0 49 56 0 4 55 0 50 0 4 55 0 51 0 4 55 0 52 0 4 55 0 54 0 4 55 0 55 0 4 55 0 57 0 5 56 0 49 48 0 5 56 0 49 50 0 5 56 0 49 51 0 5 56 0 49 53 0 5 56 0 49 55 0 5 56 0 50 50 0 4 56 0 53 0 5 57 0 49 56 0 5 57 0 50 49 0 4 57 0 51 0"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[50]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("21 4 0 49 48 0 4 0 49 51 0 4 0 50 49 0 5 48 0 49 53 0 4 48 0 50 0 4 48 0 53 0 4 48 0 55 0 4 48 0 57 0 5 49 0 49 51 0 5 49 0 49 53 0 4 49 0 52 0 4 49 0 56 0 4 49 0 57 0 5 50 0 49 54 0 4 50 0 50 0 5 50 0 50 50 0 4 51 0 49 0 4 51 0 50 0 4 51 0 53 0 4 51 0 55 0 4 51 0 57 0"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[51]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 3 0 49 0 3 0 50 0 4 0 50 49 0 3 0 53 0 3 0 55 0"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[52]));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 49 49 0 4 0 49 53 0 4 0 49 54 0 4 0 49 57 0 4 0 50 48 0 4 0 50 51 0 3 0 56 0"));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[53]));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 49 48 0 4 0 49 50 0 4 0 49 56 0 4 0 49 57 0 3 0 55 0"));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[54]));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 3 0 49 0 4 0 49 52 0 3 0 50 0 4 0 50 48 0 3 0 52 0 3 0 54 0"));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[55]));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 3 0 49 0 4 0 49 48 0 4 0 49 52 0 4 0 49 57 0 4 0 50 48 0 3 0 52 0 3 0 53 0"));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[56]));
static CONSTANT_18: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 0 49 49 0 4 0 49 57 0 4 0 50 49 0 3 0 53 0 3 0 54 0 3 0 57 0"));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[57]));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 4 0 49 50 0 4 0 49 55 0 4 0 49 57 0 4 0 50 51 0 3 0 51 0 3 0 52 0 3 0 53 0 3 0 55 0"));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("120 10 67 101 108 108 0 48 0 49 48 0 10 67 101 108 108 0 48 0 49 49 0 10 67 101 108 108 0 49 0 49 51 0 10 67 101 108 108 0 49 0 49 52 0 10 67 101 108 108 0 49 0 50 48 0 11 67 101 108 108 0 49 48 0 49 50 0 11 67 101 108 108 0 49 48 0 49 56 0 11 67 101 108 108 0 49 48 0 50 51 0 10 67 101 108 108 0 49 48 0 54 0 10 67 101 108 108 0 49 48 0 57 0 11 67 101 108 108 0 49 49 0 49 49 0 11 67 101 108 108 0 49 49 0 49 50 0 11 67 101 108 108 0 49 49 0 50 51 0 10 67 101 108 108 0 49 49 0 51 0 10 67 101 108 108 0 49 49 0 53 0 11 67 101 108 108 0 49 50 0 49 54 0 11 67 101 108 108 0 49 50 0 49 57 0 10 67 101 108 108 0 49 50 0 50 0 11 67 101 108 108 0 49 51 0 49 52 0 11 67 101 108 108 0 49 51 0 50 48 0 11 67 101 108 108 0 49 51 0 50 49 0 10 67 101 108 108 0 49 51 0 57 0 10 67 101 108 108 0 49 52 0 48 0 11 67 101 108 108 0 49 52 0 49 56 0 10 67 101 108 108 0 49 52 0 54 0 10 67 101 108 108 0 49 52 0 56 0 10 67 101 108 108 0 49 52 0 57 0 10 67 101 108 108 0 49 53 0 49 0 11 67 101 108 108 0 49 53 0 49 54 0 11 67 101 108 108 0 49 53 0 49 55 0 11 67 101 108 108 0 49 53 0 49 57 0 11 67 101 108 108 0 49 53 0 50 48 0 10 67 101 108 108 0 49 53 0 51 0 10 67 101 108 108 0 49 53 0 53 0 10 67 101 108 108 0 49 53 0 54 0 10 67 101 108 108 0 49 54 0 48 0 11 67 101 108 108 0 49 55 0 49 50 0 11 67 101 108 108 0 49 55 0 49 54 0 11 67 101 108 108 0 49 55 0 49 56 0 10 67 101 108 108 0 49 55 0 50 0 10 67 101 108 108 0 49 55 0 51 0 10 67 101 108 108 0 49 55 0 52 0 10 67 101 108 108 0 49 55 0 54 0 10 67 101 108 108 0 49 55 0 55 0 10 67 101 108 108 0 49 55 0 57 0 11 67 101 108 108 0 49 56 0 49 48 0 11 67 101 108 108 0 49 56 0 49 50 0 11 67 101 108 108 0 49 56 0 49 51 0 11 67 101 108 108 0 49 56 0 49 53 0 11 67 101 108 108 0 49 56 0 49 55 0 11 67 101 108 108 0 49 56 0 50 50 0 10 67 101 108 108 0 49 56 0 53 0 11 67 101 108 108 0 49 57 0 49 56 0 11 67 101 108 108 0 49 57 0 50 49 0 10 67 101 108 108 0 49 57 0 51 0 10 67 101 108 108 0 50 0 49 48 0 10 67 101 108 108 0 50 0 49 51 0 10 67 101 108 108 0 50 0 50 49 0 11 67 101 108 108 0 50 48 0 49 53 0 10 67 101 108 108 0 50 48 0 50 0 10 67 101 108 108 0 50 48 0 53 0 10 67 101 108 108 0 50 48 0 55 0 10 67 101 108 108 0 50 48 0 57 0 11 67 101 108 108 0 50 49 0 49 51 0 11 67 101 108 108 0 50 49 0 49 53 0 10 67 101 108 108 0 50 49 0 52 0 10 67 101 108 108 0 50 49 0 56 0 10 67 101 108 108 0 50 49 0 57 0 11 67 101 108 108 0 50 50 0 49 54 0 10 67 101 108 108 0 50 50 0 50 0 11 67 101 108 108 0 50 50 0 50 50 0 10 67 101 108 108 0 50 51 0 49 0 10 67 101 108 108 0 50 51 0 50 0 10 67 101 108 108 0 50 51 0 53 0 10 67 101 108 108 0 50 51 0 55 0 10 67 101 108 108 0 50 51 0 57 0 9 67 101 108 108 0 51 0 49 0 9 67 101 108 108 0 51 0 50 0 10 67 101 108 108 0 51 0 50 49 0 9 67 101 108 108 0 51 0 53 0 9 67 101 108 108 0 51 0 55 0 10 67 101 108 108 0 52 0 49 49 0 10 67 101 108 108 0 52 0 49 53 0 10 67 101 108 108 0 52 0 49 54 0 10 67 101 108 108 0 52 0 49 57 0 10 67 101 108 108 0 52 0 50 48 0 10 67 101 108 108 0 52 0 50 51 0 9 67 101 108 108 0 52 0 56 0 10 67 101 108 108 0 53 0 49 48 0 10 67 101 108 108 0 53 0 49 50 0 10 67 101 108 108 0 53 0 49 56 0 10 67 101 108 108 0 53 0 49 57 0 9 67 101 108 108 0 53 0 55 0 9 67 101 108 108 0 54 0 49 0 10 67 101 108 108 0 54 0 49 52 0 9 67 101 108 108 0 54 0 50 0 10 67 101 108 108 0 54 0 50 48 0 9 67 101 108 108 0 54 0 52 0 9 67 101 108 108 0 54 0 54 0 9 67 101 108 108 0 55 0 49 0 10 67 101 108 108 0 55 0 49 48 0 10 67 101 108 108 0 55 0 49 52 0 10 67 101 108 108 0 55 0 49 57 0 10 67 101 108 108 0 55 0 50 48 0 9 67 101 108 108 0 55 0 52 0 9 67 101 108 108 0 55 0 53 0 10 67 101 108 108 0 56 0 49 49 0 10 67 101 108 108 0 56 0 49 57 0 10 67 101 108 108 0 56 0 50 49 0 9 67 101 108 108 0 56 0 53 0 9 67 101 108 108 0 56 0 54 0 9 67 101 108 108 0 56 0 57 0 10 67 101 108 108 0 57 0 49 50 0 10 67 101 108 108 0 57 0 49 55 0 10 67 101 108 108 0 57 0 49 57 0 10 67 101 108 108 0 57 0 50 51 0 9 67 101 108 108 0 57 0 51 0 9 67 101 108 108 0 57 0 52 0 9 67 101 108 108 0 57 0 53 0 9 67 101 108 108 0 57 0 55 0"));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[67,101,108,108,0]));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 104 105 116 0"));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("387 6 45 49 0 45 49 0 6 45 49 0 45 50 0 5 45 49 0 48 0 8 45 49 48 0 45 49 48 0 8 45 49 48 0 45 49 49 0 7 45 49 48 0 45 57 0 8 45 49 49 0 45 49 48 0 8 45 49 49 0 45 49 49 0 8 45 49 49 0 45 49 50 0 8 45 49 50 0 45 49 49 0 8 45 49 50 0 45 49 50 0 8 45 49 50 0 45 49 51 0 8 45 49 51 0 45 49 50 0 8 45 49 51 0 45 49 51 0 8 45 49 51 0 45 49 52 0 8 45 49 52 0 45 49 51 0 8 45 49 52 0 45 49 52 0 8 45 49 52 0 45 49 53 0 8 45 49 53 0 45 49 52 0 8 45 49 53 0 45 49 53 0 8 45 49 53 0 45 49 54 0 8 45 49 54 0 45 49 53 0 8 45 49 54 0 45 49 54 0 8 45 49 54 0 45 49 55 0 8 45 49 55 0 45 49 54 0 8 45 49 55 0 45 49 55 0 8 45 49 55 0 45 49 56 0 8 45 49 56 0 45 49 55 0 8 45 49 56 0 45 49 56 0 8 45 49 56 0 45 49 57 0 8 45 49 57 0 45 49 56 0 8 45 49 57 0 45 49 57 0 8 45 49 57 0 45 50 48 0 6 45 50 0 45 49 0 6 45 50 0 45 50 0 6 45 50 0 45 51 0 8 45 50 48 0 45 49 57 0 8 45 50 48 0 45 50 48 0 8 45 50 48 0 45 50 49 0 8 45 50 49 0 45 50 48 0 8 45 50 49 0 45 50 49 0 8 45 50 49 0 45 50 50 0 8 45 50 50 0 45 50 49 0 8 45 50 50 0 45 50 50 0 8 45 50 50 0 45 50 51 0 8 45 50 51 0 45 50 50 0 8 45 50 51 0 45 50 51 0 8 45 50 51 0 45 50 52 0 8 45 50 52 0 45 50 51 0 8 45 50 52 0 45 50 52 0 8 45 50 52 0 45 50 53 0 8 45 50 53 0 45 50 52 0 8 45 50 53 0 45 50 53 0 8 45 50 53 0 45 50 54 0 8 45 50 54 0 45 50 53 0 8 45 50 54 0 45 50 54 0 8 45 50 54 0 45 50 55 0 8 45 50 55 0 45 50 54 0 8 45 50 55 0 45 50 55 0 8 45 50 55 0 45 50 56 0 8 45 50 56 0 45 50 55 0 8 45 50 56 0 45 50 56 0 8 45 50 56 0 45 50 57 0 8 45 50 57 0 45 50 56 0 8 45 50 57 0 45 50 57 0 8 45 50 57 0 45 51 48 0 6 45 51 0 45 50 0 6 45 51 0 45 51 0 6 45 51 0 45 52 0 8 45 51 48 0 45 50 57 0 8 45 51 48 0 45 51 48 0 8 45 51 48 0 45 51 49 0 8 45 51 49 0 45 51 48 0 8 45 51 49 0 45 51 49 0 8 45 51 49 0 45 51 50 0 8 45 51 50 0 45 51 49 0 8 45 51 50 0 45 51 50 0 8 45 51 50 0 45 51 51 0 8 45 51 51 0 45 51 50 0 8 45 51 51 0 45 51 51 0 8 45 51 51 0 45 51 52 0 8 45 51 52 0 45 51 51 0 8 45 51 52 0 45 51 52 0 8 45 51 52 0 45 51 53 0 8 45 51 53 0 45 51 52 0 8 45 51 53 0 45 51 53 0 8 45 51 53 0 45 51 54 0 8 45 51 54 0 45 51 53 0 8 45 51 54 0 45 51 54 0 8 45 51 54 0 45 51 55 0 8 45 51 55 0 45 51 54 0 8 45 51 55 0 45 51 55 0 8 45 51 55 0 45 51 56 0 8 45 51 56 0 45 51 55 0 8 45 51 56 0 45 51 56 0 8 45 51 56 0 45 51 57 0 8 45 51 57 0 45 51 56 0 8 45 51 57 0 45 51 57 0 8 45 51 57 0 45 52 48 0 6 45 52 0 45 51 0 6 45 52 0 45 52 0 6 45 52 0 45 53 0 8 45 52 48 0 45 51 57 0 8 45 52 48 0 45 52 48 0 8 45 52 48 0 45 52 49 0 8 45 52 49 0 45 52 48 0 8 45 52 49 0 45 52 49 0 8 45 52 49 0 45 52 50 0 8 45 52 50 0 45 52 49 0 8 45 52 50 0 45 52 50 0 8 45 52 50 0 45 52 51 0 8 45 52 51 0 45 52 50 0 8 45 52 51 0 45 52 51 0 8 45 52 51 0 45 52 52 0 8 45 52 52 0 45 52 51 0 8 45 52 52 0 45 52 52 0 8 45 52 52 0 45 52 53 0 8 45 52 53 0 45 52 52 0 8 45 52 53 0 45 52 53 0 8 45 52 53 0 45 52 54 0 8 45 52 54 0 45 52 53 0 8 45 52 54 0 45 52 54 0 8 45 52 54 0 45 52 55 0 8 45 52 55 0 45 52 54 0 8 45 52 55 0 45 52 55 0 8 45 52 55 0 45 52 56 0 8 45 52 56 0 45 52 55 0 8 45 52 56 0 45 52 56 0 8 45 52 56 0 45 52 57 0 8 45 52 57 0 45 52 56 0 8 45 52 57 0 45 52 57 0 8 45 52 57 0 45 53 48 0 6 45 53 0 45 52 0 6 45 53 0 45 53 0 6 45 53 0 45 54 0 8 45 53 48 0 45 52 57 0 8 45 53 48 0 45 53 48 0 8 45 53 48 0 45 53 49 0 8 45 53 49 0 45 53 48 0 8 45 53 49 0 45 53 49 0 8 45 53 49 0 45 53 50 0 8 45 53 50 0 45 53 49 0 8 45 53 50 0 45 53 50 0 8 45 53 50 0 45 53 51 0 8 45 53 51 0 45 53 50 0 8 45 53 51 0 45 53 51 0 8 45 53 51 0 45 53 52 0 8 45 53 52 0 45 53 51 0 8 45 53 52 0 45 53 52 0 8 45 53 52 0 45 53 53 0 8 45 53 53 0 45 53 52 0 8 45 53 53 0 45 53 53 0 8 45 53 53 0 45 53 54 0 8 45 53 54 0 45 53 53 0 8 45 53 54 0 45 53 54 0 8 45 53 54 0 45 53 55 0 8 45 53 55 0 45 53 54 0 8 45 53 55 0 45 53 55 0 8 45 53 55 0 45 53 56 0 8 45 53 56 0 45 53 55 0 8 45 53 56 0 45 53 56 0 8 45 53 56 0 45 53 57 0 8 45 53 57 0 45 53 56 0 8 45 53 57 0 45 53 57 0 8 45 53 57 0 45 54 48 0 6 45 54 0 45 53 0 6 45 54 0 45 54 0 6 45 54 0 45 55 0 8 45 54 48 0 45 53 57 0 8 45 54 48 0 45 54 48 0 8 45 54 48 0 45 54 49 0 8 45 54 49 0 45 54 48 0 8 45 54 49 0 45 54 49 0 8 45 54 49 0 45 54 50 0 8 45 54 50 0 45 54 49 0 8 45 54 50 0 45 54 50 0 8 45 54 50 0 45 54 51 0 8 45 54 51 0 45 54 50 0 8 45 54 51 0 45 54 51 0 8 45 54 51 0 45 54 52 0 8 45 54 52 0 45 54 51 0 8 45 54 52 0 45 54 52 0 8 45 54 52 0 45 54 53 0 6 45 55 0 45 54 0 6 45 55 0 45 55 0 6 45 55 0 45 56 0 6 45 56 0 45 55 0 6 45 56 0 45 56 0 6 45 56 0 45 57 0 7 45 57 0 45 49 48 0 6 45 57 0 45 56 0 6 45 57 0 45 57 0 5 48 0 45 49 0 4 48 0 48 0 4 48 0 49 0 4 49 0 48 0 4 49 0 49 0 4 49 0 50 0 6 49 48 0 49 48 0 6 49 48 0 49 49 0 5 49 48 0 57 0 6 49 49 0 49 48 0 6 49 49 0 49 49 0 6 49 49 0 49 50 0 6 49 50 0 49 49 0 6 49 50 0 49 50 0 6 49 50 0 49 51 0 6 49 51 0 49 50 0 6 49 51 0 49 51 0 6 49 51 0 49 52 0 6 49 52 0 49 51 0 6 49 52 0 49 52 0 6 49 52 0 49 53 0 6 49 53 0 49 52 0 6 49 53 0 49 53 0 6 49 53 0 49 54 0 6 49 54 0 49 53 0 6 49 54 0 49 54 0 6 49 54 0 49 55 0 6 49 55 0 49 54 0 6 49 55 0 49 55 0 6 49 55 0 49 56 0 6 49 56 0 49 55 0 6 49 56 0 49 56 0 6 49 56 0 49 57 0 6 49 57 0 49 56 0 6 49 57 0 49 57 0 6 49 57 0 50 48 0 4 50 0 49 0 4 50 0 50 0 4 50 0 51 0 6 50 48 0 49 57 0 6 50 48 0 50 48 0 6 50 48 0 50 49 0 6 50 49 0 50 48 0 6 50 49 0 50 49 0 6 50 49 0 50 50 0 6 50 50 0 50 49 0 6 50 50 0 50 50 0 6 50 50 0 50 51 0 6 50 51 0 50 50 0 6 50 51 0 50 51 0 6 50 51 0 50 52 0 6 50 52 0 50 51 0 6 50 52 0 50 52 0 6 50 52 0 50 53 0 6 50 53 0 50 52 0 6 50 53 0 50 53 0 6 50 53 0 50 54 0 6 50 54 0 50 53 0 6 50 54 0 50 54 0 6 50 54 0 50 55 0 6 50 55 0 50 54 0 6 50 55 0 50 55 0 6 50 55 0 50 56 0 6 50 56 0 50 55 0 6 50 56 0 50 56 0 6 50 56 0 50 57 0 6 50 57 0 50 56 0 6 50 57 0 50 57 0 6 50 57 0 51 48 0 4 51 0 50 0 4 51 0 51 0 4 51 0 52 0 6 51 48 0 50 57 0 6 51 48 0 51 48 0 6 51 48 0 51 49 0 6 51 49 0 51 48 0 6 51 49 0 51 49 0 6 51 49 0 51 50 0 6 51 50 0 51 49 0 6 51 50 0 51 50 0 6 51 50 0 51 51 0 6 51 51 0 51 50 0 6 51 51 0 51 51 0 6 51 51 0 51 52 0 6 51 52 0 51 51 0 6 51 52 0 51 52 0 6 51 52 0 51 53 0 6 51 53 0 51 52 0 6 51 53 0 51 53 0 6 51 53 0 51 54 0 6 51 54 0 51 53 0 6 51 54 0 51 54 0 6 51 54 0 51 55 0 6 51 55 0 51 54 0 6 51 55 0 51 55 0 6 51 55 0 51 56 0 6 51 56 0 51 55 0 6 51 56 0 51 56 0 6 51 56 0 51 57 0 6 51 57 0 51 56 0 6 51 57 0 51 57 0 6 51 57 0 52 48 0 4 52 0 51 0 4 52 0 52 0 4 52 0 53 0 6 52 48 0 51 57 0 6 52 48 0 52 48 0 6 52 48 0 52 49 0 6 52 49 0 52 48 0 6 52 49 0 52 49 0 6 52 49 0 52 50 0 6 52 50 0 52 49 0 6 52 50 0 52 50 0 6 52 50 0 52 51 0 6 52 51 0 52 50 0 6 52 51 0 52 51 0 6 52 51 0 52 52 0 6 52 52 0 52 51 0 6 52 52 0 52 52 0 6 52 52 0 52 53 0 6 52 53 0 52 52 0 6 52 53 0 52 53 0 6 52 53 0 52 54 0 6 52 54 0 52 53 0 6 52 54 0 52 54 0 6 52 54 0 52 55 0 6 52 55 0 52 54 0 6 52 55 0 52 55 0 6 52 55 0 52 56 0 6 52 56 0 52 55 0 6 52 56 0 52 56 0 6 52 56 0 52 57 0 6 52 57 0 52 56 0 6 52 57 0 52 57 0 6 52 57 0 53 48 0 4 53 0 52 0 4 53 0 53 0 4 53 0 54 0 6 53 48 0 52 57 0 6 53 48 0 53 48 0 6 53 48 0 53 49 0 6 53 49 0 53 48 0 6 53 49 0 53 49 0 6 53 49 0 53 50 0 6 53 50 0 53 49 0 6 53 50 0 53 50 0 6 53 50 0 53 51 0 6 53 51 0 53 50 0 6 53 51 0 53 51 0 6 53 51 0 53 52 0 6 53 52 0 53 51 0 6 53 52 0 53 52 0 6 53 52 0 53 53 0 6 53 53 0 53 52 0 6 53 53 0 53 53 0 6 53 53 0 53 54 0 6 53 54 0 53 53 0 6 53 54 0 53 54 0 6 53 54 0 53 55 0 6 53 55 0 53 54 0 6 53 55 0 53 55 0 6 53 55 0 53 56 0 6 53 56 0 53 55 0 6 53 56 0 53 56 0 6 53 56 0 53 57 0 6 53 57 0 53 56 0 6 53 57 0 53 57 0 6 53 57 0 54 48 0 4 54 0 53 0 4 54 0 54 0 4 54 0 55 0 6 54 48 0 53 57 0 6 54 48 0 54 48 0 6 54 48 0 54 49 0 6 54 49 0 54 48 0 6 54 49 0 54 49 0 6 54 49 0 54 50 0 6 54 50 0 54 49 0 6 54 50 0 54 50 0 6 54 50 0 54 51 0 6 54 51 0 54 50 0 6 54 51 0 54 51 0 6 54 51 0 54 52 0 6 54 52 0 54 51 0 6 54 52 0 54 52 0 6 54 52 0 54 53 0 4 55 0 54 0 4 55 0 55 0 4 55 0 56 0 4 56 0 55 0 4 56 0 56 0 4 56 0 57 0 5 57 0 49 48 0 4 57 0 56 0 4 57 0 57 0"));
fn routine_0(c: &mut Context) -> Space {
  let v0_40: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v1_3: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
    let v1_6: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4));
    let v1_7: Space = unite(&(v1_3),&(v1_6));
    let v1_10: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_6));
    let v1_11: Space = unite(&(v1_7),&(v1_10));
    let v1_14: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_8));
    let v1_15: Space = unite(&(v1_11),&(v1_14));
    let v1_18: Space = routine_1(c, &(*CONSTANT_9), &(*CONSTANT_10));
    let v1_19: Space = unite(&(v1_15),&(v1_18));
    let v1_22: Space = routine_1(c, &(*CONSTANT_11), &(*CONSTANT_12));
    let v1_23: Space = unite(&(v1_19),&(v1_22));
    let v1_26: Space = routine_1(c, &(*CONSTANT_13), &(*CONSTANT_14));
    let v1_27: Space = unite(&(v1_23),&(v1_26));
    let v1_30: Space = routine_1(c, &(*CONSTANT_15), &(*CONSTANT_16));
    let v1_31: Space = unite(&(v1_27),&(v1_30));
    let v1_34: Space = routine_1(c, &(*CONSTANT_17), &(*CONSTANT_18));
    let v1_35: Space = unite(&(v1_31),&(v1_34));
    let v1_38: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_20));
    let v1_39: Space = unite(&(v1_35),&(v1_38));
    compose(&(*CONSTANT_0),&(v1_39))
  };
  let mut v0_46 = Space::new();
  let mut v0_46_cursor = (v0_40).read_zipper();
  for v0_46_byte in v0_46_cursor.child_mask().iter() {
    v0_46_cursor.descend_to_byte(v0_46_byte);
    {
    let v0_46_tail = v0_46_cursor.fork_read_zipper();
    let v0_46_head = Path::from_slice(&[v0_46_byte]);
    let v2_2: Space = singleton(&(v0_46_head));
    let v2_3: Space = intersect(&(*CONSTANT_21),&(v2_2));
    let v2_4: Space = if has_head(&(v2_3)) { singleton(&[]) } else { Space::new() };
    drop(v2_3);
    let v2_5: Space = subtract(&(*CONSTANT_0),&(v2_4));
    drop(v2_4);
    let v2_7: Space = if (v2_5).is_empty() { Space::new() } else {
      let v3_6: Space = routine_2(c, &(v0_46_head), &(v0_46_tail).make_space(), &(*CONSTANT_22));
      compose(&(v2_5),&(v3_6))
    };
    drop(v2_5);
    let v2_8: Space = intersect(&(*CONSTANT_21),&(v2_2));
    drop(v2_2);
    let v2_9: Space = if has_head(&(v2_8)) { singleton(&[]) } else { Space::new() };
    drop(v2_8);
    let v2_11: Space = if (v2_9).is_empty() { Space::new() } else {
      let v4_10: Space = routine_3(c, &(v0_46_head), &(v0_46_tail).make_space(), &(*CONSTANT_22));
      compose(&(v2_9),&(v4_10))
    };
    drop(v2_9);
    let v2_12: Space = unite(&(v2_7),&(v2_11));
    v0_46.join_into((v2_12).clone());
    }
    v0_46_cursor.ascend(1);
  }
  drop(v0_46_cursor);
  let v0_87: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v5_50: Space = routine_4(c, &(*CONSTANT_1), &(*CONSTANT_2), &(*CONSTANT_22));
    let v5_53: Space = routine_4(c, &(*CONSTANT_3), &(*CONSTANT_4), &(*CONSTANT_22));
    let v5_54: Space = unite(&(v5_50),&(v5_53));
    let v5_57: Space = routine_4(c, &(*CONSTANT_5), &(*CONSTANT_6), &(*CONSTANT_22));
    let v5_58: Space = unite(&(v5_54),&(v5_57));
    let v5_61: Space = routine_4(c, &(*CONSTANT_7), &(*CONSTANT_8), &(*CONSTANT_22));
    let v5_62: Space = unite(&(v5_58),&(v5_61));
    let v5_65: Space = routine_4(c, &(*CONSTANT_9), &(*CONSTANT_10), &(*CONSTANT_22));
    let v5_66: Space = unite(&(v5_62),&(v5_65));
    let v5_69: Space = routine_4(c, &(*CONSTANT_11), &(*CONSTANT_12), &(*CONSTANT_22));
    let v5_70: Space = unite(&(v5_66),&(v5_69));
    let v5_73: Space = routine_4(c, &(*CONSTANT_13), &(*CONSTANT_14), &(*CONSTANT_22));
    let v5_74: Space = unite(&(v5_70),&(v5_73));
    let v5_77: Space = routine_4(c, &(*CONSTANT_15), &(*CONSTANT_16), &(*CONSTANT_22));
    let v5_78: Space = unite(&(v5_74),&(v5_77));
    let v5_81: Space = routine_4(c, &(*CONSTANT_17), &(*CONSTANT_18), &(*CONSTANT_22));
    let v5_82: Space = unite(&(v5_78),&(v5_81));
    let v5_85: Space = routine_4(c, &(*CONSTANT_19), &(*CONSTANT_20), &(*CONSTANT_22));
    let v5_86: Space = unite(&(v5_82),&(v5_85));
    compose(&(*CONSTANT_0),&(v5_86))
  };
  let v0_88: Space = unite(&(v0_46),&(v0_87));
  let v0_90: Space = wrap(&(v0_88),&(*CONSTANT_23));
  (v0_90).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v6_8 = Space::new();
  let mut v6_8_cursor = (*s0).read_zipper();
  for v6_8_byte in v6_8_cursor.child_mask().iter() {
    v6_8_cursor.descend_to_byte(v6_8_byte);
    {
    let v6_8_tail = v6_8_cursor.fork_read_zipper();
    let v6_8_head = Path::from_slice(&[v6_8_byte]);
    let v7_2: Space = singleton(&(v6_8_head));
    let v7_3: Space = intersect(&(*CONSTANT_21),&(v7_2));
    let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
    drop(v7_3);
    let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
    drop(v7_4);
    let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
      let v8_6: Path = concat_path(&(*p0),&(v6_8_head));
      let v8_7: Space = routine_1(c, &(v8_6), &(v6_8_tail).make_space());
      compose(&(v7_5),&(v8_7))
    };
    drop(v7_5);
    let v7_9: Space = intersect(&(*CONSTANT_21),&(v7_2));
    drop(v7_2);
    let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
    drop(v7_9);
    let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
      let v9_6: Path = concat_path(&(*p0),&(v6_8_head));
      let mut v9_11 = Space::new();
      let mut v9_11_cursor = (v6_8_tail).read_zipper();
      for v9_11_byte in v9_11_cursor.child_mask().iter() {
        v9_11_cursor.descend_to_byte(v9_11_byte);
        {
        let v9_11_tail = v9_11_cursor.fork_read_zipper();
        let v9_11_head = Path::from_slice(&[v9_11_byte]);
        let v10_2: Space = singleton(&(v9_11_head));
        let v10_3: Space = intersect(&(*CONSTANT_21),&(v10_2));
        let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
        drop(v10_3);
        let v10_5: Space = subtract(&(*CONSTANT_0),&(v10_4));
        drop(v10_4);
        let v10_7: Space = if (v10_5).is_empty() { Space::new() } else {
          let v11_6: Space = routine_5(c, &(v9_11_head), &(v9_6), &(v9_11_tail).make_space());
          compose(&(v10_5),&(v11_6))
        };
        drop(v10_5);
        let v10_8: Space = intersect(&(*CONSTANT_21),&(v10_2));
        drop(v10_2);
        let v10_9: Space = if has_head(&(v10_8)) { singleton(&[]) } else { Space::new() };
        drop(v10_8);
        let v10_12: Space = if (v10_9).is_empty() { Space::new() } else {
          let v12_10: Path = concat_path(&(v9_6),&(v9_11_head));
          let v12_11: Space = routine_6(c, &(v12_10));
          drop(v12_10);
          compose(&(v10_9),&(v12_11))
        };
        drop(v10_9);
        let v10_13: Space = unite(&(v10_7),&(v10_12));
        v9_11.join_into((v10_13).clone());
        }
        v9_11_cursor.ascend(1);
      }
      drop(v9_11_cursor);
      drop(v9_6);
      compose(&(v7_10),&(v9_11))
    };
    drop(v7_10);
    let v7_13: Space = unite(&(v7_8),&(v7_12));
    v6_8.join_into((v7_13).clone());
    }
    v6_8_cursor.ascend(1);
  }
  drop(v6_8_cursor);
  (v6_8).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v13_9 = Space::new();
  let mut v13_9_cursor = (*s0).read_zipper();
  for v13_9_byte in v13_9_cursor.child_mask().iter() {
    v13_9_cursor.descend_to_byte(v13_9_byte);
    {
    let v13_9_tail = v13_9_cursor.fork_read_zipper();
    let v13_9_head = Path::from_slice(&[v13_9_byte]);
    let v14_2: Space = singleton(&(v13_9_head));
    let v14_3: Space = intersect(&(*CONSTANT_21),&(v14_2));
    let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
    drop(v14_3);
    let v14_5: Space = subtract(&(*CONSTANT_0),&(v14_4));
    drop(v14_4);
    let v14_8: Space = if (v14_5).is_empty() { Space::new() } else {
      let v15_6: Path = concat_path(&(*p0),&(v13_9_head));
      let v15_7: Space = routine_2(c, &(v15_6), &(v13_9_tail).make_space(), &(*s1));
      compose(&(v14_5),&(v15_7))
    };
    drop(v14_5);
    let v14_9: Space = intersect(&(*CONSTANT_21),&(v14_2));
    drop(v14_2);
    let v14_10: Space = if has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
    drop(v14_9);
    let v14_12: Space = if (v14_10).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v13_9_head));
      let mut v16_11 = Space::new();
      let mut v16_11_cursor = (v13_9_tail).read_zipper();
      for v16_11_byte in v16_11_cursor.child_mask().iter() {
        v16_11_cursor.descend_to_byte(v16_11_byte);
        {
        let v16_11_tail = v16_11_cursor.fork_read_zipper();
        let v16_11_head = Path::from_slice(&[v16_11_byte]);
        let v17_2: Space = singleton(&(v16_11_head));
        let v17_3: Space = intersect(&(*CONSTANT_21),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
        drop(v17_4);
        let v17_7: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Space = routine_7(c, &(v16_11_head), &(v16_6), &(v16_11_tail).make_space(), &(*s1));
          compose(&(v17_5),&(v18_6))
        };
        drop(v17_5);
        let v17_8: Space = intersect(&(*CONSTANT_21),&(v17_2));
        drop(v17_2);
        let v17_9: Space = if has_head(&(v17_8)) { singleton(&[]) } else { Space::new() };
        drop(v17_8);
        let v17_11: Space = if (v17_9).is_empty() { Space::new() } else {
          let v19_10: Space = routine_8(c, &(v16_11_head), &(v16_6), &(v16_11_tail).make_space(), &(*s1));
          compose(&(v17_9),&(v19_10))
        };
        drop(v17_9);
        let v17_12: Space = unite(&(v17_7),&(v17_11));
        v16_11.join_into((v17_12).clone());
        }
        v16_11_cursor.ascend(1);
      }
      drop(v16_11_cursor);
      drop(v16_6);
      compose(&(v14_10),&(v16_11))
    };
    drop(v14_10);
    let v14_13: Space = unite(&(v14_8),&(v14_12));
    v13_9.join_into((v14_13).clone());
    }
    v13_9_cursor.ascend(1);
  }
  drop(v13_9_cursor);
  (v13_9).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v20_7: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let mut v20_28 = Space::new();
  let mut v20_28_cursor = (*s0).read_zipper();
  for v20_28_byte in v20_28_cursor.child_mask().iter() {
    v20_28_cursor.descend_to_byte(v20_28_byte);
    {
    let v20_28_tail = v20_28_cursor.fork_read_zipper();
    let v20_28_head = Path::from_slice(&[v20_28_byte]);
    let v21_2: Space = singleton(&(v20_28_head));
    let v21_3: Space = intersect(&(*CONSTANT_21),&(v21_2));
    let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
    drop(v21_3);
    let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
    drop(v21_4);
    let v21_7: Space = if (v21_5).is_empty() { Space::new() } else {
      let mut v22_6 = Space::new();
      let mut v22_6_cursor = (v20_28_tail).read_zipper();
      for v22_6_byte in v22_6_cursor.child_mask().iter() {
        v22_6_cursor.descend_to_byte(v22_6_byte);
        {
        let v22_6_tail = v22_6_cursor.fork_read_zipper();
        let v22_6_head = Path::from_slice(&[v22_6_byte]);
        let v23_2: Space = singleton(&(v22_6_head));
        let v23_3: Space = intersect(&(*CONSTANT_21),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v20_28_head),&(v22_6_head));
          let v24_7: Space = routine_7(c, &(v24_6), &(*p0), &(v22_6_tail).make_space(), &(*s1));
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_21),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_12: Space = if (v23_10).is_empty() { Space::new() } else {
          let v25_6: Path = concat_path(&(v20_28_head),&(v22_6_head));
          let v25_11: Space = routine_8(c, &(v25_6), &(*p0), &(v22_6_tail).make_space(), &(*s1));
          drop(v25_6);
          compose(&(v23_10),&(v25_11))
        };
        drop(v23_10);
        let v23_13: Space = unite(&(v23_8),&(v23_12));
        v22_6.join_into((v23_13).clone());
        }
        v22_6_cursor.ascend(1);
      }
      drop(v22_6_cursor);
      compose(&(v21_5),&(v22_6))
    };
    drop(v21_5);
    let v21_8: Space = intersect(&(*CONSTANT_21),&(v21_2));
    drop(v21_2);
    let v21_9: Space = if has_head(&(v21_8)) { singleton(&[]) } else { Space::new() };
    drop(v21_8);
    let v21_23: Space = if (v21_9).is_empty() { Space::new() } else {
      let v26_10: Path = concat_path(&(*p0),&(v20_28_head));
      let v26_11: Space = singleton(&(v26_10));
      drop(v26_10);
      let mut v26_12 = Space::new();
      let mut v26_12_cursor = (v26_11).read_zipper();
      for v26_12_byte in v26_12_cursor.child_mask().iter() {
        v26_12_cursor.descend_to_byte(v26_12_byte);
        {
        let v26_12_tail = v26_12_cursor.fork_read_zipper();
        let v26_12_head = Path::from_slice(&[v26_12_byte]);
        let v27_2: Space = singleton(&(v26_12_head));
        let v27_3: Space = intersect(&(*CONSTANT_21),&(v27_2));
        let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
        drop(v27_3);
        let v27_5: Space = subtract(&(*CONSTANT_0),&(v27_4));
        drop(v27_4);
        let v27_7: Space = if (v27_5).is_empty() { Space::new() } else {
          let v28_6: Space = routine_9(c, &(v26_12_head), &(v26_12_tail).make_space());
          compose(&(v27_5),&(v28_6))
        };
        drop(v27_5);
        let v27_8: Space = intersect(&(*CONSTANT_21),&(v27_2));
        drop(v27_2);
        let v27_9: Space = if has_head(&(v27_8)) { singleton(&[]) } else { Space::new() };
        drop(v27_8);
        let v27_11: Space = if (v27_9).is_empty() { Space::new() } else {
          let v29_10: Space = routine_10(c, &(v26_12_head), &(v26_12_tail).make_space());
          compose(&(v27_9),&(v29_10))
        };
        drop(v27_9);
        let v27_12: Space = unite(&(v27_7),&(v27_11));
        v26_12.join_into((v27_12).clone());
        }
        v26_12_cursor.ascend(1);
      }
      drop(v26_12_cursor);
      let v26_13: Space = intersect(&(v20_7),&(v26_12));
      let v26_14: Space = range_const::<{3},{4}>(&(v26_13));
      let mut v26_15 = Space::new();
      let mut v26_15_cursor = (v26_14).read_zipper();
      for v26_15_byte in v26_15_cursor.child_mask().iter() {
        v26_15_cursor.descend_to_byte(v26_15_byte);
        {
        let v26_15_tail = v26_15_cursor.fork_read_zipper();
        let v26_15_head = Path::from_slice(&[v26_15_byte]);
        let v30_2: Space = singleton(&(v26_15_head));
        let v30_3: Space = intersect(&(*CONSTANT_21),&(v30_2));
        let v30_4: Space = if has_head(&(v30_3)) { singleton(&[]) } else { Space::new() };
        drop(v30_3);
        let v30_5: Space = subtract(&(*CONSTANT_0),&(v30_4));
        drop(v30_4);
        let v30_7: Space = if (v30_5).is_empty() { Space::new() } else {
          let v31_6: Space = routine_11(c, &(v26_15_head), &(v26_15_tail).make_space());
          compose(&(v30_5),&(v31_6))
        };
        drop(v30_5);
        let v30_8: Space = intersect(&(*CONSTANT_21),&(v30_2));
        drop(v30_2);
        let v30_9: Space = if has_head(&(v30_8)) { singleton(&[]) } else { Space::new() };
        drop(v30_8);
        let v30_10: Space = compose(&(v30_9),&(*CONSTANT_24));
        drop(v30_9);
        let v30_11: Space = unite(&(v30_7),&(v30_10));
        drop(v30_10);
        v26_15.join_into((v30_11).clone());
        }
        v26_15_cursor.ascend(1);
      }
      drop(v26_15_cursor);
      let mut v26_16 = Space::new();
      let mut v26_16_cursor = (v26_11).read_zipper();
      for v26_16_byte in v26_16_cursor.child_mask().iter() {
        v26_16_cursor.descend_to_byte(v26_16_byte);
        {
        let v26_16_tail = v26_16_cursor.fork_read_zipper();
        let v26_16_head = Path::from_slice(&[v26_16_byte]);
        let v32_2: Space = singleton(&(v26_16_head));
        let v32_3: Space = intersect(&(*CONSTANT_21),&(v32_2));
        let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
        drop(v32_3);
        let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
        drop(v32_4);
        let v32_7: Space = if (v32_5).is_empty() { Space::new() } else {
          let v33_6: Space = routine_9(c, &(v26_16_head), &(v26_16_tail).make_space());
          compose(&(v32_5),&(v33_6))
        };
        drop(v32_5);
        let v32_8: Space = intersect(&(*CONSTANT_21),&(v32_2));
        drop(v32_2);
        let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
        drop(v32_8);
        let v32_11: Space = if (v32_9).is_empty() { Space::new() } else {
          let v34_10: Space = routine_10(c, &(v26_16_head), &(v26_16_tail).make_space());
          compose(&(v32_9),&(v34_10))
        };
        drop(v32_9);
        let v32_12: Space = unite(&(v32_7),&(v32_11));
        v26_16.join_into((v32_12).clone());
        }
        v26_16_cursor.ascend(1);
      }
      drop(v26_16_cursor);
      let v26_17: Space = intersect(&(v20_7),&(v26_16));
      let v26_18: Space = range_const::<{4},{5}>(&(v26_17));
      let mut v26_19 = Space::new();
      let mut v26_19_cursor = (v26_18).read_zipper();
      for v26_19_byte in v26_19_cursor.child_mask().iter() {
        v26_19_cursor.descend_to_byte(v26_19_byte);
        {
        let v26_19_tail = v26_19_cursor.fork_read_zipper();
        let v26_19_head = Path::from_slice(&[v26_19_byte]);
        let v35_2: Space = singleton(&(v26_19_head));
        let v35_3: Space = intersect(&(*CONSTANT_21),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_0),&(v35_4));
        drop(v35_4);
        let v35_7: Space = if (v35_5).is_empty() { Space::new() } else {
          let v36_6: Space = routine_12(c, &(v26_19_head), &(v26_19_tail).make_space());
          compose(&(v35_5),&(v36_6))
        };
        drop(v35_5);
        let v35_8: Space = intersect(&(*CONSTANT_21),&(v35_2));
        drop(v35_2);
        let v35_9: Space = if has_head(&(v35_8)) { singleton(&[]) } else { Space::new() };
        drop(v35_8);
        let v35_10: Space = compose(&(v35_9),&(*CONSTANT_24));
        drop(v35_9);
        let v35_11: Space = unite(&(v35_7),&(v35_10));
        drop(v35_10);
        v26_19.join_into((v35_11).clone());
        }
        v26_19_cursor.ascend(1);
      }
      drop(v26_19_cursor);
      let v26_20: Space = subtract(&(v26_15),&(v26_19));
      let v26_21: Space = if (v26_20).is_empty() { Space::new() } else {
        compose(&(v26_20),&(v26_11))
      };
      drop(v26_11);
      let mut v26_22 = Space::new();
      let mut v26_22_cursor = (v26_21).read_zipper();
      for v26_22_byte in v26_22_cursor.child_mask().iter() {
        v26_22_cursor.descend_to_byte(v26_22_byte);
        {
        let v26_22_tail = v26_22_cursor.fork_read_zipper();
        let v26_22_head = Path::from_slice(&[v26_22_byte]);
        let v38_2: Space = singleton(&(v26_22_head));
        let v38_3: Space = intersect(&(*CONSTANT_21),&(v38_2));
        let v38_4: Space = if has_head(&(v38_3)) { singleton(&[]) } else { Space::new() };
        drop(v38_3);
        let v38_5: Space = subtract(&(*CONSTANT_0),&(v38_4));
        drop(v38_4);
        let v38_7: Space = if (v38_5).is_empty() { Space::new() } else {
          let v39_6: Space = routine_13(c, &(v26_22_head), &(v26_22_tail).make_space());
          compose(&(v38_5),&(v39_6))
        };
        drop(v38_5);
        let v38_8: Space = intersect(&(*CONSTANT_21),&(v38_2));
        drop(v38_2);
        let v38_9: Space = if has_head(&(v38_8)) { singleton(&[]) } else { Space::new() };
        drop(v38_8);
        let v38_10: Space = compose(&(v38_9),&(v26_22_tail));
        drop(v38_9);
        let v38_11: Space = unite(&(v38_7),&(v38_10));
        drop(v38_10);
        v26_22.join_into((v38_11).clone());
        }
        v26_22_cursor.ascend(1);
      }
      drop(v26_22_cursor);
      compose(&(v21_9),&(v26_22))
    };
    drop(v21_9);
    let v21_24: Space = unite(&(v21_7),&(v21_23));
    v20_28.join_into((v21_24).clone());
    }
    v20_28_cursor.ascend(1);
  }
  drop(v20_28_cursor);
  drop(v20_7);
  (v20_28).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v40_9 = Space::new();
  let mut v40_9_cursor = (*s0).read_zipper();
  for v40_9_byte in v40_9_cursor.child_mask().iter() {
    v40_9_cursor.descend_to_byte(v40_9_byte);
    {
    let v40_9_tail = v40_9_cursor.fork_read_zipper();
    let v40_9_head = Path::from_slice(&[v40_9_byte]);
    let v41_2: Space = singleton(&(v40_9_head));
    let v41_3: Space = intersect(&(*CONSTANT_21),&(v41_2));
    let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
    drop(v41_3);
    let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
    drop(v41_4);
    let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
      let v42_6: Path = concat_path(&(*p0),&(v40_9_head));
      let v42_7: Space = routine_4(c, &(v42_6), &(v40_9_tail).make_space(), &(*s1));
      compose(&(v41_5),&(v42_7))
    };
    drop(v41_5);
    let v41_9: Space = intersect(&(*CONSTANT_21),&(v41_2));
    drop(v41_2);
    let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
    drop(v41_9);
    let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
      let v43_6: Path = concat_path(&(*p0),&(v40_9_head));
      let mut v43_11 = Space::new();
      let mut v43_11_cursor = (v40_9_tail).read_zipper();
      for v43_11_byte in v43_11_cursor.child_mask().iter() {
        v43_11_cursor.descend_to_byte(v43_11_byte);
        {
        let v43_11_tail = v43_11_cursor.fork_read_zipper();
        let v43_11_head = Path::from_slice(&[v43_11_byte]);
        let v44_2: Space = singleton(&(v43_11_head));
        let v44_3: Space = intersect(&(*CONSTANT_21),&(v44_2));
        let v44_4: Space = if has_head(&(v44_3)) { singleton(&[]) } else { Space::new() };
        drop(v44_3);
        let v44_5: Space = subtract(&(*CONSTANT_0),&(v44_4));
        drop(v44_4);
        let v44_7: Space = if (v44_5).is_empty() { Space::new() } else {
          let v45_6: Space = routine_14(c, &(v43_11_head), &(v43_6), &(v43_11_tail).make_space(), &(*s1));
          compose(&(v44_5),&(v45_6))
        };
        drop(v44_5);
        let v44_8: Space = intersect(&(*CONSTANT_21),&(v44_2));
        drop(v44_2);
        let v44_9: Space = if has_head(&(v44_8)) { singleton(&[]) } else { Space::new() };
        drop(v44_8);
        let v44_11: Space = if (v44_9).is_empty() { Space::new() } else {
          let v46_10: Space = routine_15(c, &(v43_11_head), &(v43_6), &(v43_11_tail).make_space(), &(*s1));
          compose(&(v44_9),&(v46_10))
        };
        drop(v44_9);
        let v44_12: Space = unite(&(v44_7),&(v44_11));
        v43_11.join_into((v44_12).clone());
        }
        v43_11_cursor.ascend(1);
      }
      drop(v43_11_cursor);
      drop(v43_6);
      compose(&(v41_10),&(v43_11))
    };
    drop(v41_10);
    let v41_13: Space = unite(&(v41_8),&(v41_12));
    v40_9.join_into((v41_13).clone());
    }
    v40_9_cursor.ascend(1);
  }
  drop(v40_9_cursor);
  (v40_9).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v47_9 = Space::new();
  let mut v47_9_cursor = (*s0).read_zipper();
  for v47_9_byte in v47_9_cursor.child_mask().iter() {
    v47_9_cursor.descend_to_byte(v47_9_byte);
    {
    let v47_9_tail = v47_9_cursor.fork_read_zipper();
    let v47_9_head = Path::from_slice(&[v47_9_byte]);
    let v48_2: Space = singleton(&(v47_9_head));
    let v48_3: Space = intersect(&(*CONSTANT_21),&(v48_2));
    let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
    drop(v48_3);
    let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
    drop(v48_4);
    let v48_8: Space = if (v48_5).is_empty() { Space::new() } else {
      let v49_6: Path = concat_path(&(*p0),&(v47_9_head));
      let v49_7: Space = routine_5(c, &(v49_6), &(*p1), &(v47_9_tail).make_space());
      compose(&(v48_5),&(v49_7))
    };
    drop(v48_5);
    let v48_9: Space = intersect(&(*CONSTANT_21),&(v48_2));
    drop(v48_2);
    let v48_10: Space = if has_head(&(v48_9)) { singleton(&[]) } else { Space::new() };
    drop(v48_9);
    let v48_14: Space = if (v48_10).is_empty() { Space::new() } else {
      let v50_6: Path = concat_path(&(*p0),&(v47_9_head));
      let v50_11: Path = concat_path(&(*p1),&(v50_6));
      drop(v50_6);
      let v50_12: Space = singleton(&(v50_11));
      drop(v50_11);
      let mut v50_13 = Space::new();
      let mut v50_13_cursor = (v50_12).read_zipper();
      for v50_13_byte in v50_13_cursor.child_mask().iter() {
        v50_13_cursor.descend_to_byte(v50_13_byte);
        {
        let v50_13_tail = v50_13_cursor.fork_read_zipper();
        let v50_13_head = Path::from_slice(&[v50_13_byte]);
        let v51_2: Space = singleton(&(v50_13_head));
        let v51_3: Space = intersect(&(*CONSTANT_21),&(v51_2));
        let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
        drop(v51_3);
        let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
        drop(v51_4);
        let v51_7: Space = if (v51_5).is_empty() { Space::new() } else {
          let v52_6: Space = routine_9(c, &(v50_13_head), &(v50_13_tail).make_space());
          compose(&(v51_5),&(v52_6))
        };
        drop(v51_5);
        let v51_8: Space = intersect(&(*CONSTANT_21),&(v51_2));
        drop(v51_2);
        let v51_9: Space = if has_head(&(v51_8)) { singleton(&[]) } else { Space::new() };
        drop(v51_8);
        let v51_11: Space = if (v51_9).is_empty() { Space::new() } else {
          let v53_10: Space = routine_10(c, &(v50_13_head), &(v50_13_tail).make_space());
          compose(&(v51_9),&(v53_10))
        };
        drop(v51_9);
        let v51_12: Space = unite(&(v51_7),&(v51_11));
        v50_13.join_into((v51_12).clone());
        }
        v50_13_cursor.ascend(1);
      }
      drop(v50_13_cursor);
      drop(v50_12);
      compose(&(v48_10),&(v50_13))
    };
    drop(v48_10);
    let v48_15: Space = unite(&(v48_8),&(v48_14));
    v47_9.join_into((v48_15).clone());
    }
    v47_9_cursor.ascend(1);
  }
  drop(v47_9_cursor);
  (v47_9).clone()
}

#[inline(always)]
fn routine_6(c: &mut Context, p0: &Path) -> Space {
  let v54_1: Space = singleton(&(*p0));
  let mut v54_16 = Space::new();
  let mut v54_16_cursor = (v54_1).read_zipper();
  for v54_16_byte in v54_16_cursor.child_mask().iter() {
    v54_16_cursor.descend_to_byte(v54_16_byte);
    {
    let v54_16_tail = v54_16_cursor.fork_read_zipper();
    let v54_16_head = Path::from_slice(&[v54_16_byte]);
    let v55_2: Space = singleton(&(v54_16_head));
    let v55_3: Space = intersect(&(*CONSTANT_21),&(v55_2));
    let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
    drop(v55_3);
    let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
    drop(v55_4);
    let v55_7: Space = if (v55_5).is_empty() { Space::new() } else {
      let mut v56_6 = Space::new();
      let mut v56_6_cursor = (v54_16_tail).read_zipper();
      for v56_6_byte in v56_6_cursor.child_mask().iter() {
        v56_6_cursor.descend_to_byte(v56_6_byte);
        {
        let v56_6_tail = v56_6_cursor.fork_read_zipper();
        let v56_6_head = Path::from_slice(&[v56_6_byte]);
        let v57_2: Space = singleton(&(v56_6_head));
        let v57_3: Space = intersect(&(*CONSTANT_21),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_0),&(v57_4));
        drop(v57_4);
        let v57_8: Space = if (v57_5).is_empty() { Space::new() } else {
          let v58_6: Path = concat_path(&(v54_16_head),&(v56_6_head));
          let v58_7: Space = routine_9(c, &(v58_6), &(v56_6_tail).make_space());
          compose(&(v57_5),&(v58_7))
        };
        drop(v57_5);
        let v57_9: Space = intersect(&(*CONSTANT_21),&(v57_2));
        drop(v57_2);
        let v57_10: Space = if has_head(&(v57_9)) { singleton(&[]) } else { Space::new() };
        drop(v57_9);
        let v57_12: Space = if (v57_10).is_empty() { Space::new() } else {
          let v59_6: Path = concat_path(&(v54_16_head),&(v56_6_head));
          let mut v59_11 = Space::new();
          let mut v59_11_cursor = (v56_6_tail).read_zipper();
          for v59_11_byte in v59_11_cursor.child_mask().iter() {
            v59_11_cursor.descend_to_byte(v59_11_byte);
            {
            let v59_11_tail = v59_11_cursor.fork_read_zipper();
            let v59_11_head = Path::from_slice(&[v59_11_byte]);
            let v60_2: Space = singleton(&(v59_11_head));
            let v60_3: Space = intersect(&(*CONSTANT_21),&(v60_2));
            let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_7: Space = if (v60_5).is_empty() { Space::new() } else {
              let v61_6: Space = routine_16(c, &(v59_11_head), &(v59_6), &(v59_11_tail).make_space());
              compose(&(v60_5),&(v61_6))
            };
            drop(v60_5);
            let v60_8: Space = intersect(&(*CONSTANT_21),&(v60_2));
            drop(v60_2);
            let v60_9: Space = if has_head(&(v60_8)) { singleton(&[]) } else { Space::new() };
            drop(v60_8);
            let v60_11: Space = if (v60_9).is_empty() { Space::new() } else {
              let v62_10: Space = routine_17(c, &(v59_11_head), &(v59_6), &(v59_11_tail).make_space());
              compose(&(v60_9),&(v62_10))
            };
            drop(v60_9);
            let v60_12: Space = unite(&(v60_7),&(v60_11));
            v59_11.join_into((v60_12).clone());
            }
            v59_11_cursor.ascend(1);
          }
          drop(v59_11_cursor);
          drop(v59_6);
          compose(&(v57_10),&(v59_11))
        };
        drop(v57_10);
        let v57_13: Space = unite(&(v57_8),&(v57_12));
        v56_6.join_into((v57_13).clone());
        }
        v56_6_cursor.ascend(1);
      }
      drop(v56_6_cursor);
      compose(&(v55_5),&(v56_6))
    };
    drop(v55_5);
    let v55_8: Space = intersect(&(*CONSTANT_21),&(v55_2));
    drop(v55_2);
    let v55_9: Space = if has_head(&(v55_8)) { singleton(&[]) } else { Space::new() };
    drop(v55_8);
    let v55_12: Space = if (v55_9).is_empty() { Space::new() } else {
      let v63_10: Space = unwrap(&(*CONSTANT_25),&(v54_16_head));
      let mut v63_11 = Space::new();
      let mut v63_11_cursor = (v54_16_tail).read_zipper();
      for v63_11_byte in v63_11_cursor.child_mask().iter() {
        v63_11_cursor.descend_to_byte(v63_11_byte);
        {
        let v63_11_tail = v63_11_cursor.fork_read_zipper();
        let v63_11_head = Path::from_slice(&[v63_11_byte]);
        let v64_2: Space = singleton(&(v63_11_head));
        let v64_3: Space = intersect(&(*CONSTANT_21),&(v64_2));
        let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
        drop(v64_3);
        let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
        drop(v64_4);
        let v64_7: Space = if (v64_5).is_empty() { Space::new() } else {
          let v65_6: Space = routine_16(c, &(v63_11_head), &(v54_16_head), &(v63_11_tail).make_space());
          compose(&(v64_5),&(v65_6))
        };
        drop(v64_5);
        let v64_8: Space = intersect(&(*CONSTANT_21),&(v64_2));
        drop(v64_2);
        let v64_9: Space = if has_head(&(v64_8)) { singleton(&[]) } else { Space::new() };
        drop(v64_8);
        let v64_10: Space = unwrap(&(*CONSTANT_25),&(v63_11_head));
        let v64_11: Space = compose(&(v63_10),&(v64_10));
        drop(v64_10);
        let v64_12: Path = concat_path(&(v54_16_head),&(v63_11_head));
        let v64_13: Space = singleton(&(v64_12));
        drop(v64_12);
        let v64_14: Space = subtract(&(v64_11),&(v64_13));
        drop(v64_11);
        drop(v64_13);
        let v64_15: Space = compose(&(v64_9),&(v64_14));
        drop(v64_9);
        drop(v64_14);
        let v64_16: Space = unite(&(v64_7),&(v64_15));
        drop(v64_15);
        v63_11.join_into((v64_16).clone());
        }
        v63_11_cursor.ascend(1);
      }
      drop(v63_11_cursor);
      drop(v63_10);
      compose(&(v55_9),&(v63_11))
    };
    drop(v55_9);
    let v55_13: Space = unite(&(v55_7),&(v55_12));
    v54_16.join_into((v55_13).clone());
    }
    v54_16_cursor.ascend(1);
  }
  drop(v54_16_cursor);
  drop(v54_1);
  (v54_16).clone()
}

fn routine_7(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v66_8: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let mut v66_26 = Space::new();
  let mut v66_26_cursor = (*s0).read_zipper();
  for v66_26_byte in v66_26_cursor.child_mask().iter() {
    v66_26_cursor.descend_to_byte(v66_26_byte);
    {
    let v66_26_tail = v66_26_cursor.fork_read_zipper();
    let v66_26_head = Path::from_slice(&[v66_26_byte]);
    let v67_2: Space = singleton(&(v66_26_head));
    let v67_3: Space = intersect(&(*CONSTANT_21),&(v67_2));
    let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
    drop(v67_3);
    let v67_5: Space = subtract(&(*CONSTANT_0),&(v67_4));
    drop(v67_4);
    let v67_8: Space = if (v67_5).is_empty() { Space::new() } else {
      let v68_6: Path = concat_path(&(*p0),&(v66_26_head));
      let v68_7: Space = routine_7(c, &(v68_6), &(*p1), &(v66_26_tail).make_space(), &(*s1));
      compose(&(v67_5),&(v68_7))
    };
    drop(v67_5);
    let v67_9: Space = intersect(&(*CONSTANT_21),&(v67_2));
    drop(v67_2);
    let v67_10: Space = if has_head(&(v67_9)) { singleton(&[]) } else { Space::new() };
    drop(v67_9);
    let v67_24: Space = if (v67_10).is_empty() { Space::new() } else {
      let v69_6: Path = concat_path(&(*p0),&(v66_26_head));
      let v69_11: Path = concat_path(&(*p1),&(v69_6));
      drop(v69_6);
      let v69_12: Space = singleton(&(v69_11));
      drop(v69_11);
      let mut v69_13 = Space::new();
      let mut v69_13_cursor = (v69_12).read_zipper();
      for v69_13_byte in v69_13_cursor.child_mask().iter() {
        v69_13_cursor.descend_to_byte(v69_13_byte);
        {
        let v69_13_tail = v69_13_cursor.fork_read_zipper();
        let v69_13_head = Path::from_slice(&[v69_13_byte]);
        let v70_2: Space = singleton(&(v69_13_head));
        let v70_3: Space = intersect(&(*CONSTANT_21),&(v70_2));
        let v70_4: Space = if has_head(&(v70_3)) { singleton(&[]) } else { Space::new() };
        drop(v70_3);
        let v70_5: Space = subtract(&(*CONSTANT_0),&(v70_4));
        drop(v70_4);
        let v70_7: Space = if (v70_5).is_empty() { Space::new() } else {
          let v71_6: Space = routine_9(c, &(v69_13_head), &(v69_13_tail).make_space());
          compose(&(v70_5),&(v71_6))
        };
        drop(v70_5);
        let v70_8: Space = intersect(&(*CONSTANT_21),&(v70_2));
        drop(v70_2);
        let v70_9: Space = if has_head(&(v70_8)) { singleton(&[]) } else { Space::new() };
        drop(v70_8);
        let v70_11: Space = if (v70_9).is_empty() { Space::new() } else {
          let v72_10: Space = routine_10(c, &(v69_13_head), &(v69_13_tail).make_space());
          compose(&(v70_9),&(v72_10))
        };
        drop(v70_9);
        let v70_12: Space = unite(&(v70_7),&(v70_11));
        v69_13.join_into((v70_12).clone());
        }
        v69_13_cursor.ascend(1);
      }
      drop(v69_13_cursor);
      let v69_14: Space = intersect(&(v66_8),&(v69_13));
      let v69_15: Space = range_const::<{3},{4}>(&(v69_14));
      let mut v69_16 = Space::new();
      let mut v69_16_cursor = (v69_15).read_zipper();
      for v69_16_byte in v69_16_cursor.child_mask().iter() {
        v69_16_cursor.descend_to_byte(v69_16_byte);
        {
        let v69_16_tail = v69_16_cursor.fork_read_zipper();
        let v69_16_head = Path::from_slice(&[v69_16_byte]);
        let v73_2: Space = singleton(&(v69_16_head));
        let v73_3: Space = intersect(&(*CONSTANT_21),&(v73_2));
        let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
        drop(v73_3);
        let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
        drop(v73_4);
        let v73_7: Space = if (v73_5).is_empty() { Space::new() } else {
          let v74_6: Space = routine_11(c, &(v69_16_head), &(v69_16_tail).make_space());
          compose(&(v73_5),&(v74_6))
        };
        drop(v73_5);
        let v73_8: Space = intersect(&(*CONSTANT_21),&(v73_2));
        drop(v73_2);
        let v73_9: Space = if has_head(&(v73_8)) { singleton(&[]) } else { Space::new() };
        drop(v73_8);
        let v73_10: Space = compose(&(v73_9),&(*CONSTANT_24));
        drop(v73_9);
        let v73_11: Space = unite(&(v73_7),&(v73_10));
        drop(v73_10);
        v69_16.join_into((v73_11).clone());
        }
        v69_16_cursor.ascend(1);
      }
      drop(v69_16_cursor);
      let mut v69_17 = Space::new();
      let mut v69_17_cursor = (v69_12).read_zipper();
      for v69_17_byte in v69_17_cursor.child_mask().iter() {
        v69_17_cursor.descend_to_byte(v69_17_byte);
        {
        let v69_17_tail = v69_17_cursor.fork_read_zipper();
        let v69_17_head = Path::from_slice(&[v69_17_byte]);
        let v75_2: Space = singleton(&(v69_17_head));
        let v75_3: Space = intersect(&(*CONSTANT_21),&(v75_2));
        let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
        drop(v75_3);
        let v75_5: Space = subtract(&(*CONSTANT_0),&(v75_4));
        drop(v75_4);
        let v75_7: Space = if (v75_5).is_empty() { Space::new() } else {
          let v76_6: Space = routine_9(c, &(v69_17_head), &(v69_17_tail).make_space());
          compose(&(v75_5),&(v76_6))
        };
        drop(v75_5);
        let v75_8: Space = intersect(&(*CONSTANT_21),&(v75_2));
        drop(v75_2);
        let v75_9: Space = if has_head(&(v75_8)) { singleton(&[]) } else { Space::new() };
        drop(v75_8);
        let v75_11: Space = if (v75_9).is_empty() { Space::new() } else {
          let v77_10: Space = routine_10(c, &(v69_17_head), &(v69_17_tail).make_space());
          compose(&(v75_9),&(v77_10))
        };
        drop(v75_9);
        let v75_12: Space = unite(&(v75_7),&(v75_11));
        v69_17.join_into((v75_12).clone());
        }
        v69_17_cursor.ascend(1);
      }
      drop(v69_17_cursor);
      let v69_18: Space = intersect(&(v66_8),&(v69_17));
      let v69_19: Space = range_const::<{4},{5}>(&(v69_18));
      let mut v69_20 = Space::new();
      let mut v69_20_cursor = (v69_19).read_zipper();
      for v69_20_byte in v69_20_cursor.child_mask().iter() {
        v69_20_cursor.descend_to_byte(v69_20_byte);
        {
        let v69_20_tail = v69_20_cursor.fork_read_zipper();
        let v69_20_head = Path::from_slice(&[v69_20_byte]);
        let v78_2: Space = singleton(&(v69_20_head));
        let v78_3: Space = intersect(&(*CONSTANT_21),&(v78_2));
        let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
        drop(v78_3);
        let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
        drop(v78_4);
        let v78_7: Space = if (v78_5).is_empty() { Space::new() } else {
          let v79_6: Space = routine_12(c, &(v69_20_head), &(v69_20_tail).make_space());
          compose(&(v78_5),&(v79_6))
        };
        drop(v78_5);
        let v78_8: Space = intersect(&(*CONSTANT_21),&(v78_2));
        drop(v78_2);
        let v78_9: Space = if has_head(&(v78_8)) { singleton(&[]) } else { Space::new() };
        drop(v78_8);
        let v78_10: Space = compose(&(v78_9),&(*CONSTANT_24));
        drop(v78_9);
        let v78_11: Space = unite(&(v78_7),&(v78_10));
        drop(v78_10);
        v69_20.join_into((v78_11).clone());
        }
        v69_20_cursor.ascend(1);
      }
      drop(v69_20_cursor);
      let v69_21: Space = subtract(&(v69_16),&(v69_20));
      let v69_22: Space = if (v69_21).is_empty() { Space::new() } else {
        compose(&(v69_21),&(v69_12))
      };
      drop(v69_12);
      let mut v69_23 = Space::new();
      let mut v69_23_cursor = (v69_22).read_zipper();
      for v69_23_byte in v69_23_cursor.child_mask().iter() {
        v69_23_cursor.descend_to_byte(v69_23_byte);
        {
        let v69_23_tail = v69_23_cursor.fork_read_zipper();
        let v69_23_head = Path::from_slice(&[v69_23_byte]);
        let v81_2: Space = singleton(&(v69_23_head));
        let v81_3: Space = intersect(&(*CONSTANT_21),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_7: Space = if (v81_5).is_empty() { Space::new() } else {
          let v82_6: Space = routine_13(c, &(v69_23_head), &(v69_23_tail).make_space());
          compose(&(v81_5),&(v82_6))
        };
        drop(v81_5);
        let v81_8: Space = intersect(&(*CONSTANT_21),&(v81_2));
        drop(v81_2);
        let v81_9: Space = if has_head(&(v81_8)) { singleton(&[]) } else { Space::new() };
        drop(v81_8);
        let v81_10: Space = compose(&(v81_9),&(v69_23_tail));
        drop(v81_9);
        let v81_11: Space = unite(&(v81_7),&(v81_10));
        drop(v81_10);
        v69_23.join_into((v81_11).clone());
        }
        v69_23_cursor.ascend(1);
      }
      drop(v69_23_cursor);
      compose(&(v67_10),&(v69_23))
    };
    drop(v67_10);
    let v67_25: Space = unite(&(v67_8),&(v67_24));
    v66_26.join_into((v67_25).clone());
    }
    v66_26_cursor.ascend(1);
  }
  drop(v66_26_cursor);
  drop(v66_8);
  (v66_26).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v83_5: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v83_6: Path = concat_path(&(*p1),&(*p0));
  let v83_7: Space = singleton(&(v83_6));
  drop(v83_6);
  let mut v83_14 = Space::new();
  let mut v83_14_cursor = (v83_7).read_zipper();
  for v83_14_byte in v83_14_cursor.child_mask().iter() {
    v83_14_cursor.descend_to_byte(v83_14_byte);
    {
    let v83_14_tail = v83_14_cursor.fork_read_zipper();
    let v83_14_head = Path::from_slice(&[v83_14_byte]);
    let v84_2: Space = singleton(&(v83_14_head));
    let v84_3: Space = intersect(&(*CONSTANT_21),&(v84_2));
    let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
    drop(v84_3);
    let v84_5: Space = subtract(&(*CONSTANT_0),&(v84_4));
    drop(v84_4);
    let v84_7: Space = if (v84_5).is_empty() { Space::new() } else {
      let v85_6: Space = routine_9(c, &(v83_14_head), &(v83_14_tail).make_space());
      compose(&(v84_5),&(v85_6))
    };
    drop(v84_5);
    let v84_8: Space = intersect(&(*CONSTANT_21),&(v84_2));
    drop(v84_2);
    let v84_9: Space = if has_head(&(v84_8)) { singleton(&[]) } else { Space::new() };
    drop(v84_8);
    let v84_11: Space = if (v84_9).is_empty() { Space::new() } else {
      let mut v86_10 = Space::new();
      let mut v86_10_cursor = (v83_14_tail).read_zipper();
      for v86_10_byte in v86_10_cursor.child_mask().iter() {
        v86_10_cursor.descend_to_byte(v86_10_byte);
        {
        let v86_10_tail = v86_10_cursor.fork_read_zipper();
        let v86_10_head = Path::from_slice(&[v86_10_byte]);
        let v87_2: Space = singleton(&(v86_10_head));
        let v87_3: Space = intersect(&(*CONSTANT_21),&(v87_2));
        let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
        drop(v87_3);
        let v87_5: Space = subtract(&(*CONSTANT_0),&(v87_4));
        drop(v87_4);
        let v87_7: Space = if (v87_5).is_empty() { Space::new() } else {
          let v88_6: Space = routine_16(c, &(v86_10_head), &(v83_14_head), &(v86_10_tail).make_space());
          compose(&(v87_5),&(v88_6))
        };
        drop(v87_5);
        let v87_8: Space = intersect(&(*CONSTANT_21),&(v87_2));
        drop(v87_2);
        let v87_9: Space = if has_head(&(v87_8)) { singleton(&[]) } else { Space::new() };
        drop(v87_8);
        let v87_11: Space = if (v87_9).is_empty() { Space::new() } else {
          let v89_10: Space = routine_17(c, &(v86_10_head), &(v83_14_head), &(v86_10_tail).make_space());
          compose(&(v87_9),&(v89_10))
        };
        drop(v87_9);
        let v87_12: Space = unite(&(v87_7),&(v87_11));
        v86_10.join_into((v87_12).clone());
        }
        v86_10_cursor.ascend(1);
      }
      drop(v86_10_cursor);
      compose(&(v84_9),&(v86_10))
    };
    drop(v84_9);
    let v84_12: Space = unite(&(v84_7),&(v84_11));
    v83_14.join_into((v84_12).clone());
    }
    v83_14_cursor.ascend(1);
  }
  drop(v83_14_cursor);
  let v83_15: Space = intersect(&(v83_5),&(v83_14));
  let v83_16: Space = range_const::<{3},{4}>(&(v83_15));
  let mut v83_25 = Space::new();
  let mut v83_25_cursor = (v83_16).read_zipper();
  for v83_25_byte in v83_25_cursor.child_mask().iter() {
    v83_25_cursor.descend_to_byte(v83_25_byte);
    {
    let v83_25_tail = v83_25_cursor.fork_read_zipper();
    let v83_25_head = Path::from_slice(&[v83_25_byte]);
    let v90_2: Space = singleton(&(v83_25_head));
    let v90_3: Space = intersect(&(*CONSTANT_21),&(v90_2));
    let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
    drop(v90_3);
    let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
    drop(v90_4);
    let v90_7: Space = if (v90_5).is_empty() { Space::new() } else {
      let mut v91_6 = Space::new();
      let mut v91_6_cursor = (v83_25_tail).read_zipper();
      for v91_6_byte in v91_6_cursor.child_mask().iter() {
        v91_6_cursor.descend_to_byte(v91_6_byte);
        {
        let v91_6_tail = v91_6_cursor.fork_read_zipper();
        let v91_6_head = Path::from_slice(&[v91_6_byte]);
        let v92_2: Space = singleton(&(v91_6_head));
        let v92_3: Space = intersect(&(*CONSTANT_21),&(v92_2));
        let v92_4: Space = if has_head(&(v92_3)) { singleton(&[]) } else { Space::new() };
        drop(v92_3);
        let v92_5: Space = subtract(&(*CONSTANT_0),&(v92_4));
        drop(v92_4);
        let v92_8: Space = if (v92_5).is_empty() { Space::new() } else {
          let v93_6: Path = concat_path(&(v83_25_head),&(v91_6_head));
          let v93_7: Space = routine_11(c, &(v93_6), &(v91_6_tail).make_space());
          drop(v93_6);
          compose(&(v92_5),&(v93_7))
        };
        drop(v92_5);
        let v92_9: Space = intersect(&(*CONSTANT_21),&(v92_2));
        drop(v92_2);
        let v92_10: Space = if has_head(&(v92_9)) { singleton(&[]) } else { Space::new() };
        drop(v92_9);
        let v92_11: Space = compose(&(v92_10),&(*CONSTANT_24));
        drop(v92_10);
        let v92_12: Space = unite(&(v92_8),&(v92_11));
        drop(v92_11);
        v91_6.join_into((v92_12).clone());
        }
        v91_6_cursor.ascend(1);
      }
      drop(v91_6_cursor);
      compose(&(v90_5),&(v91_6))
    };
    drop(v90_5);
    let v90_8: Space = intersect(&(*CONSTANT_21),&(v90_2));
    drop(v90_2);
    let v90_9: Space = if has_head(&(v90_8)) { singleton(&[]) } else { Space::new() };
    drop(v90_8);
    let v90_10: Space = compose(&(v90_9),&(*CONSTANT_24));
    drop(v90_9);
    let v90_11: Space = unite(&(v90_7),&(v90_10));
    drop(v90_10);
    v83_25.join_into((v90_11).clone());
    }
    v83_25_cursor.ascend(1);
  }
  drop(v83_25_cursor);
  let mut v83_32 = Space::new();
  let mut v83_32_cursor = (v83_7).read_zipper();
  for v83_32_byte in v83_32_cursor.child_mask().iter() {
    v83_32_cursor.descend_to_byte(v83_32_byte);
    {
    let v83_32_tail = v83_32_cursor.fork_read_zipper();
    let v83_32_head = Path::from_slice(&[v83_32_byte]);
    let v94_2: Space = singleton(&(v83_32_head));
    let v94_3: Space = intersect(&(*CONSTANT_21),&(v94_2));
    let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
    drop(v94_3);
    let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
    drop(v94_4);
    let v94_7: Space = if (v94_5).is_empty() { Space::new() } else {
      let v95_6: Space = routine_9(c, &(v83_32_head), &(v83_32_tail).make_space());
      compose(&(v94_5),&(v95_6))
    };
    drop(v94_5);
    let v94_8: Space = intersect(&(*CONSTANT_21),&(v94_2));
    drop(v94_2);
    let v94_9: Space = if has_head(&(v94_8)) { singleton(&[]) } else { Space::new() };
    drop(v94_8);
    let v94_11: Space = if (v94_9).is_empty() { Space::new() } else {
      let mut v96_10 = Space::new();
      let mut v96_10_cursor = (v83_32_tail).read_zipper();
      for v96_10_byte in v96_10_cursor.child_mask().iter() {
        v96_10_cursor.descend_to_byte(v96_10_byte);
        {
        let v96_10_tail = v96_10_cursor.fork_read_zipper();
        let v96_10_head = Path::from_slice(&[v96_10_byte]);
        let v97_2: Space = singleton(&(v96_10_head));
        let v97_3: Space = intersect(&(*CONSTANT_21),&(v97_2));
        let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
        drop(v97_3);
        let v97_5: Space = subtract(&(*CONSTANT_0),&(v97_4));
        drop(v97_4);
        let v97_7: Space = if (v97_5).is_empty() { Space::new() } else {
          let v98_6: Space = routine_16(c, &(v96_10_head), &(v83_32_head), &(v96_10_tail).make_space());
          compose(&(v97_5),&(v98_6))
        };
        drop(v97_5);
        let v97_8: Space = intersect(&(*CONSTANT_21),&(v97_2));
        drop(v97_2);
        let v97_9: Space = if has_head(&(v97_8)) { singleton(&[]) } else { Space::new() };
        drop(v97_8);
        let v97_11: Space = if (v97_9).is_empty() { Space::new() } else {
          let v99_10: Space = routine_17(c, &(v96_10_head), &(v83_32_head), &(v96_10_tail).make_space());
          compose(&(v97_9),&(v99_10))
        };
        drop(v97_9);
        let v97_12: Space = unite(&(v97_7),&(v97_11));
        v96_10.join_into((v97_12).clone());
        }
        v96_10_cursor.ascend(1);
      }
      drop(v96_10_cursor);
      compose(&(v94_9),&(v96_10))
    };
    drop(v94_9);
    let v94_12: Space = unite(&(v94_7),&(v94_11));
    v83_32.join_into((v94_12).clone());
    }
    v83_32_cursor.ascend(1);
  }
  drop(v83_32_cursor);
  let v83_33: Space = intersect(&(v83_5),&(v83_32));
  drop(v83_5);
  let v83_34: Space = range_const::<{4},{5}>(&(v83_33));
  let mut v83_43 = Space::new();
  let mut v83_43_cursor = (v83_34).read_zipper();
  for v83_43_byte in v83_43_cursor.child_mask().iter() {
    v83_43_cursor.descend_to_byte(v83_43_byte);
    {
    let v83_43_tail = v83_43_cursor.fork_read_zipper();
    let v83_43_head = Path::from_slice(&[v83_43_byte]);
    let v100_2: Space = singleton(&(v83_43_head));
    let v100_3: Space = intersect(&(*CONSTANT_21),&(v100_2));
    let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
    drop(v100_3);
    let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
    drop(v100_4);
    let v100_7: Space = if (v100_5).is_empty() { Space::new() } else {
      let mut v101_6 = Space::new();
      let mut v101_6_cursor = (v83_43_tail).read_zipper();
      for v101_6_byte in v101_6_cursor.child_mask().iter() {
        v101_6_cursor.descend_to_byte(v101_6_byte);
        {
        let v101_6_tail = v101_6_cursor.fork_read_zipper();
        let v101_6_head = Path::from_slice(&[v101_6_byte]);
        let v102_2: Space = singleton(&(v101_6_head));
        let v102_3: Space = intersect(&(*CONSTANT_21),&(v102_2));
        let v102_4: Space = if has_head(&(v102_3)) { singleton(&[]) } else { Space::new() };
        drop(v102_3);
        let v102_5: Space = subtract(&(*CONSTANT_0),&(v102_4));
        drop(v102_4);
        let v102_8: Space = if (v102_5).is_empty() { Space::new() } else {
          let v103_6: Path = concat_path(&(v83_43_head),&(v101_6_head));
          let v103_7: Space = routine_12(c, &(v103_6), &(v101_6_tail).make_space());
          drop(v103_6);
          compose(&(v102_5),&(v103_7))
        };
        drop(v102_5);
        let v102_9: Space = intersect(&(*CONSTANT_21),&(v102_2));
        drop(v102_2);
        let v102_10: Space = if has_head(&(v102_9)) { singleton(&[]) } else { Space::new() };
        drop(v102_9);
        let v102_11: Space = compose(&(v102_10),&(*CONSTANT_24));
        drop(v102_10);
        let v102_12: Space = unite(&(v102_8),&(v102_11));
        drop(v102_11);
        v101_6.join_into((v102_12).clone());
        }
        v101_6_cursor.ascend(1);
      }
      drop(v101_6_cursor);
      compose(&(v100_5),&(v101_6))
    };
    drop(v100_5);
    let v100_8: Space = intersect(&(*CONSTANT_21),&(v100_2));
    drop(v100_2);
    let v100_9: Space = if has_head(&(v100_8)) { singleton(&[]) } else { Space::new() };
    drop(v100_8);
    let v100_10: Space = compose(&(v100_9),&(*CONSTANT_24));
    drop(v100_9);
    let v100_11: Space = unite(&(v100_7),&(v100_10));
    drop(v100_10);
    v83_43.join_into((v100_11).clone());
    }
    v83_43_cursor.ascend(1);
  }
  drop(v83_43_cursor);
  let v83_44: Space = subtract(&(v83_25),&(v83_43));
  let v83_45: Space = if (v83_44).is_empty() { Space::new() } else {
    compose(&(v83_44),&(v83_7))
  };
  drop(v83_7);
  let mut v83_52 = Space::new();
  let mut v83_52_cursor = (v83_45).read_zipper();
  for v83_52_byte in v83_52_cursor.child_mask().iter() {
    v83_52_cursor.descend_to_byte(v83_52_byte);
    {
    let v83_52_tail = v83_52_cursor.fork_read_zipper();
    let v83_52_head = Path::from_slice(&[v83_52_byte]);
    let v105_2: Space = singleton(&(v83_52_head));
    let v105_3: Space = intersect(&(*CONSTANT_21),&(v105_2));
    let v105_4: Space = if has_head(&(v105_3)) { singleton(&[]) } else { Space::new() };
    drop(v105_3);
    let v105_5: Space = subtract(&(*CONSTANT_0),&(v105_4));
    drop(v105_4);
    let v105_7: Space = if (v105_5).is_empty() { Space::new() } else {
      let mut v106_6 = Space::new();
      let mut v106_6_cursor = (v83_52_tail).read_zipper();
      for v106_6_byte in v106_6_cursor.child_mask().iter() {
        v106_6_cursor.descend_to_byte(v106_6_byte);
        {
        let v106_6_tail = v106_6_cursor.fork_read_zipper();
        let v106_6_head = Path::from_slice(&[v106_6_byte]);
        let v107_2: Space = singleton(&(v106_6_head));
        let v107_3: Space = intersect(&(*CONSTANT_21),&(v107_2));
        let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
        drop(v107_3);
        let v107_5: Space = subtract(&(*CONSTANT_0),&(v107_4));
        drop(v107_4);
        let v107_8: Space = if (v107_5).is_empty() { Space::new() } else {
          let v108_6: Path = concat_path(&(v83_52_head),&(v106_6_head));
          let v108_7: Space = routine_13(c, &(v108_6), &(v106_6_tail).make_space());
          drop(v108_6);
          compose(&(v107_5),&(v108_7))
        };
        drop(v107_5);
        let v107_9: Space = intersect(&(*CONSTANT_21),&(v107_2));
        drop(v107_2);
        let v107_10: Space = if has_head(&(v107_9)) { singleton(&[]) } else { Space::new() };
        drop(v107_9);
        let v107_11: Space = compose(&(v107_10),&(v106_6_tail));
        drop(v107_10);
        let v107_12: Space = unite(&(v107_8),&(v107_11));
        drop(v107_11);
        v106_6.join_into((v107_12).clone());
        }
        v106_6_cursor.ascend(1);
      }
      drop(v106_6_cursor);
      compose(&(v105_5),&(v106_6))
    };
    drop(v105_5);
    let v105_8: Space = intersect(&(*CONSTANT_21),&(v105_2));
    drop(v105_2);
    let v105_9: Space = if has_head(&(v105_8)) { singleton(&[]) } else { Space::new() };
    drop(v105_8);
    let v105_10: Space = compose(&(v105_9),&(v83_52_tail));
    drop(v105_9);
    let v105_11: Space = unite(&(v105_7),&(v105_10));
    drop(v105_10);
    v83_52.join_into((v105_11).clone());
    }
    v83_52_cursor.ascend(1);
  }
  drop(v83_52_cursor);
  (v83_52).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v109_10: Space = unwrap(&(*CONSTANT_25),&(*p0));
  let mut v109_11 = Space::new();
  let mut v109_11_cursor = (*s0).read_zipper();
  for v109_11_byte in v109_11_cursor.child_mask().iter() {
    v109_11_cursor.descend_to_byte(v109_11_byte);
    {
    let v109_11_tail = v109_11_cursor.fork_read_zipper();
    let v109_11_head = Path::from_slice(&[v109_11_byte]);
    let v110_2: Space = singleton(&(v109_11_head));
    let v110_3: Space = intersect(&(*CONSTANT_21),&(v110_2));
    let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
    drop(v110_3);
    let v110_5: Space = subtract(&(*CONSTANT_0),&(v110_4));
    drop(v110_4);
    let v110_8: Space = if (v110_5).is_empty() { Space::new() } else {
      let v111_6: Path = concat_path(&(*p0),&(v109_11_head));
      let v111_7: Space = routine_9(c, &(v111_6), &(v109_11_tail).make_space());
      compose(&(v110_5),&(v111_7))
    };
    drop(v110_5);
    let v110_9: Space = intersect(&(*CONSTANT_21),&(v110_2));
    drop(v110_2);
    let v110_10: Space = if has_head(&(v110_9)) { singleton(&[]) } else { Space::new() };
    drop(v110_9);
    let v110_13: Space = if (v110_10).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&(v109_11_head));
      let v112_11: Space = unwrap(&(v109_10),&(v109_11_head));
      let mut v112_12 = Space::new();
      let mut v112_12_cursor = (v109_11_tail).read_zipper();
      for v112_12_byte in v112_12_cursor.child_mask().iter() {
        v112_12_cursor.descend_to_byte(v112_12_byte);
        {
        let v112_12_tail = v112_12_cursor.fork_read_zipper();
        let v112_12_head = Path::from_slice(&[v112_12_byte]);
        let v113_2: Space = singleton(&(v112_12_head));
        let v113_3: Space = intersect(&(*CONSTANT_21),&(v113_2));
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = subtract(&(*CONSTANT_0),&(v113_4));
        drop(v113_4);
        let v113_7: Space = if (v113_5).is_empty() { Space::new() } else {
          let v114_6: Space = routine_16(c, &(v112_12_head), &(v112_6), &(v112_12_tail).make_space());
          compose(&(v113_5),&(v114_6))
        };
        drop(v113_5);
        let v113_8: Space = intersect(&(*CONSTANT_21),&(v113_2));
        drop(v113_2);
        let v113_9: Space = if has_head(&(v113_8)) { singleton(&[]) } else { Space::new() };
        drop(v113_8);
        let v113_15: Space = if (v113_9).is_empty() { Space::new() } else {
          let v115_10: Space = unwrap(&(*CONSTANT_25),&(v112_12_head));
          let v115_11: Space = compose(&(v112_11),&(v115_10));
          drop(v115_10);
          let v115_12: Path = concat_path(&(v112_6),&(v112_12_head));
          let v115_13: Space = singleton(&(v115_12));
          drop(v115_12);
          let v115_14: Space = subtract(&(v115_11),&(v115_13));
          drop(v115_11);
          drop(v115_13);
          compose(&(v113_9),&(v115_14))
        };
        drop(v113_9);
        let v113_16: Space = unite(&(v113_7),&(v113_15));
        drop(v113_15);
        v112_12.join_into((v113_16).clone());
        }
        v112_12_cursor.ascend(1);
      }
      drop(v112_12_cursor);
      drop(v112_6);
      drop(v112_11);
      compose(&(v110_10),&(v112_12))
    };
    drop(v110_10);
    let v110_14: Space = unite(&(v110_8),&(v110_13));
    v109_11.join_into((v110_14).clone());
    }
    v109_11_cursor.ascend(1);
  }
  drop(v109_11_cursor);
  drop(v109_10);
  (v109_11).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v116_6: Space = unwrap(&(*CONSTANT_25),&(*p0));
  let v116_13: Space = unwrap(&(*CONSTANT_25),&(*p0));
  let mut v116_14 = Space::new();
  let mut v116_14_cursor = (*s0).read_zipper();
  for v116_14_byte in v116_14_cursor.child_mask().iter() {
    v116_14_cursor.descend_to_byte(v116_14_byte);
    {
    let v116_14_tail = v116_14_cursor.fork_read_zipper();
    let v116_14_head = Path::from_slice(&[v116_14_byte]);
    let v117_2: Space = singleton(&(v116_14_head));
    let v117_3: Space = intersect(&(*CONSTANT_21),&(v117_2));
    let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
    drop(v117_3);
    let v117_5: Space = subtract(&(*CONSTANT_0),&(v117_4));
    drop(v117_4);
    let v117_8: Space = if (v117_5).is_empty() { Space::new() } else {
      let v118_6: Space = unwrap(&(*CONSTANT_25),&(v116_14_head));
      let mut v118_7 = Space::new();
      let mut v118_7_cursor = (v116_14_tail).read_zipper();
      for v118_7_byte in v118_7_cursor.child_mask().iter() {
        v118_7_cursor.descend_to_byte(v118_7_byte);
        {
        let v118_7_tail = v118_7_cursor.fork_read_zipper();
        let v118_7_head = Path::from_slice(&[v118_7_byte]);
        let v119_2: Space = singleton(&(v118_7_head));
        let v119_3: Space = intersect(&(*CONSTANT_21),&(v119_2));
        let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
        drop(v119_3);
        let v119_5: Space = subtract(&(*CONSTANT_0),&(v119_4));
        drop(v119_4);
        let v119_8: Space = if (v119_5).is_empty() { Space::new() } else {
          let v120_6: Path = concat_path(&(v116_14_head),&(v118_7_head));
          let v120_7: Space = routine_16(c, &(v120_6), &(*p0), &(v118_7_tail).make_space());
          compose(&(v119_5),&(v120_7))
        };
        drop(v119_5);
        let v119_9: Space = intersect(&(*CONSTANT_21),&(v119_2));
        drop(v119_2);
        let v119_10: Space = if has_head(&(v119_9)) { singleton(&[]) } else { Space::new() };
        drop(v119_9);
        let v119_16: Space = if (v119_10).is_empty() { Space::new() } else {
          let v121_6: Path = concat_path(&(v116_14_head),&(v118_7_head));
          let v121_11: Space = unwrap(&(v118_6),&(v118_7_head));
          let v121_12: Space = compose(&(v116_13),&(v121_11));
          drop(v121_11);
          let v121_13: Path = concat_path(&(*p0),&(v121_6));
          drop(v121_6);
          let v121_14: Space = singleton(&(v121_13));
          drop(v121_13);
          let v121_15: Space = subtract(&(v121_12),&(v121_14));
          drop(v121_12);
          drop(v121_14);
          compose(&(v119_10),&(v121_15))
        };
        drop(v119_10);
        let v119_17: Space = unite(&(v119_8),&(v119_16));
        drop(v119_16);
        v118_7.join_into((v119_17).clone());
        }
        v118_7_cursor.ascend(1);
      }
      drop(v118_7_cursor);
      drop(v118_6);
      compose(&(v117_5),&(v118_7))
    };
    drop(v117_5);
    let v117_9: Space = intersect(&(*CONSTANT_21),&(v117_2));
    drop(v117_2);
    let v117_10: Space = if has_head(&(v117_9)) { singleton(&[]) } else { Space::new() };
    drop(v117_9);
    let v117_16: Space = if (v117_10).is_empty() { Space::new() } else {
      let v122_11: Space = unwrap(&(*CONSTANT_25),&(v116_14_head));
      let v122_12: Space = compose(&(v116_6),&(v122_11));
      drop(v122_11);
      let v122_13: Path = concat_path(&(*p0),&(v116_14_head));
      let v122_14: Space = singleton(&(v122_13));
      drop(v122_13);
      let v122_15: Space = subtract(&(v122_12),&(v122_14));
      drop(v122_12);
      drop(v122_14);
      compose(&(v117_10),&(v122_15))
    };
    drop(v117_10);
    let v117_17: Space = unite(&(v117_8),&(v117_16));
    drop(v117_16);
    v116_14.join_into((v117_17).clone());
    }
    v116_14_cursor.ascend(1);
  }
  drop(v116_14_cursor);
  drop(v116_6);
  drop(v116_13);
  (v116_14).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v123_6 = Space::new();
  let mut v123_6_cursor = (*s0).read_zipper();
  for v123_6_byte in v123_6_cursor.child_mask().iter() {
    v123_6_cursor.descend_to_byte(v123_6_byte);
    {
    let v123_6_tail = v123_6_cursor.fork_read_zipper();
    let v123_6_head = Path::from_slice(&[v123_6_byte]);
    let v124_2: Space = singleton(&(v123_6_head));
    let v124_3: Space = intersect(&(*CONSTANT_21),&(v124_2));
    let v124_4: Space = if has_head(&(v124_3)) { singleton(&[]) } else { Space::new() };
    drop(v124_3);
    let v124_5: Space = subtract(&(*CONSTANT_0),&(v124_4));
    drop(v124_4);
    let v124_8: Space = if (v124_5).is_empty() { Space::new() } else {
      let v125_6: Path = concat_path(&(*p0),&(v123_6_head));
      let v125_7: Space = routine_11(c, &(v125_6), &(v123_6_tail).make_space());
      drop(v125_6);
      compose(&(v124_5),&(v125_7))
    };
    drop(v124_5);
    let v124_9: Space = intersect(&(*CONSTANT_21),&(v124_2));
    drop(v124_2);
    let v124_10: Space = if has_head(&(v124_9)) { singleton(&[]) } else { Space::new() };
    drop(v124_9);
    let v124_11: Space = compose(&(v124_10),&(*CONSTANT_24));
    drop(v124_10);
    let v124_12: Space = unite(&(v124_8),&(v124_11));
    drop(v124_11);
    v123_6.join_into((v124_12).clone());
    }
    v123_6_cursor.ascend(1);
  }
  drop(v123_6_cursor);
  (v123_6).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v126_6 = Space::new();
  let mut v126_6_cursor = (*s0).read_zipper();
  for v126_6_byte in v126_6_cursor.child_mask().iter() {
    v126_6_cursor.descend_to_byte(v126_6_byte);
    {
    let v126_6_tail = v126_6_cursor.fork_read_zipper();
    let v126_6_head = Path::from_slice(&[v126_6_byte]);
    let v127_2: Space = singleton(&(v126_6_head));
    let v127_3: Space = intersect(&(*CONSTANT_21),&(v127_2));
    let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
    drop(v127_3);
    let v127_5: Space = subtract(&(*CONSTANT_0),&(v127_4));
    drop(v127_4);
    let v127_8: Space = if (v127_5).is_empty() { Space::new() } else {
      let v128_6: Path = concat_path(&(*p0),&(v126_6_head));
      let v128_7: Space = routine_12(c, &(v128_6), &(v126_6_tail).make_space());
      drop(v128_6);
      compose(&(v127_5),&(v128_7))
    };
    drop(v127_5);
    let v127_9: Space = intersect(&(*CONSTANT_21),&(v127_2));
    drop(v127_2);
    let v127_10: Space = if has_head(&(v127_9)) { singleton(&[]) } else { Space::new() };
    drop(v127_9);
    let v127_11: Space = compose(&(v127_10),&(*CONSTANT_24));
    drop(v127_10);
    let v127_12: Space = unite(&(v127_8),&(v127_11));
    drop(v127_11);
    v126_6.join_into((v127_12).clone());
    }
    v126_6_cursor.ascend(1);
  }
  drop(v126_6_cursor);
  (v126_6).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v129_5 = Space::new();
  let mut v129_5_cursor = (*s0).read_zipper();
  for v129_5_byte in v129_5_cursor.child_mask().iter() {
    v129_5_cursor.descend_to_byte(v129_5_byte);
    {
    let v129_5_tail = v129_5_cursor.fork_read_zipper();
    let v129_5_head = Path::from_slice(&[v129_5_byte]);
    let v130_2: Space = singleton(&(v129_5_head));
    let v130_3: Space = intersect(&(*CONSTANT_21),&(v130_2));
    let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
    drop(v130_3);
    let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
    drop(v130_4);
    let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
      let v131_6: Path = concat_path(&(*p0),&(v129_5_head));
      let v131_7: Space = routine_13(c, &(v131_6), &(v129_5_tail).make_space());
      drop(v131_6);
      compose(&(v130_5),&(v131_7))
    };
    drop(v130_5);
    let v130_9: Space = intersect(&(*CONSTANT_21),&(v130_2));
    drop(v130_2);
    let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
    drop(v130_9);
    let v130_11: Space = compose(&(v130_10),&(v129_5_tail));
    drop(v130_10);
    let v130_12: Space = unite(&(v130_8),&(v130_11));
    drop(v130_11);
    v129_5.join_into((v130_12).clone());
    }
    v129_5_cursor.ascend(1);
  }
  drop(v129_5_cursor);
  (v129_5).clone()
}

fn routine_14(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v132_8: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let mut v132_26 = Space::new();
  let mut v132_26_cursor = (*s0).read_zipper();
  for v132_26_byte in v132_26_cursor.child_mask().iter() {
    v132_26_cursor.descend_to_byte(v132_26_byte);
    {
    let v132_26_tail = v132_26_cursor.fork_read_zipper();
    let v132_26_head = Path::from_slice(&[v132_26_byte]);
    let v133_2: Space = singleton(&(v132_26_head));
    let v133_3: Space = intersect(&(*CONSTANT_21),&(v133_2));
    let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
    drop(v133_3);
    let v133_5: Space = subtract(&(*CONSTANT_0),&(v133_4));
    drop(v133_4);
    let v133_8: Space = if (v133_5).is_empty() { Space::new() } else {
      let v134_6: Path = concat_path(&(*p0),&(v132_26_head));
      let v134_7: Space = routine_14(c, &(v134_6), &(*p1), &(v132_26_tail).make_space(), &(*s1));
      compose(&(v133_5),&(v134_7))
    };
    drop(v133_5);
    let v133_9: Space = intersect(&(*CONSTANT_21),&(v133_2));
    drop(v133_2);
    let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
    drop(v133_9);
    let v133_24: Space = if (v133_10).is_empty() { Space::new() } else {
      let v135_6: Path = concat_path(&(*p0),&(v132_26_head));
      let v135_11: Path = concat_path(&(*p1),&(v135_6));
      drop(v135_6);
      let v135_12: Space = singleton(&(v135_11));
      drop(v135_11);
      let mut v135_13 = Space::new();
      let mut v135_13_cursor = (v135_12).read_zipper();
      for v135_13_byte in v135_13_cursor.child_mask().iter() {
        v135_13_cursor.descend_to_byte(v135_13_byte);
        {
        let v135_13_tail = v135_13_cursor.fork_read_zipper();
        let v135_13_head = Path::from_slice(&[v135_13_byte]);
        let v136_2: Space = singleton(&(v135_13_head));
        let v136_3: Space = intersect(&(*CONSTANT_21),&(v136_2));
        let v136_4: Space = if has_head(&(v136_3)) { singleton(&[]) } else { Space::new() };
        drop(v136_3);
        let v136_5: Space = subtract(&(*CONSTANT_0),&(v136_4));
        drop(v136_4);
        let v136_7: Space = if (v136_5).is_empty() { Space::new() } else {
          let v137_6: Space = routine_9(c, &(v135_13_head), &(v135_13_tail).make_space());
          compose(&(v136_5),&(v137_6))
        };
        drop(v136_5);
        let v136_8: Space = intersect(&(*CONSTANT_21),&(v136_2));
        drop(v136_2);
        let v136_9: Space = if has_head(&(v136_8)) { singleton(&[]) } else { Space::new() };
        drop(v136_8);
        let v136_11: Space = if (v136_9).is_empty() { Space::new() } else {
          let v138_10: Space = routine_10(c, &(v135_13_head), &(v135_13_tail).make_space());
          compose(&(v136_9),&(v138_10))
        };
        drop(v136_9);
        let v136_12: Space = unite(&(v136_7),&(v136_11));
        v135_13.join_into((v136_12).clone());
        }
        v135_13_cursor.ascend(1);
      }
      drop(v135_13_cursor);
      let v135_14: Space = intersect(&(v132_8),&(v135_13));
      let v135_15: Space = range_const::<{2},{3}>(&(v135_14));
      let mut v135_16 = Space::new();
      let mut v135_16_cursor = (v135_15).read_zipper();
      for v135_16_byte in v135_16_cursor.child_mask().iter() {
        v135_16_cursor.descend_to_byte(v135_16_byte);
        {
        let v135_16_tail = v135_16_cursor.fork_read_zipper();
        let v135_16_head = Path::from_slice(&[v135_16_byte]);
        let v139_2: Space = singleton(&(v135_16_head));
        let v139_3: Space = intersect(&(*CONSTANT_21),&(v139_2));
        let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
        drop(v139_3);
        let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
        drop(v139_4);
        let v139_7: Space = if (v139_5).is_empty() { Space::new() } else {
          let v140_6: Space = routine_18(c, &(v135_16_head), &(v135_16_tail).make_space());
          compose(&(v139_5),&(v140_6))
        };
        drop(v139_5);
        let v139_8: Space = intersect(&(*CONSTANT_21),&(v139_2));
        drop(v139_2);
        let v139_9: Space = if has_head(&(v139_8)) { singleton(&[]) } else { Space::new() };
        drop(v139_8);
        let v139_10: Space = compose(&(v139_9),&(*CONSTANT_24));
        drop(v139_9);
        let v139_11: Space = unite(&(v139_7),&(v139_10));
        drop(v139_10);
        v135_16.join_into((v139_11).clone());
        }
        v135_16_cursor.ascend(1);
      }
      drop(v135_16_cursor);
      let mut v135_17 = Space::new();
      let mut v135_17_cursor = (v135_12).read_zipper();
      for v135_17_byte in v135_17_cursor.child_mask().iter() {
        v135_17_cursor.descend_to_byte(v135_17_byte);
        {
        let v135_17_tail = v135_17_cursor.fork_read_zipper();
        let v135_17_head = Path::from_slice(&[v135_17_byte]);
        let v141_2: Space = singleton(&(v135_17_head));
        let v141_3: Space = intersect(&(*CONSTANT_21),&(v141_2));
        let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
        drop(v141_3);
        let v141_5: Space = subtract(&(*CONSTANT_0),&(v141_4));
        drop(v141_4);
        let v141_7: Space = if (v141_5).is_empty() { Space::new() } else {
          let v142_6: Space = routine_9(c, &(v135_17_head), &(v135_17_tail).make_space());
          compose(&(v141_5),&(v142_6))
        };
        drop(v141_5);
        let v141_8: Space = intersect(&(*CONSTANT_21),&(v141_2));
        drop(v141_2);
        let v141_9: Space = if has_head(&(v141_8)) { singleton(&[]) } else { Space::new() };
        drop(v141_8);
        let v141_11: Space = if (v141_9).is_empty() { Space::new() } else {
          let v143_10: Space = routine_10(c, &(v135_17_head), &(v135_17_tail).make_space());
          compose(&(v141_9),&(v143_10))
        };
        drop(v141_9);
        let v141_12: Space = unite(&(v141_7),&(v141_11));
        v135_17.join_into((v141_12).clone());
        }
        v135_17_cursor.ascend(1);
      }
      drop(v135_17_cursor);
      let v135_18: Space = intersect(&(v132_8),&(v135_17));
      let v135_19: Space = range_const::<{3},{4}>(&(v135_18));
      let mut v135_20 = Space::new();
      let mut v135_20_cursor = (v135_19).read_zipper();
      for v135_20_byte in v135_20_cursor.child_mask().iter() {
        v135_20_cursor.descend_to_byte(v135_20_byte);
        {
        let v135_20_tail = v135_20_cursor.fork_read_zipper();
        let v135_20_head = Path::from_slice(&[v135_20_byte]);
        let v144_2: Space = singleton(&(v135_20_head));
        let v144_3: Space = intersect(&(*CONSTANT_21),&(v144_2));
        let v144_4: Space = if has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
        drop(v144_3);
        let v144_5: Space = subtract(&(*CONSTANT_0),&(v144_4));
        drop(v144_4);
        let v144_7: Space = if (v144_5).is_empty() { Space::new() } else {
          let v145_6: Space = routine_19(c, &(v135_20_head), &(v135_20_tail).make_space());
          compose(&(v144_5),&(v145_6))
        };
        drop(v144_5);
        let v144_8: Space = intersect(&(*CONSTANT_21),&(v144_2));
        drop(v144_2);
        let v144_9: Space = if has_head(&(v144_8)) { singleton(&[]) } else { Space::new() };
        drop(v144_8);
        let v144_10: Space = compose(&(v144_9),&(*CONSTANT_24));
        drop(v144_9);
        let v144_11: Space = unite(&(v144_7),&(v144_10));
        drop(v144_10);
        v135_20.join_into((v144_11).clone());
        }
        v135_20_cursor.ascend(1);
      }
      drop(v135_20_cursor);
      let v135_21: Space = subtract(&(v135_16),&(v135_20));
      let v135_22: Space = if (v135_21).is_empty() { Space::new() } else {
        compose(&(v135_21),&(v135_12))
      };
      drop(v135_12);
      let mut v135_23 = Space::new();
      let mut v135_23_cursor = (v135_22).read_zipper();
      for v135_23_byte in v135_23_cursor.child_mask().iter() {
        v135_23_cursor.descend_to_byte(v135_23_byte);
        {
        let v135_23_tail = v135_23_cursor.fork_read_zipper();
        let v135_23_head = Path::from_slice(&[v135_23_byte]);
        let v147_2: Space = singleton(&(v135_23_head));
        let v147_3: Space = intersect(&(*CONSTANT_21),&(v147_2));
        let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
        drop(v147_3);
        let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
        drop(v147_4);
        let v147_7: Space = if (v147_5).is_empty() { Space::new() } else {
          let v148_6: Space = routine_20(c, &(v135_23_head), &(v135_23_tail).make_space());
          compose(&(v147_5),&(v148_6))
        };
        drop(v147_5);
        let v147_8: Space = intersect(&(*CONSTANT_21),&(v147_2));
        drop(v147_2);
        let v147_9: Space = if has_head(&(v147_8)) { singleton(&[]) } else { Space::new() };
        drop(v147_8);
        let v147_10: Space = compose(&(v147_9),&(v135_23_tail));
        drop(v147_9);
        let v147_11: Space = unite(&(v147_7),&(v147_10));
        drop(v147_10);
        v135_23.join_into((v147_11).clone());
        }
        v135_23_cursor.ascend(1);
      }
      drop(v135_23_cursor);
      compose(&(v133_10),&(v135_23))
    };
    drop(v133_10);
    let v133_25: Space = unite(&(v133_8),&(v133_24));
    v132_26.join_into((v133_25).clone());
    }
    v132_26_cursor.ascend(1);
  }
  drop(v132_26_cursor);
  drop(v132_8);
  (v132_26).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v149_5: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v149_6: Path = concat_path(&(*p1),&(*p0));
  let v149_7: Space = singleton(&(v149_6));
  drop(v149_6);
  let mut v149_14 = Space::new();
  let mut v149_14_cursor = (v149_7).read_zipper();
  for v149_14_byte in v149_14_cursor.child_mask().iter() {
    v149_14_cursor.descend_to_byte(v149_14_byte);
    {
    let v149_14_tail = v149_14_cursor.fork_read_zipper();
    let v149_14_head = Path::from_slice(&[v149_14_byte]);
    let v150_2: Space = singleton(&(v149_14_head));
    let v150_3: Space = intersect(&(*CONSTANT_21),&(v150_2));
    let v150_4: Space = if has_head(&(v150_3)) { singleton(&[]) } else { Space::new() };
    drop(v150_3);
    let v150_5: Space = subtract(&(*CONSTANT_0),&(v150_4));
    drop(v150_4);
    let v150_7: Space = if (v150_5).is_empty() { Space::new() } else {
      let v151_6: Space = routine_9(c, &(v149_14_head), &(v149_14_tail).make_space());
      compose(&(v150_5),&(v151_6))
    };
    drop(v150_5);
    let v150_8: Space = intersect(&(*CONSTANT_21),&(v150_2));
    drop(v150_2);
    let v150_9: Space = if has_head(&(v150_8)) { singleton(&[]) } else { Space::new() };
    drop(v150_8);
    let v150_11: Space = if (v150_9).is_empty() { Space::new() } else {
      let mut v152_10 = Space::new();
      let mut v152_10_cursor = (v149_14_tail).read_zipper();
      for v152_10_byte in v152_10_cursor.child_mask().iter() {
        v152_10_cursor.descend_to_byte(v152_10_byte);
        {
        let v152_10_tail = v152_10_cursor.fork_read_zipper();
        let v152_10_head = Path::from_slice(&[v152_10_byte]);
        let v153_2: Space = singleton(&(v152_10_head));
        let v153_3: Space = intersect(&(*CONSTANT_21),&(v153_2));
        let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
        drop(v153_3);
        let v153_5: Space = subtract(&(*CONSTANT_0),&(v153_4));
        drop(v153_4);
        let v153_7: Space = if (v153_5).is_empty() { Space::new() } else {
          let v154_6: Space = routine_16(c, &(v152_10_head), &(v149_14_head), &(v152_10_tail).make_space());
          compose(&(v153_5),&(v154_6))
        };
        drop(v153_5);
        let v153_8: Space = intersect(&(*CONSTANT_21),&(v153_2));
        drop(v153_2);
        let v153_9: Space = if has_head(&(v153_8)) { singleton(&[]) } else { Space::new() };
        drop(v153_8);
        let v153_11: Space = if (v153_9).is_empty() { Space::new() } else {
          let v155_10: Space = routine_17(c, &(v152_10_head), &(v149_14_head), &(v152_10_tail).make_space());
          compose(&(v153_9),&(v155_10))
        };
        drop(v153_9);
        let v153_12: Space = unite(&(v153_7),&(v153_11));
        v152_10.join_into((v153_12).clone());
        }
        v152_10_cursor.ascend(1);
      }
      drop(v152_10_cursor);
      compose(&(v150_9),&(v152_10))
    };
    drop(v150_9);
    let v150_12: Space = unite(&(v150_7),&(v150_11));
    v149_14.join_into((v150_12).clone());
    }
    v149_14_cursor.ascend(1);
  }
  drop(v149_14_cursor);
  let v149_15: Space = intersect(&(v149_5),&(v149_14));
  let v149_16: Space = range_const::<{2},{3}>(&(v149_15));
  let mut v149_25 = Space::new();
  let mut v149_25_cursor = (v149_16).read_zipper();
  for v149_25_byte in v149_25_cursor.child_mask().iter() {
    v149_25_cursor.descend_to_byte(v149_25_byte);
    {
    let v149_25_tail = v149_25_cursor.fork_read_zipper();
    let v149_25_head = Path::from_slice(&[v149_25_byte]);
    let v156_2: Space = singleton(&(v149_25_head));
    let v156_3: Space = intersect(&(*CONSTANT_21),&(v156_2));
    let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
    drop(v156_3);
    let v156_5: Space = subtract(&(*CONSTANT_0),&(v156_4));
    drop(v156_4);
    let v156_7: Space = if (v156_5).is_empty() { Space::new() } else {
      let mut v157_6 = Space::new();
      let mut v157_6_cursor = (v149_25_tail).read_zipper();
      for v157_6_byte in v157_6_cursor.child_mask().iter() {
        v157_6_cursor.descend_to_byte(v157_6_byte);
        {
        let v157_6_tail = v157_6_cursor.fork_read_zipper();
        let v157_6_head = Path::from_slice(&[v157_6_byte]);
        let v158_2: Space = singleton(&(v157_6_head));
        let v158_3: Space = intersect(&(*CONSTANT_21),&(v158_2));
        let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
        drop(v158_3);
        let v158_5: Space = subtract(&(*CONSTANT_0),&(v158_4));
        drop(v158_4);
        let v158_8: Space = if (v158_5).is_empty() { Space::new() } else {
          let v159_6: Path = concat_path(&(v149_25_head),&(v157_6_head));
          let v159_7: Space = routine_18(c, &(v159_6), &(v157_6_tail).make_space());
          drop(v159_6);
          compose(&(v158_5),&(v159_7))
        };
        drop(v158_5);
        let v158_9: Space = intersect(&(*CONSTANT_21),&(v158_2));
        drop(v158_2);
        let v158_10: Space = if has_head(&(v158_9)) { singleton(&[]) } else { Space::new() };
        drop(v158_9);
        let v158_11: Space = compose(&(v158_10),&(*CONSTANT_24));
        drop(v158_10);
        let v158_12: Space = unite(&(v158_8),&(v158_11));
        drop(v158_11);
        v157_6.join_into((v158_12).clone());
        }
        v157_6_cursor.ascend(1);
      }
      drop(v157_6_cursor);
      compose(&(v156_5),&(v157_6))
    };
    drop(v156_5);
    let v156_8: Space = intersect(&(*CONSTANT_21),&(v156_2));
    drop(v156_2);
    let v156_9: Space = if has_head(&(v156_8)) { singleton(&[]) } else { Space::new() };
    drop(v156_8);
    let v156_10: Space = compose(&(v156_9),&(*CONSTANT_24));
    drop(v156_9);
    let v156_11: Space = unite(&(v156_7),&(v156_10));
    drop(v156_10);
    v149_25.join_into((v156_11).clone());
    }
    v149_25_cursor.ascend(1);
  }
  drop(v149_25_cursor);
  let mut v149_32 = Space::new();
  let mut v149_32_cursor = (v149_7).read_zipper();
  for v149_32_byte in v149_32_cursor.child_mask().iter() {
    v149_32_cursor.descend_to_byte(v149_32_byte);
    {
    let v149_32_tail = v149_32_cursor.fork_read_zipper();
    let v149_32_head = Path::from_slice(&[v149_32_byte]);
    let v160_2: Space = singleton(&(v149_32_head));
    let v160_3: Space = intersect(&(*CONSTANT_21),&(v160_2));
    let v160_4: Space = if has_head(&(v160_3)) { singleton(&[]) } else { Space::new() };
    drop(v160_3);
    let v160_5: Space = subtract(&(*CONSTANT_0),&(v160_4));
    drop(v160_4);
    let v160_7: Space = if (v160_5).is_empty() { Space::new() } else {
      let v161_6: Space = routine_9(c, &(v149_32_head), &(v149_32_tail).make_space());
      compose(&(v160_5),&(v161_6))
    };
    drop(v160_5);
    let v160_8: Space = intersect(&(*CONSTANT_21),&(v160_2));
    drop(v160_2);
    let v160_9: Space = if has_head(&(v160_8)) { singleton(&[]) } else { Space::new() };
    drop(v160_8);
    let v160_11: Space = if (v160_9).is_empty() { Space::new() } else {
      let mut v162_10 = Space::new();
      let mut v162_10_cursor = (v149_32_tail).read_zipper();
      for v162_10_byte in v162_10_cursor.child_mask().iter() {
        v162_10_cursor.descend_to_byte(v162_10_byte);
        {
        let v162_10_tail = v162_10_cursor.fork_read_zipper();
        let v162_10_head = Path::from_slice(&[v162_10_byte]);
        let v163_2: Space = singleton(&(v162_10_head));
        let v163_3: Space = intersect(&(*CONSTANT_21),&(v163_2));
        let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
        drop(v163_3);
        let v163_5: Space = subtract(&(*CONSTANT_0),&(v163_4));
        drop(v163_4);
        let v163_7: Space = if (v163_5).is_empty() { Space::new() } else {
          let v164_6: Space = routine_16(c, &(v162_10_head), &(v149_32_head), &(v162_10_tail).make_space());
          compose(&(v163_5),&(v164_6))
        };
        drop(v163_5);
        let v163_8: Space = intersect(&(*CONSTANT_21),&(v163_2));
        drop(v163_2);
        let v163_9: Space = if has_head(&(v163_8)) { singleton(&[]) } else { Space::new() };
        drop(v163_8);
        let v163_11: Space = if (v163_9).is_empty() { Space::new() } else {
          let v165_10: Space = routine_17(c, &(v162_10_head), &(v149_32_head), &(v162_10_tail).make_space());
          compose(&(v163_9),&(v165_10))
        };
        drop(v163_9);
        let v163_12: Space = unite(&(v163_7),&(v163_11));
        v162_10.join_into((v163_12).clone());
        }
        v162_10_cursor.ascend(1);
      }
      drop(v162_10_cursor);
      compose(&(v160_9),&(v162_10))
    };
    drop(v160_9);
    let v160_12: Space = unite(&(v160_7),&(v160_11));
    v149_32.join_into((v160_12).clone());
    }
    v149_32_cursor.ascend(1);
  }
  drop(v149_32_cursor);
  let v149_33: Space = intersect(&(v149_5),&(v149_32));
  drop(v149_5);
  let v149_34: Space = range_const::<{3},{4}>(&(v149_33));
  let mut v149_43 = Space::new();
  let mut v149_43_cursor = (v149_34).read_zipper();
  for v149_43_byte in v149_43_cursor.child_mask().iter() {
    v149_43_cursor.descend_to_byte(v149_43_byte);
    {
    let v149_43_tail = v149_43_cursor.fork_read_zipper();
    let v149_43_head = Path::from_slice(&[v149_43_byte]);
    let v166_2: Space = singleton(&(v149_43_head));
    let v166_3: Space = intersect(&(*CONSTANT_21),&(v166_2));
    let v166_4: Space = if has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
    drop(v166_3);
    let v166_5: Space = subtract(&(*CONSTANT_0),&(v166_4));
    drop(v166_4);
    let v166_7: Space = if (v166_5).is_empty() { Space::new() } else {
      let mut v167_6 = Space::new();
      let mut v167_6_cursor = (v149_43_tail).read_zipper();
      for v167_6_byte in v167_6_cursor.child_mask().iter() {
        v167_6_cursor.descend_to_byte(v167_6_byte);
        {
        let v167_6_tail = v167_6_cursor.fork_read_zipper();
        let v167_6_head = Path::from_slice(&[v167_6_byte]);
        let v168_2: Space = singleton(&(v167_6_head));
        let v168_3: Space = intersect(&(*CONSTANT_21),&(v168_2));
        let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
        drop(v168_3);
        let v168_5: Space = subtract(&(*CONSTANT_0),&(v168_4));
        drop(v168_4);
        let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
          let v169_6: Path = concat_path(&(v149_43_head),&(v167_6_head));
          let v169_7: Space = routine_19(c, &(v169_6), &(v167_6_tail).make_space());
          drop(v169_6);
          compose(&(v168_5),&(v169_7))
        };
        drop(v168_5);
        let v168_9: Space = intersect(&(*CONSTANT_21),&(v168_2));
        drop(v168_2);
        let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
        drop(v168_9);
        let v168_11: Space = compose(&(v168_10),&(*CONSTANT_24));
        drop(v168_10);
        let v168_12: Space = unite(&(v168_8),&(v168_11));
        drop(v168_11);
        v167_6.join_into((v168_12).clone());
        }
        v167_6_cursor.ascend(1);
      }
      drop(v167_6_cursor);
      compose(&(v166_5),&(v167_6))
    };
    drop(v166_5);
    let v166_8: Space = intersect(&(*CONSTANT_21),&(v166_2));
    drop(v166_2);
    let v166_9: Space = if has_head(&(v166_8)) { singleton(&[]) } else { Space::new() };
    drop(v166_8);
    let v166_10: Space = compose(&(v166_9),&(*CONSTANT_24));
    drop(v166_9);
    let v166_11: Space = unite(&(v166_7),&(v166_10));
    drop(v166_10);
    v149_43.join_into((v166_11).clone());
    }
    v149_43_cursor.ascend(1);
  }
  drop(v149_43_cursor);
  let v149_44: Space = subtract(&(v149_25),&(v149_43));
  let v149_45: Space = if (v149_44).is_empty() { Space::new() } else {
    compose(&(v149_44),&(v149_7))
  };
  drop(v149_7);
  let mut v149_52 = Space::new();
  let mut v149_52_cursor = (v149_45).read_zipper();
  for v149_52_byte in v149_52_cursor.child_mask().iter() {
    v149_52_cursor.descend_to_byte(v149_52_byte);
    {
    let v149_52_tail = v149_52_cursor.fork_read_zipper();
    let v149_52_head = Path::from_slice(&[v149_52_byte]);
    let v171_2: Space = singleton(&(v149_52_head));
    let v171_3: Space = intersect(&(*CONSTANT_21),&(v171_2));
    let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
    drop(v171_3);
    let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
    drop(v171_4);
    let v171_7: Space = if (v171_5).is_empty() { Space::new() } else {
      let mut v172_6 = Space::new();
      let mut v172_6_cursor = (v149_52_tail).read_zipper();
      for v172_6_byte in v172_6_cursor.child_mask().iter() {
        v172_6_cursor.descend_to_byte(v172_6_byte);
        {
        let v172_6_tail = v172_6_cursor.fork_read_zipper();
        let v172_6_head = Path::from_slice(&[v172_6_byte]);
        let v173_2: Space = singleton(&(v172_6_head));
        let v173_3: Space = intersect(&(*CONSTANT_21),&(v173_2));
        let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
        drop(v173_3);
        let v173_5: Space = subtract(&(*CONSTANT_0),&(v173_4));
        drop(v173_4);
        let v173_8: Space = if (v173_5).is_empty() { Space::new() } else {
          let v174_6: Path = concat_path(&(v149_52_head),&(v172_6_head));
          let v174_7: Space = routine_20(c, &(v174_6), &(v172_6_tail).make_space());
          drop(v174_6);
          compose(&(v173_5),&(v174_7))
        };
        drop(v173_5);
        let v173_9: Space = intersect(&(*CONSTANT_21),&(v173_2));
        drop(v173_2);
        let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
        drop(v173_9);
        let v173_11: Space = compose(&(v173_10),&(v172_6_tail));
        drop(v173_10);
        let v173_12: Space = unite(&(v173_8),&(v173_11));
        drop(v173_11);
        v172_6.join_into((v173_12).clone());
        }
        v172_6_cursor.ascend(1);
      }
      drop(v172_6_cursor);
      compose(&(v171_5),&(v172_6))
    };
    drop(v171_5);
    let v171_8: Space = intersect(&(*CONSTANT_21),&(v171_2));
    drop(v171_2);
    let v171_9: Space = if has_head(&(v171_8)) { singleton(&[]) } else { Space::new() };
    drop(v171_8);
    let v171_10: Space = compose(&(v171_9),&(v149_52_tail));
    drop(v171_9);
    let v171_11: Space = unite(&(v171_7),&(v171_10));
    drop(v171_10);
    v149_52.join_into((v171_11).clone());
    }
    v149_52_cursor.ascend(1);
  }
  drop(v149_52_cursor);
  (v149_52).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v175_7: Space = unwrap(&(*CONSTANT_25),&(*p1));
  let v175_9: Space = unwrap(&(*CONSTANT_25),&(*p0));
  let mut v175_10 = Space::new();
  let mut v175_10_cursor = (*s0).read_zipper();
  for v175_10_byte in v175_10_cursor.child_mask().iter() {
    v175_10_cursor.descend_to_byte(v175_10_byte);
    {
    let v175_10_tail = v175_10_cursor.fork_read_zipper();
    let v175_10_head = Path::from_slice(&[v175_10_byte]);
    let v176_2: Space = singleton(&(v175_10_head));
    let v176_3: Space = intersect(&(*CONSTANT_21),&(v176_2));
    let v176_4: Space = if has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
    drop(v176_3);
    let v176_5: Space = subtract(&(*CONSTANT_0),&(v176_4));
    drop(v176_4);
    let v176_8: Space = if (v176_5).is_empty() { Space::new() } else {
      let v177_6: Path = concat_path(&(*p0),&(v175_10_head));
      let v177_7: Space = routine_16(c, &(v177_6), &(*p1), &(v175_10_tail).make_space());
      compose(&(v176_5),&(v177_7))
    };
    drop(v176_5);
    let v176_9: Space = intersect(&(*CONSTANT_21),&(v176_2));
    drop(v176_2);
    let v176_10: Space = if has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
    drop(v176_9);
    let v176_16: Space = if (v176_10).is_empty() { Space::new() } else {
      let v178_6: Path = concat_path(&(*p0),&(v175_10_head));
      let v178_12: Space = if (v175_7).is_empty() { Space::new() } else {
        let v179_11: Space = unwrap(&(v175_9),&(v175_10_head));
        compose(&(v175_7),&(v179_11))
      };
      let v178_13: Path = concat_path(&(*p1),&(v178_6));
      drop(v178_6);
      let v178_14: Space = singleton(&(v178_13));
      drop(v178_13);
      let v178_15: Space = subtract(&(v178_12),&(v178_14));
      drop(v178_12);
      drop(v178_14);
      compose(&(v176_10),&(v178_15))
    };
    drop(v176_10);
    let v176_17: Space = unite(&(v176_8),&(v176_16));
    drop(v176_16);
    v175_10.join_into((v176_17).clone());
    }
    v175_10_cursor.ascend(1);
  }
  drop(v175_10_cursor);
  drop(v175_7);
  drop(v175_9);
  (v175_10).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v180_4: Space = unwrap(&(*CONSTANT_25),&(*p1));
  let v180_7: Space = if (v180_4).is_empty() { Space::new() } else {
    let v181_6: Space = unwrap(&(*CONSTANT_25),&(*p0));
    compose(&(v180_4),&(v181_6))
  };
  drop(v180_4);
  let v180_8: Path = concat_path(&(*p1),&(*p0));
  let v180_9: Space = singleton(&(v180_8));
  drop(v180_8);
  let v180_10: Space = subtract(&(v180_7),&(v180_9));
  drop(v180_7);
  drop(v180_9);
  (v180_10).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v182_6 = Space::new();
  let mut v182_6_cursor = (*s0).read_zipper();
  for v182_6_byte in v182_6_cursor.child_mask().iter() {
    v182_6_cursor.descend_to_byte(v182_6_byte);
    {
    let v182_6_tail = v182_6_cursor.fork_read_zipper();
    let v182_6_head = Path::from_slice(&[v182_6_byte]);
    let v183_2: Space = singleton(&(v182_6_head));
    let v183_3: Space = intersect(&(*CONSTANT_21),&(v183_2));
    let v183_4: Space = if has_head(&(v183_3)) { singleton(&[]) } else { Space::new() };
    drop(v183_3);
    let v183_5: Space = subtract(&(*CONSTANT_0),&(v183_4));
    drop(v183_4);
    let v183_8: Space = if (v183_5).is_empty() { Space::new() } else {
      let v184_6: Path = concat_path(&(*p0),&(v182_6_head));
      let v184_7: Space = routine_18(c, &(v184_6), &(v182_6_tail).make_space());
      drop(v184_6);
      compose(&(v183_5),&(v184_7))
    };
    drop(v183_5);
    let v183_9: Space = intersect(&(*CONSTANT_21),&(v183_2));
    drop(v183_2);
    let v183_10: Space = if has_head(&(v183_9)) { singleton(&[]) } else { Space::new() };
    drop(v183_9);
    let v183_11: Space = compose(&(v183_10),&(*CONSTANT_24));
    drop(v183_10);
    let v183_12: Space = unite(&(v183_8),&(v183_11));
    drop(v183_11);
    v182_6.join_into((v183_12).clone());
    }
    v182_6_cursor.ascend(1);
  }
  drop(v182_6_cursor);
  (v182_6).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v185_6 = Space::new();
  let mut v185_6_cursor = (*s0).read_zipper();
  for v185_6_byte in v185_6_cursor.child_mask().iter() {
    v185_6_cursor.descend_to_byte(v185_6_byte);
    {
    let v185_6_tail = v185_6_cursor.fork_read_zipper();
    let v185_6_head = Path::from_slice(&[v185_6_byte]);
    let v186_2: Space = singleton(&(v185_6_head));
    let v186_3: Space = intersect(&(*CONSTANT_21),&(v186_2));
    let v186_4: Space = if has_head(&(v186_3)) { singleton(&[]) } else { Space::new() };
    drop(v186_3);
    let v186_5: Space = subtract(&(*CONSTANT_0),&(v186_4));
    drop(v186_4);
    let v186_8: Space = if (v186_5).is_empty() { Space::new() } else {
      let v187_6: Path = concat_path(&(*p0),&(v185_6_head));
      let v187_7: Space = routine_19(c, &(v187_6), &(v185_6_tail).make_space());
      drop(v187_6);
      compose(&(v186_5),&(v187_7))
    };
    drop(v186_5);
    let v186_9: Space = intersect(&(*CONSTANT_21),&(v186_2));
    drop(v186_2);
    let v186_10: Space = if has_head(&(v186_9)) { singleton(&[]) } else { Space::new() };
    drop(v186_9);
    let v186_11: Space = compose(&(v186_10),&(*CONSTANT_24));
    drop(v186_10);
    let v186_12: Space = unite(&(v186_8),&(v186_11));
    drop(v186_11);
    v185_6.join_into((v186_12).clone());
    }
    v185_6_cursor.ascend(1);
  }
  drop(v185_6_cursor);
  (v185_6).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v188_5 = Space::new();
  let mut v188_5_cursor = (*s0).read_zipper();
  for v188_5_byte in v188_5_cursor.child_mask().iter() {
    v188_5_cursor.descend_to_byte(v188_5_byte);
    {
    let v188_5_tail = v188_5_cursor.fork_read_zipper();
    let v188_5_head = Path::from_slice(&[v188_5_byte]);
    let v189_2: Space = singleton(&(v188_5_head));
    let v189_3: Space = intersect(&(*CONSTANT_21),&(v189_2));
    let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
    drop(v189_3);
    let v189_5: Space = subtract(&(*CONSTANT_0),&(v189_4));
    drop(v189_4);
    let v189_8: Space = if (v189_5).is_empty() { Space::new() } else {
      let v190_6: Path = concat_path(&(*p0),&(v188_5_head));
      let v190_7: Space = routine_20(c, &(v190_6), &(v188_5_tail).make_space());
      drop(v190_6);
      compose(&(v189_5),&(v190_7))
    };
    drop(v189_5);
    let v189_9: Space = intersect(&(*CONSTANT_21),&(v189_2));
    drop(v189_2);
    let v189_10: Space = if has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
    drop(v189_9);
    let v189_11: Space = compose(&(v189_10),&(v188_5_tail));
    drop(v189_10);
    let v189_12: Space = unite(&(v189_8),&(v189_11));
    drop(v189_11);
    v188_5.join_into((v189_12).clone());
    }
    v188_5_cursor.ascend(1);
  }
  drop(v188_5_cursor);
  (v188_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
