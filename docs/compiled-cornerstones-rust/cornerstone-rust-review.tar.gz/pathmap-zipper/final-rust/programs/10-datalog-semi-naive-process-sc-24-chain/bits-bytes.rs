#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("94 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 0 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 21 1 1 0 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 19 1 1 0 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 19 1 1 0 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 18 1 1 0 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 22 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 16 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 1 0 0 1 1"));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("184 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 0 1 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 0 1 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 0 0 0 1 1 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 0 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 1 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 1 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 1 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 1 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 0 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 0 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 0 1 0 1 1 1 0 1 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 0 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 0 1 1 1 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 0 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 0 1 1 1 0 1 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 0 1 1 1 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 0 1 0 0 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 0 1 0 0 0 1 1 23 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 21 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 0 1 1 1 0 1 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 0 1 0 1 0 0 1 1 27 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 26 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 0 0 0 1 1 25 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 0 1 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 0 1 0 0 0 1 1 24 0 0 0 0 1 0 1 1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 0 0 1 1 22 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 1 0 1 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 0 1 0 1 1 20 0 0 0 0 1 0 1 1 0 1 1 1 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 21 1 1 0 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 20 1 1 0 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 0 1 0 1 1 16 1 1 0 0 1 1 0 0 0 1 1 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 19 1 1 0 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 20 1 1 0 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 21 1 1 0 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 19 1 1 0 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 18 1 1 0 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 18 1 1 0 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 22 1 1 0 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 21 1 1 0 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 18 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 16 1 1 0 0 1 1 1 0 0 1 1 0 1 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 22 1 1 0 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 20 1 1 0 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 19 1 1 0 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 0 0 0 1 1 15 1 1 0 0 1 1 1 0 1 1 1 0 0 1 1 21 1 1 0 1 1 0 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 21 1 1 0 1 1 0 0 0 0 0 0 1 1 1 0 0 0 0 0 1 1 19 1 1 0 1 1 0 0 0 0 0 1 1 0 1 0 0 0 1 1 19 1 1 0 1 1 0 0 0 0 0 1 1 1 0 0 0 0 1 1 17 1 1 0 1 1 0 0 0 0 1 1 0 1 0 0 1 1 17 1 1 0 1 1 0 0 0 0 1 1 1 0 0 0 1 1 21 1 1 0 1 1 0 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 21 1 1 0 1 1 0 0 0 1 0 0 1 1 1 0 0 1 0 0 1 1 20 1 1 0 1 1 0 0 0 1 0 1 1 0 0 0 0 0 0 1 1 19 1 1 0 1 1 0 0 0 1 0 1 1 1 0 0 1 0 1 1 15 1 1 0 1 1 0 0 0 1 1 0 1 0 1 1 15 1 1 0 1 1 0 0 0 1 1 1 0 0 1 1 21 1 1 0 1 1 0 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 21 1 1 0 1 1 0 0 1 0 0 0 1 1 1 0 1 0 0 0 1 1 19 1 1 0 1 1 0 0 1 0 0 1 1 0 0 0 1 0 1 1 19 1 1 0 1 1 0 0 1 0 0 1 1 1 0 1 0 0 1 1 18 1 1 0 1 1 0 0 1 0 1 1 0 0 0 0 0 1 1 17 1 1 0 1 1 0 0 1 0 1 1 1 0 1 0 1 1 19 1 1 0 1 1 0 1 0 0 0 1 1 0 0 1 0 0 1 1 19 1 1 0 1 1 0 1 0 0 0 1 1 1 0 1 0 0 1 1 17 1 1 0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 17 1 1 0 1 1 0 1 0 0 1 1 1 0 1 0 1 1 19 1 1 0 1 1 0 1 0 1 0 0 1 1 0 0 0 0 1 1 19 1 1 0 1 1 0 1 0 1 0 0 1 1 1 0 0 0 1 1 20 1 1 0 1 1 0 1 0 1 0 1 1 0 0 1 0 0 0 1 1 20 1 1 0 1 1 0 1 0 1 0 1 1 1 0 1 0 0 0 1 1 18 1 1 0 1 1 0 1 0 1 1 0 0 1 0 0 0 1 1 17 1 1 0 1 1 0 1 0 1 1 0 1 0 1 0 1 1 21 1 1 0 1 1 1 0 0 0 0 0 1 1 0 1 0 0 0 0 1 1 19 1 1 0 1 1 1 0 0 0 0 1 1 0 0 1 0 0 1 1 19 1 1 0 1 1 1 0 0 0 0 1 1 0 1 0 0 0 1 1 17 1 1 0 1 1 1 0 0 0 1 1 0 0 1 0 1 1 17 1 1 0 1 1 1 0 0 0 1 1 0 1 0 0 1 1 19 1 1 0 1 1 1 0 0 1 0 0 1 1 0 0 0 0 1 1 21 1 1 0 1 1 1 0 0 1 0 0 1 1 0 1 0 1 0 0 1 1 20 1 1 0 1 1 1 0 0 1 0 1 1 0 0 0 0 0 0 1 1 20 1 1 0 1 1 1 0 0 1 0 1 1 1 0 0 0 0 0 1 1 17 1 1 0 1 1 1 0 0 1 1 0 1 0 1 0 1 1 15 1 1 0 1 1 1 0 0 1 1 0 1 0 1 1 21 1 1 0 1 1 1 0 1 0 0 0 1 1 0 0 0 1 0 0 1 1 21 1 1 0 1 1 1 0 1 0 0 0 1 1 1 0 0 1 0 0 1 1 19 1 1 0 1 1 1 0 1 0 0 1 1 0 0 0 1 0 1 1 19 1 1 0 1 1 1 0 1 0 0 1 1 1 0 0 1 0 1 1 18 1 1 0 1 1 1 0 1 0 1 1 0 0 0 0 0 1 1 18 1 1 0 1 1 1 0 1 0 1 1 1 0 0 0 0 1 1 14 1 1 0 1 1 1 0 1 1 0 0 0 1 1 14 1 1 0 1 1 1 0 1 1 1 0 0 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,1]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,1]));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,0,1,1,0,1,1]));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &Space) -> (Space,Space,Space,Space,Space,Space,) {
  let v1_2: Space = map_kernels::unwrap(&(*capture_0),&(*CONSTANT_3));
  let v1_4: Space = map_kernels::unwrap(&(v1_2),&(*CONSTANT_4));
  let mut v1_26 = Space::new();
  let mut v1_26_cursor = (v1_4).read_zipper();
  for v1_26_byte in v1_26_cursor.child_mask().iter() {
    v1_26_cursor.descend_to_byte(v1_26_byte);
    {
    let v1_26_tail = v1_26_cursor.fork_read_zipper();
    let v1_26_head = Path::from_slice(&[v1_26_byte]);
    let v2_2: Space = singleton(&(v1_26_head));
    let v2_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v2_2));
    let v2_4: Space = if map_kernels::has_head(&(v2_3)) { singleton(&[]) } else { Space::new() };
    drop(v2_3);
    let v2_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v2_4));
    drop(v2_4);
    let v2_7: Space = if (v2_5).is_empty() { Space::new() } else {
      let mut v3_6 = Space::new();
      let mut v3_6_cursor = (v1_26_tail).read_zipper();
      for v3_6_byte in v3_6_cursor.child_mask().iter() {
        v3_6_cursor.descend_to_byte(v3_6_byte);
        {
        let v3_6_tail = v3_6_cursor.fork_read_zipper();
        let v3_6_head = Path::from_slice(&[v3_6_byte]);
        let v4_2: Space = singleton(&(v3_6_head));
        let v4_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v4_2));
        let v4_4: Space = if map_kernels::has_head(&(v4_3)) { singleton(&[]) } else { Space::new() };
        drop(v4_3);
        let v4_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v4_4));
        drop(v4_4);
        let v4_8: Space = if (v4_5).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v1_26_head),&(v3_6_head));
          let mut v5_7 = Space::new();
          let mut v5_7_cursor = (v3_6_tail).read_zipper();
          for v5_7_byte in v5_7_cursor.child_mask().iter() {
            v5_7_cursor.descend_to_byte(v5_7_byte);
            {
            let v5_7_tail = v5_7_cursor.fork_read_zipper();
            let v5_7_head = Path::from_slice(&[v5_7_byte]);
            let v6_2: Space = singleton(&(v5_7_head));
            let v6_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v6_2));
            let v6_4: Space = if map_kernels::has_head(&(v6_3)) { singleton(&[]) } else { Space::new() };
            drop(v6_3);
            let v6_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v6_4));
            drop(v6_4);
            let v6_8: Space = if (v6_5).is_empty() { Space::new() } else {
              let v7_6: Path = concat_path(&(v5_6),&(v5_7_head));
              let v7_7: Space = routine_2(c, &(v7_6), &(v5_7_tail).make_space(), &(*capture_0));
              map_map_kernels::compose(&(v6_5),&(v7_7))
            };
            drop(v6_5);
            let v6_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v6_2));
            drop(v6_2);
            let v6_10: Space = if map_kernels::has_head(&(v6_9)) { singleton(&[]) } else { Space::new() };
            drop(v6_9);
            let v6_12: Space = if (v6_10).is_empty() { Space::new() } else {
              let v8_6: Path = concat_path(&(v5_6),&(v5_7_head));
              let v8_11: Space = routine_3(c, &(v8_6), &(v5_7_tail).make_space(), &(*capture_0));
              drop(v8_6);
              map_map_kernels::compose(&(v6_10),&(v8_11))
            };
            drop(v6_10);
            let v6_13: Space = map_map_kernels::unite(&(v6_8),&(v6_12));
            v5_7.join_into((v6_13).clone());
            }
            v5_7_cursor.ascend(1);
          }
          drop(v5_7_cursor);
          map_map_kernels::compose(&(v4_5),&(v5_7))
        };
        drop(v4_5);
        let v4_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v4_2));
        drop(v4_2);
        let v4_10: Space = if map_kernels::has_head(&(v4_9)) { singleton(&[]) } else { Space::new() };
        drop(v4_9);
        let v4_12: Space = if (v4_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v1_26_head),&(v3_6_head));
          let mut v9_11 = Space::new();
          let mut v9_11_cursor = (v3_6_tail).read_zipper();
          for v9_11_byte in v9_11_cursor.child_mask().iter() {
            v9_11_cursor.descend_to_byte(v9_11_byte);
            {
            let v9_11_tail = v9_11_cursor.fork_read_zipper();
            let v9_11_head = Path::from_slice(&[v9_11_byte]);
            let v10_2: Space = singleton(&(v9_11_head));
            let v10_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v10_2));
            let v10_4: Space = if map_kernels::has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
            drop(v10_3);
            let v10_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v10_4));
            drop(v10_4);
            let v10_8: Space = if (v10_5).is_empty() { Space::new() } else {
              let v11_6: Path = concat_path(&(v9_6),&(v9_11_head));
              let v11_7: Space = routine_2(c, &(v11_6), &(v9_11_tail).make_space(), &(*capture_0));
              map_map_kernels::compose(&(v10_5),&(v11_7))
            };
            drop(v10_5);
            let v10_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v10_2));
            drop(v10_2);
            let v10_10: Space = if map_kernels::has_head(&(v10_9)) { singleton(&[]) } else { Space::new() };
            drop(v10_9);
            let v10_12: Space = if (v10_10).is_empty() { Space::new() } else {
              let v12_6: Path = concat_path(&(v9_6),&(v9_11_head));
              let v12_11: Space = routine_4(c, &(v12_6), &(v9_11_tail).make_space(), &(*capture_0));
              drop(v12_6);
              map_map_kernels::compose(&(v10_10),&(v12_11))
            };
            drop(v10_10);
            let v10_13: Space = map_map_kernels::unite(&(v10_8),&(v10_12));
            v9_11.join_into((v10_13).clone());
            }
            v9_11_cursor.ascend(1);
          }
          drop(v9_11_cursor);
          drop(v9_6);
          map_map_kernels::compose(&(v4_10),&(v9_11))
        };
        drop(v4_10);
        let v4_13: Space = map_map_kernels::unite(&(v4_8),&(v4_12));
        v3_6.join_into((v4_13).clone());
        }
        v3_6_cursor.ascend(1);
      }
      drop(v3_6_cursor);
      map_map_kernels::compose(&(v2_5),&(v3_6))
    };
    drop(v2_5);
    let v2_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v2_2));
    drop(v2_2);
    let v2_9: Space = if map_kernels::has_head(&(v2_8)) { singleton(&[]) } else { Space::new() };
    drop(v2_8);
    let v2_11: Space = if (v2_9).is_empty() { Space::new() } else {
      let mut v13_10 = Space::new();
      let mut v13_10_cursor = (v1_26_tail).read_zipper();
      for v13_10_byte in v13_10_cursor.child_mask().iter() {
        v13_10_cursor.descend_to_byte(v13_10_byte);
        {
        let v13_10_tail = v13_10_cursor.fork_read_zipper();
        let v13_10_head = Path::from_slice(&[v13_10_byte]);
        let v14_2: Space = singleton(&(v13_10_head));
        let v14_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v14_2));
        let v14_4: Space = if map_kernels::has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
        drop(v14_3);
        let v14_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v14_4));
        drop(v14_4);
        let v14_8: Space = if (v14_5).is_empty() { Space::new() } else {
          let v15_6: Path = concat_path(&(v1_26_head),&(v13_10_head));
          let mut v15_7 = Space::new();
          let mut v15_7_cursor = (v13_10_tail).read_zipper();
          for v15_7_byte in v15_7_cursor.child_mask().iter() {
            v15_7_cursor.descend_to_byte(v15_7_byte);
            {
            let v15_7_tail = v15_7_cursor.fork_read_zipper();
            let v15_7_head = Path::from_slice(&[v15_7_byte]);
            let v16_2: Space = singleton(&(v15_7_head));
            let v16_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v16_2));
            let v16_4: Space = if map_kernels::has_head(&(v16_3)) { singleton(&[]) } else { Space::new() };
            drop(v16_3);
            let v16_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v16_4));
            drop(v16_4);
            let v16_8: Space = if (v16_5).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v15_6),&(v15_7_head));
              let v17_7: Space = routine_2(c, &(v17_6), &(v15_7_tail).make_space(), &(*capture_0));
              map_map_kernels::compose(&(v16_5),&(v17_7))
            };
            drop(v16_5);
            let v16_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v16_2));
            drop(v16_2);
            let v16_10: Space = if map_kernels::has_head(&(v16_9)) { singleton(&[]) } else { Space::new() };
            drop(v16_9);
            let v16_12: Space = if (v16_10).is_empty() { Space::new() } else {
              let v18_6: Path = concat_path(&(v15_6),&(v15_7_head));
              let v18_11: Space = routine_3(c, &(v18_6), &(v15_7_tail).make_space(), &(*capture_0));
              drop(v18_6);
              map_map_kernels::compose(&(v16_10),&(v18_11))
            };
            drop(v16_10);
            let v16_13: Space = map_map_kernels::unite(&(v16_8),&(v16_12));
            v15_7.join_into((v16_13).clone());
            }
            v15_7_cursor.ascend(1);
          }
          drop(v15_7_cursor);
          map_map_kernels::compose(&(v14_5),&(v15_7))
        };
        drop(v14_5);
        let v14_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v14_2));
        drop(v14_2);
        let v14_10: Space = if map_kernels::has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
        drop(v14_9);
        let v14_12: Space = if (v14_10).is_empty() { Space::new() } else {
          let mut v19_11 = Space::new();
          let mut v19_11_cursor = (v13_10_tail).read_zipper();
          for v19_11_byte in v19_11_cursor.child_mask().iter() {
            v19_11_cursor.descend_to_byte(v19_11_byte);
            {
            let v19_11_tail = v19_11_cursor.fork_read_zipper();
            let v19_11_head = Path::from_slice(&[v19_11_byte]);
            let v20_2: Space = singleton(&(v19_11_head));
            let v20_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v20_2));
            let v20_4: Space = if map_kernels::has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
            drop(v20_3);
            let v20_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v20_4));
            drop(v20_4);
            let v20_7: Space = if (v20_5).is_empty() { Space::new() } else {
              let v21_6: Space = routine_5(c, &(v19_11_head), &(v19_11_tail).make_space(), &(*capture_0));
              map_map_kernels::compose(&(v20_5),&(v21_6))
            };
            drop(v20_5);
            let v20_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v20_2));
            drop(v20_2);
            let v20_9: Space = if map_kernels::has_head(&(v20_8)) { singleton(&[]) } else { Space::new() };
            drop(v20_8);
            let v20_11: Space = if (v20_9).is_empty() { Space::new() } else {
              let v22_10: Space = routine_6(c, &(v19_11_head), &(v19_11_tail).make_space(), &(*capture_0));
              map_map_kernels::compose(&(v20_9),&(v22_10))
            };
            drop(v20_9);
            let v20_12: Space = map_map_kernels::unite(&(v20_7),&(v20_11));
            v19_11.join_into((v20_12).clone());
            }
            v19_11_cursor.ascend(1);
          }
          drop(v19_11_cursor);
          map_map_kernels::compose(&(v14_10),&(v19_11))
        };
        drop(v14_10);
        let v23_6: Path = concat_path(&(v1_26_head),&(v13_10_head));
        let v14_13: Space = map_kernels::wrap(&(v14_12),&(v23_6));
        let v14_14: Space = map_map_kernels::unite(&(v14_8),&(v14_13));
        v13_10.join_into((v14_14).clone());
        }
        v13_10_cursor.ascend(1);
      }
      drop(v13_10_cursor);
      map_map_kernels::compose(&(v2_9),&(v13_10))
    };
    drop(v2_9);
    let v2_12: Space = map_map_kernels::unite(&(v2_7),&(v2_11));
    v1_26.join_into((v2_12).clone());
    }
    v1_26_cursor.ascend(1);
  }
  drop(v1_26_cursor);
  let mut v1_48 = Space::new();
  let mut v1_48_cursor = (v1_4).read_zipper();
  for v1_48_byte in v1_48_cursor.child_mask().iter() {
    v1_48_cursor.descend_to_byte(v1_48_byte);
    {
    let v1_48_tail = v1_48_cursor.fork_read_zipper();
    let v1_48_head = Path::from_slice(&[v1_48_byte]);
    let v24_2: Space = singleton(&(v1_48_head));
    let v24_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v24_2));
    let v24_4: Space = if map_kernels::has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
    drop(v24_3);
    let v24_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v24_4));
    drop(v24_4);
    let v24_7: Space = if (v24_5).is_empty() { Space::new() } else {
      let mut v25_6 = Space::new();
      let mut v25_6_cursor = (v1_48_tail).read_zipper();
      for v25_6_byte in v25_6_cursor.child_mask().iter() {
        v25_6_cursor.descend_to_byte(v25_6_byte);
        {
        let v25_6_tail = v25_6_cursor.fork_read_zipper();
        let v25_6_head = Path::from_slice(&[v25_6_byte]);
        let v26_2: Space = singleton(&(v25_6_head));
        let v26_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v26_2));
        let v26_4: Space = if map_kernels::has_head(&(v26_3)) { singleton(&[]) } else { Space::new() };
        drop(v26_3);
        let v26_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v26_4));
        drop(v26_4);
        let v26_8: Space = if (v26_5).is_empty() { Space::new() } else {
          let v27_6: Path = concat_path(&(v1_48_head),&(v25_6_head));
          let mut v27_7 = Space::new();
          let mut v27_7_cursor = (v25_6_tail).read_zipper();
          for v27_7_byte in v27_7_cursor.child_mask().iter() {
            v27_7_cursor.descend_to_byte(v27_7_byte);
            {
            let v27_7_tail = v27_7_cursor.fork_read_zipper();
            let v27_7_head = Path::from_slice(&[v27_7_byte]);
            let v28_2: Space = singleton(&(v27_7_head));
            let v28_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v28_2));
            let v28_4: Space = if map_kernels::has_head(&(v28_3)) { singleton(&[]) } else { Space::new() };
            drop(v28_3);
            let v28_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v28_4));
            drop(v28_4);
            let v28_8: Space = if (v28_5).is_empty() { Space::new() } else {
              let v29_6: Path = concat_path(&(v27_6),&(v27_7_head));
              let v29_7: Space = routine_7(c, &(v29_6), &(v27_7_tail).make_space(), &(*capture_0));
              map_map_kernels::compose(&(v28_5),&(v29_7))
            };
            drop(v28_5);
            let v28_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v28_2));
            drop(v28_2);
            let v28_10: Space = if map_kernels::has_head(&(v28_9)) { singleton(&[]) } else { Space::new() };
            drop(v28_9);
            let v28_12: Space = if (v28_10).is_empty() { Space::new() } else {
              let v30_6: Path = concat_path(&(v27_6),&(v27_7_head));
              let v30_11: Space = routine_8(c, &(v30_6), &(v27_7_tail).make_space(), &(*capture_0));
              drop(v30_6);
              map_map_kernels::compose(&(v28_10),&(v30_11))
            };
            drop(v28_10);
            let v28_13: Space = map_map_kernels::unite(&(v28_8),&(v28_12));
            v27_7.join_into((v28_13).clone());
            }
            v27_7_cursor.ascend(1);
          }
          drop(v27_7_cursor);
          map_map_kernels::compose(&(v26_5),&(v27_7))
        };
        drop(v26_5);
        let v26_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v26_2));
        drop(v26_2);
        let v26_10: Space = if map_kernels::has_head(&(v26_9)) { singleton(&[]) } else { Space::new() };
        drop(v26_9);
        let v26_12: Space = if (v26_10).is_empty() { Space::new() } else {
          let v31_6: Path = concat_path(&(v1_48_head),&(v25_6_head));
          let mut v31_11 = Space::new();
          let mut v31_11_cursor = (v25_6_tail).read_zipper();
          for v31_11_byte in v31_11_cursor.child_mask().iter() {
            v31_11_cursor.descend_to_byte(v31_11_byte);
            {
            let v31_11_tail = v31_11_cursor.fork_read_zipper();
            let v31_11_head = Path::from_slice(&[v31_11_byte]);
            let v32_2: Space = singleton(&(v31_11_head));
            let v32_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v32_2));
            let v32_4: Space = if map_kernels::has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v32_4));
            drop(v32_4);
            let v32_8: Space = if (v32_5).is_empty() { Space::new() } else {
              let v33_6: Path = concat_path(&(v31_6),&(v31_11_head));
              let v33_7: Space = routine_7(c, &(v33_6), &(v31_11_tail).make_space(), &(*capture_0));
              map_map_kernels::compose(&(v32_5),&(v33_7))
            };
            drop(v32_5);
            let v32_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v32_2));
            drop(v32_2);
            let v32_10: Space = if map_kernels::has_head(&(v32_9)) { singleton(&[]) } else { Space::new() };
            drop(v32_9);
            let v32_12: Space = if (v32_10).is_empty() { Space::new() } else {
              let v34_6: Path = concat_path(&(v31_6),&(v31_11_head));
              let v34_11: Space = routine_9(c, &(v34_6), &(v31_11_tail).make_space(), &(*capture_0));
              drop(v34_6);
              map_map_kernels::compose(&(v32_10),&(v34_11))
            };
            drop(v32_10);
            let v32_13: Space = map_map_kernels::unite(&(v32_8),&(v32_12));
            v31_11.join_into((v32_13).clone());
            }
            v31_11_cursor.ascend(1);
          }
          drop(v31_11_cursor);
          drop(v31_6);
          map_map_kernels::compose(&(v26_10),&(v31_11))
        };
        drop(v26_10);
        let v26_13: Space = map_map_kernels::unite(&(v26_8),&(v26_12));
        v25_6.join_into((v26_13).clone());
        }
        v25_6_cursor.ascend(1);
      }
      drop(v25_6_cursor);
      map_map_kernels::compose(&(v24_5),&(v25_6))
    };
    drop(v24_5);
    let v24_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v24_2));
    drop(v24_2);
    let v24_9: Space = if map_kernels::has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
    drop(v24_8);
    let v24_11: Space = if (v24_9).is_empty() { Space::new() } else {
      let mut v35_10 = Space::new();
      let mut v35_10_cursor = (v1_48_tail).read_zipper();
      for v35_10_byte in v35_10_cursor.child_mask().iter() {
        v35_10_cursor.descend_to_byte(v35_10_byte);
        {
        let v35_10_tail = v35_10_cursor.fork_read_zipper();
        let v35_10_head = Path::from_slice(&[v35_10_byte]);
        let v36_2: Space = singleton(&(v35_10_head));
        let v36_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v36_2));
        let v36_4: Space = if map_kernels::has_head(&(v36_3)) { singleton(&[]) } else { Space::new() };
        drop(v36_3);
        let v36_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v36_4));
        drop(v36_4);
        let v36_8: Space = if (v36_5).is_empty() { Space::new() } else {
          let v37_6: Path = concat_path(&(v1_48_head),&(v35_10_head));
          let mut v37_7 = Space::new();
          let mut v37_7_cursor = (v35_10_tail).read_zipper();
          for v37_7_byte in v37_7_cursor.child_mask().iter() {
            v37_7_cursor.descend_to_byte(v37_7_byte);
            {
            let v37_7_tail = v37_7_cursor.fork_read_zipper();
            let v37_7_head = Path::from_slice(&[v37_7_byte]);
            let v38_2: Space = singleton(&(v37_7_head));
            let v38_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v38_2));
            let v38_4: Space = if map_kernels::has_head(&(v38_3)) { singleton(&[]) } else { Space::new() };
            drop(v38_3);
            let v38_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v38_4));
            drop(v38_4);
            let v38_8: Space = if (v38_5).is_empty() { Space::new() } else {
              let v39_6: Path = concat_path(&(v37_6),&(v37_7_head));
              let v39_7: Space = routine_7(c, &(v39_6), &(v37_7_tail).make_space(), &(*capture_0));
              map_map_kernels::compose(&(v38_5),&(v39_7))
            };
            drop(v38_5);
            let v38_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v38_2));
            drop(v38_2);
            let v38_10: Space = if map_kernels::has_head(&(v38_9)) { singleton(&[]) } else { Space::new() };
            drop(v38_9);
            let v38_12: Space = if (v38_10).is_empty() { Space::new() } else {
              let v40_6: Path = concat_path(&(v37_6),&(v37_7_head));
              let v40_11: Space = routine_8(c, &(v40_6), &(v37_7_tail).make_space(), &(*capture_0));
              drop(v40_6);
              map_map_kernels::compose(&(v38_10),&(v40_11))
            };
            drop(v38_10);
            let v38_13: Space = map_map_kernels::unite(&(v38_8),&(v38_12));
            v37_7.join_into((v38_13).clone());
            }
            v37_7_cursor.ascend(1);
          }
          drop(v37_7_cursor);
          map_map_kernels::compose(&(v36_5),&(v37_7))
        };
        drop(v36_5);
        let v36_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v36_2));
        drop(v36_2);
        let v36_10: Space = if map_kernels::has_head(&(v36_9)) { singleton(&[]) } else { Space::new() };
        drop(v36_9);
        let v36_12: Space = if (v36_10).is_empty() { Space::new() } else {
          let mut v41_11 = Space::new();
          let mut v41_11_cursor = (v35_10_tail).read_zipper();
          for v41_11_byte in v41_11_cursor.child_mask().iter() {
            v41_11_cursor.descend_to_byte(v41_11_byte);
            {
            let v41_11_tail = v41_11_cursor.fork_read_zipper();
            let v41_11_head = Path::from_slice(&[v41_11_byte]);
            let v42_2: Space = singleton(&(v41_11_head));
            let v42_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v42_2));
            let v42_4: Space = if map_kernels::has_head(&(v42_3)) { singleton(&[]) } else { Space::new() };
            drop(v42_3);
            let v42_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v42_4));
            drop(v42_4);
            let v42_7: Space = if (v42_5).is_empty() { Space::new() } else {
              let v43_6: Space = routine_10(c, &(v41_11_head), &(v41_11_tail).make_space(), &(*capture_0));
              map_map_kernels::compose(&(v42_5),&(v43_6))
            };
            drop(v42_5);
            let v42_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v42_2));
            drop(v42_2);
            let v42_9: Space = if map_kernels::has_head(&(v42_8)) { singleton(&[]) } else { Space::new() };
            drop(v42_8);
            let v42_11: Space = if (v42_9).is_empty() { Space::new() } else {
              let v44_10: Space = routine_11(c, &(v41_11_head), &(v41_11_tail).make_space(), &(*capture_0));
              map_map_kernels::compose(&(v42_9),&(v44_10))
            };
            drop(v42_9);
            let v42_12: Space = map_map_kernels::unite(&(v42_7),&(v42_11));
            v41_11.join_into((v42_12).clone());
            }
            v41_11_cursor.ascend(1);
          }
          drop(v41_11_cursor);
          map_map_kernels::compose(&(v36_10),&(v41_11))
        };
        drop(v36_10);
        let v45_6: Path = concat_path(&(v1_48_head),&(v35_10_head));
        let v36_13: Space = map_kernels::wrap(&(v36_12),&(v45_6));
        let v36_14: Space = map_map_kernels::unite(&(v36_8),&(v36_13));
        v35_10.join_into((v36_14).clone());
        }
        v35_10_cursor.ascend(1);
      }
      drop(v35_10_cursor);
      map_map_kernels::compose(&(v24_9),&(v35_10))
    };
    drop(v24_9);
    let v24_12: Space = map_map_kernels::unite(&(v24_7),&(v24_11));
    v1_48.join_into((v24_12).clone());
    }
    v1_48_cursor.ascend(1);
  }
  drop(v1_48_cursor);
  drop(v1_4);
  let v1_49: Space = map_map_kernels::unite(&(v1_26),&(v1_48));
  let v1_51: Space = map_kernels::unwrap(&(*capture_0),&(*CONSTANT_7));
  let v1_53: Space = map_kernels::unwrap(&(v1_51),&(*CONSTANT_8));
  let mut v1_73 = Space::new();
  let mut v1_73_cursor = (v1_53).read_zipper();
  for v1_73_byte in v1_73_cursor.child_mask().iter() {
    v1_73_cursor.descend_to_byte(v1_73_byte);
    {
    let v1_73_tail = v1_73_cursor.fork_read_zipper();
    let v1_73_head = Path::from_slice(&[v1_73_byte]);
    let v46_2: Space = singleton(&(v1_73_head));
    let v46_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v46_2));
    let v46_4: Space = if map_kernels::has_head(&(v46_3)) { singleton(&[]) } else { Space::new() };
    drop(v46_3);
    let v46_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v46_4));
    drop(v46_4);
    let v46_7: Space = if (v46_5).is_empty() { Space::new() } else {
      let mut v47_6 = Space::new();
      let mut v47_6_cursor = (v1_73_tail).read_zipper();
      for v47_6_byte in v47_6_cursor.child_mask().iter() {
        v47_6_cursor.descend_to_byte(v47_6_byte);
        {
        let v47_6_tail = v47_6_cursor.fork_read_zipper();
        let v47_6_head = Path::from_slice(&[v47_6_byte]);
        let v48_2: Space = singleton(&(v47_6_head));
        let v48_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v48_2));
        let v48_4: Space = if map_kernels::has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
        drop(v48_3);
        let v48_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v48_4));
        drop(v48_4);
        let v48_8: Space = if (v48_5).is_empty() { Space::new() } else {
          let v49_6: Path = concat_path(&(v1_73_head),&(v47_6_head));
          let mut v49_7 = Space::new();
          let mut v49_7_cursor = (v47_6_tail).read_zipper();
          for v49_7_byte in v49_7_cursor.child_mask().iter() {
            v49_7_cursor.descend_to_byte(v49_7_byte);
            {
            let v49_7_tail = v49_7_cursor.fork_read_zipper();
            let v49_7_head = Path::from_slice(&[v49_7_byte]);
            let v50_2: Space = singleton(&(v49_7_head));
            let v50_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v50_2));
            let v50_4: Space = if map_kernels::has_head(&(v50_3)) { singleton(&[]) } else { Space::new() };
            drop(v50_3);
            let v50_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v50_4));
            drop(v50_4);
            let v50_8: Space = if (v50_5).is_empty() { Space::new() } else {
              let v51_6: Path = concat_path(&(v49_6),&(v49_7_head));
              let v51_7: Space = routine_12(c, &(v51_6), &(v49_7_tail).make_space());
              map_map_kernels::compose(&(v50_5),&(v51_7))
            };
            drop(v50_5);
            let v50_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v50_2));
            drop(v50_2);
            let v50_10: Space = if map_kernels::has_head(&(v50_9)) { singleton(&[]) } else { Space::new() };
            drop(v50_9);
            let v50_12: Space = if (v50_10).is_empty() { Space::new() } else {
              let v52_6: Path = concat_path(&(v49_6),&(v49_7_head));
              let v52_11: Space = routine_13(c, &(v52_6), &(v49_7_tail).make_space());
              drop(v52_6);
              map_map_kernels::compose(&(v50_10),&(v52_11))
            };
            drop(v50_10);
            let v50_13: Space = map_map_kernels::unite(&(v50_8),&(v50_12));
            v49_7.join_into((v50_13).clone());
            }
            v49_7_cursor.ascend(1);
          }
          drop(v49_7_cursor);
          map_map_kernels::compose(&(v48_5),&(v49_7))
        };
        drop(v48_5);
        let v48_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v48_2));
        drop(v48_2);
        let v48_10: Space = if map_kernels::has_head(&(v48_9)) { singleton(&[]) } else { Space::new() };
        drop(v48_9);
        let v48_12: Space = if (v48_10).is_empty() { Space::new() } else {
          let v53_6: Path = concat_path(&(v1_73_head),&(v47_6_head));
          let mut v53_11 = Space::new();
          let mut v53_11_cursor = (v47_6_tail).read_zipper();
          for v53_11_byte in v53_11_cursor.child_mask().iter() {
            v53_11_cursor.descend_to_byte(v53_11_byte);
            {
            let v53_11_tail = v53_11_cursor.fork_read_zipper();
            let v53_11_head = Path::from_slice(&[v53_11_byte]);
            let v54_2: Space = singleton(&(v53_11_head));
            let v54_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v54_2));
            let v54_4: Space = if map_kernels::has_head(&(v54_3)) { singleton(&[]) } else { Space::new() };
            drop(v54_3);
            let v54_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v54_4));
            drop(v54_4);
            let v54_8: Space = if (v54_5).is_empty() { Space::new() } else {
              let v55_6: Path = concat_path(&(v53_6),&(v53_11_head));
              let v55_7: Space = routine_12(c, &(v55_6), &(v53_11_tail).make_space());
              map_map_kernels::compose(&(v54_5),&(v55_7))
            };
            drop(v54_5);
            let v54_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v54_2));
            drop(v54_2);
            let v54_10: Space = if map_kernels::has_head(&(v54_9)) { singleton(&[]) } else { Space::new() };
            drop(v54_9);
            let v54_12: Space = if (v54_10).is_empty() { Space::new() } else {
              let v56_6: Path = concat_path(&(v53_6),&(v53_11_head));
              let v56_11: Space = routine_14(c, &(v56_6), &(v53_11_tail).make_space());
              drop(v56_6);
              map_map_kernels::compose(&(v54_10),&(v56_11))
            };
            drop(v54_10);
            let v54_13: Space = map_map_kernels::unite(&(v54_8),&(v54_12));
            v53_11.join_into((v54_13).clone());
            }
            v53_11_cursor.ascend(1);
          }
          drop(v53_11_cursor);
          drop(v53_6);
          map_map_kernels::compose(&(v48_10),&(v53_11))
        };
        drop(v48_10);
        let v48_13: Space = map_map_kernels::unite(&(v48_8),&(v48_12));
        v47_6.join_into((v48_13).clone());
        }
        v47_6_cursor.ascend(1);
      }
      drop(v47_6_cursor);
      map_map_kernels::compose(&(v46_5),&(v47_6))
    };
    drop(v46_5);
    let v46_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v46_2));
    drop(v46_2);
    let v46_9: Space = if map_kernels::has_head(&(v46_8)) { singleton(&[]) } else { Space::new() };
    drop(v46_8);
    let v46_11: Space = if (v46_9).is_empty() { Space::new() } else {
      let mut v57_10 = Space::new();
      let mut v57_10_cursor = (v1_73_tail).read_zipper();
      for v57_10_byte in v57_10_cursor.child_mask().iter() {
        v57_10_cursor.descend_to_byte(v57_10_byte);
        {
        let v57_10_tail = v57_10_cursor.fork_read_zipper();
        let v57_10_head = Path::from_slice(&[v57_10_byte]);
        let v58_2: Space = singleton(&(v57_10_head));
        let v58_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v58_2));
        let v58_4: Space = if map_kernels::has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v58_4));
        drop(v58_4);
        let v58_8: Space = if (v58_5).is_empty() { Space::new() } else {
          let v59_6: Path = concat_path(&(v1_73_head),&(v57_10_head));
          let mut v59_7 = Space::new();
          let mut v59_7_cursor = (v57_10_tail).read_zipper();
          for v59_7_byte in v59_7_cursor.child_mask().iter() {
            v59_7_cursor.descend_to_byte(v59_7_byte);
            {
            let v59_7_tail = v59_7_cursor.fork_read_zipper();
            let v59_7_head = Path::from_slice(&[v59_7_byte]);
            let v60_2: Space = singleton(&(v59_7_head));
            let v60_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v60_2));
            let v60_4: Space = if map_kernels::has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (v60_5).is_empty() { Space::new() } else {
              let v61_6: Path = concat_path(&(v59_6),&(v59_7_head));
              let v61_7: Space = routine_12(c, &(v61_6), &(v59_7_tail).make_space());
              map_map_kernels::compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if map_kernels::has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (v60_10).is_empty() { Space::new() } else {
              let v62_6: Path = concat_path(&(v59_6),&(v59_7_head));
              let v62_11: Space = routine_13(c, &(v62_6), &(v59_7_tail).make_space());
              drop(v62_6);
              map_map_kernels::compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = map_map_kernels::unite(&(v60_8),&(v60_12));
            v59_7.join_into((v60_13).clone());
            }
            v59_7_cursor.ascend(1);
          }
          drop(v59_7_cursor);
          map_map_kernels::compose(&(v58_5),&(v59_7))
        };
        drop(v58_5);
        let v58_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v58_2));
        drop(v58_2);
        let v58_10: Space = if map_kernels::has_head(&(v58_9)) { singleton(&[]) } else { Space::new() };
        drop(v58_9);
        let v58_11: Space = view_map_kernels::subtract(&(v57_10_tail),&(*CONSTANT_5));
        let v58_12: Space = map_map_kernels::compose(&(v58_10),&(v58_11));
        drop(v58_10);
        drop(v58_11);
        let v63_6: Path = concat_path(&(v1_73_head),&(v57_10_head));
        let v58_13: Space = map_kernels::wrap(&(v58_12),&(v63_6));
        drop(v58_12);
        let v58_14: Space = map_map_kernels::unite(&(v58_8),&(v58_13));
        drop(v58_13);
        v57_10.join_into((v58_14).clone());
        }
        v57_10_cursor.ascend(1);
      }
      drop(v57_10_cursor);
      map_map_kernels::compose(&(v46_9),&(v57_10))
    };
    drop(v46_9);
    let v46_12: Space = map_map_kernels::unite(&(v46_7),&(v46_11));
    v1_73.join_into((v46_12).clone());
    }
    v1_73_cursor.ascend(1);
  }
  drop(v1_73_cursor);
  drop(v1_53);

((v1_2).clone(),(v1_26).clone(),(v1_48).clone(),(v1_49).clone(),(v1_51).clone(),(v1_73).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &Space) -> (Space,Space,Space,Space,Space,Space,) {
    let v86_1: Space = map_kernels::unwrap(&((*capture_0)),&(*CONSTANT_3));
    let v86_2: Space = map_kernels::unwrap(&(v86_1),&(*CONSTANT_4));
    let mut v86_3 = Space::new();
    let mut v86_3_cursor = (v86_2).read_zipper();
    for v86_3_byte in v86_3_cursor.child_mask().iter() {
      v86_3_cursor.descend_to_byte(v86_3_byte);
      {
      let v86_3_tail = v86_3_cursor.fork_read_zipper();
      let v86_3_head = Path::from_slice(&[v86_3_byte]);
      let v87_2: Space = singleton(&(v86_3_head));
      let v87_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v87_2));
      let v87_4: Space = if map_kernels::has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
      drop(v87_3);
      let v87_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v87_4));
      drop(v87_4);
      let v87_7: Space = if (v87_5).is_empty() { Space::new() } else {
        let mut v88_6 = Space::new();
        let mut v88_6_cursor = (v86_3_tail).read_zipper();
        for v88_6_byte in v88_6_cursor.child_mask().iter() {
          v88_6_cursor.descend_to_byte(v88_6_byte);
          {
          let v88_6_tail = v88_6_cursor.fork_read_zipper();
          let v88_6_head = Path::from_slice(&[v88_6_byte]);
          let v89_2: Space = singleton(&(v88_6_head));
          let v89_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v89_2));
          let v89_4: Space = if map_kernels::has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
          drop(v89_3);
          let v89_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v89_4));
          drop(v89_4);
          let v89_8: Space = if (v89_5).is_empty() { Space::new() } else {
            let v90_6: Path = concat_path(&(v86_3_head),&(v88_6_head));
            let mut v90_7 = Space::new();
            let mut v90_7_cursor = (v88_6_tail).read_zipper();
            for v90_7_byte in v90_7_cursor.child_mask().iter() {
              v90_7_cursor.descend_to_byte(v90_7_byte);
              {
              let v90_7_tail = v90_7_cursor.fork_read_zipper();
              let v90_7_head = Path::from_slice(&[v90_7_byte]);
              let v91_2: Space = singleton(&(v90_7_head));
              let v91_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v91_2));
              let v91_4: Space = if map_kernels::has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
              drop(v91_3);
              let v91_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v91_4));
              drop(v91_4);
              let v91_8: Space = if (v91_5).is_empty() { Space::new() } else {
                let v92_6: Path = concat_path(&(v90_6),&(v90_7_head));
                let v92_7: Space = routine_2(c, &(v92_6), &(v90_7_tail).make_space(), &((*capture_0)));
                map_map_kernels::compose(&(v91_5),&(v92_7))
              };
              drop(v91_5);
              let v91_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v91_2));
              drop(v91_2);
              let v91_10: Space = if map_kernels::has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
              drop(v91_9);
              let v91_12: Space = if (v91_10).is_empty() { Space::new() } else {
                let v93_6: Path = concat_path(&(v90_6),&(v90_7_head));
                let v93_11: Space = routine_3(c, &(v93_6), &(v90_7_tail).make_space(), &((*capture_0)));
                drop(v93_6);
                map_map_kernels::compose(&(v91_10),&(v93_11))
              };
              drop(v91_10);
              let v91_13: Space = map_map_kernels::unite(&(v91_8),&(v91_12));
              v90_7.join_into((v91_13).clone());
              }
              v90_7_cursor.ascend(1);
            }
            drop(v90_7_cursor);
            map_map_kernels::compose(&(v89_5),&(v90_7))
          };
          drop(v89_5);
          let v89_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v89_2));
          drop(v89_2);
          let v89_10: Space = if map_kernels::has_head(&(v89_9)) { singleton(&[]) } else { Space::new() };
          drop(v89_9);
          let v89_12: Space = if (v89_10).is_empty() { Space::new() } else {
            let v94_6: Path = concat_path(&(v86_3_head),&(v88_6_head));
            let mut v94_11 = Space::new();
            let mut v94_11_cursor = (v88_6_tail).read_zipper();
            for v94_11_byte in v94_11_cursor.child_mask().iter() {
              v94_11_cursor.descend_to_byte(v94_11_byte);
              {
              let v94_11_tail = v94_11_cursor.fork_read_zipper();
              let v94_11_head = Path::from_slice(&[v94_11_byte]);
              let v95_2: Space = singleton(&(v94_11_head));
              let v95_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v95_2));
              let v95_4: Space = if map_kernels::has_head(&(v95_3)) { singleton(&[]) } else { Space::new() };
              drop(v95_3);
              let v95_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v95_4));
              drop(v95_4);
              let v95_8: Space = if (v95_5).is_empty() { Space::new() } else {
                let v96_6: Path = concat_path(&(v94_6),&(v94_11_head));
                let v96_7: Space = routine_2(c, &(v96_6), &(v94_11_tail).make_space(), &((*capture_0)));
                map_map_kernels::compose(&(v95_5),&(v96_7))
              };
              drop(v95_5);
              let v95_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v95_2));
              drop(v95_2);
              let v95_10: Space = if map_kernels::has_head(&(v95_9)) { singleton(&[]) } else { Space::new() };
              drop(v95_9);
              let v95_12: Space = if (v95_10).is_empty() { Space::new() } else {
                let v97_6: Path = concat_path(&(v94_6),&(v94_11_head));
                let v97_11: Space = routine_4(c, &(v97_6), &(v94_11_tail).make_space(), &((*capture_0)));
                drop(v97_6);
                map_map_kernels::compose(&(v95_10),&(v97_11))
              };
              drop(v95_10);
              let v95_13: Space = map_map_kernels::unite(&(v95_8),&(v95_12));
              v94_11.join_into((v95_13).clone());
              }
              v94_11_cursor.ascend(1);
            }
            drop(v94_11_cursor);
            drop(v94_6);
            map_map_kernels::compose(&(v89_10),&(v94_11))
          };
          drop(v89_10);
          let v89_13: Space = map_map_kernels::unite(&(v89_8),&(v89_12));
          v88_6.join_into((v89_13).clone());
          }
          v88_6_cursor.ascend(1);
        }
        drop(v88_6_cursor);
        map_map_kernels::compose(&(v87_5),&(v88_6))
      };
      drop(v87_5);
      let v87_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v87_2));
      drop(v87_2);
      let v87_9: Space = if map_kernels::has_head(&(v87_8)) { singleton(&[]) } else { Space::new() };
      drop(v87_8);
      let v87_11: Space = if (v87_9).is_empty() { Space::new() } else {
        let mut v98_10 = Space::new();
        let mut v98_10_cursor = (v86_3_tail).read_zipper();
        for v98_10_byte in v98_10_cursor.child_mask().iter() {
          v98_10_cursor.descend_to_byte(v98_10_byte);
          {
          let v98_10_tail = v98_10_cursor.fork_read_zipper();
          let v98_10_head = Path::from_slice(&[v98_10_byte]);
          let v99_2: Space = singleton(&(v98_10_head));
          let v99_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v99_2));
          let v99_4: Space = if map_kernels::has_head(&(v99_3)) { singleton(&[]) } else { Space::new() };
          drop(v99_3);
          let v99_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v99_4));
          drop(v99_4);
          let v99_8: Space = if (v99_5).is_empty() { Space::new() } else {
            let v100_6: Path = concat_path(&(v86_3_head),&(v98_10_head));
            let mut v100_7 = Space::new();
            let mut v100_7_cursor = (v98_10_tail).read_zipper();
            for v100_7_byte in v100_7_cursor.child_mask().iter() {
              v100_7_cursor.descend_to_byte(v100_7_byte);
              {
              let v100_7_tail = v100_7_cursor.fork_read_zipper();
              let v100_7_head = Path::from_slice(&[v100_7_byte]);
              let v101_2: Space = singleton(&(v100_7_head));
              let v101_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v101_2));
              let v101_4: Space = if map_kernels::has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
              drop(v101_3);
              let v101_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v101_4));
              drop(v101_4);
              let v101_8: Space = if (v101_5).is_empty() { Space::new() } else {
                let v102_6: Path = concat_path(&(v100_6),&(v100_7_head));
                let v102_7: Space = routine_2(c, &(v102_6), &(v100_7_tail).make_space(), &((*capture_0)));
                map_map_kernels::compose(&(v101_5),&(v102_7))
              };
              drop(v101_5);
              let v101_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v101_2));
              drop(v101_2);
              let v101_10: Space = if map_kernels::has_head(&(v101_9)) { singleton(&[]) } else { Space::new() };
              drop(v101_9);
              let v101_12: Space = if (v101_10).is_empty() { Space::new() } else {
                let v103_6: Path = concat_path(&(v100_6),&(v100_7_head));
                let v103_11: Space = routine_3(c, &(v103_6), &(v100_7_tail).make_space(), &((*capture_0)));
                drop(v103_6);
                map_map_kernels::compose(&(v101_10),&(v103_11))
              };
              drop(v101_10);
              let v101_13: Space = map_map_kernels::unite(&(v101_8),&(v101_12));
              v100_7.join_into((v101_13).clone());
              }
              v100_7_cursor.ascend(1);
            }
            drop(v100_7_cursor);
            map_map_kernels::compose(&(v99_5),&(v100_7))
          };
          drop(v99_5);
          let v99_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v99_2));
          drop(v99_2);
          let v99_10: Space = if map_kernels::has_head(&(v99_9)) { singleton(&[]) } else { Space::new() };
          drop(v99_9);
          let v99_12: Space = if (v99_10).is_empty() { Space::new() } else {
            let mut v104_11 = Space::new();
            let mut v104_11_cursor = (v98_10_tail).read_zipper();
            for v104_11_byte in v104_11_cursor.child_mask().iter() {
              v104_11_cursor.descend_to_byte(v104_11_byte);
              {
              let v104_11_tail = v104_11_cursor.fork_read_zipper();
              let v104_11_head = Path::from_slice(&[v104_11_byte]);
              let v105_2: Space = singleton(&(v104_11_head));
              let v105_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v105_2));
              let v105_4: Space = if map_kernels::has_head(&(v105_3)) { singleton(&[]) } else { Space::new() };
              drop(v105_3);
              let v105_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v105_4));
              drop(v105_4);
              let v105_7: Space = if (v105_5).is_empty() { Space::new() } else {
                let v106_6: Space = routine_5(c, &(v104_11_head), &(v104_11_tail).make_space(), &((*capture_0)));
                map_map_kernels::compose(&(v105_5),&(v106_6))
              };
              drop(v105_5);
              let v105_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v105_2));
              drop(v105_2);
              let v105_9: Space = if map_kernels::has_head(&(v105_8)) { singleton(&[]) } else { Space::new() };
              drop(v105_8);
              let v105_11: Space = if (v105_9).is_empty() { Space::new() } else {
                let v107_10: Space = routine_6(c, &(v104_11_head), &(v104_11_tail).make_space(), &((*capture_0)));
                map_map_kernels::compose(&(v105_9),&(v107_10))
              };
              drop(v105_9);
              let v105_12: Space = map_map_kernels::unite(&(v105_7),&(v105_11));
              v104_11.join_into((v105_12).clone());
              }
              v104_11_cursor.ascend(1);
            }
            drop(v104_11_cursor);
            map_map_kernels::compose(&(v99_10),&(v104_11))
          };
          drop(v99_10);
          let v108_6: Path = concat_path(&(v86_3_head),&(v98_10_head));
          let v99_13: Space = map_kernels::wrap(&(v99_12),&(v108_6));
          let v99_14: Space = map_map_kernels::unite(&(v99_8),&(v99_13));
          v98_10.join_into((v99_14).clone());
          }
          v98_10_cursor.ascend(1);
        }
        drop(v98_10_cursor);
        map_map_kernels::compose(&(v87_9),&(v98_10))
      };
      drop(v87_9);
      let v87_12: Space = map_map_kernels::unite(&(v87_7),&(v87_11));
      v86_3.join_into((v87_12).clone());
      }
      v86_3_cursor.ascend(1);
    }
    drop(v86_3_cursor);
    let mut v86_4 = Space::new();
    let mut v86_4_cursor = (v86_2).read_zipper();
    for v86_4_byte in v86_4_cursor.child_mask().iter() {
      v86_4_cursor.descend_to_byte(v86_4_byte);
      {
      let v86_4_tail = v86_4_cursor.fork_read_zipper();
      let v86_4_head = Path::from_slice(&[v86_4_byte]);
      let v109_2: Space = singleton(&(v86_4_head));
      let v109_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v109_2));
      let v109_4: Space = if map_kernels::has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
      drop(v109_3);
      let v109_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v109_4));
      drop(v109_4);
      let v109_7: Space = if (v109_5).is_empty() { Space::new() } else {
        let mut v110_6 = Space::new();
        let mut v110_6_cursor = (v86_4_tail).read_zipper();
        for v110_6_byte in v110_6_cursor.child_mask().iter() {
          v110_6_cursor.descend_to_byte(v110_6_byte);
          {
          let v110_6_tail = v110_6_cursor.fork_read_zipper();
          let v110_6_head = Path::from_slice(&[v110_6_byte]);
          let v111_2: Space = singleton(&(v110_6_head));
          let v111_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v111_2));
          let v111_4: Space = if map_kernels::has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
          drop(v111_3);
          let v111_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v111_4));
          drop(v111_4);
          let v111_8: Space = if (v111_5).is_empty() { Space::new() } else {
            let v112_6: Path = concat_path(&(v86_4_head),&(v110_6_head));
            let mut v112_7 = Space::new();
            let mut v112_7_cursor = (v110_6_tail).read_zipper();
            for v112_7_byte in v112_7_cursor.child_mask().iter() {
              v112_7_cursor.descend_to_byte(v112_7_byte);
              {
              let v112_7_tail = v112_7_cursor.fork_read_zipper();
              let v112_7_head = Path::from_slice(&[v112_7_byte]);
              let v113_2: Space = singleton(&(v112_7_head));
              let v113_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v113_2));
              let v113_4: Space = if map_kernels::has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
              drop(v113_3);
              let v113_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v113_4));
              drop(v113_4);
              let v113_8: Space = if (v113_5).is_empty() { Space::new() } else {
                let v114_6: Path = concat_path(&(v112_6),&(v112_7_head));
                let v114_7: Space = routine_7(c, &(v114_6), &(v112_7_tail).make_space(), &((*capture_0)));
                map_map_kernels::compose(&(v113_5),&(v114_7))
              };
              drop(v113_5);
              let v113_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v113_2));
              drop(v113_2);
              let v113_10: Space = if map_kernels::has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
              drop(v113_9);
              let v113_12: Space = if (v113_10).is_empty() { Space::new() } else {
                let v115_6: Path = concat_path(&(v112_6),&(v112_7_head));
                let v115_11: Space = routine_8(c, &(v115_6), &(v112_7_tail).make_space(), &((*capture_0)));
                drop(v115_6);
                map_map_kernels::compose(&(v113_10),&(v115_11))
              };
              drop(v113_10);
              let v113_13: Space = map_map_kernels::unite(&(v113_8),&(v113_12));
              v112_7.join_into((v113_13).clone());
              }
              v112_7_cursor.ascend(1);
            }
            drop(v112_7_cursor);
            map_map_kernels::compose(&(v111_5),&(v112_7))
          };
          drop(v111_5);
          let v111_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v111_2));
          drop(v111_2);
          let v111_10: Space = if map_kernels::has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
          drop(v111_9);
          let v111_12: Space = if (v111_10).is_empty() { Space::new() } else {
            let v116_6: Path = concat_path(&(v86_4_head),&(v110_6_head));
            let mut v116_11 = Space::new();
            let mut v116_11_cursor = (v110_6_tail).read_zipper();
            for v116_11_byte in v116_11_cursor.child_mask().iter() {
              v116_11_cursor.descend_to_byte(v116_11_byte);
              {
              let v116_11_tail = v116_11_cursor.fork_read_zipper();
              let v116_11_head = Path::from_slice(&[v116_11_byte]);
              let v117_2: Space = singleton(&(v116_11_head));
              let v117_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v117_2));
              let v117_4: Space = if map_kernels::has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
              drop(v117_3);
              let v117_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v117_4));
              drop(v117_4);
              let v117_8: Space = if (v117_5).is_empty() { Space::new() } else {
                let v118_6: Path = concat_path(&(v116_6),&(v116_11_head));
                let v118_7: Space = routine_7(c, &(v118_6), &(v116_11_tail).make_space(), &((*capture_0)));
                map_map_kernels::compose(&(v117_5),&(v118_7))
              };
              drop(v117_5);
              let v117_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v117_2));
              drop(v117_2);
              let v117_10: Space = if map_kernels::has_head(&(v117_9)) { singleton(&[]) } else { Space::new() };
              drop(v117_9);
              let v117_12: Space = if (v117_10).is_empty() { Space::new() } else {
                let v119_6: Path = concat_path(&(v116_6),&(v116_11_head));
                let v119_11: Space = routine_9(c, &(v119_6), &(v116_11_tail).make_space(), &((*capture_0)));
                drop(v119_6);
                map_map_kernels::compose(&(v117_10),&(v119_11))
              };
              drop(v117_10);
              let v117_13: Space = map_map_kernels::unite(&(v117_8),&(v117_12));
              v116_11.join_into((v117_13).clone());
              }
              v116_11_cursor.ascend(1);
            }
            drop(v116_11_cursor);
            drop(v116_6);
            map_map_kernels::compose(&(v111_10),&(v116_11))
          };
          drop(v111_10);
          let v111_13: Space = map_map_kernels::unite(&(v111_8),&(v111_12));
          v110_6.join_into((v111_13).clone());
          }
          v110_6_cursor.ascend(1);
        }
        drop(v110_6_cursor);
        map_map_kernels::compose(&(v109_5),&(v110_6))
      };
      drop(v109_5);
      let v109_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v109_2));
      drop(v109_2);
      let v109_9: Space = if map_kernels::has_head(&(v109_8)) { singleton(&[]) } else { Space::new() };
      drop(v109_8);
      let v109_11: Space = if (v109_9).is_empty() { Space::new() } else {
        let mut v120_10 = Space::new();
        let mut v120_10_cursor = (v86_4_tail).read_zipper();
        for v120_10_byte in v120_10_cursor.child_mask().iter() {
          v120_10_cursor.descend_to_byte(v120_10_byte);
          {
          let v120_10_tail = v120_10_cursor.fork_read_zipper();
          let v120_10_head = Path::from_slice(&[v120_10_byte]);
          let v121_2: Space = singleton(&(v120_10_head));
          let v121_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v121_2));
          let v121_4: Space = if map_kernels::has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
          drop(v121_3);
          let v121_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v121_4));
          drop(v121_4);
          let v121_8: Space = if (v121_5).is_empty() { Space::new() } else {
            let v122_6: Path = concat_path(&(v86_4_head),&(v120_10_head));
            let mut v122_7 = Space::new();
            let mut v122_7_cursor = (v120_10_tail).read_zipper();
            for v122_7_byte in v122_7_cursor.child_mask().iter() {
              v122_7_cursor.descend_to_byte(v122_7_byte);
              {
              let v122_7_tail = v122_7_cursor.fork_read_zipper();
              let v122_7_head = Path::from_slice(&[v122_7_byte]);
              let v123_2: Space = singleton(&(v122_7_head));
              let v123_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v123_2));
              let v123_4: Space = if map_kernels::has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
              drop(v123_3);
              let v123_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v123_4));
              drop(v123_4);
              let v123_8: Space = if (v123_5).is_empty() { Space::new() } else {
                let v124_6: Path = concat_path(&(v122_6),&(v122_7_head));
                let v124_7: Space = routine_7(c, &(v124_6), &(v122_7_tail).make_space(), &((*capture_0)));
                map_map_kernels::compose(&(v123_5),&(v124_7))
              };
              drop(v123_5);
              let v123_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v123_2));
              drop(v123_2);
              let v123_10: Space = if map_kernels::has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
              drop(v123_9);
              let v123_12: Space = if (v123_10).is_empty() { Space::new() } else {
                let v125_6: Path = concat_path(&(v122_6),&(v122_7_head));
                let v125_11: Space = routine_8(c, &(v125_6), &(v122_7_tail).make_space(), &((*capture_0)));
                drop(v125_6);
                map_map_kernels::compose(&(v123_10),&(v125_11))
              };
              drop(v123_10);
              let v123_13: Space = map_map_kernels::unite(&(v123_8),&(v123_12));
              v122_7.join_into((v123_13).clone());
              }
              v122_7_cursor.ascend(1);
            }
            drop(v122_7_cursor);
            map_map_kernels::compose(&(v121_5),&(v122_7))
          };
          drop(v121_5);
          let v121_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v121_2));
          drop(v121_2);
          let v121_10: Space = if map_kernels::has_head(&(v121_9)) { singleton(&[]) } else { Space::new() };
          drop(v121_9);
          let v121_12: Space = if (v121_10).is_empty() { Space::new() } else {
            let mut v126_11 = Space::new();
            let mut v126_11_cursor = (v120_10_tail).read_zipper();
            for v126_11_byte in v126_11_cursor.child_mask().iter() {
              v126_11_cursor.descend_to_byte(v126_11_byte);
              {
              let v126_11_tail = v126_11_cursor.fork_read_zipper();
              let v126_11_head = Path::from_slice(&[v126_11_byte]);
              let v127_2: Space = singleton(&(v126_11_head));
              let v127_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v127_2));
              let v127_4: Space = if map_kernels::has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
              drop(v127_3);
              let v127_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v127_4));
              drop(v127_4);
              let v127_7: Space = if (v127_5).is_empty() { Space::new() } else {
                let v128_6: Space = routine_10(c, &(v126_11_head), &(v126_11_tail).make_space(), &((*capture_0)));
                map_map_kernels::compose(&(v127_5),&(v128_6))
              };
              drop(v127_5);
              let v127_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v127_2));
              drop(v127_2);
              let v127_9: Space = if map_kernels::has_head(&(v127_8)) { singleton(&[]) } else { Space::new() };
              drop(v127_8);
              let v127_11: Space = if (v127_9).is_empty() { Space::new() } else {
                let v129_10: Space = routine_11(c, &(v126_11_head), &(v126_11_tail).make_space(), &((*capture_0)));
                map_map_kernels::compose(&(v127_9),&(v129_10))
              };
              drop(v127_9);
              let v127_12: Space = map_map_kernels::unite(&(v127_7),&(v127_11));
              v126_11.join_into((v127_12).clone());
              }
              v126_11_cursor.ascend(1);
            }
            drop(v126_11_cursor);
            map_map_kernels::compose(&(v121_10),&(v126_11))
          };
          drop(v121_10);
          let v130_6: Path = concat_path(&(v86_4_head),&(v120_10_head));
          let v121_13: Space = map_kernels::wrap(&(v121_12),&(v130_6));
          let v121_14: Space = map_map_kernels::unite(&(v121_8),&(v121_13));
          v120_10.join_into((v121_14).clone());
          }
          v120_10_cursor.ascend(1);
        }
        drop(v120_10_cursor);
        map_map_kernels::compose(&(v109_9),&(v120_10))
      };
      drop(v109_9);
      let v109_12: Space = map_map_kernels::unite(&(v109_7),&(v109_11));
      v86_4.join_into((v109_12).clone());
      }
      v86_4_cursor.ascend(1);
    }
    drop(v86_4_cursor);
    drop(v86_2);
    let v86_5: Space = map_map_kernels::unite(&(v86_3),&(v86_4));
    let v86_6: Space = map_kernels::unwrap(&((*capture_0)),&(*CONSTANT_7));
    let v86_7: Space = map_kernels::unwrap(&(v86_6),&(*CONSTANT_8));
    let mut v86_8 = Space::new();
    let mut v86_8_cursor = (v86_7).read_zipper();
    for v86_8_byte in v86_8_cursor.child_mask().iter() {
      v86_8_cursor.descend_to_byte(v86_8_byte);
      {
      let v86_8_tail = v86_8_cursor.fork_read_zipper();
      let v86_8_head = Path::from_slice(&[v86_8_byte]);
      let v131_2: Space = singleton(&(v86_8_head));
      let v131_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v131_2));
      let v131_4: Space = if map_kernels::has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
      drop(v131_3);
      let v131_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v131_4));
      drop(v131_4);
      let v131_7: Space = if (v131_5).is_empty() { Space::new() } else {
        let mut v132_6 = Space::new();
        let mut v132_6_cursor = (v86_8_tail).read_zipper();
        for v132_6_byte in v132_6_cursor.child_mask().iter() {
          v132_6_cursor.descend_to_byte(v132_6_byte);
          {
          let v132_6_tail = v132_6_cursor.fork_read_zipper();
          let v132_6_head = Path::from_slice(&[v132_6_byte]);
          let v133_2: Space = singleton(&(v132_6_head));
          let v133_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v133_2));
          let v133_4: Space = if map_kernels::has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
          drop(v133_3);
          let v133_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v133_4));
          drop(v133_4);
          let v133_8: Space = if (v133_5).is_empty() { Space::new() } else {
            let v134_6: Path = concat_path(&(v86_8_head),&(v132_6_head));
            let mut v134_7 = Space::new();
            let mut v134_7_cursor = (v132_6_tail).read_zipper();
            for v134_7_byte in v134_7_cursor.child_mask().iter() {
              v134_7_cursor.descend_to_byte(v134_7_byte);
              {
              let v134_7_tail = v134_7_cursor.fork_read_zipper();
              let v134_7_head = Path::from_slice(&[v134_7_byte]);
              let v135_2: Space = singleton(&(v134_7_head));
              let v135_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v135_2));
              let v135_4: Space = if map_kernels::has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
              drop(v135_3);
              let v135_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v135_4));
              drop(v135_4);
              let v135_8: Space = if (v135_5).is_empty() { Space::new() } else {
                let v136_6: Path = concat_path(&(v134_6),&(v134_7_head));
                let v136_7: Space = routine_12(c, &(v136_6), &(v134_7_tail).make_space());
                map_map_kernels::compose(&(v135_5),&(v136_7))
              };
              drop(v135_5);
              let v135_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v135_2));
              drop(v135_2);
              let v135_10: Space = if map_kernels::has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
              drop(v135_9);
              let v135_12: Space = if (v135_10).is_empty() { Space::new() } else {
                let v137_6: Path = concat_path(&(v134_6),&(v134_7_head));
                let v137_11: Space = routine_13(c, &(v137_6), &(v134_7_tail).make_space());
                drop(v137_6);
                map_map_kernels::compose(&(v135_10),&(v137_11))
              };
              drop(v135_10);
              let v135_13: Space = map_map_kernels::unite(&(v135_8),&(v135_12));
              v134_7.join_into((v135_13).clone());
              }
              v134_7_cursor.ascend(1);
            }
            drop(v134_7_cursor);
            map_map_kernels::compose(&(v133_5),&(v134_7))
          };
          drop(v133_5);
          let v133_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v133_2));
          drop(v133_2);
          let v133_10: Space = if map_kernels::has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
          drop(v133_9);
          let v133_12: Space = if (v133_10).is_empty() { Space::new() } else {
            let v138_6: Path = concat_path(&(v86_8_head),&(v132_6_head));
            let mut v138_11 = Space::new();
            let mut v138_11_cursor = (v132_6_tail).read_zipper();
            for v138_11_byte in v138_11_cursor.child_mask().iter() {
              v138_11_cursor.descend_to_byte(v138_11_byte);
              {
              let v138_11_tail = v138_11_cursor.fork_read_zipper();
              let v138_11_head = Path::from_slice(&[v138_11_byte]);
              let v139_2: Space = singleton(&(v138_11_head));
              let v139_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v139_2));
              let v139_4: Space = if map_kernels::has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
              drop(v139_3);
              let v139_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v139_4));
              drop(v139_4);
              let v139_8: Space = if (v139_5).is_empty() { Space::new() } else {
                let v140_6: Path = concat_path(&(v138_6),&(v138_11_head));
                let v140_7: Space = routine_12(c, &(v140_6), &(v138_11_tail).make_space());
                map_map_kernels::compose(&(v139_5),&(v140_7))
              };
              drop(v139_5);
              let v139_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v139_2));
              drop(v139_2);
              let v139_10: Space = if map_kernels::has_head(&(v139_9)) { singleton(&[]) } else { Space::new() };
              drop(v139_9);
              let v139_12: Space = if (v139_10).is_empty() { Space::new() } else {
                let v141_6: Path = concat_path(&(v138_6),&(v138_11_head));
                let v141_11: Space = routine_14(c, &(v141_6), &(v138_11_tail).make_space());
                drop(v141_6);
                map_map_kernels::compose(&(v139_10),&(v141_11))
              };
              drop(v139_10);
              let v139_13: Space = map_map_kernels::unite(&(v139_8),&(v139_12));
              v138_11.join_into((v139_13).clone());
              }
              v138_11_cursor.ascend(1);
            }
            drop(v138_11_cursor);
            drop(v138_6);
            map_map_kernels::compose(&(v133_10),&(v138_11))
          };
          drop(v133_10);
          let v133_13: Space = map_map_kernels::unite(&(v133_8),&(v133_12));
          v132_6.join_into((v133_13).clone());
          }
          v132_6_cursor.ascend(1);
        }
        drop(v132_6_cursor);
        map_map_kernels::compose(&(v131_5),&(v132_6))
      };
      drop(v131_5);
      let v131_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v131_2));
      drop(v131_2);
      let v131_9: Space = if map_kernels::has_head(&(v131_8)) { singleton(&[]) } else { Space::new() };
      drop(v131_8);
      let v131_11: Space = if (v131_9).is_empty() { Space::new() } else {
        let mut v142_10 = Space::new();
        let mut v142_10_cursor = (v86_8_tail).read_zipper();
        for v142_10_byte in v142_10_cursor.child_mask().iter() {
          v142_10_cursor.descend_to_byte(v142_10_byte);
          {
          let v142_10_tail = v142_10_cursor.fork_read_zipper();
          let v142_10_head = Path::from_slice(&[v142_10_byte]);
          let v143_2: Space = singleton(&(v142_10_head));
          let v143_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v143_2));
          let v143_4: Space = if map_kernels::has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
          drop(v143_3);
          let v143_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v143_4));
          drop(v143_4);
          let v143_8: Space = if (v143_5).is_empty() { Space::new() } else {
            let v144_6: Path = concat_path(&(v86_8_head),&(v142_10_head));
            let mut v144_7 = Space::new();
            let mut v144_7_cursor = (v142_10_tail).read_zipper();
            for v144_7_byte in v144_7_cursor.child_mask().iter() {
              v144_7_cursor.descend_to_byte(v144_7_byte);
              {
              let v144_7_tail = v144_7_cursor.fork_read_zipper();
              let v144_7_head = Path::from_slice(&[v144_7_byte]);
              let v145_2: Space = singleton(&(v144_7_head));
              let v145_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v145_2));
              let v145_4: Space = if map_kernels::has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
              drop(v145_3);
              let v145_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v145_4));
              drop(v145_4);
              let v145_8: Space = if (v145_5).is_empty() { Space::new() } else {
                let v146_6: Path = concat_path(&(v144_6),&(v144_7_head));
                let v146_7: Space = routine_12(c, &(v146_6), &(v144_7_tail).make_space());
                map_map_kernels::compose(&(v145_5),&(v146_7))
              };
              drop(v145_5);
              let v145_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v145_2));
              drop(v145_2);
              let v145_10: Space = if map_kernels::has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
              drop(v145_9);
              let v145_12: Space = if (v145_10).is_empty() { Space::new() } else {
                let v147_6: Path = concat_path(&(v144_6),&(v144_7_head));
                let v147_11: Space = routine_13(c, &(v147_6), &(v144_7_tail).make_space());
                drop(v147_6);
                map_map_kernels::compose(&(v145_10),&(v147_11))
              };
              drop(v145_10);
              let v145_13: Space = map_map_kernels::unite(&(v145_8),&(v145_12));
              v144_7.join_into((v145_13).clone());
              }
              v144_7_cursor.ascend(1);
            }
            drop(v144_7_cursor);
            map_map_kernels::compose(&(v143_5),&(v144_7))
          };
          drop(v143_5);
          let v143_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v143_2));
          drop(v143_2);
          let v143_10: Space = if map_kernels::has_head(&(v143_9)) { singleton(&[]) } else { Space::new() };
          drop(v143_9);
          let v143_11: Space = view_map_kernels::subtract(&(v142_10_tail),&(*CONSTANT_5));
          let v143_12: Space = map_map_kernels::compose(&(v143_10),&(v143_11));
          drop(v143_10);
          drop(v143_11);
          let v148_6: Path = concat_path(&(v86_8_head),&(v142_10_head));
          let v143_13: Space = map_kernels::wrap(&(v143_12),&(v148_6));
          drop(v143_12);
          let v143_14: Space = map_map_kernels::unite(&(v143_8),&(v143_13));
          drop(v143_13);
          v142_10.join_into((v143_14).clone());
          }
          v142_10_cursor.ascend(1);
        }
        drop(v142_10_cursor);
        map_map_kernels::compose(&(v131_9),&(v142_10))
      };
      drop(v131_9);
      let v131_12: Space = map_map_kernels::unite(&(v131_7),&(v131_11));
      v86_8.join_into((v131_12).clone());
      }
      v86_8_cursor.ascend(1);
    }
    drop(v86_8_cursor);
    drop(v86_7);

((v86_1).clone(),(v86_3).clone(),(v86_4).clone(),(v86_5).clone(),(v86_6).clone(),(v86_8).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_2: Space = routine_1(c, &(*CONSTANT_1));
  let v0_3: Space = map_map_kernels::unite(&(*CONSTANT_0),&(v0_2));
  let v0_5: Space = map_kernels::unwrap(&(v0_3),&(*CONSTANT_2));
  (v0_5).clone()
}

fn routine_1(c: &mut Context, s0: &Space) -> Space {
  let (v1_2,v1_26,v1_48,v1_49,v1_51,v1_73,) = native_block_0(c, s0);
  let v1_74: Space = map_map_kernels::unite(&(v1_49),&(v1_73));
  let v1_75: Space = map_kernels::unwrap(&(v1_51),&(*CONSTANT_4));
  let mut v1_97 = Space::new();
  let mut v1_97_cursor = (v1_75).read_zipper();
  for v1_97_byte in v1_97_cursor.child_mask().iter() {
    v1_97_cursor.descend_to_byte(v1_97_byte);
    {
    let v1_97_tail = v1_97_cursor.fork_read_zipper();
    let v1_97_head = Path::from_slice(&[v1_97_byte]);
    let v64_2: Space = singleton(&(v1_97_head));
    let v64_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v64_2));
    let v64_4: Space = if map_kernels::has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
    drop(v64_3);
    let v64_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v64_4));
    drop(v64_4);
    let v64_7: Space = if (v64_5).is_empty() { Space::new() } else {
      let mut v65_6 = Space::new();
      let mut v65_6_cursor = (v1_97_tail).read_zipper();
      for v65_6_byte in v65_6_cursor.child_mask().iter() {
        v65_6_cursor.descend_to_byte(v65_6_byte);
        {
        let v65_6_tail = v65_6_cursor.fork_read_zipper();
        let v65_6_head = Path::from_slice(&[v65_6_byte]);
        let v66_2: Space = singleton(&(v65_6_head));
        let v66_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v66_2));
        let v66_4: Space = if map_kernels::has_head(&(v66_3)) { singleton(&[]) } else { Space::new() };
        drop(v66_3);
        let v66_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v66_4));
        drop(v66_4);
        let v66_8: Space = if (v66_5).is_empty() { Space::new() } else {
          let v67_6: Path = concat_path(&(v1_97_head),&(v65_6_head));
          let mut v67_7 = Space::new();
          let mut v67_7_cursor = (v65_6_tail).read_zipper();
          for v67_7_byte in v67_7_cursor.child_mask().iter() {
            v67_7_cursor.descend_to_byte(v67_7_byte);
            {
            let v67_7_tail = v67_7_cursor.fork_read_zipper();
            let v67_7_head = Path::from_slice(&[v67_7_byte]);
            let v68_2: Space = singleton(&(v67_7_head));
            let v68_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v68_2));
            let v68_4: Space = if map_kernels::has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
            drop(v68_3);
            let v68_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v68_4));
            drop(v68_4);
            let v68_8: Space = if (v68_5).is_empty() { Space::new() } else {
              let v69_6: Path = concat_path(&(v67_6),&(v67_7_head));
              let v69_7: Space = routine_15(c, &(v69_6), &(v67_7_tail).make_space(), &(*s0));
              map_map_kernels::compose(&(v68_5),&(v69_7))
            };
            drop(v68_5);
            let v68_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v68_2));
            drop(v68_2);
            let v68_10: Space = if map_kernels::has_head(&(v68_9)) { singleton(&[]) } else { Space::new() };
            drop(v68_9);
            let v68_12: Space = if (v68_10).is_empty() { Space::new() } else {
              let v70_6: Path = concat_path(&(v67_6),&(v67_7_head));
              let v70_11: Space = routine_16(c, &(v70_6), &(v67_7_tail).make_space(), &(*s0));
              drop(v70_6);
              map_map_kernels::compose(&(v68_10),&(v70_11))
            };
            drop(v68_10);
            let v68_13: Space = map_map_kernels::unite(&(v68_8),&(v68_12));
            v67_7.join_into((v68_13).clone());
            }
            v67_7_cursor.ascend(1);
          }
          drop(v67_7_cursor);
          map_map_kernels::compose(&(v66_5),&(v67_7))
        };
        drop(v66_5);
        let v66_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v66_2));
        drop(v66_2);
        let v66_10: Space = if map_kernels::has_head(&(v66_9)) { singleton(&[]) } else { Space::new() };
        drop(v66_9);
        let v66_12: Space = if (v66_10).is_empty() { Space::new() } else {
          let v71_6: Path = concat_path(&(v1_97_head),&(v65_6_head));
          let mut v71_11 = Space::new();
          let mut v71_11_cursor = (v65_6_tail).read_zipper();
          for v71_11_byte in v71_11_cursor.child_mask().iter() {
            v71_11_cursor.descend_to_byte(v71_11_byte);
            {
            let v71_11_tail = v71_11_cursor.fork_read_zipper();
            let v71_11_head = Path::from_slice(&[v71_11_byte]);
            let v72_2: Space = singleton(&(v71_11_head));
            let v72_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v72_2));
            let v72_4: Space = if map_kernels::has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
            drop(v72_3);
            let v72_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v72_4));
            drop(v72_4);
            let v72_8: Space = if (v72_5).is_empty() { Space::new() } else {
              let v73_6: Path = concat_path(&(v71_6),&(v71_11_head));
              let v73_7: Space = routine_15(c, &(v73_6), &(v71_11_tail).make_space(), &(*s0));
              map_map_kernels::compose(&(v72_5),&(v73_7))
            };
            drop(v72_5);
            let v72_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v72_2));
            drop(v72_2);
            let v72_10: Space = if map_kernels::has_head(&(v72_9)) { singleton(&[]) } else { Space::new() };
            drop(v72_9);
            let v72_12: Space = if (v72_10).is_empty() { Space::new() } else {
              let v74_6: Path = concat_path(&(v71_6),&(v71_11_head));
              let v74_11: Space = routine_17(c, &(v74_6), &(v71_11_tail).make_space(), &(*s0));
              drop(v74_6);
              map_map_kernels::compose(&(v72_10),&(v74_11))
            };
            drop(v72_10);
            let v72_13: Space = map_map_kernels::unite(&(v72_8),&(v72_12));
            v71_11.join_into((v72_13).clone());
            }
            v71_11_cursor.ascend(1);
          }
          drop(v71_11_cursor);
          drop(v71_6);
          map_map_kernels::compose(&(v66_10),&(v71_11))
        };
        drop(v66_10);
        let v66_13: Space = map_map_kernels::unite(&(v66_8),&(v66_12));
        v65_6.join_into((v66_13).clone());
        }
        v65_6_cursor.ascend(1);
      }
      drop(v65_6_cursor);
      map_map_kernels::compose(&(v64_5),&(v65_6))
    };
    drop(v64_5);
    let v64_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v64_2));
    drop(v64_2);
    let v64_9: Space = if map_kernels::has_head(&(v64_8)) { singleton(&[]) } else { Space::new() };
    drop(v64_8);
    let v64_11: Space = if (v64_9).is_empty() { Space::new() } else {
      let mut v75_10 = Space::new();
      let mut v75_10_cursor = (v1_97_tail).read_zipper();
      for v75_10_byte in v75_10_cursor.child_mask().iter() {
        v75_10_cursor.descend_to_byte(v75_10_byte);
        {
        let v75_10_tail = v75_10_cursor.fork_read_zipper();
        let v75_10_head = Path::from_slice(&[v75_10_byte]);
        let v76_2: Space = singleton(&(v75_10_head));
        let v76_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v76_2));
        let v76_4: Space = if map_kernels::has_head(&(v76_3)) { singleton(&[]) } else { Space::new() };
        drop(v76_3);
        let v76_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v76_4));
        drop(v76_4);
        let v76_8: Space = if (v76_5).is_empty() { Space::new() } else {
          let v77_6: Path = concat_path(&(v1_97_head),&(v75_10_head));
          let mut v77_7 = Space::new();
          let mut v77_7_cursor = (v75_10_tail).read_zipper();
          for v77_7_byte in v77_7_cursor.child_mask().iter() {
            v77_7_cursor.descend_to_byte(v77_7_byte);
            {
            let v77_7_tail = v77_7_cursor.fork_read_zipper();
            let v77_7_head = Path::from_slice(&[v77_7_byte]);
            let v78_2: Space = singleton(&(v77_7_head));
            let v78_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v78_2));
            let v78_4: Space = if map_kernels::has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
            drop(v78_3);
            let v78_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v78_4));
            drop(v78_4);
            let v78_8: Space = if (v78_5).is_empty() { Space::new() } else {
              let v79_6: Path = concat_path(&(v77_6),&(v77_7_head));
              let v79_7: Space = routine_15(c, &(v79_6), &(v77_7_tail).make_space(), &(*s0));
              map_map_kernels::compose(&(v78_5),&(v79_7))
            };
            drop(v78_5);
            let v78_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v78_2));
            drop(v78_2);
            let v78_10: Space = if map_kernels::has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
            drop(v78_9);
            let v78_12: Space = if (v78_10).is_empty() { Space::new() } else {
              let v80_6: Path = concat_path(&(v77_6),&(v77_7_head));
              let v80_11: Space = routine_16(c, &(v80_6), &(v77_7_tail).make_space(), &(*s0));
              drop(v80_6);
              map_map_kernels::compose(&(v78_10),&(v80_11))
            };
            drop(v78_10);
            let v78_13: Space = map_map_kernels::unite(&(v78_8),&(v78_12));
            v77_7.join_into((v78_13).clone());
            }
            v77_7_cursor.ascend(1);
          }
          drop(v77_7_cursor);
          map_map_kernels::compose(&(v76_5),&(v77_7))
        };
        drop(v76_5);
        let v76_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v76_2));
        drop(v76_2);
        let v76_10: Space = if map_kernels::has_head(&(v76_9)) { singleton(&[]) } else { Space::new() };
        drop(v76_9);
        let v76_12: Space = if (v76_10).is_empty() { Space::new() } else {
          let mut v81_11 = Space::new();
          let mut v81_11_cursor = (v75_10_tail).read_zipper();
          for v81_11_byte in v81_11_cursor.child_mask().iter() {
            v81_11_cursor.descend_to_byte(v81_11_byte);
            {
            let v81_11_tail = v81_11_cursor.fork_read_zipper();
            let v81_11_head = Path::from_slice(&[v81_11_byte]);
            let v82_2: Space = singleton(&(v81_11_head));
            let v82_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v82_2));
            let v82_4: Space = if map_kernels::has_head(&(v82_3)) { singleton(&[]) } else { Space::new() };
            drop(v82_3);
            let v82_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v82_4));
            drop(v82_4);
            let v82_7: Space = if (v82_5).is_empty() { Space::new() } else {
              let v83_6: Space = routine_18(c, &(v81_11_head), &(v81_11_tail).make_space(), &(*s0));
              map_map_kernels::compose(&(v82_5),&(v83_6))
            };
            drop(v82_5);
            let v82_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v82_2));
            drop(v82_2);
            let v82_9: Space = if map_kernels::has_head(&(v82_8)) { singleton(&[]) } else { Space::new() };
            drop(v82_8);
            let v82_11: Space = if (v82_9).is_empty() { Space::new() } else {
              let v84_10: Space = routine_19(c, &(v81_11_head), &(v81_11_tail).make_space(), &(*s0));
              map_map_kernels::compose(&(v82_9),&(v84_10))
            };
            drop(v82_9);
            let v82_12: Space = map_map_kernels::unite(&(v82_7),&(v82_11));
            v81_11.join_into((v82_12).clone());
            }
            v81_11_cursor.ascend(1);
          }
          drop(v81_11_cursor);
          map_map_kernels::compose(&(v76_10),&(v81_11))
        };
        drop(v76_10);
        let v85_6: Path = concat_path(&(v1_97_head),&(v75_10_head));
        let v76_13: Space = map_kernels::wrap(&(v76_12),&(v85_6));
        let v76_14: Space = map_map_kernels::unite(&(v76_8),&(v76_13));
        v75_10.join_into((v76_14).clone());
        }
        v75_10_cursor.ascend(1);
      }
      drop(v75_10_cursor);
      map_map_kernels::compose(&(v64_9),&(v75_10))
    };
    drop(v64_9);
    let v64_12: Space = map_map_kernels::unite(&(v64_7),&(v64_11));
    v1_97.join_into((v64_12).clone());
    }
    v1_97_cursor.ascend(1);
  }
  drop(v1_97_cursor);
  drop(v1_75);
  let v1_98: Space = map_map_kernels::unite(&(v1_74),&(v1_97));
  let v1_100: Space = map_kernels::unwrap(&(*s0),&(*CONSTANT_2));
  let v1_101: Space = map_map_kernels::subtract(&(v1_98),&(v1_100));
  drop(v1_100);
  let v1_103: Space = map_kernels::unwrap(&(*s0),&(*CONSTANT_9));
  let v1_104: Space = map_map_kernels::subtract(&(v1_101),&(v1_103));
  drop(v1_103);
  let v1_105: Space = map_kernels::wrap(&(v1_104),&(*CONSTANT_9));
  let v1_106: Space = map_map_kernels::unite(&(v1_2),&(v1_51));
  drop(v1_2);
  drop(v1_51);
  let v1_107: Space = map_kernels::wrap(&(v1_106),&(*CONSTANT_7));
  drop(v1_106);
  let v1_108: Space = map_map_kernels::unite(&(v1_105),&(v1_107));
  drop(v1_107);
  let v1_109: Space = map_map_kernels::unite(&(v1_108),&(*s0));
  let mut v1_192: Space = (v1_109).clone();
  loop {
    let (v86_1,v86_3,v86_4,v86_5,v86_6,v86_8,) = native_block_1(c, &v1_192);
    let v86_9: Space = map_map_kernels::unite(&(v86_5),&(v86_8));
    let v86_10: Space = map_kernels::unwrap(&(v86_6),&(*CONSTANT_4));
    let mut v86_11 = Space::new();
    let mut v86_11_cursor = (v86_10).read_zipper();
    for v86_11_byte in v86_11_cursor.child_mask().iter() {
      v86_11_cursor.descend_to_byte(v86_11_byte);
      {
      let v86_11_tail = v86_11_cursor.fork_read_zipper();
      let v86_11_head = Path::from_slice(&[v86_11_byte]);
      let v149_2: Space = singleton(&(v86_11_head));
      let v149_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v149_2));
      let v149_4: Space = if map_kernels::has_head(&(v149_3)) { singleton(&[]) } else { Space::new() };
      drop(v149_3);
      let v149_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v149_4));
      drop(v149_4);
      let v149_7: Space = if (v149_5).is_empty() { Space::new() } else {
        let mut v150_6 = Space::new();
        let mut v150_6_cursor = (v86_11_tail).read_zipper();
        for v150_6_byte in v150_6_cursor.child_mask().iter() {
          v150_6_cursor.descend_to_byte(v150_6_byte);
          {
          let v150_6_tail = v150_6_cursor.fork_read_zipper();
          let v150_6_head = Path::from_slice(&[v150_6_byte]);
          let v151_2: Space = singleton(&(v150_6_head));
          let v151_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v151_2));
          let v151_4: Space = if map_kernels::has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
          drop(v151_3);
          let v151_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v151_4));
          drop(v151_4);
          let v151_8: Space = if (v151_5).is_empty() { Space::new() } else {
            let v152_6: Path = concat_path(&(v86_11_head),&(v150_6_head));
            let mut v152_7 = Space::new();
            let mut v152_7_cursor = (v150_6_tail).read_zipper();
            for v152_7_byte in v152_7_cursor.child_mask().iter() {
              v152_7_cursor.descend_to_byte(v152_7_byte);
              {
              let v152_7_tail = v152_7_cursor.fork_read_zipper();
              let v152_7_head = Path::from_slice(&[v152_7_byte]);
              let v153_2: Space = singleton(&(v152_7_head));
              let v153_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v153_2));
              let v153_4: Space = if map_kernels::has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
              drop(v153_3);
              let v153_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v153_4));
              drop(v153_4);
              let v153_8: Space = if (v153_5).is_empty() { Space::new() } else {
                let v154_6: Path = concat_path(&(v152_6),&(v152_7_head));
                let v154_7: Space = routine_15(c, &(v154_6), &(v152_7_tail).make_space(), &(v1_192));
                map_map_kernels::compose(&(v153_5),&(v154_7))
              };
              drop(v153_5);
              let v153_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v153_2));
              drop(v153_2);
              let v153_10: Space = if map_kernels::has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
              drop(v153_9);
              let v153_12: Space = if (v153_10).is_empty() { Space::new() } else {
                let v155_6: Path = concat_path(&(v152_6),&(v152_7_head));
                let v155_11: Space = routine_16(c, &(v155_6), &(v152_7_tail).make_space(), &(v1_192));
                drop(v155_6);
                map_map_kernels::compose(&(v153_10),&(v155_11))
              };
              drop(v153_10);
              let v153_13: Space = map_map_kernels::unite(&(v153_8),&(v153_12));
              v152_7.join_into((v153_13).clone());
              }
              v152_7_cursor.ascend(1);
            }
            drop(v152_7_cursor);
            map_map_kernels::compose(&(v151_5),&(v152_7))
          };
          drop(v151_5);
          let v151_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v151_2));
          drop(v151_2);
          let v151_10: Space = if map_kernels::has_head(&(v151_9)) { singleton(&[]) } else { Space::new() };
          drop(v151_9);
          let v151_12: Space = if (v151_10).is_empty() { Space::new() } else {
            let v156_6: Path = concat_path(&(v86_11_head),&(v150_6_head));
            let mut v156_11 = Space::new();
            let mut v156_11_cursor = (v150_6_tail).read_zipper();
            for v156_11_byte in v156_11_cursor.child_mask().iter() {
              v156_11_cursor.descend_to_byte(v156_11_byte);
              {
              let v156_11_tail = v156_11_cursor.fork_read_zipper();
              let v156_11_head = Path::from_slice(&[v156_11_byte]);
              let v157_2: Space = singleton(&(v156_11_head));
              let v157_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v157_2));
              let v157_4: Space = if map_kernels::has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
              drop(v157_3);
              let v157_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v157_4));
              drop(v157_4);
              let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
                let v158_6: Path = concat_path(&(v156_6),&(v156_11_head));
                let v158_7: Space = routine_15(c, &(v158_6), &(v156_11_tail).make_space(), &(v1_192));
                map_map_kernels::compose(&(v157_5),&(v158_7))
              };
              drop(v157_5);
              let v157_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v157_2));
              drop(v157_2);
              let v157_10: Space = if map_kernels::has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
              drop(v157_9);
              let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
                let v159_6: Path = concat_path(&(v156_6),&(v156_11_head));
                let v159_11: Space = routine_17(c, &(v159_6), &(v156_11_tail).make_space(), &(v1_192));
                drop(v159_6);
                map_map_kernels::compose(&(v157_10),&(v159_11))
              };
              drop(v157_10);
              let v157_13: Space = map_map_kernels::unite(&(v157_8),&(v157_12));
              v156_11.join_into((v157_13).clone());
              }
              v156_11_cursor.ascend(1);
            }
            drop(v156_11_cursor);
            drop(v156_6);
            map_map_kernels::compose(&(v151_10),&(v156_11))
          };
          drop(v151_10);
          let v151_13: Space = map_map_kernels::unite(&(v151_8),&(v151_12));
          v150_6.join_into((v151_13).clone());
          }
          v150_6_cursor.ascend(1);
        }
        drop(v150_6_cursor);
        map_map_kernels::compose(&(v149_5),&(v150_6))
      };
      drop(v149_5);
      let v149_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v149_2));
      drop(v149_2);
      let v149_9: Space = if map_kernels::has_head(&(v149_8)) { singleton(&[]) } else { Space::new() };
      drop(v149_8);
      let v149_11: Space = if (v149_9).is_empty() { Space::new() } else {
        let mut v160_10 = Space::new();
        let mut v160_10_cursor = (v86_11_tail).read_zipper();
        for v160_10_byte in v160_10_cursor.child_mask().iter() {
          v160_10_cursor.descend_to_byte(v160_10_byte);
          {
          let v160_10_tail = v160_10_cursor.fork_read_zipper();
          let v160_10_head = Path::from_slice(&[v160_10_byte]);
          let v161_2: Space = singleton(&(v160_10_head));
          let v161_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v161_2));
          let v161_4: Space = if map_kernels::has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
          drop(v161_3);
          let v161_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v161_4));
          drop(v161_4);
          let v161_8: Space = if (v161_5).is_empty() { Space::new() } else {
            let v162_6: Path = concat_path(&(v86_11_head),&(v160_10_head));
            let mut v162_7 = Space::new();
            let mut v162_7_cursor = (v160_10_tail).read_zipper();
            for v162_7_byte in v162_7_cursor.child_mask().iter() {
              v162_7_cursor.descend_to_byte(v162_7_byte);
              {
              let v162_7_tail = v162_7_cursor.fork_read_zipper();
              let v162_7_head = Path::from_slice(&[v162_7_byte]);
              let v163_2: Space = singleton(&(v162_7_head));
              let v163_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v163_2));
              let v163_4: Space = if map_kernels::has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
              drop(v163_3);
              let v163_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v163_4));
              drop(v163_4);
              let v163_8: Space = if (v163_5).is_empty() { Space::new() } else {
                let v164_6: Path = concat_path(&(v162_6),&(v162_7_head));
                let v164_7: Space = routine_15(c, &(v164_6), &(v162_7_tail).make_space(), &(v1_192));
                map_map_kernels::compose(&(v163_5),&(v164_7))
              };
              drop(v163_5);
              let v163_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v163_2));
              drop(v163_2);
              let v163_10: Space = if map_kernels::has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
              drop(v163_9);
              let v163_12: Space = if (v163_10).is_empty() { Space::new() } else {
                let v165_6: Path = concat_path(&(v162_6),&(v162_7_head));
                let v165_11: Space = routine_16(c, &(v165_6), &(v162_7_tail).make_space(), &(v1_192));
                drop(v165_6);
                map_map_kernels::compose(&(v163_10),&(v165_11))
              };
              drop(v163_10);
              let v163_13: Space = map_map_kernels::unite(&(v163_8),&(v163_12));
              v162_7.join_into((v163_13).clone());
              }
              v162_7_cursor.ascend(1);
            }
            drop(v162_7_cursor);
            map_map_kernels::compose(&(v161_5),&(v162_7))
          };
          drop(v161_5);
          let v161_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v161_2));
          drop(v161_2);
          let v161_10: Space = if map_kernels::has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
          drop(v161_9);
          let v161_12: Space = if (v161_10).is_empty() { Space::new() } else {
            let mut v166_11 = Space::new();
            let mut v166_11_cursor = (v160_10_tail).read_zipper();
            for v166_11_byte in v166_11_cursor.child_mask().iter() {
              v166_11_cursor.descend_to_byte(v166_11_byte);
              {
              let v166_11_tail = v166_11_cursor.fork_read_zipper();
              let v166_11_head = Path::from_slice(&[v166_11_byte]);
              let v167_2: Space = singleton(&(v166_11_head));
              let v167_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v167_2));
              let v167_4: Space = if map_kernels::has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
              drop(v167_3);
              let v167_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v167_4));
              drop(v167_4);
              let v167_7: Space = if (v167_5).is_empty() { Space::new() } else {
                let v168_6: Space = routine_18(c, &(v166_11_head), &(v166_11_tail).make_space(), &(v1_192));
                map_map_kernels::compose(&(v167_5),&(v168_6))
              };
              drop(v167_5);
              let v167_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v167_2));
              drop(v167_2);
              let v167_9: Space = if map_kernels::has_head(&(v167_8)) { singleton(&[]) } else { Space::new() };
              drop(v167_8);
              let v167_11: Space = if (v167_9).is_empty() { Space::new() } else {
                let v169_10: Space = routine_19(c, &(v166_11_head), &(v166_11_tail).make_space(), &(v1_192));
                map_map_kernels::compose(&(v167_9),&(v169_10))
              };
              drop(v167_9);
              let v167_12: Space = map_map_kernels::unite(&(v167_7),&(v167_11));
              v166_11.join_into((v167_12).clone());
              }
              v166_11_cursor.ascend(1);
            }
            drop(v166_11_cursor);
            map_map_kernels::compose(&(v161_10),&(v166_11))
          };
          drop(v161_10);
          let v170_6: Path = concat_path(&(v86_11_head),&(v160_10_head));
          let v161_13: Space = map_kernels::wrap(&(v161_12),&(v170_6));
          let v161_14: Space = map_map_kernels::unite(&(v161_8),&(v161_13));
          v160_10.join_into((v161_14).clone());
          }
          v160_10_cursor.ascend(1);
        }
        drop(v160_10_cursor);
        map_map_kernels::compose(&(v149_9),&(v160_10))
      };
      drop(v149_9);
      let v149_12: Space = map_map_kernels::unite(&(v149_7),&(v149_11));
      v86_11.join_into((v149_12).clone());
      }
      v86_11_cursor.ascend(1);
    }
    drop(v86_11_cursor);
    drop(v86_10);
    let v86_12: Space = map_map_kernels::unite(&(v86_9),&(v86_11));
    let v86_13: Space = map_kernels::unwrap(&(v1_192),&(*CONSTANT_2));
    let v86_14: Space = map_map_kernels::subtract(&(v86_12),&(v86_13));
    drop(v86_13);
    let v86_15: Space = map_kernels::unwrap(&(v1_192),&(*CONSTANT_9));
    let v86_16: Space = map_map_kernels::subtract(&(v86_14),&(v86_15));
    drop(v86_15);
    let v86_17: Space = map_kernels::wrap(&(v86_16),&(*CONSTANT_9));
    let v86_18: Space = map_map_kernels::unite(&(v86_1),&(v86_6));
    drop(v86_1);
    drop(v86_6);
    let v86_19: Space = map_kernels::wrap(&(v86_18),&(*CONSTANT_7));
    drop(v86_18);
    let v86_20: Space = map_map_kernels::unite(&(v86_17),&(v86_19));
    drop(v86_19);
    let v86_21: Space = map_map_kernels::unite(&(v86_20),&(v1_192));
    if !v1_192.join_into((v86_21).clone()).is_element() { break; }
  }
  let v1_193: Space = map_map_kernels::unite(&(*s0),&(v1_192));
  (v1_193).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v171_24 = Space::new();
  let mut v171_24_cursor = (*s0).read_zipper();
  for v171_24_byte in v171_24_cursor.child_mask().iter() {
    v171_24_cursor.descend_to_byte(v171_24_byte);
    {
    let v171_24_tail = v171_24_cursor.fork_read_zipper();
    let v171_24_head = Path::from_slice(&[v171_24_byte]);
    let v172_2: Space = singleton(&(v171_24_head));
    let v172_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v172_2));
    let v172_4: Space = if map_kernels::has_head(&(v172_3)) { singleton(&[]) } else { Space::new() };
    drop(v172_3);
    let v172_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v172_4));
    drop(v172_4);
    let v172_8: Space = if (v172_5).is_empty() { Space::new() } else {
      let v173_6: Path = concat_path(&(*p0),&(v171_24_head));
      let mut v173_7 = Space::new();
      let mut v173_7_cursor = (v171_24_tail).read_zipper();
      for v173_7_byte in v173_7_cursor.child_mask().iter() {
        v173_7_cursor.descend_to_byte(v173_7_byte);
        {
        let v173_7_tail = v173_7_cursor.fork_read_zipper();
        let v173_7_head = Path::from_slice(&[v173_7_byte]);
        let v174_2: Space = singleton(&(v173_7_head));
        let v174_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v174_2));
        let v174_4: Space = if map_kernels::has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
        drop(v174_3);
        let v174_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v174_4));
        drop(v174_4);
        let v174_8: Space = if (v174_5).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v173_6),&(v173_7_head));
          let mut v175_7 = Space::new();
          let mut v175_7_cursor = (v173_7_tail).read_zipper();
          for v175_7_byte in v175_7_cursor.child_mask().iter() {
            v175_7_cursor.descend_to_byte(v175_7_byte);
            {
            let v175_7_tail = v175_7_cursor.fork_read_zipper();
            let v175_7_head = Path::from_slice(&[v175_7_byte]);
            let v176_2: Space = singleton(&(v175_7_head));
            let v176_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v176_2));
            let v176_4: Space = if map_kernels::has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
            drop(v176_3);
            let v176_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v176_4));
            drop(v176_4);
            let v176_8: Space = if (v176_5).is_empty() { Space::new() } else {
              let v177_6: Path = concat_path(&(v175_6),&(v175_7_head));
              let v177_7: Space = routine_20(c, &(v177_6), &(v175_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v176_5),&(v177_7))
            };
            drop(v176_5);
            let v176_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v176_2));
            drop(v176_2);
            let v176_10: Space = if map_kernels::has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
            drop(v176_9);
            let v176_12: Space = if (v176_10).is_empty() { Space::new() } else {
              let v178_6: Path = concat_path(&(v175_6),&(v175_7_head));
              let v178_11: Space = routine_21(c, &(v178_6), &(v175_7_tail).make_space(), &(*s1));
              drop(v178_6);
              map_map_kernels::compose(&(v176_10),&(v178_11))
            };
            drop(v176_10);
            let v176_13: Space = map_map_kernels::unite(&(v176_8),&(v176_12));
            v175_7.join_into((v176_13).clone());
            }
            v175_7_cursor.ascend(1);
          }
          drop(v175_7_cursor);
          map_map_kernels::compose(&(v174_5),&(v175_7))
        };
        drop(v174_5);
        let v174_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v174_2));
        drop(v174_2);
        let v174_10: Space = if map_kernels::has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
        drop(v174_9);
        let v174_12: Space = if (v174_10).is_empty() { Space::new() } else {
          let v179_6: Path = concat_path(&(v173_6),&(v173_7_head));
          let mut v179_11 = Space::new();
          let mut v179_11_cursor = (v173_7_tail).read_zipper();
          for v179_11_byte in v179_11_cursor.child_mask().iter() {
            v179_11_cursor.descend_to_byte(v179_11_byte);
            {
            let v179_11_tail = v179_11_cursor.fork_read_zipper();
            let v179_11_head = Path::from_slice(&[v179_11_byte]);
            let v180_2: Space = singleton(&(v179_11_head));
            let v180_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v180_2));
            let v180_4: Space = if map_kernels::has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
            drop(v180_3);
            let v180_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v180_4));
            drop(v180_4);
            let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
              let v181_6: Path = concat_path(&(v179_6),&(v179_11_head));
              let v181_7: Space = routine_20(c, &(v181_6), &(v179_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v180_5),&(v181_7))
            };
            drop(v180_5);
            let v180_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v180_2));
            drop(v180_2);
            let v180_10: Space = if map_kernels::has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
            drop(v180_9);
            let v180_12: Space = if (v180_10).is_empty() { Space::new() } else {
              let v182_6: Path = concat_path(&(v179_6),&(v179_11_head));
              let v182_11: Space = routine_4(c, &(v182_6), &(v179_11_tail).make_space(), &(*s1));
              drop(v182_6);
              map_map_kernels::compose(&(v180_10),&(v182_11))
            };
            drop(v180_10);
            let v180_13: Space = map_map_kernels::unite(&(v180_8),&(v180_12));
            v179_11.join_into((v180_13).clone());
            }
            v179_11_cursor.ascend(1);
          }
          drop(v179_11_cursor);
          drop(v179_6);
          map_map_kernels::compose(&(v174_10),&(v179_11))
        };
        drop(v174_10);
        let v174_13: Space = map_map_kernels::unite(&(v174_8),&(v174_12));
        v173_7.join_into((v174_13).clone());
        }
        v173_7_cursor.ascend(1);
      }
      drop(v173_7_cursor);
      map_map_kernels::compose(&(v172_5),&(v173_7))
    };
    drop(v172_5);
    let v172_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v172_2));
    drop(v172_2);
    let v172_10: Space = if map_kernels::has_head(&(v172_9)) { singleton(&[]) } else { Space::new() };
    drop(v172_9);
    let v172_12: Space = if (v172_10).is_empty() { Space::new() } else {
      let v183_6: Path = concat_path(&(*p0),&(v171_24_head));
      let mut v183_11 = Space::new();
      let mut v183_11_cursor = (v171_24_tail).read_zipper();
      for v183_11_byte in v183_11_cursor.child_mask().iter() {
        v183_11_cursor.descend_to_byte(v183_11_byte);
        {
        let v183_11_tail = v183_11_cursor.fork_read_zipper();
        let v183_11_head = Path::from_slice(&[v183_11_byte]);
        let v184_2: Space = singleton(&(v183_11_head));
        let v184_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v184_2));
        let v184_4: Space = if map_kernels::has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
        drop(v184_3);
        let v184_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v184_4));
        drop(v184_4);
        let v184_8: Space = if (v184_5).is_empty() { Space::new() } else {
          let v185_6: Path = concat_path(&(v183_6),&(v183_11_head));
          let mut v185_7 = Space::new();
          let mut v185_7_cursor = (v183_11_tail).read_zipper();
          for v185_7_byte in v185_7_cursor.child_mask().iter() {
            v185_7_cursor.descend_to_byte(v185_7_byte);
            {
            let v185_7_tail = v185_7_cursor.fork_read_zipper();
            let v185_7_head = Path::from_slice(&[v185_7_byte]);
            let v186_2: Space = singleton(&(v185_7_head));
            let v186_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v186_2));
            let v186_4: Space = if map_kernels::has_head(&(v186_3)) { singleton(&[]) } else { Space::new() };
            drop(v186_3);
            let v186_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v186_4));
            drop(v186_4);
            let v186_8: Space = if (v186_5).is_empty() { Space::new() } else {
              let v187_6: Path = concat_path(&(v185_6),&(v185_7_head));
              let v187_7: Space = routine_20(c, &(v187_6), &(v185_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v186_5),&(v187_7))
            };
            drop(v186_5);
            let v186_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v186_2));
            drop(v186_2);
            let v186_10: Space = if map_kernels::has_head(&(v186_9)) { singleton(&[]) } else { Space::new() };
            drop(v186_9);
            let v186_12: Space = if (v186_10).is_empty() { Space::new() } else {
              let v188_6: Path = concat_path(&(v185_6),&(v185_7_head));
              let v188_11: Space = routine_21(c, &(v188_6), &(v185_7_tail).make_space(), &(*s1));
              drop(v188_6);
              map_map_kernels::compose(&(v186_10),&(v188_11))
            };
            drop(v186_10);
            let v186_13: Space = map_map_kernels::unite(&(v186_8),&(v186_12));
            v185_7.join_into((v186_13).clone());
            }
            v185_7_cursor.ascend(1);
          }
          drop(v185_7_cursor);
          map_map_kernels::compose(&(v184_5),&(v185_7))
        };
        drop(v184_5);
        let v184_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v184_2));
        drop(v184_2);
        let v184_10: Space = if map_kernels::has_head(&(v184_9)) { singleton(&[]) } else { Space::new() };
        drop(v184_9);
        let v184_12: Space = if (v184_10).is_empty() { Space::new() } else {
          let mut v189_11 = Space::new();
          let mut v189_11_cursor = (v183_11_tail).read_zipper();
          for v189_11_byte in v189_11_cursor.child_mask().iter() {
            v189_11_cursor.descend_to_byte(v189_11_byte);
            {
            let v189_11_tail = v189_11_cursor.fork_read_zipper();
            let v189_11_head = Path::from_slice(&[v189_11_byte]);
            let v190_2: Space = singleton(&(v189_11_head));
            let v190_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v190_2));
            let v190_4: Space = if map_kernels::has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
            drop(v190_3);
            let v190_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v190_4));
            drop(v190_4);
            let v190_7: Space = if (v190_5).is_empty() { Space::new() } else {
              let v191_6: Space = routine_5(c, &(v189_11_head), &(v189_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v190_5),&(v191_6))
            };
            drop(v190_5);
            let v190_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v190_2));
            drop(v190_2);
            let v190_9: Space = if map_kernels::has_head(&(v190_8)) { singleton(&[]) } else { Space::new() };
            drop(v190_8);
            let v190_11: Space = if (v190_9).is_empty() { Space::new() } else {
              let v192_10: Space = routine_6(c, &(v189_11_head), &(v189_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v190_9),&(v192_10))
            };
            drop(v190_9);
            let v190_12: Space = map_map_kernels::unite(&(v190_7),&(v190_11));
            v189_11.join_into((v190_12).clone());
            }
            v189_11_cursor.ascend(1);
          }
          drop(v189_11_cursor);
          map_map_kernels::compose(&(v184_10),&(v189_11))
        };
        drop(v184_10);
        let v193_6: Path = concat_path(&(v183_6),&(v183_11_head));
        let v184_13: Space = map_kernels::wrap(&(v184_12),&(v193_6));
        let v184_14: Space = map_map_kernels::unite(&(v184_8),&(v184_13));
        v183_11.join_into((v184_14).clone());
        }
        v183_11_cursor.ascend(1);
      }
      drop(v183_11_cursor);
      drop(v183_6);
      map_map_kernels::compose(&(v172_10),&(v183_11))
    };
    drop(v172_10);
    let v172_13: Space = map_map_kernels::unite(&(v172_8),&(v172_12));
    v171_24.join_into((v172_13).clone());
    }
    v171_24_cursor.ascend(1);
  }
  drop(v171_24_cursor);
  (v171_24).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v194_24 = Space::new();
  let mut v194_24_cursor = (*s0).read_zipper();
  for v194_24_byte in v194_24_cursor.child_mask().iter() {
    v194_24_cursor.descend_to_byte(v194_24_byte);
    {
    let v194_24_tail = v194_24_cursor.fork_read_zipper();
    let v194_24_head = Path::from_slice(&[v194_24_byte]);
    let v195_2: Space = singleton(&(v194_24_head));
    let v195_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v195_2));
    let v195_4: Space = if map_kernels::has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
    drop(v195_3);
    let v195_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v195_4));
    drop(v195_4);
    let v195_8: Space = if (v195_5).is_empty() { Space::new() } else {
      let v196_6: Path = concat_path(&(*p0),&(v194_24_head));
      let mut v196_7 = Space::new();
      let mut v196_7_cursor = (v194_24_tail).read_zipper();
      for v196_7_byte in v196_7_cursor.child_mask().iter() {
        v196_7_cursor.descend_to_byte(v196_7_byte);
        {
        let v196_7_tail = v196_7_cursor.fork_read_zipper();
        let v196_7_head = Path::from_slice(&[v196_7_byte]);
        let v197_2: Space = singleton(&(v196_7_head));
        let v197_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v197_2));
        let v197_4: Space = if map_kernels::has_head(&(v197_3)) { singleton(&[]) } else { Space::new() };
        drop(v197_3);
        let v197_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v197_4));
        drop(v197_4);
        let v197_8: Space = if (v197_5).is_empty() { Space::new() } else {
          let v198_6: Path = concat_path(&(v196_6),&(v196_7_head));
          let mut v198_7 = Space::new();
          let mut v198_7_cursor = (v196_7_tail).read_zipper();
          for v198_7_byte in v198_7_cursor.child_mask().iter() {
            v198_7_cursor.descend_to_byte(v198_7_byte);
            {
            let v198_7_tail = v198_7_cursor.fork_read_zipper();
            let v198_7_head = Path::from_slice(&[v198_7_byte]);
            let v199_2: Space = singleton(&(v198_7_head));
            let v199_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v199_2));
            let v199_4: Space = if map_kernels::has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
            drop(v199_3);
            let v199_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v199_4));
            drop(v199_4);
            let v199_8: Space = if (v199_5).is_empty() { Space::new() } else {
              let v200_6: Path = concat_path(&(v198_6),&(v198_7_head));
              let v200_7: Space = routine_20(c, &(v200_6), &(v198_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v199_5),&(v200_7))
            };
            drop(v199_5);
            let v199_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v199_2));
            drop(v199_2);
            let v199_10: Space = if map_kernels::has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
            drop(v199_9);
            let v199_12: Space = if (v199_10).is_empty() { Space::new() } else {
              let v201_6: Path = concat_path(&(v198_6),&(v198_7_head));
              let v201_11: Space = routine_21(c, &(v201_6), &(v198_7_tail).make_space(), &(*s1));
              drop(v201_6);
              map_map_kernels::compose(&(v199_10),&(v201_11))
            };
            drop(v199_10);
            let v199_13: Space = map_map_kernels::unite(&(v199_8),&(v199_12));
            v198_7.join_into((v199_13).clone());
            }
            v198_7_cursor.ascend(1);
          }
          drop(v198_7_cursor);
          map_map_kernels::compose(&(v197_5),&(v198_7))
        };
        drop(v197_5);
        let v197_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v197_2));
        drop(v197_2);
        let v197_10: Space = if map_kernels::has_head(&(v197_9)) { singleton(&[]) } else { Space::new() };
        drop(v197_9);
        let v197_12: Space = if (v197_10).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v196_6),&(v196_7_head));
          let mut v202_11 = Space::new();
          let mut v202_11_cursor = (v196_7_tail).read_zipper();
          for v202_11_byte in v202_11_cursor.child_mask().iter() {
            v202_11_cursor.descend_to_byte(v202_11_byte);
            {
            let v202_11_tail = v202_11_cursor.fork_read_zipper();
            let v202_11_head = Path::from_slice(&[v202_11_byte]);
            let v203_2: Space = singleton(&(v202_11_head));
            let v203_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v203_2));
            let v203_4: Space = if map_kernels::has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
            drop(v203_3);
            let v203_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v203_4));
            drop(v203_4);
            let v203_8: Space = if (v203_5).is_empty() { Space::new() } else {
              let v204_6: Path = concat_path(&(v202_6),&(v202_11_head));
              let v204_7: Space = routine_20(c, &(v204_6), &(v202_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v203_5),&(v204_7))
            };
            drop(v203_5);
            let v203_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v203_2));
            drop(v203_2);
            let v203_10: Space = if map_kernels::has_head(&(v203_9)) { singleton(&[]) } else { Space::new() };
            drop(v203_9);
            let v203_12: Space = if (v203_10).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v202_6),&(v202_11_head));
              let v205_11: Space = routine_4(c, &(v205_6), &(v202_11_tail).make_space(), &(*s1));
              drop(v205_6);
              map_map_kernels::compose(&(v203_10),&(v205_11))
            };
            drop(v203_10);
            let v203_13: Space = map_map_kernels::unite(&(v203_8),&(v203_12));
            v202_11.join_into((v203_13).clone());
            }
            v202_11_cursor.ascend(1);
          }
          drop(v202_11_cursor);
          drop(v202_6);
          map_map_kernels::compose(&(v197_10),&(v202_11))
        };
        drop(v197_10);
        let v197_13: Space = map_map_kernels::unite(&(v197_8),&(v197_12));
        v196_7.join_into((v197_13).clone());
        }
        v196_7_cursor.ascend(1);
      }
      drop(v196_7_cursor);
      map_map_kernels::compose(&(v195_5),&(v196_7))
    };
    drop(v195_5);
    let v195_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v195_2));
    drop(v195_2);
    let v195_10: Space = if map_kernels::has_head(&(v195_9)) { singleton(&[]) } else { Space::new() };
    drop(v195_9);
    let v195_12: Space = if (v195_10).is_empty() { Space::new() } else {
      let mut v206_11 = Space::new();
      let mut v206_11_cursor = (v194_24_tail).read_zipper();
      for v206_11_byte in v206_11_cursor.child_mask().iter() {
        v206_11_cursor.descend_to_byte(v206_11_byte);
        {
        let v206_11_tail = v206_11_cursor.fork_read_zipper();
        let v206_11_head = Path::from_slice(&[v206_11_byte]);
        let v207_2: Space = singleton(&(v206_11_head));
        let v207_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v207_2));
        let v207_4: Space = if map_kernels::has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
        drop(v207_3);
        let v207_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v207_4));
        drop(v207_4);
        let v207_7: Space = if (v207_5).is_empty() { Space::new() } else {
          let mut v208_6 = Space::new();
          let mut v208_6_cursor = (v206_11_tail).read_zipper();
          for v208_6_byte in v208_6_cursor.child_mask().iter() {
            v208_6_cursor.descend_to_byte(v208_6_byte);
            {
            let v208_6_tail = v208_6_cursor.fork_read_zipper();
            let v208_6_head = Path::from_slice(&[v208_6_byte]);
            let v209_2: Space = singleton(&(v208_6_head));
            let v209_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v209_2));
            let v209_4: Space = if map_kernels::has_head(&(v209_3)) { singleton(&[]) } else { Space::new() };
            drop(v209_3);
            let v209_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v209_4));
            drop(v209_4);
            let v209_8: Space = if (v209_5).is_empty() { Space::new() } else {
              let v210_6: Path = concat_path(&(v206_11_head),&(v208_6_head));
              let v210_7: Space = routine_22(c, &(v210_6), &(v208_6_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v209_5),&(v210_7))
            };
            drop(v209_5);
            let v209_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v209_2));
            drop(v209_2);
            let v209_10: Space = if map_kernels::has_head(&(v209_9)) { singleton(&[]) } else { Space::new() };
            drop(v209_9);
            let v209_12: Space = if (v209_10).is_empty() { Space::new() } else {
              let v211_6: Path = concat_path(&(v206_11_head),&(v208_6_head));
              let v211_11: Space = routine_23(c, &(v211_6), &(v208_6_tail).make_space(), &(*s1));
              drop(v211_6);
              map_map_kernels::compose(&(v209_10),&(v211_11))
            };
            drop(v209_10);
            let v209_13: Space = map_map_kernels::unite(&(v209_8),&(v209_12));
            v208_6.join_into((v209_13).clone());
            }
            v208_6_cursor.ascend(1);
          }
          drop(v208_6_cursor);
          map_map_kernels::compose(&(v207_5),&(v208_6))
        };
        drop(v207_5);
        let v207_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v207_2));
        drop(v207_2);
        let v207_9: Space = if map_kernels::has_head(&(v207_8)) { singleton(&[]) } else { Space::new() };
        drop(v207_8);
        let v207_11: Space = if (v207_9).is_empty() { Space::new() } else {
          let mut v212_10 = Space::new();
          let mut v212_10_cursor = (v206_11_tail).read_zipper();
          for v212_10_byte in v212_10_cursor.child_mask().iter() {
            v212_10_cursor.descend_to_byte(v212_10_byte);
            {
            let v212_10_tail = v212_10_cursor.fork_read_zipper();
            let v212_10_head = Path::from_slice(&[v212_10_byte]);
            let v213_2: Space = singleton(&(v212_10_head));
            let v213_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v213_2));
            let v213_4: Space = if map_kernels::has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
            drop(v213_3);
            let v213_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v213_4));
            drop(v213_4);
            let v213_8: Space = if (v213_5).is_empty() { Space::new() } else {
              let v214_6: Path = concat_path(&(v206_11_head),&(v212_10_head));
              let v214_7: Space = routine_22(c, &(v214_6), &(v212_10_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v213_5),&(v214_7))
            };
            drop(v213_5);
            let v213_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v213_2));
            drop(v213_2);
            let v213_10: Space = if map_kernels::has_head(&(v213_9)) { singleton(&[]) } else { Space::new() };
            drop(v213_9);
            let v213_12: Space = if (v213_10).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v206_11_head),&(v212_10_head));
              let v215_11: Space = routine_24(c, &(v215_6), &(v212_10_tail).make_space(), &(*s1));
              drop(v215_6);
              map_map_kernels::compose(&(v213_10),&(v215_11))
            };
            drop(v213_10);
            let v213_13: Space = map_map_kernels::unite(&(v213_8),&(v213_12));
            v212_10.join_into((v213_13).clone());
            }
            v212_10_cursor.ascend(1);
          }
          drop(v212_10_cursor);
          map_map_kernels::compose(&(v207_9),&(v212_10))
        };
        drop(v207_9);
        let v207_12: Space = map_map_kernels::unite(&(v207_7),&(v207_11));
        v206_11.join_into((v207_12).clone());
        }
        v206_11_cursor.ascend(1);
      }
      drop(v206_11_cursor);
      map_map_kernels::compose(&(v195_10),&(v206_11))
    };
    drop(v195_10);
    let v216_6: Path = concat_path(&(*p0),&(v194_24_head));
    let v195_13: Space = map_kernels::wrap(&(v195_12),&(v216_6));
    let v195_14: Space = map_map_kernels::unite(&(v195_8),&(v195_13));
    v194_24.join_into((v195_14).clone());
    }
    v194_24_cursor.ascend(1);
  }
  drop(v194_24_cursor);
  (v194_24).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v217_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v217_22: Space = map_kernels::unwrap(&(v217_21),&(*CONSTANT_4));
  drop(v217_21);
  let mut v217_26 = Space::new();
  let mut v217_26_cursor = (*s0).read_zipper();
  for v217_26_byte in v217_26_cursor.child_mask().iter() {
    v217_26_cursor.descend_to_byte(v217_26_byte);
    {
    let v217_26_tail = v217_26_cursor.fork_read_zipper();
    let v217_26_head = Path::from_slice(&[v217_26_byte]);
    let v218_2: Space = singleton(&(v217_26_head));
    let v218_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v218_2));
    let v218_4: Space = if map_kernels::has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
    drop(v218_3);
    let v218_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v218_4));
    drop(v218_4);
    let v218_7: Space = if (v218_5).is_empty() { Space::new() } else {
      let mut v219_6 = Space::new();
      let mut v219_6_cursor = (v217_26_tail).read_zipper();
      for v219_6_byte in v219_6_cursor.child_mask().iter() {
        v219_6_cursor.descend_to_byte(v219_6_byte);
        {
        let v219_6_tail = v219_6_cursor.fork_read_zipper();
        let v219_6_head = Path::from_slice(&[v219_6_byte]);
        let v220_2: Space = singleton(&(v219_6_head));
        let v220_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v220_2));
        let v220_4: Space = if map_kernels::has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
        drop(v220_3);
        let v220_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v220_4));
        drop(v220_4);
        let v220_8: Space = if (v220_5).is_empty() { Space::new() } else {
          let v221_6: Path = concat_path(&(v217_26_head),&(v219_6_head));
          let mut v221_7 = Space::new();
          let mut v221_7_cursor = (v219_6_tail).read_zipper();
          for v221_7_byte in v221_7_cursor.child_mask().iter() {
            v221_7_cursor.descend_to_byte(v221_7_byte);
            {
            let v221_7_tail = v221_7_cursor.fork_read_zipper();
            let v221_7_head = Path::from_slice(&[v221_7_byte]);
            let v222_2: Space = singleton(&(v221_7_head));
            let v222_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v222_2));
            let v222_4: Space = if map_kernels::has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
            drop(v222_3);
            let v222_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v222_4));
            drop(v222_4);
            let v222_8: Space = if (v222_5).is_empty() { Space::new() } else {
              let v223_6: Path = concat_path(&(v221_6),&(v221_7_head));
              let v223_7: Space = routine_25(c, &(v223_6), &(v221_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v222_5),&(v223_7))
            };
            drop(v222_5);
            let v222_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v222_2));
            drop(v222_2);
            let v222_10: Space = if map_kernels::has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
            drop(v222_9);
            let v222_12: Space = if (v222_10).is_empty() { Space::new() } else {
              let v224_6: Path = concat_path(&(v221_6),&(v221_7_head));
              let v224_11: Space = routine_26(c, &(v224_6), &(v221_7_tail).make_space(), &(*s1));
              drop(v224_6);
              map_map_kernels::compose(&(v222_10),&(v224_11))
            };
            drop(v222_10);
            let v222_13: Space = map_map_kernels::unite(&(v222_8),&(v222_12));
            v221_7.join_into((v222_13).clone());
            }
            v221_7_cursor.ascend(1);
          }
          drop(v221_7_cursor);
          map_map_kernels::compose(&(v220_5),&(v221_7))
        };
        drop(v220_5);
        let v220_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v220_2));
        drop(v220_2);
        let v220_10: Space = if map_kernels::has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
        drop(v220_9);
        let v220_12: Space = if (v220_10).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v217_26_head),&(v219_6_head));
          let mut v225_11 = Space::new();
          let mut v225_11_cursor = (v219_6_tail).read_zipper();
          for v225_11_byte in v225_11_cursor.child_mask().iter() {
            v225_11_cursor.descend_to_byte(v225_11_byte);
            {
            let v225_11_tail = v225_11_cursor.fork_read_zipper();
            let v225_11_head = Path::from_slice(&[v225_11_byte]);
            let v226_2: Space = singleton(&(v225_11_head));
            let v226_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v226_2));
            let v226_4: Space = if map_kernels::has_head(&(v226_3)) { singleton(&[]) } else { Space::new() };
            drop(v226_3);
            let v226_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v226_4));
            drop(v226_4);
            let v226_8: Space = if (v226_5).is_empty() { Space::new() } else {
              let v227_6: Path = concat_path(&(v225_6),&(v225_11_head));
              let v227_7: Space = routine_25(c, &(v227_6), &(v225_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v226_5),&(v227_7))
            };
            drop(v226_5);
            let v226_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v226_2));
            drop(v226_2);
            let v226_10: Space = if map_kernels::has_head(&(v226_9)) { singleton(&[]) } else { Space::new() };
            drop(v226_9);
            let v226_12: Space = if (v226_10).is_empty() { Space::new() } else {
              let v228_6: Path = concat_path(&(v225_6),&(v225_11_head));
              let v228_11: Space = routine_24(c, &(v228_6), &(v225_11_tail).make_space(), &(*s1));
              drop(v228_6);
              map_map_kernels::compose(&(v226_10),&(v228_11))
            };
            drop(v226_10);
            let v226_13: Space = map_map_kernels::unite(&(v226_8),&(v226_12));
            v225_11.join_into((v226_13).clone());
            }
            v225_11_cursor.ascend(1);
          }
          drop(v225_11_cursor);
          drop(v225_6);
          map_map_kernels::compose(&(v220_10),&(v225_11))
        };
        drop(v220_10);
        let v220_13: Space = map_map_kernels::unite(&(v220_8),&(v220_12));
        v219_6.join_into((v220_13).clone());
        }
        v219_6_cursor.ascend(1);
      }
      drop(v219_6_cursor);
      map_map_kernels::compose(&(v218_5),&(v219_6))
    };
    drop(v218_5);
    let v218_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v218_2));
    drop(v218_2);
    let v218_9: Space = if map_kernels::has_head(&(v218_8)) { singleton(&[]) } else { Space::new() };
    drop(v218_8);
    let v218_12: Space = if (v218_9).is_empty() { Space::new() } else {
      let v229_10: Space = map_kernels::unwrap(&(v217_22),&(v217_26_head));
      let mut v229_11 = Space::new();
      let mut v229_11_cursor = (v217_26_tail).read_zipper();
      for v229_11_byte in v229_11_cursor.child_mask().iter() {
        v229_11_cursor.descend_to_byte(v229_11_byte);
        {
        let v229_11_tail = v229_11_cursor.fork_read_zipper();
        let v229_11_head = Path::from_slice(&[v229_11_byte]);
        let v230_2: Space = singleton(&(v229_11_head));
        let v230_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v230_2));
        let v230_4: Space = if map_kernels::has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
        drop(v230_3);
        let v230_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v230_4));
        drop(v230_4);
        let v230_8: Space = if (v230_5).is_empty() { Space::new() } else {
          let v231_6: Path = concat_path(&(v217_26_head),&(v229_11_head));
          let mut v231_7 = Space::new();
          let mut v231_7_cursor = (v229_11_tail).read_zipper();
          for v231_7_byte in v231_7_cursor.child_mask().iter() {
            v231_7_cursor.descend_to_byte(v231_7_byte);
            {
            let v231_7_tail = v231_7_cursor.fork_read_zipper();
            let v231_7_head = Path::from_slice(&[v231_7_byte]);
            let v232_2: Space = singleton(&(v231_7_head));
            let v232_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v232_2));
            let v232_4: Space = if map_kernels::has_head(&(v232_3)) { singleton(&[]) } else { Space::new() };
            drop(v232_3);
            let v232_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v232_4));
            drop(v232_4);
            let v232_8: Space = if (v232_5).is_empty() { Space::new() } else {
              let v233_6: Path = concat_path(&(v231_6),&(v231_7_head));
              let v233_7: Space = routine_25(c, &(v233_6), &(v231_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v232_5),&(v233_7))
            };
            drop(v232_5);
            let v232_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v232_2));
            drop(v232_2);
            let v232_10: Space = if map_kernels::has_head(&(v232_9)) { singleton(&[]) } else { Space::new() };
            drop(v232_9);
            let v232_12: Space = if (v232_10).is_empty() { Space::new() } else {
              let v234_6: Path = concat_path(&(v231_6),&(v231_7_head));
              let v234_11: Space = routine_26(c, &(v234_6), &(v231_7_tail).make_space(), &(*s1));
              drop(v234_6);
              map_map_kernels::compose(&(v232_10),&(v234_11))
            };
            drop(v232_10);
            let v232_13: Space = map_map_kernels::unite(&(v232_8),&(v232_12));
            v231_7.join_into((v232_13).clone());
            }
            v231_7_cursor.ascend(1);
          }
          drop(v231_7_cursor);
          drop(v231_6);
          map_map_kernels::compose(&(v230_5),&(v231_7))
        };
        drop(v230_5);
        let v230_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v230_2));
        drop(v230_2);
        let v230_10: Space = if map_kernels::has_head(&(v230_9)) { singleton(&[]) } else { Space::new() };
        drop(v230_9);
        let v230_13: Space = if (v230_10).is_empty() { Space::new() } else {
          let v235_11: Space = map_kernels::unwrap(&(v229_10),&(v229_11_head));
          let v235_12: Space = map_map_kernels::subtract(&(v235_11),&(*CONSTANT_5));
          drop(v235_11);
          map_map_kernels::compose(&(v230_10),&(v235_12))
        };
        drop(v230_10);
        let v230_14: Space = map_map_kernels::unite(&(v230_8),&(v230_13));
        drop(v230_13);
        v229_11.join_into((v230_14).clone());
        }
        v229_11_cursor.ascend(1);
      }
      drop(v229_11_cursor);
      drop(v229_10);
      map_map_kernels::compose(&(v218_9),&(v229_11))
    };
    drop(v218_9);
    let v218_13: Space = map_map_kernels::unite(&(v218_7),&(v218_12));
    v217_26.join_into((v218_13).clone());
    }
    v217_26_cursor.ascend(1);
  }
  drop(v217_26_cursor);
  drop(v217_22);
  let v217_27: Space = map_kernels::wrap(&(v217_26),&(*p0));
  (v217_27).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v236_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v236_22: Space = map_kernels::unwrap(&(v236_21),&(*CONSTANT_4));
  drop(v236_21);
  let v236_23: Space = map_kernels::unwrap(&(v236_22),&(*p0));
  drop(v236_22);
  let mut v236_27 = Space::new();
  let mut v236_27_cursor = (*s0).read_zipper();
  for v236_27_byte in v236_27_cursor.child_mask().iter() {
    v236_27_cursor.descend_to_byte(v236_27_byte);
    {
    let v236_27_tail = v236_27_cursor.fork_read_zipper();
    let v236_27_head = Path::from_slice(&[v236_27_byte]);
    let v237_2: Space = singleton(&(v236_27_head));
    let v237_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v237_2));
    let v237_4: Space = if map_kernels::has_head(&(v237_3)) { singleton(&[]) } else { Space::new() };
    drop(v237_3);
    let v237_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v237_4));
    drop(v237_4);
    let v237_8: Space = if (v237_5).is_empty() { Space::new() } else {
      let v238_6: Path = concat_path(&(*p0),&(v236_27_head));
      let mut v238_7 = Space::new();
      let mut v238_7_cursor = (v236_27_tail).read_zipper();
      for v238_7_byte in v238_7_cursor.child_mask().iter() {
        v238_7_cursor.descend_to_byte(v238_7_byte);
        {
        let v238_7_tail = v238_7_cursor.fork_read_zipper();
        let v238_7_head = Path::from_slice(&[v238_7_byte]);
        let v239_2: Space = singleton(&(v238_7_head));
        let v239_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v239_2));
        let v239_4: Space = if map_kernels::has_head(&(v239_3)) { singleton(&[]) } else { Space::new() };
        drop(v239_3);
        let v239_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v239_4));
        drop(v239_4);
        let v239_8: Space = if (v239_5).is_empty() { Space::new() } else {
          let v240_6: Path = concat_path(&(v238_6),&(v238_7_head));
          let mut v240_7 = Space::new();
          let mut v240_7_cursor = (v238_7_tail).read_zipper();
          for v240_7_byte in v240_7_cursor.child_mask().iter() {
            v240_7_cursor.descend_to_byte(v240_7_byte);
            {
            let v240_7_tail = v240_7_cursor.fork_read_zipper();
            let v240_7_head = Path::from_slice(&[v240_7_byte]);
            let v241_2: Space = singleton(&(v240_7_head));
            let v241_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v241_2));
            let v241_4: Space = if map_kernels::has_head(&(v241_3)) { singleton(&[]) } else { Space::new() };
            drop(v241_3);
            let v241_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v241_4));
            drop(v241_4);
            let v241_8: Space = if (v241_5).is_empty() { Space::new() } else {
              let v242_6: Path = concat_path(&(v240_6),&(v240_7_head));
              let v242_7: Space = routine_27(c, &(v242_6), &(v240_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v241_5),&(v242_7))
            };
            drop(v241_5);
            let v241_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v241_2));
            drop(v241_2);
            let v241_10: Space = if map_kernels::has_head(&(v241_9)) { singleton(&[]) } else { Space::new() };
            drop(v241_9);
            let v241_12: Space = if (v241_10).is_empty() { Space::new() } else {
              let v243_6: Path = concat_path(&(v240_6),&(v240_7_head));
              let v243_11: Space = routine_28(c, &(v243_6), &(v240_7_tail).make_space(), &(*s1));
              drop(v243_6);
              map_map_kernels::compose(&(v241_10),&(v243_11))
            };
            drop(v241_10);
            let v241_13: Space = map_map_kernels::unite(&(v241_8),&(v241_12));
            v240_7.join_into((v241_13).clone());
            }
            v240_7_cursor.ascend(1);
          }
          drop(v240_7_cursor);
          map_map_kernels::compose(&(v239_5),&(v240_7))
        };
        drop(v239_5);
        let v239_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v239_2));
        drop(v239_2);
        let v239_10: Space = if map_kernels::has_head(&(v239_9)) { singleton(&[]) } else { Space::new() };
        drop(v239_9);
        let v239_12: Space = if (v239_10).is_empty() { Space::new() } else {
          let v244_6: Path = concat_path(&(v238_6),&(v238_7_head));
          let mut v244_11 = Space::new();
          let mut v244_11_cursor = (v238_7_tail).read_zipper();
          for v244_11_byte in v244_11_cursor.child_mask().iter() {
            v244_11_cursor.descend_to_byte(v244_11_byte);
            {
            let v244_11_tail = v244_11_cursor.fork_read_zipper();
            let v244_11_head = Path::from_slice(&[v244_11_byte]);
            let v245_2: Space = singleton(&(v244_11_head));
            let v245_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v245_2));
            let v245_4: Space = if map_kernels::has_head(&(v245_3)) { singleton(&[]) } else { Space::new() };
            drop(v245_3);
            let v245_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v245_4));
            drop(v245_4);
            let v245_8: Space = if (v245_5).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v244_6),&(v244_11_head));
              let v246_7: Space = routine_27(c, &(v246_6), &(v244_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v245_5),&(v246_7))
            };
            drop(v245_5);
            let v245_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v245_2));
            drop(v245_2);
            let v245_10: Space = if map_kernels::has_head(&(v245_9)) { singleton(&[]) } else { Space::new() };
            drop(v245_9);
            let v245_12: Space = if (v245_10).is_empty() { Space::new() } else {
              let v247_6: Path = concat_path(&(v244_6),&(v244_11_head));
              let v247_11: Space = routine_24(c, &(v247_6), &(v244_11_tail).make_space(), &(*s1));
              drop(v247_6);
              map_map_kernels::compose(&(v245_10),&(v247_11))
            };
            drop(v245_10);
            let v245_13: Space = map_map_kernels::unite(&(v245_8),&(v245_12));
            v244_11.join_into((v245_13).clone());
            }
            v244_11_cursor.ascend(1);
          }
          drop(v244_11_cursor);
          drop(v244_6);
          map_map_kernels::compose(&(v239_10),&(v244_11))
        };
        drop(v239_10);
        let v239_13: Space = map_map_kernels::unite(&(v239_8),&(v239_12));
        v238_7.join_into((v239_13).clone());
        }
        v238_7_cursor.ascend(1);
      }
      drop(v238_7_cursor);
      map_map_kernels::compose(&(v237_5),&(v238_7))
    };
    drop(v237_5);
    let v237_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v237_2));
    drop(v237_2);
    let v237_10: Space = if map_kernels::has_head(&(v237_9)) { singleton(&[]) } else { Space::new() };
    drop(v237_9);
    let v237_13: Space = if (v237_10).is_empty() { Space::new() } else {
      let v248_6: Path = concat_path(&(*p0),&(v236_27_head));
      let v248_11: Space = map_kernels::unwrap(&(v236_23),&(v236_27_head));
      let mut v248_12 = Space::new();
      let mut v248_12_cursor = (v236_27_tail).read_zipper();
      for v248_12_byte in v248_12_cursor.child_mask().iter() {
        v248_12_cursor.descend_to_byte(v248_12_byte);
        {
        let v248_12_tail = v248_12_cursor.fork_read_zipper();
        let v248_12_head = Path::from_slice(&[v248_12_byte]);
        let v249_2: Space = singleton(&(v248_12_head));
        let v249_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v249_2));
        let v249_4: Space = if map_kernels::has_head(&(v249_3)) { singleton(&[]) } else { Space::new() };
        drop(v249_3);
        let v249_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v249_4));
        drop(v249_4);
        let v249_8: Space = if (v249_5).is_empty() { Space::new() } else {
          let v250_6: Path = concat_path(&(v248_6),&(v248_12_head));
          let mut v250_7 = Space::new();
          let mut v250_7_cursor = (v248_12_tail).read_zipper();
          for v250_7_byte in v250_7_cursor.child_mask().iter() {
            v250_7_cursor.descend_to_byte(v250_7_byte);
            {
            let v250_7_tail = v250_7_cursor.fork_read_zipper();
            let v250_7_head = Path::from_slice(&[v250_7_byte]);
            let v251_2: Space = singleton(&(v250_7_head));
            let v251_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v251_2));
            let v251_4: Space = if map_kernels::has_head(&(v251_3)) { singleton(&[]) } else { Space::new() };
            drop(v251_3);
            let v251_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v251_4));
            drop(v251_4);
            let v251_8: Space = if (v251_5).is_empty() { Space::new() } else {
              let v252_6: Path = concat_path(&(v250_6),&(v250_7_head));
              let v252_7: Space = routine_27(c, &(v252_6), &(v250_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v251_5),&(v252_7))
            };
            drop(v251_5);
            let v251_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v251_2));
            drop(v251_2);
            let v251_10: Space = if map_kernels::has_head(&(v251_9)) { singleton(&[]) } else { Space::new() };
            drop(v251_9);
            let v251_12: Space = if (v251_10).is_empty() { Space::new() } else {
              let v253_6: Path = concat_path(&(v250_6),&(v250_7_head));
              let v253_11: Space = routine_28(c, &(v253_6), &(v250_7_tail).make_space(), &(*s1));
              drop(v253_6);
              map_map_kernels::compose(&(v251_10),&(v253_11))
            };
            drop(v251_10);
            let v251_13: Space = map_map_kernels::unite(&(v251_8),&(v251_12));
            v250_7.join_into((v251_13).clone());
            }
            v250_7_cursor.ascend(1);
          }
          drop(v250_7_cursor);
          drop(v250_6);
          map_map_kernels::compose(&(v249_5),&(v250_7))
        };
        drop(v249_5);
        let v249_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v249_2));
        drop(v249_2);
        let v249_10: Space = if map_kernels::has_head(&(v249_9)) { singleton(&[]) } else { Space::new() };
        drop(v249_9);
        let v249_13: Space = if (v249_10).is_empty() { Space::new() } else {
          let v254_11: Space = map_kernels::unwrap(&(v248_11),&(v248_12_head));
          let v254_12: Space = map_map_kernels::subtract(&(v254_11),&(*CONSTANT_5));
          drop(v254_11);
          map_map_kernels::compose(&(v249_10),&(v254_12))
        };
        drop(v249_10);
        let v249_14: Space = map_map_kernels::unite(&(v249_8),&(v249_13));
        drop(v249_13);
        v248_12.join_into((v249_14).clone());
        }
        v248_12_cursor.ascend(1);
      }
      drop(v248_12_cursor);
      drop(v248_6);
      drop(v248_11);
      map_map_kernels::compose(&(v237_10),&(v248_12))
    };
    drop(v237_10);
    let v237_14: Space = map_map_kernels::unite(&(v237_8),&(v237_13));
    v236_27.join_into((v237_14).clone());
    }
    v236_27_cursor.ascend(1);
  }
  drop(v236_27_cursor);
  drop(v236_23);
  (v236_27).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v255_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v255_9: Space = map_kernels::unwrap(&(v255_7),&(*CONSTANT_4));
  drop(v255_7);
  let v255_10: Space = map_kernels::unwrap(&(v255_9),&(*p0));
  drop(v255_9);
  let mut v255_21 = Space::new();
  let mut v255_21_cursor = (*s0).read_zipper();
  for v255_21_byte in v255_21_cursor.child_mask().iter() {
    v255_21_cursor.descend_to_byte(v255_21_byte);
    {
    let v255_21_tail = v255_21_cursor.fork_read_zipper();
    let v255_21_head = Path::from_slice(&[v255_21_byte]);
    let v256_2: Space = singleton(&(v255_21_head));
    let v256_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v256_2));
    let v256_4: Space = if map_kernels::has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
    drop(v256_3);
    let v256_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v256_4));
    drop(v256_4);
    let v256_8: Space = if (v256_5).is_empty() { Space::new() } else {
      let v257_6: Path = concat_path(&(*p0),&(v255_21_head));
      let mut v257_7 = Space::new();
      let mut v257_7_cursor = (v255_21_tail).read_zipper();
      for v257_7_byte in v257_7_cursor.child_mask().iter() {
        v257_7_cursor.descend_to_byte(v257_7_byte);
        {
        let v257_7_tail = v257_7_cursor.fork_read_zipper();
        let v257_7_head = Path::from_slice(&[v257_7_byte]);
        let v258_2: Space = singleton(&(v257_7_head));
        let v258_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v258_2));
        let v258_4: Space = if map_kernels::has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
        drop(v258_3);
        let v258_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v258_4));
        drop(v258_4);
        let v258_8: Space = if (v258_5).is_empty() { Space::new() } else {
          let v259_6: Path = concat_path(&(v257_6),&(v257_7_head));
          let mut v259_7 = Space::new();
          let mut v259_7_cursor = (v257_7_tail).read_zipper();
          for v259_7_byte in v259_7_cursor.child_mask().iter() {
            v259_7_cursor.descend_to_byte(v259_7_byte);
            {
            let v259_7_tail = v259_7_cursor.fork_read_zipper();
            let v259_7_head = Path::from_slice(&[v259_7_byte]);
            let v260_2: Space = singleton(&(v259_7_head));
            let v260_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v260_2));
            let v260_4: Space = if map_kernels::has_head(&(v260_3)) { singleton(&[]) } else { Space::new() };
            drop(v260_3);
            let v260_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v260_4));
            drop(v260_4);
            let v260_8: Space = if (v260_5).is_empty() { Space::new() } else {
              let v261_6: Path = concat_path(&(v259_6),&(v259_7_head));
              let v261_7: Space = routine_27(c, &(v261_6), &(v259_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v260_5),&(v261_7))
            };
            drop(v260_5);
            let v260_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v260_2));
            drop(v260_2);
            let v260_10: Space = if map_kernels::has_head(&(v260_9)) { singleton(&[]) } else { Space::new() };
            drop(v260_9);
            let v260_12: Space = if (v260_10).is_empty() { Space::new() } else {
              let v262_6: Path = concat_path(&(v259_6),&(v259_7_head));
              let v262_11: Space = routine_28(c, &(v262_6), &(v259_7_tail).make_space(), &(*s1));
              drop(v262_6);
              map_map_kernels::compose(&(v260_10),&(v262_11))
            };
            drop(v260_10);
            let v260_13: Space = map_map_kernels::unite(&(v260_8),&(v260_12));
            v259_7.join_into((v260_13).clone());
            }
            v259_7_cursor.ascend(1);
          }
          drop(v259_7_cursor);
          map_map_kernels::compose(&(v258_5),&(v259_7))
        };
        drop(v258_5);
        let v258_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v258_2));
        drop(v258_2);
        let v258_10: Space = if map_kernels::has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
        drop(v258_9);
        let v258_12: Space = if (v258_10).is_empty() { Space::new() } else {
          let v263_6: Path = concat_path(&(v257_6),&(v257_7_head));
          let mut v263_11 = Space::new();
          let mut v263_11_cursor = (v257_7_tail).read_zipper();
          for v263_11_byte in v263_11_cursor.child_mask().iter() {
            v263_11_cursor.descend_to_byte(v263_11_byte);
            {
            let v263_11_tail = v263_11_cursor.fork_read_zipper();
            let v263_11_head = Path::from_slice(&[v263_11_byte]);
            let v264_2: Space = singleton(&(v263_11_head));
            let v264_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v264_2));
            let v264_4: Space = if map_kernels::has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
            drop(v264_3);
            let v264_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v264_4));
            drop(v264_4);
            let v264_8: Space = if (v264_5).is_empty() { Space::new() } else {
              let v265_6: Path = concat_path(&(v263_6),&(v263_11_head));
              let v265_7: Space = routine_27(c, &(v265_6), &(v263_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v264_5),&(v265_7))
            };
            drop(v264_5);
            let v264_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v264_2));
            drop(v264_2);
            let v264_10: Space = if map_kernels::has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
            drop(v264_9);
            let v264_12: Space = if (v264_10).is_empty() { Space::new() } else {
              let v266_6: Path = concat_path(&(v263_6),&(v263_11_head));
              let v266_11: Space = routine_24(c, &(v266_6), &(v263_11_tail).make_space(), &(*s1));
              drop(v266_6);
              map_map_kernels::compose(&(v264_10),&(v266_11))
            };
            drop(v264_10);
            let v264_13: Space = map_map_kernels::unite(&(v264_8),&(v264_12));
            v263_11.join_into((v264_13).clone());
            }
            v263_11_cursor.ascend(1);
          }
          drop(v263_11_cursor);
          drop(v263_6);
          map_map_kernels::compose(&(v258_10),&(v263_11))
        };
        drop(v258_10);
        let v258_13: Space = map_map_kernels::unite(&(v258_8),&(v258_12));
        v257_7.join_into((v258_13).clone());
        }
        v257_7_cursor.ascend(1);
      }
      drop(v257_7_cursor);
      drop(v257_6);
      map_map_kernels::compose(&(v256_5),&(v257_7))
    };
    drop(v256_5);
    let v256_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v256_2));
    drop(v256_2);
    let v256_10: Space = if map_kernels::has_head(&(v256_9)) { singleton(&[]) } else { Space::new() };
    drop(v256_9);
    let v256_13: Space = if (v256_10).is_empty() { Space::new() } else {
      let v267_11: Space = map_kernels::unwrap(&(v255_10),&(v255_21_head));
      let v267_12: Space = map_map_kernels::subtract(&(v267_11),&(*CONSTANT_5));
      drop(v267_11);
      map_map_kernels::compose(&(v256_10),&(v267_12))
    };
    drop(v256_10);
    let v256_14: Space = map_map_kernels::unite(&(v256_8),&(v256_13));
    drop(v256_13);
    v255_21.join_into((v256_14).clone());
    }
    v255_21_cursor.ascend(1);
  }
  drop(v255_21_cursor);
  drop(v255_10);
  (v255_21).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v268_24 = Space::new();
  let mut v268_24_cursor = (*s0).read_zipper();
  for v268_24_byte in v268_24_cursor.child_mask().iter() {
    v268_24_cursor.descend_to_byte(v268_24_byte);
    {
    let v268_24_tail = v268_24_cursor.fork_read_zipper();
    let v268_24_head = Path::from_slice(&[v268_24_byte]);
    let v269_2: Space = singleton(&(v268_24_head));
    let v269_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v269_2));
    let v269_4: Space = if map_kernels::has_head(&(v269_3)) { singleton(&[]) } else { Space::new() };
    drop(v269_3);
    let v269_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v269_4));
    drop(v269_4);
    let v269_8: Space = if (v269_5).is_empty() { Space::new() } else {
      let v270_6: Path = concat_path(&(*p0),&(v268_24_head));
      let mut v270_7 = Space::new();
      let mut v270_7_cursor = (v268_24_tail).read_zipper();
      for v270_7_byte in v270_7_cursor.child_mask().iter() {
        v270_7_cursor.descend_to_byte(v270_7_byte);
        {
        let v270_7_tail = v270_7_cursor.fork_read_zipper();
        let v270_7_head = Path::from_slice(&[v270_7_byte]);
        let v271_2: Space = singleton(&(v270_7_head));
        let v271_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v271_2));
        let v271_4: Space = if map_kernels::has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
        drop(v271_3);
        let v271_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v271_4));
        drop(v271_4);
        let v271_8: Space = if (v271_5).is_empty() { Space::new() } else {
          let v272_6: Path = concat_path(&(v270_6),&(v270_7_head));
          let mut v272_7 = Space::new();
          let mut v272_7_cursor = (v270_7_tail).read_zipper();
          for v272_7_byte in v272_7_cursor.child_mask().iter() {
            v272_7_cursor.descend_to_byte(v272_7_byte);
            {
            let v272_7_tail = v272_7_cursor.fork_read_zipper();
            let v272_7_head = Path::from_slice(&[v272_7_byte]);
            let v273_2: Space = singleton(&(v272_7_head));
            let v273_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v273_2));
            let v273_4: Space = if map_kernels::has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
            drop(v273_3);
            let v273_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v273_4));
            drop(v273_4);
            let v273_8: Space = if (v273_5).is_empty() { Space::new() } else {
              let v274_6: Path = concat_path(&(v272_6),&(v272_7_head));
              let v274_7: Space = routine_29(c, &(v274_6), &(v272_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v273_5),&(v274_7))
            };
            drop(v273_5);
            let v273_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v273_2));
            drop(v273_2);
            let v273_10: Space = if map_kernels::has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
            drop(v273_9);
            let v273_12: Space = if (v273_10).is_empty() { Space::new() } else {
              let v275_6: Path = concat_path(&(v272_6),&(v272_7_head));
              let v275_11: Space = routine_30(c, &(v275_6), &(v272_7_tail).make_space(), &(*s1));
              drop(v275_6);
              map_map_kernels::compose(&(v273_10),&(v275_11))
            };
            drop(v273_10);
            let v273_13: Space = map_map_kernels::unite(&(v273_8),&(v273_12));
            v272_7.join_into((v273_13).clone());
            }
            v272_7_cursor.ascend(1);
          }
          drop(v272_7_cursor);
          map_map_kernels::compose(&(v271_5),&(v272_7))
        };
        drop(v271_5);
        let v271_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v271_2));
        drop(v271_2);
        let v271_10: Space = if map_kernels::has_head(&(v271_9)) { singleton(&[]) } else { Space::new() };
        drop(v271_9);
        let v271_12: Space = if (v271_10).is_empty() { Space::new() } else {
          let v276_6: Path = concat_path(&(v270_6),&(v270_7_head));
          let mut v276_11 = Space::new();
          let mut v276_11_cursor = (v270_7_tail).read_zipper();
          for v276_11_byte in v276_11_cursor.child_mask().iter() {
            v276_11_cursor.descend_to_byte(v276_11_byte);
            {
            let v276_11_tail = v276_11_cursor.fork_read_zipper();
            let v276_11_head = Path::from_slice(&[v276_11_byte]);
            let v277_2: Space = singleton(&(v276_11_head));
            let v277_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v277_2));
            let v277_4: Space = if map_kernels::has_head(&(v277_3)) { singleton(&[]) } else { Space::new() };
            drop(v277_3);
            let v277_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v277_4));
            drop(v277_4);
            let v277_8: Space = if (v277_5).is_empty() { Space::new() } else {
              let v278_6: Path = concat_path(&(v276_6),&(v276_11_head));
              let v278_7: Space = routine_29(c, &(v278_6), &(v276_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v277_5),&(v278_7))
            };
            drop(v277_5);
            let v277_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v277_2));
            drop(v277_2);
            let v277_10: Space = if map_kernels::has_head(&(v277_9)) { singleton(&[]) } else { Space::new() };
            drop(v277_9);
            let v277_12: Space = if (v277_10).is_empty() { Space::new() } else {
              let v279_6: Path = concat_path(&(v276_6),&(v276_11_head));
              let v279_11: Space = routine_9(c, &(v279_6), &(v276_11_tail).make_space(), &(*s1));
              drop(v279_6);
              map_map_kernels::compose(&(v277_10),&(v279_11))
            };
            drop(v277_10);
            let v277_13: Space = map_map_kernels::unite(&(v277_8),&(v277_12));
            v276_11.join_into((v277_13).clone());
            }
            v276_11_cursor.ascend(1);
          }
          drop(v276_11_cursor);
          drop(v276_6);
          map_map_kernels::compose(&(v271_10),&(v276_11))
        };
        drop(v271_10);
        let v271_13: Space = map_map_kernels::unite(&(v271_8),&(v271_12));
        v270_7.join_into((v271_13).clone());
        }
        v270_7_cursor.ascend(1);
      }
      drop(v270_7_cursor);
      map_map_kernels::compose(&(v269_5),&(v270_7))
    };
    drop(v269_5);
    let v269_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v269_2));
    drop(v269_2);
    let v269_10: Space = if map_kernels::has_head(&(v269_9)) { singleton(&[]) } else { Space::new() };
    drop(v269_9);
    let v269_12: Space = if (v269_10).is_empty() { Space::new() } else {
      let v280_6: Path = concat_path(&(*p0),&(v268_24_head));
      let mut v280_11 = Space::new();
      let mut v280_11_cursor = (v268_24_tail).read_zipper();
      for v280_11_byte in v280_11_cursor.child_mask().iter() {
        v280_11_cursor.descend_to_byte(v280_11_byte);
        {
        let v280_11_tail = v280_11_cursor.fork_read_zipper();
        let v280_11_head = Path::from_slice(&[v280_11_byte]);
        let v281_2: Space = singleton(&(v280_11_head));
        let v281_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v281_2));
        let v281_4: Space = if map_kernels::has_head(&(v281_3)) { singleton(&[]) } else { Space::new() };
        drop(v281_3);
        let v281_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v281_4));
        drop(v281_4);
        let v281_8: Space = if (v281_5).is_empty() { Space::new() } else {
          let v282_6: Path = concat_path(&(v280_6),&(v280_11_head));
          let mut v282_7 = Space::new();
          let mut v282_7_cursor = (v280_11_tail).read_zipper();
          for v282_7_byte in v282_7_cursor.child_mask().iter() {
            v282_7_cursor.descend_to_byte(v282_7_byte);
            {
            let v282_7_tail = v282_7_cursor.fork_read_zipper();
            let v282_7_head = Path::from_slice(&[v282_7_byte]);
            let v283_2: Space = singleton(&(v282_7_head));
            let v283_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v283_2));
            let v283_4: Space = if map_kernels::has_head(&(v283_3)) { singleton(&[]) } else { Space::new() };
            drop(v283_3);
            let v283_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v283_4));
            drop(v283_4);
            let v283_8: Space = if (v283_5).is_empty() { Space::new() } else {
              let v284_6: Path = concat_path(&(v282_6),&(v282_7_head));
              let v284_7: Space = routine_29(c, &(v284_6), &(v282_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v283_5),&(v284_7))
            };
            drop(v283_5);
            let v283_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v283_2));
            drop(v283_2);
            let v283_10: Space = if map_kernels::has_head(&(v283_9)) { singleton(&[]) } else { Space::new() };
            drop(v283_9);
            let v283_12: Space = if (v283_10).is_empty() { Space::new() } else {
              let v285_6: Path = concat_path(&(v282_6),&(v282_7_head));
              let v285_11: Space = routine_30(c, &(v285_6), &(v282_7_tail).make_space(), &(*s1));
              drop(v285_6);
              map_map_kernels::compose(&(v283_10),&(v285_11))
            };
            drop(v283_10);
            let v283_13: Space = map_map_kernels::unite(&(v283_8),&(v283_12));
            v282_7.join_into((v283_13).clone());
            }
            v282_7_cursor.ascend(1);
          }
          drop(v282_7_cursor);
          map_map_kernels::compose(&(v281_5),&(v282_7))
        };
        drop(v281_5);
        let v281_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v281_2));
        drop(v281_2);
        let v281_10: Space = if map_kernels::has_head(&(v281_9)) { singleton(&[]) } else { Space::new() };
        drop(v281_9);
        let v281_12: Space = if (v281_10).is_empty() { Space::new() } else {
          let mut v286_11 = Space::new();
          let mut v286_11_cursor = (v280_11_tail).read_zipper();
          for v286_11_byte in v286_11_cursor.child_mask().iter() {
            v286_11_cursor.descend_to_byte(v286_11_byte);
            {
            let v286_11_tail = v286_11_cursor.fork_read_zipper();
            let v286_11_head = Path::from_slice(&[v286_11_byte]);
            let v287_2: Space = singleton(&(v286_11_head));
            let v287_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v287_2));
            let v287_4: Space = if map_kernels::has_head(&(v287_3)) { singleton(&[]) } else { Space::new() };
            drop(v287_3);
            let v287_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v287_4));
            drop(v287_4);
            let v287_7: Space = if (v287_5).is_empty() { Space::new() } else {
              let v288_6: Space = routine_10(c, &(v286_11_head), &(v286_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v287_5),&(v288_6))
            };
            drop(v287_5);
            let v287_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v287_2));
            drop(v287_2);
            let v287_9: Space = if map_kernels::has_head(&(v287_8)) { singleton(&[]) } else { Space::new() };
            drop(v287_8);
            let v287_11: Space = if (v287_9).is_empty() { Space::new() } else {
              let v289_10: Space = routine_11(c, &(v286_11_head), &(v286_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v287_9),&(v289_10))
            };
            drop(v287_9);
            let v287_12: Space = map_map_kernels::unite(&(v287_7),&(v287_11));
            v286_11.join_into((v287_12).clone());
            }
            v286_11_cursor.ascend(1);
          }
          drop(v286_11_cursor);
          map_map_kernels::compose(&(v281_10),&(v286_11))
        };
        drop(v281_10);
        let v290_6: Path = concat_path(&(v280_6),&(v280_11_head));
        let v281_13: Space = map_kernels::wrap(&(v281_12),&(v290_6));
        let v281_14: Space = map_map_kernels::unite(&(v281_8),&(v281_13));
        v280_11.join_into((v281_14).clone());
        }
        v280_11_cursor.ascend(1);
      }
      drop(v280_11_cursor);
      drop(v280_6);
      map_map_kernels::compose(&(v269_10),&(v280_11))
    };
    drop(v269_10);
    let v269_13: Space = map_map_kernels::unite(&(v269_8),&(v269_12));
    v268_24.join_into((v269_13).clone());
    }
    v268_24_cursor.ascend(1);
  }
  drop(v268_24_cursor);
  (v268_24).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v291_24 = Space::new();
  let mut v291_24_cursor = (*s0).read_zipper();
  for v291_24_byte in v291_24_cursor.child_mask().iter() {
    v291_24_cursor.descend_to_byte(v291_24_byte);
    {
    let v291_24_tail = v291_24_cursor.fork_read_zipper();
    let v291_24_head = Path::from_slice(&[v291_24_byte]);
    let v292_2: Space = singleton(&(v291_24_head));
    let v292_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v292_2));
    let v292_4: Space = if map_kernels::has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
    drop(v292_3);
    let v292_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v292_4));
    drop(v292_4);
    let v292_8: Space = if (v292_5).is_empty() { Space::new() } else {
      let v293_6: Path = concat_path(&(*p0),&(v291_24_head));
      let mut v293_7 = Space::new();
      let mut v293_7_cursor = (v291_24_tail).read_zipper();
      for v293_7_byte in v293_7_cursor.child_mask().iter() {
        v293_7_cursor.descend_to_byte(v293_7_byte);
        {
        let v293_7_tail = v293_7_cursor.fork_read_zipper();
        let v293_7_head = Path::from_slice(&[v293_7_byte]);
        let v294_2: Space = singleton(&(v293_7_head));
        let v294_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v294_2));
        let v294_4: Space = if map_kernels::has_head(&(v294_3)) { singleton(&[]) } else { Space::new() };
        drop(v294_3);
        let v294_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v294_4));
        drop(v294_4);
        let v294_8: Space = if (v294_5).is_empty() { Space::new() } else {
          let v295_6: Path = concat_path(&(v293_6),&(v293_7_head));
          let mut v295_7 = Space::new();
          let mut v295_7_cursor = (v293_7_tail).read_zipper();
          for v295_7_byte in v295_7_cursor.child_mask().iter() {
            v295_7_cursor.descend_to_byte(v295_7_byte);
            {
            let v295_7_tail = v295_7_cursor.fork_read_zipper();
            let v295_7_head = Path::from_slice(&[v295_7_byte]);
            let v296_2: Space = singleton(&(v295_7_head));
            let v296_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v296_2));
            let v296_4: Space = if map_kernels::has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
            drop(v296_3);
            let v296_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v296_4));
            drop(v296_4);
            let v296_8: Space = if (v296_5).is_empty() { Space::new() } else {
              let v297_6: Path = concat_path(&(v295_6),&(v295_7_head));
              let v297_7: Space = routine_29(c, &(v297_6), &(v295_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v296_5),&(v297_7))
            };
            drop(v296_5);
            let v296_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v296_2));
            drop(v296_2);
            let v296_10: Space = if map_kernels::has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
            drop(v296_9);
            let v296_12: Space = if (v296_10).is_empty() { Space::new() } else {
              let v298_6: Path = concat_path(&(v295_6),&(v295_7_head));
              let v298_11: Space = routine_30(c, &(v298_6), &(v295_7_tail).make_space(), &(*s1));
              drop(v298_6);
              map_map_kernels::compose(&(v296_10),&(v298_11))
            };
            drop(v296_10);
            let v296_13: Space = map_map_kernels::unite(&(v296_8),&(v296_12));
            v295_7.join_into((v296_13).clone());
            }
            v295_7_cursor.ascend(1);
          }
          drop(v295_7_cursor);
          map_map_kernels::compose(&(v294_5),&(v295_7))
        };
        drop(v294_5);
        let v294_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v294_2));
        drop(v294_2);
        let v294_10: Space = if map_kernels::has_head(&(v294_9)) { singleton(&[]) } else { Space::new() };
        drop(v294_9);
        let v294_12: Space = if (v294_10).is_empty() { Space::new() } else {
          let v299_6: Path = concat_path(&(v293_6),&(v293_7_head));
          let mut v299_11 = Space::new();
          let mut v299_11_cursor = (v293_7_tail).read_zipper();
          for v299_11_byte in v299_11_cursor.child_mask().iter() {
            v299_11_cursor.descend_to_byte(v299_11_byte);
            {
            let v299_11_tail = v299_11_cursor.fork_read_zipper();
            let v299_11_head = Path::from_slice(&[v299_11_byte]);
            let v300_2: Space = singleton(&(v299_11_head));
            let v300_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v300_2));
            let v300_4: Space = if map_kernels::has_head(&(v300_3)) { singleton(&[]) } else { Space::new() };
            drop(v300_3);
            let v300_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v300_4));
            drop(v300_4);
            let v300_8: Space = if (v300_5).is_empty() { Space::new() } else {
              let v301_6: Path = concat_path(&(v299_6),&(v299_11_head));
              let v301_7: Space = routine_29(c, &(v301_6), &(v299_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v300_5),&(v301_7))
            };
            drop(v300_5);
            let v300_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v300_2));
            drop(v300_2);
            let v300_10: Space = if map_kernels::has_head(&(v300_9)) { singleton(&[]) } else { Space::new() };
            drop(v300_9);
            let v300_12: Space = if (v300_10).is_empty() { Space::new() } else {
              let v302_6: Path = concat_path(&(v299_6),&(v299_11_head));
              let v302_11: Space = routine_9(c, &(v302_6), &(v299_11_tail).make_space(), &(*s1));
              drop(v302_6);
              map_map_kernels::compose(&(v300_10),&(v302_11))
            };
            drop(v300_10);
            let v300_13: Space = map_map_kernels::unite(&(v300_8),&(v300_12));
            v299_11.join_into((v300_13).clone());
            }
            v299_11_cursor.ascend(1);
          }
          drop(v299_11_cursor);
          drop(v299_6);
          map_map_kernels::compose(&(v294_10),&(v299_11))
        };
        drop(v294_10);
        let v294_13: Space = map_map_kernels::unite(&(v294_8),&(v294_12));
        v293_7.join_into((v294_13).clone());
        }
        v293_7_cursor.ascend(1);
      }
      drop(v293_7_cursor);
      map_map_kernels::compose(&(v292_5),&(v293_7))
    };
    drop(v292_5);
    let v292_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v292_2));
    drop(v292_2);
    let v292_10: Space = if map_kernels::has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
    drop(v292_9);
    let v292_12: Space = if (v292_10).is_empty() { Space::new() } else {
      let mut v303_11 = Space::new();
      let mut v303_11_cursor = (v291_24_tail).read_zipper();
      for v303_11_byte in v303_11_cursor.child_mask().iter() {
        v303_11_cursor.descend_to_byte(v303_11_byte);
        {
        let v303_11_tail = v303_11_cursor.fork_read_zipper();
        let v303_11_head = Path::from_slice(&[v303_11_byte]);
        let v304_2: Space = singleton(&(v303_11_head));
        let v304_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v304_2));
        let v304_4: Space = if map_kernels::has_head(&(v304_3)) { singleton(&[]) } else { Space::new() };
        drop(v304_3);
        let v304_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v304_4));
        drop(v304_4);
        let v304_7: Space = if (v304_5).is_empty() { Space::new() } else {
          let mut v305_6 = Space::new();
          let mut v305_6_cursor = (v303_11_tail).read_zipper();
          for v305_6_byte in v305_6_cursor.child_mask().iter() {
            v305_6_cursor.descend_to_byte(v305_6_byte);
            {
            let v305_6_tail = v305_6_cursor.fork_read_zipper();
            let v305_6_head = Path::from_slice(&[v305_6_byte]);
            let v306_2: Space = singleton(&(v305_6_head));
            let v306_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v306_2));
            let v306_4: Space = if map_kernels::has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
            drop(v306_3);
            let v306_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v306_4));
            drop(v306_4);
            let v306_8: Space = if (v306_5).is_empty() { Space::new() } else {
              let v307_6: Path = concat_path(&(v303_11_head),&(v305_6_head));
              let v307_7: Space = routine_31(c, &(v307_6), &(v305_6_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v306_5),&(v307_7))
            };
            drop(v306_5);
            let v306_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v306_2));
            drop(v306_2);
            let v306_10: Space = if map_kernels::has_head(&(v306_9)) { singleton(&[]) } else { Space::new() };
            drop(v306_9);
            let v306_12: Space = if (v306_10).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v303_11_head),&(v305_6_head));
              let v308_11: Space = routine_32(c, &(v308_6), &(v305_6_tail).make_space(), &(*s1));
              drop(v308_6);
              map_map_kernels::compose(&(v306_10),&(v308_11))
            };
            drop(v306_10);
            let v306_13: Space = map_map_kernels::unite(&(v306_8),&(v306_12));
            v305_6.join_into((v306_13).clone());
            }
            v305_6_cursor.ascend(1);
          }
          drop(v305_6_cursor);
          map_map_kernels::compose(&(v304_5),&(v305_6))
        };
        drop(v304_5);
        let v304_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v304_2));
        drop(v304_2);
        let v304_9: Space = if map_kernels::has_head(&(v304_8)) { singleton(&[]) } else { Space::new() };
        drop(v304_8);
        let v304_11: Space = if (v304_9).is_empty() { Space::new() } else {
          let mut v309_10 = Space::new();
          let mut v309_10_cursor = (v303_11_tail).read_zipper();
          for v309_10_byte in v309_10_cursor.child_mask().iter() {
            v309_10_cursor.descend_to_byte(v309_10_byte);
            {
            let v309_10_tail = v309_10_cursor.fork_read_zipper();
            let v309_10_head = Path::from_slice(&[v309_10_byte]);
            let v310_2: Space = singleton(&(v309_10_head));
            let v310_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v310_2));
            let v310_4: Space = if map_kernels::has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
            drop(v310_3);
            let v310_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v310_4));
            drop(v310_4);
            let v310_8: Space = if (v310_5).is_empty() { Space::new() } else {
              let v311_6: Path = concat_path(&(v303_11_head),&(v309_10_head));
              let v311_7: Space = routine_31(c, &(v311_6), &(v309_10_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v310_5),&(v311_7))
            };
            drop(v310_5);
            let v310_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v310_2));
            drop(v310_2);
            let v310_10: Space = if map_kernels::has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
            drop(v310_9);
            let v310_12: Space = if (v310_10).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v303_11_head),&(v309_10_head));
              let v312_11: Space = routine_33(c, &(v312_6), &(v309_10_tail).make_space(), &(*s1));
              drop(v312_6);
              map_map_kernels::compose(&(v310_10),&(v312_11))
            };
            drop(v310_10);
            let v310_13: Space = map_map_kernels::unite(&(v310_8),&(v310_12));
            v309_10.join_into((v310_13).clone());
            }
            v309_10_cursor.ascend(1);
          }
          drop(v309_10_cursor);
          map_map_kernels::compose(&(v304_9),&(v309_10))
        };
        drop(v304_9);
        let v304_12: Space = map_map_kernels::unite(&(v304_7),&(v304_11));
        v303_11.join_into((v304_12).clone());
        }
        v303_11_cursor.ascend(1);
      }
      drop(v303_11_cursor);
      map_map_kernels::compose(&(v292_10),&(v303_11))
    };
    drop(v292_10);
    let v313_6: Path = concat_path(&(*p0),&(v291_24_head));
    let v292_13: Space = map_kernels::wrap(&(v292_12),&(v313_6));
    let v292_14: Space = map_map_kernels::unite(&(v292_8),&(v292_13));
    v291_24.join_into((v292_14).clone());
    }
    v291_24_cursor.ascend(1);
  }
  drop(v291_24_cursor);
  (v291_24).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v314_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v314_22: Space = map_kernels::unwrap(&(v314_21),&(*CONSTANT_4));
  drop(v314_21);
  let mut v314_26 = Space::new();
  let mut v314_26_cursor = (*s0).read_zipper();
  for v314_26_byte in v314_26_cursor.child_mask().iter() {
    v314_26_cursor.descend_to_byte(v314_26_byte);
    {
    let v314_26_tail = v314_26_cursor.fork_read_zipper();
    let v314_26_head = Path::from_slice(&[v314_26_byte]);
    let v315_2: Space = singleton(&(v314_26_head));
    let v315_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v315_2));
    let v315_4: Space = if map_kernels::has_head(&(v315_3)) { singleton(&[]) } else { Space::new() };
    drop(v315_3);
    let v315_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v315_4));
    drop(v315_4);
    let v315_7: Space = if (v315_5).is_empty() { Space::new() } else {
      let mut v316_6 = Space::new();
      let mut v316_6_cursor = (v314_26_tail).read_zipper();
      for v316_6_byte in v316_6_cursor.child_mask().iter() {
        v316_6_cursor.descend_to_byte(v316_6_byte);
        {
        let v316_6_tail = v316_6_cursor.fork_read_zipper();
        let v316_6_head = Path::from_slice(&[v316_6_byte]);
        let v317_2: Space = singleton(&(v316_6_head));
        let v317_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v317_2));
        let v317_4: Space = if map_kernels::has_head(&(v317_3)) { singleton(&[]) } else { Space::new() };
        drop(v317_3);
        let v317_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v317_4));
        drop(v317_4);
        let v317_8: Space = if (v317_5).is_empty() { Space::new() } else {
          let v318_6: Path = concat_path(&(v314_26_head),&(v316_6_head));
          let mut v318_7 = Space::new();
          let mut v318_7_cursor = (v316_6_tail).read_zipper();
          for v318_7_byte in v318_7_cursor.child_mask().iter() {
            v318_7_cursor.descend_to_byte(v318_7_byte);
            {
            let v318_7_tail = v318_7_cursor.fork_read_zipper();
            let v318_7_head = Path::from_slice(&[v318_7_byte]);
            let v319_2: Space = singleton(&(v318_7_head));
            let v319_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v319_2));
            let v319_4: Space = if map_kernels::has_head(&(v319_3)) { singleton(&[]) } else { Space::new() };
            drop(v319_3);
            let v319_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v319_4));
            drop(v319_4);
            let v319_8: Space = if (v319_5).is_empty() { Space::new() } else {
              let v320_6: Path = concat_path(&(v318_6),&(v318_7_head));
              let v320_7: Space = routine_34(c, &(v320_6), &(v318_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v319_5),&(v320_7))
            };
            drop(v319_5);
            let v319_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v319_2));
            drop(v319_2);
            let v319_10: Space = if map_kernels::has_head(&(v319_9)) { singleton(&[]) } else { Space::new() };
            drop(v319_9);
            let v319_12: Space = if (v319_10).is_empty() { Space::new() } else {
              let v321_6: Path = concat_path(&(v318_6),&(v318_7_head));
              let v321_11: Space = routine_35(c, &(v321_6), &(v318_7_tail).make_space(), &(*s1));
              drop(v321_6);
              map_map_kernels::compose(&(v319_10),&(v321_11))
            };
            drop(v319_10);
            let v319_13: Space = map_map_kernels::unite(&(v319_8),&(v319_12));
            v318_7.join_into((v319_13).clone());
            }
            v318_7_cursor.ascend(1);
          }
          drop(v318_7_cursor);
          map_map_kernels::compose(&(v317_5),&(v318_7))
        };
        drop(v317_5);
        let v317_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v317_2));
        drop(v317_2);
        let v317_10: Space = if map_kernels::has_head(&(v317_9)) { singleton(&[]) } else { Space::new() };
        drop(v317_9);
        let v317_12: Space = if (v317_10).is_empty() { Space::new() } else {
          let v322_6: Path = concat_path(&(v314_26_head),&(v316_6_head));
          let mut v322_11 = Space::new();
          let mut v322_11_cursor = (v316_6_tail).read_zipper();
          for v322_11_byte in v322_11_cursor.child_mask().iter() {
            v322_11_cursor.descend_to_byte(v322_11_byte);
            {
            let v322_11_tail = v322_11_cursor.fork_read_zipper();
            let v322_11_head = Path::from_slice(&[v322_11_byte]);
            let v323_2: Space = singleton(&(v322_11_head));
            let v323_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v323_2));
            let v323_4: Space = if map_kernels::has_head(&(v323_3)) { singleton(&[]) } else { Space::new() };
            drop(v323_3);
            let v323_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v323_4));
            drop(v323_4);
            let v323_8: Space = if (v323_5).is_empty() { Space::new() } else {
              let v324_6: Path = concat_path(&(v322_6),&(v322_11_head));
              let v324_7: Space = routine_34(c, &(v324_6), &(v322_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v323_5),&(v324_7))
            };
            drop(v323_5);
            let v323_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v323_2));
            drop(v323_2);
            let v323_10: Space = if map_kernels::has_head(&(v323_9)) { singleton(&[]) } else { Space::new() };
            drop(v323_9);
            let v323_12: Space = if (v323_10).is_empty() { Space::new() } else {
              let v325_6: Path = concat_path(&(v322_6),&(v322_11_head));
              let v325_11: Space = routine_33(c, &(v325_6), &(v322_11_tail).make_space(), &(*s1));
              drop(v325_6);
              map_map_kernels::compose(&(v323_10),&(v325_11))
            };
            drop(v323_10);
            let v323_13: Space = map_map_kernels::unite(&(v323_8),&(v323_12));
            v322_11.join_into((v323_13).clone());
            }
            v322_11_cursor.ascend(1);
          }
          drop(v322_11_cursor);
          drop(v322_6);
          map_map_kernels::compose(&(v317_10),&(v322_11))
        };
        drop(v317_10);
        let v317_13: Space = map_map_kernels::unite(&(v317_8),&(v317_12));
        v316_6.join_into((v317_13).clone());
        }
        v316_6_cursor.ascend(1);
      }
      drop(v316_6_cursor);
      map_map_kernels::compose(&(v315_5),&(v316_6))
    };
    drop(v315_5);
    let v315_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v315_2));
    drop(v315_2);
    let v315_9: Space = if map_kernels::has_head(&(v315_8)) { singleton(&[]) } else { Space::new() };
    drop(v315_8);
    let v315_12: Space = if (v315_9).is_empty() { Space::new() } else {
      let v326_10: Space = map_kernels::unwrap(&(v314_22),&(v314_26_head));
      let mut v326_11 = Space::new();
      let mut v326_11_cursor = (v314_26_tail).read_zipper();
      for v326_11_byte in v326_11_cursor.child_mask().iter() {
        v326_11_cursor.descend_to_byte(v326_11_byte);
        {
        let v326_11_tail = v326_11_cursor.fork_read_zipper();
        let v326_11_head = Path::from_slice(&[v326_11_byte]);
        let v327_2: Space = singleton(&(v326_11_head));
        let v327_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v327_2));
        let v327_4: Space = if map_kernels::has_head(&(v327_3)) { singleton(&[]) } else { Space::new() };
        drop(v327_3);
        let v327_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v327_4));
        drop(v327_4);
        let v327_8: Space = if (v327_5).is_empty() { Space::new() } else {
          let v328_6: Path = concat_path(&(v314_26_head),&(v326_11_head));
          let mut v328_7 = Space::new();
          let mut v328_7_cursor = (v326_11_tail).read_zipper();
          for v328_7_byte in v328_7_cursor.child_mask().iter() {
            v328_7_cursor.descend_to_byte(v328_7_byte);
            {
            let v328_7_tail = v328_7_cursor.fork_read_zipper();
            let v328_7_head = Path::from_slice(&[v328_7_byte]);
            let v329_2: Space = singleton(&(v328_7_head));
            let v329_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v329_2));
            let v329_4: Space = if map_kernels::has_head(&(v329_3)) { singleton(&[]) } else { Space::new() };
            drop(v329_3);
            let v329_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v329_4));
            drop(v329_4);
            let v329_8: Space = if (v329_5).is_empty() { Space::new() } else {
              let v330_6: Path = concat_path(&(v328_6),&(v328_7_head));
              let v330_7: Space = routine_34(c, &(v330_6), &(v328_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v329_5),&(v330_7))
            };
            drop(v329_5);
            let v329_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v329_2));
            drop(v329_2);
            let v329_10: Space = if map_kernels::has_head(&(v329_9)) { singleton(&[]) } else { Space::new() };
            drop(v329_9);
            let v329_12: Space = if (v329_10).is_empty() { Space::new() } else {
              let v331_6: Path = concat_path(&(v328_6),&(v328_7_head));
              let v331_11: Space = routine_35(c, &(v331_6), &(v328_7_tail).make_space(), &(*s1));
              drop(v331_6);
              map_map_kernels::compose(&(v329_10),&(v331_11))
            };
            drop(v329_10);
            let v329_13: Space = map_map_kernels::unite(&(v329_8),&(v329_12));
            v328_7.join_into((v329_13).clone());
            }
            v328_7_cursor.ascend(1);
          }
          drop(v328_7_cursor);
          drop(v328_6);
          map_map_kernels::compose(&(v327_5),&(v328_7))
        };
        drop(v327_5);
        let v327_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v327_2));
        drop(v327_2);
        let v327_10: Space = if map_kernels::has_head(&(v327_9)) { singleton(&[]) } else { Space::new() };
        drop(v327_9);
        let v327_13: Space = if (v327_10).is_empty() { Space::new() } else {
          let v332_11: Space = map_kernels::unwrap(&(v326_10),&(v326_11_head));
          let v332_12: Space = map_map_kernels::subtract(&(v332_11),&(*CONSTANT_5));
          drop(v332_11);
          map_map_kernels::compose(&(v327_10),&(v332_12))
        };
        drop(v327_10);
        let v327_14: Space = map_map_kernels::unite(&(v327_8),&(v327_13));
        drop(v327_13);
        v326_11.join_into((v327_14).clone());
        }
        v326_11_cursor.ascend(1);
      }
      drop(v326_11_cursor);
      drop(v326_10);
      map_map_kernels::compose(&(v315_9),&(v326_11))
    };
    drop(v315_9);
    let v315_13: Space = map_map_kernels::unite(&(v315_7),&(v315_12));
    v314_26.join_into((v315_13).clone());
    }
    v314_26_cursor.ascend(1);
  }
  drop(v314_26_cursor);
  drop(v314_22);
  let v314_27: Space = map_kernels::wrap(&(v314_26),&(*p0));
  (v314_27).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v333_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v333_22: Space = map_kernels::unwrap(&(v333_21),&(*CONSTANT_4));
  drop(v333_21);
  let v333_23: Space = map_kernels::unwrap(&(v333_22),&(*p0));
  drop(v333_22);
  let mut v333_27 = Space::new();
  let mut v333_27_cursor = (*s0).read_zipper();
  for v333_27_byte in v333_27_cursor.child_mask().iter() {
    v333_27_cursor.descend_to_byte(v333_27_byte);
    {
    let v333_27_tail = v333_27_cursor.fork_read_zipper();
    let v333_27_head = Path::from_slice(&[v333_27_byte]);
    let v334_2: Space = singleton(&(v333_27_head));
    let v334_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v334_2));
    let v334_4: Space = if map_kernels::has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
    drop(v334_3);
    let v334_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v334_4));
    drop(v334_4);
    let v334_8: Space = if (v334_5).is_empty() { Space::new() } else {
      let v335_6: Path = concat_path(&(*p0),&(v333_27_head));
      let mut v335_7 = Space::new();
      let mut v335_7_cursor = (v333_27_tail).read_zipper();
      for v335_7_byte in v335_7_cursor.child_mask().iter() {
        v335_7_cursor.descend_to_byte(v335_7_byte);
        {
        let v335_7_tail = v335_7_cursor.fork_read_zipper();
        let v335_7_head = Path::from_slice(&[v335_7_byte]);
        let v336_2: Space = singleton(&(v335_7_head));
        let v336_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v336_2));
        let v336_4: Space = if map_kernels::has_head(&(v336_3)) { singleton(&[]) } else { Space::new() };
        drop(v336_3);
        let v336_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v336_4));
        drop(v336_4);
        let v336_8: Space = if (v336_5).is_empty() { Space::new() } else {
          let v337_6: Path = concat_path(&(v335_6),&(v335_7_head));
          let mut v337_7 = Space::new();
          let mut v337_7_cursor = (v335_7_tail).read_zipper();
          for v337_7_byte in v337_7_cursor.child_mask().iter() {
            v337_7_cursor.descend_to_byte(v337_7_byte);
            {
            let v337_7_tail = v337_7_cursor.fork_read_zipper();
            let v337_7_head = Path::from_slice(&[v337_7_byte]);
            let v338_2: Space = singleton(&(v337_7_head));
            let v338_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v338_2));
            let v338_4: Space = if map_kernels::has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
            drop(v338_3);
            let v338_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v338_4));
            drop(v338_4);
            let v338_8: Space = if (v338_5).is_empty() { Space::new() } else {
              let v339_6: Path = concat_path(&(v337_6),&(v337_7_head));
              let v339_7: Space = routine_36(c, &(v339_6), &(v337_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v338_5),&(v339_7))
            };
            drop(v338_5);
            let v338_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v338_2));
            drop(v338_2);
            let v338_10: Space = if map_kernels::has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
            drop(v338_9);
            let v338_12: Space = if (v338_10).is_empty() { Space::new() } else {
              let v340_6: Path = concat_path(&(v337_6),&(v337_7_head));
              let v340_11: Space = routine_37(c, &(v340_6), &(v337_7_tail).make_space(), &(*s1));
              drop(v340_6);
              map_map_kernels::compose(&(v338_10),&(v340_11))
            };
            drop(v338_10);
            let v338_13: Space = map_map_kernels::unite(&(v338_8),&(v338_12));
            v337_7.join_into((v338_13).clone());
            }
            v337_7_cursor.ascend(1);
          }
          drop(v337_7_cursor);
          map_map_kernels::compose(&(v336_5),&(v337_7))
        };
        drop(v336_5);
        let v336_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v336_2));
        drop(v336_2);
        let v336_10: Space = if map_kernels::has_head(&(v336_9)) { singleton(&[]) } else { Space::new() };
        drop(v336_9);
        let v336_12: Space = if (v336_10).is_empty() { Space::new() } else {
          let v341_6: Path = concat_path(&(v335_6),&(v335_7_head));
          let mut v341_11 = Space::new();
          let mut v341_11_cursor = (v335_7_tail).read_zipper();
          for v341_11_byte in v341_11_cursor.child_mask().iter() {
            v341_11_cursor.descend_to_byte(v341_11_byte);
            {
            let v341_11_tail = v341_11_cursor.fork_read_zipper();
            let v341_11_head = Path::from_slice(&[v341_11_byte]);
            let v342_2: Space = singleton(&(v341_11_head));
            let v342_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v342_2));
            let v342_4: Space = if map_kernels::has_head(&(v342_3)) { singleton(&[]) } else { Space::new() };
            drop(v342_3);
            let v342_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v342_4));
            drop(v342_4);
            let v342_8: Space = if (v342_5).is_empty() { Space::new() } else {
              let v343_6: Path = concat_path(&(v341_6),&(v341_11_head));
              let v343_7: Space = routine_36(c, &(v343_6), &(v341_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v342_5),&(v343_7))
            };
            drop(v342_5);
            let v342_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v342_2));
            drop(v342_2);
            let v342_10: Space = if map_kernels::has_head(&(v342_9)) { singleton(&[]) } else { Space::new() };
            drop(v342_9);
            let v342_12: Space = if (v342_10).is_empty() { Space::new() } else {
              let v344_6: Path = concat_path(&(v341_6),&(v341_11_head));
              let v344_11: Space = routine_33(c, &(v344_6), &(v341_11_tail).make_space(), &(*s1));
              drop(v344_6);
              map_map_kernels::compose(&(v342_10),&(v344_11))
            };
            drop(v342_10);
            let v342_13: Space = map_map_kernels::unite(&(v342_8),&(v342_12));
            v341_11.join_into((v342_13).clone());
            }
            v341_11_cursor.ascend(1);
          }
          drop(v341_11_cursor);
          drop(v341_6);
          map_map_kernels::compose(&(v336_10),&(v341_11))
        };
        drop(v336_10);
        let v336_13: Space = map_map_kernels::unite(&(v336_8),&(v336_12));
        v335_7.join_into((v336_13).clone());
        }
        v335_7_cursor.ascend(1);
      }
      drop(v335_7_cursor);
      map_map_kernels::compose(&(v334_5),&(v335_7))
    };
    drop(v334_5);
    let v334_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v334_2));
    drop(v334_2);
    let v334_10: Space = if map_kernels::has_head(&(v334_9)) { singleton(&[]) } else { Space::new() };
    drop(v334_9);
    let v334_13: Space = if (v334_10).is_empty() { Space::new() } else {
      let v345_6: Path = concat_path(&(*p0),&(v333_27_head));
      let v345_11: Space = map_kernels::unwrap(&(v333_23),&(v333_27_head));
      let mut v345_12 = Space::new();
      let mut v345_12_cursor = (v333_27_tail).read_zipper();
      for v345_12_byte in v345_12_cursor.child_mask().iter() {
        v345_12_cursor.descend_to_byte(v345_12_byte);
        {
        let v345_12_tail = v345_12_cursor.fork_read_zipper();
        let v345_12_head = Path::from_slice(&[v345_12_byte]);
        let v346_2: Space = singleton(&(v345_12_head));
        let v346_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v346_2));
        let v346_4: Space = if map_kernels::has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
        drop(v346_3);
        let v346_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v346_4));
        drop(v346_4);
        let v346_8: Space = if (v346_5).is_empty() { Space::new() } else {
          let v347_6: Path = concat_path(&(v345_6),&(v345_12_head));
          let mut v347_7 = Space::new();
          let mut v347_7_cursor = (v345_12_tail).read_zipper();
          for v347_7_byte in v347_7_cursor.child_mask().iter() {
            v347_7_cursor.descend_to_byte(v347_7_byte);
            {
            let v347_7_tail = v347_7_cursor.fork_read_zipper();
            let v347_7_head = Path::from_slice(&[v347_7_byte]);
            let v348_2: Space = singleton(&(v347_7_head));
            let v348_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v348_2));
            let v348_4: Space = if map_kernels::has_head(&(v348_3)) { singleton(&[]) } else { Space::new() };
            drop(v348_3);
            let v348_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v348_4));
            drop(v348_4);
            let v348_8: Space = if (v348_5).is_empty() { Space::new() } else {
              let v349_6: Path = concat_path(&(v347_6),&(v347_7_head));
              let v349_7: Space = routine_36(c, &(v349_6), &(v347_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v348_5),&(v349_7))
            };
            drop(v348_5);
            let v348_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v348_2));
            drop(v348_2);
            let v348_10: Space = if map_kernels::has_head(&(v348_9)) { singleton(&[]) } else { Space::new() };
            drop(v348_9);
            let v348_12: Space = if (v348_10).is_empty() { Space::new() } else {
              let v350_6: Path = concat_path(&(v347_6),&(v347_7_head));
              let v350_11: Space = routine_37(c, &(v350_6), &(v347_7_tail).make_space(), &(*s1));
              drop(v350_6);
              map_map_kernels::compose(&(v348_10),&(v350_11))
            };
            drop(v348_10);
            let v348_13: Space = map_map_kernels::unite(&(v348_8),&(v348_12));
            v347_7.join_into((v348_13).clone());
            }
            v347_7_cursor.ascend(1);
          }
          drop(v347_7_cursor);
          drop(v347_6);
          map_map_kernels::compose(&(v346_5),&(v347_7))
        };
        drop(v346_5);
        let v346_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v346_2));
        drop(v346_2);
        let v346_10: Space = if map_kernels::has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
        drop(v346_9);
        let v346_13: Space = if (v346_10).is_empty() { Space::new() } else {
          let v351_11: Space = map_kernels::unwrap(&(v345_11),&(v345_12_head));
          let v351_12: Space = map_map_kernels::subtract(&(v351_11),&(*CONSTANT_5));
          drop(v351_11);
          map_map_kernels::compose(&(v346_10),&(v351_12))
        };
        drop(v346_10);
        let v346_14: Space = map_map_kernels::unite(&(v346_8),&(v346_13));
        drop(v346_13);
        v345_12.join_into((v346_14).clone());
        }
        v345_12_cursor.ascend(1);
      }
      drop(v345_12_cursor);
      drop(v345_6);
      drop(v345_11);
      map_map_kernels::compose(&(v334_10),&(v345_12))
    };
    drop(v334_10);
    let v334_14: Space = map_map_kernels::unite(&(v334_8),&(v334_13));
    v333_27.join_into((v334_14).clone());
    }
    v333_27_cursor.ascend(1);
  }
  drop(v333_27_cursor);
  drop(v333_23);
  (v333_27).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v352_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v352_9: Space = map_kernels::unwrap(&(v352_7),&(*CONSTANT_4));
  drop(v352_7);
  let v352_10: Space = map_kernels::unwrap(&(v352_9),&(*p0));
  drop(v352_9);
  let mut v352_21 = Space::new();
  let mut v352_21_cursor = (*s0).read_zipper();
  for v352_21_byte in v352_21_cursor.child_mask().iter() {
    v352_21_cursor.descend_to_byte(v352_21_byte);
    {
    let v352_21_tail = v352_21_cursor.fork_read_zipper();
    let v352_21_head = Path::from_slice(&[v352_21_byte]);
    let v353_2: Space = singleton(&(v352_21_head));
    let v353_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v353_2));
    let v353_4: Space = if map_kernels::has_head(&(v353_3)) { singleton(&[]) } else { Space::new() };
    drop(v353_3);
    let v353_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v353_4));
    drop(v353_4);
    let v353_8: Space = if (v353_5).is_empty() { Space::new() } else {
      let v354_6: Path = concat_path(&(*p0),&(v352_21_head));
      let mut v354_7 = Space::new();
      let mut v354_7_cursor = (v352_21_tail).read_zipper();
      for v354_7_byte in v354_7_cursor.child_mask().iter() {
        v354_7_cursor.descend_to_byte(v354_7_byte);
        {
        let v354_7_tail = v354_7_cursor.fork_read_zipper();
        let v354_7_head = Path::from_slice(&[v354_7_byte]);
        let v355_2: Space = singleton(&(v354_7_head));
        let v355_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v355_2));
        let v355_4: Space = if map_kernels::has_head(&(v355_3)) { singleton(&[]) } else { Space::new() };
        drop(v355_3);
        let v355_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v355_4));
        drop(v355_4);
        let v355_8: Space = if (v355_5).is_empty() { Space::new() } else {
          let v356_6: Path = concat_path(&(v354_6),&(v354_7_head));
          let mut v356_7 = Space::new();
          let mut v356_7_cursor = (v354_7_tail).read_zipper();
          for v356_7_byte in v356_7_cursor.child_mask().iter() {
            v356_7_cursor.descend_to_byte(v356_7_byte);
            {
            let v356_7_tail = v356_7_cursor.fork_read_zipper();
            let v356_7_head = Path::from_slice(&[v356_7_byte]);
            let v357_2: Space = singleton(&(v356_7_head));
            let v357_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v357_2));
            let v357_4: Space = if map_kernels::has_head(&(v357_3)) { singleton(&[]) } else { Space::new() };
            drop(v357_3);
            let v357_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v357_4));
            drop(v357_4);
            let v357_8: Space = if (v357_5).is_empty() { Space::new() } else {
              let v358_6: Path = concat_path(&(v356_6),&(v356_7_head));
              let v358_7: Space = routine_36(c, &(v358_6), &(v356_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v357_5),&(v358_7))
            };
            drop(v357_5);
            let v357_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v357_2));
            drop(v357_2);
            let v357_10: Space = if map_kernels::has_head(&(v357_9)) { singleton(&[]) } else { Space::new() };
            drop(v357_9);
            let v357_12: Space = if (v357_10).is_empty() { Space::new() } else {
              let v359_6: Path = concat_path(&(v356_6),&(v356_7_head));
              let v359_11: Space = routine_37(c, &(v359_6), &(v356_7_tail).make_space(), &(*s1));
              drop(v359_6);
              map_map_kernels::compose(&(v357_10),&(v359_11))
            };
            drop(v357_10);
            let v357_13: Space = map_map_kernels::unite(&(v357_8),&(v357_12));
            v356_7.join_into((v357_13).clone());
            }
            v356_7_cursor.ascend(1);
          }
          drop(v356_7_cursor);
          map_map_kernels::compose(&(v355_5),&(v356_7))
        };
        drop(v355_5);
        let v355_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v355_2));
        drop(v355_2);
        let v355_10: Space = if map_kernels::has_head(&(v355_9)) { singleton(&[]) } else { Space::new() };
        drop(v355_9);
        let v355_12: Space = if (v355_10).is_empty() { Space::new() } else {
          let v360_6: Path = concat_path(&(v354_6),&(v354_7_head));
          let mut v360_11 = Space::new();
          let mut v360_11_cursor = (v354_7_tail).read_zipper();
          for v360_11_byte in v360_11_cursor.child_mask().iter() {
            v360_11_cursor.descend_to_byte(v360_11_byte);
            {
            let v360_11_tail = v360_11_cursor.fork_read_zipper();
            let v360_11_head = Path::from_slice(&[v360_11_byte]);
            let v361_2: Space = singleton(&(v360_11_head));
            let v361_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v361_2));
            let v361_4: Space = if map_kernels::has_head(&(v361_3)) { singleton(&[]) } else { Space::new() };
            drop(v361_3);
            let v361_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v361_4));
            drop(v361_4);
            let v361_8: Space = if (v361_5).is_empty() { Space::new() } else {
              let v362_6: Path = concat_path(&(v360_6),&(v360_11_head));
              let v362_7: Space = routine_36(c, &(v362_6), &(v360_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v361_5),&(v362_7))
            };
            drop(v361_5);
            let v361_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v361_2));
            drop(v361_2);
            let v361_10: Space = if map_kernels::has_head(&(v361_9)) { singleton(&[]) } else { Space::new() };
            drop(v361_9);
            let v361_12: Space = if (v361_10).is_empty() { Space::new() } else {
              let v363_6: Path = concat_path(&(v360_6),&(v360_11_head));
              let v363_11: Space = routine_33(c, &(v363_6), &(v360_11_tail).make_space(), &(*s1));
              drop(v363_6);
              map_map_kernels::compose(&(v361_10),&(v363_11))
            };
            drop(v361_10);
            let v361_13: Space = map_map_kernels::unite(&(v361_8),&(v361_12));
            v360_11.join_into((v361_13).clone());
            }
            v360_11_cursor.ascend(1);
          }
          drop(v360_11_cursor);
          drop(v360_6);
          map_map_kernels::compose(&(v355_10),&(v360_11))
        };
        drop(v355_10);
        let v355_13: Space = map_map_kernels::unite(&(v355_8),&(v355_12));
        v354_7.join_into((v355_13).clone());
        }
        v354_7_cursor.ascend(1);
      }
      drop(v354_7_cursor);
      drop(v354_6);
      map_map_kernels::compose(&(v353_5),&(v354_7))
    };
    drop(v353_5);
    let v353_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v353_2));
    drop(v353_2);
    let v353_10: Space = if map_kernels::has_head(&(v353_9)) { singleton(&[]) } else { Space::new() };
    drop(v353_9);
    let v353_13: Space = if (v353_10).is_empty() { Space::new() } else {
      let v364_11: Space = map_kernels::unwrap(&(v352_10),&(v352_21_head));
      let v364_12: Space = map_map_kernels::subtract(&(v364_11),&(*CONSTANT_5));
      drop(v364_11);
      map_map_kernels::compose(&(v353_10),&(v364_12))
    };
    drop(v353_10);
    let v353_14: Space = map_map_kernels::unite(&(v353_8),&(v353_13));
    drop(v353_13);
    v352_21.join_into((v353_14).clone());
    }
    v352_21_cursor.ascend(1);
  }
  drop(v352_21_cursor);
  drop(v352_10);
  (v352_21).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v365_21 = Space::new();
  let mut v365_21_cursor = (*s0).read_zipper();
  for v365_21_byte in v365_21_cursor.child_mask().iter() {
    v365_21_cursor.descend_to_byte(v365_21_byte);
    {
    let v365_21_tail = v365_21_cursor.fork_read_zipper();
    let v365_21_head = Path::from_slice(&[v365_21_byte]);
    let v366_2: Space = singleton(&(v365_21_head));
    let v366_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v366_2));
    let v366_4: Space = if map_kernels::has_head(&(v366_3)) { singleton(&[]) } else { Space::new() };
    drop(v366_3);
    let v366_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v366_4));
    drop(v366_4);
    let v366_8: Space = if (v366_5).is_empty() { Space::new() } else {
      let v367_6: Path = concat_path(&(*p0),&(v365_21_head));
      let mut v367_7 = Space::new();
      let mut v367_7_cursor = (v365_21_tail).read_zipper();
      for v367_7_byte in v367_7_cursor.child_mask().iter() {
        v367_7_cursor.descend_to_byte(v367_7_byte);
        {
        let v367_7_tail = v367_7_cursor.fork_read_zipper();
        let v367_7_head = Path::from_slice(&[v367_7_byte]);
        let v368_2: Space = singleton(&(v367_7_head));
        let v368_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v368_2));
        let v368_4: Space = if map_kernels::has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
        drop(v368_3);
        let v368_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v368_4));
        drop(v368_4);
        let v368_8: Space = if (v368_5).is_empty() { Space::new() } else {
          let v369_6: Path = concat_path(&(v367_6),&(v367_7_head));
          let mut v369_7 = Space::new();
          let mut v369_7_cursor = (v367_7_tail).read_zipper();
          for v369_7_byte in v369_7_cursor.child_mask().iter() {
            v369_7_cursor.descend_to_byte(v369_7_byte);
            {
            let v369_7_tail = v369_7_cursor.fork_read_zipper();
            let v369_7_head = Path::from_slice(&[v369_7_byte]);
            let v370_2: Space = singleton(&(v369_7_head));
            let v370_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v370_2));
            let v370_4: Space = if map_kernels::has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
            drop(v370_3);
            let v370_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v370_4));
            drop(v370_4);
            let v370_8: Space = if (v370_5).is_empty() { Space::new() } else {
              let v371_6: Path = concat_path(&(v369_6),&(v369_7_head));
              let v371_7: Space = routine_38(c, &(v371_6), &(v369_7_tail).make_space());
              map_map_kernels::compose(&(v370_5),&(v371_7))
            };
            drop(v370_5);
            let v370_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v370_2));
            drop(v370_2);
            let v370_10: Space = if map_kernels::has_head(&(v370_9)) { singleton(&[]) } else { Space::new() };
            drop(v370_9);
            let v370_12: Space = if (v370_10).is_empty() { Space::new() } else {
              let v372_6: Path = concat_path(&(v369_6),&(v369_7_head));
              let v372_11: Space = routine_39(c, &(v372_6), &(v369_7_tail).make_space());
              drop(v372_6);
              map_map_kernels::compose(&(v370_10),&(v372_11))
            };
            drop(v370_10);
            let v370_13: Space = map_map_kernels::unite(&(v370_8),&(v370_12));
            v369_7.join_into((v370_13).clone());
            }
            v369_7_cursor.ascend(1);
          }
          drop(v369_7_cursor);
          map_map_kernels::compose(&(v368_5),&(v369_7))
        };
        drop(v368_5);
        let v368_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v368_2));
        drop(v368_2);
        let v368_10: Space = if map_kernels::has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
        drop(v368_9);
        let v368_12: Space = if (v368_10).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v367_6),&(v367_7_head));
          let mut v373_11 = Space::new();
          let mut v373_11_cursor = (v367_7_tail).read_zipper();
          for v373_11_byte in v373_11_cursor.child_mask().iter() {
            v373_11_cursor.descend_to_byte(v373_11_byte);
            {
            let v373_11_tail = v373_11_cursor.fork_read_zipper();
            let v373_11_head = Path::from_slice(&[v373_11_byte]);
            let v374_2: Space = singleton(&(v373_11_head));
            let v374_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v374_2));
            let v374_4: Space = if map_kernels::has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
            drop(v374_3);
            let v374_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v374_4));
            drop(v374_4);
            let v374_8: Space = if (v374_5).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v373_6),&(v373_11_head));
              let v375_7: Space = routine_38(c, &(v375_6), &(v373_11_tail).make_space());
              map_map_kernels::compose(&(v374_5),&(v375_7))
            };
            drop(v374_5);
            let v374_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v374_2));
            drop(v374_2);
            let v374_10: Space = if map_kernels::has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
            drop(v374_9);
            let v374_12: Space = if (v374_10).is_empty() { Space::new() } else {
              let v376_6: Path = concat_path(&(v373_6),&(v373_11_head));
              let v376_11: Space = routine_14(c, &(v376_6), &(v373_11_tail).make_space());
              drop(v376_6);
              map_map_kernels::compose(&(v374_10),&(v376_11))
            };
            drop(v374_10);
            let v374_13: Space = map_map_kernels::unite(&(v374_8),&(v374_12));
            v373_11.join_into((v374_13).clone());
            }
            v373_11_cursor.ascend(1);
          }
          drop(v373_11_cursor);
          drop(v373_6);
          map_map_kernels::compose(&(v368_10),&(v373_11))
        };
        drop(v368_10);
        let v368_13: Space = map_map_kernels::unite(&(v368_8),&(v368_12));
        v367_7.join_into((v368_13).clone());
        }
        v367_7_cursor.ascend(1);
      }
      drop(v367_7_cursor);
      map_map_kernels::compose(&(v366_5),&(v367_7))
    };
    drop(v366_5);
    let v366_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v366_2));
    drop(v366_2);
    let v366_10: Space = if map_kernels::has_head(&(v366_9)) { singleton(&[]) } else { Space::new() };
    drop(v366_9);
    let v366_12: Space = if (v366_10).is_empty() { Space::new() } else {
      let v377_6: Path = concat_path(&(*p0),&(v365_21_head));
      let mut v377_11 = Space::new();
      let mut v377_11_cursor = (v365_21_tail).read_zipper();
      for v377_11_byte in v377_11_cursor.child_mask().iter() {
        v377_11_cursor.descend_to_byte(v377_11_byte);
        {
        let v377_11_tail = v377_11_cursor.fork_read_zipper();
        let v377_11_head = Path::from_slice(&[v377_11_byte]);
        let v378_2: Space = singleton(&(v377_11_head));
        let v378_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v378_2));
        let v378_4: Space = if map_kernels::has_head(&(v378_3)) { singleton(&[]) } else { Space::new() };
        drop(v378_3);
        let v378_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v378_4));
        drop(v378_4);
        let v378_8: Space = if (v378_5).is_empty() { Space::new() } else {
          let v379_6: Path = concat_path(&(v377_6),&(v377_11_head));
          let mut v379_7 = Space::new();
          let mut v379_7_cursor = (v377_11_tail).read_zipper();
          for v379_7_byte in v379_7_cursor.child_mask().iter() {
            v379_7_cursor.descend_to_byte(v379_7_byte);
            {
            let v379_7_tail = v379_7_cursor.fork_read_zipper();
            let v379_7_head = Path::from_slice(&[v379_7_byte]);
            let v380_2: Space = singleton(&(v379_7_head));
            let v380_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v380_2));
            let v380_4: Space = if map_kernels::has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
            drop(v380_3);
            let v380_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v380_4));
            drop(v380_4);
            let v380_8: Space = if (v380_5).is_empty() { Space::new() } else {
              let v381_6: Path = concat_path(&(v379_6),&(v379_7_head));
              let v381_7: Space = routine_38(c, &(v381_6), &(v379_7_tail).make_space());
              map_map_kernels::compose(&(v380_5),&(v381_7))
            };
            drop(v380_5);
            let v380_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v380_2));
            drop(v380_2);
            let v380_10: Space = if map_kernels::has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
            drop(v380_9);
            let v380_12: Space = if (v380_10).is_empty() { Space::new() } else {
              let v382_6: Path = concat_path(&(v379_6),&(v379_7_head));
              let v382_11: Space = routine_39(c, &(v382_6), &(v379_7_tail).make_space());
              drop(v382_6);
              map_map_kernels::compose(&(v380_10),&(v382_11))
            };
            drop(v380_10);
            let v380_13: Space = map_map_kernels::unite(&(v380_8),&(v380_12));
            v379_7.join_into((v380_13).clone());
            }
            v379_7_cursor.ascend(1);
          }
          drop(v379_7_cursor);
          map_map_kernels::compose(&(v378_5),&(v379_7))
        };
        drop(v378_5);
        let v378_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v378_2));
        drop(v378_2);
        let v378_10: Space = if map_kernels::has_head(&(v378_9)) { singleton(&[]) } else { Space::new() };
        drop(v378_9);
        let v378_11: Space = view_map_kernels::subtract(&(v377_11_tail),&(*CONSTANT_5));
        let v378_12: Space = map_map_kernels::compose(&(v378_10),&(v378_11));
        drop(v378_10);
        drop(v378_11);
        let v383_6: Path = concat_path(&(v377_6),&(v377_11_head));
        let v378_13: Space = map_kernels::wrap(&(v378_12),&(v383_6));
        drop(v378_12);
        let v378_14: Space = map_map_kernels::unite(&(v378_8),&(v378_13));
        drop(v378_13);
        v377_11.join_into((v378_14).clone());
        }
        v377_11_cursor.ascend(1);
      }
      drop(v377_11_cursor);
      drop(v377_6);
      map_map_kernels::compose(&(v366_10),&(v377_11))
    };
    drop(v366_10);
    let v366_13: Space = map_map_kernels::unite(&(v366_8),&(v366_12));
    v365_21.join_into((v366_13).clone());
    }
    v365_21_cursor.ascend(1);
  }
  drop(v365_21_cursor);
  (v365_21).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v384_15 = Space::new();
  let mut v384_15_cursor = (*s0).read_zipper();
  for v384_15_byte in v384_15_cursor.child_mask().iter() {
    v384_15_cursor.descend_to_byte(v384_15_byte);
    {
    let v384_15_tail = v384_15_cursor.fork_read_zipper();
    let v384_15_head = Path::from_slice(&[v384_15_byte]);
    let v385_2: Space = singleton(&(v384_15_head));
    let v385_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v385_2));
    let v385_4: Space = if map_kernels::has_head(&(v385_3)) { singleton(&[]) } else { Space::new() };
    drop(v385_3);
    let v385_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v385_4));
    drop(v385_4);
    let v385_8: Space = if (v385_5).is_empty() { Space::new() } else {
      let v386_6: Path = concat_path(&(*p0),&(v384_15_head));
      let mut v386_7 = Space::new();
      let mut v386_7_cursor = (v384_15_tail).read_zipper();
      for v386_7_byte in v386_7_cursor.child_mask().iter() {
        v386_7_cursor.descend_to_byte(v386_7_byte);
        {
        let v386_7_tail = v386_7_cursor.fork_read_zipper();
        let v386_7_head = Path::from_slice(&[v386_7_byte]);
        let v387_2: Space = singleton(&(v386_7_head));
        let v387_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v387_2));
        let v387_4: Space = if map_kernels::has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
        drop(v387_3);
        let v387_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v387_4));
        drop(v387_4);
        let v387_8: Space = if (v387_5).is_empty() { Space::new() } else {
          let v388_6: Path = concat_path(&(v386_6),&(v386_7_head));
          let mut v388_7 = Space::new();
          let mut v388_7_cursor = (v386_7_tail).read_zipper();
          for v388_7_byte in v388_7_cursor.child_mask().iter() {
            v388_7_cursor.descend_to_byte(v388_7_byte);
            {
            let v388_7_tail = v388_7_cursor.fork_read_zipper();
            let v388_7_head = Path::from_slice(&[v388_7_byte]);
            let v389_2: Space = singleton(&(v388_7_head));
            let v389_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v389_2));
            let v389_4: Space = if map_kernels::has_head(&(v389_3)) { singleton(&[]) } else { Space::new() };
            drop(v389_3);
            let v389_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v389_4));
            drop(v389_4);
            let v389_8: Space = if (v389_5).is_empty() { Space::new() } else {
              let v390_6: Path = concat_path(&(v388_6),&(v388_7_head));
              let v390_7: Space = routine_38(c, &(v390_6), &(v388_7_tail).make_space());
              map_map_kernels::compose(&(v389_5),&(v390_7))
            };
            drop(v389_5);
            let v389_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v389_2));
            drop(v389_2);
            let v389_10: Space = if map_kernels::has_head(&(v389_9)) { singleton(&[]) } else { Space::new() };
            drop(v389_9);
            let v389_12: Space = if (v389_10).is_empty() { Space::new() } else {
              let v391_6: Path = concat_path(&(v388_6),&(v388_7_head));
              let v391_11: Space = routine_39(c, &(v391_6), &(v388_7_tail).make_space());
              drop(v391_6);
              map_map_kernels::compose(&(v389_10),&(v391_11))
            };
            drop(v389_10);
            let v389_13: Space = map_map_kernels::unite(&(v389_8),&(v389_12));
            v388_7.join_into((v389_13).clone());
            }
            v388_7_cursor.ascend(1);
          }
          drop(v388_7_cursor);
          map_map_kernels::compose(&(v387_5),&(v388_7))
        };
        drop(v387_5);
        let v387_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v387_2));
        drop(v387_2);
        let v387_10: Space = if map_kernels::has_head(&(v387_9)) { singleton(&[]) } else { Space::new() };
        drop(v387_9);
        let v387_12: Space = if (v387_10).is_empty() { Space::new() } else {
          let v392_6: Path = concat_path(&(v386_6),&(v386_7_head));
          let mut v392_11 = Space::new();
          let mut v392_11_cursor = (v386_7_tail).read_zipper();
          for v392_11_byte in v392_11_cursor.child_mask().iter() {
            v392_11_cursor.descend_to_byte(v392_11_byte);
            {
            let v392_11_tail = v392_11_cursor.fork_read_zipper();
            let v392_11_head = Path::from_slice(&[v392_11_byte]);
            let v393_2: Space = singleton(&(v392_11_head));
            let v393_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v393_2));
            let v393_4: Space = if map_kernels::has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
            drop(v393_3);
            let v393_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v393_4));
            drop(v393_4);
            let v393_8: Space = if (v393_5).is_empty() { Space::new() } else {
              let v394_6: Path = concat_path(&(v392_6),&(v392_11_head));
              let v394_7: Space = routine_38(c, &(v394_6), &(v392_11_tail).make_space());
              map_map_kernels::compose(&(v393_5),&(v394_7))
            };
            drop(v393_5);
            let v393_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v393_2));
            drop(v393_2);
            let v393_10: Space = if map_kernels::has_head(&(v393_9)) { singleton(&[]) } else { Space::new() };
            drop(v393_9);
            let v393_12: Space = if (v393_10).is_empty() { Space::new() } else {
              let v395_6: Path = concat_path(&(v392_6),&(v392_11_head));
              let v395_11: Space = routine_14(c, &(v395_6), &(v392_11_tail).make_space());
              drop(v395_6);
              map_map_kernels::compose(&(v393_10),&(v395_11))
            };
            drop(v393_10);
            let v393_13: Space = map_map_kernels::unite(&(v393_8),&(v393_12));
            v392_11.join_into((v393_13).clone());
            }
            v392_11_cursor.ascend(1);
          }
          drop(v392_11_cursor);
          drop(v392_6);
          map_map_kernels::compose(&(v387_10),&(v392_11))
        };
        drop(v387_10);
        let v387_13: Space = map_map_kernels::unite(&(v387_8),&(v387_12));
        v386_7.join_into((v387_13).clone());
        }
        v386_7_cursor.ascend(1);
      }
      drop(v386_7_cursor);
      map_map_kernels::compose(&(v385_5),&(v386_7))
    };
    drop(v385_5);
    let v385_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v385_2));
    drop(v385_2);
    let v385_10: Space = if map_kernels::has_head(&(v385_9)) { singleton(&[]) } else { Space::new() };
    drop(v385_9);
    let v385_11: Space = view_map_kernels::subtract(&(v384_15_tail),&(*CONSTANT_5));
    let v385_12: Space = map_map_kernels::compose(&(v385_10),&(v385_11));
    drop(v385_10);
    drop(v385_11);
    let v396_6: Path = concat_path(&(*p0),&(v384_15_head));
    let v385_13: Space = map_kernels::wrap(&(v385_12),&(v396_6));
    drop(v385_12);
    let v385_14: Space = map_map_kernels::unite(&(v385_8),&(v385_13));
    drop(v385_13);
    v384_15.join_into((v385_14).clone());
    }
    v384_15_cursor.ascend(1);
  }
  drop(v384_15_cursor);
  (v384_15).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v397_3: Space = map_map_kernels::subtract(&(*s0),&(*CONSTANT_5));
  let v397_4: Space = map_kernels::wrap(&(v397_3),&(*p0));
  drop(v397_3);
  (v397_4).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v398_24 = Space::new();
  let mut v398_24_cursor = (*s0).read_zipper();
  for v398_24_byte in v398_24_cursor.child_mask().iter() {
    v398_24_cursor.descend_to_byte(v398_24_byte);
    {
    let v398_24_tail = v398_24_cursor.fork_read_zipper();
    let v398_24_head = Path::from_slice(&[v398_24_byte]);
    let v399_2: Space = singleton(&(v398_24_head));
    let v399_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v399_2));
    let v399_4: Space = if map_kernels::has_head(&(v399_3)) { singleton(&[]) } else { Space::new() };
    drop(v399_3);
    let v399_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v399_4));
    drop(v399_4);
    let v399_8: Space = if (v399_5).is_empty() { Space::new() } else {
      let v400_6: Path = concat_path(&(*p0),&(v398_24_head));
      let mut v400_7 = Space::new();
      let mut v400_7_cursor = (v398_24_tail).read_zipper();
      for v400_7_byte in v400_7_cursor.child_mask().iter() {
        v400_7_cursor.descend_to_byte(v400_7_byte);
        {
        let v400_7_tail = v400_7_cursor.fork_read_zipper();
        let v400_7_head = Path::from_slice(&[v400_7_byte]);
        let v401_2: Space = singleton(&(v400_7_head));
        let v401_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v401_2));
        let v401_4: Space = if map_kernels::has_head(&(v401_3)) { singleton(&[]) } else { Space::new() };
        drop(v401_3);
        let v401_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v401_4));
        drop(v401_4);
        let v401_8: Space = if (v401_5).is_empty() { Space::new() } else {
          let v402_6: Path = concat_path(&(v400_6),&(v400_7_head));
          let mut v402_7 = Space::new();
          let mut v402_7_cursor = (v400_7_tail).read_zipper();
          for v402_7_byte in v402_7_cursor.child_mask().iter() {
            v402_7_cursor.descend_to_byte(v402_7_byte);
            {
            let v402_7_tail = v402_7_cursor.fork_read_zipper();
            let v402_7_head = Path::from_slice(&[v402_7_byte]);
            let v403_2: Space = singleton(&(v402_7_head));
            let v403_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v403_2));
            let v403_4: Space = if map_kernels::has_head(&(v403_3)) { singleton(&[]) } else { Space::new() };
            drop(v403_3);
            let v403_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v403_4));
            drop(v403_4);
            let v403_8: Space = if (v403_5).is_empty() { Space::new() } else {
              let v404_6: Path = concat_path(&(v402_6),&(v402_7_head));
              let v404_7: Space = routine_40(c, &(v404_6), &(v402_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v403_5),&(v404_7))
            };
            drop(v403_5);
            let v403_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v403_2));
            drop(v403_2);
            let v403_10: Space = if map_kernels::has_head(&(v403_9)) { singleton(&[]) } else { Space::new() };
            drop(v403_9);
            let v403_12: Space = if (v403_10).is_empty() { Space::new() } else {
              let v405_6: Path = concat_path(&(v402_6),&(v402_7_head));
              let v405_11: Space = routine_41(c, &(v405_6), &(v402_7_tail).make_space(), &(*s1));
              drop(v405_6);
              map_map_kernels::compose(&(v403_10),&(v405_11))
            };
            drop(v403_10);
            let v403_13: Space = map_map_kernels::unite(&(v403_8),&(v403_12));
            v402_7.join_into((v403_13).clone());
            }
            v402_7_cursor.ascend(1);
          }
          drop(v402_7_cursor);
          map_map_kernels::compose(&(v401_5),&(v402_7))
        };
        drop(v401_5);
        let v401_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v401_2));
        drop(v401_2);
        let v401_10: Space = if map_kernels::has_head(&(v401_9)) { singleton(&[]) } else { Space::new() };
        drop(v401_9);
        let v401_12: Space = if (v401_10).is_empty() { Space::new() } else {
          let v406_6: Path = concat_path(&(v400_6),&(v400_7_head));
          let mut v406_11 = Space::new();
          let mut v406_11_cursor = (v400_7_tail).read_zipper();
          for v406_11_byte in v406_11_cursor.child_mask().iter() {
            v406_11_cursor.descend_to_byte(v406_11_byte);
            {
            let v406_11_tail = v406_11_cursor.fork_read_zipper();
            let v406_11_head = Path::from_slice(&[v406_11_byte]);
            let v407_2: Space = singleton(&(v406_11_head));
            let v407_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v407_2));
            let v407_4: Space = if map_kernels::has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
            drop(v407_3);
            let v407_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v407_4));
            drop(v407_4);
            let v407_8: Space = if (v407_5).is_empty() { Space::new() } else {
              let v408_6: Path = concat_path(&(v406_6),&(v406_11_head));
              let v408_7: Space = routine_40(c, &(v408_6), &(v406_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v407_5),&(v408_7))
            };
            drop(v407_5);
            let v407_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v407_2));
            drop(v407_2);
            let v407_10: Space = if map_kernels::has_head(&(v407_9)) { singleton(&[]) } else { Space::new() };
            drop(v407_9);
            let v407_12: Space = if (v407_10).is_empty() { Space::new() } else {
              let v409_6: Path = concat_path(&(v406_6),&(v406_11_head));
              let v409_11: Space = routine_17(c, &(v409_6), &(v406_11_tail).make_space(), &(*s1));
              drop(v409_6);
              map_map_kernels::compose(&(v407_10),&(v409_11))
            };
            drop(v407_10);
            let v407_13: Space = map_map_kernels::unite(&(v407_8),&(v407_12));
            v406_11.join_into((v407_13).clone());
            }
            v406_11_cursor.ascend(1);
          }
          drop(v406_11_cursor);
          drop(v406_6);
          map_map_kernels::compose(&(v401_10),&(v406_11))
        };
        drop(v401_10);
        let v401_13: Space = map_map_kernels::unite(&(v401_8),&(v401_12));
        v400_7.join_into((v401_13).clone());
        }
        v400_7_cursor.ascend(1);
      }
      drop(v400_7_cursor);
      map_map_kernels::compose(&(v399_5),&(v400_7))
    };
    drop(v399_5);
    let v399_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v399_2));
    drop(v399_2);
    let v399_10: Space = if map_kernels::has_head(&(v399_9)) { singleton(&[]) } else { Space::new() };
    drop(v399_9);
    let v399_12: Space = if (v399_10).is_empty() { Space::new() } else {
      let v410_6: Path = concat_path(&(*p0),&(v398_24_head));
      let mut v410_11 = Space::new();
      let mut v410_11_cursor = (v398_24_tail).read_zipper();
      for v410_11_byte in v410_11_cursor.child_mask().iter() {
        v410_11_cursor.descend_to_byte(v410_11_byte);
        {
        let v410_11_tail = v410_11_cursor.fork_read_zipper();
        let v410_11_head = Path::from_slice(&[v410_11_byte]);
        let v411_2: Space = singleton(&(v410_11_head));
        let v411_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v411_2));
        let v411_4: Space = if map_kernels::has_head(&(v411_3)) { singleton(&[]) } else { Space::new() };
        drop(v411_3);
        let v411_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v411_4));
        drop(v411_4);
        let v411_8: Space = if (v411_5).is_empty() { Space::new() } else {
          let v412_6: Path = concat_path(&(v410_6),&(v410_11_head));
          let mut v412_7 = Space::new();
          let mut v412_7_cursor = (v410_11_tail).read_zipper();
          for v412_7_byte in v412_7_cursor.child_mask().iter() {
            v412_7_cursor.descend_to_byte(v412_7_byte);
            {
            let v412_7_tail = v412_7_cursor.fork_read_zipper();
            let v412_7_head = Path::from_slice(&[v412_7_byte]);
            let v413_2: Space = singleton(&(v412_7_head));
            let v413_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v413_2));
            let v413_4: Space = if map_kernels::has_head(&(v413_3)) { singleton(&[]) } else { Space::new() };
            drop(v413_3);
            let v413_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v413_4));
            drop(v413_4);
            let v413_8: Space = if (v413_5).is_empty() { Space::new() } else {
              let v414_6: Path = concat_path(&(v412_6),&(v412_7_head));
              let v414_7: Space = routine_40(c, &(v414_6), &(v412_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v413_5),&(v414_7))
            };
            drop(v413_5);
            let v413_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v413_2));
            drop(v413_2);
            let v413_10: Space = if map_kernels::has_head(&(v413_9)) { singleton(&[]) } else { Space::new() };
            drop(v413_9);
            let v413_12: Space = if (v413_10).is_empty() { Space::new() } else {
              let v415_6: Path = concat_path(&(v412_6),&(v412_7_head));
              let v415_11: Space = routine_41(c, &(v415_6), &(v412_7_tail).make_space(), &(*s1));
              drop(v415_6);
              map_map_kernels::compose(&(v413_10),&(v415_11))
            };
            drop(v413_10);
            let v413_13: Space = map_map_kernels::unite(&(v413_8),&(v413_12));
            v412_7.join_into((v413_13).clone());
            }
            v412_7_cursor.ascend(1);
          }
          drop(v412_7_cursor);
          map_map_kernels::compose(&(v411_5),&(v412_7))
        };
        drop(v411_5);
        let v411_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v411_2));
        drop(v411_2);
        let v411_10: Space = if map_kernels::has_head(&(v411_9)) { singleton(&[]) } else { Space::new() };
        drop(v411_9);
        let v411_12: Space = if (v411_10).is_empty() { Space::new() } else {
          let mut v416_11 = Space::new();
          let mut v416_11_cursor = (v410_11_tail).read_zipper();
          for v416_11_byte in v416_11_cursor.child_mask().iter() {
            v416_11_cursor.descend_to_byte(v416_11_byte);
            {
            let v416_11_tail = v416_11_cursor.fork_read_zipper();
            let v416_11_head = Path::from_slice(&[v416_11_byte]);
            let v417_2: Space = singleton(&(v416_11_head));
            let v417_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v417_2));
            let v417_4: Space = if map_kernels::has_head(&(v417_3)) { singleton(&[]) } else { Space::new() };
            drop(v417_3);
            let v417_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v417_4));
            drop(v417_4);
            let v417_7: Space = if (v417_5).is_empty() { Space::new() } else {
              let v418_6: Space = routine_18(c, &(v416_11_head), &(v416_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v417_5),&(v418_6))
            };
            drop(v417_5);
            let v417_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v417_2));
            drop(v417_2);
            let v417_9: Space = if map_kernels::has_head(&(v417_8)) { singleton(&[]) } else { Space::new() };
            drop(v417_8);
            let v417_11: Space = if (v417_9).is_empty() { Space::new() } else {
              let v419_10: Space = routine_19(c, &(v416_11_head), &(v416_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v417_9),&(v419_10))
            };
            drop(v417_9);
            let v417_12: Space = map_map_kernels::unite(&(v417_7),&(v417_11));
            v416_11.join_into((v417_12).clone());
            }
            v416_11_cursor.ascend(1);
          }
          drop(v416_11_cursor);
          map_map_kernels::compose(&(v411_10),&(v416_11))
        };
        drop(v411_10);
        let v420_6: Path = concat_path(&(v410_6),&(v410_11_head));
        let v411_13: Space = map_kernels::wrap(&(v411_12),&(v420_6));
        let v411_14: Space = map_map_kernels::unite(&(v411_8),&(v411_13));
        v410_11.join_into((v411_14).clone());
        }
        v410_11_cursor.ascend(1);
      }
      drop(v410_11_cursor);
      drop(v410_6);
      map_map_kernels::compose(&(v399_10),&(v410_11))
    };
    drop(v399_10);
    let v399_13: Space = map_map_kernels::unite(&(v399_8),&(v399_12));
    v398_24.join_into((v399_13).clone());
    }
    v398_24_cursor.ascend(1);
  }
  drop(v398_24_cursor);
  (v398_24).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v421_24 = Space::new();
  let mut v421_24_cursor = (*s0).read_zipper();
  for v421_24_byte in v421_24_cursor.child_mask().iter() {
    v421_24_cursor.descend_to_byte(v421_24_byte);
    {
    let v421_24_tail = v421_24_cursor.fork_read_zipper();
    let v421_24_head = Path::from_slice(&[v421_24_byte]);
    let v422_2: Space = singleton(&(v421_24_head));
    let v422_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v422_2));
    let v422_4: Space = if map_kernels::has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
    drop(v422_3);
    let v422_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v422_4));
    drop(v422_4);
    let v422_8: Space = if (v422_5).is_empty() { Space::new() } else {
      let v423_6: Path = concat_path(&(*p0),&(v421_24_head));
      let mut v423_7 = Space::new();
      let mut v423_7_cursor = (v421_24_tail).read_zipper();
      for v423_7_byte in v423_7_cursor.child_mask().iter() {
        v423_7_cursor.descend_to_byte(v423_7_byte);
        {
        let v423_7_tail = v423_7_cursor.fork_read_zipper();
        let v423_7_head = Path::from_slice(&[v423_7_byte]);
        let v424_2: Space = singleton(&(v423_7_head));
        let v424_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v424_2));
        let v424_4: Space = if map_kernels::has_head(&(v424_3)) { singleton(&[]) } else { Space::new() };
        drop(v424_3);
        let v424_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v424_4));
        drop(v424_4);
        let v424_8: Space = if (v424_5).is_empty() { Space::new() } else {
          let v425_6: Path = concat_path(&(v423_6),&(v423_7_head));
          let mut v425_7 = Space::new();
          let mut v425_7_cursor = (v423_7_tail).read_zipper();
          for v425_7_byte in v425_7_cursor.child_mask().iter() {
            v425_7_cursor.descend_to_byte(v425_7_byte);
            {
            let v425_7_tail = v425_7_cursor.fork_read_zipper();
            let v425_7_head = Path::from_slice(&[v425_7_byte]);
            let v426_2: Space = singleton(&(v425_7_head));
            let v426_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v426_2));
            let v426_4: Space = if map_kernels::has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
            drop(v426_3);
            let v426_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v426_4));
            drop(v426_4);
            let v426_8: Space = if (v426_5).is_empty() { Space::new() } else {
              let v427_6: Path = concat_path(&(v425_6),&(v425_7_head));
              let v427_7: Space = routine_40(c, &(v427_6), &(v425_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v426_5),&(v427_7))
            };
            drop(v426_5);
            let v426_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v426_2));
            drop(v426_2);
            let v426_10: Space = if map_kernels::has_head(&(v426_9)) { singleton(&[]) } else { Space::new() };
            drop(v426_9);
            let v426_12: Space = if (v426_10).is_empty() { Space::new() } else {
              let v428_6: Path = concat_path(&(v425_6),&(v425_7_head));
              let v428_11: Space = routine_41(c, &(v428_6), &(v425_7_tail).make_space(), &(*s1));
              drop(v428_6);
              map_map_kernels::compose(&(v426_10),&(v428_11))
            };
            drop(v426_10);
            let v426_13: Space = map_map_kernels::unite(&(v426_8),&(v426_12));
            v425_7.join_into((v426_13).clone());
            }
            v425_7_cursor.ascend(1);
          }
          drop(v425_7_cursor);
          map_map_kernels::compose(&(v424_5),&(v425_7))
        };
        drop(v424_5);
        let v424_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v424_2));
        drop(v424_2);
        let v424_10: Space = if map_kernels::has_head(&(v424_9)) { singleton(&[]) } else { Space::new() };
        drop(v424_9);
        let v424_12: Space = if (v424_10).is_empty() { Space::new() } else {
          let v429_6: Path = concat_path(&(v423_6),&(v423_7_head));
          let mut v429_11 = Space::new();
          let mut v429_11_cursor = (v423_7_tail).read_zipper();
          for v429_11_byte in v429_11_cursor.child_mask().iter() {
            v429_11_cursor.descend_to_byte(v429_11_byte);
            {
            let v429_11_tail = v429_11_cursor.fork_read_zipper();
            let v429_11_head = Path::from_slice(&[v429_11_byte]);
            let v430_2: Space = singleton(&(v429_11_head));
            let v430_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v430_2));
            let v430_4: Space = if map_kernels::has_head(&(v430_3)) { singleton(&[]) } else { Space::new() };
            drop(v430_3);
            let v430_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v430_4));
            drop(v430_4);
            let v430_8: Space = if (v430_5).is_empty() { Space::new() } else {
              let v431_6: Path = concat_path(&(v429_6),&(v429_11_head));
              let v431_7: Space = routine_40(c, &(v431_6), &(v429_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v430_5),&(v431_7))
            };
            drop(v430_5);
            let v430_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v430_2));
            drop(v430_2);
            let v430_10: Space = if map_kernels::has_head(&(v430_9)) { singleton(&[]) } else { Space::new() };
            drop(v430_9);
            let v430_12: Space = if (v430_10).is_empty() { Space::new() } else {
              let v432_6: Path = concat_path(&(v429_6),&(v429_11_head));
              let v432_11: Space = routine_17(c, &(v432_6), &(v429_11_tail).make_space(), &(*s1));
              drop(v432_6);
              map_map_kernels::compose(&(v430_10),&(v432_11))
            };
            drop(v430_10);
            let v430_13: Space = map_map_kernels::unite(&(v430_8),&(v430_12));
            v429_11.join_into((v430_13).clone());
            }
            v429_11_cursor.ascend(1);
          }
          drop(v429_11_cursor);
          drop(v429_6);
          map_map_kernels::compose(&(v424_10),&(v429_11))
        };
        drop(v424_10);
        let v424_13: Space = map_map_kernels::unite(&(v424_8),&(v424_12));
        v423_7.join_into((v424_13).clone());
        }
        v423_7_cursor.ascend(1);
      }
      drop(v423_7_cursor);
      map_map_kernels::compose(&(v422_5),&(v423_7))
    };
    drop(v422_5);
    let v422_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v422_2));
    drop(v422_2);
    let v422_10: Space = if map_kernels::has_head(&(v422_9)) { singleton(&[]) } else { Space::new() };
    drop(v422_9);
    let v422_12: Space = if (v422_10).is_empty() { Space::new() } else {
      let mut v433_11 = Space::new();
      let mut v433_11_cursor = (v421_24_tail).read_zipper();
      for v433_11_byte in v433_11_cursor.child_mask().iter() {
        v433_11_cursor.descend_to_byte(v433_11_byte);
        {
        let v433_11_tail = v433_11_cursor.fork_read_zipper();
        let v433_11_head = Path::from_slice(&[v433_11_byte]);
        let v434_2: Space = singleton(&(v433_11_head));
        let v434_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v434_2));
        let v434_4: Space = if map_kernels::has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
        drop(v434_3);
        let v434_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v434_4));
        drop(v434_4);
        let v434_7: Space = if (v434_5).is_empty() { Space::new() } else {
          let mut v435_6 = Space::new();
          let mut v435_6_cursor = (v433_11_tail).read_zipper();
          for v435_6_byte in v435_6_cursor.child_mask().iter() {
            v435_6_cursor.descend_to_byte(v435_6_byte);
            {
            let v435_6_tail = v435_6_cursor.fork_read_zipper();
            let v435_6_head = Path::from_slice(&[v435_6_byte]);
            let v436_2: Space = singleton(&(v435_6_head));
            let v436_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v436_2));
            let v436_4: Space = if map_kernels::has_head(&(v436_3)) { singleton(&[]) } else { Space::new() };
            drop(v436_3);
            let v436_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v436_4));
            drop(v436_4);
            let v436_8: Space = if (v436_5).is_empty() { Space::new() } else {
              let v437_6: Path = concat_path(&(v433_11_head),&(v435_6_head));
              let v437_7: Space = routine_42(c, &(v437_6), &(v435_6_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v436_5),&(v437_7))
            };
            drop(v436_5);
            let v436_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v436_2));
            drop(v436_2);
            let v436_10: Space = if map_kernels::has_head(&(v436_9)) { singleton(&[]) } else { Space::new() };
            drop(v436_9);
            let v436_12: Space = if (v436_10).is_empty() { Space::new() } else {
              let v438_6: Path = concat_path(&(v433_11_head),&(v435_6_head));
              let v438_11: Space = routine_43(c, &(v438_6), &(v435_6_tail).make_space(), &(*s1));
              drop(v438_6);
              map_map_kernels::compose(&(v436_10),&(v438_11))
            };
            drop(v436_10);
            let v436_13: Space = map_map_kernels::unite(&(v436_8),&(v436_12));
            v435_6.join_into((v436_13).clone());
            }
            v435_6_cursor.ascend(1);
          }
          drop(v435_6_cursor);
          map_map_kernels::compose(&(v434_5),&(v435_6))
        };
        drop(v434_5);
        let v434_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v434_2));
        drop(v434_2);
        let v434_9: Space = if map_kernels::has_head(&(v434_8)) { singleton(&[]) } else { Space::new() };
        drop(v434_8);
        let v434_11: Space = if (v434_9).is_empty() { Space::new() } else {
          let mut v439_10 = Space::new();
          let mut v439_10_cursor = (v433_11_tail).read_zipper();
          for v439_10_byte in v439_10_cursor.child_mask().iter() {
            v439_10_cursor.descend_to_byte(v439_10_byte);
            {
            let v439_10_tail = v439_10_cursor.fork_read_zipper();
            let v439_10_head = Path::from_slice(&[v439_10_byte]);
            let v440_2: Space = singleton(&(v439_10_head));
            let v440_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v440_2));
            let v440_4: Space = if map_kernels::has_head(&(v440_3)) { singleton(&[]) } else { Space::new() };
            drop(v440_3);
            let v440_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v440_4));
            drop(v440_4);
            let v440_8: Space = if (v440_5).is_empty() { Space::new() } else {
              let v441_6: Path = concat_path(&(v433_11_head),&(v439_10_head));
              let v441_7: Space = routine_42(c, &(v441_6), &(v439_10_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v440_5),&(v441_7))
            };
            drop(v440_5);
            let v440_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v440_2));
            drop(v440_2);
            let v440_10: Space = if map_kernels::has_head(&(v440_9)) { singleton(&[]) } else { Space::new() };
            drop(v440_9);
            let v440_12: Space = if (v440_10).is_empty() { Space::new() } else {
              let v442_6: Path = concat_path(&(v433_11_head),&(v439_10_head));
              let v442_11: Space = routine_44(c, &(v442_6), &(v439_10_tail).make_space(), &(*s1));
              drop(v442_6);
              map_map_kernels::compose(&(v440_10),&(v442_11))
            };
            drop(v440_10);
            let v440_13: Space = map_map_kernels::unite(&(v440_8),&(v440_12));
            v439_10.join_into((v440_13).clone());
            }
            v439_10_cursor.ascend(1);
          }
          drop(v439_10_cursor);
          map_map_kernels::compose(&(v434_9),&(v439_10))
        };
        drop(v434_9);
        let v434_12: Space = map_map_kernels::unite(&(v434_7),&(v434_11));
        v433_11.join_into((v434_12).clone());
        }
        v433_11_cursor.ascend(1);
      }
      drop(v433_11_cursor);
      map_map_kernels::compose(&(v422_10),&(v433_11))
    };
    drop(v422_10);
    let v443_6: Path = concat_path(&(*p0),&(v421_24_head));
    let v422_13: Space = map_kernels::wrap(&(v422_12),&(v443_6));
    let v422_14: Space = map_map_kernels::unite(&(v422_8),&(v422_13));
    v421_24.join_into((v422_14).clone());
    }
    v421_24_cursor.ascend(1);
  }
  drop(v421_24_cursor);
  (v421_24).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v444_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v444_22: Space = map_kernels::unwrap(&(v444_21),&(*CONSTANT_4));
  drop(v444_21);
  let mut v444_26 = Space::new();
  let mut v444_26_cursor = (*s0).read_zipper();
  for v444_26_byte in v444_26_cursor.child_mask().iter() {
    v444_26_cursor.descend_to_byte(v444_26_byte);
    {
    let v444_26_tail = v444_26_cursor.fork_read_zipper();
    let v444_26_head = Path::from_slice(&[v444_26_byte]);
    let v445_2: Space = singleton(&(v444_26_head));
    let v445_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v445_2));
    let v445_4: Space = if map_kernels::has_head(&(v445_3)) { singleton(&[]) } else { Space::new() };
    drop(v445_3);
    let v445_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v445_4));
    drop(v445_4);
    let v445_7: Space = if (v445_5).is_empty() { Space::new() } else {
      let mut v446_6 = Space::new();
      let mut v446_6_cursor = (v444_26_tail).read_zipper();
      for v446_6_byte in v446_6_cursor.child_mask().iter() {
        v446_6_cursor.descend_to_byte(v446_6_byte);
        {
        let v446_6_tail = v446_6_cursor.fork_read_zipper();
        let v446_6_head = Path::from_slice(&[v446_6_byte]);
        let v447_2: Space = singleton(&(v446_6_head));
        let v447_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v447_2));
        let v447_4: Space = if map_kernels::has_head(&(v447_3)) { singleton(&[]) } else { Space::new() };
        drop(v447_3);
        let v447_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v447_4));
        drop(v447_4);
        let v447_8: Space = if (v447_5).is_empty() { Space::new() } else {
          let v448_6: Path = concat_path(&(v444_26_head),&(v446_6_head));
          let mut v448_7 = Space::new();
          let mut v448_7_cursor = (v446_6_tail).read_zipper();
          for v448_7_byte in v448_7_cursor.child_mask().iter() {
            v448_7_cursor.descend_to_byte(v448_7_byte);
            {
            let v448_7_tail = v448_7_cursor.fork_read_zipper();
            let v448_7_head = Path::from_slice(&[v448_7_byte]);
            let v449_2: Space = singleton(&(v448_7_head));
            let v449_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v449_2));
            let v449_4: Space = if map_kernels::has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
            drop(v449_3);
            let v449_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v449_4));
            drop(v449_4);
            let v449_8: Space = if (v449_5).is_empty() { Space::new() } else {
              let v450_6: Path = concat_path(&(v448_6),&(v448_7_head));
              let v450_7: Space = routine_45(c, &(v450_6), &(v448_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v449_5),&(v450_7))
            };
            drop(v449_5);
            let v449_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v449_2));
            drop(v449_2);
            let v449_10: Space = if map_kernels::has_head(&(v449_9)) { singleton(&[]) } else { Space::new() };
            drop(v449_9);
            let v449_12: Space = if (v449_10).is_empty() { Space::new() } else {
              let v451_6: Path = concat_path(&(v448_6),&(v448_7_head));
              let v451_11: Space = routine_46(c, &(v451_6), &(v448_7_tail).make_space(), &(*s1));
              drop(v451_6);
              map_map_kernels::compose(&(v449_10),&(v451_11))
            };
            drop(v449_10);
            let v449_13: Space = map_map_kernels::unite(&(v449_8),&(v449_12));
            v448_7.join_into((v449_13).clone());
            }
            v448_7_cursor.ascend(1);
          }
          drop(v448_7_cursor);
          map_map_kernels::compose(&(v447_5),&(v448_7))
        };
        drop(v447_5);
        let v447_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v447_2));
        drop(v447_2);
        let v447_10: Space = if map_kernels::has_head(&(v447_9)) { singleton(&[]) } else { Space::new() };
        drop(v447_9);
        let v447_12: Space = if (v447_10).is_empty() { Space::new() } else {
          let v452_6: Path = concat_path(&(v444_26_head),&(v446_6_head));
          let mut v452_11 = Space::new();
          let mut v452_11_cursor = (v446_6_tail).read_zipper();
          for v452_11_byte in v452_11_cursor.child_mask().iter() {
            v452_11_cursor.descend_to_byte(v452_11_byte);
            {
            let v452_11_tail = v452_11_cursor.fork_read_zipper();
            let v452_11_head = Path::from_slice(&[v452_11_byte]);
            let v453_2: Space = singleton(&(v452_11_head));
            let v453_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v453_2));
            let v453_4: Space = if map_kernels::has_head(&(v453_3)) { singleton(&[]) } else { Space::new() };
            drop(v453_3);
            let v453_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v453_4));
            drop(v453_4);
            let v453_8: Space = if (v453_5).is_empty() { Space::new() } else {
              let v454_6: Path = concat_path(&(v452_6),&(v452_11_head));
              let v454_7: Space = routine_45(c, &(v454_6), &(v452_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v453_5),&(v454_7))
            };
            drop(v453_5);
            let v453_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v453_2));
            drop(v453_2);
            let v453_10: Space = if map_kernels::has_head(&(v453_9)) { singleton(&[]) } else { Space::new() };
            drop(v453_9);
            let v453_12: Space = if (v453_10).is_empty() { Space::new() } else {
              let v455_6: Path = concat_path(&(v452_6),&(v452_11_head));
              let v455_11: Space = routine_44(c, &(v455_6), &(v452_11_tail).make_space(), &(*s1));
              drop(v455_6);
              map_map_kernels::compose(&(v453_10),&(v455_11))
            };
            drop(v453_10);
            let v453_13: Space = map_map_kernels::unite(&(v453_8),&(v453_12));
            v452_11.join_into((v453_13).clone());
            }
            v452_11_cursor.ascend(1);
          }
          drop(v452_11_cursor);
          drop(v452_6);
          map_map_kernels::compose(&(v447_10),&(v452_11))
        };
        drop(v447_10);
        let v447_13: Space = map_map_kernels::unite(&(v447_8),&(v447_12));
        v446_6.join_into((v447_13).clone());
        }
        v446_6_cursor.ascend(1);
      }
      drop(v446_6_cursor);
      map_map_kernels::compose(&(v445_5),&(v446_6))
    };
    drop(v445_5);
    let v445_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v445_2));
    drop(v445_2);
    let v445_9: Space = if map_kernels::has_head(&(v445_8)) { singleton(&[]) } else { Space::new() };
    drop(v445_8);
    let v445_12: Space = if (v445_9).is_empty() { Space::new() } else {
      let v456_10: Space = map_kernels::unwrap(&(v444_22),&(v444_26_head));
      let mut v456_11 = Space::new();
      let mut v456_11_cursor = (v444_26_tail).read_zipper();
      for v456_11_byte in v456_11_cursor.child_mask().iter() {
        v456_11_cursor.descend_to_byte(v456_11_byte);
        {
        let v456_11_tail = v456_11_cursor.fork_read_zipper();
        let v456_11_head = Path::from_slice(&[v456_11_byte]);
        let v457_2: Space = singleton(&(v456_11_head));
        let v457_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v457_2));
        let v457_4: Space = if map_kernels::has_head(&(v457_3)) { singleton(&[]) } else { Space::new() };
        drop(v457_3);
        let v457_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v457_4));
        drop(v457_4);
        let v457_8: Space = if (v457_5).is_empty() { Space::new() } else {
          let v458_6: Path = concat_path(&(v444_26_head),&(v456_11_head));
          let mut v458_7 = Space::new();
          let mut v458_7_cursor = (v456_11_tail).read_zipper();
          for v458_7_byte in v458_7_cursor.child_mask().iter() {
            v458_7_cursor.descend_to_byte(v458_7_byte);
            {
            let v458_7_tail = v458_7_cursor.fork_read_zipper();
            let v458_7_head = Path::from_slice(&[v458_7_byte]);
            let v459_2: Space = singleton(&(v458_7_head));
            let v459_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v459_2));
            let v459_4: Space = if map_kernels::has_head(&(v459_3)) { singleton(&[]) } else { Space::new() };
            drop(v459_3);
            let v459_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v459_4));
            drop(v459_4);
            let v459_8: Space = if (v459_5).is_empty() { Space::new() } else {
              let v460_6: Path = concat_path(&(v458_6),&(v458_7_head));
              let v460_7: Space = routine_45(c, &(v460_6), &(v458_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v459_5),&(v460_7))
            };
            drop(v459_5);
            let v459_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v459_2));
            drop(v459_2);
            let v459_10: Space = if map_kernels::has_head(&(v459_9)) { singleton(&[]) } else { Space::new() };
            drop(v459_9);
            let v459_12: Space = if (v459_10).is_empty() { Space::new() } else {
              let v461_6: Path = concat_path(&(v458_6),&(v458_7_head));
              let v461_11: Space = routine_46(c, &(v461_6), &(v458_7_tail).make_space(), &(*s1));
              drop(v461_6);
              map_map_kernels::compose(&(v459_10),&(v461_11))
            };
            drop(v459_10);
            let v459_13: Space = map_map_kernels::unite(&(v459_8),&(v459_12));
            v458_7.join_into((v459_13).clone());
            }
            v458_7_cursor.ascend(1);
          }
          drop(v458_7_cursor);
          drop(v458_6);
          map_map_kernels::compose(&(v457_5),&(v458_7))
        };
        drop(v457_5);
        let v457_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v457_2));
        drop(v457_2);
        let v457_10: Space = if map_kernels::has_head(&(v457_9)) { singleton(&[]) } else { Space::new() };
        drop(v457_9);
        let v457_13: Space = if (v457_10).is_empty() { Space::new() } else {
          let v462_11: Space = map_kernels::unwrap(&(v456_10),&(v456_11_head));
          let v462_12: Space = map_map_kernels::subtract(&(v462_11),&(*CONSTANT_5));
          drop(v462_11);
          map_map_kernels::compose(&(v457_10),&(v462_12))
        };
        drop(v457_10);
        let v457_14: Space = map_map_kernels::unite(&(v457_8),&(v457_13));
        drop(v457_13);
        v456_11.join_into((v457_14).clone());
        }
        v456_11_cursor.ascend(1);
      }
      drop(v456_11_cursor);
      drop(v456_10);
      map_map_kernels::compose(&(v445_9),&(v456_11))
    };
    drop(v445_9);
    let v445_13: Space = map_map_kernels::unite(&(v445_7),&(v445_12));
    v444_26.join_into((v445_13).clone());
    }
    v444_26_cursor.ascend(1);
  }
  drop(v444_26_cursor);
  drop(v444_22);
  let v444_27: Space = map_kernels::wrap(&(v444_26),&(*p0));
  (v444_27).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v463_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v463_22: Space = map_kernels::unwrap(&(v463_21),&(*CONSTANT_4));
  drop(v463_21);
  let v463_23: Space = map_kernels::unwrap(&(v463_22),&(*p0));
  drop(v463_22);
  let mut v463_27 = Space::new();
  let mut v463_27_cursor = (*s0).read_zipper();
  for v463_27_byte in v463_27_cursor.child_mask().iter() {
    v463_27_cursor.descend_to_byte(v463_27_byte);
    {
    let v463_27_tail = v463_27_cursor.fork_read_zipper();
    let v463_27_head = Path::from_slice(&[v463_27_byte]);
    let v464_2: Space = singleton(&(v463_27_head));
    let v464_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v464_2));
    let v464_4: Space = if map_kernels::has_head(&(v464_3)) { singleton(&[]) } else { Space::new() };
    drop(v464_3);
    let v464_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v464_4));
    drop(v464_4);
    let v464_8: Space = if (v464_5).is_empty() { Space::new() } else {
      let v465_6: Path = concat_path(&(*p0),&(v463_27_head));
      let mut v465_7 = Space::new();
      let mut v465_7_cursor = (v463_27_tail).read_zipper();
      for v465_7_byte in v465_7_cursor.child_mask().iter() {
        v465_7_cursor.descend_to_byte(v465_7_byte);
        {
        let v465_7_tail = v465_7_cursor.fork_read_zipper();
        let v465_7_head = Path::from_slice(&[v465_7_byte]);
        let v466_2: Space = singleton(&(v465_7_head));
        let v466_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v466_2));
        let v466_4: Space = if map_kernels::has_head(&(v466_3)) { singleton(&[]) } else { Space::new() };
        drop(v466_3);
        let v466_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v466_4));
        drop(v466_4);
        let v466_8: Space = if (v466_5).is_empty() { Space::new() } else {
          let v467_6: Path = concat_path(&(v465_6),&(v465_7_head));
          let mut v467_7 = Space::new();
          let mut v467_7_cursor = (v465_7_tail).read_zipper();
          for v467_7_byte in v467_7_cursor.child_mask().iter() {
            v467_7_cursor.descend_to_byte(v467_7_byte);
            {
            let v467_7_tail = v467_7_cursor.fork_read_zipper();
            let v467_7_head = Path::from_slice(&[v467_7_byte]);
            let v468_2: Space = singleton(&(v467_7_head));
            let v468_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v468_2));
            let v468_4: Space = if map_kernels::has_head(&(v468_3)) { singleton(&[]) } else { Space::new() };
            drop(v468_3);
            let v468_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v468_4));
            drop(v468_4);
            let v468_8: Space = if (v468_5).is_empty() { Space::new() } else {
              let v469_6: Path = concat_path(&(v467_6),&(v467_7_head));
              let v469_7: Space = routine_47(c, &(v469_6), &(v467_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v468_5),&(v469_7))
            };
            drop(v468_5);
            let v468_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v468_2));
            drop(v468_2);
            let v468_10: Space = if map_kernels::has_head(&(v468_9)) { singleton(&[]) } else { Space::new() };
            drop(v468_9);
            let v468_12: Space = if (v468_10).is_empty() { Space::new() } else {
              let v470_6: Path = concat_path(&(v467_6),&(v467_7_head));
              let v470_11: Space = routine_48(c, &(v470_6), &(v467_7_tail).make_space(), &(*s1));
              drop(v470_6);
              map_map_kernels::compose(&(v468_10),&(v470_11))
            };
            drop(v468_10);
            let v468_13: Space = map_map_kernels::unite(&(v468_8),&(v468_12));
            v467_7.join_into((v468_13).clone());
            }
            v467_7_cursor.ascend(1);
          }
          drop(v467_7_cursor);
          map_map_kernels::compose(&(v466_5),&(v467_7))
        };
        drop(v466_5);
        let v466_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v466_2));
        drop(v466_2);
        let v466_10: Space = if map_kernels::has_head(&(v466_9)) { singleton(&[]) } else { Space::new() };
        drop(v466_9);
        let v466_12: Space = if (v466_10).is_empty() { Space::new() } else {
          let v471_6: Path = concat_path(&(v465_6),&(v465_7_head));
          let mut v471_11 = Space::new();
          let mut v471_11_cursor = (v465_7_tail).read_zipper();
          for v471_11_byte in v471_11_cursor.child_mask().iter() {
            v471_11_cursor.descend_to_byte(v471_11_byte);
            {
            let v471_11_tail = v471_11_cursor.fork_read_zipper();
            let v471_11_head = Path::from_slice(&[v471_11_byte]);
            let v472_2: Space = singleton(&(v471_11_head));
            let v472_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v472_2));
            let v472_4: Space = if map_kernels::has_head(&(v472_3)) { singleton(&[]) } else { Space::new() };
            drop(v472_3);
            let v472_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v472_4));
            drop(v472_4);
            let v472_8: Space = if (v472_5).is_empty() { Space::new() } else {
              let v473_6: Path = concat_path(&(v471_6),&(v471_11_head));
              let v473_7: Space = routine_47(c, &(v473_6), &(v471_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v472_5),&(v473_7))
            };
            drop(v472_5);
            let v472_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v472_2));
            drop(v472_2);
            let v472_10: Space = if map_kernels::has_head(&(v472_9)) { singleton(&[]) } else { Space::new() };
            drop(v472_9);
            let v472_12: Space = if (v472_10).is_empty() { Space::new() } else {
              let v474_6: Path = concat_path(&(v471_6),&(v471_11_head));
              let v474_11: Space = routine_44(c, &(v474_6), &(v471_11_tail).make_space(), &(*s1));
              drop(v474_6);
              map_map_kernels::compose(&(v472_10),&(v474_11))
            };
            drop(v472_10);
            let v472_13: Space = map_map_kernels::unite(&(v472_8),&(v472_12));
            v471_11.join_into((v472_13).clone());
            }
            v471_11_cursor.ascend(1);
          }
          drop(v471_11_cursor);
          drop(v471_6);
          map_map_kernels::compose(&(v466_10),&(v471_11))
        };
        drop(v466_10);
        let v466_13: Space = map_map_kernels::unite(&(v466_8),&(v466_12));
        v465_7.join_into((v466_13).clone());
        }
        v465_7_cursor.ascend(1);
      }
      drop(v465_7_cursor);
      map_map_kernels::compose(&(v464_5),&(v465_7))
    };
    drop(v464_5);
    let v464_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v464_2));
    drop(v464_2);
    let v464_10: Space = if map_kernels::has_head(&(v464_9)) { singleton(&[]) } else { Space::new() };
    drop(v464_9);
    let v464_13: Space = if (v464_10).is_empty() { Space::new() } else {
      let v475_6: Path = concat_path(&(*p0),&(v463_27_head));
      let v475_11: Space = map_kernels::unwrap(&(v463_23),&(v463_27_head));
      let mut v475_12 = Space::new();
      let mut v475_12_cursor = (v463_27_tail).read_zipper();
      for v475_12_byte in v475_12_cursor.child_mask().iter() {
        v475_12_cursor.descend_to_byte(v475_12_byte);
        {
        let v475_12_tail = v475_12_cursor.fork_read_zipper();
        let v475_12_head = Path::from_slice(&[v475_12_byte]);
        let v476_2: Space = singleton(&(v475_12_head));
        let v476_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v476_2));
        let v476_4: Space = if map_kernels::has_head(&(v476_3)) { singleton(&[]) } else { Space::new() };
        drop(v476_3);
        let v476_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v476_4));
        drop(v476_4);
        let v476_8: Space = if (v476_5).is_empty() { Space::new() } else {
          let v477_6: Path = concat_path(&(v475_6),&(v475_12_head));
          let mut v477_7 = Space::new();
          let mut v477_7_cursor = (v475_12_tail).read_zipper();
          for v477_7_byte in v477_7_cursor.child_mask().iter() {
            v477_7_cursor.descend_to_byte(v477_7_byte);
            {
            let v477_7_tail = v477_7_cursor.fork_read_zipper();
            let v477_7_head = Path::from_slice(&[v477_7_byte]);
            let v478_2: Space = singleton(&(v477_7_head));
            let v478_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v478_2));
            let v478_4: Space = if map_kernels::has_head(&(v478_3)) { singleton(&[]) } else { Space::new() };
            drop(v478_3);
            let v478_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v478_4));
            drop(v478_4);
            let v478_8: Space = if (v478_5).is_empty() { Space::new() } else {
              let v479_6: Path = concat_path(&(v477_6),&(v477_7_head));
              let v479_7: Space = routine_47(c, &(v479_6), &(v477_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v478_5),&(v479_7))
            };
            drop(v478_5);
            let v478_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v478_2));
            drop(v478_2);
            let v478_10: Space = if map_kernels::has_head(&(v478_9)) { singleton(&[]) } else { Space::new() };
            drop(v478_9);
            let v478_12: Space = if (v478_10).is_empty() { Space::new() } else {
              let v480_6: Path = concat_path(&(v477_6),&(v477_7_head));
              let v480_11: Space = routine_48(c, &(v480_6), &(v477_7_tail).make_space(), &(*s1));
              drop(v480_6);
              map_map_kernels::compose(&(v478_10),&(v480_11))
            };
            drop(v478_10);
            let v478_13: Space = map_map_kernels::unite(&(v478_8),&(v478_12));
            v477_7.join_into((v478_13).clone());
            }
            v477_7_cursor.ascend(1);
          }
          drop(v477_7_cursor);
          drop(v477_6);
          map_map_kernels::compose(&(v476_5),&(v477_7))
        };
        drop(v476_5);
        let v476_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v476_2));
        drop(v476_2);
        let v476_10: Space = if map_kernels::has_head(&(v476_9)) { singleton(&[]) } else { Space::new() };
        drop(v476_9);
        let v476_13: Space = if (v476_10).is_empty() { Space::new() } else {
          let v481_11: Space = map_kernels::unwrap(&(v475_11),&(v475_12_head));
          let v481_12: Space = map_map_kernels::subtract(&(v481_11),&(*CONSTANT_5));
          drop(v481_11);
          map_map_kernels::compose(&(v476_10),&(v481_12))
        };
        drop(v476_10);
        let v476_14: Space = map_map_kernels::unite(&(v476_8),&(v476_13));
        drop(v476_13);
        v475_12.join_into((v476_14).clone());
        }
        v475_12_cursor.ascend(1);
      }
      drop(v475_12_cursor);
      drop(v475_6);
      drop(v475_11);
      map_map_kernels::compose(&(v464_10),&(v475_12))
    };
    drop(v464_10);
    let v464_14: Space = map_map_kernels::unite(&(v464_8),&(v464_13));
    v463_27.join_into((v464_14).clone());
    }
    v463_27_cursor.ascend(1);
  }
  drop(v463_27_cursor);
  drop(v463_23);
  (v463_27).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v482_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v482_9: Space = map_kernels::unwrap(&(v482_7),&(*CONSTANT_4));
  drop(v482_7);
  let v482_10: Space = map_kernels::unwrap(&(v482_9),&(*p0));
  drop(v482_9);
  let mut v482_21 = Space::new();
  let mut v482_21_cursor = (*s0).read_zipper();
  for v482_21_byte in v482_21_cursor.child_mask().iter() {
    v482_21_cursor.descend_to_byte(v482_21_byte);
    {
    let v482_21_tail = v482_21_cursor.fork_read_zipper();
    let v482_21_head = Path::from_slice(&[v482_21_byte]);
    let v483_2: Space = singleton(&(v482_21_head));
    let v483_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v483_2));
    let v483_4: Space = if map_kernels::has_head(&(v483_3)) { singleton(&[]) } else { Space::new() };
    drop(v483_3);
    let v483_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v483_4));
    drop(v483_4);
    let v483_8: Space = if (v483_5).is_empty() { Space::new() } else {
      let v484_6: Path = concat_path(&(*p0),&(v482_21_head));
      let mut v484_7 = Space::new();
      let mut v484_7_cursor = (v482_21_tail).read_zipper();
      for v484_7_byte in v484_7_cursor.child_mask().iter() {
        v484_7_cursor.descend_to_byte(v484_7_byte);
        {
        let v484_7_tail = v484_7_cursor.fork_read_zipper();
        let v484_7_head = Path::from_slice(&[v484_7_byte]);
        let v485_2: Space = singleton(&(v484_7_head));
        let v485_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v485_2));
        let v485_4: Space = if map_kernels::has_head(&(v485_3)) { singleton(&[]) } else { Space::new() };
        drop(v485_3);
        let v485_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v485_4));
        drop(v485_4);
        let v485_8: Space = if (v485_5).is_empty() { Space::new() } else {
          let v486_6: Path = concat_path(&(v484_6),&(v484_7_head));
          let mut v486_7 = Space::new();
          let mut v486_7_cursor = (v484_7_tail).read_zipper();
          for v486_7_byte in v486_7_cursor.child_mask().iter() {
            v486_7_cursor.descend_to_byte(v486_7_byte);
            {
            let v486_7_tail = v486_7_cursor.fork_read_zipper();
            let v486_7_head = Path::from_slice(&[v486_7_byte]);
            let v487_2: Space = singleton(&(v486_7_head));
            let v487_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v487_2));
            let v487_4: Space = if map_kernels::has_head(&(v487_3)) { singleton(&[]) } else { Space::new() };
            drop(v487_3);
            let v487_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v487_4));
            drop(v487_4);
            let v487_8: Space = if (v487_5).is_empty() { Space::new() } else {
              let v488_6: Path = concat_path(&(v486_6),&(v486_7_head));
              let v488_7: Space = routine_47(c, &(v488_6), &(v486_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v487_5),&(v488_7))
            };
            drop(v487_5);
            let v487_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v487_2));
            drop(v487_2);
            let v487_10: Space = if map_kernels::has_head(&(v487_9)) { singleton(&[]) } else { Space::new() };
            drop(v487_9);
            let v487_12: Space = if (v487_10).is_empty() { Space::new() } else {
              let v489_6: Path = concat_path(&(v486_6),&(v486_7_head));
              let v489_11: Space = routine_48(c, &(v489_6), &(v486_7_tail).make_space(), &(*s1));
              drop(v489_6);
              map_map_kernels::compose(&(v487_10),&(v489_11))
            };
            drop(v487_10);
            let v487_13: Space = map_map_kernels::unite(&(v487_8),&(v487_12));
            v486_7.join_into((v487_13).clone());
            }
            v486_7_cursor.ascend(1);
          }
          drop(v486_7_cursor);
          map_map_kernels::compose(&(v485_5),&(v486_7))
        };
        drop(v485_5);
        let v485_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v485_2));
        drop(v485_2);
        let v485_10: Space = if map_kernels::has_head(&(v485_9)) { singleton(&[]) } else { Space::new() };
        drop(v485_9);
        let v485_12: Space = if (v485_10).is_empty() { Space::new() } else {
          let v490_6: Path = concat_path(&(v484_6),&(v484_7_head));
          let mut v490_11 = Space::new();
          let mut v490_11_cursor = (v484_7_tail).read_zipper();
          for v490_11_byte in v490_11_cursor.child_mask().iter() {
            v490_11_cursor.descend_to_byte(v490_11_byte);
            {
            let v490_11_tail = v490_11_cursor.fork_read_zipper();
            let v490_11_head = Path::from_slice(&[v490_11_byte]);
            let v491_2: Space = singleton(&(v490_11_head));
            let v491_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v491_2));
            let v491_4: Space = if map_kernels::has_head(&(v491_3)) { singleton(&[]) } else { Space::new() };
            drop(v491_3);
            let v491_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v491_4));
            drop(v491_4);
            let v491_8: Space = if (v491_5).is_empty() { Space::new() } else {
              let v492_6: Path = concat_path(&(v490_6),&(v490_11_head));
              let v492_7: Space = routine_47(c, &(v492_6), &(v490_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v491_5),&(v492_7))
            };
            drop(v491_5);
            let v491_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v491_2));
            drop(v491_2);
            let v491_10: Space = if map_kernels::has_head(&(v491_9)) { singleton(&[]) } else { Space::new() };
            drop(v491_9);
            let v491_12: Space = if (v491_10).is_empty() { Space::new() } else {
              let v493_6: Path = concat_path(&(v490_6),&(v490_11_head));
              let v493_11: Space = routine_44(c, &(v493_6), &(v490_11_tail).make_space(), &(*s1));
              drop(v493_6);
              map_map_kernels::compose(&(v491_10),&(v493_11))
            };
            drop(v491_10);
            let v491_13: Space = map_map_kernels::unite(&(v491_8),&(v491_12));
            v490_11.join_into((v491_13).clone());
            }
            v490_11_cursor.ascend(1);
          }
          drop(v490_11_cursor);
          drop(v490_6);
          map_map_kernels::compose(&(v485_10),&(v490_11))
        };
        drop(v485_10);
        let v485_13: Space = map_map_kernels::unite(&(v485_8),&(v485_12));
        v484_7.join_into((v485_13).clone());
        }
        v484_7_cursor.ascend(1);
      }
      drop(v484_7_cursor);
      drop(v484_6);
      map_map_kernels::compose(&(v483_5),&(v484_7))
    };
    drop(v483_5);
    let v483_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v483_2));
    drop(v483_2);
    let v483_10: Space = if map_kernels::has_head(&(v483_9)) { singleton(&[]) } else { Space::new() };
    drop(v483_9);
    let v483_13: Space = if (v483_10).is_empty() { Space::new() } else {
      let v494_11: Space = map_kernels::unwrap(&(v482_10),&(v482_21_head));
      let v494_12: Space = map_map_kernels::subtract(&(v494_11),&(*CONSTANT_5));
      drop(v494_11);
      map_map_kernels::compose(&(v483_10),&(v494_12))
    };
    drop(v483_10);
    let v483_14: Space = map_map_kernels::unite(&(v483_8),&(v483_13));
    drop(v483_13);
    v482_21.join_into((v483_14).clone());
    }
    v482_21_cursor.ascend(1);
  }
  drop(v482_21_cursor);
  drop(v482_10);
  (v482_21).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v495_10 = Space::new();
  let mut v495_10_cursor = (*s0).read_zipper();
  for v495_10_byte in v495_10_cursor.child_mask().iter() {
    v495_10_cursor.descend_to_byte(v495_10_byte);
    {
    let v495_10_tail = v495_10_cursor.fork_read_zipper();
    let v495_10_head = Path::from_slice(&[v495_10_byte]);
    let v496_2: Space = singleton(&(v495_10_head));
    let v496_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v496_2));
    let v496_4: Space = if map_kernels::has_head(&(v496_3)) { singleton(&[]) } else { Space::new() };
    drop(v496_3);
    let v496_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v496_4));
    drop(v496_4);
    let mut v496_6 = Space::new();
    let mut v496_6_cursor = (v495_10_tail).read_zipper();
    for v496_6_byte in v496_6_cursor.child_mask().iter() {
      v496_6_cursor.descend_to_byte(v496_6_byte);
      {
      let v496_6_tail = v496_6_cursor.fork_read_zipper();
      let v496_6_head = Path::from_slice(&[v496_6_byte]);
      let v497_2: Space = Space::new();
      v496_6.join_into((v497_2).clone());
      }
      v496_6_cursor.ascend(1);
    }
    drop(v496_6_cursor);
    let v496_7: Space = map_map_kernels::compose(&(v496_5),&(v496_6));
    drop(v496_5);
    drop(v496_6);
    let v496_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v496_2));
    drop(v496_2);
    let v496_9: Space = if map_kernels::has_head(&(v496_8)) { singleton(&[]) } else { Space::new() };
    drop(v496_8);
    let v496_12: Space = if (v496_9).is_empty() { Space::new() } else {
      let v498_10: Path = concat_path(&(*p0),&(v495_10_head));
      let mut v498_11 = Space::new();
      let mut v498_11_cursor = (v495_10_tail).read_zipper();
      for v498_11_byte in v498_11_cursor.child_mask().iter() {
        v498_11_cursor.descend_to_byte(v498_11_byte);
        {
        let v498_11_tail = v498_11_cursor.fork_read_zipper();
        let v498_11_head = Path::from_slice(&[v498_11_byte]);
        let v499_2: Space = singleton(&(v498_11_head));
        let v499_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v499_2));
        drop(v499_2);
        let v499_4: Space = if map_kernels::has_head(&(v499_3)) { singleton(&[]) } else { Space::new() };
        drop(v499_3);
        let v499_6: Space = if (v499_4).is_empty() { Space::new() } else {
          let mut v500_5 = Space::new();
          let mut v500_5_cursor = (v498_11_tail).read_zipper();
          for v500_5_byte in v500_5_cursor.child_mask().iter() {
            v500_5_cursor.descend_to_byte(v500_5_byte);
            {
            let v500_5_tail = v500_5_cursor.fork_read_zipper();
            let v500_5_head = Path::from_slice(&[v500_5_byte]);
            let v501_2: Space = singleton(&(v500_5_head));
            let v501_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v501_2));
            let v501_4: Space = if map_kernels::has_head(&(v501_3)) { singleton(&[]) } else { Space::new() };
            drop(v501_3);
            let v501_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v501_4));
            drop(v501_4);
            let v501_7: Space = if (v501_5).is_empty() { Space::new() } else {
              let v502_6: Space = routine_5(c, &(v500_5_head), &(v500_5_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v501_5),&(v502_6))
            };
            drop(v501_5);
            let v501_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v501_2));
            drop(v501_2);
            let v501_9: Space = if map_kernels::has_head(&(v501_8)) { singleton(&[]) } else { Space::new() };
            drop(v501_8);
            let v501_11: Space = if (v501_9).is_empty() { Space::new() } else {
              let v503_10: Space = routine_6(c, &(v500_5_head), &(v500_5_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v501_9),&(v503_10))
            };
            drop(v501_9);
            let v501_12: Space = map_map_kernels::unite(&(v501_7),&(v501_11));
            v500_5.join_into((v501_12).clone());
            }
            v500_5_cursor.ascend(1);
          }
          drop(v500_5_cursor);
          map_map_kernels::compose(&(v499_4),&(v500_5))
        };
        drop(v499_4);
        let v499_7: Path = concat_path(&(v498_10),&(v498_11_head));
        let v499_8: Space = map_kernels::wrap(&(v499_6),&(v499_7));
        drop(v499_7);
        v498_11.join_into((v499_8).clone());
        }
        v498_11_cursor.ascend(1);
      }
      drop(v498_11_cursor);
      drop(v498_10);
      map_map_kernels::compose(&(v496_9),&(v498_11))
    };
    drop(v496_9);
    let v496_13: Space = map_map_kernels::unite(&(v496_7),&(v496_12));
    drop(v496_7);
    v495_10.join_into((v496_13).clone());
    }
    v495_10_cursor.ascend(1);
  }
  drop(v495_10_cursor);
  (v495_10).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v504_15 = Space::new();
  let mut v504_15_cursor = (*s0).read_zipper();
  for v504_15_byte in v504_15_cursor.child_mask().iter() {
    v504_15_cursor.descend_to_byte(v504_15_byte);
    {
    let v504_15_tail = v504_15_cursor.fork_read_zipper();
    let v504_15_head = Path::from_slice(&[v504_15_byte]);
    let v505_2: Space = singleton(&(v504_15_head));
    let v505_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v505_2));
    let v505_4: Space = if map_kernels::has_head(&(v505_3)) { singleton(&[]) } else { Space::new() };
    drop(v505_3);
    let v505_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v505_4));
    drop(v505_4);
    let mut v505_6 = Space::new();
    let mut v505_6_cursor = (v504_15_tail).read_zipper();
    for v505_6_byte in v505_6_cursor.child_mask().iter() {
      v505_6_cursor.descend_to_byte(v505_6_byte);
      {
      let v505_6_tail = v505_6_cursor.fork_read_zipper();
      let v505_6_head = Path::from_slice(&[v505_6_byte]);
      let v506_2: Space = Space::new();
      v505_6.join_into((v506_2).clone());
      }
      v505_6_cursor.ascend(1);
    }
    drop(v505_6_cursor);
    let v505_7: Space = map_map_kernels::compose(&(v505_5),&(v505_6));
    drop(v505_5);
    drop(v505_6);
    let v505_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v505_2));
    drop(v505_2);
    let v505_9: Space = if map_kernels::has_head(&(v505_8)) { singleton(&[]) } else { Space::new() };
    drop(v505_8);
    let v505_11: Space = if (v505_9).is_empty() { Space::new() } else {
      let mut v507_10 = Space::new();
      let mut v507_10_cursor = (v504_15_tail).read_zipper();
      for v507_10_byte in v507_10_cursor.child_mask().iter() {
        v507_10_cursor.descend_to_byte(v507_10_byte);
        {
        let v507_10_tail = v507_10_cursor.fork_read_zipper();
        let v507_10_head = Path::from_slice(&[v507_10_byte]);
        let v508_2: Space = singleton(&(v507_10_head));
        let v508_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v508_2));
        let v508_4: Space = if map_kernels::has_head(&(v508_3)) { singleton(&[]) } else { Space::new() };
        drop(v508_3);
        let v508_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v508_4));
        drop(v508_4);
        let v508_7: Space = if (v508_5).is_empty() { Space::new() } else {
          let mut v509_6 = Space::new();
          let mut v509_6_cursor = (v507_10_tail).read_zipper();
          for v509_6_byte in v509_6_cursor.child_mask().iter() {
            v509_6_cursor.descend_to_byte(v509_6_byte);
            {
            let v509_6_tail = v509_6_cursor.fork_read_zipper();
            let v509_6_head = Path::from_slice(&[v509_6_byte]);
            let v510_2: Space = singleton(&(v509_6_head));
            let v510_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v510_2));
            let v510_4: Space = if map_kernels::has_head(&(v510_3)) { singleton(&[]) } else { Space::new() };
            drop(v510_3);
            let v510_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v510_4));
            drop(v510_4);
            let v510_8: Space = if (v510_5).is_empty() { Space::new() } else {
              let v511_6: Path = concat_path(&(v507_10_head),&(v509_6_head));
              let v511_7: Space = routine_22(c, &(v511_6), &(v509_6_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v510_5),&(v511_7))
            };
            drop(v510_5);
            let v510_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v510_2));
            drop(v510_2);
            let v510_10: Space = if map_kernels::has_head(&(v510_9)) { singleton(&[]) } else { Space::new() };
            drop(v510_9);
            let v510_12: Space = if (v510_10).is_empty() { Space::new() } else {
              let v512_6: Path = concat_path(&(v507_10_head),&(v509_6_head));
              let v512_11: Space = routine_23(c, &(v512_6), &(v509_6_tail).make_space(), &(*s1));
              drop(v512_6);
              map_map_kernels::compose(&(v510_10),&(v512_11))
            };
            drop(v510_10);
            let v510_13: Space = map_map_kernels::unite(&(v510_8),&(v510_12));
            v509_6.join_into((v510_13).clone());
            }
            v509_6_cursor.ascend(1);
          }
          drop(v509_6_cursor);
          map_map_kernels::compose(&(v508_5),&(v509_6))
        };
        drop(v508_5);
        let v508_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v508_2));
        drop(v508_2);
        let v508_9: Space = if map_kernels::has_head(&(v508_8)) { singleton(&[]) } else { Space::new() };
        drop(v508_8);
        let v508_11: Space = if (v508_9).is_empty() { Space::new() } else {
          let mut v513_10 = Space::new();
          let mut v513_10_cursor = (v507_10_tail).read_zipper();
          for v513_10_byte in v513_10_cursor.child_mask().iter() {
            v513_10_cursor.descend_to_byte(v513_10_byte);
            {
            let v513_10_tail = v513_10_cursor.fork_read_zipper();
            let v513_10_head = Path::from_slice(&[v513_10_byte]);
            let v514_2: Space = singleton(&(v513_10_head));
            let v514_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v514_2));
            let v514_4: Space = if map_kernels::has_head(&(v514_3)) { singleton(&[]) } else { Space::new() };
            drop(v514_3);
            let v514_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v514_4));
            drop(v514_4);
            let v514_8: Space = if (v514_5).is_empty() { Space::new() } else {
              let v515_6: Path = concat_path(&(v507_10_head),&(v513_10_head));
              let v515_7: Space = routine_22(c, &(v515_6), &(v513_10_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v514_5),&(v515_7))
            };
            drop(v514_5);
            let v514_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v514_2));
            drop(v514_2);
            let v514_10: Space = if map_kernels::has_head(&(v514_9)) { singleton(&[]) } else { Space::new() };
            drop(v514_9);
            let v514_12: Space = if (v514_10).is_empty() { Space::new() } else {
              let v516_6: Path = concat_path(&(v507_10_head),&(v513_10_head));
              let v516_11: Space = routine_24(c, &(v516_6), &(v513_10_tail).make_space(), &(*s1));
              drop(v516_6);
              map_map_kernels::compose(&(v514_10),&(v516_11))
            };
            drop(v514_10);
            let v514_13: Space = map_map_kernels::unite(&(v514_8),&(v514_12));
            v513_10.join_into((v514_13).clone());
            }
            v513_10_cursor.ascend(1);
          }
          drop(v513_10_cursor);
          map_map_kernels::compose(&(v508_9),&(v513_10))
        };
        drop(v508_9);
        let v508_12: Space = map_map_kernels::unite(&(v508_7),&(v508_11));
        v507_10.join_into((v508_12).clone());
        }
        v507_10_cursor.ascend(1);
      }
      drop(v507_10_cursor);
      map_map_kernels::compose(&(v505_9),&(v507_10))
    };
    drop(v505_9);
    let v505_12: Path = concat_path(&(*p0),&(v504_15_head));
    let v505_13: Space = map_kernels::wrap(&(v505_11),&(v505_12));
    drop(v505_12);
    let v505_14: Space = map_map_kernels::unite(&(v505_7),&(v505_13));
    drop(v505_7);
    v504_15.join_into((v505_14).clone());
    }
    v504_15_cursor.ascend(1);
  }
  drop(v504_15_cursor);
  (v504_15).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v517_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v517_22: Space = map_kernels::unwrap(&(v517_21),&(*CONSTANT_4));
  drop(v517_21);
  let v517_23: Space = map_kernels::unwrap(&(v517_22),&(*p0));
  drop(v517_22);
  let mut v517_27 = Space::new();
  let mut v517_27_cursor = (*s0).read_zipper();
  for v517_27_byte in v517_27_cursor.child_mask().iter() {
    v517_27_cursor.descend_to_byte(v517_27_byte);
    {
    let v517_27_tail = v517_27_cursor.fork_read_zipper();
    let v517_27_head = Path::from_slice(&[v517_27_byte]);
    let v518_2: Space = singleton(&(v517_27_head));
    let v518_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v518_2));
    let v518_4: Space = if map_kernels::has_head(&(v518_3)) { singleton(&[]) } else { Space::new() };
    drop(v518_3);
    let v518_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v518_4));
    drop(v518_4);
    let v518_8: Space = if (v518_5).is_empty() { Space::new() } else {
      let v519_6: Path = concat_path(&(*p0),&(v517_27_head));
      let mut v519_7 = Space::new();
      let mut v519_7_cursor = (v517_27_tail).read_zipper();
      for v519_7_byte in v519_7_cursor.child_mask().iter() {
        v519_7_cursor.descend_to_byte(v519_7_byte);
        {
        let v519_7_tail = v519_7_cursor.fork_read_zipper();
        let v519_7_head = Path::from_slice(&[v519_7_byte]);
        let v520_2: Space = singleton(&(v519_7_head));
        let v520_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v520_2));
        let v520_4: Space = if map_kernels::has_head(&(v520_3)) { singleton(&[]) } else { Space::new() };
        drop(v520_3);
        let v520_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v520_4));
        drop(v520_4);
        let v520_8: Space = if (v520_5).is_empty() { Space::new() } else {
          let v521_6: Path = concat_path(&(v519_6),&(v519_7_head));
          let mut v521_7 = Space::new();
          let mut v521_7_cursor = (v519_7_tail).read_zipper();
          for v521_7_byte in v521_7_cursor.child_mask().iter() {
            v521_7_cursor.descend_to_byte(v521_7_byte);
            {
            let v521_7_tail = v521_7_cursor.fork_read_zipper();
            let v521_7_head = Path::from_slice(&[v521_7_byte]);
            let v522_2: Space = singleton(&(v521_7_head));
            let v522_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v522_2));
            let v522_4: Space = if map_kernels::has_head(&(v522_3)) { singleton(&[]) } else { Space::new() };
            drop(v522_3);
            let v522_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v522_4));
            drop(v522_4);
            let v522_8: Space = if (v522_5).is_empty() { Space::new() } else {
              let v523_6: Path = concat_path(&(v521_6),&(v521_7_head));
              let v523_7: Space = routine_49(c, &(v523_6), &(v521_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v522_5),&(v523_7))
            };
            drop(v522_5);
            let v522_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v522_2));
            drop(v522_2);
            let v522_10: Space = if map_kernels::has_head(&(v522_9)) { singleton(&[]) } else { Space::new() };
            drop(v522_9);
            let v522_12: Space = if (v522_10).is_empty() { Space::new() } else {
              let v524_6: Path = concat_path(&(v521_6),&(v521_7_head));
              let v524_11: Space = routine_50(c, &(v524_6), &(v521_7_tail).make_space(), &(*s1));
              drop(v524_6);
              map_map_kernels::compose(&(v522_10),&(v524_11))
            };
            drop(v522_10);
            let v522_13: Space = map_map_kernels::unite(&(v522_8),&(v522_12));
            v521_7.join_into((v522_13).clone());
            }
            v521_7_cursor.ascend(1);
          }
          drop(v521_7_cursor);
          map_map_kernels::compose(&(v520_5),&(v521_7))
        };
        drop(v520_5);
        let v520_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v520_2));
        drop(v520_2);
        let v520_10: Space = if map_kernels::has_head(&(v520_9)) { singleton(&[]) } else { Space::new() };
        drop(v520_9);
        let v520_12: Space = if (v520_10).is_empty() { Space::new() } else {
          let v525_6: Path = concat_path(&(v519_6),&(v519_7_head));
          let mut v525_11 = Space::new();
          let mut v525_11_cursor = (v519_7_tail).read_zipper();
          for v525_11_byte in v525_11_cursor.child_mask().iter() {
            v525_11_cursor.descend_to_byte(v525_11_byte);
            {
            let v525_11_tail = v525_11_cursor.fork_read_zipper();
            let v525_11_head = Path::from_slice(&[v525_11_byte]);
            let v526_2: Space = singleton(&(v525_11_head));
            let v526_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v526_2));
            let v526_4: Space = if map_kernels::has_head(&(v526_3)) { singleton(&[]) } else { Space::new() };
            drop(v526_3);
            let v526_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v526_4));
            drop(v526_4);
            let v526_8: Space = if (v526_5).is_empty() { Space::new() } else {
              let v527_6: Path = concat_path(&(v525_6),&(v525_11_head));
              let v527_7: Space = routine_49(c, &(v527_6), &(v525_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v526_5),&(v527_7))
            };
            drop(v526_5);
            let v526_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v526_2));
            drop(v526_2);
            let v526_10: Space = if map_kernels::has_head(&(v526_9)) { singleton(&[]) } else { Space::new() };
            drop(v526_9);
            let v526_12: Space = if (v526_10).is_empty() { Space::new() } else {
              let v528_6: Path = concat_path(&(v525_6),&(v525_11_head));
              let v528_11: Space = routine_24(c, &(v528_6), &(v525_11_tail).make_space(), &(*s1));
              drop(v528_6);
              map_map_kernels::compose(&(v526_10),&(v528_11))
            };
            drop(v526_10);
            let v526_13: Space = map_map_kernels::unite(&(v526_8),&(v526_12));
            v525_11.join_into((v526_13).clone());
            }
            v525_11_cursor.ascend(1);
          }
          drop(v525_11_cursor);
          drop(v525_6);
          map_map_kernels::compose(&(v520_10),&(v525_11))
        };
        drop(v520_10);
        let v520_13: Space = map_map_kernels::unite(&(v520_8),&(v520_12));
        v519_7.join_into((v520_13).clone());
        }
        v519_7_cursor.ascend(1);
      }
      drop(v519_7_cursor);
      map_map_kernels::compose(&(v518_5),&(v519_7))
    };
    drop(v518_5);
    let v518_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v518_2));
    drop(v518_2);
    let v518_10: Space = if map_kernels::has_head(&(v518_9)) { singleton(&[]) } else { Space::new() };
    drop(v518_9);
    let v518_13: Space = if (v518_10).is_empty() { Space::new() } else {
      let v529_6: Path = concat_path(&(*p0),&(v517_27_head));
      let v529_11: Space = map_kernels::unwrap(&(v517_23),&(v517_27_head));
      let mut v529_12 = Space::new();
      let mut v529_12_cursor = (v517_27_tail).read_zipper();
      for v529_12_byte in v529_12_cursor.child_mask().iter() {
        v529_12_cursor.descend_to_byte(v529_12_byte);
        {
        let v529_12_tail = v529_12_cursor.fork_read_zipper();
        let v529_12_head = Path::from_slice(&[v529_12_byte]);
        let v530_2: Space = singleton(&(v529_12_head));
        let v530_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v530_2));
        let v530_4: Space = if map_kernels::has_head(&(v530_3)) { singleton(&[]) } else { Space::new() };
        drop(v530_3);
        let v530_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v530_4));
        drop(v530_4);
        let v530_8: Space = if (v530_5).is_empty() { Space::new() } else {
          let v531_6: Path = concat_path(&(v529_6),&(v529_12_head));
          let mut v531_7 = Space::new();
          let mut v531_7_cursor = (v529_12_tail).read_zipper();
          for v531_7_byte in v531_7_cursor.child_mask().iter() {
            v531_7_cursor.descend_to_byte(v531_7_byte);
            {
            let v531_7_tail = v531_7_cursor.fork_read_zipper();
            let v531_7_head = Path::from_slice(&[v531_7_byte]);
            let v532_2: Space = singleton(&(v531_7_head));
            let v532_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v532_2));
            let v532_4: Space = if map_kernels::has_head(&(v532_3)) { singleton(&[]) } else { Space::new() };
            drop(v532_3);
            let v532_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v532_4));
            drop(v532_4);
            let v532_8: Space = if (v532_5).is_empty() { Space::new() } else {
              let v533_6: Path = concat_path(&(v531_6),&(v531_7_head));
              let v533_7: Space = routine_49(c, &(v533_6), &(v531_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v532_5),&(v533_7))
            };
            drop(v532_5);
            let v532_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v532_2));
            drop(v532_2);
            let v532_10: Space = if map_kernels::has_head(&(v532_9)) { singleton(&[]) } else { Space::new() };
            drop(v532_9);
            let v532_12: Space = if (v532_10).is_empty() { Space::new() } else {
              let v534_6: Path = concat_path(&(v531_6),&(v531_7_head));
              let v534_11: Space = routine_50(c, &(v534_6), &(v531_7_tail).make_space(), &(*s1));
              drop(v534_6);
              map_map_kernels::compose(&(v532_10),&(v534_11))
            };
            drop(v532_10);
            let v532_13: Space = map_map_kernels::unite(&(v532_8),&(v532_12));
            v531_7.join_into((v532_13).clone());
            }
            v531_7_cursor.ascend(1);
          }
          drop(v531_7_cursor);
          drop(v531_6);
          map_map_kernels::compose(&(v530_5),&(v531_7))
        };
        drop(v530_5);
        let v530_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v530_2));
        drop(v530_2);
        let v530_10: Space = if map_kernels::has_head(&(v530_9)) { singleton(&[]) } else { Space::new() };
        drop(v530_9);
        let v530_13: Space = if (v530_10).is_empty() { Space::new() } else {
          let v535_11: Space = map_kernels::unwrap(&(v529_11),&(v529_12_head));
          let v535_12: Space = map_map_kernels::subtract(&(v535_11),&(*CONSTANT_5));
          drop(v535_11);
          map_map_kernels::compose(&(v530_10),&(v535_12))
        };
        drop(v530_10);
        let v530_14: Space = map_map_kernels::unite(&(v530_8),&(v530_13));
        drop(v530_13);
        v529_12.join_into((v530_14).clone());
        }
        v529_12_cursor.ascend(1);
      }
      drop(v529_12_cursor);
      drop(v529_6);
      drop(v529_11);
      map_map_kernels::compose(&(v518_10),&(v529_12))
    };
    drop(v518_10);
    let v518_14: Space = map_map_kernels::unite(&(v518_8),&(v518_13));
    v517_27.join_into((v518_14).clone());
    }
    v517_27_cursor.ascend(1);
  }
  drop(v517_27_cursor);
  drop(v517_23);
  (v517_27).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v536_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v536_9: Space = map_kernels::unwrap(&(v536_7),&(*CONSTANT_4));
  drop(v536_7);
  let v536_10: Space = map_kernels::unwrap(&(v536_9),&(*p0));
  drop(v536_9);
  let mut v536_21 = Space::new();
  let mut v536_21_cursor = (*s0).read_zipper();
  for v536_21_byte in v536_21_cursor.child_mask().iter() {
    v536_21_cursor.descend_to_byte(v536_21_byte);
    {
    let v536_21_tail = v536_21_cursor.fork_read_zipper();
    let v536_21_head = Path::from_slice(&[v536_21_byte]);
    let v537_2: Space = singleton(&(v536_21_head));
    let v537_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v537_2));
    let v537_4: Space = if map_kernels::has_head(&(v537_3)) { singleton(&[]) } else { Space::new() };
    drop(v537_3);
    let v537_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v537_4));
    drop(v537_4);
    let v537_8: Space = if (v537_5).is_empty() { Space::new() } else {
      let v538_6: Path = concat_path(&(*p0),&(v536_21_head));
      let mut v538_7 = Space::new();
      let mut v538_7_cursor = (v536_21_tail).read_zipper();
      for v538_7_byte in v538_7_cursor.child_mask().iter() {
        v538_7_cursor.descend_to_byte(v538_7_byte);
        {
        let v538_7_tail = v538_7_cursor.fork_read_zipper();
        let v538_7_head = Path::from_slice(&[v538_7_byte]);
        let v539_2: Space = singleton(&(v538_7_head));
        let v539_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v539_2));
        let v539_4: Space = if map_kernels::has_head(&(v539_3)) { singleton(&[]) } else { Space::new() };
        drop(v539_3);
        let v539_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v539_4));
        drop(v539_4);
        let v539_8: Space = if (v539_5).is_empty() { Space::new() } else {
          let v540_6: Path = concat_path(&(v538_6),&(v538_7_head));
          let mut v540_7 = Space::new();
          let mut v540_7_cursor = (v538_7_tail).read_zipper();
          for v540_7_byte in v540_7_cursor.child_mask().iter() {
            v540_7_cursor.descend_to_byte(v540_7_byte);
            {
            let v540_7_tail = v540_7_cursor.fork_read_zipper();
            let v540_7_head = Path::from_slice(&[v540_7_byte]);
            let v541_2: Space = singleton(&(v540_7_head));
            let v541_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v541_2));
            let v541_4: Space = if map_kernels::has_head(&(v541_3)) { singleton(&[]) } else { Space::new() };
            drop(v541_3);
            let v541_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v541_4));
            drop(v541_4);
            let v541_8: Space = if (v541_5).is_empty() { Space::new() } else {
              let v542_6: Path = concat_path(&(v540_6),&(v540_7_head));
              let v542_7: Space = routine_49(c, &(v542_6), &(v540_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v541_5),&(v542_7))
            };
            drop(v541_5);
            let v541_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v541_2));
            drop(v541_2);
            let v541_10: Space = if map_kernels::has_head(&(v541_9)) { singleton(&[]) } else { Space::new() };
            drop(v541_9);
            let v541_12: Space = if (v541_10).is_empty() { Space::new() } else {
              let v543_6: Path = concat_path(&(v540_6),&(v540_7_head));
              let v543_11: Space = routine_50(c, &(v543_6), &(v540_7_tail).make_space(), &(*s1));
              drop(v543_6);
              map_map_kernels::compose(&(v541_10),&(v543_11))
            };
            drop(v541_10);
            let v541_13: Space = map_map_kernels::unite(&(v541_8),&(v541_12));
            v540_7.join_into((v541_13).clone());
            }
            v540_7_cursor.ascend(1);
          }
          drop(v540_7_cursor);
          map_map_kernels::compose(&(v539_5),&(v540_7))
        };
        drop(v539_5);
        let v539_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v539_2));
        drop(v539_2);
        let v539_10: Space = if map_kernels::has_head(&(v539_9)) { singleton(&[]) } else { Space::new() };
        drop(v539_9);
        let v539_12: Space = if (v539_10).is_empty() { Space::new() } else {
          let v544_6: Path = concat_path(&(v538_6),&(v538_7_head));
          let mut v544_11 = Space::new();
          let mut v544_11_cursor = (v538_7_tail).read_zipper();
          for v544_11_byte in v544_11_cursor.child_mask().iter() {
            v544_11_cursor.descend_to_byte(v544_11_byte);
            {
            let v544_11_tail = v544_11_cursor.fork_read_zipper();
            let v544_11_head = Path::from_slice(&[v544_11_byte]);
            let v545_2: Space = singleton(&(v544_11_head));
            let v545_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v545_2));
            let v545_4: Space = if map_kernels::has_head(&(v545_3)) { singleton(&[]) } else { Space::new() };
            drop(v545_3);
            let v545_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v545_4));
            drop(v545_4);
            let v545_8: Space = if (v545_5).is_empty() { Space::new() } else {
              let v546_6: Path = concat_path(&(v544_6),&(v544_11_head));
              let v546_7: Space = routine_49(c, &(v546_6), &(v544_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v545_5),&(v546_7))
            };
            drop(v545_5);
            let v545_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v545_2));
            drop(v545_2);
            let v545_10: Space = if map_kernels::has_head(&(v545_9)) { singleton(&[]) } else { Space::new() };
            drop(v545_9);
            let v545_12: Space = if (v545_10).is_empty() { Space::new() } else {
              let v547_6: Path = concat_path(&(v544_6),&(v544_11_head));
              let v547_11: Space = routine_24(c, &(v547_6), &(v544_11_tail).make_space(), &(*s1));
              drop(v547_6);
              map_map_kernels::compose(&(v545_10),&(v547_11))
            };
            drop(v545_10);
            let v545_13: Space = map_map_kernels::unite(&(v545_8),&(v545_12));
            v544_11.join_into((v545_13).clone());
            }
            v544_11_cursor.ascend(1);
          }
          drop(v544_11_cursor);
          drop(v544_6);
          map_map_kernels::compose(&(v539_10),&(v544_11))
        };
        drop(v539_10);
        let v539_13: Space = map_map_kernels::unite(&(v539_8),&(v539_12));
        v538_7.join_into((v539_13).clone());
        }
        v538_7_cursor.ascend(1);
      }
      drop(v538_7_cursor);
      drop(v538_6);
      map_map_kernels::compose(&(v537_5),&(v538_7))
    };
    drop(v537_5);
    let v537_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v537_2));
    drop(v537_2);
    let v537_10: Space = if map_kernels::has_head(&(v537_9)) { singleton(&[]) } else { Space::new() };
    drop(v537_9);
    let v537_13: Space = if (v537_10).is_empty() { Space::new() } else {
      let v548_11: Space = map_kernels::unwrap(&(v536_10),&(v536_21_head));
      let v548_12: Space = map_map_kernels::subtract(&(v548_11),&(*CONSTANT_5));
      drop(v548_11);
      map_map_kernels::compose(&(v537_10),&(v548_12))
    };
    drop(v537_10);
    let v537_14: Space = map_map_kernels::unite(&(v537_8),&(v537_13));
    drop(v537_13);
    v536_21.join_into((v537_14).clone());
    }
    v536_21_cursor.ascend(1);
  }
  drop(v536_21_cursor);
  drop(v536_10);
  (v536_21).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v549_4: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v549_6: Space = map_kernels::unwrap(&(v549_4),&(*CONSTANT_4));
  drop(v549_4);
  let v549_7: Space = map_kernels::unwrap(&(v549_6),&(*p0));
  drop(v549_6);
  let v549_9: Space = map_map_kernels::subtract(&(v549_7),&(*CONSTANT_5));
  drop(v549_7);
  (v549_9).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v550_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v550_22: Space = map_kernels::unwrap(&(v550_21),&(*CONSTANT_4));
  drop(v550_21);
  let v550_23: Space = map_kernels::unwrap(&(v550_22),&(*p0));
  drop(v550_22);
  let mut v550_27 = Space::new();
  let mut v550_27_cursor = (*s0).read_zipper();
  for v550_27_byte in v550_27_cursor.child_mask().iter() {
    v550_27_cursor.descend_to_byte(v550_27_byte);
    {
    let v550_27_tail = v550_27_cursor.fork_read_zipper();
    let v550_27_head = Path::from_slice(&[v550_27_byte]);
    let v551_2: Space = singleton(&(v550_27_head));
    let v551_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v551_2));
    let v551_4: Space = if map_kernels::has_head(&(v551_3)) { singleton(&[]) } else { Space::new() };
    drop(v551_3);
    let v551_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v551_4));
    drop(v551_4);
    let v551_8: Space = if (v551_5).is_empty() { Space::new() } else {
      let v552_6: Path = concat_path(&(*p0),&(v550_27_head));
      let mut v552_7 = Space::new();
      let mut v552_7_cursor = (v550_27_tail).read_zipper();
      for v552_7_byte in v552_7_cursor.child_mask().iter() {
        v552_7_cursor.descend_to_byte(v552_7_byte);
        {
        let v552_7_tail = v552_7_cursor.fork_read_zipper();
        let v552_7_head = Path::from_slice(&[v552_7_byte]);
        let v553_2: Space = singleton(&(v552_7_head));
        let v553_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v553_2));
        let v553_4: Space = if map_kernels::has_head(&(v553_3)) { singleton(&[]) } else { Space::new() };
        drop(v553_3);
        let v553_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v553_4));
        drop(v553_4);
        let v553_8: Space = if (v553_5).is_empty() { Space::new() } else {
          let v554_6: Path = concat_path(&(v552_6),&(v552_7_head));
          let mut v554_7 = Space::new();
          let mut v554_7_cursor = (v552_7_tail).read_zipper();
          for v554_7_byte in v554_7_cursor.child_mask().iter() {
            v554_7_cursor.descend_to_byte(v554_7_byte);
            {
            let v554_7_tail = v554_7_cursor.fork_read_zipper();
            let v554_7_head = Path::from_slice(&[v554_7_byte]);
            let v555_2: Space = singleton(&(v554_7_head));
            let v555_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v555_2));
            let v555_4: Space = if map_kernels::has_head(&(v555_3)) { singleton(&[]) } else { Space::new() };
            drop(v555_3);
            let v555_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v555_4));
            drop(v555_4);
            let v555_8: Space = if (v555_5).is_empty() { Space::new() } else {
              let v556_6: Path = concat_path(&(v554_6),&(v554_7_head));
              let v556_7: Space = routine_51(c, &(v556_6), &(v554_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v555_5),&(v556_7))
            };
            drop(v555_5);
            let v555_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v555_2));
            drop(v555_2);
            let v555_10: Space = if map_kernels::has_head(&(v555_9)) { singleton(&[]) } else { Space::new() };
            drop(v555_9);
            let v555_12: Space = if (v555_10).is_empty() { Space::new() } else {
              let v557_6: Path = concat_path(&(v554_6),&(v554_7_head));
              let v557_11: Space = routine_52(c, &(v557_6), &(v554_7_tail).make_space(), &(*s1));
              drop(v557_6);
              map_map_kernels::compose(&(v555_10),&(v557_11))
            };
            drop(v555_10);
            let v555_13: Space = map_map_kernels::unite(&(v555_8),&(v555_12));
            v554_7.join_into((v555_13).clone());
            }
            v554_7_cursor.ascend(1);
          }
          drop(v554_7_cursor);
          map_map_kernels::compose(&(v553_5),&(v554_7))
        };
        drop(v553_5);
        let v553_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v553_2));
        drop(v553_2);
        let v553_10: Space = if map_kernels::has_head(&(v553_9)) { singleton(&[]) } else { Space::new() };
        drop(v553_9);
        let v553_12: Space = if (v553_10).is_empty() { Space::new() } else {
          let v558_6: Path = concat_path(&(v552_6),&(v552_7_head));
          let mut v558_11 = Space::new();
          let mut v558_11_cursor = (v552_7_tail).read_zipper();
          for v558_11_byte in v558_11_cursor.child_mask().iter() {
            v558_11_cursor.descend_to_byte(v558_11_byte);
            {
            let v558_11_tail = v558_11_cursor.fork_read_zipper();
            let v558_11_head = Path::from_slice(&[v558_11_byte]);
            let v559_2: Space = singleton(&(v558_11_head));
            let v559_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v559_2));
            let v559_4: Space = if map_kernels::has_head(&(v559_3)) { singleton(&[]) } else { Space::new() };
            drop(v559_3);
            let v559_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v559_4));
            drop(v559_4);
            let v559_8: Space = if (v559_5).is_empty() { Space::new() } else {
              let v560_6: Path = concat_path(&(v558_6),&(v558_11_head));
              let v560_7: Space = routine_51(c, &(v560_6), &(v558_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v559_5),&(v560_7))
            };
            drop(v559_5);
            let v559_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v559_2));
            drop(v559_2);
            let v559_10: Space = if map_kernels::has_head(&(v559_9)) { singleton(&[]) } else { Space::new() };
            drop(v559_9);
            let v559_12: Space = if (v559_10).is_empty() { Space::new() } else {
              let v561_6: Path = concat_path(&(v558_6),&(v558_11_head));
              let v561_11: Space = routine_24(c, &(v561_6), &(v558_11_tail).make_space(), &(*s1));
              drop(v561_6);
              map_map_kernels::compose(&(v559_10),&(v561_11))
            };
            drop(v559_10);
            let v559_13: Space = map_map_kernels::unite(&(v559_8),&(v559_12));
            v558_11.join_into((v559_13).clone());
            }
            v558_11_cursor.ascend(1);
          }
          drop(v558_11_cursor);
          drop(v558_6);
          map_map_kernels::compose(&(v553_10),&(v558_11))
        };
        drop(v553_10);
        let v553_13: Space = map_map_kernels::unite(&(v553_8),&(v553_12));
        v552_7.join_into((v553_13).clone());
        }
        v552_7_cursor.ascend(1);
      }
      drop(v552_7_cursor);
      map_map_kernels::compose(&(v551_5),&(v552_7))
    };
    drop(v551_5);
    let v551_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v551_2));
    drop(v551_2);
    let v551_10: Space = if map_kernels::has_head(&(v551_9)) { singleton(&[]) } else { Space::new() };
    drop(v551_9);
    let v551_13: Space = if (v551_10).is_empty() { Space::new() } else {
      let v562_6: Path = concat_path(&(*p0),&(v550_27_head));
      let v562_11: Space = map_kernels::unwrap(&(v550_23),&(v550_27_head));
      let mut v562_12 = Space::new();
      let mut v562_12_cursor = (v550_27_tail).read_zipper();
      for v562_12_byte in v562_12_cursor.child_mask().iter() {
        v562_12_cursor.descend_to_byte(v562_12_byte);
        {
        let v562_12_tail = v562_12_cursor.fork_read_zipper();
        let v562_12_head = Path::from_slice(&[v562_12_byte]);
        let v563_2: Space = singleton(&(v562_12_head));
        let v563_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v563_2));
        let v563_4: Space = if map_kernels::has_head(&(v563_3)) { singleton(&[]) } else { Space::new() };
        drop(v563_3);
        let v563_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v563_4));
        drop(v563_4);
        let v563_8: Space = if (v563_5).is_empty() { Space::new() } else {
          let v564_6: Path = concat_path(&(v562_6),&(v562_12_head));
          let mut v564_7 = Space::new();
          let mut v564_7_cursor = (v562_12_tail).read_zipper();
          for v564_7_byte in v564_7_cursor.child_mask().iter() {
            v564_7_cursor.descend_to_byte(v564_7_byte);
            {
            let v564_7_tail = v564_7_cursor.fork_read_zipper();
            let v564_7_head = Path::from_slice(&[v564_7_byte]);
            let v565_2: Space = singleton(&(v564_7_head));
            let v565_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v565_2));
            let v565_4: Space = if map_kernels::has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
            drop(v565_3);
            let v565_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v565_4));
            drop(v565_4);
            let v565_8: Space = if (v565_5).is_empty() { Space::new() } else {
              let v566_6: Path = concat_path(&(v564_6),&(v564_7_head));
              let v566_7: Space = routine_51(c, &(v566_6), &(v564_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v565_5),&(v566_7))
            };
            drop(v565_5);
            let v565_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v565_2));
            drop(v565_2);
            let v565_10: Space = if map_kernels::has_head(&(v565_9)) { singleton(&[]) } else { Space::new() };
            drop(v565_9);
            let v565_12: Space = if (v565_10).is_empty() { Space::new() } else {
              let v567_6: Path = concat_path(&(v564_6),&(v564_7_head));
              let v567_11: Space = routine_52(c, &(v567_6), &(v564_7_tail).make_space(), &(*s1));
              drop(v567_6);
              map_map_kernels::compose(&(v565_10),&(v567_11))
            };
            drop(v565_10);
            let v565_13: Space = map_map_kernels::unite(&(v565_8),&(v565_12));
            v564_7.join_into((v565_13).clone());
            }
            v564_7_cursor.ascend(1);
          }
          drop(v564_7_cursor);
          drop(v564_6);
          map_map_kernels::compose(&(v563_5),&(v564_7))
        };
        drop(v563_5);
        let v563_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v563_2));
        drop(v563_2);
        let v563_10: Space = if map_kernels::has_head(&(v563_9)) { singleton(&[]) } else { Space::new() };
        drop(v563_9);
        let v563_13: Space = if (v563_10).is_empty() { Space::new() } else {
          let v568_11: Space = map_kernels::unwrap(&(v562_11),&(v562_12_head));
          let v568_12: Space = map_map_kernels::subtract(&(v568_11),&(*CONSTANT_5));
          drop(v568_11);
          map_map_kernels::compose(&(v563_10),&(v568_12))
        };
        drop(v563_10);
        let v563_14: Space = map_map_kernels::unite(&(v563_8),&(v563_13));
        drop(v563_13);
        v562_12.join_into((v563_14).clone());
        }
        v562_12_cursor.ascend(1);
      }
      drop(v562_12_cursor);
      drop(v562_6);
      drop(v562_11);
      map_map_kernels::compose(&(v551_10),&(v562_12))
    };
    drop(v551_10);
    let v551_14: Space = map_map_kernels::unite(&(v551_8),&(v551_13));
    v550_27.join_into((v551_14).clone());
    }
    v550_27_cursor.ascend(1);
  }
  drop(v550_27_cursor);
  drop(v550_23);
  (v550_27).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v569_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v569_9: Space = map_kernels::unwrap(&(v569_7),&(*CONSTANT_4));
  drop(v569_7);
  let v569_10: Space = map_kernels::unwrap(&(v569_9),&(*p0));
  drop(v569_9);
  let mut v569_21 = Space::new();
  let mut v569_21_cursor = (*s0).read_zipper();
  for v569_21_byte in v569_21_cursor.child_mask().iter() {
    v569_21_cursor.descend_to_byte(v569_21_byte);
    {
    let v569_21_tail = v569_21_cursor.fork_read_zipper();
    let v569_21_head = Path::from_slice(&[v569_21_byte]);
    let v570_2: Space = singleton(&(v569_21_head));
    let v570_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v570_2));
    let v570_4: Space = if map_kernels::has_head(&(v570_3)) { singleton(&[]) } else { Space::new() };
    drop(v570_3);
    let v570_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v570_4));
    drop(v570_4);
    let v570_8: Space = if (v570_5).is_empty() { Space::new() } else {
      let v571_6: Path = concat_path(&(*p0),&(v569_21_head));
      let mut v571_7 = Space::new();
      let mut v571_7_cursor = (v569_21_tail).read_zipper();
      for v571_7_byte in v571_7_cursor.child_mask().iter() {
        v571_7_cursor.descend_to_byte(v571_7_byte);
        {
        let v571_7_tail = v571_7_cursor.fork_read_zipper();
        let v571_7_head = Path::from_slice(&[v571_7_byte]);
        let v572_2: Space = singleton(&(v571_7_head));
        let v572_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v572_2));
        let v572_4: Space = if map_kernels::has_head(&(v572_3)) { singleton(&[]) } else { Space::new() };
        drop(v572_3);
        let v572_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v572_4));
        drop(v572_4);
        let v572_8: Space = if (v572_5).is_empty() { Space::new() } else {
          let v573_6: Path = concat_path(&(v571_6),&(v571_7_head));
          let mut v573_7 = Space::new();
          let mut v573_7_cursor = (v571_7_tail).read_zipper();
          for v573_7_byte in v573_7_cursor.child_mask().iter() {
            v573_7_cursor.descend_to_byte(v573_7_byte);
            {
            let v573_7_tail = v573_7_cursor.fork_read_zipper();
            let v573_7_head = Path::from_slice(&[v573_7_byte]);
            let v574_2: Space = singleton(&(v573_7_head));
            let v574_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v574_2));
            let v574_4: Space = if map_kernels::has_head(&(v574_3)) { singleton(&[]) } else { Space::new() };
            drop(v574_3);
            let v574_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v574_4));
            drop(v574_4);
            let v574_8: Space = if (v574_5).is_empty() { Space::new() } else {
              let v575_6: Path = concat_path(&(v573_6),&(v573_7_head));
              let v575_7: Space = routine_51(c, &(v575_6), &(v573_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v574_5),&(v575_7))
            };
            drop(v574_5);
            let v574_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v574_2));
            drop(v574_2);
            let v574_10: Space = if map_kernels::has_head(&(v574_9)) { singleton(&[]) } else { Space::new() };
            drop(v574_9);
            let v574_12: Space = if (v574_10).is_empty() { Space::new() } else {
              let v576_6: Path = concat_path(&(v573_6),&(v573_7_head));
              let v576_11: Space = routine_52(c, &(v576_6), &(v573_7_tail).make_space(), &(*s1));
              drop(v576_6);
              map_map_kernels::compose(&(v574_10),&(v576_11))
            };
            drop(v574_10);
            let v574_13: Space = map_map_kernels::unite(&(v574_8),&(v574_12));
            v573_7.join_into((v574_13).clone());
            }
            v573_7_cursor.ascend(1);
          }
          drop(v573_7_cursor);
          map_map_kernels::compose(&(v572_5),&(v573_7))
        };
        drop(v572_5);
        let v572_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v572_2));
        drop(v572_2);
        let v572_10: Space = if map_kernels::has_head(&(v572_9)) { singleton(&[]) } else { Space::new() };
        drop(v572_9);
        let v572_12: Space = if (v572_10).is_empty() { Space::new() } else {
          let v577_6: Path = concat_path(&(v571_6),&(v571_7_head));
          let mut v577_11 = Space::new();
          let mut v577_11_cursor = (v571_7_tail).read_zipper();
          for v577_11_byte in v577_11_cursor.child_mask().iter() {
            v577_11_cursor.descend_to_byte(v577_11_byte);
            {
            let v577_11_tail = v577_11_cursor.fork_read_zipper();
            let v577_11_head = Path::from_slice(&[v577_11_byte]);
            let v578_2: Space = singleton(&(v577_11_head));
            let v578_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v578_2));
            let v578_4: Space = if map_kernels::has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
            drop(v578_3);
            let v578_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v578_4));
            drop(v578_4);
            let v578_8: Space = if (v578_5).is_empty() { Space::new() } else {
              let v579_6: Path = concat_path(&(v577_6),&(v577_11_head));
              let v579_7: Space = routine_51(c, &(v579_6), &(v577_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v578_5),&(v579_7))
            };
            drop(v578_5);
            let v578_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v578_2));
            drop(v578_2);
            let v578_10: Space = if map_kernels::has_head(&(v578_9)) { singleton(&[]) } else { Space::new() };
            drop(v578_9);
            let v578_12: Space = if (v578_10).is_empty() { Space::new() } else {
              let v580_6: Path = concat_path(&(v577_6),&(v577_11_head));
              let v580_11: Space = routine_24(c, &(v580_6), &(v577_11_tail).make_space(), &(*s1));
              drop(v580_6);
              map_map_kernels::compose(&(v578_10),&(v580_11))
            };
            drop(v578_10);
            let v578_13: Space = map_map_kernels::unite(&(v578_8),&(v578_12));
            v577_11.join_into((v578_13).clone());
            }
            v577_11_cursor.ascend(1);
          }
          drop(v577_11_cursor);
          drop(v577_6);
          map_map_kernels::compose(&(v572_10),&(v577_11))
        };
        drop(v572_10);
        let v572_13: Space = map_map_kernels::unite(&(v572_8),&(v572_12));
        v571_7.join_into((v572_13).clone());
        }
        v571_7_cursor.ascend(1);
      }
      drop(v571_7_cursor);
      drop(v571_6);
      map_map_kernels::compose(&(v570_5),&(v571_7))
    };
    drop(v570_5);
    let v570_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v570_2));
    drop(v570_2);
    let v570_10: Space = if map_kernels::has_head(&(v570_9)) { singleton(&[]) } else { Space::new() };
    drop(v570_9);
    let v570_13: Space = if (v570_10).is_empty() { Space::new() } else {
      let v581_11: Space = map_kernels::unwrap(&(v569_10),&(v569_21_head));
      let v581_12: Space = map_map_kernels::subtract(&(v581_11),&(*CONSTANT_5));
      drop(v581_11);
      map_map_kernels::compose(&(v570_10),&(v581_12))
    };
    drop(v570_10);
    let v570_14: Space = map_map_kernels::unite(&(v570_8),&(v570_13));
    drop(v570_13);
    v569_21.join_into((v570_14).clone());
    }
    v569_21_cursor.ascend(1);
  }
  drop(v569_21_cursor);
  drop(v569_10);
  (v569_21).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v582_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v582_22: Space = map_kernels::unwrap(&(v582_21),&(*CONSTANT_4));
  drop(v582_21);
  let v582_23: Space = map_kernels::unwrap(&(v582_22),&(*p0));
  drop(v582_22);
  let mut v582_27 = Space::new();
  let mut v582_27_cursor = (*s0).read_zipper();
  for v582_27_byte in v582_27_cursor.child_mask().iter() {
    v582_27_cursor.descend_to_byte(v582_27_byte);
    {
    let v582_27_tail = v582_27_cursor.fork_read_zipper();
    let v582_27_head = Path::from_slice(&[v582_27_byte]);
    let v583_2: Space = singleton(&(v582_27_head));
    let v583_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v583_2));
    let v583_4: Space = if map_kernels::has_head(&(v583_3)) { singleton(&[]) } else { Space::new() };
    drop(v583_3);
    let v583_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v583_4));
    drop(v583_4);
    let v583_8: Space = if (v583_5).is_empty() { Space::new() } else {
      let v584_6: Path = concat_path(&(*p0),&(v582_27_head));
      let mut v584_7 = Space::new();
      let mut v584_7_cursor = (v582_27_tail).read_zipper();
      for v584_7_byte in v584_7_cursor.child_mask().iter() {
        v584_7_cursor.descend_to_byte(v584_7_byte);
        {
        let v584_7_tail = v584_7_cursor.fork_read_zipper();
        let v584_7_head = Path::from_slice(&[v584_7_byte]);
        let v585_2: Space = singleton(&(v584_7_head));
        let v585_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v585_2));
        let v585_4: Space = if map_kernels::has_head(&(v585_3)) { singleton(&[]) } else { Space::new() };
        drop(v585_3);
        let v585_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v585_4));
        drop(v585_4);
        let v585_8: Space = if (v585_5).is_empty() { Space::new() } else {
          let v586_6: Path = concat_path(&(v584_6),&(v584_7_head));
          let mut v586_7 = Space::new();
          let mut v586_7_cursor = (v584_7_tail).read_zipper();
          for v586_7_byte in v586_7_cursor.child_mask().iter() {
            v586_7_cursor.descend_to_byte(v586_7_byte);
            {
            let v586_7_tail = v586_7_cursor.fork_read_zipper();
            let v586_7_head = Path::from_slice(&[v586_7_byte]);
            let v587_2: Space = singleton(&(v586_7_head));
            let v587_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v587_2));
            let v587_4: Space = if map_kernels::has_head(&(v587_3)) { singleton(&[]) } else { Space::new() };
            drop(v587_3);
            let v587_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v587_4));
            drop(v587_4);
            let v587_8: Space = if (v587_5).is_empty() { Space::new() } else {
              let v588_6: Path = concat_path(&(v586_6),&(v586_7_head));
              let v588_7: Space = routine_53(c, &(v588_6), &(v586_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v587_5),&(v588_7))
            };
            drop(v587_5);
            let v587_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v587_2));
            drop(v587_2);
            let v587_10: Space = if map_kernels::has_head(&(v587_9)) { singleton(&[]) } else { Space::new() };
            drop(v587_9);
            let v587_12: Space = if (v587_10).is_empty() { Space::new() } else {
              let v589_6: Path = concat_path(&(v586_6),&(v586_7_head));
              let v589_11: Space = routine_54(c, &(v589_6), &(v586_7_tail).make_space(), &(*s1));
              drop(v589_6);
              map_map_kernels::compose(&(v587_10),&(v589_11))
            };
            drop(v587_10);
            let v587_13: Space = map_map_kernels::unite(&(v587_8),&(v587_12));
            v586_7.join_into((v587_13).clone());
            }
            v586_7_cursor.ascend(1);
          }
          drop(v586_7_cursor);
          map_map_kernels::compose(&(v585_5),&(v586_7))
        };
        drop(v585_5);
        let v585_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v585_2));
        drop(v585_2);
        let v585_10: Space = if map_kernels::has_head(&(v585_9)) { singleton(&[]) } else { Space::new() };
        drop(v585_9);
        let v585_12: Space = if (v585_10).is_empty() { Space::new() } else {
          let v590_6: Path = concat_path(&(v584_6),&(v584_7_head));
          let mut v590_11 = Space::new();
          let mut v590_11_cursor = (v584_7_tail).read_zipper();
          for v590_11_byte in v590_11_cursor.child_mask().iter() {
            v590_11_cursor.descend_to_byte(v590_11_byte);
            {
            let v590_11_tail = v590_11_cursor.fork_read_zipper();
            let v590_11_head = Path::from_slice(&[v590_11_byte]);
            let v591_2: Space = singleton(&(v590_11_head));
            let v591_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v591_2));
            let v591_4: Space = if map_kernels::has_head(&(v591_3)) { singleton(&[]) } else { Space::new() };
            drop(v591_3);
            let v591_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v591_4));
            drop(v591_4);
            let v591_8: Space = if (v591_5).is_empty() { Space::new() } else {
              let v592_6: Path = concat_path(&(v590_6),&(v590_11_head));
              let v592_7: Space = routine_53(c, &(v592_6), &(v590_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v591_5),&(v592_7))
            };
            drop(v591_5);
            let v591_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v591_2));
            drop(v591_2);
            let v591_10: Space = if map_kernels::has_head(&(v591_9)) { singleton(&[]) } else { Space::new() };
            drop(v591_9);
            let v591_12: Space = if (v591_10).is_empty() { Space::new() } else {
              let v593_6: Path = concat_path(&(v590_6),&(v590_11_head));
              let v593_11: Space = routine_24(c, &(v593_6), &(v590_11_tail).make_space(), &(*s1));
              drop(v593_6);
              map_map_kernels::compose(&(v591_10),&(v593_11))
            };
            drop(v591_10);
            let v591_13: Space = map_map_kernels::unite(&(v591_8),&(v591_12));
            v590_11.join_into((v591_13).clone());
            }
            v590_11_cursor.ascend(1);
          }
          drop(v590_11_cursor);
          drop(v590_6);
          map_map_kernels::compose(&(v585_10),&(v590_11))
        };
        drop(v585_10);
        let v585_13: Space = map_map_kernels::unite(&(v585_8),&(v585_12));
        v584_7.join_into((v585_13).clone());
        }
        v584_7_cursor.ascend(1);
      }
      drop(v584_7_cursor);
      map_map_kernels::compose(&(v583_5),&(v584_7))
    };
    drop(v583_5);
    let v583_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v583_2));
    drop(v583_2);
    let v583_10: Space = if map_kernels::has_head(&(v583_9)) { singleton(&[]) } else { Space::new() };
    drop(v583_9);
    let v583_13: Space = if (v583_10).is_empty() { Space::new() } else {
      let v594_6: Path = concat_path(&(*p0),&(v582_27_head));
      let v594_11: Space = map_kernels::unwrap(&(v582_23),&(v582_27_head));
      let mut v594_12 = Space::new();
      let mut v594_12_cursor = (v582_27_tail).read_zipper();
      for v594_12_byte in v594_12_cursor.child_mask().iter() {
        v594_12_cursor.descend_to_byte(v594_12_byte);
        {
        let v594_12_tail = v594_12_cursor.fork_read_zipper();
        let v594_12_head = Path::from_slice(&[v594_12_byte]);
        let v595_2: Space = singleton(&(v594_12_head));
        let v595_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v595_2));
        let v595_4: Space = if map_kernels::has_head(&(v595_3)) { singleton(&[]) } else { Space::new() };
        drop(v595_3);
        let v595_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v595_4));
        drop(v595_4);
        let v595_8: Space = if (v595_5).is_empty() { Space::new() } else {
          let v596_6: Path = concat_path(&(v594_6),&(v594_12_head));
          let mut v596_7 = Space::new();
          let mut v596_7_cursor = (v594_12_tail).read_zipper();
          for v596_7_byte in v596_7_cursor.child_mask().iter() {
            v596_7_cursor.descend_to_byte(v596_7_byte);
            {
            let v596_7_tail = v596_7_cursor.fork_read_zipper();
            let v596_7_head = Path::from_slice(&[v596_7_byte]);
            let v597_2: Space = singleton(&(v596_7_head));
            let v597_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v597_2));
            let v597_4: Space = if map_kernels::has_head(&(v597_3)) { singleton(&[]) } else { Space::new() };
            drop(v597_3);
            let v597_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v597_4));
            drop(v597_4);
            let v597_8: Space = if (v597_5).is_empty() { Space::new() } else {
              let v598_6: Path = concat_path(&(v596_6),&(v596_7_head));
              let v598_7: Space = routine_53(c, &(v598_6), &(v596_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v597_5),&(v598_7))
            };
            drop(v597_5);
            let v597_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v597_2));
            drop(v597_2);
            let v597_10: Space = if map_kernels::has_head(&(v597_9)) { singleton(&[]) } else { Space::new() };
            drop(v597_9);
            let v597_12: Space = if (v597_10).is_empty() { Space::new() } else {
              let v599_6: Path = concat_path(&(v596_6),&(v596_7_head));
              let v599_11: Space = routine_54(c, &(v599_6), &(v596_7_tail).make_space(), &(*s1));
              drop(v599_6);
              map_map_kernels::compose(&(v597_10),&(v599_11))
            };
            drop(v597_10);
            let v597_13: Space = map_map_kernels::unite(&(v597_8),&(v597_12));
            v596_7.join_into((v597_13).clone());
            }
            v596_7_cursor.ascend(1);
          }
          drop(v596_7_cursor);
          drop(v596_6);
          map_map_kernels::compose(&(v595_5),&(v596_7))
        };
        drop(v595_5);
        let v595_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v595_2));
        drop(v595_2);
        let v595_10: Space = if map_kernels::has_head(&(v595_9)) { singleton(&[]) } else { Space::new() };
        drop(v595_9);
        let v595_13: Space = if (v595_10).is_empty() { Space::new() } else {
          let v600_11: Space = map_kernels::unwrap(&(v594_11),&(v594_12_head));
          let v600_12: Space = map_map_kernels::subtract(&(v600_11),&(*CONSTANT_5));
          drop(v600_11);
          map_map_kernels::compose(&(v595_10),&(v600_12))
        };
        drop(v595_10);
        let v595_14: Space = map_map_kernels::unite(&(v595_8),&(v595_13));
        drop(v595_13);
        v594_12.join_into((v595_14).clone());
        }
        v594_12_cursor.ascend(1);
      }
      drop(v594_12_cursor);
      drop(v594_6);
      drop(v594_11);
      map_map_kernels::compose(&(v583_10),&(v594_12))
    };
    drop(v583_10);
    let v583_14: Space = map_map_kernels::unite(&(v583_8),&(v583_13));
    v582_27.join_into((v583_14).clone());
    }
    v582_27_cursor.ascend(1);
  }
  drop(v582_27_cursor);
  drop(v582_23);
  (v582_27).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v601_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v601_9: Space = map_kernels::unwrap(&(v601_7),&(*CONSTANT_4));
  drop(v601_7);
  let v601_10: Space = map_kernels::unwrap(&(v601_9),&(*p0));
  drop(v601_9);
  let mut v601_21 = Space::new();
  let mut v601_21_cursor = (*s0).read_zipper();
  for v601_21_byte in v601_21_cursor.child_mask().iter() {
    v601_21_cursor.descend_to_byte(v601_21_byte);
    {
    let v601_21_tail = v601_21_cursor.fork_read_zipper();
    let v601_21_head = Path::from_slice(&[v601_21_byte]);
    let v602_2: Space = singleton(&(v601_21_head));
    let v602_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v602_2));
    let v602_4: Space = if map_kernels::has_head(&(v602_3)) { singleton(&[]) } else { Space::new() };
    drop(v602_3);
    let v602_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v602_4));
    drop(v602_4);
    let v602_8: Space = if (v602_5).is_empty() { Space::new() } else {
      let v603_6: Path = concat_path(&(*p0),&(v601_21_head));
      let mut v603_7 = Space::new();
      let mut v603_7_cursor = (v601_21_tail).read_zipper();
      for v603_7_byte in v603_7_cursor.child_mask().iter() {
        v603_7_cursor.descend_to_byte(v603_7_byte);
        {
        let v603_7_tail = v603_7_cursor.fork_read_zipper();
        let v603_7_head = Path::from_slice(&[v603_7_byte]);
        let v604_2: Space = singleton(&(v603_7_head));
        let v604_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v604_2));
        let v604_4: Space = if map_kernels::has_head(&(v604_3)) { singleton(&[]) } else { Space::new() };
        drop(v604_3);
        let v604_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v604_4));
        drop(v604_4);
        let v604_8: Space = if (v604_5).is_empty() { Space::new() } else {
          let v605_6: Path = concat_path(&(v603_6),&(v603_7_head));
          let mut v605_7 = Space::new();
          let mut v605_7_cursor = (v603_7_tail).read_zipper();
          for v605_7_byte in v605_7_cursor.child_mask().iter() {
            v605_7_cursor.descend_to_byte(v605_7_byte);
            {
            let v605_7_tail = v605_7_cursor.fork_read_zipper();
            let v605_7_head = Path::from_slice(&[v605_7_byte]);
            let v606_2: Space = singleton(&(v605_7_head));
            let v606_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v606_2));
            let v606_4: Space = if map_kernels::has_head(&(v606_3)) { singleton(&[]) } else { Space::new() };
            drop(v606_3);
            let v606_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v606_4));
            drop(v606_4);
            let v606_8: Space = if (v606_5).is_empty() { Space::new() } else {
              let v607_6: Path = concat_path(&(v605_6),&(v605_7_head));
              let v607_7: Space = routine_53(c, &(v607_6), &(v605_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v606_5),&(v607_7))
            };
            drop(v606_5);
            let v606_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v606_2));
            drop(v606_2);
            let v606_10: Space = if map_kernels::has_head(&(v606_9)) { singleton(&[]) } else { Space::new() };
            drop(v606_9);
            let v606_12: Space = if (v606_10).is_empty() { Space::new() } else {
              let v608_6: Path = concat_path(&(v605_6),&(v605_7_head));
              let v608_11: Space = routine_54(c, &(v608_6), &(v605_7_tail).make_space(), &(*s1));
              drop(v608_6);
              map_map_kernels::compose(&(v606_10),&(v608_11))
            };
            drop(v606_10);
            let v606_13: Space = map_map_kernels::unite(&(v606_8),&(v606_12));
            v605_7.join_into((v606_13).clone());
            }
            v605_7_cursor.ascend(1);
          }
          drop(v605_7_cursor);
          map_map_kernels::compose(&(v604_5),&(v605_7))
        };
        drop(v604_5);
        let v604_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v604_2));
        drop(v604_2);
        let v604_10: Space = if map_kernels::has_head(&(v604_9)) { singleton(&[]) } else { Space::new() };
        drop(v604_9);
        let v604_12: Space = if (v604_10).is_empty() { Space::new() } else {
          let v609_6: Path = concat_path(&(v603_6),&(v603_7_head));
          let mut v609_11 = Space::new();
          let mut v609_11_cursor = (v603_7_tail).read_zipper();
          for v609_11_byte in v609_11_cursor.child_mask().iter() {
            v609_11_cursor.descend_to_byte(v609_11_byte);
            {
            let v609_11_tail = v609_11_cursor.fork_read_zipper();
            let v609_11_head = Path::from_slice(&[v609_11_byte]);
            let v610_2: Space = singleton(&(v609_11_head));
            let v610_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v610_2));
            let v610_4: Space = if map_kernels::has_head(&(v610_3)) { singleton(&[]) } else { Space::new() };
            drop(v610_3);
            let v610_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v610_4));
            drop(v610_4);
            let v610_8: Space = if (v610_5).is_empty() { Space::new() } else {
              let v611_6: Path = concat_path(&(v609_6),&(v609_11_head));
              let v611_7: Space = routine_53(c, &(v611_6), &(v609_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v610_5),&(v611_7))
            };
            drop(v610_5);
            let v610_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v610_2));
            drop(v610_2);
            let v610_10: Space = if map_kernels::has_head(&(v610_9)) { singleton(&[]) } else { Space::new() };
            drop(v610_9);
            let v610_12: Space = if (v610_10).is_empty() { Space::new() } else {
              let v612_6: Path = concat_path(&(v609_6),&(v609_11_head));
              let v612_11: Space = routine_24(c, &(v612_6), &(v609_11_tail).make_space(), &(*s1));
              drop(v612_6);
              map_map_kernels::compose(&(v610_10),&(v612_11))
            };
            drop(v610_10);
            let v610_13: Space = map_map_kernels::unite(&(v610_8),&(v610_12));
            v609_11.join_into((v610_13).clone());
            }
            v609_11_cursor.ascend(1);
          }
          drop(v609_11_cursor);
          drop(v609_6);
          map_map_kernels::compose(&(v604_10),&(v609_11))
        };
        drop(v604_10);
        let v604_13: Space = map_map_kernels::unite(&(v604_8),&(v604_12));
        v603_7.join_into((v604_13).clone());
        }
        v603_7_cursor.ascend(1);
      }
      drop(v603_7_cursor);
      drop(v603_6);
      map_map_kernels::compose(&(v602_5),&(v603_7))
    };
    drop(v602_5);
    let v602_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v602_2));
    drop(v602_2);
    let v602_10: Space = if map_kernels::has_head(&(v602_9)) { singleton(&[]) } else { Space::new() };
    drop(v602_9);
    let v602_13: Space = if (v602_10).is_empty() { Space::new() } else {
      let v613_11: Space = map_kernels::unwrap(&(v601_10),&(v601_21_head));
      let v613_12: Space = map_map_kernels::subtract(&(v613_11),&(*CONSTANT_5));
      drop(v613_11);
      map_map_kernels::compose(&(v602_10),&(v613_12))
    };
    drop(v602_10);
    let v602_14: Space = map_map_kernels::unite(&(v602_8),&(v602_13));
    drop(v602_13);
    v601_21.join_into((v602_14).clone());
    }
    v601_21_cursor.ascend(1);
  }
  drop(v601_21_cursor);
  drop(v601_10);
  (v601_21).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v614_10 = Space::new();
  let mut v614_10_cursor = (*s0).read_zipper();
  for v614_10_byte in v614_10_cursor.child_mask().iter() {
    v614_10_cursor.descend_to_byte(v614_10_byte);
    {
    let v614_10_tail = v614_10_cursor.fork_read_zipper();
    let v614_10_head = Path::from_slice(&[v614_10_byte]);
    let v615_2: Space = singleton(&(v614_10_head));
    let v615_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v615_2));
    let v615_4: Space = if map_kernels::has_head(&(v615_3)) { singleton(&[]) } else { Space::new() };
    drop(v615_3);
    let v615_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v615_4));
    drop(v615_4);
    let mut v615_6 = Space::new();
    let mut v615_6_cursor = (v614_10_tail).read_zipper();
    for v615_6_byte in v615_6_cursor.child_mask().iter() {
      v615_6_cursor.descend_to_byte(v615_6_byte);
      {
      let v615_6_tail = v615_6_cursor.fork_read_zipper();
      let v615_6_head = Path::from_slice(&[v615_6_byte]);
      let v616_2: Space = Space::new();
      v615_6.join_into((v616_2).clone());
      }
      v615_6_cursor.ascend(1);
    }
    drop(v615_6_cursor);
    let v615_7: Space = map_map_kernels::compose(&(v615_5),&(v615_6));
    drop(v615_5);
    drop(v615_6);
    let v615_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v615_2));
    drop(v615_2);
    let v615_9: Space = if map_kernels::has_head(&(v615_8)) { singleton(&[]) } else { Space::new() };
    drop(v615_8);
    let v615_12: Space = if (v615_9).is_empty() { Space::new() } else {
      let v617_10: Path = concat_path(&(*p0),&(v614_10_head));
      let mut v617_11 = Space::new();
      let mut v617_11_cursor = (v614_10_tail).read_zipper();
      for v617_11_byte in v617_11_cursor.child_mask().iter() {
        v617_11_cursor.descend_to_byte(v617_11_byte);
        {
        let v617_11_tail = v617_11_cursor.fork_read_zipper();
        let v617_11_head = Path::from_slice(&[v617_11_byte]);
        let v618_2: Space = singleton(&(v617_11_head));
        let v618_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v618_2));
        drop(v618_2);
        let v618_4: Space = if map_kernels::has_head(&(v618_3)) { singleton(&[]) } else { Space::new() };
        drop(v618_3);
        let v618_6: Space = if (v618_4).is_empty() { Space::new() } else {
          let mut v619_5 = Space::new();
          let mut v619_5_cursor = (v617_11_tail).read_zipper();
          for v619_5_byte in v619_5_cursor.child_mask().iter() {
            v619_5_cursor.descend_to_byte(v619_5_byte);
            {
            let v619_5_tail = v619_5_cursor.fork_read_zipper();
            let v619_5_head = Path::from_slice(&[v619_5_byte]);
            let v620_2: Space = singleton(&(v619_5_head));
            let v620_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v620_2));
            let v620_4: Space = if map_kernels::has_head(&(v620_3)) { singleton(&[]) } else { Space::new() };
            drop(v620_3);
            let v620_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v620_4));
            drop(v620_4);
            let v620_7: Space = if (v620_5).is_empty() { Space::new() } else {
              let v621_6: Space = routine_10(c, &(v619_5_head), &(v619_5_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v620_5),&(v621_6))
            };
            drop(v620_5);
            let v620_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v620_2));
            drop(v620_2);
            let v620_9: Space = if map_kernels::has_head(&(v620_8)) { singleton(&[]) } else { Space::new() };
            drop(v620_8);
            let v620_11: Space = if (v620_9).is_empty() { Space::new() } else {
              let v622_10: Space = routine_11(c, &(v619_5_head), &(v619_5_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v620_9),&(v622_10))
            };
            drop(v620_9);
            let v620_12: Space = map_map_kernels::unite(&(v620_7),&(v620_11));
            v619_5.join_into((v620_12).clone());
            }
            v619_5_cursor.ascend(1);
          }
          drop(v619_5_cursor);
          map_map_kernels::compose(&(v618_4),&(v619_5))
        };
        drop(v618_4);
        let v618_7: Path = concat_path(&(v617_10),&(v617_11_head));
        let v618_8: Space = map_kernels::wrap(&(v618_6),&(v618_7));
        drop(v618_7);
        v617_11.join_into((v618_8).clone());
        }
        v617_11_cursor.ascend(1);
      }
      drop(v617_11_cursor);
      drop(v617_10);
      map_map_kernels::compose(&(v615_9),&(v617_11))
    };
    drop(v615_9);
    let v615_13: Space = map_map_kernels::unite(&(v615_7),&(v615_12));
    drop(v615_7);
    v614_10.join_into((v615_13).clone());
    }
    v614_10_cursor.ascend(1);
  }
  drop(v614_10_cursor);
  (v614_10).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v623_15 = Space::new();
  let mut v623_15_cursor = (*s0).read_zipper();
  for v623_15_byte in v623_15_cursor.child_mask().iter() {
    v623_15_cursor.descend_to_byte(v623_15_byte);
    {
    let v623_15_tail = v623_15_cursor.fork_read_zipper();
    let v623_15_head = Path::from_slice(&[v623_15_byte]);
    let v624_2: Space = singleton(&(v623_15_head));
    let v624_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v624_2));
    let v624_4: Space = if map_kernels::has_head(&(v624_3)) { singleton(&[]) } else { Space::new() };
    drop(v624_3);
    let v624_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v624_4));
    drop(v624_4);
    let mut v624_6 = Space::new();
    let mut v624_6_cursor = (v623_15_tail).read_zipper();
    for v624_6_byte in v624_6_cursor.child_mask().iter() {
      v624_6_cursor.descend_to_byte(v624_6_byte);
      {
      let v624_6_tail = v624_6_cursor.fork_read_zipper();
      let v624_6_head = Path::from_slice(&[v624_6_byte]);
      let v625_2: Space = Space::new();
      v624_6.join_into((v625_2).clone());
      }
      v624_6_cursor.ascend(1);
    }
    drop(v624_6_cursor);
    let v624_7: Space = map_map_kernels::compose(&(v624_5),&(v624_6));
    drop(v624_5);
    drop(v624_6);
    let v624_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v624_2));
    drop(v624_2);
    let v624_9: Space = if map_kernels::has_head(&(v624_8)) { singleton(&[]) } else { Space::new() };
    drop(v624_8);
    let v624_11: Space = if (v624_9).is_empty() { Space::new() } else {
      let mut v626_10 = Space::new();
      let mut v626_10_cursor = (v623_15_tail).read_zipper();
      for v626_10_byte in v626_10_cursor.child_mask().iter() {
        v626_10_cursor.descend_to_byte(v626_10_byte);
        {
        let v626_10_tail = v626_10_cursor.fork_read_zipper();
        let v626_10_head = Path::from_slice(&[v626_10_byte]);
        let v627_2: Space = singleton(&(v626_10_head));
        let v627_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v627_2));
        let v627_4: Space = if map_kernels::has_head(&(v627_3)) { singleton(&[]) } else { Space::new() };
        drop(v627_3);
        let v627_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v627_4));
        drop(v627_4);
        let v627_7: Space = if (v627_5).is_empty() { Space::new() } else {
          let mut v628_6 = Space::new();
          let mut v628_6_cursor = (v626_10_tail).read_zipper();
          for v628_6_byte in v628_6_cursor.child_mask().iter() {
            v628_6_cursor.descend_to_byte(v628_6_byte);
            {
            let v628_6_tail = v628_6_cursor.fork_read_zipper();
            let v628_6_head = Path::from_slice(&[v628_6_byte]);
            let v629_2: Space = singleton(&(v628_6_head));
            let v629_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v629_2));
            let v629_4: Space = if map_kernels::has_head(&(v629_3)) { singleton(&[]) } else { Space::new() };
            drop(v629_3);
            let v629_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v629_4));
            drop(v629_4);
            let v629_8: Space = if (v629_5).is_empty() { Space::new() } else {
              let v630_6: Path = concat_path(&(v626_10_head),&(v628_6_head));
              let v630_7: Space = routine_31(c, &(v630_6), &(v628_6_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v629_5),&(v630_7))
            };
            drop(v629_5);
            let v629_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v629_2));
            drop(v629_2);
            let v629_10: Space = if map_kernels::has_head(&(v629_9)) { singleton(&[]) } else { Space::new() };
            drop(v629_9);
            let v629_12: Space = if (v629_10).is_empty() { Space::new() } else {
              let v631_6: Path = concat_path(&(v626_10_head),&(v628_6_head));
              let v631_11: Space = routine_32(c, &(v631_6), &(v628_6_tail).make_space(), &(*s1));
              drop(v631_6);
              map_map_kernels::compose(&(v629_10),&(v631_11))
            };
            drop(v629_10);
            let v629_13: Space = map_map_kernels::unite(&(v629_8),&(v629_12));
            v628_6.join_into((v629_13).clone());
            }
            v628_6_cursor.ascend(1);
          }
          drop(v628_6_cursor);
          map_map_kernels::compose(&(v627_5),&(v628_6))
        };
        drop(v627_5);
        let v627_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v627_2));
        drop(v627_2);
        let v627_9: Space = if map_kernels::has_head(&(v627_8)) { singleton(&[]) } else { Space::new() };
        drop(v627_8);
        let v627_11: Space = if (v627_9).is_empty() { Space::new() } else {
          let mut v632_10 = Space::new();
          let mut v632_10_cursor = (v626_10_tail).read_zipper();
          for v632_10_byte in v632_10_cursor.child_mask().iter() {
            v632_10_cursor.descend_to_byte(v632_10_byte);
            {
            let v632_10_tail = v632_10_cursor.fork_read_zipper();
            let v632_10_head = Path::from_slice(&[v632_10_byte]);
            let v633_2: Space = singleton(&(v632_10_head));
            let v633_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v633_2));
            let v633_4: Space = if map_kernels::has_head(&(v633_3)) { singleton(&[]) } else { Space::new() };
            drop(v633_3);
            let v633_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v633_4));
            drop(v633_4);
            let v633_8: Space = if (v633_5).is_empty() { Space::new() } else {
              let v634_6: Path = concat_path(&(v626_10_head),&(v632_10_head));
              let v634_7: Space = routine_31(c, &(v634_6), &(v632_10_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v633_5),&(v634_7))
            };
            drop(v633_5);
            let v633_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v633_2));
            drop(v633_2);
            let v633_10: Space = if map_kernels::has_head(&(v633_9)) { singleton(&[]) } else { Space::new() };
            drop(v633_9);
            let v633_12: Space = if (v633_10).is_empty() { Space::new() } else {
              let v635_6: Path = concat_path(&(v626_10_head),&(v632_10_head));
              let v635_11: Space = routine_33(c, &(v635_6), &(v632_10_tail).make_space(), &(*s1));
              drop(v635_6);
              map_map_kernels::compose(&(v633_10),&(v635_11))
            };
            drop(v633_10);
            let v633_13: Space = map_map_kernels::unite(&(v633_8),&(v633_12));
            v632_10.join_into((v633_13).clone());
            }
            v632_10_cursor.ascend(1);
          }
          drop(v632_10_cursor);
          map_map_kernels::compose(&(v627_9),&(v632_10))
        };
        drop(v627_9);
        let v627_12: Space = map_map_kernels::unite(&(v627_7),&(v627_11));
        v626_10.join_into((v627_12).clone());
        }
        v626_10_cursor.ascend(1);
      }
      drop(v626_10_cursor);
      map_map_kernels::compose(&(v624_9),&(v626_10))
    };
    drop(v624_9);
    let v624_12: Path = concat_path(&(*p0),&(v623_15_head));
    let v624_13: Space = map_kernels::wrap(&(v624_11),&(v624_12));
    drop(v624_12);
    let v624_14: Space = map_map_kernels::unite(&(v624_7),&(v624_13));
    drop(v624_7);
    v623_15.join_into((v624_14).clone());
    }
    v623_15_cursor.ascend(1);
  }
  drop(v623_15_cursor);
  (v623_15).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v636_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v636_22: Space = map_kernels::unwrap(&(v636_21),&(*CONSTANT_4));
  drop(v636_21);
  let v636_23: Space = map_kernels::unwrap(&(v636_22),&(*p0));
  drop(v636_22);
  let mut v636_27 = Space::new();
  let mut v636_27_cursor = (*s0).read_zipper();
  for v636_27_byte in v636_27_cursor.child_mask().iter() {
    v636_27_cursor.descend_to_byte(v636_27_byte);
    {
    let v636_27_tail = v636_27_cursor.fork_read_zipper();
    let v636_27_head = Path::from_slice(&[v636_27_byte]);
    let v637_2: Space = singleton(&(v636_27_head));
    let v637_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v637_2));
    let v637_4: Space = if map_kernels::has_head(&(v637_3)) { singleton(&[]) } else { Space::new() };
    drop(v637_3);
    let v637_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v637_4));
    drop(v637_4);
    let v637_8: Space = if (v637_5).is_empty() { Space::new() } else {
      let v638_6: Path = concat_path(&(*p0),&(v636_27_head));
      let mut v638_7 = Space::new();
      let mut v638_7_cursor = (v636_27_tail).read_zipper();
      for v638_7_byte in v638_7_cursor.child_mask().iter() {
        v638_7_cursor.descend_to_byte(v638_7_byte);
        {
        let v638_7_tail = v638_7_cursor.fork_read_zipper();
        let v638_7_head = Path::from_slice(&[v638_7_byte]);
        let v639_2: Space = singleton(&(v638_7_head));
        let v639_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v639_2));
        let v639_4: Space = if map_kernels::has_head(&(v639_3)) { singleton(&[]) } else { Space::new() };
        drop(v639_3);
        let v639_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v639_4));
        drop(v639_4);
        let v639_8: Space = if (v639_5).is_empty() { Space::new() } else {
          let v640_6: Path = concat_path(&(v638_6),&(v638_7_head));
          let mut v640_7 = Space::new();
          let mut v640_7_cursor = (v638_7_tail).read_zipper();
          for v640_7_byte in v640_7_cursor.child_mask().iter() {
            v640_7_cursor.descend_to_byte(v640_7_byte);
            {
            let v640_7_tail = v640_7_cursor.fork_read_zipper();
            let v640_7_head = Path::from_slice(&[v640_7_byte]);
            let v641_2: Space = singleton(&(v640_7_head));
            let v641_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v641_2));
            let v641_4: Space = if map_kernels::has_head(&(v641_3)) { singleton(&[]) } else { Space::new() };
            drop(v641_3);
            let v641_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v641_4));
            drop(v641_4);
            let v641_8: Space = if (v641_5).is_empty() { Space::new() } else {
              let v642_6: Path = concat_path(&(v640_6),&(v640_7_head));
              let v642_7: Space = routine_55(c, &(v642_6), &(v640_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v641_5),&(v642_7))
            };
            drop(v641_5);
            let v641_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v641_2));
            drop(v641_2);
            let v641_10: Space = if map_kernels::has_head(&(v641_9)) { singleton(&[]) } else { Space::new() };
            drop(v641_9);
            let v641_12: Space = if (v641_10).is_empty() { Space::new() } else {
              let v643_6: Path = concat_path(&(v640_6),&(v640_7_head));
              let v643_11: Space = routine_56(c, &(v643_6), &(v640_7_tail).make_space(), &(*s1));
              drop(v643_6);
              map_map_kernels::compose(&(v641_10),&(v643_11))
            };
            drop(v641_10);
            let v641_13: Space = map_map_kernels::unite(&(v641_8),&(v641_12));
            v640_7.join_into((v641_13).clone());
            }
            v640_7_cursor.ascend(1);
          }
          drop(v640_7_cursor);
          map_map_kernels::compose(&(v639_5),&(v640_7))
        };
        drop(v639_5);
        let v639_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v639_2));
        drop(v639_2);
        let v639_10: Space = if map_kernels::has_head(&(v639_9)) { singleton(&[]) } else { Space::new() };
        drop(v639_9);
        let v639_12: Space = if (v639_10).is_empty() { Space::new() } else {
          let v644_6: Path = concat_path(&(v638_6),&(v638_7_head));
          let mut v644_11 = Space::new();
          let mut v644_11_cursor = (v638_7_tail).read_zipper();
          for v644_11_byte in v644_11_cursor.child_mask().iter() {
            v644_11_cursor.descend_to_byte(v644_11_byte);
            {
            let v644_11_tail = v644_11_cursor.fork_read_zipper();
            let v644_11_head = Path::from_slice(&[v644_11_byte]);
            let v645_2: Space = singleton(&(v644_11_head));
            let v645_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v645_2));
            let v645_4: Space = if map_kernels::has_head(&(v645_3)) { singleton(&[]) } else { Space::new() };
            drop(v645_3);
            let v645_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v645_4));
            drop(v645_4);
            let v645_8: Space = if (v645_5).is_empty() { Space::new() } else {
              let v646_6: Path = concat_path(&(v644_6),&(v644_11_head));
              let v646_7: Space = routine_55(c, &(v646_6), &(v644_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v645_5),&(v646_7))
            };
            drop(v645_5);
            let v645_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v645_2));
            drop(v645_2);
            let v645_10: Space = if map_kernels::has_head(&(v645_9)) { singleton(&[]) } else { Space::new() };
            drop(v645_9);
            let v645_12: Space = if (v645_10).is_empty() { Space::new() } else {
              let v647_6: Path = concat_path(&(v644_6),&(v644_11_head));
              let v647_11: Space = routine_33(c, &(v647_6), &(v644_11_tail).make_space(), &(*s1));
              drop(v647_6);
              map_map_kernels::compose(&(v645_10),&(v647_11))
            };
            drop(v645_10);
            let v645_13: Space = map_map_kernels::unite(&(v645_8),&(v645_12));
            v644_11.join_into((v645_13).clone());
            }
            v644_11_cursor.ascend(1);
          }
          drop(v644_11_cursor);
          drop(v644_6);
          map_map_kernels::compose(&(v639_10),&(v644_11))
        };
        drop(v639_10);
        let v639_13: Space = map_map_kernels::unite(&(v639_8),&(v639_12));
        v638_7.join_into((v639_13).clone());
        }
        v638_7_cursor.ascend(1);
      }
      drop(v638_7_cursor);
      map_map_kernels::compose(&(v637_5),&(v638_7))
    };
    drop(v637_5);
    let v637_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v637_2));
    drop(v637_2);
    let v637_10: Space = if map_kernels::has_head(&(v637_9)) { singleton(&[]) } else { Space::new() };
    drop(v637_9);
    let v637_13: Space = if (v637_10).is_empty() { Space::new() } else {
      let v648_6: Path = concat_path(&(*p0),&(v636_27_head));
      let v648_11: Space = map_kernels::unwrap(&(v636_23),&(v636_27_head));
      let mut v648_12 = Space::new();
      let mut v648_12_cursor = (v636_27_tail).read_zipper();
      for v648_12_byte in v648_12_cursor.child_mask().iter() {
        v648_12_cursor.descend_to_byte(v648_12_byte);
        {
        let v648_12_tail = v648_12_cursor.fork_read_zipper();
        let v648_12_head = Path::from_slice(&[v648_12_byte]);
        let v649_2: Space = singleton(&(v648_12_head));
        let v649_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v649_2));
        let v649_4: Space = if map_kernels::has_head(&(v649_3)) { singleton(&[]) } else { Space::new() };
        drop(v649_3);
        let v649_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v649_4));
        drop(v649_4);
        let v649_8: Space = if (v649_5).is_empty() { Space::new() } else {
          let v650_6: Path = concat_path(&(v648_6),&(v648_12_head));
          let mut v650_7 = Space::new();
          let mut v650_7_cursor = (v648_12_tail).read_zipper();
          for v650_7_byte in v650_7_cursor.child_mask().iter() {
            v650_7_cursor.descend_to_byte(v650_7_byte);
            {
            let v650_7_tail = v650_7_cursor.fork_read_zipper();
            let v650_7_head = Path::from_slice(&[v650_7_byte]);
            let v651_2: Space = singleton(&(v650_7_head));
            let v651_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v651_2));
            let v651_4: Space = if map_kernels::has_head(&(v651_3)) { singleton(&[]) } else { Space::new() };
            drop(v651_3);
            let v651_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v651_4));
            drop(v651_4);
            let v651_8: Space = if (v651_5).is_empty() { Space::new() } else {
              let v652_6: Path = concat_path(&(v650_6),&(v650_7_head));
              let v652_7: Space = routine_55(c, &(v652_6), &(v650_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v651_5),&(v652_7))
            };
            drop(v651_5);
            let v651_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v651_2));
            drop(v651_2);
            let v651_10: Space = if map_kernels::has_head(&(v651_9)) { singleton(&[]) } else { Space::new() };
            drop(v651_9);
            let v651_12: Space = if (v651_10).is_empty() { Space::new() } else {
              let v653_6: Path = concat_path(&(v650_6),&(v650_7_head));
              let v653_11: Space = routine_56(c, &(v653_6), &(v650_7_tail).make_space(), &(*s1));
              drop(v653_6);
              map_map_kernels::compose(&(v651_10),&(v653_11))
            };
            drop(v651_10);
            let v651_13: Space = map_map_kernels::unite(&(v651_8),&(v651_12));
            v650_7.join_into((v651_13).clone());
            }
            v650_7_cursor.ascend(1);
          }
          drop(v650_7_cursor);
          drop(v650_6);
          map_map_kernels::compose(&(v649_5),&(v650_7))
        };
        drop(v649_5);
        let v649_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v649_2));
        drop(v649_2);
        let v649_10: Space = if map_kernels::has_head(&(v649_9)) { singleton(&[]) } else { Space::new() };
        drop(v649_9);
        let v649_13: Space = if (v649_10).is_empty() { Space::new() } else {
          let v654_11: Space = map_kernels::unwrap(&(v648_11),&(v648_12_head));
          let v654_12: Space = map_map_kernels::subtract(&(v654_11),&(*CONSTANT_5));
          drop(v654_11);
          map_map_kernels::compose(&(v649_10),&(v654_12))
        };
        drop(v649_10);
        let v649_14: Space = map_map_kernels::unite(&(v649_8),&(v649_13));
        drop(v649_13);
        v648_12.join_into((v649_14).clone());
        }
        v648_12_cursor.ascend(1);
      }
      drop(v648_12_cursor);
      drop(v648_6);
      drop(v648_11);
      map_map_kernels::compose(&(v637_10),&(v648_12))
    };
    drop(v637_10);
    let v637_14: Space = map_map_kernels::unite(&(v637_8),&(v637_13));
    v636_27.join_into((v637_14).clone());
    }
    v636_27_cursor.ascend(1);
  }
  drop(v636_27_cursor);
  drop(v636_23);
  (v636_27).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v655_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v655_9: Space = map_kernels::unwrap(&(v655_7),&(*CONSTANT_4));
  drop(v655_7);
  let v655_10: Space = map_kernels::unwrap(&(v655_9),&(*p0));
  drop(v655_9);
  let mut v655_21 = Space::new();
  let mut v655_21_cursor = (*s0).read_zipper();
  for v655_21_byte in v655_21_cursor.child_mask().iter() {
    v655_21_cursor.descend_to_byte(v655_21_byte);
    {
    let v655_21_tail = v655_21_cursor.fork_read_zipper();
    let v655_21_head = Path::from_slice(&[v655_21_byte]);
    let v656_2: Space = singleton(&(v655_21_head));
    let v656_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v656_2));
    let v656_4: Space = if map_kernels::has_head(&(v656_3)) { singleton(&[]) } else { Space::new() };
    drop(v656_3);
    let v656_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v656_4));
    drop(v656_4);
    let v656_8: Space = if (v656_5).is_empty() { Space::new() } else {
      let v657_6: Path = concat_path(&(*p0),&(v655_21_head));
      let mut v657_7 = Space::new();
      let mut v657_7_cursor = (v655_21_tail).read_zipper();
      for v657_7_byte in v657_7_cursor.child_mask().iter() {
        v657_7_cursor.descend_to_byte(v657_7_byte);
        {
        let v657_7_tail = v657_7_cursor.fork_read_zipper();
        let v657_7_head = Path::from_slice(&[v657_7_byte]);
        let v658_2: Space = singleton(&(v657_7_head));
        let v658_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v658_2));
        let v658_4: Space = if map_kernels::has_head(&(v658_3)) { singleton(&[]) } else { Space::new() };
        drop(v658_3);
        let v658_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v658_4));
        drop(v658_4);
        let v658_8: Space = if (v658_5).is_empty() { Space::new() } else {
          let v659_6: Path = concat_path(&(v657_6),&(v657_7_head));
          let mut v659_7 = Space::new();
          let mut v659_7_cursor = (v657_7_tail).read_zipper();
          for v659_7_byte in v659_7_cursor.child_mask().iter() {
            v659_7_cursor.descend_to_byte(v659_7_byte);
            {
            let v659_7_tail = v659_7_cursor.fork_read_zipper();
            let v659_7_head = Path::from_slice(&[v659_7_byte]);
            let v660_2: Space = singleton(&(v659_7_head));
            let v660_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v660_2));
            let v660_4: Space = if map_kernels::has_head(&(v660_3)) { singleton(&[]) } else { Space::new() };
            drop(v660_3);
            let v660_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v660_4));
            drop(v660_4);
            let v660_8: Space = if (v660_5).is_empty() { Space::new() } else {
              let v661_6: Path = concat_path(&(v659_6),&(v659_7_head));
              let v661_7: Space = routine_55(c, &(v661_6), &(v659_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v660_5),&(v661_7))
            };
            drop(v660_5);
            let v660_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v660_2));
            drop(v660_2);
            let v660_10: Space = if map_kernels::has_head(&(v660_9)) { singleton(&[]) } else { Space::new() };
            drop(v660_9);
            let v660_12: Space = if (v660_10).is_empty() { Space::new() } else {
              let v662_6: Path = concat_path(&(v659_6),&(v659_7_head));
              let v662_11: Space = routine_56(c, &(v662_6), &(v659_7_tail).make_space(), &(*s1));
              drop(v662_6);
              map_map_kernels::compose(&(v660_10),&(v662_11))
            };
            drop(v660_10);
            let v660_13: Space = map_map_kernels::unite(&(v660_8),&(v660_12));
            v659_7.join_into((v660_13).clone());
            }
            v659_7_cursor.ascend(1);
          }
          drop(v659_7_cursor);
          map_map_kernels::compose(&(v658_5),&(v659_7))
        };
        drop(v658_5);
        let v658_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v658_2));
        drop(v658_2);
        let v658_10: Space = if map_kernels::has_head(&(v658_9)) { singleton(&[]) } else { Space::new() };
        drop(v658_9);
        let v658_12: Space = if (v658_10).is_empty() { Space::new() } else {
          let v663_6: Path = concat_path(&(v657_6),&(v657_7_head));
          let mut v663_11 = Space::new();
          let mut v663_11_cursor = (v657_7_tail).read_zipper();
          for v663_11_byte in v663_11_cursor.child_mask().iter() {
            v663_11_cursor.descend_to_byte(v663_11_byte);
            {
            let v663_11_tail = v663_11_cursor.fork_read_zipper();
            let v663_11_head = Path::from_slice(&[v663_11_byte]);
            let v664_2: Space = singleton(&(v663_11_head));
            let v664_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v664_2));
            let v664_4: Space = if map_kernels::has_head(&(v664_3)) { singleton(&[]) } else { Space::new() };
            drop(v664_3);
            let v664_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v664_4));
            drop(v664_4);
            let v664_8: Space = if (v664_5).is_empty() { Space::new() } else {
              let v665_6: Path = concat_path(&(v663_6),&(v663_11_head));
              let v665_7: Space = routine_55(c, &(v665_6), &(v663_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v664_5),&(v665_7))
            };
            drop(v664_5);
            let v664_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v664_2));
            drop(v664_2);
            let v664_10: Space = if map_kernels::has_head(&(v664_9)) { singleton(&[]) } else { Space::new() };
            drop(v664_9);
            let v664_12: Space = if (v664_10).is_empty() { Space::new() } else {
              let v666_6: Path = concat_path(&(v663_6),&(v663_11_head));
              let v666_11: Space = routine_33(c, &(v666_6), &(v663_11_tail).make_space(), &(*s1));
              drop(v666_6);
              map_map_kernels::compose(&(v664_10),&(v666_11))
            };
            drop(v664_10);
            let v664_13: Space = map_map_kernels::unite(&(v664_8),&(v664_12));
            v663_11.join_into((v664_13).clone());
            }
            v663_11_cursor.ascend(1);
          }
          drop(v663_11_cursor);
          drop(v663_6);
          map_map_kernels::compose(&(v658_10),&(v663_11))
        };
        drop(v658_10);
        let v658_13: Space = map_map_kernels::unite(&(v658_8),&(v658_12));
        v657_7.join_into((v658_13).clone());
        }
        v657_7_cursor.ascend(1);
      }
      drop(v657_7_cursor);
      drop(v657_6);
      map_map_kernels::compose(&(v656_5),&(v657_7))
    };
    drop(v656_5);
    let v656_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v656_2));
    drop(v656_2);
    let v656_10: Space = if map_kernels::has_head(&(v656_9)) { singleton(&[]) } else { Space::new() };
    drop(v656_9);
    let v656_13: Space = if (v656_10).is_empty() { Space::new() } else {
      let v667_11: Space = map_kernels::unwrap(&(v655_10),&(v655_21_head));
      let v667_12: Space = map_map_kernels::subtract(&(v667_11),&(*CONSTANT_5));
      drop(v667_11);
      map_map_kernels::compose(&(v656_10),&(v667_12))
    };
    drop(v656_10);
    let v656_14: Space = map_map_kernels::unite(&(v656_8),&(v656_13));
    drop(v656_13);
    v655_21.join_into((v656_14).clone());
    }
    v655_21_cursor.ascend(1);
  }
  drop(v655_21_cursor);
  drop(v655_10);
  (v655_21).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v668_4: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v668_6: Space = map_kernels::unwrap(&(v668_4),&(*CONSTANT_4));
  drop(v668_4);
  let v668_7: Space = map_kernels::unwrap(&(v668_6),&(*p0));
  drop(v668_6);
  let v668_9: Space = map_map_kernels::subtract(&(v668_7),&(*CONSTANT_5));
  drop(v668_7);
  (v668_9).clone()
}

fn routine_34(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v669_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v669_22: Space = map_kernels::unwrap(&(v669_21),&(*CONSTANT_4));
  drop(v669_21);
  let v669_23: Space = map_kernels::unwrap(&(v669_22),&(*p0));
  drop(v669_22);
  let mut v669_27 = Space::new();
  let mut v669_27_cursor = (*s0).read_zipper();
  for v669_27_byte in v669_27_cursor.child_mask().iter() {
    v669_27_cursor.descend_to_byte(v669_27_byte);
    {
    let v669_27_tail = v669_27_cursor.fork_read_zipper();
    let v669_27_head = Path::from_slice(&[v669_27_byte]);
    let v670_2: Space = singleton(&(v669_27_head));
    let v670_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v670_2));
    let v670_4: Space = if map_kernels::has_head(&(v670_3)) { singleton(&[]) } else { Space::new() };
    drop(v670_3);
    let v670_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v670_4));
    drop(v670_4);
    let v670_8: Space = if (v670_5).is_empty() { Space::new() } else {
      let v671_6: Path = concat_path(&(*p0),&(v669_27_head));
      let mut v671_7 = Space::new();
      let mut v671_7_cursor = (v669_27_tail).read_zipper();
      for v671_7_byte in v671_7_cursor.child_mask().iter() {
        v671_7_cursor.descend_to_byte(v671_7_byte);
        {
        let v671_7_tail = v671_7_cursor.fork_read_zipper();
        let v671_7_head = Path::from_slice(&[v671_7_byte]);
        let v672_2: Space = singleton(&(v671_7_head));
        let v672_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v672_2));
        let v672_4: Space = if map_kernels::has_head(&(v672_3)) { singleton(&[]) } else { Space::new() };
        drop(v672_3);
        let v672_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v672_4));
        drop(v672_4);
        let v672_8: Space = if (v672_5).is_empty() { Space::new() } else {
          let v673_6: Path = concat_path(&(v671_6),&(v671_7_head));
          let mut v673_7 = Space::new();
          let mut v673_7_cursor = (v671_7_tail).read_zipper();
          for v673_7_byte in v673_7_cursor.child_mask().iter() {
            v673_7_cursor.descend_to_byte(v673_7_byte);
            {
            let v673_7_tail = v673_7_cursor.fork_read_zipper();
            let v673_7_head = Path::from_slice(&[v673_7_byte]);
            let v674_2: Space = singleton(&(v673_7_head));
            let v674_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v674_2));
            let v674_4: Space = if map_kernels::has_head(&(v674_3)) { singleton(&[]) } else { Space::new() };
            drop(v674_3);
            let v674_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v674_4));
            drop(v674_4);
            let v674_8: Space = if (v674_5).is_empty() { Space::new() } else {
              let v675_6: Path = concat_path(&(v673_6),&(v673_7_head));
              let v675_7: Space = routine_57(c, &(v675_6), &(v673_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v674_5),&(v675_7))
            };
            drop(v674_5);
            let v674_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v674_2));
            drop(v674_2);
            let v674_10: Space = if map_kernels::has_head(&(v674_9)) { singleton(&[]) } else { Space::new() };
            drop(v674_9);
            let v674_12: Space = if (v674_10).is_empty() { Space::new() } else {
              let v676_6: Path = concat_path(&(v673_6),&(v673_7_head));
              let v676_11: Space = routine_58(c, &(v676_6), &(v673_7_tail).make_space(), &(*s1));
              drop(v676_6);
              map_map_kernels::compose(&(v674_10),&(v676_11))
            };
            drop(v674_10);
            let v674_13: Space = map_map_kernels::unite(&(v674_8),&(v674_12));
            v673_7.join_into((v674_13).clone());
            }
            v673_7_cursor.ascend(1);
          }
          drop(v673_7_cursor);
          map_map_kernels::compose(&(v672_5),&(v673_7))
        };
        drop(v672_5);
        let v672_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v672_2));
        drop(v672_2);
        let v672_10: Space = if map_kernels::has_head(&(v672_9)) { singleton(&[]) } else { Space::new() };
        drop(v672_9);
        let v672_12: Space = if (v672_10).is_empty() { Space::new() } else {
          let v677_6: Path = concat_path(&(v671_6),&(v671_7_head));
          let mut v677_11 = Space::new();
          let mut v677_11_cursor = (v671_7_tail).read_zipper();
          for v677_11_byte in v677_11_cursor.child_mask().iter() {
            v677_11_cursor.descend_to_byte(v677_11_byte);
            {
            let v677_11_tail = v677_11_cursor.fork_read_zipper();
            let v677_11_head = Path::from_slice(&[v677_11_byte]);
            let v678_2: Space = singleton(&(v677_11_head));
            let v678_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v678_2));
            let v678_4: Space = if map_kernels::has_head(&(v678_3)) { singleton(&[]) } else { Space::new() };
            drop(v678_3);
            let v678_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v678_4));
            drop(v678_4);
            let v678_8: Space = if (v678_5).is_empty() { Space::new() } else {
              let v679_6: Path = concat_path(&(v677_6),&(v677_11_head));
              let v679_7: Space = routine_57(c, &(v679_6), &(v677_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v678_5),&(v679_7))
            };
            drop(v678_5);
            let v678_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v678_2));
            drop(v678_2);
            let v678_10: Space = if map_kernels::has_head(&(v678_9)) { singleton(&[]) } else { Space::new() };
            drop(v678_9);
            let v678_12: Space = if (v678_10).is_empty() { Space::new() } else {
              let v680_6: Path = concat_path(&(v677_6),&(v677_11_head));
              let v680_11: Space = routine_33(c, &(v680_6), &(v677_11_tail).make_space(), &(*s1));
              drop(v680_6);
              map_map_kernels::compose(&(v678_10),&(v680_11))
            };
            drop(v678_10);
            let v678_13: Space = map_map_kernels::unite(&(v678_8),&(v678_12));
            v677_11.join_into((v678_13).clone());
            }
            v677_11_cursor.ascend(1);
          }
          drop(v677_11_cursor);
          drop(v677_6);
          map_map_kernels::compose(&(v672_10),&(v677_11))
        };
        drop(v672_10);
        let v672_13: Space = map_map_kernels::unite(&(v672_8),&(v672_12));
        v671_7.join_into((v672_13).clone());
        }
        v671_7_cursor.ascend(1);
      }
      drop(v671_7_cursor);
      map_map_kernels::compose(&(v670_5),&(v671_7))
    };
    drop(v670_5);
    let v670_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v670_2));
    drop(v670_2);
    let v670_10: Space = if map_kernels::has_head(&(v670_9)) { singleton(&[]) } else { Space::new() };
    drop(v670_9);
    let v670_13: Space = if (v670_10).is_empty() { Space::new() } else {
      let v681_6: Path = concat_path(&(*p0),&(v669_27_head));
      let v681_11: Space = map_kernels::unwrap(&(v669_23),&(v669_27_head));
      let mut v681_12 = Space::new();
      let mut v681_12_cursor = (v669_27_tail).read_zipper();
      for v681_12_byte in v681_12_cursor.child_mask().iter() {
        v681_12_cursor.descend_to_byte(v681_12_byte);
        {
        let v681_12_tail = v681_12_cursor.fork_read_zipper();
        let v681_12_head = Path::from_slice(&[v681_12_byte]);
        let v682_2: Space = singleton(&(v681_12_head));
        let v682_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v682_2));
        let v682_4: Space = if map_kernels::has_head(&(v682_3)) { singleton(&[]) } else { Space::new() };
        drop(v682_3);
        let v682_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v682_4));
        drop(v682_4);
        let v682_8: Space = if (v682_5).is_empty() { Space::new() } else {
          let v683_6: Path = concat_path(&(v681_6),&(v681_12_head));
          let mut v683_7 = Space::new();
          let mut v683_7_cursor = (v681_12_tail).read_zipper();
          for v683_7_byte in v683_7_cursor.child_mask().iter() {
            v683_7_cursor.descend_to_byte(v683_7_byte);
            {
            let v683_7_tail = v683_7_cursor.fork_read_zipper();
            let v683_7_head = Path::from_slice(&[v683_7_byte]);
            let v684_2: Space = singleton(&(v683_7_head));
            let v684_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v684_2));
            let v684_4: Space = if map_kernels::has_head(&(v684_3)) { singleton(&[]) } else { Space::new() };
            drop(v684_3);
            let v684_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v684_4));
            drop(v684_4);
            let v684_8: Space = if (v684_5).is_empty() { Space::new() } else {
              let v685_6: Path = concat_path(&(v683_6),&(v683_7_head));
              let v685_7: Space = routine_57(c, &(v685_6), &(v683_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v684_5),&(v685_7))
            };
            drop(v684_5);
            let v684_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v684_2));
            drop(v684_2);
            let v684_10: Space = if map_kernels::has_head(&(v684_9)) { singleton(&[]) } else { Space::new() };
            drop(v684_9);
            let v684_12: Space = if (v684_10).is_empty() { Space::new() } else {
              let v686_6: Path = concat_path(&(v683_6),&(v683_7_head));
              let v686_11: Space = routine_58(c, &(v686_6), &(v683_7_tail).make_space(), &(*s1));
              drop(v686_6);
              map_map_kernels::compose(&(v684_10),&(v686_11))
            };
            drop(v684_10);
            let v684_13: Space = map_map_kernels::unite(&(v684_8),&(v684_12));
            v683_7.join_into((v684_13).clone());
            }
            v683_7_cursor.ascend(1);
          }
          drop(v683_7_cursor);
          drop(v683_6);
          map_map_kernels::compose(&(v682_5),&(v683_7))
        };
        drop(v682_5);
        let v682_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v682_2));
        drop(v682_2);
        let v682_10: Space = if map_kernels::has_head(&(v682_9)) { singleton(&[]) } else { Space::new() };
        drop(v682_9);
        let v682_13: Space = if (v682_10).is_empty() { Space::new() } else {
          let v687_11: Space = map_kernels::unwrap(&(v681_11),&(v681_12_head));
          let v687_12: Space = map_map_kernels::subtract(&(v687_11),&(*CONSTANT_5));
          drop(v687_11);
          map_map_kernels::compose(&(v682_10),&(v687_12))
        };
        drop(v682_10);
        let v682_14: Space = map_map_kernels::unite(&(v682_8),&(v682_13));
        drop(v682_13);
        v681_12.join_into((v682_14).clone());
        }
        v681_12_cursor.ascend(1);
      }
      drop(v681_12_cursor);
      drop(v681_6);
      drop(v681_11);
      map_map_kernels::compose(&(v670_10),&(v681_12))
    };
    drop(v670_10);
    let v670_14: Space = map_map_kernels::unite(&(v670_8),&(v670_13));
    v669_27.join_into((v670_14).clone());
    }
    v669_27_cursor.ascend(1);
  }
  drop(v669_27_cursor);
  drop(v669_23);
  (v669_27).clone()
}

fn routine_35(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v688_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v688_9: Space = map_kernels::unwrap(&(v688_7),&(*CONSTANT_4));
  drop(v688_7);
  let v688_10: Space = map_kernels::unwrap(&(v688_9),&(*p0));
  drop(v688_9);
  let mut v688_21 = Space::new();
  let mut v688_21_cursor = (*s0).read_zipper();
  for v688_21_byte in v688_21_cursor.child_mask().iter() {
    v688_21_cursor.descend_to_byte(v688_21_byte);
    {
    let v688_21_tail = v688_21_cursor.fork_read_zipper();
    let v688_21_head = Path::from_slice(&[v688_21_byte]);
    let v689_2: Space = singleton(&(v688_21_head));
    let v689_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v689_2));
    let v689_4: Space = if map_kernels::has_head(&(v689_3)) { singleton(&[]) } else { Space::new() };
    drop(v689_3);
    let v689_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v689_4));
    drop(v689_4);
    let v689_8: Space = if (v689_5).is_empty() { Space::new() } else {
      let v690_6: Path = concat_path(&(*p0),&(v688_21_head));
      let mut v690_7 = Space::new();
      let mut v690_7_cursor = (v688_21_tail).read_zipper();
      for v690_7_byte in v690_7_cursor.child_mask().iter() {
        v690_7_cursor.descend_to_byte(v690_7_byte);
        {
        let v690_7_tail = v690_7_cursor.fork_read_zipper();
        let v690_7_head = Path::from_slice(&[v690_7_byte]);
        let v691_2: Space = singleton(&(v690_7_head));
        let v691_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v691_2));
        let v691_4: Space = if map_kernels::has_head(&(v691_3)) { singleton(&[]) } else { Space::new() };
        drop(v691_3);
        let v691_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v691_4));
        drop(v691_4);
        let v691_8: Space = if (v691_5).is_empty() { Space::new() } else {
          let v692_6: Path = concat_path(&(v690_6),&(v690_7_head));
          let mut v692_7 = Space::new();
          let mut v692_7_cursor = (v690_7_tail).read_zipper();
          for v692_7_byte in v692_7_cursor.child_mask().iter() {
            v692_7_cursor.descend_to_byte(v692_7_byte);
            {
            let v692_7_tail = v692_7_cursor.fork_read_zipper();
            let v692_7_head = Path::from_slice(&[v692_7_byte]);
            let v693_2: Space = singleton(&(v692_7_head));
            let v693_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v693_2));
            let v693_4: Space = if map_kernels::has_head(&(v693_3)) { singleton(&[]) } else { Space::new() };
            drop(v693_3);
            let v693_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v693_4));
            drop(v693_4);
            let v693_8: Space = if (v693_5).is_empty() { Space::new() } else {
              let v694_6: Path = concat_path(&(v692_6),&(v692_7_head));
              let v694_7: Space = routine_57(c, &(v694_6), &(v692_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v693_5),&(v694_7))
            };
            drop(v693_5);
            let v693_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v693_2));
            drop(v693_2);
            let v693_10: Space = if map_kernels::has_head(&(v693_9)) { singleton(&[]) } else { Space::new() };
            drop(v693_9);
            let v693_12: Space = if (v693_10).is_empty() { Space::new() } else {
              let v695_6: Path = concat_path(&(v692_6),&(v692_7_head));
              let v695_11: Space = routine_58(c, &(v695_6), &(v692_7_tail).make_space(), &(*s1));
              drop(v695_6);
              map_map_kernels::compose(&(v693_10),&(v695_11))
            };
            drop(v693_10);
            let v693_13: Space = map_map_kernels::unite(&(v693_8),&(v693_12));
            v692_7.join_into((v693_13).clone());
            }
            v692_7_cursor.ascend(1);
          }
          drop(v692_7_cursor);
          map_map_kernels::compose(&(v691_5),&(v692_7))
        };
        drop(v691_5);
        let v691_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v691_2));
        drop(v691_2);
        let v691_10: Space = if map_kernels::has_head(&(v691_9)) { singleton(&[]) } else { Space::new() };
        drop(v691_9);
        let v691_12: Space = if (v691_10).is_empty() { Space::new() } else {
          let v696_6: Path = concat_path(&(v690_6),&(v690_7_head));
          let mut v696_11 = Space::new();
          let mut v696_11_cursor = (v690_7_tail).read_zipper();
          for v696_11_byte in v696_11_cursor.child_mask().iter() {
            v696_11_cursor.descend_to_byte(v696_11_byte);
            {
            let v696_11_tail = v696_11_cursor.fork_read_zipper();
            let v696_11_head = Path::from_slice(&[v696_11_byte]);
            let v697_2: Space = singleton(&(v696_11_head));
            let v697_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v697_2));
            let v697_4: Space = if map_kernels::has_head(&(v697_3)) { singleton(&[]) } else { Space::new() };
            drop(v697_3);
            let v697_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v697_4));
            drop(v697_4);
            let v697_8: Space = if (v697_5).is_empty() { Space::new() } else {
              let v698_6: Path = concat_path(&(v696_6),&(v696_11_head));
              let v698_7: Space = routine_57(c, &(v698_6), &(v696_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v697_5),&(v698_7))
            };
            drop(v697_5);
            let v697_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v697_2));
            drop(v697_2);
            let v697_10: Space = if map_kernels::has_head(&(v697_9)) { singleton(&[]) } else { Space::new() };
            drop(v697_9);
            let v697_12: Space = if (v697_10).is_empty() { Space::new() } else {
              let v699_6: Path = concat_path(&(v696_6),&(v696_11_head));
              let v699_11: Space = routine_33(c, &(v699_6), &(v696_11_tail).make_space(), &(*s1));
              drop(v699_6);
              map_map_kernels::compose(&(v697_10),&(v699_11))
            };
            drop(v697_10);
            let v697_13: Space = map_map_kernels::unite(&(v697_8),&(v697_12));
            v696_11.join_into((v697_13).clone());
            }
            v696_11_cursor.ascend(1);
          }
          drop(v696_11_cursor);
          drop(v696_6);
          map_map_kernels::compose(&(v691_10),&(v696_11))
        };
        drop(v691_10);
        let v691_13: Space = map_map_kernels::unite(&(v691_8),&(v691_12));
        v690_7.join_into((v691_13).clone());
        }
        v690_7_cursor.ascend(1);
      }
      drop(v690_7_cursor);
      drop(v690_6);
      map_map_kernels::compose(&(v689_5),&(v690_7))
    };
    drop(v689_5);
    let v689_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v689_2));
    drop(v689_2);
    let v689_10: Space = if map_kernels::has_head(&(v689_9)) { singleton(&[]) } else { Space::new() };
    drop(v689_9);
    let v689_13: Space = if (v689_10).is_empty() { Space::new() } else {
      let v700_11: Space = map_kernels::unwrap(&(v688_10),&(v688_21_head));
      let v700_12: Space = map_map_kernels::subtract(&(v700_11),&(*CONSTANT_5));
      drop(v700_11);
      map_map_kernels::compose(&(v689_10),&(v700_12))
    };
    drop(v689_10);
    let v689_14: Space = map_map_kernels::unite(&(v689_8),&(v689_13));
    drop(v689_13);
    v688_21.join_into((v689_14).clone());
    }
    v688_21_cursor.ascend(1);
  }
  drop(v688_21_cursor);
  drop(v688_10);
  (v688_21).clone()
}

fn routine_36(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v701_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v701_22: Space = map_kernels::unwrap(&(v701_21),&(*CONSTANT_4));
  drop(v701_21);
  let v701_23: Space = map_kernels::unwrap(&(v701_22),&(*p0));
  drop(v701_22);
  let mut v701_27 = Space::new();
  let mut v701_27_cursor = (*s0).read_zipper();
  for v701_27_byte in v701_27_cursor.child_mask().iter() {
    v701_27_cursor.descend_to_byte(v701_27_byte);
    {
    let v701_27_tail = v701_27_cursor.fork_read_zipper();
    let v701_27_head = Path::from_slice(&[v701_27_byte]);
    let v702_2: Space = singleton(&(v701_27_head));
    let v702_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v702_2));
    let v702_4: Space = if map_kernels::has_head(&(v702_3)) { singleton(&[]) } else { Space::new() };
    drop(v702_3);
    let v702_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v702_4));
    drop(v702_4);
    let v702_8: Space = if (v702_5).is_empty() { Space::new() } else {
      let v703_6: Path = concat_path(&(*p0),&(v701_27_head));
      let mut v703_7 = Space::new();
      let mut v703_7_cursor = (v701_27_tail).read_zipper();
      for v703_7_byte in v703_7_cursor.child_mask().iter() {
        v703_7_cursor.descend_to_byte(v703_7_byte);
        {
        let v703_7_tail = v703_7_cursor.fork_read_zipper();
        let v703_7_head = Path::from_slice(&[v703_7_byte]);
        let v704_2: Space = singleton(&(v703_7_head));
        let v704_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v704_2));
        let v704_4: Space = if map_kernels::has_head(&(v704_3)) { singleton(&[]) } else { Space::new() };
        drop(v704_3);
        let v704_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v704_4));
        drop(v704_4);
        let v704_8: Space = if (v704_5).is_empty() { Space::new() } else {
          let v705_6: Path = concat_path(&(v703_6),&(v703_7_head));
          let mut v705_7 = Space::new();
          let mut v705_7_cursor = (v703_7_tail).read_zipper();
          for v705_7_byte in v705_7_cursor.child_mask().iter() {
            v705_7_cursor.descend_to_byte(v705_7_byte);
            {
            let v705_7_tail = v705_7_cursor.fork_read_zipper();
            let v705_7_head = Path::from_slice(&[v705_7_byte]);
            let v706_2: Space = singleton(&(v705_7_head));
            let v706_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v706_2));
            let v706_4: Space = if map_kernels::has_head(&(v706_3)) { singleton(&[]) } else { Space::new() };
            drop(v706_3);
            let v706_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v706_4));
            drop(v706_4);
            let v706_8: Space = if (v706_5).is_empty() { Space::new() } else {
              let v707_6: Path = concat_path(&(v705_6),&(v705_7_head));
              let v707_7: Space = routine_59(c, &(v707_6), &(v705_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v706_5),&(v707_7))
            };
            drop(v706_5);
            let v706_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v706_2));
            drop(v706_2);
            let v706_10: Space = if map_kernels::has_head(&(v706_9)) { singleton(&[]) } else { Space::new() };
            drop(v706_9);
            let v706_12: Space = if (v706_10).is_empty() { Space::new() } else {
              let v708_6: Path = concat_path(&(v705_6),&(v705_7_head));
              let v708_11: Space = routine_60(c, &(v708_6), &(v705_7_tail).make_space(), &(*s1));
              drop(v708_6);
              map_map_kernels::compose(&(v706_10),&(v708_11))
            };
            drop(v706_10);
            let v706_13: Space = map_map_kernels::unite(&(v706_8),&(v706_12));
            v705_7.join_into((v706_13).clone());
            }
            v705_7_cursor.ascend(1);
          }
          drop(v705_7_cursor);
          map_map_kernels::compose(&(v704_5),&(v705_7))
        };
        drop(v704_5);
        let v704_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v704_2));
        drop(v704_2);
        let v704_10: Space = if map_kernels::has_head(&(v704_9)) { singleton(&[]) } else { Space::new() };
        drop(v704_9);
        let v704_12: Space = if (v704_10).is_empty() { Space::new() } else {
          let v709_6: Path = concat_path(&(v703_6),&(v703_7_head));
          let mut v709_11 = Space::new();
          let mut v709_11_cursor = (v703_7_tail).read_zipper();
          for v709_11_byte in v709_11_cursor.child_mask().iter() {
            v709_11_cursor.descend_to_byte(v709_11_byte);
            {
            let v709_11_tail = v709_11_cursor.fork_read_zipper();
            let v709_11_head = Path::from_slice(&[v709_11_byte]);
            let v710_2: Space = singleton(&(v709_11_head));
            let v710_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v710_2));
            let v710_4: Space = if map_kernels::has_head(&(v710_3)) { singleton(&[]) } else { Space::new() };
            drop(v710_3);
            let v710_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v710_4));
            drop(v710_4);
            let v710_8: Space = if (v710_5).is_empty() { Space::new() } else {
              let v711_6: Path = concat_path(&(v709_6),&(v709_11_head));
              let v711_7: Space = routine_59(c, &(v711_6), &(v709_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v710_5),&(v711_7))
            };
            drop(v710_5);
            let v710_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v710_2));
            drop(v710_2);
            let v710_10: Space = if map_kernels::has_head(&(v710_9)) { singleton(&[]) } else { Space::new() };
            drop(v710_9);
            let v710_12: Space = if (v710_10).is_empty() { Space::new() } else {
              let v712_6: Path = concat_path(&(v709_6),&(v709_11_head));
              let v712_11: Space = routine_33(c, &(v712_6), &(v709_11_tail).make_space(), &(*s1));
              drop(v712_6);
              map_map_kernels::compose(&(v710_10),&(v712_11))
            };
            drop(v710_10);
            let v710_13: Space = map_map_kernels::unite(&(v710_8),&(v710_12));
            v709_11.join_into((v710_13).clone());
            }
            v709_11_cursor.ascend(1);
          }
          drop(v709_11_cursor);
          drop(v709_6);
          map_map_kernels::compose(&(v704_10),&(v709_11))
        };
        drop(v704_10);
        let v704_13: Space = map_map_kernels::unite(&(v704_8),&(v704_12));
        v703_7.join_into((v704_13).clone());
        }
        v703_7_cursor.ascend(1);
      }
      drop(v703_7_cursor);
      map_map_kernels::compose(&(v702_5),&(v703_7))
    };
    drop(v702_5);
    let v702_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v702_2));
    drop(v702_2);
    let v702_10: Space = if map_kernels::has_head(&(v702_9)) { singleton(&[]) } else { Space::new() };
    drop(v702_9);
    let v702_13: Space = if (v702_10).is_empty() { Space::new() } else {
      let v713_6: Path = concat_path(&(*p0),&(v701_27_head));
      let v713_11: Space = map_kernels::unwrap(&(v701_23),&(v701_27_head));
      let mut v713_12 = Space::new();
      let mut v713_12_cursor = (v701_27_tail).read_zipper();
      for v713_12_byte in v713_12_cursor.child_mask().iter() {
        v713_12_cursor.descend_to_byte(v713_12_byte);
        {
        let v713_12_tail = v713_12_cursor.fork_read_zipper();
        let v713_12_head = Path::from_slice(&[v713_12_byte]);
        let v714_2: Space = singleton(&(v713_12_head));
        let v714_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v714_2));
        let v714_4: Space = if map_kernels::has_head(&(v714_3)) { singleton(&[]) } else { Space::new() };
        drop(v714_3);
        let v714_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v714_4));
        drop(v714_4);
        let v714_8: Space = if (v714_5).is_empty() { Space::new() } else {
          let v715_6: Path = concat_path(&(v713_6),&(v713_12_head));
          let mut v715_7 = Space::new();
          let mut v715_7_cursor = (v713_12_tail).read_zipper();
          for v715_7_byte in v715_7_cursor.child_mask().iter() {
            v715_7_cursor.descend_to_byte(v715_7_byte);
            {
            let v715_7_tail = v715_7_cursor.fork_read_zipper();
            let v715_7_head = Path::from_slice(&[v715_7_byte]);
            let v716_2: Space = singleton(&(v715_7_head));
            let v716_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v716_2));
            let v716_4: Space = if map_kernels::has_head(&(v716_3)) { singleton(&[]) } else { Space::new() };
            drop(v716_3);
            let v716_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v716_4));
            drop(v716_4);
            let v716_8: Space = if (v716_5).is_empty() { Space::new() } else {
              let v717_6: Path = concat_path(&(v715_6),&(v715_7_head));
              let v717_7: Space = routine_59(c, &(v717_6), &(v715_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v716_5),&(v717_7))
            };
            drop(v716_5);
            let v716_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v716_2));
            drop(v716_2);
            let v716_10: Space = if map_kernels::has_head(&(v716_9)) { singleton(&[]) } else { Space::new() };
            drop(v716_9);
            let v716_12: Space = if (v716_10).is_empty() { Space::new() } else {
              let v718_6: Path = concat_path(&(v715_6),&(v715_7_head));
              let v718_11: Space = routine_60(c, &(v718_6), &(v715_7_tail).make_space(), &(*s1));
              drop(v718_6);
              map_map_kernels::compose(&(v716_10),&(v718_11))
            };
            drop(v716_10);
            let v716_13: Space = map_map_kernels::unite(&(v716_8),&(v716_12));
            v715_7.join_into((v716_13).clone());
            }
            v715_7_cursor.ascend(1);
          }
          drop(v715_7_cursor);
          drop(v715_6);
          map_map_kernels::compose(&(v714_5),&(v715_7))
        };
        drop(v714_5);
        let v714_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v714_2));
        drop(v714_2);
        let v714_10: Space = if map_kernels::has_head(&(v714_9)) { singleton(&[]) } else { Space::new() };
        drop(v714_9);
        let v714_13: Space = if (v714_10).is_empty() { Space::new() } else {
          let v719_11: Space = map_kernels::unwrap(&(v713_11),&(v713_12_head));
          let v719_12: Space = map_map_kernels::subtract(&(v719_11),&(*CONSTANT_5));
          drop(v719_11);
          map_map_kernels::compose(&(v714_10),&(v719_12))
        };
        drop(v714_10);
        let v714_14: Space = map_map_kernels::unite(&(v714_8),&(v714_13));
        drop(v714_13);
        v713_12.join_into((v714_14).clone());
        }
        v713_12_cursor.ascend(1);
      }
      drop(v713_12_cursor);
      drop(v713_6);
      drop(v713_11);
      map_map_kernels::compose(&(v702_10),&(v713_12))
    };
    drop(v702_10);
    let v702_14: Space = map_map_kernels::unite(&(v702_8),&(v702_13));
    v701_27.join_into((v702_14).clone());
    }
    v701_27_cursor.ascend(1);
  }
  drop(v701_27_cursor);
  drop(v701_23);
  (v701_27).clone()
}

fn routine_37(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v720_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v720_9: Space = map_kernels::unwrap(&(v720_7),&(*CONSTANT_4));
  drop(v720_7);
  let v720_10: Space = map_kernels::unwrap(&(v720_9),&(*p0));
  drop(v720_9);
  let mut v720_21 = Space::new();
  let mut v720_21_cursor = (*s0).read_zipper();
  for v720_21_byte in v720_21_cursor.child_mask().iter() {
    v720_21_cursor.descend_to_byte(v720_21_byte);
    {
    let v720_21_tail = v720_21_cursor.fork_read_zipper();
    let v720_21_head = Path::from_slice(&[v720_21_byte]);
    let v721_2: Space = singleton(&(v720_21_head));
    let v721_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v721_2));
    let v721_4: Space = if map_kernels::has_head(&(v721_3)) { singleton(&[]) } else { Space::new() };
    drop(v721_3);
    let v721_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v721_4));
    drop(v721_4);
    let v721_8: Space = if (v721_5).is_empty() { Space::new() } else {
      let v722_6: Path = concat_path(&(*p0),&(v720_21_head));
      let mut v722_7 = Space::new();
      let mut v722_7_cursor = (v720_21_tail).read_zipper();
      for v722_7_byte in v722_7_cursor.child_mask().iter() {
        v722_7_cursor.descend_to_byte(v722_7_byte);
        {
        let v722_7_tail = v722_7_cursor.fork_read_zipper();
        let v722_7_head = Path::from_slice(&[v722_7_byte]);
        let v723_2: Space = singleton(&(v722_7_head));
        let v723_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v723_2));
        let v723_4: Space = if map_kernels::has_head(&(v723_3)) { singleton(&[]) } else { Space::new() };
        drop(v723_3);
        let v723_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v723_4));
        drop(v723_4);
        let v723_8: Space = if (v723_5).is_empty() { Space::new() } else {
          let v724_6: Path = concat_path(&(v722_6),&(v722_7_head));
          let mut v724_7 = Space::new();
          let mut v724_7_cursor = (v722_7_tail).read_zipper();
          for v724_7_byte in v724_7_cursor.child_mask().iter() {
            v724_7_cursor.descend_to_byte(v724_7_byte);
            {
            let v724_7_tail = v724_7_cursor.fork_read_zipper();
            let v724_7_head = Path::from_slice(&[v724_7_byte]);
            let v725_2: Space = singleton(&(v724_7_head));
            let v725_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v725_2));
            let v725_4: Space = if map_kernels::has_head(&(v725_3)) { singleton(&[]) } else { Space::new() };
            drop(v725_3);
            let v725_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v725_4));
            drop(v725_4);
            let v725_8: Space = if (v725_5).is_empty() { Space::new() } else {
              let v726_6: Path = concat_path(&(v724_6),&(v724_7_head));
              let v726_7: Space = routine_59(c, &(v726_6), &(v724_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v725_5),&(v726_7))
            };
            drop(v725_5);
            let v725_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v725_2));
            drop(v725_2);
            let v725_10: Space = if map_kernels::has_head(&(v725_9)) { singleton(&[]) } else { Space::new() };
            drop(v725_9);
            let v725_12: Space = if (v725_10).is_empty() { Space::new() } else {
              let v727_6: Path = concat_path(&(v724_6),&(v724_7_head));
              let v727_11: Space = routine_60(c, &(v727_6), &(v724_7_tail).make_space(), &(*s1));
              drop(v727_6);
              map_map_kernels::compose(&(v725_10),&(v727_11))
            };
            drop(v725_10);
            let v725_13: Space = map_map_kernels::unite(&(v725_8),&(v725_12));
            v724_7.join_into((v725_13).clone());
            }
            v724_7_cursor.ascend(1);
          }
          drop(v724_7_cursor);
          map_map_kernels::compose(&(v723_5),&(v724_7))
        };
        drop(v723_5);
        let v723_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v723_2));
        drop(v723_2);
        let v723_10: Space = if map_kernels::has_head(&(v723_9)) { singleton(&[]) } else { Space::new() };
        drop(v723_9);
        let v723_12: Space = if (v723_10).is_empty() { Space::new() } else {
          let v728_6: Path = concat_path(&(v722_6),&(v722_7_head));
          let mut v728_11 = Space::new();
          let mut v728_11_cursor = (v722_7_tail).read_zipper();
          for v728_11_byte in v728_11_cursor.child_mask().iter() {
            v728_11_cursor.descend_to_byte(v728_11_byte);
            {
            let v728_11_tail = v728_11_cursor.fork_read_zipper();
            let v728_11_head = Path::from_slice(&[v728_11_byte]);
            let v729_2: Space = singleton(&(v728_11_head));
            let v729_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v729_2));
            let v729_4: Space = if map_kernels::has_head(&(v729_3)) { singleton(&[]) } else { Space::new() };
            drop(v729_3);
            let v729_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v729_4));
            drop(v729_4);
            let v729_8: Space = if (v729_5).is_empty() { Space::new() } else {
              let v730_6: Path = concat_path(&(v728_6),&(v728_11_head));
              let v730_7: Space = routine_59(c, &(v730_6), &(v728_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v729_5),&(v730_7))
            };
            drop(v729_5);
            let v729_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v729_2));
            drop(v729_2);
            let v729_10: Space = if map_kernels::has_head(&(v729_9)) { singleton(&[]) } else { Space::new() };
            drop(v729_9);
            let v729_12: Space = if (v729_10).is_empty() { Space::new() } else {
              let v731_6: Path = concat_path(&(v728_6),&(v728_11_head));
              let v731_11: Space = routine_33(c, &(v731_6), &(v728_11_tail).make_space(), &(*s1));
              drop(v731_6);
              map_map_kernels::compose(&(v729_10),&(v731_11))
            };
            drop(v729_10);
            let v729_13: Space = map_map_kernels::unite(&(v729_8),&(v729_12));
            v728_11.join_into((v729_13).clone());
            }
            v728_11_cursor.ascend(1);
          }
          drop(v728_11_cursor);
          drop(v728_6);
          map_map_kernels::compose(&(v723_10),&(v728_11))
        };
        drop(v723_10);
        let v723_13: Space = map_map_kernels::unite(&(v723_8),&(v723_12));
        v722_7.join_into((v723_13).clone());
        }
        v722_7_cursor.ascend(1);
      }
      drop(v722_7_cursor);
      drop(v722_6);
      map_map_kernels::compose(&(v721_5),&(v722_7))
    };
    drop(v721_5);
    let v721_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v721_2));
    drop(v721_2);
    let v721_10: Space = if map_kernels::has_head(&(v721_9)) { singleton(&[]) } else { Space::new() };
    drop(v721_9);
    let v721_13: Space = if (v721_10).is_empty() { Space::new() } else {
      let v732_11: Space = map_kernels::unwrap(&(v720_10),&(v720_21_head));
      let v732_12: Space = map_map_kernels::subtract(&(v732_11),&(*CONSTANT_5));
      drop(v732_11);
      map_map_kernels::compose(&(v721_10),&(v732_12))
    };
    drop(v721_10);
    let v721_14: Space = map_map_kernels::unite(&(v721_8),&(v721_13));
    drop(v721_13);
    v720_21.join_into((v721_14).clone());
    }
    v720_21_cursor.ascend(1);
  }
  drop(v720_21_cursor);
  drop(v720_10);
  (v720_21).clone()
}

fn routine_38(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v733_7 = Space::new();
  let mut v733_7_cursor = (*s0).read_zipper();
  for v733_7_byte in v733_7_cursor.child_mask().iter() {
    v733_7_cursor.descend_to_byte(v733_7_byte);
    {
    let v733_7_tail = v733_7_cursor.fork_read_zipper();
    let v733_7_head = Path::from_slice(&[v733_7_byte]);
    let v734_2: Space = singleton(&(v733_7_head));
    let v734_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v734_2));
    let v734_4: Space = if map_kernels::has_head(&(v734_3)) { singleton(&[]) } else { Space::new() };
    drop(v734_3);
    let v734_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v734_4));
    drop(v734_4);
    let mut v734_6 = Space::new();
    let mut v734_6_cursor = (v733_7_tail).read_zipper();
    for v734_6_byte in v734_6_cursor.child_mask().iter() {
      v734_6_cursor.descend_to_byte(v734_6_byte);
      {
      let v734_6_tail = v734_6_cursor.fork_read_zipper();
      let v734_6_head = Path::from_slice(&[v734_6_byte]);
      let v735_2: Space = Space::new();
      v734_6.join_into((v735_2).clone());
      }
      v734_6_cursor.ascend(1);
    }
    drop(v734_6_cursor);
    let v734_7: Space = map_map_kernels::compose(&(v734_5),&(v734_6));
    drop(v734_5);
    drop(v734_6);
    let v734_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v734_2));
    drop(v734_2);
    let v734_9: Space = if map_kernels::has_head(&(v734_8)) { singleton(&[]) } else { Space::new() };
    drop(v734_8);
    let v734_12: Space = if (v734_9).is_empty() { Space::new() } else {
      let v736_10: Path = concat_path(&(*p0),&(v733_7_head));
      let mut v736_11 = Space::new();
      let mut v736_11_cursor = (v733_7_tail).read_zipper();
      for v736_11_byte in v736_11_cursor.child_mask().iter() {
        v736_11_cursor.descend_to_byte(v736_11_byte);
        {
        let v736_11_tail = v736_11_cursor.fork_read_zipper();
        let v736_11_head = Path::from_slice(&[v736_11_byte]);
        let v737_2: Space = singleton(&(v736_11_head));
        let v737_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v737_2));
        drop(v737_2);
        let v737_4: Space = if map_kernels::has_head(&(v737_3)) { singleton(&[]) } else { Space::new() };
        drop(v737_3);
        let v737_5: Space = view_map_kernels::subtract(&(v736_11_tail),&(*CONSTANT_5));
        let v737_6: Space = map_map_kernels::compose(&(v737_4),&(v737_5));
        drop(v737_4);
        drop(v737_5);
        let v737_7: Path = concat_path(&(v736_10),&(v736_11_head));
        let v737_8: Space = map_kernels::wrap(&(v737_6),&(v737_7));
        drop(v737_6);
        drop(v737_7);
        v736_11.join_into((v737_8).clone());
        }
        v736_11_cursor.ascend(1);
      }
      drop(v736_11_cursor);
      drop(v736_10);
      map_map_kernels::compose(&(v734_9),&(v736_11))
    };
    drop(v734_9);
    let v734_13: Space = map_map_kernels::unite(&(v734_7),&(v734_12));
    drop(v734_7);
    drop(v734_12);
    v733_7.join_into((v734_13).clone());
    }
    v733_7_cursor.ascend(1);
  }
  drop(v733_7_cursor);
  (v733_7).clone()
}

fn routine_39(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v738_6 = Space::new();
  let mut v738_6_cursor = (*s0).read_zipper();
  for v738_6_byte in v738_6_cursor.child_mask().iter() {
    v738_6_cursor.descend_to_byte(v738_6_byte);
    {
    let v738_6_tail = v738_6_cursor.fork_read_zipper();
    let v738_6_head = Path::from_slice(&[v738_6_byte]);
    let v739_2: Space = singleton(&(v738_6_head));
    let v739_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v739_2));
    let v739_4: Space = if map_kernels::has_head(&(v739_3)) { singleton(&[]) } else { Space::new() };
    drop(v739_3);
    let v739_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v739_4));
    drop(v739_4);
    let mut v739_6 = Space::new();
    let mut v739_6_cursor = (v738_6_tail).read_zipper();
    for v739_6_byte in v739_6_cursor.child_mask().iter() {
      v739_6_cursor.descend_to_byte(v739_6_byte);
      {
      let v739_6_tail = v739_6_cursor.fork_read_zipper();
      let v739_6_head = Path::from_slice(&[v739_6_byte]);
      let v740_2: Space = Space::new();
      v739_6.join_into((v740_2).clone());
      }
      v739_6_cursor.ascend(1);
    }
    drop(v739_6_cursor);
    let v739_7: Space = map_map_kernels::compose(&(v739_5),&(v739_6));
    drop(v739_5);
    drop(v739_6);
    let v739_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v739_2));
    drop(v739_2);
    let v739_9: Space = if map_kernels::has_head(&(v739_8)) { singleton(&[]) } else { Space::new() };
    drop(v739_8);
    let v739_10: Space = view_map_kernels::subtract(&(v738_6_tail),&(*CONSTANT_5));
    let v739_11: Space = map_map_kernels::compose(&(v739_9),&(v739_10));
    drop(v739_9);
    drop(v739_10);
    let v739_12: Path = concat_path(&(*p0),&(v738_6_head));
    let v739_13: Space = map_kernels::wrap(&(v739_11),&(v739_12));
    drop(v739_11);
    drop(v739_12);
    let v739_14: Space = map_map_kernels::unite(&(v739_7),&(v739_13));
    drop(v739_7);
    drop(v739_13);
    v738_6.join_into((v739_14).clone());
    }
    v738_6_cursor.ascend(1);
  }
  drop(v738_6_cursor);
  (v738_6).clone()
}

fn routine_40(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v741_10 = Space::new();
  let mut v741_10_cursor = (*s0).read_zipper();
  for v741_10_byte in v741_10_cursor.child_mask().iter() {
    v741_10_cursor.descend_to_byte(v741_10_byte);
    {
    let v741_10_tail = v741_10_cursor.fork_read_zipper();
    let v741_10_head = Path::from_slice(&[v741_10_byte]);
    let v742_2: Space = singleton(&(v741_10_head));
    let v742_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v742_2));
    let v742_4: Space = if map_kernels::has_head(&(v742_3)) { singleton(&[]) } else { Space::new() };
    drop(v742_3);
    let v742_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v742_4));
    drop(v742_4);
    let mut v742_6 = Space::new();
    let mut v742_6_cursor = (v741_10_tail).read_zipper();
    for v742_6_byte in v742_6_cursor.child_mask().iter() {
      v742_6_cursor.descend_to_byte(v742_6_byte);
      {
      let v742_6_tail = v742_6_cursor.fork_read_zipper();
      let v742_6_head = Path::from_slice(&[v742_6_byte]);
      let v743_2: Space = Space::new();
      v742_6.join_into((v743_2).clone());
      }
      v742_6_cursor.ascend(1);
    }
    drop(v742_6_cursor);
    let v742_7: Space = map_map_kernels::compose(&(v742_5),&(v742_6));
    drop(v742_5);
    drop(v742_6);
    let v742_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v742_2));
    drop(v742_2);
    let v742_9: Space = if map_kernels::has_head(&(v742_8)) { singleton(&[]) } else { Space::new() };
    drop(v742_8);
    let v742_12: Space = if (v742_9).is_empty() { Space::new() } else {
      let v744_10: Path = concat_path(&(*p0),&(v741_10_head));
      let mut v744_11 = Space::new();
      let mut v744_11_cursor = (v741_10_tail).read_zipper();
      for v744_11_byte in v744_11_cursor.child_mask().iter() {
        v744_11_cursor.descend_to_byte(v744_11_byte);
        {
        let v744_11_tail = v744_11_cursor.fork_read_zipper();
        let v744_11_head = Path::from_slice(&[v744_11_byte]);
        let v745_2: Space = singleton(&(v744_11_head));
        let v745_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v745_2));
        drop(v745_2);
        let v745_4: Space = if map_kernels::has_head(&(v745_3)) { singleton(&[]) } else { Space::new() };
        drop(v745_3);
        let v745_6: Space = if (v745_4).is_empty() { Space::new() } else {
          let mut v746_5 = Space::new();
          let mut v746_5_cursor = (v744_11_tail).read_zipper();
          for v746_5_byte in v746_5_cursor.child_mask().iter() {
            v746_5_cursor.descend_to_byte(v746_5_byte);
            {
            let v746_5_tail = v746_5_cursor.fork_read_zipper();
            let v746_5_head = Path::from_slice(&[v746_5_byte]);
            let v747_2: Space = singleton(&(v746_5_head));
            let v747_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v747_2));
            let v747_4: Space = if map_kernels::has_head(&(v747_3)) { singleton(&[]) } else { Space::new() };
            drop(v747_3);
            let v747_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v747_4));
            drop(v747_4);
            let v747_7: Space = if (v747_5).is_empty() { Space::new() } else {
              let v748_6: Space = routine_18(c, &(v746_5_head), &(v746_5_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v747_5),&(v748_6))
            };
            drop(v747_5);
            let v747_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v747_2));
            drop(v747_2);
            let v747_9: Space = if map_kernels::has_head(&(v747_8)) { singleton(&[]) } else { Space::new() };
            drop(v747_8);
            let v747_11: Space = if (v747_9).is_empty() { Space::new() } else {
              let v749_10: Space = routine_19(c, &(v746_5_head), &(v746_5_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v747_9),&(v749_10))
            };
            drop(v747_9);
            let v747_12: Space = map_map_kernels::unite(&(v747_7),&(v747_11));
            v746_5.join_into((v747_12).clone());
            }
            v746_5_cursor.ascend(1);
          }
          drop(v746_5_cursor);
          map_map_kernels::compose(&(v745_4),&(v746_5))
        };
        drop(v745_4);
        let v745_7: Path = concat_path(&(v744_10),&(v744_11_head));
        let v745_8: Space = map_kernels::wrap(&(v745_6),&(v745_7));
        drop(v745_7);
        v744_11.join_into((v745_8).clone());
        }
        v744_11_cursor.ascend(1);
      }
      drop(v744_11_cursor);
      drop(v744_10);
      map_map_kernels::compose(&(v742_9),&(v744_11))
    };
    drop(v742_9);
    let v742_13: Space = map_map_kernels::unite(&(v742_7),&(v742_12));
    drop(v742_7);
    v741_10.join_into((v742_13).clone());
    }
    v741_10_cursor.ascend(1);
  }
  drop(v741_10_cursor);
  (v741_10).clone()
}

fn routine_41(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v750_15 = Space::new();
  let mut v750_15_cursor = (*s0).read_zipper();
  for v750_15_byte in v750_15_cursor.child_mask().iter() {
    v750_15_cursor.descend_to_byte(v750_15_byte);
    {
    let v750_15_tail = v750_15_cursor.fork_read_zipper();
    let v750_15_head = Path::from_slice(&[v750_15_byte]);
    let v751_2: Space = singleton(&(v750_15_head));
    let v751_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v751_2));
    let v751_4: Space = if map_kernels::has_head(&(v751_3)) { singleton(&[]) } else { Space::new() };
    drop(v751_3);
    let v751_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v751_4));
    drop(v751_4);
    let mut v751_6 = Space::new();
    let mut v751_6_cursor = (v750_15_tail).read_zipper();
    for v751_6_byte in v751_6_cursor.child_mask().iter() {
      v751_6_cursor.descend_to_byte(v751_6_byte);
      {
      let v751_6_tail = v751_6_cursor.fork_read_zipper();
      let v751_6_head = Path::from_slice(&[v751_6_byte]);
      let v752_2: Space = Space::new();
      v751_6.join_into((v752_2).clone());
      }
      v751_6_cursor.ascend(1);
    }
    drop(v751_6_cursor);
    let v751_7: Space = map_map_kernels::compose(&(v751_5),&(v751_6));
    drop(v751_5);
    drop(v751_6);
    let v751_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v751_2));
    drop(v751_2);
    let v751_9: Space = if map_kernels::has_head(&(v751_8)) { singleton(&[]) } else { Space::new() };
    drop(v751_8);
    let v751_11: Space = if (v751_9).is_empty() { Space::new() } else {
      let mut v753_10 = Space::new();
      let mut v753_10_cursor = (v750_15_tail).read_zipper();
      for v753_10_byte in v753_10_cursor.child_mask().iter() {
        v753_10_cursor.descend_to_byte(v753_10_byte);
        {
        let v753_10_tail = v753_10_cursor.fork_read_zipper();
        let v753_10_head = Path::from_slice(&[v753_10_byte]);
        let v754_2: Space = singleton(&(v753_10_head));
        let v754_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v754_2));
        let v754_4: Space = if map_kernels::has_head(&(v754_3)) { singleton(&[]) } else { Space::new() };
        drop(v754_3);
        let v754_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v754_4));
        drop(v754_4);
        let v754_7: Space = if (v754_5).is_empty() { Space::new() } else {
          let mut v755_6 = Space::new();
          let mut v755_6_cursor = (v753_10_tail).read_zipper();
          for v755_6_byte in v755_6_cursor.child_mask().iter() {
            v755_6_cursor.descend_to_byte(v755_6_byte);
            {
            let v755_6_tail = v755_6_cursor.fork_read_zipper();
            let v755_6_head = Path::from_slice(&[v755_6_byte]);
            let v756_2: Space = singleton(&(v755_6_head));
            let v756_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v756_2));
            let v756_4: Space = if map_kernels::has_head(&(v756_3)) { singleton(&[]) } else { Space::new() };
            drop(v756_3);
            let v756_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v756_4));
            drop(v756_4);
            let v756_8: Space = if (v756_5).is_empty() { Space::new() } else {
              let v757_6: Path = concat_path(&(v753_10_head),&(v755_6_head));
              let v757_7: Space = routine_42(c, &(v757_6), &(v755_6_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v756_5),&(v757_7))
            };
            drop(v756_5);
            let v756_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v756_2));
            drop(v756_2);
            let v756_10: Space = if map_kernels::has_head(&(v756_9)) { singleton(&[]) } else { Space::new() };
            drop(v756_9);
            let v756_12: Space = if (v756_10).is_empty() { Space::new() } else {
              let v758_6: Path = concat_path(&(v753_10_head),&(v755_6_head));
              let v758_11: Space = routine_43(c, &(v758_6), &(v755_6_tail).make_space(), &(*s1));
              drop(v758_6);
              map_map_kernels::compose(&(v756_10),&(v758_11))
            };
            drop(v756_10);
            let v756_13: Space = map_map_kernels::unite(&(v756_8),&(v756_12));
            v755_6.join_into((v756_13).clone());
            }
            v755_6_cursor.ascend(1);
          }
          drop(v755_6_cursor);
          map_map_kernels::compose(&(v754_5),&(v755_6))
        };
        drop(v754_5);
        let v754_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v754_2));
        drop(v754_2);
        let v754_9: Space = if map_kernels::has_head(&(v754_8)) { singleton(&[]) } else { Space::new() };
        drop(v754_8);
        let v754_11: Space = if (v754_9).is_empty() { Space::new() } else {
          let mut v759_10 = Space::new();
          let mut v759_10_cursor = (v753_10_tail).read_zipper();
          for v759_10_byte in v759_10_cursor.child_mask().iter() {
            v759_10_cursor.descend_to_byte(v759_10_byte);
            {
            let v759_10_tail = v759_10_cursor.fork_read_zipper();
            let v759_10_head = Path::from_slice(&[v759_10_byte]);
            let v760_2: Space = singleton(&(v759_10_head));
            let v760_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v760_2));
            let v760_4: Space = if map_kernels::has_head(&(v760_3)) { singleton(&[]) } else { Space::new() };
            drop(v760_3);
            let v760_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v760_4));
            drop(v760_4);
            let v760_8: Space = if (v760_5).is_empty() { Space::new() } else {
              let v761_6: Path = concat_path(&(v753_10_head),&(v759_10_head));
              let v761_7: Space = routine_42(c, &(v761_6), &(v759_10_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v760_5),&(v761_7))
            };
            drop(v760_5);
            let v760_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v760_2));
            drop(v760_2);
            let v760_10: Space = if map_kernels::has_head(&(v760_9)) { singleton(&[]) } else { Space::new() };
            drop(v760_9);
            let v760_12: Space = if (v760_10).is_empty() { Space::new() } else {
              let v762_6: Path = concat_path(&(v753_10_head),&(v759_10_head));
              let v762_11: Space = routine_44(c, &(v762_6), &(v759_10_tail).make_space(), &(*s1));
              drop(v762_6);
              map_map_kernels::compose(&(v760_10),&(v762_11))
            };
            drop(v760_10);
            let v760_13: Space = map_map_kernels::unite(&(v760_8),&(v760_12));
            v759_10.join_into((v760_13).clone());
            }
            v759_10_cursor.ascend(1);
          }
          drop(v759_10_cursor);
          map_map_kernels::compose(&(v754_9),&(v759_10))
        };
        drop(v754_9);
        let v754_12: Space = map_map_kernels::unite(&(v754_7),&(v754_11));
        v753_10.join_into((v754_12).clone());
        }
        v753_10_cursor.ascend(1);
      }
      drop(v753_10_cursor);
      map_map_kernels::compose(&(v751_9),&(v753_10))
    };
    drop(v751_9);
    let v751_12: Path = concat_path(&(*p0),&(v750_15_head));
    let v751_13: Space = map_kernels::wrap(&(v751_11),&(v751_12));
    drop(v751_12);
    let v751_14: Space = map_map_kernels::unite(&(v751_7),&(v751_13));
    drop(v751_7);
    v750_15.join_into((v751_14).clone());
    }
    v750_15_cursor.ascend(1);
  }
  drop(v750_15_cursor);
  (v750_15).clone()
}

fn routine_42(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v763_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v763_22: Space = map_kernels::unwrap(&(v763_21),&(*CONSTANT_4));
  drop(v763_21);
  let v763_23: Space = map_kernels::unwrap(&(v763_22),&(*p0));
  drop(v763_22);
  let mut v763_27 = Space::new();
  let mut v763_27_cursor = (*s0).read_zipper();
  for v763_27_byte in v763_27_cursor.child_mask().iter() {
    v763_27_cursor.descend_to_byte(v763_27_byte);
    {
    let v763_27_tail = v763_27_cursor.fork_read_zipper();
    let v763_27_head = Path::from_slice(&[v763_27_byte]);
    let v764_2: Space = singleton(&(v763_27_head));
    let v764_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v764_2));
    let v764_4: Space = if map_kernels::has_head(&(v764_3)) { singleton(&[]) } else { Space::new() };
    drop(v764_3);
    let v764_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v764_4));
    drop(v764_4);
    let v764_8: Space = if (v764_5).is_empty() { Space::new() } else {
      let v765_6: Path = concat_path(&(*p0),&(v763_27_head));
      let mut v765_7 = Space::new();
      let mut v765_7_cursor = (v763_27_tail).read_zipper();
      for v765_7_byte in v765_7_cursor.child_mask().iter() {
        v765_7_cursor.descend_to_byte(v765_7_byte);
        {
        let v765_7_tail = v765_7_cursor.fork_read_zipper();
        let v765_7_head = Path::from_slice(&[v765_7_byte]);
        let v766_2: Space = singleton(&(v765_7_head));
        let v766_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v766_2));
        let v766_4: Space = if map_kernels::has_head(&(v766_3)) { singleton(&[]) } else { Space::new() };
        drop(v766_3);
        let v766_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v766_4));
        drop(v766_4);
        let v766_8: Space = if (v766_5).is_empty() { Space::new() } else {
          let v767_6: Path = concat_path(&(v765_6),&(v765_7_head));
          let mut v767_7 = Space::new();
          let mut v767_7_cursor = (v765_7_tail).read_zipper();
          for v767_7_byte in v767_7_cursor.child_mask().iter() {
            v767_7_cursor.descend_to_byte(v767_7_byte);
            {
            let v767_7_tail = v767_7_cursor.fork_read_zipper();
            let v767_7_head = Path::from_slice(&[v767_7_byte]);
            let v768_2: Space = singleton(&(v767_7_head));
            let v768_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v768_2));
            let v768_4: Space = if map_kernels::has_head(&(v768_3)) { singleton(&[]) } else { Space::new() };
            drop(v768_3);
            let v768_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v768_4));
            drop(v768_4);
            let v768_8: Space = if (v768_5).is_empty() { Space::new() } else {
              let v769_6: Path = concat_path(&(v767_6),&(v767_7_head));
              let v769_7: Space = routine_61(c, &(v769_6), &(v767_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v768_5),&(v769_7))
            };
            drop(v768_5);
            let v768_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v768_2));
            drop(v768_2);
            let v768_10: Space = if map_kernels::has_head(&(v768_9)) { singleton(&[]) } else { Space::new() };
            drop(v768_9);
            let v768_12: Space = if (v768_10).is_empty() { Space::new() } else {
              let v770_6: Path = concat_path(&(v767_6),&(v767_7_head));
              let v770_11: Space = routine_62(c, &(v770_6), &(v767_7_tail).make_space(), &(*s1));
              drop(v770_6);
              map_map_kernels::compose(&(v768_10),&(v770_11))
            };
            drop(v768_10);
            let v768_13: Space = map_map_kernels::unite(&(v768_8),&(v768_12));
            v767_7.join_into((v768_13).clone());
            }
            v767_7_cursor.ascend(1);
          }
          drop(v767_7_cursor);
          map_map_kernels::compose(&(v766_5),&(v767_7))
        };
        drop(v766_5);
        let v766_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v766_2));
        drop(v766_2);
        let v766_10: Space = if map_kernels::has_head(&(v766_9)) { singleton(&[]) } else { Space::new() };
        drop(v766_9);
        let v766_12: Space = if (v766_10).is_empty() { Space::new() } else {
          let v771_6: Path = concat_path(&(v765_6),&(v765_7_head));
          let mut v771_11 = Space::new();
          let mut v771_11_cursor = (v765_7_tail).read_zipper();
          for v771_11_byte in v771_11_cursor.child_mask().iter() {
            v771_11_cursor.descend_to_byte(v771_11_byte);
            {
            let v771_11_tail = v771_11_cursor.fork_read_zipper();
            let v771_11_head = Path::from_slice(&[v771_11_byte]);
            let v772_2: Space = singleton(&(v771_11_head));
            let v772_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v772_2));
            let v772_4: Space = if map_kernels::has_head(&(v772_3)) { singleton(&[]) } else { Space::new() };
            drop(v772_3);
            let v772_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v772_4));
            drop(v772_4);
            let v772_8: Space = if (v772_5).is_empty() { Space::new() } else {
              let v773_6: Path = concat_path(&(v771_6),&(v771_11_head));
              let v773_7: Space = routine_61(c, &(v773_6), &(v771_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v772_5),&(v773_7))
            };
            drop(v772_5);
            let v772_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v772_2));
            drop(v772_2);
            let v772_10: Space = if map_kernels::has_head(&(v772_9)) { singleton(&[]) } else { Space::new() };
            drop(v772_9);
            let v772_12: Space = if (v772_10).is_empty() { Space::new() } else {
              let v774_6: Path = concat_path(&(v771_6),&(v771_11_head));
              let v774_11: Space = routine_44(c, &(v774_6), &(v771_11_tail).make_space(), &(*s1));
              drop(v774_6);
              map_map_kernels::compose(&(v772_10),&(v774_11))
            };
            drop(v772_10);
            let v772_13: Space = map_map_kernels::unite(&(v772_8),&(v772_12));
            v771_11.join_into((v772_13).clone());
            }
            v771_11_cursor.ascend(1);
          }
          drop(v771_11_cursor);
          drop(v771_6);
          map_map_kernels::compose(&(v766_10),&(v771_11))
        };
        drop(v766_10);
        let v766_13: Space = map_map_kernels::unite(&(v766_8),&(v766_12));
        v765_7.join_into((v766_13).clone());
        }
        v765_7_cursor.ascend(1);
      }
      drop(v765_7_cursor);
      map_map_kernels::compose(&(v764_5),&(v765_7))
    };
    drop(v764_5);
    let v764_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v764_2));
    drop(v764_2);
    let v764_10: Space = if map_kernels::has_head(&(v764_9)) { singleton(&[]) } else { Space::new() };
    drop(v764_9);
    let v764_13: Space = if (v764_10).is_empty() { Space::new() } else {
      let v775_6: Path = concat_path(&(*p0),&(v763_27_head));
      let v775_11: Space = map_kernels::unwrap(&(v763_23),&(v763_27_head));
      let mut v775_12 = Space::new();
      let mut v775_12_cursor = (v763_27_tail).read_zipper();
      for v775_12_byte in v775_12_cursor.child_mask().iter() {
        v775_12_cursor.descend_to_byte(v775_12_byte);
        {
        let v775_12_tail = v775_12_cursor.fork_read_zipper();
        let v775_12_head = Path::from_slice(&[v775_12_byte]);
        let v776_2: Space = singleton(&(v775_12_head));
        let v776_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v776_2));
        let v776_4: Space = if map_kernels::has_head(&(v776_3)) { singleton(&[]) } else { Space::new() };
        drop(v776_3);
        let v776_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v776_4));
        drop(v776_4);
        let v776_8: Space = if (v776_5).is_empty() { Space::new() } else {
          let v777_6: Path = concat_path(&(v775_6),&(v775_12_head));
          let mut v777_7 = Space::new();
          let mut v777_7_cursor = (v775_12_tail).read_zipper();
          for v777_7_byte in v777_7_cursor.child_mask().iter() {
            v777_7_cursor.descend_to_byte(v777_7_byte);
            {
            let v777_7_tail = v777_7_cursor.fork_read_zipper();
            let v777_7_head = Path::from_slice(&[v777_7_byte]);
            let v778_2: Space = singleton(&(v777_7_head));
            let v778_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v778_2));
            let v778_4: Space = if map_kernels::has_head(&(v778_3)) { singleton(&[]) } else { Space::new() };
            drop(v778_3);
            let v778_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v778_4));
            drop(v778_4);
            let v778_8: Space = if (v778_5).is_empty() { Space::new() } else {
              let v779_6: Path = concat_path(&(v777_6),&(v777_7_head));
              let v779_7: Space = routine_61(c, &(v779_6), &(v777_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v778_5),&(v779_7))
            };
            drop(v778_5);
            let v778_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v778_2));
            drop(v778_2);
            let v778_10: Space = if map_kernels::has_head(&(v778_9)) { singleton(&[]) } else { Space::new() };
            drop(v778_9);
            let v778_12: Space = if (v778_10).is_empty() { Space::new() } else {
              let v780_6: Path = concat_path(&(v777_6),&(v777_7_head));
              let v780_11: Space = routine_62(c, &(v780_6), &(v777_7_tail).make_space(), &(*s1));
              drop(v780_6);
              map_map_kernels::compose(&(v778_10),&(v780_11))
            };
            drop(v778_10);
            let v778_13: Space = map_map_kernels::unite(&(v778_8),&(v778_12));
            v777_7.join_into((v778_13).clone());
            }
            v777_7_cursor.ascend(1);
          }
          drop(v777_7_cursor);
          drop(v777_6);
          map_map_kernels::compose(&(v776_5),&(v777_7))
        };
        drop(v776_5);
        let v776_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v776_2));
        drop(v776_2);
        let v776_10: Space = if map_kernels::has_head(&(v776_9)) { singleton(&[]) } else { Space::new() };
        drop(v776_9);
        let v776_13: Space = if (v776_10).is_empty() { Space::new() } else {
          let v781_11: Space = map_kernels::unwrap(&(v775_11),&(v775_12_head));
          let v781_12: Space = map_map_kernels::subtract(&(v781_11),&(*CONSTANT_5));
          drop(v781_11);
          map_map_kernels::compose(&(v776_10),&(v781_12))
        };
        drop(v776_10);
        let v776_14: Space = map_map_kernels::unite(&(v776_8),&(v776_13));
        drop(v776_13);
        v775_12.join_into((v776_14).clone());
        }
        v775_12_cursor.ascend(1);
      }
      drop(v775_12_cursor);
      drop(v775_6);
      drop(v775_11);
      map_map_kernels::compose(&(v764_10),&(v775_12))
    };
    drop(v764_10);
    let v764_14: Space = map_map_kernels::unite(&(v764_8),&(v764_13));
    v763_27.join_into((v764_14).clone());
    }
    v763_27_cursor.ascend(1);
  }
  drop(v763_27_cursor);
  drop(v763_23);
  (v763_27).clone()
}

fn routine_43(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v782_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v782_9: Space = map_kernels::unwrap(&(v782_7),&(*CONSTANT_4));
  drop(v782_7);
  let v782_10: Space = map_kernels::unwrap(&(v782_9),&(*p0));
  drop(v782_9);
  let mut v782_21 = Space::new();
  let mut v782_21_cursor = (*s0).read_zipper();
  for v782_21_byte in v782_21_cursor.child_mask().iter() {
    v782_21_cursor.descend_to_byte(v782_21_byte);
    {
    let v782_21_tail = v782_21_cursor.fork_read_zipper();
    let v782_21_head = Path::from_slice(&[v782_21_byte]);
    let v783_2: Space = singleton(&(v782_21_head));
    let v783_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v783_2));
    let v783_4: Space = if map_kernels::has_head(&(v783_3)) { singleton(&[]) } else { Space::new() };
    drop(v783_3);
    let v783_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v783_4));
    drop(v783_4);
    let v783_8: Space = if (v783_5).is_empty() { Space::new() } else {
      let v784_6: Path = concat_path(&(*p0),&(v782_21_head));
      let mut v784_7 = Space::new();
      let mut v784_7_cursor = (v782_21_tail).read_zipper();
      for v784_7_byte in v784_7_cursor.child_mask().iter() {
        v784_7_cursor.descend_to_byte(v784_7_byte);
        {
        let v784_7_tail = v784_7_cursor.fork_read_zipper();
        let v784_7_head = Path::from_slice(&[v784_7_byte]);
        let v785_2: Space = singleton(&(v784_7_head));
        let v785_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v785_2));
        let v785_4: Space = if map_kernels::has_head(&(v785_3)) { singleton(&[]) } else { Space::new() };
        drop(v785_3);
        let v785_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v785_4));
        drop(v785_4);
        let v785_8: Space = if (v785_5).is_empty() { Space::new() } else {
          let v786_6: Path = concat_path(&(v784_6),&(v784_7_head));
          let mut v786_7 = Space::new();
          let mut v786_7_cursor = (v784_7_tail).read_zipper();
          for v786_7_byte in v786_7_cursor.child_mask().iter() {
            v786_7_cursor.descend_to_byte(v786_7_byte);
            {
            let v786_7_tail = v786_7_cursor.fork_read_zipper();
            let v786_7_head = Path::from_slice(&[v786_7_byte]);
            let v787_2: Space = singleton(&(v786_7_head));
            let v787_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v787_2));
            let v787_4: Space = if map_kernels::has_head(&(v787_3)) { singleton(&[]) } else { Space::new() };
            drop(v787_3);
            let v787_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v787_4));
            drop(v787_4);
            let v787_8: Space = if (v787_5).is_empty() { Space::new() } else {
              let v788_6: Path = concat_path(&(v786_6),&(v786_7_head));
              let v788_7: Space = routine_61(c, &(v788_6), &(v786_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v787_5),&(v788_7))
            };
            drop(v787_5);
            let v787_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v787_2));
            drop(v787_2);
            let v787_10: Space = if map_kernels::has_head(&(v787_9)) { singleton(&[]) } else { Space::new() };
            drop(v787_9);
            let v787_12: Space = if (v787_10).is_empty() { Space::new() } else {
              let v789_6: Path = concat_path(&(v786_6),&(v786_7_head));
              let v789_11: Space = routine_62(c, &(v789_6), &(v786_7_tail).make_space(), &(*s1));
              drop(v789_6);
              map_map_kernels::compose(&(v787_10),&(v789_11))
            };
            drop(v787_10);
            let v787_13: Space = map_map_kernels::unite(&(v787_8),&(v787_12));
            v786_7.join_into((v787_13).clone());
            }
            v786_7_cursor.ascend(1);
          }
          drop(v786_7_cursor);
          map_map_kernels::compose(&(v785_5),&(v786_7))
        };
        drop(v785_5);
        let v785_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v785_2));
        drop(v785_2);
        let v785_10: Space = if map_kernels::has_head(&(v785_9)) { singleton(&[]) } else { Space::new() };
        drop(v785_9);
        let v785_12: Space = if (v785_10).is_empty() { Space::new() } else {
          let v790_6: Path = concat_path(&(v784_6),&(v784_7_head));
          let mut v790_11 = Space::new();
          let mut v790_11_cursor = (v784_7_tail).read_zipper();
          for v790_11_byte in v790_11_cursor.child_mask().iter() {
            v790_11_cursor.descend_to_byte(v790_11_byte);
            {
            let v790_11_tail = v790_11_cursor.fork_read_zipper();
            let v790_11_head = Path::from_slice(&[v790_11_byte]);
            let v791_2: Space = singleton(&(v790_11_head));
            let v791_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v791_2));
            let v791_4: Space = if map_kernels::has_head(&(v791_3)) { singleton(&[]) } else { Space::new() };
            drop(v791_3);
            let v791_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v791_4));
            drop(v791_4);
            let v791_8: Space = if (v791_5).is_empty() { Space::new() } else {
              let v792_6: Path = concat_path(&(v790_6),&(v790_11_head));
              let v792_7: Space = routine_61(c, &(v792_6), &(v790_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v791_5),&(v792_7))
            };
            drop(v791_5);
            let v791_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v791_2));
            drop(v791_2);
            let v791_10: Space = if map_kernels::has_head(&(v791_9)) { singleton(&[]) } else { Space::new() };
            drop(v791_9);
            let v791_12: Space = if (v791_10).is_empty() { Space::new() } else {
              let v793_6: Path = concat_path(&(v790_6),&(v790_11_head));
              let v793_11: Space = routine_44(c, &(v793_6), &(v790_11_tail).make_space(), &(*s1));
              drop(v793_6);
              map_map_kernels::compose(&(v791_10),&(v793_11))
            };
            drop(v791_10);
            let v791_13: Space = map_map_kernels::unite(&(v791_8),&(v791_12));
            v790_11.join_into((v791_13).clone());
            }
            v790_11_cursor.ascend(1);
          }
          drop(v790_11_cursor);
          drop(v790_6);
          map_map_kernels::compose(&(v785_10),&(v790_11))
        };
        drop(v785_10);
        let v785_13: Space = map_map_kernels::unite(&(v785_8),&(v785_12));
        v784_7.join_into((v785_13).clone());
        }
        v784_7_cursor.ascend(1);
      }
      drop(v784_7_cursor);
      drop(v784_6);
      map_map_kernels::compose(&(v783_5),&(v784_7))
    };
    drop(v783_5);
    let v783_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v783_2));
    drop(v783_2);
    let v783_10: Space = if map_kernels::has_head(&(v783_9)) { singleton(&[]) } else { Space::new() };
    drop(v783_9);
    let v783_13: Space = if (v783_10).is_empty() { Space::new() } else {
      let v794_11: Space = map_kernels::unwrap(&(v782_10),&(v782_21_head));
      let v794_12: Space = map_map_kernels::subtract(&(v794_11),&(*CONSTANT_5));
      drop(v794_11);
      map_map_kernels::compose(&(v783_10),&(v794_12))
    };
    drop(v783_10);
    let v783_14: Space = map_map_kernels::unite(&(v783_8),&(v783_13));
    drop(v783_13);
    v782_21.join_into((v783_14).clone());
    }
    v782_21_cursor.ascend(1);
  }
  drop(v782_21_cursor);
  drop(v782_10);
  (v782_21).clone()
}

fn routine_44(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v795_4: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v795_6: Space = map_kernels::unwrap(&(v795_4),&(*CONSTANT_4));
  drop(v795_4);
  let v795_7: Space = map_kernels::unwrap(&(v795_6),&(*p0));
  drop(v795_6);
  let v795_9: Space = map_map_kernels::subtract(&(v795_7),&(*CONSTANT_5));
  drop(v795_7);
  (v795_9).clone()
}

fn routine_45(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v796_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v796_22: Space = map_kernels::unwrap(&(v796_21),&(*CONSTANT_4));
  drop(v796_21);
  let v796_23: Space = map_kernels::unwrap(&(v796_22),&(*p0));
  drop(v796_22);
  let mut v796_27 = Space::new();
  let mut v796_27_cursor = (*s0).read_zipper();
  for v796_27_byte in v796_27_cursor.child_mask().iter() {
    v796_27_cursor.descend_to_byte(v796_27_byte);
    {
    let v796_27_tail = v796_27_cursor.fork_read_zipper();
    let v796_27_head = Path::from_slice(&[v796_27_byte]);
    let v797_2: Space = singleton(&(v796_27_head));
    let v797_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v797_2));
    let v797_4: Space = if map_kernels::has_head(&(v797_3)) { singleton(&[]) } else { Space::new() };
    drop(v797_3);
    let v797_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v797_4));
    drop(v797_4);
    let v797_8: Space = if (v797_5).is_empty() { Space::new() } else {
      let v798_6: Path = concat_path(&(*p0),&(v796_27_head));
      let mut v798_7 = Space::new();
      let mut v798_7_cursor = (v796_27_tail).read_zipper();
      for v798_7_byte in v798_7_cursor.child_mask().iter() {
        v798_7_cursor.descend_to_byte(v798_7_byte);
        {
        let v798_7_tail = v798_7_cursor.fork_read_zipper();
        let v798_7_head = Path::from_slice(&[v798_7_byte]);
        let v799_2: Space = singleton(&(v798_7_head));
        let v799_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v799_2));
        let v799_4: Space = if map_kernels::has_head(&(v799_3)) { singleton(&[]) } else { Space::new() };
        drop(v799_3);
        let v799_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v799_4));
        drop(v799_4);
        let v799_8: Space = if (v799_5).is_empty() { Space::new() } else {
          let v800_6: Path = concat_path(&(v798_6),&(v798_7_head));
          let mut v800_7 = Space::new();
          let mut v800_7_cursor = (v798_7_tail).read_zipper();
          for v800_7_byte in v800_7_cursor.child_mask().iter() {
            v800_7_cursor.descend_to_byte(v800_7_byte);
            {
            let v800_7_tail = v800_7_cursor.fork_read_zipper();
            let v800_7_head = Path::from_slice(&[v800_7_byte]);
            let v801_2: Space = singleton(&(v800_7_head));
            let v801_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v801_2));
            let v801_4: Space = if map_kernels::has_head(&(v801_3)) { singleton(&[]) } else { Space::new() };
            drop(v801_3);
            let v801_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v801_4));
            drop(v801_4);
            let v801_8: Space = if (v801_5).is_empty() { Space::new() } else {
              let v802_6: Path = concat_path(&(v800_6),&(v800_7_head));
              let v802_7: Space = routine_63(c, &(v802_6), &(v800_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v801_5),&(v802_7))
            };
            drop(v801_5);
            let v801_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v801_2));
            drop(v801_2);
            let v801_10: Space = if map_kernels::has_head(&(v801_9)) { singleton(&[]) } else { Space::new() };
            drop(v801_9);
            let v801_12: Space = if (v801_10).is_empty() { Space::new() } else {
              let v803_6: Path = concat_path(&(v800_6),&(v800_7_head));
              let v803_11: Space = routine_64(c, &(v803_6), &(v800_7_tail).make_space(), &(*s1));
              drop(v803_6);
              map_map_kernels::compose(&(v801_10),&(v803_11))
            };
            drop(v801_10);
            let v801_13: Space = map_map_kernels::unite(&(v801_8),&(v801_12));
            v800_7.join_into((v801_13).clone());
            }
            v800_7_cursor.ascend(1);
          }
          drop(v800_7_cursor);
          map_map_kernels::compose(&(v799_5),&(v800_7))
        };
        drop(v799_5);
        let v799_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v799_2));
        drop(v799_2);
        let v799_10: Space = if map_kernels::has_head(&(v799_9)) { singleton(&[]) } else { Space::new() };
        drop(v799_9);
        let v799_12: Space = if (v799_10).is_empty() { Space::new() } else {
          let v804_6: Path = concat_path(&(v798_6),&(v798_7_head));
          let mut v804_11 = Space::new();
          let mut v804_11_cursor = (v798_7_tail).read_zipper();
          for v804_11_byte in v804_11_cursor.child_mask().iter() {
            v804_11_cursor.descend_to_byte(v804_11_byte);
            {
            let v804_11_tail = v804_11_cursor.fork_read_zipper();
            let v804_11_head = Path::from_slice(&[v804_11_byte]);
            let v805_2: Space = singleton(&(v804_11_head));
            let v805_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v805_2));
            let v805_4: Space = if map_kernels::has_head(&(v805_3)) { singleton(&[]) } else { Space::new() };
            drop(v805_3);
            let v805_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v805_4));
            drop(v805_4);
            let v805_8: Space = if (v805_5).is_empty() { Space::new() } else {
              let v806_6: Path = concat_path(&(v804_6),&(v804_11_head));
              let v806_7: Space = routine_63(c, &(v806_6), &(v804_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v805_5),&(v806_7))
            };
            drop(v805_5);
            let v805_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v805_2));
            drop(v805_2);
            let v805_10: Space = if map_kernels::has_head(&(v805_9)) { singleton(&[]) } else { Space::new() };
            drop(v805_9);
            let v805_12: Space = if (v805_10).is_empty() { Space::new() } else {
              let v807_6: Path = concat_path(&(v804_6),&(v804_11_head));
              let v807_11: Space = routine_44(c, &(v807_6), &(v804_11_tail).make_space(), &(*s1));
              drop(v807_6);
              map_map_kernels::compose(&(v805_10),&(v807_11))
            };
            drop(v805_10);
            let v805_13: Space = map_map_kernels::unite(&(v805_8),&(v805_12));
            v804_11.join_into((v805_13).clone());
            }
            v804_11_cursor.ascend(1);
          }
          drop(v804_11_cursor);
          drop(v804_6);
          map_map_kernels::compose(&(v799_10),&(v804_11))
        };
        drop(v799_10);
        let v799_13: Space = map_map_kernels::unite(&(v799_8),&(v799_12));
        v798_7.join_into((v799_13).clone());
        }
        v798_7_cursor.ascend(1);
      }
      drop(v798_7_cursor);
      map_map_kernels::compose(&(v797_5),&(v798_7))
    };
    drop(v797_5);
    let v797_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v797_2));
    drop(v797_2);
    let v797_10: Space = if map_kernels::has_head(&(v797_9)) { singleton(&[]) } else { Space::new() };
    drop(v797_9);
    let v797_13: Space = if (v797_10).is_empty() { Space::new() } else {
      let v808_6: Path = concat_path(&(*p0),&(v796_27_head));
      let v808_11: Space = map_kernels::unwrap(&(v796_23),&(v796_27_head));
      let mut v808_12 = Space::new();
      let mut v808_12_cursor = (v796_27_tail).read_zipper();
      for v808_12_byte in v808_12_cursor.child_mask().iter() {
        v808_12_cursor.descend_to_byte(v808_12_byte);
        {
        let v808_12_tail = v808_12_cursor.fork_read_zipper();
        let v808_12_head = Path::from_slice(&[v808_12_byte]);
        let v809_2: Space = singleton(&(v808_12_head));
        let v809_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v809_2));
        let v809_4: Space = if map_kernels::has_head(&(v809_3)) { singleton(&[]) } else { Space::new() };
        drop(v809_3);
        let v809_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v809_4));
        drop(v809_4);
        let v809_8: Space = if (v809_5).is_empty() { Space::new() } else {
          let v810_6: Path = concat_path(&(v808_6),&(v808_12_head));
          let mut v810_7 = Space::new();
          let mut v810_7_cursor = (v808_12_tail).read_zipper();
          for v810_7_byte in v810_7_cursor.child_mask().iter() {
            v810_7_cursor.descend_to_byte(v810_7_byte);
            {
            let v810_7_tail = v810_7_cursor.fork_read_zipper();
            let v810_7_head = Path::from_slice(&[v810_7_byte]);
            let v811_2: Space = singleton(&(v810_7_head));
            let v811_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v811_2));
            let v811_4: Space = if map_kernels::has_head(&(v811_3)) { singleton(&[]) } else { Space::new() };
            drop(v811_3);
            let v811_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v811_4));
            drop(v811_4);
            let v811_8: Space = if (v811_5).is_empty() { Space::new() } else {
              let v812_6: Path = concat_path(&(v810_6),&(v810_7_head));
              let v812_7: Space = routine_63(c, &(v812_6), &(v810_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v811_5),&(v812_7))
            };
            drop(v811_5);
            let v811_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v811_2));
            drop(v811_2);
            let v811_10: Space = if map_kernels::has_head(&(v811_9)) { singleton(&[]) } else { Space::new() };
            drop(v811_9);
            let v811_12: Space = if (v811_10).is_empty() { Space::new() } else {
              let v813_6: Path = concat_path(&(v810_6),&(v810_7_head));
              let v813_11: Space = routine_64(c, &(v813_6), &(v810_7_tail).make_space(), &(*s1));
              drop(v813_6);
              map_map_kernels::compose(&(v811_10),&(v813_11))
            };
            drop(v811_10);
            let v811_13: Space = map_map_kernels::unite(&(v811_8),&(v811_12));
            v810_7.join_into((v811_13).clone());
            }
            v810_7_cursor.ascend(1);
          }
          drop(v810_7_cursor);
          drop(v810_6);
          map_map_kernels::compose(&(v809_5),&(v810_7))
        };
        drop(v809_5);
        let v809_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v809_2));
        drop(v809_2);
        let v809_10: Space = if map_kernels::has_head(&(v809_9)) { singleton(&[]) } else { Space::new() };
        drop(v809_9);
        let v809_13: Space = if (v809_10).is_empty() { Space::new() } else {
          let v814_11: Space = map_kernels::unwrap(&(v808_11),&(v808_12_head));
          let v814_12: Space = map_map_kernels::subtract(&(v814_11),&(*CONSTANT_5));
          drop(v814_11);
          map_map_kernels::compose(&(v809_10),&(v814_12))
        };
        drop(v809_10);
        let v809_14: Space = map_map_kernels::unite(&(v809_8),&(v809_13));
        drop(v809_13);
        v808_12.join_into((v809_14).clone());
        }
        v808_12_cursor.ascend(1);
      }
      drop(v808_12_cursor);
      drop(v808_6);
      drop(v808_11);
      map_map_kernels::compose(&(v797_10),&(v808_12))
    };
    drop(v797_10);
    let v797_14: Space = map_map_kernels::unite(&(v797_8),&(v797_13));
    v796_27.join_into((v797_14).clone());
    }
    v796_27_cursor.ascend(1);
  }
  drop(v796_27_cursor);
  drop(v796_23);
  (v796_27).clone()
}

fn routine_46(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v815_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v815_9: Space = map_kernels::unwrap(&(v815_7),&(*CONSTANT_4));
  drop(v815_7);
  let v815_10: Space = map_kernels::unwrap(&(v815_9),&(*p0));
  drop(v815_9);
  let mut v815_21 = Space::new();
  let mut v815_21_cursor = (*s0).read_zipper();
  for v815_21_byte in v815_21_cursor.child_mask().iter() {
    v815_21_cursor.descend_to_byte(v815_21_byte);
    {
    let v815_21_tail = v815_21_cursor.fork_read_zipper();
    let v815_21_head = Path::from_slice(&[v815_21_byte]);
    let v816_2: Space = singleton(&(v815_21_head));
    let v816_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v816_2));
    let v816_4: Space = if map_kernels::has_head(&(v816_3)) { singleton(&[]) } else { Space::new() };
    drop(v816_3);
    let v816_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v816_4));
    drop(v816_4);
    let v816_8: Space = if (v816_5).is_empty() { Space::new() } else {
      let v817_6: Path = concat_path(&(*p0),&(v815_21_head));
      let mut v817_7 = Space::new();
      let mut v817_7_cursor = (v815_21_tail).read_zipper();
      for v817_7_byte in v817_7_cursor.child_mask().iter() {
        v817_7_cursor.descend_to_byte(v817_7_byte);
        {
        let v817_7_tail = v817_7_cursor.fork_read_zipper();
        let v817_7_head = Path::from_slice(&[v817_7_byte]);
        let v818_2: Space = singleton(&(v817_7_head));
        let v818_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v818_2));
        let v818_4: Space = if map_kernels::has_head(&(v818_3)) { singleton(&[]) } else { Space::new() };
        drop(v818_3);
        let v818_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v818_4));
        drop(v818_4);
        let v818_8: Space = if (v818_5).is_empty() { Space::new() } else {
          let v819_6: Path = concat_path(&(v817_6),&(v817_7_head));
          let mut v819_7 = Space::new();
          let mut v819_7_cursor = (v817_7_tail).read_zipper();
          for v819_7_byte in v819_7_cursor.child_mask().iter() {
            v819_7_cursor.descend_to_byte(v819_7_byte);
            {
            let v819_7_tail = v819_7_cursor.fork_read_zipper();
            let v819_7_head = Path::from_slice(&[v819_7_byte]);
            let v820_2: Space = singleton(&(v819_7_head));
            let v820_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v820_2));
            let v820_4: Space = if map_kernels::has_head(&(v820_3)) { singleton(&[]) } else { Space::new() };
            drop(v820_3);
            let v820_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v820_4));
            drop(v820_4);
            let v820_8: Space = if (v820_5).is_empty() { Space::new() } else {
              let v821_6: Path = concat_path(&(v819_6),&(v819_7_head));
              let v821_7: Space = routine_63(c, &(v821_6), &(v819_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v820_5),&(v821_7))
            };
            drop(v820_5);
            let v820_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v820_2));
            drop(v820_2);
            let v820_10: Space = if map_kernels::has_head(&(v820_9)) { singleton(&[]) } else { Space::new() };
            drop(v820_9);
            let v820_12: Space = if (v820_10).is_empty() { Space::new() } else {
              let v822_6: Path = concat_path(&(v819_6),&(v819_7_head));
              let v822_11: Space = routine_64(c, &(v822_6), &(v819_7_tail).make_space(), &(*s1));
              drop(v822_6);
              map_map_kernels::compose(&(v820_10),&(v822_11))
            };
            drop(v820_10);
            let v820_13: Space = map_map_kernels::unite(&(v820_8),&(v820_12));
            v819_7.join_into((v820_13).clone());
            }
            v819_7_cursor.ascend(1);
          }
          drop(v819_7_cursor);
          map_map_kernels::compose(&(v818_5),&(v819_7))
        };
        drop(v818_5);
        let v818_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v818_2));
        drop(v818_2);
        let v818_10: Space = if map_kernels::has_head(&(v818_9)) { singleton(&[]) } else { Space::new() };
        drop(v818_9);
        let v818_12: Space = if (v818_10).is_empty() { Space::new() } else {
          let v823_6: Path = concat_path(&(v817_6),&(v817_7_head));
          let mut v823_11 = Space::new();
          let mut v823_11_cursor = (v817_7_tail).read_zipper();
          for v823_11_byte in v823_11_cursor.child_mask().iter() {
            v823_11_cursor.descend_to_byte(v823_11_byte);
            {
            let v823_11_tail = v823_11_cursor.fork_read_zipper();
            let v823_11_head = Path::from_slice(&[v823_11_byte]);
            let v824_2: Space = singleton(&(v823_11_head));
            let v824_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v824_2));
            let v824_4: Space = if map_kernels::has_head(&(v824_3)) { singleton(&[]) } else { Space::new() };
            drop(v824_3);
            let v824_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v824_4));
            drop(v824_4);
            let v824_8: Space = if (v824_5).is_empty() { Space::new() } else {
              let v825_6: Path = concat_path(&(v823_6),&(v823_11_head));
              let v825_7: Space = routine_63(c, &(v825_6), &(v823_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v824_5),&(v825_7))
            };
            drop(v824_5);
            let v824_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v824_2));
            drop(v824_2);
            let v824_10: Space = if map_kernels::has_head(&(v824_9)) { singleton(&[]) } else { Space::new() };
            drop(v824_9);
            let v824_12: Space = if (v824_10).is_empty() { Space::new() } else {
              let v826_6: Path = concat_path(&(v823_6),&(v823_11_head));
              let v826_11: Space = routine_44(c, &(v826_6), &(v823_11_tail).make_space(), &(*s1));
              drop(v826_6);
              map_map_kernels::compose(&(v824_10),&(v826_11))
            };
            drop(v824_10);
            let v824_13: Space = map_map_kernels::unite(&(v824_8),&(v824_12));
            v823_11.join_into((v824_13).clone());
            }
            v823_11_cursor.ascend(1);
          }
          drop(v823_11_cursor);
          drop(v823_6);
          map_map_kernels::compose(&(v818_10),&(v823_11))
        };
        drop(v818_10);
        let v818_13: Space = map_map_kernels::unite(&(v818_8),&(v818_12));
        v817_7.join_into((v818_13).clone());
        }
        v817_7_cursor.ascend(1);
      }
      drop(v817_7_cursor);
      drop(v817_6);
      map_map_kernels::compose(&(v816_5),&(v817_7))
    };
    drop(v816_5);
    let v816_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v816_2));
    drop(v816_2);
    let v816_10: Space = if map_kernels::has_head(&(v816_9)) { singleton(&[]) } else { Space::new() };
    drop(v816_9);
    let v816_13: Space = if (v816_10).is_empty() { Space::new() } else {
      let v827_11: Space = map_kernels::unwrap(&(v815_10),&(v815_21_head));
      let v827_12: Space = map_map_kernels::subtract(&(v827_11),&(*CONSTANT_5));
      drop(v827_11);
      map_map_kernels::compose(&(v816_10),&(v827_12))
    };
    drop(v816_10);
    let v816_14: Space = map_map_kernels::unite(&(v816_8),&(v816_13));
    drop(v816_13);
    v815_21.join_into((v816_14).clone());
    }
    v815_21_cursor.ascend(1);
  }
  drop(v815_21_cursor);
  drop(v815_10);
  (v815_21).clone()
}

fn routine_47(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v828_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v828_22: Space = map_kernels::unwrap(&(v828_21),&(*CONSTANT_4));
  drop(v828_21);
  let v828_23: Space = map_kernels::unwrap(&(v828_22),&(*p0));
  drop(v828_22);
  let mut v828_27 = Space::new();
  let mut v828_27_cursor = (*s0).read_zipper();
  for v828_27_byte in v828_27_cursor.child_mask().iter() {
    v828_27_cursor.descend_to_byte(v828_27_byte);
    {
    let v828_27_tail = v828_27_cursor.fork_read_zipper();
    let v828_27_head = Path::from_slice(&[v828_27_byte]);
    let v829_2: Space = singleton(&(v828_27_head));
    let v829_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v829_2));
    let v829_4: Space = if map_kernels::has_head(&(v829_3)) { singleton(&[]) } else { Space::new() };
    drop(v829_3);
    let v829_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v829_4));
    drop(v829_4);
    let v829_8: Space = if (v829_5).is_empty() { Space::new() } else {
      let v830_6: Path = concat_path(&(*p0),&(v828_27_head));
      let mut v830_7 = Space::new();
      let mut v830_7_cursor = (v828_27_tail).read_zipper();
      for v830_7_byte in v830_7_cursor.child_mask().iter() {
        v830_7_cursor.descend_to_byte(v830_7_byte);
        {
        let v830_7_tail = v830_7_cursor.fork_read_zipper();
        let v830_7_head = Path::from_slice(&[v830_7_byte]);
        let v831_2: Space = singleton(&(v830_7_head));
        let v831_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v831_2));
        let v831_4: Space = if map_kernels::has_head(&(v831_3)) { singleton(&[]) } else { Space::new() };
        drop(v831_3);
        let v831_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v831_4));
        drop(v831_4);
        let v831_8: Space = if (v831_5).is_empty() { Space::new() } else {
          let v832_6: Path = concat_path(&(v830_6),&(v830_7_head));
          let mut v832_7 = Space::new();
          let mut v832_7_cursor = (v830_7_tail).read_zipper();
          for v832_7_byte in v832_7_cursor.child_mask().iter() {
            v832_7_cursor.descend_to_byte(v832_7_byte);
            {
            let v832_7_tail = v832_7_cursor.fork_read_zipper();
            let v832_7_head = Path::from_slice(&[v832_7_byte]);
            let v833_2: Space = singleton(&(v832_7_head));
            let v833_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v833_2));
            let v833_4: Space = if map_kernels::has_head(&(v833_3)) { singleton(&[]) } else { Space::new() };
            drop(v833_3);
            let v833_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v833_4));
            drop(v833_4);
            let v833_8: Space = if (v833_5).is_empty() { Space::new() } else {
              let v834_6: Path = concat_path(&(v832_6),&(v832_7_head));
              let v834_7: Space = routine_65(c, &(v834_6), &(v832_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v833_5),&(v834_7))
            };
            drop(v833_5);
            let v833_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v833_2));
            drop(v833_2);
            let v833_10: Space = if map_kernels::has_head(&(v833_9)) { singleton(&[]) } else { Space::new() };
            drop(v833_9);
            let v833_12: Space = if (v833_10).is_empty() { Space::new() } else {
              let v835_6: Path = concat_path(&(v832_6),&(v832_7_head));
              let v835_11: Space = routine_66(c, &(v835_6), &(v832_7_tail).make_space(), &(*s1));
              drop(v835_6);
              map_map_kernels::compose(&(v833_10),&(v835_11))
            };
            drop(v833_10);
            let v833_13: Space = map_map_kernels::unite(&(v833_8),&(v833_12));
            v832_7.join_into((v833_13).clone());
            }
            v832_7_cursor.ascend(1);
          }
          drop(v832_7_cursor);
          map_map_kernels::compose(&(v831_5),&(v832_7))
        };
        drop(v831_5);
        let v831_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v831_2));
        drop(v831_2);
        let v831_10: Space = if map_kernels::has_head(&(v831_9)) { singleton(&[]) } else { Space::new() };
        drop(v831_9);
        let v831_12: Space = if (v831_10).is_empty() { Space::new() } else {
          let v836_6: Path = concat_path(&(v830_6),&(v830_7_head));
          let mut v836_11 = Space::new();
          let mut v836_11_cursor = (v830_7_tail).read_zipper();
          for v836_11_byte in v836_11_cursor.child_mask().iter() {
            v836_11_cursor.descend_to_byte(v836_11_byte);
            {
            let v836_11_tail = v836_11_cursor.fork_read_zipper();
            let v836_11_head = Path::from_slice(&[v836_11_byte]);
            let v837_2: Space = singleton(&(v836_11_head));
            let v837_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v837_2));
            let v837_4: Space = if map_kernels::has_head(&(v837_3)) { singleton(&[]) } else { Space::new() };
            drop(v837_3);
            let v837_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v837_4));
            drop(v837_4);
            let v837_8: Space = if (v837_5).is_empty() { Space::new() } else {
              let v838_6: Path = concat_path(&(v836_6),&(v836_11_head));
              let v838_7: Space = routine_65(c, &(v838_6), &(v836_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v837_5),&(v838_7))
            };
            drop(v837_5);
            let v837_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v837_2));
            drop(v837_2);
            let v837_10: Space = if map_kernels::has_head(&(v837_9)) { singleton(&[]) } else { Space::new() };
            drop(v837_9);
            let v837_12: Space = if (v837_10).is_empty() { Space::new() } else {
              let v839_6: Path = concat_path(&(v836_6),&(v836_11_head));
              let v839_11: Space = routine_44(c, &(v839_6), &(v836_11_tail).make_space(), &(*s1));
              drop(v839_6);
              map_map_kernels::compose(&(v837_10),&(v839_11))
            };
            drop(v837_10);
            let v837_13: Space = map_map_kernels::unite(&(v837_8),&(v837_12));
            v836_11.join_into((v837_13).clone());
            }
            v836_11_cursor.ascend(1);
          }
          drop(v836_11_cursor);
          drop(v836_6);
          map_map_kernels::compose(&(v831_10),&(v836_11))
        };
        drop(v831_10);
        let v831_13: Space = map_map_kernels::unite(&(v831_8),&(v831_12));
        v830_7.join_into((v831_13).clone());
        }
        v830_7_cursor.ascend(1);
      }
      drop(v830_7_cursor);
      map_map_kernels::compose(&(v829_5),&(v830_7))
    };
    drop(v829_5);
    let v829_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v829_2));
    drop(v829_2);
    let v829_10: Space = if map_kernels::has_head(&(v829_9)) { singleton(&[]) } else { Space::new() };
    drop(v829_9);
    let v829_13: Space = if (v829_10).is_empty() { Space::new() } else {
      let v840_6: Path = concat_path(&(*p0),&(v828_27_head));
      let v840_11: Space = map_kernels::unwrap(&(v828_23),&(v828_27_head));
      let mut v840_12 = Space::new();
      let mut v840_12_cursor = (v828_27_tail).read_zipper();
      for v840_12_byte in v840_12_cursor.child_mask().iter() {
        v840_12_cursor.descend_to_byte(v840_12_byte);
        {
        let v840_12_tail = v840_12_cursor.fork_read_zipper();
        let v840_12_head = Path::from_slice(&[v840_12_byte]);
        let v841_2: Space = singleton(&(v840_12_head));
        let v841_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v841_2));
        let v841_4: Space = if map_kernels::has_head(&(v841_3)) { singleton(&[]) } else { Space::new() };
        drop(v841_3);
        let v841_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v841_4));
        drop(v841_4);
        let v841_8: Space = if (v841_5).is_empty() { Space::new() } else {
          let v842_6: Path = concat_path(&(v840_6),&(v840_12_head));
          let mut v842_7 = Space::new();
          let mut v842_7_cursor = (v840_12_tail).read_zipper();
          for v842_7_byte in v842_7_cursor.child_mask().iter() {
            v842_7_cursor.descend_to_byte(v842_7_byte);
            {
            let v842_7_tail = v842_7_cursor.fork_read_zipper();
            let v842_7_head = Path::from_slice(&[v842_7_byte]);
            let v843_2: Space = singleton(&(v842_7_head));
            let v843_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v843_2));
            let v843_4: Space = if map_kernels::has_head(&(v843_3)) { singleton(&[]) } else { Space::new() };
            drop(v843_3);
            let v843_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v843_4));
            drop(v843_4);
            let v843_8: Space = if (v843_5).is_empty() { Space::new() } else {
              let v844_6: Path = concat_path(&(v842_6),&(v842_7_head));
              let v844_7: Space = routine_65(c, &(v844_6), &(v842_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v843_5),&(v844_7))
            };
            drop(v843_5);
            let v843_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v843_2));
            drop(v843_2);
            let v843_10: Space = if map_kernels::has_head(&(v843_9)) { singleton(&[]) } else { Space::new() };
            drop(v843_9);
            let v843_12: Space = if (v843_10).is_empty() { Space::new() } else {
              let v845_6: Path = concat_path(&(v842_6),&(v842_7_head));
              let v845_11: Space = routine_66(c, &(v845_6), &(v842_7_tail).make_space(), &(*s1));
              drop(v845_6);
              map_map_kernels::compose(&(v843_10),&(v845_11))
            };
            drop(v843_10);
            let v843_13: Space = map_map_kernels::unite(&(v843_8),&(v843_12));
            v842_7.join_into((v843_13).clone());
            }
            v842_7_cursor.ascend(1);
          }
          drop(v842_7_cursor);
          drop(v842_6);
          map_map_kernels::compose(&(v841_5),&(v842_7))
        };
        drop(v841_5);
        let v841_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v841_2));
        drop(v841_2);
        let v841_10: Space = if map_kernels::has_head(&(v841_9)) { singleton(&[]) } else { Space::new() };
        drop(v841_9);
        let v841_13: Space = if (v841_10).is_empty() { Space::new() } else {
          let v846_11: Space = map_kernels::unwrap(&(v840_11),&(v840_12_head));
          let v846_12: Space = map_map_kernels::subtract(&(v846_11),&(*CONSTANT_5));
          drop(v846_11);
          map_map_kernels::compose(&(v841_10),&(v846_12))
        };
        drop(v841_10);
        let v841_14: Space = map_map_kernels::unite(&(v841_8),&(v841_13));
        drop(v841_13);
        v840_12.join_into((v841_14).clone());
        }
        v840_12_cursor.ascend(1);
      }
      drop(v840_12_cursor);
      drop(v840_6);
      drop(v840_11);
      map_map_kernels::compose(&(v829_10),&(v840_12))
    };
    drop(v829_10);
    let v829_14: Space = map_map_kernels::unite(&(v829_8),&(v829_13));
    v828_27.join_into((v829_14).clone());
    }
    v828_27_cursor.ascend(1);
  }
  drop(v828_27_cursor);
  drop(v828_23);
  (v828_27).clone()
}

fn routine_48(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v847_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v847_9: Space = map_kernels::unwrap(&(v847_7),&(*CONSTANT_4));
  drop(v847_7);
  let v847_10: Space = map_kernels::unwrap(&(v847_9),&(*p0));
  drop(v847_9);
  let mut v847_21 = Space::new();
  let mut v847_21_cursor = (*s0).read_zipper();
  for v847_21_byte in v847_21_cursor.child_mask().iter() {
    v847_21_cursor.descend_to_byte(v847_21_byte);
    {
    let v847_21_tail = v847_21_cursor.fork_read_zipper();
    let v847_21_head = Path::from_slice(&[v847_21_byte]);
    let v848_2: Space = singleton(&(v847_21_head));
    let v848_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v848_2));
    let v848_4: Space = if map_kernels::has_head(&(v848_3)) { singleton(&[]) } else { Space::new() };
    drop(v848_3);
    let v848_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v848_4));
    drop(v848_4);
    let v848_8: Space = if (v848_5).is_empty() { Space::new() } else {
      let v849_6: Path = concat_path(&(*p0),&(v847_21_head));
      let mut v849_7 = Space::new();
      let mut v849_7_cursor = (v847_21_tail).read_zipper();
      for v849_7_byte in v849_7_cursor.child_mask().iter() {
        v849_7_cursor.descend_to_byte(v849_7_byte);
        {
        let v849_7_tail = v849_7_cursor.fork_read_zipper();
        let v849_7_head = Path::from_slice(&[v849_7_byte]);
        let v850_2: Space = singleton(&(v849_7_head));
        let v850_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v850_2));
        let v850_4: Space = if map_kernels::has_head(&(v850_3)) { singleton(&[]) } else { Space::new() };
        drop(v850_3);
        let v850_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v850_4));
        drop(v850_4);
        let v850_8: Space = if (v850_5).is_empty() { Space::new() } else {
          let v851_6: Path = concat_path(&(v849_6),&(v849_7_head));
          let mut v851_7 = Space::new();
          let mut v851_7_cursor = (v849_7_tail).read_zipper();
          for v851_7_byte in v851_7_cursor.child_mask().iter() {
            v851_7_cursor.descend_to_byte(v851_7_byte);
            {
            let v851_7_tail = v851_7_cursor.fork_read_zipper();
            let v851_7_head = Path::from_slice(&[v851_7_byte]);
            let v852_2: Space = singleton(&(v851_7_head));
            let v852_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v852_2));
            let v852_4: Space = if map_kernels::has_head(&(v852_3)) { singleton(&[]) } else { Space::new() };
            drop(v852_3);
            let v852_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v852_4));
            drop(v852_4);
            let v852_8: Space = if (v852_5).is_empty() { Space::new() } else {
              let v853_6: Path = concat_path(&(v851_6),&(v851_7_head));
              let v853_7: Space = routine_65(c, &(v853_6), &(v851_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v852_5),&(v853_7))
            };
            drop(v852_5);
            let v852_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v852_2));
            drop(v852_2);
            let v852_10: Space = if map_kernels::has_head(&(v852_9)) { singleton(&[]) } else { Space::new() };
            drop(v852_9);
            let v852_12: Space = if (v852_10).is_empty() { Space::new() } else {
              let v854_6: Path = concat_path(&(v851_6),&(v851_7_head));
              let v854_11: Space = routine_66(c, &(v854_6), &(v851_7_tail).make_space(), &(*s1));
              drop(v854_6);
              map_map_kernels::compose(&(v852_10),&(v854_11))
            };
            drop(v852_10);
            let v852_13: Space = map_map_kernels::unite(&(v852_8),&(v852_12));
            v851_7.join_into((v852_13).clone());
            }
            v851_7_cursor.ascend(1);
          }
          drop(v851_7_cursor);
          map_map_kernels::compose(&(v850_5),&(v851_7))
        };
        drop(v850_5);
        let v850_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v850_2));
        drop(v850_2);
        let v850_10: Space = if map_kernels::has_head(&(v850_9)) { singleton(&[]) } else { Space::new() };
        drop(v850_9);
        let v850_12: Space = if (v850_10).is_empty() { Space::new() } else {
          let v855_6: Path = concat_path(&(v849_6),&(v849_7_head));
          let mut v855_11 = Space::new();
          let mut v855_11_cursor = (v849_7_tail).read_zipper();
          for v855_11_byte in v855_11_cursor.child_mask().iter() {
            v855_11_cursor.descend_to_byte(v855_11_byte);
            {
            let v855_11_tail = v855_11_cursor.fork_read_zipper();
            let v855_11_head = Path::from_slice(&[v855_11_byte]);
            let v856_2: Space = singleton(&(v855_11_head));
            let v856_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v856_2));
            let v856_4: Space = if map_kernels::has_head(&(v856_3)) { singleton(&[]) } else { Space::new() };
            drop(v856_3);
            let v856_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v856_4));
            drop(v856_4);
            let v856_8: Space = if (v856_5).is_empty() { Space::new() } else {
              let v857_6: Path = concat_path(&(v855_6),&(v855_11_head));
              let v857_7: Space = routine_65(c, &(v857_6), &(v855_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v856_5),&(v857_7))
            };
            drop(v856_5);
            let v856_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v856_2));
            drop(v856_2);
            let v856_10: Space = if map_kernels::has_head(&(v856_9)) { singleton(&[]) } else { Space::new() };
            drop(v856_9);
            let v856_12: Space = if (v856_10).is_empty() { Space::new() } else {
              let v858_6: Path = concat_path(&(v855_6),&(v855_11_head));
              let v858_11: Space = routine_44(c, &(v858_6), &(v855_11_tail).make_space(), &(*s1));
              drop(v858_6);
              map_map_kernels::compose(&(v856_10),&(v858_11))
            };
            drop(v856_10);
            let v856_13: Space = map_map_kernels::unite(&(v856_8),&(v856_12));
            v855_11.join_into((v856_13).clone());
            }
            v855_11_cursor.ascend(1);
          }
          drop(v855_11_cursor);
          drop(v855_6);
          map_map_kernels::compose(&(v850_10),&(v855_11))
        };
        drop(v850_10);
        let v850_13: Space = map_map_kernels::unite(&(v850_8),&(v850_12));
        v849_7.join_into((v850_13).clone());
        }
        v849_7_cursor.ascend(1);
      }
      drop(v849_7_cursor);
      drop(v849_6);
      map_map_kernels::compose(&(v848_5),&(v849_7))
    };
    drop(v848_5);
    let v848_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v848_2));
    drop(v848_2);
    let v848_10: Space = if map_kernels::has_head(&(v848_9)) { singleton(&[]) } else { Space::new() };
    drop(v848_9);
    let v848_13: Space = if (v848_10).is_empty() { Space::new() } else {
      let v859_11: Space = map_kernels::unwrap(&(v847_10),&(v847_21_head));
      let v859_12: Space = map_map_kernels::subtract(&(v859_11),&(*CONSTANT_5));
      drop(v859_11);
      map_map_kernels::compose(&(v848_10),&(v859_12))
    };
    drop(v848_10);
    let v848_14: Space = map_map_kernels::unite(&(v848_8),&(v848_13));
    drop(v848_13);
    v847_21.join_into((v848_14).clone());
    }
    v847_21_cursor.ascend(1);
  }
  drop(v847_21_cursor);
  drop(v847_10);
  (v847_21).clone()
}

fn routine_49(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v860_16: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v860_17: Space = map_kernels::unwrap(&(v860_16),&(*CONSTANT_4));
  drop(v860_16);
  let v860_18: Space = map_kernels::unwrap(&(v860_17),&(*p0));
  drop(v860_17);
  let mut v860_19 = Space::new();
  let mut v860_19_cursor = (*s0).read_zipper();
  for v860_19_byte in v860_19_cursor.child_mask().iter() {
    v860_19_cursor.descend_to_byte(v860_19_byte);
    {
    let v860_19_tail = v860_19_cursor.fork_read_zipper();
    let v860_19_head = Path::from_slice(&[v860_19_byte]);
    let v861_2: Space = singleton(&(v860_19_head));
    let v861_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v861_2));
    let v861_4: Space = if map_kernels::has_head(&(v861_3)) { singleton(&[]) } else { Space::new() };
    drop(v861_3);
    let v861_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v861_4));
    drop(v861_4);
    let v861_8: Space = if (v861_5).is_empty() { Space::new() } else {
      let v862_6: Path = concat_path(&(*p0),&(v860_19_head));
      let mut v862_7 = Space::new();
      let mut v862_7_cursor = (v860_19_tail).read_zipper();
      for v862_7_byte in v862_7_cursor.child_mask().iter() {
        v862_7_cursor.descend_to_byte(v862_7_byte);
        {
        let v862_7_tail = v862_7_cursor.fork_read_zipper();
        let v862_7_head = Path::from_slice(&[v862_7_byte]);
        let v863_2: Space = singleton(&(v862_7_head));
        let v863_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v863_2));
        let v863_4: Space = if map_kernels::has_head(&(v863_3)) { singleton(&[]) } else { Space::new() };
        drop(v863_3);
        let v863_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v863_4));
        drop(v863_4);
        let mut v863_6 = Space::new();
        let mut v863_6_cursor = (v862_7_tail).read_zipper();
        for v863_6_byte in v863_6_cursor.child_mask().iter() {
          v863_6_cursor.descend_to_byte(v863_6_byte);
          {
          let v863_6_tail = v863_6_cursor.fork_read_zipper();
          let v863_6_head = Path::from_slice(&[v863_6_byte]);
          let v864_2: Space = Space::new();
          v863_6.join_into((v864_2).clone());
          }
          v863_6_cursor.ascend(1);
        }
        drop(v863_6_cursor);
        let v863_7: Space = map_map_kernels::compose(&(v863_5),&(v863_6));
        drop(v863_5);
        drop(v863_6);
        let v863_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v863_2));
        drop(v863_2);
        let v863_9: Space = if map_kernels::has_head(&(v863_8)) { singleton(&[]) } else { Space::new() };
        drop(v863_8);
        let v863_12: Space = if (v863_9).is_empty() { Space::new() } else {
          let v865_10: Path = concat_path(&(v862_6),&(v862_7_head));
          let mut v865_11 = Space::new();
          let mut v865_11_cursor = (v862_7_tail).read_zipper();
          for v865_11_byte in v865_11_cursor.child_mask().iter() {
            v865_11_cursor.descend_to_byte(v865_11_byte);
            {
            let v865_11_tail = v865_11_cursor.fork_read_zipper();
            let v865_11_head = Path::from_slice(&[v865_11_byte]);
            let v866_2: Space = singleton(&(v865_11_head));
            let v866_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v866_2));
            drop(v866_2);
            let v866_4: Space = if map_kernels::has_head(&(v866_3)) { singleton(&[]) } else { Space::new() };
            drop(v866_3);
            let v866_7: Space = if (v866_4).is_empty() { Space::new() } else {
              let v867_5: Path = concat_path(&(v865_10),&(v865_11_head));
              let v867_6: Space = routine_24(c, &(v867_5), &(v865_11_tail).make_space(), &(*s1));
              drop(v867_5);
              map_map_kernels::compose(&(v866_4),&(v867_6))
            };
            drop(v866_4);
            v865_11.join_into((v866_7).clone());
            }
            v865_11_cursor.ascend(1);
          }
          drop(v865_11_cursor);
          drop(v865_10);
          map_map_kernels::compose(&(v863_9),&(v865_11))
        };
        drop(v863_9);
        let v863_13: Space = map_map_kernels::unite(&(v863_7),&(v863_12));
        drop(v863_7);
        v862_7.join_into((v863_13).clone());
        }
        v862_7_cursor.ascend(1);
      }
      drop(v862_7_cursor);
      drop(v862_6);
      map_map_kernels::compose(&(v861_5),&(v862_7))
    };
    drop(v861_5);
    let v861_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v861_2));
    drop(v861_2);
    let v861_10: Space = if map_kernels::has_head(&(v861_9)) { singleton(&[]) } else { Space::new() };
    drop(v861_9);
    let v861_13: Space = if (v861_10).is_empty() { Space::new() } else {
      let v868_11: Space = map_kernels::unwrap(&(v860_18),&(v860_19_head));
      let mut v868_12 = Space::new();
      let mut v868_12_cursor = (v860_19_tail).read_zipper();
      for v868_12_byte in v868_12_cursor.child_mask().iter() {
        v868_12_cursor.descend_to_byte(v868_12_byte);
        {
        let v868_12_tail = v868_12_cursor.fork_read_zipper();
        let v868_12_head = Path::from_slice(&[v868_12_byte]);
        let v869_2: Space = singleton(&(v868_12_head));
        let v869_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v869_2));
        let v869_4: Space = if map_kernels::has_head(&(v869_3)) { singleton(&[]) } else { Space::new() };
        drop(v869_3);
        let v869_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v869_4));
        drop(v869_4);
        let mut v869_6 = Space::new();
        let mut v869_6_cursor = (v868_12_tail).read_zipper();
        for v869_6_byte in v869_6_cursor.child_mask().iter() {
          v869_6_cursor.descend_to_byte(v869_6_byte);
          {
          let v869_6_tail = v869_6_cursor.fork_read_zipper();
          let v869_6_head = Path::from_slice(&[v869_6_byte]);
          let v870_2: Space = Space::new();
          v869_6.join_into((v870_2).clone());
          }
          v869_6_cursor.ascend(1);
        }
        drop(v869_6_cursor);
        let v869_7: Space = map_map_kernels::compose(&(v869_5),&(v869_6));
        drop(v869_5);
        drop(v869_6);
        let v869_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v869_2));
        drop(v869_2);
        let v869_9: Space = if map_kernels::has_head(&(v869_8)) { singleton(&[]) } else { Space::new() };
        drop(v869_8);
        let v869_12: Space = if (v869_9).is_empty() { Space::new() } else {
          let v871_10: Space = map_kernels::unwrap(&(v868_11),&(v868_12_head));
          let v871_11: Space = map_map_kernels::subtract(&(v871_10),&(*CONSTANT_5));
          drop(v871_10);
          map_map_kernels::compose(&(v869_9),&(v871_11))
        };
        drop(v869_9);
        let v869_13: Space = map_map_kernels::unite(&(v869_7),&(v869_12));
        drop(v869_7);
        drop(v869_12);
        v868_12.join_into((v869_13).clone());
        }
        v868_12_cursor.ascend(1);
      }
      drop(v868_12_cursor);
      drop(v868_11);
      map_map_kernels::compose(&(v861_10),&(v868_12))
    };
    drop(v861_10);
    let v861_14: Space = map_map_kernels::unite(&(v861_8),&(v861_13));
    drop(v861_13);
    v860_19.join_into((v861_14).clone());
    }
    v860_19_cursor.ascend(1);
  }
  drop(v860_19_cursor);
  drop(v860_18);
  (v860_19).clone()
}

fn routine_50(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v872_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v872_9: Space = map_kernels::unwrap(&(v872_7),&(*CONSTANT_4));
  drop(v872_7);
  let v872_10: Space = map_kernels::unwrap(&(v872_9),&(*p0));
  drop(v872_9);
  let mut v872_16 = Space::new();
  let mut v872_16_cursor = (*s0).read_zipper();
  for v872_16_byte in v872_16_cursor.child_mask().iter() {
    v872_16_cursor.descend_to_byte(v872_16_byte);
    {
    let v872_16_tail = v872_16_cursor.fork_read_zipper();
    let v872_16_head = Path::from_slice(&[v872_16_byte]);
    let v873_2: Space = singleton(&(v872_16_head));
    let v873_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v873_2));
    let v873_4: Space = if map_kernels::has_head(&(v873_3)) { singleton(&[]) } else { Space::new() };
    drop(v873_3);
    let v873_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v873_4));
    drop(v873_4);
    let v873_8: Space = if (v873_5).is_empty() { Space::new() } else {
      let v874_6: Path = concat_path(&(*p0),&(v872_16_head));
      let mut v874_7 = Space::new();
      let mut v874_7_cursor = (v872_16_tail).read_zipper();
      for v874_7_byte in v874_7_cursor.child_mask().iter() {
        v874_7_cursor.descend_to_byte(v874_7_byte);
        {
        let v874_7_tail = v874_7_cursor.fork_read_zipper();
        let v874_7_head = Path::from_slice(&[v874_7_byte]);
        let v875_2: Space = singleton(&(v874_7_head));
        let v875_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v875_2));
        let v875_4: Space = if map_kernels::has_head(&(v875_3)) { singleton(&[]) } else { Space::new() };
        drop(v875_3);
        let v875_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v875_4));
        drop(v875_4);
        let mut v875_6 = Space::new();
        let mut v875_6_cursor = (v874_7_tail).read_zipper();
        for v875_6_byte in v875_6_cursor.child_mask().iter() {
          v875_6_cursor.descend_to_byte(v875_6_byte);
          {
          let v875_6_tail = v875_6_cursor.fork_read_zipper();
          let v875_6_head = Path::from_slice(&[v875_6_byte]);
          let v876_2: Space = Space::new();
          v875_6.join_into((v876_2).clone());
          }
          v875_6_cursor.ascend(1);
        }
        drop(v875_6_cursor);
        let v875_7: Space = map_map_kernels::compose(&(v875_5),&(v875_6));
        drop(v875_5);
        drop(v875_6);
        let v875_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v875_2));
        drop(v875_2);
        let v875_9: Space = if map_kernels::has_head(&(v875_8)) { singleton(&[]) } else { Space::new() };
        drop(v875_8);
        let v875_12: Space = if (v875_9).is_empty() { Space::new() } else {
          let v877_10: Path = concat_path(&(v874_6),&(v874_7_head));
          let mut v877_11 = Space::new();
          let mut v877_11_cursor = (v874_7_tail).read_zipper();
          for v877_11_byte in v877_11_cursor.child_mask().iter() {
            v877_11_cursor.descend_to_byte(v877_11_byte);
            {
            let v877_11_tail = v877_11_cursor.fork_read_zipper();
            let v877_11_head = Path::from_slice(&[v877_11_byte]);
            let v878_2: Space = singleton(&(v877_11_head));
            let v878_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v878_2));
            drop(v878_2);
            let v878_4: Space = if map_kernels::has_head(&(v878_3)) { singleton(&[]) } else { Space::new() };
            drop(v878_3);
            let v878_7: Space = if (v878_4).is_empty() { Space::new() } else {
              let v879_5: Path = concat_path(&(v877_10),&(v877_11_head));
              let v879_6: Space = routine_24(c, &(v879_5), &(v877_11_tail).make_space(), &(*s1));
              drop(v879_5);
              map_map_kernels::compose(&(v878_4),&(v879_6))
            };
            drop(v878_4);
            v877_11.join_into((v878_7).clone());
            }
            v877_11_cursor.ascend(1);
          }
          drop(v877_11_cursor);
          drop(v877_10);
          map_map_kernels::compose(&(v875_9),&(v877_11))
        };
        drop(v875_9);
        let v875_13: Space = map_map_kernels::unite(&(v875_7),&(v875_12));
        drop(v875_7);
        v874_7.join_into((v875_13).clone());
        }
        v874_7_cursor.ascend(1);
      }
      drop(v874_7_cursor);
      drop(v874_6);
      map_map_kernels::compose(&(v873_5),&(v874_7))
    };
    drop(v873_5);
    let v873_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v873_2));
    drop(v873_2);
    let v873_10: Space = if map_kernels::has_head(&(v873_9)) { singleton(&[]) } else { Space::new() };
    drop(v873_9);
    let v873_13: Space = if (v873_10).is_empty() { Space::new() } else {
      let v880_11: Space = map_kernels::unwrap(&(v872_10),&(v872_16_head));
      let v880_12: Space = map_map_kernels::subtract(&(v880_11),&(*CONSTANT_5));
      drop(v880_11);
      map_map_kernels::compose(&(v873_10),&(v880_12))
    };
    drop(v873_10);
    let v873_14: Space = map_map_kernels::unite(&(v873_8),&(v873_13));
    drop(v873_13);
    v872_16.join_into((v873_14).clone());
    }
    v872_16_cursor.ascend(1);
  }
  drop(v872_16_cursor);
  drop(v872_10);
  (v872_16).clone()
}

fn routine_51(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v881_10: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v881_11: Space = map_kernels::unwrap(&(v881_10),&(*CONSTANT_4));
  drop(v881_10);
  let v881_12: Space = map_kernels::unwrap(&(v881_11),&(*p0));
  drop(v881_11);
  let mut v881_13 = Space::new();
  let mut v881_13_cursor = (*s0).read_zipper();
  for v881_13_byte in v881_13_cursor.child_mask().iter() {
    v881_13_cursor.descend_to_byte(v881_13_byte);
    {
    let v881_13_tail = v881_13_cursor.fork_read_zipper();
    let v881_13_head = Path::from_slice(&[v881_13_byte]);
    let v882_2: Space = singleton(&(v881_13_head));
    let v882_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v882_2));
    let v882_4: Space = if map_kernels::has_head(&(v882_3)) { singleton(&[]) } else { Space::new() };
    drop(v882_3);
    let v882_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v882_4));
    drop(v882_4);
    let mut v882_6 = Space::new();
    let mut v882_6_cursor = (v881_13_tail).read_zipper();
    for v882_6_byte in v882_6_cursor.child_mask().iter() {
      v882_6_cursor.descend_to_byte(v882_6_byte);
      {
      let v882_6_tail = v882_6_cursor.fork_read_zipper();
      let v882_6_head = Path::from_slice(&[v882_6_byte]);
      let v883_2: Space = Space::new();
      v882_6.join_into((v883_2).clone());
      }
      v882_6_cursor.ascend(1);
    }
    drop(v882_6_cursor);
    let v882_7: Space = map_map_kernels::compose(&(v882_5),&(v882_6));
    drop(v882_5);
    drop(v882_6);
    let v882_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v882_2));
    drop(v882_2);
    let v882_9: Space = if map_kernels::has_head(&(v882_8)) { singleton(&[]) } else { Space::new() };
    drop(v882_8);
    let v882_12: Space = if (v882_9).is_empty() { Space::new() } else {
      let v884_10: Space = map_kernels::unwrap(&(v881_12),&(v881_13_head));
      let mut v884_11 = Space::new();
      let mut v884_11_cursor = (v881_13_tail).read_zipper();
      for v884_11_byte in v884_11_cursor.child_mask().iter() {
        v884_11_cursor.descend_to_byte(v884_11_byte);
        {
        let v884_11_tail = v884_11_cursor.fork_read_zipper();
        let v884_11_head = Path::from_slice(&[v884_11_byte]);
        let v885_2: Space = singleton(&(v884_11_head));
        let v885_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v885_2));
        drop(v885_2);
        let v885_4: Space = if map_kernels::has_head(&(v885_3)) { singleton(&[]) } else { Space::new() };
        drop(v885_3);
        let v885_7: Space = if (v885_4).is_empty() { Space::new() } else {
          let v886_5: Space = map_kernels::unwrap(&(v884_10),&(v884_11_head));
          let v886_6: Space = map_map_kernels::subtract(&(v886_5),&(*CONSTANT_5));
          drop(v886_5);
          map_map_kernels::compose(&(v885_4),&(v886_6))
        };
        drop(v885_4);
        v884_11.join_into((v885_7).clone());
        }
        v884_11_cursor.ascend(1);
      }
      drop(v884_11_cursor);
      drop(v884_10);
      map_map_kernels::compose(&(v882_9),&(v884_11))
    };
    drop(v882_9);
    let v882_13: Space = map_map_kernels::unite(&(v882_7),&(v882_12));
    drop(v882_7);
    drop(v882_12);
    v881_13.join_into((v882_13).clone());
    }
    v881_13_cursor.ascend(1);
  }
  drop(v881_13_cursor);
  drop(v881_12);
  (v881_13).clone()
}

fn routine_52(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v887_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v887_9: Space = map_kernels::unwrap(&(v887_7),&(*CONSTANT_4));
  drop(v887_7);
  let v887_10: Space = map_kernels::unwrap(&(v887_9),&(*p0));
  drop(v887_9);
  let mut v887_12 = Space::new();
  let mut v887_12_cursor = (*s0).read_zipper();
  for v887_12_byte in v887_12_cursor.child_mask().iter() {
    v887_12_cursor.descend_to_byte(v887_12_byte);
    {
    let v887_12_tail = v887_12_cursor.fork_read_zipper();
    let v887_12_head = Path::from_slice(&[v887_12_byte]);
    let v888_2: Space = singleton(&(v887_12_head));
    let v888_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v888_2));
    let v888_4: Space = if map_kernels::has_head(&(v888_3)) { singleton(&[]) } else { Space::new() };
    drop(v888_3);
    let v888_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v888_4));
    drop(v888_4);
    let mut v888_6 = Space::new();
    let mut v888_6_cursor = (v887_12_tail).read_zipper();
    for v888_6_byte in v888_6_cursor.child_mask().iter() {
      v888_6_cursor.descend_to_byte(v888_6_byte);
      {
      let v888_6_tail = v888_6_cursor.fork_read_zipper();
      let v888_6_head = Path::from_slice(&[v888_6_byte]);
      let v889_2: Space = Space::new();
      v888_6.join_into((v889_2).clone());
      }
      v888_6_cursor.ascend(1);
    }
    drop(v888_6_cursor);
    let v888_7: Space = map_map_kernels::compose(&(v888_5),&(v888_6));
    drop(v888_5);
    drop(v888_6);
    let v888_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v888_2));
    drop(v888_2);
    let v888_9: Space = if map_kernels::has_head(&(v888_8)) { singleton(&[]) } else { Space::new() };
    drop(v888_8);
    let v888_12: Space = if (v888_9).is_empty() { Space::new() } else {
      let v890_10: Space = map_kernels::unwrap(&(v887_10),&(v887_12_head));
      let v890_11: Space = map_map_kernels::subtract(&(v890_10),&(*CONSTANT_5));
      drop(v890_10);
      map_map_kernels::compose(&(v888_9),&(v890_11))
    };
    drop(v888_9);
    let v888_13: Space = map_map_kernels::unite(&(v888_7),&(v888_12));
    drop(v888_7);
    drop(v888_12);
    v887_12.join_into((v888_13).clone());
    }
    v887_12_cursor.ascend(1);
  }
  drop(v887_12_cursor);
  drop(v887_10);
  (v887_12).clone()
}

fn routine_53(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v891_3 = Space::new();
  let mut v891_3_cursor = (*s0).read_zipper();
  for v891_3_byte in v891_3_cursor.child_mask().iter() {
    v891_3_cursor.descend_to_byte(v891_3_byte);
    {
    let v891_3_tail = v891_3_cursor.fork_read_zipper();
    let v891_3_head = Path::from_slice(&[v891_3_byte]);
    let v892_2: Space = Space::new();
    v891_3.join_into((v892_2).clone());
    }
    v891_3_cursor.ascend(1);
  }
  drop(v891_3_cursor);
  (v891_3).clone()
}

fn routine_54(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v893_5: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
  let v893_7: Space = map_kernels::unwrap(&(v893_5),&(*CONSTANT_4));
  drop(v893_5);
  let v893_8: Space = map_kernels::unwrap(&(v893_7),&(*p0));
  drop(v893_7);
  let mut v893_10 = Space::new();
  let mut v893_10_cursor = (*s0).read_zipper();
  for v893_10_byte in v893_10_cursor.child_mask().iter() {
    v893_10_cursor.descend_to_byte(v893_10_byte);
    {
    let v893_10_tail = v893_10_cursor.fork_read_zipper();
    let v893_10_head = Path::from_slice(&[v893_10_byte]);
    let v894_2: Space = singleton(&(v893_10_head));
    let v894_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v894_2));
    drop(v894_2);
    let v894_4: Space = if map_kernels::has_head(&(v894_3)) { singleton(&[]) } else { Space::new() };
    drop(v894_3);
    let v894_7: Space = if (v894_4).is_empty() { Space::new() } else {
      let v895_5: Space = map_kernels::unwrap(&(v893_8),&(v893_10_head));
      let v895_6: Space = map_map_kernels::subtract(&(v895_5),&(*CONSTANT_5));
      drop(v895_5);
      map_map_kernels::compose(&(v894_4),&(v895_6))
    };
    drop(v894_4);
    v893_10.join_into((v894_7).clone());
    }
    v893_10_cursor.ascend(1);
  }
  drop(v893_10_cursor);
  drop(v893_8);
  (v893_10).clone()
}

fn routine_55(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v896_16: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v896_17: Space = map_kernels::unwrap(&(v896_16),&(*CONSTANT_4));
  drop(v896_16);
  let v896_18: Space = map_kernels::unwrap(&(v896_17),&(*p0));
  drop(v896_17);
  let mut v896_19 = Space::new();
  let mut v896_19_cursor = (*s0).read_zipper();
  for v896_19_byte in v896_19_cursor.child_mask().iter() {
    v896_19_cursor.descend_to_byte(v896_19_byte);
    {
    let v896_19_tail = v896_19_cursor.fork_read_zipper();
    let v896_19_head = Path::from_slice(&[v896_19_byte]);
    let v897_2: Space = singleton(&(v896_19_head));
    let v897_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v897_2));
    let v897_4: Space = if map_kernels::has_head(&(v897_3)) { singleton(&[]) } else { Space::new() };
    drop(v897_3);
    let v897_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v897_4));
    drop(v897_4);
    let v897_8: Space = if (v897_5).is_empty() { Space::new() } else {
      let v898_6: Path = concat_path(&(*p0),&(v896_19_head));
      let mut v898_7 = Space::new();
      let mut v898_7_cursor = (v896_19_tail).read_zipper();
      for v898_7_byte in v898_7_cursor.child_mask().iter() {
        v898_7_cursor.descend_to_byte(v898_7_byte);
        {
        let v898_7_tail = v898_7_cursor.fork_read_zipper();
        let v898_7_head = Path::from_slice(&[v898_7_byte]);
        let v899_2: Space = singleton(&(v898_7_head));
        let v899_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v899_2));
        let v899_4: Space = if map_kernels::has_head(&(v899_3)) { singleton(&[]) } else { Space::new() };
        drop(v899_3);
        let v899_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v899_4));
        drop(v899_4);
        let mut v899_6 = Space::new();
        let mut v899_6_cursor = (v898_7_tail).read_zipper();
        for v899_6_byte in v899_6_cursor.child_mask().iter() {
          v899_6_cursor.descend_to_byte(v899_6_byte);
          {
          let v899_6_tail = v899_6_cursor.fork_read_zipper();
          let v899_6_head = Path::from_slice(&[v899_6_byte]);
          let v900_2: Space = Space::new();
          v899_6.join_into((v900_2).clone());
          }
          v899_6_cursor.ascend(1);
        }
        drop(v899_6_cursor);
        let v899_7: Space = map_map_kernels::compose(&(v899_5),&(v899_6));
        drop(v899_5);
        drop(v899_6);
        let v899_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v899_2));
        drop(v899_2);
        let v899_9: Space = if map_kernels::has_head(&(v899_8)) { singleton(&[]) } else { Space::new() };
        drop(v899_8);
        let v899_12: Space = if (v899_9).is_empty() { Space::new() } else {
          let v901_10: Path = concat_path(&(v898_6),&(v898_7_head));
          let mut v901_11 = Space::new();
          let mut v901_11_cursor = (v898_7_tail).read_zipper();
          for v901_11_byte in v901_11_cursor.child_mask().iter() {
            v901_11_cursor.descend_to_byte(v901_11_byte);
            {
            let v901_11_tail = v901_11_cursor.fork_read_zipper();
            let v901_11_head = Path::from_slice(&[v901_11_byte]);
            let v902_2: Space = singleton(&(v901_11_head));
            let v902_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v902_2));
            drop(v902_2);
            let v902_4: Space = if map_kernels::has_head(&(v902_3)) { singleton(&[]) } else { Space::new() };
            drop(v902_3);
            let v902_7: Space = if (v902_4).is_empty() { Space::new() } else {
              let v903_5: Path = concat_path(&(v901_10),&(v901_11_head));
              let v903_6: Space = routine_33(c, &(v903_5), &(v901_11_tail).make_space(), &(*s1));
              drop(v903_5);
              map_map_kernels::compose(&(v902_4),&(v903_6))
            };
            drop(v902_4);
            v901_11.join_into((v902_7).clone());
            }
            v901_11_cursor.ascend(1);
          }
          drop(v901_11_cursor);
          drop(v901_10);
          map_map_kernels::compose(&(v899_9),&(v901_11))
        };
        drop(v899_9);
        let v899_13: Space = map_map_kernels::unite(&(v899_7),&(v899_12));
        drop(v899_7);
        v898_7.join_into((v899_13).clone());
        }
        v898_7_cursor.ascend(1);
      }
      drop(v898_7_cursor);
      drop(v898_6);
      map_map_kernels::compose(&(v897_5),&(v898_7))
    };
    drop(v897_5);
    let v897_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v897_2));
    drop(v897_2);
    let v897_10: Space = if map_kernels::has_head(&(v897_9)) { singleton(&[]) } else { Space::new() };
    drop(v897_9);
    let v897_13: Space = if (v897_10).is_empty() { Space::new() } else {
      let v904_11: Space = map_kernels::unwrap(&(v896_18),&(v896_19_head));
      let mut v904_12 = Space::new();
      let mut v904_12_cursor = (v896_19_tail).read_zipper();
      for v904_12_byte in v904_12_cursor.child_mask().iter() {
        v904_12_cursor.descend_to_byte(v904_12_byte);
        {
        let v904_12_tail = v904_12_cursor.fork_read_zipper();
        let v904_12_head = Path::from_slice(&[v904_12_byte]);
        let v905_2: Space = singleton(&(v904_12_head));
        let v905_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v905_2));
        let v905_4: Space = if map_kernels::has_head(&(v905_3)) { singleton(&[]) } else { Space::new() };
        drop(v905_3);
        let v905_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v905_4));
        drop(v905_4);
        let mut v905_6 = Space::new();
        let mut v905_6_cursor = (v904_12_tail).read_zipper();
        for v905_6_byte in v905_6_cursor.child_mask().iter() {
          v905_6_cursor.descend_to_byte(v905_6_byte);
          {
          let v905_6_tail = v905_6_cursor.fork_read_zipper();
          let v905_6_head = Path::from_slice(&[v905_6_byte]);
          let v906_2: Space = Space::new();
          v905_6.join_into((v906_2).clone());
          }
          v905_6_cursor.ascend(1);
        }
        drop(v905_6_cursor);
        let v905_7: Space = map_map_kernels::compose(&(v905_5),&(v905_6));
        drop(v905_5);
        drop(v905_6);
        let v905_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v905_2));
        drop(v905_2);
        let v905_9: Space = if map_kernels::has_head(&(v905_8)) { singleton(&[]) } else { Space::new() };
        drop(v905_8);
        let v905_12: Space = if (v905_9).is_empty() { Space::new() } else {
          let v907_10: Space = map_kernels::unwrap(&(v904_11),&(v904_12_head));
          let v907_11: Space = map_map_kernels::subtract(&(v907_10),&(*CONSTANT_5));
          drop(v907_10);
          map_map_kernels::compose(&(v905_9),&(v907_11))
        };
        drop(v905_9);
        let v905_13: Space = map_map_kernels::unite(&(v905_7),&(v905_12));
        drop(v905_7);
        drop(v905_12);
        v904_12.join_into((v905_13).clone());
        }
        v904_12_cursor.ascend(1);
      }
      drop(v904_12_cursor);
      drop(v904_11);
      map_map_kernels::compose(&(v897_10),&(v904_12))
    };
    drop(v897_10);
    let v897_14: Space = map_map_kernels::unite(&(v897_8),&(v897_13));
    drop(v897_13);
    v896_19.join_into((v897_14).clone());
    }
    v896_19_cursor.ascend(1);
  }
  drop(v896_19_cursor);
  drop(v896_18);
  (v896_19).clone()
}

fn routine_56(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v908_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v908_9: Space = map_kernels::unwrap(&(v908_7),&(*CONSTANT_4));
  drop(v908_7);
  let v908_10: Space = map_kernels::unwrap(&(v908_9),&(*p0));
  drop(v908_9);
  let mut v908_16 = Space::new();
  let mut v908_16_cursor = (*s0).read_zipper();
  for v908_16_byte in v908_16_cursor.child_mask().iter() {
    v908_16_cursor.descend_to_byte(v908_16_byte);
    {
    let v908_16_tail = v908_16_cursor.fork_read_zipper();
    let v908_16_head = Path::from_slice(&[v908_16_byte]);
    let v909_2: Space = singleton(&(v908_16_head));
    let v909_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v909_2));
    let v909_4: Space = if map_kernels::has_head(&(v909_3)) { singleton(&[]) } else { Space::new() };
    drop(v909_3);
    let v909_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v909_4));
    drop(v909_4);
    let v909_8: Space = if (v909_5).is_empty() { Space::new() } else {
      let v910_6: Path = concat_path(&(*p0),&(v908_16_head));
      let mut v910_7 = Space::new();
      let mut v910_7_cursor = (v908_16_tail).read_zipper();
      for v910_7_byte in v910_7_cursor.child_mask().iter() {
        v910_7_cursor.descend_to_byte(v910_7_byte);
        {
        let v910_7_tail = v910_7_cursor.fork_read_zipper();
        let v910_7_head = Path::from_slice(&[v910_7_byte]);
        let v911_2: Space = singleton(&(v910_7_head));
        let v911_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v911_2));
        let v911_4: Space = if map_kernels::has_head(&(v911_3)) { singleton(&[]) } else { Space::new() };
        drop(v911_3);
        let v911_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v911_4));
        drop(v911_4);
        let mut v911_6 = Space::new();
        let mut v911_6_cursor = (v910_7_tail).read_zipper();
        for v911_6_byte in v911_6_cursor.child_mask().iter() {
          v911_6_cursor.descend_to_byte(v911_6_byte);
          {
          let v911_6_tail = v911_6_cursor.fork_read_zipper();
          let v911_6_head = Path::from_slice(&[v911_6_byte]);
          let v912_2: Space = Space::new();
          v911_6.join_into((v912_2).clone());
          }
          v911_6_cursor.ascend(1);
        }
        drop(v911_6_cursor);
        let v911_7: Space = map_map_kernels::compose(&(v911_5),&(v911_6));
        drop(v911_5);
        drop(v911_6);
        let v911_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v911_2));
        drop(v911_2);
        let v911_9: Space = if map_kernels::has_head(&(v911_8)) { singleton(&[]) } else { Space::new() };
        drop(v911_8);
        let v911_12: Space = if (v911_9).is_empty() { Space::new() } else {
          let v913_10: Path = concat_path(&(v910_6),&(v910_7_head));
          let mut v913_11 = Space::new();
          let mut v913_11_cursor = (v910_7_tail).read_zipper();
          for v913_11_byte in v913_11_cursor.child_mask().iter() {
            v913_11_cursor.descend_to_byte(v913_11_byte);
            {
            let v913_11_tail = v913_11_cursor.fork_read_zipper();
            let v913_11_head = Path::from_slice(&[v913_11_byte]);
            let v914_2: Space = singleton(&(v913_11_head));
            let v914_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v914_2));
            drop(v914_2);
            let v914_4: Space = if map_kernels::has_head(&(v914_3)) { singleton(&[]) } else { Space::new() };
            drop(v914_3);
            let v914_7: Space = if (v914_4).is_empty() { Space::new() } else {
              let v915_5: Path = concat_path(&(v913_10),&(v913_11_head));
              let v915_6: Space = routine_33(c, &(v915_5), &(v913_11_tail).make_space(), &(*s1));
              drop(v915_5);
              map_map_kernels::compose(&(v914_4),&(v915_6))
            };
            drop(v914_4);
            v913_11.join_into((v914_7).clone());
            }
            v913_11_cursor.ascend(1);
          }
          drop(v913_11_cursor);
          drop(v913_10);
          map_map_kernels::compose(&(v911_9),&(v913_11))
        };
        drop(v911_9);
        let v911_13: Space = map_map_kernels::unite(&(v911_7),&(v911_12));
        drop(v911_7);
        v910_7.join_into((v911_13).clone());
        }
        v910_7_cursor.ascend(1);
      }
      drop(v910_7_cursor);
      drop(v910_6);
      map_map_kernels::compose(&(v909_5),&(v910_7))
    };
    drop(v909_5);
    let v909_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v909_2));
    drop(v909_2);
    let v909_10: Space = if map_kernels::has_head(&(v909_9)) { singleton(&[]) } else { Space::new() };
    drop(v909_9);
    let v909_13: Space = if (v909_10).is_empty() { Space::new() } else {
      let v916_11: Space = map_kernels::unwrap(&(v908_10),&(v908_16_head));
      let v916_12: Space = map_map_kernels::subtract(&(v916_11),&(*CONSTANT_5));
      drop(v916_11);
      map_map_kernels::compose(&(v909_10),&(v916_12))
    };
    drop(v909_10);
    let v909_14: Space = map_map_kernels::unite(&(v909_8),&(v909_13));
    drop(v909_13);
    v908_16.join_into((v909_14).clone());
    }
    v908_16_cursor.ascend(1);
  }
  drop(v908_16_cursor);
  drop(v908_10);
  (v908_16).clone()
}

fn routine_57(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v917_10: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v917_11: Space = map_kernels::unwrap(&(v917_10),&(*CONSTANT_4));
  drop(v917_10);
  let v917_12: Space = map_kernels::unwrap(&(v917_11),&(*p0));
  drop(v917_11);
  let mut v917_13 = Space::new();
  let mut v917_13_cursor = (*s0).read_zipper();
  for v917_13_byte in v917_13_cursor.child_mask().iter() {
    v917_13_cursor.descend_to_byte(v917_13_byte);
    {
    let v917_13_tail = v917_13_cursor.fork_read_zipper();
    let v917_13_head = Path::from_slice(&[v917_13_byte]);
    let v918_2: Space = singleton(&(v917_13_head));
    let v918_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v918_2));
    let v918_4: Space = if map_kernels::has_head(&(v918_3)) { singleton(&[]) } else { Space::new() };
    drop(v918_3);
    let v918_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v918_4));
    drop(v918_4);
    let mut v918_6 = Space::new();
    let mut v918_6_cursor = (v917_13_tail).read_zipper();
    for v918_6_byte in v918_6_cursor.child_mask().iter() {
      v918_6_cursor.descend_to_byte(v918_6_byte);
      {
      let v918_6_tail = v918_6_cursor.fork_read_zipper();
      let v918_6_head = Path::from_slice(&[v918_6_byte]);
      let v919_2: Space = Space::new();
      v918_6.join_into((v919_2).clone());
      }
      v918_6_cursor.ascend(1);
    }
    drop(v918_6_cursor);
    let v918_7: Space = map_map_kernels::compose(&(v918_5),&(v918_6));
    drop(v918_5);
    drop(v918_6);
    let v918_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v918_2));
    drop(v918_2);
    let v918_9: Space = if map_kernels::has_head(&(v918_8)) { singleton(&[]) } else { Space::new() };
    drop(v918_8);
    let v918_12: Space = if (v918_9).is_empty() { Space::new() } else {
      let v920_10: Space = map_kernels::unwrap(&(v917_12),&(v917_13_head));
      let mut v920_11 = Space::new();
      let mut v920_11_cursor = (v917_13_tail).read_zipper();
      for v920_11_byte in v920_11_cursor.child_mask().iter() {
        v920_11_cursor.descend_to_byte(v920_11_byte);
        {
        let v920_11_tail = v920_11_cursor.fork_read_zipper();
        let v920_11_head = Path::from_slice(&[v920_11_byte]);
        let v921_2: Space = singleton(&(v920_11_head));
        let v921_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v921_2));
        drop(v921_2);
        let v921_4: Space = if map_kernels::has_head(&(v921_3)) { singleton(&[]) } else { Space::new() };
        drop(v921_3);
        let v921_7: Space = if (v921_4).is_empty() { Space::new() } else {
          let v922_5: Space = map_kernels::unwrap(&(v920_10),&(v920_11_head));
          let v922_6: Space = map_map_kernels::subtract(&(v922_5),&(*CONSTANT_5));
          drop(v922_5);
          map_map_kernels::compose(&(v921_4),&(v922_6))
        };
        drop(v921_4);
        v920_11.join_into((v921_7).clone());
        }
        v920_11_cursor.ascend(1);
      }
      drop(v920_11_cursor);
      drop(v920_10);
      map_map_kernels::compose(&(v918_9),&(v920_11))
    };
    drop(v918_9);
    let v918_13: Space = map_map_kernels::unite(&(v918_7),&(v918_12));
    drop(v918_7);
    drop(v918_12);
    v917_13.join_into((v918_13).clone());
    }
    v917_13_cursor.ascend(1);
  }
  drop(v917_13_cursor);
  drop(v917_12);
  (v917_13).clone()
}

fn routine_58(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v923_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v923_9: Space = map_kernels::unwrap(&(v923_7),&(*CONSTANT_4));
  drop(v923_7);
  let v923_10: Space = map_kernels::unwrap(&(v923_9),&(*p0));
  drop(v923_9);
  let mut v923_12 = Space::new();
  let mut v923_12_cursor = (*s0).read_zipper();
  for v923_12_byte in v923_12_cursor.child_mask().iter() {
    v923_12_cursor.descend_to_byte(v923_12_byte);
    {
    let v923_12_tail = v923_12_cursor.fork_read_zipper();
    let v923_12_head = Path::from_slice(&[v923_12_byte]);
    let v924_2: Space = singleton(&(v923_12_head));
    let v924_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v924_2));
    let v924_4: Space = if map_kernels::has_head(&(v924_3)) { singleton(&[]) } else { Space::new() };
    drop(v924_3);
    let v924_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v924_4));
    drop(v924_4);
    let mut v924_6 = Space::new();
    let mut v924_6_cursor = (v923_12_tail).read_zipper();
    for v924_6_byte in v924_6_cursor.child_mask().iter() {
      v924_6_cursor.descend_to_byte(v924_6_byte);
      {
      let v924_6_tail = v924_6_cursor.fork_read_zipper();
      let v924_6_head = Path::from_slice(&[v924_6_byte]);
      let v925_2: Space = Space::new();
      v924_6.join_into((v925_2).clone());
      }
      v924_6_cursor.ascend(1);
    }
    drop(v924_6_cursor);
    let v924_7: Space = map_map_kernels::compose(&(v924_5),&(v924_6));
    drop(v924_5);
    drop(v924_6);
    let v924_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v924_2));
    drop(v924_2);
    let v924_9: Space = if map_kernels::has_head(&(v924_8)) { singleton(&[]) } else { Space::new() };
    drop(v924_8);
    let v924_12: Space = if (v924_9).is_empty() { Space::new() } else {
      let v926_10: Space = map_kernels::unwrap(&(v923_10),&(v923_12_head));
      let v926_11: Space = map_map_kernels::subtract(&(v926_10),&(*CONSTANT_5));
      drop(v926_10);
      map_map_kernels::compose(&(v924_9),&(v926_11))
    };
    drop(v924_9);
    let v924_13: Space = map_map_kernels::unite(&(v924_7),&(v924_12));
    drop(v924_7);
    drop(v924_12);
    v923_12.join_into((v924_13).clone());
    }
    v923_12_cursor.ascend(1);
  }
  drop(v923_12_cursor);
  drop(v923_10);
  (v923_12).clone()
}

fn routine_59(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v927_3 = Space::new();
  let mut v927_3_cursor = (*s0).read_zipper();
  for v927_3_byte in v927_3_cursor.child_mask().iter() {
    v927_3_cursor.descend_to_byte(v927_3_byte);
    {
    let v927_3_tail = v927_3_cursor.fork_read_zipper();
    let v927_3_head = Path::from_slice(&[v927_3_byte]);
    let v928_2: Space = Space::new();
    v927_3.join_into((v928_2).clone());
    }
    v927_3_cursor.ascend(1);
  }
  drop(v927_3_cursor);
  (v927_3).clone()
}

fn routine_60(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v929_5: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v929_7: Space = map_kernels::unwrap(&(v929_5),&(*CONSTANT_4));
  drop(v929_5);
  let v929_8: Space = map_kernels::unwrap(&(v929_7),&(*p0));
  drop(v929_7);
  let mut v929_10 = Space::new();
  let mut v929_10_cursor = (*s0).read_zipper();
  for v929_10_byte in v929_10_cursor.child_mask().iter() {
    v929_10_cursor.descend_to_byte(v929_10_byte);
    {
    let v929_10_tail = v929_10_cursor.fork_read_zipper();
    let v929_10_head = Path::from_slice(&[v929_10_byte]);
    let v930_2: Space = singleton(&(v929_10_head));
    let v930_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v930_2));
    drop(v930_2);
    let v930_4: Space = if map_kernels::has_head(&(v930_3)) { singleton(&[]) } else { Space::new() };
    drop(v930_3);
    let v930_7: Space = if (v930_4).is_empty() { Space::new() } else {
      let v931_5: Space = map_kernels::unwrap(&(v929_8),&(v929_10_head));
      let v931_6: Space = map_map_kernels::subtract(&(v931_5),&(*CONSTANT_5));
      drop(v931_5);
      map_map_kernels::compose(&(v930_4),&(v931_6))
    };
    drop(v930_4);
    v929_10.join_into((v930_7).clone());
    }
    v929_10_cursor.ascend(1);
  }
  drop(v929_10_cursor);
  drop(v929_8);
  (v929_10).clone()
}

fn routine_61(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v932_16: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v932_17: Space = map_kernels::unwrap(&(v932_16),&(*CONSTANT_4));
  drop(v932_16);
  let v932_18: Space = map_kernels::unwrap(&(v932_17),&(*p0));
  drop(v932_17);
  let mut v932_19 = Space::new();
  let mut v932_19_cursor = (*s0).read_zipper();
  for v932_19_byte in v932_19_cursor.child_mask().iter() {
    v932_19_cursor.descend_to_byte(v932_19_byte);
    {
    let v932_19_tail = v932_19_cursor.fork_read_zipper();
    let v932_19_head = Path::from_slice(&[v932_19_byte]);
    let v933_2: Space = singleton(&(v932_19_head));
    let v933_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v933_2));
    let v933_4: Space = if map_kernels::has_head(&(v933_3)) { singleton(&[]) } else { Space::new() };
    drop(v933_3);
    let v933_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v933_4));
    drop(v933_4);
    let v933_8: Space = if (v933_5).is_empty() { Space::new() } else {
      let v934_6: Path = concat_path(&(*p0),&(v932_19_head));
      let mut v934_7 = Space::new();
      let mut v934_7_cursor = (v932_19_tail).read_zipper();
      for v934_7_byte in v934_7_cursor.child_mask().iter() {
        v934_7_cursor.descend_to_byte(v934_7_byte);
        {
        let v934_7_tail = v934_7_cursor.fork_read_zipper();
        let v934_7_head = Path::from_slice(&[v934_7_byte]);
        let v935_2: Space = singleton(&(v934_7_head));
        let v935_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v935_2));
        let v935_4: Space = if map_kernels::has_head(&(v935_3)) { singleton(&[]) } else { Space::new() };
        drop(v935_3);
        let v935_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v935_4));
        drop(v935_4);
        let mut v935_6 = Space::new();
        let mut v935_6_cursor = (v934_7_tail).read_zipper();
        for v935_6_byte in v935_6_cursor.child_mask().iter() {
          v935_6_cursor.descend_to_byte(v935_6_byte);
          {
          let v935_6_tail = v935_6_cursor.fork_read_zipper();
          let v935_6_head = Path::from_slice(&[v935_6_byte]);
          let v936_2: Space = Space::new();
          v935_6.join_into((v936_2).clone());
          }
          v935_6_cursor.ascend(1);
        }
        drop(v935_6_cursor);
        let v935_7: Space = map_map_kernels::compose(&(v935_5),&(v935_6));
        drop(v935_5);
        drop(v935_6);
        let v935_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v935_2));
        drop(v935_2);
        let v935_9: Space = if map_kernels::has_head(&(v935_8)) { singleton(&[]) } else { Space::new() };
        drop(v935_8);
        let v935_12: Space = if (v935_9).is_empty() { Space::new() } else {
          let v937_10: Path = concat_path(&(v934_6),&(v934_7_head));
          let mut v937_11 = Space::new();
          let mut v937_11_cursor = (v934_7_tail).read_zipper();
          for v937_11_byte in v937_11_cursor.child_mask().iter() {
            v937_11_cursor.descend_to_byte(v937_11_byte);
            {
            let v937_11_tail = v937_11_cursor.fork_read_zipper();
            let v937_11_head = Path::from_slice(&[v937_11_byte]);
            let v938_2: Space = singleton(&(v937_11_head));
            let v938_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v938_2));
            drop(v938_2);
            let v938_4: Space = if map_kernels::has_head(&(v938_3)) { singleton(&[]) } else { Space::new() };
            drop(v938_3);
            let v938_7: Space = if (v938_4).is_empty() { Space::new() } else {
              let v939_5: Path = concat_path(&(v937_10),&(v937_11_head));
              let v939_6: Space = routine_44(c, &(v939_5), &(v937_11_tail).make_space(), &(*s1));
              drop(v939_5);
              map_map_kernels::compose(&(v938_4),&(v939_6))
            };
            drop(v938_4);
            v937_11.join_into((v938_7).clone());
            }
            v937_11_cursor.ascend(1);
          }
          drop(v937_11_cursor);
          drop(v937_10);
          map_map_kernels::compose(&(v935_9),&(v937_11))
        };
        drop(v935_9);
        let v935_13: Space = map_map_kernels::unite(&(v935_7),&(v935_12));
        drop(v935_7);
        v934_7.join_into((v935_13).clone());
        }
        v934_7_cursor.ascend(1);
      }
      drop(v934_7_cursor);
      drop(v934_6);
      map_map_kernels::compose(&(v933_5),&(v934_7))
    };
    drop(v933_5);
    let v933_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v933_2));
    drop(v933_2);
    let v933_10: Space = if map_kernels::has_head(&(v933_9)) { singleton(&[]) } else { Space::new() };
    drop(v933_9);
    let v933_13: Space = if (v933_10).is_empty() { Space::new() } else {
      let v940_11: Space = map_kernels::unwrap(&(v932_18),&(v932_19_head));
      let mut v940_12 = Space::new();
      let mut v940_12_cursor = (v932_19_tail).read_zipper();
      for v940_12_byte in v940_12_cursor.child_mask().iter() {
        v940_12_cursor.descend_to_byte(v940_12_byte);
        {
        let v940_12_tail = v940_12_cursor.fork_read_zipper();
        let v940_12_head = Path::from_slice(&[v940_12_byte]);
        let v941_2: Space = singleton(&(v940_12_head));
        let v941_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v941_2));
        let v941_4: Space = if map_kernels::has_head(&(v941_3)) { singleton(&[]) } else { Space::new() };
        drop(v941_3);
        let v941_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v941_4));
        drop(v941_4);
        let mut v941_6 = Space::new();
        let mut v941_6_cursor = (v940_12_tail).read_zipper();
        for v941_6_byte in v941_6_cursor.child_mask().iter() {
          v941_6_cursor.descend_to_byte(v941_6_byte);
          {
          let v941_6_tail = v941_6_cursor.fork_read_zipper();
          let v941_6_head = Path::from_slice(&[v941_6_byte]);
          let v942_2: Space = Space::new();
          v941_6.join_into((v942_2).clone());
          }
          v941_6_cursor.ascend(1);
        }
        drop(v941_6_cursor);
        let v941_7: Space = map_map_kernels::compose(&(v941_5),&(v941_6));
        drop(v941_5);
        drop(v941_6);
        let v941_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v941_2));
        drop(v941_2);
        let v941_9: Space = if map_kernels::has_head(&(v941_8)) { singleton(&[]) } else { Space::new() };
        drop(v941_8);
        let v941_12: Space = if (v941_9).is_empty() { Space::new() } else {
          let v943_10: Space = map_kernels::unwrap(&(v940_11),&(v940_12_head));
          let v943_11: Space = map_map_kernels::subtract(&(v943_10),&(*CONSTANT_5));
          drop(v943_10);
          map_map_kernels::compose(&(v941_9),&(v943_11))
        };
        drop(v941_9);
        let v941_13: Space = map_map_kernels::unite(&(v941_7),&(v941_12));
        drop(v941_7);
        drop(v941_12);
        v940_12.join_into((v941_13).clone());
        }
        v940_12_cursor.ascend(1);
      }
      drop(v940_12_cursor);
      drop(v940_11);
      map_map_kernels::compose(&(v933_10),&(v940_12))
    };
    drop(v933_10);
    let v933_14: Space = map_map_kernels::unite(&(v933_8),&(v933_13));
    drop(v933_13);
    v932_19.join_into((v933_14).clone());
    }
    v932_19_cursor.ascend(1);
  }
  drop(v932_19_cursor);
  drop(v932_18);
  (v932_19).clone()
}

fn routine_62(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v944_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v944_9: Space = map_kernels::unwrap(&(v944_7),&(*CONSTANT_4));
  drop(v944_7);
  let v944_10: Space = map_kernels::unwrap(&(v944_9),&(*p0));
  drop(v944_9);
  let mut v944_16 = Space::new();
  let mut v944_16_cursor = (*s0).read_zipper();
  for v944_16_byte in v944_16_cursor.child_mask().iter() {
    v944_16_cursor.descend_to_byte(v944_16_byte);
    {
    let v944_16_tail = v944_16_cursor.fork_read_zipper();
    let v944_16_head = Path::from_slice(&[v944_16_byte]);
    let v945_2: Space = singleton(&(v944_16_head));
    let v945_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v945_2));
    let v945_4: Space = if map_kernels::has_head(&(v945_3)) { singleton(&[]) } else { Space::new() };
    drop(v945_3);
    let v945_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v945_4));
    drop(v945_4);
    let v945_8: Space = if (v945_5).is_empty() { Space::new() } else {
      let v946_6: Path = concat_path(&(*p0),&(v944_16_head));
      let mut v946_7 = Space::new();
      let mut v946_7_cursor = (v944_16_tail).read_zipper();
      for v946_7_byte in v946_7_cursor.child_mask().iter() {
        v946_7_cursor.descend_to_byte(v946_7_byte);
        {
        let v946_7_tail = v946_7_cursor.fork_read_zipper();
        let v946_7_head = Path::from_slice(&[v946_7_byte]);
        let v947_2: Space = singleton(&(v946_7_head));
        let v947_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v947_2));
        let v947_4: Space = if map_kernels::has_head(&(v947_3)) { singleton(&[]) } else { Space::new() };
        drop(v947_3);
        let v947_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v947_4));
        drop(v947_4);
        let mut v947_6 = Space::new();
        let mut v947_6_cursor = (v946_7_tail).read_zipper();
        for v947_6_byte in v947_6_cursor.child_mask().iter() {
          v947_6_cursor.descend_to_byte(v947_6_byte);
          {
          let v947_6_tail = v947_6_cursor.fork_read_zipper();
          let v947_6_head = Path::from_slice(&[v947_6_byte]);
          let v948_2: Space = Space::new();
          v947_6.join_into((v948_2).clone());
          }
          v947_6_cursor.ascend(1);
        }
        drop(v947_6_cursor);
        let v947_7: Space = map_map_kernels::compose(&(v947_5),&(v947_6));
        drop(v947_5);
        drop(v947_6);
        let v947_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v947_2));
        drop(v947_2);
        let v947_9: Space = if map_kernels::has_head(&(v947_8)) { singleton(&[]) } else { Space::new() };
        drop(v947_8);
        let v947_12: Space = if (v947_9).is_empty() { Space::new() } else {
          let v949_10: Path = concat_path(&(v946_6),&(v946_7_head));
          let mut v949_11 = Space::new();
          let mut v949_11_cursor = (v946_7_tail).read_zipper();
          for v949_11_byte in v949_11_cursor.child_mask().iter() {
            v949_11_cursor.descend_to_byte(v949_11_byte);
            {
            let v949_11_tail = v949_11_cursor.fork_read_zipper();
            let v949_11_head = Path::from_slice(&[v949_11_byte]);
            let v950_2: Space = singleton(&(v949_11_head));
            let v950_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v950_2));
            drop(v950_2);
            let v950_4: Space = if map_kernels::has_head(&(v950_3)) { singleton(&[]) } else { Space::new() };
            drop(v950_3);
            let v950_7: Space = if (v950_4).is_empty() { Space::new() } else {
              let v951_5: Path = concat_path(&(v949_10),&(v949_11_head));
              let v951_6: Space = routine_44(c, &(v951_5), &(v949_11_tail).make_space(), &(*s1));
              drop(v951_5);
              map_map_kernels::compose(&(v950_4),&(v951_6))
            };
            drop(v950_4);
            v949_11.join_into((v950_7).clone());
            }
            v949_11_cursor.ascend(1);
          }
          drop(v949_11_cursor);
          drop(v949_10);
          map_map_kernels::compose(&(v947_9),&(v949_11))
        };
        drop(v947_9);
        let v947_13: Space = map_map_kernels::unite(&(v947_7),&(v947_12));
        drop(v947_7);
        v946_7.join_into((v947_13).clone());
        }
        v946_7_cursor.ascend(1);
      }
      drop(v946_7_cursor);
      drop(v946_6);
      map_map_kernels::compose(&(v945_5),&(v946_7))
    };
    drop(v945_5);
    let v945_9: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v945_2));
    drop(v945_2);
    let v945_10: Space = if map_kernels::has_head(&(v945_9)) { singleton(&[]) } else { Space::new() };
    drop(v945_9);
    let v945_13: Space = if (v945_10).is_empty() { Space::new() } else {
      let v952_11: Space = map_kernels::unwrap(&(v944_10),&(v944_16_head));
      let v952_12: Space = map_map_kernels::subtract(&(v952_11),&(*CONSTANT_5));
      drop(v952_11);
      map_map_kernels::compose(&(v945_10),&(v952_12))
    };
    drop(v945_10);
    let v945_14: Space = map_map_kernels::unite(&(v945_8),&(v945_13));
    drop(v945_13);
    v944_16.join_into((v945_14).clone());
    }
    v944_16_cursor.ascend(1);
  }
  drop(v944_16_cursor);
  drop(v944_10);
  (v944_16).clone()
}

fn routine_63(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v953_10: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v953_11: Space = map_kernels::unwrap(&(v953_10),&(*CONSTANT_4));
  drop(v953_10);
  let v953_12: Space = map_kernels::unwrap(&(v953_11),&(*p0));
  drop(v953_11);
  let mut v953_13 = Space::new();
  let mut v953_13_cursor = (*s0).read_zipper();
  for v953_13_byte in v953_13_cursor.child_mask().iter() {
    v953_13_cursor.descend_to_byte(v953_13_byte);
    {
    let v953_13_tail = v953_13_cursor.fork_read_zipper();
    let v953_13_head = Path::from_slice(&[v953_13_byte]);
    let v954_2: Space = singleton(&(v953_13_head));
    let v954_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v954_2));
    let v954_4: Space = if map_kernels::has_head(&(v954_3)) { singleton(&[]) } else { Space::new() };
    drop(v954_3);
    let v954_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v954_4));
    drop(v954_4);
    let mut v954_6 = Space::new();
    let mut v954_6_cursor = (v953_13_tail).read_zipper();
    for v954_6_byte in v954_6_cursor.child_mask().iter() {
      v954_6_cursor.descend_to_byte(v954_6_byte);
      {
      let v954_6_tail = v954_6_cursor.fork_read_zipper();
      let v954_6_head = Path::from_slice(&[v954_6_byte]);
      let v955_2: Space = Space::new();
      v954_6.join_into((v955_2).clone());
      }
      v954_6_cursor.ascend(1);
    }
    drop(v954_6_cursor);
    let v954_7: Space = map_map_kernels::compose(&(v954_5),&(v954_6));
    drop(v954_5);
    drop(v954_6);
    let v954_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v954_2));
    drop(v954_2);
    let v954_9: Space = if map_kernels::has_head(&(v954_8)) { singleton(&[]) } else { Space::new() };
    drop(v954_8);
    let v954_12: Space = if (v954_9).is_empty() { Space::new() } else {
      let v956_10: Space = map_kernels::unwrap(&(v953_12),&(v953_13_head));
      let mut v956_11 = Space::new();
      let mut v956_11_cursor = (v953_13_tail).read_zipper();
      for v956_11_byte in v956_11_cursor.child_mask().iter() {
        v956_11_cursor.descend_to_byte(v956_11_byte);
        {
        let v956_11_tail = v956_11_cursor.fork_read_zipper();
        let v956_11_head = Path::from_slice(&[v956_11_byte]);
        let v957_2: Space = singleton(&(v956_11_head));
        let v957_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v957_2));
        drop(v957_2);
        let v957_4: Space = if map_kernels::has_head(&(v957_3)) { singleton(&[]) } else { Space::new() };
        drop(v957_3);
        let v957_7: Space = if (v957_4).is_empty() { Space::new() } else {
          let v958_5: Space = map_kernels::unwrap(&(v956_10),&(v956_11_head));
          let v958_6: Space = map_map_kernels::subtract(&(v958_5),&(*CONSTANT_5));
          drop(v958_5);
          map_map_kernels::compose(&(v957_4),&(v958_6))
        };
        drop(v957_4);
        v956_11.join_into((v957_7).clone());
        }
        v956_11_cursor.ascend(1);
      }
      drop(v956_11_cursor);
      drop(v956_10);
      map_map_kernels::compose(&(v954_9),&(v956_11))
    };
    drop(v954_9);
    let v954_13: Space = map_map_kernels::unite(&(v954_7),&(v954_12));
    drop(v954_7);
    drop(v954_12);
    v953_13.join_into((v954_13).clone());
    }
    v953_13_cursor.ascend(1);
  }
  drop(v953_13_cursor);
  drop(v953_12);
  (v953_13).clone()
}

fn routine_64(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v959_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v959_9: Space = map_kernels::unwrap(&(v959_7),&(*CONSTANT_4));
  drop(v959_7);
  let v959_10: Space = map_kernels::unwrap(&(v959_9),&(*p0));
  drop(v959_9);
  let mut v959_12 = Space::new();
  let mut v959_12_cursor = (*s0).read_zipper();
  for v959_12_byte in v959_12_cursor.child_mask().iter() {
    v959_12_cursor.descend_to_byte(v959_12_byte);
    {
    let v959_12_tail = v959_12_cursor.fork_read_zipper();
    let v959_12_head = Path::from_slice(&[v959_12_byte]);
    let v960_2: Space = singleton(&(v959_12_head));
    let v960_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v960_2));
    let v960_4: Space = if map_kernels::has_head(&(v960_3)) { singleton(&[]) } else { Space::new() };
    drop(v960_3);
    let v960_5: Space = map_map_kernels::subtract(&(*CONSTANT_5),&(v960_4));
    drop(v960_4);
    let mut v960_6 = Space::new();
    let mut v960_6_cursor = (v959_12_tail).read_zipper();
    for v960_6_byte in v960_6_cursor.child_mask().iter() {
      v960_6_cursor.descend_to_byte(v960_6_byte);
      {
      let v960_6_tail = v960_6_cursor.fork_read_zipper();
      let v960_6_head = Path::from_slice(&[v960_6_byte]);
      let v961_2: Space = Space::new();
      v960_6.join_into((v961_2).clone());
      }
      v960_6_cursor.ascend(1);
    }
    drop(v960_6_cursor);
    let v960_7: Space = map_map_kernels::compose(&(v960_5),&(v960_6));
    drop(v960_5);
    drop(v960_6);
    let v960_8: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v960_2));
    drop(v960_2);
    let v960_9: Space = if map_kernels::has_head(&(v960_8)) { singleton(&[]) } else { Space::new() };
    drop(v960_8);
    let v960_12: Space = if (v960_9).is_empty() { Space::new() } else {
      let v962_10: Space = map_kernels::unwrap(&(v959_10),&(v959_12_head));
      let v962_11: Space = map_map_kernels::subtract(&(v962_10),&(*CONSTANT_5));
      drop(v962_10);
      map_map_kernels::compose(&(v960_9),&(v962_11))
    };
    drop(v960_9);
    let v960_13: Space = map_map_kernels::unite(&(v960_7),&(v960_12));
    drop(v960_7);
    drop(v960_12);
    v959_12.join_into((v960_13).clone());
    }
    v959_12_cursor.ascend(1);
  }
  drop(v959_12_cursor);
  drop(v959_10);
  (v959_12).clone()
}

fn routine_65(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v963_3 = Space::new();
  let mut v963_3_cursor = (*s0).read_zipper();
  for v963_3_byte in v963_3_cursor.child_mask().iter() {
    v963_3_cursor.descend_to_byte(v963_3_byte);
    {
    let v963_3_tail = v963_3_cursor.fork_read_zipper();
    let v963_3_head = Path::from_slice(&[v963_3_byte]);
    let v964_2: Space = Space::new();
    v963_3.join_into((v964_2).clone());
    }
    v963_3_cursor.ascend(1);
  }
  drop(v963_3_cursor);
  (v963_3).clone()
}

fn routine_66(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v965_5: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v965_7: Space = map_kernels::unwrap(&(v965_5),&(*CONSTANT_4));
  drop(v965_5);
  let v965_8: Space = map_kernels::unwrap(&(v965_7),&(*p0));
  drop(v965_7);
  let mut v965_10 = Space::new();
  let mut v965_10_cursor = (*s0).read_zipper();
  for v965_10_byte in v965_10_cursor.child_mask().iter() {
    v965_10_cursor.descend_to_byte(v965_10_byte);
    {
    let v965_10_tail = v965_10_cursor.fork_read_zipper();
    let v965_10_head = Path::from_slice(&[v965_10_byte]);
    let v966_2: Space = singleton(&(v965_10_head));
    let v966_3: Space = map_map_kernels::intersect(&(*CONSTANT_6),&(v966_2));
    drop(v966_2);
    let v966_4: Space = if map_kernels::has_head(&(v966_3)) { singleton(&[]) } else { Space::new() };
    drop(v966_3);
    let v966_7: Space = if (v966_4).is_empty() { Space::new() } else {
      let v967_5: Space = map_kernels::unwrap(&(v965_8),&(v965_10_head));
      let v967_6: Space = map_map_kernels::subtract(&(v967_5),&(*CONSTANT_5));
      drop(v967_5);
      map_map_kernels::compose(&(v966_4),&(v967_6))
    };
    drop(v966_4);
    v965_10.join_into((v966_7).clone());
    }
    v965_10_cursor.ascend(1);
  }
  drop(v965_10_cursor);
  drop(v965_8);
  (v965_10).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
