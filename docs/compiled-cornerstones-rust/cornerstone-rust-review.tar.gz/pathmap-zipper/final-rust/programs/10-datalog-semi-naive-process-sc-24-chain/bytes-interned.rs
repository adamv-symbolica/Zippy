#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("94 16 0 0 0 0 0 0 0 2 0 0 0 3 0 0 0 4 16 0 0 0 0 0 0 0 2 0 0 0 3 0 0 0 5 16 0 0 0 0 0 0 0 2 0 0 0 4 0 0 0 5 16 0 0 0 0 0 0 0 2 0 0 0 4 0 0 0 6 16 0 0 0 0 0 0 0 2 0 0 0 5 0 0 0 6 16 0 0 0 0 0 0 0 2 0 0 0 5 0 0 0 19 16 0 0 0 0 0 0 0 2 0 0 0 6 0 0 0 19 16 0 0 0 0 0 0 0 2 0 0 0 6 0 0 0 23 16 0 0 0 0 0 0 0 2 0 0 0 7 0 0 0 8 16 0 0 0 0 0 0 0 2 0 0 0 7 0 0 0 9 16 0 0 0 0 0 0 0 2 0 0 0 8 0 0 0 9 16 0 0 0 0 0 0 0 2 0 0 0 8 0 0 0 10 16 0 0 0 0 0 0 0 2 0 0 0 9 0 0 0 10 16 0 0 0 0 0 0 0 2 0 0 0 9 0 0 0 11 16 0 0 0 0 0 0 0 2 0 0 0 10 0 0 0 11 16 0 0 0 0 0 0 0 2 0 0 0 10 0 0 0 12 16 0 0 0 0 0 0 0 2 0 0 0 11 0 0 0 12 16 0 0 0 0 0 0 0 2 0 0 0 11 0 0 0 13 16 0 0 0 0 0 0 0 2 0 0 0 12 0 0 0 13 16 0 0 0 0 0 0 0 2 0 0 0 12 0 0 0 14 16 0 0 0 0 0 0 0 2 0 0 0 13 0 0 0 14 16 0 0 0 0 0 0 0 2 0 0 0 13 0 0 0 15 16 0 0 0 0 0 0 0 2 0 0 0 14 0 0 0 15 16 0 0 0 0 0 0 0 2 0 0 0 14 0 0 0 16 16 0 0 0 0 0 0 0 2 0 0 0 15 0 0 0 16 16 0 0 0 0 0 0 0 2 0 0 0 15 0 0 0 17 16 0 0 0 0 0 0 0 2 0 0 0 16 0 0 0 17 16 0 0 0 0 0 0 0 2 0 0 0 16 0 0 0 18 16 0 0 0 0 0 0 0 2 0 0 0 17 0 0 0 18 16 0 0 0 0 0 0 0 2 0 0 0 17 0 0 0 20 16 0 0 0 0 0 0 0 2 0 0 0 18 0 0 0 20 16 0 0 0 0 0 0 0 2 0 0 0 18 0 0 0 21 16 0 0 0 0 0 0 0 2 0 0 0 19 0 0 0 23 16 0 0 0 0 0 0 0 2 0 0 0 19 0 0 0 24 16 0 0 0 0 0 0 0 2 0 0 0 20 0 0 0 21 16 0 0 0 0 0 0 0 2 0 0 0 20 0 0 0 22 16 0 0 0 0 0 0 0 2 0 0 0 21 0 0 0 22 16 0 0 0 0 0 0 0 2 0 0 0 23 0 0 0 24 16 0 0 0 0 0 0 0 2 0 0 0 23 0 0 0 25 16 0 0 0 0 0 0 0 2 0 0 0 24 0 0 0 25 16 0 0 0 0 0 0 0 2 0 0 0 24 0 0 0 26 16 0 0 0 0 0 0 0 2 0 0 0 25 0 0 0 26 16 0 0 0 0 0 0 0 2 0 0 0 25 0 0 0 27 16 0 0 0 0 0 0 0 2 0 0 0 26 0 0 0 7 16 0 0 0 0 0 0 0 2 0 0 0 26 0 0 0 27 16 0 0 0 0 0 0 0 2 0 0 0 27 0 0 0 7 16 0 0 0 0 0 0 0 2 0 0 0 27 0 0 0 8 16 0 0 0 28 0 0 0 1 0 0 0 3 0 0 0 4 16 0 0 0 28 0 0 0 1 0 0 0 3 0 0 0 5 16 0 0 0 28 0 0 0 1 0 0 0 4 0 0 0 5 16 0 0 0 28 0 0 0 1 0 0 0 4 0 0 0 6 16 0 0 0 28 0 0 0 1 0 0 0 5 0 0 0 6 16 0 0 0 28 0 0 0 1 0 0 0 5 0 0 0 19 16 0 0 0 28 0 0 0 1 0 0 0 6 0 0 0 19 16 0 0 0 28 0 0 0 1 0 0 0 6 0 0 0 23 16 0 0 0 28 0 0 0 1 0 0 0 7 0 0 0 8 16 0 0 0 28 0 0 0 1 0 0 0 7 0 0 0 9 16 0 0 0 28 0 0 0 1 0 0 0 8 0 0 0 9 16 0 0 0 28 0 0 0 1 0 0 0 8 0 0 0 10 16 0 0 0 28 0 0 0 1 0 0 0 9 0 0 0 10 16 0 0 0 28 0 0 0 1 0 0 0 9 0 0 0 11 16 0 0 0 28 0 0 0 1 0 0 0 10 0 0 0 11 16 0 0 0 28 0 0 0 1 0 0 0 10 0 0 0 12 16 0 0 0 28 0 0 0 1 0 0 0 11 0 0 0 12 16 0 0 0 28 0 0 0 1 0 0 0 11 0 0 0 13 16 0 0 0 28 0 0 0 1 0 0 0 12 0 0 0 13 16 0 0 0 28 0 0 0 1 0 0 0 12 0 0 0 14 16 0 0 0 28 0 0 0 1 0 0 0 13 0 0 0 14 16 0 0 0 28 0 0 0 1 0 0 0 13 0 0 0 15 16 0 0 0 28 0 0 0 1 0 0 0 14 0 0 0 15 16 0 0 0 28 0 0 0 1 0 0 0 14 0 0 0 16 16 0 0 0 28 0 0 0 1 0 0 0 15 0 0 0 16 16 0 0 0 28 0 0 0 1 0 0 0 15 0 0 0 17 16 0 0 0 28 0 0 0 1 0 0 0 16 0 0 0 17 16 0 0 0 28 0 0 0 1 0 0 0 16 0 0 0 18 16 0 0 0 28 0 0 0 1 0 0 0 17 0 0 0 18 16 0 0 0 28 0 0 0 1 0 0 0 17 0 0 0 20 16 0 0 0 28 0 0 0 1 0 0 0 18 0 0 0 20 16 0 0 0 28 0 0 0 1 0 0 0 18 0 0 0 21 16 0 0 0 28 0 0 0 1 0 0 0 19 0 0 0 23 16 0 0 0 28 0 0 0 1 0 0 0 19 0 0 0 24 16 0 0 0 28 0 0 0 1 0 0 0 20 0 0 0 21 16 0 0 0 28 0 0 0 1 0 0 0 20 0 0 0 22 16 0 0 0 28 0 0 0 1 0 0 0 21 0 0 0 22 16 0 0 0 28 0 0 0 1 0 0 0 23 0 0 0 24 16 0 0 0 28 0 0 0 1 0 0 0 23 0 0 0 25 16 0 0 0 28 0 0 0 1 0 0 0 24 0 0 0 25 16 0 0 0 28 0 0 0 1 0 0 0 24 0 0 0 26 16 0 0 0 28 0 0 0 1 0 0 0 25 0 0 0 26 16 0 0 0 28 0 0 0 1 0 0 0 25 0 0 0 27 16 0 0 0 28 0 0 0 1 0 0 0 26 0 0 0 7 16 0 0 0 28 0 0 0 1 0 0 0 26 0 0 0 27 16 0 0 0 28 0 0 0 1 0 0 0 27 0 0 0 7 16 0 0 0 28 0 0 0 1 0 0 0 27 0 0 0 8"));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("184 16 0 0 0 0 0 0 0 1 0 0 0 3 0 0 0 4 16 0 0 0 0 0 0 0 1 0 0 0 3 0 0 0 5 16 0 0 0 0 0 0 0 1 0 0 0 4 0 0 0 5 16 0 0 0 0 0 0 0 1 0 0 0 4 0 0 0 6 16 0 0 0 0 0 0 0 1 0 0 0 5 0 0 0 6 16 0 0 0 0 0 0 0 1 0 0 0 5 0 0 0 19 16 0 0 0 0 0 0 0 1 0 0 0 6 0 0 0 19 16 0 0 0 0 0 0 0 1 0 0 0 6 0 0 0 23 16 0 0 0 0 0 0 0 1 0 0 0 7 0 0 0 8 16 0 0 0 0 0 0 0 1 0 0 0 7 0 0 0 9 16 0 0 0 0 0 0 0 1 0 0 0 8 0 0 0 9 16 0 0 0 0 0 0 0 1 0 0 0 8 0 0 0 10 16 0 0 0 0 0 0 0 1 0 0 0 9 0 0 0 10 16 0 0 0 0 0 0 0 1 0 0 0 9 0 0 0 11 16 0 0 0 0 0 0 0 1 0 0 0 10 0 0 0 11 16 0 0 0 0 0 0 0 1 0 0 0 10 0 0 0 12 16 0 0 0 0 0 0 0 1 0 0 0 11 0 0 0 12 16 0 0 0 0 0 0 0 1 0 0 0 11 0 0 0 13 16 0 0 0 0 0 0 0 1 0 0 0 12 0 0 0 13 16 0 0 0 0 0 0 0 1 0 0 0 12 0 0 0 14 16 0 0 0 0 0 0 0 1 0 0 0 13 0 0 0 14 16 0 0 0 0 0 0 0 1 0 0 0 13 0 0 0 15 16 0 0 0 0 0 0 0 1 0 0 0 14 0 0 0 15 16 0 0 0 0 0 0 0 1 0 0 0 14 0 0 0 16 16 0 0 0 0 0 0 0 1 0 0 0 15 0 0 0 16 16 0 0 0 0 0 0 0 1 0 0 0 15 0 0 0 17 16 0 0 0 0 0 0 0 1 0 0 0 16 0 0 0 17 16 0 0 0 0 0 0 0 1 0 0 0 16 0 0 0 18 16 0 0 0 0 0 0 0 1 0 0 0 17 0 0 0 18 16 0 0 0 0 0 0 0 1 0 0 0 17 0 0 0 20 16 0 0 0 0 0 0 0 1 0 0 0 18 0 0 0 20 16 0 0 0 0 0 0 0 1 0 0 0 18 0 0 0 21 16 0 0 0 0 0 0 0 1 0 0 0 19 0 0 0 23 16 0 0 0 0 0 0 0 1 0 0 0 19 0 0 0 24 16 0 0 0 0 0 0 0 1 0 0 0 20 0 0 0 21 16 0 0 0 0 0 0 0 1 0 0 0 20 0 0 0 22 16 0 0 0 0 0 0 0 1 0 0 0 21 0 0 0 22 16 0 0 0 0 0 0 0 1 0 0 0 23 0 0 0 24 16 0 0 0 0 0 0 0 1 0 0 0 23 0 0 0 25 16 0 0 0 0 0 0 0 1 0 0 0 24 0 0 0 25 16 0 0 0 0 0 0 0 1 0 0 0 24 0 0 0 26 16 0 0 0 0 0 0 0 1 0 0 0 25 0 0 0 26 16 0 0 0 0 0 0 0 1 0 0 0 25 0 0 0 27 16 0 0 0 0 0 0 0 1 0 0 0 26 0 0 0 7 16 0 0 0 0 0 0 0 1 0 0 0 26 0 0 0 27 16 0 0 0 0 0 0 0 1 0 0 0 27 0 0 0 7 16 0 0 0 0 0 0 0 1 0 0 0 27 0 0 0 8 16 0 0 0 0 0 0 0 2 0 0 0 3 0 0 0 4 16 0 0 0 0 0 0 0 2 0 0 0 3 0 0 0 5 16 0 0 0 0 0 0 0 2 0 0 0 4 0 0 0 5 16 0 0 0 0 0 0 0 2 0 0 0 4 0 0 0 6 16 0 0 0 0 0 0 0 2 0 0 0 5 0 0 0 6 16 0 0 0 0 0 0 0 2 0 0 0 5 0 0 0 19 16 0 0 0 0 0 0 0 2 0 0 0 6 0 0 0 19 16 0 0 0 0 0 0 0 2 0 0 0 6 0 0 0 23 16 0 0 0 0 0 0 0 2 0 0 0 7 0 0 0 8 16 0 0 0 0 0 0 0 2 0 0 0 7 0 0 0 9 16 0 0 0 0 0 0 0 2 0 0 0 8 0 0 0 9 16 0 0 0 0 0 0 0 2 0 0 0 8 0 0 0 10 16 0 0 0 0 0 0 0 2 0 0 0 9 0 0 0 10 16 0 0 0 0 0 0 0 2 0 0 0 9 0 0 0 11 16 0 0 0 0 0 0 0 2 0 0 0 10 0 0 0 11 16 0 0 0 0 0 0 0 2 0 0 0 10 0 0 0 12 16 0 0 0 0 0 0 0 2 0 0 0 11 0 0 0 12 16 0 0 0 0 0 0 0 2 0 0 0 11 0 0 0 13 16 0 0 0 0 0 0 0 2 0 0 0 12 0 0 0 13 16 0 0 0 0 0 0 0 2 0 0 0 12 0 0 0 14 16 0 0 0 0 0 0 0 2 0 0 0 13 0 0 0 14 16 0 0 0 0 0 0 0 2 0 0 0 13 0 0 0 15 16 0 0 0 0 0 0 0 2 0 0 0 14 0 0 0 15 16 0 0 0 0 0 0 0 2 0 0 0 14 0 0 0 16 16 0 0 0 0 0 0 0 2 0 0 0 15 0 0 0 16 16 0 0 0 0 0 0 0 2 0 0 0 15 0 0 0 17 16 0 0 0 0 0 0 0 2 0 0 0 16 0 0 0 17 16 0 0 0 0 0 0 0 2 0 0 0 16 0 0 0 18 16 0 0 0 0 0 0 0 2 0 0 0 17 0 0 0 18 16 0 0 0 0 0 0 0 2 0 0 0 17 0 0 0 20 16 0 0 0 0 0 0 0 2 0 0 0 18 0 0 0 20 16 0 0 0 0 0 0 0 2 0 0 0 18 0 0 0 21 16 0 0 0 0 0 0 0 2 0 0 0 19 0 0 0 23 16 0 0 0 0 0 0 0 2 0 0 0 19 0 0 0 24 16 0 0 0 0 0 0 0 2 0 0 0 20 0 0 0 21 16 0 0 0 0 0 0 0 2 0 0 0 20 0 0 0 22 16 0 0 0 0 0 0 0 2 0 0 0 21 0 0 0 22 16 0 0 0 0 0 0 0 2 0 0 0 23 0 0 0 24 16 0 0 0 0 0 0 0 2 0 0 0 23 0 0 0 25 16 0 0 0 0 0 0 0 2 0 0 0 24 0 0 0 25 16 0 0 0 0 0 0 0 2 0 0 0 24 0 0 0 26 16 0 0 0 0 0 0 0 2 0 0 0 25 0 0 0 26 16 0 0 0 0 0 0 0 2 0 0 0 25 0 0 0 27 16 0 0 0 0 0 0 0 2 0 0 0 26 0 0 0 7 16 0 0 0 0 0 0 0 2 0 0 0 26 0 0 0 27 16 0 0 0 0 0 0 0 2 0 0 0 27 0 0 0 7 16 0 0 0 0 0 0 0 2 0 0 0 27 0 0 0 8 16 0 0 0 28 0 0 0 1 0 0 0 3 0 0 0 4 16 0 0 0 28 0 0 0 1 0 0 0 3 0 0 0 5 16 0 0 0 28 0 0 0 1 0 0 0 3 0 0 0 6 16 0 0 0 28 0 0 0 1 0 0 0 3 0 0 0 19 16 0 0 0 28 0 0 0 1 0 0 0 4 0 0 0 5 16 0 0 0 28 0 0 0 1 0 0 0 4 0 0 0 6 16 0 0 0 28 0 0 0 1 0 0 0 4 0 0 0 19 16 0 0 0 28 0 0 0 1 0 0 0 4 0 0 0 23 16 0 0 0 28 0 0 0 1 0 0 0 5 0 0 0 6 16 0 0 0 28 0 0 0 1 0 0 0 5 0 0 0 19 16 0 0 0 28 0 0 0 1 0 0 0 5 0 0 0 23 16 0 0 0 28 0 0 0 1 0 0 0 5 0 0 0 24 16 0 0 0 28 0 0 0 1 0 0 0 6 0 0 0 19 16 0 0 0 28 0 0 0 1 0 0 0 6 0 0 0 23 16 0 0 0 28 0 0 0 1 0 0 0 6 0 0 0 24 16 0 0 0 28 0 0 0 1 0 0 0 6 0 0 0 25 16 0 0 0 28 0 0 0 1 0 0 0 7 0 0 0 8 16 0 0 0 28 0 0 0 1 0 0 0 7 0 0 0 9 16 0 0 0 28 0 0 0 1 0 0 0 7 0 0 0 10 16 0 0 0 28 0 0 0 1 0 0 0 7 0 0 0 11 16 0 0 0 28 0 0 0 1 0 0 0 8 0 0 0 9 16 0 0 0 28 0 0 0 1 0 0 0 8 0 0 0 10 16 0 0 0 28 0 0 0 1 0 0 0 8 0 0 0 11 16 0 0 0 28 0 0 0 1 0 0 0 8 0 0 0 12 16 0 0 0 28 0 0 0 1 0 0 0 9 0 0 0 10 16 0 0 0 28 0 0 0 1 0 0 0 9 0 0 0 11 16 0 0 0 28 0 0 0 1 0 0 0 9 0 0 0 12 16 0 0 0 28 0 0 0 1 0 0 0 9 0 0 0 13 16 0 0 0 28 0 0 0 1 0 0 0 10 0 0 0 11 16 0 0 0 28 0 0 0 1 0 0 0 10 0 0 0 12 16 0 0 0 28 0 0 0 1 0 0 0 10 0 0 0 13 16 0 0 0 28 0 0 0 1 0 0 0 10 0 0 0 14 16 0 0 0 28 0 0 0 1 0 0 0 11 0 0 0 12 16 0 0 0 28 0 0 0 1 0 0 0 11 0 0 0 13 16 0 0 0 28 0 0 0 1 0 0 0 11 0 0 0 14 16 0 0 0 28 0 0 0 1 0 0 0 11 0 0 0 15 16 0 0 0 28 0 0 0 1 0 0 0 12 0 0 0 13 16 0 0 0 28 0 0 0 1 0 0 0 12 0 0 0 14 16 0 0 0 28 0 0 0 1 0 0 0 12 0 0 0 15 16 0 0 0 28 0 0 0 1 0 0 0 12 0 0 0 16 16 0 0 0 28 0 0 0 1 0 0 0 13 0 0 0 14 16 0 0 0 28 0 0 0 1 0 0 0 13 0 0 0 15 16 0 0 0 28 0 0 0 1 0 0 0 13 0 0 0 16 16 0 0 0 28 0 0 0 1 0 0 0 13 0 0 0 17 16 0 0 0 28 0 0 0 1 0 0 0 14 0 0 0 15 16 0 0 0 28 0 0 0 1 0 0 0 14 0 0 0 16 16 0 0 0 28 0 0 0 1 0 0 0 14 0 0 0 17 16 0 0 0 28 0 0 0 1 0 0 0 14 0 0 0 18 16 0 0 0 28 0 0 0 1 0 0 0 15 0 0 0 16 16 0 0 0 28 0 0 0 1 0 0 0 15 0 0 0 17 16 0 0 0 28 0 0 0 1 0 0 0 15 0 0 0 18 16 0 0 0 28 0 0 0 1 0 0 0 15 0 0 0 20 16 0 0 0 28 0 0 0 1 0 0 0 16 0 0 0 17 16 0 0 0 28 0 0 0 1 0 0 0 16 0 0 0 18 16 0 0 0 28 0 0 0 1 0 0 0 16 0 0 0 20 16 0 0 0 28 0 0 0 1 0 0 0 16 0 0 0 21 16 0 0 0 28 0 0 0 1 0 0 0 17 0 0 0 18 16 0 0 0 28 0 0 0 1 0 0 0 17 0 0 0 20 16 0 0 0 28 0 0 0 1 0 0 0 17 0 0 0 21 16 0 0 0 28 0 0 0 1 0 0 0 17 0 0 0 22 16 0 0 0 28 0 0 0 1 0 0 0 18 0 0 0 20 16 0 0 0 28 0 0 0 1 0 0 0 18 0 0 0 21 16 0 0 0 28 0 0 0 1 0 0 0 18 0 0 0 22 16 0 0 0 28 0 0 0 1 0 0 0 19 0 0 0 23 16 0 0 0 28 0 0 0 1 0 0 0 19 0 0 0 24 16 0 0 0 28 0 0 0 1 0 0 0 19 0 0 0 25 16 0 0 0 28 0 0 0 1 0 0 0 19 0 0 0 26 16 0 0 0 28 0 0 0 1 0 0 0 20 0 0 0 21 16 0 0 0 28 0 0 0 1 0 0 0 20 0 0 0 22 16 0 0 0 28 0 0 0 1 0 0 0 21 0 0 0 22 16 0 0 0 28 0 0 0 1 0 0 0 23 0 0 0 24 16 0 0 0 28 0 0 0 1 0 0 0 23 0 0 0 25 16 0 0 0 28 0 0 0 1 0 0 0 23 0 0 0 26 16 0 0 0 28 0 0 0 1 0 0 0 23 0 0 0 27 16 0 0 0 28 0 0 0 1 0 0 0 24 0 0 0 7 16 0 0 0 28 0 0 0 1 0 0 0 24 0 0 0 25 16 0 0 0 28 0 0 0 1 0 0 0 24 0 0 0 26 16 0 0 0 28 0 0 0 1 0 0 0 24 0 0 0 27 16 0 0 0 28 0 0 0 1 0 0 0 25 0 0 0 7 16 0 0 0 28 0 0 0 1 0 0 0 25 0 0 0 8 16 0 0 0 28 0 0 0 1 0 0 0 25 0 0 0 26 16 0 0 0 28 0 0 0 1 0 0 0 25 0 0 0 27 16 0 0 0 28 0 0 0 1 0 0 0 26 0 0 0 7 16 0 0 0 28 0 0 0 1 0 0 0 26 0 0 0 8 16 0 0 0 28 0 0 0 1 0 0 0 26 0 0 0 9 16 0 0 0 28 0 0 0 1 0 0 0 26 0 0 0 27 16 0 0 0 28 0 0 0 1 0 0 0 27 0 0 0 7 16 0 0 0 28 0 0 0 1 0 0 0 27 0 0 0 8 16 0 0 0 28 0 0 0 1 0 0 0 27 0 0 0 9 16 0 0 0 28 0 0 0 1 0 0 0 27 0 0 0 10"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,0,0,0,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,28]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,28,0,0,0,1]));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v1_2: Space = unwrap(&(*capture_0),&(*CONSTANT_3));
  let v1_4: Space = unwrap(&(*capture_0),&(*CONSTANT_4));
  let v1_5: Space = unite(&(v1_2),&(v1_4));
  let v1_6: Space = wrap(&(v1_5),&(*CONSTANT_3));
  drop(v1_5);
  let v1_8: Space = unwrap(&(v1_2),&(*CONSTANT_5));
  let mut v1_9 = Space::new();
  let mut v1_9_cursor = (v1_8).read_zipper();
  for v1_9_byte in v1_9_cursor.child_mask().iter() {
    v1_9_cursor.descend_to_byte(v1_9_byte);
    {
    let v1_9_tail = v1_9_cursor.fork_read_zipper();
    let v1_9_head = Path::from_slice(&[v1_9_byte]);
    let mut v2_2 = Space::new();
    let mut v2_2_cursor = (v1_9_tail).read_zipper();
    for v2_2_byte in v2_2_cursor.child_mask().iter() {
      v2_2_cursor.descend_to_byte(v2_2_byte);
      {
      let v2_2_tail = v2_2_cursor.fork_read_zipper();
      let v2_2_head = Path::from_slice(&[v2_2_byte]);
      let v3_2: Path = concat_path(&(v1_9_head),&(v2_2_head));
      let mut v3_3 = Space::new();
      let mut v3_3_cursor = (v2_2_tail).read_zipper();
      for v3_3_byte in v3_3_cursor.child_mask().iter() {
        v3_3_cursor.descend_to_byte(v3_3_byte);
        {
        let v3_3_tail = v3_3_cursor.fork_read_zipper();
        let v3_3_head = Path::from_slice(&[v3_3_byte]);
        let v4_2: Path = concat_path(&(v3_2),&(v3_3_head));
        let mut v4_3 = Space::new();
        let mut v4_3_cursor = (v3_3_tail).read_zipper();
        for v4_3_byte in v4_3_cursor.child_mask().iter() {
          v4_3_cursor.descend_to_byte(v4_3_byte);
          {
          let v4_3_tail = v4_3_cursor.fork_read_zipper();
          let v4_3_head = Path::from_slice(&[v4_3_byte]);
          let mut v5_2 = Space::new();
          let mut v5_2_cursor = (v4_3_tail).read_zipper();
          for v5_2_byte in v5_2_cursor.child_mask().iter() {
            v5_2_cursor.descend_to_byte(v5_2_byte);
            {
            let v5_2_tail = v5_2_cursor.fork_read_zipper();
            let v5_2_head = Path::from_slice(&[v5_2_byte]);
            let mut v6_2 = Space::new();
            let mut v6_2_cursor = (v5_2_tail).read_zipper();
            for v6_2_byte in v6_2_cursor.child_mask().iter() {
              v6_2_cursor.descend_to_byte(v6_2_byte);
              {
              let v6_2_tail = v6_2_cursor.fork_read_zipper();
              let v6_2_head = Path::from_slice(&[v6_2_byte]);
              let v7_2: Path = concat_path(&(v5_2_head),&(v6_2_head));
              let mut v7_3 = Space::new();
              let mut v7_3_cursor = (v6_2_tail).read_zipper();
              for v7_3_byte in v7_3_cursor.child_mask().iter() {
                v7_3_cursor.descend_to_byte(v7_3_byte);
                {
                let v7_3_tail = v7_3_cursor.fork_read_zipper();
                let v7_3_head = Path::from_slice(&[v7_3_byte]);
                let v8_2: Path = concat_path(&(v7_2),&(v7_3_head));
                let mut v8_3 = Space::new();
                let mut v8_3_cursor = (v7_3_tail).read_zipper();
                for v8_3_byte in v8_3_cursor.child_mask().iter() {
                  v8_3_cursor.descend_to_byte(v8_3_byte);
                  {
                  let v8_3_tail = v8_3_cursor.fork_read_zipper();
                  let v8_3_head = Path::from_slice(&[v8_3_byte]);
                  let v9_2: Path = concat_path(&(v8_2),&(v8_3_head));
                  let v9_3: Space = routine_2(c, &(v9_2), &(v8_3_tail).make_space(), &(*capture_0));
                  drop(v9_2);
                  v8_3.join_into((v9_3).clone());
                  }
                  v8_3_cursor.ascend(1);
                }
                drop(v8_3_cursor);
                drop(v8_2);
                v7_3.join_into((v8_3).clone());
                }
                v7_3_cursor.ascend(1);
              }
              drop(v7_3_cursor);
              drop(v7_2);
              v6_2.join_into((v7_3).clone());
              }
              v6_2_cursor.ascend(1);
            }
            drop(v6_2_cursor);
            v5_2.join_into((v6_2).clone());
            }
            v5_2_cursor.ascend(1);
          }
          drop(v5_2_cursor);
          let v5_3: Path = concat_path(&(v4_2),&(v4_3_head));
          let v5_4: Space = wrap(&(v5_2),&(v5_3));
          drop(v5_3);
          v4_3.join_into((v5_4).clone());
          }
          v4_3_cursor.ascend(1);
        }
        drop(v4_3_cursor);
        drop(v4_2);
        v3_3.join_into((v4_3).clone());
        }
        v3_3_cursor.ascend(1);
      }
      drop(v3_3_cursor);
      drop(v3_2);
      v2_2.join_into((v3_3).clone());
      }
      v2_2_cursor.ascend(1);
    }
    drop(v2_2_cursor);
    v1_9.join_into((v2_2).clone());
    }
    v1_9_cursor.ascend(1);
  }
  drop(v1_9_cursor);
  drop(v1_8);
  let v1_11: Space = unwrap(&(v1_2),&(*CONSTANT_6));
  drop(v1_2);
  let mut v1_13 = Space::new();
  let mut v1_13_cursor = (v1_11).read_zipper();
  for v1_13_byte in v1_13_cursor.child_mask().iter() {
    v1_13_cursor.descend_to_byte(v1_13_byte);
    {
    let v1_13_tail = v1_13_cursor.fork_read_zipper();
    let v1_13_head = Path::from_slice(&[v1_13_byte]);
    let mut v10_2 = Space::new();
    let mut v10_2_cursor = (v1_13_tail).read_zipper();
    for v10_2_byte in v10_2_cursor.child_mask().iter() {
      v10_2_cursor.descend_to_byte(v10_2_byte);
      {
      let v10_2_tail = v10_2_cursor.fork_read_zipper();
      let v10_2_head = Path::from_slice(&[v10_2_byte]);
      let v11_2: Path = concat_path(&(v1_13_head),&(v10_2_head));
      let mut v11_3 = Space::new();
      let mut v11_3_cursor = (v10_2_tail).read_zipper();
      for v11_3_byte in v11_3_cursor.child_mask().iter() {
        v11_3_cursor.descend_to_byte(v11_3_byte);
        {
        let v11_3_tail = v11_3_cursor.fork_read_zipper();
        let v11_3_head = Path::from_slice(&[v11_3_byte]);
        let v12_2: Path = concat_path(&(v11_2),&(v11_3_head));
        let mut v12_3 = Space::new();
        let mut v12_3_cursor = (v11_3_tail).read_zipper();
        for v12_3_byte in v12_3_cursor.child_mask().iter() {
          v12_3_cursor.descend_to_byte(v12_3_byte);
          {
          let v12_3_tail = v12_3_cursor.fork_read_zipper();
          let v12_3_head = Path::from_slice(&[v12_3_byte]);
          let v13_2: Space = subtract(&(v12_3_tail),&(*CONSTANT_7));
          let v13_3: Path = concat_path(&(v12_2),&(v12_3_head));
          let v13_4: Space = wrap(&(v13_2),&(v13_3));
          drop(v13_2);
          drop(v13_3);
          v12_3.join_into((v13_4).clone());
          }
          v12_3_cursor.ascend(1);
        }
        drop(v12_3_cursor);
        drop(v12_2);
        v11_3.join_into((v12_3).clone());
        }
        v11_3_cursor.ascend(1);
      }
      drop(v11_3_cursor);
      drop(v11_2);
      v10_2.join_into((v11_3).clone());
      }
      v10_2_cursor.ascend(1);
    }
    drop(v10_2_cursor);
    v1_13.join_into((v10_2).clone());
    }
    v1_13_cursor.ascend(1);
  }
  drop(v1_13_cursor);
  drop(v1_11);
  let v1_14: Space = unite(&(v1_9),&(v1_13));
  drop(v1_13);
  let v1_15: Space = unwrap(&(v1_4),&(*CONSTANT_5));
  drop(v1_4);
  let mut v1_16 = Space::new();
  let mut v1_16_cursor = (v1_15).read_zipper();
  for v1_16_byte in v1_16_cursor.child_mask().iter() {
    v1_16_cursor.descend_to_byte(v1_16_byte);
    {
    let v1_16_tail = v1_16_cursor.fork_read_zipper();
    let v1_16_head = Path::from_slice(&[v1_16_byte]);
    let mut v14_2 = Space::new();
    let mut v14_2_cursor = (v1_16_tail).read_zipper();
    for v14_2_byte in v14_2_cursor.child_mask().iter() {
      v14_2_cursor.descend_to_byte(v14_2_byte);
      {
      let v14_2_tail = v14_2_cursor.fork_read_zipper();
      let v14_2_head = Path::from_slice(&[v14_2_byte]);
      let v15_2: Path = concat_path(&(v1_16_head),&(v14_2_head));
      let mut v15_3 = Space::new();
      let mut v15_3_cursor = (v14_2_tail).read_zipper();
      for v15_3_byte in v15_3_cursor.child_mask().iter() {
        v15_3_cursor.descend_to_byte(v15_3_byte);
        {
        let v15_3_tail = v15_3_cursor.fork_read_zipper();
        let v15_3_head = Path::from_slice(&[v15_3_byte]);
        let v16_2: Path = concat_path(&(v15_2),&(v15_3_head));
        let mut v16_3 = Space::new();
        let mut v16_3_cursor = (v15_3_tail).read_zipper();
        for v16_3_byte in v16_3_cursor.child_mask().iter() {
          v16_3_cursor.descend_to_byte(v16_3_byte);
          {
          let v16_3_tail = v16_3_cursor.fork_read_zipper();
          let v16_3_head = Path::from_slice(&[v16_3_byte]);
          let mut v17_2 = Space::new();
          let mut v17_2_cursor = (v16_3_tail).read_zipper();
          for v17_2_byte in v17_2_cursor.child_mask().iter() {
            v17_2_cursor.descend_to_byte(v17_2_byte);
            {
            let v17_2_tail = v17_2_cursor.fork_read_zipper();
            let v17_2_head = Path::from_slice(&[v17_2_byte]);
            let mut v18_2 = Space::new();
            let mut v18_2_cursor = (v17_2_tail).read_zipper();
            for v18_2_byte in v18_2_cursor.child_mask().iter() {
              v18_2_cursor.descend_to_byte(v18_2_byte);
              {
              let v18_2_tail = v18_2_cursor.fork_read_zipper();
              let v18_2_head = Path::from_slice(&[v18_2_byte]);
              let v19_2: Path = concat_path(&(v17_2_head),&(v18_2_head));
              let mut v19_3 = Space::new();
              let mut v19_3_cursor = (v18_2_tail).read_zipper();
              for v19_3_byte in v19_3_cursor.child_mask().iter() {
                v19_3_cursor.descend_to_byte(v19_3_byte);
                {
                let v19_3_tail = v19_3_cursor.fork_read_zipper();
                let v19_3_head = Path::from_slice(&[v19_3_byte]);
                let v20_2: Path = concat_path(&(v19_2),&(v19_3_head));
                let mut v20_3 = Space::new();
                let mut v20_3_cursor = (v19_3_tail).read_zipper();
                for v20_3_byte in v20_3_cursor.child_mask().iter() {
                  v20_3_cursor.descend_to_byte(v20_3_byte);
                  {
                  let v20_3_tail = v20_3_cursor.fork_read_zipper();
                  let v20_3_head = Path::from_slice(&[v20_3_byte]);
                  let v21_2: Path = concat_path(&(v20_2),&(v20_3_head));
                  let v21_3: Space = routine_3(c, &(v21_2), &(v20_3_tail).make_space(), &(*capture_0));
                  drop(v21_2);
                  v20_3.join_into((v21_3).clone());
                  }
                  v20_3_cursor.ascend(1);
                }
                drop(v20_3_cursor);
                drop(v20_2);
                v19_3.join_into((v20_3).clone());
                }
                v19_3_cursor.ascend(1);
              }
              drop(v19_3_cursor);
              drop(v19_2);
              v18_2.join_into((v19_3).clone());
              }
              v18_2_cursor.ascend(1);
            }
            drop(v18_2_cursor);
            v17_2.join_into((v18_2).clone());
            }
            v17_2_cursor.ascend(1);
          }
          drop(v17_2_cursor);
          let v17_3: Path = concat_path(&(v16_2),&(v16_3_head));
          let v17_4: Space = wrap(&(v17_2),&(v17_3));
          drop(v17_3);
          v16_3.join_into((v17_4).clone());
          }
          v16_3_cursor.ascend(1);
        }
        drop(v16_3_cursor);
        drop(v16_2);
        v15_3.join_into((v16_3).clone());
        }
        v15_3_cursor.ascend(1);
      }
      drop(v15_3_cursor);
      drop(v15_2);
      v14_2.join_into((v15_3).clone());
      }
      v14_2_cursor.ascend(1);
    }
    drop(v14_2_cursor);
    v1_16.join_into((v14_2).clone());
    }
    v1_16_cursor.ascend(1);
  }
  drop(v1_16_cursor);
  let v1_17: Space = unite(&(v1_14),&(v1_16));
  let mut v1_18 = Space::new();
  let mut v1_18_cursor = (v1_15).read_zipper();
  for v1_18_byte in v1_18_cursor.child_mask().iter() {
    v1_18_cursor.descend_to_byte(v1_18_byte);
    {
    let v1_18_tail = v1_18_cursor.fork_read_zipper();
    let v1_18_head = Path::from_slice(&[v1_18_byte]);
    let mut v22_2 = Space::new();
    let mut v22_2_cursor = (v1_18_tail).read_zipper();
    for v22_2_byte in v22_2_cursor.child_mask().iter() {
      v22_2_cursor.descend_to_byte(v22_2_byte);
      {
      let v22_2_tail = v22_2_cursor.fork_read_zipper();
      let v22_2_head = Path::from_slice(&[v22_2_byte]);
      let v23_2: Path = concat_path(&(v1_18_head),&(v22_2_head));
      let mut v23_3 = Space::new();
      let mut v23_3_cursor = (v22_2_tail).read_zipper();
      for v23_3_byte in v23_3_cursor.child_mask().iter() {
        v23_3_cursor.descend_to_byte(v23_3_byte);
        {
        let v23_3_tail = v23_3_cursor.fork_read_zipper();
        let v23_3_head = Path::from_slice(&[v23_3_byte]);
        let v24_2: Path = concat_path(&(v23_2),&(v23_3_head));
        let mut v24_3 = Space::new();
        let mut v24_3_cursor = (v23_3_tail).read_zipper();
        for v24_3_byte in v24_3_cursor.child_mask().iter() {
          v24_3_cursor.descend_to_byte(v24_3_byte);
          {
          let v24_3_tail = v24_3_cursor.fork_read_zipper();
          let v24_3_head = Path::from_slice(&[v24_3_byte]);
          let mut v25_2 = Space::new();
          let mut v25_2_cursor = (v24_3_tail).read_zipper();
          for v25_2_byte in v25_2_cursor.child_mask().iter() {
            v25_2_cursor.descend_to_byte(v25_2_byte);
            {
            let v25_2_tail = v25_2_cursor.fork_read_zipper();
            let v25_2_head = Path::from_slice(&[v25_2_byte]);
            let mut v26_2 = Space::new();
            let mut v26_2_cursor = (v25_2_tail).read_zipper();
            for v26_2_byte in v26_2_cursor.child_mask().iter() {
              v26_2_cursor.descend_to_byte(v26_2_byte);
              {
              let v26_2_tail = v26_2_cursor.fork_read_zipper();
              let v26_2_head = Path::from_slice(&[v26_2_byte]);
              let v27_2: Path = concat_path(&(v25_2_head),&(v26_2_head));
              let mut v27_3 = Space::new();
              let mut v27_3_cursor = (v26_2_tail).read_zipper();
              for v27_3_byte in v27_3_cursor.child_mask().iter() {
                v27_3_cursor.descend_to_byte(v27_3_byte);
                {
                let v27_3_tail = v27_3_cursor.fork_read_zipper();
                let v27_3_head = Path::from_slice(&[v27_3_byte]);
                let v28_2: Path = concat_path(&(v27_2),&(v27_3_head));
                let mut v28_3 = Space::new();
                let mut v28_3_cursor = (v27_3_tail).read_zipper();
                for v28_3_byte in v28_3_cursor.child_mask().iter() {
                  v28_3_cursor.descend_to_byte(v28_3_byte);
                  {
                  let v28_3_tail = v28_3_cursor.fork_read_zipper();
                  let v28_3_head = Path::from_slice(&[v28_3_byte]);
                  let v29_2: Path = concat_path(&(v28_2),&(v28_3_head));
                  let v29_3: Space = routine_4(c, &(v29_2), &(v28_3_tail).make_space(), &(*capture_0));
                  drop(v29_2);
                  v28_3.join_into((v29_3).clone());
                  }
                  v28_3_cursor.ascend(1);
                }
                drop(v28_3_cursor);
                drop(v28_2);
                v27_3.join_into((v28_3).clone());
                }
                v27_3_cursor.ascend(1);
              }
              drop(v27_3_cursor);
              drop(v27_2);
              v26_2.join_into((v27_3).clone());
              }
              v26_2_cursor.ascend(1);
            }
            drop(v26_2_cursor);
            v25_2.join_into((v26_2).clone());
            }
            v25_2_cursor.ascend(1);
          }
          drop(v25_2_cursor);
          let v25_3: Path = concat_path(&(v24_2),&(v24_3_head));
          let v25_4: Space = wrap(&(v25_2),&(v25_3));
          drop(v25_3);
          v24_3.join_into((v25_4).clone());
          }
          v24_3_cursor.ascend(1);
        }
        drop(v24_3_cursor);
        drop(v24_2);
        v23_3.join_into((v24_3).clone());
        }
        v23_3_cursor.ascend(1);
      }
      drop(v23_3_cursor);
      drop(v23_2);
      v22_2.join_into((v23_3).clone());
      }
      v22_2_cursor.ascend(1);
    }
    drop(v22_2_cursor);
    v1_18.join_into((v22_2).clone());
    }
    v1_18_cursor.ascend(1);
  }
  drop(v1_18_cursor);
  drop(v1_15);
  let v1_19: Space = unite(&(v1_17),&(v1_18));
  let v1_21: Space = unwrap(&(*capture_0),&(*CONSTANT_2));
  let v1_22: Space = subtract(&(v1_19),&(v1_21));
  drop(v1_21);
  let v1_24: Space = unwrap(&(*capture_0),&(*CONSTANT_8));
  let v1_25: Space = subtract(&(v1_22),&(v1_24));
  drop(v1_24);
  let v1_26: Space = wrap(&(v1_25),&(*CONSTANT_8));
  let v1_27: Space = unite(&(v1_6),&(v1_26));
  drop(v1_6);
  let v1_28: Space = unite(&(v1_27),&(*capture_0));
  let mut v1_30: Space = (v1_28).clone();
  loop {
    let v30_1: Space = unwrap(&(v1_30),&(*CONSTANT_3));
    let v30_2: Space = unwrap(&(v1_30),&(*CONSTANT_4));
    let v30_3: Space = unite(&(v30_1),&(v30_2));
    let v30_4: Space = wrap(&(v30_3),&(*CONSTANT_3));
    drop(v30_3);
    let v30_5: Space = unwrap(&(v30_1),&(*CONSTANT_5));
    let mut v30_6 = Space::new();
    let mut v30_6_cursor = (v30_5).read_zipper();
    for v30_6_byte in v30_6_cursor.child_mask().iter() {
      v30_6_cursor.descend_to_byte(v30_6_byte);
      {
      let v30_6_tail = v30_6_cursor.fork_read_zipper();
      let v30_6_head = Path::from_slice(&[v30_6_byte]);
      let mut v31_2 = Space::new();
      let mut v31_2_cursor = (v30_6_tail).read_zipper();
      for v31_2_byte in v31_2_cursor.child_mask().iter() {
        v31_2_cursor.descend_to_byte(v31_2_byte);
        {
        let v31_2_tail = v31_2_cursor.fork_read_zipper();
        let v31_2_head = Path::from_slice(&[v31_2_byte]);
        let v32_2: Path = concat_path(&(v30_6_head),&(v31_2_head));
        let mut v32_3 = Space::new();
        let mut v32_3_cursor = (v31_2_tail).read_zipper();
        for v32_3_byte in v32_3_cursor.child_mask().iter() {
          v32_3_cursor.descend_to_byte(v32_3_byte);
          {
          let v32_3_tail = v32_3_cursor.fork_read_zipper();
          let v32_3_head = Path::from_slice(&[v32_3_byte]);
          let v33_2: Path = concat_path(&(v32_2),&(v32_3_head));
          let mut v33_3 = Space::new();
          let mut v33_3_cursor = (v32_3_tail).read_zipper();
          for v33_3_byte in v33_3_cursor.child_mask().iter() {
            v33_3_cursor.descend_to_byte(v33_3_byte);
            {
            let v33_3_tail = v33_3_cursor.fork_read_zipper();
            let v33_3_head = Path::from_slice(&[v33_3_byte]);
            let mut v34_2 = Space::new();
            let mut v34_2_cursor = (v33_3_tail).read_zipper();
            for v34_2_byte in v34_2_cursor.child_mask().iter() {
              v34_2_cursor.descend_to_byte(v34_2_byte);
              {
              let v34_2_tail = v34_2_cursor.fork_read_zipper();
              let v34_2_head = Path::from_slice(&[v34_2_byte]);
              let mut v35_2 = Space::new();
              let mut v35_2_cursor = (v34_2_tail).read_zipper();
              for v35_2_byte in v35_2_cursor.child_mask().iter() {
                v35_2_cursor.descend_to_byte(v35_2_byte);
                {
                let v35_2_tail = v35_2_cursor.fork_read_zipper();
                let v35_2_head = Path::from_slice(&[v35_2_byte]);
                let v36_2: Path = concat_path(&(v34_2_head),&(v35_2_head));
                let mut v36_3 = Space::new();
                let mut v36_3_cursor = (v35_2_tail).read_zipper();
                for v36_3_byte in v36_3_cursor.child_mask().iter() {
                  v36_3_cursor.descend_to_byte(v36_3_byte);
                  {
                  let v36_3_tail = v36_3_cursor.fork_read_zipper();
                  let v36_3_head = Path::from_slice(&[v36_3_byte]);
                  let v37_2: Path = concat_path(&(v36_2),&(v36_3_head));
                  let mut v37_3 = Space::new();
                  let mut v37_3_cursor = (v36_3_tail).read_zipper();
                  for v37_3_byte in v37_3_cursor.child_mask().iter() {
                    v37_3_cursor.descend_to_byte(v37_3_byte);
                    {
                    let v37_3_tail = v37_3_cursor.fork_read_zipper();
                    let v37_3_head = Path::from_slice(&[v37_3_byte]);
                    let v38_2: Path = concat_path(&(v37_2),&(v37_3_head));
                    let v38_3: Space = routine_2(c, &(v38_2), &(v37_3_tail).make_space(), &(v1_30));
                    drop(v38_2);
                    v37_3.join_into((v38_3).clone());
                    }
                    v37_3_cursor.ascend(1);
                  }
                  drop(v37_3_cursor);
                  drop(v37_2);
                  v36_3.join_into((v37_3).clone());
                  }
                  v36_3_cursor.ascend(1);
                }
                drop(v36_3_cursor);
                drop(v36_2);
                v35_2.join_into((v36_3).clone());
                }
                v35_2_cursor.ascend(1);
              }
              drop(v35_2_cursor);
              v34_2.join_into((v35_2).clone());
              }
              v34_2_cursor.ascend(1);
            }
            drop(v34_2_cursor);
            let v34_3: Path = concat_path(&(v33_2),&(v33_3_head));
            let v34_4: Space = wrap(&(v34_2),&(v34_3));
            drop(v34_3);
            v33_3.join_into((v34_4).clone());
            }
            v33_3_cursor.ascend(1);
          }
          drop(v33_3_cursor);
          drop(v33_2);
          v32_3.join_into((v33_3).clone());
          }
          v32_3_cursor.ascend(1);
        }
        drop(v32_3_cursor);
        drop(v32_2);
        v31_2.join_into((v32_3).clone());
        }
        v31_2_cursor.ascend(1);
      }
      drop(v31_2_cursor);
      v30_6.join_into((v31_2).clone());
      }
      v30_6_cursor.ascend(1);
    }
    drop(v30_6_cursor);
    drop(v30_5);
    let v30_7: Space = unwrap(&(v30_1),&(*CONSTANT_6));
    drop(v30_1);
    let mut v30_8 = Space::new();
    let mut v30_8_cursor = (v30_7).read_zipper();
    for v30_8_byte in v30_8_cursor.child_mask().iter() {
      v30_8_cursor.descend_to_byte(v30_8_byte);
      {
      let v30_8_tail = v30_8_cursor.fork_read_zipper();
      let v30_8_head = Path::from_slice(&[v30_8_byte]);
      let mut v39_2 = Space::new();
      let mut v39_2_cursor = (v30_8_tail).read_zipper();
      for v39_2_byte in v39_2_cursor.child_mask().iter() {
        v39_2_cursor.descend_to_byte(v39_2_byte);
        {
        let v39_2_tail = v39_2_cursor.fork_read_zipper();
        let v39_2_head = Path::from_slice(&[v39_2_byte]);
        let v40_2: Path = concat_path(&(v30_8_head),&(v39_2_head));
        let mut v40_3 = Space::new();
        let mut v40_3_cursor = (v39_2_tail).read_zipper();
        for v40_3_byte in v40_3_cursor.child_mask().iter() {
          v40_3_cursor.descend_to_byte(v40_3_byte);
          {
          let v40_3_tail = v40_3_cursor.fork_read_zipper();
          let v40_3_head = Path::from_slice(&[v40_3_byte]);
          let v41_2: Path = concat_path(&(v40_2),&(v40_3_head));
          let mut v41_3 = Space::new();
          let mut v41_3_cursor = (v40_3_tail).read_zipper();
          for v41_3_byte in v41_3_cursor.child_mask().iter() {
            v41_3_cursor.descend_to_byte(v41_3_byte);
            {
            let v41_3_tail = v41_3_cursor.fork_read_zipper();
            let v41_3_head = Path::from_slice(&[v41_3_byte]);
            let v42_2: Space = subtract(&(v41_3_tail),&(*CONSTANT_7));
            let v42_3: Path = concat_path(&(v41_2),&(v41_3_head));
            let v42_4: Space = wrap(&(v42_2),&(v42_3));
            drop(v42_2);
            drop(v42_3);
            v41_3.join_into((v42_4).clone());
            }
            v41_3_cursor.ascend(1);
          }
          drop(v41_3_cursor);
          drop(v41_2);
          v40_3.join_into((v41_3).clone());
          }
          v40_3_cursor.ascend(1);
        }
        drop(v40_3_cursor);
        drop(v40_2);
        v39_2.join_into((v40_3).clone());
        }
        v39_2_cursor.ascend(1);
      }
      drop(v39_2_cursor);
      v30_8.join_into((v39_2).clone());
      }
      v30_8_cursor.ascend(1);
    }
    drop(v30_8_cursor);
    drop(v30_7);
    let v30_9: Space = unite(&(v30_6),&(v30_8));
    drop(v30_8);
    let v30_10: Space = unwrap(&(v30_2),&(*CONSTANT_5));
    drop(v30_2);
    let mut v30_11 = Space::new();
    let mut v30_11_cursor = (v30_10).read_zipper();
    for v30_11_byte in v30_11_cursor.child_mask().iter() {
      v30_11_cursor.descend_to_byte(v30_11_byte);
      {
      let v30_11_tail = v30_11_cursor.fork_read_zipper();
      let v30_11_head = Path::from_slice(&[v30_11_byte]);
      let mut v43_2 = Space::new();
      let mut v43_2_cursor = (v30_11_tail).read_zipper();
      for v43_2_byte in v43_2_cursor.child_mask().iter() {
        v43_2_cursor.descend_to_byte(v43_2_byte);
        {
        let v43_2_tail = v43_2_cursor.fork_read_zipper();
        let v43_2_head = Path::from_slice(&[v43_2_byte]);
        let v44_2: Path = concat_path(&(v30_11_head),&(v43_2_head));
        let mut v44_3 = Space::new();
        let mut v44_3_cursor = (v43_2_tail).read_zipper();
        for v44_3_byte in v44_3_cursor.child_mask().iter() {
          v44_3_cursor.descend_to_byte(v44_3_byte);
          {
          let v44_3_tail = v44_3_cursor.fork_read_zipper();
          let v44_3_head = Path::from_slice(&[v44_3_byte]);
          let v45_2: Path = concat_path(&(v44_2),&(v44_3_head));
          let mut v45_3 = Space::new();
          let mut v45_3_cursor = (v44_3_tail).read_zipper();
          for v45_3_byte in v45_3_cursor.child_mask().iter() {
            v45_3_cursor.descend_to_byte(v45_3_byte);
            {
            let v45_3_tail = v45_3_cursor.fork_read_zipper();
            let v45_3_head = Path::from_slice(&[v45_3_byte]);
            let mut v46_2 = Space::new();
            let mut v46_2_cursor = (v45_3_tail).read_zipper();
            for v46_2_byte in v46_2_cursor.child_mask().iter() {
              v46_2_cursor.descend_to_byte(v46_2_byte);
              {
              let v46_2_tail = v46_2_cursor.fork_read_zipper();
              let v46_2_head = Path::from_slice(&[v46_2_byte]);
              let mut v47_2 = Space::new();
              let mut v47_2_cursor = (v46_2_tail).read_zipper();
              for v47_2_byte in v47_2_cursor.child_mask().iter() {
                v47_2_cursor.descend_to_byte(v47_2_byte);
                {
                let v47_2_tail = v47_2_cursor.fork_read_zipper();
                let v47_2_head = Path::from_slice(&[v47_2_byte]);
                let v48_2: Path = concat_path(&(v46_2_head),&(v47_2_head));
                let mut v48_3 = Space::new();
                let mut v48_3_cursor = (v47_2_tail).read_zipper();
                for v48_3_byte in v48_3_cursor.child_mask().iter() {
                  v48_3_cursor.descend_to_byte(v48_3_byte);
                  {
                  let v48_3_tail = v48_3_cursor.fork_read_zipper();
                  let v48_3_head = Path::from_slice(&[v48_3_byte]);
                  let v49_2: Path = concat_path(&(v48_2),&(v48_3_head));
                  let mut v49_3 = Space::new();
                  let mut v49_3_cursor = (v48_3_tail).read_zipper();
                  for v49_3_byte in v49_3_cursor.child_mask().iter() {
                    v49_3_cursor.descend_to_byte(v49_3_byte);
                    {
                    let v49_3_tail = v49_3_cursor.fork_read_zipper();
                    let v49_3_head = Path::from_slice(&[v49_3_byte]);
                    let v50_2: Path = concat_path(&(v49_2),&(v49_3_head));
                    let v50_3: Space = routine_3(c, &(v50_2), &(v49_3_tail).make_space(), &(v1_30));
                    drop(v50_2);
                    v49_3.join_into((v50_3).clone());
                    }
                    v49_3_cursor.ascend(1);
                  }
                  drop(v49_3_cursor);
                  drop(v49_2);
                  v48_3.join_into((v49_3).clone());
                  }
                  v48_3_cursor.ascend(1);
                }
                drop(v48_3_cursor);
                drop(v48_2);
                v47_2.join_into((v48_3).clone());
                }
                v47_2_cursor.ascend(1);
              }
              drop(v47_2_cursor);
              v46_2.join_into((v47_2).clone());
              }
              v46_2_cursor.ascend(1);
            }
            drop(v46_2_cursor);
            let v46_3: Path = concat_path(&(v45_2),&(v45_3_head));
            let v46_4: Space = wrap(&(v46_2),&(v46_3));
            drop(v46_3);
            v45_3.join_into((v46_4).clone());
            }
            v45_3_cursor.ascend(1);
          }
          drop(v45_3_cursor);
          drop(v45_2);
          v44_3.join_into((v45_3).clone());
          }
          v44_3_cursor.ascend(1);
        }
        drop(v44_3_cursor);
        drop(v44_2);
        v43_2.join_into((v44_3).clone());
        }
        v43_2_cursor.ascend(1);
      }
      drop(v43_2_cursor);
      v30_11.join_into((v43_2).clone());
      }
      v30_11_cursor.ascend(1);
    }
    drop(v30_11_cursor);
    let v30_12: Space = unite(&(v30_9),&(v30_11));
    let mut v30_13 = Space::new();
    let mut v30_13_cursor = (v30_10).read_zipper();
    for v30_13_byte in v30_13_cursor.child_mask().iter() {
      v30_13_cursor.descend_to_byte(v30_13_byte);
      {
      let v30_13_tail = v30_13_cursor.fork_read_zipper();
      let v30_13_head = Path::from_slice(&[v30_13_byte]);
      let mut v51_2 = Space::new();
      let mut v51_2_cursor = (v30_13_tail).read_zipper();
      for v51_2_byte in v51_2_cursor.child_mask().iter() {
        v51_2_cursor.descend_to_byte(v51_2_byte);
        {
        let v51_2_tail = v51_2_cursor.fork_read_zipper();
        let v51_2_head = Path::from_slice(&[v51_2_byte]);
        let v52_2: Path = concat_path(&(v30_13_head),&(v51_2_head));
        let mut v52_3 = Space::new();
        let mut v52_3_cursor = (v51_2_tail).read_zipper();
        for v52_3_byte in v52_3_cursor.child_mask().iter() {
          v52_3_cursor.descend_to_byte(v52_3_byte);
          {
          let v52_3_tail = v52_3_cursor.fork_read_zipper();
          let v52_3_head = Path::from_slice(&[v52_3_byte]);
          let v53_2: Path = concat_path(&(v52_2),&(v52_3_head));
          let mut v53_3 = Space::new();
          let mut v53_3_cursor = (v52_3_tail).read_zipper();
          for v53_3_byte in v53_3_cursor.child_mask().iter() {
            v53_3_cursor.descend_to_byte(v53_3_byte);
            {
            let v53_3_tail = v53_3_cursor.fork_read_zipper();
            let v53_3_head = Path::from_slice(&[v53_3_byte]);
            let mut v54_2 = Space::new();
            let mut v54_2_cursor = (v53_3_tail).read_zipper();
            for v54_2_byte in v54_2_cursor.child_mask().iter() {
              v54_2_cursor.descend_to_byte(v54_2_byte);
              {
              let v54_2_tail = v54_2_cursor.fork_read_zipper();
              let v54_2_head = Path::from_slice(&[v54_2_byte]);
              let mut v55_2 = Space::new();
              let mut v55_2_cursor = (v54_2_tail).read_zipper();
              for v55_2_byte in v55_2_cursor.child_mask().iter() {
                v55_2_cursor.descend_to_byte(v55_2_byte);
                {
                let v55_2_tail = v55_2_cursor.fork_read_zipper();
                let v55_2_head = Path::from_slice(&[v55_2_byte]);
                let v56_2: Path = concat_path(&(v54_2_head),&(v55_2_head));
                let mut v56_3 = Space::new();
                let mut v56_3_cursor = (v55_2_tail).read_zipper();
                for v56_3_byte in v56_3_cursor.child_mask().iter() {
                  v56_3_cursor.descend_to_byte(v56_3_byte);
                  {
                  let v56_3_tail = v56_3_cursor.fork_read_zipper();
                  let v56_3_head = Path::from_slice(&[v56_3_byte]);
                  let v57_2: Path = concat_path(&(v56_2),&(v56_3_head));
                  let mut v57_3 = Space::new();
                  let mut v57_3_cursor = (v56_3_tail).read_zipper();
                  for v57_3_byte in v57_3_cursor.child_mask().iter() {
                    v57_3_cursor.descend_to_byte(v57_3_byte);
                    {
                    let v57_3_tail = v57_3_cursor.fork_read_zipper();
                    let v57_3_head = Path::from_slice(&[v57_3_byte]);
                    let v58_2: Path = concat_path(&(v57_2),&(v57_3_head));
                    let v58_3: Space = routine_4(c, &(v58_2), &(v57_3_tail).make_space(), &(v1_30));
                    drop(v58_2);
                    v57_3.join_into((v58_3).clone());
                    }
                    v57_3_cursor.ascend(1);
                  }
                  drop(v57_3_cursor);
                  drop(v57_2);
                  v56_3.join_into((v57_3).clone());
                  }
                  v56_3_cursor.ascend(1);
                }
                drop(v56_3_cursor);
                drop(v56_2);
                v55_2.join_into((v56_3).clone());
                }
                v55_2_cursor.ascend(1);
              }
              drop(v55_2_cursor);
              v54_2.join_into((v55_2).clone());
              }
              v54_2_cursor.ascend(1);
            }
            drop(v54_2_cursor);
            let v54_3: Path = concat_path(&(v53_2),&(v53_3_head));
            let v54_4: Space = wrap(&(v54_2),&(v54_3));
            drop(v54_3);
            v53_3.join_into((v54_4).clone());
            }
            v53_3_cursor.ascend(1);
          }
          drop(v53_3_cursor);
          drop(v53_2);
          v52_3.join_into((v53_3).clone());
          }
          v52_3_cursor.ascend(1);
        }
        drop(v52_3_cursor);
        drop(v52_2);
        v51_2.join_into((v52_3).clone());
        }
        v51_2_cursor.ascend(1);
      }
      drop(v51_2_cursor);
      v30_13.join_into((v51_2).clone());
      }
      v30_13_cursor.ascend(1);
    }
    drop(v30_13_cursor);
    drop(v30_10);
    let v30_14: Space = unite(&(v30_12),&(v30_13));
    let v30_15: Space = unwrap(&(v1_30),&(*CONSTANT_2));
    let v30_16: Space = subtract(&(v30_14),&(v30_15));
    drop(v30_15);
    let v30_17: Space = unwrap(&(v1_30),&(*CONSTANT_8));
    let v30_18: Space = subtract(&(v30_16),&(v30_17));
    drop(v30_17);
    let v30_19: Space = wrap(&(v30_18),&(*CONSTANT_8));
    let v30_20: Space = unite(&(v30_4),&(v30_19));
    drop(v30_4);
    let v30_21: Space = unite(&(v30_20),&(v1_30));
    if !v1_30.join_into((v30_21).clone()).is_element() { break; }
  }

((v1_14).clone(),(v1_16).clone(),(v1_17).clone(),(v1_18).clone(),(v1_19).clone(),(v1_22).clone(),(v1_25).clone(),(v1_26).clone(),(v1_27).clone(),(v1_28).clone(),(v1_30).clone(),(v1_9).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_2: Space = routine_1(c, &(*CONSTANT_1));
  let v0_3: Space = unite(&(*CONSTANT_0),&(v0_2));
  let v0_5: Space = unwrap(&(v0_3),&(*CONSTANT_2));
  (v0_5).clone()
}

fn routine_1(c: &mut Context, s0: &Space) -> Space {
  let (v1_14,v1_16,v1_17,v1_18,v1_19,v1_22,v1_25,v1_26,v1_27,v1_28,v1_30,v1_9,) = native_block_0(c, s0);
  let v1_31: Space = unite(&(*s0),&(v1_30));
  (v1_31).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v59_4: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v59_6: Space = unwrap(&(v59_4),&(*CONSTANT_5));
  drop(v59_4);
  let v59_7: Space = unwrap(&(v59_6),&(*p0));
  drop(v59_6);
  let v59_9: Space = subtract(&(v59_7),&(*CONSTANT_7));
  drop(v59_7);
  (v59_9).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v60_4: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v60_6: Space = unwrap(&(v60_4),&(*CONSTANT_5));
  drop(v60_4);
  let v60_7: Space = unwrap(&(v60_6),&(*p0));
  drop(v60_6);
  let v60_9: Space = subtract(&(v60_7),&(*CONSTANT_7));
  drop(v60_7);
  (v60_9).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v61_4: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v61_6: Space = unwrap(&(v61_4),&(*CONSTANT_5));
  drop(v61_4);
  let v61_7: Space = unwrap(&(v61_6),&(*p0));
  drop(v61_6);
  let v61_9: Space = subtract(&(v61_7),&(*CONSTANT_7));
  drop(v61_7);
  (v61_9).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
