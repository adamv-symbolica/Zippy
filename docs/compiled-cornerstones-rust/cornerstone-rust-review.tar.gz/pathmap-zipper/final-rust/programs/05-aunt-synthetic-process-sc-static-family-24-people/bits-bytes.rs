#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,1,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 15 0 0 0 0 0 1 1 0 0 1 0 0 0 1 1 14 0 0 0 0 0 1 1 1 0 0 1 0 1 1 13 0 0 0 0 1 1 0 0 0 0 0 1 1 13 0 0 0 0 1 1 1 0 0 0 0 1 1 15 0 0 0 1 0 1 1 0 0 1 0 0 0 1 1 15 0 0 0 1 0 1 1 0 1 0 0 0 0 1 1 11 0 0 0 1 1 0 0 1 0 1 1 11 0 0 0 1 1 0 1 0 0 1 1 15 0 0 1 0 0 1 1 0 0 0 0 0 0 1 1 15 0 0 1 0 0 1 1 1 0 0 0 0 0 1 1 13 0 0 1 0 1 1 0 0 1 0 0 1 1 13 0 0 1 0 1 1 1 0 1 0 0 1 1 10 0 0 1 1 0 0 0 0 1 1 10 0 0 1 1 1 0 0 0 1 1 15 0 1 0 0 0 1 1 0 0 0 0 0 0 1 1 14 0 1 0 0 0 1 1 0 1 0 1 0 1 1 13 0 1 0 0 1 1 0 0 1 0 0 1 1 13 0 1 0 0 1 1 0 1 0 0 0 1 1 12 0 1 0 1 1 0 0 0 0 0 1 1 12 0 1 0 1 1 0 0 0 1 0 1 1 9 0 1 1 0 0 0 0 1 1 8 0 1 1 0 1 0 1 1 14 1 0 0 0 0 1 1 0 1 0 1 0 1 1 14 1 0 0 0 0 1 1 1 0 0 1 0 1 1 13 1 0 0 0 1 1 0 1 0 0 0 1 1 13 1 0 0 0 1 1 1 0 0 0 0 1 1 11 1 0 0 1 1 0 0 1 0 1 1 11 1 0 0 1 1 1 0 1 0 1 1 15 1 0 1 0 0 1 1 0 1 0 0 0 0 1 1 15 1 0 1 0 0 1 1 1 0 0 0 0 0 1 1 13 1 0 1 0 1 1 0 0 0 1 0 1 1 13 1 0 1 0 1 1 1 0 1 0 0 1 1 10 1 0 1 1 0 1 0 0 1 1 10 1 0 1 1 1 0 0 0 1 1 7 1 1 0 1 0 1 1 8 1 1 1 0 1 0 1 1"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 15 0 0 0 0 0 0 1 1 0 0 1 0 0 1 1 15 0 0 0 0 0 0 1 1 0 1 0 0 0 1 1 13 0 0 0 0 0 1 1 0 0 0 0 1 1 12 0 0 0 0 0 1 1 0 1 0 1 1 10 0 0 0 0 1 1 0 0 1 1 9 0 0 0 0 1 1 0 1 1 12 0 0 0 1 0 1 1 0 1 0 1 1 13 0 0 0 1 0 1 1 1 0 1 0 1 1 15 0 0 1 0 0 0 1 1 0 0 0 0 0 1 1 15 0 0 1 0 0 0 1 1 0 0 0 1 0 1 1 13 0 0 1 0 0 1 1 0 0 1 0 1 1 13 0 0 1 0 0 1 1 0 1 0 0 1 1 11 0 0 1 0 1 1 0 0 0 1 1 11 0 0 1 0 1 1 1 0 0 1 1 15 0 1 0 0 0 0 1 1 0 0 0 1 0 1 1 15 0 1 0 0 0 0 1 1 1 0 1 0 0 1 1 13 0 1 0 0 0 1 1 0 1 0 0 1 1 13 0 1 0 0 0 1 1 1 0 0 0 1 1 11 0 1 0 0 1 1 0 0 0 1 1 10 0 1 0 0 1 1 1 0 1 1 14 0 1 0 1 0 1 1 0 1 0 0 0 1 1 14 0 1 0 1 0 1 1 1 0 0 0 0 1 1 8 0 1 0 1 1 0 1 1 7 0 1 0 1 1 1 1 15 1 0 0 0 0 0 1 1 0 0 1 0 0 1 1 15 1 0 0 0 0 0 1 1 1 0 1 0 0 1 1 13 1 0 0 0 0 1 1 0 0 0 0 1 1 13 1 0 0 0 0 1 1 1 0 0 0 1 1 10 1 0 0 0 1 1 0 0 1 1 10 1 0 0 0 1 1 1 0 1 1 14 1 0 0 1 0 1 1 0 0 0 0 0 1 1 14 1 0 0 1 0 1 1 1 0 0 0 0 1 1 13 1 0 1 0 0 1 1 0 0 1 0 1 1 13 1 0 1 0 0 1 1 1 0 1 0 1 1 11 1 0 1 0 1 1 1 0 0 1 1 8 1 0 1 0 1 1 1 1"));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("12 8 0 0 0 0 0 0 1 1 7 0 0 0 0 0 1 1 5 0 0 0 1 1 6 0 0 1 0 1 1 4 0 0 1 1 8 0 1 0 0 0 0 1 1 7 0 1 0 0 0 1 1 5 0 1 0 1 1 6 1 0 0 0 1 1 7 1 0 0 1 0 1 1 7 1 0 1 0 0 1 1 2 1 1"));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_10 = Space::new();
  let mut v0_10_cursor = (*s0.expect("unbound native input")).read_zipper();
  for v0_10_byte in v0_10_cursor.child_mask().iter() {
    v0_10_cursor.descend_to_byte(v0_10_byte);
    {
    let v0_10_tail = v0_10_cursor.fork_read_zipper();
    let v0_10_head = Path::from_slice(&[v0_10_byte]);
    let v1_2: Space = singleton(&(v0_10_head));
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_10_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        {
        let v2_6_tail = v2_6_cursor.fork_read_zipper();
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_1),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_10_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail).make_space());
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_1),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_10_head),&(v2_6_head));
          let v5_11: Space = routine_2(c, &(v5_6), &(v2_6_tail).make_space());
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
        }
        v2_6_cursor.ascend(1);
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_cursor = (v0_10_tail).read_zipper();
      for v6_10_byte in v6_10_cursor.child_mask().iter() {
        v6_10_cursor.descend_to_byte(v6_10_byte);
        {
        let v6_10_tail = v6_10_cursor.fork_read_zipper();
        let v6_10_head = Path::from_slice(&[v6_10_byte]);
        let v7_2: Space = singleton(&(v6_10_head));
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_10_head),&(v6_10_head));
          let v8_7: Space = routine_1(c, &(v8_6), &(v6_10_tail).make_space());
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v0_10_head),&(v6_10_head));
          let v9_11: Space = routine_3(c, &(v9_6), &(v6_10_tail).make_space());
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_10.join_into((v7_13).clone());
        }
        v6_10_cursor.ascend(1);
      }
      drop(v6_10_cursor);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_10.join_into((v1_12).clone());
    }
    v0_10_cursor.ascend(1);
  }
  drop(v0_10_cursor);
  let v0_12: Space = wrap(&(v0_10),&(*CONSTANT_2));
  (v0_12).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v10_22: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v10_23: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v10_33 = Space::new();
  let mut v10_33_cursor = (*s0).read_zipper();
  for v10_33_byte in v10_33_cursor.child_mask().iter() {
    v10_33_cursor.descend_to_byte(v10_33_byte);
    {
    let v10_33_tail = v10_33_cursor.fork_read_zipper();
    let v10_33_head = Path::from_slice(&[v10_33_byte]);
    let v11_2: Space = singleton(&(v10_33_head));
    let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&(v10_33_head));
      let mut v12_7 = Space::new();
      let mut v12_7_cursor = (v10_33_tail).read_zipper();
      for v12_7_byte in v12_7_cursor.child_mask().iter() {
        v12_7_cursor.descend_to_byte(v12_7_byte);
        {
        let v12_7_tail = v12_7_cursor.fork_read_zipper();
        let v12_7_head = Path::from_slice(&[v12_7_byte]);
        let v13_2: Space = singleton(&(v12_7_head));
        let v13_3: Space = intersect(&(*CONSTANT_1),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let mut v14_7 = Space::new();
          let mut v14_7_cursor = (v12_7_tail).read_zipper();
          for v14_7_byte in v14_7_cursor.child_mask().iter() {
            v14_7_cursor.descend_to_byte(v14_7_byte);
            {
            let v14_7_tail = v14_7_cursor.fork_read_zipper();
            let v14_7_head = Path::from_slice(&[v14_7_byte]);
            let v15_2: Space = singleton(&(v14_7_head));
            let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v16_7: Space = routine_4(c, &(v16_6), &(v14_7_tail).make_space());
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (v15_10).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v17_11: Space = routine_5(c, &(v17_6), &(v14_7_tail).make_space());
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            v14_7.join_into((v15_13).clone());
            }
            v14_7_cursor.ascend(1);
          }
          drop(v14_7_cursor);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_1),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let mut v18_11 = Space::new();
          let mut v18_11_cursor = (v12_7_tail).read_zipper();
          for v18_11_byte in v18_11_cursor.child_mask().iter() {
            v18_11_cursor.descend_to_byte(v18_11_byte);
            {
            let v18_11_tail = v18_11_cursor.fork_read_zipper();
            let v18_11_head = Path::from_slice(&[v18_11_byte]);
            let v19_2: Space = singleton(&(v18_11_head));
            let v19_3: Space = intersect(&(*CONSTANT_1),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (v19_5).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v18_6),&(v18_11_head));
              let v20_7: Space = routine_4(c, &(v20_6), &(v18_11_tail).make_space());
              compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = intersect(&(*CONSTANT_1),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v19_12: Space = if (v19_10).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v18_6),&(v18_11_head));
              let v21_11: Space = routine_3(c, &(v21_6), &(v18_11_tail).make_space());
              drop(v21_6);
              compose(&(v19_10),&(v21_11))
            };
            drop(v19_10);
            let v19_13: Space = unite(&(v19_8),&(v19_12));
            v18_11.join_into((v19_13).clone());
            }
            v18_11_cursor.ascend(1);
          }
          drop(v18_11_cursor);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        v12_7.join_into((v13_13).clone());
        }
        v12_7_cursor.ascend(1);
      }
      drop(v12_7_cursor);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_14: Space = if (v11_10).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&(v10_33_head));
      let v22_11: Space = unwrap(&(v10_22),&(v10_33_head));
      let v22_12: Space = unwrap(&(v10_23),&(v10_33_head));
      let mut v22_13 = Space::new();
      let mut v22_13_cursor = (v10_33_tail).read_zipper();
      for v22_13_byte in v22_13_cursor.child_mask().iter() {
        v22_13_cursor.descend_to_byte(v22_13_byte);
        {
        let v22_13_tail = v22_13_cursor.fork_read_zipper();
        let v22_13_head = Path::from_slice(&[v22_13_byte]);
        let v23_2: Space = singleton(&(v22_13_head));
        let v23_3: Space = intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&(v22_13_head));
          let mut v24_7 = Space::new();
          let mut v24_7_cursor = (v22_13_tail).read_zipper();
          for v24_7_byte in v24_7_cursor.child_mask().iter() {
            v24_7_cursor.descend_to_byte(v24_7_byte);
            {
            let v24_7_tail = v24_7_cursor.fork_read_zipper();
            let v24_7_head = Path::from_slice(&[v24_7_byte]);
            let v25_2: Space = singleton(&(v24_7_head));
            let v25_3: Space = intersect(&(*CONSTANT_1),&(v25_2));
            let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
            drop(v25_3);
            let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
            drop(v25_4);
            let v25_8: Space = if (v25_5).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v24_6),&(v24_7_head));
              let v26_7: Space = routine_4(c, &(v26_6), &(v24_7_tail).make_space());
              compose(&(v25_5),&(v26_7))
            };
            drop(v25_5);
            let v25_9: Space = intersect(&(*CONSTANT_1),&(v25_2));
            drop(v25_2);
            let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
            drop(v25_9);
            let v25_12: Space = if (v25_10).is_empty() { Space::new() } else {
              let v27_6: Path = concat_path(&(v24_6),&(v24_7_head));
              let v27_11: Space = routine_5(c, &(v27_6), &(v24_7_tail).make_space());
              drop(v27_6);
              compose(&(v25_10),&(v27_11))
            };
            drop(v25_10);
            let v25_13: Space = unite(&(v25_8),&(v25_12));
            v24_7.join_into((v25_13).clone());
            }
            v24_7_cursor.ascend(1);
          }
          drop(v24_7_cursor);
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_19: Space = if (v23_10).is_empty() { Space::new() } else {
          let v28_11: Space = unwrap(&(v22_11),&(v22_13_head));
          let v28_12: Space = restrict_to(&(*CONSTANT_4),&(v28_11));
          drop(v28_11);
          let mut v28_13 = Space::new();
          let mut v28_13_cursor = (v28_12).read_zipper();
          for v28_13_byte in v28_13_cursor.child_mask().iter() {
            v28_13_cursor.descend_to_byte(v28_13_byte);
            {
            let v28_13_tail = v28_13_cursor.fork_read_zipper();
            let v28_13_head = Path::from_slice(&[v28_13_byte]);
            let v29_2: Space = singleton(&(v28_13_head));
            let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
            let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
            drop(v29_3);
            let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
            drop(v29_4);
            let v29_7: Space = if (v29_5).is_empty() { Space::new() } else {
              let v30_6: Space = routine_6(c, &(v28_13_head), &(v28_13_tail).make_space());
              compose(&(v29_5),&(v30_6))
            };
            drop(v29_5);
            let v29_8: Space = intersect(&(*CONSTANT_1),&(v29_2));
            drop(v29_2);
            let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
            drop(v29_8);
            let v29_11: Space = if (v29_9).is_empty() { Space::new() } else {
              let v31_10: Space = routine_7(c, &(v28_13_head), &(v28_13_tail).make_space());
              compose(&(v29_9),&(v31_10))
            };
            drop(v29_9);
            let v29_12: Space = unite(&(v29_7),&(v29_11));
            v28_13.join_into((v29_12).clone());
            }
            v28_13_cursor.ascend(1);
          }
          drop(v28_13_cursor);
          drop(v28_12);
          let v28_14: Space = restrict_to(&(*CONSTANT_3),&(v28_13));
          let mut v28_15 = Space::new();
          let mut v28_15_cursor = (v28_14).read_zipper();
          for v28_15_byte in v28_15_cursor.child_mask().iter() {
            v28_15_cursor.descend_to_byte(v28_15_byte);
            {
            let v28_15_tail = v28_15_cursor.fork_read_zipper();
            let v28_15_head = Path::from_slice(&[v28_15_byte]);
            let v32_2: Space = singleton(&(v28_15_head));
            let v32_3: Space = intersect(&(*CONSTANT_1),&(v32_2));
            let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_7: Space = if (v32_5).is_empty() { Space::new() } else {
              let v33_6: Space = routine_8(c, &(v28_15_head), &(v28_15_tail).make_space());
              compose(&(v32_5),&(v33_6))
            };
            drop(v32_5);
            let v32_8: Space = intersect(&(*CONSTANT_1),&(v32_2));
            drop(v32_2);
            let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
            drop(v32_8);
            let v32_11: Space = if (v32_9).is_empty() { Space::new() } else {
              let v34_10: Space = routine_9(c, &(v28_15_head), &(v28_15_tail).make_space());
              compose(&(v32_9),&(v34_10))
            };
            drop(v32_9);
            let v32_12: Space = unite(&(v32_7),&(v32_11));
            v28_15.join_into((v32_12).clone());
            }
            v28_15_cursor.ascend(1);
          }
          drop(v28_15_cursor);
          let v28_16: Space = unwrap(&(v22_12),&(v22_13_head));
          let v28_17: Space = subtract(&(v28_15),&(v28_16));
          drop(v28_16);
          let v28_18: Space = intersect(&(v28_17),&(*CONSTANT_5));
          compose(&(v23_10),&(v28_18))
        };
        drop(v23_10);
        let v35_6: Path = concat_path(&(v22_6),&(v22_13_head));
        let v23_20: Space = wrap(&(v23_19),&(v35_6));
        let v23_21: Space = unite(&(v23_8),&(v23_20));
        v22_13.join_into((v23_21).clone());
        }
        v22_13_cursor.ascend(1);
      }
      drop(v22_13_cursor);
      drop(v22_6);
      drop(v22_11);
      drop(v22_12);
      compose(&(v11_10),&(v22_13))
    };
    drop(v11_10);
    let v11_15: Space = unite(&(v11_8),&(v11_14));
    v10_33.join_into((v11_15).clone());
    }
    v10_33_cursor.ascend(1);
  }
  drop(v10_33_cursor);
  drop(v10_22);
  drop(v10_23);
  (v10_33).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v36_8: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v36_10: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v36_39 = Space::new();
  let mut v36_39_cursor = (*s0).read_zipper();
  for v36_39_byte in v36_39_cursor.child_mask().iter() {
    v36_39_cursor.descend_to_byte(v36_39_byte);
    {
    let v36_39_tail = v36_39_cursor.fork_read_zipper();
    let v36_39_head = Path::from_slice(&[v36_39_byte]);
    let v37_2: Space = singleton(&(v36_39_head));
    let v37_3: Space = intersect(&(*CONSTANT_1),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
      let v38_6: Path = concat_path(&(*p0),&(v36_39_head));
      let mut v38_7 = Space::new();
      let mut v38_7_cursor = (v36_39_tail).read_zipper();
      for v38_7_byte in v38_7_cursor.child_mask().iter() {
        v38_7_cursor.descend_to_byte(v38_7_byte);
        {
        let v38_7_tail = v38_7_cursor.fork_read_zipper();
        let v38_7_head = Path::from_slice(&[v38_7_byte]);
        let v39_2: Space = singleton(&(v38_7_head));
        let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (v39_5).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v38_6),&(v38_7_head));
          let mut v40_7 = Space::new();
          let mut v40_7_cursor = (v38_7_tail).read_zipper();
          for v40_7_byte in v40_7_cursor.child_mask().iter() {
            v40_7_cursor.descend_to_byte(v40_7_byte);
            {
            let v40_7_tail = v40_7_cursor.fork_read_zipper();
            let v40_7_head = Path::from_slice(&[v40_7_byte]);
            let v41_2: Space = singleton(&(v40_7_head));
            let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
            drop(v41_4);
            let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v40_6),&(v40_7_head));
              let v42_7: Space = routine_4(c, &(v42_6), &(v40_7_tail).make_space());
              compose(&(v41_5),&(v42_7))
            };
            drop(v41_5);
            let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
            drop(v41_2);
            let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
            drop(v41_9);
            let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v40_6),&(v40_7_head));
              let v43_11: Space = routine_5(c, &(v43_6), &(v40_7_tail).make_space());
              drop(v43_6);
              compose(&(v41_10),&(v43_11))
            };
            drop(v41_10);
            let v41_13: Space = unite(&(v41_8),&(v41_12));
            v40_7.join_into((v41_13).clone());
            }
            v40_7_cursor.ascend(1);
          }
          drop(v40_7_cursor);
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (v39_10).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v38_6),&(v38_7_head));
          let mut v44_11 = Space::new();
          let mut v44_11_cursor = (v38_7_tail).read_zipper();
          for v44_11_byte in v44_11_cursor.child_mask().iter() {
            v44_11_cursor.descend_to_byte(v44_11_byte);
            {
            let v44_11_tail = v44_11_cursor.fork_read_zipper();
            let v44_11_head = Path::from_slice(&[v44_11_byte]);
            let v45_2: Space = singleton(&(v44_11_head));
            let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
            let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_8: Space = if (v45_5).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v44_6),&(v44_11_head));
              let v46_7: Space = routine_4(c, &(v46_6), &(v44_11_tail).make_space());
              compose(&(v45_5),&(v46_7))
            };
            drop(v45_5);
            let v45_9: Space = intersect(&(*CONSTANT_1),&(v45_2));
            drop(v45_2);
            let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
            drop(v45_9);
            let v45_12: Space = if (v45_10).is_empty() { Space::new() } else {
              let v47_6: Path = concat_path(&(v44_6),&(v44_11_head));
              let v47_11: Space = routine_3(c, &(v47_6), &(v44_11_tail).make_space());
              drop(v47_6);
              compose(&(v45_10),&(v47_11))
            };
            drop(v45_10);
            let v45_13: Space = unite(&(v45_8),&(v45_12));
            v44_11.join_into((v45_13).clone());
            }
            v44_11_cursor.ascend(1);
          }
          drop(v44_11_cursor);
          drop(v44_6);
          compose(&(v39_10),&(v44_11))
        };
        drop(v39_10);
        let v39_13: Space = unite(&(v39_8),&(v39_12));
        v38_7.join_into((v39_13).clone());
        }
        v38_7_cursor.ascend(1);
      }
      drop(v38_7_cursor);
      compose(&(v37_5),&(v38_7))
    };
    drop(v37_5);
    let v37_9: Space = intersect(&(*CONSTANT_1),&(v37_2));
    drop(v37_2);
    let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
    drop(v37_9);
    let v37_19: Space = if (v37_10).is_empty() { Space::new() } else {
      let v48_11: Space = unwrap(&(v36_8),&(v36_39_head));
      let v48_12: Space = restrict_to(&(*CONSTANT_4),&(v48_11));
      drop(v48_11);
      let mut v48_13 = Space::new();
      let mut v48_13_cursor = (v48_12).read_zipper();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_byte(v48_13_byte);
        {
        let v48_13_tail = v48_13_cursor.fork_read_zipper();
        let v48_13_head = Path::from_slice(&[v48_13_byte]);
        let v49_2: Space = singleton(&(v48_13_head));
        let v49_3: Space = intersect(&(*CONSTANT_1),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (v49_5).is_empty() { Space::new() } else {
          let mut v50_6 = Space::new();
          let mut v50_6_cursor = (v48_13_tail).read_zipper();
          for v50_6_byte in v50_6_cursor.child_mask().iter() {
            v50_6_cursor.descend_to_byte(v50_6_byte);
            {
            let v50_6_tail = v50_6_cursor.fork_read_zipper();
            let v50_6_head = Path::from_slice(&[v50_6_byte]);
            let v51_2: Space = singleton(&(v50_6_head));
            let v51_3: Space = intersect(&(*CONSTANT_1),&(v51_2));
            let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
            drop(v51_3);
            let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
            drop(v51_4);
            let v51_8: Space = if (v51_5).is_empty() { Space::new() } else {
              let v52_6: Path = concat_path(&(v48_13_head),&(v50_6_head));
              let v52_7: Space = routine_10(c, &(v52_6), &(v50_6_tail).make_space());
              compose(&(v51_5),&(v52_7))
            };
            drop(v51_5);
            let v51_9: Space = intersect(&(*CONSTANT_1),&(v51_2));
            drop(v51_2);
            let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
            drop(v51_9);
            let v51_12: Space = if (v51_10).is_empty() { Space::new() } else {
              let v53_6: Path = concat_path(&(v48_13_head),&(v50_6_head));
              let v53_11: Space = routine_11(c, &(v53_6), &(v50_6_tail).make_space());
              drop(v53_6);
              compose(&(v51_10),&(v53_11))
            };
            drop(v51_10);
            let v51_13: Space = unite(&(v51_8),&(v51_12));
            v50_6.join_into((v51_13).clone());
            }
            v50_6_cursor.ascend(1);
          }
          drop(v50_6_cursor);
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_1),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (v49_9).is_empty() { Space::new() } else {
          let mut v54_10 = Space::new();
          let mut v54_10_cursor = (v48_13_tail).read_zipper();
          for v54_10_byte in v54_10_cursor.child_mask().iter() {
            v54_10_cursor.descend_to_byte(v54_10_byte);
            {
            let v54_10_tail = v54_10_cursor.fork_read_zipper();
            let v54_10_head = Path::from_slice(&[v54_10_byte]);
            let v55_2: Space = singleton(&(v54_10_head));
            let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
            let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
            drop(v55_3);
            let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
            drop(v55_4);
            let v55_8: Space = if (v55_5).is_empty() { Space::new() } else {
              let v56_6: Path = concat_path(&(v48_13_head),&(v54_10_head));
              let v56_7: Space = routine_10(c, &(v56_6), &(v54_10_tail).make_space());
              compose(&(v55_5),&(v56_7))
            };
            drop(v55_5);
            let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
            drop(v55_2);
            let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
            drop(v55_9);
            let v55_12: Space = if (v55_10).is_empty() { Space::new() } else {
              let v57_6: Path = concat_path(&(v48_13_head),&(v54_10_head));
              let v57_11: Space = routine_12(c, &(v57_6), &(v54_10_tail).make_space());
              drop(v57_6);
              compose(&(v55_10),&(v57_11))
            };
            drop(v55_10);
            let v55_13: Space = unite(&(v55_8),&(v55_12));
            v54_10.join_into((v55_13).clone());
            }
            v54_10_cursor.ascend(1);
          }
          drop(v54_10_cursor);
          compose(&(v49_9),&(v54_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        v48_13.join_into((v49_12).clone());
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_12);
      let v48_14: Space = restrict_to(&(*CONSTANT_3),&(v48_13));
      let mut v48_15 = Space::new();
      let mut v48_15_cursor = (v48_14).read_zipper();
      for v48_15_byte in v48_15_cursor.child_mask().iter() {
        v48_15_cursor.descend_to_byte(v48_15_byte);
        {
        let v48_15_tail = v48_15_cursor.fork_read_zipper();
        let v48_15_head = Path::from_slice(&[v48_15_byte]);
        let v58_2: Space = singleton(&(v48_15_head));
        let v58_3: Space = intersect(&(*CONSTANT_1),&(v58_2));
        let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (v58_5).is_empty() { Space::new() } else {
          let mut v59_6 = Space::new();
          let mut v59_6_cursor = (v48_15_tail).read_zipper();
          for v59_6_byte in v59_6_cursor.child_mask().iter() {
            v59_6_cursor.descend_to_byte(v59_6_byte);
            {
            let v59_6_tail = v59_6_cursor.fork_read_zipper();
            let v59_6_head = Path::from_slice(&[v59_6_byte]);
            let v60_2: Space = singleton(&(v59_6_head));
            let v60_3: Space = intersect(&(*CONSTANT_1),&(v60_2));
            let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (v60_5).is_empty() { Space::new() } else {
              let v61_6: Path = concat_path(&(v48_15_head),&(v59_6_head));
              let v61_7: Space = routine_13(c, &(v61_6), &(v59_6_tail).make_space());
              compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = intersect(&(*CONSTANT_1),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (v60_10).is_empty() { Space::new() } else {
              let v62_6: Path = concat_path(&(v48_15_head),&(v59_6_head));
              let v62_11: Space = routine_14(c, &(v62_6), &(v59_6_tail).make_space());
              drop(v62_6);
              compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = unite(&(v60_8),&(v60_12));
            v59_6.join_into((v60_13).clone());
            }
            v59_6_cursor.ascend(1);
          }
          drop(v59_6_cursor);
          compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = intersect(&(*CONSTANT_1),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (v58_9).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_cursor = (v48_15_tail).read_zipper();
          for v63_10_byte in v63_10_cursor.child_mask().iter() {
            v63_10_cursor.descend_to_byte(v63_10_byte);
            {
            let v63_10_tail = v63_10_cursor.fork_read_zipper();
            let v63_10_head = Path::from_slice(&[v63_10_byte]);
            let v64_2: Space = singleton(&(v63_10_head));
            let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
            let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_8: Space = if (v64_5).is_empty() { Space::new() } else {
              let v65_6: Path = concat_path(&(v48_15_head),&(v63_10_head));
              let v65_7: Space = routine_13(c, &(v65_6), &(v63_10_tail).make_space());
              compose(&(v64_5),&(v65_7))
            };
            drop(v64_5);
            let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
            drop(v64_2);
            let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
            drop(v64_9);
            let v64_12: Space = if (v64_10).is_empty() { Space::new() } else {
              let v66_6: Path = concat_path(&(v48_15_head),&(v63_10_head));
              let v66_11: Space = routine_15(c, &(v66_6), &(v63_10_tail).make_space());
              drop(v66_6);
              compose(&(v64_10),&(v66_11))
            };
            drop(v64_10);
            let v64_13: Space = unite(&(v64_8),&(v64_12));
            v63_10.join_into((v64_13).clone());
            }
            v63_10_cursor.ascend(1);
          }
          drop(v63_10_cursor);
          compose(&(v58_9),&(v63_10))
        };
        drop(v58_9);
        let v58_12: Space = unite(&(v58_7),&(v58_11));
        v48_15.join_into((v58_12).clone());
        }
        v48_15_cursor.ascend(1);
      }
      drop(v48_15_cursor);
      let v48_16: Space = unwrap(&(v36_10),&(v36_39_head));
      let v48_17: Space = subtract(&(v48_15),&(v48_16));
      drop(v48_16);
      let v48_18: Space = intersect(&(v48_17),&(*CONSTANT_5));
      compose(&(v37_10),&(v48_18))
    };
    drop(v37_10);
    let v67_6: Path = concat_path(&(*p0),&(v36_39_head));
    let v37_20: Space = wrap(&(v37_19),&(v67_6));
    let v37_21: Space = unite(&(v37_8),&(v37_20));
    v36_39.join_into((v37_21).clone());
    }
    v36_39_cursor.ascend(1);
  }
  drop(v36_39_cursor);
  drop(v36_8);
  drop(v36_10);
  (v36_39).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v68_5: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v68_6: Space = restrict_to(&(*CONSTANT_4),&(v68_5));
  drop(v68_5);
  let mut v68_25 = Space::new();
  let mut v68_25_cursor = (v68_6).read_zipper();
  for v68_25_byte in v68_25_cursor.child_mask().iter() {
    v68_25_cursor.descend_to_byte(v68_25_byte);
    {
    let v68_25_tail = v68_25_cursor.fork_read_zipper();
    let v68_25_head = Path::from_slice(&[v68_25_byte]);
    let v69_2: Space = singleton(&(v68_25_head));
    let v69_3: Space = intersect(&(*CONSTANT_1),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (v69_5).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_cursor = (v68_25_tail).read_zipper();
      for v70_6_byte in v70_6_cursor.child_mask().iter() {
        v70_6_cursor.descend_to_byte(v70_6_byte);
        {
        let v70_6_tail = v70_6_cursor.fork_read_zipper();
        let v70_6_head = Path::from_slice(&[v70_6_byte]);
        let v71_2: Space = singleton(&(v70_6_head));
        let v71_3: Space = intersect(&(*CONSTANT_1),&(v71_2));
        let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
          let v72_6: Path = concat_path(&(v68_25_head),&(v70_6_head));
          let mut v72_7 = Space::new();
          let mut v72_7_cursor = (v70_6_tail).read_zipper();
          for v72_7_byte in v72_7_cursor.child_mask().iter() {
            v72_7_cursor.descend_to_byte(v72_7_byte);
            {
            let v72_7_tail = v72_7_cursor.fork_read_zipper();
            let v72_7_head = Path::from_slice(&[v72_7_byte]);
            let v73_2: Space = singleton(&(v72_7_head));
            let v73_3: Space = intersect(&(*CONSTANT_1),&(v73_2));
            let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (v73_5).is_empty() { Space::new() } else {
              let v74_6: Path = concat_path(&(v72_6),&(v72_7_head));
              let v74_7: Space = routine_16(c, &(v74_6), &(v72_7_tail).make_space());
              compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = intersect(&(*CONSTANT_1),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (v73_10).is_empty() { Space::new() } else {
              let v75_6: Path = concat_path(&(v72_6),&(v72_7_head));
              let v75_11: Space = routine_17(c, &(v75_6), &(v72_7_tail).make_space());
              drop(v75_6);
              compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = unite(&(v73_8),&(v73_12));
            v72_7.join_into((v73_13).clone());
            }
            v72_7_cursor.ascend(1);
          }
          drop(v72_7_cursor);
          compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = intersect(&(*CONSTANT_1),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (v71_10).is_empty() { Space::new() } else {
          let v76_6: Path = concat_path(&(v68_25_head),&(v70_6_head));
          let mut v76_11 = Space::new();
          let mut v76_11_cursor = (v70_6_tail).read_zipper();
          for v76_11_byte in v76_11_cursor.child_mask().iter() {
            v76_11_cursor.descend_to_byte(v76_11_byte);
            {
            let v76_11_tail = v76_11_cursor.fork_read_zipper();
            let v76_11_head = Path::from_slice(&[v76_11_byte]);
            let v77_2: Space = singleton(&(v76_11_head));
            let v77_3: Space = intersect(&(*CONSTANT_1),&(v77_2));
            let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
            drop(v77_3);
            let v77_5: Space = subtract(&(*CONSTANT_0),&(v77_4));
            drop(v77_4);
            let v77_8: Space = if (v77_5).is_empty() { Space::new() } else {
              let v78_6: Path = concat_path(&(v76_6),&(v76_11_head));
              let v78_7: Space = routine_16(c, &(v78_6), &(v76_11_tail).make_space());
              compose(&(v77_5),&(v78_7))
            };
            drop(v77_5);
            let v77_9: Space = intersect(&(*CONSTANT_1),&(v77_2));
            drop(v77_2);
            let v77_10: Space = if has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
            drop(v77_9);
            let v77_12: Space = if (v77_10).is_empty() { Space::new() } else {
              let v79_6: Path = concat_path(&(v76_6),&(v76_11_head));
              let v79_11: Space = routine_12(c, &(v79_6), &(v76_11_tail).make_space());
              drop(v79_6);
              compose(&(v77_10),&(v79_11))
            };
            drop(v77_10);
            let v77_13: Space = unite(&(v77_8),&(v77_12));
            v76_11.join_into((v77_13).clone());
            }
            v76_11_cursor.ascend(1);
          }
          drop(v76_11_cursor);
          drop(v76_6);
          compose(&(v71_10),&(v76_11))
        };
        drop(v71_10);
        let v71_13: Space = unite(&(v71_8),&(v71_12));
        v70_6.join_into((v71_13).clone());
        }
        v70_6_cursor.ascend(1);
      }
      drop(v70_6_cursor);
      compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = intersect(&(*CONSTANT_1),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (v69_9).is_empty() { Space::new() } else {
      let mut v80_10 = Space::new();
      let mut v80_10_cursor = (v68_25_tail).read_zipper();
      for v80_10_byte in v80_10_cursor.child_mask().iter() {
        v80_10_cursor.descend_to_byte(v80_10_byte);
        {
        let v80_10_tail = v80_10_cursor.fork_read_zipper();
        let v80_10_head = Path::from_slice(&[v80_10_byte]);
        let v81_2: Space = singleton(&(v80_10_head));
        let v81_3: Space = intersect(&(*CONSTANT_1),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
          let v82_6: Path = concat_path(&(v68_25_head),&(v80_10_head));
          let mut v82_7 = Space::new();
          let mut v82_7_cursor = (v80_10_tail).read_zipper();
          for v82_7_byte in v82_7_cursor.child_mask().iter() {
            v82_7_cursor.descend_to_byte(v82_7_byte);
            {
            let v82_7_tail = v82_7_cursor.fork_read_zipper();
            let v82_7_head = Path::from_slice(&[v82_7_byte]);
            let v83_2: Space = singleton(&(v82_7_head));
            let v83_3: Space = intersect(&(*CONSTANT_1),&(v83_2));
            let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
            drop(v83_4);
            let v83_8: Space = if (v83_5).is_empty() { Space::new() } else {
              let v84_6: Path = concat_path(&(v82_6),&(v82_7_head));
              let v84_7: Space = routine_16(c, &(v84_6), &(v82_7_tail).make_space());
              compose(&(v83_5),&(v84_7))
            };
            drop(v83_5);
            let v83_9: Space = intersect(&(*CONSTANT_1),&(v83_2));
            drop(v83_2);
            let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
            drop(v83_9);
            let v83_12: Space = if (v83_10).is_empty() { Space::new() } else {
              let v85_6: Path = concat_path(&(v82_6),&(v82_7_head));
              let v85_11: Space = routine_17(c, &(v85_6), &(v82_7_tail).make_space());
              drop(v85_6);
              compose(&(v83_10),&(v85_11))
            };
            drop(v83_10);
            let v83_13: Space = unite(&(v83_8),&(v83_12));
            v82_7.join_into((v83_13).clone());
            }
            v82_7_cursor.ascend(1);
          }
          drop(v82_7_cursor);
          drop(v82_6);
          compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = intersect(&(*CONSTANT_1),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_11: Space = compose(&(v81_10),&(v80_10_tail));
        drop(v81_10);
        let v81_12: Space = unite(&(v81_8),&(v81_11));
        drop(v81_11);
        v80_10.join_into((v81_12).clone());
        }
        v80_10_cursor.ascend(1);
      }
      drop(v80_10_cursor);
      compose(&(v69_9),&(v80_10))
    };
    drop(v69_9);
    let v69_12: Space = unite(&(v69_7),&(v69_11));
    v68_25.join_into((v69_12).clone());
    }
    v68_25_cursor.ascend(1);
  }
  drop(v68_25_cursor);
  drop(v68_6);
  let v68_26: Space = restrict_to(&(*CONSTANT_3),&(v68_25));
  let mut v68_45 = Space::new();
  let mut v68_45_cursor = (v68_26).read_zipper();
  for v68_45_byte in v68_45_cursor.child_mask().iter() {
    v68_45_cursor.descend_to_byte(v68_45_byte);
    {
    let v68_45_tail = v68_45_cursor.fork_read_zipper();
    let v68_45_head = Path::from_slice(&[v68_45_byte]);
    let v86_2: Space = singleton(&(v68_45_head));
    let v86_3: Space = intersect(&(*CONSTANT_1),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (v86_5).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_cursor = (v68_45_tail).read_zipper();
      for v87_6_byte in v87_6_cursor.child_mask().iter() {
        v87_6_cursor.descend_to_byte(v87_6_byte);
        {
        let v87_6_tail = v87_6_cursor.fork_read_zipper();
        let v87_6_head = Path::from_slice(&[v87_6_byte]);
        let v88_2: Space = singleton(&(v87_6_head));
        let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
          let v89_6: Path = concat_path(&(v68_45_head),&(v87_6_head));
          let mut v89_7 = Space::new();
          let mut v89_7_cursor = (v87_6_tail).read_zipper();
          for v89_7_byte in v89_7_cursor.child_mask().iter() {
            v89_7_cursor.descend_to_byte(v89_7_byte);
            {
            let v89_7_tail = v89_7_cursor.fork_read_zipper();
            let v89_7_head = Path::from_slice(&[v89_7_byte]);
            let v90_2: Space = singleton(&(v89_7_head));
            let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
            let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
            drop(v90_3);
            let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
            drop(v90_4);
            let v90_8: Space = if (v90_5).is_empty() { Space::new() } else {
              let v91_6: Path = concat_path(&(v89_6),&(v89_7_head));
              let v91_7: Space = routine_18(c, &(v91_6), &(v89_7_tail).make_space());
              compose(&(v90_5),&(v91_7))
            };
            drop(v90_5);
            let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
            drop(v90_2);
            let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
            drop(v90_9);
            let v90_12: Space = if (v90_10).is_empty() { Space::new() } else {
              let v92_6: Path = concat_path(&(v89_6),&(v89_7_head));
              let v92_11: Space = routine_19(c, &(v92_6), &(v89_7_tail).make_space());
              drop(v92_6);
              compose(&(v90_10),&(v92_11))
            };
            drop(v90_10);
            let v90_13: Space = unite(&(v90_8),&(v90_12));
            v89_7.join_into((v90_13).clone());
            }
            v89_7_cursor.ascend(1);
          }
          drop(v89_7_cursor);
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
          let v93_6: Path = concat_path(&(v68_45_head),&(v87_6_head));
          let mut v93_11 = Space::new();
          let mut v93_11_cursor = (v87_6_tail).read_zipper();
          for v93_11_byte in v93_11_cursor.child_mask().iter() {
            v93_11_cursor.descend_to_byte(v93_11_byte);
            {
            let v93_11_tail = v93_11_cursor.fork_read_zipper();
            let v93_11_head = Path::from_slice(&[v93_11_byte]);
            let v94_2: Space = singleton(&(v93_11_head));
            let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
            let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_8: Space = if (v94_5).is_empty() { Space::new() } else {
              let v95_6: Path = concat_path(&(v93_6),&(v93_11_head));
              let v95_7: Space = routine_18(c, &(v95_6), &(v93_11_tail).make_space());
              compose(&(v94_5),&(v95_7))
            };
            drop(v94_5);
            let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
            drop(v94_2);
            let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
            drop(v94_9);
            let v94_12: Space = if (v94_10).is_empty() { Space::new() } else {
              let v96_6: Path = concat_path(&(v93_6),&(v93_11_head));
              let v96_11: Space = routine_15(c, &(v96_6), &(v93_11_tail).make_space());
              drop(v96_6);
              compose(&(v94_10),&(v96_11))
            };
            drop(v94_10);
            let v94_13: Space = unite(&(v94_8),&(v94_12));
            v93_11.join_into((v94_13).clone());
            }
            v93_11_cursor.ascend(1);
          }
          drop(v93_11_cursor);
          drop(v93_6);
          compose(&(v88_10),&(v93_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        v87_6.join_into((v88_13).clone());
        }
        v87_6_cursor.ascend(1);
      }
      drop(v87_6_cursor);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_1),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (v86_9).is_empty() { Space::new() } else {
      let mut v97_10 = Space::new();
      let mut v97_10_cursor = (v68_45_tail).read_zipper();
      for v97_10_byte in v97_10_cursor.child_mask().iter() {
        v97_10_cursor.descend_to_byte(v97_10_byte);
        {
        let v97_10_tail = v97_10_cursor.fork_read_zipper();
        let v97_10_head = Path::from_slice(&[v97_10_byte]);
        let v98_2: Space = singleton(&(v97_10_head));
        let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (v98_5).is_empty() { Space::new() } else {
          let v99_6: Path = concat_path(&(v68_45_head),&(v97_10_head));
          let mut v99_7 = Space::new();
          let mut v99_7_cursor = (v97_10_tail).read_zipper();
          for v99_7_byte in v99_7_cursor.child_mask().iter() {
            v99_7_cursor.descend_to_byte(v99_7_byte);
            {
            let v99_7_tail = v99_7_cursor.fork_read_zipper();
            let v99_7_head = Path::from_slice(&[v99_7_byte]);
            let v100_2: Space = singleton(&(v99_7_head));
            let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
            let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (v100_5).is_empty() { Space::new() } else {
              let v101_6: Path = concat_path(&(v99_6),&(v99_7_head));
              let v101_7: Space = routine_18(c, &(v101_6), &(v99_7_tail).make_space());
              compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (v100_10).is_empty() { Space::new() } else {
              let v102_6: Path = concat_path(&(v99_6),&(v99_7_head));
              let v102_11: Space = routine_19(c, &(v102_6), &(v99_7_tail).make_space());
              drop(v102_6);
              compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = unite(&(v100_8),&(v100_12));
            v99_7.join_into((v100_13).clone());
            }
            v99_7_cursor.ascend(1);
          }
          drop(v99_7_cursor);
          drop(v99_6);
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_11: Space = compose(&(v98_10),&(v97_10_tail));
        drop(v98_10);
        let v98_12: Space = unite(&(v98_8),&(v98_11));
        drop(v98_11);
        v97_10.join_into((v98_12).clone());
        }
        v97_10_cursor.ascend(1);
      }
      drop(v97_10_cursor);
      compose(&(v86_9),&(v97_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    v68_45.join_into((v86_12).clone());
    }
    v68_45_cursor.ascend(1);
  }
  drop(v68_45_cursor);
  let v68_47: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v68_48: Space = subtract(&(v68_45),&(v68_47));
  drop(v68_47);
  let v68_50: Space = intersect(&(v68_48),&(*CONSTANT_5));
  let v68_51: Space = wrap(&(v68_50),&(*p0));
  (v68_51).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v103_17: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v103_18: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v103_25 = Space::new();
  let mut v103_25_cursor = (*s0).read_zipper();
  for v103_25_byte in v103_25_cursor.child_mask().iter() {
    v103_25_cursor.descend_to_byte(v103_25_byte);
    {
    let v103_25_tail = v103_25_cursor.fork_read_zipper();
    let v103_25_head = Path::from_slice(&[v103_25_byte]);
    let v104_2: Space = singleton(&(v103_25_head));
    let v104_3: Space = intersect(&(*CONSTANT_1),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_8: Space = if (v104_5).is_empty() { Space::new() } else {
      let v105_6: Path = concat_path(&(*p0),&(v103_25_head));
      let mut v105_7 = Space::new();
      let mut v105_7_cursor = (v103_25_tail).read_zipper();
      for v105_7_byte in v105_7_cursor.child_mask().iter() {
        v105_7_cursor.descend_to_byte(v105_7_byte);
        {
        let v105_7_tail = v105_7_cursor.fork_read_zipper();
        let v105_7_head = Path::from_slice(&[v105_7_byte]);
        let v106_2: Space = singleton(&(v105_7_head));
        let v106_3: Space = intersect(&(*CONSTANT_1),&(v106_2));
        let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
        drop(v106_4);
        let mut v106_6 = Space::new();
        let mut v106_6_cursor = (v105_7_tail).read_zipper();
        for v106_6_byte in v106_6_cursor.child_mask().iter() {
          v106_6_cursor.descend_to_byte(v106_6_byte);
          {
          let v106_6_tail = v106_6_cursor.fork_read_zipper();
          let v106_6_head = Path::from_slice(&[v106_6_byte]);
          let v107_2: Space = Space::new();
          v106_6.join_into((v107_2).clone());
          }
          v106_6_cursor.ascend(1);
        }
        drop(v106_6_cursor);
        let v106_7: Space = compose(&(v106_5),&(v106_6));
        drop(v106_5);
        drop(v106_6);
        let v106_8: Space = intersect(&(*CONSTANT_1),&(v106_2));
        drop(v106_2);
        let v106_9: Space = if has_head(&(v106_8)) { singleton(&[]) } else { Space::new() };
        drop(v106_8);
        let v106_12: Space = if (v106_9).is_empty() { Space::new() } else {
          let v108_10: Path = concat_path(&(v105_6),&(v105_7_head));
          let mut v108_11 = Space::new();
          let mut v108_11_cursor = (v105_7_tail).read_zipper();
          for v108_11_byte in v108_11_cursor.child_mask().iter() {
            v108_11_cursor.descend_to_byte(v108_11_byte);
            {
            let v108_11_tail = v108_11_cursor.fork_read_zipper();
            let v108_11_head = Path::from_slice(&[v108_11_byte]);
            let v109_2: Space = singleton(&(v108_11_head));
            let v109_3: Space = intersect(&(*CONSTANT_1),&(v109_2));
            drop(v109_2);
            let v109_4: Space = if has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
            drop(v109_3);
            let v109_7: Space = if (v109_4).is_empty() { Space::new() } else {
              let v110_5: Path = concat_path(&(v108_10),&(v108_11_head));
              let v110_6: Space = routine_3(c, &(v110_5), &(v108_11_tail).make_space());
              drop(v110_5);
              compose(&(v109_4),&(v110_6))
            };
            drop(v109_4);
            v108_11.join_into((v109_7).clone());
            }
            v108_11_cursor.ascend(1);
          }
          drop(v108_11_cursor);
          drop(v108_10);
          compose(&(v106_9),&(v108_11))
        };
        drop(v106_9);
        let v106_13: Space = unite(&(v106_7),&(v106_12));
        drop(v106_7);
        v105_7.join_into((v106_13).clone());
        }
        v105_7_cursor.ascend(1);
      }
      drop(v105_7_cursor);
      compose(&(v104_5),&(v105_7))
    };
    drop(v104_5);
    let v104_9: Space = intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
    drop(v104_9);
    let v104_14: Space = if (v104_10).is_empty() { Space::new() } else {
      let v111_6: Path = concat_path(&(*p0),&(v103_25_head));
      let v111_11: Space = unwrap(&(v103_17),&(v103_25_head));
      let v111_12: Space = unwrap(&(v103_18),&(v103_25_head));
      let mut v111_13 = Space::new();
      let mut v111_13_cursor = (v103_25_tail).read_zipper();
      for v111_13_byte in v111_13_cursor.child_mask().iter() {
        v111_13_cursor.descend_to_byte(v111_13_byte);
        {
        let v111_13_tail = v111_13_cursor.fork_read_zipper();
        let v111_13_head = Path::from_slice(&[v111_13_byte]);
        let v112_2: Space = singleton(&(v111_13_head));
        let v112_3: Space = intersect(&(*CONSTANT_1),&(v112_2));
        let v112_4: Space = if has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
        drop(v112_3);
        let v112_5: Space = subtract(&(*CONSTANT_0),&(v112_4));
        drop(v112_4);
        let mut v112_6 = Space::new();
        let mut v112_6_cursor = (v111_13_tail).read_zipper();
        for v112_6_byte in v112_6_cursor.child_mask().iter() {
          v112_6_cursor.descend_to_byte(v112_6_byte);
          {
          let v112_6_tail = v112_6_cursor.fork_read_zipper();
          let v112_6_head = Path::from_slice(&[v112_6_byte]);
          let v113_2: Space = Space::new();
          v112_6.join_into((v113_2).clone());
          }
          v112_6_cursor.ascend(1);
        }
        drop(v112_6_cursor);
        let v112_7: Space = compose(&(v112_5),&(v112_6));
        drop(v112_5);
        drop(v112_6);
        let v112_8: Space = intersect(&(*CONSTANT_1),&(v112_2));
        drop(v112_2);
        let v112_9: Space = if has_head(&(v112_8)) { singleton(&[]) } else { Space::new() };
        drop(v112_8);
        let v112_18: Space = if (v112_9).is_empty() { Space::new() } else {
          let v114_10: Space = unwrap(&(v111_11),&(v111_13_head));
          let v114_11: Space = restrict_to(&(*CONSTANT_4),&(v114_10));
          drop(v114_10);
          let mut v114_12 = Space::new();
          let mut v114_12_cursor = (v114_11).read_zipper();
          for v114_12_byte in v114_12_cursor.child_mask().iter() {
            v114_12_cursor.descend_to_byte(v114_12_byte);
            {
            let v114_12_tail = v114_12_cursor.fork_read_zipper();
            let v114_12_head = Path::from_slice(&[v114_12_byte]);
            let v115_2: Space = singleton(&(v114_12_head));
            let v115_3: Space = intersect(&(*CONSTANT_1),&(v115_2));
            let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
            drop(v115_3);
            let v115_5: Space = subtract(&(*CONSTANT_0),&(v115_4));
            drop(v115_4);
            let v115_7: Space = if (v115_5).is_empty() { Space::new() } else {
              let v116_6: Space = routine_6(c, &(v114_12_head), &(v114_12_tail).make_space());
              compose(&(v115_5),&(v116_6))
            };
            drop(v115_5);
            let v115_8: Space = intersect(&(*CONSTANT_1),&(v115_2));
            drop(v115_2);
            let v115_9: Space = if has_head(&(v115_8)) { singleton(&[]) } else { Space::new() };
            drop(v115_8);
            let v115_11: Space = if (v115_9).is_empty() { Space::new() } else {
              let v117_10: Space = routine_7(c, &(v114_12_head), &(v114_12_tail).make_space());
              compose(&(v115_9),&(v117_10))
            };
            drop(v115_9);
            let v115_12: Space = unite(&(v115_7),&(v115_11));
            v114_12.join_into((v115_12).clone());
            }
            v114_12_cursor.ascend(1);
          }
          drop(v114_12_cursor);
          drop(v114_11);
          let v114_13: Space = restrict_to(&(*CONSTANT_3),&(v114_12));
          let mut v114_14 = Space::new();
          let mut v114_14_cursor = (v114_13).read_zipper();
          for v114_14_byte in v114_14_cursor.child_mask().iter() {
            v114_14_cursor.descend_to_byte(v114_14_byte);
            {
            let v114_14_tail = v114_14_cursor.fork_read_zipper();
            let v114_14_head = Path::from_slice(&[v114_14_byte]);
            let v118_2: Space = singleton(&(v114_14_head));
            let v118_3: Space = intersect(&(*CONSTANT_1),&(v118_2));
            let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
            drop(v118_3);
            let v118_5: Space = subtract(&(*CONSTANT_0),&(v118_4));
            drop(v118_4);
            let v118_7: Space = if (v118_5).is_empty() { Space::new() } else {
              let v119_6: Space = routine_8(c, &(v114_14_head), &(v114_14_tail).make_space());
              compose(&(v118_5),&(v119_6))
            };
            drop(v118_5);
            let v118_8: Space = intersect(&(*CONSTANT_1),&(v118_2));
            drop(v118_2);
            let v118_9: Space = if has_head(&(v118_8)) { singleton(&[]) } else { Space::new() };
            drop(v118_8);
            let v118_11: Space = if (v118_9).is_empty() { Space::new() } else {
              let v120_10: Space = routine_9(c, &(v114_14_head), &(v114_14_tail).make_space());
              compose(&(v118_9),&(v120_10))
            };
            drop(v118_9);
            let v118_12: Space = unite(&(v118_7),&(v118_11));
            v114_14.join_into((v118_12).clone());
            }
            v114_14_cursor.ascend(1);
          }
          drop(v114_14_cursor);
          let v114_15: Space = unwrap(&(v111_12),&(v111_13_head));
          let v114_16: Space = subtract(&(v114_14),&(v114_15));
          drop(v114_15);
          let v114_17: Space = intersect(&(v114_16),&(*CONSTANT_5));
          compose(&(v112_9),&(v114_17))
        };
        drop(v112_9);
        let v112_19: Path = concat_path(&(v111_6),&(v111_13_head));
        let v112_20: Space = wrap(&(v112_18),&(v112_19));
        drop(v112_19);
        let v112_21: Space = unite(&(v112_7),&(v112_20));
        drop(v112_7);
        v111_13.join_into((v112_21).clone());
        }
        v111_13_cursor.ascend(1);
      }
      drop(v111_13_cursor);
      drop(v111_6);
      drop(v111_11);
      drop(v111_12);
      compose(&(v104_10),&(v111_13))
    };
    drop(v104_10);
    let v104_15: Space = unite(&(v104_8),&(v104_14));
    v103_25.join_into((v104_15).clone());
    }
    v103_25_cursor.ascend(1);
  }
  drop(v103_25_cursor);
  drop(v103_17);
  drop(v103_18);
  (v103_25).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v121_8: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v121_10: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v121_34 = Space::new();
  let mut v121_34_cursor = (*s0).read_zipper();
  for v121_34_byte in v121_34_cursor.child_mask().iter() {
    v121_34_cursor.descend_to_byte(v121_34_byte);
    {
    let v121_34_tail = v121_34_cursor.fork_read_zipper();
    let v121_34_head = Path::from_slice(&[v121_34_byte]);
    let v122_2: Space = singleton(&(v121_34_head));
    let v122_3: Space = intersect(&(*CONSTANT_1),&(v122_2));
    let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
    drop(v122_3);
    let v122_5: Space = subtract(&(*CONSTANT_0),&(v122_4));
    drop(v122_4);
    let v122_8: Space = if (v122_5).is_empty() { Space::new() } else {
      let v123_6: Path = concat_path(&(*p0),&(v121_34_head));
      let mut v123_7 = Space::new();
      let mut v123_7_cursor = (v121_34_tail).read_zipper();
      for v123_7_byte in v123_7_cursor.child_mask().iter() {
        v123_7_cursor.descend_to_byte(v123_7_byte);
        {
        let v123_7_tail = v123_7_cursor.fork_read_zipper();
        let v123_7_head = Path::from_slice(&[v123_7_byte]);
        let v124_2: Space = singleton(&(v123_7_head));
        let v124_3: Space = intersect(&(*CONSTANT_1),&(v124_2));
        let v124_4: Space = if has_head(&(v124_3)) { singleton(&[]) } else { Space::new() };
        drop(v124_3);
        let v124_5: Space = subtract(&(*CONSTANT_0),&(v124_4));
        drop(v124_4);
        let mut v124_6 = Space::new();
        let mut v124_6_cursor = (v123_7_tail).read_zipper();
        for v124_6_byte in v124_6_cursor.child_mask().iter() {
          v124_6_cursor.descend_to_byte(v124_6_byte);
          {
          let v124_6_tail = v124_6_cursor.fork_read_zipper();
          let v124_6_head = Path::from_slice(&[v124_6_byte]);
          let v125_2: Space = Space::new();
          v124_6.join_into((v125_2).clone());
          }
          v124_6_cursor.ascend(1);
        }
        drop(v124_6_cursor);
        let v124_7: Space = compose(&(v124_5),&(v124_6));
        drop(v124_5);
        drop(v124_6);
        let v124_8: Space = intersect(&(*CONSTANT_1),&(v124_2));
        drop(v124_2);
        let v124_9: Space = if has_head(&(v124_8)) { singleton(&[]) } else { Space::new() };
        drop(v124_8);
        let v124_12: Space = if (v124_9).is_empty() { Space::new() } else {
          let v126_10: Path = concat_path(&(v123_6),&(v123_7_head));
          let mut v126_11 = Space::new();
          let mut v126_11_cursor = (v123_7_tail).read_zipper();
          for v126_11_byte in v126_11_cursor.child_mask().iter() {
            v126_11_cursor.descend_to_byte(v126_11_byte);
            {
            let v126_11_tail = v126_11_cursor.fork_read_zipper();
            let v126_11_head = Path::from_slice(&[v126_11_byte]);
            let v127_2: Space = singleton(&(v126_11_head));
            let v127_3: Space = intersect(&(*CONSTANT_1),&(v127_2));
            drop(v127_2);
            let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
            drop(v127_3);
            let v127_7: Space = if (v127_4).is_empty() { Space::new() } else {
              let v128_5: Path = concat_path(&(v126_10),&(v126_11_head));
              let v128_6: Space = routine_3(c, &(v128_5), &(v126_11_tail).make_space());
              drop(v128_5);
              compose(&(v127_4),&(v128_6))
            };
            drop(v127_4);
            v126_11.join_into((v127_7).clone());
            }
            v126_11_cursor.ascend(1);
          }
          drop(v126_11_cursor);
          drop(v126_10);
          compose(&(v124_9),&(v126_11))
        };
        drop(v124_9);
        let v124_13: Space = unite(&(v124_7),&(v124_12));
        drop(v124_7);
        v123_7.join_into((v124_13).clone());
        }
        v123_7_cursor.ascend(1);
      }
      drop(v123_7_cursor);
      compose(&(v122_5),&(v123_7))
    };
    drop(v122_5);
    let v122_9: Space = intersect(&(*CONSTANT_1),&(v122_2));
    drop(v122_2);
    let v122_10: Space = if has_head(&(v122_9)) { singleton(&[]) } else { Space::new() };
    drop(v122_9);
    let v122_19: Space = if (v122_10).is_empty() { Space::new() } else {
      let v129_11: Space = unwrap(&(v121_8),&(v121_34_head));
      let v129_12: Space = restrict_to(&(*CONSTANT_4),&(v129_11));
      drop(v129_11);
      let mut v129_13 = Space::new();
      let mut v129_13_cursor = (v129_12).read_zipper();
      for v129_13_byte in v129_13_cursor.child_mask().iter() {
        v129_13_cursor.descend_to_byte(v129_13_byte);
        {
        let v129_13_tail = v129_13_cursor.fork_read_zipper();
        let v129_13_head = Path::from_slice(&[v129_13_byte]);
        let v130_2: Space = singleton(&(v129_13_head));
        let v130_3: Space = intersect(&(*CONSTANT_1),&(v130_2));
        let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
        drop(v130_3);
        let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
        drop(v130_4);
        let v130_7: Space = if (v130_5).is_empty() { Space::new() } else {
          let mut v131_6 = Space::new();
          let mut v131_6_cursor = (v129_13_tail).read_zipper();
          for v131_6_byte in v131_6_cursor.child_mask().iter() {
            v131_6_cursor.descend_to_byte(v131_6_byte);
            {
            let v131_6_tail = v131_6_cursor.fork_read_zipper();
            let v131_6_head = Path::from_slice(&[v131_6_byte]);
            let v132_2: Space = singleton(&(v131_6_head));
            let v132_3: Space = intersect(&(*CONSTANT_1),&(v132_2));
            let v132_4: Space = if has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
            drop(v132_3);
            let v132_5: Space = subtract(&(*CONSTANT_0),&(v132_4));
            drop(v132_4);
            let v132_8: Space = if (v132_5).is_empty() { Space::new() } else {
              let v133_6: Path = concat_path(&(v129_13_head),&(v131_6_head));
              let v133_7: Space = routine_10(c, &(v133_6), &(v131_6_tail).make_space());
              compose(&(v132_5),&(v133_7))
            };
            drop(v132_5);
            let v132_9: Space = intersect(&(*CONSTANT_1),&(v132_2));
            drop(v132_2);
            let v132_10: Space = if has_head(&(v132_9)) { singleton(&[]) } else { Space::new() };
            drop(v132_9);
            let v132_12: Space = if (v132_10).is_empty() { Space::new() } else {
              let v134_6: Path = concat_path(&(v129_13_head),&(v131_6_head));
              let v134_11: Space = routine_11(c, &(v134_6), &(v131_6_tail).make_space());
              drop(v134_6);
              compose(&(v132_10),&(v134_11))
            };
            drop(v132_10);
            let v132_13: Space = unite(&(v132_8),&(v132_12));
            v131_6.join_into((v132_13).clone());
            }
            v131_6_cursor.ascend(1);
          }
          drop(v131_6_cursor);
          compose(&(v130_5),&(v131_6))
        };
        drop(v130_5);
        let v130_8: Space = intersect(&(*CONSTANT_1),&(v130_2));
        drop(v130_2);
        let v130_9: Space = if has_head(&(v130_8)) { singleton(&[]) } else { Space::new() };
        drop(v130_8);
        let v130_11: Space = if (v130_9).is_empty() { Space::new() } else {
          let mut v135_10 = Space::new();
          let mut v135_10_cursor = (v129_13_tail).read_zipper();
          for v135_10_byte in v135_10_cursor.child_mask().iter() {
            v135_10_cursor.descend_to_byte(v135_10_byte);
            {
            let v135_10_tail = v135_10_cursor.fork_read_zipper();
            let v135_10_head = Path::from_slice(&[v135_10_byte]);
            let v136_2: Space = singleton(&(v135_10_head));
            let v136_3: Space = intersect(&(*CONSTANT_1),&(v136_2));
            let v136_4: Space = if has_head(&(v136_3)) { singleton(&[]) } else { Space::new() };
            drop(v136_3);
            let v136_5: Space = subtract(&(*CONSTANT_0),&(v136_4));
            drop(v136_4);
            let v136_8: Space = if (v136_5).is_empty() { Space::new() } else {
              let v137_6: Path = concat_path(&(v129_13_head),&(v135_10_head));
              let v137_7: Space = routine_10(c, &(v137_6), &(v135_10_tail).make_space());
              compose(&(v136_5),&(v137_7))
            };
            drop(v136_5);
            let v136_9: Space = intersect(&(*CONSTANT_1),&(v136_2));
            drop(v136_2);
            let v136_10: Space = if has_head(&(v136_9)) { singleton(&[]) } else { Space::new() };
            drop(v136_9);
            let v136_12: Space = if (v136_10).is_empty() { Space::new() } else {
              let v138_6: Path = concat_path(&(v129_13_head),&(v135_10_head));
              let v138_11: Space = routine_12(c, &(v138_6), &(v135_10_tail).make_space());
              drop(v138_6);
              compose(&(v136_10),&(v138_11))
            };
            drop(v136_10);
            let v136_13: Space = unite(&(v136_8),&(v136_12));
            v135_10.join_into((v136_13).clone());
            }
            v135_10_cursor.ascend(1);
          }
          drop(v135_10_cursor);
          compose(&(v130_9),&(v135_10))
        };
        drop(v130_9);
        let v130_12: Space = unite(&(v130_7),&(v130_11));
        v129_13.join_into((v130_12).clone());
        }
        v129_13_cursor.ascend(1);
      }
      drop(v129_13_cursor);
      drop(v129_12);
      let v129_14: Space = restrict_to(&(*CONSTANT_3),&(v129_13));
      let mut v129_15 = Space::new();
      let mut v129_15_cursor = (v129_14).read_zipper();
      for v129_15_byte in v129_15_cursor.child_mask().iter() {
        v129_15_cursor.descend_to_byte(v129_15_byte);
        {
        let v129_15_tail = v129_15_cursor.fork_read_zipper();
        let v129_15_head = Path::from_slice(&[v129_15_byte]);
        let v139_2: Space = singleton(&(v129_15_head));
        let v139_3: Space = intersect(&(*CONSTANT_1),&(v139_2));
        let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
        drop(v139_3);
        let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
        drop(v139_4);
        let v139_7: Space = if (v139_5).is_empty() { Space::new() } else {
          let mut v140_6 = Space::new();
          let mut v140_6_cursor = (v129_15_tail).read_zipper();
          for v140_6_byte in v140_6_cursor.child_mask().iter() {
            v140_6_cursor.descend_to_byte(v140_6_byte);
            {
            let v140_6_tail = v140_6_cursor.fork_read_zipper();
            let v140_6_head = Path::from_slice(&[v140_6_byte]);
            let v141_2: Space = singleton(&(v140_6_head));
            let v141_3: Space = intersect(&(*CONSTANT_1),&(v141_2));
            let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
            drop(v141_3);
            let v141_5: Space = subtract(&(*CONSTANT_0),&(v141_4));
            drop(v141_4);
            let v141_8: Space = if (v141_5).is_empty() { Space::new() } else {
              let v142_6: Path = concat_path(&(v129_15_head),&(v140_6_head));
              let v142_7: Space = routine_13(c, &(v142_6), &(v140_6_tail).make_space());
              compose(&(v141_5),&(v142_7))
            };
            drop(v141_5);
            let v141_9: Space = intersect(&(*CONSTANT_1),&(v141_2));
            drop(v141_2);
            let v141_10: Space = if has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
            drop(v141_9);
            let v141_12: Space = if (v141_10).is_empty() { Space::new() } else {
              let v143_6: Path = concat_path(&(v129_15_head),&(v140_6_head));
              let v143_11: Space = routine_14(c, &(v143_6), &(v140_6_tail).make_space());
              drop(v143_6);
              compose(&(v141_10),&(v143_11))
            };
            drop(v141_10);
            let v141_13: Space = unite(&(v141_8),&(v141_12));
            v140_6.join_into((v141_13).clone());
            }
            v140_6_cursor.ascend(1);
          }
          drop(v140_6_cursor);
          compose(&(v139_5),&(v140_6))
        };
        drop(v139_5);
        let v139_8: Space = intersect(&(*CONSTANT_1),&(v139_2));
        drop(v139_2);
        let v139_9: Space = if has_head(&(v139_8)) { singleton(&[]) } else { Space::new() };
        drop(v139_8);
        let v139_11: Space = if (v139_9).is_empty() { Space::new() } else {
          let mut v144_10 = Space::new();
          let mut v144_10_cursor = (v129_15_tail).read_zipper();
          for v144_10_byte in v144_10_cursor.child_mask().iter() {
            v144_10_cursor.descend_to_byte(v144_10_byte);
            {
            let v144_10_tail = v144_10_cursor.fork_read_zipper();
            let v144_10_head = Path::from_slice(&[v144_10_byte]);
            let v145_2: Space = singleton(&(v144_10_head));
            let v145_3: Space = intersect(&(*CONSTANT_1),&(v145_2));
            let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
            drop(v145_3);
            let v145_5: Space = subtract(&(*CONSTANT_0),&(v145_4));
            drop(v145_4);
            let v145_8: Space = if (v145_5).is_empty() { Space::new() } else {
              let v146_6: Path = concat_path(&(v129_15_head),&(v144_10_head));
              let v146_7: Space = routine_13(c, &(v146_6), &(v144_10_tail).make_space());
              compose(&(v145_5),&(v146_7))
            };
            drop(v145_5);
            let v145_9: Space = intersect(&(*CONSTANT_1),&(v145_2));
            drop(v145_2);
            let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
            drop(v145_9);
            let v145_12: Space = if (v145_10).is_empty() { Space::new() } else {
              let v147_6: Path = concat_path(&(v129_15_head),&(v144_10_head));
              let v147_11: Space = routine_15(c, &(v147_6), &(v144_10_tail).make_space());
              drop(v147_6);
              compose(&(v145_10),&(v147_11))
            };
            drop(v145_10);
            let v145_13: Space = unite(&(v145_8),&(v145_12));
            v144_10.join_into((v145_13).clone());
            }
            v144_10_cursor.ascend(1);
          }
          drop(v144_10_cursor);
          compose(&(v139_9),&(v144_10))
        };
        drop(v139_9);
        let v139_12: Space = unite(&(v139_7),&(v139_11));
        v129_15.join_into((v139_12).clone());
        }
        v129_15_cursor.ascend(1);
      }
      drop(v129_15_cursor);
      let v129_16: Space = unwrap(&(v121_10),&(v121_34_head));
      let v129_17: Space = subtract(&(v129_15),&(v129_16));
      drop(v129_16);
      let v129_18: Space = intersect(&(v129_17),&(*CONSTANT_5));
      compose(&(v122_10),&(v129_18))
    };
    drop(v122_10);
    let v148_6: Path = concat_path(&(*p0),&(v121_34_head));
    let v122_20: Space = wrap(&(v122_19),&(v148_6));
    let v122_21: Space = unite(&(v122_8),&(v122_20));
    v121_34.join_into((v122_21).clone());
    }
    v121_34_cursor.ascend(1);
  }
  drop(v121_34_cursor);
  drop(v121_8);
  drop(v121_10);
  (v121_34).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v149_20 = Space::new();
  let mut v149_20_cursor = (*s0).read_zipper();
  for v149_20_byte in v149_20_cursor.child_mask().iter() {
    v149_20_cursor.descend_to_byte(v149_20_byte);
    {
    let v149_20_tail = v149_20_cursor.fork_read_zipper();
    let v149_20_head = Path::from_slice(&[v149_20_byte]);
    let v150_2: Space = singleton(&(v149_20_head));
    let v150_3: Space = intersect(&(*CONSTANT_1),&(v150_2));
    let v150_4: Space = if has_head(&(v150_3)) { singleton(&[]) } else { Space::new() };
    drop(v150_3);
    let v150_5: Space = subtract(&(*CONSTANT_0),&(v150_4));
    drop(v150_4);
    let v150_8: Space = if (v150_5).is_empty() { Space::new() } else {
      let v151_6: Path = concat_path(&(*p0),&(v149_20_head));
      let mut v151_7 = Space::new();
      let mut v151_7_cursor = (v149_20_tail).read_zipper();
      for v151_7_byte in v151_7_cursor.child_mask().iter() {
        v151_7_cursor.descend_to_byte(v151_7_byte);
        {
        let v151_7_tail = v151_7_cursor.fork_read_zipper();
        let v151_7_head = Path::from_slice(&[v151_7_byte]);
        let v152_2: Space = singleton(&(v151_7_head));
        let v152_3: Space = intersect(&(*CONSTANT_1),&(v152_2));
        let v152_4: Space = if has_head(&(v152_3)) { singleton(&[]) } else { Space::new() };
        drop(v152_3);
        let v152_5: Space = subtract(&(*CONSTANT_0),&(v152_4));
        drop(v152_4);
        let v152_8: Space = if (v152_5).is_empty() { Space::new() } else {
          let v153_6: Path = concat_path(&(v151_6),&(v151_7_head));
          let mut v153_7 = Space::new();
          let mut v153_7_cursor = (v151_7_tail).read_zipper();
          for v153_7_byte in v153_7_cursor.child_mask().iter() {
            v153_7_cursor.descend_to_byte(v153_7_byte);
            {
            let v153_7_tail = v153_7_cursor.fork_read_zipper();
            let v153_7_head = Path::from_slice(&[v153_7_byte]);
            let v154_2: Space = singleton(&(v153_7_head));
            let v154_3: Space = intersect(&(*CONSTANT_1),&(v154_2));
            let v154_4: Space = if has_head(&(v154_3)) { singleton(&[]) } else { Space::new() };
            drop(v154_3);
            let v154_5: Space = subtract(&(*CONSTANT_0),&(v154_4));
            drop(v154_4);
            let v154_8: Space = if (v154_5).is_empty() { Space::new() } else {
              let v155_6: Path = concat_path(&(v153_6),&(v153_7_head));
              let v155_7: Space = routine_20(c, &(v155_6), &(v153_7_tail).make_space());
              compose(&(v154_5),&(v155_7))
            };
            drop(v154_5);
            let v154_9: Space = intersect(&(*CONSTANT_1),&(v154_2));
            drop(v154_2);
            let v154_10: Space = if has_head(&(v154_9)) { singleton(&[]) } else { Space::new() };
            drop(v154_9);
            let v154_12: Space = if (v154_10).is_empty() { Space::new() } else {
              let v156_6: Path = concat_path(&(v153_6),&(v153_7_head));
              let v156_11: Space = routine_21(c, &(v156_6), &(v153_7_tail).make_space());
              drop(v156_6);
              compose(&(v154_10),&(v156_11))
            };
            drop(v154_10);
            let v154_13: Space = unite(&(v154_8),&(v154_12));
            v153_7.join_into((v154_13).clone());
            }
            v153_7_cursor.ascend(1);
          }
          drop(v153_7_cursor);
          compose(&(v152_5),&(v153_7))
        };
        drop(v152_5);
        let v152_9: Space = intersect(&(*CONSTANT_1),&(v152_2));
        drop(v152_2);
        let v152_10: Space = if has_head(&(v152_9)) { singleton(&[]) } else { Space::new() };
        drop(v152_9);
        let v152_12: Space = if (v152_10).is_empty() { Space::new() } else {
          let v157_6: Path = concat_path(&(v151_6),&(v151_7_head));
          let mut v157_11 = Space::new();
          let mut v157_11_cursor = (v151_7_tail).read_zipper();
          for v157_11_byte in v157_11_cursor.child_mask().iter() {
            v157_11_cursor.descend_to_byte(v157_11_byte);
            {
            let v157_11_tail = v157_11_cursor.fork_read_zipper();
            let v157_11_head = Path::from_slice(&[v157_11_byte]);
            let v158_2: Space = singleton(&(v157_11_head));
            let v158_3: Space = intersect(&(*CONSTANT_1),&(v158_2));
            let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
            drop(v158_3);
            let v158_5: Space = subtract(&(*CONSTANT_0),&(v158_4));
            drop(v158_4);
            let v158_8: Space = if (v158_5).is_empty() { Space::new() } else {
              let v159_6: Path = concat_path(&(v157_6),&(v157_11_head));
              let v159_7: Space = routine_20(c, &(v159_6), &(v157_11_tail).make_space());
              compose(&(v158_5),&(v159_7))
            };
            drop(v158_5);
            let v158_9: Space = intersect(&(*CONSTANT_1),&(v158_2));
            drop(v158_2);
            let v158_10: Space = if has_head(&(v158_9)) { singleton(&[]) } else { Space::new() };
            drop(v158_9);
            let v158_12: Space = if (v158_10).is_empty() { Space::new() } else {
              let v160_6: Path = concat_path(&(v157_6),&(v157_11_head));
              let v160_11: Space = routine_12(c, &(v160_6), &(v157_11_tail).make_space());
              drop(v160_6);
              compose(&(v158_10),&(v160_11))
            };
            drop(v158_10);
            let v158_13: Space = unite(&(v158_8),&(v158_12));
            v157_11.join_into((v158_13).clone());
            }
            v157_11_cursor.ascend(1);
          }
          drop(v157_11_cursor);
          drop(v157_6);
          compose(&(v152_10),&(v157_11))
        };
        drop(v152_10);
        let v152_13: Space = unite(&(v152_8),&(v152_12));
        v151_7.join_into((v152_13).clone());
        }
        v151_7_cursor.ascend(1);
      }
      drop(v151_7_cursor);
      compose(&(v150_5),&(v151_7))
    };
    drop(v150_5);
    let v150_9: Space = intersect(&(*CONSTANT_1),&(v150_2));
    drop(v150_2);
    let v150_10: Space = if has_head(&(v150_9)) { singleton(&[]) } else { Space::new() };
    drop(v150_9);
    let v150_12: Space = if (v150_10).is_empty() { Space::new() } else {
      let v161_6: Path = concat_path(&(*p0),&(v149_20_head));
      let mut v161_11 = Space::new();
      let mut v161_11_cursor = (v149_20_tail).read_zipper();
      for v161_11_byte in v161_11_cursor.child_mask().iter() {
        v161_11_cursor.descend_to_byte(v161_11_byte);
        {
        let v161_11_tail = v161_11_cursor.fork_read_zipper();
        let v161_11_head = Path::from_slice(&[v161_11_byte]);
        let v162_2: Space = singleton(&(v161_11_head));
        let v162_3: Space = intersect(&(*CONSTANT_1),&(v162_2));
        let v162_4: Space = if has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
        drop(v162_3);
        let v162_5: Space = subtract(&(*CONSTANT_0),&(v162_4));
        drop(v162_4);
        let v162_8: Space = if (v162_5).is_empty() { Space::new() } else {
          let v163_6: Path = concat_path(&(v161_6),&(v161_11_head));
          let mut v163_7 = Space::new();
          let mut v163_7_cursor = (v161_11_tail).read_zipper();
          for v163_7_byte in v163_7_cursor.child_mask().iter() {
            v163_7_cursor.descend_to_byte(v163_7_byte);
            {
            let v163_7_tail = v163_7_cursor.fork_read_zipper();
            let v163_7_head = Path::from_slice(&[v163_7_byte]);
            let v164_2: Space = singleton(&(v163_7_head));
            let v164_3: Space = intersect(&(*CONSTANT_1),&(v164_2));
            let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
            drop(v164_3);
            let v164_5: Space = subtract(&(*CONSTANT_0),&(v164_4));
            drop(v164_4);
            let v164_8: Space = if (v164_5).is_empty() { Space::new() } else {
              let v165_6: Path = concat_path(&(v163_6),&(v163_7_head));
              let v165_7: Space = routine_20(c, &(v165_6), &(v163_7_tail).make_space());
              compose(&(v164_5),&(v165_7))
            };
            drop(v164_5);
            let v164_9: Space = intersect(&(*CONSTANT_1),&(v164_2));
            drop(v164_2);
            let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
            drop(v164_9);
            let v164_12: Space = if (v164_10).is_empty() { Space::new() } else {
              let v166_6: Path = concat_path(&(v163_6),&(v163_7_head));
              let v166_11: Space = routine_21(c, &(v166_6), &(v163_7_tail).make_space());
              drop(v166_6);
              compose(&(v164_10),&(v166_11))
            };
            drop(v164_10);
            let v164_13: Space = unite(&(v164_8),&(v164_12));
            v163_7.join_into((v164_13).clone());
            }
            v163_7_cursor.ascend(1);
          }
          drop(v163_7_cursor);
          drop(v163_6);
          compose(&(v162_5),&(v163_7))
        };
        drop(v162_5);
        let v162_9: Space = intersect(&(*CONSTANT_1),&(v162_2));
        drop(v162_2);
        let v162_10: Space = if has_head(&(v162_9)) { singleton(&[]) } else { Space::new() };
        drop(v162_9);
        let v162_11: Space = compose(&(v162_10),&(v161_11_tail));
        drop(v162_10);
        let v162_12: Space = unite(&(v162_8),&(v162_11));
        drop(v162_11);
        v161_11.join_into((v162_12).clone());
        }
        v161_11_cursor.ascend(1);
      }
      drop(v161_11_cursor);
      drop(v161_6);
      compose(&(v150_10),&(v161_11))
    };
    drop(v150_10);
    let v150_13: Space = unite(&(v150_8),&(v150_12));
    v149_20.join_into((v150_13).clone());
    }
    v149_20_cursor.ascend(1);
  }
  drop(v149_20_cursor);
  (v149_20).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v167_14 = Space::new();
  let mut v167_14_cursor = (*s0).read_zipper();
  for v167_14_byte in v167_14_cursor.child_mask().iter() {
    v167_14_cursor.descend_to_byte(v167_14_byte);
    {
    let v167_14_tail = v167_14_cursor.fork_read_zipper();
    let v167_14_head = Path::from_slice(&[v167_14_byte]);
    let v168_2: Space = singleton(&(v167_14_head));
    let v168_3: Space = intersect(&(*CONSTANT_1),&(v168_2));
    let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
    drop(v168_3);
    let v168_5: Space = subtract(&(*CONSTANT_0),&(v168_4));
    drop(v168_4);
    let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
      let v169_6: Path = concat_path(&(*p0),&(v167_14_head));
      let mut v169_7 = Space::new();
      let mut v169_7_cursor = (v167_14_tail).read_zipper();
      for v169_7_byte in v169_7_cursor.child_mask().iter() {
        v169_7_cursor.descend_to_byte(v169_7_byte);
        {
        let v169_7_tail = v169_7_cursor.fork_read_zipper();
        let v169_7_head = Path::from_slice(&[v169_7_byte]);
        let v170_2: Space = singleton(&(v169_7_head));
        let v170_3: Space = intersect(&(*CONSTANT_1),&(v170_2));
        let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
        drop(v170_3);
        let v170_5: Space = subtract(&(*CONSTANT_0),&(v170_4));
        drop(v170_4);
        let v170_8: Space = if (v170_5).is_empty() { Space::new() } else {
          let v171_6: Path = concat_path(&(v169_6),&(v169_7_head));
          let mut v171_7 = Space::new();
          let mut v171_7_cursor = (v169_7_tail).read_zipper();
          for v171_7_byte in v171_7_cursor.child_mask().iter() {
            v171_7_cursor.descend_to_byte(v171_7_byte);
            {
            let v171_7_tail = v171_7_cursor.fork_read_zipper();
            let v171_7_head = Path::from_slice(&[v171_7_byte]);
            let v172_2: Space = singleton(&(v171_7_head));
            let v172_3: Space = intersect(&(*CONSTANT_1),&(v172_2));
            let v172_4: Space = if has_head(&(v172_3)) { singleton(&[]) } else { Space::new() };
            drop(v172_3);
            let v172_5: Space = subtract(&(*CONSTANT_0),&(v172_4));
            drop(v172_4);
            let v172_8: Space = if (v172_5).is_empty() { Space::new() } else {
              let v173_6: Path = concat_path(&(v171_6),&(v171_7_head));
              let v173_7: Space = routine_20(c, &(v173_6), &(v171_7_tail).make_space());
              compose(&(v172_5),&(v173_7))
            };
            drop(v172_5);
            let v172_9: Space = intersect(&(*CONSTANT_1),&(v172_2));
            drop(v172_2);
            let v172_10: Space = if has_head(&(v172_9)) { singleton(&[]) } else { Space::new() };
            drop(v172_9);
            let v172_12: Space = if (v172_10).is_empty() { Space::new() } else {
              let v174_6: Path = concat_path(&(v171_6),&(v171_7_head));
              let v174_11: Space = routine_21(c, &(v174_6), &(v171_7_tail).make_space());
              drop(v174_6);
              compose(&(v172_10),&(v174_11))
            };
            drop(v172_10);
            let v172_13: Space = unite(&(v172_8),&(v172_12));
            v171_7.join_into((v172_13).clone());
            }
            v171_7_cursor.ascend(1);
          }
          drop(v171_7_cursor);
          compose(&(v170_5),&(v171_7))
        };
        drop(v170_5);
        let v170_9: Space = intersect(&(*CONSTANT_1),&(v170_2));
        drop(v170_2);
        let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
        drop(v170_9);
        let v170_12: Space = if (v170_10).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v169_6),&(v169_7_head));
          let mut v175_11 = Space::new();
          let mut v175_11_cursor = (v169_7_tail).read_zipper();
          for v175_11_byte in v175_11_cursor.child_mask().iter() {
            v175_11_cursor.descend_to_byte(v175_11_byte);
            {
            let v175_11_tail = v175_11_cursor.fork_read_zipper();
            let v175_11_head = Path::from_slice(&[v175_11_byte]);
            let v176_2: Space = singleton(&(v175_11_head));
            let v176_3: Space = intersect(&(*CONSTANT_1),&(v176_2));
            let v176_4: Space = if has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
            drop(v176_3);
            let v176_5: Space = subtract(&(*CONSTANT_0),&(v176_4));
            drop(v176_4);
            let v176_8: Space = if (v176_5).is_empty() { Space::new() } else {
              let v177_6: Path = concat_path(&(v175_6),&(v175_11_head));
              let v177_7: Space = routine_20(c, &(v177_6), &(v175_11_tail).make_space());
              compose(&(v176_5),&(v177_7))
            };
            drop(v176_5);
            let v176_9: Space = intersect(&(*CONSTANT_1),&(v176_2));
            drop(v176_2);
            let v176_10: Space = if has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
            drop(v176_9);
            let v176_12: Space = if (v176_10).is_empty() { Space::new() } else {
              let v178_6: Path = concat_path(&(v175_6),&(v175_11_head));
              let v178_11: Space = routine_12(c, &(v178_6), &(v175_11_tail).make_space());
              drop(v178_6);
              compose(&(v176_10),&(v178_11))
            };
            drop(v176_10);
            let v176_13: Space = unite(&(v176_8),&(v176_12));
            v175_11.join_into((v176_13).clone());
            }
            v175_11_cursor.ascend(1);
          }
          drop(v175_11_cursor);
          drop(v175_6);
          compose(&(v170_10),&(v175_11))
        };
        drop(v170_10);
        let v170_13: Space = unite(&(v170_8),&(v170_12));
        v169_7.join_into((v170_13).clone());
        }
        v169_7_cursor.ascend(1);
      }
      drop(v169_7_cursor);
      drop(v169_6);
      compose(&(v168_5),&(v169_7))
    };
    drop(v168_5);
    let v168_9: Space = intersect(&(*CONSTANT_1),&(v168_2));
    drop(v168_2);
    let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
    drop(v168_9);
    let v168_11: Space = compose(&(v168_10),&(v167_14_tail));
    drop(v168_10);
    let v168_12: Space = unite(&(v168_8),&(v168_11));
    drop(v168_11);
    v167_14.join_into((v168_12).clone());
    }
    v167_14_cursor.ascend(1);
  }
  drop(v167_14_cursor);
  (v167_14).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v179_20 = Space::new();
  let mut v179_20_cursor = (*s0).read_zipper();
  for v179_20_byte in v179_20_cursor.child_mask().iter() {
    v179_20_cursor.descend_to_byte(v179_20_byte);
    {
    let v179_20_tail = v179_20_cursor.fork_read_zipper();
    let v179_20_head = Path::from_slice(&[v179_20_byte]);
    let v180_2: Space = singleton(&(v179_20_head));
    let v180_3: Space = intersect(&(*CONSTANT_1),&(v180_2));
    let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
    drop(v180_3);
    let v180_5: Space = subtract(&(*CONSTANT_0),&(v180_4));
    drop(v180_4);
    let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
      let v181_6: Path = concat_path(&(*p0),&(v179_20_head));
      let mut v181_7 = Space::new();
      let mut v181_7_cursor = (v179_20_tail).read_zipper();
      for v181_7_byte in v181_7_cursor.child_mask().iter() {
        v181_7_cursor.descend_to_byte(v181_7_byte);
        {
        let v181_7_tail = v181_7_cursor.fork_read_zipper();
        let v181_7_head = Path::from_slice(&[v181_7_byte]);
        let v182_2: Space = singleton(&(v181_7_head));
        let v182_3: Space = intersect(&(*CONSTANT_1),&(v182_2));
        let v182_4: Space = if has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
        drop(v182_3);
        let v182_5: Space = subtract(&(*CONSTANT_0),&(v182_4));
        drop(v182_4);
        let v182_8: Space = if (v182_5).is_empty() { Space::new() } else {
          let v183_6: Path = concat_path(&(v181_6),&(v181_7_head));
          let mut v183_7 = Space::new();
          let mut v183_7_cursor = (v181_7_tail).read_zipper();
          for v183_7_byte in v183_7_cursor.child_mask().iter() {
            v183_7_cursor.descend_to_byte(v183_7_byte);
            {
            let v183_7_tail = v183_7_cursor.fork_read_zipper();
            let v183_7_head = Path::from_slice(&[v183_7_byte]);
            let v184_2: Space = singleton(&(v183_7_head));
            let v184_3: Space = intersect(&(*CONSTANT_1),&(v184_2));
            let v184_4: Space = if has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
            drop(v184_3);
            let v184_5: Space = subtract(&(*CONSTANT_0),&(v184_4));
            drop(v184_4);
            let v184_8: Space = if (v184_5).is_empty() { Space::new() } else {
              let v185_6: Path = concat_path(&(v183_6),&(v183_7_head));
              let v185_7: Space = routine_22(c, &(v185_6), &(v183_7_tail).make_space());
              compose(&(v184_5),&(v185_7))
            };
            drop(v184_5);
            let v184_9: Space = intersect(&(*CONSTANT_1),&(v184_2));
            drop(v184_2);
            let v184_10: Space = if has_head(&(v184_9)) { singleton(&[]) } else { Space::new() };
            drop(v184_9);
            let v184_12: Space = if (v184_10).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v183_6),&(v183_7_head));
              let v186_11: Space = routine_23(c, &(v186_6), &(v183_7_tail).make_space());
              drop(v186_6);
              compose(&(v184_10),&(v186_11))
            };
            drop(v184_10);
            let v184_13: Space = unite(&(v184_8),&(v184_12));
            v183_7.join_into((v184_13).clone());
            }
            v183_7_cursor.ascend(1);
          }
          drop(v183_7_cursor);
          compose(&(v182_5),&(v183_7))
        };
        drop(v182_5);
        let v182_9: Space = intersect(&(*CONSTANT_1),&(v182_2));
        drop(v182_2);
        let v182_10: Space = if has_head(&(v182_9)) { singleton(&[]) } else { Space::new() };
        drop(v182_9);
        let v182_12: Space = if (v182_10).is_empty() { Space::new() } else {
          let v187_6: Path = concat_path(&(v181_6),&(v181_7_head));
          let mut v187_11 = Space::new();
          let mut v187_11_cursor = (v181_7_tail).read_zipper();
          for v187_11_byte in v187_11_cursor.child_mask().iter() {
            v187_11_cursor.descend_to_byte(v187_11_byte);
            {
            let v187_11_tail = v187_11_cursor.fork_read_zipper();
            let v187_11_head = Path::from_slice(&[v187_11_byte]);
            let v188_2: Space = singleton(&(v187_11_head));
            let v188_3: Space = intersect(&(*CONSTANT_1),&(v188_2));
            let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
            drop(v188_3);
            let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
            drop(v188_4);
            let v188_8: Space = if (v188_5).is_empty() { Space::new() } else {
              let v189_6: Path = concat_path(&(v187_6),&(v187_11_head));
              let v189_7: Space = routine_22(c, &(v189_6), &(v187_11_tail).make_space());
              compose(&(v188_5),&(v189_7))
            };
            drop(v188_5);
            let v188_9: Space = intersect(&(*CONSTANT_1),&(v188_2));
            drop(v188_2);
            let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
            drop(v188_9);
            let v188_12: Space = if (v188_10).is_empty() { Space::new() } else {
              let v190_6: Path = concat_path(&(v187_6),&(v187_11_head));
              let v190_11: Space = routine_15(c, &(v190_6), &(v187_11_tail).make_space());
              drop(v190_6);
              compose(&(v188_10),&(v190_11))
            };
            drop(v188_10);
            let v188_13: Space = unite(&(v188_8),&(v188_12));
            v187_11.join_into((v188_13).clone());
            }
            v187_11_cursor.ascend(1);
          }
          drop(v187_11_cursor);
          drop(v187_6);
          compose(&(v182_10),&(v187_11))
        };
        drop(v182_10);
        let v182_13: Space = unite(&(v182_8),&(v182_12));
        v181_7.join_into((v182_13).clone());
        }
        v181_7_cursor.ascend(1);
      }
      drop(v181_7_cursor);
      compose(&(v180_5),&(v181_7))
    };
    drop(v180_5);
    let v180_9: Space = intersect(&(*CONSTANT_1),&(v180_2));
    drop(v180_2);
    let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
    drop(v180_9);
    let v180_12: Space = if (v180_10).is_empty() { Space::new() } else {
      let v191_6: Path = concat_path(&(*p0),&(v179_20_head));
      let mut v191_11 = Space::new();
      let mut v191_11_cursor = (v179_20_tail).read_zipper();
      for v191_11_byte in v191_11_cursor.child_mask().iter() {
        v191_11_cursor.descend_to_byte(v191_11_byte);
        {
        let v191_11_tail = v191_11_cursor.fork_read_zipper();
        let v191_11_head = Path::from_slice(&[v191_11_byte]);
        let v192_2: Space = singleton(&(v191_11_head));
        let v192_3: Space = intersect(&(*CONSTANT_1),&(v192_2));
        let v192_4: Space = if has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
        drop(v192_3);
        let v192_5: Space = subtract(&(*CONSTANT_0),&(v192_4));
        drop(v192_4);
        let v192_8: Space = if (v192_5).is_empty() { Space::new() } else {
          let v193_6: Path = concat_path(&(v191_6),&(v191_11_head));
          let mut v193_7 = Space::new();
          let mut v193_7_cursor = (v191_11_tail).read_zipper();
          for v193_7_byte in v193_7_cursor.child_mask().iter() {
            v193_7_cursor.descend_to_byte(v193_7_byte);
            {
            let v193_7_tail = v193_7_cursor.fork_read_zipper();
            let v193_7_head = Path::from_slice(&[v193_7_byte]);
            let v194_2: Space = singleton(&(v193_7_head));
            let v194_3: Space = intersect(&(*CONSTANT_1),&(v194_2));
            let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
            drop(v194_3);
            let v194_5: Space = subtract(&(*CONSTANT_0),&(v194_4));
            drop(v194_4);
            let v194_8: Space = if (v194_5).is_empty() { Space::new() } else {
              let v195_6: Path = concat_path(&(v193_6),&(v193_7_head));
              let v195_7: Space = routine_22(c, &(v195_6), &(v193_7_tail).make_space());
              compose(&(v194_5),&(v195_7))
            };
            drop(v194_5);
            let v194_9: Space = intersect(&(*CONSTANT_1),&(v194_2));
            drop(v194_2);
            let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
            drop(v194_9);
            let v194_12: Space = if (v194_10).is_empty() { Space::new() } else {
              let v196_6: Path = concat_path(&(v193_6),&(v193_7_head));
              let v196_11: Space = routine_23(c, &(v196_6), &(v193_7_tail).make_space());
              drop(v196_6);
              compose(&(v194_10),&(v196_11))
            };
            drop(v194_10);
            let v194_13: Space = unite(&(v194_8),&(v194_12));
            v193_7.join_into((v194_13).clone());
            }
            v193_7_cursor.ascend(1);
          }
          drop(v193_7_cursor);
          drop(v193_6);
          compose(&(v192_5),&(v193_7))
        };
        drop(v192_5);
        let v192_9: Space = intersect(&(*CONSTANT_1),&(v192_2));
        drop(v192_2);
        let v192_10: Space = if has_head(&(v192_9)) { singleton(&[]) } else { Space::new() };
        drop(v192_9);
        let v192_11: Space = compose(&(v192_10),&(v191_11_tail));
        drop(v192_10);
        let v192_12: Space = unite(&(v192_8),&(v192_11));
        drop(v192_11);
        v191_11.join_into((v192_12).clone());
        }
        v191_11_cursor.ascend(1);
      }
      drop(v191_11_cursor);
      drop(v191_6);
      compose(&(v180_10),&(v191_11))
    };
    drop(v180_10);
    let v180_13: Space = unite(&(v180_8),&(v180_12));
    v179_20.join_into((v180_13).clone());
    }
    v179_20_cursor.ascend(1);
  }
  drop(v179_20_cursor);
  (v179_20).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v197_14 = Space::new();
  let mut v197_14_cursor = (*s0).read_zipper();
  for v197_14_byte in v197_14_cursor.child_mask().iter() {
    v197_14_cursor.descend_to_byte(v197_14_byte);
    {
    let v197_14_tail = v197_14_cursor.fork_read_zipper();
    let v197_14_head = Path::from_slice(&[v197_14_byte]);
    let v198_2: Space = singleton(&(v197_14_head));
    let v198_3: Space = intersect(&(*CONSTANT_1),&(v198_2));
    let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
    drop(v198_3);
    let v198_5: Space = subtract(&(*CONSTANT_0),&(v198_4));
    drop(v198_4);
    let v198_8: Space = if (v198_5).is_empty() { Space::new() } else {
      let v199_6: Path = concat_path(&(*p0),&(v197_14_head));
      let mut v199_7 = Space::new();
      let mut v199_7_cursor = (v197_14_tail).read_zipper();
      for v199_7_byte in v199_7_cursor.child_mask().iter() {
        v199_7_cursor.descend_to_byte(v199_7_byte);
        {
        let v199_7_tail = v199_7_cursor.fork_read_zipper();
        let v199_7_head = Path::from_slice(&[v199_7_byte]);
        let v200_2: Space = singleton(&(v199_7_head));
        let v200_3: Space = intersect(&(*CONSTANT_1),&(v200_2));
        let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
        drop(v200_3);
        let v200_5: Space = subtract(&(*CONSTANT_0),&(v200_4));
        drop(v200_4);
        let v200_8: Space = if (v200_5).is_empty() { Space::new() } else {
          let v201_6: Path = concat_path(&(v199_6),&(v199_7_head));
          let mut v201_7 = Space::new();
          let mut v201_7_cursor = (v199_7_tail).read_zipper();
          for v201_7_byte in v201_7_cursor.child_mask().iter() {
            v201_7_cursor.descend_to_byte(v201_7_byte);
            {
            let v201_7_tail = v201_7_cursor.fork_read_zipper();
            let v201_7_head = Path::from_slice(&[v201_7_byte]);
            let v202_2: Space = singleton(&(v201_7_head));
            let v202_3: Space = intersect(&(*CONSTANT_1),&(v202_2));
            let v202_4: Space = if has_head(&(v202_3)) { singleton(&[]) } else { Space::new() };
            drop(v202_3);
            let v202_5: Space = subtract(&(*CONSTANT_0),&(v202_4));
            drop(v202_4);
            let v202_8: Space = if (v202_5).is_empty() { Space::new() } else {
              let v203_6: Path = concat_path(&(v201_6),&(v201_7_head));
              let v203_7: Space = routine_22(c, &(v203_6), &(v201_7_tail).make_space());
              compose(&(v202_5),&(v203_7))
            };
            drop(v202_5);
            let v202_9: Space = intersect(&(*CONSTANT_1),&(v202_2));
            drop(v202_2);
            let v202_10: Space = if has_head(&(v202_9)) { singleton(&[]) } else { Space::new() };
            drop(v202_9);
            let v202_12: Space = if (v202_10).is_empty() { Space::new() } else {
              let v204_6: Path = concat_path(&(v201_6),&(v201_7_head));
              let v204_11: Space = routine_23(c, &(v204_6), &(v201_7_tail).make_space());
              drop(v204_6);
              compose(&(v202_10),&(v204_11))
            };
            drop(v202_10);
            let v202_13: Space = unite(&(v202_8),&(v202_12));
            v201_7.join_into((v202_13).clone());
            }
            v201_7_cursor.ascend(1);
          }
          drop(v201_7_cursor);
          compose(&(v200_5),&(v201_7))
        };
        drop(v200_5);
        let v200_9: Space = intersect(&(*CONSTANT_1),&(v200_2));
        drop(v200_2);
        let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
        drop(v200_9);
        let v200_12: Space = if (v200_10).is_empty() { Space::new() } else {
          let v205_6: Path = concat_path(&(v199_6),&(v199_7_head));
          let mut v205_11 = Space::new();
          let mut v205_11_cursor = (v199_7_tail).read_zipper();
          for v205_11_byte in v205_11_cursor.child_mask().iter() {
            v205_11_cursor.descend_to_byte(v205_11_byte);
            {
            let v205_11_tail = v205_11_cursor.fork_read_zipper();
            let v205_11_head = Path::from_slice(&[v205_11_byte]);
            let v206_2: Space = singleton(&(v205_11_head));
            let v206_3: Space = intersect(&(*CONSTANT_1),&(v206_2));
            let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
            drop(v206_3);
            let v206_5: Space = subtract(&(*CONSTANT_0),&(v206_4));
            drop(v206_4);
            let v206_8: Space = if (v206_5).is_empty() { Space::new() } else {
              let v207_6: Path = concat_path(&(v205_6),&(v205_11_head));
              let v207_7: Space = routine_22(c, &(v207_6), &(v205_11_tail).make_space());
              compose(&(v206_5),&(v207_7))
            };
            drop(v206_5);
            let v206_9: Space = intersect(&(*CONSTANT_1),&(v206_2));
            drop(v206_2);
            let v206_10: Space = if has_head(&(v206_9)) { singleton(&[]) } else { Space::new() };
            drop(v206_9);
            let v206_12: Space = if (v206_10).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v205_6),&(v205_11_head));
              let v208_11: Space = routine_15(c, &(v208_6), &(v205_11_tail).make_space());
              drop(v208_6);
              compose(&(v206_10),&(v208_11))
            };
            drop(v206_10);
            let v206_13: Space = unite(&(v206_8),&(v206_12));
            v205_11.join_into((v206_13).clone());
            }
            v205_11_cursor.ascend(1);
          }
          drop(v205_11_cursor);
          drop(v205_6);
          compose(&(v200_10),&(v205_11))
        };
        drop(v200_10);
        let v200_13: Space = unite(&(v200_8),&(v200_12));
        v199_7.join_into((v200_13).clone());
        }
        v199_7_cursor.ascend(1);
      }
      drop(v199_7_cursor);
      drop(v199_6);
      compose(&(v198_5),&(v199_7))
    };
    drop(v198_5);
    let v198_9: Space = intersect(&(*CONSTANT_1),&(v198_2));
    drop(v198_2);
    let v198_10: Space = if has_head(&(v198_9)) { singleton(&[]) } else { Space::new() };
    drop(v198_9);
    let v198_11: Space = compose(&(v198_10),&(v197_14_tail));
    drop(v198_10);
    let v198_12: Space = unite(&(v198_8),&(v198_11));
    drop(v198_11);
    v197_14.join_into((v198_12).clone());
    }
    v197_14_cursor.ascend(1);
  }
  drop(v197_14_cursor);
  (v197_14).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v209_20 = Space::new();
  let mut v209_20_cursor = (*s0).read_zipper();
  for v209_20_byte in v209_20_cursor.child_mask().iter() {
    v209_20_cursor.descend_to_byte(v209_20_byte);
    {
    let v209_20_tail = v209_20_cursor.fork_read_zipper();
    let v209_20_head = Path::from_slice(&[v209_20_byte]);
    let v210_2: Space = singleton(&(v209_20_head));
    let v210_3: Space = intersect(&(*CONSTANT_1),&(v210_2));
    let v210_4: Space = if has_head(&(v210_3)) { singleton(&[]) } else { Space::new() };
    drop(v210_3);
    let v210_5: Space = subtract(&(*CONSTANT_0),&(v210_4));
    drop(v210_4);
    let v210_8: Space = if (v210_5).is_empty() { Space::new() } else {
      let v211_6: Path = concat_path(&(*p0),&(v209_20_head));
      let mut v211_7 = Space::new();
      let mut v211_7_cursor = (v209_20_tail).read_zipper();
      for v211_7_byte in v211_7_cursor.child_mask().iter() {
        v211_7_cursor.descend_to_byte(v211_7_byte);
        {
        let v211_7_tail = v211_7_cursor.fork_read_zipper();
        let v211_7_head = Path::from_slice(&[v211_7_byte]);
        let v212_2: Space = singleton(&(v211_7_head));
        let v212_3: Space = intersect(&(*CONSTANT_1),&(v212_2));
        let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
        drop(v212_3);
        let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
        drop(v212_4);
        let v212_8: Space = if (v212_5).is_empty() { Space::new() } else {
          let v213_6: Path = concat_path(&(v211_6),&(v211_7_head));
          let mut v213_7 = Space::new();
          let mut v213_7_cursor = (v211_7_tail).read_zipper();
          for v213_7_byte in v213_7_cursor.child_mask().iter() {
            v213_7_cursor.descend_to_byte(v213_7_byte);
            {
            let v213_7_tail = v213_7_cursor.fork_read_zipper();
            let v213_7_head = Path::from_slice(&[v213_7_byte]);
            let v214_2: Space = singleton(&(v213_7_head));
            let v214_3: Space = intersect(&(*CONSTANT_1),&(v214_2));
            let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
            drop(v214_3);
            let v214_5: Space = subtract(&(*CONSTANT_0),&(v214_4));
            drop(v214_4);
            let v214_8: Space = if (v214_5).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v213_6),&(v213_7_head));
              let v215_7: Space = routine_24(c, &(v215_6), &(v213_7_tail).make_space());
              compose(&(v214_5),&(v215_7))
            };
            drop(v214_5);
            let v214_9: Space = intersect(&(*CONSTANT_1),&(v214_2));
            drop(v214_2);
            let v214_10: Space = if has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
            drop(v214_9);
            let v214_12: Space = if (v214_10).is_empty() { Space::new() } else {
              let v216_6: Path = concat_path(&(v213_6),&(v213_7_head));
              let v216_11: Space = routine_25(c, &(v216_6), &(v213_7_tail).make_space());
              drop(v216_6);
              compose(&(v214_10),&(v216_11))
            };
            drop(v214_10);
            let v214_13: Space = unite(&(v214_8),&(v214_12));
            v213_7.join_into((v214_13).clone());
            }
            v213_7_cursor.ascend(1);
          }
          drop(v213_7_cursor);
          compose(&(v212_5),&(v213_7))
        };
        drop(v212_5);
        let v212_9: Space = intersect(&(*CONSTANT_1),&(v212_2));
        drop(v212_2);
        let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
        drop(v212_9);
        let v212_12: Space = if (v212_10).is_empty() { Space::new() } else {
          let v217_6: Path = concat_path(&(v211_6),&(v211_7_head));
          let mut v217_11 = Space::new();
          let mut v217_11_cursor = (v211_7_tail).read_zipper();
          for v217_11_byte in v217_11_cursor.child_mask().iter() {
            v217_11_cursor.descend_to_byte(v217_11_byte);
            {
            let v217_11_tail = v217_11_cursor.fork_read_zipper();
            let v217_11_head = Path::from_slice(&[v217_11_byte]);
            let v218_2: Space = singleton(&(v217_11_head));
            let v218_3: Space = intersect(&(*CONSTANT_1),&(v218_2));
            let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
            drop(v218_3);
            let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
            drop(v218_4);
            let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
              let v219_6: Path = concat_path(&(v217_6),&(v217_11_head));
              let v219_7: Space = routine_24(c, &(v219_6), &(v217_11_tail).make_space());
              compose(&(v218_5),&(v219_7))
            };
            drop(v218_5);
            let v218_9: Space = intersect(&(*CONSTANT_1),&(v218_2));
            drop(v218_2);
            let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
            drop(v218_9);
            let v218_12: Space = if (v218_10).is_empty() { Space::new() } else {
              let v220_6: Path = concat_path(&(v217_6),&(v217_11_head));
              let v220_11: Space = routine_12(c, &(v220_6), &(v217_11_tail).make_space());
              drop(v220_6);
              compose(&(v218_10),&(v220_11))
            };
            drop(v218_10);
            let v218_13: Space = unite(&(v218_8),&(v218_12));
            v217_11.join_into((v218_13).clone());
            }
            v217_11_cursor.ascend(1);
          }
          drop(v217_11_cursor);
          drop(v217_6);
          compose(&(v212_10),&(v217_11))
        };
        drop(v212_10);
        let v212_13: Space = unite(&(v212_8),&(v212_12));
        v211_7.join_into((v212_13).clone());
        }
        v211_7_cursor.ascend(1);
      }
      drop(v211_7_cursor);
      compose(&(v210_5),&(v211_7))
    };
    drop(v210_5);
    let v210_9: Space = intersect(&(*CONSTANT_1),&(v210_2));
    drop(v210_2);
    let v210_10: Space = if has_head(&(v210_9)) { singleton(&[]) } else { Space::new() };
    drop(v210_9);
    let v210_12: Space = if (v210_10).is_empty() { Space::new() } else {
      let v221_6: Path = concat_path(&(*p0),&(v209_20_head));
      let mut v221_11 = Space::new();
      let mut v221_11_cursor = (v209_20_tail).read_zipper();
      for v221_11_byte in v221_11_cursor.child_mask().iter() {
        v221_11_cursor.descend_to_byte(v221_11_byte);
        {
        let v221_11_tail = v221_11_cursor.fork_read_zipper();
        let v221_11_head = Path::from_slice(&[v221_11_byte]);
        let v222_2: Space = singleton(&(v221_11_head));
        let v222_3: Space = intersect(&(*CONSTANT_1),&(v222_2));
        let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
        drop(v222_3);
        let v222_5: Space = subtract(&(*CONSTANT_0),&(v222_4));
        drop(v222_4);
        let v222_8: Space = if (v222_5).is_empty() { Space::new() } else {
          let v223_6: Path = concat_path(&(v221_6),&(v221_11_head));
          let mut v223_7 = Space::new();
          let mut v223_7_cursor = (v221_11_tail).read_zipper();
          for v223_7_byte in v223_7_cursor.child_mask().iter() {
            v223_7_cursor.descend_to_byte(v223_7_byte);
            {
            let v223_7_tail = v223_7_cursor.fork_read_zipper();
            let v223_7_head = Path::from_slice(&[v223_7_byte]);
            let v224_2: Space = singleton(&(v223_7_head));
            let v224_3: Space = intersect(&(*CONSTANT_1),&(v224_2));
            let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
            drop(v224_3);
            let v224_5: Space = subtract(&(*CONSTANT_0),&(v224_4));
            drop(v224_4);
            let v224_8: Space = if (v224_5).is_empty() { Space::new() } else {
              let v225_6: Path = concat_path(&(v223_6),&(v223_7_head));
              let v225_7: Space = routine_24(c, &(v225_6), &(v223_7_tail).make_space());
              compose(&(v224_5),&(v225_7))
            };
            drop(v224_5);
            let v224_9: Space = intersect(&(*CONSTANT_1),&(v224_2));
            drop(v224_2);
            let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
            drop(v224_9);
            let v224_12: Space = if (v224_10).is_empty() { Space::new() } else {
              let v226_6: Path = concat_path(&(v223_6),&(v223_7_head));
              let v226_11: Space = routine_25(c, &(v226_6), &(v223_7_tail).make_space());
              drop(v226_6);
              compose(&(v224_10),&(v226_11))
            };
            drop(v224_10);
            let v224_13: Space = unite(&(v224_8),&(v224_12));
            v223_7.join_into((v224_13).clone());
            }
            v223_7_cursor.ascend(1);
          }
          drop(v223_7_cursor);
          drop(v223_6);
          compose(&(v222_5),&(v223_7))
        };
        drop(v222_5);
        let v222_9: Space = intersect(&(*CONSTANT_1),&(v222_2));
        drop(v222_2);
        let v222_10: Space = if has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
        drop(v222_9);
        let v222_11: Space = compose(&(v222_10),&(v221_11_tail));
        drop(v222_10);
        let v222_12: Space = unite(&(v222_8),&(v222_11));
        drop(v222_11);
        v221_11.join_into((v222_12).clone());
        }
        v221_11_cursor.ascend(1);
      }
      drop(v221_11_cursor);
      drop(v221_6);
      compose(&(v210_10),&(v221_11))
    };
    drop(v210_10);
    let v210_13: Space = unite(&(v210_8),&(v210_12));
    v209_20.join_into((v210_13).clone());
    }
    v209_20_cursor.ascend(1);
  }
  drop(v209_20_cursor);
  (v209_20).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v227_14 = Space::new();
  let mut v227_14_cursor = (*s0).read_zipper();
  for v227_14_byte in v227_14_cursor.child_mask().iter() {
    v227_14_cursor.descend_to_byte(v227_14_byte);
    {
    let v227_14_tail = v227_14_cursor.fork_read_zipper();
    let v227_14_head = Path::from_slice(&[v227_14_byte]);
    let v228_2: Space = singleton(&(v227_14_head));
    let v228_3: Space = intersect(&(*CONSTANT_1),&(v228_2));
    let v228_4: Space = if has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
    drop(v228_3);
    let v228_5: Space = subtract(&(*CONSTANT_0),&(v228_4));
    drop(v228_4);
    let v228_8: Space = if (v228_5).is_empty() { Space::new() } else {
      let v229_6: Path = concat_path(&(*p0),&(v227_14_head));
      let mut v229_7 = Space::new();
      let mut v229_7_cursor = (v227_14_tail).read_zipper();
      for v229_7_byte in v229_7_cursor.child_mask().iter() {
        v229_7_cursor.descend_to_byte(v229_7_byte);
        {
        let v229_7_tail = v229_7_cursor.fork_read_zipper();
        let v229_7_head = Path::from_slice(&[v229_7_byte]);
        let v230_2: Space = singleton(&(v229_7_head));
        let v230_3: Space = intersect(&(*CONSTANT_1),&(v230_2));
        let v230_4: Space = if has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
        drop(v230_3);
        let v230_5: Space = subtract(&(*CONSTANT_0),&(v230_4));
        drop(v230_4);
        let v230_8: Space = if (v230_5).is_empty() { Space::new() } else {
          let v231_6: Path = concat_path(&(v229_6),&(v229_7_head));
          let mut v231_7 = Space::new();
          let mut v231_7_cursor = (v229_7_tail).read_zipper();
          for v231_7_byte in v231_7_cursor.child_mask().iter() {
            v231_7_cursor.descend_to_byte(v231_7_byte);
            {
            let v231_7_tail = v231_7_cursor.fork_read_zipper();
            let v231_7_head = Path::from_slice(&[v231_7_byte]);
            let v232_2: Space = singleton(&(v231_7_head));
            let v232_3: Space = intersect(&(*CONSTANT_1),&(v232_2));
            let v232_4: Space = if has_head(&(v232_3)) { singleton(&[]) } else { Space::new() };
            drop(v232_3);
            let v232_5: Space = subtract(&(*CONSTANT_0),&(v232_4));
            drop(v232_4);
            let v232_8: Space = if (v232_5).is_empty() { Space::new() } else {
              let v233_6: Path = concat_path(&(v231_6),&(v231_7_head));
              let v233_7: Space = routine_24(c, &(v233_6), &(v231_7_tail).make_space());
              compose(&(v232_5),&(v233_7))
            };
            drop(v232_5);
            let v232_9: Space = intersect(&(*CONSTANT_1),&(v232_2));
            drop(v232_2);
            let v232_10: Space = if has_head(&(v232_9)) { singleton(&[]) } else { Space::new() };
            drop(v232_9);
            let v232_12: Space = if (v232_10).is_empty() { Space::new() } else {
              let v234_6: Path = concat_path(&(v231_6),&(v231_7_head));
              let v234_11: Space = routine_25(c, &(v234_6), &(v231_7_tail).make_space());
              drop(v234_6);
              compose(&(v232_10),&(v234_11))
            };
            drop(v232_10);
            let v232_13: Space = unite(&(v232_8),&(v232_12));
            v231_7.join_into((v232_13).clone());
            }
            v231_7_cursor.ascend(1);
          }
          drop(v231_7_cursor);
          compose(&(v230_5),&(v231_7))
        };
        drop(v230_5);
        let v230_9: Space = intersect(&(*CONSTANT_1),&(v230_2));
        drop(v230_2);
        let v230_10: Space = if has_head(&(v230_9)) { singleton(&[]) } else { Space::new() };
        drop(v230_9);
        let v230_12: Space = if (v230_10).is_empty() { Space::new() } else {
          let v235_6: Path = concat_path(&(v229_6),&(v229_7_head));
          let mut v235_11 = Space::new();
          let mut v235_11_cursor = (v229_7_tail).read_zipper();
          for v235_11_byte in v235_11_cursor.child_mask().iter() {
            v235_11_cursor.descend_to_byte(v235_11_byte);
            {
            let v235_11_tail = v235_11_cursor.fork_read_zipper();
            let v235_11_head = Path::from_slice(&[v235_11_byte]);
            let v236_2: Space = singleton(&(v235_11_head));
            let v236_3: Space = intersect(&(*CONSTANT_1),&(v236_2));
            let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
            drop(v236_3);
            let v236_5: Space = subtract(&(*CONSTANT_0),&(v236_4));
            drop(v236_4);
            let v236_8: Space = if (v236_5).is_empty() { Space::new() } else {
              let v237_6: Path = concat_path(&(v235_6),&(v235_11_head));
              let v237_7: Space = routine_24(c, &(v237_6), &(v235_11_tail).make_space());
              compose(&(v236_5),&(v237_7))
            };
            drop(v236_5);
            let v236_9: Space = intersect(&(*CONSTANT_1),&(v236_2));
            drop(v236_2);
            let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
            drop(v236_9);
            let v236_12: Space = if (v236_10).is_empty() { Space::new() } else {
              let v238_6: Path = concat_path(&(v235_6),&(v235_11_head));
              let v238_11: Space = routine_12(c, &(v238_6), &(v235_11_tail).make_space());
              drop(v238_6);
              compose(&(v236_10),&(v238_11))
            };
            drop(v236_10);
            let v236_13: Space = unite(&(v236_8),&(v236_12));
            v235_11.join_into((v236_13).clone());
            }
            v235_11_cursor.ascend(1);
          }
          drop(v235_11_cursor);
          drop(v235_6);
          compose(&(v230_10),&(v235_11))
        };
        drop(v230_10);
        let v230_13: Space = unite(&(v230_8),&(v230_12));
        v229_7.join_into((v230_13).clone());
        }
        v229_7_cursor.ascend(1);
      }
      drop(v229_7_cursor);
      drop(v229_6);
      compose(&(v228_5),&(v229_7))
    };
    drop(v228_5);
    let v228_9: Space = intersect(&(*CONSTANT_1),&(v228_2));
    drop(v228_2);
    let v228_10: Space = if has_head(&(v228_9)) { singleton(&[]) } else { Space::new() };
    drop(v228_9);
    let v228_11: Space = compose(&(v228_10),&(v227_14_tail));
    drop(v228_10);
    let v228_12: Space = unite(&(v228_8),&(v228_11));
    drop(v228_11);
    v227_14.join_into((v228_12).clone());
    }
    v227_14_cursor.ascend(1);
  }
  drop(v227_14_cursor);
  (v227_14).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v240_20 = Space::new();
  let mut v240_20_cursor = (*s0).read_zipper();
  for v240_20_byte in v240_20_cursor.child_mask().iter() {
    v240_20_cursor.descend_to_byte(v240_20_byte);
    {
    let v240_20_tail = v240_20_cursor.fork_read_zipper();
    let v240_20_head = Path::from_slice(&[v240_20_byte]);
    let v241_2: Space = singleton(&(v240_20_head));
    let v241_3: Space = intersect(&(*CONSTANT_1),&(v241_2));
    let v241_4: Space = if has_head(&(v241_3)) { singleton(&[]) } else { Space::new() };
    drop(v241_3);
    let v241_5: Space = subtract(&(*CONSTANT_0),&(v241_4));
    drop(v241_4);
    let v241_8: Space = if (v241_5).is_empty() { Space::new() } else {
      let v242_6: Path = concat_path(&(*p0),&(v240_20_head));
      let mut v242_7 = Space::new();
      let mut v242_7_cursor = (v240_20_tail).read_zipper();
      for v242_7_byte in v242_7_cursor.child_mask().iter() {
        v242_7_cursor.descend_to_byte(v242_7_byte);
        {
        let v242_7_tail = v242_7_cursor.fork_read_zipper();
        let v242_7_head = Path::from_slice(&[v242_7_byte]);
        let v243_2: Space = singleton(&(v242_7_head));
        let v243_3: Space = intersect(&(*CONSTANT_1),&(v243_2));
        let v243_4: Space = if has_head(&(v243_3)) { singleton(&[]) } else { Space::new() };
        drop(v243_3);
        let v243_5: Space = subtract(&(*CONSTANT_0),&(v243_4));
        drop(v243_4);
        let v243_8: Space = if (v243_5).is_empty() { Space::new() } else {
          let v244_6: Path = concat_path(&(v242_6),&(v242_7_head));
          let mut v244_7 = Space::new();
          let mut v244_7_cursor = (v242_7_tail).read_zipper();
          for v244_7_byte in v244_7_cursor.child_mask().iter() {
            v244_7_cursor.descend_to_byte(v244_7_byte);
            {
            let v244_7_tail = v244_7_cursor.fork_read_zipper();
            let v244_7_head = Path::from_slice(&[v244_7_byte]);
            let v245_2: Space = singleton(&(v244_7_head));
            let v245_3: Space = intersect(&(*CONSTANT_1),&(v245_2));
            let v245_4: Space = if has_head(&(v245_3)) { singleton(&[]) } else { Space::new() };
            drop(v245_3);
            let v245_5: Space = subtract(&(*CONSTANT_0),&(v245_4));
            drop(v245_4);
            let v245_8: Space = if (v245_5).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v244_6),&(v244_7_head));
              let v246_7: Space = routine_26(c, &(v246_6), &(v244_7_tail).make_space());
              compose(&(v245_5),&(v246_7))
            };
            drop(v245_5);
            let v245_9: Space = intersect(&(*CONSTANT_1),&(v245_2));
            drop(v245_2);
            let v245_10: Space = if has_head(&(v245_9)) { singleton(&[]) } else { Space::new() };
            drop(v245_9);
            let v245_12: Space = if (v245_10).is_empty() { Space::new() } else {
              let v247_6: Path = concat_path(&(v244_6),&(v244_7_head));
              let v247_11: Space = routine_27(c, &(v247_6), &(v244_7_tail).make_space());
              drop(v247_6);
              compose(&(v245_10),&(v247_11))
            };
            drop(v245_10);
            let v245_13: Space = unite(&(v245_8),&(v245_12));
            v244_7.join_into((v245_13).clone());
            }
            v244_7_cursor.ascend(1);
          }
          drop(v244_7_cursor);
          compose(&(v243_5),&(v244_7))
        };
        drop(v243_5);
        let v243_9: Space = intersect(&(*CONSTANT_1),&(v243_2));
        drop(v243_2);
        let v243_10: Space = if has_head(&(v243_9)) { singleton(&[]) } else { Space::new() };
        drop(v243_9);
        let v243_12: Space = if (v243_10).is_empty() { Space::new() } else {
          let v248_6: Path = concat_path(&(v242_6),&(v242_7_head));
          let mut v248_11 = Space::new();
          let mut v248_11_cursor = (v242_7_tail).read_zipper();
          for v248_11_byte in v248_11_cursor.child_mask().iter() {
            v248_11_cursor.descend_to_byte(v248_11_byte);
            {
            let v248_11_tail = v248_11_cursor.fork_read_zipper();
            let v248_11_head = Path::from_slice(&[v248_11_byte]);
            let v249_2: Space = singleton(&(v248_11_head));
            let v249_3: Space = intersect(&(*CONSTANT_1),&(v249_2));
            let v249_4: Space = if has_head(&(v249_3)) { singleton(&[]) } else { Space::new() };
            drop(v249_3);
            let v249_5: Space = subtract(&(*CONSTANT_0),&(v249_4));
            drop(v249_4);
            let v249_8: Space = if (v249_5).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v248_6),&(v248_11_head));
              let v250_7: Space = routine_26(c, &(v250_6), &(v248_11_tail).make_space());
              compose(&(v249_5),&(v250_7))
            };
            drop(v249_5);
            let v249_9: Space = intersect(&(*CONSTANT_1),&(v249_2));
            drop(v249_2);
            let v249_10: Space = if has_head(&(v249_9)) { singleton(&[]) } else { Space::new() };
            drop(v249_9);
            let v249_12: Space = if (v249_10).is_empty() { Space::new() } else {
              let v251_6: Path = concat_path(&(v248_6),&(v248_11_head));
              let v251_11: Space = routine_15(c, &(v251_6), &(v248_11_tail).make_space());
              drop(v251_6);
              compose(&(v249_10),&(v251_11))
            };
            drop(v249_10);
            let v249_13: Space = unite(&(v249_8),&(v249_12));
            v248_11.join_into((v249_13).clone());
            }
            v248_11_cursor.ascend(1);
          }
          drop(v248_11_cursor);
          drop(v248_6);
          compose(&(v243_10),&(v248_11))
        };
        drop(v243_10);
        let v243_13: Space = unite(&(v243_8),&(v243_12));
        v242_7.join_into((v243_13).clone());
        }
        v242_7_cursor.ascend(1);
      }
      drop(v242_7_cursor);
      compose(&(v241_5),&(v242_7))
    };
    drop(v241_5);
    let v241_9: Space = intersect(&(*CONSTANT_1),&(v241_2));
    drop(v241_2);
    let v241_10: Space = if has_head(&(v241_9)) { singleton(&[]) } else { Space::new() };
    drop(v241_9);
    let v241_12: Space = if (v241_10).is_empty() { Space::new() } else {
      let v252_6: Path = concat_path(&(*p0),&(v240_20_head));
      let mut v252_11 = Space::new();
      let mut v252_11_cursor = (v240_20_tail).read_zipper();
      for v252_11_byte in v252_11_cursor.child_mask().iter() {
        v252_11_cursor.descend_to_byte(v252_11_byte);
        {
        let v252_11_tail = v252_11_cursor.fork_read_zipper();
        let v252_11_head = Path::from_slice(&[v252_11_byte]);
        let v253_2: Space = singleton(&(v252_11_head));
        let v253_3: Space = intersect(&(*CONSTANT_1),&(v253_2));
        let v253_4: Space = if has_head(&(v253_3)) { singleton(&[]) } else { Space::new() };
        drop(v253_3);
        let v253_5: Space = subtract(&(*CONSTANT_0),&(v253_4));
        drop(v253_4);
        let v253_8: Space = if (v253_5).is_empty() { Space::new() } else {
          let v254_6: Path = concat_path(&(v252_6),&(v252_11_head));
          let mut v254_7 = Space::new();
          let mut v254_7_cursor = (v252_11_tail).read_zipper();
          for v254_7_byte in v254_7_cursor.child_mask().iter() {
            v254_7_cursor.descend_to_byte(v254_7_byte);
            {
            let v254_7_tail = v254_7_cursor.fork_read_zipper();
            let v254_7_head = Path::from_slice(&[v254_7_byte]);
            let v255_2: Space = singleton(&(v254_7_head));
            let v255_3: Space = intersect(&(*CONSTANT_1),&(v255_2));
            let v255_4: Space = if has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
            drop(v255_3);
            let v255_5: Space = subtract(&(*CONSTANT_0),&(v255_4));
            drop(v255_4);
            let v255_8: Space = if (v255_5).is_empty() { Space::new() } else {
              let v256_6: Path = concat_path(&(v254_6),&(v254_7_head));
              let v256_7: Space = routine_26(c, &(v256_6), &(v254_7_tail).make_space());
              compose(&(v255_5),&(v256_7))
            };
            drop(v255_5);
            let v255_9: Space = intersect(&(*CONSTANT_1),&(v255_2));
            drop(v255_2);
            let v255_10: Space = if has_head(&(v255_9)) { singleton(&[]) } else { Space::new() };
            drop(v255_9);
            let v255_12: Space = if (v255_10).is_empty() { Space::new() } else {
              let v257_6: Path = concat_path(&(v254_6),&(v254_7_head));
              let v257_11: Space = routine_27(c, &(v257_6), &(v254_7_tail).make_space());
              drop(v257_6);
              compose(&(v255_10),&(v257_11))
            };
            drop(v255_10);
            let v255_13: Space = unite(&(v255_8),&(v255_12));
            v254_7.join_into((v255_13).clone());
            }
            v254_7_cursor.ascend(1);
          }
          drop(v254_7_cursor);
          drop(v254_6);
          compose(&(v253_5),&(v254_7))
        };
        drop(v253_5);
        let v253_9: Space = intersect(&(*CONSTANT_1),&(v253_2));
        drop(v253_2);
        let v253_10: Space = if has_head(&(v253_9)) { singleton(&[]) } else { Space::new() };
        drop(v253_9);
        let v253_11: Space = compose(&(v253_10),&(v252_11_tail));
        drop(v253_10);
        let v253_12: Space = unite(&(v253_8),&(v253_11));
        drop(v253_11);
        v252_11.join_into((v253_12).clone());
        }
        v252_11_cursor.ascend(1);
      }
      drop(v252_11_cursor);
      drop(v252_6);
      compose(&(v241_10),&(v252_11))
    };
    drop(v241_10);
    let v241_13: Space = unite(&(v241_8),&(v241_12));
    v240_20.join_into((v241_13).clone());
    }
    v240_20_cursor.ascend(1);
  }
  drop(v240_20_cursor);
  (v240_20).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v258_14 = Space::new();
  let mut v258_14_cursor = (*s0).read_zipper();
  for v258_14_byte in v258_14_cursor.child_mask().iter() {
    v258_14_cursor.descend_to_byte(v258_14_byte);
    {
    let v258_14_tail = v258_14_cursor.fork_read_zipper();
    let v258_14_head = Path::from_slice(&[v258_14_byte]);
    let v259_2: Space = singleton(&(v258_14_head));
    let v259_3: Space = intersect(&(*CONSTANT_1),&(v259_2));
    let v259_4: Space = if has_head(&(v259_3)) { singleton(&[]) } else { Space::new() };
    drop(v259_3);
    let v259_5: Space = subtract(&(*CONSTANT_0),&(v259_4));
    drop(v259_4);
    let v259_8: Space = if (v259_5).is_empty() { Space::new() } else {
      let v260_6: Path = concat_path(&(*p0),&(v258_14_head));
      let mut v260_7 = Space::new();
      let mut v260_7_cursor = (v258_14_tail).read_zipper();
      for v260_7_byte in v260_7_cursor.child_mask().iter() {
        v260_7_cursor.descend_to_byte(v260_7_byte);
        {
        let v260_7_tail = v260_7_cursor.fork_read_zipper();
        let v260_7_head = Path::from_slice(&[v260_7_byte]);
        let v261_2: Space = singleton(&(v260_7_head));
        let v261_3: Space = intersect(&(*CONSTANT_1),&(v261_2));
        let v261_4: Space = if has_head(&(v261_3)) { singleton(&[]) } else { Space::new() };
        drop(v261_3);
        let v261_5: Space = subtract(&(*CONSTANT_0),&(v261_4));
        drop(v261_4);
        let v261_8: Space = if (v261_5).is_empty() { Space::new() } else {
          let v262_6: Path = concat_path(&(v260_6),&(v260_7_head));
          let mut v262_7 = Space::new();
          let mut v262_7_cursor = (v260_7_tail).read_zipper();
          for v262_7_byte in v262_7_cursor.child_mask().iter() {
            v262_7_cursor.descend_to_byte(v262_7_byte);
            {
            let v262_7_tail = v262_7_cursor.fork_read_zipper();
            let v262_7_head = Path::from_slice(&[v262_7_byte]);
            let v263_2: Space = singleton(&(v262_7_head));
            let v263_3: Space = intersect(&(*CONSTANT_1),&(v263_2));
            let v263_4: Space = if has_head(&(v263_3)) { singleton(&[]) } else { Space::new() };
            drop(v263_3);
            let v263_5: Space = subtract(&(*CONSTANT_0),&(v263_4));
            drop(v263_4);
            let v263_8: Space = if (v263_5).is_empty() { Space::new() } else {
              let v264_6: Path = concat_path(&(v262_6),&(v262_7_head));
              let v264_7: Space = routine_26(c, &(v264_6), &(v262_7_tail).make_space());
              compose(&(v263_5),&(v264_7))
            };
            drop(v263_5);
            let v263_9: Space = intersect(&(*CONSTANT_1),&(v263_2));
            drop(v263_2);
            let v263_10: Space = if has_head(&(v263_9)) { singleton(&[]) } else { Space::new() };
            drop(v263_9);
            let v263_12: Space = if (v263_10).is_empty() { Space::new() } else {
              let v265_6: Path = concat_path(&(v262_6),&(v262_7_head));
              let v265_11: Space = routine_27(c, &(v265_6), &(v262_7_tail).make_space());
              drop(v265_6);
              compose(&(v263_10),&(v265_11))
            };
            drop(v263_10);
            let v263_13: Space = unite(&(v263_8),&(v263_12));
            v262_7.join_into((v263_13).clone());
            }
            v262_7_cursor.ascend(1);
          }
          drop(v262_7_cursor);
          compose(&(v261_5),&(v262_7))
        };
        drop(v261_5);
        let v261_9: Space = intersect(&(*CONSTANT_1),&(v261_2));
        drop(v261_2);
        let v261_10: Space = if has_head(&(v261_9)) { singleton(&[]) } else { Space::new() };
        drop(v261_9);
        let v261_12: Space = if (v261_10).is_empty() { Space::new() } else {
          let v266_6: Path = concat_path(&(v260_6),&(v260_7_head));
          let mut v266_11 = Space::new();
          let mut v266_11_cursor = (v260_7_tail).read_zipper();
          for v266_11_byte in v266_11_cursor.child_mask().iter() {
            v266_11_cursor.descend_to_byte(v266_11_byte);
            {
            let v266_11_tail = v266_11_cursor.fork_read_zipper();
            let v266_11_head = Path::from_slice(&[v266_11_byte]);
            let v267_2: Space = singleton(&(v266_11_head));
            let v267_3: Space = intersect(&(*CONSTANT_1),&(v267_2));
            let v267_4: Space = if has_head(&(v267_3)) { singleton(&[]) } else { Space::new() };
            drop(v267_3);
            let v267_5: Space = subtract(&(*CONSTANT_0),&(v267_4));
            drop(v267_4);
            let v267_8: Space = if (v267_5).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v266_6),&(v266_11_head));
              let v268_7: Space = routine_26(c, &(v268_6), &(v266_11_tail).make_space());
              compose(&(v267_5),&(v268_7))
            };
            drop(v267_5);
            let v267_9: Space = intersect(&(*CONSTANT_1),&(v267_2));
            drop(v267_2);
            let v267_10: Space = if has_head(&(v267_9)) { singleton(&[]) } else { Space::new() };
            drop(v267_9);
            let v267_12: Space = if (v267_10).is_empty() { Space::new() } else {
              let v269_6: Path = concat_path(&(v266_6),&(v266_11_head));
              let v269_11: Space = routine_15(c, &(v269_6), &(v266_11_tail).make_space());
              drop(v269_6);
              compose(&(v267_10),&(v269_11))
            };
            drop(v267_10);
            let v267_13: Space = unite(&(v267_8),&(v267_12));
            v266_11.join_into((v267_13).clone());
            }
            v266_11_cursor.ascend(1);
          }
          drop(v266_11_cursor);
          drop(v266_6);
          compose(&(v261_10),&(v266_11))
        };
        drop(v261_10);
        let v261_13: Space = unite(&(v261_8),&(v261_12));
        v260_7.join_into((v261_13).clone());
        }
        v260_7_cursor.ascend(1);
      }
      drop(v260_7_cursor);
      drop(v260_6);
      compose(&(v259_5),&(v260_7))
    };
    drop(v259_5);
    let v259_9: Space = intersect(&(*CONSTANT_1),&(v259_2));
    drop(v259_2);
    let v259_10: Space = if has_head(&(v259_9)) { singleton(&[]) } else { Space::new() };
    drop(v259_9);
    let v259_11: Space = compose(&(v259_10),&(v258_14_tail));
    drop(v259_10);
    let v259_12: Space = unite(&(v259_8),&(v259_11));
    drop(v259_11);
    v258_14.join_into((v259_12).clone());
    }
    v258_14_cursor.ascend(1);
  }
  drop(v258_14_cursor);
  (v258_14).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v271_20 = Space::new();
  let mut v271_20_cursor = (*s0).read_zipper();
  for v271_20_byte in v271_20_cursor.child_mask().iter() {
    v271_20_cursor.descend_to_byte(v271_20_byte);
    {
    let v271_20_tail = v271_20_cursor.fork_read_zipper();
    let v271_20_head = Path::from_slice(&[v271_20_byte]);
    let v272_2: Space = singleton(&(v271_20_head));
    let v272_3: Space = intersect(&(*CONSTANT_1),&(v272_2));
    let v272_4: Space = if has_head(&(v272_3)) { singleton(&[]) } else { Space::new() };
    drop(v272_3);
    let v272_5: Space = subtract(&(*CONSTANT_0),&(v272_4));
    drop(v272_4);
    let v272_8: Space = if (v272_5).is_empty() { Space::new() } else {
      let v273_6: Path = concat_path(&(*p0),&(v271_20_head));
      let mut v273_7 = Space::new();
      let mut v273_7_cursor = (v271_20_tail).read_zipper();
      for v273_7_byte in v273_7_cursor.child_mask().iter() {
        v273_7_cursor.descend_to_byte(v273_7_byte);
        {
        let v273_7_tail = v273_7_cursor.fork_read_zipper();
        let v273_7_head = Path::from_slice(&[v273_7_byte]);
        let v274_2: Space = singleton(&(v273_7_head));
        let v274_3: Space = intersect(&(*CONSTANT_1),&(v274_2));
        let v274_4: Space = if has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
        drop(v274_3);
        let v274_5: Space = subtract(&(*CONSTANT_0),&(v274_4));
        drop(v274_4);
        let v274_8: Space = if (v274_5).is_empty() { Space::new() } else {
          let v275_6: Path = concat_path(&(v273_6),&(v273_7_head));
          let mut v275_7 = Space::new();
          let mut v275_7_cursor = (v273_7_tail).read_zipper();
          for v275_7_byte in v275_7_cursor.child_mask().iter() {
            v275_7_cursor.descend_to_byte(v275_7_byte);
            {
            let v275_7_tail = v275_7_cursor.fork_read_zipper();
            let v275_7_head = Path::from_slice(&[v275_7_byte]);
            let v276_2: Space = singleton(&(v275_7_head));
            let v276_3: Space = intersect(&(*CONSTANT_1),&(v276_2));
            let v276_4: Space = if has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
            drop(v276_3);
            let v276_5: Space = subtract(&(*CONSTANT_0),&(v276_4));
            drop(v276_4);
            let v276_8: Space = if (v276_5).is_empty() { Space::new() } else {
              let v277_6: Path = concat_path(&(v275_6),&(v275_7_head));
              let v277_7: Space = routine_28(c, &(v277_6), &(v275_7_tail).make_space());
              compose(&(v276_5),&(v277_7))
            };
            drop(v276_5);
            let v276_9: Space = intersect(&(*CONSTANT_1),&(v276_2));
            drop(v276_2);
            let v276_10: Space = if has_head(&(v276_9)) { singleton(&[]) } else { Space::new() };
            drop(v276_9);
            let v276_12: Space = if (v276_10).is_empty() { Space::new() } else {
              let v278_6: Path = concat_path(&(v275_6),&(v275_7_head));
              let v278_11: Space = routine_29(c, &(v278_6), &(v275_7_tail).make_space());
              drop(v278_6);
              compose(&(v276_10),&(v278_11))
            };
            drop(v276_10);
            let v276_13: Space = unite(&(v276_8),&(v276_12));
            v275_7.join_into((v276_13).clone());
            }
            v275_7_cursor.ascend(1);
          }
          drop(v275_7_cursor);
          compose(&(v274_5),&(v275_7))
        };
        drop(v274_5);
        let v274_9: Space = intersect(&(*CONSTANT_1),&(v274_2));
        drop(v274_2);
        let v274_10: Space = if has_head(&(v274_9)) { singleton(&[]) } else { Space::new() };
        drop(v274_9);
        let v274_12: Space = if (v274_10).is_empty() { Space::new() } else {
          let v279_6: Path = concat_path(&(v273_6),&(v273_7_head));
          let mut v279_11 = Space::new();
          let mut v279_11_cursor = (v273_7_tail).read_zipper();
          for v279_11_byte in v279_11_cursor.child_mask().iter() {
            v279_11_cursor.descend_to_byte(v279_11_byte);
            {
            let v279_11_tail = v279_11_cursor.fork_read_zipper();
            let v279_11_head = Path::from_slice(&[v279_11_byte]);
            let v280_2: Space = singleton(&(v279_11_head));
            let v280_3: Space = intersect(&(*CONSTANT_1),&(v280_2));
            let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
            drop(v280_3);
            let v280_5: Space = subtract(&(*CONSTANT_0),&(v280_4));
            drop(v280_4);
            let v280_8: Space = if (v280_5).is_empty() { Space::new() } else {
              let v281_6: Path = concat_path(&(v279_6),&(v279_11_head));
              let v281_7: Space = routine_28(c, &(v281_6), &(v279_11_tail).make_space());
              compose(&(v280_5),&(v281_7))
            };
            drop(v280_5);
            let v280_9: Space = intersect(&(*CONSTANT_1),&(v280_2));
            drop(v280_2);
            let v280_10: Space = if has_head(&(v280_9)) { singleton(&[]) } else { Space::new() };
            drop(v280_9);
            let v280_12: Space = if (v280_10).is_empty() { Space::new() } else {
              let v282_6: Path = concat_path(&(v279_6),&(v279_11_head));
              let v282_11: Space = routine_12(c, &(v282_6), &(v279_11_tail).make_space());
              drop(v282_6);
              compose(&(v280_10),&(v282_11))
            };
            drop(v280_10);
            let v280_13: Space = unite(&(v280_8),&(v280_12));
            v279_11.join_into((v280_13).clone());
            }
            v279_11_cursor.ascend(1);
          }
          drop(v279_11_cursor);
          drop(v279_6);
          compose(&(v274_10),&(v279_11))
        };
        drop(v274_10);
        let v274_13: Space = unite(&(v274_8),&(v274_12));
        v273_7.join_into((v274_13).clone());
        }
        v273_7_cursor.ascend(1);
      }
      drop(v273_7_cursor);
      compose(&(v272_5),&(v273_7))
    };
    drop(v272_5);
    let v272_9: Space = intersect(&(*CONSTANT_1),&(v272_2));
    drop(v272_2);
    let v272_10: Space = if has_head(&(v272_9)) { singleton(&[]) } else { Space::new() };
    drop(v272_9);
    let v272_12: Space = if (v272_10).is_empty() { Space::new() } else {
      let v283_6: Path = concat_path(&(*p0),&(v271_20_head));
      let mut v283_11 = Space::new();
      let mut v283_11_cursor = (v271_20_tail).read_zipper();
      for v283_11_byte in v283_11_cursor.child_mask().iter() {
        v283_11_cursor.descend_to_byte(v283_11_byte);
        {
        let v283_11_tail = v283_11_cursor.fork_read_zipper();
        let v283_11_head = Path::from_slice(&[v283_11_byte]);
        let v284_2: Space = singleton(&(v283_11_head));
        let v284_3: Space = intersect(&(*CONSTANT_1),&(v284_2));
        let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
        drop(v284_3);
        let v284_5: Space = subtract(&(*CONSTANT_0),&(v284_4));
        drop(v284_4);
        let v284_8: Space = if (v284_5).is_empty() { Space::new() } else {
          let v285_6: Path = concat_path(&(v283_6),&(v283_11_head));
          let mut v285_7 = Space::new();
          let mut v285_7_cursor = (v283_11_tail).read_zipper();
          for v285_7_byte in v285_7_cursor.child_mask().iter() {
            v285_7_cursor.descend_to_byte(v285_7_byte);
            {
            let v285_7_tail = v285_7_cursor.fork_read_zipper();
            let v285_7_head = Path::from_slice(&[v285_7_byte]);
            let v286_2: Space = singleton(&(v285_7_head));
            let v286_3: Space = intersect(&(*CONSTANT_1),&(v286_2));
            let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
            drop(v286_3);
            let v286_5: Space = subtract(&(*CONSTANT_0),&(v286_4));
            drop(v286_4);
            let v286_8: Space = if (v286_5).is_empty() { Space::new() } else {
              let v287_6: Path = concat_path(&(v285_6),&(v285_7_head));
              let v287_7: Space = routine_28(c, &(v287_6), &(v285_7_tail).make_space());
              compose(&(v286_5),&(v287_7))
            };
            drop(v286_5);
            let v286_9: Space = intersect(&(*CONSTANT_1),&(v286_2));
            drop(v286_2);
            let v286_10: Space = if has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
            drop(v286_9);
            let v286_12: Space = if (v286_10).is_empty() { Space::new() } else {
              let v288_6: Path = concat_path(&(v285_6),&(v285_7_head));
              let v288_11: Space = routine_29(c, &(v288_6), &(v285_7_tail).make_space());
              drop(v288_6);
              compose(&(v286_10),&(v288_11))
            };
            drop(v286_10);
            let v286_13: Space = unite(&(v286_8),&(v286_12));
            v285_7.join_into((v286_13).clone());
            }
            v285_7_cursor.ascend(1);
          }
          drop(v285_7_cursor);
          drop(v285_6);
          compose(&(v284_5),&(v285_7))
        };
        drop(v284_5);
        let v284_9: Space = intersect(&(*CONSTANT_1),&(v284_2));
        drop(v284_2);
        let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
        drop(v284_9);
        let v284_11: Space = compose(&(v284_10),&(v283_11_tail));
        drop(v284_10);
        let v284_12: Space = unite(&(v284_8),&(v284_11));
        drop(v284_11);
        v283_11.join_into((v284_12).clone());
        }
        v283_11_cursor.ascend(1);
      }
      drop(v283_11_cursor);
      drop(v283_6);
      compose(&(v272_10),&(v283_11))
    };
    drop(v272_10);
    let v272_13: Space = unite(&(v272_8),&(v272_12));
    v271_20.join_into((v272_13).clone());
    }
    v271_20_cursor.ascend(1);
  }
  drop(v271_20_cursor);
  (v271_20).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v289_14 = Space::new();
  let mut v289_14_cursor = (*s0).read_zipper();
  for v289_14_byte in v289_14_cursor.child_mask().iter() {
    v289_14_cursor.descend_to_byte(v289_14_byte);
    {
    let v289_14_tail = v289_14_cursor.fork_read_zipper();
    let v289_14_head = Path::from_slice(&[v289_14_byte]);
    let v290_2: Space = singleton(&(v289_14_head));
    let v290_3: Space = intersect(&(*CONSTANT_1),&(v290_2));
    let v290_4: Space = if has_head(&(v290_3)) { singleton(&[]) } else { Space::new() };
    drop(v290_3);
    let v290_5: Space = subtract(&(*CONSTANT_0),&(v290_4));
    drop(v290_4);
    let v290_8: Space = if (v290_5).is_empty() { Space::new() } else {
      let v291_6: Path = concat_path(&(*p0),&(v289_14_head));
      let mut v291_7 = Space::new();
      let mut v291_7_cursor = (v289_14_tail).read_zipper();
      for v291_7_byte in v291_7_cursor.child_mask().iter() {
        v291_7_cursor.descend_to_byte(v291_7_byte);
        {
        let v291_7_tail = v291_7_cursor.fork_read_zipper();
        let v291_7_head = Path::from_slice(&[v291_7_byte]);
        let v292_2: Space = singleton(&(v291_7_head));
        let v292_3: Space = intersect(&(*CONSTANT_1),&(v292_2));
        let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
        drop(v292_3);
        let v292_5: Space = subtract(&(*CONSTANT_0),&(v292_4));
        drop(v292_4);
        let v292_8: Space = if (v292_5).is_empty() { Space::new() } else {
          let v293_6: Path = concat_path(&(v291_6),&(v291_7_head));
          let mut v293_7 = Space::new();
          let mut v293_7_cursor = (v291_7_tail).read_zipper();
          for v293_7_byte in v293_7_cursor.child_mask().iter() {
            v293_7_cursor.descend_to_byte(v293_7_byte);
            {
            let v293_7_tail = v293_7_cursor.fork_read_zipper();
            let v293_7_head = Path::from_slice(&[v293_7_byte]);
            let v294_2: Space = singleton(&(v293_7_head));
            let v294_3: Space = intersect(&(*CONSTANT_1),&(v294_2));
            let v294_4: Space = if has_head(&(v294_3)) { singleton(&[]) } else { Space::new() };
            drop(v294_3);
            let v294_5: Space = subtract(&(*CONSTANT_0),&(v294_4));
            drop(v294_4);
            let v294_8: Space = if (v294_5).is_empty() { Space::new() } else {
              let v295_6: Path = concat_path(&(v293_6),&(v293_7_head));
              let v295_7: Space = routine_28(c, &(v295_6), &(v293_7_tail).make_space());
              compose(&(v294_5),&(v295_7))
            };
            drop(v294_5);
            let v294_9: Space = intersect(&(*CONSTANT_1),&(v294_2));
            drop(v294_2);
            let v294_10: Space = if has_head(&(v294_9)) { singleton(&[]) } else { Space::new() };
            drop(v294_9);
            let v294_12: Space = if (v294_10).is_empty() { Space::new() } else {
              let v296_6: Path = concat_path(&(v293_6),&(v293_7_head));
              let v296_11: Space = routine_29(c, &(v296_6), &(v293_7_tail).make_space());
              drop(v296_6);
              compose(&(v294_10),&(v296_11))
            };
            drop(v294_10);
            let v294_13: Space = unite(&(v294_8),&(v294_12));
            v293_7.join_into((v294_13).clone());
            }
            v293_7_cursor.ascend(1);
          }
          drop(v293_7_cursor);
          compose(&(v292_5),&(v293_7))
        };
        drop(v292_5);
        let v292_9: Space = intersect(&(*CONSTANT_1),&(v292_2));
        drop(v292_2);
        let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
        drop(v292_9);
        let v292_12: Space = if (v292_10).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v291_6),&(v291_7_head));
          let mut v297_11 = Space::new();
          let mut v297_11_cursor = (v291_7_tail).read_zipper();
          for v297_11_byte in v297_11_cursor.child_mask().iter() {
            v297_11_cursor.descend_to_byte(v297_11_byte);
            {
            let v297_11_tail = v297_11_cursor.fork_read_zipper();
            let v297_11_head = Path::from_slice(&[v297_11_byte]);
            let v298_2: Space = singleton(&(v297_11_head));
            let v298_3: Space = intersect(&(*CONSTANT_1),&(v298_2));
            let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = subtract(&(*CONSTANT_0),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (v298_5).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&(v297_11_head));
              let v299_7: Space = routine_28(c, &(v299_6), &(v297_11_tail).make_space());
              compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = intersect(&(*CONSTANT_1),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (v298_10).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&(v297_11_head));
              let v300_11: Space = routine_12(c, &(v300_6), &(v297_11_tail).make_space());
              drop(v300_6);
              compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = unite(&(v298_8),&(v298_12));
            v297_11.join_into((v298_13).clone());
            }
            v297_11_cursor.ascend(1);
          }
          drop(v297_11_cursor);
          drop(v297_6);
          compose(&(v292_10),&(v297_11))
        };
        drop(v292_10);
        let v292_13: Space = unite(&(v292_8),&(v292_12));
        v291_7.join_into((v292_13).clone());
        }
        v291_7_cursor.ascend(1);
      }
      drop(v291_7_cursor);
      drop(v291_6);
      compose(&(v290_5),&(v291_7))
    };
    drop(v290_5);
    let v290_9: Space = intersect(&(*CONSTANT_1),&(v290_2));
    drop(v290_2);
    let v290_10: Space = if has_head(&(v290_9)) { singleton(&[]) } else { Space::new() };
    drop(v290_9);
    let v290_11: Space = compose(&(v290_10),&(v289_14_tail));
    drop(v290_10);
    let v290_12: Space = unite(&(v290_8),&(v290_11));
    drop(v290_11);
    v289_14.join_into((v290_12).clone());
    }
    v289_14_cursor.ascend(1);
  }
  drop(v289_14_cursor);
  (v289_14).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v301_20 = Space::new();
  let mut v301_20_cursor = (*s0).read_zipper();
  for v301_20_byte in v301_20_cursor.child_mask().iter() {
    v301_20_cursor.descend_to_byte(v301_20_byte);
    {
    let v301_20_tail = v301_20_cursor.fork_read_zipper();
    let v301_20_head = Path::from_slice(&[v301_20_byte]);
    let v302_2: Space = singleton(&(v301_20_head));
    let v302_3: Space = intersect(&(*CONSTANT_1),&(v302_2));
    let v302_4: Space = if has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
    drop(v302_3);
    let v302_5: Space = subtract(&(*CONSTANT_0),&(v302_4));
    drop(v302_4);
    let v302_8: Space = if (v302_5).is_empty() { Space::new() } else {
      let v303_6: Path = concat_path(&(*p0),&(v301_20_head));
      let mut v303_7 = Space::new();
      let mut v303_7_cursor = (v301_20_tail).read_zipper();
      for v303_7_byte in v303_7_cursor.child_mask().iter() {
        v303_7_cursor.descend_to_byte(v303_7_byte);
        {
        let v303_7_tail = v303_7_cursor.fork_read_zipper();
        let v303_7_head = Path::from_slice(&[v303_7_byte]);
        let v304_2: Space = singleton(&(v303_7_head));
        let v304_3: Space = intersect(&(*CONSTANT_1),&(v304_2));
        let v304_4: Space = if has_head(&(v304_3)) { singleton(&[]) } else { Space::new() };
        drop(v304_3);
        let v304_5: Space = subtract(&(*CONSTANT_0),&(v304_4));
        drop(v304_4);
        let v304_8: Space = if (v304_5).is_empty() { Space::new() } else {
          let v305_6: Path = concat_path(&(v303_6),&(v303_7_head));
          let mut v305_7 = Space::new();
          let mut v305_7_cursor = (v303_7_tail).read_zipper();
          for v305_7_byte in v305_7_cursor.child_mask().iter() {
            v305_7_cursor.descend_to_byte(v305_7_byte);
            {
            let v305_7_tail = v305_7_cursor.fork_read_zipper();
            let v305_7_head = Path::from_slice(&[v305_7_byte]);
            let v306_2: Space = singleton(&(v305_7_head));
            let v306_3: Space = intersect(&(*CONSTANT_1),&(v306_2));
            let v306_4: Space = if has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
            drop(v306_3);
            let v306_5: Space = subtract(&(*CONSTANT_0),&(v306_4));
            drop(v306_4);
            let v306_8: Space = if (v306_5).is_empty() { Space::new() } else {
              let v307_6: Path = concat_path(&(v305_6),&(v305_7_head));
              let v307_7: Space = routine_30(c, &(v307_6), &(v305_7_tail).make_space());
              compose(&(v306_5),&(v307_7))
            };
            drop(v306_5);
            let v306_9: Space = intersect(&(*CONSTANT_1),&(v306_2));
            drop(v306_2);
            let v306_10: Space = if has_head(&(v306_9)) { singleton(&[]) } else { Space::new() };
            drop(v306_9);
            let v306_12: Space = if (v306_10).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v305_6),&(v305_7_head));
              let v308_11: Space = routine_31(c, &(v308_6), &(v305_7_tail).make_space());
              drop(v308_6);
              compose(&(v306_10),&(v308_11))
            };
            drop(v306_10);
            let v306_13: Space = unite(&(v306_8),&(v306_12));
            v305_7.join_into((v306_13).clone());
            }
            v305_7_cursor.ascend(1);
          }
          drop(v305_7_cursor);
          compose(&(v304_5),&(v305_7))
        };
        drop(v304_5);
        let v304_9: Space = intersect(&(*CONSTANT_1),&(v304_2));
        drop(v304_2);
        let v304_10: Space = if has_head(&(v304_9)) { singleton(&[]) } else { Space::new() };
        drop(v304_9);
        let v304_12: Space = if (v304_10).is_empty() { Space::new() } else {
          let v309_6: Path = concat_path(&(v303_6),&(v303_7_head));
          let mut v309_11 = Space::new();
          let mut v309_11_cursor = (v303_7_tail).read_zipper();
          for v309_11_byte in v309_11_cursor.child_mask().iter() {
            v309_11_cursor.descend_to_byte(v309_11_byte);
            {
            let v309_11_tail = v309_11_cursor.fork_read_zipper();
            let v309_11_head = Path::from_slice(&[v309_11_byte]);
            let v310_2: Space = singleton(&(v309_11_head));
            let v310_3: Space = intersect(&(*CONSTANT_1),&(v310_2));
            let v310_4: Space = if has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
            drop(v310_3);
            let v310_5: Space = subtract(&(*CONSTANT_0),&(v310_4));
            drop(v310_4);
            let v310_8: Space = if (v310_5).is_empty() { Space::new() } else {
              let v311_6: Path = concat_path(&(v309_6),&(v309_11_head));
              let v311_7: Space = routine_30(c, &(v311_6), &(v309_11_tail).make_space());
              compose(&(v310_5),&(v311_7))
            };
            drop(v310_5);
            let v310_9: Space = intersect(&(*CONSTANT_1),&(v310_2));
            drop(v310_2);
            let v310_10: Space = if has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
            drop(v310_9);
            let v310_12: Space = if (v310_10).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v309_6),&(v309_11_head));
              let v312_11: Space = routine_15(c, &(v312_6), &(v309_11_tail).make_space());
              drop(v312_6);
              compose(&(v310_10),&(v312_11))
            };
            drop(v310_10);
            let v310_13: Space = unite(&(v310_8),&(v310_12));
            v309_11.join_into((v310_13).clone());
            }
            v309_11_cursor.ascend(1);
          }
          drop(v309_11_cursor);
          drop(v309_6);
          compose(&(v304_10),&(v309_11))
        };
        drop(v304_10);
        let v304_13: Space = unite(&(v304_8),&(v304_12));
        v303_7.join_into((v304_13).clone());
        }
        v303_7_cursor.ascend(1);
      }
      drop(v303_7_cursor);
      compose(&(v302_5),&(v303_7))
    };
    drop(v302_5);
    let v302_9: Space = intersect(&(*CONSTANT_1),&(v302_2));
    drop(v302_2);
    let v302_10: Space = if has_head(&(v302_9)) { singleton(&[]) } else { Space::new() };
    drop(v302_9);
    let v302_12: Space = if (v302_10).is_empty() { Space::new() } else {
      let v313_6: Path = concat_path(&(*p0),&(v301_20_head));
      let mut v313_11 = Space::new();
      let mut v313_11_cursor = (v301_20_tail).read_zipper();
      for v313_11_byte in v313_11_cursor.child_mask().iter() {
        v313_11_cursor.descend_to_byte(v313_11_byte);
        {
        let v313_11_tail = v313_11_cursor.fork_read_zipper();
        let v313_11_head = Path::from_slice(&[v313_11_byte]);
        let v314_2: Space = singleton(&(v313_11_head));
        let v314_3: Space = intersect(&(*CONSTANT_1),&(v314_2));
        let v314_4: Space = if has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
        drop(v314_3);
        let v314_5: Space = subtract(&(*CONSTANT_0),&(v314_4));
        drop(v314_4);
        let v314_8: Space = if (v314_5).is_empty() { Space::new() } else {
          let v315_6: Path = concat_path(&(v313_6),&(v313_11_head));
          let mut v315_7 = Space::new();
          let mut v315_7_cursor = (v313_11_tail).read_zipper();
          for v315_7_byte in v315_7_cursor.child_mask().iter() {
            v315_7_cursor.descend_to_byte(v315_7_byte);
            {
            let v315_7_tail = v315_7_cursor.fork_read_zipper();
            let v315_7_head = Path::from_slice(&[v315_7_byte]);
            let v316_2: Space = singleton(&(v315_7_head));
            let v316_3: Space = intersect(&(*CONSTANT_1),&(v316_2));
            let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
            drop(v316_3);
            let v316_5: Space = subtract(&(*CONSTANT_0),&(v316_4));
            drop(v316_4);
            let v316_8: Space = if (v316_5).is_empty() { Space::new() } else {
              let v317_6: Path = concat_path(&(v315_6),&(v315_7_head));
              let v317_7: Space = routine_30(c, &(v317_6), &(v315_7_tail).make_space());
              compose(&(v316_5),&(v317_7))
            };
            drop(v316_5);
            let v316_9: Space = intersect(&(*CONSTANT_1),&(v316_2));
            drop(v316_2);
            let v316_10: Space = if has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
            drop(v316_9);
            let v316_12: Space = if (v316_10).is_empty() { Space::new() } else {
              let v318_6: Path = concat_path(&(v315_6),&(v315_7_head));
              let v318_11: Space = routine_31(c, &(v318_6), &(v315_7_tail).make_space());
              drop(v318_6);
              compose(&(v316_10),&(v318_11))
            };
            drop(v316_10);
            let v316_13: Space = unite(&(v316_8),&(v316_12));
            v315_7.join_into((v316_13).clone());
            }
            v315_7_cursor.ascend(1);
          }
          drop(v315_7_cursor);
          drop(v315_6);
          compose(&(v314_5),&(v315_7))
        };
        drop(v314_5);
        let v314_9: Space = intersect(&(*CONSTANT_1),&(v314_2));
        drop(v314_2);
        let v314_10: Space = if has_head(&(v314_9)) { singleton(&[]) } else { Space::new() };
        drop(v314_9);
        let v314_11: Space = compose(&(v314_10),&(v313_11_tail));
        drop(v314_10);
        let v314_12: Space = unite(&(v314_8),&(v314_11));
        drop(v314_11);
        v313_11.join_into((v314_12).clone());
        }
        v313_11_cursor.ascend(1);
      }
      drop(v313_11_cursor);
      drop(v313_6);
      compose(&(v302_10),&(v313_11))
    };
    drop(v302_10);
    let v302_13: Space = unite(&(v302_8),&(v302_12));
    v301_20.join_into((v302_13).clone());
    }
    v301_20_cursor.ascend(1);
  }
  drop(v301_20_cursor);
  (v301_20).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v319_14 = Space::new();
  let mut v319_14_cursor = (*s0).read_zipper();
  for v319_14_byte in v319_14_cursor.child_mask().iter() {
    v319_14_cursor.descend_to_byte(v319_14_byte);
    {
    let v319_14_tail = v319_14_cursor.fork_read_zipper();
    let v319_14_head = Path::from_slice(&[v319_14_byte]);
    let v320_2: Space = singleton(&(v319_14_head));
    let v320_3: Space = intersect(&(*CONSTANT_1),&(v320_2));
    let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
    drop(v320_3);
    let v320_5: Space = subtract(&(*CONSTANT_0),&(v320_4));
    drop(v320_4);
    let v320_8: Space = if (v320_5).is_empty() { Space::new() } else {
      let v321_6: Path = concat_path(&(*p0),&(v319_14_head));
      let mut v321_7 = Space::new();
      let mut v321_7_cursor = (v319_14_tail).read_zipper();
      for v321_7_byte in v321_7_cursor.child_mask().iter() {
        v321_7_cursor.descend_to_byte(v321_7_byte);
        {
        let v321_7_tail = v321_7_cursor.fork_read_zipper();
        let v321_7_head = Path::from_slice(&[v321_7_byte]);
        let v322_2: Space = singleton(&(v321_7_head));
        let v322_3: Space = intersect(&(*CONSTANT_1),&(v322_2));
        let v322_4: Space = if has_head(&(v322_3)) { singleton(&[]) } else { Space::new() };
        drop(v322_3);
        let v322_5: Space = subtract(&(*CONSTANT_0),&(v322_4));
        drop(v322_4);
        let v322_8: Space = if (v322_5).is_empty() { Space::new() } else {
          let v323_6: Path = concat_path(&(v321_6),&(v321_7_head));
          let mut v323_7 = Space::new();
          let mut v323_7_cursor = (v321_7_tail).read_zipper();
          for v323_7_byte in v323_7_cursor.child_mask().iter() {
            v323_7_cursor.descend_to_byte(v323_7_byte);
            {
            let v323_7_tail = v323_7_cursor.fork_read_zipper();
            let v323_7_head = Path::from_slice(&[v323_7_byte]);
            let v324_2: Space = singleton(&(v323_7_head));
            let v324_3: Space = intersect(&(*CONSTANT_1),&(v324_2));
            let v324_4: Space = if has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
            drop(v324_3);
            let v324_5: Space = subtract(&(*CONSTANT_0),&(v324_4));
            drop(v324_4);
            let v324_8: Space = if (v324_5).is_empty() { Space::new() } else {
              let v325_6: Path = concat_path(&(v323_6),&(v323_7_head));
              let v325_7: Space = routine_30(c, &(v325_6), &(v323_7_tail).make_space());
              compose(&(v324_5),&(v325_7))
            };
            drop(v324_5);
            let v324_9: Space = intersect(&(*CONSTANT_1),&(v324_2));
            drop(v324_2);
            let v324_10: Space = if has_head(&(v324_9)) { singleton(&[]) } else { Space::new() };
            drop(v324_9);
            let v324_12: Space = if (v324_10).is_empty() { Space::new() } else {
              let v326_6: Path = concat_path(&(v323_6),&(v323_7_head));
              let v326_11: Space = routine_31(c, &(v326_6), &(v323_7_tail).make_space());
              drop(v326_6);
              compose(&(v324_10),&(v326_11))
            };
            drop(v324_10);
            let v324_13: Space = unite(&(v324_8),&(v324_12));
            v323_7.join_into((v324_13).clone());
            }
            v323_7_cursor.ascend(1);
          }
          drop(v323_7_cursor);
          compose(&(v322_5),&(v323_7))
        };
        drop(v322_5);
        let v322_9: Space = intersect(&(*CONSTANT_1),&(v322_2));
        drop(v322_2);
        let v322_10: Space = if has_head(&(v322_9)) { singleton(&[]) } else { Space::new() };
        drop(v322_9);
        let v322_12: Space = if (v322_10).is_empty() { Space::new() } else {
          let v327_6: Path = concat_path(&(v321_6),&(v321_7_head));
          let mut v327_11 = Space::new();
          let mut v327_11_cursor = (v321_7_tail).read_zipper();
          for v327_11_byte in v327_11_cursor.child_mask().iter() {
            v327_11_cursor.descend_to_byte(v327_11_byte);
            {
            let v327_11_tail = v327_11_cursor.fork_read_zipper();
            let v327_11_head = Path::from_slice(&[v327_11_byte]);
            let v328_2: Space = singleton(&(v327_11_head));
            let v328_3: Space = intersect(&(*CONSTANT_1),&(v328_2));
            let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
            drop(v328_3);
            let v328_5: Space = subtract(&(*CONSTANT_0),&(v328_4));
            drop(v328_4);
            let v328_8: Space = if (v328_5).is_empty() { Space::new() } else {
              let v329_6: Path = concat_path(&(v327_6),&(v327_11_head));
              let v329_7: Space = routine_30(c, &(v329_6), &(v327_11_tail).make_space());
              compose(&(v328_5),&(v329_7))
            };
            drop(v328_5);
            let v328_9: Space = intersect(&(*CONSTANT_1),&(v328_2));
            drop(v328_2);
            let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
            drop(v328_9);
            let v328_12: Space = if (v328_10).is_empty() { Space::new() } else {
              let v330_6: Path = concat_path(&(v327_6),&(v327_11_head));
              let v330_11: Space = routine_15(c, &(v330_6), &(v327_11_tail).make_space());
              drop(v330_6);
              compose(&(v328_10),&(v330_11))
            };
            drop(v328_10);
            let v328_13: Space = unite(&(v328_8),&(v328_12));
            v327_11.join_into((v328_13).clone());
            }
            v327_11_cursor.ascend(1);
          }
          drop(v327_11_cursor);
          drop(v327_6);
          compose(&(v322_10),&(v327_11))
        };
        drop(v322_10);
        let v322_13: Space = unite(&(v322_8),&(v322_12));
        v321_7.join_into((v322_13).clone());
        }
        v321_7_cursor.ascend(1);
      }
      drop(v321_7_cursor);
      drop(v321_6);
      compose(&(v320_5),&(v321_7))
    };
    drop(v320_5);
    let v320_9: Space = intersect(&(*CONSTANT_1),&(v320_2));
    drop(v320_2);
    let v320_10: Space = if has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
    drop(v320_9);
    let v320_11: Space = compose(&(v320_10),&(v319_14_tail));
    drop(v320_10);
    let v320_12: Space = unite(&(v320_8),&(v320_11));
    drop(v320_11);
    v319_14.join_into((v320_12).clone());
    }
    v319_14_cursor.ascend(1);
  }
  drop(v319_14_cursor);
  (v319_14).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v331_20 = Space::new();
  let mut v331_20_cursor = (*s0).read_zipper();
  for v331_20_byte in v331_20_cursor.child_mask().iter() {
    v331_20_cursor.descend_to_byte(v331_20_byte);
    {
    let v331_20_tail = v331_20_cursor.fork_read_zipper();
    let v331_20_head = Path::from_slice(&[v331_20_byte]);
    let v332_2: Space = singleton(&(v331_20_head));
    let v332_3: Space = intersect(&(*CONSTANT_1),&(v332_2));
    let v332_4: Space = if has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
    drop(v332_3);
    let v332_5: Space = subtract(&(*CONSTANT_0),&(v332_4));
    drop(v332_4);
    let v332_8: Space = if (v332_5).is_empty() { Space::new() } else {
      let v333_6: Path = concat_path(&(*p0),&(v331_20_head));
      let mut v333_7 = Space::new();
      let mut v333_7_cursor = (v331_20_tail).read_zipper();
      for v333_7_byte in v333_7_cursor.child_mask().iter() {
        v333_7_cursor.descend_to_byte(v333_7_byte);
        {
        let v333_7_tail = v333_7_cursor.fork_read_zipper();
        let v333_7_head = Path::from_slice(&[v333_7_byte]);
        let v334_2: Space = singleton(&(v333_7_head));
        let v334_3: Space = intersect(&(*CONSTANT_1),&(v334_2));
        let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
        drop(v334_3);
        let v334_5: Space = subtract(&(*CONSTANT_0),&(v334_4));
        drop(v334_4);
        let v334_8: Space = if (v334_5).is_empty() { Space::new() } else {
          let v335_6: Path = concat_path(&(v333_6),&(v333_7_head));
          let mut v335_7 = Space::new();
          let mut v335_7_cursor = (v333_7_tail).read_zipper();
          for v335_7_byte in v335_7_cursor.child_mask().iter() {
            v335_7_cursor.descend_to_byte(v335_7_byte);
            {
            let v335_7_tail = v335_7_cursor.fork_read_zipper();
            let v335_7_head = Path::from_slice(&[v335_7_byte]);
            let v336_2: Space = singleton(&(v335_7_head));
            let v336_3: Space = intersect(&(*CONSTANT_1),&(v336_2));
            let v336_4: Space = if has_head(&(v336_3)) { singleton(&[]) } else { Space::new() };
            drop(v336_3);
            let v336_5: Space = subtract(&(*CONSTANT_0),&(v336_4));
            drop(v336_4);
            let v336_8: Space = if (v336_5).is_empty() { Space::new() } else {
              let v337_6: Path = concat_path(&(v335_6),&(v335_7_head));
              let v337_7: Space = routine_32(c, &(v337_6), &(v335_7_tail).make_space());
              compose(&(v336_5),&(v337_7))
            };
            drop(v336_5);
            let v336_9: Space = intersect(&(*CONSTANT_1),&(v336_2));
            drop(v336_2);
            let v336_10: Space = if has_head(&(v336_9)) { singleton(&[]) } else { Space::new() };
            drop(v336_9);
            let v336_12: Space = if (v336_10).is_empty() { Space::new() } else {
              let v338_6: Path = concat_path(&(v335_6),&(v335_7_head));
              let v338_11: Space = routine_33(c, &(v338_6), &(v335_7_tail).make_space());
              drop(v338_6);
              compose(&(v336_10),&(v338_11))
            };
            drop(v336_10);
            let v336_13: Space = unite(&(v336_8),&(v336_12));
            v335_7.join_into((v336_13).clone());
            }
            v335_7_cursor.ascend(1);
          }
          drop(v335_7_cursor);
          compose(&(v334_5),&(v335_7))
        };
        drop(v334_5);
        let v334_9: Space = intersect(&(*CONSTANT_1),&(v334_2));
        drop(v334_2);
        let v334_10: Space = if has_head(&(v334_9)) { singleton(&[]) } else { Space::new() };
        drop(v334_9);
        let v334_12: Space = if (v334_10).is_empty() { Space::new() } else {
          let v339_6: Path = concat_path(&(v333_6),&(v333_7_head));
          let mut v339_11 = Space::new();
          let mut v339_11_cursor = (v333_7_tail).read_zipper();
          for v339_11_byte in v339_11_cursor.child_mask().iter() {
            v339_11_cursor.descend_to_byte(v339_11_byte);
            {
            let v339_11_tail = v339_11_cursor.fork_read_zipper();
            let v339_11_head = Path::from_slice(&[v339_11_byte]);
            let v340_2: Space = singleton(&(v339_11_head));
            let v340_3: Space = intersect(&(*CONSTANT_1),&(v340_2));
            let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
            drop(v340_3);
            let v340_5: Space = subtract(&(*CONSTANT_0),&(v340_4));
            drop(v340_4);
            let v340_8: Space = if (v340_5).is_empty() { Space::new() } else {
              let v341_6: Path = concat_path(&(v339_6),&(v339_11_head));
              let v341_7: Space = routine_32(c, &(v341_6), &(v339_11_tail).make_space());
              compose(&(v340_5),&(v341_7))
            };
            drop(v340_5);
            let v340_9: Space = intersect(&(*CONSTANT_1),&(v340_2));
            drop(v340_2);
            let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
            drop(v340_9);
            let v340_12: Space = if (v340_10).is_empty() { Space::new() } else {
              let v342_6: Path = concat_path(&(v339_6),&(v339_11_head));
              let v342_11: Space = routine_12(c, &(v342_6), &(v339_11_tail).make_space());
              drop(v342_6);
              compose(&(v340_10),&(v342_11))
            };
            drop(v340_10);
            let v340_13: Space = unite(&(v340_8),&(v340_12));
            v339_11.join_into((v340_13).clone());
            }
            v339_11_cursor.ascend(1);
          }
          drop(v339_11_cursor);
          drop(v339_6);
          compose(&(v334_10),&(v339_11))
        };
        drop(v334_10);
        let v334_13: Space = unite(&(v334_8),&(v334_12));
        v333_7.join_into((v334_13).clone());
        }
        v333_7_cursor.ascend(1);
      }
      drop(v333_7_cursor);
      compose(&(v332_5),&(v333_7))
    };
    drop(v332_5);
    let v332_9: Space = intersect(&(*CONSTANT_1),&(v332_2));
    drop(v332_2);
    let v332_10: Space = if has_head(&(v332_9)) { singleton(&[]) } else { Space::new() };
    drop(v332_9);
    let v332_12: Space = if (v332_10).is_empty() { Space::new() } else {
      let v343_6: Path = concat_path(&(*p0),&(v331_20_head));
      let mut v343_11 = Space::new();
      let mut v343_11_cursor = (v331_20_tail).read_zipper();
      for v343_11_byte in v343_11_cursor.child_mask().iter() {
        v343_11_cursor.descend_to_byte(v343_11_byte);
        {
        let v343_11_tail = v343_11_cursor.fork_read_zipper();
        let v343_11_head = Path::from_slice(&[v343_11_byte]);
        let v344_2: Space = singleton(&(v343_11_head));
        let v344_3: Space = intersect(&(*CONSTANT_1),&(v344_2));
        let v344_4: Space = if has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
        drop(v344_3);
        let v344_5: Space = subtract(&(*CONSTANT_0),&(v344_4));
        drop(v344_4);
        let v344_8: Space = if (v344_5).is_empty() { Space::new() } else {
          let v345_6: Path = concat_path(&(v343_6),&(v343_11_head));
          let mut v345_7 = Space::new();
          let mut v345_7_cursor = (v343_11_tail).read_zipper();
          for v345_7_byte in v345_7_cursor.child_mask().iter() {
            v345_7_cursor.descend_to_byte(v345_7_byte);
            {
            let v345_7_tail = v345_7_cursor.fork_read_zipper();
            let v345_7_head = Path::from_slice(&[v345_7_byte]);
            let v346_2: Space = singleton(&(v345_7_head));
            let v346_3: Space = intersect(&(*CONSTANT_1),&(v346_2));
            let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
            drop(v346_3);
            let v346_5: Space = subtract(&(*CONSTANT_0),&(v346_4));
            drop(v346_4);
            let v346_8: Space = if (v346_5).is_empty() { Space::new() } else {
              let v347_6: Path = concat_path(&(v345_6),&(v345_7_head));
              let v347_7: Space = routine_32(c, &(v347_6), &(v345_7_tail).make_space());
              compose(&(v346_5),&(v347_7))
            };
            drop(v346_5);
            let v346_9: Space = intersect(&(*CONSTANT_1),&(v346_2));
            drop(v346_2);
            let v346_10: Space = if has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
            drop(v346_9);
            let v346_12: Space = if (v346_10).is_empty() { Space::new() } else {
              let v348_6: Path = concat_path(&(v345_6),&(v345_7_head));
              let v348_11: Space = routine_33(c, &(v348_6), &(v345_7_tail).make_space());
              drop(v348_6);
              compose(&(v346_10),&(v348_11))
            };
            drop(v346_10);
            let v346_13: Space = unite(&(v346_8),&(v346_12));
            v345_7.join_into((v346_13).clone());
            }
            v345_7_cursor.ascend(1);
          }
          drop(v345_7_cursor);
          drop(v345_6);
          compose(&(v344_5),&(v345_7))
        };
        drop(v344_5);
        let v344_9: Space = intersect(&(*CONSTANT_1),&(v344_2));
        drop(v344_2);
        let v344_10: Space = if has_head(&(v344_9)) { singleton(&[]) } else { Space::new() };
        drop(v344_9);
        let v344_11: Space = compose(&(v344_10),&(v343_11_tail));
        drop(v344_10);
        let v344_12: Space = unite(&(v344_8),&(v344_11));
        drop(v344_11);
        v343_11.join_into((v344_12).clone());
        }
        v343_11_cursor.ascend(1);
      }
      drop(v343_11_cursor);
      drop(v343_6);
      compose(&(v332_10),&(v343_11))
    };
    drop(v332_10);
    let v332_13: Space = unite(&(v332_8),&(v332_12));
    v331_20.join_into((v332_13).clone());
    }
    v331_20_cursor.ascend(1);
  }
  drop(v331_20_cursor);
  (v331_20).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v349_14 = Space::new();
  let mut v349_14_cursor = (*s0).read_zipper();
  for v349_14_byte in v349_14_cursor.child_mask().iter() {
    v349_14_cursor.descend_to_byte(v349_14_byte);
    {
    let v349_14_tail = v349_14_cursor.fork_read_zipper();
    let v349_14_head = Path::from_slice(&[v349_14_byte]);
    let v350_2: Space = singleton(&(v349_14_head));
    let v350_3: Space = intersect(&(*CONSTANT_1),&(v350_2));
    let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
    drop(v350_3);
    let v350_5: Space = subtract(&(*CONSTANT_0),&(v350_4));
    drop(v350_4);
    let v350_8: Space = if (v350_5).is_empty() { Space::new() } else {
      let v351_6: Path = concat_path(&(*p0),&(v349_14_head));
      let mut v351_7 = Space::new();
      let mut v351_7_cursor = (v349_14_tail).read_zipper();
      for v351_7_byte in v351_7_cursor.child_mask().iter() {
        v351_7_cursor.descend_to_byte(v351_7_byte);
        {
        let v351_7_tail = v351_7_cursor.fork_read_zipper();
        let v351_7_head = Path::from_slice(&[v351_7_byte]);
        let v352_2: Space = singleton(&(v351_7_head));
        let v352_3: Space = intersect(&(*CONSTANT_1),&(v352_2));
        let v352_4: Space = if has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
        drop(v352_3);
        let v352_5: Space = subtract(&(*CONSTANT_0),&(v352_4));
        drop(v352_4);
        let v352_8: Space = if (v352_5).is_empty() { Space::new() } else {
          let v353_6: Path = concat_path(&(v351_6),&(v351_7_head));
          let mut v353_7 = Space::new();
          let mut v353_7_cursor = (v351_7_tail).read_zipper();
          for v353_7_byte in v353_7_cursor.child_mask().iter() {
            v353_7_cursor.descend_to_byte(v353_7_byte);
            {
            let v353_7_tail = v353_7_cursor.fork_read_zipper();
            let v353_7_head = Path::from_slice(&[v353_7_byte]);
            let v354_2: Space = singleton(&(v353_7_head));
            let v354_3: Space = intersect(&(*CONSTANT_1),&(v354_2));
            let v354_4: Space = if has_head(&(v354_3)) { singleton(&[]) } else { Space::new() };
            drop(v354_3);
            let v354_5: Space = subtract(&(*CONSTANT_0),&(v354_4));
            drop(v354_4);
            let v354_8: Space = if (v354_5).is_empty() { Space::new() } else {
              let v355_6: Path = concat_path(&(v353_6),&(v353_7_head));
              let v355_7: Space = routine_32(c, &(v355_6), &(v353_7_tail).make_space());
              compose(&(v354_5),&(v355_7))
            };
            drop(v354_5);
            let v354_9: Space = intersect(&(*CONSTANT_1),&(v354_2));
            drop(v354_2);
            let v354_10: Space = if has_head(&(v354_9)) { singleton(&[]) } else { Space::new() };
            drop(v354_9);
            let v354_12: Space = if (v354_10).is_empty() { Space::new() } else {
              let v356_6: Path = concat_path(&(v353_6),&(v353_7_head));
              let v356_11: Space = routine_33(c, &(v356_6), &(v353_7_tail).make_space());
              drop(v356_6);
              compose(&(v354_10),&(v356_11))
            };
            drop(v354_10);
            let v354_13: Space = unite(&(v354_8),&(v354_12));
            v353_7.join_into((v354_13).clone());
            }
            v353_7_cursor.ascend(1);
          }
          drop(v353_7_cursor);
          compose(&(v352_5),&(v353_7))
        };
        drop(v352_5);
        let v352_9: Space = intersect(&(*CONSTANT_1),&(v352_2));
        drop(v352_2);
        let v352_10: Space = if has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
        drop(v352_9);
        let v352_12: Space = if (v352_10).is_empty() { Space::new() } else {
          let v357_6: Path = concat_path(&(v351_6),&(v351_7_head));
          let mut v357_11 = Space::new();
          let mut v357_11_cursor = (v351_7_tail).read_zipper();
          for v357_11_byte in v357_11_cursor.child_mask().iter() {
            v357_11_cursor.descend_to_byte(v357_11_byte);
            {
            let v357_11_tail = v357_11_cursor.fork_read_zipper();
            let v357_11_head = Path::from_slice(&[v357_11_byte]);
            let v358_2: Space = singleton(&(v357_11_head));
            let v358_3: Space = intersect(&(*CONSTANT_1),&(v358_2));
            let v358_4: Space = if has_head(&(v358_3)) { singleton(&[]) } else { Space::new() };
            drop(v358_3);
            let v358_5: Space = subtract(&(*CONSTANT_0),&(v358_4));
            drop(v358_4);
            let v358_8: Space = if (v358_5).is_empty() { Space::new() } else {
              let v359_6: Path = concat_path(&(v357_6),&(v357_11_head));
              let v359_7: Space = routine_32(c, &(v359_6), &(v357_11_tail).make_space());
              compose(&(v358_5),&(v359_7))
            };
            drop(v358_5);
            let v358_9: Space = intersect(&(*CONSTANT_1),&(v358_2));
            drop(v358_2);
            let v358_10: Space = if has_head(&(v358_9)) { singleton(&[]) } else { Space::new() };
            drop(v358_9);
            let v358_12: Space = if (v358_10).is_empty() { Space::new() } else {
              let v360_6: Path = concat_path(&(v357_6),&(v357_11_head));
              let v360_11: Space = routine_12(c, &(v360_6), &(v357_11_tail).make_space());
              drop(v360_6);
              compose(&(v358_10),&(v360_11))
            };
            drop(v358_10);
            let v358_13: Space = unite(&(v358_8),&(v358_12));
            v357_11.join_into((v358_13).clone());
            }
            v357_11_cursor.ascend(1);
          }
          drop(v357_11_cursor);
          drop(v357_6);
          compose(&(v352_10),&(v357_11))
        };
        drop(v352_10);
        let v352_13: Space = unite(&(v352_8),&(v352_12));
        v351_7.join_into((v352_13).clone());
        }
        v351_7_cursor.ascend(1);
      }
      drop(v351_7_cursor);
      drop(v351_6);
      compose(&(v350_5),&(v351_7))
    };
    drop(v350_5);
    let v350_9: Space = intersect(&(*CONSTANT_1),&(v350_2));
    drop(v350_2);
    let v350_10: Space = if has_head(&(v350_9)) { singleton(&[]) } else { Space::new() };
    drop(v350_9);
    let v350_11: Space = compose(&(v350_10),&(v349_14_tail));
    drop(v350_10);
    let v350_12: Space = unite(&(v350_8),&(v350_11));
    drop(v350_11);
    v349_14.join_into((v350_12).clone());
    }
    v349_14_cursor.ascend(1);
  }
  drop(v349_14_cursor);
  (v349_14).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v361_20 = Space::new();
  let mut v361_20_cursor = (*s0).read_zipper();
  for v361_20_byte in v361_20_cursor.child_mask().iter() {
    v361_20_cursor.descend_to_byte(v361_20_byte);
    {
    let v361_20_tail = v361_20_cursor.fork_read_zipper();
    let v361_20_head = Path::from_slice(&[v361_20_byte]);
    let v362_2: Space = singleton(&(v361_20_head));
    let v362_3: Space = intersect(&(*CONSTANT_1),&(v362_2));
    let v362_4: Space = if has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
    drop(v362_3);
    let v362_5: Space = subtract(&(*CONSTANT_0),&(v362_4));
    drop(v362_4);
    let v362_8: Space = if (v362_5).is_empty() { Space::new() } else {
      let v363_6: Path = concat_path(&(*p0),&(v361_20_head));
      let mut v363_7 = Space::new();
      let mut v363_7_cursor = (v361_20_tail).read_zipper();
      for v363_7_byte in v363_7_cursor.child_mask().iter() {
        v363_7_cursor.descend_to_byte(v363_7_byte);
        {
        let v363_7_tail = v363_7_cursor.fork_read_zipper();
        let v363_7_head = Path::from_slice(&[v363_7_byte]);
        let v364_2: Space = singleton(&(v363_7_head));
        let v364_3: Space = intersect(&(*CONSTANT_1),&(v364_2));
        let v364_4: Space = if has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
        drop(v364_3);
        let v364_5: Space = subtract(&(*CONSTANT_0),&(v364_4));
        drop(v364_4);
        let v364_8: Space = if (v364_5).is_empty() { Space::new() } else {
          let v365_6: Path = concat_path(&(v363_6),&(v363_7_head));
          let mut v365_7 = Space::new();
          let mut v365_7_cursor = (v363_7_tail).read_zipper();
          for v365_7_byte in v365_7_cursor.child_mask().iter() {
            v365_7_cursor.descend_to_byte(v365_7_byte);
            {
            let v365_7_tail = v365_7_cursor.fork_read_zipper();
            let v365_7_head = Path::from_slice(&[v365_7_byte]);
            let v366_2: Space = singleton(&(v365_7_head));
            let v366_3: Space = intersect(&(*CONSTANT_1),&(v366_2));
            let v366_4: Space = if has_head(&(v366_3)) { singleton(&[]) } else { Space::new() };
            drop(v366_3);
            let v366_5: Space = subtract(&(*CONSTANT_0),&(v366_4));
            drop(v366_4);
            let v366_8: Space = if (v366_5).is_empty() { Space::new() } else {
              let v367_6: Path = concat_path(&(v365_6),&(v365_7_head));
              let v367_7: Space = routine_34(c, &(v367_6), &(v365_7_tail).make_space());
              compose(&(v366_5),&(v367_7))
            };
            drop(v366_5);
            let v366_9: Space = intersect(&(*CONSTANT_1),&(v366_2));
            drop(v366_2);
            let v366_10: Space = if has_head(&(v366_9)) { singleton(&[]) } else { Space::new() };
            drop(v366_9);
            let v366_12: Space = if (v366_10).is_empty() { Space::new() } else {
              let v368_6: Path = concat_path(&(v365_6),&(v365_7_head));
              let v368_11: Space = routine_35(c, &(v368_6), &(v365_7_tail).make_space());
              drop(v368_6);
              compose(&(v366_10),&(v368_11))
            };
            drop(v366_10);
            let v366_13: Space = unite(&(v366_8),&(v366_12));
            v365_7.join_into((v366_13).clone());
            }
            v365_7_cursor.ascend(1);
          }
          drop(v365_7_cursor);
          compose(&(v364_5),&(v365_7))
        };
        drop(v364_5);
        let v364_9: Space = intersect(&(*CONSTANT_1),&(v364_2));
        drop(v364_2);
        let v364_10: Space = if has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
        drop(v364_9);
        let v364_12: Space = if (v364_10).is_empty() { Space::new() } else {
          let v369_6: Path = concat_path(&(v363_6),&(v363_7_head));
          let mut v369_11 = Space::new();
          let mut v369_11_cursor = (v363_7_tail).read_zipper();
          for v369_11_byte in v369_11_cursor.child_mask().iter() {
            v369_11_cursor.descend_to_byte(v369_11_byte);
            {
            let v369_11_tail = v369_11_cursor.fork_read_zipper();
            let v369_11_head = Path::from_slice(&[v369_11_byte]);
            let v370_2: Space = singleton(&(v369_11_head));
            let v370_3: Space = intersect(&(*CONSTANT_1),&(v370_2));
            let v370_4: Space = if has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
            drop(v370_3);
            let v370_5: Space = subtract(&(*CONSTANT_0),&(v370_4));
            drop(v370_4);
            let v370_8: Space = if (v370_5).is_empty() { Space::new() } else {
              let v371_6: Path = concat_path(&(v369_6),&(v369_11_head));
              let v371_7: Space = routine_34(c, &(v371_6), &(v369_11_tail).make_space());
              compose(&(v370_5),&(v371_7))
            };
            drop(v370_5);
            let v370_9: Space = intersect(&(*CONSTANT_1),&(v370_2));
            drop(v370_2);
            let v370_10: Space = if has_head(&(v370_9)) { singleton(&[]) } else { Space::new() };
            drop(v370_9);
            let v370_12: Space = if (v370_10).is_empty() { Space::new() } else {
              let v372_6: Path = concat_path(&(v369_6),&(v369_11_head));
              let v372_11: Space = routine_15(c, &(v372_6), &(v369_11_tail).make_space());
              drop(v372_6);
              compose(&(v370_10),&(v372_11))
            };
            drop(v370_10);
            let v370_13: Space = unite(&(v370_8),&(v370_12));
            v369_11.join_into((v370_13).clone());
            }
            v369_11_cursor.ascend(1);
          }
          drop(v369_11_cursor);
          drop(v369_6);
          compose(&(v364_10),&(v369_11))
        };
        drop(v364_10);
        let v364_13: Space = unite(&(v364_8),&(v364_12));
        v363_7.join_into((v364_13).clone());
        }
        v363_7_cursor.ascend(1);
      }
      drop(v363_7_cursor);
      compose(&(v362_5),&(v363_7))
    };
    drop(v362_5);
    let v362_9: Space = intersect(&(*CONSTANT_1),&(v362_2));
    drop(v362_2);
    let v362_10: Space = if has_head(&(v362_9)) { singleton(&[]) } else { Space::new() };
    drop(v362_9);
    let v362_12: Space = if (v362_10).is_empty() { Space::new() } else {
      let v373_6: Path = concat_path(&(*p0),&(v361_20_head));
      let mut v373_11 = Space::new();
      let mut v373_11_cursor = (v361_20_tail).read_zipper();
      for v373_11_byte in v373_11_cursor.child_mask().iter() {
        v373_11_cursor.descend_to_byte(v373_11_byte);
        {
        let v373_11_tail = v373_11_cursor.fork_read_zipper();
        let v373_11_head = Path::from_slice(&[v373_11_byte]);
        let v374_2: Space = singleton(&(v373_11_head));
        let v374_3: Space = intersect(&(*CONSTANT_1),&(v374_2));
        let v374_4: Space = if has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
        drop(v374_3);
        let v374_5: Space = subtract(&(*CONSTANT_0),&(v374_4));
        drop(v374_4);
        let v374_8: Space = if (v374_5).is_empty() { Space::new() } else {
          let v375_6: Path = concat_path(&(v373_6),&(v373_11_head));
          let mut v375_7 = Space::new();
          let mut v375_7_cursor = (v373_11_tail).read_zipper();
          for v375_7_byte in v375_7_cursor.child_mask().iter() {
            v375_7_cursor.descend_to_byte(v375_7_byte);
            {
            let v375_7_tail = v375_7_cursor.fork_read_zipper();
            let v375_7_head = Path::from_slice(&[v375_7_byte]);
            let v376_2: Space = singleton(&(v375_7_head));
            let v376_3: Space = intersect(&(*CONSTANT_1),&(v376_2));
            let v376_4: Space = if has_head(&(v376_3)) { singleton(&[]) } else { Space::new() };
            drop(v376_3);
            let v376_5: Space = subtract(&(*CONSTANT_0),&(v376_4));
            drop(v376_4);
            let v376_8: Space = if (v376_5).is_empty() { Space::new() } else {
              let v377_6: Path = concat_path(&(v375_6),&(v375_7_head));
              let v377_7: Space = routine_34(c, &(v377_6), &(v375_7_tail).make_space());
              compose(&(v376_5),&(v377_7))
            };
            drop(v376_5);
            let v376_9: Space = intersect(&(*CONSTANT_1),&(v376_2));
            drop(v376_2);
            let v376_10: Space = if has_head(&(v376_9)) { singleton(&[]) } else { Space::new() };
            drop(v376_9);
            let v376_12: Space = if (v376_10).is_empty() { Space::new() } else {
              let v378_6: Path = concat_path(&(v375_6),&(v375_7_head));
              let v378_11: Space = routine_35(c, &(v378_6), &(v375_7_tail).make_space());
              drop(v378_6);
              compose(&(v376_10),&(v378_11))
            };
            drop(v376_10);
            let v376_13: Space = unite(&(v376_8),&(v376_12));
            v375_7.join_into((v376_13).clone());
            }
            v375_7_cursor.ascend(1);
          }
          drop(v375_7_cursor);
          drop(v375_6);
          compose(&(v374_5),&(v375_7))
        };
        drop(v374_5);
        let v374_9: Space = intersect(&(*CONSTANT_1),&(v374_2));
        drop(v374_2);
        let v374_10: Space = if has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
        drop(v374_9);
        let v374_11: Space = compose(&(v374_10),&(v373_11_tail));
        drop(v374_10);
        let v374_12: Space = unite(&(v374_8),&(v374_11));
        drop(v374_11);
        v373_11.join_into((v374_12).clone());
        }
        v373_11_cursor.ascend(1);
      }
      drop(v373_11_cursor);
      drop(v373_6);
      compose(&(v362_10),&(v373_11))
    };
    drop(v362_10);
    let v362_13: Space = unite(&(v362_8),&(v362_12));
    v361_20.join_into((v362_13).clone());
    }
    v361_20_cursor.ascend(1);
  }
  drop(v361_20_cursor);
  (v361_20).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v379_14 = Space::new();
  let mut v379_14_cursor = (*s0).read_zipper();
  for v379_14_byte in v379_14_cursor.child_mask().iter() {
    v379_14_cursor.descend_to_byte(v379_14_byte);
    {
    let v379_14_tail = v379_14_cursor.fork_read_zipper();
    let v379_14_head = Path::from_slice(&[v379_14_byte]);
    let v380_2: Space = singleton(&(v379_14_head));
    let v380_3: Space = intersect(&(*CONSTANT_1),&(v380_2));
    let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
    drop(v380_3);
    let v380_5: Space = subtract(&(*CONSTANT_0),&(v380_4));
    drop(v380_4);
    let v380_8: Space = if (v380_5).is_empty() { Space::new() } else {
      let v381_6: Path = concat_path(&(*p0),&(v379_14_head));
      let mut v381_7 = Space::new();
      let mut v381_7_cursor = (v379_14_tail).read_zipper();
      for v381_7_byte in v381_7_cursor.child_mask().iter() {
        v381_7_cursor.descend_to_byte(v381_7_byte);
        {
        let v381_7_tail = v381_7_cursor.fork_read_zipper();
        let v381_7_head = Path::from_slice(&[v381_7_byte]);
        let v382_2: Space = singleton(&(v381_7_head));
        let v382_3: Space = intersect(&(*CONSTANT_1),&(v382_2));
        let v382_4: Space = if has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
        drop(v382_3);
        let v382_5: Space = subtract(&(*CONSTANT_0),&(v382_4));
        drop(v382_4);
        let v382_8: Space = if (v382_5).is_empty() { Space::new() } else {
          let v383_6: Path = concat_path(&(v381_6),&(v381_7_head));
          let mut v383_7 = Space::new();
          let mut v383_7_cursor = (v381_7_tail).read_zipper();
          for v383_7_byte in v383_7_cursor.child_mask().iter() {
            v383_7_cursor.descend_to_byte(v383_7_byte);
            {
            let v383_7_tail = v383_7_cursor.fork_read_zipper();
            let v383_7_head = Path::from_slice(&[v383_7_byte]);
            let v384_2: Space = singleton(&(v383_7_head));
            let v384_3: Space = intersect(&(*CONSTANT_1),&(v384_2));
            let v384_4: Space = if has_head(&(v384_3)) { singleton(&[]) } else { Space::new() };
            drop(v384_3);
            let v384_5: Space = subtract(&(*CONSTANT_0),&(v384_4));
            drop(v384_4);
            let v384_8: Space = if (v384_5).is_empty() { Space::new() } else {
              let v385_6: Path = concat_path(&(v383_6),&(v383_7_head));
              let v385_7: Space = routine_34(c, &(v385_6), &(v383_7_tail).make_space());
              compose(&(v384_5),&(v385_7))
            };
            drop(v384_5);
            let v384_9: Space = intersect(&(*CONSTANT_1),&(v384_2));
            drop(v384_2);
            let v384_10: Space = if has_head(&(v384_9)) { singleton(&[]) } else { Space::new() };
            drop(v384_9);
            let v384_12: Space = if (v384_10).is_empty() { Space::new() } else {
              let v386_6: Path = concat_path(&(v383_6),&(v383_7_head));
              let v386_11: Space = routine_35(c, &(v386_6), &(v383_7_tail).make_space());
              drop(v386_6);
              compose(&(v384_10),&(v386_11))
            };
            drop(v384_10);
            let v384_13: Space = unite(&(v384_8),&(v384_12));
            v383_7.join_into((v384_13).clone());
            }
            v383_7_cursor.ascend(1);
          }
          drop(v383_7_cursor);
          compose(&(v382_5),&(v383_7))
        };
        drop(v382_5);
        let v382_9: Space = intersect(&(*CONSTANT_1),&(v382_2));
        drop(v382_2);
        let v382_10: Space = if has_head(&(v382_9)) { singleton(&[]) } else { Space::new() };
        drop(v382_9);
        let v382_12: Space = if (v382_10).is_empty() { Space::new() } else {
          let v387_6: Path = concat_path(&(v381_6),&(v381_7_head));
          let mut v387_11 = Space::new();
          let mut v387_11_cursor = (v381_7_tail).read_zipper();
          for v387_11_byte in v387_11_cursor.child_mask().iter() {
            v387_11_cursor.descend_to_byte(v387_11_byte);
            {
            let v387_11_tail = v387_11_cursor.fork_read_zipper();
            let v387_11_head = Path::from_slice(&[v387_11_byte]);
            let v388_2: Space = singleton(&(v387_11_head));
            let v388_3: Space = intersect(&(*CONSTANT_1),&(v388_2));
            let v388_4: Space = if has_head(&(v388_3)) { singleton(&[]) } else { Space::new() };
            drop(v388_3);
            let v388_5: Space = subtract(&(*CONSTANT_0),&(v388_4));
            drop(v388_4);
            let v388_8: Space = if (v388_5).is_empty() { Space::new() } else {
              let v389_6: Path = concat_path(&(v387_6),&(v387_11_head));
              let v389_7: Space = routine_34(c, &(v389_6), &(v387_11_tail).make_space());
              compose(&(v388_5),&(v389_7))
            };
            drop(v388_5);
            let v388_9: Space = intersect(&(*CONSTANT_1),&(v388_2));
            drop(v388_2);
            let v388_10: Space = if has_head(&(v388_9)) { singleton(&[]) } else { Space::new() };
            drop(v388_9);
            let v388_12: Space = if (v388_10).is_empty() { Space::new() } else {
              let v390_6: Path = concat_path(&(v387_6),&(v387_11_head));
              let v390_11: Space = routine_15(c, &(v390_6), &(v387_11_tail).make_space());
              drop(v390_6);
              compose(&(v388_10),&(v390_11))
            };
            drop(v388_10);
            let v388_13: Space = unite(&(v388_8),&(v388_12));
            v387_11.join_into((v388_13).clone());
            }
            v387_11_cursor.ascend(1);
          }
          drop(v387_11_cursor);
          drop(v387_6);
          compose(&(v382_10),&(v387_11))
        };
        drop(v382_10);
        let v382_13: Space = unite(&(v382_8),&(v382_12));
        v381_7.join_into((v382_13).clone());
        }
        v381_7_cursor.ascend(1);
      }
      drop(v381_7_cursor);
      drop(v381_6);
      compose(&(v380_5),&(v381_7))
    };
    drop(v380_5);
    let v380_9: Space = intersect(&(*CONSTANT_1),&(v380_2));
    drop(v380_2);
    let v380_10: Space = if has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
    drop(v380_9);
    let v380_11: Space = compose(&(v380_10),&(v379_14_tail));
    drop(v380_10);
    let v380_12: Space = unite(&(v380_8),&(v380_11));
    drop(v380_11);
    v379_14.join_into((v380_12).clone());
    }
    v379_14_cursor.ascend(1);
  }
  drop(v379_14_cursor);
  (v379_14).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v391_12 = Space::new();
  let mut v391_12_cursor = (*s0).read_zipper();
  for v391_12_byte in v391_12_cursor.child_mask().iter() {
    v391_12_cursor.descend_to_byte(v391_12_byte);
    {
    let v391_12_tail = v391_12_cursor.fork_read_zipper();
    let v391_12_head = Path::from_slice(&[v391_12_byte]);
    let v392_2: Space = singleton(&(v391_12_head));
    let v392_3: Space = intersect(&(*CONSTANT_1),&(v392_2));
    let v392_4: Space = if has_head(&(v392_3)) { singleton(&[]) } else { Space::new() };
    drop(v392_3);
    let v392_5: Space = subtract(&(*CONSTANT_0),&(v392_4));
    drop(v392_4);
    let v392_8: Space = if (v392_5).is_empty() { Space::new() } else {
      let v393_6: Path = concat_path(&(*p0),&(v391_12_head));
      let mut v393_7 = Space::new();
      let mut v393_7_cursor = (v391_12_tail).read_zipper();
      for v393_7_byte in v393_7_cursor.child_mask().iter() {
        v393_7_cursor.descend_to_byte(v393_7_byte);
        {
        let v393_7_tail = v393_7_cursor.fork_read_zipper();
        let v393_7_head = Path::from_slice(&[v393_7_byte]);
        let v394_2: Space = singleton(&(v393_7_head));
        let v394_3: Space = intersect(&(*CONSTANT_1),&(v394_2));
        let v394_4: Space = if has_head(&(v394_3)) { singleton(&[]) } else { Space::new() };
        drop(v394_3);
        let v394_5: Space = subtract(&(*CONSTANT_0),&(v394_4));
        drop(v394_4);
        let mut v394_6 = Space::new();
        let mut v394_6_cursor = (v393_7_tail).read_zipper();
        for v394_6_byte in v394_6_cursor.child_mask().iter() {
          v394_6_cursor.descend_to_byte(v394_6_byte);
          {
          let v394_6_tail = v394_6_cursor.fork_read_zipper();
          let v394_6_head = Path::from_slice(&[v394_6_byte]);
          let v395_2: Space = Space::new();
          v394_6.join_into((v395_2).clone());
          }
          v394_6_cursor.ascend(1);
        }
        drop(v394_6_cursor);
        let v394_7: Space = compose(&(v394_5),&(v394_6));
        drop(v394_5);
        drop(v394_6);
        let v394_8: Space = intersect(&(*CONSTANT_1),&(v394_2));
        drop(v394_2);
        let v394_9: Space = if has_head(&(v394_8)) { singleton(&[]) } else { Space::new() };
        drop(v394_8);
        let v394_12: Space = if (v394_9).is_empty() { Space::new() } else {
          let v396_10: Path = concat_path(&(v393_6),&(v393_7_head));
          let mut v396_11 = Space::new();
          let mut v396_11_cursor = (v393_7_tail).read_zipper();
          for v396_11_byte in v396_11_cursor.child_mask().iter() {
            v396_11_cursor.descend_to_byte(v396_11_byte);
            {
            let v396_11_tail = v396_11_cursor.fork_read_zipper();
            let v396_11_head = Path::from_slice(&[v396_11_byte]);
            let v397_2: Space = singleton(&(v396_11_head));
            let v397_3: Space = intersect(&(*CONSTANT_1),&(v397_2));
            drop(v397_2);
            let v397_4: Space = if has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
            drop(v397_3);
            let v397_7: Space = if (v397_4).is_empty() { Space::new() } else {
              let v398_5: Path = concat_path(&(v396_10),&(v396_11_head));
              let v398_6: Space = routine_12(c, &(v398_5), &(v396_11_tail).make_space());
              drop(v398_5);
              compose(&(v397_4),&(v398_6))
            };
            drop(v397_4);
            v396_11.join_into((v397_7).clone());
            }
            v396_11_cursor.ascend(1);
          }
          drop(v396_11_cursor);
          drop(v396_10);
          compose(&(v394_9),&(v396_11))
        };
        drop(v394_9);
        let v394_13: Space = unite(&(v394_7),&(v394_12));
        drop(v394_7);
        v393_7.join_into((v394_13).clone());
        }
        v393_7_cursor.ascend(1);
      }
      drop(v393_7_cursor);
      drop(v393_6);
      compose(&(v392_5),&(v393_7))
    };
    drop(v392_5);
    let v392_9: Space = intersect(&(*CONSTANT_1),&(v392_2));
    drop(v392_2);
    let v392_10: Space = if has_head(&(v392_9)) { singleton(&[]) } else { Space::new() };
    drop(v392_9);
    let mut v392_11 = Space::new();
    let mut v392_11_cursor = (v391_12_tail).read_zipper();
    for v392_11_byte in v392_11_cursor.child_mask().iter() {
      v392_11_cursor.descend_to_byte(v392_11_byte);
      {
      let v392_11_tail = v392_11_cursor.fork_read_zipper();
      let v392_11_head = Path::from_slice(&[v392_11_byte]);
      let v399_2: Space = singleton(&(v392_11_head));
      let v399_3: Space = intersect(&(*CONSTANT_1),&(v399_2));
      let v399_4: Space = if has_head(&(v399_3)) { singleton(&[]) } else { Space::new() };
      drop(v399_3);
      let v399_5: Space = subtract(&(*CONSTANT_0),&(v399_4));
      drop(v399_4);
      let mut v399_6 = Space::new();
      let mut v399_6_cursor = (v392_11_tail).read_zipper();
      for v399_6_byte in v399_6_cursor.child_mask().iter() {
        v399_6_cursor.descend_to_byte(v399_6_byte);
        {
        let v399_6_tail = v399_6_cursor.fork_read_zipper();
        let v399_6_head = Path::from_slice(&[v399_6_byte]);
        let v400_2: Space = Space::new();
        v399_6.join_into((v400_2).clone());
        }
        v399_6_cursor.ascend(1);
      }
      drop(v399_6_cursor);
      let v399_7: Space = compose(&(v399_5),&(v399_6));
      drop(v399_5);
      drop(v399_6);
      let v399_8: Space = intersect(&(*CONSTANT_1),&(v399_2));
      drop(v399_2);
      let v399_9: Space = if has_head(&(v399_8)) { singleton(&[]) } else { Space::new() };
      drop(v399_8);
      let v399_10: Space = compose(&(v399_9),&(v392_11_tail));
      drop(v399_9);
      let v399_11: Space = unite(&(v399_7),&(v399_10));
      drop(v399_7);
      drop(v399_10);
      v392_11.join_into((v399_11).clone());
      }
      v392_11_cursor.ascend(1);
    }
    drop(v392_11_cursor);
    let v392_12: Space = compose(&(v392_10),&(v392_11));
    drop(v392_10);
    drop(v392_11);
    let v392_13: Space = unite(&(v392_8),&(v392_12));
    drop(v392_12);
    v391_12.join_into((v392_13).clone());
    }
    v391_12_cursor.ascend(1);
  }
  drop(v391_12_cursor);
  (v391_12).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v401_9 = Space::new();
  let mut v401_9_cursor = (*s0).read_zipper();
  for v401_9_byte in v401_9_cursor.child_mask().iter() {
    v401_9_cursor.descend_to_byte(v401_9_byte);
    {
    let v401_9_tail = v401_9_cursor.fork_read_zipper();
    let v401_9_head = Path::from_slice(&[v401_9_byte]);
    let v402_2: Space = singleton(&(v401_9_head));
    let v402_3: Space = intersect(&(*CONSTANT_1),&(v402_2));
    let v402_4: Space = if has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
    drop(v402_3);
    let v402_5: Space = subtract(&(*CONSTANT_0),&(v402_4));
    drop(v402_4);
    let v402_8: Space = if (v402_5).is_empty() { Space::new() } else {
      let v403_6: Path = concat_path(&(*p0),&(v401_9_head));
      let mut v403_7 = Space::new();
      let mut v403_7_cursor = (v401_9_tail).read_zipper();
      for v403_7_byte in v403_7_cursor.child_mask().iter() {
        v403_7_cursor.descend_to_byte(v403_7_byte);
        {
        let v403_7_tail = v403_7_cursor.fork_read_zipper();
        let v403_7_head = Path::from_slice(&[v403_7_byte]);
        let v404_2: Space = singleton(&(v403_7_head));
        let v404_3: Space = intersect(&(*CONSTANT_1),&(v404_2));
        let v404_4: Space = if has_head(&(v404_3)) { singleton(&[]) } else { Space::new() };
        drop(v404_3);
        let v404_5: Space = subtract(&(*CONSTANT_0),&(v404_4));
        drop(v404_4);
        let mut v404_6 = Space::new();
        let mut v404_6_cursor = (v403_7_tail).read_zipper();
        for v404_6_byte in v404_6_cursor.child_mask().iter() {
          v404_6_cursor.descend_to_byte(v404_6_byte);
          {
          let v404_6_tail = v404_6_cursor.fork_read_zipper();
          let v404_6_head = Path::from_slice(&[v404_6_byte]);
          let v405_2: Space = Space::new();
          v404_6.join_into((v405_2).clone());
          }
          v404_6_cursor.ascend(1);
        }
        drop(v404_6_cursor);
        let v404_7: Space = compose(&(v404_5),&(v404_6));
        drop(v404_5);
        drop(v404_6);
        let v404_8: Space = intersect(&(*CONSTANT_1),&(v404_2));
        drop(v404_2);
        let v404_9: Space = if has_head(&(v404_8)) { singleton(&[]) } else { Space::new() };
        drop(v404_8);
        let v404_12: Space = if (v404_9).is_empty() { Space::new() } else {
          let v406_10: Path = concat_path(&(v403_6),&(v403_7_head));
          let mut v406_11 = Space::new();
          let mut v406_11_cursor = (v403_7_tail).read_zipper();
          for v406_11_byte in v406_11_cursor.child_mask().iter() {
            v406_11_cursor.descend_to_byte(v406_11_byte);
            {
            let v406_11_tail = v406_11_cursor.fork_read_zipper();
            let v406_11_head = Path::from_slice(&[v406_11_byte]);
            let v407_2: Space = singleton(&(v406_11_head));
            let v407_3: Space = intersect(&(*CONSTANT_1),&(v407_2));
            drop(v407_2);
            let v407_4: Space = if has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
            drop(v407_3);
            let v407_7: Space = if (v407_4).is_empty() { Space::new() } else {
              let v408_5: Path = concat_path(&(v406_10),&(v406_11_head));
              let v408_6: Space = routine_12(c, &(v408_5), &(v406_11_tail).make_space());
              drop(v408_5);
              compose(&(v407_4),&(v408_6))
            };
            drop(v407_4);
            v406_11.join_into((v407_7).clone());
            }
            v406_11_cursor.ascend(1);
          }
          drop(v406_11_cursor);
          drop(v406_10);
          compose(&(v404_9),&(v406_11))
        };
        drop(v404_9);
        let v404_13: Space = unite(&(v404_7),&(v404_12));
        drop(v404_7);
        v403_7.join_into((v404_13).clone());
        }
        v403_7_cursor.ascend(1);
      }
      drop(v403_7_cursor);
      drop(v403_6);
      compose(&(v402_5),&(v403_7))
    };
    drop(v402_5);
    let v402_9: Space = intersect(&(*CONSTANT_1),&(v402_2));
    drop(v402_2);
    let v402_10: Space = if has_head(&(v402_9)) { singleton(&[]) } else { Space::new() };
    drop(v402_9);
    let v402_11: Space = compose(&(v402_10),&(v401_9_tail));
    drop(v402_10);
    let v402_12: Space = unite(&(v402_8),&(v402_11));
    drop(v402_11);
    v401_9.join_into((v402_12).clone());
    }
    v401_9_cursor.ascend(1);
  }
  drop(v401_9_cursor);
  (v401_9).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v409_12 = Space::new();
  let mut v409_12_cursor = (*s0).read_zipper();
  for v409_12_byte in v409_12_cursor.child_mask().iter() {
    v409_12_cursor.descend_to_byte(v409_12_byte);
    {
    let v409_12_tail = v409_12_cursor.fork_read_zipper();
    let v409_12_head = Path::from_slice(&[v409_12_byte]);
    let v410_2: Space = singleton(&(v409_12_head));
    let v410_3: Space = intersect(&(*CONSTANT_1),&(v410_2));
    let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
    drop(v410_3);
    let v410_5: Space = subtract(&(*CONSTANT_0),&(v410_4));
    drop(v410_4);
    let v410_8: Space = if (v410_5).is_empty() { Space::new() } else {
      let v411_6: Path = concat_path(&(*p0),&(v409_12_head));
      let mut v411_7 = Space::new();
      let mut v411_7_cursor = (v409_12_tail).read_zipper();
      for v411_7_byte in v411_7_cursor.child_mask().iter() {
        v411_7_cursor.descend_to_byte(v411_7_byte);
        {
        let v411_7_tail = v411_7_cursor.fork_read_zipper();
        let v411_7_head = Path::from_slice(&[v411_7_byte]);
        let v412_2: Space = singleton(&(v411_7_head));
        let v412_3: Space = intersect(&(*CONSTANT_1),&(v412_2));
        let v412_4: Space = if has_head(&(v412_3)) { singleton(&[]) } else { Space::new() };
        drop(v412_3);
        let v412_5: Space = subtract(&(*CONSTANT_0),&(v412_4));
        drop(v412_4);
        let mut v412_6 = Space::new();
        let mut v412_6_cursor = (v411_7_tail).read_zipper();
        for v412_6_byte in v412_6_cursor.child_mask().iter() {
          v412_6_cursor.descend_to_byte(v412_6_byte);
          {
          let v412_6_tail = v412_6_cursor.fork_read_zipper();
          let v412_6_head = Path::from_slice(&[v412_6_byte]);
          let v413_2: Space = Space::new();
          v412_6.join_into((v413_2).clone());
          }
          v412_6_cursor.ascend(1);
        }
        drop(v412_6_cursor);
        let v412_7: Space = compose(&(v412_5),&(v412_6));
        drop(v412_5);
        drop(v412_6);
        let v412_8: Space = intersect(&(*CONSTANT_1),&(v412_2));
        drop(v412_2);
        let v412_9: Space = if has_head(&(v412_8)) { singleton(&[]) } else { Space::new() };
        drop(v412_8);
        let v412_12: Space = if (v412_9).is_empty() { Space::new() } else {
          let v414_10: Path = concat_path(&(v411_6),&(v411_7_head));
          let mut v414_11 = Space::new();
          let mut v414_11_cursor = (v411_7_tail).read_zipper();
          for v414_11_byte in v414_11_cursor.child_mask().iter() {
            v414_11_cursor.descend_to_byte(v414_11_byte);
            {
            let v414_11_tail = v414_11_cursor.fork_read_zipper();
            let v414_11_head = Path::from_slice(&[v414_11_byte]);
            let v415_2: Space = singleton(&(v414_11_head));
            let v415_3: Space = intersect(&(*CONSTANT_1),&(v415_2));
            drop(v415_2);
            let v415_4: Space = if has_head(&(v415_3)) { singleton(&[]) } else { Space::new() };
            drop(v415_3);
            let v415_7: Space = if (v415_4).is_empty() { Space::new() } else {
              let v416_5: Path = concat_path(&(v414_10),&(v414_11_head));
              let v416_6: Space = routine_15(c, &(v416_5), &(v414_11_tail).make_space());
              drop(v416_5);
              compose(&(v415_4),&(v416_6))
            };
            drop(v415_4);
            v414_11.join_into((v415_7).clone());
            }
            v414_11_cursor.ascend(1);
          }
          drop(v414_11_cursor);
          drop(v414_10);
          compose(&(v412_9),&(v414_11))
        };
        drop(v412_9);
        let v412_13: Space = unite(&(v412_7),&(v412_12));
        drop(v412_7);
        v411_7.join_into((v412_13).clone());
        }
        v411_7_cursor.ascend(1);
      }
      drop(v411_7_cursor);
      drop(v411_6);
      compose(&(v410_5),&(v411_7))
    };
    drop(v410_5);
    let v410_9: Space = intersect(&(*CONSTANT_1),&(v410_2));
    drop(v410_2);
    let v410_10: Space = if has_head(&(v410_9)) { singleton(&[]) } else { Space::new() };
    drop(v410_9);
    let mut v410_11 = Space::new();
    let mut v410_11_cursor = (v409_12_tail).read_zipper();
    for v410_11_byte in v410_11_cursor.child_mask().iter() {
      v410_11_cursor.descend_to_byte(v410_11_byte);
      {
      let v410_11_tail = v410_11_cursor.fork_read_zipper();
      let v410_11_head = Path::from_slice(&[v410_11_byte]);
      let v417_2: Space = singleton(&(v410_11_head));
      let v417_3: Space = intersect(&(*CONSTANT_1),&(v417_2));
      let v417_4: Space = if has_head(&(v417_3)) { singleton(&[]) } else { Space::new() };
      drop(v417_3);
      let v417_5: Space = subtract(&(*CONSTANT_0),&(v417_4));
      drop(v417_4);
      let mut v417_6 = Space::new();
      let mut v417_6_cursor = (v410_11_tail).read_zipper();
      for v417_6_byte in v417_6_cursor.child_mask().iter() {
        v417_6_cursor.descend_to_byte(v417_6_byte);
        {
        let v417_6_tail = v417_6_cursor.fork_read_zipper();
        let v417_6_head = Path::from_slice(&[v417_6_byte]);
        let v418_2: Space = Space::new();
        v417_6.join_into((v418_2).clone());
        }
        v417_6_cursor.ascend(1);
      }
      drop(v417_6_cursor);
      let v417_7: Space = compose(&(v417_5),&(v417_6));
      drop(v417_5);
      drop(v417_6);
      let v417_8: Space = intersect(&(*CONSTANT_1),&(v417_2));
      drop(v417_2);
      let v417_9: Space = if has_head(&(v417_8)) { singleton(&[]) } else { Space::new() };
      drop(v417_8);
      let v417_10: Space = compose(&(v417_9),&(v410_11_tail));
      drop(v417_9);
      let v417_11: Space = unite(&(v417_7),&(v417_10));
      drop(v417_7);
      drop(v417_10);
      v410_11.join_into((v417_11).clone());
      }
      v410_11_cursor.ascend(1);
    }
    drop(v410_11_cursor);
    let v410_12: Space = compose(&(v410_10),&(v410_11));
    drop(v410_10);
    drop(v410_11);
    let v410_13: Space = unite(&(v410_8),&(v410_12));
    drop(v410_12);
    v409_12.join_into((v410_13).clone());
    }
    v409_12_cursor.ascend(1);
  }
  drop(v409_12_cursor);
  (v409_12).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v419_9 = Space::new();
  let mut v419_9_cursor = (*s0).read_zipper();
  for v419_9_byte in v419_9_cursor.child_mask().iter() {
    v419_9_cursor.descend_to_byte(v419_9_byte);
    {
    let v419_9_tail = v419_9_cursor.fork_read_zipper();
    let v419_9_head = Path::from_slice(&[v419_9_byte]);
    let v420_2: Space = singleton(&(v419_9_head));
    let v420_3: Space = intersect(&(*CONSTANT_1),&(v420_2));
    let v420_4: Space = if has_head(&(v420_3)) { singleton(&[]) } else { Space::new() };
    drop(v420_3);
    let v420_5: Space = subtract(&(*CONSTANT_0),&(v420_4));
    drop(v420_4);
    let v420_8: Space = if (v420_5).is_empty() { Space::new() } else {
      let v421_6: Path = concat_path(&(*p0),&(v419_9_head));
      let mut v421_7 = Space::new();
      let mut v421_7_cursor = (v419_9_tail).read_zipper();
      for v421_7_byte in v421_7_cursor.child_mask().iter() {
        v421_7_cursor.descend_to_byte(v421_7_byte);
        {
        let v421_7_tail = v421_7_cursor.fork_read_zipper();
        let v421_7_head = Path::from_slice(&[v421_7_byte]);
        let v422_2: Space = singleton(&(v421_7_head));
        let v422_3: Space = intersect(&(*CONSTANT_1),&(v422_2));
        let v422_4: Space = if has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
        drop(v422_3);
        let v422_5: Space = subtract(&(*CONSTANT_0),&(v422_4));
        drop(v422_4);
        let mut v422_6 = Space::new();
        let mut v422_6_cursor = (v421_7_tail).read_zipper();
        for v422_6_byte in v422_6_cursor.child_mask().iter() {
          v422_6_cursor.descend_to_byte(v422_6_byte);
          {
          let v422_6_tail = v422_6_cursor.fork_read_zipper();
          let v422_6_head = Path::from_slice(&[v422_6_byte]);
          let v423_2: Space = Space::new();
          v422_6.join_into((v423_2).clone());
          }
          v422_6_cursor.ascend(1);
        }
        drop(v422_6_cursor);
        let v422_7: Space = compose(&(v422_5),&(v422_6));
        drop(v422_5);
        drop(v422_6);
        let v422_8: Space = intersect(&(*CONSTANT_1),&(v422_2));
        drop(v422_2);
        let v422_9: Space = if has_head(&(v422_8)) { singleton(&[]) } else { Space::new() };
        drop(v422_8);
        let v422_12: Space = if (v422_9).is_empty() { Space::new() } else {
          let v424_10: Path = concat_path(&(v421_6),&(v421_7_head));
          let mut v424_11 = Space::new();
          let mut v424_11_cursor = (v421_7_tail).read_zipper();
          for v424_11_byte in v424_11_cursor.child_mask().iter() {
            v424_11_cursor.descend_to_byte(v424_11_byte);
            {
            let v424_11_tail = v424_11_cursor.fork_read_zipper();
            let v424_11_head = Path::from_slice(&[v424_11_byte]);
            let v425_2: Space = singleton(&(v424_11_head));
            let v425_3: Space = intersect(&(*CONSTANT_1),&(v425_2));
            drop(v425_2);
            let v425_4: Space = if has_head(&(v425_3)) { singleton(&[]) } else { Space::new() };
            drop(v425_3);
            let v425_7: Space = if (v425_4).is_empty() { Space::new() } else {
              let v426_5: Path = concat_path(&(v424_10),&(v424_11_head));
              let v426_6: Space = routine_15(c, &(v426_5), &(v424_11_tail).make_space());
              drop(v426_5);
              compose(&(v425_4),&(v426_6))
            };
            drop(v425_4);
            v424_11.join_into((v425_7).clone());
            }
            v424_11_cursor.ascend(1);
          }
          drop(v424_11_cursor);
          drop(v424_10);
          compose(&(v422_9),&(v424_11))
        };
        drop(v422_9);
        let v422_13: Space = unite(&(v422_7),&(v422_12));
        drop(v422_7);
        v421_7.join_into((v422_13).clone());
        }
        v421_7_cursor.ascend(1);
      }
      drop(v421_7_cursor);
      drop(v421_6);
      compose(&(v420_5),&(v421_7))
    };
    drop(v420_5);
    let v420_9: Space = intersect(&(*CONSTANT_1),&(v420_2));
    drop(v420_2);
    let v420_10: Space = if has_head(&(v420_9)) { singleton(&[]) } else { Space::new() };
    drop(v420_9);
    let v420_11: Space = compose(&(v420_10),&(v419_9_tail));
    drop(v420_10);
    let v420_12: Space = unite(&(v420_8),&(v420_11));
    drop(v420_11);
    v419_9.join_into((v420_12).clone());
    }
    v419_9_cursor.ascend(1);
  }
  drop(v419_9_cursor);
  (v419_9).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v427_6 = Space::new();
  let mut v427_6_cursor = (*s0).read_zipper();
  for v427_6_byte in v427_6_cursor.child_mask().iter() {
    v427_6_cursor.descend_to_byte(v427_6_byte);
    {
    let v427_6_tail = v427_6_cursor.fork_read_zipper();
    let v427_6_head = Path::from_slice(&[v427_6_byte]);
    let v428_2: Space = singleton(&(v427_6_head));
    let v428_3: Space = intersect(&(*CONSTANT_1),&(v428_2));
    let v428_4: Space = if has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
    drop(v428_3);
    let v428_5: Space = subtract(&(*CONSTANT_0),&(v428_4));
    drop(v428_4);
    let mut v428_6 = Space::new();
    let mut v428_6_cursor = (v427_6_tail).read_zipper();
    for v428_6_byte in v428_6_cursor.child_mask().iter() {
      v428_6_cursor.descend_to_byte(v428_6_byte);
      {
      let v428_6_tail = v428_6_cursor.fork_read_zipper();
      let v428_6_head = Path::from_slice(&[v428_6_byte]);
      let v429_2: Space = Space::new();
      v428_6.join_into((v429_2).clone());
      }
      v428_6_cursor.ascend(1);
    }
    drop(v428_6_cursor);
    let v428_7: Space = compose(&(v428_5),&(v428_6));
    drop(v428_5);
    drop(v428_6);
    let v428_8: Space = intersect(&(*CONSTANT_1),&(v428_2));
    drop(v428_2);
    let v428_9: Space = if has_head(&(v428_8)) { singleton(&[]) } else { Space::new() };
    drop(v428_8);
    let mut v428_10 = Space::new();
    let mut v428_10_cursor = (v427_6_tail).read_zipper();
    for v428_10_byte in v428_10_cursor.child_mask().iter() {
      v428_10_cursor.descend_to_byte(v428_10_byte);
      {
      let v428_10_tail = v428_10_cursor.fork_read_zipper();
      let v428_10_head = Path::from_slice(&[v428_10_byte]);
      let v430_2: Space = singleton(&(v428_10_head));
      let v430_3: Space = intersect(&(*CONSTANT_1),&(v430_2));
      drop(v430_2);
      let v430_4: Space = if has_head(&(v430_3)) { singleton(&[]) } else { Space::new() };
      drop(v430_3);
      let v430_5: Space = compose(&(v430_4),&(v428_10_tail));
      drop(v430_4);
      v428_10.join_into((v430_5).clone());
      }
      v428_10_cursor.ascend(1);
    }
    drop(v428_10_cursor);
    let v428_11: Space = compose(&(v428_9),&(v428_10));
    drop(v428_9);
    drop(v428_10);
    let v428_12: Space = unite(&(v428_7),&(v428_11));
    drop(v428_7);
    drop(v428_11);
    v427_6.join_into((v428_12).clone());
    }
    v427_6_cursor.ascend(1);
  }
  drop(v427_6_cursor);
  (v427_6).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v431_5 = Space::new();
  let mut v431_5_cursor = (*s0).read_zipper();
  for v431_5_byte in v431_5_cursor.child_mask().iter() {
    v431_5_cursor.descend_to_byte(v431_5_byte);
    {
    let v431_5_tail = v431_5_cursor.fork_read_zipper();
    let v431_5_head = Path::from_slice(&[v431_5_byte]);
    let v432_2: Space = singleton(&(v431_5_head));
    let v432_3: Space = intersect(&(*CONSTANT_1),&(v432_2));
    let v432_4: Space = if has_head(&(v432_3)) { singleton(&[]) } else { Space::new() };
    drop(v432_3);
    let v432_5: Space = subtract(&(*CONSTANT_0),&(v432_4));
    drop(v432_4);
    let mut v432_6 = Space::new();
    let mut v432_6_cursor = (v431_5_tail).read_zipper();
    for v432_6_byte in v432_6_cursor.child_mask().iter() {
      v432_6_cursor.descend_to_byte(v432_6_byte);
      {
      let v432_6_tail = v432_6_cursor.fork_read_zipper();
      let v432_6_head = Path::from_slice(&[v432_6_byte]);
      let v433_2: Space = Space::new();
      v432_6.join_into((v433_2).clone());
      }
      v432_6_cursor.ascend(1);
    }
    drop(v432_6_cursor);
    let v432_7: Space = compose(&(v432_5),&(v432_6));
    drop(v432_5);
    drop(v432_6);
    let v432_8: Space = intersect(&(*CONSTANT_1),&(v432_2));
    drop(v432_2);
    let v432_9: Space = if has_head(&(v432_8)) { singleton(&[]) } else { Space::new() };
    drop(v432_8);
    let v432_10: Space = compose(&(v432_9),&(v431_5_tail));
    drop(v432_9);
    let v432_11: Space = unite(&(v432_7),&(v432_10));
    drop(v432_7);
    drop(v432_10);
    v431_5.join_into((v432_11).clone());
    }
    v431_5_cursor.ascend(1);
  }
  drop(v431_5_cursor);
  (v431_5).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v434_6 = Space::new();
  let mut v434_6_cursor = (*s0).read_zipper();
  for v434_6_byte in v434_6_cursor.child_mask().iter() {
    v434_6_cursor.descend_to_byte(v434_6_byte);
    {
    let v434_6_tail = v434_6_cursor.fork_read_zipper();
    let v434_6_head = Path::from_slice(&[v434_6_byte]);
    let v435_2: Space = singleton(&(v434_6_head));
    let v435_3: Space = intersect(&(*CONSTANT_1),&(v435_2));
    let v435_4: Space = if has_head(&(v435_3)) { singleton(&[]) } else { Space::new() };
    drop(v435_3);
    let v435_5: Space = subtract(&(*CONSTANT_0),&(v435_4));
    drop(v435_4);
    let mut v435_6 = Space::new();
    let mut v435_6_cursor = (v434_6_tail).read_zipper();
    for v435_6_byte in v435_6_cursor.child_mask().iter() {
      v435_6_cursor.descend_to_byte(v435_6_byte);
      {
      let v435_6_tail = v435_6_cursor.fork_read_zipper();
      let v435_6_head = Path::from_slice(&[v435_6_byte]);
      let v436_2: Space = Space::new();
      v435_6.join_into((v436_2).clone());
      }
      v435_6_cursor.ascend(1);
    }
    drop(v435_6_cursor);
    let v435_7: Space = compose(&(v435_5),&(v435_6));
    drop(v435_5);
    drop(v435_6);
    let v435_8: Space = intersect(&(*CONSTANT_1),&(v435_2));
    drop(v435_2);
    let v435_9: Space = if has_head(&(v435_8)) { singleton(&[]) } else { Space::new() };
    drop(v435_8);
    let mut v435_10 = Space::new();
    let mut v435_10_cursor = (v434_6_tail).read_zipper();
    for v435_10_byte in v435_10_cursor.child_mask().iter() {
      v435_10_cursor.descend_to_byte(v435_10_byte);
      {
      let v435_10_tail = v435_10_cursor.fork_read_zipper();
      let v435_10_head = Path::from_slice(&[v435_10_byte]);
      let v437_2: Space = singleton(&(v435_10_head));
      let v437_3: Space = intersect(&(*CONSTANT_1),&(v437_2));
      drop(v437_2);
      let v437_4: Space = if has_head(&(v437_3)) { singleton(&[]) } else { Space::new() };
      drop(v437_3);
      let v437_5: Space = compose(&(v437_4),&(v435_10_tail));
      drop(v437_4);
      v435_10.join_into((v437_5).clone());
      }
      v435_10_cursor.ascend(1);
    }
    drop(v435_10_cursor);
    let v435_11: Space = compose(&(v435_9),&(v435_10));
    drop(v435_9);
    drop(v435_10);
    let v435_12: Space = unite(&(v435_7),&(v435_11));
    drop(v435_7);
    drop(v435_11);
    v434_6.join_into((v435_12).clone());
    }
    v434_6_cursor.ascend(1);
  }
  drop(v434_6_cursor);
  (v434_6).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v438_5 = Space::new();
  let mut v438_5_cursor = (*s0).read_zipper();
  for v438_5_byte in v438_5_cursor.child_mask().iter() {
    v438_5_cursor.descend_to_byte(v438_5_byte);
    {
    let v438_5_tail = v438_5_cursor.fork_read_zipper();
    let v438_5_head = Path::from_slice(&[v438_5_byte]);
    let v439_2: Space = singleton(&(v438_5_head));
    let v439_3: Space = intersect(&(*CONSTANT_1),&(v439_2));
    let v439_4: Space = if has_head(&(v439_3)) { singleton(&[]) } else { Space::new() };
    drop(v439_3);
    let v439_5: Space = subtract(&(*CONSTANT_0),&(v439_4));
    drop(v439_4);
    let mut v439_6 = Space::new();
    let mut v439_6_cursor = (v438_5_tail).read_zipper();
    for v439_6_byte in v439_6_cursor.child_mask().iter() {
      v439_6_cursor.descend_to_byte(v439_6_byte);
      {
      let v439_6_tail = v439_6_cursor.fork_read_zipper();
      let v439_6_head = Path::from_slice(&[v439_6_byte]);
      let v440_2: Space = Space::new();
      v439_6.join_into((v440_2).clone());
      }
      v439_6_cursor.ascend(1);
    }
    drop(v439_6_cursor);
    let v439_7: Space = compose(&(v439_5),&(v439_6));
    drop(v439_5);
    drop(v439_6);
    let v439_8: Space = intersect(&(*CONSTANT_1),&(v439_2));
    drop(v439_2);
    let v439_9: Space = if has_head(&(v439_8)) { singleton(&[]) } else { Space::new() };
    drop(v439_8);
    let v439_10: Space = compose(&(v439_9),&(v438_5_tail));
    drop(v439_9);
    let v439_11: Space = unite(&(v439_7),&(v439_10));
    drop(v439_7);
    drop(v439_10);
    v438_5.join_into((v439_11).clone());
    }
    v438_5_cursor.ascend(1);
  }
  drop(v438_5_cursor);
  (v438_5).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v441_2 = Space::new();
  let mut v441_2_cursor = (*s0).read_zipper();
  for v441_2_byte in v441_2_cursor.child_mask().iter() {
    v441_2_cursor.descend_to_byte(v441_2_byte);
    {
    let v441_2_tail = v441_2_cursor.fork_read_zipper();
    let v441_2_head = Path::from_slice(&[v441_2_byte]);
    let v442_2: Space = Space::new();
    v441_2.join_into((v442_2).clone());
    }
    v441_2_cursor.ascend(1);
  }
  drop(v441_2_cursor);
  (v441_2).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v443_3 = Space::new();
  let mut v443_3_cursor = (*s0).read_zipper();
  for v443_3_byte in v443_3_cursor.child_mask().iter() {
    v443_3_cursor.descend_to_byte(v443_3_byte);
    {
    let v443_3_tail = v443_3_cursor.fork_read_zipper();
    let v443_3_head = Path::from_slice(&[v443_3_byte]);
    let v444_2: Space = singleton(&(v443_3_head));
    let v444_3: Space = intersect(&(*CONSTANT_1),&(v444_2));
    drop(v444_2);
    let v444_4: Space = if has_head(&(v444_3)) { singleton(&[]) } else { Space::new() };
    drop(v444_3);
    let v444_5: Space = compose(&(v444_4),&(v443_3_tail));
    drop(v444_4);
    v443_3.join_into((v444_5).clone());
    }
    v443_3_cursor.ascend(1);
  }
  drop(v443_3_cursor);
  (v443_3).clone()
}

fn routine_34(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v445_2 = Space::new();
  let mut v445_2_cursor = (*s0).read_zipper();
  for v445_2_byte in v445_2_cursor.child_mask().iter() {
    v445_2_cursor.descend_to_byte(v445_2_byte);
    {
    let v445_2_tail = v445_2_cursor.fork_read_zipper();
    let v445_2_head = Path::from_slice(&[v445_2_byte]);
    let v446_2: Space = Space::new();
    v445_2.join_into((v446_2).clone());
    }
    v445_2_cursor.ascend(1);
  }
  drop(v445_2_cursor);
  (v445_2).clone()
}

fn routine_35(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v447_3 = Space::new();
  let mut v447_3_cursor = (*s0).read_zipper();
  for v447_3_byte in v447_3_cursor.child_mask().iter() {
    v447_3_cursor.descend_to_byte(v447_3_byte);
    {
    let v447_3_tail = v447_3_cursor.fork_read_zipper();
    let v447_3_head = Path::from_slice(&[v447_3_byte]);
    let v448_2: Space = singleton(&(v447_3_head));
    let v448_3: Space = intersect(&(*CONSTANT_1),&(v448_2));
    drop(v448_2);
    let v448_4: Space = if has_head(&(v448_3)) { singleton(&[]) } else { Space::new() };
    drop(v448_3);
    let v448_5: Space = compose(&(v448_4),&(v447_3_tail));
    drop(v448_4);
    v447_3.join_into((v448_5).clone());
    }
    v447_3_cursor.ascend(1);
  }
  drop(v447_3_cursor);
  (v447_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
