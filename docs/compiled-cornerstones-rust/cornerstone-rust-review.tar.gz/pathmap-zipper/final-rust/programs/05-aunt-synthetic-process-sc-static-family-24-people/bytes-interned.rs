#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,24]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 8 0 0 0 0 0 0 0 6 8 0 0 0 0 0 0 0 11 8 0 0 0 1 0 0 0 6 8 0 0 0 1 0 0 0 7 8 0 0 0 2 0 0 0 7 8 0 0 0 2 0 0 0 8 8 0 0 0 3 0 0 0 8 8 0 0 0 3 0 0 0 9 8 0 0 0 4 0 0 0 9 8 0 0 0 4 0 0 0 10 8 0 0 0 5 0 0 0 10 8 0 0 0 5 0 0 0 11 8 0 0 0 6 0 0 0 12 8 0 0 0 6 0 0 0 17 8 0 0 0 7 0 0 0 12 8 0 0 0 7 0 0 0 13 8 0 0 0 8 0 0 0 13 8 0 0 0 8 0 0 0 14 8 0 0 0 9 0 0 0 14 8 0 0 0 9 0 0 0 15 8 0 0 0 10 0 0 0 15 8 0 0 0 10 0 0 0 16 8 0 0 0 11 0 0 0 16 8 0 0 0 11 0 0 0 17 8 0 0 0 12 0 0 0 18 8 0 0 0 12 0 0 0 23 8 0 0 0 13 0 0 0 18 8 0 0 0 13 0 0 0 19 8 0 0 0 14 0 0 0 19 8 0 0 0 14 0 0 0 20 8 0 0 0 15 0 0 0 20 8 0 0 0 15 0 0 0 21 8 0 0 0 16 0 0 0 21 8 0 0 0 16 0 0 0 22 8 0 0 0 17 0 0 0 22 8 0 0 0 17 0 0 0 23"));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("36 8 0 0 0 6 0 0 0 0 8 0 0 0 6 0 0 0 1 8 0 0 0 7 0 0 0 1 8 0 0 0 7 0 0 0 2 8 0 0 0 8 0 0 0 2 8 0 0 0 8 0 0 0 3 8 0 0 0 9 0 0 0 3 8 0 0 0 9 0 0 0 4 8 0 0 0 10 0 0 0 4 8 0 0 0 10 0 0 0 5 8 0 0 0 11 0 0 0 0 8 0 0 0 11 0 0 0 5 8 0 0 0 12 0 0 0 6 8 0 0 0 12 0 0 0 7 8 0 0 0 13 0 0 0 7 8 0 0 0 13 0 0 0 8 8 0 0 0 14 0 0 0 8 8 0 0 0 14 0 0 0 9 8 0 0 0 15 0 0 0 9 8 0 0 0 15 0 0 0 10 8 0 0 0 16 0 0 0 10 8 0 0 0 16 0 0 0 11 8 0 0 0 17 0 0 0 6 8 0 0 0 17 0 0 0 11 8 0 0 0 18 0 0 0 12 8 0 0 0 18 0 0 0 13 8 0 0 0 19 0 0 0 13 8 0 0 0 19 0 0 0 14 8 0 0 0 20 0 0 0 14 8 0 0 0 20 0 0 0 15 8 0 0 0 21 0 0 0 15 8 0 0 0 21 0 0 0 16 8 0 0 0 22 0 0 0 16 8 0 0 0 22 0 0 0 17 8 0 0 0 23 0 0 0 12 8 0 0 0 23 0 0 0 17"));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("12 4 0 0 0 0 4 0 0 0 2 4 0 0 0 4 4 0 0 0 6 4 0 0 0 8 4 0 0 0 10 4 0 0 0 12 4 0 0 0 14 4 0 0 0 16 4 0 0 0 18 4 0 0 0 20 4 0 0 0 22"));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_1 = Space::new();
  let mut v0_1_cursor = (*s0.expect("unbound native input")).read_zipper();
  for v0_1_byte in v0_1_cursor.child_mask().iter() {
    v0_1_cursor.descend_to_byte(v0_1_byte);
    {
    let v0_1_tail = v0_1_cursor.fork_read_zipper();
    let v0_1_head = Path::from_slice(&[v0_1_byte]);
    let mut v1_2 = Space::new();
    let mut v1_2_cursor = (v0_1_tail).read_zipper();
    for v1_2_byte in v1_2_cursor.child_mask().iter() {
      v1_2_cursor.descend_to_byte(v1_2_byte);
      {
      let v1_2_tail = v1_2_cursor.fork_read_zipper();
      let v1_2_head = Path::from_slice(&[v1_2_byte]);
      let v2_2: Path = concat_path(&(v0_1_head),&(v1_2_head));
      let mut v2_3 = Space::new();
      let mut v2_3_cursor = (v1_2_tail).read_zipper();
      for v2_3_byte in v2_3_cursor.child_mask().iter() {
        v2_3_cursor.descend_to_byte(v2_3_byte);
        {
        let v2_3_tail = v2_3_cursor.fork_read_zipper();
        let v2_3_head = Path::from_slice(&[v2_3_byte]);
        let v3_2: Path = concat_path(&(v2_2),&(v2_3_head));
        let mut v3_3 = Space::new();
        let mut v3_3_cursor = (v2_3_tail).read_zipper();
        for v3_3_byte in v3_3_cursor.child_mask().iter() {
          v3_3_cursor.descend_to_byte(v3_3_byte);
          {
          let v3_3_tail = v3_3_cursor.fork_read_zipper();
          let v3_3_head = Path::from_slice(&[v3_3_byte]);
          let v4_2: Path = concat_path(&(v3_2),&(v3_3_head));
          let v4_3: Space = routine_1(c, &(v4_2), &(v3_3_tail).make_space());
          drop(v4_2);
          v3_3.join_into((v4_3).clone());
          }
          v3_3_cursor.ascend(1);
        }
        drop(v3_3_cursor);
        drop(v3_2);
        v2_3.join_into((v3_3).clone());
        }
        v2_3_cursor.ascend(1);
      }
      drop(v2_3_cursor);
      drop(v2_2);
      v1_2.join_into((v2_3).clone());
      }
      v1_2_cursor.ascend(1);
    }
    drop(v1_2_cursor);
    v0_1.join_into((v1_2).clone());
    }
    v0_1_cursor.ascend(1);
  }
  drop(v0_1_cursor);
  let v0_3: Space = wrap(&(v0_1),&(*CONSTANT_0));
  (v0_3).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v5_5: Space = unwrap(&(*CONSTANT_2),&(*p0));
  let v5_6: Space = restrict_to(&(*CONSTANT_2),&(v5_5));
  drop(v5_5);
  let mut v5_7 = Space::new();
  let mut v5_7_cursor = (v5_6).read_zipper();
  for v5_7_byte in v5_7_cursor.child_mask().iter() {
    v5_7_cursor.descend_to_byte(v5_7_byte);
    {
    let v5_7_tail = v5_7_cursor.fork_read_zipper();
    let v5_7_head = Path::from_slice(&[v5_7_byte]);
    let mut v6_2 = Space::new();
    let mut v6_2_cursor = (v5_7_tail).read_zipper();
    for v6_2_byte in v6_2_cursor.child_mask().iter() {
      v6_2_cursor.descend_to_byte(v6_2_byte);
      {
      let v6_2_tail = v6_2_cursor.fork_read_zipper();
      let v6_2_head = Path::from_slice(&[v6_2_byte]);
      let mut v7_2 = Space::new();
      let mut v7_2_cursor = (v6_2_tail).read_zipper();
      for v7_2_byte in v7_2_cursor.child_mask().iter() {
        v7_2_cursor.descend_to_byte(v7_2_byte);
        {
        let v7_2_tail = v7_2_cursor.fork_read_zipper();
        let v7_2_head = Path::from_slice(&[v7_2_byte]);
        let v8_2: Space = tails_union(&(v7_2_tail));
        v7_2.join_into((v8_2).clone());
        }
        v7_2_cursor.ascend(1);
      }
      drop(v7_2_cursor);
      v6_2.join_into((v7_2).clone());
      }
      v6_2_cursor.ascend(1);
    }
    drop(v6_2_cursor);
    v5_7.join_into((v6_2).clone());
    }
    v5_7_cursor.ascend(1);
  }
  drop(v5_7_cursor);
  drop(v5_6);
  let v5_8: Space = restrict_to(&(*CONSTANT_1),&(v5_7));
  drop(v5_7);
  let mut v5_9 = Space::new();
  let mut v5_9_cursor = (v5_8).read_zipper();
  for v5_9_byte in v5_9_cursor.child_mask().iter() {
    v5_9_cursor.descend_to_byte(v5_9_byte);
    {
    let v5_9_tail = v5_9_cursor.fork_read_zipper();
    let v5_9_head = Path::from_slice(&[v5_9_byte]);
    let mut v9_2 = Space::new();
    let mut v9_2_cursor = (v5_9_tail).read_zipper();
    for v9_2_byte in v9_2_cursor.child_mask().iter() {
      v9_2_cursor.descend_to_byte(v9_2_byte);
      {
      let v9_2_tail = v9_2_cursor.fork_read_zipper();
      let v9_2_head = Path::from_slice(&[v9_2_byte]);
      let mut v10_2 = Space::new();
      let mut v10_2_cursor = (v9_2_tail).read_zipper();
      for v10_2_byte in v10_2_cursor.child_mask().iter() {
        v10_2_cursor.descend_to_byte(v10_2_byte);
        {
        let v10_2_tail = v10_2_cursor.fork_read_zipper();
        let v10_2_head = Path::from_slice(&[v10_2_byte]);
        let v11_2: Space = tails_union(&(v10_2_tail));
        v10_2.join_into((v11_2).clone());
        }
        v10_2_cursor.ascend(1);
      }
      drop(v10_2_cursor);
      v9_2.join_into((v10_2).clone());
      }
      v9_2_cursor.ascend(1);
    }
    drop(v9_2_cursor);
    v5_9.join_into((v9_2).clone());
    }
    v5_9_cursor.ascend(1);
  }
  drop(v5_9_cursor);
  drop(v5_8);
  let v5_11: Space = unwrap(&(*CONSTANT_2),&(*p0));
  let v5_12: Space = subtract(&(v5_9),&(v5_11));
  drop(v5_9);
  drop(v5_11);
  let v5_14: Space = intersect(&(v5_12),&(*CONSTANT_3));
  drop(v5_12);
  let v5_15: Space = wrap(&(v5_14),&(*p0));
  drop(v5_14);
  (v5_15).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
