#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[48]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 49 48 0 4 0 49 49 0"));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("120 10 67 101 108 108 0 48 0 49 48 0 10 67 101 108 108 0 48 0 49 49 0 10 67 101 108 108 0 49 0 49 51 0 10 67 101 108 108 0 49 0 49 52 0 10 67 101 108 108 0 49 0 50 48 0 11 67 101 108 108 0 49 48 0 49 50 0 11 67 101 108 108 0 49 48 0 49 56 0 11 67 101 108 108 0 49 48 0 50 51 0 10 67 101 108 108 0 49 48 0 54 0 10 67 101 108 108 0 49 48 0 57 0 11 67 101 108 108 0 49 49 0 49 49 0 11 67 101 108 108 0 49 49 0 49 50 0 11 67 101 108 108 0 49 49 0 50 51 0 10 67 101 108 108 0 49 49 0 51 0 10 67 101 108 108 0 49 49 0 53 0 11 67 101 108 108 0 49 50 0 49 54 0 11 67 101 108 108 0 49 50 0 49 57 0 10 67 101 108 108 0 49 50 0 50 0 11 67 101 108 108 0 49 51 0 49 52 0 11 67 101 108 108 0 49 51 0 50 48 0 11 67 101 108 108 0 49 51 0 50 49 0 10 67 101 108 108 0 49 51 0 57 0 10 67 101 108 108 0 49 52 0 48 0 11 67 101 108 108 0 49 52 0 49 56 0 10 67 101 108 108 0 49 52 0 54 0 10 67 101 108 108 0 49 52 0 56 0 10 67 101 108 108 0 49 52 0 57 0 10 67 101 108 108 0 49 53 0 49 0 11 67 101 108 108 0 49 53 0 49 54 0 11 67 101 108 108 0 49 53 0 49 55 0 11 67 101 108 108 0 49 53 0 49 57 0 11 67 101 108 108 0 49 53 0 50 48 0 10 67 101 108 108 0 49 53 0 51 0 10 67 101 108 108 0 49 53 0 53 0 10 67 101 108 108 0 49 53 0 54 0 10 67 101 108 108 0 49 54 0 48 0 11 67 101 108 108 0 49 55 0 49 50 0 11 67 101 108 108 0 49 55 0 49 54 0 11 67 101 108 108 0 49 55 0 49 56 0 10 67 101 108 108 0 49 55 0 50 0 10 67 101 108 108 0 49 55 0 51 0 10 67 101 108 108 0 49 55 0 52 0 10 67 101 108 108 0 49 55 0 54 0 10 67 101 108 108 0 49 55 0 55 0 10 67 101 108 108 0 49 55 0 57 0 11 67 101 108 108 0 49 56 0 49 48 0 11 67 101 108 108 0 49 56 0 49 50 0 11 67 101 108 108 0 49 56 0 49 51 0 11 67 101 108 108 0 49 56 0 49 53 0 11 67 101 108 108 0 49 56 0 49 55 0 11 67 101 108 108 0 49 56 0 50 50 0 10 67 101 108 108 0 49 56 0 53 0 11 67 101 108 108 0 49 57 0 49 56 0 11 67 101 108 108 0 49 57 0 50 49 0 10 67 101 108 108 0 49 57 0 51 0 10 67 101 108 108 0 50 0 49 48 0 10 67 101 108 108 0 50 0 49 51 0 10 67 101 108 108 0 50 0 50 49 0 11 67 101 108 108 0 50 48 0 49 53 0 10 67 101 108 108 0 50 48 0 50 0 10 67 101 108 108 0 50 48 0 53 0 10 67 101 108 108 0 50 48 0 55 0 10 67 101 108 108 0 50 48 0 57 0 11 67 101 108 108 0 50 49 0 49 51 0 11 67 101 108 108 0 50 49 0 49 53 0 10 67 101 108 108 0 50 49 0 52 0 10 67 101 108 108 0 50 49 0 56 0 10 67 101 108 108 0 50 49 0 57 0 11 67 101 108 108 0 50 50 0 49 54 0 10 67 101 108 108 0 50 50 0 50 0 11 67 101 108 108 0 50 50 0 50 50 0 10 67 101 108 108 0 50 51 0 49 0 10 67 101 108 108 0 50 51 0 50 0 10 67 101 108 108 0 50 51 0 53 0 10 67 101 108 108 0 50 51 0 55 0 10 67 101 108 108 0 50 51 0 57 0 9 67 101 108 108 0 51 0 49 0 9 67 101 108 108 0 51 0 50 0 10 67 101 108 108 0 51 0 50 49 0 9 67 101 108 108 0 51 0 53 0 9 67 101 108 108 0 51 0 55 0 10 67 101 108 108 0 52 0 49 49 0 10 67 101 108 108 0 52 0 49 53 0 10 67 101 108 108 0 52 0 49 54 0 10 67 101 108 108 0 52 0 49 57 0 10 67 101 108 108 0 52 0 50 48 0 10 67 101 108 108 0 52 0 50 51 0 9 67 101 108 108 0 52 0 56 0 10 67 101 108 108 0 53 0 49 48 0 10 67 101 108 108 0 53 0 49 50 0 10 67 101 108 108 0 53 0 49 56 0 10 67 101 108 108 0 53 0 49 57 0 9 67 101 108 108 0 53 0 55 0 9 67 101 108 108 0 54 0 49 0 10 67 101 108 108 0 54 0 49 52 0 9 67 101 108 108 0 54 0 50 0 10 67 101 108 108 0 54 0 50 48 0 9 67 101 108 108 0 54 0 52 0 9 67 101 108 108 0 54 0 54 0 9 67 101 108 108 0 55 0 49 0 10 67 101 108 108 0 55 0 49 48 0 10 67 101 108 108 0 55 0 49 52 0 10 67 101 108 108 0 55 0 49 57 0 10 67 101 108 108 0 55 0 50 48 0 9 67 101 108 108 0 55 0 52 0 9 67 101 108 108 0 55 0 53 0 10 67 101 108 108 0 56 0 49 49 0 10 67 101 108 108 0 56 0 49 57 0 10 67 101 108 108 0 56 0 50 49 0 9 67 101 108 108 0 56 0 53 0 9 67 101 108 108 0 56 0 54 0 9 67 101 108 108 0 56 0 57 0 10 67 101 108 108 0 57 0 49 50 0 10 67 101 108 108 0 57 0 49 55 0 10 67 101 108 108 0 57 0 49 57 0 10 67 101 108 108 0 57 0 50 51 0 9 67 101 108 108 0 57 0 51 0 9 67 101 108 108 0 57 0 52 0 9 67 101 108 108 0 57 0 53 0 9 67 101 108 108 0 57 0 55 0"));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[49]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("53 4 0 49 51 0 4 0 49 52 0 4 0 50 48 0 5 48 0 49 50 0 5 48 0 49 56 0 5 48 0 50 51 0 4 48 0 54 0 4 48 0 57 0 5 49 0 49 49 0 5 49 0 49 50 0 5 49 0 50 51 0 4 49 0 51 0 4 49 0 53 0 5 50 0 49 54 0 5 50 0 49 57 0 4 50 0 50 0 5 51 0 49 52 0 5 51 0 50 48 0 5 51 0 50 49 0 4 51 0 57 0 4 52 0 48 0 5 52 0 49 56 0 4 52 0 54 0 4 52 0 56 0 4 52 0 57 0 4 53 0 49 0 5 53 0 49 54 0 5 53 0 49 55 0 5 53 0 49 57 0 5 53 0 50 48 0 4 53 0 51 0 4 53 0 53 0 4 53 0 54 0 4 54 0 48 0 5 55 0 49 50 0 5 55 0 49 54 0 5 55 0 49 56 0 4 55 0 50 0 4 55 0 51 0 4 55 0 52 0 4 55 0 54 0 4 55 0 55 0 4 55 0 57 0 5 56 0 49 48 0 5 56 0 49 50 0 5 56 0 49 51 0 5 56 0 49 53 0 5 56 0 49 55 0 5 56 0 50 50 0 4 56 0 53 0 5 57 0 49 56 0 5 57 0 50 49 0 4 57 0 51 0"));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[50]));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("21 4 0 49 48 0 4 0 49 51 0 4 0 50 49 0 5 48 0 49 53 0 4 48 0 50 0 4 48 0 53 0 4 48 0 55 0 4 48 0 57 0 5 49 0 49 51 0 5 49 0 49 53 0 4 49 0 52 0 4 49 0 56 0 4 49 0 57 0 5 50 0 49 54 0 4 50 0 50 0 5 50 0 50 50 0 4 51 0 49 0 4 51 0 50 0 4 51 0 53 0 4 51 0 55 0 4 51 0 57 0"));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[51]));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 3 0 49 0 3 0 50 0 4 0 50 49 0 3 0 53 0 3 0 55 0"));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[52]));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 4 0 49 49 0 4 0 49 53 0 4 0 49 54 0 4 0 49 57 0 4 0 50 48 0 4 0 50 51 0 3 0 56 0"));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[53]));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 49 48 0 4 0 49 50 0 4 0 49 56 0 4 0 49 57 0 3 0 55 0"));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[54]));
static CONSTANT_15: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 3 0 49 0 4 0 49 52 0 3 0 50 0 4 0 50 48 0 3 0 52 0 3 0 54 0"));
static CONSTANT_16: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[55]));
static CONSTANT_17: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("7 3 0 49 0 4 0 49 48 0 4 0 49 52 0 4 0 49 57 0 4 0 50 48 0 3 0 52 0 3 0 53 0"));
static CONSTANT_18: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[56]));
static CONSTANT_19: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 0 49 49 0 4 0 49 57 0 4 0 50 49 0 3 0 53 0 3 0 54 0 3 0 57 0"));
static CONSTANT_20: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[57]));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 4 0 49 50 0 4 0 49 55 0 4 0 49 57 0 4 0 50 51 0 3 0 51 0 3 0 52 0 3 0 53 0 3 0 55 0"));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[67,101,108,108,0]));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("387 6 45 49 0 45 49 0 6 45 49 0 45 50 0 5 45 49 0 48 0 8 45 49 48 0 45 49 48 0 8 45 49 48 0 45 49 49 0 7 45 49 48 0 45 57 0 8 45 49 49 0 45 49 48 0 8 45 49 49 0 45 49 49 0 8 45 49 49 0 45 49 50 0 8 45 49 50 0 45 49 49 0 8 45 49 50 0 45 49 50 0 8 45 49 50 0 45 49 51 0 8 45 49 51 0 45 49 50 0 8 45 49 51 0 45 49 51 0 8 45 49 51 0 45 49 52 0 8 45 49 52 0 45 49 51 0 8 45 49 52 0 45 49 52 0 8 45 49 52 0 45 49 53 0 8 45 49 53 0 45 49 52 0 8 45 49 53 0 45 49 53 0 8 45 49 53 0 45 49 54 0 8 45 49 54 0 45 49 53 0 8 45 49 54 0 45 49 54 0 8 45 49 54 0 45 49 55 0 8 45 49 55 0 45 49 54 0 8 45 49 55 0 45 49 55 0 8 45 49 55 0 45 49 56 0 8 45 49 56 0 45 49 55 0 8 45 49 56 0 45 49 56 0 8 45 49 56 0 45 49 57 0 8 45 49 57 0 45 49 56 0 8 45 49 57 0 45 49 57 0 8 45 49 57 0 45 50 48 0 6 45 50 0 45 49 0 6 45 50 0 45 50 0 6 45 50 0 45 51 0 8 45 50 48 0 45 49 57 0 8 45 50 48 0 45 50 48 0 8 45 50 48 0 45 50 49 0 8 45 50 49 0 45 50 48 0 8 45 50 49 0 45 50 49 0 8 45 50 49 0 45 50 50 0 8 45 50 50 0 45 50 49 0 8 45 50 50 0 45 50 50 0 8 45 50 50 0 45 50 51 0 8 45 50 51 0 45 50 50 0 8 45 50 51 0 45 50 51 0 8 45 50 51 0 45 50 52 0 8 45 50 52 0 45 50 51 0 8 45 50 52 0 45 50 52 0 8 45 50 52 0 45 50 53 0 8 45 50 53 0 45 50 52 0 8 45 50 53 0 45 50 53 0 8 45 50 53 0 45 50 54 0 8 45 50 54 0 45 50 53 0 8 45 50 54 0 45 50 54 0 8 45 50 54 0 45 50 55 0 8 45 50 55 0 45 50 54 0 8 45 50 55 0 45 50 55 0 8 45 50 55 0 45 50 56 0 8 45 50 56 0 45 50 55 0 8 45 50 56 0 45 50 56 0 8 45 50 56 0 45 50 57 0 8 45 50 57 0 45 50 56 0 8 45 50 57 0 45 50 57 0 8 45 50 57 0 45 51 48 0 6 45 51 0 45 50 0 6 45 51 0 45 51 0 6 45 51 0 45 52 0 8 45 51 48 0 45 50 57 0 8 45 51 48 0 45 51 48 0 8 45 51 48 0 45 51 49 0 8 45 51 49 0 45 51 48 0 8 45 51 49 0 45 51 49 0 8 45 51 49 0 45 51 50 0 8 45 51 50 0 45 51 49 0 8 45 51 50 0 45 51 50 0 8 45 51 50 0 45 51 51 0 8 45 51 51 0 45 51 50 0 8 45 51 51 0 45 51 51 0 8 45 51 51 0 45 51 52 0 8 45 51 52 0 45 51 51 0 8 45 51 52 0 45 51 52 0 8 45 51 52 0 45 51 53 0 8 45 51 53 0 45 51 52 0 8 45 51 53 0 45 51 53 0 8 45 51 53 0 45 51 54 0 8 45 51 54 0 45 51 53 0 8 45 51 54 0 45 51 54 0 8 45 51 54 0 45 51 55 0 8 45 51 55 0 45 51 54 0 8 45 51 55 0 45 51 55 0 8 45 51 55 0 45 51 56 0 8 45 51 56 0 45 51 55 0 8 45 51 56 0 45 51 56 0 8 45 51 56 0 45 51 57 0 8 45 51 57 0 45 51 56 0 8 45 51 57 0 45 51 57 0 8 45 51 57 0 45 52 48 0 6 45 52 0 45 51 0 6 45 52 0 45 52 0 6 45 52 0 45 53 0 8 45 52 48 0 45 51 57 0 8 45 52 48 0 45 52 48 0 8 45 52 48 0 45 52 49 0 8 45 52 49 0 45 52 48 0 8 45 52 49 0 45 52 49 0 8 45 52 49 0 45 52 50 0 8 45 52 50 0 45 52 49 0 8 45 52 50 0 45 52 50 0 8 45 52 50 0 45 52 51 0 8 45 52 51 0 45 52 50 0 8 45 52 51 0 45 52 51 0 8 45 52 51 0 45 52 52 0 8 45 52 52 0 45 52 51 0 8 45 52 52 0 45 52 52 0 8 45 52 52 0 45 52 53 0 8 45 52 53 0 45 52 52 0 8 45 52 53 0 45 52 53 0 8 45 52 53 0 45 52 54 0 8 45 52 54 0 45 52 53 0 8 45 52 54 0 45 52 54 0 8 45 52 54 0 45 52 55 0 8 45 52 55 0 45 52 54 0 8 45 52 55 0 45 52 55 0 8 45 52 55 0 45 52 56 0 8 45 52 56 0 45 52 55 0 8 45 52 56 0 45 52 56 0 8 45 52 56 0 45 52 57 0 8 45 52 57 0 45 52 56 0 8 45 52 57 0 45 52 57 0 8 45 52 57 0 45 53 48 0 6 45 53 0 45 52 0 6 45 53 0 45 53 0 6 45 53 0 45 54 0 8 45 53 48 0 45 52 57 0 8 45 53 48 0 45 53 48 0 8 45 53 48 0 45 53 49 0 8 45 53 49 0 45 53 48 0 8 45 53 49 0 45 53 49 0 8 45 53 49 0 45 53 50 0 8 45 53 50 0 45 53 49 0 8 45 53 50 0 45 53 50 0 8 45 53 50 0 45 53 51 0 8 45 53 51 0 45 53 50 0 8 45 53 51 0 45 53 51 0 8 45 53 51 0 45 53 52 0 8 45 53 52 0 45 53 51 0 8 45 53 52 0 45 53 52 0 8 45 53 52 0 45 53 53 0 8 45 53 53 0 45 53 52 0 8 45 53 53 0 45 53 53 0 8 45 53 53 0 45 53 54 0 8 45 53 54 0 45 53 53 0 8 45 53 54 0 45 53 54 0 8 45 53 54 0 45 53 55 0 8 45 53 55 0 45 53 54 0 8 45 53 55 0 45 53 55 0 8 45 53 55 0 45 53 56 0 8 45 53 56 0 45 53 55 0 8 45 53 56 0 45 53 56 0 8 45 53 56 0 45 53 57 0 8 45 53 57 0 45 53 56 0 8 45 53 57 0 45 53 57 0 8 45 53 57 0 45 54 48 0 6 45 54 0 45 53 0 6 45 54 0 45 54 0 6 45 54 0 45 55 0 8 45 54 48 0 45 53 57 0 8 45 54 48 0 45 54 48 0 8 45 54 48 0 45 54 49 0 8 45 54 49 0 45 54 48 0 8 45 54 49 0 45 54 49 0 8 45 54 49 0 45 54 50 0 8 45 54 50 0 45 54 49 0 8 45 54 50 0 45 54 50 0 8 45 54 50 0 45 54 51 0 8 45 54 51 0 45 54 50 0 8 45 54 51 0 45 54 51 0 8 45 54 51 0 45 54 52 0 8 45 54 52 0 45 54 51 0 8 45 54 52 0 45 54 52 0 8 45 54 52 0 45 54 53 0 6 45 55 0 45 54 0 6 45 55 0 45 55 0 6 45 55 0 45 56 0 6 45 56 0 45 55 0 6 45 56 0 45 56 0 6 45 56 0 45 57 0 7 45 57 0 45 49 48 0 6 45 57 0 45 56 0 6 45 57 0 45 57 0 5 48 0 45 49 0 4 48 0 48 0 4 48 0 49 0 4 49 0 48 0 4 49 0 49 0 4 49 0 50 0 6 49 48 0 49 48 0 6 49 48 0 49 49 0 5 49 48 0 57 0 6 49 49 0 49 48 0 6 49 49 0 49 49 0 6 49 49 0 49 50 0 6 49 50 0 49 49 0 6 49 50 0 49 50 0 6 49 50 0 49 51 0 6 49 51 0 49 50 0 6 49 51 0 49 51 0 6 49 51 0 49 52 0 6 49 52 0 49 51 0 6 49 52 0 49 52 0 6 49 52 0 49 53 0 6 49 53 0 49 52 0 6 49 53 0 49 53 0 6 49 53 0 49 54 0 6 49 54 0 49 53 0 6 49 54 0 49 54 0 6 49 54 0 49 55 0 6 49 55 0 49 54 0 6 49 55 0 49 55 0 6 49 55 0 49 56 0 6 49 56 0 49 55 0 6 49 56 0 49 56 0 6 49 56 0 49 57 0 6 49 57 0 49 56 0 6 49 57 0 49 57 0 6 49 57 0 50 48 0 4 50 0 49 0 4 50 0 50 0 4 50 0 51 0 6 50 48 0 49 57 0 6 50 48 0 50 48 0 6 50 48 0 50 49 0 6 50 49 0 50 48 0 6 50 49 0 50 49 0 6 50 49 0 50 50 0 6 50 50 0 50 49 0 6 50 50 0 50 50 0 6 50 50 0 50 51 0 6 50 51 0 50 50 0 6 50 51 0 50 51 0 6 50 51 0 50 52 0 6 50 52 0 50 51 0 6 50 52 0 50 52 0 6 50 52 0 50 53 0 6 50 53 0 50 52 0 6 50 53 0 50 53 0 6 50 53 0 50 54 0 6 50 54 0 50 53 0 6 50 54 0 50 54 0 6 50 54 0 50 55 0 6 50 55 0 50 54 0 6 50 55 0 50 55 0 6 50 55 0 50 56 0 6 50 56 0 50 55 0 6 50 56 0 50 56 0 6 50 56 0 50 57 0 6 50 57 0 50 56 0 6 50 57 0 50 57 0 6 50 57 0 51 48 0 4 51 0 50 0 4 51 0 51 0 4 51 0 52 0 6 51 48 0 50 57 0 6 51 48 0 51 48 0 6 51 48 0 51 49 0 6 51 49 0 51 48 0 6 51 49 0 51 49 0 6 51 49 0 51 50 0 6 51 50 0 51 49 0 6 51 50 0 51 50 0 6 51 50 0 51 51 0 6 51 51 0 51 50 0 6 51 51 0 51 51 0 6 51 51 0 51 52 0 6 51 52 0 51 51 0 6 51 52 0 51 52 0 6 51 52 0 51 53 0 6 51 53 0 51 52 0 6 51 53 0 51 53 0 6 51 53 0 51 54 0 6 51 54 0 51 53 0 6 51 54 0 51 54 0 6 51 54 0 51 55 0 6 51 55 0 51 54 0 6 51 55 0 51 55 0 6 51 55 0 51 56 0 6 51 56 0 51 55 0 6 51 56 0 51 56 0 6 51 56 0 51 57 0 6 51 57 0 51 56 0 6 51 57 0 51 57 0 6 51 57 0 52 48 0 4 52 0 51 0 4 52 0 52 0 4 52 0 53 0 6 52 48 0 51 57 0 6 52 48 0 52 48 0 6 52 48 0 52 49 0 6 52 49 0 52 48 0 6 52 49 0 52 49 0 6 52 49 0 52 50 0 6 52 50 0 52 49 0 6 52 50 0 52 50 0 6 52 50 0 52 51 0 6 52 51 0 52 50 0 6 52 51 0 52 51 0 6 52 51 0 52 52 0 6 52 52 0 52 51 0 6 52 52 0 52 52 0 6 52 52 0 52 53 0 6 52 53 0 52 52 0 6 52 53 0 52 53 0 6 52 53 0 52 54 0 6 52 54 0 52 53 0 6 52 54 0 52 54 0 6 52 54 0 52 55 0 6 52 55 0 52 54 0 6 52 55 0 52 55 0 6 52 55 0 52 56 0 6 52 56 0 52 55 0 6 52 56 0 52 56 0 6 52 56 0 52 57 0 6 52 57 0 52 56 0 6 52 57 0 52 57 0 6 52 57 0 53 48 0 4 53 0 52 0 4 53 0 53 0 4 53 0 54 0 6 53 48 0 52 57 0 6 53 48 0 53 48 0 6 53 48 0 53 49 0 6 53 49 0 53 48 0 6 53 49 0 53 49 0 6 53 49 0 53 50 0 6 53 50 0 53 49 0 6 53 50 0 53 50 0 6 53 50 0 53 51 0 6 53 51 0 53 50 0 6 53 51 0 53 51 0 6 53 51 0 53 52 0 6 53 52 0 53 51 0 6 53 52 0 53 52 0 6 53 52 0 53 53 0 6 53 53 0 53 52 0 6 53 53 0 53 53 0 6 53 53 0 53 54 0 6 53 54 0 53 53 0 6 53 54 0 53 54 0 6 53 54 0 53 55 0 6 53 55 0 53 54 0 6 53 55 0 53 55 0 6 53 55 0 53 56 0 6 53 56 0 53 55 0 6 53 56 0 53 56 0 6 53 56 0 53 57 0 6 53 57 0 53 56 0 6 53 57 0 53 57 0 6 53 57 0 54 48 0 4 54 0 53 0 4 54 0 54 0 4 54 0 55 0 6 54 48 0 53 57 0 6 54 48 0 54 48 0 6 54 48 0 54 49 0 6 54 49 0 54 48 0 6 54 49 0 54 49 0 6 54 49 0 54 50 0 6 54 50 0 54 49 0 6 54 50 0 54 50 0 6 54 50 0 54 51 0 6 54 51 0 54 50 0 6 54 51 0 54 51 0 6 54 51 0 54 52 0 6 54 52 0 54 51 0 6 54 52 0 54 52 0 6 54 52 0 54 53 0 4 55 0 54 0 4 55 0 55 0 4 55 0 56 0 4 56 0 55 0 4 56 0 56 0 4 56 0 57 0 5 57 0 49 48 0 4 57 0 56 0 4 57 0 57 0"));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 104 105 116 0"));
fn routine_0(c: &mut Context) -> Space {
  let v0_50: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v1_4: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2), &(*CONSTANT_3));
    let v1_8: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_5), &(*CONSTANT_3));
    let v1_9: Space = unite(&(v1_4),&(v1_8));
    let v1_13: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_7), &(*CONSTANT_3));
    let v1_14: Space = unite(&(v1_9),&(v1_13));
    let v1_18: Space = routine_1(c, &(*CONSTANT_8), &(*CONSTANT_9), &(*CONSTANT_3));
    let v1_19: Space = unite(&(v1_14),&(v1_18));
    let v1_23: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_11), &(*CONSTANT_3));
    let v1_24: Space = unite(&(v1_19),&(v1_23));
    let v1_28: Space = routine_1(c, &(*CONSTANT_12), &(*CONSTANT_13), &(*CONSTANT_3));
    let v1_29: Space = unite(&(v1_24),&(v1_28));
    let v1_33: Space = routine_1(c, &(*CONSTANT_14), &(*CONSTANT_15), &(*CONSTANT_3));
    let v1_34: Space = unite(&(v1_29),&(v1_33));
    let v1_38: Space = routine_1(c, &(*CONSTANT_16), &(*CONSTANT_17), &(*CONSTANT_3));
    let v1_39: Space = unite(&(v1_34),&(v1_38));
    let v1_43: Space = routine_1(c, &(*CONSTANT_18), &(*CONSTANT_19), &(*CONSTANT_3));
    let v1_44: Space = unite(&(v1_39),&(v1_43));
    let v1_48: Space = routine_1(c, &(*CONSTANT_20), &(*CONSTANT_21), &(*CONSTANT_3));
    let v1_49: Space = unite(&(v1_44),&(v1_48));
    compose(&(*CONSTANT_0),&(v1_49))
  };
  let v0_81: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v2_53: Space = routine_2(c, &(*CONSTANT_1), &(*CONSTANT_2));
    let v2_55: Space = routine_2(c, &(*CONSTANT_4), &(*CONSTANT_5));
    let v2_56: Space = unite(&(v2_53),&(v2_55));
    let v2_58: Space = routine_2(c, &(*CONSTANT_6), &(*CONSTANT_7));
    let v2_59: Space = unite(&(v2_56),&(v2_58));
    let v2_61: Space = routine_2(c, &(*CONSTANT_8), &(*CONSTANT_9));
    let v2_62: Space = unite(&(v2_59),&(v2_61));
    let v2_64: Space = routine_2(c, &(*CONSTANT_10), &(*CONSTANT_11));
    let v2_65: Space = unite(&(v2_62),&(v2_64));
    let v2_67: Space = routine_2(c, &(*CONSTANT_12), &(*CONSTANT_13));
    let v2_68: Space = unite(&(v2_65),&(v2_67));
    let v2_70: Space = routine_2(c, &(*CONSTANT_14), &(*CONSTANT_15));
    let v2_71: Space = unite(&(v2_68),&(v2_70));
    let v2_73: Space = routine_2(c, &(*CONSTANT_16), &(*CONSTANT_17));
    let v2_74: Space = unite(&(v2_71),&(v2_73));
    let v2_76: Space = routine_2(c, &(*CONSTANT_18), &(*CONSTANT_19));
    let v2_77: Space = unite(&(v2_74),&(v2_76));
    let v2_79: Space = routine_2(c, &(*CONSTANT_20), &(*CONSTANT_21));
    let v2_80: Space = unite(&(v2_77),&(v2_79));
    compose(&(*CONSTANT_0),&(v2_80))
  };
  let mut v0_87 = Space::new();
  let mut v0_87_cursor = (v0_81).read_zipper();
  for v0_87_byte in v0_87_cursor.child_mask().iter() {
    v0_87_cursor.descend_to_byte(v0_87_byte);
    {
    let v0_87_tail = v0_87_cursor.fork_read_zipper();
    let v0_87_head = Path::from_slice(&[v0_87_byte]);
    let v3_2: Space = singleton(&(v0_87_head));
    let v3_3: Space = intersect(&(*CONSTANT_22),&(v3_2));
    let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
    drop(v3_3);
    let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
    drop(v3_4);
    let v3_7: Space = if (v3_5).is_empty() { Space::new() } else {
      let v4_6: Space = routine_3(c, &(v0_87_head), &(v0_87_tail).make_space(), &(*CONSTANT_3));
      compose(&(v3_5),&(v4_6))
    };
    drop(v3_5);
    let v3_8: Space = intersect(&(*CONSTANT_22),&(v3_2));
    drop(v3_2);
    let v3_9: Space = if has_head(&(v3_8)) { singleton(&[]) } else { Space::new() };
    drop(v3_8);
    let v3_11: Space = if (v3_9).is_empty() { Space::new() } else {
      let v5_10: Space = routine_4(c, &(v0_87_head), &(v0_87_tail).make_space(), &(*CONSTANT_3));
      compose(&(v3_9),&(v5_10))
    };
    drop(v3_9);
    let v3_12: Space = unite(&(v3_7),&(v3_11));
    v0_87.join_into((v3_12).clone());
    }
    v0_87_cursor.ascend(1);
  }
  drop(v0_87_cursor);
  let v0_88: Space = unite(&(v0_50),&(v0_87));
  let v0_90: Space = wrap(&(v0_88),&(*CONSTANT_23));
  (v0_90).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v6_9 = Space::new();
  let mut v6_9_cursor = (*s0).read_zipper();
  for v6_9_byte in v6_9_cursor.child_mask().iter() {
    v6_9_cursor.descend_to_byte(v6_9_byte);
    {
    let v6_9_tail = v6_9_cursor.fork_read_zipper();
    let v6_9_head = Path::from_slice(&[v6_9_byte]);
    let v7_2: Space = singleton(&(v6_9_head));
    let v7_3: Space = intersect(&(*CONSTANT_22),&(v7_2));
    let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
    drop(v7_3);
    let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
    drop(v7_4);
    let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
      let v8_6: Path = concat_path(&(*p0),&(v6_9_head));
      let v8_7: Space = routine_1(c, &(v8_6), &(v6_9_tail).make_space(), &(*s1));
      compose(&(v7_5),&(v8_7))
    };
    drop(v7_5);
    let v7_9: Space = intersect(&(*CONSTANT_22),&(v7_2));
    drop(v7_2);
    let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
    drop(v7_9);
    let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
      let v9_6: Path = concat_path(&(*p0),&(v6_9_head));
      let mut v9_11 = Space::new();
      let mut v9_11_cursor = (v6_9_tail).read_zipper();
      for v9_11_byte in v9_11_cursor.child_mask().iter() {
        v9_11_cursor.descend_to_byte(v9_11_byte);
        {
        let v9_11_tail = v9_11_cursor.fork_read_zipper();
        let v9_11_head = Path::from_slice(&[v9_11_byte]);
        let v10_2: Space = singleton(&(v9_11_head));
        let v10_3: Space = intersect(&(*CONSTANT_22),&(v10_2));
        let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
        drop(v10_3);
        let v10_5: Space = subtract(&(*CONSTANT_0),&(v10_4));
        drop(v10_4);
        let v10_7: Space = if (v10_5).is_empty() { Space::new() } else {
          let v11_6: Space = routine_5(c, &(v9_11_head), &(v9_6), &(v9_11_tail).make_space(), &(*s1));
          compose(&(v10_5),&(v11_6))
        };
        drop(v10_5);
        let v10_8: Space = intersect(&(*CONSTANT_22),&(v10_2));
        drop(v10_2);
        let v10_9: Space = if has_head(&(v10_8)) { singleton(&[]) } else { Space::new() };
        drop(v10_8);
        let v10_11: Space = if (v10_9).is_empty() { Space::new() } else {
          let v12_10: Space = routine_6(c, &(v9_11_head), &(v9_6), &(v9_11_tail).make_space(), &(*s1));
          compose(&(v10_9),&(v12_10))
        };
        drop(v10_9);
        let v10_12: Space = unite(&(v10_7),&(v10_11));
        v9_11.join_into((v10_12).clone());
        }
        v9_11_cursor.ascend(1);
      }
      drop(v9_11_cursor);
      drop(v9_6);
      compose(&(v7_10),&(v9_11))
    };
    drop(v7_10);
    let v7_13: Space = unite(&(v7_8),&(v7_12));
    v6_9.join_into((v7_13).clone());
    }
    v6_9_cursor.ascend(1);
  }
  drop(v6_9_cursor);
  (v6_9).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v13_10: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let mut v13_11 = Space::new();
  let mut v13_11_cursor = (*s0).read_zipper();
  for v13_11_byte in v13_11_cursor.child_mask().iter() {
    v13_11_cursor.descend_to_byte(v13_11_byte);
    {
    let v13_11_tail = v13_11_cursor.fork_read_zipper();
    let v13_11_head = Path::from_slice(&[v13_11_byte]);
    let v14_2: Space = singleton(&(v13_11_head));
    let v14_3: Space = intersect(&(*CONSTANT_22),&(v14_2));
    let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
    drop(v14_3);
    let v14_5: Space = subtract(&(*CONSTANT_0),&(v14_4));
    drop(v14_4);
    let v14_8: Space = if (v14_5).is_empty() { Space::new() } else {
      let v15_6: Path = concat_path(&(*p0),&(v13_11_head));
      let v15_7: Space = routine_2(c, &(v15_6), &(v13_11_tail).make_space());
      compose(&(v14_5),&(v15_7))
    };
    drop(v14_5);
    let v14_9: Space = intersect(&(*CONSTANT_22),&(v14_2));
    drop(v14_2);
    let v14_10: Space = if has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
    drop(v14_9);
    let v14_13: Space = if (v14_10).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v13_11_head));
      let v16_11: Space = unwrap(&(v13_10),&(v13_11_head));
      let mut v16_12 = Space::new();
      let mut v16_12_cursor = (v13_11_tail).read_zipper();
      for v16_12_byte in v16_12_cursor.child_mask().iter() {
        v16_12_cursor.descend_to_byte(v16_12_byte);
        {
        let v16_12_tail = v16_12_cursor.fork_read_zipper();
        let v16_12_head = Path::from_slice(&[v16_12_byte]);
        let v17_2: Space = singleton(&(v16_12_head));
        let v17_3: Space = intersect(&(*CONSTANT_22),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
        drop(v17_4);
        let v17_7: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Space = routine_7(c, &(v16_12_head), &(v16_6), &(v16_12_tail).make_space());
          compose(&(v17_5),&(v18_6))
        };
        drop(v17_5);
        let v17_8: Space = intersect(&(*CONSTANT_22),&(v17_2));
        drop(v17_2);
        let v17_9: Space = if has_head(&(v17_8)) { singleton(&[]) } else { Space::new() };
        drop(v17_8);
        let v17_15: Space = if (v17_9).is_empty() { Space::new() } else {
          let v19_10: Space = unwrap(&(*CONSTANT_24),&(v16_12_head));
          let v19_11: Space = compose(&(v16_11),&(v19_10));
          drop(v19_10);
          let v19_12: Path = concat_path(&(v16_6),&(v16_12_head));
          let v19_13: Space = singleton(&(v19_12));
          drop(v19_12);
          let v19_14: Space = subtract(&(v19_11),&(v19_13));
          drop(v19_11);
          drop(v19_13);
          compose(&(v17_9),&(v19_14))
        };
        drop(v17_9);
        let v17_16: Space = unite(&(v17_7),&(v17_15));
        drop(v17_15);
        v16_12.join_into((v17_16).clone());
        }
        v16_12_cursor.ascend(1);
      }
      drop(v16_12_cursor);
      drop(v16_6);
      drop(v16_11);
      compose(&(v14_10),&(v16_12))
    };
    drop(v14_10);
    let v14_14: Space = unite(&(v14_8),&(v14_13));
    v13_11.join_into((v14_14).clone());
    }
    v13_11_cursor.ascend(1);
  }
  drop(v13_11_cursor);
  drop(v13_10);
  (v13_11).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v20_9 = Space::new();
  let mut v20_9_cursor = (*s0).read_zipper();
  for v20_9_byte in v20_9_cursor.child_mask().iter() {
    v20_9_cursor.descend_to_byte(v20_9_byte);
    {
    let v20_9_tail = v20_9_cursor.fork_read_zipper();
    let v20_9_head = Path::from_slice(&[v20_9_byte]);
    let v21_2: Space = singleton(&(v20_9_head));
    let v21_3: Space = intersect(&(*CONSTANT_22),&(v21_2));
    let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
    drop(v21_3);
    let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
    drop(v21_4);
    let v21_8: Space = if (v21_5).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&(v20_9_head));
      let v22_7: Space = routine_3(c, &(v22_6), &(v20_9_tail).make_space(), &(*s1));
      compose(&(v21_5),&(v22_7))
    };
    drop(v21_5);
    let v21_9: Space = intersect(&(*CONSTANT_22),&(v21_2));
    drop(v21_2);
    let v21_10: Space = if has_head(&(v21_9)) { singleton(&[]) } else { Space::new() };
    drop(v21_9);
    let v21_12: Space = if (v21_10).is_empty() { Space::new() } else {
      let v23_6: Path = concat_path(&(*p0),&(v20_9_head));
      let mut v23_11 = Space::new();
      let mut v23_11_cursor = (v20_9_tail).read_zipper();
      for v23_11_byte in v23_11_cursor.child_mask().iter() {
        v23_11_cursor.descend_to_byte(v23_11_byte);
        {
        let v23_11_tail = v23_11_cursor.fork_read_zipper();
        let v23_11_head = Path::from_slice(&[v23_11_byte]);
        let v24_2: Space = singleton(&(v23_11_head));
        let v24_3: Space = intersect(&(*CONSTANT_22),&(v24_2));
        let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
        drop(v24_3);
        let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
        drop(v24_4);
        let v24_7: Space = if (v24_5).is_empty() { Space::new() } else {
          let v25_6: Space = routine_8(c, &(v23_11_head), &(v23_6), &(v23_11_tail).make_space(), &(*s1));
          compose(&(v24_5),&(v25_6))
        };
        drop(v24_5);
        let v24_8: Space = intersect(&(*CONSTANT_22),&(v24_2));
        drop(v24_2);
        let v24_9: Space = if has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
        drop(v24_8);
        let v24_11: Space = if (v24_9).is_empty() { Space::new() } else {
          let v26_10: Space = routine_9(c, &(v23_11_head), &(v23_6), &(v23_11_tail).make_space(), &(*s1));
          compose(&(v24_9),&(v26_10))
        };
        drop(v24_9);
        let v24_12: Space = unite(&(v24_7),&(v24_11));
        v23_11.join_into((v24_12).clone());
        }
        v23_11_cursor.ascend(1);
      }
      drop(v23_11_cursor);
      drop(v23_6);
      compose(&(v21_10),&(v23_11))
    };
    drop(v21_10);
    let v21_13: Space = unite(&(v21_8),&(v21_12));
    v20_9.join_into((v21_13).clone());
    }
    v20_9_cursor.ascend(1);
  }
  drop(v20_9_cursor);
  (v20_9).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v27_7: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let v27_10: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v27_12: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let mut v27_28 = Space::new();
  let mut v27_28_cursor = (*s0).read_zipper();
  for v27_28_byte in v27_28_cursor.child_mask().iter() {
    v27_28_cursor.descend_to_byte(v27_28_byte);
    {
    let v27_28_tail = v27_28_cursor.fork_read_zipper();
    let v27_28_head = Path::from_slice(&[v27_28_byte]);
    let v28_2: Space = singleton(&(v27_28_head));
    let v28_3: Space = intersect(&(*CONSTANT_22),&(v28_2));
    let v28_4: Space = if has_head(&(v28_3)) { singleton(&[]) } else { Space::new() };
    drop(v28_3);
    let v28_5: Space = subtract(&(*CONSTANT_0),&(v28_4));
    drop(v28_4);
    let v28_7: Space = if (v28_5).is_empty() { Space::new() } else {
      let mut v29_6 = Space::new();
      let mut v29_6_cursor = (v27_28_tail).read_zipper();
      for v29_6_byte in v29_6_cursor.child_mask().iter() {
        v29_6_cursor.descend_to_byte(v29_6_byte);
        {
        let v29_6_tail = v29_6_cursor.fork_read_zipper();
        let v29_6_head = Path::from_slice(&[v29_6_byte]);
        let v30_2: Space = singleton(&(v29_6_head));
        let v30_3: Space = intersect(&(*CONSTANT_22),&(v30_2));
        let v30_4: Space = if has_head(&(v30_3)) { singleton(&[]) } else { Space::new() };
        drop(v30_3);
        let v30_5: Space = subtract(&(*CONSTANT_0),&(v30_4));
        drop(v30_4);
        let v30_8: Space = if (v30_5).is_empty() { Space::new() } else {
          let v31_6: Path = concat_path(&(v27_28_head),&(v29_6_head));
          let v31_7: Space = routine_8(c, &(v31_6), &(*p0), &(v29_6_tail).make_space(), &(*s1));
          compose(&(v30_5),&(v31_7))
        };
        drop(v30_5);
        let v30_9: Space = intersect(&(*CONSTANT_22),&(v30_2));
        drop(v30_2);
        let v30_10: Space = if has_head(&(v30_9)) { singleton(&[]) } else { Space::new() };
        drop(v30_9);
        let v30_12: Space = if (v30_10).is_empty() { Space::new() } else {
          let v32_6: Path = concat_path(&(v27_28_head),&(v29_6_head));
          let v32_11: Space = routine_9(c, &(v32_6), &(*p0), &(v29_6_tail).make_space(), &(*s1));
          drop(v32_6);
          compose(&(v30_10),&(v32_11))
        };
        drop(v30_10);
        let v30_13: Space = unite(&(v30_8),&(v30_12));
        v29_6.join_into((v30_13).clone());
        }
        v29_6_cursor.ascend(1);
      }
      drop(v29_6_cursor);
      compose(&(v28_5),&(v29_6))
    };
    drop(v28_5);
    let v28_8: Space = intersect(&(*CONSTANT_22),&(v28_2));
    drop(v28_2);
    let v28_9: Space = if has_head(&(v28_8)) { singleton(&[]) } else { Space::new() };
    drop(v28_8);
    let v28_27: Space = if (v28_9).is_empty() { Space::new() } else {
      let v33_10: Space = unwrap(&(*CONSTANT_24),&(v27_28_head));
      let v33_11: Space = compose(&(v27_7),&(v33_10));
      drop(v33_10);
      let v33_12: Path = concat_path(&(*p0),&(v27_28_head));
      let v33_13: Space = singleton(&(v33_12));
      drop(v33_12);
      let v33_14: Space = subtract(&(v33_11),&(v33_13));
      drop(v33_11);
      let v33_15: Space = intersect(&(v33_14),&(v27_10));
      drop(v33_14);
      let v33_16: Space = range_const::<{3},{4}>(&(v33_15));
      drop(v33_15);
      let mut v33_17 = Space::new();
      let mut v33_17_cursor = (v33_16).read_zipper();
      for v33_17_byte in v33_17_cursor.child_mask().iter() {
        v33_17_cursor.descend_to_byte(v33_17_byte);
        {
        let v33_17_tail = v33_17_cursor.fork_read_zipper();
        let v33_17_head = Path::from_slice(&[v33_17_byte]);
        let v34_2: Space = singleton(&(v33_17_head));
        let v34_3: Space = intersect(&(*CONSTANT_22),&(v34_2));
        let v34_4: Space = if has_head(&(v34_3)) { singleton(&[]) } else { Space::new() };
        drop(v34_3);
        let v34_5: Space = subtract(&(*CONSTANT_0),&(v34_4));
        drop(v34_4);
        let v34_7: Space = if (v34_5).is_empty() { Space::new() } else {
          let v35_6: Space = routine_10(c, &(v33_17_head), &(v33_17_tail).make_space());
          compose(&(v34_5),&(v35_6))
        };
        drop(v34_5);
        let v34_8: Space = intersect(&(*CONSTANT_22),&(v34_2));
        drop(v34_2);
        let v34_9: Space = if has_head(&(v34_8)) { singleton(&[]) } else { Space::new() };
        drop(v34_8);
        let v34_10: Space = compose(&(v34_9),&(*CONSTANT_25));
        drop(v34_9);
        let v34_11: Space = unite(&(v34_7),&(v34_10));
        drop(v34_10);
        v33_17.join_into((v34_11).clone());
        }
        v33_17_cursor.ascend(1);
      }
      drop(v33_17_cursor);
      drop(v33_16);
      let v33_18: Space = unwrap(&(*CONSTANT_24),&(v27_28_head));
      let v33_19: Space = compose(&(v27_12),&(v33_18));
      drop(v33_18);
      let v33_20: Space = subtract(&(v33_19),&(v33_13));
      drop(v33_19);
      let v33_21: Space = intersect(&(v33_20),&(v27_10));
      drop(v33_20);
      let v33_22: Space = range_const::<{4},{5}>(&(v33_21));
      drop(v33_21);
      let mut v33_23 = Space::new();
      let mut v33_23_cursor = (v33_22).read_zipper();
      for v33_23_byte in v33_23_cursor.child_mask().iter() {
        v33_23_cursor.descend_to_byte(v33_23_byte);
        {
        let v33_23_tail = v33_23_cursor.fork_read_zipper();
        let v33_23_head = Path::from_slice(&[v33_23_byte]);
        let v36_2: Space = singleton(&(v33_23_head));
        let v36_3: Space = intersect(&(*CONSTANT_22),&(v36_2));
        let v36_4: Space = if has_head(&(v36_3)) { singleton(&[]) } else { Space::new() };
        drop(v36_3);
        let v36_5: Space = subtract(&(*CONSTANT_0),&(v36_4));
        drop(v36_4);
        let v36_7: Space = if (v36_5).is_empty() { Space::new() } else {
          let v37_6: Space = routine_11(c, &(v33_23_head), &(v33_23_tail).make_space());
          compose(&(v36_5),&(v37_6))
        };
        drop(v36_5);
        let v36_8: Space = intersect(&(*CONSTANT_22),&(v36_2));
        drop(v36_2);
        let v36_9: Space = if has_head(&(v36_8)) { singleton(&[]) } else { Space::new() };
        drop(v36_8);
        let v36_10: Space = compose(&(v36_9),&(*CONSTANT_25));
        drop(v36_9);
        let v36_11: Space = unite(&(v36_7),&(v36_10));
        drop(v36_10);
        v33_23.join_into((v36_11).clone());
        }
        v33_23_cursor.ascend(1);
      }
      drop(v33_23_cursor);
      drop(v33_22);
      let v33_24: Space = subtract(&(v33_17),&(v33_23));
      let v33_25: Space = if (v33_24).is_empty() { Space::new() } else {
        compose(&(v33_24),&(v33_13))
      };
      drop(v33_13);
      let mut v33_26 = Space::new();
      let mut v33_26_cursor = (v33_25).read_zipper();
      for v33_26_byte in v33_26_cursor.child_mask().iter() {
        v33_26_cursor.descend_to_byte(v33_26_byte);
        {
        let v33_26_tail = v33_26_cursor.fork_read_zipper();
        let v33_26_head = Path::from_slice(&[v33_26_byte]);
        let v39_2: Space = singleton(&(v33_26_head));
        let v39_3: Space = intersect(&(*CONSTANT_22),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_7: Space = if (v39_5).is_empty() { Space::new() } else {
          let v40_6: Space = routine_12(c, &(v33_26_head), &(v33_26_tail).make_space());
          compose(&(v39_5),&(v40_6))
        };
        drop(v39_5);
        let v39_8: Space = intersect(&(*CONSTANT_22),&(v39_2));
        drop(v39_2);
        let v39_9: Space = if has_head(&(v39_8)) { singleton(&[]) } else { Space::new() };
        drop(v39_8);
        let v39_10: Space = compose(&(v39_9),&(v33_26_tail));
        drop(v39_9);
        let v39_11: Space = unite(&(v39_7),&(v39_10));
        drop(v39_10);
        v33_26.join_into((v39_11).clone());
        }
        v33_26_cursor.ascend(1);
      }
      drop(v33_26_cursor);
      compose(&(v28_9),&(v33_26))
    };
    drop(v28_9);
    let v28_28: Space = unite(&(v28_7),&(v28_27));
    v27_28.join_into((v28_28).clone());
    }
    v27_28_cursor.ascend(1);
  }
  drop(v27_28_cursor);
  drop(v27_7);
  drop(v27_10);
  drop(v27_12);
  (v27_28).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v41_8: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v41_10: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let v41_12: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v41_14: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v41_16: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let mut v41_28 = Space::new();
  let mut v41_28_cursor = (*s0).read_zipper();
  for v41_28_byte in v41_28_cursor.child_mask().iter() {
    v41_28_cursor.descend_to_byte(v41_28_byte);
    {
    let v41_28_tail = v41_28_cursor.fork_read_zipper();
    let v41_28_head = Path::from_slice(&[v41_28_byte]);
    let v42_2: Space = singleton(&(v41_28_head));
    let v42_3: Space = intersect(&(*CONSTANT_22),&(v42_2));
    let v42_4: Space = if has_head(&(v42_3)) { singleton(&[]) } else { Space::new() };
    drop(v42_3);
    let v42_5: Space = subtract(&(*CONSTANT_0),&(v42_4));
    drop(v42_4);
    let v42_8: Space = if (v42_5).is_empty() { Space::new() } else {
      let v43_6: Path = concat_path(&(*p0),&(v41_28_head));
      let v43_7: Space = routine_5(c, &(v43_6), &(*p1), &(v41_28_tail).make_space(), &(*s1));
      compose(&(v42_5),&(v43_7))
    };
    drop(v42_5);
    let v42_9: Space = intersect(&(*CONSTANT_22),&(v42_2));
    drop(v42_2);
    let v42_10: Space = if has_head(&(v42_9)) { singleton(&[]) } else { Space::new() };
    drop(v42_9);
    let v42_28: Space = if (v42_10).is_empty() { Space::new() } else {
      let v44_6: Path = concat_path(&(*p0),&(v41_28_head));
      let v44_12: Space = if (v41_8).is_empty() { Space::new() } else {
        let v45_11: Space = unwrap(&(v41_10),&(v41_28_head));
        compose(&(v41_8),&(v45_11))
      };
      let v44_13: Path = concat_path(&(*p1),&(v44_6));
      drop(v44_6);
      let v44_14: Space = singleton(&(v44_13));
      drop(v44_13);
      let v44_15: Space = subtract(&(v44_12),&(v44_14));
      drop(v44_12);
      let v44_16: Space = intersect(&(v44_15),&(v41_12));
      drop(v44_15);
      let v44_17: Space = range_const::<{2},{3}>(&(v44_16));
      drop(v44_16);
      let mut v44_18 = Space::new();
      let mut v44_18_cursor = (v44_17).read_zipper();
      for v44_18_byte in v44_18_cursor.child_mask().iter() {
        v44_18_cursor.descend_to_byte(v44_18_byte);
        {
        let v44_18_tail = v44_18_cursor.fork_read_zipper();
        let v44_18_head = Path::from_slice(&[v44_18_byte]);
        let v46_2: Space = singleton(&(v44_18_head));
        let v46_3: Space = intersect(&(*CONSTANT_22),&(v46_2));
        let v46_4: Space = if has_head(&(v46_3)) { singleton(&[]) } else { Space::new() };
        drop(v46_3);
        let v46_5: Space = subtract(&(*CONSTANT_0),&(v46_4));
        drop(v46_4);
        let v46_7: Space = if (v46_5).is_empty() { Space::new() } else {
          let v47_6: Space = routine_13(c, &(v44_18_head), &(v44_18_tail).make_space());
          compose(&(v46_5),&(v47_6))
        };
        drop(v46_5);
        let v46_8: Space = intersect(&(*CONSTANT_22),&(v46_2));
        drop(v46_2);
        let v46_9: Space = if has_head(&(v46_8)) { singleton(&[]) } else { Space::new() };
        drop(v46_8);
        let v46_10: Space = compose(&(v46_9),&(*CONSTANT_25));
        drop(v46_9);
        let v46_11: Space = unite(&(v46_7),&(v46_10));
        drop(v46_10);
        v44_18.join_into((v46_11).clone());
        }
        v44_18_cursor.ascend(1);
      }
      drop(v44_18_cursor);
      drop(v44_17);
      let v44_20: Space = if (v41_14).is_empty() { Space::new() } else {
        let v48_19: Space = unwrap(&(v41_16),&(v41_28_head));
        compose(&(v41_14),&(v48_19))
      };
      let v44_21: Space = subtract(&(v44_20),&(v44_14));
      drop(v44_20);
      let v44_22: Space = intersect(&(v44_21),&(v41_12));
      drop(v44_21);
      let v44_23: Space = range_const::<{3},{4}>(&(v44_22));
      drop(v44_22);
      let mut v44_24 = Space::new();
      let mut v44_24_cursor = (v44_23).read_zipper();
      for v44_24_byte in v44_24_cursor.child_mask().iter() {
        v44_24_cursor.descend_to_byte(v44_24_byte);
        {
        let v44_24_tail = v44_24_cursor.fork_read_zipper();
        let v44_24_head = Path::from_slice(&[v44_24_byte]);
        let v49_2: Space = singleton(&(v44_24_head));
        let v49_3: Space = intersect(&(*CONSTANT_22),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (v49_5).is_empty() { Space::new() } else {
          let v50_6: Space = routine_14(c, &(v44_24_head), &(v44_24_tail).make_space());
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_22),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_10: Space = compose(&(v49_9),&(*CONSTANT_25));
        drop(v49_9);
        let v49_11: Space = unite(&(v49_7),&(v49_10));
        drop(v49_10);
        v44_24.join_into((v49_11).clone());
        }
        v44_24_cursor.ascend(1);
      }
      drop(v44_24_cursor);
      drop(v44_23);
      let v44_25: Space = subtract(&(v44_18),&(v44_24));
      let v44_26: Space = if (v44_25).is_empty() { Space::new() } else {
        compose(&(v44_25),&(v44_14))
      };
      drop(v44_14);
      let mut v44_27 = Space::new();
      let mut v44_27_cursor = (v44_26).read_zipper();
      for v44_27_byte in v44_27_cursor.child_mask().iter() {
        v44_27_cursor.descend_to_byte(v44_27_byte);
        {
        let v44_27_tail = v44_27_cursor.fork_read_zipper();
        let v44_27_head = Path::from_slice(&[v44_27_byte]);
        let v52_2: Space = singleton(&(v44_27_head));
        let v52_3: Space = intersect(&(*CONSTANT_22),&(v52_2));
        let v52_4: Space = if has_head(&(v52_3)) { singleton(&[]) } else { Space::new() };
        drop(v52_3);
        let v52_5: Space = subtract(&(*CONSTANT_0),&(v52_4));
        drop(v52_4);
        let v52_7: Space = if (v52_5).is_empty() { Space::new() } else {
          let v53_6: Space = routine_15(c, &(v44_27_head), &(v44_27_tail).make_space());
          compose(&(v52_5),&(v53_6))
        };
        drop(v52_5);
        let v52_8: Space = intersect(&(*CONSTANT_22),&(v52_2));
        drop(v52_2);
        let v52_9: Space = if has_head(&(v52_8)) { singleton(&[]) } else { Space::new() };
        drop(v52_8);
        let v52_10: Space = compose(&(v52_9),&(v44_27_tail));
        drop(v52_9);
        let v52_11: Space = unite(&(v52_7),&(v52_10));
        drop(v52_10);
        v44_27.join_into((v52_11).clone());
        }
        v44_27_cursor.ascend(1);
      }
      drop(v44_27_cursor);
      compose(&(v42_10),&(v44_27))
    };
    drop(v42_10);
    let v42_29: Space = unite(&(v42_8),&(v42_28));
    v41_28.join_into((v42_29).clone());
    }
    v41_28_cursor.ascend(1);
  }
  drop(v41_28_cursor);
  drop(v41_8);
  drop(v41_10);
  drop(v41_12);
  drop(v41_14);
  drop(v41_16);
  (v41_28).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v54_5: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v54_8: Space = if (v54_5).is_empty() { Space::new() } else {
    let v55_7: Space = unwrap(&(*CONSTANT_24),&(*p0));
    compose(&(v54_5),&(v55_7))
  };
  drop(v54_5);
  let v54_9: Path = concat_path(&(*p1),&(*p0));
  let v54_10: Space = singleton(&(v54_9));
  drop(v54_9);
  let v54_11: Space = subtract(&(v54_8),&(v54_10));
  drop(v54_8);
  let v54_13: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v54_14: Space = intersect(&(v54_11),&(v54_13));
  drop(v54_11);
  let v54_15: Space = range_const::<{2},{3}>(&(v54_14));
  drop(v54_14);
  let mut v54_24 = Space::new();
  let mut v54_24_cursor = (v54_15).read_zipper();
  for v54_24_byte in v54_24_cursor.child_mask().iter() {
    v54_24_cursor.descend_to_byte(v54_24_byte);
    {
    let v54_24_tail = v54_24_cursor.fork_read_zipper();
    let v54_24_head = Path::from_slice(&[v54_24_byte]);
    let v56_2: Space = singleton(&(v54_24_head));
    let v56_3: Space = intersect(&(*CONSTANT_22),&(v56_2));
    let v56_4: Space = if has_head(&(v56_3)) { singleton(&[]) } else { Space::new() };
    drop(v56_3);
    let v56_5: Space = subtract(&(*CONSTANT_0),&(v56_4));
    drop(v56_4);
    let v56_7: Space = if (v56_5).is_empty() { Space::new() } else {
      let mut v57_6 = Space::new();
      let mut v57_6_cursor = (v54_24_tail).read_zipper();
      for v57_6_byte in v57_6_cursor.child_mask().iter() {
        v57_6_cursor.descend_to_byte(v57_6_byte);
        {
        let v57_6_tail = v57_6_cursor.fork_read_zipper();
        let v57_6_head = Path::from_slice(&[v57_6_byte]);
        let v58_2: Space = singleton(&(v57_6_head));
        let v58_3: Space = intersect(&(*CONSTANT_22),&(v58_2));
        let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_8: Space = if (v58_5).is_empty() { Space::new() } else {
          let v59_6: Path = concat_path(&(v54_24_head),&(v57_6_head));
          let v59_7: Space = routine_13(c, &(v59_6), &(v57_6_tail).make_space());
          drop(v59_6);
          compose(&(v58_5),&(v59_7))
        };
        drop(v58_5);
        let v58_9: Space = intersect(&(*CONSTANT_22),&(v58_2));
        drop(v58_2);
        let v58_10: Space = if has_head(&(v58_9)) { singleton(&[]) } else { Space::new() };
        drop(v58_9);
        let v58_11: Space = compose(&(v58_10),&(*CONSTANT_25));
        drop(v58_10);
        let v58_12: Space = unite(&(v58_8),&(v58_11));
        drop(v58_11);
        v57_6.join_into((v58_12).clone());
        }
        v57_6_cursor.ascend(1);
      }
      drop(v57_6_cursor);
      compose(&(v56_5),&(v57_6))
    };
    drop(v56_5);
    let v56_8: Space = intersect(&(*CONSTANT_22),&(v56_2));
    drop(v56_2);
    let v56_9: Space = if has_head(&(v56_8)) { singleton(&[]) } else { Space::new() };
    drop(v56_8);
    let v56_10: Space = compose(&(v56_9),&(*CONSTANT_25));
    drop(v56_9);
    let v56_11: Space = unite(&(v56_7),&(v56_10));
    drop(v56_10);
    v54_24.join_into((v56_11).clone());
    }
    v54_24_cursor.ascend(1);
  }
  drop(v54_24_cursor);
  drop(v54_15);
  let v54_26: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v54_29: Space = if (v54_26).is_empty() { Space::new() } else {
    let v60_28: Space = unwrap(&(*CONSTANT_24),&(*p0));
    compose(&(v54_26),&(v60_28))
  };
  drop(v54_26);
  let v54_30: Space = subtract(&(v54_29),&(v54_10));
  drop(v54_29);
  let v54_31: Space = intersect(&(v54_30),&(v54_13));
  drop(v54_13);
  drop(v54_30);
  let v54_32: Space = range_const::<{3},{4}>(&(v54_31));
  drop(v54_31);
  let mut v54_41 = Space::new();
  let mut v54_41_cursor = (v54_32).read_zipper();
  for v54_41_byte in v54_41_cursor.child_mask().iter() {
    v54_41_cursor.descend_to_byte(v54_41_byte);
    {
    let v54_41_tail = v54_41_cursor.fork_read_zipper();
    let v54_41_head = Path::from_slice(&[v54_41_byte]);
    let v61_2: Space = singleton(&(v54_41_head));
    let v61_3: Space = intersect(&(*CONSTANT_22),&(v61_2));
    let v61_4: Space = if has_head(&(v61_3)) { singleton(&[]) } else { Space::new() };
    drop(v61_3);
    let v61_5: Space = subtract(&(*CONSTANT_0),&(v61_4));
    drop(v61_4);
    let v61_7: Space = if (v61_5).is_empty() { Space::new() } else {
      let mut v62_6 = Space::new();
      let mut v62_6_cursor = (v54_41_tail).read_zipper();
      for v62_6_byte in v62_6_cursor.child_mask().iter() {
        v62_6_cursor.descend_to_byte(v62_6_byte);
        {
        let v62_6_tail = v62_6_cursor.fork_read_zipper();
        let v62_6_head = Path::from_slice(&[v62_6_byte]);
        let v63_2: Space = singleton(&(v62_6_head));
        let v63_3: Space = intersect(&(*CONSTANT_22),&(v63_2));
        let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
        drop(v63_3);
        let v63_5: Space = subtract(&(*CONSTANT_0),&(v63_4));
        drop(v63_4);
        let v63_8: Space = if (v63_5).is_empty() { Space::new() } else {
          let v64_6: Path = concat_path(&(v54_41_head),&(v62_6_head));
          let v64_7: Space = routine_14(c, &(v64_6), &(v62_6_tail).make_space());
          drop(v64_6);
          compose(&(v63_5),&(v64_7))
        };
        drop(v63_5);
        let v63_9: Space = intersect(&(*CONSTANT_22),&(v63_2));
        drop(v63_2);
        let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
        drop(v63_9);
        let v63_11: Space = compose(&(v63_10),&(*CONSTANT_25));
        drop(v63_10);
        let v63_12: Space = unite(&(v63_8),&(v63_11));
        drop(v63_11);
        v62_6.join_into((v63_12).clone());
        }
        v62_6_cursor.ascend(1);
      }
      drop(v62_6_cursor);
      compose(&(v61_5),&(v62_6))
    };
    drop(v61_5);
    let v61_8: Space = intersect(&(*CONSTANT_22),&(v61_2));
    drop(v61_2);
    let v61_9: Space = if has_head(&(v61_8)) { singleton(&[]) } else { Space::new() };
    drop(v61_8);
    let v61_10: Space = compose(&(v61_9),&(*CONSTANT_25));
    drop(v61_9);
    let v61_11: Space = unite(&(v61_7),&(v61_10));
    drop(v61_10);
    v54_41.join_into((v61_11).clone());
    }
    v54_41_cursor.ascend(1);
  }
  drop(v54_41_cursor);
  drop(v54_32);
  let v54_42: Space = subtract(&(v54_24),&(v54_41));
  let v54_43: Space = if (v54_42).is_empty() { Space::new() } else {
    compose(&(v54_42),&(v54_10))
  };
  drop(v54_10);
  let mut v54_50 = Space::new();
  let mut v54_50_cursor = (v54_43).read_zipper();
  for v54_50_byte in v54_50_cursor.child_mask().iter() {
    v54_50_cursor.descend_to_byte(v54_50_byte);
    {
    let v54_50_tail = v54_50_cursor.fork_read_zipper();
    let v54_50_head = Path::from_slice(&[v54_50_byte]);
    let v66_2: Space = singleton(&(v54_50_head));
    let v66_3: Space = intersect(&(*CONSTANT_22),&(v66_2));
    let v66_4: Space = if has_head(&(v66_3)) { singleton(&[]) } else { Space::new() };
    drop(v66_3);
    let v66_5: Space = subtract(&(*CONSTANT_0),&(v66_4));
    drop(v66_4);
    let v66_7: Space = if (v66_5).is_empty() { Space::new() } else {
      let mut v67_6 = Space::new();
      let mut v67_6_cursor = (v54_50_tail).read_zipper();
      for v67_6_byte in v67_6_cursor.child_mask().iter() {
        v67_6_cursor.descend_to_byte(v67_6_byte);
        {
        let v67_6_tail = v67_6_cursor.fork_read_zipper();
        let v67_6_head = Path::from_slice(&[v67_6_byte]);
        let v68_2: Space = singleton(&(v67_6_head));
        let v68_3: Space = intersect(&(*CONSTANT_22),&(v68_2));
        let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
        drop(v68_3);
        let v68_5: Space = subtract(&(*CONSTANT_0),&(v68_4));
        drop(v68_4);
        let v68_8: Space = if (v68_5).is_empty() { Space::new() } else {
          let v69_6: Path = concat_path(&(v54_50_head),&(v67_6_head));
          let v69_7: Space = routine_15(c, &(v69_6), &(v67_6_tail).make_space());
          drop(v69_6);
          compose(&(v68_5),&(v69_7))
        };
        drop(v68_5);
        let v68_9: Space = intersect(&(*CONSTANT_22),&(v68_2));
        drop(v68_2);
        let v68_10: Space = if has_head(&(v68_9)) { singleton(&[]) } else { Space::new() };
        drop(v68_9);
        let v68_11: Space = compose(&(v68_10),&(v67_6_tail));
        drop(v68_10);
        let v68_12: Space = unite(&(v68_8),&(v68_11));
        drop(v68_11);
        v67_6.join_into((v68_12).clone());
        }
        v67_6_cursor.ascend(1);
      }
      drop(v67_6_cursor);
      compose(&(v66_5),&(v67_6))
    };
    drop(v66_5);
    let v66_8: Space = intersect(&(*CONSTANT_22),&(v66_2));
    drop(v66_2);
    let v66_9: Space = if has_head(&(v66_8)) { singleton(&[]) } else { Space::new() };
    drop(v66_8);
    let v66_10: Space = compose(&(v66_9),&(v54_50_tail));
    drop(v66_9);
    let v66_11: Space = unite(&(v66_7),&(v66_10));
    drop(v66_10);
    v54_50.join_into((v66_11).clone());
    }
    v54_50_cursor.ascend(1);
  }
  drop(v54_50_cursor);
  (v54_50).clone()
}

fn routine_7(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v70_7: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v70_9: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let mut v70_10 = Space::new();
  let mut v70_10_cursor = (*s0).read_zipper();
  for v70_10_byte in v70_10_cursor.child_mask().iter() {
    v70_10_cursor.descend_to_byte(v70_10_byte);
    {
    let v70_10_tail = v70_10_cursor.fork_read_zipper();
    let v70_10_head = Path::from_slice(&[v70_10_byte]);
    let v71_2: Space = singleton(&(v70_10_head));
    let v71_3: Space = intersect(&(*CONSTANT_22),&(v71_2));
    let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
    drop(v71_3);
    let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
    drop(v71_4);
    let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
      let v72_6: Path = concat_path(&(*p0),&(v70_10_head));
      let v72_7: Space = routine_7(c, &(v72_6), &(*p1), &(v70_10_tail).make_space());
      compose(&(v71_5),&(v72_7))
    };
    drop(v71_5);
    let v71_9: Space = intersect(&(*CONSTANT_22),&(v71_2));
    drop(v71_2);
    let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
    drop(v71_9);
    let v71_16: Space = if (v71_10).is_empty() { Space::new() } else {
      let v73_6: Path = concat_path(&(*p0),&(v70_10_head));
      let v73_12: Space = if (v70_7).is_empty() { Space::new() } else {
        let v74_11: Space = unwrap(&(v70_9),&(v70_10_head));
        compose(&(v70_7),&(v74_11))
      };
      let v73_13: Path = concat_path(&(*p1),&(v73_6));
      drop(v73_6);
      let v73_14: Space = singleton(&(v73_13));
      drop(v73_13);
      let v73_15: Space = subtract(&(v73_12),&(v73_14));
      drop(v73_12);
      drop(v73_14);
      compose(&(v71_10),&(v73_15))
    };
    drop(v71_10);
    let v71_17: Space = unite(&(v71_8),&(v71_16));
    drop(v71_16);
    v70_10.join_into((v71_17).clone());
    }
    v70_10_cursor.ascend(1);
  }
  drop(v70_10_cursor);
  drop(v70_7);
  drop(v70_9);
  (v70_10).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v75_8: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v75_10: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let v75_12: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v75_14: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v75_16: Space = unwrap(&(*CONSTANT_24),&(*p0));
  let mut v75_28 = Space::new();
  let mut v75_28_cursor = (*s0).read_zipper();
  for v75_28_byte in v75_28_cursor.child_mask().iter() {
    v75_28_cursor.descend_to_byte(v75_28_byte);
    {
    let v75_28_tail = v75_28_cursor.fork_read_zipper();
    let v75_28_head = Path::from_slice(&[v75_28_byte]);
    let v76_2: Space = singleton(&(v75_28_head));
    let v76_3: Space = intersect(&(*CONSTANT_22),&(v76_2));
    let v76_4: Space = if has_head(&(v76_3)) { singleton(&[]) } else { Space::new() };
    drop(v76_3);
    let v76_5: Space = subtract(&(*CONSTANT_0),&(v76_4));
    drop(v76_4);
    let v76_8: Space = if (v76_5).is_empty() { Space::new() } else {
      let v77_6: Path = concat_path(&(*p0),&(v75_28_head));
      let v77_7: Space = routine_8(c, &(v77_6), &(*p1), &(v75_28_tail).make_space(), &(*s1));
      compose(&(v76_5),&(v77_7))
    };
    drop(v76_5);
    let v76_9: Space = intersect(&(*CONSTANT_22),&(v76_2));
    drop(v76_2);
    let v76_10: Space = if has_head(&(v76_9)) { singleton(&[]) } else { Space::new() };
    drop(v76_9);
    let v76_28: Space = if (v76_10).is_empty() { Space::new() } else {
      let v78_6: Path = concat_path(&(*p0),&(v75_28_head));
      let v78_12: Space = if (v75_8).is_empty() { Space::new() } else {
        let v79_11: Space = unwrap(&(v75_10),&(v75_28_head));
        compose(&(v75_8),&(v79_11))
      };
      let v78_13: Path = concat_path(&(*p1),&(v78_6));
      drop(v78_6);
      let v78_14: Space = singleton(&(v78_13));
      drop(v78_13);
      let v78_15: Space = subtract(&(v78_12),&(v78_14));
      drop(v78_12);
      let v78_16: Space = intersect(&(v78_15),&(v75_12));
      drop(v78_15);
      let v78_17: Space = range_const::<{3},{4}>(&(v78_16));
      drop(v78_16);
      let mut v78_18 = Space::new();
      let mut v78_18_cursor = (v78_17).read_zipper();
      for v78_18_byte in v78_18_cursor.child_mask().iter() {
        v78_18_cursor.descend_to_byte(v78_18_byte);
        {
        let v78_18_tail = v78_18_cursor.fork_read_zipper();
        let v78_18_head = Path::from_slice(&[v78_18_byte]);
        let v80_2: Space = singleton(&(v78_18_head));
        let v80_3: Space = intersect(&(*CONSTANT_22),&(v80_2));
        let v80_4: Space = if has_head(&(v80_3)) { singleton(&[]) } else { Space::new() };
        drop(v80_3);
        let v80_5: Space = subtract(&(*CONSTANT_0),&(v80_4));
        drop(v80_4);
        let v80_7: Space = if (v80_5).is_empty() { Space::new() } else {
          let v81_6: Space = routine_10(c, &(v78_18_head), &(v78_18_tail).make_space());
          compose(&(v80_5),&(v81_6))
        };
        drop(v80_5);
        let v80_8: Space = intersect(&(*CONSTANT_22),&(v80_2));
        drop(v80_2);
        let v80_9: Space = if has_head(&(v80_8)) { singleton(&[]) } else { Space::new() };
        drop(v80_8);
        let v80_10: Space = compose(&(v80_9),&(*CONSTANT_25));
        drop(v80_9);
        let v80_11: Space = unite(&(v80_7),&(v80_10));
        drop(v80_10);
        v78_18.join_into((v80_11).clone());
        }
        v78_18_cursor.ascend(1);
      }
      drop(v78_18_cursor);
      drop(v78_17);
      let v78_20: Space = if (v75_14).is_empty() { Space::new() } else {
        let v82_19: Space = unwrap(&(v75_16),&(v75_28_head));
        compose(&(v75_14),&(v82_19))
      };
      let v78_21: Space = subtract(&(v78_20),&(v78_14));
      drop(v78_20);
      let v78_22: Space = intersect(&(v78_21),&(v75_12));
      drop(v78_21);
      let v78_23: Space = range_const::<{4},{5}>(&(v78_22));
      drop(v78_22);
      let mut v78_24 = Space::new();
      let mut v78_24_cursor = (v78_23).read_zipper();
      for v78_24_byte in v78_24_cursor.child_mask().iter() {
        v78_24_cursor.descend_to_byte(v78_24_byte);
        {
        let v78_24_tail = v78_24_cursor.fork_read_zipper();
        let v78_24_head = Path::from_slice(&[v78_24_byte]);
        let v83_2: Space = singleton(&(v78_24_head));
        let v83_3: Space = intersect(&(*CONSTANT_22),&(v83_2));
        let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
        drop(v83_3);
        let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
        drop(v83_4);
        let v83_7: Space = if (v83_5).is_empty() { Space::new() } else {
          let v84_6: Space = routine_11(c, &(v78_24_head), &(v78_24_tail).make_space());
          compose(&(v83_5),&(v84_6))
        };
        drop(v83_5);
        let v83_8: Space = intersect(&(*CONSTANT_22),&(v83_2));
        drop(v83_2);
        let v83_9: Space = if has_head(&(v83_8)) { singleton(&[]) } else { Space::new() };
        drop(v83_8);
        let v83_10: Space = compose(&(v83_9),&(*CONSTANT_25));
        drop(v83_9);
        let v83_11: Space = unite(&(v83_7),&(v83_10));
        drop(v83_10);
        v78_24.join_into((v83_11).clone());
        }
        v78_24_cursor.ascend(1);
      }
      drop(v78_24_cursor);
      drop(v78_23);
      let v78_25: Space = subtract(&(v78_18),&(v78_24));
      let v78_26: Space = if (v78_25).is_empty() { Space::new() } else {
        compose(&(v78_25),&(v78_14))
      };
      drop(v78_14);
      let mut v78_27 = Space::new();
      let mut v78_27_cursor = (v78_26).read_zipper();
      for v78_27_byte in v78_27_cursor.child_mask().iter() {
        v78_27_cursor.descend_to_byte(v78_27_byte);
        {
        let v78_27_tail = v78_27_cursor.fork_read_zipper();
        let v78_27_head = Path::from_slice(&[v78_27_byte]);
        let v86_2: Space = singleton(&(v78_27_head));
        let v86_3: Space = intersect(&(*CONSTANT_22),&(v86_2));
        let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
        drop(v86_3);
        let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
        drop(v86_4);
        let v86_7: Space = if (v86_5).is_empty() { Space::new() } else {
          let v87_6: Space = routine_12(c, &(v78_27_head), &(v78_27_tail).make_space());
          compose(&(v86_5),&(v87_6))
        };
        drop(v86_5);
        let v86_8: Space = intersect(&(*CONSTANT_22),&(v86_2));
        drop(v86_2);
        let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
        drop(v86_8);
        let v86_10: Space = compose(&(v86_9),&(v78_27_tail));
        drop(v86_9);
        let v86_11: Space = unite(&(v86_7),&(v86_10));
        drop(v86_10);
        v78_27.join_into((v86_11).clone());
        }
        v78_27_cursor.ascend(1);
      }
      drop(v78_27_cursor);
      compose(&(v76_10),&(v78_27))
    };
    drop(v76_10);
    let v76_29: Space = unite(&(v76_8),&(v76_28));
    v75_28.join_into((v76_29).clone());
    }
    v75_28_cursor.ascend(1);
  }
  drop(v75_28_cursor);
  drop(v75_8);
  drop(v75_10);
  drop(v75_12);
  drop(v75_14);
  drop(v75_16);
  (v75_28).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v88_5: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
    let v89_7: Space = unwrap(&(*CONSTANT_24),&(*p0));
    compose(&(v88_5),&(v89_7))
  };
  drop(v88_5);
  let v88_9: Path = concat_path(&(*p1),&(*p0));
  let v88_10: Space = singleton(&(v88_9));
  drop(v88_9);
  let v88_11: Space = subtract(&(v88_8),&(v88_10));
  drop(v88_8);
  let v88_13: Space = unwrap(&(*s1),&(*CONSTANT_23));
  let v88_14: Space = intersect(&(v88_11),&(v88_13));
  drop(v88_11);
  let v88_15: Space = range_const::<{3},{4}>(&(v88_14));
  drop(v88_14);
  let mut v88_24 = Space::new();
  let mut v88_24_cursor = (v88_15).read_zipper();
  for v88_24_byte in v88_24_cursor.child_mask().iter() {
    v88_24_cursor.descend_to_byte(v88_24_byte);
    {
    let v88_24_tail = v88_24_cursor.fork_read_zipper();
    let v88_24_head = Path::from_slice(&[v88_24_byte]);
    let v90_2: Space = singleton(&(v88_24_head));
    let v90_3: Space = intersect(&(*CONSTANT_22),&(v90_2));
    let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
    drop(v90_3);
    let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
    drop(v90_4);
    let v90_7: Space = if (v90_5).is_empty() { Space::new() } else {
      let mut v91_6 = Space::new();
      let mut v91_6_cursor = (v88_24_tail).read_zipper();
      for v91_6_byte in v91_6_cursor.child_mask().iter() {
        v91_6_cursor.descend_to_byte(v91_6_byte);
        {
        let v91_6_tail = v91_6_cursor.fork_read_zipper();
        let v91_6_head = Path::from_slice(&[v91_6_byte]);
        let v92_2: Space = singleton(&(v91_6_head));
        let v92_3: Space = intersect(&(*CONSTANT_22),&(v92_2));
        let v92_4: Space = if has_head(&(v92_3)) { singleton(&[]) } else { Space::new() };
        drop(v92_3);
        let v92_5: Space = subtract(&(*CONSTANT_0),&(v92_4));
        drop(v92_4);
        let v92_8: Space = if (v92_5).is_empty() { Space::new() } else {
          let v93_6: Path = concat_path(&(v88_24_head),&(v91_6_head));
          let v93_7: Space = routine_10(c, &(v93_6), &(v91_6_tail).make_space());
          drop(v93_6);
          compose(&(v92_5),&(v93_7))
        };
        drop(v92_5);
        let v92_9: Space = intersect(&(*CONSTANT_22),&(v92_2));
        drop(v92_2);
        let v92_10: Space = if has_head(&(v92_9)) { singleton(&[]) } else { Space::new() };
        drop(v92_9);
        let v92_11: Space = compose(&(v92_10),&(*CONSTANT_25));
        drop(v92_10);
        let v92_12: Space = unite(&(v92_8),&(v92_11));
        drop(v92_11);
        v91_6.join_into((v92_12).clone());
        }
        v91_6_cursor.ascend(1);
      }
      drop(v91_6_cursor);
      compose(&(v90_5),&(v91_6))
    };
    drop(v90_5);
    let v90_8: Space = intersect(&(*CONSTANT_22),&(v90_2));
    drop(v90_2);
    let v90_9: Space = if has_head(&(v90_8)) { singleton(&[]) } else { Space::new() };
    drop(v90_8);
    let v90_10: Space = compose(&(v90_9),&(*CONSTANT_25));
    drop(v90_9);
    let v90_11: Space = unite(&(v90_7),&(v90_10));
    drop(v90_10);
    v88_24.join_into((v90_11).clone());
    }
    v88_24_cursor.ascend(1);
  }
  drop(v88_24_cursor);
  drop(v88_15);
  let v88_26: Space = unwrap(&(*CONSTANT_24),&(*p1));
  let v88_29: Space = if (v88_26).is_empty() { Space::new() } else {
    let v94_28: Space = unwrap(&(*CONSTANT_24),&(*p0));
    compose(&(v88_26),&(v94_28))
  };
  drop(v88_26);
  let v88_30: Space = subtract(&(v88_29),&(v88_10));
  drop(v88_29);
  let v88_31: Space = intersect(&(v88_30),&(v88_13));
  drop(v88_13);
  drop(v88_30);
  let v88_32: Space = range_const::<{4},{5}>(&(v88_31));
  drop(v88_31);
  let mut v88_41 = Space::new();
  let mut v88_41_cursor = (v88_32).read_zipper();
  for v88_41_byte in v88_41_cursor.child_mask().iter() {
    v88_41_cursor.descend_to_byte(v88_41_byte);
    {
    let v88_41_tail = v88_41_cursor.fork_read_zipper();
    let v88_41_head = Path::from_slice(&[v88_41_byte]);
    let v95_2: Space = singleton(&(v88_41_head));
    let v95_3: Space = intersect(&(*CONSTANT_22),&(v95_2));
    let v95_4: Space = if has_head(&(v95_3)) { singleton(&[]) } else { Space::new() };
    drop(v95_3);
    let v95_5: Space = subtract(&(*CONSTANT_0),&(v95_4));
    drop(v95_4);
    let v95_7: Space = if (v95_5).is_empty() { Space::new() } else {
      let mut v96_6 = Space::new();
      let mut v96_6_cursor = (v88_41_tail).read_zipper();
      for v96_6_byte in v96_6_cursor.child_mask().iter() {
        v96_6_cursor.descend_to_byte(v96_6_byte);
        {
        let v96_6_tail = v96_6_cursor.fork_read_zipper();
        let v96_6_head = Path::from_slice(&[v96_6_byte]);
        let v97_2: Space = singleton(&(v96_6_head));
        let v97_3: Space = intersect(&(*CONSTANT_22),&(v97_2));
        let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
        drop(v97_3);
        let v97_5: Space = subtract(&(*CONSTANT_0),&(v97_4));
        drop(v97_4);
        let v97_8: Space = if (v97_5).is_empty() { Space::new() } else {
          let v98_6: Path = concat_path(&(v88_41_head),&(v96_6_head));
          let v98_7: Space = routine_11(c, &(v98_6), &(v96_6_tail).make_space());
          drop(v98_6);
          compose(&(v97_5),&(v98_7))
        };
        drop(v97_5);
        let v97_9: Space = intersect(&(*CONSTANT_22),&(v97_2));
        drop(v97_2);
        let v97_10: Space = if has_head(&(v97_9)) { singleton(&[]) } else { Space::new() };
        drop(v97_9);
        let v97_11: Space = compose(&(v97_10),&(*CONSTANT_25));
        drop(v97_10);
        let v97_12: Space = unite(&(v97_8),&(v97_11));
        drop(v97_11);
        v96_6.join_into((v97_12).clone());
        }
        v96_6_cursor.ascend(1);
      }
      drop(v96_6_cursor);
      compose(&(v95_5),&(v96_6))
    };
    drop(v95_5);
    let v95_8: Space = intersect(&(*CONSTANT_22),&(v95_2));
    drop(v95_2);
    let v95_9: Space = if has_head(&(v95_8)) { singleton(&[]) } else { Space::new() };
    drop(v95_8);
    let v95_10: Space = compose(&(v95_9),&(*CONSTANT_25));
    drop(v95_9);
    let v95_11: Space = unite(&(v95_7),&(v95_10));
    drop(v95_10);
    v88_41.join_into((v95_11).clone());
    }
    v88_41_cursor.ascend(1);
  }
  drop(v88_41_cursor);
  drop(v88_32);
  let v88_42: Space = subtract(&(v88_24),&(v88_41));
  let v88_43: Space = if (v88_42).is_empty() { Space::new() } else {
    compose(&(v88_42),&(v88_10))
  };
  drop(v88_10);
  let mut v88_50 = Space::new();
  let mut v88_50_cursor = (v88_43).read_zipper();
  for v88_50_byte in v88_50_cursor.child_mask().iter() {
    v88_50_cursor.descend_to_byte(v88_50_byte);
    {
    let v88_50_tail = v88_50_cursor.fork_read_zipper();
    let v88_50_head = Path::from_slice(&[v88_50_byte]);
    let v100_2: Space = singleton(&(v88_50_head));
    let v100_3: Space = intersect(&(*CONSTANT_22),&(v100_2));
    let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
    drop(v100_3);
    let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
    drop(v100_4);
    let v100_7: Space = if (v100_5).is_empty() { Space::new() } else {
      let mut v101_6 = Space::new();
      let mut v101_6_cursor = (v88_50_tail).read_zipper();
      for v101_6_byte in v101_6_cursor.child_mask().iter() {
        v101_6_cursor.descend_to_byte(v101_6_byte);
        {
        let v101_6_tail = v101_6_cursor.fork_read_zipper();
        let v101_6_head = Path::from_slice(&[v101_6_byte]);
        let v102_2: Space = singleton(&(v101_6_head));
        let v102_3: Space = intersect(&(*CONSTANT_22),&(v102_2));
        let v102_4: Space = if has_head(&(v102_3)) { singleton(&[]) } else { Space::new() };
        drop(v102_3);
        let v102_5: Space = subtract(&(*CONSTANT_0),&(v102_4));
        drop(v102_4);
        let v102_8: Space = if (v102_5).is_empty() { Space::new() } else {
          let v103_6: Path = concat_path(&(v88_50_head),&(v101_6_head));
          let v103_7: Space = routine_12(c, &(v103_6), &(v101_6_tail).make_space());
          drop(v103_6);
          compose(&(v102_5),&(v103_7))
        };
        drop(v102_5);
        let v102_9: Space = intersect(&(*CONSTANT_22),&(v102_2));
        drop(v102_2);
        let v102_10: Space = if has_head(&(v102_9)) { singleton(&[]) } else { Space::new() };
        drop(v102_9);
        let v102_11: Space = compose(&(v102_10),&(v101_6_tail));
        drop(v102_10);
        let v102_12: Space = unite(&(v102_8),&(v102_11));
        drop(v102_11);
        v101_6.join_into((v102_12).clone());
        }
        v101_6_cursor.ascend(1);
      }
      drop(v101_6_cursor);
      compose(&(v100_5),&(v101_6))
    };
    drop(v100_5);
    let v100_8: Space = intersect(&(*CONSTANT_22),&(v100_2));
    drop(v100_2);
    let v100_9: Space = if has_head(&(v100_8)) { singleton(&[]) } else { Space::new() };
    drop(v100_8);
    let v100_10: Space = compose(&(v100_9),&(v88_50_tail));
    drop(v100_9);
    let v100_11: Space = unite(&(v100_7),&(v100_10));
    drop(v100_10);
    v88_50.join_into((v100_11).clone());
    }
    v88_50_cursor.ascend(1);
  }
  drop(v88_50_cursor);
  (v88_50).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v104_6 = Space::new();
  let mut v104_6_cursor = (*s0).read_zipper();
  for v104_6_byte in v104_6_cursor.child_mask().iter() {
    v104_6_cursor.descend_to_byte(v104_6_byte);
    {
    let v104_6_tail = v104_6_cursor.fork_read_zipper();
    let v104_6_head = Path::from_slice(&[v104_6_byte]);
    let v105_2: Space = singleton(&(v104_6_head));
    let v105_3: Space = intersect(&(*CONSTANT_22),&(v105_2));
    let v105_4: Space = if has_head(&(v105_3)) { singleton(&[]) } else { Space::new() };
    drop(v105_3);
    let v105_5: Space = subtract(&(*CONSTANT_0),&(v105_4));
    drop(v105_4);
    let v105_8: Space = if (v105_5).is_empty() { Space::new() } else {
      let v106_6: Path = concat_path(&(*p0),&(v104_6_head));
      let v106_7: Space = routine_10(c, &(v106_6), &(v104_6_tail).make_space());
      drop(v106_6);
      compose(&(v105_5),&(v106_7))
    };
    drop(v105_5);
    let v105_9: Space = intersect(&(*CONSTANT_22),&(v105_2));
    drop(v105_2);
    let v105_10: Space = if has_head(&(v105_9)) { singleton(&[]) } else { Space::new() };
    drop(v105_9);
    let v105_11: Space = compose(&(v105_10),&(*CONSTANT_25));
    drop(v105_10);
    let v105_12: Space = unite(&(v105_8),&(v105_11));
    drop(v105_11);
    v104_6.join_into((v105_12).clone());
    }
    v104_6_cursor.ascend(1);
  }
  drop(v104_6_cursor);
  (v104_6).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v107_6 = Space::new();
  let mut v107_6_cursor = (*s0).read_zipper();
  for v107_6_byte in v107_6_cursor.child_mask().iter() {
    v107_6_cursor.descend_to_byte(v107_6_byte);
    {
    let v107_6_tail = v107_6_cursor.fork_read_zipper();
    let v107_6_head = Path::from_slice(&[v107_6_byte]);
    let v108_2: Space = singleton(&(v107_6_head));
    let v108_3: Space = intersect(&(*CONSTANT_22),&(v108_2));
    let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
    drop(v108_3);
    let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
    drop(v108_4);
    let v108_8: Space = if (v108_5).is_empty() { Space::new() } else {
      let v109_6: Path = concat_path(&(*p0),&(v107_6_head));
      let v109_7: Space = routine_11(c, &(v109_6), &(v107_6_tail).make_space());
      drop(v109_6);
      compose(&(v108_5),&(v109_7))
    };
    drop(v108_5);
    let v108_9: Space = intersect(&(*CONSTANT_22),&(v108_2));
    drop(v108_2);
    let v108_10: Space = if has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
    drop(v108_9);
    let v108_11: Space = compose(&(v108_10),&(*CONSTANT_25));
    drop(v108_10);
    let v108_12: Space = unite(&(v108_8),&(v108_11));
    drop(v108_11);
    v107_6.join_into((v108_12).clone());
    }
    v107_6_cursor.ascend(1);
  }
  drop(v107_6_cursor);
  (v107_6).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v110_5 = Space::new();
  let mut v110_5_cursor = (*s0).read_zipper();
  for v110_5_byte in v110_5_cursor.child_mask().iter() {
    v110_5_cursor.descend_to_byte(v110_5_byte);
    {
    let v110_5_tail = v110_5_cursor.fork_read_zipper();
    let v110_5_head = Path::from_slice(&[v110_5_byte]);
    let v111_2: Space = singleton(&(v110_5_head));
    let v111_3: Space = intersect(&(*CONSTANT_22),&(v111_2));
    let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = subtract(&(*CONSTANT_0),&(v111_4));
    drop(v111_4);
    let v111_8: Space = if (v111_5).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&(v110_5_head));
      let v112_7: Space = routine_12(c, &(v112_6), &(v110_5_tail).make_space());
      drop(v112_6);
      compose(&(v111_5),&(v112_7))
    };
    drop(v111_5);
    let v111_9: Space = intersect(&(*CONSTANT_22),&(v111_2));
    drop(v111_2);
    let v111_10: Space = if has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
    drop(v111_9);
    let v111_11: Space = compose(&(v111_10),&(v110_5_tail));
    drop(v111_10);
    let v111_12: Space = unite(&(v111_8),&(v111_11));
    drop(v111_11);
    v110_5.join_into((v111_12).clone());
    }
    v110_5_cursor.ascend(1);
  }
  drop(v110_5_cursor);
  (v110_5).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v113_6 = Space::new();
  let mut v113_6_cursor = (*s0).read_zipper();
  for v113_6_byte in v113_6_cursor.child_mask().iter() {
    v113_6_cursor.descend_to_byte(v113_6_byte);
    {
    let v113_6_tail = v113_6_cursor.fork_read_zipper();
    let v113_6_head = Path::from_slice(&[v113_6_byte]);
    let v114_2: Space = singleton(&(v113_6_head));
    let v114_3: Space = intersect(&(*CONSTANT_22),&(v114_2));
    let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
    drop(v114_3);
    let v114_5: Space = subtract(&(*CONSTANT_0),&(v114_4));
    drop(v114_4);
    let v114_8: Space = if (v114_5).is_empty() { Space::new() } else {
      let v115_6: Path = concat_path(&(*p0),&(v113_6_head));
      let v115_7: Space = routine_13(c, &(v115_6), &(v113_6_tail).make_space());
      drop(v115_6);
      compose(&(v114_5),&(v115_7))
    };
    drop(v114_5);
    let v114_9: Space = intersect(&(*CONSTANT_22),&(v114_2));
    drop(v114_2);
    let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
    drop(v114_9);
    let v114_11: Space = compose(&(v114_10),&(*CONSTANT_25));
    drop(v114_10);
    let v114_12: Space = unite(&(v114_8),&(v114_11));
    drop(v114_11);
    v113_6.join_into((v114_12).clone());
    }
    v113_6_cursor.ascend(1);
  }
  drop(v113_6_cursor);
  (v113_6).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v116_6 = Space::new();
  let mut v116_6_cursor = (*s0).read_zipper();
  for v116_6_byte in v116_6_cursor.child_mask().iter() {
    v116_6_cursor.descend_to_byte(v116_6_byte);
    {
    let v116_6_tail = v116_6_cursor.fork_read_zipper();
    let v116_6_head = Path::from_slice(&[v116_6_byte]);
    let v117_2: Space = singleton(&(v116_6_head));
    let v117_3: Space = intersect(&(*CONSTANT_22),&(v117_2));
    let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
    drop(v117_3);
    let v117_5: Space = subtract(&(*CONSTANT_0),&(v117_4));
    drop(v117_4);
    let v117_8: Space = if (v117_5).is_empty() { Space::new() } else {
      let v118_6: Path = concat_path(&(*p0),&(v116_6_head));
      let v118_7: Space = routine_14(c, &(v118_6), &(v116_6_tail).make_space());
      drop(v118_6);
      compose(&(v117_5),&(v118_7))
    };
    drop(v117_5);
    let v117_9: Space = intersect(&(*CONSTANT_22),&(v117_2));
    drop(v117_2);
    let v117_10: Space = if has_head(&(v117_9)) { singleton(&[]) } else { Space::new() };
    drop(v117_9);
    let v117_11: Space = compose(&(v117_10),&(*CONSTANT_25));
    drop(v117_10);
    let v117_12: Space = unite(&(v117_8),&(v117_11));
    drop(v117_11);
    v116_6.join_into((v117_12).clone());
    }
    v116_6_cursor.ascend(1);
  }
  drop(v116_6_cursor);
  (v116_6).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v119_5 = Space::new();
  let mut v119_5_cursor = (*s0).read_zipper();
  for v119_5_byte in v119_5_cursor.child_mask().iter() {
    v119_5_cursor.descend_to_byte(v119_5_byte);
    {
    let v119_5_tail = v119_5_cursor.fork_read_zipper();
    let v119_5_head = Path::from_slice(&[v119_5_byte]);
    let v120_2: Space = singleton(&(v119_5_head));
    let v120_3: Space = intersect(&(*CONSTANT_22),&(v120_2));
    let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
    drop(v120_3);
    let v120_5: Space = subtract(&(*CONSTANT_0),&(v120_4));
    drop(v120_4);
    let v120_8: Space = if (v120_5).is_empty() { Space::new() } else {
      let v121_6: Path = concat_path(&(*p0),&(v119_5_head));
      let v121_7: Space = routine_15(c, &(v121_6), &(v119_5_tail).make_space());
      drop(v121_6);
      compose(&(v120_5),&(v121_7))
    };
    drop(v120_5);
    let v120_9: Space = intersect(&(*CONSTANT_22),&(v120_2));
    drop(v120_2);
    let v120_10: Space = if has_head(&(v120_9)) { singleton(&[]) } else { Space::new() };
    drop(v120_9);
    let v120_11: Space = compose(&(v120_10),&(v119_5_tail));
    drop(v120_10);
    let v120_12: Space = unite(&(v120_8),&(v120_11));
    drop(v120_11);
    v119_5.join_into((v120_12).clone());
    }
    v119_5_cursor.ascend(1);
  }
  drop(v119_5_cursor);
  (v119_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
